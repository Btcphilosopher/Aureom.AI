"""SoC backend: the UNMODIFIED sf_albion_cloud_top (ControlCore + fabric + SRAM + DMA + MGMT mailbox) with the real RV32I firmware.

Drives the product's own Verilator harness (sim/albion/albion_sim.cpp) over its line protocol, so host-visible latencies include the
real MMIO block, MGMT registers, command/completion queues, firmware execution, IRQ and host-side register reads.

Latency definition: device clock cycles (the harness `CYC` counter) between two host-side events.  The harness executes one MMIO
transaction at a time (as a PCIe BAR access that waits for completion does), so an MMIO read/write costs the cycles from request
presentation to response observation.

Hardware availability is PROBED here, not assumed: MGMT.FEAT_IMPL / FEAT_REQ / FEAT_UNAVAIL are read from a CONFIG=2 build (which requests
every feature) and the corresponding opcodes are sent to the firmware, which must answer UNSUPPORTED.
"""
import pathlib
import statistics
import subprocess

from .. import metrics as M
from .. import toolchain
from .. import runner as R

MGMT = 0x40000000
TELEM = 0x40004000
CHIP_ID = 0x53464190
M_CHIP_ID, M_FEAT_IMPL, M_FEAT_REQ, M_FEAT_UNAVAIL, M_CONFIG_ID = 0x000, 0x00C, 0x010, 0x014, 0x008
M_DEV_STATUS, M_CORE_CTRL, M_FW_STATUS, M_IRQ_STATUS, M_IRQ_ENABLE = 0x040, 0x044, 0x050, 0x060, 0x064
M_HCMD_W0, M_HCMD_SUBMIT, M_HCPL_W0, M_HCPL_POP, M_HCPLQ_STATUS = 0x100, 0x120, 0x140, 0x150, 0x154
TC_CYCLES, TC_M_CORE_TXN, TC_M_HOST_TXN, TC_M_HOST_STALL, TC_M_CORE_STALL, TC_CORE_INSTRET, TC_CORE_SLEEP = 0, 1, 4, 8, 5, 30, 31
TC_DMA_BYTES = 20
OP = {"PING": 0x01, "ALLOC": 0x10, "DMA_FILL": 0x21, "PKT_CLASSIFY": 0x50, "VBLK_IO": 0x51, "MATMUL_INT8": 0x52}
ST = {0: "OK", 1: "BAD_OPCODE", 2: "BAD_PARAM", 3: "NO_RESOURCE", 4: "DENIED", 5: "HW_PERM", 6: "HW_DECERR", 7: "ECC_UE", 8: "UNSUPPORTED",
      9: "TIMEOUT", 10: "HW_SLVERR", 11: "HOST_FAULT"}
FEATURES = {0: "CONTROLCORE", 1: "DATAFABRIC", 2: "SRAM_ECC", 3: "DMA", 4: "PERMISSION", 5: "TELEMETRY", 6: "RAS", 7: "HOSTIF",
            8: "PACKETFORGE", 9: "VIRTUALFOUNDRY", 10: "COMPUTEWORKS", 11: "IRQ"}
POLL_CHUNK = 64


class SimError(RuntimeError):
    pass


class SocSim:
    def __init__(self, binary, seed=1):
        self.banner = []
        self.p = subprocess.Popen([str(binary), "+verilator+rand+reset+2", f"+verilator+seed+{seed + 1}"], stdin=subprocess.PIPE,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)

    def cmd(self, line):
        self.p.stdin.write(line + "\n")
        self.p.stdin.flush()
        while True:
            raw = self.p.stdout.readline()
            if raw == "":
                raise SimError(f"{line[:60]!r}: simulator exited")
            reply = raw.strip()
            if reply.startswith("OK") or reply.startswith("ERR"):
                break
            self.banner.append(reply)          # RTL $display output (e.g. the requested-but-unavailable feature notice)
        if not reply.startswith("OK"):
            raise SimError(f"{line[:60]!r} -> {reply!r}")
        return reply.split()[1:]

    def close(self):
        try:
            self.cmd("QUIT")
        except Exception:
            pass
        try:
            self.p.stdin.close()
            self.p.wait(timeout=20)
        except Exception:
            self.p.kill()

    def cyc(self):
        return int(self.cmd("CYC")[0])

    def r(self, addr):
        d, e = self.cmd(f"R {addr:#x}")
        if int(e):
            raise SimError(f"read {addr:#x}: fabric error {e}")
        return int(d)

    def w(self, addr, val):
        (e,) = self.cmd(f"W {addr:#x} {val:#x}")
        if int(e):
            raise SimError(f"write {addr:#x}: fabric error {e}")

    def step(self, n):
        self.cmd(f"STEP {n}")

    def wait_irq(self, mx):
        fired, waited = self.cmd(f"WAITIRQ {mx}")
        return bool(int(fired)), int(waited)

    # ------------------------------------------------------------------------- bring-up (identical to the runtime's sequence)
    def boot(self, firmware_bin, host_latency=1):
        self.cmd("RESET")
        self.cmd("STRAP 0")
        self.cmd(f"HMLAT {host_latency}")
        if self.r(MGMT + M_CHIP_ID) != CHIP_ID:
            raise SimError("unexpected CHIP_ID")
        for _ in range(200):
            if self.r(MGMT + M_DEV_STATUS) & 1:
                break
            self.step(POLL_CHUNK)
        else:
            raise SimError("SRAM scrub did not complete")
        data = pathlib.Path(firmware_bin).read_bytes()
        data += b"\0" * (-len(data) % 4)
        words = [int.from_bytes(data[i:i + 4], "little") for i in range(0, len(data), 4)]
        (nerr,) = self.cmd(f"WB 0x0 {len(words)} " + " ".join(f"{w:#x}" for w in words))
        if int(nerr):
            raise SimError(f"{nerr} firmware load writes failed")
        self.w(MGMT + M_CORE_CTRL, 1)
        for _ in range(200):
            st = self.r(MGMT + M_FW_STATUS)
            if st == 2:
                break
            if st & 0xFFFF0000 == 0xDEAD0000:
                raise SimError(f"firmware fatal 0x{st:08x}")
            self.step(POLL_CHUNK)
        else:
            raise SimError("firmware never reported READY")
        self.w(MGMT + M_IRQ_ENABLE, 1)

    # ------------------------------------------------------------------------- mailbox
    def submit(self, opcode, args=(), domain=2, tag=1):
        words = [opcode | (domain << 8) | (tag << 16)] + list(args)
        words += [0] * (8 - len(words))
        for i, v in enumerate(words):
            self.w(MGMT + M_HCMD_W0 + 4 * i, v)
        self.w(MGMT + M_HCMD_SUBMIT, 1)

    def complete(self, max_cycles=20_000_000):
        """Same sequence as the runtime's wait(): status read, IRQ wait, drain.  Returns (cpl_words, marks)."""
        marks = {}
        waited = 0
        while True:
            if self.r(MGMT + M_HCPLQ_STATUS) & 0xFF:
                break
            marks.setdefault("first_empty_poll", self.cyc())
            fired, w = self.wait_irq(POLL_CHUNK * 64)
            waited += w
            if waited > max_cycles:
                raise SimError("completion timeout")
        marks["irq_seen"] = self.cyc()
        cpl = [self.r(MGMT + M_HCPL_W0 + 4 * i) for i in range(4)]
        self.w(MGMT + M_HCPL_POP, 1)
        return cpl, marks

    def counters(self, idxs):
        return {i: self.r(TELEM + 0x100 + 8 * i) for i in idxs}


def _stats(vals):
    v = sorted(vals)
    return {"n": len(v), "mean": sum(v) / len(v), "min": v[0], "p50": M.percentile(v, 50), "p90": M.percentile(v, 90),
            "p95": M.percentile(v, 95), "p99": M.percentile(v, 99), "p999": M.percentile(v, 99.9), "max": v[-1],
            "hist": {str(k): v.count(k) for k in sorted(set(v))} if len(set(v)) <= 48 else None}


def _build(ctx, config):
    binp, info = toolchain.build_soc_sim(ctx.soc_root, config)
    ctx.note_build(info)
    return binp


def _firmware(ctx):
    fw = toolchain.build_firmware(ctx.soc_root)
    ctx.extra["firmware"] = {k: fw[k] for k in ("sha256", "built", "toolchain", "key") if k in fw}
    return fw["bin"]


def _metrics(lat, cycles, nops, nbytes, stall=None, conflicts=None):
    m = {k: None for k in M.METRIC_KEYS}
    m.update({"clock_cycles": cycles, "completed_ops": nops, "bytes_transferred": nbytes,
              "memory_bandwidth_bytes_per_cycle": nbytes / cycles if cycles else None,
              "transaction_throughput_per_cycle": nops / cycles if cycles else None, "stall_cycles": stall, "memory_conflicts": conflicts})
    m.update(M.lat_to_metrics(lat))
    return m


# ------------------------------------------------------------------------------------------------ workloads
def host_mmio_latency(sim, pt):
    p = pt["params"]
    n = p["nops"]
    lat = []
    detail = {}
    started = None
    if p["load"] == "dma":
        buf = _alloc(sim, 8192)
        started = sim.cyc()
        sim.submit(OP["DMA_FILL"], [buf, 8192, 0xA5A5A5A5], tag=7)       # firmware now runs a DMA and polls its status over MMIO
    c0 = sim.counters([TC_M_HOST_STALL, TC_M_HOST_TXN, TC_CYCLES])
    t_begin = sim.cyc()
    for i in range(n):
        t0 = sim.cyc()
        if p["op"] == "read":
            sim.r(MGMT + M_CHIP_ID)
        else:
            sim.w(MGMT + 0x05C, i)                                        # SCRATCH register
        lat.append(sim.cyc() - t0)
    t_end = sim.cyc()
    c1 = sim.counters([TC_M_HOST_STALL, TC_M_HOST_TXN, TC_CYCLES])
    if p["load"] == "dma":
        cpl, _ = sim.complete()
        detail["background_dma_status"] = ST.get(cpl[0] >> 8 & 0xFF)
        detail["background_dma_cycles"] = cpl[2]
    host_stall = (c1[TC_M_HOST_STALL] - c0[TC_M_HOST_STALL]) & 0xFFFFFFFF
    detail.update({"op": p["op"], "load": p["load"], "rtl_host_port_stall_cycles_in_window": host_stall,
                   "definition": "device cycles from MMIO request presented to response observed (one outstanding request)"})
    return lat, t_end - t_begin, n, 4 * n, host_stall, detail


def _alloc(sim, size):
    sim.submit(OP["ALLOC"], [size], tag=3)
    cpl, _ = sim.complete()
    if (cpl[0] >> 8) & 0xFF != 0:
        raise SimError(f"ALLOC failed: {ST.get((cpl[0] >> 8) & 0xFF)}")
    return cpl[1]


def host_mailbox_roundtrip(sim, pt):
    n = pt["params"]["nops"]
    rtt, sub, turn, ret = [], [], [], []
    ci0 = sim.counters([TC_CORE_INSTRET, TC_CORE_SLEEP, TC_CYCLES])
    t_all0 = sim.cyc()
    for i in range(n):
        t0 = sim.cyc()
        sim.submit(OP["PING"], tag=10 + i)
        t1 = sim.cyc()
        cpl, marks = sim.complete()
        t3 = sim.cyc()
        if ST.get((cpl[0] >> 8) & 0xFF) != "OK":
            raise SimError("PING failed")
        rtt.append(t3 - t0)
        sub.append(t1 - t0)
        turn.append(marks["irq_seen"] - t1)
        ret.append(t3 - marks["irq_seen"])
    t_all1 = sim.cyc()
    ci1 = sim.counters([TC_CORE_INSTRET, TC_CORE_SLEEP, TC_CYCLES])
    instret = (ci1[TC_CORE_INSTRET] - ci0[TC_CORE_INSTRET]) / n
    detail = {
        "definition": "first HCMD write -> final HCPL_POP write (the runtime's PING path: 8 cmd words + doorbell, status poll, IRQ wait, 4 reads, pop)",
        "phase_cycles_median": {"submit_mmio": statistics.median(sub), "firmware_turnaround_doorbell_to_irq_seen": statistics.median(turn),
                                "completion_retrieval_mmio": statistics.median(ret)},
        "core_instructions_per_command_rtl_telemetry": instret,
        "core_sleep_fraction_over_run": (ci1[TC_CORE_SLEEP] - ci0[TC_CORE_SLEEP]) / max(1, ci1[TC_CYCLES] - ci0[TC_CYCLES]),
        "mmio_ops_per_command": {"writes": 9, "reads_min": 6},
        "p90_published_median_cycles": 384,
    }
    return rtt, t_all1 - t_all0, n, 15 * 4 * n, None, detail


def host_dma_roundtrip(sim, pt):
    p = pt["params"]
    n, ln = p["nops"], p["length"]
    buf = _alloc(sim, max(256, ln))
    rtt, dmac = [], []
    c0 = sim.counters([TC_CORE_INSTRET])
    t_all0 = sim.cyc()
    for i in range(n):
        t0 = sim.cyc()
        sim.submit(OP["DMA_FILL"], [buf, ln, i + 1], tag=20 + i)
        cpl, _ = sim.complete()
        if ST.get((cpl[0] >> 8) & 0xFF) != "OK":
            raise SimError(f"DMA_FILL failed: {ST.get((cpl[0] >> 8) & 0xFF)}")
        rtt.append(sim.cyc() - t0)
        dmac.append(cpl[2])
    t_all1 = sim.cyc()
    c1 = sim.counters([TC_CORE_INSTRET])
    detail = {"length_bytes": ln, "dma_cycles_register_per_command": dmac[-1],
              "firmware_and_mmio_overhead_cycles_median": statistics.median([r - d for r, d in zip(rtt, dmac)]),
              "core_instructions_per_command_rtl_telemetry": (c1[TC_CORE_INSTRET] - c0[TC_CORE_INSTRET]) / n,
              "definition": "HCMD write -> HCPL pop for an ALLOC'd, permission-checked DMA_FILL; dma_cycles comes from the RTL DMA_CYCLES register via the completion"}
    return rtt, t_all1 - t_all0, n, ln * n, None, detail


FUNCS = {"host_mmio_latency": host_mmio_latency, "host_mailbox_roundtrip": host_mailbox_roundtrip, "host_dma_roundtrip": host_dma_roundtrip}


def feature_probe(ctx):
    """Read the feature registers of a build that REQUESTS every feature, and send the unsupported opcodes to the firmware."""
    binp = _build(ctx, 2)
    fw = _firmware(ctx)
    sim = SocSim(binp, 1)
    try:
        sim.boot(fw)
        cfg_id = sim.r(MGMT + M_CONFIG_ID)
        impl, req, unav = (sim.r(MGMT + o) for o in (M_FEAT_IMPL, M_FEAT_REQ, M_FEAT_UNAVAIL))
        feats = {name: {"requested": bool(req >> b & 1), "implemented": bool(impl >> b & 1), "reported_unavailable": bool(unav >> b & 1)}
                 for b, name in FEATURES.items()}
        probes = {}
        for opn, feat in (("PKT_CLASSIFY", "PACKETFORGE"), ("VBLK_IO", "VIRTUALFOUNDRY"), ("MATMUL_INT8", "COMPUTEWORKS")):
            sim.submit(OP[opn], tag=40)
            cpl, _ = sim.complete()
            probes[opn] = {"feature": feat, "completion_status": ST.get((cpl[0] >> 8) & 0xFF, hex((cpl[0] >> 8) & 0xFF))}
        return {"rtl_banner": sim.banner, "config_id": cfg_id, "feat_impl": hex(impl), "feat_req": hex(req), "feat_unavail": hex(unav), "features": feats, "opcode_probes": probes,
                "build": "sf_albion_cloud_top CONFIG=2 (ALBION_HPC requests every feature, so FEAT_UNAVAIL lists what is missing)"}
    finally:
        sim.close()


def run_points(pts, cfg, ctx):
    from ..runner import make_record
    seeds = cfg["seeds"][:2] if len(cfg["seeds"]) > 2 else cfg["seeds"]
    out = []
    try:
        binp = _build(ctx, 0)
        fw = _firmware(ctx)
    except toolchain.ToolError as e:
        for pt in pts:
            out.append(make_record(pt, "UNAVAILABLE", {k: None for k in M.METRIC_KEYS}, {"error": str(e), "reason": "toolchain missing"}, [], cfg))
        return out
    try:
        ctx.extra["feature_probe"] = feature_probe(ctx)
    except Exception as e:      # the probe is evidence, not a precondition for the performance points
        ctx.extra["feature_probe"] = {"error": f"{type(e).__name__}: {e}"}
    for pt in pts:
        per_seed, details = [], []
        err = None
        for s in seeds:
            sim = SocSim(binp, s)
            try:
                sim.boot(fw, pt["hw"]["host_latency_cycles"])
                lat, cycles, nops, nbytes, stall, det = FUNCS[pt["workload"]](sim, pt)
                m = _metrics(_stats(lat), cycles, nops, nbytes, stall)
                per_seed.append({"seed": s, "status": "OK", "metrics": m})
                details.append((det, lat))
            except Exception as e:
                err = f"{type(e).__name__}: {e}"
                break
            finally:
                sim.close()
        if err or not per_seed:
            out.append(make_record(pt, "ERROR", {k: None for k in M.METRIC_KEYS}, {"error": err}, [], cfg))
            continue
        det, lat = details[0]
        det["latency_hist"] = _stats(lat)["hist"]
        det["per_operation_latency_cycles"] = lat[:64]
        sig = {(s["metrics"]["clock_cycles"], s["metrics"]["latency_p50_cycles"]) for s in per_seed}
        status, notes = "OK", []
        if len(sig) > 1:
            status = "FAIL_INSTRUMENTATION"
            notes.append(f"NONDETERMINISM across power-up seeds: {sorted(sig)}")
        out.append(make_record(pt, status, R.aggregate(per_seed), det, per_seed, cfg, notes, deterministic=True))
    return out
