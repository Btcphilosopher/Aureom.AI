"""Workload registry and suites.

A *workload* is a named, documented measurement.  A *point* is one concrete run of it (hardware configuration + parameters).
The registry is the single source of truth for what the "Test workload" provenance field contains.

Hardware that does not exist in the available RTL is declared here as UNAVAILABLE with the evidence used to establish that
(probe results are attached at run time by the SoC backend; they are never assumed).
"""
import copy
import fnmatch

FABRIC, SOC, COMPUTE, NONE = "fabric", "soc", "compute", "none"


class Workload:
    def __init__(self, id, group, backend, title, description, headline, knobs=(), deterministic=True, kind="stream"):
        self.id, self.group, self.backend, self.title, self.description = id, group, backend, title, description
        self.headline, self.knobs, self.deterministic, self.kind = headline, list(knobs), deterministic, kind

    def describe(self):
        return {"id": self.id, "group": self.group, "backend": self.backend, "title": self.title, "description": self.description,
                "headline_metric": self.headline, "knobs": self.knobs, "deterministic": self.deterministic}


REGISTRY = {}


def reg(*a, **k):
    w = Workload(*a, **k)
    REGISTRY[w.id] = w
    return w


# ------------------------------------------------------------------------------------------------ Albion fabric complex
reg("sram_seq_read", "memory", FABRIC, "SRAM sequential reads",
    "One master (CORE port) streams sequential 32-bit reads from one SRAM bank (SECDED decode in the path); every word is checked against a shadow memory.",
    "memory_bandwidth_bytes_per_cycle", ["sram_banks", "bank_bytes"])
reg("sram_seq_write", "memory", FABRIC, "SRAM sequential writes",
    "One master streams sequential full-word writes to one bank (SECDED encode); the written region is read back and verified.",
    "memory_bandwidth_bytes_per_cycle", ["sram_banks", "bank_bytes"])
reg("sram_seq_write_partial", "memory", FABRIC, "SRAM sequential partial (byte) writes",
    "Byte-strobe writes force the bank's read-modify-write path (ECC decode, merge, re-encode): the architecture's slow write case.",
    "transaction_throughput_per_cycle", ["sram_banks"])
reg("sram_random", "memory", FABRIC, "Random memory accesses",
    "K masters issue uniformly random word accesses (30 % writes) over all banks they may legally reach. Throughput is set by random bank collisions.",
    "transaction_throughput_per_cycle", ["sram_banks", "concurrent_masters"], deterministic=False)
reg("sram_bank_conflict", "memory", FABRIC, "SRAM bank conflicts",
    "K masters read sequentially, either all in the SAME bank (single-port bank: conflicts) or each in its OWN bank (conflict-free reference).",
    "transaction_throughput_per_cycle", ["sram_banks", "concurrent_masters"])
reg("bus_arbitration", "fabric", FABRIC, "Bus arbitration (fairness, starvation, tail wait)",
    "K saturating masters share one bank under the per-slave round-robin arbiter: per-master share, Jain fairness, worst grant wait. "
    "'unequal' adds low-rate masters beside a saturating one to prove they are not starved.",
    "latency_p99_cycles", ["concurrent_masters"])
reg("concurrent_mem", "memory", FABRIC, "Concurrent memory access",
    "K masters issue random mixed traffic to all legal banks simultaneously: aggregate throughput versus the K-port ideal.",
    "transaction_throughput_per_cycle", ["sram_banks", "concurrent_masters"], deterministic=False)
reg("concurrent_dma_interference", "memory", FABRIC, "DMA with a concurrent CORE reader",
    "A DMA copy (bank1 -> bank2) runs while the CORE streams reads from the DMA's source bank (same) or from a bank the DMA does not touch (distinct).",
    "memory_bandwidth_bytes_per_cycle", ["sram_banks"], kind="mixed")
reg("dma_bandwidth", "dma", FABRIC, "DMA bandwidth",
    "One DMA descriptor of a given length: fill, SRAM->SRAM (cross-bank / same-bank), host->SRAM, SRAM->host. Result verified word-by-word; "
    "reported against the DMA_CYCLES register of the RTL.",
    "memory_bandwidth_bytes_per_cycle", ["dma_burst_bytes", "dma_depth", "host_latency_cycles", "sram_banks"], kind="dma")
reg("dma_latency", "dma", FABRIC, "DMA latency",
    "Small descriptors: cycles from the CTRL start write to completion, and to the first write beat. Exposes the fixed per-descriptor cost.",
    "clock_cycles", ["dma_burst_bytes", "host_latency_cycles"], kind="dma")
reg("host_port_latency", "host", FABRIC, "HOST-port transaction latency under load",
    "The HOST master (the path a PCIe BAR drives) reads SRAM while B background masters hammer the same bank: mean and tail latency of host transactions.",
    "latency_p99_cycles", ["concurrent_masters"])

# ------------------------------------------------------------------------------------------------ Albion SoC (unmodified top + firmware)
reg("host_mmio_latency", "host", SOC, "Host MMIO round trip (unmodified sf_albion_cloud_top)",
    "Host MMIO read / write latency through the real fabric, MMIO block and MGMT registers, idle and while a firmware DMA is running.",
    "latency_avg_cycles", [], kind="soc")
reg("host_mailbox_roundtrip", "host", SOC, "Host -> firmware -> host mailbox round trip",
    "PING command: host MMIO writes + doorbell, ControlCore firmware, completion, IRQ, host reads. Median and tail over repeated commands.",
    "latency_p50_cycles", [], kind="soc")
reg("host_dma_roundtrip", "host", SOC, "Host DMA command round trip",
    "DMA_FILL commands through the firmware path: end-to-end cycles versus the bare-DMA descriptor cost (firmware overhead).",
    "clock_cycles", [], kind="soc")

# ------------------------------------------------------------------------------------------------ ComputeWorks tile
reg("vector_int32", "compute", COMPUTE, "Integer vector arithmetic (INT32 VADD / VMUL)",
    "ComputeWorks vector engine on INT32 operands, results checked bit-exactly against an independent integer model.",
    "transaction_throughput_per_cycle", ["vector_lanes", "vector_length", "compute_ports", "compute_mem_width_bits"], kind="compute")
reg("gemm_int8", "compute", COMPUTE, "Matrix multiplication (INT8 GEMM, INT32 accumulate)",
    "ComputeWorks systolic-array GEMM, results checked bit-exactly against a plain-integer reference.",
    "compute_utilization", ["tensor_shape", "tensor_array", "compute_ports", "compute_mem_width_bits"], kind="compute")
reg("compute_mem_contention", "compute", COMPUTE, "Compute tile under concurrent memory traffic",
    "GEMM while a DMA stand-in master hammers the same SRAM banks at a given duty cycle.",
    "clock_cycles", ["tensor_shape"], kind="compute")

# ------------------------------------------------------------------------------------------------ declared-unavailable hardware
UNAVAILABLE = {
    "packet_throughput": dict(group="unavailable", title="Packet throughput", needs="PacketForge (Project 86)",
                              evidence="MGMT.FEAT_UNAVAIL bit FEAT_PACKETFORGE and firmware UNSUPPORTED for opcode 0x50 (probed live by the soc backend's feature_probe); no RTL in the repository"),
    "virtual_block_io": dict(group="unavailable", title="Virtual block I/O latency", needs="VirtualFoundry (Project 87)",
                             evidence="MGMT.FEAT_UNAVAIL bit FEAT_VIRTUALFOUNDRY and firmware UNSUPPORTED for opcode 0x51 (probed); no RTL in the repository"),
    "albion_integrated_matmul": dict(group="unavailable", title="Matrix multiply through the Albion SoC (firmware opcode MATMUL_INT8)",
                                     needs="ComputeWorks integrated into sf_albion_cloud_top",
                                     evidence="MGMT.FEAT_UNAVAIL bit FEAT_COMPUTEWORKS and firmware UNSUPPORTED for opcode 0x52 (probed). ComputeWorks RTL exists "
                                              "and IS benchmarked standalone (gemm_int8) but is not wired into the Albion top"),
    "pcie_link_latency": dict(group="unavailable", title="PCIe link / host-interface physical latency", needs="a PCIe endpoint (licensed IP)",
                              evidence="host_if is a transaction-level port; no PCIe PHY/TLP model exists (see docs/albion/known_limitations.md)"),
    "silicon_or_fpga_power": dict(group="unavailable", title="Measured power / energy", needs="silicon or an instrumented FPGA board",
                                  evidence="none exists; energy is reported only as labelled estimates (see energy.py)"),
    "absolute_gbps_at_signed_off_clock": dict(group="unavailable", title="Bandwidth in GB/s at a signed-off clock", needs="timing closure",
                                              evidence="no design has closed timing; MB/s values are derived from an assumed clock and labelled as such"),
}


# ------------------------------------------------------------------------------------------------ point construction
def P(workload, label, sweep, hw, **params):
    return {"workload": workload, "label": label, "sweep": sweep, "hw": hw, "params": params}


def _hw(base, **over):
    h = copy.deepcopy(base)
    h.update(over)
    return h


def selected(cfg):
    inc = cfg["workloads"]["include"]
    exc = cfg["workloads"]["exclude"]
    ids = [w for w in REGISTRY if any(fnmatch.fnmatch(w, pat) for pat in inc) and not any(fnmatch.fnmatch(w, pat) for pat in exc)]
    return ids


def suite_points(cfg):
    """Expand the configured suite into concrete points."""
    base = cfg["hardware"]
    suite = cfg["suite"]
    pts = []
    sel = set(selected(cfg))

    def add(*a, **k):
        if a[0] in sel:
            pts.append(P(*a, **k))

    quick = suite in ("smoke", "ab")
    # ---- memory
    add("sram_seq_read", "base", None, _hw(base), nwords=4096 if not quick else 512)
    add("sram_seq_write", "base", None, _hw(base), nwords=4096 if not quick else 512)
    add("sram_seq_write_partial", "base", None, _hw(base), nwords=2048 if not quick else 256)
    add("sram_random", "masters=1", None, _hw(base), masters=1, nops=4096 if not quick else 512)
    add("sram_bank_conflict", "same-bank/K=2", None, _hw(base), masters=2, placement="same", nwords=1024 if not quick else 256)
    add("sram_bank_conflict", "distinct-banks/K=2", None, _hw(base), masters=2, placement="distinct", nwords=1024 if not quick else 256)
    add("bus_arbitration", "saturating/K=%d" % base["concurrent_masters"], None, _hw(base), masters=base["concurrent_masters"], demand="saturating",
        nops=1024 if not quick else 256)
    add("concurrent_mem", "K=%d" % base["concurrent_masters"], None, _hw(base), masters=base["concurrent_masters"], nops=2048 if not quick else 256)
    add("concurrent_dma_interference", "same-bank", None, _hw(base), placement="same", length=8192 if not quick else 1024)
    add("concurrent_dma_interference", "distinct-bank", None, _hw(base), placement="distinct", length=8192 if not quick else 1024)
    add("host_port_latency", "background=%d" % 0, None, _hw(base), background=0, nops=512 if not quick else 128)
    add("host_port_latency", "background=%d" % 3, None, _hw(base), background=3, nops=512 if not quick else 128)
    # ---- dma
    modes = ["fill", "copy_xbank", "copy_samebank", "host_to_sram", "sram_to_host"]
    for md in modes:
        add("dma_bandwidth", f"{md}/len={4096 if not quick else 1024}", None, _hw(base, host_latency_cycles=1), mode=md, length=4096 if not quick else 1024)
    for md in ("fill", "copy_xbank", "host_to_sram"):
        add("dma_latency", f"{md}/len=4", None, _hw(base), mode=md, length=4)
        add("dma_latency", f"{md}/len=64", None, _hw(base), mode=md, length=64)
    # ---- compute + soc
    add("vector_int32", "add/vl=%d" % (256 if not quick else 64), None, _hw(base), op="add", vl=256 if not quick else 64)
    add("gemm_int8", "%dx%dx%d" % tuple(base["tensor_shape"] if not quick else (8, 8, 16)), None, _hw(base),
        shape=list(base["tensor_shape"] if not quick else (8, 8, 16)))
    add("host_mmio_latency", "read-idle", None, _hw(base), op="read", load="idle", nops=64 if not quick else 16)
    add("host_mmio_latency", "write-idle", None, _hw(base), op="write", load="idle", nops=64 if not quick else 16)
    add("host_mailbox_roundtrip", "ping", None, _hw(base), nops=16 if not quick else 4)
    add("host_dma_roundtrip", "fill-64B", None, _hw(base), length=64, nops=8 if not quick else 2)
    if suite == "ab":
        # extra points that expose the host-memory path, partial writes and arbitration tails for RTL A/B comparisons
        for hl in (4, 16):
            add("dma_bandwidth", f"host_to_sram/L={hl}", None, _hw(base, host_latency_cycles=hl), mode="host_to_sram", length=1024)
        add("dma_bandwidth", "sram_to_host/L=4", None, _hw(base, host_latency_cycles=4), mode="sram_to_host", length=1024)
        add("bus_arbitration", "unequal/K=4", None, _hw(base), masters=4, demand="unequal", nops=256)
        add("sram_bank_conflict", "same-bank/K=4", None, _hw(base), masters=4, placement="same", nwords=256)
        add("sram_bank_conflict", "distinct-banks/K=4", None, _hw(base), masters=4, placement="distinct", nwords=256)
        add("host_port_latency", "background=1", None, _hw(base), background=1, nops=128)
    if quick:
        return pts

    # ================================================================ standard: one-factor sweeps around the base
    for n in (64, 256, 1024, 16384):
        add("sram_seq_read", f"nwords={n}", "size", _hw(base), nwords=n)
    for nb in (2, 8):
        add("sram_seq_read", f"banks={nb}", "banks", _hw(base, sram_banks=nb), nwords=4096)
    for n in (256, 16384):
        add("sram_seq_write", f"nwords={n}", "size", _hw(base), nwords=n)
    add("sram_seq_write", "banks=8", "banks", _hw(base, sram_banks=8), nwords=4096)
    for k in (2, 3, 4):
        add("sram_random", f"masters={k}", "masters", _hw(base), masters=k, nops=4096)
    for nb in (2, 3, 8):
        add("sram_random", f"banks={nb}/masters=4", "banks", _hw(base, sram_banks=nb), masters=4, nops=4096)
    for k in (3, 4):
        add("sram_bank_conflict", f"same-bank/K={k}", "masters", _hw(base), masters=k, placement="same", nwords=1024)
        add("sram_bank_conflict", f"distinct-banks/K={k}", "masters", _hw(base), masters=k, placement="distinct", nwords=1024)
    for k in (2, 3):
        add("bus_arbitration", f"saturating/K={k}", "masters", _hw(base), masters=k, demand="saturating", nops=1024)
    for k in (2, 4):
        add("bus_arbitration", f"unequal/K={k}", "masters", _hw(base), masters=k, demand="unequal", nops=1024)
    for k in (1, 2, 3):
        add("concurrent_mem", f"K={k}", "masters", _hw(base), masters=k, nops=2048)
    for nb in (2, 3, 8):
        add("concurrent_mem", f"banks={nb}/K=4", "banks", _hw(base, sram_banks=nb), masters=4, nops=2048)
    for b in (1, 2):
        add("host_port_latency", f"background={b}", "masters", _hw(base), background=b, nops=512)
    for ln in (64, 256, 1024, 16384):
        add("dma_bandwidth", f"fill/len={ln}", "size", _hw(base), mode="fill", length=ln)
    for ln in (64, 256, 1024, 8192):
        add("dma_bandwidth", f"copy_xbank/len={ln}", "size", _hw(base), mode="copy_xbank", length=ln)
    for ln in (64, 256, 1024):
        add("dma_bandwidth", f"host_to_sram/len={ln}", "size", _hw(base), mode="host_to_sram", length=ln)
    for ln in (64, 256, 1024, 2048):
        add("dma_bandwidth", f"copy_samebank/len={ln}", "size", _hw(base), mode="copy_samebank", length=ln)
    for hl in (4, 16, 64):
        add("dma_bandwidth", f"host_to_sram/L={hl}", "host_latency", _hw(base, host_latency_cycles=hl), mode="host_to_sram", length=4096)
        add("dma_bandwidth", f"sram_to_host/L={hl}", "host_latency", _hw(base, host_latency_cycles=hl), mode="sram_to_host", length=4096)
    for dd in (1, 2, 3, 6, 8):
        add("dma_bandwidth", f"copy_xbank/depth={dd}", "dma_depth", _hw(base, dma_depth=dd), mode="copy_xbank", length=4096)
        add("dma_bandwidth", f"host_to_sram/L=4/depth={dd}", "dma_depth", _hw(base, dma_depth=dd, host_latency_cycles=4), mode="host_to_sram", length=4096)
    add("dma_bandwidth", "copy_xbank/depth=4/L=1/banks=8", "banks", _hw(base, sram_banks=8), mode="copy_xbank", length=4096)
    add("dma_bandwidth", "copy_xbank/banks=3", "banks", _hw(base, sram_banks=3), mode="copy_xbank", length=4096)
    for md in ("fill", "copy_xbank"):
        add("dma_latency", f"{md}/len=16", "size", _hw(base), mode=md, length=16)
    for hl in (4, 16):
        add("dma_latency", f"host_to_sram/len=64/L={hl}", "host_latency", _hw(base, host_latency_cycles=hl), mode="host_to_sram", length=64)
    # ---- compute sweeps (restricted to ComputeWorks' verified configuration matrix)
    for vl in (16, 64, 1024):
        add("vector_int32", f"add/vl={vl}", "size", _hw(base), op="add", vl=vl)
    add("vector_int32", "mul/vl=256", None, _hw(base), op="mul", vl=256)
    for ln in (1, 2, 8, 16):
        add("vector_int32", f"add/vl=1024/lanes={ln}", "lanes", _hw(base, vector_lanes=ln), op="add", vl=1024)
    add("vector_int32", "add/vl=1024/lanes=4", "lanes", _hw(base), op="add", vl=1024)
    for cp, dw in ((1, 128), (2, 64), (2, 128)):
        add("vector_int32", f"add/vl=1024/cp={cp}/dw={dw}", "mem_width", _hw(base, compute_ports=cp, compute_mem_width_bits=dw), op="add", vl=1024)
    add("vector_int32", "add/vl=1024/cp=1/dw=64", "mem_width", _hw(base), op="add", vl=1024)
    for shp in ((4, 4, 4), (4, 4, 16), (4, 4, 64), (4, 4, 256), (8, 8, 64), (16, 16, 256), (32, 32, 64)):
        add("gemm_int8", "%dx%dx%d" % shp, "tensor_shape", _hw(base), shape=list(shp))
    for arr in ([2, 2], [4, 2], [8, 8]):
        add("gemm_int8", "16x16x64/array=%dx%d" % tuple(arr), "tensor_array", _hw(base, tensor_array=arr), shape=[16, 16, 64])
    for cp, dw in ((1, 128), (2, 64), (2, 128)):
        add("gemm_int8", f"16x16x64/cp={cp}/dw={dw}", "mem_width", _hw(base, compute_ports=cp, compute_mem_width_bits=dw), shape=[16, 16, 64])
    for bg in (50, 95):
        add("compute_mem_contention", f"16x16x64/bg={bg}%", "contention", _hw(base), shape=[16, 16, 64], bg=bg)
    add("compute_mem_contention", "16x16x64/bg=0%", "contention", _hw(base), shape=[16, 16, 64], bg=0)
    # points that coincide with configurations published in P90's performance report (used to anchor the memory model constants)
    add("dma_bandwidth", "fill/len=8192", "anchor", _hw(base), mode="fill", length=8192)
    add("dma_bandwidth", "copy_samebank/len=8192", "anchor", _hw(base), mode="copy_samebank", length=8192)
    add("host_mmio_latency", "read-under-dma", None, _hw(base), op="read", load="dma", nops=64)
    add("host_dma_roundtrip", "fill-1KiB", None, _hw(base), length=1024, nops=8)
    pts += validation_points(cfg, sel)
    return pts


def validation_points(cfg, sel):
    """Held-out points used ONLY to test the performance models: sizes, shapes and latencies that were not used to calibrate any constant.
    They are executed like every other point; the models never see them before predicting."""
    base = cfg["hardware"]
    out = []

    def add(*a, **k):
        if a[0] in sel:
            out.append(P(*a, **k))
    V = "blind-validation"
    for md, ln in (("fill", 12), ("fill", 100), ("fill", 3000), ("copy_xbank", 36), ("copy_xbank", 700), ("copy_xbank", 5000), ("copy_samebank", 900)):
        add("dma_bandwidth", f"{md}/len={ln}", V, _hw(base), mode=md, length=ln)
    for hl in (2, 7, 33):
        add("dma_bandwidth", f"host_to_sram/L={hl}/len=1200", V, _hw(base, host_latency_cycles=hl), mode="host_to_sram", length=1200)
    add("dma_bandwidth", "sram_to_host/L=3/len=800", V, _hw(base, host_latency_cycles=3), mode="sram_to_host", length=800)
    add("dma_bandwidth", "copy_xbank/depth=2/len=5000", V, _hw(base, dma_depth=2), mode="copy_xbank", length=5000)
    add("dma_bandwidth", "host_to_sram/L=7/depth=1/len=900", V, _hw(base, dma_depth=1, host_latency_cycles=7), mode="host_to_sram", length=900)
    add("dma_bandwidth", "host_to_sram/L=3/depth=2/len=2000", V, _hw(base, dma_depth=2, host_latency_cycles=3), mode="host_to_sram", length=2000)
    for n in (100, 3000):
        add("sram_seq_read", f"nwords={n}", V, _hw(base), nwords=n)
    add("sram_seq_write_partial", "nwords=777", V, _hw(base), nwords=777)
    add("sram_bank_conflict", "same-bank/K=3/n=500", V, _hw(base), masters=3, placement="same", nwords=500)
    add("bus_arbitration", "unequal/K=3", V, _hw(base), masters=3, demand="unequal", nops=800)
    add("sram_random", "banks=5/masters=3", V, _hw(base, sram_banks=5), masters=3, nops=3000)
    add("sram_random", "banks=4/masters=2/n=2500", V, _hw(base), masters=2, nops=2500)
    for vl in (100, 300, 700, 1500):
        add("vector_int32", f"add/vl={vl}", V, _hw(base), op="add", vl=vl)
    add("vector_int32", "mul/vl=700/lanes=2", V, _hw(base, vector_lanes=2), op="mul", vl=700)
    add("vector_int32", "add/vl=700/lanes=8", V, _hw(base, vector_lanes=8), op="add", vl=700)
    add("vector_int32", "add/vl=300/dw=128", V, _hw(base, compute_mem_width_bits=128), op="add", vl=300)
    for shp in ((5, 7, 9), (10, 6, 30), (12, 20, 100), (7, 9, 33), (20, 12, 50), (6, 5, 3), (3, 3, 2)):
        add("gemm_int8", "%dx%dx%d" % shp, V, _hw(base), shape=list(shp))
    add("gemm_int8", "9x9x40/array=2x2", V, _hw(base, tensor_array=[2, 2]), shape=[9, 9, 40])
    add("gemm_int8", "10x10x24/array=8x8", V, _hw(base, tensor_array=[8, 8]), shape=[10, 10, 24])
    add("gemm_int8", "6x5x17/array=4x2", V, _hw(base, tensor_array=[4, 2]), shape=[6, 5, 17])
    add("gemm_int8", "12x12x48/dw=128", V, _hw(base, compute_mem_width_bits=128), shape=[12, 12, 48])
    add("host_dma_roundtrip", "fill-256B", V, _hw(base), length=256, nops=8)
    add("host_dma_roundtrip", "fill-4KiB", V, _hw(base), length=4096, nops=8)
    return out


def describe_workloads(ids=None):
    out = [REGISTRY[i].describe() for i in (ids or REGISTRY)]
    out += [{"id": k, "group": "unavailable", "title": v["title"], "needs": v["needs"], "evidence": v["evidence"]} for k, v in UNAVAILABLE.items()]
    return out
