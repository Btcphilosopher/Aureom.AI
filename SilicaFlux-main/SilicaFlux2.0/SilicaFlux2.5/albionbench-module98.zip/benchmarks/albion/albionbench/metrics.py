"""Metric definitions and normalisation.

The required metric set (all reported for every measured point; ``None`` means *not applicable*, never "zero"):

  clock_cycles                       cycles of the measured window (inclusive of the final response)
  completed_ops                      transactions (fabric streams), DMA words, or MAC/element results (compute)
  bytes_transferred                  payload bytes delivered (DMA: destination bytes; streams: bytes read or written)
  latency_avg_cycles                 mean request latency, first-valid -> response (compute: per-command execution cycles)
  latency_p50/p95/p99/p999/max       tail latency, same definition
  memory_bandwidth_bytes_per_cycle   bytes_transferred / clock_cycles
  transaction_throughput_per_cycle   completed_ops / clock_cycles
  pipeline_utilization               fabric: accepted requests / (banks touched * cycles); compute: engine-busy share of the window
  stall_cycles                       cycles a requester held valid without ready (compute: engine memory-stall cycles)
  memory_conflicts                   cycles in which >= 2 requesters targeted one SRAM bank (compute: IronMemory bank-conflict cycles)
  compute_utilization                MACs (or vector elements) / peak over the window; None for non-compute workloads
"""
import math

METRIC_KEYS = [
    "clock_cycles", "completed_ops", "bytes_transferred", "latency_avg_cycles", "latency_p50_cycles", "latency_p95_cycles",
    "latency_p99_cycles", "latency_p999_cycles", "latency_max_cycles", "memory_bandwidth_bytes_per_cycle",
    "transaction_throughput_per_cycle", "pipeline_utilization", "stall_cycles", "memory_conflicts", "compute_utilization",
]

HIGHER_IS_BETTER = {"memory_bandwidth_bytes_per_cycle", "transaction_throughput_per_cycle", "pipeline_utilization", "compute_utilization",
                    "completed_ops_per_cycle"}
LOWER_IS_BETTER = {"clock_cycles", "latency_avg_cycles", "latency_p50_cycles", "latency_p95_cycles", "latency_p99_cycles",
                   "latency_p999_cycles", "latency_max_cycles", "stall_cycles", "memory_conflicts"}


def jain_index(xs):
    xs = [float(x) for x in xs]
    if not xs or sum(x * x for x in xs) == 0:
        return None
    return (sum(xs) ** 2) / (len(xs) * sum(x * x for x in xs))


def percentile(sorted_vals, p):
    if not sorted_vals:
        return None
    i = max(0, math.ceil(p / 100.0 * len(sorted_vals)) - 1)
    return sorted_vals[min(i, len(sorted_vals) - 1)]


def merge_latency(stats):
    """Merge per-port latency summaries.  Exact (from histograms) when every port provides one; otherwise a conservative bound
    (count-weighted mean, worst-port tail) and ``tail_exact = False``."""
    stats = [s for s in stats if s and s.get("n", 0) > 0]
    if not stats:
        return {"n": 0}
    n = sum(s["n"] for s in stats)
    mean = sum(s["mean"] * s["n"] for s in stats) / n
    out = {"n": n, "mean": mean, "min": min(s["min"] for s in stats), "max": max(s["max"] for s in stats)}
    if all("hist" in s for s in stats):
        h = {}
        for s in stats:
            for k, v in s["hist"].items():
                h[int(k)] = h.get(int(k), 0) + v
        flat = sorted(h)
        cum, tot = 0, sum(h.values())

        def pct(p):
            target = math.ceil(p / 100.0 * tot)
            c = 0
            for k in flat:
                c += h[k]
                if c >= target:
                    return k
            return flat[-1]
        out.update({"p50": pct(50), "p90": pct(90), "p95": pct(95), "p99": pct(99), "p999": pct(99.9), "tail_exact": True, "hist": h})
    else:
        for k in ("p50", "p90", "p95", "p99", "p999"):
            out[k] = max(s[k] for s in stats)
        out["tail_exact"] = False
    return out


def lat_to_metrics(lat):
    return {
        "latency_avg_cycles": lat.get("mean"), "latency_p50_cycles": lat.get("p50"), "latency_p95_cycles": lat.get("p95"),
        "latency_p99_cycles": lat.get("p99"), "latency_p999_cycles": lat.get("p999"), "latency_max_cycles": lat.get("max"),
    }


def at_clock(metrics, mhz):
    """Time-domain view of the cycle metrics under an ASSUMED clock."""
    out = {"clock_mhz_assumed": mhz}
    f = float(mhz)
    bw = metrics.get("memory_bandwidth_bytes_per_cycle")
    tp = metrics.get("transaction_throughput_per_cycle")
    if bw is not None:
        out["memory_bandwidth_MB_per_s"] = bw * f          # B/cycle * Mcycle/s = MB/s
    if tp is not None:
        out["transaction_throughput_Mtxn_per_s"] = tp * f
    for k in ("latency_avg_cycles", "latency_p50_cycles", "latency_p95_cycles", "latency_p99_cycles", "latency_p999_cycles", "latency_max_cycles"):
        v = metrics.get(k)
        if v is not None:
            out[k.replace("_cycles", "_ns")] = v * 1000.0 / f
    if metrics.get("clock_cycles") is not None:
        out["window_us"] = metrics["clock_cycles"] / f
    return out


def mean_of(records, key):
    vals = [r[key] for r in records if r.get(key) is not None]
    return sum(vals) / len(vals) if vals else None


def stats_of(vals):
    vals = [v for v in vals if v is not None]
    if not vals:
        return None
    m = sum(vals) / len(vals)
    var = sum((v - m) ** 2 for v in vals) / len(vals)
    return {"n": len(vals), "mean": m, "min": min(vals), "max": max(vals), "stdev": math.sqrt(var)}
