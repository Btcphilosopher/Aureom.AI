"""Regression detection: compare a candidate results.json against a baseline results.json.

Categories (severity FAIL unless noted):
  INCORRECT_RESULT        a point's data checks failed (shadow-memory / DMA / reference mismatch, response errors)
  DEADLOCK                a point made no progress (progress watchdog) - state captured in the result
  BANDWIDTH_REGRESSION    memory bandwidth (or, for compute, command throughput) dropped by more than the threshold
  CYCLES_REGRESSION       window cycles rose by more than the threshold (covers latency-type workloads such as dma_latency)
  LATENCY_REGRESSION      mean latency rose by more than the threshold
  TAIL_LATENCY_REGRESSION p99 / max latency rose by more than the tail threshold
  STALL_REGRESSION        stall cycles rose by more than the threshold for the same amount of work
  STARVATION              a measured arbitration bound (worst wait <= K-1, low-rate masters served) no longer holds
  UTILIZATION_DROP        pipeline / compute utilisation dropped by more than the threshold
  INSTRUMENTATION         monitor-vs-RTL counter mismatch or non-determinism of a deterministic workload (the measurement can no longer be trusted)
  MISSING_POINT           (with --strict-set) a baseline point is absent from the candidate
  HARDWARE_LOST           a workload that ran in the baseline is now UNAVAILABLE / errored
  CONFLICT_INCREASE       (WARN) bank-conflict cycles rose by more than the stall threshold
Informational: IMPROVED_* for the same metrics moving the right way beyond the threshold.

Noise model: the simulation is deterministic, so with identical seeds an unchanged design reproduces every counter exactly.  Thresholds are therefore
small by default; STOCHASTIC workloads (random traffic) get a x5 allowance because any arbitration change legitimately reshuffles the random sequence.
"""
import json
import pathlib

from . import config as cfgmod
from . import workloads

FAIL, WARN, INFO = "FAIL", "WARN", "INFO"
STOCHASTIC_FACTOR = 5.0


def _pct(new, old):
    if old is None or new is None:
        return None
    if old == 0:
        return 0.0 if new == 0 else float("inf")
    return 100.0 * (new - old) / abs(old)


def _thr(th, key, stochastic):
    return th[key] * (STOCHASTIC_FACTOR if stochastic else 1.0)


def compare_point(b, c, th, stochastic=False):
    """Findings for one point present in both documents."""
    F = []
    pid = c["id"]

    def add(cat, sev, msg, metric=None, old=None, new=None):
        F.append({"id": pid, "category": cat, "severity": sev, "metric": metric, "baseline": old, "candidate": new,
                  "change_pct": _pct(new, old) if (old is not None and new is not None) else None, "message": msg})

    if c["status"] == "DEADLOCK":
        add("DEADLOCK", FAIL, f"candidate deadlocked: {(c['detail'] or {}).get('deadlock_diag') or (c['detail'] or {}).get('error')}")
        return F
    if c["status"] == "FAIL_CORRECTNESS":
        iss = (c["detail"] or {}).get("correctness_issues") or [(c["detail"] or {}).get("error")]
        add("INCORRECT_RESULT", FAIL, "incorrect result: " + "; ".join(str(i) for i in iss))
        return F
    if c["status"] in ("ERROR", "UNAVAILABLE"):
        if b["status"] == "OK":
            add("HARDWARE_LOST", FAIL, f"baseline OK, candidate {c['status']}: {(c['detail'] or {}).get('error')}")
        return F
    if c["status"] == "FAIL_INSTRUMENTATION":
        add("INSTRUMENTATION", FAIL, "; ".join((c["detail"] or {}).get("instrumentation_mismatches", []) + c["notes"]) or "instrumentation mismatch")
    if b["status"] != "OK":
        return F                                    # baseline itself was not valid for this point: nothing to compare against
    mb, mc = b["metrics"], c["metrics"]
    min_abs = th["min_abs_cycles"]

    def drop(metric, cat, key):
        old, new = mb.get(metric), mc.get(metric)
        if old is None or new is None or old == 0:
            return
        p = _pct(new, old)
        if p < -_thr(th, key, stochastic):
            add(cat, FAIL, f"{metric} dropped {p:+.2f}% ({old:.4g} → {new:.4g})", metric, old, new)
        elif p > _thr(th, key, stochastic):
            add("IMPROVED_" + cat.split("_")[0], INFO, f"{metric} improved {p:+.2f}% ({old:.4g} → {new:.4g})", metric, old, new)

    def rise(metric, cat, key, sev=FAIL, abs_floor=None):
        old, new = mb.get(metric), mc.get(metric)
        if old is None or new is None:
            return
        floor = min_abs if abs_floor is None else abs_floor
        if new - old <= floor and new - old >= -floor:
            return
        p = _pct(new, old)
        if p > _thr(th, key, stochastic) and new - old > floor:
            add(cat, sev, f"{metric} rose {p:+.2f}% ({old:.4g} → {new:.4g})", metric, old, new)
        elif p < -_thr(th, key, stochastic) and old - new > floor:
            add("IMPROVED_" + cat.replace("_REGRESSION", ""), INFO, f"{metric} improved {p:+.2f}% ({old:.4g} → {new:.4g})", metric, old, new)

    ops_same = mb.get("completed_ops") == mc.get("completed_ops")
    if mb.get("memory_bandwidth_bytes_per_cycle") is not None:
        drop("memory_bandwidth_bytes_per_cycle", "BANDWIDTH_REGRESSION", "bandwidth_drop_pct")
    if c["backend"] == "compute":
        drop("transaction_throughput_per_cycle", "BANDWIDTH_REGRESSION", "bandwidth_drop_pct")
    rise("clock_cycles", "CYCLES_REGRESSION", "latency_increase_pct")
    rise("latency_avg_cycles", "LATENCY_REGRESSION", "latency_increase_pct", abs_floor=0.05)
    rise("latency_p99_cycles", "TAIL_LATENCY_REGRESSION", "tail_latency_increase_pct", abs_floor=0.5)
    rise("latency_max_cycles", "TAIL_LATENCY_REGRESSION", "tail_latency_increase_pct", abs_floor=0.5)
    if ops_same:
        rise("stall_cycles", "STALL_REGRESSION", "stall_increase_pct", abs_floor=max(min_abs, 0))
        rise("memory_conflicts", "CONFLICT_INCREASE", "stall_increase_pct", sev=WARN)
    for u in ("pipeline_utilization", "compute_utilization"):
        old, new = mb.get(u), mc.get(u)
        if old and new is not None and _pct(new, old) < -_thr(th, "utilization_drop_pct", stochastic):
            add("UTILIZATION_DROP", FAIL, f"{u} dropped {_pct(new, old):+.2f}% ({old:.4g} → {new:.4g})", u, old, new)
    # measured arbitration bounds
    db, dc = (b["detail"] or {}).get("derived", {}), (c["detail"] or {}).get("derived", {})
    if db.get("starvation_free") and dc.get("starvation_free") is False:
        add("STARVATION", FAIL, f"worst accept wait {dc.get('max_accept_wait_cycles')} cycles exceeds the K-1 = {dc.get('starvation_bound_cycles')} round-robin bound")
    if db.get("low_rate_masters_not_starved") and dc.get("low_rate_masters_not_starved") is False:
        add("STARVATION", FAIL, "a low-rate master was not served")
    jb, jc = db.get("jain_fairness"), dc.get("jain_fairness")
    if jb and jc is not None and jc < jb - 0.01:
        add("STARVATION", FAIL, f"Jain fairness fell {jb:.4f} → {jc:.4f}", "jain_fairness", jb, jc)
    return F


def compare(base, cand, thresholds=None, strict_set=False):
    th = dict(cfgmod.DEFAULT["thresholds"])
    th.update(thresholds or {})
    bp = {r["id"]: r for r in base["points"]}
    cp = {r["id"]: r for r in cand["points"]}
    F = []
    for pid, c in cp.items():
        stochastic = not workloads.REGISTRY[c["workload"]].deterministic
        if pid in bp:
            F += compare_point(bp[pid], c, th, stochastic)
        elif c["status"] not in ("OK",):
            F += compare_point({"status": "ERROR", "metrics": {}, "detail": {}}, c, th, stochastic)
    missing = [pid for pid in bp if pid not in cp]
    if strict_set:
        for pid in missing:
            F.append({"id": pid, "category": "MISSING_POINT", "severity": FAIL, "metric": None, "baseline": None, "candidate": None, "change_pct": None,
                      "message": "point present in the baseline is missing from the candidate"})
    bu = {u["id"]: u for u in base.get("unavailable", [])}
    cu = {u["id"]: u for u in cand.get("unavailable", [])}
    for uid, u in cu.items():
        if uid in bu and bu[uid].get("probe_confirms_unavailable") and u.get("probe_confirms_unavailable") is False:
            F.append({"id": uid, "category": "HARDWARE_CHANGE", "severity": INFO, "metric": None, "baseline": None, "candidate": None, "change_pct": None,
                      "message": "a feature declared unavailable in the baseline is no longer reported unavailable: add benchmarks for it"})
    summary = {"points_compared": sum(1 for pid in cp if pid in bp), "missing_from_candidate": len(missing), "new_in_candidate": sum(1 for pid in cp if pid not in bp),
               "fail": sum(1 for f in F if f["severity"] == FAIL), "warn": sum(1 for f in F if f["severity"] == WARN), "info": sum(1 for f in F if f["severity"] == INFO),
               "by_category": {}, "thresholds": th}
    for f in F:
        summary["by_category"][f["category"]] = summary["by_category"].get(f["category"], 0) + 1
    summary["verdict"] = "FAIL" if summary["fail"] else ("PASS with warnings" if summary["warn"] else "PASS")
    return {"summary": summary, "findings": F}


def render(doc, base_meta, cand_meta):
    s = doc["summary"]
    L = [f"# AlbionBench regression report", "",
         f"**Verdict: {s['verdict']}** - {s['points_compared']} points compared, {s['fail']} failing, {s['warn']} warnings, {s['info']} improvements.", "",
         f"* baseline: `{base_meta}`", f"* candidate: `{cand_meta}`",
         f"* thresholds: {json.dumps(s['thresholds'])} (stochastic workloads x{STOCHASTIC_FACTOR:g})",
         f"* by category: {json.dumps(s['by_category'])}", ""]
    for sev, title in ((FAIL, "Failures"), (WARN, "Warnings"), (INFO, "Improvements / information")):
        rows = [f for f in doc["findings"] if f["severity"] == sev]
        if not rows:
            continue
        L += [f"## {title} ({len(rows)})", "", "| point | category | detail |", "|---|---|---|"]
        for f in rows[:300]:
            L.append(f"| `{f['id']}` | {f['category']} | {f['message'].replace('|', '/')} |")
        L.append("")
    return "\n".join(L) + "\n"


def cli(a):
    from . import config as cfgmod
    base = json.loads(pathlib.Path(a.baseline).read_text())
    cand = json.loads(pathlib.Path(a.candidate).read_text())
    cfg = cfgmod.load(a.config)
    doc = compare(base, cand, cfg["thresholds"], strict_set=a.strict_set)
    out = pathlib.Path(a.out or pathlib.Path(a.candidate).parent)
    out.mkdir(parents=True, exist_ok=True)
    (out / "regression.json").write_text(json.dumps(doc, indent=1))
    (out / "regression_report.md").write_text(render(doc, a.baseline, a.candidate))
    s = doc["summary"]
    print(f"regression: {s['verdict']}  fail={s['fail']} warn={s['warn']} improved={s['info']}  by_category={s['by_category']}")
    for f in doc["findings"]:
        if f["severity"] == FAIL:
            print(f"  FAIL {f['category']:24s} {f['id']}: {f['message'][:140]}")
    return 1 if s["fail"] else 0
