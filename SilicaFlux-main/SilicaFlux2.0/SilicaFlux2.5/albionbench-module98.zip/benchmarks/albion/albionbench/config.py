"""Experiment configuration.

A configuration names the hardware knobs, the clock *assumption*, the seeds and the suite.  Every knob is classified by
where it is realised, so a report never implies that something was varied in RTL when it was not:

  rtl         - a real Verilog parameter of the simulated design; each value is a separate Verilator build
  workload    - a property of the stimulus (transfer length, tensor shape, number of active masters)
  assumption  - not representable in zero-delay RTL simulation; scales derived time-domain numbers only
  model_only  - not realisable in the available RTL; only the analytical models are evaluated (never "measured")
"""
import copy
import json
import pathlib

from . import paths

# ---- knob support matrix ---------------------------------------------------------------------------------------------
KNOBS = {
    "sram_banks": dict(
        realisation="rtl", backend="fabric", rtl_param="NB", allowed=[2, 3, 4, 5, 6, 7, 8],
        note="Albion fabric complex. Bank 0 is firmware-private (DMA can never reach it), so at least 2 banks are needed."),
    "bank_bytes": dict(
        realisation="rtl", backend="fabric", rtl_param="BANK_BYTES", allowed=[4096, 8192, 16384, 32768],
        note="Bytes per Albion SRAM bank (power of two)."),
    "dma_depth": dict(
        realisation="rtl", backend="fabric", rtl_param="DMA_DEPTH", allowed=[1, 2, 3, 4, 6, 8],
        note="Depth of the DMA prefetch FIFO (a real parameter of sf_albion_dma; sf_albion_cloud_top hard-codes 4)."),
    "bus_width_bits": dict(
        realisation="rtl", backend="fabric", rtl_param="(fixed)", allowed=[32],
        note="The Albion fabric data path is 32 bits wide in RTL (every port is [31:0]). Other widths are MODEL_ONLY for Albion; "
             "ComputeWorks' memory-port width is a real parameter, see compute_mem_width_bits."),
    "dma_burst_bytes": dict(
        realisation="workload", backend="fabric", rtl_param="-", allowed=None,
        note="sf_albion_dma has no burst protocol (single 32-bit beats, one outstanding request per port). 'Burst size' is the "
             "programmed transfer length of one DMA descriptor."),
    "concurrent_masters": dict(
        realisation="workload", backend="fabric", rtl_param="-", allowed=[1, 2, 3, 4],
        note="Fabric has exactly four masters (CORE, DMARD, DMAWR, HOST). The knob selects how many generators are active."),
    "host_latency_cycles": dict(
        realisation="workload", backend="fabric", rtl_param="-", allowed=None,
        note="Latency of the simulated host-memory port (host-side model, as in the P90 reference harness)."),
    "vector_lanes": dict(
        realisation="rtl", backend="compute", rtl_param="NUM_LANES", allowed=[1, 2, 4, 8, 16],
        note="ComputeWorks vector lanes (values covered by ComputeWorks' own verified configuration matrix)."),
    "tensor_array": dict(
        realisation="rtl", backend="compute", rtl_param="TENSOR_ROWS/TENSOR_COLS", allowed=[[2, 2], [4, 2], [4, 4], [8, 8]],
        note="INT8 systolic array dimensions (ComputeWorks' verified set)."),
    "compute_ports": dict(realisation="rtl", backend="compute", rtl_param="NUM_CP", allowed=[1, 2], note="Compute ports into the tile SRAM."),
    "compute_mem_width_bits": dict(realisation="rtl", backend="compute", rtl_param="DMA_DW", allowed=[64, 128],
                                   note="Width of the tile's local-memory words / DMA data path."),
    "tensor_shape": dict(realisation="workload", backend="compute", rtl_param="-", allowed=None, note="GEMM M,N,K."),
    "vector_length": dict(realisation="workload", backend="compute", rtl_param="-", allowed=None, note="Elements per vector command."),
    "clock_mhz": dict(
        realisation="assumption", backend="all", rtl_param="-", allowed=None,
        note="Zero-delay RTL simulation has no clock frequency. Cycle counts are clock-independent; bandwidth in MB/s, latency in ns "
             "and power-like numbers are scaled by this ASSUMED frequency. No timing closure exists for any SilicaFlux design."),
}

DEFAULT = {
    "name": "standard",
    "description": "Standard AlbionBench suite: every available workload at the reference configuration plus one-factor sweeps.",
    "suite": "standard",
    "seeds": [1, 2, 3],
    "clock": {"target_mhz": 50.0, "basis": "ASSUMED",
              "source": "P90 FPGA target (50 MHz); P90 place-and-route reached only 19.45 MHz and no timing closure exists"},
    "hardware": {
        "sram_banks": 4, "bank_bytes": 16384, "dma_depth": 4, "bus_width_bits": 32,
        "dma_burst_bytes": 4096, "concurrent_masters": 4, "host_latency_cycles": 1,
        "vector_lanes": 4, "tensor_array": [4, 4], "compute_ports": 1, "compute_mem_width_bits": 64,
        "tensor_shape": [16, 16, 64], "vector_length": 256,
    },
    "workloads": {"include": ["*"], "exclude": []},
    "thresholds": {   # regression gates, see regress.py
        "bandwidth_drop_pct": 0.5, "latency_increase_pct": 0.5, "tail_latency_increase_pct": 1.0,
        "stall_increase_pct": 1.0, "utilization_drop_pct": 1.0, "min_abs_cycles": 2,
    },
}


def load(path_or_name=None):
    cfg = copy.deepcopy(DEFAULT)
    if path_or_name:
        p = pathlib.Path(path_or_name)
        if not p.exists():
            p = paths.CONFIGS / (str(path_or_name) + ".json")
        if not p.exists():
            raise FileNotFoundError(f"configuration {path_or_name!r} not found (looked in {paths.CONFIGS})")
        user = json.loads(p.read_text())
        _merge(cfg, user)
        cfg["_source"] = str(p)
    validate(cfg)
    return cfg


def _merge(dst, src):
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            _merge(dst[k], v)
        else:
            dst[k] = v


def check_value(name, value):
    """Return (status, message): 'ok', 'model_only' (cannot be realised in RTL) or 'invalid'."""
    k = KNOBS.get(name)
    if k is None:
        return "invalid", f"unknown knob {name!r}"
    allowed = k["allowed"]
    if allowed is None:
        return "ok", ""
    if value in allowed:
        return "ok", ""
    if name == "bus_width_bits":
        return "model_only", f"{value}-bit bus is not realisable in the Albion RTL (fixed 32-bit); analytical model only"
    return "invalid", f"{name}={value!r} is outside the supported set {allowed}"


def validate(cfg):
    for name, value in cfg["hardware"].items():
        st, msg = check_value(name, value)
        if st == "invalid":
            raise ValueError(msg)
    if cfg["clock"]["target_mhz"] <= 0:
        raise ValueError("clock.target_mhz must be positive")
    bb = cfg["hardware"]["bank_bytes"]
    if bb & (bb - 1):
        raise ValueError("bank_bytes must be a power of two")


def support_matrix():
    return {k: {kk: vv for kk, vv in v.items()} for k, v in KNOBS.items()}
