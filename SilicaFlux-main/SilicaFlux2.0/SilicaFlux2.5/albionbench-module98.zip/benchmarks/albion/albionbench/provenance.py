"""Provenance capture.  Every report must identify: source revision, configuration, simulator, tool versions, random seed,
clock assumptions and test workload.  `validate()` refuses to write a report that lacks any of them."""
import datetime
import hashlib
import json
import os
import pathlib
import subprocess

from . import RESULT_SCHEMA, __version__, paths, toolchain

REQUIRED = ["source_revision", "configuration", "simulator", "tool_versions", "random_seed", "clock_assumptions", "test_workload"]


def _git(args, cwd):
    try:
        r = subprocess.run(["git"] + args, cwd=cwd, capture_output=True, text=True, timeout=20)
        return r.stdout.strip() if r.returncode == 0 else None
    except Exception:
        return None


def hash_tree(root, exclude=("build", "results", "baselines", "__pycache__", ".pytest_cache", ".git", "PROVENANCE_STAMP.json")):
    h = hashlib.sha256()
    n = 0
    root = pathlib.Path(root)
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        parts = set(p.relative_to(root).parts)
        if parts & set(exclude) or p.suffix in (".pyc", ".zip"):
            continue
        h.update(p.relative_to(root).as_posix().encode())
        h.update(p.read_bytes())
        n += 1
    return h.hexdigest(), n


def source_revision(rtl_roots=None):
    """Where the numbers come from: the repository commit, whether the framework/RTL differ from it, and content hashes."""
    fw_hash, fw_files = hash_tree(paths.ROOT)
    out = {"framework_tree_sha256": fw_hash, "framework_files": fw_files, "framework_version": __version__}
    env = os.environ.get("ALBIONBENCH_SOURCE_REV")
    head = _git(["rev-parse", "HEAD"], str(paths.ROOT))
    stamp_path = paths.ROOT / "PROVENANCE_STAMP.json"
    stamp = json.loads(stamp_path.read_text()) if stamp_path.exists() else None
    if env:
        out["git_head"], out["revision_origin"] = env, "ALBIONBENCH_SOURCE_REV environment variable"
    elif head:
        out["git_head"], out["revision_origin"] = head, "git rev-parse HEAD of the repository containing this framework"
        porcelain = _git(["status", "--porcelain", "--", str(paths.ROOT)], str(paths.ROOT))
        out["framework_uncommitted_changes"] = bool(porcelain)
        out["git_branch"] = _git(["rev-parse", "--abbrev-ref", "HEAD"], str(paths.ROOT))
    elif stamp:
        out.update({k: stamp[k] for k in ("git_head", "git_branch") if k in stamp})
        out["revision_origin"] = "PROVENANCE_STAMP.json shipped with the framework archive (not a git checkout)"
    else:
        out["git_head"], out["revision_origin"] = "unknown", "not a git checkout, no PROVENANCE_STAMP.json and no ALBIONBENCH_SOURCE_REV"
    if stamp:        # always keep the packaging-time identity next to whatever git reports now
        out["packaged_from"] = {k: stamp.get(k) for k in ("git_head", "git_branch", "stamped_at", "note")}
    roots = rtl_roots or {"albion_soc": paths.RTL_UNDER_TEST / "albion_soc", "computeworks": paths.RTL_UNDER_TEST / "computeworks"}
    rtl = {}
    for name, root in roots.items():
        root = pathlib.Path(root)
        th, n = hash_tree(root, exclude=("build", "__pycache__", ".git"))
        rtl[name] = {"path": str(root), "tree_sha256": th, "files": n}
    out["rtl_under_test"] = rtl
    src = paths.RTL_UNDER_TEST / "SOURCES.json"
    if src.exists():
        out["rtl_upstream_archives"] = json.loads(src.read_text())
    return out


def simulator_info(builds):
    """Simulator identity: Verilator version, flags and the SHA-256 of every simulator binary used."""
    vv = toolchain.version_of(["verilator", "--version"])
    return {
        "name": "Verilator", "version": vv, "kind": "cycle-accurate two-state RTL simulation (zero-delay, no timing, no power)",
        "flags": toolchain.VERILATOR_FLAGS, "power_up_state": "randomised (--x-initial unique, VerilatedContext::randReset(2), seeded per run)",
        "binaries": builds,
    }


def clock_assumptions(cfg):
    c = cfg["clock"]
    return {
        "target_mhz": c["target_mhz"], "basis": c["basis"], "source": c["source"],
        "statement": ("RTL simulation is zero-delay: cycle counts do not depend on frequency. Every value in ns, MB/s, GOPS or W "
                      f"is derived by assuming a {c['target_mhz']} MHz clock. No SilicaFlux design has timing closure; "
                      "no silicon or FPGA run exists."),
    }


def build(cfg, builds, workloads, seeds, extra=None):
    prov = {
        "schema": RESULT_SCHEMA,
        "generated_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "source_revision": source_revision(),
        "configuration": {k: v for k, v in cfg.items() if not k.startswith("_")},
        "configuration_sha256": hashlib.sha256(json.dumps({k: v for k, v in cfg.items() if not k.startswith("_")}, sort_keys=True).encode()).hexdigest(),
        "simulator": simulator_info(builds),
        "tool_versions": toolchain.tool_versions(),
        "random_seed": {"seeds": list(seeds),
                        "usage": "seed S: stream/address RNGs are seeded from S; Verilator power-up randomisation seed is S+1; "
                                 "deterministic workloads must give identical cycle counts for every seed (checked)"},
        "clock_assumptions": clock_assumptions(cfg),
        "test_workload": workloads,
    }
    if extra:
        prov.update(extra)
    return prov


def validate(prov):
    missing = [k for k in REQUIRED if not prov.get(k)]
    sr = prov.get("source_revision", {})
    if not sr.get("git_head") or sr.get("git_head") == "unknown":
        missing.append("source_revision.git_head (set ALBIONBENCH_SOURCE_REV=<commit> when running outside a git checkout without PROVENANCE_STAMP.json)")
    if not prov.get("simulator", {}).get("version"):
        missing.append("simulator.version")
    if not prov.get("test_workload"):
        missing.append("test_workload")
    if missing:
        raise ValueError(f"provenance incomplete: {missing}")
    return True
