"""benchmark_report.md and SVG charts, generated only from a results document (nothing is recomputed that is not in results.json)."""
import json
import math
import pathlib

from . import metrics as M

PALETTE = {"light": {"surface": "#fcfcfb", "ink": "#0b0b0b", "ink2": "#52514e", "grid": "#e4e3df", "s1": "#2a78d6", "s2": "#eb6834", "s3": "#1baf7a"},
           "dark": {"surface": "#1a1a19", "ink": "#f0efec", "ink2": "#c3c2b7", "grid": "#34332f", "s1": "#3987e5", "s2": "#d95926", "s3": "#199e70"}}


def f(v, n=3, dash="-"):
    if v is None:
        return dash
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, int):
        return f"{v:,}"
    if abs(v) >= 1000:
        return f"{v:,.0f}"
    return f"{v:.{n}f}"


def esc(s):
    return str(s).replace("|", "\\|")


# =============================================================================================== charts
class Svg:
    def __init__(self, w, h, title, desc):
        self.w, self.h, self.title, self.desc = w, h, title, desc
        self.parts = []

    def add(self, s):
        self.parts.append(s)

    def render(self):
        css = ":root{" + ";".join(f"--{k}:{v}" for k, v in PALETTE["light"].items()) + "}" \
              "@media (prefers-color-scheme: dark){:root{" + ";".join(f"--{k}:{v}" for k, v in PALETTE["dark"].items()) + "}}" \
              "text{font-family:system-ui,-apple-system,Segoe UI,sans-serif;font-size:12px;fill:var(--ink2)} .t{font-size:14px;font-weight:600;fill:var(--ink)}" \
              " .g{stroke:var(--grid);stroke-width:1} .ax{stroke:var(--ink2);stroke-width:1} .lbl{fill:var(--ink)}"
        return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {self.w} {self.h}" width="{self.w}" height="{self.h}" role="img" aria-labelledby="t d">'
                f'<title id="t">{self.title}</title><desc id="d">{self.desc}</desc><style>{css}</style>'
                f'<rect width="{self.w}" height="{self.h}" fill="var(--surface)"/>' + "".join(self.parts) + "</svg>")


def _logscale(lo, hi, a, b):
    llo, lhi = math.log10(lo), math.log10(hi)
    return lambda v: a + (math.log10(max(v, lo)) - llo) / (lhi - llo) * (b - a)


def _decades(lo, hi):
    out, e = [], math.floor(math.log10(lo))
    while 10 ** e <= hi * 1.0001:
        if 10 ** e >= lo * 0.9999:
            out.append(10 ** e)
        e += 1
    return out


def _fmt_tick(v):
    return f"{v:g}"


def _marker(kind, x, y, color, r=4.5):
    if kind == "circle":
        return f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r}" fill="{color}" stroke="var(--surface)" stroke-width="1.5"/>'
    if kind == "square":
        return f'<rect x="{x - r:.1f}" y="{y - r:.1f}" width="{2 * r}" height="{2 * r}" rx="1" fill="{color}" stroke="var(--surface)" stroke-width="1.5"/>'
    return f'<path d="M{x:.1f} {y - r - 1:.1f} L{x + r + 1:.1f} {y + r:.1f} L{x - r - 1:.1f} {y + r:.1f}Z" fill="{color}" stroke="var(--surface)" stroke-width="1.5"/>'


def _frame(svg, x0, y0, x1, y1, xs, ys, xlo, xhi, ylo, yhi, xlabel, ylabel):
    for v in _decades(xlo, xhi):
        svg.add(f'<line class="g" x1="{xs(v):.1f}" y1="{y0}" x2="{xs(v):.1f}" y2="{y1}"/><text x="{xs(v):.1f}" y="{y1 + 16}" text-anchor="middle">{_fmt_tick(v)}</text>')
    for v in _decades(ylo, yhi):
        svg.add(f'<line class="g" x1="{x0}" y1="{ys(v):.1f}" x2="{x1}" y2="{ys(v):.1f}"/><text x="{x0 - 6}" y="{ys(v) + 4:.1f}" text-anchor="end">{_fmt_tick(v)}</text>')
    svg.add(f'<line class="ax" x1="{x0}" y1="{y1}" x2="{x1}" y2="{y1}"/><line class="ax" x1="{x0}" y1="{y0}" x2="{x0}" y2="{y1}"/>')
    svg.add(f'<text x="{(x0 + x1) / 2:.0f}" y="{y1 + 36}" text-anchor="middle">{xlabel}</text>')
    svg.add(f'<text transform="translate(16 {(y0 + y1) / 2:.0f}) rotate(-90)" text-anchor="middle">{ylabel}</text>')


def _legend(svg, x, y, items):
    for i, (kind, color, text) in enumerate(items):
        yy = y + i * 18
        if kind == "line":
            svg.add(f'<line x1="{x}" y1="{yy}" x2="{x + 16}" y2="{yy}" stroke="{color}" stroke-width="2"/>')
        else:
            svg.add(_marker(kind, x + 8, yy, color, 4))
        svg.add(f'<text class="lbl" x="{x + 24}" y="{yy + 4}">{text}</text>')


def chart_roofline(doc):
    pts = doc["models"]["roofline"]["points"]
    base = [p for p in pts if p["roof"] in ("gemm|peak=32|bw=8", "vector|peak=4|bw=8")]
    if not base:
        return None
    W, H, x0, y0, x1, y1 = 760, 460, 70, 56, 730, 380
    xlo, xhi, ylo, yhi = 0.03, 100, 0.03, 100
    xs, ys = _logscale(xlo, xhi, x0, x1), _logscale(ylo, yhi, y1, y0)
    s = Svg(W, H, "Roofline of the ComputeWorks tile", "Measured ops per cycle versus arithmetic intensity (effective bytes) for GEMM and INT32 vector commands, with the compute and memory roofs of the reference tile.")
    s.add('<text class="t" x="70" y="24">Roofline: measured ops/cycle vs arithmetic intensity</text>')
    s.add('<text x="70" y="42">reference tile: 4x4 array, 4 lanes, 1 compute port, 64-bit memory</text>')
    _frame(s, x0, y0, x1, y1, xs, ys, xlo, xhi, ylo, yhi, "arithmetic intensity, effective SRAM bytes (ops/byte)", "ops per cycle")
    for peak, col, name in ((32, "var(--s1)", "GEMM roof 32 ops/cycle"), (4, "var(--s2)", "vector roof 4 elem/cycle")):
        ridge = peak / 8.0
        s.add(f'<polyline fill="none" stroke="{col}" stroke-width="1.5" stroke-dasharray="5 3" points="{xs(xlo):.1f},{ys(xlo * 8):.1f} {xs(ridge):.1f},{ys(peak):.1f} {xs(xhi):.1f},{ys(peak):.1f}"/>')
        s.add(f'<text class="lbl" x="{xs(xhi) - 4:.0f}" y="{ys(peak) - 6:.0f}" text-anchor="end">{name}</text>')
    for p in base:
        col, kind = ("var(--s1)", "circle") if p["kind"] == "gemm" else ("var(--s2)", "square")
        s.add(_marker(kind, xs(p["ai_effective"]), ys(p["measured_ops_per_cycle"]), col))
    _legend(s, 90, 76, [("circle", "var(--s1)", "GEMM, measured"), ("square", "var(--s2)", "INT32 vector, measured"), ("line", "var(--ink2)", "roof = min(peak, AI x bandwidth)")])
    s.add(f'<text x="{x0}" y="{H - 26}">Gap between points and roofs = serialised load/compute/store phases and per-command fixed cost.</text>')
    s.add(f'<text x="{x0}" y="{H - 8}">{len(base)} reference-tile points shown; every configuration is in results.json.</text>')
    return s.render()


def chart_validation(doc):
    rows = [r for r in doc["model_validation"]["rows"] if r["metric"] == "clock_cycles" and not r["in_sample"] and r["measured"] and r["predicted"] and r["measured"] > 0
            and r["predicted"] > 0]
    if len(rows) < 5:
        return None
    W, H, x0, y0, x1, y1 = 640, 520, 70, 56, 610, 440
    lo = max(1, min(min(r["measured"], r["predicted"]) for r in rows) * 0.8)
    hi = max(max(r["measured"], r["predicted"]) for r in rows) * 1.25
    xs, ys = _logscale(lo, hi, x0, x1), _logscale(lo, hi, y1, y0)
    s = Svg(W, H, "Predicted versus RTL-simulated cycles", "Out-of-sample predicted cycles against measured RTL cycles on log axes; points on the diagonal are exact.")
    s.add(f'<text class="t" x="70" y="24">Predicted vs RTL-simulated window cycles ({len(rows)} out-of-sample points)</text>')
    _frame(s, x0, y0, x1, y1, xs, ys, lo, hi, lo, hi, "RTL-simulated cycles (measured)", "model-predicted cycles")
    s.add(f'<line x1="{xs(lo):.1f}" y1="{ys(lo):.1f}" x2="{xs(hi):.1f}" y2="{ys(hi):.1f}" stroke="var(--ink2)" stroke-width="1" stroke-dasharray="4 3"/>')
    style = {"structural": ("circle", "var(--s1)"), "fitted": ("square", "var(--s2)"), "monte-carlo": ("triangle", "var(--s3)")}
    for r in rows:
        kind, col = style.get(r["basis"], ("circle", "var(--ink2)"))
        s.add(_marker(kind, xs(r["measured"]), ys(r["predicted"]), col, 3.5))
    cnt = {b: sum(1 for r in rows if r["basis"] == b) for b in style}
    _legend(s, 90, 76, [(style[b][0], style[b][1], f"{b} ({cnt[b]})") for b in style if cnt[b]] + [("line", "var(--ink2)", "y = x (exact)")])
    return s.render()


def chart_host_latency(doc):
    pts = {"host_to_sram": [], "sram_to_host": []}
    for r in doc["points"]:
        if r["workload"] == "dma_bandwidth" and r["status"] == "OK" and r["params"].get("mode") in pts and r["hardware"]["dma_depth"] == 4 \
                and r["params"]["length"] in (4096, 1200, 800):
            pts[r["params"]["mode"]].append((r["hardware"]["host_latency_cycles"], r["metrics"]["memory_bandwidth_bytes_per_cycle"]))
    if len(pts["host_to_sram"]) < 3:
        return None
    W, H, x0, y0, x1, y1 = 640, 420, 70, 56, 610, 340
    xlo, xhi, ylo, yhi = 0.8, 100, 0.03, 8
    xs, ys = _logscale(xlo, xhi, x0, x1), _logscale(ylo, yhi, y1, y0)
    s = Svg(W, H, "DMA bandwidth versus host-memory latency", "Measured DMA bandwidth over the host-memory port against its latency in cycles, with the 4 bytes per L cycles ceiling.")
    s.add('<text class="t" x="70" y="24">Host DMA is latency-bound: bandwidth = 4 B / L cycles</text>')
    _frame(s, x0, y0, x1, y1, xs, ys, xlo, xhi, ylo, yhi, "host-memory latency L (cycles)", "DMA bandwidth (bytes/cycle)")
    s.add(f'<polyline fill="none" stroke="var(--ink2)" stroke-width="1.5" stroke-dasharray="5 3" points="{xs(1):.1f},{ys(4):.1f} {xs(100):.1f},{ys(0.04):.1f}"/>')
    for (kind, col, mode) in (("circle", "var(--s1)", "host_to_sram"), ("square", "var(--s2)", "sram_to_host")):
        for L, bw in sorted(set(pts[mode])):
            s.add(_marker(kind, xs(L), ys(bw), col))
    _legend(s, 440, 76, [("circle", "var(--s1)", "host -> SRAM"), ("square", "var(--s2)", "SRAM -> host"), ("line", "var(--ink2)", "ceiling 4/L")])
    s.add(f'<text x="{x0}" y="{H - 10}">Markers coincide where both directions give identical bandwidth (L = 1, 4, 16, 64).</text>')
    return s.render()


def write_charts(doc, out):
    out = pathlib.Path(out)
    for name, fn in (("roofline.svg", chart_roofline), ("model_validation.svg", chart_validation), ("dma_host_latency.svg", chart_host_latency)):
        try:
            svg = fn(doc)
        except Exception as e:      # a chart must never block the report
            svg = None
            print(f"chart {name} skipped: {e}")
        if svg:
            (out / name).write_text(svg)


# =============================================================================================== markdown
def table(headers, rows, align=None):
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join((align[i] if align else ("---" if i == 0 else "---:")) for i in range(len(headers))) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out)


GROUP_TITLES = {"memory": "Memory (SRAM, random access, bank conflicts, concurrency)", "fabric": "Bus arbitration", "dma": "DMA bandwidth and latency",
                "host": "Host transactions", "compute": "Compute (integer vector arithmetic, matrix multiplication)"}


def _row(r):
    m = r["metrics"]
    en = (r.get("energy") or {}).get("total_nJ")
    err = (r.get("model_prediction") or {}).get("clock_cycles_error_pct")
    return [esc(r["label"]) + (" *" if r["sweep"] == "blind-validation" else ""), r["status"], f(m["clock_cycles"]), f(m["completed_ops"]), f(m["bytes_transferred"]),
            f(m["memory_bandwidth_bytes_per_cycle"]), f(m["transaction_throughput_per_cycle"]), f(m["latency_avg_cycles"], 2), f(m["latency_p99_cycles"], 1),
            f(m["latency_max_cycles"], 1), f(m["stall_cycles"], 0), f(m["memory_conflicts"], 0), f(m["pipeline_utilization"], 3), f(m["compute_utilization"], 3),
            f(en, 3) if en is not None else "-", ("%+.2f%%" % err) if err is not None else "-"]


HEAD = ["point", "status", "cycles", "ops", "bytes", "B/cycle", "txn/cycle", "lat avg", "p99", "max", "stalls", "conflicts", "pipe util", "compute util", "est. nJ", "model err"]


def write_markdown(doc, path):
    P = doc["provenance"]
    sr, sim, tv = P["source_revision"], P["simulator"], P["tool_versions"]
    cfgp = P["configuration"]
    recs = doc["points"]
    S = doc["summary"]
    L = []
    w = L.append
    w("# AlbionBench - SilicaFlux performance and energy benchmark report")
    w("")
    w(f"Module 98 · framework v{sr['framework_version']} · generated {P['generated_utc']} · suite **{cfgp['name']}** · "
      f"**{S['points']} measured points**, {S['by_status'].get('OK', 0)} OK" + ("" if S["all_correct"] else f" - **NOT ALL OK: {S['by_status']}**"))
    w("")
    w("> **What these numbers are.** Cycle counts from cycle-accurate RTL simulation (Verilator) of the real SilicaFlux RTL, with every result checked against an independent shadow model "
      "or reference. They are **not** silicon, FPGA or gate-level measurements. No clock frequency, timing closure or power measurement exists for any SilicaFlux design: "
      "time-domain values use an **assumed** clock and energy values are **labelled estimates** (see §7).")
    w("")
    w("## 1. Provenance")
    w("")
    w("Every field below is required; a report cannot be generated without them.")
    w("")
    rtl = sr["rtl_under_test"]
    arch = sr.get("rtl_upstream_archives", {})
    prow = [
        ["**Source revision**", f"repository `{sr.get('git_head', '?')[:12]}` (branch `{sr.get('git_branch', '-')}`; {'framework has UNCOMMITTED changes' if sr.get('framework_uncommitted_changes') else 'clean'}); "
                                f"origin: {sr['revision_origin']}. Framework tree SHA-256 `{sr['framework_tree_sha256'][:16]}` ({sr['framework_files']} files). "
                                f"RTL under test: Albion SoC tree `{rtl['albion_soc']['tree_sha256'][:16]}` ({rtl['albion_soc']['files']} files, upstream `{arch.get('albion_soc', {}).get('upstream_archive', '?')}` "
                                f"sha256 `{arch.get('albion_soc', {}).get('upstream_archive_sha256', '?')[:16]}`); ComputeWorks tree `{rtl['computeworks']['tree_sha256'][:16]}` "
                                f"({rtl['computeworks']['files']} files, upstream `{arch.get('computeworks', {}).get('upstream_archive', '?')}` sha256 `{arch.get('computeworks', {}).get('upstream_archive_sha256', '?')[:16]}`)"],
        ["**Configuration**", f"`{cfgp['name']}` (suite `{cfgp['suite']}`), config SHA-256 `{P['configuration_sha256'][:16]}`. Reference hardware: "
                              + ", ".join(f"{k}={json.dumps(v)}" for k, v in cfgp["hardware"].items())],
        ["**Simulator**", f"{sim['version']} - {sim['kind']}. Flags: `{' '.join(sim['flags'])}`. Power-up state: {sim['power_up_state']}. "
                          f"{len(sim['binaries'])} simulator build(s) (full list with binary SHA-256 in results.json → provenance.simulator.binaries): " + "; ".join(f"{b['kind']} `{b['key'][:8]}`" for b in list(sim["binaries"].values())[:4]) + " ..."],
        ["**Tool versions**", "; ".join(f"{k} = {v}" for k, v in tv.items() if v)],
        ["**Random seed**", f"seeds {P['random_seed']['seeds']} - {P['random_seed']['usage']}"],
        ["**Clock assumptions**", f"{P['clock_assumptions']['target_mhz']} MHz, basis **{P['clock_assumptions']['basis']}** ({P['clock_assumptions']['source']}). {P['clock_assumptions']['statement']}"],
        ["**Test workload**", f"{len(P['test_workload']['executed'])} workload families, {S['points']} points: " + ", ".join(f"`{x['id']}` ({len(x['points'])})" for x in P["test_workload"]["executed"])
         + f". Declared unavailable: {', '.join('`' + u + '`' for u in P['test_workload']['declared_unavailable'])}. Full parameter list per point: results.json → provenance.test_workload."],
    ]
    fw = (P.get("backend_provenance") or {}).get("firmware")
    if fw:
        prow.append(["**Firmware**", f"RV32I ControlCore image sha256 `{fw['sha256'][:16]}` built with {fw.get('toolchain')}"])
    w(table(["field", "value"], prow, ["---", "---"]))
    w("")
    w("## 2. Evidence classes and how to read the numbers")
    w("")
    w(table(["class", "meaning", "where used"], [
        ["**rtl-simulation**", "cycle-accurate simulation of the real RTL; counts are exact for the stimulus used", "all measured tables (§5)"],
        ["**structural model**", "prediction derived from RTL/protocol analysis, no constant fitted to benchmark output", "Models A, D (§6)"],
        ["**fitted model**", "constants least-squares fitted to a named calibration set; validated out of sample", "Models C, E, mailbox latency (§6)"],
        ["**ASSUMED clock**", "frequency chosen by the user; scales ns, MB/s, mW only", "`metrics_at_assumed_clock`"],
        ["**library ESTIMATE**", "activity counts x literature per-event energies; dynamic only; NOT measured", "§7 and `est. nJ` columns"],
        ["**UNAVAILABLE**", "hardware absent from the RTL; probed, never stubbed", "§4"]], ["---", "---", "---"]))
    w("")
    w("Latency is first-valid → response in cycles (compute: execution cycles per command). Tail latency is the exact percentile of all transactions where histograms are available. "
      "Metrics marked `-` are *not applicable* (never zero). `*` after a point label marks a **blind validation** point (see §6). Pipeline utilisation = accepted requests ÷ (banks touched × cycles) "
      "for fabric points, engine-active ÷ in-flight cycles for compute. Window cycles include the final response cycle.")
    w("")
    w("## 3. Key findings")
    w("")
    for i, fd in enumerate(doc.get("findings", []), 1):
        w(f"{i}. **{fd['title']}** - {fd['text']} *(evidence: {', '.join('`' + e + '`' for e in fd['evidence'][:4]) or 'models'}; class: {fd['evidence_class']})*")
    w("")
    w("## 4. Hardware availability")
    w("")
    rows = []
    for u in doc["unavailable"]:
        pr = u.get("probe")
        pt = "-"
        if pr and "feature" in pr:
            pt = (f"FEAT_{pr['feature']}: requested={pr['requested']}, implemented={pr['implemented']}; firmware opcode `{pr['opcode']}` → "
                  f"`{pr['firmware_completion_status']}`; **confirmed unavailable: {u.get('probe_confirms_unavailable')}**")
        elif pr:
            pt = f"probe did not run: {pr.get('error')}"
        rows.append([f"`{u['id']}`", u["needs"], u["evidence"], pt])
    w(table(["workload", "needs", "evidence", "live-RTL probe"], rows, ["---", "---", "---", "---"]))
    w("")
    fp = (P.get("backend_provenance") or {}).get("feature_probe") or {}
    if fp.get("rtl_banner"):
        w("RTL notice printed by `sf_albion_cloud_top` CONFIG=2: `" + " ".join(fp["rtl_banner"]) + "`")
        w("")
    w("Available and benchmarked: SRAM banks with SECDED (sequential, random, RMW, conflicts), DataFabric arbitration, DMA (fill/copy/host), host MMIO + mailbox with firmware, "
      "ComputeWorks INT32 vector and INT8 GEMM **as a standalone tile** (it is not wired into the Albion SoC top).")
    w("")
    w("## 5. Measured results")
    w("")
    for g in ("memory", "fabric", "dma", "host", "compute"):
        sel = [r for r in recs if r["group"] == g]
        if not sel:
            continue
        w(f"### {GROUP_TITLES[g]}")
        w("")
        by = {}
        for r in sel:
            by.setdefault(r["workload"], []).append(r)
        for wl, rs in by.items():
            from . import workloads
            wd = workloads.REGISTRY[wl]
            w(f"**`{wl}`** - {wd.title}. {wd.description}")
            w("")
            w(table(HEAD, [_row(r) for r in rs]))
            w("")
    bad = [r for r in recs if r["status"] != "OK"]
    if bad:
        w("### Points that did not pass")
        w("")
        w(table(["point", "status", "reason"], [[esc(r["id"]), r["status"], esc((r["detail"] or {}).get("error") or "; ".join((r["detail"] or {}).get("correctness_issues", []) + r["notes"]
                                                                                                               + (r["detail"] or {}).get("instrumentation_mismatches", [])))[:300]] for r in bad], ["---", "---", "---"]))
        w("")
    w("### Time-domain view at the ASSUMED clock")
    w("")
    clk = P["clock_assumptions"]["target_mhz"]
    sel = [r for r in recs if r["status"] == "OK" and r["label"] in ("base", "copy_xbank/len=4096", "host_to_sram/len=4096", "ping", "read-idle", "16x16x64", "add/vl=256")]
    w(f"At an **assumed {clk} MHz** (not a measured or signed-off clock):")
    w("")
    w(table(["point", "bandwidth MB/s", "latency avg ns", "latency p99 ns", "window µs"],
            [[esc(r["id"]), f(r["metrics_at_assumed_clock"].get("memory_bandwidth_MB_per_s"), 1), f(r["metrics_at_assumed_clock"].get("latency_avg_ns"), 1),
              f(r["metrics_at_assumed_clock"].get("latency_p99_ns"), 1), f(r["metrics_at_assumed_clock"].get("window_us"), 2)] for r in sel]))
    w("")
    # ---------------------------------------------------------------- models
    mv = doc["model_validation"]
    sm = mv["summary"]
    w("## 6. Performance models: predicted vs RTL simulation")
    w("")
    w("Five models predict RTL results from architecture parameters. Each prediction is compared with the measured value; a comparison is *within tolerance* if "
      f"|predicted − measured| ≤ max(absolute tolerance, percent tolerance × measured) with percent tolerance {json.dumps(doc['models']['tolerances']['percent_by_basis'])} by basis. "
      "**Only out-of-sample points count as validation.** *In-sample* = a point used to fix a constant. *Blind validation* points (marked `*`) were added after the models were written and "
      "were never used to design or calibrate them.")
    w("")
    o = sm["overall_out_of_sample"]
    i = sm["overall_in_sample"]
    w(f"**Out-of-sample: {o['within_tolerance']} of {o['n']} comparisons within tolerance** (median |error| {o['median_abs_error_pct']:.3f}%, max {o['max_abs_error_pct']:.2f}%); "
      + (f"in-sample: {i['within_tolerance']} of {i['n']}." if i else ""))
    w("")
    rows = []
    for m, v in sm["by_model"].items():
        oo, bb = v["out_of_sample"], v["blind_validation_only"]
        rows.append([f"**{m}** {doc['models']['titles'].get(m, '')}", f"{oo['within_tolerance']}/{oo['n']}" if oo else "-", f(oo["median_abs_error_pct"], 3) if oo else "-",
                     f(oo["max_abs_error_pct"], 2) if oo else "-", f"{bb['within_tolerance']}/{bb['n']}" if bb else "-"])
    rows.append(["**B** Roofline model", "see below", "-", "-", "-"])
    w(table(["model", "out-of-sample within tolerance", "median abs err %", "max abs err %", "blind-validation subset"], rows))
    w("")
    w(table(["basis", "n (out-of-sample)", "within", "median abs err %", "max abs err %"],
            [[b, v["n"], v["within_tolerance"], f(v["median_abs_error_pct"], 3), f(v["max_abs_error_pct"], 2)] for b, v in sm["by_basis"].items() if v]))
    w("")
    if (pathlib.Path(path).parent / "model_validation.svg").exists():
        w("![Predicted vs measured cycles](model_validation.svg)")
        w("")
    out = [r for r in mv["rows"] if not r["within_tolerance"]]
    w(f"### Predictions outside tolerance ({len(out)})")
    w("")
    if out:
        w(table(["model", "point", "metric", "predicted", "measured", "error", "basis", "in-sample"],
                [[r["model"], esc(r["id"]), r["metric"], f(r["predicted"], 3), f(r["measured"], 3), "%+.2f%%" % r["error_pct"], r["basis"], r["in_sample"]] for r in out]))
        w("")
        w("Each miss is a statement about the model, not the RTL: the RTL numbers above are measurements. Where a cause is known it is listed under *Known model limitations* (§9).")
    else:
        w("None.")
    w("")
    w("### Model A - memory bandwidth (structural)")
    w("")
    w("Architecture facts: one outstanding request per master with same-cycle re-issue (1 request/cycle/master); SRAM bank accepts 1 request/cycle, responds next cycle; partial writes occupy the bank "
      "2 cycles; per-slave round-robin; DMA FIFO slot lifetime = read → write round trip (Little's law: period ≥ round-trip ÷ depth); host port one outstanding request. "
      "DMA window = `(N−1)·P + S_r + S_w + 4` (copy) or `(N−1)·P + S_w + 3` (fill), same-bank copy = `2N + 3`; stochastic traffic uses the expectation of the documented arbitration rules (Monte Carlo). "
      "Constants anchored to P90's independently published DMA_CYCLES values: 2050 (fill 8 KiB), 2052 (copy), 4098 (same-bank copy), 1028/4100/16388/65540 (host, L = 1/4/16/64).")
    w("")
    w("### Model B - roofline")
    w("")
    rl = doc["models"]["roofline"]
    w("Attainable ops/cycle = min(peak compute, AI × peak bandwidth). Peaks: GEMM `2·R·C`, vector `lanes`; bandwidth `ports × memory-word bytes`. Not fitted.")
    w("")
    if (pathlib.Path(path).parent / "roofline.svg").exists():
        w("![Roofline](roofline.svg)")
        w("")
    rows = []
    for p in rl["points"]:
        if p["sweep"] in ("tensor_shape", "size", "lanes", "mem_width", "tensor_array", None) and p["roof"] in ("gemm|peak=32|bw=8", "vector|peak=4|bw=8", "gemm|peak=32|bw=16", "vector|peak=4|bw=16"):
            rows.append([esc(p["id"]), p["roof"].split("|")[1].replace("peak=", "") + " / " + p["roof"].split("|")[2].replace("bw=", ""), f(p["ai_compulsory"], 2), f(p["ai_effective"], 2),
                         f(p["measured_ops_per_cycle"], 2), f(p["attainable_effective"], 2), f(p["efficiency_vs_effective_roof"], 3), f(p["non_overlapped_bound"], 2), f(p["efficiency_vs_non_overlapped"], 3),
                         p["bound_effective"]])
    w(table(["point", "peak ops / BW (B/cyc)", "AI compulsory", "AI effective", "measured ops/cyc", "effective roof", "% of roof", "non-overlapped bound", "% of bound", "bound by"], rows[:40]))
    w("")
    ac = doc["models"]["accelerator_calibration"]
    w("### Model C - accelerator utilisation (fitted)")
    w("")
    w("Per-command cycles = load + compute + store + overhead, phases serialised. Structural terms: array busy = Σ over blocks of `(K + r + c + 1)` with the ACTUAL block size r×c (exact, including partial tiles), words written from the output byte ranges (exact), words read from the operand byte ranges (exact when tiles are word-aligned, approximate otherwise), vector compute = `ceil(len/lanes)` per staging chunk. "
      "Fitted constants (least squares on the tile's own phase counters, calibration set below):")
    w("")
    if "gemm" in ac:
        w("GEMM: " + ", ".join(f"`{k}` = {v:.3f}" for k, v in ac["gemm"].items()) + f". Calibration: {', '.join(ac['calibration_points']['gemm'])}.")
        w("")
    if "vector" in ac:
        w("Vector: " + ", ".join(f"`{k}` = {v:.3f}" for k, v in ac["vector"].items()) + f". Calibration: {', '.join(ac['calibration_points']['vector'])}.")
        w("")
    w("Dual-port (cp = 2) configurations are not modelled.")
    w("")
    w("### Model D - transaction latency")
    w("")
    sc = doc["models"]["soc_latency_calibration"]
    w("Fabric: latency = accept wait + service; K saturating masters → K cycles each (mean = p99 = max), partial write service 2, host port L. Mailbox: "
      + (f"`{sc['model']}` with t_mmio = {sc['t_mmio_cycles']:.2f} cycles measured, **CPI = {sc['cpi']:.2f}** and c = {sc['c_cycles']:.1f} cycles fitted on {', '.join(sc['calibration_points'])}; all other command points are out of sample."
         if sc else "not available in this run."))
    w("")
    sd = [r for r in mv["rows"] if r["model"] == "D" and r["workload"].startswith("host_")]
    if sd:
        w(table(["point", "predicted RTT", "measured RTT", "error", "in-sample"], [[esc(r["id"]), f(r["predicted"], 1), f(r["measured"], 1), "%+.2f%%" % r["error_pct"], r["in_sample"]] for r in sd]))
        w("")
    w("### Model E - workload scaling")
    w("")
    sca = doc["models"]["scaling"]
    w("Hockney size fit `T(n) = T0 + n / r∞` on the standard sweep, validated on blind sizes and by extrapolating to the largest standard size:")
    w("")
    rows = []
    for s_ in sca["hockney"]:
        ex = s_.get("extrapolation")
        bl = [v["error_pct"] for v in s_["validation_points"]]
        rows.append([s_["series"], f(s_["T0"], 2), f(s_["r_inf_per_cycle"], 3), f(s_["n_half"], 1), ("%+.2f%%" % ex["error_pct"]) if ex else "-",
                     (", ".join("%+.2f%%" % b for b in bl)) if bl else "-"])
    w(table(["series", "T0 (cycles)", "r∞ (n/cycle)", "n½", "extrapolation err", "blind-size errors"], rows))
    w("")
    ls = sca.get("lane_scaling")
    if ls:
        w(f"Vector lane scaling (Amdahl) `{ls['model']}`: T_serial = {ls['T_serial']:.0f}, T_parallel = {ls['T_parallel']:.0f}, max speed-up {ls['amdahl_max_speedup']:.2f}x; fitted on lanes {ls['fit_on_lanes']}.")
        w("")
        w(table(["lanes", "cycles/cmd", "speed-up", "ideal", "efficiency", "predicted", "error", "in-sample"],
                [[r["lanes"], f(r["cycles"], 0), f(r["speedup_measured"], 2), f(r["speedup_ideal"], 0), f(r["efficiency"], 3), f(r["predicted_cycles"], 0), "%+.2f%%" % r["error_pct"], r["in_sample"]]
                 for r in ls["rows"]]))
        w("")
    par = sca.get("parallel", {})
    if par.get("masters"):
        w(table(["placement", "masters", "txn/cycle", "efficiency vs ideal"], [[r["placement"], r["masters"], f(r["throughput_txn_per_cycle"], 3), f(r["efficiency"], 3)] for r in par["masters"]]))
        w("")
    if par.get("banks"):
        w(table(["banks", "random-traffic txn/cycle (4 masters)", "ideal ports", "efficiency"], [[r["banks"], f(r["throughput_txn_per_cycle"], 3), r["ideal_ports"], f(r["efficiency_vs_ideal"], 3)] for r in par["banks"]]))
        w("")
    if (pathlib.Path(path).parent / "dma_host_latency.svg").exists():
        w("![DMA vs host latency](dma_host_latency.svg)")
        w("")
    # ---------------------------------------------------------------- energy
    en = doc["energy"]
    w("## 7. Energy analysis (ESTIMATES - not measured)")
    w("")
    w(f"> **{en['label']}**")
    w("")
    w(f"**Measured power: none** - {en['measured_power_unavailable_reason']}. Three strictly separated layers: (1) *activity counts* - exact event counts from RTL simulation; "
      f"(2) *library estimate* - counts × per-event energies from `{en['library']['name']}` ({en['library']['evidence_class']}); (3) *measured power* - null. "
      "Simulated switching activity is **never** presented as silicon energy.")
    w("")
    w(f"Library: {en['library']['process_note']} Source: {en['library']['primary_source']} Uncertainty band: ×{en['library']['uncertainty_band']['low_factor']} / ×{en['library']['uncertainty_band']['high_factor']} "
      "(not a confidence interval).")
    w("")
    w("**Attribution note.** An estimate covers *all* activity in the measured window, including background masters (`host_port_latency`, `concurrent_dma_interference`); "
      "`pJ/byte` and `pJ/op` divide that total by the *foreground* bytes/ops, so points with background traffic show higher per-byte values by construction.")
    w("")
    w("Excluded from every estimate: " + "; ".join(en["library"]["excluded"]) + ".")
    w("")
    w(table(["event", "nominal pJ", "confidence", "derivation"], [[k, v["nominal"], v["confidence"], esc(v["derivation"])] for k, v in en["events_pJ"].items()], ["---", "---:", "---", "---"]))
    w("")
    sel = [r for r in recs if r.get("energy") and r["sweep"] in (None, "mem_width", "lanes", "tensor_shape", "size") and r["label"] not in ()][:60]
    w("Estimated dynamic energy per point (**ESTIMATE**, low–nominal–high band; activity counts in results.json → `energy.activity_counts`):")
    w("")
    w(table(["point", "ESTIMATE nominal nJ", "band nJ (×0.5 … ×2)", "pJ/byte", "pJ/op", "avg dynamic mW @ assumed clock (ESTIMATE)"],
            [[esc(r["id"]), f(r["energy"]["total_nJ"], 3), f(r["energy"]["dynamic_pJ"]["low"] / 1000, 3) + " … " + f(r["energy"]["dynamic_pJ"]["high"] / 1000, 3),
              f(r["energy"]["energy_per_byte_pJ"], 2), f(r["energy"]["energy_per_op_pJ"], 2), f(r["energy"]["avg_dynamic_power_mW_at_assumed_clock"], 3)] for r in sel]))
    w("")
    # ---------------------------------------------------------------- config
    w("## 8. Experiment configuration and what each knob really varies")
    w("")
    from . import config as cfgmod
    w(table(["knob", "realisation", "values in this run", "note"],
            [[k, v["realisation"], esc(_values_run(recs, k, doc)), esc(v["note"])] for k, v in cfgmod.KNOBS.items()], ["---", "---", "---", "---"]))
    w("")
    w("`rtl` = a real Verilog parameter (separate Verilator build per value); `workload` = stimulus property; `assumption` = scales derived numbers only; `model_only` = not realisable in the RTL.")
    w("")
    w("## 9. Method, checks and known limitations")
    w("")
    inst = [r for r in recs if r["status"] == "FAIL_INSTRUMENTATION"]
    w(f"* **Correctness**: every point verifies data against a shadow memory / independent reference; {S['by_status'].get('OK', 0)} of {S['points']} points passed all checks"
      + (f"; **{len(inst)} point(s) flagged FAIL_INSTRUMENTATION**." if inst else "."))
    w("* **Instrumentation cross-check**: a passive port monitor (independent of the traffic generators) is compared with the fabric's own event outputs (transactions, stalls, bank conflicts, bank accepts) and the DMA_CYCLES register on every fabric point.")
    w("* **Determinism / no X-dependence**: deterministic workloads are run with several seeds, each randomising the power-up state; identical cycle, stall and conflict counts are required.")
    w("* **Calibration against independent data**: the harness reproduces P90's published DMA_CYCLES values and its PING round trip (384 cycles) exactly, and ComputeWorks' published GEMM/vector tables (see docs/METHODOLOGY.md).")
    w("* **Known model limitations**: (1) same-bank DMA copy mean beat latency ignores the first ~4 uncontended warm-up beats (visible below ~64 words); (2) dual-port compute configurations are not modelled; "
      "(3) the Monte-Carlo model covers uniform random traffic only; (4) the transaction-latency model for host commands takes the firmware instruction count from RTL telemetry as an input; "
      "(5) GEMM shapes whose tiles are not array-aligned: array-busy cycles and words written are predicted exactly, but words read are approximate and the per-block compute/load constants differ slightly "
      "for partial blocks, so Model C's cycle error is larger there (see the blind-validation rows above).")
    w("* **Not covered**: ComputeWorks is benchmarked standalone, not through the Albion SoC; the HostBridge (Module 96) host interface and AlbionCore ALP reference subsystem are separate integration lines not benchmarked here; "
      "PCIe link behaviour does not exist in the RTL; multi-tile, NoC and HBM paths are out of scope.")
    w("")
    w("## 10. Reproduce")
    w("")
    w("```bash\ncd benchmarks/albion\npython3 -m albionbench env                       # tool check\npython3 -m albionbench run --config " + cfgp["name"] +
      " --out results/" + cfgp["name"] + "\npython3 -m albionbench regress --baseline baselines/standard.json --candidate results/" + cfgp["name"] + "/results.json\n```")
    w("")
    pathlib.Path(path).write_text("\n".join(L) + "\n")


def _values_run(recs, knob, doc):
    cfg = doc["provenance"]["configuration"]["hardware"]
    if knob == "clock_mhz":
        return str(doc["provenance"]["clock_assumptions"]["target_mhz"]) + " MHz (assumed)"
    key = {"vector_length": None, "tensor_shape": None}.get(knob, knob)
    if knob == "dma_burst_bytes":
        vals = sorted({r["params"]["length"] for r in recs if r["workload"] == "dma_bandwidth"})
        return ", ".join(map(str, vals))
    if knob == "concurrent_masters":
        vals = sorted({r["params"].get("masters", r["params"].get("background", 0) + 1) for r in recs if "masters" in r["params"] or "background" in r["params"]})
        return ", ".join(map(str, vals))
    if knob == "tensor_shape":
        return ", ".join(sorted({"x".join(map(str, r["params"]["shape"])) for r in recs if "shape" in r["params"]}, key=len))[:120] + " ..."
    if knob == "vector_length":
        return ", ".join(map(str, sorted({r["params"]["vl"] for r in recs if "vl" in r["params"]})))
    vals = sorted({json.dumps(r["hardware"].get(knob)) for r in recs}, key=lambda x: (len(x), x))
    return ", ".join(vals) if vals else str(cfg.get(knob))
