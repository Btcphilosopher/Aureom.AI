"""Detector validation: prove the regression gate FIRES on real RTL regressions and stays silent on a behaviour-neutral change.

For every variant of kind 'regression-mutant' (and the 'control'): build the mutated RTL, run the A/B suite against the unmodified baseline with the same
seeds, run regress.compare, and require
    mutants : every expected category is raised (at least one failing point per expected category) and the verdict is FAIL
    control : zero findings of any severity (no false positive)
A framework whose gate has never been shown to fail proves nothing; this is that demonstration.
"""
import json
import pathlib

from . import abtest, paths, regress, variants
from . import config as cfgmod


def run(backends=("fabric",), config="ab", only=None, say=print, jobs=None):
    cfg = cfgmod.load(config)
    root = paths.RTL_UNDER_TEST / "albion_soc"
    say("[detectors] baseline run on the unmodified RTL")
    base = abtest.run_side(cfg, root, backends, jobs, "baseline", say)
    out = []
    for name, v in variants.list_variants().items():
        if v["kind"] not in ("regression-mutant", "control") or (only and name not in only):
            continue
        say(f"[detectors] variant {name}")
        dest, info = variants.materialize(name)
        cand = abtest.run_side(cfg, dest, backends, jobs, name, say)
        cmp_doc = regress.compare(base, cand, cfg["thresholds"])
        cats = cmp_doc["summary"]["by_category"]
        fails = {f["category"] for f in cmp_doc["findings"] if f["severity"] == "FAIL"}
        exp = set(v["expected_categories"])
        if v["kind"] == "control":
            ok = not cmp_doc["findings"]
        else:
            ok = exp <= fails and cmp_doc["summary"]["verdict"] == "FAIL"
        examples = [f"{f['id']}: {f['message']}" for f in cmp_doc["findings"] if f["severity"] == "FAIL"][:3]
        out.append({"variant": name, "kind": v["kind"], "description": v["description"], "expected": sorted(exp), "raised_fail_categories": sorted(fails),
                    "all_categories": cats, "verdict": cmp_doc["summary"]["verdict"], "detected_as_expected": ok, "examples": examples,
                    "variant_tree_sha256": info["tree_sha256"]})
        say(f"  -> {name}: expected {sorted(exp)} raised {sorted(fails)}  {'OK' if ok else 'MISSED'}")
    return {"suite": config, "backends": list(backends), "results": out, "all_detected": all(r["detected_as_expected"] for r in out)}


def render(doc):
    L = ["# AlbionBench detector validation", "",
         f"Suite `{doc['suite']}`, backends {doc['backends']}. **{'ALL regressions detected as expected; control produced no findings.' if doc['all_detected'] else 'A DETECTOR MISSED - see below.'}**", "",
         "| variant | kind | expected | raised (FAIL) | verdict | detected as expected |", "|---|---|---|---|---|---|"]
    for r in doc["results"]:
        L.append(f"| `{r['variant']}` | {r['kind']} | {', '.join(r['expected']) or '(none)'} | {', '.join(r['raised_fail_categories']) or '(none)'} | {r['verdict']} | "
                 f"{'yes' if r['detected_as_expected'] else '**NO**'} |")
    L += ["", "## Evidence per variant", ""]
    for r in doc["results"]:
        L += [f"### `{r['variant']}`", "", r["description"], "", f"All categories raised: `{json.dumps(r['all_categories'])}`", ""]
        for e in r["examples"]:
            L.append(f"* {e}")
        L.append("")
    return "\n".join(L) + "\n"


def cli(a):
    toolchain_check()
    doc = run(backends=tuple(a.backends.split(",")), config=a.config, only=a.only.split(",") if a.only else None, jobs=a.jobs)
    out = pathlib.Path(a.out or paths.RESULTS / "detector_validation")
    out.mkdir(parents=True, exist_ok=True)
    (out / "detector_validation.json").write_text(json.dumps(doc, indent=1))
    (out / "detector_validation.md").write_text(render(doc))
    print("detectors:", "ALL DETECTED" if doc["all_detected"] else "MISSED", "->", out / "detector_validation.md")
    return 0 if doc["all_detected"] else 1


def toolchain_check():
    from . import toolchain
    toolchain.require_verilator()
