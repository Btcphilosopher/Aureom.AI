"""Suite execution: build simulators, run every (point, seed) in parallel, aggregate, check determinism."""
import concurrent.futures as cf
import copy
import pathlib
import time
import traceback

from . import config as cfgmod
from . import metrics as M
from . import paths, scenarios, toolchain, workloads
from .backends import fabric as fab

STATUS_ORDER = ["OK", "FAIL_INSTRUMENTATION", "FAIL_CORRECTNESS", "ERROR", "DEADLOCK"]   # worse to the right
NUMERIC = [k for k in M.METRIC_KEYS]


class Context:
    def __init__(self, rtl_roots=None, workers=None, progress=None, verbose=True):
        self.soc_root = pathlib.Path((rtl_roots or {}).get("albion_soc", paths.RTL_UNDER_TEST / "albion_soc"))
        self.cw_root = pathlib.Path((rtl_roots or {}).get("computeworks", paths.RTL_UNDER_TEST / "computeworks"))
        self.workers = workers or max(1, min(4, (toolchain.os.cpu_count() or 2)))
        self.builds = {}          # key -> build info (recorded in provenance.simulator.binaries)
        self.progress = progress or (lambda msg: None)
        self.verbose = verbose
        self.extra = {}           # backend-specific provenance (firmware hash, feature probe, ...)

    def note_build(self, info):
        self.builds[f"{info['kind']}:{info['key']}"] = info


def worst(statuses):
    return max(statuses, key=lambda s: STATUS_ORDER.index(s) if s in STATUS_ORDER else len(STATUS_ORDER))


def aggregate(per_seed):
    """Mean of numeric metrics over seeds (None if any seed lacks it)."""
    out = {}
    for k in NUMERIC:
        vals = [r["metrics"].get(k) for r in per_seed]
        if any(v is None for v in vals):
            out[k] = None
        else:
            m = sum(vals) / len(vals)
            out[k] = int(m) if all(isinstance(v, int) for v in vals) and all(v == vals[0] for v in vals) else m
    return out


def make_record(pt, status, metrics, detail, per_seed, cfg, notes=None, deterministic=True, backend=None):
    from .metrics import at_clock
    w = workloads.REGISTRY[pt["workload"]]
    rec = {
        "id": f"{pt['workload']}|{pt['label']}", "workload": pt["workload"], "label": pt["label"], "sweep": pt.get("sweep"),
        "group": w.group, "backend": backend or w.backend, "status": status, "params": pt["params"], "hardware": pt["hw"],
        "metrics": metrics, "metrics_at_assumed_clock": at_clock(metrics, cfg["clock"]["target_mhz"]) if metrics.get("clock_cycles") else {},
        "detail": detail, "per_seed": [{"seed": s["seed"], "status": s["status"], "metrics": s["metrics"]} for s in per_seed],
        "seed_variation": M.stats_of([s["metrics"].get("clock_cycles") for s in per_seed]),
        "deterministic_workload": deterministic, "notes": notes or [],
    }
    return rec


# ------------------------------------------------------------------------------------------------ fabric
def _fabric_binary(ctx, hw, cache):
    key = (hw["sram_banks"], hw["bank_bytes"], hw["dma_depth"])
    if key not in cache:
        binp, info = toolchain.build_fabric(ctx.soc_root, hw["sram_banks"], hw["bank_bytes"], hw["dma_depth"])
        ctx.note_build(info)
        cache[key] = (binp, info)
    return cache[key]


def run_fabric_point(pt, cfg, seeds, ctx, binp):
    w = workloads.REGISTRY[pt["workload"]]
    hw, p = pt["hw"], pt["params"]
    try:
        sc = scenarios.build(pt["workload"], hw, p)
    except ValueError as e:
        return make_record(pt, "ERROR", {k: None for k in M.METRIC_KEYS}, {"error": str(e)}, [], cfg)
    per_seed, details = [], []
    for s in seeds:
        raw = fab.run_raw(binp, sc, s, sc["hmlat"], sc["maxcyc"])
        status, m, det = fab.normalise(raw, w.kind)
        det["derived"] = scenarios.derive(pt["workload"], raw, hw, p)
        if status == "OK" and det.get("instrumentation_mismatches"):
            status = "FAIL_INSTRUMENTATION"
        per_seed.append({"seed": s, "status": status, "metrics": m})
        details.append(det)
    status = worst([s["status"] for s in per_seed])
    notes = []
    if w.deterministic and len(per_seed) > 1 and status == "OK":
        sig = {(s["metrics"]["clock_cycles"], s["metrics"]["completed_ops"], s["metrics"]["stall_cycles"], s["metrics"]["memory_conflicts"])
               for s in per_seed}
        if len(sig) > 1:
            status = "FAIL_INSTRUMENTATION"
            notes.append(f"NONDETERMINISM: a deterministic workload gave different counters for different seeds: {sorted(sig)}")
    metrics = aggregate(per_seed)
    det = details[0] if details else {}
    det["scenario"] = {k: sc[k] for k in ("workload", "streams", "dma", "hmlat")}
    det["harness_command"] = fab_cmd(binp, sc, seeds[0] if seeds else 1)
    return make_record(pt, status, metrics, det, per_seed, cfg, notes, w.deterministic)


def fab_cmd(binp, sc, seed):
    c = [pathlib.Path(binp).name, f"--workload={sc['workload']}", f"--seed={seed}", f"--hmlat={sc['hmlat']}"]
    for s in sc.get("streams", []):
        c += ["--stream", f'"{s}"']
    if sc.get("dma"):
        c += ["--dma", f'"{sc["dma"]}"']
    return " ".join(c)


# ------------------------------------------------------------------------------------------------ dispatch
def execute(cfg, ctx, only_backends=None, point_filter=None):
    """Run the configured suite.  Returns (records, unavailable, errors)."""
    pts = workloads.suite_points(cfg)
    if point_filter:
        pts = [p for p in pts if point_filter(p)]
    seeds = cfg["seeds"]
    records, errors = [], []
    t0 = time.time()
    by_backend = {}
    for p in pts:
        be = workloads.REGISTRY[p["workload"]].backend
        if only_backends and be not in only_backends:
            continue
        by_backend.setdefault(be, []).append(p)

    # ---- fabric: build everything first (builds are CPU heavy), then run points in parallel
    if "fabric" in by_backend:
        cache = {}
        need = sorted({(p["hw"]["sram_banks"], p["hw"]["bank_bytes"], p["hw"]["dma_depth"]) for p in by_backend["fabric"]})
        ctx.progress(f"[fabric] building {len(need)} simulator configuration(s)")
        for nb, bb, dd in need:
            _fabric_binary(ctx, {"sram_banks": nb, "bank_bytes": bb, "dma_depth": dd}, cache)
        ctx.progress(f"[fabric] running {len(by_backend['fabric'])} points x {len(seeds)} seeds")
        done = [0]

        def job(pt):
            binp, _info = _fabric_binary(ctx, pt["hw"], cache)
            try:
                return run_fabric_point(pt, cfg, seeds, ctx, binp)
            except Exception:
                return make_record(pt, "ERROR", {k: None for k in M.METRIC_KEYS}, {"error": traceback.format_exc()}, [], cfg)

        with cf.ThreadPoolExecutor(max_workers=ctx.workers) as ex:
            futs = {ex.submit(job, p): p for p in by_backend["fabric"]}
            for f in cf.as_completed(futs):
                rec = f.result()
                records.append(rec)
                done[0] += 1
                if ctx.verbose and (done[0] % 20 == 0 or rec["status"] != "OK"):
                    ctx.progress(f"  [{done[0]}/{len(by_backend['fabric'])}] {rec['id']}: {rec['status']}")

    # ---- compute
    if "compute" in by_backend:
        from .backends import compute
        ctx.progress(f"[compute] {len(by_backend['compute'])} points")
        for rec in compute.run_points(by_backend["compute"], cfg, ctx):
            records.append(rec)
            if rec["status"] != "OK":
                ctx.progress(f"  {rec['id']}: {rec['status']}")

    # ---- soc
    if "soc" in by_backend:
        from .backends import soc
        ctx.progress(f"[soc] {len(by_backend['soc'])} points")
        for rec in soc.run_points(by_backend["soc"], cfg, ctx):
            records.append(rec)
            if rec["status"] != "OK":
                ctx.progress(f"  {rec['id']}: {rec['status']}")

    order = {p["workload"] + "|" + p["label"]: i for i, p in enumerate(pts)}
    records.sort(key=lambda r: order.get(r["id"], 1 << 30))
    ctx.progress(f"suite finished in {time.time() - t0:.0f}s: {len(records)} points")
    return records
