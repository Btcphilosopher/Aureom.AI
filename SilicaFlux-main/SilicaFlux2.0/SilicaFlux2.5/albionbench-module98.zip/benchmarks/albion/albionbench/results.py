"""Result document assembly and serialisation (results.json, results.csv)."""
import csv
import json

from . import RESULT_SCHEMA, metrics as M
from . import provenance, workloads

HW_COLUMNS = ["sram_banks", "bank_bytes", "dma_depth", "bus_width_bits", "dma_burst_bytes", "concurrent_masters", "host_latency_cycles",
              "vector_lanes", "tensor_array", "compute_ports", "compute_mem_width_bits"]


def unavailable_records(ctx):
    probe = ctx.extra.get("feature_probe") or {}
    feats = (probe.get("features") or {})
    ops = (probe.get("opcode_probes") or {})
    link = {"packet_throughput": ("PACKETFORGE", "PKT_CLASSIFY"), "virtual_block_io": ("VIRTUALFOUNDRY", "VBLK_IO"),
            "albion_integrated_matmul": ("COMPUTEWORKS", "MATMUL_INT8")}
    out = []
    for wid, w in workloads.UNAVAILABLE.items():
        rec = {"id": wid, "workload": wid, "title": w["title"], "status": "UNAVAILABLE", "needs": w["needs"], "evidence": w["evidence"], "probe": None,
               "metrics": None}
        if wid in link and feats:
            f, o = link[wid]
            rec["probe"] = {"feature": f, **feats.get(f, {}), "opcode": o, "firmware_completion_status": (ops.get(o) or {}).get("completion_status"),
                            "source": "live RTL: MGMT.FEAT_* registers and mailbox command on a CONFIG=2 build of sf_albion_cloud_top"}
            rec["probe_confirms_unavailable"] = (not feats.get(f, {}).get("implemented", True)) and (ops.get(o) or {}).get("completion_status") == "UNSUPPORTED"
        elif wid in link:
            rec["probe"] = {"error": probe.get("error", "probe did not run")}
            rec["probe_confirms_unavailable"] = None
        out.append(rec)
    return out


def summary(records):
    by = {}
    for r in records:
        by[r["status"]] = by.get(r["status"], 0) + 1
    groups = {}
    for r in records:
        g = groups.setdefault(r["group"], {"points": 0, "ok": 0})
        g["points"] += 1
        g["ok"] += r["status"] == "OK"
    return {"points": len(records), "by_status": by, "by_group": groups,
            "all_correct": all(r["status"] in ("OK",) for r in records)}


def assemble(cfg, ctx, records, seeds, extra=None):
    wl_ids = sorted({r["workload"] for r in records})
    wl = []
    for i in wl_ids:
        d = workloads.REGISTRY[i].describe()
        d["points"] = [{"label": r["label"], "sweep": r["sweep"], "params": r["params"], "hardware_varied": r["hardware"]} for r in records if r["workload"] == i]
        wl.append(d)
    unav = unavailable_records(ctx)
    prov = provenance.build(cfg, ctx.builds, {"executed": wl, "declared_unavailable": [u["id"] for u in unav]}, seeds,
                            extra={"backend_provenance": ctx.extra})
    provenance.validate(prov)
    doc = {"schema": RESULT_SCHEMA, "provenance": prov, "summary": summary(records), "points": records, "unavailable": unav}
    if extra:
        doc.update(extra)
    return doc


def write_json(doc, path):
    with open(path, "w") as f:
        json.dump(doc, f, indent=1, default=str)
        f.write("\n")


def write_csv(doc, path):
    cols = (["id", "workload", "label", "sweep", "group", "backend", "status"] + ["hw_" + c for c in HW_COLUMNS] + ["params"] + M.METRIC_KEYS +
            ["memory_bandwidth_MB_per_s_at_assumed_clock", "latency_avg_ns_at_assumed_clock", "latency_p99_ns_at_assumed_clock", "clock_mhz_assumed",
             "energy_estimate_nJ", "energy_label", "predicted_cycles", "cycles_error_pct", "model", "provenance_git_head", "provenance_config_sha256"])
    prov = doc["provenance"]
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for r in doc["points"]:
            hw, m, c = r["hardware"], r["metrics"], r.get("metrics_at_assumed_clock") or {}
            en = (r.get("energy") or {})
            pred = (r.get("model_prediction") or {})
            row = [r["id"], r["workload"], r["label"], r.get("sweep") or "", r["group"], r["backend"], r["status"]]
            row += [json.dumps(hw.get(c_)) if isinstance(hw.get(c_), list) else hw.get(c_, "") for c_ in HW_COLUMNS]
            row += [json.dumps(r["params"], sort_keys=True)]
            row += ["" if m.get(k) is None else m[k] for k in M.METRIC_KEYS]
            row += [c.get("memory_bandwidth_MB_per_s", ""), c.get("latency_avg_ns", ""), c.get("latency_p99_ns", ""), c.get("clock_mhz_assumed", "")]
            row += [en.get("total_nJ", ""), en.get("label", ""), pred.get("clock_cycles", ""), pred.get("clock_cycles_error_pct", ""), pred.get("model", "")]
            row += [prov["source_revision"].get("git_head", ""), prov["configuration_sha256"]]
            w.writerow(row)


def slim(doc):
    """Compact golden-baseline form: everything the regression gate and A/B tool need, none of the bulk (per-seed arrays, histograms, raw streams)."""
    keep_detail = ("derived", "correctness_issues", "instrumentation_mismatches", "error", "deadlock_diag")
    pts = []
    for r in doc["points"]:
        d = r.get("detail") or {}
        pts.append({"id": r["id"], "workload": r["workload"], "label": r["label"], "sweep": r["sweep"], "group": r["group"], "backend": r["backend"],
                    "status": r["status"], "params": r["params"], "hardware": r["hardware"], "metrics": r["metrics"], "notes": r.get("notes", []),
                    "detail": {k: d[k] for k in keep_detail if k in d}, "energy": {k: (r.get("energy") or {}).get(k) for k in ("total_nJ", "energy_per_byte_pJ", "energy_per_op_pJ")}})
    return {"schema": doc["schema"] + "+baseline", "provenance": doc["provenance"], "summary": doc["summary"], "points": pts,
            "unavailable": doc.get("unavailable", []), "note": "golden baseline: regenerate with `albionbench baseline` after an intentional, reviewed performance change"}
