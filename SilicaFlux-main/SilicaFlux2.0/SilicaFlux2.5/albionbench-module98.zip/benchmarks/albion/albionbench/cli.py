"""Command line: albionbench run | report | regress | ab | list | env | vendor."""
import argparse
import json
import pathlib
import sys
import time

from . import config as cfgmod
from . import paths, results, runner, toolchain, workloads


def _ctx(a):
    roots = {}
    if getattr(a, "rtl_soc", None):
        roots["albion_soc"] = a.rtl_soc
    if getattr(a, "rtl_cw", None):
        roots["computeworks"] = a.rtl_cw
    return runner.Context(rtl_roots=roots or None, workers=getattr(a, "jobs", None), progress=lambda m: print(m, flush=True))


def cmd_env(a):
    v = toolchain.tool_versions()
    ok = bool(v["verilator"]) and bool(v["g++"])
    for k, val in v.items():
        print(f"  {k:10s} {val}")
    print("fabric + compute backends:", "READY" if ok else "MISSING verilator/g++")
    print("soc backend (firmware):", "READY" if v["clang"] and v["ld.lld"] else "needs clang + ld.lld")
    return 0 if ok else 1


def cmd_list(a):
    cfg = cfgmod.load(a.config)
    print(f"{'workload':30s} {'group':12s} {'backend':8s} points  headline metric")
    pts = workloads.suite_points(cfg)
    for w in workloads.REGISTRY.values():
        n = sum(1 for p in pts if p["workload"] == w.id)
        print(f"{w.id:30s} {w.group:12s} {w.backend:8s} {n:5d}   {w.headline}")
    print("\nDeclared UNAVAILABLE (absent hardware):")
    for k, v in workloads.UNAVAILABLE.items():
        print(f"  {k:36s} needs {v['needs']}")
    print("\nConfiguration knobs (realisation):")
    for k, v in cfgmod.KNOBS.items():
        print(f"  {k:24s} {v['realisation']:10s} {v['note'][:100]}")
    return 0


def cmd_run(a):
    from . import analysis
    cfg = cfgmod.load(a.config)
    if a.seeds:
        cfg["seeds"] = [int(x) for x in a.seeds.split(",")]
    if a.clock_mhz:
        cfg["clock"]["target_mhz"] = float(a.clock_mhz)
    if a.workloads:
        cfg["workloads"]["include"] = a.workloads.split(",")
    ctx = _ctx(a)
    toolchain.require_verilator()
    t0 = time.time()
    records = runner.execute(cfg, ctx, only_backends=set(a.backends.split(",")) if a.backends else None)
    doc = results.assemble(cfg, ctx, records, cfg["seeds"])
    analysis.attach(doc, cfg)
    out = pathlib.Path(a.out or paths.RESULTS / cfg["name"])
    out.mkdir(parents=True, exist_ok=True)
    results.write_json(doc, out / "results.json")
    results.write_csv(doc, out / "results.csv")
    from . import report
    report.write_markdown(doc, out / "benchmark_report.md")
    report.write_charts(doc, out)
    print(f"\nwrote {out}/results.json results.csv benchmark_report.md  ({time.time() - t0:.0f}s)")
    s = doc["summary"]
    print(f"points={s['points']} status={s['by_status']}")
    return 0 if s["all_correct"] else 3


def cmd_report(a):
    from . import analysis, report
    doc = json.loads(pathlib.Path(a.results).read_text())
    out = pathlib.Path(a.out or pathlib.Path(a.results).parent)
    report.write_markdown(doc, out / "benchmark_report.md")
    report.write_charts(doc, out)
    print("wrote", out / "benchmark_report.md")
    return 0


def cmd_regress(a):
    from . import regress
    return regress.cli(a)


def cmd_ab(a):
    from . import abtest
    return abtest.cli(a)


def cmd_baseline(a):
    doc = json.loads(pathlib.Path(a.results).read_text())
    out = pathlib.Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results.slim(doc), indent=0, default=str))
    print(f"wrote golden baseline {out} ({out.stat().st_size // 1024} KiB, {len(doc['points'])} points)")
    return 0


def cmd_variants(a):
    from . import variants
    for n, v in variants.list_variants().items():
        print(f"{n:32s} {v['kind']:26s} {v['description'][:90]}")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="albionbench", description="AlbionBench: SilicaFlux performance and energy benchmarking (Module 98)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("env", help="show tool versions and backend readiness")
    p.set_defaults(fn=cmd_env)
    p = sub.add_parser("list", help="list workloads, absent hardware and configuration knobs")
    p.add_argument("--config", default="standard")
    p.set_defaults(fn=cmd_list)
    p = sub.add_parser("run", help="run a suite and write results.json / results.csv / benchmark_report.md")
    p.add_argument("--config", default="standard")
    p.add_argument("--out")
    p.add_argument("--seeds")
    p.add_argument("--clock-mhz")
    p.add_argument("--backends", help="comma list of fabric,soc,compute")
    p.add_argument("--workloads", help="comma list / globs of workload ids")
    p.add_argument("--rtl-soc", help="use a different Albion SoC RTL tree (default: vendored snapshot)")
    p.add_argument("--rtl-cw", help="use a different ComputeWorks RTL tree")
    p.add_argument("-j", "--jobs", type=int)
    p.set_defaults(fn=cmd_run)
    p = sub.add_parser("report", help="regenerate benchmark_report.md from a results.json")
    p.add_argument("results")
    p.add_argument("--out")
    p.set_defaults(fn=cmd_report)
    p = sub.add_parser("regress", help="compare a candidate results.json against a baseline and flag regressions")
    p.add_argument("--baseline", required=True)
    p.add_argument("--candidate", required=True)
    p.add_argument("--config", default="standard")
    p.add_argument("--out")
    p.add_argument("--strict-set", action="store_true", help="also fail when points are missing from the candidate")
    p.set_defaults(fn=cmd_regress)
    p = sub.add_parser("ab", help="A/B: benchmark two RTL trees (or a variant patch) and report whether the change improved performance")
    p.add_argument("--config", default="smoke")
    p.add_argument("--baseline-rtl", help="baseline Albion SoC RTL tree (default: vendored snapshot)")
    p.add_argument("--candidate-rtl", help="candidate Albion SoC RTL tree")
    p.add_argument("--variant", help="name of a patch set in variants/ applied to the vendored RTL to form the candidate")
    p.add_argument("--reverse", action="store_true", help="treat the variant as the BASELINE (to show what a fix improved)")
    p.add_argument("--baseline-hw", help="hardware overrides for the baseline side, e.g. dma_depth=4,sram_banks=4")
    p.add_argument("--candidate-hw", help="hardware overrides for the candidate side, e.g. dma_depth=3")
    p.add_argument("--backends", default="fabric,soc")
    p.add_argument("--out")
    p.add_argument("-j", "--jobs", type=int)
    p.set_defaults(fn=cmd_ab)
    p = sub.add_parser("validate-detectors", help="mutate the RTL and prove the regression gate fires (and stays silent on a neutral change)")
    p.add_argument("--config", default="ab")
    p.add_argument("--backends", default="fabric")
    p.add_argument("--only", help="comma list of variant names")
    p.add_argument("--out")
    p.add_argument("-j", "--jobs", type=int)
    p.set_defaults(fn=lambda a: __import__("albionbench.detectors", fromlist=["cli"]).cli(a))
    p = sub.add_parser("baseline", help="write a slim golden baseline from a results.json (for the regression gate)")
    p.add_argument("results")
    p.add_argument("--out", default=str(paths.BASELINES / "standard.json"))
    p.set_defaults(fn=cmd_baseline)
    p = sub.add_parser("variants", help="list RTL variants")
    p.set_defaults(fn=cmd_variants)
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
