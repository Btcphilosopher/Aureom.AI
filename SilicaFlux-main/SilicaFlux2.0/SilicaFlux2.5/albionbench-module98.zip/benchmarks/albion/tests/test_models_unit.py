"""Model unit tests: formulas are checked against numbers that come from OUTSIDE this framework (P90's and ComputeWorks' published reports)."""
import math

import pytest

from albionbench.models import accel, fitting, membw


def test_lstsq_recovers_exact_line():
    c = fitting.lstsq([[1, x] for x in (1, 2, 3, 4)], [3, 5, 7, 9])
    assert c == pytest.approx([1.0, 2.0])


def test_solve_rejects_singular():
    with pytest.raises(ValueError):
        fitting.solve([[1, 2], [2, 4]], [1, 2])


def test_hockney_fit():
    T0, r, nh = fitting.hockney([10, 100, 1000], [10 + n / 4 for n in (10, 100, 1000)])
    assert T0 == pytest.approx(10) and r == pytest.approx(4) and nh == pytest.approx(40)


# P90 performance_report.md - DMA_CYCLES register values (published, independent harness).  window = register + 1.
@pytest.mark.parametrize("mode,nwords,L,expected_reg", [
    ("fill", 2048, 1, 2050), ("copy_xbank", 2048, 1, 2052), ("copy_samebank", 2048, 1, 4098),
    ("host_to_sram", 1024, 1, 1028), ("host_to_sram", 1024, 4, 4100), ("host_to_sram", 1024, 16, 16388), ("host_to_sram", 1024, 64, 65540),
    ("sram_to_host", 1024, 1, 1028), ("sram_to_host", 1024, 4, 4100),
])
def test_dma_window_matches_published_p90_figures(mode, nwords, L, expected_reg):
    assert membw.dma_window(mode, nwords, L, depth=4) == expected_reg + 1


def test_dma_depth_little_law():
    assert membw.dma_period("copy_xbank", 1, 1) == 3.0 and membw.dma_period("copy_xbank", 1, 2) == 1.5 and membw.dma_period("copy_xbank", 1, 3) == 1.0
    assert membw.dma_period("host_to_sram", 4, 1) == 6.0 and membw.dma_period("host_to_sram", 4, 2) == 4.0


def test_stream_and_conflict_formulas():
    class R(dict):
        pass
    rec = {"workload": "sram_bank_conflict", "hardware": {"sram_banks": 4, "dma_depth": 4, "host_latency_cycles": 1},
           "params": {"masters": 4, "placement": "same", "nwords": 1024}}
    p = membw.predict(rec)["predictions"]
    assert p["clock_cycles"] == 4097 and p["memory_conflicts"] == 4095 and p["stall_cycles"] == 12282


def test_mc_random_is_sane():
    one = membw.mc_random([[0, 1, 2, 3]], 2000)
    assert one["cycles"] == pytest.approx(2001, abs=2)                       # a single master never conflicts
    four = membw.mc_random([[0, 1, 2, 3]] * 4, 2000)
    thr = 4 * 2000 / four["cycles"]
    assert 2.0 < thr < 3.4                                                    # well below 4 (collisions) and above 2


# ComputeWorks 06_PERFORMANCE.md: 16x16x64 on a 4x4 array -> array busy 1168; words read 1152, written 128 (64-bit memory)
def test_gemm_geometry_matches_computeworks_published_counters():
    f = accel.gemm_features(16, 16, 64, 4, 4, 8)
    assert f["array_busy"] == 1168 and f["W_rd"] == 1152 and f["W_out"] == 128 and f["blocks"] == 16
    f = accel.gemm_features(4, 4, 4, 4, 4, 8)
    assert f["array_busy"] == 13


def test_partial_tile_array_busy_uses_actual_dimensions():
    f = accel.gemm_features(5, 7, 9, 4, 4, 8)          # blocks (4x4),(4x3),(1x4),(1x3)
    assert f["array_busy"] == (9 + 4 + 4 + 1) + (9 + 4 + 3 + 1) + (9 + 1 + 4 + 1) + (9 + 1 + 3 + 1)


def test_vector_geometry():
    f = accel.vec_features(1024, 4, 8, 256)
    assert f["chunks"] == 4 and f["W_rd"] == 1024 and f["W_wr"] == 512 and f["compute"] == 256
