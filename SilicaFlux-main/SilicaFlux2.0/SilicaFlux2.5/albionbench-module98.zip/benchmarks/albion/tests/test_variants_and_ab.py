import json
import pathlib

import pytest

from albionbench import abtest, variants


def test_every_variant_applies_exactly_once_and_changes_the_rtl():
    vs = variants.list_variants()
    assert len(vs) >= 8
    for name in vs:
        dest, info = variants.materialize(name)
        assert info["tree_sha256"] != info["base_tree_sha256"], name
        assert info["files_edited"], name


def test_variants_declare_expected_detector_categories():
    for name, v in variants.list_variants().items():
        assert v["kind"] in ("optimization", "historical-bug-reconstruction", "regression-mutant", "control")
        if v["kind"] == "regression-mutant":
            assert v["expected_categories"], name


def test_stale_variant_fails_loudly(tmp_path, monkeypatch):
    v = variants.load("control_comment_only")
    bad = dict(v)
    bad["edits"] = [dict(v["edits"][0], find="THIS TEXT IS NOT IN THE RTL")]
    monkeypatch.setattr(variants, "load", lambda n: bad)
    with pytest.raises(ValueError, match="matches 0 times"):
        variants.materialize("control_comment_only")


def _rec(i, wl, status="OK", **m):
    metrics = {"clock_cycles": 100, "memory_bandwidth_bytes_per_cycle": 4.0, "latency_avg_cycles": 1.0, "latency_p99_cycles": 1.0, "latency_max_cycles": 1.0,
               "stall_cycles": 10, "memory_conflicts": 0, "pipeline_utilization": 1.0, "compute_utilization": None, "completed_ops": 10}
    metrics.update(m)
    return {"id": i, "workload": wl, "label": i, "backend": "fabric", "status": status, "metrics": metrics, "detail": {"derived": {}}, "notes": [], "energy": {}}


def test_ab_headline_unchanged_but_fewer_stalls_is_not_an_improvement():
    """Fewer stalls / lower beat latency for the SAME completion time is not a faster design (the depth-2 DMA case)."""
    from albionbench import regress
    th = {"bandwidth_drop_pct": 0.5, "latency_increase_pct": 0.5, "tail_latency_increase_pct": 1.0, "stall_increase_pct": 1.0, "utilization_drop_pct": 1.0, "min_abs_cycles": 2}
    b = {"points": [_rec("p", "dma_bandwidth")], "unavailable": []}
    c = {"points": [_rec("p", "dma_bandwidth", stall_cycles=2, latency_avg_cycles=0.5)], "unavailable": []}
    rows = abtest.verdicts(regress.compare(b, c, th), b, c)
    assert rows[0]["verdict"] == "NO CHANGE" and rows[0]["secondary_only_improvements"]
    c2 = {"points": [_rec("p", "dma_bandwidth", memory_bandwidth_bytes_per_cycle=5.0, clock_cycles=80)], "unavailable": []}
    assert abtest.verdicts(regress.compare(b, c2, th), b, c2)[0]["verdict"] == "IMPROVED"
    c3 = {"points": [_rec("p", "dma_bandwidth", memory_bandwidth_bytes_per_cycle=2.0, clock_cycles=200)], "unavailable": []}
    assert abtest.verdicts(regress.compare(b, c3, th), b, c3)[0]["verdict"] == "REGRESSED"
    assert abtest.overall(abtest.verdicts(regress.compare(b, c3, th), b, c3))[0].startswith("REGRESSES")
