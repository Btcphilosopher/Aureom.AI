"""Mutation testing of the regression gate: deliberately break the RTL and require the gate to notice - for each failure class the brief lists."""
import pytest

from albionbench import detectors, variants

pytestmark = [pytest.mark.integration, pytest.mark.slow]

MUTANTS = [n for n, v in variants.list_variants().items() if v["kind"] in ("regression-mutant", "control")]


@pytest.fixture(scope="module")
def validation():
    return detectors.run(backends=("fabric",), config="ab", say=lambda m: None)


@pytest.mark.parametrize("name", MUTANTS)
def test_gate_detects_variant_as_expected(validation, name):
    r = next(x for x in validation["results"] if x["variant"] == name)
    assert r["detected_as_expected"], f"{name}: expected {r['expected']}, raised {r['raised_fail_categories']}, verdict {r['verdict']}"


def test_each_brief_failure_class_has_a_mutant_that_triggers_it(validation):
    raised = set()
    for r in validation["results"]:
        raised |= set(r["raised_fail_categories"])
    for cat in ("INCORRECT_RESULT", "BANDWIDTH_REGRESSION", "LATENCY_REGRESSION", "DEADLOCK", "STALL_REGRESSION"):      # the five classes in requirement 7
        assert cat in raised, cat


def test_control_variant_produces_no_findings(validation):
    r = next(x for x in validation["results"] if x["kind"] == "control")
    assert r["verdict"] == "PASS" and not r["all_categories"]
