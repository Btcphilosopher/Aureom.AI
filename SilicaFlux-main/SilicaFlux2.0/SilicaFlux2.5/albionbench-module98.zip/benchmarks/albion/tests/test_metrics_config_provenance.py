import json

import pytest

from albionbench import config, metrics, provenance, workloads


def test_jain_fairness_bounds():
    assert metrics.jain_index([5, 5, 5, 5]) == pytest.approx(1.0)
    assert metrics.jain_index([10, 0, 0, 0]) == pytest.approx(0.25)


def test_percentile_and_merge_exact_from_histograms():
    a = {"n": 4, "mean": 1.5, "min": 1, "max": 2, "p50": 1, "p90": 2, "p95": 2, "p99": 2, "p999": 2, "hist": {"1": 2, "2": 2}}
    b = {"n": 4, "mean": 5.0, "min": 5, "max": 5, "p50": 5, "p90": 5, "p95": 5, "p99": 5, "p999": 5, "hist": {"5": 4}}
    m = metrics.merge_latency([a, b])
    assert m["n"] == 8 and m["tail_exact"] and m["max"] == 5 and m["p99"] == 5 and m["mean"] == pytest.approx(3.25)


def test_clock_scaling_is_labelled_and_linear():
    m = {"memory_bandwidth_bytes_per_cycle": 4.0, "latency_avg_cycles": 2.0, "clock_cycles": 100, "transaction_throughput_per_cycle": 1.0}
    c = metrics.at_clock(m, 50.0)
    assert c["memory_bandwidth_MB_per_s"] == 200.0 and c["latency_avg_ns"] == pytest.approx(40.0) and c["clock_mhz_assumed"] == 50.0


def test_unrealisable_bus_width_is_model_only():
    assert config.check_value("bus_width_bits", 64)[0] == "model_only"
    assert config.check_value("bus_width_bits", 32)[0] == "ok"
    assert config.check_value("sram_banks", 1)[0] == "invalid"        # bank 0 is firmware-private: >= 2 banks needed
    assert config.check_value("vector_lanes", 3)[0] == "invalid"      # outside ComputeWorks' verified matrix
    with pytest.raises(ValueError):
        cfg = config.load("standard")
        cfg["hardware"]["sram_banks"] = 99
        config.validate(cfg)


def test_every_knob_declares_how_it_is_realised():
    for k, v in config.KNOBS.items():
        assert v["realisation"] in ("rtl", "workload", "assumption", "model_only"), k
    assert config.KNOBS["clock_mhz"]["realisation"] == "assumption"
    assert config.KNOBS["dma_burst_bytes"]["realisation"] == "workload"       # the DMA has no burst protocol: must not claim RTL


def test_provenance_requires_all_seven_fields():
    base = {k: {"x": 1} for k in provenance.REQUIRED}
    base["source_revision"] = {"git_head": "abc"}
    base["simulator"] = {"version": "5.020"}
    assert provenance.validate(dict(base))
    for k in provenance.REQUIRED:
        bad = dict(base)
        bad.pop(k)
        with pytest.raises(ValueError):
            provenance.validate(bad)


def test_unavailable_hardware_is_declared_with_evidence():
    ids = set(workloads.UNAVAILABLE)
    assert {"packet_throughput", "virtual_block_io", "albion_integrated_matmul", "silicon_or_fpga_power"} <= ids
    for k, v in workloads.UNAVAILABLE.items():
        assert v["evidence"] and v["needs"]


def test_suites_expand_and_have_unique_ids():
    for name in ("smoke", "standard", "ab"):
        cfg = config.load(name)
        pts = workloads.suite_points(cfg)
        ids = [p["workload"] + "|" + p["label"] for p in pts]
        assert len(ids) == len(set(ids)), f"duplicate point ids in suite {name}"
        assert len(pts) >= 10
