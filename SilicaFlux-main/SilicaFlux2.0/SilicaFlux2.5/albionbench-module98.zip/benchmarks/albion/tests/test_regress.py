"""The regression gate on synthetic documents: every category must fire for the right reason, and an unchanged result must raise nothing."""
import copy

import pytest

from albionbench import regress

TH = {"bandwidth_drop_pct": 0.5, "latency_increase_pct": 0.5, "tail_latency_increase_pct": 1.0, "stall_increase_pct": 1.0,
      "utilization_drop_pct": 1.0, "min_abs_cycles": 2}


def pt(workload="dma_bandwidth", label="x", **m):
    metrics = {"clock_cycles": 1000, "completed_ops": 256, "bytes_transferred": 1024, "memory_bandwidth_bytes_per_cycle": 1.024, "transaction_throughput_per_cycle": 0.256,
               "latency_avg_cycles": 1.0, "latency_p99_cycles": 1.0, "latency_max_cycles": 1.0, "stall_cycles": 100, "memory_conflicts": 50,
               "pipeline_utilization": 0.9, "compute_utilization": None}
    metrics.update(m)
    return {"id": f"{workload}|{label}", "workload": workload, "label": label, "backend": "fabric", "status": "OK", "metrics": metrics,
            "detail": {"derived": {}}, "notes": []}


def doc(*pts, unavailable=()):
    return {"points": list(pts), "unavailable": list(unavailable)}


def cats(res, sev="FAIL"):
    return {f["category"] for f in res["findings"] if f["severity"] == sev}


def test_identical_documents_raise_nothing():
    r = regress.compare(doc(pt()), doc(pt()), TH)
    assert r["findings"] == [] and r["summary"]["verdict"] == "PASS"


def test_bandwidth_and_cycles_regression():
    r = regress.compare(doc(pt()), doc(pt(memory_bandwidth_bytes_per_cycle=0.5, clock_cycles=2000)), TH)
    assert {"BANDWIDTH_REGRESSION", "CYCLES_REGRESSION"} <= cats(r)


def test_threshold_is_respected():
    r = regress.compare(doc(pt()), doc(pt(memory_bandwidth_bytes_per_cycle=1.024 * 0.997)), TH)      # -0.3 % < 0.5 % threshold
    assert not cats(r)
    r = regress.compare(doc(pt()), doc(pt(memory_bandwidth_bytes_per_cycle=1.024 * 0.99)), TH)       # -1 %
    assert "BANDWIDTH_REGRESSION" in cats(r)


def test_latency_tail_and_stall_regressions():
    r = regress.compare(doc(pt()), doc(pt(latency_avg_cycles=2.0, latency_p99_cycles=9.0, latency_max_cycles=99.0, stall_cycles=500)), TH)
    assert {"LATENCY_REGRESSION", "TAIL_LATENCY_REGRESSION", "STALL_REGRESSION"} <= cats(r)


def test_stall_growth_with_changed_work_is_not_compared():
    r = regress.compare(doc(pt()), doc(pt(stall_cycles=500, completed_ops=999)), TH)
    assert "STALL_REGRESSION" not in cats(r)


def test_utilisation_drop():
    r = regress.compare(doc(pt()), doc(pt(pipeline_utilization=0.5)), TH)
    assert "UTILIZATION_DROP" in cats(r)


def test_incorrect_result_and_deadlock_are_failures():
    bad = pt()
    bad["status"] = "FAIL_CORRECTNESS"
    bad["detail"] = {"correctness_issues": ["dma_mismatches=256"]}
    assert "INCORRECT_RESULT" in cats(regress.compare(doc(pt()), doc(bad), TH))
    dead = pt()
    dead["status"] = "DEADLOCK"
    dead["detail"] = {"deadlock_diag": "no progress"}
    assert "DEADLOCK" in cats(regress.compare(doc(pt()), doc(dead), TH))


def test_instrumentation_failure_is_flagged():
    bad = pt()
    bad["status"] = "FAIL_INSTRUMENTATION"
    bad["detail"] = {"instrumentation_mismatches": ["monitor txns != RTL ev_txn"]}
    assert "INSTRUMENTATION" in cats(regress.compare(doc(pt()), doc(bad), TH))


def test_starvation_bound_violation():
    b, c = pt("bus_arbitration", "s"), pt("bus_arbitration", "s")
    b["detail"] = {"derived": {"starvation_free": True, "jain_fairness": 1.0}}
    c["detail"] = {"derived": {"starvation_free": False, "max_accept_wait_cycles": 700, "starvation_bound_cycles": 3, "jain_fairness": 0.6}}
    assert "STARVATION" in cats(regress.compare(doc(b), doc(c), TH))


def test_stochastic_workloads_get_a_wider_allowance():
    b = pt("sram_random", "r")
    c = pt("sram_random", "r", memory_bandwidth_bytes_per_cycle=1.024 * 0.99)                       # -1 %: fails for deterministic, passes (x5) for random
    assert not cats(regress.compare(doc(b), doc(c), TH))
    c2 = pt("sram_random", "r", memory_bandwidth_bytes_per_cycle=1.024 * 0.90)
    assert "BANDWIDTH_REGRESSION" in cats(regress.compare(doc(b), doc(c2), TH))


def test_improvements_are_informational_not_failures():
    r = regress.compare(doc(pt()), doc(pt(memory_bandwidth_bytes_per_cycle=2.0, clock_cycles=500)), TH)
    assert not cats(r) and any(f["category"].startswith("IMPROVED") for f in r["findings"] if f["severity"] == "INFO")


def test_missing_point_only_fails_in_strict_mode():
    a, b = pt(label="a"), pt(label="b")
    assert not cats(regress.compare(doc(a, b), doc(a), TH))
    assert "MISSING_POINT" in cats(regress.compare(doc(a, b), doc(a), TH, strict_set=True))


def test_hardware_lost():
    c = pt()
    c["status"] = "ERROR"
    c["detail"] = {"error": "boom"}
    assert "HARDWARE_LOST" in cats(regress.compare(doc(pt()), doc(c), TH))
