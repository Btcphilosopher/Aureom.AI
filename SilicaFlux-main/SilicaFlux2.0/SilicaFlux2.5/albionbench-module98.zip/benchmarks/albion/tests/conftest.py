import pathlib
import sys

import pytest

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def pytest_configure(config):
    config.addinivalue_line("markers", "integration: needs Verilator (runs real RTL simulation)")
    config.addinivalue_line("markers", "slow: runs many simulations (minutes)")


@pytest.fixture(scope="session")
def smoke_doc():
    """One real smoke run through the whole pipeline (fabric + soc + compute), shared by the integration tests."""
    from albionbench import analysis, config, results, runner
    cfg = config.load("smoke")
    ctx = runner.Context(progress=lambda m: None)
    recs = runner.execute(cfg, ctx)
    doc = results.assemble(cfg, ctx, recs, cfg["seeds"])
    analysis.attach(doc, cfg)
    return doc
