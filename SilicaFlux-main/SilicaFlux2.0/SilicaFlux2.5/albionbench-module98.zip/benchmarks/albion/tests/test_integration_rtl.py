"""Integration tests: real Verilator simulations of the real RTL."""
import json
import subprocess

import pytest

from albionbench import analysis, config, metrics, provenance, regress, results, runner, scenarios, toolchain, workloads
from albionbench.backends import fabric as fab

pytestmark = pytest.mark.integration

B = 16384
H = 0x80000000


@pytest.fixture(scope="module")
def fab_bin():
    binp, _ = toolchain.build_fabric(toolchain.pathlib.Path(__file__).resolve().parent.parent / "rtl_under_test" / "albion_soc", 4, B, 4)
    return binp


def run_dma(binp, dma, lat=1, seed=1):
    sc = {"workload": "cal", "streams": [], "dma": dma}
    return fab.run_raw(binp, sc, seed, lat, 3_000_000)


# --- calibration: P90's PUBLISHED DMA_CYCLES values, reproduced by an independent harness --------------------------------------------------
@pytest.mark.parametrize("dma,lat,published", [
    (f"mode=fill,dst={B},len=8192", 1, 2050),
    (f"mode=copy,src={B},dst={2 * B},len=8192", 1, 2052),
    (f"mode=copy,src={B},dst={B + 8192},len=8192", 1, 4098),
    (f"mode=copy,src={H},dst={B},len=4096", 1, 1028),
    (f"mode=copy,src={H},dst={B},len=4096", 4, 4100),
    (f"mode=copy,src={H},dst={B},len=4096", 16, 16388),
    (f"mode=copy,src={H},dst={B},len=4096", 64, 65540),
    (f"mode=copy,src={B},dst={H},len=4096", 4, 4100),
])
def test_dma_cycles_reproduce_p90_published_values(fab_bin, dma, lat, published):
    raw = run_dma(fab_bin, dma, lat)
    assert raw["status"] == "OK", raw
    assert raw["dma"]["cycles_reg"] == published
    assert raw["dma"]["window_cycles"] == published + 1                      # documented done-observation delay
    assert raw["checks"]["dma_mismatches"] == 0 and raw["checks"]["readback_mismatches"] == 0


def test_bad_stimulus_is_rejected_not_silently_run(fab_bin):
    sc = {"workload": "x", "streams": ["m=1,op=r,bank=0,n=16"], "dma": None}          # master 1 may not touch firmware-private bank 0
    raw = fab.run_raw(fab_bin, sc, 1, 1, 100000)
    assert raw["status"] == "ERROR" and "bank 0" in raw["error"]


def test_data_corruption_would_be_caught(fab_bin):
    """The checker itself: ask the harness to verify a region it did NOT write (expect zero mismatches on a clean run)."""
    sc = {"workload": "x", "streams": ["m=0,op=x,wpct=40,bank=0,nbanks=4,n=2000,pat=rand", "m=3,op=x,wpct=40,bank=0,nbanks=4,n=2000,pat=rand"], "dma": None}
    raw = fab.run_raw(fab_bin, sc, 5, 1, 1_000_000)
    assert raw["status"] == "OK" and raw["checks"]["stream_read_mismatches"] == 0 and raw["checks"]["readback_words"] > 0
    assert not fab.instrumentation_check(raw)


def test_power_up_randomisation_does_not_change_deterministic_results(fab_bin):
    sigs = set()
    for seed in range(1, 7):
        sc = scenarios.build("sram_bank_conflict", dict(config.DEFAULT["hardware"]), {"masters": 3, "placement": "same", "nwords": 200})
        raw = fab.run_raw(fab_bin, sc, seed, 1, 1_000_000)
        sigs.add((raw["window"]["cycles"], tuple(m["stall_cycles"] for m in raw["masters"])))
    assert len(sigs) == 1


# --- whole-pipeline checks on one smoke run ---------------------------------------------------------------------------------------------
def test_every_point_passes_and_has_the_full_metric_set(smoke_doc):
    bad = [(r["id"], r["status"]) for r in smoke_doc["points"] if r["status"] != "OK"]
    assert not bad, bad
    for r in smoke_doc["points"]:
        assert set(metrics.METRIC_KEYS) <= set(r["metrics"]), r["id"]
        assert r["metrics"]["clock_cycles"] and r["metrics"]["completed_ops"], r["id"]


def test_required_metrics_are_populated_where_applicable(smoke_doc):
    by = {r["id"]: r["metrics"] for r in smoke_doc["points"]}
    assert by["sram_seq_read|base"]["memory_bandwidth_bytes_per_cycle"] > 3.9
    assert by["gemm_int8|8x8x16"]["compute_utilization"] is not None and by["sram_seq_read|base"]["compute_utilization"] is None   # N/A is None, never 0
    assert by["sram_bank_conflict|same-bank/K=2"]["memory_conflicts"] > 0 and by["sram_bank_conflict|distinct-banks/K=2"]["memory_conflicts"] == 0
    assert by["bus_arbitration|saturating/K=4"]["latency_p99_cycles"] == 4


def test_absent_hardware_is_probed_and_marked_unavailable(smoke_doc):
    un = {u["id"]: u for u in smoke_doc["unavailable"]}
    for k in ("packet_throughput", "virtual_block_io", "albion_integrated_matmul"):
        assert un[k]["status"] == "UNAVAILABLE"
        assert un[k]["probe_confirms_unavailable"] is True, un[k]
        assert un[k]["probe"]["firmware_completion_status"] == "UNSUPPORTED" and un[k]["probe"]["implemented"] is False
    assert un["silicon_or_fpga_power"]["status"] == "UNAVAILABLE"


def test_provenance_is_complete(smoke_doc):
    P = smoke_doc["provenance"]
    assert provenance.validate(P)
    assert P["simulator"]["version"].startswith("Verilator") and P["tool_versions"]["verilator"]
    assert P["source_revision"]["git_head"] and P["source_revision"]["rtl_under_test"]["albion_soc"]["tree_sha256"]
    assert P["clock_assumptions"]["basis"] == "ASSUMED" and P["random_seed"]["seeds"]
    assert P["test_workload"]["executed"] and all(w["points"] for w in P["test_workload"]["executed"])
    assert all(b.get("binary_sha256") for b in P["simulator"]["binaries"].values())


def test_energy_is_always_labelled_an_estimate_and_never_measured(smoke_doc):
    n = 0
    for r in smoke_doc["points"]:
        e = r.get("energy")
        if not e:
            continue
        n += 1
        assert e["evidence_class"] == "library-estimate" and "ESTIMATE" in e["label"] and "NOT measured" in e["label"]
        assert e["measured_power"] is None and e["measured_power_unavailable_reason"]
        assert e["dynamic_pJ"]["low"] < e["dynamic_pJ"]["nominal"] < e["dynamic_pJ"]["high"]
        assert "activity_counts" in e
    assert n >= 20
    assert smoke_doc["energy"]["measured_power"] is None


def test_time_domain_numbers_exist_only_under_the_assumed_clock(smoke_doc):
    for r in smoke_doc["points"]:
        assert all(not k.endswith("_ns") and not k.endswith("_MB_per_s") for k in r["metrics"]), r["id"]
        assert r["metrics_at_assumed_clock"]["clock_mhz_assumed"] == 50.0


def test_models_predict_the_smoke_run(smoke_doc):
    s = smoke_doc["model_validation"]["summary"]["overall_out_of_sample"]
    assert s["n"] > 100 and s["within_tolerance"] / s["n"] > 0.95, s


def test_report_contains_every_required_provenance_field(smoke_doc, tmp_path):
    from albionbench import report
    p = tmp_path / "r.md"
    report.write_markdown(smoke_doc, p)
    report.write_charts(smoke_doc, tmp_path)
    t = p.read_text()
    for needle in ("Source revision", "Configuration", "Simulator", "Tool versions", "Random seed", "Clock assumptions", "Test workload", "UNAVAILABLE",
                   "ESTIMATE", "not measured", "Out-of-sample"):
        assert needle.lower() in t.lower(), needle


def test_p90_published_ping_round_trip(smoke_doc):
    by = {r["id"]: r for r in smoke_doc["points"]}
    assert by["host_mailbox_roundtrip|ping"]["metrics"]["latency_p50_cycles"] == 384        # P90 performance_report.md: PING median of 16 = 384 cycles
    assert by["host_mmio_latency|read-idle"]["metrics"]["latency_p50_cycles"] == 2          # SF-DF rule 4: MMIO responds the cycle after acceptance


@pytest.mark.parametrize("shape,published", [((4, 4, 4), 70), ((4, 4, 64), 218), ((16, 16, 64), 2852), ((32, 32, 64), 11068)])
def test_computeworks_published_gemm_cycles(shape, published):
    """ComputeWorks 06_PERFORMANCE.md table 1 (cycles per command, 4x4 array, 64-bit memory), reproduced through AlbionBench's own backend."""
    from albionbench.backends import compute
    cfg = config.load("smoke")
    ctx = runner.Context(progress=lambda m: None)
    pt = workloads.P("gemm_int8", "x".join(map(str, shape)), None, dict(cfg["hardware"]), shape=list(shape))
    (rec,) = compute.run_points([pt], dict(cfg, seeds=[1]), ctx)
    assert rec["status"] == "OK", rec["detail"]
    assert rec["metrics"]["latency_avg_cycles"] == published


def test_rerun_reproduces_every_counter_exactly():
    cfg = config.load("smoke")
    cfg["workloads"]["include"] = ["sram_*", "dma_*", "bus_*", "concurrent_*", "host_port_latency"]
    docs = []
    for _ in range(2):
        ctx = runner.Context(progress=lambda m: None)
        docs.append(results.assemble(cfg, ctx, runner.execute(cfg, ctx, only_backends={"fabric"}), cfg["seeds"]))
    a, b = ({r["id"]: r["metrics"] for r in d["points"]} for d in docs)
    assert a == b
    th = {"bandwidth_drop_pct": 0.0, "latency_increase_pct": 0.0, "tail_latency_increase_pct": 0.0, "stall_increase_pct": 0.0, "utilization_drop_pct": 0.0, "min_abs_cycles": 0}
    assert regress.compare(docs[0], docs[1], th)["findings"] == []
