// =============================================================================
// AlbionBench - fabric-complex measurement wrapper.       BENCHMARK-ONLY, NOT PRODUCT RTL.
//
// Instantiates the REAL Albion blocks from rtl_under_test/albion_soc, unmodified:
//     sf_albion_datafabric  (4-master crossbar + permission unit, per-slave round robin)
//     sf_albion_sram_bank   (x NB, single-port macro behind SECDED, RMW partial writes)
//     sf_albion_dma         (copy/fill, split read/write ports, prefetch FIFO of DMA_DEPTH)
//     sf_albion_host_if     (host MMIO pass-through master + host-memory requester slave)
// and replaces what it does not benchmark with clearly labelled stand-ins:
//     * the ControlCore is absent: masters 0 and 3 (CORE, HOST) are raw ports driven by the C++ traffic generators,
//       and masters 1/2 can be taken over by generators (dma_bypass = 1) to model additional concurrent masters;
//     * the MMIO slave (fabric slave index NB) is a 1-cycle always-ready stub: MMIO / mailbox latency is measured
//       on the unmodified sf_albion_cloud_top by the "soc" backend instead;
//     * the DMA register port is driven directly by the harness (equivalent to the ControlCore's MMIO writes minus
//       their latency) - DMA latencies measured here are therefore "register start -> done", excluding firmware.
//
// Only data movement timing is measured.  Everything the harness observes is a port of the real blocks.
// =============================================================================
module albionbench_fabric_top #(
  parameter int NB         = 4,
  parameter int BANK_BYTES = 16384,
  parameter int NW         = 8,
  parameter int DMA_DEPTH  = 4
) (
  input  logic              clk,
  input  logic              rst_n,
  // generator ports, one per fabric master (0 CORE, 1 DMARD, 2 DMAWR, 3 HOST)
  input  logic [3:0]        g_valid,
  output logic [3:0]        g_ready,
  input  logic [127:0]      g_addr,
  input  logic [3:0]        g_we,
  input  logic [127:0]      g_wdata,
  input  logic [15:0]       g_wstrb,
  output logic [3:0]        g_rsp_valid,
  output logic [127:0]      g_rsp_rdata,
  output logic [11:0]       g_rsp_err,
  input  logic              dma_bypass,        // 1: masters 1/2 come from generators, DMA held idle
  // DMA register port (the ControlCore's view, minus MMIO latency)
  input  logic              dma_rg_we,
  input  logic [11:0]       dma_rg_off,
  input  logic [31:0]       dma_rg_wdata,
  output logic [31:0]       dma_rg_rdata,
  // permission state (normally held by sf_albion_perm)
  input  logic [NW*32-1:0]  win_base,
  input  logic [NW*32-1:0]  win_limit,
  input  logic [NW*12-1:0]  win_attr,
  input  logic              boot_mode,
  // host memory requester port
  output logic              hm_req_valid_o,
  input  logic              hm_req_ready_i,
  output logic [30:0]       hm_req_addr_o,
  output logic              hm_req_we_o,
  output logic [31:0]       hm_req_wdata_o,
  output logic [3:0]        hm_req_wstrb_o,
  input  logic              hm_rsp_valid_i,
  input  logic [31:0]       hm_rsp_rdata_i,
  input  logic              hm_rsp_err_i,
  // observation (all taken from real block ports)
  output logic [3:0]        mon_valid,
  output logic [3:0]        mon_ready,
  output logic [3:0]        mon_we,
  output logic [127:0]      mon_addr,
  output logic [3:0]        mon_rsp_valid,
  output logic [3:0]        mon_ev_txn,
  output logic [3:0]        mon_ev_stall,
  output logic [NB+1:0]     mon_ev_s_txn,
  output logic              mon_ev_bank_conflict,
  output logic              mon_viol,
  output logic              mon_decerr,
  output logic              dma_done_ok,
  output logic              dma_done_err,
  output logic              dma_beat_ok,
  output logic [NB-1:0]     ecc_ce,
  output logic [NB-1:0]     ecc_ue,
  output logic              init_done
);
  localparam int NS      = NB + 2;
  localparam int NM      = 4;
  localparam int WORDS   = BANK_BYTES / 4;
  localparam int AW      = $clog2(WORDS);
  localparam int BANK_SH = $clog2(BANK_BYTES);
  localparam int SI_MMIO = NB;
  localparam int SI_HOST = NB + 1;

  // ------------------------------------------------------------------ fabric nets
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_we, m_rsp_valid;
  logic [NM*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0]  m_req_wstrb, m_req_domain;
  logic [NM*3-1:0]  m_rsp_err;

  logic [NS-1:0]    s_req_valid, s_req_ready, s_req_we, s_rsp_valid;
  logic [NS*32-1:0] s_req_addr, s_req_wdata, s_rsp_rdata;
  logic [NS*4-1:0]  s_req_wstrb, s_req_domain;
  logic [NS*2-1:0]  s_req_id, s_rsp_id;
  logic [NS*3-1:0]  s_rsp_err;

  logic        viol, viol_we, decerr, bank_conflict;
  logic [31:0] viol_addr;
  logic [1:0]  viol_master;
  logic [3:0]  viol_domain;
  logic [NM-1:0] ev_m_txn, ev_m_stall;
  logic [NS-1:0] ev_s_txn;

  sf_albion_datafabric #(.NB(NB), .BANK_BYTES(BANK_BYTES), .NW(NW)) u_fabric (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid, .m_req_ready, .m_req_addr, .m_req_we, .m_req_wdata, .m_req_wstrb, .m_req_domain,
    .m_rsp_valid, .m_rsp_rdata, .m_rsp_err,
    .win_base, .win_limit, .win_attr, .boot_mode,
    .s_req_valid, .s_req_ready, .s_req_addr, .s_req_we, .s_req_wdata, .s_req_wstrb, .s_req_domain, .s_req_id,
    .s_rsp_valid, .s_rsp_rdata, .s_rsp_err, .s_rsp_id,
    .viol_o(viol), .viol_addr_o(viol_addr), .viol_master_o(viol_master), .viol_domain_o(viol_domain),
    .viol_we_o(viol_we), .decerr_o(decerr),
    .ev_m_txn_o(ev_m_txn), .ev_m_stall_o(ev_m_stall), .ev_s_txn_o(ev_s_txn), .ev_bank_conflict_o(bank_conflict));

  // ------------------------------------------------------------------ master 0: CORE port (generator)
  assign m_req_valid[0]          = g_valid[0];
  assign m_req_addr[0*32 +: 32]  = g_addr[0*32 +: 32];
  assign m_req_we[0]             = g_we[0];
  assign m_req_wdata[0*32 +: 32] = g_wdata[0*32 +: 32];
  assign m_req_wstrb[0*4 +: 4]   = g_wstrb[0*4 +: 4];
  assign m_req_domain[0*4 +: 4]  = sf_albion_regs_pkg::DOM_FIRMWARE;

  // ------------------------------------------------------------------ DMA (masters 1, 2)
  logic        dma_rd_valid, dma_wr_valid;
  logic [31:0] dma_rd_addr, dma_wr_addr, dma_wr_data;
  logic [3:0]  dma_domain;
  logic [2:0]  dma_rg_err;

  sf_albion_dma #(.DEPTH(DMA_DEPTH)) u_dma (
    .clk(clk), .rst_n(rst_n),
    .rg_we(dma_rg_we), .rg_off(dma_rg_off), .rg_wdata(dma_rg_wdata), .rg_rdata(dma_rg_rdata), .rg_err(dma_rg_err),
    .rd_req_valid(dma_rd_valid), .rd_req_ready(m_req_ready[1] && !dma_bypass), .rd_req_addr(dma_rd_addr),
    .rd_rsp_valid(m_rsp_valid[1] && !dma_bypass), .rd_rsp_rdata(m_rsp_rdata[1*32 +: 32]), .rd_rsp_err(m_rsp_err[1*3 +: 3]),
    .wr_req_valid(dma_wr_valid), .wr_req_ready(m_req_ready[2] && !dma_bypass), .wr_req_addr(dma_wr_addr),
    .wr_req_wdata(dma_wr_data),
    .wr_rsp_valid(m_rsp_valid[2] && !dma_bypass), .wr_rsp_err(m_rsp_err[2*3 +: 3]),
    .domain_o(dma_domain),
    .ev_done_ok_o(dma_done_ok), .ev_done_err_o(dma_done_err), .ev_bytes_o(dma_beat_ok));

  assign m_req_valid[1]          = dma_bypass ? g_valid[1] : dma_rd_valid;
  assign m_req_addr[1*32 +: 32]  = dma_bypass ? g_addr[1*32 +: 32] : dma_rd_addr;
  assign m_req_we[1]             = dma_bypass ? g_we[1] : 1'b0;
  assign m_req_wdata[1*32 +: 32] = dma_bypass ? g_wdata[1*32 +: 32] : 32'h0;
  assign m_req_wstrb[1*4 +: 4]   = dma_bypass ? g_wstrb[1*4 +: 4] : 4'h0;
  assign m_req_domain[1*4 +: 4]  = dma_bypass ? sf_albion_regs_pkg::DOM_FIRMWARE : dma_domain;

  assign m_req_valid[2]          = dma_bypass ? g_valid[2] : dma_wr_valid;
  assign m_req_addr[2*32 +: 32]  = dma_bypass ? g_addr[2*32 +: 32] : dma_wr_addr;
  assign m_req_we[2]             = dma_bypass ? g_we[2] : 1'b1;
  assign m_req_wdata[2*32 +: 32] = dma_bypass ? g_wdata[2*32 +: 32] : dma_wr_data;
  assign m_req_wstrb[2*4 +: 4]   = dma_bypass ? g_wstrb[2*4 +: 4] : 4'hF;
  assign m_req_domain[2*4 +: 4]  = dma_bypass ? sf_albion_regs_pkg::DOM_FIRMWARE : dma_domain;

  // ------------------------------------------------------------------ host interface (master 3, slave NB+1)
  logic [31:0] unused_h_rdata;
  logic [2:0]  unused_h_err;
  logic        unused_h_valid;
  sf_albion_host_if u_host (
    .clk(clk), .rst_n(rst_n),
    .h_req_valid_i(g_valid[3]), .h_req_ready_o(g_ready[3]), .h_req_addr_i(g_addr[3*32 +: 32]), .h_req_we_i(g_we[3]),
    .h_req_wdata_i(g_wdata[3*32 +: 32]), .h_req_wstrb_i(g_wstrb[3*4 +: 4]),
    .h_rsp_valid_o(unused_h_valid), .h_rsp_rdata_o(unused_h_rdata), .h_rsp_err_o(unused_h_err),
    .m_req_valid(m_req_valid[3]), .m_req_ready(m_req_ready[3]), .m_req_addr(m_req_addr[3*32 +: 32]),
    .m_req_we(m_req_we[3]), .m_req_wdata(m_req_wdata[3*32 +: 32]), .m_req_wstrb(m_req_wstrb[3*4 +: 4]),
    .m_rsp_valid(m_rsp_valid[3]), .m_rsp_rdata(m_rsp_rdata[3*32 +: 32]), .m_rsp_err(m_rsp_err[3*3 +: 3]),
    .s_req_valid(s_req_valid[SI_HOST]), .s_req_ready(s_req_ready[SI_HOST]), .s_req_addr(s_req_addr[SI_HOST*32 +: 32]),
    .s_req_we(s_req_we[SI_HOST]), .s_req_wdata(s_req_wdata[SI_HOST*32 +: 32]), .s_req_wstrb(s_req_wstrb[SI_HOST*4 +: 4]),
    .s_req_id(s_req_id[SI_HOST*2 +: 2]),
    .s_rsp_valid(s_rsp_valid[SI_HOST]), .s_rsp_rdata(s_rsp_rdata[SI_HOST*32 +: 32]), .s_rsp_err(s_rsp_err[SI_HOST*3 +: 3]),
    .s_rsp_id(s_rsp_id[SI_HOST*2 +: 2]),
    .hm_req_valid_o, .hm_req_ready_i, .hm_req_addr_o, .hm_req_we_o, .hm_req_wdata_o, .hm_req_wstrb_o,
    .hm_rsp_valid_i, .hm_rsp_rdata_i, .hm_rsp_err_i);
  assign m_req_domain[3*4 +: 4] = sf_albion_regs_pkg::DOM_HOST_ADMIN;

  // ------------------------------------------------------------------ SRAM banks (slaves 0..NB-1)
  logic [NB-1:0] bank_init;
  generate
    for (genvar b = 0; b < NB; b++) begin : g_bank
      logic [31:0] a;
      logic        unused_inj;
      logic [6:0]  unused_syn;
      logic [AW-1:0] unused_word;
      logic [1:0]  unused_master;
      logic [3:0]  unused_domain;
      assign a = s_req_addr[b*32 +: 32];
      sf_albion_sram_bank #(.WORDS(WORDS)) u_bank (
        .clk(clk), .rst_n(rst_n),
        .req_valid(s_req_valid[b]), .req_ready(s_req_ready[b]), .req_word(a[BANK_SH-1:2]),
        .req_we(s_req_we[b]), .req_wdata(s_req_wdata[b*32 +: 32]), .req_wstrb(s_req_wstrb[b*4 +: 4]),
        .req_id(s_req_id[b*2 +: 2]), .req_domain(s_req_domain[b*4 +: 4]),
        .rsp_valid(s_rsp_valid[b]), .rsp_rdata(s_rsp_rdata[b*32 +: 32]), .rsp_err(s_rsp_err[b*3 +: 3]),
        .rsp_id(s_rsp_id[b*2 +: 2]),
        .inj_arm(1'b0), .inj_word('0), .inj_mask('0), .inj_hit_o(unused_inj),
        .ecc_ce_o(ecc_ce[b]), .ecc_ue_o(ecc_ue[b]), .ecc_syndrome_o(unused_syn),
        .ecc_word_o(unused_word), .ecc_master_o(unused_master), .ecc_domain_o(unused_domain),
        .init_done_o(bank_init[b]));
    end
  endgenerate
  assign init_done = &bank_init;

  // ------------------------------------------------------------------ MMIO slave stub (slave NB)
  logic       stub_valid_q;
  logic [1:0] stub_id_q;
  assign s_req_ready[SI_MMIO] = 1'b1;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      stub_valid_q <= 1'b0;
      stub_id_q    <= '0;
    end else begin
      stub_valid_q <= s_req_valid[SI_MMIO];
      stub_id_q    <= s_req_id[SI_MMIO*2 +: 2];
    end
  end
  assign s_rsp_valid[SI_MMIO]          = stub_valid_q;
  assign s_rsp_rdata[SI_MMIO*32 +: 32] = 32'h0;
  assign s_rsp_err[SI_MMIO*3 +: 3]     = sf_albion_regs_pkg::FE_OK;
  assign s_rsp_id[SI_MMIO*2 +: 2]      = stub_id_q;

  // ------------------------------------------------------------------ observation
  assign g_rsp_valid[0]      = m_rsp_valid[0];
  assign g_rsp_valid[1]      = m_rsp_valid[1] && dma_bypass;
  assign g_rsp_valid[2]      = m_rsp_valid[2] && dma_bypass;
  assign g_rsp_valid[3]      = m_rsp_valid[3];
  assign g_rsp_rdata         = m_rsp_rdata;
  assign g_rsp_err           = m_rsp_err;
  assign g_ready[0]          = m_req_ready[0];
  assign g_ready[1]          = m_req_ready[1];
  assign g_ready[2]          = m_req_ready[2];
  assign mon_valid           = m_req_valid;
  assign mon_ready           = m_req_ready;
  assign mon_we              = m_req_we;
  assign mon_addr            = m_req_addr;
  assign mon_rsp_valid       = m_rsp_valid;
  assign mon_ev_txn          = ev_m_txn;
  assign mon_ev_stall        = ev_m_stall;
  assign mon_ev_s_txn        = ev_s_txn;
  assign mon_ev_bank_conflict = bank_conflict;
  assign mon_viol            = viol;
  assign mon_decerr          = decerr;

  logic unused;
  assign unused = ^{dma_rg_err, viol_addr, viol_master, viol_domain, viol_we, unused_h_rdata, unused_h_err, unused_h_valid};
endmodule
