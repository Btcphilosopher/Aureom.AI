# AlbionBench methodology

This document says what AlbionBench measures, how, why the numbers can be trusted, and — equally important — what they are **not**.

## 1. Evidence classes

| class | what it is | never to be described as |
|---|---|---|
| **rtl-simulation** | cycle counts from cycle-accurate, zero-delay, two-state Verilator simulation of the real RTL, every result verified against an independent shadow memory / reference model | silicon, FPGA, or gate-level timing |
| **structural model** | a prediction derived by reading the RTL and protocol documentation; no constant fitted to benchmark output | a measurement |
| **fitted model** | constants least-squares fitted to a *named* calibration set | validated on its own calibration points |
| **assumed clock** | a frequency chosen in the configuration (default 50 MHz, the P90 FPGA target). Scales ns, MB/s, mW only | a measured or signed-off clock |
| **library estimate** | activity counts × literature per-event energies (§7) | measured power or energy |
| **UNAVAILABLE** | hardware absent from the RTL; established by probing the live RTL, not by assertion | something to stub |

No SilicaFlux design has timing closure, a technology library, a netlist with parasitics, or a silicon/FPGA power measurement. Anything that would need those is reported `UNAVAILABLE` (see `workloads.UNAVAILABLE`).

## 2. What is simulated

Three **backends**, each driving real RTL from a vendored, SHA-256-fingerprinted snapshot (`rtl_under_test/`, `SOURCES.json`, `MANIFEST.sha256`):

| backend | design under test | stand-ins | what it measures |
|---|---|---|---|
| `fabric` | **real** `sf_albion_datafabric` (4-master crossbar + permission unit, per-slave round robin), `sf_albion_sram_bank` ×NB (SECDED, RMW), `sf_albion_dma`, `sf_albion_host_if` | `rtl_bench/albionbench_fabric_top.sv` (benchmark-only wrapper): no ControlCore (CORE and HOST ports are driven by C++ traffic generators); MMIO slave is a 1-cycle stub; DMA registers are written directly (equal to the ControlCore's MMIO writes minus their latency) | SRAM sequential/random/partial access, bank conflicts, arbitration, concurrency, DMA bandwidth and latency, HOST-port latency under load |
| `soc` | **unmodified** `sf_albion_cloud_top` + the real RV32I firmware, driven through the product's own harness `albion_sim.cpp` | none (the harness plays the host) | host MMIO latency (idle and under DMA load), mailbox PING round trip, DMA_FILL command round trip, firmware overhead, **feature probing** |
| `compute` | **real** ComputeWorks tile (P88) with its own benchmark code and independent reference models | none | INT32 vector arithmetic, INT8 GEMM, lanes / array / ports / memory width, memory contention |

ComputeWorks is benchmarked **standalone**: it is not wired into the Albion SoC top (the firmware returns `UNSUPPORTED` for the `MATMUL_INT8` opcode — probed, see §9). The HostBridge (Module 96) host-transaction interface and the AlbionCore ALP reference subsystem are separate integration lines and are **not** benchmarked in this module.

## 3. Measurement method (fabric backend)

* **Stimulus and measurement are separate.** Traffic generators and the DMA drive the DUT; a *passive per-master monitor*, built only from DUT port signals, records every request's lifetime (first valid → accept → response). The monitor never looks at generator state.
* **RTL counters are cross-checked.** The fabric's own event outputs (`ev_m_txn`, `ev_m_stall`, `ev_s_txn`, bank-conflict) and the DMA `DMA_CYCLES` register are summed over the same window and compared with the monitor on every point. Any disagreement is `FAIL_INSTRUMENTATION`.
* **Every result is checked.** Reads are compared with a shadow memory updated in *accept order* (exact under multi-master overlap, partial writes and DMA); written regions are read back after the window; DMA results are compared word-by-word with the independently known expectation; ECC events and permission violations must be zero. Illegal stimulus (e.g. DMA ports touching the firmware-private bank) is rejected up front.
* **Deadlock detection.** A progress watchdog (any handshake or response on any port) plus a cycle budget turn a hung workload into `DEADLOCK` with diagnostic state, instead of a wall-clock timeout.
* **No X-dependence.** Power-up state is randomised per seed (`--x-initial unique`, `VerilatedContext::randReset(2)`). Deterministic workloads must produce *identical* cycle, stall and conflict counts for every seed; the runner checks this on every point.
* **Host-memory timing** replicates `albion_sim.cpp` exactly (response in the cycle `accept + L`), so results are comparable with P90.

Definitions (also in `albionbench/metrics.py`): *window cycles* = first request presented → last response (inclusive; for DMA: CTRL write → `done` observed, which equals the `DMA_CYCLES` register + 1, checked). *Latency* = first-valid → response. *Tail latency* is the exact percentile of all transactions (merged histograms). *Pipeline utilisation* = accepted requests ÷ (banks touched × cycles). Not-applicable metrics are `null`, never `0`.

## 4. Calibration against numbers from outside this framework

AlbionBench's fabric/SoC harnesses were written independently of P90's Rust bench and reproduce its **published** figures *exactly* (test `test_integration_rtl.py`):

| quantity | P90 published | AlbionBench |
|---|---:|---:|
| DMA fill 8 KiB, `DMA_CYCLES` | 2050 | 2050 |
| DMA copy cross-bank 8 KiB | 2052 | 2052 |
| DMA copy same-bank 8 KiB | 4098 | 4098 |
| host→SRAM 4 KiB, host latency 1 / 4 / 16 / 64 | 1028 / 4100 / 16388 / 65540 | 1028 / 4100 / 16388 / 65540 |
| SRAM→host 4 KiB, host latency 1 / 4 | 1028 / 4100 | 1028 / 4100 |
| PING round trip, median | 384 | 384 |
| 64 B `DMA_FILL` round trip, median | 743 | 743 |

ComputeWorks' own published table (06_PERFORMANCE.md) is reproduced through AlbionBench's backend: 4×4×4 → 70, 4×4×64 → 218, 16×16×64 → 2852, 32×32×64 → 11 068 cycles per command; 16×16×64 with 50 % background DMA → 2900 (AlbionBench: 2899).

## 5. Performance models and how they are validated

Five models (`albionbench/models/`): **A** memory bandwidth (structural + Monte Carlo), **B** roofline (not fitted), **C** accelerator utilisation (structural + fitted), **D** transaction latency (structural + fitted mailbox model), **E** workload scaling (Hockney and Amdahl fits). Every prediction carries its *basis* and an `in_sample` flag, and is compared with the RTL result under a stated tolerance (1 % structural, 5 % structural-approximate / Monte Carlo, 3 % fitted, plus a 1-cycle absolute allowance on cycle-valued metrics).

Rules that keep the validation honest:

1. **Only out-of-sample points count.** Points used to fix a constant (the named calibration set; P90's anchors for Model A) are tagged `in_sample` and excluded from the headline.
2. **Blind validation.** 41 held-out points (odd transfer lengths, host latencies 2/3/7/33, partial-tile GEMM shapes, VL not a multiple of the chunk, 5 banks, …) are executed with every run but were *never used to design or calibrate a model*; they are marked `*` in the report.
3. **Misses are shown, not hidden.** The report lists every prediction outside tolerance.

What the blind set found (kept as history because it is informative): the first GEMM model assumed full-size array blocks; the blind partial-tile shapes showed array-busy cycles actually follow the *actual* block dimensions, and that words read for unaligned tiles are only approximately predictable. Both were then corrected/relabelled (`structural-approx`). The Monte Carlo conflict count originally counted per-bank rather than per-cycle (the RTL event is one bit per cycle) — also caught by the comparison.

Known model limitations are listed in §9 of every report.

## 6. Configuration knobs and honesty about what varies

`albionbench list` prints this; `config.KNOBS` is the source. In short:

| knob | realisation | note |
|---|---|---|
| SRAM bank count, bank bytes, DMA FIFO depth | **rtl** (Verilog parameter, separate Verilator build per value) | bank 0 is firmware-private, so ≥ 2 banks; cross-bank DMA copy needs ≥ 3 |
| vector lanes, tensor array, compute ports, compute memory width | **rtl** (ComputeWorks parameters) | restricted to ComputeWorks' verified configuration matrix |
| bus width | fabric data path is **fixed 32-bit in RTL** → other widths are `model_only`; ComputeWorks' memory width *is* an RTL parameter | never reported as a measurement |
| DMA burst size | **workload** property: `sf_albion_dma` has no burst protocol (single 32-bit beats, one outstanding request per port); "burst size" = programmed transfer length | |
| tensor dimensions, vector length, concurrent masters, host latency | workload | the fabric has exactly four masters |
| clock target | **assumption** | zero-delay simulation has no frequency; scales ns / MB/s / mW only |

## 7. Energy

Three strictly separated layers (`albionbench/energy.py`, `data/energy_library.json`):

1. **Activity counts** — exact event counts from simulation (SRAM accesses, MACs, DMA beats, host-port beats, fabric transactions, firmware instructions). Facts about the simulation, not energy.
2. **Library estimate** — counts × per-event energies from a named library (literature values at 45 nm; Horowitz, ISSCC 2014 energy table, scaled where stated; each coefficient carries a derivation and a confidence). Reported as a low / nominal / high band (×0.5 … ×2 — *not* a confidence interval). **Dynamic energy only**; excluded: leakage, clock tree, wires, PHY/IO, real SRAM macro energy. Not scaled to any SilicaFlux process, because none is chosen.
3. **Measured power** — always `null` with the reason.

Simulated switching activity is never presented as silicon energy. The estimate exists to compare *activity* between RTL variants (`ab` reports show the estimated pJ/byte alongside performance) and to sanity-check orders of magnitude. Per-point estimates cover all activity in the window, including background masters; `pJ/byte` divides by the *foreground* bytes only. Do not use it for power budgeting. The per-event values should be re-checked against the source before any use outside this framework.

## 8. Regression detection

`albionbench regress` compares a candidate `results.json` with a baseline. Categories: `INCORRECT_RESULT`, `DEADLOCK`, `BANDWIDTH_REGRESSION`, `CYCLES_REGRESSION`, `LATENCY_REGRESSION`, `TAIL_LATENCY_REGRESSION`, `STALL_REGRESSION`, `STARVATION`, `UTILIZATION_DROP`, `INSTRUMENTATION`, `HARDWARE_LOST`, `MISSING_POINT`, `CONFLICT_INCREASE` (warn), and informational `IMPROVED_*`.

* **Noise model.** The simulation is deterministic; with identical seeds an unchanged design reproduces every counter bit-for-bit (tested). Default thresholds are therefore tight (0.5 % bandwidth/latency, 1 % tail/stall/utilisation, ±2 cycles absolute). Stochastic workloads (random traffic) get a ×5 allowance because any arbitration change legitimately reshuffles the random sequence.
* **Stalls are only compared when the amount of work is unchanged.**
* **The gate is itself tested** (`validate-detectors`, `tests/test_detectors_mutation.py`): eight RTL variants — wrong DMA data, DMA read port without same-cycle re-issue, an extra SRAM response register, a DMA that never signals done, a fixed-priority arbiter, a 1-in-8 bank blackout, the reconstructed host-interface bubble, and a comment-only control — are built and benchmarked; each regression must be flagged under its expected category and the control must raise nothing. Evidence: `results/detector_validation/`.

## 9. A/B verdicts

`albionbench ab` runs the *same* suite and seeds on two RTL trees (or two hardware settings) and applies the regression gate's thresholds. A point is **IMPROVED** only if its workload's *headline* metric improved beyond the threshold and nothing regressed; **REGRESSED** if *any* metric failed its gate; otherwise **NO CHANGE**. Secondary metrics that move while the headline does not (fewer stalls for identical completion time) are listed but *not* counted as an improvement — that distinction was added after the DMA-depth-2 experiment showed a point whose arbiter stalls halved with unchanged cycles.

Worked examples shipped in `results/`:

| A/B | verdict |
|---|---|
| `host_if_reissue_bubble` (reconstructed pre-fix) → shipped RTL | **IMPROVES** (host DMA 4/(L+1) → 4/L B/cycle) |
| DMA FIFO depth 4 → 3 | no measurable change |
| DMA FIFO depth 4 → 2 | **REGRESSES** (−33 % copy bandwidth) |
| comment-only change | no measurable change (false-positive control) |

The `host_if_reissue_bubble` variant is a **reconstruction** from P90's description of an earlier bug; the original pre-fix source is not in the repository.

## 10. Absent hardware (probed)

`feature_probe` builds `sf_albion_cloud_top` with `CONFIG=2` (which *requests* every feature) and reads `MGMT.FEAT_REQ / FEAT_IMPL / FEAT_UNAVAIL`, then sends opcodes `0x50 / 0x51 / 0x52` to the firmware. The RTL itself prints `requested-but-unavailable features 0x00000700` and the firmware answers `UNSUPPORTED`: PacketForge, VirtualFoundry and ComputeWorks are not instantiated in the Albion top. If a future RTL revision implements one, `probe_confirms_unavailable` flips and the regression gate reports `HARDWARE_CHANGE` so that a benchmark can be added.

## 11. Limitations

* RTL simulation only; no timing, area, power, or physical effects.
* Fabric backend omits the ControlCore (so DMA latencies exclude firmware; the `soc` backend measures the full path).
* Compute is standalone; Albion↔ComputeWorks integration is not benchmarked because it does not exist.
* Model A covers uniform random traffic only; same-bank DMA mean beat latency ignores the first ~4 uncontended beats; dual-port compute configurations and unaligned-tile GEMM word counts are not modelled exactly.
* Energy numbers are order-of-magnitude, literature-based estimates.
* One clock domain; one host-memory outstanding request; no NoC/HBM/PCIe-link modelling.
