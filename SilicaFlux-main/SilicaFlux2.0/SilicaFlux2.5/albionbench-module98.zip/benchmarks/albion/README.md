# AlbionBench — SilicaFlux performance and energy benchmarking (Module 98)

A reproducible benchmark framework for the SilicaFlux cloud-compute RTL. It answers one question rigorously:

> **Did this RTL change actually improve measured, simulated performance — and did it break anything?**

Everything is **cycle-accurate RTL simulation (Verilator)** of the real SilicaFlux RTL, with every result verified against an independent shadow model or reference. It is not silicon, FPGA or gate-level measurement; time-domain numbers use an *assumed* clock and energy numbers are *labelled estimates*. See [`docs/METHODOLOGY.md`](docs/METHODOLOGY.md).

## Quick start

```bash
# needs: verilator >= 5.020, g++, python3 (stdlib only; pytest for tests)
# SoC host-latency workloads also need: clang + ld.lld + llvm-objcopy + make (ControlCore firmware)
cd benchmarks/albion
python3 -m albionbench env                   # tool versions / backend readiness
make test-fast                               # unit tests, ~1 s, no simulator
make smoke                                   # ~1 min sanity suite  -> results/smoke/
make run                                     # standard suite (171 points, ~2-4 min) -> results/standard/
make regress                                 # gate the run against the golden baseline
make ab-host-if-fix                          # what did the host-interface fix actually gain?
make validate-detectors                      # mutate the RTL, prove the gate fires
make test                                    # everything, incl. real simulation and the mutation matrix (~8 min)
```

Outputs of `run` (in `results/<config>/`):

| file | content |
|---|---|
| `results.json` | every point: status, all required metrics, assumed-clock view, detail, per-seed values, energy estimate, model predictions; `provenance`; `model_validation`; `models`; `unavailable`; `findings` |
| `results.csv` | one row per point (metrics, hardware knobs, energy, model error, provenance ids) |
| `benchmark_report.md` | the human report: provenance, evidence classes, findings, hardware availability, all tables, models vs RTL, energy, configuration, limitations |
| `roofline.svg`, `model_validation.svg`, `dma_host_latency.svg` | charts (light/dark aware) |

**Every report identifies**: source revision, configuration, simulator, tool versions, random seed, clock assumptions and test workload — generation fails if any is missing.

## What is benchmarked

| group | workloads | backend / RTL |
|---|---|---|
| memory | `sram_seq_read`, `sram_seq_write`, `sram_seq_write_partial`, `sram_random`, `sram_bank_conflict`, `concurrent_mem`, `concurrent_dma_interference` | `fabric` — real fabric + SECDED SRAM banks + DMA |
| bus | `bus_arbitration` (fairness, starvation bound, tail wait) | `fabric` |
| DMA | `dma_bandwidth` (fill, copy cross-/same-bank, host↔SRAM), `dma_latency` | `fabric` |
| host | `host_port_latency` (HOST master under load), `host_mmio_latency`, `host_mailbox_roundtrip`, `host_dma_roundtrip` | `fabric`, `soc` (unmodified `sf_albion_cloud_top` + firmware) |
| compute | `vector_int32` (VADD/VMUL), `gemm_int8`, `compute_mem_contention` | `compute` — ComputeWorks tile (standalone) |
| **unavailable** | packet throughput, virtual block I/O, matrix multiply *through the Albion SoC*, PCIe link latency, measured power, GB/s at a signed-off clock | probed on the live RTL (`MGMT.FEAT_*`, firmware `UNSUPPORTED`) — never stubbed |

`python3 -m albionbench list` shows the points per workload, the absent hardware and the configuration knobs.

## Metrics (all points)

clock cycles · completed operations · bytes transferred · average latency · tail latency (p50/p95/p99/p99.9/max) · memory bandwidth · transaction throughput · pipeline utilisation · stall cycles · memory conflicts · compute utilisation. `null` = not applicable (never zero). Definitions: `albionbench/metrics.py`, METHODOLOGY §3.

## Experiment configuration

`configs/{smoke,standard,ab}.json` (JSON, no dependencies). Each knob is classified by where it is realised — a report never implies RTL was varied when it was not:

| knob | realisation |
|---|---|
| SRAM bank count (2–8), bank bytes, DMA FIFO depth | **RTL parameter** (one Verilator build per value) |
| vector lanes (1–16), tensor array (2×2…8×8), compute ports, compute memory width | **RTL parameter** (ComputeWorks' verified matrix) |
| bus width | Albion fabric is **fixed 32-bit** → other widths are `model_only`; ComputeWorks' width is a real parameter |
| DMA burst size | **workload** — the DMA has no burst protocol; this is the descriptor length |
| tensor dimensions, vector length, concurrent masters, host latency | workload |
| clock target | **assumption** (scales ns, MB/s, mW only) |

## Performance models (predicted vs RTL)

A memory bandwidth · B roofline · C accelerator utilisation · D transaction latency · E workload scaling. Each prediction is tagged *structural / monte-carlo / fitted*, flagged *in-sample* if it was used to fix a constant, and compared with the RTL result. 41 **blind-validation** points per run were never used to build a model. Only out-of-sample comparisons count (typically ~830 comparisons per standard run; the report lists every miss).

## Regression testing and A/B

```bash
python3 -m albionbench regress --baseline baselines/standard.json --candidate results/standard/results.json --strict-set
python3 -m albionbench ab --variant host_if_reissue_bubble --reverse --backends fabric       # RTL variant
python3 -m albionbench ab --candidate-hw dma_depth=3 --backends fabric                        # hardware parameter
python3 -m albionbench ab --baseline-rtl OLD/albion_soc --candidate-rtl NEW/albion_soc        # two RTL trees
```

The gate flags incorrect results, reduced bandwidth, increased latency (mean and tail), deadlocks, stall regressions, arbitration starvation and utilisation drops, with tight thresholds because the simulation is deterministic (`configs`/`config.DEFAULT["thresholds"]`). **The gate is itself tested** by mutating the RTL (`variants/`): see `results/detector_validation/`.

A/B verdicts are driven by each workload's *headline* metric; secondary metrics that move without a change in completion time are reported but not counted as an improvement.

## Using it on new RTL

1. Put the new tree in place of / next to `rtl_under_test/albion_soc` (or point `--rtl-soc DIR` at it); `tools/vendor_rtl.py` re-vendors from the upstream zips and re-hashes.
2. `python3 -m albionbench run --rtl-soc NEW --out results/new` then `regress` / `ab` against the baseline.
3. After an *intentional, reviewed* performance change: `make baseline`.

Adding a workload: `reg(...)` + a scenario in `scenarios.py` (fabric) or a backend function; add it to `suite_points`. Adding a variant: a `variants/<name>/variant.json` of exact find/replace edits (each must match once).

## Layout

```
albionbench/        python package  (cli, runner, workloads, scenarios, metrics, models/, energy, analysis, regress, abtest, detectors, report, provenance)
harness/            fabric_harness.cpp (cycle-accurate C++/Verilator harness), compute_runner.py
rtl_bench/          albionbench_fabric_top.sv  - benchmark-only wrapper (NOT product RTL)
rtl_under_test/     hashed snapshot of the RTL under test (Albion p90, ComputeWorks p88) + SOURCES.json / MANIFEST.sha256
variants/           RTL variants: historical fix, 6 regression mutants, 1 control
configs/  baselines/  results/  tests/  docs/  tools/
```

## What this does not do

No silicon, FPGA, timing, area or power measurement (none exists). ComputeWorks is not integrated into the Albion top and is benchmarked standalone. The HostBridge (M96) and AlbionCore ALP reference subsystem are not benchmarked here. Energy values are order-of-magnitude literature-based estimates, not for power budgeting. Full list: METHODOLOGY §11 and §9 of every report.
