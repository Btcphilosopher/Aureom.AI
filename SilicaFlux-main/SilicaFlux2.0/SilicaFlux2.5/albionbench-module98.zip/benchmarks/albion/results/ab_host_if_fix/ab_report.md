# AlbionBench A/B report

**Verdict: IMPROVES measured simulated performance.**

6 point(s) improved, 0 regressed, 24 unchanged (same seeds, same harness; thresholds {"bandwidth_drop_pct": 0.5, "latency_increase_pct": 0.5, "tail_latency_increase_pct": 1.0, "stall_increase_pct": 1.0, "utilization_drop_pct": 1.0, "min_abs_cycles": 2}).

| | |
|---|---|
| **baseline** | variant:host_if_reissue_bubble (hw override: none) |
| **candidate** | vendored (hw override: none) |
| **suite** | ab |
| **seeds** | [1, 2] |
| **backends** | fabric |
| **simulator** | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| **source revision** | d1e9176418f3 |
| **variant** | host_if_reissue_bubble (historical-bug-reconstruction): Host-memory requester re-issues one cycle AFTER the response instead of in the response cycle (slot_free = !busy). Reconstructed from P90's performance report, which states that an earlier revision measured 4/(L+1) B/cycle on the host path and that AlbionBench exposed a one-cycle re-issue bubble in sf_albion_host_if that was then fixed. The original pre-fix source is not in the repository, so this is a reconstruction of the described behaviour, not a recovered file.; edited rtl/albion/sf_albion_host_if.sv |

Energy columns are library-based ESTIMATES from simulation activity (see benchmark_report.md §7); they are not measured.

## Points that changed

| point | verdict | cycles | B/cycle | lat avg | lat p99 | stalls | est. pJ/byte | categories |
|---|---|---|---|---|---|---|---|---|
| `dma_bandwidth|host_to_sram/len=1024` | **IMPROVED** | 516 → 261 | 1.984 → 3.923 | 1.50 → 1.00 | 2 → 1 | 255 → 0 | 2.77 → 2.77 | IMPROVED_BANDWIDTH, IMPROVED_CYCLES, IMPROVED_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_STALL |
| `dma_bandwidth|sram_to_host/len=1024` | **IMPROVED** | 516 → 261 | 1.984 → 3.923 | 1.50 → 1.00 | 2 → 1 | 255 → 0 | 2.77 → 2.77 | IMPROVED_BANDWIDTH, IMPROVED_CYCLES, IMPROVED_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_STALL |
| `dma_latency|host_to_sram/len=64` | **IMPROVED** | 36 → 21 | 1.778 → 3.048 | 1.47 → 1.00 | 2 → 1 | 15 → 0 | 2.77 → 2.77 | IMPROVED_BANDWIDTH, IMPROVED_CYCLES, IMPROVED_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_STALL |
| `dma_bandwidth|host_to_sram/L=4` | **IMPROVED** | 1284 → 1029 | 0.798 → 0.995 | 3.00 → 2.50 | 5 → 4 | 255 → 0 | 2.77 → 2.77 | IMPROVED_BANDWIDTH, IMPROVED_CYCLES, IMPROVED_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_STALL |
| `dma_bandwidth|host_to_sram/L=16` | **IMPROVED** | 4356 → 4101 | 0.235 → 0.250 | 9.00 → 8.50 | 17 → 16 | 255 → 0 | 2.77 → 2.77 | IMPROVED_BANDWIDTH, IMPROVED_CYCLES, IMPROVED_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_STALL |
| `dma_bandwidth|sram_to_host/L=4` | **IMPROVED** | 1284 → 1029 | 0.798 → 0.995 | 3.00 → 2.50 | 5 → 4 | 255 → 0 | 2.77 → 2.77 | IMPROVED_BANDWIDTH, IMPROVED_CYCLES, IMPROVED_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_TAIL_LATENCY, IMPROVED_STALL |

## Unchanged (24)

`sram_seq_read|base`, `sram_seq_write|base`, `sram_seq_write_partial|base`, `sram_random|masters=1`, `sram_bank_conflict|same-bank/K=2`, `sram_bank_conflict|distinct-banks/K=2`, `bus_arbitration|saturating/K=4`, `concurrent_mem|K=4`, `concurrent_dma_interference|same-bank`, `concurrent_dma_interference|distinct-bank`, `host_port_latency|background=0`, `host_port_latency|background=3`, `dma_bandwidth|fill/len=1024`, `dma_bandwidth|copy_xbank/len=1024`, `dma_bandwidth|copy_samebank/len=1024`, `dma_latency|fill/len=4`, `dma_latency|fill/len=64`, `dma_latency|copy_xbank/len=4`, `dma_latency|copy_xbank/len=64`, `dma_latency|host_to_sram/len=4`, `bus_arbitration|unequal/K=4`, `sram_bank_conflict|same-bank/K=4`, `sram_bank_conflict|distinct-banks/K=4`, `host_port_latency|background=1`

