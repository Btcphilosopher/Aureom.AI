# AlbionBench A/B report

**Verdict: NO MEASURABLE CHANGE in any workload.**

0 point(s) improved, 0 regressed, 30 unchanged (same seeds, same harness; thresholds {"bandwidth_drop_pct": 0.5, "latency_increase_pct": 0.5, "tail_latency_increase_pct": 1.0, "stall_increase_pct": 1.0, "utilization_drop_pct": 1.0, "min_abs_cycles": 2}).

| | |
|---|---|
| **baseline** | vendored (hw override: none) |
| **candidate** | variant:control_comment_only (hw override: none) |
| **suite** | ab |
| **seeds** | [1, 2] |
| **backends** | fabric |
| **simulator** | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| **source revision** | d1e9176418f3 |
| **variant** | control_comment_only (control): Comment-only change to the DMA FIFO. Behaviour is bit-identical: the A/B tool and the regression gate must report NO change (false-positive control).; edited rtl/albion/sf_albion_fifo.sv |

Energy columns are library-based ESTIMATES from simulation activity (see benchmark_report.md §7); they are not measured.

## Points that changed

| point | verdict | cycles | B/cycle | lat avg | lat p99 | stalls | est. pJ/byte | categories |
|---|---|---|---|---|---|---|---|---|

## Unchanged (30)

`sram_seq_read|base`, `sram_seq_write|base`, `sram_seq_write_partial|base`, `sram_random|masters=1`, `sram_bank_conflict|same-bank/K=2`, `sram_bank_conflict|distinct-banks/K=2`, `bus_arbitration|saturating/K=4`, `concurrent_mem|K=4`, `concurrent_dma_interference|same-bank`, `concurrent_dma_interference|distinct-bank`, `host_port_latency|background=0`, `host_port_latency|background=3`, `dma_bandwidth|fill/len=1024`, `dma_bandwidth|copy_xbank/len=1024`, `dma_bandwidth|copy_samebank/len=1024`, `dma_bandwidth|host_to_sram/len=1024`, `dma_bandwidth|sram_to_host/len=1024`, `dma_latency|fill/len=4`, `dma_latency|fill/len=64`, `dma_latency|copy_xbank/len=4`, `dma_latency|copy_xbank/len=64`, `dma_latency|host_to_sram/len=4`, `dma_latency|host_to_sram/len=64`, `dma_bandwidth|host_to_sram/L=4`, `dma_bandwidth|host_to_sram/L=16`, `dma_bandwidth|sram_to_host/L=4`, `bus_arbitration|unequal/K=4`, `sram_bank_conflict|same-bank/K=4`, `sram_bank_conflict|distinct-banks/K=4`, `host_port_latency|background=1`

