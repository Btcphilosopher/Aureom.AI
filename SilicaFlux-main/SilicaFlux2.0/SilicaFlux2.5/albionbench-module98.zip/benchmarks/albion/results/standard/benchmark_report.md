# AlbionBench - SilicaFlux performance and energy benchmark report

Module 98 · framework v1.0.0 · generated 2026-11-18T10:16:17Z · suite **standard** · **171 measured points**, 171 OK

> **What these numbers are.** Cycle counts from cycle-accurate RTL simulation (Verilator) of the real SilicaFlux RTL, with every result checked against an independent shadow model or reference. They are **not** silicon, FPGA or gate-level measurements. No clock frequency, timing closure or power measurement exists for any SilicaFlux design: time-domain values use an **assumed** clock and energy values are **labelled estimates** (see §7).

## 1. Provenance

Every field below is required; a report cannot be generated without them.

| field | value |
|---|---|
| **Source revision** | repository `d1e9176418f3` (branch `claude/bold-albattani-wivan5`; framework has UNCOMMITTED changes); origin: git rev-parse HEAD of the repository containing this framework. Framework tree SHA-256 `6b8b13214aacc283` (162 files). RTL under test: Albion SoC tree `09617ada5789a5c2` (32 files, upstream `silicaflux-albion-p90.zip` sha256 `bc94cfee0574e81b`); ComputeWorks tree `db7d3efa082ab642` (67 files, upstream `silicaflux-computeworks-p88.zip` sha256 `681362703d032a4a`) |
| **Configuration** | `standard` (suite `standard`), config SHA-256 `4df7b4facc076c76`. Reference hardware: sram_banks=4, bank_bytes=16384, dma_depth=4, bus_width_bits=32, dma_burst_bytes=4096, concurrent_masters=4, host_latency_cycles=1, vector_lanes=4, tensor_array=[4, 4], compute_ports=1, compute_mem_width_bits=64, tensor_shape=[16, 16, 64], vector_length=256 |
| **Simulator** | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) - cycle-accurate two-state RTL simulation (zero-delay, no timing, no power). Flags: `--cc --exe --build -O2 --x-assign fast --x-initial unique -Wno-UNUSEDPARAM -Wno-CMPCONST`. Power-up state: randomised (--x-initial unique, VerilatedContext::randReset(2), seeded per run). 12 simulator build(s) (full list with binary SHA-256 in results.json → provenance.simulator.binaries): fabric `bc021ea4`; fabric `e75a5fe7`; fabric `1a9adc68`; fabric `98ba6597` ... |
| **Tool versions** | verilator = Verilator 5.020 2024-01-01 rev (Debian 5.020-1); yosys = Yosys 0.33 (git sha1 2584903a060); iverilog = Icarus Verilog version 12.0 (stable) (); g++ = g++ (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0; clang = Ubuntu clang version 18.1.3 (1ubuntu1); ld.lld = Ubuntu LLD 18.1.3 (compatible with GNU linkers); make = GNU Make 4.3; git = git version 2.43.0; python = 3.13.18; platform = Linux-6.18.44-fc-v595-x86_64-with-glibc2.39; cpu_count = 4; numpy = 2.5.3 |
| **Random seed** | seeds [1, 2, 3] - seed S: stream/address RNGs are seeded from S; Verilator power-up randomisation seed is S+1; deterministic workloads must give identical cycle counts for every seed (checked) |
| **Clock assumptions** | 50.0 MHz, basis **ASSUMED** (P90 FPGA target (50 MHz); P90 place-and-route reached only 19.45 MHz and no timing closure exists). RTL simulation is zero-delay: cycle counts do not depend on frequency. Every value in ns, MB/s, GOPS or W is derived by assuming a 50.0 MHz clock. No SilicaFlux design has timing closure; no silicon or FPGA run exists. |
| **Test workload** | 17 workload families, 171 points: `bus_arbitration` (6), `compute_mem_contention` (3), `concurrent_dma_interference` (2), `concurrent_mem` (7), `dma_bandwidth` (54), `dma_latency` (10), `gemm_int8` (25), `host_dma_roundtrip` (4), `host_mailbox_roundtrip` (1), `host_mmio_latency` (3), `host_port_latency` (4), `sram_bank_conflict` (7), `sram_random` (9), `sram_seq_read` (9), `sram_seq_write` (4), `sram_seq_write_partial` (2), `vector_int32` (21). Declared unavailable: `packet_throughput`, `virtual_block_io`, `albion_integrated_matmul`, `pcie_link_latency`, `silicon_or_fpga_power`, `absolute_gbps_at_signed_off_clock`. Full parameter list per point: results.json → provenance.test_workload. |
| **Firmware** | RV32I ControlCore image sha256 `b1a78635ca2dcd36` built with Ubuntu clang version 18.1.3 (1ubuntu1) |

## 2. Evidence classes and how to read the numbers

| class | meaning | where used |
|---|---|---|
| **rtl-simulation** | cycle-accurate simulation of the real RTL; counts are exact for the stimulus used | all measured tables (§5) |
| **structural model** | prediction derived from RTL/protocol analysis, no constant fitted to benchmark output | Models A, D (§6) |
| **fitted model** | constants least-squares fitted to a named calibration set; validated out of sample | Models C, E, mailbox latency (§6) |
| **ASSUMED clock** | frequency chosen by the user; scales ns, MB/s, mW only | `metrics_at_assumed_clock` |
| **library ESTIMATE** | activity counts x literature per-event energies; dynamic only; NOT measured | §7 and `est. nJ` columns |
| **UNAVAILABLE** | hardware absent from the RTL; probed, never stubbed | §4 |

Latency is first-valid → response in cycles (compute: execution cycles per command). Tail latency is the exact percentile of all transactions where histograms are available. Metrics marked `-` are *not applicable* (never zero). `*` after a point label marks a **blind validation** point (see §6). Pipeline utilisation = accepted requests ÷ (banks touched × cycles) for fabric points, engine-active ÷ in-flight cycles for compute. Window cycles include the final response cycle.

## 3. Key findings

1. **Partial (byte) writes are the SRAM's slow path** - Sequential full-word access reaches 3.999 B/cycle (one word per cycle); byte-strobe writes reach 0.500 B/cycle because each is a read-modify-write that holds the bank two cycles (8x lower byte bandwidth, 2x lower transaction rate). Software should coalesce sub-word stores into full words. *(evidence: `sram_seq_read|base`, `sram_seq_write_partial|base`; class: measured)*
2. **Bank conflicts serialise masters exactly** - 4 masters in ONE bank complete 1.000 txn/cycle (latency 4.00 cycles); in 4 different banks 3.996 txn/cycle (latency 1.00): a 4.0x gap. Placement of concurrently used buffers in different banks is the main software lever; bank 0 is firmware-private, so tenants have NB-1 usable banks. *(evidence: `sram_bank_conflict|same-bank/K=4`, `sram_bank_conflict|distinct-banks/K=4`; class: measured)*
3. **Round-robin arbitration is fair and bounded** - Across 3 saturating-master configurations the minimum Jain fairness index is 1.0000 and the worst accept wait never exceeded K-1 cycles (bound held in every case). Low-rate masters beside a saturating one are not starved (see 'unequal' points). *(evidence: `bus_arbitration|saturating/K=4`, `bus_arbitration|saturating/K=2`, `bus_arbitration|saturating/K=3`; class: measured)*
4. **DMA prefetch FIFO depth: 3 entries already reach full rate** - depth 1: 1.332 B/cycle, depth 2: 2.660 B/cycle, depth 3: 3.981 B/cycle, depth 4: 3.981 B/cycle, depth 6: 3.981 B/cycle, depth 8: 3.981 B/cycle. A word occupies a FIFO slot for a 3-cycle read -> write round trip, so depth >= 3 sustains one word/cycle (Little's law); the shipped depth 4 is one entry deeper than the knee, and depths above 3 gave no measurable bandwidth change on these workloads. Depth 1-2 would cost 3.0x / 1.5x. (Area, power and the error-path prefetch behaviour of a shallower FIFO are not measured here.) *(evidence: `dma_bandwidth|copy_xbank/depth=1`, `dma_bandwidth|copy_xbank/depth=2`, `dma_bandwidth|copy_xbank/depth=3`, `dma_bandwidth|copy_xbank/len=4096`; class: measured)*
5. **Host DMA is latency-bound (one outstanding request)** - L=1: 3.9806 B/cycle, L=4: 0.9988 B/cycle, L=16: 0.2499 B/cycle, L=64: 0.0625 B/cycle - bandwidth equals 4/L. Multiple outstanding tagged reads on the host port (which requires a fabric change, since each master is limited to one outstanding request) are the only way to hide host latency; FIFO depth cannot help. *(evidence: `dma_bandwidth|host_to_sram/len=4096`, `dma_bandwidth|host_to_sram/L=4`, `dma_bandwidth|host_to_sram/L=16`, `dma_bandwidth|host_to_sram/L=64`; class: measured)*
6. **Host command latency is dominated by firmware** - A PING takes a median 384 cycles end to end; 355 cycles (92%) are the ControlCore firmware between doorbell and interrupt (100 instructions); the host's MMIO traffic is only 29 cycles. Small commands are firmware-bound; batching or a descriptor ring would amortise it. *(evidence: `host_mailbox_roundtrip|ping`; class: measured)*
7. **Vector throughput is memory-bound, not lane-bound** - 16x the lanes gives only 1.55x speed-up (Amdahl ceiling 1.61x): load and store phases (12 bytes per element over one 64-bit port) do not overlap compute and do not scale with lanes. A 128-bit memory word or a second compute port helps more than lanes. *(evidence: `vector_int32|add/vl=1024/lanes=1`, `vector_int32|add/vl=1024/lanes=2`, `vector_int32|add/vl=1024/cp=1/dw=64`, `vector_int32|add/vl=1024/lanes=8`; class: measured)*
8. **GEMM leaves most of the array idle because phases do not overlap** - Best MAC utilisation 43.7% (16x16x256); while computing, the array is 96.6% busy, but load is 51% and store 3% of command time. Double-buffering the staging memory is the largest available lever (not built, not measured here). *(evidence: `gemm_int8|16x16x256`; class: measured)*
9. **Roofline classification** - 46 compute points: 2 are compute-bound and 44 memory-bound on the EFFECTIVE (measured-traffic) roof; none reaches its roof (median 47% of the effective roof, 81% of the non-overlapped bound), consistent with the serialised load/compute/store design. *(evidence: models; class: modelled+measured)*

## 4. Hardware availability

| workload | needs | evidence | live-RTL probe |
|---|---|---|---|
| `packet_throughput` | PacketForge (Project 86) | MGMT.FEAT_UNAVAIL bit FEAT_PACKETFORGE and firmware UNSUPPORTED for opcode 0x50 (probed live by the soc backend's feature_probe); no RTL in the repository | FEAT_PACKETFORGE: requested=True, implemented=False; firmware opcode `PKT_CLASSIFY` → `UNSUPPORTED`; **confirmed unavailable: True** |
| `virtual_block_io` | VirtualFoundry (Project 87) | MGMT.FEAT_UNAVAIL bit FEAT_VIRTUALFOUNDRY and firmware UNSUPPORTED for opcode 0x51 (probed); no RTL in the repository | FEAT_VIRTUALFOUNDRY: requested=True, implemented=False; firmware opcode `VBLK_IO` → `UNSUPPORTED`; **confirmed unavailable: True** |
| `albion_integrated_matmul` | ComputeWorks integrated into sf_albion_cloud_top | MGMT.FEAT_UNAVAIL bit FEAT_COMPUTEWORKS and firmware UNSUPPORTED for opcode 0x52 (probed). ComputeWorks RTL exists and IS benchmarked standalone (gemm_int8) but is not wired into the Albion top | FEAT_COMPUTEWORKS: requested=True, implemented=False; firmware opcode `MATMUL_INT8` → `UNSUPPORTED`; **confirmed unavailable: True** |
| `pcie_link_latency` | a PCIe endpoint (licensed IP) | host_if is a transaction-level port; no PCIe PHY/TLP model exists (see docs/albion/known_limitations.md) | - |
| `silicon_or_fpga_power` | silicon or an instrumented FPGA board | none exists; energy is reported only as labelled estimates (see energy.py) | - |
| `absolute_gbps_at_signed_off_clock` | timing closure | no design has closed timing; MB/s values are derived from an assumed clock and labelled as such | - |

RTL notice printed by `sf_albion_cloud_top` CONFIG=2: `[albion] CONFIG 2: requested-but-unavailable features 0x00000700 reported in MGMT.FEAT_UNAVAIL (not instantiated)`

Available and benchmarked: SRAM banks with SECDED (sequential, random, RMW, conflicts), DataFabric arbitration, DMA (fill/copy/host), host MMIO + mailbox with firmware, ComputeWorks INT32 vector and INT8 GEMM **as a standalone tile** (it is not wired into the Albion SoC top).

## 5. Measured results

### Memory (SRAM, random access, bank conflicts, concurrency)

**`sram_seq_read`** - SRAM sequential reads. One master (CORE port) streams sequential 32-bit reads from one SRAM bank (SECDED decode in the path); every word is checked against a shadow memory.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| base | OK | 4,097 | 4,096 | 16,384 | 3.999 | 1.000 | 1.00 | 1 | 1 | 0 | 0 | 1.000 | - | 37.274 | +0.00% |
| nwords=64 | OK | 65 | 64 | 256 | 3.938 | 0.985 | 1.00 | 1 | 1 | 0 | 0 | 0.985 | - | 0.582 | +0.00% |
| nwords=256 | OK | 257 | 256 | 1,024 | 3.984 | 0.996 | 1.00 | 1 | 1 | 0 | 0 | 0.996 | - | 2.330 | +0.00% |
| nwords=1024 | OK | 1,025 | 1,024 | 4,096 | 3.996 | 0.999 | 1.00 | 1 | 1 | 0 | 0 | 0.999 | - | 9.318 | +0.00% |
| nwords=16384 | OK | 16,385 | 16,384 | 65,536 | 4.000 | 1.000 | 1.00 | 1 | 1 | 0 | 0 | 1.000 | - | 149.094 | +0.00% |
| banks=2 | OK | 4,097 | 4,096 | 16,384 | 3.999 | 1.000 | 1.00 | 1 | 1 | 0 | 0 | 1.000 | - | 37.274 | +0.00% |
| banks=8 | OK | 4,097 | 4,096 | 16,384 | 3.999 | 1.000 | 1.00 | 1 | 1 | 0 | 0 | 1.000 | - | 37.274 | +0.00% |
| nwords=100 * | OK | 101 | 100 | 400 | 3.960 | 0.990 | 1.00 | 1 | 1 | 0 | 0 | 0.990 | - | 0.910 | +0.00% |
| nwords=3000 * | OK | 3,001 | 3,000 | 12,000 | 3.999 | 1.000 | 1.00 | 1 | 1 | 0 | 0 | 1.000 | - | 27.300 | +0.00% |

**`sram_seq_write`** - SRAM sequential writes. One master streams sequential full-word writes to one bank (SECDED encode); the written region is read back and verified.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| base | OK | 4,097 | 4,096 | 16,384 | 3.999 | 1.000 | 1.00 | 1 | 1 | 0 | 0 | 1.000 | - | 37.274 | +0.00% |
| nwords=256 | OK | 257 | 256 | 1,024 | 3.984 | 0.996 | 1.00 | 1 | 1 | 0 | 0 | 0.996 | - | 2.330 | +0.00% |
| nwords=16384 | OK | 16,385 | 16,384 | 65,536 | 4.000 | 1.000 | 1.00 | 1 | 1 | 0 | 0 | 1.000 | - | 149.094 | +0.00% |
| banks=8 | OK | 4,097 | 4,096 | 16,384 | 3.999 | 1.000 | 1.00 | 1 | 1 | 0 | 0 | 1.000 | - | 37.274 | +0.00% |

**`sram_seq_write_partial`** - SRAM sequential partial (byte) writes. Byte-strobe writes force the bank's read-modify-write path (ECC decode, merge, re-encode): the architecture's slow write case.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| base | OK | 4,096 | 2,048 | 2,048 | 0.500 | 0.500 | 2.00 | 2 | 2 | 2,047 | 0 | 0.500 | - | 36.045 | +0.00% |
| nwords=777 * | OK | 1,554 | 777 | 777 | 0.500 | 0.500 | 2.00 | 2 | 2 | 776 | 0 | 0.500 | - | 13.675 | +0.00% |

**`sram_random`** - Random memory accesses. K masters issue uniformly random word accesses (30 % writes) over all banks they may legally reach. Throughput is set by random bank collisions.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| masters=1 | OK | 4,097 | 4,096 | 16,384 | 3.999 | 1.000 | 1.00 | 1 | 1 | 0 | 0 | 0.250 | - | 37.274 | +0.00% |
| masters=2 | OK | 4,785 | 8,192 | 32,768 | 6.848 | 1.712 | 1.15 | 2 | 2 | 1,217 | 1,217 | 0.428 | - | 74.547 | -0.21% |
| masters=3 | OK | 5,778 | 12,288 | 49,152 | 8.507 | 2.127 | 1.38 | 3 | 3 | 4,612 | 4,013 | 0.532 | - | 111.821 | -0.04% |
| masters=4 | OK | 6,678 | 16,384 | 65,536 | 9.814 | 2.453 | 1.57 | 4 | 4 | 9,321 | 6,026 | 0.613 | - | 149.094 | +0.64% |
| banks=2/masters=4 | OK | 12,311 | 16,384 | 65,536 | 5.323 | 1.331 | 2.58 | 4 | 4 | 25,843 | 12,309 | 0.665 | - | 149.094 | -0.22% |
| banks=3/masters=4 | OK | 8,113 | 16,384 | 65,536 | 8.078 | 2.019 | 1.86 | 4 | 4 | 14,028 | 7,593 | 0.673 | - | 149.094 | +0.60% |
| banks=8/masters=4 | OK | 5,093 | 16,384 | 65,536 | 12.868 | 3.217 | 1.23 | 3 | 4 | 3,789 | 3,131 | 0.402 | - | 149.094 | +0.28% |
| banks=5/masters=3 * | OK | 3,878 | 9,000 | 36,000 | 9.282 | 2.321 | 1.27 | 3 | 3 | 2,419 | 2,204 | 0.464 | - | 81.900 | +0.28% |
| banks=4/masters=2/n=2500 * | OK | 2,924 | 5,000 | 20,000 | 6.840 | 1.710 | 1.15 | 2 | 2 | 737 | 737 | 0.428 | - | 45.500 | -0.19% |

**`sram_bank_conflict`** - SRAM bank conflicts. K masters read sequentially, either all in the SAME bank (single-port bank: conflicts) or each in its OWN bank (conflict-free reference).

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| same-bank/K=2 | OK | 2,049 | 2,048 | 8,192 | 3.998 | 1.000 | 2.00 | 2 | 2 | 2,047 | 2,047 | 1.000 | - | 18.637 | +0.00% |
| distinct-banks/K=2 | OK | 1,025 | 2,048 | 8,192 | 7.992 | 1.998 | 1.00 | 1 | 1 | 0 | 0 | 0.999 | - | 18.637 | +0.00% |
| same-bank/K=3 | OK | 3,073 | 3,072 | 12,288 | 3.999 | 1.000 | 3.00 | 3 | 3 | 6,141 | 3,071 | 1.000 | - | 27.955 | +0.00% |
| distinct-banks/K=3 | OK | 1,025 | 3,072 | 12,288 | 11.988 | 2.997 | 1.00 | 1 | 1 | 0 | 0 | 0.999 | - | 27.955 | +0.00% |
| same-bank/K=4 | OK | 4,097 | 4,096 | 16,384 | 3.999 | 1.000 | 4.00 | 4 | 4 | 12,282 | 4,095 | 1.000 | - | 37.274 | +0.00% |
| distinct-banks/K=4 | OK | 1,025 | 4,096 | 16,384 | 15.984 | 3.996 | 1.00 | 1 | 1 | 0 | 0 | 0.999 | - | 37.274 | +0.00% |
| same-bank/K=3/n=500 * | OK | 1,501 | 1,500 | 6,000 | 3.997 | 0.999 | 3.00 | 3 | 3 | 2,997 | 1,499 | 0.999 | - | 13.650 | +0.00% |

**`concurrent_mem`** - Concurrent memory access. K masters issue random mixed traffic to all legal banks simultaneously: aggregate throughput versus the K-port ideal.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| K=4 | OK | 3,337 | 8,192 | 32,768 | 9.820 | 2.455 | 1.56 | 4 | 4 | 4,619 | 3,002 | 0.614 | - | 74.547 | +0.70% |
| K=1 | OK | 2,049 | 2,048 | 8,192 | 3.998 | 1.000 | 1.00 | 1 | 1 | 0 | 0 | 0.250 | - | 18.637 | +0.00% |
| K=2 | OK | 2,400 | 4,096 | 16,384 | 6.826 | 1.706 | 1.15 | 2 | 2 | 615 | 615 | 0.427 | - | 37.274 | -0.44% |
| K=3 | OK | 2,903 | 6,144 | 24,576 | 8.467 | 2.117 | 1.38 | 3 | 3 | 2,320 | 2,018 | 0.529 | - | 55.910 | -0.09% |
| banks=2/K=4 | OK | 6,175 | 8,192 | 32,768 | 5.306 | 1.327 | 2.59 | 4 | 4 | 13,017 | 6,173 | 0.663 | - | 74.547 | -0.58% |
| banks=3/K=4 | OK | 4,061 | 8,192 | 32,768 | 8.069 | 2.017 | 1.86 | 4 | 4 | 7,020 | 3,799 | 0.672 | - | 74.547 | +0.41% |
| banks=8/K=4 | OK | 2,554 | 8,192 | 32,768 | 12.829 | 3.207 | 1.23 | 3 | 4 | 1,913 | 1,581 | 0.401 | - | 74.547 | +0.21% |

**`concurrent_dma_interference`** - DMA with a concurrent CORE reader. A DMA copy (bank1 -> bank2) runs while the CORE streams reads from the DMA's source bank (same) or from a bank the DMA does not touch (distinct).

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| same-bank | OK | 4,100 | 2,048 | 8,192 | 1.998 | 0.500 | 1.50 | 2 | 2 | 2,047 | 4,095 | 0.750 | - | 56.775 | +0.00% |
| distinct-bank | OK | 2,053 | 2,048 | 8,192 | 3.990 | 0.998 | 1.00 | 1 | 1 | 0 | 0 | 0.999 | - | 56.784 | +0.00% |

### Bus arbitration

**`bus_arbitration`** - Bus arbitration (fairness, starvation, tail wait). K saturating masters share one bank under the per-slave round-robin arbiter: per-master share, Jain fairness, worst grant wait. 'unequal' adds low-rate masters beside a saturating one to prove they are not starved.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| saturating/K=4 | OK | 4,097 | 4,096 | 16,384 | 3.999 | 1.000 | 4.00 | 4 | 4 | 12,282 | 4,095 | 1.000 | - | 37.274 | +0.00% |
| saturating/K=2 | OK | 2,049 | 2,048 | 8,192 | 3.998 | 1.000 | 2.00 | 2 | 2 | 2,047 | 2,047 | 1.000 | - | 18.637 | +0.00% |
| saturating/K=3 | OK | 3,073 | 3,072 | 12,288 | 3.999 | 1.000 | 3.00 | 3 | 3 | 6,141 | 3,071 | 1.000 | - | 27.955 | +0.00% |
| unequal/K=2 | OK | 1,153 | 1,152 | 4,608 | 3.997 | 0.999 | 1.11 | 2 | 2 | 128 | 128 | 0.999 | - | 10.483 | +0.00% |
| unequal/K=4 | OK | 1,409 | 1,408 | 5,632 | 3.997 | 0.999 | 1.27 | 4 | 4 | 387 | 384 | 0.999 | - | 12.813 | +0.00% |
| unequal/K=3 * | OK | 1,001 | 1,000 | 4,000 | 3.996 | 0.999 | 1.20 | 3 | 3 | 201 | 200 | 0.999 | - | 9.100 | +0.00% |

### DMA bandwidth and latency

**`dma_bandwidth`** - DMA bandwidth. One DMA descriptor of a given length: fill, SRAM->SRAM (cross-bank / same-bank), host->SRAM, SRAM->host. Result verified word-by-word; reported against the DMA_CYCLES register of the RTL.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| fill/len=4096 | OK | 1,027 | 1,024 | 4,096 | 3.988 | 0.997 | 1.00 | 1 | 1 | 0 | 0 | 0.997 | - | 9.318 | +0.00% |
| copy_xbank/len=4096 | OK | 1,029 | 1,024 | 4,096 | 3.981 | 0.995 | 1.00 | 1 | 1 | 0 | 0 | 0.995 | - | 19.046 | +0.00% |
| copy_samebank/len=4096 | OK | 2,051 | 1,024 | 4,096 | 1.997 | 0.499 | 2.00 | 2 | 2 | 2,044 | 2,044 | 0.999 | - | 19.046 | +0.00% |
| host_to_sram/len=4096 | OK | 1,029 | 1,024 | 4,096 | 3.981 | 0.995 | 1.00 | 1 | 1 | 0 | 0 | 0.995 | - | 11.366 | +0.00% |
| sram_to_host/len=4096 | OK | 1,029 | 1,024 | 4,096 | 3.981 | 0.995 | 1.00 | 1 | 1 | 0 | 0 | 0.995 | - | 11.366 | +0.00% |
| fill/len=64 | OK | 19 | 16 | 64 | 3.368 | 0.842 | 1.00 | 1 | 1 | 0 | 0 | 0.842 | - | 0.146 | +0.00% |
| fill/len=256 | OK | 67 | 64 | 256 | 3.821 | 0.955 | 1.00 | 1 | 1 | 0 | 0 | 0.955 | - | 0.582 | +0.00% |
| fill/len=1024 | OK | 259 | 256 | 1,024 | 3.954 | 0.988 | 1.00 | 1 | 1 | 0 | 0 | 0.988 | - | 2.330 | +0.00% |
| fill/len=16384 | OK | 4,099 | 4,096 | 16,384 | 3.997 | 0.999 | 1.00 | 1 | 1 | 0 | 0 | 0.999 | - | 37.274 | +0.00% |
| copy_xbank/len=64 | OK | 21 | 16 | 64 | 3.048 | 0.762 | 1.00 | 1 | 1 | 0 | 0 | 0.762 | - | 0.298 | +0.00% |
| copy_xbank/len=256 | OK | 69 | 64 | 256 | 3.710 | 0.928 | 1.00 | 1 | 1 | 0 | 0 | 0.928 | - | 1.190 | +0.00% |
| copy_xbank/len=1024 | OK | 261 | 256 | 1,024 | 3.923 | 0.981 | 1.00 | 1 | 1 | 0 | 0 | 0.981 | - | 4.762 | +0.00% |
| copy_xbank/len=8192 | OK | 2,053 | 2,048 | 8,192 | 3.990 | 0.998 | 1.00 | 1 | 1 | 0 | 0 | 0.998 | - | 38.093 | +0.00% |
| host_to_sram/len=64 | OK | 21 | 16 | 64 | 3.048 | 0.762 | 1.00 | 1 | 1 | 0 | 0 | 0.762 | - | 0.178 | +0.00% |
| host_to_sram/len=256 | OK | 69 | 64 | 256 | 3.710 | 0.928 | 1.00 | 1 | 1 | 0 | 0 | 0.928 | - | 0.710 | +0.00% |
| host_to_sram/len=1024 | OK | 261 | 256 | 1,024 | 3.923 | 0.981 | 1.00 | 1 | 1 | 0 | 0 | 0.981 | - | 2.842 | +0.00% |
| copy_samebank/len=64 | OK | 35 | 16 | 64 | 1.829 | 0.457 | 1.88 | 2 | 2 | 28 | 28 | 0.914 | - | 0.298 | +0.00% |
| copy_samebank/len=256 | OK | 131 | 64 | 256 | 1.954 | 0.489 | 1.97 | 2 | 2 | 124 | 124 | 0.977 | - | 1.190 | +0.00% |
| copy_samebank/len=1024 | OK | 515 | 256 | 1,024 | 1.988 | 0.497 | 1.99 | 2 | 2 | 508 | 508 | 0.994 | - | 4.762 | +0.00% |
| copy_samebank/len=2048 | OK | 1,027 | 512 | 2,048 | 1.994 | 0.499 | 2.00 | 2 | 2 | 1,020 | 1,020 | 0.997 | - | 9.523 | +0.00% |
| host_to_sram/L=4 | OK | 4,101 | 1,024 | 4,096 | 0.999 | 0.250 | 2.50 | 4 | 4 | 0 | 0 | 0.250 | - | 11.366 | +0.00% |
| sram_to_host/L=4 | OK | 4,101 | 1,024 | 4,096 | 0.999 | 0.250 | 2.50 | 4 | 4 | 0 | 0 | 0.250 | - | 11.366 | +0.00% |
| host_to_sram/L=16 | OK | 16,389 | 1,024 | 4,096 | 0.250 | 0.062 | 8.50 | 16 | 16 | 0 | 0 | 0.062 | - | 11.366 | +0.00% |
| sram_to_host/L=16 | OK | 16,389 | 1,024 | 4,096 | 0.250 | 0.062 | 8.50 | 16 | 16 | 0 | 0 | 0.062 | - | 11.366 | +0.00% |
| host_to_sram/L=64 | OK | 65,541 | 1,024 | 4,096 | 0.062 | 0.016 | 32.50 | 64 | 64 | 0 | 0 | 0.016 | - | 11.366 | +0.00% |
| sram_to_host/L=64 | OK | 65,541 | 1,024 | 4,096 | 0.062 | 0.016 | 32.50 | 64 | 64 | 0 | 0 | 0.016 | - | 11.366 | +0.00% |
| copy_xbank/depth=1 | OK | 3,075 | 1,024 | 4,096 | 1.332 | 0.333 | 1.00 | 1 | 1 | 0 | 0 | 0.333 | - | 19.046 | +0.00% |
| host_to_sram/L=4/depth=1 | OK | 6,147 | 1,024 | 4,096 | 0.666 | 0.167 | 2.50 | 4 | 4 | 0 | 0 | 0.167 | - | 11.366 | +0.00% |
| copy_xbank/depth=2 | OK | 1,540 | 1,024 | 4,096 | 2.660 | 0.665 | 1.00 | 1 | 1 | 0 | 0 | 0.665 | - | 19.046 | +0.03% |
| host_to_sram/L=4/depth=2 | OK | 4,101 | 1,024 | 4,096 | 0.999 | 0.250 | 2.50 | 4 | 4 | 0 | 0 | 0.250 | - | 11.366 | +0.00% |
| copy_xbank/depth=3 | OK | 1,029 | 1,024 | 4,096 | 3.981 | 0.995 | 1.00 | 1 | 1 | 0 | 0 | 0.995 | - | 19.046 | +0.00% |
| host_to_sram/L=4/depth=3 | OK | 4,101 | 1,024 | 4,096 | 0.999 | 0.250 | 2.50 | 4 | 4 | 0 | 0 | 0.250 | - | 11.366 | +0.00% |
| copy_xbank/depth=6 | OK | 1,029 | 1,024 | 4,096 | 3.981 | 0.995 | 1.00 | 1 | 1 | 0 | 0 | 0.995 | - | 19.046 | +0.00% |
| host_to_sram/L=4/depth=6 | OK | 4,101 | 1,024 | 4,096 | 0.999 | 0.250 | 2.50 | 4 | 4 | 0 | 0 | 0.250 | - | 11.366 | +0.00% |
| copy_xbank/depth=8 | OK | 1,029 | 1,024 | 4,096 | 3.981 | 0.995 | 1.00 | 1 | 1 | 0 | 0 | 0.995 | - | 19.046 | +0.00% |
| host_to_sram/L=4/depth=8 | OK | 4,101 | 1,024 | 4,096 | 0.999 | 0.250 | 2.50 | 4 | 4 | 0 | 0 | 0.250 | - | 11.366 | +0.00% |
| copy_xbank/depth=4/L=1/banks=8 | OK | 1,029 | 1,024 | 4,096 | 3.981 | 0.995 | 1.00 | 1 | 1 | 0 | 0 | 0.995 | - | 19.046 | +0.00% |
| copy_xbank/banks=3 | OK | 1,029 | 1,024 | 4,096 | 3.981 | 0.995 | 1.00 | 1 | 1 | 0 | 0 | 0.995 | - | 19.046 | +0.00% |
| fill/len=8192 | OK | 2,051 | 2,048 | 8,192 | 3.994 | 0.999 | 1.00 | 1 | 1 | 0 | 0 | 0.999 | - | 18.637 | +0.00% |
| copy_samebank/len=8192 | OK | 4,099 | 2,048 | 8,192 | 1.999 | 0.500 | 2.00 | 2 | 2 | 4,092 | 4,092 | 0.999 | - | 38.093 | +0.00% |
| fill/len=12 * | OK | 6 | 3 | 12 | 2.000 | 0.500 | 1.00 | 1 | 1 | 0 | 0 | 0.500 | - | 0.027 | +0.00% |
| fill/len=100 * | OK | 28 | 25 | 100 | 3.571 | 0.893 | 1.00 | 1 | 1 | 0 | 0 | 0.893 | - | 0.228 | +0.00% |
| fill/len=3000 * | OK | 753 | 750 | 3,000 | 3.984 | 0.996 | 1.00 | 1 | 1 | 0 | 0 | 0.996 | - | 6.825 | +0.00% |
| copy_xbank/len=36 * | OK | 14 | 9 | 36 | 2.571 | 0.643 | 1.00 | 1 | 1 | 0 | 0 | 0.643 | - | 0.167 | +0.00% |
| copy_xbank/len=700 * | OK | 180 | 175 | 700 | 3.889 | 0.972 | 1.00 | 1 | 1 | 0 | 0 | 0.972 | - | 3.255 | +0.00% |
| copy_xbank/len=5000 * | OK | 1,255 | 1,250 | 5,000 | 3.984 | 0.996 | 1.00 | 1 | 1 | 0 | 0 | 0.996 | - | 23.250 | +0.00% |
| copy_samebank/len=900 * | OK | 453 | 225 | 900 | 1.987 | 0.497 | 1.99 | 2 | 2 | 446 | 446 | 0.993 | - | 4.185 | +0.00% |
| host_to_sram/L=2/len=1200 * | OK | 605 | 300 | 1,200 | 1.983 | 0.496 | 1.50 | 2 | 2 | 0 | 0 | 0.496 | - | 3.330 | +0.00% |
| host_to_sram/L=7/len=1200 * | OK | 2,105 | 300 | 1,200 | 0.570 | 0.143 | 4.00 | 7 | 7 | 0 | 0 | 0.143 | - | 3.330 | +0.00% |
| host_to_sram/L=33/len=1200 * | OK | 9,905 | 300 | 1,200 | 0.121 | 0.030 | 17.00 | 33 | 33 | 0 | 0 | 0.030 | - | 3.330 | +0.00% |
| sram_to_host/L=3/len=800 * | OK | 605 | 200 | 800 | 1.322 | 0.331 | 2.00 | 3 | 3 | 0 | 0 | 0.331 | - | 2.220 | +0.00% |
| copy_xbank/depth=2/len=5000 * | OK | 1,879 | 1,250 | 5,000 | 2.661 | 0.665 | 1.00 | 1 | 1 | 0 | 0 | 0.665 | - | 23.250 | +0.03% |
| host_to_sram/L=7/depth=1/len=900 * | OK | 2,028 | 225 | 900 | 0.444 | 0.111 | 4.00 | 7 | 7 | 0 | 0 | 0.111 | - | 2.498 | +0.00% |
| host_to_sram/L=3/depth=2/len=2000 * | OK | 1,505 | 500 | 2,000 | 1.329 | 0.332 | 2.00 | 3 | 3 | 0 | 0 | 0.332 | - | 5.550 | +0.00% |

**`dma_latency`** - DMA latency. Small descriptors: cycles from the CTRL start write to completion, and to the first write beat. Exposes the fixed per-descriptor cost.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| fill/len=4 | OK | 4 | 1 | 4 | 1.000 | 0.250 | 1.00 | 1 | 1 | 0 | 0 | 0.250 | - | 0.009 | +0.00% |
| fill/len=64 | OK | 19 | 16 | 64 | 3.368 | 0.842 | 1.00 | 1 | 1 | 0 | 0 | 0.842 | - | 0.146 | +0.00% |
| copy_xbank/len=4 | OK | 6 | 1 | 4 | 0.667 | 0.167 | 1.00 | 1 | 1 | 0 | 0 | 0.167 | - | 0.019 | +0.00% |
| copy_xbank/len=64 | OK | 21 | 16 | 64 | 3.048 | 0.762 | 1.00 | 1 | 1 | 0 | 0 | 0.762 | - | 0.298 | +0.00% |
| host_to_sram/len=4 | OK | 6 | 1 | 4 | 0.667 | 0.167 | 1.00 | 1 | 1 | 0 | 0 | 0.167 | - | 0.011 | +0.00% |
| host_to_sram/len=64 | OK | 21 | 16 | 64 | 3.048 | 0.762 | 1.00 | 1 | 1 | 0 | 0 | 0.762 | - | 0.178 | +0.00% |
| fill/len=16 | OK | 7 | 4 | 16 | 2.286 | 0.571 | 1.00 | 1 | 1 | 0 | 0 | 0.571 | - | 0.036 | +0.00% |
| copy_xbank/len=16 | OK | 9 | 4 | 16 | 1.778 | 0.444 | 1.00 | 1 | 1 | 0 | 0 | 0.444 | - | 0.074 | +0.00% |
| host_to_sram/len=64/L=4 | OK | 69 | 16 | 64 | 0.928 | 0.232 | 2.50 | 4 | 4 | 0 | 0 | 0.232 | - | 0.178 | +0.00% |
| host_to_sram/len=64/L=16 | OK | 261 | 16 | 64 | 0.245 | 0.061 | 8.50 | 16 | 16 | 0 | 0 | 0.061 | - | 0.178 | +0.00% |

### Host transactions

**`host_port_latency`** - HOST-port transaction latency under load. The HOST master (the path a PCIe BAR drives) reads SRAM while B background masters hammer the same bank: mean and tail latency of host transactions.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| background=0 | OK | 513 | 512 | 2,048 | 3.992 | 0.998 | 1.00 | 1 | 1 | 0 | 0 | 0.998 | - | 4.659 | - |
| background=3 | OK | 2,048 | 512 | 2,048 | 1.000 | 0.250 | 4.00 | 4 | 4 | 1,535 | 2,048 | 1.000 | - | 18.637 | - |
| background=1 | OK | 1,024 | 512 | 2,048 | 2.000 | 0.500 | 2.00 | 2 | 2 | 511 | 1,023 | 1.000 | - | 9.318 | - |
| background=2 | OK | 1,536 | 512 | 2,048 | 1.333 | 0.333 | 3.00 | 3 | 3 | 1,023 | 1,536 | 1.000 | - | 13.978 | - |

**`host_mmio_latency`** - Host MMIO round trip (unmodified sf_albion_cloud_top). Host MMIO read / write latency through the real fabric, MMIO block and MGMT registers, idle and while a firmware DMA is running.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| read-idle | OK | 130 | 64 | 256 | 1.969 | 0.492 | 2.03 | 3 | 3 | 2 | - | - | - | 0.115 | - |
| write-idle | OK | 130 | 64 | 256 | 1.969 | 0.492 | 2.03 | 3 | 3 | 2 | - | - | - | 0.115 | - |
| read-under-dma | OK | 134 | 64 | 256 | 1.910 | 0.478 | 2.09 | 3 | 3 | 6 | - | - | - | 0.115 | - |

**`host_mailbox_roundtrip`** - Host -> firmware -> host mailbox round trip. PING command: host MMIO writes + doorbell, ControlCore firmware, completion, IRQ, host reads. Median and tail over repeated commands.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ping | OK | 6,181 | 16 | 960 | 0.155 | 0.003 | 386.31 | 421 | 421 | - | - | - | - | 48.629 | - |

**`host_dma_roundtrip`** - Host DMA command round trip. DMA_FILL commands through the firmware path: end-to-end cycles versus the bare-DMA descriptor cost (firmware overhead).

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| fill-64B | OK | 5,942 | 8 | 512 | 0.086 | 0.001 | 742.75 | 743 | 743 | - | - | - | - | 48.745 | - |
| fill-1KiB | OK | 7,790 | 8 | 8,192 | 1.052 | 0.001 | 973.75 | 974 | 974 | - | - | - | - | 48.745 | - |
| fill-256B * | OK | 6,254 | 8 | 2,048 | 0.327 | 0.001 | 781.75 | 782 | 782 | - | - | - | - | 48.745 | - |
| fill-4KiB * | OK | 13,934 | 8 | 32,768 | 2.352 | 0.001 | 1,742 | 1,742 | 1,742 | - | - | - | - | 48.745 | - |

### Compute (integer vector arithmetic, matrix multiplication)

**`vector_int32`** - Integer vector arithmetic (INT32 VADD / VMUL). ComputeWorks vector engine on INT32 operands, results checked bit-exactly against an independent integer model.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| add/vl=256 | OK | 3,931 | 2,048 | 24,576 | 6.252 | 0.002 | 490.00 | 490 | 490 | 0 | 0 | 0.141 | 0.131 | 43.213 | - |
| add/vl=16 | OK | 571 | 128 | 1,536 | 2.690 | 0.014 | 70.00 | 70 | 70 | 0 | 0 | 0.129 | 0.057 | 2.701 | - |
| add/vl=64 | OK | 1,243 | 512 | 6,144 | 4.943 | 0.006 | 154.00 | 154 | 154 | 0 | 0 | 0.136 | 0.104 | 10.803 | - |
| add/vl=1024 | OK | 15,403 | 8,192 | 98,304 | 6.382 | 0.001 | 1,924 | 1,924 | 1,924 | 0 | 0 | 0.143 | 0.133 | 172.851 | - |
| mul/vl=256 | OK | 3,939 | 2,048 | 24,576 | 6.239 | 0.002 | 491.00 | 491 | 491 | 0 | 0 | 0.143 | 0.130 | 49.357 | - |
| add/vl=1024/lanes=1 | OK | 21,547 | 8,192 | 98,304 | 4.562 | 0.000 | 2,692 | 2,692 | 2,692 | 0 | 0 | 0.388 | 0.380 | 172.851 | - |
| add/vl=1024/lanes=2 | OK | 17,451 | 8,192 | 98,304 | 5.633 | 0.000 | 2,180 | 2,180 | 2,180 | 0 | 0 | 0.244 | 0.235 | 172.851 | - |
| add/vl=1024/lanes=8 | OK | 14,379 | 8,192 | 98,304 | 6.837 | 0.001 | 1,796 | 1,796 | 1,796 | 0 | 0 | 0.082 | 0.071 | 172.851 | - |
| add/vl=1024/lanes=16 | OK | 13,867 | 8,192 | 98,304 | 7.089 | 0.001 | 1,732 | 1,732 | 1,732 | 0 | 0 | 0.048 | 0.037 | 172.851 | - |
| add/vl=1024/lanes=4 | OK | 15,403 | 8,192 | 98,304 | 6.382 | 0.001 | 1,924 | 1,924 | 1,924 | 0 | 0 | 0.143 | 0.133 | 172.851 | - |
| add/vl=1024/cp=1/dw=128 | OK | 9,259 | 8,192 | 98,304 | 10.617 | 0.001 | 1,156 | 1,156 | 1,156 | 0 | 0 | 0.239 | 0.221 | 172.851 | - |
| add/vl=1024/cp=2/dw=64 | OK | 11,147 | 8,192 | 98,304 | 8.819 | 0.001 | 1,392 | 1,392 | 1,392 | 32 | 32 | 0.198 | 0.184 | 172.851 | - |
| add/vl=1024/cp=2/dw=128 | OK | 7,051 | 8,192 | 98,304 | 13.942 | 0.001 | 880.00 | 880 | 880 | 32 | 32 | 0.314 | 0.291 | 172.851 | - |
| add/vl=1024/cp=1/dw=64 | OK | 15,403 | 8,192 | 98,304 | 6.382 | 0.001 | 1,924 | 1,924 | 1,924 | 0 | 0 | 0.143 | 0.133 | 172.851 | - |
| add/vl=100 * | OK | 1,747 | 800 | 9,600 | 5.495 | 0.005 | 217.00 | 217 | 217 | 0 | 0 | 0.138 | 0.115 | 16.880 | - |
| add/vl=300 * | OK | 4,787 | 2,400 | 28,800 | 6.016 | 0.002 | 597.00 | 597 | 597 | 0 | 0 | 0.142 | 0.126 | 50.640 | - |
| add/vl=700 * | OK | 10,627 | 5,600 | 67,200 | 6.324 | 0.001 | 1,327 | 1,327 | 1,327 | 0 | 0 | 0.143 | 0.132 | 118.160 | - |
| add/vl=1500 * | OK | 22,547 | 12,000 | 144,000 | 6.387 | 0.000 | 2,817 | 2,817 | 2,817 | 0 | 0 | 0.144 | 0.133 | 253.200 | - |
| mul/vl=700/lanes=2 * | OK | 12,051 | 5,600 | 67,200 | 5.576 | 0.001 | 1,505 | 1,505 | 1,505 | 0 | 0 | 0.245 | 0.233 | 134.960 | - |
| add/vl=700/lanes=8 * | OK | 9,931 | 5,600 | 67,200 | 6.767 | 0.001 | 1,240 | 1,240 | 1,240 | 0 | 0 | 0.083 | 0.071 | 118.160 | - |
| add/vl=300/dw=128 * | OK | 2,987 | 2,400 | 28,800 | 9.642 | 0.003 | 372.00 | 372 | 372 | 0 | 0 | 0.228 | 0.202 | 50.640 | - |

**`gemm_int8`** - Matrix multiplication (INT8 GEMM, INT32 accumulate). ComputeWorks systolic-array GEMM, results checked bit-exactly against a plain-integer reference.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 16x16x64 | OK | 22,827 | 262,144 | 81,920 | 3.589 | 0.000 | 2,852 | 2,852 | 2,852 | 0 | 0 | 0.410 | 0.359 | 182.682 | - |
| 4x4x4 | OK | 571 | 1,024 | 1,024 | 1.793 | 0.014 | 70.00 | 70 | 70 | 0 | 0 | 0.186 | 0.057 | 1.946 | - |
| 4x4x16 | OK | 795 | 4,096 | 2,048 | 2.576 | 0.010 | 98.00 | 98 | 98 | 0 | 0 | 0.255 | 0.163 | 4.198 | - |
| 4x4x64 | OK | 1,755 | 16,384 | 6,656 | 3.793 | 0.005 | 218.00 | 218 | 218 | 0 | 0 | 0.335 | 0.294 | 14.106 | - |
| 4x4x256 | OK | 5,595 | 65,536 | 25,088 | 4.484 | 0.001 | 698.00 | 698 | 698 | 0 | 0 | 0.380 | 0.367 | 53.734 | - |
| 8x8x64 | OK | 6,091 | 65,536 | 22,528 | 3.699 | 0.001 | 760.00 | 760 | 760 | 0 | 0 | 0.384 | 0.337 | 49.254 | - |
| 16x16x256 | OK | 75,051 | 1,048,576 | 303,104 | 4.039 | 0.000 | 9,380 | 9,380 | 9,380 | 0 | 0 | 0.452 | 0.437 | 687.718 | - |
| 32x32x64 | OK | 88,555 | 1,048,576 | 311,296 | 3.515 | 0.000 | 11,068 | 11,068 | 11,068 | 0 | 0 | 0.422 | 0.370 | 702.054 | - |
| 16x16x64/array=2x2 | OK | 81,387 | 262,144 | 278,528 | 3.422 | 0.000 | 10,172 | 10,172 | 10,172 | 0 | 0 | 0.434 | 0.403 | 526.746 | - |
| 16x16x64/array=4x2 | OK | 42,795 | 262,144 | 147,456 | 3.446 | 0.000 | 5,348 | 5,348 | 5,348 | 0 | 0 | 0.425 | 0.383 | 297.370 | - |
| 16x16x64/array=8x8 | OK | 7,755 | 262,144 | 32,768 | 4.225 | 0.001 | 968.00 | 968 | 968 | 0 | 0 | 0.335 | 0.264 | 96.666 | - |
| 16x16x64/cp=1/dw=128 | OK | 21,803 | 262,144 | 147,456 | 6.763 | 0.000 | 2,724 | 2,724 | 2,724 | 0 | 0 | 0.429 | 0.376 | 297.370 | - |
| 16x16x64/cp=2/dw=64 | OK | 22,092 | 262,144 | 81,920 | 3.708 | 0.000 | 2,760 | 2,761 | 2,761 | 512 | 512 | 0.423 | 0.371 | 182.682 | - |
| 16x16x64/cp=2/dw=128 | OK | 21,131 | 262,144 | 147,456 | 6.978 | 0.000 | 2,640 | 2,640 | 2,640 | 32 | 32 | 0.442 | 0.388 | 297.370 | - |
| 5x7x9 * | OK | 2,035 | 5,040 | 4,992 | 2.453 | 0.004 | 253.00 | 253 | 253 | 8 | 0 | 0.253 | 0.078 | 9.492 | - |
| 10x6x30 * | OK | 5,347 | 28,800 | 17,856 | 3.339 | 0.001 | 667.00 | 667 | 667 | 0 | 0 | 0.336 | 0.169 | 35.568 | - |
| 12x20x100 * | OK | 30,299 | 384,000 | 113,664 | 3.751 | 0.000 | 3,786 | 3,786 | 3,786 | 0 | 0 | 0.432 | 0.396 | 256.512 | - |
| 7x9x33 * | OK | 5,883 | 33,264 | 20,608 | 3.503 | 0.001 | 734.00 | 734 | 734 | 48 | 0 | 0.331 | 0.177 | 41.054 | - |
| 20x12x50 * | OK | 18,267 | 192,000 | 64,640 | 3.539 | 0.000 | 2,282 | 2,282 | 2,282 | 0 | 0 | 0.388 | 0.329 | 141.920 | - |
| 6x5x3 * | OK | 1,555 | 1,440 | 2,752 | 1.770 | 0.005 | 193.00 | 193 | 193 | 0 | 0 | 0.197 | 0.029 | 5.032 | - |
| 3x3x2 * | OK | 507 | 288 | 704 | 1.389 | 0.016 | 62.00 | 62 | 62 | 16 | 0 | 0.145 | 0.018 | 1.275 | - |
| 9x9x40/array=2x2 * | OK | 23,139 | 51,840 | 77,184 | 3.336 | 0.000 | 2,891 | 2,891 | 2,891 | 0 | 0 | 0.386 | 0.280 | 142.848 | - |
| 10x10x24/array=8x8 * | OK | 3,787 | 38,400 | 13,568 | 3.583 | 0.002 | 472.00 | 472 | 472 | 0 | 0 | 0.297 | 0.079 | 29.504 | - |
| 6x5x17/array=4x2 * | OK | 3,579 | 8,160 | 9,728 | 2.718 | 0.002 | 446.00 | 446 | 446 | 16 | 0 | 0.305 | 0.143 | 18.248 | - |
| 12x12x48/dw=128 * | OK | 10,043 | 110,592 | 64,512 | 6.424 | 0.001 | 1,254 | 1,254 | 1,254 | 0 | 0 | 0.409 | 0.344 | 129.485 | - |

**`compute_mem_contention`** - Compute tile under concurrent memory traffic. GEMM while a DMA stand-in master hammers the same SRAM banks at a given duty cycle.

| point | status | cycles | ops | bytes | B/cycle | txn/cycle | lat avg | p99 | max | stalls | conflicts | pipe util | compute util | est. nJ | model err |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 16x16x64/bg=50% | OK | 23,205 | 262,144 | 81,920 | 3.530 | 0.000 | 2,899 | 2,905 | 2,905 | 371 | 396 | 0.403 | 0.353 | 182.682 | - |
| 16x16x64/bg=95% | OK | 23,263 | 262,144 | 81,920 | 3.521 | 0.000 | 2,906 | 2,925 | 2,925 | 423 | 459 | 0.402 | 0.352 | 182.682 | - |
| 16x16x64/bg=0% | OK | 22,827 | 262,144 | 81,920 | 3.589 | 0.000 | 2,852 | 2,852 | 2,852 | 0 | 0 | 0.410 | 0.359 | 182.682 | - |

### Time-domain view at the ASSUMED clock

At an **assumed 50.0 MHz** (not a measured or signed-off clock):

| point | bandwidth MB/s | latency avg ns | latency p99 ns | window µs |
|---|---:|---:|---:|---:|
| sram_seq_read\|base | 200.0 | 20.0 | 20.0 | 81.94 |
| sram_seq_write\|base | 200.0 | 20.0 | 20.0 | 81.94 |
| sram_seq_write_partial\|base | 25.0 | 40.0 | 40.0 | 81.92 |
| dma_bandwidth\|copy_xbank/len=4096 | 199.0 | 20.0 | 20.0 | 20.58 |
| dma_bandwidth\|host_to_sram/len=4096 | 199.0 | 20.0 | 20.0 | 20.58 |
| vector_int32\|add/vl=256 | 312.6 | 9,800 | 9,800 | 78.62 |
| gemm_int8\|16x16x64 | 179.4 | 57,040 | 57,040 | 456.54 |
| host_mmio_latency\|read-idle | 98.5 | 40.6 | 60.0 | 2.60 |
| host_mailbox_roundtrip\|ping | 7.8 | 7,726 | 8,420 | 123.62 |

## 6. Performance models: predicted vs RTL simulation

Five models predict RTL results from architecture parameters. Each prediction is compared with the measured value; a comparison is *within tolerance* if |predicted − measured| ≤ max(absolute tolerance, percent tolerance × measured) with percent tolerance {"structural": 1.0, "structural-approx": 5.0, "fitted": 3.0, "monte-carlo": 5.0} by basis. **Only out-of-sample points count as validation.** *In-sample* = a point used to fix a constant. *Blind validation* points (marked `*`) were added after the models were written and were never used to design or calibrate them.

**Out-of-sample: 827 of 830 comparisons within tolerance** (median |error| 0.000%, max 9.09%); in-sample: 62 of 62.

| model | out-of-sample within tolerance | median abs err % | max abs err % | blind-validation subset |
|---|---:|---:|---:|---:|
| **A** Memory bandwidth model | 342/342 | 0.000 | 2.28 | 67/67 |
| **C** Accelerator utilisation model | 131/132 | 0.000 | 9.09 | 71/72 |
| **D** Transaction-latency model | 332/334 | 0.000 | 6.67 | 62/62 |
| **E** Workload scaling model | 22/22 | 0.000 | 1.81 | 13/13 |
| **B** Roofline model | see below | - | - | - |

| basis | n (out-of-sample) | within | median abs err % | max abs err % |
|---|---:|---:|---:|---:|
| fitted | 124 | 124 | 0.000 | 2.07 |
| monte-carlo | 112 | 112 | 0.178 | 2.28 |
| structural | 561 | 559 | 0.000 | 6.67 |
| structural-approx | 33 | 32 | 0.000 | 9.09 |

![Predicted vs measured cycles](model_validation.svg)

### Predictions outside tolerance (3)

| model | point | metric | predicted | measured | error | basis | in-sample |
|---|---:|---:|---:|---:|---:|---:|---:|
| D | dma_bandwidth\|copy_samebank/len=64 | latency_avg_cycles | 2.000 | 1.875 | +6.67% | structural | False |
| D | dma_bandwidth\|copy_samebank/len=256 | latency_avg_cycles | 2.000 | 1.969 | +1.59% | structural | False |
| C | gemm_int8\|3x3x2 | bytes_transferred | 768 | 704 | +9.09% | structural-approx | False |

Each miss is a statement about the model, not the RTL: the RTL numbers above are measurements. Where a cause is known it is listed under *Known model limitations* (§9).

### Model A - memory bandwidth (structural)

Architecture facts: one outstanding request per master with same-cycle re-issue (1 request/cycle/master); SRAM bank accepts 1 request/cycle, responds next cycle; partial writes occupy the bank 2 cycles; per-slave round-robin; DMA FIFO slot lifetime = read → write round trip (Little's law: period ≥ round-trip ÷ depth); host port one outstanding request. DMA window = `(N−1)·P + S_r + S_w + 4` (copy) or `(N−1)·P + S_w + 3` (fill), same-bank copy = `2N + 3`; stochastic traffic uses the expectation of the documented arbitration rules (Monte Carlo). Constants anchored to P90's independently published DMA_CYCLES values: 2050 (fill 8 KiB), 2052 (copy), 4098 (same-bank copy), 1028/4100/16388/65540 (host, L = 1/4/16/64).

### Model B - roofline

Attainable ops/cycle = min(peak compute, AI × peak bandwidth). Peaks: GEMM `2·R·C`, vector `lanes`; bandwidth `ports × memory-word bytes`. Not fitted.

![Roofline](roofline.svg)

| point | peak ops / BW (B/cyc) | AI compulsory | AI effective | measured ops/cyc | effective roof | % of roof | non-overlapped bound | % of bound | bound by |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| vector_int32\|add/vl=256 | 4 / 8 | 0.08 | 0.08 | 0.52 | 0.67 | 0.784 | 0.57 | 0.914 | memory |
| gemm_int8\|16x16x64 | 32 / 8 | 10.67 | 3.20 | 11.49 | 25.60 | 0.449 | 14.22 | 0.808 | memory |
| vector_int32\|add/vl=16 | 4 / 8 | 0.08 | 0.08 | 0.23 | 0.67 | 0.343 | 0.57 | 0.400 | memory |
| vector_int32\|add/vl=64 | 4 / 8 | 0.08 | 0.08 | 0.42 | 0.67 | 0.623 | 0.57 | 0.727 | memory |
| vector_int32\|add/vl=1024 | 4 / 8 | 0.08 | 0.08 | 0.53 | 0.67 | 0.798 | 0.57 | 0.931 | memory |
| vector_int32\|mul/vl=256 | 4 / 8 | 0.08 | 0.08 | 0.52 | 0.67 | 0.782 | 0.57 | 0.912 | memory |
| vector_int32\|add/vl=1024/lanes=4 | 4 / 8 | 0.08 | 0.08 | 0.53 | 0.67 | 0.798 | 0.57 | 0.931 | memory |
| vector_int32\|add/vl=1024/cp=1/dw=128 | 4 / 16 | 0.08 | 0.08 | 0.89 | 1.33 | 0.664 | 1.00 | 0.886 | memory |
| vector_int32\|add/vl=1024/cp=2/dw=64 | 4 / 16 | 0.08 | 0.08 | 0.74 | 1.33 | 0.552 | 1.00 | 0.736 | memory |
| vector_int32\|add/vl=1024/cp=1/dw=64 | 4 / 8 | 0.08 | 0.08 | 0.53 | 0.67 | 0.798 | 0.57 | 0.931 | memory |
| gemm_int8\|4x4x4 | 32 / 8 | 1.33 | 1.00 | 1.83 | 8.00 | 0.229 | 6.40 | 0.286 | memory |
| gemm_int8\|4x4x16 | 32 / 8 | 2.67 | 2.00 | 5.22 | 16.00 | 0.327 | 10.67 | 0.490 | memory |
| gemm_int8\|4x4x64 | 32 / 8 | 3.56 | 2.46 | 9.39 | 19.69 | 0.477 | 12.19 | 0.771 | memory |
| gemm_int8\|4x4x256 | 32 / 8 | 3.88 | 2.61 | 11.74 | 20.90 | 0.562 | 12.64 | 0.928 | memory |
| gemm_int8\|8x8x64 | 32 / 8 | 6.40 | 2.91 | 10.78 | 23.27 | 0.463 | 13.47 | 0.800 | memory |
| gemm_int8\|16x16x256 | 32 / 8 | 14.22 | 3.46 | 13.97 | 27.68 | 0.505 | 14.84 | 0.942 | memory |
| gemm_int8\|32x32x64 | 32 / 8 | 16.00 | 3.37 | 11.84 | 26.95 | 0.439 | 14.63 | 0.810 | memory |
| gemm_int8\|16x16x64/cp=1/dw=128 | 32 / 16 | 10.67 | 1.78 | 12.03 | 28.44 | 0.423 | 15.06 | 0.799 | memory |
| gemm_int8\|16x16x64/cp=2/dw=64 | 32 / 16 | 10.67 | 3.20 | 11.87 | 32.00 | 0.371 | 19.69 | 0.603 | compute |

### Model C - accelerator utilisation (fitted)

Per-command cycles = load + compute + store + overhead, phases serialised. Structural terms: array busy = Σ over blocks of `(K + r + c + 1)` with the ACTUAL block size r×c (exact, including partial tiles), words written from the output byte ranges (exact), words read from the operand byte ranges (exact when tiles are word-aligned, approximate otherwise), vector compute = `ceil(len/lanes)` per staging chunk. Fitted constants (least squares on the tile's own phase counters, calibration set below):

GEMM: `load_per_B_tile` = 9.000, `load_per_A_tile` = 6.000, `compute_per_block` = 5.000, `store_per_block` = 8.000, `overhead_const` = 12.000, `overhead_per_block` = 1.000. Calibration: gemm_int8|16x16x64, gemm_int8|4x4x4, gemm_int8|4x4x64, gemm_int8|8x8x64.

Vector: `load_per_chunk` = 15.000, `compute_per_chunk` = 6.000, `store_per_chunk` = 8.000, `engine_busy_extra_per_chunk` = 5.000, `overhead_const` = 12.000, `overhead_per_chunk` = 1.000. Calibration: vector_int32|add/vl=256, vector_int32|add/vl=16, vector_int32|add/vl=1024.

Dual-port (cp = 2) configurations are not modelled.

### Model D - transaction latency

Fabric: latency = accept wait + service; K saturating masters → K cycles each (mean = p99 = max), partial write service 2, host port L. Mailbox: `RTT = 15*t_mmio + CPI*instret + dma_cycles + c` with t_mmio = 2.03 cycles measured, **CPI = 3.34** and c = 22.0 cycles fitted on host_mailbox_roundtrip|ping, host_dma_roundtrip|fill-64B; all other command points are out of sample.

| point | predicted RTT | measured RTT | error | in-sample |
|---|---:|---:|---:|---:|
| host_port_latency\|background=0 | 1.0 | 1.0 | +0.00% | False |
| host_port_latency\|background=0 | 1.0 | 1 | +0.00% | False |
| host_port_latency\|background=0 | 1.0 | 1 | +0.00% | False |
| host_port_latency\|background=3 | 4.0 | 4.0 | +0.05% | False |
| host_port_latency\|background=3 | 4.0 | 4 | +0.00% | False |
| host_port_latency\|background=3 | 4.0 | 4 | +0.00% | False |
| host_mailbox_roundtrip\|ping | 386.3 | 386.3 | +0.00% | True |
| host_dma_roundtrip\|fill-64B | 742.8 | 742.8 | +0.00% | True |
| host_port_latency\|background=1 | 2.0 | 2.0 | +0.10% | False |
| host_port_latency\|background=1 | 2.0 | 2 | +0.00% | False |
| host_port_latency\|background=1 | 2.0 | 2 | +0.00% | False |
| host_port_latency\|background=2 | 3.0 | 3.0 | +0.07% | False |
| host_port_latency\|background=2 | 3.0 | 3 | +0.00% | False |
| host_port_latency\|background=2 | 3.0 | 3 | +0.00% | False |
| host_dma_roundtrip\|fill-1KiB | 982.8 | 973.8 | +0.92% | False |
| host_dma_roundtrip\|fill-256B | 790.8 | 781.8 | +1.15% | False |
| host_dma_roundtrip\|fill-4KiB | 1,751 | 1,742 | +0.52% | False |

### Model E - workload scaling

Hockney size fit `T(n) = T0 + n / r∞` on the standard sweep, validated on blind sizes and by extrapolating to the largest standard size:

| series | T0 (cycles) | r∞ (n/cycle) | n½ | extrapolation err | blind-size errors |
|---|---:|---:|---:|---:|---:|
| sram_seq_read: cycles vs words | 1.00 | 1.000 | 1.0 | +0.00% | +0.00%, +0.00% |
| sram_seq_write: cycles vs words | 1.00 | 1.000 | 1.0 | - | - |
| DMA fill: cycles vs words | 3.00 | 1.000 | 3.0 | +0.00% | +0.00%, +0.00%, +0.00% |
| DMA copy (cross-bank): cycles vs words | 5.00 | 1.000 | 5.0 | +0.00% | +0.00%, +0.00%, +0.00% |
| DMA copy (same bank): cycles vs words | 3.00 | 0.500 | 1.5 | +0.00% | +0.00% |
| DMA host->SRAM (L=1): cycles vs words | 5.00 | 1.000 | 5.0 | +0.00% | - |
| vector INT32 add (4 lanes): cycles/cmd vs elements | 32.36 | 0.542 | 17.5 | -0.09% | -0.01%, -1.81%, -0.17%, -0.54% |
| GEMM 4x4 array, M=N=4: cycles/cmd vs K | 58.84 | 0.401 | 23.6 | -0.68% | - |

Vector lane scaling (Amdahl) `T(lanes) = T_serial + T_parallel / lanes`: T_serial = 1668, T_parallel = 1024, max speed-up 1.61x; fitted on lanes [1, 2, 4].

| lanes | cycles/cmd | speed-up | ideal | efficiency | predicted | error | in-sample |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 2,692 | 1.00 | 1 | 1.000 | 2,692 | +0.00% | True |
| 2 | 2,180 | 1.23 | 2 | 0.617 | 2,180 | +0.00% | True |
| 4 | 1,924 | 1.40 | 4 | 0.350 | 1,924 | +0.00% | True |
| 8 | 1,796 | 1.50 | 8 | 0.187 | 1,796 | +0.00% | False |
| 16 | 1,732 | 1.55 | 16 | 0.097 | 1,732 | +0.00% | False |

| placement | masters | txn/cycle | efficiency vs ideal |
|---|---:|---:|---:|
| distinct | 2 | 1.998 | 0.999 |
| distinct | 3 | 2.997 | 0.999 |
| distinct | 4 | 3.996 | 0.999 |
| same | 2 | 1.000 | 0.500 |
| same | 3 | 0.999 | 0.333 |
| same | 4 | 1.000 | 0.250 |

| banks | random-traffic txn/cycle (4 masters) | ideal ports | efficiency |
|---|---:|---:|---:|
| 2 | 1.327 | 2 | 0.663 |
| 3 | 2.017 | 3 | 0.672 |
| 4 | 2.455 | 4 | 0.614 |
| 8 | 3.207 | 4 | 0.802 |

![DMA vs host latency](dma_host_latency.svg)

## 7. Energy analysis (ESTIMATES - not measured)

> **ESTIMATE - library-based energy from RTL-simulation activity counts. NOT measured power or silicon energy; no silicon, FPGA or gate-level power data exists. Dynamic energy only (no leakage, clock tree, wires or PHY).**

**Measured power: none** - no silicon, instrumented FPGA board or gate-level/SPEF power analysis exists for any SilicaFlux design; simulation provides event counts, which are activity, not energy. Three strictly separated layers: (1) *activity counts* - exact event counts from RTL simulation; (2) *library estimate* - counts × per-event energies from `albionbench-literature-45nm` (LIBRARY-BASED ESTIMATE (literature order-of-magnitude values) - NOT measured, NOT from a SilicaFlux technology library); (3) *measured power* - null. Simulated switching activity is **never** presented as silicon energy.

Library: Values are published order-of-magnitude figures for a 45 nm, ~0.9 V process. No SilicaFlux design has a chosen process, netlist, placement, extracted parasitics or signed-off power analysis, so these numbers are NOT scaled to any target silicon. They are suitable for comparing activity between RTL variants and for sanity-checking orders of magnitude, not for power budgeting. Source: M. Horowitz, 'Computing's energy problem (and what we can do about it)', ISSCC 2014 keynote, energy table at 45 nm. Cited from the published table; the exact figures should be re-checked against the paper before being used outside this framework. Uncertainty band: ×0.5 / ×2.0 (not a confidence interval).

**Attribution note.** An estimate covers *all* activity in the measured window, including background masters (`host_port_latency`, `concurrent_dma_interference`); `pJ/byte` and `pJ/op` divide that total by the *foreground* bytes/ops, so points with background traffic show higher per-byte values by construction.

Excluded from every estimate: static (leakage) power: no technology library or netlist exists; clock-tree and clock-gating power; interconnect/wire energy beyond the per-transaction crossbar term; I/O and PHY energy of the host interface (a PCIe endpoint/PHY is licensed IP and not part of the RTL); SRAM macro energy for any real compiled macro (the RTL uses a behavioural array; ASIC macros are not available).

| event | nominal pJ | confidence | derivation |
|---|---:|---|---|
| sram_access_39b_16KiB | 8.5 | low | Horowitz 8 KB cache, 64-bit read = 10 pJ, scaled by access width 39/64 and capacity ~1.4x for 16 KiB: 10 * 0.61 * 1.4. Write taken equal to read (SECDED encode/decode logic folded in). |
| sram_access_per_64b_word_64KiB_tile | 14.0 | low | Horowitz 8 KB/64-bit = 10 pJ scaled ~1.4x for the 64 KiB ComputeWorks local memory (4 banks x 16 KiB). |
| fabric_transaction | 0.6 | very low | assumption: 32-bit address+data through decode, permission check and a 4x6 crossbar mux; no published figure used. |
| dma_fifo_beat | 0.4 | very low | assumption: one 32-bit register-file write plus read per DMA word. |
| host_port_beat | 1.0 | very low | assumption for the on-chip side only; the PCIe endpoint/PHY energy is excluded (see excluded list). |
| int8_mac | 0.3 | medium | Horowitz 8-bit integer multiply 0.2 pJ + 32-bit integer add 0.1 pJ for the accumulate. |
| int32_add | 0.1 | medium | Horowitz 32-bit integer add 0.1 pJ. |
| int32_mul | 3.1 | medium | Horowitz 32-bit integer multiply 3.1 pJ. |
| controlcore_instruction | 30.0 | very low | Horowitz notes instruction fetch/decode/register overhead of an in-order core dominates the ALU energy (tens of pJ at 45 nm); 30 pJ is a round assumption for a small RV32I core including its SRAM fetch. |
| mmio_transaction | 1.2 | very low | assumption: fabric transaction plus register-file access on the MMIO block. |

Estimated dynamic energy per point (**ESTIMATE**, low–nominal–high band; activity counts in results.json → `energy.activity_counts`):

| point | ESTIMATE nominal nJ | band nJ (×0.5 … ×2) | pJ/byte | pJ/op | avg dynamic mW @ assumed clock (ESTIMATE) |
|---|---:|---:|---:|---:|---:|
| sram_seq_read\|base | 37.274 | 18.637 … 74.547 | 2.27 | 9.10 | 0.455 |
| sram_seq_write\|base | 37.274 | 18.637 … 74.547 | 2.27 | 9.10 | 0.455 |
| sram_seq_write_partial\|base | 36.045 | 18.022 … 72.090 | 17.60 | 17.60 | 0.440 |
| sram_random\|masters=1 | 37.274 | 18.637 … 74.547 | 2.27 | 9.10 | 0.455 |
| sram_bank_conflict\|same-bank/K=2 | 18.637 | 9.318 … 37.274 | 2.27 | 9.10 | 0.455 |
| sram_bank_conflict\|distinct-banks/K=2 | 18.637 | 9.318 … 37.274 | 2.27 | 9.10 | 0.909 |
| bus_arbitration\|saturating/K=4 | 37.274 | 18.637 … 74.547 | 2.27 | 9.10 | 0.455 |
| concurrent_mem\|K=4 | 74.547 | 37.274 … 149.094 | 2.27 | 9.10 | 1.117 |
| concurrent_dma_interference\|same-bank | 56.775 | 28.388 … 113.550 | 6.93 | 27.72 | 0.692 |
| concurrent_dma_interference\|distinct-bank | 56.784 | 28.392 … 113.568 | 6.93 | 27.73 | 1.383 |
| host_port_latency\|background=0 | 4.659 | 2.330 … 9.318 | 2.27 | 9.10 | 0.454 |
| host_port_latency\|background=3 | 18.637 | 9.318 … 37.274 | 9.10 | 36.40 | 0.455 |
| dma_bandwidth\|fill/len=4096 | 9.318 | 4.659 … 18.637 | 2.27 | 9.10 | 0.454 |
| dma_bandwidth\|copy_xbank/len=4096 | 19.046 | 9.523 … 38.093 | 4.65 | 18.60 | 0.925 |
| dma_bandwidth\|copy_samebank/len=4096 | 19.046 | 9.523 … 38.093 | 4.65 | 18.60 | 0.464 |
| dma_bandwidth\|host_to_sram/len=4096 | 11.366 | 5.683 … 22.733 | 2.77 | 11.10 | 0.552 |
| dma_bandwidth\|sram_to_host/len=4096 | 11.366 | 5.683 … 22.733 | 2.77 | 11.10 | 0.552 |
| dma_latency\|fill/len=4 | 0.009 | 0.005 … 0.018 | 2.27 | 9.10 | 0.114 |
| dma_latency\|fill/len=64 | 0.146 | 0.073 … 0.291 | 2.27 | 9.10 | 0.383 |
| dma_latency\|copy_xbank/len=4 | 0.019 | 0.009 … 0.037 | 4.65 | 18.60 | 0.155 |
| dma_latency\|copy_xbank/len=64 | 0.298 | 0.149 … 0.595 | 4.65 | 18.60 | 0.709 |
| dma_latency\|host_to_sram/len=4 | 0.011 | 0.006 … 0.022 | 2.77 | 11.10 | 0.092 |
| dma_latency\|host_to_sram/len=64 | 0.178 | 0.089 … 0.355 | 2.77 | 11.10 | 0.423 |
| vector_int32\|add/vl=256 | 43.213 | 21.606 … 86.426 | 1.76 | 21.10 | 0.550 |
| gemm_int8\|16x16x64 | 182.682 | 91.341 … 365.363 | 2.23 | 0.70 | 0.400 |
| host_mmio_latency\|read-idle | 0.115 | 0.058 … 0.230 | 0.45 | 1.80 | 0.044 |
| host_mmio_latency\|write-idle | 0.115 | 0.058 … 0.230 | 0.45 | 1.80 | 0.044 |
| host_mailbox_roundtrip\|ping | 48.629 | 24.315 … 97.259 | 50.66 | 3,039 | 0.393 |
| host_dma_roundtrip\|fill-64B | 48.745 | 24.373 … 97.491 | 95.21 | 6,093 | 0.410 |
| sram_seq_read\|nwords=64 | 0.582 | 0.291 … 1.165 | 2.27 | 9.10 | 0.448 |
| sram_seq_read\|nwords=256 | 2.330 | 1.165 … 4.659 | 2.27 | 9.10 | 0.453 |
| sram_seq_read\|nwords=1024 | 9.318 | 4.659 … 18.637 | 2.27 | 9.10 | 0.455 |
| sram_seq_read\|nwords=16384 | 149.094 | 74.547 … 298.189 | 2.27 | 9.10 | 0.455 |
| sram_seq_write\|nwords=256 | 2.330 | 1.165 … 4.659 | 2.27 | 9.10 | 0.453 |
| sram_seq_write\|nwords=16384 | 149.094 | 74.547 … 298.189 | 2.27 | 9.10 | 0.455 |
| dma_bandwidth\|fill/len=64 | 0.146 | 0.073 … 0.291 | 2.27 | 9.10 | 0.383 |
| dma_bandwidth\|fill/len=256 | 0.582 | 0.291 … 1.165 | 2.27 | 9.10 | 0.435 |
| dma_bandwidth\|fill/len=1024 | 2.330 | 1.165 … 4.659 | 2.27 | 9.10 | 0.450 |
| dma_bandwidth\|fill/len=16384 | 37.274 | 18.637 … 74.547 | 2.27 | 9.10 | 0.455 |
| dma_bandwidth\|copy_xbank/len=64 | 0.298 | 0.149 … 0.595 | 4.65 | 18.60 | 0.709 |
| dma_bandwidth\|copy_xbank/len=256 | 1.190 | 0.595 … 2.381 | 4.65 | 18.60 | 0.863 |
| dma_bandwidth\|copy_xbank/len=1024 | 4.762 | 2.381 … 9.523 | 4.65 | 18.60 | 0.912 |
| dma_bandwidth\|copy_xbank/len=8192 | 38.093 | 19.046 … 76.186 | 4.65 | 18.60 | 0.928 |
| dma_bandwidth\|host_to_sram/len=64 | 0.178 | 0.089 … 0.355 | 2.77 | 11.10 | 0.423 |
| dma_bandwidth\|host_to_sram/len=256 | 0.710 | 0.355 … 1.421 | 2.77 | 11.10 | 0.515 |
| dma_bandwidth\|host_to_sram/len=1024 | 2.842 | 1.421 … 5.683 | 2.77 | 11.10 | 0.544 |
| dma_bandwidth\|copy_samebank/len=64 | 0.298 | 0.149 … 0.595 | 4.65 | 18.60 | 0.425 |
| dma_bandwidth\|copy_samebank/len=256 | 1.190 | 0.595 … 2.381 | 4.65 | 18.60 | 0.454 |
| dma_bandwidth\|copy_samebank/len=1024 | 4.762 | 2.381 … 9.523 | 4.65 | 18.60 | 0.462 |
| dma_bandwidth\|copy_samebank/len=2048 | 9.523 | 4.762 … 19.046 | 4.65 | 18.60 | 0.464 |
| dma_latency\|fill/len=16 | 0.036 | 0.018 … 0.073 | 2.27 | 9.10 | 0.260 |
| dma_latency\|copy_xbank/len=16 | 0.074 | 0.037 … 0.149 | 4.65 | 18.60 | 0.413 |
| vector_int32\|add/vl=16 | 2.701 | 1.350 … 5.402 | 1.76 | 21.10 | 0.236 |
| vector_int32\|add/vl=64 | 10.803 | 5.402 … 21.606 | 1.76 | 21.10 | 0.435 |
| vector_int32\|add/vl=1024 | 172.851 | 86.426 … 345.702 | 1.76 | 21.10 | 0.561 |
| vector_int32\|mul/vl=256 | 49.357 | 24.678 … 98.714 | 2.01 | 24.10 | 0.627 |
| vector_int32\|add/vl=1024/lanes=1 | 172.851 | 86.426 … 345.702 | 1.76 | 21.10 | 0.401 |
| vector_int32\|add/vl=1024/lanes=2 | 172.851 | 86.426 … 345.702 | 1.76 | 21.10 | 0.495 |
| vector_int32\|add/vl=1024/lanes=8 | 172.851 | 86.426 … 345.702 | 1.76 | 21.10 | 0.601 |
| vector_int32\|add/vl=1024/lanes=16 | 172.851 | 86.426 … 345.702 | 1.76 | 21.10 | 0.623 |

## 8. Experiment configuration and what each knob really varies

| knob | realisation | values in this run | note |
|---|---|---|---|
| sram_banks | rtl | 2, 3, 4, 5, 8 | Albion fabric complex. Bank 0 is firmware-private (DMA can never reach it), so at least 2 banks are needed. |
| bank_bytes | rtl | 16384 | Bytes per Albion SRAM bank (power of two). |
| dma_depth | rtl | 1, 2, 3, 4, 6, 8 | Depth of the DMA prefetch FIFO (a real parameter of sf_albion_dma; sf_albion_cloud_top hard-codes 4). |
| bus_width_bits | rtl | 32 | The Albion fabric data path is 32 bits wide in RTL (every port is [31:0]). Other widths are MODEL_ONLY for Albion; ComputeWorks' memory-port width is a real parameter, see compute_mem_width_bits. |
| dma_burst_bytes | workload | 12, 36, 64, 100, 256, 700, 800, 900, 1024, 1200, 2000, 2048, 3000, 4096, 5000, 8192, 16384 | sf_albion_dma has no burst protocol (single 32-bit beats, one outstanding request per port). 'Burst size' is the programmed transfer length of one DMA descriptor. |
| concurrent_masters | workload | 1, 2, 3, 4 | Fabric has exactly four masters (CORE, DMARD, DMAWR, HOST). The knob selects how many generators are active. |
| host_latency_cycles | workload | 1, 2, 3, 4, 7, 16, 33, 64 | Latency of the simulated host-memory port (host-side model, as in the P90 reference harness). |
| vector_lanes | rtl | 1, 2, 4, 8, 16 | ComputeWorks vector lanes (values covered by ComputeWorks' own verified configuration matrix). |
| tensor_array | rtl | [2, 2], [4, 2], [4, 4], [8, 8] | INT8 systolic array dimensions (ComputeWorks' verified set). |
| compute_ports | rtl | 1, 2 | Compute ports into the tile SRAM. |
| compute_mem_width_bits | rtl | 64, 128 | Width of the tile's local-memory words / DMA data path. |
| tensor_shape | workload | 5x7x9, 4x4x4, 3x3x2, 6x5x3, 9x9x40, 6x5x17, 7x9x33, 8x8x64, 4x4x64, 4x4x16, 4x4x256, 10x6x30, 20x12x50, 12x12x48, 16x16x ... | GEMM M,N,K. |
| vector_length | workload | 16, 64, 100, 256, 300, 700, 1024, 1500 | Elements per vector command. |
| clock_mhz | assumption | 50.0 MHz (assumed) | Zero-delay RTL simulation has no clock frequency. Cycle counts are clock-independent; bandwidth in MB/s, latency in ns and power-like numbers are scaled by this ASSUMED frequency. No timing closure exists for any SilicaFlux design. |

`rtl` = a real Verilog parameter (separate Verilator build per value); `workload` = stimulus property; `assumption` = scales derived numbers only; `model_only` = not realisable in the RTL.

## 9. Method, checks and known limitations

* **Correctness**: every point verifies data against a shadow memory / independent reference; 171 of 171 points passed all checks.
* **Instrumentation cross-check**: a passive port monitor (independent of the traffic generators) is compared with the fabric's own event outputs (transactions, stalls, bank conflicts, bank accepts) and the DMA_CYCLES register on every fabric point.
* **Determinism / no X-dependence**: deterministic workloads are run with several seeds, each randomising the power-up state; identical cycle, stall and conflict counts are required.
* **Calibration against independent data**: the harness reproduces P90's published DMA_CYCLES values and its PING round trip (384 cycles) exactly, and ComputeWorks' published GEMM/vector tables (see docs/METHODOLOGY.md).
* **Known model limitations**: (1) same-bank DMA copy mean beat latency ignores the first ~4 uncontended warm-up beats (visible below ~64 words); (2) dual-port compute configurations are not modelled; (3) the Monte-Carlo model covers uniform random traffic only; (4) the transaction-latency model for host commands takes the firmware instruction count from RTL telemetry as an input; (5) GEMM shapes whose tiles are not array-aligned: array-busy cycles and words written are predicted exactly, but words read are approximate and the per-block compute/load constants differ slightly for partial blocks, so Model C's cycle error is larger there (see the blind-validation rows above).
* **Not covered**: ComputeWorks is benchmarked standalone, not through the Albion SoC; the HostBridge (Module 96) host interface and AlbionCore ALP reference subsystem are separate integration lines not benchmarked here; PCIe link behaviour does not exist in the RTL; multi-tile, NoC and HBM paths are out of scope.

## 10. Reproduce

```bash
cd benchmarks/albion
python3 -m albionbench env                       # tool check
python3 -m albionbench run --config standard --out results/standard
python3 -m albionbench regress --baseline baselines/standard.json --candidate results/standard/results.json
```

