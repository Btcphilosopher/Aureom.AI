# AlbionBench A/B report

**Verdict: REGRESSES measured simulated performance.**

0 point(s) improved, 6 regressed, 24 unchanged (same seeds, same harness; thresholds {"bandwidth_drop_pct": 0.5, "latency_increase_pct": 0.5, "tail_latency_increase_pct": 1.0, "stall_increase_pct": 1.0, "utilization_drop_pct": 1.0, "min_abs_cycles": 2}).

| | |
|---|---|
| **baseline** | vendored (hw override: none) |
| **candidate** | vendored (hw override: dma_depth=2) |
| **suite** | ab |
| **seeds** | [1, 2] |
| **backends** | fabric |
| **simulator** | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| **source revision** | d1e9176418f3 |

Energy columns are library-based ESTIMATES from simulation activity (see benchmark_report.md §7); they are not measured.

## Points that changed

| point | verdict | cycles | B/cycle | lat avg | lat p99 | stalls | est. pJ/byte | categories |
|---|---|---|---|---|---|---|---|---|
| `concurrent_dma_interference|distinct-bank` | **REGRESSED** | 261 → 388 | 3.923 → 2.639 | 1.00 → 1.00 | 1 → 1 | 0 → 0 | 6.98 → 8.11 | BANDWIDTH_REGRESSION, CYCLES_REGRESSION, UTILIZATION_DROP |
| `dma_bandwidth|copy_xbank/len=1024` | **REGRESSED** | 261 → 388 | 3.923 → 2.639 | 1.00 → 1.00 | 1 → 1 | 0 → 0 | 4.65 → 4.65 | BANDWIDTH_REGRESSION, CYCLES_REGRESSION, UTILIZATION_DROP |
| `dma_bandwidth|host_to_sram/len=1024` | **REGRESSED** | 261 → 388 | 3.923 → 2.639 | 1.00 → 1.00 | 1 → 1 | 0 → 0 | 2.77 → 2.77 | BANDWIDTH_REGRESSION, CYCLES_REGRESSION, UTILIZATION_DROP |
| `dma_bandwidth|sram_to_host/len=1024` | **REGRESSED** | 261 → 388 | 3.923 → 2.639 | 1.00 → 1.00 | 1 → 1 | 0 → 0 | 2.77 → 2.77 | BANDWIDTH_REGRESSION, CYCLES_REGRESSION, UTILIZATION_DROP |
| `dma_latency|copy_xbank/len=64` | **REGRESSED** | 21 → 28 | 3.048 → 2.286 | 1.00 → 1.00 | 1 → 1 | 0 → 0 | 4.65 → 4.65 | BANDWIDTH_REGRESSION, CYCLES_REGRESSION, UTILIZATION_DROP |
| `dma_latency|host_to_sram/len=64` | **REGRESSED** | 21 → 28 | 3.048 → 2.286 | 1.00 → 1.00 | 1 → 1 | 0 → 0 | 2.77 → 2.77 | BANDWIDTH_REGRESSION, CYCLES_REGRESSION, UTILIZATION_DROP |

## Headline unchanged, secondary metrics moved (NOT counted as improvements)

| point | headline | secondary metrics that improved | stalls | lat avg |
|---|---|---|---|---|
| `dma_bandwidth|copy_samebank/len=1024` | memory_bandwidth_bytes_per_cycle unchanged (0.00%) | IMPROVED_CONFLICT_INCREASE, IMPROVED_LATENCY, IMPROVED_STALL | 508 → 254 | 1.99 → 1.50 |

## Unchanged (24)

`sram_seq_read|base`, `sram_seq_write|base`, `sram_seq_write_partial|base`, `sram_random|masters=1`, `sram_bank_conflict|same-bank/K=2`, `sram_bank_conflict|distinct-banks/K=2`, `bus_arbitration|saturating/K=4`, `concurrent_mem|K=4`, `concurrent_dma_interference|same-bank`, `host_port_latency|background=0`, `host_port_latency|background=3`, `dma_bandwidth|fill/len=1024`, `dma_bandwidth|copy_samebank/len=1024`, `dma_latency|fill/len=4`, `dma_latency|fill/len=64`, `dma_latency|copy_xbank/len=4`, `dma_latency|host_to_sram/len=4`, `dma_bandwidth|host_to_sram/L=4`, `dma_bandwidth|host_to_sram/L=16`, `dma_bandwidth|sram_to_host/L=4`, `bus_arbitration|unequal/K=4`, `sram_bank_conflict|same-bank/K=4`, `sram_bank_conflict|distinct-banks/K=4`, `host_port_latency|background=1`

