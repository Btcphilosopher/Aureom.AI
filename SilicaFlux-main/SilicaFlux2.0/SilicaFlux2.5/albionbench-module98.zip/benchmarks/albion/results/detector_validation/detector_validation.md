# AlbionBench detector validation

Suite `ab`, backends ['fabric']. **ALL regressions detected as expected; control produced no findings.**

| variant | kind | expected | raised (FAIL) | verdict | detected as expected |
|---|---|---|---|---|---|
| `control_comment_only` | control | (none) | (none) | PASS | yes |
| `mut_bank_blackout_1_in_8` | regression-mutant | BANDWIDTH_REGRESSION, STALL_REGRESSION | BANDWIDTH_REGRESSION, CYCLES_REGRESSION, LATENCY_REGRESSION, STALL_REGRESSION, STARVATION, TAIL_LATENCY_REGRESSION, UTILIZATION_DROP | FAIL | yes |
| `mut_dma_never_done` | regression-mutant | DEADLOCK | DEADLOCK | FAIL | yes |
| `mut_dma_no_read_reissue` | regression-mutant | BANDWIDTH_REGRESSION, CYCLES_REGRESSION | BANDWIDTH_REGRESSION, CYCLES_REGRESSION, UTILIZATION_DROP | FAIL | yes |
| `mut_dma_wrong_data` | regression-mutant | INCORRECT_RESULT | INCORRECT_RESULT | FAIL | yes |
| `mut_fixed_priority_arbiter` | regression-mutant | STARVATION, TAIL_LATENCY_REGRESSION | BANDWIDTH_REGRESSION, CYCLES_REGRESSION, DEADLOCK, LATENCY_REGRESSION, STALL_REGRESSION, STARVATION, TAIL_LATENCY_REGRESSION, UTILIZATION_DROP | FAIL | yes |
| `mut_sram_extra_response_cycle` | regression-mutant | BANDWIDTH_REGRESSION, LATENCY_REGRESSION | BANDWIDTH_REGRESSION, CYCLES_REGRESSION, LATENCY_REGRESSION, TAIL_LATENCY_REGRESSION, UTILIZATION_DROP | FAIL | yes |

## Evidence per variant

### `control_comment_only`

Comment-only change to the DMA FIFO. Behaviour is bit-identical: the A/B tool and the regression gate must report NO change (false-positive control).

All categories raised: `{}`


### `mut_bank_blackout_1_in_8`

Every SRAM bank refuses requests one cycle in eight (a refresh-like blackout): 12.5 % fewer accept slots, more stall cycles.

All categories raised: `{"BANDWIDTH_REGRESSION": 24, "CYCLES_REGRESSION": 22, "LATENCY_REGRESSION": 25, "TAIL_LATENCY_REGRESSION": 48, "STALL_REGRESSION": 23, "UTILIZATION_DROP": 24, "CONFLICT_INCREASE": 8, "STARVATION": 1}`

* sram_seq_read|base: memory_bandwidth_bytes_per_cycle dropped -12.46% (3.992 → 3.495)
* sram_seq_read|base: clock_cycles rose +14.23% (513 → 586)
* sram_seq_read|base: latency_avg_cycles rose +14.26% (1 → 1.143)

### `mut_dma_never_done`

DMA never raises done: the engine finishes the transfer but stays busy forever.

All categories raised: `{"DEADLOCK": 16}`

* concurrent_dma_interference|same-bank: candidate deadlocked: no port activity for 0 cycles; streams: [core_bg issued=216130 done=216129 pres=0 outst=1] dma started=1 done=0
* concurrent_dma_interference|distinct-bank: candidate deadlocked: no port activity for 0 cycles; streams: [core_bg issued=216386 done=216385 pres=0 outst=1] dma started=1 done=0
* dma_bandwidth|fill/len=1024: candidate deadlocked: no port activity for 20001 cycles; streams: dma started=1 done=0

### `mut_dma_no_read_reissue`

DMA read port may not re-issue in the response cycle (one idle cycle per beat on the read side).

All categories raised: `{"IMPROVED_LATENCY": 2, "IMPROVED_TAIL_LATENCY": 2, "IMPROVED_STALL": 2, "IMPROVED_CONFLICT_INCREASE": 2, "BANDWIDTH_REGRESSION": 9, "CYCLES_REGRESSION": 9, "UTILIZATION_DROP": 9}`

* concurrent_dma_interference|distinct-bank: memory_bandwidth_bytes_per_cycle dropped -49.42% (3.923 → 1.984)
* concurrent_dma_interference|distinct-bank: clock_cycles rose +97.70% (261 → 516)
* concurrent_dma_interference|distinct-bank: pipeline_utilization dropped -32.75% (0.9885 → 0.6647)

### `mut_dma_wrong_data`

DMA copy flips bit 0 of every word it writes (silent data corruption).

All categories raised: `{"INCORRECT_RESULT": 13}`

* concurrent_dma_interference|same-bank: incorrect result: dma_mismatches=256
* concurrent_dma_interference|distinct-bank: incorrect result: dma_mismatches=256
* dma_bandwidth|copy_xbank/len=1024: incorrect result: dma_mismatches=256

### `mut_fixed_priority_arbiter`

Per-slave arbiter uses fixed priority (master 0 first) instead of round robin: the highest-numbered master can be starved.

All categories raised: `{"IMPROVED_LATENCY": 4, "IMPROVED_TAIL_LATENCY": 4, "TAIL_LATENCY_REGRESSION": 7, "IMPROVED_STALL": 5, "IMPROVED_CONFLICT_INCREASE": 5, "STARVATION": 1, "BANDWIDTH_REGRESSION": 2, "CYCLES_REGRESSION": 2, "UTILIZATION_DROP": 2, "DEADLOCK": 3, "LATENCY_REGRESSION": 1, "STALL_REGRESSION": 1, "CONFLICT_INCREASE": 1}`

* sram_bank_conflict|same-bank/K=2: latency_max_cycles rose +12750.00% (2 → 257)
* bus_arbitration|saturating/K=4: latency_max_cycles rose +19125.00% (4 → 769)
* bus_arbitration|saturating/K=4: worst accept wait 768 cycles exceeds the K-1 = 3 round-robin bound

### `mut_sram_extra_response_cycle`

SRAM bank responses are registered once more: every access takes two cycles instead of one.

All categories raised: `{"BANDWIDTH_REGRESSION": 20, "CYCLES_REGRESSION": 17, "LATENCY_REGRESSION": 23, "TAIL_LATENCY_REGRESSION": 40, "UTILIZATION_DROP": 19, "IMPROVED_STALL": 9, "IMPROVED_CONFLICT_INCREASE": 5}`

* sram_seq_read|base: memory_bandwidth_bytes_per_cycle dropped -49.95% (3.992 → 1.998)
* sram_seq_read|base: clock_cycles rose +99.81% (513 → 1025)
* sram_seq_read|base: latency_avg_cycles rose +100.00% (1 → 2)

