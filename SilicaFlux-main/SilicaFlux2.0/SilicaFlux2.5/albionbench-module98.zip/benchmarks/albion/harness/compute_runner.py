#!/usr/bin/env python3
"""Isolated runner for ComputeWorks benchmark points (executed with `python3 -I`).

Reuses ComputeWorks' own benchmark functions (benchmarks/compute_works/bench.py: gemm_point / vec_point / summarize) so the stimulus,
the independent reference models (plain-integer GEMM and INT32, exact-rational FP32) and the counter definitions are exactly the ones
ComputeWorks was verified with.  Every point checks the last result bit-exactly; a mismatch raises and is reported as FAIL_CORRECTNESS.

usage: compute_runner.py --root <computeworks tree> --build <dir for simulator binaries> --scratch <dir> --spec '<json>'
prints one JSON document.
"""
import argparse
import json
import pathlib
import sys
import traceback

ap = argparse.ArgumentParser()
ap.add_argument("--root", required=True)
ap.add_argument("--build", required=True)
ap.add_argument("--scratch", required=True)
ap.add_argument("--spec", required=True)
a = ap.parse_args()
R = pathlib.Path(a.root)
sys.path[:0] = [str(R / "benchmarks/compute_works"), str(R / "scripts"), str(R / "model"), str(R / "tests/compute_works")]

spec = json.loads(a.spec)
out = {"status": "OK"}
try:
    import cwsim
    cwsim.BUILD = pathlib.Path(a.build)                 # simulator binaries go to the AlbionBench build cache, not the vendored tree
    import bench                                        # ComputeWorks' own benchmark module
    scratch = pathlib.Path(a.scratch)
    (scratch / "build" / "tests").mkdir(parents=True, exist_ok=True)
    bench.ROOT = scratch                                # script files are written under scratch/build/tests
    from cwlib import CW_OP_VADD, CW_OP_VMUL, CW_ET_INT32
    import cw_defs as D

    hw = spec["cfg"]                                    # kwargs for Cfg / sim_for
    cfg, sim = bench.sim_for(**hw)
    n = spec.get("n", 8)
    kind = spec["kind"]
    seed = spec.get("seed", 1)
    if kind in ("gemm", "contention"):
        M, N, K = spec["shape"]
        row = bench.gemm_point(cfg, sim, M, N, K, n=n, bg=spec.get("bg", 0), tag=f"ab_{kind}_{M}x{N}x{K}_s{seed}")
    elif kind == "vector":
        op = {"add": CW_OP_VADD, "mul": CW_OP_VMUL}[spec["op"]]
        row = bench.vec_point(cfg, sim, op, CW_ET_INT32, spec["vl"], n=n, bg=spec.get("bg", 0), tag=f"ab_vec_{spec['op']}_{spec['vl']}_s{seed}")
    else:
        raise ValueError(kind)
    s = bench.summarize(row, cfg, kind)
    s["cfg_detail"] = dict(lanes=cfg.num_lanes, rows=cfg.rows, cols=cfg.cols, cp=cfg.cp, dw=cfg.dw, banks=cfg.banks, depth=cfg.depth,
                           stg=cfg.stg, sram_bytes=cfg.sram_bytes)
    out["row"] = s
except RuntimeError as e:
    msg = str(e)
    out = {"status": "FAIL_CORRECTNESS" if "FAILED" in msg or "correctness" in msg else "ERROR", "error": msg[-1500:]}
except Exception:
    out = {"status": "ERROR", "error": traceback.format_exc()[-1500:]}
print("ALBIONBENCH_JSON " + json.dumps(out, default=str))
