// =============================================================================
// AlbionBench - cycle-accurate measurement harness for the Albion fabric complex.
//
// Drives albionbench_fabric_top (real datafabric + SRAM banks + DMA + host_if, see rtl_bench/) and prints ONE JSON
// document on stdout.  One process = one benchmark point (reset, init scrub, preload, measured window, verification).
//
// Method (what makes the numbers trustworthy):
//   * STIMULUS and MEASUREMENT are separate.  Traffic generators ("streams") and the DMA drive the DUT; a passive
//     per-master monitor, built only from DUT port signals, records every request's lifetime
//     (first-valid -> accept -> response).  The monitor never looks at generator state.
//   * The RTL's own event outputs (ev_m_txn, ev_m_stall, ev_s_txn, bank-conflict) are summed over the same window and
//     compared with the monitor's independent counts; any disagreement is reported as an instrumentation mismatch.
//   * Every read is checked against a shadow memory updated in ACCEPT order (exact under multi-master overlap, partial
//     writes and DMA).  After the window the written / DMA-destination regions are read back and verified.
//   * A progress watchdog turns a hung workload into status=DEADLOCK with diagnostic state instead of a timeout.
//   * Host-memory timing replicates sf_albion_cloud_top's reference harness (albion_sim.cpp) so results are comparable.
//
// Usage:  fabric_sim --workload=NAME --seed=S --maxcyc=N --hmlat=L
//                    [--stream "m=0,op=r,bank=1,n=4096,pat=seq"]...   [--dma "mode=copy,src=..,dst=..,len=.."]
// =============================================================================
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#include "Valbionbench_fabric_top.h"
#include "verilated.h"

#ifndef AB_NB
#define AB_NB 4
#endif
#ifndef AB_BANK_BYTES
#define AB_BANK_BYTES 16384
#endif
#ifndef AB_NW
#define AB_NW 8
#endif
#ifndef AB_DMA_DEPTH
#define AB_DMA_DEPTH 4
#endif

namespace {

constexpr int NB = AB_NB;
constexpr uint32_t BANK_BYTES = AB_BANK_BYTES;
constexpr uint32_t BANK_WORDS = BANK_BYTES / 4;
constexpr uint32_t SRAM_BYTES = NB * BANK_BYTES;
constexpr int NS = NB + 2;
constexpr uint32_t HOSTMEM_BASE = 0x80000000u;
constexpr uint32_t DMA_SRC = 0x000, DMA_DST = 0x004, DMA_LEN = 0x008, DMA_DOMAIN = 0x00C, DMA_CTRL = 0x010,
                   DMA_FILL = 0x014, DMA_STATUS = 0x018, DMA_BYTES_DONE = 0x020, DMA_CYCLES = 0x024;

// ------------------------------------------------------------------------------------------------ small utilities
uint32_t mix32(uint32_t x) {
    x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16;
    return x;
}
struct Rng {
    uint64_t s;
    explicit Rng(uint64_t seed) : s(seed * 0x9E3779B97F4A7C15ULL + 0x1234567ULL) { next(); next(); }
    uint64_t next() { s ^= s >> 12; s ^= s << 25; s ^= s >> 27; return s * 0x2545F4914F6CDD1DULL; }
    uint32_t below(uint32_t n) { return n ? uint32_t((next() >> 11) % n) : 0; }
};
// deterministic, address-keyed data pattern
uint32_t pat(uint32_t word_addr, uint32_t salt) { return mix32(word_addr * 0x9E3779B1u ^ salt); }

std::string jstr(const std::string& s) {
    std::string o = "\"";
    for (char c : s) { if (c == '"' || c == '\\') o += '\\'; o += c; }
    return o + "\"";
}

struct LatStats {
    std::vector<uint32_t> v;
    void add(uint32_t x) { v.push_back(x); }
    std::string json() const {
        std::ostringstream o;
        if (v.empty()) { o << "{\"n\":0}"; return o.str(); }
        std::vector<uint32_t> s = v;
        std::sort(s.begin(), s.end());
        double sum = 0; for (auto x : s) sum += x;
        auto pct = [&](double p) { size_t i = size_t(std::ceil(p / 100.0 * s.size())); if (i) i--; return s[std::min(i, s.size() - 1)]; };
        o << "{\"n\":" << s.size() << ",\"min\":" << s.front() << ",\"mean\":" << (sum / s.size()) << ",\"p50\":" << pct(50)
          << ",\"p90\":" << pct(90) << ",\"p95\":" << pct(95) << ",\"p99\":" << pct(99) << ",\"p999\":" << pct(99.9)
          << ",\"max\":" << s.back();
        std::map<uint32_t, uint64_t> h;
        for (auto x : s) h[x]++;
        if (h.size() <= 48) {
            o << ",\"hist\":{";
            bool first = true;
            for (auto& kv : h) { o << (first ? "" : ",") << "\"" << kv.first << "\":" << kv.second; first = false; }
            o << "}";
        }
        o << "}";
        return o.str();
    }
};

// ------------------------------------------------------------------------------------------------ argument parsing
using KV = std::map<std::string, std::string>;
KV parse_kv(const std::string& s) {
    KV kv; std::stringstream ss(s); std::string tok;
    while (std::getline(ss, tok, ',')) { auto e = tok.find('='); if (e != std::string::npos) kv[tok.substr(0, e)] = tok.substr(e + 1); }
    return kv;
}
uint64_t num(const std::string& s, uint64_t dflt = 0) { return s.empty() ? dflt : std::strtoull(s.c_str(), nullptr, 0); }
uint64_t geti(const KV& kv, const char* k, uint64_t dflt) { auto it = kv.find(k); return it == kv.end() ? dflt : num(it->second); }
std::string gets(const KV& kv, const char* k, const char* dflt) { auto it = kv.find(k); return it == kv.end() ? dflt : it->second; }

// ------------------------------------------------------------------------------------------------ host memory model
struct HostMem {  // sparse; identical semantics to albion_sim.cpp
    std::unordered_map<uint32_t, std::vector<uint32_t>> pages;
    uint32_t read(uint32_t iova) const {
        auto it = pages.find(iova >> 12);
        return it == pages.end() ? 0 : it->second[(iova & 0xFFF) >> 2];
    }
    void write(uint32_t iova, uint32_t data, uint32_t strb) {
        auto& p = pages[iova >> 12];
        if (p.empty()) p.assign(1024, 0);
        uint32_t& w = p[(iova & 0xFFF) >> 2];
        uint32_t mask = 0;
        for (int b = 0; b < 4; b++) if (strb & (1u << b)) mask |= 0xFFu << (8 * b);
        w = (w & ~mask) | (data & mask);
    }
};

// ------------------------------------------------------------------------------------------------ stream (generator)
struct Stream {
    // configuration
    std::string name;
    int m = 0;                 // fabric master 0..3
    char op = 'r';             // r read, w full write, p partial (byte) write, x mixed (wpct % writes)
    std::string pat = "seq";   // seq | rand | stride
    uint32_t base_word = 0, span = 0, stride = 1;
    uint64_t n = 0;            // operations
    uint32_t wpct = 0, gap = 0, delay = 0;
    bool bg = false;           // background: runs until the window ends, not waited for
    Rng rng{1};
    // state
    uint64_t issued = 0, completed = 0;
    bool presenting = false, outstanding = false, started = false;
    uint32_t cur_word = 0, cur_wdata = 0; uint8_t cur_strb = 0xF; bool cur_we = false;
    uint32_t exp_rdata = 0; bool exp_valid = false;
    uint32_t gap_left = 0;
    uint64_t first_cycle = 0, last_cycle = 0;
    uint64_t mismatches = 0, rsp_errors = 0, bytes = 0;
};

// ------------------------------------------------------------------------------------------------ passive port monitor
struct PortMon {
    bool waiting = false, outstanding = false;
    uint64_t first_valid = 0, accept = 0, first_valid_of_out = 0;
    uint64_t txns = 0, reads = 0, writes = 0, bytes = 0, stall_conflict = 0, stall_busy = 0, rsps = 0, valid_cycles = 0;
    LatStats total, wait, service;
    // for ordering checks
    uint64_t outstanding_viol = 0;
};

class Bench {
public:
    explicit Bench(VerilatedContext* ctx) : top_(new Valbionbench_fabric_top{ctx}) {}
    ~Bench() { top_->final(); }

    Valbionbench_fabric_top* top() { return top_.get(); }
    uint64_t cycle() const { return cycle_; }

    // ---- host memory model (cycle semantics identical to albion_sim.cpp)
    void set_hm_latency(uint32_t l) { hm_lat_ = l < 1 ? 1 : l; }
    HostMem& host() { return host_; }

    // ---- wide port helpers
    static void put32(VlWide<4>& w, int i, uint32_t x) { w[i] = x; }
    void set_win(int idx, uint32_t base, uint32_t limit, uint32_t attr) {
        top_->win_base[idx] = base;
        top_->win_limit[idx] = limit;
        // 12-bit attr fields packed from bit idx*12
        int lsb = idx * 12;
        for (int b = 0; b < 12; b++) {
            int bit = lsb + b;
            uint32_t& word = top_->win_attr[bit / 32];
            if ((attr >> b) & 1) word |= (1u << (bit % 32)); else word &= ~(1u << (bit % 32));
        }
    }
    void clear_wins() {
        for (int i = 0; i < AB_NW; i++) { top_->win_base[i] = 0; top_->win_limit[i] = 0; }
        for (size_t i = 0; i < sizeof(top_->win_attr) / sizeof(uint32_t); i++) top_->win_attr[i] = 0;
    }

    void reset() {
        top_->clk = 0; top_->rst_n = 0;
        top_->g_valid = 0; top_->g_we = 0; top_->g_wstrb = 0;
        for (int i = 0; i < 4; i++) { top_->g_addr[i] = 0; top_->g_wdata[i] = 0; }
        top_->dma_bypass = 1; top_->dma_rg_we = 0; top_->dma_rg_off = DMA_STATUS; top_->dma_rg_wdata = 0;
        top_->boot_mode = 1;
        top_->hm_req_ready_i = 1; top_->hm_rsp_valid_i = 0; top_->hm_rsp_rdata_i = 0; top_->hm_rsp_err_i = 0;
        clear_wins();
        top_->eval();
        for (int i = 0; i < 8; i++) { raw_cycle(); }
        top_->rst_n = 1;
        uint64_t guard = 0;
        while (!top_->init_done && guard++ < 4ull * BANK_WORDS + 64) raw_cycle();
        for (int i = 0; i < 4; i++) raw_cycle();
        hm_pending_ = false;
    }

    // one clock with no monitoring (reset phase)
    void raw_cycle() {
        top_->clk = 0; top_->eval(); top_->clk = 1; top_->eval(); cycle_++;
    }

    // -------------------------------------------------------------------------------------- the clocked step
    // Pass 1: set host-memory inputs, evaluate: responses (registered in the DUT) are now visible.
    // Agents consume responses and decide what to present.  Pass 2: evaluate with the new inputs, sample, clock.
    struct Pass1 { uint8_t rsp_valid; uint32_t rdata[4]; uint8_t err[4]; uint32_t dma_status; };
    Pass1 pass1() {
        top_->clk = 0;
        rsp_now_ = hm_pending_ && cycle_ >= hm_due_;
        top_->hm_rsp_valid_i = rsp_now_;
        top_->hm_rsp_rdata_i = rsp_now_ ? hm_rdata_ : 0;
        top_->hm_rsp_err_i = 0;
        top_->hm_req_ready_i = !hm_pending_ || rsp_now_;
        top_->eval();
        Pass1 p{};
        p.rsp_valid = top_->g_rsp_valid;
        for (int i = 0; i < 4; i++) {
            p.rdata[i] = top_->g_rsp_rdata[i];
            p.err[i] = (top_->g_rsp_err >> (3 * i)) & 7;
        }
        p.dma_status = top_->dma_rg_rdata;
        return p;
    }

    struct Sample {
        uint8_t valid, ready, we, rsp_valid, ev_txn, ev_stall;
        uint32_t addr[4];
        uint32_t s_txn; bool conflict, viol, decerr, dma_ok, dma_err, dma_beat;
        uint32_t ecc;
    };
    Sample pass2() {
        top_->eval();
        Sample s{};
        s.valid = top_->mon_valid; s.ready = top_->mon_ready; s.we = top_->mon_we; s.rsp_valid = top_->mon_rsp_valid;
        s.ev_txn = top_->mon_ev_txn; s.ev_stall = top_->mon_ev_stall;
        for (int i = 0; i < 4; i++) s.addr[i] = top_->mon_addr[i];
        s.s_txn = top_->mon_ev_s_txn; s.conflict = top_->mon_ev_bank_conflict; s.viol = top_->mon_viol; s.decerr = top_->mon_decerr;
        s.dma_ok = top_->dma_done_ok; s.dma_err = top_->dma_done_err; s.dma_beat = top_->dma_beat_ok;
        s.ecc = (uint32_t)top_->ecc_ue;  // uncorrectable events (corrected tracked separately)
        s.ecc |= ((uint32_t)top_->ecc_ce) << 16;
        // host memory port handshake (sampled before the clock edge)
        bool hm_hs = top_->hm_req_valid_o && top_->hm_req_ready_i;
        hm_addr_ = top_->hm_req_addr_o; hm_we_ = top_->hm_req_we_o; hm_wdata_ = top_->hm_req_wdata_o; hm_strb_ = top_->hm_req_wstrb_o;
        hm_hs_ = hm_hs;
        return s;
    }
    void clock_edge() {
        top_->clk = 1; top_->eval(); cycle_++;
        if (rsp_now_) hm_pending_ = false;
        if (hm_hs_) {
            if (hm_we_) { host_.write(hm_addr_ & ~3u, hm_wdata_, hm_strb_); hm_writes_++; }
            else { hm_rdata_ = host_.read(hm_addr_ & ~3u); hm_reads_++; }
            hm_pending_ = true;
            hm_due_ = cycle_ + (hm_lat_ - 1);
        }
    }
    uint64_t hm_reads() const { return hm_reads_; }
    uint64_t hm_writes() const { return hm_writes_; }
    uint32_t hm_latency() const { return hm_lat_; }

private:
    std::unique_ptr<Valbionbench_fabric_top> top_;
    uint64_t cycle_ = 0;
    HostMem host_;
    uint32_t hm_lat_ = 1;
    bool hm_pending_ = false, rsp_now_ = false, hm_hs_ = false, hm_we_ = false;
    uint64_t hm_due_ = 0, hm_reads_ = 0, hm_writes_ = 0;
    uint32_t hm_rdata_ = 0, hm_addr_ = 0, hm_wdata_ = 0, hm_strb_ = 0;
};

// ------------------------------------------------------------------------------------------------ the scenario runner
struct DmaJob {
    bool present = false;
    std::string mode = "copy";
    uint32_t src = 0, dst = 0, len = 0, domain = 2, fill = 0xA5A5A5A5u;
    // measured
    uint64_t t0 = 0, t_done = 0, t_first_rd = 0, t_first_wr = 0, t_last_wr = 0;
    bool started = false, done = false, seen_rd = false, seen_wr = false;
    uint32_t status_end = 0, bytes_done = 0, cycles_reg = 0;
    uint64_t rd_hs = 0, wr_hs = 0;
};

struct Scenario {
    std::string workload = "custom";
    uint64_t seed = 1, maxcyc = 2000000;
    uint32_t hmlat = 1;
    bool dma_bypass_needed = false;
    std::vector<Stream> streams;
    DmaJob dma;
};

class Runner {
public:
    Runner(Bench& b, Scenario& sc) : b_(b), sc_(sc), shadow_(SRAM_BYTES / 4, 0), written_(SRAM_BYTES / 4, 0) {}

    int run() {
        // ---- reset + permission setup
        b_.set_hm_latency(sc_.hmlat);
        b_.reset();
        b_.clear_wins();
        // domain 2 may use data banks and host memory (what a tenant DMA would be granted)
        if (NB > 1) b_.set_win(0, BANK_BYTES, SRAM_BYTES - 1, 0x207);
        b_.set_win(1, HOSTMEM_BASE, 0xFFFFFFFCu, 0x207);
        bool any_streams_m12 = false;
        for (auto& s : sc_.streams) if (s.m == 1 || s.m == 2) any_streams_m12 = true;
        if (any_streams_m12 && sc_.dma.present) { fail_ = "streams on masters 1/2 conflict with the DMA"; return emit("ERROR"); }

        // ---- preload (untimed): every region that is read gets its pattern; shadow tracks it
        preload();
        if (!fail_.empty()) return emit("ERROR");

        // ---- DMA programming (untimed) and host preload
        if (sc_.dma.present) setup_dma();

        // ---- measured window
        measure();
        status_ = (deadlock_ ? "DEADLOCK" : "OK");
        // ---- verification (untimed)
        if (!deadlock_) verify();
        return emit(status_);
    }

private:
    Bench& b_;
    Scenario& sc_;
    std::vector<uint32_t> shadow_;
    std::vector<uint8_t> written_;
    PortMon mon_[4];
    std::string fail_, status_ = "OK";
    bool deadlock_ = false, measuring_ = false;
    uint64_t t_start_ = 0, t_end_ = 0;
    // RTL-side event sums over the window
    uint64_t rtl_txn_[4] = {0, 0, 0, 0}, rtl_stall_[4] = {0, 0, 0, 0}, rtl_s_txn_[16] = {0}, rtl_conflict_ = 0;
    uint64_t mon_conflict_ = 0, mon_s_txn_[16] = {0}, viol_ = 0, decerr_ = 0, ecc_ue_ = 0, ecc_ce_ = 0;
    uint64_t bank_busy_cycles_[16] = {0};
    uint64_t dma_done_event_cycle_ = 0;
    uint64_t verify_mismatch_ = 0, verify_words_ = 0, dma_mismatch_ = 0, dma_words_checked_ = 0;
    std::string diag_;
    // for the cross-check of valid-cycle accounting
    uint64_t instr_mismatch_txn_ = 0;
    uint64_t last_progress_ = 0;   // last cycle with ANY port handshake or response (generator-independent)

    // slave index of an address (NB = MMIO, NB+1 = host memory, -1 = undecoded)
    static int slave_of(uint32_t a) {
        if (a < SRAM_BYTES) return int(a / BANK_BYTES);
        if ((a >> 16) == 0x4000) return NB;
        if (a & 0x80000000u) return NB + 1;
        return -1;
    }

    // ---- a short untimed helper: write or read single words through master 0 (CORE), used for preload / verify
    void core_op(bool we, uint32_t addr, uint32_t wdata, uint8_t strb, uint32_t* rdata, bool* err) {
        auto& t = *b_.top();
        t.dma_bypass = 1;
        t.g_valid = 1; t.g_addr[0] = addr; t.g_we = we ? 1 : 0; t.g_wdata[0] = wdata; t.g_wstrb = strb & 0xF;
        bool accepted = false;
        for (int guard = 0; guard < 100000; guard++) {
            auto p = b_.pass1(); (void)p;
            t.g_valid = accepted ? 0 : 1;
            auto s = b_.pass2();
            bool hs = !accepted && (s.valid & 1) && (s.ready & 1);
            bool rsp = s.rsp_valid & 1;
            if (hs) accepted = true;
            uint32_t rd = t.g_rsp_rdata[0]; uint32_t er = t.g_rsp_err & 7;
            b_.clock_edge();
            if (accepted && rsp && !hs) { if (rdata) *rdata = rd; if (err) *err = er != 0; t.g_valid = 0; return; }
            if (accepted && rsp && hs) { /* rsp belongs to a previous request: cannot happen in this helper */ }
        }
        fail_ = "core_op timeout";
    }

    // untimed streaming write of many words using master 0 at full rate (pipelined)
    void core_fill(uint32_t first_word, uint32_t count, bool pattern_not_zero) {
        auto& t = *b_.top();
        t.dma_bypass = 1;
        uint32_t idx = 0; bool outstanding = false;
        uint64_t guard = 0;
        uint32_t cur = 0; bool presenting = false; uint32_t done = 0;
        while ((done < count) && guard++ < 50ull * (count + 100)) {
            auto p = b_.pass1();
            if (outstanding && (p.rsp_valid & 1)) { outstanding = false; done++; }
            if (!presenting && !outstanding && idx < count) { cur = first_word + idx; presenting = true; }
            t.g_valid = presenting ? 1 : 0;
            t.g_addr[0] = cur * 4; t.g_we = 1; t.g_wstrb = 0xF;
            t.g_wdata[0] = pattern_not_zero ? pat(cur, 0xA11CE) : 0;
            auto s = b_.pass2();
            if (presenting && (s.valid & 1) && (s.ready & 1)) {
                presenting = false; outstanding = true; idx++;
                shadow_[cur] = pattern_not_zero ? pat(cur, 0xA11CE) : 0; written_[cur] = 1;
            }
            b_.clock_edge();
        }
        t.g_valid = 0;
        // drain
        for (int i = 0; i < 4; i++) { b_.pass1(); b_.pass2(); b_.clock_edge(); }
        if (done < count) fail_ = "preload timeout";
    }

    void preload() {
        // collect word ranges that are READ by streams (ops r, x) or by the DMA source
        std::vector<std::pair<uint32_t, uint32_t>> ranges;
        for (auto& s : sc_.streams) {
            if (s.op == 'r' || s.op == 'x' || s.op == 'p') {
                uint32_t span = s.span ? s.span : BANK_WORDS;
                ranges.push_back({s.base_word, span});
            }
        }
        if (sc_.dma.present && sc_.dma.mode == "copy" && sc_.dma.src < SRAM_BYTES)
            ranges.push_back({sc_.dma.src / 4, sc_.dma.len / 4});
        // merge
        std::sort(ranges.begin(), ranges.end());
        std::vector<std::pair<uint32_t, uint32_t>> merged;
        for (auto& r : ranges) {
            if (r.first + r.second > SRAM_BYTES / 4) { fail_ = "stream region outside SRAM"; return; }
            if (!merged.empty() && r.first <= merged.back().first + merged.back().second) {
                uint32_t e = std::max(merged.back().first + merged.back().second, r.first + r.second);
                merged.back().second = e - merged.back().first;
            } else merged.push_back(r);
        }
        for (auto& r : merged) { core_fill(r.first, r.second, true); if (!fail_.empty()) return; }
        // host-memory source for DMA
        if (sc_.dma.present && sc_.dma.mode == "copy" && sc_.dma.src >= HOSTMEM_BASE) {
            for (uint32_t i = 0; i < sc_.dma.len / 4; i++) {
                uint32_t a = sc_.dma.src + 4 * i;
                b_.host().write(a & 0x7FFFFFFFu, pat(a >> 2, 0x4057), 0xF);
            }
        }
        // host-memory model is addressed by hm_req_addr (31 bits): the DMA address minus HOSTMEM_BASE
    }

    void dma_write_reg(uint32_t off, uint32_t val) {
        auto& t = *b_.top();
        t.dma_rg_we = 1; t.dma_rg_off = off; t.dma_rg_wdata = val;
        b_.pass1(); b_.pass2(); b_.clock_edge();
        t.dma_rg_we = 0; t.dma_rg_off = DMA_STATUS;
    }

    void setup_dma() {
        auto& d = sc_.dma;
        auto& t = *b_.top();
        t.dma_bypass = 0;
        dma_write_reg(DMA_SRC, d.src); dma_write_reg(DMA_DST, d.dst); dma_write_reg(DMA_LEN, d.len);
        dma_write_reg(DMA_DOMAIN, d.domain); dma_write_reg(DMA_FILL, d.fill);
        // host source preload done in preload(); host destination starts empty
    }

    void reset_stream_cursor(Stream& s, int idx) {
        s.rng = Rng(sc_.seed * 1000003ULL + 17ULL * idx + 5ULL);
        s.issued = s.completed = 0; s.presenting = s.outstanding = false; s.started = false; s.exp_valid = false;
        s.gap_left = s.delay;
    }

    // choose the next operation of a stream
    void next_op(Stream& s) {
        uint32_t span = s.span ? s.span : BANK_WORDS;
        uint32_t w;
        if (s.pat == "rand") w = s.base_word + s.rng.below(span);
        else if (s.pat == "stride") w = s.base_word + uint32_t((s.issued * s.stride) % span);
        else w = s.base_word + uint32_t(s.issued % span);
        s.cur_word = w;
        bool we;
        if (s.op == 'r') we = false;
        else if (s.op == 'w' || s.op == 'p') we = true;
        else we = s.rng.below(100) < s.wpct;
        s.cur_we = we;
        if (we) {
            uint32_t d = mix32(w * 0x9E3779B1u ^ uint32_t(s.issued * 2654435761u) ^ uint32_t(s.m * 0x1234567u) ^ uint32_t(sc_.seed));
            s.cur_wdata = d;
            s.cur_strb = (s.op == 'p') ? uint8_t(1u << (s.issued & 3)) : 0xF;
        }
    }

    static bool is_active_stream(const Stream& s) { return !s.bg; }

    void measure() {
        auto& t = *b_.top();
        for (size_t i = 0; i < sc_.streams.size(); i++) reset_stream_cursor(sc_.streams[i], int(i));
        bool streams_use_m12 = false;
        for (auto& s : sc_.streams) if (s.m == 1 || s.m == 2) streams_use_m12 = true;
        t.dma_bypass = sc_.dma.present ? 0 : 1;
        if (streams_use_m12) t.dma_bypass = 1;
        // quiesce one cycle and open the window
        for (int i = 0; i < 2; i++) { b_.pass1(); b_.pass2(); b_.clock_edge(); }
        measuring_ = true;
        t_start_ = b_.cycle();
        uint64_t progress_cycle = b_.cycle();
        bool dma_start_pending = sc_.dma.present;
        last_progress_ = b_.cycle();
        uint64_t wd = std::max<uint64_t>(20000, 64ull * sc_.hmlat + 2000);

        while (true) {
            uint64_t now = b_.cycle();
            auto p = b_.pass1();
            // --- DMA start in the first window cycle
            if (dma_start_pending) {
                t.dma_rg_we = 1; t.dma_rg_off = DMA_CTRL;
                t.dma_rg_wdata = 1u | (sc_.dma.mode == "fill" ? 2u : 0u);
                sc_.dma.t0 = now; sc_.dma.started = true; dma_start_pending = false;
            } else {
                t.dma_rg_we = 0; t.dma_rg_off = DMA_STATUS;
            }
            // --- agents: consume responses, then decide what to present this cycle
            uint8_t gv = 0;
            for (size_t i = 0; i < sc_.streams.size(); i++) {
                Stream& s = sc_.streams[i];
                int m = s.m;
                if (s.outstanding && ((p.rsp_valid >> m) & 1)) {
                    s.outstanding = false; s.completed++; s.last_cycle = now;
                    if (p.err[m] != 0) s.rsp_errors++;
                    if (s.exp_valid) { if (p.rdata[m] != s.exp_rdata) s.mismatches++; s.exp_valid = false; }
                    if (s.gap > 0) s.gap_left = s.gap;
                }
                bool more = (s.n == 0 || s.issued < s.n);
                if (!s.presenting && !s.outstanding && more) {
                    if (s.gap_left > 0) s.gap_left--;
                    else { next_op(s); s.presenting = true; if (!s.started) { s.started = true; s.first_cycle = now; } }
                }
                if (s.presenting) {
                    gv |= uint8_t(1u << m);
                    t.g_addr[m] = s.cur_word * 4;
                    t.g_wdata[m] = s.cur_we ? s.cur_wdata : 0;
                    uint16_t strb = s.cur_we ? s.cur_strb : 0xF;
                    t.g_wstrb = uint16_t((t.g_wstrb & ~(0xF << (4 * m))) | (strb << (4 * m)));
                    t.g_we = uint8_t((t.g_we & ~(1u << m)) | ((s.cur_we ? 1u : 0u) << m));
                }
            }
            t.g_valid = gv;
            // --- sample
            auto sm = b_.pass2();
            account(sm, now, p);
            // --- agent accept bookkeeping (uses the same-cycle handshake)
            for (auto& s : sc_.streams) {
                int m = s.m;
                if (s.presenting && ((sm.valid >> m) & 1) && ((sm.ready >> m) & 1)) {
                    s.presenting = false; s.outstanding = true; s.issued++;
                    uint32_t w = s.cur_word;
                    if (s.cur_we) {
                        uint32_t mask = 0;
                        for (int bb = 0; bb < 4; bb++) if (s.cur_strb & (1u << bb)) mask |= 0xFFu << (8 * bb);
                        shadow_[w] = (shadow_[w] & ~mask) | (s.cur_wdata & mask);
                        written_[w] = 1;
                        s.bytes += __builtin_popcount(s.cur_strb);
                    } else { s.exp_rdata = shadow_[w]; s.exp_valid = true; s.bytes += 4; }
                }
            }
            // --- DMA completion observation (registered STATUS read in pass 1 of THIS cycle)
            if (sc_.dma.started && !sc_.dma.done && now > sc_.dma.t0) {
                if (p.dma_status & 2) { sc_.dma.done = true; sc_.dma.t_done = now; sc_.dma.status_end = p.dma_status; last_progress_ = now; }
            }
            b_.clock_edge();
            t.dma_rg_we = 0; t.dma_rg_off = DMA_STATUS;   // never leave CTRL selected: its bit 1 aliases STATUS.done
            // --- termination
            bool streams_done = true;
            for (auto& s : sc_.streams) if (is_active_stream(s) && !(s.n && s.completed >= s.n)) streams_done = false;
            bool dma_done = !sc_.dma.present || sc_.dma.done;
            if (streams_done && dma_done) { t_end_ = b_.cycle(); break; }
            if (now - last_progress_ > wd || (now - t_start_) > sc_.maxcyc) {
                deadlock_ = true; t_end_ = b_.cycle();
                std::ostringstream o;
                if (now - last_progress_ > wd) o << "no port activity for " << (now - last_progress_) << " cycles (watchdog " << wd << "); streams:";
                else o << "cycle budget exceeded (" << (now - t_start_) << " > maxcyc " << sc_.maxcyc << ") while foreground work was still pending; streams:";
                for (auto& s : sc_.streams) o << " [" << s.name << " issued=" << s.issued << " done=" << s.completed << " pres=" << s.presenting << " outst=" << s.outstanding << "]";
                if (sc_.dma.present) o << " dma started=" << sc_.dma.started << " done=" << sc_.dma.done;
                diag_ = o.str();
                break;
            }
            (void)progress_cycle;
        }
        // drain outstanding responses of background streams
        t.g_valid = 0;
        measuring_ = false;
        for (int i = 0; i < 8; i++) { b_.pass1(); b_.pass2(); b_.clock_edge(); }
        t.dma_rg_we = 0;
        if (sc_.dma.present && sc_.dma.done) {
            t.dma_rg_off = DMA_BYTES_DONE; b_.pass1(); sc_.dma.bytes_done = t.dma_rg_rdata;
            t.dma_rg_off = DMA_CYCLES; b_.pass1(); sc_.dma.cycles_reg = t.dma_rg_rdata;
            t.dma_rg_off = DMA_STATUS;
        }
    }

    // per-cycle accounting of the passive monitors + RTL event sums
    void account(const Bench::Sample& s, uint64_t now, const Bench::Pass1& p) {
        if (!measuring_) return;
        if (s.rsp_valid || (s.valid & s.ready)) last_progress_ = now;
        // slave index per master this cycle
        int tgt[4];
        for (int m = 0; m < 4; m++) tgt[m] = slave_of(s.addr[m]);
        for (int m = 0; m < 4; m++) {
            PortMon& pm = mon_[m];
            bool v = (s.valid >> m) & 1, r = (s.ready >> m) & 1, rsp = (s.rsp_valid >> m) & 1, w = (s.we >> m) & 1;
            // response first (belongs to the request accepted earlier)
            if (rsp) {
                pm.rsps++;
                if (pm.outstanding) {
                    pm.total.add(uint32_t(now - pm.first_valid_of_out));
                    pm.service.add(uint32_t(now - pm.accept));
                    pm.outstanding = false;
                } else pm.outstanding_viol++;
            }
            if (v) {
                pm.valid_cycles++;
                if (!pm.waiting) { pm.waiting = true; pm.first_valid = now; }
                if (r) {
                    pm.txns++; (w ? pm.writes : pm.reads)++;
                    pm.bytes += w ? 4 : 4;  // refined below for partial writes by streams; port bytes are word beats
                    pm.wait.add(uint32_t(now - pm.first_valid));
                    pm.accept = now; pm.first_valid_of_out = pm.first_valid; pm.outstanding = true; pm.waiting = false;
                } else {
                    bool conflict = false;
                    for (int o = 0; o < 4; o++)
                        if (o != m && ((s.valid >> o) & 1) && ((s.ready >> o) & 1) && tgt[o] == tgt[m]) conflict = true;
                    (conflict ? pm.stall_conflict : pm.stall_busy)++;
                }
            }
        }
        // independent bank-conflict definition: >=2 valid masters decoding to one SRAM bank in this cycle
        bool conf = false;
        for (int bk = 0; bk < NB; bk++) {
            int c = 0;
            for (int m = 0; m < 4; m++) if (((s.valid >> m) & 1) && tgt[m] == bk) c++;
            if (c > 1) conf = true;
            // bank accept utilisation (monitor-side)
            for (int m = 0; m < 4; m++) if (((s.valid >> m) & 1) && ((s.ready >> m) & 1) && tgt[m] == bk) mon_s_txn_[bk]++;
        }
        if (conf) mon_conflict_++;
        for (int m = 0; m < 4; m++) {
            rtl_txn_[m] += (s.ev_txn >> m) & 1;
            rtl_stall_[m] += (s.ev_stall >> m) & 1;
        }
        for (int k = 0; k < NS; k++) rtl_s_txn_[k] += (s.s_txn >> k) & 1;
        rtl_conflict_ += s.conflict;
        viol_ += s.viol; decerr_ += s.decerr;
        ecc_ue_ += (s.ecc & 0xFFFF) ? 1 : 0; ecc_ce_ += (s.ecc >> 16) ? 1 : 0;
        // DMA channel events
        if (sc_.dma.present) {
            if (((s.valid >> 1) & 1) && ((s.ready >> 1) & 1)) { sc_.dma.rd_hs++; if (!sc_.dma.seen_rd) { sc_.dma.seen_rd = true; sc_.dma.t_first_rd = now; } }
            if (((s.valid >> 2) & 1) && ((s.ready >> 2) & 1)) { sc_.dma.wr_hs++; sc_.dma.t_last_wr = now; if (!sc_.dma.seen_wr) { sc_.dma.seen_wr = true; sc_.dma.t_first_wr = now; } }
            if (s.dma_ok || s.dma_err) dma_done_event_cycle_ = now;
        }
        (void)p;
    }

    // ---- untimed read-back of one word through master 0
    uint32_t read_word_core(uint32_t word, bool* err) {
        uint32_t rd = 0;
        bool e = false;
        core_op(false, word * 4, 0, 0xF, &rd, &e);
        if (err) *err = e;
        return rd;
    }

    void verify() {
        // 1. every written SRAM word must read back its shadow value (covers ECC encode/decode on the real banks)
        for (uint32_t w = 0; w < SRAM_BYTES / 4 && fail_.empty(); w++) {
            if (!written_[w]) continue;
            bool e = false;
            uint32_t v = read_word_core(w, &e);
            verify_words_++;
            if (e || v != shadow_[w]) verify_mismatch_++;
        }
        // 2. DMA result against the independently known expectation
        if (sc_.dma.present && sc_.dma.done) {
            auto& d = sc_.dma;
            for (uint32_t i = 0; i < d.len / 4; i++) {
                uint32_t exp;
                if (d.mode == "fill") exp = d.fill;
                else {
                    uint32_t sa = d.src + 4 * i;
                    exp = (sa >= HOSTMEM_BASE) ? pat(sa >> 2, 0x4057) : pat(sa >> 2, 0xA11CE);
                }
                uint32_t da = d.dst + 4 * i, got;
                if (da >= HOSTMEM_BASE) got = b_.host().read(da & 0x7FFFFFFFu);
                else { bool e = false; got = read_word_core(da >> 2, &e); if (e) got = ~exp; }
                dma_words_checked_++;
                if (got != exp) dma_mismatch_++;
            }
        }
    }

    // ------------------------------------------------------------------------------------ result document
    int emit(const std::string& status) {
        std::ostringstream o;
        uint64_t cycles = (t_end_ > t_start_) ? (t_end_ - t_start_) : 0;
        // window ends one cycle after the last response/done observation: report inclusive cycles
        o << "{\n";
        o << " \"status\":" << jstr(fail_.empty() ? status : "ERROR") << ",\n";
        if (!fail_.empty()) o << " \"error\":" << jstr(fail_) << ",\n";
        if (!diag_.empty()) o << " \"deadlock_diag\":" << jstr(diag_) << ",\n";
        o << " \"workload\":" << jstr(sc_.workload) << ",\n";
        o << " \"build\":{\"nb\":" << NB << ",\"bank_bytes\":" << BANK_BYTES << ",\"dma_depth\":" << AB_DMA_DEPTH
          << ",\"windows\":" << AB_NW << "},\n";
        o << " \"params\":{\"seed\":" << sc_.seed << ",\"hm_latency\":" << sc_.hmlat << ",\"maxcyc\":" << sc_.maxcyc << "},\n";
        o << " \"window\":{\"cycles\":" << cycles << ",\"start_cycle\":" << t_start_ << "},\n";
        // masters
        o << " \"masters\":[";
        const char* mname[4] = {"CORE", "DMARD", "DMAWR", "HOST"};
        for (int m = 0; m < 4; m++) {
            PortMon& pm = mon_[m];
            o << (m ? "," : "") << "\n  {\"id\":" << m << ",\"name\":\"" << mname[m] << "\",\"txns\":" << pm.txns << ",\"reads\":" << pm.reads
              << ",\"writes\":" << pm.writes << ",\"valid_cycles\":" << pm.valid_cycles << ",\"stall_cycles\":" << (pm.stall_conflict + pm.stall_busy)
              << ",\"stall_conflict\":" << pm.stall_conflict << ",\"stall_busy\":" << pm.stall_busy
              << ",\"rtl_txns\":" << rtl_txn_[m] << ",\"rtl_stall_cycles\":" << rtl_stall_[m]
              << ",\"protocol_violations\":" << pm.outstanding_viol
              << ",\"latency\":" << pm.total.json() << ",\"accept_wait\":" << pm.wait.json() << ",\"service\":" << pm.service.json() << "}";
        }
        o << "\n ],\n";
        // streams
        o << " \"streams\":[";
        for (size_t i = 0; i < sc_.streams.size(); i++) {
            Stream& s = sc_.streams[i];
            uint64_t cyc = s.completed ? (s.last_cycle - s.first_cycle + 1) : 0;
            o << (i ? "," : "") << "\n  {\"name\":" << jstr(s.name) << ",\"master\":" << s.m << ",\"op\":\"" << s.op << "\",\"pattern\":" << jstr(s.pat)
              << ",\"background\":" << (s.bg ? "true" : "false") << ",\"issued\":" << s.issued << ",\"completed\":" << s.completed << ",\"bytes\":" << s.bytes
              << ",\"cycles\":" << cyc << ",\"read_mismatches\":" << s.mismatches << ",\"response_errors\":" << s.rsp_errors << "}";
        }
        o << "\n ],\n";
        // banks / slaves
        o << " \"slaves\":[";
        for (int k = 0; k < NS; k++) {
            o << (k ? "," : "") << "{\"id\":" << k << ",\"kind\":\"" << (k < NB ? "sram" : (k == NB ? "mmio" : "host")) << "\",\"rtl_accepts\":" << rtl_s_txn_[k]
              << ",\"mon_accepts\":" << (k < NB ? mon_s_txn_[k] : 0) << "}";
        }
        o << "],\n";
        o << " \"fabric\":{\"bank_conflict_cycles_rtl\":" << rtl_conflict_ << ",\"bank_conflict_cycles_mon\":" << mon_conflict_
          << ",\"perm_violations\":" << viol_ << ",\"decode_errors\":" << decerr_ << ",\"ecc_ce_cycles\":" << ecc_ce_ << ",\"ecc_ue_cycles\":" << ecc_ue_ << "},\n";
        // dma
        if (sc_.dma.present) {
            auto& d = sc_.dma;
            uint64_t dcyc = d.done ? (d.t_done - d.t0) : 0;
            o << " \"dma\":{\"mode\":" << jstr(d.mode) << ",\"src\":" << d.src << ",\"dst\":" << d.dst << ",\"len\":" << d.len << ",\"domain\":" << d.domain
              << ",\"done\":" << (d.done ? "true" : "false") << ",\"window_cycles\":" << dcyc << ",\"cycles_reg\":" << d.cycles_reg
              << ",\"bytes_done\":" << d.bytes_done << ",\"status\":" << d.status_end
              << ",\"first_read_accept\":" << (d.seen_rd ? int64_t(d.t_first_rd - d.t0) : -1)
              << ",\"first_write_accept\":" << (d.seen_wr ? int64_t(d.t_first_wr - d.t0) : -1)
              << ",\"last_write_accept\":" << (d.seen_wr ? int64_t(d.t_last_wr - d.t0) : -1)
              << ",\"done_event_cycle\":" << (dma_done_event_cycle_ ? int64_t(dma_done_event_cycle_ - d.t0) : -1)
              << ",\"read_beats\":" << d.rd_hs << ",\"write_beats\":" << d.wr_hs << "},\n";
        }
        o << " \"host_memory\":{\"latency\":" << b_.hm_latency() << ",\"reads\":" << b_.hm_reads() << ",\"writes\":" << b_.hm_writes() << "},\n";
        // checks
        uint64_t stream_mism = 0, stream_err = 0;
        for (auto& s : sc_.streams) { stream_mism += s.mismatches; stream_err += s.rsp_errors; }
        o << " \"checks\":{\"stream_read_mismatches\":" << stream_mism << ",\"stream_response_errors\":" << stream_err
          << ",\"readback_words\":" << verify_words_ << ",\"readback_mismatches\":" << verify_mismatch_
          << ",\"dma_words_checked\":" << dma_words_checked_ << ",\"dma_mismatches\":" << dma_mismatch_ << "}\n";
        o << "}\n";
        std::fputs(o.str().c_str(), stdout);
        return 0;
    }
};

}  // namespace

int main(int argc, char** argv) {
    auto ctx = std::make_unique<VerilatedContext>();
    Scenario sc;
    std::vector<std::string> streams;
    std::string dma;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        auto val = [&](const char* key) -> const char* { size_t n = std::strlen(key); return a.compare(0, n, key) == 0 ? a.c_str() + n : nullptr; };
        if (const char* v = val("--workload=")) sc.workload = v;
        else if (const char* v = val("--seed=")) sc.seed = num(v);
        else if (const char* v = val("--maxcyc=")) sc.maxcyc = num(v);
        else if (const char* v = val("--hmlat=")) sc.hmlat = uint32_t(num(v));
        else if (a == "--stream" && i + 1 < argc) streams.push_back(argv[++i]);
        else if (a == "--dma" && i + 1 < argc) dma = argv[++i];
        else if (a.compare(0, 11, "+verilator+") == 0) { /* handled by Verilated */ }
    }
    // Initial-value randomisation: results must not depend on power-up state, so flops start random (seeded).
    ctx->randReset(2);
    ctx->randSeed(int(sc.seed & 0x7fffffff) + 1);
    ctx->commandArgs(argc, argv);
    for (size_t i = 0; i < streams.size(); i++) {
        KV kv = parse_kv(streams[i]);
        Stream s;
        auto bad = [&](const char* why) {
            std::printf("{\"status\":\"ERROR\",\"error\":%s}\n", jstr(std::string("bad stream spec (") + why + "): " + streams[i]).c_str());
            return 0;
        };
        s.name = gets(kv, "name", ("s" + std::to_string(i)).c_str());
        s.m = int(geti(kv, "m", 0));
        std::string op = gets(kv, "op", "r");
        s.op = op[0];
        s.pat = gets(kv, "pat", "seq");
        uint32_t bank = uint32_t(geti(kv, "bank", 0));
        uint32_t nbanks = uint32_t(geti(kv, "nbanks", 1));
        s.base_word = bank * BANK_WORDS + uint32_t(geti(kv, "off", 0));
        if (geti(kv, "off", 0) >= nbanks * BANK_WORDS) return bad("offset beyond region");
        s.span = uint32_t(geti(kv, "span", nbanks * BANK_WORDS - geti(kv, "off", 0)));
        s.stride = uint32_t(geti(kv, "stride", 1));
        s.n = geti(kv, "n", 0);
        s.wpct = uint32_t(geti(kv, "wpct", 50));
        s.gap = uint32_t(geti(kv, "gap", 0));
        s.delay = uint32_t(geti(kv, "delay", 0));
        s.bg = geti(kv, "bg", 0) != 0;
        if (s.m < 0 || s.m > 3) return bad("master id");
        if (bank >= NB || uint64_t(s.base_word) + s.span > SRAM_BYTES / 4) return bad("region outside SRAM");
        // DMA-port masters carry the FIRMWARE domain in bypass mode: the fabric (correctly) denies them the private bank 0
        if ((s.m == 1 || s.m == 2) && s.base_word < BANK_WORDS) return bad("masters 1/2 may not access firmware-private bank 0");
        if ((s.m == 1 || s.m == 2) && op[0] != 'r' && op[0] != 'w' && op[0] != 'p' && op[0] != 'x') return bad("op");
        sc.streams.push_back(s);
    }
    if (!dma.empty()) {
        KV kv = parse_kv(dma);
        sc.dma.present = true;
        sc.dma.mode = gets(kv, "mode", "copy");
        sc.dma.src = uint32_t(geti(kv, "src", 0));
        sc.dma.dst = uint32_t(geti(kv, "dst", 0));
        sc.dma.len = uint32_t(geti(kv, "len", 0));
        sc.dma.domain = uint32_t(geti(kv, "domain", 2));
        sc.dma.fill = uint32_t(geti(kv, "fill", 0xA5A5A5A5u));
    }
    Bench bench(ctx.get());
    Runner runner(bench, sc);
    int rc = runner.run();
    std::fflush(stdout);
    return rc;
}
