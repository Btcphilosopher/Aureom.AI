#!/usr/bin/env python3
"""Package benchmarks/albion as a zip (top-level directory benchmarks/albion/), excluding build products and caches.  Does not touch git."""
import pathlib
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
out = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ROOT.parent.parent / "albionbench-module98.zip")
EXCLUDE_DIRS = {"build", "__pycache__", ".pytest_cache", ".git"}
n = 0
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(ROOT.rglob("*")):
        if p.is_dir() or set(p.relative_to(ROOT).parts) & EXCLUDE_DIRS or p.suffix in (".pyc", ".zip"):
            continue
        z.write(p, pathlib.PurePosixPath("benchmarks/albion") / p.relative_to(ROOT).as_posix())
        n += 1
print(f"wrote {out} ({n} files, {out.stat().st_size // 1024} KiB)")
