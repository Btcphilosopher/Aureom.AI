#!/usr/bin/env python3
"""Vendor a pinned, hashed snapshot of the RTL under test into rtl_under_test/.

AlbionBench measures *specific RTL*.  To make a result reproducible from the framework archive alone, the exact files
that were simulated are copied here and fingerprinted (SHA-256 per file, plus one tree hash).  Re-run this tool against
a different upstream archive to benchmark a different revision, or use `albionbench ab --candidate-rtl DIR` for a
side-by-side comparison without touching the vendored snapshot.

  python3 tools/vendor_rtl.py --soc-zip silicaflux-albion-p90.zip --cw-zip silicaflux-computeworks-p88.zip

Nothing here is modified on copy.  The upstream archives are the source of truth; SOURCES.json records their SHA-256.
"""
import argparse
import hashlib
import json
import pathlib
import shutil
import sys
import tempfile
import zipfile

HERE = pathlib.Path(__file__).resolve().parent.parent
DEST = HERE / "rtl_under_test"

# (destination subdir, member prefix inside the zip, [relative paths or directories to copy])
SOC_ITEMS = ["rtl/albion", "firmware/albion", "sim/albion", "spec/albion", "docs/albion/transaction_protocol.md",
             "docs/albion/known_limitations.md", "docs/albion/hardware_dependencies.md"]
CW_ITEMS = ["rtl", "third_party", "model", "scripts/cwsim.py", "tests/compute_works", "benchmarks/compute_works/bench.py",
            "docs/compute_works/06_PERFORMANCE.md", "docs/compute_works/01_ARCHITECTURE.md"]


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def find_root(extracted, marker):
    for p in extracted.rglob(marker):
        return p.parent if marker.count("/") == 0 else pathlib.Path(str(p)[: -len(marker)].rstrip("/"))
    raise SystemExit(f"marker {marker} not found in archive")


def copy_items(src_root, dst_root, items):
    n = 0
    for it in items:
        s = src_root / it
        if not s.exists():
            raise SystemExit(f"missing in archive: {it}")
        d = dst_root / it
        if s.is_dir():
            shutil.copytree(s, d, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "build", "obj_*"))
        else:
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(s, d)
    for p in dst_root.rglob("*"):
        if p.is_file():
            n += 1
    return n


def tree_hash(root):
    h = hashlib.sha256()
    lines = []
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.name not in ("MANIFEST.sha256",):
            rel = p.relative_to(root).as_posix()
            d = sha256_file(p)
            lines.append(f"{d}  {rel}")
            h.update(f"{d}  {rel}\n".encode())
    return h.hexdigest(), lines


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--soc-zip", required=True)
    ap.add_argument("--cw-zip", required=True)
    a = ap.parse_args()
    if DEST.exists():
        shutil.rmtree(DEST)
    DEST.mkdir(parents=True)
    sources = {}
    for name, zpath, marker, items in (("albion_soc", a.soc_zip, "rtl/albion/sf_albion_cloud_top.sv", SOC_ITEMS),
                                       ("computeworks", a.cw_zip, "rtl/albion/sf_compute_tile.sv", CW_ITEMS)):
        z = pathlib.Path(zpath)
        with tempfile.TemporaryDirectory() as td:
            ex = pathlib.Path(td) / "x"
            with zipfile.ZipFile(z) as zf:
                zf.extractall(ex)
            root = find_root(ex, marker)
            n = copy_items(root, DEST / name, items)
        th, lines = tree_hash(DEST / name)
        (DEST / name / "MANIFEST.sha256").write_text("\n".join(lines) + "\n")
        sources[name] = {"upstream_archive": z.name, "upstream_archive_sha256": sha256_file(z), "files": n,
                         "tree_sha256": th, "items": items}
        print(f"vendored {name}: {n} files, tree {th[:16]}")
    (DEST / "SOURCES.json").write_text(json.dumps(sources, indent=2) + "\n")


if __name__ == "__main__":
    sys.exit(main())
