#!/usr/bin/env python3
"""Write PROVENANCE_STAMP.json: the repository revision this framework was packaged from (used when the archive is run outside a git checkout)."""
import datetime
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent


def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else None


head = git("rev-parse", "HEAD")
if not head:
    sys.exit("not a git checkout: set ALBIONBENCH_SOURCE_REV instead")
dirty = bool(git("status", "--porcelain", "--", "."))
(ROOT / "PROVENANCE_STAMP.json").write_text(json.dumps({
    "git_head": head, "git_branch": git("rev-parse", "--abbrev-ref", "HEAD"),
    "stamped_at": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "note": ("benchmarks/albion had UNCOMMITTED changes when stamped: the commit identifies the repository state the framework was developed against, "
             "the framework itself is identified by framework_tree_sha256 in every report" if dirty else "framework tree was committed when stamped")}, indent=2) + "\n")
print("stamped", head[:12], "(uncommitted framework changes)" if dirty else "")
