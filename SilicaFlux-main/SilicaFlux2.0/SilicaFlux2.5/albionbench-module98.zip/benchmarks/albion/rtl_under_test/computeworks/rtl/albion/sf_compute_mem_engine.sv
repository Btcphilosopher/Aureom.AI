// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS :: sf_compute_mem_engine
// Aureom.AI / SilicaFlux Albion
//
// One job-driven 2-D copy engine that owns ONE IronMemory (P84) master port.
//
//   READ2D : ROWS rows of ROWBYTES bytes, row r starting at BASE + r*STRIDE in
//            local memory, copied into a staging buffer at
//            STG_BASE + r*STG_PITCH + c   (c = byte within the row).
//   WRITE2D: the reverse: staging buffer -> local memory (byte strobes: only
//            bytes inside the rows are ever written; neighbours are untouched).
//   FILL0  : zero-fill ROWBYTES bytes at BASE (ROWS must be 1).
//
// Memory is accessed in naturally aligned full words (size = log2(DW/8)), so any
// byte alignment is handled by word straddling + per-byte strobes.  A word read
// may cover bytes outside the requested row inside the same aligned word; those
// bytes are DISCARDED here (never written to staging), so they cannot leak.
//
// IronMemory returns responses in request order per port (reorder buffer), so
// the response side simply mirrors the request-side iteration: no tags needed.
// Responses are always accepted (m_rsp_ready = 1).  The first non-OK response
// code is latched in job_err; the job still drains every outstanding response.
//
// Staging: this engine does not own storage.  It emits a scatter descriptor for
// READ jobs (sw_*), and reads write data from `stg_rd_flat` for WRITE jobs.
//
// Interface timing: m_req_* are functions of registered state (and, for WRITE2D,
// of staging contents, which the executors hold stable during a store).
// =============================================================================
`timescale 1ns/1ps
`include "sf_compute_defs.svh"
`default_nettype none

module sf_compute_mem_engine #(
  parameter int DW        = 64,
  parameter int STG_BYTES = 1024,
  // derived
  parameter int NB   = DW / 8,
  parameter int LNB  = $clog2(NB),
  parameter int SIW  = $clog2(STG_BYTES) + 1      // staging index width (one spare bit for bounds checks)
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // ---------------------------------------------------------------- job
  input  wire logic                    job_valid,
  output logic                         job_ready,
  input  wire logic [1:0]              job_kind,
  input  wire logic [31:0]             job_base,
  input  wire logic [15:0]             job_rows,
  input  wire logic [31:0]             job_rowbytes,
  input  wire logic [31:0]             job_stride,
  input  wire logic [1:0]              job_stg,        // staging buffer select (carried to sw_buf)
  input  wire logic [SIW-1:0]          job_stg_base,
  input  wire logic [SIW-1:0]          job_stg_pitch,
  output logic                         job_done,       // 1-cycle pulse
  output logic [2:0]                   job_err,        // first non-OK IronMemory response code (0 = none)
  output logic [15:0]                  job_nerr,       // number of non-OK responses
  // ---------------------------------------------------------------- IronMemory master port
  output logic                         m_req_valid,
  input  wire logic                    m_req_ready,
  output logic [31:0]                  m_req_addr,
  output logic [2:0]                   m_req_size,
  output logic                         m_req_we,
  output logic [DW-1:0]                m_req_wdata,
  output logic [NB-1:0]                m_req_wstrb,
  input  wire logic                    m_rsp_valid,
  output logic                         m_rsp_ready,
  input  wire logic [DW-1:0]           m_rsp_rdata,
  input  wire logic [2:0]              m_rsp_err,
  // ---------------------------------------------------------------- staging
  input  wire logic [STG_BYTES*8-1:0]  stg_rd_flat,    // source of WRITE2D data
  output logic                         sw_en,          // scatter one response into staging
  output logic [1:0]                   sw_buf,
  output logic [SIW-1:0]               sw_idx,         // staging index of the first valid byte
  output logic [$clog2(NB+1)-1:0]      sw_nbytes,
  output logic [LNB:0]                 sw_lane0,       // first valid lane in sw_data
  output logic [DW-1:0]                sw_data,
  // ---------------------------------------------------------------- events
  output logic                         ev_rd,          // read request accepted
  output logic                         ev_wr,          // write request accepted
  output logic                         ev_stall,       // request waiting for local memory
  output logic                         ev_err,         // non-OK response
  output logic                         busy
);
  localparam int CNW = $clog2(NB + 1);

  // ---------------------------------------------------------------------------
  // job registers
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {S_IDLE = 2'd0, S_RUN = 2'd1, S_DONE = 2'd2} st_e;
  st_e state_q;

  logic [1:0]       kind_q;
  logic [15:0]      rows_q;
  logic [31:0]      rowbytes_q, stride_q;
  logic [1:0]       stg_q;
  logic [SIW-1:0]   stg_pitch_q;

  // request-side iterator
  logic [15:0]      rq_row_q;
  logic [31:0]      rq_w_q;
  logic [31:0]      rq_rs_q;           // byte address of the start of the current row
  logic [SIW-1:0]   rq_stg_q;          // staging index of the start of the current row
  logic             rq_done_q;
  // response-side iterator
  logic [15:0]      rs_row_q;
  logic [31:0]      rs_w_q;
  logic [31:0]      rs_rs_q;
  logic [SIW-1:0]   rs_stg_q;

  logic [2:0]       err_q;
  logic [15:0]      nerr_q;

  assign job_ready   = (state_q == S_IDLE);
  assign m_rsp_ready = 1'b1;
  assign busy        = (state_q != S_IDLE);

  // ---------------------------------------------------------------------------
  // request-side geometry
  // ---------------------------------------------------------------------------
  logic [32:0] rq_end;
  logic [31:0] rq_fw, rq_lw, rq_wa;
  logic        rq_lastw;
  always_comb begin
    rq_end   = {1'b0, rq_rs_q} + {1'b0, rowbytes_q};
    rq_fw    = rq_rs_q >> LNB;
    rq_lw    = 32'((rq_end - 33'd1) >> LNB);
    rq_wa    = (rq_fw + rq_w_q) << LNB;
    rq_lastw = ((rq_fw + rq_w_q) == rq_lw);
  end

  // per-lane request data
  logic [DW-1:0]   wdata_c;
  logic [NB-1:0]   wstrb_c;
  always_comb begin
    wdata_c = '0;
    wstrb_c = '0;
    for (int l = 0; l < NB; l++) begin
      logic [32:0] ba;
      logic        inr;
      logic [32:0] sidx;
      ba   = {1'b0, rq_wa} + 33'(l);
      inr  = (ba >= {1'b0, rq_rs_q}) && (ba < rq_end);
      sidx = 33'(rq_stg_q) + (ba - {1'b0, rq_rs_q});
      if (kind_q != `CW_JK_READ2D) begin
        wstrb_c[l] = inr;
        if (inr && (kind_q == `CW_JK_WRITE2D) && (sidx < 33'(STG_BYTES)))
          wdata_c[l*8 +: 8] = stg_rd_flat[int'(sidx[SIW-1:0])*8 +: 8];
      end
    end
  end

  assign m_req_valid = (state_q == S_RUN) && !rq_done_q;
  assign m_req_addr  = rq_wa;
  assign m_req_size  = 3'(LNB);
  assign m_req_we    = (kind_q != `CW_JK_READ2D);
  assign m_req_wdata = wdata_c;
  assign m_req_wstrb = wstrb_c;

  wire req_fire = m_req_valid && m_req_ready;
  assign ev_rd    = req_fire && (kind_q == `CW_JK_READ2D);
  assign ev_wr    = req_fire && (kind_q != `CW_JK_READ2D);
  assign ev_stall = m_req_valid && !m_req_ready;

  // ---------------------------------------------------------------------------
  // response-side geometry and scatter descriptor
  // ---------------------------------------------------------------------------
  logic [32:0] rs_end;
  logic [31:0] rs_fw, rs_lw, rs_wa;
  logic        rs_lastw;
  always_comb begin
    rs_end   = {1'b0, rs_rs_q} + {1'b0, rowbytes_q};
    rs_fw    = rs_rs_q >> LNB;
    rs_lw    = 32'((rs_end - 33'd1) >> LNB);
    rs_wa    = (rs_fw + rs_w_q) << LNB;
    rs_lastw = ((rs_fw + rs_w_q) == rs_lw);
  end

  logic [LNB:0]    lane0_c;
  logic [CNW-1:0]  nby_c;
  logic [32:0]     idx0_c;
  always_comb begin
    lane0_c = '0;
    nby_c   = '0;
    for (int l = NB - 1; l >= 0; l--) begin
      logic [32:0] ba;
      ba = {1'b0, rs_wa} + 33'(l);
      if ((ba >= {1'b0, rs_rs_q}) && (ba < rs_end)) begin
        lane0_c = (LNB+1)'(l);
        nby_c   = nby_c + 1'b1;
      end
    end
    idx0_c = 33'(rs_stg_q) + ({1'b0, rs_wa} + 33'(lane0_c) - {1'b0, rs_rs_q});
  end

  wire rsp_fire = (state_q == S_RUN) && m_rsp_valid;
  wire idx_ok   = ((idx0_c + 33'(nby_c)) <= 33'(STG_BYTES));
  assign sw_en     = rsp_fire && (kind_q == `CW_JK_READ2D) && (m_rsp_err == 3'd0) && idx_ok;
  assign sw_buf    = stg_q;
  assign sw_idx    = idx0_c[SIW-1:0];
  assign sw_nbytes = nby_c;
  assign sw_lane0  = lane0_c;
  assign sw_data   = m_rsp_rdata;

  assign ev_err    = rsp_fire && (m_rsp_err != 3'd0);

  // ---------------------------------------------------------------------------
  // sequencing
  // ---------------------------------------------------------------------------
  wire job_go     = job_valid && job_ready;
  wire degenerate = (job_rows == 16'd0) || (job_rowbytes == 32'd0);
  wire rq_lastrow = (rq_row_q == rows_q - 16'd1);
  wire rs_lastrow = (rs_row_q == rows_q - 16'd1);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state_q     <= S_IDLE;
      kind_q      <= '0;
      rows_q      <= '0;
      rowbytes_q  <= '0;
      stride_q    <= '0;
      stg_q       <= '0;
      stg_pitch_q <= '0;
      rq_row_q    <= '0;
      rq_w_q      <= '0;
      rq_rs_q     <= '0;
      rq_stg_q    <= '0;
      rq_done_q   <= 1'b1;
      rs_row_q    <= '0;
      rs_w_q      <= '0;
      rs_rs_q     <= '0;
      rs_stg_q    <= '0;
      err_q       <= '0;
      nerr_q      <= '0;
      job_done    <= 1'b0;
    end else begin
      job_done <= 1'b0;
      case (state_q)
        S_IDLE: if (job_go) begin
          kind_q      <= job_kind;
          rows_q      <= job_rows;
          rowbytes_q  <= job_rowbytes;
          stride_q    <= job_stride;
          stg_q       <= job_stg;
          stg_pitch_q <= job_stg_pitch;
          rq_row_q    <= '0;
          rq_w_q      <= '0;
          rq_rs_q     <= job_base;
          rq_stg_q    <= job_stg_base;
          rq_done_q   <= degenerate;
          rs_row_q    <= '0;
          rs_w_q      <= '0;
          rs_rs_q     <= job_base;
          rs_stg_q    <= job_stg_base;
          err_q       <= '0;
          nerr_q      <= '0;
          state_q     <= degenerate ? S_DONE : S_RUN;
        end

        S_RUN: begin
          // request side
          if (req_fire) begin
            if (rq_lastw) begin
              rq_w_q    <= '0;
              rq_rs_q   <= rq_rs_q + stride_q;
              rq_stg_q  <= rq_stg_q + stg_pitch_q;
              rq_row_q  <= rq_row_q + 16'd1;
              if (rq_lastrow) rq_done_q <= 1'b1;
            end else begin
              rq_w_q <= rq_w_q + 32'd1;
            end
          end
          // response side
          if (rsp_fire) begin
            if (m_rsp_err != 3'd0) begin
              if (err_q == 3'd0) err_q <= m_rsp_err;
              if (nerr_q != 16'hFFFF) nerr_q <= nerr_q + 16'd1;
            end else if ((kind_q == `CW_JK_READ2D) && !idx_ok) begin
              // staging overflow (a bug upstream): report as error code 7
              if (err_q == 3'd0) err_q <= 3'd7;
              if (nerr_q != 16'hFFFF) nerr_q <= nerr_q + 16'd1;
            end
            if (rs_lastw) begin
              rs_w_q    <= '0;
              rs_rs_q   <= rs_rs_q + stride_q;
              rs_stg_q  <= rs_stg_q + stg_pitch_q;
              rs_row_q  <= rs_row_q + 16'd1;
              if (rs_lastrow) begin
                state_q  <= S_DONE;
              end
            end else begin
              rs_w_q <= rs_w_q + 32'd1;
            end
          end
        end

        S_DONE: begin
          job_done <= 1'b1;
          state_q  <= S_IDLE;
        end

        default: state_q <= S_IDLE;
      endcase
    end
  end

  assign job_err  = err_q;
  assign job_nerr = nerr_q;

  // ---------------------------------------------------------------------------
  // simulation-only protocol checks
  // ---------------------------------------------------------------------------
  // synthesis translate_off
  logic            chk_pv_q;
  logic [31:0]     chk_pa_q;
  logic            chk_pw_q;
  logic [NB-1:0]   chk_ps_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) chk_pv_q <= 1'b0;
    else begin
      chk_pv_q <= m_req_valid && !m_req_ready;
      chk_pa_q <= m_req_addr;
      chk_pw_q <= m_req_we;
      chk_ps_q <= m_req_wstrb;
      if (chk_pv_q && m_req_valid && (chk_pa_q != m_req_addr || chk_pw_q != m_req_we || chk_ps_q != m_req_wstrb))
        $error("sf_compute_mem_engine: request changed while stalled");
      if (m_req_valid && m_req_we && (m_req_wstrb == '0))
        $error("sf_compute_mem_engine: empty write strobe issued");
      if (rsp_fire && !(rs_row_q < rows_q))
        $error("sf_compute_mem_engine: unexpected response beyond the job");
    end
  end
  // synthesis translate_on
endmodule
`default_nettype wire
