// ComputeWorks (Project 88) -- complete RTL file list, compile order.  Paths relative to the project root.
+incdir+rtl/albion
-f rtl/files_iron.f
-f rtl/files_tensor.f
-f rtl/files_vector.f
rtl/albion/sf_compute_mem_engine.sv
rtl/albion/sf_compute_memory_adapter.sv
rtl/albion/sf_compute_decoder.sv
rtl/albion/sf_compute_command_queue.sv
rtl/albion/sf_compute_guard.sv
rtl/albion/sf_compute_clear_exec.sv
rtl/albion/sf_compute_tensor_exec.sv
rtl/albion/sf_compute_vector_exec.sv
rtl/albion/sf_compute_scheduler.sv
rtl/albion/sf_compute_perf.sv
rtl/albion/sf_compute_tile.sv
