#!/usr/bin/env python3
"""ComputeWorks performance benchmarks (RTL simulation, cycle counts).

Everything reported is a MEASURED cycle count from the tile's own counters (sf_compute_perf), the per-command
completion records, and IronMemory's own conflict counters.  Nothing is estimated.  No clock frequency, area or power
is claimed: no technology library was available.  Activity counters are reported as such, not as power.

  python3 benchmarks/compute_works/bench.py            run everything -> benchmarks/compute_works/results/*.json
  python3 benchmarks/compute_works/bench.py --quick    a few points only

Method.  Dispatch is held off (clk_en = 0) while N identical commands are queued, counters are cleared, dispatch is
released, and the run ends when the N-th completion arrives.  So a stream's throughput excludes testbench gaps.
Correctness of the last result of every point is checked against the independent models.
"""
import argparse
import json
import pathlib
import random
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "model"))
sys.path.insert(0, str(ROOT / "tests/compute_works"))
import cwsim            # noqa: E402
import gen_tests as G   # noqa: E402
from cwlib import *     # noqa: E402,F401,F403
import cw_defs as D     # noqa: E402

OUT = pathlib.Path(__file__).resolve().parent / "results"
BASE = dict(depth=2048, cmd_depth=16, cpl_depth=8)          # 64 KiB local SRAM, deep queues for streaming
sims = {}


def sim_for(**kw):
    cfg = Cfg(**{**BASE, **kw})
    key = repr(sorted(cfg.vparams().items()))
    if key not in sims:
        sims[key] = cwsim.build("tb_compute_tile", cfg.vparams(), vector=True)
    return cfg, sims[key]


def slotb(cfg, i):                      # 8 slots of sram/8 bytes
    return SRAM_BASE + i * (cfg.sram_bytes // 8)


def stream(cfg, sim, make_cmds, n, setup, label, bg_pct=0, check=None, seed=1, hold=True):
    """make_cmds(i) -> descriptor words.  Returns a result row."""
    rng = random.Random(seed)
    s = Script(label)
    s.reset()
    mem = G.attach(s, Mem(cfg))
    s.setup_tenant(cfg, dest_mask=0x3)
    bg_lo = slotb(cfg, 7)
    bg_n = cfg.sram_bytes // 8
    if bg_pct:
        for off in range(0, bg_n, 4096):
            script_bwrite(s, mem, bg_lo + off, [bg_pattern(bg_lo + off + i) for i in range(min(4096, bg_n - off))])
    setup(s, mem, rng)
    if hold:
        s.clken(0)
    descs = [make_cmds(i) for i in range(n)]
    if not hold:
        s.perfclear()                      # dispatch is NOT held: each command starts as soon as it is queued
    for i, w in enumerate(descs):
        s.submit(0, w)
    if hold:
        s.perfclear()
    if bg_pct:
        s.bgdma(1, bg_lo, bg_lo + bg_n, bg_pct)
    if hold:
        s.clken(1)
    s.cpl_dump(n)
    s.perf()
    if bg_pct:
        s.bgstat(1)
    for bank in range(cfg.banks):
        s.csr(0x100 + bank * 0x20 + 4 * 3)                  # per-bank conflict cycles
    for port in range(2 + cfg.cp):
        s.csr(0x200 + port * 0x40 + 4 * 7)                  # per-port conflict losses
        s.csr(0x200 + port * 0x40 + 4 * 5)                  # per-port request stall cycles
    s.csr(0x400 + 4 * 0)
    if check:
        check(s, mem, rng)
    s.end()
    path = s.write(str(ROOT / "build" / "tests" / f"bench_{label}.cwt"))
    r = cwsim.run(sim, [f"+script={path}", "+seed=1"], timeout=1800)
    if r["result"] != "PASS":
        raise RuntimeError(f"benchmark point {label} FAILED its correctness checks: {r['fails']} {r['dut_errors']}")
    recs = r["cplrecs"]
    assert len(recs) == n and all(int(x["st"]) == 0 for x in recs), f"{label}: bad completions"
    p = r["perf"]
    csr = r["csr"]
    row = dict(label=label, n=n, cycles=p[D.CW_PC_CYCLES], busy=p[D.CW_PC_BUSY],
               exec_cycles=[int(x["cyc"]) for x in recs], qwait=[int(x["qwait"]) for x in recs],
               out_bytes=p[D.CW_PC_OUT_BYTES], macs=p[D.CW_PC_TENSOR_MACS], vec_elems=p[D.CW_PC_VEC_ELEMS],
               tensor_peak=p[D.CW_PC_TENSOR_PEAK], vec_peak=p[D.CW_PC_VEC_PEAK], array_busy=p[D.CW_PC_TENSOR_ARRAY],
               vec_active=p[D.CW_PC_VEC_ACTIVE], ph_load=p[D.CW_PC_PH_LOAD], ph_compute=p[D.CW_PC_PH_COMPUTE],
               ph_store=p[D.CW_PC_PH_STORE], overhead=p[D.CW_PC_OVERHEAD], mem_rd=p[D.CW_PC_MEM_RD_WORDS],
               mem_wr=p[D.CW_PC_MEM_WR_WORDS], mem_stall=p[D.CW_PC_MEM_STALL], qwait_sum=p[D.CW_PC_QWAIT_SUM],
               qwait_max=p[D.CW_PC_QWAIT_MAX], exec_sum=p[D.CW_PC_EXEC_SUM], exec_max=p[D.CW_PC_EXEC_MAX],
               bank_conflicts=sum(v for a, v in csr.items() if 0x100 <= a < 0x200 and ((a - 0x100) % 0x20) == 12),
               port_losses={(a - 0x200) // 0x40: v for a, v in csr.items() if 0x200 <= a < 0x400 and ((a - 0x200) % 0x40) == 28},
               port_stalls={(a - 0x200) // 0x40: v for a, v in csr.items() if 0x200 <= a < 0x400 and ((a - 0x200) % 0x40) == 20},
               bg=None)
    import re
    m = re.search(r"BG ops=(\d+) bad=(\d+)", r["out"])
    if m:
        row["bg"] = dict(ops=int(m.group(1)), bad=int(m.group(2)))
    return row


# ------------------------------------------------------------------------------------------ workloads
def gemm_point(cfg, sim, M, N, K, n=6, acc=0, bg=0, tag=None, hold=True):
    A_ADDR, B_ADDR, C_ADDR, D_ADDR = slotb(cfg, 0), slotb(cfg, 1), slotb(cfg, 2), slotb(cfg, 3)
    cap = cfg.sram_bytes // 8
    assert M * K <= cap and K * N <= cap and 4 * M * N <= cap, "GEMM operands exceed a slot"
    dat = {}

    def setup(s, mem, rng):
        dat["A"], dat["B"] = rnd_bytes(rng, M * K), rnd_bytes(rng, K * N)
        dat["C"] = [rng.getrandbits(32) for _ in range(M * N)]
        script_bwrite(s, mem, A_ADDR, dat["A"]); script_bwrite(s, mem, B_ADDR, dat["B"])
        if acc:
            script_bwrite(s, mem, C_ADDR, words_to_bytes(dat["C"]))

    def mk(i):
        return pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, acc, i + 1, 1, 0, A_ADDR, B_ADDR, C_ADDR, D_ADDR, M, N, K)

    def check(s, mem, rng):
        D_ = gemm_ref(M, N, K, dat["A"], dat["B"], dat["C"] if acc else None)
        mem.write_words(D_ADDR, D_)
        s.bread(D_ADDR, mem.read(D_ADDR, 4 * M * N))

    return stream(cfg, sim, mk, n, setup, tag or f"gemm_{M}x{N}x{K}_acc{acc}_bg{bg}", bg_pct=bg, check=check, hold=hold)


def vec_point(cfg, sim, op, etype, VL, n=6, bg=0, tag=None):
    a, b, c, d = slotb(cfg, 0), slotb(cfg, 1), slotb(cfg, 2), slotb(cfg, 3)
    dat = {}
    gen = (lambda r: r.getrandbits(32)) if etype == CW_ET_INT32 else G.rnd_fp32

    def setup(s, mem, rng):
        dat["A"] = [gen(rng) for _ in range(VL)]; dat["B"] = [gen(rng) for _ in range(VL)]
        dat["C"] = [gen(rng) for _ in range(VL)]
        script_bwrite(s, mem, a, words_to_bytes(dat["A"])); script_bwrite(s, mem, b, words_to_bytes(dat["B"]))
        script_bwrite(s, mem, c, words_to_bytes(dat["C"]))

    def mk(i):
        return pack_desc(op, etype, 0, 0, i + 1, 1, 0, a, b, c, d, w6=VL)

    def check(s, mem, rng):
        D_, _ff = G.vec_expected(op, etype, 0, dat["A"], dat["B"], dat["C"] if op == CW_OP_VFMA else None)
        mem.write_words(d, D_)
        s.bread(d, mem.read(d, 4 * VL))

    name = {CW_OP_VADD: "vadd", CW_OP_VMUL: "vmul", CW_OP_VFMA: "vfma"}[op]
    return stream(cfg, sim, mk, n, setup, tag or f"{name}_{'i32' if etype == CW_ET_INT32 else 'f32'}_vl{VL}_bg{bg}",
                  bg_pct=bg, check=check)


def nop_point(cfg, sim, n=16, hold=True, tag="nop"):
    return stream(cfg, sim, lambda i: pack_desc(CW_OP_NOP, 0, 0, 0, i + 1, 1, 0), n, lambda s, m, r: None, tag, hold=hold)


def summarize(row, cfg, kind):
    cyc = row["cycles"]
    r = dict(row)
    r["cfg"] = dict(lanes=cfg.num_lanes, array=f"{cfg.rows}x{cfg.cols}", cp=cfg.cp, dw=cfg.dw, banks=cfg.banks)
    r["kind"] = kind
    r["mean_exec"] = sum(row["exec_cycles"]) / len(row["exec_cycles"])
    r["mean_qwait"] = sum(row["qwait"]) / len(row["qwait"])
    r["steady_exec"] = row["exec_cycles"][-1]
    r["ops_per_cycle"] = (2 * row["macs"] + row["vec_elems"]) / cyc          # INT8 MAC = 2 ops; one FP32 element op = 1 op
    r["mac_util"] = row["macs"] / row["tensor_peak"] if row["tensor_peak"] else None
    r["array_util"] = row["macs"] / (cfg.rows * cfg.cols * row["array_busy"]) if row["array_busy"] else None
    r["vec_util"] = row["vec_elems"] / row["vec_peak"] if row["vec_peak"] else None
    r["out_bytes_per_cycle"] = row["out_bytes"] / cyc
    r["overhead_frac"] = row["overhead"] / row["busy"] if row["busy"] else None
    r["load_frac"] = row["ph_load"] / row["busy"] if row["busy"] else None
    r["compute_frac"] = row["ph_compute"] / row["busy"] if row["busy"] else None
    r["store_frac"] = row["ph_store"] / row["busy"] if row["busy"] else None
    r["mem_words_per_cycle"] = (row["mem_rd"] + row["mem_wr"]) / cyc
    r["stall_frac"] = row["mem_stall"] / cyc
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--only", help="comma separated groups to (re)run, merged into the existing bench.json")
    a = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    (ROOT / "build" / "tests").mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    results = {"gemm": [], "vector": [], "overhead": [], "contention": [], "ports": [], "queue": [], "latency": []}
    only = set(a.only.split(",")) if a.only else None
    if only and (OUT / "bench.json").exists():
        results.update(json.load(open(OUT / "bench.json")))
        for g in only:
            results[g] = []
    want = lambda g: (only is None) or (g in only)

    def emit(group, row, cfg, kind):
        r = summarize(row, cfg, kind)
        results[group].append(r)
        print(f"  {group:10s} {row['label']:34s} cyc/cmd={r['mean_exec']:9.1f} ops/cyc={r['ops_per_cycle']:7.3f} "
              f"mac_util={'-' if r['mac_util'] is None else f'{r['mac_util']:.3f}'} vec_util={'-' if r['vec_util'] is None else f'{r['vec_util']:.3f}'}", flush=True)

    cfg, sim = sim_for()
    if want("gemm"):
        print("== GEMM size sweep (4x4 INT8 array, 1 compute port, 64-bit memory)")
        gemm_shapes = [(4, 4, 4), (4, 4, 16), (4, 4, 64), (4, 4, 256), (8, 8, 64), (16, 16, 64), (16, 16, 256), (32, 32, 64), (32, 32, 256)]
        if a.quick:
            gemm_shapes = [(4, 4, 4), (4, 4, 64), (16, 16, 64)]
        for M, N, K in gemm_shapes:
            emit("gemm", gemm_point(cfg, sim, M, N, K), cfg, "gemm")
        emit("gemm", gemm_point(cfg, sim, 16, 16, 64, acc=1), cfg, "gemm")

    if want("vector"):
        print("== vector length sweep (4 FP32 lanes)")
        for op in (CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA):
            for VL in ([16, 64, 256, 1024] if not a.quick else [64, 1024]):
                emit("vector", vec_point(cfg, sim, op, CW_ET_FP32, VL), cfg, "vector")
        emit("vector", vec_point(cfg, sim, CW_OP_VADD, CW_ET_INT32, 256), cfg, "vector")

    if want("overhead"):
        print("== command overhead")
        emit("overhead", nop_point(cfg, sim), cfg, "nop")
        emit("overhead", gemm_point(cfg, sim, 1, 1, 1, n=12, tag="gemm_1x1x1"), cfg, "gemm")
        emit("overhead", vec_point(cfg, sim, CW_OP_VADD, CW_ET_FP32, 1, n=12, tag="vadd_f32_vl1"), cfg, "vector")

    if want("vector"):
        print("== vector lane count")
        for lanes in ([1, 2, 4, 8, 16] if not a.quick else [2, 16]):
            c2, s2 = sim_for(num_lanes=lanes)
            emit("vector", vec_point(c2, s2, CW_OP_VFMA, CW_ET_FP32, 1024, tag=f"vfma_f32_vl1024_lanes{lanes}"), c2, "vector")

    if want("ports"):
        print("== compute ports (1 vs 2) and memory width (64 vs 128)")
        for cp in (1, 2):
            for dw in (64, 128):
                c2, s2 = sim_for(cp=cp, dw=dw, depth=2048 if dw == 64 else 1024)
                emit("ports", gemm_point(c2, s2, 16, 16, 64, tag=f"gemm_16x16x64_cp{cp}_dw{dw}"), c2, "gemm")
                emit("ports", vec_point(c2, s2, CW_OP_VFMA, CW_ET_FP32, 1024, tag=f"vfma_vl1024_cp{cp}_dw{dw}"), c2, "vector")

    if want("contention"):
        print("== DMA / memory contention (a concurrent master hammers a neighbouring region)")
        for bg in ([0, 25, 50, 75, 95] if not a.quick else [0, 75]):
            emit("contention", gemm_point(cfg, sim, 16, 16, 64, bg=bg), cfg, "gemm")
            emit("contention", vec_point(cfg, sim, CW_OP_VFMA, CW_ET_FP32, 1024, bg=bg), cfg, "vector")

    if want("queue"):
        print("== queue latency: N identical commands queued behind one another")
        for n in ([1, 2, 4, 8, 16] if not a.quick else [1, 8]):
            emit("queue", gemm_point(cfg, sim, 8, 8, 32, n=n, tag=f"gemm_8x8x32_queued{n}"), cfg, "gemm")

    if want("latency"):
        print("== queue latency of an IDLE tile (dispatch not held; the command starts as soon as it is queued)")
        emit("latency", nop_point(cfg, sim, n=8, hold=False, tag="idle_nop"), cfg, "nop")
        emit("latency", gemm_point(cfg, sim, 4, 4, 4, n=1, hold=False, tag="idle_gemm_4x4x4"), cfg, "gemm")
        emit("latency", gemm_point(cfg, sim, 4, 4, 4, n=8, hold=False, tag="idle_gemm_4x4x4_x8"), cfg, "gemm")

    (OUT / "bench.json").write_text(json.dumps(results, indent=1, default=str))
    print(f"\nwrote {OUT / 'bench.json'}  ({time.time() - t0:.0f}s)")


if __name__ == "__main__":
    main()
