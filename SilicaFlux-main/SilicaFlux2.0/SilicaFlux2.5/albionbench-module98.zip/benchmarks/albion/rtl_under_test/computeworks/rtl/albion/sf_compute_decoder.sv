// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS :: sf_compute_decoder
// Aureom.AI / SilicaFlux Albion
//
// Command decoder and validator (combinational).  Takes one 256-bit descriptor plus
// the hardware-bound facts about the queue it came from, and produces either a
// rejection (status + detail) or the decoded command and the byte ranges the
// isolation check must approve.  Nothing here has a side effect: a rejected
// command never reaches an executor.
//
// Validation precedence (first failing rule wins; the order is part of the ABI):
//   1 OWNER      queue unbound, or claimed DOM != the queue's hardware-bound domain
//   2 BAD_FLAGS  reserved descriptor bits set, ACC on a non-GEMM op, illegal rounding mode
//   3 BAD_DEST   completion destination not allowed for the domain
//   4 BAD_OP     reserved op, or an op whose hardware is not built (EN_VECTOR = 0)
//   5 BAD_ETYPE  unsupported or illegal element type for the op.  FP16, BF16, FP64 and
//                every reserved code are REJECTED: they are not implemented.
//   6 BAD_DIMS   zero dimension / length
//   7 RESLIMIT   K beyond the staging capacity, or work above the queue's budget
//   8 BAD_ALIGN  4-byte alignment of INT32 / FP32 buffers
//   9 BAD_RANGE  any buffer outside the local SRAM window (40-bit arithmetic: no wrap)
//  10 OVERLAP    the result partially overlaps an input (identical = in place is allowed
//                for vector ops and for C of an accumulating GEMM)
// The isolation (Citadel) check is applied afterwards by the scheduler.
// =============================================================================
`timescale 1ns/1ps
`include "sf_compute_defs.svh"
`default_nettype none

module sf_compute_decoder #(
  parameter logic [31:0] SRAM_BASE  = 32'h1000_0000,
  parameter longint      SRAM_BYTES = 32768,
  parameter int          KMAX       = 256,
  parameter bit          EN_VECTOR  = 1'b1,
  parameter bit          EN_INT32   = 1'b1
) (
  input  wire logic [255:0]        desc,
  // hardware-bound facts about the originating queue
  input  wire logic                q_bound,
  input  wire logic [2:0]          q_dom,
  input  wire logic [3:0]          q_dest,          // queue default destination
  input  wire logic [15:0]         dest_mask,       // destinations allowed for q_dom
  input  wire logic [31:0]         q_budget,        // 0 = unlimited
  // verdict
  output logic [`CW_ST_W-1:0]      status,
  output logic [15:0]              detail,
  output logic                     dest_is_default, // use q_dest (claimed dest is untrusted)
  // decoded fields
  output logic [7:0]               op,
  output logic [7:0]               etype,
  output logic [2:0]               rm,
  output logic                     acc,
  output logic [15:0]              tag,
  output logic [2:0]               claim,
  output logic [3:0]               dest,
  output logic [15:0]              m, n, k,
  output logic [31:0]              src_a, src_b, src_c, dst,
  output logic [31:0]              len,             // CLEAR: bytes; vector ops: VL
  output logic [47:0]              work,            // GEMM: M*N*K ; vector: VL ; CLEAR: LEN
  // byte ranges the isolation check must approve: index 0..3 = A, B, C, D
  output logic [3:0]               r_use,
  output logic [4*32-1:0]          r_base,
  output logic [4*40-1:0]          r_len
);
  wire [31:0] w0 = desc[31:0];
  wire [31:0] w1 = desc[63:32];
  wire [31:0] w2 = desc[95:64];
  wire [31:0] w3 = desc[127:96];
  wire [31:0] w4 = desc[159:128];
  wire [31:0] w5 = desc[191:160];
  wire [31:0] w6 = desc[223:192];
  wire [31:0] w7 = desc[255:224];

  assign op     = w0[7:0];
  assign etype  = w0[15:8];
  assign rm     = w0[18:16];
  assign acc    = w0[19];
  assign tag    = w1[15:0];
  assign claim  = w1[18:16];
  assign dest   = w1[22:19];
  assign src_a  = w2;
  assign src_b  = w3;
  assign src_c  = w4;
  assign dst    = w5;
  assign m      = w6[15:0];
  assign n      = w6[31:16];
  assign k      = w7[15:0];
  assign len    = w6;

  localparam logic [39:0] SR_LO = {8'd0, SRAM_BASE};
  localparam logic [39:0] SR_HI = {8'd0, SRAM_BASE} + 40'(SRAM_BYTES);

  function automatic logic intersects(input logic [39:0] a0, input logic [39:0] al,
                                      input logic [39:0] b0, input logic [39:0] bl);
    intersects = (a0 < (b0 + bl)) && (b0 < (a0 + al));
  endfunction
  // partial overlap = intersect, but not identical
  function automatic logic partial(input logic [39:0] a0, input logic [39:0] al,
                                   input logic [39:0] b0, input logic [39:0] bl);
    partial = intersects(a0, al, b0, bl) && !((a0 == b0) && (al == bl));
  endfunction

  logic is_gemm, is_vec, is_clear, is_nop, is_fp_op, et_ok;
  logic [39:0] la, lb, lc, ld;
  logic [31:0] k32;

  always_comb begin
    status          = `CW_ST_OK;
    detail          = 16'd0;
    dest_is_default = 1'b0;
    r_use           = 4'b0000;
    r_base          = {src_a, src_a, src_a, src_a};
    r_len           = '0;
    work            = 48'd0;
    la = 40'd0; lb = 40'd0; lc = 40'd0; ld = 40'd0;
    k32 = {16'd0, k};

    is_nop   = (op == `CW_OP_NOP);
    is_gemm  = (op == `CW_OP_GEMM);
    is_clear = (op == `CW_OP_CLEAR);
    is_vec   = (op == `CW_OP_VADD) || (op == `CW_OP_VMUL) || (op == `CW_OP_VFMA);
    is_fp_op = is_vec && (etype == `CW_ET_FP32);

    // byte lengths (40 bit: 65535*65535*4 < 2^40)
    if (is_gemm) begin
      la = 40'(m) * 40'(k);
      lb = 40'(k) * 40'(n);
      lc = 40'(m) * 40'(n) * 40'd4;
      ld = lc;
      work = 48'(m) * 48'(n) * 48'(k);
    end else if (is_vec) begin
      la = {8'd0, w6} * 40'd4;
      lb = la; lc = la; ld = la;
      work = {16'd0, w6};
    end else if (is_clear) begin
      ld = {8'd0, w6};
      work = {16'd0, w6};
    end

    // etype legality for the op
    et_ok = 1'b1;
    if (is_gemm)               et_ok = (etype == `CW_ET_INT8);
    else if (op == `CW_OP_VFMA) et_ok = (etype == `CW_ET_FP32);
    else if (is_vec)            et_ok = (etype == `CW_ET_FP32) || (EN_INT32 && (etype == `CW_ET_INT32));

    // ---------------------------------------------------------------- precedence chain
    if (!q_bound || (claim != q_dom)) begin
      status = `CW_ST_OWNER;
      detail = {12'd0, q_bound, claim};
      dest_is_default = 1'b1;
    end else if ((w0[31:20] != 12'd0) || (w1[31:23] != 9'd0) || (w7[31:16] != 16'd0) ||
                 (acc && !is_gemm) || (is_fp_op && (rm > 3'd4))) begin
      status = `CW_ST_BAD_FLAGS;
      detail = {13'd0, rm};
      dest_is_default = 1'b1;
    end else if (!dest_mask[dest]) begin
      status = `CW_ST_BAD_DEST;
      detail = {12'd0, dest};
      dest_is_default = 1'b1;
    end else if (op > `CW_OP_LAST || (is_vec && !EN_VECTOR)) begin
      status = `CW_ST_BAD_OP;
      detail = {8'd0, op};
    end else if (!is_nop && !is_clear && !et_ok) begin
      status = `CW_ST_BAD_ETYPE;                      // includes FP16 / BF16 / FP64 / reserved codes
      detail = {8'd0, etype};
    end else if (is_gemm && (m == 16'd0 || n == 16'd0 || k == 16'd0)) begin
      status = `CW_ST_BAD_DIMS;
      detail = {12'd0, (m == 16'd0) ? `CW_DIM_M : (n == 16'd0) ? `CW_DIM_N : `CW_DIM_K};
    end else if (is_vec && (w6 == 32'd0)) begin
      status = `CW_ST_BAD_DIMS;
      detail = {12'd0, `CW_DIM_VL};
    end else if (is_clear && (w6 == 32'd0)) begin
      status = `CW_ST_BAD_DIMS;
      detail = {12'd0, `CW_DIM_LEN};
    end else if (is_gemm && (k32 > 32'(KMAX))) begin
      status = `CW_ST_RESLIMIT;
      detail = {12'd0, `CW_LIM_K};
    end else if ((q_budget != 32'd0) && (work > {16'd0, q_budget})) begin
      status = `CW_ST_RESLIMIT;
      detail = {12'd0, `CW_LIM_MACS};
    end else if ((is_gemm && ((acc && (src_c[1:0] != 2'b00)) || (dst[1:0] != 2'b00))) ||
                 (is_vec && ((src_a[1:0] != 2'b00) || (src_b[1:0] != 2'b00) ||
                             ((op == `CW_OP_VFMA) && (src_c[1:0] != 2'b00)) || (dst[1:0] != 2'b00))) ||
                 (is_clear && ((dst[1:0] != 2'b00) || (w6[1:0] != 2'b00)))) begin
      status = `CW_ST_BAD_ALIGN;
      // first offending operand in A, B, C, D order
      if      (is_vec && src_a[1:0] != 2'b00)                                  detail = {12'd0, `CW_OPND_A};
      else if (is_vec && src_b[1:0] != 2'b00)                                  detail = {12'd0, `CW_OPND_B};
      else if (((is_gemm && acc) || op == `CW_OP_VFMA) && src_c[1:0] != 2'b00) detail = {12'd0, `CW_OPND_C};
      else                                                                     detail = {12'd0, `CW_OPND_D};
    end else begin
      // ranges: which buffers does this command touch?
      if (is_gemm) begin
        r_use = {1'b1, acc, 1'b1, 1'b1};            // D C B A
      end else if (op == `CW_OP_VFMA) begin
        r_use = 4'b1111;
      end else if (is_vec) begin
        r_use = 4'b1011;                            // D, B, A
      end else if (is_clear) begin
        r_use = 4'b1000;                            // D only
      end
      r_base = {dst, src_c, src_b, src_a};
      r_len  = {ld, lc, lb, la};

      if (r_use[0] && (({8'd0, src_a} < SR_LO) || (({8'd0, src_a} + la) > SR_HI))) begin
        status = `CW_ST_BAD_RANGE; detail = {12'd0, `CW_OPND_A};
      end else if (r_use[1] && (({8'd0, src_b} < SR_LO) || (({8'd0, src_b} + lb) > SR_HI))) begin
        status = `CW_ST_BAD_RANGE; detail = {12'd0, `CW_OPND_B};
      end else if (r_use[2] && (({8'd0, src_c} < SR_LO) || (({8'd0, src_c} + lc) > SR_HI))) begin
        status = `CW_ST_BAD_RANGE; detail = {12'd0, `CW_OPND_C};
      end else if (r_use[3] && (({8'd0, dst} < SR_LO) || (({8'd0, dst} + ld) > SR_HI))) begin
        status = `CW_ST_BAD_RANGE; detail = {12'd0, `CW_OPND_D};
      end else if (is_gemm) begin
        // result may not overlap A or B at all; C only identical or disjoint
        if (intersects({8'd0, dst}, ld, {8'd0, src_a}, la)) begin
          status = `CW_ST_OVERLAP; detail = {12'd0, `CW_OPND_A};
        end else if (intersects({8'd0, dst}, ld, {8'd0, src_b}, lb)) begin
          status = `CW_ST_OVERLAP; detail = {12'd0, `CW_OPND_B};
        end else if (acc && partial({8'd0, dst}, ld, {8'd0, src_c}, lc)) begin
          status = `CW_ST_OVERLAP; detail = {12'd0, `CW_OPND_C};
        end
      end else if (is_vec) begin
        if (partial({8'd0, dst}, ld, {8'd0, src_a}, la)) begin
          status = `CW_ST_OVERLAP; detail = {12'd0, `CW_OPND_A};
        end else if (partial({8'd0, dst}, ld, {8'd0, src_b}, lb)) begin
          status = `CW_ST_OVERLAP; detail = {12'd0, `CW_OPND_B};
        end else if ((op == `CW_OP_VFMA) && partial({8'd0, dst}, ld, {8'd0, src_c}, lc)) begin
          status = `CW_ST_OVERLAP; detail = {12'd0, `CW_OPND_C};
        end
      end
    end

    // a command that is not executed uses no ranges
    if (status != `CW_ST_OK) r_use = 4'b0000;
  end
endmodule
`default_nettype wire
