// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS :: sf_compute_command_queue
// Aureom.AI / SilicaFlux Albion
//
// NQ independent descriptor queues of DEPTH entries each (256-bit descriptor).
// Every entry is time-stamped at enqueue so the scheduler can report queue latency.
//
//   * NQ = 1 is the reference configuration.  NQ > 1 adds the multiple protected
//     queues: each queue has its own storage, so one tenant's backlog can never
//     displace another's descriptors; the binding of a queue to a security domain
//     lives in the guard (hardware-programmed by the management plane), not here.
//   * Submission is one descriptor per cycle into the queue named by sub_q.
//     sub_ready is low while that queue is full (back-pressure, nothing dropped).
//     A sub_q >= NQ is accepted and DROPPED with a one-cycle ev_bad_queue pulse
//     (accepting is the only way not to wedge the submitter; no queue or domain
//     exists to receive a completion).
//   * The scheduler reads the head of every queue and pops one at dispatch.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sf_compute_command_queue #(
  parameter int NQ    = 1,
  parameter int DEPTH = 4,
  parameter int TSW   = 32,
  parameter int QW    = (NQ > 1) ? $clog2(NQ) : 1,
  parameter int CW    = $clog2(DEPTH + 1),
  parameter int PW    = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic [TSW-1:0]       now,
  // submission
  input  wire logic                 sub_valid,
  output logic                      sub_ready,
  input  wire logic [QW-1:0]        sub_q,
  input  wire logic [255:0]         sub_desc,
  // heads
  output logic      [NQ-1:0]        head_valid,
  output logic      [NQ*256-1:0]    head_desc,
  output logic      [NQ*TSW-1:0]    head_ts,
  input  wire logic [NQ-1:0]        pop,
  output logic      [NQ*CW-1:0]     occupancy,
  // events
  output logic                      ev_push,
  output logic                      ev_bad_queue
);
  logic [NQ-1:0] full_v;
  wire           q_ok = (int'(sub_q) < NQ);

  assign sub_ready    = !sub_valid ? 1'b1 : (q_ok ? !full_v[sub_q] : 1'b1);
  wire   push_any     = sub_valid && sub_ready && q_ok;
  assign ev_push      = push_any;
  assign ev_bad_queue = sub_valid && sub_ready && !q_ok;

  genvar q;
  generate
    for (q = 0; q < NQ; q++) begin : g_q
      logic [255:0]     mem_d [DEPTH];
      logic [TSW-1:0]   mem_t [DEPTH];
      logic [CW-1:0]    cnt_q;
      logic [PW-1:0]    rd_q, wr_q;
      wire do_push = push_any && (int'(sub_q) == q);
      wire do_pop  = pop[q] && (cnt_q != '0);

      assign full_v[q]                 = (int'(cnt_q) == DEPTH);
      assign head_valid[q]             = (cnt_q != '0);
      assign head_desc[q*256 +: 256]   = mem_d[rd_q];
      assign head_ts[q*TSW +: TSW]     = mem_t[rd_q];
      assign occupancy[q*CW +: CW]     = cnt_q;

      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          cnt_q <= '0; rd_q <= '0; wr_q <= '0;
          for (int i = 0; i < DEPTH; i++) begin mem_d[i] <= '0; mem_t[i] <= '0; end
        end else begin
          if (do_push) begin
            mem_d[wr_q] <= sub_desc;
            mem_t[wr_q] <= now;
            wr_q <= (int'(wr_q) == DEPTH - 1) ? '0 : wr_q + 1'b1;
          end
          if (do_pop) rd_q <= (int'(rd_q) == DEPTH - 1) ? '0 : rd_q + 1'b1;
          case ({do_push, do_pop})
            2'b10:   cnt_q <= cnt_q + 1'b1;
            2'b01:   cnt_q <= cnt_q - 1'b1;
            default: ;
          endcase
        end
      end
    end
  endgenerate
endmodule
`default_nettype wire
