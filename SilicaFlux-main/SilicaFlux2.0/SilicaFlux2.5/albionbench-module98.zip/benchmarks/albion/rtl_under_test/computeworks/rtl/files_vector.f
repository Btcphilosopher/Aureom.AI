// HPC Module 03 vector array + Module 02 FP32 lanes -- reused unmodified
third_party/hpc-m03-vector-array/lane/hpc_vector_pkg.sv
third_party/hpc-m03-vector-array/hpc_varray_pkg.sv
third_party/hpc-m03-vector-array/lane/hpc_pipe.sv
third_party/hpc-m03-vector-array/lane/hpc_lzc.sv
third_party/hpc-m03-vector-array/lane/hpc_fp32_round.sv
third_party/hpc-m03-vector-array/lane/hpc_fp32_add.sv
third_party/hpc-m03-vector-array/lane/hpc_fp32_mul.sv
third_party/hpc-m03-vector-array/lane/hpc_fp32_fma.sv
third_party/hpc-m03-vector-array/lane/hpc_fp32_misc.sv
third_party/hpc-m03-vector-array/lane/hpc_int32_mul.sv
third_party/hpc-m03-vector-array/lane/hpc_vector_lane.sv
third_party/hpc-m03-vector-array/hpc_varray_fifo.sv
third_party/hpc-m03-vector-array/hpc_varray_issue.sv
third_party/hpc-m03-vector-array/hpc_varray_collect.sv
third_party/hpc-m03-vector-array/hpc_varray_reduce.sv
third_party/hpc-m03-vector-array/hpc_varray_perf.sv
third_party/hpc-m03-vector-array/hpc_vector_array.sv
