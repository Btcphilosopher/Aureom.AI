// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS :: sf_compute_tensor_exec
// Aureom.AI / SilicaFlux Albion
//
// INT8 GEMM executor.   D[M,N] (INT32) = A[M,K] (INT8) x B[K,N] (INT8)  [+ C_in]
//
// The arithmetic is done by the REUSED TENSORCORE 02 array (tensor_systolic_array,
// output-stationary, INT8 x INT8 -> INT32, accumulation wraps modulo 2^32).  This
// module only sequences it:
//
//   for each output block (mb, nb) of ROWS x COLS (edge blocks are partial tiles):
//     LOAD  : engine jobs copy the A row block (m rows x K bytes), the B column
//             block (K rows x n bytes) and, if ACC, the C_in block (m rows x 4n
//             bytes) from local memory into the staging buffers 0 / 1 / 2.
//             With two engines A and B load concurrently; with one they serialise.
//     LAUNCH: cfg {m, n, K} into the array.
//     STREAM: present k-slice s_k = { A[:,k] , B[k,:] } from staging (A lane i =
//             staging0[i*A_PITCH + k], B lane j = staging1[k*COLS + j]).
//     COLLECT: each result row (INT32 x COLS) is written to the OUT buffer; with
//             ACC the matching C_in word is added (wraps) on the fly.  Lanes
//             beyond n are zeroed by m_col_mask.
//     STORE : a WRITE2D job copies the m x 4n result bytes to DST.
//
// Operand ordering: A is row-major M x K (lda = K); B is row-major K x N
// (ldb = N); D/C are row-major M x N INT32 (ldd = N).  Slice k pairs A[i][k]
// with B[k][j] at PE(i,j) -- verified in tests against an independent reference.
//
// Resource limit: K <= KMAX (staging capacity); the decoder rejects larger K with
// CW_ST_RESLIMIT before this module is started.
// =============================================================================
`timescale 1ns/1ps
`include "sf_compute_defs.svh"
`default_nettype none

module sf_compute_tensor_exec #(
  parameter int ROWS      = 4,
  parameter int COLS      = 4,
  parameter int NUM_CP    = 1,
  parameter int STG_BYTES = 1024,
  parameter int SIW       = $clog2(STG_BYTES) + 1,
  parameter int OWB       = 16,
  parameter int A_PITCH   = STG_BYTES / ROWS
) (
  input  wire logic                       clk,
  input  wire logic                       rst_n,
  // ---------------------------------------------------------------- command
  input  wire logic                       start,
  output logic                            ready,
  input  wire logic [15:0]                m_i, n_i, k_i,
  input  wire logic [31:0]                src_a_i, src_b_i, src_c_i, dst_i,
  input  wire logic                       acc_i,
  output logic                            done,            // 1-cycle pulse
  output logic [`CW_ST_W-1:0]             status_o,
  output logic [15:0]                     detail_o,
  output logic [31:0]                     out_bytes_o,
  output logic [47:0]                     macs_o,
  output logic [39:0]                     array_busy_o,
  output logic                            ph_load, ph_compute, ph_store,
  // ---------------------------------------------------------------- adapter jobs
  output logic [NUM_CP-1:0]               job_valid,
  input  wire logic [NUM_CP-1:0]          job_ready,
  output logic [NUM_CP*2-1:0]             job_kind,
  output logic [NUM_CP*32-1:0]            job_base,
  output logic [NUM_CP*16-1:0]            job_rows,
  output logic [NUM_CP*32-1:0]            job_rowbytes,
  output logic [NUM_CP*32-1:0]            job_stride,
  output logic [NUM_CP*2-1:0]             job_stg,
  output logic [NUM_CP*SIW-1:0]           job_stg_base,
  output logic [NUM_CP*SIW-1:0]           job_stg_pitch,
  input  wire logic [NUM_CP-1:0]          job_done,
  input  wire logic [NUM_CP*3-1:0]        job_err,
  input  wire logic [STG_BYTES*8-1:0]     stg0_flat,
  input  wire logic [STG_BYTES*8-1:0]     stg1_flat,
  input  wire logic [STG_BYTES*8-1:0]     stg2_flat,
  output logic                            o_wr_en,
  output logic [SIW-1:0]                  o_wr_idx,
  output logic [OWB*8-1:0]                o_wr_data
);
  localparam int KW   = 17;
  localparam int MW   = $clog2(ROWS + 1);
  localparam int NW   = $clog2(COLS + 1);
  localparam int RIDW = (ROWS > 1) ? $clog2(ROWS) : 1;

  initial begin
    if (OWB < 4 * COLS) $fatal(1, "sf_compute_tensor_exec: OWB must be >= 4*COLS");
    if (A_PITCH * ROWS > STG_BYTES) $fatal(1, "sf_compute_tensor_exec: A_PITCH too large");
  end

  // job types
  localparam int JT_A = 0, JT_B = 1, JT_C = 2, JT_S = 3;
  localparam int EA = 0;
  localparam int EC = 0;
  localparam int EB = (NUM_CP > 1) ? 1 : 0;
  localparam int ES = 0;

  typedef enum logic [3:0] {
    S_IDLE, S_SETUP, S_LOAD, S_LAUNCH, S_STREAM, S_STORE_ISSUE, S_STORE_WAIT, S_NEXT, S_FINISH
  } st_e;
  st_e st_q;

  // command registers
  logic [15:0] m_q, n_q, k_q;
  logic [31:0] a_q, b_q, c_q, d_q;
  logic        acc_q;
  logic [15:0] mb_q, nb_q;          // current block indices
  logic [15:0] nbm_q, nbn_q;        // block counts
  logic [15:0] mblk_q, nblk_q;      // current block extents
  // pending loads / bookkeeping
  logic        pa_q, pb_q, pc_q, ps_q;
  logic [NUM_CP-1:0] eng_act_q;
  logic [NUM_CP*2-1:0] eng_jt_q;
  logic [2:0]  err_code_q;
  logic [3:0]  err_phase_q;
  logic        int_err_q;
  logic [39:0] busy_sum_q;
  logic [31:0] blocks_q;

  assign ready = (st_q == S_IDLE);

  // ---------------------------------------------------------------------------
  // job generation
  // ---------------------------------------------------------------------------
  // geometry of the current block (32-bit arithmetic; all values validated upstream)
  wire [31:0] row0   = 32'(mb_q) * 32'(ROWS);
  wire [31:0] col0   = 32'(nb_q) * 32'(COLS);
  wire [31:0] a_base = a_q + row0 * 32'(k_q);
  wire [31:0] b_base = b_q + col0;
  wire [31:0] c_base = c_q + (row0 * 32'(n_q) + col0) * 32'd4;
  wire [31:0] d_base = d_q + (row0 * 32'(n_q) + col0) * 32'd4;

  // which job each engine would start now
  logic [NUM_CP-1:0]   sel_v;
  logic [NUM_CP*2-1:0] sel_jt;
  always_comb begin
    sel_v  = '0;
    sel_jt = '0;
    for (int e = 0; e < NUM_CP; e++) begin
      if (st_q == S_LOAD) begin
        if      (pa_q && (EA == e)) begin sel_v[e] = 1'b1; sel_jt[e*2 +: 2] = 2'(JT_A); end
        else if (pb_q && (EB == e)) begin sel_v[e] = 1'b1; sel_jt[e*2 +: 2] = 2'(JT_B); end
        else if (pc_q && (EC == e)) begin sel_v[e] = 1'b1; sel_jt[e*2 +: 2] = 2'(JT_C); end
      end else if (st_q == S_STORE_ISSUE) begin
        if (ps_q && (ES == e)) begin sel_v[e] = 1'b1; sel_jt[e*2 +: 2] = 2'(JT_S); end
      end
    end
  end

  always_comb begin
    job_valid     = sel_v;
    job_kind      = '0;
    job_base      = '0;
    job_rows      = '0;
    job_rowbytes  = '0;
    job_stride    = '0;
    job_stg       = '0;
    job_stg_base  = '0;
    job_stg_pitch = '0;
    for (int e = 0; e < NUM_CP; e++) begin
      case (sel_jt[e*2 +: 2])
        2'(JT_A): begin
          job_kind[e*2 +: 2]           = `CW_JK_READ2D;
          job_base[e*32 +: 32]         = a_base;
          job_rows[e*16 +: 16]         = mblk_q;
          job_rowbytes[e*32 +: 32]     = 32'(k_q);
          job_stride[e*32 +: 32]       = 32'(k_q);
          job_stg[e*2 +: 2]            = 2'd0;
          job_stg_base[e*SIW +: SIW]   = '0;
          job_stg_pitch[e*SIW +: SIW]  = SIW'(A_PITCH);
        end
        2'(JT_B): begin
          job_kind[e*2 +: 2]           = `CW_JK_READ2D;
          job_base[e*32 +: 32]         = b_base;
          job_rows[e*16 +: 16]         = k_q;
          job_rowbytes[e*32 +: 32]     = 32'(nblk_q);
          job_stride[e*32 +: 32]       = 32'(n_q);
          job_stg[e*2 +: 2]            = 2'd1;
          job_stg_base[e*SIW +: SIW]   = '0;
          job_stg_pitch[e*SIW +: SIW]  = SIW'(COLS);
        end
        2'(JT_C): begin
          job_kind[e*2 +: 2]           = `CW_JK_READ2D;
          job_base[e*32 +: 32]         = c_base;
          job_rows[e*16 +: 16]         = mblk_q;
          job_rowbytes[e*32 +: 32]     = 32'(nblk_q) * 32'd4;
          job_stride[e*32 +: 32]       = 32'(n_q) * 32'd4;
          job_stg[e*2 +: 2]            = 2'd2;
          job_stg_base[e*SIW +: SIW]   = '0;
          job_stg_pitch[e*SIW +: SIW]  = SIW'(4 * COLS);
        end
        default: begin  // JT_S : store the result block from the OUT buffer
          job_kind[e*2 +: 2]           = `CW_JK_WRITE2D;
          job_base[e*32 +: 32]         = d_base;
          job_rows[e*16 +: 16]         = mblk_q;
          job_rowbytes[e*32 +: 32]     = 32'(nblk_q) * 32'd4;
          job_stride[e*32 +: 32]       = 32'(n_q) * 32'd4;
          job_stg[e*2 +: 2]            = 2'd3;
          job_stg_base[e*SIW +: SIW]   = '0;
          job_stg_pitch[e*SIW +: SIW]  = SIW'(4 * COLS);
        end
      endcase
      // an engine that is not selected must present an idle job
      if (!sel_v[e]) begin
        job_kind[e*2 +: 2] = '0; job_base[e*32 +: 32] = '0; job_rows[e*16 +: 16] = '0;
        job_rowbytes[e*32 +: 32] = '0; job_stride[e*32 +: 32] = '0; job_stg[e*2 +: 2] = '0;
        job_stg_base[e*SIW +: SIW] = '0; job_stg_pitch[e*SIW +: SIW] = '0;
      end
    end
  end

  wire [NUM_CP-1:0] job_acc = job_valid & job_ready;
  wire              all_idle = (eng_act_q == '0);

  // ---------------------------------------------------------------------------
  // TENSORCORE 02 array
  // ---------------------------------------------------------------------------
  logic              tc_cfg_valid, tc_cfg_ready, tc_cfg_reject;
  logic              tc_s_valid, tc_s_ready;
  logic [ROWS*8-1:0] tc_s_a;
  logic [COLS*8-1:0] tc_s_b;
  logic [KW-1:0]     tc_s_k;
  logic              tc_m_valid;
  logic [RIDW-1:0]   tc_m_row;
  logic [COLS*32-1:0] tc_m_data;
  logic [COLS-1:0]   tc_m_col_mask;
  logic              tc_m_last;
  logic              tc_busy, tc_tile_done, tc_align_err;
  logic [39:0]       tc_perf_busy, tc_perf_issue, tc_perf_stall_up, tc_perf_stall_ext, tc_perf_mac, tc_perf_pad;

  tensor_systolic_array #(
    .ARRAY_ROWS(ROWS), .ARRAY_COLS(COLS), .DATA_WIDTH(8), .ACC_WIDTH(32),
    .K_WIDTH(KW), .MUL_PIPE(0), .CHECK_ALIGN(1), .PERF_EN(1)
  ) u_tc (
    .clk, .rst_n,
    .cfg_valid(tc_cfg_valid), .cfg_ready(tc_cfg_ready),
    .cfg_m(MW'(mblk_q)), .cfg_n(NW'(nblk_q)), .cfg_k(KW'(k_q)), .cfg_reject(tc_cfg_reject),
    .s_valid(tc_s_valid), .s_ready(tc_s_ready), .s_a(tc_s_a), .s_b(tc_s_b), .s_k(tc_s_k),
    .stall_i(1'b0),
    .m_valid(tc_m_valid), .m_ready(1'b1), .m_row(tc_m_row), .m_data(tc_m_data),
    .m_col_mask(tc_m_col_mask), .m_last(tc_m_last),
    .busy(tc_busy), .tile_done(tc_tile_done), .align_err(tc_align_err),
    .perf_busy(tc_perf_busy), .perf_issue(tc_perf_issue), .perf_stall_up(tc_perf_stall_up),
    .perf_stall_ext(tc_perf_stall_ext), .perf_mac(tc_perf_mac), .perf_pad(tc_perf_pad)
  );

  assign tc_cfg_valid = (st_q == S_LAUNCH);
  assign tc_s_valid   = (st_q == S_STREAM);

  // k-slice assembly from staging
  always_comb begin
    tc_s_a = '0;
    tc_s_b = '0;
    for (int i = 0; i < ROWS; i++) begin
      int ai;
      ai = i * A_PITCH + int'(tc_s_k);
      if (ai < STG_BYTES) tc_s_a[i*8 +: 8] = stg0_flat[ai*8 +: 8];
    end
    for (int j = 0; j < COLS; j++) begin
      int bi;
      bi = int'(tc_s_k) * COLS + j;
      if (bi < STG_BYTES) tc_s_b[j*8 +: 8] = stg1_flat[bi*8 +: 8];
    end
  end

  // result rows -> OUT buffer (with optional INT32 accumulation of C_in)
  always_comb begin
    o_wr_en   = (st_q == S_STREAM) && tc_m_valid;
    o_wr_idx  = SIW'(int'(tc_m_row) * (4 * COLS));
    o_wr_data = '0;
    for (int j = 0; j < COLS; j++) begin
      logic [31:0] cin, sum;
      int          ci;
      ci  = int'(tc_m_row) * (4 * COLS) + 4 * j;
      cin = '0;
      if (acc_q && (ci + 3 < STG_BYTES)) cin = stg2_flat[ci*8 +: 32];
      sum = tc_m_data[j*32 +: 32] + cin;                    // INT32 wraps modulo 2^32
      o_wr_data[j*32 +: 32] = tc_m_col_mask[j] ? sum : 32'd0;
    end
  end

  // ---------------------------------------------------------------------------
  // sequencing
  // ---------------------------------------------------------------------------
  assign ph_load    = (st_q == S_SETUP) || (st_q == S_LOAD);
  assign ph_compute = (st_q == S_LAUNCH) || (st_q == S_STREAM);
  assign ph_store   = (st_q == S_STORE_ISSUE) || (st_q == S_STORE_WAIT);

  wire last_blk_n = ((nb_q + 16'd1) >= nbn_q);
  wire last_blk_m = ((mb_q + 16'd1) >= nbm_q);

  logic [15:0] rem_m, rem_n;
  always_comb begin
    rem_m = m_q - 16'(row0);
    rem_n = n_q - 16'(col0);
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE;
      m_q <= '0; n_q <= '0; k_q <= '0; a_q <= '0; b_q <= '0; c_q <= '0; d_q <= '0; acc_q <= 1'b0;
      mb_q <= '0; nb_q <= '0; nbm_q <= '0; nbn_q <= '0; mblk_q <= '0; nblk_q <= '0;
      pa_q <= 1'b0; pb_q <= 1'b0; pc_q <= 1'b0; ps_q <= 1'b0;
      eng_act_q <= '0; eng_jt_q <= '0; err_code_q <= '0; err_phase_q <= '0; int_err_q <= 1'b0;
      busy_sum_q <= '0; blocks_q <= '0;
      done <= 1'b0; status_o <= `CW_ST_OK; detail_o <= '0; out_bytes_o <= '0; macs_o <= '0; array_busy_o <= '0;
    end else begin
      done <= 1'b0;

      // engine bookkeeping (jobs issued by this module).
      // ORDER MATTERS: an engine pulses job_done in the very cycle it becomes ready, so a new job can be
      // accepted in the same cycle as the previous job's done pulse.  Handle `done` first and `accept`
      // last so that acceptance wins on eng_act_q (the finished job's type is still read from the old
      // eng_jt_q, because that register is updated with a non-blocking assignment).
      for (int e = 0; e < NUM_CP; e++) begin
        if (job_done[e]) begin
          eng_act_q[e] <= 1'b0;
          if (job_err[e*3 +: 3] != 3'd0 && err_code_q == 3'd0) begin
            err_code_q <= job_err[e*3 +: 3];
            case (eng_jt_q[e*2 +: 2])
              2'(JT_A): err_phase_q <= `CW_PH_LOAD_A;
              2'(JT_B): err_phase_q <= `CW_PH_LOAD_B;
              2'(JT_C): err_phase_q <= `CW_PH_LOAD_C;
              default:  err_phase_q <= `CW_PH_STORE;
            endcase
          end
        end
        if (job_acc[e]) begin
          eng_act_q[e]          <= 1'b1;
          eng_jt_q[e*2 +: 2]    <= sel_jt[e*2 +: 2];
          case (sel_jt[e*2 +: 2])
            2'(JT_A): pa_q <= 1'b0;
            2'(JT_B): pb_q <= 1'b0;
            2'(JT_C): pc_q <= 1'b0;
            default:  ps_q <= 1'b0;
          endcase
        end
      end
      if (tc_cfg_reject || tc_align_err) int_err_q <= 1'b1;

      case (st_q)
        S_IDLE: if (start) begin
          m_q <= m_i; n_q <= n_i; k_q <= k_i;
          a_q <= src_a_i; b_q <= src_b_i; c_q <= src_c_i; d_q <= dst_i; acc_q <= acc_i;
          mb_q <= '0; nb_q <= '0;
          nbm_q <= 16'((32'(m_i) + 32'(ROWS - 1)) / 32'(ROWS));
          nbn_q <= 16'((32'(n_i) + 32'(COLS - 1)) / 32'(COLS));
          err_code_q <= '0; err_phase_q <= '0; int_err_q <= 1'b0;
          busy_sum_q <= '0; blocks_q <= '0;
          st_q <= S_SETUP;
        end

        S_SETUP: begin
          // current block extents; load A when starting a new row block, always load B (and C)
          mblk_q <= (rem_m > 16'(ROWS)) ? 16'(ROWS) : rem_m;
          nblk_q <= (rem_n > 16'(COLS)) ? 16'(COLS) : rem_n;
          pa_q   <= (nb_q == 16'd0);
          pb_q   <= 1'b1;
          pc_q   <= acc_q;
          st_q   <= S_LOAD;
        end

        S_LOAD: begin
          if (!pa_q && !pb_q && !pc_q && all_idle) begin
            if (err_code_q != 3'd0) st_q <= S_FINISH;
            else                    st_q <= S_LAUNCH;
          end
        end

        S_LAUNCH: if (tc_cfg_ready) st_q <= S_STREAM;   // cfg_valid is asserted in this state

        S_STREAM: if (tc_m_valid && tc_m_last) begin
          busy_sum_q <= busy_sum_q + tc_perf_busy;
          ps_q       <= 1'b1;
          st_q       <= S_STORE_ISSUE;
        end

        S_STORE_ISSUE: if (!ps_q) st_q <= S_STORE_WAIT;

        S_STORE_WAIT: if (all_idle) begin
          blocks_q <= blocks_q + 32'd1;
          if (err_code_q != 3'd0) st_q <= S_FINISH;
          else                    st_q <= S_NEXT;
        end

        S_NEXT: begin
          if (!last_blk_n) begin
            nb_q <= nb_q + 16'd1;
            st_q <= S_SETUP;
          end else if (!last_blk_m) begin
            nb_q <= '0;
            mb_q <= mb_q + 16'd1;
            st_q <= S_SETUP;
          end else begin
            st_q <= S_FINISH;
          end
        end

        S_FINISH: begin
          done         <= 1'b1;
          array_busy_o <= busy_sum_q;
          if (err_code_q != 3'd0) begin
            status_o    <= `CW_ST_MEM_ERR;
            detail_o    <= {err_phase_q, 9'd0, err_code_q};
            out_bytes_o <= '0;
            macs_o      <= '0;
          end else if (int_err_q) begin
            status_o    <= `CW_ST_MEM_ERR;
            detail_o    <= {4'hF, 12'd0};
            out_bytes_o <= '0;
            macs_o      <= '0;
          end else begin
            status_o    <= `CW_ST_OK;
            detail_o    <= '0;
            out_bytes_o <= 32'(m_q) * 32'(n_q) * 32'd4;
            macs_o      <= 48'(m_q) * 48'(n_q) * 48'(k_q);
          end
          st_q <= S_IDLE;
        end

        default: st_q <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
