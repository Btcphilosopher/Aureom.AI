# Provenance of the reused IP

Everything in this directory is **reused unmodified** from the SilicaFlux archives in the repository `btcphilosopher/Aureom.AI`
(`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`). Nothing was copied into new RTL and edited: the new RTL instantiates these blocks.

| Directory | Source archive | Archive SHA-256 | Members used | Files |
|---|---|---|---|---|
| `p84-ironmemory/` | `silicaflux-p84-ironmemory.zip` | `69c772acc4997db05bb8064a76a0fb5c1da6577953e527fbddcb9d5f359a752d` | `silicaflux-ironmemory/rtl/albion/*.sv` (12 are compiled and instantiated; `sf_iron_wide_port.sv` is vendored for completeness but **not used**; the simulation-only `sim/sf_iron_simdram.sv` is **not** shipped) | 13 |
| `tensorcore02/` | `silicaflux-tensorcore02.zip` | `0a2ab37797b30ab3eda08d7e98b47dadd1549f8ab588d434c98b18b0a048370f` | `silicaflux-tensorcore02/rtl/*.sv` | 4 |
| `hpc-m03-vector-array/` | `silicaflux-hpc-m03-vector-array.zip` | `c1b6d2946c5bb56b22bcaeb1da6940f61c9a07defa21a2ea40a532138d021f3d` | `silicaflux-hpc-m03-vector-array/rtl/*.sv` and `rtl/lane/*.sv` | 17 |

The ten files in `hpc-m03-vector-array/lane/` are the HPC Module 02 FP32 / INT32 vector lane (`silicaflux-hpc-m02-vector-lane.zip`, archive SHA-256
`e76a238e143113e1f2d71789b2527506d8403089968ed0cff0e4368348d988be`); they were compared byte for byte with the M02 originals and are identical.

`SHA256SUMS` lists the hash of every vendored file. Verify with:

```bash
python3 scripts/check_vendor.py                                            # against SHA256SUMS
python3 scripts/check_vendor.py --archives <path>/SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5   # byte-for-byte against the original zips
```

Each reused block carries the evidence its own project published (not repeated here): IronMemory 20/20 regression runs and 12/12 mutants; TENSORCORE 02 identical
Icarus / Verilator logs and 44/47 mutants; HPC M03 1632/1632 Verilator and 288/288 Icarus runs and 32/32 mutants, with its lanes checked against Berkeley SoftFloat-3e.
This project verifies the *integration* and everything new (`docs/compute_works/07_VERIFICATION.md`).
