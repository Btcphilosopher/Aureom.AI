// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS :: sf_compute_perf
// Aureom.AI / SilicaFlux Albion
//
// Performance counters.  40-bit, SATURATING (a read is never silently wrong), derived
// only from real events: handshakes, state occupancy and the executors' own results.
// Counter map: sf_compute_defs.svh (CW_PC_*).  Nothing here estimates power; the
// activity counters (array busy, vector active, memory words) are the inputs a
// power model would need, nothing more.
//
// Utilisation definitions (see docs/compute_works/06_PERFORMANCE.md):
//   useful ops / cycle        = (TENSOR_MACS*2 + VEC_ELEMS*flops) / CYCLES  (reported by the benchmark)
//   tensor MAC utilisation    = TENSOR_MACS / TENSOR_PEAK        (peak = ROWS*COLS MAC slots for every
//                                                                  cycle a GEMM command is in flight,
//                                                                  including load / store / overhead)
//   array utilisation         = TENSOR_MACS / (ROWS*COLS * TENSOR_ARRAY)   (only cycles the array is busy)
//   vector utilisation        = VEC_ELEMS / VEC_PEAK             (peak = NUM_LANES element slots per
//                                                                  cycle a vector command is in flight)
// =============================================================================
`timescale 1ns/1ps
`include "sf_compute_defs.svh"
`default_nettype none

module sf_compute_perf #(
  parameter int NUM_CP    = 1,
  parameter int TENSOR_PE = 16,       // ROWS * COLS
  parameter int NUM_LANES = 4,
  parameter int CW        = 40
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 clear,
  input  wire logic [5:0]           sel,
  output logic [CW-1:0]             val,
  output logic [`CW_PC_N*CW-1:0]    cnt_flat,
  // level / pulse inputs
  input  wire logic                 clk_en,
  input  wire logic                 busy,
  input  wire logic                 ph_load, ph_compute, ph_store,
  input  wire logic                 ev_cmd_in,
  input  wire logic                 ev_drop_badq,
  input  wire logic                 ev_cpl,
  input  wire logic [`CW_ST_W-1:0]  ev_status,
  input  wire logic [31:0]          ev_qwait,
  input  wire logic [31:0]          ev_exec,
  input  wire logic                 ev_gemm, ev_vec,
  input  wire logic [47:0]          ev_macs,
  input  wire logic [39:0]          ev_array_busy,
  input  wire logic [31:0]          ev_vec_elems,
  input  wire logic [39:0]          ev_vec_active,
  input  wire logic [31:0]          ev_out_bytes,
  input  wire logic [31:0]          ev_scrub_bytes,
  input  wire logic [31:0]          ev_scrub_bytes_pol,
  input  wire logic                 ev_stall_cpl,
  input  wire logic [NUM_CP-1:0]    ev_rd, ev_wr, ev_stall, ev_err
);
  logic [CW-1:0] c [`CW_PC_N];

  function automatic int popc(input logic [NUM_CP-1:0] v);
    int n;
    n = 0;
    for (int i = 0; i < NUM_CP; i++) n += int'(v[i]);
    popc = n;
  endfunction

  wire st_ok  = (ev_status == `CW_ST_OK);
  wire st_err = (ev_status == `CW_ST_MEM_ERR);
  wire st_rej = !st_ok && !st_err;

  // per-cycle increments (all widths <= 64 bit; saturating add below)
  logic [63:0] inc [`CW_PC_N];
  always_comb begin
    for (int i = 0; i < `CW_PC_N; i++) inc[i] = 64'd0;
    inc[`CW_PC_CYCLES]       = 64'd1;
    inc[`CW_PC_CLKEN_CYCLES] = {63'd0, clk_en};
    inc[`CW_PC_BUSY]         = {63'd0, busy};
    inc[`CW_PC_CMD_IN]       = {63'd0, ev_cmd_in};
    inc[`CW_PC_CMD_DONE]     = {63'd0, ev_cpl};
    inc[`CW_PC_CMD_OK]       = {63'd0, ev_cpl && st_ok};
    inc[`CW_PC_CMD_REJ]      = {63'd0, ev_cpl && st_rej};
    inc[`CW_PC_CMD_ERR]      = {63'd0, ev_cpl && st_err};
    inc[`CW_PC_QWAIT_SUM]    = ev_cpl ? {32'd0, ev_qwait} : 64'd0;
    inc[`CW_PC_EXEC_SUM]     = ev_cpl ? {32'd0, ev_exec}  : 64'd0;
    inc[`CW_PC_OVERHEAD]     = {63'd0, busy && !ph_load && !ph_compute && !ph_store};
    inc[`CW_PC_PH_LOAD]      = {63'd0, ph_load};
    inc[`CW_PC_PH_COMPUTE]   = {63'd0, ph_compute};
    inc[`CW_PC_PH_STORE]     = {63'd0, ph_store};
    inc[`CW_PC_TENSOR_MACS]  = {16'd0, ev_macs};
    inc[`CW_PC_TENSOR_ARRAY] = {24'd0, ev_array_busy};
    inc[`CW_PC_TENSOR_PEAK]  = (ev_cpl && ev_gemm) ? ({32'd0, ev_exec} * 64'(TENSOR_PE)) : 64'd0;
    inc[`CW_PC_VEC_ELEMS]    = {32'd0, ev_vec_elems};
    inc[`CW_PC_VEC_PEAK]     = (ev_cpl && ev_vec) ? ({32'd0, ev_exec} * 64'(NUM_LANES)) : 64'd0;
    inc[`CW_PC_VEC_ACTIVE]   = {24'd0, ev_vec_active};
    inc[`CW_PC_MEM_RD_WORDS] = 64'(popc(ev_rd));
    inc[`CW_PC_MEM_WR_WORDS] = 64'(popc(ev_wr));
    inc[`CW_PC_MEM_STALL]    = 64'(popc(ev_stall));
    inc[`CW_PC_MEM_ERR_RSP]  = 64'(popc(ev_err));
    inc[`CW_PC_OUT_BYTES]    = {32'd0, ev_out_bytes};
    inc[`CW_PC_REJ_OWNER]    = {63'd0, ev_cpl && (ev_status == `CW_ST_OWNER)};
    inc[`CW_PC_REJ_DENIED]   = {63'd0, ev_cpl && (ev_status == `CW_ST_DENIED)};
    inc[`CW_PC_REJ_OTHER]    = {63'd0, ev_cpl && st_rej && (ev_status != `CW_ST_OWNER) && (ev_status != `CW_ST_DENIED)};
    inc[`CW_PC_SCRUB_BYTES]  = {32'd0, ev_scrub_bytes} + {32'd0, ev_scrub_bytes_pol};
    inc[`CW_PC_STALL_CPL]    = {63'd0, ev_stall_cpl};
    inc[`CW_PC_DROP_BADQ]    = {63'd0, ev_drop_badq};
  end

  localparam logic [CW-1:0] SAT = '1;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < `CW_PC_N; i++) c[i] <= '0;
    end else if (clear) begin
      for (int i = 0; i < `CW_PC_N; i++) c[i] <= '0;
    end else begin
      for (int i = 0; i < `CW_PC_N; i++) begin
        logic [CW:0] sum;
        sum = {1'b0, c[i]} + {1'b0, inc[i][CW-1:0]};
        if (inc[i][63:CW] != '0 || sum[CW]) c[i] <= SAT;      // saturate (never wrap)
        else                                c[i] <= sum[CW-1:0];
      end
      // maxima
      if (ev_cpl && ({8'd0, ev_qwait} > c[`CW_PC_QWAIT_MAX])) c[`CW_PC_QWAIT_MAX] <= {8'd0, ev_qwait};
      if (ev_cpl && ({8'd0, ev_exec}  > c[`CW_PC_EXEC_MAX]))  c[`CW_PC_EXEC_MAX]  <= {8'd0, ev_exec};
    end
  end

  always_comb begin
    for (int i = 0; i < `CW_PC_N; i++) cnt_flat[i*CW +: CW] = c[i];
    val = (int'(sel) < `CW_PC_N) ? c[sel] : '0;
  end
endmodule
`default_nettype wire
