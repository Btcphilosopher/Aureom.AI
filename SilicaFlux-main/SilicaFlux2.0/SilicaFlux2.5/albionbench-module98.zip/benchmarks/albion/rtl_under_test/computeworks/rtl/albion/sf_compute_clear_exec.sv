// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS :: sf_compute_clear_exec
// Aureom.AI / SilicaFlux Albion
//
// Zero-fill of LEN bytes at BASE through memory-engine 0 (a FILL0 job).  Used by the
// CLEAR command (tenant scrubbing its own buffer) and by the guard's SCRUB
// (supervisor clearing a revoked region before it can be reassigned).  Byte strobes
// keep the fill exact: bytes outside [BASE, BASE+LEN) are never modified.
// =============================================================================
`timescale 1ns/1ps
`include "sf_compute_defs.svh"
`default_nettype none

module sf_compute_clear_exec #(
  parameter int NUM_CP = 1,
  parameter int SIW    = 11
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 start,
  output logic                      ready,
  input  wire logic [31:0]          base,
  input  wire logic [31:0]          len,
  output logic                      done,       // 1-cycle pulse
  output logic [2:0]                err,        // first IronMemory error code (0 = none)
  output logic                      active,
  // adapter job interface (all engines; only engine 0 is driven)
  output logic [NUM_CP-1:0]         job_valid,
  input  wire logic [NUM_CP-1:0]    job_ready,
  output logic [NUM_CP*2-1:0]       job_kind,
  output logic [NUM_CP*32-1:0]      job_base,
  output logic [NUM_CP*16-1:0]      job_rows,
  output logic [NUM_CP*32-1:0]      job_rowbytes,
  output logic [NUM_CP*32-1:0]      job_stride,
  output logic [NUM_CP*2-1:0]       job_stg,
  output logic [NUM_CP*SIW-1:0]     job_stg_base,
  output logic [NUM_CP*SIW-1:0]     job_stg_pitch,
  input  wire logic [NUM_CP-1:0]    job_done,
  input  wire logic [NUM_CP*3-1:0]  job_err
);
  typedef enum logic [1:0] {S_IDLE, S_ISSUE, S_WAIT} st_e;
  st_e         st_q;
  logic [31:0] base_q, len_q;

  assign ready  = (st_q == S_IDLE);
  assign active = (st_q != S_IDLE);

  always_comb begin
    job_valid     = '0;
    job_kind      = '0;
    job_base      = '0;
    job_rows      = '0;
    job_rowbytes  = '0;
    job_stride    = '0;
    job_stg       = '0;
    job_stg_base  = '0;
    job_stg_pitch = '0;
    if (st_q == S_ISSUE) begin
      job_valid[0]          = 1'b1;
      job_kind[1:0]         = `CW_JK_FILL0;
      job_base[31:0]        = base_q;
      job_rows[15:0]        = 16'd1;
      job_rowbytes[31:0]    = len_q;
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE; base_q <= '0; len_q <= '0; done <= 1'b0; err <= '0;
    end else begin
      done <= 1'b0;
      case (st_q)
        S_IDLE:  if (start) begin base_q <= base; len_q <= len; err <= '0; st_q <= S_ISSUE; end
        S_ISSUE: if (job_ready[0]) st_q <= S_WAIT;
        S_WAIT:  if (job_done[0]) begin
          err  <= job_err[2:0];
          done <= 1'b1;
          st_q <= S_IDLE;
        end
        default: st_q <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
