#!/usr/bin/env python3
"""Independent IEEE-754 binary32 reference for ComputeWorks (Project 88).

Pure Python, exact rational arithmetic (fractions.Fraction): every result is computed exactly and then
rounded ONCE to binary32 in the requested rounding mode.  It shares no code or algorithm with the
hardware (the SilicaFlux lane) and none with Berkeley SoftFloat.  It implements the RISC-V conventions
the lane documents:

  * rounding modes RNE 0, RTZ 1, RDN 2, RUP 3, RMM 4 (RISC-V frm encoding);
  * canonical quiet NaN 0x7FC00000 for every NaN result; NaN payloads are NOT propagated;
  * flags {NV, DZ, OF, UF, NX} = bits 4..0 (RISC-V fflags order); DZ is never raised;
  * tininess is detected AFTER rounding (the result, rounded with unbounded exponent range, is below
    the smallest normal) and UF is raised only if tiny AND inexact;
  * no flush-to-zero: subnormals are exact.

Operations: add, mul, fma (a*b + c with a single rounding), plus INT32 add / mul (mod 2^32).
"""
from fractions import Fraction
import struct

QNAN = 0x7FC00000
RNE, RTZ, RDN, RUP, RMM = 0, 1, 2, 3, 4
NV, DZ, OF, UF, NX = 16, 8, 4, 2, 1


def f2bits(x: float) -> int:
    return struct.unpack("<I", struct.pack("<f", x))[0]


def bits2f(b: int) -> float:
    return struct.unpack("<f", struct.pack("<I", b & 0xFFFFFFFF))[0]


def classify(b: int):
    """Returns (kind, sign, value).  kind in 'nan', 'snan', 'inf', 'fin'. value is an exact Fraction for 'fin'."""
    s = b >> 31
    e = (b >> 23) & 0xFF
    m = b & 0x7FFFFF
    if e == 0xFF:
        if m == 0:
            return "inf", s, None
        return ("nan" if (m >> 22) & 1 else "snan"), s, None
    if e == 0:
        v = Fraction(m, 1) * Fraction(1, 1 << 149)          # 2^-126 * m / 2^23
    else:
        v = Fraction((1 << 23) | m, 1) * (Fraction(2) ** (e - 127 - 23))
    return "fin", s, (-v if s else v)


def _round_inc(rm: int, sign: int, lsb: int, guard: int, sticky: int) -> int:
    if rm == RNE:
        return 1 if (guard and (sticky or lsb)) else 0
    if rm == RTZ:
        return 0
    if rm == RDN:
        return 1 if (sign and (guard or sticky)) else 0
    if rm == RUP:
        return 1 if ((not sign) and (guard or sticky)) else 0
    if rm == RMM:
        return guard
    raise ValueError("bad rounding mode")


def _round_exact(x: Fraction, rm: int, sign_for_zero: int):
    """Round exact nonzero rational x to binary32.  Returns (bits, flags)."""
    assert x != 0
    sign = 1 if x < 0 else 0
    ax = -x if sign else x
    # exponent e such that 2^e <= ax < 2^(e+1)
    e = ax.numerator.bit_length() - ax.denominator.bit_length()
    if Fraction(2) ** e > ax:
        e -= 1
    elif Fraction(2) ** (e + 1) <= ax:
        e += 1
    assert Fraction(2) ** e <= ax < Fraction(2) ** (e + 1)

    def quantise(scale_exp):
        """Round ax to a multiple of 2^scale_exp; returns (integer q, inexact)."""
        q = ax / (Fraction(2) ** scale_exp)
        fl = q.numerator // q.denominator
        rem = q - fl
        guard = 1 if rem >= Fraction(1, 2) else 0
        # sticky = any bit below the guard bit
        sticky = 1 if (rem - (Fraction(1, 2) if guard else 0)) != 0 else 0
        inc = _round_inc(rm, sign, fl & 1, guard, sticky)
        return fl + inc, (rem != 0)

    flags = 0
    # (1) rounding with UNBOUNDED exponent range, 24-bit precision: used for tininess and overflow
    q_unb, _ = quantise(e - 23)
    r_unb = Fraction(q_unb) * (Fraction(2) ** (e - 23))
    tiny = r_unb < Fraction(2) ** -126
    # (2) actual rounding
    if e < -126:
        q, inexact = quantise(-149)          # subnormal grid: multiples of 2^-149
        val = Fraction(q) * (Fraction(2) ** -149)
    else:
        q, inexact = quantise(e - 23)
        val = Fraction(q) * (Fraction(2) ** (e - 23))
    if inexact:
        flags |= NX
        if tiny:
            flags |= UF
    # overflow: result (unbounded-range rounding) >= 2^128
    maxfin = (Fraction((1 << 24) - 1) * (Fraction(2) ** (127 - 23)))
    if r_unb >= Fraction(2) ** 128 or val > maxfin:
        flags |= OF | NX
        # overflow result by mode
        to_inf = (rm == RNE) or (rm == RMM) or (rm == RUP and not sign) or (rm == RDN and sign)
        if to_inf:
            return (sign << 31) | 0x7F800000, flags
        return (sign << 31) | 0x7F7FFFFF, flags
    # encode val (exact binary32 value, possibly rounded up to a power of two / to the next binade)
    if val == 0:
        return (sign << 31), flags
    if val < Fraction(2) ** -126:
        m = int(val / (Fraction(2) ** -149))
        return (sign << 31) | m, flags
    ee = val.numerator.bit_length() - val.denominator.bit_length()
    if Fraction(2) ** ee > val:
        ee -= 1
    elif Fraction(2) ** (ee + 1) <= val:
        ee += 1
    mant = val / (Fraction(2) ** ee) - 1
    mant_bits = int(mant * (1 << 23))
    return (sign << 31) | ((ee + 127) << 23) | mant_bits, flags


def fma(a: int, b: int, c: int, rm: int, negate_prod: bool = False, negate_c: bool = False):
    """(+/-a*b) +/- c with one rounding.  Returns (bits, flags)."""
    ka, sa, va = classify(a)
    kb, sb, vb = classify(b)
    kc, sc, vc = classify(c)
    flags = 0
    if "snan" in (ka, kb, kc):
        flags |= NV
    if "nan" in (ka, kb, kc) or "snan" in (ka, kb, kc):
        # inf * 0 raises NV even when c is a NaN (RISC-V / SoftFloat behaviour)
        if (ka == "inf" and kb == "fin" and vb == 0) or (kb == "inf" and ka == "fin" and va == 0):
            flags |= NV
        return QNAN, flags
    psign = (sa ^ sb) ^ (1 if negate_prod else 0)
    csign = sc ^ (1 if negate_c else 0)
    prod_inf = ka == "inf" or kb == "inf"
    if prod_inf:
        if (ka == "fin" and va == 0) or (kb == "fin" and vb == 0):
            return QNAN, flags | NV                                  # inf * 0
        if kc == "inf" and csign != psign:
            return QNAN, flags | NV                                  # inf - inf
        return (psign << 31) | 0x7F800000, flags
    if kc == "inf":
        return (csign << 31) | 0x7F800000, flags
    prod = va * vb
    if negate_prod:
        prod = -prod
    cv = -vc if negate_c else vc
    exact = prod + cv
    if exact == 0:
        # exact zero sum/product: sign rules
        prod_zero = (va == 0 or vb == 0)
        c_zero = (cv == 0)
        if prod_zero and c_zero:
            # both addends are zeros: x + y with signs; (+0)+(-0) = +0 except RDN -> -0; same-sign keeps sign
            zs = psign if psign == csign else (1 if rm == RDN else 0)
        else:
            zs = 1 if rm == RDN else 0                               # exact cancellation: +0, or -0 in RDN
        return (zs << 31), flags
    bits, f = _round_exact(exact, rm, 0)
    return bits, flags | f


def fadd(a: int, b: int, rm: int):
    """a + b (single rounding), implemented as the product-free sum so that exact-zero rules are IEEE's."""
    ka, sa, va = classify(a)
    kb, sb, vb = classify(b)
    flags = 0
    if "snan" in (ka, kb):
        flags |= NV
    if ka in ("nan", "snan") or kb in ("nan", "snan"):
        return QNAN, flags
    if ka == "inf" and kb == "inf":
        if sa != sb:
            return QNAN, flags | NV
        return (sa << 31) | 0x7F800000, flags
    if ka == "inf":
        return (sa << 31) | 0x7F800000, flags
    if kb == "inf":
        return (sb << 31) | 0x7F800000, flags
    exact = va + vb
    if exact == 0:
        if va == 0 and vb == 0:
            zs = sa if sa == sb else (1 if rm == RDN else 0)
        else:
            zs = 1 if rm == RDN else 0
        return (zs << 31), flags
    bits, f = _round_exact(exact, rm, 0)
    return bits, flags | f


def fmul(a: int, b: int, rm: int):
    ka, sa, va = classify(a)
    kb, sb, vb = classify(b)
    flags = 0
    if "snan" in (ka, kb):
        flags |= NV
    if ka in ("nan", "snan") or kb in ("nan", "snan"):
        if (ka == "inf" and kb == "fin" and vb == 0) or (kb == "inf" and ka == "fin" and va == 0):
            flags |= NV
        return QNAN, flags
    s = sa ^ sb
    if ka == "inf" or kb == "inf":
        if (ka == "fin" and va == 0) or (kb == "fin" and vb == 0):
            return QNAN, flags | NV
        return (s << 31) | 0x7F800000, flags
    prod = va * vb
    if prod == 0:
        return (s << 31), flags
    bits, f = _round_exact(prod, rm, 0)
    return bits, flags | f


def iadd(a: int, b: int) -> int:
    return (a + b) & 0xFFFFFFFF


def imul(a: int, b: int) -> int:
    return (a * b) & 0xFFFFFFFF


# --------------------------------------------------------------------------------------------------
# self-check against numpy / the host float unit for the operations numpy can do exactly
# --------------------------------------------------------------------------------------------------
def _selftest(n=20000, seed=1):
    import random
    import numpy as np
    rnd = random.Random(seed)

    def rbits():
        k = rnd.random()
        if k < 0.15:
            return rnd.choice([0, 0x80000000, 0x7F800000, 0xFF800000, 0x7FC00000, 0x00000001, 0x007FFFFF,
                               0x00800000, 0x7F7FFFFF, 0xFF7FFFFF, 0x3F800000, 0xBF800000, 0x7F800001])
        if k < 0.35:
            return (rnd.getrandbits(1) << 31) | (rnd.randrange(0, 4) << 23) | rnd.getrandbits(23)  # tiny exps
        return rnd.getrandbits(32)
    bad = 0
    with np.errstate(all="ignore"):
        for _ in range(n):
            a, b = rbits(), rbits()
            x32, y32 = np.array([a], dtype=np.uint32).view(np.float32)[0], np.array([b], dtype=np.uint32).view(np.float32)[0]
            for name, ref, hw in (("add", np.float32(x32) + np.float32(y32), fadd(a, b, RNE)[0]),
                                  ("mul", np.float32(x32) * np.float32(y32), fmul(a, b, RNE)[0])):
                r = np.array([ref], dtype=np.float32).view(np.uint32)[0]
                if (r & 0x7F800000) == 0x7F800000 and (r & 0x7FFFFF):
                    r = QNAN                           # canonicalise NaN
                if int(r) != hw:
                    bad += 1
                    if bad < 6:
                        print(f"MISMATCH {name} {a:08x} {b:08x}: numpy {int(r):08x} model {hw:08x}")
    return bad


def _bracket_test(n=8000, seed=2):
    """Independent check of all five rounding modes for FMA (and therefore add / mul).

    For a finite exact value x the two float32 neighbours lo <= x <= hi are built with numpy
    (nextafter), not with this model.  Then:  RDN -> lo,  RUP -> hi,  RTZ -> the one toward zero,
    RNE -> the nearer one (tie: even mantissa),  RMM -> the nearer one (tie: larger magnitude).
    Results with |x| >= 2^127 (overflow region) are skipped here; they are covered by directed vectors."""
    import random
    import numpy as np
    rnd = random.Random(seed)
    bad = 0
    checked = 0

    def rb():
        k = rnd.random()
        if k < 0.3:
            return (rnd.getrandbits(1) << 31) | (rnd.randrange(0, 6) << 23) | rnd.getrandbits(23)   # subnormal / tiny
        return (rnd.getrandbits(1) << 31) | (rnd.randrange(40, 200) << 23) | rnd.getrandbits(23)
    with np.errstate(all="ignore"):
        for _ in range(n):
            a, b, c = rb(), rb(), rb()
            if classify(a)[0] != "fin" or classify(b)[0] != "fin" or classify(c)[0] != "fin":
                continue
            x = classify(a)[2] * classify(b)[2] + classify(c)[2]
            if x == 0 or abs(x) >= Fraction(2) ** 127:
                continue
            f = np.float32(float(x))
            fx = Fraction(float(f))
            if fx == x:
                lo = hi = f
            elif fx < x:
                lo, hi = f, np.nextafter(f, np.float32(np.inf))
            else:
                lo, hi = np.nextafter(f, np.float32(-np.inf)), f
            lov, hiv = Fraction(float(lo)), Fraction(float(hi))
            for rm in range(5):
                if lov == hiv:
                    want = lo
                elif rm == RDN:
                    want = lo
                elif rm == RUP:
                    want = hi
                elif rm == RTZ:
                    want = lo if x > 0 else hi
                else:
                    dl, dh = x - lov, hiv - x
                    if dl < dh:
                        want = lo
                    elif dh < dl:
                        want = hi
                    else:       # exact tie
                        if rm == RNE:
                            want = lo if (int(np.array([lo], dtype=np.float32).view(np.uint32)[0]) & 1) == 0 else hi
                        else:   # RMM: away from zero = larger magnitude
                            want = hi if x > 0 else lo
                wbits = int(np.array([want], dtype=np.float32).view(np.uint32)[0])
                bits, fl = fma(a, b, c, rm)
                checked += 1
                # a result of exactly zero from a nonzero x cannot happen here; compare bit-exact
                if bits != wbits:
                    bad += 1
                    if bad < 6:
                        print(f"BRACKET FAIL rm={rm} a={a:08x} b={b:08x} c={c:08x}: model {bits:08x} expected {wbits:08x}")
                # inexact flag must agree with "x is not representable"
                if bool(fl & NX) != (lov != hiv):
                    bad += 1
                    if bad < 6:
                        print(f"NX FAIL rm={rm} a={a:08x} b={b:08x} c={c:08x}: flags {fl:02x}")
    print(f"  bracket test checked {checked} (vector, mode) pairs")
    return bad


if __name__ == "__main__":
    bad = _selftest()
    print("fp32ref self-test vs numpy (add/mul, RNE):", "OK" if bad == 0 else f"{bad} mismatches")
    bad2 = _bracket_test()
    print("fp32ref rounding-bracket test (fma, all 5 modes):", "OK" if bad2 == 0 else f"{bad2} failures")
    raise SystemExit(0 if (bad == 0 and bad2 == 0) else 1)
