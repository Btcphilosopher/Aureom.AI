// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS : tb_adapter
//
// Unit test of sf_compute_memory_adapter + sf_compute_mem_engine on the REAL
// IronMemory (P84).  Random 2-D READ / WRITE / FILL jobs at arbitrary byte
// alignment, strides and pitches are checked against an independent byte-level
// shadow model of the local memory and of all four staging buffers (stray writes
// and any leakage of bytes outside the requested rows are caught).
//
// Parameters: NUM_CP (1|2), DW (64|128), NJOBS, SEED (plusarg +seed=N)
// =============================================================================
`timescale 1ns/1ps
`include "cw_tb_common.svh"

module tb_adapter;
  parameter int NUM_CP     = 2;
  parameter int DW         = 64;
  parameter int NJOBS      = 400;
  localparam int NB        = DW / 8;
  localparam int STG       = 256;
  localparam int SIW       = $clog2(STG) + 1;
  localparam int OWB       = 16;
  localparam int NP        = 2 + NUM_CP;
  localparam int BANKS     = 4;
  localparam int DEPTH     = 128;
  localparam int SRAM_BYTES = BANKS * DEPTH * NB;
  localparam logic [31:0] BASE = 32'h1000_0000;
  localparam logic [23:0] PDM  = (NUM_CP == 1) ? 24'o0000310 : 24'o0003310;
  localparam int IDW = 4;
  localparam int LEN_W = $clog2(SRAM_BYTES + 1);

  int tb_errors = 0, tb_checks = 0;
  int seed = 1;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- IronMemory
  logic [NP-1:0]      im_req_valid, im_req_ready;
  logic [NP*32-1:0]   im_req_addr;
  logic [NP*3-1:0]    im_req_size;
  logic [NP-1:0]      im_req_we;
  logic [NP*DW-1:0]   im_req_wdata;
  logic [NP*NB-1:0]   im_req_wstrb;
  logic [NP-1:0]      im_rsp_valid, im_rsp_ready;
  logic [NP*DW-1:0]   im_rsp_rdata;
  logic [NP*3-1:0]    im_rsp_err;
  logic               bm_cmd_valid, bm_cmd_ready, bm_rsp_valid;
  logic [2:0]         bm_cmd_op, bm_cmd_requester, bm_cmd_btype, bm_cmd_owner;
  logic [IDW-1:0]     bm_cmd_id;
  logic [31:0]        bm_cmd_start;
  logic [LEN_W-1:0]   bm_cmd_len;
  logic [4:0]         bm_cmd_rd_mask, bm_cmd_wr_mask;
  logic [3:0]         bm_rsp_status;
  logic               init_done;

  sf_iron_memory #(.NUM_PORTS(NP), .PORT_DOMAIN_MAP(PDM), .DW(DW), .NUM_BANKS(BANKS), .BANK_DEPTH(DEPTH),
                   .EXT_EN(0), .NUM_DESC(16)) u_im (
    .clk, .rst_n,
    .m_req_valid(im_req_valid), .m_req_ready(im_req_ready), .m_req_addr(im_req_addr), .m_req_size(im_req_size),
    .m_req_we(im_req_we), .m_req_wdata(im_req_wdata), .m_req_wstrb(im_req_wstrb),
    .m_rsp_valid(im_rsp_valid), .m_rsp_ready(im_rsp_ready), .m_rsp_rdata(im_rsp_rdata), .m_rsp_err(im_rsp_err),
    .m_rsp_ecc_corr(),
    .bm_cmd_valid, .bm_cmd_ready, .bm_cmd_op, .bm_cmd_requester, .bm_cmd_id, .bm_cmd_btype, .bm_cmd_start,
    .bm_cmd_len, .bm_cmd_owner, .bm_cmd_rd_mask, .bm_cmd_wr_mask,
    .bm_rsp_valid, .bm_rsp_status, .bm_rsp_id(), .bm_rsp_in_use(), .bm_rsp_btype(), .bm_rsp_start(), .bm_rsp_len(),
    .bm_rsp_owner(), .bm_rsp_rd_mask(), .bm_rsp_wr_mask(), .bm_rsp_err_bits(),
    .csr_valid(1'b0), .csr_we(1'b0), .csr_addr(12'd0), .csr_wdata(32'd0), .csr_rvalid(), .csr_rdata(), .csr_err(),
    .ext_cmd_valid(), .ext_cmd_ready(1'b1), .ext_cmd_we(), .ext_cmd_addr(), .ext_cmd_wdata(), .ext_cmd_wstrb(),
    .ext_cmd_tag(), .ext_rsp_valid(1'b0), .ext_rsp_ready(), .ext_rsp_rdata('0), .ext_rsp_err(1'b0), .ext_rsp_tag('0),
    .init_done, .irq(),
    .trc_valid(), .trc_port(), .trc_seq(), .trc_we(), .trc_word(), .trc_be(), .trc_wdata());

  // ---------------------------------------------------------------- adapter
  logic [NUM_CP-1:0]      job_valid, job_ready, job_done;
  logic [NUM_CP*2-1:0]    job_kind, job_stg;
  logic [NUM_CP*32-1:0]   job_base, job_rowbytes, job_stride;
  logic [NUM_CP*16-1:0]   job_rows, job_nerr;
  logic [NUM_CP*SIW-1:0]  job_stg_base, job_stg_pitch;
  logic [NUM_CP*3-1:0]    job_err;
  logic [STG*8-1:0]       stg0, stg1, stg2, stg3;
  logic                   o_wr_en, stg_clear;
  logic [SIW-1:0]         o_wr_idx;
  logic [OWB*8-1:0]       o_wr_data;
  logic [NUM_CP-1:0]      ev_rd, ev_wr, ev_stall, ev_err, eng_busy;

  logic [NUM_CP-1:0]      a_req_valid, a_req_ready, a_req_we, a_rsp_valid, a_rsp_ready;
  logic [NUM_CP*32-1:0]   a_req_addr;
  logic [NUM_CP*3-1:0]    a_req_size, a_rsp_err;
  logic [NUM_CP*DW-1:0]   a_req_wdata, a_rsp_rdata;
  logic [NUM_CP*NB-1:0]   a_req_wstrb;

  sf_compute_memory_adapter #(.NUM_CP(NUM_CP), .DW(DW), .STG_BYTES(STG), .OWB(OWB)) u_ad (
    .clk, .rst_n,
    .job_valid, .job_ready, .job_kind, .job_base, .job_rows, .job_rowbytes, .job_stride, .job_stg,
    .job_stg_base, .job_stg_pitch, .job_done, .job_err, .job_nerr,
    .m_req_valid(a_req_valid), .m_req_ready(a_req_ready), .m_req_addr(a_req_addr), .m_req_size(a_req_size),
    .m_req_we(a_req_we), .m_req_wdata(a_req_wdata), .m_req_wstrb(a_req_wstrb),
    .m_rsp_valid(a_rsp_valid), .m_rsp_ready(a_rsp_ready), .m_rsp_rdata(a_rsp_rdata), .m_rsp_err(a_rsp_err),
    .stg0_flat(stg0), .stg1_flat(stg1), .stg2_flat(stg2), .stg3_flat(stg3),
    .o_wr_en, .o_wr_idx, .o_wr_data, .stg_clear,
    .ev_rd, .ev_wr, .ev_stall, .ev_err, .eng_busy);

  // port wiring: 0 = Keystone (idle), 1 = Bridge (TB), 2.. = adapter engines
  logic        br_req_valid, br_we;
  logic [31:0] br_addr;
  logic [DW-1:0] br_wdata;
  logic [NB-1:0] br_wstrb;
  logic        br_rsp_valid;
  logic [DW-1:0] br_rdata;
  logic [2:0]  br_err;

  always_comb begin
    im_req_valid = '0; im_req_addr = '0; im_req_size = '0; im_req_we = '0; im_req_wdata = '0; im_req_wstrb = '0;
    im_rsp_ready = '1;
    im_req_valid[1]                 = br_req_valid;
    im_req_addr[32 +: 32]           = br_addr;
    im_req_size[3 +: 3]             = 3'($clog2(NB));
    im_req_we[1]                    = br_we;
    im_req_wdata[DW +: DW]          = br_wdata;
    im_req_wstrb[NB +: NB]          = br_wstrb;
    for (int e = 0; e < NUM_CP; e++) begin
      im_req_valid[2+e]                 = a_req_valid[e];
      im_req_addr[(2+e)*32 +: 32]       = a_req_addr[e*32 +: 32];
      im_req_size[(2+e)*3 +: 3]         = a_req_size[e*3 +: 3];
      im_req_we[2+e]                    = a_req_we[e];
      im_req_wdata[(2+e)*DW +: DW]      = a_req_wdata[e*DW +: DW];
      im_req_wstrb[(2+e)*NB +: NB]      = a_req_wstrb[e*NB +: NB];
    end
    a_req_ready = im_req_ready[2 +: NUM_CP];
    a_rsp_valid = im_rsp_valid[2 +: NUM_CP];
    a_rsp_rdata = im_rsp_rdata[2*DW +: NUM_CP*DW];
    a_rsp_err   = im_rsp_err[2*3 +: NUM_CP*3];
    br_rsp_valid = im_rsp_valid[1];
    br_rdata     = im_rsp_rdata[DW +: DW];
    br_err       = im_rsp_err[3 +: 3];
  end

  // ---------------------------------------------------------------- shadow models
  logic [7:0] mem   [SRAM_BYTES];
  logic [7:0] model [4][STG];

  function automatic int unsigned rnd(input int lo, input int hi);
    return $urandom_range(hi, lo);
  endfunction

  // ---------------------------------------------------------------- edge-sampled monitors
  // Race-free: monitors sample DUT outputs at the clock edge (pre-edge values) and ONLY
  // increment counters / capture data with non-blocking assignments.  The TB only READS
  // them (at negedge) and compares against snapshots it took itself, so no variable is ever
  // written from two processes.
  int              br_acc_cnt = 0, br_rsp_cnt = 0, bm_cnt = 0;
  logic [3:0]      bm_status_q;
  logic [DW-1:0]   br_rsp_data_q;
  logic [2:0]      br_rsp_err_q;
  int              job_acc_cnt [NUM_CP];
  int              done_cnt    [NUM_CP];
  logic [2:0]      err_q       [NUM_CP];
  int              done_snap   [NUM_CP];
  initial for (int e = 0; e < NUM_CP; e++) begin job_acc_cnt[e] = 0; done_cnt[e] = 0; err_q[e] = 0; done_snap[e] = 0; end
  always @(posedge clk) begin
    if (br_req_valid && im_req_ready[1]) br_acc_cnt <= br_acc_cnt + 1;
    if (im_rsp_valid[1]) begin
      br_rsp_cnt    <= br_rsp_cnt + 1;
      br_rsp_data_q <= br_rdata;
      br_rsp_err_q  <= br_err;
    end
    if (bm_rsp_valid) begin bm_cnt <= bm_cnt + 1; bm_status_q <= bm_rsp_status; end
    for (int e = 0; e < NUM_CP; e++) begin
      if (job_valid[e] && job_ready[e]) job_acc_cnt[e] <= job_acc_cnt[e] + 1;
      if (job_done[e]) begin done_cnt[e] <= done_cnt[e] + 1; err_q[e] <= job_err[e*3 +: 3]; end
    end
  end

  // ---------------------------------------------------------------- bridge helpers
  task automatic br_word(input logic [31:0] addr, input logic we, input logic [DW-1:0] wd, input logic [NB-1:0] ws,
                         output logic [DW-1:0] rd, output logic [2:0] err);
    int acc0, rsp0;
    @(negedge clk);
    acc0 = br_acc_cnt; rsp0 = br_rsp_cnt;
    br_req_valid = 1; br_addr = addr; br_we = we; br_wdata = wd; br_wstrb = ws;
    do @(negedge clk); while (br_acc_cnt == acc0);
    br_req_valid = 0;
    while (br_rsp_cnt == rsp0) @(negedge clk);
    rd = br_rsp_data_q; err = br_rsp_err_q;
  endtask

  task automatic br_write_bytes(input int off, input int n);   // write mem[off..off+n) (already in model)
    logic [DW-1:0] rd; logic [2:0] er; logic [DW-1:0] wd; logic [NB-1:0] ws;
    int wa0, wa1;
    wa0 = (off / NB) * NB; wa1 = ((off + n - 1) / NB) * NB;
    for (int wa = wa0; wa <= wa1; wa += NB) begin
      wd = '0; ws = '0;
      for (int l = 0; l < NB; l++) if ((wa + l) >= off && (wa + l) < off + n) begin
        wd[l*8 +: 8] = mem[wa + l]; ws[l] = 1'b1;
      end
      br_word(BASE + 32'(wa), 1'b1, wd, ws, rd, er);
      `CHECK_EQ(er, 3'd0, "bridge write response")
    end
  endtask

  task automatic br_check_all();
    logic [DW-1:0] rd; logic [2:0] er;
    for (int wa = 0; wa < SRAM_BYTES; wa += NB) begin
      br_word(BASE + 32'(wa), 1'b0, '0, '0, rd, er);
      `CHECK_EQ(er, 3'd0, "bridge read response")
      for (int l = 0; l < NB; l++)
        if (rd[l*8 +: 8] !== mem[wa + l]) begin
          tb_checks++; tb_errors++;
          if (tb_errors <= 40) $display("[FAIL] mem[%0d] got=%02h exp=%02h", wa + l, rd[l*8 +: 8], mem[wa + l]);
        end else tb_checks++;
    end
  endtask

  // ---------------------------------------------------------------- staging model compare
  task automatic check_stg(input string what);
    logic [STG*8-1:0] f [4];
    f[0] = stg0; f[1] = stg1; f[2] = stg2; f[3] = stg3;
    for (int s = 0; s < 4; s++)
      for (int i = 0; i < STG; i++) begin
        tb_checks++;
        if (f[s][i*8 +: 8] !== model[s][i]) begin
          tb_errors++;
          if (tb_errors <= 40) $display("[FAIL] %s: stg%0d[%0d] got=%02h exp=%02h", what, s, i, f[s][i*8 +: 8], model[s][i]);
        end
      end
  endtask

  task automatic out_fill_random();
    for (int i = 0; i < STG; i += OWB) begin
      @(negedge clk);
      o_wr_en = 1; o_wr_idx = SIW'(i);
      for (int b = 0; b < OWB; b++) begin
        logic [7:0] v; v = 8'($urandom);
        o_wr_data[b*8 +: 8] = v;
        model[3][i + b] = v;
      end
    end
    @(negedge clk); o_wr_en = 0;
    @(posedge clk);
  endtask

  // ---------------------------------------------------------------- job issue
  typedef struct packed {
    logic [31:0] kind, base_off, rows, rowbytes, stride, stg, stg_base, pitch;
  } job_t;

  task automatic issue(input int e, input job_t j);
    int acc0;
    @(negedge clk);
    acc0 = job_acc_cnt[e];
    done_snap[e] = done_cnt[e];
    job_valid[e]                  = 1'b1;
    job_kind[e*2 +: 2]            = 2'(j.kind);
    job_base[e*32 +: 32]          = BASE + 32'(j.base_off);
    job_rows[e*16 +: 16]          = 16'(j.rows);
    job_rowbytes[e*32 +: 32]      = 32'(j.rowbytes);
    job_stride[e*32 +: 32]        = 32'(j.stride);
    job_stg[e*2 +: 2]             = 2'(j.stg);
    job_stg_base[e*SIW +: SIW]    = SIW'(j.stg_base);
    job_stg_pitch[e*SIW +: SIW]   = SIW'(j.pitch);
    do @(negedge clk); while (job_acc_cnt[e] == acc0);
    job_valid[e] = 1'b0;
  endtask

  task automatic wait_done(input int e, output logic [2:0] err);
    while (done_cnt[e] == done_snap[e]) @(negedge clk);
    err = err_q[e];
  endtask

  // apply the job to the shadow model
  task automatic model_apply(input job_t j);
    for (int r = 0; r < int'(j.rows); r++)
      for (int c = 0; c < int'(j.rowbytes); c++) begin
        int moff, sidx;
        moff = j.base_off + r * j.stride + c;
        sidx = j.stg_base + r * j.pitch + c;
        case (j.kind)
          0: model[j.stg][sidx] = mem[moff];
          1: mem[moff] = model[3][sidx];
          2: mem[moff] = 8'h00;
          default: ;
        endcase
      end
  endtask

  // random legal job; returns structure
  function automatic job_t rand_job(input int kind, input int stgsel, input int win_lo, input int win_hi);
    job_t j;
    int maxrb, span;
    j.kind = kind; j.stg = stgsel;
    j.rows = (kind == 2) ? 1 : rnd(1, 6);
    j.rowbytes = (kind == 2) ? rnd(1, 200) : rnd(1, 40);
    j.stride   = (kind == 2) ? 0 : rnd(0, 70);                 // 0 and small strides overlap rows (legal for READ)
    if (kind == 1) j.stride = rnd(j.rowbytes, j.rowbytes + 40);  // writes: rows must not overlap (else order-dependent)
    j.pitch    = rnd(j.rowbytes, j.rowbytes + 9);
    span = (j.rows - 1) * j.stride + j.rowbytes;
    if (span > win_hi - win_lo) begin j.rows = 1; span = j.rowbytes; end
    j.base_off = rnd(win_lo, win_hi - span);
    // staging placement
    j.stg_base = rnd(0, 7);
    while (j.stg_base + (j.rows - 1) * j.pitch + j.rowbytes > STG) begin
      if (j.rows > 1) j.rows--; else j.rowbytes--;
      span = (j.rows - 1) * j.stride + j.rowbytes;
    end
    return j;
  endfunction

  // ---------------------------------------------------------------- main
  logic [2:0] er0, er1;
  int bm0;
  job_t jA, jB;
  initial begin
    $display("tb_adapter: start NUM_CP=%0d DW=%0d", NUM_CP, DW);
    if ($value$plusargs("seed=%d", seed)) ;
    void'($urandom(seed));
    job_valid = '0; job_kind = '0; job_base = '0; job_rows = '0; job_rowbytes = '0; job_stride = '0; job_stg = '0;
    job_stg_base = '0; job_stg_pitch = '0; o_wr_en = 0; o_wr_idx = '0; o_wr_data = '0; stg_clear = 0;
    br_req_valid = 0; br_we = 0; br_addr = '0; br_wdata = '0; br_wstrb = '0;
    bm_cmd_valid = 0; bm_cmd_op = 0; bm_cmd_requester = 0; bm_cmd_id = 0; bm_cmd_btype = 0; bm_cmd_start = 0;
    bm_cmd_len = 0; bm_cmd_owner = 0; bm_cmd_rd_mask = 0; bm_cmd_wr_mask = 0;
    for (int s = 0; s < 4; s++) for (int i = 0; i < STG; i++) model[s][i] = 8'h00;
    repeat (5) @(posedge clk);
    rst_n = 1;
    $display("[%0t] reset released", $time);
    while (!init_done) @(posedge clk);
    $display("[%0t] init_done", $time);
    repeat (3) @(posedge clk);

    // one buffer over the whole window: owner BRIDGE, readable + writable by Keystone / Bridge / Compute
    @(negedge clk);
    bm0 = bm_cnt;
    while (!bm_cmd_ready) @(negedge clk);
    bm_cmd_valid = 1; bm_cmd_op = 3'd1 /*ALLOC_AT*/; bm_cmd_requester = 3'd0; bm_cmd_btype = 3'd3;
    bm_cmd_start = BASE; bm_cmd_len = LEN_W'(SRAM_BYTES); bm_cmd_owner = 3'd1; bm_cmd_rd_mask = 5'b01011; bm_cmd_wr_mask = 5'b01011;
    @(negedge clk); bm_cmd_valid = 0;
    while (bm_cnt == bm0) @(negedge clk);
    `CHECK_EQ(bm_status_q, 4'd0, "ALLOC_AT whole window")
    $display("[%0t] alloc status %0d", $time, bm_status_q);
    @(negedge clk);

    // random initial memory image through the Bridge port
    for (int i = 0; i < SRAM_BYTES; i++) mem[i] = 8'($urandom);
    br_write_bytes(0, SRAM_BYTES);
    $display("[%0t] image written", $time);
    br_check_all();
    $display("[%0t] image verified", $time);

    for (int t = 0; t < NJOBS; t++) begin
      int mode;
      mode = rnd(0, (NUM_CP == 2) ? 5 : 3);
      if ((t % 50) == 0) $display("[%0t] job %0d mode %0d", $time, t, mode);
      case (mode)
        0, 1: begin   // single READ2D
          jA = rand_job(0, rnd(0, 2), 0, SRAM_BYTES);
          issue(0, jA); wait_done(0, er0);
          `CHECK_EQ(er0, 3'd0, "read job error")
          model_apply(jA);
        end
        2: begin      // WRITE2D from OUT buffer
          out_fill_random();
          jA = rand_job(1, 3, 0, SRAM_BYTES);
          issue(0, jA); wait_done(0, er0);
          `CHECK_EQ(er0, 3'd0, "write job error")
          model_apply(jA);
          br_check_all();
        end
        3: begin      // FILL0
          jA = rand_job(2, 0, 0, SRAM_BYTES);
          issue(0, jA); wait_done(0, er0);
          `CHECK_EQ(er0, 3'd0, "fill job error")
          model_apply(jA);
          br_check_all();
        end
        4, 5: begin   // two concurrent READ2D (different staging buffers) on both engines
          jA = rand_job(0, 0, 0, SRAM_BYTES);
          jB = rand_job(0, 1, 0, SRAM_BYTES);
          issue(0, jA);
          issue(1, jB);
          wait_done(0, er0);
          wait_done(1, er1);
          `CHECK_EQ(er0, 3'd0, "concurrent read A error")
          `CHECK_EQ(er1, 3'd0, "concurrent read B error")
          model_apply(jA); model_apply(jB);
        end
        default: ;
      endcase
      check_stg($sformatf("after job %0d mode %0d", t, mode));
      if ((t % 64) == 63) begin   // staging clear
        @(negedge clk); stg_clear = 1; @(negedge clk); stg_clear = 0;
        for (int s = 0; s < 4; s++) for (int i = 0; i < STG; i++) model[s][i] = 8'h00;
        @(posedge clk);
        check_stg("after stg_clear");
      end
    end

    // error paths: outside the window (DECODE = 1), and a degenerate job completes without traffic
    jA.kind = 0; jA.base_off = SRAM_BYTES + 64; jA.rows = 1; jA.rowbytes = 8; jA.stride = 0; jA.stg = 0; jA.stg_base = 0; jA.pitch = 8;
    issue(0, jA); wait_done(0, er0);
    `CHECK_EQ(er0, 3'd1, "read outside the window must report RSP_DECODE")
    check_stg("after failed read (no staging write)");
    jA.rows = 0;
    issue(0, jA); wait_done(0, er0);
    `CHECK_EQ(er0, 3'd0, "degenerate job")

    br_check_all();
    `TB_FINISH("tb_adapter")
  end

  // watchdog
  initial begin
    #20000000;
    $display("TB_RESULT tb_adapter FAIL timeout");
    $finish;
  end
endmodule
