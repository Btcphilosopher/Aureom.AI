// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS : shared testbench helpers
// Every testbench declares:  int tb_errors = 0; int tb_checks = 0;
// =============================================================================
`ifndef CW_TB_COMMON_SVH
`define CW_TB_COMMON_SVH

`define CHECK(cond, msg) \
  begin \
    tb_checks = tb_checks + 1; \
    if (!(cond)) begin \
      tb_errors = tb_errors + 1; \
      if (tb_errors <= 40) $display("[FAIL] %0t %s:%0d : %s", $time, `__FILE__, `__LINE__, msg); \
    end \
  end

`define CHECK_EQ(got, exp, msg) \
  begin \
    tb_checks = tb_checks + 1; \
    if ((got) !== (exp)) begin \
      tb_errors = tb_errors + 1; \
      if (tb_errors <= 40) $display("[FAIL] %0t %s:%0d : %s got=%0h exp=%0h", $time, `__FILE__, `__LINE__, msg, (got), (exp)); \
    end \
  end

// Final banner parsed by scripts/run_tests.py
`define TB_FINISH(name) \
  begin \
    if (tb_errors == 0) $display("TB_RESULT %s PASS checks=%0d", name, tb_checks); \
    else                $display("TB_RESULT %s FAIL errors=%0d checks=%0d", name, tb_errors, tb_checks); \
    $finish; \
  end

`endif
