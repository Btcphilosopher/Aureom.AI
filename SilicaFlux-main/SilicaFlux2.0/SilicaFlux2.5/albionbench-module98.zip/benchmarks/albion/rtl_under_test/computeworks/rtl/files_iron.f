// IronMemory (P84) -- reused unmodified (third_party/p84-ironmemory), compile order from its own list
+incdir+third_party/p84-ironmemory
third_party/p84-ironmemory/sf_iron_pkg.sv
third_party/p84-ironmemory/sf_iron_secded.sv
third_party/p84-ironmemory/sf_iron_sram_generic.sv
third_party/p84-ironmemory/sf_iron_sram_fpga.sv
third_party/p84-ironmemory/sf_iron_sram_asic.sv
third_party/p84-ironmemory/sf_iron_bank_adapter.sv
third_party/p84-ironmemory/sf_iron_bank_arbiter.sv
third_party/p84-ironmemory/sf_iron_rob.sv
third_party/p84-ironmemory/sf_iron_memory_map.sv
third_party/p84-ironmemory/sf_iron_buffer_manager.sv
third_party/p84-ironmemory/sf_iron_extmem_adapter.sv
third_party/p84-ironmemory/sf_iron_memory.sv
