// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS :: sf_compute_guard
// Aureom.AI / SilicaFlux Albion
//
// Isolation layer: the CITADEL CLIENT of ComputeWorks, plus a REFERENCE Citadel.
//
//   *** The repository contains no block named Citadel (see Meridian P83 docs/00_AUDIT).
//   *** The Citadel role is mapped to the permission-check role of CloudDMA (P64).
//   *** This module defines the check interface the tile enforces and gives it a
//   *** deterministic, testable reference policy.  It is NOT the Citadel.
//
// Three things live here:
//
//  1. MANAGEMENT-PLANE POLICY (pol_* port, Keystone only, accepted only while the tile is
//     quiescent so a command never sees the policy change under it):
//       SET_REGION  assign a tenant region {base, size, domain, rd, wr}
//       REVOKE      withdraw a region; it becomes DIRTY (its bytes may hold tenant data)
//       SCRUB       zero-fill a revoked region through the clear engine; it becomes CLEAN
//       BIND_QUEUE  bind a queue to a domain, priority class, default destination, RR
//                   quantum, work budget and enable
//       SET_DESTMASK allowed completion destinations of a domain
//     SCRATCHPAD CLEARING / REASSIGNMENT PROCEDURE, enforced in hardware:
//       a region can only be (re)assigned after REVOKE -> SCRUB.  SET_REGION on an entry
//       that is DIRTY, or over any DIRTY/LIVE range, is refused (CW_PS_NOT_CLEAN /
//       CW_PS_OVERLAP).  After reset every entry is clean (IronMemory's init sweep zeroes
//       the SRAM).  Regions are mutually disjoint, so an address belongs to at most one domain.
//
//  2. RANGE CHECK (chk_* port, used by the scheduler per command operand).  A byte range
//     [base, base+len) is permitted iff it lies entirely INSIDE ONE live region whose
//     domain equals the queue-bound domain and that grants the needed right.  Fault codes
//     are Meridian's: NOMAP (no region contains the range), DOMAIN, PERM.  A range that
//     spans two regions is NOMAP: only single-region ranges are supported.
//
//  3. MODE: 0 = OFF (bring-up only: every range permitted -- NO ISOLATION),
//           1 = REF (the table above),
//           2 = EXT (every query is forwarded to an external Citadel over cit_*, answered
//                    within CIT_TMO cycles or denied: fail closed).  Region policy ops are
//                    then CW_PS_UNSUPPORTED (the Citadel owns the policy).
//
// Unprotected by design: the BridgeEngine (DMA) port of the local memory is not gated by
// this table (see docs/compute_works/08_LIMITATIONS.md).
// =============================================================================
`timescale 1ns/1ps
`include "sf_compute_defs.svh"
`default_nettype none

module sf_compute_guard #(
  parameter int          NQ          = 1,
  parameter int          NREG        = 8,
  parameter int          MODE        = 1,
  parameter logic [31:0] SRAM_BASE   = 32'h1000_0000,
  parameter longint      SRAM_BYTES  = 32768,
  parameter int          REGION_LOG2 = 8,
  parameter int          CIT_TMO     = 16
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // ---------------------------------------------------------------- policy port (management plane)
  input  wire logic                 pol_valid,
  output logic                      pol_ready,
  input  wire logic [3:0]           pol_op,
  input  wire logic [3:0]           pol_idx,
  input  wire logic [31:0]          pol_a, pol_b, pol_c,
  output logic                      pol_done,          // 1-cycle pulse
  output logic [3:0]                pol_status,
  input  wire logic                 quiescent_i,       // no command between dispatch and completion
  output logic                      pol_busy,          // a policy op is executing: scheduler must not dispatch
  output logic                      pol_acc,           // a policy op is accepted THIS cycle: scheduler must not start one now
  // ---------------------------------------------------------------- scrub through the clear engine
  output logic                      scrub_start,
  output logic [31:0]               scrub_base,
  output logic [31:0]               scrub_len,
  input  wire logic                 scrub_done,
  input  wire logic [2:0]           scrub_err,
  // ---------------------------------------------------------------- queue configuration
  output logic      [NQ-1:0]        q_bound,
  output logic      [NQ-1:0]        q_en,
  output logic      [NQ*3-1:0]      q_dom,
  output logic      [NQ*`CW_PRIO_W-1:0] q_prio,
  output logic      [NQ*4-1:0]      q_dest,
  output logic      [NQ*4-1:0]      q_quantum,
  output logic      [NQ*32-1:0]     q_budget,
  output logic      [8*16-1:0]      dest_mask_flat,
  // ---------------------------------------------------------------- range check
  input  wire logic                 chk_valid,
  output logic                      chk_ready,
  input  wire logic [2:0]           chk_dom,
  input  wire logic                 chk_write,
  input  wire logic [31:0]          chk_base,
  input  wire logic [39:0]          chk_len,
  output logic                      chk_rsp_valid,
  output logic                      chk_rsp_ok,
  output logic [3:0]                chk_rsp_fault,
  // ---------------------------------------------------------------- external Citadel (MODE = 2)
  output logic                      cit_req_valid,
  input  wire logic                 cit_req_ready,
  output logic [2:0]                cit_req_dom,
  output logic                      cit_req_write,
  output logic [31:0]               cit_req_base,
  output logic [39:0]               cit_req_len,
  input  wire logic                 cit_rsp_valid,
  input  wire logic                 cit_rsp_ok,
  input  wire logic [3:0]           cit_rsp_fault,
  // ---------------------------------------------------------------- observability
  output logic [NREG-1:0]           reg_valid_o,
  output logic [NREG-1:0]           reg_dirty_o
);
  localparam int GRAN   = 1 << REGION_LOG2;
  localparam int RIW    = (NREG > 1) ? $clog2(NREG) : 1;
  localparam int QIW    = (NQ > 1) ? $clog2(NQ) : 1;
  localparam logic [32:0] SR_LO = {1'b0, SRAM_BASE};
  localparam logic [32:0] SR_HI = {1'b0, SRAM_BASE} + 33'(SRAM_BYTES);

  // ---------------------------------------------------------------------------
  // state
  // ---------------------------------------------------------------------------
  logic [NREG-1:0] r_valid, r_dirty, r_rd, r_wr;
  logic [2:0]      r_dom  [NREG];
  logic [31:0]     r_base [NREG];
  logic [31:0]     r_size [NREG];

  logic [NQ-1:0]   qb_q, qe_q;
  logic [2:0]      qdom_q    [NQ];
  logic [`CW_PRIO_W-1:0] qprio_q [NQ];
  logic [3:0]      qdest_q   [NQ];
  logic [3:0]      qquant_q  [NQ];
  logic [31:0]     qbud_q    [NQ];
  logic [15:0]     dmask_q   [8];

  always_comb begin
    for (int q = 0; q < NQ; q++) begin
      q_dom[q*3 +: 3]                       = qdom_q[q];
      q_prio[q*`CW_PRIO_W +: `CW_PRIO_W]    = qprio_q[q];
      q_dest[q*4 +: 4]                      = qdest_q[q];
      q_quantum[q*4 +: 4]                   = qquant_q[q];
      q_budget[q*32 +: 32]                  = qbud_q[q];
    end
    for (int d = 0; d < 8; d++) dest_mask_flat[d*16 +: 16] = dmask_q[d];
  end
  assign q_bound     = qb_q;
  assign q_en        = qe_q;
  assign reg_valid_o = r_valid;
  assign reg_dirty_o = r_dirty;

  // ---------------------------------------------------------------------------
  // policy FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {P_IDLE = 2'd0, P_SCRUB = 2'd1} p_e;
  p_e          p_q;
  logic [RIW-1:0] p_idx_q;

  wire [RIW-1:0] ridx = pol_idx[RIW-1:0];
  wire [QIW-1:0] qidx = pol_idx[QIW-1:0];
  wire [2:0]     didx = pol_idx[2:0];
  assign pol_ready = quiescent_i && (p_q == P_IDLE) && !pol_done;
  assign pol_busy  = (p_q != P_IDLE);
  assign pol_acc   = pol_valid && pol_ready;

  // SET_REGION validation (combinational on the offered op)
  logic [32:0] new_lo, new_hi;
  logic        ov_live, ov_dirty, al_ok, rng_ok;
  always_comb begin
    new_lo = {1'b0, pol_a};
    new_hi = {1'b0, pol_a} + {1'b0, pol_b};
    al_ok  = ((pol_a & 32'(GRAN - 1)) == 32'd0) && (pol_b != 32'd0) && ((pol_b & 32'(GRAN - 1)) == 32'd0);
    rng_ok = (new_lo >= SR_LO) && (new_hi <= SR_HI) && (new_hi > new_lo);
    ov_live = 1'b0; ov_dirty = 1'b0;
    for (int e = 0; e < NREG; e++) begin
      logic [32:0] elo, ehi;
      elo = {1'b0, r_base[e]};
      ehi = {1'b0, r_base[e]} + {1'b0, r_size[e]};
      if ((new_lo < ehi) && (elo < new_hi)) begin
        if (r_valid[e]) ov_live  = 1'b1;
        if (r_dirty[e]) ov_dirty = 1'b1;
      end
    end
  end

  // scrub request: a registered one-cycle pulse plus the revoked region's extent
  logic        scrub_start_q;
  logic [31:0] scrub_base_q, scrub_len_q;
  assign scrub_start = scrub_start_q;
  assign scrub_base  = scrub_base_q;
  assign scrub_len   = scrub_len_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      p_q <= P_IDLE; p_idx_q <= '0;
      pol_done <= 1'b0; pol_status <= `CW_PS_OK;
      scrub_start_q <= 1'b0; scrub_base_q <= '0; scrub_len_q <= '0;
      r_valid <= '0; r_dirty <= '0; r_rd <= '0; r_wr <= '0;
      for (int e = 0; e < NREG; e++) begin r_dom[e] <= '0; r_base[e] <= '0; r_size[e] <= '0; end
      qb_q <= '0; qe_q <= '1;
      for (int q = 0; q < NQ; q++) begin
        qdom_q[q] <= '0; qprio_q[q] <= '0; qdest_q[q] <= '0; qquant_q[q] <= 4'd1; qbud_q[q] <= '0;
      end
      for (int d = 0; d < 8; d++) dmask_q[d] <= 16'h0001;
    end else begin
      pol_done      <= 1'b0;
      scrub_start_q <= 1'b0;

      case (p_q)
        P_IDLE: if (pol_valid && pol_ready) begin
          pol_done   <= 1'b1;
          pol_status <= `CW_PS_OK;
          case (pol_op)
            `CW_POL_NOP: ;

            `CW_POL_SET_REGION: begin
              if (MODE == 2)                                    pol_status <= `CW_PS_UNSUPPORTED;
              else if (int'(pol_idx) >= NREG)                   pol_status <= `CW_PS_BADIDX;
              else if (!al_ok)                                  pol_status <= `CW_PS_ALIGN;
              else if (!rng_ok)                                 pol_status <= `CW_PS_RANGE;
              else if (r_valid[ridx])                        pol_status <= `CW_PS_IN_USE;
              else if (r_dirty[ridx])                        pol_status <= `CW_PS_NOT_CLEAN;
              else if (ov_live)                                 pol_status <= `CW_PS_OVERLAP;
              else if (ov_dirty)                                pol_status <= `CW_PS_NOT_CLEAN;
              else begin
                r_valid[ridx] <= 1'b1;
                r_base[ridx]  <= pol_a;
                r_size[ridx]  <= pol_b;
                r_dom[ridx]   <= pol_c[2:0];
                r_rd[ridx]    <= pol_c[8];
                r_wr[ridx]    <= pol_c[9];
              end
            end

            `CW_POL_REVOKE: begin
              if (MODE == 2)                                    pol_status <= `CW_PS_UNSUPPORTED;
              else if (int'(pol_idx) >= NREG)                   pol_status <= `CW_PS_BADIDX;
              else if (!r_valid[ridx])                       pol_status <= `CW_PS_NOT_LIVE;
              else begin
                r_valid[ridx] <= 1'b0;
                r_dirty[ridx] <= 1'b1;
              end
            end

            `CW_POL_SCRUB: begin
              if (MODE == 2)                                    pol_status <= `CW_PS_UNSUPPORTED;
              else if (int'(pol_idx) >= NREG)                   pol_status <= `CW_PS_BADIDX;
              else if (r_valid[ridx])                        pol_status <= `CW_PS_IN_USE;
              else if (r_dirty[ridx]) begin
                // long operation: hold off the response until the zero-fill finishes
                pol_done      <= 1'b0;
                scrub_start_q <= 1'b1;
                scrub_base_q  <= r_base[ridx];
                scrub_len_q   <= r_size[ridx];
                p_idx_q       <= ridx;
                p_q           <= P_SCRUB;
              end
            end

            `CW_POL_BIND_QUEUE: begin
              if (int'(pol_idx) >= NQ)                          pol_status <= `CW_PS_BADIDX;
              else begin
                qb_q[qidx]    <= 1'b1;
                qdom_q[qidx]  <= pol_a[2:0];
                qprio_q[qidx] <= pol_a[5:4];
                qdest_q[qidx] <= pol_a[11:8];
                qe_q[qidx]    <= pol_a[12];
                qquant_q[qidx] <= (pol_a[19:16] == 4'd0) ? 4'd1 : pol_a[19:16];
                qbud_q[qidx]  <= pol_b;
              end
            end

            `CW_POL_SET_DESTMASK: begin
              if (int'(pol_idx) >= 8)                           pol_status <= `CW_PS_BADIDX;
              else                                              dmask_q[didx] <= pol_a[15:0] | 16'h0001;   // destination 0 is always allowed
            end

            default: pol_status <= `CW_PS_BADARG;
          endcase
        end

        P_SCRUB: if (scrub_done) begin
          pol_done <= 1'b1;
          p_q      <= P_IDLE;
          if (scrub_err != 3'd0) begin
            pol_status <= `CW_PS_MEM_ERR;                    // stays DIRTY
          end else begin
            pol_status <= `CW_PS_OK;
            r_dirty[p_idx_q] <= 1'b0;
          end
        end
        default: p_q <= P_IDLE;
      endcase
    end
  end

  // ---------------------------------------------------------------------------
  // range check
  // ---------------------------------------------------------------------------
  logic        ref_ok;
  logic [3:0]  ref_fault;
  always_comb begin
    logic any_contains, any_dom, any_ok;
    any_contains = 1'b0; any_dom = 1'b0; any_ok = 1'b0;
    for (int e = 0; e < NREG; e++) begin
      logic [39:0] elo, ehi, qlo, qhi;
      logic        contains;
      elo = {8'd0, r_base[e]};
      ehi = {8'd0, r_base[e]} + {8'd0, r_size[e]};
      qlo = {8'd0, chk_base};
      qhi = {8'd0, chk_base} + chk_len;
      contains = r_valid[e] && (qlo >= elo) && (qhi <= ehi) && (chk_len != 40'd0);
      if (contains) begin
        any_contains = 1'b1;
        if (r_dom[e] == chk_dom) begin
          any_dom = 1'b1;
          if (chk_write ? r_wr[e] : r_rd[e]) any_ok = 1'b1;
        end
      end
    end
    ref_ok = any_ok;
    if (any_ok)             ref_fault = `CW_GF_NONE;
    else if (!any_contains) ref_fault = `CW_GF_NOMAP;
    else if (!any_dom)      ref_fault = `CW_GF_DOMAIN;
    else                    ref_fault = `CW_GF_PERM;
  end

  generate
    if (MODE == 2) begin : g_ext
      // forward the query, wait for the Citadel, fail closed after CIT_TMO cycles
      typedef enum logic [1:0] {C_IDLE, C_REQ, C_WAIT} c_e;
      c_e          c_q;
      logic [2:0]  dom_q;
      logic        wr_q;
      logic [31:0] base_q;
      logic [39:0] len_q;
      logic [$clog2(CIT_TMO+2)-1:0] tmo_q;
      assign chk_ready     = (c_q == C_IDLE);
      assign cit_req_valid = (c_q == C_REQ);
      assign cit_req_dom   = dom_q;
      assign cit_req_write = wr_q;
      assign cit_req_base  = base_q;
      assign cit_req_len   = len_q;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          c_q <= C_IDLE; dom_q <= '0; wr_q <= 1'b0; base_q <= '0; len_q <= '0; tmo_q <= '0;
          chk_rsp_valid <= 1'b0; chk_rsp_ok <= 1'b0; chk_rsp_fault <= '0;
        end else begin
          chk_rsp_valid <= 1'b0;
          case (c_q)
            C_IDLE: if (chk_valid) begin
              dom_q <= chk_dom; wr_q <= chk_write; base_q <= chk_base; len_q <= chk_len;
              tmo_q <= '0; c_q <= C_REQ;
            end
            C_REQ: begin
              if (cit_req_ready) c_q <= C_WAIT;
              tmo_q <= tmo_q + 1'b1;
              if (!cit_req_ready && int'(tmo_q) >= CIT_TMO) begin
                chk_rsp_valid <= 1'b1; chk_rsp_ok <= 1'b0; chk_rsp_fault <= `CW_GF_CITTMO; c_q <= C_IDLE;
              end
            end
            C_WAIT: begin
              tmo_q <= tmo_q + 1'b1;
              if (cit_rsp_valid) begin
                chk_rsp_valid <= 1'b1; chk_rsp_ok <= cit_rsp_ok;
                chk_rsp_fault <= cit_rsp_ok ? `CW_GF_NONE : ((cit_rsp_fault == 4'd0) ? `CW_GF_PERM : cit_rsp_fault);
                c_q <= C_IDLE;
              end else if (int'(tmo_q) >= CIT_TMO) begin
                chk_rsp_valid <= 1'b1; chk_rsp_ok <= 1'b0; chk_rsp_fault <= `CW_GF_CITTMO; c_q <= C_IDLE;
              end
            end
            default: c_q <= C_IDLE;
          endcase
        end
      end
    end else begin : g_int
      assign chk_ready     = 1'b1;
      assign cit_req_valid = 1'b0;
      assign cit_req_dom   = '0;
      assign cit_req_write = 1'b0;
      assign cit_req_base  = '0;
      assign cit_req_len   = '0;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          chk_rsp_valid <= 1'b0; chk_rsp_ok <= 1'b0; chk_rsp_fault <= '0;
        end else begin
          chk_rsp_valid <= chk_valid;
          if (MODE == 0) begin chk_rsp_ok <= 1'b1; chk_rsp_fault <= `CW_GF_NONE; end
          else           begin chk_rsp_ok <= ref_ok; chk_rsp_fault <= ref_fault; end
        end
      end
    end
  endgenerate
endmodule
`default_nettype wire
