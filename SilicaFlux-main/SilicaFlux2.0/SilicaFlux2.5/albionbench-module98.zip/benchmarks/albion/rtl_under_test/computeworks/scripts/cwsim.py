#!/usr/bin/env python3
"""Build (cached) and run the ComputeWorks testbenches with Verilator 5.x.

build(top, params, vector)  -> path of the simulator binary
run(sim, args, timeout)     -> dict(result, checks, errors, out, perf, cplrecs, csr)
"""
import hashlib
import os
import pathlib
import re
import subprocess
import time

ROOT = pathlib.Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"

VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-O2", "-j", "4"]


def _read_flist(path, seen=None):
    seen = seen if seen is not None else set()
    out = []
    for line in (ROOT / path).read_text().splitlines():
        line = line.split("//")[0].strip()
        if not line:
            continue
        if line.startswith("-f "):
            out += _read_flist(line[3:].strip(), seen)
        elif line.startswith("+incdir+"):
            out.append("-I" + str(ROOT / line[len("+incdir+"):]))
        else:
            out.append(str(ROOT / line))
    return out


def rtl_files(vector):
    f = []
    f.append("-I" + str(ROOT / "rtl/albion"))
    f.append("-I" + str(ROOT / "tests/compute_works"))
    f += _read_flist("rtl/files_iron.f")
    f += _read_flist("rtl/files_tensor.f")
    if vector:
        f += _read_flist("rtl/files_vector.f")
    for m in ["sf_compute_mem_engine", "sf_compute_memory_adapter", "sf_compute_decoder", "sf_compute_command_queue",
              "sf_compute_guard", "sf_compute_clear_exec", "sf_compute_tensor_exec"] + \
             (["sf_compute_vector_exec"] if vector else []) + \
             ["sf_compute_scheduler", "sf_compute_perf", "sf_compute_tile"]:
        f.append(str(ROOT / "rtl/albion" / (m + ".sv")))
    return f


def _src_hash(files, params, top):
    h = hashlib.sha256()
    for fp in files:
        if fp.startswith("-I"):
            continue
        h.update(pathlib.Path(fp).read_bytes())
    h.update(repr(sorted(params.items())).encode())
    h.update(top.encode())
    h.update((ROOT / "rtl/albion/sf_compute_defs.svh").read_bytes())
    return h.hexdigest()[:16]


def build(top="tb_compute_tile", params=None, vector=True, extra=None, tag=None, quiet=True):
    params = dict(params or {})
    files = rtl_files(vector) + [str(ROOT / "tests/compute_works" / (top + ".sv"))] + (extra or [])
    if top != "tb_compute_tile" and not tag:
        pass
    key = _src_hash(files, params, top)
    d = BUILD / f"obj_{top}_{key}"
    sim = d / "sim"
    if sim.exists():
        return str(sim)
    d.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["verilator"] + VFLAGS + ["--top-module", top, "-Mdir", str(d), "-o", "sim"]
    for k, v in params.items():
        cmd.append(f"-G{k}={int(v)}")
    cmd += files
    t0 = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)
    if r.returncode != 0 or not sim.exists():
        # an intermittent g++ failure (typically memory pressure on the largest configurations): retry serially once
        import shutil
        shutil.rmtree(d, ignore_errors=True)
        cmd2 = [c for c in cmd]
        i = cmd2.index("-j")
        cmd2[i + 1] = "1"
        r = subprocess.run(cmd2, capture_output=True, text=True, cwd=ROOT)
        if r.returncode != 0 or not sim.exists():
            raise RuntimeError("verilator build failed:\n" + "\n".join((r.stdout + r.stderr).splitlines()[-40:]))
    # the simulator binary is self-contained: drop the intermediate objects (the disk allowance is fixed)
    import shutil
    for entry in d.iterdir():
        if entry.name != "sim":
            shutil.rmtree(entry) if entry.is_dir() else entry.unlink()
    if not quiet:
        print(f"  built {d.name} in {time.time() - t0:.0f}s")
    return str(sim)


def run(sim, args=(), timeout=900):
    t0 = time.time()
    try:
        r = subprocess.run(["stdbuf", "-o0", "-e0", sim] + list(args), capture_output=True, text=True, timeout=timeout)
        out = r.stdout + r.stderr
        rc = r.returncode
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        rc = -9
    res = {"rc": rc, "out": out, "secs": time.time() - t0, "result": "NONE", "checks": 0, "errors": 0}
    m = re.search(r"TB_RESULT\s+(\S+)\s+(PASS|FAIL)\s*(?:checks=(\d+))?(?:\s*errors=(\d+))?(?:\s*checks=(\d+))?", out)
    if m:
        res["result"] = m.group(2)
        res["name"] = m.group(1)
        res["checks"] = int(m.group(3) or m.group(5) or 0)
        res["errors"] = int(m.group(4) or 0)
    # DUT assertion / $error messages count as failures even if the bench banner says PASS
    bad = [l for l in out.splitlines() if re.search(r"%Error|\$error|Assertion failed|sf_compute\w*: .*(two executors|completion presented|request changed|empty write strobe|unexpected response)", l)]
    res["dut_errors"] = bad
    if bad and res["result"] == "PASS":
        res["result"] = "FAIL"
    res["perf"] = {int(a): int(b) for a, b in re.findall(r"^PERF (\d+) (\d+)$", out, re.M)}
    res["csr"] = {int(a, 16): int(b) for a, b in re.findall(r"^CSR ([0-9a-f]+) (\d+)$", out, re.M)}
    res["cplrecs"] = [dict(re.findall(r"(\w+)=(\w+)", l)) for l in out.splitlines() if l.startswith("CPLREC")]
    res["fails"] = [l for l in out.splitlines() if l.startswith("[FAIL]")][:8]
    return res
