// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS :: sf_compute_vector_exec
// Aureom.AI / SilicaFlux Albion
//
// Element-wise vector executor around the REUSED hpc_vector_array (HPC Module 03, whose lanes are the
// verified Module 02 FP32 / INT32 lanes).  No arithmetic is implemented here.
//
//   VADD : D[i] = A[i] + B[i]            FP32 (FADD)  or INT32 (IADD, modulo 2^32)
//   VMUL : D[i] = A[i] * B[i]            FP32 (FMUL)  or INT32 (IMUL, modulo 2^32)
//   VFMA : D[i] = A[i] * B[i] + C[i]     FP32 fused multiply-add, ONE rounding (FMADD)
//
// The vector is processed in chunks of CH = STG_BYTES/4 elements:
//     LOAD   engine jobs copy the chunk of A, B (and C) from local memory into staging 0 / 1 / 2
//            (with two engines A and B load concurrently)
//     ARRAY  one array command {op, rm, vl = chunk}, then ceil(chunk/NUM_LANES) operand beats
//            (element e -> beat e/NUM_LANES, lane e%NUM_LANES); result beats are written to the OUT
//            buffer as they arrive; the array's completion record carries the OR of the exception flags
//     STORE  a WRITE2D job copies the chunk of results to DST
// Exception flags {NV, DZ, OF, UF, NX} of every chunk are ORed into the command's FFLAGS.
//
// Rounding mode applies to FP32 only (the decoder has already rejected RM > 4 for FP32; the array
// rejects nothing here because nothing illegal reaches it).  FP16 / BF16 / FP64 never get this far.
// =============================================================================
`timescale 1ns/1ps
`include "sf_compute_defs.svh"
`default_nettype none

module sf_compute_vector_exec #(
  parameter int NUM_LANES = 4,
  parameter int NUM_CP    = 1,
  parameter int STG_BYTES = 1024,
  parameter int SIW       = $clog2(STG_BYTES) + 1,
  parameter int OWB       = 16
) (
  input  wire logic                       clk,
  input  wire logic                       rst_n,
  // ---------------------------------------------------------------- command
  input  wire logic                       start,
  output logic                            ready,
  input  wire logic [7:0]                 op_i,
  input  wire logic [7:0]                 etype_i,
  input  wire logic [2:0]                 rm_i,
  input  wire logic [31:0]                vl_i,
  input  wire logic [31:0]                src_a_i, src_b_i, src_c_i, dst_i,
  output logic                            done,            // 1-cycle pulse
  output logic [`CW_ST_W-1:0]             status_o,
  output logic [15:0]                     detail_o,
  output logic [31:0]                     out_bytes_o,
  output logic [4:0]                      fflags_o,
  output logic [39:0]                     active_o,
  output logic                            ph_load, ph_compute, ph_store,
  // ---------------------------------------------------------------- adapter jobs
  output logic [NUM_CP-1:0]               job_valid,
  input  wire logic [NUM_CP-1:0]          job_ready,
  output logic [NUM_CP*2-1:0]             job_kind,
  output logic [NUM_CP*32-1:0]            job_base,
  output logic [NUM_CP*16-1:0]            job_rows,
  output logic [NUM_CP*32-1:0]            job_rowbytes,
  output logic [NUM_CP*32-1:0]            job_stride,
  output logic [NUM_CP*2-1:0]             job_stg,
  output logic [NUM_CP*SIW-1:0]           job_stg_base,
  output logic [NUM_CP*SIW-1:0]           job_stg_pitch,
  input  wire logic [NUM_CP-1:0]          job_done,
  input  wire logic [NUM_CP*3-1:0]        job_err,
  input  wire logic [STG_BYTES*8-1:0]     stg0_flat,
  input  wire logic [STG_BYTES*8-1:0]     stg1_flat,
  input  wire logic [STG_BYTES*8-1:0]     stg2_flat,
  output logic                            o_wr_en,
  output logic [SIW-1:0]                  o_wr_idx,
  output logic [OWB*8-1:0]                o_wr_data
);
  localparam int CH   = STG_BYTES / 4;            // elements per chunk
  localparam int VLW  = 16;
  localparam int NLB  = NUM_LANES * 32;
  localparam int BW   = $clog2(CH / NUM_LANES + 2);

  initial begin
    if (OWB < 4 * NUM_LANES) $fatal(1, "sf_compute_vector_exec: OWB must be >= 4*NUM_LANES");
    if ((CH % NUM_LANES) != 0) $fatal(1, "sf_compute_vector_exec: chunk must be a multiple of NUM_LANES");
    if (CH > 65535) $fatal(1, "sf_compute_vector_exec: chunk too large for the array's VL_W");
  end

  localparam int JT_A = 0, JT_B = 1, JT_C = 2, JT_S = 3;
  localparam int EA = 0, EC = 0;
  localparam int EB = (NUM_CP > 1) ? 1 : 0;
  localparam int ES = 0;

  typedef enum logic [3:0] {
    S_IDLE, S_CHUNK, S_LOAD, S_ACMD, S_FEED, S_STORE_ISSUE, S_STORE_WAIT, S_NEXT, S_FINISH
  } st_e;
  st_e st_q;

  // command registers
  logic [7:0]  op_q, et_q;
  logic [2:0]  rm_q;
  logic [31:0] vl_q, a_q, b_q, c_q, d_q;
  logic [31:0] e0_q;                    // first element of the current chunk
  logic [31:0] cnt_q;                   // elements in the current chunk
  logic [BW-1:0] nbeats_q, beat_q;
  logic        pa_q, pb_q, pc_q, ps_q;
  logic [NUM_CP-1:0]   eng_act_q;
  logic [NUM_CP*2-1:0] eng_jt_q;
  logic [2:0]  err_code_q;
  logic [3:0]  err_phase_q;
  logic        int_err_q;
  logic [4:0]  ff_q;
  logic        got_cpl_q, fed_q;
  logic [39:0] active_q;

  wire is_fma = (op_q == `CW_OP_VFMA);
  wire is_int = (et_q == `CW_ET_INT32);

  assign ready = (st_q == S_IDLE);

  // ---------------------------------------------------------------------------
  // job generation (same scheme as the tensor executor)
  // ---------------------------------------------------------------------------
  wire [31:0] off4  = e0_q << 2;
  wire [31:0] cbytes = cnt_q << 2;

  logic [NUM_CP-1:0]   sel_v;
  logic [NUM_CP*2-1:0] sel_jt;
  always_comb begin
    sel_v  = '0;
    sel_jt = '0;
    for (int e = 0; e < NUM_CP; e++) begin
      if (st_q == S_LOAD) begin
        if      (pa_q && (EA == e)) begin sel_v[e] = 1'b1; sel_jt[e*2 +: 2] = 2'(JT_A); end
        else if (pb_q && (EB == e)) begin sel_v[e] = 1'b1; sel_jt[e*2 +: 2] = 2'(JT_B); end
        else if (pc_q && (EC == e)) begin sel_v[e] = 1'b1; sel_jt[e*2 +: 2] = 2'(JT_C); end
      end else if (st_q == S_STORE_ISSUE) begin
        if (ps_q && (ES == e)) begin sel_v[e] = 1'b1; sel_jt[e*2 +: 2] = 2'(JT_S); end
      end
    end
  end

  always_comb begin
    job_valid     = sel_v;
    job_kind      = '0;
    job_base      = '0;
    job_rows      = '0;
    job_rowbytes  = '0;
    job_stride    = '0;
    job_stg       = '0;
    job_stg_base  = '0;
    job_stg_pitch = '0;
    for (int e = 0; e < NUM_CP; e++) begin
      if (sel_v[e]) begin
        job_rows[e*16 +: 16]         = 16'd1;
        job_rowbytes[e*32 +: 32]     = cbytes;
        job_stride[e*32 +: 32]       = 32'd0;
        job_stg_base[e*SIW +: SIW]   = '0;
        job_stg_pitch[e*SIW +: SIW]  = '0;
        case (sel_jt[e*2 +: 2])
          2'(JT_A): begin job_kind[e*2 +: 2] = `CW_JK_READ2D;  job_base[e*32 +: 32] = a_q + off4; job_stg[e*2 +: 2] = 2'd0; end
          2'(JT_B): begin job_kind[e*2 +: 2] = `CW_JK_READ2D;  job_base[e*32 +: 32] = b_q + off4; job_stg[e*2 +: 2] = 2'd1; end
          2'(JT_C): begin job_kind[e*2 +: 2] = `CW_JK_READ2D;  job_base[e*32 +: 32] = c_q + off4; job_stg[e*2 +: 2] = 2'd2; end
          default:  begin job_kind[e*2 +: 2] = `CW_JK_WRITE2D; job_base[e*32 +: 32] = d_q + off4; job_stg[e*2 +: 2] = 2'd3; end
        endcase
      end
    end
  end

  wire [NUM_CP-1:0] job_acc = job_valid & job_ready;
  wire              all_idle = (eng_act_q == '0);

  // ---------------------------------------------------------------------------
  // HPC Module 03 vector array
  // ---------------------------------------------------------------------------
  logic              va_cmd_valid, va_cmd_ready;
  logic [4:0]        va_cmd_op;
  logic              va_opnd_valid, va_opnd_ready;
  logic [NLB-1:0]    va_opnd_a, va_opnd_b, va_opnd_c;
  logic              va_res_valid, va_res_last;
  logic [NLB-1:0]    va_res_data;
  logic [NUM_LANES*5-1:0] va_res_flags;
  logic [NUM_LANES-1:0]   va_res_mask;
  logic [7:0]        va_res_tid;
  logic [VLW-1:0]    va_res_beat;
  logic              va_cpl_valid, va_cpl_illegal, va_cpl_red;
  logic [7:0]        va_cpl_tid;
  logic [4:0]        va_cpl_flags;
  logic [VLW-1:0]    va_cpl_count;
  logic [31:0]       va_cpl_result;
  logic              va_busy;

  // element operation code (hpc_vector_pkg encoding, reproduced in the defs header)
  always_comb begin
    case (op_q)
      `CW_OP_VADD: va_cmd_op = is_int ? 5'(`CW_VOP_IADD) : 5'(`CW_VOP_FADD);
      `CW_OP_VMUL: va_cmd_op = is_int ? 5'(`CW_VOP_IMUL) : 5'(`CW_VOP_FMUL);
      default:     va_cmd_op = 5'(`CW_VOP_FMADD);
    endcase
  end

  hpc_vector_array #(
    .NUM_LANES(NUM_LANES), .VL_W(VLW), .TID_W(8), .CMD_DEPTH(2), .TRK_DEPTH(8), .CPL_DEPTH(2),
    .RED_EN(1'b0), .PERF_EN(1'b0), .EN_FCMP(1'b0), .EN_INT(1'b1)
  ) u_va (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(va_cmd_valid), .cmd_ready_o(va_cmd_ready), .cmd_op_i(va_cmd_op),
    .cmd_rm_i(is_int ? 3'd0 : rm_q), .cmd_vl_i(VLW'(cnt_q)), .cmd_vm_i(1'b0), .cmd_bcast_i(3'd0),
    .cmd_scalar_i(32'd0), .cmd_red_i(1'b0), .cmd_tid_i(8'd0),
    .opnd_valid_i(va_opnd_valid), .opnd_ready_o(va_opnd_ready),
    .opnd_a_i(va_opnd_a), .opnd_b_i(va_opnd_b), .opnd_c_i(va_opnd_c), .opnd_mask_i({NUM_LANES{1'b1}}),
    .res_valid_o(va_res_valid), .res_ready_i(1'b1), .res_data_o(va_res_data), .res_flags_o(va_res_flags),
    .res_mask_o(va_res_mask), .res_tid_o(va_res_tid), .res_beat_o(va_res_beat), .res_last_o(va_res_last),
    .cpl_valid_o(va_cpl_valid), .cpl_ready_i(1'b1), .cpl_tid_o(va_cpl_tid), .cpl_flags_o(va_cpl_flags),
    .cpl_illegal_o(va_cpl_illegal), .cpl_count_o(va_cpl_count), .cpl_red_o(va_cpl_red), .cpl_result_o(va_cpl_result),
    .lane_hold_i({NUM_LANES{1'b0}}), .busy_o(va_busy), .perf_clear_i(1'b0), .perf_cnt_o());

  assign va_cmd_valid  = (st_q == S_ACMD);
  assign va_opnd_valid = (st_q == S_FEED) && !fed_q;

  // operand beat assembly from staging: beat b, lane l = element b*NUM_LANES + l
  always_comb begin
    va_opnd_a = '0; va_opnd_b = '0; va_opnd_c = '0;
    for (int l = 0; l < NUM_LANES; l++) begin
      int bi;
      bi = (int'(beat_q) * NUM_LANES + l) * 4;
      if ((bi + 3) < STG_BYTES) begin
        va_opnd_a[l*32 +: 32] = stg0_flat[bi*8 +: 32];
        va_opnd_b[l*32 +: 32] = stg1_flat[bi*8 +: 32];
        va_opnd_c[l*32 +: 32] = stg2_flat[bi*8 +: 32];
      end
    end
  end

  // result beats -> OUT buffer
  always_comb begin
    o_wr_en   = (st_q == S_FEED) && va_res_valid;
    o_wr_idx  = SIW'(int'(va_res_beat) * NUM_LANES * 4);
    o_wr_data = '0;
    o_wr_data[NLB-1:0] = va_res_data;
  end

  // ---------------------------------------------------------------------------
  // sequencing
  // ---------------------------------------------------------------------------
  assign ph_load    = (st_q == S_CHUNK) || (st_q == S_LOAD);
  assign ph_compute = (st_q == S_ACMD) || (st_q == S_FEED);
  assign ph_store   = (st_q == S_STORE_ISSUE) || (st_q == S_STORE_WAIT);

  wire [31:0] remaining = vl_q - e0_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE; op_q <= '0; et_q <= '0; rm_q <= '0; vl_q <= '0; a_q <= '0; b_q <= '0; c_q <= '0; d_q <= '0;
      e0_q <= '0; cnt_q <= '0; nbeats_q <= '0; beat_q <= '0;
      pa_q <= 1'b0; pb_q <= 1'b0; pc_q <= 1'b0; ps_q <= 1'b0;
      eng_act_q <= '0; eng_jt_q <= '0; err_code_q <= '0; err_phase_q <= '0; int_err_q <= 1'b0; ff_q <= '0;
      got_cpl_q <= 1'b0; fed_q <= 1'b0; active_q <= '0;
      done <= 1'b0; status_o <= `CW_ST_OK; detail_o <= '0; out_bytes_o <= '0; fflags_o <= '0; active_o <= '0;
    end else begin
      done <= 1'b0;

      // engine bookkeeping: `done` first, `accept` last so that acceptance wins when both happen in one cycle
      for (int e = 0; e < NUM_CP; e++) begin
        if (job_done[e]) begin
          eng_act_q[e] <= 1'b0;
          if (job_err[e*3 +: 3] != 3'd0 && err_code_q == 3'd0) begin
            err_code_q <= job_err[e*3 +: 3];
            case (eng_jt_q[e*2 +: 2])
              2'(JT_A): err_phase_q <= `CW_PH_LOAD_A;
              2'(JT_B): err_phase_q <= `CW_PH_LOAD_B;
              2'(JT_C): err_phase_q <= `CW_PH_LOAD_C;
              default:  err_phase_q <= `CW_PH_STORE;
            endcase
          end
        end
        if (job_acc[e]) begin
          eng_act_q[e]       <= 1'b1;
          eng_jt_q[e*2 +: 2] <= sel_jt[e*2 +: 2];
          case (sel_jt[e*2 +: 2])
            2'(JT_A): pa_q <= 1'b0;
            2'(JT_B): pb_q <= 1'b0;
            2'(JT_C): pc_q <= 1'b0;
            default:  ps_q <= 1'b0;
          endcase
        end
      end

      if (va_busy && (st_q == S_FEED || st_q == S_ACMD)) active_q <= active_q + 40'd1;

      case (st_q)
        S_IDLE: if (start) begin
          op_q <= op_i; et_q <= etype_i; rm_q <= rm_i; vl_q <= vl_i;
          a_q <= src_a_i; b_q <= src_b_i; c_q <= src_c_i; d_q <= dst_i;
          e0_q <= '0; ff_q <= '0; err_code_q <= '0; err_phase_q <= '0; int_err_q <= 1'b0; active_q <= '0;
          st_q <= S_CHUNK;
        end

        S_CHUNK: begin
          cnt_q    <= (remaining > 32'(CH)) ? 32'(CH) : remaining;
          nbeats_q <= BW'(((((remaining > 32'(CH)) ? 32'(CH) : remaining) + 32'(NUM_LANES - 1)) / 32'(NUM_LANES)));
          pa_q <= 1'b1; pb_q <= 1'b1; pc_q <= is_fma;
          st_q <= S_LOAD;
        end

        S_LOAD: begin
          if (!pa_q && !pb_q && !pc_q && all_idle) begin
            if (err_code_q != 3'd0) st_q <= S_FINISH;
            else begin beat_q <= '0; fed_q <= 1'b0; got_cpl_q <= 1'b0; st_q <= S_ACMD; end
          end
        end

        S_ACMD: if (va_cmd_ready) st_q <= S_FEED;

        S_FEED: begin
          if (va_opnd_valid && va_opnd_ready) begin
            if (int'(beat_q) + 1 >= int'(nbeats_q)) fed_q <= 1'b1;
            beat_q <= beat_q + 1'b1;
          end
          if (va_cpl_valid) begin
            got_cpl_q <= 1'b1;
            ff_q      <= ff_q | va_cpl_flags;
            if (va_cpl_illegal || (32'(va_cpl_count) != cnt_q)) int_err_q <= 1'b1;
          end
          if ((va_cpl_valid || got_cpl_q) && (fed_q || (va_opnd_valid && va_opnd_ready && (int'(beat_q) + 1 >= int'(nbeats_q))))) begin
            ps_q <= 1'b1;
            st_q <= S_STORE_ISSUE;
          end
        end

        S_STORE_ISSUE: if (!ps_q) st_q <= S_STORE_WAIT;

        S_STORE_WAIT: if (all_idle) begin
          if (err_code_q != 3'd0) st_q <= S_FINISH;
          else                    st_q <= S_NEXT;
        end

        S_NEXT: begin
          e0_q <= e0_q + cnt_q;
          if ((e0_q + cnt_q) >= vl_q) st_q <= S_FINISH;
          else                        st_q <= S_CHUNK;
        end

        S_FINISH: begin
          done      <= 1'b1;
          active_o  <= active_q;
          fflags_o  <= ff_q;
          if (err_code_q != 3'd0) begin
            status_o <= `CW_ST_MEM_ERR; detail_o <= {err_phase_q, 9'd0, err_code_q}; out_bytes_o <= '0; fflags_o <= '0;
          end else if (int_err_q) begin
            status_o <= `CW_ST_MEM_ERR; detail_o <= {4'hF, 12'd0}; out_bytes_o <= '0; fflags_o <= '0;
          end else begin
            status_o <= `CW_ST_OK; detail_o <= '0; out_bytes_o <= vl_q << 2;
          end
          st_q <= S_IDLE;
        end

        default: st_q <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
