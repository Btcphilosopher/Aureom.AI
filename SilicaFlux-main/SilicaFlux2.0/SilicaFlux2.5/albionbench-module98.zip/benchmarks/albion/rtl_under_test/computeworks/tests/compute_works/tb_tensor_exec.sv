// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS : tb_tensor_exec
//
// Direct test of sf_compute_tensor_exec (reused TENSORCORE 02 inside) on the REAL
// IronMemory.  Random INT8 GEMMs (partial tiles, extreme values, optional INT32
// accumulation, unaligned A/B) against an SV 64-bit reference; the whole local
// memory is compared after every command so any stray write is caught.
// The independent Python-reference campaign runs at tile level (tb_compute_tile).
// =============================================================================
`timescale 1ns/1ps
`include "cw_tb_common.svh"
`include "sf_compute_defs.svh"

module tb_tensor_exec;
  parameter int NUM_CP = 1;
  parameter int DW     = 64;
  parameter int NTESTS = 60;
  parameter int ROWS   = 4;
  parameter int COLS   = 4;
  localparam int NB    = DW / 8;
  localparam int STG   = 1024;
  localparam int SIW   = $clog2(STG) + 1;
  localparam int OWB   = 16;
  localparam int NP    = 2 + NUM_CP;
  localparam int BANKS = 4;
  localparam int DEPTH = 256;
  localparam int SRAM_BYTES = BANKS * DEPTH * NB;
  localparam logic [31:0] BASE = 32'h1000_0000;
  localparam logic [23:0] PDM  = (NUM_CP == 1) ? 24'o0000310 : 24'o0003310;
  localparam int IDW = 4;
  localparam int LEN_W = $clog2(SRAM_BYTES + 1);
  localparam int KMAX = (STG / ROWS < STG / COLS) ? STG / ROWS : STG / COLS;

  int tb_errors = 0, tb_checks = 0;
  int seed = 1;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ------------------------------------------------------------ IronMemory
  logic [NP-1:0]      im_req_valid, im_req_ready;
  logic [NP*32-1:0]   im_req_addr;
  logic [NP*3-1:0]    im_req_size;
  logic [NP-1:0]      im_req_we;
  logic [NP*DW-1:0]   im_req_wdata;
  logic [NP*NB-1:0]   im_req_wstrb;
  logic [NP-1:0]      im_rsp_valid, im_rsp_ready;
  logic [NP*DW-1:0]   im_rsp_rdata;
  logic [NP*3-1:0]    im_rsp_err;
  logic               bm_cmd_valid, bm_cmd_ready, bm_rsp_valid;
  logic [2:0]         bm_cmd_op, bm_cmd_requester, bm_cmd_btype, bm_cmd_owner;
  logic [IDW-1:0]     bm_cmd_id;
  logic [31:0]        bm_cmd_start;
  logic [LEN_W-1:0]   bm_cmd_len;
  logic [4:0]         bm_cmd_rd_mask, bm_cmd_wr_mask;
  logic [3:0]         bm_rsp_status;
  logic               init_done;

  sf_iron_memory #(.NUM_PORTS(NP), .PORT_DOMAIN_MAP(PDM), .DW(DW), .NUM_BANKS(BANKS), .BANK_DEPTH(DEPTH),
                   .EXT_EN(0), .NUM_DESC(16)) u_im (
    .clk, .rst_n,
    .m_req_valid(im_req_valid), .m_req_ready(im_req_ready), .m_req_addr(im_req_addr), .m_req_size(im_req_size),
    .m_req_we(im_req_we), .m_req_wdata(im_req_wdata), .m_req_wstrb(im_req_wstrb),
    .m_rsp_valid(im_rsp_valid), .m_rsp_ready(im_rsp_ready), .m_rsp_rdata(im_rsp_rdata), .m_rsp_err(im_rsp_err),
    .m_rsp_ecc_corr(),
    .bm_cmd_valid, .bm_cmd_ready, .bm_cmd_op, .bm_cmd_requester, .bm_cmd_id, .bm_cmd_btype, .bm_cmd_start,
    .bm_cmd_len, .bm_cmd_owner, .bm_cmd_rd_mask, .bm_cmd_wr_mask,
    .bm_rsp_valid, .bm_rsp_status, .bm_rsp_id(), .bm_rsp_in_use(), .bm_rsp_btype(), .bm_rsp_start(), .bm_rsp_len(),
    .bm_rsp_owner(), .bm_rsp_rd_mask(), .bm_rsp_wr_mask(), .bm_rsp_err_bits(),
    .csr_valid(1'b0), .csr_we(1'b0), .csr_addr(12'd0), .csr_wdata(32'd0), .csr_rvalid(), .csr_rdata(), .csr_err(),
    .ext_cmd_valid(), .ext_cmd_ready(1'b1), .ext_cmd_we(), .ext_cmd_addr(), .ext_cmd_wdata(), .ext_cmd_wstrb(),
    .ext_cmd_tag(), .ext_rsp_valid(1'b0), .ext_rsp_ready(), .ext_rsp_rdata('0), .ext_rsp_err(1'b0), .ext_rsp_tag('0),
    .init_done, .irq(),
    .trc_valid(), .trc_port(), .trc_seq(), .trc_we(), .trc_word(), .trc_be(), .trc_wdata());

  // ------------------------------------------------------------ adapter + executor
  logic [NUM_CP-1:0]      job_valid, job_ready, job_done;
  logic [NUM_CP*2-1:0]    job_kind, job_stg;
  logic [NUM_CP*32-1:0]   job_base, job_rowbytes, job_stride;
  logic [NUM_CP*16-1:0]   job_rows, job_nerr;
  logic [NUM_CP*SIW-1:0]  job_stg_base, job_stg_pitch;
  logic [NUM_CP*3-1:0]    job_err;
  logic [STG*8-1:0]       stg0, stg1, stg2, stg3;
  logic                   o_wr_en, stg_clear;
  logic [SIW-1:0]         o_wr_idx;
  logic [OWB*8-1:0]       o_wr_data;
  logic [NUM_CP-1:0]      a_req_valid, a_req_ready, a_req_we, a_rsp_valid, a_rsp_ready;
  logic [NUM_CP*32-1:0]   a_req_addr;
  logic [NUM_CP*3-1:0]    a_req_size, a_rsp_err;
  logic [NUM_CP*DW-1:0]   a_req_wdata, a_rsp_rdata;
  logic [NUM_CP*NB-1:0]   a_req_wstrb;

  sf_compute_memory_adapter #(.NUM_CP(NUM_CP), .DW(DW), .STG_BYTES(STG), .OWB(OWB)) u_ad (
    .clk, .rst_n,
    .job_valid, .job_ready, .job_kind, .job_base, .job_rows, .job_rowbytes, .job_stride, .job_stg,
    .job_stg_base, .job_stg_pitch, .job_done, .job_err, .job_nerr,
    .m_req_valid(a_req_valid), .m_req_ready(a_req_ready), .m_req_addr(a_req_addr), .m_req_size(a_req_size),
    .m_req_we(a_req_we), .m_req_wdata(a_req_wdata), .m_req_wstrb(a_req_wstrb),
    .m_rsp_valid(a_rsp_valid), .m_rsp_ready(a_rsp_ready), .m_rsp_rdata(a_rsp_rdata), .m_rsp_err(a_rsp_err),
    .stg0_flat(stg0), .stg1_flat(stg1), .stg2_flat(stg2), .stg3_flat(stg3),
    .o_wr_en, .o_wr_idx, .o_wr_data, .stg_clear,
    .ev_rd(), .ev_wr(), .ev_stall(), .ev_err(), .eng_busy());

  logic        ex_start, ex_ready, ex_done, ex_acc;
  logic [15:0] ex_m, ex_n, ex_k, ex_detail;
  logic [31:0] ex_a, ex_b, ex_c, ex_d, ex_outbytes;
  logic [4:0]  ex_status;
  logic [47:0] ex_macs;
  logic [39:0] ex_busy;

  sf_compute_tensor_exec #(.ROWS(ROWS), .COLS(COLS), .NUM_CP(NUM_CP), .STG_BYTES(STG), .OWB(OWB)) u_ex (
    .clk, .rst_n,
    .start(ex_start), .ready(ex_ready),
    .m_i(ex_m), .n_i(ex_n), .k_i(ex_k), .src_a_i(ex_a), .src_b_i(ex_b), .src_c_i(ex_c), .dst_i(ex_d), .acc_i(ex_acc),
    .done(ex_done), .status_o(ex_status), .detail_o(ex_detail), .out_bytes_o(ex_outbytes), .macs_o(ex_macs),
    .array_busy_o(ex_busy), .ph_load(), .ph_compute(), .ph_store(),
    .job_valid, .job_ready, .job_kind, .job_base, .job_rows, .job_rowbytes, .job_stride, .job_stg,
    .job_stg_base, .job_stg_pitch, .job_done, .job_err,
    .stg0_flat(stg0), .stg1_flat(stg1), .stg2_flat(stg2),
    .o_wr_en, .o_wr_idx, .o_wr_data);

  // port wiring
  logic          br_req_valid, br_we;
  logic [31:0]   br_addr;
  logic [DW-1:0] br_wdata;
  logic [NB-1:0] br_wstrb;
  always_comb begin
    im_req_valid = '0; im_req_addr = '0; im_req_size = '0; im_req_we = '0; im_req_wdata = '0; im_req_wstrb = '0;
    im_rsp_ready = '1;
    im_req_valid[1]        = br_req_valid;
    im_req_addr[32 +: 32]  = br_addr;
    im_req_size[3 +: 3]    = 3'($clog2(NB));
    im_req_we[1]           = br_we;
    im_req_wdata[DW +: DW] = br_wdata;
    im_req_wstrb[NB +: NB] = br_wstrb;
    for (int e = 0; e < NUM_CP; e++) begin
      im_req_valid[2+e]            = a_req_valid[e];
      im_req_addr[(2+e)*32 +: 32]  = a_req_addr[e*32 +: 32];
      im_req_size[(2+e)*3 +: 3]    = a_req_size[e*3 +: 3];
      im_req_we[2+e]               = a_req_we[e];
      im_req_wdata[(2+e)*DW +: DW] = a_req_wdata[e*DW +: DW];
      im_req_wstrb[(2+e)*NB +: NB] = a_req_wstrb[e*NB +: NB];
    end
    a_req_ready = im_req_ready[2 +: NUM_CP];
    a_rsp_valid = im_rsp_valid[2 +: NUM_CP];
    a_rsp_rdata = im_rsp_rdata[2*DW +: NUM_CP*DW];
    a_rsp_err   = im_rsp_err[2*3 +: NUM_CP*3];
  end

  // ------------------------------------------------------------ monitors (counters only)
  int            br_acc_cnt = 0, br_rsp_cnt = 0, bm_cnt = 0, ex_done_cnt = 0;
  logic [3:0]    bm_status_q;
  logic [DW-1:0] br_rsp_data_q;
  logic [2:0]    br_rsp_err_q;
  logic [4:0]    ex_status_q;
  logic [15:0]   ex_detail_q;
  logic [31:0]   ex_outbytes_q;
  logic [47:0]   ex_macs_q;
  always @(posedge clk) begin
    if (br_req_valid && im_req_ready[1]) br_acc_cnt <= br_acc_cnt + 1;
    if (im_rsp_valid[1]) begin
      br_rsp_cnt <= br_rsp_cnt + 1; br_rsp_data_q <= im_rsp_rdata[DW +: DW]; br_rsp_err_q <= im_rsp_err[3 +: 3];
    end
    if (bm_rsp_valid) begin bm_cnt <= bm_cnt + 1; bm_status_q <= bm_rsp_status; end
    if (ex_done) begin
      ex_done_cnt <= ex_done_cnt + 1; ex_status_q <= ex_status; ex_detail_q <= ex_detail;
      ex_outbytes_q <= ex_outbytes; ex_macs_q <= ex_macs;
    end
  end

  // ------------------------------------------------------------ shadow memory + helpers
  logic [7:0] mem [SRAM_BYTES];

  task automatic br_word(input logic [31:0] addr, input logic we, input logic [DW-1:0] wd, input logic [NB-1:0] ws,
                         output logic [DW-1:0] rd, output logic [2:0] err);
    int acc0, rsp0;
    @(negedge clk);
    acc0 = br_acc_cnt; rsp0 = br_rsp_cnt;
    br_req_valid = 1; br_addr = addr; br_we = we; br_wdata = wd; br_wstrb = ws;
    do @(negedge clk); while (br_acc_cnt == acc0);
    br_req_valid = 0;
    while (br_rsp_cnt == rsp0) @(negedge clk);
    rd = br_rsp_data_q; err = br_rsp_err_q;
  endtask

  task automatic br_write_bytes(input int off, input int n);
    logic [DW-1:0] rd; logic [2:0] er; logic [DW-1:0] wd; logic [NB-1:0] ws;
    for (int wa = (off / NB) * NB; wa <= ((off + n - 1) / NB) * NB; wa += NB) begin
      wd = '0; ws = '0;
      for (int l = 0; l < NB; l++) if ((wa + l) >= off && (wa + l) < off + n) begin
        wd[l*8 +: 8] = mem[wa + l]; ws[l] = 1'b1;
      end
      br_word(BASE + 32'(wa), 1'b1, wd, ws, rd, er);
      `CHECK_EQ(er, 3'd0, "bridge write response")
    end
  endtask

  task automatic br_check_all(input string what);
    logic [DW-1:0] rd; logic [2:0] er;
    for (int wa = 0; wa < SRAM_BYTES; wa += NB) begin
      br_word(BASE + 32'(wa), 1'b0, '0, '0, rd, er);
      `CHECK_EQ(er, 3'd0, "bridge read response")
      for (int l = 0; l < NB; l++) begin
        tb_checks++;
        if (rd[l*8 +: 8] !== mem[wa + l]) begin
          tb_errors++;
          if (tb_errors <= 40) $display("[FAIL] %s: mem[%0d] got=%02h exp=%02h", what, wa + l, rd[l*8 +: 8], mem[wa + l]);
        end
      end
    end
  endtask

  function automatic int rnd(input int lo, input int hi);
    return int'($urandom_range(hi, lo));
  endfunction

  // run one GEMM on the executor and compare everything
  int dn0;
  task automatic run_gemm(input int M, input int N, input int K, input bit acc, input int offA, input int offB,
                          input int offC, input int offD, input string tag);
    int mism;
    // reference
    logic [31:0] ref_d [];
    ref_d = new[M * N];
    for (int i = 0; i < M; i++)
      for (int j = 0; j < N; j++) begin
        longint s;
        s = 0;
        for (int k = 0; k < K; k++) begin
          longint av, bv;
          av = longint'($signed(mem[offA + i * K + k]));
          bv = longint'($signed(mem[offB + k * N + j]));
          s += av * bv;
        end
        if (acc) begin
          logic [31:0] c;
          for (int b = 0; b < 4; b++) c[b*8 +: 8] = mem[offC + (i * N + j) * 4 + b];
          s += longint'($signed(c));
        end
        ref_d[i * N + j] = s[31:0];
      end
    // drive
    @(negedge clk);
    dn0 = ex_done_cnt;
    ex_start = 1; ex_m = 16'(M); ex_n = 16'(N); ex_k = 16'(K); ex_acc = acc;
    ex_a = BASE + 32'(offA); ex_b = BASE + 32'(offB); ex_c = BASE + 32'(offC); ex_d = BASE + 32'(offD);
    @(negedge clk);
    ex_start = 0;
    while (ex_done_cnt == dn0) @(negedge clk);
    `CHECK_EQ(ex_status_q, 5'(`CW_ST_OK), {tag, ": status"})
    `CHECK_EQ(ex_outbytes_q, 32'(M * N * 4), {tag, ": out bytes"})
    `CHECK_EQ(ex_macs_q, 48'(M) * 48'(N) * 48'(K), {tag, ": MAC count"})
    // update shadow memory with the reference result, then compare the entire memory
    for (int i = 0; i < M * N; i++)
      for (int b = 0; b < 4; b++) mem[offD + i * 4 + b] = ref_d[i][b*8 +: 8];
    br_check_all(tag);
  endtask

  // ------------------------------------------------------------ main
  int M, N, K, offA, offB, offC, offD;
  bit acc;
  initial begin
    if ($value$plusargs("seed=%d", seed)) ;
    void'($urandom(seed));
    ex_start = 0; ex_m = 0; ex_n = 0; ex_k = 0; ex_a = 0; ex_b = 0; ex_c = 0; ex_d = 0; ex_acc = 0; stg_clear = 0;
    br_req_valid = 0; br_we = 0; br_addr = '0; br_wdata = '0; br_wstrb = '0;
    bm_cmd_valid = 0; bm_cmd_op = 0; bm_cmd_requester = 0; bm_cmd_id = 0; bm_cmd_btype = 0; bm_cmd_start = 0;
    bm_cmd_len = 0; bm_cmd_owner = 0; bm_cmd_rd_mask = 0; bm_cmd_wr_mask = 0;
    repeat (5) @(posedge clk);
    rst_n = 1;
    while (!init_done) @(posedge clk);
    repeat (3) @(posedge clk);
    @(negedge clk);
    while (!bm_cmd_ready) @(negedge clk);
    dn0 = bm_cnt;
    bm_cmd_valid = 1; bm_cmd_op = 3'd1; bm_cmd_requester = 3'd0; bm_cmd_btype = 3'd3;
    bm_cmd_start = BASE; bm_cmd_len = LEN_W'(SRAM_BYTES); bm_cmd_owner = 3'd1; bm_cmd_rd_mask = 5'b01011; bm_cmd_wr_mask = 5'b01011;
    @(negedge clk); bm_cmd_valid = 0;
    while (bm_cnt == dn0) @(negedge clk);
    `CHECK_EQ(bm_status_q, 4'd0, "ALLOC_AT")

    for (int i = 0; i < SRAM_BYTES; i++) mem[i] = 8'($urandom);
    br_write_bytes(0, SRAM_BYTES);

    // ---- Stage 0: ONE 4x4 INT8 tensor operation (the brief's required first step)
    for (int i = 0; i < 16; i++) mem[0 + i] = 8'(i + 1);                 // A = 1..16
    for (int i = 0; i < 16; i++) mem[64 + i] = (i % 5 == 0) ? 8'd1 : 8'd0; // B = identity-like diag (1 at 0,5,10,15)
    br_write_bytes(0, 16); br_write_bytes(64, 16);
    run_gemm(4, 4, 4, 0, 0, 64, 128, 256, "single 4x4x4");
    // A x I = A: check explicitly against the architectural meaning, not only the reference loop
    for (int i = 0; i < 16; i++) begin
      logic [31:0] v;
      for (int b = 0; b < 4; b++) v[b*8 +: 8] = mem[256 + i*4 + b];
      `CHECK_EQ(v, 32'(i + 1), "A x I == A")
    end

    // ---- random campaign
    for (int t = 0; t < NTESTS; t++) begin
      int kcap;
      M = rnd(1, 11); N = rnd(1, 11);
      kcap = (rnd(0, 7) == 0) ? KMAX : 40;
      K = rnd(1, kcap);
      if (K > 90) begin M = rnd(1, 3); N = rnd(1, 3); end   // keep A (M*K) and B (K*N) inside their 1 KiB slots
      acc = rnd(0, 2) == 0;
      // layout: each operand in its own 1 KiB-aligned slot (A/B at arbitrary byte offsets, C/D 4-byte aligned)
      offA = 0    + rnd(0, 3);
      offB = 1024 + rnd(0, 3);
      offC = 2048 + 4 * rnd(0, 3);
      offD = (rnd(0, 3) == 0 && acc) ? offC : (3072 + 4 * rnd(0, 3));   // in-place accumulate sometimes
      // data: random, with extreme-value bursts
      for (int i = 0; i < M * K; i++) mem[offA + i] = (rnd(0, 5) == 0) ? ((rnd(0,1)) ? 8'h80 : 8'h7F) : 8'($urandom);
      for (int i = 0; i < K * N; i++) mem[offB + i] = (rnd(0, 5) == 0) ? ((rnd(0,1)) ? 8'h80 : 8'h7F) : 8'($urandom);
      for (int i = 0; i < M * N * 4; i++) mem[offC + i] = 8'($urandom);
      br_write_bytes(offA, M * K); br_write_bytes(offB, K * N);
      br_write_bytes(offC, M * N * 4);   // always: shadow and device must agree (C is a decoy when !acc)
      run_gemm(M, N, K, acc, offA, offB, offC, offD, $sformatf("rand %0d M=%0d N=%0d K=%0d acc=%0d", t, M, N, K, acc));
      if (t % 16 == 15) begin @(negedge clk); stg_clear = 1; @(negedge clk); stg_clear = 0; end
    end
    `TB_FINISH("tb_tensor_exec")
  end

  initial begin
    #400000000;
    $display("TB_RESULT tb_tensor_exec FAIL timeout");
    $finish;
  end
endmodule
