#!/usr/bin/env python3
"""ComputeWorks (Project 88) verification library: script builder, descriptor encoder, and the INDEPENDENT
reference models.  Nothing in here is derived from the RTL: the validation rules are re-implemented from the
specification in rtl/albion/sf_compute_defs.svh and docs/compute_works/02_COMMANDS.md, the INT8 GEMM and
INT32 arithmetic are plain Python integers, and the floating point reference is model/fp32ref.py (exact
rational arithmetic, validated against numpy).
"""
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cw_defs import *          # noqa: F401,F403  (generated constants)
import fp32ref as fp

SRAM_BASE = 0x1000_0000
M32 = 0xFFFFFFFF


# ----------------------------------------------------------------------------------------------- configuration
class Cfg:
    """Tile configuration as the model needs it (mirrors the testbench parameters)."""

    def __init__(self, num_lanes=4, rows=4, cols=4, banks=4, depth=512, dw=64, stg=1024, queues=1, cp=1,
                 guard=1, en_vector=1, en_int32=1, cmd_depth=4, cpl_depth=4, nreg=8, starve=16, gran=256,
                 clear_staging=1, ecc=1):
        self.num_lanes, self.rows, self.cols, self.banks, self.depth, self.dw = num_lanes, rows, cols, banks, depth, dw
        self.stg, self.queues, self.cp, self.guard = stg, queues, cp, guard
        self.en_vector, self.en_int32 = en_vector, en_int32
        self.cmd_depth, self.cpl_depth, self.nreg, self.starve, self.gran = cmd_depth, cpl_depth, nreg, starve, gran
        self.clear_staging, self.ecc = clear_staging, ecc

    @property
    def sram_bytes(self):
        return self.banks * self.depth * (self.dw // 8)

    @property
    def kmax(self):
        return min(self.stg // self.rows, self.stg // self.cols)

    @property
    def sram_end(self):
        return SRAM_BASE + self.sram_bytes

    def vparams(self):
        """Verilator -G overrides that realise this configuration."""
        return {"NUM_LANES": self.num_lanes, "TENSOR_ROWS": self.rows, "TENSOR_COLS": self.cols,
                "NUM_BANKS": self.banks, "BANK_DEPTH": self.depth, "DMA_DW": self.dw, "STG_BYTES": self.stg,
                "NUM_QUEUES": self.queues, "NUM_CP": self.cp, "GUARD_MODE": self.guard,
                "EN_VECTOR": self.en_vector, "CMD_QUEUE_DEPTH": self.cmd_depth, "CPL_DEPTH": self.cpl_depth,
                "STARVE_LIMIT": self.starve, "CLEAR_STAGING": self.clear_staging, "IM_ECC_EN": self.ecc}


# ----------------------------------------------------------------------------------------------- descriptors
def pack_desc(op=CW_OP_NOP, etype=0, rm=0, acc=0, tag=0, dom=0, dest=0, a=0, b=0, c=0, dst=0,
              m=0, n=0, k=0, w6=None, res0=0, res1=0, res7=0):
    """Eight 32-bit descriptor words.  `w6` overrides the M/N word (vector length / CLEAR length)."""
    w0 = (op & 0xFF) | ((etype & 0xFF) << 8) | ((rm & 7) << 16) | ((acc & 1) << 19) | ((res0 & 0xFFF) << 20)
    w1 = (tag & 0xFFFF) | ((dom & 7) << 16) | ((dest & 0xF) << 19) | ((res1 & 0x1FF) << 23)
    w6v = (m & 0xFFFF) | ((n & 0xFFFF) << 16) if w6 is None else (w6 & M32)
    w7 = (k & 0xFFFF) | ((res7 & 0xFFFF) << 16)
    return [w0, w1, a & M32, b & M32, c & M32, dst & M32, w6v, w7]


def decode_desc(w):
    """Inverse of pack_desc (used by the model validator)."""
    d = {}
    d["op"] = w[0] & 0xFF
    d["etype"] = (w[0] >> 8) & 0xFF
    d["rm"] = (w[0] >> 16) & 7
    d["acc"] = (w[0] >> 19) & 1
    d["res0"] = (w[0] >> 20) & 0xFFF
    d["tag"] = w[1] & 0xFFFF
    d["claim"] = (w[1] >> 16) & 7
    d["dest"] = (w[1] >> 19) & 0xF
    d["res1"] = (w[1] >> 23) & 0x1FF
    d["a"], d["b"], d["c"], d["dst"] = w[2], w[3], w[4], w[5]
    d["w6"] = w[6]
    d["m"], d["n"] = w[6] & 0xFFFF, (w[6] >> 16) & 0xFFFF
    d["k"] = w[7] & 0xFFFF
    d["res7"] = (w[7] >> 16) & 0xFFFF
    return d


# ----------------------------------------------------------------------------------------------- reference arithmetic
def s8(x):
    x &= 0xFF
    return x - 256 if x >= 128 else x


def s32(x):
    x &= M32
    return x - (1 << 32) if x >= (1 << 31) else x


def gemm_ref(M, N, K, A, B, C=None):
    """D = A x B (+ C).  A: M*K int8 (row major), B: K*N int8 (row major), C: M*N uint32 (row major).
    INT32 accumulation wraps modulo 2^32 (documented overflow policy).  Returns M*N uint32 words."""
    out = []
    for i in range(M):
        for j in range(N):
            acc = 0
            for k in range(K):
                acc += s8(A[i * K + k]) * s8(B[k * N + j])
            if C is not None:
                acc += s32(C[i * N + j])
            out.append(acc & M32)
    return out


def words_to_bytes(words):
    out = []
    for w in words:
        out += [(w >> (8 * i)) & 0xFF for i in range(4)]
    return out


def bytes_to_words(bs):
    return [sum(bs[4 * i + j] << (8 * j) for j in range(4)) for i in range(len(bs) // 4)]


def vec_ref(op, etype, rm, a, b=None, c=None):
    """One element of a vector operation.  Returns (result_bits, fflags)."""
    if etype == CW_ET_INT32:
        if op == CW_OP_VADD:
            return fp.iadd(a, b), 0
        if op == CW_OP_VMUL:
            return fp.imul(a, b), 0
        raise ValueError("INT32 supports VADD / VMUL only")
    if op == CW_OP_VADD:
        return fp.fadd(a, b, rm)
    if op == CW_OP_VMUL:
        return fp.fmul(a, b, rm)
    if op == CW_OP_VFMA:
        return fp.fma(a, b, c, rm)
    raise ValueError("bad vector op")


# ----------------------------------------------------------------------------------------------- validation model
def _inter(a0, al, b0, bl):
    return a0 < b0 + bl and b0 < a0 + al


def _partial(a0, al, b0, bl):
    return _inter(a0, al, b0, bl) and not (a0 == b0 and al == bl)


def validate(w, cfg, q_bound=True, q_dom=0, q_dest=0, dest_mask=0x0001, budget=0):
    """Independent re-statement of the validation precedence (docs/compute_works/02_COMMANDS.md section 4).
    Returns (status, detail, dest_is_default, ranges) where ranges is a list of (operand_id, base, length, is_write)
    the isolation check must approve (empty if the command is rejected or has no memory operands)."""
    d = decode_desc(w)
    op, et = d["op"], d["etype"]
    is_gemm, is_clear = op == CW_OP_GEMM, op == CW_OP_CLEAR
    is_vec = op in (CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA)
    is_nop = op == CW_OP_NOP

    if (not q_bound) or d["claim"] != q_dom:
        return CW_ST_OWNER, ((1 if q_bound else 0) << 3) | d["claim"], True, []
    if d["res0"] or d["res1"] or d["res7"] or (d["acc"] and not is_gemm) or \
            (is_vec and et == CW_ET_FP32 and d["rm"] > 4):
        return CW_ST_BAD_FLAGS, d["rm"], True, []
    if not (dest_mask >> d["dest"]) & 1:
        return CW_ST_BAD_DEST, d["dest"], True, []
    if op > CW_OP_LAST or (is_vec and not cfg.en_vector):
        return CW_ST_BAD_OP, op, False, []
    if not is_nop and not is_clear:
        if is_gemm:
            ok = et == CW_ET_INT8
        elif op == CW_OP_VFMA:
            ok = et == CW_ET_FP32
        else:
            ok = et == CW_ET_FP32 or (cfg.en_int32 and et == CW_ET_INT32)
        if not ok:
            return CW_ST_BAD_ETYPE, et, False, []

    m, n, k, w6 = d["m"], d["n"], d["k"], d["w6"]
    if is_gemm:
        for v, dimid in ((m, CW_DIM_M), (n, CW_DIM_N), (k, CW_DIM_K)):
            if v == 0:
                return CW_ST_BAD_DIMS, dimid, False, []
    elif is_vec and w6 == 0:
        return CW_ST_BAD_DIMS, CW_DIM_VL, False, []
    elif is_clear and w6 == 0:
        return CW_ST_BAD_DIMS, CW_DIM_LEN, False, []

    work = m * n * k if is_gemm else (w6 if (is_vec or is_clear) else 0)
    if is_gemm and k > cfg.kmax:
        return CW_ST_RESLIMIT, CW_LIM_K, False, []
    if budget and work > budget:
        return CW_ST_RESLIMIT, CW_LIM_MACS, False, []

    a, b, c, dst = d["a"], d["b"], d["c"], d["dst"]
    if is_gemm:
        la, lb, lc = m * k, k * n, m * n * 4
        ld = lc
    elif is_vec:
        la = lb = lc = ld = w6 * 4
    elif is_clear:
        la = lb = lc = 0
        ld = w6
    else:
        la = lb = lc = ld = 0

    need_c = (is_gemm and d["acc"]) or op == CW_OP_VFMA
    if (is_gemm and ((d["acc"] and c & 3) or dst & 3)) or \
       (is_vec and ((a & 3) or (b & 3) or (op == CW_OP_VFMA and c & 3) or (dst & 3))) or \
       (is_clear and ((dst & 3) or (w6 & 3))):
        if is_vec and a & 3:
            det = CW_OPND_A
        elif is_vec and b & 3:
            det = CW_OPND_B
        elif need_c and c & 3:
            det = CW_OPND_C
        else:
            det = CW_OPND_D
        return CW_ST_BAD_ALIGN, det, False, []

    ranges = []
    if is_gemm:
        ranges = [(CW_OPND_A, a, la, False), (CW_OPND_B, b, lb, False)]
        if d["acc"]:
            ranges.append((CW_OPND_C, c, lc, False))
        ranges.append((CW_OPND_D, dst, ld, True))
    elif op == CW_OP_VFMA:
        ranges = [(CW_OPND_A, a, la, False), (CW_OPND_B, b, lb, False), (CW_OPND_C, c, lc, False), (CW_OPND_D, dst, ld, True)]
    elif is_vec:
        ranges = [(CW_OPND_A, a, la, False), (CW_OPND_B, b, lb, False), (CW_OPND_D, dst, ld, True)]
    elif is_clear:
        ranges = [(CW_OPND_D, dst, ld, True)]
    for opid, base, ln, _w in ranges:
        if base < SRAM_BASE or base + ln > cfg.sram_end:
            return CW_ST_BAD_RANGE, opid, False, []
    if is_gemm:
        if _inter(dst, ld, a, la):
            return CW_ST_OVERLAP, CW_OPND_A, False, []
        if _inter(dst, ld, b, lb):
            return CW_ST_OVERLAP, CW_OPND_B, False, []
        if d["acc"] and _partial(dst, ld, c, lc):
            return CW_ST_OVERLAP, CW_OPND_C, False, []
    elif is_vec:
        if _partial(dst, ld, a, la):
            return CW_ST_OVERLAP, CW_OPND_A, False, []
        if _partial(dst, ld, b, lb):
            return CW_ST_OVERLAP, CW_OPND_B, False, []
        if op == CW_OP_VFMA and _partial(dst, ld, c, lc):
            return CW_ST_OVERLAP, CW_OPND_C, False, []
    return CW_ST_OK, 0, False, ranges


# ----------------------------------------------------------------------------------------------- script builder
def hx(v, w=0):
    return f"{v:0{w}x}"


UNK = 0xFFFFFFFF


class Tally:
    """Independent prediction of the exactly-predictable performance counters (CW_PC_*)."""

    def __init__(self):
        self.cmd_in = self.done = self.ok = self.rej = self.err = 0
        self.rej_owner = self.rej_denied = self.rej_other = 0
        self.macs = self.vec_elems = self.out_bytes = self.scrub = self.array = 0

    def completion(self, st, out):
        if st == UNK:
            return
        self.done += 1
        if st == CW_ST_OK:
            self.ok += 1
            if out != UNK:
                self.out_bytes += out
        elif st == CW_ST_MEM_ERR:
            self.err += 1
        else:
            self.rej += 1
            if st == CW_ST_OWNER:
                self.rej_owner += 1
            elif st == CW_ST_DENIED:
                self.rej_denied += 1
            else:
                self.rej_other += 1

    def expected(self):
        return {CW_PC_CMD_IN: self.cmd_in, CW_PC_CMD_DONE: self.done, CW_PC_CMD_OK: self.ok, CW_PC_CMD_REJ: self.rej,
                CW_PC_CMD_ERR: self.err, CW_PC_REJ_OWNER: self.rej_owner, CW_PC_REJ_DENIED: self.rej_denied,
                CW_PC_REJ_OTHER: self.rej_other, CW_PC_TENSOR_MACS: self.macs, CW_PC_TENSOR_ARRAY: self.array, CW_PC_VEC_ELEMS: self.vec_elems,
                CW_PC_OUT_BYTES: self.out_bytes, CW_PC_SCRUB_BYTES: self.scrub}


class Script:
    """Builds a .cwt script for tb_compute_tile.  See the header of tests/compute_works/tb_compute_tile.sv."""

    def __init__(self, name="script"):
        self.name = name
        self.lines = []
        self.nbytes_written = 0
        self.tally = Tally()
        self.perf_checkpoint = None

    def _l(self, s):
        self.lines.append(s)

    def comment(self, s):
        self._l("# " + s)

    def reset(self):
        self._l("00")

    def bm(self, op, id_, btype, start, ln, owner, rd, wr, exp=0):
        self._l(f"02 {hx(op)} {hx(id_)} {hx(btype)} {hx(start)} {hx(ln)} {hx(owner)} {hx(rd)} {hx(wr)} {hx(exp)}")

    def bm_alloc_at(self, start, ln, owner=1, rd=0b01011, wr=0b01011, btype=3, exp=0):
        self.bm(1, 0, btype, start, ln, owner, rd, wr, exp)

    def bwrite(self, addr, data):
        data = list(data)
        if not data:
            return
        self.nbytes_written += len(data)
        self._l(f"03 {hx(addr)} {hx(len(data))} " + " ".join(f"{b & 0xFF:02x}" for b in data))

    def bread(self, addr, expect):
        """expect: list of ints 0..255, or None for don't-care (0x100)."""
        expect = list(expect)
        if not expect:
            return
        self._l(f"04 {hx(addr)} {hx(len(expect))} " + " ".join("100" if e is None else f"{e & 0xFF:02x}" for e in expect))

    def bread_err(self, addr, n=8):
        self._l(f"15 {hx(addr)} {hx(n)} " + " ".join("100" for _ in range(n)))

    def submit(self, q, w):
        self.tally.cmd_in += 1
        self._l(f"05 {hx(q)} " + " ".join(hx(x) for x in w))

    def cpl(self, q=UNK, dom=UNK, dest=UNK, tag=UNK, op=UNK, st=UNK, detail=UNK, ff=UNK, out=UNK):
        self.tally.completion(st, out)
        self._l("06 " + " ".join(hx(x) for x in (q, dom, dest, tag, op, st, detail, ff, out)))

    def cpl_any(self, **kw):
        a = dict(q=UNK, dom=UNK, dest=UNK, tag=UNK, op=UNK, st=UNK, detail=UNK, ff=UNK, out=UNK)
        a.update(kw)
        self._l("10 " + " ".join(hx(a[k]) for k in ("q", "dom", "dest", "tag", "op", "st", "detail", "ff", "out")))

    def pol(self, op, idx=0, a=0, b=0, c=0, exp=0):
        self._l(f"07 {hx(op)} {hx(idx)} {hx(a)} {hx(b)} {hx(c)} {hx(exp)}")

    def delay(self, n):
        self._l(f"08 {hx(n)}")

    def clken(self, v):
        self._l(f"0a {hx(v)}")

    def nocpl(self, cycles):
        self._l(f"0d {hx(cycles)}")

    def perf(self):
        self._l("0e")
        self.perf_checkpoint = dict(self.tally.expected())

    def csr(self, addr):
        self._l(f"0f {hx(addr)}")

    def kwrite(self, addr, data):
        data = list(data)
        self._l(f"11 {hx(addr)} {hx(len(data))} " + " ".join(f"{b & 0xFF:02x}" for b in data))

    def kerrs(self, n):
        self._l(f"12 {hx(n)}")

    def cpl_dump(self, n):
        self._l(f"13 {hx(n)}")

    def cplbp(self, pct):
        self._l(f"14 {hx(pct)}")

    def mark(self, tag):
        self._l(f"16 {hx(tag)}")

    def checkstg(self, zero=1):
        self._l(f"17 {hx(zero)}")

    def bgdma(self, en, lo=0, hi=0, pct=50):
        self._l(f"18 {hx(en)} {hx(lo)} {hx(hi)} {hx(pct)}")

    def xcit(self, lo, hi, dom):
        self._l(f"19 {hx(lo)} {hx(hi)} {hx(dom)}")

    def bgstat(self, min_ops=1):
        self._l(f"1a {hx(min_ops)}")

    def checkpend(self, n):
        self._l(f"1f {hx(n)}")

    def csrw(self, addr, data):
        self._l(f"1e {hx(addr)} {hx(data)}")

    def checkgate(self, gate=UNK & 0xFF, idle=0xFF, busy=0xFF):
        self._l(f"1d {hx(gate & 0xFF)} {hx(idle & 0xFF)} {hx(busy & 0xFF)}")

    def kread(self, addr, expect):
        expect = list(expect)
        self._l(f"1c {hx(addr)} {hx(len(expect))} " + " ".join("100" if e is None else f"{e & 0xFF:02x}" for e in expect))

    def perfclear(self):
        self._l("1b")

    def end(self):
        self._l("ff")

    # ------------------------------------------------------------------------ convenience: standard bring-up
    def setup_tenant(self, cfg, dom=1, queue=0, region=0, base=None, size=None, dest_mask=0x0003, prio=0, dest=0,
                     quantum=1, budget=0, rd=1, wr=1, alloc=True):
        """IronMemory buffer over the whole local SRAM, one tenant region, queue binding, destination mask."""
        base = SRAM_BASE if base is None else base
        size = cfg.sram_bytes if size is None else size
        if alloc:
            self.bm_alloc_at(SRAM_BASE, cfg.sram_bytes)
        self.pol(CW_POL_SET_REGION, region, base, size, dom | (rd << 8) | (wr << 9), CW_PS_OK)
        self.pol(CW_POL_BIND_QUEUE, queue, dom | (prio << 4) | (dest << 8) | (1 << 12) | (quantum << 16), budget, 0, CW_PS_OK)
        self.pol(CW_POL_SET_DESTMASK, dom, dest_mask, 0, 0, CW_PS_OK)

    def text(self):
        return "\n".join(self.lines) + "\n"

    def write(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            f.write(self.text())
        return path


# ----------------------------------------------------------------------------------------------- random helpers
def rnd_i8(rng, extreme_p=0.12):
    r = rng.random()
    if r < extreme_p:
        return rng.choice([0x80, 0x7F, 0x00, 0x01, 0xFF])
    return rng.getrandbits(8)


def rnd_bytes(rng, n, extreme_p=0.12):
    return [rnd_i8(rng, extreme_p) for _ in range(n)]


# ----------------------------------------------------------------------------------------------- memory shadow model
class Mem:
    """Byte-accurate shadow of the tile's local SRAM (zero after the IronMemory init sweep)."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.b = bytearray(cfg.sram_bytes)
        self.tally = None

    def write(self, addr, data):
        o = addr - SRAM_BASE
        assert 0 <= o and o + len(data) <= len(self.b), "model write outside SRAM"
        self.b[o:o + len(data)] = bytes(x & 0xFF for x in data)

    def read(self, addr, n):
        o = addr - SRAM_BASE
        return list(self.b[o:o + n])

    def write_words(self, addr, words):
        self.write(addr, words_to_bytes(words))

    def read_words(self, addr, nwords):
        return bytes_to_words(self.read(addr, 4 * nwords))


def script_bwrite(s, mem, addr, data):
    """Write through the BridgeEngine port AND mirror into the shadow model."""
    data = [x & 0xFF for x in data]
    s.bwrite(addr, data)
    mem.write(addr, data)


def script_check_window(s, mem, addr, n, margin=16):
    """Read back [addr-margin, addr+n+margin) and compare to the shadow model (catches stray writes next to the result)."""
    lo = max(SRAM_BASE, addr - margin)
    hi = min(mem.cfg.sram_end, addr + n + margin)
    s.bread(lo, mem.read(lo, hi - lo))


def script_check_all(s, mem, chunk=1024):
    """Compare the ENTIRE local SRAM with the shadow model."""
    for off in range(0, mem.cfg.sram_bytes, chunk):
        n = min(chunk, mem.cfg.sram_bytes - off)
        s.bread(SRAM_BASE + off, mem.read(SRAM_BASE + off, n))


def bg_pattern(addr):
    """Byte pattern the background traffic generator reads / rewrites (idempotent)."""
    return ((addr * 37) + 11) & 0xFF


# ----------------------------------------------------------------------------------------------- guard / policy model
class QState:
    """Hardware-bound facts about one queue (what BIND_QUEUE programs)."""

    def __init__(self):
        self.bound = False
        self.dom = 0
        self.prio = 0
        self.dest = 0
        self.en = True
        self.quantum = 1
        self.budget = 0


class GuardModel:
    """Independent model of the management-plane policy and the range check (sf_compute_guard, MODE = 1).
    Written from the specification in the module header / docs/compute_works/05_ISOLATION.md."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.reg = [dict(valid=False, dirty=False, base=0, size=0, dom=0, rd=False, wr=False) for _ in range(cfg.nreg)]
        self.q = [QState() for _ in range(cfg.queues)]
        self.dmask = [0x0001] * 8

    # --- policy ops: return the pol_status the tile must report
    def set_region(self, idx, base, size, dom, rd, wr):
        if idx >= self.cfg.nreg:
            return CW_PS_BADIDX
        g = self.cfg.gran
        if base % g or size == 0 or size % g:
            return CW_PS_ALIGN
        if base < SRAM_BASE or base + size > self.cfg.sram_end:
            return CW_PS_RANGE
        r = self.reg[idx]
        if r["valid"]:
            return CW_PS_IN_USE
        if r["dirty"]:
            return CW_PS_NOT_CLEAN
        live = any(o["valid"] and base < o["base"] + o["size"] and o["base"] < base + size for o in self.reg)
        if live:
            return CW_PS_OVERLAP
        dirty = any(o["dirty"] and base < o["base"] + o["size"] and o["base"] < base + size for o in self.reg)
        if dirty:
            return CW_PS_NOT_CLEAN
        r.update(valid=True, base=base, size=size, dom=dom & 7, rd=bool(rd), wr=bool(wr))
        return CW_PS_OK

    def revoke(self, idx):
        if idx >= self.cfg.nreg:
            return CW_PS_BADIDX
        r = self.reg[idx]
        if not r["valid"]:
            return CW_PS_NOT_LIVE
        r["valid"] = False
        r["dirty"] = True
        return CW_PS_OK

    def scrub(self, idx, mem):
        if idx >= self.cfg.nreg:
            return CW_PS_BADIDX
        r = self.reg[idx]
        if r["valid"]:
            return CW_PS_IN_USE
        if r["dirty"]:
            mem.write(r["base"], [0] * r["size"])
            r["dirty"] = False
        return CW_PS_OK

    def bind_queue(self, idx, dom, prio, dest, en, quantum, budget):
        if idx >= self.cfg.queues:
            return CW_PS_BADIDX
        q = self.q[idx]
        q.bound, q.dom, q.prio, q.dest, q.en = True, dom & 7, prio & 3, dest & 15, bool(en)
        q.quantum = quantum if quantum else 1
        q.budget = budget
        return CW_PS_OK

    def set_destmask(self, idx, mask):
        if idx >= 8:
            return CW_PS_BADIDX
        self.dmask[idx] = (mask | 1) & 0xFFFF
        return CW_PS_OK

    # --- the range check
    def check(self, dom, base, ln, write):
        """Returns (ok, fault).  A range is permitted iff it lies inside ONE live region of the same domain with the right."""
        contains = [r for r in self.reg if r["valid"] and ln > 0 and r["base"] <= base and base + ln <= r["base"] + r["size"]]
        if not contains:
            return False, CW_GF_NOMAP
        same = [r for r in contains if r["dom"] == dom]
        if not same:
            return False, CW_GF_DOMAIN
        if any((r["wr"] if write else r["rd"]) for r in same):
            return True, CW_GF_NONE
        return False, CW_GF_PERM

    def expect(self, w, qi):
        """Complete expectation for descriptor w submitted to queue qi: (status, detail, dest, dom, ranges_checked)."""
        qs = self.q[qi]
        st, det, dflt, ranges = validate(w, self.cfg, qs.bound, qs.dom, qs.dest, self.dmask[qs.dom], qs.budget)
        if st == CW_ST_OK:
            for opid, base, ln, wr in ranges:
                ok, fault = self.check(qs.dom, base, ln, wr)
                if not ok:
                    st, det = CW_ST_DENIED, (fault << 4) | opid
                    break
        d = decode_desc(w)
        dest = (qs.dest if (self.dmask[qs.dom] >> qs.dest) & 1 else 0) if dflt else d["dest"]
        return st, det, dest, qs.dom


# ----------------------------------------------------------------------------------------------- scheduler model
class ArbModel:
    """Independent model of the local scheduler's queue arbitration (docs/compute_works/04_SCHEDULING.md):
       * eligible = non-empty and enabled; strict priority between 4 classes (3 highest);
       * round robin inside the winning class after the last winner, with a per-queue QUANTUM
         (a queue keeps the tile for up to `quantum` consecutive commands while still a candidate);
       * anti-starvation ageing: a queue that lost STARVE consecutive decisions while eligible is treated as class 3.
       One decision per command; commands are atomic (context switches happen at command boundaries only)."""

    def __init__(self, nq, prio, quantum, starve=16):
        self.nq, self.prio, self.quantum, self.starve = nq, list(prio), list(quantum), starve
        self.last, self.last_v, self.sticky = 0, False, 0
        self.wait = [0] * nq

    def pick(self, nonempty, enabled):
        elig = [nonempty[q] and enabled[q] for q in range(self.nq)]
        if not any(elig):
            return None
        cls = [3 if self.wait[q] >= self.starve else self.prio[q] for q in range(self.nq)]
        maxc = max(cls[q] for q in range(self.nq) if elig[q])
        cand = [elig[q] and cls[q] == maxc for q in range(self.nq)]
        sel = None
        if self.last_v and cand[self.last] and self.sticky < self.quantum[self.last]:
            sel = self.last
        else:
            for i in range(1, self.nq + 1):
                idx = (self.last + i) % self.nq
                if cand[idx]:
                    sel = idx
                    break
        if self.last_v and sel == self.last:
            self.sticky = min(self.sticky + 1, 31)
        else:
            self.sticky = 1
        self.last, self.last_v = sel, True
        for q in range(self.nq):
            if q == sel:
                self.wait[q] = 0
            elif elig[q]:
                self.wait[q] = min(self.wait[q] + 1, 255)
        return sel


def array_busy_model(M, N, K, rows, cols):
    """Array-busy cycles of one GEMM, from TENSORCORE 02's documented timing: each (rows x cols) output block takes
    busy = 1 + K + m + n cycles (m, n = the block's extents; MUL_PIPE = 0).  Independent of the RTL; it also pins
    down that partial edge tiles are launched with their true extents."""
    t = 0
    for mb in range((M + rows - 1) // rows):
        for nb in range((N + cols - 1) // cols):
            t += 1 + K + min(rows, M - mb * rows) + min(cols, N - nb * cols)
    return t


def tally_gemm(mem, M, N, K):
    mem.tally.macs += M * N * K
    mem.tally.array += array_busy_model(M, N, K, mem.cfg.rows, mem.cfg.cols)
