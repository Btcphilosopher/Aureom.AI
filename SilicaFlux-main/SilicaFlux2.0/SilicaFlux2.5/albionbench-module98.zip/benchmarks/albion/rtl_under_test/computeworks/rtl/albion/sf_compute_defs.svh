// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS :: sf_compute_defs.svh
// Aureom.AI / SilicaFlux Albion
//
// Single source of truth for the ComputeWorks command descriptor, completion
// status codes, policy (management) operations, fault codes and performance
// counter map.  A `define header, not a package, for the reason the sibling
// projects give (Yosys 0.33 cannot resolve package references in module
// parameter lists).  model/cw_defs.py is GENERATED from this file by
// scripts/gen_defs.py and checked for staleness by `make check`.
//
// Rules: never renumber, only append.
// =============================================================================
`ifndef SF_COMPUTE_DEFS_SVH
`define SF_COMPUTE_DEFS_SVH

// ------------------------------------------------------------ identification
`define CW_ID                32'h5346_4357   // "SFCW"
`define CW_VERSION           32'h0001_0000   // 1.0

// ------------------------------------------------------------ command descriptor
// A command is 8 little-endian 32-bit words W0..W7 (256 bits) pushed into a
// compute queue.  Words an operation does not use are ignored; RESERVED bits
// must be zero (CW_ST_BAD_FLAGS otherwise).
//
// W0  [7:0]    OP        operation (CW_OP_*)
//     [15:8]   ETYPE     element type (CW_ET_*)
//     [18:16]  RM        FP rounding mode: RNE 0, RTZ 1, RDN 2, RUP 3, RMM 4
//     [19]     ACC       GEMM: C = C_in + A*B   (INT32 accumulation into SRC_C)
//     [31:20]  reserved, must be 0
// W1  [15:0]   TAG       transaction tag, echoed in the completion record
//     [18:16]  DOM       CLAIMED security domain; must equal the queue's
//                        hardware-bound domain (the claim is never trusted)
//     [22:19]  DEST      completion destination (must be allowed for the domain)
//     [31:23]  reserved, must be 0
// W2  SRC_A    byte address of operand A
// W3  SRC_B    byte address of operand B
// W4  SRC_C    byte address of operand C (VFMA third operand; GEMM C_in if ACC)
// W5  DST      byte address of the result
// W6  [15:0]   M    GEMM rows            |  VL  vector length (elements)
//     [31:16]  N    GEMM columns         |  (CLEAR: W6 = LEN in bytes, 32 bit)
// W7  [15:0]   K    GEMM inner dimension
//     [31:16]  reserved, must be 0
//
// Memory layouts (all little endian, packed, row major):
//   GEMM   A: M x K INT8 (lda = K)   B: K x N INT8 (ldb = N)
//          C/D: M x N INT32 (ldc = N)
//   VADD / VMUL / VFMA: VL elements of 4 bytes (FP32 or INT32), contiguous.
`define CW_DESC_W            256

// ------------------------------------------------------------ operations
`define CW_OP_NOP            8'd0     // completes immediately
`define CW_OP_VADD           8'd1     // D[i] = A[i] + B[i]
`define CW_OP_VMUL           8'd2     // D[i] = A[i] * B[i]
`define CW_OP_VFMA           8'd3     // D[i] = A[i] * B[i] + C[i]  (single rounding)
`define CW_OP_GEMM           8'd4     // D = A x B (+ C)   INT8 -> INT32
`define CW_OP_CLEAR          8'd5     // zero-fill LEN bytes at DST
`define CW_OP_LAST           8'd5     // OP > LAST -> CW_ST_BAD_OP

// ------------------------------------------------------------ element types
`define CW_ET_FP32           8'd0     // supported: VADD VMUL VFMA
`define CW_ET_INT8           8'd1     // supported: GEMM
`define CW_ET_INT32          8'd2     // supported: VADD VMUL (modulo 2^32)
`define CW_ET_FP16           8'd3     // NOT implemented -> CW_ST_BAD_ETYPE
`define CW_ET_BF16           8'd4     // NOT implemented -> CW_ST_BAD_ETYPE
`define CW_ET_FP64           8'd5     // NOT implemented -> CW_ST_BAD_ETYPE
                                      // every other code is reserved -> CW_ST_BAD_ETYPE

// ------------------------------------------------------------ completion status
`define CW_ST_W              5
`define CW_ST_OK             5'd0
`define CW_ST_BAD_OP         5'd1     // reserved / unsupported operation
`define CW_ST_BAD_ETYPE      5'd2     // unsupported precision, or type illegal for the op; DETAIL = etype
`define CW_ST_BAD_DIMS       5'd3     // zero or out-of-range dimension / length; DETAIL = field id
`define CW_ST_BAD_ALIGN      5'd4     // address or length not aligned; DETAIL = operand id
`define CW_ST_BAD_RANGE      5'd5     // a buffer is not inside the local SRAM; DETAIL = operand id
`define CW_ST_OVERLAP        5'd6     // result partially overlaps an input
`define CW_ST_OWNER          5'd7     // queue unbound, or claimed DOM != bound domain; DETAIL = claimed DOM
`define CW_ST_DENIED         5'd8     // isolation check failed; DETAIL = {operand id, fault code}
`define CW_ST_BAD_DEST       5'd9     // completion destination not allowed for the domain; DETAIL = DEST
`define CW_ST_RESLIMIT       5'd10    // exceeds a tile or per-queue resource limit; DETAIL = limit id
`define CW_ST_MEM_ERR        5'd11    // local memory returned an error; DETAIL = {phase, response code}
`define CW_ST_BAD_FLAGS      5'd12    // reserved descriptor bits set

// operand ids used in DETAIL fields
`define CW_OPND_A            4'd1
`define CW_OPND_B            4'd2
`define CW_OPND_C            4'd3
`define CW_OPND_D            4'd4
// dimension ids (CW_ST_BAD_DIMS)
`define CW_DIM_M             4'd1
`define CW_DIM_N             4'd2
`define CW_DIM_K             4'd3
`define CW_DIM_VL            4'd4
`define CW_DIM_LEN           4'd5
// resource-limit ids (CW_ST_RESLIMIT)
`define CW_LIM_K             4'd1     // K larger than the operand staging buffers hold
`define CW_LIM_VL            4'd2     // reserved
`define CW_LIM_MACS          4'd3     // per-queue MAC budget per command
// execution phase ids (CW_ST_MEM_ERR)
`define CW_PH_LOAD_A         4'd1
`define CW_PH_LOAD_B         4'd2
`define CW_PH_LOAD_C         4'd3
`define CW_PH_STORE          4'd4
`define CW_PH_CLEAR          4'd5

// ------------------------------------------------------------ isolation fault codes
// Numbering is identical to Meridian (P83) sf_meridian_pkg F_* so a real Citadel
// can return the same codes.
`define CW_GF_NONE           4'd0
`define CW_GF_NOMAP          4'd1     // no region contains the whole range
`define CW_GF_PERM           4'd2     // region found, right (read / write) missing
`define CW_GF_DOMAIN         4'd3     // region belongs to another domain
`define CW_GF_PRIV           4'd4     // reserved (Meridian F_PRIV)
`define CW_GF_CITTMO         4'd6     // external Citadel did not answer (fail closed)

// ------------------------------------------------------------ policy (management) operations
// Reachable from the management plane only (Keystone).  Accepted only while the
// tile is quiescent (no command between dispatch and completion).
`define CW_POL_NOP           4'd0
`define CW_POL_SET_REGION    4'd1     // idx; a = base; b = size; c[2:0] = domain, c[8] = rd, c[9] = wr
`define CW_POL_REVOKE        4'd2     // idx; region becomes DIRTY until scrubbed
`define CW_POL_SCRUB         4'd3     // idx; zero-fill a revoked region, then it is CLEAN
`define CW_POL_BIND_QUEUE    4'd4     // idx = queue; a[2:0] domain, a[5:4] priority, a[11:8] default dest,
                                      //   a[12] enable, a[19:16] RR quantum (0 -> 1); b = MAC budget (0 = none)
`define CW_POL_SET_DESTMASK  4'd5     // idx = domain; a[15:0] = allowed completion destinations

`define CW_PS_OK             4'd0
`define CW_PS_BADIDX         4'd1
`define CW_PS_ALIGN          4'd2     // region base/size not multiple of the region granule, or size 0
`define CW_PS_RANGE          4'd3     // region outside the local SRAM
`define CW_PS_OVERLAP        4'd4     // overlaps a live or dirty region
`define CW_PS_NOT_CLEAN      4'd5     // entry (or range) was revoked and not scrubbed
`define CW_PS_IN_USE         4'd6     // SET on a live entry (REVOKE first) / SCRUB on a live entry
`define CW_PS_NOT_LIVE       4'd7     // REVOKE on an entry that is not live
`define CW_PS_BADARG         4'd8
`define CW_PS_MEM_ERR        4'd9     // scrub could not complete (memory error)
`define CW_PS_UNSUPPORTED    4'd10    // region ops when an external Citadel owns the policy

// ------------------------------------------------------------ element-operation encodings used
// (hpc_vector_pkg encodings of Module 02, reproduced here so the decoder needs no package)
`define CW_VOP_FADD          5'h01
`define CW_VOP_FMUL          5'h03
`define CW_VOP_FMADD         5'h04
`define CW_VOP_IADD          5'h10
`define CW_VOP_IMUL          5'h11

// ------------------------------------------------------------ engine job kinds (memory adapter)
`define CW_JK_READ2D         2'd0
`define CW_JK_WRITE2D        2'd1
`define CW_JK_FILL0          2'd2

// ------------------------------------------------------------ scheduling
`define CW_PRIO_W            2        // 4 priority classes, 3 = highest

// ------------------------------------------------------------ performance counters (sf_compute_perf)
// perf_val = counter[perf_sel]; all counters are 40-bit and saturate; perf_clear zeroes them.
`define CW_PC_CYCLES         0   // clock cycles since clear
`define CW_PC_CLKEN_CYCLES   1   // cycles with clk_en_i = 1
`define CW_PC_BUSY           2   // cycles a command is between dispatch and completion
`define CW_PC_CMD_IN         3   // descriptors accepted into a queue
`define CW_PC_CMD_DONE       4   // completion records handed over
`define CW_PC_CMD_OK         5   // ... with status OK
`define CW_PC_CMD_REJ        6   // ... rejected before execution (validation / ownership / isolation)
`define CW_PC_CMD_ERR        7   // ... failed during execution (CW_ST_MEM_ERR)
`define CW_PC_QWAIT_SUM      8   // sum of (dispatch - enqueue) cycles
`define CW_PC_QWAIT_MAX      9   // maximum of the same
`define CW_PC_EXEC_SUM       10  // sum of (completion pushed - dispatch) cycles
`define CW_PC_EXEC_MAX       11  // maximum of the same
`define CW_PC_OVERHEAD       12  // busy cycles in validate / check / dispatch / complete (no data phase)
`define CW_PC_PH_LOAD        13  // busy cycles in operand load phases
`define CW_PC_PH_COMPUTE     14  // busy cycles in tensor / vector compute phases
`define CW_PC_PH_STORE       15  // busy cycles in result store phases
`define CW_PC_TENSOR_MACS    16  // useful INT8 MACs (M*N*K) of completed GEMMs
`define CW_PC_TENSOR_ARRAY   17  // array busy cycles (TC02 perf_busy) summed over launches
`define CW_PC_TENSOR_PEAK    18  // ROWS*COLS * (command cycles of GEMMs): the MAC-slot denominator
`define CW_PC_VEC_ELEMS      19  // useful vector elements of completed vector commands
`define CW_PC_VEC_PEAK       20  // NUM_LANES * (command cycles of vector commands)
`define CW_PC_VEC_ACTIVE     21  // cycles the vector array was busy
`define CW_PC_MEM_RD_WORDS   22  // word reads issued to local memory by the engines
`define CW_PC_MEM_WR_WORDS   23  // word writes issued to local memory by the engines
`define CW_PC_MEM_STALL      24  // engine-cycles with a request waiting for local memory (conflicts + backpressure)
`define CW_PC_MEM_ERR_RSP    25  // error responses from local memory
`define CW_PC_OUT_BYTES      26  // result bytes written by completed commands
`define CW_PC_REJ_OWNER      27  // rejects: ownership
`define CW_PC_REJ_DENIED     28  // rejects: isolation check
`define CW_PC_REJ_OTHER      29  // rejects: all other validation
`define CW_PC_SCRUB_BYTES    30  // bytes zero-filled by CLEAR / SCRUB
`define CW_PC_STALL_CPL      31  // cycles a finished command waited for the completion queue
`define CW_PC_DROP_BADQ       32  // descriptors dropped: queue id out of range
`define CW_PC_N              33

`endif
