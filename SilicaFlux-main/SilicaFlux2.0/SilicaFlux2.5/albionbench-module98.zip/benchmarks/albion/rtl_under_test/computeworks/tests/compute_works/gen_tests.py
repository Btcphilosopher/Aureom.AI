#!/usr/bin/env python3
"""Test-script generators for the ComputeWorks tile.  Every expected value comes from model/ (independent of the RTL).

Each generator returns a Script; scripts are written to build/tests/<name>.cwt and run by scripts/run_tests.py.
"""
import os
import random
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "model"))
from cwlib import *          # noqa: E402,F401,F403

SLOT = 2048          # byte slot used by the standard layout (A, B, C, D, ... in consecutive slots)


def slot(cfg, i):
    return SRAM_BASE + i * (cfg.sram_bytes // 8)


def do_gemm(s, mem, cfg, rng, M, N, K, acc=0, dom=1, q=0, tag=None, dest=0, offs=(0, 0, 0, 0), inplace=False,
            a_data=None, b_data=None, c_data=None, dst=None, check="window"):
    """Write operands, submit one GEMM, expect OK, check the result against the model.  Returns D words."""
    a_addr = slot(cfg, 0) + offs[0]
    b_addr = slot(cfg, 1) + offs[1]
    c_addr = slot(cfg, 2) + 4 * offs[2]
    d_addr = c_addr if (inplace and acc) else (slot(cfg, 3) + 4 * offs[3] if dst is None else dst)
    A = a_data if a_data is not None else rnd_bytes(rng, M * K)
    B = b_data if b_data is not None else rnd_bytes(rng, K * N)
    C = c_data if c_data is not None else [rng.getrandbits(32) for _ in range(M * N)]
    script_bwrite(s, mem, a_addr, A)
    script_bwrite(s, mem, b_addr, B)
    if acc:
        script_bwrite(s, mem, c_addr, words_to_bytes(C))
    tag = rng.getrandbits(16) if tag is None else tag
    w = pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, acc, tag, dom, dest, a_addr, b_addr, c_addr, d_addr, M, N, K)
    st, det, _dd, _r = validate(w, cfg, True, dom, 0, 0xFFFF, 0)
    assert st == CW_ST_OK, f"generator produced an invalid GEMM: status {st} detail {det}"
    s.submit(q, w)
    D = gemm_ref(M, N, K, A, B, C if acc else None)
    tally_gemm(mem, M, N, K)
    s.cpl(q=q, dom=dom, dest=dest, tag=tag, op=CW_OP_GEMM, st=CW_ST_OK, detail=0, ff=0, out=4 * M * N)
    mem.write_words(d_addr, D)
    if check == "window":
        script_check_window(s, mem, d_addr, 4 * M * N)
    return D


def new_script(name, cfg):
    s = Script(name)
    s.reset()
    return s


def attach(s, mem):
    mem.tally = s.tally
    return mem


# --------------------------------------------------------------------------------------------- suites
def suite_p1_single(cfg, seed=1):
    """The brief's required first step: ONE 4x4 INT8 tensor operation, checked three ways."""
    rng = random.Random(seed)
    s = new_script("p1_single", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg)
    # (1) A x I = A with a non-symmetric A: catches any operand-order or transpose mistake
    A = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    I = [1 if i == j else 0 for i in range(4) for j in range(4)]
    do_gemm(s, mem, cfg, rng, 4, 4, 4, a_data=A, b_data=I, tag=0x1001)
    # (2) I x B = B
    do_gemm(s, mem, cfg, rng, 4, 4, 4, a_data=I, b_data=A, tag=0x1002)
    # (3) A x B for non-commuting, signed operands (A x B != B x A and != A x B^T)
    A2 = [(-1) & 0xFF, 2, 0x80, 3, 5, (-7) & 0xFF, 0x7F, 1, 0, 9, (-2) & 0xFF, 4, 6, (-6) & 0xFF, 8, (-128) & 0xFF]
    B2 = [3, 0x80, 1, 2, (-4) & 0xFF, 5, 0x7F, 0, 2, (-3) & 0xFF, 6, 1, 0x7F, 0x7F, (-5) & 0xFF, 2]
    D = do_gemm(s, mem, cfg, rng, 4, 4, 4, a_data=A2, b_data=B2, tag=0x1003)
    assert D != gemm_ref(4, 4, 4, B2, A2), "test vector must distinguish A*B from B*A"
    script_check_all(s, mem)
    s.end()
    return s


def suite_p1_gemm(cfg, seed=1, n=40):
    """Randomised INT8 GEMM campaign: partial tiles, extremes, K up to the staging limit, accumulation, unaligned A/B."""
    rng = random.Random(seed)
    s = new_script("p1_gemm", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg)
    cap = cfg.sram_bytes // 8           # one slot
    for t in range(n):
        kind = rng.random()
        if kind < 0.15:                 # exactly one tile
            M, N, K = cfg.rows, cfg.cols, rng.randint(1, 24)
        elif kind < 0.30:               # tiny
            M, N, K = rng.randint(1, 3), rng.randint(1, 3), rng.randint(1, 8)
        elif kind < 0.40:               # K at the staging limit
            K = cfg.kmax
            M, N = rng.randint(1, 3), rng.randint(1, 3)
        else:                           # general, partial edge tiles
            M, N, K = rng.randint(1, 11), rng.randint(1, 11), rng.randint(1, 30)
        while M * K > cap - 8 or K * N > cap - 8 or 4 * M * N > cap - 8:
            M, N = max(1, M - 1), max(1, N - 1)
        acc = 1 if rng.random() < 0.35 else 0
        inplace = acc and rng.random() < 0.3
        offs = (rng.randint(0, 3), rng.randint(0, 3), rng.randint(0, 2), rng.randint(0, 2))   # byte-unaligned A / B
        do_gemm(s, mem, cfg, rng, M, N, K, acc=acc, offs=offs, inplace=inplace, tag=t + 1)
    script_check_all(s, mem)
    s.perf()
    s.end()
    return s


def suite_p1_overflow(cfg, seed=1):
    """INT32 accumulation overflow policy: the accumulator WRAPS modulo 2^32 (no saturation, no flag)."""
    rng = random.Random(seed)
    s = new_script("p1_overflow", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg)
    K = cfg.kmax
    # (-128)*(-128) = 16384 per product; K products stay far below 2^31, so build the wrap with the C_in path:
    M, N = 2, 2
    A = [0x80] * (M * K)
    B = [0x80] * (K * N)
    big = 0x7FFFFFF0
    C = [big, (-0x7FFFFFF0) & M32, 0xFFFFFFFF, 0x80000000]
    D = do_gemm(s, mem, cfg, rng, M, N, K, acc=1, a_data=A, b_data=B, c_data=C, tag=0x2001)
    exp0 = (K * 16384 + big) & M32
    assert D[0] == exp0 and exp0 < big or True
    # extreme single product and sign handling
    do_gemm(s, mem, cfg, rng, 1, 1, 1, a_data=[0x80], b_data=[0x80], tag=0x2002)            # (-128)*(-128)
    do_gemm(s, mem, cfg, rng, 1, 1, 1, a_data=[0x80], b_data=[0x7F], tag=0x2003)            # (-128)*127
    do_gemm(s, mem, cfg, rng, 1, 1, 1, a_data=[0x7F], b_data=[0x7F], tag=0x2004)            # 127*127
    # C_in at the INT32 edge: 0x7FFFFFFF + 1 wraps to 0x80000000
    do_gemm(s, mem, cfg, rng, 1, 1, 1, acc=1, a_data=[1], b_data=[1], c_data=[0x7FFFFFFF], tag=0x2005)
    script_check_all(s, mem)
    s.end()
    return s



# ----------------------------------------------------------------------------------------- vector helpers
SPECIAL32 = [0x00000000, 0x80000000, 0x3F800000, 0xBF800000, 0x40000000, 0x7F800000, 0xFF800000, 0x7FC00000,
             0xFFC00000, 0x7F800001, 0xFF800001, 0x7FA00000, 0x00000001, 0x80000001, 0x007FFFFF, 0x807FFFFF,
             0x00800000, 0x80800000, 0x7F7FFFFF, 0xFF7FFFFF, 0x3F000000, 0x33800000, 0x4B000000, 0x7E800000]


def rnd_fp32(rng, special_p=0.18):
    r = rng.random()
    if r < special_p:
        return rng.choice(SPECIAL32)
    if r < special_p + 0.12:                     # subnormal / tiny exponents
        return (rng.getrandbits(1) << 31) | (rng.randrange(0, 4) << 23) | rng.getrandbits(23)
    if r < special_p + 0.2:                      # huge exponents (overflow candidates)
        return (rng.getrandbits(1) << 31) | (rng.randrange(250, 255) << 23) | rng.getrandbits(23)
    if r < special_p + 0.3:                      # close to 1.0: cancellation in add / fma
        return (rng.getrandbits(1) << 31) | (rng.randrange(125, 130) << 23) | rng.getrandbits(23)
    return rng.getrandbits(32)


def vec_expected(op, etype, rm, A, B, C):
    out, ff = [], 0
    for i in range(len(A)):
        r, f = vec_ref(op, etype, rm, A[i], B[i], C[i] if C is not None else None)
        out.append(r)
        ff |= f
    return out, ff


def do_vec(s, mem, cfg, rng, op, etype, rm, VL, A=None, B=None, C=None, inplace=None, tag=None, dom=1, q=0, dest=0,
           gen=None):
    """Submit one vector op; expect OK with the exact FFLAGS; check D (and its neighbourhood) against the model."""
    gen = gen or rnd_fp32
    a_addr, b_addr, c_addr, d_addr = slot(cfg, 0), slot(cfg, 1), slot(cfg, 2), slot(cfg, 3)
    if etype == CW_ET_INT32:
        gen = lambda r: r.getrandbits(32)
    A = A if A is not None else [gen(rng) for _ in range(VL)]
    B = B if B is not None else [gen(rng) for _ in range(VL)]
    C = C if C is not None else ([gen(rng) for _ in range(VL)] if op == CW_OP_VFMA else None)
    script_bwrite(s, mem, a_addr, words_to_bytes(A))
    script_bwrite(s, mem, b_addr, words_to_bytes(B))
    if C is not None:
        script_bwrite(s, mem, c_addr, words_to_bytes(C))
    if inplace == "a":
        d_addr = a_addr
    elif inplace == "b":
        d_addr = b_addr
    elif inplace == "c" and C is not None:
        d_addr = c_addr
    tag = rng.getrandbits(16) if tag is None else tag
    w = pack_desc(op, etype, rm, 0, tag, dom, dest, a_addr, b_addr, c_addr, d_addr, w6=VL)
    st, det, _dd, _r = validate(w, cfg, True, dom, 0, 0xFFFF, 0)
    assert st == CW_ST_OK, f"generator produced an invalid vector op: status {st} detail {det}"
    s.submit(q, w)
    D, ff = vec_expected(op, etype, rm, A, B, C)
    mem.tally.vec_elems += VL
    s.cpl(q=q, dom=dom, dest=dest, tag=tag, op=op, st=CW_ST_OK, detail=0, ff=ff, out=4 * VL)
    mem.write_words(d_addr, D)
    script_check_window(s, mem, d_addr, 4 * VL)
    return D, ff


def suite_p2_fp32(cfg, seed=1, n=60):
    """FP32 VADD / VMUL / VFMA: random corner-biased data, all five rounding modes, odd lengths, multi-chunk."""
    rng = random.Random(seed)
    s = new_script("p2_fp32", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg)
    chunk = cfg.stg // 4
    slot_words = cfg.sram_bytes // 8 // 4
    for t in range(n):
        op = rng.choice([CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA])
        rm = rng.randrange(0, 5)
        r = rng.random()
        if r < 0.15:
            VL = rng.randint(1, cfg.num_lanes)                    # fewer than one beat
        elif r < 0.30:
            VL = cfg.num_lanes * rng.randint(1, 6)                # exact beats
        elif r < 0.45:
            VL = min(slot_words, chunk + rng.randint(-2, 40))     # straddles the chunk boundary
        else:
            VL = rng.randint(1, 70)
        VL = max(1, min(VL, slot_words))
        inplace = rng.choice([None, None, None, "a", "b"] + (["c"] if op == CW_OP_VFMA else []))
        do_vec(s, mem, cfg, rng, op, CW_ET_FP32, rm, VL, inplace=inplace, tag=t + 1)
    script_check_all(s, mem)
    s.perf()
    s.end()
    return s


def suite_p2_special(cfg, seed=1):
    """Directed FP32 special values: every pair of the special list through add / mul / fma, all rounding modes."""
    rng = random.Random(seed)
    s = new_script("p2_special", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg)
    vals = SPECIAL32
    pairs = [(a, b) for a in vals for b in vals]
    rng.shuffle(pairs)
    # one command per (op, rm), VL = number of pairs that fit
    per = min(len(pairs), cfg.sram_bytes // 8 // 4)
    for op in (CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA):
        for rm in range(5):
            sel = [pairs[(i + 7 * rm + 13 * op) % len(pairs)] for i in range(per)]
            A = [p[0] for p in sel]
            B = [p[1] for p in sel]
            C = [rng.choice(vals) for _ in sel] if op == CW_OP_VFMA else None
            do_vec(s, mem, cfg, rng, op, CW_ET_FP32, rm, per, A=A, B=B, C=C, tag=(op << 4) | rm)
    script_check_all(s, mem)
    s.end()
    return s


def suite_p2_int32(cfg, seed=1, n=20):
    """INT32 VADD / VMUL (modulo 2^32): the INT32 accumulation path of the vector engine."""
    rng = random.Random(seed)
    s = new_script("p2_int32", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg)
    for t in range(n):
        op = rng.choice([CW_OP_VADD, CW_OP_VMUL])
        VL = rng.randint(1, 90)
        A = [rng.choice([0, 1, 0x7FFFFFFF, 0x80000000, 0xFFFFFFFF, rng.getrandbits(32), rng.getrandbits(32)]) for _ in range(VL)]
        B = [rng.choice([0, 1, 0x7FFFFFFF, 0x80000000, 0xFFFFFFFF, rng.getrandbits(32), rng.getrandbits(32)]) for _ in range(VL)]
        do_vec(s, mem, cfg, rng, op, CW_ET_INT32, 0, VL, A=A, B=B, inplace=rng.choice([None, "a"]), tag=t + 1)
    script_check_all(s, mem)
    s.end()
    return s


def suite_p2_mixed(cfg, seed=1, n=30):
    """Mixed workload: INT8 GEMMs and FP32 / INT32 vector ops interleaved in one stream (shared staging and engines)."""
    rng = random.Random(seed)
    s = new_script("p2_mixed", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg)
    cap = cfg.sram_bytes // 8
    for t in range(n):
        k = rng.random()
        if k < 0.4:
            M, N, K = rng.randint(1, 9), rng.randint(1, 9), rng.randint(1, 20)
            do_gemm(s, mem, cfg, rng, M, N, K, acc=rng.random() < 0.3, offs=(rng.randint(0, 3), rng.randint(0, 3), 0, 0), tag=t + 1)
        elif k < 0.8:
            do_vec(s, mem, cfg, rng, rng.choice([CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA]), CW_ET_FP32, rng.randrange(0, 5),
                   rng.randint(1, 60), tag=t + 1)
        else:
            do_vec(s, mem, cfg, rng, rng.choice([CW_OP_VADD, CW_OP_VMUL]), CW_ET_INT32, 0, rng.randint(1, 60), tag=t + 1)
    script_check_all(s, mem)
    s.perf()
    s.end()
    return s



# ------------------------------------------------------------------------------------------ model of execution
def model_exec(mem, cfg, w):
    """Apply a VALIDATED command to the shadow memory.  Returns (out_bytes, fflags)."""
    d = decode_desc(w)
    op, et = d["op"], d["etype"]
    if op == CW_OP_NOP:
        return 0, 0
    if op == CW_OP_CLEAR:
        n = d["w6"]
        mem.write(d["dst"], [0] * n)
        mem.tally.scrub += n
        return n, 0
    if op == CW_OP_GEMM:
        M, N, K = d["m"], d["n"], d["k"]
        A, B = mem.read(d["a"], M * K), mem.read(d["b"], K * N)
        C = mem.read_words(d["c"], M * N) if d["acc"] else None
        mem.write_words(d["dst"], gemm_ref(M, N, K, A, B, C))
        tally_gemm(mem, M, N, K)
        return 4 * M * N, 0
    VL = d["w6"]
    A, B = mem.read_words(d["a"], VL), mem.read_words(d["b"], VL)
    C = mem.read_words(d["c"], VL) if op == CW_OP_VFMA else None
    D, ff = vec_expected(op, et, d["rm"], A, B, C)
    mem.write_words(d["dst"], D)
    mem.tally.vec_elems += VL
    return 4 * VL, ff


def rand_addr(rng, cfg, nbytes, align=1):
    hi = cfg.sram_end - nbytes
    a = SRAM_BASE + rng.randint(0, hi - SRAM_BASE)
    return a - (a % align)


def fuzz_desc(rng, cfg, dom, dest_ok=(0, 1)):
    """A random descriptor: mostly well-formed, with targeted corruptions."""
    op = rng.choice([CW_OP_NOP, CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA, CW_OP_GEMM, CW_OP_GEMM, CW_OP_CLEAR, CW_OP_VADD, CW_OP_VFMA])
    et = {CW_OP_VADD: CW_ET_FP32, CW_OP_VMUL: CW_ET_FP32, CW_OP_VFMA: CW_ET_FP32, CW_OP_GEMM: CW_ET_INT8, CW_OP_CLEAR: 0, CW_OP_NOP: 0}[op]
    if op in (CW_OP_VADD, CW_OP_VMUL) and rng.random() < 0.25:
        et = CW_ET_INT32
    rm = rng.randrange(0, 5)
    acc = 1 if (op == CW_OP_GEMM and rng.random() < 0.4) else 0
    tag = rng.getrandbits(16)
    claim = dom
    dest = rng.choice(dest_ok)
    M, N, K = rng.randint(1, 10), rng.randint(1, 10), rng.randint(1, 36)
    VL = rng.randint(1, 70)
    LEN = 4 * rng.randint(1, 40)
    if op == CW_OP_GEMM:
        la, lb, lc = M * K, K * N, 4 * M * N
    elif op == CW_OP_CLEAR:
        la = lb = lc = 0
    else:
        la = lb = lc = 4 * VL
    ld = lc if op == CW_OP_GEMM else (LEN if op == CW_OP_CLEAR else 4 * VL)
    al = 1 if op == CW_OP_GEMM else 4
    a = rand_addr(rng, cfg, max(la, 1), al)
    b = rand_addr(rng, cfg, max(lb, 1), al)
    c = rand_addr(rng, cfg, max(lc, 1), 4)
    d = rand_addr(rng, cfg, max(ld, 1), 4)
    w6 = None
    if op in (CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA):
        w6 = VL
    elif op == CW_OP_CLEAR:
        w6 = LEN
    res0 = res1 = res7 = 0
    # ---- result placement: often make it disjoint or exactly in place, sometimes overlap on purpose
    pl = rng.random()
    if op in (CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA) and pl < 0.2:
        d = a
    elif op in (CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA) and pl < 0.3:
        d = a + 4 * rng.randint(1, 3)                     # partial overlap -> OVERLAP unless it runs out of range
    elif op == CW_OP_GEMM and pl < 0.15 and acc:
        d = c
    elif op == CW_OP_GEMM and pl < 0.3:
        d = b + 4 * rng.randint(0, 3)                     # result overlaps B -> OVERLAP
    # ---- targeted corruption
    if rng.random() < 0.55:
        k = rng.randrange(0, 18)
        if k == 0:   op = rng.choice([6, 7, 8, 0x40, 0x80, 0xFF])
        elif k == 1: et = rng.choice([CW_ET_FP16, CW_ET_BF16, CW_ET_FP64, 6, 7, 0x10, 0xFF])
        elif k == 2: et = rng.choice([CW_ET_FP32, CW_ET_INT8, CW_ET_INT32])                         # maybe wrong for the op
        elif k == 3: rm = rng.choice([5, 6, 7])
        elif k == 4: res0 = rng.randint(1, 0xFFF)
        elif k == 5: res1 = rng.randint(1, 0x1FF)
        elif k == 6: res7 = rng.randint(1, 0xFFFF)
        elif k == 7: acc = 1
        elif k == 8: M = rng.choice([0, 0]); N = rng.choice([0, N]); K = rng.choice([0, K])
        elif k == 9: K = cfg.kmax + rng.randint(1, 5)
        elif k == 10: w6 = rng.choice([0, 0xFFFFFFF, 0x7FFFFFFF, 0xFFFFFFFF]) if w6 is not None else w6
        elif k == 11: a += rng.randint(1, 3); b += rng.randint(1, 3); c += rng.randint(1, 3); d += rng.randint(1, 3)
        elif k == 12: d = cfg.sram_end - rng.randint(0, 12)                                         # at / over the end
        elif k == 13: a = SRAM_BASE - rng.randint(1, 64)
        elif k == 14: dest = rng.choice([2, 3, 7, 15])
        elif k == 15: claim = (dom + rng.randint(1, 7)) & 7
        elif k == 16: b = cfg.sram_end - rng.randint(0, 8)
        elif k == 17: c = cfg.sram_end + rng.randint(0, 100)
    if op == CW_OP_GEMM:
        return pack_desc(op, et, rm, acc, tag, claim, dest, a, b, c, d, M, N, K, res0=res0, res1=res1, res7=res7)
    return pack_desc(op, et, rm, acc, tag, claim, dest, a, b, c, d, M, N, K, w6=w6, res0=res0, res1=res1, res7=res7)


def suite_p3_validate(cfg, seed=1, n=220):
    """Descriptor validation fuzz against the independent Python validator.  Rejected commands must have NO side
    effect (full-SRAM compare); accepted ones must compute correctly from arbitrary memory contents."""
    rng = random.Random(seed)
    s = new_script("p3_validate", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg, dest_mask=0x0003)
    img = [rng.getrandbits(8) for _ in range(cfg.sram_bytes)]
    for off in range(0, cfg.sram_bytes, 1024):
        script_bwrite(s, mem, SRAM_BASE + off, img[off:off + 1024])
    counts = {}
    for t in range(n):
        w = fuzz_desc(rng, cfg, 1)
        st, det, dflt, _rg = validate(w, cfg, True, 1, 0, 0x0003, 0)
        s.submit(0, w)
        d = decode_desc(w)
        out, ff = 0, 0
        if st == CW_ST_OK:
            out, ff = model_exec(mem, cfg, w)
        counts[st] = counts.get(st, 0) + 1
        dest = 0 if dflt else d["dest"]
        s.cpl(q=0, dom=1, dest=dest, tag=d["tag"], op=d["op"], st=st, detail=det, ff=ff, out=out)
        if t % 6 == 5:
            script_check_all(s, mem)
    script_check_all(s, mem)
    s.perf()
    s.end()
    s.coverage = counts
    return s


def suite_p3_reject_table(cfg, seed=1):
    """One directed command for EVERY rejection status and every unsupported precision, checking status AND detail."""
    rng = random.Random(seed)
    s = new_script("p3_reject_table", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg, dest_mask=0x0003)
    for off in range(0, cfg.sram_bytes, 1024):
        script_bwrite(s, mem, SRAM_BASE + off, [rng.getrandbits(8) for _ in range(1024)])
    a, b, c, d = slot(cfg, 0), slot(cfg, 1), slot(cfg, 2), slot(cfg, 3)
    cases = []
    # unsupported precisions: FP16, BF16, FP64 and reserved codes must be REJECTED for every op that takes a type
    for etn, et in (("FP16", CW_ET_FP16), ("BF16", CW_ET_BF16), ("FP64", CW_ET_FP64), ("rsv6", 6), ("rsv255", 255)):
        for op in (CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA):
            cases.append((f"{etn} on {op}", pack_desc(op, et, 0, 0, 0x100 + len(cases), 1, 0, a, b, c, d, w6=8)))
        cases.append((f"{etn} on GEMM", pack_desc(CW_OP_GEMM, et, 0, 0, 0x100 + len(cases), 1, 0, a, b, c, d, 2, 2, 2)))
    cases += [
        ("INT8 on VADD", pack_desc(CW_OP_VADD, CW_ET_INT8, 0, 0, 0x200, 1, 0, a, b, c, d, w6=4)),
        ("FP32 on GEMM", pack_desc(CW_OP_GEMM, CW_ET_FP32, 0, 0, 0x201, 1, 0, a, b, c, d, 2, 2, 2)),
        ("INT32 on GEMM", pack_desc(CW_OP_GEMM, CW_ET_INT32, 0, 0, 0x202, 1, 0, a, b, c, d, 2, 2, 2)),
        ("INT32 on VFMA", pack_desc(CW_OP_VFMA, CW_ET_INT32, 0, 0, 0x203, 1, 0, a, b, c, d, w6=4)),
        ("reserved op 6", pack_desc(6, 0, 0, 0, 0x204, 1, 0, a, b, c, d)),
        ("reserved op 255", pack_desc(255, 0, 0, 0, 0x205, 1, 0, a, b, c, d)),
        ("M=0", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x206, 1, 0, a, b, c, d, 0, 2, 2)),
        ("N=0", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x207, 1, 0, a, b, c, d, 2, 0, 2)),
        ("K=0", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x208, 1, 0, a, b, c, d, 2, 2, 0)),
        ("VL=0", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x209, 1, 0, a, b, c, d, w6=0)),
        ("CLEAR len 0", pack_desc(CW_OP_CLEAR, 0, 0, 0, 0x20A, 1, 0, 0, 0, 0, d, w6=0)),
        ("K > KMAX", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x20B, 1, 0, a, b, c, d, 1, 1, cfg.kmax + 1)),
        ("A misaligned VADD", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x20C, 1, 0, a + 1, b, c, d, w6=4)),
        ("B misaligned VADD", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x20D, 1, 0, a, b + 2, c, d, w6=4)),
        ("C misaligned VFMA", pack_desc(CW_OP_VFMA, CW_ET_FP32, 0, 0, 0x20E, 1, 0, a, b, c + 3, d, w6=4)),
        ("D misaligned GEMM", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x20F, 1, 0, a, b, c, d + 1, 2, 2, 2)),
        ("C misaligned GEMM acc", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 1, 0x210, 1, 0, a, b, c + 2, d, 2, 2, 2)),
        ("CLEAR len not x4", pack_desc(CW_OP_CLEAR, 0, 0, 0, 0x211, 1, 0, 0, 0, 0, d, w6=6)),
        ("A below SRAM", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x212, 1, 0, SRAM_BASE - 4, b, c, d, w6=4)),
        ("D one byte over the end", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x213, 1, 0, a, b, c, cfg.sram_end - 12, w6=4)),
        ("D exactly at the end (ok)", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x214, 1, 0, a, b, c, cfg.sram_end - 16, w6=4)),
        # boundary of the SRAM for every operand: ending exactly at the end is accepted, one word further is refused
        ("VFMA A exactly at the end (ok)", pack_desc(CW_OP_VFMA, CW_ET_FP32, 0, 0, 0x240, 1, 0, cfg.sram_end - 16, b, c, d, w6=4)),
        ("VFMA A one word over the end", pack_desc(CW_OP_VFMA, CW_ET_FP32, 0, 0, 0x241, 1, 0, cfg.sram_end - 12, b, c, d, w6=4)),
        ("VFMA B exactly at the end (ok)", pack_desc(CW_OP_VFMA, CW_ET_FP32, 0, 0, 0x242, 1, 0, a, cfg.sram_end - 16, c, d, w6=4)),
        ("VFMA B one word over the end", pack_desc(CW_OP_VFMA, CW_ET_FP32, 0, 0, 0x243, 1, 0, a, cfg.sram_end - 12, c, d, w6=4)),
        ("VFMA C exactly at the end (ok)", pack_desc(CW_OP_VFMA, CW_ET_FP32, 0, 0, 0x244, 1, 0, a, b, cfg.sram_end - 16, d, w6=4)),
        ("VFMA C one word over the end", pack_desc(CW_OP_VFMA, CW_ET_FP32, 0, 0, 0x245, 1, 0, a, b, cfg.sram_end - 12, d, w6=4)),
        ("GEMM A exactly at the end (ok)", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x246, 1, 0, cfg.sram_end - 8, b, c, d, 2, 2, 4)),
        ("GEMM A one byte over the end", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x247, 1, 0, cfg.sram_end - 7, b, c, d, 2, 2, 4)),
        ("GEMM B exactly at the end (ok)", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x248, 1, 0, a, cfg.sram_end - 8, c, d, 2, 2, 4)),
        ("GEMM B one byte over the end", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x249, 1, 0, a, cfg.sram_end - 7, c, d, 2, 2, 4)),
        ("GEMM C_in exactly at the end (ok)", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 1, 0x24A, 1, 0, a, b, cfg.sram_end - 16, d, 2, 2, 4)),
        ("GEMM C_in one word over the end", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 1, 0x24B, 1, 0, a, b, cfg.sram_end - 12, d, 2, 2, 4)),
        ("GEMM D exactly at the end (ok)", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x24C, 1, 0, a, b, c, cfg.sram_end - 16, 2, 2, 4)),
        ("GEMM D one word over the end", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x24D, 1, 0, a, b, c, cfg.sram_end - 12, 2, 2, 4)),
        ("CLEAR exactly at the end (ok)", pack_desc(CW_OP_CLEAR, 0, 0, 0, 0x24E, 1, 0, 0, 0, 0, cfg.sram_end - 64, w6=64)),
        ("CLEAR one word over the end", pack_desc(CW_OP_CLEAR, 0, 0, 0, 0x24F, 1, 0, 0, 0, 0, cfg.sram_end - 60, w6=64)),
        ("huge VL (no 32-bit wrap)", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x215, 1, 0, a, b, c, d, w6=0x40000001)),
        ("huge CLEAR", pack_desc(CW_OP_CLEAR, 0, 0, 0, 0x216, 1, 0, 0, 0, 0, d, w6=0xFFFFFFFC)),
        ("VADD partial overlap", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x217, 1, 0, a, b, c, a + 4, w6=8)),
        ("VADD in place (ok)", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x218, 1, 0, a, b, c, a, w6=8)),
        ("GEMM result overlaps A", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x219, 1, 0, a, b, c, a, 2, 2, 2)),
        ("GEMM result overlaps B", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x21A, 1, 0, a, b, c, b - 8, 2, 2, 2)),
        ("GEMM acc partial C overlap", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 1, 0x21B, 1, 0, a, b, c, c + 4, 2, 2, 2)),
        ("GEMM acc in place C=D (ok)", pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 1, 0x21C, 1, 0, a, b, c, c, 2, 2, 2)),
        ("ACC on VADD", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 1, 0x21D, 1, 0, a, b, c, d, w6=4)),
        ("RM=5", pack_desc(CW_OP_VADD, CW_ET_FP32, 5, 0, 0x21E, 1, 0, a, b, c, d, w6=4)),
        ("RM=7 on INT32 (ignored, ok)", pack_desc(CW_OP_VADD, CW_ET_INT32, 7, 0, 0x21F, 1, 0, a, b, c, d, w6=4)),
        ("reserved W0 bits", pack_desc(CW_OP_NOP, 0, 0, 0, 0x220, 1, 0, 0, 0, 0, 0, res0=1)),
        ("reserved W1 bits", pack_desc(CW_OP_NOP, 0, 0, 0, 0x221, 1, 0, 0, 0, 0, 0, res1=0x100)),
        ("reserved W7 bits", pack_desc(CW_OP_NOP, 0, 0, 0, 0x222, 1, 0, 0, 0, 0, 0, res7=0x8000)),
        ("dest 2 not allowed", pack_desc(CW_OP_NOP, 0, 0, 0, 0x223, 1, 2, 0, 0, 0, 0)),
        ("dest 15 not allowed", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x224, 1, 15, a, b, c, d, w6=4)),
        ("forged domain 2", pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x225, 2, 0, a, b, c, d, w6=4)),
        ("forged domain 0", pack_desc(CW_OP_NOP, 0, 0, 0, 0x226, 0, 0, 0, 0, 0, 0)),
        ("NOP (ok)", pack_desc(CW_OP_NOP, 0, 0, 0, 0x227, 1, 1, 0, 0, 0, 0)),
    ]
    for name, w in cases:
        st, det, dflt, _rg = validate(w, cfg, True, 1, 0, 0x0003, 0)
        s.comment(f"case: {name} -> status {st} detail {det}")
        s.submit(0, w)
        d = decode_desc(w)
        out, ff = 0, 0
        if st == CW_ST_OK:
            out, ff = model_exec(mem, cfg, w)
        s.cpl(q=0, dom=1, dest=(0 if dflt else d["dest"]), tag=d["tag"], op=d["op"], st=st, detail=det, ff=ff, out=out)
    script_check_all(s, mem)
    s.end()
    s.cases = [(n, validate(w, cfg, True, 1, 0, 0x0003, 0)[:2]) for n, w in cases]
    return s



# ------------------------------------------------------------------------------------------ isolation suites
def two_tenant_setup(s, cfg, gm):
    """IronMemory buffer over the whole SRAM; regions R0 (dom1 rw, 4K), R1 (dom2 rw, 4K), R2 (dom1 read-only, 2K);
    queue 0 -> domain 1, queue 1 -> domain 2.  Mirrors every policy op into the guard model."""
    q4 = cfg.sram_bytes // 4
    s.bm_alloc_at(SRAM_BASE, cfg.sram_bytes)
    regs = [(0, SRAM_BASE, q4, 1, 1, 1), (1, SRAM_BASE + q4, q4, 2, 1, 1), (2, SRAM_BASE + 2 * q4, q4 // 2, 1, 1, 0)]
    for idx, base, size, dom, rd, wr in regs:
        st = gm.set_region(idx, base, size, dom, rd, wr)
        s.pol(CW_POL_SET_REGION, idx, base, size, dom | (rd << 8) | (wr << 9), st)
        assert st == CW_PS_OK
    for qi, dom, dm in ((0, 1, 0x0003), (1, 2, 0x0005)):
        st = gm.bind_queue(qi, dom, 0, 0, 1, 1, 0)
        s.pol(CW_POL_BIND_QUEUE, qi, dom | (0 << 4) | (0 << 8) | (1 << 12) | (1 << 16), 0, 0, st)
        st = gm.set_destmask(dom, dm)
        s.pol(CW_POL_SET_DESTMASK, dom, dm, 0, 0, st)
    return q4


def run_cmd(s, mem, cfg, gm, qi, w, stgzero=True):
    """Submit w to queue qi, expect exactly what the models predict, apply its effect to the shadow memory."""
    st, det, dest, dom = gm.expect(w, qi)
    d = decode_desc(w)
    s.submit(qi, w)
    out, ff = 0, 0
    if st == CW_ST_OK:
        out, ff = model_exec(mem, cfg, w)
    s.cpl(q=qi, dom=dom, dest=dest, tag=d["tag"], op=d["op"], st=st, detail=det, ff=ff, out=out)
    if stgzero and cfg.clear_staging:
        s.checkstg(1)
    return st, det


def suite_p3_isolation(cfg, seed=1):
    """Cross-tenant isolation, directed and then fuzzed against the independent guard model."""
    rng = random.Random(seed)
    s = new_script("p3_isolation", cfg)
    mem = attach(s, Mem(cfg))
    gm = GuardModel(cfg)
    q4 = two_tenant_setup(s, cfg, gm)
    R0, R1, R2 = SRAM_BASE, SRAM_BASE + q4, SRAM_BASE + 2 * q4
    for off in range(0, 3 * q4, 1024):
        script_bwrite(s, mem, SRAM_BASE + off, [rng.getrandbits(8) for _ in range(1024)])     # "secrets" everywhere
    sl = q4 // 4            # 1 KiB slot inside a region

    def vadd(a, b, d, vl, dom, tag, op=CW_OP_VADD, c=0):
        return pack_desc(op, CW_ET_FP32, 0, 0, tag, dom, 0 if dom == 1 else 0, a, b, c, d, w6=vl)

    s.comment("1. each tenant works inside its own region")
    assert run_cmd(s, mem, cfg, gm, 0, vadd(R0, R0 + sl, R0 + 2 * sl, 32, 1, 0x301))[0] == CW_ST_OK
    assert run_cmd(s, mem, cfg, gm, 1, vadd(R1, R1 + sl, R1 + 2 * sl, 32, 2, 0x302))[0] == CW_ST_OK
    s.comment("2. cross-domain READ: tenant 2 reads tenant 1's region")
    st, det = run_cmd(s, mem, cfg, gm, 1, vadd(R0, R1 + sl, R1 + 2 * sl, 16, 2, 0x303))
    assert st == CW_ST_DENIED and (det >> 4) == CW_GF_DOMAIN and (det & 15) == CW_OPND_A
    s.comment("3. cross-domain WRITE: tenant 2 writes into tenant 1's region")
    st, det = run_cmd(s, mem, cfg, gm, 1, vadd(R1, R1 + sl, R0 + 3 * sl, 16, 2, 0x304))
    assert st == CW_ST_DENIED and (det >> 4) == CW_GF_DOMAIN and (det & 15) == CW_OPND_D
    s.comment("4. second operand in the other tenant's region")
    st, det = run_cmd(s, mem, cfg, gm, 0, vadd(R0, R1 + 8, R0 + sl, 16, 1, 0x305))
    assert st == CW_ST_DENIED and (det & 15) == CW_OPND_B
    s.comment("5. read-only region: reading is allowed, writing is denied with PERM")
    assert run_cmd(s, mem, cfg, gm, 0, vadd(R2, R0 + sl, R0 + 2 * sl, 16, 1, 0x306))[0] == CW_ST_OK
    st, det = run_cmd(s, mem, cfg, gm, 0, vadd(R0, R0 + sl, R2 + 64, 16, 1, 0x307))
    assert st == CW_ST_DENIED and (det >> 4) == CW_GF_PERM and (det & 15) == CW_OPND_D
    s.comment("6. range straddling two regions is refused (NOMAP): only single-region ranges are supported")
    st, det = run_cmd(s, mem, cfg, gm, 0, vadd(R1 - 32, R0 + sl, R0 + 2 * sl, 16, 1, 0x308))
    assert st == CW_ST_DENIED and (det >> 4) == CW_GF_NOMAP
    s.comment("7. unassigned memory")
    st, det = run_cmd(s, mem, cfg, gm, 0, vadd(R0, R0 + sl, SRAM_BASE + 3 * q4 + 256, 16, 1, 0x309))
    assert st == CW_ST_DENIED and (det >> 4) == CW_GF_NOMAP
    s.comment("8. forged domain field: queue 1 (domain 2) submits a descriptor CLAIMING domain 1")
    st, det = run_cmd(s, mem, cfg, gm, 1, vadd(R0, R0 + sl, R0 + 2 * sl, 16, 1, 0x30A))
    assert st == CW_ST_OWNER
    s.comment("9. CLEAR: a tenant may scrub its own buffer, not another tenant's")
    assert run_cmd(s, mem, cfg, gm, 1, pack_desc(CW_OP_CLEAR, 0, 0, 0, 0x30B, 2, 0, 0, 0, 0, R1 + sl, w6=64))[0] == CW_ST_OK
    st, det = run_cmd(s, mem, cfg, gm, 1, pack_desc(CW_OP_CLEAR, 0, 0, 0, 0x30C, 2, 0, 0, 0, 0, R0 + sl, w6=64))
    assert st == CW_ST_DENIED
    s.comment("10. completion destinations: domain 1 may use {0,1}, domain 2 may use {0,2}")
    for qi, dom, dest in ((0, 1, 1), (0, 1, 2), (1, 2, 2), (1, 2, 1), (0, 1, 7)):
        w = pack_desc(CW_OP_NOP, 0, 0, 0, 0x320 + dest * 4 + qi, dom, dest)
        run_cmd(s, mem, cfg, gm, qi, w)
    s.comment("11. INT8 GEMM across the boundary of the tenant's region")
    gA, gB, gC = R0, R0 + sl, R0 + 2 * sl
    run_cmd(s, mem, cfg, gm, 0, pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x330, 1, 0, gA, gB, gC, R0 + 3 * sl, 4, 4, 8))
    st, det = run_cmd(s, mem, cfg, gm, 0, pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x331, 1, 0, gA, gB, gC, R1 - 8, 4, 4, 8))
    assert st == CW_ST_DENIED
    script_check_all(s, mem)

    s.comment("12. isolation fuzz: random commands from both tenants, random operand placement")
    spans = [(R0, q4), (R1, q4), (R2, q4 // 2)]
    for t in range(120):
        qi = rng.randrange(0, 2)
        dom = qi + 1
        kind = rng.random()
        base_r, size_r = spans[rng.choice([0, 1, 2, 0, 1])]
        def adr(n, al=4):
            if rng.random() < 0.12:                      # near a region edge -> straddles
                x = rng.choice([R0, R1, R2, R2 + q4 // 2]) + rng.randint(-24, 8)
            else:
                x = base_r + rng.randint(0, max(0, size_r - n))
            return max(SRAM_BASE, min(x - x % al, cfg.sram_end - max(n, 4)))
        if kind < 0.45:
            VL = rng.randint(1, 24)
            w = pack_desc(rng.choice([CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA]), CW_ET_FP32, rng.randrange(0, 5), 0, t, dom, 0,
                          adr(4 * VL), adr(4 * VL), adr(4 * VL), adr(4 * VL), w6=VL)
        elif kind < 0.8:
            M, N, K = rng.randint(1, 6), rng.randint(1, 6), rng.randint(1, 12)
            w = pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, int(rng.random() < 0.3), t, dom, 0, adr(M * K, 1), adr(K * N, 1),
                          adr(4 * M * N), adr(4 * M * N), M, N, K)
        else:
            w = pack_desc(CW_OP_CLEAR, 0, 0, 0, t, dom, 0, 0, 0, 0, adr(64), w6=4 * rng.randint(1, 16))
        run_cmd(s, mem, cfg, gm, qi, w)
        if t % 8 == 7:
            script_check_all(s, mem)
    script_check_all(s, mem)
    s.perf()
    s.end()
    return s


def suite_p3_leak(cfg, seed=1):
    """Scratchpad clearing / reassignment procedure: REVOKE -> SCRUB -> SET_REGION, enforced in hardware."""
    rng = random.Random(seed)
    s = new_script("p3_leak", cfg)
    mem = attach(s, Mem(cfg))
    gm = GuardModel(cfg)
    q4 = two_tenant_setup(s, cfg, gm)
    R0, R1 = SRAM_BASE, SRAM_BASE + q4
    sl = q4 // 4
    s.comment("policy waits for a running command: a long GEMM is submitted, then a policy op; the op may only complete after the")
    s.comment("command has finished, so its completion must already be pending when the policy op returns")
    Ag, Bg = rnd_bytes(rng, 3 * cfg.kmax), rnd_bytes(rng, 3 * cfg.kmax)
    script_bwrite(s, mem, R1, Ag); script_bwrite(s, mem, R1 + sl, Bg)
    wl = pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x400, 2, 0, R1, R1 + sl, 0, R1 + 3 * sl, 3, 3, cfg.kmax)
    assert gm.expect(wl, 1)[0] == CW_ST_OK
    s.submit(1, wl)
    s.delay(12)
    st = gm.set_destmask(2, 0x5); s.pol(CW_POL_SET_DESTMASK, 2, 0x5, 0, 0, st)
    s.checkpend(1)
    out, ff = model_exec(mem, cfg, wl)
    s.cpl(q=1, dom=2, dest=0, tag=0x400, op=CW_OP_GEMM, st=CW_ST_OK, detail=0, ff=0, out=out)
    s.comment("tenant 1 produces a SECRET result inside region 0")
    do_gemm_in = lambda: None
    A = rnd_bytes(rng, 8 * 8); B = rnd_bytes(rng, 8 * 8)
    script_bwrite(s, mem, R0, A); script_bwrite(s, mem, R0 + sl, B)
    secret_addr = R0 + 3 * sl
    run_cmd(s, mem, cfg, gm, 0, pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x401, 1, 0, R0, R0 + sl, R0 + 2 * sl, secret_addr, 8, 8, 8))
    sec = mem.read(secret_addr, 4 * 8 * 8)
    assert any(sec), "the secret must be nonzero"
    s.comment("withdraw region 0")
    st = gm.revoke(0); s.pol(CW_POL_REVOKE, 0, 0, 0, 0, st); assert st == CW_PS_OK
    s.comment("revoking again / revoking a never-live entry is an error")
    st = gm.revoke(0); s.pol(CW_POL_REVOKE, 0, 0, 0, 0, st); assert st == CW_PS_NOT_LIVE
    s.comment("the old tenant loses access immediately")
    st, det = run_cmd(s, mem, cfg, gm, 0, pack_desc(CW_OP_VADD, CW_ET_FP32, 0, 0, 0x402, 1, 0, R0, R0 + sl, 0, R0 + 2 * sl, w6=8))
    assert st == CW_ST_DENIED
    s.comment("REASSIGNMENT WITHOUT SCRUB IS REFUSED, whichever way it is attempted")
    for idx, base, size, dom in ((0, R0, q4, 2), (3, R0, q4, 2), (4, R0 + sl, q4 // 4, 2), (3, R0 + 3 * sl, sl, 2)):
        st = gm.set_region(idx, base, size, dom, 1, 1)
        s.pol(CW_POL_SET_REGION, idx, base, size, dom | (1 << 8) | (1 << 9), st)
        assert st == CW_PS_NOT_CLEAN, f"expected NOT_CLEAN, got {st}"
    s.comment("a DIRTY entry must not be reused for a different, free range: that would forget the dirty marker of the old range")
    free_base = SRAM_BASE + 3 * q4
    st = gm.set_region(0, free_base, 256, 2, 1, 1)
    s.pol(CW_POL_SET_REGION, 0, free_base, 256, 2 | (1 << 8) | (1 << 9), st)
    assert st == CW_PS_NOT_CLEAN
    s.comment("the secret is still physically there until scrubbed")
    script_check_all(s, mem)
    s.comment("SCRUB a live region is refused; scrub the dirty one")
    st = gm.scrub(1, mem); s.pol(CW_POL_SCRUB, 1, 0, 0, 0, st); assert st == CW_PS_IN_USE
    st = gm.scrub(0, mem); s.pol(CW_POL_SCRUB, 0, 0, 0, 0, st); assert st == CW_PS_OK
    s.tally.scrub += q4
    assert not any(mem.read(secret_addr, 4 * 64)), "model: scrub must zero the secret"
    s.comment("after SCRUB the region is zero and may be reassigned to the other tenant")
    script_check_all(s, mem)
    st = gm.set_region(0, R0, q4, 2, 1, 1); s.pol(CW_POL_SET_REGION, 0, R0, q4, 2 | (1 << 8) | (1 << 9), st); assert st == CW_PS_OK
    s.comment("tenant 2 reads the former secret area: it sees ZEROS (a VADD of it with zeros is all zero)")
    script_bwrite(s, mem, R1, [0] * 256)
    st, det = run_cmd(s, mem, cfg, gm, 1, pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0x403, 2, 0, secret_addr, R1, 0, R1 + sl, w6=64))
    assert st == CW_ST_OK and not any(mem.read(R1 + sl, 256)), "tenant 2 must read zeros, never tenant 1's data"
    s.comment("tenant-initiated CLEAR of its own buffer")
    script_bwrite(s, mem, R1 + 2 * sl, [0xAA] * 128)
    run_cmd(s, mem, cfg, gm, 1, pack_desc(CW_OP_CLEAR, 0, 0, 0, 0x404, 2, 0, 0, 0, 0, R1 + 2 * sl, w6=128))
    script_check_all(s, mem)
    s.comment("policy op semantics: bad index, misaligned, out of range, overlap, in use")
    for args in ((9, R1, 256, 1), (3, R1 + 4, 256, 1), (3, R1, 100, 1), (3, SRAM_BASE - 256, 256, 1), (3, cfg.sram_end - 256, 512, 1),
                 (3, R1, 256, 1), (1, R1 + 3 * sl, 256, 1)):
        st = gm.set_region(*args, 1, 1); s.pol(CW_POL_SET_REGION, args[0], args[1], args[2], args[3] | (1 << 8) | (1 << 9), st)
    s.comment("a queue's work budget: the budget rejects oversize commands before they run")
    st = gm.bind_queue(0, 1, 0, 0, 1, 1, 100); s.pol(CW_POL_BIND_QUEUE, 0, 1 | (1 << 12) | (1 << 16), 100, 0, st)
    st = gm.set_region(5, R0 + q4 // 2, 256, 1, 1, 1)           # R0 now belongs to dom 2 (idx 0): overlap -> refused
    s.pol(CW_POL_SET_REGION, 5, R0 + q4 // 2, 256, 1 | (1 << 8) | (1 << 9), st)
    script_check_all(s, mem)
    s.end()
    return s


def suite_p3_memlayer(cfg, seed=1):
    """Second isolation layer: IronMemory buffer ownership.  A command can pass the tile's region check and still be
    refused by IronMemory (the compute domain lacks a right on the buffer): the result must be a MEM_ERR completion,
    and a refused write must never modify memory."""
    rng = random.Random(seed)
    s = new_script("p3_memlayer", cfg)
    mem = attach(s, Mem(cfg))
    gm = GuardModel(cfg)
    half = cfg.sram_bytes // 2
    s.bm_alloc_at(SRAM_BASE, half, 1, 0b01011, 0b01011)                                  # compute: read + write
    s.bm_alloc_at(SRAM_BASE + half, 2048, 1, 0b01011, 0b00011)                           # compute: read only
    s.bm_alloc_at(SRAM_BASE + half + 2048, 2048, 1, 0b00011, 0b00011)                    # compute: no access
    hole = SRAM_BASE + half + 4096                                                       # unmanaged: Keystone only
    hole_len = cfg.sram_bytes - half - 4096
    st = gm.set_region(0, SRAM_BASE, cfg.sram_bytes, 1, 1, 1); s.pol(CW_POL_SET_REGION, 0, SRAM_BASE, cfg.sram_bytes, 1 | (1 << 8) | (1 << 9), st)
    st = gm.bind_queue(0, 1, 0, 0, 1, 1, 0); s.pol(CW_POL_BIND_QUEUE, 0, 1 | (1 << 12) | (1 << 16), 0, 0, st)
    st = gm.set_destmask(1, 0x3); s.pol(CW_POL_SET_DESTMASK, 1, 0x3, 0, 0, st)
    managed = half + 4096
    for off in range(0, managed, 1024):
        script_bwrite(s, mem, SRAM_BASE + off, [rng.getrandbits(8) for _ in range(1024)])
    hole_data = [rng.getrandbits(8) for _ in range(hole_len)]
    s.kwrite(hole, hole_data)                  # raw Keystone writes: the only agent allowed in unmanaged memory
    mem.write(hole, hole_data)
    ro, noacc = SRAM_BASE + half, SRAM_BASE + half + 2048
    a, b, d = SRAM_BASE, SRAM_BASE + 1024, SRAM_BASE + 2048

    def raw(w, st_, det_, tag):
        dd = decode_desc(w)
        s.submit(0, w)
        s.cpl(q=0, dom=1, dest=0, tag=tag, op=dd["op"], st=st_, detail=det_, ff=0, out=0)
        if cfg.clear_staging:
            s.checkstg(1)

    def check_everything():
        for off in range(0, managed, 1024):
            s.bread(SRAM_BASE + off, mem.read(SRAM_BASE + off, min(1024, managed - off)))
        s.kread(hole, mem.read(hole, hole_len))

    s.comment("control: all operands in the compute-accessible buffer succeed")
    run_cmd(s, mem, cfg, gm, 0, pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0x501, 1, 0, a, b, 0, d, w6=16), stgzero=False)
    s.comment("write into a READ-ONLY (for compute) buffer: loads succeed, the store is refused, memory unchanged")
    raw(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0x502, 1, 0, a, b, 0, ro, w6=16), CW_ST_MEM_ERR, (CW_PH_STORE << 12) | 3, 0x502)
    s.comment("read from a buffer the compute domain may not touch: the first load is refused (PERM)")
    raw(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0x503, 1, 0, noacc, b, 0, d, w6=16), CW_ST_MEM_ERR, (CW_PH_LOAD_A << 12) | 3, 0x503)
    raw(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0x504, 1, 0, a, noacc, 0, d, w6=16), CW_ST_MEM_ERR, (CW_PH_LOAD_B << 12) | 3, 0x504)
    s.comment("unmanaged memory is Keystone-only: a store there is refused, and a read of it is refused too")
    raw(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0x505, 1, 0, a, b, 0, hole, w6=16), CW_ST_MEM_ERR, (CW_PH_STORE << 12) | 3, 0x505)
    raw(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0x50A, 1, 0, hole, b, 0, d, w6=16), CW_ST_MEM_ERR, (CW_PH_LOAD_A << 12) | 3, 0x50A)
    s.comment("GEMM: load of A refused (phase 1), then store refused (phase 4)")
    raw(pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x506, 1, 0, noacc, b, 0, d, 4, 4, 4), CW_ST_MEM_ERR, (CW_PH_LOAD_A << 12) | 3, 0x506)
    raw(pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x507, 1, 0, a, b, 0, ro, 4, 4, 4), CW_ST_MEM_ERR, (CW_PH_STORE << 12) | 3, 0x507)
    mem.tally.array += array_busy_model(4, 4, 4, cfg.rows, cfg.cols)     # the block was computed before its store was refused
    s.comment("CLEAR into a read-only buffer: refused, nothing zeroed")
    raw(pack_desc(CW_OP_CLEAR, 0, 0, 0, 0x508, 1, 0, 0, 0, 0, ro, w6=64), CW_ST_MEM_ERR, (CW_PH_CLEAR << 12) | 3, 0x508)
    s.comment("after all those failures the tile still works, and nothing but the one good result changed -- including the hole")
    run_cmd(s, mem, cfg, gm, 0, pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0x509, 1, 0, a, b, 0, d + 512, w6=16), stgzero=False)
    check_everything()
    s.perf()
    s.end()
    return s



# ------------------------------------------------------------------------------------------ queues / scheduling
def suite_p3_queues(cfg, seed=1):
    """Multiple protected queues: RR, quantum, priority classes, ageing, disabled and unbound queues, completion
    back-pressure.  Dispatch is held off (clk_en = 0) while the queues are filled, so the order is fully determined by
    the arbitration policy; the Python model predicts it and the runner compares it with the hardware's order."""
    rng = random.Random(seed)
    nq, depth = cfg.queues, cfg.cmd_depth
    s = new_script("p3_queues", cfg)
    mem = attach(s, Mem(cfg))
    gm = GuardModel(cfg)
    s.bm_alloc_at(SRAM_BASE, cfg.sram_bytes)
    s.expect_order = []          # sequence of (queue, tag, status, domain) in required completion order, per phase
    tagc = [0x100]
    arb = ArbModel(nq, [0] * nq, [1] * nq, cfg.starve)     # PERSISTENT: the hardware keeps its arbitration state across phases

    def bind(qi, dom, prio, quantum, en=1, dest=0, budget=0):
        st = gm.bind_queue(qi, dom, prio, dest, en, quantum, budget)
        s.pol(CW_POL_BIND_QUEUE, qi, dom | (prio << 4) | (dest << 8) | (en << 12) | (quantum << 16), budget, 0, st)

    for qi in range(nq - 1):                             # last queue stays UNBOUND on purpose
        s.pol(CW_POL_SET_DESTMASK, qi + 1, 0x0003, 0, 0, gm.set_destmask(qi + 1, 0x3))

    def phase(name, prios, quants, counts, enabled=None, cplbp=100):
        """Fill the queues while dispatch is stopped, release, and record the expected completion order."""
        s.comment("phase: " + name)
        enabled = enabled or [1] * nq
        for qi in range(nq - 1):
            bind(qi, qi + 1, prios[qi], quants[qi], enabled[qi])
        s.clken(0)
        pend = [[] for _ in range(nq)]
        for qi in range(nq):
            for k in range(counts[qi]):
                tagc[0] += 1
                tag = tagc[0]
                kind = rng.random()
                if kind < 0.6:
                    w = pack_desc(CW_OP_NOP, 0, 0, 0, tag, (qi + 1) & 7, 0)
                else:
                    w = pack_desc(CW_OP_CLEAR, 0, 0, 0, tag, (qi + 1) & 7, 0, 0, 0, 0, SRAM_BASE + 256 * qi, w6=16)
                s.submit(qi, w)
                pend[qi].append((tag, w))
        # regions so the CLEAR commands are permitted: each tenant owns its own 256-byte slot
        arb.prio = [prios[q] if q < nq - 1 else 0 for q in range(nq)]            # BIND_QUEUE changes policy, not state
        arb.quantum = [quants[q] if q < nq - 1 else 1 for q in range(nq)]
        order = []
        en = [bool(enabled[q]) if q < nq - 1 else True for q in range(nq)]
        while True:
            ne = [len(pend[q]) > 0 for q in range(nq)]
            sel = arb.pick(ne, en)
            if sel is None:
                break
            tag, w = pend[sel].pop(0)
            bound = sel < nq - 1
            st, det, dest, dom = (gm.expect(w, sel) if bound else (CW_ST_OWNER, (0 << 3) | decode_desc(w)["claim"], 0, 0))
            out = 0
            if bound and st == CW_ST_OK and decode_desc(w)["op"] == CW_OP_CLEAR:
                mem.write(decode_desc(w)["dst"], [0] * 16)
                out = 16
                s.tally.scrub += 16
            s.tally.completion(st, out)
            order.append((sel, tag, st, dom))
        if cplbp != 100:
            s.cplbp(cplbp)
        s.clken(1)
        s.cpl_dump(len(order))
        s.expect_order.append(order)
        s.cplbp(100)
        left = sum(len(p) for p in pend)
        if left:                                         # commands parked in a disabled queue: they must NOT complete
            s.nocpl(300)
        return pend

    # tenant regions: each queue's tenant owns a 256-byte slot (for the CLEAR commands)
    for qi in range(nq - 1):
        st = gm.set_region(qi, SRAM_BASE + 256 * qi, 256, qi + 1, 1, 1)
        s.pol(CW_POL_SET_REGION, qi, SRAM_BASE + 256 * qi, 256, (qi + 1) | (1 << 8) | (1 << 9), st)
    phase("plain round robin", [0] * nq, [1] * nq, [depth] * nq)
    phase("quanta 3/1/2", [0] * nq, [3, 1, 2, 1], [depth] * nq)
    phase("strict priority classes with ageing", [0, 1, 2, 3], [1] * nq, [depth] * nq)
    phase("two classes, quantum", [1, 1, 3, 0], [2, 2, 1, 1], [depth, depth - 2, depth, depth - 1])
    left = phase("a disabled queue is parked, then released", [0, 0, 0, 0], [1] * nq, [3, 3, 3, 2], enabled=[1, 0, 1, 1])
    # release the parked queue 1 and expect its three commands
    s.comment("release queue 1")
    bind(1, 2, 0, 1, 1)
    order = []
    for tag, w in left[1]:
        st, det, dest, dom = gm.expect(w, 1)
        out = 0
        if st == CW_ST_OK and decode_desc(w)["op"] == CW_OP_CLEAR:
            mem.write(decode_desc(w)["dst"], [0] * 16); out = 16; s.tally.scrub += 16
        s.tally.completion(st, out)
        order.append((1, tag, st, dom))
    s.cpl_dump(len(order))
    s.expect_order.append(order)
    phase("completion back-pressure (30% ready)", [0, 0, 1, 0], [1, 2, 1, 1], [depth] * nq, cplbp=30)
    script_check_all(s, mem)
    s.perf()
    s.end()
    return s



# ------------------------------------------------------------------------------------------ robustness suites
def suite_p3_backpressure(cfg, seed=1):
    """Lossless operation under pressure: submission back-pressure (tiny queues), completion back-pressure (25% ready),
    and REAL bank contention from a concurrent master hammering a neighbouring region while commands run."""
    rng = random.Random(seed)
    s = new_script("p3_backpressure", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg)
    bg_lo = slot(cfg, 7)
    bg_n = cfg.sram_bytes // 8
    s.comment("pattern region for the background master")
    script_bwrite(s, mem, bg_lo, [bg_pattern(bg_lo + i) for i in range(bg_n)])
    s.perfclear()
    s.comment("phase A: compute under concurrent contention")
    s.bgdma(1, bg_lo, bg_lo + bg_n, 70)
    for t in range(14):
        if t % 2 == 0:
            M, N, K = rng.randint(2, 8), rng.randint(2, 8), rng.randint(8, 40)
            do_gemm(s, mem, cfg, rng, M, N, K, acc=rng.random() < 0.3, tag=0x600 + t)
        else:
            do_vec(s, mem, cfg, rng, rng.choice([CW_OP_VADD, CW_OP_VMUL, CW_OP_VFMA]), CW_ET_FP32, rng.randrange(0, 5),
                   rng.randint(8, 80), tag=0x600 + t)
    s.bgstat(30)
    s.comment("phase B: submit back-to-back, completions only 6% ready -> the scheduler must stall, never drop")
    s.cplbp(6)
    exp = []
    for t in range(36):
        tag = 0x700 + t
        if t % 3 == 0:
            w = pack_desc(CW_OP_NOP, 0, 0, 0, tag, 1, 0)
            exp.append((tag, CW_OP_NOP, 0)); s.submit(0, w)
        elif t % 3 == 1:
            a, b, d = slot(cfg, 0), slot(cfg, 1), slot(cfg, 3)
            w = pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, tag, 1, 0, a, b, 0, d, w6=8)
            exp.append((tag, CW_OP_VADD, 32))
            mem.write_words(d, [(x + y) & M32 for x, y in zip(mem.read_words(a, 8), mem.read_words(b, 8))])
            mem.tally.vec_elems += 8
            s.submit(0, w)
        else:
            w = pack_desc(CW_OP_CLEAR, 0, 0, 0, tag, 1, 0, 0, 0, 0, slot(cfg, 5), w6=64)
            exp.append((tag, CW_OP_CLEAR, 64)); mem.write(slot(cfg, 5), [0] * 64); mem.tally.scrub += 64
            s.submit(0, w)
    for tag, op, out in exp:
        s.cpl(q=0, dom=1, dest=0, tag=tag, op=op, st=CW_ST_OK, detail=0, ff=0, out=out)
    s.cplbp(100)
    if cfg.clear_staging:
        s.checkstg(1)
    for bank in range(cfg.banks):                                     # IronMemory's own per-bank conflict counters
        s.csr(0x100 + bank * 0x20 + 4 * 3)
    script_check_all(s, mem)
    s.perf()
    s.end()
    return s


def suite_p3_reset(cfg, seed=1):
    """Reset: during a long command, with queued commands, and during SCRUB.  After reset the tile is empty, the local
    memory is re-initialised to zero, the policy is cleared (default deny) and it works again."""
    rng = random.Random(seed)
    s = new_script("p3_reset", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg)
    M, N, K = 8, 8, cfg.kmax
    script_bwrite(s, mem, slot(cfg, 0), rnd_bytes(rng, M * K))
    script_bwrite(s, mem, slot(cfg, 1), rnd_bytes(rng, K * N))
    w = pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x801, 1, 0, slot(cfg, 0), slot(cfg, 1), 0, slot(cfg, 3), M, N, K)
    s.comment("long GEMM in flight, plus two queued commands, then RESET")
    s.clken(1)
    s.submit(0, w); s.submit(0, pack_desc(CW_OP_NOP, 0, 0, 0, 0x802, 1, 0)); s.submit(0, pack_desc(CW_OP_NOP, 0, 0, 0, 0x803, 1, 0))
    s.delay(40)
    s.reset()
    s.nocpl(600)                                     # no completion may appear from before the reset
    s.checkgate(1, 1, 0)
    s.comment("the buffer table is empty after reset: re-allocate, then the SRAM must read ZERO (re-initialised): nothing of the old tenant survives")
    s.bm_alloc_at(SRAM_BASE, cfg.sram_bytes)
    mem = attach(s, Mem(cfg))
    script_check_all(s, mem)
    s.comment("policy cleared: default deny.  The queue is unbound again -> OWNER; the old tenant can do nothing")
    s.submit(0, pack_desc(CW_OP_NOP, 0, 0, 0, 0x804, 1, 0))
    s.cpl(q=0, dom=0, dest=0, tag=0x804, op=CW_OP_NOP, st=CW_ST_OWNER, detail=1, ff=0, out=0)
    s.comment("re-program and run normally")
    s.pol(CW_POL_SET_REGION, 0, SRAM_BASE, cfg.sram_bytes, 1 | (1 << 8) | (1 << 9), CW_PS_OK)
    s.pol(CW_POL_BIND_QUEUE, 0, 1 | (1 << 12) | (1 << 16), 0, 0, CW_PS_OK)
    s.pol(CW_POL_SET_DESTMASK, 1, 3, 0, 0, CW_PS_OK)
    gm = GuardModel(cfg); gm.set_region(0, SRAM_BASE, cfg.sram_bytes, 1, 1, 1); gm.bind_queue(0, 1, 0, 0, 1, 1, 0); gm.set_destmask(1, 3)
    do_gemm(s, mem, cfg, rng, 5, 6, 17, tag=0x805)
    s.comment("reset during a SCRUB: revoke a region, start scrubbing, reset; entry state is cleared, memory is zero")
    s.pol(CW_POL_REVOKE, 0, 0, 0, 0, CW_PS_OK)
    s.submit(0, pack_desc(CW_OP_NOP, 0, 0, 0, 0x806, 1, 0))      # queued behind the policy op
    s.reset()
    s.nocpl(300)
    s.bm_alloc_at(SRAM_BASE, cfg.sram_bytes)
    mem = attach(s, Mem(cfg))
    script_check_all(s, mem)
    s.pol(CW_POL_SET_REGION, 0, SRAM_BASE, cfg.sram_bytes, 1 | (1 << 8) | (1 << 9), CW_PS_OK)     # clean again after reset
    s.perf()
    s.end()
    return s


def suite_p3_clken(cfg, seed=1):
    """clk_en_i gates DISPATCH, never a command already started; clk_gate_ok_o reports true quiescence."""
    rng = random.Random(seed)
    s = new_script("p3_clken", cfg)
    mem = attach(s, Mem(cfg))
    s.setup_tenant(cfg)
    s.checkgate(1, 1, 0)                              # idle, queues empty: the clock may be gated
    s.comment("dispatch disabled: submitted commands wait, the tile is not quiescent")
    s.clken(0)
    s.submit(0, pack_desc(CW_OP_NOP, 0, 0, 0, 0x901, 1, 0))
    s.submit(0, pack_desc(CW_OP_NOP, 0, 0, 0, 0x902, 1, 0))
    s.nocpl(300)
    s.checkgate(0, 1, 0)                              # work pending: must NOT report gate-ok
    s.comment("enable: both run, in order")
    s.clken(1)
    s.cpl(q=0, dom=1, dest=0, tag=0x901, op=CW_OP_NOP, st=CW_ST_OK, detail=0, ff=0, out=0)
    s.cpl(q=0, dom=1, dest=0, tag=0x902, op=CW_OP_NOP, st=CW_ST_OK, detail=0, ff=0, out=0)
    s.checkgate(1, 1, 0)
    s.comment("a started command is never frozen: drop clk_en mid-command, it still completes; the NEXT one waits")
    M, N, K = 8, 8, cfg.kmax
    A, B = rnd_bytes(rng, M * K), rnd_bytes(rng, K * N)
    script_bwrite(s, mem, slot(cfg, 0), A); script_bwrite(s, mem, slot(cfg, 1), B)
    w = pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0x903, 1, 0, slot(cfg, 0), slot(cfg, 1), 0, slot(cfg, 3), M, N, K)
    s.submit(0, w)
    s.delay(30)
    s.clken(0)
    s.checkgate(0, 0, 1)                              # busy: not gate-ok
    s.submit(0, pack_desc(CW_OP_NOP, 0, 0, 0, 0x904, 1, 0))
    mem.write_words(slot(cfg, 3), gemm_ref(M, N, K, A, B)); tally_gemm(mem, M, N, K)
    s.cpl(q=0, dom=1, dest=0, tag=0x903, op=CW_OP_GEMM, st=CW_ST_OK, detail=0, ff=0, out=4 * M * N)
    s.nocpl(400)                                      # 0x904 must still be parked
    s.clken(1)
    s.cpl(q=0, dom=1, dest=0, tag=0x904, op=CW_OP_NOP, st=CW_ST_OK, detail=0, ff=0, out=0)
    s.checkgate(1, 1, 0)
    script_check_all(s, mem)
    s.perf()
    s.end()
    return s


def suite_p3_ecc(cfg, seed=1):
    """Memory error propagation through the compute path: a single-bit ECC error is corrected invisibly; an
    uncorrectable (2-bit) error in an operand word is reported as MEM_ERR to exactly the command that read it, and
    its result is not stored."""
    rng = random.Random(seed)
    s = new_script("p3_ecc", cfg)
    mem = attach(s, Mem(cfg))
    gm = GuardModel(cfg)
    s.setup_tenant(cfg)
    gm.set_region(0, SRAM_BASE, cfg.sram_bytes, 1, 1, 1); gm.bind_queue(0, 1, 0, 0, 1, 1, 0); gm.set_destmask(1, 3)
    a, b, d = slot(cfg, 0), slot(cfg, 1), slot(cfg, 3)
    nb = cfg.dw // 8
    def bank_of(addr):
        return ((addr - SRAM_BASE) // nb) % cfg.banks
    A = [rng.getrandbits(32) for _ in range(16)]; B = [rng.getrandbits(32) for _ in range(16)]
    s.comment("single-bit error injected into the first word of A (codeword bit 3): corrected on read, result exact")
    s.csrw(0x01C, 3 | (1 << 15))
    s.csrw(0x020, 0x80000000 | bank_of(a))
    script_bwrite(s, mem, a, words_to_bytes(A))
    script_bwrite(s, mem, b, words_to_bytes(B))
    w = pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0xA01, 1, 0, a, b, 0, d, w6=16)
    s.submit(0, w)
    D = [(x + y) & M32 for x, y in zip(A, B)]
    mem.write_words(d, D); mem.tally.vec_elems += 16
    s.cpl(q=0, dom=1, dest=0, tag=0xA01, op=CW_OP_VADD, st=CW_ST_OK, detail=0, ff=0, out=64)
    s.bread(d, mem.read(d, 64))
    s.csr(0x008)                                      # STATUS: corrected-ECC sticky bit (bit 5) should be set
    s.csrw(0x01C, 0)
    s.comment("double-bit error injected into the first word of B: uncorrectable -> MEM_ERR, no store")
    s.csrw(0x01C, 3 | (1 << 15) | (9 << 16) | (1 << 31))
    s.csrw(0x020, 0x80000000 | bank_of(b))
    script_bwrite(s, mem, b, words_to_bytes(B))
    D0 = mem.read(d, 64)
    s.submit(0, pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0xA02, 1, 0, a, b, 0, d + 64, w6=16))
    s.cpl(q=0, dom=1, dest=0, tag=0xA02, op=CW_OP_VADD, st=CW_ST_MEM_ERR, detail=(CW_PH_LOAD_B << 12) | 4, ff=0, out=0)
    s.csr(0x008)                                      # UE sticky bit (bit 1)
    s.csrw(0x01C, 0)
    s.comment("the same words, rewritten clean, work again; the failed command left no trace")
    script_bwrite(s, mem, b, words_to_bytes(B))
    s.submit(0, pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0xA03, 1, 0, a, b, 0, d + 64, w6=16))
    mem.write_words(d + 64, D); mem.tally.vec_elems += 16
    s.cpl(q=0, dom=1, dest=0, tag=0xA03, op=CW_OP_VADD, st=CW_ST_OK, detail=0, ff=0, out=64)
    script_check_all(s, mem)
    s.perf()
    s.end()
    return s


def suite_p3_extcit(cfg, seed=1, hang=False, noready=False):
    """GUARD_MODE = 2: every range query goes to an EXTERNAL Citadel (a different implementation: the testbench stub
    permits only domain 1 inside [lo, hi)).  With the stub hung, every query must fail closed (CITTMO)."""
    rng = random.Random(seed)
    hang = hang or noready
    s = new_script("p3_extcit_noready" if noready else ("p3_extcit_hang" if hang else "p3_extcit"), cfg)
    mem = attach(s, Mem(cfg))
    s.bm_alloc_at(SRAM_BASE, cfg.sram_bytes)
    s.pol(CW_POL_SET_REGION, 0, SRAM_BASE, 1024, 1 | (1 << 8) | (1 << 9), CW_PS_UNSUPPORTED)      # the Citadel owns the policy
    s.pol(CW_POL_REVOKE, 0, 0, 0, 0, CW_PS_UNSUPPORTED)
    s.pol(CW_POL_SCRUB, 0, 0, 0, 0, CW_PS_UNSUPPORTED)
    s.pol(CW_POL_BIND_QUEUE, 0, 1 | (1 << 12) | (1 << 16), 0, 0, CW_PS_OK)
    s.pol(CW_POL_SET_DESTMASK, 1, 3, 0, 0, CW_PS_OK)
    half = cfg.sram_bytes // 2
    lo, hi = SRAM_BASE, SRAM_BASE + half
    s.xcit(lo, hi, 1)
    a, b, d = slot(cfg, 0), slot(cfg, 1), slot(cfg, 3)            # all inside the lower half
    out_a, out_d = slot(cfg, 5), slot(cfg, 6)                     # upper half: outside the stub's window
    for off in range(0, cfg.sram_bytes, 1024):
        script_bwrite(s, mem, SRAM_BASE + off, [rng.getrandbits(8) for _ in range(1024)])
    def cmd(w, st_, det_, out_=0, ff_=0, tag=None):
        dd = decode_desc(w)
        s.submit(0, w)
        s.cpl(q=0, dom=1, dest=0, tag=dd["tag"], op=dd["op"], st=st_, detail=det_, ff=ff_, out=out_)
    if hang:
        s.comment("hung Citadel: operands present -> fail closed; the NOP (no ranges) is unaffected")
        cmd(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0xB01, 1, 0, a, b, 0, d, w6=8), CW_ST_DENIED, (CW_GF_CITTMO << 4) | CW_OPND_A)
        cmd(pack_desc(CW_OP_GEMM, CW_ET_INT8, 0, 0, 0xB02, 1, 0, a, b, 0, d, 2, 2, 2), CW_ST_DENIED, (CW_GF_CITTMO << 4) | CW_OPND_A)
        cmd(pack_desc(CW_OP_NOP, 0, 0, 0, 0xB03, 1, 0), CW_ST_OK, 0)
    else:
        s.comment("permitted ranges execute")
        A = mem.read_words(a, 8); B = mem.read_words(b, 8)
        mem.write_words(d, [(x + y) & M32 for x, y in zip(A, B)]); mem.tally.vec_elems += 8
        cmd(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0xB01, 1, 0, a, b, 0, d, w6=8), CW_ST_OK, 0, out_=32)
        s.comment("an operand above the stub's window is refused (NOMAP); nothing is executed")
        cmd(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0xB02, 1, 0, a, out_a, 0, d + 64, w6=8), CW_ST_DENIED, (CW_GF_NOMAP << 4) | CW_OPND_B)
        cmd(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0xB03, 1, 0, a, b, 0, out_d, w6=8), CW_ST_DENIED, (CW_GF_NOMAP << 4) | CW_OPND_D)
        cmd(pack_desc(CW_OP_CLEAR, 0, 0, 0, 0xB04, 1, 0, 0, 0, 0, out_d, w6=64), CW_ST_DENIED, (CW_GF_NOMAP << 4) | CW_OPND_D)
        s.comment("a different domain on the same queue is caught by the ownership check before the Citadel is asked")
        cmd(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0xB05, 2, 0, a, b, 0, d, w6=8), CW_ST_OWNER, 2 << 0 | (1 << 3))
        s.comment("re-point the Citadel's window to domain 3: our domain-1 queue is now DOMAIN-denied")
        s.xcit(lo, hi, 3)
        cmd(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0xB06, 1, 0, a, b, 0, d, w6=8), CW_ST_DENIED, (CW_GF_DOMAIN << 4) | CW_OPND_A)
        s.xcit(lo, hi, 1)
        mem.write_words(d + 64, [(x + y) & M32 for x, y in zip(A, B)]); mem.tally.vec_elems += 8
        mem.write(out_d, [0] * 0)
        cmd(pack_desc(CW_OP_VADD, CW_ET_INT32, 0, 0, 0xB07, 1, 0, a, b, 0, d + 64, w6=8), CW_ST_OK, 0, out_=32)
    script_check_all(s, mem)
    s.end()
    return s


SUITES = {
    "p1_single": suite_p1_single,
    "p1_gemm": suite_p1_gemm,
    "p1_overflow": suite_p1_overflow,
    "p2_fp32": suite_p2_fp32,
    "p2_special": suite_p2_special,
    "p2_int32": suite_p2_int32,
    "p2_mixed": suite_p2_mixed,
    "p3_validate": suite_p3_validate,
    "p3_reject_table": suite_p3_reject_table,
    "p3_isolation": suite_p3_isolation,
    "p3_leak": suite_p3_leak,
    "p3_memlayer": suite_p3_memlayer,
    "p3_queues": suite_p3_queues,
    "p3_backpressure": suite_p3_backpressure,
    "p3_reset": suite_p3_reset,
    "p3_clken": suite_p3_clken,
    "p3_ecc": suite_p3_ecc,
    "p3_extcit": suite_p3_extcit,
    "p3_extcit_hang": lambda cfg, seed=1: suite_p3_extcit(cfg, seed, hang=True),
    "p3_extcit_noready": lambda cfg, seed=1: suite_p3_extcit(cfg, seed, noready=True),
}
