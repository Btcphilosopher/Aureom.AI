// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS :: sf_compute_memory_adapter
// Aureom.AI / SilicaFlux Albion
//
// ComputeWorks <-> IronMemory (P84) adapter:  operand buffering, result
// buffering, bank-arbitration front end, local access.
//
//   NUM_CP engines (sf_compute_mem_engine), each owning exactly one IronMemory
//   master port of the ComputeWorks domain.  NUM_CP is 1 or 2: the design does
//   NOT assume an arbitrary number of SRAM ports.  With NUM_CP = 1 every job is
//   serialised on engine 0; with 2 the executors run the A and B operand loads
//   concurrently.  Bank arbitration between these ports (and the Keystone /
//   BridgeEngine ports) is IronMemory's own per-bank round-robin arbiter; this
//   adapter only reports the resulting stalls.
//
//   Four staging buffers of STG_BYTES bytes (flip-flop arrays):
//     0  A / vector A      written by engine scatter
//     1  B / vector B      written by engine scatter
//     2  C / vector C      written by engine scatter
//     3  OUT               written by the executors (o_wr_*), read by WRITE2D jobs
//   All four can be zeroed in one cycle (stg_clear): the scratchpad-residue
//   control used at every command boundary.
//
// A job is the 2-D copy of sf_compute_mem_engine.  Executors choose the engine.
// =============================================================================
`timescale 1ns/1ps
`include "sf_compute_defs.svh"
`default_nettype none

module sf_compute_memory_adapter #(
  parameter int NUM_CP    = 1,
  parameter int DW        = 64,
  parameter int STG_BYTES = 1024,
  parameter int OWB       = 16,                    // executor write-port width in bytes
  // derived
  parameter int NB   = DW / 8,
  parameter int LNB  = $clog2(NB),
  parameter int SIW  = $clog2(STG_BYTES) + 1
) (
  input  wire logic                       clk,
  input  wire logic                       rst_n,
  // ---------------------------------------------------------------- jobs (one per engine)
  input  wire logic [NUM_CP-1:0]          job_valid,
  output logic      [NUM_CP-1:0]          job_ready,
  input  wire logic [NUM_CP*2-1:0]        job_kind,
  input  wire logic [NUM_CP*32-1:0]       job_base,
  input  wire logic [NUM_CP*16-1:0]       job_rows,
  input  wire logic [NUM_CP*32-1:0]       job_rowbytes,
  input  wire logic [NUM_CP*32-1:0]       job_stride,
  input  wire logic [NUM_CP*2-1:0]        job_stg,
  input  wire logic [NUM_CP*SIW-1:0]      job_stg_base,
  input  wire logic [NUM_CP*SIW-1:0]      job_stg_pitch,
  output logic      [NUM_CP-1:0]          job_done,
  output logic      [NUM_CP*3-1:0]        job_err,
  output logic      [NUM_CP*16-1:0]       job_nerr,
  // ---------------------------------------------------------------- IronMemory compute ports
  output logic      [NUM_CP-1:0]          m_req_valid,
  input  wire logic [NUM_CP-1:0]          m_req_ready,
  output logic      [NUM_CP*32-1:0]       m_req_addr,
  output logic      [NUM_CP*3-1:0]        m_req_size,
  output logic      [NUM_CP-1:0]          m_req_we,
  output logic      [NUM_CP*DW-1:0]       m_req_wdata,
  output logic      [NUM_CP*NB-1:0]       m_req_wstrb,
  input  wire logic [NUM_CP-1:0]          m_rsp_valid,
  output logic      [NUM_CP-1:0]          m_rsp_ready,
  input  wire logic [NUM_CP*DW-1:0]       m_rsp_rdata,
  input  wire logic [NUM_CP*3-1:0]        m_rsp_err,
  // ---------------------------------------------------------------- staging
  output logic [STG_BYTES*8-1:0]          stg0_flat,
  output logic [STG_BYTES*8-1:0]          stg1_flat,
  output logic [STG_BYTES*8-1:0]          stg2_flat,
  output logic [STG_BYTES*8-1:0]          stg3_flat,
  input  wire logic                       o_wr_en,
  input  wire logic [SIW-1:0]             o_wr_idx,
  input  wire logic [OWB*8-1:0]           o_wr_data,
  input  wire logic                       stg_clear,
  // ---------------------------------------------------------------- events (per engine)
  output logic      [NUM_CP-1:0]          ev_rd,
  output logic      [NUM_CP-1:0]          ev_wr,
  output logic      [NUM_CP-1:0]          ev_stall,
  output logic      [NUM_CP-1:0]          ev_err,
  output logic      [NUM_CP-1:0]          eng_busy
);
  localparam int CNW = $clog2(NB + 1);

  logic [NUM_CP-1:0]          sw_en;
  logic [NUM_CP*2-1:0]        sw_buf;
  logic [NUM_CP*SIW-1:0]      sw_idx;
  logic [NUM_CP*CNW-1:0]      sw_nbytes;
  logic [NUM_CP*(LNB+1)-1:0]  sw_lane0;
  logic [NUM_CP*DW-1:0]       sw_data;

  genvar e;
  generate
    for (e = 0; e < NUM_CP; e++) begin : g_eng
      sf_compute_mem_engine #(.DW(DW), .STG_BYTES(STG_BYTES)) u_eng (
        .clk, .rst_n,
        .job_valid     (job_valid[e]),
        .job_ready     (job_ready[e]),
        .job_kind      (job_kind[e*2 +: 2]),
        .job_base      (job_base[e*32 +: 32]),
        .job_rows      (job_rows[e*16 +: 16]),
        .job_rowbytes  (job_rowbytes[e*32 +: 32]),
        .job_stride    (job_stride[e*32 +: 32]),
        .job_stg       (job_stg[e*2 +: 2]),
        .job_stg_base  (job_stg_base[e*SIW +: SIW]),
        .job_stg_pitch (job_stg_pitch[e*SIW +: SIW]),
        .job_done      (job_done[e]),
        .job_err       (job_err[e*3 +: 3]),
        .job_nerr      (job_nerr[e*16 +: 16]),
        .m_req_valid   (m_req_valid[e]),
        .m_req_ready   (m_req_ready[e]),
        .m_req_addr    (m_req_addr[e*32 +: 32]),
        .m_req_size    (m_req_size[e*3 +: 3]),
        .m_req_we      (m_req_we[e]),
        .m_req_wdata   (m_req_wdata[e*DW +: DW]),
        .m_req_wstrb   (m_req_wstrb[e*NB +: NB]),
        .m_rsp_valid   (m_rsp_valid[e]),
        .m_rsp_ready   (m_rsp_ready[e]),
        .m_rsp_rdata   (m_rsp_rdata[e*DW +: DW]),
        .m_rsp_err     (m_rsp_err[e*3 +: 3]),
        .stg_rd_flat   (stg3_flat),
        .sw_en         (sw_en[e]),
        .sw_buf        (sw_buf[e*2 +: 2]),
        .sw_idx        (sw_idx[e*SIW +: SIW]),
        .sw_nbytes     (sw_nbytes[e*CNW +: CNW]),
        .sw_lane0      (sw_lane0[e*(LNB+1) +: (LNB+1)]),
        .sw_data       (sw_data[e*DW +: DW]),
        .ev_rd         (ev_rd[e]),
        .ev_wr         (ev_wr[e]),
        .ev_stall      (ev_stall[e]),
        .ev_err        (ev_err[e]),
        .busy          (eng_busy[e])
      );
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // staging storage
  // ---------------------------------------------------------------------------
  logic [STG_BYTES*8-1:0] s0_q, s1_q, s2_q, s3_q;
  assign stg0_flat = s0_q;
  assign stg1_flat = s1_q;
  assign stg2_flat = s2_q;
  assign stg3_flat = s3_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s0_q <= '0; s1_q <= '0; s2_q <= '0; s3_q <= '0;
    end else if (stg_clear) begin
      s0_q <= '0; s1_q <= '0; s2_q <= '0; s3_q <= '0;
    end else begin
      // engine scatter (READ2D responses); engine order = priority, later wins
      for (int en = 0; en < NUM_CP; en++) begin
        if (sw_en[en]) begin
          for (int b = 0; b < NB; b++) begin
            if (b < int'(sw_nbytes[en*CNW +: CNW])) begin
              logic [SIW-1:0] ix;
              logic [7:0]     by;
              ix = sw_idx[en*SIW +: SIW] + SIW'(b);
              by = sw_data[en*DW + (int'(sw_lane0[en*(LNB+1) +: (LNB+1)]) + b) * 8 +: 8];
              case (sw_buf[en*2 +: 2])
                2'd0:    s0_q[int'(ix)*8 +: 8] <= by;
                2'd1:    s1_q[int'(ix)*8 +: 8] <= by;
                2'd2:    s2_q[int'(ix)*8 +: 8] <= by;
                default: ;   // buffer 3 is written only through o_wr_*
              endcase
            end
          end
        end
      end
      // executor write port into the OUT buffer
      if (o_wr_en) begin
        for (int b = 0; b < OWB; b++) begin
          if ((int'(o_wr_idx) + b) < STG_BYTES)
            s3_q[(int'(o_wr_idx) + b)*8 +: 8] <= o_wr_data[b*8 +: 8];
        end
      end
    end
  end
endmodule
`default_nettype wire
