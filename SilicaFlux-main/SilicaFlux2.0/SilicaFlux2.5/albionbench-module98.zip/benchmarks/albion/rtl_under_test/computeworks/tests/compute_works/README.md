# ComputeWorks tests

| File | Role |
|---|---|
| `tb_compute_tile.sv` | **System testbench**, a script interpreter driving the real ports of `sf_compute_tile` (policy, buffer manager, descriptors, BridgeEngine data port, completions, reset, clock enable, CSR, ECC injection, background traffic, external-Citadel stub). Contains no arithmetic and no expected values. Script grammar: header comment of the file. |
| `gen_tests.py` | Generates every suite's script and its expected values from the independent models in `../../model/`. `SUITES` lists them. |
| `tb_adapter.sv` | Unit bench of the memory adapter / engine on the real IronMemory (random 2-D jobs vs a byte-level shadow of memory and of all four staging buffers). |
| `tb_tensor_exec.sv` | Unit bench of the INT8 GEMM executor (reused TC02 inside) on the real IronMemory vs an SV 64-bit reference. |
| `cw_tb_common.svh` | `CHECK` / `TB_FINISH` macros. |

Run through `../../scripts/run_tests.py` (system suites over the configuration matrix) and `../../scripts/run_unit.py` (unit benches).

| Suite | What it proves |
|---|---|
| `p1_single`, `p1_gemm`, `p1_overflow` | one 4x4 INT8 operation; random GEMMs (partial tiles, accumulation, unaligned operands, K up to the staging limit); INT32 wrap |
| `p2_fp32`, `p2_special`, `p2_int32`, `p2_mixed` | FP32 add / mul / FMA bit-exact with exception flags, all rounding modes, special values; INT32; mixed workloads |
| `p3_reject_table`, `p3_validate` | every rejection status and unsupported precision; descriptor fuzz vs the independent validator; no side effects |
| `p3_isolation`, `p3_leak`, `p3_memlayer` | cross-tenant isolation (directed + fuzz vs an independent guard model); revoke / scrub / reassign procedure; IronMemory ownership as the second layer |
| `p3_extcit`, `p3_extcit_hang`, `p3_extcit_noready` | external Citadel: answering, hung (fail closed), never accepting (fail closed) |
| `p3_queues` | multiple queues: completion order == independent arbitration model |
| `p3_backpressure`, `p3_reset`, `p3_clken`, `p3_ecc` | back-pressure on every interface with concurrent bank contention; reset; clock enable; ECC fault injection and memory-error propagation |

A suite's performance-counter dump is compared with an exactly predicted tally (commands, rejects by class, MACs, vector elements, output bytes, scrub bytes, **array-busy cycles**)
and with structural identities between counters.
