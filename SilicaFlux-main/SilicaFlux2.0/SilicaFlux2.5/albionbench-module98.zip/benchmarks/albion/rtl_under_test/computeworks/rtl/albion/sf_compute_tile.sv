// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS
// sf_compute_tile.sv : cloud vector and tensor compute tile (TOP)
// Aureom.AI / SilicaFlux Albion
//
//   submit -> [command queue(s)] -> [scheduler: decode / validate / isolation check]
//          -> [tensor exec | vector exec | clear exec] -> [memory adapter] -> IronMemory
//          -> [completion queue] -> completion record
//
// REUSED, UNMODIFIED, VERIFIED SilicaFlux blocks (third_party/, SHA-256 + provenance):
//   TENSORCORE 02  tensor_systolic_array   INT8 x INT8 -> INT32, 4x4 output stationary
//   HPC M03/M02    hpc_vector_array        FP32 add / mul / fused multiply-add lanes (and INT32)
//   IronMemory P84 sf_iron_memory          banked ECC SRAM, buffer ownership, per-bank arbitration
// NEW in this project: queue, decoder, scheduler, guard (Citadel client + reference), memory
// engines / adapter, executors, counters.  No floating-point arithmetic is implemented here.
//
// LOCAL MEMORY.  The tile OWNS one IronMemory instance as its local operand SRAM.  Its master
// ports are: port 0 = Keystone (domain 0, supervisor), port 1 = BridgeEngine (domain 1, DMA),
// ports 2.. = ComputeWorks (domain 3), NUM_CP of them (1 or 2: the design never assumes more
// SRAM ports than it has).  Keystone also owns IronMemory's buffer-manager and CSR ports.
//
// ISOLATION.  See sf_compute_guard.sv and docs/compute_works/05_ISOLATION.md.  Two layers:
//   (1) tile level, per command: queue-bound domain, region table, destination mask;
//   (2) IronMemory level, per access: buffer ownership / read-write masks (domain 3 only).
//
// NOT CLAIMED: FP64 / FP16 / BF16 (rejected), mid-kernel preemption (none), clock gating
// (only a dispatch enable and a quiescence flag), power / area / timing (no technology data).
// =============================================================================
`timescale 1ns/1ps
`include "sf_compute_defs.svh"
`default_nettype none

module sf_compute_tile #(
  // ------------------------------------------------------------- compute configuration
  parameter int          NUM_LANES       = 4,        // FP32 vector lanes: 1, 2, 4, 8, 16
  parameter int          TENSOR_ROWS     = 4,        // INT8 tensor array rows
  parameter int          TENSOR_COLS     = 4,        // INT8 tensor array columns
  parameter int          NUM_BANKS       = 4,        // local SRAM banks
  parameter int          BANK_DEPTH      = 1024,     // words per bank: capacity = banks * depth * DMA_DW/8
  parameter int          DMA_DW          = 64,       // local-memory / BridgeEngine data width: 64 or 128
  parameter int          CMD_QUEUE_DEPTH = 4,
  parameter int          NUM_QUEUES      = 1,        // 1 = reference; up to 4 protected queues
  parameter int          NUM_CP          = 1,        // compute ports on the local memory: 1 or 2
  parameter int          STG_BYTES       = 1024,     // operand / result staging capacity per buffer
  parameter int          CPL_DEPTH       = 4,
  parameter bit          EN_VECTOR       = 1'b1,     // build the FP32 / INT32 vector path
  parameter bit          EN_INT32        = 1'b1,     // allow INT32 VADD / VMUL
  parameter int          GUARD_MODE      = 1,        // 0 off (NO isolation), 1 reference Citadel, 2 external Citadel
  parameter int          NUM_REGIONS     = 8,
  parameter bit          CLEAR_STAGING   = 1'b1,     // zero the staging buffers after every command
  parameter int          STARVE_LIMIT    = 16,
  parameter logic [31:0] SRAM_BASE       = 32'h1000_0000,
  // local-memory (IronMemory) options passed through
  parameter int          IM_ECC_EN       = 1,
  parameter int          IM_RL           = 1,
  parameter int          IM_BACKEND      = 0,
  parameter int          IM_NUM_DESC     = 16,
  parameter int          IM_GRAN_BYTES   = 256,
  // ------------------------------------------------------------- derived (do not override)
  parameter int          NB      = DMA_DW / 8,
  parameter longint      SRAM_BYTES = longint'(NUM_BANKS) * longint'(BANK_DEPTH) * (longint'(DMA_DW) / 64'd8),
  parameter int          IDW     = sf_iron_pkg::clog2_min1(IM_NUM_DESC),
  parameter int          LEN_W   = $clog2(SRAM_BYTES + 1),
  parameter int          ND      = sf_iron_pkg::NUM_DOMAINS,
  parameter int          QW      = (NUM_QUEUES > 1) ? $clog2(NUM_QUEUES) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic                  clk_en_i,          // dispatch enable (a started command always completes)
  // ------------------------------------------------------------- command submission
  input  wire logic                  sub_valid,
  output logic                       sub_ready,
  input  wire logic [QW-1:0]         sub_q,
  input  wire logic [255:0]          sub_desc,
  // ------------------------------------------------------------- completion
  output logic                       cpl_valid,
  input  wire logic                  cpl_ready,
  output logic [QW-1:0]              cpl_queue,
  output logic [2:0]                 cpl_domain,
  output logic [3:0]                 cpl_dest,
  output logic [15:0]                cpl_tag,
  output logic [7:0]                 cpl_op,
  output logic [`CW_ST_W-1:0]        cpl_status,
  output logic [15:0]                cpl_detail,
  output logic [4:0]                 cpl_fflags,
  output logic [31:0]                cpl_out_bytes,
  output logic [31:0]                cpl_cycles,
  output logic [31:0]                cpl_qwait,
  output logic [31:0]                cpl_seq,
  // ------------------------------------------------------------- management plane (Keystone)
  input  wire logic                  pol_valid,
  output logic                       pol_ready,
  input  wire logic [3:0]            pol_op,
  input  wire logic [3:0]            pol_idx,
  input  wire logic [31:0]           pol_a, pol_b, pol_c,
  output logic                       pol_done,
  output logic [3:0]                 pol_status,
  output logic [NUM_REGIONS-1:0]     reg_valid_o,
  output logic [NUM_REGIONS-1:0]     reg_dirty_o,
  // external Citadel (GUARD_MODE = 2)
  output logic                       cit_req_valid,
  input  wire logic                  cit_req_ready,
  output logic [2:0]                 cit_req_dom,
  output logic                       cit_req_write,
  output logic [31:0]                cit_req_base,
  output logic [39:0]                cit_req_len,
  input  wire logic                  cit_rsp_valid,
  input  wire logic                  cit_rsp_ok,
  input  wire logic [3:0]            cit_rsp_fault,
  // ------------------------------------------------------------- local memory: Keystone master port (domain 0)
  input  wire logic                  ks_req_valid,
  output logic                       ks_req_ready,
  input  wire logic [31:0]           ks_req_addr,
  input  wire logic [2:0]            ks_req_size,
  input  wire logic                  ks_req_we,
  input  wire logic [DMA_DW-1:0]     ks_req_wdata,
  input  wire logic [NB-1:0]         ks_req_wstrb,
  output logic                       ks_rsp_valid,
  input  wire logic                  ks_rsp_ready,
  output logic [DMA_DW-1:0]          ks_rsp_rdata,
  output logic [2:0]                 ks_rsp_err,
  // ------------------------------------------------------------- local memory: BridgeEngine (DMA) master port (domain 1)
  input  wire logic                  br_req_valid,
  output logic                       br_req_ready,
  input  wire logic [31:0]           br_req_addr,
  input  wire logic [2:0]            br_req_size,
  input  wire logic                  br_req_we,
  input  wire logic [DMA_DW-1:0]     br_req_wdata,
  input  wire logic [NB-1:0]         br_req_wstrb,
  output logic                       br_rsp_valid,
  input  wire logic                  br_rsp_ready,
  output logic [DMA_DW-1:0]          br_rsp_rdata,
  output logic [2:0]                 br_rsp_err,
  // ------------------------------------------------------------- local memory: buffer manager + CSR (Keystone)
  input  wire logic                  bm_cmd_valid,
  output logic                       bm_cmd_ready,
  input  wire logic [2:0]            bm_cmd_op,
  input  wire logic [2:0]            bm_cmd_requester,
  input  wire logic [IDW-1:0]        bm_cmd_id,
  input  wire logic [2:0]            bm_cmd_btype,
  input  wire logic [31:0]           bm_cmd_start,
  input  wire logic [LEN_W-1:0]      bm_cmd_len,
  input  wire logic [2:0]            bm_cmd_owner,
  input  wire logic [ND-1:0]         bm_cmd_rd_mask,
  input  wire logic [ND-1:0]         bm_cmd_wr_mask,
  output logic                       bm_rsp_valid,
  output logic [3:0]                 bm_rsp_status,
  output logic [IDW-1:0]             bm_rsp_id,
  output logic [31:0]                bm_rsp_start,
  output logic [LEN_W-1:0]           bm_rsp_len,
  output logic [7:0]                 bm_rsp_err_bits,
  input  wire logic                  csr_valid,
  input  wire logic                  csr_we,
  input  wire logic [11:0]           csr_addr,
  input  wire logic [31:0]           csr_wdata,
  output logic                       csr_rvalid,
  output logic [31:0]                csr_rdata,
  output logic                       csr_err,
  output logic                       init_done,
  output logic                       irq,
  // ------------------------------------------------------------- status / performance
  output logic                       busy_o,
  output logic                       idle_o,            // no command in flight
  output logic                       clk_gate_ok_o,     // idle, queues empty, completions drained, engines idle
  input  wire logic                  perf_clear,
  input  wire logic [5:0]            perf_sel,
  output logic [39:0]                perf_val,
  output logic [`CW_PC_N*40-1:0]     perf_flat
);
  // ---------------------------------------------------------------------------
  // derived constants
  // ---------------------------------------------------------------------------
  localparam int SIW    = $clog2(STG_BYTES) + 1;
  localparam int OWB    = ((4 * TENSOR_COLS) > (4 * NUM_LANES)) ? 4 * TENSOR_COLS : 4 * NUM_LANES;
  localparam int A_PITCH = STG_BYTES / TENSOR_ROWS;
  localparam int KMAX   = (STG_BYTES / TENSOR_ROWS < STG_BYTES / TENSOR_COLS) ? STG_BYTES / TENSOR_ROWS
                                                                              : STG_BYTES / TENSOR_COLS;
  localparam int NP     = 2 + NUM_CP;
  localparam int REGION_LOG2 = $clog2(IM_GRAN_BYTES);

  function automatic logic [23:0] mk_pdm(input int ncp);
    logic [23:0] r;
    r = 24'd0;
    r[5:3] = 3'd1;                                   // port 1 = BridgeEngine
    for (int i = 0; i < ncp; i++) r[3*(2+i) +: 3] = 3'd3;   // ports 2.. = ComputeWorks
    mk_pdm = r;
  endfunction

  // Illegal parameter sets fail ELABORATION in every tool (the idiom of the sibling projects): the taken branch instantiates a module
  // that does not exist.  (An `initial $fatal` would only fire when a simulation starts, not at lint or synthesis.)
  generate
    if (NUM_CP < 1 || NUM_CP > 2) begin : g_bad_ncp
      sf_compute_tile_param_error_NUM_CP_must_be_1_or_2 u_err ();
    end
    if (NUM_QUEUES < 1 || NUM_QUEUES > 4) begin : g_bad_nq
      sf_compute_tile_param_error_NUM_QUEUES_must_be_1_to_4 u_err ();
    end
    if (DMA_DW != 64 && DMA_DW != 128) begin : g_bad_dw
      sf_compute_tile_param_error_DMA_DW_must_be_64_or_128 u_err ();
    end
    if (STG_BYTES < 64 || (STG_BYTES & (STG_BYTES - 1)) != 0) begin : g_bad_stg
      sf_compute_tile_param_error_STG_BYTES_must_be_a_power_of_two_ge_64 u_err ();
    end
    if (TENSOR_ROWS < 1 || TENSOR_COLS < 1) begin : g_bad_arr
      sf_compute_tile_param_error_tensor_array_dimensions_must_be_ge_1 u_err ();
    end
    if (GUARD_MODE < 0 || GUARD_MODE > 2) begin : g_bad_guard
      sf_compute_tile_param_error_GUARD_MODE_must_be_0_1_or_2 u_err ();
    end
    if (SRAM_BYTES > (64'd1 << 30)) begin : g_bad_sram
      sf_compute_tile_param_error_local_SRAM_larger_than_1_GiB_unsupported u_err ();
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // free-running cycle counter (queue time stamps, command timing)
  // ---------------------------------------------------------------------------
  logic [31:0] now_q;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) now_q <= '0; else now_q <= now_q + 32'd1;

  // ---------------------------------------------------------------------------
  // command queues
  // ---------------------------------------------------------------------------
  localparam int QCW = $clog2(CMD_QUEUE_DEPTH + 1);
  logic [NUM_QUEUES-1:0]      q_head_valid, q_pop;
  logic [NUM_QUEUES*256-1:0]  q_head_desc;
  logic [NUM_QUEUES*32-1:0]   q_head_ts;
  logic [NUM_QUEUES*QCW-1:0]  q_occ;
  logic                       q_ev_push, q_ev_bad;

  sf_compute_command_queue #(.NQ(NUM_QUEUES), .DEPTH(CMD_QUEUE_DEPTH)) u_queue (
    .clk, .rst_n, .now(now_q),
    .sub_valid, .sub_ready, .sub_q, .sub_desc,
    .head_valid(q_head_valid), .head_desc(q_head_desc), .head_ts(q_head_ts), .pop(q_pop),
    .occupancy(q_occ), .ev_push(q_ev_push), .ev_bad_queue(q_ev_bad));

  // ---------------------------------------------------------------------------
  // guard (Citadel client + reference Citadel + policy)
  // ---------------------------------------------------------------------------
  logic                       g_pol_busy, g_pol_acc;
  logic                       g_scrub_start;
  logic [31:0]                g_scrub_base, g_scrub_len;
  logic [NUM_QUEUES-1:0]      g_q_bound, g_q_en;
  logic [NUM_QUEUES*3-1:0]    g_q_dom;
  logic [NUM_QUEUES*`CW_PRIO_W-1:0] g_q_prio;
  logic [NUM_QUEUES*4-1:0]    g_q_dest, g_q_quantum;
  logic [NUM_QUEUES*32-1:0]   g_q_budget;
  logic [8*16-1:0]            g_dest_mask;
  logic                       chk_valid, chk_ready, chk_write, chk_rsp_valid, chk_rsp_ok;
  logic [2:0]                 chk_dom;
  logic [31:0]                chk_base;
  logic [39:0]                chk_len;
  logic [3:0]                 chk_rsp_fault;
  logic                       sch_idle;
  logic                       clr_done;
  logic [2:0]                 clr_err;

  sf_compute_guard #(.NQ(NUM_QUEUES), .NREG(NUM_REGIONS), .MODE(GUARD_MODE), .SRAM_BASE(SRAM_BASE),
                     .SRAM_BYTES(SRAM_BYTES), .REGION_LOG2(REGION_LOG2)) u_guard (
    .clk, .rst_n,
    .pol_valid, .pol_ready, .pol_op, .pol_idx, .pol_a, .pol_b, .pol_c, .pol_done, .pol_status,
    .quiescent_i(sch_idle), .pol_busy(g_pol_busy), .pol_acc(g_pol_acc),
    .scrub_start(g_scrub_start), .scrub_base(g_scrub_base), .scrub_len(g_scrub_len),
    .scrub_done(clr_done), .scrub_err(clr_err),
    .q_bound(g_q_bound), .q_en(g_q_en), .q_dom(g_q_dom), .q_prio(g_q_prio), .q_dest(g_q_dest),
    .q_quantum(g_q_quantum), .q_budget(g_q_budget), .dest_mask_flat(g_dest_mask),
    .chk_valid, .chk_ready, .chk_dom, .chk_write, .chk_base, .chk_len,
    .chk_rsp_valid, .chk_rsp_ok, .chk_rsp_fault,
    .cit_req_valid, .cit_req_ready, .cit_req_dom, .cit_req_write, .cit_req_base, .cit_req_len,
    .cit_rsp_valid, .cit_rsp_ok, .cit_rsp_fault,
    .reg_valid_o, .reg_dirty_o);

  // ---------------------------------------------------------------------------
  // scheduler
  // ---------------------------------------------------------------------------
  logic        tx_start, tx_ready, tx_acc, tx_done;
  logic [15:0] tx_m, tx_n, tx_k, tx_detail;
  logic [31:0] tx_a, tx_b, tx_c, tx_d, tx_out_bytes;
  logic [`CW_ST_W-1:0] tx_status;
  logic [47:0] tx_macs;
  logic [39:0] tx_array_busy;
  logic        tx_ph_load, tx_ph_compute, tx_ph_store;

  logic        vx_start, vx_ready, vx_done;
  logic [7:0]  vx_op, vx_etype;
  logic [2:0]  vx_rm;
  logic [31:0] vx_vl, vx_a, vx_b, vx_c, vx_d, vx_out_bytes;
  logic [`CW_ST_W-1:0] vx_status;
  logic [15:0] vx_detail;
  logic [4:0]  vx_fflags;
  logic [39:0] vx_active;
  logic        vx_ph_load, vx_ph_compute, vx_ph_store;

  logic        cx_start, cx_ready;
  logic [31:0] cx_base, cx_len;
  logic        cx_done_s;
  logic        stg_clear;

  logic        s_ev_cpl, s_ev_gemm, s_ev_vec, s_busy, s_ph_load, s_ph_compute, s_ph_store, s_ev_stall_cpl;
  logic [`CW_ST_W-1:0] s_ev_status;
  logic [31:0] s_ev_qwait, s_ev_exec, s_ev_vec_elems, s_ev_out_bytes, s_ev_scrub_bytes;
  logic [47:0] s_ev_macs;
  logic [39:0] s_ev_array_busy, s_ev_vec_active;

  sf_compute_scheduler #(.NQ(NUM_QUEUES), .CPL_DEPTH(CPL_DEPTH), .STARVE_LIMIT(STARVE_LIMIT),
                         .CLEAR_STAGING(CLEAR_STAGING), .SRAM_BASE(SRAM_BASE), .SRAM_BYTES(SRAM_BYTES),
                         .KMAX(KMAX), .EN_VECTOR(EN_VECTOR), .EN_INT32(EN_INT32)) u_sched (
    .clk, .rst_n, .clk_en_i, .now(now_q),
    .head_valid(q_head_valid), .head_desc(q_head_desc), .head_ts(q_head_ts), .pop(q_pop),
    .q_bound(g_q_bound), .q_en(g_q_en), .q_dom(g_q_dom), .q_prio(g_q_prio), .q_dest(g_q_dest),
    .q_quantum(g_q_quantum), .q_budget(g_q_budget), .dest_mask_flat(g_dest_mask),
    .pol_busy(g_pol_busy), .pol_acc(g_pol_acc), .idle_o(sch_idle),
    .chk_valid, .chk_ready, .chk_dom, .chk_write, .chk_base, .chk_len,
    .chk_rsp_valid, .chk_rsp_ok, .chk_rsp_fault,
    .tx_start, .tx_ready, .tx_m, .tx_n, .tx_k, .tx_a, .tx_b, .tx_c, .tx_d, .tx_acc,
    .tx_done, .tx_status, .tx_detail, .tx_out_bytes, .tx_macs, .tx_array_busy,
    .tx_ph_load, .tx_ph_compute, .tx_ph_store,
    .vx_start, .vx_ready, .vx_op, .vx_etype, .vx_rm, .vx_vl, .vx_a, .vx_b, .vx_c, .vx_d,
    .vx_done, .vx_status, .vx_detail, .vx_out_bytes, .vx_fflags, .vx_active,
    .vx_ph_load, .vx_ph_compute, .vx_ph_store,
    .cx_start, .cx_ready, .cx_base, .cx_len, .cx_done(clr_done), .cx_err(clr_err),
    .stg_clear,
    .cpl_valid, .cpl_ready, .cpl_queue, .cpl_domain, .cpl_dest, .cpl_tag, .cpl_op, .cpl_status, .cpl_detail,
    .cpl_fflags, .cpl_out_bytes, .cpl_cycles, .cpl_qwait, .cpl_seq,
    .busy_o(s_busy), .ph_load_o(s_ph_load), .ph_compute_o(s_ph_compute), .ph_store_o(s_ph_store),
    .ev_cpl(s_ev_cpl), .ev_status(s_ev_status), .ev_qwait(s_ev_qwait), .ev_exec(s_ev_exec),
    .ev_gemm(s_ev_gemm), .ev_vec(s_ev_vec), .ev_macs(s_ev_macs), .ev_array_busy(s_ev_array_busy),
    .ev_vec_elems(s_ev_vec_elems), .ev_vec_active(s_ev_vec_active), .ev_out_bytes(s_ev_out_bytes),
    .ev_scrub_bytes(s_ev_scrub_bytes), .ev_stall_cpl(s_ev_stall_cpl));

  assign busy_o = s_busy;
  assign idle_o = sch_idle;

  // ---------------------------------------------------------------------------
  // executors
  // ---------------------------------------------------------------------------
  // adapter job interface (one set per executor, OR-combined: the idle ones drive zeros)
  logic [NUM_CP-1:0]      aj_valid, aj_ready, aj_done;
  logic [NUM_CP*2-1:0]    aj_kind, aj_stg;
  logic [NUM_CP*32-1:0]   aj_base, aj_rowbytes, aj_stride;
  logic [NUM_CP*16-1:0]   aj_rows, aj_nerr;
  logic [NUM_CP*SIW-1:0]  aj_stg_base, aj_stg_pitch;
  logic [NUM_CP*3-1:0]    aj_err;

  logic [NUM_CP-1:0]      t_valid, v_valid, c_valid;
  logic [NUM_CP*2-1:0]    t_kind, v_kind, c_kind, t_stg, v_stg, c_stg;
  logic [NUM_CP*32-1:0]   t_base, v_base, c_base, t_rowbytes, v_rowbytes, c_rowbytes, t_stride, v_stride, c_stride;
  logic [NUM_CP*16-1:0]   t_rows, v_rows, c_rows;
  logic [NUM_CP*SIW-1:0]  t_stg_base, v_stg_base, c_stg_base, t_stg_pitch, v_stg_pitch, c_stg_pitch;

  logic [STG_BYTES*8-1:0] stg0, stg1, stg2, stg3;
  logic                   t_o_en, v_o_en, o_wr_en;
  logic [SIW-1:0]         t_o_idx, v_o_idx, o_wr_idx;
  logic [OWB*8-1:0]       t_o_data, v_o_data, o_wr_data;

  sf_compute_tensor_exec #(.ROWS(TENSOR_ROWS), .COLS(TENSOR_COLS), .NUM_CP(NUM_CP), .STG_BYTES(STG_BYTES),
                           .OWB(OWB), .A_PITCH(A_PITCH)) u_tx (
    .clk, .rst_n,
    .start(tx_start), .ready(tx_ready),
    .m_i(tx_m), .n_i(tx_n), .k_i(tx_k), .src_a_i(tx_a), .src_b_i(tx_b), .src_c_i(tx_c), .dst_i(tx_d), .acc_i(tx_acc),
    .done(tx_done), .status_o(tx_status), .detail_o(tx_detail), .out_bytes_o(tx_out_bytes), .macs_o(tx_macs),
    .array_busy_o(tx_array_busy), .ph_load(tx_ph_load), .ph_compute(tx_ph_compute), .ph_store(tx_ph_store),
    .job_valid(t_valid), .job_ready(aj_ready), .job_kind(t_kind), .job_base(t_base), .job_rows(t_rows),
    .job_rowbytes(t_rowbytes), .job_stride(t_stride), .job_stg(t_stg), .job_stg_base(t_stg_base),
    .job_stg_pitch(t_stg_pitch), .job_done(aj_done), .job_err(aj_err),
    .stg0_flat(stg0), .stg1_flat(stg1), .stg2_flat(stg2),
    .o_wr_en(t_o_en), .o_wr_idx(t_o_idx), .o_wr_data(t_o_data));

  generate
    if (EN_VECTOR) begin : g_vec
      sf_compute_vector_exec #(.NUM_LANES(NUM_LANES), .NUM_CP(NUM_CP), .STG_BYTES(STG_BYTES), .OWB(OWB)) u_vx (
        .clk, .rst_n,
        .start(vx_start), .ready(vx_ready),
        .op_i(vx_op), .etype_i(vx_etype), .rm_i(vx_rm), .vl_i(vx_vl),
        .src_a_i(vx_a), .src_b_i(vx_b), .src_c_i(vx_c), .dst_i(vx_d),
        .done(vx_done), .status_o(vx_status), .detail_o(vx_detail), .out_bytes_o(vx_out_bytes),
        .fflags_o(vx_fflags), .active_o(vx_active),
        .ph_load(vx_ph_load), .ph_compute(vx_ph_compute), .ph_store(vx_ph_store),
        .job_valid(v_valid), .job_ready(aj_ready), .job_kind(v_kind), .job_base(v_base), .job_rows(v_rows),
        .job_rowbytes(v_rowbytes), .job_stride(v_stride), .job_stg(v_stg), .job_stg_base(v_stg_base),
        .job_stg_pitch(v_stg_pitch), .job_done(aj_done), .job_err(aj_err),
        .stg0_flat(stg0), .stg1_flat(stg1), .stg2_flat(stg2),
        .o_wr_en(v_o_en), .o_wr_idx(v_o_idx), .o_wr_data(v_o_data));
    end else begin : g_novec
      assign vx_ready = 1'b1; assign vx_done = 1'b0; assign vx_status = `CW_ST_OK; assign vx_detail = '0;
      assign vx_out_bytes = '0; assign vx_fflags = '0; assign vx_active = '0;
      assign vx_ph_load = 1'b0; assign vx_ph_compute = 1'b0; assign vx_ph_store = 1'b0;
      assign v_valid = '0; assign v_kind = '0; assign v_base = '0; assign v_rows = '0; assign v_rowbytes = '0;
      assign v_stride = '0; assign v_stg = '0; assign v_stg_base = '0; assign v_stg_pitch = '0;
      assign v_o_en = 1'b0; assign v_o_idx = '0; assign v_o_data = '0;
    end
  endgenerate

  // clear executor, shared by the CLEAR command and the guard's SCRUB
  logic        clr_start, clr_ready, clr_active;
  logic [31:0] clr_base, clr_len;
  logic        clr_owner_guard_q;
  assign clr_start = cx_start | g_scrub_start;
  assign clr_base  = g_scrub_start ? g_scrub_base : cx_base;
  assign clr_len   = g_scrub_start ? g_scrub_len  : cx_len;
  assign cx_ready  = clr_ready;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) clr_owner_guard_q <= 1'b0;
    else if (g_scrub_start) clr_owner_guard_q <= 1'b1;
    else if (cx_start)      clr_owner_guard_q <= 1'b0;

  sf_compute_clear_exec #(.NUM_CP(NUM_CP), .SIW(SIW)) u_cx (
    .clk, .rst_n, .start(clr_start), .ready(clr_ready), .base(clr_base), .len(clr_len),
    .done(clr_done), .err(clr_err), .active(clr_active),
    .job_valid(c_valid), .job_ready(aj_ready), .job_kind(c_kind), .job_base(c_base), .job_rows(c_rows),
    .job_rowbytes(c_rowbytes), .job_stride(c_stride), .job_stg(c_stg), .job_stg_base(c_stg_base),
    .job_stg_pitch(c_stg_pitch), .job_done(aj_done), .job_err(aj_err));

  // executors are mutually exclusive in time: combine job requests by OR, result-buffer writes by enable
  always_comb begin
    aj_valid     = t_valid | v_valid | c_valid;
    aj_kind      = t_kind | v_kind | c_kind;
    aj_base      = t_base | v_base | c_base;
    aj_rows      = t_rows | v_rows | c_rows;
    aj_rowbytes  = t_rowbytes | v_rowbytes | c_rowbytes;
    aj_stride    = t_stride | v_stride | c_stride;
    aj_stg       = t_stg | v_stg | c_stg;
    aj_stg_base  = t_stg_base | v_stg_base | c_stg_base;
    aj_stg_pitch = t_stg_pitch | v_stg_pitch | c_stg_pitch;
    o_wr_en      = t_o_en | v_o_en;
    o_wr_idx     = t_o_en ? t_o_idx  : v_o_idx;
    o_wr_data    = t_o_en ? t_o_data : v_o_data;
  end

  // ---------------------------------------------------------------------------
  // memory adapter + IronMemory
  // ---------------------------------------------------------------------------
  logic [NUM_CP-1:0]      a_req_valid, a_req_ready, a_req_we, a_rsp_valid, a_rsp_ready;
  logic [NUM_CP*32-1:0]   a_req_addr;
  logic [NUM_CP*3-1:0]    a_req_size, a_rsp_err;
  logic [NUM_CP*DMA_DW-1:0] a_req_wdata, a_rsp_rdata;
  logic [NUM_CP*NB-1:0]   a_req_wstrb;
  logic [NUM_CP-1:0]      ev_rd, ev_wr, ev_stall, ev_err, eng_busy;

  sf_compute_memory_adapter #(.NUM_CP(NUM_CP), .DW(DMA_DW), .STG_BYTES(STG_BYTES), .OWB(OWB)) u_adapter (
    .clk, .rst_n,
    .job_valid(aj_valid), .job_ready(aj_ready), .job_kind(aj_kind), .job_base(aj_base), .job_rows(aj_rows),
    .job_rowbytes(aj_rowbytes), .job_stride(aj_stride), .job_stg(aj_stg), .job_stg_base(aj_stg_base),
    .job_stg_pitch(aj_stg_pitch), .job_done(aj_done), .job_err(aj_err), .job_nerr(aj_nerr),
    .m_req_valid(a_req_valid), .m_req_ready(a_req_ready), .m_req_addr(a_req_addr), .m_req_size(a_req_size),
    .m_req_we(a_req_we), .m_req_wdata(a_req_wdata), .m_req_wstrb(a_req_wstrb),
    .m_rsp_valid(a_rsp_valid), .m_rsp_ready(a_rsp_ready), .m_rsp_rdata(a_rsp_rdata), .m_rsp_err(a_rsp_err),
    .stg0_flat(stg0), .stg1_flat(stg1), .stg2_flat(stg2), .stg3_flat(stg3),
    .o_wr_en, .o_wr_idx, .o_wr_data, .stg_clear,
    .ev_rd, .ev_wr, .ev_stall, .ev_err, .eng_busy);

  logic [NP-1:0]          im_req_valid, im_req_ready, im_rsp_valid, im_rsp_ready, im_req_we;
  logic [NP*32-1:0]       im_req_addr;
  logic [NP*3-1:0]        im_req_size, im_rsp_err;
  logic [NP*DMA_DW-1:0]   im_req_wdata, im_rsp_rdata;
  logic [NP*NB-1:0]       im_req_wstrb;

  always_comb begin
    im_req_valid = '0; im_req_addr = '0; im_req_size = '0; im_req_we = '0; im_req_wdata = '0; im_req_wstrb = '0;
    im_rsp_ready = '1;
    // port 0: Keystone
    im_req_valid[0]               = ks_req_valid;
    im_req_addr[0 +: 32]          = ks_req_addr;
    im_req_size[0 +: 3]           = ks_req_size;
    im_req_we[0]                  = ks_req_we;
    im_req_wdata[0 +: DMA_DW]     = ks_req_wdata;
    im_req_wstrb[0 +: NB]         = ks_req_wstrb;
    im_rsp_ready[0]               = ks_rsp_ready;
    // port 1: BridgeEngine
    im_req_valid[1]               = br_req_valid;
    im_req_addr[32 +: 32]         = br_req_addr;
    im_req_size[3 +: 3]           = br_req_size;
    im_req_we[1]                  = br_req_we;
    im_req_wdata[DMA_DW +: DMA_DW] = br_req_wdata;
    im_req_wstrb[NB +: NB]        = br_req_wstrb;
    im_rsp_ready[1]               = br_rsp_ready;
    // ports 2..: ComputeWorks engines
    for (int e = 0; e < NUM_CP; e++) begin
      im_req_valid[2+e]                     = a_req_valid[e];
      im_req_addr[(2+e)*32 +: 32]           = a_req_addr[e*32 +: 32];
      im_req_size[(2+e)*3 +: 3]             = a_req_size[e*3 +: 3];
      im_req_we[2+e]                        = a_req_we[e];
      im_req_wdata[(2+e)*DMA_DW +: DMA_DW]  = a_req_wdata[e*DMA_DW +: DMA_DW];
      im_req_wstrb[(2+e)*NB +: NB]          = a_req_wstrb[e*NB +: NB];
      im_rsp_ready[2+e]                     = a_rsp_ready[e];
    end
  end
  assign ks_req_ready = im_req_ready[0];
  assign br_req_ready = im_req_ready[1];
  assign ks_rsp_valid = im_rsp_valid[0];
  assign br_rsp_valid = im_rsp_valid[1];
  assign ks_rsp_rdata = im_rsp_rdata[0 +: DMA_DW];
  assign br_rsp_rdata = im_rsp_rdata[DMA_DW +: DMA_DW];
  assign ks_rsp_err   = im_rsp_err[0 +: 3];
  assign br_rsp_err   = im_rsp_err[3 +: 3];
  assign a_req_ready  = im_req_ready[2 +: NUM_CP];
  assign a_rsp_valid  = im_rsp_valid[2 +: NUM_CP];
  assign a_rsp_rdata  = im_rsp_rdata[2*DMA_DW +: NUM_CP*DMA_DW];
  assign a_rsp_err    = im_rsp_err[2*3 +: NUM_CP*3];

  sf_iron_memory #(
    .NUM_PORTS(NP), .PORT_DOMAIN_MAP(mk_pdm(NUM_CP)), .AW(32), .DW(DMA_DW), .NUM_BANKS(NUM_BANKS),
    .BANK_DEPTH(BANK_DEPTH), .RL(IM_RL), .SRAM_BASE(SRAM_BASE), .ECC_EN(IM_ECC_EN), .BACKEND(IM_BACKEND),
    .NUM_DESC(IM_NUM_DESC), .GRAN_BYTES(IM_GRAN_BYTES), .EXT_EN(0)
  ) u_im (
    .clk, .rst_n,
    .m_req_valid(im_req_valid), .m_req_ready(im_req_ready), .m_req_addr(im_req_addr), .m_req_size(im_req_size),
    .m_req_we(im_req_we), .m_req_wdata(im_req_wdata), .m_req_wstrb(im_req_wstrb),
    .m_rsp_valid(im_rsp_valid), .m_rsp_ready(im_rsp_ready), .m_rsp_rdata(im_rsp_rdata), .m_rsp_err(im_rsp_err),
    .m_rsp_ecc_corr(),
    .bm_cmd_valid, .bm_cmd_ready, .bm_cmd_op, .bm_cmd_requester, .bm_cmd_id, .bm_cmd_btype, .bm_cmd_start,
    .bm_cmd_len, .bm_cmd_owner, .bm_cmd_rd_mask, .bm_cmd_wr_mask,
    .bm_rsp_valid, .bm_rsp_status, .bm_rsp_id, .bm_rsp_in_use(), .bm_rsp_btype(), .bm_rsp_start, .bm_rsp_len,
    .bm_rsp_owner(), .bm_rsp_rd_mask(), .bm_rsp_wr_mask(), .bm_rsp_err_bits,
    .csr_valid, .csr_we, .csr_addr, .csr_wdata, .csr_rvalid, .csr_rdata, .csr_err,
    .ext_cmd_valid(), .ext_cmd_ready(1'b1), .ext_cmd_we(), .ext_cmd_addr(), .ext_cmd_wdata(), .ext_cmd_wstrb(),
    .ext_cmd_tag(), .ext_rsp_valid(1'b0), .ext_rsp_ready(), .ext_rsp_rdata('0), .ext_rsp_err(1'b0), .ext_rsp_tag('0),
    .init_done, .irq,
    .trc_valid(), .trc_port(), .trc_seq(), .trc_we(), .trc_word(), .trc_be(), .trc_wdata());

  // ---------------------------------------------------------------------------
  // quiescence / clock-gate-ready
  // ---------------------------------------------------------------------------
  assign clk_gate_ok_o = sch_idle && (q_head_valid == '0) && !cpl_valid && (eng_busy == '0) && !g_pol_busy;

  // ---------------------------------------------------------------------------
  // performance counters
  // ---------------------------------------------------------------------------
  logic [31:0] scrub_bytes_pol;
  assign scrub_bytes_pol = (clr_done && clr_owner_guard_q && (clr_err == 3'd0)) ? g_scrub_len : 32'd0;

  sf_compute_perf #(.NUM_CP(NUM_CP), .TENSOR_PE(TENSOR_ROWS * TENSOR_COLS), .NUM_LANES(NUM_LANES)) u_perf (
    .clk, .rst_n, .clear(perf_clear), .sel(perf_sel), .val(perf_val), .cnt_flat(perf_flat),
    .clk_en(clk_en_i), .busy(s_busy), .ph_load(s_ph_load), .ph_compute(s_ph_compute), .ph_store(s_ph_store),
    .ev_cmd_in(q_ev_push), .ev_drop_badq(q_ev_bad),
    .ev_cpl(s_ev_cpl), .ev_status(s_ev_status), .ev_qwait(s_ev_qwait), .ev_exec(s_ev_exec),
    .ev_gemm(s_ev_gemm), .ev_vec(s_ev_vec), .ev_macs(s_ev_macs), .ev_array_busy(s_ev_array_busy),
    .ev_vec_elems(s_ev_vec_elems), .ev_vec_active(s_ev_vec_active), .ev_out_bytes(s_ev_out_bytes),
    .ev_scrub_bytes(s_ev_scrub_bytes), .ev_scrub_bytes_pol(scrub_bytes_pol), .ev_stall_cpl(s_ev_stall_cpl),
    .ev_rd, .ev_wr, .ev_stall, .ev_err);

  // ---------------------------------------------------------------------------
  // simulation-only invariants
  // ---------------------------------------------------------------------------
  // synthesis translate_off
  always_ff @(posedge clk) if (rst_n) begin
    for (int e = 0; e < NUM_CP; e++)
      if ((int'(t_valid[e]) + int'(v_valid[e]) + int'(c_valid[e])) > 1)
        $error("sf_compute_tile: two executors drive the same memory engine in one cycle");
    if (t_o_en && v_o_en) $error("sf_compute_tile: two executors write the OUT buffer in one cycle");
    // a completion must never be delivered to a destination its domain may not use
    if (cpl_valid && !g_dest_mask[cpl_domain*16 + cpl_dest])
      $error("sf_compute_tile: completion presented to a destination not allowed for its domain");
  end
  // synthesis translate_on
endmodule
`default_nettype wire
