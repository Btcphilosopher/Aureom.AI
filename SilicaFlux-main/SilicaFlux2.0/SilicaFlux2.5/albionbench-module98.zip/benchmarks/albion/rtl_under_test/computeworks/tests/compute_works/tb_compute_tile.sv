// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS : tb_compute_tile
//
// System testbench for sf_compute_tile.  It is a SCRIPT INTERPRETER: all test content (descriptors,
// operand bytes, EXPECTED results and completion fields) comes from generated script files whose
// expected values are computed by the independent Python models in model/.  The testbench itself
// contains no arithmetic reference -- it only drives the real ports and compares.
//
// Run:   sim +script=<file.cwt> [+seed=N] [+cplbp=P]  (P = completion-ready probability in %, default 100)
//
// Script lines (hex tokens; '#' starts a comment line):
//   00                         RESET   (async assert, release, wait for the local-memory init sweep)
//   02 op id bt start len owner rd wr exp_status      buffer-manager command (exp ff = any)
//   03 addr n b0 .. b(n-1)     BWRITE  bytes through the BridgeEngine port
//   04 addr n e0 .. e(n-1)     BREAD   bytes through the BridgeEngine port, compare (e >= 100 = don't care)
//   05 q w0 .. w7              SUBMIT  one descriptor into queue q
//   06 q dom dest tag op st detail ff outbytes   CPL: wait for ONE completion and compare
//                                                 (ffffffff = don't care)
//   07 op idx a b c exp        POL     management-plane policy op, expect pol_status (ff = any)
//   08 cycles                  DELAY
//   0a v                       CLKEN   clk_en_i
//   0d cycles                  NOCPL   run N cycles and require that NO completion appears
//   0e                         PERF    print all performance counters ("PERF idx value")
//   0f addr                    CSR     read an IronMemory CSR ("CSR addr value")
//   10 q dom dest tag op st detail ff outbytes seq   CPLANY: wait for one completion, print it, compare
//   11 addr n b0 ..            KWRITE  bytes through the KEYSTONE port (raw, expects an error response count)
//   12 expect_err_cnt          KERRS   check how many Keystone/Bridge responses so far were errors
//   13 n                       ONCPL   print n completions as "CPLREC ..." lines for the Python scheduler model
//   14 pct                     CPLBP   set completion ready probability
//   15 addr n e0 ..            BREADERR  bridge read expected to FAIL (error response)  -- negative tests
//   16 tag                     MARK    print "MARK tag" (progress / for the runner)
//   17 v                       SUBHOLD v=1: hold the next SUBMIT until ... (reserved)
//   ff                         END     final checks, banner
// =============================================================================
`timescale 1ns/1ps
`include "cw_tb_common.svh"
`include "sf_compute_defs.svh"

module tb_compute_tile;
  // ------------------------------------------------------------------ DUT configuration (override with -G)
  parameter int NUM_LANES       = 4;
  parameter int TENSOR_ROWS     = 4;
  parameter int TENSOR_COLS     = 4;
  parameter int NUM_BANKS       = 4;
  parameter int BANK_DEPTH      = 512;
  parameter int DMA_DW          = 64;
  parameter int CMD_QUEUE_DEPTH = 4;
  parameter int NUM_QUEUES      = 1;
  parameter int NUM_CP          = 1;
  parameter int STG_BYTES       = 1024;
  parameter int CPL_DEPTH       = 4;
  parameter bit EN_VECTOR       = 1'b1;
  parameter int GUARD_MODE      = 1;
  parameter bit CLEAR_STAGING   = 1'b1;
  parameter int IM_ECC_EN       = 1;
  parameter int IM_RL           = 1;
  parameter int STARVE_LIMIT    = 16;
  parameter int EXT_CIT_LAT     = 2;       // external Citadel stub latency (GUARD_MODE = 2)
  parameter int EXT_CIT_HANG    = 0;       // 1: the external Citadel accepts a query but never answers; 2: it never accepts a query (fail-closed tests)

  localparam int NB    = DMA_DW / 8;
  localparam longint SRAM_BYTES = longint'(NUM_BANKS) * longint'(BANK_DEPTH) * (longint'(DMA_DW) / 64'd8);
  localparam logic [31:0] BASE = 32'h1000_0000;
  localparam int IDW   = 4;
  localparam int LEN_W = $clog2(SRAM_BYTES + 1);
  localparam int QW    = (NUM_QUEUES > 1) ? $clog2(NUM_QUEUES) : 1;
  localparam int NREG  = 8;

  int tb_errors = 0, tb_checks = 0;
  int seed = 1;
  string script_name;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ------------------------------------------------------------------ DUT
  logic                  clk_en_i;
  logic                  sub_valid, sub_ready;
  logic [QW-1:0]         sub_q;
  logic [255:0]          sub_desc;
  logic                  cpl_valid, cpl_ready;
  logic [QW-1:0]         cpl_queue;
  logic [2:0]            cpl_domain;
  logic [3:0]            cpl_dest;
  logic [15:0]           cpl_tag;
  logic [7:0]            cpl_op;
  logic [`CW_ST_W-1:0]   cpl_status;
  logic [15:0]           cpl_detail;
  logic [4:0]            cpl_fflags;
  logic [31:0]           cpl_out_bytes, cpl_cycles, cpl_qwait, cpl_seq;
  logic                  pol_valid, pol_ready, pol_done;
  logic [3:0]            pol_op, pol_idx, pol_status;
  logic [31:0]           pol_a, pol_b, pol_c;
  logic [NREG-1:0]       reg_valid_o, reg_dirty_o;
  logic                  cit_req_valid, cit_req_ready, cit_req_write, cit_rsp_valid, cit_rsp_ok;
  logic [2:0]            cit_req_dom;
  logic [31:0]           cit_req_base;
  logic [39:0]           cit_req_len;
  logic [3:0]            cit_rsp_fault;
  logic                  ks_req_valid, ks_req_ready, ks_req_we, ks_rsp_valid, ks_rsp_ready;
  logic [31:0]           ks_req_addr;
  logic [2:0]            ks_req_size, ks_rsp_err;
  logic [DMA_DW-1:0]     ks_req_wdata, ks_rsp_rdata;
  logic [NB-1:0]         ks_req_wstrb;
  logic                  br_req_valid, br_req_ready, br_req_we, br_rsp_valid, br_rsp_ready;
  logic [31:0]           br_req_addr;
  logic [2:0]            br_req_size, br_rsp_err;
  logic [DMA_DW-1:0]     br_req_wdata, br_rsp_rdata;
  logic [NB-1:0]         br_req_wstrb;
  logic                  bm_cmd_valid, bm_cmd_ready, bm_rsp_valid;
  logic [2:0]            bm_cmd_op, bm_cmd_requester, bm_cmd_btype, bm_cmd_owner;
  logic [IDW-1:0]        bm_cmd_id, bm_rsp_id;
  logic [31:0]           bm_cmd_start, bm_rsp_start;
  logic [LEN_W-1:0]      bm_cmd_len, bm_rsp_len;
  logic [4:0]            bm_cmd_rd_mask, bm_cmd_wr_mask;
  logic [3:0]            bm_rsp_status;
  logic [7:0]            bm_rsp_err_bits;
  logic                  csr_valid, csr_we, csr_rvalid, csr_err;
  logic [11:0]           csr_addr;
  logic [31:0]           csr_wdata, csr_rdata;
  logic                  init_done, irq, busy_o, idle_o, clk_gate_ok_o;
  logic                  perf_clear;
  logic [5:0]            perf_sel;
  logic [39:0]           perf_val;
  logic [`CW_PC_N*40-1:0] perf_flat;

  // Keystone port: driven by the script (KWRITE) or, while bg_en = 1, by the background traffic generator
  logic               bg_en = 1'b0, bg_v = 1'b0, bg_we = 1'b0;
  logic [31:0]        bg_addr = '0;
  logic [DMA_DW-1:0]  bg_wd = '0;
  logic [NB-1:0]      bg_wb = '0;
  wire                kv = bg_en ? bg_v : ks_req_valid;
  wire [31:0]         ka = bg_en ? bg_addr : ks_req_addr;
  wire [2:0]          kz = bg_en ? 3'($clog2(NB)) : ks_req_size;
  wire                kw = bg_en ? bg_we : ks_req_we;
  wire [DMA_DW-1:0]   kd = bg_en ? bg_wd : ks_req_wdata;
  wire [NB-1:0]       kb = bg_en ? bg_wb : ks_req_wstrb;

  sf_compute_tile #(
    .NUM_LANES(NUM_LANES), .TENSOR_ROWS(TENSOR_ROWS), .TENSOR_COLS(TENSOR_COLS), .NUM_BANKS(NUM_BANKS),
    .BANK_DEPTH(BANK_DEPTH), .DMA_DW(DMA_DW), .CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH), .NUM_QUEUES(NUM_QUEUES),
    .NUM_CP(NUM_CP), .STG_BYTES(STG_BYTES), .CPL_DEPTH(CPL_DEPTH), .EN_VECTOR(EN_VECTOR),
    .GUARD_MODE(GUARD_MODE), .NUM_REGIONS(NREG), .CLEAR_STAGING(CLEAR_STAGING), .STARVE_LIMIT(STARVE_LIMIT),
    .IM_ECC_EN(IM_ECC_EN), .IM_RL(IM_RL)
  ) dut (
    .clk, .rst_n, .clk_en_i,
    .sub_valid, .sub_ready, .sub_q, .sub_desc,
    .cpl_valid, .cpl_ready, .cpl_queue, .cpl_domain, .cpl_dest, .cpl_tag, .cpl_op, .cpl_status, .cpl_detail,
    .cpl_fflags, .cpl_out_bytes, .cpl_cycles, .cpl_qwait, .cpl_seq,
    .pol_valid, .pol_ready, .pol_op, .pol_idx, .pol_a, .pol_b, .pol_c, .pol_done, .pol_status,
    .reg_valid_o, .reg_dirty_o,
    .cit_req_valid, .cit_req_ready, .cit_req_dom, .cit_req_write, .cit_req_base, .cit_req_len,
    .cit_rsp_valid, .cit_rsp_ok, .cit_rsp_fault,
    .ks_req_valid(kv), .ks_req_ready, .ks_req_addr(ka), .ks_req_size(kz), .ks_req_we(kw), .ks_req_wdata(kd), .ks_req_wstrb(kb),
    .ks_rsp_valid, .ks_rsp_ready, .ks_rsp_rdata, .ks_rsp_err,
    .br_req_valid, .br_req_ready, .br_req_addr, .br_req_size, .br_req_we, .br_req_wdata, .br_req_wstrb,
    .br_rsp_valid, .br_rsp_ready, .br_rsp_rdata, .br_rsp_err,
    .bm_cmd_valid, .bm_cmd_ready, .bm_cmd_op, .bm_cmd_requester, .bm_cmd_id, .bm_cmd_btype, .bm_cmd_start,
    .bm_cmd_len, .bm_cmd_owner, .bm_cmd_rd_mask, .bm_cmd_wr_mask,
    .bm_rsp_valid, .bm_rsp_status, .bm_rsp_id, .bm_rsp_start, .bm_rsp_len, .bm_rsp_err_bits,
    .csr_valid, .csr_we, .csr_addr, .csr_wdata, .csr_rvalid, .csr_rdata, .csr_err,
    .init_done, .irq, .busy_o, .idle_o, .clk_gate_ok_o,
    .perf_clear, .perf_sel, .perf_val, .perf_flat);

  // ------------------------------------------------------------------ external Citadel stub (GUARD_MODE = 2)
  // A DIFFERENT implementation from the in-tile reference: flat table of allowed (dom, base, len, rights).
  // Programmed from the script with POL-less "XCIT" lines is not needed: the stub permits exactly the
  // ranges inside [XC_LO, XC_HI) for domain XC_DOM, read and write, and denies everything else.
  logic [31:0] xc_lo = BASE, xc_hi = BASE + 32'(SRAM_BYTES / 2);
  logic [2:0]  xc_dom = 3'd1;
  int          xc_cnt;
  logic        xc_pend;
  logic        xc_ok_q;
  logic [3:0]  xc_f_q;
  assign cit_req_ready = (EXT_CIT_HANG != 2);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin xc_cnt <= 0; xc_pend <= 1'b0; cit_rsp_valid <= 1'b0; cit_rsp_ok <= 1'b0; cit_rsp_fault <= 4'd0; xc_ok_q <= 0; xc_f_q <= 0; end
    else begin
      cit_rsp_valid <= 1'b0;
      if (cit_req_valid && cit_req_ready && !xc_pend) begin
        xc_pend <= 1'b1; xc_cnt <= 0;
        xc_ok_q <= (cit_req_dom == xc_dom) && (cit_req_base >= xc_lo) && ((40'(cit_req_base) + cit_req_len) <= 40'(xc_hi));
        xc_f_q  <= (cit_req_dom != xc_dom) ? 4'd3 : 4'd1;
      end else if (xc_pend) begin
        xc_cnt <= xc_cnt + 1;
        if (xc_cnt >= EXT_CIT_LAT && !EXT_CIT_HANG) begin
          cit_rsp_valid <= 1'b1; cit_rsp_ok <= xc_ok_q; cit_rsp_fault <= xc_ok_q ? 4'd0 : xc_f_q; xc_pend <= 1'b0;
        end
      end
    end
  end

  // ------------------------------------------------------------------ monitors (counters / capture only)
  int            sub_cnt = 0, pol_cnt = 0, bm_cnt = 0, br_acc_cnt = 0, br_rsp_cnt = 0, csr_cnt = 0;
  int            br_err_cnt = 0, ks_err_cnt = 0, ks_rsp_cnt = 0, ks_acc_cnt = 0;
  logic [3:0]    pol_status_q, bm_status_q;
  logic [DMA_DW-1:0] br_data_q, ks_data_q;
  logic [2:0]    br_err_q, ks_err_q;
  logic [31:0]   csr_data_q;
  int            cycle_cnt = 0;

  // completion capture (written only here, read by the interpreter through mon_rd)
  localparam int CAPN = 4096;
  logic [QW-1:0]  cap_q   [CAPN];
  logic [2:0]     cap_dom [CAPN];
  logic [3:0]     cap_dst [CAPN];
  logic [15:0]    cap_tag [CAPN];
  logic [7:0]     cap_op  [CAPN];
  logic [4:0]     cap_st  [CAPN];
  logic [15:0]    cap_det [CAPN];
  logic [4:0]     cap_ff  [CAPN];
  logic [31:0]    cap_out [CAPN];
  logic [31:0]    cap_cyc [CAPN];
  logic [31:0]    cap_qw  [CAPN];
  logic [31:0]    cap_seq [CAPN];
  int             mon_wr = 0;
  int             mon_rd = 0;

  // completion-payload stability under back-pressure
  logic           cp_hold_v = 0;
  logic [255:0]   cp_hold;
  wire  [255:0]   cp_now = {cpl_queue, cpl_domain, cpl_dest, cpl_tag, cpl_op, cpl_status, cpl_detail, cpl_fflags, cpl_out_bytes, cpl_cycles, cpl_qwait, cpl_seq};

  always @(posedge clk) begin
    cycle_cnt <= cycle_cnt + 1;
    if (sub_valid && sub_ready) sub_cnt <= sub_cnt + 1;
    if (pol_done) begin pol_cnt <= pol_cnt + 1; pol_status_q <= pol_status; end
    if (bm_rsp_valid) begin bm_cnt <= bm_cnt + 1; bm_status_q <= bm_rsp_status; end
    if (br_req_valid && br_req_ready) br_acc_cnt <= br_acc_cnt + 1;
    if (br_rsp_valid && br_rsp_ready) begin
      br_rsp_cnt <= br_rsp_cnt + 1; br_data_q <= br_rsp_rdata; br_err_q <= br_rsp_err;
      if (br_rsp_err != 3'd0) br_err_cnt <= br_err_cnt + 1;
    end
    if (kv && ks_req_ready) ks_acc_cnt <= ks_acc_cnt + 1;
    if (ks_rsp_valid && ks_rsp_ready) begin
      ks_rsp_cnt <= ks_rsp_cnt + 1; ks_data_q <= ks_rsp_rdata; ks_err_q <= ks_rsp_err;
      if (ks_rsp_err != 3'd0) ks_err_cnt <= ks_err_cnt + 1;
    end
    if (csr_rvalid) begin csr_cnt <= csr_cnt + 1; csr_data_q <= csr_rdata; end
    if (cpl_valid && cpl_ready) begin
      cap_q[mon_wr % CAPN] = cpl_queue;  cap_dom[mon_wr % CAPN] = cpl_domain; cap_dst[mon_wr % CAPN] = cpl_dest;
      cap_tag[mon_wr % CAPN] = cpl_tag;  cap_op[mon_wr % CAPN] = cpl_op;      cap_st[mon_wr % CAPN] = cpl_status;
      cap_det[mon_wr % CAPN] = cpl_detail; cap_ff[mon_wr % CAPN] = cpl_fflags; cap_out[mon_wr % CAPN] = cpl_out_bytes;
      cap_cyc[mon_wr % CAPN] = cpl_cycles; cap_qw[mon_wr % CAPN] = cpl_qwait;  cap_seq[mon_wr % CAPN] = cpl_seq;
      mon_wr = mon_wr + 1;
    end
    // payload must be stable while valid && !ready, and valid may not drop
    if (rst_n) begin
      if (cp_hold_v && !(cpl_valid && (cp_now == cp_hold))) begin
        tb_checks++; tb_errors++; $display("[FAIL] %0t completion changed or dropped while stalled", $time);
      end
      cp_hold_v <= cpl_valid && !cpl_ready;
      cp_hold   <= cp_now;
    end else cp_hold_v <= 1'b0;
  end

  // completion ready pattern
  int cplbp_pct = 100;
  always @(negedge clk) begin
    if (cplbp_pct >= 100) cpl_ready <= 1'b1;
    else                  cpl_ready <= (int'($urandom_range(99, 0)) < cplbp_pct);
  end

  // ------------------------------------------------------------------ port helpers
  task automatic br_word(input logic [31:0] addr, input logic we, input logic [DMA_DW-1:0] wd, input logic [NB-1:0] ws,
                         output logic [DMA_DW-1:0] rd, output logic [2:0] err);
    int acc0, rsp0;
    @(negedge clk);
    acc0 = br_acc_cnt; rsp0 = br_rsp_cnt;
    br_req_valid = 1; br_req_addr = addr; br_req_we = we; br_req_wdata = wd; br_req_wstrb = ws;
    br_req_size = 3'($clog2(NB));
    do @(negedge clk); while (br_acc_cnt == acc0);
    br_req_valid = 0;
    while (br_rsp_cnt == rsp0) @(negedge clk);
    rd = br_data_q; err = br_err_q;
  endtask

  task automatic ks_word(input logic [31:0] addr, input logic we, input logic [DMA_DW-1:0] wd, input logic [NB-1:0] ws,
                         output logic [DMA_DW-1:0] rd, output logic [2:0] err);
    int acc0, rsp0;
    @(negedge clk);
    acc0 = ks_acc_cnt; rsp0 = ks_rsp_cnt;
    ks_req_valid = 1; ks_req_addr = addr; ks_req_we = we; ks_req_wdata = wd; ks_req_wstrb = ws;
    ks_req_size = 3'($clog2(NB));
    do @(negedge clk); while (ks_acc_cnt == acc0);
    ks_req_valid = 0;
    while (ks_rsp_cnt == rsp0) @(negedge clk);
    rd = ks_data_q; err = ks_err_q;
  endtask


  // ------------------------------------------------------------------ background traffic (concurrent DMA stand-in)
  // A second master on the Keystone port reads / rewrites a dedicated region with the address-derived byte pattern
  //   byte(A) = (A*37 + 11) & 0xFF
  // Writes are idempotent (same pattern), so the region's contents never change and the Python shadow model stays
  // valid; every read is verified.  It exists to create REAL bank contention with the compute engines.
  function automatic logic [7:0] bg_pat(input logic [31:0] a);
    return 8'((a * 32'd37 + 32'd11) & 32'hFF);
  endfunction
  int bg_pct = 50, bg_ops = 0, bg_bad = 0, bg_state = 0, bg_acc0, bg_rsp0;
  logic [31:0] bg_lo = BASE, bg_hi = BASE;
  logic        bg_isw;
  logic [31:0] bg_a;
  always @(negedge clk) begin
    if (!bg_en || !rst_n) begin
      bg_v <= 1'b0; bg_state <= 0;
    end else begin
      case (bg_state)
        0: if (int'($urandom_range(99, 0)) < bg_pct) begin
             bg_a = bg_lo + 32'(($urandom_range(int'((bg_hi - bg_lo) / NB) - 1, 0)) * NB);
             bg_isw = ($urandom_range(3, 0) == 0);
             bg_addr <= bg_a; bg_we <= bg_isw; bg_wb <= '1;
             for (int l = 0; l < NB; l++) bg_wd[l*8 +: 8] <= bg_pat(bg_a + 32'(l));
             bg_v <= 1'b1; bg_acc0 = ks_acc_cnt; bg_rsp0 = ks_rsp_cnt; bg_state <= 1;
           end
        1: if (ks_acc_cnt != bg_acc0) begin bg_v <= 1'b0; bg_state <= 2; end
        2: if (ks_rsp_cnt != bg_rsp0) begin
             bg_ops <= bg_ops + 1;
             if (ks_err_q != 3'd0) bg_bad <= bg_bad + 1;
             else if (!bg_we) for (int l = 0; l < NB; l++) if (ks_data_q[l*8 +: 8] !== bg_pat(bg_addr + 32'(l))) bg_bad <= bg_bad + 1;
             bg_state <= 0;
           end
        default: bg_state <= 0;
      endcase
    end
  end

  // ------------------------------------------------------------------ script interpreter
  integer fd, r;
  logic [31:0] t [0:15];          // generic 32-bit tokens
  logic [11:0] bt;                // byte token (>= 0x100: don't care)
  logic [7:0]  bbuf [];           // byte buffer
  logic [11:0] ebuf [];           // expected byte buffer
  string       line;

  function automatic bit match32(input logic [31:0] got, input logic [31:0] exp);
    return (exp === 32'hFFFF_FFFF) || (got === exp);
  endfunction

  task automatic do_reset();
    @(negedge clk);
    rst_n = 0; sub_valid = 0; pol_valid = 0; br_req_valid = 0; ks_req_valid = 0; bm_cmd_valid = 0; csr_valid = 0;
    repeat (4) @(negedge clk);
    rst_n = 1;
    mon_rd = mon_wr;
    while (!init_done) @(negedge clk);
    repeat (2) @(negedge clk);
  endtask

  task automatic do_bm(input logic [31:0] op, input logic [31:0] id, input logic [31:0] bty, input logic [31:0] start,
                       input logic [31:0] len, input logic [31:0] owner, input logic [31:0] rd, input logic [31:0] wr,
                       input logic [31:0] exp);
    int c0;
    @(negedge clk);
    while (!bm_cmd_ready) @(negedge clk);
    c0 = bm_cnt;
    bm_cmd_valid = 1; bm_cmd_op = op[2:0]; bm_cmd_requester = 3'd0; bm_cmd_id = id[IDW-1:0]; bm_cmd_btype = bty[2:0];
    bm_cmd_start = start; bm_cmd_len = len[LEN_W-1:0]; bm_cmd_owner = owner[2:0]; bm_cmd_rd_mask = rd[4:0]; bm_cmd_wr_mask = wr[4:0];
    @(negedge clk); bm_cmd_valid = 0;
    while (bm_cnt == c0) @(negedge clk);
    if (exp != 32'hFF) `CHECK_EQ({28'd0, bm_status_q}, exp, "buffer-manager status")
  endtask

  // policy-accept monitor: a request is accepted at the posedge where pol_valid && pol_ready
  int pol_acc_cnt = 0;
  always @(posedge clk) if (pol_valid && pol_ready) pol_acc_cnt <= pol_acc_cnt + 1;

  task automatic do_pol(input logic [31:0] op, input logic [31:0] idx, input logic [31:0] a, input logic [31:0] b,
                        input logic [31:0] c, input logic [31:0] exp);
    int acc0, done0, guard;
    @(negedge clk);
    acc0 = pol_acc_cnt; done0 = pol_cnt; guard = 0;
    pol_valid = 1; pol_op = op[3:0]; pol_idx = idx[3:0]; pol_a = a; pol_b = b; pol_c = c;
    // hold the request until the tile accepts it (it is only ready while quiescent)
    do begin @(negedge clk); guard++; end while (pol_acc_cnt == acc0 && guard < 20000000);
    pol_valid = 0;
    while (pol_cnt == done0) @(negedge clk);          // SCRUB responds only when the zero-fill finished
    if (exp != 32'hFF) `CHECK_EQ({28'd0, pol_status_q}, exp, "policy status")
  endtask

  task automatic do_submit(input logic [31:0] q, input logic [255:0] d);
    int c0;
    @(negedge clk);
    c0 = sub_cnt;
    sub_valid = 1; sub_q = q[QW-1:0]; sub_desc = d;
    do @(negedge clk); while (sub_cnt == c0);
    sub_valid = 0;
  endtask

  task automatic wait_cpl(input int maxcyc);
    int g;
    g = 0;
    while (mon_rd >= mon_wr && g < maxcyc) begin @(negedge clk); g++; end
    if (mon_rd >= mon_wr) begin
      tb_checks++; tb_errors++;
      $display("[FAIL] %0t timeout waiting for a completion", $time);
    end
  endtask

  task automatic check_cpl(input logic [31:0] eq, input logic [31:0] edom, input logic [31:0] edst, input logic [31:0] etag,
                           input logic [31:0] eop, input logic [31:0] est, input logic [31:0] edet, input logic [31:0] eff,
                           input logic [31:0] eout, input string what);
    int i;
    wait_cpl(4000000);
    if (mon_rd < mon_wr) begin
      i = mon_rd % CAPN;
      tb_checks++;
      if (!(match32({31'd0, cap_q[i]}, eq) && match32({29'd0, cap_dom[i]}, edom) && match32({28'd0, cap_dst[i]}, edst) &&
            match32({16'd0, cap_tag[i]}, etag) && match32({24'd0, cap_op[i]}, eop) && match32({27'd0, cap_st[i]}, est) &&
            match32({16'd0, cap_det[i]}, edet) && match32({27'd0, cap_ff[i]}, eff) && match32(cap_out[i], eout))) begin
        tb_errors++;
        if (tb_errors <= 40)
          $display("[FAIL] %s: completion q=%0d dom=%0d dest=%0d tag=%h op=%0d status=%0d detail=%h ff=%h out=%0d | expected q=%h dom=%h dest=%h tag=%h op=%h st=%h det=%h ff=%h out=%h",
                   what, cap_q[i], cap_dom[i], cap_dst[i], cap_tag[i], cap_op[i], cap_st[i], cap_det[i], cap_ff[i], cap_out[i],
                   eq, edom, edst, etag, eop, est, edet, eff, eout);
      end
      mon_rd = mon_rd + 1;
    end
  endtask

  int nlines = 0;
  bit script_done = 0;
  logic [255:0] dsc;
  logic [31:0] opn;
  int  nbytes, errcnt0, a0;
  logic [DMA_DW-1:0] rdw, wdw;
  logic [NB-1:0] wsw;
  logic [2:0] er;

  initial begin
    // plusargs
    if (!$value$plusargs("script=%s", script_name)) begin $display("TB_RESULT tb_compute_tile FAIL no +script"); $finish; end
    if ($value$plusargs("seed=%d", seed)) ;
    void'($urandom(seed));
    if ($value$plusargs("cplbp=%d", cplbp_pct)) ;
    $display("CFG lanes=%0d tensor=%0dx%0d banks=%0d depth=%0d dw=%0d queues=%0d cp=%0d stg=%0d guard=%0d sram=%0d",
             NUM_LANES, TENSOR_ROWS, TENSOR_COLS, NUM_BANKS, BANK_DEPTH, DMA_DW, NUM_QUEUES, NUM_CP, STG_BYTES, GUARD_MODE, SRAM_BYTES);
    clk_en_i = 1; sub_valid = 0; sub_q = '0; sub_desc = '0; pol_valid = 0; pol_op = 0; pol_idx = 0; pol_a = 0; pol_b = 0; pol_c = 0;
    br_req_valid = 0; br_req_addr = 0; br_req_size = 0; br_req_we = 0; br_req_wdata = 0; br_req_wstrb = 0; br_rsp_ready = 1;
    ks_req_valid = 0; ks_req_addr = 0; ks_req_size = 0; ks_req_we = 0; ks_req_wdata = 0; ks_req_wstrb = 0; ks_rsp_ready = 1;
    bm_cmd_valid = 0; bm_cmd_op = 0; bm_cmd_requester = 0; bm_cmd_id = 0; bm_cmd_btype = 0; bm_cmd_start = 0; bm_cmd_len = 0;
    bm_cmd_owner = 0; bm_cmd_rd_mask = 0; bm_cmd_wr_mask = 0; csr_valid = 0; csr_we = 0; csr_addr = 0; csr_wdata = 0;
    perf_clear = 0; perf_sel = 0;

    fd = $fopen(script_name, "r");
    if (fd == 0) begin $display("TB_RESULT tb_compute_tile FAIL cannot open %s", script_name); $finish; end
    do_reset();

    while (!script_done && !$feof(fd)) begin
      r = $fscanf(fd, "%h", opn);
      if (r != 1) begin r = $fgets(line, fd); continue; end
      nlines++;
      case (opn[7:0])
        8'h00: do_reset();
        8'h02: begin r = $fscanf(fd, "%h %h %h %h %h %h %h %h %h", t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8]);
                 do_bm(t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8]); end
        8'h03: begin
          r = $fscanf(fd, "%h %h", t[0], t[1]);
          nbytes = int'(t[1]); a0 = int'(t[0]); bbuf = new[nbytes];
          for (int i = 0; i < nbytes; i++) begin r = $fscanf(fd, "%h", bt); bbuf[i] = bt[7:0]; end
          for (int wa = (a0 / NB) * NB; wa <= ((a0 + nbytes - 1) / NB) * NB; wa += NB) begin
            wdw = '0; wsw = '0;
            for (int l = 0; l < NB; l++) if ((wa + l) >= a0 && (wa + l) < a0 + nbytes) begin
              wdw[l*8 +: 8] = bbuf[wa + l - a0]; wsw[l] = 1'b1;
            end
            br_word(32'(wa), 1'b1, wdw, wsw, rdw, er);
            tb_checks++;
            if (er != 3'd0) begin tb_errors++; $display("[FAIL] BWRITE %h response error %0d", wa, er); end
          end
        end
        8'h04, 8'h15: begin
          r = $fscanf(fd, "%h %h", t[0], t[1]);
          nbytes = int'(t[1]); a0 = int'(t[0]); ebuf = new[nbytes];
          for (int i = 0; i < nbytes; i++) begin r = $fscanf(fd, "%h", bt); ebuf[i] = bt; end
          for (int wa = (a0 / NB) * NB; wa <= ((a0 + nbytes - 1) / NB) * NB; wa += NB) begin
            br_word(32'(wa), 1'b0, '0, '0, rdw, er);
            if (opn[7:0] == 8'h15) begin
              tb_checks++;
              if (er == 3'd0) begin tb_errors++; $display("[FAIL] BREADERR %h unexpectedly succeeded", wa); end
            end else begin
              tb_checks++;
              if (er != 3'd0) begin tb_errors++; $display("[FAIL] BREAD %h response error %0d", wa, er); end
              for (int l = 0; l < NB; l++) if ((wa + l) >= a0 && (wa + l) < a0 + nbytes) begin
                logic [11:0] e;
                e = ebuf[wa + l - a0];
                tb_checks++;
                if (e < 12'h100 && rdw[l*8 +: 8] !== e[7:0]) begin
                  tb_errors++;
                  if (tb_errors <= 40) $display("[FAIL] %s line %0d: mem[%h] got=%02h exp=%02h", script_name, nlines, wa + l, rdw[l*8 +: 8], e[7:0]);
                end
              end
            end
          end
        end
        8'h05: begin
          r = $fscanf(fd, "%h", t[0]);
          for (int i = 0; i < 8; i++) begin r = $fscanf(fd, "%h", t[1+i]); dsc[i*32 +: 32] = t[1+i]; end
          do_submit(t[0], dsc);
        end
        8'h06: begin
          r = $fscanf(fd, "%h %h %h %h %h %h %h %h %h", t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8]);
          check_cpl(t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8], $sformatf("%s line %0d", script_name, nlines));
        end
        8'h07: begin r = $fscanf(fd, "%h %h %h %h %h %h", t[0], t[1], t[2], t[3], t[4], t[5]);
                 do_pol(t[0], t[1], t[2], t[3], t[4], t[5]); end
        8'h08: begin r = $fscanf(fd, "%h", t[0]); repeat (int'(t[0])) @(negedge clk); end
        8'h0a: begin r = $fscanf(fd, "%h", t[0]); @(negedge clk); clk_en_i = t[0][0]; end
        8'h0d: begin
          r = $fscanf(fd, "%h", t[0]);
          errcnt0 = mon_wr;
          repeat (int'(t[0])) @(negedge clk);
          tb_checks++;
          if (mon_wr != errcnt0) begin tb_errors++; $display("[FAIL] %s line %0d: %0d unexpected completion(s) appeared", script_name, nlines, mon_wr - errcnt0); end
        end
        8'h0e: begin
          @(negedge clk);
          for (int i = 0; i < `CW_PC_N; i++) $display("PERF %0d %0d", i, perf_flat[i*40 +: 40]);
          $display("PERF_DONE cycles=%0d", cycle_cnt);
        end
        8'h0f: begin
          r = $fscanf(fd, "%h", t[0]);
          @(negedge clk); csr_valid = 1; csr_we = 0; csr_addr = t[0][11:0];
          errcnt0 = csr_cnt;
          @(negedge clk); csr_valid = 0;
          while (csr_cnt == errcnt0) @(negedge clk);
          $display("CSR %0h %0d", t[0][11:0], csr_data_q);
        end
        8'h10: begin
          r = $fscanf(fd, "%h %h %h %h %h %h %h %h %h", t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8]);
          wait_cpl(4000000);
          if (mon_rd < mon_wr) begin
            int i; i = mon_rd % CAPN;
            $display("CPLREC q=%0d dom=%0d dest=%0d tag=%0h op=%0d st=%0d det=%0h ff=%0h out=%0d cyc=%0d qwait=%0d seq=%0d",
                     cap_q[i], cap_dom[i], cap_dst[i], cap_tag[i], cap_op[i], cap_st[i], cap_det[i], cap_ff[i], cap_out[i], cap_cyc[i], cap_qw[i], cap_seq[i]);
            check_cpl(t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8], $sformatf("%s line %0d", script_name, nlines));
          end
        end
        8'h11: begin
          r = $fscanf(fd, "%h %h", t[0], t[1]);
          nbytes = int'(t[1]); a0 = int'(t[0]); bbuf = new[nbytes];
          for (int i = 0; i < nbytes; i++) begin r = $fscanf(fd, "%h", bt); bbuf[i] = bt[7:0]; end
          for (int wa = (a0 / NB) * NB; wa <= ((a0 + nbytes - 1) / NB) * NB; wa += NB) begin
            wdw = '0; wsw = '0;
            for (int l = 0; l < NB; l++) if ((wa + l) >= a0 && (wa + l) < a0 + nbytes) begin
              wdw[l*8 +: 8] = bbuf[wa + l - a0]; wsw[l] = 1'b1;
            end
            ks_word(32'(wa), 1'b1, wdw, wsw, rdw, er);
          end
        end
        8'h12: begin r = $fscanf(fd, "%h", t[0]); `CHECK_EQ(ks_err_cnt, int'(t[0]), "Keystone error-response count") end
        8'h13: begin
          r = $fscanf(fd, "%h", t[0]);
          for (int n = 0; n < int'(t[0]); n++) begin
            wait_cpl(4000000);
            if (mon_rd < mon_wr) begin
              int i; i = mon_rd % CAPN;
              $display("CPLREC q=%0d dom=%0d dest=%0d tag=%0h op=%0d st=%0d det=%0h ff=%0h out=%0d cyc=%0d qwait=%0d seq=%0d",
                       cap_q[i], cap_dom[i], cap_dst[i], cap_tag[i], cap_op[i], cap_st[i], cap_det[i], cap_ff[i], cap_out[i], cap_cyc[i], cap_qw[i], cap_seq[i]);
              mon_rd = mon_rd + 1;
            end
          end
        end
        8'h14: begin r = $fscanf(fd, "%h", t[0]); cplbp_pct = int'(t[0]); end
        8'h17: begin   // CHECKSTG v: v=1 -> all four staging buffers must be zero (white-box)
          r = $fscanf(fd, "%h", t[0]);
          @(negedge clk);
          tb_checks++;
          if (t[0][0] && (dut.u_adapter.s0_q != '0 || dut.u_adapter.s1_q != '0 || dut.u_adapter.s2_q != '0 || dut.u_adapter.s3_q != '0)) begin
            tb_errors++; $display("[FAIL] %s line %0d: staging buffers not zero after command", script_name, nlines);
          end
        end
        8'h18: begin   // BGDMA en lo hi pct : start / stop background traffic on the Keystone port
          r = $fscanf(fd, "%h %h %h %h", t[0], t[1], t[2], t[3]);
          @(negedge clk);
          if (t[0][0]) begin bg_lo = t[1]; bg_hi = t[2]; bg_pct = int'(t[3]); bg_ops = 0; bg_bad = 0; bg_en = 1'b1; end
          else begin bg_en = 1'b0; end
        end
        8'h19: begin   // XCIT lo hi dom : program the external-Citadel stub
          r = $fscanf(fd, "%h %h %h", t[0], t[1], t[2]);
          xc_lo = t[0]; xc_hi = t[1]; xc_dom = t[2][2:0];
        end
        8'h1a: begin   // BGSTAT min_ops : stop background traffic, require >= min_ops verified operations and 0 bad
          r = $fscanf(fd, "%h", t[0]);
          @(negedge clk); bg_en = 1'b0;
          repeat (40) @(negedge clk);
          $display("BG ops=%0d bad=%0d", bg_ops, bg_bad);
          tb_checks++;
          if (bg_bad != 0) begin tb_errors++; $display("[FAIL] background traffic saw %0d bad responses", bg_bad); end
          tb_checks++;
          if (bg_ops < int'(t[0])) begin tb_errors++; $display("[FAIL] background traffic completed only %0d ops (< %0d)", bg_ops, int'(t[0])); end
        end
        8'h1c: begin   // KREAD addr n e0..: read through the KEYSTONE port (raw access to unmanaged memory) and compare
          r = $fscanf(fd, "%h %h", t[0], t[1]);
          nbytes = int'(t[1]); a0 = int'(t[0]); ebuf = new[nbytes];
          for (int i = 0; i < nbytes; i++) begin r = $fscanf(fd, "%h", bt); ebuf[i] = bt; end
          for (int wa = (a0 / NB) * NB; wa <= ((a0 + nbytes - 1) / NB) * NB; wa += NB) begin
            ks_word(32'(wa), 1'b0, '0, '0, rdw, er);
            tb_checks++;
            if (er != 3'd0) begin tb_errors++; $display("[FAIL] KREAD %h response error %0d", wa, er); end
            for (int l = 0; l < NB; l++) if ((wa + l) >= a0 && (wa + l) < a0 + nbytes) begin
              logic [11:0] e;
              e = ebuf[wa + l - a0];
              tb_checks++;
              if (e < 12'h100 && rdw[l*8 +: 8] !== e[7:0]) begin
                tb_errors++;
                if (tb_errors <= 40) $display("[FAIL] %s line %0d: Keystone mem[%h] got=%02h exp=%02h", script_name, nlines, wa + l, rdw[l*8 +: 8], e[7:0]);
              end
            end
          end
        end
        8'h1d: begin   // CHECKGATE gate idle busy : compare clk_gate_ok_o / idle_o / busy_o (ff = any)
          r = $fscanf(fd, "%h %h %h", t[0], t[1], t[2]);
          @(negedge clk);
          tb_checks++;
          if ((t[0] != 32'hFF && clk_gate_ok_o !== t[0][0]) || (t[1] != 32'hFF && idle_o !== t[1][0]) || (t[2] != 32'hFF && busy_o !== t[2][0])) begin
            tb_errors++; $display("[FAIL] %s line %0d: gate/idle/busy = %b/%b/%b expected %h/%h/%h", script_name, nlines, clk_gate_ok_o, idle_o, busy_o, t[0], t[1], t[2]);
          end
        end
        8'h1e: begin   // CSRW addr data : write an IronMemory CSR (Keystone)
          r = $fscanf(fd, "%h %h", t[0], t[1]);
          @(negedge clk); csr_valid = 1; csr_we = 1; csr_addr = t[0][11:0]; csr_wdata = t[1];
          @(negedge clk); csr_valid = 0; csr_we = 0;
          repeat (2) @(negedge clk);
        end
        8'h1f: begin   // CHECKPEND n : exactly n completions captured but not yet consumed by the script
          r = $fscanf(fd, "%h", t[0]);
          @(negedge clk);
          tb_checks++;
          if ((mon_wr - mon_rd) != int'(t[0])) begin
            tb_errors++; $display("[FAIL] %s line %0d: %0d completion(s) pending, expected %0d", script_name, nlines, mon_wr - mon_rd, int'(t[0]));
          end
        end
        8'h1b: begin @(negedge clk); perf_clear = 1; @(negedge clk); perf_clear = 0; end

        8'h16: begin r = $fscanf(fd, "%h", t[0]); $display("MARK %0h", t[0]); end
        8'hff: begin
          repeat (20) @(negedge clk);
          tb_checks++;
          if (mon_rd != mon_wr) begin tb_errors++; $display("[FAIL] %0d unconsumed completion(s) at END", mon_wr - mon_rd); end
          tb_checks++;
          if (idle_o !== 1'b1) begin tb_errors++; $display("[FAIL] tile not idle at END"); end
          script_done = 1;
          `TB_FINISH("tb_compute_tile")
        end
        default: begin tb_checks++; tb_errors++; $display("[FAIL] unknown script op %0h at line %0d", opn[7:0], nlines); end
      endcase
    end
    if (!script_done) begin $display("TB_RESULT tb_compute_tile FAIL script ended without END"); $finish; end
  end

  initial begin
    #2000000000;
    $display("TB_RESULT tb_compute_tile FAIL watchdog");
    $finish;
  end
endmodule
