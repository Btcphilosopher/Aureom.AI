// =============================================================================
// SilicaFlux Albion -- Project 88 COMPUTEWORKS :: sf_compute_scheduler
// Aureom.AI / SilicaFlux Albion
//
// Local scheduler.  One command is in flight at a time (reference configuration:
// ONE OUTSTANDING COMPUTE COMMAND).  Pipeline per command:
//
//   arbitrate -> decode/validate -> isolation check (per operand) -> dispatch ->
//   wait -> completion record -> completion FIFO
//
// ARBITRATION (NQ queues; NQ = 1 degenerates to "take the head"):
//   * a queue is eligible when it has a head descriptor and is enabled (an UNBOUND queue
//     stays eligible: its commands are scheduled in order to be REJECTED with CW_ST_OWNER,
//     so every submission gets exactly one completion);
//   * strict priority between the 4 classes (3 = highest);
//   * round robin inside the winning class, with a per-queue QUANTUM: a queue keeps the
//     tile for up to `quantum` consecutive commands while it still has work and is still
//     in the winning class;
//   * ANTI-STARVATION: a queue that was eligible but lost STARVE_LIMIT consecutive
//     decisions is treated as class 3 until it is served.  Resource limits per queue: the
//     work budget enforced by the decoder (CW_ST_RESLIMIT).
//
// CONTEXT SWITCHING: queues are switched ONLY at command boundaries.  A command carries
// all its state in memory, so there is nothing to save or restore.  NO mid-kernel
// preemption exists and none is claimed: a started command runs to completion.
//
// clk_en_i gates DISPATCH only: a command already started is never frozen.  idle_o
// (no command in flight) tells the integrator when the tile is quiescent and a clock
// gate may be closed; this module does not gate any clock.
// =============================================================================
`timescale 1ns/1ps
`include "sf_compute_defs.svh"
`default_nettype none

module sf_compute_scheduler #(
  parameter int          NQ           = 1,
  parameter int          CPL_DEPTH    = 4,
  parameter int          TSW          = 32,
  parameter int          STARVE_LIMIT = 16,
  parameter bit          CLEAR_STAGING = 1'b1,
  parameter logic [31:0] SRAM_BASE    = 32'h1000_0000,
  parameter longint      SRAM_BYTES   = 32768,
  parameter int          KMAX         = 256,
  parameter bit          EN_VECTOR    = 1'b1,
  parameter bit          EN_INT32     = 1'b1,
  parameter int          QW           = (NQ > 1) ? $clog2(NQ) : 1,
  parameter int          CQW          = $clog2(CPL_DEPTH + 1)
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 clk_en_i,
  input  wire logic [TSW-1:0]       now,
  // ---------------------------------------------------------------- queues
  input  wire logic [NQ-1:0]        head_valid,
  input  wire logic [NQ*256-1:0]    head_desc,
  input  wire logic [NQ*TSW-1:0]    head_ts,
  output logic      [NQ-1:0]        pop,
  // queue configuration (from the guard)
  input  wire logic [NQ-1:0]        q_bound,
  input  wire logic [NQ-1:0]        q_en,
  input  wire logic [NQ*3-1:0]      q_dom,
  input  wire logic [NQ*`CW_PRIO_W-1:0] q_prio,
  input  wire logic [NQ*4-1:0]      q_dest,
  input  wire logic [NQ*4-1:0]      q_quantum,
  input  wire logic [NQ*32-1:0]     q_budget,
  input  wire logic [8*16-1:0]      dest_mask_flat,
  input  wire logic                 pol_busy,
  input  wire logic                 pol_acc,
  output logic                      idle_o,
  // ---------------------------------------------------------------- isolation check
  output logic                      chk_valid,
  input  wire logic                 chk_ready,
  output logic [2:0]                chk_dom,
  output logic                      chk_write,
  output logic [31:0]               chk_base,
  output logic [39:0]               chk_len,
  input  wire logic                 chk_rsp_valid,
  input  wire logic                 chk_rsp_ok,
  input  wire logic [3:0]           chk_rsp_fault,
  // ---------------------------------------------------------------- tensor executor
  output logic                      tx_start,
  input  wire logic                 tx_ready,
  output logic [15:0]               tx_m, tx_n, tx_k,
  output logic [31:0]               tx_a, tx_b, tx_c, tx_d,
  output logic                      tx_acc,
  input  wire logic                 tx_done,
  input  wire logic [`CW_ST_W-1:0]  tx_status,
  input  wire logic [15:0]          tx_detail,
  input  wire logic [31:0]          tx_out_bytes,
  input  wire logic [47:0]          tx_macs,
  input  wire logic [39:0]          tx_array_busy,
  input  wire logic                 tx_ph_load, tx_ph_compute, tx_ph_store,
  // ---------------------------------------------------------------- vector executor
  output logic                      vx_start,
  input  wire logic                 vx_ready,
  output logic [7:0]                vx_op,
  output logic [7:0]                vx_etype,
  output logic [2:0]                vx_rm,
  output logic [31:0]               vx_vl,
  output logic [31:0]               vx_a, vx_b, vx_c, vx_d,
  input  wire logic                 vx_done,
  input  wire logic [`CW_ST_W-1:0]  vx_status,
  input  wire logic [15:0]          vx_detail,
  input  wire logic [31:0]          vx_out_bytes,
  input  wire logic [4:0]           vx_fflags,
  input  wire logic [39:0]          vx_active,
  input  wire logic                 vx_ph_load, vx_ph_compute, vx_ph_store,
  // ---------------------------------------------------------------- clear executor
  output logic                      cx_start,
  input  wire logic                 cx_ready,
  output logic [31:0]               cx_base,
  output logic [31:0]               cx_len,
  input  wire logic                 cx_done,
  input  wire logic [2:0]           cx_err,
  // ---------------------------------------------------------------- staging
  output logic                      stg_clear,
  // ---------------------------------------------------------------- completion queue
  output logic                      cpl_valid,
  input  wire logic                 cpl_ready,
  output logic [QW-1:0]             cpl_queue,
  output logic [2:0]                cpl_domain,
  output logic [3:0]                cpl_dest,
  output logic [15:0]               cpl_tag,
  output logic [7:0]                cpl_op,
  output logic [`CW_ST_W-1:0]       cpl_status,
  output logic [15:0]               cpl_detail,
  output logic [4:0]                cpl_fflags,
  output logic [31:0]               cpl_out_bytes,
  output logic [31:0]               cpl_cycles,
  output logic [31:0]               cpl_qwait,
  output logic [31:0]               cpl_seq,
  // ---------------------------------------------------------------- perf events
  output logic                      busy_o,
  output logic                      ph_load_o, ph_compute_o, ph_store_o,
  output logic                      ev_cpl,
  output logic [`CW_ST_W-1:0]       ev_status,
  output logic [31:0]               ev_qwait,
  output logic [31:0]               ev_exec,
  output logic                      ev_gemm, ev_vec,
  output logic [47:0]               ev_macs,
  output logic [39:0]               ev_array_busy,
  output logic [31:0]               ev_vec_elems,
  output logic [39:0]               ev_vec_active,
  output logic [31:0]               ev_out_bytes,
  output logic [31:0]               ev_scrub_bytes,
  output logic                      ev_stall_cpl
);
  // ---------------------------------------------------------------------------
  // arbitration
  // ---------------------------------------------------------------------------
  logic [NQ-1:0]       elig;
  logic [1:0]          cls [NQ];
  logic [NQ-1:0]       cand;
  logic [QW-1:0]       last_q;
  logic                last_v_q;
  logic [4:0]          sticky_q;
  logic [7:0]          wait_q [NQ];
  logic                any_elig;
  logic [QW-1:0]       sel;

  always_comb begin
    logic [1:0] maxc;
    logic       found;
    elig = '0;
    for (int q = 0; q < NQ; q++) elig[q] = head_valid[q] && q_en[q];
    maxc = 2'd0;
    for (int q = 0; q < NQ; q++) begin
      cls[q] = (int'(wait_q[q]) >= STARVE_LIMIT) ? 2'd3 : q_prio[q*`CW_PRIO_W +: `CW_PRIO_W];
      if (elig[q] && (cls[q] > maxc)) maxc = cls[q];
    end
    for (int q = 0; q < NQ; q++) cand[q] = elig[q] && (cls[q] == maxc);
    any_elig = |elig;
    sel   = '0;
    found = 1'b0;
    // sticky: keep the same queue for up to `quantum` consecutive commands
    if (last_v_q && cand[last_q] && (int'(sticky_q) < int'(q_quantum[last_q*4 +: 4]))) begin
      sel = last_q; found = 1'b1;
    end
    // otherwise round robin starting after the last winner
    for (int i = 1; i <= NQ; i++) begin
      int idx;
      idx = (int'(last_q) + i) % NQ;
      if (!found && cand[idx]) begin sel = QW'(idx); found = 1'b1; end
    end
  end

  // ---------------------------------------------------------------------------
  // command state
  // ---------------------------------------------------------------------------
  typedef enum logic [3:0] {
    S_IDLE, S_DEC, S_CHK, S_CHKW, S_RUN, S_WAIT, S_COMPLETE
  } st_e;
  st_e st_q;

  logic [QW-1:0]   cq_q;
  logic [255:0]    desc_q;
  logic [TSW-1:0]  enq_q, disp_q;
  logic [2:0]      chk_idx_q, chk_cur_q;

  // facts of the selected queue
  wire        f_bound = q_bound[cq_q];
  wire [2:0]  f_dom   = q_dom[cq_q*3 +: 3];
  wire [3:0]  f_dest  = q_dest[cq_q*4 +: 4];
  wire [31:0] f_bud   = q_budget[cq_q*32 +: 32];
  wire [15:0] f_dmask = dest_mask_flat[f_dom*16 +: 16];

  // decoder
  logic [`CW_ST_W-1:0] d_status;
  logic [15:0]         d_detail;
  logic                d_dest_def;
  logic [7:0]          d_op, d_etype;
  logic [2:0]          d_rm;
  logic                d_acc;
  logic [15:0]         d_tag;
  logic [2:0]          d_claim;
  logic [3:0]          d_dest;
  logic [15:0]         d_m, d_n, d_k;
  logic [31:0]         d_a, d_b, d_c, d_d, d_len;
  logic [47:0]         d_work;
  logic [3:0]          d_ruse;
  logic [4*32-1:0]     d_rbase;
  logic [4*40-1:0]     d_rlen;

  sf_compute_decoder #(.SRAM_BASE(SRAM_BASE), .SRAM_BYTES(SRAM_BYTES), .KMAX(KMAX), .EN_VECTOR(EN_VECTOR), .EN_INT32(EN_INT32)) u_dec (
    .desc(desc_q), .q_bound(f_bound), .q_dom(f_dom), .q_dest(f_dest), .dest_mask(f_dmask), .q_budget(f_bud),
    .status(d_status), .detail(d_detail), .dest_is_default(d_dest_def),
    .op(d_op), .etype(d_etype), .rm(d_rm), .acc(d_acc), .tag(d_tag), .claim(d_claim), .dest(d_dest),
    .m(d_m), .n(d_n), .k(d_k), .src_a(d_a), .src_b(d_b), .src_c(d_c), .dst(d_d), .len(d_len), .work(d_work),
    .r_use(d_ruse), .r_base(d_rbase), .r_len(d_rlen));

  wire d_is_gemm  = (d_op == `CW_OP_GEMM);
  wire d_is_vec   = (d_op == `CW_OP_VADD) || (d_op == `CW_OP_VMUL) || (d_op == `CW_OP_VFMA);
  wire d_is_clear = (d_op == `CW_OP_CLEAR);

  // result registers
  logic [`CW_ST_W-1:0] r_status_q;
  logic [15:0]         r_detail_q;
  logic                r_dest_def_q;
  logic [31:0]         r_out_q;
  logic [4:0]          r_ff_q;
  logic [47:0]         r_macs_q;
  logic [39:0]         r_arr_q;
  logic [39:0]         r_vact_q;
  logic [31:0]         r_elems_q;
  logic [31:0]         r_scrub_q;
  logic [31:0]         seq_q;
  logic [31:0]         qwait_q;

  assign idle_o = (st_q == S_IDLE);
  assign busy_o = (st_q != S_IDLE);

  // pop pulse at selection
  wire start_ok = clk_en_i && !pol_busy && !pol_acc && any_elig && (st_q == S_IDLE);
  always_comb begin
    pop = '0;
    if (start_ok) pop[sel] = 1'b1;
  end

  // isolation-check request: next used operand at or after chk_idx_q
  logic       chk_found;
  logic [2:0] chk_next;
  always_comb begin
    chk_found = 1'b0;
    chk_next  = 3'd0;
    for (int i = 3; i >= 0; i--) if ((i >= int'(chk_idx_q)) && d_ruse[i]) begin chk_found = 1'b1; chk_next = 3'(i); end
  end
  assign chk_valid = (st_q == S_CHK) && chk_found;
  assign chk_dom   = f_dom;
  assign chk_write = (chk_next == 3'd3);                          // operand D is the only write
  assign chk_base  = d_rbase[chk_next[1:0]*32 +: 32];
  assign chk_len   = d_rlen[chk_next[1:0]*40 +: 40];

  // executor start (the decoded fields come straight from the held descriptor)
  assign tx_start = (st_q == S_RUN) && d_is_gemm  && tx_ready;
  assign vx_start = (st_q == S_RUN) && d_is_vec   && vx_ready;
  assign cx_start = (st_q == S_RUN) && d_is_clear && cx_ready;
  assign tx_m = d_m; assign tx_n = d_n; assign tx_k = d_k;
  assign tx_a = d_a; assign tx_b = d_b; assign tx_c = d_c; assign tx_d = d_d; assign tx_acc = d_acc;
  assign vx_op = d_op; assign vx_etype = d_etype; assign vx_rm = d_rm; assign vx_vl = d_len;
  assign vx_a = d_a; assign vx_b = d_b; assign vx_c = d_c; assign vx_d = d_d;
  assign cx_base = d_d; assign cx_len = d_len;

  assign ph_load_o    = (st_q == S_WAIT) && (tx_ph_load    || vx_ph_load);
  assign ph_compute_o = (st_q == S_WAIT) && (tx_ph_compute || vx_ph_compute);
  assign ph_store_o   = (st_q == S_WAIT) && (tx_ph_store   || vx_ph_store || d_is_clear);

  // ---------------------------------------------------------------------------
  // completion FIFO
  // ---------------------------------------------------------------------------
  localparam int RECW = QW + 3 + 4 + 16 + 8 + `CW_ST_W + 16 + 5 + 32 + 32 + 32 + 32;
  logic [RECW-1:0] fifo [CPL_DEPTH];
  logic [CQW-1:0]  f_cnt_q;
  localparam int FPW = (CPL_DEPTH > 1) ? $clog2(CPL_DEPTH) : 1;
  logic [FPW-1:0] f_rd_q, f_wr_q;
  wire             f_full  = (int'(f_cnt_q) == CPL_DEPTH);
  wire             f_empty = (f_cnt_q == '0);
  wire             f_push  = (st_q == S_COMPLETE) && !f_full;
  wire             f_pop   = cpl_valid && cpl_ready;

  // A rejected command's completion goes to the queue's default destination, but only if the domain may use it;
  // otherwise to destination 0 (always allowed).  The claimed DEST of a command that was NOT validated is never used.
  wire [3:0]  fin_dest   = r_dest_def_q ? (f_dmask[f_dest] ? f_dest : 4'd0) : d_dest;
  wire [31:0] exec_cyc   = now - disp_q;
  wire [RECW-1:0] rec_in = {cq_q, f_dom, fin_dest, d_tag, d_op, r_status_q, r_detail_q, r_ff_q, r_out_q,
                            exec_cyc, qwait_q, seq_q};

  logic [RECW-1:0] rec_out;
  assign rec_out = fifo[f_rd_q];
  assign cpl_valid = !f_empty;
  assign {cpl_queue, cpl_domain, cpl_dest, cpl_tag, cpl_op, cpl_status, cpl_detail, cpl_fflags, cpl_out_bytes,
          cpl_cycles, cpl_qwait, cpl_seq} = rec_out;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      f_cnt_q <= '0; f_rd_q <= '0; f_wr_q <= '0;
      for (int i = 0; i < CPL_DEPTH; i++) fifo[i] <= '0;
    end else begin
      if (f_push) begin
        fifo[f_wr_q] <= rec_in;
        f_wr_q <= (int'(f_wr_q) == CPL_DEPTH - 1) ? '0 : f_wr_q + 1'b1;
      end
      if (f_pop) f_rd_q <= (int'(f_rd_q) == CPL_DEPTH - 1) ? '0 : f_rd_q + 1'b1;
      case ({f_push, f_pop})
        2'b10:   f_cnt_q <= f_cnt_q + 1'b1;
        2'b01:   f_cnt_q <= f_cnt_q - 1'b1;
        default: ;
      endcase
    end
  end

  // ---------------------------------------------------------------------------
  // events (combinational pulses aligned with the push)
  // ---------------------------------------------------------------------------
  wire is_ok_st   = (r_status_q == `CW_ST_OK);
  assign ev_cpl         = f_push;
  assign ev_status      = r_status_q;
  assign ev_qwait       = qwait_q;
  assign ev_exec        = exec_cyc;
  assign ev_gemm        = f_push && d_is_gemm;
  assign ev_vec         = f_push && d_is_vec;
  assign ev_macs        = (f_push && d_is_gemm && is_ok_st) ? r_macs_q : 48'd0;
  assign ev_array_busy  = (f_push && d_is_gemm) ? r_arr_q : 40'd0;
  assign ev_vec_elems   = (f_push && d_is_vec && is_ok_st) ? d_len : 32'd0;
  assign ev_vec_active  = (f_push && d_is_vec) ? r_vact_q : 40'd0;
  assign ev_out_bytes   = (f_push && is_ok_st) ? r_out_q : 32'd0;
  assign ev_scrub_bytes = (f_push && d_is_clear && is_ok_st) ? r_scrub_q : 32'd0;
  assign ev_stall_cpl   = (st_q == S_COMPLETE) && f_full;
  assign stg_clear      = CLEAR_STAGING && f_push;

  // ---------------------------------------------------------------------------
  // sequencing
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE; cq_q <= '0; desc_q <= '0; enq_q <= '0; disp_q <= '0; chk_idx_q <= '0; chk_cur_q <= '0;
      r_status_q <= `CW_ST_OK; r_detail_q <= '0; r_dest_def_q <= 1'b0; r_out_q <= '0; r_ff_q <= '0;
      r_macs_q <= '0; r_arr_q <= '0; r_vact_q <= '0; r_elems_q <= '0; r_scrub_q <= '0;
      seq_q <= '0; qwait_q <= '0;
      last_q <= '0; last_v_q <= 1'b0; sticky_q <= '0;
      for (int q = 0; q < NQ; q++) wait_q[q] <= '0;
    end else begin
      case (st_q)
        S_IDLE: if (start_ok) begin
          cq_q     <= sel;
          desc_q   <= head_desc[sel*256 +: 256];
          enq_q    <= head_ts[sel*TSW +: TSW];
          disp_q   <= now;
          qwait_q  <= now - head_ts[sel*TSW +: TSW];
          // arbitration bookkeeping
          if (last_v_q && (sel == last_q)) sticky_q <= (sticky_q == 5'd31) ? sticky_q : sticky_q + 5'd1;
          else                             sticky_q <= 5'd1;
          last_q   <= sel;
          last_v_q <= 1'b1;
          for (int q = 0; q < NQ; q++) begin
            if (q == int'(sel))       wait_q[q] <= '0;
            else if (elig[q])         wait_q[q] <= (wait_q[q] == 8'hFF) ? wait_q[q] : wait_q[q] + 8'd1;
          end
          r_out_q <= '0; r_ff_q <= '0; r_macs_q <= '0; r_arr_q <= '0; r_vact_q <= '0; r_elems_q <= '0; r_scrub_q <= '0;
          r_detail_q <= '0; r_dest_def_q <= 1'b0; r_status_q <= `CW_ST_OK;
          st_q <= S_DEC;
        end

        S_DEC: begin
          if (d_status != `CW_ST_OK) begin
            r_status_q   <= d_status;
            r_detail_q   <= d_detail;
            r_dest_def_q <= d_dest_def;
            st_q         <= S_COMPLETE;
          end else if (d_op == `CW_OP_NOP) begin
            r_status_q <= `CW_ST_OK;
            st_q       <= S_COMPLETE;
          end else begin
            chk_idx_q <= 3'd0;
            st_q      <= S_CHK;
          end
        end

        S_CHK: begin
          if (!chk_found) st_q <= S_RUN;
          else if (chk_ready) begin
            chk_cur_q <= chk_next;
            st_q      <= S_CHKW;
          end
        end

        S_CHKW: if (chk_rsp_valid) begin
          if (!chk_rsp_ok) begin
            r_status_q   <= `CW_ST_DENIED;
            r_detail_q   <= {8'd0, chk_rsp_fault, 1'b0, chk_cur_q + 3'd1};   // {fault, operand id}
            r_dest_def_q <= 1'b0;
            st_q         <= S_COMPLETE;
          end else begin
            chk_idx_q <= chk_cur_q + 3'd1;
            st_q      <= S_CHK;
          end
        end

        S_RUN: begin
          if (tx_start || vx_start || cx_start) st_q <= S_WAIT;
        end

        S_WAIT: begin
          if (d_is_gemm && tx_done) begin
            r_status_q <= tx_status; r_detail_q <= tx_detail; r_out_q <= tx_out_bytes;
            r_macs_q <= tx_macs; r_arr_q <= tx_array_busy;
            st_q <= S_COMPLETE;
          end else if (d_is_vec && vx_done) begin
            r_status_q <= vx_status; r_detail_q <= vx_detail; r_out_q <= vx_out_bytes;
            r_ff_q <= vx_fflags; r_vact_q <= vx_active;
            st_q <= S_COMPLETE;
          end else if (d_is_clear && cx_done) begin
            if (cx_err != 3'd0) begin
              r_status_q <= `CW_ST_MEM_ERR;
              r_detail_q <= {`CW_PH_CLEAR, 9'd0, cx_err};
            end else begin
              r_status_q <= `CW_ST_OK;
              r_out_q    <= d_len;
              r_scrub_q  <= d_len;
            end
            st_q <= S_COMPLETE;
          end
        end

        S_COMPLETE: if (!f_full) begin
          seq_q <= seq_q + 32'd1;
          st_q  <= S_IDLE;
        end

        default: st_q <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
