# 01 · Architecture (brief §2, §4)

```
 Keystone ──policy──▶ ┌───────────────────────────── sf_compute_tile ─────────────────────────────┐
 (management plane)   │                                                                           │
                      │  sub_desc ─▶ [sf_compute_command_queue  NQ queues × DEPTH]                │
 host / fabric ──────▶│                    │ head descriptors                                     │
                      │                    ▼                                                      │
                      │   [sf_compute_scheduler]  arbitrate → decode/validate → isolation check   │
                      │        │      │ (sf_compute_decoder)   │ (sf_compute_guard ◀─ Citadel)    │
                      │        │      ▼ dispatch               ▼                                  │
                      │   tensor exec     vector exec     clear exec        ──▶ completion FIFO ──┼──▶ completion record
                      │   (TC02, INT8)    (HPC M03, FP32/INT32)  (zero-fill)                       │
                      │        └──────────────┬───────────────┘                                   │
                      │                  jobs │ (2-D copy)        staging A / B / C / OUT         │
                      │            [sf_compute_memory_adapter: NUM_CP × sf_compute_mem_engine]    │
                      │                       │ master ports (domain 3: ComputeWorks)             │
                      │   Keystone port ─▶ [IronMemory P84: banks, ECC, buffer ownership] ◀─ BridgeEngine (DMA) port
                      │   (domain 0)                                                  (domain 1)  │
                      └───────────────────────────────────────────────────────────────────────────┘
```

Pipeline of one command (brief §2): **command queue → command decoder → local scheduler → vector / tensor execution → local SRAM
→ result completion.** Exactly one command is in flight (the reference configuration: *one outstanding compute command*).

## Modules

| File | Role |
|---|---|
| `sf_compute_tile.sv` | **Top.** Instantiates and wires everything, including the IronMemory instance. |
| `sf_compute_defs.svh` | Single source of truth: descriptor layout, opcodes, element types, status / fault / policy codes, counter map. `model/cw_defs.py` is generated from it. |
| `sf_compute_command_queue.sv` | `NQ` descriptor FIFOs of `CMD_QUEUE_DEPTH` entries, time-stamped at enqueue. |
| `sf_compute_decoder.sv` | Combinational validation (precedence in `02_COMMANDS.md`); produces decoded fields and the byte ranges to approve. |
| `sf_compute_guard.sv` | Isolation: policy port, region table (reference Citadel), range check, external-Citadel passthrough, queue / destination configuration. |
| `sf_compute_scheduler.sv` | Queue arbitration, command sequencing, completion FIFO, performance events. |
| `sf_compute_tensor_exec.sv` | INT8 GEMM sequencer around the reused TC02 array. |
| `sf_compute_vector_exec.sv` | FP32 / INT32 element-wise sequencer around the reused HPC M03 array. |
| `sf_compute_clear_exec.sv` | Zero-fill (the `CLEAR` command and the guard's `SCRUB`). |
| `sf_compute_memory_adapter.sv` / `sf_compute_mem_engine.sv` | Local-memory access: job-driven 2-D copy engines (one per compute port) and the four staging buffers. |
| `sf_compute_perf.sv` | 33 saturating 40-bit counters. |
| reused | `sf_iron_memory` (+12 blocks), `tensor_systolic_array` (+3), `hpc_vector_array` (+16) |

## Compute configuration (brief §4)

| Brief item | Parameter | Reference | Legal / verified |
|---|---|---|---|
| Number of vector lanes | `NUM_LANES` | **4** | 1, 2, 4, 8, 16 (all five verified) |
| Tensor array dimensions | `TENSOR_ROWS`, `TENSOR_COLS` | **4 × 4** | 2×2, 4×2, 4×4, 8×8 verified; TC02 allows any `R × C` |
| Scratchpad capacity | `NUM_BANKS × BANK_DEPTH × DMA_DW/8` | 4 × 1024 × 8 B = **32 KiB** (testbench: 4 × 512 = 16 KiB; benchmark: 64 KiB) | `BANK_DEPTH` and `NUM_BANKS` (1..16) are IronMemory's |
| Command queue depth | `CMD_QUEUE_DEPTH` (per queue) | 4 | any ≥ 1; 2, 4, 8, 16 exercised |
| Queues | `NUM_QUEUES` | **1** | 1..4 (1, 2, 4 verified) |
| DMA data width | `DMA_DW` | 64 bit | 64, 128 (both verified; this is IronMemory's word width and so also the BridgeEngine port width) |
| Numeric format | `EN_VECTOR`, `EN_INT32`; element type in the descriptor | FP32 + INT8 (+INT32) | FP16 / BF16 / FP64 are **rejected**, not implemented |
| Clock-enable control | `clk_en_i`, `clk_gate_ok_o` | — | see below |
| Compute ports on the memory | `NUM_CP` | **1** | 1 or 2 (both verified) |
| Staging capacity | `STG_BYTES` | 1024 | power of two ≥ 64 (256, 1024, 2048 verified); sets `KMAX` and the vector chunk |
| Guard | `GUARD_MODE` | 1 (reference Citadel) | 0 off (**no isolation**), 1 reference, 2 external |
| Completion queue depth | `CPL_DEPTH` | 4 | 2, 4, 8 exercised |

**Reference configuration (brief §4):** four FP32 lanes, one 4×4 INT8 array, local operand SRAM (IronMemory), one outstanding
command – exactly the `base` configuration of the regression.

**Clock-enable control.** `clk_en_i` is a *dispatch* enable: it stops the scheduler starting a command; a command that has
started always runs to completion (there is no mid-kernel freeze – the reused arrays and IronMemory keep state that cannot be
frozen from outside). `clk_gate_ok_o` is high only when the scheduler is idle, every queue and the completion FIFO are empty,
every memory engine is idle and no policy operation is running, i.e. when a clock gate may safely be closed. **No clock gating
cell is instantiated**; the integrator gates the clock. Note IronMemory's optional background scrubber stops with the clock.

## Data path

**Staging.** Four flip-flop buffers of `STG_BYTES` (A, B, C, OUT). Operands stay in IronMemory; a command copies only what it
needs into staging (A/B/C by read jobs, OUT by the executors, written back by a store job). Staging is zeroed in one cycle at the
end of every command (`CLEAR_STAGING`, default on) – the scratchpad-residue control.

**Memory access** (`03_MEMORY.md`): everything is an aligned full-word access with byte strobes, so any byte alignment works,
bytes outside a requested row are never kept, and no write ever touches a neighbouring byte.

**INT8 GEMM** `D[M,N] (INT32) = A[M,K] (INT8) × B[K,N] (INT8) [+ C]`. The output is cut into `ROWS × COLS` blocks (edge blocks
are partial tiles). For each block: load A rows (reused across the column blocks of the same row block), load the B column
block, optionally load C; launch TC02; stream `s_k` slices from staging; collect result rows (adding C_in on the fly if
accumulating); store the block. Packed row-major layouts, `lda = K`, `ldb = N`, `ldd = N`. Accumulation **wraps modulo 2³²**
(no saturation, no flag). `K ≤ KMAX = min(STG/ROWS, STG/COLS)` (256 in the reference); larger K is rejected
(`CW_ST_RESLIMIT`), not silently split.

**FP32 / INT32 vectors** `VADD`, `VMUL`, `VFMA`: processed in chunks of `STG_BYTES/4` elements: load A, B (and C); one command
to the HPC array; `⌈chunk/NUM_LANES⌉` operand beats (element *e* → beat ⌊e/N⌋, lane *e* mod N); result beats land in OUT; the
array's completion carries the OR of the exception flags; store. Flags of all chunks are ORed into `FFLAGS`.

**Two compute ports.** With `NUM_CP = 2`, A and B load concurrently (engine 0 and engine 1); with 1 they serialise on engine 0.
IronMemory's per-bank round-robin arbiter then resolves conflicts between the two engines, the Keystone port and the
BridgeEngine port. The design never assumes more SRAM ports than it has.

**Not overlapped (stated, measured).** Load, compute and store of one command do not overlap, and consecutive commands do not
overlap. That bounds utilisation (`06_PERFORMANCE.md`): the structure leaves room for double-buffered staging, which was not built.

## Reset and clocking

One clock. `rst_n` is asynchronous-assert; the reused TC02 array uses a *synchronous* reset on the same net (a documented lint
waiver). Reset empties the queues, discards in-flight commands (no completion is produced for them), clears the policy to
**default deny** (every queue unbound, every region invalid and clean, destination 0 only), and IronMemory re-initialises the
whole SRAM to zero. After reset the supervisor must re-allocate IronMemory buffers and re-program the policy.
