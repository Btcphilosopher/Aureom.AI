# Repository and toolchain audit

Audit date: 2026-11-15. Performed before any QuantumTunnel code was written.

## What was inspected

The SilicaFlux repository reachable from this session is
`github.com/Btcphilosopher/SilicaFlux` (public, single commit `1244025`,
"Add files via upload"). It was cloned read-only. **Nothing was committed or
pushed.** The repository root holds a README plus sub-projects packaged as
archives; each archive was extracted into its own scratch directory and read,
not executed:

| Archive | Contents relevant to this project |
|---|---|
| `silicaflux.zip` | Core SilicaFlux cluster RTL (`silicaflux_pkg.sv`, NoC `noc_router`/`noc_interconnect` with `noc_flit_t`, tensor/vector units), Icarus `run_sim.sh`, Vivado/Quartus synthesis TCL (tools not present here), `sfx_asm.py` assembler for `.sfx` programs |
| `SilicaFlux2.0/silicafluxai.zip` | SilicaFlux-AI: `sfx_saturate`, `sfx_skid_buffer`, `sfx_fifo`, `sfx_stream_if`, `sfx_mac`; pyproject (setuptools, pydantic, pytest, hypothesis); `docs/TOOLING.md` (Icarus 12 limitations), `docs/TIMING_AND_RESET.md`, `docs/PHASE_STATUS.md` |
| `SilicaFlux2.0/SilicaFluxML.zip` | Python fixed-point model, RTL marked *pseudocode, never simulated*, and the only `.sf` file: `dsl/silicaflux_ml.sf` |
| `dsp_arithmetic.zip` | `fixed_point_pkg.sv` (signed Q-format helpers with saturation), `sat_arith.sv`, MAC/FIR/FFT with Icarus testbenches |
| `soc_integration.tar.gz` | SoC Simple Bus (`soc_bus_if`: req/rsp valid-ready, 32-bit addr/data, wstrb, error), `soc_fabric` decoder, peripherals, memory map in `soc_pkg.sv` |
| `SilicaFlux2.0/silicafluxbitcoinasic.zip` | SHA-256 ASIC RTL + Python golden vectors in `.hex` files for `$readmemh` |
| others | FSM library, RISC-V/pipelined CPUs, caches, comm protocols, formal-property examples, UVM-style FIFO environment |

## Requested items: found / not found

| Item | Status |
|---|---|
| TransistorLab code | **Not present** anywhere in the repository |
| ProcessStack / material definitions | **Not present** -- no dielectric/semiconductor material database exists |
| CMOS device models | **Not present** |
| Python scientific infrastructure | Present but unrelated (SilicaFlux-AI GEMM models, SilicaFluxML fixed-point learning model, bitcoin-ASIC vector generators). No physics code. |
| SystemVerilog packages | `silicaflux_pkg`, `fixed_point_pkg`, `soc_pkg`, `sha256_pkg`, `silicaflux_ml_pkg`, `fsm_pkg`, `mem_pkg`, `cpu_pkg`, `rv32i_pkg` |
| DataFabric | **No module of that name.** The closest existing transaction formats are the core NoC flit (`noc_flit_t` in `silicaflux_pkg.sv`) and the SoC Simple Bus (`soc_bus_if`) |
| Floating-point modules | **None** (SilicaFlux-AI explicitly has no FP datapath) |
| Fixed-point modules | `fixed_point_pkg.sv` (Q8.8 default helpers), `sat_arith.sv`, `sfx_saturate.sv`; SilicaFluxML `fixed_point_ops.sv` is unsimulated pseudocode |
| Testbenches | Many, Icarus-based, self-checking, ending with `SFX_TB_RESULT: PASS|FAIL` (SilicaFlux-AI convention) |
| Build scripts | Makefiles per sub-project, `run_sim.sh`, `scripts/run_unit_tests.sh` |
| Silica Flux `.sf` sources | One file. Its own header states it is *"a speculative sketch ... not a parseable or compiled language"*. There is **no `.sf` compiler or transpiler** in the repository. |
| Toolchain documentation | `silicaflux-ai/docs/TOOLING.md` (Icarus 12.0 limitations and the bug log they caused) |

## Conventions adopted from the existing code

* `` `default_nettype none `` / `` `timescale 1ns/1ps `` in every RTL file.
* Single clock domain; **synchronous active-low reset** (`if (!rst_n)` inside
  `always_ff @(posedge clk)`), as specified in `TIMING_AND_RESET.md`. The new
  core keeps the brief's port names (`clk_i`, `rst_ni`, `*_i`/`*_o`) because
  the brief defines that interface explicitly; reset semantics follow the
  repository.
* Immediate assertions only, wrapped in `` `ifndef SFX_SYNTHESIS `` (Icarus 12
  rejects concurrent SVA).
* Flattened packed vectors on ports (Icarus drops unpacked-array ports).
* Testbenches print `SFX_TB_RESULT: PASS|FAIL` as their last line.
* Every numeric result is labelled with its origin (RTL SIMULATION,
  SYNTHESIS TOOL, ANALYTICAL, PYTHON MODEL ...), as in `PHASE_STATUS.md`.
* Python: setuptools `pyproject.toml`, pydantic, pytest + hypothesis.

## Reuse

* `sfx_skid_buffer.sv` is vendored unmodified (with a provenance header) as
  the core's output stage. It gives full throughput and backpressure with no
  combinational `ready` path, and it is already verified in SilicaFlux-AI.
* The SoC Simple Bus signal set is reused for the optional memory-mapped
  register adapter (`rtl/integration/sf_qt_ssb_regs.sv`). Using the existing
  transaction format avoids inventing a new one.
* The `.sf` surface syntax of `silicaflux_ml.sf` is mirrored by a
  documentation-only sketch of the core (`sf/sf_quantum_tunnel.sf`), with a
  test that keeps its port list in step with the SystemVerilog. It is not
  compiled because no compiler exists, and `.sf` is not treated as `.sv`.

## Toolchain in this environment

| Tool | Version | Use |
|---|---|---|
| Python | 3.13.x | all Python (3.12+ required by the brief; 3.11+ declared) |
| numpy / scipy / pydantic / pandas / matplotlib | 2.5 / 1.18 / 2.13 / 3.0 / 3.11 | core |
| h5py / plotly / hypothesis / mpmath / fastapi | installed during the audit | storage / dashboard / tests / HP reference / API |
| scipy.constants | CODATA **2022** | detected at runtime and recorded in every provenance file |
| Icarus Verilog | 12.0 (installed during the audit) | primary RTL simulator (repository default) |
| Verilator | 5.020 (installed) | lint + second simulator (cross-simulator determinism) |
| Yosys | 0.33 (installed) | generic, ECP5 and iCE40 synthesis; ABC + liberty for ASIC-style cell area |
| nextpnr-ecp5 / nextpnr-ice40 | 0.6 (installed) | post-route timing and utilisation |
| cocotb | 2.1 (installed) | optional; the regression uses SV testbenches + Python comparison |
| OpenSTA / OpenROAD / commercial EDA | **not available** | no signoff STA, no ASIC place-and-route, no power analysis |
| ngspice | **not available** | circuit-level comparison not performed |
| DEVSIM | wheel available, not required | importer for DEVSIM-exported potentials is provided |

Yosys 0.33 limitation found during the audit: it rejects `import pkg::*`
(both file- and module-scope). The RTL therefore references package items
explicitly as `sf_qt_pkg::NAME`, which Icarus, Verilator and Yosys all accept.

## Branch / delivery

The work is delivered as a standalone project directory
(`silicaflux-quantumtunnel/`), shaped like the repository's existing
self-contained sub-projects. Per instruction, no branch was pushed and nothing
was committed to GitHub. To adopt it, create a branch such as
`feature/quantumtunnel` and add the directory. Existing working modules are
untouched.
