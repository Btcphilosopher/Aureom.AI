# Phase status (brief section 45)

Legend:

- **DONE** = implemented and passing real tests.
- **PARTIAL** = some real, tested function exists, but not the phase's full scope.
- **NOT STARTED** = nothing exists for this phase yet.

| Phase | Scope | Status | Evidence |
|---|---|---|---|
| 1 | Audit; unit-aware physics package | DONE | `docs/AUDIT.md`; `quantum/constants.py`, `units.py`; `tests/physics/test_units_constants.py` |
| 2 | Exact rectangular transmission | DONE | `rectangular.py`; 60-digit independent reference; validation checks 1–3, 5, 17 |
| 3 | WKB + comparison with exact | DONE | `wkb.py`; experiment A; validation 12; 7 validity flags tested |
| 4 | Stable numerical scattering solver | DONE | `scattering.py` + independent `schrodinger.py`; checks 6, 7, 9, 10, 13, 14 |
| 5 | Trapezoidal barriers, MOS dielectric profiles | DONE | `barriers.py`, `devices/`; experiment B; MOS electrostatics tests |
| 6 | Energy and thickness sweeps | DONE | `analysis/sweeps.py` (adaptive grid); experiments A, C |
| 7 | Fixed-point SystemVerilog WKB core | DONE | `rtl/quantum/sf_quantum_tunnel_core.sv`; lint clean; 7 configurations simulated |
| 8 | Golden vectors, Python/RTL agreement | DONE | `reference/tunneling_golden.py`; bit-exact on Icarus + Verilator; experiment E |
| 9 | Sweeps, hardware benchmarks, engineering reports | DONE | `reports/benchmarks`, `reports/synthesis` (real tools), `reports/INDEX.md` |
| 10 | TransistorLab integration, dashboard | PARTIAL | dashboard DONE (15 panels + 3D view). TransistorLab does not exist in the repository, so a contract plus adapter is provided and tested against synthetic requests |
| — | Sampled-profile integrator ("later" in the brief) | DONE | `sf_qt_integrator.sv`, bit-exact, II = 1 sample/cycle |
| — | Gate-current density from Si inversion layers | NOT STARTED | refused with `UnsupportedModelError` (roadmap item 2) |
| — | DataFabric adapter | NOT STARTED | no DataFabric in the repository; SSB adapter provided instead |

## Acceptance criteria (brief section 46)

| # | Criterion | Met | Evidence |
|---|---|---|---|
| 1 | Exact rectangular model runs | yes | `sf-quantum solve exact` |
| 2 | WKB with valid units | yes | validation 4 |
| 3 | Numerical scattering runs | yes | two independent solvers |
| 4 | Reference comparisons pass | yes | 18/18 |
| 5 | Transmission physically valid | yes | checks 8, 9 |
| 6 | Limitations reported | yes | WKB flags; `LIMITATIONS.md` |
| 7 | Synthesizable SV elaborates | yes | Yosys / Icarus / Verilator |
| 8 | RTL reproducible | yes | identical traces across simulators and runs |
| 9 | Python/RTL error measured | yes | `reports/rtl` |
| 10 | Synthesis reports with real tools | yes | `reports/synthesis` |
| 11 | Sweeps save reproducible datasets | yes | `data/experiments` |
| 12 | Dashboard shows solver data | yes | `dashboard/index.html` |
