# Physics models, scope and limitations

All models are **one-dimensional, single-band, parabolic effective-mass, coherent and elastic**. That
means no phonons, no traps, no many-body effects and no self-consistency between tunnelling current and
electrostatics. SI units are used internally, and conversions are explicit (`quantum/units.py`).

## Potential profiles

`PotentialProfile` = left lead | linear layers (constant mass each) | right lead.

- **Exactly representable:** rectangular, trapezoidal and triangular barriers, multiple barriers, and multilayer dielectrics.
- **As piecewise-linear interpolants:** smooth callables and imported samples.
- **Energy reference:** every profile carries one, and imports must state it (`custom:<description>` is allowed).
- **Bias:** an applied field is superimposed with `with_field()` or by the factories.
- **Band offsets:** barrier heights in device models are conduction-band offsets, never the Si band gap.

## Level 1 — exact rectangular barrier (`rectangular.py`)

Uses the BenDaniel-Duke matching (ψ and ψ'/m continuous), with barrier mass m_b and identical leads of mass m_l.
The unified form T = [1 + P f²]⁻¹ uses f = sinh(qa)/q, continued analytically through E = V0, and is
evaluated as log T = −logaddexp(0, log P + 2 log|f|). The result:

- stays finite for 50 nm barriers;
- has no sinh overflow;
- computes R = 1 − T without cancellation.

**Scope:** identical leads only. The general case is Level 3, which applies the flux factor explicitly.
**Validation:** an independent 4×4 linear solve at 50–60 digits, the textbook formula, the delta-barrier limit,
the thick-barrier asymptote, and over-barrier resonances (T = 1).

## Level 2 — WKB (`wkb.py`)

S(E) = ∫ √(2m(x)(V−E))/ħ dx over every forbidden interval, with T ≈ e^(−2S). Turning points are found
analytically within linear layers, and the integral is exact for the profile. The callable route uses
brentq turning points plus Gauss–Kronrod quadrature. For smooth potentials the piecewise route converges
as h² in the interior and h^1.5 overall (the √ singularity at turning points); this was measured, not assumed.

The engine keeps log T throughout, so `transmission` may underflow to 0 while `log_transmission` stays exact.

| Flag | Meaning |
|---|---|
| `above_barrier` | E ≥ max V. T is **NaN**, not 1, because over-barrier reflection exists. |
| `weak_tunnelling` | S < 1 |
| `narrow_barrier` | κ_max·w < 3 |
| `abrupt_interface` | potential step ≥ 5 % of the barrier at or inside the forbidden region (the interface prefactor is missing) |
| `mass_discontinuity` | effective-mass step inside the forbidden region |
| `multiple_forbidden_regions` | resonant structure; the WKB product has no interference |
| `rapid_variation` | \|dκ/dx\|/κ² > 0.5 in the barrier interior |
| `no_transmitted_state` | E ≤ right-lead edge: T = 0 exactly (physics, not a WKB failure) |

Any reliability flag adds a recommendation to compare against the scattering solver. An optional
`abrupt_rectangular` prefactor (16k̃²q̃²/(k̃²+q̃²)²) recovers the exact thick-barrier limit for single
rectangles only.

## Level 3 — numerical open-boundary scattering

**3a, S-matrix (`scattering.py`).** The profile is discretised into slices: flat layers stay one exact
slice, and linear layers are midpoint-sampled (second order). Each interface and slice is a 2×2 S-matrix,
combined with the Redheffer star product. All propagation factors are e^(ikd) with Im k ≥ 0, so nothing
grows exponentially. The solver outputs the incoming, reflected and transmitted fluxes,
T = |t|²·Re(k_R/m_R)/Re(k_L/m_L), and |R+T−1|.

`wavefunction()` rebuilds ψ(x) stably from prefix/suffix cascades and returns the probability current
j(x). The normalisation is a unit-amplitude incident wave. ψ is a probability amplitude; j is a probability
current (multiplying by q needs a carrier supply). A degenerate energy (k = 0 in a slice) is shifted by
1e-9 eV, which is documented and tested.

`converged_transmission()` halves the slice size until log T is stable, with Richardson extrapolation and an
error estimate.

**3b, finite difference with QTBM (`schrodinger.py`).** This shares no code with 3a. It uses the flux-form
stencil with link masses, cell-averaged V, exact lead self-energies Σ = −t·e^(ikh), and a source term for
the incident wave. It is a scattering calculation, not a finite-box eigenproblem. It conserves current exactly
for the discrete model, and its error against the continuum is O(h²).

**Reference (`hp_reference.py`, tests only).** mpmath at 50–60 digits, using Airy functions in sloped layers
and the exact Wronskian inverse.

## Gate dielectrics (`devices/`)

* **Materials** (`materials.py`): every parameter carries value, unit, provenance class, source and
  literature range.
  * SiO2: k = 3.9; conduction-band offset (CBO) 3.1 eV, range 2.9–3.34; tunnelling mass 0.5 m0, range 0.29–0.5 (literature).
  * HfO2: k = 25; CBO 1.4 eV, range 1.4–2.0 (literature); tunnelling mass 0.2 m0, range 0.1–0.4 (**assumed**).
  * Si lead mass 0.26 m0 is **assumed**. Real Si(100) has valley-dependent normal masses that a 1D lead cannot represent.
* **Stacks** (`dielectric_stack.py`): D is continuous across interfaces (optional sheet charges), so the field
  goes as 1/k per layer, never equal across layers. EOT = Σ t·3.9/k and C = 3.9 ε0/EOT. Physical thickness, EOT,
  electrical barrier thickness and transmission are kept as four separate quantities.
* **Electrostatics** (`electrostatics.py`):
  * Analytical MOS: exact classical 1D Poisson charge, gate work function, fixed charge; solves ψ_s
    (example: 1.5 nm SiO2, p-1e17, V_G = 1 V puts only ~30 % of V_G − φ_ms across the oxide).
  * DEVSIM CSV/JSON import, and an imported-field converter E_c = −q(φ − φ_ref) + ΔE_c.
  * The **SIMPLIFIED** voltage-drop model, labelled in every profile it creates.
  * Limitations: classical charge (no inversion-layer quantisation), no poly-gate depletion, no interface traps,
    no interface dipoles.
* **Gate tunnelling** (`gate_tunneling.py`): stack transmission for any electrostatics source. Gate-current
  density only via Tsu-Esaki between 3D electrodes; a Si inversion or accumulation emitter is refused.
  Leakage reported is gate tunnelling only: subthreshold, junction, BTBT, trap-assisted and GIDL leakage are
  not modelled and never added.
* **Advanced devices** (`advanced.py`): planar, FinFET sidewall, GAA nanosheet and stacked concepts produce
  `1D slice` profiles with explicit caveats.

## Current models (`models/`)

* **Landauer 1D:** I = (q/h)·g_s·M ∫ T (f_L − f_R) dE, for an explicitly 1D channel. Reproduces the
  conductance quantum (test).
* **Tsu-Esaki:** J = (q m_t kT / 2π²ħ³) ∫ T(E_z) ln[(1+e^((μL−E)/kT))/(1+e^((μR−E)/kT))] dE_z. Assumes 3D
  free-electron electrodes, conserved k_t and T evaluated at E_z.
  * **Validation:** with WKB transmission it reproduces analytical FN to within the expected next-order term
    −F/B (±1 %), at T → 0 and at 300 K with the πckT/sin(πckT) factor.
  * With the full quantum transmission it differs from FN by 0.77–2.4× in the FN regime (experiment B).
    That gap is the interface prefactor plus FN oscillations, a model difference rather than an error.
* **Fowler-Nordheim:** J = A F² exp(−B/F). It raises `FNRegimeError` when qFt < φ_B (trapezoidal barrier:
  direct tunnelling) or when ckT ≥ 1. Comparison plots use `allow_outside_regime=True` and mark the
  invalid points.

## Reliability (`analysis/reliability.py`)

Reports fields and transmission only. It makes no prediction of TDDB, BTI, HCD, trap generation or lifetime.
