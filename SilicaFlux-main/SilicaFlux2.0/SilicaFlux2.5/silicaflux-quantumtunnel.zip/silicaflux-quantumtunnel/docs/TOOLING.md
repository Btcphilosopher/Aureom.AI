# Tooling

| Tool | Version used | Role | Notes |
|---|---|---|---|
| Python | 3.13 | everything | 3.11+ declared, 3.12+ per brief |
| numpy / scipy | 2.5 / 1.18 | numerics, CODATA 2022 constants | |
| pydantic / pandas / h5py | 2.13 / 3.0 / 3.16 | models, tables, HDF5 | |
| matplotlib / plotly | 3.11 / 6.x | figures, dashboard | Plotly JS inlined (offline) |
| mpmath | 1.4 | high-precision references (tests/validation only) | |
| hypothesis / pytest | 6.x / 9.x | tests | |
| FastAPI / httpx | 0.16x | optional API | |
| Icarus Verilog | 12.0 | primary simulator (repository default) | |
| Verilator | 5.020 | lint (-Wall) + second simulator | `--binary --timing` |
| Yosys | 0.33 | synthesis (generic, ECP5, iCE40, liberty mapping) | |
| nextpnr-ecp5 | 0.6 | post-route timing/utilisation | |
| NanGate45 OCL liberty | PDKv1.3 | ASIC-style estimate only | fetched on demand into `build/pdk/`, **not redistributed**; non-manufacturable |
| Three.js / esbuild | 0.187 / npm | optional 3D view bundle | MIT; pre-bundled, Python needs no Node |
| Bebas Neue / DM Mono | @fontsource | dashboard fonts | SIL OFL 1.1, licences in `dashboard/fonts/` |

Unavailable here, so their results are **not claimed**:

- commercial simulators;
- OpenSTA / OpenROAD (signoff timing, ASIC place-and-route);
- power analysis;
- Vivado / Quartus;
- ngspice;
- an FPGA board.

## Known tool limitations hit

* **Icarus 12.**
  * No concurrent SVA, so immediate assertions are used, guarded by `SFX_SYNTHESIS`.
  * "constant selects in always_* … all bits will be included" is a benign sensitivity warning.
  * `unique` is ignored.
  * `if ($isunknown(...))` mis-evaluates (bug 10 in VERIFICATION.md).
* **Yosys 0.33.** No `import pkg::*` and no `return` in functions.
* **Verilator 5.020.** None blocking. The testbenches avoid `$urandom` seeding differences by using their
  own xorshift.
* **cocotb 2.1** requires Verilator ≥ 5.036. The regression therefore uses SV testbenches plus Python
  post-processing, which runs on both simulators.
