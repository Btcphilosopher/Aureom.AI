# Known limitations

## Physics

* **Model class.** 1D, single-band, parabolic effective mass. No non-parabolicity, no band structure, no
  valley physics. The Si lead mass is an assumed 0.26 m0.
* **Transport.** Coherent and elastic only: no phonon-assisted, trap-assisted or inelastic tunnelling, no
  image-force lowering, no space charge in the dielectric, and no self-consistency between current and potential.
* **Interfaces.** BenDaniel-Duke interface conditions; interface dipoles, roughness and transition layers are
  not modelled. Band offsets are inputs.
* **Material data.** The HfO2 tunnelling mass is *assumed*. Every HfO2 conclusion carries that uncertainty
  (experiment D quantifies it).
* **MOS electrostatics.** Classical charge, so no inversion-layer quantisation or charge centroid. No
  poly-gate depletion, no interface traps, Boltzmann statistics.
* **Gate-current density.** Only for 3D free-electron electrodes. Si inversion/accumulation emitters are
  refused, because they need 2D subband supply functions.
* **Mass mismatch.** The transverse-mass mismatch between electrode and barrier is neglected
  (T is evaluated at E_z only).
* **Advanced devices.** FinFET/GAA/stacked profiles are 1D slices. There are no 3D electrostatics, corner
  fields or confinement.
* **Calibration.** No result is calibrated to foundry, PDK or measured silicon data. Reliability mechanisms
  (TDDB, BTI, HCD, trap generation) are not modelled.

## Numerics

* The S-matrix staircase is second order for sloped layers. Flat layers are exact.
* The degenerate energy E = V_slice is shifted by 1e-9 eV.
* The adaptive energy grid can still miss an isolated resonance much narrower than its initial spacing.

## Hardware

* **Core model.** Plain WKB for a single rectangular barrier between identical leads, with no
  interface prefactor. Accuracy is claimed only within the validated input ranges (V0, E < 16 eV, a < 64 nm,
  0 < m < 16) and the per-vector error budget.
* **Output underflow.** T underflows to 0 below ~2⁻³³ (flagged); ln T remains valid.
* **Integrator precision.** K1 = C1·dx loses relative precision for very small dx (≈ 2⁻²¹/(C1·dx)). The
  maximum is 4,096 samples per profile.
* **Timing figures.** ECP5 Fmax is a post-route figure without IO constraints or a board. The ASIC numbers are
  a pre-layout estimate with a non-manufacturable research library. There is no STA, no power analysis and
  no measured FPGA or silicon result.
* **Verification scope.** Formal verification was not performed (no capable open tool for SVA here).
  Concurrent SVA is not used, because Icarus lacks it.
* **CI.** `.github/workflows/quantum.yml` has not been executed on GitHub Actions.
