# Reproducible experiments A–E

Run all five with `make quantum-report`, or a subset with
`PYTHONPATH=python python3 -m sf_quantum.experiments.run A C`.

Outputs per experiment go to `data/experiments/<ID>/`:

- `<ID>.json`, the full provenance record;
- `<ID>.h5`, the arrays;
- `<ID>_<table>.csv`, the data tables.

Figures go to `reports/figures/` and summaries to `reports/experiments_summary.json`. Every number below
is copied from those files.

## A — rectangular barrier: exact vs WKB vs numerical

The barrier is SiO2-like: 3.1 eV × 1.5 nm, m* = 0.5, identical leads, swept over 1,200 energies from 0.01 to 6 eV.

- **Exact vs S-matrix:** max |Δ ln T| = 2.1e-14.
- **Exact vs FD** (5 pm grid): 5.5e-4.
- **WKB below the barrier:** Δ ln T spans −1.39 … +2.97. This is the missing abrupt-interface prefactor plus
  the E → 0 limit.
- **WKB with the prefactor option:** within 0.008 in the thick regime.
- **Wavefunction:** j(x) is uniform to 9e-16 of j_in.
- **Above the barrier:** WKB returns NaN, while the exact T shows reflection and resonances.

## B — trapezoidal SiO2 barrier under increasing field

The barrier is 3 nm with φ = 3.1 eV, E = 0.05 eV, swept from 0.25 to 20 MV/cm.

- **FN onset:** 10.17 MV/cm, where qFt = φ − E.
- **S-matrix vs 60-digit Airy reference:** within 6e-9 (relative ln T).
- **Fowler-Nordheim oscillations** appear above the onset, and WKB cannot reproduce them.

The metal/SiO2/metal current research model at 300 K gives two results:

- with WKB transmission, the Tsu-Esaki/FN ratio is 0.96–1.26 in the FN regime (validates the current model);
- with quantum transmission, the ratio is 0.77–2.40 (interface prefactor plus oscillations).

The FN law is drawn only in its regime.

## C — SiO2 physical-thickness sweep

Thickness is swept from 0.8 to 4.0 nm, at E ∈ {0.05, 0.5, 1.0} eV and F ∈ {0, 5} MV/cm.

- **Zero field:** d ln T/dt matches −2κ to 4e-6. Transmission is exponential in thickness, at −11.7 per nm at 0.5 eV.
- **Solver convergence** against the Airy reference: observed order 2.00.
- **Selected current estimate** (MIM, 1 V): about 5.9 decades per nm.

These are model-derived; no measured leakage is implied.

## D — SiO2 vs SiO2/HfO2 at matched EOT

The two stacks are SiO2 1.0 nm and SiO2 0.5 nm / HfO2 3.21 nm. Both have EOT 1.00 nm and 3.45 µF/cm², and the
physical thickness ratio is 3.7×. At 1 V the fields are 10.0 MV/cm (SiO2) vs 10.0 / 1.56 MV/cm (IL / HfO2).

- **Nominal parameters:** T_stack/T_SiO2 = 10^−2.45 at 1 V, E = 0.05 eV.
- **Monte Carlo** (300 samples, seed 20261115) over parameter uncertainty: HfO2 mass 0.1–0.4 (assumed), HfO2
  CBO 1.4–2.0, SiO2 mass 0.29–0.5, IL thickness 0.4–0.6.
  - Results: 5 % / 50 % / 95 % = 10^−6.6 / 10^−4.3 / 10^−2.4.
  - Spearman rank correlation with the outcome: HfO2 mass −0.76, HfO2 CBO −0.44, IL thickness +0.39, SiO2 mass +0.10.
- **Also recorded:**
  - analytical MOS mapping V_G → V_stack;
  - EOT vs physical thickness;
  - Tsu-Esaki current vs bias, temperature (250–400 K) and SiO2 barrier height (2.9–3.34 eV).

The conclusion depends strongly on assumed parameters; the spread is parameter uncertainty, not
manufacturing variability.

## E — Python vs synthesizable SystemVerilog

This compares the default RTL (Icarus) against double-precision WKB on 1,936 valid vectors.

- **Bit-exact** with the fixed-point model.
- **Errors:** max |Δ ln T| = 3.0e-4, mean 2.1e-5, max |ΔT| = 5.4e-6.
- **Error/budget:** worst ratios 0.975 (ln T) and 0.956 (T).
- **Timing:** latency 38 cycles, II = 1.
- **Throughput:** post-route Fmax × II is listed per configuration in `E_hardware_throughput.csv`.
