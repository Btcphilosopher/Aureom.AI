# Architecture

## Data flow

```
 configs / CLI / API / TransistorLab contract
          │  human units (nm, eV, V/nm, MV/cm, m*/m0) ── quantum/units.py (explicit, tested)
          ▼
 devices/  materials (provenance) → DielectricStack (EOT, field partition) → electrostatics
          │  (analytical MOS | DEVSIM import | imported field | SIMPLIFIED voltage drop)
          ▼
 quantum/barriers.py   PotentialProfile = flat leads + linear layers (SI, energy reference mandatory)
          ▼
 ┌────────────── solver levels (independent implementations) ───────────────┐
 │ L1 rectangular.py   exact closed form, log domain                        │
 │ L2 wkb.py           exact piecewise-linear action + validity flags       │
 │ L3a scattering.py   Redheffer S-matrix staircase, wavefunction, j(x)     │
 │ L3b schrodinger.py  finite-difference QTBM (sparse tridiagonal)          │
 │ ref hp_reference.py mpmath 4x4 solve / Airy transfer matrices (tests)    │
 └──────────────────────────────────────────────────────────────────────────┘
          ▼
 models/  Landauer 1D · Tsu-Esaki (3D electrodes only) · Fowler-Nordheim (regime-enforced)
 analysis/ sweeps · sensitivity (seeded MC) · validation (18 checks) · reliability (field only) · benchmarks
          ▼
 reference/fixed_point_model.py   bit-accurate integer spec of the RTL + error_budget()
 reference/tunneling_golden.py    versioned vectors (.hex for $readmemh, .json, .csv) + generated SV tables
          ▼
 rtl/quantum/  sf_quantum_tunnel_core (rectangular WKB)  ·  sf_qt_integrator (sampled profiles)
               sf_qt_sqrt · sf_qt_fixed_mul · sf_qt_exp_lut · generated ROM/constants · vendored sfx_skid_buffer
 rtl/integration/sf_qt_ssb_regs  (SoC Simple Bus peripheral, optional)
          ▼
 tests/rtl/*.sv + reference/rtl_runner.py  (Icarus + Verilator, bit-exact, statistics vs double)
 reference/synthesis.py  (Yosys, nextpnr-ecp5, NanGate45 estimate)
          ▼
 experiments/run.py (A–E) → data/experiments/*.json|h5|csv, reports/figures/*.png
 viz/dashboard.py → dashboard/index.html (+ device3d.html)        reports.py → reports/INDEX.md
```

## Single sources of truth

| Fact | Defined once in | Consumers |
|---|---|---|
| Physical constants | `quantum/constants.py` (scipy CODATA 2022) | everything; `sf_qt_constants.svh` is *generated* from it |
| Fixed-point formats, rounding, saturation | `reference/fixed_point_model.py` | RTL (mirrors it bit-for-bit), golden vectors, error budget |
| 2^-f ROM | `fixed_point_model.exp_rom` | generated `sf_qt_exp_rom_l8_m*.sv` |
| Register map | `rtl/integration/sf_qt_ssb_regs.sv` header | `integration/ssb_driver.py` (test checks they agree) |
| Port list | `sf_quantum_tunnel_core.sv` | `sf/sf_quantum_tunnel.sf` sketch (test checks they agree) |

A test fails if any generated file is stale (`tests/numerical/test_fixed_point.py`).

## Provenance

`provenance.make_metadata()` stamps every saved experiment with:

- input parameters and per-parameter provenance (literature / PDK / measured / assumed / hypothetical);
- the CODATA release and constant values;
- model assumptions and material sources;
- solver settings and grid;
- git revision (or an explicit "not a git work tree") plus a SHA-256 of the source tree;
- environment versions, RTL configuration, testbench seed and validation outcome;
- the calibration statement.

Arrays go to HDF5 and tables to CSV.
