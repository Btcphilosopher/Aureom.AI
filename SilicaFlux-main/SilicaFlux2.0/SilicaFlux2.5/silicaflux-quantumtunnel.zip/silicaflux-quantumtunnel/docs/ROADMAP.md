# Future research roadmap

Ordered by value for SilicaFlux engineers. Each item names its validation gate.

1. **Measured parameters.** Replace the assumed HfO2 tunnelling mass and the Si lead mass with measured or
   PDK values. Gate: provenance class `measured`/`pdk`, and the sensitivity study re-run.
2. **2D emitter supply.** Inversion-layer subbands (Schrödinger–Poisson in Si) and a 2D supply function
   for gate current from MOS channels. Gate: reproduce published direct-tunnelling I–V shapes with stated
   parameters, labelled as a comparison, not a calibration.
3. **Non-parabolic dielectric dispersion** (Franz two-band) as an option in WKB and the S-matrix.
   Gate: limits reduce to the parabolic model.
4. **Transverse-mass coupling** in Tsu-Esaki (E_z-dependent effective barrier). Gate: equal-mass limit unchanged.
5. **DEVSIM live coupling.** Run a 1D MOS capacitor in DEVSIM and compare V_ox(V_G) against
   `MOSCapacitor`. The importer exists; the comparison does not.
6. **Hardware: integrator K precision.** Carry more fractional bits for K = C·dx. Gate: integrator budget
   with no dx-dependent term dominating.
7. **Hardware: abrupt-interface prefactor** (16k²κ²/(k²+κ²)²) as an optional log-domain additive term,
   giving exact thick-barrier transmission for rectangles in hardware.
8. **Hardware: timing.** Deeper multiplier pipelining or DSP register packing for ECP5 ≥ 100 MHz, with the
   latency/Fmax trade-off reported.
9. **Integration.** A DataFabric/NoC-flit adapter once a NoC transaction format is settled, and only if
   accelerator throughput is shown to matter for a workload. The SSB adapter covers CPU access today.
10. **Formal.** SymbiYosys proofs of the ready/valid invariants (no drop, no duplicate, in-order) for the core
    and integrator.
11. **TransistorLab.** When it exists, serve its real requests through `integration/transistorlab.py`.
