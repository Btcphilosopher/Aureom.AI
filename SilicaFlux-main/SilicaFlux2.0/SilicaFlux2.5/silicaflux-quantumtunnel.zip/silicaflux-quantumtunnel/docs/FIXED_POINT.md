# Fixed-point numerical design

The specification is `python/sf_quantum/reference/fixed_point_model.py`. The RTL is required to match it
bit-for-bit, and the model is required to stay within `error_budget()` of double-precision WKB.

## Computation

2S = C1 · a · √(m*(V0 − E)), where C1 = 2√(2 m_e q)/ħ × 1e-9 = 10.2463344 nm⁻¹ eV⁻¹ᐟ² (CODATA 2022).
The outputs are ln T = −2S and T = 2^(−y), with y = C2·a·√(m*(V0−E)) and C2 = C1·log2(e).

## Formats (defaults: DATA_W = 32, FRAC_W = F = 16, SQRT_GUARD = G = 4, CONST_FRAC = 24)

| Signal | Format | Width | Notes |
|---|---|---|---|
| V0, E (eV) | UQ16.16 in, range-checked to < 16 | 32 | E = 0 → INVALID |
| a (nm) | UQ16.16, < 64 | 32 | a = 0 allowed (no barrier: T = 1, saturated) |
| m*/m0 | UQ16.16, 0 < m < 16 | 32 | |
| dE = V0 − E | UQ4.16 | 20 | exact |
| P = m·dE | UQ8.32 | 40 | exact |
| radicand | P ≪ (2G+2) | 50 | |
| r = ⌊√radicand⌋ | UQ4.21 | 25 | exact digit recurrence |
| s = (r+1) ≫ 1 | UQ5.20 | 25 | round-half-up √, \|err\| ≤ 2⁻²¹ |
| C1, C2 codes | UQ4.24 | 28 | generated from scipy constants |
| K1, K2 = round(C·a) | UQ10.20 | 30 | |
| 2S = round(K1·s) | UQ15.16 | 31 | |
| Y = round(K2·s) | UQ15.20 | 35 | |
| log_T | SQ16.16 | 32 | −2S, saturates at −2³¹·2⁻¹⁶ (LOG_SAT) |
| ROM | 256 × (base UQ1.34, delta 26 b) | 15.6 kb | base = round(2^(−i/256)·2³⁴) |
| mant | UQ1.34 | 35 | base − round(delta·rem / 2¹²) |
| T | UQ0.32 | 32 | round(mant·2^(−yi−2)); saturates at 1−2⁻³²; 0 → TX_UNDERFLOW |

**Rounding.** Round-half-up ("add half, shift") everywhere. The square root is an exact floor computed with
one extra bit, then rounded. Nothing is truncated without a stated bound.

**Overflow.** Impossible inside the datapath for range-checked inputs, because widths are sized from the
range limits. Simulation assertions check every internal multiplier and rounding stage.

**Saturation.** Only two, both documented and flagged:
- the log output (LOG_SAT, exercised by the 24-bit configuration);
- T = 1.0, which saturates to all-ones.

**Underflow.** T rounds to exactly 0 for y ≳ 33 (ln T ≲ −23). TX_UNDERFLOW is set, and ln T remains correct.
This is why ln T is the primary output.

**Invalid / above-barrier inputs.** Both data outputs are zero and the status bit is set. Above-barrier is
never returned as T = 1.

## Error budget (per vector, `error_budget()`)

The error terms are:

- e_s = 2^−(F+G+1), from the rounded square root;
- e_K = 2^−(F+G+1) + a·|C_q − C|, from the rounded product and the quantised constant.

The bounds are:

- |Δ(2S)| ≤ K1·e_s + s·e_K1 + e_s·e_K1 + 2^−(F+1);
- |ΔT| ≤ T(2^|Δy| − 1) + 2^−⌊y−|Δy|⌋·e_mant + 2^−(W+1) (+2^−W at saturation);
- e_mant = (ln 2)²·2^−2L/8 + 2^−34 for the default linear interpolation.

A 1 % margin covers the dropped second-order terms. The bound is rigorous by construction and tight in
practice. The worst error/budget ratio is:

- 0.98 over 20,000 Python random vectors;
- 0.975 for ln T and 0.956 for T over 1,936 RTL vectors.

It also holds on 2,000 Hypothesis cases (`test_hardware_model_within_error_budget`).

Typical magnitudes:

- a 2 nm barrier: |Δ ln T| ≈ 2e-5;
- the worst case (64 nm, m = 15.9): 3e-4, against an |ln T| of up to ~15,000.

Input quantisation (rounding V0, E, a and m to 2⁻¹⁶) is a separate effect. The golden reference evaluates
double-precision WKB on the *quantised* inputs, so the budget isolates datapath error.

## The 2^−f unit: choice

See `reports/exp_study/EXP_STUDY.md` (measured errors match the analytic bounds to 3 digits):

| Approach | Max rel. error | Cost |
|---|---|---|
| nearest LUT, 2⁸ entries | 1.35e-3 | ROM only (EXP_MODE = 0) |
| **LUT + linear interp, 2⁸** | **9.2e-7** | ROM + one 26×12 multiplier (default) |
| piecewise quadratic, 16 segments | 4.3e-7 | two 34×16 multipliers |
| shift-and-add, 24 iterations | 1.2e-7 | no multiplier, 24 cycles or stages |

Linear interpolation was chosen because its error is below the datapath's own ln T error for typical
barriers, and its ROM fits two ECP5 DP16KD blocks.

## Integrator (`sf_qt_integrator`, `integrator_model.py`)

The integrator uses the same per-sample s_i. It computes term_i = w_i·s_i exactly and accumulates them
exactly (56 bits, up to 4,096 samples). It then forms A = round(acc ≫ F), 2S = round(K1·A ≫ (F+2G)) and
Y = round(K2·A ≫ SF), and finishes like the core.

The budget is the same as the core's with s → A, where e_A = Σw·e_s + 2^−(SF+1).

**Known precision limit.** For very small dx, K1 = round(C1·dx) carries a relative error of
≈ 2⁻²¹/(C1·dx). At dx = 2⁻¹⁰ nm and 4,095 samples this gives |Δ ln T| = 5e-4 (inside the budget).
More fractional bits on K would remove it (roadmap).
