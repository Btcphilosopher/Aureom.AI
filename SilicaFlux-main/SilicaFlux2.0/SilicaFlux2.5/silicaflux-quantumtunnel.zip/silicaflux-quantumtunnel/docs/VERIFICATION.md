# Verification

## Python

`make quantum-test` runs the following suites (Hypothesis property tests included):

| Suite | What it checks |
|---|---|
| `tests/physics` | units/constants, barriers, exact rectangular barrier, WKB |
| `tests/numerical` | both Level-3 solvers, stability, convergence, analysis, fixed-point model, generated-file freshness, stored vectors |
| `tests/devices` | stacks/EOT/field partition, MOS electrostatics, DEVSIM import, FN, Landauer, Tsu-Esaki, gate current, device slices |
| `tests/integration` | TransistorLab contract, register map ↔ RTL, `.sf` ↔ `.sv` ports, FastAPI, CLI (incl. the unavailable-simulator exit path) |

### Mapping of the brief's 18 required checks

`make quantum-validate` produces `reports/validation/VALIDATION.md` with the value and threshold for each check.

| # | Check | Implementation |
|---|---|---|
| 1 | exact reference | closed form vs independent 50–60-digit 4×4 boundary solve |
| 2 | thin limit | V0·a fixed, a → 0 approaches the δ-barrier result; T → 1 at fixed V0 |
| 3 | wide limit | asymptote 16E(V0−E)/V0²·e^(−2κa) |
| 4 | units | κ(1 eV, m0) = 5.12317 nm⁻¹; the eV-inside-sqrt mistake is shown to be off by √e |
| 5 | effective mass | unequal barrier/lead masses vs HP solve |
| 6 | flux normalisation | unequal leads, \|t\|²/T = 0.05, T matches HP |
| 7 | current conservation | j(x) from the reconstructed ψ is uniform to 1e-15 |
| 8 | 0 ≤ T ≤ 1 | property tests (300 + 60 Hypothesis cases) |
| 9 | R + T = 1 | property tests; \|R+T−1\| < 1e-10 |
| 10 | grid convergence | observed order 1.98 (S-matrix) / ~2 (FD) |
| 11 | energy-grid convergence | ∫T dE on refined grids; adaptive grid finds a resonance a uniform grid misses |
| 12 | WKB vs numerical | discrepancy shrinks with barrier width (smooth barrier) |
| 13 | thick-barrier stability | 50 nm exact to 1e-12; naive transfer matrix fails (test asserts it) |
| 14 | high-precision reference | 60-digit Airy transfer matrices: trapezoid, triangle, SiO2/HfO2 with unequal leads |
| 15 | reproducibility | bitwise-identical solver output; seeded Monte Carlo |
| 16 | invalid input | E ≤ 0, NaN, negative width/mass, missing energy reference |
| 17 | edge cases | E = V0 exact; resonance T = 1; WKB above-barrier refusal |
| 18 | regression | stored values (`reference/regression_values.json`) |

## RTL

* **Lint.** Verilator `-Wall` with zero warnings across six configurations/tops; a waiver is used only for an
  intentional, commented case. Icarus elaboration, and Yosys for all synthesised tops.
* **Testbenches.** Self-checking SV (`tests/rtl/*.sv`), driven by golden `.hex` files.
  * Phase A runs at full rate and checks II = 1 and the documented latency.
  * Phase B uses random request gaps and response backpressure, checking in-order delivery, no drops, no
    duplicates, and output stability while stalled.
  * Phase C asserts reset mid-stream.
  * Every response is checked bit-exactly.
* **Determinism.** xorshift stimulus, re-seeded per phase, and control changes on `negedge`, so Icarus and
  Verilator produce byte-identical traces and identical cycle counts.
* **Python statistics** (`reference/rtl_runner.py`): absolute/relative/log errors vs double-precision WKB,
  max, mean, p99, worst-case parameter combination, validated operating range, and per-vector budget checks.
  Failures are listed, never omitted.
* **Configurations:** default; `PIPE_MUL = 0`; `SQRT_BPS = 5`; `EXP_MODE = 0`; DATA_W = 24 (log saturation);
  a second seed; plus the integrator and SSB adapter.

## Bug log: real defects found by testing during development

Kept in the spirit of SilicaFlux-AI's `docs/TOOLING.md`. Each was caught by a test or report, not by inspection.

1. **mpmath reference, thick barriers.** In the rectangular 4×4 solve, raw e^(±qa) columns made mpmath's LU
   declare a well-posed system singular. Fixed with a scaled basis.
2. **mpmath reference, transmission.** In the Airy transfer-matrix reference, t = N00 + N01·r cancelled
   catastrophically for thick barriers (wrong ln T). Fixed with the exact identity det N = (k_L/m_L)/(k_R/m_R).
3. **mpmath reference, gentle slopes.** For thick, gently sloped layers, Ai and Bi span about 3,000 orders of
   magnitude; mpmath's LU (norm-relative pivot tolerance) failed. Fixed with the analytic Wronskian inverse.
4. **mpmath reference, cube root.** `mp.cbrt(-x)` returns the complex principal root. The construction was still
   mathematically valid, so earlier tests passed, but it underflowed at large |z|. Fixed with a real signed cube
   root. A regression test was added.
5. **WKB diagnostic.** The `rapid_variation` criterion was evaluated only at layer endpoints and missed the
   interior κ_max/2 point. Fixed.
6. **WKB convergence claim.** The docstring said h². Measurement showed h^1.5 overall (the √ turning-point
   singularity). The claim was corrected and the test asserts the measured order.
7. **FN temperature factor.** It raised in the direct regime even in labelled-comparison mode. It is now NaN
   and flagged.
8. **FastAPI.** The WKB above-barrier result (NaN) was not JSON-serialisable. It now returns null plus an
   explicit note.
9. **RTL latency.** Off by one in the hand count (34 vs a measured 35). The formula is now defined
   handshake-to-handshake and checked by the testbench.
10. **Icarus 12 tool bug.** `if ($isunknown(x))` evaluates TRUE for fully known values even though
    `$isunknown` displays 0. Replaced with `(^x) === 1'bx`.
11. **Testbench race.** Control variables were changed at `posedge` by the sequencing process, so Icarus and
    Verilator traces differed for the first ~20 responses of a phase. Fixed with negedge updates and per-phase
    reseeding.
12. **Yosys 0.33 limitations.** It rejects `import pkg::*` and `return` inside functions. The RTL uses
    `pkg::NAME` and assignment-style functions.
13. **Exp-unit design study.** The first shift-and-subtract variant ((1 − 2^−k) factors) could not reach
    f > 0.81. The study flagged it with a constant 15 % error. Replaced with (1 + 2^−k) multiplicative
    normalisation.
14. **Dashboard.** Plotly's binary encoding of a pandas string column produced an empty bar chart. It was found
    by rendering a screenshot, and fixed.

Design improvements made from measurements:

- moving K1/K2 after the square root saved ~990 flip-flops (generic synthesis);
- PIPE_MUL raised ECP5 post-route Fmax from 46 to 58 MHz for +3 cycles of latency.
