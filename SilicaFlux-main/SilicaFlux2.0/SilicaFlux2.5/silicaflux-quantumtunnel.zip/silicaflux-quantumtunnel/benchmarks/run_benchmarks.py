"""Entry point for `make quantum-benchmark` (same as `sf-quantum benchmark`)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))

from sf_quantum.analysis.benchmarks import run  # noqa: E402

if __name__ == "__main__":
    run()
    print((Path(__file__).resolve().parents[1] / "reports" / "benchmarks" / "BENCHMARKS.md").read_text())
