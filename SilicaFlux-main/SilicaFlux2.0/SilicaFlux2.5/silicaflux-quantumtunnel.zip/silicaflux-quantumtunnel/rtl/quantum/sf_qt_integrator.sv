// =============================================================================
// sf_qt_integrator.sv -- streaming WKB action of a sampled 1D barrier profile
//
//   2S = C1 * dx * sum_i w_i * sqrt(m_i * max(V_i - E, 0)),  ln T = -2S, T = 2^(-2S log2 e)
//
// One sample per handshake (II = 1). A profile is the samples from one with
// smp_first_i to the next with smp_last_i (a single sample may carry both).
// energy_i, dx_i and smp_tag_i are sampled with the first sample of each
// profile. Integration weights w_i are explicit inputs (UQ2.F), e.g. the
// trapezoid rule's 1/2, 1, ..., 1, 1/2 -- the hardware does not choose a rule.
// One response per profile, in order.
//
// Encodings (F = FRAC_W): V, E UQ.F eV (< 16), m UQ.F (0 < m < 16),
// w UQ.F (< 4), dx UQ.F nm (0 < dx < 64). Outputs as sf_quantum_tunnel_core.
//   error_o [0] INVALID (E==0, dx==0, any m==0, any field out of range, or more
//               than 2^N_MAX_LOG2 samples)  [1] ABOVE (no sample with V > E)
//           [2] LOG_SAT  [3] reserved
//   warn_o  [0] WKB_WEAK (2S < 2)  [1] TX_UNDERFLOW  [2] MULTI_REGION (>= 2 separate
//               forbidden regions: resonant structure, WKB ignores interference)
//
// Datapath is bit-exact with python/sf_quantum/reference/integrator_model.py.
// Same conventions as the core: synchronous active-low reset, global stall
// from the output skid buffer, valid bits reset / data not reset.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sf_qt_integrator #(
    parameter int DATA_W     = 32,
    parameter int FRAC_W     = 16,
    parameter int TAG_W      = 8,
    parameter int SQRT_GUARD = 4,
    parameter int LUT_BITS   = 8,
    parameter int EXP_MODE   = 1,
    parameter int N_MAX_LOG2 = 12
)(
    input  wire logic              clk_i,
    input  wire logic              rst_ni,
    input  wire logic              smp_valid_i,
    output      logic              smp_ready_o,
    input  wire logic              smp_first_i,
    input  wire logic              smp_last_i,
    input  wire logic [TAG_W-1:0]  smp_tag_i,
    input  wire logic [DATA_W-1:0] energy_i,
    input  wire logic [DATA_W-1:0] dx_i,
    input  wire logic [DATA_W-1:0] smp_v_i,
    input  wire logic [DATA_W-1:0] smp_m_i,
    input  wire logic [DATA_W-1:0] smp_w_i,
    output      logic              rsp_valid_o,
    input  wire logic              rsp_ready_i,
    output      logic [TAG_W-1:0]  rsp_tag_o,
    output      logic [DATA_W-1:0] log_transmission_o,
    output      logic [DATA_W-1:0] transmission_o,
    output      logic [3:0]        error_o,
    output      logic [2:0]        warn_o
);

    localparam int F      = FRAC_W;
    localparam int G      = SQRT_GUARD;
    localparam int SF     = F + G;
    localparam int E_IB   = sf_qt_pkg::SF_QT_E_IB;
    localparam int M_IB   = sf_qt_pkg::SF_QT_M_IB;
    localparam int A_IB   = sf_qt_pkg::SF_QT_A_IB;
    localparam int K_IB   = sf_qt_pkg::SF_QT_K_IB;
    localparam int W_IB   = 2;
    localparam int CF     = sf_qt_pkg::SF_QT_CONST_FRAC;
    localparam int W_DE   = E_IB + F;
    localparam int W_M    = M_IB + F;
    localparam int W_W    = W_IB + F;
    localparam int W_DX   = A_IB + F;
    localparam int W_P    = E_IB + M_IB + 2 * F;
    localparam int SQ_RAW = W_P + 2 * G + 2;
    localparam int SQ_W   = SQ_RAW + (SQ_RAW % 2);
    localparam int S_W    = SQ_W / 2;
    localparam int W_TERM = W_W + S_W;
    localparam int W_ACC  = W_TERM + N_MAX_LOG2 + 1;
    localparam int W_A    = W_ACC - F;
    localparam int W_C    = K_IB + CF;
    localparam int W_K    = K_IB + A_IB + SF;
    localparam int PR_W   = W_K + W_A;
    localparam int W_2S   = PR_W - (F + 2 * G);
    localparam int W_Y    = PR_W - SF;
    localparam int LIM_W  = ((W_2S > DATA_W) ? W_2S : DATA_W) + 1;
    localparam int CNT_W  = N_MAX_LOG2 + 1;

    logic en;
    assign smp_ready_o = en;

    // ------------------------------------------------------------ s1 input + profile latches
    logic [DATA_W-1:0] e_lat, dx_lat;
    logic [TAG_W-1:0]  tag_lat;
    always_ff @(posedge clk_i) begin
        if (en && smp_valid_i && smp_first_i) begin
            e_lat <= energy_i; dx_lat <= dx_i; tag_lat <= smp_tag_i;
        end
    end

    logic              s1_v, s1_first, s1_last;
    logic [DATA_W-1:0] s1_e, s1_dx, s1_vv, s1_m, s1_w;
    logic [TAG_W-1:0]  s1_tag;
    always_ff @(posedge clk_i) begin
        if (!rst_ni) s1_v <= 1'b0;
        else if (en) s1_v <= smp_valid_i;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin
            s1_first <= smp_first_i; s1_last <= smp_last_i;
            s1_e   <= smp_first_i ? energy_i  : e_lat;
            s1_dx  <= smp_first_i ? dx_i      : dx_lat;
            s1_tag <= smp_first_i ? smp_tag_i : tag_lat;
            s1_vv <= smp_v_i; s1_m <= smp_m_i; s1_w <= smp_w_i;
        end
    end

    // ------------------------------------------------------------ s2 checks, u = max(V-E, 0)
    logic s2_inv_c, s2_forb_c;
    always_comb begin
        s2_inv_c = (s1_e == '0) || (|s1_e[DATA_W-1:W_DE]) || (s1_dx == '0) || (|s1_dx[DATA_W-1:W_DX])
                || (s1_m == '0) || (|s1_m[DATA_W-1:W_M]) || (|s1_vv[DATA_W-1:W_DE]) || (|s1_w[DATA_W-1:W_W]);
        s2_forb_c = s1_vv > s1_e;
    end
    logic              s2_v, s2_first, s2_last, s2_inv, s2_forb;
    logic [W_DE-1:0]   s2_u;
    logic [W_M-1:0]    s2_m;
    logic [W_W-1:0]    s2_w;
    logic [W_DX-1:0]   s2_dx;
    logic [TAG_W-1:0]  s2_tag;
    always_ff @(posedge clk_i) begin
        if (!rst_ni) s2_v <= 1'b0;
        else if (en) s2_v <= s1_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin
            s2_first <= s1_first; s2_last <= s1_last; s2_inv <= s2_inv_c; s2_forb <= s2_forb_c;
            s2_u  <= s2_forb_c ? (s1_vv[W_DE-1:0] - s1_e[W_DE-1:0]) : '0;
            s2_m  <= s1_m[W_M-1:0]; s2_w <= s1_w[W_W-1:0]; s2_dx <= s1_dx[W_DX-1:0]; s2_tag <= s1_tag;
        end
    end

    // ------------------------------------------------------------ s3 P = m*u
    logic [W_P-1:0] p_c;
    logic           p_sat;
    sf_qt_fixed_mul #(.A_W(W_M), .B_W(W_DE), .SHIFT(0), .OUT_W(W_P)) u_mul_p (
        .a_i(s2_m), .b_i(s2_u), .y_o(p_c), .sat_o(p_sat));
    logic              s3_v;
    logic [W_P-1:0]    s3_p;
    localparam int SB_W = TAG_W + W_DX + W_W + 4;
    logic [SB_W-1:0]   s3_sb;
    always_ff @(posedge clk_i) begin
        if (!rst_ni) s3_v <= 1'b0;
        else if (en) s3_v <= s2_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin
            s3_p  <= p_c;
            s3_sb <= {s2_tag, s2_dx, s2_w, s2_first, s2_last, s2_inv, s2_forb};
        end
    end

    // ------------------------------------------------------------ sqrt
    logic [S_W-1:0]  sq_r;
    logic [SB_W-1:0] sq_sb;
    logic            sq_v;
    sf_qt_sqrt #(.IN_W(SQ_W), .BITS_PER_STAGE(1), .SB_W(SB_W)) u_sqrt (
        .clk_i(clk_i), .rst_ni(rst_ni), .en_i(en), .valid_i(s3_v),
        .rad_i(SQ_W'({s3_p, {(2 * G + 2){1'b0}}})), .sb_i(s3_sb),
        .valid_o(sq_v), .root_o(sq_r), .sb_o(sq_sb));

    // ------------------------------------------------------------ s4 s = round(sqrt)
    /* verilator lint_off UNUSEDSIGNAL */
    logic [S_W:0] r_plus1;  // bit 0 dropped by the rounding shift
    /* verilator lint_on UNUSEDSIGNAL */
    assign r_plus1 = {1'b0, sq_r} + {{S_W{1'b0}}, 1'b1};
    logic              s4_v;
    logic [S_W-1:0]    s4_s;
    logic [SB_W-1:0]   s4_sb;
    always_ff @(posedge clk_i) begin
        if (!rst_ni) s4_v <= 1'b0;
        else if (en) s4_v <= sq_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin s4_s <= r_plus1[S_W:1]; s4_sb <= sq_sb; end
    end

    // ------------------------------------------------------------ s5 term = w*s (exact)
    logic [TAG_W-1:0] s4_tag;
    logic [W_DX-1:0]  s4_dx;
    logic [W_W-1:0]   s4_w;
    logic             s4_first, s4_last, s4_inv, s4_forb;
    assign {s4_tag, s4_dx, s4_w, s4_first, s4_last, s4_inv, s4_forb} = s4_sb;
    logic [W_TERM-1:0] term_c;
    logic              term_sat;
    sf_qt_fixed_mul #(.A_W(W_W), .B_W(S_W), .SHIFT(0), .OUT_W(W_TERM)) u_mul_term (
        .a_i(s4_w), .b_i(s4_s), .y_o(term_c), .sat_o(term_sat));
    logic              s5_v, s5_first, s5_last, s5_inv, s5_forb;
    logic [W_TERM-1:0] s5_term;
    logic [W_DX-1:0]   s5_dx;
    logic [TAG_W-1:0]  s5_tag;
    always_ff @(posedge clk_i) begin
        if (!rst_ni) s5_v <= 1'b0;
        else if (en) s5_v <= s4_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin
            s5_term <= term_c; s5_first <= s4_first; s5_last <= s4_last; s5_inv <= s4_inv; s5_forb <= s4_forb;
            s5_dx <= s4_dx; s5_tag <= s4_tag;
        end
    end

    // ------------------------------------------------------------ s6 accumulate per profile
    logic [W_ACC-1:0] acc_q, acc_n;
    logic [CNT_W-1:0] cnt_q, cnt_n;
    logic             inv_q, inv_n, ovf_q, ovf_n, any_q, any_n, prev_q;
    logic [1:0]       reg_q, reg_n;   // forbidden-region count, saturating at 2
    always_comb begin
        acc_n = (s5_first ? '0 : acc_q) + W_ACC'(s5_term);
        inv_n = (s5_first ? 1'b0 : inv_q) | s5_inv;
        any_n = (s5_first ? 1'b0 : any_q) | s5_forb;
        ovf_n = (s5_first ? 1'b0 : ovf_q) | (!s5_first && cnt_q == CNT_W'(1 << N_MAX_LOG2));
        cnt_n = s5_first ? CNT_W'(1) : ((cnt_q == CNT_W'(1 << N_MAX_LOG2)) ? cnt_q : cnt_q + CNT_W'(1));
        reg_n = s5_first ? 2'd0 : reg_q;
        if (s5_forb && (s5_first || !prev_q) && reg_n != 2'd2) reg_n = reg_n + 2'd1;
    end
    always_ff @(posedge clk_i) begin
        if (en && s5_v) begin
            acc_q <= acc_n; cnt_q <= cnt_n; inv_q <= inv_n; ovf_q <= ovf_n; any_q <= any_n; reg_q <= reg_n;
            prev_q <= s5_forb;
        end
    end

    logic              s6_v, s6_inv, s6_above, s6_multi;
    logic [W_ACC-1:0]  s6_acc;
    logic [W_DX-1:0]   s6_dx;
    logic [TAG_W-1:0]  s6_tag;
    always_ff @(posedge clk_i) begin
        if (!rst_ni) s6_v <= 1'b0;
        else if (en) s6_v <= s5_v && s5_last;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin
            s6_acc   <= acc_n;
            s6_inv   <= inv_n | ovf_n;
            s6_above <= !(inv_n | ovf_n) && !any_n;
            s6_multi <= reg_n == 2'd2;
            s6_dx    <= s5_dx;
            s6_tag   <= s5_tag;
        end
    end

    // ------------------------------------------------------------ s7 A = round(acc >> F), K1, K2
    logic [W_A-1:0] a_c;
    logic [W_K-1:0] k1_c, k2_c;
    logic           a_sat, k1_sat, k2_sat;
    sf_qt_fixed_mul #(.A_W(W_ACC), .B_W(1), .SHIFT(F), .OUT_W(W_A)) u_rnd_a (
        .a_i(s6_acc), .b_i(1'b1), .y_o(a_c), .sat_o(a_sat));
    sf_qt_fixed_mul #(.A_W(W_C), .B_W(W_DX), .SHIFT(CF - G), .OUT_W(W_K)) u_mul_k1 (
        .a_i(sf_qt_pkg::SF_QT_C1_CODE), .b_i(s6_dx), .y_o(k1_c), .sat_o(k1_sat));
    sf_qt_fixed_mul #(.A_W(W_C), .B_W(W_DX), .SHIFT(CF - G), .OUT_W(W_K)) u_mul_k2 (
        .a_i(sf_qt_pkg::SF_QT_C2_CODE), .b_i(s6_dx), .y_o(k2_c), .sat_o(k2_sat));
    logic              s7_v;
    logic [W_A-1:0]    s7_a;
    logic [W_K-1:0]    s7_k1, s7_k2;
    logic [TAG_W+2:0]  s7_fl;
    always_ff @(posedge clk_i) begin
        if (!rst_ni) s7_v <= 1'b0;
        else if (en) s7_v <= s6_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin s7_a <= a_c; s7_k1 <= k1_c; s7_k2 <= k2_c; s7_fl <= {s6_tag, s6_inv, s6_above, s6_multi}; end
    end

    // ------------------------------------------------------------ s8 products, s9 rounding
    logic [PR_W-1:0] pr1_c, pr2_c;
    logic            pr1_sat, pr2_sat;
    sf_qt_fixed_mul #(.A_W(W_K), .B_W(W_A), .SHIFT(0), .OUT_W(PR_W)) u_mul_pr1 (
        .a_i(s7_k1), .b_i(s7_a), .y_o(pr1_c), .sat_o(pr1_sat));
    sf_qt_fixed_mul #(.A_W(W_K), .B_W(W_A), .SHIFT(0), .OUT_W(PR_W)) u_mul_pr2 (
        .a_i(s7_k2), .b_i(s7_a), .y_o(pr2_c), .sat_o(pr2_sat));
    logic              s8_v;
    logic [PR_W-1:0]   s8_pr1, s8_pr2;
    logic [TAG_W+2:0]  s8_fl;
    always_ff @(posedge clk_i) begin
        if (!rst_ni) s8_v <= 1'b0;
        else if (en) s8_v <= s7_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin s8_pr1 <= pr1_c; s8_pr2 <= pr2_c; s8_fl <= s7_fl; end
    end

    logic [W_2S-1:0] two_s_c;
    logic [W_Y-1:0]  y_c;
    logic            two_s_sat, y_sat;
    sf_qt_fixed_mul #(.A_W(PR_W), .B_W(1), .SHIFT(F + 2 * G), .OUT_W(W_2S)) u_rnd_2s (
        .a_i(s8_pr1), .b_i(1'b1), .y_o(two_s_c), .sat_o(two_s_sat));
    sf_qt_fixed_mul #(.A_W(PR_W), .B_W(1), .SHIFT(SF), .OUT_W(W_Y)) u_rnd_y (
        .a_i(s8_pr2), .b_i(1'b1), .y_o(y_c), .sat_o(y_sat));
    logic              s9_v;
    logic [W_2S-1:0]   s9_2s;
    logic [W_Y-1:0]    s9_y;
    logic [TAG_W+2:0]  s9_fl;
    always_ff @(posedge clk_i) begin
        if (!rst_ni) s9_v <= 1'b0;
        else if (en) s9_v <= s8_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin s9_2s <= two_s_c; s9_y <= y_c; s9_fl <= s8_fl; end
    end

    // ------------------------------------------------------------ s10 log output, WKB_WEAK
    localparam logic [LIM_W-1:0] LOG_LIMIT = LIM_W'(1) << (DATA_W - 1);
    localparam logic [LIM_W-1:0] WEAK_LIM  = LIM_W'(2) << F;
    logic [LIM_W-1:0]  two_s_ext;
    logic              lsat_c, weak_c;
    logic [DATA_W-1:0] log_c;
    always_comb begin
        two_s_ext = LIM_W'(s9_2s);
        lsat_c = two_s_ext > LOG_LIMIT;
        weak_c = two_s_ext < WEAK_LIM;
        log_c  = lsat_c ? {1'b1, {(DATA_W - 1){1'b0}}} : DATA_W'(~two_s_ext + LIM_W'(1));
    end
    localparam int SB2_W = TAG_W + 3 + 2 + DATA_W;
    logic              s10_v;
    logic [W_Y-1:0]    s10_y;
    logic [SB2_W-1:0]  s10_sb;
    always_ff @(posedge clk_i) begin
        if (!rst_ni) s10_v <= 1'b0;
        else if (en) s10_v <= s9_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin s10_y <= s9_y; s10_sb <= {s9_fl, lsat_c, weak_c, log_c}; end
    end

    // ------------------------------------------------------------ exp + output
    logic              ex_v, ex_under;
    logic [DATA_W-1:0] ex_t;
    logic [SB2_W-1:0]  ex_sb;
    sf_qt_exp_lut #(.DATA_W(DATA_W), .YF(SF), .W_Y(W_Y), .LUT_BITS(LUT_BITS), .MODE(EXP_MODE), .PIPE(1),
                    .SB_W(SB2_W)) u_exp (
        .clk_i(clk_i), .rst_ni(rst_ni), .en_i(en), .valid_i(s10_v), .y_i(s10_y), .sb_i(s10_sb),
        .valid_o(ex_v), .t_o(ex_t), .underflow_o(ex_under), .sb_o(ex_sb));

    logic [TAG_W-1:0]  o_tag;
    logic              o_inv, o_above, o_multi, o_lsat, o_weak, bad;
    logic [DATA_W-1:0] o_log;
    assign {o_tag, o_inv, o_above, o_multi, o_lsat, o_weak, o_log} = ex_sb;
    assign bad = o_inv || o_above;

    localparam int PAY_W = TAG_W + 2 * DATA_W + 4 + 3;
    logic [PAY_W-1:0] payload, payload_out;
    assign payload = {o_tag, bad ? '0 : o_log, bad ? '0 : ex_t,
                      1'b0, o_lsat && !bad, o_above && !o_inv, o_inv,
                      o_multi && !bad, ex_under && !bad, o_weak && !bad};

    sfx_skid_buffer #(.WIDTH(PAY_W)) u_out (
        .clk(clk_i), .rst_n(rst_ni), .in_valid(ex_v), .in_ready(en), .in_data(payload),
        .out_valid(rsp_valid_o), .out_ready(rsp_ready_i), .out_data(payload_out));
    assign {rsp_tag_o, log_transmission_o, transmission_o, error_o, warn_o} = payload_out;

`ifndef SFX_SYNTHESIS
    always_ff @(posedge clk_i) begin
        if (rst_ni && en) begin
            if (s2_v && !s2_inv) assert (!p_sat) else $error("sf_qt_integrator: P overflow");
            if (s4_v && !s4_inv) assert (!term_sat) else $error("sf_qt_integrator: term overflow");
            if (s6_v && !s6_inv) assert (!a_sat && !k1_sat && !k2_sat) else $error("sf_qt_integrator: A/K overflow");
            if (s7_v && !s7_fl[2]) assert (!pr1_sat && !pr2_sat) else $error("sf_qt_integrator: product overflow");
            if (s8_v && !s8_fl[2]) assert (!two_s_sat && !y_sat) else $error("sf_qt_integrator: rounding overflow");
        end
    end
`endif

endmodule

`default_nettype wire
