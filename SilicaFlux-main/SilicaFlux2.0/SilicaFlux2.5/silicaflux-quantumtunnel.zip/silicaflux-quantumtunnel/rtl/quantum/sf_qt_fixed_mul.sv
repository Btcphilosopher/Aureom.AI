// =============================================================================
// sf_qt_fixed_mul.sv -- unsigned fixed-point multiply, round-half-up, saturate
//
//   y = sat_OUT_W( (a * b + 2^(SHIFT-1)) >> SHIFT )
//
// Purely combinational; the caller registers the result. sat_o flags that the
// rounded product did not fit in OUT_W bits (y is then all ones). Inside the
// QuantumTunnel datapath OUT_W is sized so that this never happens for
// range-checked inputs; the core asserts that in simulation.
//
// Python reference: fixed_point_model.rnd_shift()
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sf_qt_fixed_mul #(
    parameter int A_W   = 16,
    parameter int B_W   = 16,
    parameter int SHIFT = 0,
    parameter int OUT_W = 32
)(
    input  wire logic [A_W-1:0]   a_i,
    input  wire logic [B_W-1:0]   b_i,
    output      logic [OUT_W-1:0] y_o,
    output      logic             sat_o
);

    localparam int P_W   = A_W + B_W;      // exact product width
    localparam int R_W   = P_W + 1;        // + rounding carry
    localparam int Q_W   = R_W - SHIFT;    // width after the shift
    localparam logic [R_W-1:0] HALF = (SHIFT == 0) ? '0 : (R_W'(1) << ((SHIFT == 0) ? 0 : SHIFT - 1));

    /* verilator lint_off UNUSEDSIGNAL */
    logic [R_W-1:0] prod, rounded;  // rounded[SHIFT-1:0] are the discarded fraction bits
    /* verilator lint_on UNUSEDSIGNAL */
    logic [Q_W-1:0] shifted;

    always_comb begin
        prod    = {{(B_W + 1){1'b0}}, a_i} * {{(A_W + 1){1'b0}}, b_i};
        rounded = prod + HALF;
        shifted = rounded[R_W-1:SHIFT];
    end

    generate
        if (Q_W > OUT_W) begin : g_sat
            assign sat_o = |shifted[Q_W-1:OUT_W];
            assign y_o   = sat_o ? {OUT_W{1'b1}} : shifted[OUT_W-1:0];
        end else begin : g_nosat
            assign sat_o = 1'b0;
            assign y_o   = OUT_W'(shifted);
        end
    endgenerate

endmodule

`default_nettype wire
