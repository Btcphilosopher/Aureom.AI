// =============================================================================
// sf_quantum_tunnel_core.sv -- SilicaFlux QuantumTunnel WKB accelerator
//
// Evaluates, for one rectangular barrier between identical leads, the plain
// WKB tunnelling model
//
//     2S = C1 * a * sqrt(m* (V0 - E)),    ln T = -2S,    T = 2^(-2S log2 e)
//
// with C1 = 2 sqrt(2 m_e q)/hbar * 1e-9 nm^-1 eV^-1/2 (CODATA, generated).
// It does NOT solve the Schroedinger equation and does not include the
// abrupt-interface prefactor; it is a bit-exact implementation of the
// fixed-point model python/sf_quantum/reference/fixed_point_model.py, whose
// error versus double-precision WKB is bounded by error_budget().
//
// Encoded units (F = FRAC_W, W = DATA_W; defaults 16 / 32)
//   barrier_i  UQ(W-F).F  eV   V0, potential energy of the barrier   valid < 16 eV
//   energy_i   UQ(W-F).F  eV   E, electron energy (lead band edge=0) valid 0 < E < 16 eV
//   width_i    UQ(W-F).F  nm   barrier width a                       valid < 64 nm
//   mass_i     UQ(W-F).F  m0   effective mass ratio m*/m_e           valid 0 < m < 16
//   log_transmission_o  SQ(W-F).F  ln T (two's complement, <= 0), saturates at -2^(W-F-1)
//   transmission_o      UQ0.W      T, round-to-nearest, saturates at 1 - 2^-W
//   error_o   [0] INVALID [1] ABOVE_BARRIER [2] LOG_SAT [3] reserved
//   warn_o    [0] WKB_WEAK (2S < 2)  [1] TX_UNDERFLOW (T rounds to 0)
// On INVALID or ABOVE_BARRIER both data outputs are 0 -- above-barrier is
// reported, never returned as T = 1.
//
// Pipeline (II = 1, verified in RTL simulation). LATENCY = 10 + NS_SQRT +
// 3*PIPE_MUL cycles from the request handshake edge to the earliest response
// handshake edge (38 cycles for the default configuration: NS_SQRT = 25,
// PIPE_MUL = 1). PIPE_MUL adds registers only -- outputs are bit-identical:
//   s1 input register | s2 range check, dE | s3 P=m*dE |
//   NS_SQRT sqrt stages (the 22-bit width rides along as sideband) |
//   s4 s=round(sqrt), K1=C1*a, K2=C2*a | s5 2S=K1*s, Y=K2*s |
//   s6 log saturation, WKB_WEAK | 3 exp stages | output skid buffer
// Every stage advances on `en` = output skid buffer ready (registered), so
// backpressure stalls the whole pipeline without dropping results and with
// no combinational path from rsp_ready_i to req_ready_o.
//
// Reset: synchronous, active low (repository convention). Valid bits are
// reset; data registers are not (they are qualified by valid).
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sf_quantum_tunnel_core #(
    parameter int DATA_W     = 32,
    parameter int FRAC_W     = 16,
    parameter int TAG_W      = 8,
    parameter int SQRT_GUARD = 4,
    parameter int LUT_BITS   = 8,
    parameter int EXP_MODE   = 1,  // 1: LUT + linear interpolation, 0: nearest LUT entry
    parameter int SQRT_BPS   = 1,  // square-root iterations per pipeline stage
    parameter int PIPE_MUL   = 1   // 1: extra registers around the wide multipliers (timing)
)(
    input  wire logic                           clk_i,
    input  wire logic                           rst_ni,

    input  wire logic                           req_valid_i,
    output      logic                           req_ready_o,
    input  wire logic [TAG_W-1:0]               req_tag_i,
    input  wire logic [DATA_W-1:0]              barrier_i,
    input  wire logic [DATA_W-1:0]              energy_i,
    input  wire logic [DATA_W-1:0]              width_i,
    input  wire logic [DATA_W-1:0]              mass_i,

    output      logic                           rsp_valid_o,
    input  wire logic                           rsp_ready_i,
    output      logic [TAG_W-1:0]               rsp_tag_o,
    output      logic [DATA_W-1:0]              log_transmission_o,
    output      logic [DATA_W-1:0]              transmission_o,
    output      logic [sf_qt_pkg::SF_QT_ERR_W-1:0]  error_o,
    output      logic [sf_qt_pkg::SF_QT_WARN_W-1:0] warn_o
);

    // ------------------------------------------------------------ widths
    localparam int F        = FRAC_W;
    localparam int G        = SQRT_GUARD;
    localparam int SF       = F + G;
    localparam int E_IB     = sf_qt_pkg::SF_QT_E_IB;
    localparam int M_IB     = sf_qt_pkg::SF_QT_M_IB;
    localparam int A_IB     = sf_qt_pkg::SF_QT_A_IB;
    localparam int K_IB     = sf_qt_pkg::SF_QT_K_IB;
    localparam int CF       = sf_qt_pkg::SF_QT_CONST_FRAC;
    localparam int W_DE     = E_IB + F;
    localparam int W_M      = M_IB + F;
    localparam int W_AW     = A_IB + F;
    localparam int W_P      = E_IB + M_IB + 2 * F;
    localparam int SQ_RAW   = W_P + 2 * G + 2;
    localparam int SQ_ARG_W = SQ_RAW + (SQ_RAW % 2);
    localparam int SQ_OUT_W = SQ_ARG_W / 2;
    localparam int S_W      = SQ_OUT_W;
    localparam int W_C      = K_IB + CF;
    localparam int W_K      = K_IB + A_IB + SF;
    localparam int W_2S     = W_K + S_W - SF - G;
    localparam int YF       = SF;
    localparam int W_Y      = W_K + S_W - SF;
    localparam int NS_SQRT  = (SQ_OUT_W + SQRT_BPS - 1) / SQRT_BPS;
    localparam int LIM_W    = ((W_2S > DATA_W) ? W_2S : DATA_W) + 1;

    //! Request-to-response latency in cycles (read hierarchically and checked by the testbench).
    /* verilator lint_off UNUSEDPARAM */
    localparam int LATENCY  = sf_qt_pkg::SF_QT_LATENCY_FIXED + NS_SQRT + 3 * PIPE_MUL;
    /* verilator lint_on UNUSEDPARAM */

    generate
        if (DATA_W - FRAC_W <= A_IB || DATA_W - FRAC_W <= E_IB || DATA_W - FRAC_W <= M_IB) begin : g_bad_fmt
            sf_qt_core_integer_field_too_narrow u_err ();
        end
        if (CF < G) begin : g_bad_cf
            sf_qt_core_const_frac_below_sqrt_guard u_err ();
        end
    endgenerate

    // --------------------------------------------------- global enable
    logic en;          // = output skid buffer can accept (registered signal)
    assign req_ready_o = en;

    // ======================================================== stage s1
    logic              s1_v;
    logic [TAG_W-1:0]  s1_tag;
    logic [DATA_W-1:0] s1_v0, s1_e, s1_a, s1_m;

    always_ff @(posedge clk_i) begin
        if (!rst_ni)   s1_v <= 1'b0;
        else if (en)   s1_v <= req_valid_i;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin
            s1_tag <= req_tag_i;
            s1_v0  <= barrier_i;
            s1_e   <= energy_i;
            s1_a   <= width_i;
            s1_m   <= mass_i;
        end
    end

    // ======================================================== stage s2: range checks, dE
    logic s2_inv_c, s2_above_c;
    always_comb begin
        s2_inv_c = (s1_e == '0) || (s1_m == '0)
                || (|s1_v0[DATA_W-1:W_DE]) || (|s1_e[DATA_W-1:W_DE])
                || (|s1_a[DATA_W-1:W_AW])  || (|s1_m[DATA_W-1:W_M]);
        s2_above_c = !s2_inv_c && (s1_e >= s1_v0);
    end

    logic              s2_v, s2_inv, s2_above;
    logic [TAG_W-1:0]  s2_tag;
    logic [W_DE-1:0]   s2_de;
    logic [W_AW-1:0]   s2_a;
    logic [W_M-1:0]    s2_m;

    always_ff @(posedge clk_i) begin
        if (!rst_ni)   s2_v <= 1'b0;
        else if (en)   s2_v <= s1_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin
            s2_tag   <= s1_tag;
            s2_inv   <= s2_inv_c;
            s2_above <= s2_above_c;
            s2_de    <= s1_v0[W_DE-1:0] - s1_e[W_DE-1:0];
            s2_a     <= s1_a[W_AW-1:0];
            s2_m     <= s1_m[W_M-1:0];
        end
    end

    // ======================================================== stage s3: P = m * dE (exact)
    logic [W_P-1:0] p_c;
    logic           p_sat;

    sf_qt_fixed_mul #(.A_W(W_M), .B_W(W_DE), .SHIFT(0), .OUT_W(W_P)) u_mul_p (
        .a_i(s2_m), .b_i(s2_de), .y_o(p_c), .sat_o(p_sat));

    logic              s3_v, s3_inv, s3_above;
    logic [TAG_W-1:0]  s3_tag;
    logic [W_P-1:0]    s3_p;
    logic [W_AW-1:0]   s3_a;

    always_ff @(posedge clk_i) begin
        if (!rst_ni)   s3_v <= 1'b0;
        else if (en)   s3_v <= s2_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin
            s3_tag   <= s2_tag;
            s3_inv   <= s2_inv;
            s3_above <= s2_above;
            s3_p     <= p_c;
            s3_a     <= s2_a;
        end
    end

    // ======================================================== square root
    localparam int SB1_W = TAG_W + 2 + W_AW;
    logic [SQ_ARG_W-1:0] rad;
    logic [SB1_W-1:0]    sq_sb_in, sq_sb_out;
    logic [SQ_OUT_W-1:0] sq_root;
    logic                sq_v;

    assign rad      = SQ_ARG_W'({s3_p, {(2 * G + 2){1'b0}}});   // P << (2G+2), MSB-padded if odd
    assign sq_sb_in = {s3_tag, s3_inv, s3_above, s3_a};

    sf_qt_sqrt #(.IN_W(SQ_ARG_W), .BITS_PER_STAGE(SQRT_BPS), .SB_W(SB1_W)) u_sqrt (
        .clk_i(clk_i), .rst_ni(rst_ni), .en_i(en),
        .valid_i(s3_v), .rad_i(rad), .sb_i(sq_sb_in),
        .valid_o(sq_v), .root_o(sq_root), .sb_o(sq_sb_out));

    // ======================================================== stage s4: s = round(sqrt), K1, K2
    logic [TAG_W-1:0]  sq_tag;
    logic              sq_inv, sq_above;
    logic [W_AW-1:0]   sq_a;
    assign {sq_tag, sq_inv, sq_above, sq_a} = sq_sb_out;

    logic [W_K-1:0] k1_c, k2_c;
    logic           k1_sat, k2_sat;
    sf_qt_fixed_mul #(.A_W(W_C), .B_W(W_AW), .SHIFT(CF - G), .OUT_W(W_K)) u_mul_k1 (
        .a_i(sf_qt_pkg::SF_QT_C1_CODE), .b_i(sq_a), .y_o(k1_c), .sat_o(k1_sat));
    sf_qt_fixed_mul #(.A_W(W_C), .B_W(W_AW), .SHIFT(CF - G), .OUT_W(W_K)) u_mul_k2 (
        .a_i(sf_qt_pkg::SF_QT_C2_CODE), .b_i(sq_a), .y_o(k2_c), .sat_o(k2_sat));

    logic              s4_v, s4_inv, s4_above;
    logic [TAG_W-1:0]  s4_tag;
    logic [W_K-1:0]    s4_k1, s4_k2;
    logic [S_W-1:0]    s4_s;
    /* verilator lint_off UNUSEDSIGNAL */
    logic [S_W:0]      r_plus1;   // bit 0 is dropped by the >> 1 rounding shift
    /* verilator lint_on UNUSEDSIGNAL */
    assign r_plus1 = {1'b0, sq_root} + {{S_W{1'b0}}, 1'b1};

    always_ff @(posedge clk_i) begin
        if (!rst_ni)   s4_v <= 1'b0;
        else if (en)   s4_v <= sq_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin
            s4_tag   <= sq_tag;
            s4_inv   <= sq_inv;
            s4_above <= sq_above;
            s4_k1    <= k1_c;
            s4_k2    <= k2_c;
            s4_s     <= r_plus1[S_W:1];
        end
    end

    // ======================================================== stage s5: 2S and Y
    // PIPE_MUL = 1 registers the raw products (s5a) and rounds them in s5.
    localparam int PR_W = W_K + S_W;
    logic [PR_W-1:0] pr1_c, pr2_c, pr1, pr2;
    logic            s5a_v, s5a_inv, s5a_above;
    logic [TAG_W-1:0] s5a_tag;
    logic            pr1_sat, pr2_sat;

    sf_qt_fixed_mul #(.A_W(W_K), .B_W(S_W), .SHIFT(0), .OUT_W(PR_W)) u_mul_pr1 (
        .a_i(s4_k1), .b_i(s4_s), .y_o(pr1_c), .sat_o(pr1_sat));
    sf_qt_fixed_mul #(.A_W(W_K), .B_W(S_W), .SHIFT(0), .OUT_W(PR_W)) u_mul_pr2 (
        .a_i(s4_k2), .b_i(s4_s), .y_o(pr2_c), .sat_o(pr2_sat));

    generate
        if (PIPE_MUL != 0) begin : g_s5a
            always_ff @(posedge clk_i) begin
                if (!rst_ni)   s5a_v <= 1'b0;
                else if (en)   s5a_v <= s4_v;
            end
            always_ff @(posedge clk_i) begin
                if (en) begin
                    pr1 <= pr1_c; pr2 <= pr2_c; s5a_tag <= s4_tag; s5a_inv <= s4_inv; s5a_above <= s4_above;
                end
            end
        end else begin : g_s5a_wire
            assign s5a_v = s4_v; assign pr1 = pr1_c; assign pr2 = pr2_c;
            assign s5a_tag = s4_tag; assign s5a_inv = s4_inv; assign s5a_above = s4_above;
        end
    endgenerate

    logic [W_2S-1:0] two_s_c;
    logic [W_Y-1:0]  y_c;
    logic            two_s_sat, y_sat;

    // round-half-up shifts of the exact products (multiply by 1 = pure rounding)
    sf_qt_fixed_mul #(.A_W(PR_W), .B_W(1), .SHIFT(F + 2 * G), .OUT_W(W_2S)) u_rnd_2s (
        .a_i(pr1), .b_i(1'b1), .y_o(two_s_c), .sat_o(two_s_sat));
    sf_qt_fixed_mul #(.A_W(PR_W), .B_W(1), .SHIFT(2 * SF - YF), .OUT_W(W_Y)) u_rnd_y (
        .a_i(pr2), .b_i(1'b1), .y_o(y_c), .sat_o(y_sat));

    logic              s5_v, s5_inv, s5_above;
    logic [TAG_W-1:0]  s5_tag;
    logic [W_2S-1:0]   s5_two_s;
    logic [W_Y-1:0]    s5_y;

    always_ff @(posedge clk_i) begin
        if (!rst_ni)   s5_v <= 1'b0;
        else if (en)   s5_v <= s5a_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin
            s5_tag   <= s5a_tag;
            s5_inv   <= s5a_inv;
            s5_above <= s5a_above;
            s5_two_s <= two_s_c;
            s5_y     <= y_c;
        end
    end

    // ======================================================== stage s6: log output, WKB_WEAK
    localparam logic [LIM_W-1:0] LOG_LIMIT = LIM_W'(1) << (DATA_W - 1);
    localparam logic [LIM_W-1:0] WEAK_LIM  = LIM_W'(2) << F;
    logic [LIM_W-1:0]  two_s_ext;
    logic              log_sat_c, weak_c;
    logic [DATA_W-1:0] log_c;

    always_comb begin
        two_s_ext = LIM_W'(s5_two_s);
        log_sat_c = two_s_ext > LOG_LIMIT;
        weak_c    = two_s_ext < WEAK_LIM;
        if (log_sat_c) log_c = {1'b1, {(DATA_W - 1){1'b0}}};
        else           log_c = DATA_W'(~two_s_ext + LIM_W'(1));
    end

    localparam int SB2_W = TAG_W + 4 + DATA_W;
    logic              s6_v;
    logic [W_Y-1:0]    s6_y;
    logic [SB2_W-1:0]  s6_sb;

    always_ff @(posedge clk_i) begin
        if (!rst_ni)   s6_v <= 1'b0;
        else if (en)   s6_v <= s5_v;
    end
    always_ff @(posedge clk_i) begin
        if (en) begin
            s6_y  <= s5_y;
            s6_sb <= {s5_tag, s5_inv, s5_above, log_sat_c, weak_c, log_c};
        end
    end

    // ======================================================== exp unit
    logic              ex_v, ex_under;
    logic [DATA_W-1:0] ex_t;
    logic [SB2_W-1:0]  ex_sb;

    sf_qt_exp_lut #(.DATA_W(DATA_W), .YF(YF), .W_Y(W_Y), .LUT_BITS(LUT_BITS), .MODE(EXP_MODE),
                    .PIPE(PIPE_MUL), .SB_W(SB2_W)) u_exp (
        .clk_i(clk_i), .rst_ni(rst_ni), .en_i(en),
        .valid_i(s6_v), .y_i(s6_y), .sb_i(s6_sb),
        .valid_o(ex_v), .t_o(ex_t), .underflow_o(ex_under), .sb_o(ex_sb));

    // ======================================================== output assembly + skid buffer
    logic [TAG_W-1:0]  o_tag;
    logic              o_inv, o_above, o_lsat, o_weak;
    logic [DATA_W-1:0] o_log;
    assign {o_tag, o_inv, o_above, o_lsat, o_weak, o_log} = ex_sb;

    localparam int PAY_W = TAG_W + 2 * DATA_W + sf_qt_pkg::SF_QT_ERR_W + sf_qt_pkg::SF_QT_WARN_W;
    logic              bad;
    logic [PAY_W-1:0]  payload, payload_out;
    logic [sf_qt_pkg::SF_QT_ERR_W-1:0]  err_c;
    logic [sf_qt_pkg::SF_QT_WARN_W-1:0] warn_c;

    always_comb begin
        bad = o_inv || o_above;
        err_c = '0;
        err_c[sf_qt_pkg::SF_QT_ERR_INVALID] = o_inv;
        err_c[sf_qt_pkg::SF_QT_ERR_ABOVE]   = o_above && !o_inv;
        err_c[sf_qt_pkg::SF_QT_ERR_LOG_SAT] = o_lsat && !bad;
        warn_c = '0;
        warn_c[sf_qt_pkg::SF_QT_WARN_WKB_WEAK] = o_weak && !bad;
        warn_c[sf_qt_pkg::SF_QT_WARN_TX_UNDER] = ex_under && !bad;
        payload = {o_tag, bad ? '0 : o_log, bad ? '0 : ex_t, err_c, warn_c};
    end

    sfx_skid_buffer #(.WIDTH(PAY_W)) u_out (
        .clk(clk_i), .rst_n(rst_ni),
        .in_valid(ex_v), .in_ready(en), .in_data(payload),
        .out_valid(rsp_valid_o), .out_ready(rsp_ready_i), .out_data(payload_out));

    assign {rsp_tag_o, log_transmission_o, transmission_o, error_o, warn_o} = payload_out;

`ifndef SFX_SYNTHESIS
    // Internal datapath must never saturate for range-checked inputs.
    always_ff @(posedge clk_i) begin
        if (rst_ni && en) begin
            if (s2_v && !s2_inv && !s2_above)
                assert (!p_sat)
                    else $error("sf_quantum_tunnel_core: stage-3 product overflow (width bug)");
            if (sq_v && !sq_inv && !sq_above)
                assert (!k1_sat && !k2_sat)
                    else $error("sf_quantum_tunnel_core: stage-4 constant product overflow (width bug)");
            if (s4_v && !s4_inv && !s4_above)
                assert (!pr1_sat && !pr2_sat)
                    else $error("sf_quantum_tunnel_core: stage-5 product overflow (width bug)");
            if (s5a_v && !s5a_inv && !s5a_above)
                assert (!two_s_sat && !y_sat)
                    else $error("sf_quantum_tunnel_core: stage-5 product overflow (width bug)");
        end
    end
`endif

endmodule

`default_nettype wire
