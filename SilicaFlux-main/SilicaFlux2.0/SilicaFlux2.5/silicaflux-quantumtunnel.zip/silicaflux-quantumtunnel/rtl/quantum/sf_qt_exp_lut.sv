// =============================================================================
// sf_qt_exp_lut.sv -- T = 2^-y in UQ0.DATA_W from y in UQ(W_Y-YF).YF
//
//   y = yi + yf,  2^-y = 2^-yi * 2^-yf,  2^-yf in (1/2, 1]
//   2^-yf : ROM of 2^LUT_BITS (base, delta) pairs, base = round(2^(-i/2^L) 2^MANT_F)
//           MODE 1 (default): linear interpolation  mant = base - round(delta*rem / 2^R)
//           MODE 0          : nearest entry         mant = rem >= 2^(R-1) ? base - delta : base
//   T     = round(mant * 2^-(yi + MANT_F - DATA_W)),  saturated to 2^DATA_W - 1
//
// MANT_F = DATA_W + 2 (two guard bits below the output LSB). Shifts larger than
// MANT_F+1 give exactly 0 (underflow_o), which never corrupts the separately
// computed log output. Pipeline: split+ROM | [PIPE: ROM output register] |
// multiply | [PIPE: product register] | subtract | shift -> 3 + 2*PIPE stages.
// PIPE only adds registers; the arithmetic (and every output bit) is unchanged.
//
// Python reference: fixed_point_model.evaluate() (exp part), exp_rom()
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sf_qt_exp_lut #(
    parameter int DATA_W   = 32,
    parameter int YF       = 20,
    parameter int W_Y      = 35,
    parameter int LUT_BITS = 8,
    parameter int MODE     = 1,
    parameter int PIPE     = 0,
    parameter int SB_W     = 1
)(
    input  wire logic              clk_i,
    input  wire logic              rst_ni,
    input  wire logic              en_i,
    input  wire logic              valid_i,
    input  wire logic [W_Y-1:0]    y_i,
    input  wire logic [SB_W-1:0]   sb_i,
    output      logic              valid_o,
    output      logic [DATA_W-1:0] t_o,
    output      logic              underflow_o,
    output      logic [SB_W-1:0]   sb_o
);

    localparam int MANT_F  = DATA_W + 2;
    localparam int BASE_W  = MANT_F + 1;
    localparam int DELTA_W = MANT_F - LUT_BITS;
    localparam int R_BITS  = YF - LUT_BITS;
    localparam int YI_W    = W_Y - YF;
    localparam int SH_MAX  = MANT_F + 1;
    localparam int SH_W    = $clog2(SH_MAX + 1);
    localparam int PROD_W  = DELTA_W + R_BITS + 1;

    // ---------------------------------------------------------------- stage 1
    logic [YI_W-1:0]     yi;
    logic [LUT_BITS-1:0] idx;
    logic [R_BITS-1:0]   rem;
    logic [BASE_W-1:0]   base_c;
    logic [DELTA_W-1:0]  delta_c;
    logic [SH_W-1:0]     sh_c;

    assign yi  = y_i[W_Y-1:YF];
    assign idx = y_i[YF-1 -: LUT_BITS];
    assign rem = y_i[R_BITS-1:0];
    // shift-1 = yi + (MANT_F - DATA_W) - 1 = yi + 1, clamped to SH_MAX
    assign sh_c = (yi >= YI_W'(SH_MAX - 1)) ? SH_W'(SH_MAX) : SH_W'(yi) + SH_W'(1);

    generate
        if (LUT_BITS == 8 && MANT_F == 34) begin : g_rom
            sf_qt_exp_rom_l8_m34 u_rom (.idx_i(idx), .base_o(base_c), .delta_o(delta_c));
        end else if (LUT_BITS == 8 && MANT_F == 26) begin : g_rom
            sf_qt_exp_rom_l8_m26 u_rom (.idx_i(idx), .base_o(base_c), .delta_o(delta_c));
        end else begin : g_rom_missing
            sf_qt_exp_rom_not_generated_for_this_configuration u_err ();  // run `make quantum-vectors`
        end
    endgenerate

    logic                v1;
    logic [BASE_W-1:0]   base_q;
    logic [DELTA_W-1:0]  delta_q;
    logic [R_BITS-1:0]   rem_q;
    logic [SH_W-1:0]     sh1_q;
    logic [SB_W-1:0]     sb1_q;

    always_ff @(posedge clk_i) begin
        if (!rst_ni)   v1 <= 1'b0;
        else if (en_i) v1 <= valid_i;
    end
    always_ff @(posedge clk_i) begin
        if (en_i) begin
            base_q  <= base_c;
            delta_q <= delta_c;
            rem_q   <= rem;
            sh1_q   <= sh_c;
            sb1_q   <= sb_i;
        end
    end

    // ------------------------------------------------- optional ROM output register
    logic                va;
    logic [BASE_W-1:0]   base_a;
    logic [DELTA_W-1:0]  delta_a;
    logic [R_BITS-1:0]   rem_a;
    logic [SH_W-1:0]     sha;
    logic [SB_W-1:0]     sba;

    generate
        if (PIPE != 0) begin : g_rom_reg
            always_ff @(posedge clk_i) begin
                if (!rst_ni)   va <= 1'b0;
                else if (en_i) va <= v1;
            end
            always_ff @(posedge clk_i) begin
                if (en_i) begin
                    base_a <= base_q; delta_a <= delta_q; rem_a <= rem_q; sha <= sh1_q; sba <= sb1_q;
                end
            end
        end else begin : g_rom_wire
            assign va = v1; assign base_a = base_q; assign delta_a = delta_q;
            assign rem_a = rem_q; assign sha = sh1_q; assign sba = sb1_q;
        end
    endgenerate

    // ---------------------------------------------------------------- stage 2: multiply
    logic [PROD_W-1:0] prod_c;
    logic              vb;
    logic [PROD_W-1:0] prod_b;
    logic [BASE_W-1:0] base_b;
    logic              rsel_b;
    logic [DELTA_W-1:0] delta_b;
    logic [SH_W-1:0]   shb;
    logic [SB_W-1:0]   sbb;

    assign prod_c = {{(R_BITS + 1){1'b0}}, delta_a} * {{(DELTA_W + 1){1'b0}}, rem_a};

    generate
        if (PIPE != 0) begin : g_prod_reg
            always_ff @(posedge clk_i) begin
                if (!rst_ni)   vb <= 1'b0;
                else if (en_i) vb <= va;
            end
            always_ff @(posedge clk_i) begin
                if (en_i) begin
                    prod_b <= prod_c; base_b <= base_a; rsel_b <= rem_a[R_BITS-1]; delta_b <= delta_a;
                    shb <= sha; sbb <= sba;
                end
            end
        end else begin : g_prod_wire
            assign vb = va; assign prod_b = prod_c; assign base_b = base_a; assign rsel_b = rem_a[R_BITS-1];
            assign delta_b = delta_a; assign shb = sha; assign sbb = sba;
        end
    endgenerate

    // ---------------------------------------------------------------- stage 2': subtract
    logic [BASE_W-1:0] corr, mant_c;
    localparam logic [PROD_W-1:0] HALF_R = PROD_W'(1) << (R_BITS - 1);

    always_comb begin
        if (MODE == 1) begin
            corr = BASE_W'((prod_b + HALF_R) >> R_BITS);
        end else begin
            corr = rsel_b ? BASE_W'(delta_b) : '0;
        end
        mant_c = base_b - corr;
    end

    logic              v2;
    logic [BASE_W-1:0] mant_q;
    logic [SH_W-1:0]   sh2_q;
    logic [SB_W-1:0]   sb2_q;

    always_ff @(posedge clk_i) begin
        if (!rst_ni)   v2 <= 1'b0;
        else if (en_i) v2 <= vb;
    end
    always_ff @(posedge clk_i) begin
        if (en_i) begin
            mant_q <= mant_c;
            sh2_q  <= shb;
            sb2_q  <= sbb;
        end
    end

    // ---------------------------------------------------------------- stage 3
    logic [BASE_W-1:0] shifted;
    logic [BASE_W:0]   t_wide;
    logic [DATA_W-1:0] t_c;

    always_comb begin
        shifted = mant_q >> sh2_q;
        t_wide  = ({1'b0, shifted} + {{BASE_W{1'b0}}, 1'b1}) >> 1;
        if (|t_wide[BASE_W:DATA_W]) t_c = {DATA_W{1'b1}};     // T = 1.0 saturates to 1 - 2^-W
        else                        t_c = t_wide[DATA_W-1:0];
    end

    always_ff @(posedge clk_i) begin
        if (!rst_ni)   valid_o <= 1'b0;
        else if (en_i) valid_o <= v2;
    end
    always_ff @(posedge clk_i) begin
        if (en_i) begin
            t_o         <= t_c;
            underflow_o <= (t_c == '0);
            sb_o        <= sb2_q;
        end
    end

endmodule

`default_nettype wire
