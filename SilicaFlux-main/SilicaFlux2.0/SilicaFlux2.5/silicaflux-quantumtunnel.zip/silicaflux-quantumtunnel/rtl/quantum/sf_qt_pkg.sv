// =============================================================================
// sf_qt_pkg.sv -- SilicaFlux QuantumTunnel shared constants
//
// Referenced explicitly as sf_qt_pkg::NAME (Yosys 0.33 rejects `import pkg::*`).
// Python reference: python/sf_quantum/reference/fixed_point_model.py (HWConfig)
// =============================================================================
`ifndef SF_QT_PKG_SV
`define SF_QT_PKG_SV

`timescale 1ns/1ps

package sf_qt_pkg;

    // Generated from scipy.constants (CODATA) by `make quantum-vectors`:
    //   SF_QT_CONST_FRAC, SF_QT_C1_CODE, SF_QT_C2_CODE
    `include "sf_qt_constants.svh"

    // Range checks (integer bits of the validated input ranges)
    localparam int SF_QT_E_IB = 4;   // V0, E   < 16 eV
    localparam int SF_QT_M_IB = 4;   // m*/m_e  < 16
    localparam int SF_QT_A_IB = 6;   // width   < 64 nm
    localparam int SF_QT_K_IB = 4;   // C1, C2  < 16

    // Status-bit definitions are interface constants shared by several modules;
    // not every top uses every one.
    /* verilator lint_off UNUSEDPARAM */
    // error_o bit positions
    localparam int SF_QT_ERR_W        = 4;
    localparam int SF_QT_ERR_INVALID  = 0;  // E==0, M==0 or an input out of range
    localparam int SF_QT_ERR_ABOVE    = 1;  // E >= V0: no forbidden region (outputs 0, not T=1)
    localparam int SF_QT_ERR_LOG_SAT  = 2;  // 2S beyond the log output range
    // bit 3 reserved (0)

    // warn_o bit positions
    localparam int SF_QT_WARN_W          = 2;
    localparam int SF_QT_WARN_WKB_WEAK   = 0;  // 2S < 2: WKB unreliable
    localparam int SF_QT_WARN_TX_UNDER   = 1;  // T rounds to 0 in UQ0.DATA_W
    /* verilator lint_on UNUSEDPARAM */

    // Fixed pipeline overhead around the square-root unit (see core header):
    // LATENCY = cycles from the request handshake edge to the earliest
    // response handshake edge = SF_QT_LATENCY_FIXED + NS_SQRT.
    /* verilator lint_off UNUSEDPARAM */
    localparam int SF_QT_LATENCY_FIXED = 10;
    /* verilator lint_on UNUSEDPARAM */

    // Identification for the register adapter (unused by the core itself)
    /* verilator lint_off UNUSEDPARAM */
    localparam logic [31:0] SF_QT_ID      = 32'h5346_5154;  // "SFQT"
    localparam logic [15:0] SF_QT_VERSION = 16'h0100;       // 1.0
    /* verilator lint_on UNUSEDPARAM */

endpackage

`endif
