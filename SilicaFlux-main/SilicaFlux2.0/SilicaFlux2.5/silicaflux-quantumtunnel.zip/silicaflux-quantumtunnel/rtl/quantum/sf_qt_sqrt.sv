// =============================================================================
// sf_qt_sqrt.sv -- pipelined exact integer square root (digit recurrence)
//
//   root_o = floor(sqrt(rad_i))        (exact, no approximation)
//
// Restoring radix-2 digit recurrence: each iteration consumes two radicand
// bits and produces one root bit. BITS_PER_STAGE iterations are evaluated
// combinationally per pipeline stage, so
//   latency = NS = ceil((IN_W/2) / BITS_PER_STAGE) cycles,  II = 1.
// A sideband payload travels with each operand. All stages advance only when
// en_i is high (global stall from the core's output stage).
//
// Bound used for the remainder width: after k root bits, rem <= 2*root < 2^(k+1),
// so REM_W = OUT_W + 2 bits never overflow.
//
// Python reference: math.isqrt (fixed_point_model.isqrt_floor)
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sf_qt_sqrt #(
    parameter int IN_W           = 50,
    parameter int BITS_PER_STAGE = 1,
    parameter int SB_W           = 1
)(
    input  wire logic              clk_i,
    input  wire logic              rst_ni,
    input  wire logic              en_i,
    input  wire logic              valid_i,
    input  wire logic [IN_W-1:0]   rad_i,
    input  wire logic [SB_W-1:0]   sb_i,
    output      logic              valid_o,
    output      logic [IN_W/2-1:0] root_o,
    output      logic [SB_W-1:0]   sb_o
);

    localparam int OUT_W = IN_W / 2;
    localparam int NS    = (OUT_W + BITS_PER_STAGE - 1) / BITS_PER_STAGE;
    localparam int REM_W = OUT_W + 2;

    generate
        if (IN_W % 2 != 0) begin : g_bad_width
            sf_qt_sqrt_requires_even_input_width u_err ();  // elaboration error by design
        end
    endgenerate

    // stage pipelines, flattened into packed vectors (Icarus/Yosys-portable)
    logic [NS*IN_W-1:0]  rad_p;
    logic [NS*REM_W-1:0] rem_p;
    logic [NS*OUT_W-1:0] root_p;
    logic [NS*SB_W-1:0]  sb_p;
    logic [NS-1:0]       vld_p;

    genvar s;
    generate
        for (s = 0; s < NS; s++) begin : g_stage
            localparam int ITERS = (s == NS - 1) ? (OUT_W - BITS_PER_STAGE * (NS - 1)) : BITS_PER_STAGE;

            logic [IN_W-1:0]  rad_in,  rad_c;
            logic [REM_W-1:0] rem_in,  rem_c,  rem_sh, trial;
            logic [OUT_W-1:0] root_in, root_c;
            logic [SB_W-1:0]  sb_in;
            logic             v_in;

            if (s == 0) begin : g_first
                assign rad_in  = rad_i;
                assign rem_in  = '0;
                assign root_in = '0;
                assign sb_in   = sb_i;
                assign v_in    = valid_i;
            end else begin : g_next
                assign rad_in  = rad_p [(s-1)*IN_W  +: IN_W];
                assign rem_in  = rem_p [(s-1)*REM_W +: REM_W];
                assign root_in = root_p[(s-1)*OUT_W +: OUT_W];
                assign sb_in   = sb_p  [(s-1)*SB_W  +: SB_W];
                assign v_in    = vld_p [s-1];
            end

            always_comb begin
                rad_c  = rad_in;
                rem_c  = rem_in;
                root_c = root_in;
                rem_sh = '0;
                trial  = '0;
                for (int i = 0; i < ITERS; i++) begin
                    rem_sh = {rem_c[REM_W-3:0], rad_c[IN_W-1 -: 2]};
                    rad_c  = {rad_c[IN_W-3:0], 2'b00};
                    trial  = {root_c, 2'b01};
                    if (rem_sh >= trial) begin
                        rem_c  = rem_sh - trial;
                        root_c = {root_c[OUT_W-2:0], 1'b1};
                    end else begin
                        rem_c  = rem_sh;
                        root_c = {root_c[OUT_W-2:0], 1'b0};
                    end
                end
            end

            always_ff @(posedge clk_i) begin
                if (!rst_ni)      vld_p[s] <= 1'b0;
                else if (en_i)    vld_p[s] <= v_in;
            end

            always_ff @(posedge clk_i) begin
                if (en_i) begin
                    rad_p [s*IN_W  +: IN_W]  <= rad_c;
                    rem_p [s*REM_W +: REM_W] <= rem_c;
                    root_p[s*OUT_W +: OUT_W] <= root_c;
                    sb_p  [s*SB_W  +: SB_W]  <= sb_in;
                end
            end
        end
    endgenerate

    assign valid_o = vld_p[NS-1];
    assign root_o  = root_p[(NS-1)*OUT_W +: OUT_W];
    assign sb_o    = sb_p[(NS-1)*SB_W +: SB_W];

    // the last stage's radicand and remainder are not consumed downstream
    /* verilator lint_off UNUSEDSIGNAL */
    logic unused_tail;
    assign unused_tail = ^{rad_p[(NS-1)*IN_W +: IN_W], rem_p[(NS-1)*REM_W +: REM_W]};
    /* verilator lint_on UNUSEDSIGNAL */

endmodule

`default_nettype wire
