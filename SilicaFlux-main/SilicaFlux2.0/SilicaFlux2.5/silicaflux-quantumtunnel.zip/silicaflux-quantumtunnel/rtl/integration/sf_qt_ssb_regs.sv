// =============================================================================
// sf_qt_ssb_regs.sv -- optional SoC Simple Bus register adapter
//
// Wraps sf_quantum_tunnel_core behind the existing SilicaFlux SoC Simple Bus
// (signal set of soc_integration/rtl/bus/soc_bus_if.sv, slave modport) so a
// CPU on the SoC fabric can run single WKB evaluations. The accelerator stays
// a peripheral: nothing in the CPU or fabric depends on it, and the core is
// still usable standalone through its own ready/valid interface.
//
// Register map (byte offsets from the slave base; 32-bit, word aligned)
//   0x00 CTRL        W   [0] START (self-clearing)  [1] IRQ_EN (R/W)
//   0x04 STATUS      R   [0] BUSY  [1] DONE  [2] START_DROPPED
//                    W1C [1] DONE  [2] START_DROPPED
//   0x08 BARRIER     RW  V0  UQ16.16 eV
//   0x0C ENERGY      RW  E   UQ16.16 eV
//   0x10 WIDTH       RW  a   UQ16.16 nm
//   0x14 MASS        RW  m*  UQ16.16 m0
//   0x18 TAG         RW  [7:0]
//   0x1C RESULT_LOG  R   ln T, SQ16.16
//   0x20 RESULT_T    R   T, UQ0.32
//   0x24 RESULT_STS  R   [3:0] error  [5:4] warn  [15:8] tag
//   0x28 ID          R   0x53465154 "SFQT"
//   0x2C INFO        R   [7:0] FRAC_W  [15:8] LATENCY  [31:16] VERSION
// Unmapped or misaligned addresses complete with rsp_error = 1.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sf_qt_ssb_regs #(
    parameter int FRAC_W = 16
)(
    input  wire logic        clk_i,
    input  wire logic        rst_ni,
    // SoC Simple Bus, slave side
    input  wire logic        req_valid,
    input  wire logic [31:0] req_addr,
    input  wire logic        req_write,
    input  wire logic [31:0] req_wdata,
    input  wire logic [3:0]  req_wstrb,
    output      logic        req_ready,
    output      logic        rsp_valid,
    output      logic [31:0] rsp_rdata,
    output      logic        rsp_error,
    input  wire logic        rsp_ready,
    // interrupt (level, DONE & IRQ_EN)
    output      logic        irq_o
);

    localparam int DATA_W = 32;
    localparam int TAG_W  = 8;
    localparam int NS_SQRT = ((4 + 4 + 2 * FRAC_W + 2 * 4 + 2 + 1) / 2);  // default SQRT_BPS = 1
    localparam logic [7:0] LATENCY = 8'(sf_qt_pkg::SF_QT_LATENCY_FIXED + NS_SQRT + 3);  // core default PIPE_MUL = 1

    // ------------------------------------------------------------ registers
    logic [31:0] r_v0, r_e, r_a, r_m;
    logic [7:0]  r_tag;
    logic        r_irq_en, r_busy, r_done, r_dropped;
    logic [31:0] r_log, r_t;
    logic [3:0]  r_err;
    logic [1:0]  r_warn;
    logic [7:0]  r_rtag;
    logic        launch;  // request pending towards the core

    // ------------------------------------------------------------ core
    logic        c_req_ready, c_rsp_valid;
    logic [TAG_W-1:0]  c_rsp_tag;
    logic [DATA_W-1:0] c_log, c_t;
    logic [3:0]  c_err;
    logic [1:0]  c_warn;

    sf_quantum_tunnel_core #(.DATA_W(DATA_W), .FRAC_W(FRAC_W), .TAG_W(TAG_W)) u_core (
        .clk_i(clk_i), .rst_ni(rst_ni),
        .req_valid_i(launch), .req_ready_o(c_req_ready), .req_tag_i(r_tag),
        .barrier_i(r_v0), .energy_i(r_e), .width_i(r_a), .mass_i(r_m),
        .rsp_valid_o(c_rsp_valid), .rsp_ready_i(1'b1), .rsp_tag_o(c_rsp_tag),
        .log_transmission_o(c_log), .transmission_o(c_t), .error_o(c_err), .warn_o(c_warn));

    // ------------------------------------------------------------ bus
    logic        pending;           // response waiting for rsp_ready
    logic        fire;
    logic [5:0]  word;
    logic        aligned;
    logic [31:0] wmask;

    assign req_ready = !pending;
    assign fire      = req_valid && req_ready;
    assign word      = req_addr[7:2];
    assign aligned   = (req_addr[1:0] == 2'b00) && (req_addr[11:8] == 4'h0);
    assign wmask     = {{8{req_wstrb[3]}}, {8{req_wstrb[2]}}, {8{req_wstrb[1]}}, {8{req_wstrb[0]}}};

    // assignment-style function body: Yosys 0.33 does not accept `return`
    function automatic logic [31:0] merge(input logic [31:0] old, input logic [31:0] wd, input logic [31:0] m);
        merge = (old & ~m) | (wd & m);
    endfunction

    logic [31:0] rdata_c;
    logic        err_c;
    always_comb begin
        rdata_c = '0;
        err_c   = !aligned;
        unique case (word)
            6'h00: rdata_c = {30'b0, r_irq_en, 1'b0};
            6'h01: rdata_c = {29'b0, r_dropped, r_done, r_busy};
            6'h02: rdata_c = r_v0;
            6'h03: rdata_c = r_e;
            6'h04: rdata_c = r_a;
            6'h05: rdata_c = r_m;
            6'h06: rdata_c = {24'b0, r_tag};
            6'h07: rdata_c = r_log;
            6'h08: rdata_c = r_t;
            6'h09: rdata_c = {16'b0, r_rtag, 2'b0, r_warn, r_err};
            6'h0A: rdata_c = sf_qt_pkg::SF_QT_ID;
            6'h0B: rdata_c = {sf_qt_pkg::SF_QT_VERSION, LATENCY, 8'(FRAC_W)};
            default: err_c = 1'b1;
        endcase
        // read-only registers reject writes
        if (req_write && (word >= 6'h07) && (word <= 6'h0B)) err_c = 1'b1;
    end

    always_ff @(posedge clk_i) begin
        if (!rst_ni) begin
            pending   <= 1'b0;
            rsp_valid <= 1'b0;
            rsp_rdata <= '0;
            rsp_error <= 1'b0;
            r_v0 <= '0; r_e <= '0; r_a <= '0; r_m <= '0; r_tag <= '0;
            r_irq_en <= 1'b0; r_busy <= 1'b0; r_done <= 1'b0; r_dropped <= 1'b0;
            r_log <= '0; r_t <= '0; r_err <= '0; r_warn <= '0; r_rtag <= '0;
            launch <= 1'b0;
        end else begin
            // core handshakes
            if (launch && c_req_ready) launch <= 1'b0;
            if (c_rsp_valid) begin
                r_log <= c_log; r_t <= c_t; r_err <= c_err; r_warn <= c_warn; r_rtag <= c_rsp_tag;
                r_busy <= 1'b0;
                r_done <= 1'b1;
            end
            // bus response channel
            if (rsp_valid && rsp_ready) begin
                rsp_valid <= 1'b0;
                pending   <= 1'b0;
            end
            if (fire) begin
                pending   <= 1'b1;
                rsp_valid <= 1'b1;
                rsp_error <= err_c;
                rsp_rdata <= req_write ? 32'b0 : rdata_c;
                if (req_write && !err_c) begin
                    unique case (word)
                        6'h00: begin
                            if (req_wstrb[0]) r_irq_en <= req_wdata[1];
                            if (req_wstrb[0] && req_wdata[0]) begin
                                if (r_busy) r_dropped <= 1'b1;
                                else begin
                                    launch <= 1'b1;
                                    r_busy <= 1'b1;
                                    r_done <= 1'b0;
                                end
                            end
                        end
                        6'h01: begin
                            if (req_wstrb[0] && req_wdata[1]) r_done    <= 1'b0;
                            if (req_wstrb[0] && req_wdata[2]) r_dropped <= 1'b0;
                        end
                        6'h02: r_v0  <= merge(r_v0, req_wdata, wmask);
                        6'h03: r_e   <= merge(r_e,  req_wdata, wmask);
                        6'h04: r_a   <= merge(r_a,  req_wdata, wmask);
                        6'h05: r_m   <= merge(r_m,  req_wdata, wmask);
                        6'h06: if (req_wstrb[0]) r_tag <= req_wdata[7:0];
                        default: ;
                    endcase
                end
            end
        end
    end

    assign irq_o = r_done && r_irq_en;

    /* verilator lint_off UNUSEDSIGNAL */
    logic unused_addr;
    assign unused_addr = ^{req_addr[31:12]};  // upper address bits are decoded by soc_fabric
    /* verilator lint_on UNUSEDSIGNAL */

endmodule

`default_nettype wire
