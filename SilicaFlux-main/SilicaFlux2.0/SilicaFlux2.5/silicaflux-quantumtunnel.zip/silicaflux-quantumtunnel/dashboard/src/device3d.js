// SilicaFlux QuantumTunnel -- optional 3D device view (Three.js).
// Bundled with esbuild into dashboard/vendor/device3d.bundle.js (see dashboard/src/README.md).
// Reads window.SFQT_DEVICE (injected by sf_quantum.viz.dashboard.build_device3d):
//   { stack: [{name, thickness_nm, field_MV_cm}], cut: {x_nm:[], V_eV:[]}, bias_V, label }
// Everything physical shown here comes from that 1D solver output. The 3D body is
// a schematic: lateral dimensions are illustrative and vertical layer thicknesses
// are exaggerated for visibility.
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

const D = window.SFQT_DEVICE;
const C = { navy: 0x0b1630, si: 0x2b3a5c, sd: 0x3d4f78, sio2: 0x00a3c2, hfo2: 0x8c6fe8, gate: 0xb08a2e,
            text: "#E8ECF4", cut: 0xd85c78, field: 0x00a3c2 };
const root = document.getElementById("view");
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(window.devicePixelRatio);
renderer.setSize(root.clientWidth, root.clientHeight);
renderer.setClearColor(0x070e1f);
root.appendChild(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(40, root.clientWidth / root.clientHeight, 0.1, 1000);
camera.position.set(40, 42, 95);
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 8, 0);
scene.add(new THREE.AmbientLight(0xffffff, 0.55));
const dl = new THREE.DirectionalLight(0xffffff, 0.9);
dl.position.set(40, 80, 60);
scene.add(dl);

const VSCALE = D.vscale; // vertical exaggeration of nm-scale layers (stated in the UI)
function box(w, h, d, color, x, y, z, opacity = 1) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d),
    new THREE.MeshStandardMaterial({ color, transparent: opacity < 1, opacity, roughness: 0.6, metalness: 0.15 }));
  m.position.set(x, y + h / 2, z);
  scene.add(m);
  return m;
}
const labels = [];
function label(text, pos) {
  const el = document.createElement("div");
  el.className = "lbl";
  el.textContent = text;
  document.body.appendChild(el);
  labels.push({ el, pos: pos.clone() });
}

// substrate, source / drain, channel
box(70, 12, 40, C.si, 0, -12, 0);
box(18, 4, 40, C.sd, -26, -4, 0);
box(18, 4, 40, C.sd, 26, -4, 0);
label("Si substrate", new THREE.Vector3(0, -8, 22));
label("source (n+)", new THREE.Vector3(-30, -2, 22));
label("drain (n+)", new THREE.Vector3(26, 1, 22));
label("channel", new THREE.Vector3(0, -1, 22));

// gate stack (actual layer order and relative thickness from the solver input)
let y = 0;
for (const L of D.stack) {
  const h = L.thickness_nm * VSCALE;
  const col = L.name.startsWith("HfO2") ? C.hfo2 : C.sio2;
  box(34, h, 40, col, 0, y, 0, 0.92);
  label(`${L.name} ${L.thickness_nm.toFixed(2)} nm  |F| ${L.field_MV_cm.toFixed(2)} MV/cm`, new THREE.Vector3(18, y + h / 2, 21));
  // field arrows (length proportional to the computed field in this layer)
  const len = Math.max(1.0, Math.min(h * 0.9, L.field_MV_cm * 0.5));
  for (const xz of [-10, 0, 10]) {
    const a = new THREE.ArrowHelper(new THREE.Vector3(0, -1, 0), new THREE.Vector3(xz, y + h / 2 + len / 2, -14),
      len, C.field, 0.8, 0.6);
    scene.add(a);
  }
  y += h;
}
box(34, 10, 40, C.gate, 0, y, 0);
label("metal gate", new THREE.Vector3(0, y + 11, 21));

// 1D cut through the stack centre
const cutMat = new THREE.LineBasicMaterial({ color: C.cut });
scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(
  [new THREE.Vector3(0, -6, 20.5), new THREE.Vector3(0, y + 12, 20.5)]), cutMat));
label("1D tunnelling cut", new THREE.Vector3(-2, y + 14, 20.5));

// potential-energy profile along the cut, drawn in a plane beside the device
const px0 = -64, scaleE = 6.0;
const pts = D.cut.x_nm.map((xn, i) => new THREE.Vector3(px0 + D.cut.V_eV[i] * scaleE, xn * VSCALE, 20.5));
scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),
  new THREE.LineBasicMaterial({ color: 0xc9a84c })));
scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(
  [new THREE.Vector3(px0, -6, 20.5), new THREE.Vector3(px0, y + 6, 20.5)]),
  new THREE.LineBasicMaterial({ color: 0x6f7c96 })));
label(`Ec(x) along the cut (eV), ${D.label}`, new THREE.Vector3(px0 + 22, y + 9, 20.5));
label("E = 0 (Si Ec)", new THREE.Vector3(px0 - 4, -7, 20.5));

// tunnelling direction (substrate -> gate), not a trajectory
const tun = new THREE.ArrowHelper(new THREE.Vector3(0, 1, 0), new THREE.Vector3(-6, -3, 20.5), y + 6, 0xd85c78, 1.4, 1.0);
scene.add(tun);
label("tunnelling direction (a probability, not a path)", new THREE.Vector3(-14, y + 4, 23));

function placeLabels() {
  const w = root.clientWidth, h = root.clientHeight;
  for (const L of labels) {
    const p = L.pos.clone().project(camera);
    L.el.style.left = `${(p.x * 0.5 + 0.5) * w}px`;
    L.el.style.top = `${(-p.y * 0.5 + 0.5) * h + root.offsetTop}px`;
    L.el.style.display = p.z < 1 ? "block" : "none";
  }
}
function animate() {
  controls.update();
  renderer.render(scene, camera);
  placeLabels();
  requestAnimationFrame(animate);
}
window.addEventListener("resize", () => {
  camera.aspect = root.clientWidth / root.clientHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(root.clientWidth, root.clientHeight);
});
animate();
