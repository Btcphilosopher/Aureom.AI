# 3D view source

`device3d.js` is bundled (Three.js r0.187 + OrbitControls, MIT licence) into
`../vendor/device3d.bundle.js` so that `device3d.html` works offline from `file://`:

    npm install three@0.187.0 esbuild
    npx esbuild device3d.js --bundle --minify --format=iife --legal-comments=eof \
        --outfile=../vendor/device3d.bundle.js

`sf_quantum.viz.dashboard.build_device3d()` injects the solver data
(`window.SFQT_DEVICE`) and inlines the bundle; Python does not need Node.
