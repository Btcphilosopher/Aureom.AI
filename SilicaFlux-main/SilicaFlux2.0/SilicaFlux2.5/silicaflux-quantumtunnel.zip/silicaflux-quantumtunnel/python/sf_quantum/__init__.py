"""SilicaFlux QuantumTunnel.

One-dimensional, effective-mass, coherent quantum-tunnelling physics engine
with three explicitly separated solver levels:

* Level 1 -- exact analytical transmission for an ideal rectangular barrier
  (:mod:`sf_quantum.quantum.rectangular`).
* Level 2 -- WKB semiclassical transmission with validity diagnostics
  (:mod:`sf_quantum.quantum.wkb`).
* Level 3 -- numerical open-boundary scattering: a stable scattering-matrix
  (Redheffer star product) solver (:mod:`sf_quantum.quantum.scattering`) and
  an independent finite-difference quantum-transmitting-boundary solver
  (:mod:`sf_quantum.quantum.schrodinger`).

Everything is SI internally. Nothing in this package is calibrated against a
foundry process or measured silicon; see ``docs/LIMITATIONS.md``.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]
