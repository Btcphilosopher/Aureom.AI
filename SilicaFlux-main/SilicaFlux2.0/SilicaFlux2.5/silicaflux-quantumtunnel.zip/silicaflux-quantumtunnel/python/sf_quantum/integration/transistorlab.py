"""TransistorLab integration contract (proposed).

TransistorLab does **not** exist in the audited SilicaFlux repository
(docs/AUDIT.md). This module therefore defines the request/response contract
a TransistorLab implementation would use, and a working adapter that serves
it with QuantumTunnel. When TransistorLab lands, it needs only to produce
:class:`TunnellingRequest` objects; nothing here assumes its internals.

Accepted inputs: device geometry, dielectric structure, electrostatic
potential profile (optional), bias conditions, material parameters.
Returned: transmission spectra, WKB action, wavefunction summary, selected
current estimates (only where the model's requirements are met), validity
warnings and numerical error estimates. Nothing is labelled foundry-calibrated.
"""

from __future__ import annotations

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from ..devices import materials as M
from ..devices.advanced import DeviceSlice
from ..devices.dielectric_stack import DielectricLayer, DielectricStack
from ..devices.electrostatics import MOSCapacitor, profile_from_potential
from ..models.current import UnsupportedModelError
from ..quantum import scattering, wkb
from ..quantum.constants import Q_E

CALIBRATION = "model-derived; not calibrated against foundry, PDK or measured devices"


class LayerSpec(BaseModel):
    material: str = Field(description="key of sf_quantum.devices.materials.DIELECTRICS, or 'hypothetical'")
    thickness_nm: float = Field(gt=0)
    k: float | None = None
    cbo_eV: float | None = None
    mass_rel: float | None = None


class PotentialSpec(BaseModel):
    x_nm: list[float]
    phi_V: list[float]
    delta_ec_eV: list[float]
    mass_rel: list[float]
    energy_reference: str


class TunnellingRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    device: str = Field("planar MOSFET", description="architecture name (geometry is recorded, not solved in 3D)")
    geometry: dict = Field(default_factory=dict)
    stack: list[LayerSpec]
    gate_voltage_V: float | None = None
    stack_voltage_V: float | None = None
    substrate_doping_cm3: float = 1e17
    substrate_type: str = "p"
    temperature_K: float = 300.0
    energies_eV: list[float] = Field(default_factory=lambda: [0.05, 0.1, 0.2])
    potential: PotentialSpec | None = None


class TunnellingResponse(BaseModel):
    dimensionality: str
    profile: dict
    energies_eV: list[float]
    log_transmission_scattering: list[float]
    log_transmission_wkb: list[float | None]
    wkb_action: list[float | None]
    wkb_flags: list[list[str]]
    wavefunction_summary: dict
    current_estimates: dict
    numerical_error_estimates: dict
    validity_warnings: list[str]
    calibration: str = CALIBRATION


def _stack(req: TunnellingRequest) -> DielectricStack:
    layers = []
    for l in req.stack:
        if l.material in M.DIELECTRICS and l.k is None and l.cbo_eV is None and l.mass_rel is None:
            mat = M.DIELECTRICS[l.material]
        else:
            base = M.DIELECTRICS.get(l.material)
            mat = M.hypothetical_dielectric(
                l.material, l.k if l.k is not None else base.relative_permittivity.value,
                l.cbo_eV if l.cbo_eV is not None else base.conduction_band_offset_eV.value,
                l.mass_rel if l.mass_rel is not None else base.tunnelling_mass_rel.value,
                note="TransistorLab-supplied override")
        layers.append(DielectricLayer(material=mat, thickness_nm=l.thickness_nm))
    return DielectricStack(name=f"{req.device} stack", layers=tuple(layers))


def analyse(req: TunnellingRequest) -> TunnellingResponse:
    warnings = ["1D tunnelling slice: no 3D electrostatics, confinement or atomistic effects",
                "gate-current density is not computed for Si inversion/accumulation emitters "
                "(2D subband supply not implemented)"]
    stack = _stack(req)
    if req.potential is not None:
        p = req.potential
        prof = profile_from_potential(p.x_nm, p.phi_V, p.delta_ec_eV, p.mass_rel, energy_reference=p.energy_reference,
                                      label="TransistorLab-supplied potential")
        warnings.append("potential supplied by caller; its energy reference is taken as given")
    elif req.gate_voltage_V is not None:
        mos = MOSCapacitor(stack, M.GENERIC_METAL_GATE, req.substrate_doping_cm3, req.substrate_type, req.temperature_K)
        prof = DeviceSlice(req.device, "gate dielectric normal", stack,
                           potential_source=lambda s, v: mos.barrier_profile(v), geometry=req.geometry).profile(req.gate_voltage_V)
        warnings += list(MOSCapacitor.ASSUMPTIONS)
    elif req.stack_voltage_V is not None:
        prof = DeviceSlice(req.device, "gate dielectric normal", stack, geometry=req.geometry).profile(req.stack_voltage_V)
        warnings.append("SIMPLIFIED voltage-drop model (stack voltage given directly)")
    else:
        raise ValueError("give potential, gate_voltage_V or stack_voltage_V")
    E = np.asarray(req.energies_eV) * Q_E
    if np.any(E <= prof.left.potential_J):
        raise ValueError("energies must lie above the left-lead band edge of the profile")
    sc = scattering.transmission(prof, E)
    w_res = [wkb.wkb(prof, e) for e in E]
    conv = scattering.converged_transmission(prof, float(E[0]))
    wf = scattering.wavefunction(prof, float(E[0]), n_points=400)
    return TunnellingResponse(
        dimensionality=prof.dimensionality, profile=prof.to_dict(), energies_eV=list(req.energies_eV),
        log_transmission_scattering=[float(x) for x in sc.log_transmission],
        log_transmission_wkb=[None if not np.isfinite(r.log_transmission) else float(r.log_transmission) for r in w_res],
        wkb_action=[float(r.action) if r.turning_points_m else None for r in w_res],
        wkb_flags=[[f.value for f in r.flags] for r in w_res],
        wavefunction_summary={"energy_eV": req.energies_eV[0], "transmission": wf.transmission,
                              "current_uniformity": float((wf.current.max() - wf.current.min()) / wf.incident_flux),
                              "normalisation": "unit-amplitude incident plane wave"},
        current_estimates={"status": "not computed",
                           "reason": str(UnsupportedModelError("Si surface emitter: 2D supply function not implemented"))},
        numerical_error_estimates={"smatrix_log_T_error_estimate_at_first_energy": conv["error_estimate"],
                                   "max_flux_conservation_error": float(sc.conservation_error.max())},
        validity_warnings=warnings,
    )


__all__ = ["TunnellingRequest", "TunnellingResponse", "LayerSpec", "PotentialSpec", "analyse", "CALIBRATION"]
