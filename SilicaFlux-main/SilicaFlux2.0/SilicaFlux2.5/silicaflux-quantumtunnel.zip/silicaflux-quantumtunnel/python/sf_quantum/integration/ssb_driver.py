"""Software view of the SoC Simple Bus register adapter (rtl/integration/sf_qt_ssb_regs.sv).

``RegisterMap`` is the single Python statement of the register layout; the
RTL testbench ``tests/rtl/tb_sf_qt_ssb_regs.sv`` exercises the same offsets
and ``tests/integration`` checks the two agree. ``Driver`` shows the intended
firmware sequence against any object with ``read32(addr)``/``write32(addr, v)``
(e.g. a cocotb bus model or a memory-mapped device file).

DataFabric: no module of that name exists in the audited repository. The SSB
adapter is the integration point that uses an *existing* transaction format;
a NoC-flit adapter is deferred until the accelerator has demonstrated value
(docs/ROADMAP.md).
"""

from __future__ import annotations

from dataclasses import dataclass

from ..reference import fixed_point_model as FP


@dataclass(frozen=True)
class RegisterMap:
    CTRL: int = 0x00
    STATUS: int = 0x04
    BARRIER: int = 0x08
    ENERGY: int = 0x0C
    WIDTH: int = 0x10
    MASS: int = 0x14
    TAG: int = 0x18
    RESULT_LOG: int = 0x1C
    RESULT_T: int = 0x20
    RESULT_STS: int = 0x24
    ID: int = 0x28
    INFO: int = 0x2C
    ID_VALUE: int = 0x53465154
    CTRL_START: int = 1 << 0
    CTRL_IRQ_EN: int = 1 << 1
    STATUS_BUSY: int = 1 << 0
    STATUS_DONE: int = 1 << 1
    STATUS_DROPPED: int = 1 << 2


REGS = RegisterMap()


class Driver:
    def __init__(self, bus, base: int = 0x4000_4000, poll_limit: int = 1000):
        self.bus, self.base, self.poll_limit = bus, base, poll_limit

    def evaluate(self, v0_eV: float, e_eV: float, a_nm: float, m_rel: float, tag: int = 0) -> dict:
        b = self.base
        if self.bus.read32(b + REGS.ID) != REGS.ID_VALUE:
            raise RuntimeError("QuantumTunnel accelerator not found at base address")
        for off, val in ((REGS.BARRIER, v0_eV), (REGS.ENERGY, e_eV), (REGS.WIDTH, a_nm), (REGS.MASS, m_rel)):
            self.bus.write32(b + off, FP.encode(val, 16, 32))
        self.bus.write32(b + REGS.TAG, tag & 0xFF)
        self.bus.write32(b + REGS.CTRL, REGS.CTRL_START)
        for _ in range(self.poll_limit):
            if self.bus.read32(b + REGS.STATUS) & REGS.STATUS_DONE:
                break
        else:
            raise TimeoutError("accelerator did not complete")
        log_code = self.bus.read32(b + REGS.RESULT_LOG)
        t_code = self.bus.read32(b + REGS.RESULT_T)
        sts = self.bus.read32(b + REGS.RESULT_STS)
        self.bus.write32(b + REGS.STATUS, REGS.STATUS_DONE)
        return {"log_T": FP.to_signed(log_code, 32) / 65536, "T": t_code / 2**32, "error": sts & 0xF,
                "warn": (sts >> 4) & 0x3, "tag": (sts >> 8) & 0xFF}


class ModelBus:
    """Behavioural stand-in for the adapter (bit-accurate results via the fixed-point model)."""

    def __init__(self, base: int = 0x4000_4000):
        self.base = base
        self.r = {k: 0 for k in (REGS.BARRIER, REGS.ENERGY, REGS.WIDTH, REGS.MASS, REGS.TAG)}
        self.status = 0
        self.res = (0, 0, 0)

    def read32(self, addr: int) -> int:
        off = addr - self.base
        if off == REGS.ID:
            return REGS.ID_VALUE
        if off == REGS.STATUS:
            return self.status
        if off == REGS.RESULT_LOG:
            return self.res[0]
        if off == REGS.RESULT_T:
            return self.res[1]
        if off == REGS.RESULT_STS:
            return self.res[2]
        return self.r.get(off, 0)

    def write32(self, addr: int, v: int) -> None:
        off = addr - self.base
        if off == REGS.CTRL and v & REGS.CTRL_START:
            h = FP.evaluate(self.r[REGS.BARRIER], self.r[REGS.ENERGY], self.r[REGS.WIDTH], self.r[REGS.MASS])
            self.res = (h.log_code, h.t_code, h.err | (h.warn << 4) | (self.r[REGS.TAG] << 8))
            self.status = REGS.STATUS_DONE
        elif off == REGS.STATUS:
            self.status &= ~v
        elif off in self.r:
            self.r[off] = v


__all__ = ["RegisterMap", "REGS", "Driver", "ModelBus"]
