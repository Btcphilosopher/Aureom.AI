r"""Electrostatic potential inputs for tunnelling profiles.

Four sources of a barrier profile are supported, each labelled in the
resulting profile's notes:

1. :class:`MOSCapacitor` -- **analytical MOS electrostatics**: exact 1D
   Poisson charge of a uniformly doped Si substrate (Boltzmann statistics,
   full depletion/accumulation/inversion expression), gate work function,
   fixed oxide charge, multilayer dielectric. The gate voltage is *not*
   assumed to drop entirely across the dielectric: the surface potential
   :math:`\psi_s` is solved from

   .. math:: V_G - \phi_{ms} = \psi_s + V_\mathrm{stack}(\psi_s),\qquad
             V_\mathrm{stack} = \text{stack voltage carrying } D_0 = -(Q_s(\psi_s)+Q_f)

   with :math:`Q_s` the Kingston/Taur-Ning charge expression.
2. :func:`profile_from_potential` -- any **imported numerical field data**
   (e.g. a TCAD cut): electron potential energy computed consistently as
   :math:`E_c(x) = -q[\phi(x)-\phi_\mathrm{ref}] + \Delta E_c(x)`.
3. :func:`load_devsim_export` -- **DEVSIM** node data exported to CSV/JSON
   (``x``, ``Potential``, ``region``). DEVSIM itself is optional; this module
   only reads its output.
4. :meth:`~sf_quantum.devices.dielectric_stack.DielectricStack.simplified_profile`
   -- the **clearly labelled simplified voltage-drop model**.

Limitations of the analytical MOS model (stated, not hidden): classical
charge (no inversion-layer quantisation or charge-centroid shift), no
polysilicon-gate depletion, no interface traps, Boltzmann statistics (not
valid for degenerate surfaces), intrinsic level assumed at midgap, band
offsets taken as given (no interface dipoles).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from scipy.optimize import brentq

from ..quantum.barriers import PotentialProfile, from_samples
from ..quantum.constants import EPS_0, K_B, Q_E
from ..quantum.units import per_cm3_to_per_m3
from .dielectric_stack import DielectricStack
from .materials import SILICON, Electrode, Semiconductor


@dataclass(frozen=True)
class MOSState:
    gate_voltage_V: float
    flatband_voltage_V: float
    surface_potential_V: float
    stack_voltage_V: float
    semiconductor_charge_C_per_m2: float
    regime: str
    fields_V_per_m: np.ndarray
    voltage_drops_V: np.ndarray
    fraction_across_stack: float
    assumptions: tuple[str, ...] = field(default_factory=tuple)


@dataclass
class MOSCapacitor:
    stack: DielectricStack
    gate: Electrode
    doping_cm3: float = 1e17
    doping_type: str = "p"
    temperature_K: float = 300.0
    fixed_oxide_charge_C_per_m2: float = 0.0
    semiconductor: Semiconductor = SILICON

    ASSUMPTIONS = (
        "classical 1D Poisson charge (Boltzmann), no inversion-layer quantisation",
        "uniform substrate doping, complete ionisation",
        "no poly-gate depletion, no interface traps",
        "intrinsic level at midgap; electron-affinity rule for band offsets",
    )

    def __post_init__(self):
        if self.doping_type not in ("p", "n"):
            raise ValueError("doping_type must be 'p' or 'n'")
        if self.doping_cm3 <= 0 or self.temperature_K <= 0:
            raise ValueError("doping and temperature must be > 0")

    # ------------------------------------------------------------ material
    @property
    def vt(self) -> float:
        return K_B * self.temperature_K / Q_E

    @property
    def eps_si(self) -> float:
        return EPS_0 * self.semiconductor.relative_permittivity.value

    @property
    def n_i(self) -> float:
        return per_cm3_to_per_m3(self.semiconductor.intrinsic_density_cm3.value)

    @property
    def n_dop(self) -> float:
        return per_cm3_to_per_m3(self.doping_cm3)

    @property
    def fermi_potential_V(self) -> float:
        """|E_i - E_F|/q in the bulk."""
        return self.vt * np.log(self.n_dop / self.n_i)

    @property
    def semiconductor_work_function_eV(self) -> float:
        chi = self.semiconductor.electron_affinity_eV.value
        eg = self.semiconductor.bandgap_eV.value
        sgn = 1.0 if self.doping_type == "p" else -1.0
        return chi + eg / 2.0 + sgn * self.fermi_potential_V

    @property
    def flatband_voltage_V(self) -> float:
        phi_ms = self.gate.work_function_eV.value - self.semiconductor_work_function_eV
        c = self.stack.capacitance_F_per_m2
        # interface charges inside the stack shift the flat-band voltage too
        v_int = self.stack.voltage_from_d0(0.0)
        return phi_ms - self.fixed_oxide_charge_C_per_m2 / c + v_int

    # ------------------------------------------------------------ charge
    def semiconductor_charge(self, psi_s: float) -> float:
        """Exact 1D Poisson charge per area Q_s(psi_s) [C/m^2] (Taur & Ning eq. 2.183 form)."""
        b = 1.0 / self.vt
        ratio = (self.n_i / self.n_dop) ** 2
        x = psi_s if self.doping_type == "p" else -psi_s
        f2 = (np.expm1(-b * x) + b * x) + ratio * (np.expm1(b * x) - b * x)
        f = np.sqrt(max(f2, 0.0))
        q = np.sqrt(2.0 * self.eps_si * K_B * self.temperature_K * self.n_dop) * f
        sign = -np.sign(x) if x != 0 else 0.0
        return float(sign * q) if self.doping_type == "p" else float(-sign * q)

    def regime(self, psi_s: float) -> str:
        phi_f = self.fermi_potential_V
        x = psi_s if self.doping_type == "p" else -psi_s
        if abs(x) < 1e-9:
            return "flat-band"
        if x < 0:
            return "accumulation"
        if x < 2.0 * phi_f:
            return "depletion" if x < phi_f else "weak inversion"
        return "strong inversion"

    # ------------------------------------------------------------ solve
    def solve(self, gate_voltage_V: float) -> MOSState:
        vg = float(gate_voltage_V)
        phi_ms = self.gate.work_function_eV.value - self.semiconductor_work_function_eV

        def residual(psi):
            d0 = -(self.semiconductor_charge(psi) + self.fixed_oxide_charge_C_per_m2)
            return psi + self.stack.voltage_from_d0(d0) - (vg - phi_ms)

        lo, hi = -1.5, 1.5
        while residual(lo) > 0:
            lo -= 0.5
        while residual(hi) < 0:
            hi += 0.5
        psi = brentq(residual, lo, hi, xtol=1e-14, rtol=1e-14, maxiter=500)
        qs = self.semiconductor_charge(psi)
        d0 = -(qs + self.fixed_oxide_charge_C_per_m2)
        v_stack = self.stack.voltage_from_d0(d0)
        part = self.stack.partition(v_stack)
        denom = vg - phi_ms
        frac = v_stack / denom if abs(denom) > 1e-12 else float("nan")
        return MOSState(vg, self.flatband_voltage_V, float(psi), float(v_stack), qs, self.regime(psi),
                        part["fields_V_per_m"], part["voltage_drops_V"], float(frac), self.ASSUMPTIONS)

    def barrier_profile(self, gate_voltage_V: float, *, right_lead: str = "gate") -> PotentialProfile:
        """Tunnelling profile from the Si conduction-band edge at the interface to the gate.

        Energy zero: Si conduction-band edge at the Si/dielectric interface.
        With ``right_lead="gate"`` the gate electrode band bottom is placed at
        ``chi_Si - phi_m - q V_stack - E_F,gate`` (vacuum-level alignment).
        """
        st = self.solve(gate_voltage_V)
        chi = self.semiconductor.electron_affinity_eV.value
        if right_lead == "gate":
            vr = chi - self.gate.work_function_eV.value - st.stack_voltage_V - self.gate.fermi_energy_eV.value
            mr = self.gate.mass_rel.value
        else:
            vr, mr = None, 1.0
        return self.stack.barrier_profile(
            st.voltage_drops_V, right_lead_potential_eV=vr, right_lead_mass=mr,
            left_lead_mass=self.semiconductor.lead_mass_rel.value,
            label=f"MOS {self.stack.describe()} @ VG={gate_voltage_V:g} V ({st.regime})",
            notes=("1D slice normal to the gate dielectric",
                   f"analytical MOS electrostatics: psi_s={st.surface_potential_V:.4f} V, "
                   f"V_stack={st.stack_voltage_V:.4f} V ({100 * st.fraction_across_stack:.1f}% of VG-phi_ms)",
                   *self.ASSUMPTIONS),
        )


def profile_from_potential(
    x_nm: np.ndarray,
    phi_V: np.ndarray,
    delta_ec_eV: np.ndarray,
    mass_rel: np.ndarray | float,
    *,
    phi_reference_V: float | None = None,
    energy_reference: str = "custom:Ec relative to the conduction-band edge at the first sample",
    label: str = "imported electrostatic potential",
) -> PotentialProfile:
    """Electron potential energy from an electrostatic potential profile.

    ``E_c(x) = -q [phi(x) - phi_ref] + Delta_Ec(x)`` in eV, where ``Delta_Ec``
    is the local conduction-band offset (0 in the reference semiconductor) and
    ``phi_ref`` defaults to ``phi(x[0])``. A sign error here (using +q phi) is
    the classic mistake; ``tests/devices`` guards against it.
    """
    x = np.asarray(x_nm, dtype=float)
    phi = np.asarray(phi_V, dtype=float)
    dec = np.broadcast_to(np.asarray(delta_ec_eV, dtype=float), x.shape)
    ref = phi[0] if phi_reference_V is None else phi_reference_V
    ec = -(phi - ref) + dec  # eV (q * V / q)
    return from_samples(x - x[0], ec, mass_rel, energy_reference=energy_reference, label=label,
                        notes=("electron potential energy E_c = -q(phi - phi_ref) + Delta_Ec",))


def load_devsim_export(path: str | Path, *, dielectric_offsets_eV: dict[str, float],
                       masses_rel: dict[str, float], region_order: list[str] | None = None) -> PotentialProfile:
    """Read DEVSIM node data exported as CSV (``x,Potential,region``) or JSON.

    DEVSIM reports ``x`` in cm by default and ``Potential`` in V; both are
    converted. Region names map to conduction-band offsets and tunnelling
    masses. Duplicate interface nodes (one per region) are averaged.
    """
    path = Path(path)
    if path.suffix == ".json":
        data = json.loads(path.read_text())
        rows = [(float(r["x"]), float(r["Potential"]), r["region"]) for r in data["nodes"]]
        x_unit = data.get("x_unit", "cm")
    else:
        rows, x_unit = [], "cm"
        for line in path.read_text().splitlines():
            if not line.strip() or line.startswith("#"):
                if "x_unit" in line:
                    x_unit = line.split(":", 1)[1].strip()
                continue
            if line.lower().startswith("x,"):
                continue
            a, b, c = line.split(",")
            rows.append((float(a), float(b), c.strip()))
    scale = {"cm": 1e7, "m": 1e9, "nm": 1.0, "um": 1e3}[x_unit]
    regions = region_order or list(dict.fromkeys(r[2] for r in rows))
    pts: dict[float, list] = {}
    for x, phi, reg in rows:
        if reg not in dielectric_offsets_eV:
            raise ValueError(f"region {reg!r} has no conduction-band offset supplied")
        pts.setdefault(round(x * scale, 9), []).append((phi, reg))
    xs = np.array(sorted(pts))
    phi = np.array([np.mean([p for p, _ in pts[x]]) for x in xs])
    reg = [max(pts[x], key=lambda pr: dielectric_offsets_eV[pr[1]])[1] for x in xs]
    dec = np.array([dielectric_offsets_eV[r] for r in reg])
    m = np.array([masses_rel[r] for r in reg])
    return profile_from_potential(xs, phi, dec, m, label=f"DEVSIM export {path.name}",
                                  energy_reference="custom:Ec relative to Si Ec at the first DEVSIM node")


def devsim_available() -> bool:
    try:
        import devsim  # noqa: F401
        return True
    except Exception:
        return False


__all__ = ["MOSCapacitor", "MOSState", "profile_from_potential", "load_devsim_export", "devsim_available"]
