"""Material parameters with explicit provenance.

Every number used by a device model is a :class:`Parameter` that records its
value, unit, provenance class, source and (where known) a literature range
used by the sensitivity analysis. Provenance classes follow the brief:

* ``literature``   -- taken from a cited publication or standard text;
* ``pdk``          -- from a process design kit (none are bundled; PDK data
                      is licence-restricted and must be supplied by the user);
* ``measured``     -- experimentally measured by the user;
* ``assumed``      -- an engineering assumption with no verified source here;
* ``hypothetical`` -- deliberately invented for a what-if study.

Nothing in this file is calibrated to a specific foundry process.

Notes on sources
----------------
* SiO2 / HfO2 permittivity, band gap and conduction-band offset to Si:
  J. Robertson, "High dielectric constant oxides", Eur. Phys. J. Appl. Phys.
  28, 265 (2004), Table 1 (SiO2: k=3.9, Eg=9 eV, CBO=3.2 eV; HfO2: k=25,
  Eg=5.8 eV, CBO=1.4 eV); see also J. Robertson, J. Vac. Sci. Technol. B 18,
  1785 (2000). The SiO2 nominal CBO used here is 3.1 eV, the value commonly
  used for Si/SiO2 tunnelling (internal photoemission ~3.1-3.15 eV); the range
  2.9-3.34 eV brackets values used in the literature. Reported HfO2 CBOs span
  roughly 1.4-2.0 eV.
* SiO2 electron tunnelling mass: 0.5 m0 from Fowler-Nordheim analysis
  (Z. A. Weinberg, J. Appl. Phys. 53, 5052 (1982)); direct-tunnelling
  extractions give 0.30 (parabolic) / 0.41 (non-parabolic) m0
  (B. Brar, G. D. Wilk, A. C. Seabaugh, Appl. Phys. Lett. 69, 2728 (1996)).
  Range 0.29-0.50 m0.
* HfO2 electron tunnelling mass: **assumed** (0.2 m0, range 0.1-0.4 m0). No
  verified source was available to this build; values in the literature vary
  widely. Replace with a measured value before drawing quantitative
  conclusions.
* Silicon: S. M. Sze and K. K. Ng, *Physics of Semiconductor Devices*, 3rd ed.
  (Wiley, 2007): eps_r=11.7, chi=4.05 eV, Eg=1.12 eV, n_i=9.65e9 cm^-3 (300 K).
* Silicon conduction-band mass for the 1D lead: **assumed** 0.26 m0
  (conductivity-mass average). Real Si(100) has valley-dependent normal masses
  0.916 m0 (Delta-2) and 0.19 m0 (Delta-4); the 1D model cannot represent that.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Provenance(str, Enum):
    LITERATURE = "literature"
    PDK = "pdk"
    MEASURED = "measured"
    ASSUMED = "assumed"
    HYPOTHETICAL = "hypothetical"


class Parameter(BaseModel):
    model_config = ConfigDict(frozen=True)

    value: float
    unit: str
    provenance: Provenance
    source: str
    range: tuple[float, float] | None = None
    note: str = ""

    @model_validator(mode="after")
    def _check_range(self):
        if self.range is not None:
            lo, hi = self.range
            if not lo <= self.value <= hi:
                raise ValueError(f"nominal value {self.value} outside its stated range {self.range}")
        return self

    def with_value(self, value: float, provenance: Provenance | None = None, source: str | None = None) -> "Parameter":
        return Parameter(value=value, unit=self.unit, provenance=provenance or self.provenance,
                         source=source or self.source, range=None if (self.range and not
                         self.range[0] <= value <= self.range[1]) else self.range, note=self.note)


ROBERTSON_2004 = "J. Robertson, Eur. Phys. J. Appl. Phys. 28, 265 (2004), Table 1"
SZE_NG_2007 = "S. M. Sze & K. K. Ng, Physics of Semiconductor Devices, 3rd ed. (2007)"


class DielectricMaterial(BaseModel):
    model_config = ConfigDict(frozen=True)

    name: str
    relative_permittivity: Parameter
    conduction_band_offset_eV: Parameter = Field(description="Conduction-band offset to the Si conduction band")
    tunnelling_mass_rel: Parameter
    bandgap_eV: Parameter | None = None

    @model_validator(mode="after")
    def _physical(self):
        if self.relative_permittivity.value < 1.0:
            raise ValueError("relative permittivity must be >= 1")
        if self.tunnelling_mass_rel.value <= 0:
            raise ValueError("tunnelling mass must be > 0")
        return self

    def electron_affinity_eV(self, si_affinity_eV: float) -> float:
        """Electron affinity implied by the CBO under the electron-affinity rule."""
        return si_affinity_eV - self.conduction_band_offset_eV.value


class Semiconductor(BaseModel):
    model_config = ConfigDict(frozen=True)

    name: str
    relative_permittivity: Parameter
    electron_affinity_eV: Parameter
    bandgap_eV: Parameter
    intrinsic_density_cm3: Parameter
    lead_mass_rel: Parameter


class ElectrodeKind(str, Enum):
    METAL = "metal"                  # 3D free-electron electrode
    DEGENERATE_3D = "degenerate_3d"  # degenerately doped semiconductor treated as 3D electron gas
    SEMICONDUCTOR_SURFACE = "semiconductor_surface"  # inversion/accumulation layer (quantised in reality)


class Electrode(BaseModel):
    model_config = ConfigDict(frozen=True)

    name: str
    kind: ElectrodeKind
    work_function_eV: Parameter
    fermi_energy_eV: Parameter = Field(description="Fermi level above the electrode band bottom")
    mass_rel: Parameter


SIO2 = DielectricMaterial(
    name="SiO2",
    relative_permittivity=Parameter(value=3.9, unit="1", provenance=Provenance.LITERATURE, source=ROBERTSON_2004),
    conduction_band_offset_eV=Parameter(
        value=3.1, unit="eV", provenance=Provenance.LITERATURE,
        source="Si/SiO2 internal photoemission ~3.1-3.15 eV; " + ROBERTSON_2004 + " lists 3.2 eV",
        range=(2.9, 3.34)),
    tunnelling_mass_rel=Parameter(
        value=0.5, unit="m0", provenance=Provenance.LITERATURE,
        source="Z. A. Weinberg, J. Appl. Phys. 53, 5052 (1982); range from B. Brar et al., APL 69, 2728 (1996)",
        range=(0.29, 0.5), note="parabolic dispersion assumed"),
    bandgap_eV=Parameter(value=9.0, unit="eV", provenance=Provenance.LITERATURE, source=ROBERTSON_2004),
)

HFO2 = DielectricMaterial(
    name="HfO2",
    relative_permittivity=Parameter(value=25.0, unit="1", provenance=Provenance.LITERATURE, source=ROBERTSON_2004,
                                    range=(16.0, 25.0), note="phase- and process-dependent"),
    conduction_band_offset_eV=Parameter(value=1.4, unit="eV", provenance=Provenance.LITERATURE,
                                        source=ROBERTSON_2004 + "; reported values span ~1.4-2.0 eV",
                                        range=(1.4, 2.0)),
    tunnelling_mass_rel=Parameter(value=0.2, unit="m0", provenance=Provenance.ASSUMED,
                                  source="engineering assumption -- no verified source in this build",
                                  range=(0.1, 0.4), note="replace with a measured value"),
    bandgap_eV=Parameter(value=5.8, unit="eV", provenance=Provenance.LITERATURE, source=ROBERTSON_2004),
)

SILICON = Semiconductor(
    name="Si",
    relative_permittivity=Parameter(value=11.7, unit="1", provenance=Provenance.LITERATURE, source=SZE_NG_2007),
    electron_affinity_eV=Parameter(value=4.05, unit="eV", provenance=Provenance.LITERATURE, source=SZE_NG_2007),
    bandgap_eV=Parameter(value=1.12, unit="eV", provenance=Provenance.LITERATURE, source=SZE_NG_2007 + " (300 K)"),
    intrinsic_density_cm3=Parameter(value=9.65e9, unit="cm^-3", provenance=Provenance.LITERATURE,
                                    source=SZE_NG_2007 + " (300 K)"),
    lead_mass_rel=Parameter(value=0.26, unit="m0", provenance=Provenance.ASSUMED,
                            source="conductivity-mass average; Si(100) normal masses are 0.916 / 0.19 m0",
                            range=(0.19, 0.916)),
)

GENERIC_METAL_GATE = Electrode(
    name="midgap metal gate (TiN-like)",
    kind=ElectrodeKind.METAL,
    work_function_eV=Parameter(value=4.5, unit="eV", provenance=Provenance.ASSUMED,
                               source="typical near-midgap metal-gate work function; process dependent",
                               range=(4.3, 4.8)),
    fermi_energy_eV=Parameter(value=5.5, unit="eV", provenance=Provenance.ASSUMED,
                              source="free-electron-metal assumption"),
    mass_rel=Parameter(value=1.0, unit="m0", provenance=Provenance.ASSUMED, source="free-electron metal"),
)

N_PLUS_POLY = Electrode(
    name="n+ poly-Si (degenerate, 3D approximation)",
    kind=ElectrodeKind.DEGENERATE_3D,
    work_function_eV=Parameter(value=4.05, unit="eV", provenance=Provenance.ASSUMED,
                               source="Fermi level at the Si conduction-band edge (degenerate n+)"),
    fermi_energy_eV=Parameter(value=0.05, unit="eV", provenance=Provenance.ASSUMED,
                              source="degenerate doping ~1e20 cm^-3, order-of-magnitude"),
    mass_rel=Parameter(value=0.26, unit="m0", provenance=Provenance.ASSUMED, source="see SILICON.lead_mass_rel"),
)

DIELECTRICS: dict[str, DielectricMaterial] = {"SiO2": SIO2, "HfO2": HFO2}
ELECTRODES: dict[str, Electrode] = {"metal": GENERIC_METAL_GATE, "n+poly": N_PLUS_POLY}


def hypothetical_dielectric(name: str, k: float, cbo_eV: float, mass_rel: float, note: str = "") -> DielectricMaterial:
    """Build a clearly-labelled hypothetical dielectric for what-if studies."""
    hyp = lambda v, u: Parameter(value=v, unit=u, provenance=Provenance.HYPOTHETICAL,
                                 source="user-defined hypothetical material", note=note)
    return DielectricMaterial(name=name, relative_permittivity=hyp(k, "1"),
                              conduction_band_offset_eV=hyp(cbo_eV, "eV"), tunnelling_mass_rel=hyp(mass_rel, "m0"))


def material_table() -> list[dict]:
    """Flat provenance table for reports."""
    rows = []
    for mat in DIELECTRICS.values():
        for field_name in ("relative_permittivity", "conduction_band_offset_eV", "tunnelling_mass_rel", "bandgap_eV"):
            p = getattr(mat, field_name)
            if p is None:
                continue
            rows.append({"material": mat.name, "parameter": field_name, "value": p.value, "unit": p.unit,
                         "provenance": p.provenance.value, "range": p.range, "source": p.source})
    for field_name in ("relative_permittivity", "electron_affinity_eV", "bandgap_eV", "intrinsic_density_cm3",
                       "lead_mass_rel"):
        p = getattr(SILICON, field_name)
        rows.append({"material": "Si", "parameter": field_name, "value": p.value, "unit": p.unit,
                     "provenance": p.provenance.value, "range": p.range, "source": p.source})
    for key, el in ELECTRODES.items():
        for field_name in ("work_function_eV", "fermi_energy_eV", "mass_rel"):
            p = getattr(el, field_name)
            rows.append({"material": el.name, "parameter": field_name, "value": p.value, "unit": p.unit,
                         "provenance": p.provenance.value, "range": p.range, "source": p.source})
    return rows


__all__ = [
    "Provenance", "Parameter", "DielectricMaterial", "Semiconductor", "ElectrodeKind", "Electrode",
    "SIO2", "HFO2", "SILICON", "GENERIC_METAL_GATE", "N_PLUS_POLY", "DIELECTRICS", "ELECTRODES",
    "hypothetical_dielectric", "material_table",
]
