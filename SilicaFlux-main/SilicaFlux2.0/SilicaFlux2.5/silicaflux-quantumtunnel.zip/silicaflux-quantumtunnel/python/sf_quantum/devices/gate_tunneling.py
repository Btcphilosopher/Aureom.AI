"""Direct gate-dielectric tunnelling research models.

Two clearly separated deliverables:

* **Transmission** through a gate stack (any electrostatics source): the
  electron travels from the Si conduction band (left lead) through the
  dielectric layers to the gate (right lead). Barrier energies come from the
  stack's conduction-band offsets -- never from the silicon band gap.
* **Gate-current density** via Tsu-Esaki, *only* for junctions between 3D
  free-electron-like electrodes (metal / degenerate n+ poly treated as 3D).
  This is a research model validated against the analytical FN limit; it is
  not a calibrated MOSFET gate-leakage predictor. Si inversion/accumulation
  emitters are refused.

Gate leakage computed here is *gate tunnelling only*. It is never added to
subthreshold, junction, band-to-band or trap-assisted leakage -- none of those
mechanisms is implemented in this package.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..models.current import UnsupportedModelError, tsu_esaki_current_density
from ..quantum import scattering, wkb
from ..quantum.barriers import Layer, Lead, PotentialProfile
from ..quantum.constants import Q_E
from ..quantum.units import effective_mass_kg, eV_to_J, nm_to_m
from .dielectric_stack import DielectricStack
from .materials import SILICON, Electrode, ElectrodeKind

NOT_MODELLED_LEAKAGE = (
    "subthreshold channel current",
    "junction leakage",
    "band-to-band tunnelling",
    "trap-assisted tunnelling",
    "gate-induced drain leakage",
)


def stack_transmission(profile: PotentialProfile, energies_eV: np.ndarray, *, max_slice_m: float = 0.005e-9) -> dict:
    """WKB and scattering transmission through a stack profile at given energies."""
    E = np.asarray(energies_eV, dtype=float) * Q_E
    sc = scattering.transmission(profile, E, max_slice_m=max_slice_m)
    wk = wkb.wkb_spectrum(profile, E)
    return {
        "energy_eV": np.asarray(energies_eV, dtype=float),
        "T_scattering": sc.transmission,
        "logT_scattering": sc.log_transmission,
        "T_wkb": wk["transmission"],
        "logT_wkb": wk["log_transmission"],
        "wkb_above_barrier": wk["above_barrier"],
        "conservation_error_max": float(sc.conservation_error.max()),
        "profile": profile.to_dict(),
    }


def junction_profile(stack: DielectricStack, bias_V: float, emitter: Electrode, collector: Electrode,
                     *, drops_V: np.ndarray | None = None) -> PotentialProfile:
    """Electrode / stack / electrode profile referenced to the emitter Fermi level.

    Barrier height of layer i at the emitter side: ``phi_em - chi_i`` with
    ``chi_i = chi_Si - CBO_i`` (electron-affinity rule). The collector Fermi
    level sits at ``-q bias``. Unless ``drops_V`` is given the bias is
    partitioned across the stack by its permittivities (no interface charge),
    i.e. the electrodes are ideal metals with no band bending.
    """
    chi_si = SILICON.electron_affinity_eV.value
    if drops_V is None:
        drops_V = stack.partition(bias_V)["voltage_drops_V"]
    layers, cum = [], 0.0
    phi_e = emitter.work_function_eV.value
    for l, dv in zip(stack.layers, drops_V):
        chi = l.material.electron_affinity_eV(chi_si)
        top = phi_e - chi
        v1 = top - cum
        cum += dv
        layers.append(Layer(nm_to_m(l.thickness_nm), eV_to_J(v1), eV_to_J(top - cum),
                            effective_mass_kg(l.material.tunnelling_mass_rel.value), l.material.name, l.material.name))
    # contact potential: collector Fermi level at -q*bias; vacuum-level step from work-function difference
    # is absorbed into the requirement that sum(drops) + (phi_c - phi_e) = bias for real electrodes.
    left = Lead(eV_to_J(-emitter.fermi_energy_eV.value), effective_mass_kg(emitter.mass_rel.value), emitter.name)
    right = Lead(eV_to_J(-bias_V - collector.fermi_energy_eV.value), effective_mass_kg(collector.mass_rel.value),
                 collector.name)
    return PotentialProfile(tuple(layers), left, right, "left_fermi_level",
                            f"{emitter.name} / {stack.describe()} / {collector.name} @ {bias_V:g} V",
                            notes=("planar junction between 3D electrodes; energy zero = emitter Fermi level",),
                            metadata={"bias_V": bias_V, "stack": stack.summary()})


@dataclass(frozen=True)
class GateCurrentResult:
    bias_V: float
    J_A_per_m2: float
    J_A_per_cm2: float
    current_A: float | None
    power_W: float | None
    temperature_K: float
    model: str
    method: str
    validity: tuple[str, ...]
    not_modelled: tuple[str, ...] = NOT_MODELLED_LEAKAGE
    extras: dict = field(default_factory=dict)


def gate_current_density(
    stack: DielectricStack,
    bias_V: float,
    *,
    emitter: Electrode,
    collector: Electrode,
    temperature_K: float = 300.0,
    method: str = "scattering",
    area_m2: float | None = None,
    n_energy: int = 3000,
    max_slice_m: float = 0.01e-9,
) -> GateCurrentResult:
    """Tsu-Esaki gate-tunnelling current density for a 3D-electrode junction.

    Refuses semiconductor-surface (inversion/accumulation) emitters. Power is
    the electrical power delivered by the bias source to this tunnelling
    current, ``P = I * V``, for the specified bias only.
    """
    kinds = (emitter.kind.value, collector.kind.value)
    if ElectrodeKind.SEMICONDUCTOR_SURFACE.value in kinds:
        raise UnsupportedModelError(
            "gate-current density from a Si inversion/accumulation layer needs 2D subband supply "
            "functions; not implemented. Use stack_transmission() for transmission-only analysis."
        )
    prof = junction_profile(stack, bias_V, emitter, collector)
    if method == "scattering":
        tfun = lambda E: scattering.transmission(prof, E, max_slice_m=max_slice_m).transmission
    elif method == "wkb":
        tfun = lambda E: np.nan_to_num(np.exp(-2.0 * wkb.wkb_action_array(prof, E)), nan=0.0) * (E > prof.right.potential_J)
    else:
        raise ValueError("method must be 'scattering' or 'wkb'")
    res = tsu_esaki_current_density(
        tfun, emitter_band_bottom_J=prof.left.potential_J, mu_left_J=0.0, mu_right_J=-bias_V * Q_E,
        temperature_K=temperature_K, transverse_mass_rel=emitter.mass_rel.value, electrode_kinds=kinds,
        n_energy=n_energy)
    J = res["J_A_per_m2"]
    I = J * area_m2 if area_m2 is not None else None
    P = I * bias_V if I is not None else None
    validity = [
        "research model: Tsu-Esaki, 3D free-electron electrodes, transverse momentum conserved",
        "transmission evaluated at normal energy only (transverse-mass mismatch neglected)",
        "no image-force lowering, no traps, no interface dipoles",
        "validated against the analytical Fowler-Nordheim limit; NOT calibrated to measured devices",
    ]
    if any(l.material.tunnelling_mass_rel.value != emitter.mass_rel.value for l in stack.layers):
        validity.append("emitter mass differs from barrier mass: k_t-conservation coupling ignored")
    return GateCurrentResult(bias_V, J, res["J_A_per_cm2"], I, P, temperature_K, res["model"], method,
                             tuple(validity), extras={"profile": prof.to_dict(), "energy_points": res["energy_grid_points"]})


__all__ = ["stack_transmission", "junction_profile", "gate_current_density", "GateCurrentResult",
           "NOT_MODELLED_LEAKAGE"]
