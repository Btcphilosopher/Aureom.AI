r"""Multilayer gate-dielectric stacks, EOT and electrostatic field partitioning.

Electrostatics (no free carriers inside the dielectrics)
-------------------------------------------------------
The normal component of the displacement field D is continuous across a
dielectric interface unless a sheet charge sits on it. With D pointing from
the gate towards the substrate and magnitude ``D_0`` in the layer next to the
substrate,

.. math:: D_{i+1} = D_i - \sigma_i ,\qquad F_i = \frac{D_i}{\varepsilon_0\varepsilon_{r,i}},
          \qquad V_\mathrm{stack} = \sum_i F_i t_i .

With no interface charge this is the series-capacitor result: the field is
*not* equal in layers of different permittivity; it scales as
:math:`1/\varepsilon_{r,i}`.

EOT and capacitance
-------------------
.. math:: \mathrm{EOT} = \sum_i t_i\,\frac{3.9}{\varepsilon_{r,i}},\qquad
          C_\mathrm{stack} = \frac{3.9\,\varepsilon_0}{\mathrm{EOT}}

(ideal: no quantum-capacitance, polysilicon-depletion or inversion-centroid
corrections; those belong to the full MOS electrostatics in
:mod:`.electrostatics`).

Four distinct quantities are kept apart throughout: *physical thickness*,
*EOT*, *electrical (tunnelling) barrier thickness at a given energy* and
*transmission probability*.
"""

from __future__ import annotations

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, field_validator

from ..quantum.barriers import Layer, Lead, PotentialProfile
from ..quantum.constants import EPS_0, Q_E
from ..quantum.units import effective_mass_kg, eV_to_J, nm_to_m
from .materials import SILICON, DielectricMaterial

K_SIO2_REFERENCE = 3.9


class DielectricLayer(BaseModel):
    model_config = ConfigDict(frozen=True)

    material: DielectricMaterial
    thickness_nm: float = Field(gt=0)

    @property
    def eot_nm(self) -> float:
        return self.thickness_nm * K_SIO2_REFERENCE / self.material.relative_permittivity.value


class DielectricStack(BaseModel):
    """Layers ordered from the substrate (left) to the gate (right)."""

    model_config = ConfigDict(frozen=True)

    name: str = "stack"
    layers: tuple[DielectricLayer, ...]
    interface_charges_C_per_m2: tuple[float, ...] = ()

    @field_validator("layers")
    @classmethod
    def _non_empty(cls, v):
        if len(v) == 0:
            raise ValueError("a dielectric stack needs at least one layer")
        return v

    def model_post_init(self, __context) -> None:
        if self.interface_charges_C_per_m2 and len(self.interface_charges_C_per_m2) != len(self.layers) - 1:
            raise ValueError("interface_charges must have one entry per internal dielectric interface")

    # ----------------------------------------------------------------- metrics
    @property
    def physical_thickness_nm(self) -> float:
        return float(sum(l.thickness_nm for l in self.layers))

    @property
    def eot_nm(self) -> float:
        return float(sum(l.eot_nm for l in self.layers))

    @property
    def capacitance_F_per_m2(self) -> float:
        return K_SIO2_REFERENCE * EPS_0 / nm_to_m(self.eot_nm)

    def _sigma(self) -> np.ndarray:
        return np.asarray(self.interface_charges_C_per_m2 or [0.0] * (len(self.layers) - 1), dtype=float)

    def displacement_from_d0(self, d0: float) -> np.ndarray:
        """Per-layer |D| [C/m^2] given D in the substrate-side layer."""
        sig = self._sigma()
        return np.concatenate([[d0], d0 - np.cumsum(sig)])

    def voltage_from_d0(self, d0: float) -> float:
        d = self.displacement_from_d0(d0)
        return float(sum(di / (EPS_0 * l.material.relative_permittivity.value) * nm_to_m(l.thickness_nm)
                         for di, l in zip(d, self.layers)))

    def partition(self, v_stack: float) -> dict:
        """Fields and voltage drops for a total voltage ``v_stack`` across the stack."""
        # V is affine in d0: V = a d0 + b
        b = self.voltage_from_d0(0.0)
        a = self.voltage_from_d0(1.0) - b
        d0 = (v_stack - b) / a
        d = self.displacement_from_d0(d0)
        fields = np.array([di / (EPS_0 * l.material.relative_permittivity.value) for di, l in zip(d, self.layers)])
        drops = fields * np.array([nm_to_m(l.thickness_nm) for l in self.layers])
        return {
            "displacement_C_per_m2": d,
            "fields_V_per_m": fields,
            "fields_MV_per_cm": fields / 1e8,
            "voltage_drops_V": drops,
            "gate_charge_C_per_m2": float(d[-1]),
        }

    def eot_field_V_per_m(self, v_stack: float) -> float:
        """Field an SiO2 film of thickness EOT would carry at the same voltage (no interface charge)."""
        return v_stack / nm_to_m(self.eot_nm)

    # ----------------------------------------------------------------- barrier
    def barrier_profile(
        self,
        drops_V: np.ndarray,
        *,
        left_lead_potential_eV: float = 0.0,
        left_lead_mass: float = SILICON.lead_mass_rel.value,
        right_lead_potential_eV: float | None = None,
        right_lead_mass: float = 1.0,
        energy_reference: str = "si_conduction_band_edge",
        label: str | None = None,
        notes: tuple[str, ...] = (),
    ) -> PotentialProfile:
        """Conduction-band-edge profile for given per-layer voltage drops.

        Layer i starts at its conduction-band offset minus the cumulative
        electron potential-energy drop ``q * sum(drops[:i])`` (electron-affinity
        rule; interface dipoles not modelled). Default right lead: flat at the
        energy reached at the gate side of the stack (a *simplified* electrode;
        pass ``right_lead_potential_eV`` for a physical gate electrode).
        """
        drops = np.asarray(drops_V, dtype=float)
        if drops.shape != (len(self.layers),):
            raise ValueError("need one voltage drop per layer")
        layers = []
        cum = 0.0
        for l, dv in zip(self.layers, drops):
            cbo = l.material.conduction_band_offset_eV.value
            v1 = left_lead_potential_eV + cbo - cum
            cum += dv
            v2 = left_lead_potential_eV + cbo - cum
            layers.append(Layer(nm_to_m(l.thickness_nm), eV_to_J(v1), eV_to_J(v2),
                                effective_mass_kg(l.material.tunnelling_mass_rel.value), l.material.name,
                                l.material.name))
        vr = left_lead_potential_eV - cum if right_lead_potential_eV is None else right_lead_potential_eV
        return PotentialProfile(
            tuple(layers),
            Lead(eV_to_J(left_lead_potential_eV), effective_mass_kg(left_lead_mass), "substrate"),
            Lead(eV_to_J(vr), effective_mass_kg(right_lead_mass), "gate"),
            energy_reference,
            label or f"{self.name} ({self.describe()})",
            notes=tuple(notes),
            metadata={"stack": self.summary(), "voltage_drops_V": drops.tolist()},
        )

    def simplified_profile(self, v_stack: float, **kw) -> PotentialProfile:
        """SIMPLIFIED voltage-drop model: the given ``v_stack`` is entirely across the stack.

        The caller asserts the stack voltage; substrate band bending,
        depletion/inversion charge and work-function differences are *not*
        computed here (use :class:`~sf_quantum.devices.electrostatics.MOSCapacitor`).
        """
        part = self.partition(v_stack)
        notes = kw.pop("notes", ()) + (
            "SIMPLIFIED voltage-drop model: stack voltage supplied directly; no substrate band bending, "
            "depletion/inversion charge or work-function difference computed",)
        return self.barrier_profile(part["voltage_drops_V"], notes=notes, **kw)

    # ----------------------------------------------------------------- report
    def describe(self) -> str:
        return " / ".join(f"{l.material.name} {l.thickness_nm:g} nm" for l in self.layers)

    def summary(self) -> dict:
        return {
            "name": self.name,
            "layers": [{"material": l.material.name, "thickness_nm": l.thickness_nm,
                        "k": l.material.relative_permittivity.value,
                        "cbo_eV": l.material.conduction_band_offset_eV.value,
                        "mass_rel": l.material.tunnelling_mass_rel.value,
                        "provenance": {
                            "k": l.material.relative_permittivity.provenance.value,
                            "cbo": l.material.conduction_band_offset_eV.provenance.value,
                            "mass": l.material.tunnelling_mass_rel.provenance.value}} for l in self.layers],
            "physical_thickness_nm": self.physical_thickness_nm,
            "eot_nm": self.eot_nm,
            "capacitance_uF_per_cm2": self.capacitance_F_per_m2 * 100.0,
            "interface_charges_C_per_m2": list(self.interface_charges_C_per_m2),
        }


def single_layer(material: DielectricMaterial, thickness_nm: float, name: str | None = None) -> DielectricStack:
    return DielectricStack(name=name or f"{material.name} {thickness_nm:g} nm",
                           layers=(DielectricLayer(material=material, thickness_nm=thickness_nm),))


def high_k_thickness_for_eot(target_eot_nm: float, high_k: DielectricMaterial,
                             interfacial: list[DielectricLayer] = ()) -> float:
    """Physical high-k thickness giving ``target_eot_nm`` on top of the interfacial layers."""
    il = sum(l.eot_nm for l in interfacial)
    remaining = target_eot_nm - il
    if remaining <= 0:
        raise ValueError(f"interfacial layers alone already have EOT {il:.3f} nm >= target {target_eot_nm} nm")
    return remaining * high_k.relative_permittivity.value / K_SIO2_REFERENCE


def matched_eot_stack(target_eot_nm: float, high_k: DielectricMaterial, il_material: DielectricMaterial,
                      il_thickness_nm: float, name: str | None = None) -> DielectricStack:
    il = DielectricLayer(material=il_material, thickness_nm=il_thickness_nm)
    t_hk = high_k_thickness_for_eot(target_eot_nm, high_k, [il])
    return DielectricStack(name=name or f"{il_material.name} {il_thickness_nm:g} / {high_k.name} {t_hk:.3g} nm",
                           layers=(il, DielectricLayer(material=high_k, thickness_nm=t_hk)))


__all__ = ["K_SIO2_REFERENCE", "DielectricLayer", "DielectricStack", "single_layer",
           "high_k_thickness_for_eot", "matched_eot_stack"]
