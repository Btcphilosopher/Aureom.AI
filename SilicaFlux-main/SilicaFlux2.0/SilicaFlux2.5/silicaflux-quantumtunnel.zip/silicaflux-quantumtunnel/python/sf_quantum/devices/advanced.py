"""Extensible interfaces for advanced transistor architectures (1D slices only).

Every architecture here produces a **one-dimensional** tunnelling cut normal to
a gate-dielectric surface. The profiles are labelled as such; nothing in this
module computes 3D electrostatics, quantum confinement in fins/sheets,
atomistic transport or calibrated device behaviour. A future 2D/3D field
solver (or TransistorLab/DEVSIM data) plugs in through ``potential_source``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Protocol

from ..quantum.barriers import PotentialProfile, replace
from .dielectric_stack import DielectricStack

DIMENSIONALITY = "1D slice"


class PotentialSource(Protocol):
    def __call__(self, stack: DielectricStack, bias_V: float) -> PotentialProfile: ...


def simplified_source(stack: DielectricStack, bias_V: float) -> PotentialProfile:
    return stack.simplified_profile(bias_V)


@dataclass
class DeviceSlice:
    """Base class: a named location on a device where a 1D cut is taken."""

    architecture: str
    location: str
    stack: DielectricStack
    potential_source: Callable[[DielectricStack, float], PotentialProfile] = simplified_source
    geometry: dict = field(default_factory=dict)
    caveats: tuple[str, ...] = ()

    def profile(self, bias_V: float) -> PotentialProfile:
        p = self.potential_source(self.stack, bias_V)
        notes = p.notes + (
            f"{DIMENSIONALITY} of a {self.architecture} at '{self.location}'",
            "no 3D electrostatics, confinement, corner fields or atomistic effects are represented",
            *self.caveats,
        )
        return replace(p, dimensionality=DIMENSIONALITY, notes=notes,
                       label=f"{self.architecture} [{self.location}] {p.label}",
                       metadata={**p.metadata, "architecture": self.architecture, "geometry": self.geometry})


def planar_mosfet(stack: DielectricStack, **geom) -> DeviceSlice:
    return DeviceSlice("planar MOSFET", "channel centre, normal to gate", stack, geometry=geom)


def finfet_sidewall(stack: DielectricStack, fin_width_nm: float, fin_height_nm: float, **kw) -> DeviceSlice:
    return DeviceSlice("FinFET", "fin sidewall mid-height, normal to the sidewall", stack,
                       geometry={"fin_width_nm": fin_width_nm, "fin_height_nm": fin_height_nm},
                       caveats=("fin corners concentrate field; a sidewall cut underestimates corner tunnelling",), **kw)


def gaa_nanosheet(stack: DielectricStack, sheet_width_nm: float, sheet_thickness_nm: float, **kw) -> DeviceSlice:
    return DeviceSlice("gate-all-around nanosheet", "sheet top surface centre", stack,
                       geometry={"sheet_width_nm": sheet_width_nm, "sheet_thickness_nm": sheet_thickness_nm},
                       caveats=("sheet thickness quantisation shifts the emitter subband; not modelled",), **kw)


def stacked_transistor_concept(stack: DielectricStack, tiers: int, **kw) -> DeviceSlice:
    return DeviceSlice("stacked (CFET-like) research concept", "single tier gate dielectric", stack,
                       geometry={"tiers": tiers},
                       caveats=("inter-tier coupling and shared-gate electrostatics are not represented",), **kw)


__all__ = ["DIMENSIONALITY", "DeviceSlice", "planar_mosfet", "finfet_sidewall", "gaa_nanosheet",
           "stacked_transistor_concept", "simplified_source"]
