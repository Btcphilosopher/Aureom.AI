r"""Fowler-Nordheim (FN) tunnelling research module.

Model (Lenzlinger & Snow form, free-electron emitter, T = 0)
------------------------------------------------------------
.. math::

   J_\mathrm{FN} = A F^2 \exp(-B/F),\qquad
   A = \frac{q^3}{16\pi^2\hbar\,\phi_B}\,\frac{m_e}{m_\mathrm{ox}},\qquad
   B = \frac{4\sqrt{2m_\mathrm{ox}}\,\phi_B^{3/2}}{3\hbar q}

with :math:`\phi_B` the emitter-Fermi-level-to-barrier height, :math:`m_e`
the emitter (supply) mass and :math:`m_\mathrm{ox}` the barrier tunnelling
mass. The exponent is the WKB action of the *triangular* barrier seen by an
electron at the emitter Fermi level; the prefactor comes from integrating the
3D Fermi-sea supply with the transmission linearised about the Fermi level
(see :func:`sf_quantum.models.current.tsu_esaki_current_density`, which
reproduces this limit numerically -- ``tests/devices/test_fn_and_current.py``).

Validity (enforced)
-------------------
* The barrier at the Fermi level must actually be triangular:
  :math:`qF t_\mathrm{ox} \ge \phi_B`. For thinner/lower-field oxides the
  barrier is trapezoidal (direct tunnelling) and :func:`current_density`
  raises :class:`FNRegimeError` unless ``allow_outside_regime=True`` (used only
  for labelled comparison plots).
* No image-force lowering, parabolic band in the oxide, emitter is a 3D
  degenerate electron gas, temperature correction only through
  :func:`temperature_factor` (valid for :math:`c k T < 1`).
"""

from __future__ import annotations

import numpy as np

from ..quantum.constants import HBAR, K_B, M_E, Q_E


class FNRegimeError(ValueError):
    """Raised when the FN formula is applied outside its regime of validity."""


def exponent_B(phi_B_eV: float, m_ox_rel: float) -> float:
    """B [V/m]."""
    phi = phi_B_eV * Q_E
    return 4.0 * np.sqrt(2.0 * m_ox_rel * M_E) * phi**1.5 / (3.0 * HBAR * Q_E)


def prefactor_A(phi_B_eV: float, m_ox_rel: float, m_emitter_rel: float = 1.0) -> float:
    """A [A/V^2]."""
    phi = phi_B_eV * Q_E
    return Q_E**3 / (16.0 * np.pi**2 * HBAR * phi) * (m_emitter_rel / m_ox_rel)


def regime(field_V_per_m: np.ndarray | float, thickness_m: float, phi_B_eV: float) -> np.ndarray:
    """'fowler-nordheim' where qF t >= phi_B (triangular at E_F), else 'direct'."""
    f = np.atleast_1d(np.asarray(field_V_per_m, dtype=float))
    return np.where(f * thickness_m >= phi_B_eV, "fowler-nordheim", "direct")


def current_density(
    field_V_per_m: np.ndarray | float,
    phi_B_eV: float,
    m_ox_rel: float,
    *,
    thickness_m: float,
    m_emitter_rel: float = 1.0,
    temperature_K: float = 0.0,
    allow_outside_regime: bool = False,
) -> dict:
    """FN current density [A/m^2] with explicit validity reporting."""
    f = np.atleast_1d(np.asarray(field_V_per_m, dtype=float))
    if np.any(f <= 0):
        raise ValueError("field must be > 0")
    reg = regime(f, thickness_m, phi_B_eV)
    outside = reg != "fowler-nordheim"
    if np.any(outside) and not allow_outside_regime:
        raise FNRegimeError(
            f"qF*t_ox < phi_B for {int(outside.sum())} field point(s): the barrier at the Fermi level is "
            "trapezoidal (direct tunnelling). The FN formula does not apply; use the direct-tunnelling "
            "transmission/current models, or pass allow_outside_regime=True for a labelled comparison."
        )
    A = prefactor_A(phi_B_eV, m_ox_rel, m_emitter_rel)
    B = exponent_B(phi_B_eV, m_ox_rel)
    with np.errstate(under="ignore"):
        j0 = A * f**2 * np.exp(-B / f)
    if temperature_K > 0:
        ckt = c_parameter(f, phi_B_eV, m_ox_rel) * K_B * temperature_K
        bad_t = ckt >= 1.0
        if np.any(bad_t) and not allow_outside_regime:
            raise FNRegimeError("c kT >= 1: the linearised finite-temperature FN expansion diverges")
        tf = np.full_like(f, np.nan)
        tf[~bad_t] = temperature_factor(f[~bad_t], phi_B_eV, m_ox_rel, temperature_K)
        outside = outside | bad_t
    else:
        tf = np.ones_like(f)
    return {"J_A_per_m2": j0 * tf, "J0_A_per_m2": j0, "log_J0": np.log(A) + 2 * np.log(f) - B / f,
            "temperature_factor": tf, "regime": reg, "outside_validity": outside, "A": A, "B": B}


def c_parameter(field_V_per_m: np.ndarray | float, phi_B_eV: float, m_ox_rel: float) -> np.ndarray:
    """c = d(-ln D)/dE at the Fermi level = 2 sqrt(2 m_ox phi_B) / (hbar q F)  [1/J]."""
    f = np.asarray(field_V_per_m, dtype=float)
    return 2.0 * np.sqrt(2.0 * m_ox_rel * M_E * phi_B_eV * Q_E) / (HBAR * Q_E * f)


def temperature_factor(field_V_per_m, phi_B_eV, m_ox_rel, temperature_K) -> np.ndarray:
    """Finite-temperature FN enhancement pi c kT / sin(pi c kT) (requires c kT < 1)."""
    ckt = c_parameter(field_V_per_m, phi_B_eV, m_ox_rel) * K_B * temperature_K
    if np.any(ckt >= 1.0):
        raise FNRegimeError("c kT >= 1: the linearised finite-temperature FN expansion diverges")
    x = np.pi * ckt
    return np.where(x > 0, x / np.sin(np.where(x > 0, x, 1.0)), 1.0)


def triangular_log_transmission(energy_below_barrier_eV: np.ndarray | float, field_V_per_m: float,
                                m_ox_rel: float) -> np.ndarray:
    """WKB ln D for a triangular barrier of height ``phi - E`` above the electron."""
    u = np.asarray(energy_below_barrier_eV, dtype=float) * Q_E
    return -4.0 * np.sqrt(2.0 * m_ox_rel * M_E) * u**1.5 / (3.0 * HBAR * Q_E * field_V_per_m)


def fn_plot_coordinates(field_V_per_m: np.ndarray, J_A_per_m2: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """(1/F, ln(J/F^2)): a straight line of slope -B in the FN regime."""
    f = np.asarray(field_V_per_m, dtype=float)
    return 1.0 / f, np.log(np.asarray(J_A_per_m2) / f**2)


__all__ = ["FNRegimeError", "exponent_B", "prefactor_A", "regime", "current_density", "c_parameter",
           "temperature_factor", "triangular_log_transmission", "fn_plot_coordinates"]
