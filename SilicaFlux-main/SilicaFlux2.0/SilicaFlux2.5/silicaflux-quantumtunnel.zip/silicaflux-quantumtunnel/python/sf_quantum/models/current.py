r"""Current models with explicit dimensionality and validity.

1. :func:`landauer_current_1d` -- coherent **one-dimensional** channel:

   .. math:: I = \frac{q}{h}\,g_s\,M\int T(E)\,[f_L(E)-f_R(E)]\,dE

   with spin degeneracy :math:`g_s` and an explicit conducting-mode count
   :math:`M`. This is a current in amperes for a defined 1D channel. It is
   **not** a MOS gate-current density.

2. :func:`tsu_esaki_current_density` -- planar tunnel junction between two
   **3D free-electron-like electrodes** (metal, or a degenerate
   semiconductor treated as a 3D electron gas). Transverse momentum is
   conserved, bands are parabolic and isotropic with transverse mass
   :math:`m_t` in the emitter, and the transmission depends only on the
   normal energy :math:`E_z`:

   .. math:: J = \frac{q\,m_t\,k_BT}{2\pi^2\hbar^3}\int T(E_z)\,
             \ln\frac{1+e^{(\mu_L-E_z)/k_BT}}{1+e^{(\mu_R-E_z)/k_BT}}\,dE_z

   Its requirements -- carrier supply function, transverse-mode integration,
   electrode states, planar geometry -- are satisfied *only* for those
   electrode types. An inversion or accumulation layer is a quantised 2D
   system and is refused (:class:`UnsupportedModelError`).
   Validation: reproduces the analytical Fowler-Nordheim current, including
   its finite-temperature factor, in the FN regime.
"""

from __future__ import annotations

from typing import Callable

import numpy as np
from scipy.special import expit

from ..quantum.constants import H_PLANCK, HBAR, K_B, M_E, Q_E


class UnsupportedModelError(ValueError):
    """The requested current model's physical requirements are not met."""


def fermi_dirac(E_J: np.ndarray, mu_J: float, temperature_K: float) -> np.ndarray:
    """Fermi-Dirac occupation, overflow-safe; T = 0 gives a step (1/2 at E = mu)."""
    E = np.asarray(E_J, dtype=float)
    if temperature_K < 0:
        raise ValueError("temperature must be >= 0")
    if temperature_K == 0:
        return np.where(E < mu_J, 1.0, np.where(E > mu_J, 0.0, 0.5))
    return expit(-(E - mu_J) / (K_B * temperature_K))


def landauer_current_1d(
    energies_J: np.ndarray,
    transmission: np.ndarray,
    mu_left_J: float,
    mu_right_J: float,
    temperature_K: float,
    *,
    spin_degeneracy: int = 2,
    modes: int = 1,
) -> dict:
    """Coherent 1D Landauer current [A] (trapezoidal quadrature on the given grid)."""
    if spin_degeneracy not in (1, 2):
        raise ValueError("spin_degeneracy must be 1 or 2")
    if modes < 1:
        raise ValueError("modes must be >= 1")
    E = np.asarray(energies_J, dtype=float)
    T = np.asarray(transmission, dtype=float)
    if E.shape != T.shape or E.ndim != 1 or np.any(np.diff(E) <= 0):
        raise ValueError("need strictly increasing 1D energy grid matching the transmission array")
    window = fermi_dirac(E, mu_left_J, temperature_K) - fermi_dirac(E, mu_right_J, temperature_K)
    integrand = T * window
    I = Q_E / H_PLANCK * spin_degeneracy * modes * np.trapezoid(integrand, E)
    return {"current_A": float(I), "model": "Landauer 1D coherent channel",
            "spin_degeneracy": spin_degeneracy, "modes": modes, "temperature_K": temperature_K,
            "note": "current of an explicitly one-dimensional channel; not a MOS gate-current density"}


def conductance_quantum() -> float:
    """2 q^2 / h [S]."""
    return 2.0 * Q_E**2 / H_PLANCK


def _supply(E: np.ndarray, mu: float, temperature_K: float) -> np.ndarray:
    """k T ln(1 + exp((mu - E)/kT)) [J], T = 0 limit max(mu - E, 0)."""
    if temperature_K == 0:
        return np.clip(mu - E, 0.0, None)
    kt = K_B * temperature_K
    return kt * np.logaddexp(0.0, (mu - E) / kt)


def tsu_esaki_current_density(
    transmission_fn: Callable[[np.ndarray], np.ndarray],
    *,
    emitter_band_bottom_J: float,
    mu_left_J: float,
    mu_right_J: float,
    temperature_K: float,
    transverse_mass_rel: float,
    electrode_kinds: tuple[str, str],
    n_energy: int = 4000,
    window_kT: float = 40.0,
    e_max_J: float | None = None,
) -> dict:
    """Tsu-Esaki current density [A/m^2] for a planar junction between 3D electrodes.

    ``transmission_fn(E_z)`` must return the flux transmission at normal
    energy ``E_z`` (J, same scale as the chemical potentials).
    """
    allowed = {"metal", "degenerate_3d"}
    if any(k not in allowed for k in electrode_kinds):
        raise UnsupportedModelError(
            "Tsu-Esaki gate-current density requires 3D free-electron-like electrodes on both sides "
            f"(got {electrode_kinds}). Inversion/accumulation layers are quantised 2D systems with "
            "different supply functions; only transmission outputs are provided for them."
        )
    if transverse_mass_rel <= 0:
        raise ValueError("transverse mass must be > 0")
    kt = K_B * max(temperature_K, 1e-3)
    mu_hi = max(mu_left_J, mu_right_J)
    e_lo = emitter_band_bottom_J
    e_hi = e_max_J if e_max_J is not None else mu_hi + window_kT * kt + 0.05 * Q_E
    if e_hi <= e_lo:
        raise ValueError("empty energy window")
    # dense near the Fermi levels where the integrand peaks, coarser deep in the Fermi sea
    E = np.unique(np.concatenate([
        np.linspace(e_lo, e_hi, n_energy),
        np.linspace(max(e_lo, mu_hi - 1.0 * Q_E), e_hi, n_energy),
    ]))
    E = E[E > e_lo]
    T = np.asarray(transmission_fn(E), dtype=float)
    supply = _supply(E, mu_left_J, temperature_K) - _supply(E, mu_right_J, temperature_K)
    pref = Q_E * transverse_mass_rel * M_E / (2.0 * np.pi**2 * HBAR**3)
    J = pref * np.trapezoid(T * supply, E)
    return {"J_A_per_m2": float(J), "J_A_per_cm2": float(J) * 1e-4, "energy_grid_points": int(E.size),
            "model": "Tsu-Esaki planar junction, 3D free-electron electrodes, k_t conserved, T(E_z) only",
            "temperature_K": temperature_K, "transverse_mass_rel": transverse_mass_rel}


__all__ = ["UnsupportedModelError", "fermi_dirac", "landauer_current_1d", "conductance_quantum",
           "tsu_esaki_current_density"]
