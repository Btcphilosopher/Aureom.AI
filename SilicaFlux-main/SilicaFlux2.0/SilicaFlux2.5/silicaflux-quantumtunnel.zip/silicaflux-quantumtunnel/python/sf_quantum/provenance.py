"""Experiment provenance and storage (JSON metadata + HDF5 arrays + CSV tables).

Every saved experiment records: input parameters, constants provenance
(CODATA release), model assumptions, material-property sources and
provenance classes, solver settings, grid resolution, git revision (or an
explicit statement that none exists) plus a SHA-256 hash of the source tree,
numerical results, RTL configuration, testbench seed and validation outcome.

Parameter provenance classes: literature / pdk / measured / assumed /
hypothetical (see :mod:`sf_quantum.devices.materials`). No PDK data is bundled;
PDK-derived parameters must be supplied by a licensed user and are never
written into shared reports by this module unless the caller passes them.
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any

import numpy as np

from . import __version__
from .quantum.constants import constants_provenance

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SOURCE_GLOBS = ("python/sf_quantum/**/*.py", "rtl/**/*.sv", "rtl/**/*.svh", "tests/**/*.py", "tests/**/*.sv")


def source_tree_hash(root: Path = PROJECT_ROOT) -> str:
    h = hashlib.sha256()
    files = sorted({p for g in SOURCE_GLOBS for p in root.glob(g) if p.is_file()})
    for p in files:
        h.update(str(p.relative_to(root)).encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def git_revision(root: Path = PROJECT_ROOT) -> dict:
    try:
        rev = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"], capture_output=True, text=True,
                             timeout=5)
        if rev.returncode != 0:
            return {"revision": None, "note": "not a git work tree (delivered as an archive)"}
        dirty = subprocess.run(["git", "-C", str(root), "status", "--porcelain"], capture_output=True, text=True,
                               timeout=5).stdout.strip() != ""
        return {"revision": rev.stdout.strip(), "dirty": dirty}
    except (OSError, subprocess.SubprocessError):
        return {"revision": None, "note": "git unavailable"}


def environment() -> dict:
    import scipy
    mods = {"python": sys.version.split()[0], "numpy": np.__version__, "scipy": scipy.__version__,
            "platform": platform.platform(), "sf_quantum": __version__}
    for name in ("h5py", "pandas", "pydantic", "mpmath", "plotly", "matplotlib"):
        try:
            mods[name] = __import__(name).__version__
        except Exception:
            mods[name] = None
    return mods


def _jsonable(obj: Any):
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return _jsonable(obj.tolist())
    if isinstance(obj, (np.floating,)):
        obj = float(obj)
    if isinstance(obj, float):
        if np.isnan(obj):
            return "NaN"
        if np.isinf(obj):
            return "Infinity" if obj > 0 else "-Infinity"
        return obj
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if hasattr(obj, "value") and hasattr(obj, "name") and type(obj).__module__ != "builtins":
        try:
            return obj.value
        except Exception:
            pass
    if hasattr(obj, "model_dump"):
        return _jsonable(obj.model_dump())
    return obj


def make_metadata(
    experiment: str,
    *,
    inputs: dict,
    assumptions: list[str],
    materials: list[dict] | None = None,
    solver_settings: dict | None = None,
    grid: dict | None = None,
    results_summary: dict | None = None,
    rtl_configuration: dict | None = None,
    testbench_seed: int | None = None,
    validation: dict | None = None,
    parameter_provenance: dict[str, str] | None = None,
    reproduce: str | None = None,
) -> dict:
    return _jsonable({
        "experiment": experiment,
        "created_utc": _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"),
        "sf_quantum_version": __version__,
        "inputs": inputs,
        "parameter_provenance": parameter_provenance or {},
        "physical_constants": constants_provenance(),
        "model_assumptions": assumptions,
        "material_property_sources": materials or [],
        "solver_settings": solver_settings or {},
        "grid_resolution": grid or {},
        "git": git_revision(),
        "source_tree_sha256": source_tree_hash(),
        "environment": environment(),
        "results_summary": results_summary or {},
        "rtl_configuration": rtl_configuration,
        "testbench_seed": testbench_seed,
        "validation_outcome": validation,
        "reproduce_with": reproduce,
        "calibration_statement": "Model-derived results; not calibrated against foundry, PDK or measured silicon data.",
    })


def save_experiment(out_dir: str | Path, name: str, metadata: dict, arrays: dict[str, np.ndarray] | None = None,
                    tables: dict | None = None) -> dict:
    """Write ``<name>.json`` (+ ``<name>.h5`` and ``<name>_<table>.csv``). Returns written paths."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written = {}
    if arrays:
        import h5py
        h5 = out / f"{name}.h5"
        with h5py.File(h5, "w") as f:
            f.attrs["experiment"] = name
            f.attrs["metadata_json"] = json.dumps(metadata)
            for key, arr in arrays.items():
                a = np.asarray(arr)
                if a.dtype == object:
                    a = a.astype("S")
                f.create_dataset(key, data=a)
        written["hdf5"] = str(h5)
        metadata = {**metadata, "hdf5_datasets": sorted(arrays)}
    if tables:
        for tname, df in tables.items():
            p = out / f"{name}_{tname}.csv"
            df.to_csv(p, index=False)
            written[f"csv:{tname}"] = str(p)
        metadata = {**metadata, "csv_tables": sorted(tables)}
    js = out / f"{name}.json"
    js.write_text(json.dumps(_jsonable(metadata), indent=2))
    written["json"] = str(js)
    return written


def load_experiment(out_dir: str | Path, name: str) -> tuple[dict, dict[str, np.ndarray]]:
    out = Path(out_dir)
    meta = json.loads((out / f"{name}.json").read_text())
    arrays = {}
    h5 = out / f"{name}.h5"
    if h5.exists():
        import h5py
        with h5py.File(h5, "r") as f:
            arrays = {k: f[k][()] for k in f.keys()}
    return meta, arrays


__all__ = ["source_tree_hash", "git_revision", "environment", "make_metadata", "save_experiment",
           "load_experiment", "PROJECT_ROOT"]
