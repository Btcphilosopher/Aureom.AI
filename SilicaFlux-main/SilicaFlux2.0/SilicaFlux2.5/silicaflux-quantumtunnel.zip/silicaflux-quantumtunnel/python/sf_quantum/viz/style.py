"""Shared visual identity for figures and the dashboard.

Data-mark colours are the brand hues (gold, cyan, violet, rose) stepped into the
dark-surface lightness band and validated with the dataviz palette checker
against the midnight-navy chart surface (#0B1630): all checks pass, worst
adjacent CVD dE 9.6, normal-vision dE 18.6, contrast >= 3:1. The brighter
brand values are used only for headings / accents, never for data marks.
"""

from __future__ import annotations

SURFACE = "#0B1630"        # chart surface (midnight navy)
PAGE = "#070E1F"           # page background
PANEL_EDGE = "#1C2A4A"
GRID = "#1F2D4D"
TEXT_PRIMARY = "#E8ECF4"
TEXT_SECONDARY = "#A9B4C9"
TEXT_MUTED = "#6F7C96"
ACCENT_GOLD = "#C9A84C"    # brand accents (headings)
ACCENT_CYAN = "#00E5FF"

SERIES = ["#B08A2E", "#00A3C2", "#8C6FE8", "#D85C78"]  # validated categorical order
BARRIER_FILL = "rgba(176,138,46,0.18)"

FONT_DISPLAY = "'Bebas Neue', 'Oswald', 'Impact', sans-serif"
FONT_MONO = "'DM Mono', 'IBM Plex Mono', 'Menlo', monospace"


def apply_matplotlib():
    import matplotlib as mpl
    mpl.rcParams.update({
        "figure.facecolor": PAGE, "axes.facecolor": SURFACE, "savefig.facecolor": PAGE,
        "axes.edgecolor": PANEL_EDGE, "axes.labelcolor": TEXT_SECONDARY, "axes.titlecolor": TEXT_PRIMARY,
        "xtick.color": TEXT_MUTED, "ytick.color": TEXT_MUTED, "text.color": TEXT_PRIMARY,
        "grid.color": GRID, "grid.linewidth": 0.6, "axes.grid": True,
        "axes.prop_cycle": mpl.cycler(color=SERIES), "lines.linewidth": 2.0, "lines.markersize": 6,
        "legend.frameon": False, "legend.labelcolor": TEXT_SECONDARY, "font.family": "monospace",
        "font.size": 9, "axes.titlesize": 11, "axes.spines.top": False, "axes.spines.right": False,
    })


def plotly_layout(title: str, xtitle: str, ytitle: str, *, ylog: bool = False, xlog: bool = False) -> dict:
    axis = dict(gridcolor=GRID, zerolinecolor=GRID, linecolor=PANEL_EDGE, color=TEXT_SECONDARY,
                tickfont=dict(family=FONT_MONO, size=10, color=TEXT_MUTED),
                title_font=dict(family=FONT_MONO, size=11, color=TEXT_SECONDARY))
    return dict(
        title=dict(text=title, font=dict(family=FONT_DISPLAY, size=20, color=TEXT_PRIMARY), x=0.01),
        paper_bgcolor=SURFACE, plot_bgcolor=SURFACE, margin=dict(l=60, r=18, t=46, b=48),
        font=dict(family=FONT_MONO, color=TEXT_SECONDARY, size=11),
        xaxis=dict(axis, title=xtitle, type="log" if xlog else "linear"),
        yaxis=dict(axis, title=ytitle, type="log" if ylog else "linear"),
        legend=dict(font=dict(size=10, color=TEXT_SECONDARY), bgcolor="rgba(0,0,0,0)", orientation="h",
                    y=-0.22, x=0),
        hovermode="x unified", hoverlabel=dict(bgcolor=PAGE, font=dict(family=FONT_MONO, color=TEXT_PRIMARY)),
        colorway=SERIES, height=360,
    )
