"""SilicaFlux Silicon Physics dashboard (static, self-contained HTML).

Renders ONLY data produced by actual computations: every panel reads the
experiment files in ``data/experiments`` and the RTL / synthesis reports.
Nothing is synthesised for display. Each panel states the origin of its
numbers (PYTHON MODEL, RTL SIMULATION, POST-ROUTE, ...) and carries a data
table view. Output: ``dashboard/index.html`` (Plotly inlined, fonts embedded,
works offline).
"""

from __future__ import annotations

import base64
import html
import json
from pathlib import Path

import numpy as np
import pandas as pd

from ..provenance import PROJECT_ROOT
from ..quantum import barriers as B
from ..quantum.constants import Q_E
from . import style as S

EXP = PROJECT_ROOT / "data" / "experiments"
FONT_DIR = PROJECT_ROOT / "dashboard" / "fonts"


def _csv(exp: str, table: str) -> pd.DataFrame:
    return pd.read_csv(EXP / exp / f"{exp}_{table}.csv")


def _h5(exp: str) -> dict:
    import h5py
    with h5py.File(EXP / exp / f"{exp}.h5", "r") as f:
        return {k: f[k][()] for k in f.keys()}


def _line(x, y, name, i, dash=None, width=2.0):
    import plotly.graph_objects as go
    return go.Scatter(x=list(map(float, x)), y=[None if (v is None or not np.isfinite(v)) else float(v) for v in y],
                      mode="lines", name=name, line=dict(color=S.SERIES[i % 4], width=width, dash=dash))


def _table(df: pd.DataFrame, n: int = 12, src: str = "") -> str:
    d = df.head(n).copy()
    for c in d.columns:
        if d[c].dtype.kind == "f":
            d[c] = d[c].map(lambda v: f"{v:.5g}")
    head = "".join(f"<th>{html.escape(str(c))}</th>" for c in d.columns)
    rows = "".join("<tr>" + "".join(f"<td>{html.escape(str(v))}</td>" for v in r) + "</tr>" for r in d.values)
    more = f"<p class='src'>first {min(n, len(df))} of {len(df)} rows - full table: <code>{html.escape(src)}</code></p>" if src else ""
    return f"<details><summary>data table</summary><div class='tw'><table><thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table></div>{more}</details>"


def _fig(traces, title, xt, yt, ylog=False, xlog=False, shapes=None, annotations=None, hovermode=None, extra=None):
    import plotly.graph_objects as go
    lay = S.plotly_layout(title, xt, yt, ylog=ylog, xlog=xlog)
    if shapes:
        lay["shapes"] = shapes
    if annotations:
        lay["annotations"] = annotations
    if hovermode:
        lay["hovermode"] = hovermode
    if extra:
        lay.update(extra)
    return go.Figure(data=traces, layout=lay)


def build_panels() -> list[dict]:
    import plotly.graph_objects as go
    P = []
    A = _csv("A", "spectrum")
    Ah = _h5("A")
    Bf, Bj = _csv("B", "field_sweep"), _csv("B", "current_density")
    Ct, Cc, Cj = _csv("C", "thickness_sweep"), _csv("C", "convergence"), _csv("C", "current_vs_thickness")
    Ds, Dt, De = _csv("D", "stacks"), _csv("D", "transmission_vs_voltage"), _csv("D", "eot_lines")
    Djb, Dmc = _csv("D", "J_vs_bias"), _csv("D", "monte_carlo")
    Dloc = _csv("D", "local_sensitivity")
    E = _csv("E", "python_vs_rtl")
    Et = _csv("E", "hardware_throughput")
    dmeta = json.loads((EXP / "D" / "D.json").read_text())

    # 1 device structure: gate-stack cross-sections with real layer thicknesses
    shapes, ann, traces = [], [], []
    colours = {"Si": "#2B3A5C", "SiO2": "#00A3C2", "HfO2": "#8C6FE8", "gate": "#B08A2E"}
    for j, st in enumerate(dmeta["results_summary"]["stacks"]):
        x0, x1 = j * 1.6, j * 1.6 + 1.0
        y = 0.0
        layers = [("Si", 1.2)] + [(p.split(" ")[0], float(p.split(" ")[1])) for p in st["layers"].split(" / ")] + [("gate", 1.2)]
        for name, th in layers:
            shapes.append(dict(type="rect", x0=x0, x1=x1, y0=y, y1=y + th, line=dict(color=S.SURFACE, width=2),
                               fillcolor=colours.get(name, "#555")))
            traces.append(go.Scatter(x=[(x0 + x1) / 2], y=[y + th / 2], mode="markers", marker=dict(size=1, opacity=0),
                                     showlegend=False, hovertemplate=f"{st['stack']}<br>{name}: {th:.3g} nm<extra></extra>"))
            if name not in ("Si", "gate"):
                ann.append(dict(x=x1 + 0.05, y=y + th / 2, text=f"{name} {th:.3g} nm", showarrow=False, xanchor="left",
                                font=dict(size=10, color=S.TEXT_SECONDARY)))
            y += th
        ann.append(dict(x=(x0 + x1) / 2, y=y + 0.35, text=f"{st['stack']}<br>EOT {st['eot_nm']:.2f} nm", showarrow=False,
                        font=dict(size=11, color=S.TEXT_PRIMARY)))
    ann += [dict(x=0.5, y=0.6, text="Si substrate", showarrow=False, font=dict(size=10, color=S.TEXT_SECONDARY))]
    fig = _fig(traces, "1  Gate-stack structure (to scale, 1D cut)", "", "height above Si surface (nm)",
               shapes=shapes, annotations=ann, hovermode="closest",
               extra={"xaxis": dict(visible=False, range=[-0.2, 3.6]), "showlegend": False})
    P.append({"fig": fig, "origin": "CONFIGURATION (experiment D stacks)",
              "caption": "Matched-EOT stacks of experiment D drawn to scale. The tunnelling calculation is a 1D cut normal "
                         "to this stack; lateral geometry is not modelled.", "table": _table(Ds, src="data/experiments/D/D_stacks.csv")})

    # 2 potential-energy barrier
    from ..devices import materials as M
    from ..devices.dielectric_stack import matched_eot_stack, single_layer
    tr = []
    for i, (name, prof) in enumerate([("SiO2 1.0 nm @ 1 V", single_layer(M.SIO2, 1.0).simplified_profile(1.0)),
                                      ("SiO2 0.5 / HfO2 3.2 nm @ 1 V", matched_eot_stack(1.0, M.HFO2, M.SIO2, 0.5).simplified_profile(1.0)),
                                      ("rectangular 3.1 eV x 1.5 nm (exp. A)", B.rectangular(3.1, 1.5, 0.5))]):
        x, v, _ = prof.sample(600, lead_extent_m=0.6e-9)
        tr.append(_line(x * 1e9, v / Q_E, name, i))
    fig = _fig(tr, "2  Potential-energy barrier", "position x (nm)", "conduction-band edge (eV, Si Ec = 0)")
    P.append({"fig": fig, "origin": "PYTHON MODEL (simplified voltage-drop model; band offsets from literature, HfO2 mass assumed)",
              "caption": "Electron potential energy V(x): barrier heights are conduction-band offsets, never the Si band gap.",
              "table": ""})

    # 3 wavefunction
    x = Ah["wf_x_nm"]
    fig = _fig([_line(x, Ah["wf_psi_re"], "Re psi", 0), _line(x, Ah["wf_psi_im"], "Im psi", 1)],
               "3  Electron wavefunction (E = 1.0 eV)", "x (nm)", "psi (unit incident amplitude)",
               shapes=[dict(type="rect", x0=0, x1=1.5, y0=0, y1=1, yref="paper", fillcolor=S.BARRIER_FILL, line_width=0)])
    P.append({"fig": fig, "origin": "PYTHON MODEL (S-matrix reconstruction, exp. A)",
              "caption": "Computed stationary scattering state for a unit-amplitude incident wave; left lead holds incident "
                         "+ reflected waves, right lead the transmitted wave. Shaded: barrier. Not a particle trajectory.",
              "table": _table(pd.DataFrame({"x_nm": x[::100], "Re_psi": Ah["wf_psi_re"][::100], "Im_psi": Ah["wf_psi_im"][::100]}))})

    # 4 probability density
    fig = _fig([_line(x, Ah["wf_density"], "|psi|^2, E = 1.0 eV (tunnelling)", 0),
                _line(Ah["wf_above_x_nm"], Ah["wf_above_density"], "|psi|^2, E = 4.0 eV (above barrier)", 1)],
               "4  Probability density", "x (nm)", "|psi|^2 (relative to incident beam)",
               shapes=[dict(type="rect", x0=0, x1=1.5, y0=0, y1=1, yref="paper", fillcolor=S.BARRIER_FILL, line_width=0)])
    P.append({"fig": fig, "origin": "PYTHON MODEL",
              "caption": "Probability density, not electric current: the probability current j(x) is uniform through the "
                         f"device (max spread {json.loads((EXP / 'A' / 'A.json').read_text())['results_summary']['wavefunction_current_spread']:.1e} of j_in).",
              "table": ""})

    # 5 transmission vs energy
    fig = _fig([_line(A.energy_eV, A.T_exact, "exact (L1)", 0), _line(A.energy_eV, A.T_wkb, "WKB (L2)", 1, "dash"),
                _line(A.energy_eV, A.T_scattering, "S-matrix (L3)", 2, "dot"), _line(A.energy_eV, A.T_fd, "finite difference (L3)", 3, "dashdot")],
               "5  Transmission vs energy", "electron energy E (eV)", "T", ylog=True)
    P.append({"fig": fig, "origin": "PYTHON MODEL (exp. A, 1200 energies)",
              "caption": "WKB is undefined above the barrier top (gap) and misses the abrupt-interface prefactor below it; "
                         "S-matrix matches the exact solution to 2e-14 in ln T.",
              "table": _table(A[["energy_eV", "T_exact", "T_wkb", "T_scattering", "T_fd"]].iloc[::100], src="data/experiments/A/A_spectrum.csv")})

    # 6 transmission vs thickness
    tr = []
    i = 0
    for (F, e), g in Ct.groupby(["field_MV_per_cm", "energy_eV"]):
        if e in (0.05, 1.0):
            tr.append(_line(g.thickness_nm, g.logT_scattering, f"E={e} eV, F={F:g} MV/cm", i))
            i += 1
    fig = _fig(tr, "6  Transmission vs oxide thickness", "SiO2 physical thickness (nm)", "ln T")
    P.append({"fig": fig, "origin": "PYTHON MODEL (exp. C, S-matrix)",
              "caption": "ln T falls linearly with thickness at zero field (slope -2 kappa, matched to 4e-6): exponential "
                         "sensitivity. Model-derived, not measured leakage.",
              "table": _table(Ct, src="data/experiments/C/C_thickness_sweep.csv")})

    # 7 transmission vs field
    fn = Bf[Bf.regime == "fowler-nordheim"]
    fig = _fig([_line(Bf.field_MV_per_cm, Bf.logT_scattering, "S-matrix", 0), _line(Bf.field_MV_per_cm, Bf.logT_wkb, "WKB", 1, "dash"),
                _line(fn.field_MV_per_cm, fn.logT_fn_triangular, "FN triangular (valid regime)", 2, "dot")],
               "7  Transmission vs applied field", "oxide field (MV/cm)", "ln T at E = 0.05 eV",
               shapes=[dict(type="line", x0=10.17, x1=10.17, y0=0, y1=1, yref="paper", line=dict(color=S.TEXT_MUTED, width=1))],
               annotations=[dict(x=10.17, y=1.02, yref="paper", text="FN onset (qFt = phi - E)", showarrow=False,
                                 font=dict(size=10, color=S.TEXT_MUTED))])
    P.append({"fig": fig, "origin": "PYTHON MODEL (exp. B, 3 nm SiO2)",
              "caption": "Above the FN onset the S-matrix shows Fowler-Nordheim interference oscillations that WKB cannot.",
              "table": _table(Bf, src="data/experiments/B/B_field_sweep.csv")})

    # 8 direct vs FN
    fnr = Bj[Bj.regime == "fowler-nordheim"]
    fig = _fig([_line(Bj.field_MV_per_cm, Bj.J_tsu_esaki_A_cm2, "Tsu-Esaki, quantum T", 0),
                _line(Bj.field_MV_per_cm, Bj.J_tsu_esaki_wkbT_A_cm2, "Tsu-Esaki, WKB T", 1, "dot"),
                _line(fnr.field_MV_per_cm, fnr.J_fn_analytic_A_cm2, "FN analytical (FN regime only)", 2, "dash")],
               "8  Direct vs Fowler-Nordheim", "oxide field (MV/cm)", "J (A/cm^2)", ylog=True)
    P.append({"fig": fig, "origin": "PYTHON MODEL (research current model: metal/SiO2 3 nm/metal, 300 K)",
              "caption": "The FN law is drawn only where qFt > phi_B. With WKB transmission the numerical current reproduces "
                         "FN; full quantum transmission adds the interface prefactor and oscillations. Not a MOSFET leakage prediction.",
              "table": _table(Bj, src="data/experiments/B/B_current_density.csv")})

    # 9 SiO2 vs high-k
    tr = [_line(g.v_stack_V, g.logT_scattering, n, i) for i, (n, g) in enumerate(Dt.groupby("stack"))]
    fig = _fig(tr, "9  SiO2 vs high-k at matched EOT 1.0 nm", "voltage across stack (V)", "ln T at E = 0.05 eV")
    P.append({"fig": fig, "origin": "PYTHON MODEL (exp. D; HfO2 tunnelling mass ASSUMED 0.2 m0)",
              "caption": "Same capacitance, 3.7x the physical thickness: lower transmission for nominal parameters. "
                         "Panel 15 shows how strongly that depends on the assumed HfO2 parameters.",
              "table": _table(Dt, src="data/experiments/D/D_transmission_vs_voltage.csv")})

    # 10 EOT vs physical thickness
    fig = _fig([_line(De.physical_nm, De.eot_SiO2_nm, "SiO2", 0), _line(De.physical_nm, De["eot_HfO2_on_0.5nm_IL_nm"], "HfO2 on 0.5 nm SiO2 IL", 1)],
               "10  EOT vs physical thickness", "physical thickness (nm)", "EOT (nm)")
    P.append({"fig": fig, "origin": "ANALYTICAL (EOT = sum t_i 3.9/k_i)",
              "caption": "Physical thickness, EOT, electrical barrier thickness and transmission are four different quantities.",
              "table": _table(De.iloc[::4], src="data/experiments/D/D_eot_lines.csv")})

    # 11 gate leakage
    tr = [go.Scatter(x=g.bias_V, y=g.J_A_cm2, mode="lines+markers", name=n, line=dict(color=S.SERIES[i], width=2),
                     marker=dict(size=8)) for i, (n, g) in enumerate(Djb.groupby("stack"))]
    fig = _fig(tr, "11  Gate tunnelling current (research model)", "bias (V)", "J (A/cm^2)", ylog=True)
    P.append({"fig": fig, "origin": "PYTHON MODEL (Tsu-Esaki, 3D metal electrodes, 300 K; validated vs FN limit; uncalibrated)",
              "caption": "Gate tunnelling only. Subthreshold, junction, band-to-band and trap-assisted leakage are not modelled "
                         "and never added. Temperature and barrier-height dependence: see table/CSV.",
              "table": _table(pd.concat([Djb, _csv("D", "J_vs_temperature"), _csv("D", "J_vs_barrier")]), 20,
                              "data/experiments/D/D_J_vs_*.csv")})

    # 12 convergence
    fig = _fig([go.Scatter(x=Cc.grid_nm, y=Cc.abs_err_smatrix, mode="lines+markers", name="S-matrix staircase",
                           line=dict(color=S.SERIES[0], width=2), marker=dict(size=8)),
                go.Scatter(x=Cc.grid_nm, y=Cc.abs_err_fd, mode="lines+markers", name="finite difference",
                           line=dict(color=S.SERIES[1], width=2), marker=dict(size=8))],
               "12  Numerical solver convergence", "grid spacing (nm)", "|ln T - ln T_Airy(60 digits)|", ylog=True, xlog=True,
               hovermode="closest")
    P.append({"fig": fig, "origin": "PYTHON MODEL vs mpmath high-precision Airy reference",
              "caption": "Both independent Level-3 solvers converge at second order to the exact Airy solution.",
              "table": _table(Cc, src="data/experiments/C/C_convergence.csv")})

    # 13 python vs rtl
    fig = _fig([go.Scatter(x=-E.ref_logT, y=E.abs_dlogT, mode="markers", name="|ln T_RTL - ln T_double|",
                           marker=dict(color=S.SERIES[1], size=8, line=dict(color=S.SURFACE, width=1))),
                go.Scatter(x=-E.ref_logT, y=E.budget_logT, mode="markers", name="per-vector error budget",
                           marker=dict(color=S.SERIES[0], size=8, symbol="line-ew-open"))],
               "13  Python vs RTL accuracy", "2S = -ln T (reference)", "absolute ln T error", ylog=True, xlog=True,
               hovermode="closest")
    rtl = json.loads((PROJECT_ROOT / "reports" / "rtl" / "rtl_verification.json").read_text())
    P.append({"fig": fig, "origin": "RTL SIMULATION (Icarus Verilog 12; Verilator 5 trace identical)",
              "caption": f"{len(E)} valid vectors, bit-exact with the fixed-point model; worst error/budget "
                         f"{E.ratio_logT.max():.3f} (ln T), {E.ratio_T.max():.3f} (T). All runs pass: {rtl['all_pass']}.",
              "table": _table(E[["index", "V0_eV", "E_eV", "A_nm", "M_rel", "ref_logT", "rtl_logT", "abs_dlogT", "budget_logT"]],
                              src="data/experiments/E/E_python_vs_rtl.csv")})

    # 14 hardware throughput
    fig = _fig([go.Bar(x=[str(c) for c in Et.config], y=[float(v) for v in Et.throughput_Meval_per_s],
                       marker=dict(color=S.SERIES[2], line=dict(color=S.SURFACE, width=2), cornerradius=4),
                       name="evaluations / s (millions)",
                       customdata=[[int(a), int(b), int(c)] for a, b, c in zip(Et.latency_cycles, Et.LUT4, Et.FF)],
                       hovertemplate="%{x}<br>%{y:.1f} M eval/s (II=1 x post-route Fmax)<br>latency %{customdata[0]} cycles"
                                     "<br>LUT4 %{customdata[1]}, FF %{customdata[2]}<extra></extra>")],
               "14  Hardware throughput (ECP5 post-route)", "RTL configuration", "million evaluations / s",
               hovermode="closest", extra={"showlegend": False, "xaxis": dict(S.plotly_layout("", "", "")["xaxis"],
                                                                              type="category", title="RTL configuration")})
    P.append({"fig": fig, "origin": "POST-ROUTE (nextpnr-ecp5, LFE5U-85F) x II=1 from RTL SIMULATION",
              "caption": "Throughput = Fmax x 1 result/cycle. No board constraints; not a measured FPGA run.",
              "table": _table(Et, src="data/experiments/E/E_hardware_throughput.csv")})

    # 15 parameter sensitivity
    fig = _fig([go.Histogram(x=Dmc.log10_T_ratio_hk_over_sio2, nbinsx=30, marker=dict(color=S.SERIES[3], line=dict(color=S.SURFACE, width=2), cornerradius=4),
                             name="Monte Carlo samples")],
               "15  Parameter sensitivity (Monte Carlo)", "log10(T_highk / T_SiO2) at 1 V", "samples", hovermode="closest",
               extra={"showlegend": False, "bargap": 0.04})
    sp = dmeta["results_summary"]["mc_spearman"]
    P.append({"fig": fig, "origin": "PYTHON MODEL; spread = PARAMETER UNCERTAINTY (not manufacturing variability)",
              "caption": "Spearman rank correlation with the outcome: " + ", ".join(f"{k} {v:+.2f}" for k, v in sp.items())
                         + ". The assumed HfO2 mass dominates.",
              "table": _table(Dloc, src="data/experiments/D/D_local_sensitivity.csv")})
    return P


def _fonts_css() -> str:
    css = []
    for fam, fname, w in (("Bebas Neue", "bebas-neue-latin-400-normal.woff2", 400),
                          ("DM Mono", "dm-mono-latin-400-normal.woff2", 400),
                          ("DM Mono", "dm-mono-latin-500-normal.woff2", 500)):
        f = FONT_DIR / fname
        if f.exists():
            b64 = base64.b64encode(f.read_bytes()).decode()
            css.append(f"@font-face{{font-family:'{fam}';font-weight:{w};font-display:swap;"
                       f"src:url(data:font/woff2;base64,{b64}) format('woff2');}}")
    return "\n".join(css)


def build(out: str | Path = PROJECT_ROOT / "dashboard" / "index.html") -> str:
    from plotly.offline import get_plotlyjs
    panels = build_panels()
    val = json.loads((PROJECT_ROOT / "reports" / "validation" / "validation.json").read_text()) \
        if (PROJECT_ROOT / "reports" / "validation" / "validation.json").exists() else None
    e = json.loads((EXP / "E" / "E.json").read_text())["results_summary"]
    tp = pd.DataFrame(e["throughput_table"])
    best = tp.loc[tp.fmax_mhz_post_route.idxmax()] if len(tp) else None
    tiles = [
        ("Validation checks", f"{val['passed']}/{val['total']}" if val else "not run", "PYTHON MODEL"),
        ("RTL vectors bit-exact", f"{e['n_compared']}", "RTL SIMULATION"),
        ("Max |delta ln T| RTL", f"{e['max_abs_dlogT']:.1e}", "vs double-precision WKB"),
        ("Post-route Fmax", f"{best.fmax_mhz_post_route:.1f} MHz" if best is not None else "n/a",
         f"ECP5, config '{best.config}'" if best is not None else ""),
    ]
    tile_html = "".join(f"<div class='tile'><div class='tv'>{html.escape(v)}</div><div class='tl'>{html.escape(l)}</div>"
                        f"<div class='to'>{html.escape(o)}</div></div>" for l, v, o in tiles)
    cards, scripts = [], []
    for i, p in enumerate(panels):
        cards.append(f"<section class='card'><div id='p{i}' class='plot'></div><p class='origin'>{html.escape(p['origin'])}</p>"
                     f"<p class='cap'>{html.escape(p['caption'])}</p>{p['table']}</section>")
        scripts.append(f"Plotly.newPlot('p{i}', ...(() => {{const f = {p['fig'].to_json()}; return [f.data, f.layout, "
                       f"{{displaylogo:false, responsive:true}}];}})());")
    doc = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SilicaFlux QuantumTunnel - Silicon Physics Dashboard</title>
<style>
{_fonts_css()}
:root{{--page:{S.PAGE};--surface:{S.SURFACE};--edge:{S.PANEL_EDGE};--t1:{S.TEXT_PRIMARY};--t2:{S.TEXT_SECONDARY};
--t3:{S.TEXT_MUTED};--gold:{S.ACCENT_GOLD};--cyan:{S.ACCENT_CYAN};}}
body{{margin:0;background:var(--page);color:var(--t1);font-family:{S.FONT_MONO};}}
header{{padding:28px 32px 8px;border-bottom:1px solid var(--edge);}}
h1{{font-family:{S.FONT_DISPLAY};font-weight:400;letter-spacing:.04em;font-size:44px;margin:0;color:var(--gold);}}
h1 span{{color:var(--cyan);}}
.sub{{color:var(--t2);font-size:13px;margin:6px 0 16px;max-width:1100px;line-height:1.5}}
.tiles{{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:16px}}
.tile{{background:var(--surface);border:1px solid var(--edge);border-radius:6px;padding:12px 16px;min-width:200px}}
.tv{{font-family:{S.FONT_DISPLAY};font-size:32px;color:var(--t1);letter-spacing:.03em}}
.tl{{color:var(--t2);font-size:12px}} .to{{color:var(--t3);font-size:11px;margin-top:2px}}
main{{display:grid;grid-template-columns:repeat(auto-fill,minmax(560px,1fr));gap:18px;padding:22px 32px}}
.card{{background:var(--surface);border:1px solid var(--edge);border-radius:8px;padding:8px 12px 12px}}
.plot{{height:360px}}
.origin{{color:var(--cyan);font-size:11px;margin:6px 0 2px;opacity:.85}}
.cap{{color:var(--t2);font-size:12px;line-height:1.45;margin:2px 0 6px}}
details summary{{cursor:pointer;color:var(--t3);font-size:11px}}
.tw{{overflow-x:auto;max-height:260px}} table{{border-collapse:collapse;font-size:10.5px;margin-top:6px}}
th,td{{border-bottom:1px solid var(--edge);padding:3px 8px;text-align:right;white-space:nowrap}} th{{color:var(--t2)}}
td{{color:var(--t1)}} .src{{color:var(--t3);font-size:10.5px}} code{{color:var(--t2)}}
footer{{padding:0 32px 30px;color:var(--t3);font-size:11px;line-height:1.6}}
a{{color:var(--cyan)}}
</style>
<script>{get_plotlyjs()}</script></head>
<body><header><h1>SilicaFlux <span>QuantumTunnel</span></h1>
<p class="sub">Silicon physics dashboard. Every panel is drawn from files written by the solver, the RTL regression or the
synthesis tools in this repository (see each panel's origin line and data table). One-dimensional, effective-mass,
coherent models; nothing here is calibrated to a foundry process or measured silicon.</p>
<div class="tiles">{tile_html}</div></header>
<main>{''.join(cards)}</main>
<footer>Regenerate: <code>make quantum-report</code>. 3D device view: <a href="device3d.html">device3d.html</a>.
Fonts: Bebas Neue and DM Mono, SIL Open Font License 1.1. Charts: Plotly (MIT).</footer>
<script>{''.join(scripts)}</script></body></html>"""
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(doc)
    return str(out)


def build_device3d(out: str | Path = PROJECT_ROOT / "dashboard" / "device3d.html") -> str | None:
    """Optional Three.js view: schematic planar device + the solver's 1D potential cut.

    Physical content (layer order/thickness, per-layer field, Ec(x) along the cut)
    comes from the experiment-D stack at 1 V (simplified voltage-drop model).
    """
    bundle = PROJECT_ROOT / "dashboard" / "vendor" / "device3d.bundle.js"
    if not bundle.exists():
        return None
    from ..devices import materials as M
    from ..devices.dielectric_stack import matched_eot_stack
    st = matched_eot_stack(1.0, M.HFO2, M.SIO2, 0.5)
    part = st.partition(1.0)
    prof = st.simplified_profile(1.0)
    x, v, _ = prof.sample(400, lead_extent_m=0.8e-9)
    data = {"stack": [{"name": l.material.name, "thickness_nm": l.thickness_nm, "field_MV_cm": float(f)}
                      for l, f in zip(st.layers, part["fields_MV_per_cm"])],
            "cut": {"x_nm": (x * 1e9).round(5).tolist(), "V_eV": (v / Q_E).round(5).tolist()},
            "bias_V": 1.0, "label": "SiO2 0.5 / HfO2 3.2 nm, V_stack = 1 V", "vscale": 5.0}
    doc = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>SilicaFlux QuantumTunnel - 3D device view</title>
<style>{_fonts_css()}
body{{margin:0;background:{S.PAGE};color:{S.TEXT_PRIMARY};font-family:{S.FONT_MONO};overflow:hidden}}
#hdr{{padding:14px 22px 6px}} h1{{font-family:{S.FONT_DISPLAY};font-weight:400;color:{S.ACCENT_GOLD};margin:0;font-size:32px}}
p{{color:{S.TEXT_SECONDARY};font-size:12px;margin:4px 0;max-width:1200px}}
#view{{position:absolute;top:120px;left:0;right:0;bottom:0}}
.lbl{{position:absolute;transform:translate(-50%,-50%);font-size:11px;color:{S.TEXT_PRIMARY};
background:rgba(7,14,31,.72);padding:2px 6px;border-radius:3px;pointer-events:none;white-space:nowrap}}
</style></head><body><div id="hdr"><h1>3D device view (schematic)</h1>
<p>Lateral dimensions are illustrative and layer thicknesses are exaggerated {data['vscale']:g}x vertically. The only physics drawn is
the solver's <b>one-dimensional</b> conduction-band cut, the per-layer field and the tunnelling direction for
{data['label']} (simplified voltage-drop model). This is not a 3D electrostatic or transport solution, and
transmission is a probability, not a particle trajectory. Drag to orbit, scroll to zoom.</p></div>
<div id="view"></div>
<script>window.SFQT_DEVICE = {json.dumps(data)};</script>
<script>{bundle.read_text()}</script></body></html>"""
    out = Path(out)
    out.write_text(doc)
    return str(out)


__all__ = ["build", "build_panels", "build_device3d"]
