"""The first five reproducible experiments (brief section 40).

Each experiment writes to ``data/experiments/<ID>/``:
``<ID>.json`` (provenance metadata), ``<ID>.h5`` (arrays), ``<ID>_<table>.csv``
(data tables), and figures to ``reports/figures/``. Reproduce with
``sf-quantum report`` or ``python -m sf_quantum.experiments.run A B C D E``.

A  rectangular barrier: exact vs WKB vs numerical scattering (+ FD, HP reference)
B  trapezoidal SiO2 barrier under increasing field: direct -> Fowler-Nordheim
C  SiO2 physical-thickness sweep: model-derived transmission sensitivity
D  SiO2 vs SiO2/HfO2 at matched EOT, with band offsets, masses and their uncertainty
E  Python vs synthesizable SystemVerilog WKB comparison
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from ..analysis import sensitivity, sweeps
from ..devices import materials as M
from ..devices.dielectric_stack import matched_eot_stack, single_layer
from ..devices.electrostatics import MOSCapacitor
from ..devices.gate_tunneling import gate_current_density
from ..models import current as C
from ..models import fowler_nordheim as FN
from ..provenance import PROJECT_ROOT, make_metadata, save_experiment
from ..quantum import barriers as B
from ..quantum import scattering as S
from ..quantum import schrodinger as FD
from ..quantum import wkb as W
from ..quantum.constants import HBAR, M_E, Q_E
from ..quantum.hp_reference import layered_transfer_hp
from ..quantum.rectangular import rectangular_transmission

DATA = PROJECT_ROOT / "data" / "experiments"
FIGS = PROJECT_ROOT / "reports" / "figures"


def _fig():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from ..viz.style import apply_matplotlib
    apply_matplotlib()
    return plt


def _save(plt, fig, name):
    FIGS.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(FIGS / name, dpi=140)
    plt.close(fig)
    return str((FIGS / name).relative_to(PROJECT_ROOT))


# =============================================================================
def experiment_a() -> dict:
    V0, a, m = 3.1, 1.5, 0.5
    prof = B.rectangular(V0, a, m, label="Experiment A: SiO2-like rectangular barrier")
    E = np.linspace(0.01, 6.0, 1200) * Q_E
    df = sweeps.energy_sweep(prof, E, methods=("wkb", "scattering", "fd"))
    df["logT_wkb_prefactor"] = [W.wkb(prof, e, prefactor="abrupt_rectangular").log_transmission
                                if e < V0 * Q_E else np.nan for e in E]
    for col in ("wkb", "wkb_prefactor", "scattering", "fd"):
        df[f"dlogT_{col}"] = df[f"logT_{col}"] - df["logT_exact"]
    picks = [0.05, 0.5, 1.0, 2.0, 3.0, 3.1, 3.5, 5.0]
    table = []
    for e in picks:
        ex = rectangular_transmission(e * Q_E, V0 * Q_E, a * 1e-9, m * M_E)
        hp = layered_transfer_hp(prof, e * Q_E, dps=50)
        w = W.wkb(prof, e * Q_E)
        sm = S.transmission(prof, e * Q_E)
        fd = FD.solve(prof, e * Q_E)
        table.append({"E_eV": e, "regime": ex.regime[0], "T_exact": ex.transmission[0], "T_hp_mpmath": hp.transmission,
                      "T_wkb": w.transmission, "T_scattering": sm.transmission[0], "T_fd": fd.transmission[0],
                      "R_scattering": sm.reflection[0], "wkb_flags": ";".join(f.value for f in w.flags)})
    table = pd.DataFrame(table)
    wf_in = S.wavefunction(prof, 1.0 * Q_E, n_points=1500)
    wf_ab = S.wavefunction(prof, 4.0 * Q_E, n_points=1500)
    arrays = {"energy_eV": df.energy_eV.values, "T_exact": df.T_exact.values, "T_scattering": df.T_scattering.values,
              "T_wkb": df.T_wkb.values, "T_fd": df.T_fd.values, "logT_exact": df.logT_exact.values,
              "wf_x_nm": wf_in.x_m * 1e9, "wf_psi_re": wf_in.psi.real, "wf_psi_im": wf_in.psi.imag,
              "wf_density": np.abs(wf_in.psi) ** 2, "wf_current": wf_in.current,
              "wf_above_x_nm": wf_ab.x_m * 1e9, "wf_above_density": np.abs(wf_ab.psi) ** 2,
              "wf_above_re": wf_ab.psi.real}
    good = df[df.energy_eV < V0 - 0.2]
    summary = {
        "max_abs_dlogT_scattering": float(np.nanmax(np.abs(df.dlogT_scattering))),
        "max_abs_dlogT_fd": float(np.nanmax(np.abs(df.dlogT_fd))),
        "wkb_dlogT_range_below_barrier": [float(good.dlogT_wkb.min()), float(good.dlogT_wkb.max())],
        "wkb_prefactor_max_abs_dlogT_thick_regime": float(np.nanmax(np.abs(good.dlogT_wkb_prefactor))),
        "max_conservation_error": float(df.conservation_error.max()),
        "wavefunction_current_spread": float((wf_in.current.max() - wf_in.current.min()) / wf_in.incident_flux),
        "T_wavefunction_E1eV": wf_in.transmission,
    }
    meta = make_metadata("A", inputs={"V0_eV": V0, "width_nm": a, "m_eff": m, "lead_mass": m},
                         parameter_provenance={"V0_eV": "assumed (SiO2-like)", "m_eff": "literature (SiO2 0.5 m0)"},
                         assumptions=["ideal rectangular barrier, identical leads, 1D coherent"],
                         solver_settings={"scattering_max_slice_nm": 0.005, "fd_grid_nm": 0.005, "hp_dps": 50},
                         grid={"n_energy": int(E.size)}, results_summary=summary,
                         reproduce="sf-quantum report --experiments A")
    paths = save_experiment(DATA / "A", "A", meta, arrays, {"spectrum": df, "selected_energies": table})
    plt = _fig()
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax[0].semilogy(df.energy_eV, df.T_exact, label="exact (Level 1)")
    ax[0].semilogy(df.energy_eV, df.T_wkb, "--", label="WKB (Level 2)")
    ax[0].semilogy(df.energy_eV, df.T_scattering, ":", label="S-matrix (Level 3)")
    ax[0].axvline(V0, color="#6F7C96", lw=1)
    ax[0].set(xlabel="electron energy E (eV)", ylabel="transmission T", title="A: T(E), 3.1 eV x 1.5 nm, m*=0.5")
    ax[0].legend()
    ax[1].plot(df.energy_eV, df.dlogT_wkb, label="WKB - exact")
    ax[1].plot(df.energy_eV, df.dlogT_wkb_prefactor, label="WKB with abrupt prefactor - exact")
    ax[1].plot(df.energy_eV, df.dlogT_fd * 100, label="FD - exact (x100)")
    ax[1].set(xlabel="E (eV)", ylabel="delta ln T", title="model discrepancy vs exact")
    ax[1].legend()
    figs = [_save(plt, fig, "A_spectrum_discrepancy.png")]
    return {"id": "A", "summary": summary, "files": paths, "figures": figs}


# =============================================================================
def experiment_b() -> dict:
    phi, t, m, lead = 3.1, 3.0, 0.5, 0.26
    fields = np.linspace(0.25, 20.0, 80)
    df = sweeps.field_sweep(M.SIO2, t, fields, energy_eV=0.05, lead_mass=lead)
    hp_rows = []
    for F in (2.0, 8.0, 12.0, 18.0):
        prof = single_layer(M.SIO2, t).simplified_profile(F * 0.1 * t, left_lead_mass=lead, right_lead_mass=lead)
        hp_rows.append({"field_MV_per_cm": F, "logT_airy_hp": layered_transfer_hp(prof, 0.05 * Q_E).log_transmission,
                        "logT_scattering_converged": S.converged_transmission(prof, 0.05 * Q_E)["log_transmission"]})
    hp = pd.DataFrame(hp_rows)
    # current density: metal / SiO2 3 nm / metal, Tsu-Esaki vs analytical FN (FN regime only)
    g = M.GENERIC_METAL_GATE
    phi_mim = g.work_function_eV.value - M.SIO2.electron_affinity_eV(M.SILICON.electron_affinity_eV.value)
    j_rows = []
    for F in np.linspace(2.0, 16.0, 15):
        v = F * 0.1 * t
        te = gate_current_density(single_layer(M.SIO2, t), v, emitter=g, collector=g, temperature_K=300.0,
                                  n_energy=2500, max_slice_m=0.01e-9)
        tw = gate_current_density(single_layer(M.SIO2, t), v, emitter=g, collector=g, temperature_K=300.0,
                                  n_energy=2500, method="wkb")
        fn = FN.current_density(F * 1e8, phi_mim, m, thickness_m=t * 1e-9, m_emitter_rel=1.0, temperature_K=300.0,
                                allow_outside_regime=True)
        j_rows.append({"field_MV_per_cm": F, "bias_V": v, "J_tsu_esaki_A_cm2": te.J_A_per_cm2,
                       "J_tsu_esaki_wkbT_A_cm2": tw.J_A_per_cm2,
                       "J_fn_analytic_A_cm2": float(fn["J_A_per_m2"][0]) * 1e-4, "regime": fn["regime"][0],
                       "fn_outside_validity": bool(fn["outside_validity"][0])})
    jdf = pd.DataFrame(j_rows)
    fnr = jdf[jdf.regime == "fowler-nordheim"]
    summary = {
        "fn_onset_field_MV_per_cm_at_E": float((phi - 0.05) / (0.1 * t)),
        "max_rel_diff_scattering_vs_airy_logT": float(np.max(np.abs(hp.logT_scattering_converged - hp.logT_airy_hp)
                                                             / np.abs(hp.logT_airy_hp))),
        "fn_regime_tsu_esaki_over_fn_range": [float((fnr.J_tsu_esaki_A_cm2 / fnr.J_fn_analytic_A_cm2).min()),
                                              float((fnr.J_tsu_esaki_A_cm2 / fnr.J_fn_analytic_A_cm2).max())],
        "fn_regime_tsu_esaki_wkbT_over_fn_range": [float((fnr.J_tsu_esaki_wkbT_A_cm2 / fnr.J_fn_analytic_A_cm2).min()),
                                                   float((fnr.J_tsu_esaki_wkbT_A_cm2 / fnr.J_fn_analytic_A_cm2).max())],
        "interpretation": "With WKB transmission the numerical Tsu-Esaki current reproduces the analytical FN law "
                          "(validation of the current model); with the full quantum transmission it differs by the "
                          "abrupt-interface prefactor and FN interference oscillations -- a model difference, not an error.",
        "mim_barrier_height_eV": float(phi_mim),
    }
    meta = make_metadata("B", inputs={"phi_B_eV": phi, "thickness_nm": t, "m_ox": m, "lead_mass": lead, "E_eV": 0.05},
                         parameter_provenance={"phi_B_eV": "literature", "m_ox": "literature", "lead_mass": "assumed",
                                               "metal_work_function": "assumed"},
                         assumptions=["SIMPLIFIED voltage-drop model (field set directly)", "1D", "no image force",
                                      "Tsu-Esaki: 3D free-electron metal electrodes"],
                         materials=M.material_table(), results_summary=summary,
                         reproduce="sf-quantum report --experiments B")
    paths = save_experiment(DATA / "B", "B", meta, {"field_MV_per_cm": df.field_MV_per_cm.values,
                                                    "logT_scattering": df.logT_scattering.values,
                                                    "logT_wkb": df.logT_wkb.values,
                                                    "logT_fn_triangular": df.logT_fn_triangular.values},
                            {"field_sweep": df, "hp_reference": hp, "current_density": jdf})
    plt = _fig()
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax[0].plot(df.field_MV_per_cm, df.logT_scattering, label="S-matrix (trapezoid/triangle)")
    ax[0].plot(df.field_MV_per_cm, df.logT_wkb, "--", label="WKB")
    sel = df.regime == "fowler-nordheim"
    ax[0].plot(df.field_MV_per_cm[sel], df.logT_fn_triangular[sel], ":", label="FN triangular (valid regime only)")
    ax[0].axvline(summary["fn_onset_field_MV_per_cm_at_E"], color="#6F7C96", lw=1)
    ax[0].set(xlabel="oxide field (MV/cm)", ylabel="ln T at E = 0.05 eV", title="B: 3 nm SiO2, direct -> FN")
    ax[0].legend()
    ax[1].semilogy(jdf.field_MV_per_cm, jdf.J_tsu_esaki_A_cm2, label="Tsu-Esaki, quantum T")
    ax[1].semilogy(jdf.field_MV_per_cm, jdf.J_tsu_esaki_wkbT_A_cm2, ":", label="Tsu-Esaki, WKB T")
    ax[1].semilogy(fnr.field_MV_per_cm, fnr.J_fn_analytic_A_cm2, "--", label="FN analytical (FN regime)")
    ax[1].set(xlabel="oxide field (MV/cm)", ylabel="J (A/cm^2)", title="metal/SiO2/metal research model, 300 K")
    ax[1].legend()
    return {"id": "B", "summary": summary, "files": paths, "figures": [_save(plt, fig, "B_field_regimes.png")]}


# =============================================================================
def experiment_c() -> dict:
    th = np.round(np.linspace(0.8, 4.0, 33), 4)
    df = sweeps.thickness_sweep(M.SIO2, th, energies_eV=(0.05, 0.5, 1.0), fields_MV_per_cm=(0.0, 5.0))
    # solver convergence on a biased barrier (vs Airy HP reference)
    prof = single_layer(M.SIO2, 2.0).simplified_profile(1.0)
    ref = layered_transfer_hp(prof, 0.5 * Q_E).log_transmission
    conv = []
    for h in (0.08, 0.04, 0.02, 0.01, 0.005, 0.0025):
        conv.append({"grid_nm": h,
                     "abs_err_smatrix": abs(S.transmission(prof, 0.5 * Q_E, max_slice_m=h * 1e-9).log_transmission[0] - ref),
                     "abs_err_fd": abs(FD.solve(prof, 0.5 * Q_E, grid_m=h * 1e-9).log_transmission[0] - ref)})
    conv = pd.DataFrame(conv)
    # selected current estimates: metal / SiO2 / metal at 1 V (research model)
    g = M.GENERIC_METAL_GATE
    jt = [{"thickness_nm": float(t), "J_A_cm2": gate_current_density(single_layer(M.SIO2, float(t)), 1.0, emitter=g,
                                                                      collector=g, n_energy=1500).J_A_per_cm2}
          for t in (1.2, 1.6, 2.0, 2.4, 2.8, 3.2)]
    jt = pd.DataFrame(jt)
    flat = df[(df.field_MV_per_cm == 0) & (df.energy_eV == 0.5)].iloc[3:-3]
    orders = np.log2(conv.abs_err_smatrix.values[:-1] / conv.abs_err_smatrix.values[1:])
    summary = {
        "decay_rate_vs_2kappa_max_rel_dev": float(np.max(np.abs(flat.dlogT_dt_per_nm / flat.minus_2kappa_per_nm - 1))),
        "logT_per_nm_at_0.5eV_flat": float(flat.dlogT_dt_per_nm.mean()),
        "smatrix_observed_order": float(np.median(orders)),
        "J_decades_per_nm_1V": float(-np.polyfit(jt.thickness_nm, np.log10(jt.J_A_cm2), 1)[0]),
        "statement": "Transmission falls exponentially with physical thickness (ln T slope ~ -2 kappa). "
                     "These are model-derived transmissions, not measured transistor leakage.",
    }
    meta = make_metadata("C", inputs={"thickness_nm": th.tolist(), "energies_eV": [0.05, 0.5, 1.0],
                                      "fields_MV_per_cm": [0.0, 5.0]},
                         assumptions=["SIMPLIFIED voltage-drop model", "Si lead mass 0.26 (assumed)", "1D"],
                         materials=M.material_table(), results_summary=summary,
                         solver_settings={"scattering_max_slice_nm": 0.005},
                         reproduce="sf-quantum sweep thickness / sf-quantum report --experiments C")
    paths = save_experiment(DATA / "C", "C", meta, {"thickness_nm": th}, {"thickness_sweep": df, "convergence": conv,
                                                                         "current_vs_thickness": jt})
    plt = _fig()
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    for (F, e), g_ in df.groupby(["field_MV_per_cm", "energy_eV"]):
        if e in (0.05, 1.0):
            ax[0].plot(g_.thickness_nm, g_.logT_scattering, label=f"E={e} eV, F={F:g} MV/cm")
    ax[0].set(xlabel="SiO2 physical thickness (nm)", ylabel="ln T", title="C: thickness sensitivity")
    ax[0].legend(fontsize=7)
    ax[1].loglog(conv.grid_nm, conv.abs_err_smatrix, "o-", label="S-matrix staircase")
    ax[1].loglog(conv.grid_nm, conv.abs_err_fd, "s-", label="finite difference")
    ax[1].set(xlabel="grid spacing (nm)", ylabel="|ln T - ln T_Airy|", title="solver convergence (~h^2)")
    ax[1].legend()
    return {"id": "C", "summary": summary, "files": paths, "figures": [_save(plt, fig, "C_thickness_convergence.png")]}


# =============================================================================
def experiment_d(n_mc: int = 300, seed: int = 20261115) -> dict:
    eot = 1.0
    sio2 = single_layer(M.SIO2, eot, name="SiO2 (EOT 1.0 nm)")
    hk = matched_eot_stack(eot, M.HFO2, M.SIO2, 0.5, name="SiO2 0.5 nm / HfO2 (EOT 1.0 nm)")
    stacks = {"SiO2": sio2, "SiO2/HfO2": hk}
    rows = []
    for name, s in stacks.items():
        part = s.partition(1.0)
        rows.append({"stack": name, "physical_thickness_nm": s.physical_thickness_nm, "eot_nm": s.eot_nm,
                     "capacitance_uF_cm2": s.capacitance_F_per_m2 * 100,
                     "fields_MV_cm_at_1V": json.dumps([round(f, 3) for f in part["fields_MV_per_cm"]]),
                     "layers": s.describe()})
    stack_table = pd.DataFrame(rows)
    vs = np.linspace(0.05, 1.5, 30)
    tv = []
    for name, s in stacks.items():
        for v in vs:
            prof = s.simplified_profile(float(v))
            tv.append({"stack": name, "v_stack_V": float(v),
                       "logT_scattering": float(S.transmission(prof, 0.05 * Q_E).log_transmission[0]),
                       "logT_wkb": float(W.wkb(prof, 0.05 * Q_E).log_transmission)})
    tv = pd.DataFrame(tv)
    # MOS electrostatics: same EOT -> same C -> same V_stack(V_G); report fraction across stack
    mos_rows = []
    for name, s in stacks.items():
        mos = MOSCapacitor(s, M.GENERIC_METAL_GATE, doping_cm3=1e17)
        for vg in (0.5, 1.0, 1.5):
            st = mos.solve(vg)
            mos_rows.append({"stack": name, "V_G": vg, "psi_s_V": st.surface_potential_V, "V_stack_V": st.stack_voltage_V,
                             "fraction_across_stack": st.fraction_across_stack, "regime": st.regime,
                             "logT_E0.05": float(S.transmission(mos.barrier_profile(vg), 0.05 * Q_E).log_transmission[0])})
    mos_df = pd.DataFrame(mos_rows)
    # EOT vs physical thickness lines
    phys = np.linspace(0.5, 6.0, 40)
    eot_lines = pd.DataFrame({"physical_nm": phys, "eot_SiO2_nm": phys,
                              "eot_HfO2_on_0.5nm_IL_nm": 0.5 + np.clip(phys - 0.5, 0, None) * 3.9 / 25.0})
    # gate current (Tsu-Esaki research model, metal electrodes) vs bias, temperature, barrier height
    g = M.GENERIC_METAL_GATE
    jb = [{"stack": n, "bias_V": float(v), "J_A_cm2": gate_current_density(s, float(v), emitter=g, collector=g,
                                                                            n_energy=1500).J_A_per_cm2}
          for n, s in stacks.items() for v in (0.25, 0.5, 0.75, 1.0, 1.25)]
    jT = [{"stack": "SiO2", "temperature_K": T, "J_A_cm2": gate_current_density(sio2, 1.0, emitter=g, collector=g,
                                                                                  temperature_K=T, n_energy=1500).J_A_per_cm2}
          for T in (250.0, 300.0, 350.0, 400.0)]
    jphi = []
    for cbo in (2.9, 3.0, 3.1, 3.2, 3.34):
        mat = M.SIO2.model_copy(update={"conduction_band_offset_eV": M.SIO2.conduction_band_offset_eV.with_value(cbo)})
        jphi.append({"sio2_cbo_eV": cbo, "J_A_cm2": gate_current_density(single_layer(mat, eot), 1.0, emitter=g,
                                                                          collector=g, n_energy=1500).J_A_per_cm2})
    # Monte Carlo over assumed / literature-range parameters (parameter uncertainty)
    def model(p):
        il = M.SIO2.model_copy(update={"tunnelling_mass_rel": M.SIO2.tunnelling_mass_rel.with_value(p["m_sio2"])})
        hf = M.HFO2.model_copy(update={"tunnelling_mass_rel": M.HFO2.tunnelling_mass_rel.with_value(p["m_hfo2"]),
                                       "conduction_band_offset_eV": M.HFO2.conduction_band_offset_eV.with_value(p["cbo_hfo2"])})
        st_hk = matched_eot_stack(eot, hf, il, p["t_il"])
        st_ox = single_layer(il, eot)
        lt_hk = float(S.transmission(st_hk.simplified_profile(1.0), 0.05 * Q_E, max_slice_m=0.01e-9).log_transmission[0])
        lt_ox = float(S.transmission(st_ox.simplified_profile(1.0), 0.05 * Q_E, max_slice_m=0.01e-9).log_transmission[0])
        return {"logT_hk": lt_hk, "logT_sio2": lt_ox, "log10_T_ratio_hk_over_sio2": (lt_hk - lt_ox) / np.log(10)}
    dists = [sensitivity.Distribution("m_hfo2", "uniform", (0.1, 0.4), 0.2, provenance="assumed", unit="m0"),
             sensitivity.Distribution("cbo_hfo2", "uniform", (1.4, 2.0), 1.4, provenance="literature", unit="eV"),
             sensitivity.Distribution("m_sio2", "uniform", (0.29, 0.5), 0.5, provenance="literature", unit="m0"),
             sensitivity.Distribution("t_il", "uniform", (0.4, 0.6), 0.5, provenance="hypothetical", unit="nm")]
    mc = sensitivity.monte_carlo(model, dists, n_samples=n_mc, seed=seed)
    loc = sensitivity.local_sensitivities(model, {"m_hfo2": 0.2, "cbo_hfo2": 1.4, "m_sio2": 0.5, "t_il": 0.5},
                                          "log10_T_ratio_hk_over_sio2")
    s_ratio = mc["summary"]["log10_T_ratio_hk_over_sio2"]
    summary = {
        "stacks": stack_table.to_dict(orient="records"),
        "log10_T_ratio_nominal_at_1V": float(model({"m_hfo2": 0.2, "cbo_hfo2": 1.4, "m_sio2": 0.5, "t_il": 0.5})
                                             ["log10_T_ratio_hk_over_sio2"]),
        "mc_log10_ratio": {k: s_ratio[k] for k in ("p05", "p50", "p95", "min", "max")},
        "mc_spearman": s_ratio["spearman"],
        "fraction_of_mc_samples_where_hk_lower_T": float((mc["samples"].log10_T_ratio_hk_over_sio2 < 0).mean()),
        "interpretation": mc["interpretation"],
        "statement": "At matched EOT the thicker high-k stack shows lower model transmission for the nominal "
                     "parameters, but the size of the advantage depends strongly on the assumed HfO2 mass and "
                     "band offset (see Monte Carlo); no measured leakage is implied.",
    }
    meta = make_metadata("D", inputs={"target_eot_nm": eot, "il_nm": 0.5, "E_eV": 0.05, "mc_samples": n_mc},
                         parameter_provenance={"HfO2 mass": "assumed", "HfO2 CBO": "literature range",
                                               "SiO2 mass": "literature range", "IL thickness": "hypothetical"},
                         assumptions=["SIMPLIFIED voltage-drop model for T(V_stack)", "analytical MOS electrostatics for VG mapping",
                                      "Tsu-Esaki with metal electrodes for J (research model)", "1D slice"],
                         materials=M.material_table(), results_summary=summary, testbench_seed=seed,
                         reproduce="sf-quantum dielectric compare / sf-quantum report --experiments D")
    paths = save_experiment(DATA / "D", "D", meta, {"v_stack_V": vs}, {
        "stacks": stack_table, "transmission_vs_voltage": tv, "mos": mos_df, "eot_lines": eot_lines,
        "J_vs_bias": pd.DataFrame(jb), "J_vs_temperature": pd.DataFrame(jT), "J_vs_barrier": pd.DataFrame(jphi),
        "monte_carlo": mc["samples"], "local_sensitivity": pd.DataFrame(loc).T.reset_index(names="parameter")})
    plt = _fig()
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    for n, g_ in tv.groupby("stack"):
        ax[0].plot(g_.v_stack_V, g_.logT_scattering, label=n)
    ax[0].set(xlabel="voltage across stack (V)", ylabel="ln T at E=0.05 eV", title="D: matched EOT 1.0 nm")
    ax[0].legend()
    ax[1].hist(mc["samples"].log10_T_ratio_hk_over_sio2, bins=30, color="#00A3C2")
    ax[1].set(xlabel="log10(T_stack / T_SiO2) at 1 V", ylabel="samples", title="parameter-uncertainty Monte Carlo")
    return {"id": "D", "summary": summary, "files": paths, "figures": [_save(plt, fig, "D_sio2_vs_highk.png")]}


# =============================================================================
def experiment_e() -> dict:
    from ..reference import rtl_runner
    from ..reference import fixed_point_model as FP
    rtl_json = PROJECT_ROOT / "reports" / "rtl" / "rtl_verification.json"
    if not rtl_json.exists():
        rtl_runner.run_all()
    rtl = json.loads(rtl_json.read_text())
    run = next((r for r in rtl["runs"] if r["config"] == "default" and r["simulator"] == "iverilog"), None)
    if run is None or run["status"] == "simulator-unavailable":
        return {"id": "E", "summary": {"status": "RTL simulator unavailable -- comparison NOT run"}, "files": {}, "figures": []}
    vec = json.loads((PROJECT_ROOT / "vectors" / "sf_qt_core_v1" / "vectors.json").read_text())["vectors"]
    rows = []
    for line in (PROJECT_ROOT / run["results_file"]).read_text().splitlines():
        ph, idx, tag, lg, t, err, warn, lat = line.split()
        if ph != "1":
            continue
        r = vec[int(idx)]
        if int(err) & 3:
            continue
        ref = r["reference"]
        lv = FP.to_signed(int(lg, 16), 32) / 65536
        tv = int(t, 16) / 2**32
        rows.append({"index": int(idx), **r["inputs"], "ref_logT": ref["log_transmission"], "rtl_logT": lv,
                     "abs_dlogT": abs(lv - ref["log_transmission"]), "ref_T": ref["transmission"], "rtl_T": tv,
                     "abs_dT": abs(tv - ref["transmission"]), "budget_logT": r["tolerance"]["log_transmission_abs"],
                     "budget_T": r["tolerance"]["transmission_abs"], "warn": int(warn)})
    df = pd.DataFrame(rows)
    df["ratio_logT"] = df.abs_dlogT / df.budget_logT
    df["ratio_T"] = df.abs_dT / df.budget_T
    synth = PROJECT_ROOT / "reports" / "synthesis" / "synthesis.json"
    hw = json.loads(synth.read_text()) if synth.exists() else {}
    tp = []
    for n, e in hw.get("configs", {}).items():
        fmax = e["ecp5"].get("pnr", {}).get("fmax_mhz")
        lat = {"default": 38, "nopipe": 35, "bps5": 18, "direct": 38}[n]
        tp.append({"config": n, "fmax_mhz_post_route": fmax, "latency_cycles": lat,
                   "throughput_Meval_per_s": fmax, "latency_ns": (lat * 1e3 / fmax) if fmax else None,
                   "LUT4": e["ecp5"]["LUT4"], "FF": e["ecp5"]["TRELLIS_FF"], "MULT18X18D": e["ecp5"]["MULT18X18D"]})
    tp = pd.DataFrame(tp)
    summary = {"n_compared": int(len(df)), "bit_exact_all_runs": rtl["all_pass"],
               "cross_simulator_identical": rtl["cross_simulator_identical_traces"],
               "max_abs_dlogT": float(df.abs_dlogT.max()), "mean_abs_dlogT": float(df.abs_dlogT.mean()),
               "max_abs_dT": float(df.abs_dT.max()), "max_ratio_to_budget_logT": float(df.ratio_logT.max()),
               "max_ratio_to_budget_T": float(df.ratio_T.max()),
               "latency_cycles": run["tb_stats"]["latency"],
               "initiation_interval": (run["tb_stats"]["phaseA_issue_span"] + 1) / run["tb_stats"]["n"],
               "throughput_table": tp.to_dict(orient="records")}
    meta = make_metadata("E", inputs={"vector_set": "sf_qt_core_v1"}, assumptions=[
        "RTL SIMULATION (Icarus Verilog 12) vs Python double-precision WKB", "rectangular barrier, plain WKB"],
        rtl_configuration=run["rtl_parameters"], testbench_seed=run["seed"], results_summary=summary,
        validation={"bit_exact": run["comparison"]["bit_exact"], "outside_budget": len(run["comparison"]["outside_budget"])},
        reproduce="sf-quantum verify rtl && sf-quantum report --experiments E")
    paths = save_experiment(DATA / "E", "E", meta, {"ref_logT": df.ref_logT.values, "rtl_logT": df.rtl_logT.values},
                            {"python_vs_rtl": df, "hardware_throughput": tp})
    plt = _fig()
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax[0].scatter(-df.ref_logT, df.abs_dlogT, s=8, label="|ln T_RTL - ln T_ref|")
    ax[0].scatter(-df.ref_logT, df.budget_logT, s=4, alpha=0.5, label="per-vector error budget")
    ax[0].set(xscale="log", yscale="log", xlabel="2S = -ln T (reference)", ylabel="absolute ln T error",
              title="E: Python vs RTL (bit-exact model)")
    ax[0].legend()
    ax[1].hist(df.ratio_logT, bins=40, color="#8C6FE8")
    ax[1].set(xlabel="error / budget (ln T)", ylabel="vectors", title="all inside budget (< 1)")
    return {"id": "E", "summary": summary, "files": paths, "figures": [_save(plt, fig, "E_python_vs_rtl.png")]}


EXPERIMENTS = {"A": experiment_a, "B": experiment_b, "C": experiment_c, "D": experiment_d, "E": experiment_e}


def run(ids=("A", "B", "C", "D", "E")) -> dict:
    out = {}
    for i in ids:
        out[i] = EXPERIMENTS[i]()
    (PROJECT_ROOT / "reports").mkdir(exist_ok=True)
    path = PROJECT_ROOT / "reports" / "experiments_summary.json"
    merged = json.loads(path.read_text()) if path.exists() else {}
    merged.update({k: {"summary": v["summary"], "figures": v["figures"], "files": v["files"]} for k, v in out.items()})
    path.write_text(json.dumps(dict(sorted(merged.items())), indent=2, default=str))
    return out


if __name__ == "__main__":  # pragma: no cover
    ids = sys.argv[1:] or ["A", "B", "C", "D", "E"]
    res = run(ids)
    for k, v in res.items():
        print(k, json.dumps(v["summary"], default=str)[:400])
