"""Top-level engineering report index (reports/INDEX.md)."""

from __future__ import annotations

import json
from pathlib import Path

from .provenance import PROJECT_ROOT, git_revision, source_tree_hash


def _status(path: Path, key: str | None = None) -> str:
    if not path.exists():
        return "not generated"
    if key is None:
        return "present"
    try:
        return str(json.loads(path.read_text()).get(key))
    except Exception:
        return "unreadable"


def write_index(out: str | Path = PROJECT_ROOT / "reports" / "INDEX.md") -> str:
    R = PROJECT_ROOT / "reports"
    val = R / "validation" / "validation.json"
    v = json.loads(val.read_text()) if val.exists() else None
    rtl = R / "rtl" / "rtl_verification.json"
    r = json.loads(rtl.read_text()) if rtl.exists() else None
    lines = [
        "# SilicaFlux QuantumTunnel -- engineering reports", "",
        f"Source tree SHA-256: `{source_tree_hash()}`; git: {git_revision()}", "",
        "| report | status | file |", "|---|---|---|",
        f"| Numerical validation (18 checks) | {f'{v['passed']}/{v['total']} pass' if v else 'not run'} | `validation/VALIDATION.md` |",
        f"| RTL verification | {('all pass' if r['all_pass'] else 'FAILURES') if r else 'not run'}"
        f"{'' if not r or not r.get('unavailable') else ' (unavailable: ' + ', '.join(r['unavailable']) + ')'} | `rtl/RTL_VERIFICATION.md` |",
        f"| Synthesis / place-and-route | {_status(R / 'synthesis' / 'SYNTHESIS.md')} | `synthesis/SYNTHESIS.md` |",
        f"| Exp-unit design study | {_status(R / 'exp_study' / 'EXP_STUDY.md')} | `exp_study/EXP_STUDY.md` |",
        f"| Benchmarks | {_status(R / 'benchmarks' / 'BENCHMARKS.md')} | `benchmarks/BENCHMARKS.md` |",
        f"| Experiments A-E summary | {_status(R / 'experiments_summary.json')} | `experiments_summary.json`, `../data/experiments/` |",
        f"| Figures | {len(list((R / 'figures').glob('*.png'))) if (R / 'figures').exists() else 0} PNG | `figures/` |",
        f"| Dashboard | {_status(PROJECT_ROOT / 'dashboard' / 'index.html')} | `../dashboard/index.html` |", "",
        "Labels used throughout: PYTHON MODEL, ANALYTICAL, RTL SIMULATION, SYNTHESIS, POST-ROUTE, "
        "PRE-LAYOUT ESTIMATE. No FPGA measurement, silicon measurement, signoff STA or power analysis exists "
        "in this repository.", ""]
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines))
    return str(out)


__all__ = ["write_index"]
