"""Transmission-energy spectra, thickness and field sweeps.

``adaptive_energy_grid`` refines an energy grid until linear interpolation
between neighbouring points reproduces the solver at every new midpoint to a
tolerance in both T (linear) and ln T. This resolves narrow resonances that a
uniform grid misses -- but only resonances wider than the initial grid spacing
are guaranteed to be found; an isolated resonance much narrower than the
initial spacing can still be missed (documented limitation).
"""

from __future__ import annotations

from typing import Callable

import numpy as np
import pandas as pd

from ..devices.dielectric_stack import single_layer
from ..devices.materials import DielectricMaterial
from ..models import fowler_nordheim as FN
from ..quantum import scattering, schrodinger, wkb
from ..quantum.barriers import PotentialProfile
from ..quantum.constants import HBAR, M_E, Q_E
from ..quantum.rectangular import rectangular_transmission


def _scattering_fn(profile: PotentialProfile, max_slice_m: float) -> Callable[[np.ndarray], np.ndarray]:
    sliced = scattering.discretize(profile, max_slice_m)
    return lambda E: scattering.transmission(profile, E, sliced=sliced).transmission


def adaptive_energy_grid(
    profile: PotentialProfile,
    e_min_J: float,
    e_max_J: float,
    *,
    n_initial: int = 200,
    tol_linear: float = 5e-3,
    tol_log: float = 0.05,
    max_points: int = 20000,
    max_slice_m: float = scattering.DEFAULT_MAX_SLICE_M,
) -> tuple[np.ndarray, np.ndarray]:
    """Adaptively refined (E, T) using the scattering solver."""
    if not e_max_J > e_min_J > profile.left.potential_J:
        raise ValueError("need left-lead band edge < e_min < e_max")
    tf = _scattering_fn(profile, max_slice_m)
    E = np.linspace(e_min_J, e_max_J, n_initial)
    T = tf(E)
    while E.size < max_points:
        mid = 0.5 * (E[:-1] + E[1:])
        Tm = tf(mid)
        lin = 0.5 * (T[:-1] + T[1:])
        with np.errstate(divide="ignore", invalid="ignore"):
            lerr = np.abs(np.log(np.maximum(Tm, 1e-300)) - 0.5 * (np.log(np.maximum(T[:-1], 1e-300))
                                                                 + np.log(np.maximum(T[1:], 1e-300))))
        bad = (np.abs(Tm - lin) > tol_linear) | (lerr > tol_log)
        if not np.any(bad):
            break
        budget = max_points - E.size
        idx = np.flatnonzero(bad)[:budget]
        E = np.concatenate([E, mid[idx]])
        T = np.concatenate([T, Tm[idx]])
        order = np.argsort(E)
        E, T = E[order], T[order]
    return E, T


def energy_sweep(
    profile: PotentialProfile,
    energies_J: np.ndarray,
    *,
    methods: tuple[str, ...] = ("wkb", "scattering", "fd"),
    max_slice_m: float = scattering.DEFAULT_MAX_SLICE_M,
    fd_grid_m: float = schrodinger.DEFAULT_GRID_M,
) -> pd.DataFrame:
    """T(E) by several methods on one grid. Adds the exact result for single flat barriers."""
    E = np.asarray(energies_J, dtype=float)
    df = pd.DataFrame({"energy_eV": E / Q_E})
    is_rect = (len(profile.layers) == 1 and profile.layers[0].is_constant
               and profile.left.potential_J == profile.right.potential_J == 0.0
               and profile.left.mass_kg == profile.right.mass_kg)
    if is_rect:
        lay = profile.layers[0]
        r = rectangular_transmission(E, lay.v_start_J, lay.thickness_m, lay.mass_kg, profile.left.mass_kg)
        df["T_exact"], df["logT_exact"] = r.transmission, r.log_transmission
    if "wkb" in methods:
        w = wkb.wkb_spectrum(profile, E)
        df["T_wkb"], df["logT_wkb"] = w["transmission"], w["log_transmission"]
        df["wkb_above_barrier"] = w["above_barrier"]
        df["wkb_weak"] = w["weak_tunnelling"]
    if "scattering" in methods:
        s = scattering.transmission(profile, E, max_slice_m=max_slice_m)
        df["T_scattering"], df["logT_scattering"] = s.transmission, s.log_transmission
        df["R_scattering"] = s.reflection
        df["conservation_error"] = s.conservation_error
    if "fd" in methods:
        f = schrodinger.solve(profile, E, grid_m=fd_grid_m)
        df["T_fd"], df["logT_fd"] = f.transmission, f.log_transmission
    return df


def thickness_sweep(
    material: DielectricMaterial,
    thicknesses_nm: np.ndarray,
    *,
    energies_eV: tuple[float, ...] = (0.05, 0.5, 1.0),
    fields_MV_per_cm: tuple[float, ...] = (0.0, 5.0),
    lead_mass: float = 0.26,
    max_slice_m: float = 0.005e-9,
) -> pd.DataFrame:
    """ln T vs physical thickness for several energies and fields (simplified voltage-drop model)."""
    rows = []
    m_ox = material.tunnelling_mass_rel.value
    phi = material.conduction_band_offset_eV.value
    for F in fields_MV_per_cm:
        for t in thicknesses_nm:
            stack = single_layer(material, float(t))
            prof = stack.simplified_profile(F * 0.1 * t, left_lead_mass=lead_mass, right_lead_mass=lead_mass)
            E = np.asarray(energies_eV) * Q_E
            s = scattering.transmission(prof, E, max_slice_m=max_slice_m)
            w = wkb.wkb_spectrum(prof, E)
            for e, ls, lw, cons in zip(energies_eV, s.log_transmission, w["log_transmission"], s.conservation_error):
                rows.append({"material": material.name, "field_MV_per_cm": F, "thickness_nm": float(t),
                             "energy_eV": e, "logT_scattering": ls, "logT_wkb": lw, "conservation_error": cons})
    df = pd.DataFrame(rows)
    # local exponential decay rate vs the flat-barrier estimate 2 kappa (field = 0 only)
    df["dlogT_dt_per_nm"] = np.nan
    for (F, e), g in df.groupby(["field_MV_per_cm", "energy_eV"]):
        if len(g) > 2:
            df.loc[g.index, "dlogT_dt_per_nm"] = np.gradient(g["logT_scattering"].to_numpy(), g["thickness_nm"].to_numpy())
    kap = np.sqrt(2 * m_ox * M_E * np.clip(phi - df["energy_eV"], 0, None) * Q_E) / HBAR * 1e-9
    df["minus_2kappa_per_nm"] = np.where(df["field_MV_per_cm"] == 0, -2 * kap, np.nan)
    return df


def field_sweep(
    material: DielectricMaterial,
    thickness_nm: float,
    fields_MV_per_cm: np.ndarray,
    *,
    energy_eV: float = 0.05,
    lead_mass: float = 0.26,
    max_slice_m: float = 0.005e-9,
) -> pd.DataFrame:
    """ln T vs field for one dielectric; marks the direct / FN regime at this energy."""
    rows = []
    phi = material.conduction_band_offset_eV.value
    m_ox = material.tunnelling_mass_rel.value
    for F in np.asarray(fields_MV_per_cm, dtype=float):
        v = F * 0.1 * thickness_nm
        prof = single_layer(material, thickness_nm).simplified_profile(v, left_lead_mass=lead_mass,
                                                                       right_lead_mass=lead_mass)
        E = energy_eV * Q_E
        ls = scattering.transmission(prof, E, max_slice_m=max_slice_m).log_transmission[0]
        w = wkb.wkb(prof, E)
        fn_log = FN.triangular_log_transmission(phi - energy_eV, F * 1e8, m_ox) if F > 0 else np.nan
        rows.append({"material": material.name, "thickness_nm": thickness_nm, "field_MV_per_cm": F,
                     "voltage_V": v, "energy_eV": energy_eV, "logT_scattering": ls, "logT_wkb": w.log_transmission,
                     "logT_fn_triangular": float(fn_log),
                     "regime": "fowler-nordheim" if v >= phi - energy_eV else "direct",
                     "wkb_flags": ";".join(f.value for f in w.flags)})
    return pd.DataFrame(rows)


__all__ = ["adaptive_energy_grid", "energy_sweep", "thickness_sweep", "field_sweep"]
