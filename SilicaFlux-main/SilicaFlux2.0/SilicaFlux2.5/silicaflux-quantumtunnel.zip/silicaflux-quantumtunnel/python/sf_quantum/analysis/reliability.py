"""Reliability *research interface*: dielectric field stress vs tunnelling.

This module reports field and tunnelling quantities under specified
operating conditions so that they can be studied alongside reliability data.
It deliberately does **not** predict wear-out: tunnelling current is not
equated with any of the mechanisms in :data:`NOT_MODELLED`, each of which
needs its own physics and calibration.
"""

from __future__ import annotations

import numpy as np

from ..devices.dielectric_stack import DielectricStack
from ..quantum import scattering
from ..quantum.constants import Q_E

NOT_MODELLED = (
    "time-dependent dielectric breakdown (TDDB)",
    "bias-temperature instability (BTI)",
    "hot-carrier degradation (HCD)",
    "oxide trap generation",
    "long-term wear-out / lifetime extrapolation",
)


def field_stress_report(stack: DielectricStack, v_stack_values: np.ndarray, *, energy_eV: float = 0.05,
                        temperature_K: float = 300.0) -> dict:
    rows = []
    for v in np.asarray(v_stack_values, dtype=float):
        part = stack.partition(v)
        prof = stack.simplified_profile(v)
        lt = float(scattering.transmission(prof, energy_eV * Q_E).log_transmission[0])
        rows.append({
            "v_stack_V": float(v),
            "fields_MV_per_cm": part["fields_MV_per_cm"].tolist(),
            "max_field_MV_per_cm": float(np.max(np.abs(part["fields_MV_per_cm"]))),
            "max_field_layer": stack.layers[int(np.argmax(np.abs(part["fields_MV_per_cm"])))].material.name,
            "logT_at_energy": lt,
        })
    return {"stack": stack.summary(), "temperature_K": temperature_K, "energy_eV": energy_eV, "rows": rows,
            "not_modelled": list(NOT_MODELLED),
            "statement": "Field and transmission only. No lifetime, breakdown or degradation prediction is made."}


__all__ = ["NOT_MODELLED", "field_stress_report"]
