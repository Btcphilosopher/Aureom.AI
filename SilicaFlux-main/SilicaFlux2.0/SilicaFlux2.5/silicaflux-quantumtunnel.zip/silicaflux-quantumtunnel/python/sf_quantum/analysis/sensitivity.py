"""Parameter sensitivity and Monte Carlo uncertainty propagation.

Two kinds of spread are kept strictly apart:

* ``parameter_uncertainty`` -- our *lack of knowledge* of an assumed or
  literature parameter (e.g. the HfO2 tunnelling mass, 0.1-0.4 m0). This is
  epistemic; the resulting spread is "what the model predicts if the
  parameter is anywhere in this range", not a yield distribution.
* ``manufacturing_variability`` -- measured run-to-run / die-to-die spread.
  Only allowed for parameters whose provenance is ``measured`` or ``pdk``;
  no such data ships with this package, so every default study uses
  parameter uncertainty only.

Random numbers come from ``numpy.random.default_rng(seed)``; the seed is
recorded and identical seeds give bitwise-identical samples.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
import pandas as pd
from scipy import stats

UNCERTAINTY_KINDS = ("parameter_uncertainty", "manufacturing_variability")


@dataclass(frozen=True)
class Distribution:
    name: str
    kind: str  # uniform | normal | triangular | fixed
    params: tuple[float, ...]
    nominal: float
    uncertainty_kind: str = "parameter_uncertainty"
    provenance: str = "assumed"
    unit: str = ""

    def __post_init__(self):
        if self.kind not in ("uniform", "normal", "triangular", "fixed"):
            raise ValueError(f"unknown distribution kind {self.kind}")
        if self.uncertainty_kind not in UNCERTAINTY_KINDS:
            raise ValueError(f"uncertainty_kind must be one of {UNCERTAINTY_KINDS}")
        if self.uncertainty_kind == "manufacturing_variability" and self.provenance not in ("measured", "pdk"):
            raise ValueError("manufacturing variability requires measured or PDK-derived data; "
                             f"'{self.name}' has provenance '{self.provenance}'")

    def sample(self, rng: np.random.Generator, n: int) -> np.ndarray:
        if self.kind == "uniform":
            lo, hi = self.params
            return rng.uniform(lo, hi, n)
        if self.kind == "normal":
            mu, sd = self.params
            return rng.normal(mu, sd, n)
        if self.kind == "triangular":
            lo, mode, hi = self.params
            return rng.triangular(lo, mode, hi, n)
        return np.full(n, self.nominal)


def monte_carlo(
    model: Callable[[dict], dict],
    distributions: list[Distribution],
    *,
    n_samples: int = 500,
    seed: int = 20261115,
    output_keys: tuple[str, ...] | None = None,
) -> dict:
    """Propagate parameter distributions through ``model(params) -> {output: value}``."""
    rng = np.random.default_rng(seed)
    samples = {d.name: d.sample(rng, n_samples) for d in distributions}
    rows = []
    for i in range(n_samples):
        p = {k: float(v[i]) for k, v in samples.items()}
        out = model(p)
        rows.append({**p, **out})
    df = pd.DataFrame(rows)
    outs = output_keys or tuple(k for k in df.columns if k not in samples)
    summary = {}
    for o in outs:
        col = df[o].replace([np.inf, -np.inf], np.nan).dropna()
        summary[o] = {
            "mean": float(col.mean()), "std": float(col.std(ddof=1)),
            "p05": float(col.quantile(0.05)), "p50": float(col.quantile(0.5)), "p95": float(col.quantile(0.95)),
            "min": float(col.min()), "max": float(col.max()), "n_finite": int(col.size),
            "spearman": {d.name: float(stats.spearmanr(df[d.name], df[o], nan_policy="omit").statistic)
                         for d in distributions if d.kind != "fixed"},
        }
    return {"samples": df, "summary": summary, "seed": seed, "n_samples": n_samples,
            "distributions": [d.__dict__ for d in distributions],
            "interpretation": ("spread reflects parameter uncertainty in assumed/literature inputs, "
                               "not measured manufacturing variability")
            if all(d.uncertainty_kind == "parameter_uncertainty" for d in distributions)
            else "includes measured manufacturing variability for the flagged parameters"}


def local_sensitivities(model: Callable[[dict], dict], nominal: dict[str, float], output: str,
                        *, rel_step: float = 1e-3) -> dict[str, dict]:
    """Central-difference derivatives d(output)/d(ln p) and normalised elasticities."""
    base = model(nominal)[output]
    res = {}
    for k, v in nominal.items():
        if v == 0:
            continue
        h = rel_step * abs(v)
        up = model({**nominal, k: v + h})[output]
        dn = model({**nominal, k: v - h})[output]
        d = (up - dn) / (2 * h)
        res[k] = {"d_output_d_param": float(d), "d_output_d_lnparam": float(d * v),
                  "nominal": v, "output_nominal": float(base)}
    return res


__all__ = ["Distribution", "monte_carlo", "local_sensitivities", "UNCERTAINTY_KINDS"]
