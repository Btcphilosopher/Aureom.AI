"""Scientific validation suite (brief section 34): 18 checks, each reported with
its measured value, its threshold and PASS/FAIL. Failures are reported, never
dropped. ``run_all`` is what ``make quantum-validate`` executes; the same
physics is also covered (more exhaustively) by pytest.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable

import numpy as np

from ..quantum import barriers as B
from ..quantum import scattering as S
from ..quantum import schrodinger as FD
from ..quantum import wkb as W
from ..quantum.constants import HBAR, M_E, Q_E
from ..quantum.rectangular import abrupt_prefactor, rectangular_transmission
from ..quantum.units import eV_to_J, m_to_nm


@dataclass
class CheckResult:
    number: int
    name: str
    passed: bool
    value: float | str
    threshold: str
    detail: str
    seconds: float = 0.0


def _rect():
    return B.rectangular(3.1, 1.5, 0.5)


def c01_exact_reference():
    from ..quantum.hp_reference import rectangular_hp
    worst = 0.0
    for a in (0.5e-9, 1.5e-9, 20e-9):
        for e in (0.01, 1.0, 3.0, 3.3, 8.0):
            got = rectangular_transmission(e * Q_E, 3.1 * Q_E, a, 0.5 * M_E).log_transmission[0]
            ref = rectangular_hp(e * Q_E, 3.1 * Q_E, a, 0.5 * M_E, dps=50).log_transmission
            worst = max(worst, abs(got - ref) / max(1.0, abs(ref)))
    return worst < 1e-12, worst, "< 1e-12 rel. in ln T", "closed form vs 50-digit 4x4 boundary-matching solve"


def c02_thin_limit():
    alpha, E, m = 0.3 * Q_E * 1e-9, 0.5 * Q_E, 0.5 * M_E
    delta = 1.0 / (1.0 + m * alpha**2 / (2 * HBAR**2 * E))
    t = rectangular_transmission(E, alpha / 1e-12, 1e-12, m).transmission[0]
    err = abs(t - delta) / delta
    return err < 1e-3, err, "< 1e-3", "V0*a fixed, a=1 pm vs delta-barrier T"


def c03_wide_limit():
    E, V0, m, a = 1.0 * Q_E, 3.1 * Q_E, 0.5 * M_E, 40e-9
    kap = np.sqrt(2 * m * (V0 - E)) / HBAR
    asym = np.log(abrupt_prefactor(E, V0, m)[0]) - 2 * kap * a
    err = abs(rectangular_transmission(E, V0, a, m).log_transmission[0] - asym)
    return err < 1e-10, err, "< 1e-10 abs in ln T", "40 nm vs 16E(V0-E)/V0^2 exp(-2 kappa a)"


def c04_units():
    kappa_nm = np.sqrt(2 * M_E * eV_to_J(1.0)) / HBAR * 1e-9
    err = abs(kappa_nm - 5.12317) / 5.12317
    return err < 2e-6, err, "< 2e-6", "kappa(1 eV, m0) = 5.12317 nm^-1 (catches eV/J mix-ups)"


def c05_mass():
    from ..quantum.hp_reference import rectangular_hp
    got = rectangular_transmission(0.2 * Q_E, 3.1 * Q_E, 1e-9, 0.5 * M_E, 0.26 * M_E).transmission[0]
    ref = rectangular_hp(0.2 * Q_E, 3.1 * Q_E, 1e-9, 0.5 * M_E, 0.26 * M_E).transmission
    err = abs(got - ref) / ref
    return err < 1e-12, err, "< 1e-12", "barrier 0.5 m0 / leads 0.26 m0 (BenDaniel-Duke) vs HP solve"


def c06_flux():
    from ..quantum.hp_reference import layered_transfer_hp
    p = B.layered([dict(thickness_nm=1.0, v_start_eV=2.0, m_eff=0.4)], left_lead=(0.0, 1.0), right_lead=(-2.0, 0.1))
    r = S.transmission(p, 0.05 * Q_E)
    ref = layered_transfer_hp(p, 0.05 * Q_E).transmission
    err = abs(r.transmission[0] - ref) / ref
    amp_ratio = abs(r.t_amplitude[0]) ** 2 / r.transmission[0]
    return err < 1e-10, err, "< 1e-10", f"unequal leads: |t|^2/T = {amp_ratio:.3g} (velocity factor applied)"


def c07_current():
    wf = S.wavefunction(B.trapezoidal(3.1, 1.1, 2.0, 0.5), 1.0 * Q_E)
    spread = float((wf.current.max() - wf.current.min()) / wf.incident_flux)
    return spread < 1e-9, spread, "< 1e-9", "max-min of j(x)/j_in across leads and barrier"


def c08_bounds():
    rng = np.random.default_rng(8)
    bad = 0
    for _ in range(400):
        e, v, a = rng.uniform(1e-3, 10), rng.uniform(-1, 8), rng.uniform(0.01, 20)
        T = rectangular_transmission(e * Q_E, v * Q_E, a * 1e-9, rng.uniform(0.05, 1.5) * M_E).transmission[0]
        bad += not (0.0 <= T <= 1.0)
    p = B.trapezoidal(3.1, 0.5, 3.0, 0.4)
    T = S.transmission(p, np.linspace(0.01, 6, 300) * Q_E).transmission
    bad += int(np.sum((T < 0) | (T > 1 + 1e-12)))
    return bad == 0, bad, "0 violations", "400 random rectangles + 300-point trapezoid spectrum"


def c09_rt_unity():
    p = B.layered([dict(thickness_nm=1.2, v_start_eV=3.1, v_end_eV=1.5, m_eff=0.5),
                   dict(thickness_nm=2.0, v_start_eV=1.4, v_end_eV=0.3, m_eff=0.2)],
                  left_lead=(0.0, 0.26), right_lead=(-2.0, 1.0))
    E = np.linspace(0.01, 5, 500) * Q_E
    worst = float(max(S.transmission(p, E).conservation_error.max(), FD.solve(p, E[::10]).conservation_error.max()))
    return worst < 1e-10, worst, "< 1e-10", "|R+T-1|, S-matrix and FD, SiO2/HfO2-like stack"


def c10_grid():
    from ..quantum.hp_reference import layered_transfer_hp
    p = B.trapezoidal(3.1, 1.1, 2.0, 0.5)
    ref = layered_transfer_hp(p, 0.5 * Q_E).log_transmission
    e = [abs(S.transmission(p, 0.5 * Q_E, max_slice_m=h).log_transmission[0] - ref) for h in (0.04e-9, 0.02e-9, 0.01e-9)]
    order = float(np.mean(np.log2(np.array(e[:-1]) / np.array(e[1:]))))
    return 1.8 < order < 2.3, order, "observed order in (1.8, 2.3)", "S-matrix staircase, slice 0.04/0.02/0.01 nm"


def c11_energy_grid():
    p = B.trapezoidal(1.0, 0.6, 2.0, 0.3)
    vals = [np.trapezoid(S.transmission(p, np.linspace(0.01, 0.9, n) * Q_E).transmission, np.linspace(0.01, 0.9, n))
            for n in (101, 201, 401, 801)]
    rel = float(abs(vals[-1] - vals[-2]) / abs(vals[-1]))
    mono = bool(abs(vals[1] - vals[0]) > abs(vals[2] - vals[1]) > abs(vals[3] - vals[2]))
    return rel < 1e-4 and mono, rel, "< 1e-4 and monotone", "integral of T(E) dE on 101..801-point grids"


def c12_wkb_discrepancy():
    E = 0.3 * Q_E
    d = []
    for w in (1.0, 2.0, 4.0):
        p = B.from_function(lambda x, w=w: np.exp(-((x - 2 * w) / w) ** 2), 0.0, 4 * w, 0.3, n_samples=401,
                            v_left_eV=0.0, v_right_eV=0.0)
        d.append(abs(W.wkb(p, E).log_transmission - S.transmission(p, E, max_slice_m=0.002e-9).log_transmission[0])
                 / abs(S.transmission(p, E, max_slice_m=0.002e-9).log_transmission[0]))
    ok = d[0] > d[1] > d[2] and d[2] < 0.02
    return ok, d[-1], "decreasing with width, < 2% for the widest", \
        f"smooth Gaussian barrier relative ln T discrepancy {['%.3g' % x for x in d]}"


def c13_thick():
    p = B.rectangular(3.1, 50.0, 0.5)
    E = 1.0 * Q_E
    got = S.transmission(p, E).log_transmission[0]
    ref = rectangular_transmission(E, 3.1 * Q_E, 50e-9, 0.5 * M_E).log_transmission[0]
    naive = S.naive_transfer_matrix_log_t(p, E)
    err = abs(got - ref) / abs(ref)
    return err < 1e-12 and np.isfinite(got), err, "< 1e-12 rel.", \
        f"50 nm SiO2-like, ln T = {ref:.1f}; naive transfer matrix gives {naive}"


def c14_high_precision():
    from ..quantum.hp_reference import layered_transfer_hp
    worst = 0.0
    for p in (B.trapezoidal(3.1, 1.1, 2.0, 0.5), B.triangular(3.1, 1.2, 0.5)):
        for e in (0.05, 1.0):
            ref = layered_transfer_hp(p, e * Q_E).log_transmission
            got = S.converged_transmission(p, e * Q_E, rtol_log=1e-8)["log_transmission"]
            worst = max(worst, abs(got - ref) / max(1.0, abs(ref)))
    return worst < 1e-7, worst, "< 1e-7 rel.", "converged S-matrix vs 60-digit Airy transfer matrices"


def c15_reproducibility():
    from .sensitivity import Distribution, monte_carlo
    model = lambda p: {"logT": float(rectangular_transmission(1.0 * Q_E, p["V"] * Q_E, p["a"] * 1e-9, 0.5 * M_E)
                                     .log_transmission[0])}
    d = [Distribution("V", "uniform", (2.9, 3.3), 3.1), Distribution("a", "uniform", (1.0, 2.0), 1.5)]
    a = monte_carlo(model, d, n_samples=50, seed=7)["samples"]
    b = monte_carlo(model, d, n_samples=50, seed=7)["samples"]
    same = bool(a.equals(b))
    s1 = S.transmission(_rect(), np.linspace(0.1, 5, 40) * Q_E).transmission
    s2 = S.transmission(_rect(), np.linspace(0.1, 5, 40) * Q_E).transmission
    ok = same and bool(np.array_equal(s1, s2))
    return ok, int(ok), "bitwise identical", "seeded Monte Carlo + repeated solver calls"


def c16_invalid():
    cases = [
        lambda: rectangular_transmission(0.0, 1.0, 1e-9, M_E),
        lambda: rectangular_transmission(1.0, 1.0, -1e-9, M_E),
        lambda: S.transmission(_rect(), -1e-20),
        lambda: FD.solve(_rect(), 0.0),
        lambda: W.wkb(_rect(), float("nan")),
        lambda: B.from_samples([0, 1], [0, 1], 0.5, energy_reference=""),
        lambda: B.Layer(1e-9, 0.0, 0.0, -1.0),
    ]
    rejected = 0
    for c in cases:
        try:
            c()
        except ValueError:
            rejected += 1
    return rejected == len(cases), f"{rejected}/{len(cases)}", "all rejected with ValueError", \
        "E<=0, negative width/mass, NaN, missing energy reference"


def c17_edges():
    a, V0, m = 1.5e-9, 3.1 * Q_E, 0.5 * M_E
    at = rectangular_transmission(V0, V0, a, m).transmission[0]
    ref = 1.0 / (1.0 + m * a**2 * V0 / (2 * HBAR**2))
    e1 = abs(at - ref) / ref
    E = np.linspace(0.07, 0.09, 4001) * Q_E
    peak = float(S.transmission(B.double_barrier(0.3, 1.0, 5.0, 0.067), E).transmission.max())
    above = W.wkb(B.rectangular(1.0, 1.0, 0.5), 1.5 * Q_E)
    ok = e1 < 1e-13 and peak > 0.9999 and W.WKBFlag.ABOVE_BARRIER in above.flags and np.isnan(above.transmission)
    return ok, f"E=V0 err {e1:.2g}; resonance peak {peak:.6f}", "E=V0 exact, T_res>0.9999, WKB above-barrier flagged", \
        "barrier top, resonant double barrier, above-barrier WKB refusal"


def c18_regression():
    from ..reference import regression_values as RV
    worst, details = RV.compare()
    return worst < 1e-10, worst, "< 1e-10 rel. vs stored values", details


CHECKS: list[tuple[int, str, Callable]] = [
    (1, "Exact rectangular-barrier reference", c01_exact_reference),
    (2, "Thin-barrier limit", c02_thin_limit),
    (3, "Wide-barrier limit", c03_wide_limit),
    (4, "Correct potential-energy units", c04_units),
    (5, "Correct effective-mass handling", c05_mass),
    (6, "Correct flux normalisation", c06_flux),
    (7, "Probability-current conservation", c07_current),
    (8, "0 <= T <= 1 for passive lossless models", c08_bounds),
    (9, "R + T -> 1", c09_rt_unity),
    (10, "Grid convergence", c10_grid),
    (11, "Energy-grid convergence", c11_energy_grid),
    (12, "WKB vs numerical discrepancy", c12_wkb_discrepancy),
    (13, "Thick-barrier numerical stability", c13_thick),
    (14, "High-precision reference comparison", c14_high_precision),
    (15, "Reproducibility", c15_reproducibility),
    (16, "Invalid-input rejection", c16_invalid),
    (17, "Edge-case validation", c17_edges),
    (18, "Numerical regression tests", c18_regression),
]


def run_all() -> list[CheckResult]:
    out = []
    for num, name, fn in CHECKS:
        t0 = time.perf_counter()
        try:
            ok, val, thr, det = fn()
        except Exception as exc:  # a crash is a reported failure, not a skipped check
            ok, val, thr, det = False, "EXCEPTION", "-", f"{type(exc).__name__}: {exc}"
        out.append(CheckResult(num, name, bool(ok), val if isinstance(val, str) else float(val), thr, det,
                               time.perf_counter() - t0))
    return out


def write_report(results: list[CheckResult], out_dir: str | Path) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    n_pass = sum(r.passed for r in results)
    (out / "validation.json").write_text(json.dumps({"passed": n_pass, "total": len(results),
                                                     "checks": [asdict(r) for r in results]}, indent=2))
    lines = ["# Numerical validation report", "",
             "Origin of every number: PYTHON MODEL (this package) compared with the stated reference.", "",
             f"**{n_pass} / {len(results)} checks passed.**", "",
             "| # | Check | Result | Value | Threshold | Detail |", "|---|---|---|---|---|---|"]
    for r in results:
        v = r.value if isinstance(r.value, str) else f"{r.value:.3g}"
        lines.append(f"| {r.number} | {r.name} | {'PASS' if r.passed else '**FAIL**'} | {v} | {r.threshold} | {r.detail} |")
    (out / "VALIDATION.md").write_text("\n".join(lines) + "\n")
    return {"passed": n_pass, "total": len(results)}


__all__ = ["CheckResult", "CHECKS", "run_all", "write_report"]
