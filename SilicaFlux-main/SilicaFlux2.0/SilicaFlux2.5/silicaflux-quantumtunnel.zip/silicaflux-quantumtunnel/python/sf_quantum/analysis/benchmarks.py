"""Performance benchmarks (brief section 35).

Python numbers are measured here (``time.perf_counter``, ``tracemalloc`` peak).
RTL / FPGA / ASIC numbers are *read* from the RTL-simulation and synthesis
reports produced by real tools; nothing is estimated by hand and missing
reports are stated as missing.
"""

from __future__ import annotations

import json
import platform
import time
import tracemalloc
from pathlib import Path

import numpy as np

from ..provenance import PROJECT_ROOT, make_metadata
from ..quantum import barriers as B
from ..quantum import scattering as S
from ..quantum import schrodinger as FD
from ..quantum import wkb as W
from ..quantum.constants import M_E, Q_E
from ..quantum.rectangular import rectangular_transmission


def _time(fn, repeat: int = 5, number: int = 1) -> float:
    best = float("inf")
    for _ in range(repeat):
        t0 = time.perf_counter()
        for _ in range(number):
            fn()
        best = min(best, (time.perf_counter() - t0) / number)
    return best


def _peak_mem(fn) -> float:
    tracemalloc.start()
    fn()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return peak / 2**20


def python_benchmarks() -> dict:
    rect = B.rectangular(3.1, 1.5, 0.5)
    trap = B.trapezoidal(3.1, 1.1, 2.0, 0.5)
    E1 = 1.0 * Q_E
    Ev = np.linspace(0.01, 5.0, 2000) * Q_E
    Ebig = np.linspace(0.01, 5.0, 100_000) * Q_E
    res = {}
    t = _time(lambda: rectangular_transmission(Ebig, 3.1 * Q_E, 1.5e-9, 0.5 * M_E), repeat=3)
    res["exact_rectangular_vectorised"] = {"seconds_per_energy": t / Ebig.size, "energies_per_second": Ebig.size / t}
    res["exact_rectangular_single"] = {"seconds": _time(lambda: rectangular_transmission(E1, 3.1 * Q_E, 1.5e-9, 0.5 * M_E), number=200)}
    res["wkb_single_with_diagnostics"] = {"seconds": _time(lambda: W.wkb(trap, E1), number=200)}
    t = _time(lambda: W.wkb_action_array(trap, Ebig), repeat=3)
    res["wkb_action_vectorised"] = {"seconds_per_energy": t / Ebig.size, "energies_per_second": Ebig.size / t}
    res["smatrix_single_rectangular"] = {"seconds": _time(lambda: S.transmission(rect, E1), number=100)}
    sl = S.discretize(trap)
    res["smatrix_single_trapezoid"] = {"seconds": _time(lambda: S.transmission(trap, E1, sliced=sl), number=20),
                                       "slices": sl.n_slices}
    t = _time(lambda: S.transmission(trap, Ev, sliced=sl), repeat=3)
    res["smatrix_spectrum_2000E"] = {"seconds": t, "energies_per_second": Ev.size / t, "slices": sl.n_slices}
    t = _time(lambda: FD.solve(trap, Ev[:200]), repeat=3)
    res["fd_spectrum_200E"] = {"seconds": t, "energies_per_second": 200 / t}
    from ..analysis.sweeps import thickness_sweep
    from ..devices.materials import SIO2
    t0 = time.perf_counter()
    thickness_sweep(SIO2, np.linspace(0.8, 4.0, 33), energies_eV=(0.05, 0.5, 1.0), fields_MV_per_cm=(0.0, 5.0))
    res["thickness_sweep_33x3x2"] = {"seconds": time.perf_counter() - t0, "solves": 33 * 3 * 2}
    res["peak_memory_MiB"] = {
        "smatrix_spectrum_2000E": _peak_mem(lambda: S.transmission(trap, Ev, sliced=sl)),
        "exact_100k_energies": _peak_mem(lambda: rectangular_transmission(Ebig, 3.1 * Q_E, 1.5e-9, 0.5 * M_E)),
        "wavefunction_2000_points": _peak_mem(lambda: S.wavefunction(trap, E1)),
    }
    return res


def hardware_from_reports() -> dict:
    out = {}
    rtl = PROJECT_ROOT / "reports" / "rtl" / "rtl_verification.json"
    if rtl.exists():
        r = json.loads(rtl.read_text())
        out["rtl"] = [{"config": x["config"], "simulator": x["simulator"], "status": x["status"],
                       "latency_cycles": x["tb_stats"].get("latency"),
                       "initiation_interval": (x["tb_stats"]["phaseA_issue_span"] + 1) / x["tb_stats"]["n"]
                       if x["tb_stats"].get("n") else None,
                       "transactions_per_cycle": x["tb_stats"]["n"] / (x["tb_stats"]["phaseA_issue_span"] + 1)
                       if x["tb_stats"].get("n") else None}
                      for x in r["runs"] if x["status"] != "simulator-unavailable"]
    else:
        out["rtl"] = "missing: run `make quantum-rtl-test`"
    syn = PROJECT_ROOT / "reports" / "synthesis" / "synthesis.json"
    if syn.exists():
        s = json.loads(syn.read_text())
        out["fpga_ecp5"] = {n: {"LUT4": e["ecp5"]["LUT4"], "FF": e["ecp5"]["TRELLIS_FF"], "DSP_MULT18X18D": e["ecp5"]["MULT18X18D"],
                                "BRAM_DP16KD": e["ecp5"]["DP16KD"], "post_route_fmax_MHz": e["ecp5"].get("pnr", {}).get("fmax_mhz")}
                            for n, e in s.get("configs", {}).items()}
        d = s.get("configs", {}).get("default", {})
        out["asic_estimate"] = d.get("asic_nangate45")
        out["generic_cells"] = {n: e["generic"]["cells"] for n, e in s.get("configs", {}).items()}
    else:
        out["fpga_ecp5"] = "missing: run `make quantum-rtl-synth`"
    return out


def run(out_dir: str | Path = PROJECT_ROOT / "reports" / "benchmarks") -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    py = python_benchmarks()
    hw = hardware_from_reports()
    meta = make_metadata("benchmarks", inputs={"cpu": platform.processor() or platform.machine()},
                         assumptions=["best of N wall-clock runs, single process", "hardware numbers read from tool reports"])
    (out / "benchmarks.json").write_text(json.dumps({**meta, "python": py, "hardware": hw}, indent=2, default=str))
    L = ["# Performance benchmarks", "",
         f"Python measured on `{platform.machine()}`, {platform.python_version()} (best-of-N wall clock).", "",
         "| Python benchmark | result |", "|---|---|"]
    L += [f"| exact rectangular, vectorised | {py['exact_rectangular_vectorised']['energies_per_second']:.3g} energies/s |",
          f"| exact rectangular, single call | {py['exact_rectangular_single']['seconds'] * 1e6:.1f} us |",
          f"| WKB with full diagnostics, single | {py['wkb_single_with_diagnostics']['seconds'] * 1e6:.1f} us |",
          f"| WKB action, vectorised | {py['wkb_action_vectorised']['energies_per_second']:.3g} energies/s |",
          f"| S-matrix rectangular, single energy | {py['smatrix_single_rectangular']['seconds'] * 1e6:.1f} us |",
          f"| S-matrix trapezoid ({py['smatrix_single_trapezoid']['slices']} slices), single energy | {py['smatrix_single_trapezoid']['seconds'] * 1e3:.2f} ms |",
          f"| S-matrix spectrum, 2000 energies | {py['smatrix_spectrum_2000E']['seconds']:.3f} s ({py['smatrix_spectrum_2000E']['energies_per_second']:.3g} E/s) |",
          f"| finite-difference spectrum, 200 energies | {py['fd_spectrum_200E']['seconds']:.3f} s |",
          f"| thickness sweep (198 solves) | {py['thickness_sweep_33x3x2']['seconds']:.2f} s |"]
    L += [f"| peak memory: {k} | {v:.1f} MiB |" for k, v in py["peak_memory_MiB"].items()]
    L += ["", "## RTL (RTL SIMULATION)", ""]
    if isinstance(hw["rtl"], list):
        L += ["| config | simulator | latency (cycles) | II | transactions/cycle |", "|---|---|---|---|---|"]
        L += [f"| {r['config']} | {r['simulator']} | {r['latency_cycles']} | {r['initiation_interval']:.3f} | "
              f"{r['transactions_per_cycle']:.3f} |" for r in hw["rtl"]]
    else:
        L.append(hw["rtl"])
    L += ["", "## FPGA (SYNTHESIS + POST-ROUTE, Lattice ECP5 LFE5U-85F)", ""]
    if isinstance(hw["fpga_ecp5"], dict):
        L += ["| config | LUT4 | FF | DSP (MULT18X18D) | BRAM (DP16KD) | post-route Fmax (MHz) |", "|---|---|---|---|---|---|"]
        L += [f"| {n} | {v['LUT4']} | {v['FF']} | {v['DSP_MULT18X18D']} | {v['BRAM_DP16KD']} | {v['post_route_fmax_MHz']} |"
              for n, v in hw["fpga_ecp5"].items()]
        a = hw.get("asic_estimate")
        if a and a.get("cell_area_um2"):
            L += ["", "## ASIC (PRE-LAYOUT ESTIMATE, NanGate45 OCL typical)", "",
                  f"cells {a['cells']}, cell area {a['cell_area_um2']:.0f} um^2, ABC logic delay {a['abc_critical_delay_ps']:.0f} ps. "
                  "No STA, no power (tools unavailable)."]
    else:
        L.append(hw["fpga_ecp5"])
    (out / "BENCHMARKS.md").write_text("\n".join(L) + "\n")
    return {"python": py, "hardware": hw}


__all__ = ["run", "python_benchmarks", "hardware_from_reports"]
