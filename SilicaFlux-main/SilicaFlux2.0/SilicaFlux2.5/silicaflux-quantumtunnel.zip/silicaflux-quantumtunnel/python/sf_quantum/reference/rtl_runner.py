"""Build, run and compare the SystemVerilog accelerator against the golden reference.

``run_config`` compiles ``tests/rtl/tb_sf_quantum_tunnel_core.sv`` with Icarus
or Verilator for one RTL configuration, runs it, parses the response trace and
reports:

* bit-exact agreement with :func:`fixed_point_model.evaluate` (required),
* RTL vs double-precision WKB: absolute T error, relative T error (where
  T > 1e-6), ln T error, max / mean, worst-case parameter combination,
* whether every error lies inside its per-vector error budget,
* latency, initiation interval and throughput measured in simulation.

Failing vectors are listed, never dropped. If no simulator is installed the
result says so explicitly (``status = "simulator-unavailable"``) instead of
claiming success.
"""

from __future__ import annotations

import json
import math
import re
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..provenance import PROJECT_ROOT, make_metadata
from . import fixed_point_model as FP

RTL_FILES = [
    "rtl/quantum/sf_qt_pkg.sv",
    "rtl/quantum/generated/sf_qt_exp_rom_l8_m34.sv",
    "rtl/quantum/generated/sf_qt_exp_rom_l8_m26.sv",
    "rtl/quantum/vendor/sfx_skid_buffer.sv",
    "rtl/quantum/sf_qt_fixed_mul.sv",
    "rtl/quantum/sf_qt_sqrt.sv",
    "rtl/quantum/sf_qt_exp_lut.sv",
    "rtl/quantum/sf_quantum_tunnel_core.sv",
]
TB = "tests/rtl/tb_sf_quantum_tunnel_core.sv"
INCLUDE = "rtl/quantum/generated"


@dataclass(frozen=True)
class RTLConfig:
    name: str
    vector_set: str
    data_w: int = 32
    frac_w: int = 16
    exp_mode: int = 1
    sqrt_bps: int = 1
    pipe_mul: int = 1

    def defines(self) -> dict[str, str]:
        return {"SF_QT_DATA_W": str(self.data_w), "SF_QT_FRAC_W": str(self.frac_w),
                "SF_QT_EXP_MODE": str(self.exp_mode), "SF_QT_SQRT_BPS": str(self.sqrt_bps),
                "SF_QT_PIPE_MUL": str(self.pipe_mul),
                "SF_QT_VEC_DIR": f'"vectors/{self.vector_set}"'}


CONFIGS = {
    "default": RTLConfig("default", "sf_qt_core_v1"),
    "bps5": RTLConfig("bps5", "sf_qt_core_v1", sqrt_bps=5),
    "nopipe": RTLConfig("nopipe", "sf_qt_core_v1", pipe_mul=0),
    "direct": RTLConfig("direct", "sf_qt_core_direct_v1", exp_mode=0),
    "w24": RTLConfig("w24", "sf_qt_core_w24_v1", data_w=24),
}


def available_simulators() -> dict[str, str | None]:
    return {"iverilog": shutil.which("iverilog"), "vvp": shutil.which("vvp"), "verilator": shutil.which("verilator")}


def _build_and_run(cfg: RTLConfig, simulator: str, seed: int, build: Path) -> tuple[str, Path, float]:
    root = PROJECT_ROOT
    build.mkdir(parents=True, exist_ok=True)
    out = build / f"results_{cfg.name}_{simulator}_seed{seed}.txt"
    srcs = [str(root / f) for f in RTL_FILES] + [str(root / TB)]
    inc = [f"-I{root / INCLUDE}", f"-I{root / 'vectors' / cfg.vector_set}"]
    t0 = time.perf_counter()
    if simulator == "iverilog":
        vvp = build / f"tb_{cfg.name}.vvp"
        cmd = ["iverilog", "-g2012", "-s", "tb_sf_quantum_tunnel_core", "-o", str(vvp), *inc,
               *[f"-D{k}={v}" for k, v in cfg.defines().items()], *srcs]
        c = subprocess.run(cmd, cwd=root, capture_output=True, text=True)
        if c.returncode != 0:
            raise RuntimeError(f"iverilog compile failed:\n{c.stderr}")
        r = subprocess.run(["vvp", "-n", str(vvp), f"+seed={seed}", f"+outfile={out}"], cwd=root,
                           capture_output=True, text=True, timeout=1800)
    elif simulator == "verilator":
        mdir = build / f"vl_{cfg.name}"
        cmd = ["verilator", "--binary", "--timing", "-j", "2", "-Wno-fatal", "-Wno-lint", "-Wno-style",
               "--top-module", "tb_sf_quantum_tunnel_core", "-Mdir", str(mdir), "-o", "tb", *inc,
               *[f"-D{k}={v}" for k, v in cfg.defines().items()], *srcs]
        c = subprocess.run(cmd, cwd=root, capture_output=True, text=True)
        if c.returncode != 0:
            raise RuntimeError(f"verilator build failed:\n{c.stderr[-4000:]}")
        r = subprocess.run([str(mdir / "tb"), f"+seed={seed}", f"+outfile={out}"], cwd=root, capture_output=True,
                           text=True, timeout=1800)
    else:
        raise ValueError(f"unknown simulator {simulator}")
    return r.stdout + r.stderr, out, time.perf_counter() - t0


def _parse_stats(log: str) -> dict:
    m = re.search(r"SF_QT_STATS (.*)", log)
    stats = {}
    if m:
        for kv in m.group(1).split():
            k, v = kv.split("=")
            stats[k] = int(v)
    stats["tb_result"] = "PASS" if "SFX_TB_RESULT: PASS" in log else "FAIL"
    return stats


def compare(cfg: RTLConfig, results_file: Path) -> dict:
    """Bit-exact and accuracy comparison of an RTL trace against the golden vectors."""
    vec = json.loads((PROJECT_ROOT / "vectors" / cfg.vector_set / "vectors.json").read_text())
    recs = vec["vectors"]
    hwcfg = FP.HWConfig(**{k: v for k, v in vec["solver_settings"]["hw_config"].items()
                           if k in FP.HWConfig.__dataclass_fields__})
    W, F = hwcfg.data_w, hwcfg.frac_w
    bit_mismatch, rows = [], []
    for line in results_file.read_text().split("\n"):
        if not line.strip():
            continue
        phase, idx, tag, log_h, t_h, err, warn, lat = line.split()
        idx = int(idx)
        r = recs[idx]
        log_code, t_code = int(log_h, 16), int(t_h, 16)
        x = r["expected_hw"]
        if (log_code, t_code, int(err), int(warn)) != (x["log_code"], x["t_code"], x["err"], x["warn"]):
            bit_mismatch.append({"phase": int(phase), "index": idx, "name": r["name"]})
        if int(phase) != 1:
            continue
        rows.append((idx, log_code, t_code, int(err), int(warn), int(lat)))
    # accuracy versus double precision (phase-A responses, valid tunnelling cases only)
    abs_t, rel_t, abs_log, ratio_log, ratio_t, worst = [], [], [], [], [], None
    outside_budget = []
    for idx, log_code, t_code, err, warn, lat in rows:
        r = recs[idx]
        if err & (FP.ERR_INVALID | FP.ERR_ABOVE):
            continue
        ref = r["reference"]
        log_v = FP.to_signed(log_code, W) / (1 << F)
        t_v = t_code / (1 << W)
        if err & FP.ERR_LOG_SAT:
            continue  # saturated log is a reported range limit, not an accuracy sample
        el = abs(log_v - ref["log_transmission"])
        et = abs(t_v - ref["transmission"])
        abs_log.append(el)
        abs_t.append(et)
        if ref["transmission"] > 1e-6:
            rel_t.append(et / ref["transmission"])
        tol = r["tolerance"]
        ratio_log.append(el / tol["log_transmission_abs"])
        ratio_t.append(et / tol["transmission_abs"])
        if el > tol["log_transmission_abs"] or et > tol["transmission_abs"]:
            outside_budget.append({"index": idx, "name": r["name"], "log_err": el, "t_err": et, "tolerance": tol})
        if worst is None or el > worst["log_err"]:
            worst = {"index": idx, "name": r["name"], "inputs": r["inputs"], "log_err": el, "t_err": et,
                     "ref_logT": ref["log_transmission"]}
    valid = [recs[i] for i, *_ in rows if not (recs[i]["expected_hw"]["err"] & (FP.ERR_INVALID | FP.ERR_ABOVE))]
    rng = {k: [min(v["inputs"][k] for v in valid), max(v["inputs"][k] for v in valid)]
           for k in ("V0_eV", "E_eV", "A_nm", "M_rel")} if valid else {}
    def s(a):
        return {"max": float(np.max(a)), "mean": float(np.mean(a)), "p99": float(np.quantile(a, 0.99))} if a else None
    counts = {"responses_checked": len(rows), "valid_tunnelling": len(abs_log),
              "invalid": sum(1 for i, *_ in rows if recs[i]["expected_hw"]["err"] & FP.ERR_INVALID),
              "above_barrier": sum(1 for i, *_ in rows if recs[i]["expected_hw"]["err"] & FP.ERR_ABOVE),
              "log_saturated": sum(1 for i, *_ in rows if recs[i]["expected_hw"]["err"] & FP.ERR_LOG_SAT),
              "tx_underflow": sum(1 for i, *_ in rows if recs[i]["expected_hw"]["warn"] & FP.WARN_TX_UNDER),
              "wkb_weak": sum(1 for i, *_ in rows if recs[i]["expected_hw"]["warn"] & FP.WARN_WKB_WEAK)}
    return {
        "bit_exact": not bit_mismatch, "bit_mismatches": bit_mismatch[:50], "n_bit_mismatches": len(bit_mismatch),
        "counts": counts,
        "abs_logT_error": s(abs_log), "abs_T_error": s(abs_t), "rel_T_error_where_T_gt_1e-6": s(rel_t),
        "max_error_over_budget_logT": float(max(ratio_log)) if ratio_log else None,
        "max_error_over_budget_T": float(max(ratio_t)) if ratio_t else None,
        "outside_budget": outside_budget, "worst_case_logT": worst,
        "validated_operating_range": {"inputs": rng, "note": "range spanned by valid vectors that met their budget; "
                                      "accuracy outside it is not claimed"},
        "vector_set": cfg.vector_set, "vector_sha256": vec["content_sha256"],
    }


def run_config(name: str = "default", simulator: str = "iverilog", seed: int = 20261115,
               build: str | Path | None = None) -> dict:
    cfg = CONFIGS[name]
    sims = available_simulators()
    need = ["iverilog", "vvp"] if simulator == "iverilog" else ["verilator"]
    if not all(sims[n] for n in need):
        return {"config": name, "simulator": simulator, "status": "simulator-unavailable",
                "message": f"{simulator} not found on PATH -- RTL verification gate NOT run"}
    build = Path(build) if build else PROJECT_ROOT / "build" / "rtl"
    log, out, secs = _build_and_run(cfg, simulator, seed, build)
    stats = _parse_stats(log)
    cmp_ = compare(cfg, out) if out.exists() else {"bit_exact": False, "error": "no results file"}
    passed = stats.get("tb_result") == "PASS" and cmp_.get("bit_exact") and not cmp_.get("outside_budget")
    return {"config": name, "simulator": simulator, "seed": seed, "status": "pass" if passed else "fail",
            "rtl_parameters": cfg.__dict__, "tb_stats": stats, "comparison": cmp_, "wall_seconds": secs,
            "results_file": str(out.relative_to(PROJECT_ROOT)) if out.is_relative_to(PROJECT_ROOT) else str(out),
            "log_tail": log.strip().splitlines()[-4:]}


INTEGRATOR_FILES = [f for f in RTL_FILES if not f.endswith("sf_quantum_tunnel_core.sv")] + ["rtl/quantum/sf_qt_integrator.sv"]


def run_integrator(simulator: str = "iverilog", build: str | Path | None = None) -> dict:
    """Sampled-profile integrator regression + comparison with discrete and continuous references."""
    sims = available_simulators()
    need = ["iverilog", "vvp"] if simulator == "iverilog" else ["verilator"]
    if not all(sims[n] for n in need):
        return {"config": "integrator", "simulator": simulator, "status": "simulator-unavailable"}
    root = PROJECT_ROOT
    build = Path(build) if build else root / "build" / "rtl"
    build.mkdir(parents=True, exist_ok=True)
    out = build / f"integrator_{simulator}.txt"
    srcs = [str(root / f) for f in INTEGRATOR_FILES] + [str(root / "tests/rtl/tb_sf_qt_integrator.sv")]
    inc = [f"-I{root / INCLUDE}", f"-I{root / 'vectors' / 'sf_qt_integrator_v1'}"]
    t0 = time.perf_counter()
    if simulator == "iverilog":
        vvp = build / "tb_integrator.vvp"
        c = subprocess.run(["iverilog", "-g2012", "-s", "tb_sf_qt_integrator", "-o", str(vvp), *inc, *srcs],
                           cwd=root, capture_output=True, text=True)
        if c.returncode:
            raise RuntimeError(c.stderr)
        r = subprocess.run(["vvp", "-n", str(vvp), f"+outfile={out}"], cwd=root, capture_output=True, text=True, timeout=1800)
    else:
        mdir = build / "vl_integrator"
        c = subprocess.run(["verilator", "--binary", "--timing", "-j", "2", "-Wno-fatal", "-Wno-lint", "-Wno-style",
                            "--top-module", "tb_sf_qt_integrator", "-Mdir", str(mdir), "-o", "tb", *inc, *srcs],
                           cwd=root, capture_output=True, text=True)
        if c.returncode:
            raise RuntimeError(c.stderr[-3000:])
        r = subprocess.run([str(mdir / "tb"), f"+outfile={out}"], cwd=root, capture_output=True, text=True, timeout=1800)
    log = r.stdout + r.stderr
    m = re.search(r"SF_QT_INT_STATS (.*)", log)
    stats = {k: int(v) for k, v in (kv.split("=") for kv in m.group(1).split())} if m else {}
    vec = json.loads((root / "vectors" / "sf_qt_integrator_v1" / "vectors.json").read_text())["profiles"]
    mismatch, rows, outside = [], [], []
    for line in out.read_text().splitlines():
        idx, lg, t, err, warn = line.split()
        p = vec[int(idx)]
        x = p["expected_hw"]
        lc, tc = int(lg, 16), int(t, 16)
        if (lc, tc, int(err), int(warn)) != (x["log_code"], x["t_code"], x["err"], x["warn"]):
            mismatch.append(p["name"])
        if int(err) & 3 or int(err) & 4:
            continue
        ref = p["reference_discrete"]
        el = abs(FP.to_signed(lc, 32) / 65536 - ref["log_t"])
        et = abs(tc / 2**32 - ref["t"])
        if el > p["tolerance"]["log_t"] or et > p["tolerance"]["t"]:
            outside.append(p["name"])
        rows.append({"name": p["name"], "n_samples": p["n_samples"], "abs_dlogT_vs_discrete": el,
                     "ratio_to_budget": el / p["tolerance"]["log_t"],
                     "discretisation_error_2S": p["discretisation_error_2S"]})
    passed = "SFX_TB_RESULT: PASS" in log and not mismatch and not outside
    return {"config": "integrator", "simulator": simulator, "status": "pass" if passed else "fail", "tb_stats": stats,
            "bit_exact": not mismatch, "mismatches": mismatch, "outside_budget": outside, "profiles": rows,
            "max_abs_dlogT_vs_discrete": max((r["abs_dlogT_vs_discrete"] for r in rows), default=None),
            "max_ratio_to_budget": max((r["ratio_to_budget"] for r in rows), default=None),
            "results_file": str(out), "wall_seconds": time.perf_counter() - t0}


def run_all(out_dir: str | Path = PROJECT_ROOT / "reports" / "rtl", seed: int = 20261115) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    runs = [run_config("default", "iverilog", seed), run_config("default", "verilator", seed),
            run_config("bps5", "iverilog", seed), run_config("nopipe", "iverilog", seed),
            run_config("direct", "iverilog", seed),
            run_config("w24", "iverilog", seed), run_config("default", "iverilog", seed + 1)]
    # cross-simulator determinism: identical traces for the same seed
    det = None
    a, b = runs[0], runs[1]
    if a["status"] != "simulator-unavailable" and b["status"] != "simulator-unavailable":
        det = (PROJECT_ROOT / a["results_file"]).read_bytes() == (PROJECT_ROOT / b["results_file"]).read_bytes()
    integ = [run_integrator("iverilog"), run_integrator("verilator")]
    if all(i["status"] != "simulator-unavailable" for i in integ):
        integ_det = Path(integ[0]["results_file"]).read_bytes() == Path(integ[1]["results_file"]).read_bytes()
    else:
        integ_det = None
    summary = {"all_pass": all(r["status"] == "pass" for r in runs + integ if r["status"] != "simulator-unavailable"),
               "integrator": integ, "integrator_cross_simulator_identical": integ_det,
               "unavailable": [f"{r['config']}/{r['simulator']}" for r in runs + integ
                               if r["status"] == "simulator-unavailable"],
               "cross_simulator_identical_traces": det, "runs": runs}
    meta = make_metadata("RTL verification", inputs={"configs": list(CONFIGS)}, assumptions=[
        "SV testbench + Python comparison", "label: RTL SIMULATION (Icarus Verilog / Verilator)"],
        rtl_configuration={k: v.__dict__ for k, v in CONFIGS.items()}, testbench_seed=seed,
        validation={"all_pass": summary["all_pass"], "cross_simulator_identical": det})
    (out / "rtl_verification.json").write_text(json.dumps({**meta, **summary}, indent=2, default=str))
    (out / "RTL_VERIFICATION.md").write_text(_markdown(summary))
    return summary


def _fmt(x, f="{:.3g}"):
    return "-" if x is None else f.format(x)


def _markdown(summary: dict) -> str:
    L = ["# RTL verification report", "",
         "Origin: **RTL SIMULATION** of `rtl/quantum/sf_quantum_tunnel_core.sv` (Icarus Verilog 12 / Verilator 5) "
         "compared with the Python golden reference.", "",
         f"All runs pass: **{summary['all_pass']}**. Cross-simulator identical traces: "
         f"**{summary['cross_simulator_identical_traces']}**.", ""]
    if summary["unavailable"]:
        L += [f"Missing verification gates (simulator unavailable): {', '.join(summary['unavailable'])}", ""]
    L += ["| config | sim | seed | status | vectors | bit-exact | latency (cyc) | II | max abs ln T err | "
          "mean abs ln T err | max rel T err (T>1e-6) | max err/budget (lnT, T) |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in summary["runs"]:
        if r["status"] == "simulator-unavailable":
            L.append(f"| {r['config']} | {r['simulator']} | - | UNAVAILABLE | - | - | - | - | - | - | - | - |")
            continue
        c, t = r["comparison"], r["tb_stats"]
        ii = (t.get("phaseA_issue_span", 0) + 1) / t["n"] if t.get("n") else None
        L.append(f"| {r['config']} | {r['simulator']} | {r['seed']} | {r['status'].upper()} | {t.get('n')} | "
                 f"{c['bit_exact']} | {t.get('latency')} | {_fmt(ii, '{:.3f}')} | "
                 f"{_fmt(c['abs_logT_error']['max'] if c['abs_logT_error'] else None)} | "
                 f"{_fmt(c['abs_logT_error']['mean'] if c['abs_logT_error'] else None)} | "
                 f"{_fmt(c['rel_T_error_where_T_gt_1e-6']['max'] if c['rel_T_error_where_T_gt_1e-6'] else None)} | "
                 f"{_fmt(c['max_error_over_budget_logT'])}, {_fmt(c['max_error_over_budget_T'])} |")
    L += ["", "## Worst-case parameter combinations (ln T)", ""]
    for r in summary["runs"]:
        if r["status"] == "simulator-unavailable" or not r["comparison"].get("worst_case_logT"):
            continue
        w = r["comparison"]["worst_case_logT"]
        L.append(f"- `{r['config']}/{r['simulator']}/seed {r['seed']}`: vector {w['index']} ({w['name']}): inputs {w['inputs']}, "
                 f"|d lnT| = {w['log_err']:.3g} at ln T = {w['ref_logT']:.4g}")
    L += ["", "## Coverage counts (phase A)", ""]
    for r in summary["runs"]:
        if r["status"] != "simulator-unavailable":
            L.append(f"- `{r['config']}/{r['simulator']}`: {r['comparison']['counts']}")
    L += ["", "## Sampled-profile integrator (`sf_qt_integrator`)", ""]
    for i in summary.get("integrator", []):
        if i["status"] == "simulator-unavailable":
            L.append(f"- {i['simulator']}: UNAVAILABLE (gate not run)")
            continue
        t = i["tb_stats"]
        L.append(f"- {i['simulator']}: **{i['status'].upper()}** -- {t.get('profiles')} profiles / {t.get('samples')} samples, "
                 f"bit-exact {i['bit_exact']}, II = {(t.get('sample_issue_span', 0) + 1) / max(t.get('samples', 1), 1):.3f} "
                 f"sample/cycle, max |d lnT| vs discrete reference {i['max_abs_dlogT_vs_discrete']:.3g} "
                 f"(max error/budget {i['max_ratio_to_budget']:.3f})")
    L.append(f"- cross-simulator identical traces: {summary.get('integrator_cross_simulator_identical')}")
    L += ["", "Discretisation error (discrete trapezoid sum vs continuous piecewise-linear WKB, 2S) is a property "
          "of the sampling, not of the hardware; per-profile values are in `rtl_verification.json`.", ""]
    L += ["", "Vectors outside budget and bit mismatches are listed in `rtl_verification.json` "
          "(empty lists mean none occurred).", ""]
    return "\n".join(L)


__all__ = ["RTLConfig", "CONFIGS", "available_simulators", "run_config", "run_all", "compare"]
