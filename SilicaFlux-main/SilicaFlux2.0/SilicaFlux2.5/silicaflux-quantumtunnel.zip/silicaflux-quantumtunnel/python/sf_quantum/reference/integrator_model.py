r"""Bit-accurate model of ``rtl/quantum/sf_qt_integrator.sv`` (sampled-profile WKB).

The hardware accumulates the discretised WKB action of a sampled 1D profile

.. math:: 2S \approx C_1\,\Delta x \sum_i w_i \sqrt{m_i\,\max(V_i - E, 0)}

with **explicitly supplied integration weights** ``w_i`` (e.g. trapezoid:
1/2 at both ends, 1 inside). Two references are kept separate:

* the *discrete* sum in double precision -- what the datapath approximates
  (acceptance: bit-exact RTL vs this model, and this model within
  :func:`error_budget` of the double-precision discrete sum);
* the *continuous* WKB action of the piecewise-linear profile through the
  samples (:mod:`sf_quantum.quantum.wkb`) -- the difference is the
  discretisation error, reported, not hidden, and not part of the hardware
  acceptance.

Formats (F = FRAC_W, G = SQRT_GUARD, SF = F + G): V, E UQ4.F (< 16 eV);
m UQ4.F; w UQ2.F (< 4); dx UQ6.F nm (< 64). s_i as in the core (UQ5.SF);
term_i = w_i s_i exact (F+SF fractional bits); ACC exact; A = round(ACC >> F);
K1, K2 = round(C*dx); 2S = round(K1 A >> (F+2G)); Y = round(K2 A >> SF);
log / T as in the core.

Status: err[0] INVALID (E == 0, dx == 0, any m == 0, any field out of range,
or more than 2^N_MAX_LOG2 samples), err[1] ABOVE (no sample has V > E),
err[2] LOG_SAT; warn[0] WKB_WEAK (2S < 2), warn[1] TX_UNDER,
warn[2] MULTI_REGION (two or more separate forbidden regions: resonant
structure, WKB product ignores interference).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..quantum.constants import HBAR, M_E, Q_E
from . import fixed_point_model as FP

W_IB = 2


@dataclass(frozen=True)
class IntegratorConfig:
    hw: FP.HWConfig = FP.DEFAULT
    n_max_log2: int = 12


DEFAULT = IntegratorConfig()


def evaluate_profile(samples: list[tuple[int, int, int]], e: int, dx: int, cfg: IntegratorConfig = DEFAULT) -> dict:
    """``samples`` = [(V, m, w) codes]. Returns dict(log_code, t_code, err, warn, acc, a, two_s, y)."""
    h = cfg.hw
    W, F, G, SF = h.data_w, h.F, h.G, h.SF
    mask = (1 << W) - 1
    e_lim, m_lim, w_lim, a_lim = 1 << (h.e_ib + F), 1 << (h.m_ib + F), 1 << (W_IB + F), 1 << (h.a_ib + F)
    inv = e == 0 or e >= e_lim or dx == 0 or dx >= a_lim or len(samples) > (1 << cfg.n_max_log2) or len(samples) == 0
    acc = 0
    any_forb = False
    regions = 0
    prev = False
    for v, m, w in samples:
        v, m, w = v & mask, m & mask, w & mask
        inv |= m == 0 or v >= e_lim or m >= m_lim or w >= w_lim
        forb = v > e
        if forb and not prev:
            regions += 1
        prev = forb
        any_forb |= forb
        u = (v - e) if forb else 0
        r = math.isqrt((m * u) << (2 * G + 2))
        s = (r + 1) >> 1
        acc += w * s
    if inv:
        return {"log_code": 0, "t_code": 0, "err": FP.ERR_INVALID, "warn": 0}
    if not any_forb:
        return {"log_code": 0, "t_code": 0, "err": FP.ERR_ABOVE, "warn": 0}
    a = FP.rnd_shift(acc, F)
    c1, c2 = FP.constant_codes(h)
    k1 = FP.rnd_shift(c1 * dx, h.const_frac - G)
    k2 = FP.rnd_shift(c2 * dx, h.const_frac - G)
    two_s = FP.rnd_shift(k1 * a, F + 2 * G)
    y = FP.rnd_shift(k2 * a, SF)
    err, warn = 0, 0
    lim = 1 << (W - 1)
    if two_s > lim:
        log_code = (-lim) & mask
        err |= FP.ERR_LOG_SAT
    else:
        log_code = (-two_s) & mask
    if two_s < (2 << F):
        warn |= FP.WARN_WKB_WEAK
    yi, yf = y >> h.YF, y & ((1 << h.YF) - 1)
    base, delta = FP.exp_rom(h)[yf >> h.R_BITS]
    rem = yf & ((1 << h.R_BITS) - 1)
    mant = base - FP.rnd_shift(delta * rem, h.R_BITS) if h.exp_mode == "interp" else \
        (base - delta if rem >= (1 << (h.R_BITS - 1)) else base)
    t = ((mant >> min(yi + 1, h.SH_MAX)) + 1) >> 1
    t = min(t, mask)
    if t == 0:
        warn |= FP.WARN_TX_UNDER
    if regions >= 2:
        warn |= 4
    return {"log_code": log_code, "t_code": t, "err": err, "warn": warn, "acc": acc, "a": a, "two_s": two_s, "y": y}


def discrete_reference(samples, e, dx, cfg: IntegratorConfig = DEFAULT) -> dict:
    F = cfg.hw.F
    E, DX = e / (1 << F), dx / (1 << F)
    tot = 0.0
    wsum = 0.0
    for v, m, w in samples:
        V, M, Wt = v / (1 << F), m / (1 << F), w / (1 << F)
        wsum += Wt
        if V > E:
            tot += Wt * math.sqrt(M * (V - E))
    two_s = 2.0 * (DX * 1e-9) * math.sqrt(2 * M_E * Q_E) / HBAR * tot
    return {"two_s": two_s, "log_t": -two_s, "t": math.exp(-two_s), "weighted_sqrt_sum": tot, "weight_sum": wsum}


def error_budget(samples, e, dx, cfg: IntegratorConfig = DEFAULT) -> dict:
    """|hardware - discrete double| bounds (same derivation as the core, with s -> A)."""
    h = cfg.hw
    F, SF = h.F, h.SF
    ref = discrete_reference(samples, e, dx, cfg)
    DX = dx / (1 << F)
    c1q, c2q = (c / (1 << h.const_frac) for c in FP.constant_codes(h))
    e_s = 2.0 ** -(SF + 1)
    e_a = ref["weight_sum"] * e_s + 2.0 ** -(SF + 1)
    A = ref["weighted_sqrt_sum"]
    e_k1 = 2.0 ** -(SF + 1) + DX * abs(c1q - FP.c1_physical())
    e_k2 = 2.0 ** -(SF + 1) + DX * abs(c2q - FP.c2_physical())
    k1, k2 = FP.c1_physical() * DX, FP.c2_physical() * DX
    b_2s = k1 * e_a + A * e_k1 + e_a * e_k1 + 2.0 ** -(F + 1)
    b_y = k2 * e_a + A * e_k2 + e_a * e_k2 + 2.0 ** -(SF + 1)
    hstep = 2.0 ** -h.lut_bits
    e_mant = (math.log(2) ** 2) * hstep * hstep / 8.0 + 2.0 ** -h.MANT_F
    y_true = ref["two_s"] * math.log2(math.e)
    b_t = ref["t"] * (2.0 ** b_y - 1.0) + 2.0 ** (-max(math.floor(y_true - b_y), 0)) * e_mant + 2.0 ** -(h.data_w + 1)
    return {"log_t": 1.01 * b_2s, "t": 1.01 * b_t}


__all__ = ["IntegratorConfig", "DEFAULT", "evaluate_profile", "discrete_reference", "error_budget", "W_IB"]
