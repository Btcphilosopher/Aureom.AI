"""Authoritative golden reference for the SystemVerilog WKB accelerator.

Generates deterministic, versioned test-vector sets. Each vector carries:

* input barrier parameters (physical values and encoded codes),
* input energy,
* reference WKB action and log-transmission (double precision, from the
  package's WKB engine on the *quantised* inputs -- i.e. the physics the
  hardware is meant to approximate),
* reference transmission,
* validity flags (Python WKB diagnostics + expected hardware status bits),
* expected numerical tolerance (the per-vector error budget of
  :func:`~.fixed_point_model.error_budget`),
* the bit-exact expected hardware outputs (:func:`~.fixed_point_model.evaluate`).

Files written to ``vectors/<set_name>/``::

    stimulus.hex   $readmemh: {tag, V0, E, A, M}         one vector per line
    expected.hex   $readmemh: {pad, warn, err, log_T, T}
    n_vectors.svh  `define SF_QT_N_VECTORS <n>
    vectors.json   full metadata + every vector record
    vectors.csv    flat table
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..provenance import make_metadata
from ..quantum.barriers import rectangular
from ..quantum.constants import Q_E
from ..quantum.wkb import wkb
from . import fixed_point_model as FP

VECTOR_FORMAT_VERSION = "1.0.0"
DEFAULT_SEED = 20261115


@dataclass(frozen=True)
class VectorSpec:
    name: str
    v0_eV: float | None = None
    e_eV: float | None = None
    a_nm: float | None = None
    m_rel: float | None = None
    codes: tuple[int, int, int, int] | None = None  # raw codes override (out-of-range tests)


def _directed(cfg: FP.HWConfig) -> list[VectorSpec]:
    lsb = 2.0 ** -cfg.frac_w
    e_max = 2.0 ** cfg.e_ib - lsb
    a_max = 2.0 ** cfg.a_ib - lsb
    m_max = 2.0 ** cfg.m_ib - lsb
    full = (1 << cfg.data_w) - 1
    v = []
    for a in (0.5, 1.0, 1.5, 2.0, 3.0, 5.0):
        for e in (0.05, 0.5, 1.0, 2.0, 3.0):
            v.append(VectorSpec(f"SiO2-like V0=3.1 E={e} a={a}", 3.1, e, a, 0.5))
    for a in (1.0, 2.0, 4.0):
        v.append(VectorSpec(f"HfO2-like V0=1.4 E=0.05 a={a}", 1.4, 0.05, a, 0.2))
    v += [
        VectorSpec("high barrier", 15.9, 0.01, 1.0, 0.5),
        VectorSpec("low barrier, light mass", 0.05, 0.01, 1.0, 0.067),
        VectorSpec("zero width -> T=1 saturates", 3.1, 1.0, 0.0, 0.5),
        VectorSpec("1-LSB width", 3.1, 1.0, lsb, 0.5),
        VectorSpec("0.01 nm width", 3.1, 1.0, 0.01, 0.5),
        VectorSpec("maximum action", e_max, lsb, a_max, m_max),
        VectorSpec("max width typical", 3.1, 0.5, a_max, 0.5),
        VectorSpec("1-LSB below barrier", 3.1, 3.1 - lsb, 1.5, 0.5),
        VectorSpec("tiny dE*m: T near 1", lsb * 3, lsb, 0.01, lsb),
        VectorSpec("min mass", 3.1, 0.5, 1.5, lsb),
        VectorSpec("max mass", 3.1, 0.5, 1.5, m_max),
        VectorSpec("max energies", e_max, e_max - 0.5, 1.0, 0.5),
        VectorSpec("T just representable", 3.1, 1.0, 4.2, 0.5),
        VectorSpec("T underflow", 3.1, 1.0, 6.0, 0.5),
        VectorSpec("at barrier (E == V0) -> ABOVE", 3.1, 3.1, 1.5, 0.5),
        VectorSpec("above barrier -> ABOVE", 3.1, 3.5, 1.5, 0.5),
        VectorSpec("E = 0 -> INVALID", 3.1, 0.0, 1.5, 0.5),
        VectorSpec("M = 0 -> INVALID", 3.1, 1.0, 1.5, 0.0),
        VectorSpec("V0 out of range -> INVALID", codes=(1 << (cfg.e_ib + cfg.frac_w), 1 << cfg.frac_w,
                                                         1 << cfg.frac_w, 1 << (cfg.frac_w - 1))),
        VectorSpec("A out of range -> INVALID", codes=(3 << cfg.frac_w, 1 << cfg.frac_w,
                                                        1 << (cfg.a_ib + cfg.frac_w), 1 << (cfg.frac_w - 1))),
        VectorSpec("M out of range -> INVALID", codes=(3 << cfg.frac_w, 1 << cfg.frac_w, 1 << cfg.frac_w,
                                                        1 << (cfg.m_ib + cfg.frac_w))),
        VectorSpec("all ones -> INVALID", codes=(full, full, full, full)),
        VectorSpec("all zeros -> INVALID", codes=(0, 0, 0, 0)),
    ]
    return v


def _random(cfg: FP.HWConfig, n: int, seed: int) -> list[VectorSpec]:
    rng = np.random.default_rng(seed)
    out = []
    lsb = 2.0 ** -cfg.frac_w
    e_max = 2.0 ** cfg.e_ib - lsb
    for i in range(n):
        if rng.random() < 0.05:  # raw random codes: robustness, mostly INVALID
            out.append(VectorSpec(f"rand-codes-{i}", codes=tuple(int(x) for x in rng.integers(0, 1 << cfg.data_w, 4))))
            continue
        v0 = rng.uniform(0.02, e_max)
        e = rng.uniform(lsb, 1.1 * v0) if rng.random() < 0.1 else rng.uniform(lsb, v0)
        e = min(e, e_max)
        a = math.exp(rng.uniform(math.log(0.02), math.log(2.0 ** cfg.a_ib - lsb)))
        m = math.exp(rng.uniform(math.log(0.02), math.log(2.0 ** cfg.m_ib - lsb)))
        out.append(VectorSpec(f"rand-{i}", v0, e, a, m))
    return out


def _hexw(x: int, bits: int) -> str:
    return f"{x:0{(bits + 3) // 4}x}"


def build_vector(spec: VectorSpec, idx: int, cfg: FP.HWConfig) -> dict:
    F, W = cfg.frac_w, cfg.data_w
    if spec.codes is not None:
        v0, e, a, m = spec.codes
    else:
        v0, e, a, m = (FP.encode(x, F, W) for x in (spec.v0_eV, spec.e_eV, spec.a_nm, spec.m_rel))
    hw = FP.evaluate(v0, e, a, m, cfg)
    ref = FP.double_reference(v0, e, a, m, cfg)
    budget = FP.error_budget(v0, e, a, m, cfg)
    flags_py: list[str] = []
    if hw.err == 0:
        V0, E, A, M = (x / (1 << F) for x in (v0, e, a, m))
        if A > 0:
            w = wkb(rectangular(V0, A, M), E * Q_E)
            flags_py = [f.value for f in w.flags]
            # the golden action comes from the physics engine itself
            ref_engine = 2.0 * w.action
            assert math.isclose(ref_engine, ref["two_s"], rel_tol=1e-12, abs_tol=1e-12), (ref_engine, ref)
        else:
            flags_py = ["zero_width_no_barrier"]
    tag = idx & ((1 << cfg.tag_w) - 1)
    rec = {
        "index": idx, "name": spec.name, "tag": tag,
        "inputs": {"V0_eV": v0 / (1 << F), "E_eV": e / (1 << F), "A_nm": a / (1 << F), "M_rel": m / (1 << F)},
        "nominal_inputs": None if spec.codes else {"V0_eV": spec.v0_eV, "E_eV": spec.e_eV, "A_nm": spec.a_nm,
                                                    "M_rel": spec.m_rel},
        "codes": {"V0": v0, "E": e, "A": a, "M": m},
        "reference": {"wkb_action": ref["two_s"] / 2 if math.isfinite(ref["two_s"]) else None,
                      "log_transmission": ref["log_t"] if math.isfinite(ref["log_t"]) else None,
                      "transmission": ref["t"] if math.isfinite(ref["t"]) else None},
        "validity": {"python_wkb_flags": flags_py, "hw_err": hw.err, "hw_warn": hw.warn,
                     "wkb_reliable": hw.err == 0 and not ({"weak_tunnelling", "narrow_barrier"} & set(flags_py))},
        "tolerance": {"log_transmission_abs": budget["log_t"], "transmission_abs": budget["t"]},
        "expected_hw": {"log_code": hw.log_code, "log_value": hw.log_value, "t_code": hw.t_code,
                        "t_value": hw.t_value, "err": hw.err, "warn": hw.warn},
    }
    return rec


def generate(set_name: str = "sf_qt_core_v1", *, cfg: FP.HWConfig = FP.DEFAULT, n_random: int = 2000,
             seed: int = DEFAULT_SEED, out_root: str | Path = "vectors") -> dict:
    specs = _directed(cfg) + _random(cfg, n_random, seed)
    recs = [build_vector(s, i, cfg) for i, s in enumerate(specs)]
    W = cfg.data_w
    stim_bits = cfg.tag_w + 4 * W
    exp_bits = 8 + 2 * W
    stim_lines, exp_lines = [], []
    for r in recs:
        c = r["codes"]
        word = (r["tag"] << (4 * W)) | (c["V0"] << (3 * W)) | (c["E"] << (2 * W)) | (c["A"] << W) | c["M"]
        stim_lines.append(_hexw(word, stim_bits))
        x = r["expected_hw"]
        eword = (x["warn"] << (2 * W + 4)) | (x["err"] << (2 * W)) | (x["log_code"] << W) | x["t_code"]
        exp_lines.append(_hexw(eword, exp_bits))
    body = "\n".join(stim_lines) + "\n" + "\n".join(exp_lines)
    digest = hashlib.sha256((json.dumps(cfg.as_dict(), sort_keys=True) + body).encode()).hexdigest()
    header = (f"// SilicaFlux QuantumTunnel golden vectors '{set_name}' format {VECTOR_FORMAT_VERSION}\n"
              f"// sha256 {digest}\n")
    out = Path(out_root) / set_name
    out.mkdir(parents=True, exist_ok=True)
    (out / "stimulus.hex").write_text(header + "\n".join(stim_lines) + "\n")
    (out / "expected.hex").write_text(header + "\n".join(exp_lines) + "\n")
    (out / "n_vectors.svh").write_text(f"`define SF_QT_N_VECTORS {len(recs)}\n")
    meta = make_metadata(
        f"golden vectors {set_name}",
        inputs={"n_directed": len(_directed(cfg)), "n_random": n_random, "seed": seed},
        assumptions=["single rectangular barrier, plain WKB (no interface prefactor)", "identical leads",
                     "reference evaluated on the quantised inputs"],
        solver_settings={"hw_config": cfg.as_dict(), "C1_code": FP.constant_codes(cfg)[0],
                         "C2_code": FP.constant_codes(cfg)[1], "C1_physical": FP.c1_physical()},
        testbench_seed=seed,
    )
    meta.update({"set_name": set_name, "format_version": VECTOR_FORMAT_VERSION, "content_sha256": digest,
                 "stimulus_layout": f"{{tag[{cfg.tag_w}], V0[{W}], E[{W}], A[{W}], M[{W}]}}",
                 "expected_layout": f"{{pad[2], warn[2], err[4], log_T[{W}], T[{W}]}}",
                 "n_vectors": len(recs), "vectors": recs})
    (out / "vectors.json").write_text(json.dumps(meta, indent=1))
    import pandas as pd
    flat = [{"index": r["index"], "name": r["name"], **r["inputs"], **{f"code_{k}": v for k, v in r["codes"].items()},
             "ref_logT": r["reference"]["log_transmission"], "ref_T": r["reference"]["transmission"],
             "hw_logT": r["expected_hw"]["log_value"], "hw_T": r["expected_hw"]["t_value"],
             "err": r["expected_hw"]["err"], "warn": r["expected_hw"]["warn"],
             "tol_logT": r["tolerance"]["log_transmission_abs"], "tol_T": r["tolerance"]["transmission_abs"],
             "python_flags": ";".join(r["validity"]["python_wkb_flags"])} for r in recs]
    pd.DataFrame(flat).to_csv(out / "vectors.csv", index=False)
    return {"dir": str(out), "n_vectors": len(recs), "sha256": digest}


# --------------------------------------------------------------------------- RTL code generation

def generate_rtl_constants(cfg: FP.HWConfig = FP.DEFAULT, path: str | Path = "rtl/quantum/generated/sf_qt_constants.svh") -> str:
    c1, c2 = FP.constant_codes(cfg)
    txt = f"""// GENERATED by sf_quantum.reference.tunneling_golden -- do not edit.
// C1 = 2*sqrt(2*m_e*q)/hbar*1e-9 = {FP.c1_physical():.15g} nm^-1 eV^-1/2 (CODATA via scipy.constants)
// C2 = C1*log2(e) = {FP.c2_physical():.15g}
// Codes are UQ{cfg.k_ib}.{cfg.const_frac}, round-to-nearest.
localparam int SF_QT_CONST_FRAC = {cfg.const_frac};
localparam logic [{cfg.W_C - 1}:0] SF_QT_C1_CODE = {cfg.W_C}'d{c1};
localparam logic [{cfg.W_C - 1}:0] SF_QT_C2_CODE = {cfg.W_C}'d{c2};
"""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(txt)
    return str(p)


def generate_rtl_rom(cfg: FP.HWConfig = FP.DEFAULT, out_dir: str | Path = "rtl/quantum/generated") -> str:
    rom = FP.exp_rom(cfg)
    L, MF = cfg.lut_bits, cfg.MANT_F
    bw = MF + 1
    dw = max(int(max(d for _, d in rom)).bit_length(), 1)
    name = f"sf_qt_exp_rom_l{L}_m{MF}"
    lines = [
        f"// GENERATED by sf_quantum.reference.tunneling_golden -- do not edit.",
        f"// base[i] = round(2^(-i/2^{L}) * 2^{MF}), delta[i] = base[i] - base[i+1]  (2^{L} entries)",
        "`default_nettype none",
        "`timescale 1ns/1ps",
        f"module {name} (",
        f"    input  wire logic [{L - 1}:0] idx_i,",
        f"    output      logic [{bw - 1}:0] base_o,",
        f"    output      logic [{dw - 1}:0] delta_o",
        ");",
        "    always_comb begin",
        "        unique case (idx_i)",
    ]
    for i, (b, d) in enumerate(rom):
        lines.append(f"            {L}'d{i}: begin base_o = {bw}'d{b}; delta_o = {dw}'d{d}; end")
    lines += ["            default: begin base_o = '0; delta_o = '0; end",
              "        endcase", "    end", "endmodule", "`default_nettype wire", ""]
    p = Path(out_dir) / f"{name}.sv"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("\n".join(lines))
    return str(p)


W24 = FP.HWConfig(data_w=24, frac_w=16)
DIRECT = FP.HWConfig(exp_mode="direct")

#: vector set name -> (HWConfig, number of random vectors, seed offset)
VECTOR_SETS = {
    "sf_qt_core_v1": (FP.DEFAULT, None, 0),
    "sf_qt_core_w24_v1": (W24, 400, 1),
    "sf_qt_core_direct_v1": (DIRECT, 500, 2),
}


def generate_all(out_root: str | Path = "vectors", rtl_root: str | Path = "rtl/quantum/generated",
                 n_random: int = 2000, seed: int = DEFAULT_SEED) -> dict:
    res = {name: generate(name, cfg=cfg, n_random=n_random if n is None else n, seed=seed + off, out_root=out_root)
           for name, (cfg, n, off) in VECTOR_SETS.items()}
    res["integrator"] = generate_integrator_vectors(out_root=out_root)
    generate_rtl_constants(FP.DEFAULT, Path(rtl_root) / "sf_qt_constants.svh")
    res["roms"] = [generate_rtl_rom(FP.DEFAULT, rtl_root), generate_rtl_rom(W24, rtl_root)]
    return res


def main(argv=None):
    ap = argparse.ArgumentParser(description="Generate golden vectors and generated RTL tables")
    ap.add_argument("--out", default="vectors")
    ap.add_argument("--rtl", default="rtl/quantum/generated")
    ap.add_argument("--n-random", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=DEFAULT_SEED)
    a = ap.parse_args(argv)
    print(json.dumps(generate_all(a.out, a.rtl, a.n_random, a.seed), indent=2))


if __name__ == "__main__":  # pragma: no cover
    main()


# --------------------------------------------------------------------------- integrator vectors

def _integrator_profiles(seed: int) -> list[dict]:
    """Sampled profiles: dict(name, x_nm, V_eV, m, E_eV, dx_nm) or raw-code overrides."""
    rng = np.random.default_rng(seed)
    dx = 2.0 ** -6  # 0.015625 nm, exactly representable: no input quantisation of dx
    P = []

    def grid(width):
        n = int(round(width / dx)) + 1
        return np.arange(n) * dx

    x = grid(1.5)
    P.append(dict(name="SiO2 trapezoid 3.1->2.6 eV, 1.5 nm", x=x, V=3.1 - 0.5 * x / 1.5, m=np.full(x.size, 0.5), E=0.05, dx=dx))
    x = grid(3.0)
    P.append(dict(name="FN triangle 3.1 eV at 1.5 V/nm", x=x, V=3.1 - 1.5 * x, m=np.full(x.size, 0.5), E=0.05, dx=dx))
    x = grid(1.5)
    P.append(dict(name="sampled rectangle 3.1 eV x 1.5 nm", x=x, V=np.full(x.size, 3.1), m=np.full(x.size, 0.5), E=1.0, dx=dx))
    x = grid(3.7)
    il = x < 0.5
    V = np.where(il, 3.1 - 0.5 * x, 1.4 - 0.5 - (x - 0.5) * 0.5 / 3.2)
    P.append(dict(name="SiO2 0.5 / HfO2 3.2 nm at 1 V", x=x, V=V, m=np.where(il, 0.5, 0.2), E=0.05, dx=dx))
    x = grid(7.0)
    V = np.where((x <= 1.0) | (x >= 6.0), 0.3, 0.0)
    P.append(dict(name="double barrier (MULTI_REGION)", x=x, V=V, m=np.full(x.size, 0.067), E=0.08, dx=dx))
    x = grid(4.0)
    P.append(dict(name="smooth Gaussian barrier", x=x, V=1.5 * np.exp(-((x - 2.0) / 0.7) ** 2), m=np.full(x.size, 0.3),
                  E=0.4, dx=dx))
    P.append(dict(name="all samples below E (ABOVE)", x=grid(1.0), V=np.full(65, 0.5), m=np.full(65, 0.5), E=1.0, dx=dx))
    P.append(dict(name="E = 0 (INVALID)", x=grid(1.0), V=np.full(65, 3.1), m=np.full(65, 0.5), E=0.0, dx=dx))
    m0 = np.full(65, 0.5)
    m0[10] = 0.0
    P.append(dict(name="one sample with m = 0 (INVALID)", x=grid(1.0), V=np.full(65, 3.1), m=m0, E=1.0, dx=dx))
    P.append(dict(name="single-sample profile", x=np.array([0.0]), V=np.array([3.1]), m=np.array([0.5]), E=1.0, dx=0.5,
                  weights=np.array([1.0])))
    P.append(dict(name="4096 samples (maximum)", x=np.arange(4096) * 2.0 ** -10, V=np.full(4096, 2.0),
                  m=np.full(4096, 0.3), E=1.0, dx=2.0 ** -10))
    P.append(dict(name="4097 samples (overflow -> INVALID)", x=np.arange(4097) * 2.0 ** -10, V=np.full(4097, 2.0),
                  m=np.full(4097, 0.3), E=1.0, dx=2.0 ** -10))
    P.append(dict(name="wide high barrier (log large)", x=grid(8.0), V=np.full(513, 9.0), m=np.full(513, 1.0), E=0.1, dx=dx))
    for i in range(40):
        n = int(rng.integers(2, 300))
        d = float(2.0 ** -int(rng.integers(4, 9)))
        xs = np.arange(n) * d
        knots = rng.uniform(0.0, 6.0, 4)
        V = np.interp(xs, np.linspace(0, xs[-1] if n > 1 else 1, 4), knots)
        m = np.full(n, float(rng.choice([0.067, 0.2, 0.3, 0.5, 1.0])))
        P.append(dict(name=f"random profile {i}", x=xs, V=V, m=m, E=float(rng.uniform(0.01, 3.0)), dx=d))
    return P


def generate_integrator_vectors(set_name: str = "sf_qt_integrator_v1", *, seed: int = DEFAULT_SEED + 7,
                                out_root: str | Path = "vectors") -> dict:
    from ..quantum.barriers import from_samples
    from ..quantum.wkb import wkb_action_array
    from . import integrator_model as IM
    cfg = IM.DEFAULT
    h = cfg.hw
    F, W = h.frac_w, h.data_w
    smp_lines, exp_lines, recs = [], [], []
    for pi, p in enumerate(_integrator_profiles(seed)):
        n = len(p["x"])
        w = p.get("weights")
        if w is None:
            w = np.ones(n)
            if n > 1:
                w[0] = w[-1] = 0.5
        codes = [(FP.encode(float(v), F, W), FP.encode(float(mm), F, W), FP.encode(float(ww), F, W))
                 for v, mm, ww in zip(np.clip(p["V"], 0, None), p["m"], w)]
        e_c, dx_c = FP.encode(p["E"], F, W), FP.encode(p["dx"], F, W)
        hw = IM.evaluate_profile(codes, e_c, dx_c, cfg)
        tag = pi & 0xFF
        disc = IM.discrete_reference(codes, e_c, dx_c, cfg) if hw["err"] == 0 else None
        budget = IM.error_budget(codes, e_c, dx_c, cfg) if hw["err"] == 0 else None
        cont = None
        if hw["err"] == 0 and n > 1 and min(p["m"]) > 0:
            prof = from_samples(np.asarray(p["x"]), np.clip(p["V"], 0, None), p["m"],
                                energy_reference="left_lead_band_edge", v_left_eV=0.0, v_right_eV=0.0)
            cont = float(2 * wkb_action_array(prof, np.array([e_c / (1 << F) * 1.602176634e-19]))[0])
        for i, (v, mm, ww) in enumerate(codes):
            first, last = int(i == 0), int(i == n - 1)
            word = (first << (2 + 8 + 5 * W - 1)) | (last << (8 + 5 * W)) | (tag << (5 * W)) | (e_c << (4 * W)) | \
                (dx_c << (3 * W)) | (v << (2 * W)) | (mm << W) | ww
            smp_lines.append(_hexw(word, 2 + 8 + 5 * W))
        eword = (hw["warn"] << (2 * W + 4)) | (hw["err"] << (2 * W)) | (hw["log_code"] << W) | hw["t_code"]
        exp_lines.append(_hexw(eword, 8 + 2 * W))
        recs.append({"index": pi, "name": p["name"], "tag": tag, "n_samples": n, "E_eV": e_c / (1 << F),
                     "dx_nm": dx_c / (1 << F),
                     "expected_hw": {"log_code": hw["log_code"], "log_value": FP.to_signed(hw["log_code"], W) / (1 << F),
                                     "t_code": hw["t_code"], "err": hw["err"], "warn": hw["warn"]},
                     "reference_discrete": disc, "tolerance": budget,
                     "reference_continuous_2S": cont,
                     "discretisation_error_2S": (disc["two_s"] - cont) if (disc and cont is not None) else None})
    body = "\n".join(smp_lines) + "\n" + "\n".join(exp_lines)
    digest = hashlib.sha256(body.encode()).hexdigest()
    header = (f"// SilicaFlux QuantumTunnel integrator vectors '{set_name}' format {VECTOR_FORMAT_VERSION}\n"
              f"// sha256 {digest}\n")
    out = Path(out_root) / set_name
    out.mkdir(parents=True, exist_ok=True)
    (out / "samples.hex").write_text(header + "\n".join(smp_lines) + "\n")
    (out / "expected.hex").write_text(header + "\n".join(exp_lines) + "\n")
    (out / "n_vectors.svh").write_text(f"`define SF_QT_N_SAMPLES {len(smp_lines)}\n`define SF_QT_N_PROFILES {len(recs)}\n")
    meta = make_metadata(f"integrator vectors {set_name}", inputs={"n_profiles": len(recs), "seed": seed},
                         assumptions=["trapezoid-rule weights unless stated", "two references: discrete (acceptance) "
                                      "and continuous piecewise-linear WKB (discretisation error, reported only)"],
                         solver_settings={"hw_config": h.as_dict(), "n_max_log2": cfg.n_max_log2}, testbench_seed=seed)
    meta.update({"set_name": set_name, "format_version": VECTOR_FORMAT_VERSION, "content_sha256": digest,
                 "sample_layout": f"{{first, last, tag[8], E[{W}], dx[{W}], V[{W}], m[{W}], w[{W}]}}",
                 "expected_layout": f"{{pad, warn[3], err[4], log_T[{W}], T[{W}]}}", "profiles": recs})
    (out / "vectors.json").write_text(json.dumps(meta, indent=1, default=float))
    return {"dir": str(out), "n_profiles": len(recs), "n_samples": len(smp_lines), "sha256": digest}
