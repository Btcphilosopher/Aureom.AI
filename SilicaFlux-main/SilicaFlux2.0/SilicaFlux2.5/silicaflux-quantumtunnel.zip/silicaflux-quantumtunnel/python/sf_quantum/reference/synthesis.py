"""Synthesis and implementation reports from real tools (no invented numbers).

Flows (each runs only if its tool is installed; otherwise the gate is
recorded as *unavailable*):

* **Yosys generic** -- technology-independent gate count, flip-flops and
  Yosys' CMOS transistor estimate.
* **Yosys synth_ecp5 + nextpnr-ecp5** -- LUT4 / FF / MULT18X18D / DP16KD
  utilisation and *post-route* maximum frequency on a Lattice LFE5U-85F
  (CABGA756). Label: POST-ROUTE (nextpnr, no board constraints).
* **Yosys synth_ice40** -- resource estimate against an iCE40 UP5K (fit check).
* **ASIC-style** -- Yosys + ABC mapped to the NanGate45 Open Cell Library
  (typical corner; a *non-manufacturable* research library fetched at run
  time, not redistributed): standard-cell area (pre-layout, no wires) and
  ABC's post-sizing combinational delay estimate (no wire load, no clock tree,
  no setup). Label: PRE-LAYOUT ESTIMATE. This is not signoff STA, and no power
  estimate is produced (no activity-annotated power tool is available).
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import time
import urllib.request
from pathlib import Path

from ..provenance import PROJECT_ROOT, make_metadata
from .rtl_runner import RTL_FILES

NANGATE_URL = ("https://raw.githubusercontent.com/The-OpenROAD-Project/OpenROAD-flow-scripts/master/"
               "flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib")
LIB_CACHE = PROJECT_ROOT / "build" / "pdk" / "NangateOpenCellLibrary_typical.lib"

SYNTH_CONFIGS = {
    "default": {"PIPE_MUL": 1, "SQRT_BPS": 1, "EXP_MODE": 1},
    "nopipe": {"PIPE_MUL": 0, "SQRT_BPS": 1, "EXP_MODE": 1},
    "bps5": {"PIPE_MUL": 1, "SQRT_BPS": 5, "EXP_MODE": 1},
    "direct": {"PIPE_MUL": 1, "SQRT_BPS": 1, "EXP_MODE": 0},
}


def tools() -> dict:
    return {t: shutil.which(t) for t in ("yosys", "nextpnr-ecp5", "nextpnr-ice40")}


def _read(top: str, params: dict, extra_files=()) -> str:
    files = " ".join(str(PROJECT_ROOT / f) for f in list(RTL_FILES) + list(extra_files))
    chp = " ".join(f"-set {k} {v}" for k, v in params.items())
    s = f"read_verilog -sv -DSFX_SYNTHESIS -I{PROJECT_ROOT / 'rtl/quantum/generated'} {files}; "
    if chp:
        s += f"chparam {chp} {top}; "
    return s


def _yosys(script: str, log: Path, timeout: int = 1800) -> tuple[str, float]:
    t0 = time.perf_counter()
    r = subprocess.run(["yosys", "-q", "-l", str(log), "-p", script], capture_output=True, text=True, timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError(f"yosys failed ({log}):\n{r.stderr[-3000:]}")
    return log.read_text(), time.perf_counter() - t0


def _cells(stat_text: str) -> dict:
    out = {}
    m = re.search(r"Number of cells:\s+(\d+)", stat_text)
    if m:
        out["cells"] = int(m.group(1))
    for name, n in re.findall(r"^\s+(\$?[\w$]+)\s+(\d+)\s*$", stat_text, re.M):
        out[name] = int(n)
    m = re.search(r"Estimated number of transistors:\s+(\d+)", stat_text)
    if m:
        out["transistors_estimate"] = int(m.group(1))
    m = re.search(r"Chip area for module .*?:\s+([\d.]+)", stat_text)
    if m:
        out["chip_area_um2"] = float(m.group(1))
    return out


def generic(name: str, params: dict, out: Path, top: str = "sf_quantum_tunnel_core", extra=()) -> dict:
    stat = out / f"generic_{name}_stat.txt"
    _, secs = _yosys(_read(top, params, extra) + f"synth -flatten -top {top}; tee -q -o {stat} stat; "
                     f"tee -q -a {stat} stat -tech cmos", out / f"generic_{name}.log")
    c = _cells(stat.read_text())
    ffs = sum(v for k, v in c.items() if "DFF" in k)
    return {"label": "SYNTHESIS (Yosys generic)", "cells": c.get("cells"), "flip_flops": ffs,
            "transistors_estimate": c.get("transistors_estimate"), "seconds": secs}


def ecp5(name: str, params: dict, out: Path, freq_mhz: float = 100.0, top: str = "sf_quantum_tunnel_core") -> dict:
    js = out / f"ecp5_{name}.json"
    stat = out / f"ecp5_{name}_stat.txt"
    _, secs = _yosys(_read(top, params) + f"synth_ecp5 -top {top} -json {js}; tee -q -o {stat} stat",
                     out / f"ecp5_{name}.log")
    c = _cells(stat.read_text())
    res = {"label": "SYNTHESIS (Yosys synth_ecp5)", "LUT4": c.get("LUT4"), "TRELLIS_FF": c.get("TRELLIS_FF"),
           "CCU2C": c.get("CCU2C"), "MULT18X18D": c.get("MULT18X18D", 0), "DP16KD": c.get("DP16KD", 0),
           "PFUMX": c.get("PFUMX"), "L6MUX21": c.get("L6MUX21"), "synth_seconds": secs}
    if shutil.which("nextpnr-ecp5"):
        log = out / f"ecp5_{name}_pnr.log"
        t0 = time.perf_counter()
        r = subprocess.run(["nextpnr-ecp5", "--85k", "--package", "CABGA756", "--json", str(js), "--freq",
                            str(freq_mhz), "--seed", "1", "--log", str(log), "--quiet",
                            "--report", str(out / f"ecp5_{name}_pnr_report.json")],
                           capture_output=True, text=True, timeout=3600)
        text = log.read_text() if log.exists() else r.stderr
        fmax = re.findall(r"Max frequency for clock '[^']*': ([\d.]+) MHz", text)
        util = {}
        for cell, used, avail in re.findall(r"Info:\s+(\w+):\s+(\d+)/\s*(\d+)", text):
            util[cell] = {"used": int(used), "available": int(avail)}
        crit = re.findall(r"Info:\s+[\d.]+\s+[\d.]+\s+Source (\S+)", text)
        res["pnr"] = {"label": "POST-ROUTE (nextpnr-ecp5 0.6, LFE5U-85F CABGA756, speed grade 6, no IO constraints)",
                      "fmax_mhz": float(fmax[-1]) if fmax else None, "target_mhz": freq_mhz,
                      "met_target": bool(fmax) and float(fmax[-1]) >= freq_mhz, "utilisation": util,
                      "critical_path_start": crit[0] if crit else None, "seconds": time.perf_counter() - t0,
                      "returncode": r.returncode}
    else:
        res["pnr"] = {"status": "unavailable", "message": "nextpnr-ecp5 not installed: post-route timing NOT measured"}
    return res


def ecp5_top(name: str, out: Path, top: str, extra: list[str], freq_mhz: float = 100.0) -> dict:
    """ECP5 synthesis + nextpnr for a top other than the core (extra source files)."""
    js = out / f"ecp5_{name}.json"
    stat = out / f"ecp5_{name}_stat.txt"
    _yosys(_read(top, {}, extra) + f"synth_ecp5 -top {top} -json {js}; tee -q -o {stat} stat", out / f"ecp5_{name}.log")
    c = _cells(stat.read_text())
    res = {"label": "SYNTHESIS (Yosys synth_ecp5)", "LUT4": c.get("LUT4"), "TRELLIS_FF": c.get("TRELLIS_FF"),
           "MULT18X18D": c.get("MULT18X18D", 0), "DP16KD": c.get("DP16KD", 0)}
    if shutil.which("nextpnr-ecp5"):
        log = out / f"ecp5_{name}_pnr.log"
        subprocess.run(["nextpnr-ecp5", "--85k", "--package", "CABGA756", "--json", str(js), "--freq", str(freq_mhz),
                        "--seed", "1", "--log", str(log), "--quiet"], capture_output=True, text=True, timeout=3600)
        fmax = re.findall(r"Max frequency for clock '[^']*': ([\d.]+) MHz", log.read_text() if log.exists() else "")
        res["pnr"] = {"label": "POST-ROUTE (nextpnr-ecp5, LFE5U-85F)", "fmax_mhz": float(fmax[-1]) if fmax else None}
    return res


def ice40(name: str, params: dict, out: Path, top: str = "sf_quantum_tunnel_core") -> dict:
    stat = out / f"ice40_{name}_stat.txt"
    _, secs = _yosys(_read(top, params) + f"synth_ice40 -dsp -top {top}; tee -q -o {stat} stat", out / f"ice40_{name}.log")
    c = _cells(stat.read_text())
    luts = c.get("SB_LUT4", 0)
    return {"label": "SYNTHESIS (Yosys synth_ice40 -dsp), fit check against iCE40 UP5K", "SB_LUT4": luts,
            "SB_DFF_total": sum(v for k, v in c.items() if k.startswith("SB_DFF")), "SB_MAC16": c.get("SB_MAC16", 0),
            "SB_RAM40_4K": c.get("SB_RAM40_4K", 0), "SB_CARRY": c.get("SB_CARRY", 0),
            "up5k_capacity": {"SB_LUT4": 5280, "SB_MAC16": 8, "SB_RAM40_4K": 30},
            "fits_up5k": luts <= 5280 and c.get("SB_MAC16", 0) <= 8, "seconds": secs}


def ensure_liberty() -> Path | None:
    if LIB_CACHE.exists():
        return LIB_CACHE
    try:
        LIB_CACHE.parent.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(NANGATE_URL, timeout=60) as resp:
            LIB_CACHE.write_bytes(resp.read())
        return LIB_CACHE
    except Exception:
        return None


def asic(name: str, params: dict, out: Path, period_ps: int = 2500, top: str = "sf_quantum_tunnel_core") -> dict:
    lib = ensure_liberty()
    if lib is None:
        return {"status": "unavailable", "message": "NanGate45 liberty could not be fetched: ASIC estimate NOT produced"}
    stat = out / f"asic_{name}_stat.txt"
    log = out / f"asic_{name}.log"
    script = (_read(top, params) + f"synth -flatten -top {top}; dfflibmap -liberty {lib}; "
              f"abc -liberty {lib} -D {period_ps} -script +strash;dch,-f;map,-D,{period_ps};topo;"
              f"buffer;upsize;dnsize;stime,-p; opt_clean; tee -q -o {stat} stat -liberty {lib}")
    text, secs = _yosys(script, log)
    c = _cells(stat.read_text())
    delays = re.findall(r"Delay =\s+([\d.]+) ps", text)
    d = float(delays[-1]) if delays else None
    return {"label": "PRE-LAYOUT ESTIMATE (Yosys+ABC, NanGate45 OCL typical, non-manufacturable research library)",
            "cells": c.get("cells"), "cell_area_um2": c.get("chip_area_um2"),
            "abc_critical_delay_ps": d, "logic_only_fmax_estimate_mhz": (1e6 / d) if d else None,
            "caveats": ["cell area only: no placement, routing, wires or clock tree",
                        "delay is ABC's combinational estimate with no wire-load model; NOT static timing analysis",
                        "no power estimate (no activity-annotated power tool available)"],
            "seconds": secs}


def run_all(out_dir: str | Path = PROJECT_ROOT / "reports" / "synthesis", quick: bool = False) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    work = PROJECT_ROOT / "build" / "synth"
    work.mkdir(parents=True, exist_ok=True)
    t = tools()
    if not t["yosys"]:
        res = {"status": "unavailable", "message": "yosys not installed: synthesis gate NOT run", "tools": t}
        (out / "synthesis.json").write_text(json.dumps(res, indent=2))
        return res
    results: dict = {"tools": t, "configs": {}}
    names = ["default"] if quick else list(SYNTH_CONFIGS)
    for n in names:
        p = SYNTH_CONFIGS[n]
        entry = {"parameters": p, "generic": generic(n, p, work), "ecp5": ecp5(n, p, work)}
        if n == "default":
            entry["ice40"] = ice40(n, p, work)
            entry["asic_nangate45"] = asic(n, p, work)
        results["configs"][n] = entry
    if not quick:
        results["ssb_adapter_generic"] = generic("ssb_adapter", {}, work, top="sf_qt_ssb_regs",
                                                 extra=["rtl/integration/sf_qt_ssb_regs.sv"])
        results["integrator"] = {"generic": generic("integrator", {}, work, top="sf_qt_integrator",
                                                    extra=["rtl/quantum/sf_qt_integrator.sv"]),
                                 "ecp5": ecp5_top("integrator", work, "sf_qt_integrator",
                                                  ["rtl/quantum/sf_qt_integrator.sv"])}
        results["exp_unit"] = {
            f"mode{m}": {"generic": generic(f"exp_mode{m}", {"MODE": m, "PIPE": 1}, work, top="sf_qt_exp_lut"),
                         "ecp5": {k: v for k, v in ecp5(f"exp_mode{m}", {"MODE": m, "PIPE": 1}, work,
                                                        top="sf_qt_exp_lut").items() if k != "pnr"}}
            for m in (0, 1)}
    meta = make_metadata("synthesis", inputs={"configs": SYNTH_CONFIGS}, assumptions=[
        "labels identify the origin of every number", "no IO constraints / board timing",
        "NanGate45 is non-manufacturable; numbers are comparative estimates only"])
    (out / "synthesis.json").write_text(json.dumps({**meta, **results}, indent=2, default=str))
    (out / "SYNTHESIS.md").write_text(markdown(results))
    return results


def markdown(r: dict) -> str:
    L = ["# Synthesis, implementation and resource report", "",
         "Every number below was produced by the named tool in this environment. Labels: "
         "SYNTHESIS = logic synthesis, POST-ROUTE = after nextpnr placement and routing, "
         "PRE-LAYOUT ESTIMATE = standard-cell mapping without placement. No number is estimated by hand.", "",
         "## FPGA: Lattice ECP5 LFE5U-85F (Yosys 0.33 + nextpnr-ecp5 0.6)", "",
         "| config | PIPE_MUL | SQRT_BPS | EXP_MODE | LUT4 | FF | CCU2C | MULT18X18D | DP16KD | post-route Fmax (MHz) | latency (cycles) |",
         "|---|---|---|---|---|---|---|---|---|---|---|"]
    lat = {"default": 38, "nopipe": 35, "bps5": 18, "direct": 38}
    for n, e in r["configs"].items():
        p, c = e["parameters"], e["ecp5"]
        fm = c.get("pnr", {}).get("fmax_mhz")
        L.append(f"| {n} | {p['PIPE_MUL']} | {p['SQRT_BPS']} | {p['EXP_MODE']} | {c['LUT4']} | {c['TRELLIS_FF']} | "
                 f"{c['CCU2C']} | {c['MULT18X18D']} | {c['DP16KD']} | {fm if fm is not None else 'n/a'} | {lat.get(n)} |")
    L += ["", "Throughput at II = 1 (verified in RTL simulation) is one evaluation per cycle, i.e. "
          "Fmax million evaluations per second for the post-route Fmax above.", "",
          "## Technology-independent (Yosys generic)", "",
          "| config | cells | flip-flops | transistor estimate |", "|---|---|---|---|"]
    for n, e in r["configs"].items():
        g = e["generic"]
        L.append(f"| {n} | {g['cells']} | {g['flip_flops']} | {g['transistors_estimate']} |")
    d = r["configs"].get("default", {})
    if "ice40" in d:
        i = d["ice40"]
        L += ["", "## iCE40 UP5K fit check (Yosys synth_ice40 -dsp)", "",
              f"SB_LUT4 {i['SB_LUT4']} (capacity 5280), SB_MAC16 {i['SB_MAC16']} (capacity 8), "
              f"SB_RAM40_4K {i['SB_RAM40_4K']}, DFF {i['SB_DFF_total']} -> fits: **{i['fits_up5k']}**"]
    if "asic_nangate45" in d:
        a = d["asic_nangate45"]
        if a.get("status") == "unavailable":
            L += ["", "## ASIC-style estimate", "", a["message"]]
        else:
            L += ["", "## ASIC-style PRE-LAYOUT ESTIMATE (NanGate45 Open Cell Library, typical)", "",
                  f"- standard cells: {a['cells']}", f"- cell area: {a['cell_area_um2']:.0f} um^2 "
                  f"({a['cell_area_um2'] / 1e6:.4f} mm^2)",
                  f"- ABC post-sizing combinational delay: {a['abc_critical_delay_ps']:.0f} ps "
                  f"(logic-only bound {a['logic_only_fmax_estimate_mhz']:.0f} MHz)", ""]
            L += [f"- caveat: {c}" for c in a["caveats"]]
    if "exp_unit" in r:
        L += ["", "## Exponential unit design study (synthesised alone, PIPE=1)", "",
              "| mode | generic cells | FF | ECP5 LUT4 | MULT18X18D | DP16KD |", "|---|---|---|---|---|---|"]
        for m, e in r["exp_unit"].items():
            L.append(f"| {m} ({'linear interpolation' if m.endswith('1') else 'nearest entry'}) | {e['generic']['cells']} | "
                     f"{e['generic']['flip_flops']} | {e['ecp5']['LUT4']} | {e['ecp5']['MULT18X18D']} | {e['ecp5']['DP16KD']} |")
        L += ["", "Accuracy of each option: `reports/exp_study/EXP_STUDY.md`."]
    if "integrator" in r:
        g, e = r["integrator"]["generic"], r["integrator"]["ecp5"]
        L += ["", "## Sampled-profile integrator (`sf_qt_integrator`)", "",
              f"Generic: {g['cells']} cells, {g['flip_flops']} flip-flops. ECP5: LUT4 {e['LUT4']}, FF {e['TRELLIS_FF']}, "
              f"MULT18X18D {e['MULT18X18D']}, DP16KD {e['DP16KD']}, post-route Fmax "
              f"{e.get('pnr', {}).get('fmax_mhz', 'n/a')} MHz (one sample per cycle)."]
    if "ssb_adapter_generic" in r:
        s = r["ssb_adapter_generic"]
        L += ["", f"SoC Simple Bus adapter incl. core (generic): {s['cells']} cells, {s['flip_flops']} flip-flops."]
    L += ["", "Not produced (tool unavailable): signoff STA, ASIC place-and-route, power analysis, "
          "vendor (Vivado/Quartus) implementation.", ""]
    return "\n".join(L)


__all__ = ["run_all", "tools", "SYNTH_CONFIGS", "ensure_liberty"]
