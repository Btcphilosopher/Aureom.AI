"""Design study for the 2^-f unit (f in [0, 1)): accuracy vs hardware cost.

Four approaches are evaluated with integer arithmetic at the same output
precision (MANT_F = 34 fractional bits):

1. **direct LUT**    -- nearest of 2^L stored values (no multiplier).
2. **LUT + linear**  -- 2^L (base, delta) pairs + one delta x remainder multiply
                        (the implemented default; bit-identical to the RTL).
3. **piecewise quadratic** -- 2^Lq segments, Horner c0 + r(c1 + r c2): two multipliers.
4. **iterative shift-and-add** -- 2^-f = 2^(1-f)/2 with 2^g = prod (1 + 2^-k)^{d_k},
                        d_k chosen greedily against a table of log2(1 + 2^-k); one shift-add
                        per iteration, N iterations (no multiplier, N cycles or N stages).

Accuracy is measured (max |relative error| over a dense grid of f); cost is
counted structurally (ROM bits, multipliers with operand widths, adders,
iterations). Synthesised cost for options 1 and 2 comes from
``reports/synthesis`` (real Yosys / ECP5 numbers) when available.
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np

from ..provenance import PROJECT_ROOT, make_metadata
from . import fixed_point_model as FP

MANT_F = 34
YF = 20


def _grid(n: int = 1 << 16, seed: int = 3) -> np.ndarray:
    rng = np.random.default_rng(seed)
    codes = np.unique(np.concatenate([np.arange(0, 1 << YF, max(1, (1 << YF) // n)),
                                      rng.integers(0, 1 << YF, n)]))
    return codes.astype(np.int64)


def _rel_err(mant: np.ndarray, codes: np.ndarray) -> np.ndarray:
    true = np.exp2(-codes / float(1 << YF))
    return np.abs(mant / float(1 << MANT_F) - true) / true


def lut_options(L: int) -> dict:
    cfg_i = FP.HWConfig(lut_bits=L, exp_mode="interp")
    cfg_d = FP.HWConfig(lut_bits=L, exp_mode="direct")
    codes = _grid()
    out = {}
    for cfg, name in ((cfg_d, "direct"), (cfg_i, "interp")):
        rom = FP.exp_rom(cfg)
        R = cfg.R_BITS
        idx = codes >> R
        rem = codes & ((1 << R) - 1)
        base = np.array([rom[i][0] for i in idx], dtype=object)
        delta = np.array([rom[i][1] for i in idx], dtype=object)
        if name == "interp":
            mant = base - (delta * rem + (1 << (R - 1))) // (1 << R)
        else:
            mant = np.where(rem >= (1 << (R - 1)), base - delta, base)
        err = _rel_err(mant.astype(float), codes)
        dw = max(d for _, d in rom).bit_length()
        out[name] = {
            "lut_bits": L, "max_rel_error": float(err.max()), "mean_rel_error": float(err.mean()),
            "rom_bits": (2 ** L) * ((MANT_F + 1) + (dw if name == "interp" else dw)),
            "multipliers": [] if name == "direct" else [f"{dw}x{R}"],
            "adders": 1 if name == "direct" else 2, "iterations": 1,
            "analytic_bound": (math.log(2) / 2 ** (L + 1)) if name == "direct" else (math.log(2) ** 2 / 8 / 4 ** L),
        }
    return out


def quadratic(Lq: int) -> dict:
    nseg = 2 ** Lq
    codes = _grid()
    seg = codes >> (YF - Lq)
    r = (codes & ((1 << (YF - Lq)) - 1)) / float(1 << (YF - Lq))  # in [0,1)
    coef = []
    for s in range(nseg):
        # Chebyshev-node least squares fit of 2^-(s + r)/nseg on r in [0, 1]
        k = np.arange(16)
        rr = 0.5 - 0.5 * np.cos((2 * k + 1) * np.pi / 32)
        y = np.exp2(-(s + rr) / nseg)
        c2, c1, c0 = np.polyfit(rr, y, 2)
        coef.append([round(c * (1 << MANT_F)) for c in (c0, c1, c2)])
    coef = np.array(coef, dtype=object)
    rq = (codes & ((1 << (YF - Lq)) - 1)).astype(object)
    sh = YF - Lq
    c0, c1, c2 = coef[seg, 0], coef[seg, 1], coef[seg, 2]
    inner = c1 + (c2 * rq + (1 << (sh - 1))) // (1 << sh)
    mant = c0 + (inner * rq + (1 << (sh - 1))) // (1 << sh)
    err = _rel_err(mant.astype(float), codes)
    return {"segments": nseg, "max_rel_error": float(err.max()), "mean_rel_error": float(err.mean()),
            "rom_bits": nseg * 3 * (MANT_F + 2), "multipliers": [f"{MANT_F}x{sh}", f"{MANT_F}x{sh}"],
            "adders": 4, "iterations": 1}


def shift_subtract(n_iter: int) -> dict:
    """Multiplicative normalisation: 2^-f = 2^(1-f) / 2, 2^g = prod_k (1 + 2^-k)^{d_k}, k = 0..N-1.

    Greedy digit selection converges because log2(1 + 2^-k) <= sum_{j>k} log2(1 + 2^-j)
    (the product of (1 + a_j) is at least 1 + sum a_j). (Factors (1 - 2^-k) fail: their
    tail sum from k=2 is ~0.81 < 1, leaving f in (0.81, 1) unreachable.)
    """
    WF = MANT_F + 6  # working precision
    tab = [round(math.log2(1 + 2.0 ** -k) * (1 << WF)) for k in range(n_iter)]
    codes = _grid(1 << 12)
    mants = []
    one = 1 << WF
    for c in codes:
        resid = one - (int(c) << (WF - YF))  # g = 1 - f in (0, 1]
        x = one
        for k, t in enumerate(tab):
            if resid >= t:
                resid -= t
                x += x >> k
        mants.append((x >> 1) >> (WF - MANT_F))  # 2^g / 2
    err = _rel_err(np.array(mants, dtype=float), codes)
    return {"iterations": n_iter, "max_rel_error": float(err.max()), "mean_rel_error": float(err.mean()),
            "rom_bits": n_iter * WF, "multipliers": [], "adders": 2 * n_iter,
            "note": "residual after N iterations bounds the error by ~2^-N; one compare + shift-add per iteration"}


def run(out_dir: str | Path = PROJECT_ROOT / "reports" / "exp_study") -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    res = {"lut": {L: lut_options(L) for L in (4, 6, 8, 10)},
           "quadratic": {Lq: quadratic(Lq) for Lq in (2, 4, 6)},
           "shift_subtract": {n: shift_subtract(n) for n in (16, 24, 34)}}
    synth = PROJECT_ROOT / "reports" / "synthesis" / "synthesis.json"
    if synth.exists():
        s = json.loads(synth.read_text())
        res["synthesised_exp_unit"] = s.get("exp_unit")
    meta = make_metadata("exp unit design study", inputs={"MANT_F": MANT_F, "YF": YF},
                         assumptions=["accuracy measured on a dense grid, integer arithmetic",
                                      "cost of options 3-4 is a structural count, not synthesis"])
    (out / "exp_study.json").write_text(json.dumps({**meta, **res}, indent=2, default=str))
    L = ["# 2^-f unit design study", "",
         "Accuracy: measured max relative error of the 2^-f mantissa (PYTHON MODEL, integer arithmetic, "
         f"MANT_F={MANT_F}). Cost: structural count; synthesised numbers for the two implemented modes are in "
         "`reports/synthesis/SYNTHESIS.md`.", "",
         "| approach | size | max rel. error | ROM bits | multipliers | iterations |", "|---|---|---|---|---|---|"]
    for Lb, d in res["lut"].items():
        for k in ("direct", "interp"):
            e = d[k]
            L.append(f"| LUT {'nearest' if k == 'direct' else '+ linear interp'} | 2^{Lb} entries | "
                     f"{e['max_rel_error']:.3g} (bound {e['analytic_bound']:.3g}) | {e['rom_bits']} | "
                     f"{', '.join(e['multipliers']) or '-'} | 1 |")
    for Lq, e in res["quadratic"].items():
        L.append(f"| piecewise quadratic | {e['segments']} segments | {e['max_rel_error']:.3g} | {e['rom_bits']} | "
                 f"{', '.join(e['multipliers'])} | 1 |")
    for n, e in res["shift_subtract"].items():
        L.append(f"| shift-and-add | {n} iterations | {e['max_rel_error']:.3g} | {e['rom_bits']} | - | {n} |")
    L += ["", "**Choice:** LUT + linear interpolation with 2^8 entries (implemented, default EXP_MODE=1). Its "
          "~1e-6 error is below the datapath's own ln T error for typical barriers, it needs one modest "
          "multiplier, and the ROM fits two ECP5 DP16KD blocks. Nearest-entry (EXP_MODE=0) saves the "
          "multiplier at ~1e-3 error. A quadratic would need two wide multipliers for accuracy the datapath "
          "cannot use; shift-and-add trades the multiplier for ~N cycles or N pipeline stages.", ""]
    (out / "EXP_STUDY.md").write_text("\n".join(L))
    return res


__all__ = ["run", "lut_options", "quadratic", "shift_subtract"]
