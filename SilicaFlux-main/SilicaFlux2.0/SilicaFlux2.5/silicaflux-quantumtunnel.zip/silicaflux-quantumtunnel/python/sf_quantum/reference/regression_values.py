"""Numerical regression values (validation check 18).

``CASES`` are fixed solver configurations; ``regression_values.json`` (next to
this file) stores the values produced by the reviewed implementation.
``compare()`` recomputes them and reports the worst relative deviation. To
regenerate after an intentional, reviewed change:
``python -m sf_quantum.reference.regression_values --update``.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

from ..quantum import barriers as B
from ..quantum import scattering as S
from ..quantum import schrodinger as FD
from ..quantum import wkb as W
from ..quantum.constants import M_E, Q_E
from ..quantum.rectangular import rectangular_transmission

STORE = Path(__file__).with_name("regression_values.json")


def _cases() -> dict[str, float]:
    tz = B.trapezoidal(3.1, 1.1, 2.0, 0.5)
    db = B.double_barrier(0.3, 1.0, 5.0, 0.067)
    return {
        "exact_rect_3.1eV_1.5nm_E1.0": float(rectangular_transmission(1.0 * Q_E, 3.1 * Q_E, 1.5e-9, 0.5 * M_E).log_transmission[0]),
        "exact_rect_3.1eV_20nm_E0.5": float(rectangular_transmission(0.5 * Q_E, 3.1 * Q_E, 20e-9, 0.5 * M_E).log_transmission[0]),
        "wkb_trapezoid_E0.5": float(W.wkb(tz, 0.5 * Q_E).log_transmission),
        "wkb_triangle_E0.01": float(W.wkb(B.triangular(3.1, 1.0, 0.5), 0.01 * Q_E).log_transmission),
        "smatrix_trapezoid_E0.5": float(S.transmission(tz, 0.5 * Q_E).log_transmission[0]),
        "smatrix_double_barrier_E0.0789": float(S.transmission(db, 0.0789 * Q_E).transmission[0]),
        "fd_trapezoid_E0.5": float(FD.solve(tz, 0.5 * Q_E).log_transmission[0]),
    }


def compare() -> tuple[float, str]:
    stored = json.loads(STORE.read_text())
    now = _cases()
    worst, worst_key = 0.0, ""
    for k, v in stored.items():
        dev = abs(now[k] - v) / max(abs(v), 1e-300)
        if dev > worst:
            worst, worst_key = dev, k
    return worst, f"{len(stored)} stored values; worst: {worst_key or 'none'}"


def update() -> None:
    STORE.write_text(json.dumps(_cases(), indent=2))


if __name__ == "__main__":  # pragma: no cover
    if "--update" in sys.argv:
        update()
        print(f"wrote {STORE}")
    else:
        print(compare())
