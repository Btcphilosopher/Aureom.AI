r"""Bit-accurate integer model of ``rtl/quantum/sf_quantum_tunnel_core.sv``.

This file *is* the numerical specification of the hardware. Every shift,
rounding and saturation below has a one-to-one counterpart in the RTL; the
RTL regression requires bit-exact agreement with :func:`evaluate`, and
:func:`error_budget` bounds the difference between :func:`evaluate` and the
double-precision WKB reference (:mod:`.tunneling_golden`).

Computation (rectangular barrier, plain WKB, identical leads)
------------------------------------------------------------
.. math:: 2S = C_1\,a\,\sqrt{m^*(V_0-E)},\qquad
          C_1 = \frac{2\sqrt{2 m_e q}}{\hbar}\times10^{-9}\ \mathrm{nm^{-1}eV^{-1/2}},
          \qquad \ln T = -2S,\qquad T = 2^{-y},\ y = C_2\,a\sqrt{m^*(V_0-E)},\ C_2=C_1\log_2 e

Fixed-point formats (``F = FRAC_W``, ``G = SQRT_GUARD``, defaults 16 / 4)
----------------------------------------------------------------------------
=========  ================  ==========================================  =====================
signal     format            meaning                                     range check
=========  ================  ==========================================  =====================
V0, E      UQ(W-F).F          energy, eV, zero = lead band edge           < 2^E_IB = 16 eV
A          UQ(W-F).F          barrier width, nm                           < 2^A_IB = 64 nm
M          UQ(W-F).F          m*/m_e                                      0 < M < 2^M_IB = 16
dE         UQ4.F              V0 - E (exact)
P          UQ8.2F             M * dE (exact)
r          UQ4.(F+G+1)        floor(sqrt(P << (2G+2)))  (exact digit recurrence)
s          UQ5.(F+G)          (r + 1) >> 1    -> round-half-up sqrt
K1, K2     UQ10.(F+G)         round(C1*A), round(C2*A); C in UQ4.CF (CF=24)
TWO_S      UQ15.F             round(K1*s)
Y          UQ15.(F+G)         round(K2*s)
log_T      SQ(W-F).F          -TWO_S, saturated at -2^(W-1)              error bit LOG_SAT
mant       UQ1.(W+2)          2^-frac(Y): ROM (2^L entries, base+delta) + linear interpolation
T          UQ0.W              round(mant * 2^-int(Y)), saturated to 2^W-1
=========  ================  ==========================================  =====================

Rounding is round-half-up everywhere ("add half, shift right"); nothing is
truncated without a stated bound. Overflow is impossible inside the datapath
for in-range inputs (the widths above are sized from the range checks);
the only saturations are the two documented output ones.

Status outputs
--------------
``err[0] INVALID``   E == 0, M == 0, or any input above its range (outputs 0)
``err[1] ABOVE``     E >= V0 -- no forbidden region; outputs 0, NOT T = 1
``err[2] LOG_SAT``   2S exceeds the log output range (log saturated)
``err[3]``           reserved, 0
``warn[0] WKB_WEAK`` 2S < 2: WKB unreliable (near barrier top / very thin)
``warn[1] TX_UNDER`` T rounds to 0 in UQ0.W (log output still valid)
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field
from functools import lru_cache

from ..quantum.constants import HBAR, M_E, Q_E

ERR_INVALID, ERR_ABOVE, ERR_LOG_SAT = 1, 2, 4
WARN_WKB_WEAK, WARN_TX_UNDER = 1, 2


def c1_physical() -> float:
    """2 sqrt(2 m_e q) / hbar * 1e-9  [nm^-1 eV^-1/2]."""
    return 2.0 * math.sqrt(2.0 * M_E * Q_E) / HBAR * 1e-9


def c2_physical() -> float:
    return c1_physical() * math.log2(math.e)


@dataclass(frozen=True)
class HWConfig:
    data_w: int = 32
    frac_w: int = 16
    sqrt_guard: int = 4
    const_frac: int = 24
    lut_bits: int = 8
    e_ib: int = 4
    m_ib: int = 4
    a_ib: int = 6
    k_ib: int = 4
    tag_w: int = 8
    exp_mode: str = "interp"  # "interp" (LUT + linear interpolation) or "direct" (nearest LUT entry)

    def __post_init__(self):
        if self.data_w - self.frac_w <= max(self.e_ib, self.m_ib, self.a_ib):
            raise ValueError("integer field must be wider than the range-check widths "
                             "(the range limits 2^(IB+F) must be representable in DATA_W bits)")
        if self.frac_w + self.sqrt_guard <= self.lut_bits:
            raise ValueError("LUT index wider than the fractional part of y")
        if self.const_frac < self.sqrt_guard:
            raise ValueError("const_frac must be >= sqrt_guard")
        if self.exp_mode not in ("interp", "direct"):
            raise ValueError("exp_mode must be 'interp' or 'direct'")

    # ---- derived widths (mirrored as localparams in sf_qt_pkg / the core) ----
    @property
    def F(self): return self.frac_w
    @property
    def G(self): return self.sqrt_guard
    @property
    def SF(self): return self.frac_w + self.sqrt_guard           # frac bits of s, K1, K2
    @property
    def W_DE(self): return self.e_ib + self.F
    @property
    def W_P(self): return self.e_ib + self.m_ib + 2 * self.F
    @property
    def SQ_ARG_W(self):
        w = self.W_P + 2 * self.G + 2
        return w + (w & 1)
    @property
    def SQ_OUT_W(self): return self.SQ_ARG_W // 2
    @property
    def S_W(self): return self.SQ_OUT_W                          # s = (r+1)>>1 may equal 2^(SQ_OUT_W-1)
    @property
    def W_A(self): return self.a_ib + self.F
    @property
    def W_C(self): return self.k_ib + self.const_frac
    @property
    def W_K(self): return self.k_ib + self.a_ib + self.SF
    @property
    def W_2S(self): return self.W_K + self.S_W - self.SF - self.G  # frac F
    @property
    def YF(self): return self.SF
    @property
    def W_Y(self): return self.W_K + self.S_W - self.SF            # frac YF
    @property
    def MANT_F(self): return self.data_w + 2
    @property
    def R_BITS(self): return self.YF - self.lut_bits
    @property
    def SH_MAX(self): return self.MANT_F + 1

    def as_dict(self) -> dict:
        d = asdict(self)
        d.update({k: getattr(self, k) for k in ("W_DE", "W_P", "SQ_ARG_W", "SQ_OUT_W", "S_W", "W_A", "W_C", "W_K",
                                                "W_2S", "YF", "W_Y", "MANT_F", "R_BITS", "SH_MAX")})
        return d


DEFAULT = HWConfig()


def rnd_shift(x: int, n: int) -> int:
    """Round-half-up right shift of a non-negative integer (n >= 0)."""
    if n == 0:
        return x
    return (x + (1 << (n - 1))) >> n


def isqrt_floor(x: int) -> int:
    """Exact floor(sqrt(x)) -- what the RTL digit recurrence computes."""
    return math.isqrt(x)


@lru_cache(maxsize=16)
def constant_codes(cfg: HWConfig = DEFAULT) -> tuple[int, int]:
    return round(c1_physical() * (1 << cfg.const_frac)), round(c2_physical() * (1 << cfg.const_frac))


@lru_cache(maxsize=16)
def exp_rom(cfg: HWConfig = DEFAULT) -> tuple[tuple[int, int], ...]:
    """ROM of (base, delta): base[i] = round(2^(-i/2^L) 2^MANT_F), delta[i] = base[i] - base[i+1]."""
    n = 1 << cfg.lut_bits
    base = [round(2.0 ** (-i / n) * (1 << cfg.MANT_F)) for i in range(n + 1)]
    base[n] = 1 << (cfg.MANT_F - 1)
    base[0] = 1 << cfg.MANT_F
    return tuple((base[i], base[i] - base[i + 1]) for i in range(n))


def encode(value: float, frac: int, width: int) -> int:
    """Round-to-nearest unsigned encoding; raises if not representable in ``width`` bits."""
    if value < 0 or not math.isfinite(value):
        raise ValueError("unsigned fixed-point value must be finite and >= 0")
    code = round(value * (1 << frac))
    if code >= (1 << width):
        raise ValueError(f"{value} does not fit UQ{width - frac}.{frac}")
    return code


def decode(code: int, frac: int) -> float:
    return code / (1 << frac)


def to_signed(code: int, width: int) -> int:
    code &= (1 << width) - 1
    return code - (1 << width) if code >> (width - 1) else code


@dataclass
class HWResult:
    log_code: int          # two's complement DATA_W bits (unsigned representation)
    t_code: int
    err: int
    warn: int
    inter: dict = field(default_factory=dict)

    @property
    def log_value(self) -> float:
        return to_signed(self.log_code, self._w) / (1 << self._f)

    def bind(self, cfg: HWConfig) -> "HWResult":
        self._w, self._f, self._dw = cfg.data_w, cfg.frac_w, cfg.data_w
        return self

    @property
    def t_value(self) -> float:
        return self.t_code / (1 << self._dw)


def evaluate(v0: int, e: int, a: int, m: int, cfg: HWConfig = DEFAULT) -> HWResult:
    """Bit-accurate evaluation from input codes."""
    W, F, G = cfg.data_w, cfg.F, cfg.G
    mask = (1 << W) - 1
    v0, e, a, m = v0 & mask, e & mask, a & mask, m & mask
    e_lim, a_lim, m_lim = 1 << (cfg.e_ib + F), 1 << (cfg.a_ib + F), 1 << (cfg.m_ib + F)
    invalid = e == 0 or m == 0 or v0 >= e_lim or e >= e_lim or a >= a_lim or m >= m_lim
    if invalid:
        return HWResult(0, 0, ERR_INVALID, 0, {"stage": "invalid"}).bind(cfg)
    if e >= v0:
        return HWResult(0, 0, ERR_ABOVE, 0, {"stage": "above_barrier"}).bind(cfg)
    de = v0 - e
    p = m * de
    r = isqrt_floor(p << (2 * G + 2))
    s = (r + 1) >> 1
    c1, c2 = constant_codes(cfg)
    k1 = rnd_shift(c1 * a, cfg.const_frac - G)
    k2 = rnd_shift(c2 * a, cfg.const_frac - G)
    two_s = rnd_shift(k1 * s, F + 2 * G)
    y = rnd_shift(k2 * s, 2 * cfg.SF - cfg.YF)
    err = warn = 0
    log_limit = 1 << (W - 1)
    if two_s > log_limit:
        log_code = (-log_limit) & mask
        err |= ERR_LOG_SAT
    else:
        log_code = (-two_s) & mask
    if two_s < (2 << F):
        warn |= WARN_WKB_WEAK
    yi = y >> cfg.YF
    yf = y & ((1 << cfg.YF) - 1)
    idx = yf >> cfg.R_BITS
    rem = yf & ((1 << cfg.R_BITS) - 1)
    base, delta = exp_rom(cfg)[idx]
    if cfg.exp_mode == "interp":
        mant = base - rnd_shift(delta * rem, cfg.R_BITS)
    else:  # direct: nearest of base[idx], base[idx+1]
        mant = base - delta if rem >= (1 << (cfg.R_BITS - 1)) else base
    sh_m1 = min(yi + (cfg.MANT_F - W) - 1, cfg.SH_MAX)
    t = ((mant >> sh_m1) + 1) >> 1
    if t > mask:
        t = mask
    if t == 0:
        warn |= WARN_TX_UNDER
    return HWResult(log_code, t, err, warn, {"de": de, "p": p, "r": r, "s": s, "k1": k1, "k2": k2, "two_s": two_s,
                                             "y": y, "yi": yi, "idx": idx, "rem": rem, "mant": mant}).bind(cfg)


def double_reference(v0: int, e: int, a: int, m: int, cfg: HWConfig = DEFAULT) -> dict:
    """Double-precision WKB on the *quantised* inputs (what the datapath should approximate)."""
    F = cfg.F
    V0, E, A, M = (x / (1 << F) for x in (v0, e, a, m))
    if E <= 0 or E >= V0:
        return {"two_s": float("nan"), "log_t": float("nan"), "t": float("nan"), "y": float("nan")}
    two_s = 2.0 * (A * 1e-9) * math.sqrt(2.0 * M * M_E * (V0 - E) * Q_E) / HBAR
    return {"two_s": two_s, "log_t": -two_s, "t": math.exp(-two_s), "y": two_s * math.log2(math.e)}


def error_budget(v0: int, e: int, a: int, m: int, cfg: HWConfig = DEFAULT) -> dict:
    """Worst-case |hardware - double| bounds derived from the format table.

    ln T:  |d(2S)| <= K1 e_s + s e_K1 + e_s e_K1 + 2^-(F+1)
           e_s  = 2^-(F+G+1)                     (rounded sqrt)
           e_K1 = 2^-(F+G+1) + A |C1q - C1|      (rounded product, quantised constant)
    T:     |dT| <= T (2^{ln2 |dy|} - 1) + 2^{-yi} e_mant + 2^-(W+1) [+ 2^-W saturation]
           e_mant = (ln2)^2 2^-2L / 8 + 2^-MANT_F  (interp)  |  ln2 2^-(L+1) + 2^-MANT_F (direct)
    """
    F, G, SF = cfg.F, cfg.G, cfg.SF
    ref = double_reference(v0, e, a, m, cfg)
    if not math.isfinite(ref["two_s"]):
        return {"log_t": 0.0, "t": 0.0}
    A, M = a / (1 << F), m / (1 << F)
    dE = (v0 - e) / (1 << F)
    c1q, c2q = (c / (1 << cfg.const_frac) for c in constant_codes(cfg))
    s_true = math.sqrt(M * dE)
    e_s = 2.0 ** -(SF + 1)
    e_k1 = 2.0 ** -(SF + 1) + A * abs(c1q - c1_physical())
    e_k2 = 2.0 ** -(SF + 1) + A * abs(c2q - c2_physical())
    k1, k2 = c1_physical() * A, c2_physical() * A
    b_2s = k1 * e_s + s_true * e_k1 + e_s * e_k1 + 2.0 ** -(F + 1)
    b_y = k2 * e_s + s_true * e_k2 + e_s * e_k2 + 2.0 ** -(cfg.YF + 1)
    h = 2.0 ** -cfg.lut_bits
    e_mant = ((math.log(2) ** 2) * h * h / 8.0 if cfg.exp_mode == "interp" else math.log(2) * h / 2.0) \
        + 2.0 ** -cfg.MANT_F
    T = ref["t"]
    yi_min = max(math.floor(ref["y"] - b_y), 0)  # smallest integer part the hardware can produce
    b_t = T * (2.0 ** b_y - 1.0) + 2.0 ** (-yi_min) * e_mant + 2.0 ** -(cfg.data_w + 1)
    if T > 1.0 - 2.0 ** -cfg.data_w - b_t:
        b_t += 2.0 ** -cfg.data_w
    # 1% margin for second-order terms dropped above
    return {"log_t": 1.01 * b_2s, "t": 1.01 * b_t, "y": 1.01 * b_y}


__all__ = ["HWConfig", "DEFAULT", "HWResult", "evaluate", "double_reference", "error_budget", "encode", "decode",
           "to_signed", "constant_codes", "exp_rom", "c1_physical", "c2_physical", "rnd_shift",
           "ERR_INVALID", "ERR_ABOVE", "ERR_LOG_SAT", "WARN_WKB_WEAK", "WARN_TX_UNDER"]
