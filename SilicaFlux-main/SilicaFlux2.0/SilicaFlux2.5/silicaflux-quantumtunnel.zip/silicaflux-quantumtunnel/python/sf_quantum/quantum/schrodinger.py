r"""LEVEL 3b -- finite-difference open-boundary Schroedinger solver.

An *independent* second numerical method (shares no code with
:mod:`.scattering`), used to cross-validate it.

Equation
--------
Stationary effective-mass Schroedinger equation with position-dependent mass,

.. math:: -\frac{\hbar^2}{2}\frac{d}{dx}\left[\frac{1}{m(x)}\frac{d\psi}{dx}\right] + V(x)\psi = E\psi ,

discretised on a uniform grid :math:`x_i = i h` with the
BenDaniel-Duke-consistent flux-form stencil

.. math:: -\frac{\hbar^2}{2h^2}\left[\frac{\psi_{i+1}-\psi_i}{m_{i+1/2}}
          - \frac{\psi_i-\psi_{i-1}}{m_{i-1/2}}\right] + V_i\psi_i = E\psi_i ,

where :math:`m_{i\pm1/2}` is the mass at the link midpoint (so the discrete
:math:`\psi'/m` is continuous across an interface lying on a node) and
:math:`V_i` is the dual-cell average of V. For constant mass this is the
conventional three-point Laplacian.

Open boundaries (quantum transmitting boundary method)
------------------------------------------------------
This is a *scattering* calculation, not a finite-box eigenproblem. The leads
are semi-infinite uniform lattices with the same discretisation; eliminating
them exactly gives the retarded self-energies
:math:`\Sigma = -t\,e^{ikh}` (:math:`t=\hbar^2/2m h^2`,
:math:`E-V = 2t(1-\cos kh)`) and a source :math:`2it_L\sin(k_Lh)` for a
unit-amplitude incident wave. Solving the tridiagonal system

.. math:: (E - H - \Sigma_L - \Sigma_R)\,\psi = s

gives :math:`\psi` in the device, :math:`r=\psi_0-1`, :math:`t=\psi_N` and the
flux transmission :math:`T=|t|^2 v_R/v_L` with discrete group velocities
:math:`v\propto t\sin(kh)`. The discrete model conserves current exactly;
its error relative to the continuum is :math:`O(h^2)`.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.linalg import solve_banded

from .barriers import PotentialProfile
from .constants import HBAR

DEFAULT_GRID_M = 0.005e-9


@dataclass(frozen=True)
class FDResult:
    energy_J: np.ndarray
    transmission: np.ndarray
    reflection: np.ndarray
    conservation_error: np.ndarray
    n_nodes: int
    grid_m: float
    psi: np.ndarray | None = None  # only for single-energy calls with return_psi=True
    x_m: np.ndarray | None = None

    @property
    def log_transmission(self) -> np.ndarray:
        with np.errstate(divide="ignore"):
            return np.log(self.transmission)


def _grid(profile: PotentialProfile, h_target: float):
    W = profile.width_m
    n_int = max(4, int(np.ceil(W / h_target)))
    h = W / n_int
    x = np.arange(n_int + 1) * h
    # dual-cell average of V: mean of the two half-cell midpoints (exact for linear pieces)
    v = 0.5 * (profile.potential(x - 0.25 * h) + profile.potential(x + 0.25 * h))
    # end nodes: half-cell outside the device belongs to the lead
    v[0] = 0.5 * (profile.left.potential_J + profile.potential(np.array([0.25 * h]))[0])
    v[-1] = 0.5 * (profile.right.potential_J + profile.potential(np.array([W - 0.25 * h]))[0])
    links = x[:-1] + 0.5 * h
    m_link = profile.mass(links)
    return x, h, v, m_link


def _lead_k(E: float, v: float, t: float) -> complex:
    """Discrete lead wavevector*h from E - v = 2t(1 - cos kh), retarded branch."""
    c = 1.0 - (E - v) / (2.0 * t)
    if -1.0 < c < 1.0:
        return complex(np.arccos(c))  # propagating, 0 < kh < pi
    if c >= 1.0:  # below band: evanescent, e^{ikh} = 1/(c + sqrt(c^2-1)) < 1
        return 1j * np.arccosh(c)
    raise ValueError("energy above the discrete lead band; refine the grid")


def solve(profile: PotentialProfile, energies_J: np.ndarray | float, *, grid_m: float = DEFAULT_GRID_M,
          return_psi: bool = False) -> FDResult:
    """Transmission by the finite-difference QTBM for each energy."""
    E_arr = np.atleast_1d(np.asarray(energies_J, dtype=float))
    if np.any(E_arr <= profile.left.potential_J):
        raise ValueError("energy must exceed the left-lead band edge")
    x, h, v, m_link = _grid(profile, grid_m)
    n = x.size
    tL = HBAR**2 / (2.0 * profile.left.mass_kg * h**2)
    tR = HBAR**2 / (2.0 * profile.right.mass_kg * h**2)
    t_link = HBAR**2 / (2.0 * m_link * h**2)  # n-1 interior links
    # diagonal: V_i + t_{i-1/2} + t_{i+1/2}; boundary links couple to the leads
    t_left_of = np.concatenate([[tL], t_link])
    t_right_of = np.concatenate([t_link, [tR]])
    diag_h = v + t_left_of + t_right_of

    T = np.empty_like(E_arr)
    R = np.empty_like(E_arr)
    psi_out = None
    for idx, E in enumerate(E_arr):
        khL = _lead_k(E, profile.left.potential_J, tL)
        khR = _lead_k(E, profile.right.potential_J, tR)
        sigL = -tL * np.exp(1j * khL)
        sigR = -tR * np.exp(1j * khR)
        ab = np.zeros((3, n), dtype=complex)
        ab[0, 1:] = t_link          # super-diagonal of (E - H): +t
        ab[1, :] = E - diag_h
        ab[2, :-1] = t_link         # sub-diagonal
        ab[1, 0] -= sigL
        ab[1, -1] -= sigR
        rhs = np.zeros(n, dtype=complex)
        rhs[0] = 2j * tL * np.sin(khL)
        psi = solve_banded((1, 1), ab, rhs)
        vL = tL * np.sin(khL).real
        vR = tR * np.sin(khR).real if khR.imag == 0 else 0.0
        T[idx] = abs(psi[-1]) ** 2 * vR / vL
        R[idx] = abs(psi[0] - 1.0) ** 2
        if return_psi and E_arr.size == 1:
            psi_out = psi
    return FDResult(E_arr, T, R, np.abs(R + T - 1.0), n, h, psi_out, x if psi_out is not None else None)


__all__ = ["FDResult", "solve", "DEFAULT_GRID_M"]
