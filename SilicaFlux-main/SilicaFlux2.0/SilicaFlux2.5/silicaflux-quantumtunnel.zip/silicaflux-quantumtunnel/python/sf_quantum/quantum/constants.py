"""Central physical-constants module.

All values come from :mod:`scipy.constants` (CODATA recommended values; the
release in use is detected and recorded for provenance). Everything in this
package is SI internally: metres, kilograms, seconds, joules, volts, kelvin,
amperes.

The *free-electron* mass :data:`M_E` is never used directly as a transport
mass. Semiconductor and dielectric effective masses are always expressed as a
dimensionless ratio to :data:`M_E` and converted with
:func:`sf_quantum.quantum.units.effective_mass_kg`.
"""

from __future__ import annotations

import scipy
from scipy import constants as _c

#: Reduced Planck constant  [J s]
HBAR: float = float(_c.hbar)
#: Planck constant  [J s]
H_PLANCK: float = float(_c.h)
#: Elementary charge (positive)  [C]
Q_E: float = float(_c.e)
#: Free-electron rest mass  [kg]
M_E: float = float(_c.m_e)
#: Boltzmann constant  [J/K]
K_B: float = float(_c.k)
#: Vacuum permittivity  [F/m]
EPS_0: float = float(_c.epsilon_0)

# Reference electron-mass values of each CODATA release, used only to detect
# which release scipy is serving (scipy does not expose this publicly).
_CODATA_ELECTRON_MASS = {
    "2014": 9.10938356e-31,
    "2018": 9.1093837015e-31,
    "2022": 9.1093837139e-31,
}


def codata_release() -> str:
    """Return the CODATA release year scipy.constants is serving."""
    for year, value in _CODATA_ELECTRON_MASS.items():
        if abs(M_E - value) <= 1e-12 * value:
            return year
    return "unknown"


def constants_provenance() -> dict:
    """Machine-readable provenance record for the constants in use."""
    return {
        "source": "scipy.constants",
        "scipy_version": scipy.__version__,
        "codata_release": codata_release(),
        "values_SI": {
            "hbar_J_s": HBAR,
            "h_J_s": H_PLANCK,
            "e_C": Q_E,
            "m_e_kg": M_E,
            "k_B_J_per_K": K_B,
            "epsilon_0_F_per_m": EPS_0,
        },
    }


__all__ = [
    "HBAR",
    "H_PLANCK",
    "Q_E",
    "M_E",
    "K_B",
    "EPS_0",
    "codata_release",
    "constants_provenance",
]
