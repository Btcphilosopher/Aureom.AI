"""One-dimensional potential-energy barrier geometry.

Canonical representation
------------------------
Every barrier in the package is a :class:`PotentialProfile`: a sequence of
:class:`Layer` objects between two semi-infinite, flat :class:`Lead`
electrodes. Inside a layer the potential energy is *linear* in position
(constant layers are the special case ``v_start == v_end``) and the effective
mass is constant. This covers, exactly:

* rectangular, trapezoidal and triangular barriers,
* multiple barriers / resonant structures,
* multilayer gate dielectrics with per-layer field,

and, as a piecewise-linear interpolant, any smooth user-defined potential or
imported sampled profile (:func:`from_function`, :func:`from_samples`,
:func:`from_csv`).

Coordinates: the device region is ``0 <= x <= width``; the left lead occupies
``x < 0`` and the right lead ``x > width``. At an internal boundary the
potential is taken from the layer to the right (a convention only relevant for
plotting; the solvers treat interfaces explicitly).

Energy reference
----------------
Potential energy is only meaningful relative to a stated zero. Every profile
carries ``energy_reference``; imported profiles *must* state one. Electron
energies passed to solvers are measured on the same scale.

Units: SI internally (metres, joules, kilograms). Factory functions accept the
human-facing units nm / eV / V/nm / dimensionless mass ratio and convert
through :mod:`sf_quantum.quantum.units`.
"""

from __future__ import annotations

import csv
import math
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Callable, Iterable, Sequence

import numpy as np

from .constants import M_E, Q_E
from .units import J_to_eV, NM, effective_mass_kg, eV_to_J, m_to_nm, nm_to_m

#: Recognised energy-reference conventions. ``custom:<description>`` is also
#: accepted so that imported data can state its own zero explicitly.
ENERGY_REFERENCES: dict[str, str] = {
    "left_lead_band_edge": "Zero of potential energy is the conduction-band edge of the left (incident) electrode.",
    "si_conduction_band_edge": "Zero is the silicon conduction-band edge at the Si/dielectric interface.",
    "left_fermi_level": "Zero is the Fermi level of the left electrode.",
    "vacuum_level": "Zero is the local vacuum level (energies are negative inside bound materials).",
}


def validate_energy_reference(ref: str | None) -> str:
    if ref is None or not str(ref).strip():
        raise ValueError(
            "an energy reference is required (one of "
            f"{sorted(ENERGY_REFERENCES)} or 'custom:<description>')"
        )
    ref = str(ref).strip()
    if ref in ENERGY_REFERENCES:
        return ref
    if ref.startswith("custom:") and len(ref) > len("custom:"):
        return ref
    raise ValueError(
        f"unknown energy reference {ref!r}; use one of {sorted(ENERGY_REFERENCES)} "
        "or 'custom:<description>'"
    )


@dataclass(frozen=True)
class Lead:
    """Semi-infinite flat electrode (constant potential energy and mass)."""

    potential_J: float
    mass_kg: float
    name: str = "lead"

    def __post_init__(self) -> None:
        if not math.isfinite(self.potential_J):
            raise ValueError("lead potential must be finite")
        if not (math.isfinite(self.mass_kg) and self.mass_kg > 0):
            raise ValueError("lead effective mass must be finite and > 0")


@dataclass(frozen=True)
class Layer:
    """Layer of constant effective mass with linear potential energy."""

    thickness_m: float
    v_start_J: float
    v_end_J: float
    mass_kg: float
    name: str = ""
    material: str | None = None

    def __post_init__(self) -> None:
        for name in ("thickness_m", "v_start_J", "v_end_J", "mass_kg"):
            if not math.isfinite(getattr(self, name)):
                raise ValueError(f"layer {name} must be finite")
        if self.thickness_m <= 0:
            raise ValueError("layer thickness must be > 0")
        if self.mass_kg <= 0:
            raise ValueError("layer effective mass must be > 0")

    @property
    def is_constant(self) -> bool:
        return self.v_start_J == self.v_end_J

    @property
    def slope_J_per_m(self) -> float:
        return (self.v_end_J - self.v_start_J) / self.thickness_m

    def potential_local(self, s: np.ndarray) -> np.ndarray:
        """Potential energy at local coordinate ``0 <= s <= thickness``."""
        return self.v_start_J + (self.v_end_J - self.v_start_J) * (np.asarray(s) / self.thickness_m)


@dataclass(frozen=True)
class PotentialProfile:
    """Layered 1D potential-energy profile between two flat leads."""

    layers: tuple[Layer, ...]
    left: Lead
    right: Lead
    energy_reference: str = "left_lead_band_edge"
    label: str = ""
    dimensionality: str = "1D"
    notes: tuple[str, ...] = ()
    metadata: dict = field(default_factory=dict, compare=False, hash=False)

    def __post_init__(self) -> None:
        if len(self.layers) == 0:
            raise ValueError("a profile needs at least one layer")
        object.__setattr__(self, "layers", tuple(self.layers))
        object.__setattr__(self, "notes", tuple(self.notes))
        object.__setattr__(self, "energy_reference", validate_energy_reference(self.energy_reference))

    # ------------------------------------------------------------------ geometry
    @property
    def width_m(self) -> float:
        return float(sum(layer.thickness_m for layer in self.layers))

    @property
    def boundaries_m(self) -> np.ndarray:
        """Layer boundary positions, starting at 0 and ending at ``width_m``."""
        return np.concatenate([[0.0], np.cumsum([l.thickness_m for l in self.layers])])

    @property
    def v_max_J(self) -> float:
        return max(max(l.v_start_J, l.v_end_J) for l in self.layers)

    @property
    def v_min_J(self) -> float:
        return min(min(l.v_start_J, l.v_end_J) for l in self.layers)

    @property
    def is_piecewise_constant(self) -> bool:
        return all(l.is_constant for l in self.layers)

    def potential(self, x_m: np.ndarray | float) -> np.ndarray:
        """Potential energy V(x) [J], including the flat leads outside the device."""
        x = np.atleast_1d(np.asarray(x_m, dtype=float))
        out = np.empty_like(x)
        b = self.boundaries_m
        out[x < 0] = self.left.potential_J
        out[x >= b[-1]] = self.right.potential_J
        for i, layer in enumerate(self.layers):
            sel = (x >= b[i]) & (x < b[i + 1])
            out[sel] = layer.potential_local(x[sel] - b[i])
        return out if np.ndim(x_m) else out[0]

    def mass(self, x_m: np.ndarray | float) -> np.ndarray:
        """Effective mass m(x) [kg], including the leads."""
        x = np.atleast_1d(np.asarray(x_m, dtype=float))
        out = np.empty_like(x)
        b = self.boundaries_m
        out[x < 0] = self.left.mass_kg
        out[x >= b[-1]] = self.right.mass_kg
        for i, layer in enumerate(self.layers):
            out[(x >= b[i]) & (x < b[i + 1])] = layer.mass_kg
        return out if np.ndim(x_m) else out[0]

    def discontinuities(self) -> list[dict]:
        """Abrupt changes of potential or mass at every boundary (incl. leads)."""
        b = self.boundaries_m
        result = []
        left_v, left_m = self.left.potential_J, self.left.mass_kg
        for i, layer in enumerate(self.layers):
            dv = layer.v_start_J - left_v
            dm = layer.mass_kg - left_m
            if dv != 0.0 or dm != 0.0:
                result.append({"x_m": float(b[i]), "dV_J": float(dv), "dm_kg": float(dm), "index": i})
            left_v, left_m = layer.v_end_J, layer.mass_kg
        dv = self.right.potential_J - left_v
        dm = self.right.mass_kg - left_m
        if dv != 0.0 or dm != 0.0:
            result.append({"x_m": float(b[-1]), "dV_J": float(dv), "dm_kg": float(dm), "index": len(self.layers)})
        return result

    # ----------------------------------------------------------- transformations
    def with_field(self, field_V_per_m: float) -> "PotentialProfile":
        """Superimpose a uniform electric field across the device region.

        A field F pointing from left to right lowers the electron potential
        energy by ``q F x``; the right lead is lowered by ``q F width``.
        """
        b = self.boundaries_m
        drop = Q_E * float(field_V_per_m)
        layers = tuple(
            replace(l, v_start_J=l.v_start_J - drop * b[i], v_end_J=l.v_end_J - drop * b[i + 1])
            for i, l in enumerate(self.layers)
        )
        right = replace(self.right, potential_J=self.right.potential_J - drop * b[-1])
        return replace(
            self,
            layers=layers,
            right=right,
            notes=self.notes + (f"uniform field {field_V_per_m:.6g} V/m superimposed",),
        )

    def sample(self, n: int = 1000, lead_extent_m: float | None = None) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Return (x, V, m) samples for plotting, including a stretch of each lead."""
        w = self.width_m
        ext = 0.25 * w if lead_extent_m is None else lead_extent_m
        x = np.linspace(-ext, w + ext, n)
        # make sure every boundary is represented on both sides
        b = self.boundaries_m
        eps = 1e-6 * w
        x = np.unique(np.concatenate([x, b - eps, b + eps, b]))
        return x, self.potential(x), self.mass(x)

    # --------------------------------------------------------------- reporting
    def to_dict(self) -> dict:
        return {
            "label": self.label,
            "energy_reference": self.energy_reference,
            "dimensionality": self.dimensionality,
            "notes": list(self.notes),
            "left_lead": {"name": self.left.name, "potential_eV": J_to_eV(self.left.potential_J),
                          "mass_rel": self.left.mass_kg / M_E},
            "right_lead": {"name": self.right.name, "potential_eV": J_to_eV(self.right.potential_J),
                           "mass_rel": self.right.mass_kg / M_E},
            "layers": [
                {
                    "name": l.name,
                    "material": l.material,
                    "thickness_nm": m_to_nm(l.thickness_m),
                    "v_start_eV": J_to_eV(l.v_start_J),
                    "v_end_eV": J_to_eV(l.v_end_J),
                    "mass_rel": l.mass_kg / M_E,
                }
                for l in self.layers
            ],
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PotentialProfile":
        layers = tuple(
            Layer(
                thickness_m=nm_to_m(l["thickness_nm"]),
                v_start_J=eV_to_J(l["v_start_eV"]),
                v_end_J=eV_to_J(l["v_end_eV"]),
                mass_kg=effective_mass_kg(l["mass_rel"]),
                name=l.get("name", ""),
                material=l.get("material"),
            )
            for l in d["layers"]
        )
        left = Lead(eV_to_J(d["left_lead"]["potential_eV"]), effective_mass_kg(d["left_lead"]["mass_rel"]),
                    d["left_lead"].get("name", "left"))
        right = Lead(eV_to_J(d["right_lead"]["potential_eV"]), effective_mass_kg(d["right_lead"]["mass_rel"]),
                     d["right_lead"].get("name", "right"))
        return cls(layers, left, right, d["energy_reference"], d.get("label", ""),
                   d.get("dimensionality", "1D"), tuple(d.get("notes", ())), dict(d.get("metadata", {})))

    def describe(self) -> str:
        parts = [f"{self.label or 'profile'} [{self.dimensionality}, ref={self.energy_reference}]"]
        for l in self.layers:
            parts.append(
                f"  {l.name or l.material or 'layer'}: {m_to_nm(l.thickness_m):.4g} nm, "
                f"V {J_to_eV(l.v_start_J):.4g}->{J_to_eV(l.v_end_J):.4g} eV, m*={l.mass_kg / M_E:.4g}"
            )
        return "\n".join(parts)


# =============================================================================
# Factory functions (human-facing units)
# =============================================================================

def _lead(potential_eV: float, mass_rel: float, name: str) -> Lead:
    return Lead(eV_to_J(potential_eV), effective_mass_kg(mass_rel), name)


def rectangular(
    height_eV: float,
    width_nm: float,
    m_eff: float,
    *,
    lead_mass: float | None = None,
    lead_potential_eV: float = 0.0,
    label: str | None = None,
    material: str | None = None,
) -> PotentialProfile:
    """Ideal rectangular barrier of potential energy ``height_eV`` between identical leads.

    ``height_eV`` is the barrier potential energy on the profile's energy
    scale (the leads sit at ``lead_potential_eV``, default 0).
    """
    lm = m_eff if lead_mass is None else lead_mass
    layer = Layer(nm_to_m(width_nm), eV_to_J(height_eV), eV_to_J(height_eV), effective_mass_kg(m_eff),
                  "barrier", material)
    return PotentialProfile(
        (layer,), _lead(lead_potential_eV, lm, "left"), _lead(lead_potential_eV, lm, "right"),
        "left_lead_band_edge", label or f"rectangular {height_eV:g} eV x {width_nm:g} nm",
    )


def trapezoidal(
    v_start_eV: float,
    v_end_eV: float,
    width_nm: float,
    m_eff: float,
    *,
    lead_mass: float | None = None,
    v_left_eV: float = 0.0,
    v_right_eV: float | None = None,
    label: str | None = None,
    material: str | None = None,
) -> PotentialProfile:
    """Barrier whose potential energy varies linearly from ``v_start`` to ``v_end``.

    By default the right lead is lowered by the same amount as the barrier
    (``v_right = v_left + v_end - v_start``), i.e. identical electrodes with the
    whole potential drop inside the barrier.
    """
    lm = m_eff if lead_mass is None else lead_mass
    vr = v_left_eV + (v_end_eV - v_start_eV) if v_right_eV is None else v_right_eV
    layer = Layer(nm_to_m(width_nm), eV_to_J(v_start_eV), eV_to_J(v_end_eV), effective_mass_kg(m_eff),
                  "barrier", material)
    return PotentialProfile(
        (layer,), _lead(v_left_eV, lm, "left"), _lead(vr, lm, "right"), "left_lead_band_edge",
        label or f"trapezoidal {v_start_eV:g}->{v_end_eV:g} eV x {width_nm:g} nm",
    )


def biased_rectangular(
    height_eV: float,
    width_nm: float,
    m_eff: float,
    *,
    field_V_per_nm: float | None = None,
    voltage_V: float | None = None,
    lead_mass: float | None = None,
    label: str | None = None,
) -> PotentialProfile:
    """Rectangular barrier under a uniform field confined to the barrier.

    Give either ``field_V_per_nm`` or the voltage drop ``voltage_V`` across the
    barrier. The result is trapezoidal for ``qV < height`` and has a triangular
    forbidden region (Fowler-Nordheim regime) for electrons near the lead edge
    when ``qV > height``.
    """
    if (field_V_per_nm is None) == (voltage_V is None):
        raise ValueError("give exactly one of field_V_per_nm or voltage_V")
    v = voltage_V if voltage_V is not None else field_V_per_nm * width_nm
    return trapezoidal(height_eV, height_eV - v, width_nm, m_eff, lead_mass=lead_mass,
                       label=label or f"rectangular {height_eV:g} eV x {width_nm:g} nm, V={v:g} V")


def triangular(
    height_eV: float,
    field_V_per_nm: float,
    m_eff: float,
    *,
    extent_factor: float = 1.5,
    lead_mass: float | None = None,
    label: str | None = None,
) -> PotentialProfile:
    """Triangular barrier: abrupt rise to ``height`` then a linear fall at field F.

    The device region extends ``extent_factor`` times the classical width
    ``height / (qF)`` so the right lead sits below the left lead band edge and
    carries propagating states for every E > 0 (the Fowler-Nordheim geometry).
    """
    if field_V_per_nm <= 0:
        raise ValueError("field must be > 0 for a triangular barrier")
    if extent_factor <= 1.0:
        raise ValueError("extent_factor must exceed 1 so the barrier closes inside the device")
    l_nm = height_eV / field_V_per_nm
    width = extent_factor * l_nm
    return trapezoidal(height_eV, height_eV - field_V_per_nm * width, width, m_eff, lead_mass=lead_mass,
                       label=label or f"triangular {height_eV:g} eV, F={field_V_per_nm:g} V/nm")


def multi_barrier(
    segments: Sequence[tuple[float, float, float]],
    *,
    lead_mass: float,
    v_left_eV: float = 0.0,
    v_right_eV: float = 0.0,
    label: str = "multi-barrier",
) -> PotentialProfile:
    """Piecewise-constant profile from ``(width_nm, V_eV, m_eff)`` segments."""
    layers = tuple(
        Layer(nm_to_m(w), eV_to_J(v), eV_to_J(v), effective_mass_kg(m), f"seg{i}")
        for i, (w, v, m) in enumerate(segments)
    )
    return PotentialProfile(layers, _lead(v_left_eV, lead_mass, "left"), _lead(v_right_eV, lead_mass, "right"),
                            "left_lead_band_edge", label)


def double_barrier(
    height_eV: float,
    barrier_nm: float,
    well_nm: float,
    m_eff: float,
    *,
    well_mass: float | None = None,
    lead_mass: float | None = None,
    label: str | None = None,
) -> PotentialProfile:
    """Symmetric resonant double barrier (barrier / well / barrier)."""
    wm = m_eff if well_mass is None else well_mass
    lm = wm if lead_mass is None else lead_mass
    return multi_barrier(
        [(barrier_nm, height_eV, m_eff), (well_nm, 0.0, wm), (barrier_nm, height_eV, m_eff)],
        lead_mass=lm,
        label=label or f"double barrier {height_eV:g} eV, {barrier_nm:g}/{well_nm:g}/{barrier_nm:g} nm",
    )


def layered(
    layer_specs: Iterable[dict],
    *,
    left_lead: tuple[float, float],
    right_lead: tuple[float, float],
    energy_reference: str = "left_lead_band_edge",
    label: str = "layered profile",
    notes: Sequence[str] = (),
    metadata: dict | None = None,
) -> PotentialProfile:
    """General layered profile.

    ``layer_specs`` items: ``{"thickness_nm", "v_start_eV", "v_end_eV", "m_eff", "name"?, "material"?}``.
    ``left_lead`` / ``right_lead``: ``(potential_eV, mass_rel)``.
    """
    layers = tuple(
        Layer(nm_to_m(s["thickness_nm"]), eV_to_J(s["v_start_eV"]), eV_to_J(s.get("v_end_eV", s["v_start_eV"])),
              effective_mass_kg(s["m_eff"]), s.get("name", f"layer{i}"), s.get("material"))
        for i, s in enumerate(layer_specs)
    )
    return PotentialProfile(layers, _lead(left_lead[0], left_lead[1], "left"),
                            _lead(right_lead[0], right_lead[1], "right"), energy_reference, label,
                            notes=tuple(notes), metadata=dict(metadata or {}))


def from_samples(
    x_nm: Sequence[float],
    v_eV: Sequence[float],
    m_eff: float | Sequence[float],
    *,
    energy_reference: str,
    v_left_eV: float | None = None,
    v_right_eV: float | None = None,
    lead_mass: float | tuple[float, float] | None = None,
    label: str = "sampled profile",
    notes: Sequence[str] = (),
) -> PotentialProfile:
    """Piecewise-linear profile through sampled points.

    The potential is linear between consecutive samples (exact for the
    interpolant); the mass of each interval is the mean of its endpoint masses.
    Leads default to the first and last sample's potential and mass.
    ``energy_reference`` is mandatory.
    """
    x = np.asarray(x_nm, dtype=float)
    v = np.asarray(v_eV, dtype=float)
    if x.ndim != 1 or x.size < 2 or v.shape != x.shape:
        raise ValueError("need matching 1D x and V arrays with at least two samples")
    if not (np.all(np.isfinite(x)) and np.all(np.isfinite(v))):
        raise ValueError("sampled profile contains non-finite values")
    if np.any(np.diff(x) <= 0):
        raise ValueError("sample positions must be strictly increasing")
    m = np.broadcast_to(np.asarray(m_eff, dtype=float), x.shape)
    if np.any(m <= 0) or not np.all(np.isfinite(m)):
        raise ValueError("effective mass samples must be finite and > 0")
    layers = tuple(
        Layer(nm_to_m(x[i + 1] - x[i]), eV_to_J(v[i]), eV_to_J(v[i + 1]),
              effective_mass_kg(0.5 * (m[i] + m[i + 1])), f"s{i}")
        for i in range(x.size - 1)
    )
    if lead_mass is None:
        lm_l, lm_r = float(m[0]), float(m[-1])
    elif isinstance(lead_mass, tuple):
        lm_l, lm_r = lead_mass
    else:
        lm_l = lm_r = float(lead_mass)
    vl = float(v[0]) if v_left_eV is None else v_left_eV
    vr = float(v[-1]) if v_right_eV is None else v_right_eV
    return PotentialProfile(layers, _lead(vl, lm_l, "left"), _lead(vr, lm_r, "right"),
                            energy_reference, label, notes=tuple(notes),
                            metadata={"origin_x_nm": float(x[0]), "n_samples": int(x.size)})


def from_function(
    v_of_x_eV: Callable[[np.ndarray], np.ndarray],
    x_start_nm: float,
    x_end_nm: float,
    m_eff: float | Callable[[np.ndarray], np.ndarray],
    *,
    n_samples: int = 401,
    energy_reference: str = "left_lead_band_edge",
    v_left_eV: float | None = None,
    v_right_eV: float | None = None,
    lead_mass: float | None = None,
    label: str = "user-defined smooth potential",
) -> PotentialProfile:
    """Sample a smooth user-defined potential ``V(x_nm) -> eV`` onto a piecewise-linear profile."""
    if n_samples < 2:
        raise ValueError("n_samples must be >= 2")
    x = np.linspace(x_start_nm, x_end_nm, n_samples)
    v = np.asarray(v_of_x_eV(x), dtype=float)
    m = m_eff(x) if callable(m_eff) else m_eff
    return from_samples(x - x_start_nm, v, m, energy_reference=energy_reference, v_left_eV=v_left_eV,
                        v_right_eV=v_right_eV, lead_mass=lead_mass, label=label,
                        notes=(f"sampled from callable at {n_samples} points (piecewise-linear interpolant)",))


def from_csv(path: str | Path, *, energy_reference: str | None = None, label: str | None = None,
             lead_mass: float | None = None) -> PotentialProfile:
    """Import a profile from CSV with columns ``x_nm, V_eV[, m_rel]``.

    The energy reference must be supplied either as the argument or as a
    header comment line ``# energy_reference: <ref>``. Lines starting with
    ``#`` are otherwise ignored.
    """
    path = Path(path)
    header_ref = None
    rows: list[list[str]] = []
    with path.open(newline="") as fh:
        for line in fh:
            s = line.strip()
            if not s:
                continue
            if s.startswith("#"):
                body = s.lstrip("#").strip()
                if body.lower().startswith("energy_reference:"):
                    header_ref = body.split(":", 1)[1].strip()
                continue
            rows.append(next(csv.reader([s])))
    if not rows:
        raise ValueError(f"{path} contains no data")
    header = [h.strip() for h in rows[0]]
    if "x_nm" not in header or "V_eV" not in header:
        raise ValueError("CSV must have columns 'x_nm' and 'V_eV' (and optionally 'm_rel')")
    ref = energy_reference if energy_reference is not None else header_ref
    if ref is None:
        raise ValueError(
            f"{path}: imported potential profiles must define their energy reference "
            "(pass energy_reference= or add '# energy_reference: <ref>' to the file)"
        )
    data = np.array([[float(c) for c in r] for r in rows[1:]], dtype=float)
    ix, iv = header.index("x_nm"), header.index("V_eV")
    m = data[:, header.index("m_rel")] if "m_rel" in header else (lead_mass if lead_mass is not None else None)
    if m is None:
        raise ValueError("CSV has no 'm_rel' column; pass lead_mass= to supply a constant effective mass")
    x = data[:, ix]
    return from_samples(x - x[0], data[:, iv], m, energy_reference=ref, label=label or f"imported {path.name}",
                        notes=(f"imported from {path.name}",), lead_mass=lead_mass)


__all__ = [
    "ENERGY_REFERENCES",
    "Lead",
    "Layer",
    "PotentialProfile",
    "validate_energy_reference",
    "rectangular",
    "trapezoidal",
    "biased_rectangular",
    "triangular",
    "multi_barrier",
    "double_barrier",
    "layered",
    "from_samples",
    "from_function",
    "from_csv",
    "NM",
]
