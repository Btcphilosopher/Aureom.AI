r"""LEVEL 3a -- stable scattering-matrix solver for multilayer structures.

Method
------
The profile is discretised into slices of constant potential and mass
(:func:`discretize`). Flat layers are kept as a single exact slice; linear
layers are split into slices no thicker than ``max_slice_m`` with the
potential sampled at the slice midpoint (second-order accurate). In each
slice

.. math:: \psi = f\,e^{ik(x-x_l)} + g\,e^{ik(x_r-x)},\qquad
          k=\sqrt{2m(E-V)}/\hbar,\ \mathrm{Im}\,k\ge 0 .

Interfaces obey the BenDaniel-Duke conditions (:math:`\psi` and
:math:`\psi'/m` continuous). Each interface and each slice is a 2x2 scattering
matrix mapping incoming to outgoing amplitudes, and the structure is the
Redheffer star product of all of them. Because every propagation factor is
:math:`e^{ikd}` with :math:`|e^{ikd}|\le 1`, no exponentially *growing*
quantity ever appears: a 50 nm SiO2 barrier (T ~ 1e-280) is as stable as a
1 nm one. (The naive transfer-matrix product overflows here; see
``tests/numerical/test_stability.py``.)

Outputs are flux-normalised:

.. math:: T = |t|^2\,\frac{\mathrm{Re}(k_R/m_R)}{\mathrm{Re}(k_L/m_L)},\qquad R=|r|^2,

so unequal leads are handled correctly (amplitude transmission is *not* the
transmitted probability flux). For a lossless two-terminal problem
``R + T = 1``; the residual is returned as ``conservation_error``.

Degenerate points
-----------------
At an energy exactly equal to a slice potential the plane-wave basis is
degenerate (k = 0). Such energies are shifted by ``DEGENERACY_SHIFT_J``
(1e-9 eV); T is analytic in E so the induced change is O(1e-9) relative to
the local slope dT/dE.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .barriers import PotentialProfile
from .constants import HBAR, Q_E

DEGENERACY_SHIFT_J = 1e-9 * Q_E
DEFAULT_MAX_SLICE_M = 0.005e-9


@dataclass(frozen=True)
class SlicedProfile:
    thickness_m: np.ndarray
    potential_J: np.ndarray
    mass_kg: np.ndarray
    edges_m: np.ndarray
    v_left_J: float
    v_right_J: float
    m_left_kg: float
    m_right_kg: float

    @property
    def n_slices(self) -> int:
        return int(self.thickness_m.size)


def discretize(profile: PotentialProfile, max_slice_m: float = DEFAULT_MAX_SLICE_M,
               min_slices_per_linear_layer: int = 4) -> SlicedProfile:
    """Staircase discretisation: flat layers exact, linear layers midpoint-sampled."""
    if max_slice_m <= 0:
        raise ValueError("max_slice_m must be > 0")
    th, vv, mm = [], [], []
    for layer in profile.layers:
        if layer.is_constant:
            th.append(layer.thickness_m)
            vv.append(layer.v_start_J)
            mm.append(layer.mass_kg)
            continue
        n = max(min_slices_per_linear_layer, int(math.ceil(layer.thickness_m / max_slice_m)))
        h = layer.thickness_m / n
        mids = (np.arange(n) + 0.5) * h
        th.extend([h] * n)
        vv.extend(layer.potential_local(mids).tolist())
        mm.extend([layer.mass_kg] * n)
    t = np.asarray(th, dtype=float)
    return SlicedProfile(t, np.asarray(vv, dtype=float), np.asarray(mm, dtype=float),
                         np.concatenate([[0.0], np.cumsum(t)]),
                         profile.left.potential_J, profile.right.potential_J,
                         profile.left.mass_kg, profile.right.mass_kg)


def _wavevector(E: np.ndarray, V: np.ndarray, m: np.ndarray) -> np.ndarray:
    """k = sqrt(2m(E-V))/hbar with Im k >= 0 (decaying / outgoing branch)."""
    dE = E - V
    dE = np.where(np.abs(dE) < DEGENERACY_SHIFT_J, DEGENERACY_SHIFT_J, dE)
    return np.sqrt((2.0 * m * dE).astype(complex)) / HBAR


class _S:
    """2x2 scattering matrix (vectorised over energy): incoming (a+, b-) -> outgoing (a-, b+)."""

    __slots__ = ("tf", "rl", "tb", "rr")

    def __init__(self, tf, rl, tb, rr):
        self.tf, self.rl, self.tb, self.rr = tf, rl, tb, rr

    @staticmethod
    def interface(pa, pb) -> "_S":
        s = pa + pb
        return _S(2.0 * pa / s, (pa - pb) / s, 2.0 * pb / s, (pb - pa) / s)

    def star(self, other: "_S") -> "_S":
        d = 1.0 - self.rr * other.rl
        return _S(
            other.tf * self.tf / d,
            self.rl + self.tb * other.rl * self.tf / d,
            self.tb * other.tb / d,
            other.rr + other.tf * self.rr * other.tb / d,
        )

    def propagate(self, phase) -> "_S":
        """self (star) pure propagation with factor ``phase`` (|phase| <= 1)."""
        return _S(self.tf * phase, self.rl, self.tb * phase, self.rr * phase * phase)

    @staticmethod
    def identity(shape) -> "_S":
        one = np.ones(shape, dtype=complex)
        zero = np.zeros(shape, dtype=complex)
        return _S(one, zero, one.copy(), zero.copy())


@dataclass(frozen=True)
class ScatteringResult:
    energy_J: np.ndarray
    transmission: np.ndarray
    reflection: np.ndarray
    t_amplitude: np.ndarray
    r_amplitude: np.ndarray
    incident_flux: np.ndarray       # hbar Re(k_L/m_L) per unit incident amplitude^2  [m/s]
    transmitted_flux: np.ndarray
    reflected_flux: np.ndarray
    conservation_error: np.ndarray  # |R + T - 1|
    n_slices: int
    max_slice_m: float

    @property
    def log_transmission(self) -> np.ndarray:
        with np.errstate(divide="ignore"):
            return np.log(self.transmission)


def transmission(profile: PotentialProfile, energies_J: np.ndarray | float, *,
                 max_slice_m: float = DEFAULT_MAX_SLICE_M, sliced: SlicedProfile | None = None) -> ScatteringResult:
    """Flux-normalised transmission/reflection for an array of energies."""
    E = np.atleast_1d(np.asarray(energies_J, dtype=float))
    if np.any(~np.isfinite(E)):
        raise ValueError("energies must be finite")
    if np.any(E <= profile.left.potential_J):
        raise ValueError("energy must exceed the left-lead band edge (no propagating incident state)")
    sp = sliced if sliced is not None else discretize(profile, max_slice_m)
    kL = _wavevector(E, sp.v_left_J, sp.m_left_kg)
    kR = _wavevector(E, sp.v_right_J, sp.m_right_kg)
    pL, pR = kL / sp.m_left_kg, kR / sp.m_right_kg

    S = None
    p_prev = pL
    for j in range(sp.n_slices):
        kj = _wavevector(E, sp.potential_J[j], sp.mass_kg[j])
        pj = kj / sp.mass_kg[j]
        iface = _S.interface(p_prev, pj)
        S = iface if S is None else S.star(iface)
        S = S.propagate(np.exp(1j * kj * sp.thickness_m[j]))
        p_prev = pj
    S = S.star(_S.interface(p_prev, pR))

    t, r = S.tf, S.rl
    vel_l = HBAR * pL.real
    vel_r = HBAR * np.where(pR.real > 0, pR.real, 0.0)
    flux_t = vel_r * np.abs(t) ** 2
    flux_r = vel_l * np.abs(r) ** 2
    T = flux_t / vel_l
    R = flux_r / vel_l
    T = np.where(E <= sp.v_right_J, 0.0, T)
    return ScatteringResult(E, T, R, t, r, vel_l, flux_t, flux_r, np.abs(R + T - 1.0),
                            sp.n_slices, max_slice_m)


@dataclass(frozen=True)
class Wavefunction:
    """Solver-computed stationary scattering state for a unit-amplitude incident wave.

    Normalisation: incident plane wave ``exp(i k_L x)`` of unit amplitude in the
    left lead, so ``|psi|^2`` is a probability density *relative to the
    incident beam density* (dimensionless) and ``current`` is the probability
    current ``(hbar/m) Im(psi* dpsi/dx)`` in m/s per unit incident density.
    Electric current would additionally need carrier supply and charge.
    """

    x_m: np.ndarray
    psi: np.ndarray
    current: np.ndarray
    incident: np.ndarray     # incident component (left lead only, NaN elsewhere)
    reflected: np.ndarray    # reflected component (left lead only)
    transmitted: np.ndarray  # transmitted component (right lead only)
    energy_J: float
    transmission: float
    reflection: float
    incident_flux: float


def wavefunction(profile: PotentialProfile, energy_J: float, x_m: np.ndarray | None = None, *,
                 max_slice_m: float = DEFAULT_MAX_SLICE_M, n_points: int = 2000,
                 lead_extent_m: float | None = None) -> Wavefunction:
    """Reconstruct psi(x) from the stable S-matrix cascade (prefix/suffix method).

    In slice j with left-edge forward amplitude ``f`` and right-edge backward
    amplitude ``g``: ``f = tL / (1 - rL_r rR_l P^2)``, ``g = rR_l P f`` where
    ``(tL, rL_r)`` belong to the cascade left of the slice and ``rR_l`` to the
    cascade right of it -- every quantity is bounded, so the reconstruction is
    as stable as the transmission itself.
    """
    E = np.array([float(energy_J)])
    sp = discretize(profile, max_slice_m)
    N = sp.n_slices
    kL = _wavevector(E, sp.v_left_J, sp.m_left_kg)
    kR = _wavevector(E, sp.v_right_J, sp.m_right_kg)
    k = [_wavevector(E, sp.potential_J[j], sp.mass_kg[j]) for j in range(N)]
    p = [kL / sp.m_left_kg] + [k[j] / sp.mass_kg[j] for j in range(N)] + [kR / sp.m_right_kg]
    P = [np.exp(1j * k[j] * sp.thickness_m[j]) for j in range(N)]
    ifaces = [_S.interface(p[j], p[j + 1]) for j in range(N + 1)]

    # prefix[j]: left lead -> just inside left edge of slice j
    prefix = [None] * N
    S = ifaces[0]
    prefix[0] = S
    for j in range(1, N):
        S = S.propagate(P[j - 1]).star(ifaces[j])
        prefix[j] = S
    total = S.propagate(P[N - 1]).star(ifaces[N])
    # suffix[j]: just inside right edge of slice j -> right lead
    suffix = [None] * N
    S = ifaces[N]
    suffix[N - 1] = S
    for j in range(N - 2, -1, -1):
        S = ifaces[j + 1].propagate(P[j + 1]).star(S)
        suffix[j] = S

    f = np.empty(N, dtype=complex)
    g = np.empty(N, dtype=complex)
    for j in range(N):
        L, R = prefix[j], suffix[j]
        fj = L.tf / (1.0 - L.rr * R.rl * P[j] ** 2)
        f[j] = fj[0]
        g[j] = (R.rl * P[j] * fj)[0]

    t, r = total.tf[0], total.rl[0]
    W = sp.edges_m[-1]
    ext = 0.3 * W if lead_extent_m is None else lead_extent_m
    if x_m is None:
        x_m = np.linspace(-ext, W + ext, n_points)
    x = np.asarray(x_m, dtype=float)
    psi = np.empty(x.shape, dtype=complex)
    dpsi = np.empty(x.shape, dtype=complex)
    mass = np.empty(x.shape, dtype=float)
    inc = np.full(x.shape, np.nan, dtype=complex)
    ref = np.full(x.shape, np.nan, dtype=complex)
    trn = np.full(x.shape, np.nan, dtype=complex)

    kl, kr = kL[0], kR[0]
    left = x < 0
    inc[left] = np.exp(1j * kl * x[left])
    ref[left] = r * np.exp(-1j * kl * x[left])
    psi[left] = inc[left] + ref[left]
    dpsi[left] = 1j * kl * (inc[left] - ref[left])
    mass[left] = sp.m_left_kg
    right = x >= W
    trn[right] = t * np.exp(1j * kr * (x[right] - W))
    psi[right] = trn[right]
    dpsi[right] = 1j * kr * trn[right]
    mass[right] = sp.m_right_kg
    idx = np.clip(np.searchsorted(sp.edges_m, x, side="right") - 1, 0, N - 1)
    mid = ~left & ~right
    for j in np.unique(idx[mid]):
        sel = mid & (idx == j)
        kj = k[j][0]
        xl, xr = sp.edges_m[j], sp.edges_m[j + 1]
        fw = f[j] * np.exp(1j * kj * (x[sel] - xl))
        bw = g[j] * np.exp(1j * kj * (xr - x[sel]))
        psi[sel] = fw + bw
        dpsi[sel] = 1j * kj * (fw - bw)
        mass[sel] = sp.mass_kg[j]
    current = HBAR / mass * np.imag(np.conj(psi) * dpsi)
    vel_l = HBAR * (kl / sp.m_left_kg).real
    vel_r = HBAR * max((kr / sp.m_right_kg).real, 0.0)
    T = float(vel_r * abs(t) ** 2 / vel_l) if E[0] > sp.v_right_J else 0.0
    return Wavefunction(x, psi, current, inc, ref, trn, float(energy_J), T, float(abs(r) ** 2), float(vel_l))


def converged_transmission(profile: PotentialProfile, energy_J: float, *, rtol_log: float = 1e-6,
                           start_slice_m: float = 0.02e-9, max_refinements: int = 10) -> dict:
    """Halve the slice size until log T changes by < ``rtol_log`` (relative).

    Returns the Richardson-extrapolated estimate (second-order scheme) and an
    error estimate. Profiles made only of flat layers are exact at any slice
    size and return immediately.
    """
    if profile.is_piecewise_constant:
        res = transmission(profile, energy_J, max_slice_m=start_slice_m)
        return {"log_transmission": float(res.log_transmission[0]), "error_estimate": 0.0,
                "max_slice_m": start_slice_m, "refinements": 0, "converged": True, "history": []}
    h = start_slice_m
    prev = float(transmission(profile, energy_J, max_slice_m=h).log_transmission[0])
    history = [(h, prev)]
    for i in range(max_refinements):
        h /= 2.0
        cur = float(transmission(profile, energy_J, max_slice_m=h).log_transmission[0])
        history.append((h, cur))
        extrap = cur + (cur - prev) / 3.0
        err = abs(cur - prev) / 3.0
        if err <= rtol_log * max(1.0, abs(cur)):
            return {"log_transmission": extrap, "error_estimate": err, "max_slice_m": h,
                    "refinements": i + 1, "converged": True, "history": history}
        prev = cur
    return {"log_transmission": cur + (cur - prev) / 3.0, "error_estimate": abs(cur - prev) / 3.0,
            "max_slice_m": h, "refinements": max_refinements, "converged": False, "history": history}


def naive_transfer_matrix_log_t(profile: PotentialProfile, energy_J: float,
                                max_slice_m: float = DEFAULT_MAX_SLICE_M) -> float:
    """Unscaled transfer-matrix product -- for the stability comparison test ONLY.

    Multiplies 2x2 matrices containing exp(+kappa d); overflows (returns nan or
    inf) for thick barriers. Not used by any production path.
    """
    sp = discretize(profile, max_slice_m)
    E = np.array([float(energy_J)])
    kL = _wavevector(E, sp.v_left_J, sp.m_left_kg)[0]
    kR = _wavevector(E, sp.v_right_J, sp.m_right_kg)[0]
    M = np.eye(2, dtype=complex)
    with np.errstate(all="ignore"):
        for j in range(sp.n_slices):
            q = _wavevector(E, sp.potential_J[j], sp.mass_kg[j])[0] * -1j  # q = -i k  (real when evanescent)
            m = sp.mass_kg[j]
            d = sp.thickness_m[j]
            ch, sh = np.cosh(q * d), np.sinh(q * d)
            M = np.array([[ch, m * sh / q], [q * sh / m, ch]]) @ M
        WL = np.array([[1, 1], [1j * kL / sp.m_left_kg, -1j * kL / sp.m_left_kg]])
        WR = np.array([[1, 1], [1j * kR / sp.m_right_kg, -1j * kR / sp.m_right_kg]])
        N = np.linalg.solve(WR, M @ WL)
        r = -N[1, 0] / N[1, 1]
        t = N[0, 0] + N[0, 1] * r
        T = abs(t) ** 2 * (kR / sp.m_right_kg).real / (kL / sp.m_left_kg).real
        return float(np.log(T))


__all__ = [
    "SlicedProfile",
    "ScatteringResult",
    "Wavefunction",
    "discretize",
    "transmission",
    "wavefunction",
    "converged_transmission",
    "naive_transfer_matrix_log_t",
    "DEFAULT_MAX_SLICE_M",
]
