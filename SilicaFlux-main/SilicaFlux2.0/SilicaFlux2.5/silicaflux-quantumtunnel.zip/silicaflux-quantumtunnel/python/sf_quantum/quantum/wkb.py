r"""LEVEL 2 -- WKB (semiclassical) tunnelling.

Model
-----
.. math::

   S(E) = \int_{V(x)>E} \frac{\sqrt{2 m(x)\,(V(x)-E)}}{\hbar}\,dx, \qquad
   T_\mathrm{WKB}(E) \approx e^{-2S(E)}

The action is integrated over every classically forbidden interval.
``log_transmission = -2 S`` is the primary output; ``transmission`` is only
its exponential and underflows gracefully to 0.0 for very thick barriers
without corrupting the log value.

Integration
-----------
* :func:`wkb` on a :class:`~sf_quantum.quantum.barriers.PotentialProfile` is
  *exact* for the profile: within a linear layer
  :math:`\int\sqrt{u}\,dx` is evaluated in closed form, turning points inside
  layers are located analytically, and the per-layer mass is applied
  piecewise. Smooth or imported potentials are piecewise-linear interpolants,
  so the only approximation is the interpolation itself (tested to converge
  as h^2 in the barrier interior and h^1.5 overall, the latter set by the
  square-root behaviour of the integrand at turning points).
* :func:`wkb_callable` integrates a callable :math:`V(x)` with adaptive Gauss-
  Kronrod quadrature between automatically detected turning points (brentq
  refinement). Used to cross-check the piecewise integration.

Validity diagnostics (never silently ignored)
---------------------------------------------
``ABOVE_BARRIER``      E >= max V: there is no forbidden region. The WKB
                       tunnelling formula does not apply and is **not**
                       replaced by T = 1 -- over-barrier reflection is real.
                       ``transmission``/``log_transmission`` are NaN.
``WEAK_TUNNELLING``    S < 1 (T_WKB > e^-2): near the barrier top or very thin;
                       the exponential approximation is unreliable.
``NARROW_BARRIER``     forbidden width * kappa_max < 3: barrier comparable to
                       the evanescent decay length.
``ABRUPT_INTERFACE``   a potential step at or inside the forbidden region; WKB
                       omits the interface prefactor (for an abrupt rectangle
                       ``16 k^2 kappa^2/(k^2+kappa^2)^2``).
``MASS_DISCONTINUITY`` effective-mass step inside/at the forbidden region.
``MULTIPLE_FORBIDDEN_REGIONS`` resonant multi-barrier structure; the WKB
                       product ignores interference and resonances.
``RAPID_VARIATION``    |dkappa/dx| / kappa^2 > 0.5 in the barrier interior.
``NO_TRANSMITTED_STATE`` E <= right-lead band edge: no propagating outgoing
                       state, transmission is exactly 0 (physical, not a WKB
                       failure).

Whenever a reliability flag is raised the result carries a recommendation to
compare against the numerical scattering solver.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable

import numpy as np
from scipy import integrate, optimize

from .barriers import PotentialProfile
from .constants import HBAR
from .rectangular import abrupt_prefactor


class WKBFlag(str, Enum):
    ABOVE_BARRIER = "above_barrier"
    WEAK_TUNNELLING = "weak_tunnelling"
    NARROW_BARRIER = "narrow_barrier"
    ABRUPT_INTERFACE = "abrupt_interface"
    MASS_DISCONTINUITY = "mass_discontinuity"
    MULTIPLE_FORBIDDEN_REGIONS = "multiple_forbidden_regions"
    RAPID_VARIATION = "rapid_variation"
    NO_TRANSMITTED_STATE = "no_transmitted_state"


#: Flags that make the WKB estimate unreliable (NO_TRANSMITTED_STATE is exact physics).
RELIABILITY_FLAGS = frozenset(
    {
        WKBFlag.ABOVE_BARRIER,
        WKBFlag.WEAK_TUNNELLING,
        WKBFlag.NARROW_BARRIER,
        WKBFlag.ABRUPT_INTERFACE,
        WKBFlag.MASS_DISCONTINUITY,
        WKBFlag.MULTIPLE_FORBIDDEN_REGIONS,
        WKBFlag.RAPID_VARIATION,
    }
)

RECOMMEND_NUMERICAL = (
    "WKB is unreliable for this configuration; compare with the numerical scattering solver "
    "(sf_quantum.quantum.scattering.transmission / `sf-quantum solve scattering`)."
)

WEAK_ACTION_THRESHOLD = 1.0
NARROW_KAPPA_WIDTH = 3.0
RAPID_VARIATION_THRESHOLD = 0.5
ABRUPT_RELATIVE_STEP = 0.05


@dataclass(frozen=True)
class WKBResult:
    energy_J: float
    action: float
    log_transmission: float
    transmission: float
    turning_points_m: tuple[tuple[float, float], ...]
    flags: tuple[WKBFlag, ...]
    recommendation: str | None
    diagnostics: dict = field(default_factory=dict)

    @property
    def reliable(self) -> bool:
        return not (set(self.flags) & RELIABILITY_FLAGS)

    def as_dict(self) -> dict:
        return {
            "energy_J": self.energy_J,
            "action": self.action,
            "log_transmission": self.log_transmission,
            "transmission": self.transmission,
            "turning_points_m": [list(t) for t in self.turning_points_m],
            "flags": [f.value for f in self.flags],
            "reliable": self.reliable,
            "recommendation": self.recommendation,
            "diagnostics": self.diagnostics,
        }


def _sqrt_linear_integral(u1: np.ndarray, u2: np.ndarray, d: np.ndarray) -> np.ndarray:
    """Exact integral of sqrt(u) over a layer where u is linear from u1 to u2 (both >= 0)."""
    s1, s2 = np.sqrt(u1), np.sqrt(u2)
    denom = s1 + s2
    with np.errstate(invalid="ignore", divide="ignore"):
        val = (2.0 / 3.0) * d * (u1 + s1 * s2 + u2) / denom
    return np.where(denom > 0, val, 0.0)


def _layer_arrays(profile: PotentialProfile):
    d = np.array([l.thickness_m for l in profile.layers])
    v1 = np.array([l.v_start_J for l in profile.layers])
    v2 = np.array([l.v_end_J for l in profile.layers])
    m = np.array([l.mass_kg for l in profile.layers])
    x0 = profile.boundaries_m[:-1]
    return d, v1, v2, m, x0


def _forbidden_parts(u1, u2, d, x0):
    """Per-layer forbidden sub-interval [xa, xb] and the action integral of sqrt(u) over it."""
    pos1, pos2 = u1 > 0, u2 > 0
    both = pos1 & pos2
    only1 = pos1 & ~pos2
    only2 = ~pos1 & pos2
    xa = np.full_like(d, np.nan)
    xb = np.full_like(d, np.nan)
    integral = np.zeros_like(d)
    # whole layer forbidden
    xa[both], xb[both] = x0[both], x0[both] + d[both]
    integral[both] = _sqrt_linear_integral(u1[both], u2[both], d[both])
    # forbidden at the start, turning point inside
    f = u1[only1] / (u1[only1] - u2[only1])
    xa[only1], xb[only1] = x0[only1], x0[only1] + f * d[only1]
    integral[only1] = (2.0 / 3.0) * f * d[only1] * np.sqrt(u1[only1])
    # forbidden at the end
    f = -u1[only2] / (u2[only2] - u1[only2])
    xa[only2], xb[only2] = x0[only2] + f * d[only2], x0[only2] + d[only2]
    integral[only2] = (2.0 / 3.0) * (1.0 - f) * d[only2] * np.sqrt(u2[only2])
    return xa, xb, integral


def wkb_action_array(profile: PotentialProfile, energies_J: np.ndarray) -> np.ndarray:
    """Vectorised WKB action S(E) for many energies (no diagnostics)."""
    d, v1, v2, m, x0 = _layer_arrays(profile)
    E = np.atleast_1d(np.asarray(energies_J, dtype=float))[:, None]
    u1 = v1[None, :] - E
    u2 = v2[None, :] - E
    s1, s2 = np.sqrt(np.clip(u1, 0, None)), np.sqrt(np.clip(u2, 0, None))
    pos1, pos2 = u1 > 0, u2 > 0
    with np.errstate(invalid="ignore", divide="ignore"):
        whole = (2.0 / 3.0) * d * (u1 + s1 * s2 + u2) / (s1 + s2)
        f1 = u1 / (u1 - u2)
        part1 = (2.0 / 3.0) * f1 * d * s1
        part2 = (2.0 / 3.0) * (1.0 - (-u1 / (u2 - u1))) * d * s2
    val = np.where(pos1 & pos2, whole, np.where(pos1, part1, np.where(pos2, part2, 0.0)))
    return np.sum(np.sqrt(2.0 * m)[None, :] * val, axis=1) / HBAR


def wkb(profile: PotentialProfile, energy_J: float, *, prefactor: str = "none") -> WKBResult:
    """WKB action, log-transmission and validity diagnostics at one energy.

    ``prefactor="abrupt_rectangular"`` multiplies by the abrupt-interface
    factor (only for a single flat layer between identical leads); the default
    is plain WKB.
    """
    E = float(energy_J)
    if not np.isfinite(E):
        raise ValueError("energy must be finite")
    if E <= profile.left.potential_J:
        raise ValueError("energy is at or below the left-lead band edge: no propagating incident state")
    d, v1, v2, m, x0 = _layer_arrays(profile)
    u1, u2 = v1 - E, v2 - E
    xa, xb, integ = _forbidden_parts(u1, u2, d, x0)
    action = float(np.sum(np.sqrt(2.0 * m) * integ) / HBAR)

    flags: list[WKBFlag] = []
    diag: dict = {}
    forbidden = ~np.isnan(xa)
    # merge contiguous forbidden pieces into regions
    regions: list[list[float]] = []
    region_layers: list[list[int]] = []
    for i in np.flatnonzero(forbidden):
        if regions and abs(xa[i] - regions[-1][1]) <= 1e-15 * max(1.0, abs(xa[i])) + 1e-30:
            regions[-1][1] = xb[i]
            region_layers[-1].append(i)
        else:
            regions.append([xa[i], xb[i]])
            region_layers.append([i])
    turning = tuple((float(a), float(b)) for a, b in regions)

    if E <= profile.right.potential_J:
        flags.append(WKBFlag.NO_TRANSMITTED_STATE)

    if not regions:
        flags.append(WKBFlag.ABOVE_BARRIER)
        return WKBResult(E, 0.0, float("nan"), float("nan"), (), tuple(flags),
                         "Energy is above the barrier maximum: no classically forbidden region. "
                         "Over-barrier reflection is not described by WKB tunnelling; "
                         + RECOMMEND_NUMERICAL, {"v_max_J": profile.v_max_J})

    kap1 = np.sqrt(2.0 * m * np.clip(u1, 0, None)) / HBAR
    kap2 = np.sqrt(2.0 * m * np.clip(u2, 0, None)) / HBAR
    kappa_max = float(np.max(np.where(forbidden, np.maximum(kap1, kap2), 0.0)))
    widths = [b - a for a, b in regions]
    diag.update({
        "kappa_max_per_m": kappa_max,
        "forbidden_widths_m": widths,
        "n_forbidden_regions": len(regions),
        "u_max_J": float(np.max(np.where(forbidden, np.maximum(u1, u2), 0.0))),
    })

    if len(regions) > 1:
        flags.append(WKBFlag.MULTIPLE_FORBIDDEN_REGIONS)
    if action < WEAK_ACTION_THRESHOLD:
        flags.append(WKBFlag.WEAK_TUNNELLING)
    if max(widths) * kappa_max < NARROW_KAPPA_WIDTH:
        flags.append(WKBFlag.NARROW_BARRIER)

    # abrupt potential / mass steps at or inside a forbidden region
    u_max = diag["u_max_J"]
    abrupt_steps, mass_steps = [], []
    for disc in profile.discontinuities():
        x = disc["x_m"]
        inside = any(a - 1e-15 <= x <= b + 1e-15 for a, b in regions)
        if not inside:
            continue
        if abs(disc["dV_J"]) >= ABRUPT_RELATIVE_STEP * u_max:
            abrupt_steps.append({"x_m": x, "dV_J": disc["dV_J"]})
        if disc["dm_kg"] != 0.0:
            mass_steps.append({"x_m": x, "dm_kg": disc["dm_kg"]})
    if abrupt_steps:
        flags.append(WKBFlag.ABRUPT_INTERFACE)
        diag["abrupt_steps"] = abrupt_steps
    if mass_steps:
        flags.append(WKBFlag.MASS_DISCONTINUITY)
        diag["mass_steps"] = mass_steps

    # WKB smoothness criterion |dkappa/dx|/kappa^2 = m|s| / (hbar^2 kappa^3),
    # evaluated where kappa >= kappa_max / 2 (away from the turning points)
    slopes = (v2 - v1) / d
    worst = 0.0
    k_floor = 0.5 * kappa_max
    for i in np.flatnonzero(forbidden):
        if slopes[i] == 0.0:
            continue
        k_hi, k_lo = max(kap1[i], kap2[i]), min(kap1[i], kap2[i])
        if k_hi < k_floor:
            continue
        # the parameter grows as kappa falls, so the worst interior point of a
        # linear layer is at max(kappa_min, kappa_max/2)
        k_eval = max(k_lo, k_floor)
        worst = max(worst, m[i] * abs(slopes[i]) / (HBAR**2 * k_eval**3))
    diag["max_variation_parameter"] = worst
    if worst > RAPID_VARIATION_THRESHOLD:
        flags.append(WKBFlag.RAPID_VARIATION)

    log_t = -2.0 * action
    if prefactor == "abrupt_rectangular":
        if len(profile.layers) != 1 or not profile.layers[0].is_constant or \
                profile.left.potential_J != profile.right.potential_J or \
                profile.left.mass_kg != profile.right.mass_kg:
            raise ValueError("abrupt_rectangular prefactor only applies to a single flat barrier between identical leads")
        lay = profile.layers[0]
        pf = abrupt_prefactor(E - profile.left.potential_J, lay.v_start_J - profile.left.potential_J,
                              lay.mass_kg, profile.left.mass_kg)[0]
        log_t += float(np.log(pf))
        diag["prefactor"] = float(pf)
    elif prefactor != "none":
        raise ValueError("prefactor must be 'none' or 'abrupt_rectangular'")

    if WKBFlag.NO_TRANSMITTED_STATE in flags:
        log_t, trans = float("-inf"), 0.0
    else:
        trans = float(np.exp(log_t))
    reco = RECOMMEND_NUMERICAL if set(flags) & RELIABILITY_FLAGS else None
    return WKBResult(E, action, log_t, trans, turning, tuple(flags), reco, diag)


def wkb_spectrum(profile: PotentialProfile, energies_J: np.ndarray) -> dict:
    """WKB over an energy grid. Returns arrays; above-barrier points are NaN."""
    E = np.atleast_1d(np.asarray(energies_J, dtype=float))
    if np.any(E <= profile.left.potential_J):
        raise ValueError("all energies must exceed the left-lead band edge")
    S = wkb_action_array(profile, E)
    above = E >= profile.v_max_J
    log_t = np.where(above, np.nan, -2.0 * S)
    no_tx = E <= profile.right.potential_J
    log_t = np.where(no_tx & ~above, -np.inf, log_t)
    with np.errstate(over="ignore"):
        trans = np.exp(log_t)
    weak = (~above) & (S < WEAK_ACTION_THRESHOLD)
    return {"energy_J": E, "action": S, "log_transmission": log_t, "transmission": trans,
            "above_barrier": above, "weak_tunnelling": weak, "no_transmitted_state": no_tx}


def wkb_callable(
    potential_J: Callable[[np.ndarray], np.ndarray],
    mass_kg: Callable[[np.ndarray], np.ndarray] | float,
    x_range_m: tuple[float, float],
    energy_J: float,
    *,
    n_scan: int = 4001,
    epsrel: float = 1e-10,
) -> tuple[float, list[tuple[float, float]]]:
    """WKB action for a callable potential via adaptive quadrature.

    Returns ``(S, turning_points)``. Turning points are bracketed on an
    ``n_scan`` grid and refined with Brent's method.
    """
    a, b = x_range_m
    xs = np.linspace(a, b, n_scan)
    g = np.asarray(potential_J(xs), dtype=float) - energy_J
    if not np.all(np.isfinite(g)):
        raise ValueError("potential returned non-finite values")
    mfun = (lambda x: float(mass_kg)) if np.isscalar(mass_kg) else mass_kg

    def gfun(x):
        return float(potential_J(np.array([x]))[0]) - energy_J

    intervals = []
    inside = g[0] > 0
    start = a if inside else None
    for i in range(1, n_scan):
        if (g[i] > 0) != (g[i - 1] > 0):
            root = optimize.brentq(gfun, xs[i - 1], xs[i], xtol=1e-18 * max(1.0, abs(b - a)) + 1e-22)
            if g[i] > 0:
                start = root
            else:
                intervals.append((start, root))
                start = None
    if start is not None:
        intervals.append((start, b))

    def integrand(x):
        u = gfun(x)
        return np.sqrt(2.0 * float(mfun(np.array([x]))[0] if not np.isscalar(mass_kg) else mfun(x)) * max(u, 0.0))

    total = 0.0
    for lo, hi in intervals:
        val, _ = integrate.quad(integrand, lo, hi, epsabs=0.0, epsrel=epsrel, limit=400)
        total += val
    return total / HBAR, intervals


__all__ = [
    "WKBFlag",
    "WKBResult",
    "RELIABILITY_FLAGS",
    "RECOMMEND_NUMERICAL",
    "wkb",
    "wkb_spectrum",
    "wkb_action_array",
    "wkb_callable",
]
