"""Explicit unit conversions between human-facing units and internal SI.

Every conversion is a named function; nothing in the package multiplies by a
bare magic number. The human-facing units supported are nm, eV, V/nm, MV/cm,
A/cm^2 and cm^-3 (doping). Each function is covered by
``tests/physics/test_units.py``.

The most common bug in tunnelling codes -- taking ``sqrt(2*m*(V-E))`` with V
and E in electronvolts -- is prevented by convention: all solver entry points
take joules. The human-facing wrappers convert first.
"""

from __future__ import annotations

import numpy as np

from .constants import K_B, M_E, Q_E

ArrayLike = float | np.ndarray

# --- length ---------------------------------------------------------------

NM = 1e-9  # metres per nanometre (exact by definition of the SI prefix)
CM = 1e-2  # metres per centimetre


def nm_to_m(x_nm: ArrayLike) -> ArrayLike:
    return np.asarray(x_nm, dtype=float) * NM if np.ndim(x_nm) else float(x_nm) * NM


def m_to_nm(x_m: ArrayLike) -> ArrayLike:
    return np.asarray(x_m, dtype=float) / NM if np.ndim(x_m) else float(x_m) / NM


# --- energy ---------------------------------------------------------------

def eV_to_J(e_eV: ArrayLike) -> ArrayLike:
    """Electronvolts -> joules (1 eV = e * 1 V, e from CODATA)."""
    return np.asarray(e_eV, dtype=float) * Q_E if np.ndim(e_eV) else float(e_eV) * Q_E


def J_to_eV(e_J: ArrayLike) -> ArrayLike:
    return np.asarray(e_J, dtype=float) / Q_E if np.ndim(e_J) else float(e_J) / Q_E


def thermal_energy_J(temperature_K: float) -> float:
    if temperature_K < 0:
        raise ValueError("temperature must be non-negative (kelvin)")
    return K_B * float(temperature_K)


# --- electric field -------------------------------------------------------

def V_per_nm_to_V_per_m(f: ArrayLike) -> ArrayLike:
    return np.asarray(f, dtype=float) / NM if np.ndim(f) else float(f) / NM


def V_per_m_to_V_per_nm(f: ArrayLike) -> ArrayLike:
    return np.asarray(f, dtype=float) * NM if np.ndim(f) else float(f) * NM


def MV_per_cm_to_V_per_m(f: ArrayLike) -> ArrayLike:
    """1 MV/cm = 1e6 V / 1e-2 m = 1e8 V/m."""
    return np.asarray(f, dtype=float) * (1e6 / CM) if np.ndim(f) else float(f) * (1e6 / CM)


def V_per_m_to_MV_per_cm(f: ArrayLike) -> ArrayLike:
    return np.asarray(f, dtype=float) / (1e6 / CM) if np.ndim(f) else float(f) / (1e6 / CM)


# --- current density ------------------------------------------------------

def A_per_cm2_to_A_per_m2(j: ArrayLike) -> ArrayLike:
    """1 A/cm^2 = 1e4 A/m^2."""
    return np.asarray(j, dtype=float) / CM**2 if np.ndim(j) else float(j) / CM**2


def A_per_m2_to_A_per_cm2(j: ArrayLike) -> ArrayLike:
    return np.asarray(j, dtype=float) * CM**2 if np.ndim(j) else float(j) * CM**2


# --- concentration --------------------------------------------------------

def per_cm3_to_per_m3(n: ArrayLike) -> ArrayLike:
    """1 cm^-3 = 1e6 m^-3."""
    return np.asarray(n, dtype=float) / CM**3 if np.ndim(n) else float(n) / CM**3


def per_m3_to_per_cm3(n: ArrayLike) -> ArrayLike:
    return np.asarray(n, dtype=float) * CM**3 if np.ndim(n) else float(n) * CM**3


# --- capacitance per area -------------------------------------------------

def F_per_m2_to_uF_per_cm2(c: ArrayLike) -> ArrayLike:
    """1 F/m^2 = 1e6 uF / 1e4 cm^2 = 100 uF/cm^2."""
    return np.asarray(c, dtype=float) * 1e6 * CM**2 if np.ndim(c) else float(c) * 1e6 * CM**2


# --- effective mass -------------------------------------------------------

def effective_mass_kg(m_rel: ArrayLike) -> ArrayLike:
    """Convert a dimensionless effective-mass ratio m*/m_e to kilograms.

    Raises ``ValueError`` for non-positive or non-finite ratios: an effective
    mass of zero or below has no meaning in the parabolic effective-mass
    Schroedinger equation used here.
    """
    arr = np.asarray(m_rel, dtype=float)
    if not np.all(np.isfinite(arr)) or np.any(arr <= 0):
        raise ValueError(f"effective-mass ratio must be finite and > 0, got {m_rel!r}")
    return arr * M_E if np.ndim(m_rel) else float(arr) * M_E


def mass_ratio(m_kg: ArrayLike) -> ArrayLike:
    return np.asarray(m_kg, dtype=float) / M_E if np.ndim(m_kg) else float(m_kg) / M_E


__all__ = [name for name in dir() if not name.startswith("_") and name not in {"annotations", "np"}]
