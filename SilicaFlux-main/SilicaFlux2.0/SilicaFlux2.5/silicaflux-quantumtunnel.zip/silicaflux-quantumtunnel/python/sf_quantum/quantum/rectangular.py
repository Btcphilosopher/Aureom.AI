r"""LEVEL 1 -- exact transmission through an ideal rectangular barrier.

Model and assumptions
---------------------
* Stationary, one-dimensional, single-band effective-mass Schroedinger
  equation; coherent, elastic, no scattering or dissipation.
* Barrier of height :math:`V_0` and width :math:`a`, effective mass
  :math:`m_b`; both leads flat at :math:`V=0` with the *same* effective mass
  :math:`m_\ell` (identical lead materials).
* BenDaniel-Duke interface conditions: :math:`\psi` and
  :math:`\psi'/m` continuous.
* Incident energy :math:`E>0` (a propagating state exists in the lead).

Derivation (independent of the numerical solvers)
-------------------------------------------------
With :math:`k^2 = 2m_\ell E/\hbar^2`, :math:`q^2 = 2m_b(V_0-E)/\hbar^2`
(:math:`q^2<0` above the barrier), :math:`\tilde k = k/m_\ell` and
:math:`\tilde q = q/m_b`, matching at both interfaces gives the *flux*
transmission probability

.. math::

   T = \left[1 + \frac{(\tilde k^2+\tilde q^2)^2}{4\tilde k^2}\,
       m_b^2 \left(\frac{\sinh qa}{q}\right)^2\right]^{-1}

where :math:`\sinh(qa)/q` is the entire function equal to
:math:`\sin(|q|a)/|q|` for :math:`q^2<0` and to :math:`a` at :math:`q=0`.
For equal masses this reduces to the textbook results
:math:`T=[1+V_0^2\sinh^2(\kappa a)/(4E(V_0-E))]^{-1}` (tunnelling),
:math:`T=[1+V_0^2\sin^2(k_b a)/(4E(E-V_0))]^{-1}` (above barrier) and
:math:`T=[1+m a^2 V_0/(2\hbar^2)]^{-1}` at :math:`E=V_0`.

Because the leads are identical, the flux ratio equals the squared amplitude
ratio :math:`|t|^2`; the general unequal-lead case is handled by the
numerical solvers, which apply the explicit velocity factor.

Numerics
--------
The unified form is continuous through :math:`E=V_0` (series for
:math:`\sinh(x)/x` near 0) and is evaluated in the log domain,
:math:`\ln T = -\mathrm{logaddexp}(0, \ln P + 2\ln|f|)`, so a 20 nm SiO2
barrier with :math:`T\sim10^{-200}` does not overflow ``sinh`` and
:math:`R=1-T` is computed without cancellation.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .constants import HBAR

_SERIES_X = 1e-3  # below this |qa| use the Taylor series of sinh(x)/x, sin(x)/x


@dataclass(frozen=True)
class RectangularResult:
    energy_J: np.ndarray
    transmission: np.ndarray
    reflection: np.ndarray
    log_transmission: np.ndarray
    regime: np.ndarray  # 'tunnelling' | 'at_barrier' | 'above_barrier'

    def as_dict(self) -> dict:
        return {
            "energy_J": self.energy_J.tolist(),
            "transmission": self.transmission.tolist(),
            "reflection": self.reflection.tolist(),
            "log_transmission": self.log_transmission.tolist(),
            "regime": self.regime.tolist(),
        }


def _log_sinh(x: np.ndarray) -> np.ndarray:
    """log(sinh(x)) for x > 0 without overflow."""
    x = np.asarray(x, dtype=float)
    out = np.empty_like(x)
    small = x < 20.0
    out[small] = np.log(np.sinh(x[small]))
    big = ~small
    out[big] = x[big] - np.log(2.0) + np.log1p(-np.exp(-2.0 * x[big]))
    return out


def rectangular_transmission(
    energy_J: np.ndarray | float,
    height_J: float,
    width_m: float,
    barrier_mass_kg: float,
    lead_mass_kg: float | None = None,
) -> RectangularResult:
    """Exact flux transmission/reflection for an ideal rectangular barrier.

    Parameters are SI. ``energy_J`` may be an array. Raises ``ValueError`` for
    ``E <= 0`` (no propagating incident state), non-positive width or mass.
    ``height_J`` may be negative (a square well), in which case every energy is
    above the 'barrier'.
    """
    E = np.atleast_1d(np.asarray(energy_J, dtype=float))
    if np.any(~np.isfinite(E)) or np.any(E <= 0):
        raise ValueError("incident energy must be finite and > 0 (lead band edge is at 0)")
    if not (width_m > 0 and np.isfinite(width_m)):
        raise ValueError("barrier width must be > 0")
    if not (barrier_mass_kg > 0):
        raise ValueError("barrier mass must be > 0")
    m_l = barrier_mass_kg if lead_mass_kg is None else lead_mass_kg
    if not (m_l > 0):
        raise ValueError("lead mass must be > 0")
    m_b = barrier_mass_kg
    a = width_m

    k2 = 2.0 * m_l * E / HBAR**2                # lead wavevector^2
    q2 = 2.0 * m_b * (height_J - E) / HBAR**2   # barrier decay constant^2 (negative above barrier)
    km2 = k2 / m_l**2
    qm2 = q2 / m_b**2
    # prefactor P = (k~^2 + q~^2)^2 m_b^2 / (4 k~^2)   (>= 0)
    # log|f| where f = sinh(qa)/q (analytically continued)
    q = np.sqrt(np.abs(q2))
    x = q * a
    log_f = np.empty_like(E)
    regime = np.empty(E.shape, dtype=object)
    with np.errstate(divide="ignore"):
        # the prefactor vanishes (log -> -inf, T = 1) where k~^2 + q~^2 == 0
        log_p = 2.0 * np.log(np.abs(km2 + qm2)) + 2.0 * np.log(m_b) - np.log(4.0 * km2)
        tun = q2 > 0
        above = q2 < 0
        at = q2 == 0
        # tunnelling
        xt = x[tun]
        series = xt < _SERIES_X
        lf = np.empty_like(xt)
        lf[series] = np.log(a) + np.log1p(xt[series] ** 2 / 6.0 + xt[series] ** 4 / 120.0)
        lf[~series] = _log_sinh(xt[~series]) - np.log(q[tun][~series])
        log_f[tun] = lf
        regime[tun] = "tunnelling"
        # above barrier: sin(x)/q  (may be exactly zero at resonance)
        xa = x[above]
        series = xa < _SERIES_X
        fa = np.empty_like(xa)
        fa[series] = a * (1.0 - xa[series] ** 2 / 6.0 + xa[series] ** 4 / 120.0)
        fa[~series] = np.sin(xa[~series]) / q[above][~series]
        log_f[above] = np.log(np.abs(fa))
        regime[above] = "above_barrier"
        # exactly at the barrier top
        log_f[at] = np.log(a)
        regime[at] = "at_barrier"

        # Pf^2 = 0 when the prefactor vanishes (km2 + qm2 == 0) or f == 0 (resonance)
        log_pf2 = log_p + 2.0 * log_f
        log_t = -np.logaddexp(0.0, log_pf2)
        log_r = log_pf2 - np.logaddexp(0.0, log_pf2)
    T = np.exp(log_t)
    R = np.exp(log_r)
    return RectangularResult(E, T, R, log_t, regime)


def textbook_equal_mass(energy_J: np.ndarray | float, height_J: float, width_m: float, mass_kg: float) -> np.ndarray:
    """Direct textbook formula (equal masses), for cross-checking only.

    Overflows for thick barriers by design -- it is the naive expression.
    """
    E = np.atleast_1d(np.asarray(energy_J, dtype=float))
    V0 = height_J
    out = np.empty_like(E)
    below = E < V0
    kap = np.sqrt(2 * mass_kg * (V0 - E[below])) / HBAR
    out[below] = 1.0 / (1.0 + V0**2 * np.sinh(kap * width_m) ** 2 / (4 * E[below] * (V0 - E[below])))
    abv = E > V0
    kb = np.sqrt(2 * mass_kg * (E[abv] - V0)) / HBAR
    out[abv] = 1.0 / (1.0 + V0**2 * np.sin(kb * width_m) ** 2 / (4 * E[abv] * (E[abv] - V0)))
    eq = E == V0
    out[eq] = 1.0 / (1.0 + mass_kg * width_m**2 * V0 / (2 * HBAR**2))
    return out


def abrupt_prefactor(energy_J: np.ndarray | float, height_J: float, barrier_mass_kg: float,
                     lead_mass_kg: float | None = None) -> np.ndarray:
    """Thick-barrier prefactor ``16 k~^2 q~^2 / (k~^2+q~^2)^2`` with ``T ~ prefactor * exp(-2 q a)``.

    This is the interface factor that plain WKB omits for abrupt barriers.
    Valid for ``0 < E < V0``.
    """
    E = np.atleast_1d(np.asarray(energy_J, dtype=float))
    m_l = barrier_mass_kg if lead_mass_kg is None else lead_mass_kg
    km2 = 2.0 * E / (m_l * HBAR**2)
    qm2 = 2.0 * (height_J - E) / (barrier_mass_kg * HBAR**2)
    return 16.0 * km2 * qm2 / (km2 + qm2) ** 2


__all__ = ["RectangularResult", "rectangular_transmission", "textbook_equal_mass", "abrupt_prefactor"]
