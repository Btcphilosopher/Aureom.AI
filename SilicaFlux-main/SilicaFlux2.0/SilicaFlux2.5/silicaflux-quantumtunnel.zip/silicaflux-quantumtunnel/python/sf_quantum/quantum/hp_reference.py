r"""High-precision (mpmath) reference solutions.

These are *independent* implementations used only for validation:

* :func:`rectangular_hp` -- solves the 4x4 interface-matching linear system for
  a rectangular barrier directly (no closed-form transmission formula), at
  arbitrary precision.
* :func:`layered_transfer_hp` -- exact solution of the effective-mass
  Schroedinger equation for any :class:`~sf_quantum.quantum.barriers.PotentialProfile`
  whose layers are linear in x: Airy functions in sloped layers, hyperbolic
  functions in flat layers, transfer matrices in the continuous variables
  :math:`(\psi, \psi'/m)` evaluated with mpmath at ``dps`` digits. In double
  precision this approach overflows for thick barriers; in mpmath it does not,
  which is exactly why it is the reference and not the production solver.

The production solvers (:mod:`.scattering`, :mod:`.schrodinger`) never call
this module.
"""

from __future__ import annotations

from dataclasses import dataclass

try:  # optional dependency
    import mpmath as mp
except ImportError:  # pragma: no cover - exercised only without mpmath
    mp = None

from .barriers import PotentialProfile
from .constants import HBAR, M_E, Q_E


class MissingDependencyError(RuntimeError):
    pass


def _require_mp():
    if mp is None:
        raise MissingDependencyError("mpmath is required for the high-precision reference (pip install mpmath)")


@dataclass(frozen=True)
class HPResult:
    transmission: float
    reflection: float
    log_transmission: float
    dps: int
    transmission_str: str


def _hbar():
    return mp.mpf(float(HBAR))


def rectangular_hp(energy_J: float, height_J: float, width_m: float, barrier_mass_kg: float,
                   lead_mass_kg: float | None = None, dps: int = 50) -> HPResult:
    """Rectangular barrier by direct solution of the boundary-matching system."""
    _require_mp()
    with mp.workdps(dps):
        hb = _hbar()
        E = mp.mpf(float(energy_J))
        V0 = mp.mpf(float(height_J))
        a = mp.mpf(float(width_m))
        mb = mp.mpf(float(barrier_mass_kg))
        ml = mb if lead_mass_kg is None else mp.mpf(float(lead_mass_kg))
        if E <= 0:
            raise ValueError("energy must be > 0")
        k = mp.sqrt(2 * ml * E) / hb
        q = mp.sqrt(mp.mpc(2 * mb * (V0 - E))) / hb  # complex above barrier
        ik = mp.mpc(0, 1) * k
        eika = mp.exp(ik * a)
        if q == 0:
            # E == V0: barrier solutions are 1 and x.  psi_B = A + B x
            Mx = mp.matrix([
                [1, -1, 0, 0],
                [-ik / ml, 0, -1 / mb, 0],
                [0, 1, a, -eika],
                [0, 0, 1 / mb, -ik / ml * eika],
            ])
        else:
            # unknowns: r, A, B, t ; psi_L = e^{ikx} + r e^{-ikx},
            # psi_B = A e^{q(x-a)} + B e^{-qx}  (scaled basis: every entry has |.| <= 1),
            # psi_R = t e^{ikx}
            e = mp.exp(-q * a)
            Mx = mp.matrix([
                [1, -e, -1, 0],
                [-ik / ml, -q / mb * e, q / mb, 0],
                [0, 1, e, -eika],
                [0, q / mb, -q / mb * e, -ik / ml * eika],
            ])
        rhs = mp.matrix([-1, -ik / ml, 0, 0])
        sol = mp.lu_solve(Mx, rhs)
        r, t = sol[0], sol[3]
        T = abs(t) ** 2
        R = abs(r) ** 2
        return HPResult(float(T), float(R), float(mp.log(T)), dps, mp.nstr(T, 30))


def _layer_matrix(layer, E, hb):
    """Transfer matrix of (psi, psi'/m) across one linear layer (mpmath)."""
    d = mp.mpf(float(layer.thickness_m))
    m = mp.mpf(float(layer.mass_kg))
    v1 = mp.mpf(float(layer.v_start_J))
    v2 = mp.mpf(float(layer.v_end_J))
    if abs(v2 - v1) <= mp.mpf("1e-40"):
        q = mp.sqrt(mp.mpc(2 * m * (v1 - E))) / hb
        if q == 0:
            ch, sh_over_q, q_sh = mp.mpf(1), d, mp.mpf(0)
        else:
            ch = mp.cosh(q * d)
            sh_over_q = mp.sinh(q * d) / q
            q_sh = q * mp.sinh(q * d)
        return mp.matrix([[ch, m * sh_over_q], [q_sh / m, ch]])
    s = (v2 - v1) / d
    a3 = 2 * m * s / hb**2
    alpha = mp.sign(a3) * mp.cbrt(abs(a3))  # REAL cube root carrying the sign of s (mp.cbrt(-x) is complex)
    z1 = alpha * ((v1 - E) / s)
    z2 = alpha * (d + (v1 - E) / s)

    def phi(z):
        ai, aip = mp.airyai(z), mp.airyai(z, derivative=1)
        bi, bip = mp.airybi(z), mp.airybi(z, derivative=1)
        return mp.matrix([[ai, bi], [alpha * aip / m, alpha * bip / m]])

    p1, p2 = phi(z1), phi(z2)
    # Inverse from the exact Wronskian Ai Bi' - Ai' Bi = 1/pi (det = alpha/(m pi)).
    # A numerical LU inverse fails here: Ai and Bi differ by hundreds of orders of
    # magnitude for thick, gently sloped layers and mpmath's pivot tolerance is
    # relative to the matrix norm.
    inv_det = m * mp.pi / alpha
    p1_inv = mp.matrix([[p1[1, 1] * inv_det, -p1[0, 1] * inv_det],
                        [-p1[1, 0] * inv_det, p1[0, 0] * inv_det]])
    return p2 * p1_inv


def layered_transfer_hp(profile: PotentialProfile, energy_J: float, dps: int = 60) -> HPResult:
    """Exact transmission of a piecewise-linear layered profile (Airy transfer matrices)."""
    _require_mp()
    with mp.workdps(dps):
        hb = _hbar()
        E = mp.mpf(float(energy_J))
        vl = mp.mpf(float(profile.left.potential_J))
        vr = mp.mpf(float(profile.right.potential_J))
        ml = mp.mpf(float(profile.left.mass_kg))
        mr = mp.mpf(float(profile.right.mass_kg))
        if E <= vl:
            raise ValueError("energy must exceed the left-lead band edge")
        kl = mp.sqrt(2 * ml * (E - vl)) / hb
        kr = mp.sqrt(mp.mpc(2 * mr * (E - vr))) / hb
        i = mp.mpc(0, 1)
        WL = mp.matrix([[1, 1], [i * kl / ml, -i * kl / ml]])
        WR = mp.matrix([[1, 1], [i * kr / mr, -i * kr / mr]])
        M = mp.eye(2)
        for layer in profile.layers:
            M = _layer_matrix(layer, E, hb) * M
        N = mp.inverse(WR) * M * WL
        r = -N[1, 0] / N[1, 1]
        # t = N00 + N01 r suffers catastrophic cancellation for thick barriers.
        # Every layer matrix has unit determinant (constant Wronskian of
        # psi and psi'/m), so det N = det(WL)/det(WR) = (kl/ml)/(kr/mr) exactly
        # and t = det N / N11 without cancellation.
        t = ((kl / ml) / (kr / mr)) / N[1, 1]
        vel_r = mp.re(kr / mr)
        vel_l = kl / ml
        T = abs(t) ** 2 * vel_r / vel_l if vel_r > 0 else mp.mpf(0)
        R = abs(r) ** 2
        logT = mp.log(T) if T > 0 else mp.mpf("-inf")
        return HPResult(float(T), float(R), float(logT), dps, mp.nstr(T, 30))


def rectangular_hp_eV(energy_eV: float, height_eV: float, width_nm: float, m_barrier: float,
                      m_lead: float | None = None, dps: int = 50) -> HPResult:
    """Human-unit wrapper around :func:`rectangular_hp`."""
    return rectangular_hp(energy_eV * Q_E, height_eV * Q_E, width_nm * 1e-9, m_barrier * M_E,
                          None if m_lead is None else m_lead * M_E, dps)


__all__ = ["HPResult", "MissingDependencyError", "rectangular_hp", "rectangular_hp_eV", "layered_transfer_hp"]
