"""sf-quantum command-line interface.

Every documented command executes, or exits with a clear
unavailable-dependency message (exit code 3) -- it never pretends to succeed.

    sf-quantum barrier rectangular|trapezoidal ...
    sf-quantum solve exact|wkb|scattering|fd ...
    sf-quantum sweep energy|thickness|field ...
    sf-quantum compare models ...
    sf-quantum dielectric compare ...
    sf-quantum generate rtl-vectors
    sf-quantum verify rtl [--config NAME --simulator iverilog|verilator]
    sf-quantum synth
    sf-quantum validate
    sf-quantum benchmark
    sf-quantum report [--experiments A B ...]
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys

import numpy as np

EXIT_UNAVAILABLE = 3


def _profile(a):
    from .quantum import barriers as B
    if a.shape == "rectangular":
        return B.rectangular(a.height, a.width, a.mass, lead_mass=a.lead_mass)
    if a.shape == "trapezoidal":
        if a.field is not None:
            return B.biased_rectangular(a.height, a.width, a.mass, field_V_per_nm=a.field, lead_mass=a.lead_mass)
        end = a.height if a.end_height is None else a.end_height
        return B.trapezoidal(a.height, end, a.width, a.mass, lead_mass=a.lead_mass)
    if a.shape == "triangular":
        return B.triangular(a.height, a.field or 1.0, a.mass, lead_mass=a.lead_mass)
    raise SystemExit(f"unknown shape {a.shape}")


def _barrier_args(p, shape_default="rectangular"):
    p.add_argument("--shape", default=shape_default, choices=["rectangular", "trapezoidal", "triangular"])
    p.add_argument("--height", type=float, default=3.1, help="barrier potential energy, eV")
    p.add_argument("--end-height", type=float, default=None, help="trapezoid end potential, eV")
    p.add_argument("--width", type=float, default=1.5, help="nm")
    p.add_argument("--mass", type=float, default=0.5, help="barrier effective mass, m*/m0")
    p.add_argument("--lead-mass", type=float, default=None, help="lead effective mass, m*/m0")
    p.add_argument("--field", type=float, default=None, help="applied field across the barrier, V/nm")
    p.add_argument("--json", action="store_true", help="machine-readable output")


def _emit(obj, as_json):
    if as_json:
        print(json.dumps(obj, indent=2, default=str))
    else:
        for k, v in obj.items():
            print(f"{k:>28}: {v}")


def cmd_barrier(a):
    a.shape = a.kind
    p = _profile(a)
    if a.json:
        print(json.dumps(p.to_dict(), indent=2))
    else:
        print(p.describe())
        print(f"energy reference: {p.energy_reference}; width {p.width_m * 1e9:.4g} nm; Vmax {p.v_max_J / 1.602176634e-19:.4g} eV")


def cmd_solve(a):
    from .quantum import scattering as S, schrodinger as FD, wkb as W
    from .quantum.constants import Q_E
    from .quantum.rectangular import rectangular_transmission
    p = _profile(a)
    E = a.energy * Q_E
    if a.method == "exact":
        if a.shape != "rectangular" or a.field:
            raise SystemExit("exact solution is only defined for an unbiased rectangular barrier (Level 1)")
        r = rectangular_transmission(E, a.height * Q_E, a.width * 1e-9, a.mass * 9.1093837139e-31,
                                     None if a.lead_mass is None else a.lead_mass * 9.1093837139e-31)
        out = {"method": "exact (Level 1)", "T": r.transmission[0], "R": r.reflection[0], "ln_T": r.log_transmission[0],
               "regime": r.regime[0]}
    elif a.method == "wkb":
        r = W.wkb(p, E)
        out = {"method": "WKB (Level 2)", "action_S": r.action, "ln_T": r.log_transmission, "T": r.transmission,
               "turning_points_nm": [tuple(round(x * 1e9, 6) for x in tp) for tp in r.turning_points_m],
               "flags": [f.value for f in r.flags], "reliable": r.reliable, "recommendation": r.recommendation}
    elif a.method == "scattering":
        r = S.transmission(p, E, max_slice_m=a.slice * 1e-9)
        out = {"method": "S-matrix (Level 3)", "T": r.transmission[0], "R": r.reflection[0], "ln_T": r.log_transmission[0],
               "conservation_error": r.conservation_error[0], "slices": r.n_slices}
    else:
        r = FD.solve(p, E, grid_m=a.slice * 1e-9)
        out = {"method": "finite-difference QTBM (Level 3)", "T": r.transmission[0], "R": r.reflection[0],
               "ln_T": r.log_transmission[0], "conservation_error": r.conservation_error[0], "nodes": r.n_nodes}
    out["energy_eV"] = a.energy
    _emit(out, a.json)


def cmd_sweep(a):
    from .analysis import sweeps
    from .devices.materials import DIELECTRICS
    from .quantum.constants import Q_E
    if a.kind == "energy":
        p = _profile(a)
        if a.adaptive:
            E, T = sweeps.adaptive_energy_grid(p, a.emin * Q_E, a.emax * Q_E, n_initial=a.points)
            import pandas as pd
            df = pd.DataFrame({"energy_eV": E / Q_E, "T_scattering": T})
        else:
            df = sweeps.energy_sweep(p, np.linspace(a.emin, a.emax, a.points) * Q_E)
    elif a.kind == "thickness":
        df = sweeps.thickness_sweep(DIELECTRICS[a.material], np.linspace(a.tmin, a.tmax, a.points))
    else:
        df = sweeps.field_sweep(DIELECTRICS[a.material], a.thickness, np.linspace(a.fmin, a.fmax, a.points))
    if a.out:
        df.to_csv(a.out, index=False)
        print(f"wrote {len(df)} rows to {a.out}")
    else:
        print(df.to_string(max_rows=40))


def cmd_compare(a):
    from .analysis import sweeps
    from .quantum.constants import Q_E
    p = _profile(a)
    df = sweeps.energy_sweep(p, np.array(a.energies) * Q_E)
    cols = [c for c in df.columns if c.startswith("logT") or c == "energy_eV"]
    print(df[cols].to_string(index=False))


def cmd_dielectric(a):
    from .devices import materials as M
    from .devices.dielectric_stack import matched_eot_stack, single_layer
    from .quantum import scattering as S
    from .quantum.constants import Q_E
    ref = single_layer(M.SIO2, a.eot)
    hk = matched_eot_stack(a.eot, M.HFO2, M.SIO2, a.il)
    rows = []
    for name, st in (("SiO2", ref), ("SiO2/HfO2", hk)):
        part = st.partition(a.voltage)
        lt = S.transmission(st.simplified_profile(a.voltage), a.energy * Q_E).log_transmission[0]
        rows.append({"stack": name, "layers": st.describe(), "physical_nm": round(st.physical_thickness_nm, 4),
                     "EOT_nm": round(st.eot_nm, 4), "C_uF_cm2": round(st.capacitance_F_per_m2 * 100, 4),
                     "fields_MV_cm": [round(f, 3) for f in part["fields_MV_per_cm"]], "ln_T": round(float(lt), 4)})
    print(json.dumps({"voltage_across_stack_V": a.voltage, "energy_eV": a.energy, "stacks": rows,
                      "provenance": {"HfO2 mass": "assumed", "band offsets": "literature"},
                      "note": "simplified voltage-drop model; 1D; not a leakage prediction"}, indent=2))


def cmd_generate(a):
    from .reference.tunneling_golden import generate_all
    print(json.dumps(generate_all(n_random=a.n_random, seed=a.seed), indent=2))


def _need_sim():
    if not (shutil.which("iverilog") or shutil.which("verilator")):
        print("UNAVAILABLE: no HDL simulator (iverilog or verilator) on PATH -- RTL verification gate not run.",
              file=sys.stderr)
        raise SystemExit(EXIT_UNAVAILABLE)


def cmd_verify(a):
    _need_sim()
    from .reference import rtl_runner
    if a.config:
        r = rtl_runner.run_config(a.config, a.simulator, a.seed)
        print(json.dumps({k: r[k] for k in ("config", "simulator", "status", "tb_stats")}, indent=2, default=str))
        if r["status"] == "simulator-unavailable":
            raise SystemExit(EXIT_UNAVAILABLE)
        raise SystemExit(0 if r["status"] == "pass" else 1)
    s = rtl_runner.run_all()
    print(open(rtl_runner.PROJECT_ROOT / "reports" / "rtl" / "RTL_VERIFICATION.md").read())
    raise SystemExit(0 if s["all_pass"] else 1)


def cmd_synth(a):
    from .reference import synthesis
    if not shutil.which("yosys"):
        print("UNAVAILABLE: yosys not on PATH -- synthesis gate not run.", file=sys.stderr)
        raise SystemExit(EXIT_UNAVAILABLE)
    synthesis.run_all(quick=a.quick)
    print(open(synthesis.PROJECT_ROOT / "reports" / "synthesis" / "SYNTHESIS.md").read())


def cmd_validate(a):
    from .analysis.validation import run_all, write_report
    from .provenance import PROJECT_ROOT
    res = run_all()
    s = write_report(res, PROJECT_ROOT / "reports" / "validation")
    for r in res:
        print(f"[{'PASS' if r.passed else 'FAIL'}] {r.number:2d} {r.name}: {r.value if isinstance(r.value, str) else f'{r.value:.3g}'}")
    print(f"{s['passed']}/{s['total']} checks passed")
    raise SystemExit(0 if s["passed"] == s["total"] else 1)


def cmd_benchmark(a):
    from .analysis.benchmarks import run
    from .provenance import PROJECT_ROOT
    run()
    print(open(PROJECT_ROOT / "reports" / "benchmarks" / "BENCHMARKS.md").read())


def cmd_report(a):
    from .experiments.run import run as run_exp
    from .provenance import PROJECT_ROOT
    from .viz.dashboard import build, build_device3d
    res = run_exp(tuple(a.experiments))
    for k, v in res.items():
        print(f"experiment {k}: {len(v['files'])} files, figures {v['figures']}")
    if set("ABCDE") <= set(a.experiments) or a.dashboard:
        print("dashboard:", build())
        d3 = build_device3d()
        print("3D view:", d3 or "skipped (dashboard/vendor/device3d.bundle.js missing)")
    from .reports import write_index
    print("index:", write_index())


def main(argv=None):
    ap = argparse.ArgumentParser(prog="sf-quantum", description="SilicaFlux QuantumTunnel")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("barrier", help="build and describe a barrier profile")
    p.add_argument("kind", choices=["rectangular", "trapezoidal", "triangular"])
    _barrier_args(p)
    p.set_defaults(func=cmd_barrier)

    p = sub.add_parser("solve", help="transmission by one solver level")
    p.add_argument("method", choices=["exact", "wkb", "scattering", "fd"])
    _barrier_args(p)
    p.add_argument("--energy", type=float, default=1.0, help="electron energy, eV (lead band edge = 0)")
    p.add_argument("--slice", type=float, default=0.005, help="numerical grid / slice size, nm")
    p.set_defaults(func=cmd_solve)

    p = sub.add_parser("sweep", help="energy / thickness / field sweeps")
    p.add_argument("kind", choices=["energy", "thickness", "field"])
    _barrier_args(p)
    p.add_argument("--emin", type=float, default=0.01)
    p.add_argument("--emax", type=float, default=5.0)
    p.add_argument("--points", type=int, default=200)
    p.add_argument("--adaptive", action="store_true")
    p.add_argument("--material", default="SiO2", choices=["SiO2", "HfO2"])
    p.add_argument("--tmin", type=float, default=0.8)
    p.add_argument("--tmax", type=float, default=4.0)
    p.add_argument("--thickness", type=float, default=3.0)
    p.add_argument("--fmin", type=float, default=0.5, help="MV/cm")
    p.add_argument("--fmax", type=float, default=20.0, help="MV/cm")
    p.add_argument("--out", default=None, help="CSV output path")
    p.set_defaults(func=cmd_sweep)

    p = sub.add_parser("compare", help="compare solver levels")
    p.add_argument("what", choices=["models"])
    _barrier_args(p)
    p.add_argument("--energies", type=float, nargs="+", default=[0.05, 0.5, 1.0, 2.0, 3.0, 4.0])
    p.set_defaults(func=cmd_compare)

    p = sub.add_parser("dielectric", help="SiO2 vs high-k at matched EOT")
    p.add_argument("what", choices=["compare"])
    p.add_argument("--eot", type=float, default=1.0)
    p.add_argument("--il", type=float, default=0.5)
    p.add_argument("--voltage", type=float, default=1.0)
    p.add_argument("--energy", type=float, default=0.05)
    p.set_defaults(func=cmd_dielectric)

    p = sub.add_parser("generate", help="golden vectors and generated RTL tables")
    p.add_argument("what", choices=["rtl-vectors"])
    p.add_argument("--n-random", type=int, default=2000)
    p.add_argument("--seed", type=int, default=20261115)
    p.set_defaults(func=cmd_generate)

    p = sub.add_parser("verify", help="RTL simulation vs golden reference")
    p.add_argument("what", choices=["rtl"])
    p.add_argument("--config", default=None)
    p.add_argument("--simulator", default="iverilog", choices=["iverilog", "verilator"])
    p.add_argument("--seed", type=int, default=20261115)
    p.set_defaults(func=cmd_verify)

    p = sub.add_parser("synth", help="synthesis / place-and-route reports")
    p.add_argument("--quick", action="store_true", help="default configuration only")
    p.set_defaults(func=cmd_synth)

    p = sub.add_parser("validate", help="18-check numerical validation suite")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("benchmark", help="performance benchmarks")
    p.set_defaults(func=cmd_benchmark)

    p = sub.add_parser("report", help="run experiments, build figures and dashboard")
    p.add_argument("--experiments", nargs="+", default=["A", "B", "C", "D", "E"], choices=list("ABCDE"))
    p.add_argument("--dashboard", action="store_true")
    p.set_defaults(func=cmd_report)

    a = ap.parse_args(argv)
    a.func(a)


if __name__ == "__main__":  # pragma: no cover
    main()
