"""Optional FastAPI service (``uvicorn sf_quantum.api:app``).

Thin HTTP layer over the solvers and the TransistorLab contract. FastAPI is an
optional dependency (``pip install .[api]``); importing this module without it
raises a clear error.
"""

from __future__ import annotations

try:
    from fastapi import FastAPI, HTTPException
except ImportError as exc:  # pragma: no cover
    raise ImportError("FastAPI is optional: pip install 'sf-quantum[api]'") from exc

from pydantic import BaseModel, Field

from . import __version__
from .integration.transistorlab import TunnellingRequest, TunnellingResponse, analyse
from .quantum import barriers as B
from .quantum import scattering, wkb
from .quantum.constants import M_E, Q_E
from .quantum.rectangular import rectangular_transmission

app = FastAPI(title="SilicaFlux QuantumTunnel", version=__version__)


def _clean(obj):
    """JSON has no NaN/inf: undefined results (e.g. WKB above the barrier) become null."""
    import math
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    return obj


class BarrierQuery(BaseModel):
    height_eV: float = 3.1
    width_nm: float = Field(1.5, gt=0)
    mass_rel: float = Field(0.5, gt=0)
    energy_eV: float = Field(1.0, gt=0)
    field_V_per_nm: float | None = None


@app.get("/health")
def health():
    return {"status": "ok", "version": __version__}


@app.post("/solve/{method}")
def solve(method: str, q: BarrierQuery):
    prof = (B.biased_rectangular(q.height_eV, q.width_nm, q.mass_rel, field_V_per_nm=q.field_V_per_nm)
            if q.field_V_per_nm else B.rectangular(q.height_eV, q.width_nm, q.mass_rel))
    E = q.energy_eV * Q_E
    try:
        if method == "exact":
            if q.field_V_per_nm:
                raise HTTPException(400, "exact solution only for unbiased rectangular barriers")
            r = rectangular_transmission(E, q.height_eV * Q_E, q.width_nm * 1e-9, q.mass_rel * M_E)
            return {"method": "exact", "T": float(r.transmission[0]), "ln_T": float(r.log_transmission[0])}
        if method == "wkb":
            r = wkb.wkb(prof, E)
            out = _clean({"method": "wkb", **{k: v for k, v in r.as_dict().items() if k != "diagnostics"}})
            if out["transmission"] is None:
                out["note"] = "transmission undefined in the WKB tunnelling model for this input (see flags)"
            return out
        if method == "scattering":
            r = scattering.transmission(prof, E)
            return {"method": "scattering", "T": float(r.transmission[0]), "R": float(r.reflection[0]),
                    "ln_T": float(r.log_transmission[0]), "conservation_error": float(r.conservation_error[0])}
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    raise HTTPException(404, f"unknown method {method}")


@app.post("/transistorlab/analyse", response_model=TunnellingResponse)
def transistorlab(req: TunnellingRequest):
    try:
        return analyse(req)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
