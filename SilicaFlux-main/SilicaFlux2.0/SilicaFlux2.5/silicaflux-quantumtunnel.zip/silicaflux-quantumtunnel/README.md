# SilicaFlux QuantumTunnel

**Quantum-tunnelling physics engine and SystemVerilog WKB accelerator** — Aureom.AI | SilicaFlux Semiconductor Systems

```
DEVICE PARAMETERS -> BARRIER POTENTIAL MODEL -> PYTHON QUANTUM SOLVER (L1 exact / L2 WKB / L3 S-matrix + FD)
  -> TRANSMISSION / CURRENT ANALYSIS -> FIXED-POINT HARDWARE MODEL -> SYSTEMVERILOG RTL -> RTL VERIFICATION
  -> SILICAFLUX ENGINEERING DASHBOARD
```

QuantumTunnel computes quantum transmission through one-dimensional semiconductor and gate-dielectric
potential barriers. It has three explicitly separated solver levels, research models for gate-dielectric
tunnelling, a bit-accurate fixed-point specification, and a synthesizable, pipelined SystemVerilog
accelerator for the WKB model. Every number in the reports is produced by code in this
directory and labelled with its origin. Nothing is calibrated to a foundry process or to measured
silicon.

## What is in the box

| Capability | Where | Status (evidence) |
|---|---|---|
| L1 exact rectangular barrier (log-domain, continuous through E = V0, unequal masses) | `python/sf_quantum/quantum/rectangular.py` | matches an independent 60-digit boundary-matching solve to ~1e-14, down to T ~ e^-640 |
| L2 WKB with turning points and 7 validity diagnostics | `quantum/wkb.py` | exact action for piecewise-linear profiles; above-barrier is **flagged**, never returned as T = 1 |
| L3a stable scattering-matrix (Redheffer) solver + wavefunction reconstruction | `quantum/scattering.py` | 50 nm barrier exact to 1e-12; current conserved to 1e-15; naive transfer matrix shown to fail |
| L3b independent finite-difference open-boundary (QTBM) solver | `quantum/schrodinger.py` | second-order convergence to the 60-digit Airy reference |
| Barrier geometry: rectangular, trapezoidal, triangular, multi-barrier, smooth, imported (energy reference mandatory) | `quantum/barriers.py` | |
| Materials with provenance, dielectric stacks, EOT, field partitioning | `devices/` | HfO2 tunnelling mass is explicitly **assumed** |
| Analytical MOS electrostatics, DEVSIM import, simplified voltage-drop model (labelled) | `devices/electrostatics.py` | |
| Fowler-Nordheim (regime-enforced), Landauer 1D, Tsu-Esaki 3D-electrode current | `models/` | Tsu-Esaki reproduces analytical FN, including the next-order correction |
| Sweeps, adaptive energy grids, Monte Carlo sensitivity, 18-check validation | `analysis/` | **18/18 pass** (`reports/validation/VALIDATION.md`) |
| Golden reference + bit-accurate fixed-point model + error budget | `reference/` | 3 core vector sets (3,068 vectors) + 53 integrator profiles (16,095 samples) |
| WKB accelerator `sf_quantum_tunnel_core` (II = 1, ready/valid, backpressure) | `rtl/quantum/` | bit-exact on Icarus **and** Verilator, identical traces; all errors inside the derived budget |
| Sampled-profile integrator `sf_qt_integrator` | `rtl/quantum/sf_qt_integrator.sv` | bit-exact, one sample per cycle |
| SoC Simple Bus register adapter | `rtl/integration/sf_qt_ssb_regs.sv` | bus-level test passes |
| Synthesis: Yosys generic, ECP5 + nextpnr post-route, iCE40 fit, NanGate45 estimate | `reports/synthesis/SYNTHESIS.md` | real tool output only |
| Experiments A-E (JSON + HDF5 + CSV + figures) | `data/experiments/`, `reports/figures/` | |
| Silicon-physics dashboard (15 panels, solver data only) + optional Three.js 3D view | `dashboard/index.html`, `dashboard/device3d.html` | |
| CLI `sf-quantum`, FastAPI service, TransistorLab contract | `cli.py`, `api.py`, `integration/` | |

## Quick start

```bash
python3 -m pip install -e ".[dev,hp,api]"      # or just: export PYTHONPATH=$PWD/python
make quantum-test        # Python tests (physics, numerical, devices, integration)
make quantum-validate    # 18-check scientific validation report
make quantum-vectors     # golden vectors + generated RTL constants / ROM
make quantum-rtl-lint    # Verilator -Wall (6 configurations / tops) + Icarus elaboration
make quantum-rtl-test    # SV testbenches on Icarus + Verilator, bit-exact comparison
make quantum-rtl-synth   # Yosys / nextpnr-ecp5 / NanGate45 estimate
make quantum-benchmark
make quantum-report      # experiments A-E, figures, dashboard, report index
```

Tools used here: Python 3.13, Icarus Verilog 12, Verilator 5.020, Yosys 0.33, nextpnr-ecp5 0.6.
A missing tool is reported as a **MISSING GATE** (`reports/gates.txt`), never as a pass.

```bash
sf-quantum solve exact --height 3.1 --width 1.5 --mass 0.5 --energy 1.0
sf-quantum solve wkb   --shape trapezoidal --field 0.5 --energy 0.5     # flags + recommendation
sf-quantum sweep energy --shape rectangular --adaptive --out spectrum.csv
sf-quantum dielectric compare --eot 1.0 --il 0.5 --voltage 1.0
sf-quantum verify rtl
```

## Headline results

All values are copied from the generated reports. Regenerate with the Make targets above.

* **Validation:** 18/18 checks pass. For example, exact vs 50-digit reference ≤ 3e-15; S-matrix
  vs 60-digit Airy reference ≤ 5e-12; current conservation 2e-15; observed convergence order 1.98.
* **Accelerator accuracy:** RTL SIMULATION, 1,936 valid vectors, bit-exact with the model. Max |Δ ln T| vs
  double-precision WKB is 3.0e-4 (mean 2.1e-5). Max relative T error is 8.7e-5 where T > 1e-6. Every vector
  is within its own error budget (worst ratio 0.975).
* **Accelerator performance:** II = 1 at a latency of 38 cycles by default (18 with 5 sqrt bits/stage).
  The post-route ECP5 Fmax is in `reports/synthesis/SYNTHESIS.md` (≈58 MHz for the default config,
  i.e. ≈58 M evaluations/s). That is a pre-board, no-IO-constraint place-and-route figure, not an FPGA measurement.
* **Physics findings (experiments):**
  * WKB misses the abrupt-interface prefactor of a rectangular barrier: Δ ln T from −1.4 to +3.0 below the barrier.
  * Fowler-Nordheim oscillations appear above the FN onset at 10.2 MV/cm for 3 nm SiO2.
  * At matched EOT (1.0 nm) the SiO2/HfO2 stack transmits 10^-2.4 of SiO2 at 1 V for nominal parameters,
    but the Monte Carlo 5–95 % range is 10^-6.6 to 10^-2.4. The assumed HfO2 mass dominates.

## Read next

`docs/AUDIT.md` (repository audit) · `docs/ARCHITECTURE.md` · `docs/PHYSICS_MODELS.md` ·
`docs/FIXED_POINT.md` · `docs/RTL.md` · `docs/VERIFICATION.md` (incl. the bug log) · `docs/EXPERIMENTS.md` ·
`docs/TOOLING.md` · `docs/LIMITATIONS.md` · `docs/ROADMAP.md` · `docs/PHASE_STATUS.md` · `reports/INDEX.md`

## Delivery note

Built against `github.com/Btcphilosopher/SilicaFlux @ 1244025` (audited read-only). Nothing was committed
or pushed. To adopt, add this directory on a branch such as `feature/quantumtunnel`.
