// =============================================================================
// tb_sf_qt_integrator.sv -- sampled-profile WKB integrator regression
//
// Streams every sample of vectors/sf_qt_integrator_v1 (profiles delimited by
// first/last), checks each per-profile response bit-exactly against the
// Python model, in order, under (A) full rate and (B) random input gaps and
// output backpressure. Phase A also checks one sample per cycle (II = 1).
// Responses of phase A go to +outfile for the Python statistics.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

`include "n_vectors.svh"

`ifndef SF_QT_INT_DIR
`define SF_QT_INT_DIR "vectors/sf_qt_integrator_v1"
`endif

module tb_sf_qt_integrator;
    localparam int W  = 32;
    localparam int NS = `SF_QT_N_SAMPLES;
    localparam int NP = `SF_QT_N_PROFILES;
    localparam int SW = 2 + 8 + 5 * W;
    localparam int EW = 8 + 2 * W;

    logic clk = 1'b0, rst_n = 1'b0;
    always #5 clk = ~clk;

    logic          sv, sr, sf, sl, rv, rr;
    logic [7:0]    stag, rtag;
    logic [W-1:0]  se, sdx, svv, sm, sw, lg, tt;
    logic [3:0]    err;
    logic [2:0]    warn;

    sf_qt_integrator dut (.clk_i(clk), .rst_ni(rst_n), .smp_valid_i(sv), .smp_ready_o(sr), .smp_first_i(sf),
                          .smp_last_i(sl), .smp_tag_i(stag), .energy_i(se), .dx_i(sdx), .smp_v_i(svv), .smp_m_i(sm),
                          .smp_w_i(sw), .rsp_valid_o(rv), .rsp_ready_i(rr), .rsp_tag_o(rtag), .log_transmission_o(lg),
                          .transmission_o(tt), .error_o(err), .warn_o(warn));

    logic [SW-1:0] smp [0:NS-1];
    logic [EW-1:0] expv [0:NP-1];
    integer cycle = 0, send = 0, recv = 0, mism = 0, proto = 0, first_fire = -1, last_fire = -1;
    integer p_valid = 256, p_ready = 256, fd;
    logic   driving = 1'b0, logging = 1'b0;
    logic [31:0] rd = 32'h1234_5678, rm = 32'h9E37_79B9;
    string  outfile;

    function automatic logic [31:0] xs(input logic [31:0] x);
        logic [31:0] y; y = x ^ (x << 13); y = y ^ (y >> 17); return y ^ (y << 5);
    endfunction

    always @(posedge clk) cycle <= cycle + 1;

    integer nxt;
    always @(posedge clk) begin
        if (!rst_n) sv <= 1'b0;
        else if (driving) begin
            nxt = send;
            if (sv && sr) begin
                if (first_fire < 0) first_fire = cycle;
                last_fire = cycle;
                nxt = send + 1;
            end
            send <= nxt;
            if (!sv || sr) begin
                rd = xs(rd);
                if (nxt < NS && integer'(rd[7:0]) < p_valid) begin
                    sv <= 1'b1;
                    {sf, sl, stag, se, sdx, svv, sm, sw} <= smp[nxt];
                end else sv <= 1'b0;
            end
        end else sv <= 1'b0;
    end

    logic [EW-1:0] e;
    logic          prev_stall = 1'b0;
    logic [8+2*W+7-1:0] prev_data;
    always @(posedge clk) begin
        if (!rst_n) begin rr <= 1'b0; prev_stall <= 1'b0; end
        else begin
            if (prev_stall && !(rv && {rtag, lg, tt, err, warn} == prev_data)) proto = proto + 1;
            if (rv && rr) begin
                if (recv >= NP) proto = proto + 1;
                else begin
                    e = expv[recv];
                    if (rtag !== 8'(recv) || lg !== e[2*W-1:W] || tt !== e[W-1:0] || err !== e[2*W+3:2*W] ||
                        warn !== e[2*W+6:2*W+4]) begin
                        mism = mism + 1;
                        if (mism <= 5) $display("MISMATCH profile %0d: log %h/%h t %h/%h err %b/%b warn %b/%b", recv, lg,
                                                e[2*W-1:W], tt, e[W-1:0], err, e[2*W+3:2*W], warn, e[2*W+6:2*W+4]);
                    end
                    if (logging) $fwrite(fd, "%0d %h %h %0d %0d\n", recv, lg, tt, err, warn);
                end
                recv <= recv + 1;
            end
            prev_stall <= rv && !rr;
            prev_data  <= {rtag, lg, tt, err, warn};
            rm = xs(rm);
            rr <= integer'(rm[7:0]) < p_ready;
        end
    end

    task automatic run(input integer pv, input integer pr, input logic lg_on, input logic [31:0] seed);
        @(negedge clk);
        p_valid = pv; p_ready = pr; logging = lg_on; send = 0; recv = 0; first_fire = -1;
        rd = seed; rm = seed ^ 32'h9E37_79B9;
        driving = 1'b1;
        while (recv < NP && cycle < 50_000_000) @(negedge clk);
        driving = 1'b0;
        repeat (60) @(negedge clk);
        if (rv) proto = proto + 1;
    endtask

    integer span;
    initial begin
        if (!$value$plusargs("outfile=%s", outfile)) outfile = "integrator_results.txt";
        $readmemh({`SF_QT_INT_DIR, "/samples.hex"}, smp);
        $readmemh({`SF_QT_INT_DIR, "/expected.hex"}, expv);
        fd = $fopen(outfile, "w");
        repeat (5) @(negedge clk);
        rst_n = 1'b1;
        repeat (2) @(negedge clk);
        run(256, 256, 1'b1, 32'd1);
        span = last_fire - first_fire;
        if (span != NS - 1) begin proto = proto + 1; $display("II: %0d samples issued over %0d cycles", NS, span + 1); end
        run(160, 120, 1'b0, 32'd77);
        $fclose(fd);
        $display("SF_QT_INT_STATS profiles=%0d samples=%0d sample_issue_span=%0d mismatches=%0d protocol_errors=%0d",
                 NP, NS, span, mism, proto);
        if (mism == 0 && proto == 0) $display("SFX_TB_RESULT: PASS");
        else $display("SFX_TB_RESULT: FAIL");
        $finish;
    end
endmodule

`default_nettype wire
