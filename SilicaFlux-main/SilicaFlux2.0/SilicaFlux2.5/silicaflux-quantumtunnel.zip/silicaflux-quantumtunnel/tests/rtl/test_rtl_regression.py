"""pytest wrapper around the SystemVerilog regression (marker: rtl).

If no simulator is installed these tests are *skipped with an explicit reason*
-- the missing verification gate is recorded, never reported as a pass.
"""

import shutil
import subprocess

import pytest

from sf_quantum.provenance import PROJECT_ROOT
from sf_quantum.reference import rtl_runner

pytestmark = pytest.mark.rtl
HAVE_IVERILOG = bool(shutil.which("iverilog") and shutil.which("vvp"))
HAVE_VERILATOR = bool(shutil.which("verilator"))


@pytest.mark.skipif(not HAVE_IVERILOG, reason="MISSING GATE: iverilog not installed")
@pytest.mark.parametrize("config", ["default", "w24", "nopipe"])
def test_core_bit_exact_iverilog(config, tmp_path):
    r = rtl_runner.run_config(config, "iverilog", seed=101, build=tmp_path)
    assert r["status"] == "pass", r["log_tail"]
    c = r["comparison"]
    assert c["bit_exact"] and not c["outside_budget"]
    assert r["tb_stats"]["latency"] == {"default": 38, "w24": 38, "nopipe": 35}[config]
    if config == "w24":
        assert c["counts"]["log_saturated"] > 0


@pytest.mark.skipif(not (HAVE_IVERILOG and HAVE_VERILATOR), reason="MISSING GATE: need both iverilog and verilator")
def test_cross_simulator_identical_traces(tmp_path):
    a = rtl_runner.run_config("default", "iverilog", seed=202, build=tmp_path / "a")
    b = rtl_runner.run_config("default", "verilator", seed=202, build=tmp_path / "b")
    assert a["status"] == b["status"] == "pass"
    assert (PROJECT_ROOT / a["results_file"]).read_bytes() == (PROJECT_ROOT / b["results_file"]).read_bytes() \
        if a["results_file"].startswith("build") else open(a["results_file"], "rb").read() == open(b["results_file"], "rb").read()


@pytest.mark.skipif(not HAVE_IVERILOG, reason="MISSING GATE: iverilog not installed")
def test_ssb_adapter(tmp_path):
    srcs = [str(PROJECT_ROOT / f) for f in rtl_runner.RTL_FILES] + [
        str(PROJECT_ROOT / "rtl/integration/sf_qt_ssb_regs.sv"), str(PROJECT_ROOT / "tests/rtl/tb_sf_qt_ssb_regs.sv")]
    vvp = tmp_path / "ssb.vvp"
    c = subprocess.run(["iverilog", "-g2012", "-s", "tb_sf_qt_ssb_regs", "-o", str(vvp),
                        f"-I{PROJECT_ROOT / 'rtl/quantum/generated'}", f"-I{PROJECT_ROOT / 'vectors/sf_qt_core_v1'}",
                        '-DSF_QT_VEC_DIR="vectors/sf_qt_core_v1"', *srcs], capture_output=True, text=True, cwd=PROJECT_ROOT)
    assert c.returncode == 0, c.stderr
    r = subprocess.run(["vvp", "-n", str(vvp)], capture_output=True, text=True, cwd=PROJECT_ROOT, timeout=600)
    assert "SFX_TB_RESULT: PASS" in r.stdout, r.stdout[-2000:]


@pytest.mark.skipif(not HAVE_VERILATOR, reason="MISSING GATE: verilator not installed")
@pytest.mark.parametrize("params", [[], ["-GPIPE_MUL=0"], ["-GDATA_W=24"], ["-GEXP_MODE=0", "-GSQRT_BPS=5"]])
def test_verilator_lint_clean(params):
    srcs = [str(PROJECT_ROOT / f) for f in rtl_runner.RTL_FILES]
    r = subprocess.run(["verilator", "--lint-only", "-Wall", f"-I{PROJECT_ROOT / 'rtl/quantum/generated'}",
                        "--top-module", "sf_quantum_tunnel_core", *params, *srcs], capture_output=True, text=True)
    assert r.returncode == 0 and not r.stderr.strip(), r.stderr


@pytest.mark.skipif(not HAVE_IVERILOG, reason="MISSING GATE: iverilog not installed")
def test_integrator_bit_exact(tmp_path):
    r = rtl_runner.run_integrator("iverilog", build=tmp_path)
    assert r["status"] == "pass", (r["mismatches"], r["outside_budget"])
    assert r["tb_stats"]["sample_issue_span"] + 1 == r["tb_stats"]["samples"]  # II = 1 sample/cycle


@pytest.mark.skipif(not HAVE_VERILATOR, reason="MISSING GATE: verilator not installed")
def test_integrator_lint_clean():
    srcs = [str(PROJECT_ROOT / f) for f in rtl_runner.INTEGRATOR_FILES]
    r = subprocess.run(["verilator", "--lint-only", "-Wall", f"-I{PROJECT_ROOT / 'rtl/quantum/generated'}",
                        "--top-module", "sf_qt_integrator", *srcs], capture_output=True, text=True)
    assert r.returncode == 0 and not r.stderr.strip(), r.stderr
