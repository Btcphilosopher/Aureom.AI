// =============================================================================
// tb_sf_quantum_tunnel_core.sv -- self-checking regression for the WKB core
//
// Runs on Icarus Verilog 12 (-g2012) and Verilator 5 (--binary --timing).
// Stimulus/expected values come from the Python golden reference
// (vectors/<set>/stimulus.hex, expected.hex). Pseudo-random valid/ready
// patterns use two independent xorshift32 generators seeded by +seed=<n>, so
// both simulators produce identical traces.
//
// Phases
//   A  full-rate streaming (valid and ready always high): bit-exact check,
//      initiation interval, latency == 10 + NS_SQRT + 3*PIPE_MUL (request handshake edge
//      to response handshake edge)
//   B  random request gaps + random response backpressure: bit-exact check,
//      in-order/no-drop/no-duplicate, output stability while stalled
//   C  reset asserted mid-stream: outputs cleared, then a fresh run is exact
//
// Every response of A and B is also written to +outfile=<path> for the
// Python statistics (sf_quantum.reference.rtl_runner).
// Last line: SFX_TB_RESULT: PASS | FAIL   (SilicaFlux-AI convention)
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

`ifndef SF_QT_DATA_W
`define SF_QT_DATA_W 32
`endif
`ifndef SF_QT_FRAC_W
`define SF_QT_FRAC_W 16
`endif
`ifndef SF_QT_EXP_MODE
`define SF_QT_EXP_MODE 1
`endif
`ifndef SF_QT_SQRT_BPS
`define SF_QT_SQRT_BPS 1
`endif
`ifndef SF_QT_PIPE_MUL
`define SF_QT_PIPE_MUL 1
`endif
`ifndef SF_QT_VEC_DIR
`define SF_QT_VEC_DIR "vectors/sf_qt_core_v1"
`endif

`include "n_vectors.svh"

module tb_sf_quantum_tunnel_core;

    localparam int DATA_W  = `SF_QT_DATA_W;
    localparam int FRAC_W  = `SF_QT_FRAC_W;
    localparam int TAG_W   = 8;
    localparam int N       = `SF_QT_N_VECTORS;
    localparam int STIM_W  = TAG_W + 4 * DATA_W;
    localparam int EXP_W   = 8 + 2 * DATA_W;
    localparam int BPS     = `SF_QT_SQRT_BPS;
    // documented latency formula, recomputed independently of the RTL
    localparam int W_P      = 4 + 4 + 2 * FRAC_W;
    localparam int SQ_RAW   = W_P + 2 * 4 + 2;
    localparam int SQ_OUT_W = (SQ_RAW + (SQ_RAW % 2)) / 2;
    localparam int PIPE_MUL = `SF_QT_PIPE_MUL;
    localparam int EXP_LAT  = 10 + (SQ_OUT_W + BPS - 1) / BPS + 3 * PIPE_MUL;

    logic clk = 1'b0;
    logic rst_n = 1'b0;
    always #5 clk = ~clk;

    logic              req_valid, req_ready, rsp_valid, rsp_ready;
    logic [TAG_W-1:0]  req_tag, rsp_tag;
    logic [DATA_W-1:0] barrier, energy, width, mass, log_t, t;
    logic [3:0]        err;
    logic [1:0]        warn;

    sf_quantum_tunnel_core #(
        .DATA_W(DATA_W), .FRAC_W(FRAC_W), .TAG_W(TAG_W),
        .EXP_MODE(`SF_QT_EXP_MODE), .SQRT_BPS(BPS), .PIPE_MUL(PIPE_MUL)
    ) dut (
        .clk_i(clk), .rst_ni(rst_n),
        .req_valid_i(req_valid), .req_ready_o(req_ready), .req_tag_i(req_tag),
        .barrier_i(barrier), .energy_i(energy), .width_i(width), .mass_i(mass),
        .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_tag_o(rsp_tag),
        .log_transmission_o(log_t), .transmission_o(t), .error_o(err), .warn_o(warn)
    );

    logic [STIM_W-1:0] stim [0:N-1];
    logic [EXP_W-1:0]  expv [0:N-1];

    // ------------------------------------------------------------ control
    integer cycle = 0;
    integer n_send = 0;
    integer p_valid = 256;   // probability * 256
    integer p_ready = 256;
    logic   driving = 1'b0;
    logic   logging = 1'b0;
    integer phase_id = 0;
    integer send_idx = 0, recv_idx = 0;
    integer mismatches = 0, proto_errors = 0, x_errors = 0;
    integer lat_min = 1 << 30, lat_max = 0;
    integer first_fire = -1, last_fire = -1;
    integer fire_cycle [0:N-1];
    integer fd;
    logic [31:0] seed;
    logic [31:0] rng_drv, rng_mon;

    function automatic logic [31:0] xorshift32(input logic [31:0] x);
        logic [31:0] y;
        y = x ^ (x << 13);
        y = y ^ (y >> 17);
        y = y ^ (y << 5);
        return y;
    endfunction

    always @(posedge clk) cycle <= cycle + 1;

    // ------------------------------------------------------------ driver
    integer nxt;
    always @(posedge clk) begin
        if (!rst_n) begin
            req_valid <= 1'b0;
        end else if (driving) begin
            nxt = send_idx;
            if (req_valid && req_ready) begin
                fire_cycle[send_idx] = cycle;
                if (first_fire < 0) first_fire = cycle;
                last_fire = cycle;
                nxt = send_idx + 1;
            end
            send_idx <= nxt;
            if (!req_valid || req_ready) begin
                rng_drv = xorshift32(rng_drv);
                if (nxt < n_send && integer'(rng_drv[7:0]) < p_valid) begin
                    req_valid <= 1'b1;
                    {req_tag, barrier, energy, width, mass} <= stim[nxt];
                end else begin
                    req_valid <= 1'b0;
                end
            end
        end else begin
            req_valid <= 1'b0;
        end
    end

    // ------------------------------------------------------------ monitor
    logic              prev_stall = 1'b0;
    logic [TAG_W+2*DATA_W+6-1:0] prev_data;
    logic [EXP_W-1:0]  e;
    integer lat;
    always @(posedge clk) begin
        if (!rst_n) begin
            rsp_ready  <= 1'b0;
            prev_stall <= 1'b0;
        end else begin
            // NB: Icarus 12 mis-evaluates `if ($isunknown(...))` as true for known
            // values (docs/TOOLING.md); the reduction-XOR idiom is portable.
            if (rsp_valid && ((^{rsp_tag, log_t, t, err, warn}) === 1'bx)) x_errors = x_errors + 1;
            if (prev_stall && !(rsp_valid && {rsp_tag, log_t, t, err, warn} == prev_data)) begin
                proto_errors = proto_errors + 1;
                $display("PROTOCOL: response changed or dropped while stalled at cycle %0d", cycle);
            end
            if (rsp_valid && rsp_ready) begin
                if (recv_idx >= n_send) begin
                    proto_errors = proto_errors + 1;
                    $display("PROTOCOL: unexpected extra response at cycle %0d", cycle);
                end else begin
                    e = expv[recv_idx];
                    lat = cycle - fire_cycle[recv_idx];
                    if (lat < lat_min) lat_min = lat;
                    if (lat > lat_max) lat_max = lat;
                    if (rsp_tag !== stim[recv_idx][STIM_W-1 -: TAG_W] || warn !== e[2*DATA_W+5:2*DATA_W+4] ||
                        err !== e[2*DATA_W+3:2*DATA_W] || log_t !== e[2*DATA_W-1:DATA_W] || t !== e[DATA_W-1:0]) begin
                        mismatches = mismatches + 1;
                        if (mismatches <= 10)
                            $display("MISMATCH phase %0d idx %0d: got tag=%h log=%h t=%h err=%b warn=%b exp log=%h t=%h err=%b warn=%b",
                                     phase_id, recv_idx, rsp_tag, log_t, t, err, warn, e[2*DATA_W-1:DATA_W], e[DATA_W-1:0],
                                     e[2*DATA_W+3:2*DATA_W], e[2*DATA_W+5:2*DATA_W+4]);
                    end
                    if (logging)
                        $fwrite(fd, "%0d %0d %0d %h %h %0d %0d %0d\n", phase_id, recv_idx, rsp_tag, log_t, t, err, warn, lat);
                end
                recv_idx <= recv_idx + 1;
            end
            prev_stall <= rsp_valid && !rsp_ready;
            prev_data  <= {rsp_tag, log_t, t, err, warn};
            rng_mon = xorshift32(rng_mon);
            rsp_ready <= (integer'(rng_mon[7:0]) < p_ready);
        end
    end

    // ------------------------------------------------------------ sequencing
    // All control changes happen on the falling edge so the posedge driver and
    // monitor never race with this process (keeps Icarus and Verilator traces
    // identical); the PRNGs are re-seeded per phase for the same reason.
    task automatic run_phase(input integer id, input integer count, input integer pv, input integer pr,
                             input logic log_it);
        integer guard;
        @(negedge clk);
        phase_id = id;
        n_send = count;
        p_valid = pv;
        p_ready = pr;
        logging = log_it;
        send_idx = 0;
        recv_idx = 0;
        first_fire = -1;
        rng_drv = seed ^ (32'h0101_0101 * id);
        rng_mon = seed ^ 32'h9E37_79B9 ^ (32'h0202_0202 * id);
        driving = 1'b1;
        guard = 0;
        while (recv_idx < count && guard < 40 * count + 1000) begin
            @(negedge clk);
            guard = guard + 1;
        end
        driving = 1'b0;
        if (recv_idx < count) begin
            proto_errors = proto_errors + 1;
            $display("TIMEOUT in phase %0d: received %0d of %0d", id, recv_idx, count);
        end
        repeat (EXP_LAT + 5) @(negedge clk);
        if (rsp_valid) begin
            proto_errors = proto_errors + 1;
            $display("PROTOCOL: response present after phase %0d drained", id);
        end
    endtask

    integer phaseA_span, lat_min_A, lat_max_A, k;
    integer reset_errs = 0;
    string  outfile;

    initial begin
        if (!$value$plusargs("seed=%d", seed)) seed = 32'd20261115;
        if (seed == 0) seed = 32'd1;
        rng_drv = seed;
        rng_mon = seed ^ 32'h9E37_79B9;
        if (!$value$plusargs("outfile=%s", outfile)) outfile = "rtl_results.txt";
        $readmemh({`SF_QT_VEC_DIR, "/stimulus.hex"}, stim);
        $readmemh({`SF_QT_VEC_DIR, "/expected.hex"}, expv);
        fd = $fopen(outfile, "w");
        $display("tb_sf_quantum_tunnel_core: N=%0d DATA_W=%0d FRAC_W=%0d EXP_MODE=%0d SQRT_BPS=%0d PIPE_MUL=%0d seed=%0d expected latency=%0d",
                 N, DATA_W, FRAC_W, `SF_QT_EXP_MODE, BPS, PIPE_MUL, seed, EXP_LAT);
        req_valid = 1'b0;
        rsp_ready = 1'b0;
        rst_n = 1'b0;
        repeat (5) @(negedge clk);
        rst_n = 1'b1;
        repeat (2) @(negedge clk);

        // ---- phase A: full-rate streaming
        lat_min = 1 << 30; lat_max = 0;
        run_phase(1, N, 256, 256, 1'b1);
        phaseA_span = last_fire - first_fire;
        lat_min_A = lat_min; lat_max_A = lat_max;
        if (phaseA_span != N - 1) begin
            proto_errors = proto_errors + 1;
            $display("THROUGHPUT: %0d requests took %0d cycles to issue (expected II=1 -> %0d)", N, phaseA_span, N - 1);
        end
        if (lat_min_A != EXP_LAT || lat_max_A != EXP_LAT) begin
            proto_errors = proto_errors + 1;
            $display("LATENCY: measured %0d..%0d, documented %0d", lat_min_A, lat_max_A, EXP_LAT);
        end

        // ---- phase B: random gaps + backpressure
        lat_min = 1 << 30; lat_max = 0;
        run_phase(2, N, 150, 110, 1'b1);

        // ---- phase C: reset mid-stream
        @(negedge clk);
        phase_id = 3;
        n_send = N; p_valid = 230; p_ready = 200; logging = 1'b0;
        send_idx = 0; recv_idx = 0; first_fire = -1;
        rng_drv = seed ^ 32'h0303_0303;
        rng_mon = seed ^ 32'h9E37_79B9 ^ 32'h0606_0606;
        driving = 1'b1;
        while (recv_idx < 100) @(negedge clk);
        rst_n = 1'b0;
        @(negedge clk);
        for (k = 0; k < 3; k++) begin
            @(negedge clk);
            if (rsp_valid !== 1'b0 || req_valid !== 1'b0) reset_errs = reset_errs + 1;
        end
        driving = 1'b0;
        rst_n = 1'b1;
        repeat (2) @(negedge clk);
        if (rsp_valid !== 1'b0) reset_errs = reset_errs + 1;
        if (req_ready !== 1'b1) reset_errs = reset_errs + 1;
        repeat (EXP_LAT + 5) @(negedge clk);
        if (rsp_valid !== 1'b0) reset_errs = reset_errs + 1;  // nothing in flight survived reset
        run_phase(4, 64, 200, 180, 1'b0);

        $fclose(fd);
        $display("SF_QT_STATS n=%0d latency=%0d latency_documented=%0d phaseA_issue_span=%0d phaseB_latency_min=%0d phaseB_latency_max=%0d mismatches=%0d protocol_errors=%0d x_errors=%0d reset_errors=%0d total_cycles=%0d",
                 N, lat_min_A, EXP_LAT, phaseA_span, lat_min, lat_max, mismatches, proto_errors, x_errors, reset_errs, cycle);
        if (mismatches == 0 && proto_errors == 0 && x_errors == 0 && reset_errs == 0)
            $display("SFX_TB_RESULT: PASS");
        else
            $display("SFX_TB_RESULT: FAIL");
        $finish;
    end

    initial begin
        #(64'd400_000_000);
        $display("WATCHDOG timeout");
        $display("SFX_TB_RESULT: FAIL");
        $finish;
    end

endmodule

`default_nettype wire
