// =============================================================================
// tb_sf_qt_ssb_regs.sv -- SoC Simple Bus adapter test (CPU-style bus master BFM)
//
// Writes barrier parameters for the first N_CHECK golden vectors, starts the
// core, polls STATUS.DONE, reads the results and compares them bit-exactly
// with expected.hex. Also checks ID/INFO, unmapped-address errors, read-only
// write rejection, START while BUSY (START_DROPPED) and the interrupt.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

`include "n_vectors.svh"

module tb_sf_qt_ssb_regs;
    localparam int N       = `SF_QT_N_VECTORS;
    localparam int N_CHECK = 64;
    localparam int STIM_W  = 8 + 4 * 32;
    localparam int EXP_W   = 8 + 2 * 32;

    logic clk = 1'b0, rst_n = 1'b0;
    always #5 clk = ~clk;

    logic        req_valid = 1'b0, req_write = 1'b0, req_ready, rsp_valid, rsp_error, rsp_ready = 1'b0, irq;
    logic [31:0] req_addr = '0, req_wdata = '0, rsp_rdata;
    logic [3:0]  req_wstrb = 4'hF;

    sf_qt_ssb_regs dut (.clk_i(clk), .rst_ni(rst_n), .req_valid(req_valid), .req_addr(req_addr),
                        .req_write(req_write), .req_wdata(req_wdata), .req_wstrb(req_wstrb),
                        .req_ready(req_ready), .rsp_valid(rsp_valid), .rsp_rdata(rsp_rdata),
                        .rsp_error(rsp_error), .rsp_ready(rsp_ready), .irq_o(irq));

    logic [STIM_W-1:0] stim [0:N-1];
    logic [EXP_W-1:0]  expv [0:N-1];
    integer errors = 0;
    logic [31:0] base = 32'h4000_4000;
    logic [31:0] rd;
    logic        rerr;

    task automatic bus(input logic wr, input logic [31:0] addr, input logic [31:0] wdata,
                       output logic [31:0] rdata, output logic err);
        @(posedge clk);
        req_valid <= 1'b1; req_write <= wr; req_addr <= addr; req_wdata <= wdata; req_wstrb <= 4'hF;
        @(posedge clk);
        while (!req_ready) @(posedge clk);
        req_valid <= 1'b0;
        rsp_ready <= 1'b1;
        @(posedge clk);
        while (!rsp_valid) @(posedge clk);
        rdata = rsp_rdata;
        err = rsp_error;
        @(posedge clk);
        rsp_ready <= 1'b0;
    endtask

    task automatic wr32(input logic [31:0] off, input logic [31:0] d);
        logic [31:0] dummy; logic e;
        bus(1'b1, base + off, d, dummy, e);
        if (e) begin errors = errors + 1; $display("unexpected bus error writing %h", off); end
    endtask

    task automatic rd32(input logic [31:0] off, output logic [31:0] d);
        logic e;
        bus(1'b0, base + off, 32'h0, d, e);
        if (e) begin errors = errors + 1; $display("unexpected bus error reading %h", off); end
    endtask

    integer i, polls;
    logic [EXP_W-1:0] e;
    logic [31:0] st, lg, tt, rs;

    initial begin
        $readmemh({`SF_QT_VEC_DIR, "/stimulus.hex"}, stim);
        $readmemh({`SF_QT_VEC_DIR, "/expected.hex"}, expv);
        repeat (4) @(posedge clk);
        rst_n = 1'b1;
        repeat (2) @(posedge clk);

        rd32(32'h28, rd);
        if (rd !== 32'h5346_5154) begin errors++; $display("ID mismatch %h", rd); end
        rd32(32'h2C, rd);
        if (rd[7:0] !== 8'd16 || rd[15:8] !== 8'd38) begin errors++; $display("INFO mismatch %h", rd); end
        bus(1'b0, base + 32'h80, 0, rd, rerr);
        if (!rerr) begin errors++; $display("unmapped read did not error"); end
        bus(1'b1, base + 32'h1C, 32'hDEAD_BEEF, rd, rerr);
        if (!rerr) begin errors++; $display("write to read-only register did not error"); end
        bus(1'b0, base + 32'h09, 0, rd, rerr);
        if (!rerr) begin errors++; $display("misaligned read did not error"); end

        wr32(32'h00, 32'h2);  // IRQ_EN
        for (i = 0; i < N_CHECK; i++) begin
            wr32(32'h08, stim[i][127:96]);
            wr32(32'h0C, stim[i][95:64]);
            wr32(32'h10, stim[i][63:32]);
            wr32(32'h14, stim[i][31:0]);
            wr32(32'h18, {24'b0, stim[i][135:128]});
            wr32(32'h00, 32'h3);  // START | IRQ_EN
            if (i == 0) begin
                wr32(32'h00, 32'h3);  // START again while busy -> dropped
                rd32(32'h04, st);
                if (st[2] !== 1'b1) begin errors++; $display("START_DROPPED not set"); end
                wr32(32'h04, 32'h4);
            end
            polls = 0;
            do begin rd32(32'h04, st); polls++; end while (st[1] !== 1'b1 && polls < 200);
            if (irq !== 1'b1) begin errors++; $display("IRQ not raised for vector %0d", i); end
            rd32(32'h1C, lg);
            rd32(32'h20, tt);
            rd32(32'h24, rs);
            e = expv[i];
            if (lg !== e[63:32] || tt !== e[31:0] || rs[3:0] !== e[67:64] || rs[5:4] !== e[69:68] ||
                rs[15:8] !== stim[i][135:128]) begin
                errors++;
                $display("MISMATCH vector %0d: log %h/%h t %h/%h sts %h", i, lg, e[63:32], tt, e[31:0], rs);
            end
            wr32(32'h04, 32'h2);  // clear DONE
            if (irq !== 1'b0) begin errors++; $display("IRQ not cleared"); end
        end
        $display("SF_QT_SSB_STATS vectors=%0d errors=%0d", N_CHECK, errors);
        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else             $display("SFX_TB_RESULT: FAIL");
        $finish;
    end

    initial begin
        #(64'd50_000_000);
        $display("WATCHDOG timeout");
        $display("SFX_TB_RESULT: FAIL");
        $finish;
    end
endmodule

`default_nettype wire
