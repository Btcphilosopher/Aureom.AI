"""Level 1 exact rectangular barrier: validation checks 1, 2, 3, 5, 8, 9, 14, 16, 17."""

import numpy as np
import pytest
from hypothesis import given, settings, strategies as st

from sf_quantum.quantum.constants import HBAR, M_E, Q_E
from sf_quantum.quantum.hp_reference import rectangular_hp
from sf_quantum.quantum.rectangular import abrupt_prefactor, rectangular_transmission, textbook_equal_mass

V0 = 3.1 * Q_E
M = 0.5 * M_E


@pytest.mark.parametrize("a_nm", [0.3, 1.5, 4.0])
def test_matches_textbook_equal_mass(a_nm):
    E = np.array([0.01, 0.3, 1.0, 2.9, 3.1, 3.4, 6.0, 12.0]) * Q_E
    got = rectangular_transmission(E, V0, a_nm * 1e-9, M).transmission
    ref = textbook_equal_mass(E, V0, a_nm * 1e-9, M)
    np.testing.assert_allclose(got, ref, rtol=1e-12)


@pytest.mark.hp
@pytest.mark.parametrize("a_nm", [0.5, 1.5, 20.0, 50.0])
@pytest.mark.parametrize("e_eV", [0.01, 1.0, 3.0, 3.1, 3.3, 8.0])
def test_matches_independent_high_precision_linear_system(a_nm, e_eV):
    """Check 1 & 14: closed form vs direct 4x4 boundary-matching solve at 60 digits."""
    got = rectangular_transmission(e_eV * Q_E, V0, a_nm * 1e-9, M).log_transmission[0]
    ref = rectangular_hp(e_eV * Q_E, V0, a_nm * 1e-9, M, dps=60).log_transmission
    assert got == pytest.approx(ref, rel=1e-12, abs=1e-12)


@pytest.mark.hp
@pytest.mark.parametrize("e_eV", [0.2, 2.0, 3.5])
def test_unequal_barrier_and_lead_mass(e_eV):
    """Check 5: BenDaniel-Duke mass handling (barrier 0.5, leads 0.26)."""
    got = rectangular_transmission(e_eV * Q_E, V0, 1.0e-9, 0.5 * M_E, 0.26 * M_E).transmission[0]
    ref = rectangular_hp(e_eV * Q_E, V0, 1.0e-9, 0.5 * M_E, 0.26 * M_E).transmission
    assert got == pytest.approx(ref, rel=1e-12)


def test_thin_barrier_limit_is_delta_barrier():
    """Check 2: V0 a = alpha fixed, a -> 0 gives T = 1/(1 + m alpha^2 / (2 hbar^2 E))."""
    alpha = 0.3 * Q_E * 1e-9  # 0.3 eV nm
    E = 0.5 * Q_E
    delta = 1.0 / (1.0 + M * alpha**2 / (2 * HBAR**2 * E))
    errs = []
    for a in [1e-10, 1e-11, 1e-12]:
        t = rectangular_transmission(E, alpha / a, a, M).transmission[0]
        errs.append(abs(t - delta))
    assert errs[-1] < 1e-3 * delta
    assert errs[0] > errs[1] > errs[2]
    # zero-thickness limit with finite height: T -> 1
    assert rectangular_transmission(E, V0, 1e-15, M).transmission[0] == pytest.approx(1.0, abs=1e-8)


def test_wide_barrier_limit_prefactor():
    """Check 3: T -> 16 E (V0-E)/V0^2 exp(-2 kappa a) for kappa a >> 1."""
    E = 1.0 * Q_E
    kap = np.sqrt(2 * M * (V0 - E)) / HBAR
    pf = abrupt_prefactor(E, V0, M)[0]
    assert pf == pytest.approx(16 * E * (V0 - E) / V0**2, rel=1e-12)
    ratios = []
    for a in [0.5e-9, 2e-9, 10e-9, 40e-9]:
        lt = rectangular_transmission(E, V0, a, M).log_transmission[0]
        ratios.append(lt - (np.log(pf) - 2 * kap * a))
    assert abs(ratios[-1]) < 1e-12
    assert abs(ratios[0]) > abs(ratios[1]) > abs(ratios[2])


def test_thick_barrier_no_overflow():
    """Check 13 (Level 1): 50 nm barrier, T ~ 1e-280, finite log value."""
    r = rectangular_transmission(np.array([0.5, 1.0]) * Q_E, V0, 50e-9, M)
    assert np.all(np.isfinite(r.log_transmission))
    assert np.all(r.log_transmission < -500)
    assert np.all(r.reflection <= 1.0)


def test_continuity_through_barrier_top():
    """Check 17: E -> V0 from both sides is continuous and equals the q = 0 formula."""
    a = 1.5e-9
    at = rectangular_transmission(V0, V0, a, M).transmission[0]
    ref = 1.0 / (1.0 + M * a**2 * V0 / (2 * HBAR**2))
    assert at == pytest.approx(ref, rel=1e-14)
    for dE in [1e-6, 1e-9]:
        lo = rectangular_transmission(V0 - dE * Q_E, V0, a, M).transmission[0]
        hi = rectangular_transmission(V0 + dE * Q_E, V0, a, M).transmission[0]
        assert lo == pytest.approx(at, rel=1e-4 * dE / 1e-6 + 1e-12)
        assert hi == pytest.approx(at, rel=1e-4 * dE / 1e-6 + 1e-12)


def test_above_barrier_reflection_and_resonances():
    """Above-barrier T is not 1 in general, and equals 1 at k_b a = n pi."""
    a = 2e-9
    E = 4.0 * Q_E
    r = rectangular_transmission(E, V0, a, M)
    assert r.transmission[0] < 0.999
    assert r.reflection[0] > 1e-3
    kb = np.pi / a  # first resonance
    E_res = V0 + (HBAR * kb) ** 2 / (2 * M)
    assert rectangular_transmission(E_res, V0, a, M).transmission[0] == pytest.approx(1.0, abs=1e-12)


def test_invalid_inputs_rejected():
    """Check 16."""
    with pytest.raises(ValueError):
        rectangular_transmission(0.0, V0, 1e-9, M)
    with pytest.raises(ValueError):
        rectangular_transmission(-0.1 * Q_E, V0, 1e-9, M)
    with pytest.raises(ValueError):
        rectangular_transmission(1.0 * Q_E, V0, 0.0, M)
    with pytest.raises(ValueError):
        rectangular_transmission(1.0 * Q_E, V0, 1e-9, 0.0)
    with pytest.raises(ValueError):
        rectangular_transmission(float("nan"), V0, 1e-9, M)


@settings(max_examples=300, deadline=None)
@given(
    e=st.floats(1e-4, 20.0),
    v=st.floats(-2.0, 10.0),
    a=st.floats(1e-3, 30.0),
    mb=st.floats(0.05, 2.0),
    ml=st.floats(0.05, 2.0),
)
def test_property_bounds_and_conservation(e, v, a, mb, ml):
    """Checks 8 and 9: 0 <= T <= 1 and R + T = 1 for every parameter combination."""
    r = rectangular_transmission(e * Q_E, v * Q_E, a * 1e-9, mb * M_E, ml * M_E)
    T, R = r.transmission[0], r.reflection[0]
    assert 0.0 <= T <= 1.0
    assert 0.0 <= R <= 1.0
    assert T + R == pytest.approx(1.0, abs=1e-12)
    assert np.isfinite(r.log_transmission[0]) and r.log_transmission[0] <= 0.0
