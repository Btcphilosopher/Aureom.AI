import numpy as np
import pytest

from sf_quantum.quantum import barriers as B
from sf_quantum.quantum.constants import M_E, Q_E


def test_rectangular_geometry():
    p = B.rectangular(3.1, 2.0, 0.5)
    assert p.width_m == pytest.approx(2e-9)
    assert p.v_max_J == pytest.approx(3.1 * Q_E)
    assert p.energy_reference == "left_lead_band_edge"
    assert p.potential(np.array([-1e-9]))[0] == 0.0
    assert p.potential(np.array([1e-9]))[0] == pytest.approx(3.1 * Q_E)
    assert p.mass(1e-9) == pytest.approx(0.5 * M_E)
    assert len(p.discontinuities()) == 2


def test_trapezoidal_default_right_lead_follows_drop():
    p = B.trapezoidal(3.1, 2.1, 2.0, 0.5)
    assert p.right.potential_J == pytest.approx(-1.0 * Q_E)
    p2 = B.biased_rectangular(3.1, 2.0, 0.5, field_V_per_nm=0.5)
    assert p2.layers[0].v_end_J == pytest.approx(2.1 * Q_E)
    with pytest.raises(ValueError):
        B.biased_rectangular(3.1, 2.0, 0.5)


def test_triangular_closes_inside_device():
    p = B.triangular(3.0, 1.0, 0.5, extent_factor=1.5)
    assert p.width_m == pytest.approx(4.5e-9)
    assert p.right.potential_J < 0
    with pytest.raises(ValueError):
        B.triangular(3.0, -1.0, 0.5)


def test_with_field_lowers_right_lead():
    p = B.rectangular(3.0, 2.0, 0.5).with_field(5e8)  # 0.5 V/nm
    assert p.layers[0].v_end_J == pytest.approx(2.0 * Q_E)
    assert p.right.potential_J == pytest.approx(-1.0 * Q_E)


def test_double_barrier_and_multi():
    p = B.double_barrier(0.3, 1.0, 5.0, 0.067)
    assert len(p.layers) == 3
    assert p.width_m == pytest.approx(7e-9)


def test_function_and_samples_are_piecewise_linear():
    p = B.from_function(lambda x: 2.0 * np.exp(-((x - 1.0) / 0.4) ** 2), 0.0, 2.0, 0.3, n_samples=101,
                        v_left_eV=0.0, v_right_eV=0.0)
    assert len(p.layers) == 100
    assert p.v_max_J == pytest.approx(2.0 * Q_E, rel=1e-12)


def test_energy_reference_required_and_validated(tmp_path):
    with pytest.raises(ValueError):
        B.from_samples([0, 1], [0, 1], 0.5, energy_reference="")
    with pytest.raises(ValueError):
        B.from_samples([0, 1], [0, 1], 0.5, energy_reference="mystery")
    p = B.from_samples([0, 1], [0, 1], 0.5, energy_reference="custom:TCAD Ec relative to Fermi level")
    assert p.energy_reference.startswith("custom:")
    f = tmp_path / "prof.csv"
    f.write_text("x_nm,V_eV,m_rel\n0,0,0.5\n1,3,0.5\n2,0,0.5\n")
    with pytest.raises(ValueError, match="energy reference"):
        B.from_csv(f)
    f.write_text("# energy_reference: si_conduction_band_edge\nx_nm,V_eV,m_rel\n0,0,0.5\n1,3,0.5\n2,0,0.5\n")
    p = B.from_csv(f)
    assert p.energy_reference == "si_conduction_band_edge"
    assert p.v_max_J == pytest.approx(3 * Q_E)


def test_invalid_layers_rejected():
    with pytest.raises(ValueError):
        B.Layer(0.0, 0.0, 0.0, M_E)
    with pytest.raises(ValueError):
        B.Layer(1e-9, float("nan"), 0.0, M_E)
    with pytest.raises(ValueError):
        B.Layer(1e-9, 0.0, 0.0, -M_E)
    with pytest.raises(ValueError):
        B.from_samples([0, 0], [0, 1], 0.5, energy_reference="left_lead_band_edge")


def test_dict_round_trip():
    p = B.trapezoidal(3.1, 1.0, 1.5, 0.42)
    q = B.PotentialProfile.from_dict(p.to_dict())
    assert q.width_m == pytest.approx(p.width_m)
    assert q.layers[0].v_end_J == pytest.approx(p.layers[0].v_end_J)
    assert q.right.potential_J == pytest.approx(p.right.potential_J)
