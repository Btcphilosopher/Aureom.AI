"""Units and constants: every conversion explicit and tested (spec 4, validation check 4)."""

import math

import numpy as np
import pytest
from scipy import constants as sc

from sf_quantum.quantum import constants as C
from sf_quantum.quantum import units as U


def test_constants_are_codata_from_scipy():
    assert C.HBAR == sc.hbar
    assert C.Q_E == sc.e
    assert C.M_E == sc.m_e
    assert C.K_B == sc.k
    assert C.EPS_0 == sc.epsilon_0
    prov = C.constants_provenance()
    assert prov["codata_release"] in {"2018", "2022"}
    assert prov["values_SI"]["hbar_J_s"] == sc.hbar


def test_length_round_trip():
    assert U.nm_to_m(1.0) == 1e-9
    assert U.m_to_nm(2.5e-9) == pytest.approx(2.5, rel=1e-15)
    arr = np.array([0.1, 1.0, 10.0])
    np.testing.assert_allclose(U.m_to_nm(U.nm_to_m(arr)), arr, rtol=1e-15)


def test_energy_conversion_uses_elementary_charge():
    assert U.eV_to_J(1.0) == sc.e
    assert U.J_to_eV(sc.e) == 1.0
    np.testing.assert_allclose(U.J_to_eV(U.eV_to_J(np.array([0.025, 3.1]))), [0.025, 3.1], rtol=1e-15)


def test_field_conversions():
    # 1 V/nm = 1e9 V/m = 10 MV/cm
    assert U.V_per_nm_to_V_per_m(1.0) == pytest.approx(1e9, rel=1e-15)
    assert U.V_per_m_to_MV_per_cm(1e9) == pytest.approx(10.0, rel=1e-15)
    assert U.MV_per_cm_to_V_per_m(10.0) == pytest.approx(1e9, rel=1e-15)
    assert U.V_per_m_to_V_per_nm(U.MV_per_cm_to_V_per_m(5.0)) == pytest.approx(0.5, rel=1e-15)


def test_current_density_conversion():
    assert U.A_per_cm2_to_A_per_m2(1.0) == pytest.approx(1e4, rel=1e-15)
    assert U.A_per_m2_to_A_per_cm2(1e4) == pytest.approx(1.0, rel=1e-15)


def test_concentration_and_capacitance():
    assert U.per_cm3_to_per_m3(1e17) == pytest.approx(1e23, rel=1e-15)
    # 3.9 eps0 / 1 nm = 3.453e-2 F/m^2 = 3.453 uF/cm^2
    c = 3.9 * sc.epsilon_0 / 1e-9
    assert U.F_per_m2_to_uF_per_cm2(c) == pytest.approx(3.4531, rel=1e-4)


def test_effective_mass_distinct_from_free_mass():
    assert U.effective_mass_kg(1.0) == C.M_E
    assert U.effective_mass_kg(0.5) == 0.5 * C.M_E
    with pytest.raises(ValueError):
        U.effective_mass_kg(0.0)
    with pytest.raises(ValueError):
        U.effective_mass_kg(-0.2)
    with pytest.raises(ValueError):
        U.effective_mass_kg(float("nan"))


def test_decay_constant_known_value():
    """kappa for 1 eV and free mass is 5.1231 nm^-1: catches eV/J mix-ups inside the sqrt."""
    kappa = math.sqrt(2 * C.M_E * U.eV_to_J(1.0)) / C.HBAR
    assert U.m_to_nm(1.0 / kappa) == pytest.approx(1 / 5.12317, rel=1e-5)
    # the classic bug: sqrt with energy in eV gives a value 1/sqrt(e) ~ 2.5e9 times too small
    wrong = math.sqrt(2 * C.M_E * 1.0) / C.HBAR
    assert kappa / wrong == pytest.approx(math.sqrt(sc.e), rel=1e-12)


def test_thermal_energy():
    assert U.thermal_energy_J(300.0) == pytest.approx(sc.k * 300.0)
    assert U.J_to_eV(U.thermal_energy_J(300.0)) == pytest.approx(0.025852, rel=1e-4)
    with pytest.raises(ValueError):
        U.thermal_energy_J(-1.0)
