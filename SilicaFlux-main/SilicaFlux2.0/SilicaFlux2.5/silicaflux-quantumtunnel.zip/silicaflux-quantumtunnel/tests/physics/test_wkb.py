"""Level 2 WKB: units, exactness of the action integral, and validity diagnostics."""

import numpy as np
import pytest

from sf_quantum.quantum import barriers as B
from sf_quantum.quantum import scattering as S
from sf_quantum.quantum.constants import HBAR, M_E, Q_E
from sf_quantum.quantum.rectangular import rectangular_transmission
from sf_quantum.quantum.wkb import WKBFlag, wkb, wkb_callable, wkb_spectrum


def test_rectangular_action_is_kappa_a():
    p = B.rectangular(3.1, 2.0, 0.5)
    E = 1.0 * Q_E
    r = wkb(p, E)
    kappa = np.sqrt(2 * 0.5 * M_E * 2.1 * Q_E) / HBAR
    assert r.action == pytest.approx(kappa * 2e-9, rel=1e-13)
    assert r.log_transmission == pytest.approx(-2 * kappa * 2e-9, rel=1e-13)
    assert WKBFlag.ABRUPT_INTERFACE in r.flags and not r.reliable
    assert r.recommendation is not None


def test_abrupt_prefactor_option_recovers_exact_thick_limit():
    p = B.rectangular(3.1, 6.0, 0.5)
    E = 1.0 * Q_E
    exact = rectangular_transmission(E, 3.1 * Q_E, 6e-9, 0.5 * M_E).log_transmission[0]
    with_pf = wkb(p, E, prefactor="abrupt_rectangular").log_transmission
    plain = wkb(p, E).log_transmission
    assert abs(with_pf - exact) < 1e-9
    assert abs(plain - exact) > 0.3  # the omitted prefactor is a real, reported discrepancy


def test_triangular_action_matches_fowler_nordheim_exponent():
    phi, F, m = 3.1, 1.0, 0.5  # eV, V/nm
    p = B.triangular(phi, F, m)
    E = 1e-3 * Q_E
    r = wkb(p, E)
    expected = (2.0 / 3.0) * np.sqrt(2 * m * M_E) * ((phi * Q_E - E) ** 1.5) / (HBAR * Q_E * F * 1e9)
    assert r.action == pytest.approx(expected, rel=1e-12)
    assert len(r.turning_points_m) == 1
    x_in, x_out = r.turning_points_m[0]
    assert x_in == pytest.approx(0.0, abs=1e-20)
    assert x_out == pytest.approx((phi * Q_E - E) / (Q_E * F * 1e9), rel=1e-12)


def test_piecewise_linear_action_matches_adaptive_quadrature():
    """Smooth Gaussian barrier: exact piecewise-linear integral -> quad on the callable (h^2)."""
    V = lambda x_nm: 1.5 * np.exp(-((x_nm - 2.0) / 0.7) ** 2)
    E = 0.4 * Q_E
    S_quad, tps = wkb_callable(lambda x: V(x * 1e9) * Q_E, 0.3 * M_E, (0.0, 4e-9), E)
    assert len(tps) == 1
    errs = []
    for n in [51, 801, 3201]:
        p = B.from_function(V, 0.0, 4.0, 0.3, n_samples=n, v_left_eV=0.0, v_right_eV=0.0)
        errs.append(abs(wkb(p, E).action - S_quad) / S_quad)
    assert errs[-1] < 2e-8
    # sqrt(u) has a square-root singularity at each turning point, so the
    # piecewise-linear interpolant converges as h^1.5 there (h^2 in the interior)
    order = np.log(errs[1] / errs[2]) / np.log(4.0)
    assert order > 1.3, order
    assert errs[0] > errs[1] > errs[2]


def test_wkb_approaches_exact_for_smooth_wide_barriers():
    """Check 12: WKB vs numerical discrepancy shrinks as a smooth barrier grows."""
    E = 0.3 * Q_E
    discrepancies = []
    for w in [1.0, 2.0, 4.0]:
        p = B.from_function(lambda x: 1.0 * np.exp(-((x - 2 * w) / w) ** 2), 0.0, 4 * w, 0.3, n_samples=401,
                            v_left_eV=0.0, v_right_eV=0.0)
        lw = wkb(p, E).log_transmission
        ln = S.transmission(p, E, max_slice_m=0.002e-9).log_transmission[0]
        discrepancies.append(abs(lw - ln) / abs(ln))
    assert discrepancies[0] > discrepancies[1] > discrepancies[2]
    assert discrepancies[-1] < 0.02


def test_above_barrier_is_flagged_not_unit():
    p = B.rectangular(1.0, 1.0, 0.5)
    r = wkb(p, 1.5 * Q_E)
    assert WKBFlag.ABOVE_BARRIER in r.flags
    assert np.isnan(r.transmission) and np.isnan(r.log_transmission)
    exact = rectangular_transmission(1.5 * Q_E, 1.0 * Q_E, 1e-9, 0.5 * M_E).transmission[0]
    assert exact < 0.999  # over-barrier reflection is real
    spec = wkb_spectrum(p, np.array([0.5, 1.5]) * Q_E)
    assert np.isnan(spec["transmission"][1]) and spec["above_barrier"][1]


def test_weak_and_narrow_flags_near_barrier_top():
    p = B.rectangular(3.1, 1.0, 0.5)
    r = wkb(p, 3.09 * Q_E)
    assert WKBFlag.WEAK_TUNNELLING in r.flags
    assert WKBFlag.NARROW_BARRIER in r.flags


def test_double_barrier_flagged_resonant():
    p = B.double_barrier(0.3, 1.0, 5.0, 0.067)
    r = wkb(p, 0.08 * Q_E)
    assert WKBFlag.MULTIPLE_FORBIDDEN_REGIONS in r.flags
    assert r.diagnostics["n_forbidden_regions"] == 2


def test_no_transmitted_state_is_exact_zero():
    p = B.rectangular(3.0, 1.0, 0.5, lead_potential_eV=0.0)
    p = B.PotentialProfile(p.layers, p.left, B.Lead(1.0 * Q_E, p.right.mass_kg), p.energy_reference)
    r = wkb(p, 0.5 * Q_E)
    assert WKBFlag.NO_TRANSMITTED_STATE in r.flags
    assert r.transmission == 0.0 and r.log_transmission == -np.inf
    assert S.transmission(p, 0.5 * Q_E).transmission[0] == 0.0


def test_rapid_variation_flag_for_extreme_field():
    p = B.triangular(3.1, 8.0, 0.5)
    assert WKBFlag.RAPID_VARIATION in wkb(p, 0.01 * Q_E).flags
    p2 = B.triangular(3.1, 0.5, 0.5)
    assert WKBFlag.RAPID_VARIATION not in wkb(p2, 0.01 * Q_E).flags


def test_log_transmission_retained_for_extreme_thickness():
    p = B.rectangular(3.1, 200.0, 0.5)
    r = wkb(p, 0.5 * Q_E)
    assert r.transmission == 0.0  # exp underflows...
    assert np.isfinite(r.log_transmission) and r.log_transmission < -2000  # ...the log does not


def test_invalid_energy():
    p = B.rectangular(3.1, 1.0, 0.5)
    with pytest.raises(ValueError):
        wkb(p, 0.0)
    with pytest.raises(ValueError):
        wkb(p, float("nan"))
    with pytest.raises(ValueError):
        wkb(p, 1.0 * Q_E, prefactor="bogus")
