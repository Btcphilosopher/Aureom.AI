"""Fixed-point model (the RTL's specification): budget soundness, generated-file freshness."""

import json
import math

import pytest
from hypothesis import given, settings, strategies as st

from sf_quantum.provenance import PROJECT_ROOT
from sf_quantum.reference import fixed_point_model as FP
from sf_quantum.reference import tunneling_golden as G


@settings(max_examples=2000, deadline=None)
@given(v0=st.floats(0.02, 15.99), frac_e=st.floats(1e-4, 0.9999), a=st.floats(0.0, 63.99), m=st.floats(1e-4, 15.99))
def test_hardware_model_within_error_budget(v0, frac_e, a, m):
    c = [FP.encode(x, 16, 32) for x in (v0, v0 * frac_e, a, m)]
    if c[1] == 0 or c[3] == 0 or c[1] >= c[0]:
        return
    r = FP.evaluate(*c)
    ref = FP.double_reference(*c)
    b = FP.error_budget(*c)
    assert r.err & (FP.ERR_INVALID | FP.ERR_ABOVE) == 0
    assert abs(r.log_value - ref["log_t"]) <= b["log_t"]
    assert abs(r.t_value - ref["t"]) <= b["t"]
    assert 0 <= r.t_code < 2**32


def test_status_bits():
    enc = lambda *v: [FP.encode(x, 16, 32) for x in v]
    assert FP.evaluate(*enc(3.1, 3.1, 1.5, 0.5)).err == FP.ERR_ABOVE
    assert FP.evaluate(*enc(3.1, 3.5, 1.5, 0.5)).err == FP.ERR_ABOVE
    above = FP.evaluate(*enc(3.1, 3.5, 1.5, 0.5))
    assert above.t_code == 0 and above.log_code == 0  # reported, never returned as T = 1
    assert FP.evaluate(0, 0, 0, 0).err == FP.ERR_INVALID
    assert FP.evaluate(16 << 16, 1 << 16, 1 << 16, 1 << 15).err == FP.ERR_INVALID
    weak = FP.evaluate(*enc(3.1, 3.09, 0.05, 0.5))
    assert weak.warn & FP.WARN_WKB_WEAK
    under = FP.evaluate(*enc(3.1, 1.0, 6.0, 0.5))
    assert under.warn & FP.WARN_TX_UNDER and under.t_code == 0 and under.log_value < -40
    zero_w = FP.evaluate(*enc(3.1, 1.0, 0.0, 0.5))
    assert zero_w.t_code == 2**32 - 1 and zero_w.log_code == 0
    w24 = FP.HWConfig(data_w=24)
    sat = FP.evaluate(*[FP.encode(x, 16, 24) for x in (15.0, 0.1, 60.0, 10.0)], cfg=w24)
    assert sat.err & FP.ERR_LOG_SAT and FP.to_signed(sat.log_code, 24) == -(2**23)


def test_constants_and_rom():
    assert FP.c1_physical() == pytest.approx(10.24633, rel=1e-6)
    c1, c2 = FP.constant_codes()
    assert abs(c1 / 2**24 - FP.c1_physical()) <= 2**-25
    rom = FP.exp_rom()
    assert len(rom) == 256 and rom[0][0] == 2**34
    for i in (0, 77, 255):
        assert rom[i][0] == round(2 ** (-i / 256) * 2**34) or i == 0
    with pytest.raises(ValueError):
        FP.HWConfig(data_w=22, frac_w=16)  # integer field too narrow for the range checks


def test_generated_rtl_files_are_current(tmp_path):
    """The checked-in generated SV must equal a fresh generation (single source of truth)."""
    G.generate_rtl_constants(FP.DEFAULT, tmp_path / "c.svh")
    assert (tmp_path / "c.svh").read_text() == (PROJECT_ROOT / "rtl/quantum/generated/sf_qt_constants.svh").read_text()
    for cfg in (FP.DEFAULT, G.W24):
        p = G.generate_rtl_rom(cfg, tmp_path)
        name = p.split("/")[-1]
        assert open(p).read() == (PROJECT_ROOT / "rtl/quantum/generated" / name).read_text()


@pytest.mark.parametrize("set_name", list(G.VECTOR_SETS))
def test_stored_vectors_reproduce_bit_exactly(set_name):
    vec = json.loads((PROJECT_ROOT / "vectors" / set_name / "vectors.json").read_text())
    cfg = FP.HWConfig(**{k: v for k, v in vec["solver_settings"]["hw_config"].items() if k in FP.HWConfig.__dataclass_fields__})
    assert vec["format_version"] == G.VECTOR_FORMAT_VERSION
    for r in vec["vectors"][::7]:
        c = r["codes"]
        h = FP.evaluate(c["V0"], c["E"], c["A"], c["M"], cfg)
        x = r["expected_hw"]
        assert (h.log_code, h.t_code, h.err, h.warn) == (x["log_code"], x["t_code"], x["err"], x["warn"])
        if x["err"] == 0 and r["reference"]["log_transmission"] is not None:
            assert math.isfinite(r["tolerance"]["log_transmission_abs"])


def test_vector_generation_deterministic(tmp_path):
    a = G.generate("t", n_random=50, seed=5, out_root=tmp_path / "a")
    b = G.generate("t", n_random=50, seed=5, out_root=tmp_path / "b")
    assert a["sha256"] == b["sha256"]
    c = G.generate("t", n_random=50, seed=6, out_root=tmp_path / "c")
    assert c["sha256"] != a["sha256"]
