import json

import numpy as np
import pytest

from sf_quantum.analysis import reliability, sensitivity, sweeps, validation
from sf_quantum.devices import materials as M
from sf_quantum.devices.dielectric_stack import matched_eot_stack
from sf_quantum.provenance import load_experiment, make_metadata, save_experiment
from sf_quantum.quantum import barriers as B
from sf_quantum.quantum import scattering as S
from sf_quantum.quantum.constants import M_E, Q_E
from sf_quantum.quantum.rectangular import rectangular_transmission


def test_adaptive_grid_resolves_resonance_uniform_grid_misses():
    p = B.double_barrier(0.3, 3.0, 5.0, 0.067)  # thick barriers: narrow resonances
    coarse = np.linspace(0.005, 0.25, 40) * Q_E
    t_coarse = S.transmission(p, coarse).transmission.max()
    E, T = sweeps.adaptive_energy_grid(p, 0.005 * Q_E, 0.25 * Q_E, n_initial=40, tol_linear=2e-3, max_points=8000)
    assert t_coarse < 0.9
    assert T.max() > 0.999
    assert np.all(np.diff(E) > 0)


def test_energy_sweep_includes_exact_for_rectangular():
    df = sweeps.energy_sweep(B.rectangular(3.1, 1.5, 0.5), np.linspace(0.1, 5, 30) * Q_E)
    np.testing.assert_allclose(df["logT_scattering"], df["logT_exact"], rtol=1e-11, atol=1e-11)
    assert df.loc[df.energy_eV > 3.1, "logT_wkb"].isna().all()  # above-barrier WKB is NaN, not 1
    assert (df["conservation_error"] < 1e-10).all()


def test_thickness_sweep_exponential_slope():
    df = sweeps.thickness_sweep(M.SIO2, np.linspace(1.0, 4.0, 13), energies_eV=(0.5,), fields_MV_per_cm=(0.0,))
    inner = df.iloc[2:-2]
    np.testing.assert_allclose(inner["dlogT_dt_per_nm"], inner["minus_2kappa_per_nm"], rtol=5e-3)


def test_field_sweep_regimes():
    df = sweeps.field_sweep(M.SIO2, 3.0, np.array([1.0, 5.0, 12.0]), energy_eV=0.05)
    assert list(df.regime) == ["direct", "direct", "fowler-nordheim"]
    fn = df[df.regime == "fowler-nordheim"].iloc[0]
    assert fn.logT_wkb == pytest.approx(fn.logT_fn_triangular, rel=1e-9)


def test_monte_carlo_reproducible_and_spearman_sign():
    def model(p):
        return {"logT": float(rectangular_transmission(1.0 * Q_E, p["V"] * Q_E, p["a"] * 1e-9, p["m"] * M_E)
                              .log_transmission[0])}
    d = [sensitivity.Distribution("V", "uniform", (2.9, 3.3), 3.1, provenance="literature"),
         sensitivity.Distribution("a", "triangular", (1.4, 1.5, 1.6), 1.5),
         sensitivity.Distribution("m", "uniform", (0.29, 0.5), 0.5, provenance="literature")]
    r1 = sensitivity.monte_carlo(model, d, n_samples=200, seed=11)
    r2 = sensitivity.monte_carlo(model, d, n_samples=200, seed=11)
    assert r1["samples"].equals(r2["samples"])
    s = r1["summary"]["logT"]["spearman"]
    assert s["a"] < 0 and s["m"] < 0 and s["V"] < 0
    assert "not measured manufacturing variability" in r1["interpretation"]
    loc = sensitivity.local_sensitivities(model, {"V": 3.1, "a": 1.5, "m": 0.5}, "logT")
    # d lnT / d ln a = -2 kappa a exactly for the dominant exponential (plus a small prefactor term)
    assert loc["a"]["d_output_d_lnparam"] == pytest.approx(loc["a"]["output_nominal"], rel=0.15)


def test_manufacturing_variability_requires_measured_data():
    with pytest.raises(ValueError, match="measured"):
        sensitivity.Distribution("t_ox", "normal", (1.5, 0.02), 1.5, uncertainty_kind="manufacturing_variability")
    sensitivity.Distribution("t_ox", "normal", (1.5, 0.02), 1.5, uncertainty_kind="manufacturing_variability",
                             provenance="measured")


def test_provenance_round_trip(tmp_path):
    meta = make_metadata("unit-test", inputs={"V0_eV": 3.1}, assumptions=["1D"], testbench_seed=3,
                         parameter_provenance={"V0_eV": "literature"})
    assert meta["physical_constants"]["codata_release"] in ("2018", "2022")
    assert len(meta["source_tree_sha256"]) == 64
    assert "calibration_statement" in meta
    paths = save_experiment(tmp_path, "exp", meta, arrays={"E": np.arange(3.0), "flags": np.array(["a", "bb"], dtype=object)})
    m2, arr = load_experiment(tmp_path, "exp")
    assert m2["inputs"]["V0_eV"] == 3.1
    np.testing.assert_array_equal(arr["E"], np.arange(3.0))
    assert json.loads(open(paths["json"]).read())["hdf5_datasets"] == ["E", "flags"]


def test_validation_suite_all_pass(tmp_path):
    res = validation.run_all()
    failed = [(r.number, r.name, r.detail) for r in res if not r.passed]
    assert not failed, failed
    summary = validation.write_report(res, tmp_path)
    assert summary == {"passed": 18, "total": 18}
    assert (tmp_path / "VALIDATION.md").exists()


def test_reliability_interface_disclaims_wearout():
    rep = reliability.field_stress_report(matched_eot_stack(1.0, M.HFO2, M.SIO2, 0.5), np.array([0.5, 1.0]))
    assert rep["rows"][1]["max_field_layer"] == "SiO2"
    assert any("TDDB" in s for s in rep["not_modelled"])
