"""Level 3 numerical solvers: checks 6, 7, 9, 10, 11, 13, 14, 15, 17."""

import numpy as np
import pytest
from hypothesis import given, settings, strategies as st

from sf_quantum.quantum import barriers as B
from sf_quantum.quantum import scattering as S
from sf_quantum.quantum import schrodinger as FD
from sf_quantum.quantum.constants import M_E, Q_E
from sf_quantum.quantum.hp_reference import layered_transfer_hp
from sf_quantum.quantum.rectangular import rectangular_transmission

ENERGIES = np.array([0.01, 0.5, 1.0, 3.0, 3.2, 5.0, 10.0]) * Q_E


@pytest.mark.parametrize("a_nm", [0.5, 1.5, 20.0, 50.0])
def test_smatrix_exact_for_rectangular(a_nm):
    """Flat layers are single exact slices: agreement to rounding, even at 50 nm."""
    p = B.rectangular(3.1, a_nm, 0.5)
    ref = rectangular_transmission(ENERGIES, 3.1 * Q_E, a_nm * 1e-9, 0.5 * M_E).log_transmission
    got = S.transmission(p, ENERGIES).log_transmission
    np.testing.assert_allclose(got, ref, rtol=1e-12, atol=1e-11)


def test_smatrix_degenerate_energy_is_documented_shift():
    p = B.rectangular(3.1, 1.5, 0.5)
    got = S.transmission(p, 3.1 * Q_E).transmission[0]
    exact = rectangular_transmission(3.1 * Q_E, 3.1 * Q_E, 1.5e-9, 0.5 * M_E).transmission[0]
    # the 1e-9 eV shift of the degenerate slice perturbs T by ~ (dT/dE) * 1e-9 eV
    assert got == pytest.approx(exact, rel=1e-7)


def test_thick_barrier_stability_vs_naive_transfer_matrix():
    """Check 13: S-matrix finite & exact at 20 nm; the naive transfer-matrix product is not."""
    p = B.rectangular(3.1, 20.0, 0.5)
    E = 1.0 * Q_E
    exact = rectangular_transmission(E, 3.1 * Q_E, 20e-9, 0.5 * M_E).log_transmission[0]
    stable = S.transmission(p, E).log_transmission[0]
    naive = S.naive_transfer_matrix_log_t(p, E)
    assert stable == pytest.approx(exact, rel=1e-12)
    assert not (np.isfinite(naive) and abs(naive - exact) < 1.0)


@pytest.mark.hp
@pytest.mark.parametrize(
    "profile",
    [
        B.trapezoidal(3.1, 1.1, 2.0, 0.5),
        B.triangular(3.1, 1.2, 0.5),
        B.layered(
            [dict(thickness_nm=0.5, v_start_eV=3.1, v_end_eV=2.9, m_eff=0.5),
             dict(thickness_nm=2.0, v_start_eV=1.4, v_end_eV=0.6, m_eff=0.2)],
            left_lead=(0.0, 0.26), right_lead=(-1.2, 1.0)),
    ],
    ids=["trapezoid", "triangle", "SiO2-HfO2-unequal-leads"],
)
@pytest.mark.parametrize("e_eV", [0.05, 0.5, 1.5])
def test_numerical_solvers_vs_airy_high_precision(profile, e_eV):
    """Check 14: both numerical solvers converge to the exact Airy solution."""
    E = e_eV * Q_E
    ref = layered_transfer_hp(profile, E, dps=60).log_transmission
    sm = S.converged_transmission(profile, E, rtol_log=1e-8)
    assert sm["log_transmission"] == pytest.approx(ref, rel=1e-7, abs=1e-7)
    fd = FD.solve(profile, E, grid_m=0.002e-9).log_transmission[0]
    assert fd == pytest.approx(ref, rel=2e-4, abs=2e-4)


def test_flux_normalisation_unequal_leads():
    """Check 6: T != |t|^2 when lead velocities differ; flux-normalised T matches the reference."""
    # slow heavy left lead, fast light right lead: velocity ratio ~ 20
    p = B.layered([dict(thickness_nm=1.0, v_start_eV=2.0, v_end_eV=2.0, m_eff=0.4)],
                  left_lead=(0.0, 1.0), right_lead=(-2.0, 0.1))
    E = 0.05 * Q_E
    r = S.transmission(p, E)
    amp2 = abs(r.t_amplitude[0]) ** 2
    assert amp2 / r.transmission[0] < 0.1 or amp2 / r.transmission[0] > 10
    assert r.transmission[0] + r.reflection[0] == pytest.approx(1.0, abs=1e-12)
    ref = layered_transfer_hp(p, E).transmission
    assert r.transmission[0] == pytest.approx(ref, rel=1e-10)
    assert r.transmitted_flux[0] / r.incident_flux[0] == pytest.approx(r.transmission[0], rel=1e-14)


@pytest.mark.parametrize("profile", [B.trapezoidal(3.1, 1.1, 2.0, 0.5), B.double_barrier(0.3, 1.0, 5.0, 0.067)])
def test_probability_current_constant_through_device(profile):
    """Check 7: j(x) computed from the reconstructed psi is uniform and equals T * j_in."""
    E = 0.0789 * Q_E if len(profile.layers) == 3 else 1.0 * Q_E
    wf = S.wavefunction(profile, E)
    spread = (wf.current.max() - wf.current.min()) / wf.incident_flux
    assert spread < 1e-9
    assert np.mean(wf.current) / wf.incident_flux == pytest.approx(wf.transmission, rel=1e-8)


def test_wavefunction_matches_lead_amplitudes():
    p = B.rectangular(3.1, 1.0, 0.5)
    E = 1.0 * Q_E
    wf = S.wavefunction(p, E)
    left = wf.x_m < 0
    np.testing.assert_allclose(np.abs(wf.incident[left]), 1.0, rtol=1e-12)
    assert np.nanmax(np.abs(wf.reflected[left])) ** 2 == pytest.approx(wf.reflection, rel=1e-10)
    # psi continuous at interfaces
    for xb in [0.0, 1e-9]:
        near = np.array([xb - 1e-19, xb + 1e-19])
        w2 = S.wavefunction(p, E, x_m=near)
        assert abs(w2.psi[0] - w2.psi[1]) < 1e-5 * abs(w2.psi[0])


def test_grid_convergence_second_order():
    """Check 10: observed order of accuracy ~2 for both numerical solvers."""
    p = B.trapezoidal(3.1, 1.1, 2.0, 0.5)
    E = 0.5 * Q_E
    ref = layered_transfer_hp(p, E).log_transmission
    sm = [abs(S.transmission(p, E, max_slice_m=h).log_transmission[0] - ref) for h in (0.04e-9, 0.02e-9, 0.01e-9)]
    fd = [abs(FD.solve(p, E, grid_m=h).log_transmission[0] - ref) for h in (0.02e-9, 0.01e-9, 0.005e-9)]
    for errs in (sm, fd):
        orders = np.log2(np.array(errs[:-1]) / np.array(errs[1:]))
        assert np.all(orders > 1.8) and np.all(orders < 2.3), orders


def test_energy_grid_convergence_of_integrated_transmission():
    """Check 11: integral of T(E) converges as the energy grid is refined."""
    p = B.trapezoidal(1.0, 0.6, 2.0, 0.3)
    vals = []
    for n in [51, 101, 201, 401]:
        E = np.linspace(0.01, 0.9, n) * Q_E
        T = S.transmission(p, E).transmission
        vals.append(np.trapezoid(T, E))
    diffs = np.abs(np.diff(vals))
    assert diffs[0] > diffs[1] > diffs[2]
    assert diffs[-1] / abs(vals[-1]) < 1e-3


def test_resonant_double_barrier_unity_peak():
    p = B.double_barrier(0.3, 1.0, 5.0, 0.067)
    E = np.linspace(0.07, 0.09, 4001) * Q_E
    T = S.transmission(p, E).transmission
    assert T.max() > 0.9999
    fdT = FD.solve(p, E[np.argmax(T)], grid_m=0.002e-9).transmission[0]
    assert fdT > 0.95  # FD resonance shifts slightly with h; still a sharp peak


def test_reproducibility_bitwise():
    """Check 15."""
    p = B.trapezoidal(3.1, 1.1, 2.0, 0.5)
    E = np.linspace(0.01, 3.0, 50) * Q_E
    a = S.transmission(p, E).transmission
    b = S.transmission(p, E).transmission
    assert np.array_equal(a, b)
    assert np.array_equal(FD.solve(p, E).transmission, FD.solve(p, E).transmission)


def test_invalid_energies_rejected():
    p = B.rectangular(3.1, 1.0, 0.5)
    for bad in (0.0, -1e-20, float("nan")):
        with pytest.raises(ValueError):
            S.transmission(p, bad)
    with pytest.raises(ValueError):
        FD.solve(p, 0.0)


@settings(max_examples=60, deadline=None)
@given(
    v1=st.floats(0.0, 4.0), v2=st.floats(-2.0, 4.0), w=st.floats(0.2, 6.0),
    m=st.floats(0.1, 1.0), ml=st.floats(0.1, 1.0), mr=st.floats(0.1, 1.0), e=st.floats(0.01, 6.0),
)
def test_property_conservation_any_trapezoid(v1, v2, w, m, ml, mr, e):
    p = B.layered([dict(thickness_nm=w, v_start_eV=v1, v_end_eV=v2, m_eff=m)],
                  left_lead=(0.0, ml), right_lead=(min(v2, 0.0) - 0.5, mr))
    r = S.transmission(p, e * Q_E, max_slice_m=0.02e-9)
    assert 0.0 <= r.transmission[0] <= 1.0 + 1e-12
    assert r.conservation_error[0] < 1e-9
    f = FD.solve(p, e * Q_E, grid_m=0.02e-9)
    assert 0.0 <= f.transmission[0] <= 1.0 + 1e-12
    assert f.conservation_error[0] < 1e-9


@pytest.mark.hp
@pytest.mark.parametrize("field_MV_per_cm", [0.25, 2.0, 18.0])
def test_airy_reference_gentle_slope_thick_layer(field_MV_per_cm):
    """Regression: Airy arguments of |z| ~ 1e2 (Ai/Bi ~ 1e-1500 / 1e+1500) and negative slopes.

    Two bugs were found here during development: mpmath's numerical LU inverse declared the
    Airy basis singular (fixed with the exact Wronskian) and mp.cbrt returned the complex
    principal root for negative slopes (fixed with the real cube root)."""
    from sf_quantum.devices import materials as Mt
    from sf_quantum.devices.dielectric_stack import single_layer
    prof = single_layer(Mt.SIO2, 3.0).simplified_profile(field_MV_per_cm * 0.3, left_lead_mass=0.26,
                                                          right_lead_mass=0.26)
    ref = layered_transfer_hp(prof, 0.05 * Q_E).log_transmission
    got = S.converged_transmission(prof, 0.05 * Q_E, rtol_log=1e-9)["log_transmission"]
    assert got == pytest.approx(ref, rel=1e-7)
