import json
import re
import subprocess
import sys

import pytest

from sf_quantum.integration.ssb_driver import REGS, Driver, ModelBus
from sf_quantum.integration.transistorlab import LayerSpec, TunnellingRequest, analyse
from sf_quantum.provenance import PROJECT_ROOT
from sf_quantum.reference import fixed_point_model as FP


def test_transistorlab_contract_mos_and_simplified():
    req = TunnellingRequest(stack=[LayerSpec(material="SiO2", thickness_nm=0.5), LayerSpec(material="HfO2", thickness_nm=2.5)],
                            gate_voltage_V=1.0, geometry={"L_nm": 20})
    r = analyse(req)
    assert r.dimensionality == "1D slice"
    assert len(r.log_transmission_scattering) == 3
    assert r.current_estimates["status"] == "not computed"
    assert "not calibrated" in r.calibration
    assert any("1D" in w for w in r.validity_warnings)
    r2 = analyse(TunnellingRequest(stack=[LayerSpec(material="SiO2", thickness_nm=1.5, mass_rel=0.42)], stack_voltage_V=0.8))
    assert r2.profile["layers"][0]["mass_rel"] == pytest.approx(0.42)
    with pytest.raises(ValueError):
        analyse(TunnellingRequest(stack=[LayerSpec(material="SiO2", thickness_nm=1.0)]))


def test_register_map_matches_rtl():
    sv = (PROJECT_ROOT / "rtl/integration/sf_qt_ssb_regs.sv").read_text()
    doc = dict(re.findall(r"//\s+0x([0-9A-F]{2}) (\w+)", sv))
    expected = {f"{getattr(REGS, k):02X}": k for k in ("CTRL", "STATUS", "BARRIER", "ENERGY", "WIDTH", "MASS", "TAG",
                                                       "RESULT_LOG", "RESULT_T", "RESULT_STS", "ID", "INFO")}
    assert doc == expected
    assert f"{REGS.ID_VALUE:08X}" in sv.replace("_", "").upper() or "5346_5154" in sv


def test_driver_against_bit_accurate_model_bus():
    d = Driver(ModelBus())
    out = d.evaluate(3.1, 1.0, 1.5, 0.5, tag=9)
    ref = FP.double_reference(*[FP.encode(x, 16, 32) for x in (3.1, 1.0, 1.5, 0.5)])
    assert out["error"] == 0 and out["tag"] == 9
    assert out["log_T"] == pytest.approx(ref["log_t"], abs=1e-4)


def test_sf_sketch_ports_match_systemverilog():
    sf = (PROJECT_ROOT / "sf/sf_quantum_tunnel.sf").read_text()
    sv = (PROJECT_ROOT / "rtl/quantum/sf_quantum_tunnel_core.sv").read_text()
    sf_ports = set(re.findall(r"^\s*(?:input|output)\s+(\w+)\s*:", sf, re.M)) | set(re.findall(r"^\s*(?:clock|reset)\s+(\w+)", sf, re.M))
    header = sv[sv.index("module sf_quantum_tunnel_core"):sv.index(");")]
    sv_ports = set(re.findall(r"(\w+_[io]|\w+_ni)\s*,?\s*$", header, re.M))
    assert sf_ports == sv_ports, (sf_ports ^ sv_ports)
    sf_params = set(re.findall(r"(\w+): UInt =", sf))
    sv_params = set(re.findall(r"parameter int (\w+)", header))
    assert sf_params == sv_params
    assert "NOT COMPILED" in sf


def test_fastapi_endpoints():
    pytest.importorskip("fastapi")
    pytest.importorskip("httpx")
    from fastapi.testclient import TestClient
    from sf_quantum.api import app
    c = TestClient(app)
    assert c.get("/health").json()["status"] == "ok"
    r = c.post("/solve/exact", json={"height_eV": 3.1, "width_nm": 1.5, "mass_rel": 0.5, "energy_eV": 1.0}).json()
    assert r["ln_T"] == pytest.approx(-14.4973, abs=1e-3)
    above = c.post("/solve/wkb", json={"energy_eV": 4.0}).json()
    assert above["flags"] == ["above_barrier"] and above["transmission"] is None and "undefined" in above["note"]
    assert c.post("/solve/bogus", json={}).status_code == 404
    assert c.post("/solve/scattering", json={"energy_eV": -1}).status_code == 422
    t = c.post("/transistorlab/analyse", json={"stack": [{"material": "SiO2", "thickness_nm": 1.2}], "stack_voltage_V": 0.5})
    assert t.status_code == 200 and t.json()["dimensionality"] == "1D slice"


def _cli(*args):
    return subprocess.run([sys.executable, "-m", "sf_quantum.cli", *args], capture_output=True, text=True,
                          cwd=PROJECT_ROOT, env={"PYTHONPATH": str(PROJECT_ROOT / "python"), "PATH": "/usr/bin:/bin"})


def test_cli_solvers_and_dielectric():
    r = _cli("solve", "exact", "--energy", "1.0", "--json")
    assert r.returncode == 0, r.stderr
    assert json.loads(r.stdout)["ln_T"] == pytest.approx(-14.4973, abs=1e-3)
    r = _cli("solve", "wkb", "--energy", "1.0", "--json")
    assert "abrupt_interface" in json.loads(r.stdout)["flags"]
    r = _cli("solve", "scattering", "--shape", "trapezoidal", "--field", "0.5", "--energy", "0.5", "--json")
    assert json.loads(r.stdout)["conservation_error"] < 1e-10
    r = _cli("dielectric", "compare")
    assert r.returncode == 0 and json.loads(r.stdout)["stacks"][1]["EOT_nm"] == pytest.approx(1.0)
    r = _cli("barrier", "trapezoidal", "--field", "0.3")
    assert r.returncode == 0 and "energy reference" in r.stdout
    r = _cli("compare", "models", "--energies", "0.5", "4.0")
    assert r.returncode == 0 and "logT_exact" in r.stdout
    r = _cli("solve", "exact", "--shape", "trapezoidal", "--field", "0.3")
    assert r.returncode != 0


def test_cli_reports_unavailable_simulator_clearly():
    """With no simulator on PATH the RTL gate must say so and exit 3, not claim success."""
    r = subprocess.run([sys.executable, "-m", "sf_quantum.cli", "verify", "rtl"], capture_output=True, text=True,
                       cwd=PROJECT_ROOT, env={"PYTHONPATH": str(PROJECT_ROOT / "python"), "PATH": "/nonexistent"})
    assert r.returncode == 3
    assert "UNAVAILABLE" in r.stderr
