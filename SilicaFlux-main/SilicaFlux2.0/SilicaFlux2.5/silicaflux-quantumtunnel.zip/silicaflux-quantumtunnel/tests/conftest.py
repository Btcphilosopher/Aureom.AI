import os
import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))


def pytest_configure(config):
    os.environ.setdefault("MPLBACKEND", "Agg")


@pytest.fixture(scope="session")
def project_root() -> Path:
    return ROOT


def have_simulator() -> bool:
    return shutil.which("iverilog") is not None or shutil.which("verilator") is not None
