import numpy as np
import pytest

from sf_quantum.devices import materials as M
from sf_quantum.devices.advanced import DIMENSIONALITY, finfet_sidewall, gaa_nanosheet, planar_mosfet
from sf_quantum.devices.dielectric_stack import single_layer
from sf_quantum.devices.gate_tunneling import gate_current_density, junction_profile
from sf_quantum.models import current as C
from sf_quantum.models import fowler_nordheim as FN
from sf_quantum.quantum import barriers as B
from sf_quantum.quantum import scattering as S
from sf_quantum.quantum.constants import Q_E
from sf_quantum.quantum.wkb import wkb_action_array

PHI, M_OX = 3.1, 0.5


def _fn_profile(F_V_per_nm, t_nm=6.0):
    V = F_V_per_nm * t_nm
    return B.layered([dict(thickness_nm=t_nm, v_start_eV=PHI, v_end_eV=PHI - V, m_eff=M_OX)],
                     left_lead=(-5.5, 1.0), right_lead=(-5.5 - V, 1.0), energy_reference="left_fermi_level"), V


@pytest.mark.parametrize("F", [0.8, 1.0, 1.5])
@pytest.mark.parametrize("T", [1e-3, 300.0])
def test_tsu_esaki_reproduces_fowler_nordheim(F, T):
    """Independent validation of the 3D current model: numerical supply-function integral with WKB
    triangular transmission vs the analytical FN law. The residual is the next term of the
    linearisation, -F/B, which is checked quantitatively."""
    prof, V = _fn_profile(F)
    tf = lambda E: np.exp(-2 * wkb_action_array(prof, E))
    num = C.tsu_esaki_current_density(tf, emitter_band_bottom_J=-5.5 * Q_E, mu_left_J=0.0, mu_right_J=-V * Q_E,
                                      temperature_K=T, transverse_mass_rel=1.0, electrode_kinds=("metal", "metal"),
                                      n_energy=6000)["J_A_per_m2"]
    fn = FN.current_density(F * 1e9, PHI, M_OX, thickness_m=6e-9, temperature_K=T)
    ratio = num / fn["J_A_per_m2"][0]
    expected = 1.0 - F * 1e9 / fn["B"]
    assert ratio == pytest.approx(expected, abs=0.01)


def test_fn_refuses_direct_regime():
    with pytest.raises(FN.FNRegimeError):
        FN.current_density(0.5e9, PHI, M_OX, thickness_m=2e-9)  # qFt = 1 V < 3.1 eV
    out = FN.current_density(np.array([0.5e9, 2.0e9]), PHI, M_OX, thickness_m=2e-9, allow_outside_regime=True)
    assert list(out["regime"]) == ["direct", "fowler-nordheim"]
    assert out["outside_validity"][0] and not out["outside_validity"][1]


def test_fn_constants_and_plot_line():
    B_ = FN.exponent_B(PHI, M_OX)
    prof = B.triangular(PHI, 1.0, M_OX)
    from sf_quantum.quantum.wkb import wkb
    assert B_ / 1e9 == pytest.approx(2 * wkb(prof, 1e-30).action, rel=1e-9)
    F = np.linspace(1.0e9, 2.0e9, 5)
    j = FN.current_density(F, PHI, M_OX, thickness_m=5e-9)["J_A_per_m2"]
    x, y = FN.fn_plot_coordinates(F, j)
    slope = np.polyfit(x, y, 1)[0]
    assert slope == pytest.approx(-B_, rel=1e-9)
    with pytest.raises(FN.FNRegimeError):
        FN.temperature_factor(0.2e9, PHI, M_OX, 1000.0)


def test_landauer_conductance_quantum():
    E = np.linspace(-0.5, 0.5, 20001) * Q_E
    v = 1e-4
    out = C.landauer_current_1d(E, np.ones_like(E), v * Q_E / 2, -v * Q_E / 2, 4.0)
    assert out["current_A"] / v == pytest.approx(C.conductance_quantum(), rel=1e-6)
    out1 = C.landauer_current_1d(E, np.ones_like(E), v * Q_E / 2, -v * Q_E / 2, 4.0, spin_degeneracy=1, modes=3)
    assert out1["current_A"] / v == pytest.approx(1.5 * C.conductance_quantum(), rel=1e-6)
    assert "not a MOS gate-current density" in out["note"]
    with pytest.raises(ValueError):
        C.landauer_current_1d(E[::-1], np.ones_like(E), 0.0, 0.0, 300.0)


def test_landauer_through_barrier_zero_bias_zero_current():
    p = B.rectangular(0.3, 2.0, 0.067)
    E = np.linspace(0.001, 0.6, 3000) * Q_E
    T = S.transmission(p, E).transmission
    assert C.landauer_current_1d(E, T, 0.05 * Q_E, 0.05 * Q_E, 300.0)["current_A"] == 0.0
    i1 = C.landauer_current_1d(E, T, 0.06 * Q_E, 0.05 * Q_E, 300.0)["current_A"]
    i2 = C.landauer_current_1d(E, T, 0.05 * Q_E, 0.06 * Q_E, 300.0)["current_A"]
    assert i1 > 0 and i2 == pytest.approx(-i1, rel=1e-12)


def test_fermi_dirac_limits():
    assert C.fermi_dirac(np.array([-1.0, 0.0, 1.0]) * Q_E, 0.0, 0.0).tolist() == [1.0, 0.5, 0.0]
    assert C.fermi_dirac(np.array([100.0]) * Q_E, 0.0, 300.0)[0] == 0.0  # no overflow
    with pytest.raises(ValueError):
        C.fermi_dirac(0.0, 0.0, -1.0)


def test_gate_current_symmetry_and_refusal():
    s = single_layer(M.SIO2, 2.0)
    g = M.GENERIC_METAL_GATE
    j0 = gate_current_density(s, 0.0, emitter=g, collector=g)
    assert j0.J_A_per_m2 == 0.0
    jp = gate_current_density(s, 1.0, emitter=g, collector=g, area_m2=1e-12)
    jn = gate_current_density(s, -1.0, emitter=g, collector=g)
    assert jp.J_A_per_m2 > 0 and jn.J_A_per_m2 == pytest.approx(-jp.J_A_per_m2, rel=1e-6)
    assert jp.power_W == pytest.approx(jp.current_A * 1.0)
    assert "subthreshold channel current" in jp.not_modelled
    inv = M.Electrode(name="Si inversion layer", kind=M.ElectrodeKind.SEMICONDUCTOR_SURFACE,
                      work_function_eV=M.SILICON.electron_affinity_eV, fermi_energy_eV=g.fermi_energy_eV,
                      mass_rel=M.SILICON.lead_mass_rel)
    with pytest.raises(C.UnsupportedModelError):
        gate_current_density(s, 1.0, emitter=inv, collector=g)


def test_gate_current_increases_with_bias_decreases_with_thickness():
    g = M.GENERIC_METAL_GATE
    j = [gate_current_density(single_layer(M.SIO2, 2.0), v, emitter=g, collector=g, n_energy=1500).J_A_per_m2
         for v in (0.5, 1.0, 1.5)]
    assert j[0] < j[1] < j[2]
    jt = [gate_current_density(single_layer(M.SIO2, t), 1.0, emitter=g, collector=g, n_energy=1500).J_A_per_m2
          for t in (1.5, 2.0, 2.5)]
    assert jt[0] > jt[1] > jt[2]
    # exponential thickness dependence: log-slope roughly constant
    s1, s2 = np.log(jt[0] / jt[1]), np.log(jt[1] / jt[2])
    assert s2 == pytest.approx(s1, rel=0.25)


def test_junction_profile_barrier_from_work_function_and_affinity():
    p = junction_profile(single_layer(M.SIO2, 2.0), 0.0, M.GENERIC_METAL_GATE, M.GENERIC_METAL_GATE)
    chi_ox = M.SILICON.electron_affinity_eV.value - M.SIO2.conduction_band_offset_eV.value
    assert p.v_max_J / Q_E == pytest.approx(M.GENERIC_METAL_GATE.work_function_eV.value - chi_ox)


def test_advanced_slices_are_labelled_1d():
    s = single_layer(M.SIO2, 1.2)
    for sl in (planar_mosfet(s), finfet_sidewall(s, 7, 42), gaa_nanosheet(s, 30, 5)):
        p = sl.profile(1.0)
        assert p.dimensionality == DIMENSIONALITY
        assert any("no 3D electrostatics" in n for n in p.notes)
