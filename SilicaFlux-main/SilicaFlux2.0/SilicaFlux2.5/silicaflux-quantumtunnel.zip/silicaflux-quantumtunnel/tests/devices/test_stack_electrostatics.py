import numpy as np
import pytest

from sf_quantum.devices import materials as M
from sf_quantum.devices.dielectric_stack import (DielectricLayer, DielectricStack, high_k_thickness_for_eot,
                                                 matched_eot_stack, single_layer)
from sf_quantum.devices.electrostatics import MOSCapacitor, load_devsim_export, profile_from_potential
from sf_quantum.quantum.constants import EPS_0, Q_E


def test_barrier_height_is_band_offset_not_bandgap():
    p = single_layer(M.SIO2, 1.5).simplified_profile(0.0)
    assert p.v_max_J / Q_E == pytest.approx(3.1)
    assert p.v_max_J / Q_E != pytest.approx(M.SILICON.bandgap_eV.value)


def test_eot_and_capacitance():
    s = single_layer(M.SIO2, 1.0)
    assert s.eot_nm == pytest.approx(1.0)
    assert s.capacitance_F_per_m2 == pytest.approx(3.9 * EPS_0 / 1e-9)
    hk = matched_eot_stack(1.0, M.HFO2, M.SIO2, 0.5)
    assert hk.eot_nm == pytest.approx(1.0, rel=1e-12)
    assert hk.layers[1].thickness_nm == pytest.approx(0.5 * 25 / 3.9)
    assert hk.physical_thickness_nm > 3 * s.physical_thickness_nm
    assert hk.capacitance_F_per_m2 == pytest.approx(s.capacitance_F_per_m2, rel=1e-12)
    with pytest.raises(ValueError):
        high_k_thickness_for_eot(0.4, M.HFO2, [DielectricLayer(material=M.SIO2, thickness_nm=0.5)])


def test_field_partition_scales_inverse_permittivity():
    hk = matched_eot_stack(1.0, M.HFO2, M.SIO2, 0.5)
    part = hk.partition(1.0)
    f = part["fields_V_per_m"]
    assert f[0] / f[1] == pytest.approx(25.0 / 3.9, rel=1e-12)  # D continuous
    assert part["voltage_drops_V"].sum() == pytest.approx(1.0, rel=1e-12)
    d = part["displacement_C_per_m2"]
    assert d[0] == pytest.approx(d[1], rel=1e-12)


def test_interface_charge_breaks_d_continuity():
    s = DielectricStack(layers=(DielectricLayer(material=M.SIO2, thickness_nm=0.5),
                                DielectricLayer(material=M.HFO2, thickness_nm=2.0)),
                        interface_charges_C_per_m2=(1e-3,))
    part = s.partition(1.0)
    assert part["displacement_C_per_m2"][0] - part["displacement_C_per_m2"][1] == pytest.approx(1e-3)
    assert part["voltage_drops_V"].sum() == pytest.approx(1.0, rel=1e-12)


def test_mos_not_all_voltage_across_oxide():
    mos = MOSCapacitor(single_layer(M.SIO2, 1.5), M.GENERIC_METAL_GATE, doping_cm3=1e17, doping_type="p")
    st = mos.solve(1.0)
    assert st.regime == "strong inversion"
    assert 0.05 < st.fraction_across_stack < 0.9
    # Kirchhoff: VG - phi_ms = psi_s + V_ox
    phi_ms = mos.gate.work_function_eV.value - mos.semiconductor_work_function_eV
    assert st.surface_potential_V + st.stack_voltage_V == pytest.approx(1.0 - phi_ms, abs=1e-12)
    # Gauss at the Si surface: eps_ox F_ox = -Q_s
    assert EPS_0 * 3.9 * st.fields_V_per_m[0] == pytest.approx(-st.semiconductor_charge_C_per_m2, rel=1e-10)


def test_mos_flatband_and_depletion_analytic():
    mos = MOSCapacitor(single_layer(M.SIO2, 3.0), M.GENERIC_METAL_GATE, doping_cm3=1e16, doping_type="p")
    st = mos.solve(mos.flatband_voltage_V)
    assert abs(st.surface_potential_V) < 1e-9 and st.regime == "flat-band"
    # depletion approximation: Q = -sqrt(2 eps q N psi) when psi >> kT/q and below inversion
    psi = 0.3
    q_exact = mos.semiconductor_charge(psi)
    q_dep = -np.sqrt(2 * mos.eps_si * Q_E * mos.n_dop * (psi - mos.vt))
    assert q_exact == pytest.approx(q_dep, rel=1e-3)


def test_mos_n_type_mirror():
    p = MOSCapacitor(single_layer(M.SIO2, 2.0), M.GENERIC_METAL_GATE, 1e17, "p")
    n = MOSCapacitor(single_layer(M.SIO2, 2.0), M.GENERIC_METAL_GATE, 1e17, "n")
    assert p.semiconductor_charge(0.4) == pytest.approx(-n.semiconductor_charge(-0.4), rel=1e-12)
    assert n.solve(-1.0).regime in ("strong inversion", "weak inversion", "depletion")


def test_mos_barrier_profile_labelled():
    mos = MOSCapacitor(single_layer(M.SIO2, 1.5), M.GENERIC_METAL_GATE)
    prof = mos.barrier_profile(1.2)
    assert prof.energy_reference == "si_conduction_band_edge"
    assert any("1D slice" in n for n in prof.notes)
    assert prof.layers[0].v_end_J < prof.layers[0].v_start_J


def test_potential_to_energy_sign():
    """Higher electrostatic potential lowers electron energy: E_c = -q phi."""
    p = profile_from_potential([0.0, 1.0, 2.0], [0.0, 0.5, 1.0], [0.0, 3.1, 3.1], 0.5)
    v = p.potential(np.array([1.2e-9, 1.8e-9])) / Q_E  # both inside the oxide (Delta Ec = 3.1)
    assert v[1] < v[0]
    assert p.layers[-1].v_end_J / Q_E == pytest.approx(2.1)


def test_devsim_csv_import(tmp_path):
    f = tmp_path / "devsim_nodes.csv"
    f.write_text("# x_unit: nm\nx,Potential,region\n0.0,0.0,silicon\n0.0,0.0,oxide\n1.0,0.4,oxide\n2.0,0.8,oxide\n")
    p = load_devsim_export(f, dielectric_offsets_eV={"silicon": 0.0, "oxide": 3.1},
                           masses_rel={"silicon": 0.26, "oxide": 0.5})
    assert p.energy_reference.startswith("custom:")
    assert p.width_m == pytest.approx(2e-9)
    assert p.layers[-1].v_end_J / Q_E == pytest.approx(3.1 - 0.8)
    with pytest.raises(ValueError):
        load_devsim_export(f, dielectric_offsets_eV={"oxide": 3.1}, masses_rel={"oxide": 0.5})


def test_material_provenance_complete():
    rows = M.material_table()
    assert all(r["source"] for r in rows)
    hf_mass = [r for r in rows if r["material"] == "HfO2" and r["parameter"] == "tunnelling_mass_rel"][0]
    assert hf_mass["provenance"] == "assumed"
    with pytest.raises(ValueError):
        M.Parameter(value=5.0, unit="eV", provenance="literature", source="x", range=(1.0, 2.0))
    hyp = M.hypothetical_dielectric("X", 15.0, 2.0, 0.3)
    assert hyp.relative_permittivity.provenance == M.Provenance.HYPOTHETICAL
