# RTL verification report

Origin: **RTL SIMULATION** of `rtl/quantum/sf_quantum_tunnel_core.sv` (Icarus Verilog 12 / Verilator 5) compared with the Python golden reference.

All runs pass: **True**. Cross-simulator identical traces: **True**.

| config | sim | seed | status | vectors | bit-exact | latency (cyc) | II | max abs ln T err | mean abs ln T err | max rel T err (T>1e-6) | max err/budget (lnT, T) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| default | iverilog | 20261115 | PASS | 2056 | True | 38 | 1.000 | 0.000299 | 2.1e-05 | 8.66e-05 | 0.975, 0.956 |
| default | verilator | 20261115 | PASS | 2056 | True | 38 | 1.000 | 0.000299 | 2.1e-05 | 8.66e-05 | 0.975, 0.956 |
| bps5 | iverilog | 20261115 | PASS | 2056 | True | 18 | 1.000 | 0.000299 | 2.1e-05 | 8.66e-05 | 0.975, 0.956 |
| nopipe | iverilog | 20261115 | PASS | 2056 | True | 35 | 1.000 | 0.000299 | 2.1e-05 | 8.66e-05 | 0.975, 0.956 |
| direct | iverilog | 20261115 | PASS | 556 | True | 38 | 1.000 | 0.000259 | 1.98e-05 | 0.00135 | 0.934, 0.941 |
| w24 | iverilog | 20261115 | PASS | 456 | True | 38 | 1.000 | 0.000237 | 9.11e-06 | 0.0213 | 0.958, 0.966 |
| default | iverilog | 20261116 | PASS | 2056 | True | 38 | 1.000 | 0.000299 | 2.1e-05 | 8.66e-05 | 0.975, 0.956 |

## Worst-case parameter combinations (ln T)

- `default/iverilog/seed 20261115`: vector 1674 (rand-1618): inputs {'V0_eV': 1.4821624755859375, 'E_eV': 0.10107421875, 'A_nm': 63.775421142578125, 'M_rel': 5.91436767578125}, |d lnT| = 0.000299 at ln T = -1868
- `default/verilator/seed 20261115`: vector 1674 (rand-1618): inputs {'V0_eV': 1.4821624755859375, 'E_eV': 0.10107421875, 'A_nm': 63.775421142578125, 'M_rel': 5.91436767578125}, |d lnT| = 0.000299 at ln T = -1868
- `bps5/iverilog/seed 20261115`: vector 1674 (rand-1618): inputs {'V0_eV': 1.4821624755859375, 'E_eV': 0.10107421875, 'A_nm': 63.775421142578125, 'M_rel': 5.91436767578125}, |d lnT| = 0.000299 at ln T = -1868
- `nopipe/iverilog/seed 20261115`: vector 1674 (rand-1618): inputs {'V0_eV': 1.4821624755859375, 'E_eV': 0.10107421875, 'A_nm': 63.775421142578125, 'M_rel': 5.91436767578125}, |d lnT| = 0.000299 at ln T = -1868
- `direct/iverilog/seed 20261115`: vector 429 (rand-373): inputs {'V0_eV': 7.594757080078125, 'E_eV': 6.33160400390625, 'A_nm': 63.5517578125, 'M_rel': 0.02813720703125}, |d lnT| = 0.000259 at ln T = -122.8
- `w24/iverilog/seed 20261115`: vector 319 (rand-263): inputs {'V0_eV': 8.201187133789062, 'E_eV': 6.25628662109375, 'A_nm': 57.51911926269531, 'M_rel': 0.0214996337890625}, |d lnT| = 0.000237 at ln T = -120.5
- `default/iverilog/seed 20261116`: vector 1674 (rand-1618): inputs {'V0_eV': 1.4821624755859375, 'E_eV': 0.10107421875, 'A_nm': 63.775421142578125, 'M_rel': 5.91436767578125}, |d lnT| = 0.000299 at ln T = -1868

## Coverage counts (phase A)

- `default/iverilog`: {'responses_checked': 2056, 'valid_tunnelling': 1936, 'invalid': 98, 'above_barrier': 22, 'log_saturated': 0, 'tx_underflow': 849, 'wkb_weak': 527}
- `default/verilator`: {'responses_checked': 2056, 'valid_tunnelling': 1936, 'invalid': 98, 'above_barrier': 22, 'log_saturated': 0, 'tx_underflow': 849, 'wkb_weak': 527}
- `bps5/iverilog`: {'responses_checked': 2056, 'valid_tunnelling': 1936, 'invalid': 98, 'above_barrier': 22, 'log_saturated': 0, 'tx_underflow': 849, 'wkb_weak': 527}
- `nopipe/iverilog`: {'responses_checked': 2056, 'valid_tunnelling': 1936, 'invalid': 98, 'above_barrier': 22, 'log_saturated': 0, 'tx_underflow': 849, 'wkb_weak': 527}
- `direct/iverilog`: {'responses_checked': 556, 'valid_tunnelling': 520, 'invalid': 26, 'above_barrier': 10, 'log_saturated': 0, 'tx_underflow': 221, 'wkb_weak': 139}
- `w24/iverilog`: {'responses_checked': 456, 'valid_tunnelling': 346, 'invalid': 30, 'above_barrier': 5, 'log_saturated': 75, 'tx_underflow': 186, 'wkb_weak': 118}
- `default/iverilog`: {'responses_checked': 2056, 'valid_tunnelling': 1936, 'invalid': 98, 'above_barrier': 22, 'log_saturated': 0, 'tx_underflow': 849, 'wkb_weak': 527}

## Sampled-profile integrator (`sf_qt_integrator`)

- iverilog: **PASS** -- 53 profiles / 16095 samples, bit-exact True, II = 1.000 sample/cycle, max |d lnT| vs discrete reference 0.000509 (max error/budget 0.509)
- verilator: **PASS** -- 53 profiles / 16095 samples, bit-exact True, II = 1.000 sample/cycle, max |d lnT| vs discrete reference 0.000509 (max error/budget 0.509)
- cross-simulator identical traces: True

Discretisation error (discrete trapezoid sum vs continuous piecewise-linear WKB, 2S) is a property of the sampling, not of the hardware; per-profile values are in `rtl_verification.json`.


Vectors outside budget and bit mismatches are listed in `rtl_verification.json` (empty lists mean none occurred).
