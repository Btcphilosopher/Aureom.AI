# 2^-f unit design study

Accuracy: measured max relative error of the 2^-f mantissa (PYTHON MODEL, integer arithmetic, MANT_F=34). Cost: structural count; synthesised numbers for the two implemented modes are in `reports/synthesis/SYNTHESIS.md`.

| approach | size | max rel. error | ROM bits | multipliers | iterations |
|---|---|---|---|---|---|
| LUT nearest | 2^4 entries | 0.0219 (bound 0.0217) | 1040 | - | 1 |
| LUT + linear interp | 2^4 entries | 0.000235 (bound 0.000235) | 1040 | 30x16 | 1 |
| LUT nearest | 2^6 entries | 0.00543 (bound 0.00542) | 4032 | - | 1 |
| LUT + linear interp | 2^6 entries | 1.47e-05 (bound 1.47e-05) | 4032 | 28x14 | 1 |
| LUT nearest | 2^8 entries | 0.00135 (bound 0.00135) | 15616 | - | 1 |
| LUT + linear interp | 2^8 entries | 9.16e-07 (bound 9.16e-07) | 15616 | 26x12 | 1 |
| LUT nearest | 2^10 entries | 0.000338 (bound 0.000338) | 60416 | - | 1 |
| LUT + linear interp | 2^10 entries | 5.74e-08 (bound 5.73e-08) | 60416 | 24x10 | 1 |
| piecewise quadratic | 4 segments | 2.92e-05 | 432 | 34x18, 34x18 | 1 |
| piecewise quadratic | 16 segments | 4.32e-07 | 1728 | 34x16, 34x16 | 1 |
| piecewise quadratic | 64 segments | 6.77e-09 | 6912 | 34x14, 34x14 | 1 |
| shift-and-add | 16 iterations | 3.05e-05 | 640 | - | 16 |
| shift-and-add | 24 iterations | 1.19e-07 | 960 | - | 24 |
| shift-and-add | 34 iterations | 2.33e-10 | 1360 | - | 34 |

**Choice:** LUT + linear interpolation with 2^8 entries (implemented, default EXP_MODE=1). Its ~1e-6 error is below the datapath's own ln T error for typical barriers, it needs one modest multiplier, and the ROM fits two ECP5 DP16KD blocks. Nearest-entry (EXP_MODE=0) saves the multiplier at ~1e-3 error. A quadratic would need two wide multipliers for accuracy the datapath cannot use; shift-and-add trades the multiplier for ~N cycles or N pipeline stages.
