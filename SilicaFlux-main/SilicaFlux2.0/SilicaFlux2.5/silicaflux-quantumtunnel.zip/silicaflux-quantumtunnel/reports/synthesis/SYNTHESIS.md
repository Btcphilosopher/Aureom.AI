# Synthesis, implementation and resource report

Every number below was produced by the named tool in this environment. Labels: SYNTHESIS = logic synthesis, POST-ROUTE = after nextpnr placement and routing, PRE-LAYOUT ESTIMATE = standard-cell mapping without placement. No number is estimated by hand.

## FPGA: Lattice ECP5 LFE5U-85F (Yosys 0.33 + nextpnr-ecp5 0.6)

| config | PIPE_MUL | SQRT_BPS | EXP_MODE | LUT4 | FF | CCU2C | MULT18X18D | DP16KD | post-route Fmax (MHz) | latency (cycles) |
|---|---|---|---|---|---|---|---|---|---|---|
| default | 1 | 1 | 1 | 2237 | 3331 | 983 | 22 | 2 | 57.84 | 38 |
| nopipe | 0 | 1 | 1 | 2234 | 3017 | 983 | 22 | 2 | 46.2 | 35 |
| bps5 | 1 | 5 | 1 | 2986 | 1627 | 983 | 22 | 2 | 34.51 | 18 |
| direct | 1 | 1 | 0 | 2263 | 3287 | 959 | 20 | 2 | 54.85 | 38 |

Throughput at II = 1 (verified in RTL simulation) is one evaluation per cycle, i.e. Fmax million evaluations per second for the post-route Fmax above.

## Technology-independent (Yosys generic)

| config | cells | flip-flops | transistor estimate |
|---|---|---|---|
| default | 28503 | 3371 | 197284 |
| nopipe | 28269 | 3057 | 197726 |
| bps5 | 27048 | 1688 | 197182 |
| direct | 26521 | 3327 | 182718 |

## iCE40 UP5K fit check (Yosys synth_ice40 -dsp)

SB_LUT4 2725 (capacity 5280), SB_MAC16 21 (capacity 8), SB_RAM40_4K 4, DFF 3272 -> fits: **False**

## ASIC-style PRE-LAYOUT ESTIMATE (NanGate45 Open Cell Library, typical)

- standard cells: 36112
- cell area: 48066 um^2 (0.0481 mm^2)
- ABC post-sizing combinational delay: 1431 ps (logic-only bound 699 MHz)

- caveat: cell area only: no placement, routing, wires or clock tree
- caveat: delay is ABC's combinational estimate with no wire-load model; NOT static timing analysis
- caveat: no power estimate (no activity-annotated power tool available)

## Exponential unit design study (synthesised alone, PIPE=1)

| mode | generic cells | FF | ECP5 LUT4 | MULT18X18D | DP16KD |
|---|---|---|---|---|---|
| mode0 (nearest entry) | 2875 | 288 | 375 | 0 | 2 |
| mode1 (linear interpolation) | 4778 | 310 | 349 | 2 | 2 |

Accuracy of each option: `reports/exp_study/EXP_STUDY.md`.

## Sampled-profile integrator (`sf_qt_integrator`)

Generic: 38868 cells, 4434 flip-flops. ECP5: LUT4 3364, FF 4392, MULT18X18D 28, DP16KD 2, post-route Fmax 57.21 MHz (one sample per cycle).

SoC Simple Bus adapter incl. core (generic): 29695 cells, 3622 flip-flops.

Not produced (tool unavailable): signoff STA, ASIC place-and-route, power analysis, vendor (Vivado/Quartus) implementation.
