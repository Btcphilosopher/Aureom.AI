# SilicaFlux QuantumTunnel -- engineering reports

Source tree SHA-256: `c570cb22b5fe387ba9beab5068f25d2ee928b5ba1e666546048ff3363378d1fd`; git: {'revision': None, 'note': 'not a git work tree (delivered as an archive)'}

| report | status | file |
|---|---|---|
| Numerical validation (18 checks) | 18/18 pass | `validation/VALIDATION.md` |
| RTL verification | all pass | `rtl/RTL_VERIFICATION.md` |
| Synthesis / place-and-route | present | `synthesis/SYNTHESIS.md` |
| Exp-unit design study | present | `exp_study/EXP_STUDY.md` |
| Benchmarks | present | `benchmarks/BENCHMARKS.md` |
| Experiments A-E summary | present | `experiments_summary.json`, `../data/experiments/` |
| Figures | 5 PNG | `figures/` |
| Dashboard | present | `../dashboard/index.html` |

Labels used throughout: PYTHON MODEL, ANALYTICAL, RTL SIMULATION, SYNTHESIS, POST-ROUTE, PRE-LAYOUT ESTIMATE. No FPGA measurement, silicon measurement, signoff STA or power analysis exists in this repository.
