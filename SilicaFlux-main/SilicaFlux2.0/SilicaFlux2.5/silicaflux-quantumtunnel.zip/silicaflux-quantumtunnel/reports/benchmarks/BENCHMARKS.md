# Performance benchmarks

Python measured on `x86_64`, 3.13.18 (best-of-N wall clock).

| Python benchmark | result |
|---|---|
| exact rectangular, vectorised | 1.76e+07 energies/s |
| exact rectangular, single call | 50.3 us |
| WKB with full diagnostics, single | 78.4 us |
| WKB action, vectorised | 4.43e+07 energies/s |
| S-matrix rectangular, single energy | 59.8 us |
| S-matrix trapezoid (401 slices), single energy | 6.65 ms |
| S-matrix spectrum, 2000 energies | 0.053 s (3.74e+04 E/s) |
| finite-difference spectrum, 200 energies | 0.010 s |
| thickness sweep (198 solves) | 0.33 s |
| peak memory: smatrix_spectrum_2000E | 0.7 MiB |
| peak memory: exact_100k_energies | 12.5 MiB |
| peak memory: wavefunction_2000_points | 1.1 MiB |

## RTL (RTL SIMULATION)

| config | simulator | latency (cycles) | II | transactions/cycle |
|---|---|---|---|---|
| default | iverilog | 38 | 1.000 | 1.000 |
| default | verilator | 38 | 1.000 | 1.000 |
| bps5 | iverilog | 18 | 1.000 | 1.000 |
| nopipe | iverilog | 35 | 1.000 | 1.000 |
| direct | iverilog | 38 | 1.000 | 1.000 |
| w24 | iverilog | 38 | 1.000 | 1.000 |
| default | iverilog | 38 | 1.000 | 1.000 |

## FPGA (SYNTHESIS + POST-ROUTE, Lattice ECP5 LFE5U-85F)

| config | LUT4 | FF | DSP (MULT18X18D) | BRAM (DP16KD) | post-route Fmax (MHz) |
|---|---|---|---|---|---|
| default | 2237 | 3331 | 22 | 2 | 57.84 |
| nopipe | 2234 | 3017 | 22 | 2 | 46.2 |
| bps5 | 2986 | 1627 | 22 | 2 | 34.51 |
| direct | 2263 | 3287 | 20 | 2 | 54.85 |

## ASIC (PRE-LAYOUT ESTIMATE, NanGate45 OCL typical)

cells 36112, cell area 48066 um^2, ABC logic delay 1431 ps. No STA, no power (tools unavailable).
