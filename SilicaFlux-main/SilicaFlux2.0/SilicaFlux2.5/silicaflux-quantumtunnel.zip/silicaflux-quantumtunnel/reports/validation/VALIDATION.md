# Numerical validation report

Origin of every number: PYTHON MODEL (this package) compared with the stated reference.

**18 / 18 checks passed.**

| # | Check | Result | Value | Threshold | Detail |
|---|---|---|---|---|---|
| 1 | Exact rectangular-barrier reference | PASS | 2.76e-15 | < 1e-12 rel. in ln T | closed form vs 50-digit 4x4 boundary-matching solve |
| 2 | Thin-barrier limit | PASS | 0.000486 | < 1e-3 | V0*a fixed, a=1 pm vs delta-barrier T |
| 3 | Wide-barrier limit | PASS | 0 | < 1e-10 abs in ln T | 40 nm vs 16E(V0-E)/V0^2 exp(-2 kappa a) |
| 4 | Correct potential-energy units | PASS | 5.42e-07 | < 2e-6 | kappa(1 eV, m0) = 5.12317 nm^-1 (catches eV/J mix-ups) |
| 5 | Correct effective-mass handling | PASS | 3.85e-14 | < 1e-12 | barrier 0.5 m0 / leads 0.26 m0 (BenDaniel-Duke) vs HP solve |
| 6 | Correct flux normalisation | PASS | 9.13e-16 | < 1e-10 | unequal leads: |t|^2/T = 0.0494 (velocity factor applied) |
| 7 | Probability-current conservation | PASS | 1.56e-15 | < 1e-9 | max-min of j(x)/j_in across leads and barrier |
| 8 | 0 <= T <= 1 for passive lossless models | PASS | 0 | 0 violations | 400 random rectangles + 300-point trapezoid spectrum |
| 9 | R + T -> 1 | PASS | 2.53e-12 | < 1e-10 | |R+T-1|, S-matrix and FD, SiO2/HfO2-like stack |
| 10 | Grid convergence | PASS | 1.98 | observed order in (1.8, 2.3) | S-matrix staircase, slice 0.04/0.02/0.01 nm |
| 11 | Energy-grid convergence | PASS | 3e-05 | < 1e-4 and monotone | integral of T(E) dE on 101..801-point grids |
| 12 | WKB vs numerical discrepancy | PASS | 0.000823 | decreasing with width, < 2% for the widest | smooth Gaussian barrier relative ln T discrepancy ['0.0466', '0.0129', '0.000823'] |
| 13 | Thick-barrier numerical stability | PASS | 2.17e-16 | < 1e-12 rel. | 50 nm SiO2-like, ln T = -523.7; naive transfer matrix gives 453.3337602727402 |
| 14 | High-precision reference comparison | PASS | 4.32e-12 | < 1e-7 rel. | converged S-matrix vs 60-digit Airy transfer matrices |
| 15 | Reproducibility | PASS | 1 | bitwise identical | seeded Monte Carlo + repeated solver calls |
| 16 | Invalid-input rejection | PASS | 7/7 | all rejected with ValueError | E<=0, negative width/mass, NaN, missing energy reference |
| 17 | Edge-case validation | PASS | E=V0 err 3.3e-15; resonance peak 1.000000 | E=V0 exact, T_res>0.9999, WKB above-barrier flagged | barrier top, resonant double barrier, above-barrier WKB refusal |
| 18 | Numerical regression tests | PASS | 0 | < 1e-10 rel. vs stored values | 7 stored values; worst: none |
