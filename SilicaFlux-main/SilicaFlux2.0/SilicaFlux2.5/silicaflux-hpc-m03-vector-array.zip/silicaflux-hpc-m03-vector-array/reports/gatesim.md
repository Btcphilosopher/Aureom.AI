# Module 03 gate-level simulation

34 / 34 PASS.  Netlists: Yosys 0.33 `synth -flatten` generic gates of `hpc_vector_array` (default parameters, NUM_LANES = 2 and 4), written by `syn/run_synth.sh`.  Testbench: `tb/tb_hpc_vector_array.sv` compiled with `-DGATE` (identical checks except the internal-probe coverage and the held-lane probe).  Icarus runs are 4-state: X on any output or any X left by reset fails the run.  The `long` test (vl = 65 535) is run on Verilator only (Icarus gate-level runtime).

| simulator | netlist | test | profile | result | elements | cycles | resets (mid-activity) |
|---|---|---|---|---|---|---|---|
| verilator | n2 | directed | clean | PASS | 133 | 168 | 0 (0) |
| verilator | n2 | mixed | stall | PASS | 1467 | 2005 | 0 (0) |
| verilator | n2 | mask | phase | PASS | 406 | 1023 | 0 (0) |
| verilator | n2 | red | stall | PASS | 850 | 1747 | 0 (0) |
| verilator | n2 | reset | rst_stall | PASS | 1163 | 163 | 15 (12) |
| verilator | n2 | b2b | bp | PASS | 792 | 4587 | 0 (0) |
| verilator | n2 | illegal | clean | PASS | 458 | 1102 | 0 (0) |
| verilator | n2 | fpexc | stuck | PASS | 952 | 11268 | 0 (0) |
| verilator | n2 | long | clean | PASS | 81980 | 45104 | 0 (0) |
| icarus | n2 | directed | clean | PASS | 133 | 168 | 0 (0) |
| icarus | n2 | mixed | stall | PASS | 1467 | 2005 | 0 (0) |
| icarus | n2 | mask | phase | PASS | 406 | 1023 | 0 (0) |
| icarus | n2 | red | stall | PASS | 850 | 1747 | 0 (0) |
| icarus | n2 | reset | rst_stall | PASS | 1163 | 163 | 15 (12) |
| icarus | n2 | b2b | bp | PASS | 792 | 4587 | 0 (0) |
| icarus | n2 | illegal | clean | PASS | 458 | 1102 | 0 (0) |
| icarus | n2 | fpexc | stuck | PASS | 952 | 11228 | 0 (0) |
| verilator | n4 | directed | clean | PASS | 244 | 176 | 0 (0) |
| verilator | n4 | mixed | stall | PASS | 2838 | 2588 | 0 (0) |
| verilator | n4 | mask | phase | PASS | 763 | 1052 | 0 (0) |
| verilator | n4 | red | stall | PASS | 2274 | 2314 | 0 (0) |
| verilator | n4 | reset | rst_stall | PASS | 2231 | 38 | 20 (14) |
| verilator | n4 | b2b | bp | PASS | 1423 | 4786 | 0 (0) |
| verilator | n4 | illegal | clean | PASS | 458 | 658 | 0 (0) |
| verilator | n4 | fpexc | stuck | PASS | 1900 | 9531 | 0 (0) |
| verilator | n4 | long | clean | PASS | 89917 | 24981 | 0 (0) |
| icarus | n4 | directed | clean | PASS | 244 | 176 | 0 (0) |
| icarus | n4 | mixed | stall | PASS | 2838 | 2588 | 0 (0) |
| icarus | n4 | mask | phase | PASS | 763 | 1052 | 0 (0) |
| icarus | n4 | red | stall | PASS | 2274 | 2314 | 0 (0) |
| icarus | n4 | reset | rst_stall | PASS | 2231 | 38 | 20 (14) |
| icarus | n4 | b2b | bp | PASS | 1423 | 4786 | 0 (0) |
| icarus | n4 | illegal | clean | PASS | 458 | 658 | 0 (0) |
| icarus | n4 | fpexc | stuck | PASS | 1900 | 10369 | 0 (0) |
