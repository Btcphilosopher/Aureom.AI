# Module 03 mutation testing

32 / 32 mutants killed (configuration `n4`, 12 regression runs per mutant, first failing run shown).

| id | injected bug | result | first detection |
|---|---|---|---|
| M01 | tail: one element too many | KILLED | directed/s1/clean: ERROR @cyc 13: result beat header: cmd #0 got tid 0 beat 0 last 1 mask 0011, exp tid 0 beat 0 last 1 mask 0001 |
| M02 | framing: last beat off by one | KILLED | directed/s1/clean: ERROR @cyc 15: result beat header: cmd #2 got tid 2 beat 0 last 0 mask 1111, exp tid 2 beat 0 last 1 mask 1111 |
| M03 | mask ignored | KILLED | directed/s1/clean: ERROR @cyc 48: result beat header: cmd #19 got tid d3 beat 0 last 0 mask 1111, exp tid d3 beat 0 last 0 mask 1010 |
| M04 | beat released while a lane is held | KILLED | mixed/s1/stall: [95000] %Fatal: hpc_varray_issue.sv:283: Assertion failed in TOP.tb_hpc_vector_array.dut.u_issue.unnamedblk5: hpc_varray_issue: beat release |
| M05 | per-lane acceptance not cleared | KILLED | directed/s1/clean: TEST FAILED: no progress for 20000 cycles (deadlock?) |
| M06 | element re-issued to a lane (duplicate) | KILLED | mixed/s1/stall: [185000] %Fatal: hpc_varray_collect.sv:251: Assertion failed in TOP.tb_hpc_vector_array.dut.u_collect.unnamedblk3: hpc_varray_collect: lane  |
| M07 | broadcast select | KILLED | directed/s1/clean: ERROR @cyc 55: cmd #22 beat 0 lane 0: got 4e927835/01 exp d6df9cd2/01 |
| M08 | illegal command marked active | KILLED | directed/s1/clean: [585000] %Fatal: hpc_varray_collect.sv:251: Assertion failed in TOP.tb_hpc_vector_array.dut.u_collect.unnamedblk3: hpc_varray_collect: lane  |
| M09 | tracking-queue backpressure ignored | KILLED | directed/s1/clean: [695000] %Fatal: hpc_varray_fifo.sv:71: Assertion failed in TOP.tb_hpc_vector_array.dut.u_trk: hpc_varray_fifo TOP.tb_hpc_vector_array.dut.u |
| M10 | element offered to a held lane (hold contract) | KILLED | mixed/s1/stall: ERROR @cyc 10: element offered to a held lane |
| M11 | collect when ANY lane is ready (stalled lane result dropped) | KILLED | mixed/s1/stall: [335000] %Fatal: hpc_varray_collect.sv:251: Assertion failed in TOP.tb_hpc_vector_array.dut.u_collect.unnamedblk3: hpc_varray_collect: lane  |
| M12 | inactive element data leaks | KILLED | directed/s1/clean: ERROR @cyc 52: cmd #20 beat 1 lane 0: got 80000000/00 exp 00000000/00 |
| M13 | inactive element flags leak | KILLED | directed/s1/clean: ERROR @cyc 52: cmd #20 beat 1 lane 0: got 00000000/03 exp 00000000/00 |
| M14 | flags leak into the next command | KILLED | directed/s1/clean: ERROR @cyc 25: completion cmd #6: got tid 6 fl 11 ill 0 cnt 1 red 0 res 00000000, exp tid 6 fl 00 ill 0 cnt 1 red 0 res 00000000 |
| M15 | active-element count | KILLED | directed/s1/clean: ERROR @cyc 18: completion cmd #3: got tid 3 fl 01 ill 0 cnt 2 red 0 res 00000000, exp tid 3 fl 01 ill 0 cnt 5 red 0 res 00000000 |
| M16 | result not retired on handover (duplicate) | KILLED | directed/s1/clean: ERROR @cyc 35: result beat header: cmd #12 got tid b beat 3 last 1 mask 0001, exp tid 52 beat 0 last 1 mask 0001 |
| M17 | results taken from inactive lanes (misassociation) | KILLED | directed/s1/clean: [515000] %Fatal: hpc_varray_collect.sv:251: Assertion failed in TOP.tb_hpc_vector_array.dut.u_collect.unnamedblk3: hpc_varray_collect: lane  |
| M18 | beat index not advanced | KILLED | directed/s1/clean: ERROR @cyc 17: result beat header: cmd #3 got tid 3 beat 0 last 1 mask 0001, exp tid 3 beat 1 last 1 mask 0001 |
| M19 | completion overtakes its last result beat | KILLED | mixed/s1/stall: ERROR @cyc 55: completion of cmd #2 before its result beat 7 |
| M20 | payload not zeroed when not valid | KILLED | directed/s1/clean: ERROR @cyc 35: result payload not zero while res_valid = 0 |
| M21 | tree bypass forwards the wrong child | KILLED | directed/s1/clean: ERROR @cyc 85: completion cmd #26: got tid 1a fl 01 ill 0 cnt 19 red 1 res c32c0183, exp tid 1a fl 01 ill 0 cnt 19 red 1 res c32c059a |
| M22 | absent child replaced by an identity add | KILLED | directed/s1/clean: [765000] %Fatal: hpc_varray_reduce.sv:259: Assertion failed in TOP.tb_hpc_vector_array.dut.u_reduce.g_red.g_lvl[0].g_node[1]: hpc_varray_red |
| M23 | initial accumulator value ignored | KILLED | directed/s1/clean: ERROR @cyc 100: completion cmd #27: got tid 1b fl 01 ill 0 cnt 19 red 1 res 43c2dde8, exp tid 1b fl 01 ill 0 cnt 19 red 1 res 440c705c |
| M24 | accumulator recurrence hazard | KILLED | directed/s1/clean: [705000] %Fatal: hpc_varray_reduce.sv:441: Assertion failed in TOP.tb_hpc_vector_array.dut.u_reduce.g_red: hpc_varray_reduce: item reached t |
| M25 | completion credits not consumed | KILLED | mixed/s1/stall: [2775000] %Fatal: hpc_varray_fifo.sv:71: Assertion failed in TOP.tb_hpc_vector_array.dut.u_cplq: hpc_varray_fifo TOP.tb_hpc_vector_array.dut |
| M26 | accumulator-add flags lost | KILLED | mixed/s1/stall: ERROR @cyc 1875: completion cmd #118: got tid 76 fl 00 ill 0 cnt 1 red 1 res c30f3bcc, exp tid 76 fl 01 ill 0 cnt 1 red 1 res c30f3bcc |
| M27 | tree-add flags lost | KILLED | mixed/s1/stall: ERROR @cyc 570: completion cmd #34: got tid 1c fl 00 ill 0 cnt 4 red 1 res 7f800000, exp tid 1c fl 05 ill 0 cnt 4 red 1 res 7f800000 |
| M28 | illegal reduction returns a value | KILLED | illegal/s1/clean: ERROR @cyc 19: completion cmd #0: got tid 11 fl 00 ill 1 cnt 0 red 1 res be059948, exp tid 11 fl 00 ill 1 cnt 0 red 1 res 00000000 |
| M29 | queue pointer wrap | KILLED | directed/s1/clean: ERROR @cyc 24: result beat header: cmd #6 got tid 9 beat 0 last 0 mask 1111, exp tid 6 beat 0 last 1 mask 0001 |
| M31 | completion token bypasses an in-flight reduction | KILLED | directed/s1/clean: ERROR @cyc 99: completion cmd #27: got tid b4 fl 00 ill 0 cnt 5 red 0 res 00000000, exp tid 1b fl 01 ill 0 cnt 19 red 1 res 440c705c |
| M32 | bypassed token counted as in flight | KILLED | directed/s1/clean: ERROR @cyc 197: busy_o still high after the test drained |
| M30 | busy_o low while a completion is pending | KILLED | directed/s1/clean: ERROR @cyc 142: busy_o low while commands are outstanding |
