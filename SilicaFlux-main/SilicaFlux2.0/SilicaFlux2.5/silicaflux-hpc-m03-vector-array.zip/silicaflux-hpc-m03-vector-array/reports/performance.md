# Module 03 measured performance

Cycle-accurate RTL simulation (Verilator 5.020) of the default configuration (lane latencies FADD 3 / FMUL 3 / FMA 4 / MISC 1, `LANE_ROB_DEPTH=8`, `TRK_DEPTH=8`, `CMD_DEPTH=4`, `CPL_DEPTH=4`, `RED_LAT=3`).  Every run passes the self-checking testbench (bit-exact against SoftFloat-3e).  Counter values come from the array's own performance counters, which the testbench checks against its own counts.  **These are cycle counts; no clock frequency is implied** (section 6 states its assumptions explicitly).

## 1. Isolated latency (cycles)

One command of one beat (vl = NUM_LANES) at a time (`+GAP=30`), no backpressure.  *beat to result*: operand beat accepted in cycle t, result beat handed over in cycle t + x.  *beat to completion*: last operand beat accepted to completion handed over.

| operation | expected beat to result | N=1 beat→result / beat→cpl | N=2 beat→result / beat→cpl | N=4 beat→result / beat→cpl | N=8 beat→result / beat→cpl | N=16 beat→result / beat→cpl |
|---|---|---|---|---|---|---|
| FMV | 3 | 3 / 4 | 3 / 4 | 3 / 4 | 3 / 4 | 3 / 4 |
| FADD | 5 | 5 / 6 | 5 / 6 | 5 / 6 | 5 / 6 | 5 / 6 |
| FMUL | 5 | 5 / 6 | 5 / 6 | 5 / 6 | 5 / 6 | 5 / 6 |
| FMADD | 6 | 6 / 7 | 6 / 7 | 6 / 7 | 6 / 7 | 6 / 7 |
| FMV sum-reduction | - | - / 7 | - / 10 | - / 13 | - / 16 | - / 19 |
| FMUL sum-reduction | - | - / 9 | - / 12 | - / 15 | - / 18 | - / 21 |

Elementwise beat to result = lane latency (LAT + 1, Module 02) + 1 collector register.  The completion record travels through the reduction unit's tree pipeline to stay in order behind reductions, so its latency grows with log2(N) x RED_LAT.

## 2. Cycles per vector operation (back-to-back FMADD commands, no stalls)

64 commands of the same vector length issued back to back.  *measured* = result-stream cycles per command in steady state ((t_last_result(cmd 63) - t_last_result(cmd 7)) / 56); *ideal* = ceil(vl / N) beats at one beat per cycle.

**NUM_LANES = 1**

| vl | beats | ideal cycles/op | measured cycles/op | elements/cycle | lane utilisation |
|---|---|---|---|---|---|
| 1 | 1 | 1 | 1.00 | 1.00 | 1.000 |
| 1 | 1 | 1 | 1.00 | 1.00 | 1.000 |
| 1 | 1 | 1 | 1.00 | 1.00 | 1.000 |
| 2 | 2 | 2 | 2.00 | 1.00 | 1.000 |
| 4 | 4 | 4 | 4.00 | 1.00 | 1.000 |
| 16 | 16 | 16 | 16.00 | 1.00 | 1.000 |
| 64 | 64 | 64 | 64.00 | 1.00 | 1.000 |

**NUM_LANES = 2**

| vl | beats | ideal cycles/op | measured cycles/op | elements/cycle | lane utilisation |
|---|---|---|---|---|---|
| 1 | 1 | 1 | 1.00 | 1.00 | 0.500 |
| 1 | 1 | 1 | 1.00 | 1.00 | 0.500 |
| 2 | 1 | 1 | 1.00 | 2.00 | 1.000 |
| 3 | 2 | 2 | 2.00 | 1.50 | 0.750 |
| 8 | 4 | 4 | 4.00 | 2.00 | 1.000 |
| 32 | 16 | 16 | 16.00 | 2.00 | 1.000 |
| 128 | 64 | 64 | 64.00 | 2.00 | 1.000 |

**NUM_LANES = 4**

| vl | beats | ideal cycles/op | measured cycles/op | elements/cycle | lane utilisation |
|---|---|---|---|---|---|
| 1 | 1 | 1 | 1.00 | 1.00 | 0.250 |
| 2 | 1 | 1 | 1.00 | 2.00 | 0.500 |
| 4 | 1 | 1 | 1.00 | 4.00 | 1.000 |
| 5 | 2 | 2 | 2.00 | 2.50 | 0.625 |
| 16 | 4 | 4 | 4.00 | 4.00 | 1.000 |
| 64 | 16 | 16 | 16.00 | 4.00 | 1.000 |
| 256 | 64 | 64 | 64.00 | 4.00 | 1.000 |

**NUM_LANES = 8**

| vl | beats | ideal cycles/op | measured cycles/op | elements/cycle | lane utilisation |
|---|---|---|---|---|---|
| 1 | 1 | 1 | 1.00 | 1.00 | 0.125 |
| 4 | 1 | 1 | 1.00 | 4.00 | 0.500 |
| 8 | 1 | 1 | 1.00 | 8.00 | 1.000 |
| 9 | 2 | 2 | 2.00 | 4.50 | 0.562 |
| 32 | 4 | 4 | 4.00 | 8.00 | 1.000 |
| 128 | 16 | 16 | 16.00 | 8.00 | 1.000 |
| 512 | 64 | 64 | 64.00 | 8.00 | 1.000 |

**NUM_LANES = 16**

| vl | beats | ideal cycles/op | measured cycles/op | elements/cycle | lane utilisation |
|---|---|---|---|---|---|
| 1 | 1 | 1 | 1.00 | 1.00 | 0.062 |
| 8 | 1 | 1 | 1.00 | 8.00 | 0.500 |
| 16 | 1 | 1 | 1.00 | 16.00 | 1.000 |
| 17 | 2 | 2 | 2.00 | 8.50 | 0.531 |
| 64 | 4 | 4 | 4.00 | 16.00 | 1.000 |
| 256 | 16 | 16 | 16.00 | 16.00 | 1.000 |
| 1024 | 64 | 64 | 64.00 | 16.00 | 1.000 |

## 3. Sustained streaming throughput and utilisation (counters)

One elementwise FMADD stream of 32 commands x vl = 64 x N, and one FMUL sum-reduction (dot product) stream of 16 commands x vl = 64 x N.  Over the whole run (fill and drain included): accepted / completed elements per cycle = ELEM_IN / CYCLES and ELEM_OUT / CYCLES; lane utilisation = ELEM_IN / (N x BUSY).

| N | workload | cycles | busy | elements | accepted el./cycle | completed el./cycle | lane utilisation | ideal el./cycle |
|---|---|---|---|---|---|---|---|---|
| 1 | elementwise FMADD | 2096 | 2056 | 2048 | 0.98 | 0.98 | 0.996 | 1.00 |
| 1 | dot product (FMUL + sum) | 3120 | 3080 | 1024 | 0.33 | 0.33 | 0.332 | 0.33 |
| 2 | elementwise FMADD | 2096 | 2056 | 4096 | 1.95 | 1.95 | 0.996 | 2.00 |
| 2 | dot product (FMUL + sum) | 3123 | 3083 | 2048 | 0.66 | 0.66 | 0.332 | 0.67 |
| 4 | elementwise FMADD | 2096 | 2056 | 8192 | 3.91 | 3.91 | 0.996 | 4.00 |
| 4 | dot product (FMUL + sum) | 3126 | 3086 | 4096 | 1.31 | 1.31 | 0.332 | 1.33 |
| 8 | elementwise FMADD | 2096 | 2056 | 16384 | 7.82 | 7.82 | 0.996 | 8.00 |
| 8 | dot product (FMUL + sum) | 3129 | 3089 | 8192 | 2.62 | 2.62 | 0.331 | 2.67 |
| 16 | elementwise FMADD | 2096 | 2056 | 32768 | 15.63 | 15.63 | 0.996 | 16.00 |
| 16 | dot product (FMUL + sum) | 3132 | 3092 | 16384 | 5.23 | 5.23 | 0.331 | 5.33 |

Ideal for the dot product is N / RED_LAT element per cycle: the FP32 accumulator has one add in flight (docs/REDUCTION.md).

## 4. Stall and backpressure behaviour (FMADD, 32 commands x vl = 16 x N)

Counter definitions: `docs/PERFORMANCE.md` section 1.  STALL_LANE = cycles an operand beat waited for at least one lane; LANE_STALL = lane-cycles of that waiting; COLL_WAIT = cycles the head beat waited for lane results; RES_BP = cycles a result beat waited for the consumer.

| N | profile | cycles | el./cycle | lane util. | STALL_LANE | LANE_STALL | OPND_STARVE | COLL_WAIT | RES_BP |
|---|---|---|---|---|---|---|---|---|---|
| 1 | clean | 560 | 0.91 | 0.985 | 0 | 0 | 0 | 4 | 0 |
| 1 | stall | 1040 | 0.49 | 0.513 | 180 | 180 | 238 | 96 | 405 |
| 1 | phase | 816 | 0.63 | 0.660 | 256 | 256 | 0 | 226 | 53 |
| 1 | stuck | 8531 | 0.06 | 0.060 | 7952 | 7952 | 18 | 1727 | 82 |
| 1 | bp | 4732 | 0.11 | 0.109 | 56 | 56 | 0 | 4 | 4165 |
| 2 | clean | 560 | 1.83 | 0.985 | 0 | 0 | 0 | 4 | 0 |
| 2 | stall | 1144 | 0.90 | 0.464 | 308 | 342 | 253 | 240 | 421 |
| 2 | phase | 1072 | 0.96 | 0.496 | 512 | 512 | 0 | 510 | 52 |
| 2 | stuck | 8398 | 0.12 | 0.061 | 7812 | 7812 | 25 | 1755 | 81 |
| 2 | bp | 4321 | 0.24 | 0.120 | 107 | 110 | 0 | 4 | 3758 |
| 4 | clean | 560 | 3.66 | 0.985 | 0 | 0 | 0 | 4 | 0 |
| 4 | stall | 1299 | 1.58 | 0.408 | 527 | 694 | 206 | 493 | 395 |
| 4 | phase | 1072 | 1.91 | 0.496 | 512 | 1024 | 0 | 510 | 52 |
| 4 | stuck | 8398 | 0.24 | 0.061 | 7812 | 7812 | 25 | 1755 | 81 |
| 4 | bp | 4518 | 0.45 | 0.114 | 212 | 233 | 0 | 5 | 3956 |
| 8 | clean | 560 | 7.31 | 0.985 | 0 | 0 | 0 | 4 | 0 |
| 8 | stall | 1493 | 2.74 | 0.353 | 755 | 1367 | 176 | 702 | 415 |
| 8 | phase | 1072 | 3.82 | 0.496 | 512 | 2048 | 0 | 510 | 52 |
| 8 | stuck | 8398 | 0.49 | 0.061 | 7812 | 7812 | 25 | 1755 | 81 |
| 8 | bp | 4286 | 0.96 | 0.121 | 338 | 440 | 0 | 4 | 3725 |
| 16 | clean | 560 | 14.63 | 0.985 | 0 | 0 | 0 | 4 | 0 |
| 16 | stall | 1794 | 4.57 | 0.292 | 1010 | 2806 | 222 | 1074 | 458 |
| 16 | phase | 1072 | 7.64 | 0.496 | 512 | 4096 | 0 | 510 | 52 |
| 16 | stuck | 8398 | 0.98 | 0.061 | 7812 | 7812 | 25 | 1755 | 81 |
| 16 | bp | 4180 | 1.96 | 0.124 | 507 | 928 | 0 | 5 | 3606 |

Profiles: `clean` = no stalls; `stall` = random gaps + 25 % lane holds + 45 % result backpressure; `phase` = lanes held on alternating cycles (out of phase); `stuck` = one lane held 15/16 of the time; `bp` = result ready 12 %.

## 5. Theoretical peak FP32 throughput (NOT a benchmark)

Assumptions, all explicit: (a) initiation interval 1 per lane for FMADD, **as measured in section 2/3** (one beat of N elements per cycle when nothing stalls); (b) one FMA = 2 FLOP; (c) the operand stream delivers one full beat every cycle and the result stream is never backpressured; (d) the clock values below.  Peak = 2 x N x f.  The 25 MHz row is the ULX3S oscillator and SilicaFlux-V's FPGA clock; the post-route row uses nextpnr-ecp5's static-timing Fmax estimate for this design (one seed, speed grade 6) where place-and-route succeeded.  Nothing was measured on hardware.  Required operand + result bandwidth at that rate is 16 B per element (a, b, c in, result out).

| N | FLOP/cycle | peak at 25 MHz | streaming bandwidth needed at 25 MHz | post-route Fmax (MHz) | peak at that Fmax |
|---|---|---|---|---|---|
| 1 | 2 | 50 MFLOP/s | 0.40 GB/s | 32.21 | 64 MFLOP/s |
| 2 | 4 | 100 MFLOP/s | 0.80 GB/s | 32.15 | 129 MFLOP/s |
| 4 | 8 | 200 MFLOP/s | 1.60 GB/s | 32.15 | 257 MFLOP/s |
| 8 | 16 | 400 MFLOP/s | 3.20 GB/s | 31.58 | 505 MFLOP/s |
| 16 | 32 | 800 MFLOP/s | 6.40 GB/s | n/a (no routed result) | - |

For comparison, the SilicaFlux DataFabric SFB bus is 32 bits wide: at 25 MHz it moves 0.1 GB/s, so a DataFabric-fed array is operand-bandwidth bound long before the lanes saturate (elementwise FMA has an arithmetic intensity of 2 FLOP / 16 B).

