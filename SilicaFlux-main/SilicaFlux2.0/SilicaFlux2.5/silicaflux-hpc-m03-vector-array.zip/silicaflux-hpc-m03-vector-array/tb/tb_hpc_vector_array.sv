// =============================================================================
// SilicaFlux-HPC :: tb_hpc_vector_array -- self-checking vector-array testbench
//
// Streams a test (ref/gen_stim.py: cmds.txt, beats.txt) into hpc_vector_array
// and checks every output against the independent reference
// (ref/varray_ref, SoftFloat-3e: res.txt, cpl.txt), in order:
//   * result beats: tid, beat index, last, active mask, every element's data
//     and flags (inactive positions must be data 0 / flags 0 / mask 0)
//   * completion records: tid, aggregated flags, illegal, active-element
//     count, reduction flag and reduction result
//   * no drop / no duplicate / no reordering: the expected streams are
//     consumed strictly in order and must be exhausted at the end
//   * a completion is never presented before the last result beat of its
//     command has been handed over
//   * valid/ready protocol: payload stable and valid held while stalled,
//     payload zero while not valid, no ready / valid during reset, no
//     cmd_ready in the first cycle after reset
//   * busy_o high whenever work is outstanding, low at the end
//   * no X/Z on any output (4-state simulators)
//   * performance counters equal the testbench's own counts (no-reset runs)
//
// Stimulus timing is driven by an xorshift generator (identical on Verilator
// and Icarus): command/operand valid gaps, result/completion backpressure,
// per-lane hold patterns and segment-wise asynchronous reset injection.
//
// Plusargs
//   +DIR=path      test directory (cmds.txt beats.txt res.txt cpl.txt)
//   +SEED=n        timing seed
//   +PCMD=% +POPND=% +PRES=% +PCPL=%   valid / ready probabilities
//   +HOLD=m +PHOLD=%  lane hold mode (0 none, 1 random, 2 bursts,
//                  3 one mostly-held lane, 4 out-of-phase alternation)
//   +RESET=1 +RSTWIN=n   inject resets within n cycles of each segment start
//   +GAP=n         wait for each completion + n idle cycles before the next
//                  command (isolated latency measurement)
//   +LATLOG=file   per-command timestamps for scripts/characterize.py
//   +MAXCYC=n +QUIET
// Define GATE to simulate a synthesized netlist (no internal probes).
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module tb_hpc_vector_array;
  parameter int NUM_LANES      = 2;
  parameter int VL_W           = 16;
  parameter int TID_W          = 8;
  parameter int CMD_DEPTH      = 4;
  parameter int TRK_DEPTH      = 8;
  parameter int CPL_DEPTH      = 4;
  parameter bit RED_EN         = 1'b1;
  parameter int RED_LAT        = 3;
  parameter bit PERF_EN        = 1'b1;
  parameter int LANE_ROB_DEPTH = 8;
  parameter int LAT_FADD       = 3;
  parameter int LAT_FMUL       = 3;
  parameter int LAT_FMA        = 4;
  parameter int LAT_MISC       = 1;
  parameter int LAT_IMUL       = 2;
  parameter bit EN_FCMP        = 1'b1;
  parameter bit EN_INT         = 1'b1;

  localparam int N    = NUM_LANES;
  localparam int CW   = 32;
  localparam int NPC  = hpc_varray_pkg::PC_N;
  localparam int MAXC = 1 << 17;              // per-command timestamp slots

  // ------------------------------------------------------------ DUT wiring
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  logic               cmd_valid = 1'b0;
  wire                cmd_ready;
  logic [4:0]         cmd_op = '0;
  logic [2:0]         cmd_rm = '0;
  logic [VL_W-1:0]    cmd_vl = '0;
  logic               cmd_vm = 1'b0;
  logic [2:0]         cmd_bcast = '0;
  logic [31:0]        cmd_scalar = '0;
  logic               cmd_red = 1'b0;
  logic [TID_W-1:0]   cmd_tid = '0;
  logic               opnd_valid = 1'b0;
  wire                opnd_ready;
  logic [N*32-1:0]    opnd_a = '0, opnd_b = '0, opnd_c = '0;
  logic [N-1:0]       opnd_mask = '0;
  wire                res_valid;
  logic               res_ready = 1'b0;
  wire [N*32-1:0]     res_data;
  wire [N*5-1:0]      res_flags;
  wire [N-1:0]        res_mask;
  wire [TID_W-1:0]    res_tid;
  wire [VL_W-1:0]     res_beat;
  wire                res_last;
  wire                cpl_valid;
  logic               cpl_ready = 1'b0;
  wire [TID_W-1:0]    cpl_tid;
  wire [4:0]          cpl_flags;
  wire                cpl_illegal;
  wire [VL_W-1:0]     cpl_count;
  wire                cpl_red;
  wire [31:0]         cpl_result;
  logic [N-1:0]       lane_hold = '0;
  wire                busy;
  logic               perf_clear = 1'b0;
  wire [NPC*CW-1:0]   perf_cnt;

`ifdef GATE
  hpc_vector_array dut (
`else
  hpc_vector_array #(
    .NUM_LANES(N), .VL_W(VL_W), .TID_W(TID_W), .CMD_DEPTH(CMD_DEPTH),
    .TRK_DEPTH(TRK_DEPTH), .CPL_DEPTH(CPL_DEPTH), .RED_EN(RED_EN), .RED_LAT(RED_LAT),
    .PERF_EN(PERF_EN), .PERF_CW(CW), .LANE_ROB_DEPTH(LANE_ROB_DEPTH),
    .LAT_FADD(LAT_FADD), .LAT_FMUL(LAT_FMUL), .LAT_FMA(LAT_FMA), .LAT_MISC(LAT_MISC),
    .LAT_IMUL(LAT_IMUL), .EN_FCMP(EN_FCMP), .EN_INT(EN_INT)
  ) dut (
`endif
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_op_i(cmd_op), .cmd_rm_i(cmd_rm),
    .cmd_vl_i(cmd_vl), .cmd_vm_i(cmd_vm), .cmd_bcast_i(cmd_bcast), .cmd_scalar_i(cmd_scalar),
    .cmd_red_i(cmd_red), .cmd_tid_i(cmd_tid),
    .opnd_valid_i(opnd_valid), .opnd_ready_o(opnd_ready), .opnd_a_i(opnd_a),
    .opnd_b_i(opnd_b), .opnd_c_i(opnd_c), .opnd_mask_i(opnd_mask),
    .res_valid_o(res_valid), .res_ready_i(res_ready), .res_data_o(res_data),
    .res_flags_o(res_flags), .res_mask_o(res_mask), .res_tid_o(res_tid),
    .res_beat_o(res_beat), .res_last_o(res_last),
    .cpl_valid_o(cpl_valid), .cpl_ready_i(cpl_ready), .cpl_tid_o(cpl_tid),
    .cpl_flags_o(cpl_flags), .cpl_illegal_o(cpl_illegal), .cpl_count_o(cpl_count),
    .cpl_red_o(cpl_red), .cpl_result_o(cpl_result),
    .lane_hold_i(lane_hold), .busy_o(busy),
    .perf_clear_i(perf_clear), .perf_cnt_o(perf_cnt)
  );

  // ------------------------------------------------------------ configuration
  string dir, latlog;
  int    seed, p_cmd, p_opnd, p_res, p_cpl, hold_mode, p_hold, rst_en, rst_win, gap;
  longint max_cyc;
  bit    quiet;
  int    fc, fb, fr, fp, fl;

  // ------------------------------------------------------------ helpers
  logic [31:0] rng;
  function automatic logic [31:0] xs(input logic [31:0] x);
    logic [31:0] y;
    y = x ^ (x << 13);
    y = y ^ (y >> 17);
    y = y ^ (y << 5);
    xs = y;
  endfunction
  // X/Z detection by reduction XOR (Icarus 12 returns 1 from $isunknown() on a
  // concatenation even when every bit is known, so $isunknown is not used)
  function automatic logic has_x(input logic [2047:0] v);
    has_x = ((^v) === 1'bx);
  endfunction
  function automatic int pct(input int p);   // 1 with probability p %
    rng = xs(rng);
    pct = (int'(rng % 100) < p) ? 1 : 0;
  endfunction
  function automatic int rnd(input int m);   // 0 .. m-1
    rng = xs(rng);
    rnd = int'(rng % m);
  endfunction

  longint cyc = 0;
  int n_err = 0;
  task automatic fail(input string msg);
    n_err = n_err + 1;
    if (n_err <= 20) $display("ERROR @cyc %0d: %s", cyc, msg);
    if (n_err > 200) begin
      $display("TEST FAILED (too many errors)");
      $finish;
    end
  endtask

  // ------------------------------------------------------------ streams
  // command stream
  bit          c_have, c_eof;
  logic [31:0] c_seg, c_idx, c_op, c_rm, c_vl, c_vm, c_bc, c_sc, c_red, c_tid;
  // operand-beat stream
  bit          b_have, b_eof;
  logic [31:0] b_seg, b_idx, b_mask;
  logic [N*32-1:0] b_a, b_b, b_c;
  // expected result beats
  bit          r_have, r_eof;
  logic [31:0] r_seg, r_idx, r_tid, r_beat, r_last, r_mask;
  logic [N*32-1:0] r_d;
  logic [N*5-1:0]  r_f;
  // expected completions
  bit          p_have, p_eof;
  logic [31:0] p_seg, p_idx, p_tid, p_flags, p_ill, p_count, p_red, p_result;

  task automatic load_cmd();
    int rc;
    rc = $fscanf(fc, "%h %h %h %h %h %h %h %h %h %h\n", c_seg, c_idx, c_op, c_rm, c_vl, c_vm,
                 c_bc, c_sc, c_red, c_tid);
    c_have = (rc == 10);
    c_eof  = !c_have;
  endtask
  task automatic load_beat();
    int rc;
    logic [31:0] w;
    rc = $fscanf(fb, "%h %h %h", b_seg, b_idx, b_mask);
    b_have = (rc == 3);
    b_eof  = !b_have;
    if (b_have)
      for (int l = 0; l < N; l++) begin
        rc = $fscanf(fb, "%h", w); b_a[l*32 +: 32] = w;
        rc = $fscanf(fb, "%h", w); b_b[l*32 +: 32] = w;
        rc = $fscanf(fb, "%h", w); b_c[l*32 +: 32] = w;
      end
  endtask
  task automatic load_res();
    int rc;
    logic [31:0] w;
    rc = $fscanf(fr, "%h %h %h %h %h %h", r_seg, r_idx, r_tid, r_beat, r_last, r_mask);
    r_have = (rc == 6);
    r_eof  = !r_have;
    if (r_have)
      for (int l = 0; l < N; l++) begin
        rc = $fscanf(fr, "%h", w); r_d[l*32 +: 32] = w;
        rc = $fscanf(fr, "%h", w); r_f[l*5 +: 5]   = w[4:0];
      end
  endtask
  task automatic load_cpl();
    int rc;
    rc = $fscanf(fp, "%h %h %h %h %h %h %h %h\n", p_seg, p_idx, p_tid, p_flags, p_ill, p_count,
                 p_red, p_result);
    p_have = (rc == 8);
    p_eof  = !p_have;
  endtask

  // ------------------------------------------------------------ state
  longint cyc_since_rst = 0, last_progress = 0, perf_t0 = 0;
  int     rst_cnt = 4;
  logic [31:0] cur_seg = 0;
  longint seg_start = 0, rst_at = -1;
  bit     seg_rst_done = 0;
  bit     seg_done = 0;
  int     n_resets = 0, n_rst_mid = 0;
  longint n_cmd_acc = 0, n_beat_acc = 0, n_res = 0, n_cpl = 0, n_elem = 0;
  longint n_res_bp = 0, n_cpl_bp = 0, n_busy = 0, n_cmd_seg = 0, n_cpl_seg = 0;
  bit     prev_res_hold = 0, prev_cpl_hold = 0;
  logic [N*32-1:0] pr_data; logic [N*5-1:0] pr_flags; logic [N-1:0] pr_mask;
  logic [TID_W-1:0] pr_tid; logic [VL_W-1:0] pr_beat; logic pr_last;
  logic [TID_W-1:0] pc_tid; logic [4:0] pc_flags; logic pc_ill; logic [VL_W-1:0] pc_count;
  logic pc_red; logic [31:0] pc_result;
  int     hold_cnt [0:N-1];
  int     stuck_lane = 0;
  bit     gap_wait = 0;
  longint gap_until = 0;
  bit     done = 0;
  int     drain = 0;
  // timestamps
  longint t_cmd [0:MAXC-1], t_b0 [0:MAXC-1], t_bl [0:MAXC-1], t_r0 [0:MAXC-1],
          t_rl [0:MAXC-1], t_cpl[0:MAXC-1];
  int     vl_of [0:MAXC-1];
  bit     red_of[0:MAXC-1];
  // coverage (internal probes)
  longint cv_partial = 0, cv_mixed_out = 0, cv_trk_full = 0, cv_cq_full = 0, cv_cpl_block = 0,
          cv_red_space = 0, cv_rob_full = 0, cv_masked_sent = 0, cv_hold_need = 0,
          cv_red_cred = 0;

  function automatic logic seg_ok(input logic [31:0] s);
    seg_ok = (s == cur_seg);
  endfunction

  // ------------------------------------------------------------ main process
  always @(posedge clk) begin : main
    cyc = cyc + 1;
    if (cyc > max_cyc) begin
      $display("TEST FAILED: timeout after %0d cycles (cmd %0d/%0d beat %0d res %0d cpl %0d)",
               cyc, n_cmd_acc, c_idx, n_beat_acc, n_res, n_cpl);
      $finish;
    end

    if (!rst_n) begin
      // ======================================================== in reset
      cyc_since_rst = 0;
      if (cmd_ready || opnd_ready || res_valid || cpl_valid || busy)
        fail("ready/valid/busy asserted during reset");
      // the array must ignore the inputs during reset: drive garbage
      rng = xs(rng);
      cmd_valid  <= rng[0];
      opnd_valid <= rng[1];
      cmd_op     <= rng[6:2];
      res_ready  <= rng[7];
      cpl_ready  <= rng[8];
      lane_hold  <= N'(rng[31:16]);
      prev_res_hold = 0;
      prev_cpl_hold = 0;
      if (rst_cnt > 0) rst_cnt = rst_cnt - 1;
      if (rst_cnt == 0) begin
        rst_n <= 1'b1;                       // synchronous de-assertion
        cmd_valid  <= 1'b0;
        opnd_valid <= 1'b0;
      end
    end else begin
      // ======================================================== running
      cyc_since_rst = cyc_since_rst + 1;
      if (cyc_since_rst == 1) begin
        if (cmd_ready) fail("cmd_ready high in first cycle after reset");
        perf_t0 = cyc;
      end

      // ---------------------------------------------------- X checks
      if (has_x({cmd_ready, opnd_ready, res_valid, cpl_valid, busy}))
        fail($sformatf("X/Z on control output %b%b%b%b%b", cmd_ready, opnd_ready, res_valid, cpl_valid, busy));
      if (has_x({res_data, res_flags, res_mask, res_tid, res_beat, res_last}))
        fail($sformatf("X/Z on result payload d=%h f=%h m=%b t=%h b=%h l=%b", res_data, res_flags, res_mask, res_tid, res_beat, res_last));
      if (has_x({cpl_tid, cpl_flags, cpl_illegal, cpl_count, cpl_red, cpl_result}))
        fail("X/Z on completion payload");
      if (PERF_EN && has_x(2048'(perf_cnt))) fail("X/Z on performance counters");

      // ---------------------------------------------------- protocol checks
      if (prev_res_hold) begin
        if (!res_valid) fail("res_valid dropped without handshake");
        else if (res_data !== pr_data || res_flags !== pr_flags || res_mask !== pr_mask ||
                 res_tid !== pr_tid || res_beat !== pr_beat || res_last !== pr_last)
          fail("result payload changed while stalled");
      end
      if (prev_cpl_hold) begin
        if (!cpl_valid) fail("cpl_valid dropped without handshake");
        else if (cpl_tid !== pc_tid || cpl_flags !== pc_flags || cpl_illegal !== pc_ill ||
                 cpl_count !== pc_count || cpl_red !== pc_red || cpl_result !== pc_result)
          fail("completion payload changed while stalled");
      end
      if (!res_valid && (res_data != 0 || res_flags != 0 || res_mask != 0 || res_tid != 0 ||
                         res_beat != 0 || res_last))
        fail("result payload not zero while res_valid = 0");
      if (!cpl_valid && (cpl_tid != 0 || cpl_flags != 0 || cpl_illegal || cpl_count != 0 ||
                         cpl_red || cpl_result != 0))
        fail("completion payload not zero while cpl_valid = 0");
      if ((n_cmd_seg != n_cpl_seg) && !busy) fail("busy_o low while commands are outstanding");
      if (busy) n_busy = n_busy + 1;
      if (res_valid && !res_ready) n_res_bp = n_res_bp + 1;
      if (cpl_valid && !cpl_ready) n_cpl_bp = n_cpl_bp + 1;

      // ---------------------------------------------------- handshakes
      if (cmd_valid && cmd_ready) begin
        n_cmd_acc = n_cmd_acc + 1;
        n_cmd_seg = n_cmd_seg + 1;
        last_progress = cyc;
        if (c_idx < MAXC) begin
          t_cmd[c_idx] = cyc; vl_of[c_idx] = int'(c_vl); red_of[c_idx] = c_red[0];
          t_b0[c_idx] = -1; t_r0[c_idx] = -1; t_bl[c_idx] = -1; t_rl[c_idx] = -1;
        end
        if (gap > 0) gap_wait = 1;
        load_cmd();
      end
      if (opnd_valid && opnd_ready) begin
        n_beat_acc = n_beat_acc + 1;
        last_progress = cyc;
        if (b_idx < MAXC) begin
          if (t_b0[b_idx] < 0) t_b0[b_idx] = cyc;
          t_bl[b_idx] = cyc;
        end
        load_beat();
      end
      if (cpl_valid && cpl_ready) begin
        n_cpl = n_cpl + 1;
        n_cpl_seg = n_cpl_seg + 1;
        last_progress = cyc;
        if (!p_have || !seg_ok(p_seg)) begin
          fail($sformatf("unexpected completion (tid %0h)", cpl_tid));
        end else begin
          if (cpl_tid !== TID_W'(p_tid) || cpl_flags !== p_flags[4:0] || cpl_illegal !== p_ill[0] ||
              cpl_count !== VL_W'(p_count) || cpl_red !== p_red[0] || cpl_result !== p_result)
            fail($sformatf("completion cmd #%0d: got tid %0h fl %02h ill %0b cnt %0d red %0b res %08h, exp tid %0h fl %02h ill %0b cnt %0d red %0b res %08h",
                           p_idx, cpl_tid, cpl_flags, cpl_illegal, cpl_count, cpl_red, cpl_result,
                           p_tid[TID_W-1:0], p_flags[4:0], p_ill[0], p_count, p_red[0], p_result));
          // completion only after all result beats of the command were handed over
          if (r_have && seg_ok(r_seg) && r_idx <= p_idx)
            fail($sformatf("completion of cmd #%0d before its result beat %0d", p_idx, r_beat));
          if (p_ill == 0) n_elem = n_elem + longint'(p_count);
          if (p_idx < MAXC) t_cpl[p_idx] = cyc;
          if (gap > 0) begin gap_wait = 0; gap_until = cyc + gap; end
          load_cpl();
        end
      end

      if (res_valid && res_ready) begin
        n_res = n_res + 1;
        last_progress = cyc;
        if (!r_have || !seg_ok(r_seg)) begin
          fail($sformatf("unexpected result beat (tid %0h beat %0d)", res_tid, res_beat));
        end else begin
          if (res_tid !== TID_W'(r_tid) || res_beat !== VL_W'(r_beat) || res_last !== r_last[0] ||
              res_mask !== N'(r_mask))
            fail($sformatf("result beat header: cmd #%0d got tid %0h beat %0d last %0b mask %b, exp tid %0h beat %0d last %0b mask %b",
                           r_idx, res_tid, res_beat, res_last, res_mask, r_tid[TID_W-1:0],
                           r_beat, r_last[0], r_mask[N-1:0]));
          for (int l = 0; l < N; l++)
            if (res_data[l*32 +: 32] !== r_d[l*32 +: 32] || res_flags[l*5 +: 5] !== r_f[l*5 +: 5])
              fail($sformatf("cmd #%0d beat %0d lane %0d: got %08h/%02h exp %08h/%02h",
                             r_idx, r_beat, l, res_data[l*32 +: 32], res_flags[l*5 +: 5],
                             r_d[l*32 +: 32], r_f[l*5 +: 5]));
          if (r_idx < MAXC) begin
            if (t_r0[r_idx] < 0) t_r0[r_idx] = cyc;
            t_rl[r_idx] = cyc;
          end
          load_res();
        end
      end
      // stall memory for the next cycle's stability check
      prev_res_hold = res_valid && !res_ready;
      pr_data = res_data; pr_flags = res_flags; pr_mask = res_mask; pr_tid = res_tid;
      pr_beat = res_beat; pr_last = res_last;
      prev_cpl_hold = cpl_valid && !cpl_ready;
      pc_tid = cpl_tid; pc_flags = cpl_flags; pc_ill = cpl_illegal; pc_count = cpl_count;
      pc_red = cpl_red; pc_result = cpl_result;

`ifndef GATE
      // ---------------------------------------------------- mechanism coverage
      if ((|(dut.ln_valid & dut.ln_ready)) && !(opnd_valid && opnd_ready)) cv_partial++;
      if (!dut.trk_empty && !dut.th_nobeat && (|(dut.th_act & dut.lo_valid)) &&
          !(&(~dut.th_act | dut.lo_valid))) cv_mixed_out++;
      if (dut.trk_full) cv_trk_full++;
      if (dut.u_issue.cq_full) cv_cq_full++;
      if (!dut.cq_empty && dut.cpl_block) cv_cpl_block++;
      if (dut.it_valid && !dut.it_ready && dut.u_reduce.sp_q != 0) cv_red_space++;
      if (dut.it_valid && !dut.it_ready && dut.u_reduce.cred_q == 0) cv_red_cred++;
      if (|(dut.ln_valid & dut.u_issue.hold_q)) fail("element offered to a held lane");
      for (int l = 0; l < N; l++) begin
        if (!dut.ln_ready[l]) cv_rob_full++;
        if (dut.ln_valid[l] && dut.ln_ready[l] && !dut.ln_en[l]) cv_masked_sent++;
        if (dut.u_issue.lane_need[l] && dut.u_issue.hold_q[l] && dut.u_issue.beat_ph &&
            opnd_valid) cv_hold_need++;
      end
`endif

      // ---------------------------------------------------- segment / reset control
      begin
        seg_done = !(c_have && c_seg == cur_seg) && !(b_have && b_seg == cur_seg) &&
                   !(r_have && r_seg == cur_seg) && !(p_have && p_seg == cur_seg);
        if (seg_done && !done) begin
          if (c_eof && b_eof && r_eof && p_eof) begin
            done = 1; drain = 0;
          end else if (rst_en && !seg_rst_done && rnd(4) == 0) begin
            rst_at = cyc;                          // reset while idle
          end else begin
            cur_seg = cur_seg + 1; n_cmd_seg = 0; n_cpl_seg = 0; seg_rst_done = 0;
            rst_at = rst_en ? cyc + 1 + rnd(rst_win) : -1;
          end
        end
      end
      if (rst_en && !done && rst_at >= 0 && cyc >= rst_at && !seg_rst_done) begin
        // asynchronous reset in the middle of (or after) the segment
        seg_rst_done = 1;
        n_resets = n_resets + 1;
        if (!seg_done) n_rst_mid = n_rst_mid + 1;      // work of the segment outstanding
        rst_n <= 1'b0;
        rst_cnt = 1 + rnd(4);
        // discard every not-yet-observed record of this segment
        while (c_have && c_seg == cur_seg) load_cmd();
        while (b_have && b_seg == cur_seg) load_beat();
        while (r_have && r_seg == cur_seg) load_res();
        while (p_have && p_seg == cur_seg) load_cpl();
        cur_seg = cur_seg + 1; n_cmd_seg = 0; n_cpl_seg = 0;
        seg_start = cyc; rst_at = cyc + 8 + rnd(rst_win); seg_rst_done = 0;
        if (c_eof && b_eof && r_eof && p_eof) done = 1;
        gap_wait = 0;
      end

      // ---------------------------------------------------- drive next cycle
      if (!(cmd_valid && !cmd_ready)) begin
        if (c_have && seg_ok(c_seg) && !gap_wait && cyc >= gap_until && pct(p_cmd) == 1) begin
          cmd_valid  <= 1'b1;
          cmd_op     <= c_op[4:0];  cmd_rm  <= c_rm[2:0];  cmd_vl <= VL_W'(c_vl);
          cmd_vm     <= c_vm[0];    cmd_bcast <= c_bc[2:0]; cmd_scalar <= c_sc;
          cmd_red    <= c_red[0];   cmd_tid <= TID_W'(c_tid);
        end else begin
          cmd_valid  <= 1'b0;
        end
      end
      if (!(opnd_valid && !opnd_ready)) begin
        if (b_have && seg_ok(b_seg) && pct(p_opnd) == 1) begin
          opnd_valid <= 1'b1;
          opnd_a <= b_a; opnd_b <= b_b; opnd_c <= b_c; opnd_mask <= N'(b_mask);
        end else begin
          opnd_valid <= 1'b0;
        end
      end
      res_ready <= (pct(p_res) == 1);
      cpl_ready <= (pct(p_cpl) == 1);
      // per-lane hold patterns
      begin
        logic [N-1:0] h;
        h = '0;
        case (hold_mode)
          1: for (int l = 0; l < N; l++) h[l] = (pct(p_hold) == 1);
          2: for (int l = 0; l < N; l++) begin
               if (hold_cnt[l] > 0) begin hold_cnt[l] = hold_cnt[l] - 1; h[l] = 1'b1; end
               else if (pct(p_hold) == 1) hold_cnt[l] = 1 + rnd(48);
             end
          3: begin
               if (rnd(512) == 0) stuck_lane = rnd(N);
               h[stuck_lane] = (rnd(16) != 0);
             end
          4: for (int l = 0; l < N; l++) h[l] = ((cyc + l) % 2 == 0);
          default: h = '0;
        endcase
        if (N == 1 && hold_mode == 4) h[0] = (cyc % 3 == 0);
        lane_hold <= h;
      end

      // ---------------------------------------------------- liveness / end
      if (cyc - last_progress > 20000) begin
        $display("TEST FAILED: no progress for 20000 cycles (deadlock?)");
        $finish;
      end
      if (done) begin
        drain = drain + 1;
        if (drain == 40) begin
          finish_test();
          perf_clear <= 1'b1;                  // exercise the counter clear
        end
        if (drain == 41) perf_clear <= 1'b0;
        if (drain == 43) begin
          if (PERF_EN)
            for (int i = 0; i < NPC; i++)
              if (perf_cnt[i*CW +: CW] > ((i == hpc_varray_pkg::PC_CYCLES) ? 2 : 0))
                fail($sformatf("perf counter %0d not cleared", i));
          if (n_err == 0) $display("TEST PASSED");
          else            $display("TEST FAILED (%0d errors)", n_err);
          $finish;
        end
      end
    end
  end

  // ------------------------------------------------------------ end of test
  task automatic finish_test();
    longint pc [0:NPC-1];
    longint cycles;
    real    epc, util;
    if (busy) fail("busy_o still high after the test drained");
    if (res_valid || cpl_valid) fail("output still valid after the test drained");
    for (int i = 0; i < NPC; i++) pc[i] = longint'(perf_cnt[i*CW +: CW]);
    cycles = cyc - perf_t0;
    if (PERF_EN && n_resets == 0) begin
      if (pc[hpc_varray_pkg::PC_CMD_IN]   != n_cmd_acc)
        fail($sformatf("perf CMD_IN %0d != %0d", pc[hpc_varray_pkg::PC_CMD_IN], n_cmd_acc));
      if (pc[hpc_varray_pkg::PC_CMD_DONE] != n_cpl)      fail("perf CMD_DONE mismatch");
      if (pc[hpc_varray_pkg::PC_BEAT_IN]  != n_beat_acc) fail("perf BEAT_IN mismatch");
      if (pc[hpc_varray_pkg::PC_BEAT_OUT] != n_res)      fail("perf BEAT_OUT mismatch");
      if (pc[hpc_varray_pkg::PC_ELEM_IN]  != n_elem)     fail("perf ELEM_IN mismatch");
      if (pc[hpc_varray_pkg::PC_ELEM_OUT] != n_elem)     fail("perf ELEM_OUT mismatch");
      if (pc[hpc_varray_pkg::PC_RES_BP]   != n_res_bp)   fail("perf RES_BP mismatch");
      if (pc[hpc_varray_pkg::PC_CPL_BP]   != n_cpl_bp)   fail("perf CPL_BP mismatch");
      if (pc[hpc_varray_pkg::PC_BUSY]     != n_busy)     fail("perf BUSY mismatch");
      if (pc[hpc_varray_pkg::PC_CYCLES]   != cycles)
        fail($sformatf("perf CYCLES %0d != %0d", pc[hpc_varray_pkg::PC_CYCLES], cycles));
    end
    epc  = (cycles > 0) ? real'(n_elem) / real'(cycles) : 0.0;
    util = (cycles > 0) ? real'(n_elem) / real'(cycles * N) : 0.0;
    $display("STATS N=%0d cycles=%0d busy=%0d cmds=%0d beats_in=%0d beats_out=%0d elems=%0d elem_per_cycle=%.3f lane_util=%.3f stall_lane=%0d stall_trk=%0d lane_stall=%0d opnd_starve=%0d res_bp=%0d coll_wait=%0d red_wait=%0d cpl_bp=%0d resets=%0d resets_mid=%0d",
             N, cycles, n_busy, n_cmd_acc, n_beat_acc, n_res, n_elem, epc, util,
             pc[hpc_varray_pkg::PC_STALL_LANE], pc[hpc_varray_pkg::PC_STALL_TRK],
             pc[hpc_varray_pkg::PC_LANE_STALL], pc[hpc_varray_pkg::PC_OPND_STARVE],
             pc[hpc_varray_pkg::PC_RES_BP], pc[hpc_varray_pkg::PC_COLL_WAIT],
             pc[hpc_varray_pkg::PC_RED_WAIT], pc[hpc_varray_pkg::PC_CPL_BP], n_resets, n_rst_mid);
`ifndef GATE
    $display("COVER partial_issue=%0d mixed_lane_out=%0d trk_full=%0d cmdq_full=%0d cpl_block=%0d red_spacing=%0d red_credit=%0d lane_rob_full=%0d masked_sent=%0d hold_on_need=%0d",
             cv_partial, cv_mixed_out, cv_trk_full, cv_cq_full, cv_cpl_block, cv_red_space,
             cv_red_cred, cv_rob_full, cv_masked_sent, cv_hold_need);
`endif
    if (latlog != "") begin
      fl = $fopen(latlog, "w");
      for (longint i = 0; i < n_cmd_acc && i < MAXC; i++)
        $fwrite(fl, "%0d %0d %0d %0d %0d %0d %0d %0d %0d\n", i, vl_of[i], red_of[i], t_cmd[i],
                t_b0[i], t_bl[i], t_r0[i], t_rl[i], t_cpl[i]);
      $fclose(fl);
    end
  endtask

  // ------------------------------------------------------------ setup
  initial begin
    if (!$value$plusargs("DIR=%s", dir)) dir = ".";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    if (!$value$plusargs("PCMD=%d", p_cmd)) p_cmd = 100;
    if (!$value$plusargs("POPND=%d", p_opnd)) p_opnd = 100;
    if (!$value$plusargs("PRES=%d", p_res)) p_res = 100;
    if (!$value$plusargs("PCPL=%d", p_cpl)) p_cpl = 100;
    if (!$value$plusargs("HOLD=%d", hold_mode)) hold_mode = 0;
    if (!$value$plusargs("PHOLD=%d", p_hold)) p_hold = 20;
    if (!$value$plusargs("RESET=%d", rst_en)) rst_en = 0;
    if (!$value$plusargs("RSTWIN=%d", rst_win)) rst_win = 300;
    if (!$value$plusargs("GAP=%d", gap)) gap = 0;
    if (!$value$plusargs("MAXCYC=%d", max_cyc)) max_cyc = 64'd20000000;
    if (!$value$plusargs("LATLOG=%s", latlog)) latlog = "";
    quiet = $test$plusargs("QUIET");
    rng = 32'h9E3779B9 ^ 32'(seed * 2654435761);
    if (rng == 0) rng = 32'h1;
    for (int l = 0; l < N; l++) hold_cnt[l] = 0;
    fc = $fopen({dir, "/cmds.txt"}, "r");
    fb = $fopen({dir, "/beats.txt"}, "r");
    fr = $fopen({dir, "/res.txt"}, "r");
    fp = $fopen({dir, "/cpl.txt"}, "r");
    if (fc == 0 || fb == 0 || fr == 0 || fp == 0) begin
      $display("TEST FAILED: cannot open test files in %s", dir);
      $finish;
    end
    load_cmd(); load_beat(); load_res(); load_cpl();
    rst_at = rst_en ? 64'(20 + (seed % 97)) : -1;
    if (!quiet)
      $display("tb: N=%0d dir=%s seed=%0d pcmd=%0d popnd=%0d pres=%0d pcpl=%0d hold=%0d/%0d reset=%0d gap=%0d",
               N, dir, seed, p_cmd, p_opnd, p_res, p_cpl, hold_mode, p_hold, rst_en, gap);
  end
endmodule
