#!/usr/bin/env python3
"""SilicaFlux-HPC Module 03 :: gatesim.py -- post-synthesis simulation.

Runs the unmodified self-checking testbench (compiled with -DGATE: no internal
probes) against the flattened generic gate-level netlists written by
syn/run_synth.sh (NUM_LANES = 2 and 4, default parameters), on Verilator and
on Icarus.  Icarus is 4-state: a reset that left any control flop X, or an X
reaching an output, fails the run.

usage: gatesim.py [--out reports/gatesim.md]
"""
import argparse
import concurrent.futures as cf
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import regress  # noqa: E402

ROOT = regress.ROOT
RUNS = [("directed", 1, "clean"), ("mixed", 1, "stall"), ("mask", 1, "phase"), ("red", 1, "stall"),
        ("reset", 1, "rst_stall"), ("b2b", 1, "bp"), ("illegal", 1, "clean"), ("fpexc", 1, "stuck"),
        ("long", 1, "clean")]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "gatesim.md"))
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    a = ap.parse_args()
    regress.build_ref()
    logdir = os.path.join(ROOT, "reports", "logs_gate")
    os.makedirs(logdir, exist_ok=True)
    res = []
    for cfg, n in (("n2", 2), ("n4", 4)):
        net = os.path.join(ROOT, "build", "syn", f"hpc_vector_array_n{n}_netlist.v")
        if not os.path.exists(net):
            sys.exit(f"missing netlist {net}: run syn/run_synth.sh first")
        for sim in ("verilator", "icarus"):
            exe, _ = regress.build_sim(sim, cfg, gate=net)
            plan = [r for r in RUNS if not (sim == "icarus" and r[0] == "long")]
            with cf.ThreadPoolExecutor(a.jobs) as ex:
                futs = [ex.submit(regress.run_one, sim, exe, cfg, t, s, p,
                                  {**regress.PROFILES, **regress.RESET_PROFILES}[p], logdir)
                        for t, s, p in plan]
                part = [f.result() for f in futs]
            print(f"[{sim:9s}] gate {cfg}: {sum(r['ok'] for r in part)}/{len(part)} PASS", flush=True)
            res += part
    ok = sum(r["ok"] for r in res)
    L = ["# Module 03 gate-level simulation", "",
         f"{ok} / {len(res)} PASS.  Netlists: Yosys 0.33 `synth -flatten` generic gates of "
         "`hpc_vector_array` (default parameters, NUM_LANES = 2 and 4), written by "
         "`syn/run_synth.sh`.  Testbench: `tb/tb_hpc_vector_array.sv` compiled with `-DGATE` "
         "(identical checks except the internal-probe coverage and the held-lane probe).  "
         "Icarus runs are 4-state: X on any output or any X left by reset fails the run.  "
         "The `long` test (vl = 65 535) is run on Verilator only (Icarus gate-level runtime).", "",
         "| simulator | netlist | test | profile | result | elements | cycles | resets (mid-activity) |",
         "|---|---|---|---|---|---|---|---|"]
    for r in res:
        st = regress.kv(r["stats"]) if r["stats"] else {}
        L.append(f"| {r['sim']} | {r['cfg']} | {r['test']} | {r['prof']} | {'PASS' if r['ok'] else 'FAIL'} | "
                 f"{st.get('elems', '')} | {st.get('cycles', '')} | {st.get('resets', '')} ({st.get('resets_mid', '')}) |")
    open(a.out, "w").write("\n".join(L) + "\n")
    print(f"gatesim: {ok}/{len(res)} PASS -> {a.out}")
    sys.exit(0 if ok == len(res) else 1)


if __name__ == "__main__":
    main()
