#!/usr/bin/env bash
# SilicaFlux-HPC Module 03 :: lint.sh -- Verilator -Wall (all array sizes and
# several parameter sets), Icarus elaboration and Yosys elaboration + latch
# check of the array RTL.  Fails on any warning.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
RTL="$(tr '\n' ' ' < rtl/files.f)"
mkdir -p reports
OUT=reports/lint.txt
{
  echo "# lint: $(verilator --version); $(iverilog -V 2>&1 | head -1); $(yosys -V)"
  for cfg in "-GNUM_LANES=1" "-GNUM_LANES=2" "-GNUM_LANES=4" "-GNUM_LANES=8" "-GNUM_LANES=16" \
             "-GNUM_LANES=4 -GCMD_DEPTH=1 -GTRK_DEPTH=1 -GCPL_DEPTH=1 -GLANE_ROB_DEPTH=2 -GLAT_FADD=2 -GLAT_FMUL=2 -GLAT_FMA=3 -GLAT_IMUL=1 -GRED_LAT=2" \
             "-GNUM_LANES=8 -GTRK_DEPTH=12 -GCPL_DEPTH=6 -GLANE_ROB_DEPTH=16 -GLAT_FMA=8 -GRED_LAT=5 -GVL_W=12 -GTID_W=5" \
             "-GNUM_LANES=2 -GRED_EN=0 -GPERF_EN=0 -GEN_FCMP=0 -GEN_INT=0" \
             "-GNUM_LANES=16 -GRED_EN=0 -GPERF_CW=48 -GVL_W=20 -GTID_W=1"; do
    echo "== verilator --lint-only -Wall $cfg"
    verilator --lint-only -Wall --top-module hpc_vector_array $cfg $RTL 2>&1
    echo "   exit=$? (no output = clean)"
  done
  for n in 1 2 4 8 16; do
    echo "== iverilog -g2012 elaboration NUM_LANES=$n"
    iverilog -g2012 -o /dev/null -s hpc_vector_array -Phpc_vector_array.NUM_LANES=$n $RTL 2>&1
  done
  echo "== iverilog -g2012 testbench elaboration"
  iverilog -g2012 -o /dev/null -s tb_hpc_vector_array $RTL tb/tb_hpc_vector_array.sv 2>&1
  for n in 1 16; do
    echo "== yosys read_verilog -sv; hierarchy -check; proc; no latches (NUM_LANES=$n)"
    yosys -q -p "read_verilog -sv -DSYNTHESIS $RTL; hierarchy -check -top hpc_vector_array -chparam NUM_LANES $n; proc;
      select -assert-none t:\$dlatch t:\$adlatch t:\$dlatchsr" 2>&1
  done
  echo "== lint clean"
} > "$OUT" 2>&1
if grep -qiE '^%(Warning|Error)|error|warning|sorry' "$OUT"; then cat "$OUT"; echo "LINT FAILED"; exit 1; fi
cat "$OUT"
