#!/usr/bin/env python3
"""SilicaFlux-HPC Module 03 :: synth_summary.py -- tabulate Yosys results.

Reads reports/synth/*_stat.txt (and reports/pnr/*.json if present) and writes
reports/synth/summary.md.  Every number is copied from a tool report; device
capacities are vendor data-sheet values.
"""
import json
import os
import re
import sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "reports/synth"
NS = [1, 2, 4, 8, 16]

# vendor capacities
ECP5 = {"LFE5U-25F": (24288, 28), "LFE5U-45F": (43848, 72), "LFE5U-85F": (83640, 156)}
XC7 = {"xc7a100t": (63400, 126800, 240), "xc7a200t": (133800, 267600, 740)}


def cells(path):
    """Return {cell_type: count} of the top-level (flattened) design."""
    if not os.path.exists(path):
        return None
    txt = open(path).read()
    # flattened: one module section; hierarchical: use the 'design hierarchy' totals
    m = re.search(r"=== design hierarchy ===(.*)", txt, re.S)
    body = m.group(1) if m else txt
    d = {}
    in_cells = False
    for line in body.splitlines():
        if re.match(r"\s+Number of cells:", line):
            in_cells = True
            d["_total"] = int(line.split()[-1])
            continue
        if in_cells:
            mm = re.match(r"\s+(\S+)\s+(\d+)$", line)
            if mm:
                d[mm.group(1)] = d.get(mm.group(1), 0) + int(mm.group(2))
            elif line.strip() == "" and d:
                in_cells = False
    return d


def ltp(path):
    if not os.path.exists(path):
        return ""
    m = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", open(path).read())
    return m.group(1) if m else ""


def flops(d):
    return sum(v for k, v in d.items() if re.match(r"\$_(S?DFF|DFFE|SDFF|ALDFF|DFFSR)", k)
               or k.startswith("$_DFF"))


def ecp5_row(d):
    lut = d.get("LUT4", 0)
    ccu = d.get("CCU2C", 0)
    dpr = d.get("TRELLIS_DPR16X4", 0)
    ff = d.get("TRELLIS_FF", 0)
    mul = d.get("MULT18X18D", 0)
    ebr = d.get("DP16KD", 0)
    est = lut + 2 * ccu + 4 * dpr    # LUT4 equivalents (CCU2C = 2 LUT4; DPR16X4 ~ 4 LUT4)
    return lut, ccu, dpr, ff, mul, ebr, est


def xc7_row(d):
    lut = sum(d.get(f"LUT{i}", 0) for i in range(1, 7))
    lram = sum(v for k, v in d.items() if k.startswith("RAM") and k[3:5] in ("32", "64", "16"))
    ff = sum(v for k, v in d.items() if re.match(r"FD[CPRS]E?$", k))
    car = d.get("CARRY4", 0)
    dsp = d.get("DSP48E1", 0)
    srl = sum(v for k, v in d.items() if k.startswith("SRL"))
    return lut, lram, srl, ff, car, dsp


def pnr(n, variant=""):
    """P&R result for the frozen RTL, or a marker if only a stale / no result exists."""
    root = os.path.dirname(os.path.dirname(os.path.abspath(OUT)))
    p = os.path.join(os.path.dirname(OUT), "pnr", f"pnr{variant}_n{n}.json")
    frozen = os.path.join(root, "build", "rtl_frozen.sha256")
    if not os.path.exists(p):
        return None
    if os.path.exists(frozen) and os.path.getmtime(p) < os.path.getmtime(frozen):
        return dict(result="no result for the final RTL (run not completed)", util={}, fmax="")
    return json.load(open(p))


def main():
    L = ["# Module 03 synthesis summary", "",
         "Yosys 0.33, unmodified RTL, flattened synthesis.  All numbers are copied from the "
         "`*_stat.txt` / `*_ltp.txt` reports in this directory.  Synthesis numbers are "
         "pre-place-and-route estimates; post-route results (nextpnr-ecp5) are in "
         "`reports/pnr/` and are quoted separately below.  **No clock frequency is derived "
         "from synthesis.**", ""]

    L += ["## 1. Generic synthesis (`synth -flatten`, Yosys internal gate library)", "",
          "`check -assert` passed and **zero latches** were inferred in every row "
          "(the script aborts otherwise).", "",
          "| NUM_LANES | cells | flip-flops | longest path (generic cells) | cells / lane |",
          "|---|---|---|---|---|"]
    for n in NS:
        d = cells(os.path.join(OUT, f"generic_n{n}_stat.txt"))
        if d is None:
            L.append(f"| {n} | not run | | | |")
            continue
        L.append(f"| {n} | {d['_total']:,} | {flops(d):,} | {ltp(os.path.join(OUT, f'generic_n{n}_ltp.txt'))} "
                 f"| {d['_total'] // n:,} |")

    for title, pre, note in (("2. Lattice ECP5 (`synth_ecp5`), default configuration", "ecp5",
                              "All lanes with FADD/FMUL/FMA/MISC/IMUL units, reduction unit, counters."),
                             ("3. Lattice ECP5, lean configuration", "ecp5_lean",
                              "FP add/mul/FMA lanes only (`EN_FCMP=0`, `EN_INT=0`), no reduction unit "
                              "(`RED_EN=0`), no counters (`PERF_EN=0`).")):
        L += ["", f"## {title}", "", note, "",
              "LUT4-equivalent estimate = LUT4 + 2 x CCU2C + 4 x TRELLIS_DPR16X4 (a lower-bound style "
              "estimate of slice LUT usage; nextpnr's post-pack `TRELLIS_COMB` count is authoritative "
              "and is given in section 5 where place-and-route was run).", "",
              "| NUM_LANES | LUT4 | CCU2C | DPR16X4 | FF | MULT18X18D | DP16KD | LUT4-eq. est. | "
              + " | ".join(f"{k} LUT / DSP" for k in ECP5) + " |",
              "|---" * (8 + len(ECP5)) + "|"]
        for n in NS:
            d = cells(os.path.join(OUT, f"{pre}_n{n}_stat.txt"))
            if d is None:
                L.append(f"| {n} | not run |" + " |" * (7 + len(ECP5)))
                continue
            lut, ccu, dpr, ff, mul, ebr, est = ecp5_row(d)
            fit = []
            for dev, (cl, cm) in ECP5.items():
                fit.append(f"{100 * est / cl:.0f} % / {100 * mul / cm:.0f} %"
                           + (" **exceeds**" if est > cl or mul > cm else ""))
            L.append(f"| {n} | {lut:,} | {ccu:,} | {dpr:,} | {ff:,} | {mul} | {ebr} | {est:,} | "
                     + " | ".join(fit) + " |")

    for title, pre in (("4. Xilinx 7-series (`synth_xilinx -family xc7 -flatten -noiopad`)", "xc7"),
                       ("4b. Xilinx 7-series, lean configuration", "xc7_lean")):
        L += ["", f"## {title}", "",
              "Yosys mapping, not Vivado: Vivado results will differ.  Utilisation is against "
              "the device's LUT / DSP48E1 count.", "",
              "| NUM_LANES | LUT | LUTRAM | SRL | FF | CARRY4 | DSP48E1 | "
              + " | ".join(f"{k} LUT / DSP" for k in XC7) + " |",
              "|---" * (7 + len(XC7)) + "|"]
        for n in NS:
            d = cells(os.path.join(OUT, f"{pre}_n{n}_stat.txt"))
            if d is None:
                L.append(f"| {n} | not run |" + " |" * (6 + len(XC7)))
                continue
            lut, lram, srl, ff, car, dsp = xc7_row(d)
            tot = lut + lram + srl
            fit = [f"{100 * tot / cl:.0f} % / {100 * dsp / cd:.0f} %" + (" **exceeds**" if tot > cl or dsp > cd else "")
                   for dev, (cl, cf, cd) in XC7.items()]
            L.append(f"| {n} | {lut:,} | {lram:,} | {srl:,} | {ff:,} | {car:,} | {dsp} | " + " | ".join(fit) + " |")

    # place and route
    L += ["", "## 5. Place and route (nextpnr-ecp5, LFE5U-85F CABGA381, ULX3S pinout)", ""]
    rows = []
    for variant, label in (("", "default"), ("_lean", "lean")):
        for n in NS:
            r = pnr(n, variant)
            if r is not None:
                rows.append((label, n, r))
    if not rows:
        L.append("Not run (see `syn/run_pnr.sh`).")
    else:
        L += ["Design = array + timing harness (`syn/hpc_varray_fpga_harness.sv`).  Fmax is "
              "nextpnr's post-route static timing estimate for the speed-6 device at the stated "
              "seed; it is a property of this implementation run, not a measured hardware clock.", "",
              "| configuration | NUM_LANES | result | TRELLIS_COMB | TRELLIS_FF | MULT18X18D | Fmax (MHz) |",
              "|---|---|---|---|---|---|---|"]
        for label, n, r in rows:
            u = r.get("util", {})
            def g(k):
                v = u.get(k)
                return f"{v[0]:,} / {v[1]:,}" if v else ""
            L.append(f"| {label} | {n} | {r.get('result', '')} | {g('TRELLIS_COMB')} | {g('TRELLIS_FF')} | "
                     f"{g('MULT18X18D')} | {r.get('fmax', '')} |")

    # per block (subtree totals from the hierarchical stat)
    d = os.path.join(OUT, "hier_n4_stat.txt")
    if os.path.exists(d):
        txt = open(d).read().split("=== design hierarchy ===")[0]
        mods = {}
        for m in re.finditer(r"=== (\S+) ===(.*?)(?=\n=== |\Z)", txt, re.S):
            ct = {}
            for mm in re.finditer(r"^\s+(\S+)\s+(\d+)$", m.group(2), re.M):
                ct[mm.group(1)] = int(mm.group(2))
            mods[m.group(1)] = ct
        memo = {}
        def sub(mn):
            if mn not in memo:
                memo[mn] = sum(c if t not in mods else c * sub(t) for t, c in mods[mn].items())
            return memo[mn]
        top = mods.get("hpc_vector_array", {})
        total = sub("hpc_vector_array")
        L += ["", "## 6. Cells per block (generic, hierarchical, NUM_LANES = 4)", "",
              "Subtree totals (block including its sub-modules) from `hier_n4_stat.txt`.  "
              "Hierarchical synthesis does not optimise across block boundaries, so the total "
              "is slightly above the flattened figure in section 1.", "",
              "| block | instances | cells per instance | cells total | share |", "|---|---|---|---|---|"]
        rows = [(t.split(chr(92))[-1], c, sub(t)) for t, c in top.items() if t in mods]
        own = sum(c for t, c in top.items() if t not in mods)
        for name, c, per in sorted(rows, key=lambda r: -r[1] * r[2]):
            L.append(f"| {name} | {c} | {per:,} | {c * per:,} | {100 * c * per / total:.1f} % |")
        L.append(f"| top-level glue | 1 | {own:,} | {own:,} | {100 * own / total:.1f} % |")
        L.append(f"| **total** | | | **{total:,}** | 100 % |")
        L += ["", "The two top-level `hpc_varray_fifo` rows are the beat-tracking queue (larger, "
              "8 entries of N + 39 + TID_W bits) and the completion queue (4 entries); the command "
              "queue is inside `hpc_varray_issue`."]
    L += ["", "Timing of the synthesis runs: `timing.txt`.  Structural interface check: "
          "`structural_check.txt`.", ""]
    open(os.path.join(OUT, "summary.md"), "w").write("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
