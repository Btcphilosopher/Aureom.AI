#!/usr/bin/env python3
"""SilicaFlux-HPC Module 03 :: mutate.py -- mutation testing of the array RTL.

Each mutant injects one realistic bug into the Module 03 RTL (issue
controller, collector, reduction unit, FIFO, top level).  The mutated design
is rebuilt (Verilator, NUM_LANES = 4) and run against a subset of the
regression; the mutant is KILLED if any run fails (mismatch, protocol/X
check, simulation assertion, deadlock or timeout).  A surviving mutant means a
blind spot in the verification.  The Module 02 lane is not mutated here (its
own campaign killed 28/28 mutants).

usage: mutate.py [--jobs J] [--out reports/mutation.md]
"""
import argparse
import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import regress  # noqa: E402

ROOT = regress.ROOT
B = os.path.join(ROOT, "build", "mut")

# id, file, original text, mutated text, bug class
MUTANTS = [
    ("M01", "hpc_varray_issue.sv", "tail_act[l] = (cur_rem_q > VL_W'(l));",
     "tail_act[l] = (cur_rem_q >= VL_W'(l));", "tail: one element too many"),
    ("M02", "hpc_varray_issue.sv", "wire logic last_beat = (cur_rem_q <= VL_W'(N));",
     "wire logic last_beat = (cur_rem_q < VL_W'(N));", "framing: last beat off by one"),
    ("M03", "hpc_varray_issue.sv", "ln_en[l]     = ~cur_vm_q | opnd_mask_i[l];",
     "ln_en[l]     = 1'b1;", "mask ignored"),
    ("M04", "hpc_varray_issue.sv", "lane_ok[l]   = ~lane_need[l] | (ln_ready_i[l] & ~hold_q[l]);",
     "lane_ok[l]   = ~lane_need[l] | ln_ready_i[l];", "beat released while a lane is held"),
    ("M05", "hpc_varray_issue.sv", "acc_q  <= beat_fire ? '0 : (acc_q | (ln_valid_o & ln_ready_i));",
     "acc_q  <= (acc_q | (ln_valid_o & ln_ready_i));", "per-lane acceptance not cleared"),
    ("M06", "hpc_varray_issue.sv", "lane_need[l] = tail_act[l] & ~acc_q[l] & ~cur_ill_q;",
     "lane_need[l] = tail_act[l] & ~cur_ill_q;", "element re-issued to a lane (duplicate)"),
    ("M07", "hpc_varray_issue.sv", "wire logic bc_b = cur_bcast_q[hpc_varray_pkg::BC_B];",
     "wire logic bc_b = cur_bcast_q[hpc_varray_pkg::BC_A];", "broadcast select"),
    ("M08", "hpc_varray_issue.sv", "wire logic [N-1:0] act = tail_act & ln_en & {N{~cur_ill_q}};",
     "wire logic [N-1:0] act = tail_act & ln_en;", "illegal command marked active"),
    ("M09", "hpc_varray_issue.sv", "wire logic offer = beat_ph & ~trk_full_i;",
     "wire logic offer = beat_ph;", "tracking-queue backpressure ignored"),
    ("M10", "hpc_varray_issue.sv", "assign ln_valid_o = {N{offer & opnd_valid_i}} & lane_need & ~hold_q;",
     "assign ln_valid_o = {N{offer & opnd_valid_i}} & lane_need;",
     "element offered to a held lane (hold contract)"),
    ("M11", "hpc_varray_collect.sv", "wire logic lanes_rdy = &(~trk_act_i | ln_ovalid_i);",
     "wire logic lanes_rdy = |(trk_act_i & ln_ovalid_i) | ~|trk_act_i;",
     "collect when ANY lane is ready (stalled lane result dropped)"),
    ("M12", "hpc_varray_collect.sv",
     "hv_vals [l*32 +: 32] = trk_act_i[l] ? ln_result_i[l*32 +: 32] : 32'd0;",
     "hv_vals [l*32 +: 32] = ln_result_i[l*32 +: 32];", "inactive element data leaks"),
    ("M13", "hpc_varray_collect.sv",
     "hv_flags[l*5  +: 5]  = trk_act_i[l] ? ln_flags_i [l*5  +: 5]  : 5'd0;",
     "hv_flags[l*5  +: 5]  = ln_flags_i [l*5  +: 5];", "inactive element flags leak"),
    ("M14", "hpc_varray_collect.sv", "          cflags_q <= '0;\n          ccount_q <= '0;",
     "          ccount_q <= '0;", "flags leak into the next command"),
    ("M15", "hpc_varray_collect.sv", "          ccount_q <= ccount_q + VL_W'(beat_cnt);",
     "          ccount_q <= ccount_q + VL_W'(1);", "active-element count"),
    ("M16", "hpc_varray_collect.sv",
     "      else if (res_valid_q && res_ready_i) res_valid_q <= 1'b0;", "",
     "result not retired on handover (duplicate)"),
    ("M17", "hpc_varray_collect.sv", "assign ln_oready_o = {N{fire & h_beat}} & trk_act_i;",
     "assign ln_oready_o = {N{fire & h_beat}};", "results taken from inactive lanes (misassociation)"),
    ("M18", "hpc_varray_collect.sv", "          cbeat_q  <= cbeat_q + VL_W'(1);", "",
     "beat index not advanced"),
    ("M19", "hpc_varray_collect.sv", "assign it_wait_o  = elem_tok & h_beat;",
     "assign it_wait_o  = 1'b0;", "completion overtakes its last result beat"),
    ("M20", "hpc_varray_collect.sv", "assign res_data_o     = res_valid_q ? res_data_q  : '0;",
     "assign res_data_o     = res_data_q;", "payload not zeroed when not valid"),
    ("M21", "hpc_varray_reduce.sv", "{va, vb, va ? xa : xb}", "{va, vb, vb ? xa : xb}",
     "tree bypass forwards the wrong child"),
    ("M22", "hpc_varray_reduce.sv", "wire logic both = bd[33] & bd[32];",
     "wire logic both = bd[33] | bd[32];", "absent child replaced by an identity add"),
    ("M23", "hpc_varray_reduce.sv", "wire logic [31:0]     acc_in = s_first ? s_init : acc_q;",
     "wire logic [31:0]     acc_in = acc_q;", "initial accumulator value ignored"),
    ("M24", "hpc_varray_reduce.sv", "if (it_fire && need_add) sp_q <= 8'(RLAT - 1);",
     "if (it_fire && need_add) sp_q <= 8'(0);", "accumulator recurrence hazard"),
    ("M25", "hpc_varray_reduce.sv", "cred_q <= cred_q - CRW'(cred_take) + CRW'(cpl_pop_i);",
     "cred_q <= cred_q + CRW'(cpl_pop_i) - CRW'(cpl_pop_i);", "completion credits not consumed"),
    ("M26", "hpc_varray_reduce.sv", "        afl_q <= afl_q | aaf;", "        afl_q <= afl_q;",
     "accumulator-add flags lost"),
    ("M27", "hpc_varray_reduce.sv", "for (int j = 0; j < M; j++) nflg_or = nflg_or | nflg[j*5 +: 5];",
     "for (int j = 0; j < M; j++) nflg_or = nflg_or;", "tree-add flags lost"),
    ("M28", "hpc_varray_reduce.sv", "tk_result_q <= s_ill ? 32'd0 : acc_in;",
     "tk_result_q <= acc_in;", "illegal reduction returns a value"),
    ("M29", "hpc_varray_fifo.sv", "ptr_inc = (p == IW'(DEPTH - 1)) ? '0 : p + IW'(1);",
     "ptr_inc = (p == IW'(DEPTH - 2)) ? '0 : p + IW'(1);", "queue pointer wrap"),
    ("M31", "hpc_varray_reduce.sv", "wire  logic byp     = it_fire & ~it_grp_i & (infl_q == '0);",
     "wire  logic byp     = it_fire & ~it_grp_i;", "completion token bypasses an in-flight reduction"),
    ("M32", "hpc_varray_reduce.sv", "infl_q <= infl_q + 8'(item_in) - 8'(item_done);",
     "infl_q <= infl_q + 8'(it_fire) - 8'(item_done);", "bypassed token counted as in flight"),
    ("M30", "hpc_vector_array.sv",
     "assign busy_o = iss_busy | ~trk_empty | (|lane_busy) | res_valid_o | red_busy | ~cq_empty;",
     "assign busy_o = iss_busy | ~trk_empty | (|lane_busy) | res_valid_o | red_busy;",
     "busy_o low while a completion is pending"),
]

# (test, seed, profile) subset run against every mutant (NUM_LANES = 4)
SUBSET = [("directed", 1, "clean"), ("mixed", 1, "stall"), ("mask", 1, "phase"),
          ("red", 1, "stall"), ("illegal", 1, "clean"), ("b2b", 1, "bp"),
          ("reset", 1, "rst_stall"), ("fpexc", 1, "stuck"), ("bcast", 1, "clean"),
          ("nonmult", 1, "burst"), ("red", 2, "clean"), ("short", 1, "stall")]


def run_mutant(m, cfg):
    mid, fname, old, new, desc = m
    d = os.path.join(B, mid)
    if os.path.exists(d):
        shutil.rmtree(d)
    shutil.copytree(os.path.join(ROOT, "rtl"), os.path.join(d, "rtl"))
    p = os.path.join(d, "rtl", fname)
    src = open(p).read()
    if src.count(old) != 1:
        return dict(id=mid, desc=desc, status="BAD (pattern count %d)" % src.count(old), by="")
    open(p, "w").write(src.replace(old, new))
    srcs = [os.path.join(d, l.strip()) for l in open(os.path.join(ROOT, "rtl", "files.f")) if l.strip()]
    out = os.path.join(d, "obj")
    cmd = ["verilator", "--binary", "--timing", "-O1", "-j", "1", "--timescale", "1ns/1ps",
           "-Wno-fatal", "-Wno-WIDTH", "-Wno-lint", "-Wno-style", "--top-module",
           "tb_hpc_vector_array", "-Mdir", out, "-o", "sim"]
    cmd += [f"-G{k}={v}" for k, v in regress.CONFIGS[cfg][0].items()] + srcs + [regress.TB]
    r = regress.sh(cmd)
    if r.returncode:
        return dict(id=mid, desc=desc, status="KILLED (does not build)", by="build")
    exe = os.path.join(out, "sim")
    for test, seed, prof in SUBSET:
        dd = regress.gen_test(cfg, test, seed, 1.0)
        plus = {**regress.PROFILES, **regress.RESET_PROFILES}[prof].split()
        try:
            rr = regress.sh([exe] + plus + [f"+DIR={dd}", f"+SEED={seed * 31 + len(prof)}", "+QUIET",
                                            "+MAXCYC=400000"], timeout=600)
            out_txt = rr.stdout
        except subprocess.TimeoutExpired:
            out_txt = "TIMEOUT"
        if "TEST PASSED" not in out_txt:
            first = next((l for l in out_txt.splitlines() if "ERROR" in l or "FAIL" in l or
                          "fatal" in l.lower() or "TIMEOUT" in l), out_txt.strip().splitlines()[-1:] or [""])
            if isinstance(first, list):
                first = first[0] if first else ""
            return dict(id=mid, desc=desc, status="KILLED", by=f"{test}/s{seed}/{prof}: {first[:140]}")
    return dict(id=mid, desc=desc, status="SURVIVED", by="")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--cfg", default="n4")
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "mutation.md"))
    a = ap.parse_args()
    regress.build_ref()
    import concurrent.futures as cf
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(lambda m: run_mutant(m, a.cfg), MUTANTS))
    killed = sum(r["status"].startswith("KILLED") for r in res)
    lines = ["# Module 03 mutation testing", "",
             f"{killed} / {len(res)} mutants killed (configuration `{a.cfg}`, "
             f"{len(SUBSET)} regression runs per mutant, first failing run shown).", "",
             "| id | injected bug | result | first detection |", "|---|---|---|---|"]
    for r in res:
        lines.append(f"| {r['id']} | {r['desc']} | {r['status']} | {r['by'].replace('|', '/')} |")
    open(a.out, "w").write("\n".join(lines) + "\n")
    for r in res:
        print(f"{r['id']} {r['status']:9s} {r['desc']}  <- {r['by'][:90]}")
    print(f"mutation: {killed}/{len(res)} killed -> {a.out}")
    sys.exit(0 if killed == len(res) else 1)


if __name__ == "__main__":
    main()
