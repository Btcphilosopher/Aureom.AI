#!/usr/bin/env bash
# SilicaFlux-HPC Module 03 :: run_all.sh -- regenerate every report.
# Requires Verilator 5.020, Icarus Verilog 12, Yosys 0.33, nextpnr-ecp5 0.6,
# gcc and Python >= 3.10.  Several hours on 4 cores (synthesis of the 16-lane
# array and ECP5 place and route dominate).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
bash ref/build_ref.sh
bash scripts/lint.sh
./build/ref/red_order_study 1000 1 > reports/reduction_order_study.md
python3 -I scripts/regress.py --sim verilator --seeds 3 --out reports/regression_verilator.md
python3 -I scripts/regress.py --sim icarus --icarus-seeds 1 --out reports/regression_icarus.md
python3 -I scripts/mutate.py
python3 -I scripts/characterize.py
bash syn/run_synth.sh
python3 -I scripts/gatesim.py
bash syn/run_pnr.sh 1 2 4 8
VARIANT=lean bash syn/run_pnr.sh 4 8
python3 -I scripts/synth_summary.py reports/synth
python3 -I scripts/characterize.py      # picks up the post-route Fmax for section 5
echo "== all reports regenerated"
