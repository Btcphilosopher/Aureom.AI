#!/usr/bin/env python3
"""SilicaFlux-HPC Module 03 :: characterize.py -- measured array performance.

Every number is measured in cycle-accurate RTL simulation (Verilator) of the
default configuration, from the array's own performance counters (which the
testbench cross-checks against its own counts) and per-command timestamps
(+LATLOG).  Every run also passes the self-checking testbench, so all results
are bit-exact.  Cycle counts only: no clock frequency is implied, except in
the explicitly labelled theoretical-peak table, which states its assumptions.

usage: characterize.py [--out reports/performance.md] [--ns 1,2,4,8,16]
"""
import argparse
import json
import os
import re
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import regress  # noqa: E402

ROOT = regress.ROOT
B = os.path.join(ROOT, "build", "perf")


def gen(n, name, op, vl, ncmd, red=0, vm=0):
    d = os.path.join(B, f"n{n}", name)
    if not os.path.exists(os.path.join(d, "cpl.txt")):
        os.makedirs(d, exist_ok=True)
        r = regress.sh([sys.executable, "-I", os.path.join(ROOT, "ref", "gen_stim.py"), "--n", str(n),
                        "--test", "perf", "--op", op, "--vl", str(vl), "--ncmd", str(ncmd),
                        "--red", str(red), "--vm", str(vm), "--seed", "5", "--out", d])
        if r.returncode:
            raise RuntimeError(r.stdout)
        r = regress.sh([os.path.join(ROOT, "build", "ref", "varray_ref"), str(n), "1", "1", "1"] +
                       [os.path.join(d, f) for f in ("cmds.txt", "beats.txt", "res.txt", "cpl.txt")])
        if r.returncode:
            raise RuntimeError(r.stdout)
    return d


def run(exe, d, plus):
    lat = os.path.join(d, "lat_" + re.sub(r"[^A-Za-z0-9]", "_", plus) + ".txt")
    r = regress.sh([exe] + plus.split() + [f"+DIR={d}", "+SEED=3", "+QUIET", f"+LATLOG={lat}"])
    if "TEST PASSED" not in r.stdout:
        raise RuntimeError(f"characterisation run failed: {d} {plus}\n{r.stdout[-2000:]}")
    st = dict(x.split("=", 1) for x in re.search(r"^STATS (.*)$", r.stdout, re.M).group(1).split())
    rows = []
    for line in open(lat):
        f = [int(x) for x in line.split()]
        rows.append(dict(idx=f[0], vl=f[1], red=f[2], t_cmd=f[3], t_b0=f[4], t_bl=f[5], t_r0=f[6],
                         t_rl=f[7], t_cpl=f[8]))
    return st, rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "performance.md"))
    ap.add_argument("--ns", default="1,2,4,8,16")
    a = ap.parse_args()
    regress.build_ref()
    ns = [int(x) for x in a.ns.split(",")]
    exes = {n: regress.build_sim("verilator", f"n{n}")[0] for n in ns}
    P = {}
    L = ["# Module 03 measured performance", "",
         "Cycle-accurate RTL simulation (Verilator 5.020) of the default configuration "
         "(lane latencies FADD 3 / FMUL 3 / FMA 4 / MISC 1, `LANE_ROB_DEPTH=8`, `TRK_DEPTH=8`, "
         "`CMD_DEPTH=4`, `CPL_DEPTH=4`, `RED_LAT=3`).  Every run passes the self-checking "
         "testbench (bit-exact against SoftFloat-3e).  Counter values come from the array's own "
         "performance counters, which the testbench checks against its own counts.  "
         "**These are cycle counts; no clock frequency is implied** (section 6 states its "
         "assumptions explicitly).", ""]

    # ---------------------------------------------------------------- 1 latency
    L += ["## 1. Isolated latency (cycles)", "",
          "One command of one beat (vl = NUM_LANES) at a time (`+GAP=30`), no backpressure.  "
          "*beat to result*: operand beat accepted in cycle t, result beat handed over in cycle "
          "t + x.  *beat to completion*: last operand beat accepted to completion handed over.", "",
          "| operation | expected beat to result | " + " | ".join(f"N={n} beat→result / beat→cpl" for n in ns) + " |",
          "|---|---|" + "---|" * len(ns)]
    ops = [("FMV", 1, 0), ("FADD", 3, 0), ("FMUL", 3, 0), ("FMADD", 4, 0), ("FMV", 1, 1), ("FMUL", 3, 1)]
    for op, lat, red in ops:
        cells = []
        for n in ns:
            d = gen(n, f"lat_{op}_{red}", op, n, 24, red=red)
            st, rows = run(exes[n], d, "+GAP=30")
            br = sorted({r["t_r0"] - r["t_b0"] for r in rows if r["t_r0"] >= 0})
            bc = sorted({r["t_cpl"] - r["t_bl"] for r in rows})
            P.setdefault("lat", {})[f"{op}{'_red' if red else ''}_n{n}"] = (br, bc)
            fmt = lambda s: (str(s[0]) if len(s) == 1 else f"{s[0]}..{s[-1]}") if s else "-"
            cells.append(f"{fmt(br)} / {fmt(bc)}")
        name = f"{op} sum-reduction" if red else op
        L.append(f"| {name} | {'-' if red else lat + 2} | " + " | ".join(cells) + " |")
    L += ["", "Elementwise beat to result = lane latency (LAT + 1, Module 02) + 1 collector "
          "register.  The completion record travels through the reduction unit's tree pipeline "
          "to stay in order behind reductions, so its latency grows with log2(N) x RED_LAT.", ""]

    # ---------------------------------------------------------------- 2 cycles per op
    vls = lambda n: [1, max(1, n // 2), n, n + 1, 4 * n, 16 * n, 64 * n]
    L += ["## 2. Cycles per vector operation (back-to-back FMADD commands, no stalls)", "",
          "64 commands of the same vector length issued back to back.  *measured* = result-stream "
          "cycles per command in steady state ((t_last_result(cmd 63) - t_last_result(cmd 7)) / 56); "
          "*ideal* = ceil(vl / N) beats at one beat per cycle.", ""]
    for n in ns:
        L += [f"**NUM_LANES = {n}**", "", "| vl | beats | ideal cycles/op | measured cycles/op | elements/cycle | lane utilisation |",
              "|---|---|---|---|---|---|"]
        for vl in vls(n):
            d = gen(n, f"cpo_{vl}", "FMADD", vl, 64)
            st, rows = run(exes[n], d, "")
            rl = sorted(rows, key=lambda r: r["idx"])
            cyc = (rl[63]["t_rl"] - rl[7]["t_rl"]) / 56
            nb = -(-vl // n)
            P.setdefault("cpo", {})[f"n{n}_vl{vl}"] = cyc
            L.append(f"| {vl} | {nb} | {nb} | {cyc:.2f} | {vl / cyc:.2f} | {vl / cyc / n:.3f} |")
        L.append("")

    # ---------------------------------------------------------------- 3 streaming
    L += ["## 3. Sustained streaming throughput and utilisation (counters)", "",
          "One elementwise FMADD stream of 32 commands x vl = 64 x N, and one FMUL sum-reduction "
          "(dot product) stream of 16 commands x vl = 64 x N.  Over the whole run (fill and drain "
          "included): accepted / completed elements per cycle = ELEM_IN / CYCLES and ELEM_OUT / "
          "CYCLES; lane utilisation = ELEM_IN / (N x BUSY).", "",
          "| N | workload | cycles | busy | elements | accepted el./cycle | completed el./cycle | lane utilisation | ideal el./cycle |",
          "|---|---|---|---|---|---|---|---|---|"]
    for n in ns:
        for wl, op, red, nc, ideal in (("elementwise FMADD", "FMADD", 0, 32, n),
                                       ("dot product (FMUL + sum)", "FMUL", 1, 16, n / 3)):
            d = gen(n, f"stream_{op}_{red}", op, 64 * n, nc, red=red)
            st, rows = run(exes[n], d, "")
            cyc, busy, el = int(st["cycles"]), int(st["busy"]), int(st["elems"])
            P.setdefault("stream", {})[f"n{n}_{op}_{red}"] = dict(cycles=cyc, busy=busy, elems=el)
            L.append(f"| {n} | {wl} | {cyc} | {busy} | {el} | {el / cyc:.2f} | {el / cyc:.2f} | "
                     f"{el / (n * busy):.3f} | {ideal:.2f} |")
    L += ["", "Ideal for the dot product is N / RED_LAT element per cycle: the FP32 accumulator "
          "has one add in flight (docs/REDUCTION.md).", ""]

    # ---------------------------------------------------------------- 4 stalls
    profs = [("clean", "no stalls"), ("stall", "random gaps + 25 % lane holds + 45 % result backpressure"),
             ("phase", "lanes held on alternating cycles (out of phase)"),
             ("stuck", "one lane held 15/16 of the time"), ("bp", "result ready 12 %")]
    L += ["## 4. Stall and backpressure behaviour (FMADD, 32 commands x vl = 16 x N)", "",
          "Counter definitions: `docs/PERFORMANCE.md` section 1.  STALL_LANE = cycles an operand "
          "beat waited for at least one lane; LANE_STALL = lane-cycles of that waiting; "
          "COLL_WAIT = cycles the head beat waited for lane results; RES_BP = cycles a result "
          "beat waited for the consumer.", "",
          "| N | profile | cycles | el./cycle | lane util. | STALL_LANE | LANE_STALL | OPND_STARVE | COLL_WAIT | RES_BP |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for n in ns:
        d = gen(n, "stall_fmadd", "FMADD", 16 * n, 32)
        for prof, desc in profs:
            st, _ = run(exes[n], d, regress.PROFILES[prof])
            cyc, busy, el = int(st["cycles"]), int(st["busy"]), int(st["elems"])
            P.setdefault("stalls", {})[f"n{n}_{prof}"] = st
            L.append(f"| {n} | {prof} | {cyc} | {el / cyc:.2f} | {el / (n * busy):.3f} | {st['stall_lane']} | "
                     f"{st['lane_stall']} | {st['opnd_starve']} | {st['coll_wait']} | {st['res_bp']} |")
    L += ["", "Profiles: " + "; ".join(f"`{p}` = {d}" for p, d in profs) + ".", ""]

    # ---------------------------------------------------------------- 5 peak
    pnr = {}
    for n in ns:
        p = os.path.join(ROOT, "reports", "pnr", f"pnr_n{n}.json")
        frozen = os.path.join(ROOT, "build", "rtl_frozen.sha256")
        if os.path.exists(p) and (not os.path.exists(frozen) or os.path.getmtime(p) > os.path.getmtime(frozen)):
            j = json.load(open(p))
            if j.get("fmax") and j.get("result") == "routed":
                pnr[n] = float(j["fmax"])
    L += ["## 5. Theoretical peak FP32 throughput (NOT a benchmark)", "",
          "Assumptions, all explicit: (a) initiation interval 1 per lane for FMADD, **as measured "
          "in section 2/3** (one beat of N elements per cycle when nothing stalls); (b) one FMA = "
          "2 FLOP; (c) the operand stream delivers one full beat every cycle and the result stream "
          "is never backpressured; (d) the clock values below.  Peak = 2 x N x f.  The 25 MHz row "
          "is the ULX3S oscillator and SilicaFlux-V's FPGA clock; the post-route row uses "
          "nextpnr-ecp5's static-timing Fmax estimate for this design (one seed, speed grade 6) "
          "where place-and-route succeeded.  Nothing was measured on hardware.  Required "
          "operand + result bandwidth at that rate is 16 B per element (a, b, c in, result out).", "",
          "| N | FLOP/cycle | peak at 25 MHz | streaming bandwidth needed at 25 MHz | post-route Fmax (MHz) | peak at that Fmax |",
          "|---|---|---|---|---|---|"]
    for n in ns:
        f = pnr.get(n)
        L.append(f"| {n} | {2 * n} | {2 * n * 25:.0f} MFLOP/s | {16 * n * 25 / 1000:.2f} GB/s | "
                 f"{f if f else 'n/a (no routed result)'} | {f'{2 * n * f:.0f} MFLOP/s' if f else '-'} |")
    L += ["", "For comparison, the SilicaFlux DataFabric SFB bus is 32 bits wide: at 25 MHz it "
          "moves 0.1 GB/s, so a DataFabric-fed array is operand-bandwidth bound long before the "
          "lanes saturate (elementwise FMA has an arithmetic intensity of 2 FLOP / 16 B).", ""]
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    open(a.out, "w").write("\n".join(L) + "\n")
    json.dump(P, open(os.path.join(os.path.dirname(a.out), "performance.json"), "w"), indent=1)
    print("\n".join(L))


if __name__ == "__main__":
    main()
