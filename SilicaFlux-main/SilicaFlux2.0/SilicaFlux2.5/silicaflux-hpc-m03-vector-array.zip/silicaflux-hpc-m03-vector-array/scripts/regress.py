#!/usr/bin/env python3
"""SilicaFlux-HPC Module 03 :: regress.py -- vector-array regression.

For every array configuration, every test recipe (ref/gen_stim.py) and every
seed it generates the stimulus, computes the expected outputs with the
SoftFloat-based reference (build/ref/varray_ref) and runs the self-checking
testbench under several timing profiles (valid gaps, backpressure, per-lane
hold patterns, reset injection) on Verilator and/or Icarus.

usage: regress.py [--sim verilator|icarus|both] [--configs n2,n4,...]
                  [--seeds K] [--quick] [--jobs J] [--out reports/regression.md]
"""
import argparse
import concurrent.futures as cf
import os
import re
import subprocess
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BUILD = os.path.join(ROOT, "build")
RTL_F = os.path.join(ROOT, "rtl", "files.f")
TB = os.path.join(ROOT, "tb", "tb_hpc_vector_array.sv")

# name -> (parameters, generator flags)
CONFIGS = {
    "n1":  ({"NUM_LANES": 1}, {}),
    "n2":  ({"NUM_LANES": 2}, {}),
    "n4":  ({"NUM_LANES": 4}, {}),
    "n8":  ({"NUM_LANES": 8}, {}),
    "n16": ({"NUM_LANES": 16}, {}),
    # minimum queues and lane buffers, minimum latencies: every flow-control
    # path saturates constantly
    "n4_min": ({"NUM_LANES": 4, "CMD_DEPTH": 1, "TRK_DEPTH": 1, "CPL_DEPTH": 1,
                "LANE_ROB_DEPTH": 2, "LAT_FADD": 2, "LAT_FMUL": 2, "LAT_FMA": 3,
                "LAT_IMUL": 1, "RED_LAT": 2}, {}),
    # deep pipelines, deeper queues, slower reduction adder
    "n8_deep": ({"NUM_LANES": 8, "TRK_DEPTH": 12, "CPL_DEPTH": 6, "LANE_ROB_DEPTH": 16,
                 "LAT_FADD": 4, "LAT_FMUL": 5, "LAT_FMA": 8, "LAT_MISC": 3, "LAT_IMUL": 4,
                 "RED_LAT": 5, "VL_W": 12, "TID_W": 5}, {"vl-w": 12}),
    # FP add/mul/FMA-only lanes, no reduction unit, no counters
    "n2_lean": ({"NUM_LANES": 2, "RED_EN": 0, "PERF_EN": 0, "EN_FCMP": 0, "EN_INT": 0},
                {"red-en": 0, "en-fcmp": 0, "en-int": 0}),
}

# test recipe -> commands per N (scaled down for wide arrays)
TESTS = {
    "directed": 0, "full": 160, "short": 200, "nonmult": 160, "mask": 160, "bcast": 120,
    "fpexc": 160, "illegal": 120, "red": 120, "mixed": 160, "b2b": 400, "long": 3,
    "reset": 260,
}

# timing profiles: plusargs
PROFILES = {
    "clean":  "+PCMD=100 +POPND=100 +PRES=100 +PCPL=100 +HOLD=0",
    "stall":  "+PCMD=60 +POPND=70 +PRES=55 +PCPL=50 +HOLD=1 +PHOLD=25",
    "burst":  "+PCMD=90 +POPND=85 +PRES=75 +PCPL=70 +HOLD=2 +PHOLD=3",
    "stuck":  "+PCMD=95 +POPND=95 +PRES=85 +PCPL=90 +HOLD=3",
    "phase":  "+PCMD=100 +POPND=100 +PRES=90 +PCPL=90 +HOLD=4",
    "bp":     "+PCMD=100 +POPND=100 +PRES=12 +PCPL=15 +HOLD=1 +PHOLD=10",
}
RESET_PROFILES = {
    "rst_stall": "+RESET=1 +RSTWIN=250 +PCMD=70 +POPND=75 +PRES=60 +PCPL=60 +HOLD=1 +PHOLD=20",
    "rst_clean": "+RESET=1 +RSTWIN=120 +PCMD=100 +POPND=100 +PRES=100 +PCPL=100 +HOLD=0",
    "rst_bp":    "+RESET=1 +RSTWIN=400 +PCMD=100 +POPND=100 +PRES=15 +PCPL=20 +HOLD=2 +PHOLD=3",
}


def sh(cmd, **kw):
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, **kw)


def build_ref():
    r = sh(["bash", os.path.join(ROOT, "ref", "build_ref.sh")])
    if r.returncode:
        sys.exit("reference build failed:\n" + r.stdout)


def build_sim(sim, cfg, gate=None):
    params = CONFIGS[cfg][0]
    tag = f"{sim}_{cfg}" + ("_gate" if gate else "")
    out = os.path.join(BUILD, "sim", tag)
    os.makedirs(out, exist_ok=True)
    srcs = [gate] if gate else [l.strip() for l in open(RTL_F) if l.strip()]
    srcs = [s if os.path.isabs(s) else os.path.join(ROOT, s) for s in srcs]
    if gate:   # packages are still needed by the testbench
        srcs = [os.path.join(ROOT, "rtl", "lane", "hpc_vector_pkg.sv"),
                os.path.join(ROOT, "rtl", "hpc_varray_pkg.sv")] + srcs
    if sim == "verilator":
        cmd = ["verilator", "--binary", "--timing", "-O2", "-j", "2", "--timescale", "1ns/1ps",
               "-Wno-fatal", "-Wno-WIDTH", "-Wno-lint", "-Wno-style",
               "--top-module", "tb_hpc_vector_array", "-Mdir", out, "-o", "sim"]
        cmd += [f"-G{k}={v}" for k, v in params.items()]
        if gate:
            cmd += ["-DGATE", "-DSYNTHESIS"]
        cmd += srcs + [TB]
        exe = os.path.join(out, "sim")
    else:
        exe = os.path.join(out, "sim.vvp")
        cmd = ["iverilog", "-g2012", "-o", exe, "-s", "tb_hpc_vector_array"]
        cmd += [f"-Ptb_hpc_vector_array.{k}={v}" for k, v in params.items()]
        if gate:
            cmd += ["-DGATE", "-DSYNTHESIS"]
        cmd += srcs + [TB]
    t0 = time.time()
    r = sh(cmd)
    if r.returncode:
        raise RuntimeError(f"{sim} build {cfg} failed:\n{r.stdout[-4000:]}")
    return exe, time.time() - t0


def gen_test(cfg, test, seed, ncmd_scale):
    params, gflags = CONFIGS[cfg]
    n = params["NUM_LANES"]
    d = os.path.join(BUILD, "tests", cfg, f"{test}_s{seed}")
    done = os.path.join(d, "cpl.txt")
    deps = [os.path.join(ROOT, "ref", "gen_stim.py"), os.path.join(BUILD, "ref", "varray_ref")]
    if os.path.exists(done) and all(os.path.getmtime(done) > os.path.getmtime(x) for x in deps):
        return d
    os.makedirs(d, exist_ok=True)
    base = TESTS[test]
    ncmd = max(4, int(base * ncmd_scale * (4 / max(4, n)) ** 0.5)) if base else 0
    cmd = [sys.executable, "-I", os.path.join(ROOT, "ref", "gen_stim.py"), "--n", str(n),
           "--test", test, "--seed", str(seed), "--out", d, "--ncmd", str(ncmd)]
    for k, v in gflags.items():
        cmd += [f"--{k}", str(v)]
    if test == "long":
        cmd += ["--long-cap", "4096"]
    r = sh(cmd)
    if r.returncode:
        raise RuntimeError(r.stdout)
    en_fcmp = params.get("EN_FCMP", 1)
    en_int = params.get("EN_INT", 1)
    red_en = params.get("RED_EN", 1)
    r = sh([os.path.join(BUILD, "ref", "varray_ref"), str(n), str(en_fcmp), str(en_int),
            str(red_en)] + [os.path.join(d, f) for f in ("cmds.txt", "beats.txt", "res.txt", "cpl.txt")])
    if r.returncode:
        raise RuntimeError(r.stdout)
    return d


def run_one(sim, exe, cfg, test, seed, prof, plus, logdir):
    d = gen_test(cfg, test, seed, 1.0)
    log = os.path.join(logdir, f"{sim}__{cfg}__{test}_s{seed}__{prof}.log")
    args = plus.split() + [f"+DIR={d}", f"+SEED={seed * 31 + len(prof)}", "+QUIET"]
    cmd = ([exe] if sim == "verilator" else ["vvp", "-n", exe]) + args
    t0 = time.time()
    r = sh(cmd, timeout=3600)
    dt = time.time() - t0
    with open(log, "w") as f:
        f.write(" ".join(cmd) + "\n" + r.stdout)
    ok = "TEST PASSED" in r.stdout
    stats = re.search(r"^STATS (.*)$", r.stdout, re.M)
    cover = re.search(r"^COVER (.*)$", r.stdout, re.M)
    return dict(sim=sim, cfg=cfg, test=test, seed=seed, prof=prof, ok=ok, dt=dt, log=log,
                stats=stats.group(1) if stats else "", cover=cover.group(1) if cover else "",
                err=("" if ok else "\n".join(l for l in r.stdout.splitlines()
                                             if "ERROR" in l or "FAILED" in l)[:600]))


def plan(sim, cfg, seeds, quick):
    jobs = []
    for test in TESTS:
        for seed in range(1, seeds + 1):
            if test == "directed" and seed > 1:
                continue
            profs = RESET_PROFILES if test == "reset" else PROFILES
            for prof, plus in profs.items():
                if quick and prof not in ("clean", "stall", "rst_stall", "phase"):
                    continue
                if sim == "icarus" and prof not in ("clean", "stall", "rst_stall", "stuck"):
                    continue
                if test == "long" and prof not in ("clean", "stall", "bp"):
                    continue
                jobs.append((test, seed, prof, plus))
    return jobs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sim", default="verilator", choices=["verilator", "icarus", "both"])
    ap.add_argument("--configs", default="n2,n4,n8,n1,n16,n4_min,n8_deep,n2_lean")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--icarus-seeds", type=int, default=1)
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "regression.md"))
    a = ap.parse_args()
    build_ref()
    sims = ["verilator", "icarus"] if a.sim == "both" else [a.sim]
    cfgs = a.configs.split(",")
    logdir = os.path.join(ROOT, "reports", "logs")
    os.makedirs(logdir, exist_ok=True)
    results, builds = [], []
    t_start = time.time()
    for cfg in cfgs:
        for sim in sims:
            exe, bt = build_sim(sim, cfg)
            builds.append((sim, cfg, bt))
            seeds = a.seeds if sim == "verilator" else a.icarus_seeds
            jobs = plan(sim, cfg, seeds, a.quick)
            # generate stimulus serially (cached), then simulate in parallel
            for test, seed, _, _ in jobs:
                gen_test(cfg, test, seed, 1.0)
            with cf.ThreadPoolExecutor(a.jobs) as ex:
                futs = [ex.submit(run_one, sim, exe, cfg, t, s, p, pl, logdir) for t, s, p, pl in jobs]
                part = [f.result() for f in futs]
            npass = sum(r["ok"] for r in part)
            print(f"[{sim:9s}] {cfg:8s}: {npass}/{len(part)} PASS  (build {bt:.0f}s)", flush=True)
            for r in part:
                if not r["ok"]:
                    print(f"   FAIL {r['test']} s{r['seed']} {r['prof']}: {r['err']}", flush=True)
            results += part
    total = time.time() - t_start
    write_report(a.out, results, builds, total, a)
    nfail = sum(not r["ok"] for r in results)
    print(f"regression: {len(results) - nfail}/{len(results)} PASS in {total:.0f}s -> {a.out}")
    sys.exit(1 if nfail else 0)


def kv(s):
    return dict(x.split("=", 1) for x in s.split())


def write_report(path, results, builds, total, a):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tools = sh(["verilator", "--version"]).stdout.strip() + "; " + \
        sh(["iverilog", "-V"]).stdout.splitlines()[0]
    lines = ["# Module 03 regression", "",
             f"Tools: {tools}. Wall time {total:.0f} s on {os.cpu_count()} CPUs.", "",
             "Every run is a self-checking testbench run against the SoftFloat-3e reference "
             "(`ref/varray_ref`); PASS means every result beat and completion record matched "
             "in order, all protocol / X / busy checks held and (no-reset runs) all performance "
             "counters equalled the testbench's own counts.", "",
             "## Summary per configuration", "",
             "| simulator | configuration | parameters | runs | PASS | elements checked | resets injected (mid-activity) |",
             "|---|---|---|---|---|---|---|"]
    for sim, cfg, _ in builds:
        rs = [r for r in results if r["sim"] == sim and r["cfg"] == cfg]
        el = sum(int(kv(r["stats"]).get("elems", 0)) for r in rs if r["stats"])
        rst = sum(int(kv(r["stats"]).get("resets", 0)) for r in rs if r["stats"])
        rstm = sum(int(kv(r["stats"]).get("resets_mid", 0)) for r in rs if r["stats"])
        p = " ".join(f"{k}={v}" for k, v in CONFIGS[cfg][0].items())
        lines.append(f"| {sim} | {cfg} | {p} | {len(rs)} | {sum(r['ok'] for r in rs)} | {el} | {rst} ({rstm}) |")
    lines += ["", "## Per test (all seeds and timing profiles)", "",
              "| simulator | configuration | test | runs | PASS | commands | elements | result beats |",
              "|---|---|---|---|---|---|---|---|"]
    for sim, cfg, _ in builds:
        for t in TESTS:
            rs = [r for r in results if r["sim"] == sim and r["cfg"] == cfg and r["test"] == t]
            if not rs:
                continue
            st = [kv(r["stats"]) for r in rs if r["stats"]]
            lines.append(f"| {sim} | {cfg} | {t} | {len(rs)} | {sum(r['ok'] for r in rs)} | "
                         f"{sum(int(s['cmds']) for s in st)} | {sum(int(s['elems']) for s in st)} | "
                         f"{sum(int(s['beats_out']) for s in st)} |")
    lines += ["", "## Mechanism coverage (sum over all Verilator runs of a configuration)", "",
              "Cycles (or lane-cycles) in which each mechanism was active. `partial_issue`: some lanes "
              "took their element of a beat while others had not yet; `mixed_lane_out`: the head beat "
              "had results from some active lanes but not all; `hold_on_need`: a lane that still "
              "needed to take an element was held; `cpl_block`: a completion record was held back "
              "because its last result beat was not yet handed over; `red_spacing` / `red_credit`: "
              "reduction admission waited for the accumulator / for completion-queue credit.", ""]
    keys = ["partial_issue", "mixed_lane_out", "hold_on_need", "trk_full", "cmdq_full", "cpl_block",
            "red_spacing", "red_credit", "lane_rob_full", "masked_sent"]
    lines.append("| configuration | " + " | ".join(keys) + " |")
    lines.append("|---" * (len(keys) + 1) + "|")
    for sim, cfg, _ in builds:
        if sim != "verilator":
            continue
        rs = [kv(r["cover"]) for r in results if r["sim"] == sim and r["cfg"] == cfg and r["cover"]]
        lines.append(f"| {cfg} | " + " | ".join(str(sum(int(c.get(k, 0)) for c in rs)) for k in keys) + " |")
    fails = [r for r in results if not r["ok"]]
    lines += ["", f"## Failures: {len(fails)}", ""]
    for r in fails:
        lines.append(f"* {r['sim']} {r['cfg']} {r['test']} s{r['seed']} {r['prof']}: `{r['err'][:300]}`")
    lines += ["", "Timing profiles: " + "; ".join(f"`{k}`: {v}" for k, v in {**PROFILES, **RESET_PROFILES}.items()), ""]
    with open(path, "w") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
