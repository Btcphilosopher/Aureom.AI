#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-HPC Module 03 :: run_pnr.sh -- ECP5 place and route (nextpnr-ecp5)
#
# Same flow and board as the SilicaFlux-V FPGA build (fpga/ulx3s): Yosys
# synth_ecp5 -> nextpnr-ecp5 --85k --package CABGA381, 25 MHz clock on G2,
# reset on button F1 (R1), signature on the eight LEDs.  The array is wrapped
# in syn/hpc_varray_fpga_harness.sv (registered LFSR stimulus, XOR signature)
# so that every array path is register-to-register.
#
#   usage: run_pnr.sh [N ...]         default: 1 2 4 8
#          VARIANT=lean run_pnr.sh N  FP-only lanes, no reduction, no counters
#
# Results: reports/pnr/pnr[_lean]_n<N>.{log,json}.  A configuration that does
# not fit the device is recorded as such (nextpnr's own error), not skipped.
# No bitstream is programmed and nothing was run on hardware.
# =============================================================================
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/reports/pnr"
BLD="$ROOT/build/pnr"
mkdir -p "$OUT" "$BLD"
RTL="$(sed "s|^|$ROOT/|" "$ROOT/rtl/files.f" | tr '\n' ' ') $ROOT/syn/hpc_varray_fpga_harness.sv"
SEED="${SEED:-1}"
VARIANT="${VARIANT:-}"
PARAMS=""
if [ "$VARIANT" = lean ]; then
  PARAMS="-chparam EN_FCMP 0 -chparam EN_INT 0 -chparam RED_EN 0 -chparam PERF_EN 0"
fi
SFX="${VARIANT:+_$VARIANT}"

cat > "$BLD/harness.lpf" <<'EOF'
BLOCK RESETPATHS;
LOCATE COMP "clk_25mhz" SITE "G2";
IOBUF  PORT "clk_25mhz" PULLMODE=NONE IO_TYPE=LVCMOS33;
FREQUENCY PORT "clk_25mhz" 25 MHZ;
LOCATE COMP "btn[1]" SITE "R1";
IOBUF  PORT "btn[1]" PULLMODE=DOWN IO_TYPE=LVCMOS33;
LOCATE COMP "led[0]" SITE "B2";
LOCATE COMP "led[1]" SITE "C2";
LOCATE COMP "led[2]" SITE "C1";
LOCATE COMP "led[3]" SITE "D2";
LOCATE COMP "led[4]" SITE "D1";
LOCATE COMP "led[5]" SITE "E2";
LOCATE COMP "led[6]" SITE "E1";
LOCATE COMP "led[7]" SITE "H3";
IOBUF  PORT "led[0]" PULLMODE=NONE IO_TYPE=LVCMOS33 DRIVE=4;
IOBUF  PORT "led[1]" PULLMODE=NONE IO_TYPE=LVCMOS33 DRIVE=4;
IOBUF  PORT "led[2]" PULLMODE=NONE IO_TYPE=LVCMOS33 DRIVE=4;
IOBUF  PORT "led[3]" PULLMODE=NONE IO_TYPE=LVCMOS33 DRIVE=4;
IOBUF  PORT "led[4]" PULLMODE=NONE IO_TYPE=LVCMOS33 DRIVE=4;
IOBUF  PORT "led[5]" PULLMODE=NONE IO_TYPE=LVCMOS33 DRIVE=4;
IOBUF  PORT "led[6]" PULLMODE=NONE IO_TYPE=LVCMOS33 DRIVE=4;
IOBUF  PORT "led[7]" PULLMODE=NONE IO_TYPE=LVCMOS33 DRIVE=4;
EOF

NS=("$@"); [ ${#NS[@]} -eq 0 ] && NS=(1 2 4 8)
for n in "${NS[@]}"; do
  tag="pnr${SFX}_n$n"
  echo "== $tag: synth_ecp5"
  t0=$SECONDS
  yosys -q -p "read_verilog -sv -DSYNTHESIS $RTL;
    hierarchy -check -top hpc_varray_fpga_harness -chparam NUM_LANES $n $PARAMS;
    synth_ecp5 -top hpc_varray_fpga_harness -json $BLD/$tag.json;
    tee -q -o $OUT/${tag}_yosys_stat.txt stat" > "$OUT/${tag}_yosys.log" 2>&1
  ys=$?
  echo "== $tag: nextpnr-ecp5 (synth exit $ys, $((SECONDS - t0)) s)"
  t1=$SECONDS
  timeout 7200 nextpnr-ecp5 --85k --package CABGA381 --speed 6 --json "$BLD/$tag.json" \
    --lpf "$BLD/harness.lpf" --freq 25 --seed "$SEED" --timing-allow-fail \
    --report "$OUT/${tag}_report.json" -l "$OUT/$tag.log" -q > /dev/null 2>&1
  rc=$?
  dt=$((SECONDS - t1))
  python3 -I - "$OUT/$tag.log" "$OUT/$tag.json" "$rc" "$dt" "$n" "${VARIANT:-default}" <<'PY'
import json, re, sys
log, out, rc, dt, n, var = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4], sys.argv[5], sys.argv[6]
txt = open(log, errors="replace").read()
util = {m.group(1): (int(m.group(2)), int(m.group(3)))
        for m in re.finditer(r"Info:\s+(\w+):\s+(\d+)/\s*(\d+)", txt)}
f = re.findall(r"Max frequency for clock\s+'[^']*clk_25mhz[^']*': ([\d.]+) MHz", txt)
err = re.findall(r"ERROR: (.*)", txt)
res = "routed" if rc == 0 else ("does not fit: " + err[0][:160] if err else f"failed (exit {rc})")
d = dict(n=int(n), variant=var, result=res, exit=rc, seconds=int(dt), util=util,
         fmax=(f[-1] if f else ""), errors=err[:3])
json.dump(d, open(out, "w"), indent=1)
print(json.dumps(d))
PY
done
