// =============================================================================
// SilicaFlux-HPC :: hpc_varray_fpga_harness -- place-and-route timing harness
//
// The array has NUM_LANES*230 + 120 I/O signals, far more than the ULX3S
// (ECP5-85F, CABGA381) offers.  To place and route the array and measure its
// real post-route timing, this harness
//   * drives EVERY array input from registers loaded by a 64-bit LFSR
//     (lane operands are made distinct per lane so no lane can be merged with
//     another by the synthesis tool),
//   * XOR-folds EVERY array output into a registered 64-bit signature that is
//     reduced to the 8 LEDs, so no array logic is removable,
//   * synchronises the reset button.
// All array paths are therefore register-to-register.  The harness adds about
// NUM_LANES*100 + 300 flip-flops and a small XOR tree; its numbers are
// included in the reported utilisation.  This is NOT a functional test
// harness (handshake rules are deliberately not respected); functional
// verification is done in simulation.
// =============================================================================
`default_nettype none

module hpc_varray_fpga_harness #(
  parameter int NUM_LANES = 2,
  parameter bit RED_EN    = 1'b1,
  parameter bit PERF_EN   = 1'b1,
  parameter bit EN_FCMP   = 1'b1,
  parameter bit EN_INT    = 1'b1
) (
  input  wire logic       clk_25mhz,
  input  wire logic [1:1] btn,          // F1: reset (active high)
  output logic      [7:0] led
);
  localparam int N  = NUM_LANES;
  localparam int PW = hpc_varray_pkg::PC_N * 32;

  // reset synchroniser (asynchronous assert, synchronous de-assert)
  logic [1:0] rs_q;
  always_ff @(posedge clk_25mhz or posedge btn[1]) begin
    if (btn[1]) rs_q <= 2'b00;
    else        rs_q <= {rs_q[0], 1'b1};
  end
  wire logic rst_n = rs_q[1];

  // stimulus LFSR (x^64 + x^63 + x^61 + x^60 + 1)
  logic [63:0] lf_q;
  always_ff @(posedge clk_25mhz or negedge rst_n) begin
    if (!rst_n) lf_q <= 64'h0123_4567_89AB_CDEF;
    else        lf_q <= {lf_q[62:0], lf_q[63] ^ lf_q[62] ^ lf_q[60] ^ lf_q[59]};
  end

  // registered array inputs
  logic            cmd_valid, cmd_vm, cmd_red, opnd_valid, res_ready, cpl_ready, perf_clear;
  logic [4:0]      cmd_op;
  logic [2:0]      cmd_rm, cmd_bcast;
  logic [15:0]     cmd_vl;
  logic [31:0]     cmd_scalar;
  logic [7:0]      cmd_tid;
  logic [N*32-1:0] opnd_a, opnd_b, opnd_c;
  logic [N-1:0]    opnd_mask, lane_hold;
  always_ff @(posedge clk_25mhz) begin
    cmd_valid  <= lf_q[0];
    cmd_vm     <= lf_q[1];
    cmd_red    <= lf_q[2] & lf_q[3];
    opnd_valid <= lf_q[4] | lf_q[5];
    res_ready  <= lf_q[6] | lf_q[7];
    cpl_ready  <= lf_q[8] | lf_q[9];
    perf_clear <= &lf_q[15:10];
    cmd_op     <= lf_q[20:16];
    cmd_rm     <= lf_q[22:20];
    cmd_bcast  <= lf_q[25:23] & {3{lf_q[26]}};
    cmd_vl     <= lf_q[42:27];
    cmd_scalar <= lf_q[63:32];
    cmd_tid    <= lf_q[46:39];
    for (int l = 0; l < N; l++) begin
      opnd_a[l*32 +: 32] <= lf_q[31:0]  ^ (32'h9E37_79B9 * 32'(3*l + 1));
      opnd_b[l*32 +: 32] <= lf_q[63:32] ^ (32'h7F4A_7C15 * 32'(3*l + 2));
      opnd_c[l*32 +: 32] <= lf_q[47:16] ^ (32'h85EB_CA6B * 32'(3*l + 3));
    end
    opnd_mask <= N'(lf_q[63:48]) ^ N'(lf_q[15:0]);
    lane_hold <= N'(lf_q[55:40]) & N'(lf_q[23:8]) & N'(lf_q[31:16]);
  end

  logic            cmd_ready, opnd_ready, res_valid, res_last, cpl_valid, cpl_illegal, cpl_red, busy;
  logic [N*32-1:0] res_data;
  logic [N*5-1:0]  res_flags;
  logic [N-1:0]    res_mask;
  logic [7:0]      res_tid, cpl_tid;
  logic [15:0]     res_beat, cpl_count;
  logic [4:0]      cpl_flags;
  logic [31:0]     cpl_result;
  logic [PW-1:0]   perf_cnt;

  hpc_vector_array #(
    .NUM_LANES(N), .RED_EN(RED_EN), .PERF_EN(PERF_EN), .EN_FCMP(EN_FCMP), .EN_INT(EN_INT)
  ) u_array (
    .clk_i(clk_25mhz), .rst_ni(rst_n),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_op_i(cmd_op), .cmd_rm_i(cmd_rm),
    .cmd_vl_i(cmd_vl), .cmd_vm_i(cmd_vm), .cmd_bcast_i(cmd_bcast), .cmd_scalar_i(cmd_scalar),
    .cmd_red_i(cmd_red), .cmd_tid_i(cmd_tid),
    .opnd_valid_i(opnd_valid), .opnd_ready_o(opnd_ready), .opnd_a_i(opnd_a),
    .opnd_b_i(opnd_b), .opnd_c_i(opnd_c), .opnd_mask_i(opnd_mask),
    .res_valid_o(res_valid), .res_ready_i(res_ready), .res_data_o(res_data),
    .res_flags_o(res_flags), .res_mask_o(res_mask), .res_tid_o(res_tid),
    .res_beat_o(res_beat), .res_last_o(res_last),
    .cpl_valid_o(cpl_valid), .cpl_ready_i(cpl_ready), .cpl_tid_o(cpl_tid),
    .cpl_flags_o(cpl_flags), .cpl_illegal_o(cpl_illegal), .cpl_count_o(cpl_count),
    .cpl_red_o(cpl_red), .cpl_result_o(cpl_result),
    .lane_hold_i(lane_hold), .busy_o(busy),
    .perf_clear_i(perf_clear), .perf_cnt_o(perf_cnt)
  );

  // output signature: XOR fold of every array output into 64 bits
  localparam int OW = N*32 + N*5 + N + 8 + 16 + 1 + 8 + 5 + 1 + 16 + 1 + 32 + 4 + PW;
  wire logic [OW-1:0] all_out = {res_data, res_flags, res_mask, res_tid, res_beat, res_last,
                                 cpl_tid, cpl_flags, cpl_illegal, cpl_count, cpl_red, cpl_result,
                                 cmd_ready, opnd_ready, res_valid, cpl_valid ^ busy, perf_cnt};
  logic [63:0] fold;
  always_comb begin
    fold = '0;
    for (int i = 0; i < OW; i++) fold[i % 64] = fold[i % 64] ^ all_out[i];
  end
  logic [63:0] sig_q;
  always_ff @(posedge clk_25mhz or negedge rst_n) begin
    if (!rst_n) sig_q <= '0;
    else        sig_q <= {sig_q[62:0], sig_q[63]} ^ fold;
  end
  always_comb begin
    led = '0;
    for (int i = 0; i < 64; i++) led[i % 8] = led[i % 8] ^ sig_q[i];
  end
endmodule
