#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-HPC Module 03 :: run_synth.sh -- Yosys 0.33 synthesis of the array
#
# For NUM_LANES = 1, 2, 4, 8, 16 (all from unmodified RTL):
#   generic  synth -flatten; check -assert; no latches; stat; ltp -noff
#   ecp5     synth_ecp5  (Lattice ECP5: LUT4 / CCU2C / TRELLIS_FF / MULT18X18D /
#            distributed RAM)       -- SilicaFlux FPGA prototype family (ULX3S)
#   xc7      synth_xilinx -family xc7 (LUT / FD / CARRY4 / DSP48E1 / LUTRAM)
#   lean     ecp5 + xc7 with FP-only lanes (EN_FCMP=0, EN_INT=0), no reduction
#            unit, no counters
# plus
#   hier     non-flattened generic synthesis, N = 4: cells per block
#   struct   structural proof: no combinational path from any input to
#            cmd_ready_o / opnd_ready_o / res_* / cpl_* (with positive controls)
#   netlist  generic netlist of N = 2 and N = 4 for gate-level simulation
#
# Resource numbers are Yosys synthesis results (pre-place-and-route).
# Post-route numbers and timing come from syn/run_pnr.sh (nextpnr-ecp5).
# No clock frequency is derived from anything in this script.
# =============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/reports/synth"
BLD="$ROOT/build/syn"
mkdir -p "$OUT" "$BLD"
JOBS="${JOBS:-3}"
RTL="$(sed "s|^|$ROOT/|" "$ROOT/rtl/files.f" | tr '\n' ' ')"
READ="read_verilog -sv -DSYNTHESIS $RTL"
LATCH='select -assert-none t:$dlatch t:$adlatch t:$dlatchsr t:$_DLATCH_* t:$_DLATCHSR_*'
LEAN="-chparam EN_FCMP 0 -chparam EN_INT 0 -chparam RED_EN 0 -chparam PERF_EN 0"

job() {   # kind name N "extra chparams"   (log keeps warnings/errors only)
  local kind=$1 name=$2 n=$3 extra=$4 log="$OUT/${2}.log" t0=$SECONDS
  local hier="hierarchy -check -top hpc_vector_array -chparam NUM_LANES $n $extra"
  case $kind in
    generic)
      local nl=""
      if [ "$n" = 2 ] || [ "$n" = 4 ]; then
        [ -z "$extra" ] && nl="write_verilog -noattr $BLD/hpc_vector_array_n${n}_netlist.v"
      fi
      yosys -q -p "$READ; $hier; synth -top hpc_vector_array -flatten; check -assert;
        $LATCH; tee -q -o $OUT/${name}_stat.txt stat; tee -q -o $OUT/${name}_ltp.txt ltp -noff; $nl" > "$log" 2>&1 ;;
    ecp5)
      yosys -q -p "$READ; $hier; synth_ecp5 -top hpc_vector_array; check -assert;
        $LATCH; tee -q -o $OUT/${name}_stat.txt stat" > "$log" 2>&1 ;;
    xc7)
      yosys -q -p "$READ; $hier; synth_xilinx -family xc7 -flatten -noiopad -top hpc_vector_array;
        check -assert; $LATCH; tee -q -o $OUT/${name}_stat.txt stat" > "$log" 2>&1 ;;
    hier)
      yosys -q -p "$READ; $hier; synth -top hpc_vector_array; check -assert;
        $LATCH; tee -q -o $OUT/${name}_stat.txt stat -top hpc_vector_array" > "$log" 2>&1 ;;
  esac
  local rc=$?
  echo "$name exit=$rc $((SECONDS - t0)) s" | tee -a "$OUT/timing.txt"
}

: > "$OUT/timing.txt"
JOBLIST=()
for n in 16 8 4 2 1; do
  JOBLIST+=("generic|generic_n$n|$n|" "ecp5|ecp5_n$n|$n|" "xc7|xc7_n$n|$n|"
            "ecp5|ecp5_lean_n$n|$n|$LEAN" "xc7|xc7_lean_n$n|$n|$LEAN")
done
JOBLIST+=("hier|hier_n4|4|")
set +e
for j in "${JOBLIST[@]}"; do
  IFS='|' read -r kind name n extra <<< "$j"
  if [ -n "${ONLY:-}" ] && ! [[ "$name" =~ $ONLY ]]; then continue; fi
  while [ "$(jobs -rp | wc -l)" -ge "$JOBS" ]; do wait -n; done
  job "$kind" "$name" "$n" "$extra" &
done
wait
set -e
if grep -v "exit=0" "$OUT/timing.txt"; then echo "SYNTHESIS JOB FAILED"; exit 1; fi

# ----------------------------------------------------------------------------
# structural check: registered-state-only interface outputs
# ----------------------------------------------------------------------------
STOP=':-$dff:-$adff:-$dffe:-$adffe:-$sdff:-$sdffe:-$sdffce:-$aldff:-$aldffe:-$dffsr:-$dffsre'
SC="$OUT/structural_check.txt"
: > "$SC"
for n in 1 2 4 8 16; do
  yosys -q -p "$READ; hierarchy -check -top hpc_vector_array -chparam NUM_LANES $n;
    proc; flatten; memory; opt -fast;
    select -set ins i:* i:clk_i i:rst_ni %d %d;
    select -set outs o:cmd_ready_o o:opnd_ready_o o:res_* o:cpl_* o:busy_o o:perf_cnt_o;
    select -set cone @outs %ci*$STOP;
    tee -q -o $BLD/sc_n$n.txt select -list @cone @ins %i;
    select -set pc1 w:ln_valid %ci*$STOP;
    tee -q -o $BLD/pc1_n$n.txt select -list @pc1 @ins %i;
    select -set pc2 w:lo_ready %ci*$STOP;
    tee -q -o $BLD/pc2_n$n.txt select -list @pc2 @ins %i" > "$BLD/struct_n$n.log" 2>&1
  viol=$(grep -c hpc_vector_array "$BLD/sc_n$n.txt" || true)
  p1=$(grep -c opnd_valid_i "$BLD/pc1_n$n.txt" || true)
  p2=$(grep -c res_ready_i "$BLD/pc2_n$n.txt" || true)
  echo "N=$n  inputs combinationally reaching registered-interface outputs: $viol" \
       " | positive controls: lane valid <- opnd_valid_i: $p1, lane out_ready <- res_ready_i: $p2" >> "$SC"
  if [ "$viol" != 0 ] || [ "$p1" != 1 ] || [ "$p2" != 1 ]; then
    cat "$SC"; echo "STRUCTURAL CHECK FAILED"; exit 1
  fi
done
cat "$SC"
python3 -I "$ROOT/scripts/synth_summary.py" "$OUT"
echo "== synthesis done"
