# SilicaFlux-HPC · Module 03 — Scalable Parallel Vector Execution Array

**Primary source:** `rtl/hpc_vector_array.sv` · Aureom.AI | SilicaFlux-HPC

A parameterised FP32 vector execution array. `NUM_LANES` (1, 2, 4, 8 or 16) instances of the
verified Module 02 lane, `hpc_vector_lane` (**reused unmodified**), sit behind an explicit vector
issue controller and an in-order result collector, with an ordered sum / dot-product reduction
unit and performance counters.

* **Interfaces.** Commands, operand beats, result beats and completion records each have their
  own valid/ready interface.
* **Vector length.** Vectors of any length up to 2^VL_W − 1 are processed one beat of N elements
  per cycle, with tail and per-element masking. Nothing is truncated.
* **Correctness.** Results come out bit-exact, in order, losslessly under any lane stall or
  backpressure. Exception flags are aggregated per command.

## Status against the acceptance criteria (brief §10)

| Criterion | Result | Evidence |
|---|---|---|
| All configured lanes execute correctly | ✅ | NUM_LANES 1, 2, 4, 8, 16 plus three stress variants: **1632/1632** Verilator and **288/288** Icarus regression runs, **8.15 M** active-element results bit-exact against Berkeley SoftFloat-3e (`reports/regression_*.md`) |
| Masked elements do not corrupt results | ✅ | Inactive positions carry NaN/sNaN garbage operands and must read back as data 0, flags 0, mask 0. Never aggregated. Mutants M03 / M12 / M13 killed. |
| Backpressure is lossless | ✅ | Random result / completion backpressure (down to 12 % ready), five per-lane hold patterns, resets. The expected streams are consumed exactly. Mutants M09 / M11 / M16 / M25 killed. |
| Results correctly associated with commands | ✅ | Checked per beat: tid, beat index, last flag. Completions arrive in command order and only after their data. Lane-tag assertion on every collected element. Mutants M06 / M17 / M19 / M31 killed. |
| Resource use recorded from actual synthesis | ✅ | Yosys generic / ECP5 / Xilinx synthesis for every N (0 latches), and nextpnr-ecp5 place and route on the ULX3S device (`reports/synth/summary.md`, `reports/pnr/`) |

**Bring-up order (as the brief requires).**

1. Two lanes first: full test list, 138/138.
2. Then four and eight lanes: 276/276.
3. Only then one and sixteen lanes and the three stress variants.

The final campaign below re-ran everything on the frozen RTL.

Headline numbers:

| Item | Result |
|---|---|
| Regression | **1632/1632** (Verilator) + **288/288** (Icarus, 4-state) PASS, 1,467 resets injected |
| Mutation testing | **32/32** killed |
| Gate-level simulation | **34/34** PASS (netlists N = 2, 4; Verilator + Icarus) |
| Lint | clean: Verilator `-Wall` on 9 parameter sets, Icarus, Yosys |
| Interface timing | proved structurally: no combinational input → ready/valid/payload path, N = 1–16 |
| Logic depth | the array adds none: longest path = the lane's FMA segment (53 generic cells) |
| Throughput | **⌈vl/N⌉ cycles per command**, measured for every vl and N; 0.996 lane utilisation streaming |
| Reduction | defined order; bit-reproducible for a given N; equal to sequential FP32 software at N = 1 |
| Clock frequency | ECP5 post-route estimate only (below). No ASIC timing is claimed. |

## Deliverables (brief §9)

| Requested | File(s) |
|---|---|
| `hpc_vector_array.sv` | `rtl/hpc_vector_array.sv` |
| Vector issue controller | `rtl/hpc_varray_issue.sv` (with `hpc_varray_collect.sv` for completion and ordering) |
| Shared vector interface definitions | `rtl/hpc_varray_pkg.sv` (encodings, legality, counter map) + `docs/ARRAY_INTERFACE.md` (port bundles, protocols) |
| Parameterised tests | `tb/tb_hpc_vector_array.sv` (any `NUM_LANES` / queue / latency parameters), `ref/gen_stim.py` (13 test recipes), `ref/varray_ref.c`, `scripts/regress.py` (8 configurations x 6 timing profiles) |
| Synthesis reports | `reports/synth/summary.md` + raw `*_stat.txt` / `*_ltp.txt`, `reports/pnr/` (nextpnr logs / JSON) |
| Documentation | `docs/` (audit, interface, microarchitecture, reduction, verification, performance, synthesis) |
| Optional reduction stage | `rtl/hpc_varray_reduce.sv`, `docs/REDUCTION.md`, `ref/red_order_study.c` |

## Interface at a glance

```
hpc_vector_array #(NUM_LANES=2, VL_W=16, TID_W=8, CMD_DEPTH=4, TRK_DEPTH=8, CPL_DEPTH=4,
                   RED_EN=1, RED_LAT=3, PERF_EN=1, PERF_CW=32,
                   LANE_ROB_DEPTH=8, LAT_FADD=3, LAT_FMUL=3, LAT_FMA=4, LAT_MISC=1, LAT_IMUL=2,
                   EN_FCMP=1, EN_INT=1)
  clk_i, rst_ni
  cmd  : cmd_valid_i / cmd_ready_o    op[4:0] rm[2:0] vl vm bcast[2:0] scalar[31:0] red tid
  opnd : opnd_valid_i / opnd_ready_o  a b c [N*32]  mask[N]                 (one beat = N elements)
  res  : res_valid_o / res_ready_i    data[N*32] flags[N*5] mask[N] tid beat last
  cpl  : cpl_valid_o / cpl_ready_i    tid flags[4:0] illegal count red result[31:0]
  lane_hold_i[N]  busy_o  perf_clear_i  perf_cnt_o[16*PERF_CW]
```

* **Element mapping.** Element *e* goes to beat ⌊e/N⌋, lane *e* mod N. A command uses exactly
  ⌈vl/N⌉ operand beats and, if elementwise, produces ⌈vl/N⌉ result beats.
* **Active elements.** An element is active when `legal & (e < vl) & (!vm | mask)`. An inactive
  position is not executed, outputs data 0 / flags 0 / mask 0, and is never aggregated.
* **Operand sources.** Operands are per-lane, supplied through the streaming `opnd` interface,
  optionally replaced by the broadcast `scalar` (vector-scalar forms such as AXPY). There is no
  SRAM gather and no cache-coherent interface.
* **Ordering.**
  * Completion records arrive in command order.
  * A command's completion is presented only after its last result beat has been handed over.
  * `cpl_flags_o` is the OR over the command's active elements, plus every reduction add.
* **Operations.** All Module 02 lane operations; FADD, FMUL and FMADD are the mandatory ones.
  Adding `red=1` gives a sum reduction: FMV → Σa, FMUL → Σa·b (dot product).

Full specification: `docs/ARRAY_INTERFACE.md`. Documents cited as "Module 02 `docs/…`" are in
`SilicaFlux-main/SilicaFlux2.0/silicaflux-hpc-m02-vector-lane.zip`, whose `rtl/` is reproduced
unmodified in `rtl/lane/`. Reduction order, precision and reproducibility:
`docs/REDUCTION.md`.

## Measured performance (cycle counts, RTL simulation)

All figures are cycle counts from RTL simulation, default configuration. Every run is also a
passing self-checking test (`reports/performance.md`, `docs/PERFORMANCE.md`).

| Metric | Measured |
|---|---|
| Operand beat → result beat (FMV / FADD, FMUL / FMADD) | 3 / 5 / 6 cycles, every N |
| Last beat → completion, elementwise | result + 1, every N |
| Last beat → completion, sum / dot (N = 1 → 16) | 7 → 19 / 9 → 21 cycles (+3 per doubling of N) |
| Cycles per vector operation, back to back | exactly ⌈vl/N⌉ for vl = 1 … 64·N, N = 1 … 16 (no per-command overhead) |
| Streaming FMADD, 32 × 64·N elements | 0.996 lane utilisation; 15.63 accepted = completed elements per cycle at N = 16 |
| Dot product (FMUL + sum) | N / `RED_LAT` elements per cycle (5.23 at N = 16, ideal 5.33) |
| Out-of-phase lane holds (no cycle with all lanes free) | 0.496 utilisation, against a 0.5 bound. Partial issue never starves. |
| One lane free 1/16 of the time | 0.061 utilisation: the array paces at its slowest lane, losslessly |

**Theoretical peak, not a benchmark.** It assumes II = 1 per lane (measured), 2 FLOP per FMA, a
never-starved operand stream and the stated clock: 2·N·f.

* At the ULX3S's 25 MHz: N = 4 gives 200 MFLOP/s.
* At the 4-lane design's 32.15 MHz post-route estimate: 257 MFLOP/s.

Sustaining that needs 16 B per element of stream bandwidth, 1.6 GB/s at N = 4 and 25 MHz. That is
16× what the 32-bit DataFabric bus provides.

## FPGA resources (actual synthesis and place and route)

Target: ULX3S, Lattice **LFE5U-85F** (83,640 LUT4, 156 MULT18X18D). This is the SilicaFlux
FPGA prototype board. Flow: Yosys `synth_ecp5` + nextpnr-ecp5, inside a register-to-register
timing harness. Fmax is nextpnr's post-route estimate (speed 6, seed 1); nothing was run on
hardware.

| configuration | N | result | LUTs | MULT18X18D | Fmax (est.) |
|---|---|---|---|---|---|
| default (all units, reduction, counters) | 1 | routed | 12,651 (15 %) | 11 | 32.21 MHz |
| default | 2 | routed | 22,453 (27 %) | 22 | 32.15 MHz |
| default | 4 | routed | 41,971 (50 %) | 44 | 32.15 MHz |
| default | 8 | routed, **marginal**: no headroom, 73-minute route | 81,007 (97 %) | 88 | 31.58 MHz |
| default | 16 | **does not fit**: synthesis needs 154,925 LUT4-eq (185 %) and 176 MULT18X18D | | | |
| lean (FP add/mul/FMA only) | 4 | routed | 30,834 (37 %) | 32 | 31.91 MHz |
| lean | 8 | routed | 60,367 (72 %) | 64 | 30.75 MHz |
| lean | 16 | **does not fit** (117,498 LUT4-eq, 140 %) | | | |

* With all features, 4 lanes fit comfortably. 8 full lanes route but leave no room for anything
  else, so the lean build (72 %) is the practical 8-lane prototype. 16 lanes need a bigger
  device.
* The critical path is always inside a lane's FMA (Module 02), never in the array control.
* On Xilinx 7-series (Yosys estimate), 8 full lanes use 64 % of an Artix-7 100T, and 16 full
  lanes exceed it.

Details: `docs/SYNTHESIS.md`.

## Contents

```
rtl/  hpc_vector_array.sv     top: lanes (generate), queues, completion gating, counters
      hpc_varray_issue.sv     vector issue controller (command queue, beats, masks, per-lane issue)
      hpc_varray_collect.sv   in-order result collector, flag/count aggregation
      hpc_varray_reduce.sv    ordered FP32 sum-reduction tree + accumulator, completion-token stage
      hpc_varray_fifo.sv      register FIFO (command, tracking and completion queues)
      hpc_varray_perf.sv      16 saturating performance counters
      hpc_varray_pkg.sv       shared interface definitions: encodings, legality, counter map
      lane/                   Module 02 lane RTL, unmodified (SHA256SUMS)
      files.f
tb/   tb_hpc_vector_array.sv  self-checking testbench (Verilator + Icarus, RTL and gate level)
ref/  varray_ref.c            independent reference of the array spec (SoftFloat-3e)
      red_order_study.c       reduction-order vs sequential vs exact study
      gen_stim.py             stimulus generator (corner-biased FP32, masks, framing)
      build_ref.sh
scripts/ run_all.sh regress.py mutate.py gatesim.py characterize.py lint.sh synth_summary.py
syn/  run_synth.sh            Yosys generic / ECP5 / Xilinx synthesis, structural interface check
      run_pnr.sh              nextpnr-ecp5 place and route (ULX3S LFE5U-85F)
      hpc_varray_fpga_harness.sv   P&R timing harness (LFSR stimulus, XOR signature)
docs/ AUDIT.md ARRAY_INTERFACE.md MICROARCHITECTURE.md REDUCTION.md VERIFICATION.md
      PERFORMANCE.md SYNTHESIS.md
reports/ regression_verilator.md regression_icarus.md mutation.md gatesim.md lint.txt
         performance.md performance.json reduction_order_study.md synth/ pnr/ logs*/
third_party/ berkeley-softfloat-3 (Release 3e, BSD-3-Clause, unmodified) + SOFTFLOAT_SHA256SUMS
```

## Reproduce

Requires Verilator 5.020, Icarus Verilog 12, Yosys 0.33 and nextpnr-ecp5 0.6 (Ubuntu 24.04
packages, the SilicaFlux tool baseline), plus gcc and Python ≥ 3.10.

Everything:

```bash
bash scripts/run_all.sh
```

That takes several hours on 4 cores; 16-lane synthesis and place and route dominate.

Individual steps:

```bash
make ref && make lint && make quick
```

```bash
make regress-verilator
```

```bash
make mutate && make characterize
```

```bash
make synth && make gatesim && make pnr
```

## Known limitations and next steps

* **FPGA size.** See the table above for which configurations fit the ULX3S LFE5U-85F. Larger
  arrays need a larger device (ECP5 has no bigger part than 85F), the lean configuration, or an
  ASIC flow.
* **Clock.** ECP5 post-route Fmax is limited by the lane's FMA datapath (Module 02), not by the
  array control. No ASIC timing has been run. The next step is the SilicaFlux OpenROAD flow on
  `NUM_LANES = 4` (`docs/SYNTHESIS.md` §4).
* **A beat completes only when its slowest lane has taken its element.** One persistently slow
  lane therefore throttles the whole array: the `stuck` profile measures about 1/16 utilisation.
  This is inherent to beat-synchronous SIMD. Per-lane decoupling queues would let lanes run
  ahead, but cannot raise beat throughput above the slowest lane.
* **Masked elements** are sent to their lane with `lane_en = 0`. That keeps `opnd_ready_o`
  registered, but it needs the lane to have a free slot, which can cause a small false stall
  when lane buffer occupancies diverge under backpressure.
* **Reduction.**
  * Throughput is N / `RED_LAT` elements per cycle: one FP32 accumulator with one add in flight.
  * The accumulator is FP32 and the dot product is unfused.
  * Results are bit-reproducible for a given N, and equal to sequential software only at N = 1.

  See `docs/REDUCTION.md` §6 for options.
* **Operand supply.** There is a streaming interface only. No VRF reader or DMA adapter is
  included. Elementwise FMA needs 16 B per element; the 32-bit DataFabric bus delivers 0.1 GB/s
  at 25 MHz, against 1.6 GB/s needed by 4 lanes (`docs/PERFORMANCE.md`).
* **Verification.** Simulation, mutation, gate-level simulation and structural proof only. There
  is no formal proof, nothing was run on hardware, and TestFloat was not run through the array.
  `NUM_LANES` is limited to 1–16.
* **Repository.** Two independent FP32 FMA implementations exist: Module 01 `fp32_fma` and
  Module 02 `hpc_fp32_fma`. Consolidation is recommended (`docs/AUDIT.md` §3).

## Licensing

Berkeley SoftFloat Release 3e is © The Regents of the University of California, BSD-3-Clause
(`third_party/berkeley-softfloat-3/COPYING.txt`), vendored unmodified. It is used only by the
verification reference. The SilicaFlux-HPC sources follow the licensing of the Aureom.AI
repository.
