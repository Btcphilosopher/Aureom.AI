#!/usr/bin/env python3
"""SilicaFlux-HPC :: gen_stim.py -- vector-array stimulus generator.

Writes the command stream and the operand-beat stream for one test:

  cmds.txt   seg idx op rm vl vm bcast scalar red tid
  beats.txt  seg idx mask a0 b0 c0 ... a{N-1} b{N-1} c{N-1}

(all hex).  Expected results are produced separately by ref/varray_ref
(SoftFloat-based) so that the generator never decides what is correct.

Every command is framed with exactly ceil(vl / N) operand beats, whatever its
legality, broadcast flags or operation (docs/ARRAY_INTERFACE.md section 3).
Operand words of tail / masked / unused positions are random (often NaN or
signalling NaN) so that a leak from an inactive position is visible.

usage: gen_stim.py --n N --test T --seed S --out DIR [--ncmd K] [--segs S]
                   [--en-fcmp 0|1] [--en-int 0|1] [--red-en 0|1] [--vl-w W]
"""
import argparse
import os
import random
import struct

OP = dict(FMV=0x00, FADD=0x01, FSUB=0x02, FMUL=0x03, FMADD=0x04, FMSUB=0x05, FNMSUB=0x06,
          FNMADD=0x07, FMIN=0x08, FMAX=0x09, FEQ=0x0A, FLT=0x0B, FLE=0x0C, IADD=0x10,
          IMUL=0x11)
RESERVED = [0x0D, 0x0E, 0x0F] + list(range(0x12, 0x20))
MANDATORY = ["FADD", "FMUL", "FMADD"]
FP_ARITH = ["FMV", "FADD", "FSUB", "FMUL", "FMADD", "FMSUB", "FNMSUB", "FNMADD"]
ALL_OPS = list(OP)

TESTS = ["directed", "full", "short", "nonmult", "mask", "bcast", "fpexc", "illegal",
         "red", "mixed", "long", "b2b", "reset", "perf"]


def f2u(x):
    return struct.unpack("<I", struct.pack("<f", x))[0]


def u2f(u):
    return struct.unpack("<f", struct.pack("<I", u & 0xFFFFFFFF))[0]


class Gen:
    def __init__(self, n, seed, args):
        self.n = n
        self.r = random.Random(seed)
        self.a = args
        self.cmds = []          # (seg, idx, op, rm, vl, vm, bcast, scalar, red, tid)
        self.beats = []         # (seg, idx, mask, [(a,b,c)]*N)
        self.seg = 0

    # ------------------------------------------------------------ FP32 values
    def fval(self, kind=None):
        r = self.r
        s = r.getrandbits(1) << 31
        k = kind or r.choices(
            ["zero", "sub", "minn", "maxn", "inf", "qnan", "snan", "one", "int", "any",
             "mid", "big", "tiny"],
            weights=[4, 6, 2, 3, 3, 3, 3, 3, 4, 10, 30, 6, 6])[0]
        if k == "zero": return s
        if k == "sub":  return s | r.choice([1, 2, 0x7FFFFF, 0x400000, r.getrandbits(23) or 1])
        if k == "minn": return s | (0x00800000 + r.choice([0, 1, 2, r.getrandbits(8)]))
        if k == "maxn": return s | (0x7F7FFFFF - r.choice([0, 1, r.getrandbits(8)]))
        if k == "inf":  return s | 0x7F800000
        if k == "qnan": return s | 0x7FC00000 | r.getrandbits(22)
        if k == "snan": return s | 0x7F800000 | (r.getrandbits(22) or 1)
        if k == "one":  return s | 0x3F800000
        if k == "int":  return f2u(float(r.randint(-64, 64)))
        if k == "any":  return r.getrandbits(32)
        if k == "big":  return s | (r.randint(0xE0, 0xFE) << 23) | r.getrandbits(23)
        if k == "tiny": return s | (r.randint(0x01, 0x20) << 23) | r.getrandbits(23)
        return s | (r.randint(100, 154) << 23) | r.getrandbits(23)      # mid

    def nice(self):
        """Moderate normal values (reductions that do not saturate to inf/NaN)."""
        r = self.r
        return (r.getrandbits(1) << 31) | (r.randint(110, 140) << 23) | r.getrandbits(23)

    def triple(self, op, style):
        r = self.r
        if style == "nice":
            return self.nice(), self.nice(), self.nice()
        a, b, c = self.fval(), self.fval(), self.fval()
        if op in ("FADD", "FSUB") and r.random() < 0.25:           # cancellation
            b = (a ^ (0x80000000 if op == "FADD" else 0)) ^ r.choice([0, 1, 2, 3])
        if op in ("FMADD", "FMSUB", "FNMSUB", "FNMADD") and r.random() < 0.25:
            fa, fb = u2f(a), u2f(b)
            try:
                p = fa * fb
                c = f2u(-p if op in ("FMADD", "FNMADD") else p) ^ r.choice([0, 1, 2])
            except (OverflowError, ValueError):
                pass
        return a, b, c

    def garbage(self):
        return self.fval(self.r.choice(["snan", "qnan", "any", "inf"]))

    # ------------------------------------------------------------ commands
    def add_cmd(self, op, vl, rm=None, vm=0, bcast=0, scalar=None, red=0, tid=None,
                mask_style="random", val_style="corner"):
        r, n = self.r, self.n
        idx = len(self.cmds)
        if not 0 <= vl < (1 << self.a.vl_w):
            raise ValueError("vl %d outside the %d-bit vl range" % (vl, self.a.vl_w))
        opc = OP[op] if isinstance(op, str) else op
        opname = op if isinstance(op, str) else "RSVD"
        if rm is None:
            rm = r.randint(0, 4)
        if scalar is None:
            scalar = self.nice() if (red or val_style == "nice") else self.fval()
        if tid is None:
            tid = idx & 0xFF if r.random() < 0.7 else r.getrandbits(8)
        self.cmds.append((self.seg, idx, opc, rm, vl, vm, bcast, scalar, red, tid))
        nb = (vl + n - 1) // n
        for g in range(nb):
            if mask_style == "ones":
                mask = (1 << n) - 1
            elif mask_style == "zeros":
                mask = 0
            elif mask_style == "alt":
                mask = int("01" * 8, 2) & ((1 << n) - 1) if g % 2 else int("10" * 8, 2) & ((1 << n) - 1)
            else:
                mask = r.choice([r.getrandbits(n), r.getrandbits(n), (1 << n) - 1, 0,
                                 1 << r.randrange(n)])
            lanes = []
            for l in range(n):
                e = g * n + l
                active_pos = e < vl and (not vm or (mask >> l) & 1)
                if active_pos:
                    lanes.append(self.triple(opname, val_style))
                else:
                    lanes.append((self.garbage(), self.garbage(), self.garbage()))
            self.beats.append((self.seg, idx, mask, lanes))

    def rnd_op(self, pool=None, mand_weight=0.6):
        r = self.r
        if pool is None:
            if r.random() < mand_weight:
                return r.choice(MANDATORY)
            pool = ALL_OPS
        return r.choice(pool)

    def legal_ops(self):
        ops = list(FP_ARITH)
        if self.a.en_fcmp: ops += ["FMIN", "FMAX", "FEQ", "FLT", "FLE"]
        if self.a.en_int:  ops += ["IADD", "IMUL"]
        return ops

    def vl_of(self, kind):
        r, n = self.r, self.n
        if kind == "full":    return n * r.randint(1, 8)
        if kind == "short":   return r.randint(1, max(1, n - 1))
        if kind == "nonmult": return n * r.randint(0, 6) + r.randint(1, max(1, n - 1)) if n > 1 else r.randint(1, 37)
        if kind == "mixed":
            return r.choice([0, 1, n, n + 1, r.randint(1, 4 * n), r.randint(1, 16 * n),
                             r.randint(1, 64 * n)])
        raise ValueError(kind)

    # ------------------------------------------------------------ test recipes
    def build(self, test, ncmd):
        r, n = self.r, self.n
        legal = self.legal_ops()
        if test == "directed":
            for op in MANDATORY:
                for vl in sorted({1, max(1, n - 1), n, n + 1, 2 * n, 3 * n + 1}):
                    self.add_cmd(op, vl, rm=0)
            self.add_cmd("FADD", 0)
            self.add_cmd("FMADD", 2 * n + 1, vm=1, mask_style="alt")
            self.add_cmd("FMUL", 2 * n, vm=1, mask_style="zeros")
            self.add_cmd("FMUL", 2 * n, vm=1, mask_style="ones")
            self.add_cmd("FMADD", 3 * n, bcast=0b001)           # a = scalar (AXPY form)
            self.add_cmd("FADD", n + 1, bcast=0b010)
            self.add_cmd(0x1F, n + 1)                           # reserved opcode
            self.add_cmd("FADD", n, rm=7)                       # illegal rm
            if self.a.red_en:
                self.add_cmd("FMV", 4 * n + 3, red=1, val_style="nice", scalar=0)
                self.add_cmd("FMUL", 4 * n + 3, red=1, val_style="nice", scalar=0)
                self.add_cmd("FMUL", 0, red=1, scalar=f2u(1.5))
                self.add_cmd("FMUL", 3 * n, red=1, vm=1, mask_style="zeros", scalar=f2u(-2.0))
            for op in legal:
                self.add_cmd(op, n + 1)
            return
        for _ in range(ncmd):
            if test in ("full", "short", "nonmult"):
                self.add_cmd(self.rnd_op(legal), self.vl_of(test))
            elif test == "mask":
                self.add_cmd(self.rnd_op(legal), self.vl_of(r.choice(["full", "nonmult", "short"])),
                             vm=1, mask_style=r.choice(["random", "random", "ones", "zeros", "alt"]))
            elif test == "bcast":
                self.add_cmd(self.rnd_op(legal), self.vl_of("mixed"), bcast=r.randint(1, 7),
                             vm=r.getrandbits(1))
            elif test == "fpexc":
                self.add_cmd(self.rnd_op(FP_ARITH, 0.7), self.vl_of(r.choice(["full", "nonmult"])),
                             vm=r.getrandbits(1), rm=r.randint(0, 4))
            elif test == "illegal":
                kind = r.randint(0, 3)
                if kind == 0:
                    self.add_cmd(r.choice(RESERVED), self.vl_of("mixed"))
                elif kind == 1:
                    self.add_cmd(r.choice(FP_ARITH[1:]), self.vl_of("mixed"), rm=r.randint(5, 7))
                elif kind == 2:
                    self.add_cmd(r.choice(ALL_OPS), self.vl_of("mixed"), red=1,
                                 bcast=r.choice([0, 1, 2, 4]), rm=r.randint(0, 7))
                else:
                    self.add_cmd(self.rnd_op(legal), self.vl_of("mixed"), vm=r.getrandbits(1))
            elif test == "red":
                if not self.a.red_en:
                    self.add_cmd(r.choice(["FMV", "FMUL"]), self.vl_of("mixed"), red=1)
                    continue
                op = r.choice(["FMV", "FMUL", "FMUL", "FMV", "FADD", "FMADD", "FSUB", "FNMADD"])
                style = r.choice(["nice", "nice", "nice", "corner"])
                init = r.choice([0, 0x80000000, self.nice(), self.fval()])
                self.add_cmd(op, self.vl_of(r.choice(["mixed", "full", "nonmult"])), red=1,
                             vm=r.getrandbits(1), scalar=init, val_style=style)
                if r.random() < 0.3:                        # interleave elementwise
                    self.add_cmd(self.rnd_op(legal), self.vl_of("short"))
            elif test in ("mixed", "reset"):
                p = r.random()
                if p < 0.08:
                    self.add_cmd(r.choice(RESERVED + ["FADD"]), self.vl_of("mixed"),
                                 rm=r.choice([0, 5, 6, 7]))
                elif p < 0.25 and self.a.red_en:
                    self.add_cmd(r.choice(FP_ARITH), self.vl_of("mixed"), red=1,
                                 vm=r.getrandbits(1), val_style=r.choice(["nice", "corner"]))
                else:
                    self.add_cmd(self.rnd_op(legal), self.vl_of("mixed"), vm=r.getrandbits(1),
                                 bcast=r.choice([0, 0, 0, r.randint(1, 7)]))
                if test == "reset" and r.random() < 0.12:
                    self.seg += 1
            elif test == "long":
                vmax = (1 << self.a.vl_w) - 1
                vl = r.choice([vmax, r.randint(vmax // 2, vmax), r.randint(min(1000, vmax), min(5000, vmax))])
                vl = min(vl, self.a.long_cap * n) if self.a.long_cap else vl
                if not self.cmds:
                    vl = vmax                           # first command: maximum vl, always
                self.add_cmd(self.rnd_op(MANDATORY), vl, vm=r.getrandbits(1))
            elif test == "perf":                         # characterisation workload
                self.add_cmd(self.a.op, self.a.vl, rm=0, vm=self.a.vm, red=self.a.red,
                             val_style="nice", mask_style="ones" if not self.a.vm else "random",
                             scalar=0 if self.a.red else None)
            elif test == "b2b":
                self.add_cmd(self.rnd_op(legal), r.choice([1, n, n, 2 * n, r.randint(1, 2 * n)]),
                             vm=r.choice([0, 0, 1]))
            else:
                raise ValueError(test)

    def write(self, out):
        os.makedirs(out, exist_ok=True)
        with open(os.path.join(out, "cmds.txt"), "w") as f:
            for c in self.cmds:
                f.write("%x %x %x %x %x %x %x %08x %x %x\n" % c)
        with open(os.path.join(out, "beats.txt"), "w") as f:
            for seg, idx, mask, lanes in self.beats:
                f.write("%x %x %x " % (seg, idx, mask))
                f.write(" ".join("%08x %08x %08x" % t for t in lanes))
                f.write("\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, required=True)
    ap.add_argument("--test", choices=TESTS, required=True)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", required=True)
    ap.add_argument("--ncmd", type=int, default=200)
    ap.add_argument("--en-fcmp", type=int, default=1)
    ap.add_argument("--en-int", type=int, default=1)
    ap.add_argument("--red-en", type=int, default=1)
    ap.add_argument("--vl-w", type=int, default=16)
    ap.add_argument("--op", default="FMADD", help="perf test: element operation")
    ap.add_argument("--vl", type=int, default=64, help="perf test: vector length")
    ap.add_argument("--red", type=int, default=0, help="perf test: sum-reduction")
    ap.add_argument("--vm", type=int, default=0, help="perf test: masked")
    ap.add_argument("--long-cap", type=int, default=0,
                    help="cap long-test vl at this many beats (0 = no cap)")
    a = ap.parse_args()
    g = Gen(a.n, a.seed * 7919 + a.n * 104729 + TESTS.index(a.test), a)
    g.build(a.test, a.ncmd)
    g.write(a.out)
    print("gen_stim: N=%d test=%s seed=%d cmds=%d beats=%d segs=%d" %
          (a.n, a.test, a.seed, len(g.cmds), len(g.beats), g.seg + 1))


if __name__ == "__main__":
    main()
