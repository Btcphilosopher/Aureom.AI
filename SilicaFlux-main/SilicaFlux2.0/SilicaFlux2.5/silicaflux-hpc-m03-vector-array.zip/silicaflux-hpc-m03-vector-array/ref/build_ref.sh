#!/usr/bin/env bash
# =============================================================================
# Build the independent reference from vendored, unmodified sources:
#   third_party/berkeley-softfloat-3  (Release 3e, commit f74b1e4, BSD-3-Clause;
#                                      the same copy Module 01 vendors)
# Outputs (build/ref/):
#   softfloat-RISCV/softfloat.a   SoftFloat, RISCV specialisation
#   varray_ref                    array-specification reference model
#   red_order_study               reduction-order characterisation tool
# Idempotent.
# =============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SF="$ROOT/third_party/berkeley-softfloat-3"
OUT="$ROOT/build/ref"
JOBS="${JOBS:-$(nproc)}"
mkdir -p "$OUT"

( cd "$ROOT/third_party" && sha256sum --quiet -c SOFTFLOAT_SHA256SUMS ) \
  || { echo "SoftFloat sources do not match SOFTFLOAT_SHA256SUMS"; exit 1; }

dir="$OUT/softfloat-RISCV"
if [ ! -f "$dir/softfloat.a" ]; then
  rm -rf "$dir"; cp -r "$SF/build/Linux-x86_64-GCC" "$dir"
  make -s -C "$dir" -j"$JOBS" SOURCE_DIR="$SF/source" SPECIALIZE_TYPE=RISCV softfloat.a
fi

for t in varray_ref red_order_study; do
  if [ ! -x "$OUT/$t" ] || [ "$ROOT/ref/$t.c" -nt "$OUT/$t" ]; then
    gcc -O2 -std=c11 -Wall -Wextra -Werror -I"$SF/source/include" -I"$dir" \
      "$ROOT/ref/$t.c" "$dir/softfloat.a" -lm -o "$OUT/$t"
  fi
done
echo "reference built: $OUT/varray_ref $OUT/red_order_study"
