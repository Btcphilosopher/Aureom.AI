/* =============================================================================
 * SilicaFlux-HPC :: red_order_study -- how much does the reduction order matter?
 *
 * For random FP32 dot products it computes, with SoftFloat-3e (RNE):
 *   p_i      = fl(a_i * b_i)                          (the array's FMUL element op)
 *   seq      = (((0 + p_0) + p_1) + ...)              strict sequential FP32 software
 *   arr[N]   = the array's documented order for NUM_LANES = N
 *              (per-beat pairwise tree over lane index, then in-order FP32
 *               accumulation of beat sums starting from 0)
 *   exact    = sum of the p_i accumulated EXACTLY in a 320-bit fixed-point
 *              accumulator, then rounded once to FP32 (RNE)
 * and reports, per vector length / data distribution:
 *   * how often arr[N] is bitwise identical to seq,
 *   * the error of seq and arr[N] against exact, in units of the exact
 *     result's ulp (max and mean).
 * It also asserts arr[1] == seq on every trial (NUM_LANES = 1 is defined to
 * be strict sequential accumulation).
 *
 *   red_order_study [trials] [seed]   -> markdown on stdout
 * ===========================================================================*/
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "softfloat.h"

static uint64_t rs = 88172645463325252ull;
static uint64_t xr(void) { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
static double ur(void) { return (double)(xr() >> 11) / 9007199254740992.0; }

static float32_t F(uint32_t v) { float32_t x; x.v = v; return x; }
static uint32_t add(uint32_t a, uint32_t b) { return f32_add(F(a), F(b)).v; }
static uint32_t fl32(double d) { float f = (float)d; uint32_t u; memcpy(&u, &f, 4); return u; }

/* ---- the array's order (docs/REDUCTION.md) ---------------------------------- */
static uint32_t arr_sum(const uint32_t *x, int len, int n, uint32_t init) {
    uint32_t acc = init;
    for (int g = 0; g * n < len; g++) {
        uint32_t v[16]; bool p[16];
        for (int l = 0; l < n; l++) { int e = g * n + l; p[l] = e < len; v[l] = p[l] ? x[e] : 0; }
        for (int w = n; w > 1; w /= 2)
            for (int j = 0; j < w / 2; j++) {
                if (p[2*j] && p[2*j+1]) { v[j] = add(v[2*j], v[2*j+1]); p[j] = true; }
                else if (p[2*j])        { v[j] = v[2*j]; p[j] = true; }
                else if (p[2*j+1])      { v[j] = v[2*j+1]; p[j] = true; }
                else                     p[j] = false;
            }
        if (p[0]) acc = add(acc, v[0]);
    }
    return acc;
}

/* ---- exact accumulation: value = sum m * 2^(e) with e >= -149 --------------- */
#define LIMBS 12                      /* 12 x 32 bit = 384 bits, bit 0 = 2^-149 */
typedef struct { int64_t w[LIMBS]; } acc_t;

static void ex_add(acc_t *a, uint32_t u) {
    uint32_t ex = (u >> 23) & 0xFF, m = u & 0x7FFFFF;
    if (ex == 0xFF) { fprintf(stderr, "non-finite in exact sum\n"); exit(2); }
    if (ex) m |= 0x800000; else ex = 1;
    int sh = (int)ex - 1;             /* m * 2^(ex-150) = m << (ex-1) in units of 2^-149 */
    uint64_t lo = (uint64_t)m << (sh % 32);
    int k = sh / 32;
    int64_t s = (u >> 31) ? -1 : 1;
    a->w[k]     += s * (int64_t)(lo & 0xFFFFFFFFu);
    a->w[k + 1] += s * (int64_t)(lo >> 32);
}
/* normalise limbs to [0, 2^32) with signed top; return sign and magnitude */
static int ex_norm(acc_t *a, uint32_t mag[LIMBS]) {
    int64_t c = 0;
    for (int i = 0; i < LIMBS; i++) { int64_t t = a->w[i] + c; c = t >> 32; a->w[i] = t & 0xFFFFFFFF; }
    int neg = c < 0;
    if (neg) {                         /* two's complement negate */
        uint64_t carry = 1;
        for (int i = 0; i < LIMBS; i++) { uint64_t t = (uint64_t)(~(uint32_t)a->w[i]) + carry; mag[i] = (uint32_t)t; carry = t >> 32; }
    } else for (int i = 0; i < LIMBS; i++) mag[i] = (uint32_t)a->w[i];
    return neg;
}
static int bit(const uint32_t *m, int i) { return (m[i / 32] >> (i % 32)) & 1; }
static uint32_t ex_round(acc_t *a) {   /* RNE to FP32 */
    uint32_t m[LIMBS]; int neg = ex_norm(a, m);
    int top = -1;
    for (int i = LIMBS * 32 - 1; i >= 0; i--) if (bit(m, i)) { top = i; break; }
    if (top < 0) return 0;                       /* exact zero -> +0 (RNE) */
    int lsb = top - 23; if (lsb < 0) lsb = 0;    /* subnormal range: lsb fixed at 2^-149 */
    uint64_t sig = 0;
    for (int i = top; i >= lsb; i--) sig = (sig << 1) | (uint64_t)bit(m, i);
    int g = lsb > 0 ? bit(m, lsb - 1) : 0, st = 0;
    for (int i = lsb - 2; i >= 0; i--) if (bit(m, i)) { st = 1; break; }
    if (g && (st || (sig & 1))) sig++;
    int e = lsb;                                  /* value = sig * 2^(e-149) */
    if (sig >> 24) { sig >>= 1; e++; }
    uint32_t r;
    if (sig < 0x800000) r = (uint32_t)sig;        /* subnormal (e == 0) */
    else { int bexp = e + 1; if (bexp >= 255) r = 0x7F800000; else r = ((uint32_t)bexp << 23) | ((uint32_t)sig & 0x7FFFFF); }
    return r | (neg ? 0x80000000u : 0);
}
static double ulp_err(uint32_t got, uint32_t ex) {
    float g, e; memcpy(&g, &got, 4); memcpy(&e, &ex, 4);
    if (!isfinite(g) || !isfinite(e)) return NAN;
    uint32_t ea = ex & 0x7FFFFFFF;
    int bexp = (int)(ea >> 23); if (bexp == 0) bexp = 1;
    double ulp = ldexp(1.0, bexp - 150);
    return fabs((double)g - (double)e) / ulp;
}

int main(int argc, char **argv) {
    int trials = argc > 1 ? atoi(argv[1]) : 2000;
    if (argc > 2) rs ^= (uint64_t)atoll(argv[2]) * 0x9E3779B97F4A7C15ull;
    softfloat_roundingMode = softfloat_round_near_even;
    softfloat_detectTininess = softfloat_tininess_afterRounding;
    static const int lens[] = { 16, 100, 1000, 10000 };
    static const char *dist[] = { "uniform [0,1) (all positive)", "uniform [-1,1) (signed)",
                                  "signed, exponent spread 2^-20..2^20" };
    static const int NS[] = { 2, 4, 8, 16 };
    static uint32_t a[10000], b[10000], p[10000];

    printf("Trials per row: %d. Products rounded to FP32 (RNE), sums in FP32 (RNE).\n\n", trials);
    printf("| distribution | length | seq err max / mean (ulp) |");
    for (int k = 0; k < 4; k++) printf(" N=%d: =seq %% | N=%d err max / mean |", NS[k], NS[k]);
    printf("\n|---|---|---|");
    for (int k = 0; k < 4; k++) printf("---|---|");
    printf("\n");
    long mism1 = 0;
    for (int d = 0; d < 3; d++)
        for (int li = 0; li < 4; li++) {
            int len = lens[li];
            int same[4] = {0}; double emax[5] = {0}, esum[5] = {0}; int ecnt[5] = {0};
            for (int t = 0; t < trials; t++) {
                acc_t ex; memset(&ex, 0, sizeof ex);
                for (int i = 0; i < len; i++) {
                    double x, y;
                    if (d == 0) { x = ur(); y = ur(); }
                    else if (d == 1) { x = 2 * ur() - 1; y = 2 * ur() - 1; }
                    else { x = (2 * ur() - 1) * ldexp(1, (int)(xr() % 41) - 20); y = 2 * ur() - 1; }
                    a[i] = fl32(x); b[i] = fl32(y);
                    p[i] = f32_mul(F(a[i]), F(b[i])).v;
                    ex_add(&ex, p[i]);
                }
                uint32_t exr = ex_round(&ex);
                uint32_t seq = 0;
                for (int i = 0; i < len; i++) seq = add(seq, p[i]);
                if (arr_sum(p, len, 1, 0) != seq) mism1++;
                double e0 = ulp_err(seq, exr);
                if (!isnan(e0)) { if (e0 > emax[0]) emax[0] = e0; esum[0] += e0; ecnt[0]++; }
                for (int k = 0; k < 4; k++) {
                    uint32_t r = arr_sum(p, len, NS[k], 0);
                    same[k] += (r == seq);
                    double e = ulp_err(r, exr);
                    if (!isnan(e)) { if (e > emax[k+1]) emax[k+1] = e; esum[k+1] += e; ecnt[k+1]++; }
                }
            }
            printf("| %s | %d | %.1f / %.2f |", dist[d], len, emax[0], esum[0] / (ecnt[0] ? ecnt[0] : 1));
            for (int k = 0; k < 4; k++)
                printf(" %.1f | %.1f / %.2f |", 100.0 * same[k] / trials, emax[k+1],
                       esum[k+1] / (ecnt[k+1] ? ecnt[k+1] : 1));
            printf("\n");
        }
    printf("\nNUM_LANES = 1 order vs strict sequential loop: %ld mismatches (must be 0).\n", mism1);
    return mism1 ? 1 : 0;
}
