/* =============================================================================
 * SilicaFlux-HPC :: varray_ref -- independent reference model of the vector
 *                                 array specification (docs/ARRAY_INTERFACE.md)
 *
 * Written from the specification, not from the RTL.  Element arithmetic uses
 * Berkeley SoftFloat-3e (RISCV specialisation: canonical NaN 0x7FC00000,
 * tininess after rounding), which shares no code with the Module 02 lane or its
 * Python reference model.
 *
 *   varray_ref N EN_FCMP EN_INT RED_EN cmds.txt beats.txt res.txt cpl.txt
 *
 * Input (hex, whitespace separated, produced by ref/gen_stim.py)
 *   cmds.txt   seg idx op rm vl vm bcast scalar red tid
 *   beats.txt  seg idx mask a0 b0 c0 a1 b1 c1 ... a{N-1} b{N-1} c{N-1}
 * Output (expected DUT behaviour, in order)
 *   res.txt    seg idx tid beat last mask d0 f0 d1 f1 ... (one line per result beat)
 *   cpl.txt    seg idx tid flags ill count red result     (one line per command)
 *
 * Specification implemented here
 *   - element e of a command -> beat e / N, lane e % N; ceil(vl/N) beats
 *   - active(e) = legal & e < vl & (!vm | mask bit)
 *   - bcast bit k replaces operand k (a, b, c) of every element by scalar
 *   - elementwise: one result beat per operand beat; inactive positions carry
 *     data 0, flags 0, mask bit 0; completion flags = OR over active elements
 *   - reduction: pairwise tree over lane index per beat (absent children are
 *     bypassed, never replaced by an identity), then acc = acc + S_g in beat
 *     order starting from acc = scalar; FP32 accumulator, command rm
 *   - illegal command: no active elements, flags 0, count 0, result 0, beats
 *     still consumed (and, if elementwise, emitted with mask 0)
 * ===========================================================================*/
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "softfloat.h"

enum { OP_FMV = 0x00, OP_FADD, OP_FSUB, OP_FMUL, OP_FMADD, OP_FMSUB, OP_FNMSUB, OP_FNMADD,
       OP_FMIN, OP_FMAX, OP_FEQ, OP_FLT, OP_FLE, OP_IADD = 0x10, OP_IMUL = 0x11 };

static int N, EN_FCMP, EN_INT, RED_EN;

/* ---------------------------------------------------------------- flags */
static unsigned take_flags(void) {
    unsigned f = softfloat_exceptionFlags, r = 0;
    if (f & softfloat_flag_invalid)  r |= 1u << 4;   /* NV */
    if (f & softfloat_flag_infinite) r |= 1u << 3;   /* DZ */
    if (f & softfloat_flag_overflow) r |= 1u << 2;   /* OF */
    if (f & softfloat_flag_underflow)r |= 1u << 1;   /* UF */
    if (f & softfloat_flag_inexact)  r |= 1u << 0;   /* NX */
    softfloat_exceptionFlags = 0;
    return r;
}

static void set_rm(unsigned rm) {
    static const uint_fast8_t map[5] = {
        softfloat_round_near_even, softfloat_round_minMag, softfloat_round_min,
        softfloat_round_max, softfloat_round_near_maxMag };
    if (rm > 4) { fprintf(stderr, "set_rm: illegal rm %u reached arithmetic\n", rm); exit(2); }
    softfloat_roundingMode = map[rm];
}

static float32_t F(uint32_t v) { float32_t x; x.v = v; return x; }
static bool is_nan(uint32_t x)  { return ((x >> 23) & 0xFF) == 0xFF && (x & 0x7FFFFF); }
static bool is_snan(uint32_t x) { return is_nan(x) && !(x & 0x400000); }
static bool is_zero(uint32_t x) { return (x & 0x7FFFFFFF) == 0; }

/* ---------------------------------------------------------------- legality */
static bool rm_ok(unsigned rm) { return rm <= 4; }
static bool elem_legal(unsigned op, unsigned rm) {
    switch (op) {
    case OP_FMV: return true;
    case OP_FADD: case OP_FSUB: case OP_FMUL: case OP_FMADD: case OP_FMSUB:
    case OP_FNMSUB: case OP_FNMADD: return rm_ok(rm);
    case OP_FMIN: case OP_FMAX: case OP_FEQ: case OP_FLT: case OP_FLE: return EN_FCMP;
    case OP_IADD: case OP_IMUL: return EN_INT;
    default: return false;
    }
}
static bool cmd_legal(unsigned op, unsigned rm, unsigned red, unsigned bcast) {
    if (red) return RED_EN && op <= OP_FNMADD && rm_ok(rm) && bcast == 0;
    return elem_legal(op, rm);
}

/* ---------------------------------------------------------------- element op */
static uint32_t elem_op(unsigned op, unsigned rm, uint32_t a, uint32_t b, uint32_t c,
                        unsigned *flags) {
    uint32_t r = 0;
    softfloat_exceptionFlags = 0;
    switch (op) {
    case OP_FMV:    r = a; break;
    case OP_FADD:   set_rm(rm); r = f32_add(F(a), F(b)).v; break;
    case OP_FSUB:   set_rm(rm); r = f32_sub(F(a), F(b)).v; break;
    case OP_FMUL:   set_rm(rm); r = f32_mul(F(a), F(b)).v; break;
    case OP_FMADD:  set_rm(rm); r = f32_mulAdd(F(a), F(b), F(c)).v; break;
    case OP_FMSUB:  set_rm(rm); r = f32_mulAdd(F(a), F(b), F(c ^ 0x80000000u)).v; break;
    case OP_FNMSUB: set_rm(rm); r = f32_mulAdd(F(a ^ 0x80000000u), F(b), F(c)).v; break;
    case OP_FNMADD: set_rm(rm); r = f32_mulAdd(F(a ^ 0x80000000u), F(b), F(c ^ 0x80000000u)).v; break;
    case OP_FMIN: case OP_FMAX: {
        bool nv = is_snan(a) || is_snan(b);
        if (is_nan(a) && is_nan(b))      r = 0x7FC00000u;
        else if (is_nan(a))              r = b;
        else if (is_nan(b))              r = a;
        else if (is_zero(a) && is_zero(b))
            r = (op == OP_FMIN) ? ((a | b) & 0x80000000u) : ((a & b) & 0x80000000u);
        else {
            bool lt = f32_lt_quiet(F(a), F(b));
            r = (op == OP_FMIN) ? (lt ? a : b) : (lt ? b : a);
        }
        softfloat_exceptionFlags = nv ? softfloat_flag_invalid : 0;
        break; }
    case OP_FEQ:  r = f32_eq(F(a), F(b)); break;
    case OP_FLT:  r = f32_lt(F(a), F(b)); break;
    case OP_FLE:  r = f32_le(F(a), F(b)); break;
    case OP_IADD: r = a + b; break;
    case OP_IMUL: r = (uint32_t)((uint64_t)a * (uint64_t)b); break;
    default: fprintf(stderr, "elem_op: illegal op %02x reached arithmetic\n", op); exit(2);
    }
    *flags = take_flags();
    return r;
}

static uint32_t add_rm(uint32_t x, uint32_t y, unsigned rm, unsigned *flags) {
    set_rm(rm);
    softfloat_exceptionFlags = 0;
    uint32_t r = f32_add(F(x), F(y)).v;
    *flags |= take_flags();
    return r;
}

/* ---------------------------------------------------------------- I/O helpers */
static int rd(FILE *f, uint32_t *v) { unsigned x; int k = fscanf(f, "%x", &x); *v = x; return k; }

int main(int argc, char **argv) {
    if (argc != 9) {
        fprintf(stderr, "usage: %s N EN_FCMP EN_INT RED_EN cmds beats res cpl\n", argv[0]);
        return 2;
    }
    N = atoi(argv[1]); EN_FCMP = atoi(argv[2]); EN_INT = atoi(argv[3]); RED_EN = atoi(argv[4]);
    if (N < 1 || N > 16) { fprintf(stderr, "bad N\n"); return 2; }
    FILE *fc = fopen(argv[5], "r"), *fb = fopen(argv[6], "r");
    FILE *fr = fopen(argv[7], "w"), *fp = fopen(argv[8], "w");
    if (!fc || !fb || !fr || !fp) { perror("open"); return 2; }

    softfloat_detectTininess = softfloat_tininess_afterRounding;
    uint64_t ncmd = 0, nbeat = 0, nres = 0;

    for (;;) {
        uint32_t seg, idx, op, rm, vl, vm, bcast, scalar, red, tid;
        if (rd(fc, &seg) != 1) break;
        if (rd(fc, &idx) != 1 || rd(fc, &op) != 1 || rd(fc, &rm) != 1 || rd(fc, &vl) != 1 ||
            rd(fc, &vm) != 1 || rd(fc, &bcast) != 1 || rd(fc, &scalar) != 1 ||
            rd(fc, &red) != 1 || rd(fc, &tid) != 1) { fprintf(stderr, "bad cmd record\n"); return 2; }
        ncmd++;
        bool legal = cmd_legal(op, rm, red, bcast);
        uint32_t nb = (vl + (uint32_t)N - 1) / (uint32_t)N;
        unsigned cflags = 0;
        uint32_t count = 0, acc = scalar;

        for (uint32_t g = 0; g < nb; g++) {
            uint32_t bseg, bidx, mask, a[16], b[16], c[16];
            if (rd(fb, &bseg) != 1 || rd(fb, &bidx) != 1 || rd(fb, &mask) != 1) {
                fprintf(stderr, "missing beat %u of command %u\n", g, idx); return 2;
            }
            if (bseg != seg || bidx != idx) { fprintf(stderr, "beat framing mismatch cmd %u\n", idx); return 2; }
            for (int l = 0; l < N; l++)
                if (rd(fb, &a[l]) != 1 || rd(fb, &b[l]) != 1 || rd(fb, &c[l]) != 1) {
                    fprintf(stderr, "short beat\n"); return 2;
                }
            nbeat++;
            uint32_t act = 0, d[16]; unsigned f[16];
            for (int l = 0; l < N; l++) {
                uint32_t e = g * (uint32_t)N + (uint32_t)l;
                bool on = legal && e < vl && (!vm || ((mask >> l) & 1u));
                d[l] = 0; f[l] = 0;
                if (!on) continue;
                act |= 1u << l;
                uint32_t oa = (bcast & 1) ? scalar : a[l];
                uint32_t ob = (bcast & 2) ? scalar : b[l];
                uint32_t oc = (bcast & 4) ? scalar : c[l];
                d[l] = elem_op(op, rm, oa, ob, oc, &f[l]);
                cflags |= f[l];
                count++;
            }
            if (!red) {
                fprintf(fr, "%x %x %x %x %x %x", seg, idx, tid, g, (g == nb - 1) ? 1u : 0u, act);
                for (int l = 0; l < N; l++) fprintf(fr, " %08x %x", d[l], f[l]);
                fprintf(fr, "\n");
                nres++;
            } else if (act) {
                /* pairwise tree over lane index, absent children bypassed */
                uint32_t v[16]; bool p[16];
                for (int l = 0; l < N; l++) { v[l] = d[l]; p[l] = (act >> l) & 1u; }
                for (int w = N; w > 1; w /= 2) {
                    for (int j = 0; j < w / 2; j++) {
                        if (p[2*j] && p[2*j+1])  { v[j] = add_rm(v[2*j], v[2*j+1], rm, &cflags); p[j] = true; }
                        else if (p[2*j])         { v[j] = v[2*j];   p[j] = true; }
                        else if (p[2*j+1])       { v[j] = v[2*j+1]; p[j] = true; }
                        else                     { p[j] = false; }
                    }
                }
                acc = add_rm(acc, v[0], rm, &cflags);   /* p[0] is true since act != 0 */
            }
        }
        if (!legal) { cflags = 0; count = 0; }
        uint32_t result = (red && legal) ? acc : 0;
        fprintf(fp, "%x %x %x %x %x %x %x %08x\n", seg, idx, tid, cflags, legal ? 0u : 1u,
                count, red, result);
    }
    uint32_t junk;
    if (rd(fb, &junk) == 1) { fprintf(stderr, "extra beats after last command\n"); return 2; }
    fclose(fr); fclose(fp);
    fprintf(stderr, "varray_ref: N=%d cmds=%" PRIu64 " beats=%" PRIu64 " res_beats=%" PRIu64 "\n",
            N, ncmd, nbeat, nres);
    return 0;
}
