// =============================================================================
// SilicaFlux MCU-I FPGA prototype top -- Radiona ULX3S (Lattice ECP5 LFE5U-85F)
// Adapted from silicaflux-v-release1.zip:silicaflux-v/fpga/ulx3s/sfv_ulx3s_top.sv (SilicaFlux-V).
//
//   clk_25mhz   25 MHz oscillator used directly as the SoC clock, or (USE_PLL=1)
//               a 20 MHz PLL output when timing does not close at 25 MHz
//   btn[1]      reset (active high); a power-on counter also resets
//   btn[3:2]    boot straps {btn3, btn2}: none = 0 SPI flash, btn2 = 1 JTAG,
//               btn3 = 2 UART (load an image from the host over the FT231X),
//               both = 3 SRAM
//   ftdi_*      UART0 console on the on-board FT231X (115200 8N1)
//   J1 gp/gn    JTAG (gp0 TCK, gn0 TMS, gp1 TDI, gn1 TDO), SPI0 flash PMOD
//               (gp2 SCK, gn2 MOSI, gp3 MISO, gn3 CS0#), SPI1 (gp4 SCK,
//               gn4 MOSI, gp5 MISO, gn5 CS0#), I2C (gp6 SCL, gn6 SDA, open
//               drain, pull-ups), UART1 (gp7 TX, gn7 RX), PWM[3:0] (gp8..gp11),
//               PWM fault (gn8), GPIO[15:10] (gn9..gn11, gp12..gp14)
//   led[7:0]    {test_pass, test_fail, gpio[8] (blink), pwm[1], cpu_sleep,
//                heartbeat[2:0]}
// DEMO_LOOPBACK = 1 provides the loopbacks the example firmware expects
// INSIDE the FPGA (same as the simulation board model): gpio[2]->gpio[3],
// gpio[8]->gpio[4], pwm[0]->gpio[5], gpio[9]->PWM fault, SPI0 CS1 MOSI->MISO.
// With DEMO_LOOPBACK = 0 these come from the header pins/jumpers instead.
// All I/O are LVCMOS33 FPGA pins: no foundry pads, ESD or 5 V tolerance.
// =============================================================================
`default_nettype none

module mcu_ulx3s_top #(
  parameter int DEMO_LOOPBACK = 1,
  parameter int USE_PLL       = 0          // 1: SoC clock = 20 MHz from the ECP5 PLL (EHXPLLL)
) (
  input  wire logic       clk_25mhz,
  input  wire logic [6:0] btn,
  output logic [7:0]      led,
  output logic            ftdi_rxd,
  input  wire logic       ftdi_txd,
  input  wire logic       jtag_tck,
  input  wire logic       jtag_tms,
  input  wire logic       jtag_tdi,
  output logic            jtag_tdo,
  output logic            spi0_sck,
  output logic            spi0_mosi,
  input  wire logic       spi0_miso,
  output logic            spi0_csn,
  output logic            spi1_sck,
  output logic            spi1_mosi,
  input  wire logic       spi1_miso,
  output logic            spi1_csn,
  inout  wire             i2c_scl,
  inout  wire             i2c_sda,
  output logic            uart1_tx,
  input  wire logic       uart1_rx,
  output logic [3:0]      pwm,
  input  wire logic       pwm_fault,
  inout  wire [5:0]       gpio_hdr,
  output logic            wifi_gpio0
);
  assign wifi_gpio0 = 1'b1;               // keep the ESP32 from resetting the board

  // SoC clock: the 25 MHz oscillator, or 20 MHz from the PLL when the
  // implementation does not close timing at 25 MHz (see docs/FPGA.md).
  // PLL: fPFD = 25/5 = 5 MHz, fOUT = 5 x 4 = 20 MHz, fVCO = 20 x 30 = 600 MHz.
  wire clk;
  localparam logic [15:0] BAUD = (USE_PLL != 0) ? 16'd174 : 16'd217;   // 115200 Bd
  if (USE_PLL != 0) begin : g_pll
    wire pll_locked_unused;
    (* FREQUENCY_PIN_CLKI="25", FREQUENCY_PIN_CLKOP="20", ICP_CURRENT="12", LPF_RESISTOR="8",
       MFG_ENABLE_FILTEROPAMP="1", MFG_GMCREF_SEL="2" *)
    EHXPLLL #(
      .PLLRST_ENA("DISABLED"), .INTFB_WAKE("DISABLED"), .STDBY_ENABLE("DISABLED"), .DPHASE_SOURCE("DISABLED"),
      .OUTDIVIDER_MUXA("DIVA"), .OUTDIVIDER_MUXB("DIVB"), .OUTDIVIDER_MUXC("DIVC"), .OUTDIVIDER_MUXD("DIVD"),
      .CLKI_DIV(5), .CLKOP_ENABLE("ENABLED"), .CLKOP_DIV(30), .CLKOP_CPHASE(14), .CLKOP_FPHASE(0),
      .FEEDBK_PATH("CLKOP"), .CLKFB_DIV(4)
    ) u_pll (
      .RST(1'b0), .STDBY(1'b0), .CLKI(clk_25mhz), .CLKOP(clk), .CLKFB(clk), .CLKINTFB(),
      .PHASESEL0(1'b0), .PHASESEL1(1'b0), .PHASEDIR(1'b1), .PHASESTEP(1'b1), .PHASELOADREG(1'b1),
      .PLLWAKESYNC(1'b0), .ENCLKOP(1'b0), .LOCK(pll_locked_unused)
    );
  end else begin : g_nopll
    assign clk = clk_25mhz;
  end

  logic [3:0] por_cnt = 4'd0;
  always_ff @(posedge clk) if (por_cnt != 4'hF) por_cnt <= por_cnt + 4'd1;
  wire rst_n = (por_cnt == 4'hF) && !btn[1];

  logic [31:0] gpio_i, gpio_o, gpio_oe, test_status;
  logic [3:0]  s0_cs, s1_cs, pwm_o;
  logic        test_pass, test_fail, cpu_sleep, tdo, tdo_oe, scl_oe, sda_oe, s0_mosi, s0_miso;

  // I2C open drain: drive low or release (pull-up in the LPF + external resistors)
  assign i2c_scl = scl_oe ? 1'b0 : 1'bz;
  assign i2c_sda = sda_oe ? 1'b0 : 1'bz;
  // header GPIO[15:10]: tri-state
  genvar g;
  for (g = 0; g < 6; g++) begin : g_hdr
    assign gpio_hdr[g] = gpio_oe[10+g] ? gpio_o[10+g] : 1'bz;
  end

  always_comb begin
    gpio_i        = gpio_oe & gpio_o;
    gpio_i[1:0]   = {btn[3], btn[2]};
    gpio_i[15:10] = gpio_hdr;
    if (DEMO_LOOPBACK != 0) begin
      gpio_i[3] = gpio_o[2];
      gpio_i[4] = gpio_o[8];
      gpio_i[5] = pwm_o[0];
    end
  end
  wire fault_in = (DEMO_LOOPBACK != 0) ? gpio_o[9] : pwm_fault;
  assign s0_miso = (DEMO_LOOPBACK != 0 && !s0_cs[1]) ? s0_mosi : spi0_miso;

  mcu_top #(.SRAM_BACKEND(`SRAM_BACKEND_FPGA), .UART_BAUD_RESET(BAUD)) u_mcu (
    .clk, .rst_ni(rst_n), .pwr_ok_i(1'b1), .test_mode(1'b0),
    .tck(jtag_tck), .tms(jtag_tms), .tdi(jtag_tdi), .tdo, .tdo_oe,
    .uart0_tx(ftdi_rxd), .uart0_rx(ftdi_txd), .uart1_tx, .uart1_rx,
    .spi0_sck, .spi0_mosi(s0_mosi), .spi0_miso(s0_miso), .spi0_cs_n(s0_cs),
    .spi1_sck, .spi1_mosi, .spi1_miso, .spi1_cs_n(s1_cs),
    .i2c_scl_i(i2c_scl), .i2c_scl_oe(scl_oe), .i2c_sda_i(i2c_sda), .i2c_sda_oe(sda_oe),
    .gpio_i, .gpio_o, .gpio_oe, .pwm_o, .pwm_fault_i(fault_in),
    .test_pass, .test_fail, .test_status, .cpu_sleep
  );
  assign spi0_mosi = s0_mosi;
  assign spi0_csn  = s0_cs[0];
  assign spi1_csn  = s1_cs[0];
  assign pwm       = pwm_o;
  assign jtag_tdo  = tdo_oe ? tdo : 1'b1;

  logic [24:0] hb = '0;
  always_ff @(posedge clk) hb <= hb + 25'd1;
  assign led = {test_pass, test_fail, gpio_o[8], pwm_o[1], cpu_sleep, hb[24:22]};
  wire unused_ok = ^{btn[0], btn[6:4], test_status, s0_cs[3:2], s1_cs[3:1], gpio_o[31:16], gpio_oe[31:16]};
endmodule

`default_nettype wire
