#!/usr/bin/env bash
# SilicaFlux MCU-I FPGA build: ULX3S (ECP5-85F), Yosys + nextpnr-ecp5 + Trellis.
# usage: fpga/ulx3s/build.sh [industrial|basic]   -> build/fpga/<variant>/mcu_ulx3s.bit
# env: SEED (nextpnr seed, default 1), FREQ (MHz constraint, default 25)
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
V="${1:-industrial}"
for t in yosys nextpnr-ecp5 ecppack; do command -v $t >/dev/null || { echo "ERROR: $t not found (FPGA flow needs Yosys, nextpnr-ecp5, Project Trellis)"; exit 2; }; done
B=build/fpga/$V; mkdir -p $B
ROM=build/$V/mcu_bootrom_image.sv
[ -f $ROM ] || make -s -C firmware VARIANT=$V rom || exit 1
USE_PLL=${USE_PLL:-0}      # 1: 20 MHz SoC clock from the ECP5 PLL
[ "$USE_PLL" = 1 ] && FREQ=${FREQ:-20}
SRC="rtl/generated/mcu_cfg_${V}_pkg.sv $(grep -v '^//' rtl/files.f | tr '\n' ' ') $ROM fpga/ulx3s/mcu_ulx3s_top.sv"
INC="-I third_party/silicaflux-sramlib/rtl/mem -I third_party/silicaflux-sramlib/rtl/mem/backends/asic"
SEED=${SEED:-1}; FREQ=${FREQ:-25}
# -abc9 aborted inside yosys-abc 0.33 on this design (return code 134); the
# classic ABC mapper is the default.  Set ABC9=-abc9 to try it.
ABC9=${ABC9:-}
echo "[fpga] yosys synth_ecp5 ($V)"
yosys -q -l $B/yosys.log -p "read_verilog -defer -sv -DSYNTHESIS -DSFV_NO_CLOCK_GATE $INC $SRC; \
  chparam -set USE_PLL $USE_PLL mcu_ulx3s_top; hierarchy -top mcu_ulx3s_top; synth_ecp5 -top mcu_ulx3s_top $ABC9 -json $B/mcu_ulx3s.json; \
  tee -q -o $B/yosys_stat.txt stat" || { tail -20 $B/yosys.log; exit 1; }
echo "[fpga] nextpnr-ecp5 (seed $SEED, ${FREQ} MHz)"
rm -f $B/nextpnr_exit_note.txt
nextpnr-ecp5 --85k --package CABGA381 --json $B/mcu_ulx3s.json --lpf fpga/ulx3s/mcu_ulx3s.lpf \
  --textcfg $B/mcu_ulx3s.config --freq $FREQ --seed $SEED --report $B/nextpnr_report.json \
  -l $B/nextpnr.log > /dev/null 2>&1
rc=$?
if [ $rc != 0 ]; then
  # nextpnr-ecp5 0.6 was observed to return non-zero after "Program finished normally" with a complete
  # config; accept that case only (recorded in the summary), fail otherwise.
  if grep -aq "Program finished normally" $B/nextpnr.log && [ -s $B/mcu_ulx3s.config ] && \
     ! grep -aq "^ERROR" $B/nextpnr.log; then
    echo "NOTE: nextpnr-ecp5 exit code $rc after 'Program finished normally' (config complete)" | tee $B/nextpnr_exit_note.txt
  else
    tail -30 $B/nextpnr.log; exit 1
  fi
fi
echo "[fpga] ecppack"
ecppack --compress $B/mcu_ulx3s.config $B/mcu_ulx3s.bit || exit 1
sha256sum $B/mcu_ulx3s.bit > $B/mcu_ulx3s.bit.sha256
grep -a -E "Max frequency for clock|TRELLIS_SLICE|TRELLIS_COMB|TRELLIS_FF|DP16KD|TRELLIS_IO|MULT18X18D|EHXPLLL" $B/nextpnr.log | sed 's/^Info: *//' | sort -u > $B/summary.txt
cat $B/summary.txt
echo "[fpga] bitstream: $B/mcu_ulx3s.bit (NOT tested on hardware)"
