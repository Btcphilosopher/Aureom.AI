# SilicaFlux MCU-I -- Industrial Microcontroller SoC, Generation I

Aureom.AI / SilicaFlux Semiconductor Systems -- Project 04.

MCU-I is a compact, synthesizable RISC-V microcontroller SoC built from the existing SilicaFlux code base
(SilicaFlux-V CPU and peripherals, DataFabric bus and DMA, SRAM Wrapper Library) plus new industrial peripherals.
One parameterised RTL code base produces two configurations:

* **BASIC** -- RV32I_Zicsr, 64 KiB SRAM, 8 KiB boot ROM, UART, SPI (flash boot), 16 GPIO, machine timer + GP timer,
  watchdog, interrupt controller, fault log, JTAG debug, MBIST.
* **INDUSTRIAL** -- BASIC + RV32IM, 128 KiB SRAM with byte parity, I2C, 4 GP timers, 4 PWM with fault input,
  DMA with peripheral pacing, second UART/SPI, 32 GPIO, integer DSP/MAC accelerator.

**Status (honest summary).** RTL, firmware and verification exist and pass in simulation; formal proofs and
logic synthesis on public PDKs were run; FPGA bitstreams were generated.  **Nothing has been run on silicon (none
exists) or on a physical FPGA board.  No placement/routing, static timing or signoff has been performed.  MCU-I is
not tape-out ready.**  Every number in the documentation comes from a tool output in `reports/`
([reports/SUMMARY.md](reports/SUMMARY.md)); blockers are in [docs/ISSUES.md](docs/ISSUES.md).

## Quick start

Prerequisites (versions used: [reports/SUMMARY.md](reports/SUMMARY.md)): Verilator >= 5.020, Icarus Verilog 12,
Yosys 0.33 (+ yosys-smtbmc, yosys-abc, z3), Python 3 with PyYAML and cocotb 2.x, GNU `riscv64-unknown-elf-gcc`
(rv32 multilibs); for FPGA nextpnr-ecp5 + Project Trellis.  On Ubuntu 24.04:
```bash
sudo apt-get install verilator iverilog yosys gcc-riscv64-unknown-elf nextpnr-ecp5 fpga-trellis z3
pip install cocotb pyyaml
```
```bash
make mcu-deps        # riscv-tests + public PDK data (network)
make mcu-lint        # lint both variants
make mcu-test        # riscv-tests + cocotb unit tests + SoC firmware regression
make mcu-formal      # formal proofs + CPU equivalence
make mcu-fpga        # ULX3S bitstreams
make mcu-synth       # Yosys logic synthesis on IHP SG13G2, SKY130, GF180MCU
make mcu-bench       # DSP accelerator benchmark
make mcu-report      # reports/SUMMARY.md
```
Single SoC simulation: `scripts/build_sim.sh industrial && build/industrial/sim/vtb_mcu_soc +flash=build/fw/industrial/01_hello.flash.hex`.

## Repository layout

```
configs/      memmap.yaml (single source of truth), basic.yaml, industrial.yaml
rtl/          cpu bus(crossbar is vendored) mem dma gpio uart spi i2c timers pwm watchdog interrupts power debug dsp top
              generated/ (memory-map package, configuration packages)   files.f (compile order)
third_party/  unmodified SilicaFlux sources (SilicaFlux-V, DataFabric, SRAM library) + SHA256SUMS + PROVENANCE.md
tb/           cpu/ (riscv-tests harness)  soc/ (firmware testbench)  models/ (SPI flash, I2C devices)  unit/ (cocotb)
formal/       harnesses, runner, CPU equivalence script
firmware/     boot/ (boot ROM) hal/ drivers/ examples/ include/ (generated headers) common/ (link script)
fpga/ulx3s/   top, constraints, build script
asic/         configs (IHP SG13G2, SKY130, GF180MCU), tech wrappers, SDC, synthesis + summary scripts
scripts/      generator, lint, regressions, image tools, benchmark, report collector, dependency fetch
docs/         specifications and reports (index below)
reports/      tool outputs of this release
ci/           GitHub Actions workflow
```

## Documentation

| Document | Content |
|---|---|
| [docs/AUDIT.md](docs/AUDIT.md) | repository audit, reuse matrix, licensing |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | block diagram, configurations, pins, determinism |
| [docs/CPU.md](docs/CPU.md) | ISA, CSRs, traps, M extension, toolchain target, compliance statement |
| [docs/BUS.md](docs/BUS.md) | system bus (SFB2) usage |
| [docs/MEMORY_AND_BOOT.md](docs/MEMORY_AND_BOOT.md) | SRAM, parity, boot ROM, SPI flash boot flow, image format |
| [docs/MEMORY_MAP.md](docs/MEMORY_MAP.md), [docs/REGISTERS.md](docs/REGISTERS.md) | generated memory and register maps |
| [docs/PERIPHERALS.md](docs/PERIPHERALS.md) | peripheral behaviour and limits |
| [docs/CLOCK_RESET.md](docs/CLOCK_RESET.md) | clocks, resets, clock gating, power modes |
| [docs/SAFETY.md](docs/SAFETY.md) | watchdog, supervision, fault monitoring |
| [docs/SECURITY.md](docs/SECURITY.md) | debug lock, unsupported security features |
| [docs/DSP.md](docs/DSP.md) | DSP/MAC accelerator and cost/benefit |
| [docs/FIRMWARE.md](docs/FIRMWARE.md) | toolchain, HAL, drivers, examples |
| [docs/VERIFICATION.md](docs/VERIFICATION.md) | verification plan, results, reproducibility |
| [docs/FPGA.md](docs/FPGA.md) | ULX3S prototype and bring-up checklist |
| [docs/ASIC.md](docs/ASIC.md) | synthesis results, node comparison, packages, foundry IP, flow |
| [docs/DFT.md](docs/DFT.md) | DFT provisions and readiness checklist |
| [docs/METRICS.md](docs/METRICS.md) | engineering metrics |
| [docs/ISSUES.md](docs/ISSUES.md) | open blockers and resolved defects |
| [docs/RELEASES.md](docs/RELEASES.md) | incremental release status |
| [docs/CHANGELOG.md](docs/CHANGELOG.md) | every file: vendored / derived / new |

## Provenance and licensing

Derived from SilicaFlux sources in `btcphilosopher/Aureom.AI` (`SilicaFlux-main/`); vendored files are byte-identical
(`scripts/check_vendor.sh`), derived files state their origin and changes in their headers.  No license file exists
in the source repository -- the owner must add one before external distribution.  Third-party material (riscv-tests,
PDK data) is fetched, not redistributed.
