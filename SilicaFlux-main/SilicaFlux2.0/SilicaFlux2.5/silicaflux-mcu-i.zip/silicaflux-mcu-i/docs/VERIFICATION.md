# Verification plan and results

All results below were produced by the commands listed, with the tool versions in `reports/SUMMARY.md`.
Random tests use fixed seeds (cocotb `COCOTB_RANDOM_SEED=20261106`, per-test `random.Random(n)` seeds in the test
files, riscv-tests profiles with seeds 1 and 2).  Every regression writes its command lines into its report.

## Summary

| Level | Command | Result |
|---|---|---|
| Lint (Verilator -Wall, Yosys elaboration + latch check) | `make mcu-lint` | both variants: 0 errors, 0 unwaived warnings, 0 unintended latches (only ICG latches) |
| CPU ISA (riscv-tests, 3 bus profiles x 2 seeds) | `make mcu-isa` | RV32M=0 55/55, RV32M=1 63/63, RV32M=2 63/63 |
| CPU formal equivalence vs upstream `sfv_cpu` (RV32M=0) | `make mcu-formal` | proven (2,164 equivalence points) |
| Unit (cocotb + Python reference models, Icarus) | `make mcu-unit` | 12 benches, 21 tests, all pass |
| SoC firmware (Verilator, real boot ROM + firmware) | `make mcu-sim` | BASIC 15/15, INDUSTRIAL 18/18 |
| Formal (BMC + ABC PDR, non-vacuity mutants) | `make mcu-formal` | see `reports/formal/formal.md` |
| RTL coverage (firmware regression, Verilator line/branch/toggle) | `scripts/coverage.sh` | see `reports/coverage/` and METRICS.md |

## Test inventory by required category

| Category | Required check | Where |
|---|---|---|
| CPU | instruction compliance (riscv-tests, not ACT) | `scripts/run_riscv_tests.sh` -> `reports/sim/riscv_tests_m*.txt` |
| | branches, register correctness | riscv-tests rv32ui (every branch/ALU/load/store instruction), random bus backpressure |
| | exceptions | rv32mi (illegal, misaligned, ecall/ebreak, CSR), `11_faults` (access faults, misaligned, illegal, ecall) |
| | interrupts | `tb_cpu` random IRQ injection, `03_timer_irq` (MTI, MSI, MEI via INTC, WFI), `02_blink` (GPIO IRQ) |
| Memory | SRAM read/write, byte lanes | `demo`, unit `test_sram_bank` (random strobes vs Python memory) |
| | read latency | fixed by `sram_sp` READ_LATENCY=1 (upstream verified); SoC tests |
| | reset behaviour | no storage reset by design; MBIST scrub at boot (every SoC run) |
| | address boundaries | `11_faults` (above SRAM -> access fault), DMA overflow checks |
| | boot ROM | every SoC run boots through it; ROM write -> bus error (`11_faults`, DMA test) |
| | parity | `11_faults` (injection -> access fault + log), unit `test_sram_bank` |
| Bus | arbitration | formal `arbiter_rr_n4`, `xbar_3x2_upstream` (re-run of the DataFabric proofs); DMA vs CPU contention in `06_dma_copy` |
| | backpressure | DMA unit test (random ready/latency + R2 payload check), riscv-tests profiles |
| | illegal addresses | `11_faults`, JTAG SBA error read, DMA error codes 8/9, `test_dbg_gate` |
| | data integrity | DMA random copies vs Python, SoC copy checks |
| | reset during transactions | protocol rule R11 (upstream); watchdog reset while firmware runs (`07_watchdog`) |
| Peripherals | UART framing/parity/errors | unit `test_uart` (Python encoder, injected bad parity/stop, overrun, glitch), `06_dma_copy` (UART1 even parity) |
| | SPI modes | unit `test_spi` (independent slave model, 4 modes x 3 lengths x 3 dividers), `04_spi_loopback`, flash model |
| | I2C clock stretching | unit `test_i2c` (stretch measured, timeout, glitch filter, START/STOP monitor), `05_i2c` |
| | GPIO interrupts | unit `test_gpio`, `02_blink` |
| | timer rollover | unit `test_gptimer`, `03_timer_irq` |
| | PWM duty cycle | unit `test_pwm` (measured high time, shadow update without runt pulses, fault latency), `08_pwm` (timer capture) |
| | watchdog expiration | unit `test_wdt`, formal `wdt`, `07_watchdog` |
| | interrupt controller | unit `test_intc` (300 random configurations vs model), formal `intc` |
| DMA | copy correctness, completion, errors, contention | unit `test_dma`, formal `dma`, `06_dma_copy` |
| System | reset to boot, firmware execution | every SoC scenario |
| | interrupt servicing | `03_timer_irq`, `02_blink`, `07_watchdog` |
| | concurrent peripheral operation | `demo` (timer IRQs + GPIO + SPI + DMA + PWM + WDT), `06_dma_copy` (DMA + UART + CPU) |
| | error recovery | `07_watchdog`, `11_faults`, `05_i2c` (bus timeout and recovery), boot corruption |
| | low-power state transitions | `03_timer_irq` (gated WFI, wake by timer, mcycle stopped), clock-gated peripheral access (`11_faults`) |
| Debug | JTAG IDCODE/BYPASS/SBA/mailbox, debug lock | `boot_jtag_mailbox`, `boot_sram_jtag_preload`, `debug_lock` scenarios; formal `dbg_gate` |

## Independent reference models

Python: UART frame encoder (test_uart), SPI slave (test_spi), interrupt-priority model (test_intc), memory/fabric
model with backpressure (test_dma), bit-exact DSP model (test_dsp), memory model (test_sram_bank), GP-timer/PWM
timing equations.  C: bit-exact DSP model used on the target (10_dsp_fir).  SystemVerilog behavioural board
models: SPI NOR flash, I2C EEPROM and clock-stretching sensor.  SVA-style embedded checkers in `mcu_intc`,
`mcu_wdt`, `mcu_dma`, `mcu_dbg_gate` (formal only).

## Measured behaviour worth quoting (simulation)

From the SoC UART logs (`reports/sim/logs/`); simulation observations for the given firmware, not guarantees:

| Quantity | BASIC | INDUSTRIAL |
|---|---|---|
| machine-timer interrupt: mtime match -> read of mtime inside the C handler (includes HAL trap entry, 16 register saves, dispatch), max of 5 | 83 cycles | 83 cycles |
| gated WFI over a 2,000-cycle timer period: mcycle advance | 250 cycles | 250 cycles |
| DMA SRAM -> SRAM, 1 KiB | - | 1,104 cycles (4 cycles/word) |
| I2C sensor read (pointer write + repeated START + 2-byte read, 3 us stretching per ACK, f_SCL = clk/32) | - | 2,607 cycles |
| PWM ch0 period / high time measured by timer capture (TOP 399, prescale 1, duty 100) | - | 800 / 200 cycles |
| 16-tap FIR x 64 samples (plain C / accelerator) | 205,714 / - | 55,364 / 3,713 |

## Not verified / limitations

* No RISC-V architectural test suite (ACT), no riscv-formal.
* No gate-level simulation, no timing simulation, no power-aware simulation.
* No structural CDC/RDC analysis; no X-propagation analysis of the full SoC (Verilator is 2-state; the unit
  tests run on 4-state Icarus).
* Formal proofs cover the listed blocks only; DMA/WDT/crossbar proofs are bounded where PDR did not converge.
* Liveness (forward progress) is not formally proven anywhere.
* Board-level behaviour (pads, ESD, real flash parts, real I2C devices) is untested.
* RTL coverage is measured on the firmware regression only (flash-boot scenarios; the JTAG/UART/SRAM boot
  scenarios and the cocotb unit tests are not merged in).  Toggle coverage is the weakest metric (see
  `reports/coverage/`): unused GPIO bits, debug paths and upper address bits are rarely or never toggled.  No
  functional coverage model (covergroups) exists; coverage closure has not been attempted.
