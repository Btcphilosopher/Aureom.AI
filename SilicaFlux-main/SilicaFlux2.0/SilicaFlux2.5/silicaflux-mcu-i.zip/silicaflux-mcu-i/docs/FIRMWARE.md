# MCU-I firmware platform

## Toolchain

GNU `riscv64-unknown-elf-gcc` 13.2 (Ubuntu 24.04 package `gcc-riscv64-unknown-elf`) with its rv32 multilibs;
bare metal, no libc (`-ffreestanding -nostdlib`, libgcc for software multiply/divide on RV32I).  The ISA string
comes from the variant file (`configs/<variant>.yaml: toolchain`): BASIC `rv32i_zicsr_zifencei`, INDUSTRIAL
`rv32im_zicsr_zifencei`, ABI `ilp32`.  The boot ROM is always built for RV32I so one ROM image serves every
variant.  `-Werror` is on.

```bash
make -C firmware VARIANT=basic        # or industrial; outputs in build/fw/<variant>/
```
Per application: `.elf`, `.bin`, `.lst`, `.img` (boot image) and `.flash.hex` (SPI flash image for the testbench
and for programmers); `sizes.txt`; the boot ROM also produces `build/<variant>/mcu_bootrom_image.sv`.

## Layout

| Path | Content |
|---|---|
| `include/mcu_regs.h` | generated register/field/IRQ/DREQ definitions (from `configs/memmap.yaml`) |
| `include/generated/mcu_config_<variant>.h`, `mcu_mem_<variant>.ld` | generated configuration and memory sizes |
| `include/mcu_hal.h` | documented C API (every function described in the header) |
| `hal/crt0.S` | application startup: gp, sp, .bss clear, trap vector, `main`, result -> TEST_STATUS |
| `hal/trap_entry.S`, `hal/trap.c` | trap entry (caller-saved context), dispatcher: MEI (INTC claim loop -> registered handler), MTI, MSI, exceptions (hook or report) |
| `hal/mcu_lib.c` | memset/memcpy/memcmp, CRC-32 (nibble table), test helpers |
| `drivers/` | `sysctrl.c` `uart.c` `console.c` (printf subset) `gpio.c` `timer.c` (machine + GP timers) `spi.c` (+ SPI NOR: RDID, READ, WREN, PP, SE, RDSR) `i2c.c` `pwm.c` `wdt.c` `dma.c` `dsp.c` (+ bit-exact reference model) `fault.c` |
| `boot/` | boot ROM (`rom_start.S`, `bootrom.c`, `rom.ld`) |
| `common/app.ld` | application link script (image at the SRAM base, 2 KiB minimum stack check) |
| `examples/` | applications below |

## Examples (each is self-checking and ends with TEST_STATUS pass/fail)

| # | Directory | Demonstrates | Variant |
|---|---|---|---|
| 1 | `01_hello` | version/identity over UART | both |
| 2 | `02_blink` | GPIO toggle (LED), atomic ops, edge and level interrupts | both |
| 3 | `03_timer_irq` | machine-timer interrupt + latency, GP timer through INTC with priority/threshold, one-shot, rollover, software interrupt, gated-clock WFI sleep | both |
| 4 | `04_spi_loopback` | SPI modes 0-3, 8/16/32-bit frames, BUSY/RX_VALID/RX_OVF | both (+SPI1) |
| 5 | `05_i2c` | EEPROM write/read with repeated START, NACK, clock-stretching sensor, timeout and recovery | INDUSTRIAL |
| 6 | `06_dma_copy` | verified memory copy (word/byte), contention, every error case, abort, UART1 TX/RX via DREQ | INDUSTRIAL |
| 7 | `07_watchdog` | service, early warning, hang -> watchdog reset -> recovery with reset cause and fault log | both |
| 8 | `08_pwm` | PWM duty/period measured by timer capture, shadowed update, polarity, fault -> safe state | INDUSTRIAL |
| 9 | `09_flash_boot` | runs after SPI flash boot; JEDEC ID, re-verifies its own image CRC, program/erase cycle | both |
| 10 | `10_dsp_fir` | MAC/DOT2/Q15/saturating ops and 16-tap FIR vs reference model + cycle benchmark | both (accelerator: INDUSTRIAL) |
| - | `11_faults` | bus errors, exceptions, fault log, gated peripheral, parity injection | both |
| - | `12_dbg_lock` | debug lock (checked by the testbench JTAG host) | both |
| - | `demo` | FPGA board demonstration (FPGA.md checklist) | both |

Firmware has executed in RTL simulation only.  **Nothing has run on silicon (none exists) or on a physical FPGA
board (not available in this environment).**

## HAL conventions

* Multi-instance drivers take the instance base (`MCU_UART1_BASE`); functions return 0 or a negative `MCU_E*`.
* Interrupts: `mcu_irq_register(MCU_IRQ_x, handler, prio)` enables the INTC source; handlers must clear the cause
  at the peripheral (sources are level-sensitive).  `mcu_set_exception_handler()` installs a hook returning the
  resume PC (the faults example skips faulting instructions with `mepc + 4`).
* `CHECK()` / `mcu_test_finish()` make every example a regression test.
