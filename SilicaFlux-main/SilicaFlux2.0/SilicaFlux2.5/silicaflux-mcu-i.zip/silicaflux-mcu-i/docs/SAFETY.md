# Watchdog, supervision and fault monitoring

**MCU-I is not certified to IEC 61508, ISO 26262 or any other functional-safety standard, and no RTL feature
below constitutes a certified safety mechanism.**  Certification needs a safety lifecycle, FMEDA / diagnostic
coverage analysis, a safety manual and independent assessment.  The architecture is arranged so such an analysis
can be done later: every fault source is visible, logged with an address, and handled deterministically.

## Watchdog (`mcu_wdt`)

| Situation | Behaviour |
|---|---|
| reset | disabled; LOAD = 0x00FF_FFFF; counter = LOAD |
| enable | CTRL.EN (set-only: only a reset stops it), optional CTRL.LOCK (set-only: LOAD/PRESCALE/EWI/CTRL writes -> bus error) |
| legal service | write WDT_KEY1 then WDT_KEY2 -> counter reloaded |
| illegal service | any other SERVICE value while enabled -> ILLEGAL + immediate reset request |
| early warning | STATUS.EWI when COUNT <= EWI_THRESH; interrupt if EWI_EN |
| expiry | COUNT = 0 -> reset request -> 8-cycle system reset; RESET_CAUSE.WDT set, WDT_COUNT++, fault log WDT_RESET |
| debug halt | with CTRL.DBG_PAUSE the counter pauses while JTAG holds the CPU |
| WFI sleep | keeps counting (its clock is never gated) |
| firmware lockup | no service -> EWI -> reset -> ROM boots the image again -> firmware reads RESET_CAUSE / fault log (demonstrated by `07_watchdog`) |
| **clock failure** | **not detected**: the watchdog runs from the same clock as the CPU, so a stopped clock stops it too.  Independent protection needs an independent oscillator (internal RC or external) feeding the watchdog through a synchroniser -- not present.  FAULT.CLK_FAULT is reserved and never set. |

Formal properties proven on the RTL (`reports/formal/formal.md`): EN set-only, reset request sticky, LOCK
freezes LOAD/PRESCALE, counter only increases on enable or a legal service, illegal service -> reset request.
A deliberately broken watchdog (EN clearable) is caught by the same harness (non-vacuity).

## Supervision provisions

* `pwr_ok_i` (power-good / external supervisor) joins `rst_ni` into the POR reset.  Brown-out comparators and
  power-on-reset circuits are analogue macros or external ICs and are not part of this design.
* RESET_CAUSE (POR domain) distinguishes POR, software reset, JTAG reset, watchdog; BOOT_STATUS records boot ROM
  progress / failure codes across resets.

## Fault log (`mcu_fault`, POR domain)

Records (sticky W1C status, saturating counters, last address and source): bus decode errors (any master,
including the DMA and the debugger), peripheral bus errors, SRAM parity errors, DMA errors, watchdog early
warning, watchdog resets, boot failures (set by the ROM), UART errors, I2C errors, PWM faults, software-reported
faults.  Optional interrupt per bit.  Survives soft and watchdog resets.

## Deterministic hardware responses

| Fault | Response |
|---|---|
| unmapped / denied / misaligned bus access | bus error -> CPU precise access-fault or misaligned exception (mtval = address); DMA stops with READ/WRITE_BUS error and address |
| execute from peripherals | instruction port denied by the access matrix -> instruction access fault |
| SRAM parity error | bus error on the read (load/fetch access fault), logged with address |
| watchdog | system reset |
| PWM fault input | all PWM channels to their SAFE level within 3 clock cycles, latched until cleared with the input inactive |
| DMA programming error | refused before any bus access (13 error codes) |
| peripheral misuse (busy SPI/DSP/I2C, locked WDT) | bus error, no side effect |

Verified by `11_faults` (CPU-side faults, parity injection, gated peripheral), `06_dma_copy` (DMA errors),
`08_pwm` (fault input), `07_watchdog`, and the unit tests.
