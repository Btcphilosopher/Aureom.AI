# Memory subsystem and boot

## SRAM

* 4 banks on separate crossbar ports (instruction fetch and data/DMA proceed in parallel when they use different
  banks), contiguous from `0x1000_0000`.  Bank = `mcu_sram_bank` = SFB2 adapter + SilicaFlux SRAM Wrapper Library
  `sram_sp` (vendored unmodified).
* Sizes: BASIC 64 KiB, INDUSTRIAL 128 KiB, experiment 256 KiB (`BANK_WORDS: 16384`).  These are design points,
  not guaranteed foundry macro configurations; the ASIC backend tiles whatever macros the PDK provides
  (IHP SG13G2: `RM_IHPSG13_1P_4096x16` -> 8 macros for BASIC, 24 for INDUSTRIAL).
* Backends (same RTL, selected by `SRAM_BACKEND`): GENERIC (simulation, behavioural array), FPGA (block-RAM
  inference: 64 ECP5 DP16KD for INDUSTRIAL), ASIC (foundry macro black boxes, never flip-flops).
* Synchronous read, READ_LATENCY = 1, byte write enables, write acknowledged only after the array was written.
* **No reset of storage bits**; contents are undefined after power-up.  The boot ROM runs the March C- MBIST on all
  banks before using any SRAM: it is the power-on self-test and leaves every word = 0 (with valid parity).
* Parity (INDUSTRIAL): one odd-parity bit per byte (36-bit words).  Byte writes update the matching parity bits,
  so no read-modify-write is needed.  SECDED ECC was not chosen because byte/halfword stores would require a
  read-modify-write in the bank (extra latency, a new bus wait state, more verification) -- parity gives
  deterministic *detection* (bus error -> precise load/fetch access fault, fault log entry with address) and is the
  technically justified first step; correction is a recorded follow-up (ISSUES.md).  `PARITY_CTRL.INJECT` stores
  inverted parity on the next write for testing.  MBIST covers the data bits only (parity bits are written with
  valid parity by MBIST but not compared -- DFT gap, see DFT.md).

## Boot ROM

* 8 KiB window at `0x0000_0000`; the image (`firmware/boot/`) is 2,104 bytes and identical for both variants (it
  discovers SRAM size and features from SYSCTRL).  It uses no RAM data (enforced by its link script).
* Implementation: `sfv_bootrom` + a generated combinational image module (`gen_rom.py`) -> logic gates in every
  flow.  For ASIC this is the "logic ROM" option; at 2 KiB of content it synthesises to a few thousand cells
  (included in the reported area).  A foundry via/metal-programmable ROM macro with the same 1-cycle contract can
  replace it 1:1 if area matters more than mask-change flexibility.
* Writes return a bus error.  Simulation and FPGA use the same generated RTL (no `$readmemh` in the synthesis path).

## Non-volatile firmware storage: external SPI NOR flash

There is no on-chip flash (an ordinary CMOS logic process has none).  Firmware lives in an external SPI NOR on
SPI0/CS0 and is copied to SRAM by the boot ROM.  The boot ROM drives SPI0 in software, then releases it; the
application owns SPI0 afterwards -- the pins never have two owners, so no arbitration hardware is needed.

### Boot flow (mode = straps on gpio[1:0], sampled 3 cycles after reset release, or JTAG override)

1. Reset released (POR -> system -> CPU, each synchronised).
2. Immutable ROM code: `BOOT_STATUS = 0xB0010001`; MBIST all banks (skipped in mode 3); failure -> fault log
   BOOT_FAIL, TEST_STATUS fail, halt.
3. Enable parity checking if implemented; stack at the top of SRAM.
4. Mode 0 (SPI): read 20-byte header at flash offset 0x000000, else 0x100000 (room for an FPGA bitstream in a
   shared flash).  Mode 1 (JTAG): wait for the host to load SRAM and post SCRATCH0/1.  Mode 2 (UART): receive the
   image on UART0.  Mode 3 (SRAM): jump to the SRAM base (preloaded by a tester/debugger).
5. Validate the header: magic `MCI1`; length > 0 and a multiple of 4; load address in SRAM, word aligned; load +
   length <= SRAM end - 1 KiB (ROM stack); entry inside the image.
6. Copy word by word (SPI 32-bit frames, SCK = clk/2) while computing CRC-32.
7. CRC mismatch -> `BOOT_STATUS = 0xB0D000xx`, fault log, halt.  **Authenticity is not verified**: there is no key
   storage and no reviewed signature implementation, so no secure-boot claim is made (SECURITY.md).
8. `BOOT_STATUS = 0x600D00mm`, `fence.i`, jump to the entry point.

Image format (`scripts/mkimage.py`): `{magic 0x4D434931, load, length, entry, crc32}` little-endian, then payload.
Verified in simulation: flash boot (every example), 1 MiB offset, corrupted image rejected, JTAG mailbox boot,
UART boot, SRAM boot after a JTAG preload (`reports/sim/soc_*.txt`).

**JTAG boot rule:** load SRAM while the ROM is waiting; do not reset the CPU afterwards (a CPU reset restarts the
ROM, whose MBIST clears SRAM).  Mode 3 is the mode for "preload, then reset".
