# MCU-I peripherals -- behaviour and limits

Register-level details: [REGISTERS.md](REGISTERS.md) (generated).  Common rules: 32-bit accesses only; a write to
a read-only register, a sub-word write, an unimplemented offset or an access to a clock-gated peripheral returns a
bus error with no side effect (MCU-I blocks; the vendored machine timer ignores writes to its offsets only).

## GPIO (`mcu_gpio`)
Direction, output, atomic OUT_SET/OUT_CLR/OUT_TGL, input through a 2-flop synchroniser per pin, rising/falling
edge interrupts (latched, W1C), level-high/low interrupts (not latched).  **Sampling limits:** a pulse shorter than
one clock period can be missed; a level must be stable for 2 clock periods to be guaranteed to produce an edge
event; input-to-IN latency is 2 cycles.  gpio[1:0] are boot straps during reset; gpio[4+c] feed GP-timer capture
channel c.  Output drivers, pull resistors, ESD and voltage tolerance belong to the foundry pad cells, not this RTL.

## UART (`mcu_uart`, derived from `sfv_uart`)
Separate TX/RX engines, divisor in clock cycles per bit (minimum 4), 8 data bits, parity none/even/odd, 1 or 2
stop bits, 8-entry TX and RX FIFOs.  RX: 2-flop synchroniser, start bit validated at mid-bit (glitches shorter
than half a bit rejected), sampling at mid-bit, first stop bit checked.  Deterministic FIFO behaviour: TX push
when full -> dropped + TX_OVF; RX byte when full -> dropped + RX_OVF; read when empty -> RX_EMPTY, no pop.
Framing error -> byte dropped + FRAME_ERR; parity error -> byte stored + PARITY_ERR.  Loopback mode; error
interrupt; DMA requests (TX not full / RX not empty).  Console output: `con_printf`.

## SPI (`mcu_spi`, derived from `sfv_spi`)
Master, modes 0-3 (CTRL bit 0 = CPOL, bit 1 = CPHA; the HAL maps the standard mode number), MSB first,
8/16/32-bit frames, SCK half period = DIV+1 cycles (fastest clk/2), 4 software chip selects, full duplex,
BUSY write protection (bus error), DONE/RX_VALID/RX_OVF, RX_AUTO (a DATA read starts the next all-ones frame:
lets one DMA channel stream a flash read; the final read starts one extra frame, harmless for flash).  SPI0 CS0 is
the boot flash.  Verified against an independent Python slave model in all 4 modes, 3 lengths, 3 dividers.

## I2C (`mcu_i2c`, new)
Master, byte commands {START, WRITE/READ, ACK/NACK, STOP}, 7-bit addressing as the first byte, repeated START,
clock stretching (waits for SCL high), 2-flop synchroniser + glitch filter (spikes < 4 cycles ignored), timeout
on stretched SCL (lines released, TIMEOUT), ARB_LOST if SDA is low while transmitting a 1.  **Open-drain only:**
outputs are pull-low enables; the pad must be an open-drain or tri-state cell with an external pull-up.  Between
START and STOP the idle master holds SCL low.  f_SCL = f_clk / (4 (PRESCALE+1)), PRESCALE >= 7.
Single master (no multi-master arbitration recovery).

## Machine timer (`sfv_timer`, vendored)
64-bit mtime with prescaler, mtimecmp (resets to all-ones: no interrupt after reset), msip.  Drives MTI/MSI.

## General-purpose timers (`mcu_gptimer`, new)
1 (BASIC) or 4 (INDUSTRIAL) 32-bit channels: prescaler, reload (period = (PRESCALE+1)(RELOAD+1)), compare,
periodic or one-shot (one-shot clears EN), input capture on rising/falling/both edges with overrun flag, status
W1C (a hardware event in the same cycle as a clear wins), per-event interrupt enables.

## PWM (`mcu_pwm`, new)
Shared 16-bit timebase + prescaler, 4 channels, duty shadow registers applied at period start (no runt pulses,
verified), polarity, per-channel output enable and SAFE level, registered outputs.  Reset state: outputs 0,
timebase stopped.  Fault input: 2-flop synchroniser, latched FAULT, all channels to SAFE within 3 clock cycles of
the pin edge (measured), clear refused while the input is active.  **Not a certified safety function** (no
independent shutdown path, no diagnostic-coverage analysis) -- see [SAFETY.md](SAFETY.md).

## Watchdog (`mcu_wdt`, new) -- see [SAFETY.md](SAFETY.md)
Down-counter with prescaler, set-only EN and LOCK, keyed service (KEY1 then KEY2), illegal service -> immediate
reset request, early-warning interrupt, optional pause while the debugger holds the CPU, reset cause recorded.

## Interrupt controller (`mcu_intc`, new)
16 level sources -> MEI; enable, software pending, priority 0-7 (0 = never), threshold, CLAIM (highest priority,
lowest index; no side effect), ACTIVE.  Sources: UART0 SPI0 GPIO GPTIMER WDT FAULT DBG MBIST DMA I2C0 UART1 SPI1
PWM BUSERR.  Asynchronous external events enter through GPIO synchronisers.  Latency in architectural terms: a
source flop change reaches mip.MEIP combinationally; the CPU traps at the next instruction boundary not inside a
bus access, plus trap entry (3 cycles); the HAL handler adds register saving and the claim read.  Measured
machine-timer latency is in VERIFICATION.md (simulation, not a guarantee).

## DMA (`mcu_dma`, derived from DataFabric)
One channel; memory-to-memory, peripheral-to-memory and memory-to-peripheral; word or byte elements; fixed or
incrementing source/destination; DREQ pacing (UART0/1 RX/TX, SPI0/1 RX/TX); validation before any access (13
error codes); bus errors stop the transfer and are reported with the address; abort at an element boundary (or
immediately while waiting for DREQ); completion/error interrupts.  **Access restriction:** a peripheral address
is legal only on a fixed side with DREQ pacing, so the DMA can never sweep side-effecting registers.  Peripheral
DMA is enabled only for UART and SPI data registers, whose data-valid/space-available semantics were reviewed
(one access per request level; the level is re-sampled only after the previous element completed).  4 cycles per
element with 1-cycle slaves.  The DMA clock cannot be gated while a transfer is active.

## DSP/MAC accelerator (`mcu_dsp`, new, optional) -- see [DSP.md](DSP.md)

## SYSCTRL, FAULT -- see [CLOCK_RESET.md](CLOCK_RESET.md) and [SAFETY.md](SAFETY.md)
