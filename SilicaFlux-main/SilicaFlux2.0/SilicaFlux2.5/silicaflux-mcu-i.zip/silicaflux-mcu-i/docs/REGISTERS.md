# MCU-I register reference

Generated from `configs/memmap.yaml` by `scripts/mcu_gen.py` — do not edit.

All registers are 32 bits wide, word aligned, little-endian; access them with 32-bit loads/stores only.
Reserved bits read as 0 and must be written as 0.  Access: RO read-only, RW read/write, WO write-only (reads 0), W1C write 1 to clear, W1S write 1 to set.  `domain: por` registers are reset only by the pin/power-on reset and survive soft and watchdog resets.

## sysctrl

System control: identity, boot straps, resets and reset cause, clock enables, bus-error capture, MBIST, debug lock, SRAM parity control

RTL: `rtl/power/mcu_sysctrl.sv`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | CHIP_ID | RO | `0x4D434901` | hardware revision ID |
| `0x004` | BOOT_MODE | RO | `0x0` |  |
| | `[1:0]` STRAPS | RO | | gpio[1:0] sampled 3 cycles after reset release (or JTAG override) |
| `0x008` | SCRATCH0 | RW | `0x0` | JTAG boot mailbox: entry point |
| `0x00C` | SCRATCH1 | RW | `0x0` | JTAG boot mailbox: JTAG_GO starts the image |
| `0x010` | TEST_STATUS | RW | `0x0` |  |
| | `[1:0]` STATE | RW | | 0 running, 1 pass, 2 fail (drives test_pass/test_fail pins) |
| | `[15:8]` CODE | RW | |  |
| `0x014` | SOFT_RESET | WO | `0x0` | write SOFT_RESET_KEY -> system reset (CPU, bus, peripherals; POR-domain registers kept) |
| `0x018` | RESET_CAUSE | W1C | `0x1` |  (POR domain) |
| | `[0]` POR | W1C | | pin/power-on reset |
| | `[1]` SOFT | W1C | |  |
| | `[2]` JTAG | W1C | | JTAG system reset request |
| | `[3]` WDT | W1C | | watchdog expiry or illegal service |
| | `[15:8]` WDT_COUNT | RO | | watchdog resets since POR (saturating) |
| `0x01C` | CLK_EN | RW | `0x1FF` |  |
| | `[0]` UART0 | RW | |  |
| | `[1]` SPI0 | RW | |  |
| | `[2]` GPTIMER | RW | |  |
| | `[3]` UART1 | RW | |  |
| | `[4]` SPI1 | RW | |  |
| | `[5]` I2C0 | RW | |  |
| | `[6]` PWM | RW | |  |
| | `[7]` DMA | RW | |  |
| | `[8]` DSP | RW | |  |
| | `[16]` CPU_SLEEP_CG | RW | | gate the CPU clock while it waits in WFI |
| `0x020` | BUSERR_ADDR | RO | `0x0` | address of the first unacknowledged decode error |
| `0x024` | BUSERR_INFO | RW | `0x0` |  |
| | `[0]` VALID | W1C | |  |
| | `[2:1]` MASTER | RO | |  |
| | `[3]` WRITE | RO | |  |
| `0x028` | MBIST_CTRL | RW | `0x0` |  |
| | `[0]` START | WO | |  |
| | `[1]` BG_CHK | RW | |  |
| | `[8]` IRQ_EN | RW | |  |
| `0x02C` | MBIST_STATUS | RO | `0x0` |  |
| | `[0]` BUSY | RO | |  |
| | `[1]` DONE | RO | |  |
| | `[2]` FAIL | RO | |  |
| | `[11:8]` FAIL_BANK | RO | |  |
| | `[14:12]` FAIL_ELEM | RO | |  |
| | `[31:16]` FAIL_ADDR | RO | |  |
| `0x030` | DOORBELL | RW | `0x0` |  |
| | `[0]` RING | RW | |  |
| `0x034` | BOOT_STATUS | RW | `0x0` | boot progress/result code written by the boot ROM; survives soft and watchdog reset (POR domain) |
| `0x038` | FEATURES | RO | `0x0` |  |
| | `[0]` RV32M | RO | |  |
| | `[1]` FAST_MUL | RO | |  |
| | `[2]` PARITY | RO | |  |
| | `[3]` DMA | RO | |  |
| | `[4]` I2C | RO | |  |
| | `[5]` PWM | RO | |  |
| | `[6]` DSP | RO | |  |
| | `[9:8]` N_UART | RO | |  |
| | `[11:10]` N_SPI | RO | |  |
| | `[14:12]` N_TIMER | RO | |  |
| | `[23:16]` GPIO_N | RO | |  |
| | `[24]` CLK_MON | RO | | clock monitor present (0: not implemented) |
| | `[25]` SECURE_BOOT | RO | | authenticated boot (0: not implemented) |
| | `[26]` OTP | RO | | OTP/eFuse (0: not implemented) |
| `0x03C` | SRAM_SIZE | RO | `0x0` | configured SRAM bytes |
| `0x040` | DBG_LOCK | RW | `0x0` |  (POR domain) |
| | `[0]` LOCKED | RW | | write DBG_LOCK_KEY to set; cleared only by POR; blocks JTAG SBA, CPU hold, JTAG system reset and boot override |
| `0x044` | PARITY_CTRL | RW | `0x0` |  |
| | `[0]` CHECK_EN | RW | | report SRAM parity errors as bus errors |
| | `[1]` INJECT | RW | | store inverted parity on the next SRAM write (self-clearing; test only) |
| `0x048` | PMU_STATUS | RO | `0x0` |  |
| | `[0]` CPU_SLEEP | RO | |  |

## intc

Interrupt controller: 16 level sources -> CPU machine external interrupt (MEI), 7 priority levels, threshold, claim

RTL: `rtl/interrupts/mcu_intc.sv`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | PENDING | RO | `0x0` | live source levels OR software-pending bits |
| `0x004` | ENABLE | RW | `0x0` |  |
| `0x008` | CLAIM | RO | `0x0` |  |
| | `[7:0]` ID | RO | | 1 + index of the highest-priority active source (lowest index wins ties); 0 = none. No side effect: sources are cleared at the peripheral |
| `0x00C` | SWPEND | RW | `0x0` | software-set pending bits (software interrupts per source) |
| `0x010` | THRESHOLD | RW | `0x0` |  |
| | `[2:0]` LEVEL | RW | | only priorities > LEVEL interrupt |
| `0x014` | ACTIVE | RO | `0x0` | pending & enabled & priority > threshold |
| `0x020` | PRIO0 | RW | `0x11111111` | priority of sources 0..7, 4 bits each (3 LSBs used; 0 = never) |
| `0x024` | PRIO1 | RW | `0x11111111` | priority of sources 8..15 |

## mtimer

RISC-V CLINT-style machine timer: mtime/mtimecmp -> MTI, msip -> MSI

RTL: `third_party/silicaflux-v/rtl/periph/sfv_periph_misc.sv (sfv_timer, unmodified)`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | MTIME_LO | RW | `0x0` |  |
| `0x004` | MTIME_HI | RW | `0x0` |  |
| `0x008` | MTIMECMP_LO | RW | `0xFFFFFFFF` |  |
| `0x00C` | MTIMECMP_HI | RW | `0xFFFFFFFF` |  |
| `0x010` | MSIP | RW | `0x0` |  |
| | `[0]` MSIP | RW | |  |
| `0x014` | PRESCALE | RW | `0x0` |  |
| | `[15:0]` DIV | RW | | mtime += 1 every DIV+1 cycles |

## uart

UART: 8 data bits, optional even/odd parity, 1 or 2 stop bits, TX/RX FIFOs, framing/parity/overrun detection

RTL: `rtl/uart/mcu_uart.sv`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | DATA | RW | `0x80000000` |  |
| | `[7:0]` BYTE | RW | | W: push TX byte (dropped and TX_OVF set if full); R: pop RX byte |
| | `[31]` RX_EMPTY | RO | | no byte was popped |
| `0x004` | STATUS | RW | `0x3` |  |
| | `[0]` TX_READY | RO | |  |
| | `[1]` TX_IDLE | RO | |  |
| | `[2]` RX_VALID | RO | |  |
| | `[3]` RX_OVF | W1C | |  |
| | `[4]` FRAME_ERR | W1C | |  |
| | `[5]` TX_OVF | W1C | |  |
| | `[6]` PARITY_ERR | W1C | |  |
| | `[7]` RX_FULL | RO | |  |
| | `[12:8]` RX_COUNT | RO | |  |
| | `[20:16]` TX_COUNT | RO | |  |
| `0x008` | CTRL | RW | `0x0` |  |
| | `[0]` TX_IRQ_EN | RW | | irq while TX_IDLE |
| | `[1]` RX_IRQ_EN | RW | | irq while RX_VALID |
| | `[2]` LOOPBACK | RW | |  |
| | `[4:3]` PARITY | RW | | 0 none, 1 even, 2 odd, 3 reserved (= none) |
| | `[5]` STOP2 | RW | |  |
| | `[6]` ERR_IRQ_EN | RW | | irq while any error flag is set |
| `0x00C` | BAUD | RW | `0xD9` |  |
| | `[15:0]` DIV | RW | | bit period in clk cycles (values < 4 are stored as 4) |

## spi

SPI master: modes 0-3, 8/16/32-bit frames MSB first, 4 chip selects, DMA RX auto mode

RTL: `rtl/spi/mcu_spi.sv`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | DATA | RW | `0x0` | W: start a frame (bus error while BUSY); R: last received frame, clears RX_VALID; in RX_AUTO mode a read also starts the next frame with all-ones |
| `0x004` | STATUS | RW | `0x0` |  |
| | `[0]` BUSY | RO | |  |
| | `[1]` DONE | W1C | |  |
| | `[2]` RX_VALID | RO | |  |
| | `[3]` RX_OVF | W1C | | a frame completed while RX_VALID was still set |
| `0x008` | CTRL | RW | `0x0` |  |
| | `[0]` CPOL | RW | |  |
| | `[1]` CPHA | RW | |  |
| | `[2]` IRQ_EN | RW | | irq while DONE |
| | `[5:4]` LEN | RW | | 0: 8, 1: 16, 2: 32 bits (3 = 32) |
| | `[6]` RX_AUTO | RW | |  |
| | `[11:8]` CS | RW | | bit i = drive cs_n[i] low |
| `0x00C` | DIV | RW | `0x3` |  |
| | `[15:0]` DIV | RW | | SCK half period = DIV+1 clk cycles |

## gpio

GPIO: direction, output, atomic set/clear/toggle, synchronised inputs, edge and level interrupts

RTL: `rtl/gpio/mcu_gpio.sv`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | IN | RO | `0x0` | synchronised pad inputs (2-flop synchroniser) |
| `0x004` | OUT | RW | `0x0` |  |
| `0x008` | OE | RW | `0x0` | 1 = output |
| `0x00C` | IRQ_RISE_EN | RW | `0x0` |  |
| `0x010` | IRQ_FALL_EN | RW | `0x0` |  |
| `0x014` | IRQ_PEND | W1C | `0x0` | latched edge events |
| `0x018` | OUT_SET | WO | `0x0` |  |
| `0x01C` | OUT_CLR | WO | `0x0` |  |
| `0x020` | OUT_TGL | WO | `0x0` |  |
| `0x024` | IRQ_HIGH_EN | RW | `0x0` | level-high interrupt enable (not latched) |
| `0x028` | IRQ_LOW_EN | RW | `0x0` | level-low interrupt enable (not latched) |
| `0x02C` | IRQ_STATUS | RO | `0x0` | IRQ_PEND | active level conditions |

## wdt

Watchdog: down-counter, keyed service sequence, early-warning interrupt, reset request, lock

RTL: `rtl/watchdog/mcu_wdt.sv`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | CTRL | RW | `0x0` |  |
| | `[0]` EN | W1S | | set-only: once running only a reset stops the watchdog |
| | `[1]` LOCK | W1S | | set-only: LOAD/PRESCALE/EWI_THRESH/CTRL writes then return a bus error |
| | `[2]` EWI_EN | RW | |  |
| | `[3]` DBG_PAUSE | RW | | pause while the debugger holds the CPU |
| `0x004` | LOAD | RW | `0xFFFFFF` | timeout in ticks; loaded on enable and on every legal service |
| `0x008` | PRESCALE | RW | `0x0` |  |
| | `[15:0]` DIV | RW | | one tick every DIV+1 clk cycles |
| `0x00C` | COUNT | RO | `0xFFFFFF` |  |
| `0x010` | SERVICE | WO | `0x0` | write WDT_KEY1 then WDT_KEY2 to reload; any other value -> ILLEGAL and immediate reset request (when EN) |
| `0x014` | EWI_THRESH | RW | `0x0` | early warning when COUNT <= EWI_THRESH |
| `0x018` | STATUS | RW | `0x0` |  |
| | `[0]` EWI | W1C | |  |
| | `[1]` RUNNING | RO | |  |
| | `[2]` ILLEGAL | RO | |  |
| | `[3]` KEY1_SEEN | RO | |  |

## fault

System health / fault log (POR domain: survives soft and watchdog reset)

RTL: `rtl/debug/mcu_fault.sv`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | STATUS | W1C | `0x0` |  (POR domain) |
| | `[0]` BUS_DECODE | W1C | | unmapped/denied/misaligned access by any master |
| | `[1]` PERIPH_ERR | W1C | | peripheral bus error response |
| | `[2]` SRAM_PARITY | W1C | |  |
| | `[3]` DMA_ERR | W1C | |  |
| | `[4]` WDT_EWI | W1C | |  |
| | `[5]` WDT_RESET | W1C | |  |
| | `[6]` BOOT_FAIL | W1C | | set by firmware |
| | `[7]` UART_ERR | W1C | |  |
| | `[8]` I2C_ERR | W1C | |  |
| | `[9]` PWM_FAULT | W1C | |  |
| | `[10]` SW_FAULT | W1C | |  |
| | `[11]` CLK_FAULT | W1C | | reserved: no clock monitor implemented, never set |
| `0x004` | IRQ_EN | RW | `0x0` |  (POR domain) |
| `0x008` | SET | WO | `0x0` | write 1 to set STATUS bits (firmware-reported faults, test) |
| `0x00C` | BUS_ERR_COUNT | RO | `0x0` | decode errors (saturating) (POR domain) |
| `0x010` | PARITY_ERR_COUNT | RO | `0x0` |  (POR domain) |
| `0x014` | PERIPH_ERR_COUNT | RO | `0x0` |  (POR domain) |
| `0x018` | LAST_ADDR | RO | `0x0` |  (POR domain) |
| `0x01C` | LAST_INFO | RO | `0x0` |  (POR domain) |
| | `[3:0]` SOURCE | RO | | 1 decode, 2 peripheral, 3 parity |
| | `[5:4]` MASTER | RO | |  |
| | `[6]` WRITE | RO | |  |
| `0x020` | CLEAR_COUNTS | WO | `0x0` |  |

## gptimer

General-purpose timers: N channels (stride 0x20), prescaler, reload, compare, periodic/one-shot, input capture

RTL: `rtl/timers/mcu_gptimer.sv`

Channel registers (offset < 0x20) repeat every 0x20 bytes for each of the `N_TIMER` channels.

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | CH_CTRL | RW | `0x0` |  |
| | `[0]` EN | RW | | cleared by hardware at the end of a one-shot period |
| | `[1]` ONESHOT | RW | |  |
| | `[2]` OVF_IE | RW | |  |
| | `[3]` CMP_IE | RW | |  |
| | `[4]` CAP_IE | RW | |  |
| | `[6:5]` CAP_EDGE | RW | | 0 off, 1 rising, 2 falling, 3 both |
| `0x004` | CH_PRESCALE | RW | `0x0` |  |
| | `[15:0]` DIV | RW | |  |
| `0x008` | CH_RELOAD | RW | `0xFFFFFFFF` | counter counts 0..RELOAD, then OVF |
| `0x00C` | CH_COUNT | RW | `0x0` |  |
| `0x010` | CH_CMP | RW | `0xFFFFFFFF` |  |
| `0x014` | CH_CAPTURE | RO | `0x0` |  |
| `0x018` | CH_STATUS | W1C | `0x0` |  |
| | `[0]` OVF | W1C | |  |
| | `[1]` CMP | W1C | |  |
| | `[2]` CAP | W1C | |  |
| | `[3]` CAP_OVR | W1C | |  |
| `0x100` | IRQ_STATUS | RO | `0x0` | per-channel interrupt request |
| `0x104` | INFO | RO | `0x0` |  |
| | `[3:0]` N_CH | RO | |  |

## pwm

PWM: shared 16-bit timebase, per-channel shadowed duty, output enable, polarity, safe state and latched fault input

RTL: `rtl/pwm/mcu_pwm.sv`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | CTRL | RW | `0x0` |  |
| | `[0]` EN | RW | |  |
| | `[1]` FAULT_EN | RW | |  |
| | `[2]` FAULT_POL | RW | | 1 = fault input active high |
| | `[3]` FAULT_IE | RW | |  |
| | `[4]` PERIOD_IE | RW | |  |
| `0x004` | PRESCALE | RW | `0x0` |  |
| | `[15:0]` DIV | RW | |  |
| `0x008` | PERIOD | RW | `0xFFFF` |  |
| | `[15:0]` TOP | RW | | counter counts 0..TOP (period = TOP+1 ticks) |
| `0x00C` | COUNT | RO | `0x0` |  |
| `0x010` | STATUS | RW | `0x0` |  |
| | `[0]` FAULT | W1C | | latched; a clear is ignored while the fault input is active |
| | `[1]` PERIOD | W1C | |  |
| | `[2]` FAULT_IN | RO | |  |
| `0x014` | OUT_EN | RW | `0x0` |  |
| `0x018` | SAFE | RW | `0x0` | per-channel output level when disabled or faulted |
| `0x01C` | POL | RW | `0x0` | per-channel inversion of the active level |
| `0x020` | DUTY0 | RW | `0x0` |  |
| | `[16:0]` DUTY | RW | | active while COUNT < DUTY; applied at the next period start |
| `0x024` | DUTY1 | RW | `0x0` |  |
| | `[16:0]` DUTY | RW | |  |
| `0x028` | DUTY2 | RW | `0x0` |  |
| | `[16:0]` DUTY | RW | |  |
| `0x02C` | DUTY3 | RW | `0x0` |  |
| | `[16:0]` DUTY | RW | |  |

## i2c

I2C master: START/repeated START/STOP, 7-bit addressing by byte commands, ACK/NACK, clock stretching, glitch filter, timeout, open-drain outputs

RTL: `rtl/i2c/mcu_i2c.sv`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | PRESCALE | RW | `0x3F` |  |
| | `[15:0]` QTR | RW | | quarter SCL period = QTR+1 clk cycles |
| `0x004` | CTRL | RW | `0x0` |  |
| | `[0]` EN | RW | |  |
| | `[1]` IRQ_EN | RW | | irq while DONE or an error flag is set |
| `0x008` | CMD | WO | `0x0` |  |
| | `[0]` START | WO | | (repeated) START before the byte |
| | `[1]` STOP | WO | | STOP after the byte |
| | `[2]` READ | WO | |  |
| | `[3]` WRITE | WO | |  |
| | `[4]` NACK | WO | | after READ: send NACK (1) instead of ACK |
| `0x00C` | TXDATA | RW | `0x0` |  |
| | `[7:0]` BYTE | RW | |  |
| `0x010` | RXDATA | RO | `0x0` |  |
| | `[7:0]` BYTE | RO | |  |
| `0x014` | STATUS | RW | `0x0` |  |
| | `[0]` BUSY | RO | |  |
| | `[1]` DONE | W1C | |  |
| | `[2]` RX_NACK | RO | | acknowledge bit received after WRITE (1 = NACK) |
| | `[3]` TIMEOUT | W1C | |  |
| | `[4]` BUS_BUSY | RO | | between START and STOP |
| | `[5]` ARB_LOST | W1C | | SDA low while the master released it during a WRITE |
| `0x018` | TIMEOUT | RW | `0x0` |  |
| | `[23:0]` CYCLES | RW | | max clk cycles SCL may be stretched; 0 disables |

## dma

Single-channel DMA (derived from SilicaFlux DataFabric dma_transfer_engine): memory-to-memory, peripheral-to-memory and memory-to-peripheral with DREQ pacing

RTL: `rtl/dma/mcu_dma.sv`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | CONTROL | WO | `0x0` |  |
| | `[0]` START | WO | |  |
| | `[1]` ABORT | WO | |  |
| `0x004` | STATUS | RO | `0x0` |  |
| | `[0]` BUSY | RO | |  |
| | `[1]` DONE | RO | |  |
| | `[2]` ERROR | RO | |  |
| | `[3]` ABORTED | RO | |  |
| | `[11:8]` STATE | RO | |  |
| `0x008` | SRC_ADDR | RW | `0x0` |  |
| `0x00C` | DST_ADDR | RW | `0x0` |  |
| `0x010` | LENGTH | RW | `0x0` | bytes |
| `0x014` | BYTES_DONE | RO | `0x0` |  |
| `0x018` | INT_ENABLE | RW | `0x0` |  |
| | `[0]` DONE | RW | |  |
| | `[1]` ERROR | RW | |  |
| `0x01C` | INT_STATUS | W1C | `0x0` |  |
| | `[0]` DONE | W1C | |  |
| | `[1]` ERROR | W1C | |  |
| `0x020` | ERROR_CODE | RO | `0x0` |  |
| | `[3:0]` CODE | RO | | 0 none 1 zero length 2 length 3 src align 4 dst align 5 src overflow 6 dst overflow 7 overlap 8 read bus error 9 write bus error 10 aborted 11 peripheral rule 12 length alignment 13 bad DREQ |
| `0x024` | ERROR_ADDR | RO | `0x0` |  |
| `0x028` | INFO | RO | `0x0` |  |
| | `[7:0]` MAX_LEN_LOG2 | RO | |  |
| | `[23:8]` DREQ_MASK | RO | |  |
| | `[31:24]` VERSION | RO | |  |
| `0x02C` | ID | RO | `0x53464D44` |  |
| `0x030` | MODE | RW | `0x0` |  |
| | `[0]` SRC_FIXED | RW | |  |
| | `[1]` DST_FIXED | RW | |  |
| | `[2]` BYTE | RW | | 8-bit elements (fixed side: word register, value in [7:0]) |
| | `[11:8]` DREQ_SEL | RW | | 0 = free running; see dreqs |

## dsp

Integer DSP/MAC accelerator: 16x16 signed MAC into a 32-bit accumulator, dual MAC, Q15 multiply, saturating add, 16-tap FIR

RTL: `rtl/dsp/mcu_dsp.sv`

| Offset | Register | Access | Reset | Description |
|---|---|---|---|---|
| `0x000` | CTRL | RW | `0x0` |  |
| | `[0]` SAT | RW | | saturate accumulations |
| | `[1]` ROUND | RW | | round-to-nearest on right shifts |
| | `[12:8]` SHIFT | RW | | right shift for the _Q outputs |
| `0x004` | STATUS | RW | `0x0` |  |
| | `[0]` OVF | W1C | | sticky overflow (saturation event or wrap) |
| | `[1]` BUSY | RO | |  |
| `0x008` | ACC | RW | `0x0` |  |
| `0x00C` | OPA | RW | `0x0` | packed {hi16, lo16} operand of DOT2 |
| `0x010` | MAC | WO | `0x0` | {x[31:16], y[15:0]}: ACC += x*y |
| `0x014` | DOT2 | WO | `0x0` | ACC += OPA.lo*w.lo + OPA.hi*w.hi (2 cycles) |
| `0x018` | MULQ | WO | `0x0` | {x,y}: RESULT = sat16(round((x*y) >> 15)) |
| `0x01C` | SADD | WO | `0x0` | {x,y}: RESULT = sat16(x+y) |
| `0x020` | RESULT | RO | `0x0` |  |
| `0x024` | ACC_Q | RO | `0x0` | sat16(round(ACC >> SHIFT)) |
| `0x040` | FIR_CTRL | RW | `0x0` |  |
| | `[3:0]` NTAPS_M1 | RW | | taps - 1 |
| | `[8]` CLEAR | WO | | clear the delay line |
| `0x044` | FIR_IN | WO | `0x0` | push a 16-bit sample and compute one output (NTAPS cycles, BUSY); write while BUSY -> bus error |
| `0x048` | FIR_OUT | RO | `0x0` |  |
| `0x04C` | FIR_OUT_Q | RO | `0x0` | sat16(round(FIR_OUT >> SHIFT)) |
| `0x080` ×16 (stride 4) | COEF0 | RW | `0x0` |  |
| | `[15:0]` C | RW | |  |
