# FPGA prototype -- Radiona ULX3S (Lattice ECP5 LFE5U-85F-6BG381)

The ULX3S is a commercially available, openly documented board (85F version required for the INDUSTRIAL SRAM).
Flow: Yosys `synth_ecp5` -> nextpnr-ecp5 -> ecppack (Project Trellis), all open source; no vendor IP.

```bash
fpga/ulx3s/build.sh industrial      # or basic -> build/fpga/<variant>/mcu_ulx3s.bit
openFPGALoader -b ulx3s build/fpga/industrial/mcu_ulx3s.bit     # (board attached; not done here)
```

**Status: bitstreams were generated; they have NOT been loaded onto or executed on a physical board.**  No FPGA
validation is claimed.  Results of this run (seed 1): see the table at the end (copied from `reports/fpga/`).

## Implementation

* Clock: the 25 MHz oscillator directly (no PLL); UART divisor 217 = 115200 Bd.
* SRAM: SRAM Wrapper Library FPGA backend -> ECP5 DP16KD block RAM (inference, no IP cores); the boot ROM is logic.
* Clock gates: `SFV_NO_CLOCK_GATE` (functionally identical, gating is power-only).
* `DEMO_LOOPBACK = 1` (default) implements inside the FPGA the loopbacks the firmware expects (the same as the
  simulation board): gpio[2]->gpio[3], gpio[8]->gpio[4], pwm[0]->gpio[5], gpio[9]->PWM fault, SPI0 CS1
  MOSI->MISO.  Set 0 to use header jumpers instead.
* Timing: a register slice in front of the peripheral bridge cuts the CPU-address -> peripheral-read path that
  initially limited Fmax to ~19-20 MHz (ISSUES.md MCU-R4 and the slice note in `rtl/top/mcu_soc.sv`).

## Pins (`fpga/ulx3s/mcu_ulx3s.lpf`)

| Function | ULX3S | Function | ULX3S |
|---|---|---|---|
| clock 25 MHz | G2 | reset | btn F1 (R1) |
| straps {btn3, btn2} | UP (R18), F2 (T1): none = SPI flash, F2 = JTAG, UP = UART, both = SRAM | UART0 | on-board FT231X (L4 TX, M1 RX) |
| JTAG TCK/TMS/TDI/TDO | gp0/gn0/gp1/gn1 | SPI0 flash PMOD SCK/MOSI/MISO/CS# | gp2/gn2/gp3/gn3 |
| SPI1 SCK/MOSI/MISO/CS# | gp4/gn4/gp5/gn5 | I2C SCL/SDA (open drain, pull-up) | gp6/gn6 |
| UART1 TX/RX | gp7/gn7 | PWM0..3, fault | gp8, gp9, gp10, gp11, gn8 |
| GPIO[15:10] | gn9, gn10, gn11, gp12, gp13, gp14 | LEDs | {pass, fail, blink, pwm1, sleep, heartbeat x3} |

Pins gp0..gn3 are those of the SilicaFlux-V ULX3S build; the remaining J1 assignments follow the ULX3S reference
constraint file and **must be checked against the official LPF of the board revision before connecting external
hardware.**

## Board bring-up checklist (to be executed; nothing below has been done on hardware)

| # | Step | Expected | Result |
|---|---|---|---|
| 1 | Program the bitstream (`openFPGALoader -b ulx3s ...`) | DONE LED, heartbeat LEDs blink | not run |
| 2 | Open the FT231X port at 115200 8N1, press F1 (reset) | MCU-I resets | not run |
| 3 | Boot: hold UP while releasing F1 (UART mode), send `build/fw/<variant>/demo.img` raw | ROM banner, `boot: waiting for UART image`, then `K` and the demo starts | not run |
| 4 | Alternatively program `demo.img` into a SPI NOR on the gp2..gn3 PMOD at offset 0 (or the on-board flash at 0x100000 with an SPI-to-USRMCLK adaptation, not implemented) and reset with no button | `boot: spi image at ...` | not run |
| 5 | Version message | `=== SilicaFlux MCU-I <variant> demo, chip 4d434901 ...` | not run |
| 6 | SRAM self-test | `[PASS] SRAM self-test` | not run |
| 7 | Timers and interrupts | `[PASS] timer interrupts`; LED2 (gpio[8]) toggles | not run |
| 8 | SPI loopback | `[PASS] SPI0 loopback` | not run |
| 9 | DMA memory copy (INDUSTRIAL) | `[PASS] DMA 2 KiB memory copy` | not run |
| 10 | GPIO + PWM outputs | LED2 blinking; PWM on gp8..gp11 at 25/50/75/100 % (scope); LED3 = PWM1 | not run |
| 11 | Fault + watchdog | `[PASS] fault log readable`, `[PASS] watchdog running and serviced`; then load `07_watchdog.img`: reset after the hang and `recovered ... by watchdog reset` | not run |
| 12 | JTAG | external adapter on gp0..gn1: IDCODE `0x14D49001`; SBA read of `0x40000000` = `0x4D434901` | not run |
| 13 | I2C (INDUSTRIAL) | 24Cxx EEPROM at 0x50 + pull-ups on gp6/gn6: `05_i2c` passes (sensor part needs a device at 0x48) | not run |
| 14 | Record | UART logs, LED photos, scope captures into `reports/fpga/hardware/` | not run |

## Results of this run (`reports/fpga/<variant>/`, nextpnr-ecp5 0.6, seed 1, 25 MHz constraint)

| Variant | LUT4 | FF | CCU2C | DP16KD (of 208) | MULT18X18D | post-route Fmax (clk) | bitstream SHA-256 |
|---|---|---|---|---|---|---|---|
| BASIC | 10163 | 2452 | 584 | 32 | 0 | 31.50 MHz (PASS at 25 MHz) | `7f062e49fefc3bee...` |
| INDUSTRIAL | 17975 | 4810 | 1356 | 64 | 2 | 29.28 MHz (PASS at 25 MHz) | `fcece69cad8a0fb3...` |

History of the INDUSTRIAL timing closure (all post-route, seed 1): 25.05 MHz with a Yosys `-abc9` netlist whose
ABC step had aborted (discarded), 20.49 MHz with the classic ABC mapper, 19.27 MHz after moving the M-unit
negation into a prepare cycle (path was elsewhere), 28.38 MHz after inserting the register slice in front of
the peripheral bridge, **29.28 MHz** in the final run (after the DMA range-check fix, ISSUES.md MCU-R9; this is the
delivered bitstream).  Results vary with the placement seed; a different seed or tool version can move Fmax by
several MHz -- re-run `fpga/ulx3s/build.sh` and check `nextpnr.log` before relying on a bitstream.  In one earlier
INDUSTRIAL run nextpnr-ecp5 returned a non-zero exit code after "Program finished normally" with a complete
configuration; `build.sh` then packs the bitstream from that configuration and writes `nextpnr_exit_note.txt`
(the final runs of both variants exited normally).  `USE_PLL=1
fpga/ulx3s/build.sh` builds a 20 MHz variant (ECP5 PLL) if more margin is needed.
