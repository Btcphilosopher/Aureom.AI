# MCU-I system bus

The bus is the SilicaFlux DataFabric SFB2 crossbar, vendored unmodified
(`third_party/silicaflux-datafabric/rtl/interconnect/`).  Its protocol specification is
`third_party/silicaflux-datafabric/docs/datafabric/PROTOCOL.md`; this file only records how MCU-I uses it.

| Requirement | How it is met |
|---|---|
| 32-bit addresses / 32-bit data / byte strobes | SFB2 AW = 32, DW = 32, `req_wstrb[3:0]` |
| request / response handshakes, backpressure | `req_valid/req_ready`, `rsp_valid/rsp_ready` on every port |
| error responses | `rsp_error`: unmapped address, access-matrix denial, misaligned address (crossbar), ROM write (ROM), peripheral sub-word write / absent page / unimplemented offset / gated peripheral (bridge), SRAM parity error (bank) |
| address decoding | per-master decoder generated from `mcu_memmap_pkg` (base/mask per slave) |
| arbitration | per-slave round robin, grant lock under backpressure; ABC PDR proofs of exclusivity, conservation, bounded waiting (upstream harness, re-run here: `xbar_3x2_upstream`, `arbiter_rr_n4`) |
| deterministic, verifiable | one transaction per port, in-order responses, 0 added cycles |

Masters that speak SFB v1 (CPU ports, JTAG SBA) connect directly with `rsp_ready = 1` (PROTOCOL.md section 1);
v1 slaves (boot ROM, peripheral bridge) sit behind `sfb_v1_slave_adapter`.  SRAM banks are native SFB2
(`mcu_sram_bank`).

A request-side register slice (`sfb_reg_slice`, DataFabric, REQ_SLICE = 1, RSP_SLICE = 0) sits between the
crossbar and the peripheral bridge adapter.  It breaks the CPU-address -> crossbar -> bridge -> read-data path
(FPGA critical path, ISSUES.md MCU-R4) at the cost of one extra cycle per peripheral access; ROM and SRAM paths
are unchanged.  The "0 added cycles" property above refers to the crossbar itself.

**Standard-bus compatibility.** SFB2 is SilicaFlux's own OBI-style protocol.  No Wishbone, AHB, APB or AXI
bridge is included and no compatibility with those standards is claimed (renaming signals would not make it
compatible).  An AXI4-Lite or AHB-Lite bridge is a small, separate block if external IP requires it.

**Clocking.** Single clock domain; the only CDC is the JTAG TCK domain, crossed inside `mcu_jtag_dbg` with a
toggle handshake through two-flop synchronisers (upstream design, documented in its header).

**Reset during transactions.** All bus state resets with `sys_rst_n`; a reset cancels every transaction in
flight (PROTOCOL.md R11).  The fault log and reset cause live in the POR domain and record the event.

**Measured contention.** With CPU instruction fetch, CPU data and DMA all targeting SRAM, the DMA copy of 1 KiB
in the SoC test (`06_dma_copy`) completes correctly while the CPU loads from the same bank; the cycle count per
word is reported in [VERIFICATION.md](VERIFICATION.md).
