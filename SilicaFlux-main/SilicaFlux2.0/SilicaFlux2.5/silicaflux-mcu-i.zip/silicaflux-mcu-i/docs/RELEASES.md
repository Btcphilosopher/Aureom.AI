# Incremental releases -- status

| Release | Scope | Status | Evidence |
|---|---|---|---|
| 1 | CPU + ROM + SRAM + UART; firmware boots and prints in simulation | **done (simulation)** | `01_hello` boots through the ROM from the SPI-flash model and prints over UART (both variants); riscv-tests on the CPU |
| 2 | bus + GPIO + timer + interrupts | **done (simulation)** | `02_blink`, `03_timer_irq`; unit tests gpio, gptimer, intc; formal intc |
| 3 | SPI + external flash boot | **done (simulation)** | every scenario boots from the flash model; `09_flash_boot`; 1 MiB offset, corrupted image, UART/JTAG/SRAM boot modes |
| 4 | watchdog + reset supervision | **done (simulation)** | `07_watchdog` (hang -> reset -> recovery, reset cause, POR-domain fault log); unit + formal wdt |
| 5 | DMA + I2C + PWM (INDUSTRIAL) | **done (simulation)** | `05_i2c`, `06_dma_copy`, `08_pwm`; unit tests i2c/dma/pwm; formal dma |
| 6 | DSP/MAC accelerator, benchmarked | **done (simulation + synthesis area)** | `10_dsp_fir` bit-exact; `reports/bench/dsp_benchmark.md` |
| 7 | FPGA demonstration | **bitstreams built, NOT executed on hardware** | `reports/fpga/`; board checklist in FPGA.md awaits a ULX3S-85F |
| 8 | ASIC synthesis / physical design experiments | **logic synthesis done on 3 public PDKs; no placement/routing/STA** (OpenROAD/OpenSTA unavailable here) | `reports/asic/`; ASIC.md |
| 9 | DFT and manufacturing preparation | **provisions + readiness checklist; no scan/ATPG** | DFT.md, ISSUES.md |

The baseline (CPU, memory, UART) was validated first; every later release re-ran the complete regression.
