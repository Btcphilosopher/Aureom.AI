# MCU-I memory map

Generated from `configs/memmap.yaml` by `scripts/mcu_gen.py` — do not edit.

## Regions

| Region | Base | Window | Kind | Access | Notes |
|---|---|---|---|---|---|
| BOOT_ROM | `0x00000000` | 8 KiB | rom | rx | 8 KiB mask-programmed boot ROM (window = ROM size; writes -> bus error) |
| SRAM | `0x10000000` | 256 KiB | memory | rwx | 4 banks, window sized by configuration (BASIC 64 KiB, INDUSTRIAL 128 KiB, max 256 KiB); addresses above the configured size -> decode error |
| PERIPH | `0x40000000` | 128 KiB | window | rw | register bus behind sfv_periph_bridge, 32 pages of 4 KiB; execute-never |

Everything else is unmapped: any access returns a bus error (no aliasing).

## Configured sizes

| Variant | SRAM | ROM | GPIO | Timers | Features |
|---|---|---|---|---|---|
| BASIC | 64 KiB (4 banks) | 8 KiB | 16 | 1 | RV32I, no parity |
| INDUSTRIAL | 128 KiB (4 banks) | 8 KiB | 32 | 4 | UART1, SPI1, I2C, PWM, DMA, DSP, RV32M, parity |

## Peripheral pages (4 KiB each)

| Page | Base | Block | Present when | RTL |
|---|---|---|---|---|
| SYSCTRL | `0x40000000` | sysctrl | always | `rtl/power/mcu_sysctrl.sv` |
| INTC | `0x40001000` | intc | always | `rtl/interrupts/mcu_intc.sv` |
| MTIMER | `0x40002000` | mtimer | always | `third_party/silicaflux-v/rtl/periph/sfv_periph_misc.sv (sfv_timer, unmodified)` |
| UART0 | `0x40003000` | uart | always | `rtl/uart/mcu_uart.sv` |
| SPI0 | `0x40004000` | spi | always | `rtl/spi/mcu_spi.sv` |
| GPIO | `0x40005000` | gpio | always | `rtl/gpio/mcu_gpio.sv` |
| DMA | `0x40006000` | dma | HAS_DMA | `rtl/dma/mcu_dma.sv` |
| FAULT | `0x40007000` | fault | always | `rtl/debug/mcu_fault.sv` |
| WDT | `0x40008000` | wdt | always | `rtl/watchdog/mcu_wdt.sv` |
| GPTIMER | `0x40009000` | gptimer | always | `rtl/timers/mcu_gptimer.sv` |
| PWM | `0x4000A000` | pwm | HAS_PWM | `rtl/pwm/mcu_pwm.sv` |
| I2C0 | `0x4000B000` | i2c | HAS_I2C | `rtl/i2c/mcu_i2c.sv` |
| UART1 | `0x4000C000` | uart | HAS_UART1 | `rtl/uart/mcu_uart.sv` |
| SPI1 | `0x4000D000` | spi | HAS_SPI1 | `rtl/spi/mcu_spi.sv` |
| DSP | `0x4000E000` | dsp | HAS_DSP | `rtl/dsp/mcu_dsp.sv` |

Absent pages and unimplemented offsets return a bus error.

## Bus masters

| Index | Master | Present | Notes |
|---|---|---|---|
| 0 | DBG | always | JTAG system-bus access (blocked when SYSCTRL.DBG_LOCK is set) |
| 1 | CPUD | always | CPU data port |
| 2 | CPUI | always | CPU instruction port; peripherals are execute-never |
| 3 | DMA | HAS_DMA | DMA; the DMA engine itself only allows peripheral addresses in fixed-address, DREQ-paced mode |

## Interrupt sources (mcu_intc)

| Index | Source | Present | Notes |
|---|---|---|---|
| 0 | UART0 | always |  |
| 1 | SPI0 | always |  |
| 2 | GPIO | always |  |
| 3 | GPTIMER | always |  |
| 4 | WDT | always | early-warning interrupt |
| 5 | FAULT | always |  |
| 6 | DBG | always | SYSCTRL doorbell (JTAG/software) |
| 7 | MBIST | always |  |
| 8 | DMA | HAS_DMA |  |
| 9 | I2C0 | HAS_I2C |  |
| 10 | UART1 | HAS_UART1 |  |
| 11 | SPI1 | HAS_SPI1 |  |
| 12 | PWM | HAS_PWM |  |
| 13 | BUSERR | always | SYSCTRL first-decode-error capture valid |

Machine timer (MTI) and software interrupt (MSI) come from MTIMER directly.

## DMA request lines

| DREQ_SEL | Source | Present |
|---|---|---|
| 1 | UART0_RX | always |
| 2 | UART0_TX | always |
| 3 | SPI0_RX | always |
| 4 | SPI0_TX | always |
| 5 | UART1_RX | HAS_UART1 |
| 6 | UART1_TX | HAS_UART1 |
| 7 | SPI1_RX | HAS_SPI1 |
| 8 | SPI1_TX | HAS_SPI1 |

## Constants

| Name | Value |
|---|---|
| CHIP_ID | `0x4D434901` |
| MIMPID | `0x20000` |
| JTAG_PART | `0x4D49` |
| JTAG_MFR | `0x0` |
| SOFT_RESET_KEY | `0x5AFE0001` |
| DBG_LOCK_KEY | `0x10C4ED01` |
| WDT_KEY1 | `0xA5A5` |
| WDT_KEY2 | `0x5A5A` |
| JTAG_GO | `0xB007C0DE` |
| IMG_MAGIC | `0x4D434931` |
| DMA_ID_VALUE | `0x53464D44` |
