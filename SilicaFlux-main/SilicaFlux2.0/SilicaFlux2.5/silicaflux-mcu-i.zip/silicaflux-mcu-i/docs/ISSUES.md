# Known issues, blockers and resolved defects

Severity: **B** blocks tape-out, **H** high, **M** medium, **L** low.

## Open

| ID | Sev | Area | Issue | Required action |
|---|---|---|---|---|
| MCU-01 | B | physical design | No placement, CTS, routing, extraction, multi-corner STA, DRC/LVS/antenna, IR-drop/EM.  OpenROAD/OpenSTA could not be installed here (the environment's permission policy blocked downloading the conda-packaged binaries), so the ORFS-ready scripts were generated but not run. | Run `asic/scripts/run_synth.sh` with `STA=sta`, then the OpenROAD flow (docs/ASIC.md) in a licensed/open PDK; MCMM signoff. |
| MCU-02 | B | foundry IP | Needed and not available: production SRAM compiler macros for the chosen node (36-bit words with bit or 9-bit byte write masks for parity), I/O pad library with ESD and power pads, open-drain pads for I2C, POR/BOR, oscillator (or external), optional ROM macro and OTP. | Select foundry/node, obtain IP, write `asic/tech/<node>/` wrappers (the SRAM Wrapper Library adapter framework already exists). |
| MCU-03 | B | DFT | No scan insertion, ATPG, compression, OCC, boundary scan/BSDL (docs/DFT.md). | Commercial or open DFT flow on the final library; >= 98 % stuck-at target. |
| MCU-04 | B | timing | No static timing in a real library (no STA tool); the only timing evidence is FPGA post-route at 25 MHz: 31.5 MHz BASIC / 29.3 MHz INDUSTRIAL, one placement seed (docs/FPGA.md), which says nothing about ASIC timing. | STA at the target node; if needed register the CSR-write / register-file paths or add a pipeline stage. |
| MCU-05 | B | validation | FPGA bitstreams were generated but **not run on hardware**; ULX3S pins beyond gp0..gn3 were taken from the board reference and must be checked against the board revision. | Execute the FPGA bring-up checklist (docs/FPGA.md) on a ULX3S-85F. |
| MCU-06 | B | packaging | No pin multiplexer: INDUSTRIAL has 60 signal pins (+ supplies) which does not fit QFN-64; BASIC (31 signals) fits QFN-48. | Add an IOMUX (peripheral functions on GPIO pins) or reduce GPIO; decide the package from the real pad count (docs/ASIC.md). |
| MCU-07 | H | debug | No RISC-V External Debug Module (halt, step, breakpoints, register access); JTAG offers bus access, CPU hold, reset only. | Add a minimal DM (abstract commands, progbuf) + OpenOCD config. |
| MCU-08 | H | ISA verification | riscv-tests pass; the RISC-V International architectural tests (ACT) and riscv-formal were not run -> no compliance claim. | Run riscv-arch-test with a signature dump harness; consider riscv-formal (RVFI-like trace exists). |
| MCU-09 | H | CDC/RDC | No structural CDC/RDC tool run; generic 2-flop synchronisers without characterised cells/MTBF. | Run a CDC/RDC checker; map `sfv_sync` to library synchroniser cells (dont_touch). |
| MCU-10 | H | memory | The public sky130 OpenRAM macro has an 8-bit write mask: the INDUSTRIAL parity configuration (9-bit lanes) is correctly refused by the SRAM Wrapper Library for sky130 (IHP SG13G2 and GF180 bit-mask macros work). | Choose macros with bit/9-bit masks, or disable parity for such nodes. |
| MCU-11 | H | formal | Some properties hold only to the BMC depth if ABC PDR does not converge (see reports/formal/formal.md, rows marked "bounded only"); no liveness proofs (a slave that never answers hangs its master by design). | Abstractions/invariants for unbounded proofs; decide on a bus timeout. |
| MCU-12 | H | verification | No gate-level simulation of a synthesized netlist with SDF; SoC regression is firmware-level (no random system-level stress with JTAG + CPU + DMA concurrently). | GLS of the firmware regression on the final netlist; constrained-random SoC test. |
| MCU-13 | H | supervision | The watchdog uses the system clock: no clock-failure detection; no on-chip POR/BOR. | Independent low-frequency oscillator for the watchdog; analogue supervisor IP or external. |
| MCU-14 | M | memory | Parity detects but does not correct; MBIST does not compare parity bits. | SECDED with read-modify-write for sub-word stores if the reliability target requires correction; extend MBIST. |
| MCU-15 | M | security | No secure boot, OTP, TRNG, PMP; debug lock is a firmware policy (docs/SECURITY.md). | PMP first; then OTP + TRNG + reviewed signature verification. |
| MCU-16 | M | reset | Large asynchronous reset fan-out (same class as upstream ISS-006); recovery/removal must be closed after reset-tree synthesis. | Reset buffering, per-region synchronisers if required by STA. |
| MCU-17 | M | identity | JTAG JEDEC manufacturer field is a placeholder (0x000); no per-die ID. | Obtain a JEDEC ID; OTP-based die ID. |
| MCU-18 | M | power | No power analysis (no STA/power tool, no switching activity from the netlist); single always-on domain, no power gating. | VCD-based power at the target node; decide on power domains from measured leakage needs. |
| MCU-19 | M | DMA | Single channel; no 2-D/strided, no descriptor chaining; peripheral DMA only for UART and SPI data registers. | Add channels/features only for a measured workload. |
| MCU-20 | L | peripherals | Clock-gating a busy peripheral freezes it mid-operation (documented); DSP coefficients/delay line are not reset (undefined until written); SPI RX_AUTO performs one extra frame after the final DMA read; I2C is single-master, 7-bit only, no target mode. | Documented behaviour; revisit with product requirements. |
| MCU-21 | L | interrupts | Interrupt latency characterised only in simulation (machine timer); no bound proven. | Derive a worst-case bound from the CPU/bus model once the configuration is frozen. |
| MCU-22 | L | tools | Yosys 0.33 `synth_ecp5 -abc9` aborted inside yosys-abc (return code 134) on this design; the classic ABC mapper is used. | Re-test with a newer Yosys. |

## Resolved during this release (found by verification)

| ID | Found by | Defect | Fix |
|---|---|---|---|
| MCU-R1 | riscv-tests `rv32um/rem` | negative remainder used the upper half of a 64-bit negation (borrow from the quotient) | negate the 32-bit remainder only; 63/63 rv32ui/um/mi pass |
| MCU-R2 | SoC test `05_i2c` | I2C master released SCL while idle between byte commands -> spurious clock pulse, target desynchronised | hold SCL low (SDA unchanged) while the bus is owned |
| MCU-R3 | cocotb `test_spi` (independent slave model) | HAL `spi_init` wrote the SPI mode number into CTRL[1:0] although bit 0 is CPOL and bit 1 CPHA -> modes 1 and 2 swapped (invisible to loopback tests) | driver maps mode -> {CPHA, CPOL} |
| MCU-R4 | FPGA place & route | post-route Fmax 20.5 MHz < 25 MHz.  First suspect (M-unit operand negation) moved into a prepare cycle (MUL/DIV 34 -> 35 cycles) without gain (19.3 MHz); the real critical path was CPU address -> crossbar -> peripheral bridge -> read-data mux | `sfb_reg_slice` (request side) in front of the peripheral bridge (+1 cycle per peripheral access); 28.4 MHz post-route; re-verified with riscv-tests and both SoC regressions |
| MCU-R5 | Verilator lint | generated constant `DMA_ID` collided with register `DMA.ID` | constant renamed; generator now rejects duplicate SV symbols |
| MCU-R6 | Yosys elaboration / formal | Yosys 0.33 rejects `return` in functions and `string` parameters; hierarchical references in formal harnesses were silently undriven (vacuous properties) | function-name assignment, untyped parameter; state properties moved into embedded `ifdef FORMAL` checkers, verified non-vacuous with mutants |
| MCU-R7 | design review | fault log fed with the sticky RESET_CAUSE.WDT level (could never be cleared) | edge detection |
| MCU-R8 | SoC/unit tests | testbench defects: UART gated mid-byte by the fault test, GCC split a misaligned C access into halfword loads, 2-state `$isunknown` image sizing, JTAG flow reset the CPU after loading, I2C model changed SDA with SCL high after a stretch and advanced a bit early on a read address ACK, DMA fabric model sampled handshakes after the edge | each fixed in the test/model; no RTL change |
| MCU-R9 | formal `dma` property P5 (no DMA access to the peripheral window unless fixed + DREQ-paced) | the peripheral rule tested only the start address: an incrementing transfer starting below 0x4000_0000 could run into the peripheral registers (e.g. SRC = 0x3FFF_FFF0, LENGTH = 0x20 -- now a DMA unit-test case) | an incrementing side is checked over its whole range [addr, addr+len); P5 re-run, DMA unit test extended with range cases, INDUSTRIAL SoC regression 18/18 |
