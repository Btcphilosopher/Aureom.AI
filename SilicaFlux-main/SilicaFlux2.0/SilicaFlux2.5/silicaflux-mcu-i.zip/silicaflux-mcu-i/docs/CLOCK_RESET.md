# Clocks, resets and power management

## Clocks

| Clock | Source | Users |
|---|---|---|
| `clk` | one external reference (board oscillator / tester); no PLL | everything except the JTAG TAP |
| CPU clock | `sfv_clkgate` (ICG) on `clk`, enable = !(CLK_EN.CPU_SLEEP_CG && WFI-sleeping && bus idle) | `mcu_cpu` |
| peripheral clocks | 9 ICGs on `clk`, enable = SYSCTRL.CLK_EN bit (DMA: OR busy) | UART0/1, SPI0/1, GPTIMER, I2C0, PWM, DMA, DSP |
| `tck` | JTAG pin | TAP + TCK-side debug registers |

* Clock gating uses only integrated clock-gate cells: `sfv_clkgate` maps to `sg13g2_slgcp_1` (IHP),
  `sky130_fd_sc_hd__sdlclkp_1` (sky130), `gf180mcu_fd_sc_mcu7t5v0__icgtp_1` (GF180, new wrapper); its
  behavioural model is the only intentional latch in the RTL (lint and synthesis reports list exactly the ICG
  latches, nothing else).  `test_mode` forces every gate open (scan).  On FPGA `SFV_NO_CLOCK_GATE` turns the
  wrapper into a wire (gating is a power optimisation only; every gated block is correct with a free-running clock).
* Not gated: SYSCTRL, INTC, machine timer, GPIO (wake-up sources), watchdog, fault log, bus, memories.
* A gated peripheral answers register accesses with a bus error; a peripheral gated mid-operation freezes and
  resumes when re-enabled (time-stretched -- firmware must not gate a busy UART/SPI/I2C; the DMA cannot be gated
  while busy).
* CDC: only TCK <-> clk inside the JTAG debug module (toggle handshake + `sfv_sync`).  Asynchronous inputs (GPIO,
  UART RX, I2C, PWM fault, straps) pass 2-flop synchronisers.  A structural CDC tool has not been run (ISSUES.md).
* No frequency is claimed.  Constraints: `asic/constraints/mcu_soc.sdc` (targets 50 MHz at 130 nm, 40 MHz at
  180 nm), `fpga/ulx3s/mcu_ulx3s.lpf` (25 MHz).  Achieved values exist only where a tool ran (FPGA.md, ASIC.md).
* PLL: none.  A future PLL would feed `clk`; its lock signal would join `pwr_ok_i` in the POR combination.

## Resets

```
rst_ni & pwr_ok_i --sfv_rst_sync--> por_rst_n  (POR domain: RESET_CAUSE, WDT_COUNT, BOOT_STATUS, DBG_LOCK,
                                                fault log, JTAG system side, reset-pulse generator)
por & !(soft|WDT pulse) & !JTAG reset --sfv_rst_sync--> sys_rst_n (bus, memories' control, peripherals)
sys & !JTAG CPU hold --sfv_rst_sync--> cpu_rst_n (CPU)
```
* Asynchronous assertion, synchronous de-assertion (2 flops) at every level; ordering POR -> system -> CPU (each
  level releases at least 2 cycles after the previous one).  In `test_mode` every reset is the pin (DFT rule).
* CPU start: fetches from 0x0000_0000 two cycles after `cpu_rst_n` releases; boot straps are sampled 3 cycles after
  `sys_rst_n` releases (before the ROM reads them).
* SRAM: contents are never reset (undefined at power-up, preserved across soft/WDT/CPU resets); the ROM's MBIST
  initialises them (except boot mode 3).
* Peripheral reset values: [REGISTERS.md](REGISTERS.md) (all outputs inactive: UART TX idle high, SPI CS
  de-asserted, I2C released, PWM outputs 0, GPIO inputs).
* Watchdog reset and software reset (key `0x5AFE0001` to SYSCTRL.SOFT_RESET) generate an 8-cycle system-reset
  pulse from the POR domain; RESET_CAUSE records POR/SOFT/JTAG/WDT (sticky, W1C) and counts watchdog resets.
* `pwr_ok_i` is the provision for an external supervisor or an on-chip power-on-reset / brown-out comparator.
  **No POR or BOR circuit is part of this RTL** -- they are analogue blocks (licensed macro or external supervisor
  IC).
* Reset-domain verification: SoC tests cover POR, soft reset (upstream scenario + debug), watchdog reset
  (`07_watchdog`: POR-domain log survives, system state resets) and JTAG CPU hold (`boot_sram_jtag_preload`).  No
  formal RDC tool was run (ISSUES.md).

## Power management (always-on single power domain)

| Mode | Entry | Clocks | Wake-up |
|---|---|---|---|
| Run | - | all enabled peripherals | - |
| Idle | `wfi` with CLK_EN.CPU_SLEEP_CG = 0 | CPU clock running (stalled) | any interrupt (MEI/MTI/MSI pending) |
| Sleep | `wfi` with CLK_EN.CPU_SLEEP_CG = 1 | CPU clock gated once the bus is idle; DMA may keep running | any pending interrupt re-enables the CPU clock |
| Peripheral off | CLK_EN bit = 0 | that peripheral's clock gated | software |

Measured in simulation (`03_timer_irq`): across a gated WFI spanning a 2,000-cycle timer period, `mcycle`
advanced 250 cycles (set-up, wake-up and the interrupt handler), i.e. the CPU clock was stopped for the rest.  No power numbers are claimed (no power analysis was run).

**Clock gating is not power gating.**  MCU-I has no power switches, isolation cells, level shifters, retention
flops, UPF/CPF power intent or power-aware verification; all of these would be required for true power gating
and none is claimed.  First silicon should stay a single always-on domain unless measured leakage requirements
justify more (ISSUES.md).
