# DSP / MAC accelerator (`rtl/dsp/mcu_dsp.sv`, optional, INDUSTRIAL)

## Reuse evaluation (done first)

| Candidate | Finding | Decision |
|---|---|---|
| SilicaFlux-V `sfv_vec_engine` (4 x 32-bit SIMD) + `sfv_tensor_engine` | operands live in the 16 KiB tile scratchpad (TSPM) with its own bank arbitration; reducing it still needs the scratchpad and the tile register pages | not reused: too large for an MCU, wrong programming model for streaming FIR |
| repository `dsp_arithmetic` (`mac_unit`, `sat_arith`, `fir_filter`) | wildcard package imports (rejected by the Yosys 0.33 flow used for ASIC/FPGA), fixed Q-format pipelines, no register interface, testbench-only verification | not reused; same functions re-implemented in a register-mapped block |

## Function

16 x 16 signed multiplier (one, shared), 32-bit accumulator with optional saturation and sticky overflow, dual MAC
(DOT2, 2 cycles), Q15 multiply with rounding/saturation, saturating 16-bit add, Q-format read-out of the
accumulator (shift, round, saturate), 16-tap FIR (coefficients + delay line in the block, 1 tap per cycle).
Register map: [REGISTERS.md](REGISTERS.md) block `dsp`.  Commands written while BUSY return a bus error.
Results match the C reference model (`firmware/drivers/dsp.c`) and the independent Python model
(`tb/unit/test_dsp.py`, 400 random operations + FIR in 3 configurations) bit-exactly.

## Benchmark (`scripts/bench_dsp.sh`, RTL simulation, 16-tap FIR x 64 samples, identical data)

| Configuration | Saturating FIR in software (bit-exact model) | Plain C FIR (wrapping) | FIR on the accelerator |
|---|---|---|---|
| BASIC RV32I (libgcc `__mulsi3`) | 232,592 cycles | 205,714 cycles | n/a |
| RV32IM, iterative M unit (RV32M = 1) | 79,044 | 55,364 | **3,713** |
| RV32IM, single-cycle multiplier (RV32M = 2) | 44,228 | 20,548 | **3,713** |

Accelerator time is dominated by bus traffic (FIR_IN write, BUSY poll, FIR_OUT read through the peripheral bridge:
~58 cycles/sample for a 16-cycle computation); DMA-fed or streamed operation would reduce it further.

## Area (Yosys, IHP SG13G2 typical library, pre-layout, standard cells only)

| Block | Area | Increment |
|---|---|---|
| `mcu_cpu` RV32I (RV32M = 0) | 168,711 um^2 | - |
| `mcu_cpu` iterative M (RV32M = 1) | 193,199 um^2 | +24,489 um^2 (+14.5 %) |
| `mcu_cpu` single-cycle multiplier (RV32M = 2) | 260,486 um^2 | +91,775 um^2 (+54 %) |
| `mcu_dsp` | 91,553 um^2 | +91,553 um^2 |

## Cost / benefit

* RV32I -> RV32IM iterative: 3.7x faster plain-C FIR for +24.5k um^2 (~3.7 % of the INDUSTRIAL standard-cell logic) -- and it
  speeds up every multiply/divide in C code.  **Recommended for INDUSTRIAL (default).**
* The single-cycle multiplier and the accelerator cost almost the same area (~92k um^2).  For the FIR kernel the
  accelerator is 5.5x faster than the fast multiplier (3,713 vs 20,548 cycles) and 14.9x faster than the iterative
  M unit; the fast multiplier helps all code without driver changes.
* Against total INDUSTRIAL logic+SRAM area on IHP SG13G2 (~6.8 mm^2, SRAM-dominated) the accelerator adds ~1.3 %.
* Conclusion: keep the accelerator **optional** (`HAS_DSP`), enabled for products whose workloads are filter/MAC
  bound (sensor conditioning, motor-current filtering); BASIC does not include it.  Area figures are pre-layout
  estimates; no power numbers exist, so energy per sample is not claimed.
