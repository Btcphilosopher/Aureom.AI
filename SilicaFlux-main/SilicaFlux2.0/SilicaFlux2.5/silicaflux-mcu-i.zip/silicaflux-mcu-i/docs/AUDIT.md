# Repository audit and reuse matrix

Audit of `btcphilosopher/Aureom.AI` (branch `claude/friendly-rubin-6svjje`, base commit `fb7244d`) carried out
before any MCU-I design work.  Only files that exist in the repository are listed; nothing below is assumed.

## 1. Where SilicaFlux lives

All SilicaFlux material is under `SilicaFlux-main/`, almost entirely as archives (zip/tar.gz) plus loose
`.sf` files and PDF reports.  Archives were extracted to a scratch area and inspected; the ones relevant to a
microcontroller are:

| Archive (SHA-256 prefix) | Content | Relevance to MCU-I |
|---|---|---|
| `silicaflux-v-release1.zip` (`424816e9`) | **SilicaFlux-V release 1**: RV32I_Zicsr 2-stage CPU, SFB crossbar, peripheral bridge, UART, SPI, GPIO, CLINT timer, INTC, sysctrl, JTAG TAP + SBA, boot ROM, MBIST, vector/tensor accelerators, firmware, riscv-tests harness, cocotb, SymbiYosys, ULX3S FPGA flow, sky130/IHP ASIC scripts, reports | **primary base** (CPU, bus slaves, peripherals, debug, flows) |
| `silicaflux-datafabric.zip` (`9f1f3735`) | **DataFabric (Project 03)**: SFB2 crossbar (formally proven), register slice, v1 slave adapter, single-channel DMA, SRAM-library slaves, memory-map generator, formal runner | bus fabric, DMA base, formal method |
| `SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` (`13b1cee1`) | **SRAM Wrapper Library (Project 01)**: `sram_sp`/1R1W/TDP, generic/FPGA/ASIC backends, open-PDK macro adapters (sky130, GF180, IHP), MBIST | SRAM banks (required by the brief) |
| `soc_integration.tar.gz` (`c7a8d59c`) | earlier SoC (CPU BFM, UART/GPIO/timer/IRQ) | superseded by SilicaFlux-V (which already derived its UART map from it) |
| `cpu_core.zip`, `RISC-V CPU.zip`, `pipelined_cpu.zip` | three earlier RV32I-style cores without CSRs/traps/bus interface | superseded: SilicaFlux-V's `sfv_cpu` derives its decode tables from `cpu_core` and adds traps, CSRs, bus |
| `comm_protocols.zip` (`cc53768e`) | UART, SPI master/slave, I2C controller, AXI-Lite slave (standalone, no register bus) | evaluated for I2C; not reused (see 3) |
| `dsp_arithmetic.zip` (`677ff11b`) | MAC unit, saturating arithmetic, FIR, FFT butterfly | evaluated for the DSP block; not reused (see 3) |
| `digital_lib.zip`, `Finite State Machines Library.zip`, `memory_cache_repo.zip`, `UVM_Inspired_Architecture.zip`, `formal verification.zip` | teaching-style building blocks, caches, FIFOs, UVM-like FIFO TB, Jasper scripts | not needed (MCU-I has no cache; FIFOs come from `sfv_common`) |
| `silicaflux_rtl*.zip`, loose `*.sf` (`alu.sf`, `fetch_unit.sf`, `vector_engine.sf`, ...) | SilicaFlux 2.x dataflow cluster (custom 32-bit ISA, tiles, NoC); `.sf` files are SystemVerilog with a different extension (verified by inspection, as also recorded in the sramlib and DataFabric audits) | not an MCU ISA; no toolchain; not reused |
| `sfx_asm.py` (SilicaFlux 2.5) | assembler for the custom SilicaFlux ISA | not applicable (MCU-I is RISC-V) |
| PDFs (`Silica_Flux.pdf`, `SilicaFlux RTL-to-GDSII Implementation Report.pdf`, ...) | reports | context only |

No custom `.sf` compiler/translator exists: `.sf` files are plain SystemVerilog.  No LICENSE/COPYING/NOTICE file
exists anywhere in the repository; all SilicaFlux sources are internal Aureom.AI material (see 4).

## 2. Baseline re-verification (performed in this environment before reuse)

| Upstream claim | Re-run here | Result |
|---|---|---|
| SilicaFlux-V firmware builds | `make fw` (clang/lld 18) | PASS |
| SilicaFlux-V SoC firmware scenarios | `make soc-sim` (Verilator 5.020) | 6/6 PASS, cycle counts identical to the upstream report (e.g. 3 101 307) |
| `sfv_cpu` riscv-tests | `tb/cpu/run_riscv_tests.sh` (2 profiles, 1 seed) | 55/55 PASS |
| SRAM library files used by DataFabric | byte comparison of `sram_sp.sv`, `sram_defs.svh`, `sram_rsp_path.sv`, `sram_backend_1rw.sv` | identical between the Project-01 zip and DataFabric's vendored copy |

## 3. Reuse matrix

Legend: **V** = vendored unmodified (`third_party/`, hashes in `third_party/SHA256SUMS`), **D** = derived copy in
`rtl/` with the changes listed in the file header, **E** = evaluated and not reused, **N** = new.

| Block | Source (path inside archive) | Module | Interface | Parameters | Clock / reset | Synth. | Upstream verification | Use | Modifications | Integration risk |
|---|---|---|---|---|---|---|---|---|---|---|
| CPU | `silicaflux-v/rtl/cpu/sfv_cpu.sv` | `sfv_cpu` | 2 SFB v1 masters (I, D), irq_ext/timer/soft, RVFI-like trace | BOOT_ADDR, RV32E, HART_ID | 1 clk, async-assert rst_n | yes | riscv-tests 55/55, BMC depth 16 of bus props | **D** `rtl/cpu/mcu_cpu.sv` | RV32M option (iterative / 1-cycle mul), misa.M, MIMPID param, `bus_idle` output; **formally proven equivalent to `sfv_cpu` for RV32M=0** | I-port may change an ungranted address after redirect (upstream ISS-017) -- tolerated by SFB2 crossbar |
| Crossbar | `silicaflux-datafabric/rtl/interconnect/sfb_crossbar.sv` (+ decoder, arbiter, req mux, rsp router, error slave) | `sfb_crossbar` | SFB2 NM masters x NS slaves, decode-error capture | NM, NS, DW, ARB_MODE, CHECK_ALIGN, SLV_BASE/MASK, MST_SLV_EN | 1 clk, rst_n | yes | ABC PDR unbounded proofs (3x2), mutation campaign | **V** | none | 0-cycle combinational paths; one transaction per port (DataFabric DF-07) |
| v1 slave adapter | `.../sfb_v1_slave_adapter.sv` | `sfb_v1_slave_adapter` | SFB2 slave -> SFB v1 | - | clk, rst_n | yes | cocotb, SoC | **V** | none | adds a parking register |
| Peripheral bridge | `silicaflux-v/rtl/bus/sfv_periph_bridge.sv` | `sfv_periph_bridge` | SFB v1 slave -> 32 x 4 KiB register pages | NP, PAGE_EN | clk, rst_n | yes | cocotb, SoC | **V** | none | sub-word writes refused (documented rule) |
| Boot ROM slave | `silicaflux-v/rtl/mem/sfv_mem_slaves.sv` | `sfv_bootrom` | SFB v1 slave, generated image module | WORDS | clk, rst_n | yes (logic ROM) | SoC | **V** | none | ROM is logic; foundry ROM macro optional |
| ROM generator | `silicaflux-v/scripts/gen_rom.py`, `bin2hex.py` | - | bin -> case-statement module | --words | - | - | used upstream | **V** | none | - |
| SRAM | `silicaflux-sramlib/rtl/mem/sram_sp.sv` + backends | `sram_sp` | valid/ready req + rsp, MBIST port | DATA_WIDTH, DEPTH, MASK_WIDTH, READ_LATENCY, BACKEND, MACRO | clk, rst_n (array not reset) | yes; ASIC backend uses real macros | regression + bounded formal upstream | **V** | none | 36-bit (parity) words tile onto 16-bit IHP macros (12 wasted bits per bank row) |
| SRAM bank slave | `silicaflux-datafabric/rtl/mem/sfb_sram_slave.sv` | `sfb_sram_slave` | SFB2 slave on `sram_sp` | DW, DEPTH, READ_LATENCY, BACKEND, MACRO | clk, rst_n | yes | SoC upstream | **D** `rtl/mem/mcu_sram_bank.sv` | optional per-byte odd parity, parity event/address, injection | MBIST does not cover parity bits |
| MBIST | `silicaflux-v/rtl/mem/sfv_mbist.sv` | `sfv_mbist` | broadcast raw array port, 4 banks | AW, NBANKS | clk, rst_n | yes | SoC fault-injection scenarios upstream | **V** | none | requires READ_LATENCY = 1 (DataFabric DF-13) |
| Common cells | `silicaflux-v/rtl/common/sfv_common.sv`, `sfv_clkgate.sv` | `sfv_sync`, `sfv_rst_sync`, `sfv_fifo`, `sfv_clkgate` | - | STAGES, WIDTH, DEPTH | - | yes (ICG latch whitelisted) | upstream formal (FIFO) | **V** | none | generic synchronisers (no MTBF cells) |
| ICG tech wrappers | `silicaflux-v/asic/tech/{sky130,ihp_sg13g2}/sfv_clkgate.sv` | `sfv_clkgate` | - | - | - | yes | upstream ASIC runs | **V** (copied to `asic/tech/`) | GF180 wrapper **N** | - |
| Machine timer | `silicaflux-v/rtl/periph/sfv_periph_misc.sv` | `sfv_timer` | register page, MTI/MSI | - | clk, rst_n | yes | cocotb/SoC upstream | **V** | none | - |
| GPIO | same file | `sfv_gpio` | register page | N | clk, rst_n | yes | upstream | **D** `rtl/gpio/mcu_gpio.sv` | atomic set/clear/toggle, level irqs, width 32 | - |
| INTC | same file | `sfv_intc` | enable + claim | N | clk, rst_n | yes | upstream | **E** -> **N** `rtl/interrupts/mcu_intc.sv` | priorities, threshold, SW pending (new design) | - |
| UART | `silicaflux-v/rtl/periph/sfv_uart.sv` | `sfv_uart` | register page | FIFO_DEPTH, BAUD_RESET | clk, rst_n | yes | upstream | **D** `rtl/uart/mcu_uart.sv` | parity, 2 stop bits, parity error, counts, DREQ, error event | - |
| SPI | `silicaflux-v/rtl/periph/sfv_spi.sv` | `sfv_spi` | register page | - | clk, rst_n | yes | upstream | **D** `rtl/spi/mcu_spi.sv` | 8/16/32-bit frames, 4 CS, RX_VALID/RX_OVF, RX_AUTO, DREQ | - |
| Sysctrl | `silicaflux-v/rtl/periph/sfv_sysctrl.sv` | `sfv_sysctrl` | register page | - | sys + POR domain | yes | upstream | **D** `rtl/power/mcu_sysctrl.sv` | WDT reset generator, reset cause, boot status, features, clock enables, debug lock, parity control | - |
| JTAG | `silicaflux-v/rtl/debug/sfv_jtag.sv` | `sfv_jtag_tap`, `sfv_jtag_dbg` | TAP, SBA bus master, DBGCTRL | IRW | tck + clk domains | yes | upstream formal (TAP) | **D** `rtl/debug/mcu_jtag.sv` | renamed, MCU-I IDCODE only | no RISC-V Debug Module (upstream ISS-009) |
| DMA | `silicaflux-datafabric/rtl/dma/dma_transfer_engine.sv`, `dma_control_regs.sv`, `dma_validate.sv` | `dma_transfer_engine` ... | register page + SFB2 master | DW, MAX_LEN_LOG2 | clk, rst_n | yes | bounded formal, cocotb, SoC upstream | **D** `rtl/dma/mcu_dma.sv` | fixed-address sides, byte elements, DREQ pacing, peripheral rule, length rule | DataFabric DF-05 (bounded-only proofs) applies |
| I2C | `comm_protocols/rtl/i2c/i2c_controller.sv` | `i2c_controller` | standalone ports, no register bus | - | - | - | testbench only | **E** -> **N** `rtl/i2c/mcu_i2c.sv` | new: register bus, open-drain only, stretching, filter, timeout | - |
| DSP | `dsp_arithmetic/rtl/mac_unit.sv`, `sat_arith.sv`, `fir_filter.sv`; `silicaflux-v/rtl/accel/sfv_vec_engine.sv` | - | streaming / TSPM-bound | - | - | - | testbench only / upstream | **E** -> **N** `rtl/dsp/mcu_dsp.sv` | `dsp_arithmetic` uses wildcard package imports (Yosys 0.33 limit) and a fixed Q pipeline; `sfv_vec_engine` needs the tile scratchpad (16 KiB) | - |
| Vector/tensor tile | `silicaflux-v/rtl/accel/*` | `sfv_tile` | TSPM + 2 pages | LANES, MUL_W | clk | yes | upstream | **E** | not part of an MCU (area); pages 16/17 left unmapped | - |
| CPU testbench | `silicaflux-v/tb/cpu/tb_cpu.sv` | `tb_cpu` | random backpressure, IRQ injection | - | - | - | upstream | **D** `tb/cpu/tb_cpu.sv` | DUT = `mcu_cpu`, RV32M parameter | - |
| SoC testbench | `silicaflux-v/tb/soc/tb_soc.sv` | `tb_soc` | UART monitor, JTAG tasks | - | - | - | upstream | **D** `tb/soc/tb_mcu_soc.sv` | new board models (flash, I2C, loopbacks), more scenarios | - |
| Formal runner | `silicaflux-datafabric/formal/datafabric/run_formal.py`, `fv_sfb_xbar.sv`, `fv_sfb_arbiter.sv` | - | Yosys + smtbmc + ABC PDR | - | - | - | upstream | **D** `formal/run_formal.py`; harnesses **V** | MCU-I jobs, equivalence job | - |
| Memory-map generator | `silicaflux-datafabric/python/datafabric/memmap_gen.py` | - | YAML -> SV/C/Py/MD | - | - | - | upstream unit test | **E** -> **N** `scripts/mcu_gen.py` (same approach, MCU-I schema, configuration packages) | - | - |
| FPGA flow | `silicaflux-v/fpga/ulx3s/*` | `sfv_ulx3s_top` | ULX3S ECP5-85F | - | 25 MHz | yes | bitstream built upstream, not on hardware | **D** `fpga/ulx3s/*` | MCU-I top, more pins, internal demo loopbacks | LPF pins beyond gp0..gn3 must be checked against the board |
| ASIC flow | `silicaflux-v/asic/scripts/run_asic.sh`, `configs/*.cfg`, `constraints/sfv_soc.sdc` | - | Yosys + OpenSTA | - | - | - | upstream run | **D** `asic/scripts/run_synth.sh`, `asic/configs/*`, `asic/constraints/mcu_soc.sdc` | MCU-I sources, GF180 config, macro accounting | OpenSTA/OpenROAD not installable here (see docs/ASIC.md) |

## 4. Licensing obligations

* No license file exists in the repository; SilicaFlux-V, DataFabric, the SRAM Wrapper Library and all reused
  code are internal Aureom.AI sources.  MCU-I keeps the upstream headers and provenance notes; vendored files are
  byte-identical (`third_party/SHA256SUMS`, `third_party/PROVENANCE.md`).  **Before any external distribution the
  repository owner must choose and add a license.**
* Third-party material is **not** redistributed in the deliverable; it is fetched by `scripts/fetch_deps.sh`:
  riscv-tests (BSD-3-Clause), OpenROAD-flow-scripts platform data for sky130 (Apache-2.0), IHP SG13G2
  (Apache-2.0) and GF180MCU (Apache-2.0).  The GNU RISC-V toolchain (GPL, with the GCC runtime library exception
  for libgcc) is used, not shipped.
* No commercial IP is used.

## 5. Gaps found (and how MCU-I handles them)

| Gap | Handling |
|---|---|
| No M extension in the upstream CPU | added as an option (RV32M = 1/2), verified with riscv-tests rv32um |
| No DMA peripheral support upstream (DataFabric DF-06) | fixed-address + DREQ pacing + peripheral rule in `mcu_dma` |
| No I2C, PWM, GP timers, watchdog, fault log, priority INTC | new RTL |
| No SRAM parity/ECC (upstream ISS-014) | byte parity option (ECC would need read-modify-write for byte writes; see docs/MEMORY.md) |
| No RISC-V Debug Module (upstream ISS-009) | still open (JTAG SBA + CPU hold only) -- documented blocker |
| No boundary scan (upstream ISS-004) | still open |
| No OTP/eFuse, entropy source or secure element | secure boot marked unsupported; image CRC is integrity only |
| No pin multiplexer (IOMUX) | open: required before packaging the INDUSTRIAL variant in QFN-64 (docs/ASIC.md) |
