# Security and debug access

## Implemented

| Feature | What it does | Limits |
|---|---|---|
| Debug lock (`SYSCTRL.DBG_LOCK`, `mcu_dbg_gate`) | Writing the key `0x10C4ED01` sets a POR-domain lock: JTAG system-bus accesses are answered with a bus error locally (never reach the system), CPU hold, JTAG system reset and boot-mode override are forced inactive.  IDCODE/BYPASS stay readable for board test. | Firmware policy, not a root of trust: a device powers up unlocked until the boot ROM or application sets it; no OTP to make it permanent; physical attacks and `test_mode` (manufacturing scan) are out of scope. |
| Manufacturing test separated from application access | `test_mode` pin (scan/ICG control, reset bypass) is distinct from the JTAG debug functions; the application cannot enter test mode | test_mode must be bonded out or tied off according to the product's test strategy |
| Identity | CHIP_ID (hardware revision), JTAG IDCODE (part 0x4D49, JEDEC manufacturer field **placeholder 0x000**), mimpid, FEATURES | no unique per-device identity (needs OTP/eFuse) |
| Boot image integrity | CRC-32 over the payload, header bounds checks | **integrity, not authenticity** |
| Access restrictions | execute-never peripheral window; DMA peripheral rule; bus errors on every illegal access | no privilege levels, no PMP, no MPU |

## Not implemented (marked unsupported, FEATURES.SECURE_BOOT = 0, FEATURES.OTP = 0)

* **Secure boot**: requires immutable key storage (OTP/eFuse or ROM-embedded public key hash), an independently
  reviewed signature verification (e.g. a vetted Ed25519/ECDSA implementation, constant-time), anti-rollback
  counters and a key-provisioning process.  None of these exist; no fake verification was written.
* **Hardware root of trust / device identity**: no entropy source (TRNG), no PUF, no secure element.
* **Memory protection**: no PMP/MPU; machine mode only.
* **OTP/eFuse provisioning**: no macro available in the public PDKs used here.
* No production signing secrets exist anywhere in the RTL or firmware.

Recommended path (ISSUES.md): add RISC-V PMP (smallest step, protects the stack/vector table), then select a
foundry OTP macro, add a TRNG, and design secure boot around a reviewed library before any security claim.
