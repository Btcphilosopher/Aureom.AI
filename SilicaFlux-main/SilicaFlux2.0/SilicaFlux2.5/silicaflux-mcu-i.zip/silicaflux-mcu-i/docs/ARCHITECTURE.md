# MCU-I architecture

## 1. Block diagram

```
                 +------------------------- mcu_soc --------------------------------+
  clk ---------->| ICG(cpu) -> mcu_cpu RV32I[M]_Zicsr  I-port ----+                 |
  rst_ni, pwr_ok | reset ctl (sfv_rst_sync x3)          D-port --+ |                 |
  test_mode      |                                              | |                 |
  tck tms tdi -->| mcu_jtag_dbg (TAP, SBA) -> mcu_dbg_gate -----+ | |               |
  tdo <----------|                                            | | | |  mcu_dma ---+ |
                 |          sfb_crossbar (SFB2, round robin, decode errors, XN)     |
                 |    +--------+--------+--------+--------+--------------+          |
                 |   ROM     SRAM b0  SRAM b1  SRAM b2  SRAM b3   periph bridge     |
                 | sfv_bootrom (mcu_sram_bank: sram_sp + parity)   (32 x 4 KiB)    |
                 |                 sfv_mbist (March C-) on all banks   |            |
                 |   +---------------------------------------------------------+    |
                 |   SYSCTRL INTC MTIMER UART0 SPI0 GPIO FAULT WDT GPTIMER          |
                 |   [DMA PWM I2C0 UART1 SPI1 DSP]  (INDUSTRIAL)                    |
                 +------------------------------------------------------------------+
```

* One authoritative memory map: `configs/memmap.yaml` -> [MEMORY_MAP.md](MEMORY_MAP.md), [REGISTERS.md](REGISTERS.md).
* Two configurations from one RTL code base: `configs/basic.yaml`, `configs/industrial.yaml` ->
  `rtl/generated/mcu_cfg_<variant>_pkg.sv` (package `mcu_cfg_pkg`) consumed by `rtl/top/mcu_top.sv`.  The variant is
  chosen by which package file is compiled -- there are no feature `` `define``s in the RTL.  The only defines
  are the inherited technology switches `SYNTHESIS` (drops simulation-only checks) and `SFV_NO_CLOCK_GATE` (FPGA).

## 2. Configurations

| Feature | BASIC | INDUSTRIAL |
|---|---|---|
| CPU | RV32I_Zicsr (`-march=rv32i_zicsr_zifencei -mabi=ilp32`) | RV32IM_Zicsr (`rv32im_zicsr_zifencei`, `ilp32`), iterative M unit |
| SRAM | 64 KiB, 4 banks x 16 KiB | 128 KiB, 4 banks x 32 KiB, odd byte parity |
| Boot ROM | 8 KiB window, 2.1 KiB used | same image |
| UART / SPI | 1 / 1 (SPI0 = boot flash) | 2 / 2 |
| GPIO | 16 | 32 |
| Timers | CLINT machine timer + 1 GP timer channel | machine timer + 4 GP timer channels |
| PWM | - | 4 channels, fault input, safe state |
| I2C | - | 1 master |
| DMA | - | 1 channel, memory/peripheral, DREQ pacing |
| DSP/MAC | - | optional block (on in the default INDUSTRIAL config) |
| Watchdog, fault log, INTC, JTAG, MBIST, debug lock | yes | yes |

Further experiments are one YAML edit away (e.g. `BANK_WORDS: 16384` -> 256 KiB, `RV32M: 2` single-cycle
multiplier, `HAS_DSP: 0`).  `SRAM_BANKS` is fixed at 4 (MBIST controller), `N_TIMER` 1..4, `GPIO_N` 8..32.

## 3. CPU

See [CPU.md](CPU.md).  Two-stage in-order RV32 (fetch / execute), machine mode only, precise traps, no
speculation beyond sequential prefetch of two instructions, no caches.

## 4. Interconnect

SFB2 (SilicaFlux Bus rev. 2, `third_party/silicaflux-datafabric/docs/datafabric/PROTOCOL.md`): valid/ready
request channel (32-bit address, 32-bit data, byte strobes, write flag), valid/ready response channel (read data,
error), one transaction outstanding per port, in-order responses, error responses for unmapped/denied/misaligned
accesses.  It is an OBI-*style* protocol designed in SilicaFlux; MCU-I does not claim OBI, Wishbone or AMBA
compatibility (no bridge to those buses is provided -- see [BUS.md](BUS.md)).

| Masters (priority irrelevant: round robin) | Slaves |
|---|---|
| 0 DBG (JTAG SBA, through the debug lock) | 0 ROM (window = ROM size) |
| 1 CPU data | 1..4 SRAM banks (window = bank size, contiguous) |
| 2 CPU instruction (denied the peripheral window: execute-never) | 5 peripheral bridge (128 KiB, 32 pages) |
| 3 DMA (INDUSTRIAL) | |

The peripheral bridge converts to the SilicaFlux-V register bus (one-cycle strobe, combinational read data,
registered response, 2-cycle access).  Peripherals with gated clocks answer every access with a bus error.

## 5. Clocks, resets, power

See [CLOCK_RESET.md](CLOCK_RESET.md).  One functional clock domain plus the JTAG TCK domain; peripheral and CPU
clock gating with integrated clock-gate cells; three reset levels (POR, system, CPU) with asynchronous assertion
and synchronous release; POR-domain registers keep reset cause, boot status and the fault log across soft and
watchdog resets.

## 6. Pins (core boundary `mcu_top`)

| Group | BASIC | INDUSTRIAL | Notes |
|---|---|---|---|
| clk, rst_ni, pwr_ok_i, test_mode | 4 | 4 | |
| JTAG tck/tms/tdi/tdo (+tdo_oe) | 4 | 4 | tdo_oe drives the pad enable |
| UART0 / UART1 | 2 | 4 | |
| SPI0 (sck, mosi, miso, cs0, cs1) / SPI1 (sck, mosi, miso, cs0) | 5 | 9 | 4 CS per controller in RTL |
| I2C scl/sda (open-drain enables) | - | 2 | |
| GPIO | 16 | 32 | gpio[1:0] boot straps, gpio[4+c] timer capture c |
| PWM[3:0] + fault | - | 5 | |
| test_pass, test_fail | (2) | (2) | optional status pins |
| **signal pins** | **31 (+2)** | **60 (+2)** | |

Package implications (supply pins, no IOMUX) are analysed in [ASIC.md](ASIC.md).

## 7. Determinism

* Fixed instruction timing: ALU 1 cycle, load/store 2 + slave wait states, taken branch/jump 3, MUL/DIV 35
  (RV32M = 1, data-independent), MUL 1 (RV32M = 2); no caches, no branch prediction, no speculation.
* Fixed-latency slaves: SRAM 1 cycle, ROM 1 cycle, peripherals 1 cycle (+ adapter); crossbar adds 0 cycles.
* Round-robin arbitration with proven bounded waiting (each master waits at most NM-1 other transactions per
  slave); separate SRAM banks let the instruction and data ports proceed in parallel when they target different
  banks.
* Interrupt latency is not promised as a fixed number: it depends on the instruction in execution and on bus
  contention.  Measured values are in [VERIFICATION.md](VERIFICATION.md) (MTI, simulation).
