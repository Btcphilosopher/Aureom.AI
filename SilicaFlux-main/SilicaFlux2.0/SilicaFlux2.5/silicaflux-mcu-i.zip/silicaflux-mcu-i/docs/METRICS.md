# Engineering metrics

Only measured values (tool outputs in `reports/`).  "not measured" means no tool produced the number.

| Metric | BASIC | INDUSTRIAL | Source |
|---|---|---|---|
| Functional regression (SoC firmware scenarios) | 15/15 pass | 18/18 pass | reports/sim/soc_*.txt |
| CPU ISA tests (riscv-tests) | 55/55 (RV32I+Zicsr) | 63/63 (RV32IM+Zicsr, both M options) | reports/sim/riscv_tests_m*.txt |
| CPU instruction coverage by ISA tests | all 37 RV32I computational/control/memory instructions + FENCE.I + CSR/ECALL/EBREAK/MRET/WFI (rv32mi) | + all 8 RV32M instructions | riscv-tests suite list |
| Unit tests (cocotb) | 12 benches / 21 tests pass (shared) | | reports/sim/unit_summary.txt |
| Formal | see reports/formal/formal.md | | |
| RTL coverage, design files, firmware regression (Verilator line/branch/toggle) | line 82.3 % (368/447), branch 79.3 % (292/368), toggle 58.9 % (7212/12236) | line 89.1 % (563/632), branch 87.6 % (431/492), toggle 63.6 % (10120/15911) | reports/coverage/ |
| SRAM capacity | 64 KiB (4 x 16 KiB) | 128 KiB (4 x 32 KiB) + parity | configs/*.yaml |
| Boot ROM | 8 KiB window, 2,104 bytes used | same | reports/firmware/ |
| Flip-flops (IHP SG13G2 synthesis) | 3495 | 6182 | reports/asic/ |
| Standard-cell area IHP SG13G2 (pre-layout) | 0.366 mm^2 | 0.658 mm^2 | reports/asic/ |
| SRAM macro area IHP SG13G2 | 8 x RM_IHPSG13_1P_4096x16 = 2.061 mm^2 | 24 x = 6.183 mm^2 | reports/asic/ |
| Standard-cell area SKY130 HD / GF180MCU | 0.200 mm^2 / 0.610 mm^2 | 0.361 mm^2 (no parity) / 1.108 mm^2 | reports/asic/ |
| Critical path / Fmax (ASIC) | **not measured** (no STA) | **not measured** | ISSUES.md MCU-01/04 |
| Fmax FPGA ECP5-85F post-route (seed 1) | 31.50 MHz (PASS at 25 MHz) | 29.28 MHz (PASS at 25 MHz) | reports/fpga/ |
| FPGA resources | LUT4 10163, FF 2452, CCU2C 584, DP16KD 32, MULT18X18D 0 | LUT4 17975, FF 4810, CCU2C 1356, DP16KD 64, MULT18X18D 2 | reports/fpga/ |
| I/O count (core signals) | 31 (+2 status) | 60 (+2 status) | ARCHITECTURE.md |
| Estimated power | **not measured** | **not measured** | no power analysis tool run |
| DMA bandwidth | - | 4 cycles/word SRAM->SRAM (1 KiB in 1,104 cycles) | reports/sim/logs |
| Firmware size (text, hello / largest example) | 2,794 / 4,714 B (03_timer_irq) | 2,530 / 5,336 B (10_dsp_fir) | reports/firmware/ |
| SRAM utilisation (largest example image + bss + 2 KiB stack) | < 12 % of 64 KiB | < 8 % of 128 KiB | firmware sizes |
| Interrupt latency (MTI match -> C handler, simulation, max of 5) | 83 cycles | 83 cycles | reports/sim/logs |
| DSP: 16-tap FIR x 64 samples | 205,714 cycles (plain C) | 55,364 (C) / 3,713 (accelerator) | reports/bench |
| Die dimensions | **not physically implemented**; planning estimate ~5.9 mm^2 (IHP) | ~12.7 mm^2 (IHP) | ASIC.md (estimate formula) |
| Yield | **not estimated** | | |

## Before/after against the smallest configuration (BASIC = 1.0)

| Metric | BASIC | INDUSTRIAL | Ratio |
|---|---|---|---|
| std-cell area (IHP SG13G2) | 0.366 mm^2 | 0.658 mm^2 | 1.80x |
| SRAM macro area (IHP) | 2.061 mm^2 | 6.183 mm^2 | 3.0x (2x capacity, 36-bit words on 16-bit macros) |
| flip-flops | 3495 | 6182 | 1.77x |
| signal pins | 31 | 60 | 1.9x |
| FIR performance (plain C -> best available) | 205,714 cycles | 3,713 cycles | 55x faster |
