// Formal harness: mcu_wdt with a free register bus and debug halt;
// properties are embedded in the RTL (`ifdef FORMAL).
module fv_wdt (
  input logic clk, rb_sel, rb_we, dbg_halt,
  input logic [11:0] rb_addr,
  input logic [31:0] rb_wdata
);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  logic [31:0] rb_rdata;
  logic rb_err, irq_ewi, reset_req;
  mcu_wdt dut (.clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .dbg_halt, .irq_ewi, .reset_req);
endmodule
