// Formal harness: mcu_dbg_gate (port-level properties; the RTL also carries
// an embedded `ifdef FORMAL checker).  Assumptions: the debug master obeys
// SFB v1 (at most one outstanding transaction); the fabric answers only an
// outstanding forwarded request, >= 1 cycle later.
// P1 locked & nothing forwarded -> no system request
// P2 no unsolicited response to the debug master; one forwarded transaction
// P3 CPU hold, JTAG reset and boot override are inactive while locked
module fv_dbg_gate (
  input logic clk, locked, d_req, d_we, d_cpu_hold, d_sys_reset_req, d_boot_ovr,
  input logic m_gnt, m_rvalid_in, m_err,
  input logic [31:0] d_addr, d_wdata, m_rdata,
  input logic [3:0] d_be
);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  logic d_gnt, d_rvalid, d_err, m_req, m_we, cpu_hold, sys_reset_req, boot_ovr;
  logic [31:0] d_rdata, m_addr, m_wdata;
  logic [3:0] m_be;
  logic fwd_q, out_q;
  wire m_rvalid = m_rvalid_in && fwd_q;
  always_ff @(posedge clk) begin
    if (!rst_n) begin fwd_q <= 1'b0; out_q <= 1'b0; end
    else begin
      if (m_req && m_gnt) fwd_q <= 1'b1; else if (m_rvalid) fwd_q <= 1'b0;
      if (d_req && d_gnt) out_q <= 1'b1; else if (d_rvalid) out_q <= 1'b0;
    end
  end
  mcu_dbg_gate dut (.clk, .rst_n, .locked, .d_req, .d_gnt, .d_addr, .d_we, .d_be, .d_wdata,
    .d_rvalid, .d_rdata, .d_err, .d_cpu_hold, .d_sys_reset_req, .d_boot_ovr,
    .m_req, .m_gnt, .m_addr, .m_we, .m_be, .m_wdata, .m_rvalid, .m_rdata, .m_err,
    .cpu_hold, .sys_reset_req, .boot_ovr);
`ifdef FORMAL
  always_comb if (!rst_n || out_q) assume (!d_req);
  always_comb if (rst_n) begin
    if (locked && !fwd_q) assert (!m_req);                               // P1
    assert (!(d_rvalid && !out_q));                                      // P2
    if (m_req) assert (!fwd_q);
    if (locked) assert (!cpu_hold && !sys_reset_req && !boot_ovr);       // P3
  end
`endif
endmodule
