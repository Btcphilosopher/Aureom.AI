// Formal harness: mcu_intc (N = 16) with a free register bus and free source
// levels; properties are embedded in the RTL (`ifdef FORMAL).
module fv_intc (
  input logic clk, rb_sel, rb_we,
  input logic [11:0] rb_addr,
  input logic [31:0] rb_wdata,
  input logic [15:0] src
);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  logic [31:0] rb_rdata;
  logic rb_err, irq_ext;
  mcu_intc #(.N(16)) dut (.clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .src, .irq_ext);
endmodule
