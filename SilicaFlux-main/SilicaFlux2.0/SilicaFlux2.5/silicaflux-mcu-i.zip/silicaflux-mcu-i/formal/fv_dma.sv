// Formal harness: mcu_dma with a free register bus, free DREQ lines and a
// fabric that answers only an outstanding request (>= 1 cycle later).
// Port-level properties here, state properties embedded in the RTL:
// P1 at most one transaction in flight
// P2 request payload stable while valid && !ready (SFB2 R2)
// P4 a write is only issued after an error-free read response
module fv_dma (
  input logic clk, rb_sel, rb_we, req_ready, rsp_valid_in, rsp_error,
  input logic [11:0] rb_addr,
  input logic [31:0] rb_wdata, rsp_rdata,
  input logic [15:0] dreq
);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  logic [31:0] rb_rdata, req_addr, req_wdata;
  logic rb_err, irq, req_valid, req_write, rsp_ready, busy, err_evt;
  logic [3:0] req_wstrb;
  logic out_q, out_w_q, hold_q, rd_ok_q, w_q, past = 1'b0;
  logic [31:0] a_q;
  logic [3:0] s_q;
  wire rsp_valid = rsp_valid_in && out_q;
  mcu_dma #(.MAX_LEN_LOG2(16), .DREQ_MASK(16'h01FE)) dut (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq, .dreq,
    .req_valid, .req_ready, .req_write, .req_addr, .req_wdata, .req_wstrb,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_error, .busy, .err_evt);
  always_ff @(posedge clk) begin
    past <= rst_n;
    if (!rst_n) begin out_q <= 1'b0; rd_ok_q <= 1'b0; out_w_q <= 1'b0; end
    else begin
      if (req_valid && req_ready) begin out_q <= 1'b1; out_w_q <= req_write; if (req_write) rd_ok_q <= 1'b0; end
      else if (rsp_valid && rsp_ready) begin out_q <= 1'b0; if (!out_w_q) rd_ok_q <= !rsp_error; end
    end
    hold_q <= req_valid && !req_ready;
    a_q <= req_addr; w_q <= req_write; s_q <= req_wstrb;
  end
`ifdef FORMAL
  always_comb if (rst_n && past) begin
    if (req_valid) assert (!out_q);                                                         // P1
    if (hold_q) assert (req_valid && req_addr == a_q && req_write == w_q && req_wstrb == s_q); // P2
    if (req_valid && req_write) assert (rd_ok_q);                                           // P4
  end
`endif
endmodule
