#!/usr/bin/env python3
"""SilicaFlux MCU-I formal runner (no SymbiYosys required).

Derived from third_party/silicaflux-datafabric/formal/datafabric/run_formal.py
(same method): Yosys `read_verilog -formal`, prep, flatten,
async2sync, then
  * BMC  : ABC bmc3 on the AIGER model (default) or yosys-smtbmc + SMT solver
           (BMC_ENGINE=smt, SMT_SOLVER=z3), depth N
  * prove: AIGER + ABC PDR (unbounded), with a time budget
plus a Yosys equivalence job (formal/equiv_cpu.ys).  `expect FAIL` jobs are
non-vacuity checks: the harness on deliberately broken RTL must fail.
Writes reports/formal/formal.md and formal.json (a job subset updates only those rows); exit 1 if any job
is not OK.
usage: python3 formal/run_formal.py [job ...]
"""
import json
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "build", "formal")
SOLVER = os.environ.get("SMT_SOLVER", "z3")
PKG = os.path.join(ROOT, "rtl/generated/mcu_memmap_pkg.sv")
DF = os.path.join(ROOT, "third_party/silicaflux-datafabric")


def r(*p):
    return os.path.join(ROOT, *p)


XBAR = [os.path.join(DF, "rtl/interconnect", f) for f in
        ("sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv", "sfb_error_slave.sv",
         "sfb_crossbar.sv")]
JOBS = [
    # name, top, files, chparams, bmc depth, prove, options
    ("xbar_3x2_upstream", "fv_sfb_xbar", XBAR + [os.path.join(DF, "formal/datafabric/fv_sfb_xbar.sv")], {}, 10, True,
     {"note": "vendored DataFabric harness re-run on the vendored crossbar", "bmc_engine": "abc_bmc3"}),
    ("arbiter_rr_n4", "fv_sfb_arbiter", [os.path.join(DF, "rtl/interconnect/sfb_arbiter.sv"),
                                         os.path.join(DF, "formal/datafabric/fv_sfb_arbiter.sv")], {"N": 4, "MODE": 1}, 20, True,
     {"note": "MCU-I INDUSTRIAL uses 4 masters, round robin"}),
    ("dbg_gate", "fv_dbg_gate", [r("rtl/debug/mcu_dbg_gate.sv"), r("formal/fv_dbg_gate.sv")], {}, 20, True, {}),
    ("dbg_gate_mutant", "fv_dbg_gate", [r("rtl/debug/mcu_dbg_gate.sv"), r("formal/fv_dbg_gate.sv")], {}, 10, False,
     {"expect": "FAIL", "mutate": ("mcu_dbg_gate.sv", "assign cpu_hold      = d_cpu_hold && !locked;",
                                   "assign cpu_hold      = d_cpu_hold;"), "note": "lock does not block CPU hold"}),
    ("intc", "fv_intc", [PKG, r("rtl/interrupts/mcu_intc.sv"), r("formal/fv_intc.sv")], {}, 3, True, {}),
    ("intc_mutant", "fv_intc", [PKG, r("rtl/interrupts/mcu_intc.sv"), r("formal/fv_intc.sv")], {}, 3, False,
     {"expect": "FAIL", "mutate": ("mcu_intc.sv", "(prio_q[i*4 +: 3] >= best)", "(prio_q[i*4 +: 3] > best)"),
      "note": "ties resolved to the highest index"}),
    ("wdt", "fv_wdt", [PKG, r("rtl/watchdog/mcu_wdt.sv"), r("formal/fv_wdt.sv")], {}, 24, True,
     {"pdr_timeout": 600, "bmc_engine": "abc_bmc3"}),
    ("wdt_mutant", "fv_wdt", [PKG, r("rtl/watchdog/mcu_wdt.sv"), r("formal/fv_wdt.sv")], {}, 10, False,
     {"expect": "FAIL", "mutate": ("mcu_wdt.sv", "if (rb_wdata[0]) en_q   <= 1'b1;", "en_q <= rb_wdata[0];"),
      "note": "EN clearable by software", "bmc_engine": "abc_bmc3"}),
    ("dma", "fv_dma", [PKG, r("rtl/dma/mcu_dma.sv"), r("formal/fv_dma.sv")], {}, 18, True,
     {"pdr_timeout": 900, "bmc_timeout": 1800, "bmc_engine": "abc_bmc3"}),
    ("dma_mutant", "fv_dma", [PKG, r("rtl/dma/mcu_dma.sv"), r("formal/fv_dma.sv")], {}, 14, False,
     {"expect": "FAIL", "mutate": ("mcu_dma.sv", "(s_per && !(sfix_q && sel_q != 4'd0)) ||", "1'b0 ||"),
      "note": "peripheral rule removed for the source side", "bmc_engine": "abc_bmc3"}),
]


def apply_mutation(name, files, mut):
    if not mut:
        return files
    d = os.path.join(OUT, name, "mut")
    os.makedirs(d, exist_ok=True)
    out = []
    for f in files:
        if os.path.basename(f) == mut[0]:
            src = open(f).read()
            assert mut[1] in src, (name, mut[1])
            g = os.path.join(d, mut[0])
            open(g, "w").write(src.replace(mut[1], mut[2]))
            out.append(g)
        else:
            out.append(f)
    return out


def yosys_prep(name, top, files, params):
    d = os.path.join(OUT, name)
    os.makedirs(d, exist_ok=True)
    ch = "".join(f"chparam -set {k} {v} {top}; " for k, v in params.items())
    common = (f"read_verilog -sv -formal -DFORMAL -DSYNTHESIS {' '.join(files)}; {ch}prep -top {top}; "
              f"flatten; async2sync; dffunmap; setundef -undriven -zero; opt_clean; ")
    smt, aig = os.path.join(d, "model.smt2"), os.path.join(d, "model.aig")
    r1 = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys_smt.log"), "-p", common + f"write_smt2 -wires {smt}"],
                        capture_output=True, text=True)
    r2 = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys_aig.log"), "-p",
                         common + "memory_map; opt -full -nosdff -nodffe; techmap; opt -fast -nosdff -nodffe; dffunmap; "
                         f"abc -g AND -fast; opt_clean; write_aiger -I -B -zinit -no-startoffset -map {d}/model.aim {aig}"],
                        capture_output=True, text=True)
    return d, smt, aig, r1, r2


def run_job(job):
    name, top, files, params, depth, prove = job[:6]
    opt = job[6] if len(job) > 6 else {}
    t0 = time.time()
    files = apply_mutation(name, files, opt.get("mutate"))
    d, smt, aig, r1, r2 = yosys_prep(name, top, files, params)
    row = dict(job=name, top=top, params=params, expect=opt.get("expect", "PASS"), note=opt.get("note", ""))
    if r1.returncode or r2.returncode:
        row.update(bmc="ERROR", prove="ERROR", ok=False, secs=0, detail=(r1.stderr + r2.stderr)[-1500:])
        return row
    try:
        if opt.get("bmc_engine", os.environ.get("BMC_ENGINE", "abc_bmc3")) == "abc_bmc3":
            # bit-level BMC on the AIGER model (ABC bmc3, as used by DataFabric for its DMA proofs)
            tb = opt.get("bmc_timeout", 1800)
            b = subprocess.run(["yosys-abc", "-c", f"read_aiger {aig}; fold; strash; bmc3 -F {depth} -T {tb} -v"],
                               capture_output=True, text=True, cwd=d, timeout=tb + 300)
            open(os.path.join(d, "bmc.log"), "w").write(b.stdout + b.stderr)
            m = re.search(r"No output asserted in (\d+) frames", b.stdout)
            row["bmc"] = ("FAIL (counterexample)" if "was asserted" in b.stdout else
                          f"PASS depth {m.group(1)} (abc bmc3)" if m else "ERROR")
        else:
            b = subprocess.run(["yosys-smtbmc", "-s", SOLVER, "--presat", "-t", str(depth), smt],
                               capture_output=True, text=True, cwd=d, timeout=opt.get("bmc_timeout", 1800))
            open(os.path.join(d, "bmc.log"), "w").write(b.stdout + b.stderr)
            row["bmc"] = (f"PASS depth {depth}" if b.returncode == 0 and "Status: PASSED" in b.stdout else
                          "FAIL (counterexample)" if "Status: FAILED" in b.stdout else "ERROR")
    except subprocess.TimeoutExpired:
        row["bmc"] = f"TIMEOUT depth {depth}"
    row["prove"] = "-"
    if prove:
        tp = opt.get("pdr_timeout", 900)
        try:
            a = subprocess.run(["yosys-abc", "-c", f"read_aiger {aig}; fold; strash; pdr -T {tp}"],
                               capture_output=True, text=True, cwd=d, timeout=tp + 300)
            open(os.path.join(d, "pdr.log"), "w").write(a.stdout + a.stderr)
            row["prove"] = ("PROVED (unbounded, ABC PDR)" if "Property proved" in a.stdout else
                            "FAIL (counterexample)" if "was asserted" in a.stdout else f"UNKNOWN (PDR budget {tp} s)")
        except subprocess.TimeoutExpired:
            row["prove"] = f"UNKNOWN (PDR budget {tp} s)"
    if row["expect"] == "FAIL":
        row["ok"] = "FAIL" in row["bmc"] or "FAIL" in row["prove"]
    else:
        row["ok"] = row["bmc"].startswith("PASS") and not row["prove"].startswith("FAIL")
    row["secs"] = round(time.time() - t0, 1)
    return row


def run_equiv():
    t0 = time.time()
    d = os.path.join(OUT, "equiv_cpu")
    os.makedirs(d, exist_ok=True)
    p = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "equiv.log"), os.path.join(HERE, "equiv_cpu.ys")],
                       capture_output=True, text=True, cwd=ROOT)
    log = open(os.path.join(d, "equiv.log")).read()
    m = re.search(r"Found (\d+) \$equiv cells.*?Of those cells (\d+) are proven and (\d+) are unproven", log, re.S)
    res = f"PROVED ({m.group(2)}/{m.group(1)} equiv cells)" if p.returncode == 0 and m else "NOT PROVED"
    return dict(job="equiv_cpu_m0_vs_sfv_cpu", top="mcu_cpu vs sfv_cpu", params={"RV32M": 0}, expect="PASS",
                bmc="-", prove=res + ", Yosys equiv_simple/equiv_induct", ok=res.startswith("PROVED"),
                secs=round(time.time() - t0, 1), note="derived CPU (BASIC) == riscv-tests-verified upstream CPU")


def main():
    sel = sys.argv[1:]
    res = []
    for job in JOBS:
        if sel and job[0] not in sel:
            continue
        row = run_job(job)
        res.append(row)
        print(f"{row['job']:20s} bmc={row['bmc']:24s} prove={row['prove']:30s} expect={row['expect']:4s} "
              f"{'OK' if row['ok'] else 'NOT OK'} {row['secs']}s", flush=True)
    if not sel or "equiv_cpu" in sel:
        row = run_equiv()
        res.append(row)
        print(f"{row['job']:20s} {row['prove']} {'OK' if row['ok'] else 'NOT OK'} {row['secs']}s", flush=True)
    os.makedirs(r("reports", "formal"), exist_ok=True)
    jpath = r("reports", "formal", "formal.json")
    if sel and os.path.exists(jpath):
        # subset run: replace only the re-run rows, keep the others from the previous report
        new = {x["job"]: x for x in res}
        old = json.load(open(jpath)).get("jobs", [])
        res = [new.pop(x["job"], x) for x in old] + list(new.values())
    tools = {"yosys": subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip(),
             "solver": SOLVER, "solver_version": subprocess.run([SOLVER, "--version"], capture_output=True, text=True).stdout.strip()}
    json.dump(dict(tools=tools, jobs=res), open(jpath, "w"), indent=1)
    with open(r("reports", "formal", "formal.md"), "w") as f:
        f.write(f"# MCU-I formal results\n\n{tools['yosys']}; BMC: yosys-smtbmc + {tools['solver_version']} or ABC bmc3 (bit-level); "
                "unbounded: ABC PDR (yosys-abc).  `expect FAIL` rows are non-vacuity mutants.  A PDR result of "
                "UNKNOWN means the time budget was reached: the property then holds only to the BMC depth.\n"
                "Command: `python3 formal/run_formal.py`\n\n"
                "| job | top | BMC | unbounded / equivalence | expect | verdict | note |\n|---|---|---|---|---|---|---|\n")
        for x in res:
            v = "OK" if x["ok"] else "**NOT OK**"
            if x["ok"] and x["expect"] == "PASS" and x["prove"].startswith("UNKNOWN"):
                v = "OK, **bounded only**"
            f.write(f"| {x['job']} | {x['top']} | {x['bmc']} | {x['prove']} | {x['expect']} | {v} | {x.get('note', '')} |\n")
    sys.exit(0 if all(x["ok"] for x in res) else 1)


if __name__ == "__main__":
    main()
