# MCU-I formal results

Yosys 0.33 (git sha1 2584903a060); BMC: yosys-smtbmc + Z3 version 4.8.12 - 64 bit or ABC bmc3 (bit-level); unbounded: ABC PDR (yosys-abc).  `expect FAIL` rows are non-vacuity mutants.  A PDR result of UNKNOWN means the time budget was reached: the property then holds only to the BMC depth.
Command: `python3 formal/run_formal.py`

| job | top | BMC | unbounded / equivalence | expect | verdict | note |
|---|---|---|---|---|---|---|
| xbar_3x2_upstream | fv_sfb_xbar | PASS depth 10 (abc bmc3) | PROVED (unbounded, ABC PDR) | PASS | OK | vendored DataFabric harness re-run on the vendored crossbar |
| arbiter_rr_n4 | fv_sfb_arbiter | PASS depth 20 (abc bmc3) | PROVED (unbounded, ABC PDR) | PASS | OK | MCU-I INDUSTRIAL uses 4 masters, round robin |
| dbg_gate | fv_dbg_gate | PASS depth 20 (abc bmc3) | PROVED (unbounded, ABC PDR) | PASS | OK |  |
| dbg_gate_mutant | fv_dbg_gate | FAIL (counterexample) | - | FAIL | OK | lock does not block CPU hold |
| intc | fv_intc | PASS depth 3 (abc bmc3) | PROVED (unbounded, ABC PDR) | PASS | OK |  |
| intc_mutant | fv_intc | FAIL (counterexample) | - | FAIL | OK | ties resolved to the highest index |
| wdt | fv_wdt | PASS depth 24 (abc bmc3) | UNKNOWN (PDR budget 600 s) | PASS | OK, **bounded only** |  |
| wdt_mutant | fv_wdt | FAIL (counterexample) | - | FAIL | OK | EN clearable by software |
| dma | fv_dma | PASS depth 18 (abc bmc3) | UNKNOWN (PDR budget 900 s) | PASS | OK, **bounded only** |  |
| dma_mutant | fv_dma | FAIL (counterexample) | - | FAIL | OK | peripheral rule removed for the source side |
| equiv_cpu_m0_vs_sfv_cpu | mcu_cpu vs sfv_cpu | - | PROVED (2164/2164 equiv cells), Yosys equiv_simple/equiv_induct | PASS | OK | derived CPU (BASIC) == riscv-tests-verified upstream CPU |
