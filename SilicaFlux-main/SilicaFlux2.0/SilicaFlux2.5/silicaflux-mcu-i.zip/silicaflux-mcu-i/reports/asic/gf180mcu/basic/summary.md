## gf180mcu / basic  (180 nm (GF180MCU open PDK), Yosys logic synthesis, pre-layout)

- standard-cell area: 610452 um^2 (0.610 mm^2)
- SRAM macro area: not included (macro Liberty not available in this run)
- cells: 20778, flip-flops: 3498, ICG cells: 4
- SRAM macros (black boxes): {'gf180mcu_fd_ip_sram__sram512x8m8wm1': 128}
- longest topological path (generic cells, before mapping): 138
- latches outside clock gates: 0
- timing/power: NOT RUN (OpenSTA not installed in this environment)
