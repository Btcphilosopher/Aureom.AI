## gf180mcu / industrial  (180 nm (GF180MCU open PDK), Yosys logic synthesis, pre-layout)

- standard-cell area: 1107902 um^2 (1.108 mm^2)
- SRAM macro area: not included (macro Liberty not available in this run)
- cells: 39391, flip-flops: 6185, ICG cells: 10
- SRAM macros (black boxes): {'gf180mcu_fd_ip_sram__sram512x8m8wm1': 320}
- longest topological path (generic cells, before mapping): 139
- latches outside clock gates: 0
- timing/power: NOT RUN (OpenSTA not installed in this environment)
