read_liberty build/asic/gf180mcu/basic/gf180mcu_fd_sc_mcu7t5v0__tt_025C_3v30.lib
foreach l {} { read_liberty $l }
read_verilog build/asic/gf180mcu/basic/mcu_top.netlist.v
link_design mcu_top
read_sdc asic/constraints/mcu_soc.sdc
report_checks -path_delay max -group_count 5 -fields {fanout cap slew} -digits 3 > build/asic/gf180mcu/basic/timing_max.rpt
report_checks -path_delay min -digits 3 > build/asic/gf180mcu/basic/timing_min.rpt
report_wns > build/asic/gf180mcu/basic/wns.rpt
report_tns > build/asic/gf180mcu/basic/tns.rpt
set_power_activity -input -activity 0.1
report_power > build/asic/gf180mcu/basic/power.rpt
exit
