## sky130hd / basic  (130 nm (SkyWater SKY130 open PDK), Yosys logic synthesis, pre-layout)

- standard-cell area: 200236 um^2 (0.200 mm^2)
- SRAM macro area: not included (macro Liberty not available in this run)
- cells: 21230, flip-flops: 3498, ICG cells: 4
- SRAM macros (black boxes): {'sky130_sram_2kbyte_1rw1r_32x512_8': 32}
- longest topological path (generic cells, before mapping): 139
- latches outside clock gates: 0
- timing/power: NOT RUN (OpenSTA not installed in this environment)
