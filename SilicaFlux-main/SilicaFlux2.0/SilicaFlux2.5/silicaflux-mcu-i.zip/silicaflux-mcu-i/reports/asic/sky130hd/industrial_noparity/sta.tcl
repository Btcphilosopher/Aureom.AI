read_liberty /tmp/claude-0/-home-user-Aureom-AI/a0748d54-598c-54b9-8895-01e204c1bde1/scratchpad/deps/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
foreach l {} { read_liberty $l }
read_verilog build/asic/sky130hd/industrial_noparity/mcu_top.netlist.v
link_design mcu_top
read_sdc asic/constraints/mcu_soc.sdc
report_checks -path_delay max -group_count 5 -fields {fanout cap slew} -digits 3 > build/asic/sky130hd/industrial_noparity/timing_max.rpt
report_checks -path_delay min -digits 3 > build/asic/sky130hd/industrial_noparity/timing_min.rpt
report_wns > build/asic/sky130hd/industrial_noparity/wns.rpt
report_tns > build/asic/sky130hd/industrial_noparity/tns.rpt
set_power_activity -input -activity 0.1
report_power > build/asic/sky130hd/industrial_noparity/power.rpt
exit
