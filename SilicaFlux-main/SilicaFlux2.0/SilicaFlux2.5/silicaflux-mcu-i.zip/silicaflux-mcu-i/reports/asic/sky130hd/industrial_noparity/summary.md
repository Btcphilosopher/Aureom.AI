## sky130hd / industrial  (130 nm (SkyWater SKY130 open PDK), Yosys logic synthesis, pre-layout)

- standard-cell area: 360631 um^2 (0.361 mm^2)
- SRAM macro area: not included (macro Liberty not available in this run)
- cells: 39765, flip-flops: 6153, ICG cells: 10
- SRAM macros (black boxes): {'sky130_sram_2kbyte_1rw1r_32x512_8': 64}
- longest topological path (generic cells, before mapping): 138
- latches outside clock gates: 0
- timing/power: NOT RUN (OpenSTA not installed in this environment)
