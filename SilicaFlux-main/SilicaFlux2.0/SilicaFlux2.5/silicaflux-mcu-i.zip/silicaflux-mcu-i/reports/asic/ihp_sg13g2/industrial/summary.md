## ihp_sg13g2 / industrial  (130 nm (IHP SG13G2 open PDK), Yosys logic synthesis, pre-layout)

- standard-cell area: 657691 um^2 (0.658 mm^2)
- SRAM macro area: 6182604 um^2 (6.183 mm^2) -> logic + SRAM 6.840 mm^2 (no pads, no utilisation/whitespace)
- cells: 39248, flip-flops: 6182, ICG cells: 10
- SRAM macros (black boxes): {'RM_IHPSG13_1P_4096x16_c3_bm_bist': 24}
- longest topological path (generic cells, before mapping): 138
- latches outside clock gates: 0
- timing/power: NOT RUN (OpenSTA not installed in this environment)
