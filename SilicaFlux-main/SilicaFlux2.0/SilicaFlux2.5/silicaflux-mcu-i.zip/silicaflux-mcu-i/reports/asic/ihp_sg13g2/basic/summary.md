## ihp_sg13g2 / basic  (130 nm (IHP SG13G2 open PDK), Yosys logic synthesis, pre-layout)

- standard-cell area: 366220 um^2 (0.366 mm^2)
- SRAM macro area: 2060868 um^2 (2.061 mm^2) -> logic + SRAM 2.427 mm^2 (no pads, no utilisation/whitespace)
- cells: 20982, flip-flops: 3495, ICG cells: 4
- SRAM macros (black boxes): {'RM_IHPSG13_1P_4096x16_c3_bm_bist': 8}
- longest topological path (generic cells, before mapping): 138
- latches outside clock gates: 0
- timing/power: NOT RUN (OpenSTA not installed in this environment)
