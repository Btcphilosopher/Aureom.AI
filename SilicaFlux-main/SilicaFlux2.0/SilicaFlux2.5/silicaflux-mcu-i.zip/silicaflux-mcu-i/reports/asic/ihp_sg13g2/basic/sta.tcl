read_liberty /tmp/claude-0/-home-user-Aureom-AI/a0748d54-598c-54b9-8895-01e204c1bde1/scratchpad/deps/orfs/flow/platforms/ihp-sg13g2/lib/sg13g2_stdcell_typ_1p20V_25C.lib
foreach l {/tmp/claude-0/-home-user-Aureom-AI/a0748d54-598c-54b9-8895-01e204c1bde1/scratchpad/deps/orfs/flow/platforms/ihp-sg13g2/lib/RM_IHPSG13_1P_4096x16_c3_bm_bist_typ_1p20V_25C.lib} { read_liberty $l }
read_verilog build/asic/ihp_sg13g2/basic/mcu_top.netlist.v
link_design mcu_top
read_sdc asic/constraints/mcu_soc.sdc
report_checks -path_delay max -group_count 5 -fields {fanout cap slew} -digits 3 > build/asic/ihp_sg13g2/basic/timing_max.rpt
report_checks -path_delay min -digits 3 > build/asic/ihp_sg13g2/basic/timing_min.rpt
report_wns > build/asic/ihp_sg13g2/basic/wns.rpt
report_tns > build/asic/ihp_sg13g2/basic/tns.rpt
set_power_activity -input -activity 0.1
report_power > build/asic/ihp_sg13g2/basic/power.rpt
exit
