// =============================================================================
// SilicaFlux MCU-I :: spi_flash_model -- behavioural SPI NOR flash (testbench)
//
// Generic NOR command subset, SPI mode 0/3 (MOSI sampled on SCK rise, MISO
// driven on SCK fall), MSB first, 24-bit addresses, SIZE bytes:
//   0x03 READ (stream)   0x9F RDID (3 bytes: ID)   0x05 RDSR (WIP, WEL)
//   0x06 WREN            0x02 PAGE PROGRAM (AND into the array, page wrap)
//   0x20 SECTOR ERASE (4 KiB -> 0xFF)
// Program/erase need WEL, execute at CS rising edge and report WIP for
// BUSY_READS status polls.  ID is a testbench value, not a real vendor ID.
// Preload with $readmemh (byte per line) via the `mem` array.
// =============================================================================
`timescale 1ns/1ps
module spi_flash_model #(
  parameter int          SIZE       = 2 * 1024 * 1024,
  parameter logic [23:0] ID         = 24'h5A4D12,
  parameter int          BUSY_READS = 2
) (
  input  logic sck,
  input  logic cs_n,
  input  logic mosi,
  output logic miso
);
  logic [7:0] mem [0:SIZE-1];
  logic [7:0] cmd, sh_in, sh_out;
  logic [23:0] addr;
  int bits, state;            // 0 cmd, 1 addr, 2 data-out, 3 data-in, 4 ignore
  logic wel = 0;
  int busy = 0;
  logic [7:0] pp_buf [0:255];
  int pp_n;
  logic [23:0] op_addr;

  initial begin
    miso = 1'b0;
    for (int i = 0; i < SIZE; i++) mem[i] = 8'hFF;
  end

  task automatic load_out(input logic [7:0] b); sh_out = b; endtask

  always @(negedge cs_n) begin
    bits = 0; state = 0; addr = 0; pp_n = 0; sh_out = 8'h00;
  end

  always @(posedge cs_n) begin
    if (state >= 1 && cmd == 8'h02 && wel && pp_n > 0) begin
      for (int i = 0; i < pp_n; i++)
        mem[{op_addr[23:8], 8'(op_addr[7:0] + i)} % SIZE] &= pp_buf[i];
      wel = 0; busy = BUSY_READS;
    end else if (cmd == 8'h20 && bits >= 32 && wel) begin
      for (int i = 0; i < 4096; i++) mem[(({op_addr[23:12], 12'h000}) + i) % SIZE] = 8'hFF;
      wel = 0; busy = BUSY_READS;
    end else if (cmd == 8'h06 && bits == 8) begin
      wel = 1;
    end
    miso = 1'b0;
  end

  always @(posedge sck) if (!cs_n) begin
    sh_in = {sh_in[6:0], mosi};
    bits++;
    if (bits % 8 == 0) begin
      case (state)
        0: begin
          cmd = sh_in;
          case (cmd)
            8'h03, 8'h02, 8'h20: state = 1;
            8'h9F: begin state = 2; load_out(ID[23:16]); end
            8'h05: begin state = 2; load_out({6'd0, wel, busy > 0}); if (busy > 0) busy--; end
            default: state = 4;
          endcase
        end
        1: begin
          addr = {addr[15:0], sh_in};
          if (bits == 32) begin
            op_addr = addr;
            if (cmd == 8'h03) begin state = 2; load_out(mem[addr % SIZE]); end
            else if (cmd == 8'h02) state = 3;
            else state = 4;
          end
        end
        2: begin
          if (cmd == 8'h03) begin addr = addr + 1; load_out(mem[addr % SIZE]); end
          else if (cmd == 8'h9F) load_out((bits == 16) ? ID[15:8] : (bits == 24) ? ID[7:0] : 8'h00);
          else load_out({6'd0, wel, busy > 0});
        end
        3: begin if (pp_n < 256) begin pp_buf[pp_n] = sh_in; pp_n++; end end
        default: ;
      endcase
    end
  end

  always @(negedge sck) if (!cs_n && state == 2) begin
    miso   = sh_out[7];
    sh_out = {sh_out[6:0], 1'b0};
  end
endmodule
