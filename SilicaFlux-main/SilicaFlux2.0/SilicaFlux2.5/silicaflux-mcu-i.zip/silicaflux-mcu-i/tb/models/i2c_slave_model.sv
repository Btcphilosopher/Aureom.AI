// =============================================================================
// SilicaFlux MCU-I :: i2c_slave_model -- behavioural I2C target (testbench)
//
// Open-drain: drives only scl_oe/sda_oe (1 = pull low); the bus levels are
// wired-AND with a pull-up in the testbench.  7-bit address ADDR.
//   KIND 0 (EEPROM): 256 bytes; write {ptr, data...}; read streams from ptr.
//   KIND 1 (SENSOR): registers 0x00 = {0x1A, 0x2B}; holds SCL low for
//     STRETCH_NS after each acknowledge (clock stretching); register 0x7F
//     holds SCL low for HANG_NS (bus-timeout test).
// START/STOP detection on SDA edges while SCL is high; data sampled on SCL
// rise; the target changes SDA HOLD_NS after SCL falls.
// =============================================================================
`timescale 1ns/1ps
module i2c_slave_model #(
  parameter logic [6:0] ADDR       = 7'h50,
  parameter int         KIND       = 0,
  parameter int         STRETCH_NS = 2000,
  parameter int         HANG_NS    = 150000,
  parameter int         HOLD_NS    = 30
) (
  input  logic scl,
  input  logic sda,
  output logic scl_oe,
  output logic sda_oe
);
  logic [7:0] mem [0:255];
  logic [7:0] ptr, sh;
  int  bitn;
  int  st;            // 0 idle, 1 addr, 2 write data, 3 read data, 4 ignore
  logic first_w, rd_ack_phase, wr_ack_phase, nacked;
  logic hang_req;

  initial begin
    scl_oe = 0; sda_oe = 0; st = 0; ptr = 0;
    for (int i = 0; i < 256; i++) mem[i] = 8'(i);
    if (KIND == 1) begin mem[0] = 8'h1A; mem[1] = 8'h2B; end
  end

  // START / repeated START
  always @(negedge sda) if (scl) begin
    st = 1; bitn = 0; sh = 0; wr_ack_phase = 0; rd_ack_phase = 0; sda_oe = 0;
  end
  // STOP
  always @(posedge sda) if (scl) begin
    st = 0; sda_oe = 0;
  end

  always @(posedge scl) begin
    if (st == 1 || st == 2) begin
      if (wr_ack_phase) ;                         // our ACK bit being clocked
      else begin sh = {sh[6:0], sda}; bitn++; end
    end else if (st == 3) begin
      if (rd_ack_phase) nacked = sda;             // master's ACK/NACK
    end
  end

  always @(negedge scl) begin
    #(HOLD_NS);
    if (wr_ack_phase) begin                       // end of our ACK bit (address or data)
      wr_ack_phase = 0;
      sda_oe = 0;
      if (KIND == 1) begin                        // clock stretching after ACK
        scl_oe = 1;
        if (hang_req) begin #(HANG_NS); hang_req = 0; end
        else #(STRETCH_NS);
      end
      // read: drive the first data bit while SCL is still low (a change of
      // SDA while SCL is high would be a START/STOP condition) ...
      if (st == 3) sda_oe = !sh[7];
      // ... then end the stretch
      if (KIND == 1) begin #(HOLD_NS); scl_oe = 0; end
    end else if (st == 1 || st == 2) begin
      if (bitn == 8) begin
        bitn = 0;
        if (st == 1) begin
          if (sh[7:1] == ADDR) begin
            wr_ack_phase = 1; sda_oe = 1;         // ACK the address
            if (sh[0]) begin st = 3; sh = mem[ptr]; end
            else begin st = 2; first_w = 1; end
          end else st = 4;
        end else begin                            // data byte written
          if (first_w) begin
            ptr = sh; first_w = 0;
            if (KIND == 1 && sh == 8'h7F) hang_req = 1;
          end else begin
            mem[ptr] = sh; ptr++;
          end
          wr_ack_phase = 1; sda_oe = 1;
        end
      end
    end else if (st == 3) begin
      if (rd_ack_phase) begin                     // after the master's ACK/NACK bit
        rd_ack_phase = 0;
        if (nacked) begin st = 4; sda_oe = 0; end
        else begin ptr++; sh = mem[ptr]; bitn = 0; sda_oe = !sh[7]; end
      end else begin
        bitn++;
        if (bitn == 8) begin sda_oe = 0; rd_ack_phase = 1; end   // release for the master's ACK
        else begin sh = {sh[6:0], 1'b0}; sda_oe = !sh[7]; end
      end
    end
  end
endmodule
