"""mcu_sram_bank (PARITY=1): byte-strobe writes and reads against a Python
memory, parity injection -> rsp_error + par_evt with the address, check
disabled -> no error, rewrite heals, MBIST raw port access."""
import random

import cocotb
from cocotb.triggers import RisingEdge, ReadOnly, Timer

from common import start


async def access(dut, addr, write=0, data=0, strb=0xF):
    d = dut
    d.req_valid.value = 1
    d.req_write.value = write
    d.req_addr.value = addr
    d.req_wdata.value = data
    d.req_wstrb.value = strb
    while True:
        await RisingEdge(d.clk)
        await ReadOnly()
        if int(d.req_ready.value):
            break
    await Timer(1, unit="ns")
    d.req_valid.value = 0
    ev = 0
    while True:
        await ReadOnly()
        if int(d.rsp_valid.value):
            r, e = int(d.rsp_rdata.value), int(d.rsp_error.value)
            ev = int(d.par_evt.value)
            pa = int(d.par_addr.value)
            await RisingEdge(d.clk)
            return r, e, ev, pa
        await RisingEdge(d.clk)


@cocotb.test()
async def test_parity(dut):
    for s, v in (("req_valid", 0), ("rsp_ready", 1), ("chk_en", 0), ("inject", 0), ("tst_active", 0),
                 ("tst_ce", 0), ("tst_we", 0), ("tst_addr", 0), ("tst_wdata", 0)):
        getattr(dut, s).value = v
    await start(dut)
    rng = random.Random(2)
    mem = {}
    for a in range(0, 64 * 4, 4):
        mem[a] = rng.getrandbits(32)
        await access(dut, a, 1, mem[a])
    dut.chk_en.value = 1
    for _ in range(100):
        a = 4 * rng.randrange(64)
        if rng.random() < 0.5:
            d, st = rng.getrandbits(32), rng.randrange(1, 16)
            await access(dut, a, 1, d, st)
            m = mem[a]
            for b in range(4):
                if st >> b & 1:
                    m = (m & ~(0xFF << 8 * b)) | (d & (0xFF << 8 * b))
            mem[a] = m
        else:
            r, e, _, _ = await access(dut, a)
            assert e == 0 and r == mem[a]
    # inject: inverted parity on the written lanes -> read error
    dut.inject.value = 1
    await access(dut, 0x40, 1, 0xDEADBEEF, 0x2)
    dut.inject.value = 0
    r, e, ev, pa = await access(dut, 0x40)
    assert e == 1 and r == 0 and ev == 1 and pa == 0x40
    dut.chk_en.value = 0
    r, e, _, _ = await access(dut, 0x40)
    assert e == 0, "check disabled"
    dut.chk_en.value = 1
    await access(dut, 0x40, 1, 0x12345678)
    r, e, _, _ = await access(dut, 0x40)
    assert e == 0 and r == 0x12345678, "rewrite heals"
    # MBIST raw port
    dut.tst_active.value = 1
    dut.tst_ce.value = 1; dut.tst_we.value = 1; dut.tst_addr.value = 5; dut.tst_wdata.value = 0xA5A5A5A5
    await RisingEdge(dut.clk)
    dut.tst_we.value = 0
    await RisingEdge(dut.clk)
    await ReadOnly()
    assert int(dut.tst_rdata.value) == 0xA5A5A5A5
    await RisingEdge(dut.clk)
    dut.tst_active.value = 0; dut.tst_ce.value = 0
    r, e, _, _ = await access(dut, 5 * 4)
    assert e == 0 and r == 0xA5A5A5A5, "MBIST writes valid parity"
