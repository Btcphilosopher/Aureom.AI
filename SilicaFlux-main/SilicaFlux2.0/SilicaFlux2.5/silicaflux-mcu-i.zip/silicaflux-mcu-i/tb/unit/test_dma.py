"""mcu_dma against a Python SFB2 memory/peripheral model with random request
backpressure and response latency: word and byte copies with random
lengths/alignments (reference: Python memory copy), fixed-address peripheral
transfers paced by DREQ, every validation error, bus errors, abort, one
transaction in flight, payload stability (SFB2 rule R2)."""
import random

import cocotb
from cocotb.triggers import RisingEdge, Timer

from common import RegBus, start, REGS

PER = 0x4000_0000
FIFO_ADDR = PER + 0x3000            # "peripheral data register" (UART-like FIFO)
MODE_SF, MODE_DF, MODE_BYTE = 1, 2, 4


def iv(sig):
    """int value; unresolved bits (e.g. the non-reset write-data register) -> 0"""
    v = sig.value
    return int(v) if v.is_resolvable else 0


class Fabric:
    def __init__(self, dut, rng):
        self.dut, self.rng = dut, rng
        self.mem = {}
        self.fifo_in, self.fifo_out = [], []
        self.err_ranges = [(0x3000_0000, 0x3001_0000)]
        self.max_out = 0
        self.dreq_rx = 0

    def rd(self, a):
        if a == FIFO_ADDR:
            return self.fifo_in.pop(0) if self.fifo_in else 0
        return self.mem.get(a, 0)

    async def run(self):
        """Handshakes are evaluated with the values of the cycle that just
        ended (sampled at the clock edge, before the edge's register updates);
        new outputs are driven 1 ns after the edge."""
        d = self.dut
        d.req_ready.value = 0
        d.rsp_valid.value = 0
        d.rsp_error.value = 0
        d.rsp_rdata.value = 0
        pending = None          # [cycles until rsp_valid, rdata, err]
        hold = None
        rv = 0                  # our rsp_valid during the cycle that just ended
        while True:
            await RisingEdge(d.clk)
            v, rdy = iv(d.req_valid), iv(d.req_ready)
            a, w = iv(d.req_addr), iv(d.req_write)
            wd, ws = iv(d.req_wdata), iv(d.req_wstrb)
            rsp_hs = rv and iv(d.rsp_ready)
            if v and not rdy:
                if hold is not None:
                    assert hold == (a, w, ws), "R2: payload changed while not accepted"
                hold = (a, w, ws)
            else:
                hold = None
            if rsp_hs:
                pending = None
            if v and rdy:
                assert pending is None, "two transactions in flight"
                err = any(lo <= a < hi for lo, hi in self.err_ranges)
                rdata = 0
                if not err:
                    if w:
                        if a == FIFO_ADDR:
                            self.fifo_out.append(wd & 0xFF)
                        else:
                            old = self.mem.get(a, 0)
                            for b in range(4):
                                if ws >> b & 1:
                                    old = (old & ~(0xFF << 8 * b)) | (wd & (0xFF << 8 * b))
                            self.mem[a] = old
                    else:
                        rdata = self.rd(a)
                pending = [self.rng.randrange(0, 4), rdata, err]
            await Timer(1, unit="ns")
            d.req_ready.value = int(self.rng.random() < 0.6)
            d.dreq.value = (int(len(self.fifo_in) > 0) << 1) | (1 << 2)
            rv = 0
            if pending is not None:
                if pending[0] == 0:
                    rv = 1
                    d.rsp_rdata.value = 0 if pending[2] else pending[1]
                    d.rsp_error.value = int(pending[2])
                else:
                    pending[0] -= 1
            d.rsp_valid.value = rv


async def xfer(rb, src, dst, ln, mode=0, dreq=0):
    await rb.write("SRC_ADDR", src)
    await rb.write("DST_ADDR", dst)
    await rb.write("LENGTH", ln)
    await rb.write("MODE", mode | (dreq << 8))
    await rb.write("CONTROL", 1)
    while (await rb.read("STATUS")) & 1:
        pass
    return await rb.read("ERROR_CODE")


def bytes_of(mem, a, n):
    return bytes((mem.get((a + i) & ~3, 0) >> (8 * ((a + i) & 3))) & 0xFF for i in range(n))


@cocotb.test()
async def test_copies_random(dut):
    rng = random.Random(11)
    dut.dreq.value = 0
    await start(dut)
    fab = Fabric(dut, rng)
    cocotb.start_soon(fab.run())
    rb = RegBus(dut, "dma")
    assert await rb.read("ID") == 0x53464D44
    for it in range(30):
        byte = rng.random() < 0.5
        n = rng.randrange(1, 64) if byte else 4 * rng.randrange(1, 32)
        src = 0x1000_0000 + (rng.randrange(0, 256) if byte else 4 * rng.randrange(0, 64))
        dst = 0x1000_2000 + (rng.randrange(0, 256) if byte else 4 * rng.randrange(0, 64))
        for a in range(src & ~3, src + n + 4, 4):
            fab.mem[a] = rng.getrandbits(32)
        guard_lo, guard_hi = bytes_of(fab.mem, dst - 4, 4), bytes_of(fab.mem, dst + n, 4)
        exp = bytes_of(fab.mem, src, n)
        code = await xfer(rb, src, dst, n, MODE_BYTE if byte else 0)
        assert code == 0, f"iter {it}: error {code}"
        assert bytes_of(fab.mem, dst, n) == exp, f"iter {it}: data"
        assert bytes_of(fab.mem, dst - 4, 4) == guard_lo and bytes_of(fab.mem, dst + n, 4) == guard_hi, "write outside range"
        assert await rb.read("BYTES_DONE") == n


@cocotb.test()
async def test_errors_periph_abort(dut):
    rng = random.Random(5)
    dut.dreq.value = 0
    await start(dut)
    fab = Fabric(dut, rng)
    cocotb.start_soon(fab.run())
    rb = RegBus(dut, "dma")
    await rb.write("INT_ENABLE", 3)
    S = 0x1000_0000
    assert await xfer(rb, S, S + 0x100, 0) == 1, "zero length"
    assert await xfer(rb, S, S + 0x100, (1 << 16) + 4) == 2, "too long"
    assert await xfer(rb, S + 1, S + 0x100, 8) == 3, "src align (word)"
    assert await xfer(rb, S, S + 0x102, 8) == 4, "dst align (word)"
    assert await xfer(rb, 0xFFFF_FFF0, S, 0x20) == 5, "src overflow"
    assert await xfer(rb, S, 0xFFFF_FFF0, 0x20) == 6, "dst overflow"
    assert await xfer(rb, S, S + 4, 16) == 7, "overlap"
    assert await xfer(rb, 0x3000_0000, S, 8) == 8, "read bus error"
    assert await rb.read("ERROR_ADDR") == 0x3000_0000
    assert await xfer(rb, S, 0x3000_0000, 8) == 9, "write bus error"
    assert await xfer(rb, FIFO_ADDR, S, 4) == 11, "peripheral without fixed/DREQ"
    assert await xfer(rb, FIFO_ADDR, S, 4, MODE_SF) == 11, "peripheral fixed but no DREQ"
    # incrementing ranges are checked over their whole extent (MCU-R9, found by formal P5)
    assert await xfer(rb, PER - 0x10, S, 0x20) == 11, "src range runs into peripheral window"
    assert await xfer(rb, S, PER - 0x10, 0x20) == 11, "dst range runs into peripheral window"
    assert await xfer(rb, PER + 0x2_0000 - 4, S, 8) == 11, "src range starts in window top"
    assert await xfer(rb, S, PER - 0x20, 0x20) == 0, "dst range ending at window base is legal"
    assert await xfer(rb, PER + 0x2_0000, S, 0x20) == 0, "src range above window is legal"
    assert await xfer(rb, S, S + 0x100, 6) == 12, "length alignment"
    assert await xfer(rb, FIFO_ADDR, S, 4, MODE_SF, dreq=12) == 13, "unimplemented DREQ"
    assert int(dut.irq.value) == 1
    await rb.write("INT_STATUS", 3)
    assert int(dut.irq.value) == 0
    # peripheral -> memory, byte elements, paced by DREQ 1 (data available)
    fab.fifo_in = [0x11, 0x22]
    await rb.write("SRC_ADDR", FIFO_ADDR)
    await rb.write("DST_ADDR", S + 0x41)
    await rb.write("LENGTH", 5)
    await rb.write("MODE", MODE_SF | MODE_BYTE | (1 << 8))
    await rb.write("CONTROL", 1)
    await rb.write("LENGTH", 9, expect_err=True)         # busy: config locked
    await rb.write("CONTROL", 1, expect_err=True)        # busy: START refused
    for _ in range(200):
        await RisingEdge(dut.clk)
    assert (await rb.read("STATUS")) & 1, "waiting for data"
    fab.fifo_in += [0x33, 0x44, 0x55]
    while (await rb.read("STATUS")) & 1:
        pass
    assert await rb.read("ERROR_CODE") == 0
    assert bytes_of(fab.mem, S + 0x41, 5) == bytes([0x11, 0x22, 0x33, 0x44, 0x55])
    # memory -> peripheral, paced by DREQ 2 (always ready)
    fab.mem[S + 0x80] = 0x44332211
    assert await xfer(rb, S + 0x80, FIFO_ADDR, 4, MODE_DF | MODE_BYTE, dreq=2) == 0
    assert fab.fifo_out == [0x11, 0x22, 0x33, 0x44]
    # abort while waiting for a request that never comes
    await rb.write("SRC_ADDR", FIFO_ADDR)
    await rb.write("DST_ADDR", S)
    await rb.write("LENGTH", 4)
    await rb.write("MODE", MODE_SF | (1 << 8))
    await rb.write("CONTROL", 1)
    await rb.write("CONTROL", 2)
    while (await rb.read("STATUS")) & 1:
        pass
    assert await rb.read("ERROR_CODE") == 10 and (await rb.read("STATUS")) & 8
