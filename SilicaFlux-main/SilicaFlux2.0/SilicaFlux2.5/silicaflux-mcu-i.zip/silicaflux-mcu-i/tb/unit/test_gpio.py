"""mcu_gpio: direction/output, atomic set/clear/toggle, 2-flop input
synchronisation latency, edge interrupts (W1C), level interrupts, errors."""
import cocotb
from cocotb.triggers import ClockCycles, RisingEdge

from common import RegBus, start


@cocotb.test()
async def test_gpio(dut):
    dut.gpio_i.value = 0
    await start(dut)
    rb = RegBus(dut, "gpio")
    await rb.write("OE", 0x00FF)
    await rb.write("OUT", 0x0F0F)
    assert int(dut.gpio_o.value) == 0x0F0F and int(dut.gpio_oe.value) == 0x00FF
    await rb.write("OUT_SET", 0x00F0)
    await rb.write("OUT_CLR", 0x000F)
    await rb.write("OUT_TGL", 0x8001)
    assert await rb.read("OUT") == 0x8FF1
    # synchroniser latency: IN reflects a pin change after 2 clk edges
    dut.gpio_i.value = 0x0100
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    assert (await rb.read("IN")) & 0x0100
    # edges
    await rb.write("IRQ_RISE_EN", 0x0200)
    await rb.write("IRQ_FALL_EN", 0x0400)
    dut.gpio_i.value = 0x0700
    await ClockCycles(dut.clk, 4)
    dut.gpio_i.value = 0x0100
    await ClockCycles(dut.clk, 4)
    assert await rb.read("IRQ_PEND") == 0x0600 and int(dut.irq.value) == 1
    await rb.write("IRQ_PEND", 0x0200)
    assert await rb.read("IRQ_PEND") == 0x0400
    await rb.write("IRQ_PEND", 0x0400)
    assert int(dut.irq.value) == 0
    # level interrupts are not latched
    await rb.write("IRQ_HIGH_EN", 0x0800)
    dut.gpio_i.value = 0x0900
    await ClockCycles(dut.clk, 3)
    assert int(dut.irq.value) == 1 and (await rb.read("IRQ_STATUS")) & 0x0800
    dut.gpio_i.value = 0x0100
    await ClockCycles(dut.clk, 3)
    assert int(dut.irq.value) == 0
    await rb.write("IN", 0, expect_err=True)
    await rb.read(0x030, expect_err=True)
