"""mcu_i2c with behavioural targets: START/repeated START/STOP, address
ACK/NACK, write/read, clock stretching (measured), timeout, glitch filter,
protocol monitor (SDA only changes while SCL is low except START/STOP, the
master never drives a line high: open-drain only)."""
import cocotb
from cocotb.triggers import RisingEdge, ClockCycles

from common import RegBus, start, fmask

CMD_START, CMD_STOP, CMD_READ, CMD_WRITE, CMD_NACK = 1, 2, 4, 8, 16


class Monitor:
    def __init__(self, dut):
        self.dut = dut
        self.starts = self.stops = 0
        self.bad = []

    async def run(self):
        d = self.dut
        ps, pd = 1, 1
        while True:
            await RisingEdge(d.clk)
            s, a = int(d.scl.value), int(d.sda.value)
            if s and ps and a != pd:
                if a == 0:
                    self.starts += 1
                else:
                    self.stops += 1
            ps, pd = s, a


async def cmd(rb, c, data=None):
    if data is not None:
        await rb.write("TXDATA", data)
    await rb.write("CMD", c)
    while (await rb.read("STATUS")) & 1:
        pass
    st = await rb.read("STATUS")
    await rb.write("STATUS", fmask("i2c", "STATUS", "DONE"))
    return st


@cocotb.test()
async def test_eeprom_and_nack(dut):
    dut.glitch_scl.value = 0
    await start(dut)
    mon = Monitor(dut)
    cocotb.start_soon(mon.run())
    rb = RegBus(dut, "i2c")
    await rb.write("PRESCALE", 7)
    await rb.write("CMD", CMD_START, expect_err=True)          # disabled -> refused
    await rb.write("CTRL", 1)
    st = await cmd(rb, CMD_START | CMD_WRITE, 0xA0)            # 0x50 write
    assert not (st & fmask("i2c", "STATUS", "RX_NACK")) and st & fmask("i2c", "STATUS", "BUS_BUSY")
    for b in (0x20, 0x11, 0x22, 0x33):
        assert not (await cmd(rb, CMD_WRITE, b)) & fmask("i2c", "STATUS", "RX_NACK")
    await cmd(rb, CMD_STOP)
    assert not (await rb.read("STATUS")) & fmask("i2c", "STATUS", "BUS_BUSY")
    await cmd(rb, CMD_START | CMD_WRITE, 0xA0)
    await cmd(rb, CMD_WRITE, 0x20)
    await cmd(rb, CMD_START | CMD_WRITE, 0xA1)                 # repeated START, read
    got = []
    for i in range(3):
        last = i == 2
        await cmd(rb, CMD_READ | ((CMD_NACK | CMD_STOP) if last else 0))
        got.append(await rb.read("RXDATA"))
    assert got == [0x11, 0x22, 0x33], got
    st = await cmd(rb, CMD_START | CMD_WRITE | CMD_STOP, 0x46)  # 0x23: nobody
    assert st & fmask("i2c", "STATUS", "RX_NACK")
    assert mon.starts >= 4 and mon.stops >= 3


@cocotb.test()
async def test_stretch_timeout_glitch(dut):
    dut.glitch_scl.value = 0
    await start(dut)
    rb = RegBus(dut, "i2c")
    await rb.write("PRESCALE", 7)
    await rb.write("CTRL", 1)
    # clock stretching: the sensor holds SCL for 3 us after each ACK
    t0 = cocotb.utils.get_sim_time("ns")
    await cmd(rb, CMD_START | CMD_WRITE, 0x90)
    await cmd(rb, CMD_WRITE, 0x00)
    await cmd(rb, CMD_START | CMD_WRITE, 0x91)
    await cmd(rb, CMD_READ)
    v0 = await rb.read("RXDATA")
    await cmd(rb, CMD_READ | CMD_NACK | CMD_STOP)
    v1 = await rb.read("RXDATA")
    dt = cocotb.utils.get_sim_time("ns") - t0
    assert (v0, v1) == (0x1A, 0x2B), (hex(v0), hex(v1))
    assert dt > 3 * 3000, f"stretching not honoured ({dt} ns)"
    # timeout: register 0x7F makes the sensor hold SCL for 60 us
    await rb.write("TIMEOUT", 1000)
    await cmd(rb, CMD_START | CMD_WRITE, 0x90)
    await cmd(rb, CMD_WRITE, 0x7F)
    st = await cmd(rb, CMD_START | CMD_WRITE, 0x91)
    assert st & fmask("i2c", "STATUS", "TIMEOUT") and not (st & fmask("i2c", "STATUS", "BUS_BUSY"))
    assert int(dut.m_scl_oe.value) == 0 and int(dut.m_sda_oe.value) == 0, "lines released after timeout"
    await rb.write("STATUS", fmask("i2c", "STATUS", "TIMEOUT"))
    await ClockCycles(dut.clk, 7000)
    # glitch filter: a 2-cycle low spike on SCL while the bus is idle-high is ignored
    await rb.write("TIMEOUT", 0)
    await cmd(rb, CMD_START | CMD_WRITE, 0xA0)
    dut.glitch_scl.value = 1
    await ClockCycles(dut.clk, 2)
    dut.glitch_scl.value = 0
    st = await cmd(rb, CMD_WRITE | CMD_STOP, 0x00)
    assert not (st & fmask("i2c", "STATUS", "RX_NACK"))
