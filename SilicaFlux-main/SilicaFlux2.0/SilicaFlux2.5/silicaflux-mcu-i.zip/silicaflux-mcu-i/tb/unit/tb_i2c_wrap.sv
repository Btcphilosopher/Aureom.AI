// cocotb wrapper: mcu_i2c + EEPROM and sensor models on a wired-AND bus with
// pull-ups, plus glitch injection inputs and a bus monitor for the test.
`timescale 1ns/1ps
module tb_i2c_wrap (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rb_sel,
  input  logic        rb_we,
  input  logic [11:0] rb_addr,
  input  logic [31:0] rb_wdata,
  output logic [31:0] rb_rdata,
  output logic        rb_err,
  output logic        irq,
  output logic        err_evt,
  input  logic        glitch_scl,      // test: force SCL low (spike)
  output logic        scl,
  output logic        sda,
  output logic        m_scl_oe,
  output logic        m_sda_oe
);
  logic ee_scl_oe, ee_sda_oe, se_scl_oe, se_sda_oe;
  assign scl = !(m_scl_oe || ee_scl_oe || se_scl_oe || glitch_scl);
  assign sda = !(m_sda_oe || ee_sda_oe || se_sda_oe);
  mcu_i2c u_dut (.clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
                 .scl_i(scl), .sda_i(sda), .scl_oe(m_scl_oe), .sda_oe(m_sda_oe), .irq, .err_evt);
  i2c_slave_model #(.ADDR(7'h50), .KIND(0)) u_ee (.scl, .sda, .scl_oe(ee_scl_oe), .sda_oe(ee_sda_oe));
  i2c_slave_model #(.ADDR(7'h48), .KIND(1), .STRETCH_NS(3000), .HANG_NS(60000)) u_se (.scl, .sda, .scl_oe(se_scl_oe), .sda_oe(se_sda_oe));
endmodule
