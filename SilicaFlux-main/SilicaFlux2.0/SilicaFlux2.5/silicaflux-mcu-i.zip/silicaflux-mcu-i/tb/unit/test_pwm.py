"""mcu_pwm: duty/period measured on the output against the specification
(0 %, 25 %, 100 %, DUTY > TOP), glitch-free shadowed duty update, polarity,
safe state on disable, fault latency (<= 3 clk), latched fault clear rules."""
import cocotb
from cocotb.triggers import ClockCycles, RisingEdge, ReadOnly, Timer

from common import RegBus, start, REGS


async def measure(dut, chan, cycles):
    hi = 0
    widths, run = [], 0
    for _ in range(cycles):
        await RisingEdge(dut.clk)
        b = (int(dut.pwm_o.value) >> chan) & 1
        hi += b
        if b:
            run += 1
        elif run:
            widths.append(run); run = 0
    return hi, widths


@cocotb.test()
async def test_duty_shadow_polarity(dut):
    dut.fault_i.value = 0
    await start(dut)
    rb = RegBus(dut, "pwm")
    assert int(dut.pwm_o.value) == 0, "reset state"
    await rb.write("PRESCALE", 0)
    await rb.write("PERIOD", 99)                         # period 100 clk
    for i, d in enumerate((25, 0, 100, 200)):
        await rb.write(REGS["pwm"]["DUTY0"] + 4 * i, d)
    await rb.write("OUT_EN", 0xF)
    await rb.write("CTRL", 1)
    await ClockCycles(dut.clk, 120)
    for chan, exp in ((0, 250), (1, 0), (2, 1000), (3, 1000)):
        hi, _ = await measure(dut, chan, 1000)
        assert abs(hi - exp) <= 1, f"ch{chan}: high {hi} of 1000, expected {exp}"
    # shadowed update: no runt pulses (every pulse is 25 or 60 wide)
    t = cocotb.start_soon(measure(dut, 0, 1000))
    await ClockCycles(dut.clk, 337)
    await rb.write(REGS["pwm"]["DUTY0"], 60)
    _, widths = await t
    assert all(w in (25, 60) for w in widths[1:]), widths
    # polarity
    await rb.write("POL", 0x1)
    await ClockCycles(dut.clk, 200)
    hi, _ = await measure(dut, 0, 1000)
    assert abs(hi - 400) <= 1
    # disable -> SAFE levels
    await rb.write("SAFE", 0x5)
    await rb.write("CTRL", 0)
    await ClockCycles(dut.clk, 2)
    assert int(dut.pwm_o.value) == 0x5


@cocotb.test()
async def test_fault(dut):
    dut.fault_i.value = 0
    await start(dut)
    rb = RegBus(dut, "pwm")
    await rb.write("PERIOD", 9)
    for i in range(4):
        await rb.write(REGS["pwm"]["DUTY0"] + 4 * i, 20)  # always active
    await rb.write("SAFE", 0x2)
    await rb.write("OUT_EN", 0xF)
    await rb.write("CTRL", 1 | 2 | 4 | 8)                # EN, FAULT_EN, active high, FAULT_IE
    await ClockCycles(dut.clk, 30)
    assert int(dut.pwm_o.value) == 0xF
    await RisingEdge(dut.clk)
    dut.fault_i.value = 1                                # pin changes just after a clock edge
    n = 0
    while True:
        await RisingEdge(dut.clk)
        await ReadOnly()                                 # values after this edge's updates
        n += 1
        if int(dut.pwm_o.value) == 0x2:
            break
    await Timer(1, unit="ns")
    assert n <= 3, f"fault response {n} cycles"
    assert int(dut.irq.value) == 1
    await rb.write("STATUS", 1)
    assert (await rb.read("STATUS")) & 1, "clear ignored while the input is active"
    dut.fault_i.value = 0
    await ClockCycles(dut.clk, 4)
    assert int(dut.pwm_o.value) == 0x2, "stays safe until cleared"
    await rb.write("STATUS", 1)
    assert not ((await rb.read("STATUS")) & 1)
    await ClockCycles(dut.clk, 15)
    assert int(dut.pwm_o.value) == 0xF
    await rb.write("COUNT", 0, expect_err=True)
