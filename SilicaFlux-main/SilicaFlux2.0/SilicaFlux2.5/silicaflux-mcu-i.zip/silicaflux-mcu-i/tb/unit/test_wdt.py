"""mcu_wdt: countdown and expiry -> reset_req, legal service sequence,
illegal service -> immediate reset request, set-only EN/LOCK, LOCK bus
errors, early-warning interrupt, debug pause."""
import cocotb
from cocotb.triggers import ClockCycles, RisingEdge

from common import RegBus, start, CONST


@cocotb.test()
async def test_expiry_service_lock(dut):
    dut.dbg_halt.value = 0
    await start(dut)
    rb = RegBus(dut, "wdt")
    assert not (await rb.read("STATUS")) & 2, "disabled after reset"
    await rb.write("LOAD", 200)
    await rb.write("EWI_THRESH", 50)
    await rb.write("CTRL", 1 | 4)                        # EN, EWI_EN
    await rb.write("CTRL", 4)                            # EN is set-only
    assert (await rb.read("CTRL")) & 1
    for _ in range(4):
        await ClockCycles(dut.clk, 120)
        await rb.write("SERVICE", CONST["WDT_KEY1"])
        await rb.write("SERVICE", CONST["WDT_KEY2"])
        assert int(dut.reset_req.value) == 0
        assert await rb.read("COUNT") > 150
    assert int(dut.irq_ewi.value) == 0
    n = 0
    while int(dut.irq_ewi.value) == 0:
        await RisingEdge(dut.clk); n += 1
    assert 140 <= n <= 160, n
    n = 0
    while int(dut.reset_req.value) == 0:
        await RisingEdge(dut.clk); n += 1
    assert 40 <= n <= 60, n


@cocotb.test()
async def test_illegal_lock_pause(dut):
    dut.dbg_halt.value = 0
    await start(dut)
    rb = RegBus(dut, "wdt")
    await rb.write("LOAD", 1000)
    await rb.write("CTRL", 1 | 2 | 8)                    # EN, LOCK, DBG_PAUSE
    await rb.write("LOAD", 5, expect_err=True)
    await rb.write("PRESCALE", 5, expect_err=True)
    await rb.write("CTRL", 0, expect_err=True)
    dut.dbg_halt.value = 1
    c0 = await rb.read("COUNT")
    await ClockCycles(dut.clk, 100)
    assert await rb.read("COUNT") == c0, "paused while the debugger holds the CPU"
    dut.dbg_halt.value = 0
    await ClockCycles(dut.clk, 10)
    assert int(dut.reset_req.value) == 0
    await rb.write("SERVICE", 0x1234)                    # wrong key
    await RisingEdge(dut.clk)
    assert int(dut.reset_req.value) == 1
    assert (await rb.read("STATUS")) & 4
