"""Shared cocotb helpers for MCU-I unit tests (register-bus driver, clock/reset)."""
import os
import sys

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import FallingEdge, RisingEdge, ClockCycles, Timer

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "scripts", "generated"))
import mcu_map  # noqa: E402  (generated from configs/memmap.yaml)

REGS = mcu_map.REGS
FIELDS = mcu_map.FIELDS
CONST = mcu_map.CONST


async def start(dut, period_ns=10, rst="rst_n"):
    cocotb.start_soon(Clock(dut.clk, period_ns, unit="ns").start())
    getattr(dut, rst).value = 1
    await Timer(1, unit="ns")
    getattr(dut, rst).value = 0
    for s in ("rb_sel", "rb_we", "rb_addr", "rb_wdata"):
        if hasattr(dut, s):
            getattr(dut, s).value = 0
    await ClockCycles(dut.clk, 3)
    getattr(dut, rst).value = 1
    await RisingEdge(dut.clk)


class RegBus:
    """Drives the SilicaFlux-V register bus (rb_sel strobe, combinational
    rb_rdata/rb_err in the strobe cycle, side effects at the clock edge)."""

    def __init__(self, dut, block, sel="rb_sel"):
        self.dut, self.block, self.sel = dut, block, sel

    def off(self, name):
        return REGS[self.block][name] if isinstance(name, str) else name

    async def access(self, name, we, data=0):
        d = self.dut
        await FallingEdge(d.clk)
        getattr(d, self.sel).value = 1
        d.rb_we.value = int(we)
        d.rb_addr.value = self.off(name)
        d.rb_wdata.value = data & 0xFFFFFFFF
        await Timer(1, unit="ns")
        err = int(d.rb_err.value)
        # write cycles: read data is don't-care (and may be X for storage that
        # is intentionally not reset, e.g. DSP coefficients)
        rdata = 0 if we else int(d.rb_rdata.value)
        await RisingEdge(d.clk)
        await Timer(1, unit="ns")
        getattr(d, self.sel).value = 0
        d.rb_we.value = 0
        return rdata, err

    async def write(self, name, data, expect_err=False):
        _, err = await self.access(name, 1, data)
        assert err == int(expect_err), f"write {self.block}.{name}: err={err}, expected {int(expect_err)}"

    async def read(self, name, expect_err=False):
        v, err = await self.access(name, 0)
        assert err == int(expect_err), f"read {self.block}.{name}: err={err}"
        return v


def field(block, reg, name, value):
    hi, lo = FIELDS[block][reg][name]
    return (value >> lo) & ((1 << (hi - lo + 1)) - 1)


def fmask(block, reg, name):
    hi, lo = FIELDS[block][reg][name]
    return ((1 << (hi - lo + 1)) - 1) << lo
