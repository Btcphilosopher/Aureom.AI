"""mcu_intc against a Python model: random source levels, enables, priorities,
threshold and software-pending bits; CLAIM = highest priority, lowest index."""
import random

import cocotb
from cocotb.triggers import ClockCycles

from common import RegBus, start


def model(src, sw, en, prio, thr):
    pend = src | sw
    act = [i for i in range(16) if (pend >> i) & 1 and (en >> i) & 1 and prio[i] > thr]
    if not act:
        return 0, 0
    best = max(prio[i] for i in act)
    return min(i for i in act if prio[i] == best) + 1, sum(1 << i for i in act)


@cocotb.test()
async def test_random(dut):
    dut.src.value = 0
    await start(dut)
    rb = RegBus(dut, "intc")
    assert await rb.read("PRIO0") == 0x11111111
    rng = random.Random(3)
    for it in range(300):
        src, sw, en = rng.getrandbits(16), rng.getrandbits(16) & rng.getrandbits(16), rng.getrandbits(16)
        prio = [rng.randrange(8) for _ in range(16)]
        thr = rng.randrange(8)
        dut.src.value = src
        await rb.write("ENABLE", en)
        await rb.write("SWPEND", sw)
        await rb.write("THRESHOLD", thr)
        await rb.write("PRIO0", sum(prio[i] << (4 * i) for i in range(8)))
        await rb.write("PRIO1", sum(prio[8 + i] << (4 * i) for i in range(8)))
        claim, act = model(src, sw, en, prio, thr)
        assert await rb.read("CLAIM") == claim, f"iter {it}"
        assert await rb.read("ACTIVE") == act
        assert int(dut.irq_ext.value) == (act != 0)
        assert await rb.read("PENDING") == (src | sw)
    await rb.write("CLAIM", 0, expect_err=True)
