"""mcu_uart: TX framing (parity/stop variants) against a Python encoder, RX
decoding with injected frames, parity/framing/overrun errors, FIFO limits,
loopback, glitch rejection, DMA request levels."""
import random

import cocotb
from cocotb.triggers import ClockCycles, RisingEdge

from common import RegBus, start, fmask

BAUD = 16


def frame_bits(byte, parity, stop2):
    bits = [0] + [(byte >> i) & 1 for i in range(8)]
    if parity in (1, 2):
        p = bin(byte).count("1") & 1
        bits.append(p ^ (1 if parity == 2 else 0))
    bits += [1, 1] if stop2 else [1]
    return bits


async def capture_tx(dut, nbits):
    """Sample txd in the middle of each bit after the start edge."""
    while int(dut.txd.value) == 1:
        await RisingEdge(dut.clk)
    await ClockCycles(dut.clk, BAUD // 2)
    out = []
    for _ in range(nbits):
        out.append(int(dut.txd.value))
        await ClockCycles(dut.clk, BAUD)
    return out


async def send_rx(dut, bits):
    for b in bits:
        dut.rxd.value = b
        await ClockCycles(dut.clk, BAUD)
    dut.rxd.value = 1


@cocotb.test()
async def test_tx_framing(dut):
    dut.rxd.value = 1
    await start(dut)
    rb = RegBus(dut, "uart")
    await rb.write("BAUD", BAUD)
    rng = random.Random(1)
    for parity in (0, 1, 2):
        for stop2 in (0, 1):
            await rb.write("CTRL", (parity << 3) | (stop2 << 5))
            for _ in range(4):
                byte = rng.randrange(256)
                exp = frame_bits(byte, parity, stop2)
                await rb.write("DATA", byte)
                got = await capture_tx(dut, len(exp))
                assert got == exp, f"parity={parity} stop2={stop2} byte={byte:02x}: {got} != {exp}"
            while not (await rb.read("STATUS")) & fmask("uart", "STATUS", "TX_IDLE"):
                pass


@cocotb.test()
async def test_rx_and_errors(dut):
    dut.rxd.value = 1
    await start(dut)
    rb = RegBus(dut, "uart")
    await rb.write("BAUD", BAUD)
    await rb.write("CTRL", 1 << 3)                      # even parity
    st = fmask
    # good frame
    await send_rx(dut, frame_bits(0x5A, 1, 0))
    await ClockCycles(dut.clk, 4)
    assert int(dut.dreq_rx.value) == 1
    v = await rb.read("DATA")
    assert v & 0xFF == 0x5A and not (v >> 31)
    assert int(dut.dreq_rx.value) == 0
    # parity error: byte stored, PARITY_ERR set
    bad = frame_bits(0x33, 1, 0)
    bad[9] ^= 1
    await send_rx(dut, bad)
    await ClockCycles(dut.clk, 4)
    s = await rb.read("STATUS")
    assert s & st("uart", "STATUS", "PARITY_ERR")
    assert (await rb.read("DATA")) & 0xFF == 0x33
    await rb.write("STATUS", st("uart", "STATUS", "PARITY_ERR"))
    # framing error: stop bit 0 -> byte dropped
    fr = frame_bits(0x44, 1, 0)
    fr[-1] = 0
    await send_rx(dut, fr)
    await ClockCycles(dut.clk, 2 * BAUD)
    s = await rb.read("STATUS")
    assert s & st("uart", "STATUS", "FRAME_ERR") and not (s & st("uart", "STATUS", "RX_VALID"))
    await rb.write("STATUS", 0x7F)
    # overrun: FIFO depth 8, send 10 -> 8 kept, RX_OVF
    for i in range(10):
        await send_rx(dut, frame_bits(i, 1, 0))
    await ClockCycles(dut.clk, 4)
    s = await rb.read("STATUS")
    assert s & st("uart", "STATUS", "RX_OVF") and s & st("uart", "STATUS", "RX_FULL")
    assert ((s >> 8) & 0x1F) == 8
    got = [(await rb.read("DATA")) & 0xFF for _ in range(8)]
    assert got == list(range(8)), got
    v = await rb.read("DATA")
    assert v >> 31 == 1, "read while empty returns RX_EMPTY, no pop"
    # glitch shorter than half a bit is rejected
    dut.rxd.value = 0
    await ClockCycles(dut.clk, BAUD // 4)
    dut.rxd.value = 1
    await ClockCycles(dut.clk, 3 * BAUD)
    assert not ((await rb.read("STATUS")) & st("uart", "STATUS", "RX_VALID"))


@cocotb.test()
async def test_loopback_fifo_full(dut):
    dut.rxd.value = 1
    await start(dut)
    rb = RegBus(dut, "uart")
    await rb.write("BAUD", 3)                          # stored as 4 (minimum)
    assert await rb.read("BAUD") == 4
    await rb.write("BAUD", BAUD)
    await rb.write("CTRL", (2 << 3) | (1 << 2) | (1 << 5))   # odd parity, loopback, 2 stop
    for i in range(12):                                 # FIFO 8 + shifter: extra bytes dropped
        await rb.write("DATA", 0xA0 + i)
    s = await rb.read("STATUS")
    assert s & fmask("uart", "STATUS", "TX_OVF")
    assert int(dut.txd.value) in (0, 1)
    await ClockCycles(dut.clk, 13 * BAUD * 10)
    got = []
    while True:
        v = await rb.read("DATA")
        if v >> 31:
            break
        got.append(v & 0xFF)
    assert got[0] == 0xA0 and len(got) == 8, got       # 1 in the shifter + 7.. limited by RX FIFO 8
    s = await rb.read("STATUS")
    assert not (s & fmask("uart", "STATUS", "PARITY_ERR")) and not (s & fmask("uart", "STATUS", "FRAME_ERR"))
    await rb.write("STATUS", 0, expect_err=False)
    await rb.read(0x010, expect_err=True)              # unmapped offset
