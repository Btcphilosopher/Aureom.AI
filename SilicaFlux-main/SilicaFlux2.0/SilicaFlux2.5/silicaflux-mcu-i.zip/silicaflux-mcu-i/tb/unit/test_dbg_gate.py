"""mcu_dbg_gate: unlocked pass-through; locked -> local error response, no
system request, CPU hold / reset / boot override forced off; a transaction
already forwarded before the lock completes normally."""
import cocotb
from cocotb.triggers import RisingEdge, ReadOnly, Timer

from common import start


@cocotb.test()
async def test_gate(dut):
    for s in ("locked", "d_req", "d_we", "d_cpu_hold", "d_sys_reset_req", "d_boot_ovr", "m_gnt", "m_rvalid", "m_err"):
        getattr(dut, s).value = 0
    dut.d_addr.value = 0x40000000; dut.d_be.value = 0xF; dut.d_wdata.value = 0; dut.m_rdata.value = 0x1234
    await start(dut)
    dut.d_cpu_hold.value = 1
    await Timer(1, unit="ns")
    assert int(dut.cpu_hold.value) == 1
    # unlocked transaction
    dut.d_req.value = 1; dut.m_gnt.value = 1
    await Timer(1, unit="ns")
    assert int(dut.m_req.value) == 1 and int(dut.d_gnt.value) == 1
    await RisingEdge(dut.clk); await Timer(1, unit="ns")
    dut.d_req.value = 0; dut.m_gnt.value = 0
    dut.locked.value = 1                                  # lock while a response is pending
    await Timer(1, unit="ns")
    assert int(dut.cpu_hold.value) == 0
    dut.m_rvalid.value = 1
    await Timer(1, unit="ns")
    assert int(dut.d_rvalid.value) == 1 and int(dut.d_rdata.value) == 0x1234 and int(dut.d_err.value) == 0
    await RisingEdge(dut.clk); await Timer(1, unit="ns")
    dut.m_rvalid.value = 0
    # locked transaction: refused locally
    dut.d_req.value = 1
    await Timer(1, unit="ns")
    assert int(dut.m_req.value) == 0 and int(dut.d_gnt.value) == 1
    await RisingEdge(dut.clk); await Timer(1, unit="ns")
    dut.d_req.value = 0
    await Timer(1, unit="ns")
    assert int(dut.d_rvalid.value) == 1 and int(dut.d_err.value) == 1 and int(dut.d_rdata.value) == 0
