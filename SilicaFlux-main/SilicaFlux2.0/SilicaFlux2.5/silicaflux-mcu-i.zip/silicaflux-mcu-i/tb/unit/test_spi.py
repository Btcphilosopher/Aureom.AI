"""mcu_spi against an independent Python SPI slave model: all four modes,
8/16/32-bit frames, several SCK dividers, full duplex data both directions,
chip-select mapping, BUSY write protection, RX_VALID/RX_OVF, RX_AUTO."""
import random

import cocotb
from cocotb.triggers import Edge, RisingEdge, ClockCycles, First

from common import RegBus, start, fmask


class SpiSlave:
    """Mode-aware slave driven by SCK edges (like a real device): samples MOSI
    on the sampling edge, changes MISO on the other edge; for CPHA=0 the first
    bit is valid as soon as the frame starts."""

    def __init__(self, dut):
        self.dut = dut
        self.rx = []

    async def frame(self, mode, bits, tx_word, cs_bit=0):
        d = self.dut
        cpha = mode & 1
        while (int(d.cs_n.value) >> cs_bit) & 1:
            await RisingEdge(d.clk)
        tx = [(tx_word >> (bits - 1 - i)) & 1 for i in range(bits)]
        rx, idx, edges = 0, 0, 0
        if not cpha:
            d.miso.value = tx[0]
            idx = 1
        while edges < 2 * bits:
            await Edge(d.sck)
            edges += 1
            leading = (edges % 2 == 1)
            if leading ^ bool(cpha):                  # sampling edge
                rx = (rx << 1) | int(d.mosi.value)
            elif idx < bits:                          # shifting edge
                d.miso.value = tx[idx]
                idx += 1
        self.rx.append(rx)
        return rx


@cocotb.test()
async def test_modes_lengths(dut):
    dut.miso.value = 0
    await start(dut)
    rb = RegBus(dut, "spi")
    slave = SpiSlave(dut)
    rng = random.Random(7)
    for div in (0, 1, 3):
        await rb.write("DIV", div)
        for mode in range(4):
            for lenc, bits in ((0, 8), (1, 16), (2, 32)):
                m2s = rng.getrandbits(bits)
                s2m = rng.getrandbits(bits)
                pp = (mode >> 1) | ((mode & 1) << 1)          # CTRL: bit0 CPOL, bit1 CPHA
                await rb.write("CTRL", pp | (lenc << 4))
                assert int(dut.sck.value) == (mode >> 1), f"SCK idles at CPOL (div={div} mode={mode} bits={bits} sck={int(dut.sck.value)})"
                await rb.write("CTRL", pp | (lenc << 4) | (1 << 8))      # CS0
                t = cocotb.start_soon(slave.frame(mode, bits, s2m))
                await rb.write("DATA", m2s)
                await t
                while (await rb.read("STATUS")) & 1:
                    pass
                got = await rb.read("DATA")
                assert slave.rx[-1] == m2s, f"MOSI mode={mode} bits={bits} div={div}: {slave.rx[-1]:x} != {m2s:x}"
                assert got == s2m, f"MISO mode={mode} bits={bits} div={div}: {got:x} != {s2m:x}"
                assert int(dut.sck.value) == (mode >> 1), "SCK returns to CPOL"
                await rb.write("CTRL", pp | (lenc << 4))


@cocotb.test()
async def test_status_cs_auto(dut):
    dut.miso.value = 1
    await start(dut)
    rb = RegBus(dut, "spi")
    await rb.write("DIV", 2)
    await rb.write("CTRL", (0xA << 8) | (2 << 4))       # CS1 and CS3, 32-bit
    assert int(dut.cs_n.value) == 0b0101
    await rb.write("DATA", 0x12345678)
    await rb.write("DATA", 0, expect_err=True)           # BUSY: refused
    while (await rb.read("STATUS")) & 1:
        pass
    s = await rb.read("STATUS")
    assert s & fmask("spi", "STATUS", "DONE") and s & fmask("spi", "STATUS", "RX_VALID")
    assert int(dut.dreq_rx.value) == 1 and int(dut.dreq_tx.value) == 1
    await rb.write("DATA", 1)                            # second frame without reading
    while (await rb.read("STATUS")) & 1:
        pass
    assert (await rb.read("STATUS")) & fmask("spi", "STATUS", "RX_OVF")
    assert await rb.read("DATA") == 0xFFFFFFFF           # MISO tied high
    assert not ((await rb.read("STATUS")) & fmask("spi", "STATUS", "RX_VALID"))
    # RX_AUTO: a DATA read starts the next frame (all-ones out)
    await rb.write("CTRL", (2 << 4) | (1 << 6) | (1 << 8))
    assert int(dut.dreq_tx.value) == 0
    await rb.read("DATA")
    s = await rb.read("STATUS")
    assert s & 1, "read in RX_AUTO started a frame"
    await rb.read(0x010, expect_err=True)
