"""mcu_gptimer (4 channels): period = (PRESCALE+1)(RELOAD+1), one-shot,
compare, capture on rising/falling/both edges with overrun, 32-bit rollover,
channel independence, status W1C, read-only CAPTURE."""
import cocotb
from cocotb.triggers import ClockCycles, RisingEdge

from common import RegBus, start, REGS

STRIDE = 0x20


def ch(c, name):
    return c * STRIDE + REGS["gptimer"][name]


async def wait_status(rb, c, mask, limit=100000):
    for _ in range(limit):
        if (await rb.read(ch(c, "CH_STATUS"))) & mask:
            return
    raise AssertionError("status timeout")


@cocotb.test()
async def test_period_oneshot_compare(dut):
    dut.cap_i.value = 0
    await start(dut)
    rb = RegBus(dut, "gptimer")
    assert await rb.read("INFO") == 4
    # periodic: measure the interval between two OVF events in clk cycles
    await rb.write(ch(0, "CH_PRESCALE"), 2)
    await rb.write(ch(0, "CH_RELOAD"), 19)
    await rb.write(ch(0, "CH_CTRL"), 1 | 4)                 # EN, OVF_IE
    t = []
    for _ in range(3):
        while int(dut.irq.value) == 0:
            await RisingEdge(dut.clk)
        t.append(cocotb.utils.get_sim_time("ns"))
        await rb.write(ch(0, "CH_STATUS"), 1)
    assert round((t[2] - t[1]) / 10) == 3 * 20, f"period {(t[2]-t[1])/10} cycles"
    await rb.write(ch(0, "CH_CTRL"), 0)
    # one-shot + compare on channel 2 (others untouched)
    await rb.write(ch(2, "CH_RELOAD"), 30)
    await rb.write(ch(2, "CH_CMP"), 10)
    await rb.write(ch(2, "CH_CTRL"), 1 | 2)
    await ClockCycles(dut.clk, 60)
    assert (await rb.read(ch(2, "CH_CTRL"))) & 1 == 0, "one-shot cleared EN"
    assert (await rb.read(ch(2, "CH_STATUS"))) & 3 == 3
    assert await rb.read(ch(2, "CH_COUNT")) == 0
    assert await rb.read(ch(1, "CH_STATUS")) == 0 and await rb.read(ch(3, "CH_COUNT")) == 0
    # rollover
    await rb.write(ch(3, "CH_COUNT"), 0xFFFFFFFD)
    await rb.write(ch(3, "CH_CTRL"), 1)
    await ClockCycles(dut.clk, 10)
    assert (await rb.read(ch(3, "CH_STATUS"))) & 1
    assert await rb.read(ch(3, "CH_COUNT")) < 16
    await rb.write(ch(3, "CH_CAPTURE"), 0, expect_err=True)


@cocotb.test()
async def test_capture(dut):
    dut.cap_i.value = 0
    await start(dut)
    rb = RegBus(dut, "gptimer")
    await rb.write(ch(1, "CH_CTRL"), 1 | (3 << 5))         # EN, both edges
    await ClockCycles(dut.clk, 50)
    dut.cap_i.value = 0b0010
    await ClockCycles(dut.clk, 3)
    c1 = await rb.read(ch(1, "CH_CAPTURE"))
    assert (await rb.read(ch(1, "CH_STATUS"))) & 4
    await rb.write(ch(1, "CH_STATUS"), 4)
    await ClockCycles(dut.clk, 40)
    dut.cap_i.value = 0
    await ClockCycles(dut.clk, 3)
    c2 = await rb.read(ch(1, "CH_CAPTURE"))
    assert 38 <= c2 - c1 <= 50, (c1, c2)
    dut.cap_i.value = 0b0010
    await ClockCycles(dut.clk, 3)
    assert (await rb.read(ch(1, "CH_STATUS"))) & 0xC == 0xC, "capture while CAP set -> CAP_OVR"
