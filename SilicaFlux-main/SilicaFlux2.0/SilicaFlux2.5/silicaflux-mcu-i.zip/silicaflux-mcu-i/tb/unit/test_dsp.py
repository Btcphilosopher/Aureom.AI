"""mcu_dsp against an independent Python model (bit exact): random MAC,
DOT2, MULQ, SADD, ACC_Q with SAT/ROUND/SHIFT combinations, sticky overflow,
16-tap FIR with random coefficients/samples, BUSY write protection."""
import random

import cocotb
from cocotb.triggers import ClockCycles

from common import RegBus, start, REGS


def s16(v):
    v &= 0xFFFF
    return v - 0x10000 if v & 0x8000 else v


def s32(v):
    v &= 0xFFFFFFFF
    return v - (1 << 32) if v & 0x80000000 else v


def add_sat(a, b, sat):
    s = s32(a + b)
    ovf = (a < 0) == (b < 0) and (s < 0) != (a < 0)
    if ovf and sat:
        s = -(1 << 31) if a < 0 else (1 << 31) - 1
    return s, ovf


def sat16(v):
    if v > 32767:
        return 32767, True
    if v < -32768:
        return -32768, True
    return v, False


def shr(v, s, rnd):
    if rnd and s:
        v += 1 << (s - 1)
    return v >> s


class Model:
    def __init__(self):
        self.acc = 0; self.ovf = False; self.sat = 0; self.rnd = 0; self.shift = 0; self.res = 0
        self.opa = 0; self.coef = [0] * 16; self.dl = [0] * 16; self.nt = 1; self.fir = 0


async def wait_idle(rb):
    while (await rb.read("STATUS")) & 2:
        pass


@cocotb.test()
async def test_random_ops(dut):
    await start(dut)
    rb = RegBus(dut, "dsp")
    rng = random.Random(9)
    m = Model()
    for it in range(400):
        op = rng.randrange(6)
        if op == 0:
            m.sat, m.rnd, m.shift = rng.randrange(2), rng.randrange(2), rng.randrange(32)
            await rb.write("CTRL", m.sat | (m.rnd << 1) | (m.shift << 8))
        elif op == 1:
            x, y = rng.choice([-32768, 32767, rng.randrange(-32768, 32768)]), rng.randrange(-32768, 32768)
            await rb.write("MAC", ((x & 0xFFFF) << 16) | (y & 0xFFFF))
            m.acc, o = add_sat(m.acc, x * y, m.sat); m.ovf |= o
        elif op == 2:
            a, b = rng.getrandbits(32), rng.getrandbits(32)
            await rb.write("OPA", a)
            await rb.write("DOT2", b)
            m.acc, o1 = add_sat(m.acc, s16(a) * s16(b), m.sat)
            m.acc, o2 = add_sat(m.acc, s16(a >> 16) * s16(b >> 16), m.sat)
            m.ovf |= o1 | o2
        elif op == 3:
            x, y = rng.randrange(-32768, 32768), rng.randrange(-32768, 32768)
            await rb.write("MULQ", ((x & 0xFFFF) << 16) | (y & 0xFFFF))
            m.res, o = sat16(shr(x * y, 15, m.rnd)); m.ovf |= o
        elif op == 4:
            x, y = rng.randrange(-32768, 32768), rng.randrange(-32768, 32768)
            await rb.write("SADD", ((x & 0xFFFF) << 16) | (y & 0xFFFF))
            m.res, o = sat16(x + y); m.ovf |= o
        else:
            m.acc = s32(rng.getrandbits(32))
            await rb.write("ACC", m.acc & 0xFFFFFFFF)
        await wait_idle(rb)
        assert s32(await rb.read("ACC")) == m.acc, f"iter {it} op {op}: ACC"
        assert s32(await rb.read("RESULT")) == m.res, f"iter {it}: RESULT"
        assert s32(await rb.read("ACC_Q")) == sat16(shr(m.acc, m.shift, m.rnd))[0], f"iter {it}: ACC_Q"
        assert bool((await rb.read("STATUS")) & 1) == m.ovf, f"iter {it}: OVF"
        if rng.random() < 0.1:
            await rb.write("STATUS", 1); m.ovf = False


@cocotb.test()
async def test_fir(dut):
    await start(dut)
    rb = RegBus(dut, "dsp")
    rng = random.Random(4)
    for nt, sat in ((16, 1), (5, 0), (1, 1)):
        coef = [rng.randrange(-32768, 32768) for _ in range(16)]
        for i in range(16):
            await rb.write(REGS["dsp"]["COEF0"] + 4 * i, coef[i] & 0xFFFF)
        await rb.write("CTRL", sat | (1 << 1) | (15 << 8))
        await rb.write("FIR_CTRL", (nt - 1) | (1 << 8))
        dl = [0] * 16
        for n in range(40):
            x = rng.randrange(-32768, 32768)
            dl = [x] + dl[:15]
            acc, ovf = 0, False
            for k in range(nt):
                acc, o = add_sat(acc, coef[k] * dl[k], sat); ovf |= o
            await rb.write("FIR_IN", x & 0xFFFF)
            if nt > 2:
                await rb.write("FIR_IN", 0, expect_err=True)   # busy: refused, ignored
            await wait_idle(rb)
            assert s32(await rb.read("FIR_OUT")) == acc, f"nt={nt} n={n}"
            assert s32(await rb.read("FIR_OUT_Q")) == sat16(shr(acc, 15, 1))[0]
        await rb.write("STATUS", 1)
