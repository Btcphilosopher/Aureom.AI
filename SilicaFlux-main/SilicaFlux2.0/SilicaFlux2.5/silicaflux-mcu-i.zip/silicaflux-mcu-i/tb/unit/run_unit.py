#!/usr/bin/env python3
"""Run the MCU-I cocotb unit tests (Icarus Verilog).

    python3 tb/unit/run_unit.py [test ...]      (default: all)

Writes build/unit/<test>/results.xml and reports/sim/unit_summary.txt with
seed, simulator and cocotb versions.  Exit status 1 if any test fails.
"""
import os
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import cocotb
from cocotb_tools.runner import get_runner

ROOT = Path(__file__).resolve().parents[2]
SEED = int(os.environ.get("COCOTB_RANDOM_SEED", "20261106"))
COMMON = ["rtl/generated/mcu_memmap_pkg.sv", "third_party/silicaflux-v/rtl/common/sfv_common.sv"]
SRAM = ["third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv",
        "third_party/silicaflux-sramlib/rtl/mem/backends/fpga/sram_fpga_1rw.sv",
        "third_party/silicaflux-sramlib/rtl/mem/sram_backend_1rw.sv",
        "third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv",
        "third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv"]
TESTS = {
    "uart":     (["rtl/uart/mcu_uart.sv"], "mcu_uart", {}),
    "spi":      (["rtl/spi/mcu_spi.sv"], "mcu_spi", {}),
    "i2c":      (["rtl/i2c/mcu_i2c.sv", "tb/models/i2c_slave_model.sv", "tb/unit/tb_i2c_wrap.sv"], "tb_i2c_wrap", {}),
    "gpio":     (["rtl/gpio/mcu_gpio.sv"], "mcu_gpio", {"N": 16}),
    "gptimer":  (["rtl/timers/mcu_gptimer.sv"], "mcu_gptimer", {"N": 4}),
    "pwm":      (["rtl/pwm/mcu_pwm.sv"], "mcu_pwm", {}),
    "wdt":      (["rtl/watchdog/mcu_wdt.sv"], "mcu_wdt", {}),
    "intc":     (["rtl/interrupts/mcu_intc.sv"], "mcu_intc", {}),
    "dma":      (["rtl/dma/mcu_dma.sv"], "mcu_dma", {"DREQ_MASK": 0x1FE}),
    "dsp":      (["rtl/dsp/mcu_dsp.sv"], "mcu_dsp", {}),
    "sram_bank": (SRAM + ["rtl/mem/mcu_sram_bank.sv"], "mcu_sram_bank", {"PARITY": 1, "DEPTH": 256}),
    "dbg_gate": (["rtl/debug/mcu_dbg_gate.sv"], "mcu_dbg_gate", {}),
}


def run(name):
    srcs, top, params = TESTS[name]
    build = ROOT / "build" / "unit" / name
    r = get_runner("icarus")
    r.build(sources=[ROOT / s for s in COMMON + srcs], hdl_toplevel=top, build_dir=build,
            parameters=params, includes=[ROOT / "third_party/silicaflux-sramlib/rtl/mem"],
            build_args=["-g2012"], always=True, timescale=("1ns", "1ps"))
    xml = r.test(hdl_toplevel=top, test_module=f"test_{name}", build_dir=build,
                 test_dir=ROOT / "tb" / "unit", seed=SEED, extra_env={"PYTHONPATH": str(ROOT / "tb" / "unit")})
    tree = ET.parse(xml)
    cases = tree.findall(".//testcase")
    fails = [c.get("name") for c in cases if c.find("failure") is not None or c.find("error") is not None]
    return len(cases), fails


def main():
    names = sys.argv[1:] or list(TESTS)
    rows, bad = [], 0
    for n in names:
        try:
            total, fails = run(n)
        except Exception as e:  # build error etc.
            total, fails = 0, [f"runner error: {e}"]
        bad += bool(fails) or total == 0
        rows.append(f"{n:10s} tests={total} fail={len(fails)} {' '.join(fails)}")
        print(rows[-1], flush=True)
    out = ROOT / "reports" / "sim" / "unit_summary.txt"
    out.parent.mkdir(parents=True, exist_ok=True)
    iv = os.popen("iverilog -V 2>&1 | head -1").read().strip()
    with open(out, "w") as f:
        f.write(f"# MCU-I cocotb unit tests; cocotb {cocotb.__version__}; {iv}; COCOTB_RANDOM_SEED={SEED}\n")
        f.write(f"# command: python3 tb/unit/run_unit.py {' '.join(names)}\n")
        f.write("\n".join(rows) + f"\nOVERALL {'PASS' if not bad else 'FAIL'}\n")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
