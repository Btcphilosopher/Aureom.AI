// SilicaFlux MCU-I :: Verilator main for coverage builds
// Verilator 5.020's generated --main does not write coverage data, so the
// coverage build (scripts/coverage.sh) uses this main instead: identical
// simulation loop, plus VerilatedCov::write() at the end.  Output file:
// coverage.dat in the working directory (override with +covfile=<path>).
#include "verilated.h"
#include "verilated_cov.h"
#include "Vtb_mcu_soc.h"
#include <memory>
#include <string>

int main(int argc, char** argv, char**) {
    const std::unique_ptr<VerilatedContext> contextp{new VerilatedContext};
    contextp->commandArgs(argc, argv);
    const std::unique_ptr<Vtb_mcu_soc> topp{new Vtb_mcu_soc{contextp.get()}};
    while (!contextp->gotFinish()) {
        topp->eval();
        if (!topp->eventsPending()) break;
        contextp->time(topp->nextTimeSlot());
    }
    topp->final();
    const char* arg = contextp->commandArgsPlusMatch("covfile=");
    std::string f = (arg && *arg) ? std::string(arg).substr(9) : std::string("coverage.dat");
    contextp->coveragep()->write(f.c_str());
    return 0;
}
