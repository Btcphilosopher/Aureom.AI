// =============================================================================
// SilicaFlux MCU-I :: tb_mcu_soc -- firmware-level SoC testbench
//
// Derived from third_party/silicaflux-v/tb/soc/tb_soc.sv (UART monitor, JTAG
// host tasks, pass/fail protocol); board models are new.
// DUT: mcu_top (variant selected by the compiled mcu_cfg_<variant>_pkg.sv).
// Board:
//   UART0 -> monitor (prints "UART| ..."), optional image injection on RX
//   UART1 TX -> RX loopback
//   SPI0 CS0 -> spi_flash_model (boot image), CS1 -> MOSI->MISO loopback
//   SPI1 MOSI -> MISO loopback
//   I2C: EEPROM model @0x50, clock-stretching sensor model @0x48, pull-ups
//   GPIO: gpio[1:0] boot straps, gpio[2] -> gpio[3], gpio[8] -> gpio[4],
//         pwm[0] -> gpio[5] (timer capture 1), gpio[9] -> pwm_fault_i,
//         other pads pulled low
//   JTAG host: +jtag=1 load SRAM image and post the mailbox (boot mode 1)
//              +jtag=2 check debug lock (SBA refused, IDCODE readable)
//              +jtag=3 hold CPU, load SRAM image, release (boot mode 3)
// plusargs: +boot=<0..3> +flash=<hex> +uart_img=<bin as hex bytes>
//           +uart_n=<bytes> +sram=<word hex> +sram_words=<n> +jtag=<n>
//           +maxcyc=<n> +expect_fail=1 +log=<file>
//           +stop_on="<uart line>"
// Exit: "TB_SOC RESULT PASS|FAIL|TIMEOUT ..."
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_mcu_soc;
  localparam int BAUD = 16;                       // UART bit period (clk cycles)

  logic clk = 0, rst_n = 1;
  initial #1 rst_n = 0;                           // asserted with an edge (see SFV ISS-108)
  always #5 clk = ~clk;                           // 100 MHz simulation clock

  logic tck = 0, tms = 1, tdi = 0, tdo, tdo_oe;
  logic uart0_tx, uart0_rx = 1, uart1_tx;
  logic spi0_sck, spi0_mosi, spi0_miso, spi1_sck, spi1_mosi;
  logic [3:0] spi0_cs_n, spi1_cs_n;
  logic i2c_scl_oe, i2c_sda_oe;
  wire  i2c_scl, i2c_sda;
  logic [31:0] gpio_i, gpio_o, gpio_oe;
  logic [3:0] pwm_o;
  logic test_pass, test_fail, cpu_sleep;
  logic [31:0] test_status;
  logic [1:0] straps;
  logic [31:0] pad;

  mcu_top #(.UART_BAUD_RESET(16'(BAUD))) u_top (
    .clk, .rst_ni(rst_n), .pwr_ok_i(1'b1), .test_mode(1'b0),
    .tck, .tms, .tdi, .tdo, .tdo_oe,
    .uart0_tx, .uart0_rx, .uart1_tx, .uart1_rx(uart1_tx),
    .spi0_sck, .spi0_mosi, .spi0_miso, .spi0_cs_n,
    .spi1_sck, .spi1_mosi, .spi1_miso(spi1_mosi), .spi1_cs_n,
    .i2c_scl_i(i2c_scl), .i2c_scl_oe, .i2c_sda_i(i2c_sda), .i2c_sda_oe,
    .gpio_i, .gpio_o, .gpio_oe, .pwm_o, .pwm_fault_i(pad[9]),
    .test_pass, .test_fail, .test_status, .cpu_sleep
  );

  // ------------------------------------------------------------ GPIO pads
  always_comb begin
    for (int k = 0; k < 32; k++) pad[k] = gpio_oe[k] ? gpio_o[k] : 1'b0;
    gpio_i = pad;
    if (!gpio_oe[0]) gpio_i[0] = straps[0];
    if (!gpio_oe[1]) gpio_i[1] = straps[1];
    if (!gpio_oe[3]) gpio_i[3] = pad[2];
    if (!gpio_oe[4]) gpio_i[4] = pad[8];
    if (!gpio_oe[5]) gpio_i[5] = pwm_o[0];
  end

  // ------------------------------------------------------------ SPI
  logic flash_miso;
  spi_flash_model u_flash (.sck(spi0_sck), .cs_n(spi0_cs_n[0]), .mosi(spi0_mosi), .miso(flash_miso));
  assign spi0_miso = !spi0_cs_n[0] ? flash_miso : (!spi0_cs_n[1] ? spi0_mosi : 1'b0);

  // ------------------------------------------------------------ I2C (wired-AND, pull-ups)
  logic ee_scl_oe, ee_sda_oe, se_scl_oe, se_sda_oe;
  assign i2c_scl = !(i2c_scl_oe || ee_scl_oe || se_scl_oe);
  assign i2c_sda = !(i2c_sda_oe || ee_sda_oe || se_sda_oe);
  i2c_slave_model #(.ADDR(7'h50), .KIND(0)) u_eeprom (.scl(i2c_scl), .sda(i2c_sda), .scl_oe(ee_scl_oe), .sda_oe(ee_sda_oe));
  i2c_slave_model #(.ADDR(7'h48), .KIND(1)) u_sensor (.scl(i2c_scl), .sda(i2c_sda), .scl_oe(se_scl_oe), .sda_oe(se_sda_oe));

  // ------------------------------------------------------------ UART0 monitor
  int    logfd = 0;
  string logname, line = "";
  int    n_chars = 0, n_prompt = 0;
  bit    stop_hit = 0;
  string stop_on;
  initial begin : uart_mon
    logic [7:0] ch;
    forever begin
      @(negedge uart0_tx);
      repeat (BAUD / 2) @(posedge clk);
      if (uart0_tx == 1'b0) begin
        for (int i = 0; i < 8; i++) begin
          repeat (BAUD) @(posedge clk);
          ch[i] = uart0_tx;
        end
        repeat (BAUD) @(posedge clk);
        if (uart0_tx != 1'b1) $display("TB_SOC UART framing error");
        n_chars++;
        if (ch == 8'h0A) begin
          $display("UART| %s", line);
          if (line == "boot: waiting for JTAG host" || line == "boot: waiting for UART image") n_prompt++;
          if (stop_on != "" && line == stop_on) stop_hit = 1;
          if (logfd != 0) $fdisplay(logfd, "%s", line);
          line = "";
        end else if (ch != 8'h0D) begin
          line = {line, string'(ch)};
        end
      end
    end
  end

  // UART0 RX injection (UART boot)
  logic [7:0] uimg [0:131071];
  int         uimg_n = 0;
  task automatic uart_send(input logic [7:0] b);
    uart0_rx = 0; repeat (BAUD) @(posedge clk);
    for (int i = 0; i < 8; i++) begin uart0_rx = b[i]; repeat (BAUD) @(posedge clk); end
    uart0_rx = 1; repeat (BAUD) @(posedge clk);
  endtask

  // ------------------------------------------------------------ JTAG host (from SFV tb_soc)
  localparam int TCK_HALF = 20;
  task automatic jtag_clk(input logic m, input logic d, output logic q);
    tms = m; tdi = d;
    #(TCK_HALF) tck = 1; q = tdo;
    #(TCK_HALF) tck = 0;
  endtask
  task automatic jtag_reset();
    logic q;
    for (int i = 0; i < 6; i++) jtag_clk(1, 0, q);
    jtag_clk(0, 0, q);
  endtask
  task automatic jtag_ir(input logic [4:0] ir);
    logic q;
    jtag_clk(1, 0, q); jtag_clk(1, 0, q); jtag_clk(0, 0, q); jtag_clk(0, 0, q);
    for (int i = 0; i < 5; i++) jtag_clk(i == 4, ir[i], q);
    jtag_clk(1, 0, q); jtag_clk(0, 0, q);
  endtask
  task automatic jtag_dr(input int n, input logic [127:0] din, output logic [127:0] dout);
    logic q;
    dout = '0;
    jtag_clk(1, 0, q); jtag_clk(0, 0, q); jtag_clk(0, 0, q);
    for (int i = 0; i < n; i++) begin jtag_clk(i == n - 1, din[i], q); dout[i] = q; end
    jtag_clk(1, 0, q); jtag_clk(0, 0, q);
  endtask
  task automatic sba(input logic [1:0] op, input logic [31:0] a, input logic [31:0] d,
                     output logic [31:0] rd, output logic err);
    logic [127:0] o;
    jtag_ir(5'h10);
    jtag_dr(66, {62'd0, op, d, a}, o);
    do jtag_dr(66, 128'd0, o); while (o[65]);
    rd = o[63:32]; err = o[64];
  endtask

  // ------------------------------------------------------------ main
  string  flashf, sramf, uimgf;
  int     boot, maxcyc, jtag_scn, cyc, expect_fail, sram_words, jtag_errs = 0;
  logic [31:0] sram_img [0:16383];
  bit     done = 0;
  localparam logic [31:0] IDCODE = {4'h1, mcu_memmap_pkg::JTAG_PART, mcu_memmap_pkg::JTAG_MFR, 1'b1};

  initial begin
    if (!$value$plusargs("boot=%d", boot)) boot = 0;
    if (!$value$plusargs("maxcyc=%d", maxcyc)) maxcyc = 20_000_000;
    if (!$value$plusargs("jtag=%d", jtag_scn)) jtag_scn = 0;
    if (!$value$plusargs("expect_fail=%d", expect_fail)) expect_fail = 0;
    if (!$value$plusargs("stop_on=%s", stop_on)) stop_on = "";
    if ($value$plusargs("log=%s", logname)) logfd = $fopen(logname, "w");
    straps = 2'(boot);
    if ($value$plusargs("flash=%s", flashf)) $readmemh(flashf, u_flash.mem);
    // image lengths are passed explicitly (2-state simulators cannot detect
    // unloaded entries with $isunknown)
    if (!$value$plusargs("sram_words=%d", sram_words)) sram_words = 0;
    if ($value$plusargs("sram=%s", sramf)) $readmemh(sramf, sram_img);
    if (!$value$plusargs("uart_n=%d", uimg_n)) uimg_n = 0;
    if ($value$plusargs("uart_img=%s", uimgf)) $readmemh(uimgf, uimg);
    $display("TB_SOC variant=%s boot_mode=%0d jtag=%0d", mcu_cfg_pkg::VARIANT, boot, jtag_scn);
    repeat (5) @(posedge clk);
    rst_n = 1;
  end

  // UART boot host
  initial begin
    #1;
    if (uimgf != "") begin
      wait (n_prompt >= 1);
      repeat (100) @(posedge clk);
      for (int i = 0; i < uimg_n; i++) uart_send(uimg[i]);
      $display("TB_SOC UART image sent (%0d bytes)", uimg_n);
    end
  end

  // JTAG host scenarios
  initial begin
    logic [127:0] o;
    logic [31:0]  rd;
    logic         e;
    #1;
    if (jtag_scn != 0) begin
      #(200);
      jtag_reset();
      jtag_dr(32, 128'd0, o);
      $display("TB_SOC JTAG IDCODE=%08x", o[31:0]);
      if (o[31:0] !== IDCODE) begin jtag_errs++; $display("TB_SOC JTAG IDCODE mismatch (expected %08x)", IDCODE); end
    end
    if (jtag_scn == 1 || jtag_scn == 3) begin
      if (jtag_scn == 1) wait (n_prompt >= 1);
      jtag_ir(5'h1F);
      jtag_dr(9, 128'h1A5, o);
      if (o[8:1] !== 8'hA5) begin jtag_errs++; $display("TB_SOC JTAG bypass bad"); end
      // mode 3: hold the CPU while loading (the ROM jumped to SRAM already).
      // mode 1: the ROM waits for the mailbox; load WITHOUT resetting the CPU
      // (a CPU reset restarts the ROM, whose MBIST would clear SRAM again).
      if (jtag_scn == 3) begin jtag_ir(5'h11); jtag_dr(8, 128'h01, o); end
      sba(2'd1, 32'h4000_0000, 0, rd, e);
      $display("TB_SOC JTAG SBA CHIP_ID=%08x err=%0d", rd, e);
      if (rd !== mcu_memmap_pkg::CHIP_ID || e) jtag_errs++;
      sba(2'd1, 32'h3000_0000, 0, rd, e);
      if (!e) begin jtag_errs++; $display("TB_SOC JTAG SBA missing bus error"); end
      for (int i = 0; i < sram_words; i++) begin
        sba(2'd2, 32'h1000_0000 + 4 * i, sram_img[i], rd, e);
        if (e) jtag_errs++;
      end
      for (int i = 0; i < sram_words; i += 61) begin
        sba(2'd1, 32'h1000_0000 + 4 * i, 0, rd, e);
        if (rd !== sram_img[i]) jtag_errs++;
      end
      if (jtag_scn == 1) begin
        sba(2'd2, 32'h4000_0008, 32'h1000_0000, rd, e);              // SCRATCH0 = entry
        sba(2'd2, 32'h4000_000C, mcu_memmap_pkg::JTAG_GO, rd, e);    // SCRATCH1 = go
      end
      $display("TB_SOC JTAG image loaded (%0d words), errors=%0d", sram_words, jtag_errs);
      if (jtag_scn == 3) begin jtag_ir(5'h11); jtag_dr(8, 128'h00, o); end   // release CPU hold
    end
    if (jtag_scn == 2) begin
      wait (u_top.u_soc.u_sysctrl.lock_q === 1'b1);
      repeat (50) @(posedge clk);
      sba(2'd1, 32'h4000_0000, 0, rd, e);
      $display("TB_SOC JTAG after DBG_LOCK: SBA read err=%0d rdata=%08x", e, rd);
      if (!e || rd !== 32'd0) jtag_errs++;
      jtag_ir(5'h11); jtag_dr(8, 128'h01, o);                       // try to hold the CPU
      repeat (200) @(posedge clk);
      if (u_top.u_soc.cpu_rst_n !== 1'b1) begin jtag_errs++; $display("TB_SOC JTAG hold not blocked"); end
      jtag_ir(5'h01); jtag_dr(32, 128'd0, o);
      if (o[31:0] !== IDCODE) jtag_errs++;
      $display("TB_SOC JTAG debug-lock checks errors=%0d", jtag_errs);
    end
  end

  initial begin
    cyc = 0;
    @(posedge rst_n);
    while (!done && cyc < maxcyc) begin
      @(posedge clk);
      cyc++;
      if (jtag_errs != 0) begin
        $display("TB_SOC RESULT FAIL jtag_errors=%0d cycles=%0d", jtag_errs, cyc);
        done = 1;
      end else if (stop_hit) begin
        $display("TB_SOC RESULT PASS stop_on=\"%s\" cycles=%0d chars=%0d", stop_on, cyc, n_chars);
        done = 1;
      end else if (test_fail) begin
        repeat (200 * BAUD) @(posedge clk);
        if (expect_fail)
          $display("TB_SOC RESULT PASS expected-failure-detected status=%08x cycles=%0d", test_status, cyc);
        else
          $display("TB_SOC RESULT FAIL status=%08x cycles=%0d chars=%0d", test_status, cyc, n_chars);
        done = 1;
      end else if (test_pass) begin
        repeat (200 * BAUD) @(posedge clk);
        if (expect_fail)
          $display("TB_SOC RESULT FAIL expected a failure status=%08x", test_status);
        else
          $display("TB_SOC RESULT PASS status=%08x cycles=%0d chars=%0d", test_status, cyc, n_chars);
        done = 1;
      end
    end
    if (!done) $display("TB_SOC RESULT TIMEOUT cycles=%0d pc=%08x", cyc, u_top.u_soc.u_cpu.fb0_pc_q);
    if (logfd != 0) $fclose(logfd);
    $finish;
  end
endmodule

`default_nettype wire
