#!/usr/bin/env bash
# =============================================================================
# SilicaFlux MCU-I :: run the riscv-tests ISA suites on mcu_cpu
#
# usage: scripts/run_riscv_tests.sh <RV32M: 0|1|2> [RISCV_TESTS_DIR]
# env  : PROFILES="gnt%:maxlat ..." (default "100:1 70:2 40:4"), SEEDS="1 2"
#
# Suites: rv32ui + rv32mi always; rv32um when RV32M != 0.
# Each test runs on tb/cpu/tb_cpu.sv under several bus-backpressure profiles
# (random grant probability, random response latency, per seed).
# These are the riscv-software-src/riscv-tests self-checking ISA tests; they
# are NOT the RISC-V International architectural certification suite, and
# passing them is not a claim of RISC-V compliance.
# Derived from third_party/silicaflux-v/tb/cpu/run_riscv_tests.sh (clang ->
# GNU toolchain, rv32um added, M-dependent build).
# =============================================================================
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
M="${1:?usage: run_riscv_tests.sh <RV32M> [riscv-tests dir]}"
RT="${2:-${RISCV_TESTS:-$ROOT/deps/riscv-tests}}"
OUT="$ROOT/build/riscv-tests/m$M"; mkdir -p "$OUT"
REPORT="$ROOT/reports/sim/riscv_tests_m$M.txt"; mkdir -p "$(dirname "$REPORT")"
PREFIX="${RISCV_PREFIX:-riscv64-unknown-elf-}"
PROFILES="${PROFILES:-100:1 70:2 40:4}"
SEEDS="${SEEDS:-1 2}"

command -v ${PREFIX}gcc >/dev/null || { echo "ERROR: ${PREFIX}gcc not found (set RISCV_PREFIX)"; exit 2; }
command -v verilator >/dev/null || { echo "ERROR: verilator not found"; exit 2; }
[ -d "$RT/isa" ] || { echo "ERROR: riscv-tests not found at $RT (run scripts/fetch_deps.sh)"; exit 2; }

if [ "$M" = 0 ]; then MARCH=rv32i_zicsr_zifencei; SUITES="rv32ui rv32mi";
else MARCH=rv32im_zicsr_zifencei; SUITES="rv32ui rv32um rv32mi"; fi
CFLAGS="-march=$MARCH -mabi=ilp32 -static -mcmodel=medany -fvisibility=hidden -nostdlib -nostartfiles"

SIMDIR="$OUT/obj_dir"
verilator --binary --timing -Wno-fatal -Wno-WIDTH -O2 --top-module tb_cpu -GRV32M=$M \
  -Mdir "$SIMDIR" -o vtb_cpu "$ROOT/rtl/cpu/mcu_cpu.sv" "$ROOT/tb/cpu/tb_cpu.sv" \
  > "$OUT/verilator_build.log" 2>&1 || { tail -30 "$OUT/verilator_build.log"; exit 1; }
SIM="$SIMDIR/vtb_cpu"

# Excluded tests (documented in docs/VERIFICATION.md):
#   rv32ui/ma_data    hardware misaligned access is optional; mcu_cpu traps
#   rv32mi/pmpaddr    no PMP (not implemented in MCU-I)
#   rv32mi/breakpoint no debug trigger module (tselect/tdata*)
SKIP=" rv32ui/ma_data rv32mi/pmpaddr rv32mi/breakpoint "

pass=0; fail=0; : > "$REPORT"
{
  echo "# riscv-tests on mcu_cpu RV32M=$M  ($(date -u +%F' '%T) UTC)"
  echo "# riscv-tests commit: $(git -C "$RT" rev-parse HEAD 2>/dev/null)"
  echo "# toolchain: $(${PREFIX}gcc --version | head -1) ; -march=$MARCH -mabi=ilp32"
  echo "# simulator: $(verilator --version)"
  echo "# profiles (grant%:maxlatency): $PROFILES ; seeds: $SEEDS"
} >> "$REPORT"
for suite in $SUITES; do
  for src in "$RT"/isa/$suite/*.S; do
    t="$suite/$(basename "$src" .S)"
    case "$SKIP" in *" $t "*) echo "SKIP $t" >> "$REPORT"; continue;; esac
    elf="$OUT/${t//\//-}.elf"
    if ! ${PREFIX}gcc $CFLAGS -I"$RT/env/p" -I"$RT/isa/macros/scalar" -T"$RT/env/p/link.ld" \
         "$src" -o "$elf" > "$elf.log" 2>&1; then
      echo "BUILD-FAIL $t" | tee -a "$REPORT"; fail=$((fail+1)); continue
    fi
    ${PREFIX}objcopy -O binary "$elf" "$elf.bin"
    python3 "$ROOT/third_party/silicaflux-v/scripts/bin2hex.py" "$elf.bin" "$elf.hex" > /dev/null
    tohost=$(${PREFIX}nm "$elf" | awk '$3=="tohost"{print $1}')
    ok=1
    for prof in $PROFILES; do for seed in $SEEDS; do
      g=${prof%%:*}; l=${prof##*:}
      r=$("$SIM" +hex="$elf.hex" +tohost="$tohost" +gnt=$g +lat=$l +seed=$seed 2>&1 | grep "TB_CPU RESULT")
      case "$r" in *PASS*) ;; *) ok=0; echo "FAIL $t gnt=$g lat=$l seed=$seed : $r" >> "$REPORT";; esac
    done; done
    if [ $ok = 1 ]; then echo "PASS $t" >> "$REPORT"; pass=$((pass+1)); else echo "FAIL $t"; fail=$((fail+1)); fi
  done
done
echo "TOTAL pass=$pass fail=$fail" | tee -a "$REPORT"
[ $fail = 0 ]
