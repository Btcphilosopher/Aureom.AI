#!/usr/bin/env python3
"""Build an MCU-I boot image (header + payload) from a flat binary.

    mkimage.py <app.bin> <load> <entry> <out.img> [--flash-hex F] [--offset N]

Header (little-endian, 20 bytes): magic 0x4D434931 ("MCI1"), load address,
payload length (padded to a multiple of 4), entry address, CRC-32 (zlib /
ISO-HDLC) of the padded payload.  The CRC is an integrity check, not an
authentication mechanism (docs/SECURITY.md).
--flash-hex writes a byte-per-line $readmemh file of a flash image with the
boot image at --offset (default 0), erased bytes 0xFF, for the testbench SPI
NOR model and for flash programmers that accept hex.
"""
import argparse, struct, zlib

MAGIC = 0x4D434931


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("bin"); ap.add_argument("load"); ap.add_argument("entry"); ap.add_argument("out")
    ap.add_argument("--flash-hex"); ap.add_argument("--offset", default="0")
    ap.add_argument("--corrupt", action="store_true", help="flip one payload bit (negative test)")
    a = ap.parse_args()
    data = open(a.bin, "rb").read()
    data += b"\0" * ((-len(data)) % 4)
    load, entry = int(a.load, 0), int(a.entry, 0)
    crc = zlib.crc32(data) & 0xFFFFFFFF
    if a.corrupt:
        data = bytes([data[0] ^ 1]) + data[1:]
    img = struct.pack("<5I", MAGIC, load, len(data), entry, crc) + data
    open(a.out, "wb").write(img)
    if a.flash_hex:
        off = int(a.offset, 0)
        with open(a.flash_hex, "w") as f:
            f.write(f"@{off:x}\n")
            f.write("\n".join(f"{b:02x}" for b in img) + "\n")
    print(f"mkimage: {a.out} payload={len(data)} bytes crc=0x{crc:08x} load=0x{load:08x} entry=0x{entry:08x}"
          + (" (CORRUPTED)" if a.corrupt else ""))


if __name__ == "__main__":
    main()
