#!/usr/bin/env bash
# Fetch the external test/PDK collateral (not redistributed with MCU-I):
#   deps/riscv-tests                         riscv-software-src/riscv-tests (BSD-3-Clause)
#   deps/orfs/flow/platforms/{sky130hd,ihp-sg13g2,gf180}/{lib,lef}
#                                            OpenROAD-flow-scripts platform data (Apache-2.0 PDKs)
# Pinned commits are the ones used for the results in reports/.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p deps && cd deps
RT_COMMIT=3df703cd52d5f0d8224e3c50bf03c6cb70efff98
ENV_COMMIT=6de71edb142be36319e380ce782c3d1830c65d68
ORFS_COMMIT=3f8ab4ebeb3a886a88fc0774b176c77a18905718
if [ ! -d riscv-tests ]; then
  git clone https://github.com/riscv-software-src/riscv-tests riscv-tests
  git -C riscv-tests checkout $RT_COMMIT
  git -C riscv-tests submodule update --init env
  git -C riscv-tests/env checkout $ENV_COMMIT
fi
if [ ! -d orfs ]; then
  git clone --filter=blob:none --sparse https://github.com/The-OpenROAD-Project/OpenROAD-flow-scripts orfs
  git -C orfs checkout $ORFS_COMMIT
  git -C orfs sparse-checkout set flow/platforms/sky130hd/lib flow/platforms/sky130hd/lef \
    flow/platforms/ihp-sg13g2/lib flow/platforms/ihp-sg13g2/lef flow/platforms/gf180/lib
fi
echo "deps ready: export PLATFORMS=$PWD/orfs/flow/platforms"
