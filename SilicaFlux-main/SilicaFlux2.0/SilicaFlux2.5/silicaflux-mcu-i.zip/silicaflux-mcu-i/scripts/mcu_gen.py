#!/usr/bin/env python3
"""SilicaFlux MCU-I generator: memory map + configuration -> RTL/C/Python/docs.

    python3 scripts/mcu_gen.py [--check]

Inputs : configs/memmap.yaml, configs/basic.yaml, configs/industrial.yaml
Outputs: rtl/generated/mcu_memmap_pkg.sv
         rtl/generated/mcu_cfg_<variant>_pkg.sv      (package mcu_cfg_pkg)
         firmware/include/mcu_regs.h
         firmware/include/generated/mcu_config_<variant>.h
         firmware/include/generated/mcu_mem_<variant>.ld
         scripts/generated/mcu_map.py
         docs/MEMORY_MAP.md, docs/REGISTERS.md
--check : verify that the committed outputs are up to date (CI), exit 1 if not.

Validation (any failure aborts with a message, nothing is written):
  regions power-of-two sized, size-aligned, non-overlapping; pages unique and
  inside the peripheral window; masters/IRQs/DREQs unique; register offsets
  word-aligned, inside a 4 KiB page and non-overlapping (arrays/channels
  expanded); fields inside 32 bits and non-overlapping; reset values fit the
  declared fields; every `cfg:` flag exists in the variant configuration.
"""
import argparse
import os
import sys

import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VARIANTS = ["basic", "industrial"]
CFG_FLAGS_DERIVED = {"always"}


def die(msg):
    sys.exit("mcu_gen: ERROR: " + msg)


def bits(spec):
    s = str(spec)
    if ":" in s:
        hi, lo = (int(x) for x in s.split(":"))
    else:
        hi = lo = int(s)
    if not (0 <= lo <= hi <= 31):
        die(f"field bits {spec} outside 0..31")
    return hi, lo


def load():
    mm = yaml.safe_load(open(os.path.join(ROOT, "configs/memmap.yaml")))
    cfgs = {v: yaml.safe_load(open(os.path.join(ROOT, f"configs/{v}.yaml"))) for v in VARIANTS}
    return mm, cfgs


def expand_regs(block):
    """Yield (name, off, reg) with channel/array expansion for overlap checks."""
    ch = block.get("channels")
    for r in block["regs"]:
        n = r.get("array", 1)
        st = r.get("stride", 4)
        for i in range(n):
            off = r["offset"] + i * st
            if ch and r["offset"] < ch["stride"]:
                for c in range(8):     # maximum channel count checked
                    yield (f"{r['name']}[{c}]", off + c * ch["stride"], r)
            else:
                yield (r["name"] if n == 1 else f"{r['name']}[{i}]", off, r)


def validate(mm, cfgs):
    flags = set(CFG_FLAGS_DERIVED)
    for v, c in cfgs.items():
        flags |= {k for k in c["params"]}
    # regions
    regs = sorted(mm["regions"], key=lambda r: r["base"])
    for r in regs:
        if r["size"] & (r["size"] - 1):
            die(f"region {r['name']} size not a power of two")
        if r["base"] % r["size"]:
            die(f"region {r['name']} base not aligned to its size")
    for a, b in zip(regs, regs[1:]):
        if a["base"] + a["size"] > b["base"]:
            die(f"regions {a['name']} and {b['name']} overlap")
    per = next(r for r in mm["regions"] if r["name"] == "PERIPH")
    npages = per["size"] // mm["meta"]["page_size"]
    for key in ("pages", "masters", "interrupts", "dreqs"):
        seen_i, seen_n = set(), set()
        for e in mm[key]:
            if e["index"] in seen_i:
                die(f"duplicate {key} index {e['index']}")
            if e["name"] in seen_n:
                die(f"duplicate {key} name {e['name']}")
            seen_i.add(e["index"]); seen_n.add(e["name"])
            if e.get("cfg", "always") not in flags:
                die(f"{key} {e['name']}: unknown cfg flag {e['cfg']}")
    for p in mm["pages"]:
        if not 0 <= p["index"] < npages:
            die(f"page {p['name']} outside the peripheral window")
        if p["block"] not in mm["register_blocks"]:
            die(f"page {p['name']}: unknown block {p['block']}")
    if max(i["index"] for i in mm["interrupts"]) >= 16:
        die("interrupt index >= 16 (mcu_intc has 16 sources)")
    if max(d["index"] for d in mm["dreqs"]) >= 16 or min(d["index"] for d in mm["dreqs"]) < 1:
        die("DREQ index must be 1..15")
    # registers and fields
    for bn, b in mm["register_blocks"].items():
        used = {}
        for name, off, r in expand_regs(b):
            if off % 4 or off >= 0x1000:
                die(f"{bn}.{name}: offset 0x{off:x} not word aligned or outside the page")
            if off in used:
                die(f"{bn}: {name} overlaps {used[off]} at 0x{off:x}")
            used[off] = name
        for r in b["regs"]:
            mask = 0
            for f in r.get("fields", []):
                hi, lo = bits(f["bits"])
                m = ((1 << (hi - lo + 1)) - 1) << lo
                if mask & m:
                    die(f"{bn}.{r['name']}.{f['name']}: overlapping field")
                mask |= m
            if r.get("fields") and (r.get("reset", 0) & ~mask & 0xFFFFFFFF):
                die(f"{bn}.{r['name']}: reset 0x{r['reset']:x} has bits outside its fields")
    return True


# ----------------------------------------------------------------------------- emitters
def hdr(c="//"):
    return (f"{c} GENERATED by scripts/mcu_gen.py from configs/memmap.yaml and configs/<variant>.yaml\n"
            f"{c} -- do not edit; run `make mcu-gen`.\n")


def check_symbols(text):
    seen = set()
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("localparam"):
            name = line.split("=")[0].split()[-1]
            if name in seen:
                die(f"generated SystemVerilog symbol {name} is defined twice (rename a constant/register)")
            seen.add(name)
    return text


def emit_sv_pkg(mm):
    L = [hdr(), "// Package references are used inside module bodies only (Yosys 0.33 rule).",
         "`default_nettype none", "package mcu_memmap_pkg;", ""]
    for r in mm["regions"]:
        L.append(f"  localparam logic [31:0] {r['name']}_BASE = 32'h{r['base']:08X};")
        L.append(f"  localparam logic [31:0] {r['name']}_WINDOW = 32'h{r['size']:08X};")
    L.append("")
    for p in mm["pages"]:
        L.append(f"  localparam int PG_{p['name']} = {p['index']};")
    L.append(f"  localparam int NUM_PAGES = {max(p['index'] for p in mm['pages']) + 1};")
    L.append("")
    for m in mm["masters"]:
        L.append(f"  localparam int M_{m['name']} = {m['index']};")
    L.append("")
    for i in mm["interrupts"]:
        L.append(f"  localparam int IRQ_{i['name']} = {i['index']};")
    L.append("  localparam int NUM_IRQ = 16;")
    L.append("")
    for d in mm["dreqs"]:
        L.append(f"  localparam int DREQ_{d['name']} = {d['index']};")
    L.append("")
    for k, v in mm["constants"].items():
        w = 32 if v > 0xFFFF or k.endswith("KEY") or k.endswith("ID") or k in ("JTAG_GO", "IMG_MAGIC", "MIMPID") else 16
        if k == "JTAG_MFR":
            L.append(f"  localparam logic [10:0] {k} = 11'h{v:03X};")
        elif k == "JTAG_PART":
            L.append(f"  localparam logic [15:0] {k} = 16'h{v:04X};")
        else:
            L.append(f"  localparam logic [31:0] {k} = 32'h{v:08X};")
    for bn, b in mm["register_blocks"].items():
        P = bn.upper()
        L.append("")
        L.append(f"  // ---- {bn}: {b['desc']}")
        for r in b["regs"]:
            L.append(f"  localparam logic [11:0] {P}_{r['name']} = 12'h{r["offset"]:03X};")
            if "reset" in r:
                L.append(f"  localparam logic [31:0] {P}_{r['name']}_RST = 32'h{r['reset'] & 0xFFFFFFFF:08X};")
        if b.get("channels"):
            L.append(f"  localparam int {P}_CH_STRIDE = {b['channels']['stride']};")
    L += ["", "endpackage", "", "`default_nettype wire", ""]
    return "\n".join(L)


def emit_cfg_pkg(v, c):
    p = c["params"]
    L = [hdr(), f"// MCU-I {v.upper()} configuration.  Exactly one mcu_cfg_*_pkg.sv is compiled per build.",
         "`default_nettype none", "package mcu_cfg_pkg;", f"  localparam VARIANT = \"{v}\";"]
    for k, val in p.items():
        L.append(f"  localparam int {k} = {val};")
    L.append(f"  localparam int SRAM_BYTES = {p['SRAM_BANKS'] * p['BANK_WORDS'] * 4};")
    L += ["endpackage", "`default_nettype wire", ""]
    return "\n".join(L)


def emit_c_cfg(v, c):
    p = c["params"]
    L = ["/* " + hdr("").replace("\n", " ").strip() + " */", f"#ifndef MCU_CONFIG_H", "#define MCU_CONFIG_H",
         f"#define MCU_VARIANT \"{v}\"", f"#define MCU_VARIANT_{v.upper()} 1"]
    for k, val in p.items():
        L.append(f"#define MCU_CFG_{k} {val}")
    L.append(f"#define MCU_SRAM_SIZE {p['SRAM_BANKS'] * p['BANK_WORDS'] * 4}u")
    L.append(f"#define MCU_SRAM_BANK_SIZE {p['BANK_WORDS'] * 4}u")
    L.append(f"#define MCU_ROM_SIZE {p['ROM_WORDS'] * 4}u")
    L += ["#endif", ""]
    return "\n".join(L)


def emit_ld_mem(v, c):
    p = c["params"]
    return (f"/* {hdr('').strip()} */\n"
            f"MEMORY {{\n"
            f"  ROM  (rx)  : ORIGIN = 0x00000000, LENGTH = {p['ROM_WORDS'] * 4}\n"
            f"  SRAM (rwx) : ORIGIN = 0x10000000, LENGTH = {p['SRAM_BANKS'] * p['BANK_WORDS'] * 4}\n"
            f"}}\n")


def emit_c(mm):
    L = ["/* " + hdr("").replace("\n", " ").strip() + " */", "#ifndef MCU_REGS_H", "#define MCU_REGS_H",
         "#include <stdint.h>", "",
         "#define MCU_REG32(a) (*(volatile uint32_t *)(uintptr_t)(a))", ""]
    for r in mm["regions"]:
        L.append(f"#define MCU_{r['name']}_BASE 0x{r['base']:08X}u")
    per = next(r for r in mm["regions"] if r["name"] == "PERIPH")["base"]
    L.append("")
    for p in mm["pages"]:
        L.append(f"#define MCU_{p['name']}_BASE 0x{per + p['index'] * 0x1000:08X}u")
    L.append("")
    for i in mm["interrupts"]:
        L.append(f"#define MCU_IRQ_{i['name']} {i['index']}")
    L.append("")
    for d in mm["dreqs"]:
        L.append(f"#define MCU_DREQ_{d['name']} {d['index']}u")
    L.append("")
    for k, val in mm["constants"].items():
        L.append(f"#define MCU_{k} 0x{val:X}u")
    for bn, b in mm["register_blocks"].items():
        P = bn.upper()
        L.append("")
        L.append(f"/* ---- {bn}: {b['desc']} */")
        ch = b.get("channels")
        for r in b["regs"]:
            if ch and r["offset"] < ch["stride"]:
                L.append(f"#define {P}_{r['name']}_OFF(ch) (0x{r["offset"]:03X}u + (uint32_t)(ch) * 0x{ch['stride']:X}u)")
            elif r.get("array"):
                L.append(f"#define {P}_{r['name'].rstrip('0123456789')}_OFF(i) (0x{r["offset"]:03X}u + (uint32_t)(i) * {r.get('stride', 4)}u)")
            else:
                L.append(f"#define {P}_{r['name']}_OFF 0x{r["offset"]:03X}u")
            for f in r.get("fields", []):
                hi, lo = bits(f["bits"])
                nm = f"{P}_{r['name']}_{f['name']}"
                if hi == lo:
                    L.append(f"#define {nm} (1u << {lo})")
                else:
                    L.append(f"#define {nm}_SHIFT {lo}")
                    L.append(f"#define {nm}_MASK (0x{(1 << (hi - lo + 1)) - 1:X}u << {lo})")
    # per-instance accessors
    L.append("")
    L.append("/* ---- per-instance register accessors */")
    for p in mm["pages"]:
        b = mm["register_blocks"][p["block"]]
        P = p["block"].upper()
        ch = b.get("channels")
        for r in b["regs"]:
            if ch and r["offset"] < ch["stride"]:
                L.append(f"#define {p['name']}_{r['name']}(ch) MCU_REG32(MCU_{p['name']}_BASE + {P}_{r['name']}_OFF(ch))")
            elif r.get("array"):
                base = r['name'].rstrip('0123456789')
                L.append(f"#define {p['name']}_{base}(i) MCU_REG32(MCU_{p['name']}_BASE + {P}_{base}_OFF(i))")
            else:
                L.append(f"#define {p['name']}_{r['name']} MCU_REG32(MCU_{p['name']}_BASE + {P}_{r['name']}_OFF)")
    L += ["", "#endif", ""]
    return "\n".join(L)


def emit_py(mm, cfgs):
    per = next(r for r in mm["regions"] if r["name"] == "PERIPH")["base"]
    out = {"regions": {r["name"]: (r["base"], r["size"]) for r in mm["regions"]},
           "pages": {p["name"]: per + p["index"] * 0x1000 for p in mm["pages"]},
           "irq": {i["name"]: i["index"] for i in mm["interrupts"]},
           "dreq": {d["name"]: d["index"] for d in mm["dreqs"]},
           "const": mm["constants"],
           "regs": {bn: {r["name"]: r["offset"] for r in b["regs"]} for bn, b in mm["register_blocks"].items()},
           "fields": {bn: {r["name"]: {f["name"]: bits(f["bits"]) for f in r.get("fields", [])}
                           for r in b["regs"]} for bn, b in mm["register_blocks"].items()},
           "configs": {v: c["params"] for v, c in cfgs.items()}}
    return ("# " + hdr("").replace("\n", " ").strip() + "\n" +
            "\n".join(f"{k.upper()} = {repr(v)}" for k, v in out.items()) + "\n")


def emit_md_map(mm, cfgs):
    L = ["# MCU-I memory map", "", "Generated from `configs/memmap.yaml` by `scripts/mcu_gen.py` — do not edit.", "",
         "## Regions", "", "| Region | Base | Window | Kind | Access | Notes |", "|---|---|---|---|---|---|"]
    for r in mm["regions"]:
        L.append(f"| {r['name']} | `0x{r['base']:08X}` | {r['size'] // 1024} KiB | {r['kind']} | {r['access']} | {r.get('note', '')} |")
    L += ["", "Everything else is unmapped: any access returns a bus error (no aliasing).", "",
          "## Configured sizes", "", "| Variant | SRAM | ROM | GPIO | Timers | Features |", "|---|---|---|---|---|---|"]
    for v, c in cfgs.items():
        p = c["params"]
        feats = [k[4:] for k in ("HAS_UART1", "HAS_SPI1", "HAS_I2C", "HAS_PWM", "HAS_DMA", "HAS_DSP") if p[k]]
        feats += ["RV32M" if p["RV32M"] else "RV32I", "parity" if p["SRAM_PARITY"] else "no parity"]
        L.append(f"| {v.upper()} | {p['SRAM_BANKS'] * p['BANK_WORDS'] * 4 // 1024} KiB ({p['SRAM_BANKS']} banks) | "
                 f"{p['ROM_WORDS'] * 4 // 1024} KiB | {p['GPIO_N']} | {p['N_TIMER']} | {', '.join(feats)} |")
    per = next(r for r in mm["regions"] if r["name"] == "PERIPH")["base"]
    L += ["", "## Peripheral pages (4 KiB each)", "", "| Page | Base | Block | Present when | RTL |", "|---|---|---|---|---|"]
    for p in mm["pages"]:
        L.append(f"| {p['name']} | `0x{per + p['index'] * 0x1000:08X}` | {p['block']} | {p.get('cfg', 'always')} | "
                 f"`{mm['register_blocks'][p['block']]['rtl']}` |")
    L += ["", "Absent pages and unimplemented offsets return a bus error.", "",
          "## Bus masters", "", "| Index | Master | Present | Notes |", "|---|---|---|---|"]
    for m in mm["masters"]:
        L.append(f"| {m['index']} | {m['name']} | {m.get('cfg', 'always')} | {m.get('note', '')} |")
    L += ["", "## Interrupt sources (mcu_intc)", "", "| Index | Source | Present | Notes |", "|---|---|---|---|"]
    for i in mm["interrupts"]:
        L.append(f"| {i['index']} | {i['name']} | {i.get('cfg', 'always')} | {i.get('note', '')} |")
    L += ["", "Machine timer (MTI) and software interrupt (MSI) come from MTIMER directly.", "",
          "## DMA request lines", "", "| DREQ_SEL | Source | Present |", "|---|---|---|"]
    for d in mm["dreqs"]:
        L.append(f"| {d['index']} | {d['name']} | {d.get('cfg', 'always')} |")
    L += ["", "## Constants", "", "| Name | Value |", "|---|---|"]
    for k, v in mm["constants"].items():
        L.append(f"| {k} | `0x{v:X}` |")
    return "\n".join(L) + "\n"


def emit_md_regs(mm):
    L = ["# MCU-I register reference", "", "Generated from `configs/memmap.yaml` by `scripts/mcu_gen.py` — do not edit.", "",
         "All registers are 32 bits wide, word aligned, little-endian; access them with 32-bit loads/stores only.",
         "Reserved bits read as 0 and must be written as 0.  Access: RO read-only, RW read/write, WO write-only "
         "(reads 0), W1C write 1 to clear, W1S write 1 to set.  `domain: por` registers are reset only by the "
         "pin/power-on reset and survive soft and watchdog resets.", ""]
    for bn, b in mm["register_blocks"].items():
        L += [f"## {bn}", "", b["desc"], "", f"RTL: `{b['rtl']}`", ""]
        if b.get("channels"):
            L += [f"Channel registers (offset < 0x{b['channels']['stride']:X}) repeat every "
                  f"0x{b['channels']['stride']:X} bytes for each of the `{b['channels']['count_param']}` channels.", ""]
        L += ["| Offset | Register | Access | Reset | Description |", "|---|---|---|---|---|"]
        for r in b["regs"]:
            arr = f" ×{r['array']} (stride {r.get('stride', 4)})" if r.get("array") else ""
            dom = " (POR domain)" if r.get("domain") == "por" else ""
            L.append(f"| `0x{r["offset"]:03X}`{arr} | {r['name']} | {r['access']} | `0x{r.get('reset', 0) & 0xFFFFFFFF:X}` | "
                     f"{r.get('desc', '')}{dom} |")
            for f in r.get("fields", []):
                L.append(f"| | `[{f['bits']}]` {f['name']} | {f.get('access', r['access'])} | | {f.get('desc', '')} |")
        L.append("")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    mm, cfgs = load()
    validate(mm, cfgs)
    outs = {
        "rtl/generated/mcu_memmap_pkg.sv": check_symbols(emit_sv_pkg(mm)),
        "firmware/include/mcu_regs.h": emit_c(mm),
        "scripts/generated/mcu_map.py": emit_py(mm, cfgs),
        "docs/MEMORY_MAP.md": emit_md_map(mm, cfgs),
        "docs/REGISTERS.md": emit_md_regs(mm),
    }
    for v, c in cfgs.items():
        outs[f"rtl/generated/mcu_cfg_{v}_pkg.sv"] = emit_cfg_pkg(v, c)
        outs[f"firmware/include/generated/mcu_config_{v}.h"] = emit_c_cfg(v, c)
        outs[f"firmware/include/generated/mcu_mem_{v}.ld"] = emit_ld_mem(v, c)
    stale = []
    for path, text in outs.items():
        full = os.path.join(ROOT, path)
        if a.check:
            if not os.path.exists(full) or open(full).read() != text:
                stale.append(path)
            continue
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w") as f:
            f.write(text)
    if a.check:
        if stale:
            print("mcu_gen: STALE outputs:", ", ".join(stale))
            sys.exit(1)
        print(f"mcu_gen: {len(outs)} outputs up to date")
    else:
        print(f"mcu_gen: validated memory map ({len(mm['regions'])} regions, {len(mm['pages'])} pages, "
              f"{sum(len(b['regs']) for b in mm['register_blocks'].values())} registers); wrote {len(outs)} files")


if __name__ == "__main__":
    main()
