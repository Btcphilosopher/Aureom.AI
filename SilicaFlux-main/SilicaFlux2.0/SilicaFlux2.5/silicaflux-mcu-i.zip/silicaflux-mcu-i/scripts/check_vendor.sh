#!/usr/bin/env bash
# Verify that third_party/ is byte-identical to the recorded upstream files.
cd "$(dirname "$0")/../third_party" && sha256sum --quiet -c SHA256SUMS && echo "vendored files: OK ($(wc -l < SHA256SUMS) files)"
