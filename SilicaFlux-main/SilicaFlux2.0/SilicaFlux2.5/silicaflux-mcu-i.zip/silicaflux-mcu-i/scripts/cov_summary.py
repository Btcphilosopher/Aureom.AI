#!/usr/bin/env python3
"""Summarise a merged Verilator coverage file (coverage.dat format) per RTL file
and per coverage type.

usage: scripts/cov_summary.py <merged.dat> <variant> <n_scenarios>  > summary.txt

* A point is one Verilator coverage counter (line block, branch arm or toggle
  bit), counted per instance (two UART instances = two sets of points).
* covered = counter > 0 after merging all scenarios.
* Design total = files under rtl/ and third_party/.  Testbench files (tb/) are
  excluded; the generated boot-ROM image (build/.../mcu_bootrom_image.sv, a
  data table) is listed separately and excluded from the design total.
"""
import collections
import sys

path, variant, n = sys.argv[1], sys.argv[2], sys.argv[3]
TYPES = ("line", "branch", "toggle")
per = collections.defaultdict(lambda: {t: [0, 0] for t in TYPES})   # file -> type -> [covered, total]
for raw in open(path, errors="replace"):
    if not raw.startswith("C '"):
        continue
    key, cnt = raw[3:].rstrip("\n").rsplit("' ", 1)
    d = dict(f.split("\x02", 1) for f in key.split("\x01") if "\x02" in f)
    t = d.get("page", "").split("/")[0].replace("v_", "")
    if t not in TYPES:
        continue
    f = d.get("f", "?")
    per[f][t][1] += 1
    per[f][t][0] += int(cnt) > 0


def pct(c, t):
    return f"{100.0 * c / t:5.1f}%" if t else "    -"


def row(name, x):
    cells = " ".join(f"{x[t][0]:6d}/{x[t][1]:<6d} {pct(*x[t])}" for t in TYPES)
    return f"{name:76s} {cells}"


design = {f: x for f, x in per.items() if f.startswith(("rtl/", "third_party/"))}
other = {f: x for f, x in per.items() if f not in design}
print(f"# Verilator coverage, variant {variant}, {n} firmware scenarios merged (source: merged coverage.dat)")
print("# point = one coverage counter, per instance; covered = hit at least once in any scenario")
print("# design = rtl/ + third_party/; testbench and generated boot-ROM data excluded from the totals")
print(f"{'file':76s} {'line':>20s} {'branch':>20s} {'toggle':>20s}")
tot = {t: [0, 0] for t in TYPES}
for f in sorted(design):
    print(row(f, design[f]))
    for t in TYPES:
        tot[t][0] += design[f][t][0]
        tot[t][1] += design[f][t][1]
print(row("DESIGN TOTAL", tot))
allc = sum(tot[t][0] for t in TYPES)
allt = sum(tot[t][1] for t in TYPES)
print(f"TOTAL {allc}/{allt} {100.0 * allc / max(allt, 1):.1f}% (design, all types)")
for t in TYPES:
    print(f"TOTAL_{t.upper()} {tot[t][0]}/{tot[t][1]} {100.0 * tot[t][0] / max(tot[t][1], 1):.1f}%")
print("# excluded from the totals:")
for f in sorted(other):
    print(row(f, other[f]))
