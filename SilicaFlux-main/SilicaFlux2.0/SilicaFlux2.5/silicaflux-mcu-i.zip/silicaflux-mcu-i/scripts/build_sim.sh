#!/usr/bin/env bash
# Build the Verilator SoC simulator for one variant: build/<variant>/sim/vtb_mcu_soc
# usage: scripts/build_sim.sh <basic|industrial> [extra verilator args]
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
V="${1:?variant}"; shift || true
ROM=build/$V/mcu_bootrom_image.sv
CFG_PKG=${CFG_PKG:-rtl/generated/mcu_cfg_${V}_pkg.sv}   # override for experiments
SIMDIR=${SIMDIR:-build/$V/sim}
# MAIN_CPP: optional custom C++ main (coverage builds); default = Verilator --binary main
if [ -n "${MAIN_CPP:-}" ]; then MODE="--cc --exe --build --timing $ROOT/$MAIN_CPP"; else MODE="--binary --timing"; fi
[ -f "$ROM" ] || { echo "ERROR: $ROM missing (run: make -C firmware VARIANT=$V)"; exit 2; }
mkdir -p $SIMDIR
verilator $MODE --timescale 1ns/1ps -O2 -j 4 -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD \
  --top-module tb_mcu_soc -Mdir $SIMDIR/obj -o vtb_mcu_soc \
  +incdir+third_party/silicaflux-sramlib/rtl/mem +incdir+third_party/silicaflux-sramlib/rtl/mem/backends/asic \
  $CFG_PKG $(grep -v '^//' rtl/files.f) \
  third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_*.sv \
  third_party/silicaflux-sramlib/rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv \
  $ROM tb/models/spi_flash_model.sv tb/models/i2c_slave_model.sv tb/soc/tb_mcu_soc.sv "$@" \
  > $SIMDIR/build.log 2>&1 || { grep -E "%Error" $SIMDIR/build.log | head -30; exit 1; }
cp $SIMDIR/obj/vtb_mcu_soc $SIMDIR/vtb_mcu_soc
echo "built $SIMDIR/vtb_mcu_soc"
