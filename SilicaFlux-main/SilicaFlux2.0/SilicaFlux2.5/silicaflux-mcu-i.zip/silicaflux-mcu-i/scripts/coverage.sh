#!/usr/bin/env bash
# =============================================================================
# SilicaFlux MCU-I :: RTL line/toggle coverage of the SoC firmware regression
# usage: scripts/coverage.sh [variant]   (default industrial)
# Builds a Verilator --coverage simulator, runs every SoC scenario of
# scripts/soc_regress.sh, merges the coverage data and writes
# reports/coverage/<variant>_summary.txt (scripts/cov_summary.py: per RTL file, line/branch/toggle).
# Coverage is measured on the firmware-level regression only (unit tests run
# on Icarus and are not included).
# =============================================================================
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
V=${1:-industrial}
OUT=build/$V/cov; mkdir -p $OUT reports/coverage
make -s -C firmware VARIANT=$V > /dev/null || exit 1
MAIN_CPP=tb/soc/sim_main_cov.cpp SIMDIR=$OUT/sim scripts/build_sim.sh $V --coverage-line --coverage-toggle > /dev/null || exit 1
rm -rf $OUT/run_*
FW=build/fw/$V; SIM=$OUT/sim/vtb_mcu_soc
rm -f $OUT/*.dat
n=0
for img in $FW/*.flash.hex; do
  b=$(basename $img .flash.hex)
  case $b in hello_bad|hello_hi) continue;; esac
  args="+boot=0"; [ $b = 12_dbg_lock ] && args="+boot=0 +jtag=2"
  # tb/soc/sim_main_cov.cpp writes coverage.dat into the working directory
  mkdir -p $OUT/run_$b
  ( cd $OUT/run_$b && "$ROOT/$SIM" +flash="$ROOT/$img" $args +maxcyc=12000000 > ../$b.log 2>&1 )
  [ -f $OUT/run_$b/coverage.dat ] && cp $OUT/run_$b/coverage.dat $OUT/$b.dat
  grep -q "RESULT PASS" $OUT/$b.log && n=$((n+1)) || echo "warning: $b did not pass under coverage build"
done
verilator_coverage --write $OUT/merged.dat $OUT/*.dat > /dev/null
verilator_coverage --annotate $OUT/annotate --annotate-min 1 $OUT/merged.dat > $OUT/annotate.log 2>&1   # per-line view
python3 scripts/cov_summary.py $OUT/merged.dat $V $n > reports/coverage/${V}_summary.txt
grep -E '^TOTAL' reports/coverage/${V}_summary.txt
