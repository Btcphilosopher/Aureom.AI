#!/usr/bin/env bash
# =============================================================================
# SilicaFlux MCU-I :: SoC firmware regression (Verilator)
# usage: scripts/soc_regress.sh [variant ...]   (default: basic industrial)
# For each variant: builds firmware + simulator, runs every scenario, writes
# reports/sim/soc_<variant>.txt (+ per-scenario UART logs in build/) and
# exits non-zero if any scenario does not PASS.
# Scenario = name | firmware image | plusargs.  Every scenario boots through
# the real boot ROM (SPI flash unless the scenario tests another boot mode).
# =============================================================================
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
VARIANTS="${*:-basic industrial}"
mkdir -p reports/sim
overall=0
for V in $VARIANTS; do
  make -s -C firmware VARIANT=$V > build/fw_$V.log 2>&1 || { echo "firmware build failed ($V)"; tail build/fw_$V.log; exit 1; }
  scripts/build_sim.sh $V > /dev/null || exit 1
  FW=build/fw/$V
  SIM=build/$V/sim/vtb_mcu_soc
  LOGD=build/$V/sim/logs; mkdir -p $LOGD
  # derived images for boot-path tests
  python3 scripts/mkimage.py $FW/01_hello.bin 0x10000000 0x10000000 $FW/hello_bad.img \
    --flash-hex $FW/hello_bad.flash.hex --corrupt > /dev/null
  python3 scripts/mkimage.py $FW/01_hello.bin 0x10000000 0x10000000 $FW/hello_hi.img \
    --flash-hex $FW/hello_hi.flash.hex --offset 0x100000 > /dev/null
  python3 -c "import sys;d=open('$FW/01_hello.img','rb').read();open('$FW/hello_uart.hex','w').write('\n'.join('%02x'%b for b in d)+'\n')"
  python3 third_party/silicaflux-v/scripts/bin2hex.py $FW/01_hello.bin $FW/hello_sram.hex > /dev/null
  S=()
  S+=("hello_spi_boot|01_hello.flash.hex|+boot=0")
  S+=("gpio_blink|02_blink.flash.hex|+boot=0")
  S+=("timer_irq_lowpower|03_timer_irq.flash.hex|+boot=0")
  S+=("spi_loopback_modes|04_spi_loopback.flash.hex|+boot=0")
  S+=("watchdog_reset_recovery|07_watchdog.flash.hex|+boot=0")
  S+=("flash_boot_program_erase|09_flash_boot.flash.hex|+boot=0")
  S+=("dsp_fir|10_dsp_fir.flash.hex|+boot=0")
  S+=("fault_handling|11_faults.flash.hex|+boot=0")
  S+=("board_demo|demo.flash.hex|+boot=0")
  S+=("debug_lock|12_dbg_lock.flash.hex|+boot=0 +jtag=2")
  S+=("boot_flash_offset_1MiB|hello_hi.flash.hex|+boot=0")
  S+=("boot_corrupt_image_rejected|hello_bad.flash.hex|+boot=0 +expect_fail=1")
  NW=$(wc -l < $FW/hello_sram.hex); NB=$(wc -l < $FW/hello_uart.hex)
  S+=("boot_jtag_mailbox|-|+boot=1 +jtag=1 +sram=$FW/hello_sram.hex +sram_words=$NW")
  S+=("boot_uart|-|+boot=2 +uart_img=$FW/hello_uart.hex +uart_n=$NB")
  S+=("boot_sram_jtag_preload|-|+boot=3 +jtag=3 +sram=$FW/hello_sram.hex +sram_words=$NW")
  if [ "$V" = industrial ]; then
    S+=("i2c_eeprom_sensor|05_i2c.flash.hex|+boot=0")
    S+=("dma_copy_uart|06_dma_copy.flash.hex|+boot=0")
    S+=("pwm_capture_fault|08_pwm.flash.hex|+boot=0")
  fi
  REP=reports/sim/soc_$V.txt
  {
    echo "# MCU-I SoC firmware regression -- variant $V -- $(date -u +%F' '%T) UTC"
    echo "# $(verilator --version); $(riscv64-unknown-elf-gcc --version | head -1)"
    echo "# simulator: $SIM ; clock 10 ns ; UART 16 clk/bit"
  } > $REP
  pass=0; fail=0
  for s in "${S[@]}"; do
    IFS='|' read -r name img args <<< "$s"
    fl=""; [ "$img" != "-" ] && fl="+flash=$FW/$img"
    cmd="$SIM $fl $args +maxcyc=${MAXCYC:-12000000} +log=$LOGD/$name.uart.log"
    r=$($cmd 2>&1 | tee $LOGD/$name.sim.log | grep "TB_SOC RESULT" | head -1)
    case "$r" in *PASS*) pass=$((pass+1)); st=PASS;; *) fail=$((fail+1)); st=FAIL; overall=1;; esac
    printf "%-30s %s\n" "$name" "${r:-NO RESULT}" | tee -a $REP
    echo "    cmd: $cmd" >> $REP
  done
  echo "TOTAL $V pass=$pass fail=$fail" | tee -a $REP
done
exit $overall
