#!/usr/bin/env python3
"""Send an MCU-I boot image over UART to the boot ROM (boot mode 2).

    uart_load.py /dev/ttyUSB0 build/fw/industrial/demo.img [--baud 115200]

Reset the board with the UART-boot strap selected, wait for
"boot: waiting for UART image", then run this tool; it streams the raw image
(header + payload) and prints the console output that follows.  Requires
pyserial.  Not exercised on hardware in this release (FPGA.md).
"""
import argparse
import sys
import time

try:
    import serial
except ImportError:
    sys.exit("uart_load: pyserial is required (pip install pyserial)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("port"); ap.add_argument("image"); ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--listen", type=float, default=10.0, help="seconds to print console output afterwards")
    a = ap.parse_args()
    img = open(a.image, "rb").read()
    with serial.Serial(a.port, a.baud, timeout=0.1) as s:
        s.write(img)
        s.flush()
        print(f"uart_load: sent {len(img)} bytes", file=sys.stderr)
        t0 = time.time()
        while time.time() - t0 < a.listen:
            d = s.read(256)
            if d:
                sys.stdout.write(d.decode(errors="replace"))
                sys.stdout.flush()


if __name__ == "__main__":
    main()
