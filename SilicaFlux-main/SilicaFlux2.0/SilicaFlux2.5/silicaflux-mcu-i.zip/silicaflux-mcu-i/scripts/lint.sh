#!/usr/bin/env bash
# =============================================================================
# SilicaFlux MCU-I :: lint -- Verilator -Wall + Yosys elaboration / latch check
# usage: scripts/lint.sh [variant ...]   (default: basic industrial)
# Writes reports/lint/<variant>_verilator.log, <variant>_yosys.log, SUMMARY.txt
# Fails (exit 1) on any Verilator error, any Verilator warning outside the
# waiver list (scripts/lint_waivers.txt), or any latch other than the
# whitelisted ICG enable latch in sfv_clkgate.
# =============================================================================
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
VARIANTS="${*:-basic industrial}"
OUT=reports/lint; mkdir -p "$OUT" build/lint
for t in verilator yosys python3; do command -v $t >/dev/null || { echo "ERROR: $t not found"; exit 2; }; done
INC="+incdir+third_party/silicaflux-sramlib/rtl/mem +incdir+third_party/silicaflux-sramlib/rtl/mem/backends/asic"
EXTRA="third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_sky130.sv third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_gf180.sv third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp1p.sv third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp2p.sv third_party/silicaflux-sramlib/rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv"
FILES=$(grep -v '^//' rtl/files.f | tr '\n' ' ')
fail=0; : > $OUT/SUMMARY.txt
echo "# lint $(date -u +%F' '%T) UTC; $(verilator --version); $(yosys -V)" >> $OUT/SUMMARY.txt
for v in $VARIANTS; do
  ROM=build/$v/mcu_bootrom_image.sv
  if [ ! -f "$ROM" ]; then head -c 4 /dev/zero > build/lint/zero.bin
    python3 third_party/silicaflux-v/scripts/gen_rom.py build/lint/zero.bin build/lint/rom_$v.sv --words 2048 >/dev/null; ROM=build/lint/rom_$v.sv; fi
  verilator --lint-only -Wall -Wno-fatal -Wno-DECLFILENAME --top-module mcu_top $INC \
    rtl/generated/mcu_cfg_${v}_pkg.sv $FILES $EXTRA $ROM > $OUT/${v}_verilator.log 2>&1
  # keep only warnings that are not waived (waivers: file:message-substring)
  grep -E "^%(Warning|Error)" $OUT/${v}_verilator.log | sed "s|$ROOT/||" > build/lint/${v}_issues.txt
  errs=$(grep -c "^%Error" build/lint/${v}_issues.txt)
  unwaived=$(grep "^%Warning" build/lint/${v}_issues.txt | grep -v -F -f scripts/lint_waivers.txt | grep -c . )
  # Yosys: elaborate, flatten, look for latches
  yosys -q -l $OUT/${v}_yosys.log -p "read_verilog -defer -sv -D SYNTHESIS -I third_party/silicaflux-sramlib/rtl/mem -I third_party/silicaflux-sramlib/rtl/mem/backends/asic rtl/generated/mcu_cfg_${v}_pkg.sv $FILES $EXTRA $ROM; hierarchy -check -top mcu_top; proc; flatten; opt_clean; select -list t:\$dlatch t:\$adlatch t:\$dlatchsr; tee -o build/lint/${v}_latches.txt select -list t:\$dlatch t:\$adlatch t:\$dlatchsr" > /dev/null 2>&1
  yrc=$?
  nlat=$(grep -c . build/lint/${v}_latches.txt 2>/dev/null || echo 0)
  bad_lat=$(grep -v "u_cg\|cg_cpu\|en_l" build/lint/${v}_latches.txt 2>/dev/null | grep -c . )
  printf "%-11s verilator errors=%s unwaived_warnings=%s | yosys rc=%s latches=%s (unintended=%s)\n" $v $errs $unwaived $yrc $nlat $bad_lat | tee -a $OUT/SUMMARY.txt
  if [ "$errs" != 0 ] || [ "$unwaived" != 0 ] || [ $yrc != 0 ] || [ "$bad_lat" != 0 ]; then
    fail=1; grep "^%Warning" build/lint/${v}_issues.txt | grep -v -F -f scripts/lint_waivers.txt | head -40
  fi
done
[ $fail = 0 ] && echo "LINT PASS" | tee -a $OUT/SUMMARY.txt || { echo "LINT FAIL" | tee -a $OUT/SUMMARY.txt; exit 1; }
