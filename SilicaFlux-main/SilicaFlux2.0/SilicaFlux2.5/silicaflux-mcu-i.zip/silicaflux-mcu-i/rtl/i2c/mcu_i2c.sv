// =============================================================================
// SilicaFlux MCU-I :: mcu_i2c -- I2C master (new for MCU-I)
//
// Register map: docs/REGISTERS.md block `i2c`.  Byte-command interface:
//   CMD = {NACK, WRITE, READ, STOP, START}; one command = optional (repeated)
//   START, optional byte transfer (WRITE: TXDATA out + ACK in -> RX_NACK;
//   READ: byte in -> RXDATA + ACK/NACK out), optional STOP.  A 7-bit address
//   phase is a WRITE of {addr, r/w} after START.
// Pins: open-drain semantics only.  scl_oe/sda_oe = 1 pulls the line low;
//   0 releases it (external pull-up -> high).  The output data value is
//   always 0 and must be wired to an open-drain/tri-state pad cell
//   (ASIC: foundry I/O cell; FPGA: tri-state with pull-up).  The lines are
//   never driven high.
// Inputs: 2-flop synchroniser + glitch filter (a level change is accepted
//   after FILT consecutive equal samples, i.e. spikes shorter than FILT clk
//   cycles are suppressed).
// Timing: four phases of QTR = PRESCALE+1 clk cycles per bit (SCL low half =
//   2 phases, high half = 2 phases); PRESCALE values below 7 are treated as 7
//   so the input pipeline (output flop + 2-flop sync + filter) settles inside
//   one phase.  f_SCL ~= f_clk / (4*(PRESCALE+1)) (lower when stretched).
// Bus ownership: between START and STOP the idle engine keeps SCL low (and
//   SDA unchanged) so consecutive byte commands never create extra clocks.
// Clock stretching: after releasing SCL the engine waits until SCL is seen
//   high before timing the high phase.  With TIMEOUT != 0 a wait longer than
//   TIMEOUT clk cycles aborts the command: both lines released, TIMEOUT and
//   DONE set, BUS_BUSY cleared.
// ARB_LOST: while transmitting a 1 (SDA released) SDA is sampled low -> the
//   command aborts (lines released) with ARB_LOST and DONE set.  This is a
//   single-master controller; ARB_LOST indicates contention or a bus fault.
// =============================================================================
`default_nettype none

module mcu_i2c #(
  parameter int FILT = 4
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  input  wire logic        scl_i,
  input  wire logic        sda_i,
  output logic             scl_oe,
  output logic             sda_oe,
  output logic             irq,
  output logic             err_evt       // timeout / arbitration-lost / NACK event (pulse)
);
  localparam logic [11:0] A_PRE  = mcu_memmap_pkg::I2C_PRESCALE;
  localparam logic [11:0] A_CTRL = mcu_memmap_pkg::I2C_CTRL;
  localparam logic [11:0] A_CMD  = mcu_memmap_pkg::I2C_CMD;
  localparam logic [11:0] A_TX   = mcu_memmap_pkg::I2C_TXDATA;
  localparam logic [11:0] A_RX   = mcu_memmap_pkg::I2C_RXDATA;
  localparam logic [11:0] A_STAT = mcu_memmap_pkg::I2C_STATUS;
  localparam logic [11:0] A_TO   = mcu_memmap_pkg::I2C_TIMEOUT;

  // ------------------------------------------------------------ input filter
  logic scl_s, sda_s, scl_f, sda_f;
  sfv_sync #(.STAGES(2), .RESET_VAL(1'b1)) u_ss (.clk, .rst_n, .d(scl_i), .q(scl_s));
  sfv_sync #(.STAGES(2), .RESET_VAL(1'b1)) u_ds (.clk, .rst_n, .d(sda_i), .q(sda_s));
  localparam int FW = (FILT > 1) ? $clog2(FILT + 1) : 1;
  logic [FW-1:0] scl_fc, sda_fc;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      scl_f <= 1'b1; sda_f <= 1'b1; scl_fc <= '0; sda_fc <= '0;
    end else begin
      if (scl_s == scl_f) scl_fc <= '0;
      else if (scl_fc == FW'(FILT - 1)) begin scl_f <= scl_s; scl_fc <= '0; end
      else scl_fc <= scl_fc + 1'b1;
      if (sda_s == sda_f) sda_fc <= '0;
      else if (sda_fc == FW'(FILT - 1)) begin sda_f <= sda_s; sda_fc <= '0; end
      else sda_fc <= sda_fc + 1'b1;
    end
  end

  // ------------------------------------------------------------ registers
  logic [15:0] pre_q;
  logic        en_q, ien_q;
  logic [7:0]  tx_q, rx_q;
  logic        done_q, nack_q, to_q, bb_q, arb_q;
  logic [23:0] tmo_q;

  localparam logic [1:0] OP_IDLE = 2'd0, OP_START = 2'd1, OP_BYTE = 2'd2, OP_STOP = 2'd3;
  logic [1:0]  op_q, ph_q;
  logic [3:0]  bit_q;            // 0..7 data, 8 acknowledge
  logic [15:0] qcnt_q;
  logic [23:0] wcnt_q;           // stretch wait counter
  logic        c_stop, c_read, c_write, c_nack;
  logic [7:0]  sh_q;
  logic        scl_oe_n, sda_oe_n; // next output values (registered below)

  wire wr      = rb_sel && rb_we;
  wire busy    = (op_q != OP_IDLE);
  wire cmd_wr  = wr && rb_addr == A_CMD && !busy && en_q;
  wire [15:0] qtr = (pre_q < 16'd7) ? 16'd7 : pre_q;
  wire wait_hi = (ph_q == 2'd1) && !scl_f;            // SCL released, not yet high
  wire ph_end  = !wait_hi && (qcnt_q == qtr);
  wire timeout = wait_hi && (tmo_q != 24'd0) && (wcnt_q >= tmo_q);
  // bit currently transmitted by the master (1 = released)
  wire is_wbit = (op_q == OP_BYTE) && ((c_write && bit_q != 4'd8) || (c_read && bit_q == 4'd8));
  wire wbit    = (bit_q == 4'd8) ? c_nack : sh_q[7];
  wire arb_lost = (op_q == OP_BYTE) && is_wbit && wbit && (ph_q == 2'd2) && ph_end && !sda_f;

  // line control for the current (op, phase, bit)
  always_comb begin
    scl_oe_n = scl_oe;
    sda_oe_n = sda_oe;
    case (op_q)
      OP_START: case (ph_q)
        2'd0: sda_oe_n = 1'b0;                          // release SDA (SCL unchanged)
        2'd1: begin scl_oe_n = 1'b0; sda_oe_n = 1'b0; end
        2'd2: begin scl_oe_n = 1'b0; sda_oe_n = 1'b1; end   // SDA falls while SCL high
        default: begin scl_oe_n = 1'b1; sda_oe_n = 1'b1; end
      endcase
      OP_STOP: case (ph_q)
        2'd0: begin scl_oe_n = 1'b1; sda_oe_n = 1'b1; end
        2'd1: begin scl_oe_n = 1'b0; sda_oe_n = 1'b1; end
        default: begin scl_oe_n = 1'b0; sda_oe_n = 1'b0; end  // SDA rises while SCL high
      endcase
      OP_BYTE: case (ph_q)
        2'd0: begin scl_oe_n = 1'b1; sda_oe_n = is_wbit ? !wbit : 1'b0; end
        2'd1, 2'd2: scl_oe_n = 1'b0;
        default: scl_oe_n = 1'b1;
      endcase
      // idle: while the bus is owned (after START, before STOP) hold SCL low
      // and SDA unchanged between byte commands -- releasing SCL here would
      // generate a spurious clock pulse; otherwise release both lines
      default: begin scl_oe_n = bb_q; sda_oe_n = bb_q && sda_oe; end
    endcase
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pre_q <= mcu_memmap_pkg::I2C_PRESCALE_RST[15:0]; en_q <= 1'b0; ien_q <= 1'b0;
      tx_q <= '0; rx_q <= '0; done_q <= 1'b0; nack_q <= 1'b0; to_q <= 1'b0; bb_q <= 1'b0;
      arb_q <= 1'b0; tmo_q <= '0;
      op_q <= OP_IDLE; ph_q <= '0; bit_q <= '0; qcnt_q <= '0; wcnt_q <= '0;
      c_stop <= 1'b0; c_read <= 1'b0; c_write <= 1'b0; c_nack <= 1'b0; sh_q <= '0;
      scl_oe <= 1'b0; sda_oe <= 1'b0;
    end else begin
      scl_oe <= scl_oe_n;
      sda_oe <= sda_oe_n;
      if (wr) begin
        case (rb_addr)
          A_PRE:  pre_q <= rb_wdata[15:0];
          A_CTRL: begin en_q <= rb_wdata[0]; ien_q <= rb_wdata[1]; end
          A_TX:   tx_q  <= rb_wdata[7:0];
          A_STAT: begin
            if (rb_wdata[1]) done_q <= 1'b0;
            if (rb_wdata[3]) to_q   <= 1'b0;
            if (rb_wdata[5]) arb_q  <= 1'b0;
          end
          A_TO:   tmo_q <= rb_wdata[23:0];
          default: ;
        endcase
      end
      if (cmd_wr) begin
        c_stop <= rb_wdata[1]; c_read <= rb_wdata[2]; c_write <= rb_wdata[3] && !rb_wdata[2];
        c_nack <= rb_wdata[4];
        sh_q   <= tx_q; bit_q <= '0; ph_q <= '0; qcnt_q <= '0; wcnt_q <= '0;
        done_q <= 1'b0;
        if (rb_wdata[0])                     op_q <= OP_START;
        else if (rb_wdata[2] || rb_wdata[3]) op_q <= OP_BYTE;
        else if (rb_wdata[1])                op_q <= OP_STOP;
        else                                 done_q <= 1'b1;      // empty command
      end else if (busy) begin
        // phase timing (paused while waiting for SCL high)
        if (wait_hi) begin
          wcnt_q <= wcnt_q + 24'd1;
          qcnt_q <= '0;
        end else if (!ph_end) begin
          qcnt_q <= qcnt_q + 16'd1;
        end
        if (timeout || arb_lost) begin
          op_q <= OP_IDLE; done_q <= 1'b1; bb_q <= 1'b0;
          scl_oe <= 1'b0; sda_oe <= 1'b0;
          if (timeout) to_q  <= 1'b1;
          else         arb_q <= 1'b1;
        end else if (ph_end) begin
          qcnt_q <= '0;
          wcnt_q <= '0;
          ph_q   <= ph_q + 2'd1;
          // sample at the end of the SCL-high data phase
          if (op_q == OP_BYTE && ph_q == 2'd2 && !is_wbit) begin
            if (bit_q == 4'd8) nack_q <= sda_f;
            else               sh_q   <= {sh_q[6:0], sda_f};
          end
          if (ph_q == 2'd3) begin
            case (op_q)
              OP_START: begin
                bb_q <= 1'b1;
                if (c_read || c_write) op_q <= OP_BYTE;
                else if (c_stop)       op_q <= OP_STOP;
                else begin op_q <= OP_IDLE; done_q <= 1'b1; end
              end
              OP_BYTE: begin
                if (bit_q != 4'd8 && is_wbit) sh_q <= {sh_q[6:0], 1'b0};
                if (bit_q == 4'd8) begin
                  bit_q <= '0;
                  if (c_read) rx_q <= sh_q;
                  if (c_stop) op_q <= OP_STOP;
                  else begin op_q <= OP_IDLE; done_q <= 1'b1; end
                end else begin
                  bit_q <= bit_q + 4'd1;
                end
              end
              default: begin                  // OP_STOP
                bb_q <= 1'b0;
                op_q <= OP_IDLE; done_q <= 1'b1;
              end
            endcase
          end
        end
      end
    end
  end

  assign irq     = ien_q && (done_q || to_q || arb_q);
  wire unused_ok = ^rb_wdata[31:24];
  assign err_evt = timeout || arb_lost ||
                   (busy && ph_end && op_q == OP_BYTE && ph_q == 2'd2 && bit_q == 4'd8 && c_write && sda_f);

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      A_PRE:  rb_rdata = {16'd0, pre_q};
      A_CTRL: rb_rdata = {30'd0, ien_q, en_q};
      A_CMD:  begin rb_rdata = 32'd0; rb_err = rb_we && (busy || !en_q); end
      A_TX:   rb_rdata = {24'd0, tx_q};
      A_RX:   begin rb_rdata = {24'd0, rx_q}; rb_err = rb_we; end
      A_STAT: rb_rdata = {26'd0, arb_q, bb_q, to_q, nack_q, done_q, busy};
      A_TO:   rb_rdata = {8'd0, tmo_q};
      default: rb_err = 1'b1;
    endcase
  end
endmodule

`default_nettype wire
