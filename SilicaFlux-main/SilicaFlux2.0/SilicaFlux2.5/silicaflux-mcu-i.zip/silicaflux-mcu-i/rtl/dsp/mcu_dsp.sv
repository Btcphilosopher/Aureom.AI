// =============================================================================
// SilicaFlux MCU-I :: mcu_dsp -- integer DSP / MAC accelerator (new, optional)
//
// Register map: docs/REGISTERS.md block `dsp`.  One shared 16x16 signed
// multiplier, a 32-bit accumulator and a 16-tap FIR engine.
//   MAC   {x,y}        ACC  += x*y                      (1 execute cycle)
//   DOT2  {bh,bl}      ACC  += OPA.lo*bl + OPA.hi*bh    (2 execute cycles)
//   MULQ  {x,y}        RESULT = sat16(rnd((x*y) >>> 15)) (Q15 multiply)
//   SADD  {x,y}        RESULT = sat16(x + y)
//   ACC_Q (read)       sat16(rnd(ACC >>> SHIFT))
//   FIR_IN sample      delay line shift, then FIR_OUT = sum_{i<NTAPS} COEF[i]*x[n-i]
//                      (NTAPS execute cycles, BUSY)
// Arithmetic: accumulations are 32-bit; an accumulation overflow sets the
// sticky STATUS.OVF and, with CTRL.SAT, clamps to 0x7FFF_FFFF / 0x8000_0000
// (otherwise wraps).  Q15/SADD/ACC_Q saturate to 16 bits (OVF on clamp in
// MULQ/SADD).  CTRL.ROUND adds 2^(s-1) before an s-bit right shift
// (round half up), otherwise truncates (floor).
// Timing: a command write is registered and executed in the following
// cycle(s); a CPU load issued after the store observes the result (>= 2
// cycles later).  Command/config writes while BUSY return a bus error and
// are ignored (deterministic).  Results match the C reference model in
// firmware/drivers/mcu_dsp.c and tb/models/dsp_ref.py bit-exactly.
// Evaluation (docs/DSP.md): SilicaFlux-V sfv_vec_engine (4x32-bit SIMD tied
// to the tile scratchpad) and the repository dsp_arithmetic library were
// assessed first; neither fits a register-mapped MCU accelerator without the
// scratchpad / wildcard-import dependencies, so this block is new.
// =============================================================================
`default_nettype none

module mcu_dsp #(
  parameter int NTAPS_MAX = 16
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err
);
  localparam logic [11:0] A_CTRL  = mcu_memmap_pkg::DSP_CTRL;
  localparam logic [11:0] A_STAT  = mcu_memmap_pkg::DSP_STATUS;
  localparam logic [11:0] A_ACC   = mcu_memmap_pkg::DSP_ACC;
  localparam logic [11:0] A_OPA   = mcu_memmap_pkg::DSP_OPA;
  localparam logic [11:0] A_MAC   = mcu_memmap_pkg::DSP_MAC;
  localparam logic [11:0] A_DOT2  = mcu_memmap_pkg::DSP_DOT2;
  localparam logic [11:0] A_MULQ  = mcu_memmap_pkg::DSP_MULQ;
  localparam logic [11:0] A_SADD  = mcu_memmap_pkg::DSP_SADD;
  localparam logic [11:0] A_RES   = mcu_memmap_pkg::DSP_RESULT;
  localparam logic [11:0] A_ACCQ  = mcu_memmap_pkg::DSP_ACC_Q;
  localparam logic [11:0] A_FCTRL = mcu_memmap_pkg::DSP_FIR_CTRL;
  localparam logic [11:0] A_FIN   = mcu_memmap_pkg::DSP_FIR_IN;
  localparam logic [11:0] A_FOUT  = mcu_memmap_pkg::DSP_FIR_OUT;
  localparam logic [11:0] A_FOUTQ = mcu_memmap_pkg::DSP_FIR_OUT_Q;
  localparam logic [11:0] A_COEF0 = mcu_memmap_pkg::DSP_COEF0;

  localparam logic [2:0] OP_NONE = 3'd0, OP_MAC = 3'd1, OP_DOTL = 3'd2, OP_DOTH = 3'd3,
                         OP_MULQ = 3'd4, OP_SADD = 3'd5;

  logic        sat_q, rnd_q, ovf_q;
  logic [4:0]  shift_q;
  logic [31:0] acc_q, opa_q, res_q, fir_q;
  logic [3:0]  ntm1_q;
  logic [2:0]  op_q;
  logic [15:0] a_q, b_q, bh_q;
  logic [15:0] coef_q [0:NTAPS_MAX-1];
  logic [15:0] dl_q   [0:NTAPS_MAX-1];
  logic        fir_run_q;
  logic [3:0]  fidx_q;

  wire wr       = rb_sel && rb_we;
  wire busy     = (op_q != OP_NONE) || fir_run_q;
  wire is_coef  = (rb_addr >= A_COEF0) && (rb_addr < A_COEF0 + 12'(4 * NTAPS_MAX));
  wire [3:0] cidx = rb_addr[5:2];
  wire is_cmd   = (rb_addr == A_MAC) || (rb_addr == A_DOT2) || (rb_addr == A_MULQ) ||
                  (rb_addr == A_SADD) || (rb_addr == A_FIN) || (rb_addr == A_ACC) ||
                  (rb_addr == A_FCTRL) || (rb_addr == A_OPA) || (rb_addr == A_CTRL) || is_coef;
  wire wr_ok    = wr && !(busy && is_cmd);

  // ------------------------------------------------------------ shared datapath
  wire signed [15:0] ma = fir_run_q ? $signed(coef_q[fidx_q]) : $signed(a_q);
  wire signed [15:0] mb = fir_run_q ? $signed(dl_q[fidx_q])   : $signed(b_q);
  wire signed [31:0] prod = ma * mb;

  function automatic logic [32:0] add_sat(input logic [31:0] x, input logic [31:0] y, input logic sat);
    // returns {overflow, result}
    logic [31:0] s;
    logic        o;
    s = x + y;
    o = (x[31] == y[31]) && (s[31] != x[31]);
    if (o && sat) s = x[31] ? 32'h8000_0000 : 32'h7FFF_FFFF;
    add_sat = {o, s};
  endfunction
  function automatic logic [16:0] sat16(input logic signed [33:0] v);
    // returns {clamped, value}
    if (v > 34'sd32767)       sat16 = {1'b1, 16'h7FFF};
    else if (v < -34'sd32768) sat16 = {1'b1, 16'h8000};
    else                      sat16 = {1'b0, v[15:0]};
  endfunction
  function automatic logic signed [33:0] shr(input logic signed [31:0] v, input logic [4:0] s, input logic rnd);
    logic signed [33:0] t;
    t = {{2{v[31]}}, v};
    if (rnd && s != 5'd0) t = t + (34'sd1 <<< (s - 5'd1));
    shr = t >>> s;
  endfunction

  wire [32:0] acc_add = add_sat(acc_q, prod, sat_q);
  wire [32:0] fir_add = add_sat((fidx_q == 4'd0) ? 32'd0 : fir_q, prod, sat_q);
  wire [16:0] mulq_v  = sat16(shr(prod, 5'd15, rnd_q));
  wire [16:0] sadd_v  = sat16({{18{a_q[15]}}, a_q} + {{18{b_q[15]}}, b_q});
  wire [16:0] accq_v  = sat16(shr(acc_q, shift_q, rnd_q));
  wire [16:0] firq_v  = sat16(shr(fir_q, shift_q, rnd_q));

  integer k;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sat_q <= 1'b0; rnd_q <= 1'b0; ovf_q <= 1'b0; shift_q <= '0;
      acc_q <= '0; opa_q <= '0; res_q <= '0; fir_q <= '0; ntm1_q <= '0;
      op_q <= OP_NONE; a_q <= '0; b_q <= '0; bh_q <= '0;
      fir_run_q <= 1'b0; fidx_q <= '0;
    end else begin
      // ---- execute stage
      case (op_q)
        OP_MAC:  begin acc_q <= acc_add[31:0]; ovf_q <= ovf_q | acc_add[32]; op_q <= OP_NONE; end
        OP_DOTL: begin acc_q <= acc_add[31:0]; ovf_q <= ovf_q | acc_add[32];
                       a_q <= opa_q[31:16]; b_q <= bh_q; op_q <= OP_DOTH; end
        OP_DOTH: begin acc_q <= acc_add[31:0]; ovf_q <= ovf_q | acc_add[32]; op_q <= OP_NONE; end
        OP_MULQ: begin res_q <= {{16{mulq_v[15]}}, mulq_v[15:0]}; ovf_q <= ovf_q | mulq_v[16]; op_q <= OP_NONE; end
        OP_SADD: begin res_q <= {{16{sadd_v[15]}}, sadd_v[15:0]}; ovf_q <= ovf_q | sadd_v[16]; op_q <= OP_NONE; end
        default: ;
      endcase
      if (fir_run_q) begin
        fir_q <= fir_add[31:0];
        ovf_q <= ovf_q | fir_add[32];
        if (fidx_q == ntm1_q) fir_run_q <= 1'b0;
        else                  fidx_q    <= fidx_q + 4'd1;
      end
      // ---- register writes / command issue
      if (wr_ok) begin
        case (rb_addr)
          A_CTRL:  begin sat_q <= rb_wdata[0]; rnd_q <= rb_wdata[1]; shift_q <= rb_wdata[12:8]; end
          A_STAT:  if (rb_wdata[0]) ovf_q <= 1'b0;
          A_ACC:   acc_q <= rb_wdata;
          A_OPA:   opa_q <= rb_wdata;
          A_MAC:   begin a_q <= rb_wdata[31:16]; b_q <= rb_wdata[15:0]; op_q <= OP_MAC; end
          A_DOT2:  begin a_q <= opa_q[15:0]; b_q <= rb_wdata[15:0]; bh_q <= rb_wdata[31:16]; op_q <= OP_DOTL; end
          A_MULQ:  begin a_q <= rb_wdata[31:16]; b_q <= rb_wdata[15:0]; op_q <= OP_MULQ; end
          A_SADD:  begin a_q <= rb_wdata[31:16]; b_q <= rb_wdata[15:0]; op_q <= OP_SADD; end
          A_FCTRL: ntm1_q <= rb_wdata[3:0];
          A_FIN:   begin fir_run_q <= 1'b1; fidx_q <= 4'd0; end
          default: ;
        endcase
      end
    end
  end

  // coefficient and delay-line storage (datapath, reset by CLEAR / not reset)
  always_ff @(posedge clk) begin
    if (wr_ok && is_coef) coef_q[cidx] <= rb_wdata[15:0];
    if (wr_ok && rb_addr == A_FCTRL && rb_wdata[8]) begin
      for (k = 0; k < NTAPS_MAX; k = k + 1) dl_q[k] <= 16'd0;
    end else if (wr_ok && rb_addr == A_FIN) begin
      dl_q[0] <= rb_wdata[15:0];
      for (k = 1; k < NTAPS_MAX; k = k + 1) dl_q[k] <= dl_q[k-1];
    end
  end

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = wr && busy && is_cmd;
    if (is_coef) begin
      rb_rdata = {{16{coef_q[cidx][15]}}, coef_q[cidx]};
    end else begin
      case (rb_addr)
        A_CTRL:  rb_rdata = {19'd0, shift_q, 6'd0, rnd_q, sat_q};
        A_STAT:  rb_rdata = {30'd0, busy, ovf_q};
        A_ACC:   rb_rdata = acc_q;
        A_OPA:   rb_rdata = opa_q;
        A_MAC, A_DOT2, A_MULQ, A_SADD, A_FIN: rb_rdata = 32'd0;
        A_RES:   begin rb_rdata = res_q; rb_err = rb_we; end
        A_ACCQ:  begin rb_rdata = {{16{accq_v[15]}}, accq_v[15:0]}; rb_err = rb_we; end
        A_FCTRL: rb_rdata = {28'd0, ntm1_q};
        A_FOUT:  begin rb_rdata = fir_q; rb_err = rb_we; end
        A_FOUTQ: begin rb_rdata = {{16{firq_v[15]}}, firq_v[15:0]}; rb_err = rb_we; end
        default: rb_err = 1'b1;
      endcase
    end
  end
  wire unused_ok = accq_v[16] ^ firq_v[16];
endmodule

`default_nettype wire
