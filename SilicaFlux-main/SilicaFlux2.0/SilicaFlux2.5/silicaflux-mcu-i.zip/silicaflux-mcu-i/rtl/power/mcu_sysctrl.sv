// =============================================================================
// SilicaFlux MCU-I :: mcu_sysctrl -- system control, reset supervision,
// clock enables (PMU), debug lock and SRAM parity control
//
// Derived from third_party/silicaflux-v/rtl/periph/sfv_sysctrl.sv (register
// layout 0x00..0x30 kept, MBIST group select and tile clock-gate removed).
// New for MCU-I: watchdog reset generator and reset-cause recording, boot
// status, feature/size discovery, debug lock, per-peripheral clock enables,
// CPU sleep clock gate enable, SRAM parity control.  Register map:
// docs/REGISTERS.md (generated from configs/memmap.yaml, block `sysctrl`).
//
// Reset domains
//   por_rst_n (pin/power-on, synchronised): RESET_CAUSE, WDT_COUNT,
//     BOOT_STATUS, DBG_LOCK and the reset-pulse generator.  These survive
//     soft and watchdog resets so firmware can diagnose why it restarted.
//   rst_n (system reset): everything else.
// Reset requests -> sys_reset_req: an 8-cycle pulse (generator on por_rst_n)
//   started by a keyed SOFT_RESET write or by the rising edge of wdt_req.
//   The JTAG system-reset request is applied directly by the reset
//   controller in mcu_soc; it is only recorded here.
// =============================================================================
`default_nettype none

module mcu_sysctrl #(
  parameter logic [31:0] FEATURES  = 32'h0,
  parameter logic [31:0] SRAM_SIZE = 32'h0
) (
  input  wire logic        clk,
  input  wire logic        rst_n,        // system reset
  input  wire logic        por_rst_n,    // pin reset (survives soft/WDT reset)
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  input  wire logic [1:0]  boot_straps,
  input  wire logic        jtag_srst,    // JTAG system reset request (level)
  input  wire logic        wdt_req,      // watchdog reset request (level, sys domain)
  input  wire logic        cpu_sleep,
  // bus error capture
  input  wire logic        berr_evt,
  input  wire logic [31:0] berr_addr,
  input  wire logic [1:0]  berr_master,
  input  wire logic        berr_we,
  // MBIST
  output logic             mbist_start,
  output logic             mbist_bg,
  input  wire logic        mbist_busy,
  input  wire logic        mbist_done,
  input  wire logic        mbist_fail,
  input  wire logic [3:0]  mbist_fail_bank,
  input  wire logic [2:0]  mbist_fail_elem,
  input  wire logic [15:0] mbist_fail_addr,
  // parity
  output logic             par_chk_en,
  output logic             par_inject,
  input  wire logic        par_inject_done,
  // outputs
  output logic             sys_reset_req,  // to reset controller (8-cycle pulse)
  output logic [8:0]       clk_en,         // peripheral clock enables
  output logic             cpu_sleep_cg,   // gate the CPU clock in WFI
  output logic             dbg_locked,
  output logic             wdt_reset_seen, // a watchdog reset occurred (fault log)
  output logic             test_pass,
  output logic             test_fail,
  output logic [31:0]      test_status,
  output logic             irq_berr,
  output logic             irq_mbist,
  output logic             irq_dbg
);
  localparam logic [11:0] A_CHIP_ID      = mcu_memmap_pkg::SYSCTRL_CHIP_ID;
  localparam logic [11:0] A_BOOT_MODE    = mcu_memmap_pkg::SYSCTRL_BOOT_MODE;
  localparam logic [11:0] A_SCRATCH0     = mcu_memmap_pkg::SYSCTRL_SCRATCH0;
  localparam logic [11:0] A_SCRATCH1     = mcu_memmap_pkg::SYSCTRL_SCRATCH1;
  localparam logic [11:0] A_TEST_STATUS  = mcu_memmap_pkg::SYSCTRL_TEST_STATUS;
  localparam logic [11:0] A_SOFT_RESET   = mcu_memmap_pkg::SYSCTRL_SOFT_RESET;
  localparam logic [11:0] A_RESET_CAUSE  = mcu_memmap_pkg::SYSCTRL_RESET_CAUSE;
  localparam logic [11:0] A_CLK_EN       = mcu_memmap_pkg::SYSCTRL_CLK_EN;
  localparam logic [11:0] A_BUSERR_ADDR  = mcu_memmap_pkg::SYSCTRL_BUSERR_ADDR;
  localparam logic [11:0] A_BUSERR_INFO  = mcu_memmap_pkg::SYSCTRL_BUSERR_INFO;
  localparam logic [11:0] A_MBIST_CTRL   = mcu_memmap_pkg::SYSCTRL_MBIST_CTRL;
  localparam logic [11:0] A_MBIST_STATUS = mcu_memmap_pkg::SYSCTRL_MBIST_STATUS;
  localparam logic [11:0] A_DOORBELL     = mcu_memmap_pkg::SYSCTRL_DOORBELL;
  localparam logic [11:0] A_BOOT_STATUS  = mcu_memmap_pkg::SYSCTRL_BOOT_STATUS;
  localparam logic [11:0] A_FEATURES     = mcu_memmap_pkg::SYSCTRL_FEATURES;
  localparam logic [11:0] A_SRAM_SIZE    = mcu_memmap_pkg::SYSCTRL_SRAM_SIZE;
  localparam logic [11:0] A_DBG_LOCK     = mcu_memmap_pkg::SYSCTRL_DBG_LOCK;
  localparam logic [11:0] A_PARITY_CTRL  = mcu_memmap_pkg::SYSCTRL_PARITY_CTRL;
  localparam logic [11:0] A_PMU_STATUS   = mcu_memmap_pkg::SYSCTRL_PMU_STATUS;

  wire wr = rb_sel && rb_we;
  logic [1:0]  boot_q, strap_cnt;
  logic [31:0] scr0_q, scr1_q, tst_q, beaddr_q;
  logic        bev_q, bewe_q, mbg_q, mien_q, db_q, mstart_q, pchk_q, pinj_q, cg_cpu_q;
  logic [1:0]  bem_q;
  logic [8:0]  clken_q;

  // ------------------------------------------------------------ system domain
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      boot_q <= 2'b00; strap_cnt <= 2'd0;
      scr0_q <= '0; scr1_q <= '0; tst_q <= '0; beaddr_q <= '0;
      bev_q  <= 1'b0; bewe_q <= 1'b0; bem_q <= '0;
      mbg_q  <= 1'b0; mien_q <= 1'b0; db_q <= 1'b0; mstart_q <= 1'b0;
      pchk_q <= 1'b0; pinj_q <= 1'b0;
      clken_q <= 9'h1FF; cg_cpu_q <= 1'b0;
    end else begin
      mstart_q <= wr && rb_addr == A_MBIST_CTRL && rb_wdata[0];
      // straps (synchronised at the SoC top) sampled once, 3 cycles after
      // reset release, then held (no asynchronous data load; scan-safe)
      if (strap_cnt != 2'd3) begin
        strap_cnt <= strap_cnt + 2'd1;
        boot_q    <= boot_straps;
      end
      if (berr_evt && !bev_q) begin
        bev_q <= 1'b1; beaddr_q <= berr_addr; bem_q <= berr_master; bewe_q <= berr_we;
      end
      if (par_inject_done) pinj_q <= 1'b0;
      if (wr) begin
        case (rb_addr)
          A_SCRATCH0:    scr0_q <= rb_wdata;
          A_SCRATCH1:    scr1_q <= rb_wdata;
          A_TEST_STATUS: tst_q  <= rb_wdata;
          A_CLK_EN:      begin clken_q <= rb_wdata[8:0]; cg_cpu_q <= rb_wdata[16]; end
          A_BUSERR_INFO: if (rb_wdata[0]) bev_q <= 1'b0;
          A_MBIST_CTRL:  begin mbg_q <= rb_wdata[1]; mien_q <= rb_wdata[8]; end
          A_DOORBELL:    db_q <= rb_wdata[0];
          A_PARITY_CTRL: begin pchk_q <= rb_wdata[0]; pinj_q <= rb_wdata[1]; end
          default: ;
        endcase
      end
    end
  end

  // ------------------------------------------------------------ POR domain
  logic [3:0]  srst_cnt;
  logic [3:0]  cause_q;          // [0] POR [1] SOFT [2] JTAG [3] WDT
  logic [7:0]  wdt_cnt_q;
  logic [31:0] boot_st_q;
  logic        lock_q, wdt_req_q, jtag_q;
  wire soft_req  = wr && rb_addr == A_SOFT_RESET && rb_wdata == mcu_memmap_pkg::SOFT_RESET_KEY;
  wire wdt_rise  = wdt_req && !wdt_req_q;
  wire jtag_rise = jtag_srst && !jtag_q;
  always_ff @(posedge clk or negedge por_rst_n) begin
    if (!por_rst_n) begin
      srst_cnt  <= '0;
      cause_q   <= 4'b0001;
      wdt_cnt_q <= '0;
      boot_st_q <= '0;
      lock_q    <= 1'b0;
      wdt_req_q <= 1'b0;
      jtag_q    <= 1'b0;
    end else begin
      wdt_req_q <= wdt_req;
      jtag_q    <= jtag_srst;
      if (wr && rb_addr == A_RESET_CAUSE) cause_q <= cause_q & ~rb_wdata[3:0];
      if (soft_req || wdt_rise) srst_cnt <= 4'd8;
      else if (srst_cnt != 4'd0) srst_cnt <= srst_cnt - 4'd1;
      if (soft_req)  cause_q[1] <= 1'b1;
      if (jtag_rise) cause_q[2] <= 1'b1;
      if (wdt_rise) begin
        cause_q[3] <= 1'b1;
        if (wdt_cnt_q != 8'hFF) wdt_cnt_q <= wdt_cnt_q + 8'd1;
      end
      if (wr && rb_addr == A_BOOT_STATUS) boot_st_q <= rb_wdata;
      if (wr && rb_addr == A_DBG_LOCK && rb_wdata == mcu_memmap_pkg::DBG_LOCK_KEY) lock_q <= 1'b1;
    end
  end
  assign sys_reset_req  = (srst_cnt != 4'd0);
  assign wdt_reset_seen = cause_q[3];

  assign mbist_start  = mstart_q;
  assign mbist_bg     = mbg_q;
  assign par_chk_en   = pchk_q;
  assign par_inject   = pinj_q;
  assign clk_en       = clken_q;
  assign cpu_sleep_cg = cg_cpu_q;
  assign dbg_locked   = lock_q;
  assign test_status  = tst_q;
  assign test_pass    = (tst_q[1:0] == 2'd1);
  assign test_fail    = (tst_q[1:0] == 2'd2);
  assign irq_berr     = bev_q;
  assign irq_mbist    = mien_q && mbist_done;
  assign irq_dbg      = db_q;

  // ------------------------------------------------------------ read / error
  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      A_CHIP_ID:      begin rb_rdata = mcu_memmap_pkg::CHIP_ID; rb_err = rb_we; end
      A_BOOT_MODE:    begin rb_rdata = {30'd0, boot_q}; rb_err = rb_we; end
      A_SCRATCH0:     rb_rdata = scr0_q;
      A_SCRATCH1:     rb_rdata = scr1_q;
      A_TEST_STATUS:  rb_rdata = tst_q;
      A_SOFT_RESET:   rb_rdata = 32'd0;
      A_RESET_CAUSE:  rb_rdata = {16'd0, wdt_cnt_q, 4'd0, cause_q};
      A_CLK_EN:       rb_rdata = {15'd0, cg_cpu_q, 7'd0, clken_q};
      A_BUSERR_ADDR:  begin rb_rdata = beaddr_q; rb_err = rb_we; end
      A_BUSERR_INFO:  rb_rdata = {28'd0, bewe_q, bem_q, bev_q};
      A_MBIST_CTRL:   rb_rdata = {23'd0, mien_q, 6'd0, mbg_q, 1'b0};
      A_MBIST_STATUS: begin
        rb_rdata = {mbist_fail_addr, 1'b0, mbist_fail_elem, mbist_fail_bank,
                    5'd0, mbist_fail, mbist_done && !mstart_q, mbist_busy || mstart_q};
        rb_err   = rb_we;
      end
      A_DOORBELL:     rb_rdata = {31'd0, db_q};
      A_BOOT_STATUS:  rb_rdata = boot_st_q;
      A_FEATURES:     begin rb_rdata = FEATURES; rb_err = rb_we; end
      A_SRAM_SIZE:    begin rb_rdata = SRAM_SIZE; rb_err = rb_we; end
      A_DBG_LOCK:     rb_rdata = {31'd0, lock_q};
      A_PARITY_CTRL:  rb_rdata = {30'd0, pinj_q, pchk_q};
      A_PMU_STATUS:   begin rb_rdata = {31'd0, cpu_sleep}; rb_err = rb_we; end
      default:        rb_err = 1'b1;
    endcase
  end
endmodule

`default_nettype wire
