// =============================================================================
// SilicaFlux MCU-I :: mcu_soc -- core SoC (pad-less), BASIC and INDUSTRIAL
//
//   mcu_cpu (RV32I[M]_Zicsr) --I/D--+
//   JTAG SBA (via mcu_dbg_gate) ----+--> sfb_crossbar (SFB2, round robin) -->
//   mcu_dma (INDUSTRIAL) -----------+      ROM | SRAM bank 0..3 | periph bridge
//
//   periph bridge pages (configs/memmap.yaml):
//     SYSCTRL INTC MTIMER UART0 SPI0 GPIO FAULT WDT GPTIMER  (always)
//     DMA PWM I2C0 UART1 SPI1 DSP                            (feature params)
//
// One functional clock `clk` (+ JTAG `tck`).  Peripheral clocks are gated by
// integrated clock-gate cells (sfv_clkgate wrapper -> library ICG in ASIC,
// pass-through on FPGA with SFV_NO_CLOCK_GATE); the CPU clock is gated while
// it waits in WFI with an idle bus (SYSCTRL.CLK_EN.CPU_SLEEP_CG).  No
// combinational clock gating outside sfv_clkgate.
// Resets (async assert, sync release, bypassed to the pin in test_mode):
//   por_rst_n  rst_ni & pwr_ok_i      -> POR-domain registers, JTAG sys side
//   sys_rst_n  por & !soft/WDT pulse & !JTAG reset -> bus, memories, periph
//   cpu_rst_n  sys & !JTAG CPU hold   -> CPU
// Feature parameters only remove hardware; the memory map never moves.
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module mcu_soc #(
  parameter int          RV32M        = 0,
  parameter int          SRAM_BANKS   = 4,
  parameter int          BANK_WORDS   = 4096,
  parameter int          SRAM_PARITY  = 0,
  parameter int          SRAM_BACKEND = `SRAM_BACKEND_GENERIC,
  parameter int          SRAM_MACRO   = 0,
  parameter int          ROM_WORDS    = 2048,
  parameter int          GPIO_N       = 16,
  parameter int          N_TIMER      = 1,
  parameter int          HAS_UART1    = 0,
  parameter int          HAS_SPI1     = 0,
  parameter int          HAS_I2C      = 0,
  parameter int          HAS_PWM      = 0,
  parameter int          HAS_DMA      = 0,
  parameter int          HAS_DSP      = 0,
  parameter logic [15:0] UART_BAUD_RESET = 16'd217,
  localparam int         NPWM         = 4
) (
  input  wire logic              clk,
  input  wire logic              rst_ni,
  input  wire logic              pwr_ok_i,      // external supervisor / power-good (1 = ok)
  input  wire logic              test_mode,
  // JTAG
  input  wire logic              tck,
  input  wire logic              tms,
  input  wire logic              tdi,
  output logic                   tdo,
  output logic                   tdo_oe,
  // UART
  output logic                   uart0_tx,
  input  wire logic              uart0_rx,
  output logic                   uart1_tx,
  input  wire logic              uart1_rx,
  // SPI (SPI0 CS0 = boot flash)
  output logic                   spi0_sck,
  output logic                   spi0_mosi,
  input  wire logic              spi0_miso,
  output logic [3:0]             spi0_cs_n,
  output logic                   spi1_sck,
  output logic                   spi1_mosi,
  input  wire logic              spi1_miso,
  output logic [3:0]             spi1_cs_n,
  // I2C (open drain: *_oe = 1 pulls the line low)
  input  wire logic              i2c_scl_i,
  output logic                   i2c_scl_oe,
  input  wire logic              i2c_sda_i,
  output logic                   i2c_sda_oe,
  // GPIO (gpio[1:0] = boot straps during reset; gpio[4+c] = timer capture c)
  input  wire logic [GPIO_N-1:0] gpio_i,
  output logic [GPIO_N-1:0]      gpio_o,
  output logic [GPIO_N-1:0]      gpio_oe,
  // PWM
  output logic [NPWM-1:0]        pwm_o,
  input  wire logic              pwm_fault_i,
  // status
  output logic                   test_pass,
  output logic                   test_fail,
  output logic [31:0]            test_status,
  output logic                   cpu_sleep
);
  // ------------------------------------------------------------------ sizes
  localparam int NM         = (HAS_DMA != 0) ? 4 : 3;
  localparam int NS         = SRAM_BANKS + 2;
  localparam int S_ROM      = 0;
  localparam int S_PER      = SRAM_BANKS + 1;
  localparam int BANK_BYTES = BANK_WORDS * 4;
  localparam int BAW        = $clog2(BANK_WORDS);
  localparam int MI = mcu_memmap_pkg::M_CPUI, MD = mcu_memmap_pkg::M_CPUD, MG = mcu_memmap_pkg::M_DBG;
  localparam int MDMA = mcu_memmap_pkg::M_DMA;

  if (SRAM_BANKS != 4) begin : g_err_banks
    $error("mcu_soc: SRAM_BANKS must be 4 (sfv_mbist NBANKS)");
  end
  if (GPIO_N < 8 || GPIO_N > 32) begin : g_err_gpio
    $error("mcu_soc: GPIO_N must be 8..32");
  end
  if (N_TIMER < 1 || N_TIMER > 4) begin : g_err_tmr
    $error("mcu_soc: N_TIMER must be 1..4");
  end

  function automatic logic [NS*32-1:0] f_base();
    f_base = '0;
    f_base[S_ROM*32 +: 32] = mcu_memmap_pkg::BOOT_ROM_BASE;
    for (int b = 0; b < SRAM_BANKS; b++)
      f_base[(b+1)*32 +: 32] = mcu_memmap_pkg::SRAM_BASE + 32'(b * BANK_BYTES);
    f_base[S_PER*32 +: 32] = mcu_memmap_pkg::PERIPH_BASE;
  endfunction
  function automatic logic [NS*32-1:0] f_mask();
    f_mask = '0;
    f_mask[S_ROM*32 +: 32] = ~32'(ROM_WORDS * 4 - 1);
    for (int b = 0; b < SRAM_BANKS; b++) f_mask[(b+1)*32 +: 32] = ~32'(BANK_BYTES - 1);
    f_mask[S_PER*32 +: 32] = ~(mcu_memmap_pkg::PERIPH_WINDOW - 32'd1);
  endfunction
  // execute-never: the instruction port cannot reach the peripheral window
  function automatic logic [NM*NS-1:0] f_en();
    f_en = {(NM*NS){1'b1}};
    f_en[MI*NS + S_PER] = 1'b0;
  endfunction

  localparam logic [31:0] FEATURES =
      32'((RV32M != 0) ? 1 : 0) | (32'((RV32M == 2) ? 1 : 0) << 1) | (32'(SRAM_PARITY != 0) << 2) |
      (32'(HAS_DMA != 0) << 3) | (32'(HAS_I2C != 0) << 4) | (32'(HAS_PWM != 0) << 5) |
      (32'(HAS_DSP != 0) << 6) | ((32'd1 + 32'(HAS_UART1 != 0)) << 8) | ((32'd1 + 32'(HAS_SPI1 != 0)) << 10) |
      (32'(N_TIMER) << 12) | (32'(GPIO_N) << 16);

  // ------------------------------------------------------------------ resets
  logic por_rst_n, sys_rst_n, cpu_rst_n, sys_reset_req, jtag_hold, jtag_srst;
  sfv_rst_sync u_rs_por (.clk, .rst_ni(rst_ni && pwr_ok_i), .test_mode, .test_rst_ni(rst_ni), .rst_no(por_rst_n));
  sfv_rst_sync u_rs_sys (.clk, .rst_ni(por_rst_n && !sys_reset_req && !jtag_srst), .test_mode,
                         .test_rst_ni(rst_ni), .rst_no(sys_rst_n));
  sfv_rst_sync u_rs_cpu (.clk, .rst_ni(sys_rst_n && !jtag_hold), .test_mode,
                         .test_rst_ni(rst_ni), .rst_no(cpu_rst_n));

  // ------------------------------------------------------------------ crossbar
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0]  m_req_wstrb;
  logic [NS-1:0]    s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [NS*32-1:0] s_req_addr, s_req_wdata, s_rsp_rdata;
  logic [NS*4-1:0]  s_req_wstrb;
  logic             dec_evt, dec_write;
  logic [31:0]      dec_addr;
  logic [1:0]       dec_master;
  logic [NM-1:0]    ev_unused0, ev_unused1, ev_unused2, ev_unused3;

  sfb_crossbar #(
    .NM(NM), .NS(NS), .AW(32), .DW(32), .ARB_MODE(1), .CHECK_ALIGN(1),
    .SLV_BASE(f_base()), .SLV_MASK(f_mask()), .MST_SLV_EN(f_en())
  ) u_xbar (
    .clk, .rst_n(sys_rst_n),
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .err_evt(dec_evt), .err_addr(dec_addr), .err_master(dec_master), .err_write(dec_write),
    .ev_req_accept(ev_unused0), .ev_req_stall(ev_unused1), .ev_arb_loss(ev_unused2), .ev_rsp_stall(ev_unused3)
  );

  // ------------------------------------------------------------------ CPU (SFB v1 masters: rsp_ready = 1)
  logic irq_ext, irq_timer, irq_soft, cpu_bus_idle, cpu_sleep_cg, cpu_gclk;
  sfv_clkgate u_cg_cpu (.clk, .en(!(cpu_sleep_cg && cpu_sleep && cpu_bus_idle)), .test_en(test_mode),
                        .gclk(cpu_gclk));
  logic [31:0] cpu_i_addr;
  /* verilator lint_off PINCONNECTEMPTY */
  mcu_cpu #(.BOOT_ADDR(mcu_memmap_pkg::BOOT_ROM_BASE), .RV32M(RV32M), .MIMPID(mcu_memmap_pkg::MIMPID)) u_cpu (
    .clk(cpu_gclk), .rst_n(cpu_rst_n),
    .i_req(m_req_valid[MI]), .i_gnt(m_req_ready[MI]), .i_addr(cpu_i_addr), .i_rvalid(m_rsp_valid[MI]),
    .i_rdata(m_rsp_rdata[MI*32 +: 32]), .i_err(m_rsp_error[MI]),
    .d_req(m_req_valid[MD]), .d_gnt(m_req_ready[MD]), .d_addr(m_req_addr[MD*32 +: 32]),
    .d_we(m_req_write[MD]), .d_be(m_req_wstrb[MD*4 +: 4]), .d_wdata(m_req_wdata[MD*32 +: 32]),
    .d_rvalid(m_rsp_valid[MD]), .d_rdata(m_rsp_rdata[MD*32 +: 32]), .d_err(m_rsp_error[MD]),
    .irq_ext, .irq_timer, .irq_soft, .sleeping(cpu_sleep), .bus_idle(cpu_bus_idle),
    .rt_valid(), .rt_pc(), .rt_insn(), .rt_trap(), .rt_cause(), .rt_rd(), .rt_rd_wdata(), .rt_rd_we()
  );
  /* verilator lint_on PINCONNECTEMPTY */
  assign m_req_addr[MI*32 +: 32]  = cpu_i_addr;
  assign m_req_write[MI]          = 1'b0;
  assign m_req_wstrb[MI*4 +: 4]   = 4'b1111;
  assign m_req_wdata[MI*32 +: 32] = 32'd0;
  assign m_rsp_ready[MI]          = 1'b1;
  assign m_rsp_ready[MD]          = 1'b1;

  // ------------------------------------------------------------------ JTAG debug + access control
  logic        dbg_locked, j_req, j_gnt, j_we, j_rvalid, j_err, j_hold, j_srst, j_bovr, boot_ovr;
  logic [31:0] j_addr, j_wdata, j_rdata;
  logic [3:0]  j_be;
  logic [1:0]  boot_ovr_mode;
  mcu_jtag_dbg u_dbg (
    .tck, .trst_n(rst_ni), .tms, .tdi, .tdo, .tdo_oe,
    .clk, .rst_n(por_rst_n),
    .m_req(j_req), .m_gnt(j_gnt), .m_addr(j_addr), .m_we(j_we), .m_be(j_be), .m_wdata(j_wdata),
    .m_rvalid(j_rvalid), .m_rdata(j_rdata), .m_err(j_err),
    .cpu_hold(j_hold), .sys_reset_req(j_srst), .boot_ovr(j_bovr), .boot_ovr_mode,
    .cpu_sleep, .test_pass, .test_fail
  );
  mcu_dbg_gate u_dbg_gate (
    .clk, .rst_n(por_rst_n), .locked(dbg_locked),
    .d_req(j_req), .d_gnt(j_gnt), .d_addr(j_addr), .d_we(j_we), .d_be(j_be), .d_wdata(j_wdata),
    .d_rvalid(j_rvalid), .d_rdata(j_rdata), .d_err(j_err),
    .d_cpu_hold(j_hold), .d_sys_reset_req(j_srst), .d_boot_ovr(j_bovr),
    .m_req(m_req_valid[MG]), .m_gnt(m_req_ready[MG]), .m_addr(m_req_addr[MG*32 +: 32]),
    .m_we(m_req_write[MG]), .m_be(m_req_wstrb[MG*4 +: 4]), .m_wdata(m_req_wdata[MG*32 +: 32]),
    .m_rvalid(m_rsp_valid[MG]), .m_rdata(m_rsp_rdata[MG*32 +: 32]), .m_err(m_rsp_error[MG]),
    .cpu_hold(jtag_hold), .sys_reset_req(jtag_srst), .boot_ovr
  );
  assign m_rsp_ready[MG] = 1'b1;

  // ------------------------------------------------------------------ boot ROM (SFB v1 slave)
  logic rom_req, rom_gnt, rom_we, rom_rvalid, rom_err;
  logic [31:0] rom_addr, rom_wdata, rom_rdata;
  logic [3:0]  rom_be;
  sfb_v1_slave_adapter u_rom_ad (
    .clk, .rst_n(sys_rst_n),
    .req_valid(s_req_valid[S_ROM]), .req_ready(s_req_ready[S_ROM]), .req_write(s_req_write[S_ROM]),
    .req_addr(s_req_addr[S_ROM*32 +: 32]), .req_wdata(s_req_wdata[S_ROM*32 +: 32]),
    .req_wstrb(s_req_wstrb[S_ROM*4 +: 4]), .rsp_valid(s_rsp_valid[S_ROM]), .rsp_ready(s_rsp_ready[S_ROM]),
    .rsp_rdata(s_rsp_rdata[S_ROM*32 +: 32]), .rsp_error(s_rsp_error[S_ROM]),
    .v1_req(rom_req), .v1_gnt(rom_gnt), .v1_addr(rom_addr), .v1_we(rom_we), .v1_be(rom_be),
    .v1_wdata(rom_wdata), .v1_rvalid(rom_rvalid), .v1_rdata(rom_rdata), .v1_err(rom_err)
  );
  sfv_bootrom #(.WORDS(ROM_WORDS)) u_rom (
    .clk, .rst_n(sys_rst_n),
    .req(rom_req), .gnt(rom_gnt), .addr(rom_addr), .we(rom_we), .be(rom_be), .wdata(rom_wdata),
    .rvalid(rom_rvalid), .rdata(rom_rdata), .err(rom_err)
  );

  // ------------------------------------------------------------------ SRAM banks + MBIST
  logic mb_start, mb_bg, mb_busy, mb_done, mb_fail, mb_en, mb_ce, mb_we;
  logic [3:0]  mb_fbank;
  logic [2:0]  mb_felem;
  logic [BAW-1:0] mb_faddr, mb_addr;
  logic [31:0] mb_wdata;
  logic [SRAM_BANKS*32-1:0] mb_rd;
  sfv_mbist #(.AW(BAW), .NBANKS(SRAM_BANKS)) u_mbist (
    .clk, .rst_n(sys_rst_n), .start(mb_start), .bg_chk(mb_bg), .last(BAW'(BANK_WORDS - 1)),
    .busy(mb_busy), .done(mb_done), .fail(mb_fail), .fail_bank(mb_fbank),
    .fail_addr(mb_faddr), .fail_elem(mb_felem),
    .bist_en(mb_en), .bist_ce(mb_ce), .bist_we(mb_we), .bist_addr(mb_addr),
    .bist_wdata(mb_wdata), .bist_rdata(mb_rd)
  );

  logic par_chk_en, par_inject;
  logic [SRAM_BANKS-1:0]    par_evt_b, bank_wr_acc;
  logic [SRAM_BANKS*32-1:0] par_addr_b;
  genvar gb;
  for (gb = 0; gb < SRAM_BANKS; gb++) begin : g_sram
    mcu_sram_bank #(.DEPTH(BANK_WORDS), .PARITY(SRAM_PARITY), .READ_LATENCY(1),
                    .BACKEND(SRAM_BACKEND), .MACRO(SRAM_MACRO)) u_bank (
      .clk, .rst_n(sys_rst_n),
      .req_valid(s_req_valid[gb+1]), .req_ready(s_req_ready[gb+1]), .req_write(s_req_write[gb+1]),
      .req_addr(s_req_addr[(gb+1)*32 +: 32]), .req_wdata(s_req_wdata[(gb+1)*32 +: 32]),
      .req_wstrb(s_req_wstrb[(gb+1)*4 +: 4]), .rsp_valid(s_rsp_valid[gb+1]), .rsp_ready(s_rsp_ready[gb+1]),
      .rsp_rdata(s_rsp_rdata[(gb+1)*32 +: 32]), .rsp_error(s_rsp_error[gb+1]),
      .chk_en(par_chk_en), .inject(par_inject),
      .par_evt(par_evt_b[gb]), .par_addr(par_addr_b[gb*32 +: 32]),
      .tst_active(mb_en), .tst_ce(mb_ce), .tst_we(mb_we), .tst_addr(mb_addr), .tst_wdata(mb_wdata),
      .tst_rdata(mb_rd[gb*32 +: 32])
    );
    assign bank_wr_acc[gb] = s_req_valid[gb+1] && s_req_ready[gb+1] && s_req_write[gb+1];
  end
  logic        par_evt;
  logic [31:0] par_addr;
  always_comb begin
    par_evt  = |par_evt_b;
    par_addr = 32'd0;
    for (int b = SRAM_BANKS - 1; b >= 0; b--) if (par_evt_b[b]) par_addr = par_addr_b[b*32 +: 32];
  end

  // ------------------------------------------------------------------ peripheral bridge (SFB v1 slave)
  localparam int NP = 32;
  localparam logic [31:0] PAGE_EN =
      (32'd1 << mcu_memmap_pkg::PG_SYSCTRL) | (32'd1 << mcu_memmap_pkg::PG_INTC) |
      (32'd1 << mcu_memmap_pkg::PG_MTIMER)  | (32'd1 << mcu_memmap_pkg::PG_UART0) |
      (32'd1 << mcu_memmap_pkg::PG_SPI0)    | (32'd1 << mcu_memmap_pkg::PG_GPIO) |
      (32'd1 << mcu_memmap_pkg::PG_FAULT)   | (32'd1 << mcu_memmap_pkg::PG_WDT) |
      (32'd1 << mcu_memmap_pkg::PG_GPTIMER) |
      (32'(HAS_DMA != 0)   << mcu_memmap_pkg::PG_DMA)   | (32'(HAS_PWM != 0)   << mcu_memmap_pkg::PG_PWM) |
      (32'(HAS_I2C != 0)   << mcu_memmap_pkg::PG_I2C0)  | (32'(HAS_UART1 != 0) << mcu_memmap_pkg::PG_UART1) |
      (32'(HAS_SPI1 != 0)  << mcu_memmap_pkg::PG_SPI1)  | (32'(HAS_DSP != 0)   << mcu_memmap_pkg::PG_DSP);

  // Request-channel register slice between the crossbar and the peripheral
  // bridge (DataFabric sfb_reg_slice, the placement PROTOCOL.md section 7
  // intends): cuts the path CPU load/store address -> crossbar decode ->
  // peripheral register read mux -> bridge response register, which limited
  // the FPGA clock (docs/FPGA.md).  +1 cycle per peripheral access; the
  // crossbar's one-transaction-per-port rule still holds end to end.
  logic        ps_req_valid, ps_req_ready, ps_req_write, ps_rsp_valid, ps_rsp_ready, ps_rsp_error;
  logic [31:0] ps_req_addr, ps_req_wdata, ps_rsp_rdata;
  logic [3:0]  ps_req_wstrb;
  sfb_reg_slice #(.AW(32), .DW(32), .REQ_SLICE(1), .RSP_SLICE(0)) u_per_slice (
    .clk, .rst_n(sys_rst_n),
    .s_req_valid(s_req_valid[S_PER]), .s_req_ready(s_req_ready[S_PER]), .s_req_write(s_req_write[S_PER]),
    .s_req_addr(s_req_addr[S_PER*32 +: 32]), .s_req_wdata(s_req_wdata[S_PER*32 +: 32]),
    .s_req_wstrb(s_req_wstrb[S_PER*4 +: 4]), .s_rsp_valid(s_rsp_valid[S_PER]), .s_rsp_ready(s_rsp_ready[S_PER]),
    .s_rsp_rdata(s_rsp_rdata[S_PER*32 +: 32]), .s_rsp_error(s_rsp_error[S_PER]),
    .m_req_valid(ps_req_valid), .m_req_ready(ps_req_ready), .m_req_write(ps_req_write),
    .m_req_addr(ps_req_addr), .m_req_wdata(ps_req_wdata), .m_req_wstrb(ps_req_wstrb),
    .m_rsp_valid(ps_rsp_valid), .m_rsp_ready(ps_rsp_ready), .m_rsp_rdata(ps_rsp_rdata), .m_rsp_error(ps_rsp_error)
  );

  logic pb_req, pb_gnt, pb_we, pb_rvalid, pb_err;
  logic [31:0] pb_addr, pb_wdata, pb_rdata;
  logic [3:0]  pb_be;
  sfb_v1_slave_adapter u_per_ad (
    .clk, .rst_n(sys_rst_n),
    .req_valid(ps_req_valid), .req_ready(ps_req_ready), .req_write(ps_req_write),
    .req_addr(ps_req_addr), .req_wdata(ps_req_wdata),
    .req_wstrb(ps_req_wstrb), .rsp_valid(ps_rsp_valid), .rsp_ready(ps_rsp_ready),
    .rsp_rdata(ps_rsp_rdata), .rsp_error(ps_rsp_error),
    .v1_req(pb_req), .v1_gnt(pb_gnt), .v1_addr(pb_addr), .v1_we(pb_we), .v1_be(pb_be),
    .v1_wdata(pb_wdata), .v1_rvalid(pb_rvalid), .v1_rdata(pb_rdata), .v1_err(pb_err)
  );

  logic [NP-1:0]    rb_sel, rb_err_g;
  logic             rb_we;
  logic [11:0]      rb_addr;
  logic [31:0]      rb_wdata;
  logic [NP*32-1:0] rb_rdata, rb_rdata_g;
  logic [NP-1:0]    rb_err;
  sfv_periph_bridge #(.NP(NP), .PAGE_EN(PAGE_EN)) u_pbr (
    .clk, .rst_n(sys_rst_n),
    .req(pb_req), .gnt(pb_gnt), .addr(pb_addr), .we(pb_we), .be(pb_be), .wdata(pb_wdata),
    .rvalid(pb_rvalid), .rdata(pb_rdata), .err(pb_err),
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rb_rdata_g), .rb_err(rb_err_g)
  );

  // peripheral-error snoop for the fault log (one transaction per slave port)
  logic [31:0] per_addr_q;
  logic        per_we_q;
  always_ff @(posedge clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
      per_addr_q <= '0; per_we_q <= 1'b0;
    end else if (s_req_valid[S_PER] && s_req_ready[S_PER]) begin
      per_addr_q <= s_req_addr[S_PER*32 +: 32]; per_we_q <= s_req_write[S_PER];
    end
  end
  wire per_evt = s_rsp_valid[S_PER] && s_rsp_ready[S_PER] && s_rsp_error[S_PER];

  // ------------------------------------------------------------------ clock enables
  // index: 0 UART0 1 SPI0 2 GPTIMER 3 UART1 4 SPI1 5 I2C0 6 PWM 7 DMA 8 DSP
  logic [8:0] clk_en, clk_en_eff;
  /* verilator lint_off UNUSEDSIGNAL */   // gclk of absent optional peripherals
  logic [8:0] gclk;
  /* verilator lint_on UNUSEDSIGNAL */
  logic       dma_busy;
  always_comb begin
    clk_en_eff    = clk_en;
    clk_en_eff[7] = clk_en[7] || dma_busy;        // never stop a DMA with a transfer in flight
  end
  genvar gc;
  for (gc = 0; gc < 9; gc++) begin : g_cg
    sfv_clkgate u_cg (.clk, .en(clk_en_eff[gc]), .test_en(test_mode), .gclk(gclk[gc]));
  end
  // page -> clock-enable index (-1: never gated)
  function automatic int f_cg(input int p);
    case (p)
      mcu_memmap_pkg::PG_UART0:   f_cg = 0;
      mcu_memmap_pkg::PG_SPI0:    f_cg = 1;
      mcu_memmap_pkg::PG_GPTIMER: f_cg = 2;
      mcu_memmap_pkg::PG_UART1:   f_cg = 3;
      mcu_memmap_pkg::PG_SPI1:    f_cg = 4;
      mcu_memmap_pkg::PG_I2C0:    f_cg = 5;
      mcu_memmap_pkg::PG_PWM:     f_cg = 6;
      mcu_memmap_pkg::PG_DMA:     f_cg = 7;
      mcu_memmap_pkg::PG_DSP:     f_cg = 8;
      default:                    f_cg = -1;
    endcase
  endfunction
  // a gated (disabled) peripheral answers every access with a bus error
  genvar gp;
  for (gp = 0; gp < NP; gp++) begin : g_page
    if (!PAGE_EN[gp]) begin : g_absent
      assign rb_rdata[gp*32 +: 32] = 32'd0;
      assign rb_err[gp]            = 1'b1;
    end
    if (f_cg(gp) >= 0) begin : g_gated
      assign rb_rdata_g[gp*32 +: 32] = clk_en[f_cg(gp)] ? rb_rdata[gp*32 +: 32] : 32'd0;
      assign rb_err_g[gp]            = rb_err[gp] || !clk_en[f_cg(gp)];
    end else begin : g_ungated
      assign rb_rdata_g[gp*32 +: 32] = rb_rdata[gp*32 +: 32];
      assign rb_err_g[gp]            = rb_err[gp];
    end
  end

  // ------------------------------------------------------------------ interrupts
  logic [15:0] irq_src;
  logic irq_uart0, irq_spi0, irq_gpio, irq_gpt, irq_wdt, irq_fault, irq_dbg, irq_mbist, irq_berr;
  logic irq_dma, irq_i2c, irq_uart1, irq_spi1, irq_pwm;
  always_comb begin
    irq_src = '0;
    irq_src[mcu_memmap_pkg::IRQ_UART0]   = irq_uart0;
    irq_src[mcu_memmap_pkg::IRQ_SPI0]    = irq_spi0;
    irq_src[mcu_memmap_pkg::IRQ_GPIO]    = irq_gpio;
    irq_src[mcu_memmap_pkg::IRQ_GPTIMER] = irq_gpt;
    irq_src[mcu_memmap_pkg::IRQ_WDT]     = irq_wdt;
    irq_src[mcu_memmap_pkg::IRQ_FAULT]   = irq_fault;
    irq_src[mcu_memmap_pkg::IRQ_DBG]     = irq_dbg;
    irq_src[mcu_memmap_pkg::IRQ_MBIST]   = irq_mbist;
    irq_src[mcu_memmap_pkg::IRQ_DMA]     = irq_dma;
    irq_src[mcu_memmap_pkg::IRQ_I2C0]    = irq_i2c;
    irq_src[mcu_memmap_pkg::IRQ_UART1]   = irq_uart1;
    irq_src[mcu_memmap_pkg::IRQ_SPI1]    = irq_spi1;
    irq_src[mcu_memmap_pkg::IRQ_PWM]     = irq_pwm;
    irq_src[mcu_memmap_pkg::IRQ_BUSERR]  = irq_berr;
  end

  // ------------------------------------------------------------------ always-present peripherals
  localparam int P_SC = mcu_memmap_pkg::PG_SYSCTRL, P_IC = mcu_memmap_pkg::PG_INTC;
  localparam int P_MT = mcu_memmap_pkg::PG_MTIMER,  P_U0 = mcu_memmap_pkg::PG_UART0;
  localparam int P_S0 = mcu_memmap_pkg::PG_SPI0,    P_GP = mcu_memmap_pkg::PG_GPIO;
  localparam int P_FT = mcu_memmap_pkg::PG_FAULT,   P_WD = mcu_memmap_pkg::PG_WDT;
  localparam int P_GT = mcu_memmap_pkg::PG_GPTIMER, P_DM = mcu_memmap_pkg::PG_DMA;
  localparam int P_PW = mcu_memmap_pkg::PG_PWM,     P_I2 = mcu_memmap_pkg::PG_I2C0;
  localparam int P_U1 = mcu_memmap_pkg::PG_UART1,   P_S1 = mcu_memmap_pkg::PG_SPI1;
  localparam int P_DS = mcu_memmap_pkg::PG_DSP;

  logic [1:0] straps_s;
  sfv_sync u_st0 (.clk, .rst_n(por_rst_n), .d(gpio_i[0]), .q(straps_s[0]));
  sfv_sync u_st1 (.clk, .rst_n(por_rst_n), .d(gpio_i[1]), .q(straps_s[1]));

  logic wdt_req, wdt_reset_seen, uart0_evt, uart1_evt, i2c_evt, pwm_evt, dma_evt;
  /* verilator lint_off UNUSEDSIGNAL */   // unused when HAS_DMA = 0
  logic [15:0] dreq;
  /* verilator lint_on UNUSEDSIGNAL */

  mcu_sysctrl #(.FEATURES(FEATURES), .SRAM_SIZE(32'(SRAM_BANKS * BANK_BYTES))) u_sysctrl (
    .clk, .rst_n(sys_rst_n), .por_rst_n,
    .rb_sel(rb_sel[P_SC]), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rb_rdata[P_SC*32 +: 32]), .rb_err(rb_err[P_SC]),
    .boot_straps(boot_ovr ? boot_ovr_mode : straps_s), .jtag_srst, .wdt_req, .cpu_sleep,
    .berr_evt(dec_evt), .berr_addr(dec_addr), .berr_master(dec_master), .berr_we(dec_write),
    .mbist_start(mb_start), .mbist_bg(mb_bg), .mbist_busy(mb_busy), .mbist_done(mb_done),
    .mbist_fail(mb_fail), .mbist_fail_bank(mb_fbank), .mbist_fail_elem(mb_felem),
    .mbist_fail_addr(16'(mb_faddr)),
    .par_chk_en, .par_inject, .par_inject_done(|bank_wr_acc),
    .sys_reset_req, .clk_en, .cpu_sleep_cg, .dbg_locked, .wdt_reset_seen,
    .test_pass, .test_fail, .test_status, .irq_berr, .irq_mbist, .irq_dbg
  );

  mcu_intc #(.N(16)) u_intc (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_IC]), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rb_rdata[P_IC*32 +: 32]), .rb_err(rb_err[P_IC]),
    .src(irq_src), .irq_ext
  );

  sfv_timer u_mtimer (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_MT]), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rb_rdata[P_MT*32 +: 32]), .rb_err(rb_err[P_MT]),
    .irq_timer, .irq_soft
  );

  logic u0_dtx, u0_drx;
  mcu_uart #(.BAUD_RESET(UART_BAUD_RESET)) u_uart0 (
    .clk(gclk[0]), .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_U0]), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rb_rdata[P_U0*32 +: 32]), .rb_err(rb_err[P_U0]),
    .txd(uart0_tx), .rxd(uart0_rx), .irq(irq_uart0), .dreq_tx(u0_dtx), .dreq_rx(u0_drx),
    .err_evt(uart0_evt)
  );

  logic s0_dtx, s0_drx;
  mcu_spi #(.NCS(4)) u_spi0 (
    .clk(gclk[1]), .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_S0]), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rb_rdata[P_S0*32 +: 32]), .rb_err(rb_err[P_S0]),
    .sck(spi0_sck), .mosi(spi0_mosi), .miso(spi0_miso), .cs_n(spi0_cs_n), .irq(irq_spi0),
    .dreq_tx(s0_dtx), .dreq_rx(s0_drx)
  );

  /* verilator lint_off UNUSEDSIGNAL */   // only the capture pins are used
  logic [GPIO_N-1:0] gpio_s;
  /* verilator lint_on UNUSEDSIGNAL */
  mcu_gpio #(.N(GPIO_N)) u_gpio (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_GP]), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rb_rdata[P_GP*32 +: 32]), .rb_err(rb_err[P_GP]),
    .gpio_i, .gpio_o, .gpio_oe, .gpio_in_sync(gpio_s), .irq(irq_gpio)
  );

  logic wdt_ewi_q;
  mcu_wdt u_wdt (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_WD]), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rb_rdata[P_WD*32 +: 32]), .rb_err(rb_err[P_WD]),
    .dbg_halt(jtag_hold), .irq_ewi(irq_wdt), .reset_req(wdt_req)
  );
  always_ff @(posedge clk or negedge sys_rst_n) begin
    if (!sys_rst_n) wdt_ewi_q <= 1'b0;
    else            wdt_ewi_q <= irq_wdt;
  end

  mcu_fault u_fault (
    .clk, .por_rst_n,
    .rb_sel(rb_sel[P_FT]), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rb_rdata[P_FT*32 +: 32]), .rb_err(rb_err[P_FT]),
    .dec_evt, .dec_addr, .dec_master, .dec_write,
    .per_evt, .per_addr(per_addr_q), .per_write(per_we_q),
    .par_evt, .par_addr,
    .dma_evt, .uart_evt(uart0_evt || uart1_evt), .i2c_evt, .pwm_evt,
    .ewi_evt(irq_wdt && !wdt_ewi_q), .wdt_rst(wdt_reset_seen), .irq(irq_fault)
  );

  mcu_gptimer #(.N(N_TIMER)) u_gpt (
    .clk(gclk[2]), .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_GT]), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(rb_rdata[P_GT*32 +: 32]), .rb_err(rb_err[P_GT]),
    .cap_i(gpio_s[4 +: N_TIMER]), .irq(irq_gpt)
  );

  // ------------------------------------------------------------------ optional peripherals
  logic u1_dtx, u1_drx, s1_dtx, s1_drx;
  if (HAS_UART1 != 0) begin : g_uart1
    mcu_uart #(.BAUD_RESET(UART_BAUD_RESET)) u_uart1 (
      .clk(gclk[3]), .rst_n(sys_rst_n),
      .rb_sel(rb_sel[P_U1]), .rb_we, .rb_addr, .rb_wdata,
      .rb_rdata(rb_rdata[P_U1*32 +: 32]), .rb_err(rb_err[P_U1]),
      .txd(uart1_tx), .rxd(uart1_rx), .irq(irq_uart1), .dreq_tx(u1_dtx), .dreq_rx(u1_drx),
      .err_evt(uart1_evt)
    );
  end else begin : g_no_uart1
    assign uart1_tx = 1'b1; assign irq_uart1 = 1'b0; assign u1_dtx = 1'b0; assign u1_drx = 1'b0;
    assign uart1_evt = 1'b0;
    wire unused_u1 = uart1_rx;
  end

  if (HAS_SPI1 != 0) begin : g_spi1
    mcu_spi #(.NCS(4)) u_spi1 (
      .clk(gclk[4]), .rst_n(sys_rst_n),
      .rb_sel(rb_sel[P_S1]), .rb_we, .rb_addr, .rb_wdata,
      .rb_rdata(rb_rdata[P_S1*32 +: 32]), .rb_err(rb_err[P_S1]),
      .sck(spi1_sck), .mosi(spi1_mosi), .miso(spi1_miso), .cs_n(spi1_cs_n), .irq(irq_spi1),
      .dreq_tx(s1_dtx), .dreq_rx(s1_drx)
    );
  end else begin : g_no_spi1
    assign spi1_sck = 1'b0; assign spi1_mosi = 1'b0; assign spi1_cs_n = 4'hF; assign irq_spi1 = 1'b0;
    assign s1_dtx = 1'b0; assign s1_drx = 1'b0;
    wire unused_s1 = spi1_miso;
  end

  if (HAS_I2C != 0) begin : g_i2c
    mcu_i2c u_i2c (
      .clk(gclk[5]), .rst_n(sys_rst_n),
      .rb_sel(rb_sel[P_I2]), .rb_we, .rb_addr, .rb_wdata,
      .rb_rdata(rb_rdata[P_I2*32 +: 32]), .rb_err(rb_err[P_I2]),
      .scl_i(i2c_scl_i), .sda_i(i2c_sda_i), .scl_oe(i2c_scl_oe), .sda_oe(i2c_sda_oe),
      .irq(irq_i2c), .err_evt(i2c_evt)
    );
  end else begin : g_no_i2c
    assign i2c_scl_oe = 1'b0; assign i2c_sda_oe = 1'b0; assign irq_i2c = 1'b0; assign i2c_evt = 1'b0;
    wire unused_i2 = i2c_scl_i ^ i2c_sda_i;
  end

  if (HAS_PWM != 0) begin : g_pwm
    mcu_pwm #(.NCH(NPWM)) u_pwm (
      .clk(gclk[6]), .rst_n(sys_rst_n),
      .rb_sel(rb_sel[P_PW]), .rb_we, .rb_addr, .rb_wdata,
      .rb_rdata(rb_rdata[P_PW*32 +: 32]), .rb_err(rb_err[P_PW]),
      .fault_i(pwm_fault_i), .pwm_o, .irq(irq_pwm), .fault_evt(pwm_evt)
    );
  end else begin : g_no_pwm
    assign pwm_o = '0; assign irq_pwm = 1'b0; assign pwm_evt = 1'b0;
    wire unused_pw = pwm_fault_i;
  end

  always_comb begin
    dreq = '0;
    dreq[mcu_memmap_pkg::DREQ_UART0_RX] = u0_drx;
    dreq[mcu_memmap_pkg::DREQ_UART0_TX] = u0_dtx;
    dreq[mcu_memmap_pkg::DREQ_SPI0_RX]  = s0_drx;
    dreq[mcu_memmap_pkg::DREQ_SPI0_TX]  = s0_dtx;
    dreq[mcu_memmap_pkg::DREQ_UART1_RX] = u1_drx;
    dreq[mcu_memmap_pkg::DREQ_UART1_TX] = u1_dtx;
    dreq[mcu_memmap_pkg::DREQ_SPI1_RX]  = s1_drx;
    dreq[mcu_memmap_pkg::DREQ_SPI1_TX]  = s1_dtx;
  end
  localparam logic [15:0] DREQ_MASK =
      (16'd1 << mcu_memmap_pkg::DREQ_UART0_RX) | (16'd1 << mcu_memmap_pkg::DREQ_UART0_TX) |
      (16'd1 << mcu_memmap_pkg::DREQ_SPI0_RX)  | (16'd1 << mcu_memmap_pkg::DREQ_SPI0_TX) |
      (16'(HAS_UART1 != 0) << mcu_memmap_pkg::DREQ_UART1_RX) | (16'(HAS_UART1 != 0) << mcu_memmap_pkg::DREQ_UART1_TX) |
      (16'(HAS_SPI1 != 0)  << mcu_memmap_pkg::DREQ_SPI1_RX)  | (16'(HAS_SPI1 != 0)  << mcu_memmap_pkg::DREQ_SPI1_TX);

  if (HAS_DMA != 0) begin : g_dma
    mcu_dma #(.MAX_LEN_LOG2(16), .DREQ_MASK(DREQ_MASK), .PER_BASE(mcu_memmap_pkg::PERIPH_BASE),
              .PER_MASK(~(mcu_memmap_pkg::PERIPH_WINDOW - 32'd1))) u_dma (
      .clk(gclk[7]), .rst_n(sys_rst_n),
      .rb_sel(rb_sel[P_DM]), .rb_we, .rb_addr, .rb_wdata,
      .rb_rdata(rb_rdata[P_DM*32 +: 32]), .rb_err(rb_err[P_DM]), .irq(irq_dma), .dreq,
      .req_valid(m_req_valid[MDMA]), .req_ready(m_req_ready[MDMA]), .req_write(m_req_write[MDMA]),
      .req_addr(m_req_addr[MDMA*32 +: 32]), .req_wdata(m_req_wdata[MDMA*32 +: 32]),
      .req_wstrb(m_req_wstrb[MDMA*4 +: 4]), .rsp_valid(m_rsp_valid[MDMA]), .rsp_ready(m_rsp_ready[MDMA]),
      .rsp_rdata(m_rsp_rdata[MDMA*32 +: 32]), .rsp_error(m_rsp_error[MDMA]),
      .busy(dma_busy), .err_evt(dma_evt)
    );
  end else begin : g_no_dma
    assign irq_dma = 1'b0; assign dma_busy = 1'b0; assign dma_evt = 1'b0;
  end

  if (HAS_DSP != 0) begin : g_dsp
    mcu_dsp u_dsp (
      .clk(gclk[8]), .rst_n(sys_rst_n),
      .rb_sel(rb_sel[P_DS]), .rb_we, .rb_addr, .rb_wdata,
      .rb_rdata(rb_rdata[P_DS*32 +: 32]), .rb_err(rb_err[P_DS])
    );
  end
endmodule

`default_nettype wire
