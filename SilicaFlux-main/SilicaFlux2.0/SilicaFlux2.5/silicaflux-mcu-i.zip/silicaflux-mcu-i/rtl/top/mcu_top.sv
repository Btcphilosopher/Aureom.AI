// =============================================================================
// SilicaFlux MCU-I :: mcu_top -- configuration wrapper
//
// Instantiates mcu_soc with the parameters of the configuration package
// mcu_cfg_pkg.  Exactly one of rtl/generated/mcu_cfg_basic_pkg.sv or
// rtl/generated/mcu_cfg_industrial_pkg.sv (both generated from
// configs/<variant>.yaml by scripts/mcu_gen.py) is compiled per build, so the
// variant is selected by the file list, not by scattered `defines.
// GPIO ports are 32 bits wide for every variant; bits >= GPIO_N read 0 and
// are never driven.
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module mcu_top #(
  parameter int          SRAM_BACKEND    = `SRAM_BACKEND_GENERIC,
  parameter int          SRAM_MACRO      = 0,
  parameter logic [15:0] UART_BAUD_RESET = 16'd217      // 25 MHz / 115200
) (
  input  wire logic        clk,
  input  wire logic        rst_ni,
  input  wire logic        pwr_ok_i,
  input  wire logic        test_mode,
  input  wire logic        tck,
  input  wire logic        tms,
  input  wire logic        tdi,
  output logic             tdo,
  output logic             tdo_oe,
  output logic             uart0_tx,
  input  wire logic        uart0_rx,
  output logic             uart1_tx,
  input  wire logic        uart1_rx,
  output logic             spi0_sck,
  output logic             spi0_mosi,
  input  wire logic        spi0_miso,
  output logic [3:0]       spi0_cs_n,
  output logic             spi1_sck,
  output logic             spi1_mosi,
  input  wire logic        spi1_miso,
  output logic [3:0]       spi1_cs_n,
  input  wire logic        i2c_scl_i,
  output logic             i2c_scl_oe,
  input  wire logic        i2c_sda_i,
  output logic             i2c_sda_oe,
  /* verilator lint_off UNUSEDSIGNAL */   // bits >= GPIO_N
  input  wire logic [31:0] gpio_i,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic [31:0]      gpio_o,
  output logic [31:0]      gpio_oe,
  output logic [3:0]       pwm_o,
  input  wire logic        pwm_fault_i,
  output logic             test_pass,
  output logic             test_fail,
  output logic [31:0]      test_status,
  output logic             cpu_sleep
);
  localparam int GN = mcu_cfg_pkg::GPIO_N;
  logic [GN-1:0] g_o, g_oe;

  mcu_soc #(
    .RV32M(mcu_cfg_pkg::RV32M), .SRAM_BANKS(mcu_cfg_pkg::SRAM_BANKS), .BANK_WORDS(mcu_cfg_pkg::BANK_WORDS),
    .SRAM_PARITY(mcu_cfg_pkg::SRAM_PARITY), .SRAM_BACKEND(SRAM_BACKEND), .SRAM_MACRO(SRAM_MACRO),
    .ROM_WORDS(mcu_cfg_pkg::ROM_WORDS), .GPIO_N(GN), .N_TIMER(mcu_cfg_pkg::N_TIMER),
    .HAS_UART1(mcu_cfg_pkg::HAS_UART1), .HAS_SPI1(mcu_cfg_pkg::HAS_SPI1), .HAS_I2C(mcu_cfg_pkg::HAS_I2C),
    .HAS_PWM(mcu_cfg_pkg::HAS_PWM), .HAS_DMA(mcu_cfg_pkg::HAS_DMA), .HAS_DSP(mcu_cfg_pkg::HAS_DSP),
    .UART_BAUD_RESET(UART_BAUD_RESET)
  ) u_soc (
    .clk, .rst_ni, .pwr_ok_i, .test_mode, .tck, .tms, .tdi, .tdo, .tdo_oe,
    .uart0_tx, .uart0_rx, .uart1_tx, .uart1_rx,
    .spi0_sck, .spi0_mosi, .spi0_miso, .spi0_cs_n, .spi1_sck, .spi1_mosi, .spi1_miso, .spi1_cs_n,
    .i2c_scl_i, .i2c_scl_oe, .i2c_sda_i, .i2c_sda_oe,
    .gpio_i(gpio_i[GN-1:0]), .gpio_o(g_o), .gpio_oe(g_oe),
    .pwm_o, .pwm_fault_i, .test_pass, .test_fail, .test_status, .cpu_sleep
  );
  always_comb begin
    gpio_o  = '0;
    gpio_oe = '0;
    gpio_o[GN-1:0]  = g_o;
    gpio_oe[GN-1:0] = g_oe;
  end
endmodule

`default_nettype wire
