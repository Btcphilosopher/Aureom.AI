// =============================================================================
// SilicaFlux MCU-I :: mcu_gptimer -- general-purpose timers (new for MCU-I)
//
// N independent channels (1..4), register stride 0x20 (docs/REGISTERS.md,
// block `gptimer`).  Per channel:
//   prescaler  one tick every PRESCALE+1 clk cycles while EN
//   counter    counts up 0..RELOAD; at RELOAD the next tick wraps it to 0 and
//              sets OVF (periodic) -- or, with ONESHOT, sets OVF, clears EN
//              and leaves the counter at 0
//   compare    CMP flag on the tick where the counter becomes equal to CMP
//   capture    on the selected edge of the (already synchronised) capture
//              input, COUNT is copied to CAPTURE and CAP is set; a capture
//              while CAP is still set also sets CAP_OVR (CAPTURE overwritten)
//   interrupt  irq[ch] = (OVF & OVF_IE) | (CMP & CMP_IE) | (CAP & CAP_IE)
// Writing COUNT or PRESCALE restarts the prescaler.  Status bits are W1C; a
// hardware set in the same cycle as a clear wins (no lost events).
// Rollover: RELOAD = 0xFFFF_FFFF gives a free-running 32-bit counter.
// =============================================================================
`default_nettype none

module mcu_gptimer #(
  parameter int N = 1
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         rb_sel,
  input  wire logic         rb_we,
  input  wire logic [11:0]  rb_addr,
  input  wire logic [31:0]  rb_wdata,
  output logic [31:0]       rb_rdata,
  output logic              rb_err,
  input  wire logic [N-1:0] cap_i,         // synchronised capture inputs
  output logic              irq
);
  localparam logic [4:0] O_CTRL = mcu_memmap_pkg::GPTIMER_CH_CTRL[4:0];
  localparam logic [4:0] O_PRE  = mcu_memmap_pkg::GPTIMER_CH_PRESCALE[4:0];
  localparam logic [4:0] O_RLD  = mcu_memmap_pkg::GPTIMER_CH_RELOAD[4:0];
  localparam logic [4:0] O_CNT  = mcu_memmap_pkg::GPTIMER_CH_COUNT[4:0];
  localparam logic [4:0] O_CMP  = mcu_memmap_pkg::GPTIMER_CH_CMP[4:0];
  localparam logic [4:0] O_CAP  = mcu_memmap_pkg::GPTIMER_CH_CAPTURE[4:0];
  localparam logic [4:0] O_ST   = mcu_memmap_pkg::GPTIMER_CH_STATUS[4:0];
  localparam logic [11:0] A_IRQ  = mcu_memmap_pkg::GPTIMER_IRQ_STATUS;
  localparam logic [11:0] A_INFO = mcu_memmap_pkg::GPTIMER_INFO;

  wire        wr     = rb_sel && rb_we;
  wire [2:0]  ch_sel = rb_addr[7:5];
  wire [4:0]  ch_off = rb_addr[4:0];
  wire        in_ch  = (rb_addr[11:8] == 4'd0) && (32'(ch_sel) < N);

  logic [N-1:0]    irq_ch;
  logic [N*32-1:0] rd_ch;
  logic [N-1:0]    err_ch;

  genvar c;
  for (c = 0; c < N; c++) begin : g_ch
    logic [6:0]  ctrl_q;
    logic [15:0] pre_q, pcnt_q;
    logic [31:0] rld_q, cnt_q, cmp_q, cap_q;
    logic [3:0]  st_q;
    logic        cap_d;
    wire sel   = in_ch && (ch_sel == 3'(c));
    wire w     = wr && sel;
    wire en    = ctrl_q[0];
    wire tick  = en && (pcnt_q == pre_q);
    wire wrap  = tick && (cnt_q == rld_q);
    wire [31:0] cnt_nx = wrap ? 32'd0 : cnt_q + 32'd1;
    wire cmp_hit = tick && (cnt_nx == cmp_q);
    wire rise  = cap_i[c] && !cap_d;
    wire fall  = !cap_i[c] && cap_d;
    wire cap_hit = (ctrl_q[5] && rise) || (ctrl_q[6] && fall);

    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        ctrl_q <= '0; pre_q <= '0; pcnt_q <= '0;
        rld_q <= mcu_memmap_pkg::GPTIMER_CH_RELOAD_RST; cnt_q <= '0;
        cmp_q <= mcu_memmap_pkg::GPTIMER_CH_CMP_RST; cap_q <= '0;
        st_q <= '0; cap_d <= 1'b0;
      end else begin
        cap_d <= cap_i[c];
        // prescaler
        if (!en || tick) pcnt_q <= '0;
        else             pcnt_q <= pcnt_q + 16'd1;
        // counter
        if (tick) begin
          cnt_q <= cnt_nx;
          if (wrap && ctrl_q[1]) ctrl_q[0] <= 1'b0;      // one-shot ends
        end
        if (cap_hit) cap_q <= cnt_q;
        // status: W1C, hardware set wins
        st_q <= (st_q & ~((w && ch_off == O_ST) ? rb_wdata[3:0] : 4'd0))
              | {cap_hit && st_q[2], cap_hit, cmp_hit, wrap};
        // register writes
        if (w) begin
          case (ch_off)
            O_CTRL: ctrl_q <= rb_wdata[6:0];
            O_PRE:  begin pre_q <= rb_wdata[15:0]; pcnt_q <= '0; end
            O_RLD:  rld_q <= rb_wdata;
            O_CNT:  begin cnt_q <= rb_wdata; pcnt_q <= '0; end
            O_CMP:  cmp_q <= rb_wdata;
            default: ;
          endcase
        end
      end
    end
    assign irq_ch[c] = (st_q[0] && ctrl_q[2]) || (st_q[1] && ctrl_q[3]) || (st_q[2] && ctrl_q[4]);
    always_comb begin
      rd_ch[c*32 +: 32] = 32'd0;
      err_ch[c] = 1'b0;
      case (ch_off)
        O_CTRL: rd_ch[c*32 +: 32] = {25'd0, ctrl_q};
        O_PRE:  rd_ch[c*32 +: 32] = {16'd0, pre_q};
        O_RLD:  rd_ch[c*32 +: 32] = rld_q;
        O_CNT:  rd_ch[c*32 +: 32] = cnt_q;
        O_CMP:  rd_ch[c*32 +: 32] = cmp_q;
        O_CAP:  begin rd_ch[c*32 +: 32] = cap_q; err_ch[c] = rb_we; end
        O_ST:   rd_ch[c*32 +: 32] = {28'd0, st_q};
        default: err_ch[c] = 1'b1;
      endcase
    end
  end
  assign irq = |irq_ch;

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (in_ch) begin
      for (int i = 0; i < N; i++) begin
        if (ch_sel == 3'(i)) begin
          rb_rdata = rd_ch[i*32 +: 32];
          rb_err   = err_ch[i];
        end
      end
    end else if (rb_addr == A_IRQ) begin
      rb_rdata[N-1:0] = irq_ch;
      rb_err   = rb_we;
    end else if (rb_addr == A_INFO) begin
      rb_rdata = 32'(N);
      rb_err   = rb_we;
    end else begin
      rb_err   = 1'b1;
    end
  end
endmodule

`default_nettype wire
