// =============================================================================
// SilicaFlux MCU-I :: mcu_pwm -- PWM with safe state and fault input (new)
//
// Register map: docs/REGISTERS.md block `pwm`.
//   * Shared timebase: 16-bit counter 0..PERIOD.TOP, one step every
//     PRESCALE+1 clk cycles while EN.  Period = (TOP+1)(PRESCALE+1) cycles.
//   * Channel i active while COUNT < DUTY_i (DUTY_i = 0: never; DUTY_i >
//     TOP: always).  DUTY writes go to a shadow register and take effect at
//     the next period start (counter wrap) or immediately while EN = 0, so a
//     duty update never produces a runt pulse.
//   * Output: pwm_o[i] = OUT_EN[i] && EN && !FAULT ? (active ^ POL[i])
//                                                  : SAFE[i]
//     Reset state: all outputs 0 (SAFE resets to 0), timebase stopped.
//   * Fault input (pwm_fault_i, asynchronous pin): 2-flop synchroniser, then
//     with FAULT_EN the active level (FAULT_POL) latches STATUS.FAULT and all
//     channels go to SAFE within 3 clk cycles of the pin edge (2 synchroniser
//     + 1 output register).  FAULT stays latched until firmware clears it
//     with the input inactive; EN is not changed (restart is explicit).
// Safety note: these are functional provisions for a motor-control safe
// state.  They are not a certified safety function (no diagnostic coverage
// analysis, no independent shutdown path); see docs/SAFETY.md.
// =============================================================================
`default_nettype none

module mcu_pwm #(
  parameter int NCH = 4
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           rb_sel,
  input  wire logic           rb_we,
  input  wire logic [11:0]    rb_addr,
  input  wire logic [31:0]    rb_wdata,
  output logic [31:0]         rb_rdata,
  output logic                rb_err,
  input  wire logic           fault_i,
  output logic [NCH-1:0]      pwm_o,
  output logic                irq,
  output logic                fault_evt     // fault latched this cycle (pulse)
);
  localparam logic [11:0] A_CTRL  = mcu_memmap_pkg::PWM_CTRL;
  localparam logic [11:0] A_PRE   = mcu_memmap_pkg::PWM_PRESCALE;
  localparam logic [11:0] A_PER   = mcu_memmap_pkg::PWM_PERIOD;
  localparam logic [11:0] A_CNT   = mcu_memmap_pkg::PWM_COUNT;
  localparam logic [11:0] A_STAT  = mcu_memmap_pkg::PWM_STATUS;
  localparam logic [11:0] A_OEN   = mcu_memmap_pkg::PWM_OUT_EN;
  localparam logic [11:0] A_SAFE  = mcu_memmap_pkg::PWM_SAFE;
  localparam logic [11:0] A_POL   = mcu_memmap_pkg::PWM_POL;
  localparam logic [11:0] A_DUTY0 = mcu_memmap_pkg::PWM_DUTY0;

  logic [4:0]       ctrl_q;
  logic [15:0]      pre_q, pcnt_q, top_q, cnt_q;
  logic             flt_q, per_q;
  logic [NCH-1:0]   oen_q, safe_q, pol_q;
  logic [NCH*17-1:0] duty_sh_q, duty_q;
  wire wr  = rb_sel && rb_we;
  wire en  = ctrl_q[0];

  logic flt_s;
  sfv_sync u_fs (.clk, .rst_n, .d(fault_i), .q(flt_s));
  wire flt_act = ctrl_q[1] && (flt_s == ctrl_q[2]);

  wire tick = en && (pcnt_q == pre_q);
  wire wrap = tick && (cnt_q == top_q);
  wire duty_wr = wr && rb_addr >= A_DUTY0 && rb_addr < A_DUTY0 + 12'(4 * NCH);
  wire [1:0] duty_idx = rb_addr[3:2];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ctrl_q <= '0; pre_q <= '0; pcnt_q <= '0; top_q <= 16'hFFFF; cnt_q <= '0;
      flt_q <= 1'b0; per_q <= 1'b0; oen_q <= '0; safe_q <= '0; pol_q <= '0;
      duty_sh_q <= '0; duty_q <= '0;
    end else begin
      if (!en || tick) pcnt_q <= '0;
      else             pcnt_q <= pcnt_q + 16'd1;
      if (!en)         cnt_q <= '0;
      else if (tick)   cnt_q <= wrap ? 16'd0 : cnt_q + 16'd1;
      // shadow -> active at period start (or always while stopped)
      if (wrap || !en) duty_q <= duty_sh_q;
      // status
      if (flt_act) flt_q <= 1'b1;
      else if (wr && rb_addr == A_STAT && rb_wdata[0]) flt_q <= 1'b0;
      if (wrap) per_q <= 1'b1;
      else if (wr && rb_addr == A_STAT && rb_wdata[1]) per_q <= 1'b0;
      if (wr) begin
        case (rb_addr)
          A_CTRL: ctrl_q <= rb_wdata[4:0];
          A_PRE:  begin pre_q <= rb_wdata[15:0]; pcnt_q <= '0; end
          A_PER:  top_q  <= rb_wdata[15:0];
          A_OEN:  oen_q  <= rb_wdata[NCH-1:0];
          A_SAFE: safe_q <= rb_wdata[NCH-1:0];
          A_POL:  pol_q  <= rb_wdata[NCH-1:0];
          default: ;
        endcase
        if (duty_wr) duty_sh_q[duty_idx*17 +: 17] <= rb_wdata[16:0];
      end
    end
  end

  // registered outputs (glitch-free pins)
  logic [NCH-1:0] act;
  always_comb begin
    for (int i = 0; i < NCH; i++) act[i] = ({1'b0, cnt_q} < duty_q[i*17 +: 17]);
  end
  wire run = en && !flt_q && !flt_act;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) pwm_o <= '0;
    else        pwm_o <= (oen_q & {NCH{run}} & (act ^ pol_q)) | (~(oen_q & {NCH{run}}) & safe_q);
  end

  assign irq       = (ctrl_q[3] && flt_q) || (ctrl_q[4] && per_q);
  assign fault_evt = flt_act && !flt_q;
  wire unused_ok = ^rb_wdata[31:17];

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (rb_addr >= A_DUTY0 && rb_addr < A_DUTY0 + 12'(4 * NCH)) begin
      rb_rdata = {15'd0, duty_sh_q[duty_idx*17 +: 17]};
    end else begin
      case (rb_addr)
        A_CTRL: rb_rdata = {27'd0, ctrl_q};
        A_PRE:  rb_rdata = {16'd0, pre_q};
        A_PER:  rb_rdata = {16'd0, top_q};
        A_CNT:  begin rb_rdata = {16'd0, cnt_q}; rb_err = rb_we; end
        A_STAT: rb_rdata = {29'd0, flt_s, per_q, flt_q};
        A_OEN:  rb_rdata[NCH-1:0] = oen_q;
        A_SAFE: rb_rdata[NCH-1:0] = safe_q;
        A_POL:  rb_rdata[NCH-1:0] = pol_q;
        default: rb_err = 1'b1;
      endcase
    end
  end
endmodule

`default_nettype wire
