// SilicaFlux MCU-I RTL compile order (variant-independent part).
// Add exactly one rtl/generated/mcu_cfg_<variant>_pkg.sv BEFORE this list and
// the generated ROM image build/<variant>/mcu_bootrom_image.sv after it.
// Include path: +incdir+third_party/silicaflux-sramlib/rtl/mem
rtl/generated/mcu_memmap_pkg.sv
third_party/silicaflux-v/rtl/common/sfv_common.sv
third_party/silicaflux-v/rtl/common/sfv_clkgate.sv
third_party/silicaflux-v/rtl/bus/sfv_periph_bridge.sv
third_party/silicaflux-v/rtl/periph/sfv_periph_misc.sv
third_party/silicaflux-v/rtl/mem/sfv_mem_slaves.sv
third_party/silicaflux-v/rtl/mem/sfv_sram_sp.sv
third_party/silicaflux-v/rtl/mem/sfv_mbist.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_addr_decoder.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_arbiter.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_error_slave.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_req_mux.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_rsp_router.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_crossbar.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_v1_slave_adapter.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_skid_buffer.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_reg_slice.sv
third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv
third_party/silicaflux-sramlib/rtl/mem/backends/fpga/sram_fpga_1rw.sv
third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_asic_array.sv
third_party/silicaflux-sramlib/rtl/mem/sram_backend_1rw.sv
third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv
third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv
rtl/cpu/mcu_cpu.sv
rtl/mem/mcu_sram_bank.sv
rtl/power/mcu_sysctrl.sv
rtl/interrupts/mcu_intc.sv
rtl/uart/mcu_uart.sv
rtl/spi/mcu_spi.sv
rtl/gpio/mcu_gpio.sv
rtl/watchdog/mcu_wdt.sv
rtl/debug/mcu_fault.sv
rtl/debug/mcu_jtag.sv
rtl/debug/mcu_dbg_gate.sv
rtl/timers/mcu_gptimer.sv
rtl/pwm/mcu_pwm.sv
rtl/i2c/mcu_i2c.sv
rtl/dma/mcu_dma.sv
rtl/dsp/mcu_dsp.sv
rtl/top/mcu_soc.sv
rtl/top/mcu_top.sv
