// =============================================================================
// SilicaFlux MCU-I :: mcu_fault -- system-health / fault log (new for MCU-I)
//
// Register map: docs/REGISTERS.md block `fault`.  All state is in the
// POR reset domain, so the log survives soft and watchdog resets and
// firmware can read why the previous run failed.
//
// Event inputs are single-cycle pulses in the system clock domain:
//   dec_evt    crossbar decode error (unmapped / access-matrix / misaligned)
//              with address, master and direction
//   per_evt    peripheral-bridge error response (unimplemented page/offset,
//              sub-word write, RO write, gated peripheral) with address
//   par_evt    SRAM parity error (read response) with address
//   dma_evt, uart_evt, i2c_evt, pwm_evt, ewi_evt, wdt_rst (level)
// Hardware response (deterministic, implemented elsewhere):
//   decode/peripheral/parity errors -> bus error response to the master
//     (CPU: precise load/store/instruction access-fault trap; DMA: transfer
//     stops with ERROR_CODE read/write bus error);
//   watchdog -> system reset; PWM fault -> outputs to SAFE state.
// This block only records and (optionally) interrupts.  CLK_FAULT is a
// reserved bit: there is no clock-monitor hardware, so it is never set.
// =============================================================================
`default_nettype none

module mcu_fault (
  input  wire logic        clk,
  input  wire logic        por_rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  input  wire logic        dec_evt,
  input  wire logic [31:0] dec_addr,
  input  wire logic [1:0]  dec_master,
  input  wire logic        dec_write,
  input  wire logic        per_evt,
  input  wire logic [31:0] per_addr,
  input  wire logic        per_write,
  input  wire logic        par_evt,
  input  wire logic [31:0] par_addr,
  input  wire logic        dma_evt,
  input  wire logic        uart_evt,
  input  wire logic        i2c_evt,
  input  wire logic        pwm_evt,
  input  wire logic        ewi_evt,
  input  wire logic        wdt_rst,
  output logic             irq
);
  localparam logic [11:0] A_STATUS = mcu_memmap_pkg::FAULT_STATUS;
  localparam logic [11:0] A_IRQEN  = mcu_memmap_pkg::FAULT_IRQ_EN;
  localparam logic [11:0] A_SET    = mcu_memmap_pkg::FAULT_SET;
  localparam logic [11:0] A_BUSCNT = mcu_memmap_pkg::FAULT_BUS_ERR_COUNT;
  localparam logic [11:0] A_PARCNT = mcu_memmap_pkg::FAULT_PARITY_ERR_COUNT;
  localparam logic [11:0] A_PERCNT = mcu_memmap_pkg::FAULT_PERIPH_ERR_COUNT;
  localparam logic [11:0] A_LADDR  = mcu_memmap_pkg::FAULT_LAST_ADDR;
  localparam logic [11:0] A_LINFO  = mcu_memmap_pkg::FAULT_LAST_INFO;
  localparam logic [11:0] A_CLRCNT = mcu_memmap_pkg::FAULT_CLEAR_COUNTS;

  logic [11:0] st_q, ien_q;
  logic [31:0] bus_cnt_q, par_cnt_q, per_cnt_q, laddr_q;
  logic [6:0]  linfo_q;
  logic        wdt_q;            // edge detect: wdt_rst is the sticky cause bit
  wire wr = rb_sel && rb_we;

  logic [11:0] ev;
  always_comb begin
    ev = '0;
    ev[0] = dec_evt;  ev[1] = per_evt; ev[2] = par_evt; ev[3] = dma_evt;
    ev[4] = ewi_evt;  ev[5] = wdt_rst && !wdt_q; ev[7] = uart_evt; ev[8] = i2c_evt; ev[9] = pwm_evt;
    // ev[6] BOOT_FAIL, ev[10] SW_FAULT: firmware (SET); ev[11] CLK_FAULT: none
  end

  function automatic logic [31:0] sat_inc(input logic [31:0] c);
    sat_inc = (c == 32'hFFFF_FFFF) ? c : c + 32'd1;
  endfunction

  always_ff @(posedge clk or negedge por_rst_n) begin
    if (!por_rst_n) begin
      st_q <= '0; ien_q <= '0; bus_cnt_q <= '0; par_cnt_q <= '0; per_cnt_q <= '0;
      laddr_q <= '0; linfo_q <= '0; wdt_q <= 1'b0;
    end else begin
      wdt_q <= wdt_rst;
      st_q <= (st_q & ~((wr && rb_addr == A_STATUS) ? rb_wdata[11:0] : 12'd0))
            | ev | ((wr && rb_addr == A_SET) ? (rb_wdata[11:0] & 12'h7FF) : 12'd0);
      if (wr && rb_addr == A_IRQEN) ien_q <= rb_wdata[11:0];
      if (wr && rb_addr == A_CLRCNT && rb_wdata[0]) begin
        bus_cnt_q <= '0; par_cnt_q <= '0; per_cnt_q <= '0;
      end else begin
        if (dec_evt) bus_cnt_q <= sat_inc(bus_cnt_q);
        if (par_evt) par_cnt_q <= sat_inc(par_cnt_q);
        if (per_evt) per_cnt_q <= sat_inc(per_cnt_q);
      end
      // last address: priority parity > peripheral > decode within a cycle
      if (par_evt) begin
        laddr_q <= par_addr; linfo_q <= {1'b0, 2'd0, 4'd3};
      end else if (per_evt) begin
        laddr_q <= per_addr; linfo_q <= {per_write, 2'd0, 4'd2};
      end else if (dec_evt) begin
        laddr_q <= dec_addr; linfo_q <= {dec_write, dec_master, 4'd1};
      end
    end
  end
  assign irq = |(st_q & ien_q);
  wire unused_ok = ^rb_wdata[31:12];

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      A_STATUS: rb_rdata = {20'd0, st_q};
      A_IRQEN:  rb_rdata = {20'd0, ien_q};
      A_SET:    rb_rdata = 32'd0;
      A_BUSCNT: begin rb_rdata = bus_cnt_q; rb_err = rb_we; end
      A_PARCNT: begin rb_rdata = par_cnt_q; rb_err = rb_we; end
      A_PERCNT: begin rb_rdata = per_cnt_q; rb_err = rb_we; end
      A_LADDR:  begin rb_rdata = laddr_q; rb_err = rb_we; end
      A_LINFO:  begin rb_rdata = {25'd0, linfo_q}; rb_err = rb_we; end
      A_CLRCNT: rb_rdata = 32'd0;
      default:  rb_err = 1'b1;
    endcase
  end
endmodule

`default_nettype wire
