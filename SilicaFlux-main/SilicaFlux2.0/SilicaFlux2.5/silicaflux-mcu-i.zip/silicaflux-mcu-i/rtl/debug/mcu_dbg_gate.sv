// =============================================================================
// SilicaFlux MCU-I :: mcu_dbg_gate -- debug access control (new for MCU-I)
//
// Sits between the JTAG system-bus-access master (mcu_jtag_dbg, SFB v1
// req/gnt + rvalid) and the crossbar.  When `locked` (SYSCTRL.DBG_LOCK, set
// by firmware with a key, cleared only by power-on reset):
//   * new SBA requests are not forwarded; they are granted locally and
//     answered one cycle later with err = 1, rdata = 0 (no system side
//     effect, the debugger sees a bus error);
//   * a transaction already forwarded before the lock completes normally
//     (no lost or duplicated responses);
//   * CPU hold, JTAG system reset and boot-mode override are forced inactive.
// IDCODE/BYPASS remain readable (board-level identification / chain test).
// Limits (docs/SECURITY.md): the lock is a firmware policy, not a hardware
// root of trust.  There is no OTP/eFuse, so a device always powers up
// unlocked until the boot ROM or application sets the lock; physical attacks
// are out of scope.  Manufacturing test (scan, test_mode pin) bypasses it.
// =============================================================================
`default_nettype none

module mcu_dbg_gate (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        locked,
  // from the JTAG debug module
  input  wire logic        d_req,
  output logic             d_gnt,
  input  wire logic [31:0] d_addr,
  input  wire logic        d_we,
  input  wire logic [3:0]  d_be,
  input  wire logic [31:0] d_wdata,
  output logic             d_rvalid,
  output logic [31:0]      d_rdata,
  output logic             d_err,
  input  wire logic        d_cpu_hold,
  input  wire logic        d_sys_reset_req,
  input  wire logic        d_boot_ovr,
  // to the crossbar (SFB v1 master)
  output logic             m_req,
  input  wire logic        m_gnt,
  output logic [31:0]      m_addr,
  output logic             m_we,
  output logic [3:0]       m_be,
  output logic [31:0]      m_wdata,
  input  wire logic        m_rvalid,
  input  wire logic [31:0] m_rdata,
  input  wire logic        m_err,
  output logic             cpu_hold,
  output logic             sys_reset_req,
  output logic             boot_ovr
);
  logic busy_q, rej_q;
  wire  block = locked && !busy_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy_q <= 1'b0;
      rej_q  <= 1'b0;
    end else begin
      if (m_req && m_gnt)  busy_q <= 1'b1;
      else if (m_rvalid)   busy_q <= 1'b0;
      rej_q <= d_req && block;
    end
  end

  assign m_req    = d_req && !block;
  assign m_addr   = d_addr;
  assign m_we     = d_we;
  assign m_be     = d_be;
  assign m_wdata  = d_wdata;
  assign d_gnt    = block ? d_req : m_gnt;
  assign d_rvalid = m_rvalid || rej_q;
  assign d_rdata  = rej_q ? 32'd0 : m_rdata;
  assign d_err    = rej_q ? 1'b1 : m_err;

`ifdef FORMAL
  // embedded checker: a locally refused request is answered with an error
  always_comb if (rst_n && rej_q) assert (d_rvalid && d_err && d_rdata == 32'd0);
`endif

  assign cpu_hold      = d_cpu_hold && !locked;
  assign sys_reset_req = d_sys_reset_req && !locked;
  assign boot_ovr      = d_boot_ovr && !locked;
endmodule

`default_nettype wire
