/* SilicaFlux MCU-I trap dispatcher: machine external (INTC claim -> handler),
 * machine timer, machine software interrupts and synchronous exceptions. */
#include "mcu_hal.h"

extern void mcu_trap_entry(void);
static mcu_isr_t isr_tab[16];
static mcu_isr_t timer_isr, soft_isr;
static mcu_exc_handler_t exc_handler;
volatile uint32_t mcu_last_mcause, mcu_last_mtval, mcu_exc_count;

void mcu_trap_init(void) {
  csr_write(mtvec, (uint32_t)(uintptr_t)&mcu_trap_entry);
  csr_set(mie, MIE_MEIE);
}

void mcu_irq_register(int src, mcu_isr_t isr, int prio) {
  if (src < 0 || src > 15) return;
  isr_tab[src] = isr;
  uint32_t reg = (src < 8) ? MCU_INTC_BASE + INTC_PRIO0_OFF : MCU_INTC_BASE + INTC_PRIO1_OFF;
  uint32_t sh = (uint32_t)(src & 7) * 4u;
  uint32_t v = MCU_REG32(reg);
  v = (v & ~(0xFu << sh)) | ((uint32_t)(prio & 7) << sh);
  MCU_REG32(reg) = v;
  INTC_ENABLE |= (1u << src);
}

void mcu_irq_unregister(int src) {
  if (src < 0 || src > 15) return;
  INTC_ENABLE &= ~(1u << src);
  isr_tab[src] = 0;
}

void mcu_set_timer_handler(mcu_isr_t isr) {
  timer_isr = isr;
  if (isr) csr_set(mie, MIE_MTIE); else csr_clear(mie, MIE_MTIE);
}

void mcu_set_soft_handler(mcu_isr_t isr) {
  soft_isr = isr;
  if (isr) csr_set(mie, MIE_MSIE); else csr_clear(mie, MIE_MSIE);
}

void mcu_set_exception_handler(mcu_exc_handler_t h) { exc_handler = h; }

uint32_t mcu_trap_dispatch(uint32_t mcause, uint32_t mepc, uint32_t mtval) {
  if (mcause & 0x80000000u) {
    uint32_t code = mcause & 0x1F;
    if (code == 11) {                       /* MEI: serve until no active source */
      uint32_t id;
      while ((id = INTC_CLAIM & 0xFF) != 0) {
        mcu_isr_t f = isr_tab[id - 1];
        if (f) f();
        else INTC_ENABLE &= ~(1u << (id - 1));   /* unhandled: mask it */
      }
    } else if (code == 7) {
      if (timer_isr) timer_isr(); else mtimer_disable_cmp();
    } else if (code == 3) {
      if (soft_isr) soft_isr(); else MTIMER_MSIP = 0;
    }
    return mepc;
  }
  mcu_last_mcause = mcause;
  mcu_last_mtval = mtval;
  mcu_exc_count++;
  if (exc_handler) return exc_handler(mcause, mepc, mtval);
  con_printf("EXCEPTION mcause=%x mepc=%08x mtval=%08x\n", mcause, mepc, mtval);
  mcu_test_fail(0xEE);
  for (;;) mcu_wfi();
}
