/* SilicaFlux MCU-I HAL: memory helpers, CRC-32, test bookkeeping. */
#include "mcu_hal.h"

volatile uint32_t mcu_check_fails, mcu_check_count;

void *mcu_memset(void *d, int c, size_t n) {
  uint8_t *p = d;
  while (n--) *p++ = (uint8_t)c;
  return d;
}
void *mcu_memcpy(void *d, const void *s, size_t n) {
  uint8_t *p = d;
  const uint8_t *q = s;
  while (n--) *p++ = *q++;
  return d;
}
int mcu_memcmp(const void *a, const void *b, size_t n) {
  const uint8_t *p = a, *q = b;
  for (; n; n--, p++, q++) if (*p != *q) return (int)*p - (int)*q;
  return 0;
}
/* GCC may emit calls to these for struct copies / initialisers */
void *memset(void *d, int c, size_t n) { return mcu_memset(d, c, n); }
void *memcpy(void *d, const void *s, size_t n) { return mcu_memcpy(d, s, n); }

/* CRC-32 (reflected polynomial 0xEDB88320, init/final XOR 0xFFFFFFFF = zlib),
 * nibble table: 64 bytes of constants, 2 table steps per byte. */
static const uint32_t crc_nib[16] = {
  0x00000000u, 0x1DB71064u, 0x3B6E20C8u, 0x26D930ACu, 0x76DC4190u, 0x6B6B51F4u, 0x4DB26158u, 0x5005713Cu,
  0xEDB88320u, 0xF00F9344u, 0xD6D6A3E8u, 0xCB61B38Cu, 0x9B64C2B0u, 0x86D3D2D4u, 0xA00AE278u, 0xBDBDF21Cu};
uint32_t mcu_crc32(uint32_t crc, const void *buf, size_t n) {
  const uint8_t *p = buf;
  crc = ~crc;
  while (n--) {
    crc ^= *p++;
    crc = (crc >> 4) ^ crc_nib[crc & 15];
    crc = (crc >> 4) ^ crc_nib[crc & 15];
  }
  return ~crc;
}

void mcu_test_pass(void) { SYSCTRL_TEST_STATUS = 1; }
void mcu_test_fail(uint32_t code) { SYSCTRL_TEST_STATUS = 2u | ((code & 0xFFu) << 8); }

int mcu_test_finish(const char *name) {
  con_printf("%s: checks=%u fails=%u -> %s\n", name, mcu_check_count, mcu_check_fails,
             mcu_check_fails ? "FAIL" : "PASS");
  uart_flush(MCU_UART0_BASE);
  return mcu_check_fails ? (int)(mcu_check_fails > 255 ? 255 : mcu_check_fails) : 0;
}
