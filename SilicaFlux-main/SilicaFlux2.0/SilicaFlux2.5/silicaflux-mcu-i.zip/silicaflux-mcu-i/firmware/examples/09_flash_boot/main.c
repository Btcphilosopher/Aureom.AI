/* Example 9 -- external SPI flash boot.  This image was copied from the SPI
 * NOR flash by the boot ROM; it identifies the flash, re-reads its own boot
 * header, recomputes the CRC of the code in SRAM, and demonstrates a flash
 * program/erase cycle on a spare sector (testbench flash model / real NOR). */
#include "mcu_hal.h"

extern char _start[], __image_end[];

int main(void) {
  uint32_t bs = SYSCTRL_BOOT_STATUS;
  con_printf("flash_boot: BOOT_STATUS=%08x mode=%u\n", bs, sys_boot_mode());
  CHECK(bs == 0x600D0000u, "booted from SPI flash (mode 0)");
  spi_init(MCU_SPI0_BASE, 0, 0, 8);
  uint32_t id = flash_read_id(MCU_SPI0_BASE, 0);
  con_printf("flash_boot: JEDEC id %06x\n", id);
  CHECK(id != 0 && id != 0xFFFFFF, "flash JEDEC ID");
  uint32_t h[5];
  flash_read(MCU_SPI0_BASE, 0, 0, h, sizeof h);
  CHECK(h[0] == MCU_IMG_MAGIC, "image magic in flash");
  CHECK(h[1] == (uint32_t)(uintptr_t)_start, "load address");
  uint32_t crc = mcu_crc32(0, (const void *)(uintptr_t)h[1], h[2]);
  con_printf("flash_boot: image %u bytes, crc hdr=%08x sram=%08x\n", h[2], h[4], crc);
  CHECK(crc == h[4], "SRAM copy matches the flash image CRC");
  /* program / erase a spare sector at 192 KiB */
  uint8_t w[16], r[16];
  for (int i = 0; i < 16; i++) w[i] = (uint8_t)(0xA0 + i);
  CHECK(flash_sector_erase(MCU_SPI0_BASE, 0, 0x30000) == MCU_OK, "sector erase");
  flash_read(MCU_SPI0_BASE, 0, 0x30000, r, 16);
  CHECK(r[0] == 0xFF && r[15] == 0xFF, "erased");
  CHECK(flash_page_program(MCU_SPI0_BASE, 0, 0x30000, w, 16) == MCU_OK, "page program");
  flash_read(MCU_SPI0_BASE, 0, 0x30000, r, 16);
  CHECK(mcu_memcmp(w, r, 16) == 0, "programmed data read back");
  return mcu_test_finish("flash_boot");
}
