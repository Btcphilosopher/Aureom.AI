/* Example 4 -- SPI loopback in all four modes and three frame lengths.
 * SPI0 CS1: the testbench (and the FPGA board checklist) loops MOSI back to
 * MISO while CS1 is asserted (CS0 is the boot flash).  INDUSTRIAL: SPI1 with
 * MOSI->MISO loopback, plus the RX_AUTO / RX_OVF status behaviour. */
#include "mcu_hal.h"

static void loop_test(uint32_t base, uint32_t cs, const char *name) {
  static const uint32_t pat[3] = {0xA5u, 0x1234u, 0xDEADBEEFu};
  static const uint32_t bits[3] = {8, 16, 32};
  for (uint32_t mode = 0; mode < 4; mode++) {
    for (int l = 0; l < 3; l++) {
      spi_init(base, 1, mode, bits[l]);
      spi_cs(base, cs);
      uint32_t r = spi_xfer(base, pat[l] ^ (mode * 0x11u));
      spi_cs(base, 0);
      CHECK(r == (pat[l] ^ (mode * 0x11u)), "SPI loopback data");
      if (r != (pat[l] ^ (mode * 0x11u)))
        con_printf("  %s mode %u len %u: got %08x\n", name, mode, bits[l], r);
    }
  }
  con_printf("spi: %s loopback, 4 modes x 8/16/32 bits done\n", name);
}

int main(void) {
  loop_test(MCU_SPI0_BASE, 1u << 1, "SPI0/CS1");
  /* busy protection: a DATA write while BUSY is refused with a bus error */
  spi_init(MCU_SPI0_BASE, 20, 0, 32);
  SPI0_DATA = 0x11111111u;
  CHECK(SPI0_STATUS & SPI_STATUS_BUSY, "BUSY during a frame");
  while (SPI0_STATUS & SPI_STATUS_BUSY) {}
  CHECK(SPI0_STATUS & SPI_STATUS_DONE, "DONE after a frame");
  CHECK(SPI0_STATUS & SPI_STATUS_RX_VALID, "RX_VALID after a frame");
  (void)SPI0_DATA;
  CHECK(!(SPI0_STATUS & SPI_STATUS_RX_VALID), "DATA read clears RX_VALID");
#if MCU_CFG_HAS_SPI1
  loop_test(MCU_SPI1_BASE, 1u, "SPI1");
  spi_init(MCU_SPI1_BASE, 0, 0, 8);
  spi_cs(MCU_SPI1_BASE, 1);
  SPI1_DATA = 0x3C; while (SPI1_STATUS & SPI_STATUS_BUSY) {}
  SPI1_DATA = 0x5A; while (SPI1_STATUS & SPI_STATUS_BUSY) {}
  CHECK(SPI1_STATUS & SPI_STATUS_RX_OVF, "RX_OVF when RX_VALID was not consumed");
  CHECK((SPI1_DATA & 0xFF) == 0x5A, "last frame kept");
  SPI1_STATUS = SPI_STATUS_RX_OVF;
  spi_cs(MCU_SPI1_BASE, 0);
#endif
  return mcu_test_finish("spi_loopback");
}
