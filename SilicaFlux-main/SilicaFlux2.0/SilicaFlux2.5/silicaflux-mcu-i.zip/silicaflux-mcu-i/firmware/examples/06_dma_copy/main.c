/* Example 6 -- DMA (INDUSTRIAL): verified memory copy (word and byte
 * elements), concurrent CPU traffic, error cases (unmapped address, peripheral
 * rule, overlap, length alignment, abort), and UART1 transmit/receive paced by
 * DREQ (testbench/board loops UART1 TX back to RX). */
#include "mcu_hal.h"

#if MCU_CFG_HAS_DMA
#define N 256
static uint32_t src[N], dst[N];
static uint8_t txb[32], rxb[32];
#endif

int main(void) {
#if MCU_CFG_HAS_DMA
  for (int i = 0; i < N; i++) { src[i] = 0x5A000000u ^ ((uint32_t)i * 0x01010101u); dst[i] = 0; }
  uint32_t c0 = mcu_cycles();
  CHECK(dma_copy((uint32_t)src, (uint32_t)dst, sizeof src) == MCU_OK, "SRAM->SRAM word copy");
  uint32_t c1 = mcu_cycles();
  CHECK(mcu_memcmp(src, dst, sizeof src) == 0, "copy data correct");
  CHECK(dma_bytes_done() == sizeof src, "BYTES_DONE");
  con_printf("dma: %u bytes in %u cycles (%u cycles/word)\n", (uint32_t)sizeof src, c1 - c0, (c1 - c0) / N);
  /* byte mode, odd length, unaligned addresses */
  mcu_memset(dst, 0, sizeof dst);
  CHECK(dma_start((uint32_t)src + 1, (uint32_t)dst + 3, 37, DMA_BYTE, 0) == MCU_OK && dma_wait() == MCU_OK,
        "byte-mode copy");
  CHECK(mcu_memcmp((uint8_t *)src + 1, (uint8_t *)dst + 3, 37) == 0, "byte-mode data");
  CHECK(((uint8_t *)dst)[2] == 0 && ((uint8_t *)dst)[40] == 0, "no write outside the range");
  /* contention: CPU keeps loading from the same bank during a DMA */
  dma_start((uint32_t)src, (uint32_t)dst, sizeof src, 0, 0);
  uint32_t sum = 0;
  for (int i = 0; i < N; i++) sum += src[i];
  CHECK(dma_wait() == MCU_OK, "DMA completes under CPU contention");
  uint32_t ref = 0;
  for (int i = 0; i < N; i++) ref += dst[i];
  CHECK(sum == ref, "CPU and DMA data consistent");
  /* errors */
  CHECK(dma_copy(0x30000000u, (uint32_t)dst, 16) == -100 - 8, "unmapped source -> read bus error");
  CHECK(DMA_ERROR_ADDR == 0x30000000u, "ERROR_ADDR");
  CHECK(fault_status() & FAULT_STATUS_DMA_ERR, "DMA error logged");
  CHECK(dma_copy((uint32_t)src, 0x00000100u, 16) == -100 - 9, "ROM destination -> write bus error");
  CHECK(dma_copy(MCU_UART0_BASE, (uint32_t)dst, 4) == -100 - 11, "peripheral without DREQ refused");
  CHECK(dma_copy((uint32_t)src, (uint32_t)src + 8, 64) == -100 - 7, "overlap refused");
  CHECK(dma_copy((uint32_t)src, (uint32_t)dst, 6) == -100 - 12, "word mode needs length % 4 == 0");
  CHECK(dma_start((uint32_t)src, MCU_UART1_BASE, 4, DMA_DST_FIXED, 15) == MCU_OK && dma_wait() == -100 - 13,
        "unimplemented DREQ refused");
  fault_clear(FAULT_STATUS_DMA_ERR);
  /* abort while waiting for a DREQ that never comes (UART1 RX empty) */
  dma_start(MCU_UART1_BASE, (uint32_t)rxb, 4, DMA_SRC_FIXED | DMA_BYTE, MCU_DREQ_UART1_RX);
  mtimer_delay(100);
  CHECK(DMA_STATUS & DMA_STATUS_BUSY, "waiting for DREQ");
  dma_abort();
  CHECK(dma_wait() == -100 - 10 && (DMA_STATUS & DMA_STATUS_ABORTED), "abort");
  /* UART1 loopback paced by DREQ: RX DMA armed first, then TX DMA would need a
   * second channel, so TX is done by the CPU here and RX by the DMA */
  uart_init(MCU_UART1_BASE, 16, UART_PARITY_EVEN, 0);
  for (int i = 0; i < 32; i++) txb[i] = (uint8_t)(0x30 + i);
  mcu_memset(rxb, 0, sizeof rxb);
  dma_start(MCU_UART1_BASE, (uint32_t)rxb, 32, DMA_SRC_FIXED | DMA_BYTE, MCU_DREQ_UART1_RX);
  for (int i = 0; i < 32; i++) uart_putc(MCU_UART1_BASE, (char)txb[i]);
  CHECK(dma_wait() == MCU_OK, "UART1 RX DMA complete");
  CHECK(mcu_memcmp(txb, rxb, 32) == 0, "UART1 loopback data via DMA RX");
  /* TX by DMA, RX by CPU */
  dma_start((uint32_t)txb, MCU_UART1_BASE, 32, DMA_DST_FIXED | DMA_BYTE, MCU_DREQ_UART1_TX);
  int ok = 1;
  for (int i = 0; i < 32; i++) ok &= (uart_getc(MCU_UART1_BASE) == txb[i]);
  CHECK(dma_wait() == MCU_OK && ok, "UART1 TX DMA data");
  CHECK((uart_status(MCU_UART1_BASE) & (UART_STATUS_PARITY_ERR | UART_STATUS_FRAME_ERR | UART_STATUS_RX_OVF)) == 0,
        "no UART errors");
#else
  con_printf("dma: not present in %s\n", MCU_VARIANT);
#endif
  return mcu_test_finish("dma_copy");
}
