/* Example 3 -- timer interrupts: machine timer (MTI) periodic interrupt,
 * general-purpose timer through the interrupt controller with priority and
 * threshold, one-shot mode, rollover, software interrupt, WFI with the CPU
 * clock gated, and measured interrupt latency (simulation cycle counts). */
#include "mcu_hal.h"

#define PERIOD 2000u
static volatile uint32_t mti_count, gpt_count0, msi_count, lat_max;
static volatile uint64_t next_cmp;

static void mti_isr(void) {
  uint32_t lat = (uint32_t)(mtimer_now() - next_cmp);   /* mtime ticks = clk cycles (prescale 0) */
  if (lat > lat_max) lat_max = lat;
  mti_count++;
  next_cmp += PERIOD;
  mtimer_set_cmp(next_cmp);
}
static void gpt_isr(void) {
  gpt_count0++;
  gpt_clear(0, GPTIMER_CH_STATUS_OVF | GPTIMER_CH_STATUS_CMP);
}
static void msi_isr(void) { msi_count++; mtimer_soft_irq(0); }

int main(void) {
  /* machine timer */
  mcu_set_timer_handler(mti_isr);
  next_cmp = mtimer_now() + PERIOD;
  mtimer_set_cmp(next_cmp);
  mcu_irq_global_enable();
  while (mti_count < 5) {}
  mtimer_disable_cmp();
  mcu_set_timer_handler(0);
  CHECK(mti_count >= 5, "5 machine-timer interrupts");
  con_printf("timer: MTI x%u, max latency %u cycles (mtime match -> handler)\n", mti_count, lat_max);
  CHECK(lat_max < 200, "MTI latency bounded");

  /* GP timer periodic through INTC */
  mcu_irq_register(MCU_IRQ_GPTIMER, gpt_isr, 3);
  gpt_start(0, 3, 199, GPT_PERIODIC, 1u /* OVF_IE */);
  while (gpt_count0 < 3) {}
  gpt_stop(0);
  CHECK(gpt_count0 >= 3, "3 GP-timer overflow interrupts");
  /* threshold masks priority-3 source */
  INTC_THRESHOLD = 3;
  uint32_t before = gpt_count0;
  gpt_start(0, 0, 99, GPT_PERIODIC, 1u);
  mtimer_delay(600);
  CHECK(gpt_count0 == before, "THRESHOLD=3 masks a priority-3 source");
  CHECK(INTC_PENDING & (1u << MCU_IRQ_GPTIMER), "source still pending in INTC");
  INTC_THRESHOLD = 0;
  while (gpt_count0 == before) {}
  gpt_stop(0);
  mcu_irq_unregister(MCU_IRQ_GPTIMER);
  gpt_clear(0, 0xF);

  /* one-shot + compare + rollover with interrupts off */
  gpt_set_cmp(0, 10);
  gpt_start(0, 0, 50, GPT_ONESHOT, 0);
  mtimer_delay(200);
  CHECK(!(GPTIMER_CH_CTRL(0) & GPTIMER_CH_CTRL_EN), "one-shot clears EN");
  CHECK((gpt_status(0) & 3u) == 3u, "one-shot sets OVF and CMP");
  GPTIMER_CH_RELOAD(0) = 0xFFFFFFFFu;
  GPTIMER_CH_COUNT(0) = 0xFFFFFFF0u;
  gpt_clear(0, 0xF);
  GPTIMER_CH_CTRL(0) = GPTIMER_CH_CTRL_EN;
  mtimer_delay(100);
  gpt_stop(0);
  CHECK(gpt_status(0) & GPTIMER_CH_STATUS_OVF, "32-bit rollover sets OVF");
  CHECK(gpt_count(0) < 0x100u, "counter wrapped to 0");

  /* software interrupt */
  mcu_set_soft_handler(msi_isr);
  mtimer_soft_irq(1);
  mtimer_delay(10);
  CHECK(msi_count == 1, "machine software interrupt");
  mcu_set_soft_handler(0);

  /* low power: WFI with the CPU clock gated, wake by the machine timer */
  sys_clk_enable(SYSCTRL_CLK_EN_CPU_SLEEP_CG, 1);
  mcu_set_timer_handler(mti_isr);
  uint32_t n0 = mti_count, c0 = mcu_cycles();
  next_cmp = mtimer_now() + PERIOD;
  mtimer_set_cmp(next_cmp);
  mcu_wfi();
  uint32_t c1 = mcu_cycles();
  mtimer_disable_cmp();
  sys_clk_enable(SYSCTRL_CLK_EN_CPU_SLEEP_CG, 0);
  CHECK(mti_count == n0 + 1, "woke from gated WFI by timer");
  con_printf("timer: WFI sleep, mcycle advanced %u of ~%u cycles (CPU clock gated)\n", c1 - c0, PERIOD);
  CHECK((c1 - c0) < PERIOD / 2, "mcycle stopped while the CPU clock was gated");
  return mcu_test_finish("timer_irq");
}
