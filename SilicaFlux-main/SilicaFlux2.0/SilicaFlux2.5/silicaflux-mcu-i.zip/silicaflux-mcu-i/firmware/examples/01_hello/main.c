/* Example 1 -- Hello World over UART0: version message and identity registers. */
#include "mcu_hal.h"

int main(void) {
  con_printf("Hello from SilicaFlux MCU-I (%s)\n", MCU_VARIANT);
  con_printf("chip_id=%08x mimpid=%08x misa=%08x features=%08x sram=%u bytes\n", sys_chip_id(),
             csr_read(mimpid), csr_read(misa), sys_features(), sys_sram_size());
  CHECK(sys_chip_id() == MCU_CHIP_ID, "CHIP_ID");
  CHECK(sys_sram_size() == MCU_SRAM_SIZE, "SRAM_SIZE matches configuration");
  CHECK(((sys_features() & SYSCTRL_FEATURES_RV32M) != 0) == (MCU_CFG_RV32M != 0), "FEATURES.RV32M");
  CHECK(((csr_read(misa) >> 12) & 1u) == (MCU_CFG_RV32M != 0), "misa.M");
  CHECK((SYSCTRL_BOOT_STATUS & 0xFFFF0000u) == 0x600D0000u, "booted by the ROM");
  return mcu_test_finish("hello");
}
