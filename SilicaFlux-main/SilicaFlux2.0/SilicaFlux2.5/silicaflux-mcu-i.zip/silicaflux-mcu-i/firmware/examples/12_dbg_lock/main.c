/* Example 12 -- debug access control: the application locks JTAG system-bus
 * access, CPU hold and JTAG reset (SYSCTRL.DBG_LOCK, cleared only by power-on
 * reset).  The testbench (+jtag=2) then verifies that SBA accesses return a
 * bus error while IDCODE stays readable. */
#include "mcu_hal.h"

int main(void) {
  CHECK((SYSCTRL_DBG_LOCK & 1u) == 0, "unlocked after power-on");
  SYSCTRL_DBG_LOCK = 0x12345678u;                 /* wrong key: no effect */
  CHECK((SYSCTRL_DBG_LOCK & 1u) == 0, "wrong key ignored");
  sys_debug_lock();
  CHECK((SYSCTRL_DBG_LOCK & 1u) == 1, "locked with the key");
  SYSCTRL_DBG_LOCK = 0;                           /* cannot unlock */
  CHECK((SYSCTRL_DBG_LOCK & 1u) == 1, "lock is sticky");
  con_printf("dbg_lock: JTAG system access locked; waiting for host probe\n");
  mtimer_delay(400000);
  return mcu_test_finish("dbg_lock");
}
