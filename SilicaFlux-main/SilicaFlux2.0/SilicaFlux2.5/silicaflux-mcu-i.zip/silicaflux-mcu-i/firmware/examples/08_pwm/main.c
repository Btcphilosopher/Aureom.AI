/* Example 8 -- PWM waveform (INDUSTRIAL): 25 % duty on channel 0, measured by
 * GP-timer input capture (testbench/board: pwm[0] -> gpio[5] = capture
 * channel 1), shadowed duty update, polarity, and the fault input (gpio[9]
 * drives pwm_fault_i in the testbench) forcing the safe state. */
#include "mcu_hal.h"

#if MCU_CFG_HAS_PWM
/* time between two capture edges of the given kinds on channel 1 */
static uint32_t edge_delta(uint32_t first, uint32_t second) {
  gpt_start(1, 0, 0xFFFFFFFFu, GPT_PERIODIC, 0);
  gpt_capture_config(1, first);
  gpt_clear(1, 0xF);
  while (!(gpt_status(1) & GPTIMER_CH_STATUS_CAP)) {}
  uint32_t a = gpt_capture(1);
  gpt_capture_config(1, second);
  gpt_clear(1, 0xF);
  while (!(gpt_status(1) & GPTIMER_CH_STATUS_CAP)) {}
  uint32_t b = gpt_capture(1);
  gpt_stop(1);
  return b - a;
}
#endif

int main(void) {
#if MCU_CFG_HAS_PWM
  CHECK((PWM_OUT_EN | PWM_CTRL) == 0, "reset state: disabled");
  pwm_init(1, 399);                       /* period = 400 x 2 = 800 clk */
  pwm_set_duty(0, 100);                   /* 25 % */
  pwm_set_duty(1, 300);                   /* 75 % */
  pwm_outputs(0x3, 0x0, 0x0);
  pwm_start(1);
  uint32_t per = edge_delta(1, 1), hi = edge_delta(1, 2);
  con_printf("pwm: ch0 period=%u high=%u cycles\n", per, hi);
  CHECK(per == 800, "period = (TOP+1)(PRESCALE+1)");
  CHECK(hi == 200, "25 % duty");
  pwm_set_duty(0, 200);                   /* shadowed: applied at the next period */
  mtimer_delay(1700);
  hi = edge_delta(1, 2);
  CHECK(hi == 400, "duty update to 50 %");
  /* fault input -> safe state */
  gpio_set_dir(1u << 9, 1u << 9);
  gpio_clear(1u << 9);
  pwm_outputs(0x3, 0x2, 0x0);             /* safe: ch0 low, ch1 high */
  pwm_fault_config(1, 1, 0);
  gpio_set(1u << 9);                      /* fault asserted */
  mtimer_delay(20);
  CHECK(pwm_status() & PWM_STATUS_FAULT, "fault latched");
  CHECK((gpio_read() & (1u << 5)) == 0, "ch0 forced to its safe level (low)");
  CHECK(pwm_fault_clear() == MCU_EBUSY, "fault cannot be cleared while active");
  CHECK(fault_status() & FAULT_STATUS_PWM_FAULT, "PWM fault logged");
  gpio_clear(1u << 9);
  mtimer_delay(20);
  CHECK(pwm_fault_clear() == MCU_OK, "fault cleared after the input is released");
  per = edge_delta(1, 1);
  CHECK(per == 800, "PWM resumes after fault clear");
  fault_clear(FAULT_STATUS_PWM_FAULT);
  /* polarity inversion */
  pwm_outputs(0x3, 0x0, 0x1);
  mtimer_delay(1700);
  hi = edge_delta(1, 2);
  CHECK(hi == 400, "inverted 50 % -> 50 % high");
  pwm_start(0);
  mtimer_delay(10);
  CHECK((gpio_read() & (1u << 5)) == 0, "disabled -> safe level");
#else
  con_printf("pwm: not present in %s\n", MCU_VARIANT);
#endif
  return mcu_test_finish("pwm");
}
