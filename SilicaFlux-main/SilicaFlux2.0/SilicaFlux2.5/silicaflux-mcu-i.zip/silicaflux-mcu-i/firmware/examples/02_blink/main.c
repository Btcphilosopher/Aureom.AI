/* Example 2 -- GPIO blinking: gpio[8] toggles (board LED); the testbench and
 * the FPGA board checklist loop gpio[8] back to gpio[4].  Also exercises the
 * atomic SET/CLR/TGL registers and edge/level interrupts on gpio[3] driven by
 * gpio[2] through a loopback. */
#include "mcu_hal.h"

static volatile uint32_t edges;
static void gpio_isr(void) {
  uint32_t p = GPIO_IRQ_PEND;
  if (p & (1u << 3)) edges++;
  gpio_irq_clear(p);
}

int main(void) {
  gpio_set_dir((1u << 8) | (1u << 2), (1u << 8) | (1u << 2));
  for (int i = 0; i < 6; i++) {
    gpio_toggle(1u << 8);
    mtimer_delay(200);
    uint32_t want = (GPIO_OUT >> 8) & 1u;
    CHECK(((gpio_read() >> 4) & 1u) == want, "gpio[8] -> gpio[4] loopback follows the LED");
  }
  gpio_set(1u << 8);  CHECK(GPIO_OUT & (1u << 8), "OUT_SET");
  gpio_clear(1u << 8); CHECK(!(GPIO_OUT & (1u << 8)), "OUT_CLR");
  /* edge interrupts: gpio[2] -> gpio[3] loopback */
  gpio_clear(1u << 2);
  mtimer_delay(20);
  gpio_irq_config(1u << 3, GPIO_IRQ_RISE | GPIO_IRQ_FALL);
  gpio_irq_clear(0xFFFFFFFFu);
  mcu_irq_register(MCU_IRQ_GPIO, gpio_isr, 2);
  mcu_irq_global_enable();
  for (int i = 0; i < 4; i++) { gpio_toggle(1u << 2); mtimer_delay(50); }
  CHECK(edges == 4, "4 GPIO edge interrupts");
  /* level interrupt: pending while high, not latched */
  gpio_irq_config(1u << 3, GPIO_IRQ_HIGH);
  gpio_clear(1u << 2); mtimer_delay(20);
  CHECK((gpio_irq_pending() & (1u << 3)) == 0, "level low -> not pending");
  mcu_irq_global_disable();
  gpio_set(1u << 2); mtimer_delay(20);
  CHECK((gpio_irq_pending() & (1u << 3)) != 0, "level high -> pending");
  gpio_irq_config(1u << 3, 0);
  con_printf("blink: done, edge irqs=%u\n", edges);
  return mcu_test_finish("blink");
}
