/* Example 7 -- watchdog reset demonstration.
 * Run 1 (after power-on): legal service keeps the watchdog alive; then the
 * "firmware hangs", the early-warning interrupt fires, the watchdog resets the
 * system.  The boot ROM boots the image again.  Run 2: RESET_CAUSE.WDT, the
 * fault log (POR domain) and BOOT_STATUS show what happened -> pass. */
#include "mcu_hal.h"

static volatile uint32_t ewi_seen;
static void wdt_isr(void) {
  ewi_seen = 1;
  SYSCTRL_SCRATCH0 = 0xE771u;      /* note: SCRATCH regs are reset by the WDT reset */
  WDT_CTRL = WDT_CTRL & ~WDT_CTRL_EWI_EN;    /* keep the level source quiet */
}

int main(void) {
  uint32_t cause = sys_reset_cause();
  con_printf("watchdog: reset_cause=%x wdt_resets=%u fault=%x\n", cause & 0xF, (cause >> 8) & 0xFF,
             fault_status());
  if (cause & SYSCTRL_RESET_CAUSE_WDT) {
    CHECK(fault_status() & FAULT_STATUS_WDT_RESET, "fault log recorded the watchdog reset");
    CHECK(fault_status() & FAULT_STATUS_WDT_EWI, "fault log recorded the early warning");
    CHECK(((cause >> 8) & 0xFF) == 1, "one watchdog reset since POR");
    CHECK(!(WDT_STATUS & WDT_STATUS_RUNNING), "watchdog disabled after reset");
    sys_reset_cause_clear(0xF);
    fault_clear(0xFFF);
    con_printf("watchdog: recovered from a firmware hang by watchdog reset\n");
    return mcu_test_finish("watchdog");
  }
  /* run 1 */
  CHECK(cause & SYSCTRL_RESET_CAUSE_POR, "first run after power-on");
  mcu_irq_register(MCU_IRQ_WDT, wdt_isr, 7);
  mcu_irq_global_enable();
  wdt_start(4000, 0, 1000, 1, 1);
  for (int i = 0; i < 5; i++) { mtimer_delay(2000); wdt_service(); }
  CHECK(!ewi_seen, "serviced watchdog does not warn");
  WDT_LOAD = 1;                                   /* locked: refused with a bus error */
  CHECK(WDT_LOAD == 4000, "LOCK protects LOAD");
  con_printf("watchdog: simulating a hang (no more service)\n");
  uart_flush(MCU_UART0_BASE);
  for (;;) {}                                     /* EWI interrupt, then reset */
}
