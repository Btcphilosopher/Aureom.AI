/* FPGA / board demonstration (docs/FPGA.md checklist): version message, SRAM
 * self-test, timer interrupts, SPI loopback, DMA copy, GPIO + PWM outputs,
 * fault log and a serviced watchdog.  Prints one PASS/FAIL line per step and
 * a final summary; also runs in the simulation regression. */
#include "mcu_hal.h"

static volatile uint32_t ticks;
static uint64_t nxt;
static void mti(void) { ticks++; nxt += 1000; mtimer_set_cmp(nxt); gpio_toggle(1u << 8); }

static void step(const char *name, int ok) {
  CHECK(ok, name);
  con_printf("[%s] %s\n", ok ? "PASS" : "FAIL", name);
}

static uint32_t buf_a[512], buf_b[512];

int main(void) {
  con_printf("\n=== SilicaFlux MCU-I %s demo, chip %08x, RTL rev %u ===\n", MCU_VARIANT, sys_chip_id(),
             sys_chip_id() & 0xFF);
  /* SRAM self-test on the demo buffers (walking pattern + byte/half lanes) */
  int ok = 1;
  for (int i = 0; i < 512; i++) buf_a[i] = 0xA5A50000u ^ (uint32_t)i;
  for (int i = 0; i < 512; i++) ok &= (buf_a[i] == (0xA5A50000u ^ (uint32_t)i));
  ((volatile uint8_t *)buf_a)[1] = 0x5A;
  ((volatile uint16_t *)buf_a)[1] = 0xBEEF;
  ok &= (buf_a[0] == 0xBEEF5A00u);
  step("SRAM self-test", ok);
  /* watchdog: serviced in the timer loop below */
  wdt_start(200000, 0, 0, 0, 0);
  /* timers + interrupts, LED blink on gpio[8] */
  gpio_set_dir(1u << 8, 1u << 8);
  mcu_set_timer_handler(mti);
  nxt = mtimer_now() + 1000;
  mtimer_set_cmp(nxt);
  mcu_irq_global_enable();
  while (ticks < 10) wdt_service();
  mtimer_disable_cmp();
  step("timer interrupts (10 x MTI)", ticks >= 10);
  /* SPI loopback (SPI0 CS1 jumper) */
  spi_init(MCU_SPI0_BASE, 2, 0, 8);
  spi_cs(MCU_SPI0_BASE, 1u << 1);
  ok = 1;
  for (uint32_t v = 0; v < 16; v++) ok &= (spi_xfer(MCU_SPI0_BASE, v * 17u) == v * 17u);
  spi_cs(MCU_SPI0_BASE, 0);
  step("SPI0 loopback", ok);
#if MCU_CFG_HAS_DMA
  for (int i = 0; i < 512; i++) { buf_a[i] = (uint32_t)i * 2654435761u; buf_b[i] = 0; }
  step("DMA 2 KiB memory copy", dma_copy((uint32_t)buf_a, (uint32_t)buf_b, sizeof buf_a) == MCU_OK &&
                                mcu_memcmp(buf_a, buf_b, sizeof buf_a) == 0);
#else
  (void)buf_b;
#endif
#if MCU_CFG_HAS_PWM
  pwm_init(0, 999);
  pwm_set_duty(0, 250); pwm_set_duty(1, 500); pwm_set_duty(2, 750); pwm_set_duty(3, 1000);
  pwm_outputs(0xF, 0, 0);
  pwm_start(1);
  step("PWM outputs running (25/50/75/100 %)", (PWM_CTRL & PWM_CTRL_EN) != 0);
#endif
  wdt_service();
  /* fault path: one deliberate decode error, logged and survivable */
  FAULT_CLEAR_COUNTS = 1;
  fault_clear(0xFFF);
  uint32_t n0 = FAULT_BUS_ERR_COUNT;
  (void)n0;
  step("fault log readable", (FAULT_STATUS & 0x800u) == 0);
  step("watchdog running and serviced", (WDT_STATUS & WDT_STATUS_RUNNING) && wdt_count() > 100000);
  con_printf("demo: reset_cause=%x boot_status=%08x\n", sys_reset_cause(), SYSCTRL_BOOT_STATUS);
  return mcu_test_finish("demo");
}
