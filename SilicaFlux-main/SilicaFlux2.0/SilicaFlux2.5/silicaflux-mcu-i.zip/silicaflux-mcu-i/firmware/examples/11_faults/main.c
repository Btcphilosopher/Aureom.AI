/* Example 11 -- deterministic fault handling: bus errors, exceptions, fault
 * log, clock-gated peripheral access, SRAM parity (INDUSTRIAL). */
#include "mcu_hal.h"

static volatile uint32_t skipped;
static uint32_t skip_handler(uint32_t mcause, uint32_t mepc, uint32_t mtval) {
  (void)mcause; (void)mtval;
  skipped++;
  return mepc + 4;                         /* skip the faulting instruction (no C extension) */
}
static volatile uint32_t sink;

int main(void) {
  mcu_set_exception_handler(skip_handler);
  fault_clear(0xFFF);
  FAULT_CLEAR_COUNTS = 1;
  uint32_t n0 = mcu_exc_count;
  sink = MCU_REG32(0x30000000u);           /* unmapped */
  CHECK(mcu_exc_count == n0 + 1 && mcu_last_mcause == 5, "unmapped load -> load access fault");
  CHECK(mcu_last_mtval == 0x30000000u, "mtval = faulting address");
  CHECK(fault_status() & FAULT_STATUS_BUS_DECODE, "decode error logged");
  CHECK(FAULT_LAST_ADDR == 0x30000000u && (FAULT_LAST_INFO & 0xF) == 1, "fault log address/source");
  CHECK(SYSCTRL_BUSERR_INFO & 1, "SYSCTRL first-error capture");
  SYSCTRL_BUSERR_INFO = 1;
  MCU_REG32(0x00000100u) = 1;              /* ROM write */
  CHECK(mcu_last_mcause == 7, "ROM write -> store access fault");
  *(volatile uint8_t *)(MCU_GPIO_BASE + GPIO_OUT_OFF) = 1;   /* sub-word peripheral write */
  CHECK(mcu_last_mcause == 7 && (fault_status() & FAULT_STATUS_PERIPH_ERR), "sub-word peripheral write refused");
  sink = MCU_REG32(MCU_PERIPH_BASE + 0x1F000u);              /* absent page */
  CHECK(mcu_last_mcause == 5, "absent peripheral page -> access fault");
  sink = MCU_REG32(MCU_SRAM_BASE + MCU_SRAM_SIZE);           /* just above SRAM */
  CHECK(mcu_last_mcause == 5, "address above configured SRAM -> access fault");
  {                                                          /* misaligned (inline asm: GCC would */
    uint32_t a = MCU_SRAM_BASE + 2, v;                       /* split a C access into halfwords)  */
    __asm__ volatile("lw %0, 0(%1)" : "=r"(v) : "r"(a));
    sink = v;
  }
  CHECK(mcu_last_mcause == 4, "misaligned load -> address-misaligned exception");
  __asm__ volatile(".word 0xFFFFFFFF");
  CHECK(mcu_last_mcause == 2, "illegal instruction");
  __asm__ volatile("ecall");
  CHECK(mcu_last_mcause == 11, "ecall");
  /* jump into the peripheral window: execute-never -> instruction access fault */
  CHECK(FAULT_BUS_ERR_COUNT >= 2, "decode error counter");
  /* clock-gated peripheral returns bus errors */
  uart_flush(MCU_UART0_BASE);              /* gating a busy UART would freeze it mid-byte */
  sys_clk_enable(SYSCTRL_CLK_EN_UART0, 0);
  sink = UART0_STATUS;
  CHECK(mcu_last_mcause == 5, "gated UART0 -> access fault");
  sys_clk_enable(SYSCTRL_CLK_EN_UART0, 1);
#if MCU_CFG_SRAM_PARITY
  static volatile uint32_t victim[4];
  victim[1] = 0x12345678u;
  sys_parity_inject_next_write();
  victim[1] = 0xCAFEF00Du;                  /* stored with inverted parity */
  sink = victim[1];
  CHECK(mcu_last_mcause == 5, "parity error -> load access fault");
  CHECK(fault_status() & FAULT_STATUS_SRAM_PARITY, "parity error logged");
  CHECK(FAULT_PARITY_ERR_COUNT == 1 && FAULT_LAST_ADDR == (uint32_t)&victim[1], "parity address");
  victim[1] = 0xCAFEF00Du;                  /* rewrite heals the word */
  CHECK(victim[1] == 0xCAFEF00Du, "rewritten word reads correctly");
#endif
  con_printf("faults: %u exceptions handled\n", skipped);
  fault_report();
  mcu_set_exception_handler(0);
  return mcu_test_finish("faults");
}
