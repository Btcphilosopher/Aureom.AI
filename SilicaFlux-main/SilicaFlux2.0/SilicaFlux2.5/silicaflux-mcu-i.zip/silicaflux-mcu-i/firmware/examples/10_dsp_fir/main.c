/* Example 10 -- DSP filtering (INDUSTRIAL, optional accelerator): MAC, DOT2,
 * Q15 multiply, saturating add and a 16-tap FIR, each compared bit-exactly
 * with the C reference model, plus a cycle benchmark of the same FIR on the
 * CPU (RV32I software multiply or RV32IM) vs the accelerator. */
#include "mcu_hal.h"

#define NT 16
#define NS 64
static const int16_t coef[NT] = {-120, 340, -900, 2100, -4100, 6900, 10200, 13000,
                                 13000, 10200, 6900, -4100, 2100, -900, 340, -120};
static int16_t x[NS];
static int32_t y_hw[NS], y_sw[NS];

#if MCU_CFG_HAS_DSP
static volatile uint32_t busy_faults;
static uint32_t skip_store(uint32_t mcause, uint32_t mepc, uint32_t mtval) {
  (void)mcause; (void)mtval;
  busy_faults++;
  return mepc + 4;
}
#endif

static uint32_t lcg = 12345;
static int16_t rnd16(void) { lcg = lcg * 1103515245u + 12345u; return (int16_t)(lcg >> 16); }

int main(void) {
  for (int i = 0; i < NS; i++) x[i] = rnd16();
  /* software FIR (reference model, saturating) */
  int16_t hist[NT] = {0};
  int ovf_sw = 0;
  uint32_t c0 = mcu_cycles();
  for (int n = 0; n < NS; n++) {
    for (int k = NT - 1; k > 0; k--) hist[k] = hist[k - 1];
    hist[0] = x[n];
    y_sw[n] = dsp_ref_fir(coef, hist, NT, 1, &ovf_sw);
  }
  uint32_t c_sw = mcu_cycles() - c0;
  con_printf("dsp: software FIR %u taps x %u samples: %u cycles (%s)\n", NT, NS, c_sw,
             MCU_CFG_RV32M ? "RV32IM" : "RV32I");
  /* best-case software baseline: plain wrapping MAC loop (no saturation) */
  {
    int16_t h2[NT] = {0};
    volatile int32_t sink = 0;
    uint32_t p0 = mcu_cycles();
    for (int n = 0; n < NS; n++) {
      for (int k = NT - 1; k > 0; k--) h2[k] = h2[k - 1];
      h2[0] = x[n];
      int32_t acc = 0;
      for (int k = 0; k < NT; k++) acc += (int32_t)coef[k] * (int32_t)h2[k];
      sink = acc;
    }
    (void)sink;
    con_printf("dsp: plain C FIR (no saturation): %u cycles\n", mcu_cycles() - p0);
  }
#if MCU_CFG_HAS_DSP
  dsp_config(1, 1, 15);
  dsp_fir_init(coef, NT);
  c0 = mcu_cycles();
  for (int n = 0; n < NS; n++) y_hw[n] = dsp_fir_push(x[n]);
  uint32_t c_hw = mcu_cycles() - c0;
  int same = 1;
  for (int n = 0; n < NS; n++) same &= (y_hw[n] == y_sw[n]);
  CHECK(same, "accelerator FIR == reference model (bit exact)");
  CHECK(((dsp_status() & DSP_STATUS_OVF) != 0) == (ovf_sw != 0), "overflow flag matches the model");
  con_printf("dsp: accelerator FIR: %u cycles -> speed-up x%u.%u\n", c_hw, c_sw / c_hw, (10u * c_sw / c_hw) % 10u);
  /* scalar operations vs model */
  int ov = 0;
  dsp_clear_ovf();
  dsp_config(1, 1, 8);
  dsp_acc_set(0x7FFF0000);
  dsp_mac(32767, 32767);                                   /* overflows -> saturates */
  CHECK(dsp_acc_get() == dsp_ref_add_sat(0x7FFF0000, 32767 * 32767, 1, &ov), "MAC saturation");
  CHECK((dsp_status() & DSP_STATUS_OVF) && ov, "MAC overflow flag");
  dsp_clear_ovf();
  dsp_acc_set(1000);
  dsp_dot2(0x0003FFFEu, 0x00050007u);                      /* a=(3,-2) b=(5,7): 1000 + (-14) + 15 */
  CHECK(dsp_acc_get() == 1001, "DOT2");
  CHECK(dsp_acc_q() == dsp_ref_sat16_shr(1001, 8, 1), "ACC_Q shift/round/saturate");
  int failq = 0;
  for (int i = 0; i < 64; i++) {
    int16_t a = rnd16(), b = rnd16();
    int o = 0;
    failq += dsp_mulq15(a, b) != dsp_ref_mulq15(a, b, 1, &o);
  }
  CHECK(failq == 0, "MULQ (Q15) == model for 64 random pairs");
  CHECK(dsp_mulq15(-32768, -32768) == 32767, "Q15 -1 * -1 saturates");
  CHECK(dsp_sadd16(30000, 10000) == 32767 && dsp_sadd16(-30000, -10000) == -32768, "saturating add");
  /* busy protection: a command written while BUSY is refused with a bus
   * error (store access fault) and has no effect */
  mcu_set_exception_handler(skip_store);
  int32_t before = (int32_t)DSP_FIR_OUT;
  (void)before;
  DSP_FIR_IN = 1;
  DSP_FIR_IN = 2;                                          /* second write while BUSY */
  while (dsp_status() & DSP_STATUS_BUSY) {}
  mcu_set_exception_handler(0);
  CHECK(busy_faults == 1 && mcu_last_mcause == 7, "write while BUSY -> bus error (store access fault)");
#else
  (void)y_hw;
  con_printf("dsp: accelerator not present in %s (software path only)\n", MCU_VARIANT);
  CHECK(ovf_sw == 0 || ovf_sw == 1, "software model ran");
#endif
  return mcu_test_finish("dsp_fir");
}
