/* Example 5 -- I2C peripheral communication (INDUSTRIAL).  Testbench devices:
 * 0x50 = 256-byte EEPROM model (auto-increment pointer), 0x48 = sensor model
 * that stretches SCL; no device at 0x23 (NACK).  Board: any 24Cxx EEPROM. */
#include "mcu_hal.h"

int main(void) {
#if MCU_CFG_HAS_I2C
  uint32_t b = MCU_I2C0_BASE;
  i2c_init(b, 7, 20000);            /* f_SCL = clk / 32 */
  CHECK(i2c_probe(b, 0x50) == MCU_OK, "EEPROM ACKs its address");
  CHECK(i2c_probe(b, 0x23) == MCU_ENACK, "absent device NACKs");
  uint8_t w[5] = {0x10, 0xC0, 0xFF, 0xEE, 0x42};       /* pointer 0x10 + 4 data bytes */
  CHECK(i2c_write(b, 0x50, w, 5, 1) == MCU_OK, "EEPROM write");
  uint8_t ptr = 0x10, r[4] = {0};
  CHECK(i2c_write_read(b, 0x50, &ptr, 1, r, 4) == MCU_OK, "EEPROM read with repeated START");
  CHECK(r[0] == 0xC0 && r[1] == 0xFF && r[2] == 0xEE && r[3] == 0x42, "EEPROM data read back");
  con_printf("i2c: eeprom readback %x %x %x %x\n", r[0], r[1], r[2], r[3]);
  uint8_t s[2] = {0};
  uint8_t reg = 0x00;
  uint32_t c0 = mcu_cycles();
  CHECK(i2c_write_read(b, 0x48, &reg, 1, s, 2) == MCU_OK, "sensor read (clock stretching)");
  uint32_t c1 = mcu_cycles();
  CHECK(s[0] == 0x1A && s[1] == 0x2B, "sensor value");
  con_printf("i2c: sensor %x %x in %u cycles\n", s[0], s[1], c1 - c0);
  /* timeout: sensor register 0x7F makes the model hold SCL low "forever" */
  I2C0_TIMEOUT = 2000;
  reg = 0x7F;
  int rc = i2c_write_read(b, 0x48, &reg, 1, s, 1);
  CHECK(rc == MCU_ETIMEOUT, "clock-stretch timeout detected");
  CHECK(fault_status() & FAULT_STATUS_I2C_ERR, "I2C error logged in FAULT");
  fault_clear(FAULT_STATUS_I2C_ERR);
  /* bus recovers after the model releases SCL */
  mtimer_delay(30000);
  I2C0_TIMEOUT = 20000;
  CHECK(i2c_probe(b, 0x50) == MCU_OK, "bus usable after timeout");
#else
  con_printf("i2c: not present in %s\n", MCU_VARIANT);
#endif
  return mcu_test_finish("i2c");
}
