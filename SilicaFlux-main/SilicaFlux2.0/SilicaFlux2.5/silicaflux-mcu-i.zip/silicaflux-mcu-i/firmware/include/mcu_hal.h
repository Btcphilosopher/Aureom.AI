/* =============================================================================
 * SilicaFlux MCU-I hardware abstraction layer -- public C API
 *
 * Bare-metal, no libc.  Every function is documented here; register-level
 * definitions come from mcu_regs.h (generated from configs/memmap.yaml) and
 * the configuration from mcu_config.h (generated from configs/<variant>.yaml,
 * force-included by the build).  Multi-instance peripherals take the
 * instance base address (MCU_UART0_BASE, MCU_SPI1_BASE, ...).
 * Return conventions: 0 = success, negative = error (MCU_E*).
 * ===========================================================================*/
#ifndef MCU_HAL_H
#define MCU_HAL_H

#include <stdint.h>
#include <stddef.h>
#include "mcu_regs.h"

#ifndef MCU_CLK_HZ
#define MCU_CLK_HZ 25000000u            /* board oscillator (ULX3S: 25 MHz) */
#endif

#define MCU_OK        0
#define MCU_EINVAL   (-1)
#define MCU_ETIMEOUT (-2)
#define MCU_ENACK    (-3)
#define MCU_EBUS     (-4)
#define MCU_EBUSY    (-5)
#define MCU_ENODEV   (-6)

#define REG(base, off) MCU_REG32((base) + (off))

/* ------------------------------------------------------------------ CPU / CSR */
#define csr_read(csr) ({ uint32_t __v; __asm__ volatile("csrr %0, " #csr : "=r"(__v)); __v; })
#define csr_write(csr, v) __asm__ volatile("csrw " #csr ", %0" ::"rK"(v))
#define csr_set(csr, v) __asm__ volatile("csrs " #csr ", %0" ::"rK"(v))
#define csr_clear(csr, v) __asm__ volatile("csrc " #csr ", %0" ::"rK"(v))
#define MSTATUS_MIE (1u << 3)
#define MIE_MSIE (1u << 3)
#define MIE_MTIE (1u << 7)
#define MIE_MEIE (1u << 11)

static inline uint32_t mcu_cycles(void) { return csr_read(mcycle); }
static inline uint32_t mcu_instret(void) { return csr_read(minstret); }
static inline void mcu_wfi(void) { __asm__ volatile("wfi"); }
static inline void mcu_fence_i(void) { __asm__ volatile("fence.i" ::: "memory"); }
static inline void mcu_irq_global_enable(void) { csr_set(mstatus, MSTATUS_MIE); }
static inline void mcu_irq_global_disable(void) { csr_clear(mstatus, MSTATUS_MIE); }

/* ------------------------------------------------------------------ traps (hal/trap.c) */
typedef void (*mcu_isr_t)(void);
/* Exception hook: return the PC to resume at (e.g. epc + 4 to skip). */
typedef uint32_t (*mcu_exc_handler_t)(uint32_t mcause, uint32_t mepc, uint32_t mtval);
void mcu_trap_init(void);                                    /* mtvec -> HAL trap entry */
void mcu_irq_register(int src, mcu_isr_t isr, int prio);    /* INTC source handler + enable */
void mcu_irq_unregister(int src);
void mcu_set_timer_handler(mcu_isr_t isr);                   /* MTI (enables mie.MTIE) */
void mcu_set_soft_handler(mcu_isr_t isr);                    /* MSI (enables mie.MSIE) */
void mcu_set_exception_handler(mcu_exc_handler_t h);         /* NULL = report and fail */
extern volatile uint32_t mcu_last_mcause, mcu_last_mtval, mcu_exc_count;

/* ------------------------------------------------------------------ system (drivers/sysctrl.c) */
uint32_t sys_chip_id(void);
uint32_t sys_features(void);
uint32_t sys_sram_size(void);
uint32_t sys_boot_mode(void);
uint32_t sys_reset_cause(void);                 /* SYSCTRL.RESET_CAUSE raw */
void     sys_reset_cause_clear(uint32_t bits);
void     sys_soft_reset(void) __attribute__((noreturn));
void     sys_clk_enable(uint32_t mask, int on); /* SYSCTRL_CLK_EN_* bits */
int      sys_mbist_run(int checkerboard);       /* 0 pass, MCU_EBUS fail (destroys SRAM!) */
void     sys_parity_enable(int on);
void     sys_parity_inject_next_write(void);
void     sys_debug_lock(void);                  /* irreversible until power-on reset */
void     mcu_test_pass(void);                   /* TEST_STATUS = pass (status pins) */
void     mcu_test_fail(uint32_t code);          /* TEST_STATUS = fail | code << 8 */

/* ------------------------------------------------------------------ UART (drivers/uart.c) */
#define UART_PARITY_NONE 0u
#define UART_PARITY_EVEN 1u
#define UART_PARITY_ODD  2u
void uart_init(uint32_t base, uint32_t baud_div, uint32_t parity, int stop2); /* baud_div 0 = keep */
void uart_putc(uint32_t base, char c);          /* blocks while TX FIFO full */
int  uart_getc(uint32_t base);                  /* blocks; returns byte */
int  uart_try_getc(uint32_t base);              /* -1 if empty */
void uart_puts(uint32_t base, const char *s);
void uart_flush(uint32_t base);                 /* wait TX_IDLE */
uint32_t uart_status(uint32_t base);
/* console on UART0 (drivers/console.c) */
void con_puts(const char *s);
void con_putc(char c);
void con_printf(const char *fmt, ...);          /* %c %s %d %u %x %X %08x %p */

/* ------------------------------------------------------------------ GPIO (drivers/gpio.c) */
void     gpio_set_dir(uint32_t out_mask, uint32_t oe);  /* oe bits for out_mask pins */
void     gpio_write(uint32_t mask, uint32_t value);
void     gpio_set(uint32_t mask);
void     gpio_clear(uint32_t mask);
void     gpio_toggle(uint32_t mask);
uint32_t gpio_read(void);
#define GPIO_IRQ_RISE 1u
#define GPIO_IRQ_FALL 2u
#define GPIO_IRQ_HIGH 4u
#define GPIO_IRQ_LOW  8u
void     gpio_irq_config(uint32_t mask, uint32_t kinds);
uint32_t gpio_irq_pending(void);
void     gpio_irq_clear(uint32_t mask);

/* ------------------------------------------------------------------ timers (drivers/timer.c) */
uint64_t mtimer_now(void);
void     mtimer_set_cmp(uint64_t t);
void     mtimer_disable_cmp(void);
void     mtimer_delay(uint32_t ticks);           /* busy wait (prescale 0: 1 tick = 1 clk) */
void     mtimer_soft_irq(int on);
#define GPT_PERIODIC 0u
#define GPT_ONESHOT  1u
void     gpt_start(int ch, uint32_t prescale, uint32_t reload, uint32_t mode, uint32_t irq_mask);
void     gpt_stop(int ch);
uint32_t gpt_count(int ch);
void     gpt_set_cmp(int ch, uint32_t cmp);
void     gpt_capture_config(int ch, uint32_t edge); /* 0 off, 1 rise, 2 fall, 3 both */
uint32_t gpt_capture(int ch);
uint32_t gpt_status(int ch);
void     gpt_clear(int ch, uint32_t bits);

/* ------------------------------------------------------------------ SPI + NOR flash */
void     spi_init(uint32_t base, uint32_t div, uint32_t mode, uint32_t bits); /* mode 0..3, bits 8/16/32 */
void     spi_cs(uint32_t base, uint32_t cs_mask);
uint32_t spi_xfer(uint32_t base, uint32_t word);
void     spi_xfer_buf(uint32_t base, const uint8_t *tx, uint8_t *rx, size_t n);   /* 8-bit frames */
uint32_t flash_read_id(uint32_t spi_base, uint32_t cs);
void     flash_read(uint32_t spi_base, uint32_t cs, uint32_t addr, void *dst, size_t n);
int      flash_page_program(uint32_t spi_base, uint32_t cs, uint32_t addr, const void *src, size_t n);
int      flash_sector_erase(uint32_t spi_base, uint32_t cs, uint32_t addr);

/* ------------------------------------------------------------------ I2C (drivers/i2c.c) */
void i2c_init(uint32_t base, uint32_t prescale, uint32_t timeout_cycles);
int  i2c_write(uint32_t base, uint8_t addr7, const uint8_t *buf, size_t n, int stop);
int  i2c_read(uint32_t base, uint8_t addr7, uint8_t *buf, size_t n);
int  i2c_write_read(uint32_t base, uint8_t addr7, const uint8_t *w, size_t wn, uint8_t *r, size_t rn);
int  i2c_probe(uint32_t base, uint8_t addr7);   /* 0 = ACK */

/* ------------------------------------------------------------------ PWM (drivers/pwm.c) */
void pwm_init(uint32_t prescale, uint32_t top);
void pwm_set_duty(int ch, uint32_t duty);
void pwm_outputs(uint32_t enable_mask, uint32_t safe_levels, uint32_t polarity);
void pwm_start(int on);
void pwm_fault_config(int enable, int active_high, int irq);
int  pwm_fault_clear(void);                     /* 0 cleared, MCU_EBUSY input still active */
uint32_t pwm_status(void);

/* ------------------------------------------------------------------ watchdog (drivers/wdt.c) */
void wdt_start(uint32_t timeout_ticks, uint32_t prescale, uint32_t ewi_thresh, int ewi_irq, int lock);
void wdt_service(void);
uint32_t wdt_count(void);

/* ------------------------------------------------------------------ DMA (drivers/dma.c) */
#define DMA_SRC_FIXED 1u
#define DMA_DST_FIXED 2u
#define DMA_BYTE      4u
int  dma_start(uint32_t src, uint32_t dst, uint32_t len, uint32_t mode_flags, uint32_t dreq);
int  dma_wait(void);                            /* 0 ok, else -(DMA error code) - 100 */
int  dma_copy(uint32_t src, uint32_t dst, uint32_t len);  /* blocking word copy */
uint32_t dma_error_code(void);
uint32_t dma_bytes_done(void);
void dma_abort(void);

/* ------------------------------------------------------------------ DSP (drivers/dsp.c) */
void     dsp_config(int saturate, int round, uint32_t shift);
void     dsp_acc_set(int32_t v);
int32_t  dsp_acc_get(void);
void     dsp_mac(int16_t x, int16_t y);
void     dsp_dot2(uint32_t a_packed, uint32_t b_packed);
int16_t  dsp_mulq15(int16_t x, int16_t y);
int16_t  dsp_sadd16(int16_t x, int16_t y);
int16_t  dsp_acc_q(void);
void     dsp_fir_init(const int16_t *coef, int ntaps);
int32_t  dsp_fir_push(int16_t sample);          /* returns FIR_OUT */
uint32_t dsp_status(void);
void     dsp_clear_ovf(void);
/* bit-exact software reference model of the accelerator (also used on RV32I) */
int32_t  dsp_ref_add_sat(int32_t a, int32_t b, int sat, int *ovf);
int16_t  dsp_ref_mulq15(int16_t x, int16_t y, int round, int *ovf);
int16_t  dsp_ref_sat16_shr(int32_t v, uint32_t s, int round);
int32_t  dsp_ref_fir(const int16_t *coef, const int16_t *hist, int ntaps, int sat, int *ovf);

/* ------------------------------------------------------------------ fault log (drivers/fault.c) */
uint32_t fault_status(void);
void     fault_clear(uint32_t bits);
void     fault_report(void);                    /* print log on the console */

/* ------------------------------------------------------------------ misc */
void *mcu_memset(void *d, int c, size_t n);
void *mcu_memcpy(void *d, const void *s, size_t n);
int   mcu_memcmp(const void *a, const void *b, size_t n);
uint32_t mcu_crc32(uint32_t crc, const void *buf, size_t n);   /* CRC-32/ISO-HDLC */

/* test helpers used by the examples: CHECK prints and counts failures */
extern volatile uint32_t mcu_check_fails, mcu_check_count;
#define CHECK(cond, msg) do { mcu_check_count++; if (!(cond)) { mcu_check_fails++; \
    con_printf("  CHECK FAIL: %s (line %d)\n", msg, __LINE__); } } while (0)
int mcu_test_finish(const char *name);          /* prints summary, sets TEST_STATUS */

#endif
