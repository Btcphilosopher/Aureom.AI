/* =============================================================================
 * SilicaFlux MCU-I boot ROM (immutable boot code).
 *
 * Boot mode = SYSCTRL.BOOT_MODE (gpio[1:0] straps, or JTAG override):
 *   0 SPI   : external SPI NOR flash on SPI0/CS0, READ (0x03).  The image is
 *             searched at flash offset 0x000000, then 0x100000 (the second
 *             location leaves room for an FPGA bitstream in a shared flash).
 *   1 JTAG  : wait for a host to load SRAM over JTAG and post the mailbox
 *             (SCRATCH1 = JTAG_GO, SCRATCH0 = entry).
 *   2 UART  : receive the same image format on UART0 (raw bytes), ACK 'K'.
 *   3 SRAM  : jump to SRAM base (image preloaded by tester/debugger).
 * Image = 20-byte header {magic "MCI1", load, length, entry, crc32} + payload
 * (scripts/mkimage.py).  Validation before anything is copied:
 *   magic; length > 0, multiple of 4; load >= SRAM base, word aligned;
 *   load + length <= SRAM end - ROM stack reserve (the ROM stack is at the
 *   top of SRAM); entry inside [load, load + length).
 * After the copy the CRC-32 of the payload must match the header.
 * This is an INTEGRITY check against corruption, NOT authentication: there
 * is no key storage (no OTP/eFuse) and no reviewed signature verification,
 * so MCU-I does not implement secure boot (docs/SECURITY.md).
 * BOOT_STATUS (POR domain, survives soft/WDT reset):
 *   0xB001000x ROM stages, 0x600D00mm booted in mode mm,
 *   0xB0D0xxyy failure (xx = mode, yy = reason: 01 MBIST, 02 magic, 03 bounds,
 *   04 crc, 05 jtag entry).
 * ===========================================================================*/
#include <stdint.h>
#include "mcu_regs.h"

#define ROM_STACK_RESERVE 1024u
typedef void (*entry_fn)(void);

/* ---------------------------------------------------------------- console */
static void putc_(char c) {
  while (!(UART0_STATUS & UART_STATUS_TX_READY)) {}
  UART0_DATA = (uint8_t)c;
}
static void puts_(const char *s) {
  for (; *s; s++) { if (*s == '\n') putc_('\r'); putc_(*s); }
}
static void puthex(uint32_t v) {
  for (int i = 28; i >= 0; i -= 4) putc_("0123456789abcdef"[(v >> i) & 15]);
}
static void kv(const char *k, uint32_t v) { puts_(k); puts_(" 0x"); puthex(v); puts_("\n"); }
static uint8_t getc_(void) {
  uint32_t d;
  do { d = UART0_DATA; } while (d & UART_DATA_RX_EMPTY);
  return (uint8_t)d;
}

/* ---------------------------------------------------------------- CRC-32 */
static uint32_t crc32_upd(uint32_t crc, uint32_t w) {   /* crc is the raw (inverted) state */
  static const uint32_t nib[16] = {
    0x00000000u, 0x1DB71064u, 0x3B6E20C8u, 0x26D930ACu, 0x76DC4190u, 0x6B6B51F4u, 0x4DB26158u, 0x5005713Cu,
    0xEDB88320u, 0xF00F9344u, 0xD6D6A3E8u, 0xCB61B38Cu, 0x9B64C2B0u, 0x86D3D2D4u, 0xA00AE278u, 0xBDBDF21Cu};
  for (int b = 0; b < 4; b++) {
    crc ^= (w >> (8 * b)) & 0xFFu;
    crc = (crc >> 4) ^ nib[crc & 15];
    crc = (crc >> 4) ^ nib[crc & 15];
  }
  return crc;
}

/* ---------------------------------------------------------------- failure */
static void fail(uint32_t mode, uint32_t reason) __attribute__((noreturn));
static void fail(uint32_t mode, uint32_t reason) {
  SPI0_CTRL = 0;
  SYSCTRL_BOOT_STATUS = 0xB0D00000u | (mode << 8) | reason;
  FAULT_SET = FAULT_STATUS_BOOT_FAIL;
  kv("boot: FAILED code", SYSCTRL_BOOT_STATUS);
  while (!(UART0_STATUS & UART_STATUS_TX_IDLE)) {}
  SYSCTRL_TEST_STATUS = 2u | (reason << 8);
  for (;;) __asm__ volatile("wfi");
}

typedef struct { uint32_t magic, load, length, entry, crc; } img_hdr_t;

static int hdr_ok(const img_hdr_t *h) {
  uint32_t lo = MCU_SRAM_BASE;
  uint32_t hi = MCU_SRAM_BASE + SYSCTRL_SRAM_SIZE - ROM_STACK_RESERVE;
  return h->length != 0 && (h->length & 3u) == 0 && (h->load & 3u) == 0 && h->load >= lo &&
         h->load < hi && h->length <= hi - h->load && h->entry >= h->load &&
         h->entry < h->load + h->length;
}

static void boot_jump(uint32_t mode, uint32_t entry) __attribute__((noreturn));
static void boot_jump(uint32_t mode, uint32_t entry) {
  SPI0_CTRL = 0;
  kv("boot: entry", entry);
  while (!(UART0_STATUS & UART_STATUS_TX_IDLE)) {}
  SYSCTRL_BOOT_STATUS = 0x600D0000u | mode;
  __asm__ volatile("fence.i" ::: "memory");
  ((entry_fn)(uintptr_t)entry)();
  for (;;) {}
}

/* ---------------------------------------------------------------- SPI flash */
static uint32_t spi32(uint32_t w) {
  SPI0_DATA = w;
  while (SPI0_STATUS & SPI_STATUS_BUSY) {}
  return SPI0_DATA;
}
static uint32_t bswap(uint32_t w) {
  return (w >> 24) | ((w >> 8) & 0xFF00u) | ((w << 8) & 0xFF0000u) | (w << 24);
}
/* start a READ at addr (32-bit frame = command + 24-bit address), CS0 held */
static void flash_open(uint32_t addr) {
  SPI0_CTRL = 0;
  SPI0_DIV = 0;                                         /* SCK = clk/2 */
  SPI0_CTRL = (2u << SPI_CTRL_LEN_SHIFT) | (1u << SPI_CTRL_CS_SHIFT);   /* mode 0, 32-bit, CS0 */
  (void)spi32(0x03000000u | (addr & 0xFFFFFFu));
}
static uint32_t flash_word(void) { return bswap(spi32(0xFFFFFFFFu)); }   /* little-endian image */

static void spi_boot(void) {
  static const uint32_t offs[2] = {0x000000u, 0x100000u};
  img_hdr_t h;
  for (int k = 0; k < 2; k++) {
    flash_open(offs[k]);
    h.magic = flash_word();
    if (h.magic != MCU_IMG_MAGIC) { SPI0_CTRL = 0; continue; }
    h.load = flash_word(); h.length = flash_word(); h.entry = flash_word(); h.crc = flash_word();
    kv("boot: spi image at", offs[k]);
    if (!hdr_ok(&h)) fail(0, 3);
    volatile uint32_t *dst = (volatile uint32_t *)(uintptr_t)h.load;
    uint32_t c = 0xFFFFFFFFu;
    for (uint32_t i = 0; i < h.length / 4u; i++) {
      uint32_t w = flash_word();
      dst[i] = w;
      c = crc32_upd(c, w);
    }
    SPI0_CTRL = 0;
    if (~c != h.crc) { kv("boot: crc", ~c); fail(0, 4); }
    kv("boot: loaded bytes", h.length);
    boot_jump(0, h.entry);
  }
  fail(0, 2);
}

static uint32_t uart_word(void) {
  uint32_t w = 0;
  for (int b = 0; b < 4; b++) w |= (uint32_t)getc_() << (8 * b);
  return w;
}
static void uart_boot(void) {
  img_hdr_t h;
  puts_("boot: waiting for UART image\n");
  h.magic = uart_word();
  if (h.magic != MCU_IMG_MAGIC) fail(2, 2);
  h.load = uart_word(); h.length = uart_word(); h.entry = uart_word(); h.crc = uart_word();
  if (!hdr_ok(&h)) fail(2, 3);
  volatile uint32_t *dst = (volatile uint32_t *)(uintptr_t)h.load;
  uint32_t c = 0xFFFFFFFFu;
  for (uint32_t i = 0; i < h.length / 4u; i++) {
    uint32_t w = uart_word();
    dst[i] = w;
    c = crc32_upd(c, w);
  }
  if (~c != h.crc) fail(2, 4);
  putc_('K'); putc_('\n');
  boot_jump(2, h.entry);
}

static void jtag_boot(void) {
  puts_("boot: waiting for JTAG host\n");
  while (SYSCTRL_SCRATCH1 != MCU_JTAG_GO) {}
  uint32_t e = SYSCTRL_SCRATCH0;
  SYSCTRL_SCRATCH1 = 0;
  if (e < MCU_SRAM_BASE || e >= MCU_SRAM_BASE + SYSCTRL_SRAM_SIZE || (e & 3u)) fail(1, 5);
  boot_jump(1, e);
}

void rom_main(void) {
  uint32_t mode = SYSCTRL_BOOT_MODE & 3u;
  puts_("\nSilicaFlux MCU-I boot ROM 1.0\n");
  kv("chip", SYSCTRL_CHIP_ID);
  kv("features", SYSCTRL_FEATURES);
  kv("sram", SYSCTRL_SRAM_SIZE);
  kv("reset_cause", SYSCTRL_RESET_CAUSE);
  kv("boot_mode", mode);
  SYSCTRL_BOOT_STATUS = 0xB0010003u;
  switch (mode) {
    case 0: spi_boot(); break;
    case 1: jtag_boot(); break;
    case 2: uart_boot(); break;
    default: boot_jump(3, MCU_SRAM_BASE);
  }
}
