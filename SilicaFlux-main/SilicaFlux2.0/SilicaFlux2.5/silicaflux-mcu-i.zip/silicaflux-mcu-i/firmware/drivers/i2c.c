/* SilicaFlux MCU-I driver: I2C master (mcu_i2c), 7-bit addressing. */
#include "mcu_hal.h"

#define I2C_CMD(base, c) (REG(base, I2C_CMD_OFF) = (c))

void i2c_init(uint32_t base, uint32_t prescale, uint32_t timeout_cycles) {
  REG(base, I2C_PRESCALE_OFF) = prescale;
  REG(base, I2C_TIMEOUT_OFF) = timeout_cycles;
  REG(base, I2C_STATUS_OFF) = I2C_STATUS_DONE | I2C_STATUS_TIMEOUT | I2C_STATUS_ARB_LOST;
  REG(base, I2C_CTRL_OFF) = I2C_CTRL_EN;
}
/* issue one command and wait; returns 0, MCU_ETIMEOUT, MCU_EBUS (arbitration) */
static int i2c_do(uint32_t base, uint32_t cmd) {
  I2C_CMD(base, cmd);
  while (REG(base, I2C_STATUS_OFF) & I2C_STATUS_BUSY) {}
  uint32_t st = REG(base, I2C_STATUS_OFF);
  REG(base, I2C_STATUS_OFF) = I2C_STATUS_DONE;
  if (st & I2C_STATUS_TIMEOUT) { REG(base, I2C_STATUS_OFF) = I2C_STATUS_TIMEOUT; return MCU_ETIMEOUT; }
  if (st & I2C_STATUS_ARB_LOST) { REG(base, I2C_STATUS_OFF) = I2C_STATUS_ARB_LOST; return MCU_EBUS; }
  return MCU_OK;
}
static int i2c_wbyte(uint32_t base, uint8_t b, uint32_t flags) {
  REG(base, I2C_TXDATA_OFF) = b;
  int r = i2c_do(base, I2C_CMD_WRITE | flags);
  if (r) return r;
  return (REG(base, I2C_STATUS_OFF) & I2C_STATUS_RX_NACK) ? MCU_ENACK : MCU_OK;
}
static void i2c_stop(uint32_t base) { (void)i2c_do(base, I2C_CMD_STOP); }

int i2c_write(uint32_t base, uint8_t addr7, const uint8_t *buf, size_t n, int stop) {
  int r = i2c_wbyte(base, (uint8_t)(addr7 << 1), I2C_CMD_START);
  for (size_t i = 0; r == MCU_OK && i < n; i++) r = i2c_wbyte(base, buf[i], 0);
  if (r != MCU_OK || stop) i2c_stop(base);
  return r;
}
int i2c_read(uint32_t base, uint8_t addr7, uint8_t *buf, size_t n) {
  int r = i2c_wbyte(base, (uint8_t)((addr7 << 1) | 1u), I2C_CMD_START);
  if (r != MCU_OK) { i2c_stop(base); return r; }
  for (size_t i = 0; i < n; i++) {
    int last = (i + 1 == n);
    r = i2c_do(base, I2C_CMD_READ | (last ? (I2C_CMD_NACK | I2C_CMD_STOP) : 0u));
    if (r) return r;
    buf[i] = (uint8_t)REG(base, I2C_RXDATA_OFF);
  }
  if (n == 0) i2c_stop(base);
  return MCU_OK;
}
int i2c_write_read(uint32_t base, uint8_t addr7, const uint8_t *w, size_t wn, uint8_t *rbuf, size_t rn) {
  int r = i2c_write(base, addr7, w, wn, 0);       /* no STOP: repeated START follows */
  if (r) return r;
  return i2c_read(base, addr7, rbuf, rn);
}
int i2c_probe(uint32_t base, uint8_t addr7) { return i2c_write(base, addr7, 0, 0, 1); }
