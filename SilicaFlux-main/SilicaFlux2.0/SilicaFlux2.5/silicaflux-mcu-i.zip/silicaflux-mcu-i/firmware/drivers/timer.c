/* SilicaFlux MCU-I driver: machine timer (sfv_timer) and general-purpose timers (mcu_gptimer). */
#include "mcu_hal.h"

uint64_t mtimer_now(void) {
  uint32_t hi, lo;
  do { hi = MTIMER_MTIME_HI; lo = MTIMER_MTIME_LO; } while (hi != MTIMER_MTIME_HI);
  return ((uint64_t)hi << 32) | lo;
}
void mtimer_set_cmp(uint64_t t) {
  MTIMER_MTIMECMP_HI = 0xFFFFFFFFu;            /* no spurious match while updating */
  MTIMER_MTIMECMP_LO = (uint32_t)t;
  MTIMER_MTIMECMP_HI = (uint32_t)(t >> 32);
}
void mtimer_disable_cmp(void) { MTIMER_MTIMECMP_HI = 0xFFFFFFFFu; MTIMER_MTIMECMP_LO = 0xFFFFFFFFu; }
void mtimer_delay(uint32_t ticks) {
  uint64_t end = mtimer_now() + ticks;
  while (mtimer_now() < end) {}
}
void mtimer_soft_irq(int on) { MTIMER_MSIP = on ? 1u : 0u; }

void gpt_start(int ch, uint32_t prescale, uint32_t reload, uint32_t mode, uint32_t irq_mask) {
  GPTIMER_CH_CTRL(ch) = 0;
  GPTIMER_CH_PRESCALE(ch) = prescale;
  GPTIMER_CH_RELOAD(ch) = reload;
  GPTIMER_CH_COUNT(ch) = 0;
  GPTIMER_CH_STATUS(ch) = 0xF;
  GPTIMER_CH_CTRL(ch) = GPTIMER_CH_CTRL_EN | (mode ? GPTIMER_CH_CTRL_ONESHOT : 0u) |
                        ((irq_mask & 7u) << 2) | (GPTIMER_CH_CTRL(ch) & GPTIMER_CH_CTRL_CAP_EDGE_MASK);
}
void gpt_stop(int ch) { GPTIMER_CH_CTRL(ch) &= ~GPTIMER_CH_CTRL_EN; }
uint32_t gpt_count(int ch) { return GPTIMER_CH_COUNT(ch); }
void gpt_set_cmp(int ch, uint32_t cmp) { GPTIMER_CH_CMP(ch) = cmp; }
void gpt_capture_config(int ch, uint32_t edge) {
  GPTIMER_CH_CTRL(ch) = (GPTIMER_CH_CTRL(ch) & ~GPTIMER_CH_CTRL_CAP_EDGE_MASK) |
                        ((edge & 3u) << GPTIMER_CH_CTRL_CAP_EDGE_SHIFT);
}
uint32_t gpt_capture(int ch) { return GPTIMER_CH_CAPTURE(ch); }
uint32_t gpt_status(int ch) { return GPTIMER_CH_STATUS(ch); }
void gpt_clear(int ch, uint32_t bits) { GPTIMER_CH_STATUS(ch) = bits; }
