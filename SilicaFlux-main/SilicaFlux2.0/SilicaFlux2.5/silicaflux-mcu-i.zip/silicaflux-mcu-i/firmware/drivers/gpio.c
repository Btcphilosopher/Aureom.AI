/* SilicaFlux MCU-I driver: GPIO (mcu_gpio). */
#include "mcu_hal.h"

void gpio_set_dir(uint32_t out_mask, uint32_t oe) { GPIO_OE = (GPIO_OE & ~out_mask) | (oe & out_mask); }
void gpio_write(uint32_t mask, uint32_t value) { GPIO_OUT = (GPIO_OUT & ~mask) | (value & mask); }
void gpio_set(uint32_t mask) { GPIO_OUT_SET = mask; }
void gpio_clear(uint32_t mask) { GPIO_OUT_CLR = mask; }
void gpio_toggle(uint32_t mask) { GPIO_OUT_TGL = mask; }
uint32_t gpio_read(void) { return GPIO_IN; }
void gpio_irq_config(uint32_t mask, uint32_t kinds) {
  GPIO_IRQ_RISE_EN = (GPIO_IRQ_RISE_EN & ~mask) | ((kinds & GPIO_IRQ_RISE) ? mask : 0u);
  GPIO_IRQ_FALL_EN = (GPIO_IRQ_FALL_EN & ~mask) | ((kinds & GPIO_IRQ_FALL) ? mask : 0u);
  GPIO_IRQ_HIGH_EN = (GPIO_IRQ_HIGH_EN & ~mask) | ((kinds & GPIO_IRQ_HIGH) ? mask : 0u);
  GPIO_IRQ_LOW_EN  = (GPIO_IRQ_LOW_EN & ~mask)  | ((kinds & GPIO_IRQ_LOW) ? mask : 0u);
}
uint32_t gpio_irq_pending(void) { return GPIO_IRQ_STATUS; }
void gpio_irq_clear(uint32_t mask) { GPIO_IRQ_PEND = mask; }
