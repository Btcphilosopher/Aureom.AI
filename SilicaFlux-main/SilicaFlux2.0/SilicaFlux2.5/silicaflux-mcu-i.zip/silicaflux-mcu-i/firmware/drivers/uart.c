/* SilicaFlux MCU-I driver: UART (mcu_uart). */
#include "mcu_hal.h"

void uart_init(uint32_t base, uint32_t baud_div, uint32_t parity, int stop2) {
  if (baud_div) REG(base, UART_BAUD_OFF) = baud_div;
  REG(base, UART_CTRL_OFF) = ((parity & 3u) << UART_CTRL_PARITY_SHIFT) | (stop2 ? UART_CTRL_STOP2 : 0u);
  REG(base, UART_STATUS_OFF) = UART_STATUS_RX_OVF | UART_STATUS_FRAME_ERR | UART_STATUS_TX_OVF |
                               UART_STATUS_PARITY_ERR;
}
void uart_putc(uint32_t base, char c) {
  while (!(REG(base, UART_STATUS_OFF) & UART_STATUS_TX_READY)) {}
  REG(base, UART_DATA_OFF) = (uint8_t)c;
}
int uart_try_getc(uint32_t base) {
  uint32_t d = REG(base, UART_DATA_OFF);
  return (d & UART_DATA_RX_EMPTY) ? -1 : (int)(d & 0xFFu);
}
int uart_getc(uint32_t base) {
  int c;
  while ((c = uart_try_getc(base)) < 0) {}
  return c;
}
void uart_puts(uint32_t base, const char *s) {
  while (*s) {
    if (*s == '\n') uart_putc(base, '\r');
    uart_putc(base, *s++);
  }
}
void uart_flush(uint32_t base) {
  while (!(REG(base, UART_STATUS_OFF) & UART_STATUS_TX_IDLE)) {}
}
uint32_t uart_status(uint32_t base) { return REG(base, UART_STATUS_OFF); }
