/* SilicaFlux MCU-I driver: PWM (mcu_pwm). */
#include "mcu_hal.h"

void pwm_init(uint32_t prescale, uint32_t top) { PWM_PRESCALE = prescale; PWM_PERIOD = top; }
void pwm_set_duty(int ch, uint32_t duty) { MCU_REG32(MCU_PWM_BASE + PWM_DUTY0_OFF + 4u * (uint32_t)ch) = duty; }
void pwm_outputs(uint32_t en, uint32_t safe, uint32_t pol) { PWM_SAFE = safe; PWM_POL = pol; PWM_OUT_EN = en; }
void pwm_start(int on) { PWM_CTRL = on ? (PWM_CTRL | PWM_CTRL_EN) : (PWM_CTRL & ~PWM_CTRL_EN); }
void pwm_fault_config(int enable, int active_high, int irq) {
  uint32_t c = PWM_CTRL & ~(PWM_CTRL_FAULT_EN | PWM_CTRL_FAULT_POL | PWM_CTRL_FAULT_IE);
  PWM_CTRL = c | (enable ? PWM_CTRL_FAULT_EN : 0u) | (active_high ? PWM_CTRL_FAULT_POL : 0u) |
             (irq ? PWM_CTRL_FAULT_IE : 0u);
}
int pwm_fault_clear(void) {
  PWM_STATUS = PWM_STATUS_FAULT;
  return (PWM_STATUS & PWM_STATUS_FAULT) ? MCU_EBUSY : MCU_OK;
}
uint32_t pwm_status(void) { return PWM_STATUS; }
