/* SilicaFlux MCU-I driver: DMA (mcu_dma). */
#include "mcu_hal.h"

int dma_start(uint32_t src, uint32_t dst, uint32_t len, uint32_t mode_flags, uint32_t dreq) {
  if (DMA_STATUS & DMA_STATUS_BUSY) return MCU_EBUSY;
  DMA_SRC_ADDR = src;
  DMA_DST_ADDR = dst;
  DMA_LENGTH = len;
  DMA_MODE = (mode_flags & 7u) | ((dreq & 0xFu) << DMA_MODE_DREQ_SEL_SHIFT);
  DMA_INT_STATUS = DMA_INT_STATUS_DONE | DMA_INT_STATUS_ERROR;
  DMA_CONTROL = DMA_CONTROL_START;
  return MCU_OK;
}
int dma_wait(void) {
  while (DMA_STATUS & DMA_STATUS_BUSY) {}
  if (DMA_STATUS & DMA_STATUS_ERROR) return -100 - (int)(DMA_ERROR_CODE & 0xFu);
  return MCU_OK;
}
int dma_copy(uint32_t src, uint32_t dst, uint32_t len) {
  int r = dma_start(src, dst, len, 0, 0);
  return r ? r : dma_wait();
}
uint32_t dma_error_code(void) { return DMA_ERROR_CODE & 0xFu; }
uint32_t dma_bytes_done(void) { return DMA_BYTES_DONE; }
void dma_abort(void) { DMA_CONTROL = DMA_CONTROL_ABORT; }
