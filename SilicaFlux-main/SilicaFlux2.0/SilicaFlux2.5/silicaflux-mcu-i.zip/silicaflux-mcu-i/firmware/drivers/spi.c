/* SilicaFlux MCU-I driver: SPI master (mcu_spi) and SPI NOR flash commands. */
#include "mcu_hal.h"

void spi_init(uint32_t base, uint32_t div, uint32_t mode, uint32_t bits) {
  uint32_t len = (bits == 32) ? 2u : (bits == 16) ? 1u : 0u;
  REG(base, SPI_DIV_OFF) = div;
  /* standard mode number = CPOL*2 + CPHA; CTRL has CPOL in bit 0, CPHA in bit 1 */
  uint32_t pol_pha = ((mode >> 1) & 1u ? SPI_CTRL_CPOL : 0u) | ((mode & 1u) ? SPI_CTRL_CPHA : 0u);
  REG(base, SPI_CTRL_OFF) = pol_pha | (len << SPI_CTRL_LEN_SHIFT);
  REG(base, SPI_STATUS_OFF) = SPI_STATUS_DONE | SPI_STATUS_RX_OVF;
}
void spi_cs(uint32_t base, uint32_t cs_mask) {
  REG(base, SPI_CTRL_OFF) = (REG(base, SPI_CTRL_OFF) & ~SPI_CTRL_CS_MASK) | ((cs_mask & 0xFu) << SPI_CTRL_CS_SHIFT);
}
uint32_t spi_xfer(uint32_t base, uint32_t word) {
  REG(base, SPI_DATA_OFF) = word;
  while (REG(base, SPI_STATUS_OFF) & SPI_STATUS_BUSY) {}
  return REG(base, SPI_DATA_OFF);
}
void spi_xfer_buf(uint32_t base, const uint8_t *tx, uint8_t *rx, size_t n) {
  for (size_t i = 0; i < n; i++) {
    uint8_t r = (uint8_t)spi_xfer(base, tx ? tx[i] : 0xFFu);
    if (rx) rx[i] = r;
  }
}

/* ---- standard SPI NOR commands (mode 0, 8-bit frames) */
static void fl_begin(uint32_t b, uint32_t cs, uint8_t cmd) {
  REG(b, SPI_CTRL_OFF) &= ~(SPI_CTRL_LEN_MASK | SPI_CTRL_CPOL | SPI_CTRL_CPHA);
  spi_cs(b, 1u << cs);
  spi_xfer(b, cmd);
}
static void fl_addr(uint32_t b, uint32_t a) { spi_xfer(b, (a >> 16) & 0xFF); spi_xfer(b, (a >> 8) & 0xFF); spi_xfer(b, a & 0xFF); }
static void fl_end(uint32_t b) { spi_cs(b, 0); }

uint32_t flash_read_id(uint32_t b, uint32_t cs) {
  fl_begin(b, cs, 0x9F);
  uint32_t id = spi_xfer(b, 0xFF) << 16;
  id |= spi_xfer(b, 0xFF) << 8;
  id |= spi_xfer(b, 0xFF);
  fl_end(b);
  return id;
}
void flash_read(uint32_t b, uint32_t cs, uint32_t addr, void *dst, size_t n) {
  fl_begin(b, cs, 0x03);
  fl_addr(b, addr);
  spi_xfer_buf(b, 0, dst, n);
  fl_end(b);
}
static int fl_wait(uint32_t b, uint32_t cs) {
  for (uint32_t i = 0; i < 1000000u; i++) {
    fl_begin(b, cs, 0x05);
    uint32_t st = spi_xfer(b, 0xFF);
    fl_end(b);
    if (!(st & 1u)) return MCU_OK;
  }
  return MCU_ETIMEOUT;
}
int flash_page_program(uint32_t b, uint32_t cs, uint32_t addr, const void *src, size_t n) {
  if (n == 0 || n > 256 || ((addr & 0xFF) + n) > 256) return MCU_EINVAL;
  fl_begin(b, cs, 0x06); fl_end(b);          /* WREN */
  fl_begin(b, cs, 0x02);
  fl_addr(b, addr);
  spi_xfer_buf(b, src, 0, n);
  fl_end(b);
  return fl_wait(b, cs);
}
int flash_sector_erase(uint32_t b, uint32_t cs, uint32_t addr) {
  fl_begin(b, cs, 0x06); fl_end(b);
  fl_begin(b, cs, 0x20);
  fl_addr(b, addr);
  fl_end(b);
  return fl_wait(b, cs);
}
