/* SilicaFlux MCU-I console on UART0: minimal printf (no libc). */
#include <stdarg.h>
#include "mcu_hal.h"

void con_putc(char c) {
  if (c == '\n') uart_putc(MCU_UART0_BASE, '\r');
  uart_putc(MCU_UART0_BASE, c);
}
void con_puts(const char *s) { while (*s) con_putc(*s++); }

static void put_u(uint32_t v, uint32_t base, int width, char pad, int upper) {
  char b[12];
  int n = 0;
  do {
    uint32_t d = v % base;            /* RV32I: libgcc __umodsi3 */
    b[n++] = (char)(d < 10 ? '0' + d : (upper ? 'A' : 'a') + d - 10);
    v /= base;
  } while (v);
  while (n < width) b[n++] = pad;
  while (n) con_putc(b[--n]);
}

void con_printf(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  for (; *fmt; fmt++) {
    if (*fmt != '%') { con_putc(*fmt); continue; }
    fmt++;
    char pad = ' ';
    int width = 0;
    if (*fmt == '0') { pad = '0'; fmt++; }
    while (*fmt >= '0' && *fmt <= '9') width = width * 10 + (*fmt++ - '0');
    switch (*fmt) {
      case 'c': con_putc((char)va_arg(ap, int)); break;
      case 's': { const char *s = va_arg(ap, const char *); con_puts(s ? s : "(null)"); break; }
      case 'd': { int v = va_arg(ap, int);
                  if (v < 0) { con_putc('-'); put_u((uint32_t)(-(v + 1)) + 1u, 10, width, pad, 0); }
                  else put_u((uint32_t)v, 10, width, pad, 0);
                  break; }
      case 'u': put_u(va_arg(ap, uint32_t), 10, width, pad, 0); break;
      case 'x': put_u(va_arg(ap, uint32_t), 16, width, pad, 0); break;
      case 'X': put_u(va_arg(ap, uint32_t), 16, width, pad, 1); break;
      case 'p': con_puts("0x"); put_u(va_arg(ap, uint32_t), 16, 8, '0', 0); break;
      case '%': con_putc('%'); break;
      default: con_putc('?'); break;
    }
  }
  va_end(ap);
}
