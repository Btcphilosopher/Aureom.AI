/* SilicaFlux MCU-I driver: fault log (mcu_fault, POR domain). */
#include "mcu_hal.h"

uint32_t fault_status(void) { return FAULT_STATUS; }
void fault_clear(uint32_t bits) { FAULT_STATUS = bits; }
void fault_report(void) {
  con_printf("fault: status=%03x buserr=%u periph=%u parity=%u last=%08x info=%x reset_cause=%x\n",
             FAULT_STATUS, FAULT_BUS_ERR_COUNT, FAULT_PERIPH_ERR_COUNT, FAULT_PARITY_ERR_COUNT,
             FAULT_LAST_ADDR, FAULT_LAST_INFO, SYSCTRL_RESET_CAUSE);
}
