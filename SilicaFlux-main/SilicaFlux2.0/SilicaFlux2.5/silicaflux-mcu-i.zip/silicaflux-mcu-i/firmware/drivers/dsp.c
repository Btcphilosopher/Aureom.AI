/* SilicaFlux MCU-I driver: DSP/MAC accelerator (mcu_dsp) + bit-exact C reference model. */
#include "mcu_hal.h"

static inline void dsp_wait(void) { while (DSP_STATUS & DSP_STATUS_BUSY) {} }

void dsp_config(int saturate, int round, uint32_t shift) {
  dsp_wait();
  DSP_CTRL = (saturate ? DSP_CTRL_SAT : 0u) | (round ? DSP_CTRL_ROUND : 0u) | ((shift & 31u) << DSP_CTRL_SHIFT_SHIFT);
}
void dsp_acc_set(int32_t v) { dsp_wait(); DSP_ACC = (uint32_t)v; }
int32_t dsp_acc_get(void) { dsp_wait(); return (int32_t)DSP_ACC; }
void dsp_mac(int16_t x, int16_t y) { dsp_wait(); DSP_MAC = ((uint32_t)(uint16_t)x << 16) | (uint16_t)y; }
void dsp_dot2(uint32_t a, uint32_t b) { dsp_wait(); DSP_OPA = a; DSP_DOT2 = b; }
int16_t dsp_mulq15(int16_t x, int16_t y) {
  dsp_wait(); DSP_MULQ = ((uint32_t)(uint16_t)x << 16) | (uint16_t)y; dsp_wait();
  return (int16_t)DSP_RESULT;
}
int16_t dsp_sadd16(int16_t x, int16_t y) {
  dsp_wait(); DSP_SADD = ((uint32_t)(uint16_t)x << 16) | (uint16_t)y; dsp_wait();
  return (int16_t)DSP_RESULT;
}
int16_t dsp_acc_q(void) { dsp_wait(); return (int16_t)DSP_ACC_Q; }
void dsp_fir_init(const int16_t *coef, int ntaps) {
  dsp_wait();
  for (int i = 0; i < ntaps; i++) DSP_COEF(i) = (uint16_t)coef[i];
  for (int i = ntaps; i < 16; i++) DSP_COEF(i) = 0;
  DSP_FIR_CTRL = (uint32_t)(ntaps - 1) | DSP_FIR_CTRL_CLEAR;
}
int32_t dsp_fir_push(int16_t s) {
  DSP_FIR_IN = (uint16_t)s;
  dsp_wait();
  return (int32_t)DSP_FIR_OUT;
}
uint32_t dsp_status(void) { return DSP_STATUS; }
void dsp_clear_ovf(void) { DSP_STATUS = DSP_STATUS_OVF; }

/* ---------------------------------------------------------------- reference model */
int32_t dsp_ref_add_sat(int32_t a, int32_t b, int sat, int *ovf) {
  uint32_t s = (uint32_t)a + (uint32_t)b;
  int o = ((a < 0) == (b < 0)) && (((int32_t)s < 0) != (a < 0));
  if (o) {
    *ovf = 1;
    if (sat) return a < 0 ? (int32_t)0x80000000u : 0x7FFFFFFF;
  }
  return (int32_t)s;
}
static int16_t sat16(int64_t v, int *ovf) {
  if (v > 32767) { if (ovf) *ovf = 1; return 32767; }
  if (v < -32768) { if (ovf) *ovf = 1; return -32768; }
  return (int16_t)v;
}
static int64_t shr_rnd(int64_t v, uint32_t s, int round) {
  if (round && s) v += (int64_t)1 << (s - 1);
  return v >> s;                       /* arithmetic shift (GCC) */
}
int16_t dsp_ref_mulq15(int16_t x, int16_t y, int round, int *ovf) {
  int32_t p = (int32_t)x * (int32_t)y;
  return sat16(shr_rnd(p, 15, round), ovf);
}
int16_t dsp_ref_sat16_shr(int32_t v, uint32_t s, int round) { return sat16(shr_rnd(v, s, round), 0); }
int32_t dsp_ref_fir(const int16_t *coef, const int16_t *hist, int ntaps, int sat, int *ovf) {
  int32_t acc = 0;
  for (int i = 0; i < ntaps; i++) acc = dsp_ref_add_sat(acc, (int32_t)coef[i] * (int32_t)hist[i], sat, ovf);
  return acc;
}
