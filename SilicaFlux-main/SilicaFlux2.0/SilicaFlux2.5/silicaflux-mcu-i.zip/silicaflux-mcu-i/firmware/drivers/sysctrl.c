/* SilicaFlux MCU-I driver: system control, reset supervision, PMU, MBIST, parity, debug lock. */
#include "mcu_hal.h"

uint32_t sys_chip_id(void) { return SYSCTRL_CHIP_ID; }
uint32_t sys_features(void) { return SYSCTRL_FEATURES; }
uint32_t sys_sram_size(void) { return SYSCTRL_SRAM_SIZE; }
uint32_t sys_boot_mode(void) { return SYSCTRL_BOOT_MODE & 3u; }
uint32_t sys_reset_cause(void) { return SYSCTRL_RESET_CAUSE; }
void sys_reset_cause_clear(uint32_t bits) { SYSCTRL_RESET_CAUSE = bits & 0xFu; }

void sys_soft_reset(void) {
  SYSCTRL_SOFT_RESET = MCU_SOFT_RESET_KEY;
  for (;;) {}
}

void sys_clk_enable(uint32_t mask, int on) {
  if (on) SYSCTRL_CLK_EN |= mask;
  else    SYSCTRL_CLK_EN &= ~mask;
}

int sys_mbist_run(int checkerboard) {
  SYSCTRL_MBIST_CTRL = SYSCTRL_MBIST_CTRL_START | (checkerboard ? SYSCTRL_MBIST_CTRL_BG_CHK : 0u);
  while (SYSCTRL_MBIST_STATUS & SYSCTRL_MBIST_STATUS_BUSY) {}
  return (SYSCTRL_MBIST_STATUS & SYSCTRL_MBIST_STATUS_FAIL) ? MCU_EBUS : MCU_OK;
}

void sys_parity_enable(int on) {
  SYSCTRL_PARITY_CTRL = on ? SYSCTRL_PARITY_CTRL_CHECK_EN : 0u;
}
void sys_parity_inject_next_write(void) {
  SYSCTRL_PARITY_CTRL = SYSCTRL_PARITY_CTRL | SYSCTRL_PARITY_CTRL_INJECT;
}
void sys_debug_lock(void) { SYSCTRL_DBG_LOCK = MCU_DBG_LOCK_KEY; }
