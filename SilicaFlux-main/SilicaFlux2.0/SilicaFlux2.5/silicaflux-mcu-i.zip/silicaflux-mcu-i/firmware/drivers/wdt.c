/* SilicaFlux MCU-I driver: watchdog (mcu_wdt). */
#include "mcu_hal.h"

void wdt_start(uint32_t timeout_ticks, uint32_t prescale, uint32_t ewi_thresh, int ewi_irq, int lock) {
  WDT_LOAD = timeout_ticks;
  WDT_PRESCALE = prescale;
  WDT_EWI_THRESH = ewi_thresh;
  WDT_STATUS = WDT_STATUS_EWI;
  WDT_CTRL = WDT_CTRL_EN | (ewi_irq ? WDT_CTRL_EWI_EN : 0u) | WDT_CTRL_DBG_PAUSE | (lock ? WDT_CTRL_LOCK : 0u);
}
void wdt_service(void) {
  WDT_SERVICE = MCU_WDT_KEY1;
  WDT_SERVICE = MCU_WDT_KEY2;
}
uint32_t wdt_count(void) { return WDT_COUNT; }
