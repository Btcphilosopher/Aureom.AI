// =============================================================================
// SilicaFlux MCU-I :: sfv_clkgate for GlobalFoundries GF180MCU (7-track, 5 V
// tolerant library) -- maps the ICG wrapper to the library's positive-edge
// integrated clock gate with test enable (icgtp: CLK, E, TE -> Q).
// Same module name/ports as third_party/silicaflux-v rtl/common/sfv_clkgate.sv.
// =============================================================================
module sfv_clkgate (input wire logic clk, input wire logic en, input wire logic test_en,
                    output logic gclk);
  gf180mcu_fd_sc_mcu7t5v0__icgtp_1 u_icg (.CLK(clk), .E(en), .TE(test_en), .Q(gclk));
endmodule
