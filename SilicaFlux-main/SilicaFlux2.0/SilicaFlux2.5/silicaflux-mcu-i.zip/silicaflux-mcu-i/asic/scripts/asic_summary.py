#!/usr/bin/env python3
"""Summarise one MCU-I ASIC synthesis run (only numbers present in the tool
outputs are reported; anything not run is stated as such).

    asic_summary.py <out_dir> <pdk> <variant> <clk_period_ns> <node>
"""
import json
import os
import re
import sys

out, pdk, var, per, node = sys.argv[1:6]
stat = open(os.path.join(out, "synth_stat.txt")).read()
res = {"pdk": pdk, "variant": var, "node": node, "target_period_ns": float(per)}
m = re.search(r"Chip area for (?:top )?module '\\?mcu_top': ([0-9.]+)", stat)
res["area_um2_total"] = float(m.group(1)) if m else None
m = re.search(r"Number of cells:\s+(\d+)", stat)
res["cells"] = int(m.group(1)) if m else None
cells = dict((c, int(n)) for c, n in re.findall(r"^\s+(\S+)\s+(\d+)\s*$", stat, re.M))
res["flops"] = sum(n for c, n in cells.items() if re.search(r"df|DF|sdff|dfxtp|dfrtp|dfstp|dfrbp", c) and "dly" not in c)
res["icg_cells"] = sum(n for c, n in cells.items() if re.search(r"icg|slgcp|dlclkp", c, re.I))
macros = {c: n for c, n in cells.items() if c.startswith(("RM_IHPSG13", "sky130_sram", "gf180mcu_fd_ip_sram"))}
res["sram_macros"] = macros
# macro area from the macro Liberty files (LIB_MACROS), if they were read
macro_area = 0.0
for lib in os.environ.get("LIB_MACROS", "").split():
    txt = open(lib).read()
    cm = re.search(r"cell\s*\(\s*\"?(\w+)", txt)
    am = re.search(r"^\s*area\s*:\s*([0-9.]+)", txt, re.M)
    if cm and am and cm.group(1) in macros:
        macro_area += float(am.group(1)) * macros[cm.group(1)]
        res.setdefault("macro_area_each_um2", {})[cm.group(1)] = float(am.group(1))
res["sram_macro_area_um2"] = macro_area if macro_area else None
if res["area_um2_total"] is not None:
    res["std_cell_area_um2"] = res["area_um2_total"] - macro_area
# macro area (if the macro Liberty was read, stat lists it in the total)
lat = open(os.path.join(out, "latches.txt")).read().strip().splitlines() if os.path.exists(os.path.join(out, "latches.txt")) else []
res["latch_cells_outside_icg"] = len([l for l in lat if l.strip()])
ltp = open(os.path.join(out, "ltp.txt")).read() if os.path.exists(os.path.join(out, "ltp.txt")) else ""
m = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", ltp)
res["logic_depth_generic_cells"] = int(m.group(1)) if m else None
sta = os.path.join(out, "wns.rpt")
if os.path.exists(sta):
    res["sta"] = open(sta).read().strip()
    p = os.path.join(out, "power.rpt")
    res["power"] = open(p).read().strip()[-400:] if os.path.exists(p) else None
else:
    res["sta"] = "NOT RUN (OpenSTA not installed in this environment)"
json.dump(res, open(os.path.join(out, "summary.json"), "w"), indent=1)
print(f"## {pdk} / {var}  ({node}, Yosys logic synthesis, pre-layout)\n")
print(f"- standard-cell area: {res['std_cell_area_um2']:.0f} um^2 ({res['std_cell_area_um2']/1e6:.3f} mm^2)")
if res["sram_macro_area_um2"]:
    print(f"- SRAM macro area: {res['sram_macro_area_um2']:.0f} um^2 ({res['sram_macro_area_um2']/1e6:.3f} mm^2) "
          f"-> logic + SRAM {res['area_um2_total']/1e6:.3f} mm^2 (no pads, no utilisation/whitespace)")
else:
    print("- SRAM macro area: not included (macro Liberty not available in this run)")
print(f"- cells: {res['cells']}, flip-flops: {res['flops']}, ICG cells: {res['icg_cells']}")
print(f"- SRAM macros (black boxes): {macros if macros else 'none'}")
print(f"- longest topological path (generic cells, before mapping): {res['logic_depth_generic_cells']}")
print(f"- latches outside clock gates: {res['latch_cells_outside_icg']}")
print(f"- timing/power: {res['sta']}")
