#!/usr/bin/env bash
# =============================================================================
# SilicaFlux MCU-I ASIC logic synthesis (Yosys) on a public PDK library.
#   asic/scripts/run_synth.sh <ihp_sg13g2|sky130hd|gf180mcu> <basic|industrial>
# env: PLATFORMS (ORFS flow/platforms), CLK_PERIOD_NS, STA (optional OpenSTA)
# Outputs build/asic/<pdk>/<variant>/: netlist, synth_stat.txt (cell area from
# the Liberty file), ltp.txt (logic depth), abc delay estimate, summary.md.
# If OpenSTA is installed (STA=sta), sta.tcl is run for pre-layout timing and
# power; otherwise it is generated but NOT run (stated in summary.md).
# Pre-layout results only: no placement, routing, clock tree or parasitics.
# =============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
CFG=${1:?pdk}; V=${2:?variant}
source asic/configs/$CFG.cfg
CFG_PKG=${CFG_PKG:-rtl/generated/mcu_cfg_${V}_pkg.sv}    # override for experiments
OUT=build/asic/$CFG/${OUT_NAME:-$V}; mkdir -p $OUT
command -v yosys >/dev/null || { echo "ERROR: yosys not found"; exit 2; }
[ -f "$LIB_STD" ] || { echo "ERROR: $LIB_STD missing (run scripts/fetch_deps.sh, set PLATFORMS)"; exit 2; }
ROM=build/$V/mcu_bootrom_image.sv
[ -f $ROM ] || make -s -C firmware VARIANT=$V rom
LIB=$LIB_STD
if [[ "$LIB_STD" == *.gz ]]; then LIB=$OUT/$(basename "${LIB_STD%.gz}"); zcat "$LIB_STD" > "$LIB"; fi
PERIOD_PS=$(python3 -c "print(int(float('$CLK_PERIOD_NS')*1000))")
read -r TH_CELL TH_PORT <<< "$TIEHI"; read -r TL_CELL TL_PORT <<< "$TIELO"
read -r BUF_CELL BUF_I BUF_O <<< "$BUF"
MACRO_RD=""; MACRO_ST=""
for l in $LIB_MACROS; do MACRO_RD="$MACRO_RD read_liberty -lib $l;"; MACRO_ST="$MACRO_ST -liberty $l"; done
RTL=$(grep -v '^//' rtl/files.f | grep -v sfv_clkgate | tr '\n' ' ')
ASIC_SRAM="third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_sky130.sv third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_gf180.sv third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp1p.sv third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp2p.sv"
STUBS=third_party/silicaflux-sramlib/rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv
cat > $OUT/synth.ys <<YS
read_liberty -lib $LIB
$MACRO_RD
read_verilog -defer -sv -DSYNTHESIS -I third_party/silicaflux-sramlib/rtl/mem -I third_party/silicaflux-sramlib/rtl/mem/backends/asic $CFG_PKG $RTL $ASIC_SRAM $TECH_DIR/sfv_clkgate.sv $ROM
read_verilog -lib -sv $STUBS
chparam -set SRAM_BACKEND 2 -set SRAM_MACRO $SRAM_MACRO_ID mcu_top
hierarchy -check -top mcu_top
synth -top mcu_top -flatten
tee -q -o $OUT/ltp.txt ltp -noff
opt -purge
dfflibmap -liberty $LIB
abc -liberty $LIB -D $PERIOD_PS
opt_clean -purge
hilomap -singleton -hicell $TH_CELL $TH_PORT -locell $TL_CELL $TL_PORT
setundef -zero
insbuf -buf $BUF_CELL $BUF_I $BUF_O
opt_clean -purge
tee -q -o $OUT/synth_stat.txt stat -liberty $LIB $MACRO_ST
tee -q -o $OUT/latches.txt select -list t:\$dlatch t:\$_DLATCH* t:*dlat*
write_verilog -noattr -noexpr -nohex -nodec $OUT/mcu_top.netlist.v
YS
echo "[asic] yosys synthesis $CFG/$V (target ${CLK_PERIOD_NS} ns)"
yosys -q -l $OUT/yosys.log -s $OUT/synth.ys > /dev/null || { tail -20 $OUT/yosys.log; exit 1; }
cat > $OUT/sta.tcl <<TCL
read_liberty $LIB
foreach l {$LIB_MACROS} { read_liberty \$l }
read_verilog $OUT/mcu_top.netlist.v
link_design mcu_top
read_sdc asic/constraints/mcu_soc.sdc
report_checks -path_delay max -group_count 5 -fields {fanout cap slew} -digits 3 > $OUT/timing_max.rpt
report_checks -path_delay min -digits 3 > $OUT/timing_min.rpt
report_wns > $OUT/wns.rpt
report_tns > $OUT/tns.rpt
set_power_activity -input -activity 0.1
report_power > $OUT/power.rpt
exit
TCL
if command -v ${STA:-sta} >/dev/null 2>&1; then
  CLK_PERIOD_NS=$CLK_PERIOD_NS ${STA:-sta} -no_splash -exit $OUT/sta.tcl > $OUT/sta.log 2>&1 || true
fi
LIB_MACROS="$LIB_MACROS" python3 asic/scripts/asic_summary.py $OUT $CFG $V "$CLK_PERIOD_NS" "$NODE" | tee $OUT/summary.md
