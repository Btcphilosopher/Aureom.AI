# SilicaFlux MCU-I timing constraints (functional mode), for OpenSTA /
# OpenROAD and commercial STA.  Applies to mcu_top (core, no pad ring).
# CLK_PERIOD_NS is set by the flow (configs/*.cfg; default 20 ns = 50 MHz
# for 130 nm, 25 ns for 180 nm).  These are TARGETS, not achieved results.
set period $::env(CLK_PERIOD_NS)
create_clock -name clk -period $period [get_ports clk]
create_clock -name tck -period 100.0 [get_ports tck]
# JTAG and system clocks are asynchronous; every crossing goes through
# sfv_sync two-flop synchronisers / toggle handshakes (docs/CLOCK_RESET.md).
set_clock_groups -asynchronous -group {clk} -group {tck}
set_clock_uncertainty 0.25 [get_clocks clk]
set_clock_transition 0.15 [get_clocks clk]
# Gated clocks (ICG cells) are generated inside the design; STA derives them
# through the clock-gating cells (clock-gating checks on the enables).
# I/O budgets: 30 % of the period outside the chip (pads + board)
set io [expr 0.3 * $period]
set_input_delay  $io -clock clk [get_ports {uart0_rx uart1_rx spi0_miso spi1_miso gpio_i* pwm_fault_i i2c_scl_i i2c_sda_i}]
set_output_delay $io -clock clk [get_ports {uart0_tx uart1_tx spi0_* spi1_* gpio_o* gpio_oe* pwm_o* i2c_*_oe test_pass test_fail test_status* cpu_sleep}]
set_input_delay  20.0 -clock tck [get_ports {tms tdi}]
set_output_delay 20.0 -clock tck [get_ports {tdo tdo_oe}]
# asynchronous / static inputs: synchronised internally or static in functional mode
set_false_path -from [get_ports rst_ni]
set_false_path -from [get_ports pwr_ok_i]
set_false_path -from [get_ports test_mode]
set_load 0.02 [all_outputs]
set_input_transition 0.2 [all_inputs]
