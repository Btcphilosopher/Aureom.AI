# Vendored SilicaFlux sources (unmodified)

Every file under `third_party/` is a byte-identical copy of a file from the Aureom.AI repository
(`btcphilosopher/Aureom.AI`, branch `claude/friendly-rubin-6svjje`, base commit `fb7244d`).  `SHA256SUMS` lists
every vendored file; `scripts/check_vendor.sh` verifies them.  Files that MCU-I changed were copied to `rtl/`,
`tb/` or `formal/` under new names with the changes listed in their headers (docs/AUDIT.md, docs/CHANGELOG.md).

| Directory | Source archive in the repository | SHA-256 of the archive | Project |
|---|---|---|---|
| `silicaflux-v/` | `SilicaFlux-main/silicaflux-v-release1.zip` (path `silicaflux-v/`) | `424816e9eaedee999a711617ceb2f517d55684301f7dc260c24f73af9c045b16` | SilicaFlux-V release 1 |
| `silicaflux-datafabric/` | `SilicaFlux-main/silicaflux-datafabric.zip` (path `silicaflux-datafabric/`) | `9f1f37357c8e25e00c214227894bca37c45e18ae9d7a993f87039a7679b665fb` | SilicaFlux DataFabric (Project 03) |
| `silicaflux-sramlib/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` (path `silicaflux-sramlib/`) | `13b1cee1f913d7b5821f338ce0d12a038e02a1062538c66e4917cae2599beb16` | SilicaFlux SRAM Wrapper Library (Project 01) |

License: no license file exists in the source repository; these are internal Aureom.AI sources.
