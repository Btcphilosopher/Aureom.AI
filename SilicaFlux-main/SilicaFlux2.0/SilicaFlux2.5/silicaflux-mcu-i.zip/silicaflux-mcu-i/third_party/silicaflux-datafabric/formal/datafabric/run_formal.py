#!/usr/bin/env python3
"""DataFabric formal runner (no SymbiYosys needed).
For every job: Yosys (read -formal, prep, flatten, async2sync, dffunmap) then
  * bmc  : yosys-smtbmc --presat with the chosen SMT solver, depth N
  * prove: AIGER + ABC PDR (unbounded; the engine SilicaFlux-V used via sby)
Writes reports/datafabric/formal.{json,md}.  Exit 1 if any job fails."""
import json, os, re, subprocess, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
OUT = os.path.join(ROOT, "build", "formal")
IC = os.path.join(ROOT, "rtl", "interconnect")
DMA = os.path.join(ROOT, "rtl", "dma")
SOLVER = os.environ.get("SMT_SOLVER", "z3")

def ic(*f): return [os.path.join(IC, x) for x in f]
XBAR = ic("sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv",
          "sfb_error_slave.sv", "sfb_crossbar.sv")
JOBS = [
    # name, top, files, chparams, engines(bmc depth, prove)
    ("arbiter_rr_n3", "fv_sfb_arbiter", ic("sfb_arbiter.sv") + [os.path.join(HERE, "fv_sfb_arbiter.sv")], {"N": 3, "MODE": 1}, 24, True),
    ("arbiter_rr_n5", "fv_sfb_arbiter", ic("sfb_arbiter.sv") + [os.path.join(HERE, "fv_sfb_arbiter.sv")], {"N": 5, "MODE": 1}, 12, True),
    ("arbiter_fixed_n4", "fv_sfb_arbiter", ic("sfb_arbiter.sv") + [os.path.join(HERE, "fv_sfb_arbiter.sv")], {"N": 4, "MODE": 0}, 20, True),
    ("skid_buffer", "fv_sfb_skid", ic("sfb_skid_buffer.sv") + [os.path.join(HERE, "fv_sfb_skid.sv")], {}, 30, True),
    ("crossbar_3x2", "fv_sfb_xbar", XBAR + [os.path.join(HERE, "fv_sfb_xbar.sv")], {}, 10, True),
]
EXTRA = os.path.join(HERE, "jobs_extra.py")
if os.path.exists(EXTRA):
    exec(open(EXTRA).read())          # DMA jobs appended by jobs_extra.py

def apply_mutation(name, files, mut):
    """mut = (basename, old, new): copy that file with one edit into build/formal/<name>/"""
    if not mut:
        return files
    d = os.path.join(OUT, name, "mut"); os.makedirs(d, exist_ok=True)
    out = []
    for f in files:
        if os.path.basename(f) == mut[0]:
            src = open(f).read(); assert mut[1] in src, (name, mut[1])
            g = os.path.join(d, mut[0]); open(g, "w").write(src.replace(mut[1], mut[2])); out.append(g)
        else:
            out.append(f)
    return out

def yosys_prep(name, top, files, params):
    d = os.path.join(OUT, name); os.makedirs(d, exist_ok=True)
    ch = "".join(f"chparam -set {k} {v} {top}; " for k, v in params.items())
    inc = f"-I{DMA} "
    common = (f"read_verilog -sv -formal -DFORMAL -DSYNTHESIS {inc}{' '.join(files)}; {ch}prep -top {top}; "
              f"flatten; async2sync; dffunmap; setundef -undriven -zero; opt_clean; ")
    smt = os.path.join(d, "model.smt2"); aig = os.path.join(d, "model.aig")
    r1 = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys_smt.log"), "-p", common + f"write_smt2 -wires {smt}"],
                        capture_output=True, text=True)
    r2 = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys_aig.log"), "-p",
                         common + "memory_map; opt -full -nosdff -nodffe; techmap; opt -fast -nosdff -nodffe; dffunmap; abc -g AND -fast; opt_clean; "
                         f"write_aiger -I -B -zinit -no-startoffset -map {d}/model.aim {aig}"],
                        capture_output=True, text=True)
    return d, smt, aig, r1, r2

def judge(r):
    """PASS jobs: BMC passed (or skipped/timeout with a proof) and the unbounded proof (if run)
    succeeded or timed out with BMC passing.  FAIL jobs (mutants): a counterexample was found."""
    if r.get("expect") == "FAIL":
        return "FAIL" in r.get("bmc", "") or "FAIL" in r.get("prove", "")
    bmc_ok = r["bmc"].startswith("PASS") or (r["bmc"] in ("skipped",) or r["bmc"].startswith("TIMEOUT")) and \
        r.get("prove", "").startswith("PROVED")
    prove = r.get("prove", "-")
    prove_ok = prove in ("-",) or prove.startswith("PROVED") or (prove.startswith("UNKNOWN") and r["bmc"].startswith("PASS"))
    return bmc_ok and prove_ok

def from_logs(job):
    """Rebuild a job result from its saved artefacts (result.json, else bmc.log / pdr.log)."""
    name, top, files, params, depth, prove = job[:6]
    opt = job[6] if len(job) > 6 else {}
    d = os.path.join(OUT, name)
    rj = os.path.join(d, "result.json")
    if os.path.exists(rj):
        return json.load(open(rj))
    row = dict(job=name, top=top, params=params, expect=opt.get("expect", "PASS"), note=opt.get("note", ""),
               secs=None, source="re-parsed from bmc.log/pdr.log")
    b = open(os.path.join(d, "bmc.log")).read() if os.path.exists(os.path.join(d, "bmc.log")) else None
    if b is None:
        row["bmc"] = "NOT RUN"
    elif "was asserted" in b or "Status: FAILED" in b:
        row["bmc"] = "FAIL (counterexample)"
    elif "Status: PASSED" in b:
        row["bmc"] = f"PASS depth {depth}"
    elif "No output asserted" in b:
        m = re.search(r"No output asserted in (\d+) frames", b)
        row["bmc"] = f"PASS depth {m.group(1) if m else depth} (abc bmc3)"
    else:
        row["bmc"] = "ERROR"
    if prove:
        pl = os.path.join(d, "pdr.log")
        p = open(pl).read() if os.path.exists(pl) else None
        row["prove"] = ("NOT RUN" if p is None else "PROVED (unbounded, ABC PDR)" if "Property proved" in p else
                        "FAIL (counterexample)" if "was asserted" in p else "UNKNOWN")
    row["ok"] = judge(row)
    return row


def write_report(res):
    os.makedirs(os.path.join(ROOT, "reports", "datafabric"), exist_ok=True)
    def ver(c):
        try: return subprocess.run(c, capture_output=True, text=True).stdout.strip().splitlines()[0]
        except Exception: return "n/a"
    tools = {"yosys": ver(["yosys", "-V"]), "solver": SOLVER, SOLVER: ver([SOLVER, "--version"])}
    json.dump(dict(tools=tools, jobs=res), open(os.path.join(ROOT, "reports", "datafabric", "formal.json"), "w"), indent=1)
    with open(os.path.join(ROOT, "reports", "datafabric", "formal.md"), "w") as f:
        f.write(f"# Formal results\n\n{tools['yosys']}; BMC with yosys-smtbmc + {tools[SOLVER]} or ABC bmc3 (bit-level, "
                "on the AIGER model); unbounded proofs with ABC PDR (yosys-abc).  `expect FAIL` rows are non-vacuity "
                "checks: the same harness on deliberately broken RTL must produce a counterexample.  A PDR result of "
                "UNKNOWN means the engine hit its time budget: the property then holds only to the BMC depth.\n\n"
                "| job | top | params | BMC | unbounded | expect | verdict | note |\n|---|---|---|---|---|---|---|---|\n")
        for r in res:
            prove = r.get("prove", "-")
            m = re.search(r"Reached timeout \((\d+) seconds\) in frame (\d+)", r.get("prove_detail", ""))
            if prove == "UNKNOWN" and m:
                prove = f"UNKNOWN (PDR budget {m.group(1)} s reached in frame {m.group(2)})"
            verdict = "OK" if r["ok"] else "**NOT OK**"
            if r["ok"] and r["expect"] == "PASS" and not prove.startswith("PROVED") and prove != "-":
                verdict = "OK, **bounded only**"
            f.write(f"| {r['job']} | {r['top']} | {r['params']} | {r['bmc']} | {prove} | "
                    f"{r['expect']} | {verdict} | {r.get('note','')} |\n")


def main():
    if sys.argv[1:] == ["--collect"]:
        res = [from_logs(j) for j in JOBS]
        write_report(res)
        for r in res: print(f"{r['job']:26s} bmc={r['bmc']:30s} prove={r.get('prove','-'):30s} {'OK' if r['ok'] else 'NOT OK'}")
        return 0 if all(r["ok"] for r in res) else 1
    sel = sys.argv[1:]
    res = []
    for job in JOBS:
        name, top, files, params, depth, prove = job[:6]
        opt = job[6] if len(job) > 6 else {}
        if sel and name not in sel:
            continue
        t0 = time.time()
        files = apply_mutation(name, files, opt.get("mutate"))
        d, smt, aig, r1, r2 = yosys_prep(name, top, files, params)
        row = dict(job=name, top=top, params=params, expect=opt.get("expect", "PASS"),
                   note=opt.get("note", ""))
        if r1.returncode or r2.returncode:
            row.update(bmc="ERROR", prove="ERROR", ok=False, secs=0, detail=(r1.stderr + r2.stderr)[-1500:])
            res.append(row); print(name, "YOSYS ERROR", row["detail"][-600:]); continue
        if depth > 0 and opt.get("bmc_engine") == "abc_bmc3":
            # bit-level BMC on the AIGER model (ABC bmc3, a standard SymbiYosys engine)
            try:
                # -T: ABC stops by itself at the time budget and reports the frames it covered
                tb = opt.get("bmc_timeout", 1800)
                b = subprocess.run(["yosys-abc", "-c", f"read_aiger {aig}; fold; strash; bmc3 -F {depth} -T {tb} -v"],
                                   capture_output=True, text=True, cwd=d, timeout=tb + 300)
                open(os.path.join(d, "bmc.log"), "w").write(b.stdout + b.stderr)
                m = re.search(r"No output asserted in (\d+) frames", b.stdout)
                if "was asserted" in b.stdout:
                    row["bmc"] = "FAIL (counterexample)"
                elif m:
                    row["bmc"] = f"PASS depth {m.group(1)} (abc bmc3)"
                else:
                    row["bmc"] = "ERROR"
            except subprocess.TimeoutExpired:
                row["bmc"] = f"TIMEOUT depth {depth}"
        elif depth > 0:
            try:
                b = subprocess.run(["yosys-smtbmc", "-s", SOLVER, "--presat", "-t", str(depth), smt],
                                   capture_output=True, text=True, cwd=d, timeout=opt.get("bmc_timeout", 1800))
                open(os.path.join(d, "bmc.log"), "w").write(b.stdout + b.stderr)
                row["bmc"] = f"PASS depth {depth}" if b.returncode == 0 and "Status: PASSED" in b.stdout else \
                             ("FAIL (counterexample)" if "Status: FAILED" in b.stdout else "ERROR")
            except subprocess.TimeoutExpired:
                row["bmc"] = f"TIMEOUT depth {depth}"
        else:
            row["bmc"] = "skipped"
        if row["bmc"] == "FAIL":
            row["bmc_detail"] = "\n".join(l for l in b.stdout.splitlines() if "Assert failed" in l or "failed" in l.lower())[:800]
        if prove:
            try:
                tp = opt.get("pdr_timeout", 1800)
                a = subprocess.run(["yosys-abc", "-c", f"read_aiger {aig}; fold; strash; pdr -T {tp}; write_cex -a {d}/cex.aiw"],
                                   capture_output=True, text=True, cwd=d, timeout=tp + 300)
            except subprocess.TimeoutExpired as ex:
                a = None
            if a is None:
                row["prove"] = "UNKNOWN (PDR timeout)"
            elif "Property proved" in a.stdout:
                row["prove"] = "PROVED (unbounded, ABC PDR)"
            elif "was asserted" in a.stdout or "is asserted" in a.stdout.lower():
                row["prove"] = "FAIL (counterexample)"
            else:
                row["prove"] = "UNKNOWN"
                row["prove_detail"] = a.stdout[-600:]
        row["secs"] = round(time.time() - t0, 1)
        res.append(row)
        row["ok"] = judge(row)
        json.dump(row, open(os.path.join(d, "result.json"), "w"), indent=1)
        print(f"{name:26s} bmc={row['bmc']:22s} prove={row.get('prove','-'):30s} expect={row['expect']:4s} "
              f"{'OK' if row['ok'] else 'NOT OK'} {row['secs']}s")
    if sel:
        return 0 if all(r["ok"] for r in res) else 1
    write_report(res)
    ok = all(r["ok"] for r in res)
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
