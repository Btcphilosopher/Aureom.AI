// Formal harness: sfb_crossbar, NM = 3 masters x NS = 2 slaves, DW = 16,
// round-robin, alignment check, master 2 denied access to slave 1.
// Slave s is mapped at 0x1000_0000 + s*0x100 (256 B windows); everything
// else is unmapped.  Masters are unconstrained apart from SFB2 R2 (a held
// request keeps its payload).  Slaves are unconstrained apart from: respond
// only to an outstanding transaction, never in its acceptance cycle, and
// hold a back-pressured response (R4).
// Properties (all checked every cycle after reset):
//   P1 single outstanding per master and per slave port
//   P2 exclusive grant: at most one master handshake maps to each slave
//   P3 conservation: a master handshake that maps to slave s coincides with
//      a slave-s handshake carrying the identical payload, and every slave
//      handshake has such a master (no loss, duplication, misroute)
//   P4 ownership: a slave response reaches exactly its owner, with the
//      slave's data and error flag; s_rsp_ready is the owner's rsp_ready
//   P5 no master response without an outstanding transaction
//   P6 decode errors: unmapped/denied/misaligned requests never reach a
//      slave and are answered with rsp_error = 1, rsp_rdata = 0
//   P7 slave-side request stability (R2) and master-side response
//      stability (R4) under back-pressure
module fv_sfb_xbar (
  input logic          clk,
  input logic [2:0]    m_req_valid, m_req_write, m_rsp_ready,
  input logic [95:0]   m_req_addr,
  input logic [47:0]   m_req_wdata,
  input logic [5:0]    m_req_wstrb,
  input logic [1:0]    s_req_ready, s_rsp_valid, s_rsp_error,
  input logic [31:0]   s_rsp_rdata
);
  localparam int NM = 3, NS = 2, DW = 16, SB = 2;
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  logic [NM-1:0]    m_req_ready, m_rsp_valid, m_rsp_error;
  logic [NM*DW-1:0] m_rsp_rdata;
  logic [NS-1:0]    s_req_valid, s_req_write, s_rsp_ready;
  logic [NS*32-1:0] s_req_addr;
  logic [NS*DW-1:0] s_req_wdata;
  logic [NS*SB-1:0] s_req_wstrb;
  logic err_evt, err_write;
  logic [31:0] err_addr;
  logic [1:0] err_master;
  logic [NM-1:0] e0, e1, e2, e3;
  localparam logic [NM*NS-1:0] EN = 6'b01_11_11;      // bit m*NS+s; m2 -> s1 denied

  sfb_crossbar #(.NM(NM), .NS(NS), .AW(32), .DW(DW), .ARB_MODE(1), .CHECK_ALIGN(1),
    .SLV_BASE({32'h1000_0100, 32'h1000_0000}), .SLV_MASK({32'hFFFF_FF00, 32'hFFFF_FF00}),
    .MST_SLV_EN(EN)) dut (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .err_evt, .err_addr, .err_master, .err_write,
    .ev_req_accept(e0), .ev_req_stall(e1), .ev_arb_loss(e2), .ev_rsp_stall(e3));

`ifdef FORMAL
  // reference decoder: tg[m] = slave index (0/1) or 2 = decode error
  logic [1:0] tg [0:NM-1];
  always_comb
    for (int m = 0; m < NM; m++) begin
      tg[m] = 2'd2;
      if (m_req_addr[m*32+9 +: 23] == 23'h08_0000 && m_req_addr[m*32] == 1'b0 &&
          EN[m*NS + (m_req_addr[m*32+8] ? 1 : 0)])
        tg[m] = {1'b0, m_req_addr[m*32+8]};
    end
  // number of master handshakes mapping to each slave
  logic [1:0] nhit [0:NS-1];
  logic [NM-1:0] own;
  always_comb begin
    for (int s = 0; s < NS; s++) begin
      nhit[s] = 2'd0;
      for (int m = 0; m < NM; m++)
        if (m_req_valid[m] && m_req_ready[m] && tg[m] == 2'(s)) nhit[s] = nhit[s] + 2'd1;
    end
    for (int m = 0; m < NM; m++) begin
      own[m] = m_out[m] && m_derr[m];
      for (int s = 0; s < NS; s++)
        if (s_out[s] && s_own[s] == 2'(m) && s_rsp_valid[s]) own[m] = 1'b1;
    end
  end

  logic [NM-1:0] m_out, m_derr, mq_v, mq_r, mq_w;
  logic [NS-1:0] s_out, sq_v, sq_r, sq_w, sp_v, sp_r;
  logic [1:0]    s_own [0:NS-1];
  logic [31:0]   mq_a [0:NM-1];
  logic [15:0]   mq_d [0:NM-1];
  logic [1:0]    mq_st [0:NM-1];
  logic [31:0]   sq_a [0:NS-1];
  logic [15:0]   sq_d [0:NS-1], sp_d [0:NS-1];
  logic [1:0]    sq_st [0:NS-1];
  logic [NS-1:0] sp_e;
  logic [NM-1:0] mp_v, mp_e;
  logic [15:0]   mp_d [0:NM-1];
  logic          past;
  initial begin
    m_out = '0; m_derr = '0; s_out = '0; past = 1'b0; mq_v = '0; sq_v = '0; sp_v = '0; mp_v = '0;
  end

  always_ff @(posedge clk) begin
    past <= rst_n;
    for (int m = 0; m < NM; m++) begin
      if (m_req_valid[m] && m_req_ready[m]) begin
        m_out[m]  <= 1'b1;
        m_derr[m] <= (tg[m] == 2'd2);
      end else if (m_rsp_valid[m] && m_rsp_ready[m]) m_out[m] <= 1'b0;
      mq_v[m] <= m_req_valid[m]; mq_r[m] <= m_req_ready[m]; mq_w[m] <= m_req_write[m];
      mq_a[m] <= m_req_addr[m*32 +: 32]; mq_d[m] <= m_req_wdata[m*16 +: 16]; mq_st[m] <= m_req_wstrb[m*2 +: 2];
      mp_v[m] <= m_rsp_valid[m] && !m_rsp_ready[m]; mp_e[m] <= m_rsp_error[m]; mp_d[m] <= m_rsp_rdata[m*16 +: 16];
    end
    for (int s = 0; s < NS; s++) begin
      if (s_req_valid[s] && s_req_ready[s]) begin
        s_out[s] <= 1'b1;
        for (int m = 0; m < NM; m++)
          if (m_req_valid[m] && m_req_ready[m] && tg[m] == 2'(s)) s_own[s] <= 2'(m);
      end else if (s_rsp_valid[s] && s_rsp_ready[s]) s_out[s] <= 1'b0;
      sq_v[s] <= s_req_valid[s]; sq_r[s] <= s_req_ready[s]; sq_w[s] <= s_req_write[s];
      sq_a[s] <= s_req_addr[s*32 +: 32]; sq_d[s] <= s_req_wdata[s*16 +: 16]; sq_st[s] <= s_req_wstrb[s*2 +: 2];
      sp_v[s] <= s_rsp_valid[s] && !s_rsp_ready[s]; sp_e[s] <= s_rsp_error[s]; sp_d[s] <= s_rsp_rdata[s*16 +: 16];
    end
    if (!rst_n) begin m_out <= '0; s_out <= '0; end
  end

  // ------------------------------------------------------------ environment
  always_comb if (rst_n && past) begin
    for (int m = 0; m < NM; m++)                      // masters: R2
      if (mq_v[m] && !mq_r[m])
        assume (m_req_valid[m] && m_req_write[m] == mq_w[m] && m_req_addr[m*32 +: 32] == mq_a[m] &&
                m_req_wdata[m*16 +: 16] == mq_d[m] && m_req_wstrb[m*2 +: 2] == mq_st[m]);
    for (int s = 0; s < NS; s++)                      // slaves: R4
      if (sp_v[s]) assume (s_rsp_valid[s] && s_rsp_error[s] == sp_e[s] && s_rsp_rdata[s*16 +: 16] == sp_d[s]);
  end
  always_comb if (rst_n)
    for (int s = 0; s < NS; s++) assume (!s_rsp_valid[s] || s_out[s]);   // only for an outstanding txn

  // ------------------------------------------------------------ properties
  always_comb if (rst_n) begin
    for (int m = 0; m < NM; m++) begin
      // P1 master single outstanding
      assert (!(m_req_valid[m] && m_req_ready[m] && m_out[m] && !(m_rsp_valid[m] && m_rsp_ready[m])));
      // P5 no response without an outstanding transaction
      assert (!m_rsp_valid[m] || m_out[m]);
      // P6 decode-error responses
      if (m_rsp_valid[m] && m_out[m] && m_derr[m]) assert (m_rsp_error[m] && m_rsp_rdata[m*16 +: 16] == 16'd0);
    end
    for (int s = 0; s < NS; s++) begin
      // P1 slave single outstanding
      assert (!(s_req_valid[s] && s_req_ready[s] && s_out[s] && !(s_rsp_valid[s] && s_rsp_ready[s])));
      // P2 + P3: master handshakes mapping to s
      for (int m = 0; m < NM; m++)
        if (m_req_valid[m] && m_req_ready[m] && tg[m] == 2'(s))
          assert (s_req_valid[s] && s_req_ready[s] && s_req_addr[s*32 +: 32] == m_req_addr[m*32 +: 32] &&
                  s_req_write[s] == m_req_write[m] && s_req_wdata[s*16 +: 16] == m_req_wdata[m*16 +: 16] &&
                  s_req_wstrb[s*2 +: 2] == m_req_wstrb[m*2 +: 2]);
      assert (nhit[s] <= 2'd1);
      if (s_req_valid[s] && s_req_ready[s]) assert (nhit[s] == 2'd1);
      // P4 ownership
      if (s_out[s]) begin
        assert (s_rsp_ready[s] == m_rsp_ready[s_own[s]]);
        if (s_rsp_valid[s]) begin
          assert (m_rsp_valid[s_own[s]]);
          assert (m_rsp_rdata[s_own[s]*16 +: 16] == s_rsp_rdata[s*16 +: 16]);
          assert (m_rsp_error[s_own[s]] == s_rsp_error[s]);
        end
      end
    end
    // P4b a master only ever receives its own response (from the slave that
    // owns its transaction, or from its decode-error slave)
    for (int m = 0; m < NM; m++) if (m_rsp_valid[m]) assert (own[m]);
  end
  always_comb if (rst_n && past) begin
    // P7 stability
    for (int s = 0; s < NS; s++)
      if (sq_v[s] && !sq_r[s])
        assert (s_req_valid[s] && s_req_addr[s*32 +: 32] == sq_a[s] && s_req_write[s] == sq_w[s] &&
                s_req_wdata[s*16 +: 16] == sq_d[s] && s_req_wstrb[s*2 +: 2] == sq_st[s]);
    for (int m = 0; m < NM; m++)
      if (mp_v[m]) assert (m_rsp_valid[m] && m_rsp_error[m] == mp_e[m] && m_rsp_rdata[m*16 +: 16] == mp_d[m]);
  end
`endif
endmodule
