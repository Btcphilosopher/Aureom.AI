// Formal harness: sfb_arbiter (N requesters, MODE parameter).
// Environment: a requester keeps requesting until its grant is accepted
// (SFB2 R2); accept/stall are driven only for a valid grant and are mutually
// exclusive.  Properties:
//   A1 grant is one-hot or zero, and only to a requester (exclusive grants)
//   A2 work conserving: some request -> some grant
//   A3 grant lock: a stalled grant is repeated next cycle
//   A4 (MODE = 1) bounded waiting: while requester i waits, at most N-1
//      accepts go to other requesters (round-robin fairness)
module fv_sfb_arbiter #(
  parameter int N    = 3,
  parameter int MODE = 1
) (
  input logic         clk,
  input logic [N-1:0] req,
  input logic         stall_in,
  input logic         accept_in
);
  localparam int IW = (N > 1) ? $clog2(N) : 1;
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  logic [N-1:0]  grant;
  logic [IW-1:0] grant_idx;
  logic          grant_valid;
  wire stall  = grant_valid && stall_in && !accept_in;
  wire accept = grant_valid && accept_in;

  sfb_arbiter #(.N(N), .MODE(MODE)) dut (
    .clk, .rst_n, .req, .stall, .accept, .grant, .grant_idx, .grant_valid);

`ifdef FORMAL
  logic [N-1:0] req_q, grant_q;
  logic         acc_q, stall_q, valid_q;
  logic [3:0]   others [0:N-1];
  initial begin req_q = '0; acc_q = 1'b0; stall_q = 1'b0; valid_q = 1'b0; grant_q = '0; end
  always_ff @(posedge clk) begin
    req_q <= req; acc_q <= accept; stall_q <= stall; valid_q <= rst_n; grant_q <= grant;
    for (int i = 0; i < N; i++) begin
      if (!rst_n || !req[i] || (accept && grant[i])) others[i] <= 4'd0;
      else if (accept && !grant[i] && others[i] != 4'hF) others[i] <= others[i] + 4'd1;
    end
  end
  // environment: requests are held until accepted
  always_comb if (valid_q)
    for (int i = 0; i < N; i++) if (req_q[i] && !(acc_q && grant_q[i])) assume (req[i]);
  always_comb if (rst_n) begin
    // A1
    assert ((grant & ~req) == '0);
    assert ((grant & (grant - 1'b1)) == '0);
    assert (grant_valid == (grant != '0));
    if (grant_valid) assert (grant == (N'(1) << grant_idx));
    // A2
    assert ((req == '0) || grant_valid);
  end
  always_ff @(posedge clk) if (rst_n && valid_q) begin
    // A3
    if (stall_q && (req & grant_q) != '0) assert (grant == grant_q);
  end
  always_comb if (rst_n && MODE == 1)
    for (int i = 0; i < N; i++) assert (others[i] <= 4'(N - 1));     // A4
`endif
endmodule
