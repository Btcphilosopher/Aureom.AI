# SF-G1 optimisation log

Rules (docs/06 §3): optimise **only after profiling**; one change at a time; every change recorded on four axes — **correctness, resources, timing, throughput** — and regressions reported. Cycle numbers are *simulated cycles* (RTL under Verilator, modelled host port, `rd_lat4` unless stated); resource and Fmax numbers are *Yosys/nextpnr results* for the ULX3S-85F (speed 6); nothing is measured on hardware. Tables below are generated from `reports/results/`; the narrative was written from the same data.

## 1. Baseline profile (V0) — where the time goes

| workload (rd_lat4) | total cycles | what the device counters say |
|---|---:|---|
| `nop_single` | 139 | FETCH 128 cycles (92%): 16 single-beat reads, one per SQ dword |
| `h2d_4k` (4 KiB) | 8334 | H2D engine 8193 cycles = 8.0 per word (single-beat reads, each paying the read latency) |
| `d2h_4k` | 1169 | writes are posted: 1028 engine cycles ≈ 1 per word |
| `vec_add8` (1024 words) | 4238 | VEC engine 4097 = 4.0 cycles per word (sequential, one read port) |
| `ten_acc` (64 tiles, 1024 outputs) | 9038 | TEN engine 8897 = 8.7 cycles per output (one shared multiplier) |
| `scrub_window` (16 KiB) | 4238 | SCRUB engine 4097 = 1 word per cycle |

## 2. Step table

Throughput columns are total cycles of the named workload before → after (`rd_lat4`); Fmax is the post-route figure of the highest target met (or best final if none met) before → after, from the *final* RTL revision, so Fmax steps are **cumulative with O6**: V4/V5 figures include the O6 gain, which the O6 rows separate. Correctness is the 26-test suite on every variant (`reports/results/suite_*.txt`) plus the checks in `reports/verification-report.md`.

| step | change | profile evidence | parameters | correctness | throughput (cycles) | LUT+carry | EBR | mult | Fmax MHz |
|---|---|---|---|---|---|---|---|---|---|
| O1 v0→v1 | burst SQ fetch (one 16-beat read per command) and 64-beat DMA read bursts | device counters: FETCH = 128 of 139 cycles of a single NOP (16 single-beat reads); the H2D engine needs ≈ 8 cycles per word (every single-beat read pays the read latency) | `FETCH_BURST=1, DMA_BURST=64` | 26/26 on all variants | `kernel_vecadd_job` 11,311 → 3,835; `kernel_matmul16_job` 13,709 → 9,446; `h2d_4k` 8,334 → 1,173; `vec_add8` 4,238 → 4,133; `ten_acc` 9,038 → 8,933 | 8987 → 8886 | 40 → 40 | 4 → 4 | 43.2 → 41.8 |
| O2 v1→v2 | two read ports on device memory, pipelined VEC (1 word/cycle) | after O1 the VEC counter is 4 cycles per word (read A, read B, compute, write) for a 1024-word VEC | `VEC_MODE=1` | 26/26 on all variants | `kernel_vecadd_job` 3,835 → 2,303; `kernel_matmul16_job` 9,446 → 9,190; `vec_add8` 4,133 → 1,065; `ten_acc` 8,933 → 8,677 | 8886 → 9053 | 40 → 72 | 4 → 5 | 41.8 → 39.4 |
| O3 v2→v3 | four 8×8 multipliers, one TEN output per cycle | after O2 the TEN counter is ≈ 8 cycles per output (one shared multiplier) | `TEN_MODE=1` | 26/26 on all variants | `kernel_matmul16_job` 9,190 → 2,726; `ten_acc` 8,677 → 1,701 | 9053 → 9170 | 72 → 72 | 5 → 4 | 39.4 → 38.5 |
| O4 v3→v4 | register the BRAM read outputs; split multiply and accumulate into separate stages | nextpnr critical path of v3 (final RTL): 25.99 ns, starts at a **block-RAM output** (5.83 ns clk-to-q) and goes through the multiplier and 23 carry cells; Fmax had *fallen* with O2/O3 (§4) | `PIPE=1` | 26/26 on all variants | `kernel_vecadd_job` 2,303 → 2,304; `kernel_matmul16_job` 2,726 → 2,790; `vec_add8` 1,065 → 1,066; `ten_acc` 1,701 → 1,765 | 9170 → 9133 | 72 → 72 | 4 → 4 | 38.5 → 60.3 |
| O5 v4→v5 | register the four lane products before the adder tree | nextpnr critical path of v4 (final RTL): 16.58 ns = flop → multiplier → 16 carry cells (logic 7.04 ns, routing 9.01 ns) | `PIPE=2` | 26/26 on all variants | `kernel_vecadd_job` 2,304 → 2,305; `kernel_matmul16_job` 2,790 → 2,854; `vec_add8` 1,066 → 1,067; `ten_acc` 1,765 → 1,829 | 9133 → 9271 | 72 → 72 | 4 → 4 | 60.3 → 63.3 |
| O6 v4 (O6 off → on, same RTL, A/B @ 50 MHz target) | gate the unused mode's datapath with the build constants | §3: nextpnr critical path went through *unreachable* sequential states | `VSEQ/VPIPE/TSEQ/TPIPE` | 26/26 on all variants; engine window invariant re-proved for v0, v3, v4, v5 | unchanged (no function change) | 9,616 → 9,133 | 72 → 72 | 4 → 4 | 45.5 → 60.3 |
| O6 v5 (O6 off → on, same RTL, A/B @ 60 MHz target) | gate the unused mode's datapath with the build constants | §3: nextpnr critical path went through *unreachable* sequential states | `VSEQ/VPIPE/TSEQ/TPIPE` | 26/26 on all variants; engine window invariant re-proved for v0, v3, v4, v5 | unchanged (no function change) | 9,859 → 9,271 | 72 → 72 | 4 → 4 | 48.3 → 63.3 |

## 3. O6 — the dead-datapath finding (a profile result, not a design idea)

After O5 the post-route Fmax moved by only a couple of MHz although the multiplier→adder path it targeted had been cut. Reading the *actual* critical path (nextpnr's `--report` JSON lists every cell; `scripts/critical_path.py` summarises it; the A/B in §3.0 reproduces it) showed the path went from a flop through LUT logic into the multiplier and then **a long carry-chain adder** into a register — the multiplier→adder shape O5 had removed from the *pipelined* datapath (the A/B in §3.0 confirms the structure; which exact register ends the path is not identifiable from nextpnr's net names). Cause: the engine still contained the *sequential* VEC and TEN states (`E_VS_*`, `E_TS_*`) in builds with `VEC_MODE=1` / `TEN_MODE=1`. They are unreachable there, but synthesis cannot prove it (the state register is a free-running FSM) and static timing cannot know a path is false, so it sized the clock by them.

**Change (O6):** gate every state of the unused mode with the build constants (`VSEQ/VPIPE/TSEQ/TPIPE`, `rtl/sfg1_engine.sv`), so synthesis removes the dead logic. No function changes: the full suite passes on all variants and the engine-window invariant is proved for V0, V3, V4 and V5 on the final RTL.

### 3.0 Reproducible A/B on the final RTL (`scripts/ab_o6.sh`: a copy of `rtl/` with the gating forced off; same flow, same seed)

| variant | target MHz | O6 OFF: final Fmax | O6 OFF: TRELLIS_COMB | O6 OFF: critical path | O6 ON (shipped): final Fmax | O6 ON: TRELLIS_COMB | O6 ON: critical path |
|---|---:|---:|---:|---|---:|---:|---|
| v4 | 50 | 45.52 | 9,616 | 21.97 ns, mult yes, 34 carry cells | 60.33 | 9,133 | 16.58 ns, mult yes, 16 carry cells |
| v5 | 60 | 48.31 | 9,859 | 20.7 ns, mult yes, 31 carry cells | 63.31 | 9,271 | 15.8 ns, mult no, 10 carry cells |

### 3.0b Earlier RTL revision (before the lint fixes and the front-end fixes), kept in `reports/results/history/`

| V5 run | RTL revision | target MHz | final Fmax MHz | timing met | TRELLIS_COMB | DP16KD | MULT18X18D |
|---|---|---:|---:|---|---:|---:|---:|
| v5 | before O6 (history) | 60 | 50.52 | no | 9,316 | 72 | 4 |
| v5 | before O6 (history) | 75 | 52.20 | no | 9,298 | 72 | 4 |
| v5 | after O6 (final RTL) | 60 | 63.31 | yes | 9,271 | 72 | 4 |
| v5 | after O6 (final RTL) | 75 | 63.28 | no | 9,244 | 72 | 4 |

### 3.1 What the critical path is made of, per variant (final RTL; `scripts/critical_path.py` from nextpnr's report)

| run | path delay ns | clk-to-q | logic | routing | carry-chain cells | DSP multiplier on path | what that says |
|---|---:|---:|---:|---:|---:|---|---|
| v0_40 | 23.15 | 5.83 | 7.23 | 10.09 | 28 | yes | starts at a **block-RAM output** (5.8 ns clk-to-q) and goes through the multiplier/adders: the O4 target |
| v0_50 | 24.41 | 5.83 | 7.42 | 11.16 | 28 | yes | starts at a **block-RAM output** (5.8 ns clk-to-q) and goes through the multiplier/adders: the O4 target |
| v1_40 | 23.94 | 5.83 | 7.39 | 10.71 | 27 | yes | starts at a **block-RAM output** (5.8 ns clk-to-q) and goes through the multiplier/adders: the O4 target |
| v1_50 | 23.2 | 5.83 | 7.2 | 10.17 | 28 | yes | starts at a **block-RAM output** (5.8 ns clk-to-q) and goes through the multiplier/adders: the O4 target |
| v2_40 | 25.81 | 5.83 | 7.09 | 12.89 | 23 | yes | starts at a **block-RAM output** (5.8 ns clk-to-q) and goes through the multiplier/adders: the O4 target |
| v2_50 | 25.38 | 5.83 | 7.3 | 12.25 | 30 | yes | starts at a **block-RAM output** (5.8 ns clk-to-q) and goes through the multiplier/adders: the O4 target |
| v3_40 | 26.0 | 5.83 | 7.04 | 13.13 | 16 | yes | starts at a **block-RAM output** (5.8 ns clk-to-q) and goes through the multiplier/adders: the O4 target |
| v3_50 | 25.99 | 5.83 | 7.32 | 12.84 | 23 | yes | starts at a **block-RAM output** (5.8 ns clk-to-q) and goes through the multiplier/adders: the O4 target |
| v4_50 | 16.58 | 0.52 | 7.04 | 9.01 | 16 | yes | starts at a flop; the multiplier is still on the path |
| v4_60 | 17.58 | 0.52 | 7.11 | 9.95 | 19 | yes | starts at a flop; the multiplier is still on the path |
| v4_noO6_50 | 21.97 | 0.52 | 8.92 | 12.53 | 34 | yes | starts at a flop; the multiplier is still on the path |
| v5_60 | 15.8 | 0.52 | 3.81 | 11.46 | 10 | no | no multiplier: carry chains with routing-dominated delay (64-bit address / bounds arithmetic) |
| v5_75 | 15.8 | 0.52 | 5.09 | 10.19 | 24 | no | no multiplier: carry chains with routing-dominated delay (64-bit address / bounds arithmetic) |
| v5_noO6_60 | 20.7 | 0.52 | 8.31 | 11.86 | 31 | yes | starts at a flop; the multiplier is still on the path |

Net names after Yosys flop merging are mostly opaque, so the last row is a statement about the *structure* of the path (many carry cells, 70 % routing, no DSP), not a confirmed source line. Its shape matches the a-priori expectation in `docs/02` §4 that 64-bit address adders/comparators would limit the clock. V0–V3 start at a block-RAM output (clk-to-q 5.8 ns): registering those outputs (O4) removes that term, which is why O4 moves Fmax most (pre-O6 revision: 37.2 → 49.9 MHz; the further jump of V4 to 60.3 MHz is O6).


The same gating applies to every variant (V0/V1 lose the pipelined datapaths, V2–V5 the sequential ones), so **resource counts and Fmax of V0–V4 in this report are those of the post-O6 RTL**; their pre-O6 figures are in `reports/results/history/` and shown below for comparison.

| variant | pre-O6 best Fmax MHz (history) | pre-O6 LUT+carry | final Fmax MHz | final LUT+carry |
|---|---:|---:|---:|---:|
| v0 | 40.8 | 9087 | 43.2 | 8987 |
| v1 | 41.2 | 9144 | 41.8 | 8886 |
| v2 | 37.9 | 9148 | 39.4 | 9053 |
| v3 | 37.2 | 9185 | 38.5 | 9170 |
| v4 | 49.9 | 9254 | 60.3 | 9133 |
| v5 | 52.2 | 9298 | 63.3 | 9271 |

## 4. Regressions and things that did not help

* **O2 and O3 lowered Fmax** (more parallel datapath on one clock) while cutting cycles; O4 was the fix for that. Cycles were bought first, timing second, and the report shows both.
* **O5 gave little**: before O6 it moved Fmax by only ≈ +1–3 MHz (history table in §3); after O6, V4 → V5 is 60.3 → 63.3 MHz — a few MHz, the size of seed-to-seed variation. My reading of the V4 path as the *live* TEN adder tree was a guess; only the cell-level path report of V5 showed it was the dead sequential datapath (§3).
* A front-end formal run (not an optimisation) forced three functional changes late (R9 sampled registers, base alignment, enable-while-busy; `docs/01` F1–F3). They add 192 flip-flops (shadow queue registers) and some comparators; all numbers in this report are *after* them.
* The 100 MHz aspiration of `docs/02` §4 was **not reached**; see the Fmax table in `reports/perf-report.md` §3.1 for what was.

## 5. Process note

The order above is the order I found things in, not a retrospective tidy-up: V0–V3 results were first produced on an *earlier RTL revision* (before the lint fixes, O6 and the front-end fixes); those files are preserved in `reports/results/history/` and every result outside that directory was regenerated on the final RTL (hash in `reports/results/MANIFEST.txt`).

## 6. Next steps the profile points to (not done)

1. **SQ prefetch / command overlap.** With a 100-cycle host read latency a single NOP costs 130 cycles vs 34 at latency 4: the SQ fetch is an un-overlapped round trip per command. Fetching the next entry while the engine runs hides it. 
2. **SCRUB at 1 word/cycle** (4133 cycles for a 16 KiB window, run on every context open and close by the driver): a 4-words/cycle scrub port or a valid-bit scheme would cut it.
3. **Shorten what is critical now (V5):** the path has no multiplier but long carry chains with ≈ 70 % routing delay — by its structure the 64-bit host-address/bounds arithmetic (`sfg1_cmdchk`, front-end). Registering the comparator results (one extra cycle per command, ≈ 3 % on a NOP stream) is the profile-justified next step; I did not do it.
3b. Let Yosys use the DSP's own input/output registers (`MULT18X18D`) instead of fabric flops; the multiplier block alone costs ≈ 3.9 ns in the V4 path report.
4. Host data path is 32-bit; a 64-bit port doubles H2D/D2H payload rate where the link allows.

