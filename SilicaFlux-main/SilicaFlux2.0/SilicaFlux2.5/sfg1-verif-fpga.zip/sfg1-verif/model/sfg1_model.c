// SPDX-License-Identifier: GPL-2.0-only
#include "sfg1_model.h"
#include <string.h>

static inline int range_ok(uint64_t off, uint64_t n, uint64_t win)
{
	return n <= win && off <= win - n;       /* overflow-free */
}

static inline uint32_t ld32(const uint8_t *p) { uint32_t v; memcpy(&v, p, 4); return v; }
static inline void st32(uint8_t *p, uint32_t v) { memcpy(p, &v, 4); }

int32_t sfg1m_dot8(uint32_t a, uint32_t b)
{
	int32_t s = 0;
	for (int k = 0; k < 4; k++)
		s += (int32_t)(int8_t)(a >> (8 * k)) * (int32_t)(int8_t)(b >> (8 * k));
	return s;
}

uint32_t sfg1m_vec_lane(uint32_t op, uint32_t a, uint32_t b)
{
	if (op == SFG1M_VEC_XOR32) return a ^ b;
	if (op == SFG1M_VEC_AND32) return a & b;
	uint32_t r = 0;
	for (int k = 0; k < 4; k++) {
		int x = (int8_t)(a >> (8 * k)), y = (int8_t)(b >> (8 * k)), v = 0;
		switch (op) {
		case SFG1M_VEC_ADD8:  v = x + y; break;
		case SFG1M_VEC_SUB8:  v = x - y; break;
		case SFG1M_VEC_MAX8:  v = x > y ? x : y; break;
		case SFG1M_VEC_RELU8: v = x < 0 ? 0 : x; break;
		case SFG1M_VEC_MUL8:  v = x * y; break;
		}
		r |= (uint32_t)(uint8_t)v << (8 * k);
	}
	return r;
}

uint8_t sfg1m_check(const sfg1m_dev *d, const sfg1m_sqe *e)
{
	const uint64_t win = d->win_bytes;
	const uint64_t len = e->len, a = e->dev_a, b = e->dev_b, c = e->dev_c;
	uint64_t n, n2;

	if (e->ctx_id >= d->max_ctx) return SFG1M_ST_BAD_CTX;
	if (e->rsvd0 || e->rsvd1)    return SFG1M_ST_BAD_ARGS;

	switch (e->opcode) {
	case SFG1M_OP_NOP:
	case SFG1M_OP_SCRUB:
		/* fields an opcode does not use must be zero (contract 4.1) */
		if (e->flags || e->exec_op || e->host_addr || len || a || b || c)
			return SFG1M_ST_BAD_ARGS;
		return SFG1M_ST_OK;

	case SFG1M_OP_DMA_H2D:
	case SFG1M_OP_DMA_D2H:
		if (e->flags || e->exec_op || b || c) return SFG1M_ST_BAD_ARGS;
		if (!len || ((len | a) & 3))          return SFG1M_ST_BOUNDS;
		if (!range_ok(a, len, win))           return SFG1M_ST_BOUNDS;
		if (__builtin_add_overflow(e->host_addr, len, &n)) return SFG1M_ST_DMA_ERROR; /* host range wraps */
		return SFG1M_ST_OK;

	case SFG1M_OP_VEC:
		if (e->flags || e->host_addr || e->exec_op > SFG1M_VEC_DOT8) return SFG1M_ST_BAD_ARGS;
		if (!len || ((a | b | c) & 3) || __builtin_mul_overflow(len, 4ull, &n)) return SFG1M_ST_BOUNDS;
		if (e->exec_op == SFG1M_VEC_RELU8 && b) return SFG1M_ST_BAD_ARGS;
		n2 = e->exec_op == SFG1M_VEC_DOT8 ? 4 : n;
		if (!range_ok(a, n, win) || (e->exec_op != SFG1M_VEC_RELU8 && !range_ok(b, n, win)) ||
		    !range_ok(c, n2, win))
			return SFG1M_ST_BOUNDS;
		return SFG1M_ST_OK;

	case SFG1M_OP_TEN:
		if ((e->flags & ~SFG1M_CMDF_TEN_ACC) || e->exec_op || e->host_addr) return SFG1M_ST_BAD_ARGS;
		if (!len || ((a | b | c) & 3) || __builtin_mul_overflow(len, 16ull, &n) ||
		    __builtin_mul_overflow(len, 64ull, &n2))
			return SFG1M_ST_BOUNDS;
		if (!range_ok(a, n, win) || !range_ok(b, n, win) || !range_ok(c, n2, win))
			return SFG1M_ST_BOUNDS;
		return SFG1M_ST_OK;
	}
	return SFG1M_ST_BAD_OPCODE;
}

uint8_t sfg1m_exec(sfg1m_dev *d, const sfg1m_sqe *e, const sfg1m_host *h)
{
	uint8_t st = sfg1m_check(d, e);
	if (st) return st;
	uint8_t *w = d->mem + (uint64_t)e->ctx_id * d->win_bytes;
	const uint64_t len = e->len, a = e->dev_a, b = e->dev_b, c = e->dev_c;

	switch (e->opcode) {
	case SFG1M_OP_NOP: return SFG1M_ST_OK;
	case SFG1M_OP_SCRUB: memset(w, 0, d->win_bytes); return SFG1M_ST_OK;
	case SFG1M_OP_DMA_H2D:
		return h->read(h->user, e->host_addr, w + a, len) ? SFG1M_ST_DMA_ERROR : SFG1M_ST_OK;
	case SFG1M_OP_DMA_D2H:
		return h->write(h->user, e->host_addr, w + a, len) ? SFG1M_ST_DMA_ERROR : SFG1M_ST_OK;
	case SFG1M_OP_VEC: {
		if (e->exec_op == SFG1M_VEC_DOT8) {
			int32_t acc = 0;
			for (uint64_t i = 0; i < len; i++)
				acc = (int32_t)((uint32_t)acc + (uint32_t)sfg1m_dot8(ld32(w + a + 4 * i), ld32(w + b + 4 * i)));
			st32(w + c, (uint32_t)acc);
			return SFG1M_ST_OK;
		}
		for (uint64_t i = 0; i < len; i++) {       /* element order matters for overlapping C */
			uint32_t x = ld32(w + a + 4 * i);
			uint32_t y = e->exec_op == SFG1M_VEC_RELU8 ? 0 : ld32(w + b + 4 * i);
			st32(w + c + 4 * i, sfg1m_vec_lane(e->exec_op, x, y));
		}
		return SFG1M_ST_OK;
	}
	case SFG1M_OP_TEN:
		for (uint64_t t = 0; t < len; t++) {
			const int8_t *A = (const int8_t *)(w + a + 16 * t);
			const int8_t *B = (const int8_t *)(w + b + 16 * t);
			uint8_t *C = w + c + 64 * t;
			uint32_t out[16];
			for (int r = 0; r < 4; r++)
				for (int q = 0; q < 4; q++) {
					uint32_t acc = (e->flags & SFG1M_CMDF_TEN_ACC) ? ld32(C + 4 * (4 * r + q)) : 0;
					for (int k = 0; k < 4; k++)
						acc += (uint32_t)((int32_t)A[4 * r + k] * (int32_t)B[4 * k + q]);
					out[4 * r + q] = acc;
				}
			for (int i = 0; i < 16; i++) st32(C + 4 * i, out[i]);
		}
		return SFG1M_ST_OK;
	}
	return SFG1M_ST_BAD_OPCODE;
}
