/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * SF-G1 golden model: command-level behaviour of the device per the DRAFT v1.0 contract
 * (vendor/sfg1-driver/docs/02-hw-interface.md sections 4, 8, 9, 10), written from the contract
 * text and independent of both the RTL (rtl/sfg1_cmdchk.sv, rtl/sfg1_engine.sv) and the driver's
 * mock (kernel/sfg1_mock.c). The model is compared against BOTH:
 *   - the driver's own mock_exec(), extracted verbatim (tb/unit/fuzz_model_vs_mock.c)
 *   - the RTL, through the co-simulation (tb/cosim: diff, directed, stress)
 * Constants below are cross-checked against kernel/sfg1_hw.h by scripts/contract_check.py.
 */
#ifndef SFG1_MODEL_H
#define SFG1_MODEL_H
#include <stdint.h>
#include <stddef.h>

#define SFG1M_CHIP_ID          0x53464001u
#define SFG1M_OP_NOP           0
#define SFG1M_OP_DMA_H2D       1
#define SFG1M_OP_VEC           2
#define SFG1M_OP_TEN           3
#define SFG1M_OP_DMA_D2H       5
#define SFG1M_OP_SCRUB         6
#define SFG1M_ST_OK            0
#define SFG1M_ST_BAD_OPCODE    1
#define SFG1M_ST_BAD_CTX       2
#define SFG1M_ST_ENGINE_DISABLED 3
#define SFG1M_ST_BOUNDS        4
#define SFG1M_ST_FETCH_ERROR   5
#define SFG1M_ST_DMA_ERROR     6
#define SFG1M_ST_BAD_ARGS      7
#define SFG1M_VEC_ADD8         0
#define SFG1M_VEC_SUB8         1
#define SFG1M_VEC_MAX8         2
#define SFG1M_VEC_RELU8        3
#define SFG1M_VEC_XOR32        4
#define SFG1M_VEC_AND32        5
#define SFG1M_VEC_MUL8         6
#define SFG1M_VEC_DOT8         7
#define SFG1M_CMDF_TEN_ACC     1u

/* 64-byte submission-queue entry, little-endian host (as in kernel/sfg1_hw.h) */
typedef struct __attribute__((packed)) {
	uint16_t opcode, ctx_id, cid, flags;
	uint32_t exec_op, rsvd0;
	uint64_t host_addr, len, dev_a, dev_b, dev_c, rsvd1;
} sfg1m_sqe;
#ifdef __cplusplus
static_assert(sizeof(sfg1m_sqe) == 64, "SQ entry must be 64 bytes");
extern "C" {
#else
_Static_assert(sizeof(sfg1m_sqe) == 64, "SQ entry must be 64 bytes");
#endif

/* host memory as seen by the device DMA engine; return 0 on success, non-zero = fault */
typedef struct {
	int (*read)(void *user, uint64_t addr, void *buf, uint64_t len);
	int (*write)(void *user, uint64_t addr, const void *buf, uint64_t len);
	void *user;
} sfg1m_host;

typedef struct {
	uint32_t max_ctx;
	uint32_t win_bytes;           /* window per context */
	uint8_t *mem;                 /* max_ctx * win_bytes */
} sfg1m_dev;

/* Static decision (BAD_CTX / BAD_ARGS / BAD_OPCODE / BOUNDS) or OK. No side effects. */
uint8_t sfg1m_check(const sfg1m_dev *d, const sfg1m_sqe *e);
/* Check, then execute against device memory and host DMA. Returns the completion status. */
uint8_t sfg1m_exec(sfg1m_dev *d, const sfg1m_sqe *e, const sfg1m_host *h);
/* INT8x4 lane ops, exposed so unit tests can compare them with the RTL ALU directly */
uint32_t sfg1m_vec_lane(uint32_t op, uint32_t a, uint32_t b);
int32_t  sfg1m_dot8(uint32_t a, uint32_t b);
#ifdef __cplusplus
}
#endif
#endif
