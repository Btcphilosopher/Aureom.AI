#!/usr/bin/env python3
"""SF-G1 bring-up / measurement tool for the FPGA shell (rtl/fpga) -- one script, two links.

  --sim build/shell_v3/shell_sim     the Verilated FPGA top (simulation; no hardware involved)
  --port /dev/ttyUSB0 [--baud N]     a real ULX3S running the bitstream (NOT exercised by this project:
                                     no board was available; see docs/05-limitations.md)

It speaks the shell's UART protocol (rtl/fpga/sfg1_bridge.sv), discovers the device with the
contract's sequence (docs/02 section 2), builds the queues in the shell's host-RAM stand-in, runs
kernels, verifies results against a Python reference and reads the device's own cycle counters.
Every result is labelled with where it came from: "simulation" or "hardware". The performance
report keeps those apart; this tool cannot turn one into the other.
"""
import argparse, json, struct, subprocess, sys, time

SQ_BASE, CQ_BASE, BUF_A, BUF_B, BUF_C, BUF_D = 0x0400, 0x0800, 0x1000, 0x1800, 0x2000, 0x2800
R = dict(ID=0x000, HWVER=0x004, CAPS=0x008, LIM0=0x00c, LIM1=0x010, CTRL=0x020, STATUS=0x024, RESET=0x028,
         IRQ_STATUS=0x030, IRQ_MASK=0x034, SQ_BASE_LO=0x040, SQ_BASE_HI=0x044, SQ_ENTRIES=0x048, SQ_TAIL=0x04c,
         CQ_BASE_LO=0x050, CQ_BASE_HI=0x054, CQ_ENTRIES=0x058, CQ_HEAD=0x05c, SQ_HEAD=0x060, CQ_TAIL=0x064,
         DONE=0x068, ERR=0x06c, SCRATCH=0x07c)
PERF = dict(CTRL=0x100, CYCLES=0x104, BUSY=0x108, CMDS=0x10c, FETCH=0x110, DECODE=0x114, EXEC=0x118, WB=0x11c,
            H2D=0x120, D2H=0x124, VEC=0x128, TEN=0x12c, SCRUB=0x130, RD_BEATS=0x134, WR_BEATS=0x138,
            RD_STALL=0x13c, WR_STALL=0x140)
OP_NOP, OP_H2D, OP_VEC, OP_TEN, OP_D2H, OP_SCRUB = 0, 1, 2, 3, 5, 6


class SimLink:
    kind = "simulation"
    def __init__(self, path, mhz=50, baud=2000000):
        self.p = subprocess.Popen([path, str(mhz), str(baud)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, bufsize=0)
    def write(self, b): self.p.stdin.write(b); self.p.stdin.flush()
    def read(self, n):
        out = b""
        while len(out) < n:
            c = self.p.stdout.read(n - len(out))
            if not c: raise IOError("shell simulator closed")
            out += c
        return out
    def close(self):
        try: self.p.stdin.close(); self.p.wait(timeout=20)
        except Exception: self.p.kill()


class SerialLink:
    kind = "hardware"
    def __init__(self, port, baud=2000000):
        import serial                                    # pip install pyserial (only needed with real hardware)
        self.s = serial.Serial(port, baud, timeout=2)
    def write(self, b): self.s.write(b)
    def read(self, n):
        d = self.s.read(n)
        if len(d) != n: raise IOError("serial timeout")
        return d
    def close(self): self.s.close()


class Dev:
    def __init__(self, link): self.l = link
    def ping(self): self.l.write(b"?"); return self.l.read(4)
    def wr(self, a, v): self.l.write(b"W" + struct.pack("<HI", a, v & 0xffffffff)); assert self.l.read(1) == b"\x06"
    def rd(self, a): self.l.write(b"R" + struct.pack("<H", a)); return struct.unpack("<I", self.l.read(4))[0]
    def mem_wr(self, a, data):
        assert a % 4 == 0 and len(data) % 4 == 0
        self.l.write(b"M" + struct.pack("<HH", a, len(data)) + bytes(data)); assert self.l.read(1) == b"\x06"
    def mem_rd(self, a, n):
        assert a % 4 == 0 and n % 4 == 0
        self.l.write(b"m" + struct.pack("<HH", a, n)); return self.l.read(n)
    def irqs(self): self.l.write(b"I"); return self.l.read(1)[0]
    def perf(self): return {k: self.rd(v) for k, v in PERF.items() if k != "CTRL"}
    def perf_clear(self): self.wr(PERF["CTRL"], 1)

    # ---- contract bring-up (docs/02 section 2, then enable) ----
    def discover(self):
        assert self.ping() == b"SFG1", "no SF-G1 shell answered"
        assert self.rd(R["ID"]) == 0x53464001, "wrong chip id"
        assert self.rd(R["HWVER"]) >> 16 == 1
        l0, l1 = self.rd(R["LIM0"]), self.rd(R["LIM1"])
        self.max_ctx, self.max_q, self.win = l0 & 0xffff, l0 >> 16, (l1 >> 16) * 1024
        self.wr(R["SCRATCH"], 0xa5a5a5a5); assert self.rd(R["SCRATCH"]) == 0xa5a5a5a5
        self.wr(R["SCRATCH"], 0x5a5a5a5a); assert self.rd(R["SCRATCH"]) == 0x5a5a5a5a
        self.wr(R["SCRATCH"], 0)
        return dict(max_ctx=self.max_ctx, max_qent=self.max_q, window=self.win, caps=self.rd(R["CAPS"]))

    def setup(self, entries=16):
        self.n = entries; self.tail = 0; self.cq_head = 0; self.phase = 1
        self.mem_wr(SQ_BASE, bytes(64 * entries)); self.mem_wr(CQ_BASE, bytes(16 * entries))
        self.wr(R["CTRL"], 0)
        self.wr(R["SQ_BASE_LO"], SQ_BASE); self.wr(R["SQ_BASE_HI"], 0); self.wr(R["SQ_ENTRIES"], entries)
        self.wr(R["CQ_BASE_LO"], CQ_BASE); self.wr(R["CQ_BASE_HI"], 0); self.wr(R["CQ_ENTRIES"], entries)
        self.wr(R["IRQ_STATUS"], 7); self.wr(R["IRQ_MASK"], 7); self.wr(R["CTRL"], 1)

    def sqe(self, op, ctx=0, flags=0, exec_op=0, host=0, ln=0, a=0, b=0, c=0, rsvd0=0, rsvd1=0):
        cid = self.tail
        return struct.pack("<HHHHIIQQQQQQ", op, ctx, cid, flags, exec_op, rsvd0, host, ln, a, b, c, rsvd1)

    def run(self, cmds, timeout_s=20):
        """cmds: list of (kwargs). Returns list of (status, cid). Stops at the first error (device halts, R7)."""
        out = []; i = 0
        while i < len(cmds):
            n = min(len(cmds) - i, self.n - 1)
            for k in range(n):
                self.mem_wr(SQ_BASE + 64 * self.tail, self.sqe(**cmds[i + k])); self.tail = (self.tail + 1) % self.n
            self.wr(R["SQ_TAIL"], self.tail)
            got = 0; t0 = time.time(); halted = False
            while got < n:
                slot = self.mem_rd(CQ_BASE + 16 * self.cq_head, 16)
                sp = struct.unpack("<H", slot[14:16])[0]
                if (sp & 1) == self.phase:
                    out.append((sp >> 1, struct.unpack("<H", slot[12:14])[0])); got += 1
                    self.cq_head = (self.cq_head + 1) % self.n
                    if self.cq_head == 0: self.phase ^= 1
                    self.wr(R["CQ_HEAD"], self.cq_head)
                    if sp >> 1: halted = True; break
                elif time.time() - t0 > timeout_s: raise TimeoutError("no completion")
            i += n if not halted else len(cmds)
            if halted: break
        return out

    def clear_halt(self): self.wr(R["IRQ_STATUS"], 7); self.wr(R["CTRL"], 1 | 4)


def ref_vec(op, a, b):
    out = bytearray()
    for x, y in zip(a, b):
        sx, sy = x - 256 if x > 127 else x, y - 256 if y > 127 else y
        out.append({0: sx + sy, 1: sx - sy, 2: max(sx, sy), 6: sx * sy}[op] & 0xff)
    return bytes(out)


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--sim"); g.add_argument("--port")
    ap.add_argument("--baud", type=int, default=2000000); ap.add_argument("--json", default=None)
    ap.add_argument("--lanes", type=int, default=1024, help="INT8 lanes in the vector kernel")
    a = ap.parse_args()
    link = SimLink(a.sim, baud=a.baud) if a.sim else SerialLink(a.port, a.baud)
    d = Dev(link); results = dict(link=link.kind, measured_on_hardware=(link.kind == "hardware"), workloads=[], checks=[])
    ok = True
    def check(name, cond, detail=""):
        nonlocal ok
        ok &= bool(cond); results["checks"].append(dict(name=name, ok=bool(cond), detail=detail))
        print(("PASS " if cond else "FAIL ") + name + (" " + detail if detail and not cond else ""))
    try:
        info = d.discover(); results["device"] = info; print("discovered", info)
        d.wr(R["RESET"], 0x52455345); time.sleep(0.01)
        while d.rd(R["STATUS"]) & 0x10: pass
        d.setup(16)
        # ---- workload 1: vector add through the full ring protocol ----
        n = a.lanes; import random; rnd = random.Random(1)
        A = bytes(rnd.randrange(256) for _ in range(n)); B = bytes(rnd.randrange(256) for _ in range(n))
        d.mem_wr(BUF_A, A); d.mem_wr(BUF_B, B)
        d.perf_clear(); d.irqs(); t0 = time.time()
        r = d.run([dict(op=OP_SCRUB), dict(op=OP_H2D, host=BUF_A, ln=n, a=0), dict(op=OP_H2D, host=BUF_B, ln=n, a=n),
                   dict(op=OP_VEC, exec_op=0, ln=n // 4, a=0, b=n, c=2 * n), dict(op=OP_D2H, host=BUF_C, ln=n, a=2 * n)])
        wall = time.time() - t0
        got = d.mem_rd(BUF_C, n); pc = d.perf()
        check("vecadd statuses all OK", all(s == 0 for s, _ in r) and len(r) == 5, str(r))
        check("vecadd result == Python reference", got == ref_vec(0, A, B))
        check("interrupt messages observed", d.irqs() >= 1)
        results["workloads"].append(dict(name="vecadd_%d_lanes" % n, host_wall_s=round(wall, 4), perf=pc))
        # ---- workload 2: matmul tiles with accumulate ----
        tiles = 8; At = bytes(rnd.randrange(256) for _ in range(16 * tiles)); Bt = bytes(rnd.randrange(256) for _ in range(16 * tiles))
        d.mem_wr(BUF_A, At); d.mem_wr(BUF_B, Bt); d.perf_clear()
        r = d.run([dict(op=OP_SCRUB), dict(op=OP_H2D, host=BUF_A, ln=16 * tiles, a=0), dict(op=OP_H2D, host=BUF_B, ln=16 * tiles, a=256),
                   dict(op=OP_TEN, ln=tiles, a=0, b=256, c=512), dict(op=OP_TEN, flags=1, ln=tiles, a=0, b=256, c=512),
                   dict(op=OP_D2H, host=BUF_D, ln=64 * tiles, a=512)])
        pc = d.perf(); out = d.mem_rd(BUF_D, 64 * tiles); okm = True
        for t in range(tiles):
            for i in range(4):
                for j in range(4):
                    acc = sum((lambda x: x - 256 if x > 127 else x)(At[16 * t + 4 * i + k]) * (lambda x: x - 256 if x > 127 else x)(Bt[16 * t + 4 * k + j]) for k in range(4))
                    v = struct.unpack("<i", out[64 * t + 4 * (4 * i + j):64 * t + 4 * (4 * i + j) + 4])[0]
                    okm &= (v == 2 * acc)
        check("matmul (C=A*B; C+=A*B) result == Python reference", okm and all(s == 0 for s, _ in r))
        results["workloads"].append(dict(name="matmul_%d_tiles_acc" % tiles, perf=pc))
        # ---- workload 3: invalid command -> error CQE, queue halts, CLEAR_HALT resumes ----
        e0 = d.rd(R["ERR"])
        r = d.run([dict(op=OP_VEC, exec_op=9, ln=4, a=0, b=16, c=32)])
        check("invalid VEC exec_op -> BAD_ARGS (7) and halt", r and r[0][0] == 7 and (d.rd(R["STATUS"]) & 4) != 0, str(r))
        check("ERR_COUNT advanced", d.rd(R["ERR"]) == e0 + 1)
        d.clear_halt(); r = d.run([dict(op=OP_NOP)]); check("device usable after CLEAR_HALT", r and r[0][0] == 0)
        # ---- workload 4: ENGINE_RESET + recovery ----
        d.wr(R["CTRL"], 2)
        while d.rd(R["STATUS"]) & 0x10: pass
        d.setup(16); r = d.run([dict(op=OP_NOP)]); check("device usable after ENGINE_RESET", r and r[0][0] == 0)
        results["status"] = "PASS" if ok else "FAIL"
    finally:
        link.close()
    if a.json: json.dump(results, open(a.json, "w"), indent=1)
    print("BRINGUP", results.get("status", "ERROR"), "(link: %s%s)" % (link.kind, "" if link.kind == "hardware" else "; NOT hardware"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
