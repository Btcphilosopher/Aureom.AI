# RTL variants. Every variant is built from the SAME sources; only parameters differ, and the
# whole verification suite runs on each. See reports/optimisation-log.md for what each step changes.
#   FETCH_BURST  SQ entry fetched as one 16-beat read (1) instead of 16 single-beat reads (0)
#   DMA_BURST    max host read burst for DMA_H2D, in 32-bit beats (1 = single-beat)
#   VEC_MODE     0 sequential, one read port | 1 two read copies, pipelined (1 word/cycle)
#   TEN_MODE     0 sequential, one multiplier | 1 four multipliers, pipelined (1 output/cycle)
V0_PARAMS = -GFETCH_BURST=0 -GDMA_BURST=1  -GVEC_MODE=0 -GTEN_MODE=0
V1_PARAMS = -GFETCH_BURST=1 -GDMA_BURST=64 -GVEC_MODE=0 -GTEN_MODE=0
V2_PARAMS = -GFETCH_BURST=1 -GDMA_BURST=64 -GVEC_MODE=1 -GTEN_MODE=0
V3_PARAMS = -GFETCH_BURST=1 -GDMA_BURST=64 -GVEC_MODE=1 -GTEN_MODE=1
V4_PARAMS = -GFETCH_BURST=1 -GDMA_BURST=64 -GVEC_MODE=1 -GTEN_MODE=1 -GPIPE=1
V5_PARAMS = -GFETCH_BURST=1 -GDMA_BURST=64 -GVEC_MODE=1 -GTEN_MODE=1 -GPIPE=2
