#!/bin/bash
# One-time environment setup. Tested on Ubuntu 24.04 (apt: verilator 5.020, yosys 0.33, z3 4.8.12). The FPGA tools are pinned pip wheels
# (YoWASP) installed into ./.venv. Run from the project root: `make setup`.
set -euo pipefail; cd "$(dirname "$0")/.."
need=()
for t in verilator yosys yosys-abc z3 g++ make python3; do command -v "$t" >/dev/null || need+=("$t"); done
if [ ${#need[@]} -gt 0 ]; then
  echo "missing tools: ${need[*]} -- installing apt packages (needs root)"
  apt-get update && apt-get install -y --no-install-recommends verilator yosys z3 g++ make python3 python3-venv
fi
python3 -m venv .venv && .venv/bin/pip install -q -r requirements.txt
echo "verilator:    $(verilator --version)"
echo "yosys (apt):  $(yosys -V)    z3: $(z3 --version)"
echo "yowasp-yosys: $(.venv/bin/yowasp-yosys -V | head -1)"
echo "nextpnr-ecp5: $(.venv/bin/yowasp-nextpnr-ecp5 --version 2>&1 | head -1)"
echo "optional: pyserial is only needed for tools/sfg1_bringup.py --port with a real board (pip install pyserial)"
