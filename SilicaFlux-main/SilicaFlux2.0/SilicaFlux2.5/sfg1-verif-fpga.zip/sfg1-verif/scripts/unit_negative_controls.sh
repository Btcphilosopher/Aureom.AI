#!/bin/bash
# Negative controls for the leaf-module unit simulations: build vecalu / cmdchk with a deliberate bug (MUT=n) and require the
# unit test to REPORT MISMATCHES (non-zero exit). A unit test that cannot fail proves nothing.
set -uo pipefail; cd "$(dirname "$0")/.."; export PATH=$PWD/.venv/bin:$PATH
make -s build/libmodel.a
ok=1
run() {   # name top rtl extra-verilator extra-cflags mut desc
  local d=build/unit_neg/$1_m$6; mkdir -p $d
  verilator --cc --exe --build -j 2 -Wno-fatal -Wno-lint -Wno-style -O3 --x-initial unique -Irtl -Imodel --top-module $2 --prefix V$1 --Mdir $d -o unit_$1 $4 -GMUT=$6 \
     -CFLAGS "-std=gnu++17 -O2 -I$PWD/model $5" -LDFLAGS "$PWD/build/libmodel.a" $3 $PWD/tb/unit/unit_$1.cpp > $d/build.log 2>&1 || { echo "  build failed ($1 MUT=$6)"; tail -5 $d/build.log; ok=0; return; }
  if $d/unit_$1 > $d/out.txt 2>&1; then echo "  $1 MUT=$6 ($7): NOT DETECTED"; ok=0; else echo "  $1 MUT=$6 ($7): detected  ($(tail -n 1 $d/out.txt | cut -c1-90))"; fi
}
run vecalu sfg1_vecalu rtl/sfg1_vecalu.sv "" "" 12 "SUB8 operands swapped"
run vecalu sfg1_vecalu rtl/sfg1_vecalu.sv "" "" 18 "DOT8 omits lane 3"
run cmdchk sfg1_cmdchk rtl/sfg1_cmdchk.sv "-GWIN_B=4096" "-DWINB=4096" 10 "window bound off by one word"
run cmdchk sfg1_cmdchk rtl/sfg1_cmdchk.sv "-GWIN_B=4096" "-DWINB=4096" 11 "NOP with non-zero fields accepted"
run cmdchk sfg1_cmdchk rtl/sfg1_cmdchk.sv "-GWIN_B=4096" "-DWINB=4096" 15 "VEC length overflow ignored"
[ $ok = 1 ] && echo "UNIT NEGATIVE CONTROLS: OK" || { echo "UNIT NEGATIVE CONTROLS: FAILED"; exit 1; }
