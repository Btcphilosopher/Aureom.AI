#!/bin/bash
# Reproducible A/B for optimisation O6 (dead-mode datapath gating, rtl/sfg1_engine.sv): build a COPY of rtl/ in which the four gating constants are
# forced to 1 (= the unused mode's states stay in the netlist, as before O6), then run the same flow on it. Function is identical (those states
# are unreachable); only the netlist differs. The shipped RTL is not modified. Usage: scripts/ab_o6.sh [variant] [MHz]   (default v5 60)
set -euo pipefail; cd "$(dirname "$0")/.."; export PATH=$PWD/.venv/bin:$PATH
V=${1:-v5}; MHZ=${2:-60}; D=build/ab_o6/${V}_${MHZ}/rtl
mkdir -p "$D" && cp -r rtl/. "$D/" && python3 - <<PY
p = "$D/sfg1_engine.sv"; s = open(p).read()
a = "localparam VSEQ = (VEC_MODE == 0), VPIPE = (VEC_MODE == 1), TSEQ = (TEN_MODE == 0), TPIPE = (TEN_MODE == 1);"
assert a in s, "gating line not found (rtl/ changed?)"; open(p, "w").write(s.replace(a, "localparam VSEQ = 1, VPIPE = 1, TSEQ = 1, TPIPE = 1;   // A/B copy: O6 gating OFF"))
PY
python3 fpga/synth/run_flow.py --variant "$V" --mhz "$MHZ" --seeds 1 --rtl "$D" --tag _noO6
