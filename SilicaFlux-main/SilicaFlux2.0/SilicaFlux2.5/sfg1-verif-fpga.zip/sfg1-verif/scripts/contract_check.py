#!/usr/bin/env python3
"""Cross-check every place the SF-G1 draft contract is encoded.

  C header (driver)        vendor/sfg1-driver/kernel/sfg1_hw.h          <- reference for names/values
  SV package (driver RTL)  vendor/sfg1-driver/rtl/sfg1_pkg.sv
  RTL constants (this prj) rtl/sfg1_defs.svh
  golden model             model/sfg1_model.h        (SFG1M_* names)
  C++ test host            tb/cosim/hostq.h          (register offsets, enums)
  Python bring-up tool     tools/sfg1_bringup.py     (register offsets)

Each constant that appears in more than one place must have the same value. Bit-position
constants (CTRL/STATUS/IRQ/CAP) are stored as BIT(n) in C and as plain integer positions in SV.
`--selftest` proves the checker can fail: it injects a one-value change into a private copy of each
source in turn and requires a mismatch to be reported.
"""
import os, re, shutil, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def num(s):
    s = s.strip().rstrip("uUlL")
    m = re.match(r"(\d+)'([hHdD])([0-9a-fA-F_]+)$", s)
    if m: return int(m.group(3).replace("_", ""), 16 if m.group(2) in "hH" else 10)
    return int(s, 0)

def parse_c(text):
    d = {}                                            # name -> (value, kind) kind: 'val' | 'bit'
    for m in re.finditer(r"#define\s+(SFG1_\w+)\s+BIT\((\d+)\)", text): d[m.group(1)] = (int(m.group(2)), "bit")
    for m in re.finditer(r"#define\s+(SFG1_\w+)\s+(0x[0-9a-fA-F]+u?|\d+u?)\b", text):
        if m.group(1) not in d: d[m.group(1)] = (num(m.group(2)), "val")
    return d

def parse_sv(text):
    d = {}
    for m in re.finditer(r"localparam\s+(?:(integer|int)|(?:logic\s*)?\[[^\]]+\])\s+((?:SFG1|SFX)_\w+)\s*=\s*([^;,]+)[;,]", text):
        d[m.group(2)] = (num(m.group(3)), "int" if m.group(1) else "val")
    # comma-separated integer declarations:  localparam integer A = 0, B = 1;
    for m in re.finditer(r"localparam\s+integer\s+([^;]+);", text):
        for part in m.group(1).split(","):
            mm = re.match(r"\s*((?:SFG1|SFX)_\w+)\s*=\s*(\d+)\s*$", part)
            if mm: d[mm.group(1)] = (int(mm.group(2)), "int")
    return d

def parse_model(text):
    d = {}
    for m in re.finditer(r"#define\s+SFG1M_(\w+)\s+(0x[0-9a-fA-F]+u?|\d+u?)\b", text): d["SFG1_" + m.group(1)] = (num(m.group(2)), "val")
    return d

def parse_hostq(text):
    d = {}
    names = {"R_": "SFG1_REG_", "X_PERF_": "SFX_REG_PERF_"}
    for m in re.finditer(r"\b(R_[A-Z0-9_]+|X_PERF_[A-Z0-9_]+)\s*=\s*(0x[0-9a-fA-F]+)", text):
        n = m.group(1)
        key = ("SFX_REG_PERF_" + n[len("X_PERF_"):]) if n.startswith("X_PERF_") else ("SFG1_REG_" + n[2:])
        d[key] = (num(m.group(2)), "val")
    for n, v in re.findall(r"\b(CTRL_ENABLE|CTRL_ENGINE_RESET|CTRL_CLEAR_HALT)\s*=\s*(\d+)", text): d["SFG1_" + n] = (int(v), "mask")
    return d

def parse_py(text):
    d = {}
    for blk, pre in (("R", "SFG1_REG_"), ("PERF", "SFX_REG_PERF_")):
        m = re.search(r"^" + blk + r"\s*=\s*dict\((.*?)\)\s*$", text, re.S | re.M)
        if m:
            for k, v in re.findall(r"(\w+)=(0x[0-9a-fA-F]+)", m.group(1)): d[pre + k] = (int(v, 16), "val")
    return d

ALIAS = {"SFG1_REG_HWVER": "SFG1_REG_HW_VERSION", "SFG1_REG_LIM0": "SFG1_REG_LIMITS0", "SFG1_REG_LIM1": "SFG1_REG_LIMITS1",
         "SFG1_REG_DEVMEM_LO": "SFG1_REG_DEVMEM_LO", "SFG1_REG_DONE": "SFG1_REG_DONE_COUNT", "SFG1_REG_ERR": "SFG1_REG_ERR_COUNT",
         "SFG1_REG_HEARTBEAT": "SFG1_REG_HEARTBEAT", "SFX_REG_PERF_H2D": "SFX_REG_PERF_OP_H2D", "SFX_REG_PERF_D2H": "SFX_REG_PERF_OP_D2H",
         "SFX_REG_PERF_VEC": "SFX_REG_PERF_OP_VEC", "SFX_REG_PERF_TEN": "SFX_REG_PERF_OP_TEN", "SFX_REG_PERF_SCRUB": "SFX_REG_PERF_OP_SCRUB",
         "SFX_REG_PERF_RDB": "SFX_REG_PERF_RD_BEATS", "SFX_REG_PERF_WRB": "SFX_REG_PERF_WR_BEATS", "SFX_REG_PERF_RDS": "SFX_REG_PERF_RD_STALL",
         "SFX_REG_PERF_WRS": "SFX_REG_PERF_WR_STALL", "SFX_REG_PERF_VER": "SFX_REG_PERF_VERSION", "SFX_REG_PERF_CYC": "SFX_REG_PERF_CYCLES"}

def comparable(a, ka, b, kb):
    """Compare two values taking the bit-position / mask / value conventions into account."""
    if ka == "bit" or kb == "bit":
        pos, other, ko = (a, b, kb) if ka == "bit" else (b, a, ka)
        return other == pos if ko == "int" else other == (1 << pos)
    if "mask" in (ka, kb):
        m, o = (a, b) if ka == "mask" else (b, a)
        return m == o if True else False
    return a == b

def load(root):
    rd = lambda p: open(os.path.join(root, p)).read()
    return {
        "C header": parse_c(rd("vendor/sfg1-driver/kernel/sfg1_hw.h")),
        "driver SV pkg": parse_sv(rd("vendor/sfg1-driver/rtl/sfg1_pkg.sv")),
        "RTL defs": parse_sv(rd("rtl/sfg1_defs.svh")),
        "golden model": parse_model(rd("model/sfg1_model.h")),
        "C++ host": {ALIAS.get(k, k): v for k, v in parse_hostq(rd("tb/cosim/hostq.h")).items()},
        "Python tool": {ALIAS.get(k, k): v for k, v in parse_py(rd("tools/sfg1_bringup.py")).items()},
    }

def check(root, verbose=True):
    srcs = load(root); names = {}
    for s, d in srcs.items():
        for n, (v, k) in d.items(): names.setdefault(n, {})[s] = (v, k)
    shared = {n: m for n, m in names.items() if len(m) > 1}
    bad = []
    for n, m in sorted(shared.items()):
        items = list(m.items())
        for i in range(1, len(items)):
            (s0, (v0, k0)), (s1, (v1, k1)) = items[0], items[i]
            if not comparable(v0, k0, v1, k1): bad.append((n, s0, v0, s1, v1))
    if verbose:
        print(f"{len(shared)} constants appear in more than one place; sources: " + ", ".join(f"{s}={len(d)}" for s, d in srcs.items()))
        pk = {n for n, m in names.items() if "C header" in m and "driver SV pkg" in m}
        print(f"  C header vs driver SV package: {len(pk)} shared (driver package reports 58)")
        for n, s0, v0, s1, v1 in bad: print(f"  MISMATCH {n}: {s0}={v0:#x}  {s1}={v1:#x}")
    need = ["SFG1_CHIP_ID", "SFG1_REG_SQ_TAIL", "SFG1_REG_CQ_HEAD", "SFG1_OP_SCRUB", "SFG1_ST_BAD_ARGS", "SFG1_IRQ_FATAL", "SFG1_RESET_MAGIC", "SFG1_VEC_DOT8"]
    missing = [n for n in need if n not in shared or len(shared[n]) < 3]
    if missing and verbose: print("  expected constants missing from >= 3 sources:", missing)
    return len(shared), bad, missing

def selftest():
    """Negative control: change one value in each source copy, the checker must notice."""
    edits = [("vendor/sfg1-driver/kernel/sfg1_hw.h", "#define SFG1_OP_VEC			2", "#define SFG1_OP_VEC			12"),
             ("vendor/sfg1-driver/rtl/sfg1_pkg.sv", "SFG1_REG_SQ_TAIL    = 12'h04c", "SFG1_REG_SQ_TAIL    = 12'h050"),
             ("rtl/sfg1_defs.svh", "SFG1_ST_BOUNDS          = 3'd4", "SFG1_ST_BOUNDS          = 3'd5"),
             ("model/sfg1_model.h", "#define SFG1M_VEC_DOT8         7", "#define SFG1M_VEC_DOT8         6"),
             ("tb/cosim/hostq.h", "R_CQ_HEAD = 0x05c", "R_CQ_HEAD = 0x058"),
             ("tools/sfg1_bringup.py", "CQ_HEAD=0x05c", "CQ_HEAD=0x058")]
    ok = True
    for rel, a, b in edits:
        tmp = tempfile.mkdtemp()
        try:
            for p in ["vendor/sfg1-driver/kernel/sfg1_hw.h", "vendor/sfg1-driver/rtl/sfg1_pkg.sv", "rtl/sfg1_defs.svh", "model/sfg1_model.h", "tb/cosim/hostq.h", "tools/sfg1_bringup.py"]:
                os.makedirs(os.path.dirname(os.path.join(tmp, p)), exist_ok=True); shutil.copy(os.path.join(ROOT, p), os.path.join(tmp, p))
            t = open(os.path.join(tmp, rel)).read()
            if a not in t: print(f"  selftest: pattern not found in {rel}: {a!r}"); ok = False; continue
            open(os.path.join(tmp, rel), "w").write(t.replace(a, b, 1))
            _, bad, _ = check(tmp, verbose=False)
            print(f"  negative control {os.path.basename(rel):18s}: " + ("mismatch detected" if bad else "NOT DETECTED"))
            ok &= bool(bad)
        finally: shutil.rmtree(tmp, ignore_errors=True)
    return ok

if __name__ == "__main__":
    n, bad, missing = check(ROOT)
    st = True
    if "--selftest" in sys.argv: st = selftest()
    print("CONTRACT CHECK:", "OK" if not bad and not missing and st and n >= 60 else "FAILED")
    sys.exit(0 if not bad and not missing and st and n >= 60 else 1)
