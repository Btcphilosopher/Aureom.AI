#!/usr/bin/env python3
"""Run the cycle-profile workloads (tb/cosim/tests_perf.cpp) for every variant under two host-memory models and
write reports/results/perf_sim.json. SIMULATED CYCLES ONLY: they come from the RTL under Verilator against a
modelled host port (rd latency / beat gap) -- not from hardware, and with no clock frequency attached."""
import json, os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
VARIANTS = sys.argv[1].split(",") if len(sys.argv) > 1 else ["v0", "v1", "v2", "v3", "v4", "v5"]
MODELS = {"rd_lat4": {"SFG1_RD_LAT": "4"}, "rd_lat100": {"SFG1_RD_LAT": "100"}}
out = {"note": "simulated cycles (Verilator) against a modelled host port; no frequency", "win_kib": 16, "ctx": 4, "results": {}}
for v in VARIANTS:
    subprocess.run(["make", "-s", "sim", f"VARIANT={v}", "WIN=16"], check=True, capture_output=True)
    sim = f"build/sim_{v}_w16_c4_m0_o0/sim"
    for mname, env in MODELS.items():
        r = subprocess.run([sim, "perf"], capture_output=True, text=True, env=dict(os.environ, **env))
        if "failed=0" not in r.stdout: sys.exit(f"perf run failed for {v}/{mname}:\n{r.stdout[-800:]}{r.stderr[-400:]}")
        wl = {}
        for line in r.stdout.splitlines():
            if line.startswith("PERF "):
                parts = line.split(); wl[parts[1]] = {k: float(x) for k, x in (p.split("=") for p in parts[2:])}
        out["results"].setdefault(v, {})[mname] = wl
        print(f"{v} {mname}: {len(wl)} workloads", flush=True)
os.makedirs("reports/results", exist_ok=True); json.dump(out, open("reports/results/perf_sim.json", "w"), indent=1)
