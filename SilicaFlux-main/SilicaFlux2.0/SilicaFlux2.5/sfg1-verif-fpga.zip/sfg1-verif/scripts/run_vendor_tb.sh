#!/bin/bash
# Regression of the driver package's front-end testbench (ordering rules R1/R3/R4/R6, resets, halt,
# CQ overflow ...) against the DERIVED front-end rtl/sfg1_frontend.sv, for both SQ-fetch styles, plus
# the two ordering mutants which must be CAUGHT. Also re-runs the ORIGINAL testbench against the
# ORIGINAL front-end as the provenance baseline (expects the driver package's own 566 checks).
set -uo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd); cd "$ROOT"
OUT=${OUT:-$ROOT/build/vendor_tb}; mkdir -p "$OUT"; python3 scripts/make_vendor_tb.py >/dev/null || exit 2
rc=0
run() { # name expect top-module extra-args... files...
  local name=$1 expect=$2; shift 2
  verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module tb_sfg1_host_frontend --Mdir "$OUT/$name" -o sim "$@" > "$OUT/$name.build.log" 2>&1 \
    || { echo "BUILD FAIL $name"; tail -15 "$OUT/$name.build.log"; rc=1; return; }
  "$OUT/$name/sim" > "$OUT/$name.log" 2>&1
  local res; res=$(grep TB_RESULT "$OUT/$name.log" | tail -1)
  printf "%-34s expect %-4s -> %s\n" "$name" "$expect" "${res:-no result}"
  if [ "$expect" = PASS ]; then echo "$res" | grep -q "TB_RESULT PASS" || { grep "FAIL @" "$OUT/$name.log" | head -5; rc=1; }
  else echo "$res" | grep -q "TB_RESULT FAIL" || rc=1; fi
}
V=vendor/sfg1-driver/rtl
run original_tb_original_fe PASS -GORDER_BUG=0 $V/sfg1_pkg.sv $V/sfg1_host_frontend.sv $V/tb_sfg1_host_frontend.sv
for fb in 0 1; do
  F="-Irtl $V/sfg1_pkg.sv rtl/sfg1_cmdchk.sv rtl/sfg1_frontend.sv build/tb_vendor_patched.sv"
  run derived_fe_fetchburst${fb}_correct PASS -GORDER_BUG=0 -GFETCH_BURST=$fb $F
  run derived_fe_fetchburst${fb}_order1  FAIL -GORDER_BUG=1 -GFETCH_BURST=$fb $F
  run derived_fe_fetchburst${fb}_order2  FAIL -GORDER_BUG=2 -GFETCH_BURST=$fb $F
done
[ $rc -eq 0 ] && echo "VENDOR TB: OK" || echo "VENDOR TB: FAILED"
exit $rc
