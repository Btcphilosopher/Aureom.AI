#!/usr/bin/env python3
"""Write reports/results/MANIFEST.txt: which RTL revision and which tool versions produced the results in this directory."""
import datetime, hashlib, os, platform, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
def sh(cmd):
    try: return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=60, env=dict(os.environ, PATH=f"{ROOT}/.venv/bin:" + os.environ["PATH"])).stdout.strip().splitlines()[0]
    except Exception: return "n/a"
files = sorted(os.path.join(d, f) for d, _, fs in os.walk("rtl") for f in fs)
per = {f: hashlib.sha256(open(f, "rb").read()).hexdigest() for f in files}
agg = hashlib.sha256("".join(f"{per[f]}  {f}\n" for f in files).encode()).hexdigest()
L = ["SF-G1 verification & FPGA project -- results manifest", f"generated (UTC): {datetime.datetime.now(datetime.timezone.utc):%Y-%m-%d %H:%M}", "",
     f"RTL revision (sha256 over rtl/**): {agg}", *(f"  {per[f][:16]}  {f}" for f in files), "",
     "tools:", f"  verilator      {sh('verilator --version')}", f"  yosys (apt)    {sh('yosys -V')}   [formal model generation, yosys-abc BMC]", f"  z3             {sh('z3 --version')}",
     f"  yowasp-yosys   {sh('yowasp-yosys -V')}   [FPGA synthesis]", f"  nextpnr-ecp5   {sh('yowasp-nextpnr-ecp5 --version 2>&1')}", f"  gcc            {sh('gcc --version')}", f"  python         {platform.python_version()}",
     "", f"machine: {platform.platform()}, {os.cpu_count()} cores", "",
     "results in this directory are from the RTL revision above unless they live in history/ (earlier revisions, kept for the optimisation log only).",
     "NO result here was measured on hardware."]
open("reports/results/MANIFEST.txt", "w").write("\n".join(L) + "\n"); print("wrote reports/results/MANIFEST.txt; RTL sha256", agg[:16])
