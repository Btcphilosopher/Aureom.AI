#!/bin/bash
# RTL lint: verilator --lint-only -Wall over the core+checker and over the FPGA top, with the documented waivers (rtl/lint.vlt).
# Passes only with ZERO warnings. Also checks that the RTL parses in Yosys (the synthesis front end), which is stricter in places.
set -uo pipefail; cd "$(dirname "$0")/.."; export PATH=$PWD/.venv/bin:$PATH
CORE="rtl/sfg1_cmdchk.sv rtl/sfg1_vecalu.sv rtl/sfg1_devmem.sv rtl/sfg1_frontend.sv rtl/sfg1_hbus.sv rtl/sfg1_perf.sv rtl/sfg1_engine.sv rtl/sfg1_core.sv"
SHELL_="rtl/fpga/sfg1_uart.sv rtl/fpga/sfg1_hostram.sv rtl/fpga/sfg1_bridge.sv rtl/fpga/sfg1_fpga_top.sv"
rc=0
chk() { local n; n=$(verilator --lint-only -Wall -Irtl rtl/lint.vlt "$@" 2>&1 | grep -c -E '^%(Warning|Error)'); echo "  lint $LBL: $n warnings/errors"; [ "$n" = 0 ] || { verilator --lint-only -Wall -Irtl rtl/lint.vlt "$@" 2>&1 | grep -E '^%(Warning|Error)' | head -5; rc=1; }; }
for cfg in "0 0 0 0" "1 1 1 1" "1 1 1 2"; do set -- $cfg
  LBL="core+checker (FETCH_BURST=$1 VEC_MODE=$2 TEN_MODE=$3 PIPE=$4)"; P=$4
  chk --top-module sfg1_sim_top -GFETCH_BURST=$1 -GVEC_MODE=$2 -GTEN_MODE=$3 -GPIPE=$P $CORE rtl/sfg1_proto_chk.sv rtl/sfg1_sim_top.sv; done
LBL="FPGA top (SIM)"; chk --top-module sfg1_fpga_top -DSIM $SHELL_ $CORE
echo "  yosys parse (synthesis front end):"
yowasp-yosys -q -p "read_verilog -sv -I rtl $CORE $SHELL_ rtl/fpga/pll_50.v; hierarchy -top sfg1_fpga_top" && echo "  yosys: parses and elaborates" || rc=1
[ $rc -eq 0 ] && echo "LINT: OK" || echo "LINT: FAILED"; exit $rc
