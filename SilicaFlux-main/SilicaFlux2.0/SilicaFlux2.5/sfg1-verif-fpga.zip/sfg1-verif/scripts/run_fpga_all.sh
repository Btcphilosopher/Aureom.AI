#!/bin/bash
# Place-and-route every variant at two targets bracketing what it can do (12 runs, 2 in parallel, ~25 min). Results: reports/results/fpga_<v>_<mhz>.json
# Targets are the PLL options in rtl/fpga/pll_*.v. nextpnr optimises towards the target, so a run reports the Fmax reached FOR that target; both are listed in the report.
set -uo pipefail; cd "$(dirname "$0")/.."; export PATH=$PWD/.venv/bin:$PATH
mkdir -p build/fpga_logs
printf '%s\n' "v0 40" "v0 50" "v1 40" "v1 50" "v2 40" "v2 50" "v3 40" "v3 50" "v4 50" "v4 60" "v5 60" "v5 75" |
  xargs -P "${JOBS:-2}" -L1 bash -c 'python3 fpga/synth/run_flow.py --variant $0 --mhz $1 --seeds 1 > build/fpga_logs/$0_$1.out 2>&1; tail -n 1 build/fpga_logs/$0_$1.out'
