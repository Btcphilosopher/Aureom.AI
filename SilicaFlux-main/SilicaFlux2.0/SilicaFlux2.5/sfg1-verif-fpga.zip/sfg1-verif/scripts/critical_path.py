#!/usr/bin/env python3
"""Summarise the nextpnr critical path of every place-and-route run (build/fpga/<variant>_<MHz>/s<seed>.report.json) into
reports/results/critpath.json: delay split (clk-to-q / logic / routing), number of carry-chain (CCU2C) hops, whether a DSP multiplier or a
block-RAM port is on the path, and the first 'named' hierarchy prefixes seen. Net names after Yosys flop merging are mostly opaque, so
this reports STRUCTURE, not a guaranteed source line."""
import collections, glob, json, os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
out = {}
for f in sorted(glob.glob("build/fpga/v*_*/s*.report.json")):
    tag = f.split("/")[2]; r = json.load(open(f)); cps = r.get("critical_paths", [])
    if not cps: continue
    segs = cps[0]["path"]; agg = collections.Counter()
    for s in segs: agg[s["type"]] += s["delay"]
    names = " ".join(str(s.get("net", "")) + " " + s.get("from", {}).get("cell", "") + " " + s.get("to", {}).get("cell", "") for s in segs)
    out[tag + "/" + os.path.basename(f).split(".")[0]] = dict(
        total_ns=round(sum(agg.values()), 2), clk_to_q_ns=round(agg["clk-to-q"], 2), logic_ns=round(agg["logic"], 2), routing_ns=round(agg["routing"], 2),
        carry_cells_on_path=len(set(re.findall(r"CCU2C\w*\$CCU2_COMB[01]", names))), has_dsp_multiplier="MULT18X18D" in names, has_bram_port=bool(re.search(r"DIA|DIB|DOA|DOB", names)),
        hierarchy_prefixes=sorted(set(re.findall(r"\b(u_core\.u_\w+|u_ram|u_bridge|u_uart)", names)))[:8])
os.makedirs("reports/results", exist_ok=True); json.dump(out, open("reports/results/critpath.json", "w"), indent=1)
for k, v in out.items(): print(f"{k:12s} {v['total_ns']:5.1f} ns = clk-to-q {v['clk_to_q_ns']} + logic {v['logic_ns']} + routing {v['routing_ns']}  carry cells {v['carry_cells_on_path']:3d}  mult {v['has_dsp_multiplier']}  hier {v['hierarchy_prefixes']}")
