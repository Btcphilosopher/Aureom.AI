#!/usr/bin/env python3
"""Decode a counterexample of an abc-engine formal job (build/formal/<job>): print the per-cycle CSR/bus stimulus and the
values of the key state signals, and which assertion failed. Usage: formal_cex.py <job-name> [frames]"""
import json, os, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
name = sys.argv[1]; frames = sys.argv[2] if len(sys.argv) > 2 else "40"
w = os.path.join("build/formal", name, name); tmp = tempfile.mkdtemp(); aiw = os.path.join(tmp, "t.aiw"); yw = os.path.join(tmp, "t.yw"); vcd = os.path.join(tmp, "t.vcd")
subprocess.run(["yosys-abc", "-c", f"read_aiger {w}/model/design_aiger.aig; fold; strash; bmc3 -F {frames}; write_cex -a {aiw}"], capture_output=True)
subprocess.run(["yosys-witness", "aiw2yw", aiw, f"{w}/model/design_aiger.ywa", yw], capture_output=True)
r = subprocess.run(["yosys", "-q", "-p", f"read_rtlil {w}/model/design_prep.il; sim -r {yw} -scope fe_formal -vcd {vcd} -w -timescale 1ns fe_formal"], capture_output=True, text=True)
if not os.path.exists(vcd): sys.exit(f"no counterexample found within {frames} frames (or the job has no AIGER model): nothing to decode")
print("\n".join(l for l in (r.stdout + r.stderr).splitlines() if "Assert" in l and "failed" in l))
want = ["csr_wr", "csr_addr", "csr_wdata", "mrd_req", "mrd_valid", "mrd_err", "mwr_req", "mwr_ready", "eng_done", "eng_abort", "st", "enable", "halted", "fatal", "rst_act", "irq_status", "irq_msg", "sq_head", "sq_tail", "cq_head", "cq_tail", "fm"]
ids = {}; scope = []; rows = []; cur = {}; t = None
for line in open(vcd):
    line = line.strip()
    if line.startswith("$scope"): scope.append(line.split()[2])
    elif line.startswith("$upscope"): scope.pop()
    elif line.startswith("$var"):
        p = line.split(); ids.setdefault(p[3], []).append((".".join(scope), p[4]))
    elif line.startswith("#"):
        if t is not None: rows.append((t, dict(cur)))
        t = int(line[1:])
    elif line and line[0] in "b01xz" and not line.startswith("$"):
        if line[0] == "b": v, i = line[1:].split()
        else: v, i = line[0], line[1:]
        cur[i] = v
rows.append((t, dict(cur)))
sel = {n: i for i, ns in ids.items() for sc, n in ns if sc == "fe_formal" and n in want}
prev = {}
for t, c in rows:
    cyc = t // 5
    if t % 10: continue
    out = []
    for n in want:
        if n in sel and sel[n] in c:
            v = c[sel[n]]
            try: v = hex(int(v, 2))
            except Exception: pass
            if prev.get(n) != v or n in ("csr_wr",): out.append(f"{n}={v}")
            prev[n] = v
    print(f"t={t:4d}", " ".join(out))
