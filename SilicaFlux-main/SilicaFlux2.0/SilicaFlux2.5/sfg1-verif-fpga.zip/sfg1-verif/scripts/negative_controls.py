#!/usr/bin/env python3
"""Negative controls for the C-level differential: inject one small bug into a private copy of the golden model and
require the model-vs-mock fuzz to report mismatches. A fuzz that cannot fail proves nothing."""
import os, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MUT = [("window bound off by one word", "return n <= win && off <= win - n;", "return n <= win && off <= win - n + 4;"),
       ("DMA alignment test drops dev_a", "if (!len || ((len | a) & 3))", "if (!len || (len & 3))"),
       ("DOT8 accumulator off by one", "acc = (int32_t)((uint32_t)acc + (uint32_t)sfg1m_dot8(", "acc = (int32_t)(1u + (uint32_t)acc + (uint32_t)sfg1m_dot8("),
       ("SUB8 operands swapped", "case SFG1M_VEC_SUB8:  v = x - y; break;", "case SFG1M_VEC_SUB8:  v = y - x; break;"),
       ("RELU8 b!=0 rule removed", "if (e->exec_op == SFG1M_VEC_RELU8 && b) return SFG1M_ST_BAD_ARGS;", ""),
       ("TEN accumulate flag ignored", "uint32_t acc = (e->flags & SFG1M_CMDF_TEN_ACC) ? ld32(C + 4 * (4 * r + q)) : 0;", "uint32_t acc = 0;")]
ok = True
src = open(os.path.join(ROOT, "model/sfg1_model.c")).read()
for name, a, b in MUT:
    if a not in src: print(f"  pattern not found for: {name}"); ok = False; continue
    d = tempfile.mkdtemp(); open(os.path.join(d, "m.c"), "w").write(src.replace(a, b, 1))
    cc = subprocess.run(["gcc", "-std=gnu2x", "-O2", "-w", "-I", os.path.join(ROOT, "driver/shim/include"), "-I", os.path.join(ROOT, "vendor/sfg1-driver/kernel"),
                         "-I", os.path.join(ROOT, "model"), "-I", os.path.join(ROOT, "build"), os.path.join(ROOT, "tb/unit/fuzz_model_vs_mock.c"), os.path.join(d, "m.c"), "-o", os.path.join(d, "f")], capture_output=True, text=True)
    if cc.returncode: print("  build failed:", cc.stderr[-300:]); ok = False; continue
    r = subprocess.run([os.path.join(d, "f"), "400000"], capture_output=True, text=True)
    line = [l for l in r.stdout.splitlines() if l.startswith("fuzz_model_vs_mock")][0]
    detected = r.returncode != 0
    print(f"  {name:36s}: {'detected' if detected else 'NOT DETECTED'}  ({line.split(': ')[1]})"); ok &= detected
print("NEGATIVE CONTROLS:", "OK" if ok else "FAILED"); sys.exit(0 if ok else 1)
