#!/usr/bin/env python3
"""Mutation testing of the RTL against the co-simulation suite.

Each mutant is a deliberate, plausible bug gated by the MUT / ORDER_BUG parameters (0 in every
real build). For each one the simulator is rebuilt with the bug enabled and the WHOLE suite is
run; the mutant is KILLED if at least one test fails (or the protocol checker fires). A SURVIVING
mutant is a hole in the verification and makes this script exit non-zero.
Usage: mutation_test.py [--variant v0] [--only 13,14] [--out reports/results/mutation_v0.json]
"""
import argparse, json, os, re, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

MUTANTS = [  # (id, make args, description)
    ("ORDER_BUG=1", {"OBUG": 1}, "CQE phase dword written FIRST (R3)"),
    ("ORDER_BUG=2", {"OBUG": 2}, "interrupt cause published before the CQE is complete (R3/R6)"),
    ("MUT=1",  {"MUT": 1},  "CQ phase tag not toggled on wrap"),
    ("MUT=2",  {"MUT": 2},  "CLEAR_HALT has no effect"),
    ("MUT=3",  {"MUT": 3},  "BAD_CTX test uses > instead of >="),
    ("MUT=4",  {"MUT": 4},  "queue does not halt after an error (R7)"),
    ("MUT=5",  {"MUT": 5},  "reserved SQ fields not checked"),
    ("MUT=6",  {"MUT": 6},  "reset leaves IRQ_STATUS set"),
    ("MUT=10", {"MUT": 10}, "window bounds check off by one word"),
    ("MUT=11", {"MUT": 11}, "NOP with non-zero fields accepted (the reference front-end's behaviour)"),
    ("MUT=12", {"MUT": 12}, "VEC SUB8 operands swapped"),
    ("MUT=13", {"MUT": 13}, "SCRUB clears only half the window"),
    ("MUT=14", {"MUT": 14}, "TEN accumulate flag ignored"),
    ("MUT=15", {"MUT": 15}, "VEC len*4 overflow not detected"),
    ("MUT=16", {"MUT": 16}, "DMA_H2D drops the last word"),
    ("MUT=17", {"MUT": 17}, "DMA_D2H reads from a neighbouring context's window"),
    ("MUT=18", {"MUT": 18}, "VEC DOT8 omits lane 3"),
    ("MUT=19", {"MUT": 19}, "DMA read burst may cross a 4 KiB boundary", {"v1", "v2", "v3"}),   # needs DMA_BURST > 1
    ("MUT=20", {"MUT": 20}, "stale read responses (old epoch) accepted"),
    ("MUT=21", {"MUT": 21}, "bus requests not gated while a reset is aborting"),
    ("MUT=22", {"MUT": 22}, "CQ-full (R5) not detected: completion overwrites an unconsumed CQE"),
    ("MUT=23", {"MUT": 23}, "no interrupt re-send after W1C/mask write leaves a cause pending (R6)"),
    ("MUT=25", {"MUT": 25}, "engine ignores the reset/abort pulse"),
    ("MUT=26", {"MUT": 26}, "FATAL survives a FUNCTION reset"),
    ("MUT=27", {"MUT": 27}, "SQ head not advanced past a failing command"),
    ("MUT=28", {"MUT": 28}, "ENABLE 0->1 accepted while the previous command is still draining (I10)"),
    ("MUT=29", {"MUT": 29}, "queue base alignment / address-space wrap not checked (I9)"),
    ("MUT=30", {"MUT": 30}, "queue registers used live instead of sampled at ENABLE 0->1 (R9)"),
]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", default="v0"); ap.add_argument("--only", default="")
    ap.add_argument("--out", default=None); ap.add_argument("--tests", default="")
    a = ap.parse_args()
    only = set(a.only.split(",")) if a.only else None
    res = []
    for mut in MUTANTS:
        mid, args, desc = mut[:3]
        if len(mut) > 3 and a.variant not in mut[3]:
            res.append({"id": mid, "desc": desc, "status": "NOT_APPLICABLE", "note": "code path absent in this variant"}); print(f"{mid:12s} n/a       (code path absent in {a.variant})"); continue
        if only and mid.split("=")[1] not in only and mid not in only:
            continue
        t0 = time.time()
        mk = ["make", "-s", "sim", f"VARIANT={a.variant}"] + [f"{k}={v}" for k, v in args.items()]
        b = subprocess.run(mk, cwd=ROOT, capture_output=True, text=True)
        if b.returncode:
            res.append({"id": mid, "desc": desc, "status": "BUILD_FAILED", "log": b.stdout[-500:] + b.stderr[-500:]}); print(mid, "BUILD FAILED"); continue
        simdir = f"build/sim_{a.variant}_w4_c4_m{args.get('MUT',0)}_o{args.get('OBUG',0)}/sim"
        try:
            r = subprocess.run([simdir] + ([t for t in a.tests.split(",") if t]), cwd=ROOT, capture_output=True, text=True, timeout=1800)
            out, rc = r.stdout, r.returncode
        except subprocess.TimeoutExpired as e:      # a hang IS a detection (tests have no watchdog of their own)
            out, rc = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or ""), 124
        failed = re.findall(r"^TEST (\S+)\s+FAIL", out, re.M)
        chk = re.findall(r"^TEST (\S+)\s+\S+ .*checker_mask=([0-9a-f]{4})", out, re.M)
        fired = [n for n, m in chk if m != "0000"]
        killed = rc != 0 or bool(failed)
        status = "KILLED" if killed else "SURVIVED"
        res.append({"id": mid, "desc": desc, "status": status, "failed_tests": failed, "checker_fired_in": fired,
                    "exit": rc, "seconds": round(time.time() - t0, 1)})
        print(f"{mid:12s} {status:9s} by {','.join(failed) if failed else ('timeout/exit %d' % rc if rc else '-')}"
              f"{'  [checker: ' + ','.join(fired) + ']' if fired else ''}   {desc}", flush=True)
    surv = [r for r in res if r["status"] not in ("KILLED", "NOT_APPLICABLE")]
    napp = sum(1 for r in res if r["status"] == "NOT_APPLICABLE")
    print(f"\n{len(res) - len(surv) - napp}/{len(res) - napp} applicable mutants killed ({napp} not applicable)" + (f"; SURVIVORS: {[r['id'] for r in surv]}" if surv else ""))
    if a.out:
        os.makedirs(os.path.dirname(os.path.join(ROOT, a.out)), exist_ok=True)
        json.dump({"variant": a.variant, "results": res}, open(os.path.join(ROOT, a.out), "w"), indent=1)
    return 1 if surv else 0

sys.exit(main())
