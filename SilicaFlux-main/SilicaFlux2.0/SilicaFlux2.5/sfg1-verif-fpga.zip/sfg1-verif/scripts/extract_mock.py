#!/usr/bin/env python3
"""Extract the driver mock's command-execution logic VERBATIM from vendor/sfg1-driver/kernel/sfg1_mock.c.

Pulls three functions (win_ok, lane_op, mock_exec) by name -- the text is not edited -- and writes
them into build/mock_exec_extracted.inc. The file's SHA-256 is pinned: if the vendored mock
changes, this script fails loudly instead of silently testing something else.
"""
import hashlib, re, sys, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
src = (root / "vendor/sfg1-driver/kernel/sfg1_mock.c")
PIN = None
for line in (root / "vendor/SHA256SUMS").read_text().splitlines():
    h, name = line.split()
    if name.endswith("kernel/sfg1_mock.c"):
        PIN = h
actual = hashlib.sha256(src.read_bytes()).hexdigest()
if PIN != actual:
    sys.exit(f"vendored sfg1_mock.c hash mismatch: pinned {PIN} actual {actual}")
text = src.read_text()
out = ["/* AUTO-EXTRACTED VERBATIM from sfg1_mock.c (sha256 %s). Do not edit. */\n" % actual]
for name, sig in (("win_ok", r"static bool win_ok\("), ("lane_op", r"static u32 lane_op\("),
                  ("mock_exec", r"static u16 mock_exec\(")):
    m = re.search(r"^" + sig, text, re.M)
    if not m:
        sys.exit(f"function {name} not found")
    end = text.index("\n}\n", m.start()) + 3        # closing brace at column 0
    out.append(text[m.start():end] + "\n")
dest = root / "build"
dest.mkdir(exist_ok=True)
(dest / "mock_exec_extracted.inc").write_text("".join(out))
print("extracted win_ok, lane_op, mock_exec from sfg1_mock.c sha256", actual[:16])
