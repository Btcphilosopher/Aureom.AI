#!/usr/bin/env python3
"""Derive a testbench for rtl/sfg1_frontend.sv from the driver package's vendored
tb_sfg1_host_frontend.sv. The vendored file is never edited; this script applies the minimal,
listed changes and writes build/tb_vendor_patched.sv. Every substitution is asserted to apply.

Why the changes are needed (all because the derived front-end implements more of the contract):
  C1 module/port names      sfg1_host_frontend -> sfg1_frontend; new ports mrd_len, mrd_err, mwr_ready,
                            fe_state, dbg_fe get testbench signals (mrd_err=0, mwr_ready=1)
  C2 burst-capable reads    the responder returns mrd_len beats (needed when FETCH_BURST=1)
  C3 valid operands         the reference front-end forwarded any VEC/DMA command to a stub engine;
                            the derived one validates operands (contract section 8), so the testbench
                            builds well-formed VEC / DMA_H2D commands (len, offsets, host address)
  C4 FETCH_BURST parameter  passed through from the command line
"""
import hashlib, os, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = open(f"{root}/vendor/sfg1-driver/rtl/tb_sfg1_host_frontend.sv").read()
def sub(old, new):
    global src
    assert old in src, "patch does not apply: " + old[:60]
    src = src.replace(old, new, 1)

sub("module tb_sfg1_host_frontend #(parameter int ORDER_BUG = 0);",
    "module tb_sfg1_host_frontend #(parameter int ORDER_BUG = 0, parameter int FETCH_BURST = 0);")
sub("  sfg1_host_frontend #(.MAX_CTX(8), .MAX_QENT(1024), .WIN_KIB(1024), .RESET_CYCLES(6), .ORDER_BUG(ORDER_BUG)) dut (.*);",
    "  logic [8:0]  mrd_len;\n  logic        mrd_err = 1'b0, mwr_ready = 1'b1;\n  wire  [3:0]  fe_state;\n  wire [383:0] dbg_fe;\n"
    "  sfg1_frontend #(.MAX_CTX(8), .MAX_QENT(1024), .WIN_KIB(1024), .RESET_CYCLES(6), .FETCH_BURST(FETCH_BURST), .ORDER_BUG(ORDER_BUG)) dut (.*);")
# C2: burst-capable read responder
sub("""  int rd_due = -1;
  logic [63:0] rd_a;
  always @(posedge clk) begin
    mrd_valid <= 1'b0;
    if (mrd_req) begin rd_due <= cyc + 2 + ($urandom % 3); rd_a <= mrd_addr; end
    if (rd_due >= 0 && cyc >= rd_due) begin
      mrd_valid <= 1'b1; mrd_data <= hmem[rd_a[15:2]]; rd_due <= -1;
    end
  end""", """  int rd_due = -1, rd_left = 0;
  logic [63:0] rd_a;
  always @(posedge clk) begin
    mrd_valid <= 1'b0;
    if (mrd_req) begin rd_due <= cyc + 2 + ($urandom % 3); rd_a <= mrd_addr; rd_left <= int'(mrd_len); end
    if (rd_due >= 0 && cyc >= rd_due && rd_left > 0) begin
      mrd_valid <= 1'b1; mrd_data <= hmem[rd_a[15:2]]; rd_a <= rd_a + 4; rd_left <= rd_left - 1;
      if (rd_left == 1) rd_due <= -1;
    end
  end""")
# C3: well-formed commands
sub("""    hmem[base + 3] = rsvd0;""", """    hmem[base + 3] = rsvd0;
    if (op == SFG1_OP_VEC) begin                        // VEC ADD8, 4 words: A=0 B=64 C=128 (window-relative)
      hmem[base + 6] = 32'd4; hmem[base + 10] = 32'd64; hmem[base + 12] = 32'd128;
    end
    if (op == SFG1_OP_DMA_H2D) begin                    // 64 bytes from host 0x2000 to window offset 0
      hmem[base + 4] = 32'h2000; hmem[base + 6] = 32'd64;
    end""")
open(f"{root}/build/tb_vendor_patched.sv", "w").write(src)
print("wrote build/tb_vendor_patched.sv (derived from sha256 %s)" % hashlib.sha256(open(f"{root}/vendor/sfg1-driver/rtl/tb_sfg1_host_frontend.sv","rb").read()).hexdigest()[:16])
