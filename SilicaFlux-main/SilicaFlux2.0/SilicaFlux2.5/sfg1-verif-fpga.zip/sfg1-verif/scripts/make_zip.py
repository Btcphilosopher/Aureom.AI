#!/usr/bin/env python3
"""Package the project as a ZIP: sources, scripts, docs, reports and raw results, plus (under artifacts/) the bitstreams and tool logs that
the reports refer to. Excludes the virtualenv, build trees and caches. The archive unpacks into <name>/ and is self-contained:
`make setup && make verify` reproduces the quick path.  Usage: make_zip.py <output.zip> [name]"""
import hashlib, json, os, sys, zipfile, glob
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
out = os.path.abspath(sys.argv[1]); name = sys.argv[2] if len(sys.argv) > 2 else "sfg1-verif"
SKIP_DIRS = {".venv", "build", "__pycache__", ".git", "_c4_m0_o0"}
files = []
for d, ds, fs in os.walk("."):
    ds[:] = sorted(x for x in ds if x not in SKIP_DIRS)
    for f in sorted(fs):
        if f.endswith((".pyc", ".swp")) or f in ("Makefile.new",) or "__stale" in f: continue
        files.append((os.path.join(d, f)[2:], os.path.join(d, f)[2:]))
# artifacts the reports refer to
art = []
for j in sorted(glob.glob("reports/results/fpga_v*_*.json")):
    d = json.load(open(j)); tag = os.path.basename(j)[5:-5]
    for p in d.get("pnr", []):
        b = p.get("bitstream", {}).get("path")
        if b and os.path.exists(b):
            base = b[:-4]
            for ext in (".bit", ".log", ".pack.log"):
                if os.path.exists(base + ext): art.append((base + ext, f"artifacts/fpga/{tag}/{os.path.basename(base + ext)}"))
            sy = os.path.join(os.path.dirname(b), "synth.stat")
            if os.path.exists(sy): art.append((sy, f"artifacts/fpga/{tag}/synth.stat"))
for f in sorted(glob.glob("build/formal/*/log.txt")): art.append((f, f"artifacts/formal/{f.split('/')[2]}.log"))
for f in sorted(glob.glob("build/final_*.out")): art.append((f, f"artifacts/logs/{os.path.basename(f)}"))
if os.path.exists("build/rtl_manifest.sha256"): art.append(("build/rtl_manifest.sha256", "artifacts/rtl_manifest.sha256"))
seen = set(); n = 0; size = 0
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for src, dst in files + art:
        if dst in seen or os.path.abspath(src) == out: continue
        seen.add(dst); st = os.stat(src)
        zi = zipfile.ZipInfo(f"{name}/{dst}", date_time=(2026, 11, 22, 12, 0, 0)); zi.external_attr = (st.st_mode & 0xFFFF) << 16; zi.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(zi, open(src, "rb").read(), compresslevel=9); n += 1; size += st.st_size
print(f"{out}: {n} files, {size/1e6:.1f} MB uncompressed, {os.path.getsize(out)/1e6:.1f} MB zipped; sha256 {hashlib.sha256(open(out, 'rb').read()).hexdigest()}")
