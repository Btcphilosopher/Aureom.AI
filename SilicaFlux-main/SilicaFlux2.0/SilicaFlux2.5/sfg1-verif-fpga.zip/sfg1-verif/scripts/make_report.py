#!/usr/bin/env python3
"""Regenerate reports/perf-report.md (and the numeric part of reports/verification-report.md) from reports/results/*.json
and reports/results/suite_*.txt. Nothing here measures anything: it only formats results that other scripts produced, and it
keeps the three kinds of number apart:

    SIMULATED CYCLES        RTL under Verilator against a MODELLED host port (no clock frequency attached)
    SYNTHESIS / PNR         what Yosys / nextpnr-ecp5 report for the LFE5U-85F-6 (resource counts, static-timing Fmax)
    MEASURED HARDWARE       none exists. The section is generated empty on purpose.

Projections (cycles / tool Fmax) are labelled PROJECTION and are never merged into either column above.
"""
import glob, json, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
RES = "reports/results"
VARS = ["v0", "v1", "v2", "v3", "v4", "v5"]
DESC = {"v0": "sequential VEC/TEN, single-beat SQ fetch, single-beat DMA", "v1": "+ burst SQ fetch, 64-beat DMA bursts",
        "v2": "+ 2-read-port pipelined VEC", "v3": "+ 4-multiplier TEN (1 output/cycle)", "v4": "+ registered BRAM outputs, multiply/accumulate split (PIPE=1)",
        "v5": "+ registered lane products before the adder tree (PIPE=2)"}

def load(p, default=None):
    try: return json.load(open(p))
    except Exception: return default

def norm(d):
    """older result files (history/) stored one entry per timing line with key 'mhz'; convert to the current shape (final = last line, pre-route = first)."""
    for p in d.get("pnr", []):
        fm = p.get("fmax") or []
        if fm and "mhz_final" not in fm[0]:
            p["fmax"] = [dict(clock=fm[-1]["clock"], mhz_final=fm[-1]["mhz"], met=fm[-1]["met"], constraint_mhz=fm[-1]["constraint_mhz"], mhz_pre_route_estimate=fm[0]["mhz"])]
    return d

def fpga_runs():
    runs = {}
    for f in sorted(glob.glob(f"{RES}/fpga_v*_*.json")):
        d = norm(load(f) or {})
        if not d or "pnr" not in d or d.get("tag"): continue          # tagged runs are A/B experiments (scripts/ab_o6.sh), reported separately
        runs.setdefault(d["variant"], []).append(d)
    return runs

def ab_runs():
    out = {}
    for f in sorted(glob.glob(f"{RES}/fpga_v*_*.json")):
        d = norm(load(f) or {})
        if d and d.get("tag") == "_noO6" and d.get("pnr"): out[(d["variant"], d["core_mhz_target"])] = d
    return out

def best_fmax(runs):
    """(achieved_mhz, met_target_mhz, run): highest TARGET at which timing was met (else the best reported final Fmax)."""
    met = [(d["core_mhz_target"], p["fmax"][0]["mhz_final"], d, p) for d in runs for p in d["pnr"] if p.get("fmax") and p["fmax"][0]["met"]]
    allr = [(d["core_mhz_target"], p["fmax"][0]["mhz_final"], d, p) for d in runs for p in d["pnr"] if p.get("fmax")]
    if met:
        t, f, d, p = max(met, key=lambda x: (x[0], x[1])); return f, t, d, p, True
    if allr:
        t, f, d, p = max(allr, key=lambda x: x[1]); return f, t, d, p, False
    return None, None, None, None, False

def fmt(x, n=1): return "–" if x is None else f"{x:,.{n}f}"

def perf_tables(out, perf, fm):
    res = perf["results"]; vs = [v for v in VARS if v in res]
    for model, label in (("rd_lat4", "host read latency 4 cycles (fast bus)"), ("rd_lat100", "host read latency 100 cycles (slow / far host memory)")):
        out.append(f"\n#### 2.2{'a' if model == 'rd_lat4' else 'b'} Total cycles, doorbell to last completion — {label}\n")
        wls = list(res[vs[0]][model].keys())
        out.append("| workload | " + " | ".join(vs) + " |"); out.append("|---|" + "---:|" * len(vs))
        for w in wls: out.append(f"| `{w}` | " + " | ".join(f"{res[v][model][w]['total']:,.0f}" for v in vs) + " |")
    out.append("\n#### 2.3 Issue rate — commands per cycle, and ops per cycle (rd_lat4)\n")
    out.append("`commands/cycle` = SQ commands completed ÷ total cycles. `ops/cycle` = useful lane/MAC operations ÷ total cycles "
               "(ops, as defined in `tb/cosim/tests_perf.cpp`: VEC ADD/MUL = 4 per word, DOT8 = 8 per word (4 multiplies + 4 adds), TEN = 128 per 16-output tile (16 outputs × 4 multiplies + 4 adds)). "
               "`engine ops/cycle` divides by the engine's own busy cycles for that operation (VEC/TEN performance counters) instead.\n")
    cols = ["nop_stream48", "nop_single", "vec_add8", "vec_dot8", "ten_noacc", "ten_acc", "kernel_vecadd_job", "kernel_matmul16_job"]
    out.append("| variant | " + " | ".join(f"{c}: cmd/cyc" for c in cols[:2]) + " | " + " | ".join(f"{c}: ops/cyc" for c in cols[2:6]) + " | engine ops/cyc vec_add8 | engine ops/cyc ten_acc |")
    out.append("|---|" + "---:|" * (2 + 4 + 2))
    for v in vs:
        r = res[v]["rd_lat4"]
        cells = [f"{r[c]['cmds'] / r[c]['total']:.4f}" for c in cols[:2]] + [f"{r[c]['ops'] / r[c]['total']:.3f}" for c in cols[2:6]]
        cells += [f"{r['vec_add8']['ops'] / max(r['vec_add8']['vec'], 1):.2f}", f"{r['ten_acc']['ops'] / max(r['ten_acc']['ten'], 1):.2f}"]
        out.append(f"| {v} | " + " | ".join(cells) + " |")
    out.append("\n#### 2.4 Effective memory bandwidth — bytes per cycle (rd_lat4 | rd_lat100)\n")
    out.append("H2D/D2H: payload bytes ÷ total cycles of a single 4 KiB transfer command (includes the command fetch, decode and completion write). "
               "`vec_add8`/`ten_acc`: device-memory bytes read+written by the engine ÷ total cycles. `host port` = (read beats + write beats) × 4 B ÷ total cycles of the `kernel_vecadd_job`.\n")
    out.append("| variant | h2d_4k | d2h_4k | vec_add8 (dev mem) | ten_acc (dev mem) | host port, kernel_vecadd_job |"); out.append("|---|---:|---:|---:|---:|---:|")
    for v in vs:
        def bw(m, w): r = res[v][m][w]; return r["bytes"] / r["total"]
        def hp(m): r = res[v][m]["kernel_vecadd_job"]; return (r["rd_beats"] + r["wr_beats"]) * 4 / r["total"]
        out.append(f"| {v} | " + " | ".join(f"{bw('rd_lat4', w):.3f} \\| {bw('rd_lat100', w):.3f}" for w in ["h2d_4k", "d2h_4k", "vec_add8", "ten_acc"]) + f" | {hp('rd_lat4'):.3f} \\| {hp('rd_lat100'):.3f} |")
    out.append("\n#### 2.5 Host-transfer overhead inside a job (counters, rd_lat4 | rd_lat100)\n")
    out.append("`transfer share` = (H2D + D2H engine-busy cycles) ÷ total cycles of the job; `fixed` = cycles the job spends outside any operation "
               "(`total − h2d − d2h − vec − ten`: SQ fetch, decode, completion write, interrupt latency).\n")
    out.append("| variant | job | total | H2D | kernel (vec+ten) | D2H | fixed | transfer share |"); out.append("|---|---|---:|---:|---:|---:|---:|---:|")
    for v in vs:
        for j in ("kernel_vecadd_job", "kernel_matmul16_job"):
            cells = []
            for m in ("rd_lat4", "rd_lat100"):
                r = res[v][m][j]; k = r["vec"] + r["ten"]; fixed = r["total"] - r["h2d"] - r["d2h"] - k
                cells.append((r["total"], r["h2d"], k, r["d2h"], fixed, (r["h2d"] + r["d2h"]) / r["total"]))
            out.append(f"| {v} | `{j}` | " + " | ".join((f"{a:,.0f} \\| {b:,.0f}" if i < 5 else f"{a*100:.1f}% \\| {b*100:.1f}%") for i, (a, b) in enumerate(zip(*cells))) + " |")

def main():
    perf = load(f"{RES}/perf_sim.json"); runs = fpga_runs(); out = []
    bf = {v: best_fmax(runs.get(v, [])) for v in VARS}
    out += ["# SF-G1 performance report", "",
            "Generated by `scripts/make_report.py` from `reports/results/*.json`. **Nothing in this report is a hardware measurement.** "
            "No SF-G1 silicon exists, no FPGA board was available to this project, and PCIe is not modelled. "
            "Section 5 (measured hardware) is empty on purpose.", "",
            "| kind | where it comes from | what it is | in this report |", "|---|---|---|---|",
            "| **Simulated cycles** | RTL under Verilator, `tb/cosim` against a *modelled* host-memory port (read latency, beat gap, back-pressure) | exact cycle counts of this RTL for a *model* of the bus; no clock frequency | §2 |",
            "| **Synthesis / implementation estimates** | Yosys `synth_ecp5` + nextpnr-ecp5 (LFE5U-85F-6BG381C), `fpga/synth/run_flow.py` | resource counts; post-route *static timing* Fmax of the constrained clock | §3 |",
            "| **Projection** | simulated cycles ÷ tool-reported Fmax | what the first two *would* imply on this FPGA if the bus model were true and timing were as reported; **not a measurement** | §4 |",
            "| **Measured hardware** | a real board running the bitstream (`tools/sfg1_bringup.py --port ...`) | — | §5: **none** |", ""]
    # ---- 1. summary
    out += ["## 1. Summary (per design variant)", "",
            "Variants are cumulative optimisation steps chosen from profiles (see `reports/optimisation-log.md`). All pass the same 26-test suite and the same formal/protocol checks.", "",
            "| variant | what changed | Fmax, post-route (nextpnr) | highest target met | LUT4+carry | FF | EBR (of 208) | 18×18 mult | kernel_vecadd_job cycles (rd_lat4) | kernel_matmul16_job cycles (rd_lat4) |",
            "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for v in VARS:
        f, t, d, p, met = bf[v]
        u = p["utilisation"] if p else {}
        g = lambda k: (f"{u[k][0]:,}" if k in u else "–")
        pv = (perf or {}).get("results", {}).get(v, {}).get("rd_lat4", {})
        vj = f"{pv['kernel_vecadd_job']['total']:,.0f}" if pv else "–"; mj = f"{pv['kernel_matmul16_job']['total']:,.0f}" if pv else "–"
        out.append(f"| {v} | {DESC[v]} | {fmt(f)} MHz{'' if met else ' (target missed)'} | {('%d MHz' % t) if met else '—'} | {g('TRELLIS_COMB')} | {g('TRELLIS_FF')} | {g('DP16KD')} | {g('MULT18X18D')} | {vj} | {mj} |")
    out += ["", "*Fmax is the post-route figure nextpnr prints for the single core clock at the highest target for which it reported timing as met "
            "(or, where no target was met, the best final figure seen). It depends on the placer seed and on the target; every run is listed in §3.1.*", ""]
    # ---- 2. simulated cycles
    out += ["## 2. Simulated cycles (RTL under Verilator, modelled host port)", "",
            "**Method.** `tb/cosim/tests_perf.cpp` submits fixed workloads through the real queue protocol and reads the *device's own* performance counters "
            "(BAR0 0x100+: BUSY, FETCH, DECODE, EXEC, WB, per-operation busy cycles, read/write beats and stalls) and the simulation cycle counter. "
            "The host port is a model: fixed read latency (4 or 100 cycles), one beat per cycle, no jitter. Window 16 KiB, 4 contexts. "
            "These counts are exact for this RTL **against that model**; a real PCIe path would add latency, jitter, TLP overhead, credits and a clock-domain crossing, none of which are modelled.", ""]
    if perf: perf_tables(out, perf, bf)
    else: out.append("_perf_sim.json missing: run `make perf`._")
    # ---- 3. synthesis / implementation
    out += ["", "## 3. Synthesis and implementation estimates (tool-reported; not measured)", "",
            "Target: Lattice LFE5U-85F-6BG381C (ULX3S-85F), 25 MHz crystal → PLL. Flow: `yowasp-yosys synth_ecp5` → `yowasp-nextpnr-ecp5 --85k --package CABGA381 --speed 6` → `ecppack`. "
            "The top is the bring-up shell (`rtl/fpga/sfg1_fpga_top.sv`): core + UART bridge + on-chip dual-port 'host RAM' stand-in + LEDs, so BRAM counts include the stand-in.", "",
            "### 3.1 Clock frequency — every place-and-route run", "",
            "| variant | target MHz | seed | final Fmax MHz (post-route) | pre-route estimate MHz | timing met | bitstream sha256 (first 12) |", "|---|---:|---:|---:|---:|---|---|"]
    for v in VARS:
        for d in sorted(runs.get(v, []), key=lambda d: d["core_mhz_target"]):
            for p in d["pnr"]:
                if not p.get("fmax"): continue
                x = p["fmax"][0]; bs = p.get("bitstream", {}).get("sha256", "")[:12]
                out.append(f"| {v} | {d['core_mhz_target']} | {p['seed']} | {x['mhz_final']:.2f} | {x['mhz_pre_route_estimate']:.2f} | {'**yes**' if x['met'] else 'no'} | `{bs}` |")
    out += ["", "### 3.2 Resource utilisation (best run per variant)", "",
            "| variant | Yosys: LUT4 | Yosys: FF | Yosys: carry (CCU2C) | Yosys: DP16KD | Yosys: MULT18X18D | nextpnr: TRELLIS_COMB | nextpnr: TRELLIS_FF | nextpnr: EBR | nextpnr: MULT | % of 84K LUT | % of 208 EBR |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for v in VARS:
        f, t, d, p, met = bf[v]
        if not d: continue
        c = d["synthesis"]["counts"]; u = p["utilisation"]
        out.append(f"| {v} | {c['LUT4']:,} | {c['TRELLIS_FF']:,} | {c['CCU2C']:,} | {c['DP16KD']} | {c['MULT18X18D']} | {u['TRELLIS_COMB'][0]:,} | {u['TRELLIS_FF'][0]:,} | {u['DP16KD'][0]} | {u['MULT18X18D'][0]} | {100*u['TRELLIS_COMB'][0]/u['TRELLIS_COMB'][1]:.1f}% | {100*u['DP16KD'][0]/u['DP16KD'][1]:.1f}% |")
    out += ["", "A-priori estimates (docs/02 §4, written before synthesis): 3,000–6,000 LUT4, 2,500–4,500 FF, **64–80 EBR**, 4–16 multipliers, target 50 MHz / aspiration ≥ 100 MHz. "
            "Reality check in docs/02 §8.", ""]
    # ---- 4. projections
    out += ["## 4. Projections: simulated cycles ÷ tool-reported Fmax (NOT measured)", "",
            "Each number below is `cycles / (Fmax × 10⁶)` using the *post-route Fmax of the same variant from §1*. It answers 'what would this workload take on this FPGA **if** the "
            "modelled bus were the real bus and the design ran at the reported Fmax'. It is a projection from two non-hardware sources. Any real host path (PCIe/UART) is excluded.", ""]
    if perf:
        out += ["| variant | Fmax used (MHz) | kernel_vecadd_job (µs) | kernel_matmul16_job (µs) | vec_add8 1024 words, engine only (µs) | ten_acc 64 tiles, engine only (µs) | 4 KiB H2D incl. fetch (µs) | H2D payload MB/s |", "|---|---:|---:|---:|---:|---:|---:|---:|"]
        for v in VARS:
            f = bf[v][0]; r = perf["results"].get(v, {}).get("rd_lat4")
            if not f or not r: continue
            us = lambda cyc: cyc / f
            out.append(f"| {v} | {f:.1f} | {us(r['kernel_vecadd_job']['total']):.2f} | {us(r['kernel_matmul16_job']['total']):.2f} | {us(r['vec_add8']['vec']):.2f} | {us(r['ten_acc']['ten']):.2f} | {us(r['h2d_4k']['total']):.2f} | {r['h2d_4k']['bytes'] / r['h2d_4k']['total'] * f:.0f} |")
    out += ["", "### 4.1 Runtime-level phase split (driver + runtime over the RTL, simulated time)", ""]
    kp = []
    for v in VARS:
        f = f"{RES}/suite_{v}.txt"
        if os.path.exists(f):
            for l in open(f):
                m = re.match(r"KPERF (\S+) x(\d+): total (\d+) cycles; h2d (\d+) ns, kernel (\d+) ns, d2h (\d+) ns .*jobs (\d+)", l)
                if m: kp.append((v,) + m.groups())
    if kp:
        out += ["From `drv_kernels`: the userspace runtime submits 8 × 16×16×16 INT8 matmuls through the ported driver layer onto the RTL; time is the simulation clock at an *assumed* 100 MHz "
                "(the harness's fixed 10 ns per cycle, **not** the achieved Fmax), attributed per phase by the runtime's phase-split mode (submit/wait of H2D, kernel and D2H jobs).", "",
                "| variant | workload | total cycles | H2D | kernel | D2H | jobs | host-transfer share |", "|---|---|---:|---:|---:|---:|---:|---:|"]
        for v, nm, n, tot, h, k, d, j in kp:
            h, k, d = int(h), int(k), int(d)
            out.append(f"| {v} | {nm} ×{n} | {int(tot):,} | {h/1e3:.1f} µs | {k/1e3:.1f} µs | {d/1e3:.1f} µs | {j} | {100*(h+d)/(h+k+d):.1f}% |")
        out.append("")
    # ---- bring-up shell
    bu = [(f, load(f)) for f in sorted(glob.glob(f"{RES}/bringup_sim_*.json"))]
    out += ["### 4.2 End-to-end through the FPGA shell (simulation of the exact FPGA top, UART link)", ""]
    if bu:
        out += ["`tools/sfg1_bringup.py --sim` drives the Verilated **FPGA top** (core + UART bridge + host-RAM stand-in) with the same Python script that would drive a real board over `--port`. "
                "`measured_on_hardware` is false in every file. CYCLES = whole run incl. loading data over a 2 Mbaud UART model; BUSY = cycles the device itself was busy.", "",
                "| file | workload | link | measured on hardware | total cycles (UART incl.) | device BUSY cycles | BUSY share | checks |", "|---|---|---|---|---:|---:|---:|---|"]
        for f, d in bu:
            ok = sum(1 for c in d["checks"] if c["ok"]); n = len(d["checks"])
            for w in d["workloads"]:
                p = w["perf"]; out.append(f"| `{os.path.basename(f)}` | {w['name']} | {d['link']} | {d['measured_on_hardware']} | {p['CYCLES']:,} | {p['BUSY']:,} | {100*p['BUSY']/p['CYCLES']:.1f}% | {ok}/{n} pass ({d['status']}) |")
        out += ["", "The shell's link is a UART: end-to-end time is dominated by moving bytes over the serial line, not by the device. That is a property of the *bring-up shell*, not of the design.", ""]
    # ---- 5. hardware
    out += ["## 5. Measured hardware results", "", "**None.** No FPGA board, and no SF-G1 device, was available to this project; no bitstream has been loaded on any hardware.",
            "", "| quantity | measured on hardware |", "|---|---|"]
    for q in ["Clock frequency actually achieved", "Resource utilisation", "Instructions issued per cycle", "Effective memory bandwidth", "Kernel execution time", "Host-transfer overhead", "End-to-end workload time"]:
        out.append(f"| {q} | *not measured* |")
    out += ["", "To produce them: build `build/fpga/<variant>_<MHz>/s<seed>.bit` (`make fpga VARIANT=v5 MHZ=60`), load it on a ULX3S (`openFPGALoader`, see `docs/02` §7.3), then run "
            "`python3 tools/sfg1_bringup.py --port /dev/ttyUSB0 --json reports/results/bringup_hw_<variant>.json`. The tool labels results `hardware`; this generator would then "
            "report them here, separately from §2–§4. Clock frequency on hardware additionally needs an external reference (the shell exposes a heartbeat counter and the PERF_CYCLES register for a host-side estimate).", ""]
    # ---- 6. caveats
    out += ["## 6. Caveats that affect how to read the numbers", "",
            "* Fmax from nextpnr is a *static-timing estimate with the tool's delay model*, for one seed per run. Timing closure is not guaranteed on a real device (voltage/temperature/speed-grade margin is not modelled).",
            "* The bus model is the biggest unknown for throughput: command fetch alone is ≈ 16 reads per SQ entry (one burst in V1+), and every command ends with four posted CQE writes. A real PCIe link changes these costs substantially.",
            "* `ops` are defined per workload in `tb/cosim/tests_perf.cpp`; they count INT8 lane operations (multiply or add), not 'instructions' of any ISA.",
            "* The 'instructions issued per cycle' of this machine is **commands per cycle** (one SQ entry = one instruction) plus the engine's internal ops/cycle; the design is a command-driven accelerator, not an instruction-issue pipeline.",
            "* Results for V0–V4 and V5 come from the *same final RTL revision* (see the date and RTL hash in `reports/results/MANIFEST.txt`); earlier revisions' results are kept in `reports/results/history/` for the optimisation log only.", ""]
    open("reports/perf-report.md", "w").write("\n".join(out) + "\n"); print("wrote reports/perf-report.md", len(out), "lines")


def verification_report():
    out = ["# SF-G1 verification report", "", "Generated by `scripts/make_report.py` from `reports/results/` (suite output, mutation JSON, formal JSON, `checks.txt`). "
           "Method and the meaning of each layer: `docs/03-verification-plan.md`. **All results are simulation or bounded formal on a draft contract; none is hardware.**", ""]
    out += ["## 1. Co-simulation suite, every design variant", "", "| variant | tests | failed | checks passed | protocol-checker mask nonzero in |", "|---|---:|---:|---:|---:|"]
    for v in VARS:
        f = f"{RES}/suite_{v}.txt"
        if not os.path.exists(f): continue
        txt = open(f).read(); tests = re.findall(r"^TEST (\S+)\s+(PASS|FAIL) checks=(\d+) fails=(\d+) cycles=(\d+) \([\d.]+s\) checker_mask=([0-9a-f]+)", txt, re.M)
        sm = re.search(r"SUMMARY ran=(\d+) failed=(\d+)", txt)
        out.append(f"| {v} | {sm.group(1) if sm else len(tests)} | {sm.group(2) if sm else '?'} | {sum(int(t[2]) for t in tests):,} | {sum(1 for t in tests if int(t[5], 16))} |")
    f = f"{RES}/suite_v5.txt"
    if os.path.exists(f):
        out += ["", "Per test on V5 (the most pipelined variant; the other variants are in `reports/results/suite_*.txt`):", "", "| test | result | checks | cycles |", "|---|---|---:|---:|"]
        for t in re.findall(r"^TEST (\S+)\s+(PASS|FAIL) checks=(\d+) fails=(\d+) cycles=(\d+)", open(f).read(), re.M): out.append(f"| `{t[0]}` | {t[1]} | {t[2]} | {int(t[4]):,} |")
    for v in ("v0", "v5"):
        d = load(f"{RES}/mutation_{v}.json")
        if not d: continue
        rs = d["results"]; kill = [r for r in rs if r["status"] == "KILLED"]; surv = [r for r in rs if r["status"] == "SURVIVED"]; na = [r for r in rs if r["status"] == "NOT_APPLICABLE"]; oth = [r for r in rs if r["status"] not in ("KILLED", "SURVIVED", "NOT_APPLICABLE")]
        out += ["", f"## 2{'a' if v == 'v0' else 'b'}. Mutation testing — variant {v}", "", f"**{len(kill)} killed, {len(surv)} survived, {len(na)} not applicable, {len(oth)} other** of {len(rs)} mutants. "
                "`first failing tests` lists up to 4 tests that failed; `checker` = the protocol checker fired in at least one test.", "", "| mutant | status | what it breaks | failing tests | checker |", "|---|---|---|---:|---|"]
        for r in rs: out.append(f"| `{r['id']}` | {r['status']} | {r['desc']} | {len(r.get('failed_tests', []))} ({', '.join(r.get('failed_tests', [])[:4])}) | {'yes' if r.get('checker_fired_in') else '–'} |")
    fm = load(f"{RES}/formal.json")
    if fm:
        out += ["", "## 3. Formal", "", "`expect FAIL` rows are the negative controls: the same property against a deliberately broken RTL must produce a counterexample (depth = frame of the counterexample). "
                "`depth` for a PASS is the number of cycles from reset for which **no violation exists** (bounded model checking), or *all states* for an inductive invariant, or *exhaustive* for combinational equivalence (depth 1). "
                "A time-limited run reports the depth it actually completed.", "", "| proof | expected | result | depth / frame | seconds | note |", "|---|---|---|---|---:|---|"]
        for r in fm: out.append(f"| `{r['name']}` | {r['expect']} | {'**' + r['got'] + '**' if r['ok'] else r['got'] + ' (UNEXPECTED)'} | {r['depth']}{(' (target ' + str(r['target_depth']) + ')') if r.get('target_depth') and r['target_depth'] != r['depth'] else ''} | {r['seconds']} | {r.get('detail', '')[:110]} |")
        okc = sum(1 for r in fm if r["ok"]); nd = sum(1 for r in fm if "EXPECTED NON-DETECTION" in r.get("detail", ""))
        out += ["", f"{okc}/{len(fm)} as expected" + (f" — of which {nd} is an *expected non-detection* (a negative control that the bound is too shallow to catch; stated in its note), so **{okc - nd} negative controls/proofs behaved as designed and {nd} property (P5) is not formally covered**." if nd else ".")]
    if os.path.exists(f"{RES}/checks.txt"):
        out += ["", "## 4. Lint, contract cross-check, vendor testbench, model-vs-mock fuzz, unit simulations (verbatim output)", "", "```", open(f"{RES}/checks.txt").read().rstrip(), "```"]
    out += ["", "## 5. Not verified", "", "See `docs/05-limitations.md`: no hardware, no PCIe, the contract is unratified, formal is bounded for the front-end, no coverage metrics."]
    open("reports/verification-report.md", "w").write("\n".join(out) + "\n"); print("wrote reports/verification-report.md", len(out), "lines")

STEPS = [  # id, from, to, change, profile evidence, parameter
    ("O1", "v0", "v1", "burst SQ fetch (one 16-beat read per command) and 64-beat DMA read bursts", "device counters: FETCH = 128 of 139 cycles of a single NOP (16 single-beat reads); the H2D engine needs ≈ 8 cycles per word (every single-beat read pays the read latency)", "FETCH_BURST=1, DMA_BURST=64"),
    ("O2", "v1", "v2", "two read ports on device memory, pipelined VEC (1 word/cycle)", "after O1 the VEC counter is 4 cycles per word (read A, read B, compute, write) for a 1024-word VEC", "VEC_MODE=1"),
    ("O3", "v2", "v3", "four 8×8 multipliers, one TEN output per cycle", "after O2 the TEN counter is ≈ 8 cycles per output (one shared multiplier)", "TEN_MODE=1"),
    ("O4", "v3", "v4", "register the BRAM read outputs; split multiply and accumulate into separate stages", "nextpnr critical path of v3 (Fmax had *fallen* as parallel datapaths were added, §4): BRAM read → multiplier → adder tree → accumulator in one cycle", "PIPE=1"),
    ("O5", "v4", "v5", "register the four lane products before the adder tree", "nextpnr critical path of v4: multiplier → 3 adder levels → result register", "PIPE=2"),
]

def optimisation_log():
    perf = load(f"{RES}/perf_sim.json"); runs = fpga_runs(); bf = {v: best_fmax(runs.get(v, [])) for v in VARS}; hist = {}
    for f in sorted(glob.glob(f"{RES}/history/fpga_v*__rtl_rev_pre_O6.json")):
        d = norm(load(f) or {})
        if d and "pnr" in d: hist.setdefault(d["variant"], []).append(d)
    R = (perf or {}).get("results", {}); out = []
    def w(v, wl, k="total", m="rd_lat4"):
        try: return R[v][m][wl][k]
        except Exception: return None
    out += ["# SF-G1 optimisation log", "",
            "Rules (docs/06 §3): optimise **only after profiling**; one change at a time; every change recorded on four axes — **correctness, resources, timing, throughput** — and regressions reported. "
            "Cycle numbers are *simulated cycles* (RTL under Verilator, modelled host port, `rd_lat4` unless stated); resource and Fmax numbers are *Yosys/nextpnr results* "
            "for the ULX3S-85F (speed 6); nothing is measured on hardware. Tables below are generated from `reports/results/`; the narrative was written from the same data.", "",
            "## 1. Baseline profile (V0) — where the time goes", "",
            "| workload (rd_lat4) | total cycles | what the device counters say |", "|---|---:|---|"]
    if R.get("v0"):
        r = R["v0"]["rd_lat4"]
        out.append(f"| `nop_single` | {r['nop_single']['total']:.0f} | FETCH {r['nop_single']['fetch']:.0f} cycles ({100*r['nop_single']['fetch']/r['nop_single']['total']:.0f}%): 16 single-beat reads, one per SQ dword |")
        out.append(f"| `h2d_4k` (4 KiB) | {r['h2d_4k']['total']:.0f} | H2D engine {r['h2d_4k']['h2d']:.0f} cycles = {r['h2d_4k']['h2d']/1024:.1f} per word (single-beat reads, each paying the read latency) |")
        out.append(f"| `d2h_4k` | {r['d2h_4k']['total']:.0f} | writes are posted: {r['d2h_4k']['d2h']:.0f} engine cycles ≈ 1 per word |")
        out.append(f"| `vec_add8` (1024 words) | {r['vec_add8']['total']:.0f} | VEC engine {r['vec_add8']['vec']:.0f} = {r['vec_add8']['vec']/1024:.1f} cycles per word (sequential, one read port) |")
        out.append(f"| `ten_acc` (64 tiles, 1024 outputs) | {r['ten_acc']['total']:.0f} | TEN engine {r['ten_acc']['ten']:.0f} = {r['ten_acc']['ten']/1024:.1f} cycles per output (one shared multiplier) |")
        out.append(f"| `scrub_window` (16 KiB) | {r['scrub_window']['total']:.0f} | SCRUB engine {r['scrub_window']['scrub']:.0f} = 1 word per cycle |")
    out += ["", "## 2. Step table", "",
            "Throughput columns are total cycles of the named workload before → after (`rd_lat4`); Fmax is the post-route figure of the highest target met (or best final if none met) before → after, "
            "from the *final* RTL revision, so Fmax steps are **cumulative with O6**: V4/V5 figures include the O6 gain, which the O6 rows separate. Correctness is the 26-test suite on every variant (`reports/results/suite_*.txt`) plus the checks in `reports/verification-report.md`.", "",
            "| step | change | profile evidence | parameters | correctness | throughput (cycles) | LUT+carry | EBR | mult | Fmax MHz |", "|---|---|---|---|---|---|---|---|---|---|"]
    def util(v, k):
        p = bf[v][3]; return p["utilisation"][k][0] if p else None
    def fx(v): return bf[v][0]
    cpj0 = load(f"{RES}/critpath.json") or {}
    for sid, a, b, ch, ev, par in STEPS:
        v3c, v4c = cpj0.get("v3_50/s1"), cpj0.get("v4_50/s1")
        if sid == "O4" and v3c: ev = f"nextpnr critical path of v3 (final RTL): {v3c['total_ns']} ns, starts at a **block-RAM output** ({v3c['clk_to_q_ns']} ns clk-to-q) and goes through the multiplier and {v3c['carry_cells_on_path']} carry cells; Fmax had *fallen* with O2/O3 (§4)"
        if sid == "O5" and v4c: ev = f"nextpnr critical path of v4 (final RTL): {v4c['total_ns']} ns = flop → multiplier → {v4c['carry_cells_on_path']} carry cells (logic {v4c['logic_ns']} ns, routing {v4c['routing_ns']} ns)"
        tp = []
        for wl in ("kernel_vecadd_job", "kernel_matmul16_job", "h2d_4k", "vec_add8", "ten_acc"):
            x, y = w(a, wl), w(b, wl)
            if x is not None and y is not None and x != y: tp.append(f"`{wl}` {x:,.0f} → {y:,.0f}")
        suite = "26/26 on all variants"
        out.append(f"| {sid} {a}→{b} | {ch} | {ev} | `{par}` | {suite} | {'; '.join(tp) or 'unchanged'} | "
                   f"{util(a, 'TRELLIS_COMB') or '–'} → {util(b, 'TRELLIS_COMB') or '–'} | {util(a, 'DP16KD') or '–'} → {util(b, 'DP16KD') or '–'} | {util(a, 'MULT18X18D') or '–'} → {util(b, 'MULT18X18D') or '–'} | {fmt(fx(a))} → {fmt(fx(b))} |")
    ab = ab_runs()
    for (v, t), d in sorted(ab.items()):
        on = [x for x in runs.get(v, []) if x["core_mhz_target"] == t]
        if on:
            po, pn = d["pnr"][0], on[0]["pnr"][0]
            out.append(f"| O6 {v} (O6 off → on, same RTL, A/B @ {t} MHz target) | gate the unused mode's datapath with the build constants | §3: nextpnr critical path went through *unreachable* sequential states | `VSEQ/VPIPE/TSEQ/TPIPE` | 26/26 on all variants; engine window invariant re-proved for v0, v3, v4, v5 | unchanged (no function change) | {po['utilisation']['TRELLIS_COMB'][0]:,} → {pn['utilisation']['TRELLIS_COMB'][0]:,} | {po['utilisation']['DP16KD'][0]} → {pn['utilisation']['DP16KD'][0]} | {po['utilisation']['MULT18X18D'][0]} → {pn['utilisation']['MULT18X18D'][0]} | {po['fmax'][0]['mhz_final']:.1f} → {pn['fmax'][0]['mhz_final']:.1f} |")
    out += ["", "## 3. O6 — the dead-datapath finding (a profile result, not a design idea)", "",
            "After O5 the post-route Fmax moved by only a couple of MHz although the multiplier→adder path it targeted had been cut. Reading the *actual* critical path (nextpnr's `--report` JSON lists every cell; `scripts/critical_path.py` summarises it; the A/B in §3.0 reproduces it) showed the path went from a flop through LUT logic into the multiplier and then **a long carry-chain adder** into a register — "
            "the multiplier→adder shape O5 had removed from the *pipelined* datapath (the A/B in §3.0 confirms the structure; which exact register ends the path is not identifiable from nextpnr's net names). Cause: the engine still contained the *sequential* VEC and TEN states (`E_VS_*`, `E_TS_*`) in builds with `VEC_MODE=1` / `TEN_MODE=1`. "
            "They are unreachable there, but synthesis cannot prove it (the state register is a free-running FSM) and static timing cannot know a path is false, so it sized the clock by them.", "",
            "**Change (O6):** gate every state of the unused mode with the build constants (`VSEQ/VPIPE/TSEQ/TPIPE`, `rtl/sfg1_engine.sv`), so synthesis removes the dead logic. "
            "No function changes: the full suite passes on all variants and the engine-window invariant is proved for V0, V3, V4 and V5 on the final RTL.", "",
            "### 3.0 Reproducible A/B on the final RTL (`scripts/ab_o6.sh`: a copy of `rtl/` with the gating forced off; same flow, same seed)", "",
            "| variant | target MHz | O6 OFF: final Fmax | O6 OFF: TRELLIS_COMB | O6 OFF: critical path | O6 ON (shipped): final Fmax | O6 ON: TRELLIS_COMB | O6 ON: critical path |", "|---|---:|---:|---:|---|---:|---:|---|"]
    cpj = load(f"{RES}/critpath.json") or {}
    def cps(key):
        v = cpj.get(key)
        return f"{v['total_ns']} ns, mult {'yes' if v['has_dsp_multiplier'] else 'no'}, {v['carry_cells_on_path']} carry cells" if v else "–"
    for (v, t), d in sorted(ab_runs().items()):
        on = [x for x in runs.get(v, []) if x["core_mhz_target"] == t]
        po = d["pnr"][0]; pn = on[0]["pnr"][0] if on else None
        out.append(f"| {v} | {t} | {po['fmax'][0]['mhz_final']:.2f} | {po['utilisation']['TRELLIS_COMB'][0]:,} | {cps(f'{v}_noO6_{t}/s1')} | " +
                   (f"{pn['fmax'][0]['mhz_final']:.2f} | {pn['utilisation']['TRELLIS_COMB'][0]:,} | {cps(f'{v}_{t}/s1')} |" if pn else "– | – | – |"))
    out += ["", "### 3.0b Earlier RTL revision (before the lint fixes and the front-end fixes), kept in `reports/results/history/`", "",
            "| V5 run | RTL revision | target MHz | final Fmax MHz | timing met | TRELLIS_COMB | DP16KD | MULT18X18D |", "|---|---|---:|---:|---|---:|---:|---:|"]
    for tag, src in (("before O6 (history)", hist.get("v5", [])), ("after O6 (final RTL)", runs.get("v5", []))):
        for d in sorted(src, key=lambda d: d["core_mhz_target"]):
            for p in d["pnr"]:
                if p.get("fmax"):
                    x = p["fmax"][0]; u = p["utilisation"]; fm_ = x.get("mhz_final", x.get("mhz"))
                    out.append(f"| v5 | {tag} | {d['core_mhz_target']} | {fm_:.2f} | {'yes' if x['met'] else 'no'} | {u['TRELLIS_COMB'][0]:,} | {u['DP16KD'][0]} | {u['MULT18X18D'][0]} |")
    cp = load(f"{RES}/critpath.json") or {}
    if cp:
        out += ["", "### 3.1 What the critical path is made of, per variant (final RTL; `scripts/critical_path.py` from nextpnr's report)", "",
                "| run | path delay ns | clk-to-q | logic | routing | carry-chain cells | DSP multiplier on path | what that says |", "|---|---:|---:|---:|---:|---:|---|---|"]
        for k, v in sorted(cp.items()):
            say = ("starts at a **block-RAM output** (5.8 ns clk-to-q) and goes through the multiplier/adders: the O4 target" if v["clk_to_q_ns"] > 3 else
                   ("starts at a flop; the multiplier is still on the path" if v["has_dsp_multiplier"] else "no multiplier: carry chains with routing-dominated delay (64-bit address / bounds arithmetic)"))
            out.append(f"| {k.split('/')[0]} | {v['total_ns']} | {v['clk_to_q_ns']} | {v['logic_ns']} | {v['routing_ns']} | {v['carry_cells_on_path']} | {'yes' if v['has_dsp_multiplier'] else 'no'} | {say} |")
        out += ["", "Net names after Yosys flop merging are mostly opaque, so the last row is a statement about the *structure* of the path (many carry cells, 70 % routing, no DSP), "
                "not a confirmed source line. Its shape matches the a-priori expectation in `docs/02` §4 that 64-bit address adders/comparators would limit the clock. "
                f"V0–V3 start at a block-RAM output (clk-to-q 5.8 ns): registering those outputs (O4) removes that term, which is why O4 moves Fmax most (pre-O6 revision: {fmt(best_fmax(hist.get('v3', []))[0])} → {fmt(best_fmax(hist.get('v4', []))[0])} MHz; the further jump of V4 to {fmt(fx('v4'))} MHz is O6).", ""]
    out += ["", "The same gating applies to every variant (V0/V1 lose the pipelined datapaths, V2–V5 the sequential ones), so **resource counts and Fmax of V0–V4 in this report are those of the post-O6 RTL**; "
            "their pre-O6 figures are in `reports/results/history/` and shown below for comparison.", "",
            "| variant | pre-O6 best Fmax MHz (history) | pre-O6 LUT+carry | final Fmax MHz | final LUT+carry |", "|---|---:|---:|---:|---:|"]
    for v in VARS:
        h = best_fmax(hist.get(v, [])) if hist.get(v) else (None,) * 5
        hl = h[3]["utilisation"]["TRELLIS_COMB"][0] if h[3] else None
        out.append(f"| {v} | {fmt(h[0])} | {hl if hl else '–'} | {fmt(fx(v))} | {util(v, 'TRELLIS_COMB') or '–'} |")
    out += ["", "## 4. Regressions and things that did not help", "",
            "* **O2 and O3 lowered Fmax** (more parallel datapath on one clock) while cutting cycles; O4 was the fix for that. Cycles were bought first, timing second, and the report shows both.",
            f"* **O5 gave little**: before O6 it moved Fmax by only ≈ +1–3 MHz (history table in §3); after O6, V4 → V5 is {fmt(fx('v4'))} → {fmt(fx('v5'))} MHz — a few MHz, the size of seed-to-seed variation. My reading of the V4 path as the *live* TEN adder tree was a guess; only the cell-level path report of V5 showed it was the dead sequential datapath (§3).",
            "* A front-end formal run (not an optimisation) forced three functional changes late (R9 sampled registers, base alignment, enable-while-busy; `docs/01` F1–F3). They add 192 flip-flops (shadow queue registers) and some comparators; all numbers in this report are *after* them.",
            "* The 100 MHz aspiration of `docs/02` §4 was **not reached**; see the Fmax table in `reports/perf-report.md` §3.1 for what was.", "",
            "## 5. Process note", "",
            "The order above is the order I found things in, not a retrospective tidy-up: V0–V3 results were first produced on an *earlier RTL revision* (before the lint fixes, O6 and the front-end fixes); "
            "those files are preserved in `reports/results/history/` and every result outside that directory was regenerated on the final RTL (hash in `reports/results/MANIFEST.txt`).", "",
            "## 6. Next steps the profile points to (not done)", ""]
    nl = w("v5", "nop_single", "total", "rd_lat100"); n4 = w("v5", "nop_single")
    out += [f"1. **SQ prefetch / command overlap.** With a 100-cycle host read latency a single NOP costs {nl:.0f} cycles vs {n4:.0f} at latency 4: the SQ fetch is an un-overlapped round trip per command. Fetching the next entry while the engine runs hides it. " if nl else "1. SQ prefetch / command overlap.",
            "2. **SCRUB at 1 word/cycle** (4133 cycles for a 16 KiB window, run on every context open and close by the driver): a 4-words/cycle scrub port or a valid-bit scheme would cut it.",
            "3. **Shorten what is critical now (V5):** the path has no multiplier but long carry chains with ≈ 70 % routing delay — by its structure the 64-bit host-address/bounds arithmetic (`sfg1_cmdchk`, front-end). Registering the comparator results (one extra cycle per command, ≈ 3 % on a NOP stream) is the profile-justified next step; I did not do it.",
            "3b. Let Yosys use the DSP's own input/output registers (`MULT18X18D`) instead of fabric flops; the multiplier block alone costs ≈ 3.9 ns in the V4 path report.",
            "4. Host data path is 32-bit; a 64-bit port doubles H2D/D2H payload rate where the link allows.", ""]
    open("reports/optimisation-log.md", "w").write("\n".join(out) + "\n"); print("wrote reports/optimisation-log.md", len(out), "lines")

def docs02_section8():
    """Replace section 8 of docs/02 with the a-priori-vs-synthesised comparison (generated: numbers come from reports/results)."""
    runs = fpga_runs(); bf = {v: best_fmax(runs.get(v, [])) for v in VARS}
    f = "docs/02-fpga-requirements-and-board-selection.md"; t = open(f).read(); i = t.index("## 8. Reality check")
    v5 = bf["v5"]; v0 = bf["v0"]
    if not v5[3]: return
    m50 = [v.upper() for v in VARS if bf[v][4] and bf[v][1] >= 50]
    u5, u0 = v5[3]["utilisation"], (v0[3]["utilisation"] if v0[3] else None); c5 = v5[2]["synthesis"]["counts"]
    def row(q, est, act, verdict): return f"| {q} | {est} | {act} | {verdict} |"
    L = ["## 8. Reality check (generated by `scripts/make_report.py` from `reports/results/fpga_*.json`; the numbers are Yosys/nextpnr results, not measurements)", "",
         "A-priori estimates (§4, written before any synthesis) against the most pipelined variant V5 (the baseline V0 in brackets), including the bring-up shell (UART bridge, 16 KiB host-RAM stand-in):", "",
         "| quantity | a-priori (§4) | synthesised / placed | verdict |", "|---|---|---|---|",
         row("4-input LUTs", "3,000 – 6,000", f"{c5['LUT4']:,} LUT4 (+ {c5['CCU2C']:,} carry cells; nextpnr TRELLIS_COMB {u5['TRELLIS_COMB'][0]:,} = {100*u5['TRELLIS_COMB'][0]/u5['TRELLIS_COMB'][1]:.0f}% of the device)" + (f" [V0: TRELLIS_COMB {u0['TRELLIS_COMB'][0]:,}]" if u0 else ""), "LUT4 count at the top of the estimate; counting the carry cells placed in the same slices, the logic is about 50 % larger than the estimate"),
         row("Flip-flops", "2,500 – 4,500", f"{u5['TRELLIS_FF'][0]:,}" + (f" [V0: {u0['TRELLIS_FF'][0]:,}]" if u0 else ""), "inside the estimate"),
         row("18 Kb block RAM", "64 – 80", f"{u5['DP16KD'][0]} of {u5['DP16KD'][1]}" + (f" [V0: {u0['DP16KD'][0]}]" if u0 else ""), "as estimated (the second read copy for VEC_MODE=1 is the cost of the dual read port)"),
         row("18×18 multipliers", "4 – 16", f"{u5['MULT18X18D'][0]}", "bottom of the range (4 MACs × 8×8 bits)"),
         row("Clock", "target 50 MHz, aspiration ≥ 100 MHz", f"{v5[0]:.1f} MHz post-route at the highest met target ({v5[1]} MHz); {fmt(v0[0])} MHz for V0" if v5[4] else f"best {v5[0]:.1f} MHz, target missed", f"50 MHz target met by {', '.join(m50) or 'no variant'}; the ≥ 100 MHz aspiration was **not** reached (see the critical-path note in `reports/optimisation-log.md`)"),
         row("Clock domains", "1", "1 (core clock from the PLL; UART bridge in the same domain)", "as designed"),
         row("I/O", "clock, reset, UART, ≥ 4 LEDs", f"{u5['TRELLIS_IO'][0]} I/O cells", "as designed"), "",
         "Reading the table: the block-RAM and multiplier estimates (derived from bit counts and datapath width) held; the LUT estimate was at its upper edge (more once carry cells are counted); "
         "the ≥ 100 MHz aspiration was not derived from the ECP5 speed-grade-6 delay model and was **not** met — see the critical-path analysis in `reports/optimisation-log.md` §3.", ""]
    open(f, "w").write(t[:i] + "\n".join(L) + "\n"); print("updated docs/02 §8")

main(); verification_report(); optimisation_log(); docs02_section8()
