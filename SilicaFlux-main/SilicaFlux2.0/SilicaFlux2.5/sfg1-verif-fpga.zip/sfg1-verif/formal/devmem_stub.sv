// SPDX-License-Identifier: GPL-2.0-only
// FORMAL ABSTRACTION of sfg1_devmem for the window-isolation proof: the read data are FREE (any value, any time).
// Sound for that proof because it constrains only the ADDRESSES the engine drives, never the data read back; it
// removes the memory array from the SMT problem. Not used in any other proof or in any build.
`timescale 1ns/1ps
module sfg1_devmem #(parameter integer DEPTH = 4096, parameter integer NRD = 1) (
  input wire clk, input wire wr_en, input wire [$clog2(DEPTH)-1:0] wr_addr, input wire [31:0] wr_data,
  input wire rd0_en, input wire [$clog2(DEPTH)-1:0] rd0_addr, output wire [31:0] rd0_data,
  input wire rd1_en, input wire [$clog2(DEPTH)-1:0] rd1_addr, output wire [31:0] rd1_data);
  (* anyseq *) wire [31:0] free0;
  (* anyseq *) wire [31:0] free1;
  assign rd0_data = free0; assign rd1_data = free1;
endmodule
