// SPDX-License-Identifier: GPL-2.0-only
// FORMAL: front-end protocol properties against a HOSTILE host: CSR writes (any register, any value, any time),
// any bus responses consistent with the requests issued, any write back-pressure, any engine result. Checked: the
// protocol checker's properties P1-P8, P11, P13 (see rtl/sfg1_proto_chk.sv) plus reset/halt/fatal/enable invariants.
// Host-conformance ASSUMPTIONS (only these): CQ_HEAD is only ever moved forward within [head, tail] (credit return).
`timescale 1ns/1ps
module fe_formal #(parameter integer FETCH_BURST = 1, parameter integer ORDER_BUG = 0, parameter integer MUT = 0) (
  input wire clk, input wire csr_wr, input wire [11:0] csr_addr, input wire [31:0] csr_wdata,
  input wire mrd_valid, input wire [31:0] mrd_data, input wire mrd_err, input wire mwr_ready, input wire eng_done, input wire [2:0] eng_status);
  `include "sfg1_defs.svh"
  `include "sfg1_dbg.svh"
  reg init = 1'b1; always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;
  wire [31:0] csr_rdata; wire mrd_req, mwr_req, irq_msg, eng_start, eng_abort; wire [63:0] mrd_addr, mwr_addr; wire [8:0] mrd_len; wire [31:0] mwr_data;
  wire [15:0] eop, ectx, efl; wire [31:0] eex; wire [63:0] eh, el, ea, eb, ec; wire [3:0] st; wire [383:0] dbg;
  sfg1_frontend #(.MAX_CTX(4), .MAX_QENT(16), .WIN_KIB(1), .RESET_CYCLES(2), .FETCH_BURST(FETCH_BURST), .ORDER_BUG(ORDER_BUG), .MUT(MUT)) dut (
    .clk(clk), .rst_n(rst_n), .csr_wr(csr_wr), .csr_addr(csr_addr), .csr_wdata(csr_wdata), .csr_rdata(csr_rdata),
    .mrd_req(mrd_req), .mrd_addr(mrd_addr), .mrd_len(mrd_len), .mrd_valid(mrd_valid), .mrd_data(mrd_data), .mrd_err(mrd_err),
    .mwr_req(mwr_req), .mwr_addr(mwr_addr), .mwr_data(mwr_data), .mwr_ready(mwr_ready), .irq_msg(irq_msg),
    .eng_start(eng_start), .eng_opcode(eop), .eng_ctx(ectx), .eng_flags(efl), .eng_exec_op(eex), .eng_host_addr(eh), .eng_len(el), .eng_a(ea), .eng_b(eb), .eng_c(ec),
    .eng_done(eng_done), .eng_status(eng_status), .eng_abort(eng_abort), .fe_state(st), .dbg_fe(dbg));
  wire [86:0] dbg_eng = 87'd0;
  wire [15:0] fm, fc;
  sfg1_proto_chk #(.MAX_CTX(4), .WIN_KIB(1)) chk (.clk(clk), .rst_n(rst_n), .csr_wr(csr_wr), .csr_addr(csr_addr), .mrd_req(mrd_req), .mrd_addr(mrd_addr), .mrd_len(mrd_len),
    .mwr_req(mwr_req), .mwr_addr(mwr_addr), .mwr_data(mwr_data), .mwr_ready(mwr_ready), .irq_msg(irq_msg), .dbg_fe(dbg), .dbg_eng(dbg_eng), .fail_mask(fm), .fail_cnt(fc));

  wire enable = dbg[DBGF_ENABLE], halted = dbg[DBGF_HALTED], fatal = dbg[DBGF_FATAL], rst_act = dbg[DBGF_RESET];
  wire [15:0] cq_head = dbg[DBGF_CQHEAD +: 16], cq_tail = dbg[DBGF_CQTAIL +: 16], cq_n = dbg[DBGF_CQN +: 16], sq_head = dbg[DBGF_SQHEAD +: 16], sq_tail = dbg[DBGF_SQTAIL +: 16];
  wire [2:0]  irq_status = dbg[DBGF_IRQST +: 3];
  // ---- environment assumptions ----
  reg [8:0] outst = 9'd0; reg p_abort = 1'b0;
  always @(posedge clk) begin
    p_abort <= eng_abort;
    if (mrd_req) outst <= mrd_len; else if (mrd_err || eng_abort) outst <= 9'd0; else if (mrd_valid && outst != 0) outst <= outst - 9'd1;
  end
  always @* begin
    // (reset is held during the first cycle only: rst_n = !init, so no assumption is needed -- an earlier
    //  `assume (rst_n || !init)` here was FALSE in cycle 0 and made every proof vacuous; see docs/03)
    if (mrd_valid || mrd_err) assume (outst != 9'd0 && !eng_abort);      // responses only to an outstanding request (the bus unit filters stale ones)
    assume (!(mrd_valid && mrd_err));
    if (eng_done) assume (st == 4'd4);                                   // the engine answers only while the front-end waits for it
    assume (eng_status == 3'd0 || eng_status == 3'd3 || eng_status == 3'd6);
    if (csr_wr && csr_addr == SFG1_REG_CQ_HEAD && cq_n != 0)             // conforming credit return: forward, never past the tail
      assume ((((csr_wdata[15:0] & (cq_n[15:0] - 16'd1)) - cq_head) & (cq_n[15:0] - 16'd1)) <= ((cq_tail - cq_head) & (cq_n[15:0] - 16'd1)));
  end
  // ---- properties ----
  wire ctrl_wr = csr_wr && csr_addr == SFG1_REG_CTRL;
  wire rst_ev  = (ctrl_wr && csr_wdata[SFG1_CTRL_ENGINE_RESET]) || (csr_wr && csr_addr == SFG1_REG_RESET && csr_wdata == SFG1_RESET_MAGIC);
  wire func_ev = csr_wr && csr_addr == SFG1_REG_RESET && csr_wdata == SFG1_RESET_MAGIC;
  reg p_rst = 1'b0, p_func = 1'b0, p_halted = 1'b0, p_fatal = 1'b0, p_clr = 1'b0, p_enable = 1'b0, p_ctrl = 1'b0, pv = 1'b0;
  always @(posedge clk) begin pv <= !init; p_rst <= rst_ev; p_func <= func_ev; p_halted <= halted; p_fatal <= fatal; p_enable <= enable; p_ctrl <= ctrl_wr;
    p_clr <= ctrl_wr && csr_wdata[SFG1_CTRL_CLEAR_HALT]; end
  always @(posedge clk) if (pv) begin
    assert (fm == 16'd0);                                                                      // P1..P13 of the protocol checker
    assert (st <= 4'd9);                                                                       // FSM stays in range
    if (p_rst) assert (!enable && st == 4'd0 && sq_head == 0 && sq_tail == 0 && cq_tail == 0 && cq_head == 0 && irq_status == 0 && !halted && rst_act);   // reset effects
    if (p_halted && !p_clr && !p_rst && !init) assert (halted);                                // HALTED is sticky until CLEAR_HALT or a reset
    if (p_fatal && !p_func) assert (fatal);                                                    // FATAL is cleared only by a FUNCTION reset
    if (!p_enable && enable) assert (p_ctrl);                                                  // ENABLE rises only through a CTRL write
    if (!p_enable && !p_rst) assert (!(enable && !p_ctrl));                                    // ...and never by itself
  end
endmodule
