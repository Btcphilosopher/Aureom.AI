// SPDX-License-Identifier: GPL-2.0-only
// FORMAL: device-memory window isolation of sfg1_engine. For ANY sequence of validated commands, ANY bus
// responses and ANY stalls, every device-memory address the engine drives (write, read port 0, read port 1)
// lies in the window of the context it is serving. The structural reason is that addresses are formed as
// {ctx, window-local pointer} by concatenation (no adder); the proof is what stops a future edit breaking it.
`timescale 1ns/1ps
module engine_formal #(parameter integer VEC_MODE = 0, parameter integer TEN_MODE = 0, parameter integer MUT = 0, parameter integer DMA_BURST = 1, parameter integer PIPE = 0) (
  input wire clk, input wire eng_start,
  input wire [15:0] eng_opcode, input wire [15:0] eng_ctx, input wire [15:0] eng_flags, input wire [31:0] eng_exec_op,
  input wire [63:0] eng_host_addr, input wire [63:0] eng_len, input wire [63:0] eng_a, input wire [63:0] eng_b, input wire [63:0] eng_c,
  input wire eng_abort, input wire r_valid, input wire [31:0] r_data, input wire r_err, input wire mwr_ready, input wire mwr_err);
  `include "sfg1_dbg.svh"
  localparam integer MAX_CTX = 4, WIN_KIB = 1, WL = 8;           // 256-word windows keep the SMT problem small
  // No reset and no assumptions about the state: the engine starts in an ARBITRARY state (any FSM code, any
  // pointers, any context register), so a pass proves the property for every reachable AND unreachable state --
  // an inductive invariant, which is stronger than bounded reachability and cheap for the solver.
  wire rst_n = 1'b1;
  wire eng_done; wire [2:0] eng_status; wire e_mrd_req, e_mwr_req, busy, rd_stall, wr_stall; wire [63:0] e_mrd_addr, e_mwr_addr; wire [8:0] e_mrd_len; wire [31:0] e_mwr_data; wire [4:0] op_oh;
  wire [86:0] dbg;
  sfg1_engine #(.MAX_CTX(MAX_CTX), .WIN_KIB(WIN_KIB), .DMA_BURST(DMA_BURST), .VEC_MODE(VEC_MODE), .TEN_MODE(TEN_MODE), .PIPE(PIPE), .MUT(MUT)) dut (
    .clk(clk), .rst_n(rst_n), .eng_start(eng_start), .eng_opcode(eng_opcode), .eng_ctx(eng_ctx), .eng_flags(eng_flags), .eng_exec_op(eng_exec_op),
    .eng_host_addr(eng_host_addr), .eng_len(eng_len), .eng_a(eng_a), .eng_b(eng_b), .eng_c(eng_c), .eng_done(eng_done), .eng_status(eng_status), .eng_abort(eng_abort),
    .e_mrd_req(e_mrd_req), .e_mrd_addr(e_mrd_addr), .e_mrd_len(e_mrd_len), .r_valid(r_valid), .r_data(r_data), .r_err(r_err),
    .e_mwr_req(e_mwr_req), .e_mwr_addr(e_mwr_addr), .e_mwr_data(e_mwr_data), .mwr_ready(mwr_ready), .mwr_err(mwr_err),
    .eng_busy(busy), .op_oh(op_oh), .rd_stall(rd_stall), .wr_stall(wr_stall), .dbg_eng(dbg));
  wire [7:0]  ctx = dbg[DBGE_CTX +: 8];
  wire        wen = dbg[DBGE_WREN];
  wire [23:0] wa = dbg[DBGE_WRADDR +: 24], r0 = dbg[DBGE_RD0ADDR +: 24], r1 = dbg[DBGE_RD1ADDR +: 24];
  always @* begin
    if (wen) assert ((wa >> WL) == {16'd0, ctx});          // writes
    assert ((r0 >> WL) == {16'd0, ctx});                     // read port 0
    assert ((r1 >> WL) == {16'd0, ctx});                     // read port 1
  end
endmodule
