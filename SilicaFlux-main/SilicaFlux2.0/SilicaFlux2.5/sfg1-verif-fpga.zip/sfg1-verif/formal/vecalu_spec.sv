// SPDX-License-Identifier: GPL-2.0-only
// FORMAL: sfg1_vecalu (all 8 ops incl. the DOT8 reduction) equals a per-lane specification for ALL operand values.
`timescale 1ns/1ps
module vecalu_formal #(parameter integer MUT = 0) (input wire [2:0] op, input wire [31:0] a, input wire [31:0] b);
  wire [31:0] y; wire signed [31:0] dot;
  sfg1_vecalu #(.MUT(MUT)) dut (.op(op), .a(a), .b(b), .y(y), .dot(dot));
  integer k; reg [31:0] spec; reg signed [31:0] sd; integer x, z, r;
  always @* begin
    spec = 32'd0; sd = 32'sd0;
    for (k = 0; k < 4; k = k + 1) begin
      x = $signed(a[8*k +: 8]); z = $signed(b[8*k +: 8]); sd = sd + x * z;
      case (op)
        3'd0: r = x + z;  3'd1: r = x - z;  3'd2: r = (x > z) ? x : z;  3'd3: r = (x < 0) ? 0 : x;  3'd6: r = x * z;  default: r = 0;
      endcase
      spec[8*k +: 8] = r[7:0];
    end
    if (op == 3'd4) spec = a ^ b;
    if (op == 3'd5) spec = a & b;
    if (op == 3'd7) spec = 32'd0;
  end
  always @* begin assert (y == spec); assert (dot == sd); end
endmodule
