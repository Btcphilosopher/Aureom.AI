// SPDX-License-Identifier: GPL-2.0-only
// FORMAL: sfg1_cmdchk is equal, for EVERY input, to an independently written specification that uses
// arithmetic wide enough that nothing can overflow (192 bits) instead of the RTL's high-bit tests.
// Precedence per the driver mock (docs/01-contract-interpretation.md section 2).
`timescale 1ns/1ps
module cmdchk_formal #(parameter integer MUT = 0) (input wire [15:0] op, input wire [15:0] flags, input wire [31:0] exec_op,
                      input wire [63:0] host_addr, input wire [63:0] len, input wire [63:0] a, input wire [63:0] b, input wire [63:0] c);
  localparam integer WIN_B = 16384;
  wire [2:0] st;
  sfg1_cmdchk #(.WIN_B(WIN_B), .MUT(MUT)) dut (.op(op), .flags(flags), .exec_op(exec_op), .host_addr(host_addr), .len(len), .a(a), .b(b), .c(c), .status(st));

  localparam [191:0] TWO64 = 192'd1 << 64;
  wire [191:0] L = len, A = a, B = b, C = c, H = host_addr;
  wire [191:0] n4 = L * 4, n16 = L * 16, n64 = L * 64;
  function fits(input [191:0] off, input [191:0] n);            // [off, off+n) inside the window, exact arithmetic
    fits = (off + n) <= WIN_B;
  endfunction
  wire none     = (flags == 0) && (exec_op == 0) && (host_addr == 0) && (len == 0) && (a == 0) && (b == 0) && (c == 0);
  wire unal_abc = (a % 4 != 0) || (b % 4 != 0) || (c % 4 != 0);
  wire relu = (exec_op == 3), dot = (exec_op == 7);
  reg [2:0] spec;
  always @* begin
    spec = 3'd0;
    case (op)
      16'd0, 16'd6: spec = none ? 3'd0 : 3'd7;
      16'd1, 16'd5:
        if (flags != 0 || exec_op != 0 || b != 0 || c != 0) spec = 3'd7;
        else if (len == 0 || len % 4 != 0 || a % 4 != 0) spec = 3'd4;
        else if (!fits(A, L)) spec = 3'd4;
        else if (H + L >= TWO64) spec = 3'd6;
        else spec = 3'd0;
      16'd2:
        if (flags != 0 || host_addr != 0 || exec_op > 7) spec = 3'd7;
        else if (len == 0 || unal_abc || n4 >= TWO64) spec = 3'd4;
        else if (relu && b != 0) spec = 3'd7;
        else if (!fits(A, n4) || (!relu && !fits(B, n4)) || !fits(C, dot ? 192'd4 : n4)) spec = 3'd4;
        else spec = 3'd0;
      16'd3:
        if ((flags & 16'hfffe) != 0 || exec_op != 0 || host_addr != 0) spec = 3'd7;
        else if (len == 0 || unal_abc || n16 >= TWO64 || n64 >= TWO64) spec = 3'd4;
        else if (!fits(A, n16) || !fits(B, n16) || !fits(C, n64)) spec = 3'd4;
        else spec = 3'd0;
      default: spec = 3'd1;
    endcase
  end
  always @* assert (st == spec);
endmodule
