// SPDX-License-Identifier: GPL-2.0-only
// SF-G1 host-bus unit.
//  * Muxes the host-memory master between the front-end (SQ fetch, CQE write-back) and the
//    engine (DMA). They never need the bus at the same time: the front-end waits in S_EXEC
//    while the engine owns it.
//  * Epoch filter: every read request carries the current 4-bit epoch as a tag; the bus must
//    return it with each response. The epoch advances on every ENGINE/FUNCTION reset, so read
//    data that arrives after a reset (a request issued before it) is discarded instead of being
//    mistaken for the answer to a later request. (PCIe completion tags play this role.)
//  * Responses are registered once (timing) before they reach the front-end / engine.
`timescale 1ns/1ps
module sfg1_hbus #(parameter integer MUT = 0) (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        eng_busy,
  input  wire        abort,            // reset pulse from the front-end: advance the epoch
  // from front-end
  input  wire        f_mrd_req,  input wire [63:0] f_mrd_addr, input wire [8:0] f_mrd_len,
  input  wire        f_mwr_req,  input wire [63:0] f_mwr_addr, input wire [31:0] f_mwr_data,
  // from engine
  input  wire        e_mrd_req,  input wire [63:0] e_mrd_addr, input wire [8:0] e_mrd_len,
  input  wire        e_mwr_req,  input wire [63:0] e_mwr_addr, input wire [31:0] e_mwr_data,
  // to / from the outside world
  output wire        mrd_req,    output wire [63:0] mrd_addr,  output wire [8:0] mrd_len,
  output wire [3:0]  mrd_tag,
  input  wire        mrd_valid,  input wire [31:0] mrd_data,    input wire mrd_err,
  input  wire [3:0]  mrd_rtag,
  output wire        mwr_req,    output wire [63:0] mwr_addr,   output wire [31:0] mwr_data,
  // filtered, registered responses to both consumers
  output reg         r_valid,
  output reg  [31:0] r_data,
  output reg         r_err
);
  reg [3:0] epoch;
  always @(posedge clk or negedge rst_n)
    if (!rst_n) epoch <= 4'd0;
    else if (abort) epoch <= epoch + 4'd1;

  // While the abort pulse is high no NEW request may leave the core: the front-end and the engine
  // retract their pending requests one cycle apart, so without this gate the engine's pending write
  // (or a stale read) could still be accepted after the host has asked for the reset (found by
  // protocol property P11 in the reset/timeout tests).
  wire gate = abort && (MUT != 21);                              // MUTANT 21: no gating
  assign mrd_req  = !gate && (eng_busy ? e_mrd_req  : f_mrd_req);
  assign mrd_addr = eng_busy ? e_mrd_addr : f_mrd_addr;
  assign mrd_len  = eng_busy ? e_mrd_len  : f_mrd_len;
  assign mrd_tag  = epoch;
  assign mwr_req  = !gate && (eng_busy ? e_mwr_req  : f_mwr_req);
  assign mwr_addr = eng_busy ? e_mwr_addr : f_mwr_addr;
  assign mwr_data = eng_busy ? e_mwr_data : f_mwr_data;

  wire in_epoch = (MUT == 20) ? 1'b1 : (mrd_rtag == epoch);     // MUTANT 20: accept stale responses
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin r_valid <= 1'b0; r_data <= 32'd0; r_err <= 1'b0; end
    else begin
      r_valid <= mrd_valid && in_epoch && !abort;
      r_err   <= mrd_err   && in_epoch && !abort;
      r_data  <= mrd_data;
    end
  end
endmodule
