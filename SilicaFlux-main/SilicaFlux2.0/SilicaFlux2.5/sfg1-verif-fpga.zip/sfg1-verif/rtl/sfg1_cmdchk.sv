// SPDX-License-Identifier: GPL-2.0-only
// SF-G1 command checker: purely combinational, one place that decides BAD_ARGS / BOUNDS for the
// engine opcodes. Precedence is the one of the driver's reference model (kernel/sfg1_mock.c,
// mock_exec) -- see docs/01-contract-interpretation.md. Kept free of state so it can be proven
// exhaustively against an independent specification (formal/cmdchk_spec.sv).
//
// WIN_B = bytes per context window. All comparisons are exact 64-bit arithmetic: a field >= 2^32
// is out of bounds for any window < 4 GiB, and "len*4 / *16 / *64 overflows u64" is decided by
// the high bits (len >= 2^62 / 2^60 / 2^58), because the reference reports BOUNDS for overflow
// *before* it evaluates other BAD_ARGS rules.
`timescale 1ns/1ps
module sfg1_cmdchk #(
  parameter integer WIN_B = 16384,
  parameter integer MUT   = 0       // verification mutants only (0 = correct)
) (
  input  wire [15:0] op,
  input  wire [15:0] flags,
  input  wire [31:0] exec_op,
  input  wire [63:0] host_addr,
  input  wire [63:0] len,
  input  wire [63:0] a,
  input  wire [63:0] b,
  input  wire [63:0] c,
  output reg  [2:0]  status
);
  `include "sfg1_defs.svh"

  // [off, off+n) inside [0, WIN_B) with n given as a 64-bit byte count (no overflow possible)
  function range_ok(input [63:0] off, input [63:0] n);
    reg [63:0] lim;
    begin
      lim = 64'(WIN_B);
      if (MUT == 10)      range_ok = (n <= lim) && (off <= lim - n + 64'd4); // MUTANT: off-by-one-word, accepts off+n == WIN_B+4
      else                range_ok = (n <= lim) && (off <= lim - n);
    end
  endfunction

  wire any_other_nz = (flags != 16'd0) | (exec_op != 32'd0) | (host_addr != 64'd0) |
                      (len != 64'd0) | (a != 64'd0) | (b != 64'd0) | (c != 64'd0);
  wire align_abc    = ((a[1:0] | b[1:0] | c[1:0]) != 2'b00);
  wire len_zero     = (len == 64'd0);
  wire ovf4         = (len[63:62] != 2'b00);
  wire ovf16        = (len[63:60] != 4'b0000);
  wire ovf64        = (len[63:58] != 6'b000000);
  wire [63:0] n4    = {len[61:0], 2'b00};
  wire [63:0] n16   = {len[59:0], 4'b0000};
  wire [63:0] n64   = {len[57:0], 6'b000000};
  wire is_relu      = (exec_op == {29'd0, SFG1_VEC_RELU8});
  wire is_dot       = (exec_op == {29'd0, SFG1_VEC_DOT8});
  wire [63:0] c_vec = is_dot ? 64'd4 : n4;
  wire [64:0] hsum  = {1'b0, host_addr} + {1'b0, len};     // host range [host, host+len) wraps the 64-bit space
  wire        host_wrap = hsum[64];

  always @* begin
    status = SFG1_ST_OK;
    case (op)
      SFG1_OP_NOP, SFG1_OP_SCRUB: begin
        // no operands allowed
        if (any_other_nz && !(MUT == 11 && op == SFG1_OP_NOP)) status = SFG1_ST_BAD_ARGS;
      end
      SFG1_OP_DMA_H2D, SFG1_OP_DMA_D2H: begin
        if ((flags != 16'd0) | (exec_op != 32'd0) | (b != 64'd0) | (c != 64'd0)) status = SFG1_ST_BAD_ARGS;
        else if (len_zero | ((len[1:0] | a[1:0]) != 2'b00))                     status = SFG1_ST_BOUNDS;
        else if (!range_ok(a, len))                                               status = SFG1_ST_BOUNDS;
        else if (host_wrap)                                                       status = SFG1_ST_DMA_ERROR;
      end
      SFG1_OP_VEC: begin
        if ((flags != 16'd0) | (host_addr != 64'd0) | (exec_op > 32'd7))          status = SFG1_ST_BAD_ARGS;
        else if (len_zero | align_abc | ((MUT == 15) ? 1'b0 : ovf4))              status = SFG1_ST_BOUNDS;   // MUTANT 15: overflow ignored
        else if (is_relu && (b != 64'd0))                                         status = SFG1_ST_BAD_ARGS;
        else if (!range_ok(a, n4) || (!is_relu && !range_ok(b, n4)) || !range_ok(c, c_vec))
                                                                                  status = SFG1_ST_BOUNDS;
      end
      SFG1_OP_TEN: begin
        if (((flags & 16'hfffe) != 16'd0) | (exec_op != 32'd0) | (host_addr != 64'd0)) status = SFG1_ST_BAD_ARGS;
        else if (len_zero | align_abc | ovf16 | ovf64)                            status = SFG1_ST_BOUNDS;
        else if (!range_ok(a, n16) || !range_ok(b, n16) || !range_ok(c, n64))     status = SFG1_ST_BOUNDS;
      end
      default: status = SFG1_ST_BAD_OPCODE;
    endcase
  end
endmodule
