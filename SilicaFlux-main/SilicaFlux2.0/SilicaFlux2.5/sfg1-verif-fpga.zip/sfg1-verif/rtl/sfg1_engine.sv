// SPDX-License-Identifier: GPL-2.0-only
// -----------------------------------------------------------------------------
// SF-G1 execution engine (DRAFT v1.0 contract, sections 8-10). NEW RTL, authored for this
// project: the driver package's reference RTL stubs the engine behind eng_*.
//
// Executes ONE already-validated command at a time (the front-end's sfg1_cmdchk has accepted
// it): DMA_H2D, DMA_D2H, VEC, TEN, SCRUB. Owns the device-local memory.
//
// Isolation by construction: every device-memory address is the CONCATENATION {ctx, wptr} with
// a window-local word pointer `wptr` of WL bits. There is no adder between a context id and an
// address, so a pointer bug (wrap, overflow) can at worst wrap inside the context's own window.
// formal/engine_window.sby proves  mem_addr[AW-1:WL] == active ctx  for all inputs and states.
//
// Variants (parameters; each is verified by the same suite, see reports/optimisation-log.md):
//   DMA_BURST  1: single-beat host reads (baseline)  | up to 256 beats per request
//   VEC_MODE   0: sequential, 1 read port, 4 cycles/word | 1: 2 read ports, 1 word/cycle pipelined
//   TEN_MODE   0: sequential, 1 multiplier, ~5-8 cycles/output | 1: 4 multipliers, 1 output/cycle
//   PIPE       0: BRAM -> multiplier -> adder -> accumulator in one cycle | 1: BRAM outputs registered, multiply and
//              accumulate split into separate stages in VEC_MODE 1 / TEN_MODE 1 | 2: additionally the four lane products are
//              registered before the adder tree (timing closure; +1..3 cycles latency per VEC op / TEN tile)
//   (VEC_MODE=1 doubles device memory: two identical read copies)
// MUT: verification mutants only (13..19); 0 in every real build.
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
module sfg1_engine #(
  parameter integer MAX_CTX   = 4,       // power of two, >= 2
  parameter integer WIN_KIB   = 16,      // power of two
  parameter integer DMA_BURST = 1,
  parameter integer VEC_MODE  = 0,
  parameter integer TEN_MODE  = 0,
  parameter integer PIPE      = 0,
  parameter integer MUT       = 0
) (
  input  wire        clk,
  input  wire        rst_n,

  input  wire        eng_start,
  input  wire [15:0] eng_opcode,
  input  wire [15:0] eng_ctx,
  input  wire [15:0] eng_flags,
  input  wire [31:0] eng_exec_op,
  input  wire [63:0] eng_host_addr,
  input  wire [63:0] eng_len,
  input  wire [63:0] eng_a,
  input  wire [63:0] eng_b,
  input  wire [63:0] eng_c,
  output reg         eng_done,
  output reg  [2:0]  eng_status,
  input  wire        eng_abort,

  // host bus (through sfg1_hbus)
  output reg         e_mrd_req,
  output reg  [63:0] e_mrd_addr,
  output reg  [8:0]  e_mrd_len,
  input  wire        r_valid,
  input  wire [31:0] r_data,
  input  wire        r_err,
  output reg         e_mwr_req,
  output reg  [63:0] e_mwr_addr,
  output reg  [31:0] e_mwr_data,
  input  wire        mwr_ready,
  input  wire        mwr_err,

  // observability
  output wire        eng_busy,
  output wire [4:0]  op_oh,
  output wire        rd_stall,
  output wire        wr_stall,
  output wire [86:0] dbg_eng                   // layout: sfg1_dbg.svh
);
  `include "sfg1_defs.svh"
  `include "sfg1_dbg.svh"

  localparam integer WIN_WORDS = WIN_KIB * 256;
  localparam integer WL  = $clog2(WIN_WORDS);
  localparam integer CW  = $clog2(MAX_CTX);
  localparam integer AW  = CW + WL;
  localparam integer NRD = (VEC_MODE == 1) ? 2 : 1;
  // O6: the datapath of the mode a build does NOT use is gated by these constants so synthesis removes it. Without this the
  // unreachable sequential states stay in the netlist and static timing, which cannot know they are unreachable, reports their
  // multiplier->adder paths as critical (profile finding, see reports/optimisation-log.md).
  localparam VSEQ = (VEC_MODE == 0), VPIPE = (VEC_MODE == 1), TSEQ = (TEN_MODE == 0), TPIPE = (TEN_MODE == 1);
  localparam integer LD_N = (NRD == 2) ? 4 : 8;
  localparam [31:0] WIN_WORDS_C = WIN_WORDS;
  localparam [8:0]  BURST_C = 9'(DMA_BURST);
  localparam [3:0]  LD_N4 = 4'(LD_N);

  localparam [4:0] E_IDLE = 5'd0,  E_SCRUB = 5'd1,  E_H_REQ = 5'd2,  E_H_WAIT = 5'd3, E_D_RUN = 5'd4,
                   E_VS_A = 5'd5,  E_VS_B = 5'd6,   E_VS_C = 5'd7,   E_VS_D = 5'd8,
                   E_VP_RUN = 5'd9, E_V_FIN = 5'd10,
                   E_T_LD = 5'd11, E_TS_C0 = 5'd12, E_TS_C1 = 5'd13, E_TS_C2 = 5'd14, E_TS_M = 5'd15,
                   E_TS_W = 5'd16, E_TP_RUN = 5'd17, E_T_NEXT = 5'd18, E_DONE = 5'd19;
  localparam [2:0] O_NONE = 3'd0, O_H2D = 3'd1, O_D2H = 3'd2, O_VEC = 3'd3, O_TEN = 3'd4, O_SCRUB = 3'd5;

  reg [4:0]    st;
  reg [2:0]    opr;
  reg [CW-1:0] ctxr;
  reg [WL-1:0] pa, pb, pc, pr, ra, rb;
  reg [31:0]   cnt, cnt2;
  reg [63:0]   hptr;
  reg [2:0]    res_status, vop;
  reg          acc_flag;
  reg [8:0]    beats;
  reg          d_err;

  // VEC state
  reg [31:0]   opa;
  reg signed [31:0] vacc;
  reg          v0, v1, v2;
  reg [31:0]   res_q;
  // TEN state
  reg [127:0]  a_reg, b_reg;
  reg [3:0]    ld_i, i0, i1;
  reg [3:0]    o_i;
  reg [1:0]    kk;
  reg signed [31:0] cacc;
  reg [4:0]    t_iss;
  reg [4:0]    wcnt;
  reg          p0_v, p1_v, p2_v, p3_v, v1b;
  reg [31:0]   a_q, b_q, c_q;
  reg signed [31:0] dot_q;
  reg signed [15:0] pq0, pq1, pq2, pq3;
  reg          v2b, p4_v;
  reg [31:0]   c_q2;
  reg [3:0]    p0_o;
  reg [31:0]   t_opa, t_opb;

  assign eng_busy = (st != E_IDLE);
  assign op_oh    = {opr == O_SCRUB, opr == O_TEN, opr == O_VEC, opr == O_D2H, opr == O_H2D} & {5{eng_busy}};
  assign rd_stall = (st == E_H_WAIT) && !r_valid && !r_err;
  assign wr_stall = e_mwr_req && !mwr_ready;

  // ---- device memory ----------------------------------------------------------
  reg              wr_en;
  reg  [AW-1:0]    wr_addr;
  reg  [31:0]      wr_data;
  reg              rd0_en;
  wire [31:0]      rd0_data, rd1_data;
  wire [AW-1:0]    rd0_addr = (MUT == 17 && st == E_D_RUN) ? {ctxr ^ {{(CW-1){1'b0}}, 1'b1}, ra} : {ctxr, ra};
  wire [AW-1:0]    rd1_addr = {ctxr, rb};
  sfg1_devmem #(.DEPTH(1 << AW), .NRD(NRD)) u_mem (
    .clk(clk), .wr_en(wr_en), .wr_addr(wr_addr), .wr_data(wr_data),
    .rd0_en(rd0_en), .rd0_addr(rd0_addr), .rd0_data(rd0_data),
    .rd1_en(1'b1),   .rd1_addr(rd1_addr), .rd1_data(rd1_data));

  assign dbg_eng = {{(24-AW){1'b0}}, rd1_addr, {(24-AW){1'b0}}, rd0_addr, {(24-AW){1'b0}}, wr_addr, wr_en,
                    8'd0 | {{(8-CW){1'b0}}, ctxr}, st, eng_busy};

  // ---- datapath units -----------------------------------------------------------
  wire [31:0]        alu_a = (VEC_MODE == 1) ? ((PIPE != 0) ? a_q : rd0_data) : opa;
  wire [31:0]        alu_b = (VEC_MODE == 1) ? ((PIPE != 0) ? b_q : rd1_data) : rd0_data;
  wire [31:0]        alu_y;
  wire signed [31:0] alu_dot;
  wire signed [15:0] ap0, ap1, ap2, ap3;
  sfg1_vecalu #(.MUT(MUT)) u_valu (.op(vop), .a(alu_a), .b(alu_b), .y(alu_y), .dot(alu_dot), .pr0(ap0), .pr1(ap1), .pr2(ap2), .pr3(ap3));

  wire [31:0]        td_y;
  wire signed [31:0] td_dot;
  wire signed [15:0] tp0, tp1, tp2, tp3;
  sfg1_vecalu #(.MUT(0)) u_tdot (.op(3'd7), .a(t_opa), .b(t_opb), .y(td_y), .dot(td_dot), .pr0(tp0), .pr1(tp1), .pr2(tp2), .pr3(tp3));
  // PIPE=2: sums of REGISTERED products (the adder tree starts from flops, not from the multiplier outputs)
  wire signed [31:0] sum_pq = ({{16{pq0[15]}}, pq0} + {{16{pq1[15]}}, pq1}) + ({{16{pq2[15]}}, pq2} + {{16{pq3[15]}}, pq3});     // TEN
  // VEC DOT8 path of PIPE=2 (identical logic; separate wire only so MUTANT 18 "DOT8 omits lane 3" exists in this datapath too -- with MUT=0 synthesis merges them)
  wire signed [31:0] sum_pq_v = (MUT == 18) ? (({{16{pq0[15]}}, pq0} + {{16{pq1[15]}}, pq1}) + {{16{pq2[15]}}, pq2})
                                            : (({{16{pq0[15]}}, pq0} + {{16{pq1[15]}}, pq1}) + ({{16{pq2[15]}}, pq2} + {{16{pq3[15]}}, pq3}));

  // TEN sequential multiplier operands
  wire [1:0] sr = o_i[3:2];
  wire [1:0] sq = o_i[1:0];
  wire signed [7:0] sa = a_reg[{sr, kk, 3'b000} +: 8];                 // A[r][k]
  wire signed [7:0] sb = b_reg[{kk, sq, 3'b000} +: 8];                 // B[k][q]
  wire signed [15:0] sprod = sa * sb;

  // H2D burst length: min(words left, DMA_BURST, words to the next 4 KiB boundary)
  wire [12:0] wtb13 = 13'd4096 - {1'b0, hptr[11:0]} + 13'd3;
  wire [10:0] wtb   = wtb13[12:2];
  wire [8:0]  cnt_c = (cnt[31:9] != 23'd0) ? 9'h1ff : cnt[8:0];
  wire [8:0]  nb_a  = (cnt_c < BURST_C) ? cnt_c : BURST_C;
  wire [8:0]  nb    = (MUT == 19) ? nb_a : ((wtb < {2'b00, nb_a}) ? wtb[8:0] : nb_a);   // MUTANT 19: 4 KiB rule ignored

  wire d_can_load = !e_mwr_req || mwr_ready;
  wire d_err_now  = d_err | (e_mwr_req && mwr_ready && mwr_err);
  wire is_dot     = (vop == SFG1_VEC_DOT8);

  // ---- memory port muxing ---------------------------------------------------------
  always @* begin
    wr_en = 1'b0; wr_addr = {ctxr, pc}; wr_data = 32'd0;
    rd0_en = 1'b1;
    case (st)
      E_SCRUB:  begin wr_en = 1'b1; wr_addr = {ctxr, pc}; wr_data = 32'd0; end
      E_H_WAIT: begin wr_en = r_valid && !r_err && !(MUT == 16 && cnt == 32'd1);   // MUTANT 16: last word dropped
                     wr_addr = {ctxr, pa}; wr_data = r_data; end
      E_D_RUN:  begin rd0_en = d_can_load; end
      E_VS_D:   begin wr_en = VSEQ && !is_dot; wr_addr = {ctxr, pc}; wr_data = VSEQ ? alu_y : 32'd0; end
      E_VP_RUN: begin wr_en = VPIPE && v2 && !is_dot; wr_addr = {ctxr, pc}; wr_data = VPIPE ? res_q : 32'd0; end
      E_V_FIN:  begin wr_en = 1'b1; wr_addr = {ctxr, pc}; wr_data = vacc; end
      E_TS_W:   begin wr_en = TSEQ; wr_addr = {ctxr, pc}; wr_data = TSEQ ? cacc : 32'd0; end
      E_TP_RUN: begin wr_en = TPIPE && ((PIPE == 2) ? p4_v : (PIPE != 0) ? p3_v : p2_v); wr_addr = {ctxr, pc}; wr_data = TPIPE ? res_q : 32'd0; end
      default: ;
    endcase
  end

  // ---- control FSM --------------------------------------------------------------------
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= E_IDLE; opr <= O_NONE; ctxr <= 0; pa <= 0; pb <= 0; pc <= 0; pr <= 0; ra <= 0; rb <= 0;
      cnt <= 0; cnt2 <= 0; hptr <= 0; res_status <= 0; vop <= 0; acc_flag <= 0; beats <= 0; d_err <= 0;
      opa <= 0; vacc <= 0; v0 <= 0; v1 <= 0; v2 <= 0; res_q <= 0; a_reg <= 0; b_reg <= 0;
      ld_i <= 0; i0 <= 0; i1 <= 0; o_i <= 0; kk <= 0; cacc <= 0; t_iss <= 0; wcnt <= 0;
      p0_v <= 0; p1_v <= 0; p2_v <= 0; p3_v <= 0; p4_v <= 0; v1b <= 0; v2b <= 0; a_q <= 0; b_q <= 0; c_q <= 0; c_q2 <= 0; dot_q <= 0; pq0 <= 0; pq1 <= 0; pq2 <= 0; pq3 <= 0; p0_o <= 0; t_opa <= 0; t_opb <= 0;
      eng_done <= 0; eng_status <= 0;
      e_mrd_req <= 0; e_mrd_addr <= 0; e_mrd_len <= 1; e_mwr_req <= 0; e_mwr_addr <= 0; e_mwr_data <= 0;
    end else begin
      eng_done  <= 1'b0;
      e_mrd_req <= 1'b0;
      if (e_mwr_req && mwr_ready) e_mwr_req <= 1'b0;

      case (st)
        E_IDLE: if (eng_start) begin
          ctxr <= eng_ctx[CW-1:0];
          pa <= eng_a[WL+1:2]; pb <= eng_b[WL+1:2]; pc <= eng_c[WL+1:2];
          hptr <= eng_host_addr; vop <= eng_exec_op[2:0]; acc_flag <= eng_flags[0];
          res_status <= SFG1_ST_OK; vacc <= 0; d_err <= 1'b0;
          v0 <= 0; v1 <= 0; v2 <= 0; p0_v <= 0; p1_v <= 0; p2_v <= 0; p3_v <= 0; p4_v <= 0; v1b <= 0; v2b <= 0;
          case (eng_opcode)
            SFG1_OP_SCRUB:   begin opr <= O_SCRUB; pc <= 0; cnt <= WIN_WORDS_C; st <= E_SCRUB; end
            SFG1_OP_DMA_H2D: begin opr <= O_H2D; cnt <= eng_len[33:2]; st <= E_H_REQ; end
            SFG1_OP_DMA_D2H: begin opr <= O_D2H; cnt <= eng_len[33:2]; cnt2 <= eng_len[33:2]; st <= E_D_RUN; end
            SFG1_OP_VEC:     begin opr <= O_VEC; cnt <= eng_len[31:0]; cnt2 <= eng_len[31:0];
                                   st <= (VEC_MODE == 1) ? E_VP_RUN : E_VS_A; end
            SFG1_OP_TEN:     begin opr <= O_TEN; cnt <= eng_len[31:0]; ld_i <= 0; st <= E_T_LD; end
            default:         begin opr <= O_NONE; res_status <= SFG1_ST_BAD_OPCODE; st <= E_DONE; end
          endcase
        end

        // ---------------- SCRUB: zero the whole window of the context ----------------
        E_SCRUB: begin
          pc <= pc + 1'b1; cnt <= cnt - 32'd1;
          if (cnt == ((MUT == 13) ? (WIN_WORDS_C >> 1) : 32'd1)) st <= E_DONE;   // MUTANT 13: half scrub
        end

        // ---------------- DMA_H2D ----------------------------------------------------
        E_H_REQ: begin
          e_mrd_req <= 1'b1; e_mrd_addr <= hptr; e_mrd_len <= nb; beats <= nb; st <= E_H_WAIT;
        end
        E_H_WAIT:
          if (r_err) begin res_status <= SFG1_ST_DMA_ERROR; st <= E_DONE; end
          else if (r_valid) begin
            pa <= pa + 1'b1; hptr <= hptr + 64'd4; cnt <= cnt - 32'd1; beats <= beats - 9'd1;
            if (cnt == 32'd1) st <= E_DONE;
            else if (beats == 9'd1) st <= E_H_REQ;
          end

        // ---------------- DMA_D2H: read -> output register (valid/ready) ----------------
        E_D_RUN: begin
          if (e_mwr_req && mwr_ready && mwr_err) d_err <= 1'b1;
          if (d_can_load) begin
            e_mwr_req <= v1 && !d_err_now;         // v1 = "rd0_data holds the next word"; stop after a fault
            if (v1 && !d_err_now) begin
              e_mwr_addr <= hptr; e_mwr_data <= rd0_data; hptr <= hptr + 64'd4; cnt2 <= cnt2 - 32'd1;
            end
            v1 <= v0;
            if (cnt != 32'd0) begin ra <= pa; pa <= pa + 1'b1; cnt <= cnt - 32'd1; v0 <= 1'b1; end
            else v0 <= 1'b0;
          end
          if ((cnt2 == 32'd0 || d_err_now) && (!e_mwr_req || mwr_ready)) begin
            res_status <= d_err_now ? SFG1_ST_DMA_ERROR : SFG1_ST_OK;
            st <= E_DONE;
          end
        end

        // ---------------- VEC, sequential (VEC_MODE 0) -----------------------------------
        E_VS_A: begin ra <= pa; st <= E_VS_B; end
        E_VS_B: begin ra <= pb; st <= E_VS_C; end
        E_VS_C: begin opa <= rd0_data; st <= E_VS_D; end
        E_VS_D: if (VSEQ) begin
          if (is_dot) vacc <= vacc + alu_dot;
          else pc <= pc + 1'b1;
          pa <= pa + 1'b1; pb <= pb + 1'b1; cnt <= cnt - 32'd1;
          if (cnt == 32'd1) st <= is_dot ? E_V_FIN : E_DONE;
          else st <= E_VS_A;
        end

        // ---------------- VEC, pipelined, two read ports (VEC_MODE 1) --------------------
        E_VP_RUN: if (VPIPE) begin
          if (cnt != 32'd0) begin ra <= pa; rb <= pb; pa <= pa + 1'b1; pb <= pb + 1'b1; cnt <= cnt - 32'd1; v0 <= 1'b1; end
          else v0 <= 1'b0;
          v1 <= v0;
          if (PIPE != 0) begin                       // stage: register BRAM outputs; stage: multiply/ALU -> registers; stage: accumulate
            if (v1) begin a_q <= rd0_data; b_q <= rd1_data; end
            v1b <= v1;
            if (v1b) begin res_q <= alu_y; if (PIPE == 2) begin pq0 <= ap0; pq1 <= ap1; pq2 <= ap2; pq3 <= ap3; end else dot_q <= alu_dot; end
            v2 <= v1b;
            if (PIPE == 2) begin                  // dot product: register products, sum them one stage later, accumulate one stage after that
              v2b <= v2;
              if (v2) dot_q <= sum_pq_v;
              if (v2b) vacc <= vacc + dot_q;
            end else if (v2) vacc <= vacc + dot_q;
          end else begin
            if (v1) begin res_q <= alu_y; vacc <= vacc + alu_dot; end
            v2 <= v1;
          end
          if (v2 && !is_dot) pc <= pc + 1'b1;
          if (cnt == 32'd0 && !v0 && !v1 && !v1b && !v2 && !v2b) st <= is_dot ? E_V_FIN : E_DONE;
        end
        E_V_FIN: st <= E_DONE;

        // ---------------- TEN: load A and B tile registers ---------------------------------
        E_T_LD: begin
          if (ld_i < LD_N4) begin
            if (NRD == 2) begin ra <= pa + {{(WL-2){1'b0}}, ld_i[1:0]}; rb <= pb + {{(WL-2){1'b0}}, ld_i[1:0]}; end
            else ra <= ld_i[2] ? (pb + {{(WL-2){1'b0}}, ld_i[1:0]}) : (pa + {{(WL-2){1'b0}}, ld_i[1:0]});
            v0 <= 1'b1; i0 <= ld_i; ld_i <= ld_i + 4'd1;
          end else v0 <= 1'b0;
          v1 <= v0; i1 <= i0;
          if (v1) begin
            if (NRD == 2) begin
              a_reg[{i1[1:0], 5'd0} +: 32] <= rd0_data; b_reg[{i1[1:0], 5'd0} +: 32] <= rd1_data;
            end else if (i1[2]) b_reg[{i1[1:0], 5'd0} +: 32] <= rd0_data;
            else                a_reg[{i1[1:0], 5'd0} +: 32] <= rd0_data;
          end
          if (ld_i == LD_N4 && !v0) begin
            o_i <= 0; kk <= 0; t_iss <= 0; wcnt <= 0; pr <= pc; p0_v <= 0; p1_v <= 0; p2_v <= 0; p3_v <= 0; p4_v <= 0; v1 <= 0;
            st <= (TEN_MODE == 1) ? E_TP_RUN : E_TS_C0;
          end
        end

        // ---------------- TEN, sequential, one multiplier (TEN_MODE 0) -------------------------
        E_TS_C0: if (acc_flag && MUT != 14) begin ra <= pc; st <= E_TS_C1; end
                 else begin cacc <= 0; kk <= 0; st <= E_TS_M; end
        E_TS_C1: st <= E_TS_C2;
        E_TS_C2: begin cacc <= rd0_data; kk <= 0; st <= E_TS_M; end
        E_TS_M: if (TSEQ) begin
          cacc <= cacc + {{16{sprod[15]}}, sprod};
          kk <= kk + 2'd1;
          if (kk == 2'd3) st <= E_TS_W;
        end
        E_TS_W: begin
          pc <= pc + 1'b1; o_i <= o_i + 4'd1;
          if (o_i == 4'd15) st <= E_T_NEXT; else st <= E_TS_C0;
        end

        // ---------------- TEN, pipelined, four multipliers, 1 output/cycle (TEN_MODE 1) ---------
        E_TP_RUN: if (TPIPE) begin
          // stage 0: issue the old-C read (accumulate mode) for output t_iss
          if (t_iss < 5'd16) begin
            if (acc_flag && MUT != 14) begin ra <= pr; pr <= pr + 1'b1; end
            p0_v <= 1'b1; p0_o <= t_iss[3:0]; t_iss <= t_iss + 5'd1;
          end else p0_v <= 1'b0;
          // stage 1: operand select (row r of A, column q of B as 4 bytes)
          p1_v <= p0_v;
          if (p0_v) begin
            t_opa <= a_reg[{p0_o[3:2], 5'd0} +: 32];
            t_opb <= {b_reg[{2'd3, p0_o[1:0], 3'd0} +: 8], b_reg[{2'd2, p0_o[1:0], 3'd0} +: 8],
                      b_reg[{2'd1, p0_o[1:0], 3'd0} +: 8], b_reg[{2'd0, p0_o[1:0], 3'd0} +: 8]};
          end
          // stage 2: multiply-accumulate (+ old C when accumulating)
          p2_v <= p1_v;
          if (PIPE == 2) begin                       // s2: four products + old-C into registers; s3: sum; s4: add old C; s5: write
            if (p1_v) begin pq0 <= tp0; pq1 <= tp1; pq2 <= tp2; pq3 <= tp3; c_q <= (acc_flag && MUT != 14) ? rd0_data : 32'd0; end
            p3_v <= p2_v;
            if (p2_v) begin dot_q <= sum_pq; c_q2 <= c_q; end
            p4_v <= p3_v;
            if (p3_v) res_q <= dot_q + c_q2;
            if (p4_v) begin pc <= pc + 1'b1; wcnt <= wcnt + 5'd1; if (wcnt == 5'd15) st <= E_T_NEXT; end
          end else if (PIPE != 0) begin              // stage 2: dot product and old-C into registers; stage 3: add; stage 4: write
            if (p1_v) begin dot_q <= td_dot; c_q <= (acc_flag && MUT != 14) ? rd0_data : 32'd0; end
            p3_v <= p2_v;
            if (p2_v) res_q <= dot_q + c_q;
            if (p3_v) begin pc <= pc + 1'b1; wcnt <= wcnt + 5'd1; if (wcnt == 5'd15) st <= E_T_NEXT; end
          end else begin
            if (p1_v) res_q <= td_dot + ((acc_flag && MUT != 14) ? rd0_data : 32'd0);
            // stage 3: write
            if (p2_v) begin pc <= pc + 1'b1; wcnt <= wcnt + 5'd1; if (wcnt == 5'd15) st <= E_T_NEXT; end
          end
        end

        E_T_NEXT: begin
          pa <= pa + 4; pb <= pb + 4; cnt <= cnt - 32'd1; ld_i <= 0; v0 <= 0; v1 <= 0;
          if (cnt == 32'd1) st <= E_DONE; else st <= E_T_LD;
        end

        E_DONE: begin eng_done <= 1'b1; eng_status <= res_status; st <= E_IDLE; opr <= O_NONE; end
        default: st <= E_IDLE;
      endcase

      if (eng_abort && MUT != 25) begin            // reset: drop the command, no completion (MUTANT 25: ignored)
        st <= E_IDLE; opr <= O_NONE; eng_done <= 1'b0; e_mwr_req <= 1'b0; e_mrd_req <= 1'b0;
        v0 <= 0; v1 <= 0; v2 <= 0; p0_v <= 0; p1_v <= 0; p2_v <= 0; p3_v <= 0; p4_v <= 0; v1b <= 0; v2b <= 0;
      end
    end
  end
endmodule
