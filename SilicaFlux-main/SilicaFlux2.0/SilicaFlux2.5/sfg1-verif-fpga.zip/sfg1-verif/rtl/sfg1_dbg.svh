// SPDX-License-Identifier: GPL-2.0-only
// Debug tap bus layouts (read-only observation of internal state for the protocol checker and
// formal harnesses). Always present as module outputs; unconnected outputs cost nothing.
localparam integer DBGF_ENABLE = 0,   DBGF_HALTED = 1,  DBGF_FATAL = 2,   DBGF_RESET = 3,   DBGF_PHASE = 4;
localparam integer DBGF_IRQST  = 5,   DBGF_IRQMSK  = 8,  DBGF_STATE = 11;                    // 3,3,4 bits
localparam integer DBGF_SQN    = 15,  DBGF_CQN     = 31, DBGF_SQHEAD = 47,  DBGF_SQTAIL = 63;  // 16 bits each
localparam integer DBGF_CQHEAD = 79,  DBGF_CQTAIL  = 95;                                      // 16 bits each
localparam integer DBGF_SQBASE = 111, DBGF_CQBASE  = 175;                                     // 64 bits each
localparam integer DBGF_CMDOP  = 239, DBGF_CMDHOST = 255, DBGF_CMDLEN = 319;                  // 16,64,64
localparam integer DBGF_ABORT  = 383, DBGF_W = 384;
localparam integer DBGE_BUSY = 0, DBGE_ST = 1, DBGE_CTX = 6, DBGE_WREN = 14;                  // 1,5,8,1
localparam integer DBGE_WRADDR = 15, DBGE_RD0ADDR = 39, DBGE_RD1ADDR = 63, DBGE_W = 87;        // 24 bits each
