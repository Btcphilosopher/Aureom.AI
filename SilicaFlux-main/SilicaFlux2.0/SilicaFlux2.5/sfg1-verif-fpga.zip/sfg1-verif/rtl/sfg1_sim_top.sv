// SPDX-License-Identifier: GPL-2.0-only
// Simulation top: the device core plus the protocol checker (sfg1_proto_chk). Not synthesised.
`timescale 1ns/1ps
module sfg1_sim_top #(
  parameter integer MAX_CTX = 4, parameter integer MAX_QENT = 64, parameter integer WIN_KIB = 4,
  parameter integer RESET_CYCLES = 6, parameter integer FETCH_BURST = 0, parameter integer DMA_BURST = 1,
  parameter integer VEC_MODE = 0, parameter integer TEN_MODE = 0, parameter integer PIPE = 0, parameter integer PERF_EN = 1,
  parameter integer ORDER_BUG = 0, parameter integer MUT = 0
) (
  input  wire        clk, input wire rst_n,
  input  wire        csr_wr, input wire [11:0] csr_addr, input wire [31:0] csr_wdata, output wire [31:0] csr_rdata,
  output wire        mrd_req, output wire [63:0] mrd_addr, output wire [8:0] mrd_len, output wire [3:0] mrd_tag,
  input  wire        mrd_valid, input wire [31:0] mrd_data, input wire mrd_err, input wire [3:0] mrd_rtag,
  output wire        mwr_req, output wire [63:0] mwr_addr, output wire [31:0] mwr_data,
  input  wire        mwr_ready, input wire mwr_err,
  output wire        irq_msg,
  output wire [15:0] chk_fail_mask, output wire [15:0] chk_fail_cnt
);
  wire [383:0] dbg_fe; wire [86:0] dbg_eng;
  sfg1_core #(.MAX_CTX(MAX_CTX), .MAX_QENT(MAX_QENT), .WIN_KIB(WIN_KIB), .RESET_CYCLES(RESET_CYCLES),
              .FETCH_BURST(FETCH_BURST), .DMA_BURST(DMA_BURST), .VEC_MODE(VEC_MODE), .TEN_MODE(TEN_MODE), .PIPE(PIPE),
              .PERF_EN(PERF_EN), .ORDER_BUG(ORDER_BUG), .MUT(MUT)) u_core (
    .clk(clk), .rst_n(rst_n), .csr_wr(csr_wr), .csr_addr(csr_addr), .csr_wdata(csr_wdata), .csr_rdata(csr_rdata),
    .mrd_req(mrd_req), .mrd_addr(mrd_addr), .mrd_len(mrd_len), .mrd_tag(mrd_tag),
    .mrd_valid(mrd_valid), .mrd_data(mrd_data), .mrd_err(mrd_err), .mrd_rtag(mrd_rtag),
    .mwr_req(mwr_req), .mwr_addr(mwr_addr), .mwr_data(mwr_data), .mwr_ready(mwr_ready), .mwr_err(mwr_err),
    .irq_msg(irq_msg), .dbg_fe(dbg_fe), .dbg_eng(dbg_eng));
  sfg1_proto_chk #(.MAX_CTX(MAX_CTX), .WIN_KIB(WIN_KIB)) u_chk (
    .clk(clk), .rst_n(rst_n), .csr_wr(csr_wr), .csr_addr(csr_addr),
    .mrd_req(mrd_req), .mrd_addr(mrd_addr), .mrd_len(mrd_len),
    .mwr_req(mwr_req), .mwr_addr(mwr_addr), .mwr_data(mwr_data), .mwr_ready(mwr_ready),
    .irq_msg(irq_msg), .dbg_fe(dbg_fe), .dbg_eng(dbg_eng),
    .fail_mask(chk_fail_mask), .fail_cnt(chk_fail_cnt));
endmodule
