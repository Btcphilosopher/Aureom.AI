// SPDX-License-Identifier: GPL-2.0-only
// -----------------------------------------------------------------------------
// SF-G1 host front-end (DRAFT v1.0 contract) -- DERIVED from the driver package's reference RTL
// vendor/sfg1-driver/rtl/sfg1_host_frontend.sv (SHA-256 in vendor/SHA256SUMS). Deltas, all
// documented in docs/01-contract-interpretation.md section "Front-end deltas":
//   D1  synthesizable subset Yosys 0.71 accepts: no package import, no blocking-assign state in
//       the clocked process (event wires are computed in an always @* block instead)
//   D2  optional burst SQ fetch (FETCH_BURST=1: one 16-beat read instead of 16 single reads)
//   D3  mrd_err ends a fetch with status FETCH_ERROR (the reference had no error input)
//   D4  mwr_ready back-pressure on CQE writes; the interrupt cause is published only after the
//       phase dword (dw3) has been ACCEPTED (rule R3 with a stalled bus)
//   D5  all BAD_ARGS / BOUNDS / BAD_OPCODE decisions come from sfg1_cmdchk (the reference
//       completed a NOP with non-zero fields as OK; contract 4.1 and the mock say BAD_ARGS)
//   D6  mrd_len / fe_state outputs (burst length, profiling)
// Ordering guarantees kept from the reference:
//   R3  dw0,dw1,dw2 then dw3={status_phase,cid} LAST; only then IRQ_STATUS / interrupt message
//   R6  message when (IRQ_STATUS & IRQ_MASK) goes 0->non-zero, and again after a W1C/mask write
//       that leaves it non-zero
// MUT / ORDER_BUG are verification mutants (tests must FAIL on them); 0 in every real build.
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
module sfg1_frontend #(
  parameter integer MAX_CTX      = 4,
  parameter integer MAX_QENT     = 64,
  parameter integer WIN_KIB      = 16,
  parameter integer RESET_CYCLES = 6,
  parameter integer FETCH_BURST  = 0,
  parameter integer ORDER_BUG    = 0,
  parameter integer MUT          = 0
) (
  input  wire        clk,
  input  wire        rst_n,

  // BAR0 register interface: writes apply on the clock edge, reads are combinational
  input  wire        csr_wr,
  input  wire [11:0] csr_addr,
  input  wire [31:0] csr_wdata,
  output reg  [31:0] csr_rdata,

  // host-memory master (read: request pulse, then mrd_len beats; write: valid/ready)
  output reg         mrd_req,
  output reg  [63:0] mrd_addr,
  output reg  [8:0]  mrd_len,
  input  wire        mrd_valid,
  input  wire [31:0] mrd_data,
  input  wire        mrd_err,
  output reg         mwr_req,
  output reg  [63:0] mwr_addr,
  output reg  [31:0] mwr_data,
  input  wire        mwr_ready,
  output reg         irq_msg,

  // execution engine (only validated commands are started)
  output reg         eng_start,
  output wire [15:0] eng_opcode,
  output wire [15:0] eng_ctx,
  output wire [15:0] eng_flags,
  output wire [31:0] eng_exec_op,
  output wire [63:0] eng_host_addr,
  output wire [63:0] eng_len,
  output wire [63:0] eng_a,
  output wire [63:0] eng_b,
  output wire [63:0] eng_c,
  input  wire        eng_done,
  input  wire [2:0]  eng_status,
  output reg         eng_abort,

  output wire [3:0]  fe_state,
  output wire [383:0] dbg_fe                   // layout: sfg1_dbg.svh
);
  `include "sfg1_defs.svh"
  `include "sfg1_dbg.svh"

  localparam [3:0] S_IDLE = 4'd0, S_RD_REQ = 4'd1, S_RD_WAIT = 4'd2, S_DECODE = 4'd3, S_EXEC = 4'd4,
                   S_WB0 = 4'd5, S_WB1 = 4'd6, S_WB2 = 4'd7, S_WB3 = 4'd8, S_COMMIT = 4'd9;
  localparam integer WIN_B = WIN_KIB * 1024;
  localparam [15:0] LIM_Q = 16'(MAX_QENT);
  localparam [15:0] LIM_C = 16'(MAX_CTX);
  localparam [15:0] LIM_W = 16'(WIN_KIB);
  localparam [7:0]  RST_CNT = 8'(RESET_CYCLES);
  localparam [31:0] DEVMEM_BYTES = MAX_CTX * WIN_KIB * 1024;

  reg [3:0] state;
  assign fe_state = state;

  // ---- architectural state --------------------------------------------------
  reg        enable, halted, fatal, reset_active;
  reg [7:0]  reset_cnt;
  reg [7:0]  last_err;
  // R9: the queue base/size registers are SAMPLED on ENABLE 0 -> 1. sq_base_r.. are what the host reads and writes; sq_base..
  // are the sampled copies every datapath (fetch address, CQE address, wrap masks, the checker's view) uses. Without the copies,
  // a host that clears ENABLE while a fetch is in flight and then reprograms SQ_ENTRIES moves the fetch window under that fetch
  // (found by formal on this block, docs/03 finding F1).
  reg [63:0] sq_base_r, cq_base_r, sq_base, cq_base;
  reg [31:0] sq_n_r, cq_n_r, sq_n, cq_n;
  reg [15:0] sq_tail, sq_head, cq_head, cq_tail;
  reg        cq_phase;
  reg [2:0]  irq_status, irq_mask;
  reg [31:0] scratch, done_count, err_count, heartbeat;

  // ---- command latch (64-byte SQ entry as 16 little-endian dwords) -----------
  reg [511:0] ent;
  reg [3:0]   rd_idx;
  reg [2:0]   status;
  reg         fetch_err;

  wire [31:0] e0  = ent[ 31:  0], e1  = ent[ 63: 32], e2  = ent[ 95: 64], e3  = ent[127: 96];
  wire [31:0] e4  = ent[159:128], e5  = ent[191:160], e6  = ent[223:192], e7  = ent[255:224];
  wire [31:0] e8  = ent[287:256], e9  = ent[319:288], e10 = ent[351:320], e11 = ent[383:352];
  wire [31:0] e12 = ent[415:384], e13 = ent[447:416], e14 = ent[479:448], e15 = ent[511:480];

  assign eng_opcode    = e0[15:0];
  assign eng_ctx       = e0[31:16];
  assign eng_flags     = e1[31:16];
  assign eng_exec_op   = e2;
  assign eng_host_addr = {e5, e4};
  assign eng_len       = {e7, e6};
  assign eng_a         = {e9, e8};
  assign eng_b         = {e11, e10};
  assign eng_c         = {e13, e12};

  wire [15:0] cmd_op  = e0[15:0];
  wire [15:0] cmd_ctx = fetch_err ? 16'd0   : e0[31:16];
  wire [15:0] cmd_cid = fetch_err ? sq_head : e1[15:0];      // D3: no entry to echo -> slot index

  wire [2:0] chk_status;
  sfg1_cmdchk #(.WIN_B(WIN_B), .MUT(MUT)) u_chk (
    .op(cmd_op), .flags(eng_flags), .exec_op(eng_exec_op), .host_addr(eng_host_addr),
    .len(eng_len), .a(eng_a), .b(eng_b), .c(eng_c), .status(chk_status));

  wire [15:0] sq_mask      = sq_n[15:0] - 16'd1;
  wire [15:0] cq_mask      = cq_n[15:0] - 16'd1;
  wire [15:0] sq_head_next = (sq_head + 16'd1) & sq_mask;
  wire [15:0] cq_tail_next = (cq_tail + 16'd1) & cq_mask;

  function queue_cfg_ok(input [31:0] s, input [31:0] c);
    begin
      queue_cfg_ok = (s >= 32'd16) && (s <= MAX_QENT) && ((s & (s - 32'd1)) == 32'd0) &&
                     (c >= s) && (c <= MAX_QENT) && ((c & (c - 32'd1)) == 32'd0);
    end
  endfunction

  // CQE dwords. dw3 = {status_phase, cid}; status_phase = {status, phase} (contract section 4.2)
  function [31:0] cqe_dw(input [1:0] dw);
    begin
      case (dw)
        0:       cqe_dw = 32'd0;
        1:       cqe_dw = 32'd0;
        2:       cqe_dw = {cmd_ctx, sq_head_next};
        default: cqe_dw = {12'd0, status, cq_phase, cmd_cid};
      endcase
    end
  endfunction
  function [1:0] dw_of(input [1:0] k);          // ORDER_BUG 1: phase dword written first
    begin
      dw_of = (ORDER_BUG == 1) ? (k + 2'd3) : k;
    end
  endfunction

  // ---- combinational events ---------------------------------------------------
  wire wb_stall   = mwr_req && !mwr_ready;
  wire commit_go  = (state == S_COMMIT) && !wb_stall;
  wire early_irq  = (ORDER_BUG == 2) && (state == S_WB2) && !wb_stall;
  wire cqfull     = (state == S_WB0) && (cq_tail_next == cq_head) && (MUT != 22);   // MUTANT 22: R5 check off
  wire ctrl_wr    = csr_wr && (csr_addr == SFG1_REG_CTRL);
  wire do_engine_reset = ctrl_wr && csr_wdata[SFG1_CTRL_ENGINE_RESET];
  wire do_func_reset   = csr_wr && (csr_addr == SFG1_REG_RESET) && (csr_wdata == SFG1_RESET_MAGIC);
  wire en_rise    = ctrl_wr && !csr_wdata[SFG1_CTRL_ENGINE_RESET] && csr_wdata[SFG1_CTRL_ENABLE] && !enable;
  // INTERPRETATION (docs/01 I9): a queue base that is not aligned to its entry size (SQ 64 B, CQ 16 B) or whose queue would wrap past the end of the
  // 64-bit bus address space is an invalid configuration (FATAL, not enabled), like the non-power-of-two sizes R9 lists. Found by formal (docs/03 F2/F3).
  /* verilator lint_off UNUSEDSIGNAL */
  wire [64:0] sq_end_r = {1'b0, sq_base_r} + {43'd0, sq_n_r[15:0], 6'd0};     // only the carry-out (bit 64) is used
  wire [64:0] cq_end_r = {1'b0, cq_base_r} + {45'd0, cq_n_r[15:0], 4'd0};
  /* verilator lint_on UNUSEDSIGNAL */
  wire        base_ok  = (MUT == 29) || ((sq_base_r[5:0] == 6'd0) && (cq_base_r[3:0] == 4'd0) && !sq_end_r[64] && !cq_end_r[64]);   // MUTANT 29: no check
  wire en_ok      = queue_cfg_ok(sq_n_r, cq_n_r) && base_ok && !fatal && !reset_active;
  wire cfg_fatal  = en_rise && !en_ok;
  wire csr_irq_ev = csr_wr && (csr_addr == SFG1_REG_IRQ_STATUS || csr_addr == SFG1_REG_IRQ_MASK);

  reg [2:0] irq_set, irq_clr, irq_status_n, irq_mask_n;
  reg       pend_now, pend_next;
  always @* begin
    irq_set = 3'd0;
    if (commit_go || early_irq) irq_set = irq_set | (3'd1 << SFG1_IRQ_CQ);
    if (commit_go && status != SFG1_ST_OK) irq_set = irq_set | (3'd1 << SFG1_IRQ_ERROR);
    if (cqfull || cfg_fatal)    irq_set = irq_set | (3'd1 << SFG1_IRQ_FATAL);
    irq_clr = (csr_wr && csr_addr == SFG1_REG_IRQ_STATUS) ? csr_wdata[2:0] : 3'd0;
    irq_status_n = (irq_status & ~irq_clr) | irq_set;
    irq_mask_n   = (csr_wr && csr_addr == SFG1_REG_IRQ_MASK) ? csr_wdata[2:0] : irq_mask;
    pend_now  = |(irq_status & irq_mask);
    pend_next = |(irq_status_n & irq_mask_n);
  end

  // ---- CSR read mux ------------------------------------------------------------
  always @* begin
    csr_rdata = 32'h0;
    case (csr_addr)
      SFG1_REG_ID:         csr_rdata = SFG1_CHIP_ID;
      SFG1_REG_HW_VERSION: csr_rdata = 32'h0001_0000;
      SFG1_REG_CAPS:       csr_rdata = (32'd1 << SFG1_CAP_ENGINE_RESET) | (32'd1 << SFG1_CAP_FUNC_RESET) |
                                       (32'd1 << SFG1_CAP_SCRUB) | (32'd1 << SFG1_CAP_VEC) |
                                       (32'd1 << SFG1_CAP_TEN);
      SFG1_REG_LIMITS0:    csr_rdata = {LIM_Q, LIM_C};
      SFG1_REG_LIMITS1:    csr_rdata = {LIM_W, 8'd0, 8'd64};
      SFG1_REG_DEVMEM_LO:  csr_rdata = DEVMEM_BYTES;
      SFG1_REG_DEVMEM_HI:  csr_rdata = 32'h0;
      SFG1_REG_CTRL:       csr_rdata = {31'd0, enable};
      SFG1_REG_STATUS:     csr_rdata = {16'd0, last_err, 3'd0, reset_active, fatal, halted,
                                        (state != S_IDLE), !reset_active};
      SFG1_REG_IRQ_STATUS: csr_rdata = {29'd0, irq_status};
      SFG1_REG_IRQ_MASK:   csr_rdata = {29'd0, irq_mask};
      SFG1_REG_SQ_BASE_LO: csr_rdata = sq_base_r[31:0];
      SFG1_REG_SQ_BASE_HI: csr_rdata = sq_base_r[63:32];
      SFG1_REG_SQ_ENTRIES: csr_rdata = sq_n_r;
      SFG1_REG_SQ_TAIL:    csr_rdata = {16'd0, sq_tail};
      SFG1_REG_CQ_BASE_LO: csr_rdata = cq_base_r[31:0];
      SFG1_REG_CQ_BASE_HI: csr_rdata = cq_base_r[63:32];
      SFG1_REG_CQ_ENTRIES: csr_rdata = cq_n_r;
      SFG1_REG_CQ_HEAD:    csr_rdata = {16'd0, cq_head};
      SFG1_REG_SQ_HEAD:    csr_rdata = {16'd0, sq_head};
      SFG1_REG_CQ_TAIL:    csr_rdata = {16'd0, cq_tail};
      SFG1_REG_DONE_COUNT: csr_rdata = done_count;
      SFG1_REG_ERR_COUNT:  csr_rdata = err_count;
      SFG1_REG_HEARTBEAT:  csr_rdata = heartbeat;
      SFG1_REG_SCRATCH:    csr_rdata = scratch;
      default:             csr_rdata = 32'h0;
    endcase
  end


  // ---- debug taps (observation only) ----
  assign dbg_fe = {eng_abort, eng_len, eng_host_addr, eng_opcode, cq_base, sq_base, cq_tail, cq_head, sq_tail, sq_head,
                   cq_n[15:0], sq_n[15:0], state, irq_mask, irq_status, cq_phase, reset_active, fatal, halted, enable};

  wire [63:0] sq_slot_addr = sq_base + {42'd0, sq_head, 6'd0};
  wire [63:0] cq_slot_addr = cq_base + {44'd0, cq_tail, 4'd0};

  // ---- sequential logic --------------------------------------------------------
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; enable <= 1'b0; halted <= 1'b0; fatal <= 1'b0;
      reset_active <= 1'b0; reset_cnt <= 8'd0; last_err <= 8'd0;
      sq_base <= 64'd0; cq_base <= 64'd0; sq_n <= 32'd0; cq_n <= 32'd0; sq_base_r <= 64'd0; cq_base_r <= 64'd0; sq_n_r <= 32'd0; cq_n_r <= 32'd0;
      sq_tail <= 16'd0; sq_head <= 16'd0; cq_head <= 16'd0; cq_tail <= 16'd0; cq_phase <= 1'b1;
      irq_status <= 3'd0; irq_mask <= 3'd0; scratch <= 32'd0; done_count <= 32'd0; err_count <= 32'd0;
      heartbeat <= 32'd0; rd_idx <= 4'd0; status <= 3'd0; fetch_err <= 1'b0;
      mrd_req <= 1'b0; mwr_req <= 1'b0; mrd_addr <= 64'd0; mrd_len <= 9'd1;
      mwr_addr <= 64'd0; mwr_data <= 32'd0;
      eng_start <= 1'b0; eng_abort <= 1'b0; irq_msg <= 1'b0;
      ent <= 512'd0;
    end else begin
      mrd_req   <= 1'b0;
      eng_start <= 1'b0;
      eng_abort <= 1'b0;
      if (mwr_req && mwr_ready) mwr_req <= 1'b0;      // accepted; a new write may be loaded below
      if (enable) heartbeat <= heartbeat + 32'd1;
      if (MUT == 30) begin sq_base <= sq_base_r; cq_base <= cq_base_r; sq_n <= sq_n_r; cq_n <= cq_n_r; end   // MUTANT 30: queue registers not sampled (live)

      if (reset_active) begin
        if (reset_cnt == 8'd0) reset_active <= 1'b0;
        else reset_cnt <= reset_cnt - 8'd1;
      end

      // ---- command FSM ----
      case (state)
        S_IDLE:
          if (enable && !halted && !fatal && !reset_active && sq_head != sq_tail) begin
            rd_idx <= 4'd0;
            state  <= S_RD_REQ;
          end
        S_RD_REQ: begin
          mrd_req  <= 1'b1;
          if (FETCH_BURST != 0) begin
            mrd_addr <= sq_slot_addr;
            mrd_len  <= 9'd16;
          end else begin
            mrd_addr <= sq_slot_addr + {58'd0, rd_idx, 2'b00};
            mrd_len  <= 9'd1;
          end
          state    <= S_RD_WAIT;
        end
        S_RD_WAIT:
          if (mrd_err) begin                                // D3
            fetch_err <= 1'b1; status <= SFG1_ST_FETCH_ERROR; state <= S_WB0;
          end else if (mrd_valid) begin
            ent[{rd_idx, 5'd0} +: 32] <= mrd_data;
            if (rd_idx == 4'd15) state <= S_DECODE;
            else begin
              rd_idx <= rd_idx + 4'd1;
              if (FETCH_BURST == 0) state <= S_RD_REQ;      // burst mode keeps listening
            end
          end
        S_DECODE: begin
          if ((MUT == 3) ? (cmd_ctx > LIM_C) : (cmd_ctx >= LIM_C)) begin
            status <= SFG1_ST_BAD_CTX;     state <= S_WB0;
          end else if (MUT != 5 && (e3 != 32'd0 || e14 != 32'd0 || e15 != 32'd0)) begin
            status <= SFG1_ST_BAD_ARGS;    state <= S_WB0;        // reserved fields must be zero
          end else if (chk_status != SFG1_ST_OK) begin
            status <= chk_status;          state <= S_WB0;
          end else if (cmd_op == SFG1_OP_NOP) begin
            status <= SFG1_ST_OK;          state <= S_WB0;
          end else begin
            eng_start <= 1'b1;             state <= S_EXEC;
          end
        end
        S_EXEC:
          if (eng_done) begin status <= eng_status; state <= S_WB0; end

        // CQE write-back: dw0, dw1, dw2, then dw3 (phase + status) LAST (rule R3).
        S_WB0:
          if (cq_tail_next == cq_head && MUT != 22) begin   // CQ full: protocol violation by the host (R5)
            fatal <= 1'b1; state <= S_IDLE; fetch_err <= 1'b0;
          end else begin
            mwr_req <= 1'b1; mwr_addr <= cq_slot_addr + {60'd0, dw_of(2'd0), 2'b00};
            mwr_data <= cqe_dw(dw_of(2'd0));
            state <= S_WB1;
          end
        S_WB1:
          if (!wb_stall) begin
            mwr_req <= 1'b1; mwr_addr <= cq_slot_addr + {60'd0, dw_of(2'd1), 2'b00};
            mwr_data <= cqe_dw(dw_of(2'd1));
            state <= S_WB2;
          end
        S_WB2:
          if (!wb_stall) begin
            mwr_req <= 1'b1; mwr_addr <= cq_slot_addr + {60'd0, dw_of(2'd2), 2'b00};
            mwr_data <= cqe_dw(dw_of(2'd2));
            state <= S_WB3;
          end
        S_WB3:
          if (!wb_stall) begin
            mwr_req <= 1'b1; mwr_addr <= cq_slot_addr + {60'd0, dw_of(2'd3), 2'b00};
            mwr_data <= cqe_dw(dw_of(2'd3));
            state <= S_COMMIT;
          end
        S_COMMIT:
          if (!wb_stall) begin
            // dw3 has been accepted by the posted-write channel; only now publish the cause
            sq_head    <= (MUT == 27 && status != SFG1_ST_OK) ? sq_head : sq_head_next;   // MUTANT 27: sq_head not advanced on error
            cq_tail    <= cq_tail_next;
            if (cq_tail_next == 16'd0 && MUT != 1) cq_phase <= ~cq_phase;
            done_count <= done_count + 32'd1;
            fetch_err  <= 1'b0;
            if (status != SFG1_ST_OK) begin
              if (MUT != 4) halted <= 1'b1;
              err_count  <= err_count + 32'd1;
              last_err   <= {5'd0, status};
            end
            state <= S_IDLE;
          end
        default: state <= S_IDLE;
      endcase

      // ---- CSR writes ----
      if (csr_wr) begin
        case (csr_addr)
          SFG1_REG_CTRL: begin
            if (csr_wdata[SFG1_CTRL_CLEAR_HALT] && MUT != 2) halted <= 1'b0;
            if (!csr_wdata[SFG1_CTRL_ENGINE_RESET]) begin
              if (csr_wdata[SFG1_CTRL_ENABLE] && !enable) begin
                // INTERPRETATION (docs/01 I10): ENABLE 0 -> 1 is honoured only when the front-end is idle (STATUS.BUSY = 0). A write while a
                // command is still draining after ENABLE=0 is ignored (CTRL.ENABLE reads back 0) -- re-sampling the queue registers
                // under an in-flight command would move its CQE (docs/03 F3). The driver quiesces with CTRL=0, polls BUSY, else ENGINE_RESET.
                if (state != S_IDLE && MUT != 28) begin             // MUTANT 28: ENABLE accepted while a command drains
                end else if (en_ok) begin
                  enable <= 1'b1;                      // queue registers sampled on 0 -> 1 (R9)
                  sq_base <= sq_base_r; cq_base <= cq_base_r; sq_n <= sq_n_r; cq_n <= cq_n_r;
                  sq_head <= 16'd0; sq_tail <= 16'd0; cq_head <= 16'd0; cq_tail <= 16'd0; cq_phase <= 1'b1;
                end else begin
                  fatal <= 1'b1;
                end
              end else if (!csr_wdata[SFG1_CTRL_ENABLE]) begin
                enable <= 1'b0;
              end
            end
          end
          SFG1_REG_IRQ_MASK:   irq_mask <= csr_wdata[2:0];
          SFG1_REG_SQ_BASE_LO: if (!enable) sq_base_r[31:0]  <= csr_wdata;
          SFG1_REG_SQ_BASE_HI: if (!enable) sq_base_r[63:32] <= csr_wdata;
          SFG1_REG_SQ_ENTRIES: if (!enable) sq_n_r <= csr_wdata;
          SFG1_REG_CQ_BASE_LO: if (!enable) cq_base_r[31:0]  <= csr_wdata;
          SFG1_REG_CQ_BASE_HI: if (!enable) cq_base_r[63:32] <= csr_wdata;
          SFG1_REG_CQ_ENTRIES: if (!enable) cq_n_r <= csr_wdata;
          SFG1_REG_SQ_TAIL:    if (enable && sq_n != 32'd0) sq_tail <= csr_wdata[15:0] & sq_mask;
          SFG1_REG_CQ_HEAD:    if (cq_n != 32'd0) cq_head <= csr_wdata[15:0] & cq_mask;
          SFG1_REG_SCRATCH:    scratch <= csr_wdata;
          default: ;
        endcase
      end

      // ---- interrupt status / message (rule R6) ----
      irq_status <= irq_status_n;
      irq_msg    <= pend_next && (!pend_now || (csr_irq_ev && MUT != 23));   // MUTANT 23: no re-send after W1C/mask

      // ---- fatal causes ----
      if (cfg_fatal) fatal <= 1'b1;

      // ---- resets (override everything above) ----
      if (do_engine_reset || do_func_reset) begin
        reset_active <= 1'b1;
        reset_cnt    <= RST_CNT;
        enable       <= 1'b0;
        eng_abort    <= 1'b1;
        state        <= S_IDLE;
        mwr_req      <= 1'b0;                 // an aborted command writes NO completion
        fetch_err    <= 1'b0;
        sq_head <= 16'd0; sq_tail <= 16'd0; cq_head <= 16'd0; cq_tail <= 16'd0; cq_phase <= 1'b1;
        halted <= 1'b0; last_err <= 8'd0; irq_msg <= 1'b0;
        if (MUT != 6) irq_status <= 3'd0;
        if (do_func_reset) begin
          if (MUT != 26) fatal <= 1'b0;          // MUTANT 26: FATAL survives a function reset
          sq_base <= 64'd0; cq_base <= 64'd0; sq_n <= 32'd0; cq_n <= 32'd0; sq_base_r <= 64'd0; cq_base_r <= 64'd0; sq_n_r <= 32'd0; cq_n_r <= 32'd0;
          irq_mask <= 3'd0; done_count <= 32'd0; err_count <= 32'd0;
        end
      end
    end
  end
endmodule
