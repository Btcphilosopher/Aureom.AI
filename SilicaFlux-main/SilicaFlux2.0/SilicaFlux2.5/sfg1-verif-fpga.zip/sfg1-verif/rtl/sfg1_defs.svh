// SPDX-License-Identifier: GPL-2.0-only
// SF-G1 contract constants for synthesizable RTL (DRAFT v1.0 contract, see
// vendor/sfg1-driver/docs/02-hw-interface.md). Included INSIDE module bodies because the
// Yosys front end cannot parse package imports. scripts/contract_check.py compares every
// name here with kernel/sfg1_hw.h, the vendored sfg1_pkg.sv and model/sfg1_model.h.
localparam [31:0] SFG1_CHIP_ID = 32'h53464001;

localparam [11:0] SFG1_REG_ID         = 12'h000;
localparam [11:0] SFG1_REG_HW_VERSION = 12'h004;
localparam [11:0] SFG1_REG_CAPS       = 12'h008;
localparam [11:0] SFG1_REG_LIMITS0    = 12'h00c;
localparam [11:0] SFG1_REG_LIMITS1    = 12'h010;
localparam [11:0] SFG1_REG_DEVMEM_LO  = 12'h014;
localparam [11:0] SFG1_REG_DEVMEM_HI  = 12'h018;
localparam [11:0] SFG1_REG_CTRL       = 12'h020;
localparam [11:0] SFG1_REG_STATUS     = 12'h024;
localparam [11:0] SFG1_REG_RESET      = 12'h028;
localparam [11:0] SFG1_REG_IRQ_STATUS = 12'h030;
localparam [11:0] SFG1_REG_IRQ_MASK   = 12'h034;
localparam [11:0] SFG1_REG_SQ_BASE_LO = 12'h040;
localparam [11:0] SFG1_REG_SQ_BASE_HI = 12'h044;
localparam [11:0] SFG1_REG_SQ_ENTRIES = 12'h048;
localparam [11:0] SFG1_REG_SQ_TAIL    = 12'h04c;
localparam [11:0] SFG1_REG_CQ_BASE_LO = 12'h050;
localparam [11:0] SFG1_REG_CQ_BASE_HI = 12'h054;
localparam [11:0] SFG1_REG_CQ_ENTRIES = 12'h058;
localparam [11:0] SFG1_REG_CQ_HEAD    = 12'h05c;
localparam [11:0] SFG1_REG_SQ_HEAD    = 12'h060;
localparam [11:0] SFG1_REG_CQ_TAIL    = 12'h064;
localparam [11:0] SFG1_REG_DONE_COUNT = 12'h068;
localparam [11:0] SFG1_REG_ERR_COUNT  = 12'h06c;
localparam [11:0] SFG1_REG_HEARTBEAT  = 12'h070;
localparam [11:0] SFG1_REG_SCRATCH    = 12'h07c;

localparam [31:0] SFG1_RESET_MAGIC = 32'h52455345;

localparam integer SFG1_CTRL_ENABLE       = 0;
localparam integer SFG1_CTRL_ENGINE_RESET = 1;
localparam integer SFG1_CTRL_CLEAR_HALT   = 2;
localparam integer SFG1_STATUS_READY        = 0;
localparam integer SFG1_STATUS_BUSY         = 1;
localparam integer SFG1_STATUS_HALTED       = 2;
localparam integer SFG1_STATUS_FATAL        = 3;
localparam integer SFG1_STATUS_RESET_ACTIVE = 4;
localparam integer SFG1_IRQ_CQ    = 0;
localparam integer SFG1_IRQ_ERROR = 1;
localparam integer SFG1_IRQ_FATAL = 2;

localparam integer SFG1_CAP_ENGINE_RESET = 0;
localparam integer SFG1_CAP_FUNC_RESET   = 1;
localparam integer SFG1_CAP_SCRUB        = 2;
localparam integer SFG1_CAP_VEC          = 3;
localparam integer SFG1_CAP_TEN          = 4;

localparam [15:0] SFG1_OP_NOP     = 16'd0;
localparam [15:0] SFG1_OP_DMA_H2D = 16'd1;
localparam [15:0] SFG1_OP_VEC     = 16'd2;
localparam [15:0] SFG1_OP_TEN     = 16'd3;
localparam [15:0] SFG1_OP_DMA_D2H = 16'd5;
localparam [15:0] SFG1_OP_SCRUB   = 16'd6;

localparam [2:0] SFG1_ST_OK              = 3'd0;
localparam [2:0] SFG1_ST_BAD_OPCODE      = 3'd1;
localparam [2:0] SFG1_ST_BAD_CTX         = 3'd2;
localparam [2:0] SFG1_ST_ENGINE_DISABLED = 3'd3;
localparam [2:0] SFG1_ST_BOUNDS          = 3'd4;
localparam [2:0] SFG1_ST_FETCH_ERROR     = 3'd5;
localparam [2:0] SFG1_ST_DMA_ERROR       = 3'd6;
localparam [2:0] SFG1_ST_BAD_ARGS        = 3'd7;

localparam [2:0] SFG1_VEC_ADD8  = 3'd0;
localparam [2:0] SFG1_VEC_SUB8  = 3'd1;
localparam [2:0] SFG1_VEC_MAX8  = 3'd2;
localparam [2:0] SFG1_VEC_RELU8 = 3'd3;
localparam [2:0] SFG1_VEC_XOR32 = 3'd4;
localparam [2:0] SFG1_VEC_AND32 = 3'd5;
localparam [2:0] SFG1_VEC_MUL8  = 3'd6;
localparam [2:0] SFG1_VEC_DOT8  = 3'd7;

// ---- vendor extension (NOT part of the draft contract): performance counters at 0x100+ ----
localparam [11:0] SFX_REG_PERF_CTRL     = 12'h100;
localparam [11:0] SFX_REG_PERF_CYCLES   = 12'h104;
localparam [11:0] SFX_REG_PERF_BUSY     = 12'h108;
localparam [11:0] SFX_REG_PERF_CMDS     = 12'h10c;
localparam [11:0] SFX_REG_PERF_FETCH    = 12'h110;
localparam [11:0] SFX_REG_PERF_DECODE   = 12'h114;
localparam [11:0] SFX_REG_PERF_EXEC     = 12'h118;
localparam [11:0] SFX_REG_PERF_WB       = 12'h11c;
localparam [11:0] SFX_REG_PERF_OP_H2D   = 12'h120;
localparam [11:0] SFX_REG_PERF_OP_D2H   = 12'h124;
localparam [11:0] SFX_REG_PERF_OP_VEC   = 12'h128;
localparam [11:0] SFX_REG_PERF_OP_TEN   = 12'h12c;
localparam [11:0] SFX_REG_PERF_OP_SCRUB = 12'h130;
localparam [11:0] SFX_REG_PERF_RD_BEATS = 12'h134;
localparam [11:0] SFX_REG_PERF_WR_BEATS = 12'h138;
localparam [11:0] SFX_REG_PERF_RD_STALL = 12'h13c;
localparam [11:0] SFX_REG_PERF_WR_STALL = 12'h140;
localparam [11:0] SFX_REG_PERF_VERSION  = 12'h144;
