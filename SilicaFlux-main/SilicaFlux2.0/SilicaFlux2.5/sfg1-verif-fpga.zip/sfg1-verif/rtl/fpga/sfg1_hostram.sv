// SPDX-License-Identifier: GPL-2.0-only
// Host-memory STAND-IN for boards without a host link that can master memory (no PCIe): an on-chip
// dual-port RAM that plays the role of host RAM for the SF-G1 core (SQ/CQ/buffers). Port A serves
// the core's bus (tagged burst reads with error responses, posted writes with back-pressure);
// port B is the UART bridge. THIS IS NOT PCIe: it makes the core's behaviour observable on hardware
// but proves nothing about PCIe ordering or timing (docs/02-fpga-requirements-and-board-selection.md).
`timescale 1ns/1ps
module sfg1_hostram #(parameter integer WORDS = 4096) (
  input  wire        clk, input wire rst_n,
  input  wire        mrd_req, input wire [63:0] mrd_addr, input wire [8:0] mrd_len, input wire [3:0] mrd_tag,
  output wire        mrd_valid, output wire [31:0] mrd_data, output wire mrd_err, output wire [3:0] mrd_rtag,
  input  wire        mwr_req, input wire [63:0] mwr_addr, input wire [31:0] mwr_data,
  output wire        mwr_ready, output wire mwr_err,
  input  wire        b_we, input wire [$clog2(WORDS)-1:0] b_addr, input wire [31:0] b_din, output reg [31:0] b_dout
);
  localparam integer AW = $clog2(WORDS);
  // Two independent ports (core / UART bridge). They are never used on the same word at the same time
  // (the host loads and reads RAM while the core is idle), so a read/write collision is declared
  // "do not care" for the synthesiser (no_rw_check): that is what lets it use a true-dual-port block RAM.
  (* ram_style = "block", no_rw_check *) reg [31:0] mem [0:WORDS-1];
  // ---- core read machine ----
  reg        act; reg [8:0] left; reg [63:0] ptr; reg [3:0] tag;
  reg        v1, e1; reg [3:0] t1;
  wire [63:0] ptr_w = {2'b00, ptr[63:2]};
  wire        ptr_ok = (ptr[63:2] < 62'(WORDS)) && (ptr[1:0] == 2'b00);
  wire [63:0] wr_w = {2'b00, mwr_addr[63:2]};
  wire        wr_ok = (mwr_addr[63:2] < 62'(WORDS));
  assign mwr_ready = !act;                                       // reads own port A while streaming
  assign mwr_err   = mwr_req && mwr_ready && !wr_ok;
  wire        wea  = mwr_req && mwr_ready && wr_ok;
  wire [AW-1:0] addra = wea ? wr_w[AW-1:0] : ptr_w[AW-1:0];
  reg [31:0] douta;
  always @(posedge clk) begin
    if (wea) mem[addra] <= mwr_data;
    douta <= mem[addra];
  end
  always @(posedge clk) begin
    if (b_we) mem[b_addr] <= b_din;
    b_dout <= mem[b_addr];
  end
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin act <= 0; left <= 0; ptr <= 0; tag <= 0; v1 <= 0; e1 <= 0; t1 <= 0; end
    else begin
      v1 <= 1'b0; e1 <= 1'b0;
      if (mrd_req) begin act <= 1'b1; left <= mrd_len; ptr <= mrd_addr; tag <= mrd_tag; end   // a new request replaces any older burst
      else if (act) begin
        t1 <= tag;
        if (!ptr_ok) begin e1 <= 1'b1; act <= 1'b0; end          // fault ends the burst
        else begin
          v1 <= 1'b1; ptr <= ptr + 64'd4; left <= left - 9'd1;
          if (left == 9'd1) act <= 1'b0;
        end
      end
    end
  end
  assign mrd_valid = v1; assign mrd_data = douta; assign mrd_err = e1; assign mrd_rtag = t1;
endmodule
