// SPDX-License-Identifier: GPL-2.0-only
// 8N1 UART, CPB = clock cycles per bit. RX samples mid-bit with a 2-FF synchroniser.
`timescale 1ns/1ps
module sfg1_uart #(parameter integer CPB = 25) (
  input  wire       clk, input wire rst_n,
  input  wire       rxd, output reg txd,
  output reg        rx_valid, output reg [7:0] rx_data,
  input  wire       tx_start, input wire [7:0] tx_data, output wire tx_busy
);
  localparam [15:0] HALF = 16'(CPB / 2), FULL = 16'(CPB - 1);
  reg [1:0] rs; always @(posedge clk) rs <= {rs[0], rxd};
  wire rx = rs[1];
  reg [15:0] rc; reg [3:0] rb; reg rrun; reg [7:0] rsh;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin rx_valid <= 0; rrun <= 0; rc <= 0; rb <= 0; rsh <= 0; rx_data <= 0; end
    else begin
      rx_valid <= 1'b0;
      if (!rrun) begin
        if (!rx) begin rrun <= 1'b1; rc <= HALF; rb <= 4'd0; end            // start bit seen: wait half a bit
      end else if (rc != 0) rc <= rc - 16'd1;
      else begin
        rc <= FULL;
        if (rb == 4'd0) begin if (rx) rrun <= 1'b0; else rb <= 4'd1; end        // verify the start bit at its middle
        else if (rb <= 4'd8) begin rsh <= {rx, rsh[7:1]}; rb <= rb + 4'd1; end
        else begin rrun <= 1'b0; if (rx) begin rx_valid <= 1'b1; rx_data <= rsh; end end   // stop bit must be high
      end
    end
  end
  reg [15:0] tc; reg [3:0] tb; reg [9:0] tsh; reg trun;
  assign tx_busy = trun;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin txd <= 1'b1; trun <= 0; tc <= 0; tb <= 0; tsh <= 10'h3ff; end
    else if (!trun) begin
      txd <= 1'b1;
      if (tx_start) begin tsh <= {1'b1, tx_data, 1'b0}; trun <= 1'b1; tc <= FULL; tb <= 4'd0; end
    end else begin
      txd <= tsh[0];
      if (tc != 0) tc <= tc - 16'd1;
      else begin
        tc <= FULL; tsh <= {1'b1, tsh[9:1]};
        if (tb == 4'd9) trun <= 1'b0; else tb <= tb + 4'd1;
      end
    end
  end
endmodule
