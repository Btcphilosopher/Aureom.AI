// SPDX-License-Identifier: GPL-2.0-only
// UART <-> BAR0 / host-RAM bridge. Byte protocol (little-endian), every request is answered:
//   '?'                         -> "SFG1"
//   'W' a16 d32                 -> 0x06            write BAR0 register
//   'R' a16                     -> d32             read BAR0 register
//   'M' a16 n16 <n bytes>       -> 0x06            write host RAM (a16, n16 multiples of 4)
//   'm' a16 n16                 -> <n bytes>       read host RAM
//   'I'                         -> u8              interrupt messages since the last 'I' (saturating); clears
`timescale 1ns/1ps
module sfg1_bridge #(parameter integer AW = 12) (
  input  wire clk, input wire rst_n,
  input  wire rx_valid, input wire [7:0] rx_data,
  output reg  tx_start, output reg [7:0] tx_data, input wire tx_busy,
  output reg  csr_wr, output reg [11:0] csr_addr, output reg [31:0] csr_wdata, input wire [31:0] csr_rdata,
  output reg  b_we, output reg [AW-1:0] b_addr, output reg [31:0] b_din, input wire [31:0] b_dout,
  input  wire irq_msg, output reg act_rx, output reg act_tx
);
  localparam [4:0] CMD=0, A0=1, A1=2, D0=3, D1=4, D2=5, D3=6, L0=7, L1=8, MW=9, DO_W=10, DO_R=11, DO_R2=12, REP=13, MR=14, MR1=15, MR2=16;
  reg [4:0] st, after; reg [7:0] cmd; reg [15:0] addr, len; reg [31:0] word; reg [1:0] bc;
  reg [31:0] rep; reg [2:0] rep_n; reg [7:0] irq_cnt; reg [15:0] led_hold;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= CMD; after <= CMD; cmd <= 0; addr <= 0; len <= 0; word <= 0; bc <= 0; rep <= 0; rep_n <= 0; irq_cnt <= 0;
      tx_start <= 0; tx_data <= 0; csr_wr <= 0; csr_addr <= 0; csr_wdata <= 0; b_we <= 0; b_addr <= 0; b_din <= 0; act_rx <= 0; act_tx <= 0; led_hold <= 0;
    end else begin
      tx_start <= 1'b0; csr_wr <= 1'b0; b_we <= 1'b0;
      if (irq_msg && irq_cnt != 8'hff) irq_cnt <= irq_cnt + 8'd1;
      if (rx_valid) led_hold <= 16'hffff; else if (led_hold != 0) led_hold <= led_hold - 16'd1;
      act_rx <= led_hold != 0; act_tx <= tx_busy;
      case (st)
        CMD: if (rx_valid) begin
          cmd <= rx_data;
          case (rx_data)
            8'h3f: begin rep <= 32'h31474653; rep_n <= 3'd4; st <= REP; after <= CMD; end        // "SFG1"
            8'h57, 8'h52, 8'h4d, 8'h6d: st <= A0;
            8'h49: begin rep <= {24'd0, irq_cnt}; rep_n <= 3'd1; irq_cnt <= 8'd0; st <= REP; after <= CMD; end
            default: ;
          endcase
        end
        A0: if (rx_valid) begin addr[7:0] <= rx_data; st <= A1; end
        A1: if (rx_valid) begin addr[15:8] <= rx_data;
              st <= (cmd == 8'h57) ? D0 : (cmd == 8'h52) ? DO_R : L0; end
        D0: if (rx_valid) begin word[7:0] <= rx_data; st <= D1; end
        D1: if (rx_valid) begin word[15:8] <= rx_data; st <= D2; end
        D2: if (rx_valid) begin word[23:16] <= rx_data; st <= D3; end
        D3: if (rx_valid) begin word[31:24] <= rx_data; st <= DO_W; end
        DO_W: begin csr_wr <= 1'b1; csr_addr <= addr[11:0]; csr_wdata <= word; rep <= 32'h06; rep_n <= 3'd1; st <= REP; after <= CMD; end
        DO_R: begin csr_addr <= addr[11:0]; st <= DO_R2; end
        DO_R2: begin rep <= csr_rdata; rep_n <= 3'd4; st <= REP; after <= CMD; end
        L0: if (rx_valid) begin len[7:0] <= rx_data; st <= L1; end
        L1: if (rx_valid) begin len[15:8] <= rx_data; bc <= 0; st <= (cmd == 8'h4d) ? ((len == 0 && rx_data == 0) ? CMD : MW) : MR; end
        MW: if (rx_valid) begin
              word <= {rx_data, word[31:8]}; bc <= bc + 2'd1;
              if (bc == 2'd3) begin b_we <= 1'b1; b_addr <= addr[AW+1:2]; b_din <= {rx_data, word[31:8]};
                addr <= addr + 16'd4; len <= len - 16'd4;
                if (len == 16'd4) begin rep <= 32'h06; rep_n <= 3'd1; st <= REP; after <= CMD; end end
            end
        MR: begin b_addr <= addr[AW+1:2]; st <= MR1; end
        MR1: st <= MR2;
        MR2: begin rep <= b_dout; rep_n <= 3'd4; addr <= addr + 16'd4; len <= len - 16'd4; st <= REP; after <= (len == 16'd4) ? CMD : MR; end
        REP: if (!tx_busy && !tx_start) begin
              if (rep_n == 0) st <= after;
              else begin tx_start <= 1'b1; tx_data <= rep[7:0]; rep <= {8'd0, rep[31:8]}; rep_n <= rep_n - 3'd1; end
            end
        default: st <= CMD;
      endcase
    end
  end
endmodule
