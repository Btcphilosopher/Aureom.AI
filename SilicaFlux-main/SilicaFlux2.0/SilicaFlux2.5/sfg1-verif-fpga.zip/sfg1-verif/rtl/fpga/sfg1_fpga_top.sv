// SPDX-License-Identifier: GPL-2.0-only
// SF-G1 FPGA bring-up top for the Radiona ULX3S (Lattice ECP5-85F). The host talks to it over the
// board's USB-UART; host memory is an on-chip stand-in (see sfg1_hostram.sv). Not PCIe.
// -DSIM: no PLL, the testbench clock IS the core clock (CORE_MHZ must match it).
`timescale 1ns/1ps
module sfg1_fpga_top #(
  parameter integer CORE_MHZ = 50, parameter integer BAUD = 2000000, parameter integer HOST_WORDS = 4096,
  parameter integer MAX_CTX = 4, parameter integer WIN_KIB = 16, parameter integer FETCH_BURST = 0,
  parameter integer DMA_BURST = 1, parameter integer VEC_MODE = 0, parameter integer TEN_MODE = 0, parameter integer PIPE = 0
) (
  input  wire       clk_25mhz,
  input  wire       ftdi_txd,       // FTDI TX -> FPGA RX
  output wire       ftdi_rxd,       // FPGA TX -> FTDI RX
  output wire [7:0] led
);
  wire clk, locked;
`ifdef SIM
  assign clk = clk_25mhz; assign locked = 1'b1;
`else
  sfg1_pll u_pll (.clkin(clk_25mhz), .clkout0(clk), .locked(locked));
`endif
  // power-on reset: held until the PLL is locked and a counter expires, then released synchronously
  reg [15:0] por = 16'd0; reg [1:0] rsync = 2'b00;
  always @(posedge clk) begin
    if (!locked) por <= 16'd0; else if (por != 16'hffff) por <= por + 16'd1;
    rsync <= {rsync[0], (por == 16'hffff)};
  end
  wire rst_n = rsync[1];

  wire rx_valid, tx_start, tx_busy, txd; wire [7:0] rx_data, tx_data;
  sfg1_uart #(.CPB((CORE_MHZ * 1000000) / BAUD)) u_uart (.clk(clk), .rst_n(rst_n), .rxd(ftdi_txd), .txd(txd),
    .rx_valid(rx_valid), .rx_data(rx_data), .tx_start(tx_start), .tx_data(tx_data), .tx_busy(tx_busy));
  assign ftdi_rxd = txd;

  localparam integer AW = $clog2(HOST_WORDS);
  wire csr_wr; wire [11:0] csr_addr; wire [31:0] csr_wdata, csr_rdata; wire b_we; wire [AW-1:0] b_addr; wire [31:0] b_din, b_dout;
  wire irq_msg, act_rx, act_tx;
  sfg1_bridge #(.AW(AW)) u_bridge (.clk(clk), .rst_n(rst_n), .rx_valid(rx_valid), .rx_data(rx_data), .tx_start(tx_start),
    .tx_data(tx_data), .tx_busy(tx_busy), .csr_wr(csr_wr), .csr_addr(csr_addr), .csr_wdata(csr_wdata), .csr_rdata(csr_rdata),
    .b_we(b_we), .b_addr(b_addr), .b_din(b_din), .b_dout(b_dout), .irq_msg(irq_msg), .act_rx(act_rx), .act_tx(act_tx));

  wire mrd_req, mrd_valid, mrd_err, mwr_req, mwr_ready, mwr_err; wire [63:0] mrd_addr, mwr_addr; wire [8:0] mrd_len;
  wire [3:0] mrd_tag, mrd_rtag; wire [31:0] mrd_data, mwr_data; wire [383:0] dbg_fe; wire [86:0] dbg_eng;
  sfg1_core #(.MAX_CTX(MAX_CTX), .MAX_QENT(64), .WIN_KIB(WIN_KIB), .FETCH_BURST(FETCH_BURST), .DMA_BURST(DMA_BURST),
              .VEC_MODE(VEC_MODE), .TEN_MODE(TEN_MODE), .PIPE(PIPE), .PERF_EN(1)) u_core (
    .clk(clk), .rst_n(rst_n), .csr_wr(csr_wr), .csr_addr(csr_addr), .csr_wdata(csr_wdata), .csr_rdata(csr_rdata),
    .mrd_req(mrd_req), .mrd_addr(mrd_addr), .mrd_len(mrd_len), .mrd_tag(mrd_tag), .mrd_valid(mrd_valid), .mrd_data(mrd_data),
    .mrd_err(mrd_err), .mrd_rtag(mrd_rtag), .mwr_req(mwr_req), .mwr_addr(mwr_addr), .mwr_data(mwr_data),
    .mwr_ready(mwr_ready), .mwr_err(mwr_err), .irq_msg(irq_msg), .dbg_fe(dbg_fe), .dbg_eng(dbg_eng));
  sfg1_hostram #(.WORDS(HOST_WORDS)) u_ram (.clk(clk), .rst_n(rst_n), .mrd_req(mrd_req), .mrd_addr(mrd_addr), .mrd_len(mrd_len),
    .mrd_tag(mrd_tag), .mrd_valid(mrd_valid), .mrd_data(mrd_data), .mrd_err(mrd_err), .mrd_rtag(mrd_rtag), .mwr_req(mwr_req),
    .mwr_addr(mwr_addr), .mwr_data(mwr_data), .mwr_ready(mwr_ready), .mwr_err(mwr_err),
    .b_we(b_we), .b_addr(b_addr), .b_din(b_din), .b_dout(b_dout));

  // status LEDs: [0] heartbeat [1] PLL locked [2] BUSY [3] HALTED [4] FATAL [5] interrupt (toggles) [6] UART rx [7] UART tx
  reg [24:0] hb; reg irq_t;
  always @(posedge clk) begin hb <= hb + 25'd1; if (irq_msg) irq_t <= ~irq_t; end
  wire fe_busy = (dbg_fe[14:11] != 4'd0);
  assign led = {act_tx, act_rx, irq_t, dbg_fe[2], dbg_fe[1], fe_busy, locked, hb[24]};
endmodule
