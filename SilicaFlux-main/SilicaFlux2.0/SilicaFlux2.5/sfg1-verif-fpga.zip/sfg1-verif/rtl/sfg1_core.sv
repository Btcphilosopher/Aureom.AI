// SPDX-License-Identifier: GPL-2.0-only
// SF-G1 device core: front-end + engine (+ device memory) + host-bus unit + perf counters.
// External interface = BAR0 register port + host-memory master (+ interrupt message).
// This is the unit the FPGA flow synthesises and the co-simulation harness drives.
`timescale 1ns/1ps
module sfg1_core #(
  parameter integer MAX_CTX      = 4,
  parameter integer MAX_QENT     = 64,
  parameter integer WIN_KIB      = 16,
  parameter integer RESET_CYCLES = 6,
  parameter integer FETCH_BURST  = 0,
  parameter integer DMA_BURST    = 1,
  parameter integer VEC_MODE     = 0,
  parameter integer TEN_MODE     = 0,
  parameter integer PIPE         = 0,
  parameter integer PERF_EN      = 1,
  parameter integer ORDER_BUG    = 0,
  parameter integer MUT          = 0
) (
  input  wire        clk,
  input  wire        rst_n,
  // BAR0
  input  wire        csr_wr,
  input  wire [11:0] csr_addr,
  input  wire [31:0] csr_wdata,
  output wire [31:0] csr_rdata,
  // host-memory master
  output wire        mrd_req,
  output wire [63:0] mrd_addr,
  output wire [8:0]  mrd_len,
  output wire [3:0]  mrd_tag,
  input  wire        mrd_valid,
  input  wire [31:0] mrd_data,
  input  wire        mrd_err,
  input  wire [3:0]  mrd_rtag,
  output wire        mwr_req,
  output wire [63:0] mwr_addr,
  output wire [31:0] mwr_data,
  input  wire        mwr_ready,
  input  wire        mwr_err,
  output wire        irq_msg,
  // debug taps (layouts in sfg1_dbg.svh); unconnected in synthesis builds
  output wire [383:0] dbg_fe,
  output wire [86:0]  dbg_eng
);
  wire        f_csr_wr = csr_wr && (csr_addr[11:8] == 4'd0);
  wire        x_csr_wr = csr_wr && (csr_addr[11:8] == 4'd1);
  wire [31:0] f_rdata, x_rdata;
  assign csr_rdata = (csr_addr[11:8] == 4'd1 && PERF_EN != 0) ? x_rdata :
                     (csr_addr[11:8] == 4'd0) ? f_rdata : 32'd0;

  wire        f_mrd_req, f_mwr_req, e_mrd_req, e_mwr_req;
  wire [63:0] f_mrd_addr, f_mwr_addr, e_mrd_addr, e_mwr_addr;
  wire [8:0]  f_mrd_len, e_mrd_len;
  wire [31:0] f_mwr_data, e_mwr_data;
  wire        r_valid, r_err;
  wire [31:0] r_data;

  wire        eng_start, eng_done, eng_abort;
  wire [15:0] eng_opcode, eng_ctx, eng_flags;
  wire [31:0] eng_exec_op;
  wire [63:0] eng_host_addr, eng_len, eng_a, eng_b, eng_c;
  wire [2:0]  eng_status;
  wire [3:0]  fe_state;
  wire        eng_busy, rd_stall, wr_stall;
  wire [4:0]  op_oh;

  // The front-end sees the bus's write-accept; it owns/loads mwr only when the engine is idle.
  wire        fe_mwr_ready = mwr_ready;

  sfg1_frontend #(.MAX_CTX(MAX_CTX), .MAX_QENT(MAX_QENT), .WIN_KIB(WIN_KIB), .RESET_CYCLES(RESET_CYCLES),
                  .FETCH_BURST(FETCH_BURST), .ORDER_BUG(ORDER_BUG), .MUT(MUT)) u_fe (
    .clk(clk), .rst_n(rst_n),
    .csr_wr(f_csr_wr), .csr_addr(csr_addr), .csr_wdata(csr_wdata), .csr_rdata(f_rdata),
    .mrd_req(f_mrd_req), .mrd_addr(f_mrd_addr), .mrd_len(f_mrd_len),
    .mrd_valid(r_valid), .mrd_data(r_data), .mrd_err(r_err),
    .mwr_req(f_mwr_req), .mwr_addr(f_mwr_addr), .mwr_data(f_mwr_data), .mwr_ready(fe_mwr_ready),
    .irq_msg(irq_msg),
    .eng_start(eng_start), .eng_opcode(eng_opcode), .eng_ctx(eng_ctx), .eng_flags(eng_flags),
    .eng_exec_op(eng_exec_op), .eng_host_addr(eng_host_addr), .eng_len(eng_len),
    .eng_a(eng_a), .eng_b(eng_b), .eng_c(eng_c),
    .eng_done(eng_done), .eng_status(eng_status), .eng_abort(eng_abort),
    .fe_state(fe_state), .dbg_fe(dbg_fe));

  sfg1_engine #(.MAX_CTX(MAX_CTX), .WIN_KIB(WIN_KIB), .DMA_BURST(DMA_BURST), .VEC_MODE(VEC_MODE),
                .TEN_MODE(TEN_MODE), .PIPE(PIPE), .MUT(MUT)) u_eng (
    .clk(clk), .rst_n(rst_n),
    .eng_start(eng_start), .eng_opcode(eng_opcode), .eng_ctx(eng_ctx), .eng_flags(eng_flags),
    .eng_exec_op(eng_exec_op), .eng_host_addr(eng_host_addr), .eng_len(eng_len),
    .eng_a(eng_a), .eng_b(eng_b), .eng_c(eng_c),
    .eng_done(eng_done), .eng_status(eng_status), .eng_abort(eng_abort),
    .e_mrd_req(e_mrd_req), .e_mrd_addr(e_mrd_addr), .e_mrd_len(e_mrd_len),
    .r_valid(r_valid), .r_data(r_data), .r_err(r_err),
    .e_mwr_req(e_mwr_req), .e_mwr_addr(e_mwr_addr), .e_mwr_data(e_mwr_data),
    .mwr_ready(mwr_ready), .mwr_err(mwr_err),
    .eng_busy(eng_busy), .op_oh(op_oh), .rd_stall(rd_stall), .wr_stall(wr_stall), .dbg_eng(dbg_eng));

  sfg1_hbus #(.MUT(MUT)) u_bus (
    .clk(clk), .rst_n(rst_n), .eng_busy(eng_busy), .abort(eng_abort),
    .f_mrd_req(f_mrd_req), .f_mrd_addr(f_mrd_addr), .f_mrd_len(f_mrd_len),
    .f_mwr_req(f_mwr_req), .f_mwr_addr(f_mwr_addr), .f_mwr_data(f_mwr_data),
    .e_mrd_req(e_mrd_req), .e_mrd_addr(e_mrd_addr), .e_mrd_len(e_mrd_len),
    .e_mwr_req(e_mwr_req), .e_mwr_addr(e_mwr_addr), .e_mwr_data(e_mwr_data),
    .mrd_req(mrd_req), .mrd_addr(mrd_addr), .mrd_len(mrd_len), .mrd_tag(mrd_tag),
    .mrd_valid(mrd_valid), .mrd_data(mrd_data), .mrd_err(mrd_err), .mrd_rtag(mrd_rtag),
    .mwr_req(mwr_req), .mwr_addr(mwr_addr), .mwr_data(mwr_data),
    .r_valid(r_valid), .r_data(r_data), .r_err(r_err));

  generate if (PERF_EN != 0) begin : g_perf
    // cmd_done: the front-end committed a command (state S_COMMIT while not stalled)
    wire cmd_done = (fe_state == 4'd9) && !(mwr_req && !mwr_ready);
    sfg1_perf u_perf (
      .clk(clk), .rst_n(rst_n), .csr_wr(x_csr_wr), .csr_addr(csr_addr), .csr_wdata(csr_wdata),
      .csr_rdata(x_rdata), .fe_state(fe_state), .cmd_done(cmd_done), .op_oh(op_oh),
      .rd_beat(r_valid), .wr_beat(mwr_req && mwr_ready), .rd_stall(rd_stall), .wr_stall(wr_stall));
  end else begin : g_noperf
    assign x_rdata = 32'd0;
  end endgenerate
endmodule
