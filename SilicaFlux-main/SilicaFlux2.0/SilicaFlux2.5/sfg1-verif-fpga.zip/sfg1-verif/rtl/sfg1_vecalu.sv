// SPDX-License-Identifier: GPL-2.0-only
// SF-G1 VEC lane ALU (combinational). A 32-bit word holds four signed INT8 lanes, lane k = byte k.
// Semantics: contract section 8 / kernel mock lane_op(): ADD8/SUB8 wrap per lane, MAX8 signed,
// RELU8 unary on A, XOR32/AND32 on the whole word, MUL8 = low byte of each lane product.
// DOT8 is a reduction: dot = sum over 4 lanes of a_k*b_k as one INT32 (accumulated by the caller).
`timescale 1ns/1ps
module sfg1_vecalu #(parameter integer MUT = 0) (
  input  wire [2:0]  op,
  input  wire [31:0] a,
  input  wire [31:0] b,
  output reg  [31:0] y,
  output wire signed [31:0] dot,     // sum of the four lane products (valid for any op; used for DOT8)
  output wire signed [15:0] pr0, pr1, pr2, pr3   // the four lane products (registered by the engine when PIPE=2)
);
  `include "sfg1_defs.svh"
  wire signed [7:0] a0 = a[7:0],  a1 = a[15:8],  a2 = a[23:16],  a3 = a[31:24];
  wire signed [7:0] b0 = b[7:0],  b1 = b[15:8],  b2 = b[23:16],  b3 = b[31:24];
  wire signed [15:0] p0 = a0 * b0, p1 = a1 * b1, p2 = a2 * b2, p3 = a3 * b3;
  assign pr0 = p0; assign pr1 = p1; assign pr2 = p2; assign pr3 = p3;
  wire signed [31:0] q0 = {{16{p0[15]}}, p0}, q1 = {{16{p1[15]}}, p1}, q2 = {{16{p2[15]}}, p2}, q3 = {{16{p3[15]}}, p3};
  assign dot = (MUT == 18) ? ((q0 + q1) + q2) : ((q0 + q1) + (q2 + q3));   // MUTANT 18: lane 3 missing

  function [7:0] lane(input [2:0] o, input signed [7:0] x, input signed [7:0] z, input signed [15:0] p);
    begin
      case (o)
        SFG1_VEC_ADD8:  lane = x + z;
        SFG1_VEC_SUB8:  lane = (MUT == 12) ? (z - x) : (x - z);      // MUTANT 12: operands swapped
        SFG1_VEC_MAX8:  lane = (x > z) ? x : z;
        SFG1_VEC_RELU8: lane = (x < 0) ? 8'd0 : x;
        SFG1_VEC_MUL8:  lane = p[7:0];
        default:        lane = 8'd0;
      endcase
    end
  endfunction

  always @* begin
    case (op)
      SFG1_VEC_XOR32: y = a ^ b;
      SFG1_VEC_AND32: y = a & b;
      SFG1_VEC_DOT8:  y = 32'd0;
      default:        y = {lane(op, a3, b3, p3), lane(op, a2, b2, p2), lane(op, a1, b1, p1), lane(op, a0, b0, p0)};
    endcase
  end
endmodule
