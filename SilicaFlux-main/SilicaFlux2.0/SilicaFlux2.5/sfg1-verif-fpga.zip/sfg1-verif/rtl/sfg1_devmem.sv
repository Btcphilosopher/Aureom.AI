// SPDX-License-Identifier: GPL-2.0-only
// SF-G1 device-local memory: 32-bit words, one write port, NRD synchronous read ports
// (NRD=2 keeps two identical copies so VEC can read A and B in the same cycle).
// Read-before-write on address collision. Read ports have a clock enable so a stalled consumer
// can hold its data. Content after power-up/reset is not guaranteed (contract: "undefined").
`timescale 1ns/1ps
module sfg1_devmem #(
  parameter integer DEPTH = 4096,
  parameter integer NRD   = 1
) (
  input  wire        clk,
  input  wire        wr_en,
  input  wire [$clog2(DEPTH)-1:0] wr_addr,
  input  wire [31:0] wr_data,
  input  wire        rd0_en,
  input  wire [$clog2(DEPTH)-1:0] rd0_addr,
  output reg  [31:0] rd0_data,
  input  wire        rd1_en,
  input  wire [$clog2(DEPTH)-1:0] rd1_addr,
  output reg  [31:0] rd1_data
);
  (* ram_style = "block" *) reg [31:0] mem0 [0:DEPTH-1];
  always @(posedge clk) begin
    if (wr_en) mem0[wr_addr] <= wr_data;
    if (rd0_en) rd0_data <= mem0[rd0_addr];
  end
  generate
    if (NRD == 2) begin : g_dual
      (* ram_style = "block" *) reg [31:0] mem1 [0:DEPTH-1];
      always @(posedge clk) begin
        if (wr_en) mem1[wr_addr] <= wr_data;
        if (rd1_en) rd1_data <= mem1[rd1_addr];
      end
    end else begin : g_single
      always @* rd1_data = 32'h0;
    end
  endgenerate
endmodule
