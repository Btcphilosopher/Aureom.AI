// SPDX-License-Identifier: GPL-2.0-only
// SF-G1 performance counters -- VENDOR EXTENSION at BAR0 0x100.. (not part of the draft contract;
// the driver never touches it). 32-bit wrapping counters; the same registers are used for the
// simulated-cycle profile and (on hardware) for measured-cycle profiles over the host link.
`timescale 1ns/1ps
module sfg1_perf (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        csr_wr,
  input  wire [11:0] csr_addr,
  input  wire [31:0] csr_wdata,
  output reg  [31:0] csr_rdata,
  input  wire [3:0]  fe_state,
  input  wire        cmd_done,
  input  wire [4:0]  op_oh,        // {SCRUB, TEN, VEC, D2H, H2D}: engine busy with this opcode
  input  wire        rd_beat,
  input  wire        wr_beat,
  input  wire        rd_stall,
  input  wire        wr_stall
);
  `include "sfg1_defs.svh"
  localparam [3:0] S_IDLE = 4'd0, S_RD_REQ = 4'd1, S_RD_WAIT = 4'd2, S_DECODE = 4'd3, S_EXEC = 4'd4,
                   S_WB0 = 4'd5, S_WB1 = 4'd6, S_WB2 = 4'd7, S_WB3 = 4'd8, S_COMMIT = 4'd9;
  reg [31:0] c_cycles, c_busy, c_cmds, c_fetch, c_decode, c_exec, c_wb;
  reg [31:0] c_h2d, c_d2h, c_vec, c_ten, c_scrub, c_rdb, c_wrb, c_rds, c_wrs;
  wire clr = csr_wr && (csr_addr == SFX_REG_PERF_CTRL) && csr_wdata[0];
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      c_cycles <= 0; c_busy <= 0; c_cmds <= 0; c_fetch <= 0; c_decode <= 0; c_exec <= 0; c_wb <= 0;
      c_h2d <= 0; c_d2h <= 0; c_vec <= 0; c_ten <= 0; c_scrub <= 0; c_rdb <= 0; c_wrb <= 0;
      c_rds <= 0; c_wrs <= 0;
    end else if (clr) begin                       // synchronous clear (CSR write)
      c_cycles <= 0; c_busy <= 0; c_cmds <= 0; c_fetch <= 0; c_decode <= 0; c_exec <= 0; c_wb <= 0;
      c_h2d <= 0; c_d2h <= 0; c_vec <= 0; c_ten <= 0; c_scrub <= 0; c_rdb <= 0; c_wrb <= 0;
      c_rds <= 0; c_wrs <= 0;
    end else begin
      c_cycles <= c_cycles + 1;
      if (fe_state != S_IDLE) c_busy <= c_busy + 1;
      if (cmd_done) c_cmds <= c_cmds + 1;
      if (fe_state == S_RD_REQ || fe_state == S_RD_WAIT) c_fetch <= c_fetch + 1;
      if (fe_state == S_DECODE) c_decode <= c_decode + 1;
      if (fe_state == S_EXEC)   c_exec   <= c_exec + 1;
      if (fe_state >= S_WB0 && fe_state <= S_COMMIT) c_wb <= c_wb + 1;
      if (op_oh[0]) c_h2d <= c_h2d + 1;
      if (op_oh[1]) c_d2h <= c_d2h + 1;
      if (op_oh[2]) c_vec <= c_vec + 1;
      if (op_oh[3]) c_ten <= c_ten + 1;
      if (op_oh[4]) c_scrub <= c_scrub + 1;
      if (rd_beat)  c_rdb <= c_rdb + 1;
      if (wr_beat)  c_wrb <= c_wrb + 1;
      if (rd_stall) c_rds <= c_rds + 1;
      if (wr_stall) c_wrs <= c_wrs + 1;
    end
  end
  always @* begin
    case (csr_addr)
      SFX_REG_PERF_CTRL:     csr_rdata = 32'd1;
      SFX_REG_PERF_CYCLES:   csr_rdata = c_cycles;
      SFX_REG_PERF_BUSY:     csr_rdata = c_busy;
      SFX_REG_PERF_CMDS:     csr_rdata = c_cmds;
      SFX_REG_PERF_FETCH:    csr_rdata = c_fetch;
      SFX_REG_PERF_DECODE:   csr_rdata = c_decode;
      SFX_REG_PERF_EXEC:     csr_rdata = c_exec;
      SFX_REG_PERF_WB:       csr_rdata = c_wb;
      SFX_REG_PERF_OP_H2D:   csr_rdata = c_h2d;
      SFX_REG_PERF_OP_D2H:   csr_rdata = c_d2h;
      SFX_REG_PERF_OP_VEC:   csr_rdata = c_vec;
      SFX_REG_PERF_OP_TEN:   csr_rdata = c_ten;
      SFX_REG_PERF_OP_SCRUB: csr_rdata = c_scrub;
      SFX_REG_PERF_RD_BEATS: csr_rdata = c_rdb;
      SFX_REG_PERF_WR_BEATS: csr_rdata = c_wrb;
      SFX_REG_PERF_RD_STALL: csr_rdata = c_rds;
      SFX_REG_PERF_WR_STALL: csr_rdata = c_wrs;
      SFX_REG_PERF_VERSION:  csr_rdata = 32'h0000_0001;
      default:               csr_rdata = 32'd0;
    endcase
  end
endmodule
