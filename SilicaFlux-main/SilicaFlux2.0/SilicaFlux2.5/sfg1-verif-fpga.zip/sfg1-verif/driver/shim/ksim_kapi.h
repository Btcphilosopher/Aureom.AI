/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Userspace implementation of the (small) part of the Linux kernel API that the SF-G1 driver's
 * hardware-facing files use: sfg1_hw.c, sfg1_ring.c, sfg1_irq.c, sfg1_reset.c. They are compiled
 * UNMODIFIED against this header. Time is SIMULATED: jiffies/ktime/msleep derive from the RTL
 * clock, so every timeout in the real code (read_poll_timeout, job timeout, reset timeout) is
 * measured in simulated device cycles. Locks assert correct (non-nested) use.
 *
 * What is NOT here: DRM core, scheduler, GEM, PCI, real concurrency. sfg1_job.c / sfg1_ctx.c /
 * sfg1_gem.c / sfg1_main.c are re-implemented in ksim.c (see docs/04-driver-integration.md).
 */
#ifndef KSIM_KAPI_H
#define KSIM_KAPI_H
#define _GNU_SOURCE
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/types.h>

#ifdef __cplusplus
extern "C" {
#endif
#define LINUX_VERSION_CODE 0x061200
#define KERNEL_VERSION(a, b, c) (((a) << 16) + ((b) << 8) + (c))
#define IS_ENABLED(option) 0                 /* CONFIG_DRM_ACCEL_SFG1_MOCK etc.: off */
#define __bitwise
#define __user
#define __init
#define __exit
#define likely(x)   __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)
#define READ_ONCE(x)  (*(volatile __typeof__(x) *)&(x))
#define WRITE_ONCE(x, v) do { *(volatile __typeof__(x) *)&(x) = (v); } while (0)
#define smp_store_release(p, v) __atomic_store_n((p), (v), __ATOMIC_RELEASE)
#define smp_load_acquire(p)     __atomic_load_n((p), __ATOMIC_ACQUIRE)
#define dma_wmb() __atomic_thread_fence(__ATOMIC_RELEASE)
#define dma_rmb() __atomic_thread_fence(__ATOMIC_ACQUIRE)
#define container_of(ptr, type, member) ((type *)((char *)(ptr) - offsetof(type, member)))
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define U32_MAX 0xffffffffu
#define SZ_1K 1024u
#define SZ_1M (1024u * 1024u)
#define PAGE_SIZE 4096u
#define BITS_PER_LONG 64
#ifndef BIT
#define BIT(n) (1UL << (n))
#endif
#define WARN_ON_ONCE(c) ({ int __c = !!(c); if (__c) { static int __once; if (!__once++) fprintf(stderr, "ksim: WARN_ON_ONCE(%s) at %s:%d\n", #c, __FILE__, __LINE__); } __c; })
#define WARN_ON(c) WARN_ON_ONCE(c)
#define lockdep_assert_held(l) do { } while (0)
#define IS_ERR(p) ((unsigned long)(p) >= (unsigned long)-4095)
#define ERR_PTR(e) ((void *)(long)(e))
#define PTR_ERR(p) ((long)(p))
#define IS_ALIGNED(x, a) (((x) & ((__typeof__(x))(a) - 1)) == 0)
#define min_t(t, a, b) ({ t __a = (a), __b = (b); __a < __b ? __a : __b; })
#define max_t(t, a, b) ({ t __a = (a), __b = (b); __a > __b ? __a : __b; })
#define min(a, b) ({ __typeof__(a) __a = (a); __typeof__(b) __b = (b); __a < __b ? __a : __b; })
#define max(a, b) ({ __typeof__(a) __a = (a); __typeof__(b) __b = (b); __a > __b ? __a : __b; })
#define lower_32_bits(n) ((u32)((n) & 0xffffffffu))
#define upper_32_bits(n) ((u32)(((n) >> 16) >> 16))
#define struct_size(p, member, n) (sizeof(*(p)) + (size_t)(n) * sizeof((p)->member[0]))
#define cpu_to_le16(x) (x)
#define cpu_to_le32(x) (x)
#define cpu_to_le64(x) (x)
#define le16_to_cpu(x) (x)
#define le32_to_cpu(x) (x)
#define le64_to_cpu(x) (x)
#define is_power_of_2(n) ((n) != 0 && (((n) & ((n) - 1)) == 0))
#define check_mul_overflow(a, b, d) __builtin_mul_overflow((a), (b), (d))
#define check_add_overflow(a, b, d) __builtin_add_overflow((a), (b), (d))
#define __ffs64(x) __builtin_ctzll(x)
#define FIELD_GET(mask, val) (((val) & (mask)) >> __builtin_ctzll(mask))
#define GENMASK(h, l) ((~0UL << (l)) & (~0UL >> (BITS_PER_LONG - 1 - (h))))

/* ---- lists ---- */
struct list_head { struct list_head *next, *prev; };
#define LIST_HEAD(name) struct list_head name = { &(name), &(name) }
static inline void INIT_LIST_HEAD(struct list_head *l) { l->next = l->prev = l; }
static inline bool list_empty(const struct list_head *h) { return h->next == h; }
static inline void __list_add(struct list_head *n, struct list_head *p, struct list_head *x) { x->prev = n; n->next = x; n->prev = p; p->next = n; }
static inline void list_add_tail(struct list_head *n, struct list_head *h) { __list_add(n, h->prev, h); }
static inline void list_add(struct list_head *n, struct list_head *h) { __list_add(n, h, h->next); }
static inline void __list_del(struct list_head *p, struct list_head *x) { x->prev = p; p->next = x; }
static inline void list_del_init(struct list_head *e) { __list_del(e->prev, e->next); INIT_LIST_HEAD(e); }
static inline void list_move_tail(struct list_head *e, struct list_head *h) { __list_del(e->prev, e->next); list_add_tail(e, h); }
static inline void list_splice_init(struct list_head *l, struct list_head *h)
{
	if (list_empty(l)) return;
	struct list_head *first = l->next, *last = l->prev, *at = h->prev;
	first->prev = at; at->next = first; last->next = h; h->prev = last; INIT_LIST_HEAD(l);
}
#define list_entry(ptr, type, member) container_of(ptr, type, member)
#define list_first_entry(ptr, type, member) list_entry((ptr)->next, type, member)
#define list_first_entry_or_null(ptr, type, member) (list_empty(ptr) ? NULL : list_first_entry(ptr, type, member))
#define list_for_each_entry(pos, head, member) \
	for (pos = list_entry((head)->next, __typeof__(*pos), member); &pos->member != (head); pos = list_entry(pos->member.next, __typeof__(*pos), member))
#define list_for_each_entry_safe(pos, n, head, member) \
	for (pos = list_entry((head)->next, __typeof__(*pos), member), n = list_entry(pos->member.next, __typeof__(*pos), member); \
	     &pos->member != (head); pos = n, n = list_entry(n->member.next, __typeof__(*n), member))

/* ---- locks: single-threaded, but misuse (nesting, unlock without lock) is caught ---- */
typedef struct { int locked; } spinlock_t;
struct mutex { int locked; };
static inline void spin_lock_init(spinlock_t *l) { l->locked = 0; }
static inline void spin_lock(spinlock_t *l) { if (l->locked) { fprintf(stderr, "ksim: spinlock recursion\n"); abort(); } l->locked = 1; }
static inline void spin_unlock(spinlock_t *l) { if (!l->locked) { fprintf(stderr, "ksim: spin_unlock of unlocked lock\n"); abort(); } l->locked = 0; }
static inline void mutex_init(struct mutex *m) { m->locked = 0; }
static inline void mutex_lock(struct mutex *m) { if (m->locked) { fprintf(stderr, "ksim: mutex recursion\n"); abort(); } m->locked = 1; }
static inline void mutex_unlock(struct mutex *m) { if (!m->locked) { fprintf(stderr, "ksim: mutex_unlock of unlocked mutex\n"); abort(); } m->locked = 0; }

/* ---- atomics / refcounts / bits ---- */
typedef struct { int counter; } atomic_t;
typedef struct { long long counter; } atomic64_t;
static inline void atomic_set(atomic_t *a, int v) { a->counter = v; }
static inline int atomic_read(const atomic_t *a) { return a->counter; }
static inline void atomic_inc(atomic_t *a) { a->counter++; }
static inline void atomic_dec(atomic_t *a) { a->counter--; }
static inline int atomic_inc_return(atomic_t *a) { return ++a->counter; }
static inline void atomic_or(int v, atomic_t *a) { a->counter |= v; }
static inline int atomic_xchg(atomic_t *a, int v) { int o = a->counter; a->counter = v; return o; }
static inline void atomic64_set(atomic64_t *a, long long v) { a->counter = v; }
static inline long long atomic64_read(const atomic64_t *a) { return a->counter; }
static inline void atomic64_inc(atomic64_t *a) { a->counter++; }
static inline void atomic64_add(long long v, atomic64_t *a) { a->counter += v; }
struct kref { int refcount; };
static inline void kref_init(struct kref *k) { k->refcount = 1; }
static inline void kref_get(struct kref *k) { k->refcount++; }
static inline int kref_put(struct kref *k, void (*rel)(struct kref *)) { if (--k->refcount == 0) { rel(k); return 1; } return 0; }
static inline void set_bit(int nr, unsigned long *a) { *a |= 1UL << nr; }
static inline int test_bit(int nr, const unsigned long *a) { return (*a >> nr) & 1; }
static inline int test_and_set_bit(int nr, unsigned long *a) { int o = test_bit(nr, a); set_bit(nr, a); return o; }

/* ---- simulated time (provided by ksim.c) ---- */
typedef int64_t ktime_t;
#define HZ 1000
extern unsigned long ksim_jiffies(void);
extern int64_t ksim_now_ns(void);
extern void ksim_advance_ns(int64_t ns);
#define jiffies ksim_jiffies()
#define msecs_to_jiffies(ms) ((unsigned long)(ms))
#define time_before(a, b) ((long)((a) - (b)) < 0)
#define time_after(a, b)  ((long)((b) - (a)) < 0)
static inline ktime_t ktime_get(void) { return ksim_now_ns(); }
static inline ktime_t ktime_sub(ktime_t a, ktime_t b) { return a - b; }
static inline int64_t ktime_to_ns(ktime_t t) { return t; }
static inline bool ktime_after(ktime_t a, ktime_t b) { return a > b; }
static inline void msleep(unsigned ms) { ksim_advance_ns((int64_t)ms * 1000000); }
static inline void udelay(unsigned us) { ksim_advance_ns((int64_t)us * 1000); }
#define ETIMEDOUT_KSIM ETIMEDOUT
#define read_poll_timeout(op, val, cond, sleep_us, timeout_us, sleep_before_read, args...) ({ \
	int64_t __end = ksim_now_ns() + (int64_t)(timeout_us) * 1000; int __ret = 0; \
	for (;;) { (val) = op(args); if (cond) break; \
		if (ksim_now_ns() > __end) { (val) = op(args); __ret = (cond) ? 0 : -ETIMEDOUT; break; } \
		ksim_advance_ns((int64_t)((sleep_us) ? (sleep_us) : 1) * 1000); } \
	__ret; })

/* ---- diagnostics ---- */
struct device { const char *name; };
extern void ksim_log(const char *lvl, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
#define dev_err(d, ...)  ksim_log("err", __VA_ARGS__)
#define dev_warn(d, ...) ksim_log("warn", __VA_ARGS__)
#define dev_info(d, ...) ksim_log("info", __VA_ARGS__)

/* ---- dma_fence / DRM / scheduler / irq stubs ---- */
struct dma_fence { int signaled; int error; void *owner; };
static inline bool dma_fence_begin_signalling(void) { return true; }
static inline void dma_fence_end_signalling(bool c) { (void)c; }
static inline void dma_fence_set_error(struct dma_fence *f, int e) { f->error = e; }
static inline void dma_fence_signal(struct dma_fence *f) { f->signaled = 1; }
static inline bool dma_fence_is_signaled(struct dma_fence *f) { return f->signaled; }
struct drm_device { int dummy; };
struct drm_file { void *driver_priv; };
struct drm_gem_object { size_t size; };
struct drm_sched_entity { int dummy; };
struct drm_gpu_scheduler { int dummy; };
struct drm_sched_job { int dummy; };
struct drm_printer; struct dma_buf; struct drm_driver; struct drm_sched_backend_ops;
struct work_struct { int pending; };
struct workqueue_struct { int dummy; };
typedef struct { int dummy; } wait_queue_head_t;
struct xarray { int dummy; };
enum drm_gpu_sched_stat { DRM_GPU_SCHED_STAT_NONE, DRM_GPU_SCHED_STAT_RESET, DRM_GPU_SCHED_STAT_NO_HANG, DRM_GPU_SCHED_STAT_ENODEV };
typedef enum { IRQ_NONE = 0, IRQ_HANDLED = 1, IRQ_WAKE_THREAD = 2 } irqreturn_t;
extern void drm_sched_stop(struct drm_gpu_scheduler *s, struct drm_sched_job *j);
extern void drm_sched_start(struct drm_gpu_scheduler *s, int err);
extern void drm_sched_fault(struct drm_gpu_scheduler *s);
extern bool queue_work(struct workqueue_struct *wq, struct work_struct *w);
extern void disable_irq(int irq);
extern void enable_irq(int irq);

/* ---- DMA coherent memory = simulated host memory (ksim.c) ---- */
extern void *ksim_dma_alloc(size_t size, u64 *bus);
extern void ksim_dma_free(size_t size, void *cpu, u64 bus);
#define GFP_KERNEL 0
#define dma_alloc_coherent(dev, size, handle, gfp) ksim_dma_alloc((size), (u64 *)(handle))
#define dma_free_coherent(dev, size, cpu, handle) ksim_dma_free((size), (cpu), (handle))
#define kzalloc(n, f) calloc(1, (n))
#define kvzalloc(n, f) calloc(1, (n))
#define kfree(p) free(p)
#define kvfree(p) free(p)
#ifdef __cplusplus
}
#endif
#endif /* KSIM_KAPI_H */
