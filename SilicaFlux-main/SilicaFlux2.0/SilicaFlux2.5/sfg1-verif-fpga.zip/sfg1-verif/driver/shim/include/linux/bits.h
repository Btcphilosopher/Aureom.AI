/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef SFG1_SHIM_LINUX_BITS_H
#define SFG1_SHIM_LINUX_BITS_H
#define BIT(n) (1UL << (n))
#define BITS_PER_LONG 64
#define GENMASK(h, l) ((~0UL << (l)) & (~0UL >> (BITS_PER_LONG - 1 - (h))))
#endif
