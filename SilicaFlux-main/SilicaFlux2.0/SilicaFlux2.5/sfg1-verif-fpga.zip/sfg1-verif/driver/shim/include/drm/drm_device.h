/* SPDX-License-Identifier: GPL-2.0-only */
#include "ksim_kapi.h"
