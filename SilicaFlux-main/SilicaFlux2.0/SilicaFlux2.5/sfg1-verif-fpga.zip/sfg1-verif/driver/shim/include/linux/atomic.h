/* SPDX-License-Identifier: GPL-2.0-only */
/* userspace shim: everything lives in ksim_kapi.h */
#include "ksim_kapi.h"
