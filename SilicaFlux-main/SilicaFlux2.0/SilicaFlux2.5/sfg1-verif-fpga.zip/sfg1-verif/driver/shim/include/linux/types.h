/* SPDX-License-Identifier: GPL-2.0-only */
/* Userspace shim: real UAPI <linux/types.h> plus the kernel-internal short integer names. */
#ifndef SFG1_SHIM_LINUX_TYPES_H
#define SFG1_SHIM_LINUX_TYPES_H
#include_next <linux/types.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef unsigned long long u64;   /* kernel: int-ll64 */
typedef int8_t s8; typedef int16_t s16; typedef int32_t s32; typedef long long s64;
typedef u64 dma_addr_t;
#endif
