/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef SFG1_SHIM_LINUX_BUILD_BUG_H
#define SFG1_SHIM_LINUX_BUILD_BUG_H
#endif
