// SPDX-License-Identifier: GPL-2.0-only
/*
 * ksim: the SF-G1 driver, in userspace, over the RTL co-simulation.
 *
 * REAL driver code, compiled unmodified against driver/shim/ksim_kapi.h:
 *   sfg1_hw.c     discovery, queue programming, start / quiesce / engine & function reset
 *   sfg1_ring.c   SQ push + doorbell, CQ reap (phase bit, dma_rmb), job completion
 *   sfg1_irq.c    top half (ack) + threaded drain (acknowledge-then-drain)
 *   sfg1_reset.c  timeout / error recovery: ENGINE_RESET -> FUNCTION reset -> DEAD, strikes, cancel
 * RE-IMPLEMENTED here (they are welded to DRM core objects; logic and error codes follow the real
 * source, see the comments): sfg1_main.c bring-up, sfg1_ctx.c (slots, scrub, open/close),
 * sfg1_gem.c (BO_CREATE quotas), sfg1_job.c (sfg1_build_cmd validation, SUBMIT, WAIT_JOB,
 * run_job), the drm_sched credit/timeout role. These ports are NOT the kernel code and carry the
 * risk of any port; docs/04-driver-integration.md says exactly what is and is not covered.
 */
#include "ksim.h"
#include "sfg1_drv.h"
#include <drm/drm.h>
#include <time.h>

/* ------------------------------------------------------------------------ state */
static struct sfg1_device S;
static struct device DEV = { "sfg1-ksim" };
static const struct ksim_host_ops *H;
static struct ksim_cfg CFG;
static int irq_enabled = 1, irq_deferred, in_irq, sched_fault, reset_work_pending, in_pump;

/* ------------------------------------------------------------------------ time, log, hooks */
int64_t ksim_now_ns(void) { return (int64_t)((double)H->cycle(H->u) * 1000.0 / H->clock_mhz); }
unsigned long ksim_jiffies(void) { return (unsigned long)(ksim_now_ns() / 1000000); }
void ksim_advance_ns(int64_t ns)
{
	uint64_t c = (uint64_t)((double)ns * H->clock_mhz / 1000.0);
	H->tick(H->u, c ? c : 1);
}

#define LOGN 256
static char logbuf[LOGN][200]; static int logn;
void ksim_log(const char *lvl, const char *fmt, ...)
{
	char line[200]; va_list ap;
	va_start(ap, fmt); vsnprintf(line, sizeof(line), fmt, ap); va_end(ap);
	snprintf(logbuf[logn % LOGN], sizeof(logbuf[0]), "%s: %s", lvl, line); logn++;
	if (getenv("KSIM_VERBOSE")) fprintf(stderr, "[ksim %s] %s", lvl, line);
}
int ksim_log_count(const char *needle) { int n = 0; for (int i = 0; i < logn && i < LOGN; i++) if (strstr(logbuf[i], needle)) n++; return n; }
void ksim_log_clear(void) { logn = 0; }

void *ksim_dma_alloc(size_t size, u64 *bus) { uint64_t b = 0; void *p = H->alloc(H->u, size, &b); *bus = b; return p; }
void ksim_dma_free(size_t size, void *cpu, u64 bus) { (void)cpu; H->release(H->u, bus, size); }

void drm_sched_stop(struct drm_gpu_scheduler *s, struct drm_sched_job *j) { (void)s; (void)j; }
void drm_sched_start(struct drm_gpu_scheduler *s, int err) { (void)s; (void)err; }
void drm_sched_fault(struct drm_gpu_scheduler *s) { (void)s; sched_fault = 1; }
bool queue_work(struct workqueue_struct *wq, struct work_struct *w) { (void)wq; (void)w; reset_work_pending = 1; return true; }
void disable_irq(int irq) { (void)irq; irq_enabled = 0; }
void enable_irq(int irq) { (void)irq; irq_enabled = 1; }

/* ---- the two tiny functions of sfg1_ctx.c that sfg1_reset.c needs (verbatim logic) ---- */
int sfg1_ctx_usable(struct sfg1_ctx *ctx)
{
	enum sfg1_state st = READ_ONCE(ctx->sdev->state);
	if (st == SFG1_STATE_REMOVED || st == SFG1_STATE_DEAD || test_bit(SFG1_CTXF_DEVICE_GONE, &ctx->flags)) return -ENODEV;
	if (test_bit(SFG1_CTXF_BANNED, &ctx->flags)) return -ECANCELED;
	if (test_bit(SFG1_CTXF_LOST, &ctx->flags)) return -ECONNRESET;
	return 0;
}
void sfg1_ctx_note_strike(struct sfg1_ctx *ctx)
{
	if (atomic_inc_return(&ctx->strikes) >= (int)ctx->sdev->cfg.strike_limit && !test_and_set_bit(SFG1_CTXF_BANNED, &ctx->flags))
		dev_warn(ctx->sdev->dev, "context %u banned after %d hangs/errors\n", ctx->id, atomic_read(&ctx->strikes));
}
void sfg1_ctx_put(struct sfg1_ctx *ctx) { (void)ctx; }
void sfg1_result_put(struct sfg1_result *res) { if (--res->ref.refcount == 0) free(res); }

/* ------------------------------------------------------------------------ files, BOs, jobs */
#define MAXFILES 8
#define MAXBO 96
#define MAXRES 128
struct ksim_file;
struct ksim_bo { int used, closed, refs; u32 handle; u64 size, dma; void *cpu; u64 mmap_off; };
struct ksim_job {
	struct list_head node; struct sfg1_job *j; struct ksim_file *f; struct ksim_bo *bos[SFG1_MAX_CMDS_PER_SUBMIT]; int nbo;
	int pushed, nopush_done, gc;
	int hold;                  /* a waiter is using this job: gc_jobs() must not free it */
};
struct ksim_file {
	int used; struct sfg1_ctx *ctx;
	struct ksim_bo bos[MAXBO]; struct { u64 id; struct sfg1_result *res; } results[MAXRES];
};
static struct ksim_file files[MAXFILES];
static LIST_HEAD(all_jobs);

static struct ksim_file *file_of(int fd) { int i = fd - 1000; return (i >= 0 && i < MAXFILES && files[i].used) ? &files[i] : NULL; }
static bool job_complete(struct ksim_job *kj) { return kj->nopush_done || (kj->j->hw_fence && kj->j->hw_fence->signaled); }

static void bo_unref(struct ksim_bo *bo)
{
	if (--bo->refs == 0 && bo->closed) {
		H->release(H->u, bo->dma, bo->size);
		bo->used = 0;
	}
}

/* ---- sfg1_run_job() equivalent: hand a queued job to the hardware ring ---- */
static void run_job(struct ksim_job *kj)
{
	struct sfg1_job *job = kj->j; int ret;
	if (job->ctx) {
		ret = sfg1_ctx_usable(job->ctx);
		if (ret) { sfg1_job_set_result(job, DRM_SFG1_JOB_CANCELED); atomic64_inc(&job->ctx->jobs_canceled); kj->nopush_done = 1; return; }
	} else if (READ_ONCE(S.state) != SFG1_STATE_RUNNING) {
		sfg1_job_set_result(job, DRM_SFG1_JOB_CANCELED); kj->nopush_done = 1; return;
	}
	job->hw_fence_inited = true;
	kj->pushed = 1;
	ret = sfg1_ring_push_job(&S, job);
	if (ret) sfg1_job_finish(job, DRM_SFG1_JOB_CANCELED, ret);
}

static void gc_jobs(void)
{
	struct ksim_job *kj, *tmp;
	list_for_each_entry_safe(kj, tmp, &all_jobs, node) {
		if (!job_complete(kj) || kj->gc || kj->hold) continue;
		kj->gc = 1;
		for (int i = 0; i < kj->nbo; i++) bo_unref(kj->bos[i]);
		if (kj->j->ctx) atomic_dec(&kj->j->ctx->jobs_alive);
		sfg1_result_put(kj->j->res);
		free(kj->j->hw_fence); free(kj->j);
		list_del_init(&kj->node); free(kj);
	}
}

void ksim_irq(void)
{
	if (in_irq || !irq_enabled) { irq_deferred = 1; return; }
	in_irq = 1;
	if (sfg1_irq_top(S.irq, &S) == IRQ_WAKE_THREAD) sfg1_irq_thread(S.irq, &S);
	in_irq = 0;
}

/* The drm_sched role: credits (SQ capacity), the hang timer, fault / reset work, run_job order. */
void ksim_pump(void)
{
	struct ksim_job *kj, *tmp;
	if (in_pump) return;
	in_pump = 1;
	if (irq_enabled && irq_deferred) { irq_deferred = 0; ksim_irq(); }
	if (reset_work_pending) { reset_work_pending = 0; sfg1_reset_work(&S.reset_work); }
	if (sched_fault) {
		sched_fault = 0;
		struct sfg1_job *g = list_first_entry_or_null(&S.inflight, struct sfg1_job, node);
		if (g) sfg1_timedout_job(&g->base); else sfg1_reset_work(&S.reset_work);
	}
	if (S.state == SFG1_STATE_RUNNING && !list_empty(&S.inflight) &&
	    time_after(jiffies, S.last_progress + msecs_to_jiffies(S.cfg.job_timeout_ms))) {
		struct sfg1_job *g = list_first_entry(&S.inflight, struct sfg1_job, node);
		sfg1_timedout_job(&g->base);
	}
	list_for_each_entry_safe(kj, tmp, &all_jobs, node) {
		if (kj->pushed || kj->nopush_done || kj->gc) continue;
		if (S.state == SFG1_STATE_RESETTING) break;
		if (S.state == SFG1_STATE_RUNNING && kj->j->n_cmds > S.sq_free) break;          // credit limit
		run_job(kj);
		if (S.state != SFG1_STATE_RUNNING && !kj->nopush_done && !kj->pushed) break;
	}
	gc_jobs();
	in_pump = 0;
}

/* ------------------------------------------------------------------------ scrub / contexts (sfg1_ctx.c) */
static struct ksim_job *new_job(struct ksim_file *f, struct sfg1_ctx *ctx, u32 ncmds)
{
	struct ksim_job *kj = calloc(1, sizeof(*kj));
	kj->j = calloc(1, struct_size(kj->j, cmds, ncmds));
	kj->j->hw_fence = calloc(1, sizeof(*kj->j->hw_fence));
	kj->j->hw_fence->owner = kj->j;
	kj->j->res = calloc(1, sizeof(*kj->j->res));
	kref_init(&kj->j->res->ref); kj->j->res->status = SFG1_RESULT_UNSET;
	INIT_LIST_HEAD(&kj->j->node); kj->j->sdev = &S; kj->j->n_cmds = ncmds; kj->f = f; kj->j->ctx = ctx;
	INIT_LIST_HEAD(&kj->node);
	return kj;
}

enum sfg1_scrub_result sfg1_scrub_window(struct sfg1_device *sdev, u32 ctx_id)
{
	enum sfg1_scrub_result verdict = SFG1_SCRUB_TRANSIENT;
	struct ksim_job *kj = new_job(NULL, NULL, 1);
	struct sfg1_result *res = kj->j->res;
	kj->j->cmds[0].opcode = cpu_to_le16(SFG1_OP_SCRUB);
	kj->j->cmds[0].ctx_id = cpu_to_le16(ctx_id);
	kj->j->id = 0;
	res->ref.refcount++;                       /* ours */
	kj->hold = 1;                              /* we poll it across ksim_pump(), which garbage-collects finished jobs */
	list_add_tail(&kj->node, &all_jobs);
	int64_t deadline = ksim_now_ns() + (int64_t)(sdev->cfg.job_timeout_ms * 4 + 1000) * 1000000;
	while (!job_complete(kj) && ksim_now_ns() < deadline) { ksim_pump(); if (job_complete(kj)) break; ksim_advance_ns(200); }
	if (job_complete(kj)) {
		u32 st = res->status;
		if (st == DRM_SFG1_JOB_OK) verdict = SFG1_SCRUB_OK;
		else if (st == DRM_SFG1_JOB_TIMEOUT || st == DRM_SFG1_JOB_ERROR) verdict = SFG1_SCRUB_FAILED;
	}
	kj->hold = 0;
	ksim_pump();
	sfg1_result_put(res);
	return verdict;
}

static int scrub_retry(u32 ctx_id)
{
	int attempt, hard = 0;
	for (attempt = 0; attempt < 6; attempt++) {
		enum sfg1_scrub_result v = sfg1_scrub_window(&S, ctx_id);
		enum sfg1_state st = READ_ONCE(S.state);
		if (v == SFG1_SCRUB_OK) return 0;
		if (st == SFG1_STATE_DEAD || st == SFG1_STATE_REMOVED) return -ENODEV;
		if (v == SFG1_SCRUB_FAILED && ++hard >= 2) return -EIO;
		msleep(25 + 50 * attempt);
	}
	return -EAGAIN;
}

static void slot_release(struct sfg1_ctx *ctx, bool clean, bool quarantine)
{
	list_del_init(&ctx->node);
	S.slots[ctx->id].ctx = NULL;
	S.slots[ctx->id].needs_scrub = !clean;
	if (quarantine) {
		S.slots[ctx->id].quarantine_until = jiffies + msecs_to_jiffies(S.cfg.quarantine_ms) ?: 1;
		dev_warn(S.dev, "context window %u: the scrub command failed repeatedly; withheld for %u ms\n", ctx->id, S.cfg.quarantine_ms);
	}
}

int ksim_open(void)
{
	enum sfg1_state st = READ_ONCE(S.state);
	u32 i, slot = U32_MAX; int fd;
	if (st != SFG1_STATE_RUNNING && st != SFG1_STATE_RESETTING) return -ENODEV;
	for (fd = 0; fd < MAXFILES && files[fd].used; fd++) ;
	if (fd == MAXFILES) return -EMFILE;
	struct sfg1_ctx *ctx = calloc(1, sizeof(*ctx));
	kref_init(&ctx->ref); ctx->sdev = &S; INIT_LIST_HEAD(&ctx->node);
	for (i = 0; i < S.max_ctx; i++)
		if (!S.slots[i].ctx && !sfg1_slot_quarantined(&S.slots[i])) { slot = i; break; }
	if (slot == U32_MAX) { free(ctx); return -EBUSY; }          /* all hardware contexts in use */
	S.slots[slot].ctx = ctx; ctx->id = slot; ctx->serial = ++S.ctx_serial;
	bool scrub = S.slots[slot].needs_scrub;
	list_add_tail(&ctx->node, &S.ctx_list);
	if (scrub) {
		int ret = scrub_retry(slot);
		if (ret) { slot_release(ctx, false, ret == -EIO); free(ctx); return ret; }
		S.slots[slot].needs_scrub = false;
	}
	memset(&files[fd], 0, sizeof(files[fd])); files[fd].used = 1; files[fd].ctx = ctx;
	return 1000 + fd;
}

int ksim_close(int fd)
{
	struct ksim_file *f = file_of(fd);
	if (!f) return -EBADF;
	struct sfg1_ctx *ctx = f->ctx; struct ksim_job *kj, *tmp; bool clean = false, hard_fail = false;
	set_bit(SFG1_CTXF_CLOSING, &ctx->flags);
	list_for_each_entry(kj, &all_jobs, node)                          /* queued, never pushed: cancelled */
		if (kj->f == f && !kj->pushed && !kj->nopush_done) { sfg1_job_set_result(kj->j, DRM_SFG1_JOB_CANCELED); atomic64_inc(&ctx->jobs_canceled); kj->nopush_done = 1; }
	int64_t deadline = ksim_now_ns() + (int64_t)(S.cfg.job_timeout_ms * 4 + 1000) * 1000000;
	while (atomic_read(&ctx->jobs_alive) && ksim_now_ns() < deadline) { ksim_pump(); ksim_advance_ns(500); }
	if (!atomic_read(&ctx->jobs_alive)) {
		st: ;
		enum sfg1_state s = READ_ONCE(S.state);
		if (s == SFG1_STATE_RUNNING || s == SFG1_STATE_RESETTING) { int sr = scrub_retry(ctx->id); clean = sr == 0; hard_fail = sr == -EIO; }
	} else dev_warn(S.dev, "context %u: jobs still alive at close; window will be scrubbed on reuse\n", ctx->id);
	slot_release(ctx, clean, hard_fail);
	for (int i = 0; i < MAXRES; i++) if (f->results[i].res) { sfg1_result_put(f->results[i].res); f->results[i].res = NULL; }
	for (int i = 0; i < MAXBO; i++) if (f->bos[i].used && !f->bos[i].closed) { f->bos[i].closed = 1; bo_unref(&f->bos[i]); }
	(void)tmp; free(ctx);
	f->used = 0;
	return 0;
}

/* ------------------------------------------------------------------------ ioctls */
static u64 total_bo_bytes;
static int bo_create(struct ksim_file *f, struct drm_sfg1_bo_create *a)
{
	struct sfg1_ctx *ctx = f->ctx; int ret, i, n = 0; u64 size, bytes = 0;
	if (a->flags || a->reserved) return -EINVAL;
	if (!a->size || a->size > CFG.max_bo_size) return -EINVAL;
	size = (a->size + PAGE_SIZE - 1) & ~(u64)(PAGE_SIZE - 1);
	ret = sfg1_ctx_usable(ctx); if (ret) return ret;
	for (i = 0; i < MAXBO; i++) if (f->bos[i].used) { n++; bytes += f->bos[i].size; }
	if (n + 1 > (int)CFG.max_bos) return -ENOSPC;
	if (bytes + size > CFG.max_bo_bytes_per_ctx) return -ENOSPC;
	if (total_bo_bytes + size > CFG.max_total_bo_bytes) return -ENOSPC;
	for (i = 0; i < MAXBO && f->bos[i].used; i++) ;
	if (i == MAXBO) return -ENOSPC;
	struct ksim_bo *bo = &f->bos[i]; uint64_t bus = 0;
	bo->cpu = H->alloc(H->u, size, &bus); bo->dma = bus; bo->size = size; bo->used = 1; bo->closed = 0; bo->refs = 1;
	memset(bo->cpu, 0, size);                                                 /* never rely on the allocator for isolation */
	bo->handle = i + 1; bo->mmap_off = ((u64)(1000 + (int)(f - files)) << 40) | ((u64)bo->handle << 20);
	total_bo_bytes += size;
	a->handle = bo->handle; a->mmap_offset = bo->mmap_off; a->real_size = size;
	return 0;
}

static int range_ok(u64 off, u64 len, u64 limit) { return len <= limit && off <= limit - len; }
static int win_check(u64 off, u64 len) { return range_ok(off, len, S.ctx_win_size) ? 0 : -EINVAL; }

/* sfg1_build_cmd(), kernel/sfg1_job.c: same checks, same order, same error codes */
static int build_cmd(struct ksim_file *f, struct ksim_job *kj, struct sfg1_ctx *ctx, const struct drm_sfg1_cmd *c, struct sfg1_sq_entry *e)
{
	u64 bytes_in, bytes_c, a_len, b_len, c_len; struct ksim_bo *bo;
	if (c->reserved) return -EINVAL;
	memset(e, 0, sizeof(*e));
	e->opcode = cpu_to_le16(c->op);
	e->ctx_id = cpu_to_le16(ctx->id);
	switch (c->op) {
	case DRM_SFG1_OP_NOP:
		if (c->flags || c->bo_handle || c->exec_op || c->bo_offset || c->len || c->dev_a || c->dev_b || c->dev_c) return -EINVAL;
		return 0;
	case DRM_SFG1_OP_DMA_H2D:
	case DRM_SFG1_OP_DMA_D2H:
		if (c->flags || c->exec_op || c->dev_b || c->dev_c) return -EINVAL;
		if (!c->len || !IS_ALIGNED(c->len, 4) || !IS_ALIGNED(c->bo_offset, 4) || !IS_ALIGNED(c->dev_a, 4)) return -EINVAL;
		if (!c->bo_handle || c->bo_handle > MAXBO || !f->bos[c->bo_handle - 1].used || f->bos[c->bo_handle - 1].closed) return -ENOENT;
		bo = &f->bos[c->bo_handle - 1];
		{ int dup = 0; for (int i = 0; i < kj->nbo; i++) dup |= kj->bos[i] == bo;
		  if (!dup) { if (kj->nbo >= (int)SFG1_MAX_CMDS_PER_SUBMIT) return -EINVAL; kj->bos[kj->nbo++] = bo; bo->refs++; } }
		if (!range_ok(c->bo_offset, c->len, bo->size)) return -EINVAL;
		{ int r = win_check(c->dev_a, c->len); if (r) return r; }
		e->host_addr = cpu_to_le64(bo->dma + c->bo_offset);
		e->len = cpu_to_le64(c->len); e->dev_a = cpu_to_le64(c->dev_a);
		return 0;
	case DRM_SFG1_OP_VEC:
		if (!(S.caps & SFG1_CAP_VEC) || c->flags || c->bo_handle || c->bo_offset) return -EINVAL;
		if (c->exec_op > DRM_SFG1_VEC_DOT8 || !c->len) return -EINVAL;
		if (!IS_ALIGNED(c->dev_a, 4) || !IS_ALIGNED(c->dev_b, 4) || !IS_ALIGNED(c->dev_c, 4)) return -EINVAL;
		if (check_mul_overflow(c->len, 4ULL, &bytes_in)) return -EINVAL;
		a_len = bytes_in; b_len = (c->exec_op == DRM_SFG1_VEC_RELU8) ? 0 : bytes_in; c_len = (c->exec_op == DRM_SFG1_VEC_DOT8) ? 4 : bytes_in;
		if (c->exec_op == DRM_SFG1_VEC_RELU8 && c->dev_b) return -EINVAL;
		if (win_check(c->dev_a, a_len) || (b_len && win_check(c->dev_b, b_len)) || win_check(c->dev_c, c_len)) return -EINVAL;
		e->exec_op = cpu_to_le32(c->exec_op); e->len = cpu_to_le64(c->len);
		e->dev_a = cpu_to_le64(c->dev_a); e->dev_b = cpu_to_le64(c->dev_b); e->dev_c = cpu_to_le64(c->dev_c);
		return 0;
	case DRM_SFG1_OP_TEN:
		if (!(S.caps & SFG1_CAP_TEN) || (c->flags & ~SFG1_CMDF_VALID_MASK) || c->bo_handle || c->bo_offset || c->exec_op || !c->len) return -EINVAL;
		if (!IS_ALIGNED(c->dev_a, 4) || !IS_ALIGNED(c->dev_b, 4) || !IS_ALIGNED(c->dev_c, 4)) return -EINVAL;
		if (check_mul_overflow(c->len, 16ULL, &bytes_in) || check_mul_overflow(c->len, 64ULL, &bytes_c)) return -EINVAL;
		if (win_check(c->dev_a, bytes_in) || win_check(c->dev_b, bytes_in) || win_check(c->dev_c, bytes_c)) return -EINVAL;
		e->flags = cpu_to_le16(c->flags); e->len = cpu_to_le64(c->len);
		e->dev_a = cpu_to_le64(c->dev_a); e->dev_b = cpu_to_le64(c->dev_b); e->dev_c = cpu_to_le64(c->dev_c);
		return 0;
	default:
		return -EINVAL;      /* includes SCRUB (kernel only) and every unknown opcode */
	}
}

static int do_submit(struct ksim_file *f, struct drm_sfg1_submit *a)
{
	struct sfg1_ctx *ctx = f->ctx;
	const u32 max_cmds = min_t(u32, SFG1_MAX_CMDS_PER_SUBMIT, S.sq.entries - 1);
	int ret; u32 i;
	if (a->flags || a->pad || a->reserved) return -EINVAL;
	if (!a->cmd_count || a->cmd_count > max_cmds) return -EINVAL;
	if (a->cmd_stride < DRM_SFG1_CMD_SIZE_V1 || a->cmd_stride > PAGE_SIZE || !IS_ALIGNED(a->cmd_stride, 8)) return -EINVAL;
	if (!a->cmds_ptr) return -EFAULT;
	ret = sfg1_ctx_usable(ctx); if (ret) return ret;
	if (atomic_inc_return(&ctx->jobs_alive) > (int)S.cfg.max_inflight_jobs) { ret = -EBUSY; goto err_alive; }
	if (atomic_inc_return(&ctx->unreaped) > (int)S.cfg.max_pending_results) { ret = -EBUSY; goto err_unreaped; }
	struct ksim_job *kj = new_job(f, ctx, a->cmd_count);
	for (i = 0; i < a->cmd_count; i++) {
		struct drm_sfg1_cmd c; const unsigned char *src = (const unsigned char *)(uintptr_t)a->cmds_ptr + (size_t)i * a->cmd_stride;
		memcpy(&c, src, sizeof(c));
		for (u32 k = sizeof(c); k < a->cmd_stride; k++) if (src[k]) { ret = -E2BIG; goto err_job; }     /* copy_struct_from_user() */
		ret = build_cmd(f, kj, ctx, &c, &kj->j->cmds[i]);
		if (ret) goto err_job;
	}
	kj->j->id = (u64)++ctx->job_seq.counter;
	int slot; for (slot = 0; slot < MAXRES && f->results[slot].res; slot++) ;
	if (slot == MAXRES) { ret = -ENOMEM; goto err_job; }
	kj->j->res->id = kj->j->id; f->results[slot].id = kj->j->id; f->results[slot].res = kj->j->res; kj->j->res->ref.refcount++;   /* the table's reference */
	atomic64_inc(&ctx->jobs_submitted); atomic64_add(a->cmd_count, &ctx->cmds_submitted);
	a->job_id = kj->j->id;
	list_add_tail(&kj->node, &all_jobs);
	ksim_pump();
	return 0;
err_job:
	for (int i2 = 0; i2 < kj->nbo; i2++) bo_unref(kj->bos[i2]);
	sfg1_result_put(kj->j->res); free(kj->j->hw_fence); free(kj->j); free(kj);
err_unreaped:
	atomic_dec(&ctx->unreaped);
err_alive:
	atomic_dec(&ctx->jobs_alive);
	return ret;
}

static int do_wait(struct ksim_file *f, struct drm_sfg1_wait_job *a)
{
	struct sfg1_result *res = NULL; struct ksim_job *kj = NULL, *it; int slot, rc = 0;
	if (a->flags || a->pad || a->reserved) return -EINVAL;
	for (slot = 0; slot < MAXRES; slot++) if (f->results[slot].res && f->results[slot].id == a->job_id) { res = f->results[slot].res; break; }
	if (!res) return -ENOENT;
	list_for_each_entry(it, &all_jobs, node) if (it->j->res == res && !it->gc) kj = it;
	if (kj) kj->hold++;                              /* ksim_pump() below may garbage-collect finished jobs */
	int64_t deadline;
	if (a->timeout_ns == 0) deadline = 0;
	else if (a->timeout_ns == INT64_MAX) deadline = INT64_MAX;
	else {                                           /* absolute CLOCK_MONOTONIC -> simulated time */
		struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
		int64_t rel = a->timeout_ns - ((int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec);
		deadline = rel <= 0 ? 0 : ksim_now_ns() + rel;
	}
	res->ref.refcount++;
	for (;;) {
		ksim_pump();
		if (!kj || job_complete(kj) || res->status != SFG1_RESULT_UNSET) break;
		if (a->timeout_ns == 0) { rc = -EBUSY; break; }
		if (deadline != INT64_MAX && ksim_now_ns() >= deadline) { rc = -ETIMEDOUT; break; }
		ksim_advance_ns(200);
	}
	if (!rc) {
		u32 st = smp_load_acquire(&res->status);
		if (st == SFG1_RESULT_UNSET) st = (kj && kj->j->hw_fence && kj->j->hw_fence->error) ? DRM_SFG1_JOB_CANCELED : DRM_SFG1_JOB_OK;
		a->status = st; a->dev_error = READ_ONCE(res->dev_error);
		f->results[slot].res = NULL; atomic_dec(&f->ctx->unreaped);
		sfg1_result_put(res);                         /* the table's reference */
	}
	if (kj) kj->hold--;
	sfg1_result_put(res);                             /* ours */
	ksim_pump();
	return rc;
}

/* Test hook: queue ONE job made of caller-supplied 64-byte SQ entries, bypassing sfg1_build_cmd().
 * Models "a patched driver emitting bad descriptors" (docs/07-hw-bringup.md section 3) so the
 * DEVICE-side checks can be exercised through the real ring code. cid and ctx_id are NOT touched. */
int ksim_raw_submit(int fd, const void *sqes, uint32_t n, uint64_t *job_id)
{
	struct ksim_file *f = file_of(fd);
	if (!f || !n || n > S.sq.entries - 1) return -EINVAL;
	struct sfg1_ctx *ctx = f->ctx; int slot;
	atomic_inc(&ctx->jobs_alive); atomic_inc(&ctx->unreaped);
	struct ksim_job *kj = new_job(f, ctx, n);
	memcpy(kj->j->cmds, sqes, (size_t)n * sizeof(struct sfg1_sq_entry));
	kj->j->id = (u64)++ctx->job_seq.counter;
	for (slot = 0; slot < MAXRES && f->results[slot].res; slot++) ;
	if (slot == MAXRES) return -ENOMEM;
	kj->j->res->id = kj->j->id; f->results[slot].id = kj->j->id; f->results[slot].res = kj->j->res; kj->j->res->ref.refcount++;
	atomic64_inc(&ctx->jobs_submitted); atomic64_add(n, &ctx->cmds_submitted);
	*job_id = kj->j->id;
	list_add_tail(&kj->node, &all_jobs);
	ksim_pump();
	return 0;
}
uint32_t ksim_sq_free(void) { return S.sq_free; }
uint32_t ksim_sq_entries(void) { return S.sq.entries; }
uint64_t ksim_bo_bus(int fd, uint32_t handle) { struct ksim_file *f = file_of(fd); return (f && handle && handle <= MAXBO && f->bos[handle - 1].used) ? f->bos[handle - 1].dma : 0; }
unsigned ksim_ctx_flags(int fd) { struct ksim_file *f = file_of(fd); return f ? (unsigned)f->ctx->flags : 0xffffffffu; }
unsigned ksim_ctx_id(int fd) { struct ksim_file *f = file_of(fd); return f ? f->ctx->id : 0xffffffffu; }
uint32_t ksim_hw_caps(void) { return S.caps; }

int ksim_ioctl(int fd, unsigned long req, void *arg)
{
	struct ksim_file *f = file_of(fd);
	if (!f) return -EBADF;
	if (req == DRM_IOCTL_GEM_CLOSE) {
		struct drm_gem_close *c = arg;
		if (!c->handle || c->handle > MAXBO || !f->bos[c->handle - 1].used || f->bos[c->handle - 1].closed) return -EINVAL;
		struct ksim_bo *bo = &f->bos[c->handle - 1];
		total_bo_bytes -= bo->size; bo->closed = 1; bo_unref(bo);
		return 0;
	}
	if (req == DRM_IOCTL_PRIME_HANDLE_TO_FD || req == DRM_IOCTL_PRIME_FD_TO_HANDLE) return -EPERM;   /* dma-buf sharing is blocked */
	if (req == DRM_IOCTL_SFG1_BO_CREATE) return bo_create(f, arg);
	if (req == DRM_IOCTL_SFG1_SUBMIT) return do_submit(f, arg);
	if (req == DRM_IOCTL_SFG1_WAIT_JOB) return do_wait(f, arg);
	if (req == DRM_IOCTL_SFG1_GET_PARAM) {
		struct drm_sfg1_get_param *p = arg; struct sfg1_ctx *ctx = f->ctx;
		if (p->pad) return -EINVAL;
		switch (p->param) {
		case DRM_SFG1_PARAM_UAPI_VERSION: p->value = (DRM_SFG1_UAPI_MAJOR << 16) | DRM_SFG1_UAPI_MINOR; break;
		case DRM_SFG1_PARAM_HW_VERSION: p->value = S.hw_version; break;
		case DRM_SFG1_PARAM_HW_CAPS: p->value = S.caps; break;
		case DRM_SFG1_PARAM_CTX_ID: p->value = ctx->id; break;
		case DRM_SFG1_PARAM_CTX_WINDOW_SIZE: p->value = S.ctx_win_size; break;
		case DRM_SFG1_PARAM_MAX_BO_SIZE: p->value = CFG.max_bo_size; break;
		case DRM_SFG1_PARAM_MAX_BOS: p->value = CFG.max_bos; break;
		case DRM_SFG1_PARAM_MAX_BO_BYTES: p->value = CFG.max_bo_bytes_per_ctx; break;
		case DRM_SFG1_PARAM_MAX_CMDS_PER_SUBMIT: p->value = min_t(u32, SFG1_MAX_CMDS_PER_SUBMIT, S.sq.entries - 1); break;
		case DRM_SFG1_PARAM_MAX_INFLIGHT_JOBS: p->value = S.cfg.max_inflight_jobs; break;
		case DRM_SFG1_PARAM_MAX_PENDING_RESULTS: p->value = S.cfg.max_pending_results; break;
		case DRM_SFG1_PARAM_JOB_TIMEOUT_MS: p->value = S.cfg.job_timeout_ms; break;
		case DRM_SFG1_PARAM_CTX_STATE: p->value = ctx->flags & 7; break;
		case DRM_SFG1_PARAM_VEC_OPS: p->value = 0xff; break;
		default: return -EINVAL;
		}
		return 0;
	}
	if (req == DRM_IOCTL_SFG1_GET_STATS) {
		struct drm_sfg1_get_stats *s = arg; struct sfg1_ctx *c = f->ctx;
		for (int i = 0; i < 4; i++) if (s->reserved[i]) return -EINVAL;
		memset(s, 0, sizeof(*s));
		s->ctx_id = c->id; s->ctx_state = c->flags & 7;
		s->jobs_submitted = c->jobs_submitted.counter; s->jobs_ok = c->jobs_ok.counter; s->jobs_error = c->jobs_error.counter;
		s->jobs_timeout = c->jobs_timeout.counter; s->jobs_canceled = c->jobs_canceled.counter; s->cmds_submitted = c->cmds_submitted.counter;
		s->busy_ns = c->busy_ns.counter; s->device_engine_resets = S.engine_resets; s->device_func_resets = S.func_resets;
		return 0;
	}
	return -ENOTTY;
}

void *ksim_mmap(int fd, size_t len, long off)
{
	struct ksim_file *f = file_of(fd);
	if (!f) return NULL;
	for (int i = 0; i < MAXBO; i++)
		if (f->bos[i].used && !f->bos[i].closed && f->bos[i].mmap_off == (u64)off && len <= f->bos[i].size) return f->bos[i].cpu;
	return NULL;       /* another file's offset, or unknown: refused */
}

/* ------------------------------------------------------------------------ probe */
static u32 be_rd(struct sfg1_device *s, u32 off) { (void)s; return H->rd32(H->u, off); }
static void be_wr(struct sfg1_device *s, u32 off, u32 v) { (void)s; H->wr32(H->u, off, v); }
static const struct sfg1_backend_ops BE = { .rd32 = be_rd, .wr32 = be_wr };

void ksim_default_cfg(struct ksim_cfg *c)
{
	memset(c, 0, sizeof(*c));
	c->queue_entries = 64; c->job_timeout_ms = 10; c->reset_timeout_ms = 10; c->strike_limit = 3; c->quarantine_ms = 100;
	c->max_bos = 64; c->max_inflight_jobs = 16; c->max_pending_results = 32;
	c->max_bo_size = 1u << 20; c->max_bo_bytes_per_ctx = 2u << 20; c->max_total_bo_bytes = 4u << 20;
}

int ksim_probe(const struct ksim_host_ops *h, const struct ksim_cfg *c)
{
	int ret;
	H = h; CFG = *c; memset(&S, 0, sizeof(S)); memset(files, 0, sizeof(files)); INIT_LIST_HEAD(&all_jobs);
	irq_enabled = 1; irq_deferred = in_irq = sched_fault = reset_work_pending = in_pump = 0; total_bo_bytes = 0; logn = 0;
	S.dev = &DEV; S.ops = &BE;
	S.cfg.queue_entries = c->queue_entries; S.cfg.job_timeout_ms = c->job_timeout_ms; S.cfg.reset_timeout_ms = c->reset_timeout_ms;
	S.cfg.strike_limit = c->strike_limit; S.cfg.quarantine_ms = c->quarantine_ms; S.cfg.max_bos = c->max_bos;
	S.cfg.max_inflight_jobs = c->max_inflight_jobs; S.cfg.max_pending_results = c->max_pending_results;
	spin_lock_init(&S.ring_lock); spin_lock_init(&S.fence_lock);
	mutex_init(&S.ctx_lock); mutex_init(&S.bo_lock); mutex_init(&S.reset_lock);
	INIT_LIST_HEAD(&S.inflight); INIT_LIST_HEAD(&S.ctx_list); INIT_LIST_HEAD(&S.bo_list);
	S.state = SFG1_STATE_INIT;
	ret = sfg1_hw_discover(&S);                       /* REAL: discovery sequence of contract section 2 */
	if (ret) return ret;
	S.cfg.queue_entries = min(S.cfg.queue_entries, S.max_qent);
	S.slots = calloc(S.max_ctx, sizeof(*S.slots));
	for (u32 i = 0; i < S.max_ctx; i++) S.slots[i].needs_scrub = true;     /* power-up content unknown */
	ret = sfg1_rings_alloc(&S); if (ret) return ret;
	S.irq = 1; S.irq_requested = true;
	ret = sfg1_hw_start(&S);                          /* REAL: program queues, enable */
	if (ret) return ret;
	S.state = SFG1_STATE_RUNNING;
	return 0;
}
void ksim_remove(void) { sfg1_hw_quiesce(&S); S.state = SFG1_STATE_REMOVED; }
int ksim_dev_state(void) { return S.state; }
uint64_t ksim_engine_resets(void) { return S.engine_resets; }
uint64_t ksim_func_resets(void) { return S.func_resets; }
