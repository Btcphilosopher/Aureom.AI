/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Force-included (-include) when compiling the driver package's UNMODIFIED example programs and
 * the runtime for simulation: redirects the libc calls that sfg1_user.h makes (open, ioctl, mmap,
 * opendir ...) to the userspace driver simulation. Without this header the same sources talk to a
 * real /dev/accel/accelN. System headers are included first so only the call sites are renamed.
 */
#ifndef KSIM_LIBC_H
#define KSIM_LIBC_H
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>
#ifdef __cplusplus
extern "C" {
#endif
int kl_open(const char *path, int flags, ...);
int kl_close(int fd);
int kl_ioctl(int fd, unsigned long req, void *arg);
void *kl_mmap(void *addr, size_t len, int prot, int flags, int fd, off_t off);
int kl_munmap(void *addr, size_t len);
DIR *kl_opendir(const char *path);
struct dirent *kl_readdir(DIR *d);
int kl_closedir(DIR *d);
#ifdef __cplusplus
}
#endif
#define open kl_open
#define close kl_close
#define ioctl kl_ioctl
#define mmap kl_mmap
#define munmap kl_munmap
#define opendir kl_opendir
#define readdir kl_readdir
#define closedir kl_closedir
#endif
