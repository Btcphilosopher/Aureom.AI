// SPDX-License-Identifier: GPL-2.0-only
// Implementation of the redirected libc calls (see ksim_libc.h). NOT compiled with the redirection.
#define _GNU_SOURCE
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <string.h>
#include <sys/mman.h>
#include <drm/drm.h>
#include "ksim.h"

int kl_open(const char *path, int flags, ...)
{
	(void)flags;
	if (strncmp(path, "/dev/accel/accel", 16)) { errno = ENOENT; return -1; }
	int fd = ksim_open();
	if (fd < 0) { errno = -fd; return -1; }
	return fd;
}
int kl_close(int fd) { int r = ksim_close(fd); if (r) { errno = -r; return -1; } return 0; }
int kl_ioctl(int fd, unsigned long req, void *arg) { int r = ksim_ioctl(fd, req, arg); if (r) { errno = -r; return -1; } return 0; }
void *kl_mmap(void *addr, size_t len, int prot, int flags, int fd, off_t off)
{
	(void)addr; (void)prot; (void)flags;
	void *p = ksim_mmap(fd, len, (long)off);
	if (!p) { errno = EACCES; return MAP_FAILED; }
	return p;
}
int kl_munmap(void *addr, size_t len) { (void)addr; (void)len; return 0; }
static int dir_state;
DIR *kl_opendir(const char *path) { if (strcmp(path, "/dev/accel")) { errno = ENOENT; return NULL; } dir_state = 0; return (DIR *)&dir_state; }
struct dirent *kl_readdir(DIR *d)
{
	static struct dirent e; (void)d;
	if (dir_state++) return NULL;
	memset(&e, 0, sizeof(e)); strcpy(e.d_name, "accel0");
	return &e;
}
int kl_closedir(DIR *d) { (void)d; return 0; }
