/* SPDX-License-Identifier: GPL-2.0-only */
/* ksim: userspace simulation of the SF-G1 Linux driver on top of the RTL co-simulation. */
#ifndef KSIM_H
#define KSIM_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
struct ksim_host_ops {
	void *u;
	uint32_t (*rd32)(void *u, uint32_t off);              /* BAR0 read  (completion waits for posted writes) */
	void (*wr32)(void *u, uint32_t off, uint32_t v);      /* BAR0 write */
	void (*tick)(void *u, uint64_t cycles);               /* advance the RTL; interrupts call ksim_irq() */
	uint64_t (*cycle)(void *u);
	void *(*alloc)(void *u, uint64_t size, uint64_t *bus); /* zeroed host memory, 4 KiB aligned; returns CPU pointer */
	void (*release)(void *u, uint64_t bus, uint64_t size);
	double clock_mhz;                                     /* simulated device clock: converts cycles to driver time */
};
struct ksim_cfg {
	uint32_t queue_entries, job_timeout_ms, reset_timeout_ms, strike_limit, quarantine_ms;
	uint32_t max_bos, max_inflight_jobs, max_pending_results;
	uint64_t max_bo_bytes_per_ctx, max_bo_size, max_total_bo_bytes;
};
void ksim_default_cfg(struct ksim_cfg *c);
int  ksim_probe(const struct ksim_host_ops *h, const struct ksim_cfg *c);   /* real sfg1_hw_discover/rings_alloc/hw_start */
void ksim_remove(void);
void ksim_irq(void);                                     /* an interrupt message arrived */
void ksim_pump(void);                                    /* scheduler step: push jobs, hang timeout, recovery */
int  ksim_open(void);                                    /* fd >= 1000 or -errno */
int  ksim_close(int fd);
int  ksim_ioctl(int fd, unsigned long req, void *arg);   /* 0 or -errno */
void *ksim_mmap(int fd, size_t len, long off);           /* pointer into simulated host memory, or NULL */
/* introspection for tests */
int      ksim_dev_state(void);                           /* 0 INIT 1 RUNNING 2 RESETTING 3 DEAD 4 REMOVED */
uint64_t ksim_engine_resets(void);
uint64_t ksim_func_resets(void);
int      ksim_log_count(const char *needle);
void     ksim_log_clear(void);
unsigned ksim_ctx_flags(int fd);
unsigned ksim_ctx_id(int fd);
uint32_t ksim_hw_caps(void);
int      ksim_raw_submit(int fd, const void *sqes, uint32_t n, uint64_t *job_id);   /* bypass validation: device-side checks */
uint32_t ksim_sq_free(void);
uint32_t ksim_sq_entries(void);
uint64_t ksim_bo_bus(int fd, uint32_t handle);                                      /* bus address of a BO (tests) */
#ifdef __cplusplus
}
#endif
#endif
