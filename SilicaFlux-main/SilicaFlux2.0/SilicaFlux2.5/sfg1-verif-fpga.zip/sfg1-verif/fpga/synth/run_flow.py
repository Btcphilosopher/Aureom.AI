#!/usr/bin/env python3
"""Open FPGA flow for the SF-G1 bring-up top: Yosys (synth_ecp5) -> nextpnr-ecp5 -> ecppack.

  fpga/synth/run_flow.py --variant v3 --mhz 100 [--seeds 1,2,3] [--out build/fpga]

Target: Lattice LFE5U-85F, package CABGA381, speed grade 6 (ULX3S-85F). Writes a JSON summary
(reports/results/fpga_<variant>_<mhz>.json) with what the TOOLS report:
  * synthesis resource counts (Yosys 'stat')             -> "synthesis estimate"
  * post-place-and-route resource use and Fmax (nextpnr) -> "implementation (static timing) result"
Neither is a measurement of hardware. Run from the project root (the WASM tools only see the cwd).
"""
import argparse, hashlib, json, os, re, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(ROOT)
VAR = {"v0": dict(FETCH_BURST=0, DMA_BURST=1, VEC_MODE=0, TEN_MODE=0), "v1": dict(FETCH_BURST=1, DMA_BURST=64, VEC_MODE=0, TEN_MODE=0),
       "v2": dict(FETCH_BURST=1, DMA_BURST=64, VEC_MODE=1, TEN_MODE=0), "v3": dict(FETCH_BURST=1, DMA_BURST=64, VEC_MODE=1, TEN_MODE=1),
       "v4": dict(FETCH_BURST=1, DMA_BURST=64, VEC_MODE=1, TEN_MODE=1, PIPE=1),
       "v5": dict(FETCH_BURST=1, DMA_BURST=64, VEC_MODE=1, TEN_MODE=1, PIPE=2)}
SRC = ["rtl/sfg1_cmdchk.sv", "rtl/sfg1_vecalu.sv", "rtl/sfg1_devmem.sv", "rtl/sfg1_frontend.sv", "rtl/sfg1_hbus.sv", "rtl/sfg1_perf.sv",
       "rtl/sfg1_engine.sv", "rtl/sfg1_core.sv", "rtl/fpga/sfg1_uart.sv", "rtl/fpga/sfg1_hostram.sv", "rtl/fpga/sfg1_bridge.sv", "rtl/fpga/sfg1_fpga_top.sv"]

def tool(name, args, log):
    t0 = time.time()
    r = subprocess.run([name] + args, capture_output=True, text=True)
    open(log, "w").write(r.stdout + "\n" + r.stderr)
    return r.returncode, r.stdout + r.stderr, time.time() - t0

def stat_counts(txt):
    c = {}
    for k in ["LUT4", "PFUMX", "L6MUX21", "TRELLIS_FF", "DP16KD", "MULT18X18D", "ALU54B", "CCU2C", "TRELLIS_DPR16X4", "EHXPLLL"]:
        m = re.findall(r"^\s+(\d+)\s+" + k + r"\b", txt, re.M)
        c[k] = int(m[-1]) if m else 0
    return c

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", default="v0"); ap.add_argument("--mhz", type=int, default=50)
    ap.add_argument("--seeds", default="1"); ap.add_argument("--out", default="build/fpga")
    ap.add_argument("--abc9", action="store_true"); ap.add_argument("--tag", default="")
    ap.add_argument("--rtl", default="rtl", help="RTL directory (default: rtl); used by scripts/ab_o6.sh to build an A/B copy")
    ap.add_argument("--ctx", type=int, default=4); ap.add_argument("--win", type=int, default=16)
    a = ap.parse_args()
    v = VAR[a.variant]; name = f"{a.variant}{a.tag}_{a.mhz}"
    out = os.path.join(a.out, name); os.makedirs(out, exist_ok=True)
    pll = f"{a.rtl}/fpga/pll_{a.mhz}.v"
    if not os.path.exists(pll): sys.exit(f"no PLL file {pll}; generate with: yowasp-ecppll -i 25 -o {a.mhz} --module sfg1_pll --file {pll}")
    params = " ".join(f"-set {k} {val}" for k, val in dict(v, CORE_MHZ=a.mhz, MAX_CTX=a.ctx, WIN_KIB=a.win).items())
    src = [x.replace("rtl/", a.rtl + "/", 1) for x in SRC]
    ys = f"""read_verilog -sv -I {a.rtl} {' '.join(src)} {pll}
chparam {params} sfg1_fpga_top
hierarchy -top sfg1_fpga_top
synth_ecp5 {'-abc9 ' if a.abc9 else ''}-top sfg1_fpga_top -json {out}/synth.json
tee -o {out}/synth.stat stat
"""
    open(f"{out}/synth.ys", "w").write(ys)
    rc, txt, ts = tool("yowasp-yosys", ["-q", "-s", f"{out}/synth.ys"], f"{out}/synth.log")
    if rc: sys.exit("yosys failed:\n" + txt[-2000:])
    syn = stat_counts(open(f"{out}/synth.stat").read())
    summary = dict(variant=a.variant, tag=a.tag, rtl=a.rtl, params=v, core_mhz_target=a.mhz, ctx=a.ctx, win_kib=a.win, abc9=a.abc9,
                   synthesis=dict(counts=syn, seconds=round(ts, 1)), pnr=[])
    for seed in [int(s) for s in a.seeds.split(",")]:
        pre = f"{out}/s{seed}"
        rc, txt, tp = tool("yowasp-nextpnr-ecp5", ["--85k", "--package", "CABGA381", "--speed", "6", "--json", f"{out}/synth.json",
                           "--lpf", "fpga/constraints/ulx3s.lpf", "--seed", str(seed), "--textcfg", f"{pre}.config",
                           "--report", f"{pre}.report.json", "--log", f"{pre}.log"], f"{pre}.stdout")
        log = open(f"{pre}.log").read() if os.path.exists(f"{pre}.log") else txt
        fm = re.findall(r"Max frequency for clock\s+'([^']+)':\s+([0-9.]+) MHz \((PASS|FAIL) at ([0-9.]+) MHz\)", log)
        util = dict((m[0], (int(m[1]), int(m[2]))) for m in re.findall(r"^Info:\s+(\w+):\s+(\d+)/\s*(\d+)\s+\d+%", log, re.M)) if False else {}
        util = {}
        for m in re.finditer(r"Info:\s+([A-Z0-9_]+):\s+(\d+)/\s*(\d+)\s+(\d+)%", log):
            util[m.group(1)] = (int(m.group(2)), int(m.group(3)))
        by_clk = {}
        for c, f, pf, t in fm: by_clk.setdefault(c, []).append((float(f), pf == "PASS", float(t)))
        fmax = [dict(clock=c, mhz_final=v[-1][0], met=v[-1][1], constraint_mhz=v[-1][2], mhz_pre_route_estimate=v[0][0]) for c, v in by_clk.items()]
        res = dict(seed=seed, ok=(rc == 0 or any(x["met"] is False for x in fmax)), nextpnr_rc=rc, seconds=round(tp, 1), fmax=fmax, utilisation=util)
        rc = 0 if fmax else rc            # nextpnr exits non-zero when timing is not met; the bitstream is still produced
        if rc == 0:
            rc2, t2, _ = tool("yowasp-ecppack", ["--compress", f"{pre}.config", f"{pre}.bit"], f"{pre}.pack.log")
            if rc2 == 0 and os.path.exists(f"{pre}.bit"):
                res["bitstream"] = dict(path=f"{pre}.bit", sha256=hashlib.sha256(open(f"{pre}.bit", "rb").read()).hexdigest(), bytes=os.path.getsize(f"{pre}.bit"))
        else: res["error"] = log[-800:]
        summary["pnr"].append(res)
        print(f"{name} seed {seed}: " + ("; ".join(f"{x['mhz_final']:.1f} MHz final ({'PASS' if x['met'] else 'FAIL'} @ {x['constraint_mhz']:.0f}), pre-route est. {x['mhz_pre_route_estimate']:.1f}" for x in res["fmax"] if "glbnet" in x["clock"] or True) or "no timing result") + f"  [{tp:.0f}s]", flush=True)
    os.makedirs("reports/results", exist_ok=True)
    json.dump(summary, open(f"reports/results/fpga_{name}.json", "w"), indent=1)

main()
