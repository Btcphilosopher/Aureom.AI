# SF-G1 core -- Xilinx Vivado out-of-context synthesis + timing (ALTERNATIVE flow).
#
# STATUS: NOT RUN. Vivado is not available in this project's environment, so nothing below has been
# executed, no number from it exists anywhere in the reports, and the script may need adjustment for
# your Vivado version. It is provided so a team with a licence can obtain a second, independent
# resource/timing estimate for the same RTL on an Artix-7 (the part used by the repository's older
# SilicaFlux Arty A7-100T scripts). Out of context: no pins, no PCIe shell.
#
#   vivado -mode batch -source fpga/synth/vivado_synth.tcl -tclargs v4 100 xc7a100tcsg324-1
set variant [lindex $argv 0]; if {$variant eq ""} {set variant v4}
set mhz     [lindex $argv 1]; if {$mhz eq ""}     {set mhz 100}
set part    [lindex $argv 2]; if {$part eq ""}    {set part xc7a100tcsg324-1}
array set P {
  v0 {FETCH_BURST 0 DMA_BURST 1  VEC_MODE 0 TEN_MODE 0 PIPE 0}
  v1 {FETCH_BURST 1 DMA_BURST 64 VEC_MODE 0 TEN_MODE 0 PIPE 0}
  v2 {FETCH_BURST 1 DMA_BURST 64 VEC_MODE 1 TEN_MODE 0 PIPE 0}
  v3 {FETCH_BURST 1 DMA_BURST 64 VEC_MODE 1 TEN_MODE 1 PIPE 0}
  v4 {FETCH_BURST 1 DMA_BURST 64 VEC_MODE 1 TEN_MODE 1 PIPE 1}
  v5 {FETCH_BURST 1 DMA_BURST 64 VEC_MODE 1 TEN_MODE 1 PIPE 2}
}
set out build/vivado_${variant}_${mhz}
file mkdir $out
read_verilog -sv [glob rtl/sfg1_cmdchk.sv rtl/sfg1_vecalu.sv rtl/sfg1_devmem.sv rtl/sfg1_frontend.sv rtl/sfg1_hbus.sv \
                       rtl/sfg1_perf.sv rtl/sfg1_engine.sv rtl/sfg1_core.sv]
set generics {}
foreach {k v} $P($variant) { lappend generics -generic ${k}=$v }
synth_design -top sfg1_core -part $part -mode out_of_context {*}$generics -generic WIN_KIB=16 -generic MAX_CTX=4 \
  -include_dirs rtl
create_clock -name clk -period [expr {1000.0 / $mhz}] [get_ports clk]
report_utilization -file $out/utilization.rpt
report_timing_summary -file $out/timing_synth.rpt
opt_design; place_design; route_design
report_utilization -file $out/utilization_routed.rpt
report_timing_summary -file $out/timing_routed.rpt
write_checkpoint -force $out/sfg1_core_routed.dcp
