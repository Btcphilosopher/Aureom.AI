# SF-G1 verification and FPGA-development project

A reproducible project that wraps the SilicaFlux **SF-G1** Linux driver package (as found in the `Aureom.AI` repository) with
device RTL, a verification stack, an open-source FPGA flow for a specific board, a profile-driven optimisation record, and a
performance report. **Read the next section first.**

## What this is, and what it is not

* **There is no ratified SF-G1 hardware and no device RTL in the repository.** The driver package contains a *proposed* host/device
  contract and a *reference front-end* (CSR file, queue fetch, completion write-back, interrupts, resets). The execution engine,
  device memory, host-bus unit and counters in this project are **new RTL written here against that draft contract**. It is this
  project's implementation of an unratified contract, not an existing design (`docs/00`).
* **Nothing was measured on hardware.** No board and no device was available. The performance report keeps *simulated cycles*,
  *synthesis/implementation estimates* and *measured hardware* apart; the third section is empty on purpose.
  "Clock frequency achieved" means the post-route static-timing figure nextpnr reports for the ULX3S-85F — a tool number.
* **PCIe is not modelled.** The host port is a numbers-only model; the FPGA shell talks UART. See `docs/05-limitations.md`.
* **Formal results are bounded** for the front-end (the depth reached is stated per proof); combinational and window-isolation
  proofs are complete. Three real front-end bugs were found by it and fixed (`docs/01` §5, F1–F3).
* The golden model, the driver mock, the testbenches and the RTL reflect **one reading of one draft contract**.

Nothing in this archive has been committed to any git repository.

## Headline results (all simulation, tool estimates or bounded formal — see the reports for definitions)

| | result | where |
|---|---|---|
| Co-simulation suite | 26/26 tests pass on all six design variants; zero protocol-checker (P1–P14) violations | `reports/verification-report.md` §1 |
| Mutation testing | 27/27 applicable injected bugs killed on V0 and on V5 | §2 |
| Formal | 21 proofs / negative controls as designed: combinational equivalence (exhaustive), engine window isolation (all states; V0, V3, V4, V5), front-end BMC to **24–25 cycles** (bounded). One negative control (CQ-full, P5) is an *expected non-detection* at that depth, so P5 is **not** formally covered | §3 |
| Bugs the verification found in this project's own design | 3 real front-end hazards (formal: F1–F3), 1 test-harness blind spot (random differential), 1 vacuous proof of mine, 1 timing-critical dead datapath | `docs/01` §5, `reports/optimisation-log.md` |
| Performance, simulated cycles (modelled host port, read latency 4) | 16×16×16 matmul job 13,709 → 2,854 cycles (V0 → V5); vector-add job 11,311 → 2,305 | `reports/perf-report.md` §2 |
| FPGA (ULX3S-85F, nextpnr post-route, speed grade 6) | V5: **63.3 MHz** (60 MHz target met; 75 not), 9,271 LUT+carry (11 %), 72 of 208 EBR, 4 multipliers; V0: 43.2 MHz. The ≥ 100 MHz aspiration was not met | §3 |
| Projection (cycles ÷ tool Fmax, **not measured**) | V5 matmul job ≈ 45 µs, vector-add job ≈ 36 µs, 4 KiB H2D ≈ 221 MB/s of payload | §4 |
| **Measured on hardware** | **nothing** | §5 |

## Quick start

```bash
sudo apt-get install -y verilator yosys z3 g++ make python3-venv   # verilator 5.0xx; yosys/z3 (apt) provide yosys-abc, yosys-smtbmc, z3 for the formal flow
make setup          # .venv with the pinned FPGA/formal tools (yowasp-yosys, nextpnr-ecp5, ecppack, SBY) from requirements.txt
make verify         # quick path (≈ 5 min on 4 cores, measured from a clean extraction of this zip): lint, contract, vendor TB, model-vs-mock fuzz, unit sims (+ their negative controls), suite on v0 and v5, core formal proofs
make demo           # the annotated end-to-end path (a few seconds): runtime call -> SQ -> device -> CQE -> interrupt -> verified output
make verify-full    # everything incl. all six variants, mutation sweeps (v0, v5), all place-and-route runs, front-end formal, perf, bring-up, reports (≈ 1.5-2 h)
```

`make help` lists every target. Results land in `reports/results/`; `make report` regenerates `reports/*.md` from them.

## Layout

| path | content |
|---|---|
| `rtl/` | device RTL: `sfg1_frontend` (derived from the driver package's reference), `sfg1_engine`, `sfg1_cmdchk`, `sfg1_vecalu`, `sfg1_devmem`, `sfg1_hbus`, `sfg1_perf`, `sfg1_core`; `sfg1_proto_chk` (protocol assertions P1–P14); `sfg1_sim_top`; `rtl/fpga/` bring-up shell (PLL, UART bridge, host-RAM stand-in) |
| `model/` | C golden model (`sfg1_model.c`) |
| `tb/cosim/` | Verilator C++ harness: modelled host port, 26-test suite, perf workloads, annotated demo; `tb/unit/` leaf-module unit sims and the model-vs-mock fuzz; `tb/fpga/` shell simulation |
| `driver/`, `runtime/` | userspace build of the driver's **real** hardware-facing C files + a port of the DRM-entangled layers; the runtime library `sfg1rt` |
| `vendor/` | pinned copy of the driver package files used (`SHA256SUMS`) |
| `formal/` | SymbiYosys / Yosys / `yosys-abc` proofs and their negative controls |
| `fpga/` | ULX3S constraints, `run_flow.py` (Yosys → nextpnr → ecppack), a Vivado script (**not run**) |
| `tools/sfg1_bringup.py` | host-side bring-up/measurement tool: `--sim` (Verilated shell) or `--port` (real board; **never run on hardware**) |
| `scripts/` | lint, contract check, mock extraction, mutation testing, formal runner, perf collection, report generation |
| `docs/` | 00 scope & provenance · 01 contract interpretation & findings · 02 FPGA requirements & board selection · 03 verification plan · 04 driver integration · 05 limitations · 06 performance methodology |
| `reports/` | `perf-report.md`, `optimisation-log.md`, `verification-report.md`, `results/` (raw JSON/text, `MANIFEST.txt`), `results/history/` (earlier RTL revisions, labelled) |

## The deliverables, and the command that reproduces each

| asked for | command | result |
|---|---|---|
| RTL lint checks | `make lint` | zero Verilator `-Wall` warnings on 3 configurations + the FPGA top; Yosys parses the synthesis set |
| Unit simulations | `make unit` | `vecalu`, `cmdchk`, `devmem`, `hbus` against the golden model (millions of vectors) |
| ISA differential testing | `make fuzz`; suite test `diff` | model vs the driver's own mock (extracted verbatim) on 3 M commands; RTL vs model on random valid+invalid commands with random bus timing |
| Protocol assertions | built into every `make test` | P1–P14 (`rtl/sfg1_proto_chk.sv`); a test fails if any fires; the same module is the formal property set |
| Formal checks, bounded control blocks | `make formal` | `reports/verification-report.md` §3: depths, negative controls |
| End-to-end kernel tests | suite `drv_kernels`, `drv_examples`; `make bringup` | runtime kernels and the driver's unmodified examples on the RTL; Python-driven kernels on the exact FPGA top |
| Driver/runtime integration | suite `drv_*` (11 tests) | real `sfg1_hw/ring/irq/reset.c` over the RTL; see `docs/04` for real vs ported |
| FPGA synthesis and timing scripts | `make fpga VARIANT=v5 MHZ=60`, `make fpga-all` | resources, post-route Fmax, bitstream hash |
| Effect of one optimisation, reproducibly | `make ab-o6` | place-and-route of the final RTL with optimisation O6 switched off vs on (`reports/optimisation-log.md` §3) |
| Stalls, interrupts, wraparound, invalid commands, memory faults, timeouts, resets, concurrent contexts | `make test`, mapping in `docs/03` §2 | every item has named tests and mutants |
| Performance report | `make perf bringup report` | `reports/perf-report.md` |
| Optimisation record | — | `reports/optimisation-log.md` (each change: correctness, resources, timing, throughput) |
| Host submission → verified device output | `make demo` | annotated trace, see below |

## Board choice

Chosen **after** the requirements were written down (`docs/02` §1–§6): **Radiona ULX3S-85F** (Lattice LFE5U-85F-6BG381C, speed
grade 6; 84 K LUT4, 208 × 18 Kb EBR, 25 MHz crystal, FT231XS UART) because it is the only candidate with an end-to-end open
toolchain, enough block RAM for 4 × 16 KiB windows with a second read copy, and an on-board USB-UART. It has **no PCIe**; the
trade-offs and the rejected candidates are in `docs/02` §7.

## Demonstrated path: host kernel submission → verified device output

`make demo` runs `sim demo`: the runtime call `sfg1rt_vec_i8(ADD8)` goes through the (ported) UAPI layer and the **real**
`sfg1_ring.c`, which writes four SQ entries into host memory and rings the doorbell; the RTL fetches each entry, checks and
executes it (H2D, H2D, VEC, D2H), writes each completion (dw3 last), raises an interrupt; the **real** interrupt/ring code acknowledges,
drains and returns credit; the runtime hands back the result, which the test compares lane-by-lane with a CPU reference while the
protocol checker watches every bus cycle. The trace prints each BAR0 access and device bus transaction, decoded.
The same path runs for every variant (`make demo VARIANT=v0`…`v5`) and, over a UART instead of PCIe, through the FPGA top
(`make bringup`).

## Variants

Optimisations are parameters so the same tests run on all of them: `v0` sequential baseline → `v1` burst fetch + DMA bursts →
`v2` two-read-port pipelined VEC → `v3` four-multiplier TEN → `v4` registered BRAM outputs → `v5` registered products. Their
effect on correctness, resources, timing and throughput is in `reports/optimisation-log.md`.

## Environment and reproducibility

* Ubuntu 24.04 container, 4 cores, 15 GB. Verilator 5.020 and Yosys 0.33/Z3 4.8.12 from apt; FPGA tools pinned in `requirements.txt`
  (YoWASP wheels: the WASM tools only see the current directory tree, so run `make` from the project root).
* `reports/results/MANIFEST.txt` records the RTL hash and tool versions that produced the shipped results.
* Place-and-route Fmax depends on the placer seed; the flow runs one seed per target by default (`--seeds 1,2,3` for more). With the pinned tools the flow is deterministic: a clean extraction of this zip reproduced V5 @ 60 MHz bit-exactly (same Fmax, same bitstream sha256 `7646aa66a2d9…`).
* The front-end BMC depth is time-limited (`SFG1_FORMAL_TIMEOUT`, 600 s per proof in the shipped run) and therefore depends on machine load: expect ≈ 22-26 cycles, not exactly 24/25.

## Licensing

The vendored driver files are GPL-2.0-only (UAPI GPL-2.0 WITH Linux-syscall-note OR MIT; examples MIT); files derived from them keep
GPL-2.0-only. The repository has no top-level licence file; an owner must choose one before distribution (`docs/00`).
