# 04 — Driver / runtime integration: what runs, what is ported, what is not covered

## Architecture

```
 userspace programs            driver package examples ex1/ex2/ex3/ex5 (UNMODIFIED)   runtime/sfg1rt.c (kernels)
        │  open/ioctl/mmap/opendir  (redirected by -include driver/usim/ksim_libc.h; without it: a real /dev/accel/accelN)
        ▼
 driver/usim/ksim.c   ── PORT of sfg1_main/ctx/gem/job: contexts + slot policy + scrub, BO_CREATE quotas,
        │                sfg1_build_cmd validation, SUBMIT, WAIT_JOB, run_job, the drm_sched credit/timeout role
        ▼
 vendor/.../sfg1_hw.c  sfg1_ring.c  sfg1_irq.c  sfg1_reset.c   ── REAL driver code, unmodified,
        │               compiled against driver/shim/ksim_kapi.h (spinlocks, lists, atomics, jiffies, read_poll_timeout …)
        ▼  sfg1_backend_ops.rd32/wr32
 tb/cosim/ksim_glue.cpp ──► SfgSys ──► Verilated sfg1_core (+ protocol checker)   host memory = simulated DMA memory
```

Simulated **time** is derived from the RTL clock (`clock_mhz`, default 100): every timeout in the real code
(`read_poll_timeout`, job timeout, reset timeout, quarantine) is measured in simulated device cycles, and locks assert
against recursion/unbalanced use. `drm_sched_fault` / `queue_work` set flags that `ksim_pump()` services by calling the
real `sfg1_timedout_job()` / `sfg1_reset_work()`.

## What is REAL vs PORTED

| Driver function | In ksim | Fidelity |
|---|---|---|
| discovery sequence (contract §2), queue programming, enable, quiesce, engine/function reset | real `sfg1_hw.c` | identical code |
| SQ push + doorbell, CQ reap with phase bit and `dma_rmb()`, job completion | real `sfg1_ring.c` | identical code |
| interrupt top half (ack) + threaded drain (acknowledge-then-drain) | real `sfg1_irq.c` | identical code |
| recovery: ENGINE → FUNCTION → DEAD, culprit/cancel, strikes, lost contexts | real `sfg1_reset.c` | identical code |
| `sfg1_build_cmd` validation, SUBMIT/WAIT_JOB/BO_CREATE ioctls, context slots, scrub policy, ban, quotas | `ksim.c` **port** | logic and error codes copied from the real source; could diverge |
| DRM core, GEM objects, drm_sched, dma_fence, PCI glue, mmap faults, fdinfo, unplug | **not covered** | the QEMU suite in the driver package covers the kernel side against its mock |

## Integration checks (all in `tb/cosim/tests_driver.cpp`; every one passes on V0–V5)

| Test | Scenario |
|---|---|
| `drv_probe` | real discovery/queue/enable over the RTL; device left as the driver intends |
| `drv_examples` | the driver package's **unmodified** examples ex1/ex2/ex3/ex5 print `OK` against the RTL (ex4 forks and needs real DRM isolation; not run) |
| `drv_kernels` | runtime E2E vs a CPU reference: 6 VEC ops, ReLU, DOT, 5 matmul shapes, 2-layer INT8 MLP (device matmul → host requantise → device ReLU → device matmul) |
| `drv_concurrent` | all 4 hardware contexts interleaved over many ring laps; credit accounting; `EBUSY` on the 5th open |
| `drv_validation` | 51 UAPI error cases: rejected before the device (zero bus traffic, no counters changed) |
| `drv_devchecks` | raw bad descriptors through the real ring (the "patched driver" of bring-up doc §3): device status code + exactly one engine reset each |
| `drv_faults` | DMA fault → `ERROR/DMA_ERROR`, recovery, bystander unaffected; faulting D2H writes nothing |
| `drv_timeout` | host stops answering reads: job `TIMEOUT` after the configured 10 ms (simulated), queued innocent job `CANCELED` (never replayed), engine reset, 3 strikes → ban, other contexts unaffected |
| `drv_lostirq` | every interrupt lost: the timeout path's final reap completes the job `OK`; no reset, no strike |
| `drv_funcreset` | FATAL (queue config corrupted by a rogue agent): engine reset cannot clear it → FUNCTION reset → all contexts `LOST` (`ECONNRESET`); a fresh context reads zeros |
| `drv_isolation` | scrub on close/open: a new owner of a slot never reads the previous owner's window |

## Not covered (and where it would be)

Real PCIe and IOMMU behaviour; PCI glue (`sfg1_pci.c` is compile-tested only upstream and not exercised here);
runtime PM; hot-unplug; real concurrency (the simulation is single-threaded; interleaving is by submission order);
the cloud runtime and P30 runtime (different devices — they cannot drive an SF-G1).
