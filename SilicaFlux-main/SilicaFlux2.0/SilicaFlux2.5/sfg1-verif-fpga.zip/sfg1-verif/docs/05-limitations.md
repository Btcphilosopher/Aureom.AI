# 05 — Unresolved limitations (read before relying on any result)

## Hardware / measurement

1. **No hardware was available. There is not one measured hardware number in this project.** `tools/sfg1_bringup.py --port`
   and the bitstream flow exist; `reports/perf-report.md` §5 ("measured hardware") is deliberately empty. No bitstream has
   been loaded on any board; the bitstreams in `artifacts/fpga/` are place-and-route outputs for the ULX3S-85F.
2. **The ULX3S pin assignments** (`fpga/constraints/ulx3s.lpf`) come from the board vendor's constraint file for
   revisions v2.x.x/v3.0.x, fetched through a web tool; they were **not** checked against the schematic, and a v3.1.x board is
   not covered. Check your revision before programming.
3. **No PCIe.** The ULX3S has none; the open toolchain has no established ECP5 PCIe path. The shell's UART + on-chip RAM
   stand-in makes the core observable on hardware but says nothing about TLP ordering, MSI-X, completion timeouts, IOMMU
   or bandwidth over a real link. A PCIe bring-up needs another board and a vendor shell — **not built**.
4. **Clock-domain crossings** for a PCIe user clock are not designed.
5. Achieved Fmax is for **speed grade 6** (the slowest) with nextpnr's timing model, **one placer seed per target**; it varies
   with seed, target and tool version. The 100 MHz aspiration in `docs/02` was **not reached**; see `reports/perf-report.md` §3.
6. The Vivado script (`fpga/synth/vivado_synth.tcl`) was **never run** (no Vivado here).

## Contract

7. **The SF-G1 host/device contract is an unratified draft** and the engine, memory, bus unit and counters are *this project's*
   reading of it (`docs/00`). Eleven interpretations are listed in `docs/01` §4 for ratification; two of them (I9 queue-base
   alignment/wrap → FATAL, I10 ENABLE ignored while draining) were added because formal verification showed the draft silent
   where a hostile host can reach it. If a real hardware team decides otherwise, the RTL, model, mock-extraction and tests change together.
8. The D2H fault path assumes a bus adapter that can report a *synchronous* write error (`mwr_err`); real PCIe posted writes
   cannot. **Open question** in `docs/01` §4.3.

## Design

9. One in-order queue, one command at a time; no concurrency inside the device (contract v1).
10. **SQ prefetch/overlap is not implemented**: with a 100-cycle host read latency a single NOP costs 130 cycles against 34 at
    latency 4 (`reports/perf-report.md` §2.2). It is the identified next optimisation.
11. `SCRUB` runs at 1 word/cycle (4133 cycles for a 16 KiB window) and the driver scrubs on every context open and close.
12. Each added pipeline stage costs one cycle per TEN tile (the tile pipeline drains between tiles): `ten_acc` went from 1,701
    (V3) to 1,829 (V5) cycles — the price of the Fmax gain, recorded in `reports/optimisation-log.md`.
13. Debug-tap buses and the mutation parameters (`MUT`, `ORDER_BUG`) exist in the RTL; they are 0/unconnected in every real
    build, but a conservative release would strip them.
14. Window size and context count must be powers of two (`sfg1_engine.sv`).
15. Partial overlap of a VEC output with an input is undefined by the contract and differs between the sequential and the
    pipelined variants; only exact aliasing is defined and tested.

## Verification

16. **Formal results are bounded for the front-end.** The depth completed is stated per proof in `reports/verification-report.md`
    §3 and depends on the time limit and machine load (abc BMC, `SFG1_FORMAL_TIMEOUT`); it covers CSR set-up, a fetch and the
    start of execution, not a full round trip with long bursts. Combinational equivalence (`cmdchk`, `vecalu`) is exhaustive;
    engine window isolation is an inductive invariant over all states. Liveness (no deadlock) is only tested, not proved.
    The earlier front-end proofs were **vacuous** because of a wrong assumption of mine; that is fixed and recorded
    (`docs/01` §5), and every proof now has a negative control that must fail.
17. The golden model, the driver mock, the testbenches and the RTL share one author's reading of one draft contract.
    Mutation testing (`reports/verification-report.md` §2) shows the *tests* detect every applicable injected bug on V0 and V5;
    it cannot show the contract is right, and the mutant list is itself my idea of plausible bugs.
18. Differential tests use a modelled host memory; stress runs are seconds long (millions of cycles), not soak tests.
19. `ksim.c` is a port; see `04-driver-integration.md` for what is not covered. The kernel-side QEMU suite of the driver
    package was **not** re-run (no kernel tree).
20. Coverage metrics (line/toggle) were not collected.
21. Toolchain versions are pinned (`requirements.txt`; Verilator 5.020, Yosys 0.33 and Z3 4.8.12 from apt), but all results
    were produced on one machine; the formal flow mixes the apt Yosys (model generation, `yosys-abc`) with the YoWASP SBY wrapper,
    which is why `scripts/run_formal.py` runs `yosys-abc` itself for the front-end proofs.
