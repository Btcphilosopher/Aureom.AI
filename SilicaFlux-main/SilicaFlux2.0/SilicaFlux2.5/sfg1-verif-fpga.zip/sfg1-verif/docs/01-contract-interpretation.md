# 01 — Contract interpretation, deltas from the reference RTL, and findings

The contract is `vendor/sfg1-driver/docs/02-hw-interface.md` (DRAFT v1.0). Where it is silent, this project followed
the driver's own mock (`kernel/sfg1_mock.c`) because the driver's test suite is written against it; every such choice is
listed so a hardware team can overrule it.

## 1. Command execution semantics (what the engine implements)

Commands execute strictly in order, one at a time. `ctx_id` selects window `[ctx·W, (ctx+1)·W)`; device addresses are
formed as `{ctx, window-local word pointer}` by concatenation, so no address can leave the window even if a pointer
overflows (proved: `formal/engine_formal.sv`).

| Op | Semantics |
|---|---|
| `NOP` | OK if every operand field is zero, else `BAD_ARGS` |
| `SCRUB` | same operand rule; zeroes the whole window (1 word/cycle: `W/4` cycles) |
| `DMA_H2D` / `DMA_D2H` | `len` bytes between host `host_addr` and window offset `dev_a`; 4-byte aligned; reads are issued as bursts that never cross a 4 KiB boundary |
| `VEC` | INT8×4 lanes, ops 0–7 (`ADD8 SUB8 MAX8 RELU8 XOR32 AND32 MUL8 DOT8`); `DOT8` writes one INT32 to `C[0]` |
| `TEN` | `C = A·B` or `C += A·B` per 4×4 INT8 tile → INT32 (wrap-around) |

## 2. Error precedence (identical in the mock, the golden model and `sfg1_cmdchk`)

1. `ctx_id ≥ MAX_CTX` → `BAD_CTX` &nbsp; 2. `rsvd0` or `rsvd1` ≠ 0 → `BAD_ARGS` &nbsp; 3. per opcode:

| Opcode | in this order |
|---|---|
| NOP, SCRUB | any operand field ≠ 0 → `BAD_ARGS` |
| H2D, D2H | `flags∨exec_op∨dev_b∨dev_c ≠ 0` → `BAD_ARGS`; `len==0` or `(len∨dev_a) & 3` → `BOUNDS`; window range violated → `BOUNDS`; `host_addr+len` wraps 2⁶⁴ → `DMA_ERROR` |
| VEC | `flags∨host_addr ≠ 0` or `exec_op > 7` → `BAD_ARGS`; `len==0` or any of `a,b,c` unaligned or `len·4` overflows u64 → `BOUNDS`; `RELU8` with `dev_b ≠ 0` → `BAD_ARGS`; any operand outside the window (DOT8: C is 4 bytes) → `BOUNDS` |
| TEN | `flags & ~1`, `exec_op` or `host_addr ≠ 0` → `BAD_ARGS`; `len==0`, unaligned, `len·16` or `len·64` overflows → `BOUNDS`; any tile array outside the window → `BOUNDS` |
| other | `BAD_OPCODE` (including the reserved opcode 4) |

Note the consequence that surprised me and is pinned by tests: a `RELU8` with `len ≥ 2⁶²` reports **`BOUNDS`** (the overflow
rule comes first), whereas a moderate `len` with `dev_b ≠ 0` reports `BAD_ARGS`.
These precedences are checked three ways: golden model vs the mock (3 M commands, `tb/unit/fuzz_model_vs_mock.c`), RTL
checker vs golden model (6 M commands, `tb/unit/unit_cmdchk.cpp`), and RTL checker vs an independent wide-arithmetic
specification for **all** inputs (formal, `formal/cmdchk_spec.sv`).

## 3. Front-end deltas from the reference RTL (`rtl/sfg1_frontend.sv` vs `vendor/.../sfg1_host_frontend.sv`)

| # | Delta | Why |
|---|---|---|
| D1 | Synthesizable subset Yosys accepts: no package import; no blocking-assignment state in the clocked process (event wires computed in `always @*`) | Yosys 0.33 **and** 0.71 cannot parse `import pkg::*` in a module |
| D2 | Optional burst SQ fetch (`FETCH_BURST=1`: one 16-beat read instead of 16 single reads) | profile: fetch is 128 of 135 cycles per command in the baseline |
| D3 | `mrd_err` ends a fetch with `FETCH_ERROR`; `cid := SQ slot index`, `ctx := 0` in that CQE (nothing to echo) | the reference had no error input, so `FETCH_ERROR` was unreachable |
| D4 | `mwr_ready` back-pressure on CQE writes; the interrupt cause is published only after dw3 has been **accepted** | R3 must hold on a stalled bus |
| D5 | All `BAD_ARGS/BOUNDS/BAD_OPCODE` decisions come from `sfg1_cmdchk` | the reference completed `NOP` with non-zero fields as `OK` (contradicts contract §4.1 and the mock) — mutant `MUT=11` reproduces it and is killed |
| D6 | `mrd_len`, `fe_state`, debug taps | burst length; profiling; protocol checker |
| D7 | Queue base/size registers are **shadows**; the datapath uses copies sampled at the accepted `ENABLE` 0→1 edge (R9 as written) | formal finding F1: with live registers a disable-then-reprogram moves the window under an in-flight fetch |
| D8 | An unaligned queue base (SQ 64 B, CQ 16 B) or a queue that would wrap past 2^64 → invalid configuration (`FATAL`) | formal finding F2; interpretation I9 |
| D9 | `ENABLE` 0→1 is ignored while the front-end is not idle | formal finding F3; interpretation I10 |

**Regression:** the driver package's own front-end testbench, run against the derived front-end by a scripted patch
(`scripts/make_vendor_tb.py`: C1–C4 listed in that file), gives the identical result as against the original:
**566 checks pass; the two ordering mutants fail with 136 and 7 failing checks** (`scripts/run_vendor_tb.sh`, both fetch styles).

## 4. Things the contract does not say, and what was assumed (please ratify or overrule)

1. **Stale read data after a reset.** A read issued before `ENGINE_RESET` may be answered after it. The contract is silent.
   Implemented: every read carries a 4-bit epoch tag that advances on each reset; responses with an old tag are dropped
   (`sfg1_hbus.sv`; PCIe completion tags would play this role). Without it a late beat corrupts a later command
   (mutant 20, killed by the `reset` test).
2. **Posted-write flush.** The driver relies on "a register read completes after earlier posted writes" (PCIe producer/
   consumer rule). Modelled in the co-simulation; unverified for any real fabric.
3. **D2H memory faults.** PCIe posted writes have no error response. The contract lists `DMA_ERROR` for "host DMA
   fault" generally; this RTL accepts a synchronous `mwr_err` from the bus adapter (an IOMMU/range-checker could provide
   it) and stops streaming after the first fault. A real PCIe shell cannot do that synchronously — **open question.**
4. **Unbound contexts.** Contract §10 lists `BAD_CTX` for an "unbound" context, but the contract has no bind mechanism
   (only the mock has `ctx_bind`). The RTL treats every `ctx_id < MAX_CTX` as bound.
5. **Host address alignment** is not checked (the mock does not either); the kernel never generates unaligned addresses.
6. **Overlap.** For `VEC` with *partial* overlap of `C` with `A` or `B` the contract says values are undefined. The
   sequential variant happens to match the mock element-for-element; the pipelined variants differ. Tests generate
   partial overlaps only for the sequential variant. Exact aliasing (`C == A` or `C == B`) is exercised everywhere. `TEN`
   reads A and B and (accumulating) C before writing, so arbitrary overlap is defined and tested.
7. **Faulting DMA leaves the destination undefined.** After `DMA_ERROR` the destination window range may be partially
   written; the differential test scrubs the context afterwards (as the driver's recovery would).
8. **A write request in flight when a reset arrives** is retracted (never accepted) rather than allowed to complete.
   Found by protocol property P11 (see §5).
9. **I9 — Queue base alignment and wrap.** R9 lists non-power-of-two sizes, `CQ < SQ` and over-limit sizes as invalid configurations
   but says nothing about the *bases*. Implemented: an SQ base not 64-byte aligned, a CQ base not 16-byte aligned (the entry
   sizes), or a queue whose end would pass 2^64, is an invalid configuration: `FATAL` + `IRQ_FATAL`, not enabled. The
   real driver allocates page-aligned DMA memory, so it never trips this. *Ratify or overrule.* (Found by formal, F2.)
10. **I10 — ENABLE 0→1 while a command is still draining.** The driver quiesces with `CTRL=0`, polls `STATUS.BUSY`, and only
    then reconfigures (`sfg1_hw_quiesce`). The contract does not say what a re-enable *during* the drain does. Implemented:
    the write's ENABLE bit is ignored (`CTRL.ENABLE` reads back 0, no FATAL). Any other choice must still keep the in-flight
    command's CQE where the sampled queue registers put it. *Ratify or overrule.* (Found by formal, F3.)
11. **I11 — "Sampled on ENABLE 0→1" is implemented literally (R9).** The registers the host reads/writes are *shadows*; the
    datapath uses copies sampled at the accepted 0→1 edge. A command already in flight when the host disables and
    reprograms the queue therefore completes against the geometry it started with. (Found by formal, F1.)

## 5. Findings produced by this verification (each is fixed or documented)

| Finding | How found | Status |
|---|---|---|
| Engine's pending bus write could still be **accepted one cycle after** the host asked for a reset (retract skew between front-end and engine) | protocol property P11 in the `reset`/`timeout` tests | **fixed** (`sfg1_hbus.sv` gates requests while the abort pulse is high); mutant 21 shows the test detects its absence |
| Performance-counter block mixed a *synchronous* clear into an *asynchronous*-reset condition: fine in simulation, **not synthesizable** | Yosys: "Multiple edge sensitive events found" | **fixed** |
| `ops` test compared per-op *statuses* but overwrote the result buffer between VEC ops: a DOT8 that omitted a lane survived | mutation testing (mutant 18 killed by one test only) | **fixed** (distinct host slot per operation) |
| `use-after-free` in my userspace driver port: `WAIT_JOB` held a job pointer across the scheduler's garbage collection | crash only when allocator reuse lined up | **fixed** (hold count) |
| Reference front-end accepts `NOP` with non-zero fields | differential vs the mock | **fixed** in the derived front-end (D5) |
| Reference front-end cannot report `FETCH_ERROR` | reading the contract against the RTL | **fixed** (D3) |
| **F1** — `ENABLE` cleared while an SQ fetch is outstanding, then `SQ_ENTRIES` reprogrammed: the *live* register moved the fetch window under the in-flight fetch (the protocol checker's P8 — SQ fetch addressing — fired at frame 8 of the front-end BMC). Simulation never did this: every directed test reconfigures only after `BUSY=0`. | **formal** (front-end BMC, hostile CSR stimulus), property P8 | **fixed**: shadow + sampled queue registers (I11); `cfg_race` test; mutant 30 (live registers) is killed by `cfg_race` |
| **F2** — host programs an unaligned `SQ_BASE` (0x1): the device issued a fetch at address 1 (P8 again, frame 9) | **formal** | **fixed**: alignment/wrap is part of the configuration check (I9); mutant 29 killed |
| **F3** — `ENABLE` set again while the previous command is still draining: the new queue geometry was sampled under the in-flight command, so its CQE went to the *new* CQ (P1, frame 11) | **formal** | **fixed**: ignored while `BUSY` (I10); mutant 28 killed |
| A *vacuous* front-end proof: my wrapper contained `assume (rst_n || !init)`, which is false in cycle 0 (rst_n is `!init`), so every bound passed trivially | noticed because the AIGER model collapsed to one variable and the ORDER_BUG negative controls did not fail | **fixed**; every proof in `formal.json` has a negative control that must fail |
| The **random ISA differential was blind to arithmetic bugs on one lane**: windows start scrubbed, so most operands were zeros and a DOT8 that dropped lane 3 passed (mutant 18 **survived on V5**, killed on V0 only by directed tests) | mutation testing on V5 | **fixed**: each batch first fills half the windows with random data; mutant 18 is now killed by `diff` on every variant. The mutant itself also did not exist in the PIPE=2 datapath (dot computed from registered products) — now it does |
| After the random fill the differential exposed a **generator gap**: VEC with `C == A` and `B = A − 3 words` (partial overlap of C with B, undefined by the contract; pipelined variants legitimately differ from a sequential model) | the strengthened differential failed on V4/V5 only | **fixed in the generator** (partial overlap is only generated for the sequential variant); not an RTL change |
| After a FATAL with nothing in flight the real driver recovers *immediately* through its reset work (classified as a protocol fault, no strike), not after a timeout | my driver test's wrong expectation | test corrected; behaviour is the driver's design |
