# 00 — Scope, provenance, and what this project is NOT

## What was asked, and what actually exists

The request was to integrate "the SilicaFlux SF-G1 hardware, runtime, and driver" into a reproducible
verification and FPGA-development project. The repository (`Aureom.AI`, archive
`SilicaFlux-main/silicaflux-sfg1-driver-0.1.0.zip`, SHA-256
`56152fa34cbfd2f2062964eb1e3670c1ec0e9953ec3bd28ebaa6876913311665`) contains, for SF-G1:

| Piece | What exists | Evidence |
|---|---|---|
| **Driver** | A Linux 6.18 DRM-accel driver, UAPI, a software mock device, 5 examples, QEMU tests | `vendor/sfg1-driver/` (its own README) |
| **Hardware** | **No ratified specification and no device RTL.** The driver package ships a *proposed* host/device contract (`vendor/sfg1-driver/docs/02-hw-interface.md`) and a *reference front-end* RTL (CSR file, SQ fetch, CQE write-back, interrupts, resets) with the execution engine and device memory stubbed out | `vendor/sfg1-driver/README.md` ("No SF-G1 hardware spec existed", "Nothing has run on physical hardware") |
| **Runtime** | No SF-G1-specific runtime beyond the driver's UAPI and its header-only helper `examples/sfg1_user.h`. The other two runtimes in the repository target *different devices* (`silicaflux-cloudruntime`: the P61 CloudDPU, chip id `SFDP`; `SilicaFlux-OS-runtime-P30`: ControlCore / HostLink) and contain no reference to SF-G1 | grep for `53464001` / `SFG1` outside the driver package: none |

## What this project therefore builds

* **Hardware**: the driver package's reference front-end is *derived* (documented deltas in
  `01-contract-interpretation.md`), and the **engine, device memory, host-bus unit and perf counters are NEW RTL
  written here against the draft contract** (`rtl/`). This is *my* implementation of an unratified contract, not an
  existing SF-G1 design. Nothing here is endorsed by a hardware team; whether it matches any future SF-G1 is unknown.
* **Runtime**: `runtime/sfg1rt.[ch]`, a small C library on the driver's public UAPI (via `sfg1_user.h`), written here.
* **Driver**: the real driver code, unmodified, where it is hardware-facing (`sfg1_hw.c`, `sfg1_ring.c`,
  `sfg1_irq.c`, `sfg1_reset.c` compile in userspace against a kernel-API shim) and a **port** (`driver/usim/ksim.c`)
  of the DRM-entangled layers (contexts, BOs, submit validation, wait). Ports can differ from the original; see
  `04-driver-integration.md` for exactly what is and is not covered.
* **FPGA**: a bring-up shell for the ULX3S-85F (UART bridge + on-chip host-RAM stand-in), the open flow to
  synthesise, place, time and package it, and a Vivado script that was **not run**.

## What "verified" means here (and does not)

Every device-facing result is against **simulation** (Verilator RTL, a C golden model, the driver's own mock logic
extracted verbatim) and **formal proofs with stated bounds**. Nothing ran on a physical board: no board was available.
Consequences, stated once so they cannot be missed:

1. **No measured hardware results exist.** The performance report keeps three kinds of numbers apart — *simulated
   cycles*, *synthesis/implementation estimates*, *measured hardware* — and the third section is empty. The tooling that
   would fill it (`tools/sfg1_bringup.py --port`) exists and has been exercised only against the Verilated shell.
2. **PCIe is not modelled.** The host-memory port is a numbers-only model (latency, throttle, back-pressure). R3/R4/R6
   (posted-write ordering, interrupt message semantics) hold in this project because the model is in-order by
   construction. Whether real PCIe, an IOMMU and MSI-X behave that way is exactly what the contract's open questions ask.
3. **The contract is a proposal.** Passing tests shows the driver, the golden model, the mock logic and this RTL
   *agree with each other* on it. It shows nothing about any real device.
4. "Clock frequency achieved" is the post-place-and-route static-timing figure from nextpnr for an ECP5 speed-grade-6
   part. It is a tool-reported number, not an oscilloscope measurement.

## Provenance of vendored files

`vendor/SHA256SUMS` pins every vendored file. `scripts/extract_mock.py` refuses to run if `sfg1_mock.c` differs from
its pinned hash. Licences: the driver is GPL-2.0-only (UAPI: GPL-2.0 WITH Linux-syscall-note OR MIT; examples: MIT);
files derived from it keep GPL-2.0-only. The repository has no top-level licence file: an owner must choose one before
any distribution (`vendor/sfg1-driver/LICENSES/`).
