# 06 — Performance methodology: how each number is obtained, and the rules for optimising

## 1. Three kinds of number, never mixed

| kind | produced by | unit | what it can and cannot say |
|---|---|---|---|
| **Simulated cycles** | `tb/cosim/tests_perf.cpp` → `scripts/collect_perf.py` → `reports/results/perf_sim.json` | clock cycles of the RTL | exact for this RTL against the **modelled** host port (read latency 4 or 100 cycles, 1 beat/cycle). Says nothing about frequency or about a real link |
| **Synthesis / implementation estimates** | `fpga/synth/run_flow.py` → `reports/results/fpga_<variant>_<MHz>.json` | LUT4/FF/EBR/multiplier counts, MHz | Yosys resource counts; nextpnr *post-route static timing* for speed grade 6. A tool's model, one placer seed per run |
| **Measured hardware** | `tools/sfg1_bringup.py --port` on a real board | — | **No such data exists.** The report section is generated empty |

`reports/perf-report.md` also has *projections* (cycles ÷ Fmax). They are labelled as such: they combine the first two kinds and are not measurements.

## 2. Definitions of the requested metrics

| requested | definition used | source |
|---|---|---|
| Clock frequency actually achieved | post-route Fmax that nextpnr prints for the constrained core clock, at the highest target for which it reports timing *met*; every run (target, seed, final Fmax, pre-route estimate) is listed | `fpga_*.json` |
| Resource utilisation | Yosys `stat` (LUT4, FF, carry, DP16KD, MULT18X18D) and nextpnr's post-pack utilisation (TRELLIS_COMB/FF, EBR, MULT) vs the device totals; includes the shell (UART bridge, 16 KiB host-RAM stand-in) | `fpga_*.json` |
| Instructions issued per cycle | the machine is command-driven: **commands/cycle** = completed SQ entries ÷ total cycles; plus **ops/cycle** (INT8 lane/MAC operations per workload, defined in `tests_perf.cpp`) ÷ total cycles and ÷ the engine's own busy cycles | `perf_sim.json` |
| Effective memory bandwidth | payload (or device-memory bytes touched) ÷ total cycles, in bytes/cycle; MB/s only in the labelled projection (× Fmax) | `perf_sim.json` |
| Kernel execution time | engine busy cycles for the VEC/TEN operation (device counters 0x128/0x12c); µs only in the projection | `perf_sim.json` |
| Host-transfer overhead | (H2D + D2H engine cycles) ÷ job total cycles; fixed overhead = cycles outside any operation; plus the runtime-level phase split (`KPERF`) | `perf_sim.json`, `suite_*.txt` |
| End-to-end workload time | doorbell to last completion in cycles (`kernel_vecadd_job`, `kernel_matmul16_job`); through the FPGA shell, whole-run cycles including the UART link (`bringup_sim_*.json`) | same |

## 3. Rules followed while optimising

1. **Optimise only after profiling.** Every change in `reports/optimisation-log.md` names the profile that justified it (device counters or the nextpnr critical path), not an expectation.
2. **One change at a time, each recorded on four axes:** correctness (full suite on every variant, formal where applicable), resources, timing, throughput. A change that cannot be tied to a measured bottleneck is not made.
3. **Parameterised, not forked.** Optimisations are parameters (`FETCH_BURST`, `DMA_BURST`, `VEC_MODE`, `TEN_MODE`, `PIPE`), so the *same* tests and checkers run on every variant; V0 stays as the baseline for comparison.
4. **A regression on any axis is reported**, not hidden (e.g. V2 and V3 lowered Fmax; V5 gave almost nothing until the real critical path was found).
5. **Results are tied to the RTL revision** (`reports/results/MANIFEST.txt` has the hash of `rtl/`); results from earlier revisions are kept only in `reports/results/history/` and labelled.

## 4. Known measurement limits

* nextpnr's Fmax is not monotone in the target and varies with the seed; one seed per run is a *sample*. Differences of a few MHz between variants are within that noise.
* The host-port model has constant latency; real links have jitter, credits and TLP overhead.
* The perf counters are 32-bit and cleared per workload; the 16 KiB window and 4 contexts are fixed for all runs.
* Simulated time in the runtime-level phase split uses a fixed 10 ns per cycle (100 MHz), which is *not* the achieved Fmax of any variant.
