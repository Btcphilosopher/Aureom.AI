# 02 — FPGA requirements, assumptions, and board selection

**Order of work (as required): requirements and assumptions first (§1–§6), board selection
afterwards (§7).** The a-priori numbers in §4 were written *before* any synthesis was run;
§8 compares them with what the tools later reported, so wrong assumptions are visible rather
than quietly corrected.

> Provenance reminder: there is no ratified SF-G1 hardware specification. The requirements
> below are derived from the **draft** contract (`vendor/sfg1-driver/docs/02-hw-interface.md`)
> and from the RTL in this project (`rtl/`). See `docs/00-scope-and-provenance.md`.

## 1. What the FPGA must host

The device core `sfg1_core` (front-end + engine + device memory + host-bus unit):

| Block | Function | Source |
|---|---|---|
| `sfg1_frontend` | BAR0 CSR file, SQ fetch, CQE write-back (rules R3/R4/R6/R7/R9), resets | derived from the driver's reference front-end |
| `sfg1_engine` | in-order execution of NOP / DMA_H2D / DMA_D2H / VEC / TEN / SCRUB with window bounds checks | new (written against contract §8, §9, §10) |
| `sfg1_devmem` | device-local memory, one window per hardware context | new |
| `sfg1_hbus` | host-memory master mux, epoch-tagged read-response filter, perf counters | new |

## 2. Memory requirements

| Item | Requirement | Derivation |
|---|---|---|
| Device-local memory | `MAX_CTX × CTX_WIN_KIB × 1024` bytes. Default FPGA build: 4 × 16 KiB = **64 KiB** | contract §9; sized so every example/kernel in this project fits a window |
| Read ports on device memory | 1 (baseline) or 2 (VEC at 1 word/cycle needs A and B read concurrently) | engine design |
| Memory type | synchronous-read, 32-bit-wide, inferable as block RAM (no distributed RAM for windows) | contract has no latency requirement; BRAM is the only efficient on-chip option |
| Width/granule | 32-bit words; every DMA/VEC/TEN offset and length is 4-byte aligned | contract §8 |
| Host memory | SQ + CQ + buffers. **Not on the device in a real SF-G1** (host RAM over PCIe). A bring-up shell must therefore provide a stand-in: ≥ `SQ(16×64 B)+CQ(16×16 B)` = 1.25 KiB + working buffers; default **16 KiB** | contract §1, §7 |
| Off-chip DRAM | **not required** in v1 (device memory is the on-chip windows) | contract §9 |

## 3. Interface requirements

| # | Requirement | Mandatory for | Notes |
|---|---|---|---|
| I1 | Host access to a 4 KiB, 32-bit register window (BAR0 map, contract §3) | any bring-up | PCIe BAR in the real device; a serial/Ethernet register bridge is an acceptable *bring-up* stand-in |
| I2 | Host-memory master: 32-bit beats, read bursts (≤ 4 KiB, never crossing a 4 KiB boundary), posted writes with back-pressure | any bring-up | in a real device this is the PCIe TLP engine |
| I3 | Interrupt message (MSI-X) | contract rule R6 | stand-in: a status byte/event over the bridge |
| I4 | **In-order posted writes** (CQE dwords, then interrupt message) with no relaxed ordering | rules R3/R6 | holds by construction in an on-chip FIFO; a *property of PCIe* that only a PCIe platform can confirm |
| I5 | Programming + debug link usable with an open tool | reproducibility | JTAG via `openFPGALoader` |
| I6 | Cycle-accurate counters readable from the host | hardware measurement | vendor-extension CSR block at `0x100+` (not part of the contract; the driver never touches it) |

**PCIe itself (endpoint IP, MSI-X, bus mastering) is a *desirable* requirement, not one this
project can satisfy and test.** No PCIe endpoint IP exists in the repository, and an open
toolchain path for ECP5 PCIe is not established (see §7 sources). Consequence, stated here so
it cannot be missed later: **on a board without PCIe, rules R3/R4/R6 are exercised only against
the stand-in's in-order FIFO — they are *not* validated against real PCIe ordering.**

## 4. Resource assumptions (a priori — before synthesis)

| Resource | Estimate | Basis |
|---|---|---|
| 4-input LUTs | 3,000 – 6,000 | front-end ≈ 800 (16×32-bit command latch + decoder), engine ≈ 1,500–2,500 (64-bit bounds comparators dominate), counters/bus ≈ 700 |
| Flip-flops | 2,500 – 4,500 | 512 for the command latch, ≈ 640 for 20 × 32-bit perf counters, engine/address registers |
| 18 Kb block RAM (EBR) | **64 – 80** | 64 KiB window memory = 32 EBR at 32-bit width (2 KiB each); the dual-read-port variant duplicates it → 64; + host stand-in 16 KiB = 8 EBR |
| Multipliers (18×18) | 4 – 16 | TEN dot-product: 4 INT8 MACs per output (4 for the 4-MAC variant, 16 for a 16-MAC variant; may map to LUTs instead) |
| Clock | **target 50 MHz**, aspiration ≥ 100 MHz | 64-bit address adders/comparators and BRAM-read→ALU→BRAM-write paths are the expected limiters |
| Clock domains | 1 (core) + the UART bridge in the same domain | no CDC in the core |
| I/O | clock, reset, UART RX/TX, ≥ 4 status LEDs | the core's wide host-bus ports stay internal |

## 5. Clocking assumptions

* Single core clock `clk`, generated from the board oscillator by a PLL (`EHXPLLL` on ECP5);
  asynchronous reset input, synchronised to `clk` (2-FF) before use.
* No clock-domain crossings inside `sfg1_core`. A real PCIe shell adds at least one
  (PCIe user clock ↔ core clock) and needs async FIFOs on the CSR, read and write paths — **not
  built here** (listed in `docs/05-limitations.md`).
* The reported "clock frequency achieved" is the **post-place-and-route static-timing Fmax
  reported by nextpnr** for the constrained clock; it is *not* a measured hardware frequency.

## 6. Toolchain requirements

| Need | Choice | Version used in this project |
|---|---|---|
| RTL simulation / lint | Verilator | 5.020 (Ubuntu 24.04 `apt`) |
| Synthesis | Yosys (`synth_ecp5`) | 0.71 (pip `yowasp-yosys==0.71.0.0.post1285`) |
| Place & route + timing | nextpnr-ecp5 | 0.11.1 (pip `yowasp-nextpnr-ecp5==0.11.1.0.post826`) |
| Bitstream | `ecppack` | bundled with the nextpnr package |
| Formal | SymbiYosys + Z3 | bundled with `yowasp-yosys` |
| Board programming | `openFPGALoader` | **not installed here; not run** |
| Vendor flow (alternative) | Vivado | script provided (`fpga/synth/vivado_synth.tcl`), **not run: Vivado is not available** |

The tool must be runnable **in this repository's reproduction path without a licence**, because
"clock frequency actually achieved" must come from a flow anyone can re-run. That requirement
eliminates boards whose only supported flow is proprietary.

## 7. Board selection

### 7.1 Decision criteria (from §2–§6)

| ID | Criterion | Weight |
|---|---|---|
| C1 | Open toolchain flow runnable here (synthesis + P&R + timing + bitstream) | must |
| C2 | ≥ 80 × 18 Kb block RAM (design needs 64–80, plus headroom for `MAX_CTX=8`) | must |
| C3 | ≥ 16 multipliers, ≥ 20 k LUTs | must |
| C4 | Host link able to carry register + memory traffic for bring-up (USB-serial/Ethernet) | must |
| C5 | Programmable/debuggable with open tools (JTAG) | must |
| C6 | PCIe edge connector with a usable open endpoint path | desirable |
| C7 | Documented public pinout (constraints must be verifiable) | must |

### 7.2 Candidates

| Board / device | C1 | C2 (EBR) | C4 host link | C6 PCIe | Evidence status |
|---|---|---|---|---|---|
| **Radiona ULX3S-85F** — Lattice LFE5U-85F-6BG381C | yes (Yosys + nextpnr-ecp5 + ecppack) | 208 (3,744 Kb) | FT231XS USB-serial (3 Mbit/s) + 500 kbit JTAG | **no** | LUT/EBR/UART/crystal facts from vendor/board pages (sources below); multiplier count taken from nextpnr output, not memory |
| ULX3S-45F (LFE5U-45F) | yes | 108 | same | no | same sources; 108 EBR fits the default build but leaves little headroom |
| Lattice ECP5 PCI Express development kit | partial (device supported; **PCIe endpoint is Lattice's commercial IP**; open path = a 2020 Gen1×1 experiment) | not verified in this session | PCIe | yes | PCIe IP status from search results below; board details **not verified** |
| Digilent Arty A7-100T (Xilinx Artix-7; target of the SilicaFlux `synth/vivado` scripts in this repo) | **no** (Vivado only; none available here) | not verified here | USB-serial | no | would yield *no* achieved-frequency number in this environment |
| Xilinx PCIe boards (Alveo / Acorn-class Artix-7) | **no** (Vivado + XDMA/QDMA IP) | — | PCIe | yes | not evaluated further: C1 fails |

### 7.3 Selection: **Radiona ULX3S-85F (LFE5U-85F-6BG381C, speed grade 6)**

Rationale, strictly against the criteria: it is the only candidate that satisfies **C1** (the
flow is reproducible here and yields a real post-route Fmax and a real bitstream), **C2/C3** with
~2.5× headroom on block RAM, **C4/C5** through one USB cable, and **C7** (open-hardware board
with a public pinout).

**What the selection costs (C6 fails), explicitly:**

1. The board has **no PCIe**. The host link is a UART bridge + an on-chip *host-memory stand-in*
   (`rtl/fpga/`). This validates the device core's behaviour end to end in hardware, **not** the
   PCIe-specific parts of the contract (TLP ordering, MSI-X re-fire, completion timeouts,
   IOMMU).
2. **Slowest speed grade** (-6): the achieved Fmax is a conservative figure for this board and
   not representative of a -8 part.
3. Results on this board say nothing about the SF-G1 as a PCIe card. A PCIe bring-up needs a
   different board plus a vendor PCIe shell — an **open item**, not a deliverable here.

Sources consulted for §7 (search results; board details not independently measured):
ULX3S product/manual pages ([crowdsupply.com/radiona/ulx3s](https://crowdsupply.com/radiona/ulx3s),
[radiona.org/ulx3s](https://radiona.org/ulx3s/), [emard/ulx3s MANUAL](https://github.com/emard/ulx3s/blob/master/doc/MANUAL.md));
ECP5 family table ([latticesemi.com/ECP5](https://www.latticesemi.com/ECP5): LFE5U-85 = 84 K LUT, 208 × 18 Kb sysMEM);
ECP5 PCIe status ([Lattice PCIe endpoint IP — commercial](https://www.latticesemi.com/products/designsoftwareandip/intellectualproperty/ipcore/ipcores01/pciexpressendpointcore),
[ecp5-pcie GSoC 2020 report](https://ecp5-pcie.github.io/gsoc/2020/09/23/development-report.html)).

## 8. Reality check (generated by `scripts/make_report.py` from `reports/results/fpga_*.json`; the numbers are Yosys/nextpnr results, not measurements)

A-priori estimates (§4, written before any synthesis) against the most pipelined variant V5 (the baseline V0 in brackets), including the bring-up shell (UART bridge, 16 KiB host-RAM stand-in):

| quantity | a-priori (§4) | synthesised / placed | verdict |
|---|---|---|---|
| 4-input LUTs | 3,000 – 6,000 | 6,067 LUT4 (+ 1,413 carry cells; nextpnr TRELLIS_COMB 9,271 = 11% of the device) [V0: TRELLIS_COMB 8,987] | LUT4 count at the top of the estimate; counting the carry cells placed in the same slices, the logic is about 50 % larger than the estimate |
| Flip-flops | 2,500 – 4,500 | 3,415 [V0: 3,096] | inside the estimate |
| 18 Kb block RAM | 64 – 80 | 72 of 208 [V0: 40] | as estimated (the second read copy for VEC_MODE=1 is the cost of the dual read port) |
| 18×18 multipliers | 4 – 16 | 4 | bottom of the range (4 MACs × 8×8 bits) |
| Clock | target 50 MHz, aspiration ≥ 100 MHz | 63.3 MHz post-route at the highest met target (60 MHz); 43.2 MHz for V0 | 50 MHz target met by V4, V5; the ≥ 100 MHz aspiration was **not** reached (see the critical-path note in `reports/optimisation-log.md`) |
| Clock domains | 1 | 1 (core clock from the PLL; UART bridge in the same domain) | as designed |
| I/O | clock, reset, UART, ≥ 4 LEDs | 11 I/O cells | as designed |

Reading the table: the block-RAM and multiplier estimates (derived from bit counts and datapath width) held; the LUT estimate was at its upper edge (more once carry cells are counted); the ≥ 100 MHz aspiration was not derived from the ECP5 speed-grade-6 delay model and was **not** met — see the critical-path analysis in `reports/optimisation-log.md` §3.

