// SPDX-License-Identifier: GPL-2.0-only
#include "sfg1_user.h"
#include "sfg1rt.h"

struct sfg1rt {
	struct sfg1_dev dev;
	struct sfg1_bo stage;           /* one staging BO for every transfer */
	uint64_t stage_bytes;
	uint64_t brk;                   /* device-window bump pointer (bytes) */
	int phase_split;
	int64_t (*clock_ns)(void *);
	void *clock_arg;
	sfg1rt_timing t;
};

static int64_t default_clock(void *a) { (void)a; return sfg1_now_ns(); }
static inline int64_t now(sfg1rt *r) { return r->clock_ns ? r->clock_ns(r->clock_arg) : default_clock(NULL); }

sfg1rt *sfg1rt_create(uint64_t stage_bytes, int *err)
{
	char path[64]; int rc; sfg1rt *r = calloc(1, sizeof(*r));
	if (!r) { if (err) *err = -ENOMEM; return NULL; }
	r->clock_ns = default_clock;
	if ((rc = sfg1_find_device(path, sizeof(path))) || (rc = sfg1_open(path, &r->dev))) { free(r); if (err) *err = rc; return NULL; }
	if ((rc = sfg1_bo_create(&r->dev, stage_bytes, &r->stage))) { sfg1_close(&r->dev); free(r); if (err) *err = rc; return NULL; }
	r->stage_bytes = r->stage.size;
	if (err) *err = 0;
	return r;
}
void sfg1rt_destroy(sfg1rt *r) { if (!r) return; sfg1_bo_destroy(&r->dev, &r->stage); sfg1_close(&r->dev); free(r); }
void sfg1rt_set_clock(sfg1rt *r, int64_t (*clock_ns)(void *), void *arg) { r->clock_ns = clock_ns; r->clock_arg = arg; }
void sfg1rt_set_phase_split(sfg1rt *r, int on) { r->phase_split = on; }
sfg1rt_timing *sfg1rt_timing_get(sfg1rt *r) { return &r->t; }
uint64_t sfg1rt_window_bytes(const sfg1rt *r) { return r->dev.window; }
static void sfg1rt_dreset(sfg1rt *r) { r->brk = 0; }
static int sfg1rt_dalloc(sfg1rt *r, uint64_t bytes, uint64_t *off)
{
	uint64_t a = (r->brk + 15) & ~15ull;
	if (bytes > r->dev.window || a > r->dev.window - bytes) return -ENOSPC;
	*off = a; r->brk = a + bytes;
	return 0;
}

/* Run a job. With phase_split the three phases are separate jobs so their time can be attributed. */
static int run_phase(sfg1rt *r, struct drm_sfg1_cmd *c, uint32_t n, int64_t *acc)
{
	int64_t t0 = now(r);
	int rc = sfg1_run(&r->dev, c, n);
	if (acc) *acc += now(r) - t0;
	r->t.jobs++; r->t.cmds += n;
	return rc;
}
static int run3(sfg1rt *r, struct drm_sfg1_cmd *up, uint32_t nu, struct drm_sfg1_cmd *k, uint32_t nk, struct drm_sfg1_cmd *down, uint32_t nd)
{
	int rc;
	if (r->phase_split) {
		if ((rc = run_phase(r, up, nu, &r->t.h2d_ns))) return rc;
		if ((rc = run_phase(r, k, nk, &r->t.kernel_ns))) return rc;
		return run_phase(r, down, nd, &r->t.d2h_ns);
	}
	struct drm_sfg1_cmd all[64]; uint32_t n = 0;
	if (nu + nk + nd > 63) return -E2BIG;
	memcpy(all + n, up, nu * sizeof(*up)); n += nu;
	memcpy(all + n, k, nk * sizeof(*k)); n += nk;
	memcpy(all + n, down, nd * sizeof(*down)); n += nd;
	return run_phase(r, all, n, &r->t.kernel_ns);
}

int sfg1rt_vec_i8(sfg1rt *r, uint32_t op, const int8_t *a, const int8_t *b, int8_t *out, size_t n)
{
	uint64_t oa, ob, oc, s = 0; int rc;
	if (n % 4 || !n) return -EINVAL;
	if (3 * n > r->stage_bytes) return -E2BIG;
	sfg1rt_dreset(r);
	if ((rc = sfg1rt_dalloc(r, n, &oa)) || (rc = sfg1rt_dalloc(r, n, &ob)) || (rc = sfg1rt_dalloc(r, n, &oc))) return rc;
	memcpy((int8_t *)r->stage.map + s, a, n); memcpy((int8_t *)r->stage.map + n, b, n);
	struct drm_sfg1_cmd up[2] = { sfg1_cmd_h2d(&r->stage, 0, oa, n), sfg1_cmd_h2d(&r->stage, n, ob, n) };
	struct drm_sfg1_cmd k = sfg1_cmd_vec(op, oa, ob, oc, n / 4);
	struct drm_sfg1_cmd down = sfg1_cmd_d2h(&r->stage, 2 * n, oc, n);
	if ((rc = run3(r, up, 2, &k, 1, &down, 1))) return rc;
	memcpy(out, (int8_t *)r->stage.map + 2 * n, n);
	r->t.bytes_h2d += 2 * n; r->t.bytes_d2h += n;
	return 0;
}

int sfg1rt_relu_i8(sfg1rt *r, const int8_t *x, int8_t *out, size_t n)
{
	uint64_t ox, oc; int rc;
	if (n % 4 || !n) return -EINVAL;
	if (2 * n > r->stage_bytes) return -E2BIG;
	sfg1rt_dreset(r);
	if ((rc = sfg1rt_dalloc(r, n, &ox)) || (rc = sfg1rt_dalloc(r, n, &oc))) return rc;
	memcpy(r->stage.map, x, n);
	struct drm_sfg1_cmd up = sfg1_cmd_h2d(&r->stage, 0, ox, n);
	struct drm_sfg1_cmd k = sfg1_cmd_vec(DRM_SFG1_VEC_RELU8, ox, 0, oc, n / 4);
	struct drm_sfg1_cmd down = sfg1_cmd_d2h(&r->stage, n, oc, n);
	if ((rc = run3(r, &up, 1, &k, 1, &down, 1))) return rc;
	memcpy(out, (int8_t *)r->stage.map + n, n);
	r->t.bytes_h2d += n; r->t.bytes_d2h += n;
	return 0;
}

int sfg1rt_dot_i8(sfg1rt *r, const int8_t *a, const int8_t *b, size_t n, int32_t *out)
{
	uint64_t oa, ob, oc; int rc;
	if (n % 4 || !n) return -EINVAL;
	if (2 * n + 16 > r->stage_bytes) return -E2BIG;
	sfg1rt_dreset(r);
	if ((rc = sfg1rt_dalloc(r, n, &oa)) || (rc = sfg1rt_dalloc(r, n, &ob)) || (rc = sfg1rt_dalloc(r, 16, &oc))) return rc;
	memcpy(r->stage.map, a, n); memcpy((int8_t *)r->stage.map + n, b, n);
	struct drm_sfg1_cmd up[2] = { sfg1_cmd_h2d(&r->stage, 0, oa, n), sfg1_cmd_h2d(&r->stage, n, ob, n) };
	struct drm_sfg1_cmd k = sfg1_cmd_vec(DRM_SFG1_VEC_DOT8, oa, ob, oc, n / 4);
	struct drm_sfg1_cmd down = sfg1_cmd_d2h(&r->stage, 2 * n, oc, 4);
	if ((rc = run3(r, up, 2, &k, 1, &down, 1))) return rc;
	memcpy(out, (int8_t *)r->stage.map + 2 * n, 4);
	r->t.bytes_h2d += 2 * n; r->t.bytes_d2h += 4;
	return 0;
}

int sfg1rt_matmul_i8(sfg1rt *r, const int8_t *A, const int8_t *B, int32_t *C, int M, int K, int N)
{
	if (M % 4 || K % 4 || N % 4 || M <= 0 || K <= 0 || N <= 0) return -EINVAL;
	const int MT = M / 4, KT = K / 4, NT = N / 4, T = MT * NT;
	if (KT > 56) return -E2BIG;
	const uint64_t ab = (uint64_t)KT * T * 16, cb = (uint64_t)T * 64;
	if (2 * ab + cb > r->stage_bytes) return -E2BIG;
	uint64_t da, db, dc; int rc;
	sfg1rt_dreset(r);
	if ((rc = sfg1rt_dalloc(r, ab, &da)) || (rc = sfg1rt_dalloc(r, ab, &db)) || (rc = sfg1rt_dalloc(r, cb, &dc))) return rc;
	int8_t *sa = (int8_t *)r->stage.map, *sb = sa + ab;
	/* tile arrays: for K-tile kk, tile t=(i,j) holds A(i,kk) resp. B(kk,j) -- replicated so one TEN command covers every output tile */
	for (int kk = 0; kk < KT; kk++)
		for (int i = 0; i < MT; i++)
			for (int j = 0; j < NT; j++) {
				int8_t *ta = sa + ((uint64_t)kk * T + (uint64_t)i * NT + j) * 16, *tb = sb + ((uint64_t)kk * T + (uint64_t)i * NT + j) * 16;
				for (int p = 0; p < 4; p++)
					for (int q = 0; q < 4; q++) { ta[p * 4 + q] = A[(4 * i + p) * K + 4 * kk + q]; tb[p * 4 + q] = B[(4 * kk + p) * N + 4 * j + q]; }
			}
	struct drm_sfg1_cmd up[2] = { sfg1_cmd_h2d(&r->stage, 0, da, ab), sfg1_cmd_h2d(&r->stage, ab, db, ab) };
	struct drm_sfg1_cmd k[64];
	for (int kk = 0; kk < KT; kk++) k[kk] = sfg1_cmd_ten(da + (uint64_t)kk * T * 16, db + (uint64_t)kk * T * 16, dc, T, kk > 0);
	struct drm_sfg1_cmd down = sfg1_cmd_d2h(&r->stage, 2 * ab, dc, cb);
	if (r->phase_split) {                                    /* the compute phase may need more than 63 commands */
		if ((rc = run_phase(r, up, 2, &r->t.h2d_ns)) || (rc = run_phase(r, k, KT, &r->t.kernel_ns)) || (rc = run_phase(r, &down, 1, &r->t.d2h_ns))) return rc;
	} else if ((rc = run3(r, up, 2, k, KT, &down, 1))) return rc;
	const int32_t *sc = (const int32_t *)((int8_t *)r->stage.map + 2 * ab);
	for (int i = 0; i < MT; i++)
		for (int j = 0; j < NT; j++)
			for (int p = 0; p < 4; p++)
				for (int q = 0; q < 4; q++) C[(4 * i + p) * N + 4 * j + q] = sc[((uint64_t)i * NT + j) * 16 + p * 4 + q];
	r->t.bytes_h2d += 2 * ab; r->t.bytes_d2h += cb;
	return 0;
}

int sfg1rt_mlp_i8(sfg1rt *r, const int8_t *X, const int8_t *W1, const int8_t *W2, int IN, int HID, int OUT, int shift, int32_t *Y)
{
	int32_t *h32 = malloc((size_t)HID * 4 * sizeof(int32_t)); int8_t *h8 = malloc((size_t)HID * 4), *h8r = malloc((size_t)HID * 4);
	int rc = 0;
	if (!h32 || !h8 || !h8r) { rc = -ENOMEM; goto out; }
	if ((rc = sfg1rt_matmul_i8(r, W1, X, h32, HID, IN, 4))) goto out;                    /* H1 = W1 * X      (device, TEN) */
	for (int i = 0; i < HID * 4; i++) {                                                  /* requantise       (host) */
		int32_t v = h32[i] >> shift;
		h8[i] = (int8_t)(v > 127 ? 127 : v < -128 ? -128 : v);
	}
	if ((rc = sfg1rt_relu_i8(r, h8, h8r, (size_t)HID * 4))) goto out;                    /* ReLU             (device, VEC) */
	rc = sfg1rt_matmul_i8(r, W2, h8r, Y, OUT, HID, 4);                                   /* Y = W2 * H       (device, TEN) */
out:
	free(h32); free(h8); free(h8r);
	return rc;
}
