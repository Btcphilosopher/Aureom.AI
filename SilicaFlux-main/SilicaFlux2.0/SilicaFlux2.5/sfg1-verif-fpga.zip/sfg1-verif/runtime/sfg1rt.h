/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * sfg1rt - SF-G1 runtime (host side). Built ONLY on the driver's public UAPI through its own
 * header-only helper (vendor/sfg1-driver/examples/sfg1_user.h), so the same source runs against
 *   - the userspace driver simulation over the RTL  (compile with -include driver/usim/ksim_libc.h)
 *   - a real /dev/accel/accelN                       (compile without it; NOT exercised: no hardware)
 * It owns what a runtime owns: a staging buffer, a bump allocator over the context's device window,
 * data-layout conversion (4x4 tiling), command batching, and optional phase-split timing.
 */
#ifndef SFG1RT_H
#define SFG1RT_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct sfg1rt sfg1rt;                              /* opaque: the implementation uses sfg1_user.h (C only) */
typedef struct { int64_t h2d_ns, kernel_ns, d2h_ns; uint64_t jobs, cmds, bytes_h2d, bytes_d2h; } sfg1rt_timing;

sfg1rt *sfg1rt_create(uint64_t stage_bytes, int *err);     /* NULL on failure, *err = -errno */
void sfg1rt_destroy(sfg1rt *r);
void sfg1rt_set_clock(sfg1rt *r, int64_t (*clock_ns)(void *), void *arg);   /* default: CLOCK_MONOTONIC */
void sfg1rt_set_phase_split(sfg1rt *r, int on);            /* 1: H2D, compute, D2H as three jobs so each can be timed */
sfg1rt_timing *sfg1rt_timing_get(sfg1rt *r);
uint64_t sfg1rt_window_bytes(const sfg1rt *r);


/* C[i] = A[i] op B[i] on n INT8 lanes (n multiple of 4); op = DRM_SFG1_VEC_{ADD8,SUB8,MAX8,XOR32,AND32,MUL8} */
int  sfg1rt_vec_i8(sfg1rt *r, uint32_t op, const int8_t *a, const int8_t *b, int8_t *out, size_t n);
int  sfg1rt_relu_i8(sfg1rt *r, const int8_t *x, int8_t *out, size_t n);
int  sfg1rt_dot_i8(sfg1rt *r, const int8_t *a, const int8_t *b, size_t n, int32_t *out);
/* C[MxN] (int32) = A[MxK] (int8) * B[KxN] (int8), row-major; M, K, N multiples of 4. Tiles on the host,
 * one TEN command per K-tile (accumulating on the device). */
int  sfg1rt_matmul_i8(sfg1rt *r, const int8_t *A, const int8_t *B, int32_t *C, int M, int K, int N);
/* Two-layer INT8 MLP on 4 input vectors: H = relu(requant(W1 X)); Y = W2 H.
 * X[IN x 4], W1[HID x IN], W2[OUT x HID]; requant = arithmetic >> shift, saturate to INT8. */
int  sfg1rt_mlp_i8(sfg1rt *r, const int8_t *X, const int8_t *W1, const int8_t *W2, int IN, int HID, int OUT,
		   int shift, int32_t *Y);
#ifdef __cplusplus
}
#endif
#endif
