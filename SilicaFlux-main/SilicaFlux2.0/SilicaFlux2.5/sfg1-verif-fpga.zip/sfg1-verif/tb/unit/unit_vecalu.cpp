// SPDX-License-Identifier: GPL-2.0-only
// Unit test: sfg1_vecalu vs the golden model. Exhaustive over every (a,b) byte pair for every lane op
// (all 4 lanes carry different pairs), then random full words. DOT8 is checked through the `dot` output.
#include "Vvecalu.h"
#include "verilated.h"
#include "sfg1_model.h"
#include <cstdio>
#include <cstdlib>
static uint64_t rs = 88172645463325252ull; static inline uint64_t rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
int main(int argc, char **argv)
{
	Verilated::commandArgs(argc, argv); Vvecalu *m = new Vvecalu; long checks = 0, bad = 0;
	auto chk = [&](uint32_t op, uint32_t a, uint32_t b) {
		m->op = op; m->a = a; m->b = b; m->eval(); checks++;
		uint32_t want = op == 7 ? 0 : sfg1m_vec_lane(op, a, b);
		int32_t wd = sfg1m_dot8(a, b);
		if (m->y != want || (int32_t)m->dot != wd) { if (++bad < 6) printf("MISMATCH op=%u a=%08x b=%08x y=%08x want=%08x dot=%d want=%d\n", op, a, b, m->y, want, (int32_t)m->dot, wd); }
	};
	for (uint32_t op = 0; op < 8; op++)
		for (uint32_t x = 0; x < 256; x++)
			for (uint32_t y = 0; y < 256; y++) {
				chk(op, x | (y << 8) | ((x ^ 0x5a) << 16) | ((y ^ 0xa5) << 24), y | (x << 8) | ((y ^ 0x33) << 16) | ((x ^ 0xcc) << 24));
				chk(op, x * 0x01010101u, y * 0x01010101u);
			}
	for (long i = 0; i < 4000000; i++) chk((uint32_t)(rnd() & 7), (uint32_t)rnd(), (uint32_t)rnd());
	printf("unit_vecalu: %ld checks, %ld mismatches\n", checks, bad); delete m; return bad ? 1 : 0;
}
