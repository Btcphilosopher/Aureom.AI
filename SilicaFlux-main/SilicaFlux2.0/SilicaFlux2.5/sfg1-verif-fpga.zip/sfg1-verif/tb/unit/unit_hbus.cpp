// SPDX-License-Identifier: GPL-2.0-only
// Unit test: sfg1_hbus. (1) ownership mux (2) epoch tag = number of aborts (3) responses with a stale tag are
// dropped, current-tag responses are delivered (registered, one cycle) (4) no new request leaves the core while
// the abort pulse is high.
#include "Vhbus.h"
#include "verilated.h"
#include <cstdio>
static int bad = 0, checks = 0;
#define CK(c, ...) do { checks++; if (!(c)) { if (++bad < 8) { printf("FAIL: "); printf(__VA_ARGS__); printf("\n"); } } } while (0)
int main(int argc, char **argv)
{
	Verilated::commandArgs(argc, argv); Vhbus *m = new Vhbus;
	auto tick = [&] { m->clk = 0; m->eval(); m->clk = 1; m->eval(); };
	m->rst_n = 0; tick(); tick(); m->rst_n = 1; m->eval();
	m->eng_busy = 0; m->__SYM__abort = 0; m->f_mrd_req = 1; m->f_mrd_addr = 0x1000; m->f_mrd_len = 16; m->e_mrd_req = 0; m->e_mrd_addr = 0x2000; m->e_mrd_len = 4;
	m->f_mwr_req = 1; m->f_mwr_addr = 0x30; m->f_mwr_data = 7; m->e_mwr_req = 0; m->e_mwr_addr = 0x40; m->e_mwr_data = 9; m->eval();
	CK(m->mrd_req && m->mrd_addr == 0x1000 && m->mrd_len == 16, "front-end owns the read bus when the engine is idle");
	CK(m->mwr_req && m->mwr_addr == 0x30 && m->mwr_data == 7, "front-end owns the write bus when the engine is idle");
	m->eng_busy = 1; m->e_mrd_req = 1; m->e_mwr_req = 1; m->eval();
	CK(m->mrd_addr == 0x2000 && m->mrd_len == 4 && m->mwr_addr == 0x40 && m->mwr_data == 9, "engine owns both buses while busy");
	m->eng_busy = 0; m->f_mrd_req = 0; m->f_mwr_req = 0; m->e_mrd_req = 0; m->e_mwr_req = 0; m->eval();
	// epoch tag increments on every abort pulse
	for (int k = 0; k < 20; k++) {
		CK(m->mrd_tag == (k & 15), "tag %u after %d aborts", m->mrd_tag, k);
		m->__SYM__abort = 1; m->eval(); tick(); m->__SYM__abort = 0; m->eval();
	}
	// responses: current tag delivered, stale tag dropped, error flag follows the same rule
	int tag = m->mrd_tag;
	m->mrd_valid = 1; m->mrd_data = 0xdeadbeef; m->mrd_rtag = tag; m->mrd_err = 0; tick();
	CK(m->r_valid && m->r_data == 0xdeadbeef && !m->r_err, "in-epoch beat must be delivered");
	m->mrd_rtag = (tag + 1) & 15; tick(); CK(!m->r_valid, "stale-tag beat must be dropped");
	m->mrd_valid = 0; m->mrd_err = 1; m->mrd_rtag = (tag + 15) & 15; tick(); CK(!m->r_err, "stale-tag error must be dropped");
	m->mrd_rtag = tag; tick(); CK(m->r_err, "in-epoch error must be delivered");
	m->mrd_err = 0; tick();
	// a beat that arrives in the same cycle as an abort is dropped (the abort starts a new epoch)
	m->mrd_valid = 1; m->mrd_rtag = tag; m->__SYM__abort = 1; tick(); CK(!m->r_valid, "beat coinciding with an abort must be dropped"); m->__SYM__abort = 0; m->mrd_valid = 0;
	// no new request may leave while abort is high
	m->f_mrd_req = 1; m->e_mwr_req = 1; m->eng_busy = 1; m->__SYM__abort = 1; m->eval();
	CK(!m->mrd_req && !m->mwr_req, "requests must be gated while the abort pulse is high");
	m->__SYM__abort = 0; m->eval(); CK(m->mwr_req, "requests resume after the abort pulse");
	printf("unit_hbus: %d checks, %d failures\n", checks, bad); delete m; return bad ? 1 : 0;
}
