// SPDX-License-Identifier: GPL-2.0-only
// Unit test: sfg1_devmem (NRD=2): synchronous read, read-before-write on collision, read-enable hold,
// both read copies identical after any write sequence.
#include "Vdevmem.h"
#include "verilated.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
static uint64_t rs = 99; static inline uint64_t rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
int main(int argc, char **argv)
{
	Verilated::commandArgs(argc, argv); Vdevmem *m = new Vdevmem; const int D = 64; std::vector<uint32_t> ref(D, 0), seen(D, 0); long checks = 0, bad = 0;
	uint32_t exp0 = 0, exp1 = 0;
	auto tick = [&] { m->clk = 0; m->eval(); m->clk = 1; m->eval(); };
	for (int i = 0; i < D; i++) { m->wr_en = 1; m->wr_addr = i; m->wr_data = 0; m->rd0_en = 0; m->rd1_en = 0; tick(); }
	for (long it = 0; it < 400000; it++) {
		bool we = rnd() & 1, e0 = rnd() % 4 != 0, e1 = rnd() % 4 != 0; uint32_t wa = rnd() % D, wd = (uint32_t)rnd(), a0 = rnd() % D, a1 = rnd() % D;
		m->wr_en = we; m->wr_addr = wa; m->wr_data = wd; m->rd0_en = e0; m->rd0_addr = a0; m->rd1_en = e1; m->rd1_addr = a1;
		uint32_t n0 = ref[a0], n1 = ref[a1];                      // read-before-write: old contents
		tick();
		if (we) ref[wa] = wd;
		if (e0) exp0 = n0; if (e1) exp1 = n1;                      // disabled port holds its previous value
		checks += 2; if (m->rd0_data != exp0 && ++bad < 6) printf("rd0 mismatch it=%ld got %08x want %08x\n", it, m->rd0_data, exp0);
		if (m->rd1_data != exp1 && ++bad < 6) printf("rd1 mismatch it=%ld got %08x want %08x\n", it, m->rd1_data, exp1);
	}
	printf("unit_devmem: %ld checks, %ld mismatches\n", checks, bad); delete m; return bad ? 1 : 0;
}
