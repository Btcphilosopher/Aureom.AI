// SPDX-License-Identifier: GPL-2.0-only
// Unit test: sfg1_cmdchk (BAD_ARGS / BOUNDS / DMA_ERROR / BAD_OPCODE decisions) vs sfg1m_check().
// Structured-random commands concentrate on boundaries, overflows and 64-bit extremes.
#include "Vcmdchk.h"
#include "verilated.h"
#include "sfg1_model.h"
#include <cstdio>
#include <cstdlib>
#ifndef WINB
#define WINB 4096
#endif
static uint64_t rs = 0x1234567887654321ull; static inline uint64_t rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
static uint64_t pick()
{
	const uint64_t W = WINB;
	switch (rnd() % 16) {
	case 0: return 0; case 1: return (rnd() % (W / 4)) * 4; case 2: return W - 4 * (rnd() % 8); case 3: return W + 4 * (rnd() % 3) - 4;
	case 4: return rnd() % W; case 5: return rnd() % (W / 4 + 2); case 6: return 1ull << (58 + rnd() % 6); case 7: return (1ull << (58 + rnd() % 6)) - 1 - rnd() % 3;
	case 8: return ~0ull - rnd() % 5; case 9: return 1ull << (32 + rnd() % 30); case 10: return W / 4 - rnd() % 3; case 11: return W / 16 + rnd() % 3 - 1;
	case 12: return W / 64 + rnd() % 3 - 1; case 13: return rnd(); case 14: return (rnd() % 64) * 4; default: return (1ull << 32) - rnd() % 4;
	}
}
int main(int argc, char **argv)
{
	Verilated::commandArgs(argc, argv); Vcmdchk *m = new Vcmdchk; long checks = 0, bad = 0, cnt[8] = {0};
	sfg1m_dev d{4, (uint32_t)WINB, nullptr};
	static const uint16_t ops[] = {0, 1, 2, 3, 5, 6, 1, 2, 3, 5, 4, 7, 9, 0xffff, 2, 3};
	for (long i = 0; i < 6000000; i++) {
		sfg1m_sqe e; memset(&e, 0, sizeof e);
		e.opcode = ops[rnd() % 16]; e.ctx_id = 0;
		// opcode-aware: set only the fields the opcode uses (so most vectors reach the BOUNDS / OK / DMA rules),
		// then pollute one unused field in ~1 of 6 vectors to exercise the BAD_ARGS rules too
		auto small = [&]() -> uint64_t { return (rnd() % 8 == 0) ? pick() : 4 * (rnd() % (WINB / 8)); };
		switch (e.opcode) {
		case 1: case 5:
			e.len = (rnd() % 4) ? 4 * (1 + rnd() % (WINB / 4)) : pick(); e.dev_a = (rnd() % 3) ? 4 * (rnd() % (WINB / 8)) : pick();
			e.host_addr = (rnd() % 6 == 0) ? (~0ull - rnd() % 128) : (rnd() % 3 == 0 ? pick() : 0x10000 + 4 * (rnd() % 1000)); break;
		case 2:
			e.exec_op = (rnd() % 10 == 0) ? (uint32_t)(rnd() % 12) : (uint32_t)(rnd() % 8);
			e.len = (rnd() % 4) ? 1 + rnd() % (WINB / 16) : pick(); e.dev_a = small(); e.dev_b = e.exec_op == 3 && (rnd() % 4) ? 0 : small(); e.dev_c = small(); break;
		case 3:
			e.flags = (rnd() % 8 == 0) ? (uint16_t)(rnd() % 4) : (uint16_t)(rnd() % 2);
			e.len = (rnd() % 4) ? 1 + rnd() % (WINB / 64) : pick(); e.dev_a = small(); e.dev_b = small(); e.dev_c = small(); break;
		default: break;
		}
		if (rnd() % 6 == 0) switch (rnd() % 7) {
			case 0: e.flags = (uint16_t)rnd(); break; case 1: e.exec_op = (uint32_t)rnd(); break; case 2: e.host_addr = rnd(); break;
			case 3: e.len = rnd(); break; case 4: e.dev_a = pick(); break; case 5: e.dev_b = pick(); break; default: e.dev_c = pick(); break; }
		m->op = e.opcode; m->flags = e.flags; m->exec_op = e.exec_op; m->host_addr = e.host_addr; m->len = e.len; m->a = e.dev_a; m->b = e.dev_b; m->c = e.dev_c; m->eval();
		uint8_t want = sfg1m_check(&d, &e); checks++; cnt[want & 7]++;
		if (m->status != want && ++bad < 8) printf("MISMATCH op=%u flags=%x exec=%u host=%llx len=%llx a=%llx b=%llx c=%llx rtl=%u model=%u\n", e.opcode, e.flags, e.exec_op, (unsigned long long)e.host_addr, (unsigned long long)e.len, (unsigned long long)e.dev_a, (unsigned long long)e.dev_b, (unsigned long long)e.dev_c, m->status, want);
	}
	printf("unit_cmdchk (WIN_B=%d): %ld checks, %ld mismatches; outcomes OK/OPC/CTX/-/BOUNDS/-/DMA/ARGS = %ld %ld %ld %ld %ld %ld %ld %ld\n", WINB, checks, bad, cnt[0], cnt[1], cnt[2], cnt[3], cnt[4], cnt[5], cnt[6], cnt[7]);
	delete m; return bad ? 1 : 0;
}
