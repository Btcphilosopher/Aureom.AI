// SPDX-License-Identifier: GPL-2.0-only
// Differential fuzz: golden model (model/sfg1_model.c) vs the driver mock's mock_exec(), compiled
// from the VERBATIM extraction in build/mock_exec_extracted.inc. Same commands, same initial
// device memory, same host memory; after every command compare status, ALL device memory and
// ALL host memory. Any difference is a finding about the model OR the contract wording.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/types.h>
#include "sfg1_hw.h"
#include "sfg1_model.h"

/* ---- minimal kernel-API shim used by the extracted code ---- */
#define le16_to_cpu(x) (x)
#define le32_to_cpu(x) (x)
#define le64_to_cpu(x) (x)
#define READ_ONCE(x)   (x)
#define mutex_lock(x)   ((void)(x))
#define mutex_unlock(x) ((void)(x))
#define check_mul_overflow(a, b, d) __builtin_mul_overflow((a), (b), (d))
#define check_add_overflow(a, b, d) __builtin_add_overflow((a), (b), (d))
static inline u32 get_unaligned_le32(const void *p) { u32 v; memcpy(&v, p, 4); return v; }
static inline void put_unaligned_le32(u32 v, void *p) { memcpy(p, &v, 4); }

struct sfg1_mock {
	u32 max_ctx; u64 win_size; u8 *devmem; u64 ctx_serial[256];
	u32 inj_scrub_fail, st_scrubs; int region_lock;
};

/* ---- host memory: two valid regions, everything else faults (all-or-nothing) ---- */
#define R0_BASE 0x10000ull
#define R0_SIZE 0x4000ull
#define R1_BASE 0x20000ull
#define R1_SIZE 0x2000ull
struct host { uint8_t r0[R0_SIZE], r1[R1_SIZE]; };
static uint8_t *hm_ptr(struct host *h, uint64_t addr, uint64_t len)
{
	uint64_t end;
	if (__builtin_add_overflow(addr, len, &end)) return NULL;
	if (addr >= R0_BASE && end <= R0_BASE + R0_SIZE) return h->r0 + (addr - R0_BASE);
	if (addr >= R1_BASE && end <= R1_BASE + R1_SIZE) return h->r1 + (addr - R1_BASE);
	return NULL;
}
static struct host *g_mock_host;
static u16 mock_dma(struct sfg1_mock *m, u64 host, void *win, u64 len, u64 owner, bool to_host)
{
	(void)m; (void)owner;
	uint8_t *p = hm_ptr(g_mock_host, host, len);
	if (!p) return SFG1_ST_DMA_ERROR;
	if (to_host) memcpy(p, win, len); else memcpy(win, p, len);
	return SFG1_ST_OK;
}
#include "mock_exec_extracted.inc"

static int m_read(void *u, uint64_t a, void *buf, uint64_t n)
{ uint8_t *p = hm_ptr(u, a, n); if (!p) return 1; memcpy(buf, p, n); return 0; }
static int m_write(void *u, uint64_t a, const void *buf, uint64_t n)
{ uint8_t *p = hm_ptr(u, a, n); if (!p) return 1; memcpy(p, buf, n); return 0; }

static uint64_t rs = 88172645463325252ull;
static inline uint64_t rnd(void) { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
static inline uint64_t rn(uint64_t n) { return rnd() % n; }

#define NCTX 4
#define WIN  1024u
/* structured pool for a 64-bit field */
static uint64_t pick(uint64_t win)
{
	switch (rn(14)) {
	case 0: return 0;
	case 1: return rn(win / 4) * 4;
	case 2: return win - 4 * rn(8);
	case 3: return win + 4 * rn(3) - 4;
	case 4: return rn(win);                      /* maybe misaligned */
	case 5: return rn(win / 4 + 2);              /* small counts */
	case 6: return 1ull << (58 + rn(6));         /* overflow of *64, *16, *4 */
	case 7: return (1ull << (58 + rn(6))) - 1;
	case 8: return ~0ull - rn(4);
	case 9: return 1ull << (32 + rn(30));
	case 10: return win / 4 - rn(3);
	case 11: return win / 16 + rn(3) - 1;
	case 12: return win / 64 + rn(3) - 1;
	default: return rn(32) * 4;
	}
}
static uint64_t pick_host(void)
{
	switch (rn(9)) {
	case 0: return R0_BASE + rn(R0_SIZE / 4) * 4;
	case 1: return R1_BASE + rn(R1_SIZE / 4) * 4;
	case 2: return R0_BASE + R0_SIZE - 4 * rn(8);          /* straddles the end */
	case 3: return R1_BASE - 4 * rn(4);
	case 4: return rn(0x40000);
	case 5: return 0;
	case 6: return ~0ull - rn(8);
	case 7: return R0_BASE + rn(R0_SIZE);                  /* misaligned */
	default: return R0_BASE;
	}
}

static const char *stn[8] = {"OK","BAD_OPCODE","BAD_CTX","ENG_DIS","BOUNDS","FETCH","DMA_ERR","BAD_ARGS"};
int main(int argc, char **argv)
{
	long iters = argc > 1 ? atol(argv[1]) : 2000000;
	if (argc > 2) rs ^= strtoull(argv[2], 0, 0) * 0x9e3779b97f4a7c15ull;
	static uint8_t dm[NCTX * WIN], dk[NCTX * WIN];
	static struct host hm_model, hm_mock;
	struct sfg1_mock mk = { .max_ctx = NCTX, .win_size = WIN, .devmem = dk };
	for (int i = 0; i < 256; i++) mk.ctx_serial[i] = 1;
	sfg1m_dev md = { .max_ctx = NCTX, .win_bytes = WIN, .mem = dm };
	sfg1m_host mh = { m_read, m_write, &hm_model };
	g_mock_host = &hm_mock;
	static long cnt[8][8]; long mismatches = 0;

	for (long it = 0; it < iters; it++) {
		if ((it & 0xffff) == 0) {                         /* reseed memories */
			for (unsigned i = 0; i < sizeof(dm); i++) dm[i] = dk[i] = (uint8_t)rnd();
			for (unsigned i = 0; i < R0_SIZE; i++) hm_model.r0[i] = hm_mock.r0[i] = (uint8_t)rnd();
			for (unsigned i = 0; i < R1_SIZE; i++) hm_model.r1[i] = hm_mock.r1[i] = (uint8_t)rnd();
		}
		sfg1m_sqe e; memset(&e, 0, sizeof(e));
		static const uint16_t ops[] = {0,1,2,3,5,6,1,2,3,5,2,3,4,7,0xffff};
		e.opcode = ops[rn(sizeof(ops)/2)];
		e.ctx_id = rn(16) == 0 ? (uint16_t)(NCTX + rn(3)) : (uint16_t)rn(NCTX);
		e.cid = (uint16_t)rnd();
		/* mostly well-formed for the opcode, sometimes polluted */
		int pollute = rn(6) == 0;
		switch (e.opcode) {
		case 1: case 5:
			e.host_addr = pick_host(); e.len = pick(WIN); e.dev_a = pick(WIN); break;
		case 2:
			e.exec_op = rn(12) == 0 ? (uint32_t)rn(10) : (uint32_t)rn(8);
			e.len = pick(WIN); e.dev_a = pick(WIN); e.dev_b = e.exec_op == 3 && rn(4) ? 0 : pick(WIN); e.dev_c = pick(WIN);
			if (rn(3) == 0) { e.dev_a = (rn(WIN/4)) * 4; e.dev_b = rn(WIN/4) * 4; e.dev_c = rn(2) ? e.dev_a : e.dev_b; e.len = rn(WIN/4 / 2) + 1; }
			break;
		case 3:
			e.flags = rn(8) == 0 ? (uint16_t)rnd() : (uint16_t)rn(2);
			e.len = rn(3) ? rn(WIN / 64 + 2) : pick(WIN); e.dev_a = pick(WIN); e.dev_b = pick(WIN); e.dev_c = pick(WIN);
			if (rn(2)) { e.dev_a = rn(WIN/4) * 4; e.dev_b = rn(WIN/4) * 4; e.dev_c = rn(WIN/4) * 4; }
			break;
		default: break;
		}
		if (pollute) {
			switch (rn(9)) {
			case 0: e.flags = (uint16_t)rnd(); break;
			case 1: e.exec_op = (uint32_t)rnd(); break;
			case 2: e.host_addr = rnd(); break;
			case 3: e.rsvd0 = (uint32_t)rnd(); break;
			case 4: e.rsvd1 = rnd(); break;
			case 5: e.len = rnd(); break;
			case 6: e.dev_b = rnd(); break;
			case 7: e.dev_c = rnd(); break;
			default: e.dev_a = rnd(); break;
			}
		}
		uint8_t sm = sfg1m_exec(&md, &e, &mh);
		u16 sk = mock_exec(&mk, (const struct sfg1_sq_entry *)&e);
		cnt[e.opcode & 7][sm & 7]++;
		int bad = sm != sk || memcmp(dm, dk, sizeof(dm)) ||
			  memcmp(hm_model.r0, hm_mock.r0, R0_SIZE) || memcmp(hm_model.r1, hm_mock.r1, R1_SIZE);
		if (bad && ++mismatches <= 10) {
			printf("MISMATCH it=%ld op=%u ctx=%u flags=%#x exec=%u host=%#llx len=%#llx a=%#llx b=%#llx c=%#llx "
			       "rsvd0=%#x rsvd1=%#llx: model=%s mock=%s%s\n", it, e.opcode, e.ctx_id, e.flags, e.exec_op,
			       (unsigned long long)e.host_addr, (unsigned long long)e.len, (unsigned long long)e.dev_a,
			       (unsigned long long)e.dev_b, (unsigned long long)e.dev_c, e.rsvd0, (unsigned long long)e.rsvd1,
			       sm < 8 ? stn[sm] : "?", sk < 8 ? stn[sk] : "?", sm == sk ? " (memory differs)" : "");
			/* resync so one disagreement does not cascade */
			memcpy(dk, dm, sizeof(dm)); memcpy(&hm_mock, &hm_model, sizeof(hm_model));
		}
	}
	printf("fuzz_model_vs_mock: %ld commands, %ld mismatches\n", iters, mismatches);
	printf("coverage (rows: opcode 0..7, cols: status OK,BAD_OPC,BAD_CTX,ENG_DIS,BOUNDS,FETCH,DMA_ERR,BAD_ARGS)\n");
	for (int o = 0; o < 8; o++) { printf(" op%d:", o); for (int s = 0; s < 8; s++) printf(" %8ld", cnt[o][s]); printf("\n"); }
	return mismatches ? 1 : 0;
}
