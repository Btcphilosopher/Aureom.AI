// SPDX-License-Identifier: GPL-2.0-only
// Verilated sfg1_fpga_top (the FPGA top, -DSIM) as a UART peer on stdin/stdout. The host tool
// (tools/sfg1_bringup.py) speaks the same byte protocol to this and to a real serial port.
//   shell_sim [core_mhz baud]   reads request bytes on stdin, writes response bytes on stdout.
#include "Vsfg1_fpga_top.h"
#include "verilated.h"
#include <cstdio>
#include <cstdlib>
#include <deque>
#include <poll.h>
#include <unistd.h>

int main(int argc, char **argv)
{
	Verilated::commandArgs(argc, argv);
	const long core_mhz = argc > 1 ? atol(argv[1]) : 50, baud = argc > 2 ? atol(argv[2]) : 2000000;
	const int cpb = (int)(core_mhz * 1000000 / baud);
	Vsfg1_fpga_top *t = new Vsfg1_fpga_top;
	std::deque<int> bits;                 // bits to drive on ftdi_txd (start, 8 data, stop), each held cpb cycles
	int hold = 0, cur = 1;
	int rstate = 0, rcnt = 0, rbit = 0, rsh = 0, prev_rx = 1;
	unsigned long long cyc = 0; int idle = 0; bool eof = false; int drain = 0;
	t->ftdi_txd = 1; t->clk_25mhz = 0; t->eval();
	for (int i = 0; i < 90000; i++) { t->clk_25mhz = 0; t->eval(); t->clk_25mhz = 1; t->eval(); }   // power-on: PLL lock + 65536-cycle reset hold
	for (;;) {
		if (bits.empty() && hold == 0 && !eof) {
			struct pollfd p = {0, POLLIN, 0};
			int timeout = idle > 20000 ? -1 : 0;                    // device quiet and host silent: wait for the host
			if (poll(&p, 1, timeout) > 0 && (p.revents & POLLIN)) {
				unsigned char b; ssize_t n = read(0, &b, 1);
				if (n == 1) { bits.push_back(0); for (int i = 0; i < 8; i++) bits.push_back((b >> i) & 1); bits.push_back(1); idle = 0; }
				else eof = true;
			}
		}
		if (hold == 0 && !bits.empty()) { cur = bits.front(); bits.pop_front(); hold = cpb; }
		t->ftdi_txd = cur; if (hold) hold--; if (hold == 0 && bits.empty()) cur = 1;
		t->clk_25mhz = 0; t->eval(); t->clk_25mhz = 1; t->eval(); cyc++; idle++;
		// UART receiver on ftdi_rxd (mid-bit sampling)
		int rx = t->ftdi_rxd;
		if (rstate == 0) { if (!rx && prev_rx) { rstate = 1; rcnt = cpb / 2; } }
		else if (--rcnt <= 0) {
			rcnt = cpb;
			if (rstate == 1) { if (!rx) { rstate = 2; rbit = 0; rsh = 0; } else rstate = 0; }
			else if (rstate == 2) { rsh |= rx << rbit; if (++rbit == 8) rstate = 3; }
			else { if (rx) { unsigned char o = (unsigned char)rsh; if (write(1, &o, 1) != 1) return 2; idle = 0; } rstate = 0; }
		}
		prev_rx = rx;
		if (eof && bits.empty() && hold == 0 && ++drain > 5000) break;
	}
	t->final(); delete t; return 0;
}
