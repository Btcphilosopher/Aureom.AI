// SPDX-License-Identifier: GPL-2.0-only
#include "sfg1sys.h"
#include "Vsfg1_sim_top.h"
#include "verilated.h"
#include <cstdio>
#include <cstdlib>

bool HostMem::valid(uint64_t a, uint64_t n) const
{
	uint64_t end;
	if (__builtin_add_overflow(a, n, &end) || end > d.size() || a < 0x1000) return false;
	for (auto &h : holes)
		if (a < h.first + h.second && end > h.first) return false;
	return true;
}
uint64_t HostMem::alloc(uint64_t n, uint64_t align)
{
	brk = (brk + align - 1) & ~(align - 1);
	uint64_t a = brk;
	brk += n;
	if (brk > d.size()) { fprintf(stderr, "HostMem exhausted\n"); abort(); }
	memset(&d[a], 0, n);
	return a;
}

SfgSys::SfgSys() : top(new Vsfg1_sim_top)
{
	rng = 0x9e3779b97f4a7c15ull;
	if (const char *b = getenv("SFG1_CYCLE_BUDGET")) cycle_budget = strtoull(b, nullptr, 0);
	hw_reset();
	// discover build parameters through the register interface itself (contract section 2)
	uint32_t l0 = csr_read(0x00c), l1 = csr_read(0x010);
	max_ctx = l0 & 0xffff;
	win_bytes = (l1 >> 16) * 1024;
}
SfgSys::~SfgSys() { top->final(); delete top; }

uint32_t SfgSys::rnd() { rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17; return (uint32_t)(rng >> 11); }
int SfgSys::rr(int lo, int hi) { return hi <= lo ? lo : lo + (int)(rnd() % (uint32_t)(hi - lo + 1)); }
uint16_t SfgSys::chk_mask() { return top->chk_fail_mask; }
uint16_t SfgSys::chk_cnt() { return top->chk_fail_cnt; }

void SfgSys::hw_reset()
{
	beats.clear(); posted.clear(); last_beat_due = last_post_due = 0; irq_pending = 0;
	top->clk = 0; top->rst_n = 0; top->csr_wr = 0; top->csr_addr = 0; top->csr_wdata = 0;
	top->mrd_valid = 0; top->mrd_data = 0; top->mrd_err = 0; top->mrd_rtag = 0; top->mwr_ready = 1; top->mwr_err = 0;
	for (int i = 0; i < 4; i++) { top->clk = 1; top->eval(); top->clk = 0; top->eval(); }
	top->rst_n = 1; top->eval();
}

void SfgSys::deliver_posted()
{
	while (!posted.empty() && posted.front().due <= cycle) {
		Posted p = posted.front(); posted.pop_front();
		if (p.msg) { irq_msgs++; irq_pending++; }
		else if (hm.valid(p.addr, 4)) hm.w32(p.addr, p.data);
	}
}

// One clock. Pre-edge: sample what the DUT presents, decide what the environment drives.
void SfgSys::eval_edge(bool cwr, uint16_t caddr, uint32_t cdata)
{
	// ---- DUT outputs (stable since the previous edge) ----
	bool rd_req = top->mrd_req, wr_req = top->mwr_req, irq = top->irq_msg;
	uint64_t rd_addr = top->mrd_addr, wr_addr = top->mwr_addr; uint32_t wr_data = top->mwr_data;
	int rd_len = top->mrd_len; uint8_t rd_tag = top->mrd_tag;

	// ---- drive inputs for this edge ----
	bool have_beat = !beats.empty() && beats.front().due <= cycle;
	top->mrd_valid = 0; top->mrd_err = 0; top->mrd_data = 0; top->mrd_rtag = 0;
	if (have_beat) {
		Beat b = beats.front(); beats.pop_front();
		top->mrd_rtag = b.tag; top->mrd_data = b.data;
		if (b.err) top->mrd_err = 1; else { top->mrd_valid = 1; rd_beats++; }
	}
	bool ready = !force_wr_stall && ((cfg.wr_stall_prob <= 0.0) || ((rnd() & 0xffff) >= cfg.wr_stall_prob * 65536.0));
	bool wr_ok = wr_req && hm.valid(wr_addr, 4);
	top->mwr_ready = ready;
	top->mwr_err = (wr_req && ready && !wr_ok);
	top->csr_wr = cwr; top->csr_addr = caddr; top->csr_wdata = cdata;
	top->eval();

	// ---- environment reaction to the handshakes at this edge ----
	if (rd_req) {
		rd_reqs++;
		if (trace) trace("MRD", rd_addr, (uint64_t)rd_len);
		if (!hang_reads && !(rd_addr >= hang_lo && rd_addr < hang_hi)) {
			uint64_t t = cycle + 1 + rr(cfg.rd_lat_min, cfg.rd_lat_max) + (uint64_t)late_reads;
			if (t <= last_beat_due) t = last_beat_due + 1;
			for (int i = 0; i < rd_len; i++) {
				uint64_t a = rd_addr + 4ull * i;
				bool bad = force_rd_error || !hm.valid(a, 4);
				Beat b{t, bad ? 0u : hm.r32(a), bad, rd_tag};
				beats.push_back(b); last_beat_due = t;
				if (bad) { rd_faults++; break; }              // an error ends the burst
				t += 1 + cfg.beat_gap;
			}
		}
	}
	if (wr_req && ready) {
		wr_acc++;
		if (trace) trace("MWR", wr_addr, wr_data);
		if (!wr_ok) wr_faults++;
		uint64_t t = cycle + 1 + rr(cfg.wr_lat_min, cfg.wr_lat_max);
		if (t <= last_post_due) t = last_post_due + 1;        // channel is strictly in order
		posted.push_back({t, false, wr_addr, wr_data}); last_post_due = t;
	}
	if (irq) {                                                  // a message is a posted write too
		if (trace) trace("MSI", 0, 0);
		uint64_t t = cycle + 1 + rr(cfg.wr_lat_min, cfg.wr_lat_max);
		if (t <= last_post_due) t = last_post_due + 1;
		posted.push_back({t, true, 0, 0}); last_post_due = t;
	}

	// ---- clock edge ----
	top->clk = 1; top->eval();
	top->clk = 0; top->eval();
	cycle++;
	deliver_posted();
	if (cycle > cycle_budget) throw TestTimeout();
}

void SfgSys::tick()
{
	eval_edge(false, 0, 0);
	if (monitor) monitor(*this);
	if (irq_dispatch && !in_csr && irq_pending && on_irq) {
		irq_pending = 0;
		on_irq();
	}
}

bool SfgSys::run_until(const std::function<bool()> &pred, uint64_t max_cycles)
{
	for (uint64_t i = 0; i < max_cycles; i++) {
		if (pred()) return true;
		tick();
	}
	return pred();
}

void SfgSys::csr_write(uint16_t off, uint32_t v)
{
	bool was = in_csr; in_csr = true;
	if (trace) trace("CSRW", off, v);
	eval_edge(true, off, v);
	if (monitor) monitor(*this);
	top->csr_wr = 0;
	in_csr = was;
}

uint32_t SfgSys::csr_read(uint16_t off)
{
	bool was = in_csr; in_csr = true;
	top->csr_addr = off; top->csr_wr = 0; top->eval();
	uint32_t v = top->csr_rdata;                       // register value at the time the read arrives
	if (trace) trace("CSRR", off, v);
	// the completion cannot overtake earlier posted writes (PCIe producer/consumer ordering)
	eval_edge(false, off, 0);
	for (int guard = 0; !posted.empty() && guard < 100000; guard++) { eval_edge(false, off, 0); if (monitor) monitor(*this); }
	in_csr = was;
	return v;
}
