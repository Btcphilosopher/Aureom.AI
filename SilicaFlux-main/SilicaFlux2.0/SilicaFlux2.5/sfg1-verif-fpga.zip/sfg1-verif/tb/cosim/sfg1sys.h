// SPDX-License-Identifier: GPL-2.0-only
// Co-simulation system around the Verilated SF-G1 core: host memory, host-bus timing/fault model,
// posted-write channel (with interrupt messages), BAR0 access. All time is in DUT clock cycles.
//
// What this models and what it does NOT (also stated in docs/06-performance-methodology.md):
//  + host memory latency/throughput as configured numbers, in-order posted writes, write
//    back-pressure, read errors, hung/late reads, unmapped regions
//  + the PCIe rule that a register read's completion cannot pass earlier posted writes
//  - NOT a PCIe model: no TLP framing, credits, max-payload splitting, relaxed ordering, MSI-X
//    masking, link errors, IOMMU
#ifndef SFG1SYS_H
#define SFG1SYS_H
#include <cstdint>
#include <cstring>
#include <deque>
#include <functional>
#include <string>
#include <vector>

struct Vsfg1_sim_top;
struct TestTimeout {};                // thrown when a test exceeds its cycle budget (a hang is a failure)

struct BusCfg {
	int rd_lat_min = 4, rd_lat_max = 4;   // cycles from request to first beat
	int beat_gap = 0;                     // idle cycles between beats (throttle)
	int wr_lat_min = 2, wr_lat_max = 2;   // posted-write delivery latency
	double wr_stall_prob = 0.0;           // P(mwr_ready low) per cycle
	uint64_t seed = 1;
};

struct HostMem {
	std::vector<uint8_t> d;               // flat memory starting at address 0
	std::vector<std::pair<uint64_t, uint64_t>> holes;   // unmapped [addr, addr+len)
	uint64_t brk = 0x1000;
	std::vector<std::pair<std::string, uint64_t>> named;   // alloc_named cache
	explicit HostMem(size_t n = 4 << 20) : d(n, 0) {}
	std::vector<std::pair<uint64_t, std::vector<uint64_t>>> freel;           // page-multiple blocks, reused by size
	uint64_t alloc_block(uint64_t n) {                                         // zeroed, 4 KiB aligned, recycled on free
		n = (n + 4095) & ~4095ull;
		for (auto &f : freel) if (f.first == n && !f.second.empty()) { uint64_t a = f.second.back(); f.second.pop_back(); memset(&d[a], 0, n); return a; }
		return alloc(n, 4096);
	}
	void free_block(uint64_t a, uint64_t n) {
		n = (n + 4095) & ~4095ull;
		for (auto &f : freel) if (f.first == n) { f.second.push_back(a); return; }
		freel.push_back({n, {a}});
	}
	uint64_t alloc_named(const std::string &key, uint64_t n, uint64_t align = 64) {
		for (auto &p : named) if (p.first == key) return p.second;
		uint64_t a = alloc(n, align); named.push_back({key, a}); return a;
	}
	bool valid(uint64_t a, uint64_t n) const;
	uint64_t alloc(uint64_t n, uint64_t align = 64);    // bump allocator, zeroed
	uint32_t r32(uint64_t a) const { uint32_t v; memcpy(&v, &d[a], 4); return v; }
	void w32(uint64_t a, uint32_t v) { memcpy(&d[a], &v, 4); }
	uint16_t r16(uint64_t a) const { uint16_t v; memcpy(&v, &d[a], 2); return v; }
	void hole(uint64_t a, uint64_t n) { holes.push_back({a, n}); }
	void clear_holes() { holes.clear(); }
};

class SfgSys {
public:
	SfgSys();
	~SfgSys();
	// ---- time ----
	uint64_t cycle = 0;
	uint64_t cycle_budget = 30000000;     // per-test limit; env SFG1_CYCLE_BUDGET overrides
	void tick();                          // advance one clock, dispatch pending interrupts (if enabled)
	bool run_until(const std::function<bool()> &pred, uint64_t max_cycles);
	void idle(uint64_t n) { for (uint64_t i = 0; i < n; i++) tick(); }
	// ---- reset ----
	void hw_reset();                      // asynchronous reset of the whole device (power-on)
	// ---- BAR0 ----
	void csr_write(uint16_t off, uint32_t v);
	uint32_t csr_read(uint16_t off);      // value sampled now; completion waits for earlier posted writes
	// ---- host side ----
	HostMem hm;
	BusCfg cfg;
	std::function<void()> on_irq;         // interrupt-message handler (called from tick(), not from CSR ops)
	bool irq_dispatch = true;
	// ---- fault / stall injection ----
	bool hang_reads = false;              // requests are swallowed (never answered)
	uint64_t hang_lo = 0, hang_hi = 0;    // ...or only requests whose first address is in [lo, hi)
	int  late_reads = 0;                  // answer after this many extra cycles (0 = off)
	bool force_wr_stall = false;          // mwr_ready held low
	bool force_rd_error = false;          // every read request fails on its first beat
	// ---- observation ----
	uint64_t irq_msgs = 0, rd_reqs = 0, rd_beats = 0, wr_acc = 0, wr_faults = 0, rd_faults = 0;
	uint64_t stale_responses_sent = 0;
	uint16_t chk_mask(); uint16_t chk_cnt();
	std::vector<std::string> log;         // protocol-monitor failures (C++ side)
	size_t posted_pending() const { return posted.size(); }
	// ---- device parameters read from the build ----
	int max_ctx = 0, win_bytes = 0;
	// per-cycle monitor hook (tests may add checks)
	std::function<void(SfgSys &)> monitor;
	// event trace (demo): kind is "CSRW" "CSRR" "MRD" (a=addr, b=beats) "MWR" (a=addr, b=data) "MSI"; null = off
	std::function<void(const char *kind, uint64_t a, uint64_t b)> trace;
	Vsfg1_sim_top *top;

private:
	struct Beat { uint64_t due; uint32_t data; bool err; uint8_t tag; };
	struct Posted { uint64_t due; bool msg; uint64_t addr; uint32_t data; };
	std::deque<Beat> beats;
	std::deque<Posted> posted;
	uint64_t last_beat_due = 0, last_post_due = 0;
	uint64_t rng;
	int irq_pending = 0;
	bool in_csr = false;
	uint32_t rnd();
	int rr(int lo, int hi);
	void eval_edge(bool csr_wr, uint16_t addr, uint32_t wdata);
	void deliver_posted();
};
#endif
