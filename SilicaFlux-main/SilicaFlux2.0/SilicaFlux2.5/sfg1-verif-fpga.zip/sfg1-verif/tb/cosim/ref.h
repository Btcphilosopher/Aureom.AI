// SPDX-License-Identifier: GPL-2.0-only
// Reference device = golden model + its own copy of host memory, advanced in lock step with the DUT.
#ifndef REF_H
#define REF_H
#include "hostq.h"
struct Ref {
	std::vector<uint8_t> mem; sfg1m_dev dev; HostMem mhm; sfg1m_host host;
	Ref(int max_ctx, int win_bytes) : mem((size_t)max_ctx * win_bytes, 0), mhm(4 << 20)
	{
		dev.max_ctx = max_ctx; dev.win_bytes = win_bytes; dev.mem = mem.data();
		host.user = this;
		host.read = [](void *u, uint64_t a, void *b, uint64_t n) { auto *r = (Ref *)u; if (!r->mhm.valid(a, n)) return 1; memcpy(b, &r->mhm.d[a], n); return 0; };
		host.write = [](void *u, uint64_t a, const void *b, uint64_t n) { auto *r = (Ref *)u; if (!r->mhm.valid(a, n)) return 1; memcpy(&r->mhm.d[a], b, n); return 0; };
	}
	void sync_host(const HostMem &h) { mhm.d = h.d; mhm.holes = h.holes; mhm.brk = h.brk; }
	uint8_t exec(const sfg1m_sqe &e) { return sfg1m_exec(&dev, &e, &host); }
	uint8_t *win(int ctx) { return mem.data() + (size_t)ctx * dev.win_bytes; }
};
static inline bool same_bytes(const HostMem &a, const HostMem &b, uint64_t addr, uint64_t n) { return memcmp(&a.d[addr], &b.d[addr], n) == 0; }
#endif
