// SPDX-License-Identifier: GPL-2.0-only
// Directed tests: discovery, wraparound, every opcode vs the golden model, invalid commands,
// memory faults, context isolation, queue protocol violations. Each returns true on success;
// individual checks are counted in g_tr.
#include "ref.h"
#include <algorithm>
#include <random>

static uint32_t R32(SfgSys &s, uint16_t r) { return s.csr_read(r); }

// ---------------------------------------------------------------- discovery / CSR
static bool t_csr(SfgSys &s)
{
	CHECK(R32(s, R_ID) == 0x53464001u, "ID %08x", R32(s, R_ID));
	CHECK((R32(s, R_HWVER) >> 16) == 1, "hw major");
	uint32_t caps = R32(s, R_CAPS);
	CHECK((caps & 0x1f) == 0x1f, "caps %x", caps);
	uint32_t l0 = R32(s, R_LIM0), l1 = R32(s, R_LIM1);
	CHECK((l0 & 0xffff) == (uint32_t)s.max_ctx && s.max_ctx >= 1 && s.max_ctx <= 256, "max ctx %u", l0 & 0xffff);
	uint32_t maxq = l0 >> 16;
	CHECK(maxq >= 16 && maxq <= 4096 && (maxq & (maxq - 1)) == 0, "max qent %u", maxq);
	CHECK((l1 & 0xff) >= 32 && (l1 & 0xff) <= 64, "dma bits %u", l1 & 0xff);
	CHECK((l1 >> 16) >= 1, "win kib");
	CHECK(R32(s, R_DEVMEM_LO) >= (uint32_t)s.max_ctx * (l1 >> 16) * 1024u && R32(s, R_DEVMEM_HI) == 0, "devmem");
	uint32_t st = R32(s, R_STATUS);
	CHECK((st & ST_READY) && !(st & (ST_RESET_ACTIVE | ST_FATAL | ST_HALTED | ST_BUSY)), "status after power-up %x", st);
	// register self-test as sfg1_hw_discover() does it
	s.csr_write(R_SCRATCH, 0xa5a5a5a5); CHECK(R32(s, R_SCRATCH) == 0xa5a5a5a5, "scratch a5");
	s.csr_write(R_SCRATCH, 0x5a5a5a5a); CHECK(R32(s, R_SCRATCH) == 0x5a5a5a5a, "scratch 5a");
	// read-only registers ignore writes; unknown registers read as zero
	s.csr_write(R_ID, 0); s.csr_write(R_CAPS, 0); s.csr_write(R_LIM0, 0);
	CHECK(R32(s, R_ID) == 0x53464001u && R32(s, R_CAPS) == caps && R32(s, R_LIM0) == l0, "RO regs writable");
	CHECK(R32(s, 0x080) == 0 && R32(s, 0x0fc) == 0 && R32(s, 0x200) == 0 && R32(s, 0xffc) == 0, "reserved reads");
	CHECK(R32(s, X_PERF_VER) == 1, "perf block version");
	// heartbeat runs only while enabled
	uint32_t h0 = R32(s, R_HEARTBEAT); s.idle(20); CHECK(R32(s, R_HEARTBEAT) == h0, "heartbeat runs while disabled");
	HostQ q(s); q.setup(16);
	h0 = R32(s, R_HEARTBEAT); s.idle(20); CHECK(R32(s, R_HEARTBEAT) > h0, "heartbeat stalled while enabled");
	// queue registers are frozen while ENABLE=1 (R9)
	uint32_t b0 = R32(s, R_SQ_BASE_LO); s.csr_write(R_SQ_BASE_LO, 0x1234560); s.csr_write(R_SQ_ENTRIES, 32);
	CHECK(R32(s, R_SQ_BASE_LO) == b0 && R32(s, R_SQ_ENTRIES) == 16, "queue regs writable while enabled");
	// doorbell is masked to the queue
	s.csr_write(R_SQ_TAIL, 0xfff3); CHECK(R32(s, R_SQ_TAIL) == (0xfff3u & 15), "tail not masked: %x", R32(s, R_SQ_TAIL));
	return g_tr->fails == 0;
}

// invalid queue configurations raise FATAL and do not enable (R9); function reset recovers
static bool t_cfg_fatal(SfgSys &s)
{
	struct Cfg { uint32_t sq, cq; const char *why; } cfgs[] = {
		{17, 32, "sq not power of two"}, {16, 8, "cq < sq"}, {8, 16, "sq < 16"}, {16, 48, "cq not power of two"},
		{16, 8192, "cq > max"}, {0, 0, "unset"}, {8192, 8192, "sq > max"},
	};
	for (auto &c : cfgs) {
		s.csr_write(R_RESET, RESET_MAGIC); wait_ready(s);
		uint64_t sqm = s.hm.alloc(4096, 4096), cqm = s.hm.alloc(4096, 4096);
		s.csr_write(R_SQ_BASE_LO, (uint32_t)sqm); s.csr_write(R_SQ_ENTRIES, c.sq);
		s.csr_write(R_CQ_BASE_LO, (uint32_t)cqm); s.csr_write(R_CQ_ENTRIES, c.cq);
		s.csr_write(R_IRQ_MASK, 7);
		s.csr_write(R_CTRL, CTRL_ENABLE);
		s.idle(4);
		uint32_t st = R32(s, R_STATUS);
		CHECK(st & ST_FATAL, "%s: FATAL not set (status %x)", c.why, st);
		CHECK(R32(s, R_CTRL) == 0, "%s: device enabled despite bad config", c.why);
		CHECK(R32(s, R_IRQ_STATUS) & IRQ_FATAL, "%s: no FATAL cause", c.why);
		s.csr_write(R_SQ_TAIL, 1); s.idle(20);
		CHECK(R32(s, R_SQ_HEAD) == 0 && R32(s, R_DONE) == 0, "%s: executed work while FATAL", c.why);
		// ENGINE_RESET must NOT clear FATAL (it is only cleared by a function reset)
		s.csr_write(R_CTRL, CTRL_ENGINE_RESET); wait_ready(s);
		CHECK(R32(s, R_STATUS) & ST_FATAL, "%s: ENGINE_RESET cleared FATAL", c.why);
	}
	s.csr_write(R_RESET, RESET_MAGIC); wait_ready(s);
	CHECK(!(R32(s, R_STATUS) & ST_FATAL), "function reset did not clear FATAL");
	CHECK(R32(s, R_SQ_ENTRIES) == 0 && R32(s, R_CQ_BASE_LO) == 0 && R32(s, R_IRQ_MASK) == 0, "function reset kept config");
	// a wrong reset magic is ignored
	s.csr_write(R_SCRATCH, 0x77); s.csr_write(R_RESET, RESET_MAGIC ^ 1); s.idle(10);
	CHECK(R32(s, R_SCRATCH) == 0x77 && (R32(s, R_STATUS) & ST_READY), "bad magic acted as reset");
	HostQ q(s); q.setup(16);
	auto r = q.run({sqe_nop()}); CHECK(r.size() == 1 && r[0].status == 0, "device unusable after recovery");
	return g_tr->fails == 0;
}

// queue-configuration hazards found by formal verification of the front-end (docs/03 findings F1-F3):
//  F1 ENABLE cleared mid-fetch, then the queue registers reprogrammed: the in-flight command must keep the geometry sampled at ENABLE 0->1 (R9)
//  F2 a queue base not aligned to its entry size, or a queue that would wrap the 64-bit address space, is an invalid configuration (I9)
//  F3 ENABLE 0->1 while the previous command is still draining is ignored (I10)
static bool t_cfg_race(SfgSys &s)
{
	s.csr_write(R_RESET, RESET_MAGIC); wait_ready(s);
	struct Bad { uint64_t sq, cq; const char *why; } bad[] = {
		{0x2004, 0x4000, "SQ base not 64-byte aligned"}, {0x2020, 0x4000, "SQ base only 32-byte aligned"}, {0x2000, 0x4008, "CQ base not 16-byte aligned"},
		{0xffffffffffffffc0ull, 0x4000, "SQ would wrap the address space"}, {0x2000, 0xfffffffffffffff0ull, "CQ would wrap the address space"},
	};
	for (auto &b : bad) {
		s.csr_write(R_RESET, RESET_MAGIC); wait_ready(s);
		s.csr_write(R_SQ_BASE_LO, (uint32_t)b.sq); s.csr_write(R_SQ_BASE_HI, (uint32_t)(b.sq >> 32)); s.csr_write(R_SQ_ENTRIES, 16);
		s.csr_write(R_CQ_BASE_LO, (uint32_t)b.cq); s.csr_write(R_CQ_BASE_HI, (uint32_t)(b.cq >> 32)); s.csr_write(R_CQ_ENTRIES, 16);
		s.csr_write(R_CTRL, CTRL_ENABLE); s.idle(4);
		CHECK(R32(s, R_STATUS) & ST_FATAL, "%s: FATAL not set", b.why);
		CHECK(R32(s, R_CTRL) == 0, "%s: device enabled", b.why);
	}
	s.csr_write(R_RESET, RESET_MAGIC); wait_ready(s);
	const int lat0 = s.cfg.rd_lat_min, lat1 = s.cfg.rd_lat_max;
	s.cfg.rd_lat_min = s.cfg.rd_lat_max = 60;                       // slow host port: the SQ fetch stays outstanding for a while
	HostQ q(s); q.setup(16);
	const uint32_t done0 = R32(s, R_DONE);
	q.push(sqe_nop()); q.doorbell();
	s.idle(10);
	CHECK(R32(s, R_STATUS) & ST_BUSY, "no command in flight (status %x)", R32(s, R_STATUS));
	s.csr_write(R_CTRL, 0);                                         // disable mid-command ...
	uint64_t sq2 = s.hm.alloc(64 * 64, 4096), cq2 = s.hm.alloc(64 * 16, 4096);
	s.csr_write(R_SQ_BASE_LO, (uint32_t)sq2); s.csr_write(R_SQ_BASE_HI, (uint32_t)(sq2 >> 32)); s.csr_write(R_SQ_ENTRIES, 64);   // ... and reprogram (F1)
	s.csr_write(R_CQ_BASE_LO, (uint32_t)cq2); s.csr_write(R_CQ_BASE_HI, (uint32_t)(cq2 >> 32)); s.csr_write(R_CQ_ENTRIES, 64);
	s.csr_write(R_CTRL, CTRL_ENABLE);                               // F3: still draining -> ignored
	CHECK(R32(s, R_CTRL) == 0, "ENABLE accepted while a command was draining");
	CHECK(R32(s, R_SQ_ENTRIES) == 64 && R32(s, R_CQ_ENTRIES) == 64, "queue register read-back");
	wait_idle(s);
	CHECK(s.chk_mask() == 0, "protocol checker fired: mask %04x", s.chk_mask());
	auto r = q.reap();                                              // the in-flight command completed against the SAMPLED (old) queues
	CHECK(r.size() == 1 && r[0].status == 0, "in-flight command lost or failed (%zu cqes)", r.size());
	CHECK(R32(s, R_DONE) - done0 == 1, "done_count delta %u", R32(s, R_DONE) - done0);
	CHECK(!(R32(s, R_STATUS) & ST_FATAL), "FATAL after a legal disable/reprogram sequence");
	s.cfg.rd_lat_min = lat0; s.cfg.rd_lat_max = lat1;
	HostQ q2(s); q2.setup(64);                                      // legal re-enable on the new geometry
	auto r2 = q2.run({sqe_nop(), sqe_nop()});
	CHECK(r2.size() == 2 && r2[0].status == 0 && r2[1].status == 0, "device unusable after reprogramming");
	CHECK(s.chk_mask() == 0, "protocol checker fired: mask %04x", s.chk_mask());
	return g_tr->fails == 0;
}

// ---------------------------------------------------------------- queue wraparound
static bool t_ring_wrap(SfgSys &s)
{
	struct Q { uint32_t sq, cq; } qs[] = {{16, 16}, {16, 64}, {32, 32}, {64, 64}};
	for (auto &c : qs) {
		HostQ q(s); q.setup(c.sq, c.cq);
		const uint32_t done0 = R32(s, R_DONE);      // DONE_COUNT survives ENABLE toggles (only a function reset clears it)
		uint32_t total = 3 * c.cq + c.sq / 2 + 7, sent = 0, seen = 0, expect_cid = 0;
		std::mt19937 rng(c.sq * 131 + c.cq);
		while (seen < total) {
			uint32_t burst = 1 + rng() % (c.sq - 1);
			uint32_t n = 0;
			while (n < burst && sent < total && q.free_slots() > 0) { q.push(sqe_nop((uint16_t)(sent % s.max_ctx))); sent++; n++; }
			if (n) q.doorbell();
			s.idle(1 + rng() % 5);
			for (auto &e : q.reap()) {
				CHECK(e.status == 0, "wrap sq=%u cq=%u cqe %u status %u", c.sq, c.cq, seen, e.status);
				CHECK(e.cid == (expect_cid % c.sq), "cid %u want %u", e.cid, expect_cid % c.sq);
				CHECK(e.sq_head == ((expect_cid + 1) % c.sq), "sq_head %u want %u", e.sq_head, (expect_cid + 1) % c.sq);
				CHECK(e.ctx == (expect_cid % s.max_ctx), "ctx echo");
				expect_cid++; seen++;
			}
		}
		s.idle(20);
		CHECK(R32(s, R_DONE) - done0 == total, "done_count delta %u want %u", R32(s, R_DONE) - done0, total);
		CHECK(R32(s, R_SQ_HEAD) == (total % c.sq) && R32(s, R_CQ_TAIL) == (total % c.cq), "head/tail regs %u/%u", R32(s, R_SQ_HEAD), R32(s, R_CQ_TAIL));
		CHECK(q.reap().empty(), "spurious CQE after drain");
		// stale CQEs of the previous lap must not be re-delivered: phase of next slot must be old
		CHECK(!(R32(s, R_STATUS) & (ST_BUSY | ST_HALTED | ST_FATAL)), "status after wrap run");
	}
	return g_tr->fails == 0;
}

// ---------------------------------------------------------------- every opcode vs the golden model
struct Bufs { uint64_t in, out; };
static void fill(HostMem &h, uint64_t a, size_t n, std::mt19937 &rng) { for (size_t i = 0; i < n; i++) h.d[a + i] = (uint8_t)rng(); }

static bool t_ops(SfgSys &s)
{
	const int W = s.win_bytes;
	std::mt19937 rng(7);
	HostQ q(s); q.setup(32);
	Bufs b{s.hm.alloc(W, 4096), s.hm.alloc(W, 4096)};
	uint64_t big = s.hm.alloc(8 * W, 4096);
	uint64_t perop = s.hm.alloc(16 * W, 4096);             // one distinct result slot per operation: EVERY result is compared
	Ref ref(s.max_ctx, W);
	for (int ctx = 0; ctx < s.max_ctx; ctx++) {
		fill(s.hm, b.in, W, rng);
		ref.sync_host(s.hm);
		std::vector<sfg1m_sqe> cmds;
		const uint64_t A = 0, B = W / 4, C = W / 2;                  // three quarter-window regions
		const uint64_t words = 37;                                   // odd length
		cmds.push_back(sqe_scrub(ctx));
		cmds.push_back(sqe_h2d(ctx, b.in, 0, W));                    // whole window incl. last bytes
		for (uint32_t op = 0; op < 8; op++) {
			uint64_t c = C + (op == 3 ? 0 : 0);
			cmds.push_back(sqe_vec(ctx, op, A, op == 3 ? 0 : B, c, words));
			cmds.push_back(sqe_d2h(ctx, perop + (uint64_t)op * W / 2, C, words * 4));   // this op's result, own host slot
			cmds.push_back(sqe_h2d(ctx, b.in, 0, W));                // restore inputs
		}
		cmds.push_back(sqe_vec(ctx, 0, A, B, A, words));             // in-place ADD8 (C == A)
		cmds.push_back(sqe_d2h(ctx, perop + 8 * W / 2, A, words * 4));
		cmds.push_back(sqe_vec(ctx, 1, A, B, B, words));             // in-place SUB8 (C == B)
		cmds.push_back(sqe_d2h(ctx, perop + 9 * W / 2, B, words * 4));
		cmds.push_back(sqe_ten(ctx, A, B, C, 3, false));
		cmds.push_back(sqe_d2h(ctx, perop + 10 * W / 2, C, 3 * 64));
		cmds.push_back(sqe_ten(ctx, A, B, C, 3, true));              // accumulate
		cmds.push_back(sqe_d2h(ctx, perop + 11 * W / 2, C, 3 * 64));
		cmds.push_back(sqe_ten(ctx, A, A, C, 2, true));
		cmds.push_back(sqe_d2h(ctx, perop + 12 * W / 2, C, 2 * 64));
		cmds.push_back(sqe_d2h(ctx, b.out, 0, W));                   // full window back
		cmds.push_back(sqe_scrub(ctx));
		cmds.push_back(sqe_d2h(ctx, big, 0, W));                     // zeros
		std::vector<Cqe> got;
		for (size_t i = 0; i < cmds.size(); i += 24) {                // chunk to the queue size
			std::vector<sfg1m_sqe> chunk(cmds.begin() + i, cmds.begin() + std::min(cmds.size(), i + 24));
			auto g = q.run(chunk); got.insert(got.end(), g.begin(), g.end());
		}
		CHECK(got.size() == cmds.size(), "ctx %d: %zu completions of %zu", ctx, got.size(), cmds.size());
		for (size_t i = 0; i < got.size() && i < cmds.size(); i++) {
			uint8_t want = ref.exec(cmds[i]);
			CHECK(got[i].status == want, "ctx %d cmd %zu (op %u) status %u want %u", ctx, i, cmds[i].opcode, got[i].status, want);
		}
		CHECK(same_bytes(s.hm, ref.mhm, b.out, W), "ctx %d: final window dump differs from the model", ctx);
		for (int slot = 0; slot < 13; slot++)
			CHECK(same_bytes(s.hm, ref.mhm, perop + (uint64_t)slot * W / 2, W / 2), "ctx %d: result of operation slot %d differs from the model", ctx, slot);
		CHECK(same_bytes(s.hm, ref.mhm, big, W), "ctx %d: scrubbed window not zero", ctx);
		bool allz = true; for (int i = 0; i < W; i++) allz &= s.hm.d[big + i] == 0;
		CHECK(allz, "ctx %d: window not zero after SCRUB", ctx);
	}
	return g_tr->fails == 0;
}

// ---------------------------------------------------------------- invalid commands
struct Bad { const char *name; sfg1m_sqe e; uint8_t want; };
static bool t_invalid(SfgSys &s)
{
	const uint64_t W = s.win_bytes;
	HostQ q(s); q.setup(32);
	uint64_t buf = s.hm.alloc(2 * W, 4096);
	Ref ref(s.max_ctx, W);
	std::vector<Bad> t;
	auto add = [&](const char *n, sfg1m_sqe e) { t.push_back({n, e, 0}); };
	add("opcode 4 (reserved)", sqe(4, 0)); add("opcode 7", sqe(7, 0)); add("opcode 0xffff", sqe(0xffff, 0));
	add("ctx == MAX_CTX", sqe_nop((uint16_t)s.max_ctx)); add("ctx 0xffff", sqe_nop(0xffff));
	{ auto e = sqe_nop(); e.rsvd0 = 1; add("rsvd0", e); }
	{ auto e = sqe_nop(); e.rsvd1 = 1ull << 40; add("rsvd1", e); }
	{ auto e = sqe_nop(); e.flags = 1; add("NOP flags", e); }
	{ auto e = sqe_nop(); e.len = 4; add("NOP len", e); }
	{ auto e = sqe_nop(); e.dev_c = 4; add("NOP dev_c", e); }
	{ auto e = sqe_nop(); e.host_addr = buf; add("NOP host", e); }
	{ auto e = sqe_nop(); e.exec_op = 1; add("NOP exec_op", e); }
	{ auto e = sqe_scrub(0); e.len = 4; add("SCRUB len", e); }
	{ auto e = sqe_scrub(0); e.flags = 2; add("SCRUB flags", e); }
	{ auto e = sqe_h2d(0, buf, 0, 64); e.flags = 1; add("H2D flags", e); }
	{ auto e = sqe_h2d(0, buf, 0, 64); e.exec_op = 1; add("H2D exec_op", e); }
	{ auto e = sqe_h2d(0, buf, 0, 64); e.dev_b = 4; add("H2D dev_b", e); }
	{ auto e = sqe_d2h(0, buf, 0, 64); e.dev_c = 4; add("D2H dev_c", e); }
	add("H2D len 0", sqe_h2d(0, buf, 0, 0)); add("H2D len misaligned", sqe_h2d(0, buf, 0, 6));
	add("H2D dev misaligned", sqe_h2d(0, buf, 2, 64)); add("H2D len > window", sqe_h2d(0, buf, 0, W + 4));
	add("H2D a == window", sqe_h2d(0, buf, W, 4)); add("H2D a+len > window", sqe_h2d(0, buf, W - 4, 8));
	add("H2D len 2^63", sqe_h2d(0, buf, 0, 1ull << 63)); add("H2D dev 2^63", sqe_h2d(0, buf, 1ull << 63, 4));
	add("H2D dev ~0", sqe_h2d(0, buf, ~0ull - 3, 4)); add("D2H a+len > window", sqe_d2h(0, buf, W - 8, 16));
	add("D2H len 0", sqe_d2h(0, buf, 0, 0));
	add("H2D host wraps 2^64", sqe_h2d(0, ~0ull - 15, 0, 64)); add("D2H host wraps 2^64", sqe_d2h(0, ~0ull - 15, 0, 64));
	add("VEC exec_op 8", sqe_vec(0, 8, 0, 0, 0, 4)); add("VEC exec_op 0x80000000", sqe_vec(0, 0x80000000u, 0, 0, 0, 4));
	{ auto e = sqe_vec(0, 0, 0, 0, 0, 4); e.flags = 1; add("VEC flags", e); }
	{ auto e = sqe_vec(0, 0, 0, 0, 0, 4); e.host_addr = buf; add("VEC host", e); }
	add("VEC len 0", sqe_vec(0, 0, 0, 16, 32, 0)); add("VEC a misaligned", sqe_vec(0, 0, 2, 16, 32, 4));
	add("VEC b misaligned", sqe_vec(0, 0, 0, 18, 32, 4)); add("VEC c misaligned", sqe_vec(0, 0, 0, 16, 34, 4));
	add("VEC a OOB", sqe_vec(0, 0, W - 8, 0, 64, 4)); add("VEC b OOB", sqe_vec(0, 0, 0, W - 8, 64, 4));
	add("VEC c OOB", sqe_vec(0, 0, 0, 64, W - 8, 4)); add("VEC DOT c needs 4 bytes", sqe_vec(0, 7, 0, 64, W, 4));
	add("VEC len*4 overflows", sqe_vec(0, 0, 0, 0, 0, 1ull << 62)); add("VEC len huge", sqe_vec(0, 0, 0, 0, 0, 1ull << 40));
	add("VEC RELU b != 0", sqe_vec(0, 3, 0, 16, 32, 4)); add("VEC RELU b misaligned", sqe_vec(0, 3, 0, 2, 32, 4));
	add("VEC RELU len 2^62 (overflow wins)", sqe_vec(0, 3, 0, 16, 32, 1ull << 62));
	{ auto e = sqe_ten(0, 0, 16, 32, 1, false); e.flags = 2; add("TEN flags bit1", e); }
	{ auto e = sqe_ten(0, 0, 16, 32, 1, false); e.exec_op = 1; add("TEN exec_op", e); }
	{ auto e = sqe_ten(0, 0, 16, 32, 1, false); e.host_addr = 8; add("TEN host", e); }
	add("TEN len 0", sqe_ten(0, 0, 16, 32, 0, false)); add("TEN a misaligned", sqe_ten(0, 1, 16, 32, 1, false));
	add("TEN a OOB", sqe_ten(0, W - 8, 16, 128, 1, false)); add("TEN c OOB (needs 64B)", sqe_ten(0, 0, 16, W - 32, 1, false));
	add("TEN len*16 overflows", sqe_ten(0, 0, 0, 0, 1ull << 60, false)); add("TEN len*64 overflows", sqe_ten(0, 0, 0, 0, 1ull << 58, true));
	add("TEN tiles beyond window", sqe_ten(0, 0, 0, 0, W / 16 + 1, false));
	for (auto &x : t) x.want = ref.exec(x.e);
	for (auto &x : t) CHECK(x.want != 0, "bad test table: %s is valid in the model", x.name);

	// preload recognisable device state so side effects would be visible
	std::mt19937 rng(3); fill(s.hm, buf, W, rng);
	{ auto r = q.run({sqe_h2d(0, buf, 0, W), sqe_h2d(1 % s.max_ctx, buf + 0, 0, W)}); CHECK(r.size() == 2 && r[0].status == 0, "preload"); }
	uint64_t snap = s.hm.alloc(W, 4096), snap2 = s.hm.alloc(W, 4096);
	{ auto r = q.run({sqe_d2h(0, snap, 0, W)}); CHECK(r.size() == 1, "snapshot"); }

	uint32_t errs = R32(s, R_ERR);
	for (auto &x : t) {
		HostQ &Q = q;
		Q.push(x.e); Q.push(sqe_nop());                                  // a second command queued BEHIND the bad one
		Q.doorbell();
		bool got = s.run_until([&] { return (R32(s, R_STATUS) & ST_HALTED) != 0; }, 20000);
		CHECK(got, "%s: never halted", x.name);
		auto r = Q.reap();
		CHECK(r.size() == 1, "%s: %zu completions before halt (want 1)", x.name, r.size());
		if (r.size() >= 1) {
			CHECK(r[0].status == x.want, "%s: status %u want %u", x.name, r[0].status, x.want);
			CHECK(r[0].cid == (uint16_t)((Q.tail + Q.n_sq - 2) % Q.n_sq), "%s: cid echo %u", x.name, r[0].cid);
		}
		uint32_t st = R32(s, R_STATUS);
		CHECK((st & ST_HALTED) && ((st >> 8) & 0xff) == x.want, "%s: HALTED/LAST_ERR %x want err %u", x.name, st, x.want);
		CHECK(R32(s, R_IRQ_STATUS) & IRQ_ERR, "%s: IRQ_ERROR not raised", x.name);
		CHECK(R32(s, R_ERR) == ++errs, "%s: err_count", x.name);
		s.idle(60);
		CHECK(Q.reap().empty(), "%s: command behind the failing one ran while HALTED (R7)", x.name);
		s.csr_write(R_IRQ_STATUS, 7);
		s.csr_write(R_CTRL, CTRL_ENABLE | CTRL_CLEAR_HALT);               // resume: the queued NOP completes
		bool ok = s.run_until([&] { auto z = Q.reap(); return z.size() == 1 && z[0].status == 0; }, 20000);
		CHECK(ok, "%s: queued NOP did not complete after CLEAR_HALT", x.name);
		CHECK(!(R32(s, R_STATUS) & ST_HALTED), "%s: still halted", x.name);
	}
	// no failing command may have modified device memory
	{ auto r = q.run({sqe_d2h(0, snap2, 0, W)}); CHECK(r.size() == 1 && r[0].status == 0, "final snapshot"); }
	CHECK(same_bytes(s.hm, s.hm, snap, W) && memcmp(&s.hm.d[snap], &s.hm.d[snap2], W) == 0, "device memory changed by rejected commands");
	return g_tr->fails == 0;
}

// ---------------------------------------------------------------- memory faults
static bool t_memfault(SfgSys &s)
{
	const uint64_t W = s.win_bytes;
	HostQ q(s); q.setup(32);
	std::mt19937 rng(11);
	uint64_t good = s.hm.alloc(W, 4096), badreg = s.hm.alloc(W, 4096), out = s.hm.alloc(W, 4096);
	fill(s.hm, good, W, rng);
	auto resume = [&] { s.csr_write(R_IRQ_STATUS, 7); s.csr_write(R_CTRL, CTRL_ENABLE | CTRL_CLEAR_HALT); };
	auto one = [&](sfg1m_sqe e) { auto r = q.run({e}); return r.empty() ? 99 : r[0].status; };
	CHECK(one(sqe_h2d(0, good, 0, W)) == 0, "baseline H2D");

	// 1. H2D from an unmapped host region
	s.hm.hole(badreg, W);
	CHECK(one(sqe_h2d(0, badreg, 0, 64)) == SFG1M_ST_DMA_ERROR, "H2D from unmapped host memory must be DMA_ERROR");
	CHECK(R32(s, R_STATUS) & ST_HALTED, "no halt after DMA error"); resume();
	// 2. H2D that starts mapped and runs into a hole mid-burst
	CHECK(one(sqe_h2d(0, badreg - 32, 0, 128)) == SFG1M_ST_DMA_ERROR, "H2D straddling a hole"); resume();
	// 3. D2H into an unmapped region: error, and nothing lands in the hole
	std::vector<uint8_t> before(s.hm.d.begin() + badreg, s.hm.d.begin() + badreg + W);
	CHECK(one(sqe_d2h(0, badreg, 0, 64)) == SFG1M_ST_DMA_ERROR, "D2H to unmapped host memory must be DMA_ERROR");
	CHECK(memcmp(before.data(), &s.hm.d[badreg], W) == 0, "write reached the unmapped region"); resume();
	// 4. 64-bit wraparound of the host range is a fault without any bus access
	uint64_t r0 = s.rd_reqs; CHECK(one(sqe_nop()) == 0, "nop"); const uint64_t fetch_reads = s.rd_reqs - r0;   // SQ-fetch cost of one command in this variant
	uint64_t rr = s.rd_reqs;
	CHECK(one(sqe_h2d(0, ~0ull - 15, 0, 64)) == SFG1M_ST_DMA_ERROR, "wrapping host range"); resume();
	CHECK(s.rd_reqs - rr == fetch_reads, "wrapping range issued DMA reads (%lu vs %lu fetch-only)", (unsigned long)(s.rd_reqs - rr), (unsigned long)fetch_reads);
	// 5. SQ entry fetch fault -> FETCH_ERROR with cid == slot, queue halts (R7)
	{
		uint32_t slot = q.tail;
		s.hm.hole(q.sq + (uint64_t)slot * 64, 64);
		q.push(sqe_nop()); q.doorbell();
		bool h = s.run_until([&] { return (R32(s, R_STATUS) & ST_HALTED) != 0; }, 20000);
		CHECK(h, "fetch fault: never halted");
		auto r = q.reap();
		CHECK(r.size() == 1 && r[0].status == SFG1M_ST_FETCH_ERROR, "fetch fault status %u", r.empty() ? 99 : r[0].status);
		if (!r.empty()) CHECK(r[0].cid == slot && r[0].sq_head == ((slot + 1) % q.n_sq), "FETCH_ERROR cid/sq_head %u/%u (slot %u)", r[0].cid, r[0].sq_head, slot);
		s.hm.clear_holes(); s.hm.hole(badreg, W); resume();
		CHECK(one(sqe_nop()) == 0, "device not usable after FETCH_ERROR");
	}
	// 6. a burst that crosses a 4 KiB boundary must still transfer correctly
	{
		uint64_t pg = s.hm.alloc(3 * 4096, 4096) + 4096;
		for (int i = 0; i < 2048; i++) s.hm.d[pg - 1024 + i] = (uint8_t)(i * 7 + 1);
		CHECK(one(sqe_h2d(0, pg - 1024, 0, std::min<uint64_t>(2048, W))) == 0, "page-crossing H2D");
		CHECK(one(sqe_d2h(0, out, 0, std::min<uint64_t>(2048, W))) == 0, "readback");
		CHECK(memcmp(&s.hm.d[out], &s.hm.d[pg - 1024], std::min<uint64_t>(2048, W)) == 0, "page-crossing data mismatch");
	}
	CHECK(s.chk_mask() == 0, "protocol checker fired: mask %04x", s.chk_mask());
	return g_tr->fails == 0;
}

// ---------------------------------------------------------------- concurrent contexts / isolation
static bool t_ctx(SfgSys &s)
{
	const uint64_t W = s.win_bytes; const int N = s.max_ctx;
	HostQ q(s); q.setup(64);
	std::mt19937 rng(23);
	std::vector<uint64_t> in(N), out(N);
	Ref ref(N, W);
	for (int c = 0; c < N; c++) { in[c] = s.hm.alloc(W, 4096); out[c] = s.hm.alloc(W, 4096); fill(s.hm, in[c], W, rng); }
	ref.sync_host(s.hm);
	// interleave commands from all contexts in one queue; same offsets in every context
	std::vector<sfg1m_sqe> cmds;
	for (int c = 0; c < N; c++) cmds.push_back(sqe_scrub(c));
	for (int c = 0; c < N; c++) cmds.push_back(sqe_h2d(c, in[c], 0, W));
	for (int round = 0; round < 6; round++)
		for (int c = 0; c < N; c++) {
			cmds.push_back(sqe_vec(c, round % 7, 0, (round % 7) == 3 ? 0 : W / 4, W / 2, 32));   // RELU8 requires dev_b == 0
			if (round & 1) cmds.push_back(sqe_ten(c, 0, W / 4, W / 2 + 256, 2, round & 2));
		}
	for (int c = 0; c < N; c++) cmds.push_back(sqe_d2h(c, out[c], 0, W));
	std::vector<Cqe> got;
	for (size_t i = 0; i < cmds.size(); i += 40) {
		std::vector<sfg1m_sqe> chunk(cmds.begin() + i, cmds.begin() + std::min(cmds.size(), i + 40));
		auto g = q.run(chunk); got.insert(got.end(), g.begin(), g.end());
	}
	CHECK(got.size() == cmds.size(), "got %zu of %zu", got.size(), cmds.size());
	for (size_t i = 0; i < got.size(); i++) { uint8_t w = ref.exec(cmds[i]); CHECK(got[i].status == w, "cmd %zu status %u want %u", i, got[i].status, w); CHECK(got[i].ctx == cmds[i].ctx_id, "ctx echo %zu", i); }
	for (int c = 0; c < N; c++) CHECK(same_bytes(s.hm, ref.mhm, out[c], W), "ctx %d window differs from the model (cross-context interference?)", c);
	// scrubbing one context leaves the others untouched
	uint64_t chk = s.hm.alloc(W, 4096);
	for (int victim = 0; victim < N; victim++) {
		q.run({sqe_scrub(victim)}); ref.exec(sqe_scrub(victim));
		for (int c = 0; c < N; c++) {
			auto r = q.run({sqe_d2h(c, chk, 0, W)}); ref.exec(sqe_d2h(c, chk, 0, W));
			CHECK(r.size() == 1 && memcmp(&s.hm.d[chk], ref.win(c), W) == 0, "after scrub of ctx %d, ctx %d window differs", victim, c);
		}
	}
	// no command may reach another window: offsets at/over the window end are rejected
	for (int c = 0; c < N; c++) {
		for (uint64_t a : {W, W + 4, 2 * W, W - 4 + 8}) {
			auto e = sqe_h2d(c, in[c], a, 8);
			auto r = q.run({e});
			CHECK(!r.empty() && r[0].status == SFG1M_ST_BOUNDS, "ctx %d H2D at %llu: status %u", c, (unsigned long long)a, r.empty() ? 99 : r[0].status);
			s.csr_write(R_CTRL, CTRL_ENABLE | CTRL_CLEAR_HALT); q.reap();
		}
	}
	CHECK(s.chk_mask() == 0, "protocol checker fired: mask %04x", s.chk_mask());
	return g_tr->fails == 0;
}

// ---------------------------------------------------------------- credit violation (R5)
static bool t_cqfull(SfgSys &s)
{
	HostQ q(s); q.setup(16, 16);
	// a conforming host never has more than SQ-1 commands outstanding. Break the rule on purpose:
	// never return CQ credit and keep submitting around the ring.
	for (int i = 0; i < 15; i++) q.push(sqe_nop());
	q.doorbell(); s.run_until([&] { return R32(s, R_DONE) == 15; }, 200000);
	CHECK(R32(s, R_DONE) == 15, "done %u", R32(s, R_DONE));
	// do NOT reap. Submit one more: its CQE would land on top of the unconsumed slot 0.
	uint32_t cqt = R32(s, R_CQ_TAIL);
	q.inflight = 0; q.push(sqe_nop()); q.doorbell(); s.run_until([&] { return (R32(s, R_STATUS) & ST_FATAL) != 0; }, 50000);
	CHECK(R32(s, R_STATUS) & ST_FATAL, "device did not raise FATAL on CQ overflow");
	CHECK(R32(s, R_IRQ_STATUS) & IRQ_FATAL, "no FATAL interrupt cause");
	CHECK(R32(s, R_CQ_TAIL) == cqt, "CQ tail advanced despite overflow");
	// the unconsumed CQE (slot 0) must not have been overwritten
	uint16_t sp = s.hm.r16(q.cq + 14);
	CHECK((sp & 1) == 1 && s.hm.r16(q.cq + 12) == 0, "unconsumed CQE slot 0 was overwritten");
	CHECK(s.chk_mask() == 0, "protocol checker fired: mask %04x", s.chk_mask());
	// FATAL survives an ENGINE reset, needs a function reset
	s.csr_write(R_CTRL, CTRL_ENGINE_RESET); wait_ready(s);
	CHECK(R32(s, R_STATUS) & ST_FATAL, "ENGINE_RESET cleared FATAL");
	s.csr_write(R_RESET, RESET_MAGIC); wait_ready(s);
	CHECK(!(R32(s, R_STATUS) & ST_FATAL), "function reset did not clear FATAL");
	return g_tr->fails == 0;
}

const std::vector<TestEntry> &all_tests_directed()
{
	static const std::vector<TestEntry> v = {
		{"csr", t_csr, "discovery sequence, RO/WO/frozen registers, doorbell masking"},
		{"cfg_fatal", t_cfg_fatal, "invalid queue configurations raise FATAL (R9); only a function reset clears it"},
		{"cfg_race", t_cfg_race, "queue-config hazards from formal: disable-mid-fetch + reprogram, misaligned/wrapping bases, enable-while-busy"},
		{"ring_wrap", t_ring_wrap, "queue wraparound for 4 SQ/CQ geometries, phase toggling, cid/sq_head echo"},
		{"ops", t_ops, "every opcode/VEC op/TEN mode on every context vs the golden model"},
		{"invalid", t_invalid, "~60 invalid commands: status, halt (R7), no side effects, CLEAR_HALT resume"},
		{"memfault", t_memfault, "DMA faults, FETCH_ERROR, host range wrap, 4 KiB page crossing"},
		{"ctx", t_ctx, "interleaved contexts, window isolation, per-context scrub, cross-window rejection"},
		{"cqfull", t_cqfull, "CQ overflow by a non-conforming host -> FATAL, no overwrite (R5)"},
	};
	return v;
}
