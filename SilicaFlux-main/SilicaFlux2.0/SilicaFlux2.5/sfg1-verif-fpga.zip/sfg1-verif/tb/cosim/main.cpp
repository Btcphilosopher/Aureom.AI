// SPDX-License-Identifier: GPL-2.0-only
// Co-simulation test runner: `sim [--list] [--seed N] [name ...]` ; each test gets a fresh DUT.
#include "hostq.h"
#include "verilated.h"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <cstring>

TestResult *g_tr = nullptr;
const std::vector<TestEntry> &all_tests_directed();
const std::vector<TestEntry> &all_tests_stress();
const std::vector<TestEntry> &all_tests_driver();
const std::vector<TestEntry> &all_tests_perf();
const std::vector<TestEntry> &all_tests_demo();
const std::vector<TestEntry> &all_tests()
{
	static std::vector<TestEntry> v;
	if (v.empty()) {
		for (auto &t : all_tests_directed()) v.push_back(t);
		for (auto &t : all_tests_stress()) v.push_back(t);
		for (auto &t : all_tests_driver()) v.push_back(t);
		for (auto &t : all_tests_perf()) v.push_back(t);
	}
	return v;
}

int main(int argc, char **argv)
{
	Verilated::commandArgs(argc, argv);
	std::vector<std::string> want; bool list = false;
	for (int i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "--list")) list = true;
		else if (argv[i][0] != '+' && argv[i][0] != '-') want.push_back(argv[i]);
	}
	if (list) { for (auto &t : all_tests()) printf("%-12s %s\n", t.name, t.desc); for (auto &t : all_tests_demo()) printf("%-12s %s\n", t.name, t.desc); return 0; }
	int failed = 0, ran = 0;
	std::vector<TestEntry> todo = all_tests();
	for (auto &t : all_tests_demo()) if (std::find(want.begin(), want.end(), t.name) != want.end()) todo.push_back(t);   // the demo runs only when named
	for (auto &t : todo) {
		if (!want.empty() && std::find(want.begin(), want.end(), t.name) == want.end()) continue;
		TestResult tr; tr.name = t.name; g_tr = &tr;
		SfgSys *s = new SfgSys();
		auto t0 = std::chrono::steady_clock::now();
		bool ok = false;
		try { ok = t.fn(*s); }
		catch (TestTimeout &) { tr.fails++; tr.msgs.push_back("cycle budget exceeded: the device or the test hung"); }
		uint16_t m = s->chk_mask();
		if (m) { tr.fails++; tr.msgs.push_back("protocol checker mask " + std::to_string(m)); }
		tr.cycles = s->cycle;
		double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
		bool pass = ok && tr.fails == 0;
		printf("TEST %-12s %s checks=%ld fails=%ld cycles=%llu (%.1fs) checker_mask=%04x\n", t.name, pass ? "PASS" : "FAIL",
		       tr.checks, tr.fails, (unsigned long long)tr.cycles, sec, m);
		if (!pass) { failed++; for (auto &m2 : tr.msgs) printf("    %s\n", m2.c_str()); }
		ran++;
		delete s;
	}
	printf("SUMMARY ran=%d failed=%d\n", ran, failed);
	return failed ? 1 : 0;
}
