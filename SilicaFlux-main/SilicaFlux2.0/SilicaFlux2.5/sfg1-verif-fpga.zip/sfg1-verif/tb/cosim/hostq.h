// SPDX-License-Identifier: GPL-2.0-only
// Host-side queue driver model + test helpers. Mirrors vendor/sfg1-driver/kernel/sfg1_ring.c:
// entries are plain stores, the doorbell publishes them (R1), completions are detected by the
// phase tag before the payload is read (R4), credit is returned through CQ_HEAD (R5), and
// interrupts are handled acknowledge-then-drain (R6).
#ifndef HOSTQ_H
#define HOSTQ_H
#include "sfg1sys.h"
#include "sfg1_model.h"
#include <cstdio>
#include <string>

// ---- register offsets (contract section 3) ----
enum : uint16_t {
	R_ID = 0x000, R_HWVER = 0x004, R_CAPS = 0x008, R_LIM0 = 0x00c, R_LIM1 = 0x010, R_DEVMEM_LO = 0x014,
	R_DEVMEM_HI = 0x018, R_CTRL = 0x020, R_STATUS = 0x024, R_RESET = 0x028, R_IRQ_STATUS = 0x030,
	R_IRQ_MASK = 0x034, R_SQ_BASE_LO = 0x040, R_SQ_BASE_HI = 0x044, R_SQ_ENTRIES = 0x048, R_SQ_TAIL = 0x04c,
	R_CQ_BASE_LO = 0x050, R_CQ_BASE_HI = 0x054, R_CQ_ENTRIES = 0x058, R_CQ_HEAD = 0x05c, R_SQ_HEAD = 0x060,
	R_CQ_TAIL = 0x064, R_DONE = 0x068, R_ERR = 0x06c, R_HEARTBEAT = 0x070, R_SCRATCH = 0x07c,
	X_PERF_CTRL = 0x100, X_PERF_CYCLES = 0x104, X_PERF_BUSY = 0x108, X_PERF_CMDS = 0x10c, X_PERF_FETCH = 0x110,
	X_PERF_DECODE = 0x114, X_PERF_EXEC = 0x118, X_PERF_WB = 0x11c, X_PERF_H2D = 0x120, X_PERF_D2H = 0x124,
	X_PERF_VEC = 0x128, X_PERF_TEN = 0x12c, X_PERF_SCRUB = 0x130, X_PERF_RDB = 0x134, X_PERF_WRB = 0x138,
	X_PERF_RDS = 0x13c, X_PERF_WRS = 0x140, X_PERF_VER = 0x144,
};
enum { CTRL_ENABLE = 1, CTRL_ENGINE_RESET = 2, CTRL_CLEAR_HALT = 4 };
enum { ST_READY = 1, ST_BUSY = 2, ST_HALTED = 4, ST_FATAL = 8, ST_RESET_ACTIVE = 16 };
enum { IRQ_CQ = 1, IRQ_ERR = 2, IRQ_FATAL = 4 };
static const uint32_t RESET_MAGIC = 0x52455345u;

struct Cqe { uint32_t result; uint16_t sq_head, ctx, cid, status, phase; };

// ---- test bookkeeping ----
struct TestResult {
	std::string name; long checks = 0, fails = 0; uint64_t cycles = 0;
	std::vector<std::string> msgs;
};
extern TestResult *g_tr;
#define CHECK(cond, ...) do { g_tr->checks++; if (!(cond)) { g_tr->fails++; \
	char _b[512]; snprintf(_b, sizeof(_b), __VA_ARGS__); \
	if (g_tr->msgs.size() < 12) g_tr->msgs.push_back(std::string(__FILE__ ":") + std::to_string(__LINE__) + ": " + _b); } } while (0)

static inline sfg1m_sqe sqe(uint16_t op, uint16_t ctx) { sfg1m_sqe e; memset(&e, 0, sizeof(e)); e.opcode = op; e.ctx_id = ctx; return e; }
static inline sfg1m_sqe sqe_nop(uint16_t ctx = 0) { return sqe(SFG1M_OP_NOP, ctx); }
static inline sfg1m_sqe sqe_h2d(uint16_t ctx, uint64_t host, uint64_t dev, uint64_t len) { auto e = sqe(SFG1M_OP_DMA_H2D, ctx); e.host_addr = host; e.dev_a = dev; e.len = len; return e; }
static inline sfg1m_sqe sqe_d2h(uint16_t ctx, uint64_t host, uint64_t dev, uint64_t len) { auto e = sqe(SFG1M_OP_DMA_D2H, ctx); e.host_addr = host; e.dev_a = dev; e.len = len; return e; }
static inline sfg1m_sqe sqe_vec(uint16_t ctx, uint32_t op, uint64_t a, uint64_t b, uint64_t c, uint64_t words) { auto e = sqe(SFG1M_OP_VEC, ctx); e.exec_op = op; e.dev_a = a; e.dev_b = b; e.dev_c = c; e.len = words; return e; }
static inline sfg1m_sqe sqe_ten(uint16_t ctx, uint64_t a, uint64_t b, uint64_t c, uint64_t tiles, bool acc) { auto e = sqe(SFG1M_OP_TEN, ctx); e.dev_a = a; e.dev_b = b; e.dev_c = c; e.len = tiles; e.flags = acc; return e; }
static inline sfg1m_sqe sqe_scrub(uint16_t ctx) { return sqe(SFG1M_OP_SCRUB, ctx); }

class HostQ {
public:
	SfgSys &s;
	uint64_t sq = 0, cq = 0;
	uint32_t n_sq = 0, n_cq = 0, tail = 0, cq_head = 0, inflight = 0;
	int phase = 1;
	uint64_t irq_handled = 0, cqes_reaped = 0;
	explicit HostQ(SfgSys &sys) : s(sys) {}

	// Program the queues and enable the device (contract section 2, steps 8; rule R9).
	void setup(uint32_t entries, uint32_t cq_entries = 0, uint32_t irq_mask = 7, bool fresh_memory = true)
	{
		if (!cq_entries) cq_entries = entries;
		n_sq = entries; n_cq = cq_entries;
		if (fresh_memory || !sq) {            // one queue pair per geometry: the device has a single queue pair
			sq = s.hm.alloc_named("sq" + std::to_string(entries), (uint64_t)entries * 64, 4096);
			cq = s.hm.alloc_named("cq" + std::to_string(cq_entries), (uint64_t)cq_entries * 16, 4096);
		}
		memset(&s.hm.d[sq], 0, (size_t)entries * 64); memset(&s.hm.d[cq], 0, (size_t)cq_entries * 16);
		tail = 0; cq_head = 0; phase = 1; inflight = 0;
		s.csr_write(R_CTRL, 0);
		s.csr_write(R_SQ_BASE_LO, (uint32_t)sq); s.csr_write(R_SQ_BASE_HI, (uint32_t)(sq >> 32)); s.csr_write(R_SQ_ENTRIES, entries);
		s.csr_write(R_CQ_BASE_LO, (uint32_t)cq); s.csr_write(R_CQ_BASE_HI, (uint32_t)(cq >> 32)); s.csr_write(R_CQ_ENTRIES, cq_entries);
		s.csr_write(R_IRQ_STATUS, 7); s.csr_write(R_IRQ_MASK, irq_mask);
		s.csr_write(R_CTRL, CTRL_ENABLE);
	}
	uint32_t free_slots() const { return n_sq - 1 - inflight; }
	void push(sfg1m_sqe e)
	{
		e.cid = (uint16_t)tail;                               // driver convention: cid == slot
		memcpy(&s.hm.d[sq + (uint64_t)tail * 64], &e, 64);
		tail = (tail + 1) % n_sq; inflight++;
	}
	void doorbell() { s.csr_write(R_SQ_TAIL, tail); }           // dma_wmb() is implicit: stores are already visible
	// Drain the CQ: phase first (R4), then payload; return credit once (R5).
	std::vector<Cqe> reap()
	{
		std::vector<Cqe> out;
		for (;;) {
			uint64_t a = cq + (uint64_t)cq_head * 16;
			uint16_t sp = s.hm.r16(a + 14);
			if ((int)(sp & 1) != phase) break;
			Cqe c; c.result = s.hm.r32(a); c.sq_head = s.hm.r16(a + 8); c.ctx = s.hm.r16(a + 10);
			c.cid = s.hm.r16(a + 12); c.status = sp >> 1; c.phase = sp & 1;
			out.push_back(c);
			cq_head = (cq_head + 1) % n_cq; if (!cq_head) phase ^= 1;
			if (inflight) inflight--;
		}
		cqes_reaped += out.size();
		if (!out.empty()) s.csr_write(R_CQ_HEAD, cq_head);
		return out;
	}
	// Interrupt handler: read IRQ_STATUS, W1C exactly the bits read, then drain (R6).
	std::vector<Cqe> irq_ack_drain(uint32_t *causes = nullptr)
	{
		uint32_t st = s.csr_read(R_IRQ_STATUS);
		if (st) s.csr_write(R_IRQ_STATUS, st);
		if (causes) *causes = st;
		irq_handled++;
		return reap();
	}
	// Submit commands and wait for all completions (or a halt). Returns completions in order.
	std::vector<Cqe> run(const std::vector<sfg1m_sqe> &cmds, uint64_t max_cycles = 2000000, bool *timed_out = nullptr)
	{
		std::vector<Cqe> got; size_t sent = 0; uint64_t start = s.cycle; bool to = false;
		while (got.size() < cmds.size()) {
			bool pushed = false;
			while (sent < cmds.size() && free_slots() > 0) { push(cmds[sent++]); pushed = true; }
			if (pushed) doorbell();
			s.tick();
			auto r = reap(); got.insert(got.end(), r.begin(), r.end());
			if (!r.empty() && r.back().status != 0) break;                   // halted on error: caller decides
			if (s.cycle - start > max_cycles) { to = true; break; }
		}
		if (timed_out) *timed_out = to;
		return got;
	}
};

// ---- device-side helpers shared by tests ----
static inline void wait_idle(SfgSys &s, uint64_t max = 200000)
{
	s.run_until([&] { return !(s.csr_read(R_STATUS) & ST_BUSY); }, max);
}
static inline bool wait_ready(SfgSys &s, uint64_t max = 1000)
{
	return s.run_until([&] { return (s.csr_read(R_STATUS) & (ST_READY | ST_RESET_ACTIVE)) == ST_READY; }, max);
}

typedef bool (*TestFn)(SfgSys &);
struct TestEntry { const char *name; TestFn fn; const char *desc; };
const std::vector<TestEntry> &all_tests();
#endif
