// SPDX-License-Identifier: GPL-2.0-only
// Stress / robustness tests: bus stalls, interrupts, resets, timeouts and recovery, and the random
// ISA differential test against the golden model.
#include "ref.h"
#include <algorithm>
#include <cstdlib>
#include <random>

#ifndef SFG1_VEC_MODE
#define SFG1_VEC_MODE 0
#endif
static uint32_t R32(SfgSys &s, uint16_t r) { return s.csr_read(r); }
static void fillr(HostMem &h, uint64_t a, size_t n, std::mt19937 &rng) { for (size_t i = 0; i < n; i++) h.d[a + i] = (uint8_t)rng(); }
static uint64_t fnv(const uint8_t *p, size_t n, uint64_t h = 1469598103934665603ull) { for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 1099511628211ull; } return h; }
static void resume(SfgSys &s) { s.csr_write(R_IRQ_STATUS, 7); s.csr_write(R_CTRL, CTRL_ENABLE | CTRL_CLEAR_HALT); }

// Continuous payload-before-phase monitor (rule R3/R4, "M1" of the driver package's testbench):
// whenever a CQE's phase tag is visible in host memory its payload must already be correct.
struct CqeMon {
	HostQ *q = nullptr; uint32_t head = 0, count = 0; int phase = 1; std::vector<uint16_t> ctx_of; long violations = 0;
	void attach(SfgSys &s, HostQ &hq)
	{
		q = &hq; head = 0; count = 0; phase = 1; ctx_of.assign(hq.n_sq, 0);
		s.monitor = [this](SfgSys &sys) { step(sys); };
	}
	void note_push(uint32_t slot, uint16_t ctx) { ctx_of[slot] = ctx; }
	void step(SfgSys &s)
	{
		for (int guard = 0; guard < 4; guard++) {
			uint64_t a = q->cq + (uint64_t)head * 16;
			uint16_t sp = s.hm.r16(a + 14);
			if ((int)(sp & 1) != phase) return;
			uint32_t cid = count % q->n_sq;
			bool ok = s.hm.r16(a + 12) == cid && s.hm.r16(a + 8) == ((cid + 1) % q->n_sq) && s.hm.r16(a + 10) == ctx_of[cid] &&
				  s.hm.r32(a) == 0 && s.hm.r32(a + 4) == 0;
			if (!ok) { violations++; if (violations < 4) fprintf(stderr, "  CQE monitor: slot %u phase visible but payload wrong (cid %u sq_head %u ctx %u)\n", head, s.hm.r16(a + 12), s.hm.r16(a + 8), s.hm.r16(a + 10)); }
			head = (head + 1) % q->n_cq; count++; if (!head) phase ^= 1;
		}
	}
};

// --------------------------------------------------------------------------------- bus stalls
// One fixed workload, many bus timing configurations. Results (statuses + all data) must be
// identical to the zero-stall run and to the golden model; nothing may hang.
static uint64_t run_workload(SfgSys &s, HostQ &q, CqeMon &mon, Ref &ref, uint64_t in, uint64_t out, int seed, bool *bad)
{
	const uint64_t W = s.win_bytes; std::mt19937 rng(seed); uint64_t h = 0;
	std::vector<sfg1m_sqe> cmds;
	for (int c = 0; c < s.max_ctx; c++) {
		cmds.push_back(sqe_scrub(c)); cmds.push_back(sqe_h2d(c, in + c * 512, 0, 1024 + 8 * c));
		cmds.push_back(sqe_vec(c, SFG1M_VEC_ADD8, 0, 256, 512, 64)); cmds.push_back(sqe_vec(c, SFG1M_VEC_DOT8, 0, 256, 1024, 64));
		cmds.push_back(sqe_ten(c, 0, 256, 1536, 4, false)); cmds.push_back(sqe_ten(c, 0, 256, 1536, 4, true));
		cmds.push_back(sqe_d2h(c, out + c * W, 0, W));
	}
	std::vector<Cqe> got; size_t sent = 0; uint64_t t0 = s.cycle; *bad = false;
	while (got.size() < cmds.size()) {
		bool pushed = false;
		while (sent < cmds.size() && q.free_slots() > 0) { mon.note_push(q.tail, cmds[sent].ctx_id); q.push(cmds[sent++]); pushed = true; }
		if (pushed) q.doorbell();
		s.idle(1 + rng() % 3);
		auto r = q.reap(); got.insert(got.end(), r.begin(), r.end());
		if (s.cycle - t0 > 3000000) { *bad = true; break; }
	}
	for (size_t i = 0; i < got.size(); i++) { uint8_t w = ref.exec(cmds[i]); if (got[i].status != w) *bad = true; h = fnv((const uint8_t *)&got[i].status, 2, h); }
	for (int c = 0; c < s.max_ctx; c++) { if (memcmp(&s.hm.d[out + c * W], ref.win(c), W)) *bad = true; h = fnv(&s.hm.d[out + c * W], W, h); }
	return h;
}

static bool t_stalls(SfgSys &s)
{
	const uint64_t W = s.win_bytes; std::mt19937 rng(5);
	uint64_t in = s.hm.alloc(4096, 4096), out = s.hm.alloc(s.max_ctx * W, 4096);
	fillr(s.hm, in, 4096, rng);
	struct C { const char *n; int lmin, lmax, gap; double stall; } cfgs[] = {
		{"zero-latency", 1, 1, 0, 0}, {"nominal", 4, 4, 0, 0}, {"slow read 40", 40, 40, 0, 0}, {"random lat 1..60", 1, 60, 0, 0},
		{"throttled beats gap 3", 4, 8, 3, 0}, {"write stall 10%", 2, 6, 0, 0.1}, {"write stall 50%", 2, 6, 0, 0.5},
		{"write stall 90%", 2, 6, 0, 0.9}, {"everything slow", 20, 60, 2, 0.7},
	};
	uint64_t base = 0;
	for (size_t i = 0; i < sizeof(cfgs) / sizeof(cfgs[0]); i++) {
		s.csr_write(R_RESET, RESET_MAGIC); wait_ready(s);
		s.cfg.rd_lat_min = cfgs[i].lmin; s.cfg.rd_lat_max = cfgs[i].lmax; s.cfg.beat_gap = cfgs[i].gap; s.cfg.wr_stall_prob = cfgs[i].stall;
		s.cfg.wr_lat_min = 1; s.cfg.wr_lat_max = 1 + (int)i * 3;
		HostQ q(s); q.setup(16); CqeMon mon; mon.attach(s, q);
		Ref ref(s.max_ctx, W); ref.sync_host(s.hm);
		bool bad; uint64_t t0 = s.cycle;
		uint64_t h = run_workload(s, q, mon, ref, in, out, 99, &bad);
		CHECK(!bad, "%s: result differs from the model or timed out", cfgs[i].n);
		CHECK(mon.violations == 0, "%s: payload-before-phase violated %ld times", cfgs[i].n, mon.violations);
		if (i == 0) base = h; else CHECK(h == base, "%s: result digest differs from the zero-latency run", cfgs[i].n);
		if (getenv("SFG1_VERBOSE")) printf("  stalls[%s]: %llu cycles\n", cfgs[i].n, (unsigned long long)(s.cycle - t0));
		s.monitor = nullptr;
	}
	// a long forced write stall in the middle of completion write-back, then release
	{
		s.csr_write(R_RESET, RESET_MAGIC); wait_ready(s); s.cfg = BusCfg();
		HostQ q(s); q.setup(16); CqeMon mon; mon.attach(s, q);
		for (int i = 0; i < 6; i++) { mon.note_push(q.tail, 0); q.push(sqe_nop()); }
		s.force_wr_stall = true; q.doorbell(); s.idle(400);
		uint32_t dn = R32(s, R_DONE);
		CHECK(dn == 0, "completions committed while the posted-write channel was blocked (done=%u)", dn);
		s.force_wr_stall = false;
		s.run_until([&] { return R32(s, R_DONE) == 6; }, 100000);
		auto r = q.reap(); size_t n = r.size(); s.idle(100); auto r2 = q.reap(); n += r2.size();
		CHECK(n == 6, "%zu of 6 completions after releasing the stall", n);
		CHECK(mon.violations == 0, "payload-before-phase violated during stall");
		s.monitor = nullptr;
	}
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	return g_tr->fails == 0;
}

// --------------------------------------------------------------------------------- interrupts
static bool t_irq(SfgSys &s)
{
	HostQ q(s); q.setup(16);
	uint64_t msgs0, handled = 0, total = 0;
	// (a) acknowledge-then-drain handler driven by message delivery, completions racing with the handler
	s.on_irq = [&] { q.irq_ack_drain(); handled++; };
	std::mt19937 rng(41); msgs0 = s.irq_msgs;
	for (int round = 0; round < 60; round++) {
		int n = 1 + rng() % 12;
		for (int i = 0; i < n && q.free_slots() > 0; i++) { q.push(sqe_nop()); total++; }
		q.doorbell();
		s.idle(rng() % 40);
	}
	CHECK(s.run_until([&] { return q.cqes_reaped == total; }, 400000), "lost completion: %llu reaped of %llu (R6 acknowledge-then-drain)", (unsigned long long)q.cqes_reaped, (unsigned long long)total);
	s.idle(200);
	CHECK(s.irq_msgs > msgs0 && handled > 0, "no interrupt messages observed");
	uint64_t quiet0 = s.irq_msgs; s.idle(500);
	CHECK(s.irq_msgs == quiet0, "interrupt storm: %llu messages while idle", (unsigned long long)(s.irq_msgs - quiet0));
	CHECK(R32(s, R_IRQ_STATUS) == 0, "IRQ_STATUS not clean after the handler: %x", R32(s, R_IRQ_STATUS));

	// (b) mask / unmask re-fire (R6)
	s.on_irq = nullptr;
	q.setup(16, 16, /*irq_mask=*/0);
	uint64_t m0 = s.irq_msgs; uint32_t dn0 = R32(s, R_DONE);
	q.push(sqe_nop()); q.doorbell(); s.run_until([&] { return R32(s, R_DONE) >= dn0 + 1; }, 20000); s.idle(50);
	CHECK(R32(s, R_IRQ_STATUS) & IRQ_CQ, "cause not recorded while masked");
	CHECK(s.irq_msgs == m0, "message sent while the cause is masked");
	s.csr_write(R_IRQ_MASK, 7); s.idle(30);
	CHECK(s.irq_msgs == m0 + 1, "no message after unmasking a pending cause (%llu)", (unsigned long long)(s.irq_msgs - m0));
	// a W1C that leaves another cause pending re-sends a message
	{
		s.csr_write(R_IRQ_STATUS, 7); s.idle(20); q.reap();
		auto bad = sqe_nop(); bad.opcode = 9;                                  // -> error: CQ and ERROR causes
		q.push(bad); q.doorbell(); s.run_until([&] { return (R32(s, R_STATUS) & ST_HALTED) != 0; }, 20000); s.idle(30);
		uint32_t st = R32(s, R_IRQ_STATUS);
		CHECK((st & (IRQ_CQ | IRQ_ERR)) == (IRQ_CQ | IRQ_ERR), "causes %x", st);
		uint64_t before = s.irq_msgs;
		s.csr_write(R_IRQ_STATUS, IRQ_CQ); s.idle(30);                         // clears CQ only; ERROR still pending
		CHECK(s.irq_msgs == before + 1, "no re-send after a partial W1C leaves a cause pending (%llu)", (unsigned long long)(s.irq_msgs - before));
		s.csr_write(R_IRQ_STATUS, IRQ_ERR); s.idle(30);
		CHECK(s.irq_msgs == before + 1, "message sent when all causes are clear");
		q.reap(); resume(s);
	}
	// (c) NEGATIVE CONTROL: the reverse order (drain, then acknowledge) loses a wake-up
	{
		q.setup(16); s.irq_dispatch = false; uint64_t mm = s.irq_msgs;
		q.push(sqe_nop()); q.doorbell();
		s.run_until([&] { return s.irq_msgs > mm; }, 50000); s.idle(5);
		uint32_t st = R32(s, R_IRQ_STATUS);                                    // handler reads the cause...
		auto r1 = q.reap();                                                    // ...drains first (WRONG order)
		CHECK(r1.size() == 1, "wrong-order handler: first drain");
		uint32_t d0 = R32(s, R_DONE);
		q.push(sqe_nop()); q.doorbell();                                       // a completion lands before the ack
		s.run_until([&] { return R32(s, R_DONE) >= d0 + 1 && !(R32(s, R_STATUS) & ST_BUSY); }, 50000); s.idle(20);
		uint64_t mid = s.irq_msgs;
		s.csr_write(R_IRQ_STATUS, st);                                         // ...then acknowledges: clears the NEW cause too
		s.idle(300);
		CHECK(s.irq_msgs == mid, "unexpected message after a late ack");
		bool lost = q.reap().size() == 1;                                      // CQE is there but no interrupt will ever announce it
		CHECK(lost, "negative control failed: expected an unannounced completion with drain-then-ack");
		s.irq_dispatch = true;
	}
	// (d) FATAL is signalled by interrupt as well
	{
		s.csr_write(R_RESET, RESET_MAGIC); wait_ready(s);
		uint64_t m1 = s.irq_msgs; s.csr_write(R_IRQ_MASK, 7);
		s.csr_write(R_SQ_ENTRIES, 17); s.csr_write(R_CQ_ENTRIES, 32); s.csr_write(R_CTRL, CTRL_ENABLE); s.idle(30);
		CHECK(s.irq_msgs == m1 + 1 && (R32(s, R_IRQ_STATUS) & IRQ_FATAL), "FATAL interrupt");
	}
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	return g_tr->fails == 0;
}

// --------------------------------------------------------------------------------- resets
static bool t_reset(SfgSys &s)
{
	const uint64_t W = s.win_bytes; std::mt19937 rng(77);
	uint64_t a = s.hm.alloc(W, 4096), b = s.hm.alloc(W, 4096), chk = s.hm.alloc(W, 4096);
	fillr(s.hm, a, W, rng); fillr(s.hm, b, W, rng);
	HostQ q(s); q.setup(16);
	auto verify_device = [&](const char *why) {
		HostQ q2(s); q2.setup(16);
		auto r = q2.run({sqe_scrub(0), sqe_h2d(0, a, 0, 256), sqe_d2h(0, chk, 0, 256)});
		CHECK(r.size() == 3 && r[0].status == 0 && r[1].status == 0 && r[2].status == 0, "%s: device unusable after reset", why);
		CHECK(memcmp(&s.hm.d[chk], &s.hm.d[a], 256) == 0, "%s: data corrupted after reset (stale response?)", why);
	};
	// ---- (a) idle ENGINE_RESET: state classes (contract section 6 table) ----
	{
		auto r = q.run({sqe_nop(), sqe_nop(), sqe_nop()}); CHECK(r.size() == 3, "setup");
		s.csr_write(R_IRQ_MASK, 5);
		uint32_t dn = R32(s, R_DONE), sqb = R32(s, R_SQ_BASE_LO), cqe = R32(s, R_CQ_ENTRIES);
		s.csr_write(R_CTRL, CTRL_ENGINE_RESET);
		CHECK(R32(s, R_STATUS) & ST_RESET_ACTIVE, "RESET_ACTIVE not visible right after the reset write");
		CHECK(!(R32(s, R_STATUS) & ST_READY), "READY while RESET_ACTIVE");
		CHECK(wait_ready(s), "READY never returned");
		CHECK(R32(s, R_CTRL) == 0, "ENABLE not cleared"); CHECK(R32(s, R_SQ_HEAD) == 0 && R32(s, R_CQ_TAIL) == 0 && R32(s, R_SQ_TAIL) == 0 && R32(s, R_CQ_HEAD) == 0, "queue indices not cleared");
		CHECK(R32(s, R_IRQ_STATUS) == 0, "IRQ_STATUS not cleared");
		CHECK(R32(s, R_DONE) == dn && R32(s, R_SQ_BASE_LO) == sqb && R32(s, R_CQ_ENTRIES) == cqe && R32(s, R_IRQ_MASK) == 5, "ENGINE_RESET must retain counters/config/IRQ_MASK");
		// doorbell while disabled is ignored
		s.csr_write(R_SQ_TAIL, 3); CHECK(R32(s, R_SQ_TAIL) == 0, "doorbell accepted while disabled");
	}
	// ---- (b) reset with a command hung on the host bus: no completion, device recovers ----
	{
		q.setup(16); s.hang_reads = true;
		q.push(sqe_h2d(0, a, 0, 128)); q.push(sqe_nop()); q.doorbell();
		s.idle(2000);                                                           // the SQ fetch itself is blackholed
		CHECK(R32(s, R_STATUS) & ST_BUSY, "device not busy while its fetch is hung");
		s.csr_write(R_CTRL, CTRL_ENGINE_RESET); wait_ready(s);
		CHECK(!(R32(s, R_STATUS) & ST_BUSY), "still busy after reset");
		CHECK(q.reap().empty(), "a completion was written for an aborted command");
		s.hang_reads = false; verify_device("hung SQ fetch");
	}
	// ---- (c) hung DMA read: the SQ fetch works, the data read never completes ----
	{
		HostQ q2(s); q2.setup(16); s.hang_lo = a; s.hang_hi = a + W;
		q2.push(sqe_h2d(0, a, 0, 256)); q2.doorbell(); s.idle(3000);
		CHECK(R32(s, R_STATUS) & ST_BUSY, "device not stuck on a hung DMA read");
		CHECK(R32(s, R_SQ_HEAD) == 0, "command retired although its DMA never completed");
		s.csr_write(R_CTRL, CTRL_ENGINE_RESET); wait_ready(s);
		CHECK(q2.reap().empty(), "completion for an aborted DMA");
		s.hang_lo = s.hang_hi = 0; verify_device("hung DMA read");
	}
	// ---- (d) STALE read data after a reset must be discarded (epoch filter) ----
	{
		HostQ q2(s); q2.setup(16);
		s.cfg.rd_lat_min = s.cfg.rd_lat_max = 4; s.late_reads = 0;
		// first transfer: requests answered very late
		q2.push(sqe_h2d(0, b, 0, 64)); q2.doorbell();
		s.late_reads = 300;
		s.idle(100);
		s.csr_write(R_CTRL, CTRL_ENGINE_RESET); wait_ready(s);
		s.late_reads = 0;
		// immediately start different work while the stale beats are still on their way
		HostQ q3(s); q3.setup(16);
		auto r = q3.run({sqe_scrub(0), sqe_h2d(0, a, 0, 256), sqe_d2h(0, chk, 0, 256)}, 400000);
		s.idle(600);                                                            // let every stale beat arrive
		CHECK(r.size() == 3 && r[2].status == 0, "work after reset failed");
		CHECK(memcmp(&s.hm.d[chk], &s.hm.d[a], 256) == 0, "STALE data from before the reset reached device memory / a later command");
		verify_device("stale responses");
	}
	// ---- (e) reset in the middle of long on-device commands; memory of other contexts survives ----
	{
		HostQ q2(s); q2.setup(16);
		auto r = q2.run({sqe_scrub(1), sqe_h2d(1, a, 0, W), sqe_d2h(1, chk, 0, W)});
		CHECK(r.size() == 3 && memcmp(&s.hm.d[chk], &s.hm.d[a], W) == 0, "preload ctx 1");
		for (int victim_op = 0; victim_op < 3; victim_op++) {
			q2.setup(16);
			sfg1m_sqe e = victim_op == 0 ? sqe_scrub(0) : victim_op == 1 ? sqe_ten(0, 0, 256, 512, 8, true) : sqe_vec(0, 0, 0, 256, 512, 200);
			uint32_t d0 = R32(s, R_DONE);
			q2.push(sqe_h2d(0, b, 0, W)); q2.push(e); q2.doorbell();
			s.run_until([&] { return R32(s, R_DONE) >= d0 + 1 && (R32(s, R_STATUS) & ST_BUSY); }, 200000); s.idle(20);   // mid-flight
			s.csr_write(R_CTRL, CTRL_ENGINE_RESET); wait_ready(s);
			s.csr_write(R_IRQ_STATUS, 7);
			HostQ q3(s); q3.setup(16);
			auto g = q3.run({sqe_d2h(1, chk, 0, W)});
			CHECK(g.size() == 1 && g[0].status == 0 && memcmp(&s.hm.d[chk], &s.hm.d[a], W) == 0, "ctx 1 memory not retained across an ENGINE_RESET (victim op %d)", victim_op);
		}
	}
	// ---- (f) reset while a CQE write is stalled: it is dropped, nothing leaks later ----
	{
		HostQ q2(s); q2.setup(16);
		q2.push(sqe_nop()); q2.doorbell(); s.force_wr_stall = true;
		s.idle(900);                                                            // fetch done, CQE write-back stalled
		s.csr_write(R_CTRL, CTRL_ENGINE_RESET); wait_ready(s); s.force_wr_stall = false; s.idle(100);
		CHECK(s.hm.r16(q2.cq + 14) == 0 && s.hm.r32(q2.cq + 8) == 0, "CQE (partially) written for an aborted command");
		verify_device("stalled write-back");
	}
	// ---- (g) FUNCTION reset clears configuration, counters and FATAL ----
	{
		HostQ q2(s); q2.setup(16); q2.run({sqe_nop()});
		s.csr_write(R_RESET, RESET_MAGIC); CHECK(R32(s, R_STATUS) & ST_RESET_ACTIVE, "no RESET_ACTIVE after function reset"); wait_ready(s);
		CHECK(R32(s, R_DONE) == 0 && R32(s, R_ERR) == 0 && R32(s, R_SQ_BASE_LO) == 0 && R32(s, R_SQ_ENTRIES) == 0 && R32(s, R_IRQ_MASK) == 0, "function reset kept state");
		verify_device("function reset");
	}
	// ---- (h) reset storm: random resets at random moments during random work ----
	{
		long resets = 0, ok = 0;
		for (int i = 0; i < 120; i++) {
			HostQ q2(s); q2.setup(16);
			s.cfg.rd_lat_min = 1; s.cfg.rd_lat_max = 1 + rng() % 30; s.cfg.wr_stall_prob = (rng() % 3) ? 0.0 : 0.5;
			int n = 1 + rng() % 6;
			for (int k = 0; k < n; k++) {
				switch (rng() % 4) {
				case 0: q2.push(sqe_h2d(rng() % s.max_ctx, a, 4 * (rng() % 64), 4 + 4 * (rng() % 200))); break;
				case 1: q2.push(sqe_d2h(rng() % s.max_ctx, chk, 0, 4 + 4 * (rng() % 200))); break;
				case 2: q2.push(sqe_ten(rng() % s.max_ctx, 0, 256, 512, 1 + rng() % 6, rng() & 1)); break;
				default: q2.push(sqe_vec(rng() % s.max_ctx, rng() % 8 == 3 ? 0 : rng() % 8, 0, 256, 512, 1 + rng() % 100)); break;
				}
			}
			q2.doorbell(); s.idle(rng() % 400);
			if (rng() % 4) s.csr_write(R_CTRL, CTRL_ENGINE_RESET); else s.csr_write(R_RESET, RESET_MAGIC);
			resets++;
			if (!wait_ready(s, 2000)) { CHECK(false, "storm %d: READY never returned", i); break; }
			s.csr_write(R_IRQ_STATUS, 7); s.force_wr_stall = false; s.hang_reads = false;
			s.cfg.wr_stall_prob = 0; s.cfg.rd_lat_max = s.cfg.rd_lat_min = 4;
			HostQ q3(s); q3.setup(16);
			auto g = q3.run({sqe_scrub(0), sqe_h2d(0, a, 0, 128), sqe_d2h(0, chk, 0, 128)}, 200000);
			if (g.size() == 3 && g[2].status == 0 && !memcmp(&s.hm.d[chk], &s.hm.d[a], 128)) ok++;
			else CHECK(false, "storm %d: device not functional after reset", i);
		}
		CHECK(ok == resets, "reset storm: %ld of %ld recoveries", ok, resets);
	}
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	return g_tr->fails == 0;
}

// --------------------------------------------------------------------------------- timeouts / recovery
// Driver policy (docs/01-design.md section 6): no progress for T -> ENGINE_RESET -> if READY does not
// return -> FUNCTION reset. The device side must always give the host a way out.
static bool t_timeout(SfgSys &s)
{
	const uint64_t W = s.win_bytes; std::mt19937 rng(91);
	uint64_t a = s.hm.alloc(W, 4096), chk = s.hm.alloc(W, 4096), o = s.hm.alloc(W, 4096);
	fillr(s.hm, a, W, rng);
	struct Hang { const char *name; std::function<void()> inject; std::function<void()> release; std::vector<sfg1m_sqe> cmds; } hs[] = {
		{"SQ fetch never answered", [&] { s.hang_reads = true; }, [&] { s.hang_reads = false; }, {sqe_nop()}},
		{"DMA read data never arrives", [&] { s.hang_lo = a; s.hang_hi = a + W; }, [&] { s.hang_lo = s.hang_hi = 0; }, {sqe_h2d(0, a, 0, 256)}},
		{"posted-write path blocked during D2H", [&] { s.force_wr_stall = true; }, [&] { s.force_wr_stall = false; }, {sqe_d2h(0, o, 0, 256)}},
		{"posted-write path blocked during CQE write-back", [&] { s.force_wr_stall = true; }, [&] { s.force_wr_stall = false; }, {sqe_nop()}},
	};
	uint64_t worst_recovery = 0;
	for (auto &h : hs) {
		HostQ q(s); q.setup(16);
		h.inject(); q.push(h.cmds[0]); q.doorbell();
		uint64_t t0 = s.cycle;
		bool progressed = s.run_until([&] { return !q.reap().empty(); }, 5000);
		CHECK(!progressed, "%s: a completion appeared although the path is blocked", h.name);
		CHECK(R32(s, R_STATUS) & ST_BUSY, "%s: not BUSY while stuck", h.name);
		// ---- recovery: ENGINE_RESET ----
		uint64_t r0 = s.cycle;
		s.csr_write(R_CTRL, CTRL_ENGINE_RESET);
		bool rdy = wait_ready(s, 5000);
		CHECK(rdy, "%s: READY did not return after ENGINE_RESET", h.name);
		worst_recovery = std::max(worst_recovery, s.cycle - r0);
		h.release(); s.idle(50);
		HostQ q2(s); q2.setup(16);
		auto g = q2.run({sqe_scrub(0), sqe_h2d(0, a, 0, 256), sqe_d2h(0, chk, 0, 256)}, 100000);
		CHECK(g.size() == 3 && g[2].status == 0 && !memcmp(&s.hm.d[chk], &s.hm.d[a], 256), "%s: not functional after recovery", h.name);
		(void)t0;
	}
	// FUNCTION reset recovers even from a wedged bus: escalation path
	{
		s.hang_reads = true; HostQ q(s); q.setup(16); q.push(sqe_nop()); q.doorbell(); s.idle(500);
		s.csr_write(R_RESET, RESET_MAGIC); CHECK(wait_ready(s, 5000), "READY after FUNCTION reset");
		s.hang_reads = false; s.idle(20);
		HostQ q2(s); q2.setup(16); auto g = q2.run({sqe_nop()}); CHECK(g.size() == 1 && g[0].status == 0, "device unusable after function reset");
	}
	if (getenv("SFG1_VERBOSE")) printf("  timeout: worst ENGINE_RESET recovery = %llu cycles\n", (unsigned long long)worst_recovery);
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	return g_tr->fails == 0;
}

// --------------------------------------------------------------------------------- random ISA differential test
static uint64_t pickf(std::mt19937_64 &r, uint64_t win)
{
	switch (r() % 12) {
	case 0: return 0; case 1: return (r() % (win / 4)) * 4; case 2: return win - 4 * (r() % 8); case 3: return win + 4 * (r() % 3) - 4;
	case 4: return r() % win; case 5: return r() % (win / 4 + 2); case 6: return 1ull << (58 + r() % 6);
	case 7: return ~0ull - (r() % 4); case 8: return 1ull << (32 + r() % 30); case 9: return win / 4 - (r() % 3);
	default: return (r() % 32) * 4;
	}
}

static bool t_diff(SfgSys &s)
{
	const uint64_t W = s.win_bytes; const int N = s.max_ctx;
	long seed = getenv("SFG1_SEED") ? atol(getenv("SFG1_SEED")) : 1;
	int batches = getenv("SFG1_BATCHES") ? atoi(getenv("SFG1_BATCHES")) : 200;
	std::mt19937_64 R(seed * 0x9e3779b97f4a7c15ull + 17); std::mt19937 r32((uint32_t)seed);
	HostQ q(s); q.setup(32);
	const uint64_t DSZ = 4 * W;                                   // any single DMA (<= W) fits in the area or in the hole
	uint64_t D = s.hm.alloc(DSZ, 4096), hole = s.hm.alloc(DSZ, 4096), dump = s.hm.alloc(N * W, 4096);
	s.hm.hole(hole, DSZ);
	for (size_t i = 0; i < DSZ; i++) s.hm.d[D + i] = (uint8_t)r32();
	Ref ref(N, W); ref.sync_host(s.hm);
	std::vector<bool> taint(N, false);
	long cmds_run = 0, errs = 0, mism = 0; long cnt_op[8] = {0}, cnt_st[8] = {0};
	auto hostaddr = [&](bool bad) -> uint64_t { return (bad ? hole : D) + 4 * (R() % ((DSZ - W) / 4 + 1)); };

	for (int b = 0; b < batches; b++) {
		// random bus personality per batch: results must not depend on it
		s.cfg.rd_lat_min = 1 + R() % 6; s.cfg.rd_lat_max = s.cfg.rd_lat_min + R() % 20; s.cfg.beat_gap = (R() % 4 == 0) ? R() % 3 : 0;
		s.cfg.wr_stall_prob = (R() % 3 == 0) ? 0.05 * (R() % 12) : 0; s.cfg.wr_lat_min = 1; s.cfg.wr_lat_max = 1 + R() % 8;
		std::vector<sfg1m_sqe> cmds;
		for (int c = 0; c < N; c++) if (taint[c]) { cmds.push_back(sqe_scrub(c)); taint[c] = false; }       // resync after a DMA fault
		// fill half of the windows with random data first: without it most operands are the scrubbed zeros and arithmetic bugs on one lane
		// (e.g. a DOT8 that drops lane 3) are invisible to this test -- found by mutation testing on V5 (mutant 18)
		for (int c = 0; c < N; c++) if (R() % 2) cmds.push_back(sqe_h2d(c, D + 4 * (R() % ((DSZ - W) / 4 + 1)), 0, W));
		int n = 1 + R() % 20;
		for (int i = 0; i < n; i++) {
			int c = R() % N; sfg1m_sqe e; int k = R() % 100;
			uint64_t len;
			if (k < 20) { len = 4 * (1 + R() % (W / 8)); uint64_t a = 4 * (R() % ((W - len) / 4 + 1)); e = sqe_h2d(c, hostaddr(R() % 25 == 0), a, len); }
			else if (k < 40) { len = 4 * (1 + R() % (W / 8)); uint64_t a = 4 * (R() % ((W - len) / 4 + 1)); e = sqe_d2h(c, hostaddr(R() % 25 == 0), a, len); }
			else if (k < 60) {
				uint32_t op = R() % 8; uint64_t words = 1 + R() % (W / 16);
				uint64_t span = words * 4, A, B, C;
				A = 4 * (R() % ((W - span) / 4 + 1)); B = op == 3 ? 0 : 4 * (R() % ((W - span) / 4 + 1));
				switch (R() % 3) {                                         // C: disjoint, exact alias, or (V0 only) partial overlap
				case 0: C = 4 * (R() % ((W - (op == 7 ? 4 : span)) / 4 + 1)); if (SFG1_VEC_MODE != 0 && op != 7) { auto ov = [&](uint64_t x) { return x != C && x < C + span && C < x + span; }; if (ov(A) || (op != 3 && ov(B))) C = A; } break;
				case 1: C = A; break;
				default: C = (op == 3 || R() & 1) ? A : B; break;
				}
				// the contract leaves PARTIAL overlap of C with A or B undefined and the pipelined variants differ from a sequential model there;
				// exact aliasing (C == A, C == B) is defined and tested. (A random-data fill exposed this generator gap on V4/V5: B = A - 3 words, C = A.)
				if (SFG1_VEC_MODE != 0 && op != 7) { auto ov = [&](uint64_t x) { return x != C && x < C + span && C < x + span; }; if (ov(A)) A = C; if (op != 3 && ov(B)) B = C; }
				e = sqe_vec(c, op, A, B, C, words);
			}
			else if (k < 75) {
				uint64_t tiles = 1 + R() % 6; uint64_t A = 4 * (R() % ((W - 16 * tiles) / 4 + 1)), B2 = 4 * (R() % ((W - 16 * tiles) / 4 + 1)), C = 4 * (R() % ((W - 64 * tiles) / 4 + 1));
				e = sqe_ten(c, A, B2, C, tiles, R() & 1);                   // arbitrary overlaps are fine for TEN (see engine header)
			}
			else if (k < 78) e = sqe_scrub(c);
			else if (k < 82) e = sqe_nop(c);
			else {                                                            // boundary / garbage
				e = sqe((uint16_t)(R() % 9), (uint16_t)(R() % (N + 2)));
				e.flags = (R() % 3 == 0) ? (uint16_t)R() : (uint16_t)(R() & 1); e.exec_op = (R() % 3 == 0) ? (uint32_t)(R() % 10) : (uint32_t)(R() % 8);
				e.host_addr = (R() % 2) ? hostaddr(R() % 4 == 0) : R(); e.len = pickf(R, W); e.dev_a = pickf(R, W); e.dev_b = pickf(R, W); e.dev_c = pickf(R, W);
				if (R() % 8 == 0) e.rsvd0 = (uint32_t)R(); if (R() % 8 == 0) e.rsvd1 = R();
			}
			cmds.push_back(e);
		}
		// ---- run on the DUT, stop-and-resume on errors (R7), model executes every command in order ----
		std::vector<Cqe> got; size_t sent = 0; uint64_t t0 = s.cycle; bool stuck = false;
		while (got.size() < cmds.size()) {
			bool pushed = false;
			while (sent < cmds.size() && q.free_slots() > 0) { q.push(cmds[sent++]); pushed = true; }
			if (pushed) q.doorbell();
			s.idle(1);
			auto r = q.reap(); got.insert(got.end(), r.begin(), r.end());
			if (!r.empty() && r.back().status) {
				s.run_until([&] { return (R32(s, R_STATUS) & ST_HALTED) != 0; }, 100);
				s.idle(40); auto r2 = q.reap(); CHECK(r2.empty(), "diff: command executed while HALTED");
				got.insert(got.end(), r2.begin(), r2.end()); resume(s);
			}
			if (s.cycle - t0 > 2000000) { stuck = true; break; }
		}
		CHECK(!stuck, "diff batch %d: stuck", b);
		for (size_t i = 0; i < got.size() && i < cmds.size(); i++) {
			uint8_t want = ref.exec(cmds[i]); cmds_run++;
			cnt_op[cmds[i].opcode & 7]++; cnt_st[want & 7]++;
			if (want) errs++;
			if (got[i].status != want) {
				mism++;
				CHECK(false, "diff b%d cmd%zu: op %u ctx %u flags %x exec %u host %llx len %llx a %llx b %llx c %llx: rtl status %u model %u", b, i, cmds[i].opcode, cmds[i].ctx_id, cmds[i].flags, cmds[i].exec_op,
				      (unsigned long long)cmds[i].host_addr, (unsigned long long)cmds[i].len, (unsigned long long)cmds[i].dev_a, (unsigned long long)cmds[i].dev_b, (unsigned long long)cmds[i].dev_c, got[i].status, want);
			}
			if (want == SFG1M_ST_DMA_ERROR && cmds[i].opcode == SFG1M_OP_DMA_H2D) taint[cmds[i].ctx_id] = true;
			if (want == SFG1M_ST_DMA_ERROR && cmds[i].opcode == SFG1M_OP_DMA_D2H) { /* nothing written: no taint */ }
			if (got[i].ctx != cmds[i].ctx_id) CHECK(false, "diff: ctx echo");
		}
		if (mism > 10) break;
		// ---- observe device state only through the contract: dump every window ----
		std::vector<sfg1m_sqe> dumps;
		for (int c = 0; c < N; c++) if (!taint[c]) dumps.push_back(sqe_d2h(c, dump + c * W, 0, W));
		auto g = q.run(dumps, 2000000);
		CHECK(g.size() == dumps.size(), "diff: window dump incomplete");
		for (auto &d : dumps) ref.exec(d);
		for (int c = 0; c < N; c++) if (!taint[c] && memcmp(&s.hm.d[dump + c * W], ref.win(c), W)) {
			CHECK(false, "diff b%d: ctx %d window differs from the model", b, c); mism++;
			if (mism == 1 || getenv("SFG1_VERBOSE")) for (size_t i = 0; i < cmds.size(); i++) {       // first failure: show the batch that produced it
				const auto &x = cmds[i]; fprintf(stderr, "    b%d cmd%zu: op %u ctx %u flags %x exec %u len %llx a %llx b %llx c %llx  (model status %s)\n", b, i, x.opcode, x.ctx_id, x.flags, x.exec_op,
				        (unsigned long long)x.len, (unsigned long long)x.dev_a, (unsigned long long)x.dev_b, (unsigned long long)x.dev_c, "see above");
			}
		}
		if (memcmp(&s.hm.d[D], &ref.mhm.d[D], DSZ)) { CHECK(false, "diff b%d: host data area differs from the model", b); mism++; }
		if (mism > 10) break;
	}
	if (getenv("SFG1_VERBOSE") || true) {
		printf("  diff seed=%ld: %ld commands (%ld rejected); by opcode [nop h2d vec ten - d2h scrub]:", seed, cmds_run, errs);
		for (int i = 0; i < 7; i++) printf(" %ld", cnt_op[i]); printf("\n");
	}
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	return g_tr->fails == 0;
}

const std::vector<TestEntry> &all_tests_stress()
{
	static const std::vector<TestEntry> v = {
		{"stalls", t_stalls, "9 bus timing/back-pressure configurations give identical results; forced write stall; payload-before-phase monitor"},
		{"irq", t_irq, "acknowledge-then-drain, mask/unmask re-fire, partial W1C, negative control (drain-then-ack loses a wake-up), FATAL irq"},
		{"reset", t_reset, "ENGINE/FUNCTION reset semantics, aborted commands write no CQE, stale read data discarded, memory retention, 120-reset storm"},
		{"timeout", t_timeout, "4 hang classes -> ENGINE_RESET recovery; FUNCTION reset escalation"},
		{"diff", t_diff, "random ISA differential vs the golden model: statuses, device windows, host memory; random bus timing"},
	};
	return v;
}
