// SPDX-License-Identifier: GPL-2.0-only
// Cycle-accurate profile of fixed workloads, read from the device's own perf counters (BAR0 0x100+) and from the
// simulation clock. ALL numbers here are SIMULATED CYCLES of the RTL against a MODELLED host-memory port
// (latency/throttle from BusCfg; env SFG1_RD_LAT, SFG1_BEAT_GAP). They are not hardware measurements and they
// carry no clock frequency: frequency comes from the FPGA flow (a different, equally non-hardware kind of number).
// Output: one machine-readable line per workload:  PERF <name> key=value ...
#include "ref.h"
#include <cstdlib>
#include <random>

static uint32_t R32(SfgSys &s, uint16_t r) { return s.csr_read(r); }
struct Meas { uint64_t total; uint32_t cmds; uint32_t busy, fetch, decode, exec, wb, h2d, d2h, vec, ten, scrub, rdb, wrb, rds, wrs; };

static Meas measure(SfgSys &s, HostQ &q, const std::vector<sfg1m_sqe> &cmds)
{
	s.csr_write(X_PERF_CTRL, 1);                                   // clear counters
	uint64_t t0 = s.cycle; size_t done = 0, sent = 0;
	while (sent < cmds.size() && q.free_slots() > 0) q.push(cmds[sent++]);
	q.doorbell();
	while (done < cmds.size()) {
		s.tick();
		uint32_t before = q.cqes_reaped; auto r = q.reap(); (void)before; done += r.size();
		for (auto &c : r) if (c.status) { fprintf(stderr, "perf workload command failed with status %u\n", c.status); abort(); }
		if (sent < cmds.size() && q.free_slots() > 0) { while (sent < cmds.size() && q.free_slots() > 0) q.push(cmds[sent++]); q.doorbell(); }
		if (s.cycle - t0 > 50000000) { fprintf(stderr, "perf workload hung\n"); abort(); }
	}
	Meas m{}; m.total = s.cycle - t0; m.cmds = (uint32_t)cmds.size();
	m.busy = R32(s, X_PERF_BUSY); m.fetch = R32(s, X_PERF_FETCH); m.decode = R32(s, X_PERF_DECODE); m.exec = R32(s, X_PERF_EXEC); m.wb = R32(s, X_PERF_WB);
	m.h2d = R32(s, X_PERF_H2D); m.d2h = R32(s, X_PERF_D2H); m.vec = R32(s, X_PERF_VEC); m.ten = R32(s, X_PERF_TEN); m.scrub = R32(s, X_PERF_SCRUB);
	m.rdb = R32(s, X_PERF_RDB); m.wrb = R32(s, X_PERF_WRB); m.rds = R32(s, X_PERF_RDS); m.wrs = R32(s, X_PERF_WRS);
	return m;
}
static void emit(const char *name, const Meas &m, double bytes = 0, double ops = 0)
{
	printf("PERF %s total=%llu cmds=%u busy=%u fetch=%u decode=%u exec=%u wb=%u h2d=%u d2h=%u vec=%u ten=%u scrub=%u rd_beats=%u wr_beats=%u rd_stall=%u wr_stall=%u bytes=%.0f ops=%.0f\n",
	       name, (unsigned long long)m.total, m.cmds, m.busy, m.fetch, m.decode, m.exec, m.wb, m.h2d, m.d2h, m.vec, m.ten, m.scrub, m.rdb, m.wrb, m.rds, m.wrs, bytes, ops);
}

static bool t_perf(SfgSys &s)
{
	if (const char *l = getenv("SFG1_RD_LAT")) s.cfg.rd_lat_min = s.cfg.rd_lat_max = atoi(l);
	if (const char *g = getenv("SFG1_BEAT_GAP")) s.cfg.beat_gap = atoi(g);
	const uint64_t W = s.win_bytes; std::mt19937 rng(3);
	HostQ q(s); q.setup(64);
	uint64_t buf = s.hm.alloc(W, 4096), out = s.hm.alloc(W, 4096);
	for (uint64_t i = 0; i < W; i++) s.hm.d[buf + i] = (uint8_t)rng();
	const uint64_t kb4 = std::min<uint64_t>(4096, W / 2), vw = std::min<uint64_t>(1024, W / 16);      // 4 KiB transfers, 1024-word VEC (256 in a 4 KiB window)
	// the working set must be initialised on the device (windows start undefined)
	{ std::vector<sfg1m_sqe> c = {sqe_scrub(0), sqe_h2d(0, buf, 0, W)}; measure(s, q, c); }

	{ std::vector<sfg1m_sqe> c(48, sqe_nop()); Meas m = measure(s, q, c); emit("nop_stream48", m); }
	{ std::vector<sfg1m_sqe> c(1, sqe_nop());  Meas m = measure(s, q, c); emit("nop_single", m); }
	{ std::vector<sfg1m_sqe> c = {sqe_h2d(0, buf, 0, kb4)}; Meas m = measure(s, q, c); emit("h2d_4k", m, (double)kb4); }
	{ std::vector<sfg1m_sqe> c = {sqe_d2h(0, out, 0, kb4)}; Meas m = measure(s, q, c); emit("d2h_4k", m, (double)kb4); }
	{ std::vector<sfg1m_sqe> c = {sqe_vec(0, SFG1M_VEC_ADD8, 0, vw * 4, vw * 8, vw)}; Meas m = measure(s, q, c); emit("vec_add8", m, 12.0 * vw, 4.0 * vw); }
	{ std::vector<sfg1m_sqe> c = {sqe_vec(0, SFG1M_VEC_MUL8, 0, vw * 4, vw * 8, vw)}; Meas m = measure(s, q, c); emit("vec_mul8", m, 12.0 * vw, 4.0 * vw); }
	{ std::vector<sfg1m_sqe> c = {sqe_vec(0, SFG1M_VEC_DOT8, 0, vw * 4, vw * 8, vw)}; Meas m = measure(s, q, c); emit("vec_dot8", m, 8.0 * vw, 8.0 * vw); }
	const uint64_t tiles = std::min<uint64_t>(64, W / 256);
	{ std::vector<sfg1m_sqe> c = {sqe_ten(0, 0, tiles * 16, tiles * 32, tiles, false)}; Meas m = measure(s, q, c); emit("ten_noacc", m, tiles * 96.0, tiles * 128.0); }
	{ std::vector<sfg1m_sqe> c = {sqe_ten(0, 0, tiles * 16, tiles * 32, tiles, true)}; Meas m = measure(s, q, c); emit("ten_acc", m, tiles * 160.0, tiles * 128.0); }
	{ std::vector<sfg1m_sqe> c = {sqe_scrub(0)}; Meas m = measure(s, q, c); emit("scrub_window", m, (double)W); }
	// a typical kernel: upload two operands, VEC add, download (the same shape as the driver's ex2_vector_add)
	{ const uint64_t n = std::min<uint64_t>(2048, W / 4);
	  std::vector<sfg1m_sqe> c = {sqe_h2d(0, buf, 0, n), sqe_h2d(0, buf + n, n, n), sqe_vec(0, SFG1M_VEC_ADD8, 0, n, 2 * n, n / 4), sqe_d2h(0, out, 2 * n, n)};
	  Meas m = measure(s, q, c); emit("kernel_vecadd_job", m, 3.0 * n, (double)n); }
	// matmul-shaped job: 2 uploads, 4 accumulating TEN commands, 1 download (16x16x16, one tile array per K-tile)
	{ const uint64_t T = 16, ab = 4 * T * 16;
	  std::vector<sfg1m_sqe> c = {sqe_h2d(0, buf, 0, ab), sqe_h2d(0, buf + ab, ab, ab)};
	  for (int k = 0; k < 4; k++) c.push_back(sqe_ten(0, k * T * 16, ab + k * T * 16, 2 * ab, T, k > 0));
	  c.push_back(sqe_d2h(0, out, 2 * ab, T * 64));
	  Meas m = measure(s, q, c); emit("kernel_matmul16_job", m, 2.0 * ab + T * 64, 2.0 * 16 * 16 * 16); }
	printf("PERFCFG rd_lat=%d beat_gap=%d win=%llu ctx=%d\n", s.cfg.rd_lat_min, s.cfg.beat_gap, (unsigned long long)W, s.max_ctx);
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	return g_tr->fails == 0;
}

const std::vector<TestEntry> &all_tests_perf() { static const std::vector<TestEntry> v = {{"perf", t_perf, "cycle profile of fixed workloads (PERF lines)"}}; return v; }
