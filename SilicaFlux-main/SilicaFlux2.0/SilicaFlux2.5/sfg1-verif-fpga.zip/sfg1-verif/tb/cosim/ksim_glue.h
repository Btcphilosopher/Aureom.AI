// SPDX-License-Identifier: GPL-2.0-only
// Binds the userspace driver simulation (ksim) to the RTL co-simulation (SfgSys).
#ifndef KSIM_GLUE_H
#define KSIM_GLUE_H
#include "hostq.h"
extern "C" {
#include "ksim.h"
}
struct Ksim {
	SfgSys &s; ksim_cfg cfg; ksim_host_ops ops; int probe_rc;
	explicit Ksim(SfgSys &sys, double clock_mhz = 100.0, void (*tweak)(ksim_cfg &) = nullptr);
	~Ksim();
};
SfgSys *ksim_sys();
#endif
