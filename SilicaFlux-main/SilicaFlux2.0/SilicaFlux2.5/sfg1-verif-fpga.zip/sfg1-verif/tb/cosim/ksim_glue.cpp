// SPDX-License-Identifier: GPL-2.0-only
#include "ksim_glue.h"
static SfgSys *g_sys = nullptr;
SfgSys *ksim_sys() { return g_sys; }
static uint32_t h_rd(void *, uint32_t off) { return g_sys->csr_read((uint16_t)off); }
static void h_wr(void *, uint32_t off, uint32_t v) { g_sys->csr_write((uint16_t)off, v); }
static void h_tick(void *, uint64_t c) { for (uint64_t i = 0; i < c; i++) g_sys->tick(); }
static uint64_t h_cycle(void *) { return g_sys->cycle; }
static void *h_alloc(void *, uint64_t size, uint64_t *bus) { *bus = g_sys->hm.alloc_block(size); return &g_sys->hm.d[*bus]; }
static void h_release(void *, uint64_t bus, uint64_t size) { g_sys->hm.free_block(bus, size); }

Ksim::Ksim(SfgSys &sys, double clock_mhz, void (*tweak)(ksim_cfg &)) : s(sys)
{
	g_sys = &sys;
	ksim_default_cfg(&cfg);
	if (tweak) tweak(cfg);
	ops = {nullptr, h_rd, h_wr, h_tick, h_cycle, h_alloc, h_release, clock_mhz};
	s.on_irq = [] { ksim_irq(); };
	probe_rc = ksim_probe(&ops, &cfg);
}
Ksim::~Ksim() { s.on_irq = nullptr; g_sys = nullptr; }
