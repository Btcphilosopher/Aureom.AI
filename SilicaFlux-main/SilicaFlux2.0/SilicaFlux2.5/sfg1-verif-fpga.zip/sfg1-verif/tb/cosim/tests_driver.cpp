// SPDX-License-Identifier: GPL-2.0-only
// Driver / runtime integration tests: the REAL driver ring/IRQ/hw/recovery code (ksim) and the
// ported UAPI layer, over the RTL. Includes the driver package's unmodified examples and the
// runtime's end-to-end kernels.
#include "ksim_glue.h"
#include "ref.h"
#include <algorithm>
#include <random>
#include <set>
#include <time.h>
extern "C" {
#include <drm/drm.h>
#include <drm/sfg1_accel.h>
#include "sfg1rt.h"
int ex1_main(int, char **); int ex2_main(void); int ex3_main(void); int ex5_main(void);
}

static uint32_t R32(SfgSys &s, uint16_t r) { return s.csr_read(r); }
enum { F_OK = 0, F_ERR = 1, F_TO = 2, F_CANCEL = 3 };

struct DC {                              // a driver-level context: fd + one BO
	int fd = -1; uint32_t bo = 0; uint8_t *map = nullptr; uint64_t size = 0, off = 0, win = 0;
	int open(uint64_t bytes = 16384)
	{
		fd = ksim_open(); if (fd < 0) return fd;
		struct drm_sfg1_get_param p = {DRM_SFG1_PARAM_CTX_WINDOW_SIZE, 0, 0};
		ksim_ioctl(fd, DRM_IOCTL_SFG1_GET_PARAM, &p); win = p.value;
		struct drm_sfg1_bo_create b = {}; b.size = bytes;
		int r = ksim_ioctl(fd, DRM_IOCTL_SFG1_BO_CREATE, &b); if (r) return r;
		bo = b.handle; off = b.mmap_offset; size = b.real_size; map = (uint8_t *)ksim_mmap(fd, size, (long)off);
		return map ? 0 : -EFAULT;
	}
	void close() { if (fd >= 0) ksim_close(fd); fd = -1; }
	static drm_sfg1_cmd h2d(uint32_t bo, uint64_t boff, uint64_t dev, uint64_t len) { drm_sfg1_cmd c = {}; c.op = DRM_SFG1_OP_DMA_H2D; c.bo_handle = bo; c.bo_offset = boff; c.dev_a = dev; c.len = len; return c; }
	static drm_sfg1_cmd d2h(uint32_t bo, uint64_t boff, uint64_t dev, uint64_t len) { drm_sfg1_cmd c = {}; c.op = DRM_SFG1_OP_DMA_D2H; c.bo_handle = bo; c.bo_offset = boff; c.dev_a = dev; c.len = len; return c; }
	static drm_sfg1_cmd vec(uint32_t op, uint64_t a, uint64_t b, uint64_t c_, uint64_t w) { drm_sfg1_cmd c = {}; c.op = DRM_SFG1_OP_VEC; c.exec_op = op; c.dev_a = a; c.dev_b = b; c.dev_c = c_; c.len = w; return c; }
	static drm_sfg1_cmd nop() { drm_sfg1_cmd c = {}; c.op = DRM_SFG1_OP_NOP; return c; }
	int submit(const drm_sfg1_cmd *c, uint32_t n, uint64_t *id, uint32_t stride = sizeof(drm_sfg1_cmd))
	{ drm_sfg1_submit s = {}; s.cmds_ptr = (uintptr_t)c; s.cmd_count = n; s.cmd_stride = stride; int r = ksim_ioctl(fd, DRM_IOCTL_SFG1_SUBMIT, &s); if (!r) *id = s.job_id; return r; }
	int wait(uint64_t id, uint32_t *st, uint32_t *dev_err = nullptr, int64_t timeout_ms = -1)
	{
		drm_sfg1_wait_job w = {}; w.job_id = id;
		if (timeout_ms < 0) w.timeout_ns = INT64_MAX; else if (timeout_ms == 0) w.timeout_ns = 0;
		else { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); w.timeout_ns = (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec + timeout_ms * 1000000LL; }
		int r = ksim_ioctl(fd, DRM_IOCTL_SFG1_WAIT_JOB, &w); if (!r) { *st = w.status; if (dev_err) *dev_err = w.dev_error; } return r;
	}
	int run(const drm_sfg1_cmd *c, uint32_t n, uint32_t *dev_err = nullptr)
	{ uint64_t id; int r = submit(c, n, &id); if (r) return r; uint32_t st = 99; r = wait(id, &st, dev_err); return r ? r : (st == F_OK ? 0 : -(1000 + (int)st)); }
	drm_sfg1_get_stats stats() { drm_sfg1_get_stats g = {}; ksim_ioctl(fd, DRM_IOCTL_SFG1_GET_STATS, &g); return g; }
};

static void small_timeouts(ksim_cfg &c) { c.job_timeout_ms = 10; c.reset_timeout_ms = 10; c.strike_limit = 3; c.quarantine_ms = 100; }

// ----------------------------------------------------------------------------------- probe
static bool t_drv_probe(SfgSys &s)
{
	Ksim k(s, 100.0, small_timeouts);
	CHECK(k.probe_rc == 0, "ksim_probe -> %d", k.probe_rc);
	CHECK(ksim_dev_state() == 1, "device state %d", ksim_dev_state());
	CHECK((ksim_hw_caps() & 0x1f) == 0x1f, "caps %x", ksim_hw_caps());
	CHECK(ksim_log_count("SF-G1 hw 1.0.0") >= 1, "discovery log line missing");
	DC a; CHECK(a.open() == 0, "open");
	drm_sfg1_get_param p = {DRM_SFG1_PARAM_UAPI_VERSION, 0, 0}; ksim_ioctl(a.fd, DRM_IOCTL_SFG1_GET_PARAM, &p);
	CHECK(p.value == (1u << 16), "uapi version %llx", (unsigned long long)p.value);
	CHECK(a.win == (uint64_t)s.win_bytes, "ctx window %llu vs RTL %d", (unsigned long long)a.win, s.win_bytes);
	p = {DRM_SFG1_PARAM_MAX_CMDS_PER_SUBMIT, 0, 0}; ksim_ioctl(a.fd, DRM_IOCTL_SFG1_GET_PARAM, &p);
	CHECK(p.value == 63, "max cmds %llu", (unsigned long long)p.value);
	// the driver left the device in the state the contract prescribes: enabled, interrupts on, queues programmed
	CHECK(R32(s, R_CTRL) == 1 && R32(s, R_IRQ_MASK) == 7 && R32(s, R_SQ_ENTRIES) == ksim_sq_entries() && R32(s, R_CQ_ENTRIES) == ksim_sq_entries(), "device not programmed as the driver intends");
	CHECK((R32(s, R_STATUS) & (ST_READY | ST_FATAL | ST_HALTED)) == ST_READY, "status");
	CHECK(ksim_sq_free() == ksim_sq_entries() - 1, "credits %u", ksim_sq_free());
	CHECK(R32(s, R_SCRATCH) == 0, "driver left SCRATCH dirty");
	a.close(); ksim_remove();
	return g_tr->fails == 0;
}

// ----------------------------------------------------------------------------------- unmodified driver examples
static bool t_drv_examples(SfgSys &s)
{
	Ksim k(s, 100.0, small_timeouts); CHECK(k.probe_rc == 0, "probe");
	fflush(stdout);
	CHECK(ex1_main(0, nullptr) == 0, "ex1_info (unmodified driver example)");
	CHECK(ex2_main() == 0, "ex2_vector_add (unmodified): device output differs from the CPU reference");
	CHECK(ex3_main() == 0, "ex3_matmul (unmodified): device output differs from the CPU reference");
	CHECK(ex5_main() == 0, "ex5_error_handling (unmodified)");
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	CHECK(ksim_log_count("err:") == 0, "driver logged errors during healthy examples");
	return g_tr->fails == 0;
}

// ----------------------------------------------------------------------------------- end-to-end kernels (runtime)
static int64_t sim_clock(void *p) { SfgSys *s = (SfgSys *)p; return (int64_t)((double)s->cycle * 10.0); }   // 100 MHz -> 10 ns/cycle
static bool t_drv_kernels(SfgSys &s)
{
	Ksim k(s, 100.0, small_timeouts); CHECK(k.probe_rc == 0, "probe");
	int rc; sfg1rt *rt = sfg1rt_create(16384, &rc); CHECK(rt != nullptr, "runtime open %d", rc); if (!rt) return false;
	sfg1rt_set_clock(rt, sim_clock, &s);
	const int W = s.win_bytes; std::mt19937 rng(99);
	const size_t n = (size_t)W / 4;                    // lanes per operand: 3 operands fit the window
	std::vector<int8_t> a(n), b(n), c(n), ref(n);
	for (auto &x : a) x = (int8_t)rng(); for (auto &x : b) x = (int8_t)rng();
	struct VO { uint32_t op; const char *nm; int (*f)(int, int); } vops[] = {
		{DRM_SFG1_VEC_ADD8, "ADD8", [](int x, int y) { return x + y; }}, {DRM_SFG1_VEC_SUB8, "SUB8", [](int x, int y) { return x - y; }},
		{DRM_SFG1_VEC_MAX8, "MAX8", [](int x, int y) { return x > y ? x : y; }}, {DRM_SFG1_VEC_MUL8, "MUL8", [](int x, int y) { return x * y; }},
		{DRM_SFG1_VEC_XOR32, "XOR32", [](int x, int y) { return x ^ y; }}, {DRM_SFG1_VEC_AND32, "AND32", [](int x, int y) { return x & y; }},
	};
	for (auto &o : vops) {
		rc = sfg1rt_vec_i8(rt, o.op, a.data(), b.data(), c.data(), n); CHECK(rc == 0, "%s: rc %d", o.nm, rc);
		for (size_t i = 0; i < n; i++) ref[i] = (int8_t)o.f(a[i], b[i]);
		CHECK(memcmp(c.data(), ref.data(), n) == 0, "%s: device result differs from the CPU reference", o.nm);
	}
	rc = sfg1rt_relu_i8(rt, a.data(), c.data(), n); CHECK(rc == 0, "relu rc %d", rc);
	for (size_t i = 0; i < n; i++) ref[i] = a[i] < 0 ? 0 : a[i];
	CHECK(memcmp(c.data(), ref.data(), n) == 0, "RELU8 differs");
	int32_t dev_dot = 0, want = 0; rc = sfg1rt_dot_i8(rt, a.data(), b.data(), n, &dev_dot); CHECK(rc == 0, "dot rc %d", rc);
	for (size_t i = 0; i < n; i++) want += (int)a[i] * (int)b[i];
	CHECK(dev_dot == want, "DOT8 %d want %d", dev_dot, want);
	// matmul: several shapes, vs a CPU reference
	struct MM { int M, K, N; } shapes[] = {{4, 4, 4}, {8, 12, 4}, {16, 16, 16}, {12, 8, 20}, {16, 32, 8}};
	for (auto &m : shapes) {
		std::vector<int8_t> A((size_t)m.M * m.K), B((size_t)m.K * m.N); std::vector<int32_t> C((size_t)m.M * m.N), R((size_t)m.M * m.N, 0);
		for (auto &x : A) x = (int8_t)rng(); for (auto &x : B) x = (int8_t)rng();
		rc = sfg1rt_matmul_i8(rt, A.data(), B.data(), C.data(), m.M, m.K, m.N);
		if (rc) { CHECK(false, "matmul %dx%dx%d rc %d", m.M, m.K, m.N, rc); continue; }
		for (int i = 0; i < m.M; i++) for (int j = 0; j < m.N; j++) { int32_t acc = 0; for (int q = 0; q < m.K; q++) acc += A[i * m.K + q] * B[q * m.N + j]; R[i * m.N + j] = acc; }
		CHECK(C == R, "matmul %dx%dx%d differs from the CPU reference", m.M, m.K, m.N);
	}
	// two-layer MLP: matmul(device) -> requantise(host) -> relu(device) -> matmul(device)
	{
		const int IN = 16, HID = 16, OUT = 8, shift = 7; std::vector<int8_t> X(IN * 4), W1(HID * IN), W2(OUT * HID); std::vector<int32_t> Y(OUT * 4), RY(OUT * 4);
		for (auto &x : X) x = (int8_t)(rng() % 64 - 32); for (auto &x : W1) x = (int8_t)(rng() % 32 - 16); for (auto &x : W2) x = (int8_t)(rng() % 32 - 16);
		rc = sfg1rt_mlp_i8(rt, X.data(), W1.data(), W2.data(), IN, HID, OUT, shift, Y.data()); CHECK(rc == 0, "mlp rc %d", rc);
		std::vector<int8_t> H(HID * 4);
		for (int i = 0; i < HID; i++) for (int j = 0; j < 4; j++) { int32_t acc = 0; for (int q = 0; q < IN; q++) acc += W1[i * IN + q] * X[q * 4 + j]; acc >>= shift; acc = acc > 127 ? 127 : acc < -128 ? -128 : acc; H[i * 4 + j] = (int8_t)(acc < 0 ? 0 : acc); }
		for (int i = 0; i < OUT; i++) for (int j = 0; j < 4; j++) { int32_t acc = 0; for (int q = 0; q < HID; q++) acc += W2[i * HID + q] * H[q * 4 + j]; RY[i * 4 + j] = acc; }
		CHECK(Y == RY, "MLP output differs from the CPU reference");
	}
	// phase-split timing run (kernel vs host-transfer attribution), 16x16x16 matmul repeated
	{
		sfg1rt_set_phase_split(rt, 1); sfg1rt_timing *tm = sfg1rt_timing_get(rt); memset(tm, 0, sizeof(*tm)); std::vector<int8_t> A(256), B(256); std::vector<int32_t> C(256);
		for (auto &x : A) x = (int8_t)rng(); for (auto &x : B) x = (int8_t)rng();
		uint64_t c0 = s.cycle;
		for (int i = 0; i < 8; i++) CHECK(sfg1rt_matmul_i8(rt, A.data(), B.data(), C.data(), 16, 16, 16) == 0, "timed matmul");
		printf("KPERF matmul16x16x16 x8: total %llu cycles; h2d %lld ns, kernel %lld ns, d2h %lld ns (simulated, 100 MHz); jobs %llu\n",
		       (unsigned long long)(s.cycle - c0), (long long)tm->h2d_ns, (long long)tm->kernel_ns, (long long)tm->d2h_ns, (unsigned long long)tm->jobs);
		sfg1rt_set_phase_split(rt, 0);
	}
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	CHECK(ksim_log_count("err:") == 0, "driver logged errors");
	sfg1rt_destroy(rt);
	return g_tr->fails == 0;
}

// ----------------------------------------------------------------------------------- concurrent contexts + ring wraparound
static bool t_drv_concurrent(SfgSys &s)
{
	Ksim k(s, 100.0, small_timeouts); CHECK(k.probe_rc == 0, "probe");
	const int N = s.max_ctx; std::vector<DC> c(N);
	for (int i = 0; i < N; i++) CHECK(c[i].open(4096) == 0, "open %d", i);
	DC extra; CHECK(extra.open() == -EBUSY, "all %d hardware contexts in use: next open must be EBUSY (got %d)", N, extra.open());
	std::set<unsigned> ids; for (auto &x : c) ids.insert(ksim_ctx_id(x.fd)); CHECK((int)ids.size() == N, "contexts share a hardware slot");
	struct J { int ctx; uint64_t id; };
	std::vector<J> jobs; std::mt19937 rng(5);
	const int rounds = 30;                                          // 30 rounds x N ctx x 4 cmds >> queue capacity: several laps
	for (int rd = 0; rd < rounds; rd++)
		for (int i = 0; i < N; i++) {
			memset(c[i].map, (uint8_t)(i * 16 + rd), 256);                  // context-specific, round-specific pattern
			drm_sfg1_cmd cmds[4] = {DC::h2d(c[i].bo, 0, 0, 256), DC::h2d(c[i].bo, 0, 256, 256), DC::vec(DRM_SFG1_VEC_ADD8, 0, 256, 512, 64), DC::d2h(c[i].bo, 1024 + (uint64_t)(rd % 2) * 256, 512, 256)};
			uint64_t id; int r = c[i].submit(cmds, 4, &id);
			if (r == -EBUSY) {                                              // quota: drain the oldest then retry (documented client behaviour)
				for (auto &j : jobs) if (j.ctx == i) { uint32_t st; c[i].wait(j.id, &st); CHECK(st == F_OK, "job status %u", st); j.ctx = -1; break; }
				r = c[i].submit(cmds, 4, &id);
			}
			CHECK(r == 0, "submit ctx %d round %d: %d", i, rd, r); jobs.push_back({i, id});
			// results are verified after waiting: remember the expected output per (ctx, round parity)
			if (rd >= rounds - 2) { /* final rounds checked below */ }
			// finish this job before the next round overwrites the BO pattern (in-order per ctx)
			if (jobs.size() > (size_t)N * 3) { J j = jobs[jobs.size() - 1 - N * 3]; if (j.ctx >= 0) { uint32_t st; CHECK(c[j.ctx].wait(j.id, &st) == 0 && st == F_OK, "wait"); } }
		}
	for (auto &j : jobs) if (j.ctx >= 0) { uint32_t st = 99; int r = c[j.ctx].wait(j.id, &st); if (r != -ENOENT) CHECK(r == 0 && st == F_OK, "final wait r=%d st=%u", r, st); }
	// verify the last result of every context: ADD8 of the pattern with itself
	for (int i = 0; i < N; i++) {
		uint8_t p = (uint8_t)(i * 16 + rounds - 1), want = (uint8_t)(p + p); uint64_t off = 1024 + (uint64_t)((rounds - 1) % 2) * 256;
		bool ok = true; for (int b = 0; b < 256; b++) ok &= c[i].map[off + b] == want;
		CHECK(ok, "ctx %d: result corrupted (isolation / ordering)", i);
		auto st = c[i].stats(); CHECK(st.jobs_ok == (uint64_t)rounds && st.jobs_error == 0 && st.jobs_timeout == 0, "ctx %d stats ok=%llu err=%llu", i, (unsigned long long)st.jobs_ok, (unsigned long long)st.jobs_error);
	}
	s.run_until([&] { return !(R32(s, R_STATUS) & ST_BUSY); }, 100000);
	CHECK(ksim_sq_free() == ksim_sq_entries() - 1, "SQ credits leaked: %u of %u", ksim_sq_free(), ksim_sq_entries() - 1);
	CHECK(R32(s, R_SQ_HEAD) == R32(s, R_SQ_TAIL), "ring not drained");
	CHECK(R32(s, R_DONE) >= (uint32_t)(rounds * N * 4), "device retired %u commands", R32(s, R_DONE));
	CHECK(R32(s, R_DONE) > 3u * ksim_sq_entries(), "the run did not wrap the ring (%u cmds, %u entries)", R32(s, R_DONE), ksim_sq_entries());
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	for (auto &x : c) x.close();
	return g_tr->fails == 0;
}

// ----------------------------------------------------------------------------------- UAPI validation (rejected before the device)
static bool t_drv_validation(SfgSys &s)
{
	Ksim k(s, 100.0, small_timeouts); CHECK(k.probe_rc == 0, "probe");
	DC a; CHECK(a.open(8192) == 0, "open"); const uint64_t W = a.win;
	uint64_t rr0 = s.rd_reqs, wr0 = s.wr_acc, id; auto st0 = a.stats();
	struct T { const char *n; std::vector<drm_sfg1_cmd> c; int want; uint32_t stride; };
	auto mk = [&](drm_sfg1_cmd c, const std::function<void(drm_sfg1_cmd &)> &f) { f(c); return c; };
	std::vector<T> t;
	t.push_back({"unknown opcode 4", {mk(DC::nop(), [](drm_sfg1_cmd &c) { c.op = 4; })}, -EINVAL, 64});
	t.push_back({"SCRUB from userspace", {mk(DC::nop(), [](drm_sfg1_cmd &c) { c.op = 6; })}, -EINVAL, 64});
	t.push_back({"NOP with a field", {mk(DC::nop(), [](drm_sfg1_cmd &c) { c.len = 4; })}, -EINVAL, 64});
	t.push_back({"reserved set", {mk(DC::nop(), [](drm_sfg1_cmd &c) { c.reserved = 1; })}, -EINVAL, 64});
	t.push_back({"H2D bad handle 0", {DC::h2d(0, 0, 0, 64)}, -ENOENT, 64});
	t.push_back({"H2D foreign handle 77", {DC::h2d(77, 0, 0, 64)}, -ENOENT, 64});
	t.push_back({"H2D len 0", {DC::h2d(a.bo, 0, 0, 0)}, -EINVAL, 64});
	t.push_back({"H2D len unaligned", {DC::h2d(a.bo, 0, 0, 6)}, -EINVAL, 64});
	t.push_back({"H2D bo_offset unaligned", {DC::h2d(a.bo, 2, 0, 64)}, -EINVAL, 64});
	t.push_back({"H2D dev unaligned", {DC::h2d(a.bo, 0, 2, 64)}, -EINVAL, 64});
	t.push_back({"H2D past the BO", {DC::h2d(a.bo, a.size - 32, 0, 64)}, -EINVAL, 64});
	t.push_back({"H2D BO offset+len overflows", {DC::h2d(a.bo, ~0ull - 3, 0, 64)}, -EINVAL, 64});
	t.push_back({"H2D past the device window", {DC::h2d(a.bo, 0, W - 32, 64)}, -EINVAL, 64});
	t.push_back({"H2D dev+len overflows", {DC::h2d(a.bo, 0, ~0ull - 7, 64)}, -EINVAL, 64});
	t.push_back({"D2H len > window", {DC::d2h(a.bo, 0, 0, W + 4)}, -EINVAL, 64});
	t.push_back({"VEC exec_op 8", {DC::vec(8, 0, 0, 0, 4)}, -EINVAL, 64});
	t.push_back({"VEC len*4 overflows", {DC::vec(0, 0, 0, 0, 1ull << 62)}, -EINVAL, 64});
	t.push_back({"VEC RELU with dev_b", {DC::vec(3, 0, 16, 32, 4)}, -EINVAL, 64});
	t.push_back({"VEC operand outside window", {DC::vec(0, 0, 16, W, 4)}, -EINVAL, 64});
	t.push_back({"VEC len 0", {DC::vec(0, 0, 16, 32, 0)}, -EINVAL, 64});
	t.push_back({"TEN flags bit1", {mk(DC::nop(), [](drm_sfg1_cmd &c) { c.op = 3; c.len = 1; c.flags = 2; c.dev_b = 16; c.dev_c = 32; })}, -EINVAL, 64});
	t.push_back({"TEN C outside window", {mk(DC::nop(), [&](drm_sfg1_cmd &c) { c.op = 3; c.len = 1; c.dev_c = W - 8; })}, -EINVAL, 64});
	t.push_back({"stride < 64", {DC::nop()}, -EINVAL, 32});
	t.push_back({"stride not multiple of 8", {DC::nop()}, -EINVAL, 68});
	t.push_back({"stride 8192", {DC::nop()}, -EINVAL, 8192});
	for (auto &x : t) {
		std::vector<uint8_t> raw(std::max<size_t>(x.stride, 64) * x.c.size() + 64, 0); for (size_t i = 0; i < x.c.size(); i++) memcpy(&raw[i * x.stride], &x.c[i], 64);
		drm_sfg1_submit sb = {}; sb.cmds_ptr = (uintptr_t)raw.data(); sb.cmd_count = (uint32_t)x.c.size(); sb.cmd_stride = x.stride;
		int r = ksim_ioctl(a.fd, DRM_IOCTL_SFG1_SUBMIT, &sb); CHECK(r == x.want, "%s: %d want %d", x.n, r, x.want);
	}
	{ drm_sfg1_cmd c = DC::nop(); drm_sfg1_submit sb = {}; sb.cmds_ptr = (uintptr_t)&c; sb.cmd_stride = 64;
	  sb.cmd_count = 0; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_SFG1_SUBMIT, &sb) == -EINVAL, "cmd_count 0");
	  sb.cmd_count = 64; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_SFG1_SUBMIT, &sb) == -EINVAL, "cmd_count 64 > max");
	  sb.cmd_count = 1; sb.flags = 1; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_SFG1_SUBMIT, &sb) == -EINVAL, "flags"); sb.flags = 0; sb.pad = 1; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_SFG1_SUBMIT, &sb) == -EINVAL, "pad"); sb.pad = 0; sb.reserved = 1; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_SFG1_SUBMIT, &sb) == -EINVAL, "reserved"); sb.reserved = 0;
	  sb.cmds_ptr = 0; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_SFG1_SUBMIT, &sb) == -EFAULT, "NULL cmds_ptr"); }
	{ std::vector<uint8_t> raw(144, 0); drm_sfg1_cmd n = DC::nop(); memcpy(&raw[0], &n, 64); raw[64 + 8] = 1;   // a "newer userspace" tail in command #2
	  drm_sfg1_submit sb = {}; sb.cmds_ptr = (uintptr_t)raw.data(); sb.cmd_count = 2; sb.cmd_stride = 72; memcpy(&raw[72], &n, 64);
	  raw[72 + 64] = 1; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_SFG1_SUBMIT, &sb) == -E2BIG, "non-zero tail beyond the known command size -> E2BIG"); }
	// a whole batch is rejected if ANY command is bad, and nothing reaches the device
	{ drm_sfg1_cmd c[3] = {DC::nop(), DC::nop(), DC::h2d(a.bo, 0, 0, 6)}; CHECK(a.submit(c, 3, &id) == -EINVAL, "batch with one bad command"); }
	CHECK(s.rd_reqs == rr0 && s.wr_acc == wr0, "rejected submits touched the device (%llu reads, %llu writes)", (unsigned long long)(s.rd_reqs - rr0), (unsigned long long)(s.wr_acc - wr0));
	auto st1 = a.stats(); CHECK(st1.jobs_submitted == st0.jobs_submitted && st1.cmds_submitted == st0.cmds_submitted, "rejected submits were counted");
	// BO_CREATE
	{ drm_sfg1_bo_create b = {}; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_SFG1_BO_CREATE, &b) == -EINVAL, "BO size 0");
	  b.size = 1ull << 40; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_SFG1_BO_CREATE, &b) == -EINVAL, "BO too big");
	  b.size = 4096; b.flags = 1; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_SFG1_BO_CREATE, &b) == -EINVAL, "BO flags"); b.flags = 0; b.reserved = 1; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_SFG1_BO_CREATE, &b) == -EINVAL, "BO reserved"); }
	{ int n = 0, r = 0; for (; n < 200 && !r; n++) { drm_sfg1_bo_create b = {}; b.size = 4096; r = ksim_ioctl(a.fd, DRM_IOCTL_SFG1_BO_CREATE, &b); } CHECK(r == -ENOSPC && n > 8, "BO quota: stopped after %d creates with %d", n, r); }
	// WAIT_JOB semantics
	{ uint32_t st; CHECK(a.wait(12345, &st) == -ENOENT, "unknown job id");
	  drm_sfg1_cmd c = DC::nop(); CHECK(a.submit(&c, 1, &id) == 0, "submit nop"); CHECK(a.wait(id, &st) == 0 && st == F_OK, "wait");
	  CHECK(a.wait(id, &st) == -ENOENT, "second wait of the same job must be ENOENT");
	  CHECK(a.submit(&c, 1, &id) == 0, "submit"); int r = a.wait(id, &st, nullptr, 0); CHECK(r == -EBUSY || (r == 0 && st == F_OK), "poll of a fresh job: %d", r); if (r == -EBUSY) CHECK(a.wait(id, &st) == 0, "job lost after a poll"); }
	// dma-buf export is refused
	{ drm_prime_handle ph = {}; ph.handle = a.bo; CHECK(ksim_ioctl(a.fd, DRM_IOCTL_PRIME_HANDLE_TO_FD, &ph) == -EPERM, "prime export must be EPERM"); }
	CHECK(ksim_ioctl(a.fd, 0x12345678, nullptr) == -ENOTTY, "unknown ioctl");
	a.close();
	return g_tr->fails == 0;
}

// ----------------------------------------------------------------------------------- device-side checks through the real ring (patched-driver scenario)
static void many_strikes(ksim_cfg &c) { small_timeouts(c); c.strike_limit = 1000; }   // this test makes ~9 deliberate device errors on ONE context
static bool t_drv_device_checks(SfgSys &s)
{
	Ksim k(s, 100.0, many_strikes); CHECK(k.probe_rc == 0, "probe");
	DC a; CHECK(a.open(8192) == 0, "open");
	const uint64_t W = a.win; const uint32_t ctx = ksim_ctx_id(a.fd); uint64_t bus = ksim_bo_bus(a.fd, a.bo);
	sfg1m_dev md{(uint32_t)s.max_ctx, (uint32_t)W, nullptr};
	struct Case { const char *n; sfg1m_sqe e; };
	auto E = [&](uint16_t op) { sfg1m_sqe e; memset(&e, 0, sizeof e); e.opcode = op; e.ctx_id = (uint16_t)ctx; return e; };
	std::vector<Case> cs;
	{ auto e = E(1); e.host_addr = bus; e.len = 64; e.dev_a = W - 32; cs.push_back({"H2D past the window", e}); }
	{ auto e = E(2); e.exec_op = 0; e.len = 4; e.dev_a = 0; e.dev_b = 16; e.dev_c = W; cs.push_back({"VEC C outside the window", e}); }
	{ auto e = E(0); e.ctx_id = (uint16_t)s.max_ctx; cs.push_back({"ctx == MAX_CTX", e}); }
	{ auto e = E(0); e.rsvd1 = 7; cs.push_back({"reserved field set", e}); }
	{ auto e = E(9); cs.push_back({"opcode 9", e}); }
	{ auto e = E(1); e.host_addr = 0x500; e.len = 64; cs.push_back({"H2D from unmapped host memory", e}); }
	{ auto e = E(1); e.host_addr = ~0ull - 15; e.len = 64; cs.push_back({"H2D host range wraps", e}); }
	{ auto e = E(3); e.flags = 2; e.len = 1; cs.push_back({"TEN flags bit 1", e}); }
	{ auto e = E(0); e.flags = 1; cs.push_back({"NOP with flags", e}); }
	uint64_t eres0 = ksim_engine_resets();
	for (auto &c : cs) {
		uint8_t want = sfg1m_check(&md, &c.e);
		sfg1m_sqe tmp = c.e; sfg1m_host h{[](void *, uint64_t a2, void *, uint64_t) { return a2 < 0x1000 ? 1 : 0; }, nullptr, nullptr};
		if (want == 0 || want == SFG1M_ST_DMA_ERROR) { /* DMA outcomes depend on host memory: modelled below */ }
		if (c.e.opcode == 1 && want == 0) want = SFG1M_ST_DMA_ERROR;                  // unmapped host
		(void)tmp; (void)h;
		uint64_t id; int r = ksim_raw_submit(a.fd, &c.e, 1, &id); CHECK(r == 0, "%s: raw submit %d", c.n, r);
		uint32_t st = 99, de = 0; r = a.wait(id, &st, &de);
		CHECK(r == 0 && st == F_ERR && de == want, "%s: job status %u dev_error %u want ERROR/%u", c.n, st, de, want);
		CHECK(ksim_engine_resets() == ++eres0, "%s: recovery must perform exactly one engine reset (have %llu)", c.n, (unsigned long long)ksim_engine_resets());
		CHECK(R32(s, R_STATUS) & ST_READY, "%s: device not ready after recovery", c.n);
		CHECK(!(R32(s, R_STATUS) & ST_HALTED), "%s: device left halted", c.n);
		// the context is still usable (a protocol-conforming error is a strike, not a ban) and the device works
		drm_sfg1_cmd n = DC::nop(); if (a.run(&n, 1) != 0) { CHECK(false, "%s: next job failed", c.n); break; }
	}
	CHECK(ksim_log_count("recovering") >= (int)cs.size(), "recovery log lines: %d", ksim_log_count("recovering"));
	CHECK(a.stats().jobs_error == cs.size(), "jobs_error %llu want %zu", (unsigned long long)a.stats().jobs_error, cs.size());
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	a.close();
	return g_tr->fails == 0;
}

// ----------------------------------------------------------------------------------- DMA fault through the normal path
static bool t_drv_faults(SfgSys &s)
{
	Ksim k(s, 100.0, small_timeouts); CHECK(k.probe_rc == 0, "probe");
	DC a, b; CHECK(a.open(8192) == 0 && b.open(8192) == 0, "open");
	for (int i = 0; i < 256; i++) a.map[i] = (uint8_t)i;
	uint64_t bus = ksim_bo_bus(a.fd, a.bo);
	s.hm.hole(bus, 4096);                                              // the host loses the page under a DMA: an IOMMU-style fault
	drm_sfg1_cmd c[2] = {DC::h2d(a.bo, 0, 0, 256), DC::nop()}; uint32_t de = 0;
	int r = a.run(c, 2, &de);
	CHECK(r == -(1000 + F_ERR) && de == SFG1M_ST_DMA_ERROR, "faulting job: %d dev_error %u (want ERROR / DMA_ERROR)", r, de);
	CHECK(a.stats().jobs_error == 1, "error not accounted");
	s.hm.clear_holes();
	// recovery: the device works again, for both contexts, and the error was not replayed
	for (int i = 0; i < 256; i++) a.map[i] = (uint8_t)(255 - i);
	drm_sfg1_cmd good[3] = {DC::h2d(a.bo, 0, 0, 256), DC::vec(DRM_SFG1_VEC_ADD8, 0, 0, 256, 64), DC::d2h(a.bo, 512, 256, 256)};
	CHECK(a.run(good, 3) == 0, "job after recovery");
	bool ok = true; for (int i = 0; i < 256; i++) ok &= a.map[512 + i] == (uint8_t)(2 * (255 - i)); CHECK(ok, "result after recovery wrong");
	drm_sfg1_cmd n = DC::nop(); CHECK(b.run(&n, 1) == 0, "bystander context after another context's fault");
	CHECK(b.stats().jobs_error == 0 && b.stats().jobs_canceled == 0, "bystander accounting disturbed");
	CHECK(ksim_engine_resets() == 1, "engine resets %llu", (unsigned long long)ksim_engine_resets());
	// a faulting D2H: host memory must not be written
	std::vector<uint8_t> keep(a.map + 1024, a.map + 1024 + 256);
	s.hm.hole(bus + 1024, 256);
	drm_sfg1_cmd d[1] = {DC::d2h(a.bo, 1024, 0, 256)}; r = a.run(d, 1, &de);
	CHECK(r == -(1000 + F_ERR) && de == SFG1M_ST_DMA_ERROR, "faulting D2H: %d/%u", r, de);
	s.hm.clear_holes(); CHECK(memcmp(keep.data(), a.map + 1024, 256) == 0, "faulting D2H modified host memory");
	CHECK(a.run(&n, 1) == 0, "job after the D2H fault");
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	a.close(); b.close();
	return g_tr->fails == 0;
}

// ----------------------------------------------------------------------------------- hang -> timeout -> reset -> strikes -> ban
static bool t_drv_timeout(SfgSys &s)
{
	Ksim k(s, 100.0, small_timeouts); CHECK(k.probe_rc == 0, "probe");
	DC a, b, c; CHECK(a.open(4096) == 0 && b.open(4096) == 0 && c.open(4096) == 0, "open");
	drm_sfg1_cmd h2d1 = DC::h2d(a.bo, 0, 0, 256); drm_sfg1_cmd nop = DC::nop();
	for (int strike = 1; strike <= 3; strike++) {
		uint64_t ia, ib; uint32_t sa = 99, sb = 99;
		s.hang_reads = true;                                                    // the host stops answering device reads
		CHECK(a.submit(&h2d1, 1, &ia) == 0, "strike %d: submit hung job", strike);
		CHECK(b.submit(&nop, 1, &ib) == 0, "strike %d: submit innocent job behind it", strike);
		uint64_t t0 = s.cycle;
		CHECK(a.wait(ia, &sa) == 0, "wait A"); CHECK(b.wait(ib, &sb) == 0, "wait B");
		double ms = (double)(s.cycle - t0) / 100e3;                              // 100 MHz
		CHECK(sa == F_TO, "strike %d: hung job status %u (want TIMEOUT)", strike, sa);
		CHECK(sb == F_CANCEL, "strike %d: innocent queued job status %u (want CANCELED, never replayed)", strike, sb);
		CHECK(ms >= 9.0 && ms < 60.0, "strike %d: timeout fired after %.2f ms (configured 10 ms)", strike, ms);
		s.hang_reads = false;
		CHECK(ksim_engine_resets() == (uint64_t)strike, "engine resets %llu", (unsigned long long)ksim_engine_resets());
		CHECK(R32(s, R_STATUS) & ST_READY, "device not ready after recovery");
		CHECK(b.run(&nop, 1) == 0, "strike %d: bystander usable after recovery", strike);
		if (strike < 3) CHECK(a.run(&nop, 1) == 0, "context with %d strike(s) must still work", strike);
	}
	CHECK(ksim_ctx_flags(a.fd) & 1, "context not banned after 3 strikes");
	uint64_t id; int r = a.submit(&nop, 1, &id); CHECK(r == -ECANCELED, "submit on a banned context: %d (want ECANCELED)", r);
	CHECK(b.run(&nop, 1) == 0 && c.run(&nop, 1) == 0, "other contexts affected by A's ban");
	CHECK(a.stats().jobs_timeout == 3, "timeouts accounted: %llu", (unsigned long long)a.stats().jobs_timeout);
	a.close(); DC n; CHECK(n.open(4096) == 0, "a new context must still be openable"); drm_sfg1_cmd z = DC::nop(); CHECK(n.run(&z, 1) == 0, "new context works"); n.close();
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	b.close(); c.close();
	return g_tr->fails == 0;
}

// ----------------------------------------------------------------------------------- lost interrupt: no reset, no strike
static bool t_drv_lost_irq(SfgSys &s)
{
	Ksim k(s, 100.0, small_timeouts); CHECK(k.probe_rc == 0, "probe");
	DC a; CHECK(a.open(4096) == 0, "open");
	for (int i = 0; i < 64; i++) a.map[i] = (uint8_t)(i + 1);
	drm_sfg1_cmd c[3] = {DC::h2d(a.bo, 0, 0, 64), DC::vec(DRM_SFG1_VEC_ADD8, 0, 0, 64, 16), DC::d2h(a.bo, 128, 64, 64)};
	s.irq_dispatch = false;                                                      // every interrupt message is lost
	uint64_t ir0 = s.irq_msgs; int r = a.run(c, 3);
	s.irq_dispatch = true;
	CHECK(s.irq_msgs > ir0, "the device did send messages (they were dropped by the test)");
	CHECK(r == 0, "job must still complete OK through the timeout path's final reap (%d)", r);
	CHECK(ksim_engine_resets() == 0, "a lost interrupt must not cause a reset");
	CHECK(ksim_ctx_flags(a.fd) == 0 && a.stats().jobs_timeout == 0, "a lost interrupt must not cost the context a strike");
	bool ok = true; for (int i = 0; i < 64; i++) ok &= a.map[128 + i] == (uint8_t)(2 * (i + 1)); CHECK(ok, "result wrong");
	a.close();
	return g_tr->fails == 0;
}

// ----------------------------------------------------------------------------------- engine reset cannot recover -> function reset, all contexts lost
static bool t_drv_func_reset(SfgSys &s)
{
	Ksim k(s, 100.0, small_timeouts); CHECK(k.probe_rc == 0, "probe");
	DC a, b; CHECK(a.open(4096) == 0 && b.open(4096) == 0, "open");
	drm_sfg1_cmd nop = DC::nop(); CHECK(a.run(&nop, 1) == 0, "baseline");
	// ---- (A) idle device: a rogue agent corrupts the queue configuration. The device raises FATAL (ENGINE_RESET cannot clear
	//      it). The driver sees a FATAL interrupt with no failing CQE = protocol fault, and recovers by itself (reset work).
	s.csr_write(R_CTRL, 0); s.csr_write(R_SQ_ENTRIES, 17); s.csr_write(R_CTRL, CTRL_ENABLE);
	CHECK(R32(s, R_STATUS) & ST_FATAL, "FATAL expected");
	CHECK(s.run_until([&] { ksim_pump(); return ksim_func_resets() == 1; }, 5000000), "driver never recovered an idle device from FATAL");
	CHECK(ksim_func_resets() == 1, "function reset must have been used (have %llu)", (unsigned long long)ksim_func_resets());
	CHECK(ksim_log_count("trying function reset") >= 1, "escalation (engine reset failed -> function reset) not logged");
	CHECK(ksim_log_count("protocol violation") >= 1, "protocol fault not classified");
	CHECK(ksim_dev_state() == 1, "device state %d (want RUNNING)", ksim_dev_state());
	CHECK(!(R32(s, R_STATUS) & ST_FATAL) && R32(s, R_CTRL) == 1 && R32(s, R_SQ_ENTRIES) == ksim_sq_entries(), "device not reprogrammed after the function reset");
	CHECK((ksim_ctx_flags(a.fd) & 2) && (ksim_ctx_flags(b.fd) & 2), "every context must be LOST after a function reset");
	uint64_t id; CHECK(a.submit(&nop, 1, &id) == -ECONNRESET, "submit on a lost context must be ECONNRESET");
	a.close(); b.close();
	DC n; CHECK(n.open(4096) == 0, "fresh context after function reset"); CHECK(n.run(&nop, 1) == 0, "fresh context works");
	// device memory after a function reset is undefined: the new owner must nevertheless see zeros (driver scrubs)
	drm_sfg1_cmd d[1] = {DC::d2h(n.bo, 0, 0, 1024)}; memset(n.map, 0xAB, 1024);
	CHECK(n.run(d, 1) == 0, "readback"); bool z = true; for (int i = 0; i < 1024; i++) z &= n.map[i] == 0; CHECK(z, "a new context observed stale window contents after a function reset");
	// ---- (B) a job in flight when the device is wedged: the guilty job completes (never replayed), the device recovers
	{
		s.hang_reads = true; uint32_t st = 99; uint64_t jid;
		CHECK(n.submit(&nop, 1, &jid) == 0, "submit"); s.idle(300);
		s.csr_write(R_CTRL, 0); s.csr_write(R_SQ_ENTRIES, 17); s.csr_write(R_CTRL, CTRL_ENABLE); s.hang_reads = false;   // FATAL while hung
		CHECK(n.wait(jid, &st) == 0, "wait"); CHECK(st == F_ERR || st == F_TO || st == F_CANCEL, "in-flight job status %u", st);
		CHECK(s.run_until([&] { ksim_pump(); return ksim_func_resets() >= 2; }, 5000000), "second recovery did not use a function reset");
		CHECK(ksim_dev_state() == 1 && !(R32(s, R_STATUS) & ST_FATAL), "device not recovered");
		CHECK(ksim_ctx_flags(n.fd) & 2, "context must be lost");
	}
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	n.close();
	return g_tr->fails == 0;
}

// ----------------------------------------------------------------------------------- scrub-on-reuse isolation between owners
static bool t_drv_isolation(SfgSys &s)
{
	Ksim k(s, 100.0, small_timeouts); CHECK(k.probe_rc == 0, "probe");
	const uint64_t W = s.win_bytes;
	for (int round = 0; round < 3; round++) {
		DC a; CHECK(a.open(W) == 0, "open A");
		unsigned slot = ksim_ctx_id(a.fd);
		for (uint64_t i = 0; i < W; i++) a.map[i] = (uint8_t)(0xC0 + round);       // a "secret" filling the whole window
		drm_sfg1_cmd up[1] = {DC::h2d(a.bo, 0, 0, W)}; CHECK(a.run(up, 1) == 0, "upload secret");
		a.close();                                                                   // driver must scrub the window at close
		DC b; CHECK(b.open(W) == 0, "open B"); CHECK(ksim_ctx_id(b.fd) == slot, "B did not get A's slot (%u vs %u)", ksim_ctx_id(b.fd), slot);
		memset(b.map, 0xFF, W); drm_sfg1_cmd down[1] = {DC::d2h(b.bo, 0, 0, W)}; CHECK(b.run(down, 1) == 0, "download");
		bool z = true; for (uint64_t i = 0; i < W; i++) z &= b.map[i] == 0; CHECK(z, "round %d: the new owner of slot %u read the previous owner's data", round, slot);
		b.close();
	}
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	return g_tr->fails == 0;
}

const std::vector<TestEntry> &all_tests_driver()
{
	static const std::vector<TestEntry> v = {
		{"drv_probe", t_drv_probe, "REAL sfg1_hw_discover/rings/start over the RTL; device left as the driver intends"},
		{"drv_examples", t_drv_examples, "the driver package's UNMODIFIED examples ex1/ex2/ex3/ex5 against the RTL"},
		{"drv_kernels", t_drv_kernels, "runtime E2E: 6 VEC ops, RELU, DOT, 5 matmul shapes, 2-layer MLP vs CPU; phase-split timing"},
		{"drv_concurrent", t_drv_concurrent, "all hardware contexts concurrently, many ring laps, credit accounting, isolation"},
		{"drv_validation", t_drv_validation, "~45 UAPI validation cases: rejected before the device, no side effects"},
		{"drv_devchecks", t_drv_device_checks, "raw bad descriptors through the real ring: device-side status + one engine reset each"},
		{"drv_faults", t_drv_faults, "DMA fault -> ERROR/DMA_ERROR, recovery, bystander unaffected; faulting D2H writes nothing"},
		{"drv_timeout", t_drv_timeout, "hang -> TIMEOUT + CANCELED -> ENGINE_RESET -> 3 strikes -> ban; others unaffected"},
		{"drv_lostirq", t_drv_lost_irq, "lost interrupts: job completes via the final reap; no reset, no strike"},
		{"drv_funcreset", t_drv_func_reset, "FATAL -> engine reset cannot recover -> FUNCTION reset -> all contexts LOST; fresh ctx sees zeros"},
		{"drv_isolation", t_drv_isolation, "scrub-on-close/open: a new owner never sees the previous owner's window"},
	};
	return v;
}

// ----------------------------------------------------------------------------------- annotated end-to-end demonstration
// Not part of the default suite (it prints a narrative): `sim demo`. One kernel, from the runtime call to the verified result,
// with every bus-level event the device and the host exchanged, decoded.
static const char *csr_name(uint16_t o)
{
	switch (o) {
	case 0x020: return "CTRL"; case 0x024: return "STATUS"; case 0x030: return "IRQ_STATUS (W1C)"; case 0x034: return "IRQ_MASK";
	case 0x04c: return "SQ_TAIL  <-- doorbell"; case 0x05c: return "CQ_HEAD  <-- credit return"; case 0x060: return "SQ_HEAD"; case 0x064: return "CQ_TAIL";
	case 0x068: return "DONE_COUNT"; case 0x06c: return "ERR_COUNT"; default: return "(register)";
	}
}
static const char *op_name(unsigned o)
{
	switch (o) { case SFG1M_OP_NOP: return "NOP"; case SFG1M_OP_DMA_H2D: return "DMA_H2D"; case SFG1M_OP_VEC: return "VEC"; case SFG1M_OP_TEN: return "TEN";
	             case SFG1M_OP_DMA_D2H: return "DMA_D2H"; case SFG1M_OP_SCRUB: return "SCRUB"; default: return "?"; }
}
static bool t_demo(SfgSys &s)
{
	Ksim k(s, 100.0, small_timeouts); CHECK(k.probe_rc == 0, "probe");
	int rc; sfg1rt *rt = sfg1rt_create(16384, &rc); CHECK(rt != nullptr, "runtime open %d", rc); if (!rt) return false;
	sfg1rt_set_clock(rt, sim_clock, &s);
	const uint64_t sqb = R32(s, R_SQ_BASE_LO) | ((uint64_t)R32(s, R_SQ_BASE_HI) << 32), cqb = R32(s, R_CQ_BASE_LO) | ((uint64_t)R32(s, R_CQ_BASE_HI) << 32);
	const uint32_t sqn = R32(s, R_SQ_ENTRIES), cqn = R32(s, R_CQ_ENTRIES);
	const size_t n = 64; int8_t a[n], b[n], c[n], ref[n];
	for (size_t i = 0; i < n; i++) { a[i] = (int8_t)(3 * (int)i - 90); b[i] = (int8_t)(100 - 5 * (int)i); ref[i] = (int8_t)(a[i] + b[i]); }
	printf("\n=== SF-G1 end-to-end path: host kernel submission -> device -> verified output ===\n");
	printf("device: SQ %u x 64 B at host 0x%llx, CQ %u x 16 B at 0x%llx (programmed by the REAL sfg1_hw.c probe)\n", sqn, (unsigned long long)sqb, cqn, (unsigned long long)cqb);
	printf("kernel: c[i] = a[i] + b[i] (INT8 lane-wise ADD8, wrapping), %zu lanes, a[0..3]=%d,%d,%d,%d b[0..3]=%d,%d,%d,%d\n\n", n, a[0], a[1], a[2], a[3], b[0], b[1], b[2], b[3]);
	struct Ev { uint64_t cyc; std::string kind; uint64_t x, y; }; std::vector<Ev> ev;
	const uint64_t c0 = s.cycle;
	s.trace = [&](const char *kd, uint64_t x, uint64_t y) { ev.push_back({s.cycle - c0, kd, x, y}); };
	rc = sfg1rt_vec_i8(rt, DRM_SFG1_VEC_ADD8, a, b, c, n);
	s.trace = nullptr;
	CHECK(rc == 0, "sfg1rt_vec_i8 rc %d", rc);
	printf("step 1  host  sfg1rt_vec_i8(ADD8) -> DRM_IOCTL_SFG1_SUBMIT -> job {H2D a, H2D b, VEC, D2H c} -> real sfg1_ring.c writes 4 SQ entries (slots 1-4; slot 0 was the context-open scrub) into host memory, then rings the doorbell (tail 1 -> 5)\n");
	printf("step 2  device fetches each SQ entry (burst read), decodes + checks it (sfg1_cmdchk), runs it, writes a 16-byte CQE (dw0,dw1,dw2, then dw3 = {status,phase,cid} LAST), then raises the interrupt\n");
	printf("step 3  host  ISR: read IRQ_STATUS, write-1-clear exactly those bits, then drain the CQ by phase tag, return credit (CQ_HEAD)\n\n");
	printf("  cycle  who     event\n");
	int dma_rd = 0, dma_wr = 0; uint64_t dma_rd_first = 0, dma_wr_first = 0, dma_rd_cyc = 0, dma_wr_cyc = 0;
	auto flush = [&](uint64_t) {
		if (dma_rd) { printf("  %5llu  device  DMA read burst(s) from host memory starting 0x%llx  (H2D payload for the command above)\n", (unsigned long long)dma_rd_cyc, (unsigned long long)dma_rd_first); dma_rd = 0; }
		if (dma_wr) { printf("  %5llu  device  DMA writes %d words to host memory starting 0x%llx  (D2H result c, for the command above)\n", (unsigned long long)dma_wr_cyc, dma_wr, (unsigned long long)dma_wr_first); dma_wr = 0; }
	};
	for (auto &e : ev) {
		bool in_sq = e.kind == "MRD" && e.x >= sqb && e.x < sqb + (uint64_t)sqn * 64, in_cq = e.kind == "MWR" && e.x >= cqb && e.x < cqb + (uint64_t)cqn * 16;
		if (e.kind == "MRD" && !in_sq) { if (!dma_rd) { dma_rd_first = e.x; dma_rd_cyc = e.cyc; } dma_rd++; continue; }
		if (e.kind == "MWR" && !in_cq) { if (!dma_wr) { dma_wr_first = e.x; dma_wr_cyc = e.cyc; } dma_wr++; continue; }
		flush(e.cyc);
		if (e.kind == "CSRW") printf("  %5llu  host    BAR0 write  %-28s <- 0x%x\n", (unsigned long long)e.cyc, csr_name((uint16_t)e.x), (unsigned)e.y);
		else if (e.kind == "CSRR") printf("  %5llu  host    BAR0 read   %-28s  = 0x%x\n", (unsigned long long)e.cyc, csr_name((uint16_t)e.x), (unsigned)e.y);
		else if (in_sq) {
			const sfg1m_sqe *q = (const sfg1m_sqe *)&s.hm.d[e.x];
			printf("  %5llu  device  fetches SQ slot %llu (%llu beats): %s%s ctx=%u host=0x%llx len=%llu\n", (unsigned long long)e.cyc, (unsigned long long)((e.x - sqb) / 64), (unsigned long long)e.y,
			       op_name(q->opcode), q->opcode == SFG1M_OP_VEC ? " ADD8" : "", q->ctx_id, (unsigned long long)q->host_addr, (unsigned long long)q->len);
		} else if (in_cq) printf("  %5llu  device  writes CQE slot %llu dw%llu = 0x%08x%s\n", (unsigned long long)e.cyc, (unsigned long long)((e.x - cqb) / 16), (unsigned long long)((e.x - cqb) % 16 / 4), (unsigned)e.y,
		                         ((e.x - cqb) % 16 == 12) ? ("   <- dw3: status " + std::to_string((e.y >> 17) & 0x7f) + ", phase " + std::to_string((e.y >> 16) & 1) + " (published last)").c_str() : "");
		else if (e.kind == "MSI") printf("  %5llu  device  interrupt message (after the last CQE dword was accepted)\n", (unsigned long long)e.cyc);
	}
	flush(s.cycle - c0);
	bool same = memcmp(c, ref, n) == 0;
	printf("\nstep 4  host  runtime returns; compares the device output with a CPU reference over %zu lanes: %s\n", n, same ? "IDENTICAL" : "DIFFERENT");
	printf("        c[0..3] = %d,%d,%d,%d   reference = %d,%d,%d,%d   total %llu cycles (simulated; 100 MHz assumed only for the runtime's clock)\n",
	       c[0], c[1], c[2], c[3], ref[0], ref[1], ref[2], ref[3], (unsigned long long)(s.cycle - c0));
	printf("        protocol checker (P1-P14) mask = %04x   driver error log lines = %d\n\n", s.chk_mask(), ksim_log_count("err:"));
	CHECK(same, "device output differs from the CPU reference");
	CHECK(s.chk_mask() == 0, "protocol checker mask %04x", s.chk_mask());
	CHECK(ksim_log_count("err:") == 0, "driver logged errors");
	sfg1rt_destroy(rt);
	return g_tr->fails == 0;
}
const std::vector<TestEntry> &all_tests_demo()
{
	static const std::vector<TestEntry> v = {{"demo", t_demo, "annotated end-to-end trace: runtime call -> SQ -> device -> CQE -> interrupt -> verified output (run by name)"}};
	return v;
}
