#!/usr/bin/env python3
"""Performance study driver.  Builds the benches for each configuration, runs the workloads, collects every "PERF," line into benchmarks/results.csv.
Every figure comes from the core's hardware counters / completion records / the bench's cycle count: simulation cycles, no clock frequency is implied.
usage: benchmarks/run_bench.py [--quick]"""
import os, subprocess, sys, csv, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
rows = []
def sh(cmd, env=None):
    e = dict(os.environ); e.update(env or {})
    p = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=e)
    return p.stdout
def collect(out, cfg):
    for line in out.splitlines():
        if line.startswith("PERF,"):
            parts = line.split(",")[1:]
            d = {"config": cfg, "workload": parts[0]}
            for kv in parts[1:]:
                if "=" in kv: k, v = kv.split("=", 1); d[k] = v
            rows.append(d)
        elif line.startswith("PERF_ERROR"): print("!!", cfg, line)
def flat(name, params, only=None):
    sh(f"scripts/build_tb.sh {name} {params} MAX_LEN=1024", {"MAIN": "tests/tp_main.cpp", "EXE": "tp_main"})
    out = sh(f"build/{name}/tp_main" + (f" --only {only}" if only else ""))
    collect(out, f"{params}")
    print("flat", params, only or "all", flush=True)
for np_ in (2, 4, 8): flat(f"pf{np_}", f"NP={np_} IN_DEPTH=4 OUT_DEPTH=4")
if "--quick" not in sys.argv:
    for ind in (1, 2, 8):
        flat(f"pfi{ind}", f"NP=4 IN_DEPTH={ind} OUT_DEPTH=4", "jitter")
        flat(f"pfi{ind}", f"NP=4 IN_DEPTH={ind} OUT_DEPTH=4", "imbalance")
        flat(f"pfi{ind}", f"NP=4 IN_DEPTH={ind} OUT_DEPTH=4", "peak")
    for outd in (1, 2, 8):
        flat(f"pfo{outd}", f"NP=4 IN_DEPTH=4 OUT_DEPTH={outd}", "sink_rate")
        flat(f"pfo{outd}", f"NP=4 IN_DEPTH=4 OUT_DEPTH={outd}", "peak")
    for np_ in (2, 4, 8): flat(f"pff{np_}", f"NP={np_} FP32_EN=1 IN_DEPTH=4 OUT_DEPTH=4", "fp32_peak"); flat(f"pff{np_}", f"NP={np_} FP32_EN=1 IN_DEPTH=4 OUT_DEPTH=4", "fp32_len_sweep")
for fan, h in ((2, 1), (2, 2), (2, 3), (4, 2), (3, 2)):
    sh(f"scripts/build_tt.sh ptt{fan}{h} FAN={fan} H={h} MAX_LEN=1024")
    collect(sh(f"build/ptt{fan}{h}/tt_main --test perf"), f"tree FAN={fan} H={h}"); print("tree", fan, h, flush=True)
sh("scripts/build_tm.sh ptm")
mem = sh("build/ptm/tm_main --test perf")
for line in mem.splitlines():
    m = re.search(r"PERF len=(\d+) dma_in=(\d+) collective_with_memory=(\d+) dma_out=(\d+)", line)
    if m: rows.append({"config": "memory system", "workload": "mem_flow", "len": m.group(1), "dma_in": m.group(2), "collective_with_memory": m.group(3), "dma_out": m.group(4)})
keys = sorted({k for r in rows for k in r}, key=lambda k: (k not in ("config", "workload"), k))
os.makedirs("benchmarks", exist_ok=True)
with open("benchmarks/results.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rows)
print(len(rows), "rows -> benchmarks/results.csv")
