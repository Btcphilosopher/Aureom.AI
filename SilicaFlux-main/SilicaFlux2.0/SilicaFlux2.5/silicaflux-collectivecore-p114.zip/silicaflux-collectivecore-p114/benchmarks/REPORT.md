# Performance report — SilicaFlux CollectiveCore (Project 114)

**Evidence level: RTL simulation (Verilator 5.020).  Every figure below was read from the core's own hardware counters (`sf_collective_perf`), from completion records or from the bench's cycle count and copied by `benchmarks/make_report.py` from `benchmarks/results.csv` (raw data).  Units are clock CYCLES: no clock frequency, no Gbit/s, no area, no power is implied, and the FP32 / memory results inherit the vendored blocks' evidence level.**

Terms: *active cycle* = a cycle in which a collective was running; *element* = one 32-bit value; *beat* = one element on a stream; *bytes* = 4 × beats; *effective throughput* = bytes delivered to receivers ÷ wall cycles of the whole run (collective gaps included); *compute utilisation* = elements reduced ÷ active cycles, against the datapath peak of **one element per cycle** (the reduction tree retires one element position per cycle whatever the participant count); *starve share* = share of active cycles with an element still owed by a participant (input / network stall); *out-stall share* = share with a result blocked at the output; *imbalance* = largest difference, in elements, between the most and the least advanced sending participant.

## 1. Peak throughput (8 back-to-back all-reduce SUM, 256 elements, nobody stalls)

| participants | active cycles | elements / active cycle | elements / wall cycle | bytes in | bytes out | effective B/cycle | mean latency | input occupancy mean / max |
|---|---|---|---|---|---|---|---|---|
| 2 | 2088 | 0.9808 | 0.9702 | 16384 | 16384 | 7.76 | 262.0 | 1.96 / 2 |
| 4 | 2088 | 0.9808 | 0.9702 | 32768 | 32768 | 15.52 | 262.0 | 3.92 / 4 |
| 8 | 2088 | 0.9808 | 0.9702 | 65536 | 65536 | 31.05 | 262.0 | 7.85 / 8 |

**Reading.** The reduction datapath retires 1 element per cycle regardless of NP; what grows with NP is the data moved: effective throughput scales with the number of receivers (4 B × NP per cycle at peak). The ~2 % below 1.0 is the fixed per-collective overhead (§2).

## 2. Reduction latency vs vector length (one all-reduce, empty pipeline)

Latency = cycles from the command being taken to the completion record being pushed (`cpl_cycles`).

| elements | NP=2 INT | NP=8 INT | NP=2 FP32 | NP=4 FP32 | NP=8 FP32 |
|---|---|---|---|---|---|
| 1 | 7 | 7 | 12 | 17 | 22 |
| 2 | 8 | 8 | 13 | 18 | 23 |
| 4 | 10 | 10 | 15 | 20 | 25 |
| 8 | 14 | 14 | 19 | 24 | 29 |
| 16 | 22 | 22 | 27 | 32 | 37 |
| 64 | 70 | 70 | 75 | 80 | 85 |
| 256 | 262 | 262 | 267 | 272 | 277 |
| 1024 | 1030 | 1030 | 1035 | 1040 | 1045 |

**Reading.** Integer latency is **len + 6 cycles for every NP from 2 to 8** (command pop, input adapter, reduction register stage, output register, delivery, completion). FP32 adds one FMA pipeline (5 cycles) per tree level: 7 + 5·⌈log₂ NP⌉ for one element (12, 17, 22 measured for NP = 2, 4, 8), and then also streams at one element per cycle.

## 3. Buffer depths (4 participants, peak workload)

| input depth | output depth | elements / active cycle | starve share | out-stall share |
|---|---|---|---|---|
| 1 | 4 | 0.4961 | 0.4961 | 0.0000 |
| 2 | 4 | 0.9808 | 0.0038 | 0.0000 |
| 4 | 4 | 0.9808 | 0.0038 | 0.0000 |
| 8 | 4 | 0.9808 | 0.0038 | 0.0000 |
| 4 | 1 | 0.4961 | 0.0019 | 0.4942 |
| 4 | 2 | 0.9808 | 0.0038 | 0.0000 |
| 4 | 8 | 0.9808 | 0.0038 | 0.0000 |

**Finding.** A **1-deep buffer halves throughput** (0.496 elements/cycle): the vendored `sfd_fifo` cannot accept and release in the same cycle, so a depth-1 FIFO alternates fill / drain. Depth ≥ 2 restores full rate; deeper buffers add nothing at peak.

## 4. Slow consumer (4 participants, depths 4/4, 256 elements)

| consumer ready probability | elements / active cycle | effective B/cycle | out-stall share | output occupancy mean | input occupancy max | mean latency |
|---|---|---|---|---|---|---|
| 0.5 | 0.4410 | 7.01 | 0.536 | 7.66 | 16 | 582 |
| 0.25 | 0.2107 | 3.36 | 0.769 | 7.79 | 16 | 1216 |
| 0.1 | 0.0853 | 1.36 | 0.897 | 7.74 | 16 | 3004 |

**Reading.** Throughput follows the consumers (slightly below their rate: the fork waits for the slowest of the receivers on every element); the stall shows up as output stall and full buffers, not as lost data.

## 5. Network jitter on every participant (4 participants; each presents an element with the given probability per cycle)

| per-cycle presentation probability | input depth | elements / active cycle | starve share | input occupancy mean / max | imbalance max |
|---|---|---|---|---|---|
| 0.75 | 1 | 0.4389 | 0.554 | 2.09 / 4 | 1 |
| 0.5 | 1 | 0.3092 | 0.686 | 2.29 / 4 | 1 |
| 0.25 | 1 | 0.1592 | 0.838 | 2.44 / 4 | 1 |
| 0.75 | 2 | 0.5933 | 0.398 | 4.40 / 7 | 2 |
| 0.5 | 2 | 0.3765 | 0.618 | 4.52 / 7 | 2 |
| 0.25 | 2 | 0.1883 | 0.809 | 4.56 / 7 | 2 |
| 0.75 | 4 | 0.6900 | 0.299 | 8.09 / 13 | 4 |
| 0.5 | 4 | 0.4292 | 0.564 | 8.12 / 13 | 4 |
| 0.25 | 4 | 0.2060 | 0.791 | 8.47 / 13 | 4 |
| 0.75 | 8 | 0.7106 | 0.278 | 14.57 / 25 | 8 |
| 0.5 | 8 | 0.4541 | 0.539 | 14.56 / 25 | 8 |
| 0.25 | 8 | 0.2340 | 0.762 | 14.59 / 25 | 8 |

**Reading.** With independent random gaps the engine runs at the pace of the slowest participant *per element*; deeper input buffers recover part of that by letting fast participants run ahead (imbalance grows with the depth, bounded by it).

## 6. Persistent participant imbalance (one of 4 participants slower, depth 4)

| slow participant rate | elements / active cycle | starve share | imbalance max (elements) |
|---|---|---|---|
| 0.5 | 0.4933 | 0.499 | 4 |
| 0.25 | 0.2585 | 0.737 | 4 |
| 0.1 | 0.0975 | 0.901 | 4 |

**Reading.** A sustained imbalance caps throughput at the slow participant's rate, whatever the buffer depth (see the raw CSV for depths 1/2/8: identical); the imbalance the engine tolerates is bounded by the input buffer depth (backpressure on the fast ones).

## 7. A participant that starts late (4 participants, first collective only)

| delay (cycles) | elements / active cycle | starve share | mean latency |
|---|---|---|---|
| 50 | 0.9377 | 0.048 | 274 |
| 200 | 0.8245 | 0.163 | 312 |
| 800 | 0.5559 | 0.435 | 462 |

## 8. FP32 SUM (verified FMA tree)

| participants | elements / active cycle (256 elements) | mean latency (256 elements) | input occupancy mean |
|---|---|---|---|
| 2 | 0.9624 | 267 | 1.93 |
| 4 | 0.9446 | 272 | 3.78 |
| 8 | 0.9275 | 277 | 7.42 |

## 9. Tree topology (all-reduce SUM, every leaf sends and receives, nobody stalls)

| tree | leaves | nodes | elements | cycles to first result beat | cycles to last result beat | result elements / cycle |
|---|---|---|---|---|---|---|
| FAN 2, H 1 | 2 | 1 | 1 | 6 | 6 | 1.000 |
| FAN 2, H 1 | 2 | 1 | 16 | 6 | 21 | 1.000 |
| FAN 2, H 1 | 2 | 1 | 256 | 6 | 261 | 1.000 |
| FAN 2, H 2 | 4 | 3 | 1 | 13 | 13 | 1.000 |
| FAN 2, H 2 | 4 | 3 | 16 | 13 | 28 | 1.000 |
| FAN 2, H 2 | 4 | 3 | 256 | 13 | 268 | 1.000 |
| FAN 2, H 3 | 8 | 7 | 1 | 20 | 20 | 1.000 |
| FAN 2, H 3 | 8 | 7 | 16 | 20 | 35 | 1.000 |
| FAN 2, H 3 | 8 | 7 | 256 | 20 | 275 | 1.000 |
| FAN 3, H 2 | 9 | 4 | 1 | 13 | 13 | 1.000 |
| FAN 3, H 2 | 9 | 4 | 16 | 13 | 28 | 1.000 |
| FAN 3, H 2 | 9 | 4 | 256 | 13 | 268 | 1.000 |
| FAN 4, H 2 | 16 | 5 | 1 | 13 | 13 | 1.000 |
| FAN 4, H 2 | 16 | 5 | 16 | 13 | 28 | 1.000 |
| FAN 4, H 2 | 16 | 5 | 256 | 13 | 268 | 1.000 |

**Reading.** The tree is cut-through: the first result reaches the leaves after **6 + 7·(H−1) cycles** (6, 13, 20 for H = 1, 2, 3 — each extra level adds an up hop and a down hop of ~3.5 cycles each), and from then on results stream at **one element per cycle** whatever the depth. The fan-in does not change the latency (FAN 2, 3, 4 at H = 2 are identical). The reduction of 16 leaves needs the same time as 4 when the tree is two levels deep, at the price of a 4-way node.

## 10. Memory-fed collective (StreamDMA + MemoryMatrix + adapters, 2 participants, 4-bank 128-bit matrix)

| elements | StreamDMA stage-in (both buffers) | collective incl. memory loads/stores | StreamDMA drain | collective elements / cycle |
|---|---|---|---|---|
| 64 | 114 cycles | 176 cycles | 114 cycles | 0.364 |
| 256 | 216 cycles | 656 cycles | 216 cycles | 0.390 |
| 1024 | 624 cycles | 2576 cycles | 624 cycles | 0.398 |

**Reading.** StreamDMA moves the buffers at ~13 B/cycle (its own measured regime, 128-bit datapath). The adapter-fed collective runs at ~0.4 elements/cycle, not 1.0: each adapter issues its element reads **and** its element writes through ONE MemoryMatrix master (one request per cycle, arbitrated), so a participant needs ≥ 2 request cycles per element, plus bank conflicts between the four masters. A second master per adapter (separate read and write ports) would lift this toward 1.0; it is not built.

## 11. What these numbers do not say

* Cycles, not seconds: no frequency exists (no timing closure, see `docs/10_SYNTHESIS.md`).
* Single-node figures use ideal sources/sinks unless stated; the random-gap workloads are synthetic models of network jitter, not measurements of a network.
* One collective runs at a time per node (documented limit): back-to-back collectives pay the ~3-cycle gap seen in elements/wall-cycle vs elements/active-cycle; there is no overlap between consecutive collectives.
* The tree latencies are for zero-latency links between nodes (the links are direct wires in the simulation top); a physical link adds its own latency per hop.

