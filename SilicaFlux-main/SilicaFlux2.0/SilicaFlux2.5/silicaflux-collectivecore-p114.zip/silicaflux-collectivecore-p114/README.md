# SilicaFlux CollectiveCore — Project 114

**Aureom.AI | SilicaFlux Cloud Semiconductor Systems** · primary RTL: `rtl/sf_collective_core.sv`

A synthesizable distributed compute-and-reduction engine for collectives over multiple SilicaFlux compute nodes or accelerator tiles:
`Collective Command Queue → Input Stream Controller → Operation Scheduler → Reduction Datapath → Output Stream Controller → Completion`, with local and remote participant adapters, a fixed **tree** topology, broadcast / all-reduce distribution, and an FP32 SUM built on the repository's verified FMA.

> **Status — read this first.**  RTL **simulation** (Verilator 5.020) against an independent software reference, **bounded formal** (Yosys SAT / Z3) plus exhaustive combinational proofs, mutation testing of both, and Yosys synthesis *estimates*.  **No FPGA, no silicon, no timing closure; no frequency, area or power is claimed; every performance figure is in cycles.**
> This is **not** a complete collective-communications library: one collective per node at a time, ≤ 8 participants per node, 32-bit elements, a tree topology only.  `RDMAEngine` does not exist in the repository and `PacketForge` is only a code name (docs/00).  Everything not implemented is listed in `docs/11_LIMITATIONS.md` and is not advertised by the core's `caps` output.
> Delivered as a ZIP.  **Nothing was committed to the repository.**

## Definition of done — met in simulation

> *Two simulated accelerator participants complete supported reductions and receive mathematically correct results with proper ordering, backpressure and failure reporting.*

* **Mathematically correct:** every result (INT32/UINT32 SUM MIN MAX AND OR XOR; FP32 SUM bit-exact against Berkeley SoftFloat) of 125,761 scored collectives matches the reference; the command validator and the reduction fold are proved over all inputs (`reports/formal.md`).
* **Ordering:** collectives never mix (IDs are serial numbers; future beats held, stale beats dropped); results leave in index order; completion records come in command order, and a collective completes only after every destination accepted every beat; over memory, the store engine's completion record — the one software must wait for — comes only after every write was acknowledged (checked at the instant the record appears).
* **Backpressure:** arbitrary ready/valid stalls on every port; an offered beat is never withdrawn (proved by BMC on the output port and monitored every cycle on the output streams of the flat, tree and network benches).
* **Failure reporting:** timeouts name the senders the engine was waiting for; protocol errors, participant failures, aborts, link failures and memory-protection violations each have a code, a completion record, error terminators for receivers still owed data, and a clean recovery for the next collective.

Then: N participants (2…8 per node), **trees** of nodes (FAN 2/3/4, 1–3 levels), all-reduce / broadcast / reduce-to-root, reduce-scatter and all-gather (flat nodes), FP32 SUM, a network adapter for remote participants, memory adapters over the real **StreamDMA + MemoryMatrix + MemoryGuard stand-in**.

## Results (copied from `reports/`)

| item | result |
|---|---|
| Simulation regression | **232 of 232** bench runs pass (flat NP 2…8, depth 1…8, FP32, RS/AG; trees FAN 2/3/4 × H 1…3, FP32; network WIN 2…16 × credits 1…16; memory system), 8 seeds each; **125,761 collectives scored**, 17,791,991 simulated cycles |
| Formal | **48 of 48** jobs pass: `cmd_validate` ≡ the specified rules over all 2^64 commands (4 configurations); collective-ID order over all values; tree reduction ≡ independent fold (every operator × type, NP 2/3/4); ingress adapter, output port (stability), scheduler (BMC depth 14–16); reachability witnesses |
| Formal sensitivity | **27 of 27** injected bugs make their formal job fail |
| Mutation testing | **74 of 78** injected bugs killed; 4 survivors, each shown equivalent (docs/08 §6) |
| Performance (cycles) | peak **0.98 elements/cycle** at any NP ≤ 8; integer all-reduce latency **len + 6**; FP32 + 5 per tree level; tree first result `6 + 7(H−1)` then 1 element/cycle; 1-deep buffers halve throughput (depth ≥ 2 needed); memory-fed ≈ 0.4 elements/cycle (benchmarks/REPORT.md) |
| Lint / latches | 0 `-Wall` warnings in 14 configurations; 9 illegal parameter sets rejected at elaboration; 0 latches in 9 synthesised configurations |
| Vendoring | 417 vendored files byte-identical to the manifest and to their members in the repository's archives |

## Deliverables (brief → file)

| requested | where |
|---|---|
| `sf_collective_core.sv` | `rtl/sf_collective_core.sv` (top) |
| `sf_collective_pkg.sv` | `rtl/sf_collective_pkg.sv` |
| `sf_collective_command_queue.sv` | `rtl/sf_collective_command_queue.sv` |
| `sf_collective_reduction.sv` | `rtl/sf_collective_reduction.sv` (+ `sf_collective_fp32_node.sv`) |
| `sf_collective_scheduler.sv` | `rtl/sf_collective_scheduler.sv` |
| `sf_collective_stream_adapter.sv` | `rtl/sf_collective_stream_adapter.sv` (input stream controller / participant adapter) |
| `sf_collective_perf.sv` | `rtl/sf_collective_perf.sv` |
| additional (needed by the architecture) | `rtl/sf_collective_output.sv`, `rtl/sf_collective_outport.sv` (output stream controller), `rtl/sf_collective_net_adapter.sv` (remote participants), `rtl/sf_collective_mem_{rd,wr,adapter}.sv` (memory / StreamDMA integration) |
| multi-participant simulation | `sim/sf_collective_tree_sim.sv` (FAN-ary trees), `sim/sf_collective_net_sim.sv` (local + remote), `sim/sf_collective_mm_system.sv` (real StreamDMA + MemoryMatrix); the flat N-participant simulation is the bench `tests/tb_main.cpp` over the core |
| testbench | `tests/` (Verilator C++ benches, independent reference `sf_coll_ref.h`) |
| formal properties | `formal/` (6 harnesses, runner, sensitivity check) |
| performance report | `benchmarks/REPORT.md` (+ raw `results.csv`) |

## Quick start

Tools (Ubuntu 24.04): `verilator` 5.020, `yosys` 0.33, `z3` 4.8, `python3`, `g++`, `make`.

```bash
make check lint quick            # vendored files, ABI, lint (+ negative tests), two-participant baseline: ~2 minutes
make regress formal formal-mut   # full simulation regression and formal: ~15 minutes
make mutate bench synth          # mutation campaign (~45 min), performance matrix, synthesis estimates
```

Build one bench by hand:

```bash
scripts/build_tb.sh np2 NP=2 && build/np2/tb_main --seed 1            # flat node, two participants
scripts/build_tb.sh fp4 NP=4 FP32_EN=1 && build/fp4/tb_main --seed 3  # four participants with FP32
scripts/build_tt.sh tt22 FAN=2 H=2 && build/tt22/tt_main --seed 1     # a 4-leaf tree of 3 nodes
scripts/build_tn.sh tn8 WIN=8 CREDITS=8 && build/tn8/tn_main          # remote participant over a lossy transport
scripts/build_tm.sh tm && build/tm/tm_main                            # StreamDMA + MemoryMatrix + adapters
```

## Layout

```
rtl/          SystemVerilog (filelist.f, filelist_fp32.f, filelist_mm.f, lint.vlt)
sim/          multi-node / system simulation tops
tests/        Verilator benches + independent reference model
formal/       Yosys harnesses, runner, sensitivity (mutant) check
scripts/      build, lint, regression, mutation, synthesis, vendor/ABI checks, package flattener
benchmarks/   performance driver, raw results, REPORT.md
third_party/  vendored, byte-identical (MANIFEST.tsv): sfd_fifo, fp32_fma, SoftFloat-3e, StreamDMA P103 r2, CloudDMA P64 guard, MemoryMatrix P101
docs/         00 audit · 01 architecture · 02 ABI · 03 numerics · 04 topology · 05 collectives · 06 network · 07 memory · 08 verification · 09 performance · 10 synthesis · 11 limitations
reports/      the generated evidence (regression, formal, mutation, lint, synthesis, tool versions)
```

## What the repository did and did not contain (docs/00)

Reused unmodified: `sfd_fifo` (every buffer), the **verified FP32 FMA** (FP32 SUM), **StreamDMA**, **MemoryMatrix**, the CloudDMA permission table (MemoryGuard stand-in), Berkeley SoftFloat (oracle).
Not present: **RDMAEngine** (a streaming transport adapter is built against a contract defined here), **PacketForge** (a code name for PacketCore, not integrated), **MemoryGuard** (the verified stand-in is used), any cross-participant reduction (the existing reduction is intra-tile).

## Read next

`docs/11_LIMITATIONS.md` (what is not claimed) → `docs/02_ABI.md` → `docs/03_NUMERICS.md` → `docs/04_TOPOLOGY.md` → `docs/08_VERIFICATION.md` → `benchmarks/REPORT.md`.
