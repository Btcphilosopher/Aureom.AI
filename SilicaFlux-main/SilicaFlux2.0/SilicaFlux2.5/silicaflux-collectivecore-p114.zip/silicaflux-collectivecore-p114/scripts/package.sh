#!/bin/bash
# Build the delivery ZIP:  scripts/package.sh [OUTPUT.zip]    (build products, mutation clones and logs of scratch runs are excluded)
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd); NAME=silicaflux-collectivecore-p114
OUT="${1:-$ROOT/../$NAME.zip}"
TMP=$(mktemp -d); mkdir -p $TMP/$NAME
tar --exclude='./build' --exclude='*.vcd' --exclude='__pycache__' --exclude='obj_dir' --exclude='./reports/*_run.log' --exclude='./reports/mutation_survivors.log' --exclude='./reports/formal_mut_run.log' -cf - . | tar -C $TMP/$NAME -xf -
( cd $TMP && rm -f "$OUT" && zip -q -r -9 "$OUT" $NAME )
echo "wrote $OUT ($(du -h "$OUT" | cut -f1)), $(unzip -Z1 "$OUT" | wc -l) entries"
rm -rf $TMP
