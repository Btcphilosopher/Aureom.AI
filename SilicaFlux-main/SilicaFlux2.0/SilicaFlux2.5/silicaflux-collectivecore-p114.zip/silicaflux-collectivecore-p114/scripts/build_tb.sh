#!/bin/bash
# Build the flat-node Verilator bench:   scripts/build_tb.sh NAME [PARAM=VALUE ...]
#   PARAM is any sf_collective_core parameter (NP, MAX_LEN, IN_DEPTH, OUT_DEPTH, CMD_DEPTH, CPL_DEPTH, FP32_EN, REDSCAT_EN, ALLGATHER_EN).
#   The matching TB_* macros are derived here so the C++ reference knows the build.  Output: build/NAME/tb_main
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd)
name="$1"; shift
G=""; D=""
NP=2; MAXLEN=300; RS=0; AG=0; FP=0
HAVE_ML=0
for a in "$@"; do
  k="${a%%=*}"; v="${a#*=}"
  case "$k" in
    NP) NP=$v; G="$G -GNP=$v" ;;
    MAX_LEN) MAXLEN=$v; HAVE_ML=1; G="$G -GMAX_LEN=$v" ;;
    REDSCAT_EN) RS=$v; G="$G -GREDSCAT_EN=1'b$v" ;;
    ALLGATHER_EN) AG=$v; G="$G -GALLGATHER_EN=1'b$v" ;;
    FP32_EN) FP=$v; G="$G -GFP32_EN=1'b$v" ;;
    *) G="$G -G$k=$v" ;;
  esac
done
[ "$HAVE_ML" = "0" ] && G="$G -GMAX_LEN=$MAXLEN"
FILES="-f rtl/filelist.f"
INC=""
EXTRA_FILES=""
[ "$FP" = "1" ] && FILES="$FILES rtl/sf_collective_fp32_node.sv -f rtl/filelist_fp32.f"
SF=""
if [ "$FP" = "1" ]; then SF="-DTB_FP32 -I$ROOT/third_party/berkeley-softfloat-3/source/include"; fi
[ "$FP" = "1" ] && scripts/build_softfloat.sh
mkdir -p build/$name
verilator --cc --exe --build -j ${VJ:-4} -O2 -Wno-fatal --top-module sf_collective_core -Mdir build/$name \
  rtl/lint.vlt $FILES $G \
  -CFLAGS "-O2 -std=c++17 -DTB_NP=$NP -DTB_MAXLEN=$MAXLEN -DTB_REDSCAT=$RS -DTB_ALLGATHER=$AG -DTB_FP32_EN=$FP $SF -I$ROOT/tests" \
  $( [ -n "$TRACE" ] && echo --trace -CFLAGS -DTRACE ) \
  $ROOT/${MAIN:-tests/tb_main.cpp} $( [ "$FP" = "1" ] && echo "$ROOT/build/softfloat/softfloat.a" ) -o ${EXE:-tb_main} > build/$name/build.log 2>&1 || { tail -40 build/$name/build.log; exit 1; }
echo "built build/$name/tb_main"
