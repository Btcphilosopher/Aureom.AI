#!/bin/bash
# Build the Berkeley SoftFloat-3e oracle library (RISC-V specialisation: canonical NaN 0x7FC00000) from the vendored sources.
# Output: build/softfloat/softfloat.a.  Same compile flags as the repository's fp32_fma reference build (ref/build_ref.sh).
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd); SF=$ROOT/third_party/berkeley-softfloat-3; OUT=$ROOT/build/softfloat
[ -f $OUT/softfloat.a ] && exit 0
rm -rf $OUT; mkdir -p build; cp -r $SF/build/Linux-x86_64-GCC $OUT
make -s -C $OUT -j4 SOURCE_DIR=$SF/source SPECIALIZE_TYPE=RISCV \
  COMPILE_C="gcc -c -fPIC -Werror-implicit-function-declaration -DSOFTFLOAT_FAST_INT64 -DSOFTFLOAT_ROUND_ODD -DINLINE_LEVEL=5 -DSOFTFLOAT_FAST_DIV32TO16 -DSOFTFLOAT_FAST_DIV64TO32 -I. -I$SF/source/RISCV -I$SF/source/include -O2 -o \$@" softfloat.a
echo "built $OUT/softfloat.a"
