#!/usr/bin/env python3
"""Yosys synthesis estimates (no PDK, no timing, no frequency / area / power claim): generic gate mapping, Lattice ECP5, Xilinx 7-series, per configuration,
plus an explicit latch check.  Packages are flattened first (scripts/flatten_pkg.py).  Writes reports/synth.md.   usage: synth_report.py [--quick]"""
import os, re, subprocess, sys, shutil
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
CORE = ["perf", "command_queue", "stream_adapter", "reduction", "outport", "output", "scheduler", "core"]
FIFO = "third_party/p61-clouddpu/rtl/sfd_fifo.sv"
FPF = ["third_party/hpc-fp32-fma/rtl/" + l.strip() for l in open("third_party/hpc-fp32-fma/rtl/files.f") if l.strip()]
CFGS = [  # label, top, rtl modules, extra files, params
 ("core NP=2 (INT)",                     "sf_collective_core", CORE, [], "NP=2"),
 ("core NP=4 (INT)",                     "sf_collective_core", CORE, [], "NP=4"),
 ("core NP=8 (INT)",                     "sf_collective_core", CORE, [], "NP=8"),
 ("core NP=4 (INT + reduce-scatter + all-gather)", "sf_collective_core", CORE, [], "NP=4 REDSCAT_EN=1 ALLGATHER_EN=1"),
 ("core NP=2 tree-interior node (INT)",  "sf_collective_core", CORE, [], "NP=2 INTERIOR=1"),
 ("core NP=2 (INT + FP32)",              "sf_collective_core", CORE + ["fp32_node"], FPF, "NP=2 FP32_EN=1"),
 ("core NP=4 (INT + FP32)",              "sf_collective_core", CORE + ["fp32_node"], FPF, "NP=4 FP32_EN=1"),
 ("network adapter (WIN=8)",             "sf_collective_net_adapter", ["net_adapter"], [], "WIN=8"),
 ("memory adapter (load + store engines)", "sf_collective_mem_adapter", ["mem_rd", "mem_wr", "mem_adapter"], [], ""),
]
if "--quick" in sys.argv: CFGS = CFGS[:2]
flat = "build/synth_rtl"; shutil.rmtree(flat, ignore_errors=True)
subprocess.check_call([sys.executable, "scripts/flatten_pkg.py", flat] + [f"rtl/sf_collective_{m}.sv" for m in sorted({m for c in CFGS for m in c[2]})])
def script(cfg, target):
    label, top, mods, extra, params = cfg
    ys = ["read_verilog -sv " + " ".join([FIFO] + [f"{flat}/sf_collective_{m}.sv" for m in mods] + extra)]
    for kv in params.split():
        k, v = kv.split("="); ys.append(f"chparam -set {k} {v} {top}")
    ys += [f"hierarchy -check -top {top}", "proc", "flatten", "opt_clean"]
    if target == "latch": ys += ["tee -o /dev/stdout select -count t:$dlatch t:$_DLATCH_*"]
    else:
        ys += {"generic": [f"synth -top {top}"], "ecp5": [f"synth_ecp5 -top {top}"], "xc7": [f"synth_xilinx -family xc7 -top {top}"]}[target]
        ys += ["tee -o /dev/stdout stat"]
    return "; ".join(ys)
def run(cfg, target):
    r = subprocess.run(["yosys", "-q", "-p", script(cfg, target)], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr
def parse(out):
    d = {}
    i = out.rfind("Number of cells")
    total = int(re.search(r"Number of cells:?\s+(\d+)", out[i:]).group(1)) if i >= 0 else 0
    for line in out[i:].splitlines()[1:]:
        m = re.match(r"\s+(\S+)\s+(\d+)\s*$", line)
        if not m: break
        d[m.group(1)] = int(m.group(2))
    return total, d
def ffs(d): return sum(v for k, v in d.items() if "DFF" in k or k in ("TRELLIS_FF", "FDRE", "FDCE", "FDPE", "FDSE", "FDRE_1"))
def luts(d): return sum(v for k, v in d.items() if re.match(r"LUT\d$", k))
rows = []; latches = []
for cfg in CFGS:
    r = {}
    for tgt in ("generic", "ecp5", "xc7"):
        rc, out = run(cfg, tgt)
        r[tgt] = ("ERROR", out[-300:]) if rc else parse(out)
    rc, out = run(cfg, "latch"); m = re.search(r"(\d+) objects", out); nl = int(m.group(1)) if m else -1
    latches.append(nl); rows.append((cfg, r))
    g, e, x = r["generic"], r["ecp5"], r["xc7"]
    print(cfg[0], "| generic", g[0], ffs(g[1]) if g[0] != "ERROR" else "-", "| ecp5 LUT", luts(e[1]) if e[0] != "ERROR" else e[1][:80], "FF", ffs(e[1]) if e[0] != "ERROR" else "-", "| xc7 LUT", luts(x[1]) if x[0] != "ERROR" else "-", "FF", ffs(x[1]) if x[0] != "ERROR" else "-", "| latches", nl, flush=True)
os.makedirs("reports", exist_ok=True)
with open("reports/synth.md", "w") as f:
    f.write("# Synthesis estimates (Yosys 0.33, no PDK)\n\n**What this is:** cell / flip-flop / LUT counts from Yosys technology-independent and FPGA mappings of the synthesizable RTL.  **What it is not:** no timing, no clock frequency, no area in um^2, no power, no place-and-route, no hardware.  "
            "Counts depend on Yosys' optimisation and say nothing about timing closure.  The FIFOs (`sfd_fifo`) are register arrays here (no SRAM macro mapping); a silicon build would map them to RAM macros.  The FPGA columns exclude the distributed-RAM primitives Yosys inferred for FIFO storage on those targets (they are neither LUT nor FF in these columns), while the generic mapping turns every storage bit into a flip-flop; that is why the generic FF counts are much larger than the FPGA FF counts.  "
            "Defaults: IN_DEPTH = OUT_DEPTH = CMD_DEPTH = CPL_DEPTH = 4, TERM_DEPTH = 2, MAX_LEN = 4096.\n\n"
            "| configuration | generic cells | generic FFs | ECP5 LUT4 | ECP5 FFs | Xilinx-7 LUTs | Xilinx-7 FFs | latches |\n|---|---|---|---|---|---|---|---|\n")
    for (cfg, r), nl in zip(rows, latches):
        g, e, x = r["generic"], r["ecp5"], r["xc7"]
        ok = lambda v: v[0] != "ERROR"
        f.write(f"| {cfg[0]} | {g[0] if ok(g) else 'n/a'} | {ffs(g[1]) if ok(g) else 'n/a'} | {luts(e[1]) if ok(e) else 'n/a'} | {ffs(e[1]) if ok(e) else 'n/a'} | {luts(x[1]) if ok(x) else 'n/a'} | {ffs(x[1]) if ok(x) else 'n/a'} | {nl} |\n")
    f.write("\nLatches are counted on the proc-ed, flattened netlist (`select -count t:$dlatch`): 0 means no unintended latch in any configuration.\n")
print("wrote reports/synth.md")
