#!/bin/bash
echo "# tool versions used for every report in this package"
for t in "verilator --version" "yosys -V" "z3 --version" "yosys-smtbmc --version" "iverilog -V" "python3 --version" "g++ --version" "make --version"; do echo "\$ $t"; $t 2>&1 | head -1; done
echo "host: $(uname -srm), $(nproc) CPUs"
