#!/usr/bin/env python3
"""Replace the @@PLACEHOLDERS@@ in README.md and docs/*.md with numbers read from reports/ and benchmarks/ (no figure is typed by hand)."""
import csv, os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
def rd(p): return open(p).read() if os.path.exists(p) else ""
v = {}
r = rd("reports/regression.md"); m = re.search(r"\*\*(\d+) of (\d+) bench runs pass; ([\d,]+) collectives scored; ([\d,]+) simulated cycles", r)
if m: v.update(REG_PASS=m.group(1), REG_RUNS=m.group(2), REG_COLLS=m.group(3), REG_CYC=m.group(4))
f = rd("reports/formal.md"); m = re.search(r"\*\*(\d+) of (\d+) jobs pass", f)
if m: v.update(FORMAL_PASS=m.group(1), FORMAL_TOTAL=m.group(2))
f = rd("reports/formal_mutants.md"); m = re.search(r"\*\*(\d+) of (\d+) injected bugs", f)
if m: v.update(FMUT_KILLED=m.group(1), FMUT_TOTAL=m.group(2))
f = rd("reports/mutation.md"); m = re.search(r"\*\*(\d+) of (\d+) mutants killed\*\*; survivors: (\d+)", f)
if m: v.update(MUT_KILLED=m.group(1), MUT_TOTAL=m.group(2), MUT_SURV=m.group(3))
if os.path.exists("benchmarks/results.csv"):
    for row in csv.DictReader(open("benchmarks/results.csv")):
        if row["workload"] == "peak" and "NP=2 IN_DEPTH=4 OUT_DEPTH=4" in row["config"]: v["PEAK_EPC"] = f"{float(row['elem_per_active_cycle']):.2f}"
for p in ["README.md"] + [f"docs/{x}" for x in sorted(os.listdir("docs"))]:
    s = open(p).read(); t = re.sub(r"@@(\w+)@@", lambda m: v.get(m.group(1), m.group(0)), s)
    if t != s: open(p, "w").write(t)
left = [p for p in ["README.md"] + [f"docs/{x}" for x in os.listdir("docs")] if re.search(r"@@\w+@@", open(p).read())]
print("filled:", sorted(v)); print("unfilled placeholders in:", left)
