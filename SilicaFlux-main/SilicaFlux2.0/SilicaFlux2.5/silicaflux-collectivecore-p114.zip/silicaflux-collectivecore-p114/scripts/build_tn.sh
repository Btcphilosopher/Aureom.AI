#!/bin/bash
# Build the network-adapter Verilator bench:   scripts/build_tn.sh NAME [WIN=8 CREDITS=8 ...]    Output: build/NAME/tn_main
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd); name="$1"; shift
G=""; WIN=8; CRED=8
for a in "$@"; do k="${a%%=*}"; v="${a#*=}"; case "$k" in WIN) WIN=$v; G="$G -GWIN=$v";; CREDITS) CRED=$v; G="$G -GCREDITS=$v";; *) G="$G -G$k=$v";; esac; done
mkdir -p build/$name
verilator --cc --exe --build -j ${VJ:-4} -O2 -Wno-fatal --top-module sf_collective_net_sim -Mdir build/$name rtl/lint.vlt \
  -f rtl/filelist.f rtl/sf_collective_net_adapter.sv sim/sf_collective_net_sim.sv $G -GMAX_LEN=300 \
  -CFLAGS "-O2 -std=c++17 -DTB_WIN=$WIN -DTB_CREDITS=$CRED -I$ROOT/tests" $ROOT/tests/tn_main.cpp -o tn_main > build/$name/build.log 2>&1 || { tail -40 build/$name/build.log; exit 1; }
echo "built build/$name/tn_main"
