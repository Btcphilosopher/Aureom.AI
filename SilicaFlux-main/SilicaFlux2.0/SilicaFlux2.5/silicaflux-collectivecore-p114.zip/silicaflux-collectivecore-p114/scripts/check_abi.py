#!/usr/bin/env python3
"""Compare the numeric ABI constants of rtl/sf_collective_pkg.sv with the independent reference header tests/sf_coll_ref.h
(collective types, operators, data types, error codes, flag bits, command field positions).  Exits non-zero on any difference."""
import os, re, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
pkg = open(os.path.join(root, "rtl/sf_collective_pkg.sv")).read()
ref = open(os.path.join(root, "tests/sf_coll_ref.h")).read()
def sv_consts(prefixes):
    d = {}
    for m in re.finditer(r"localparam\s+(?:logic\s*\[[^\]]*\]|int)\s+([^;]*);", pkg):
        for item in re.sub(r"//[^\n]*", "", m.group(1)).split(","):
            mm = re.match(r"\s*(\w+)\s*=\s*(?:\d+'d)?(\d+)\s*$", item)
            if mm and any(mm.group(1).startswith(p) for p in prefixes): d[mm.group(1)] = int(mm.group(2))
    return d
def enum_consts(name):
    m = re.search(r"enum\s*\{([^}]*)\}", ref[ref.index(name):], re.S) if False else None
def ref_enum(first):
    i = ref.index(first); m = re.search(r"enum\s*\{([^}]*)\}", ref[i - 10:], re.S)
    out = {}
    for tok in m.group(1).split(","):
        tok = tok.strip()
        if not tok: continue
        k, v = [x.strip() for x in tok.split("=")]
        out[k] = int(v)
    return out
bad = 0
def cmp(sv, rf, label):
    global bad
    for k, v in rf.items():
        if k not in sv: print(f"MISSING in pkg: {label} {k}"); bad += 1
        elif sv[k] != v: print(f"DIFF {label} {k}: pkg={sv[k]} ref={v}"); bad += 1
cmp(sv_consts(["CT_"]), ref_enum("CT_REDUCE = 0"), "ctype")
cmp(sv_consts(["OP_"]), ref_enum("OP_SUM = 0"), "op")
cmp(sv_consts(["DT_"]), ref_enum("DT_I32 = 0"), "dtype")
cmp(sv_consts(["E_"]), ref_enum("E_OK = 0"), "error")
cmp(sv_consts(["FL_"]), ref_enum("FL_NX = 0"), "flag")
# command field positions: pkg C_* vs Cmd::pack()
sv = sv_consts(["C_"]); want = {"C_CID": 0, "C_CTYPE": 16, "C_OP": 19, "C_DT": 22, "C_RM": 24, "C_SEND": 27, "C_RECV": 35, "C_LEN": 43}
m = re.search(r"uint64_t pack\(\) const \{(.*?)\}", ref, re.S).group(1)
shifts = {"cid": 0}
for mm in re.finditer(r"\(uint64_t\)(\w+) << (\d+)", m): shifts[mm.group(1)] = int(mm.group(2))
ref_pos = {"C_CID": shifts["cid"], "C_CTYPE": shifts["ctype"], "C_OP": shifts["op"], "C_DT": shifts["dtype"], "C_RM": shifts["rm"], "C_SEND": shifts["send"], "C_RECV": shifts["recv"], "C_LEN": shifts["len"]}
for k, v in ref_pos.items():
    if sv.get(k) != v: print(f"DIFF command field {k}: pkg={sv.get(k)} ref={v}"); bad += 1
print("ABI check:", "OK (pkg == reference header)" if not bad else f"{bad} difference(s)")
sys.exit(1 if bad else 0)
