#!/usr/bin/env python3
"""Full simulation regression: every bench x every configuration x N seeds.  Writes reports/regression.md (counts copied from the benches' RESULT lines).
usage: scripts/regress.py [--seeds N] [--quick]"""
import os, re, subprocess, sys, concurrent.futures as cf, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
SEEDS = int(sys.argv[sys.argv.index("--seeds") + 1]) if "--seeds" in sys.argv else 8
QUICK = "--quick" in sys.argv
FLAT = [  # name, build args
 ("flat NP=2 (default depths 4/4)", "np2", "NP=2"), ("flat NP=2 depth 1/1/1/1", "d1", "NP=2 IN_DEPTH=1 OUT_DEPTH=1 CMD_DEPTH=1 CPL_DEPTH=1 TERM_DEPTH=1"),
 ("flat NP=2 depth 8/8", "d8", "NP=2 IN_DEPTH=8 OUT_DEPTH=8"), ("flat NP=3 depth 2/3", "np3", "NP=3 IN_DEPTH=2 OUT_DEPTH=3"),
 ("flat NP=4", "np4", "NP=4"), ("flat NP=8 depth 3/2", "np8", "NP=8 IN_DEPTH=3 OUT_DEPTH=2 TERM_DEPTH=3"),
 ("flat NP=2 + reduce-scatter + all-gather", "rg2", "NP=2 REDSCAT_EN=1 ALLGATHER_EN=1"), ("flat NP=4 + RS + AG depth 2/2", "rg4", "NP=4 REDSCAT_EN=1 ALLGATHER_EN=1 IN_DEPTH=2 OUT_DEPTH=2"),
 ("flat NP=8 + RS + AG", "rg8", "NP=8 REDSCAT_EN=1 ALLGATHER_EN=1 IN_DEPTH=3 OUT_DEPTH=2"),
 ("flat NP=2 + FP32", "fp2", "NP=2 FP32_EN=1"), ("flat NP=3 + FP32 depth 2/2", "fp3", "NP=3 FP32_EN=1 IN_DEPTH=2 OUT_DEPTH=2"), ("flat NP=4 + FP32", "fp4", "NP=4 FP32_EN=1"),
 ("flat NP=5 + FP32 + RS + AG depth 1/1", "fp5", "NP=5 FP32_EN=1 REDSCAT_EN=1 ALLGATHER_EN=1 IN_DEPTH=1 OUT_DEPTH=1"), ("flat NP=8 + FP32", "fp8", "NP=8 FP32_EN=1 IN_DEPTH=3"),
]
TREE = [("tree FAN=2 H=1 (root only)", "tt21", "FAN=2 H=1"), ("tree FAN=2 H=2", "tt22", "FAN=2 H=2"), ("tree FAN=2 H=3", "tt23", "FAN=2 H=3"), ("tree FAN=3 H=2 depth 2/2", "tt32", "FAN=3 H=2 IN_DEPTH=2 OUT_DEPTH=2"),
        ("tree FAN=4 H=2", "tt42", "FAN=4 H=2"), ("tree FAN=2 H=3 depth 1", "tt23d1", "FAN=2 H=3 IN_DEPTH=1 OUT_DEPTH=1 CMD_DEPTH=1 CPL_DEPTH=1 TERM_DEPTH=1"),
        ("tree FAN=2 H=2 + FP32", "ft22", "FAN=2 H=2 FP32_EN=1"), ("tree FAN=3 H=2 + FP32", "ft32", "FAN=3 H=2 FP32_EN=1"), ("tree FAN=2 H=3 + FP32 depth 2/2", "ft23", "FAN=2 H=3 FP32_EN=1 IN_DEPTH=2 OUT_DEPTH=2"),
        ("tree FAN=4 H=2 + FP32", "ft42", "FAN=4 H=2 FP32_EN=1")]
NET = [("network WIN=2 CREDITS=1", "tn2", "WIN=2 CREDITS=1"), ("network WIN=4 CREDITS=3", "tn4", "WIN=4 CREDITS=3"), ("network WIN=8 CREDITS=8", "tn8", "WIN=8 CREDITS=8"), ("network WIN=16 CREDITS=16", "tn16", "WIN=16 CREDITS=16")]
MEM = [("memory system (StreamDMA + MemoryMatrix + adapters)", "tm", "")]
if QUICK: FLAT, TREE, NET = FLAT[:2], TREE[:2], NET[:1]; SEEDS = 2
def sh(cmd): return subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True).stdout
def job(kind, cfg):
    label, name, args = cfg
    script, exe = {"flat": ("build_tb.sh", "tb_main"), "tree": ("build_tt.sh", "tt_main"), "net": ("build_tn.sh", "tn_main"), "mem": ("build_tm.sh", "tm_main")}[kind]
    b = sh(f"VJ=2 scripts/{script} r_{name} {args}")
    if "built" not in b: return (kind, label, "BUILD FAIL: " + b[-200:], [])
    res = []
    for sd in range(1, SEEDS + 1):
        out = sh(f"build/r_{name}/{exe} --seed {sd} --quiet" + (" --test all" if False else ""))
        m = re.search(r"RESULT: (PASS|FAIL)\s+tests=(\d+) failed=(\d+).*?colls=(\d+) cycles=(\d+)", out)
        res.append((sd, m.group(1) if m else "ERROR", int(m.group(2)) if m else 0, int(m.group(4)) if m else 0, int(m.group(5)) if m else 0))
    return (kind, label, "ok", res)
t0 = time.time(); results = []
with cf.ThreadPoolExecutor(max_workers=2) as ex:
    futs = [ex.submit(job, "flat", c) for c in FLAT] + [ex.submit(job, "tree", c) for c in TREE] + [ex.submit(job, "net", c) for c in NET] + [ex.submit(job, "mem", c) for c in MEM]
    for f in futs: r = f.result(); results.append(r); print(r[1], r[2], [x[1] for x in r[3]].count("PASS"), "/", len(r[3]), flush=True)
os.makedirs("reports", exist_ok=True)
tot_runs = tot_pass = tot_c = tot_cy = 0
with open("reports/regression.md", "w") as f:
    f.write(f"# Simulation regression\n\nVerilator 5.020; every bench is deterministic per seed; seeds 1..{SEEDS} per configuration.  \"colls\" = collectives scored against the independent reference (scoreboard); the count restarts at each hard reset inside the reset scenarios, so it is a lower bound.\n\n| bench | configuration | tests | seeds passing | collectives scored | simulated cycles |\n|---|---|---|---|---|---|\n")
    for kind, label, st, res in results:
        if st != "ok": f.write(f"| {kind} | {label} | – | {st} | | |\n"); continue
        npass = sum(1 for x in res if x[1] == "PASS"); colls = sum(x[3] for x in res); cyc = sum(x[4] for x in res); tests = res[0][2] if res else 0
        f.write(f"| {kind} | {label} | {tests} | {npass} / {len(res)} | {colls:,} | {cyc:,} |\n")
        tot_runs += len(res); tot_pass += npass; tot_c += colls; tot_cy += cyc
    f.write(f"\n**{tot_pass} of {tot_runs} bench runs pass; {tot_c:,} collectives scored; {tot_cy:,} simulated cycles.**  ({int(time.time()-t0)} s)\n")
print(f"{tot_pass}/{tot_runs} runs pass, {tot_c} collectives, {tot_cy} cycles")
sys.exit(0 if tot_pass == tot_runs else 1)
