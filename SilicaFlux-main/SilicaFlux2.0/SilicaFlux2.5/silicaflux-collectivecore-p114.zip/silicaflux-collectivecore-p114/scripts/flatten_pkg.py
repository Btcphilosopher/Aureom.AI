#!/usr/bin/env python3
"""Yosys 0.33 cannot read `module m import pkg::*; #(...) (...)`.  For the Yosys flows only (formal, synthesis) this tool writes copies of the
RTL in which sf_collective_pkg's constants become `localparam`s at the head of every importing module's parameter list and its functions are
inlined at the top of the module body.  The simulation RTL is untouched.   usage: flatten_pkg.py OUTDIR file.sv ...   (the package itself is read from rtl/)"""
import os, re, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
pkg = open(os.path.join(os.environ.get("SF_RTL_DIR", os.path.join(root, "rtl")), "sf_collective_pkg.sv")).read()
body = pkg[pkg.index("package sf_collective_pkg;") + len("package sf_collective_pkg;"): pkg.index("endpackage")]
lps = []
for m in re.finditer(r"^\s*localparam\b[^;]*;", body, re.M):
    s = re.sub(r"//[^\n]*", "", m.group(0)).strip()
    lps.append(s[:-1] + ",")
funcs = "\n".join(m.group(0) for m in re.finditer(r"^\s*function\b.*?^\s*endfunction", body, re.M | re.S))
lp_text = "\n  ".join(lps)
out = sys.argv[1]; os.makedirs(out, exist_ok=True)
for f in sys.argv[2:]:
    s = open(f).read()
    if "import sf_collective_pkg::*;" in s:
        if re.search(r"import sf_collective_pkg::\*;\s*#\(", s):
            s = re.sub(r"import sf_collective_pkg::\*;\s*#\(", "#(\n  " + lp_text + "\n  ", s, count=1)
        else:
            s = re.sub(r"import sf_collective_pkg::\*;\s*\(", "#(\n  " + lp_text.rstrip(",") + "\n) (", s, count=1)
        # functions go right after the port list: the first line that is exactly ");" following the header
        i = s.index("\n);\n") + 4
        s = s[:i] + funcs + "\n" + s[i:]
    open(os.path.join(out, os.path.basename(f)), "w").write(s)
