#!/bin/bash
# Build the tree Verilator bench:   scripts/build_tt.sh NAME FAN=2 H=2 [MAX_LEN=.. IN_DEPTH=.. OUT_DEPTH=.. ...]
#   Output: build/NAME/tt_main
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd)
name="$1"; shift
G=""; FAN=2; H=2; MAXLEN=300; FP=0; HAVE_ML=0
for a in "$@"; do
  k="${a%%=*}"; v="${a#*=}"
  case "$k" in
    FAN) FAN=$v; G="$G -GFAN=$v" ;;
    H) H=$v; G="$G -GH=$v" ;;
    MAX_LEN) MAXLEN=$v; HAVE_ML=1; G="$G -GMAX_LEN=$v" ;;
    FP32_EN) FP=$v; G="$G -GFP32_EN=1'b$v" ;;
    *) G="$G -G$k=$v" ;;
  esac
done
[ "$HAVE_ML" = "0" ] && G="$G -GMAX_LEN=$MAXLEN"
FILES="-f rtl/filelist.f sim/sf_collective_tree_sim.sv"
SF=""; LIBS=""
if [ "$FP" = "1" ]; then FILES="$FILES rtl/sf_collective_fp32_node.sv -f rtl/filelist_fp32.f"; SF="-DTB_FP32 -I$ROOT/third_party/berkeley-softfloat-3/source/include"; LIBS="$ROOT/build/softfloat/softfloat.a"; fi
[ "$FP" = "1" ] && scripts/build_softfloat.sh
mkdir -p build/$name
verilator --cc --exe --build -j ${VJ:-4} -O2 -Wno-fatal -Wno-UNOPTFLAT --top-module sf_collective_tree_sim -Mdir build/$name \
  rtl/lint.vlt $FILES $G \
  -CFLAGS "-O2 -std=c++17 -DTB_FAN=$FAN -DTB_H=$H -DTB_MAXLEN=$MAXLEN -DTB_FP32_EN=$FP $SF -I$ROOT/tests" \
  $ROOT/tests/tt_main.cpp $LIBS -o tt_main > build/$name/build.log 2>&1 || { tail -40 build/$name/build.log; exit 1; }
echo "built build/$name/tt_main"
