#!/usr/bin/env python3
"""Verify that every vendored file in third_party/ is byte-identical to the SHA-256 recorded in third_party/MANIFEST.tsv and (optionally) to the member of the
repository archive it was copied from:   check_vendor.py [--repo <repository root>]"""
import hashlib, os, sys, zipfile
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rows = []
for line in open(os.path.join(root, "third_party", "MANIFEST.tsv")):
    if line.startswith("#") or not line.strip(): continue
    path, member, src, sha = line.rstrip("\n").split("\t")
    rows.append((path, member, src, sha))
bad = 0
for path, member, src, sha in rows:
    h = hashlib.sha256(open(os.path.join(root, "third_party", path), "rb").read()).hexdigest()
    if h != sha: print("BAD", path); bad += 1
print(f"manifest: {len(rows)} files, {'all match' if not bad else str(bad) + ' MISMATCH'}")
repo = sys.argv[sys.argv.index("--repo") + 1] if "--repo" in sys.argv else None
if repo:
    import re
    zips = {}; checked = unchecked = ab = 0; last = None
    for path, member, src, sha in rows:
        m = re.search(r"\S+\.zip", src)
        outer = m.group(0) if m else last          # "same" = the archive of the previous row
        last = outer
        zp = os.path.join(repo, outer) if outer else ""
        if not zp or not os.path.exists(zp): unchecked += 1; continue
        z = zips.setdefault(zp, zipfile.ZipFile(zp))
        if member in z.namelist():
            checked += 1
            if hashlib.sha256(z.read(member)).hexdigest() != sha: print("BAD archive member", member); ab += 1
        else: unchecked += 1
    print(f"archive provenance: {checked} compared with their archive member, {ab} mismatch, {unchecked} not checked (archive or member not found at that path)")
    bad += ab
sys.exit(1 if bad else 0)
