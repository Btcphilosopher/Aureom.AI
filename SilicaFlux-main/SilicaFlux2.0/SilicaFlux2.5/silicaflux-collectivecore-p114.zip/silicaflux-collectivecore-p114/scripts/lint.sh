#!/bin/bash
# Verilator -Wall lint of every synthesizable block in several parameterisations (must be warning-free) plus negative elaboration tests (illegal parameters must be REJECTED).
# Writes reports/lint.md.
cd "$(dirname "$0")/.."
mkdir -p reports; OUT=reports/lint.md; fail=0
{ echo "# Lint report (Verilator $(verilator --version | cut -d' ' -f2), -Wall)"; echo; echo "| configuration | warnings |"; echo "|---|---|"; } > $OUT
FPF="rtl/sf_collective_fp32_node.sv -f rtl/filelist_fp32.f"
lint() { # label top extra_files params...
  label="$1"; top="$2"; extra="$3"; shift 3; G=""; for p in "$@"; do G="$G -G$p"; done
  n=$(verilator --lint-only -Wall rtl/lint.vlt -f rtl/filelist.f $extra --top-module $top $G 2>&1 | grep -c '^%Warning\|^%Error')
  echo "| $label | $n |" >> $OUT; [ "$n" = 0 ] || fail=1
}
lint "core NP=2 default" sf_collective_core ""
lint "core NP=3 depth 1/1/1/1/1" sf_collective_core "" NP=3 IN_DEPTH=1 OUT_DEPTH=1 CMD_DEPTH=1 CPL_DEPTH=1 TERM_DEPTH=1
lint "core NP=8" sf_collective_core "" NP=8
lint "core NP=5 + reduce-scatter + all-gather" sf_collective_core "" NP=5 "REDSCAT_EN=1'b1" "ALLGATHER_EN=1'b1"
lint "core NP=2 tree-interior UP_PID=1" sf_collective_core "" NP=2 "INTERIOR=1'b1" UP_PID=1
lint "core NP=4 tree-interior + RS + AG" sf_collective_core "" NP=4 "INTERIOR=1'b1" UP_PID=3 "REDSCAT_EN=1'b1" "ALLGATHER_EN=1'b1"
lint "core NP=2 + FP32" sf_collective_core "$FPF" "FP32_EN=1'b1"
lint "core NP=3 + FP32" sf_collective_core "$FPF" NP=3 "FP32_EN=1'b1"
lint "core NP=8 + FP32 + RS + AG" sf_collective_core "$FPF" NP=8 "FP32_EN=1'b1" "REDSCAT_EN=1'b1" "ALLGATHER_EN=1'b1" MAX_LEN=1000
lint "FP32 tree node" sf_collective_fp32_node "$FPF"
lint "network adapter WIN=2" sf_collective_net_adapter "rtl/sf_collective_net_adapter.sv" WIN=2
lint "network adapter WIN=16 CREDITS=16" sf_collective_net_adapter "rtl/sf_collective_net_adapter.sv" WIN=16 CREDITS=16
lint "memory adapter" sf_collective_mem_adapter "rtl/sf_collective_mem_rd.sv rtl/sf_collective_mem_wr.sv rtl/sf_collective_mem_adapter.sv"
lint "memory adapter AW=40 MM_AW=24 DATA_WIDTH=256" sf_collective_mem_adapter "rtl/sf_collective_mem_rd.sv rtl/sf_collective_mem_wr.sv rtl/sf_collective_mem_adapter.sv" AW=40 MM_AW=24 DATA_WIDTH=256
echo >> $OUT; echo "## Negative elaboration tests (each must be rejected)" >> $OUT; echo >> $OUT; echo "| illegal parameters | rejected |" >> $OUT; echo "|---|---|" >> $OUT
neg() { name="$1"; shift; G=""; for p in "$@"; do G="$G -G$p"; done
  if verilator --lint-only rtl/lint.vlt -f rtl/filelist.f --top-module sf_collective_core $G >/dev/null 2>&1; then echo "| $name | **NO (accepted!)** |" >> $OUT; fail=1; else echo "| $name | yes |" >> $OUT; fi; }
neg "NP=1" NP=1
neg "NP=9" NP=9
neg "MAX_LEN=0" MAX_LEN=0
neg "MAX_LEN * NP >= 2^20 (MAX_LEN=200000, NP=8)" MAX_LEN=200000 NP=8
neg "IN_DEPTH=0" IN_DEPTH=0
neg "OUT_DEPTH=0" OUT_DEPTH=0
neg "CMD_DEPTH=0" CMD_DEPTH=0
neg "TERM_DEPTH=0" TERM_DEPTH=0
neg "UP_PID=8" UP_PID=8
echo >> $OUT; echo "Vendored third_party files are waived unchanged in rtl/lint.vlt; package constants consumed elsewhere are waived for UNUSEDPARAM." >> $OUT
cat $OUT | tail -34; exit $fail
