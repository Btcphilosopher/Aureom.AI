#!/usr/bin/env python3
"""Mutation campaign: inject deliberate RTL bugs, rebuild the benches, require every mutant to be KILLED (some bench fails).
   The unmutated design must pass every bench first (baseline gate).  Writes reports/mutation.md.
   usage: scripts/mutate.py [--jobs N] [--only SUBSTR] [--list]"""
import os, re, shutil, subprocess, sys, concurrent.futures as cf, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

# (id, file, original text (must occur exactly once), replacement, class, benches, description)
FLAT, TREE, NET, MEM = "flat", "tree", "net", "mem"
M = []
def mut(i, f, a, b, cls, benches, desc): M.append((i, f, a, b, cls, benches, desc))

SA = "rtl/sf_collective_stream_adapter.sv"; RD = "rtl/sf_collective_reduction.sv"; PK = "rtl/sf_collective_pkg.sv"; SC = "rtl/sf_collective_scheduler.sv"
OP = "rtl/sf_collective_outport.sv"; OU = "rtl/sf_collective_output.sv"; CQ = "rtl/sf_collective_command_queue.sv"; FN = "rtl/sf_collective_fp32_node.sv"
NA = "rtl/sf_collective_net_adapter.sv"; MR = "rtl/sf_collective_mem_rd.sv"; MW = "rtl/sf_collective_mem_wr.sv"; CO = "rtl/sf_collective_core.sv"
CORE = [FLAT, TREE]
# ---- stream adapter (input stream controller)
mut("sa-dup-off", SA, "else if (idx_w < exp_w) code = E_DUP;", "else if (idx_w < exp_w) code = E_OK;", "protocol", CORE, "duplicate elements are not detected")
mut("sa-seq-off", SA, "else if (idx_w > exp_w) code = E_SEQ;", "else if (idx_w > exp_w) code = E_OK;", "protocol", CORE, "element gaps are not detected")
mut("sa-early-drop", SA, "assign s_ready = early ? 1'b0 :", "assign s_ready = early ? 1'b1 :", "ordering", CORE, "beats of a future collective are consumed (dropped) instead of held")
mut("sa-cid-ignored", SA, "wire cid_eq = ref_valid && (s_cid == act_cid);", "wire cid_eq = ref_valid;", "isolation", CORE, "beats of ANY collective are accepted into the running one")
mut("sa-pid-off", SA, "else if (!act_en || s_pid != PID_W'(PID) || s_dtype != act_dtype || s_op != act_op) code = E_HDR;", "else if (!act_en || s_dtype != act_dtype || s_op != act_op) code = E_HDR;", "protocol", CORE, "participant id not checked")
mut("sa-dtop-off", SA, "else if (!act_en || s_pid != PID_W'(PID) || s_dtype != act_dtype || s_op != act_op) code = E_HDR;", "else if (!act_en || s_pid != PID_W'(PID)) code = E_HDR;", "protocol", CORE, "data type / operation echo not checked")
mut("sa-sender-off", SA, "else if (!act_en || s_pid != PID_W'(PID) ||", "else if (s_pid != PID_W'(PID) ||", "protocol", CORE, "a non-sender's data is accepted")
mut("sa-last-off", SA, "else if (idx_w >= act_len || (s_last != (idx_w == last_idx))) code = E_LEN;", "else if (idx_w >= act_len) code = E_LEN;", "protocol", CORE, "LAST flag not checked")
mut("sa-len-off", SA, "else if (idx_w >= act_len || (s_last != (idx_w == last_idx))) code = E_LEN;", "else if (s_last != (idx_w == last_idx)) code = E_LEN;", "protocol", CORE, "elements beyond the command length accepted")
mut("sa-peer-off", SA, "if (s_err) code = E_PEER;", "if (1'b0) code = E_PEER;", "failure", CORE, "source error flag ignored")
mut("sa-clr-leak", SA, "wire clr = !act_valid || sclr;", "wire clr = sclr;", "isolation", CORE, "input buffer / index state not cleared between collectives")
mut("sa-stale-block", SA, "wire stale  = !early && !mine;", "wire stale  = 1'b0;", "ordering", CORE, "stale beats are held instead of discarded")
mut("sa-expidx", SA, "else if (push)   exp_idx <= exp_idx + 1'b1;", "else if (push && s_idx[0])   exp_idx <= exp_idx + 1'b1;", "datapath", CORE, "element counter skips")
# ---- package: operators / validation
mut("pk-unsigned-cmp", PK, "lt = (dt == DT_U32) ? (a < b) : ($signed(a) < $signed(b));", "lt = ($signed(a) < $signed(b));", "numerics", CORE, "UINT32 MIN/MAX compared as signed")
mut("pk-signed-cmp", PK, "lt = (dt == DT_U32) ? (a < b) : ($signed(a) < $signed(b));", "lt = (a < b);", "numerics", CORE, "INT32 MIN/MAX compared as unsigned")
mut("pk-max-swap", PK, "OP_MAX:  red_op = lt ? b : a;", "OP_MAX:  red_op = lt ? a : b;", "numerics", CORE, "MAX returns the minimum")
mut("pk-sum", PK, "OP_SUM:  red_op = a + b;", "OP_SUM:  red_op = a - b;", "numerics", CORE, "SUM subtracts")
mut("pk-xor", PK, "OP_XOR:  red_op = a ^ b;", "OP_XOR:  red_op = a | b;", "numerics", CORE, "XOR computes OR")
mut("pk-reduce-root", PK, "else if (ct == CT_REDUCE    && nr != 4'd1) cmd_validate = E_CMD_MASK;", "else if (ct == CT_REDUCE    && nr == 4'd0) cmd_validate = E_CMD_MASK;", "validation", CORE, "REDUCE accepts several roots")
mut("pk-len-limit", PK, "else if (ln > LEN_W'(max_len) ||", "else if (ln > LEN_W'(max_len) + LEN_W'(1) ||", "validation", CORE, "length limit off by one")
mut("pk-cid-after", PK, "cid_after = (d != 16'd0) && (d[15] == 1'b0);", "cid_after = (d != 16'd0) && (d[15] == 1'b1);", "ordering", CORE, "collective-ID order inverted")
mut("pk-fp-rm", PK, "((cmd_dt(c) == DT_F32) && (cmd_op(c) == OP_SUM) && (cmd_rm(c) > 3'd4))", "((cmd_dt(c) == DT_F32) && (cmd_op(c) == OP_SUM) && (cmd_rm(c) > 3'd6))", "validation", CORE, "illegal rounding modes 5,6 accepted")
mut("pk-op-legal", PK, "else if (dt == DT_F32) op_legal = fp32_en && (op == OP_SUM);", "else if (dt == DT_F32) op_legal = fp32_en;", "validation", CORE, "FP32 accepts every integer operator")
# ---- reduction
mut("rd-ovf-signed", RD, "(ssum != 35'($signed(ssum[31:0])))", "1'b0", "numerics", CORE, "signed overflow flag never raised")
mut("rd-ovf-unsigned", RD, "(usum[34:32] != 3'd0)", "(usum[34:33] != 2'd0)", "numerics", CORE, "unsigned carry flag too late")
mut("rd-align", RD, "wire all_ok      = ((h_valid | ~send_mask) == {NP{1'b1}});", "wire all_ok      = (|h_valid);", "isolation", CORE, "elements combined before every participant has delivered (misalignment)")
mut("rd-pop", RD, "if (fire_red) h_ready = send_mask;", "if (fire_red) h_ready = NP'(1);", "datapath", CORE, "only participant 0's head is popped")
mut("rd-done", RD, "assign red_done = run && (elem_in == res_len) && !rv_q && (res_len != '0);", "assign red_done = run && (elem_in == res_len) && (res_len != '0);", "completion", CORE, "reduction reported done while the last result is still in the stage")
mut("rd-gather-order", RD, "g_ptr_q <= (g_wrap && g_found) ? g_next : g_cur;", "g_ptr_q <= g_cur;", "datapath", CORE, "all-gather never advances to the next participant")
mut("rd-clr", RD, "wire clr = !run || sclr;", "wire clr = sclr;", "isolation", CORE, "reduction state not cleared between collectives")
mut("rd-flags-fp", RD, "fl_q[4:0] <= fl_q[4:0] | fp_flags_acc;", "fl_q[4:0] <= fl_q[4:0];", "numerics", CORE, "FP exception flags never recorded")
mut("rd-fp-ready", RD, "if (fp_mode)  h_ready = fp_h_ready;", "if (fp_mode)  h_ready = '0;", "datapath", CORE, "FP32 heads never popped")
# ---- FP node
mut("fn-one", FN, "32'h3F800000", "32'h40000000", "numerics", CORE, "FMA multiplier 2.0 instead of 1.0")
mut("fn-rm", FN, ".in_rm(rm)", ".in_rm(3'd0)", "numerics", CORE, "rounding mode ignored")
mut("fn-busy", FN, "assign busy = (cnt_q != 8'd0);", "assign busy = 1'b0;", "isolation", CORE, "FP pipeline reports idle while operations are in flight")
mut("fn-passthrough", FN, "wire sel_a   = pa && !(HAS_ADD && pb);", "wire sel_a   = pa;", "numerics", CORE, "a lone operand is also added")
mut("fn-order", FN, ".in_a(a_data), .in_b(32'h3F800000), .in_c(b_data)", ".in_a(b_data), .in_b(32'h3F800000), .in_c(a_data)", "numerics", CORE, "operands swapped (must be bit-identical: expected EQUIVALENT)")
# ---- output / outport
mut("ou-fork-all", OU, "wire           dests_ready    = ((f_in_ready | ~dest_vec) == {NP{1'b1}});", "wire           dests_ready    = (|(f_in_ready & dest_vec));", "datapath", CORE, "fork does not wait for every destination (beats lost)")
mut("ou-redscat", OU, "rs_dest_q <= rs_found ? rs_next : rs_cur;", "rs_dest_q <= rs_cur;", "datapath", CORE, "reduce-scatter never moves to the next receiver")
mut("ou-clr", OU, "wire clr = !run || sclr;", "wire clr = sclr;", "isolation", CORE, "fork counters not cleared between collectives")
mut("op-arm", OP, "wire arm    = fail && run && en && (ld_nx != exp_len);", "wire arm    = 1'b0;", "failure", CORE, "no error terminators")
mut("op-term-idx", OP, ".in_data({op, dtype, IDX_W'(ld_nx), cid})", ".in_data({op, dtype, IDX_W'(ld_cnt), cid})", "failure", CORE, "terminator index off by the beat in the register")
mut("op-old", OP, "if (accept && !oe_q && !old_q) del_cnt <= del_cnt + 1'b1;", "if (accept && !oe_q) del_cnt <= del_cnt + 1'b1;", "isolation", CORE, "a leftover beat of a failed collective counts for the next one")
mut("op-load-run", OP, "wire load_data  = slot_free && !t_pend && f_valid && run && !sclr;", "wire load_data  = slot_free && !t_pend && f_valid && !sclr;", "failure", CORE, "beats loaded after the failure cycle")
mut("op-hold", OP, "wire slot_free  = !ov_q || o_ready;", "wire slot_free  = 1'b1;", "protocol", CORE, "an offered beat can be overwritten")
mut("op-last", OP, "ol_q <= (ld_cnt == exp_len - 1'b1);", "ol_q <= (ld_cnt == exp_len);", "protocol", CORE, "LAST flag misplaced")
mut("op-pend", OP, "assign pend      = en && (del_cnt != exp_len);", "assign pend      = en && (ld_cnt != exp_len);", "completion", CORE, "completion counts beats loaded, not accepted")
# ---- scheduler / queue
mut("sc-done", SC, "wire          done_now  = run && red_ok && out_done;", "wire          done_now  = run && red_ok;", "completion", CORE, "completion before every destination accepted its beats")
mut("sc-timeout", SC, "wire          to_hit    = (cfg_timeout != 32'd0) && (wd_q >= cfg_timeout);", "wire          to_hit    = 1'b0;", "failure", CORE, "watchdog disabled")
mut("sc-abort", SC, "if (ctl_abort) begin", "if (1'b0) begin", "failure", CORE, "abort ignored")
mut("sc-ref", SC, "if (q_err != E_CMD_CID) begin\n              ref_valid <= 1'b1;", "if (1'b1) begin\n              ref_valid <= 1'b1;", "ordering", CORE, "a rejected non-monotonic ID moves the reference ID")
mut("sc-pf", SC, "wire          pf_hit    = |(part_fail & inv);", "wire          pf_hit    = 1'b0;", "failure", CORE, "participant failure ignored")
mut("sc-flush", SC, "          if (!red_busy) begin\n            if (soft_q) begin", "          if (1'b1) begin\n            if (soft_q) begin", "isolation", CORE, "flush does not wait for the FP pipelines to drain")
mut("sc-missing", SC, "f_maskA[NP-1:0] = c_send & ~in_done & ~in_hvalid;", "f_maskA[NP-1:0] = c_send & ~in_done;", "failure", CORE, "timeout blames back-pressured senders")
mut("sc-progress", SC, "if (progress) wd_q <= '0;", "if (1'b0) wd_q <= '0;", "failure", CORE, "watchdog never re-armed by progress")
mut("cq-cid", CQ, "if (have_last && !cid_after(cmd_cid(cmd_data), last_cid)) verdict = E_CMD_CID;", "if (1'b0) verdict = E_CMD_CID;", "ordering", CORE, "non-monotonic collective IDs accepted")
mut("co-term", CO, ".part_fail(part_fail),", ".part_fail('0),", "failure", CORE, "part_fail not wired")
# ---- network adapter
mut("na-dup-old", NA, "wire              seq_old  = same_x && (rx_seq < exp_seq);", "wire              seq_old  = 1'b0;", "network", [NET], "already delivered sequence numbers are accepted again")
mut("na-dup-slot", NA, "wire              seq_dup  = same_x && !seq_old && !seq_far && slot_v[rx_seq[WB-1:0]];", "wire              seq_dup  = 1'b0;", "network", [NET], "duplicate inside the window overwrites the stored element")
mut("na-far", NA, "wire              seq_far  = same_x && !seq_old && (dseq >= IDX_W'(WIN));", "wire              seq_far  = 1'b0;", "network", [NET], "beats beyond the reorder window are stored")
mut("na-timeout", NA, "wire to_hit   = (cfg_timeout != 32'd0) && cur_open && (idle_cnt >= cfg_timeout);", "wire to_hit   = 1'b0;", "network", [NET], "link watchdog disabled")
mut("na-credit", NA, "wire tx_go = o_valid && (cred_q != '0) && !failed;", "wire tx_go = o_valid && !failed;", "network", [NET], "credit limit not enforced")
mut("na-stale", NA, "(have_done && !cid_after(rx_xfer, done_xfer));", "1'b0;", "network", [NET], "stale retransmissions of a finished transfer reopen it")
mut("na-last", NA, "if (slot_l[exp_slot]) begin\n              cur_open <= 1'b0;", "if (1'b0) begin\n              cur_open <= 1'b0;", "network", [NET], "transfer never closes")
mut("na-ack", NA, ".in_data({cpl_blame, cpl_err, cpl_ok, cpl_cid})", ".in_data({cpl_ok, cpl_err, cpl_blame, cpl_cid})", "network", [NET], "ack fields swapped")
mut("na-fail", NA, "assign fail_out = failed;", "assign fail_out = 1'b0;", "network", [NET], "link failure not reported to the core")
# ---- memory adapter
mut("mr-align", MR, "if (misal)              begin", "if (1'b0)              begin", "memory", [MEM], "unaligned buffers accepted")
mut("mr-len", MR, "else if (toolong)       begin", "else if (1'b0)       begin", "memory", [MEM], "over-long / wrapping buffers accepted")
mut("mr-guard", MR, "if (!gr_ok)            begin", "if (1'b0)            begin", "memory", [MEM], "guard refusal ignored on loads")
mut("mr-aperture", MR, "else if (!pa_in_ap)    begin", "else if (1'b0)    begin", "memory", [MEM], "aperture check off on loads")
mut("mr-pa", MR, "else begin pa_q <= gr_pa[MM_AW-1:0];", "else begin pa_q <= iova_q[MM_AW-1:0];", "memory", [MEM], "load uses the IOVA, not the guard's physical address")
mut("mr-errbeat", MR, "if (err_q) begin if (!f_valid) st_q <= S_ERRBEAT; end", "if (err_q) begin if (!f_valid) st_q <= S_CPL; end", "memory", [MEM], "failed load gives no error beat")
mut("mw-guard", MW, "if (!gr_ok)         begin", "if (1'b0)         begin", "memory", [MEM], "guard refusal ignored on stores")
mut("mw-pa", MW, "else begin pa_q <= gr_pa[MM_AW-1:0]; bel_q <= burst_el; st_q <= S_STREAM; end", "else begin pa_q <= iova_q[MM_AW-1:0]; bel_q <= burst_el; st_q <= S_STREAM; end", "memory", [MEM], "store uses the IOVA, not the guard's physical address")
mut("mw-ack", MW, "S_FINISH:  if (outst_q == '0 && !mr_valid) st_q <= S_CPL;", "S_FINISH:  st_q <= S_CPL;", "memory", [MEM], "store completes before the write responses")
mut("mw-align", MW, "if (misal)             begin", "if (1'b0)             begin", "memory", [MEM], "unaligned store accepted")
mut("mw-discard", MW, "if (misal)             begin code_q <= M_ALIGN; st_q <= S_DISCARD; end", "if (misal)             begin code_q <= M_ALIGN; st_q <= S_FINISH; end", "memory", [MEM], "refused store leaves the result stream undrained")
mut("mw-strobe", "rtl/sf_collective_mem_adapter.sv", "assign m_req_be    = {{(W-4){1'b0}}, 4'hF};", "assign m_req_be    = {{(W-4){1'b0}}, 4'h7};", "memory", [MEM], "top byte of every element not written")

# ---- bench configurations
BENCH = {
  FLAT: ("scripts/build_tb.sh", ["NP=3", "FP32_EN=1", "REDSCAT_EN=1", "ALLGATHER_EN=1", "IN_DEPTH=2", "OUT_DEPTH=2"], "tb_main", ["--seed", "1", "--quiet"], ["--seed", "2", "--quiet"]),
  TREE: ("scripts/build_tt.sh", ["FAN=2", "H=2", "FP32_EN=1"], "tt_main", ["--seed", "1", "--quiet"], ["--seed", "2", "--quiet"]),
  NET:  ("scripts/build_tn.sh", ["WIN=4", "CREDITS=4"], "tn_main", ["--seed", "1", "--quiet"], ["--seed", "2", "--quiet"]),
  MEM:  ("scripts/build_tm.sh", [], "tm_main", ["--seed", "1", "--quiet"], ["--seed", "2", "--quiet"]),
}

def clone(tag):
    d = os.path.join(ROOT, "build", "mut", tag)
    shutil.rmtree(d, ignore_errors=True); os.makedirs(d + "/build")
    for sub in ("rtl", "sim", "scripts"): shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub))
    for sub in ("third_party", "tests"): os.symlink(os.path.join(ROOT, sub), os.path.join(d, sub))
    if os.path.isdir(os.path.join(ROOT, "build/softfloat")): os.symlink(os.path.join(ROOT, "build/softfloat"), os.path.join(d, "build/softfloat"))
    return d

def run(cmd, cwd, timeout=900, env=None):
    e = dict(os.environ); e["VJ"] = "1"
    if env: e.update(env)
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout, env=e)
    return p.returncode, p.stdout

def eval_bench(proj, bname):
    script, params, exe, *seeds = BENCH[bname]
    rc, out = run([script, "b_" + bname] + params, proj)
    if rc != 0: return "BUILD_FAIL", out[-600:]
    for s in seeds:
        rc, out = run([f"build/b_{bname}/{exe}"] + s, proj, timeout=600)
        if rc != 0: return "KILLED", [l for l in out.splitlines() if "FAIL" in l][:3]
    return "PASS", ""

def do_mutant(m):
    i, f, a, b, cls, benches, desc = m
    proj = clone("m_" + i)
    path = os.path.join(proj, f)
    src = open(path).read()
    n = src.count(a)
    if n != 1: return (i, "BAD_PATTERN", f"pattern occurs {n} times", m)
    open(path, "w").write(src.replace(a, b))
    for bn in benches:
        st, info = eval_bench(proj, bn)
        if st == "BUILD_FAIL": return (i, "BUILD_FAIL", info, m)
        if st == "KILLED": 
            shutil.rmtree(proj, ignore_errors=True)
            return (i, "KILLED", bn + ": " + (info[0].strip() if info else ""), m)
    shutil.rmtree(proj, ignore_errors=True)
    return (i, "SURVIVED", "", m)

def main():
    jobs = 3
    only = None
    if "--jobs" in sys.argv: jobs = int(sys.argv[sys.argv.index("--jobs") + 1])
    if "--only" in sys.argv: only = sys.argv[sys.argv.index("--only") + 1]
    muts = [m for m in M if not only or any(o == m[0] or (o in m[4]) for o in only.split(","))]
    if "--list" in sys.argv:
        for m in muts: print(f"{m[0]:18s} {m[4]:10s} {m[6]}")
        return
    os.makedirs("reports", exist_ok=True)
    # ---- baseline gate
    print("baseline gate ...", flush=True)
    proj = clone("baseline")
    used = sorted({b for m in muts for b in m[5]})
    for bn in used:
        st, info = eval_bench(proj, bn)
        print(f"  baseline {bn}: {st}", flush=True)
        if st != "PASS": print("BASELINE FAILS -- refusing to mutate:", info); sys.exit(2)
    t0 = time.time(); res = []
    with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
        for r in ex.map(do_mutant, muts):
            res.append(r); print(f"  {r[0]:18s} {r[1]:11s} {r[2][:100]}", flush=True)
    killed = sum(1 for r in res if r[1] == "KILLED"); surv = [r for r in res if r[1] == "SURVIVED"]; bad = [r for r in res if r[1] in ("BUILD_FAIL", "BAD_PATTERN")]
    with open("reports/mutation.md", "w") as fh:
        fh.write(f"# Mutation report\n\nBenches per mutant: flat core (NP=3, FP32, reduce-scatter, all-gather, depth 2), tree (FAN=2 H=2, FP32), network adapter (WIN=4 CREDITS=4), memory system; 2 seeds each. Baseline gate: all benches pass unmutated.\n\n")
        fh.write(f"**{killed} of {len(res)} mutants killed**; survivors: {len(surv)}; invalid (build error / bad pattern): {len(bad)}.  ({int(time.time()-t0)} s)\n\n")
        fh.write("| mutant | class | injected bug | result | detected by |\n|---|---|---|---|---|\n")
        for r in res: fh.write(f"| {r[0]} | {r[3][4]} | {r[3][6]} | {r[1]} | {r[2][:90].replace('|', '/')} |\n")
    print(f"\n{killed}/{len(res)} killed, {len(surv)} survived, {len(bad)} invalid")
    sys.exit(0 if not surv and not bad else 1)
main()
