#!/bin/bash
# Build the memory-system Verilator bench (collective core + adapters + real StreamDMA + real MemoryMatrix + guards): scripts/build_tm.sh NAME [PARAM=VALUE...]
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd); name="$1"; shift
G=""; ML=1024
for a in "$@"; do k="${a%%=*}"; v="${a#*=}"; case "$k" in MAX_LEN) ML=$v; G="$G -GMAX_LEN=$v";; *) G="$G -G$k=$v";; esac; done
[[ "$G" == *MAX_LEN* ]] || G="$G -GMAX_LEN=$ML"
mkdir -p build/$name
verilator --cc --exe --build -j ${VJ:-4} -O2 -Wno-fatal --top-module sf_collective_mm_system -Mdir build/$name rtl/lint.vlt \
  -f rtl/filelist.f -f rtl/filelist_mm.f rtl/sf_collective_mem_rd.sv rtl/sf_collective_mem_wr.sv rtl/sf_collective_mem_adapter.sv sim/sf_collective_mm_system.sv $G \
  -CFLAGS "-O2 -std=c++17 -DTB_MAXLEN=$ML -I$ROOT/tests" $ROOT/tests/tm_main.cpp -o tm_main > build/$name/build.log 2>&1 || { grep -E "%Error|error:" build/$name/build.log | head -30; exit 1; }
echo "built build/$name/tm_main"
