# Formal verification results

Yosys 0.33 + yosys-smtbmc + Z3 4.8.12.  **Exhaustive** = purely combinational harness, depth 1, every input value (Z3).  **BMC** = bounded model check (Yosys SAT engine) to the stated depth from the reset state: no counterexample within that depth; NOT an unbounded proof.  Inputs of the sequential harnesses are free (the solver chooses them) except for the stated environment assumptions (a source holds a beat until accepted; short commands; pipelines do not become busy while nothing runs).

| job | kind | depth | result | time | what is checked |
|---|---|---|---|---|---|
| cid | exhaustive | 1 | PASS | 0 s | collective-ID order: irreflexive, asymmetric, total, successor, windowed transitivity |
| cmd_np4_all | exhaustive | 1 | PASS | 2 s | cmd_validate == acceptance rules, root node, all options (all 2^64 commands) |
| cmd_np8_min | exhaustive | 1 | PASS | 2 s | cmd_validate == rules, 8 participants, integer-only build |
| cmd_np3_int | exhaustive | 1 | PASS | 2 s | cmd_validate == rules, tree-interior node |
| cmd_np2_int | exhaustive | 1 | PASS | 2 s | cmd_validate == rules, tree-interior node, two ports |
| adapter_d3 | BMC | 14 | PASS | 31 s | ingress adapter: exactly-once, in-order, header-checked elements; stall-future / drop-stale rules; shadow queue |
| adapter_d1 | BMC | 14 | PASS | 5 s | ingress adapter, 1-deep buffer |
| adapter_wit1 | witness (reachability) | 14 | PASS | 2 s | WITNESS: two elements can be stored (must FAIL) |
| adapter_wit2 | witness (reachability) | 14 | PASS | 2 s | WITNESS: a protocol error can occur (must FAIL) |
| adapter_wit3 | witness (reachability) | 14 | PASS | 1 s | WITNESS: elements can be popped (must FAIL) |
| outport_d2 | BMC | 16 | PASS | 5 s | output port: an offered beat is stable until accepted; well-formed data beats and terminators |
| outport_d1 | BMC | 16 | PASS | 3 s | output port, minimal buffers |
| outport_wit1 | witness (reachability) | 16 | PASS | 1 s | WITNESS: a terminator can be offered (must FAIL) |
| outport_wit2 | witness (reachability) | 16 | PASS | 1 s | WITNESS: a complete stream can be offered (must FAIL) |
| outport_wit3 | witness (reachability) | 16 | PASS | 1 s | WITNESS: a beat can be stalled (must FAIL) |
| sched_np2 | BMC | 16 | PASS | 4 s | scheduler: one record per command, success only after the done conditions, flush before a failure record, context stable |
| sched_np3 | BMC | 14 | PASS | 3 s | scheduler, 3 participants |
| sched_wit1 | witness (reachability) | 16 | PASS | 2 s | WITNESS: a successful non-empty collective can complete (must FAIL) |
| sched_wit2 | witness (reachability) | 16 | PASS | 2 s | WITNESS: a failed collective can reach its record (must FAIL) |
| sched_wit3 | witness (reachability) | 16 | PASS | 2 s | WITNESS: a rejected command can reach its record (must FAIL) |
| red_wit | witness (reachability) | 4 | PASS | 1 s | WITNESS: an element can be reduced (must FAIL) |
| red_np2_sum_i32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (SUM INT32, 2 participants); overflow flag == exact-sum test; all-or-none aligned pop |
| red_np2_sum_u32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (SUM UINT32, 2 participants); overflow flag == exact-sum test; all-or-none aligned pop |
| red_np2_min_i32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (MIN INT32, 2 participants); all-or-none aligned pop |
| red_np2_min_u32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (MIN UINT32, 2 participants); all-or-none aligned pop |
| red_np2_max_i32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (MAX INT32, 2 participants); all-or-none aligned pop |
| red_np2_max_u32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (MAX UINT32, 2 participants); all-or-none aligned pop |
| red_np2_and | BMC | 4 | PASS | 0 s | tree reduction == independent fold (AND, 2 participants); all-or-none aligned pop |
| red_np2_or | BMC | 4 | PASS | 1 s | tree reduction == independent fold (OR, 2 participants); all-or-none aligned pop |
| red_np2_xor | BMC | 4 | PASS | 1 s | tree reduction == independent fold (XOR, 2 participants); all-or-none aligned pop |
| red_np3_sum_i32 | BMC | 4 | PASS | 2 s | tree reduction == independent fold (SUM INT32, 3 participants); overflow flag == exact-sum test; all-or-none aligned pop |
| red_np3_sum_u32 | BMC | 4 | PASS | 2 s | tree reduction == independent fold (SUM UINT32, 3 participants); overflow flag == exact-sum test; all-or-none aligned pop |
| red_np3_min_i32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (MIN INT32, 3 participants); all-or-none aligned pop |
| red_np3_min_u32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (MIN UINT32, 3 participants); all-or-none aligned pop |
| red_np3_max_i32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (MAX INT32, 3 participants); all-or-none aligned pop |
| red_np3_max_u32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (MAX UINT32, 3 participants); all-or-none aligned pop |
| red_np3_and | BMC | 4 | PASS | 1 s | tree reduction == independent fold (AND, 3 participants); all-or-none aligned pop |
| red_np3_or | BMC | 4 | PASS | 1 s | tree reduction == independent fold (OR, 3 participants); all-or-none aligned pop |
| red_np3_xor | BMC | 4 | PASS | 1 s | tree reduction == independent fold (XOR, 3 participants); all-or-none aligned pop |
| red_np4_sum_i32 | BMC | 4 | PASS | 8 s | tree reduction == independent fold (SUM INT32, 4 participants); overflow flag == exact-sum test; all-or-none aligned pop |
| red_np4_sum_u32 | BMC | 4 | PASS | 6 s | tree reduction == independent fold (SUM UINT32, 4 participants); overflow flag == exact-sum test; all-or-none aligned pop |
| red_np4_min_i32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (MIN INT32, 4 participants); all-or-none aligned pop |
| red_np4_min_u32 | BMC | 4 | PASS | 1 s | tree reduction == independent fold (MIN UINT32, 4 participants); all-or-none aligned pop |
| red_np4_max_i32 | BMC | 4 | PASS | 2 s | tree reduction == independent fold (MAX INT32, 4 participants); all-or-none aligned pop |
| red_np4_max_u32 | BMC | 4 | PASS | 2 s | tree reduction == independent fold (MAX UINT32, 4 participants); all-or-none aligned pop |
| red_np4_and | BMC | 4 | PASS | 1 s | tree reduction == independent fold (AND, 4 participants); all-or-none aligned pop |
| red_np4_or | BMC | 4 | PASS | 1 s | tree reduction == independent fold (OR, 4 participants); all-or-none aligned pop |
| red_np4_xor | BMC | 4 | PASS | 1 s | tree reduction == independent fold (XOR, 4 participants); all-or-none aligned pop |

**48 of 48 jobs pass.**
