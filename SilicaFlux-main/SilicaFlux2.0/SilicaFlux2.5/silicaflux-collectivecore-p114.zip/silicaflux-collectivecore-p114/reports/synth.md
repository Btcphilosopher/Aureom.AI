# Synthesis estimates (Yosys 0.33, no PDK)

**What this is:** cell / flip-flop / LUT counts from Yosys technology-independent and FPGA mappings of the synthesizable RTL.  **What it is not:** no timing, no clock frequency, no area in um^2, no power, no place-and-route, no hardware.  Counts depend on Yosys' optimisation and say nothing about timing closure.  The FIFOs (`sfd_fifo`) are register arrays here (no SRAM macro mapping); a silicon build would map them to RAM macros.  The FPGA columns exclude the distributed-RAM primitives Yosys inferred for FIFO storage on those targets (they are neither LUT nor FF in these columns), while the generic mapping turns every storage bit into a flip-flop; that is why the generic FF counts are much larger than the FPGA FF counts.  Defaults: IN_DEPTH = OUT_DEPTH = CMD_DEPTH = CPL_DEPTH = 4, TERM_DEPTH = 2, MAX_LEN = 4096.

| configuration | generic cells | generic FFs | ECP5 LUT4 | ECP5 FFs | Xilinx-7 LUTs | Xilinx-7 FFs | latches |
|---|---|---|---|---|---|---|---|
| core NP=2 (INT) | 18459 | 2784 | 8294 | 1573 | 4023 | 1572 | 0 |
| core NP=4 (INT) | 25572 | 3818 | 10099 | 1901 | 5268 | 1900 | 0 |
| core NP=8 (INT) | 39841 | 5883 | 14188 | 2557 | 8193 | 2556 | 0 |
| core NP=4 (INT + reduce-scatter + all-gather) | 29560 | 3964 | 14133 | 2015 | 6450 | 2014 | 0 |
| core NP=2 tree-interior node (INT) | 20183 | 3221 | 8697 | 1663 | 4306 | 1663 | 0 |
| core NP=2 (INT + FP32) | 23389 | 3405 | 10267 | 2168 | 5560 | 2146 | 0 |
| core NP=4 (INT + FP32) | 39809 | 5563 | 15642 | 3618 | 10076 | 3617 | 0 |
| network adapter (WIN=8) | 2771 | 538 | 1226 | 450 | 593 | 450 | 0 |
| memory adapter (load + store engines) | 3917 | 464 | 1209 | 336 | 859 | 336 | 0 |

Latches are counted on the proc-ed, flattened netlist (`select -count t:$dlatch`): 0 means no unintended latch in any configuration.
