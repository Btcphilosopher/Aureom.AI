# Mutation report

Benches per mutant: flat core (NP=3, FP32, reduce-scatter, all-gather, depth 2), tree (FAN=2 H=2, FP32), network adapter (WIN=4 CREDITS=4), memory system; 2 seeds each. Baseline gate: all benches pass unmutated.

**68 of 77 mutants killed**; survivors: 9; invalid (build error / bad pattern): 0.  (874 s)

| mutant | class | injected bug | result | detected by |
|---|---|---|---|---|
| sa-dup-off | protocol | duplicate elements are not detected | KILLED | flat: duplicate        FAIL  (283 cycles) |
| sa-seq-off | protocol | element gaps are not detected | KILLED | flat: faults           FAIL  (3691 cycles) |
| sa-early-drop | ordering | beats of a future collective are consumed (dropped) instead of held | KILLED | flat: ops_all          FAIL  (2000000 cycles) |
| sa-cid-ignored | isolation | beats of ANY collective are accepted into the running one | KILLED | flat: missing          FAIL  (744 cycles) |
| sa-pid-off | protocol | participant id not checked | KILLED | flat: faults           FAIL  (2502 cycles) |
| sa-dtop-off | protocol | data type / operation echo not checked | KILLED | flat: faults           FAIL  (2540 cycles) |
| sa-sender-off | protocol | a non-sender's data is accepted | SURVIVED |  |
| sa-last-off | protocol | LAST flag not checked | KILLED | flat: faults           FAIL  (2520 cycles) |
| sa-len-off | protocol | elements beyond the command length accepted | KILLED | flat: faults           FAIL  (2501 cycles) |
| sa-peer-off | failure | source error flag ignored | KILLED | flat: faults           FAIL  (2496 cycles) |
| sa-clr-leak | isolation | input buffer / index state not cleared between collectives | KILLED | flat: ops_all          FAIL  (575 cycles) |
| sa-stale-block | ordering | stale beats are held instead of discarded | KILLED | flat: stale            FAIL  (47 cycles) |
| sa-expidx | datapath | element counter skips | KILLED | flat: ops_all          FAIL  (669 cycles) |
| pk-unsigned-cmp | numerics | UINT32 MIN/MAX compared as signed | KILLED | flat: ops_all          FAIL  (1037 cycles) |
| pk-signed-cmp | numerics | INT32 MIN/MAX compared as unsigned | KILLED | flat: ops_all          FAIL  (1037 cycles) |
| pk-max-swap | numerics | MAX returns the minimum | KILLED | flat: ops_all          FAIL  (1037 cycles) |
| pk-sum | numerics | SUM subtracts | KILLED | flat: ops_all          FAIL  (1037 cycles) |
| pk-xor | numerics | XOR computes OR | KILLED | flat: ops_all          FAIL  (1037 cycles) |
| pk-reduce-root | validation | REDUCE accepts several roots | KILLED | flat: cmd_reject       FAIL  (458 cycles) |
| pk-len-limit | validation | length limit off by one | KILLED | flat: cmd_reject       FAIL  (460 cycles) |
| pk-cid-after | ordering | collective-ID order inverted | KILLED | flat: ops_all          FAIL  (468 cycles) |
| pk-fp-rm | validation | illegal rounding modes 5,6 accepted | KILLED | flat: fp32_reject      FAIL  (109 cycles) |
| pk-op-legal | validation | FP32 accepts every integer operator | KILLED | flat: fp32_reject      FAIL  (120 cycles) |
| rd-ovf-signed | numerics | signed overflow flag never raised | KILLED | flat: ops_all          FAIL  (1037 cycles) |
| rd-ovf-unsigned | numerics | unsigned carry flag too late | KILLED | flat: special_values   FAIL  (847 cycles) |
| rd-align | isolation | elements combined before every participant has delivered (misalignment) | KILLED | flat: backpressure     FAIL  (9423 cycles) |
| rd-pop | datapath | only participant 0's head is popped | KILLED | flat: ops_all          FAIL  (1317 cycles) |
| rd-done | completion | reduction reported done while the last result is still in the stage | SURVIVED |  |
| rd-gather-order | datapath | all-gather never advances to the next participant | KILLED | flat: redscat_gather   FAIL  (2000000 cycles) |
| rd-clr | isolation | reduction state not cleared between collectives | KILLED | flat: ops_all          FAIL  (2000000 cycles) |
| rd-flags-fp | numerics | FP exception flags never recorded | KILLED | flat: faults           FAIL  (2498 cycles) |
| rd-fp-ready | datapath | FP32 heads never popped | KILLED | flat: faults           FAIL  (2497 cycles) |
| fn-one | numerics | FMA multiplier 2.0 instead of 1.0 | KILLED | flat: faults           FAIL  (2498 cycles) |
| fn-rm | numerics | rounding mode ignored | KILLED | flat: faults           FAIL  (2498 cycles) |
| fn-busy | isolation | FP pipeline reports idle while operations are in flight | KILLED | flat: fp32_flush       FAIL  (5666 cycles) |
| fn-passthrough | numerics | a lone operand is also added | SURVIVED |  |
| fn-order | numerics | operands swapped (must be bit-identical: expected EQUIVALENT) | SURVIVED |  |
| ou-fork-all | datapath | fork does not wait for every destination (beats lost) | KILLED | flat: backpressure     FAIL  (22001105 cycles) |
| ou-redscat | datapath | reduce-scatter never moves to the next receiver | KILLED | flat: redscat_gather   FAIL  (2000000 cycles) |
| ou-clr | isolation | fork counters not cleared between collectives | KILLED | flat: redscat_gather   FAIL  (2000000 cycles) |
| op-arm | failure | no error terminators | KILLED | flat: missing          FAIL  (1376 cycles) |
| op-term-idx | failure | terminator index off by the beat in the register | KILLED | flat: duplicate        FAIL  (247 cycles) |
| op-old | isolation | a leftover beat of a failed collective counts for the next one | KILLED | flat: fp32_flush       FAIL  (6177 cycles) |
| op-load-run | failure | beats loaded after the failure cycle | SURVIVED |  |
| op-hold | protocol | an offered beat can be overwritten | KILLED | flat: backpressure     FAIL  (24000000 cycles) |
| op-last | protocol | LAST flag misplaced | KILLED | flat: ops_all          FAIL  (1037 cycles) |
| op-pend | completion | completion counts beats loaded, not accepted | KILLED | flat: backpressure     FAIL  (8216 cycles) |
| sc-done | completion | completion before every destination accepted its beats | KILLED | flat: backpressure     FAIL  (9999 cycles) |
| sc-timeout | failure | watchdog disabled | KILLED | flat: missing          FAIL  (2000000 cycles) |
| sc-abort | failure | abort ignored | KILLED | flat: abort            FAIL  (1809 cycles) |
| sc-ref | ordering | a rejected non-monotonic ID moves the reference ID | SURVIVED |  |
| sc-pf | failure | participant failure ignored | KILLED | flat: part_fail        FAIL  (1833 cycles) |
| sc-flush | isolation | flush does not wait for the FP pipelines to drain | KILLED | flat: fp32_flush       FAIL  (5666 cycles) |
| sc-missing | failure | timeout blames back-pressured senders | KILLED | flat: missing          FAIL  (1376 cycles) |
| sc-progress | failure | watchdog never re-armed by progress | SURVIVED |  |
| cq-cid | ordering | non-monotonic collective IDs accepted | KILLED | flat: cmd_reject       FAIL  (2000000 cycles) |
| co-term | failure | part_fail not wired | KILLED | flat: part_fail        FAIL  (1833 cycles) |
| na-dup-old | network | already delivered sequence numbers are accepted again | KILLED | net: reorder_dup    FAIL  (24000000 cycles, 36 collectives; dup=0 stale=0 reorder=0) |
| na-dup-slot | network | duplicate inside the window overwrites the stored element | KILLED | net: reorder_dup    FAIL  (3553 cycles, 36 collectives; dup=58 stale=16 reorder=914) |
| na-far | network | beats beyond the reorder window are stored | KILLED | net: inorder        FAIL  (197 cycles, 8 collectives; dup=32 stale=0 reorder=118) |
| na-timeout | network | link watchdog disabled | KILLED | net: lost_beat      FAIL  (8800012 cycles, 8 collectives; dup=0 stale=0 reorder=3) |
| na-credit | network | credit limit not enforced | KILLED | net: credits        FAIL  (823 cycles, 6 collectives; dup=0 stale=0 reorder=340) |
| na-stale | network | stale retransmissions of a finished transfer reopen it | KILLED | net: reorder_dup    FAIL  (24000000 cycles, 36 collectives; dup=13 stale=0 reorder=40) |
| na-last | network | transfer never closes | KILLED | net: inorder        FAIL  (2000000 cycles, 8 collectives; dup=0 stale=0 reorder=19) |
| na-ack | network | ack fields swapped | KILLED | net: inorder        FAIL  (245 cycles, 8 collectives; dup=0 stale=0 reorder=150) |
| na-fail | network | link failure not reported to the core | KILLED | net: lost_beat      FAIL  (8800012 cycles, 8 collectives; dup=0 stale=15 reorder=6) |
| mr-align | memory | unaligned buffers accepted | KILLED | mem: protection   FAIL  (17487 cycles) |
| mr-len | memory | over-long / wrapping buffers accepted | KILLED | mem: protection   FAIL  (18448 cycles) |
| mr-guard | memory | guard refusal ignored on loads | KILLED | mem: protection   FAIL  (17634 cycles) |
| mr-aperture | memory | aperture check off on loads | KILLED | mem: protection   FAIL  (17487 cycles) |
| mr-pa | memory | load uses the IOVA, not the guard's physical address | SURVIVED |  |
| mr-errbeat | memory | failed load gives no error beat | KILLED | mem: protection   FAIL  (10130418 cycles) |
| mw-guard | memory | guard refusal ignored on stores | KILLED | mem: protection   FAIL  (17485 cycles) |
| mw-ack | memory | store completes before the write responses | SURVIVED |  |
| mw-align | memory | unaligned store accepted | KILLED | mem: protection   FAIL  (17423 cycles) |
| mw-discard | memory | refused store leaves the result stream undrained | KILLED | mem: protection   FAIL  (2031984 cycles) |
| mw-strobe | memory | top byte of every element not written | KILLED | mem: flow         FAIL  (22918 cycles) |
