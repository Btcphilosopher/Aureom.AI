# Lint report (Verilator 5.020, -Wall)

| configuration | warnings |
|---|---|
| core NP=2 default | 0 |
| core NP=3 depth 1/1/1/1/1 | 0 |
| core NP=8 | 0 |
| core NP=5 + reduce-scatter + all-gather | 0 |
| core NP=2 tree-interior UP_PID=1 | 0 |
| core NP=4 tree-interior + RS + AG | 0 |
| core NP=2 + FP32 | 0 |
| core NP=3 + FP32 | 0 |
| core NP=8 + FP32 + RS + AG | 0 |
| FP32 tree node | 0 |
| network adapter WIN=2 | 0 |
| network adapter WIN=16 CREDITS=16 | 0 |
| memory adapter | 0 |
| memory adapter AW=40 MM_AW=24 DATA_WIDTH=256 | 0 |

## Negative elaboration tests (each must be rejected)

| illegal parameters | rejected |
|---|---|
| NP=1 | yes |
| NP=9 | yes |
| MAX_LEN=0 | yes |
| MAX_LEN * NP >= 2^20 (MAX_LEN=200000, NP=8) | yes |
| IN_DEPTH=0 | yes |
| OUT_DEPTH=0 | yes |
| CMD_DEPTH=0 | yes |
| TERM_DEPTH=0 | yes |
| UP_PID=8 | yes |

Vendored third_party files are waived unchanged in rtl/lint.vlt; package constants consumed elsewhere are waived for UNUSEDPARAM.
