# Simulation regression

Verilator 5.020; every bench is deterministic per seed; seeds 1..8 per configuration.  "colls" = collectives scored against the independent reference (scoreboard); the count restarts at each hard reset inside the reset scenarios, so it is a lower bound.

| bench | configuration | tests | seeds passing | collectives scored | simulated cycles |
|---|---|---|---|---|---|
| flat | flat NP=2 (default depths 4/4) | 30 | 8 / 8 | 5,643 | 733,381 |
| flat | flat NP=2 depth 1/1/1/1 | 30 | 8 / 8 | 5,683 | 817,690 |
| flat | flat NP=2 depth 8/8 | 30 | 8 / 8 | 5,576 | 717,878 |
| flat | flat NP=3 depth 2/3 | 30 | 8 / 8 | 5,996 | 843,327 |
| flat | flat NP=4 | 30 | 8 / 8 | 6,145 | 856,327 |
| flat | flat NP=8 depth 3/2 | 30 | 8 / 8 | 7,205 | 1,088,192 |
| flat | flat NP=2 + reduce-scatter + all-gather | 30 | 8 / 8 | 6,043 | 738,282 |
| flat | flat NP=4 + RS + AG depth 2/2 | 30 | 8 / 8 | 6,525 | 961,006 |
| flat | flat NP=8 + RS + AG | 30 | 8 / 8 | 7,492 | 1,261,865 |
| flat | flat NP=2 + FP32 | 30 | 8 / 8 | 6,657 | 808,701 |
| flat | flat NP=3 + FP32 depth 2/2 | 30 | 8 / 8 | 6,948 | 920,277 |
| flat | flat NP=4 + FP32 | 30 | 8 / 8 | 7,148 | 950,348 |
| flat | flat NP=5 + FP32 + RS + AG depth 1/1 | 30 | 8 / 8 | 7,847 | 1,303,381 |
| flat | flat NP=8 + FP32 | 30 | 8 / 8 | 8,240 | 1,163,972 |
| tree | tree FAN=2 H=1 (root only) | 14 | 8 / 8 | 2,603 | 243,550 |
| tree | tree FAN=2 H=2 | 14 | 8 / 8 | 2,671 | 301,574 |
| tree | tree FAN=2 H=3 | 14 | 8 / 8 | 2,749 | 337,221 |
| tree | tree FAN=3 H=2 depth 2/2 | 14 | 8 / 8 | 2,797 | 351,143 |
| tree | tree FAN=4 H=2 | 14 | 8 / 8 | 2,950 | 354,192 |
| tree | tree FAN=2 H=3 depth 1 | 14 | 8 / 8 | 2,756 | 373,567 |
| tree | tree FAN=2 H=2 + FP32 | 14 | 8 / 8 | 2,738 | 313,000 |
| tree | tree FAN=3 H=2 + FP32 | 14 | 8 / 8 | 2,849 | 348,669 |
| tree | tree FAN=2 H=3 + FP32 depth 2/2 | 14 | 8 / 8 | 2,794 | 351,272 |
| tree | tree FAN=4 H=2 + FP32 | 14 | 8 / 8 | 3,012 | 361,305 |
| net | network WIN=2 CREDITS=1 | 9 | 8 / 8 | 1,083 | 211,536 |
| net | network WIN=4 CREDITS=3 | 9 | 8 / 8 | 1,061 | 142,037 |
| net | network WIN=8 CREDITS=8 | 9 | 8 / 8 | 1,064 | 125,430 |
| net | network WIN=16 CREDITS=16 | 9 | 8 / 8 | 1,070 | 122,948 |
| mem | memory system (StreamDMA + MemoryMatrix + adapters) | 5 | 8 / 8 | 416 | 689,920 |

**232 of 232 bench runs pass; 125,761 collectives scored; 17,791,991 simulated cycles.**  (193 s)
