# Formal sensitivity: injected bugs vs formal jobs

Each row injects one deliberate RTL bug and runs ONE named formal job on the mutated design; the job must produce a counterexample.

| mutant | formal job | injected bug | result |
|---|---|---|---|
| sa-dup-off | adapter_d3 | duplicate elements are not detected | KILLED (counterexample) |
| sa-seq-off | adapter_d3 | element gaps are not detected | KILLED (counterexample) |
| sa-early-drop | adapter_d3 | beats of a future collective are consumed (dropped) instead of held | KILLED (counterexample) |
| sa-cid-ignored | adapter_d3 | beats of ANY collective are accepted into the running one | KILLED (counterexample) |
| sa-pid-off | adapter_d3 | participant id not checked | KILLED (counterexample) |
| sa-sender-off | adapter_d3 | a non-sender's data is accepted | KILLED (counterexample) |
| sa-last-off | adapter_d3 | LAST flag not checked | KILLED (counterexample) |
| sa-dtop-off | adapter_d3 | data type / operation echo not checked | KILLED (counterexample) |
| sa-clr-leak | adapter_d3 | input buffer / index state not cleared between collectives | KILLED (counterexample) |
| op-hold | outport_d2 | an offered beat can be overwritten | KILLED (counterexample) |
| op-last | outport_d2 | LAST flag misplaced | KILLED (counterexample) |
| sc-done | sched_np2 | completion before every destination accepted its beats | KILLED (counterexample) |
| sc-flush | sched_np2 | flush does not wait for the FP pipelines to drain | KILLED (counterexample) |
| pk-sum | red_np2_sum_i32 | SUM subtracts | KILLED (counterexample) |
| pk-unsigned-cmp | red_np2_min_u32 | UINT32 MIN/MAX compared as signed | KILLED (counterexample) |
| pk-signed-cmp | red_np2_max_i32 | INT32 MIN/MAX compared as unsigned | KILLED (counterexample) |
| pk-max-swap | red_np2_max_u32 | MAX returns the minimum | KILLED (counterexample) |
| pk-xor | red_np2_xor | XOR computes OR | KILLED (counterexample) |
| rd-ovf-signed | red_np2_sum_i32 | signed overflow flag never raised | KILLED (counterexample) |
| rd-ovf-unsigned | red_np2_sum_u32 | unsigned carry flag too late | KILLED (counterexample) |
| rd-pop | red_np2_sum_u32 | only participant 0's head is popped | KILLED (counterexample) |
| rd-align | red_np2_and | elements combined before every participant has delivered (misalignment) | KILLED (counterexample) |
| pk-reduce-root | cmd_np4_all | REDUCE accepts several roots | KILLED (counterexample) |
| pk-len-limit | cmd_np4_all | length limit off by one | KILLED (counterexample) |
| pk-op-legal | cmd_np4_all | FP32 accepts every integer operator | KILLED (counterexample) |
| pk-fp-rm | cmd_np4_all | illegal rounding modes 5,6 accepted | KILLED (counterexample) |
| pk-cid-after | cid | collective-ID order inverted | KILLED (counterexample) |

**27 of 27 injected bugs make their formal job fail.**
