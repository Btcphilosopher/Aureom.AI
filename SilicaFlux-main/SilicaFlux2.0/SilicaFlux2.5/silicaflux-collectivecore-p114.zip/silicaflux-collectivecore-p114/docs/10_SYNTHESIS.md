# 10 — Synthesis estimates

`make synth` → `reports/synth.md`: Yosys 0.33 generic-gate, Lattice ECP5 and Xilinx 7-series mappings of nine configurations, with an explicit latch check (**0 latches in every configuration**).  The flow is the one the repository's other modules used (read → hierarchy → proc → synth), on package-flattened copies (`scripts/flatten_pkg.py`).

**This is not a timing or area result.**  No PDK, no timing analysis, no clock frequency, no µm², no power, no place-and-route.  FIFO storage is register arrays in the generic mapping and inferred distributed RAM on the FPGA mappings (excluded from the LUT/FF columns).  Observations that are safe to draw: the integer datapath grows with NP (more input ports, wider comparator tree); each FP32 FMA node adds roughly 1.8–2 k ECP5 LUT4 (NP = 2 has one FMA, NP = 4 has three); the network and memory adapters are small next to the core; nothing infers a latch.

Control-logic depth was not analysed, and no figure here says anything about achievable frequency.
