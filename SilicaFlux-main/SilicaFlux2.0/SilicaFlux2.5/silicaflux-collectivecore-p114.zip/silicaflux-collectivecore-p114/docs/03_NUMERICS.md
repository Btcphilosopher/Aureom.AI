# 03 — Numerics: what a reduction means, exactly

## 1. Integer operators (INT32, UINT32)

Let x₀ … x_{k-1} be the contributions of the k senders to one element position.

| op | result | notes |
|---|---|---|
| SUM | (Σ xᵢ) mod 2³² | the same 32 bits for INT32 and UINT32; **wrap-around, not saturation** |
| MIN / MAX | smallest / largest xᵢ | INT32: two's-complement order. UINT32: unsigned order. Equal operands are bit-identical, so ties cannot differ |
| AND / OR / XOR | bitwise over all xᵢ | identical for both types |

**Overflow flag.**  `INT_OVF` (completion flag bit 5) is raised iff the **exact** (unbounded) sum of the contributions of some element is not representable in the data type: outside [−2³¹, 2³¹−1] for INT32, ≥ 2³² for UINT32.  The wrapped result is still delivered.  The test is on the exact sum, so it does not depend on the order of the additions — for a **single node**.
*In a tree the flag is node-local* (§4): every node tests the exact sum of **its own inputs**, which for an interior node are its children's already-wrapped results; the data result is always exactly (Σ xᵢ) mod 2³² whatever the tree.

SUM, MIN, MAX, AND, OR, XOR are associative and commutative on 32-bit integers, so for them the shape of the reduction tree cannot change a result bit; the tree is fixed anyway because FP32 shares the datapath definition.  `formal/fv_red.sv` proves, over all input values, that the fixed tree equals an independent fold from the highest participant down.

## 2. FP32 SUM (build option `FP32_EN`)

Available only because the repository contains a SoftFloat/TestFloat-verified FMA (`silicaflux-hpc-fp32-fma`, 30.7 M TestFloat cases per configuration in its own regression), vendored unmodified.  Every add is `fp32_fma(a, 1.0, b) = round(a·1.0 + b)`; the product is exact, so result **and all five flags** are those of IEEE-754 binary32 addition (verified: the independent reference uses SoftFloat `f32_add`, and swapping the operands changes nothing).

| item | definition |
|---|---|
| rounding | the command's `rm` (RNE, RTZ, RDN, RUP, RMM) for every add of the collective |
| NaN | any add that involves a NaN returns the canonical quiet NaN `0x7FC00000` (RISC-V convention, `NAN_PROPAGATE = 0`); a signalling NaN also raises NV |
| infinities | IEEE rules: +∞ + −∞ = NaN (NV); an overflowing add gives ±∞ (RNE, RUP/RDN per sign) or ±max (RTZ and the opposite directed mode) with OF, NX |
| subnormals | full support, no flush-to-zero; tininess after rounding |
| flags | OR over every add of the node; completion flags bits 4:0 |
| **absent operands** | a participant that is not a sender is **skipped**, never replaced by an additive identity (no identity exists under every rounding mode: −0 + (+0) is +0 but −0 under RDN; and a phantom add would canonicalise a NaN payload). A lone contribution passes through bit-for-bit, with no add and no flag |
| BROADCAST of FP32 | a bit copy (`COPY`): NaN payloads included |
| not provided | FP32 MIN / MAX, FP32 AND/OR/XOR (rejected, `E_CMD_OP`); fused or compensated summation; FP64; BF16/FP16 |

### Reduction order and reproducibility

Participants occupy leaves 0…7 of a fixed balanced binary tree; `node(l, r)` adds the two halves, an absent half is skipped:

```
          ((p0 + p1) + (p2 + p3)) + ((p4 + p5) + (p6 + p7))        e.g. senders {0,1,2,5}: ((p0+p1)+p2) + p5
```

* The result is a function of the **sender mask only** — never of arrival times, stalls, buffer depths, backpressure or resets.  Verified by running identical data under four very different timings and comparing bits (`fp32_repro`), and in every random test against the reference.
* **Floating-point addition is not associative.**  Results are **not** promised to be identical across different association orders.  Measured on the reference with cancellation-prone random data (`fp32_repro`): the fixed tree differs from a sequential left-to-right sum on ~10 % of random 4-term sums and ~14 % of 8-term sums.
* A binary tree of nodes (`FAN = 2`) reduces in **exactly** the flat balanced order (asserted on every collective of the binary-tree benches).  A tree with another fan-in (3, 4) is a different but equally fixed association: node (l,i) applies the balanced tree over its own ports; the bench's independent reference models that shape.  Results are therefore bit-identical only between identical topologies and masks.

## 3. What is *not* claimed

Equality with a correctly rounded exact sum; equality with any BLAS / GPU / MPI reduction order; bit-reproducibility across different participant numbering or topologies.

## 4. Flags in a tree are node-local

Each node's completion record carries the flags of its own additions only: the INT overflow test over the values that node received, the IEEE flags of the adds that node performed.  A tree-wide indication is the OR of the nodes' records.  The bench computes the expected flag of every node (`ref::compute_tree`) and compares each completion record.
