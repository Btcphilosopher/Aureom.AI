# 06 — Network interface: the remote participant adapter

## 1. What exists and what does not

The brief asks for a connection to an RDMAEngine "or a streaming transport adapter".  **The repository has no RDMAEngine** (docs/00).  `sf_collective_net_adapter` is therefore a streaming transport adapter against a transport contract defined here; it makes no claim to RDMA semantics.  An RDMA engine (or PacketCore-based transport) would present the same beat interface: one 32-bit element per beat tagged with a transfer id and a sequence number — e.g. RDMA writes with immediate data carrying `{xfer, seq}`.

## 2. Transport contract (what the adapter assumes and offers)

| direction | signals | semantics |
|---|---|---|
| RX (transport → node) | `rx_valid/ready, rx_xfer(16), rx_seq(20), rx_dtype, rx_op, rx_data, rx_last, rx_err` | **may be reordered, duplicated, delayed or lost**; `xfer` = collective id, `seq` = element index |
| TX (node → transport) | `tx_valid/ready, tx_xfer, tx_seq, tx_dtype, tx_op, tx_data, tx_last, tx_err` + `tx_credit` | in order; at most `CREDITS` beats outstanding; the remote returns credits |
| completion propagation | `ack_valid/ready, ack_cid, ack_ok, ack_err, ack_blamed` | one message per completion record of the node |
| failure | `link_down` (in), `fail_out` (to the core's `part_fail[p]`), `st_timeout`, `st_down`, `ctl_clear` | a failed link stays failed until the control plane clears it |

## 3. Behaviour

**Sequence handling.**  One transfer at a time per link.  A beat of a *later* transfer waits (`rx_ready = 0`); a beat of an *earlier or finished* transfer is a stale retransmission: consumed, counted (`ev_stale`).  Within the open transfer a reorder window of `WIN` elements (power of two) stores `seq ∈ [exp, exp+WIN)` in slot `seq mod WIN` and delivers strictly in index order: `seq < exp` or an occupied slot is a duplicate (consumed, counted, **never delivered twice**); `seq ≥ exp+WIN` waits (window flow control).  An `rx_err` beat is passed on as an error beat (the core reports `E_PEER`).  Opening a transfer needs `seq < WIN`.
**Timeouts.**  While a transfer is open and the *next element is missing* (the adapter is waiting for the network, not for the core), `cfg_timeout` cycles without any beat arriving declare the link failed (`st_timeout`).  A slow *core* is never blamed.  The core's own watchdog covers "the peer never started".
**Participant failures.**  A failed link drives `fail_out` (→ `part_fail[p]` → `E_PART_FAIL`, `cpl_maskA` names the participant), its RX consumes and drops everything (so the transport never blocks), its TX holds.  A beat already on offer to the core is never withdrawn: the failure waits until it is taken.
**Credits.**  TX sends a beat only with a credit; credits are returned by the remote (`tx_credit`).  Verified: outstanding beats never exceed `CREDITS` under random readiness and late credit returns.
**Completion propagation.**  Every completion record of the node is queued (`ACK_DEPTH`) and forwarded as an ack message, with `blamed` = this participant is named in the record's masks.  If the queue is full the ack is lost and `ev_ack_lost` counts it (bounded and visible).
**No assumption that inputs arrive together.**  The adapter and the core both tolerate arbitrary arrival times; the tests delay the remote by up to 800 cycles.

## 4. Verification (`tests/tn_main.cpp`, system top `sim/sf_collective_net_sim.sv`: local participant 0 + remote participant 1)

`inorder`, `reorder_dup` (reordering inside the window, in-window / delivered / whole-stale duplicates — **every injected duplicate counted exactly once, none combined**), `late_remote`, `broadcast`, `lost_beat` (watchdog → `E_PART_FAIL` → terminators → ack names the participant → `ctl_clear` → clean recovery), `link_down`, `err_beat`, `credits`, `random`; window 2/4/8/16 × credits 1…16 × 8 seeds.  Results: reports/regression.md.

## 5. Limits

One open transfer per link; static window/credit/ack parameters; no retransmission request, congestion control, encryption or authentication (the transport below must provide reliability if loss is not acceptable); the ack queue is bounded and advisory; no multi-link aggregation; the adapter is a *participant* adapter (it does not route between nodes).
