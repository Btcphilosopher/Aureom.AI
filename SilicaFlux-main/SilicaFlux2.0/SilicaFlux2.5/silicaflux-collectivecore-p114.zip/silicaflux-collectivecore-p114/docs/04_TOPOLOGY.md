# 04 — Topology: how data moves between participants

## 1. The interface is topology-independent

Every link in every topology carries the same thing: the **stream beat** of docs/02 §4 (`cid, pid, idx, dtype, op, data, last, err`, valid/ready).  A participant, a local memory adapter, a network adapter and a child node's `up` port are interchangeable producers; a participant port, a store engine, a network adapter and a child's `dn` port are interchangeable consumers.  What differs between topologies is only *which node's output is wired to which node's input* and *which commands each node receives*.  The core never learns the topology: it knows a mask of senders, a mask of receivers and — for an interior node — that its reduced stream leaves on `up` and the final result arrives on `dn`.

## 2. The implemented topology: a fixed tree

A node (`sf_collective_core`) has NP ≤ 8 participant ports.  Nodes compose into a **FAN-ary tree** (`sim/sf_collective_tree_sim.sv`, FAN = 2…8, any height):

```
                      root (INTERIOR=0)                level H-1
                     in[0]   in[1]   out[0]  out[1]
                      ▲  ▲    ▲  ▲     │        │
              up ─────┘  │    │  └─────┘ dn      │   child.up  → parent.in[p]       (reduced partial results flow UP)
                         │    │                    │   parent.out[p] → child.dn        (the final result flows DOWN)
        interior node A ─┘    └─ interior node B                                         level 1 … 0
        in[0] in[1] out[0] out[1]   ...
         ▲     ▲     │     │
       leaf0  leaf1  leaf0  leaf1                      leaves = participants (accelerator tiles)
```

All-reduce: each leaf's stream enters its level-0 node → that node reduces its ports (fixed balanced tree) and sends the partial **up** → ... → the root reduces the partials and sends the final result **down** each child link → each node forwards it (`dn` → its receivers' output ports) → leaves.  Reduce-to-root: the same, but only the root participant's path carries the result down.  Broadcast: the sender's stream travels up to the root (single contributor: passed through unchanged) and then down to every receiver.  Everything is **cut-through** at one element per cycle: the first result reaches the leaves after `6 + 7·(H−1)` cycles and then streams (measured, benchmarks/REPORT.md §9).

### Command expansion (the control plane)

A global collective (leaf masks) becomes one command per participating node: node (l, i)'s `send_mask` bit p = "some global sender lies under child p", likewise `recv_mask`; nodes with both masks empty get no command.  Interior nodes derive `up = send ≠ ∅` and `down = recv ≠ ∅`; the root distributes its own result.  `REDUCE` therefore stays one-hot at every level (the root leaf's path), `BROADCAST` stays single-sender.  The bench's `Tt::expand` is the reference expansion; a driver must do the same and use **the same collective id on every node**.  The top root always participates (a collective entirely inside one subtree still passes through the root).

### Order of arithmetic and flags in a tree

Node (l, i) applies the balanced tree over its own ports.  For FAN = 2 this equals the flat balanced tree over all leaves (asserted on every collective of the binary-tree benches), so an FP32 result is bit-identical to the flat 2^H-participant node.  Flags are node-local (docs/03 §4).

### Failure in a tree

A node that fails (timeout, protocol error, participant failure, abort) emits an error terminator on `up` and on every owed receiver port; the parent turns it into `E_PEER` (or the child's `dn` adapter does), so the failure propagates along the links the data would have used; every commanded node ends with exactly one completion record.  Verified: faults injected at leaves (every fault type, at random leaves and element positions, plus random mixes) → every node completes, receivers get a clean prefix + terminator, the *next* collectives are exact (`tt_main faults`, `part_fail`, `abort`, `reset`, `random_faults`).

## 3. Ring, tree and hierarchical reduction — what was investigated

**Only the tree is implemented.**  The comparison below is **analytical** (the repository has no network model, so there is nothing to measure a ring on); it uses this engine's measured numbers where they apply and states its assumptions.  Treat it as design guidance, not as a result.

Assumptions: N participants, M elements per participant, every link moves 1 element per cycle per direction (full duplex), an interior node can reduce at link rate (true for this engine), per-hop latency ≈ 3.5 cycles per direction (measured, tree), a ring step costs `h = 4` cycles of latency plus the chunk transfer.

| scheme | steps / depth | time for all-reduce | elements crossing the busiest link | notes |
|---|---|---|---|---|
| **tree** (FAN F, **implemented**) | ⌈log_F N⌉ levels | `6 + 7(H−1) + (M−1)` cycles (cut-through, measured form) | M per direction | latency grows with log N; an interior node needs F+2 stream ports; the root is a bandwidth concentrator (F inputs at line rate) |
| **ring** (reduce-scatter + all-gather, not built) | 2(N−1) steps | ≈ `2(N−1)(h + M/N)` | 2(N−1)/N · M ≈ 2M per direction | bandwidth-balanced, minimal ports per node (1 in, 1 out), latency grows **linearly** with N; needs chunking and the reduce-scatter / all-gather collectives at tree-free nodes |
| **hierarchical** (tree inside a group, ring or tree across groups; not built beyond FAN > 2) | log within + 2(G−1) across | between the two | between M and 2M | fits packages / boards with fast local and slower global links; FAN > 2 nodes cover the first level |

Illustrative numbers from the formulas (cycles; M = elements):

| N | M | tree F=2 | tree F=4 | ring |
|---|---|---|---|---|
| 8 | 16 | 35 | 28 | 84 |
| 8 | 4096 | 4115 | 4108 | 7224 |
| 64 | 16 | 56 | 35 | 536 |
| 64 | 4096 | 4136 | 4115 | 8568 |
| 512 | 16 | 77 | 49 | 4120 |

Under these assumptions (full-duplex links, line-rate interior reduction, no per-link bandwidth cap) the cut-through tree is faster than a store-and-forward ring at every size because each element crosses each link once per direction instead of ~2(N−1)/N times; the ring wins when ports per node are the constraint (radix 2 vs F+2), when the tree root's fan-in cannot be fed at line rate, or when links are half-duplex.  None of that was simulated.

## 4. What is not covered

Rings, tori, multi-root or pipelined multi-collective schedules; reduce-scatter and all-gather across a tree (rejected by interior nodes, never advertised); adaptive or fault-tolerant re-routing around a failed node; a hardware command-expansion unit (the control plane is software / the bench); links with their own latency or credit loops other than the network adapter (docs/06).
