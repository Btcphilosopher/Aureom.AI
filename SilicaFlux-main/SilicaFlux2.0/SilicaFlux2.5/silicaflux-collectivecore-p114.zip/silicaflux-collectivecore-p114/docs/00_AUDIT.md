# 00 — Repository audit (Project 114, CollectiveCore)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/charming-galileo-5f8r59`, working tree as cloned (last commit `a0ffc7e`).  The SilicaFlux material is almost entirely inside zip archives
(`SilicaFlux-main/*.zip`, `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/*.zip`, ~120 module archives).  **Nothing was committed to the repository; this project is delivered as an archive.**
Every archive that could hold a collective, reduction, DMA, transport, fabric, FP or memory block was extracted into a scratch directory (untrusted data, never executed) and read; names and contents were searched in all ~750 files.

## 1. The names in the brief

| Brief name | What exists | Decision |
|---|---|---|
| **TensorCore** | `silicaflux-tensorcore01…10`, `tensorcore08` (INT8 systolic array, accumulator, quantiser, tile iterator, DMA adapter, HPC tile integration) | Inspected, **not integrated**: it is a GEMM engine; its INT32 accumulators are not a cross-participant reduction. Its tile/memory conventions informed the stream-and-queue style. |
| **FP32 Vector Engine** | `silicaflux-hpc-m02-vector-lane`, `m03-vector-array`, `hpc-fp32-fma`; `.sf` `vector_engine` (integer SIMD) | **Reused (FP32 only)**: `silicaflux-hpc-fp32-fma` (`fp32_fma`, IEEE-754 binary32 FMA, 5 rounding modes, 5 flags, valid/ready, **verified bit-exact against Berkeley SoftFloat-3e / TestFloat-3e**) is vendored byte-identical and is the only arithmetic used for FP32. The vector-lane array is a different thing (lane-parallel elementwise operations). |
| **RDMAEngine** | **Does not exist.** Zero hits for "rdma" in any archive member name, README, document or source in the repository. | A *streaming transport adapter* (`sf_collective_net_adapter`) is built against a transport contract **defined by this project** (docs/06). No RDMA semantics are claimed. |
| **PacketForge** | **Does not exist as a module.** It is a code name: the Meridian (P83) and Keystone (P82) audits map it to **PacketCore (P62)**, and the Albion README lists "PacketForge P86" among accelerators that were *missing* from that workspace. | Not integrated. PacketCore is an Ethernet/IP packet processor (parser, classifier, queues); the collective transport contract is deliberately independent of any packet format. |
| **StreamDMA** | `silicaflux-streamdma-p103(-r2)`: protected scatter-gather DMA (descriptor queue → validator → MemoryGuard → read/write engines → completion) with an AXI4-style port and a MemoryMatrix bridge | **Reused, byte-identical** (`third_party/streamdma-p103`, real RTL in the system bench): stages buffers between memory types. |
| **Meridian / DataFabric** | Meridian P83 (`sf_meridian_fabric`, domain-bound crossbar), MeridianQoS P102, DataFabric SFB2 (`silicaflux-datafabric`), DataFabric-NoC SFB3 (`silicaflux-datafabric-noc`) | Inspected, **not integrated**. They are address-mapped request/response fabrics (loads/stores with tags), not stream fabrics for reductions. The collective's stream protocol is topology-independent and could be carried over them; that adapter is not built. |
| **Buffer management** | BufferCore P55 (storage buffer, NAND/ECC path), MemoryPool P65 (tiering), StreamDMA's reservation ring, MemoryMatrix P101 (banked SRAM) | **MemoryMatrix reused** (real RTL) as the SRAM the adapters and StreamDMA share. `sfd_fifo` (P61) reused for every buffer. BufferCore/MemoryPool are storage-side and not relevant to on-chip element streams. |
| **MemoryGuard** | **No module of that name** (StreamDMA's audit says the same). The verified stand-in is the P64 permission checker/table (`sfdma_perm_checker/table`: per-burst IOMMU contract). | The adapters use the same contract; the same vendored table is the guard in the system bench. It is a *model of isolation*, not an isolation mechanism by itself. |
| **Existing reduction modules** | `hpc_varray_reduce` (ordered FP32 sum / dot-product reduction **inside one vector array**), `.sf` `vector_engine` REDUCE op | Different scope: intra-tile, one stream. **No cross-participant collective existed.** The FP32 conventions of `hpc_varray_reduce` (absent operands skipped, never an identity; canonical NaN; node flags OR-ed; reduction order defined and timing-independent) were adopted. |

## 2. What was reused (byte-identical, `third_party/MANIFEST.tsv`, `scripts/check_vendor.py --repo <root>` compares every file with its archive member: 417 files, 0 mismatches)

| block | files | used for |
|---|---|---|
| P61 `sfd_fifo` | 1 | every buffer (input, output, terminator, command, completion, ack) |
| `silicaflux-hpc-fp32-fma` RTL | 13 | FP32 additions |
| Berkeley SoftFloat-3e (RISC-V specialisation) | 323 | the independent FP oracle in the benches (not in the RTL) |
| StreamDMA P103 r2 | 13 | memory-system bench |
| CloudDMA P64 guard | 3 | MemoryGuard stand-in |
| MemoryMatrix P101 + its SRAM/ECC sources | 33 | memory in the system bench |

## 3. Conventions adopted from the repository

`clk` / active-low `rst_n` with asynchronous assert; only control state reset; `valid/ready` naming; `default_nettype none`; Verilator `-Wall`-clean RTL; Verilator C++ benches with an independent reference; Yosys + Z3 formal harnesses with shadow models; mutation testing with a baseline gate; numbered `docs/`, `reports/`, "delivered as a ZIP, nothing committed".

## 4. What had to be built (new)

The ABI and package; command queue; ingress stream adapter; scheduler; reduction datapath (integer and FP32 tree); output stream controller with terminators; performance counters; the tree topology top; the network adapter; the memory adapters; the benches, reference model, formal harnesses and mutation campaign.

## 5. Tool notes

Verilator 5.020, Yosys 0.33, Z3 4.8.12, Icarus 12 (the versions the repository's other modules used).  Yosys 0.33 cannot read the `module m import pkg::*;` header form, so the Yosys flows (formal, synthesis) run on a **flattened copy** produced by `scripts/flatten_pkg.py`; the simulated RTL is idiomatic SystemVerilog.
