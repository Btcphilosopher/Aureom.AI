# 07 — Memory integration: StreamDMA, MemoryMatrix, MemoryGuard

## 1. Structure (`sim/sf_collective_mm_system.sv`, real vendored RTL)

```
host (bench, matrix master 4)          ┌────────────────── sf_memory_matrix (P101, 4 banks x 4096 x 64 bit, 128-bit ports) ─────────────────┐
StreamDMA ─ bridge ─ masters 0/1  ───► │ 0 DMA read   1 DMA write   2 adapter 0 (read+write)   3 adapter 1 (read+write)   4 host            │
 (P103 r2)  guard table 0 (P64)        └────────────────────────────────────────────────────────────────────────────────────────────────────┘
 adapter i = sf_collective_mem_rd (load engine → participant stream) + sf_collective_mem_wr (result stream → store engine) + guard table i + arbitrated matrix master
 two participants of ONE sf_collective_core (NP = 2)
```

Flow of a collective: the host fills SRAM buffers (type 1) → **StreamDMA** copies them into scratchpad buffers (type 4) and reports completion → the driver submits the collective command and one **load** and one **store descriptor** per participant → the adapters stream the inputs, the core reduces, the adapters store the results → the driver waits for the **store completion** (not the core's) → StreamDMA drains the result buffers back to SRAM → the host reads and compares.  Memory is loaded and dumped only through the matrix's own port.

## 2. What is validated, where

| required check | rule | evidence (`tests/tm_main.cpp`) |
|---|---|---|
| **buffer bounds** | each ≤ 4 KiB burst must lie inside ONE guard mapping; a buffer that runs off its mapping fails after the bursts that fit (`M_PERM`); buffers that would wrap the address space (`iova + 4·len ≥ 2^AW`) are `M_LEN` without access | `ld runs off mapping`, `ld address wrap` |
| **data length** | `len ≤ MAX_LEN` else `M_LEN`; `len = 0` completes `M_OK`, no access, no stream beats | `ld too long`, empty collective |
| **domain permissions** | every burst is submitted to the MemoryGuard with the descriptor's domain; refusals (`no mapping`, `permission`, `wrong domain`) are `M_PERM`; **only the physical address the guard returns reaches the memory** (non-identity translation test for loads and stores); a refused store writes nothing (sentinel check); a read-only mapping refuses writes | `ld unmapped`, `ld wrong domain`, `st read-only`, `st wrong domain`, `st beyond memory`, `translate` |
| **element alignment** | buffer address must be 4-byte aligned else `M_ALIGN` | `ld unaligned`, `st unaligned` |
| **memory faults** | physical address outside the matrix → matrix status ≠ OK → `M_BUS`; physical address outside the 1 MiB aperture → `M_BUS` without an access | `ld beyond memory`, `ld beyond aperture` |
| **completion ordering** | load completion only after the last beat (or error beat) was accepted by the core; **store completion only after every write response** — checked at the instant the record appears: the matrix's performed-write counter must already include all of that adapter's writes (a mutant that completes early is killed by this) | `flow`, `burst_split`, `translate` |
| **failure behaviour** | a failed load ends its stream with an error beat so the core fails the collective (`E_PEER`) instead of timing out; a refused store *discards* the result stream so the core still completes; a stream error (terminator) stops the store (`M_STREAM`) | `protection` (12 cases, each followed by a clean recovery collective) |
| page-straddling buffers | bursts are cut at 4 KiB boundaries | `burst_split` (loads straddle 0x11000, a store straddles 0x13000) |

Note: mappings are 4 KiB-granular and bursts never cross 4 KiB, so a *single burst* can never straddle two mappings; "range crossing" appears as a buffer running off the END of its mapping (the first bursts succeed, the next one is refused).

## 3. Results

End-to-end exact results for 8 lengths × random operators over the real memory system; 12 protection/bounds negatives; 4 translation runs; 4 page-straddling runs; 3 performance runs — all seeds pass (reports/regression.md).  Memory-fed collective: ~0.4 elements/cycle (benchmarks/REPORT.md §10).

## 4. Limits

Elements are accessed as 4-byte requests (no wide bursts on the matrix side); an adapter shares ONE matrix master between its read and write streams (≤ 0.5 element/cycle/adapter, measured ~0.4); contiguous buffers only (scatter-gather belongs to StreamDMA); `MEMTYPE` is fixed per adapter instance; the MemoryGuard is the P64 simulation table (a verified model, not a hardware isolation mechanism); MemoryMatrix `flush_i` is global; a failed store may leave a correct *prefix* of the result in memory — the completion record, not the buffer, says whether it is valid; the StreamDMA ↔ adapter ordering is a driver contract (wait for completion records), not a hardware interlock.
