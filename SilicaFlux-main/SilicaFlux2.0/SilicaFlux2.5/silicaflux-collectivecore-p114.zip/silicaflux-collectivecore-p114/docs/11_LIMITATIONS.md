# 11 — Limitations and what is NOT claimed (read this first)

## Evidence level

RTL **simulation** (Verilator 5.020), **bounded** formal (Yosys SAT / Z3), Yosys synthesis **estimates**.  **No FPGA, no silicon, no timing closure, no clock frequency, no power, no µm²**, no place-and-route.  Every performance figure is in cycles.  Nothing here is "a complete distributed collective-communications library": it is a verified engine for a small set of integer (and FP32 SUM) collectives over a fixed tree, with a streaming transport adapter and a memory adapter.

## Scope limits (by design, documented, tested where they bite)

| area | limit |
|---|---|
| concurrency | **one collective per node at a time**; commands run in order; no overlap between consecutive collectives (~3-cycle gap measured); no multiple outstanding collectives |
| participants | ≤ 8 per node (8-bit masks); larger systems are trees of nodes; tree commands are expanded by the control plane (here: the bench), the top root always participates |
| data | 32-bit elements, one element per cycle per port; INT32 / UINT32 (SUM MIN MAX AND OR XOR), FP32 SUM only. No FP32 MIN/MAX, no FP64/BF16/FP16/INT8/INT64, no saturating arithmetic, no compensated summation |
| collectives | REDUCE / BROADCAST / ALLREDUCE on flat nodes and trees; REDUCE_SCATTER and ALL_GATHER **flat nodes only** (interior nodes reject them); no all-to-all, scan, barrier, gather/scatter |
| topology | tree only. Ring, tree-of-rings, torus, adaptive routing, re-routing around a failed node: **not built** (analysis in docs/04 is analytical) |
| IDs | collective ids must be strictly increasing (16-bit serial numbers); an id repeated or going backwards is rejected. After a **soft reset the stream sources must be quiesced** with the core |
| lengths | `len ≤ MAX_LEN` (parameter) with `MAX_LEN × NP < 2^20` |
| terminators | one error terminator per failed collective per port, queued in `TERM_DEPTH` slots; beyond that the newest is lost and `PC_TERM_LOST` counts it |
| watchdog | counts cycles without progress per collective; `0` = off. A slow-but-steady collective never times out; a stall does, and the stalled participant's *own* later data is blocked behind its late data (in-order streams) |

## Numerics

* Integer overflow wraps; `INT_OVF` is the exact-sum test of the node's own inputs (node-local in a tree).
* FP32 results are a function of the sender mask and topology only; **not** identical across different association orders, not correctly rounded, not equal to any BLAS/GPU/MPI order.  FP32 correctness rests on the vendored `fp32_fma` (verified in its own project against SoftFloat/TestFloat) **plus** this project's differential testing of the integrated structure against SoftFloat `f32_add` (millions of adds with directed specials; it is not a re-run of TestFloat on the integrated tree).
* FP32 flags in a tree are node-local.

## Network adapter

The transport contract is defined by this project (no RDMAEngine exists).  One open transfer per link; static window / credit / ack parameters; no retransmission request, congestion control, encryption or authentication; acks are advisory and bounded (loss counted).  Not verified: real network behaviour (the remote node is a bench model with injected reorder / duplicate / loss / delay).

## Memory adapter

Element-wise 4-byte requests; one matrix master shared by an adapter's read and write streams (~0.4 elements/cycle measured, ≤ 0.5 by construction); contiguous buffers; the guard is the P64 **simulation table** (a verified model of the IOMMU contract, not an isolation mechanism); MemoryMatrix `flush_i` is global; a failed store may leave a correct prefix of the result in memory (the completion record says it is invalid); ordering between StreamDMA and the adapters is a driver contract (wait for completion records), not an interlock; no ECC configuration was exercised in the system bench.

## Verification limits

* **Reference independence.** The software reference (`tests/sf_coll_ref.h`) uses different formulations (64-bit arithmetic, recursive tree, SoftFloat) and was written from the ABI text, but by the same author as the RTL: it removes shared *code*, not shared *misunderstanding*.  Two things reduce that risk: SoftFloat is an external oracle for FP32, and the formal harnesses restate the rules a third time.
* **Formal is bounded** (depth 14–16 for the sequential harnesses, 4 for the reduction fold) except the combinational proofs (command validation over all 2^64 commands in four configurations, collective-id order over all values), which are exhaustive.  No unbounded induction was attempted.  Not covered formally: the tree composition, the FP32 nodes, the output fork, the network and memory adapters (simulation + mutation only).
* **Harness assumptions** are stated in the harness files (a source holds a beat until accepted; short commands; FP pipelines do not become busy while nothing runs; a port is pushed at most `exp_len` elements per collective).  Reachability witnesses (which must *fail*) show those assumptions do not make the proofs vacuous.
* **Mutation testing** measures the benches against 78 chosen bugs; survivors are listed and each is argued equivalent in `reports/mutation.md` / `docs/08_VERIFICATION.md`.  A different set of bugs could find gaps; five real gaps were found and closed this way during development.
* **Coverage** is functional (scenarios, parameter sweeps, random mixes with several seeds) — no structural coverage tool was run.

## Reuse caveats

Vendored blocks keep their own evidence level (StreamDMA, MemoryMatrix, the guard table, `fp32_fma`); this project verifies their *integration*, not their internals.  `sfd_fifo` cannot accept and release in the same cycle at depth 1, which is why depth ≥ 2 is required for full rate (measured, benchmarks/REPORT.md §3).
