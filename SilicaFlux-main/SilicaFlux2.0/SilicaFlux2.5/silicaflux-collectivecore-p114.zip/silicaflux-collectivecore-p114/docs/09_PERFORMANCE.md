# 09 — Performance

The full study, its method and its raw data are in **`benchmarks/REPORT.md`** (generated from `benchmarks/results.csv` by `benchmarks/make_report.py`; run with `make bench`).  Metrics requested by the brief and where they are measured:

| metric | where |
|---|---|
| elements reduced per cycle | §1 (peak: 0.98 elements per active cycle, independent of NP) |
| bytes transferred | §1 (bytes in / out per run), §10 |
| reduction latency | §2: integer `len + 6` cycles for every NP ≤ 8; FP32 + 5 cycles per tree level; tree first-result `6 + 7·(H−1)` (§9) |
| network stalls | §5 (starve share under jitter), §6 (imbalance), §7 (late participant) |
| buffer occupancy | every table (mean / max input and output occupancy from the counters) and §3 (depth sweep) |
| compute utilisation | elements ÷ active cycles against the 1-element/cycle datapath peak (§1, §3, §8) |
| participant imbalance | §5, §6 (`PC_IMB_MAX` / `PC_IMB_SUM`) |
| effective throughput | §1, §4, §10 (bytes delivered ÷ wall cycles) |

Findings worth knowing: a 1-deep buffer halves throughput (the vendored FIFO cannot accept and release in one cycle) so depth ≥ 2 is required; a sustained imbalance caps throughput at the slow participant whatever the buffer depth while jitter is smoothed by deeper input buffers; the tree is cut-through (1 element per cycle at any depth); the memory-fed collective runs at ~0.4 elements per cycle because each adapter shares one MemoryMatrix master between reads and writes.  All figures are simulation cycles: no frequency, area or power is implied.
