# 02 — ABI: commands, streams, completion records, errors

Source of truth: `rtl/sf_collective_pkg.sv` (`scripts/check_abi.py` compares every numeric constant with the independent reference header `tests/sf_coll_ref.h`).
All multi-bit fields are little-endian bit ranges of the stated width.  Participants are numbered 0 … NP−1 (NP = 2…8).

## 1. Collective types (`ctype`, 3 bits)

| code | name | senders | receivers | what every receiver gets |
|---|---|---|---|---|
| 0 | `REDUCE` (reduce-to-root) | ≥ 1 | exactly 1 (the root) | `len` elements: the reduction of the senders' elements |
| 1 | `BROADCAST` | exactly 1 | ≥ 1 | `len` elements: a bit-exact copy of the sender's vector (no arithmetic; operator must be `COPY`) |
| 2 | `ALLREDUCE` | ≥ 1 | ≥ 1 | `len` elements: the same reduction as `REDUCE`, delivered to every receiver |
| 3 | `REDSCAT` (reduce-scatter) | ≥ 1 | R ≥ 1 | the reduction is cut into R equal chunks of `len/R` elements; the r-th receiver (in participant order) gets chunk r, indexed from 0. `len % R == 0` is required. **Build option** `REDSCAT_EN`, root nodes only |
| 4 | `ALLGATHER` | ≥ 1 | ≥ 1 | the senders' vectors concatenated in participant order (`n_senders × len` elements); operator `COPY`. **Build option** `ALLGATHER_EN`, root nodes only |

`caps` (core output, 16 bits) states exactly what a build implements: bit 0 REDUCE, 1 BROADCAST, 2 ALLREDUCE, 3 REDSCAT, 4 ALLGATHER, 8 integer operators, 9 FP32 SUM, 12 tree-interior node.  Nothing that is not implemented and verified is advertised.

## 2. Operators and data types

| `op` | name | defined for |
|---|---|---|
| 0 `SUM` | addition | INT32, UINT32 (wrap-around), FP32 (IEEE-754, rounding mode `rm`) |
| 1 `MIN`, 2 `MAX` | minimum / maximum | INT32 (signed order), UINT32 (unsigned order). **Not** FP32 |
| 3 `AND`, 4 `OR`, 5 `XOR` | bitwise | INT32 / UINT32 (identical bits). **Not** FP32 |
| 6 `COPY` | data movement | BROADCAST and ALLGATHER only (any 32-bit type, including FP32: bits are copied) |

`dtype`: 0 `INT32`, 1 `UINT32`, 2 `FP32` (only when the build has `FP32_EN`; operator must then be `SUM` or `COPY`).  `rm` (RISC-V `frm`: 0 RNE, 1 RTZ, 2 RDN, 3 RUP, 4 RMM) is checked only for FP32 `SUM` (> 4 is `E_CMD_OP`) and ignored otherwise.
Exact numerical semantics: `docs/03_NUMERICS.md`.

## 3. Command word (64 bits)

```
[15:0]  cid        collective id
[18:16] ctype      [21:19] op      [23:22] dtype      [26:24] rm
[34:27] send_mask  [42:35] recv_mask                  [63:43] len (elements per participant; 0 = empty collective)
```

`len = 0` is legal: the collective completes `OK` immediately and no stream carries a beat (stray beats for its id are discarded as stale).
**Collective IDs are 16-bit serial numbers (RFC 1982 order) and must be strictly increasing** per node (`E_CMD_CID` otherwise).  An ID is the identity of a collective: beats of ID *x* are never combined with beats of any other ID.
A node runs ONE collective at a time, commands in submission order.  Every submitted command yields exactly one completion record, in command order — rejected commands too.

### Validation (first failing rule wins; `cmd_validate`, proved equal to this list over all 2^64 commands in four configurations, `reports/formal.md`)

| order | error | rule |
|---|---|---|
| 0 | `E_CMD_CID` (5) | cid not strictly after the previous *accepted* cid. Does not move the reference id. |
| 1 | `E_CMD_TYPE` (1) | ctype > 4; REDSCAT / ALLGATHER not built; either on a tree-interior node |
| 2 | `E_CMD_OP` (2) | op > 6 / dtype > 2; copy types need `COPY`, reduce types forbid it; FP32 needs `FP32_EN` and `SUM`; FP32 `SUM` needs `rm ≤ 4` |
| 3 | `E_CMD_LEN` (3) | `len > MAX_LEN`; REDSCAT with `len % R ≠ 0` |
| 4 | `E_CMD_MASK` (4) | a mask bit ≥ NP; root node: send or recv empty, REDUCE recv not one-hot, BROADCAST send not one-hot; interior node: both empty, REDUCE recv > 1, BROADCAST send > 1 |

## 4. Stream beat (inputs `in_*`, outputs `out_*`, `up_*`, `dn_*`)

`valid/ready` handshake; **a source holds a beat unchanged while `valid && !ready`**.  One beat = one 32-bit element.

| signal | width | meaning |
|---|---|---|
| `cid` | 16 | collective id |
| `pid` | 3 | participant id — on inputs it must equal the port; on outputs it is the destination port (`UP_PID` on `up`) |
| `idx` | 20 | element index within the stream of this collective at this port |
| `dtype`, `op` | 2, 3 | echo of the command (checked) |
| `data` | 32 | the element |
| `last` | 1 | final element (`idx == len-1`; for outputs `idx == n_out-1`) |
| `err` | 1 | source declares the stream failed (an **error beat**: `err=1, last=1, data=0`) |

### What the input side does with a beat (`sf_collective_stream_adapter`)

* ID **after** the running collective's (or no collective activated yet) → **held** (`ready = 0`). It belongs to a collective that has not started.
* ID equal to the running collective's → checked, first failing rule wins: `err` → `E_PEER` (12); non-sender, wrong `pid`, `dtype` or `op` → `E_HDR` (10); `idx` < expected → `E_DUP` (9); `idx` > expected → `E_SEQ` (8); `idx` ≥ len or `last` not exactly on `len-1` → `E_LEN` (11).  A failing beat is consumed, never stored, and fails the collective.
* ID **before** the running/last collective's, or equal while nothing runs (finished / failed) → **stale**: consumed and discarded, counted (`PC_STALE`). Late retransmissions and the tails of aborted streams can neither block a port nor corrupt a later collective.

Elements therefore enter the input buffer strictly as 0,1,2,… — *the k-th buffer entry is element k* — which is what makes element alignment in the reduction datapath positional.

### What the output side guarantees (`sf_collective_outport`)

An offered beat is **never withdrawn or changed** until accepted (proved by BMC, `formal/fv_outport.sv`, and monitored every cycle on the output streams of the flat, tree and network benches).  When a collective fails, every destination that still owed beats receives an **error terminator** `{cid of the failed collective, idx = beats offered, last=1, err=1}` after the beat already on offer and before anything of a later collective.  Terminators wait in a per-port queue (`TERM_DEPTH`, default 2); if it overflows the newest is lost and `PC_TERM_LOST` counts it — a bounded, visible limit.

## 5. Completion record (one per command, in order)

`cpl_cid`, `cpl_ok`, `cpl_err` (below), `cpl_ctype`, `cpl_len`, `cpl_cycles` (pop → record), `cpl_flags`, `cpl_maskA`, `cpl_maskB`.

* `cpl_flags[4:0]` = IEEE flags `{NV, DZ, OF, UF, NX}` (bit 4 = NV … bit 0 = NX) accumulated over the additions of this node (FP32 SUM); `cpl_flags[5]` = `INT_OVF`.  **Flags are node-local** (docs/03 §4).
* `cpl_maskA` (9 bits, bit 8 = parent link): the senders **the engine was waiting for** at a timeout — owed elements *and* empty input buffer (a sender that is merely back-pressured by a stalled peer is not blamed); the ports that raised a protocol error; the participants named by `part_fail`.
* `cpl_maskB`: the destinations (bit 8 = up port) that still owed beats when the collective failed.

| code | name | meaning |
|---|---|---|
| 0 | `E_OK` | |
| 1–5 | `E_CMD_*` | command rejected, nothing ran (table in §3) |
| 6 | `E_TIMEOUT` | no progress (no element accepted, reduced or delivered) for `cfg_timeout` cycles; 0 disables |
| 7 | `E_PART_FAIL` | a participant in `part_fail[]` that still owed or was owed data |
| 8–12 | `E_SEQ` `E_DUP` `E_HDR` `E_LEN` `E_PEER` | stream protocol errors (§4) |
| 13 | `E_ABORT` | `ctl_abort` pulse |
| 14 | `E_INTERNAL` | reserved: an internal invariant violation (never produced; checked by formal and benches) |

Failure priority when several arrive in one cycle: abort > protocol error (lowest port first, `dn` last) > participant failure > timeout; **success wins over a failure in the same cycle**.
A failed collective never reports success, clears all of its state (input buffers, reduction, FP pipelines, output buffers) and does not disturb later collectives.

## 6. Soft reset and hard reset

`rst_n` (asynchronous assert, active low) and `ctl_soft_reset` (synchronous pulse) both return the core to the post-reset state, queue and completion buffer included; soft reset keeps the performance counters.  The reference collective id is forgotten, so **the stream sources must be quiesced with the core** (a stale beat presented after a soft reset would be held as "future").

## 7. Performance counters (`perf_sel` → `perf_data`)

Indices in `sf_collective_pkg::PC_*` (cycles, active, elements, beats in/out, input starvation, output stall, fork block, collectives ok/err, rejects, latency sum/max/last, input/output occupancy sum/max, participant imbalance max/sum, stale beats, protocol errors, lost terminators).  Counters saturate, are cleared by `perf_clear`, and are not cleared by soft reset.
