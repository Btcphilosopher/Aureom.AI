# 08 — Verification

Evidence level: RTL simulation (Verilator 5.020) against an independent software reference, bounded formal (Yosys SAT, Z3 for the exhaustive combinational checks), mutation testing of both, Yosys elaboration/synthesis for latch checks.  Numbers in this file are copied by `scripts/fill_docs.py` from `reports/`.

## 1. Headline results

| item | result | report |
|---|---|---|
| Simulation regression | **232 of 232** bench runs pass; **125,761** collectives scored against the reference; 17,791,991 simulated cycles | `reports/regression.md` |
| Formal | **48 of 48** jobs pass (exhaustive command-validation and ID-order proofs; bounded proofs; reachability witnesses) | `reports/formal.md` |
| Formal sensitivity | **27 of 27** injected RTL bugs make their named formal job fail | `reports/formal_mutants.md` |
| Mutation (simulation) | **74 of 78** injected bugs killed by at least one bench; 4 survivors, each analysed below | `reports/mutation.md` |
| Lint | Verilator `-Wall`: 0 warnings in 14 configurations; 9 illegal parameter sets rejected at elaboration | `reports/lint.md` |
| Latches | 0 in every synthesised configuration | `reports/synth.md` |
| Vendored files | 417 files byte-identical to the manifest and to their members in the repository archives | `scripts/check_vendor.py --repo <root>` |
| ABI | constants of the package == the independent reference header | `scripts/check_abi.py` |

## 2. The reference model (`tests/sf_coll_ref.h`)

Written from the ABI text with different formulations from the RTL: integer operators in **64-bit arithmetic over the exact values**; the FP32 reduction through **Berkeley SoftFloat-3e** `f32_add` (RISC-V specialisation, the repository's own FP oracle); the tree as a **recursive definition over participant ranges** (the RTL is a flat three-level array of nodes); per-receiver results by plain vector slicing; per-node flags for trees; the command-validation rules restated.  It shares no code with the RTL.  It is *not* independently authored (docs/11).

## 3. Test plan against the brief (§13)

| required | scenarios (flat bench unless noted) |
|---|---|
| SUM / MIN / MAX (and AND / OR / XOR) | `ops_all` (every operator × INT32/UINT32 × REDUCE/ALLREDUCE + BROADCAST), `special_values`, `random`; tree `ops`; memory `flow` |
| zero and negative values | `special_values` (all-zero vectors; corner values 0, ±1, 0x7FFFFFFF, 0x80000000/1, 0xFFFFFFFF, patterns), small-signed data |
| integer overflow | `special_values` (25 directed pairs: wrap, carry, exact-sum flag for INT32/UINT32, signed vs unsigned MIN/MAX), tree `overflow` (node-local flags) |
| different vector lengths | `lengths` (1…33, 63–65, 127–129, 255–257, MAX−1, MAX), `random`, tree, memory (1…257 elements) |
| empty workloads | `empty` (len = 0 mixed with real collectives, all types), memory empty collective |
| backpressure | `backpressure` (consumers, sources, completion port, command port at rates 1.0 … 0.04), tree `backpressure`, `random`; per-cycle stream-stability monitors on the output streams |
| delayed participants | `delayed` (up to 600 cycles, slow sources), `late_remote` (to 700), tree `delayed`, `cmd_skew` (commands late and uneven), `watchdog_progress` |
| missing participants | `missing` (each participant stops mid-stream; last element dropped) → `E_TIMEOUT` with the exact blamed mask, then a clean recovery; tree `faults`, `random_faults` |
| duplicate data | `duplicate` (repeated element, repeated-with-different-payload) → `E_DUP`, nothing double-counted, next collective clean; `reorder_dup` (network, every duplicate counted once), `stale` (late duplicates of finished collectives) |
| reset | `reset_hard` (asynchronous reset at 40 random points, with faults and stalled consumers), `reset_soft`, tree `reset`; engine must be clean afterwards and run a fresh collective |
| timeout | `missing`, `output_timeout` (consumer never takes the result → blamed destinations, terminators after it wakes up), `watchdog_progress` (steady-but-slow collective must NOT time out), `lost_beat` |
| multiple sequential collectives | `sequential` (80 back-to-back), `early_data` (data long before commands), `cid_wrap` (id wrap-around), `random` |
| output correctness | scoreboard on every collective: every beat's data / index / last / dtype / op / port, every completion record (status, flags, masks, ordering), terminators on failure, no beat for unknown / foreign collectives |
| independent software reference | §2 |

Failure injection (flat, tree, network, memory): dropped / duplicated / out-of-order element, wrong participant id / data type / operation, wrong LAST, early LAST, extra element, error flag, stopped stream, non-sender streaming, wrong collective id (stale / future), `part_fail`, abort, link down / lost beat / error beat, protocol and protection negatives (12 memory cases), rejected commands (13 kinds).

## 4. Benches

| bench | file | what it exercises |
|---|---|---|
| flat node | `tests/tb_main.cpp` (+ `tb_harness.h`, `tb_common.h`) | 30 scenarios (the four FP32 scenarios and the reduce-scatter / all-gather scenario are active only in builds with those options) on NP 2…8, depth 1…8 |
| tree | `tests/tt_main.cpp` over `sim/sf_collective_tree_sim.sv` | 13 scenarios + a latency measurement, on FAN 2/3/4, H 1…3, with and without FP32; control-plane command expansion; failure propagation; recovery |
| network | `tests/tn_main.cpp` over `sim/sf_collective_net_sim.sv` | remote participant over a lossy transport model |
| memory system | `tests/tm_main.cpp` over `sim/sf_collective_mm_system.sv` | real StreamDMA + MemoryMatrix + guard tables + adapters |
| performance | `tests/tp_main.cpp` | counter-based measurement (docs/09) |

## 5. Formal (`formal/`)

| harness | claim | kind |
|---|---|---|
| `fv_cid` | collective-ID serial-number order: irreflexive, asymmetric, total except half-circle, successor across wrap, windowed transitivity | exhaustive |
| `fv_cmd` | `cmd_validate` accepts exactly the specified commands and names the first failing rule, for root / interior nodes and four build option sets | exhaustive over all 2^64 commands |
| `fv_red` | the fixed reduction tree equals an independent fold from the highest participant down — every operator × data type, NP = 2, 3, 4; the INT overflow flag equals the exact-sum test; pop is all-or-none and only when every present head is valid | BMC depth 4 (all input values) |
| `fv_adapter` | what enters the input buffer is exactly the in-order, exactly-once, header-checked element stream of the running collective; future-ID beats are held, stale beats always consumed; buffer cleared at every collective boundary | BMC depth 14, shadow queue |
| `fv_outport` | **an offered beat is never withdrawn or changed until accepted**; well-formed data beats (idx < len, LAST exactly last) and terminators (err ⇒ last, no data) | BMC depth 16 |
| `fv_sched` | one completion record per popped command, none otherwise; success only after the done conditions were observed; a failed command's record only after the FP pipelines drained; context stable during a run; failure only in a running, not-done state | BMC depth 14–16 |
| `*_wit*` | reachability witnesses: the "interesting" events can occur under the harness's assumptions (they must FAIL) | witness |

Why bounded and why that is still meaningful: control state is small (FIFO levels, counters of at most 6 elements) and depths are chosen so that all state transitions of a collective of ≤ 6 elements, a failure, a flush and the start of the next collective are reachable (the witnesses show it).  This is **not** an unbounded proof; no induction was attempted.

## 6. Mutation testing (`scripts/mutate.py`)

78 deliberate bugs (classes: protocol, ordering, isolation, numerics, validation, datapath, completion, failure, network, memory).  The unmutated design must pass every bench first (baseline gate).  A mutant is **killed** when any bench set fails (flat NP=3 with FP32 + reduce-scatter + all-gather and depth 2; tree FAN 2 H 2 FP32; network WIN 4 / CREDITS 4; memory system; two seeds each).
**Survivors, each analysed** (`reports/mutation.md` is generated):

| mutant | verdict | argument |
|---|---|---|
| `fn-order` | equivalent | IEEE-754 addition is commutative bit-exactly (value and flags); swapping the FMA's operands cannot be observed |
| `fn-passthrough` | equivalent | `sel_add` has priority over `sel_a` in the node's encoder; `HAS_ADD = 0` nodes can never see both operands |
| `rd-done` | equivalent | `out_done` already implies every result beat has left the result stage, so the `!rv_q` guard in `red_done` is redundant (defence in depth) |
| `op-load-run` | equivalent | after a failure the queued terminator (`t_pend`) already blocks `load_data` in the only cycle in which the `run` gate matters; when no terminator is armed the FIFO holds nothing more (all beats loaded) |

First campaign (77 mutants; one more was added afterwards, `reports/mutation_run1.md` is kept as the record): 68 of 77 killed; of the nine survivors the five non-equivalent ones (the four above are the equivalent ones) exposed real bench gaps (non-sender data, watchdog progress semantics, stale-after-rejected-id hang, non-identity translation, store-completion ordering), closed with new scenarios — see CHANGELOG #14.

## 7. Defects found and fixed during development

CHANGELOG.md lists 14 items; the most important: an output-stability violation under failure found by the stream monitor (#1), a terminator-loss limit found by random faults (#2), and a timeout-blame refinement found while writing the test (#3).

## 8. How to reproduce

```bash
make check lint quick          # minutes
make regress formal formal-mut # ~15 minutes
make mutate                    # ~45 minutes (3 parallel builds)
make bench synth               # ~30 minutes
```
