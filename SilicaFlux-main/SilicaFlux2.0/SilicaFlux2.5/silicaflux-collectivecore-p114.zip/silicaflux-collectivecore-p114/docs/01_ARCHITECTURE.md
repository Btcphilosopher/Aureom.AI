# 01 — Architecture

## 1. Block diagram (one node, `sf_collective_core`)

```
 cmd ─► [Collective Command Queue] ─► [Operation Scheduler] ───────────────► completion records ─► cpl
         validate, strictly-increasing     ONE collective at a time;                                (one per command, in order)
         IDs, error verdict travels        watchdog, abort, part_fail,
         with the command                  first-error latch, flush
                                                │ context (cid, op, dtype, masks, lengths)
 in[0] ─► [Input Stream Controller 0] ─┐        ▼
 in[1] ─► [   (stream adapter + buffer) ]─┼─►[Reduction Datapath]──► result stream ─►[Output Stream Controller]──► out[0..NP-1]
  ...                                      │   align · select op ·    (1 element/cycle)   fork (all-or-nothing)      up  (tree interior)
 dn   ─► [Input Stream Controller dn]  ────┘   tree · overflow ·                           per-port output register
          (tree interior only)                 FP32 FMA tree ·                              + error-terminator queue
                                               result stage · counting
 perf counters ◄── events from every block
```

| module | file | responsibility |
|---|---|---|
| `sf_collective_pkg` | `rtl/sf_collective_pkg.sv` | ABI constants, command layout, `cmd_validate`, `cid_after`, operator semantics (`red_op`, `red_node`), perf map |
| `sf_collective_command_queue` | | accept commands; validate at enqueue; enforce ID order; verdict stored with the command |
| `sf_collective_scheduler` | | latch + derive lengths; run / flush / complete FSM; failure priority; watchdog; masks; one record per command |
| `sf_collective_stream_adapter` | | one per participant (+`dn`): protocol checks, stall-early / drop-stale, ordered input buffer |
| `sf_collective_reduction` | | element alignment, operator selection, fixed balanced tree (INT combinational; FP32 elastic tree of verified FMA nodes), exact overflow flag, all-gather mode, result stage, completion counting |
| `sf_collective_fp32_node` | | one FP32 tree node: join + vendored `fp32_fma` + flush-discard + in-flight count |
| `sf_collective_output` | | output stream controller: fork to destinations (broadcast / all-reduce / reduce-scatter chunking), `up` flow, delivery counting |
| `sf_collective_outport` | | one output port: FIFO + output register (an offered beat is never withdrawn) + terminator queue |
| `sf_collective_perf` | | saturating counter bank |
| `sf_collective_core` | | integration, completion buffer, imbalance / occupancy aggregation |
| `sf_collective_net_adapter` | | remote participant over a streaming transport (docs/06) |
| `sf_collective_mem_rd` / `_mem_wr` / `_mem_adapter` | | local participant over MemoryMatrix + MemoryGuard (docs/07) |
| `sim/sf_collective_tree_sim` | | FAN-ary tree of nodes (docs/04) |

## 2. The invariants the structure is built to give

1. **Collectives never mix.** An input buffer only ever holds beats whose id equals the running collective's, from the right port, in index order (formal `fv_adapter`); buffers and counters are cleared between collectives; beats of later collectives are *held*, of earlier ones *dropped*.
2. **Alignment is positional.** The k-th buffer entry is element k, so the reduction pops every present head together (formal `fv_red`: all-or-none pop, only when every present head is valid).
3. **Success is earned.** A node reports success only after the reduction is complete *and* every destination has accepted every beat (formal `fv_sched`: success ⇒ done condition seen); a memory *store* completion record exists only after every write of that store was acknowledged (adapter; the core's own record precedes it — software waits for the store completion).
4. **Failure is clean and reported.** One cause (fixed priority), one record, a flush that also drains the FP pipelines, error terminators to receivers still owed data, no leakage into the next collective.
5. **Streams are stable.** An offered beat is never withdrawn or changed (formal `fv_outport`; a per-cycle monitor on the output streams of the flat, tree and network benches).

## 3. Timing (simulation cycles; benchmarks/REPORT.md)

Integer all-reduce latency = `len + 6` for any NP ≤ 8; FP32 adds 5 cycles per tree level; the datapath retires one element per cycle; consecutive collectives are separated by ~3 cycles (no overlap).  Tree: first result at the leaves after `6 + 7·(H−1)` cycles, then one element per cycle.

## 4. Reset

`rst_n` asynchronous assert (all control state, including the FMA valid bits), `ctl_soft_reset` synchronous (same effect, counters kept, FP pipelines drained before the node accepts work again).  Datapath storage is not reset (qualified by valid bits), as in the other SilicaFlux blocks.

## 5. Parameters

`NP` (2…8), `MAX_LEN`, `IN_DEPTH` (≥ 2 for full rate), `OUT_DEPTH` (≥ 2), `CMD_DEPTH`, `CPL_DEPTH`, `TERM_DEPTH`, `INTERIOR`, `UP_PID`, `FP32_EN`, `REDSCAT_EN`, `ALLGATHER_EN`; elaboration refuses `MAX_LEN·NP ≥ 2^20` and out-of-range values.
