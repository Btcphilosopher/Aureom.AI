# 05 — The collectives: definitions and what is implemented

| collective | definition (docs/02 §1) | flat node (NP ≤ 8) | tree of nodes | verified by |
|---|---|---|---|---|
| **Reduce-to-root** (`REDUCE`) | reduction of the senders' vectors, delivered to exactly one receiver (the root) | **implemented** | **implemented** | flat: `ops_all`, `roots`-style random masks, `random`; tree: `roots`, `ops`, `random` |
| **Broadcast** (`BROADCAST`) | one sender's vector, bit-exact, to every receiver | **implemented** | **implemented** | flat: `ops_all`, `random`; tree: `roots`, `random`; FP32 broadcast is a bit copy (`fp32_sum`) |
| **All-reduce** (`ALLREDUCE`) | reduce, then the same result to every receiver | **implemented** | **implemented** | everywhere |
| **Reduce-scatter** (`REDSCAT`) | reduce, then receiver r gets chunk r of `len/R` elements | **implemented** (build option `REDSCAT_EN`) | **not implemented** (interior nodes reject it, `E_CMD_TYPE`; never advertised) | flat NP 2/3/4/8: `redscat_gather`, `random` |
| **All-gather** (`ALLGATHER`) | concatenation of the senders' vectors in participant order to every receiver | **implemented** (build option `ALLGATHER_EN`) | **not implemented** (same) | flat NP 2/3/4/8: `redscat_gather`, `random` |

Operators: SUM, MIN, MAX, AND, OR, XOR on INT32 / UINT32; FP32 SUM (`FP32_EN`).  `caps` reports exactly the build's capabilities; a command outside them is rejected with a specific error and an in-order completion record — it is never silently ignored or partially run.

The five collectives are **distinct hardware paths**, not renamings: REDUCE/ALLREDUCE differ in the destination set (the fork), BROADCAST uses the single-contributor pass-through of the tree, REDSCAT uses the chunked destination pointer of the output controller, ALLGATHER replaces the tree by a sequential participant-ordered copy in the reduction module.

Not implemented anywhere: all-to-all, scan, barrier as a collective, gather/scatter to a root, variable chunk sizes, non-contiguous layouts (the memory adapters move contiguous buffers; scatter-gather is StreamDMA's job).
