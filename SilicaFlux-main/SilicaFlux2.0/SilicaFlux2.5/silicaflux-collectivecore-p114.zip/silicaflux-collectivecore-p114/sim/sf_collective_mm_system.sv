// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_mm_system -- two local accelerator participants over the real memory system
//
//   host (bench) --master 4--+
//   sf_stream_dma --bridge--master 0/1--+                       masters of sf_memory_matrix (P101, vendored, unmodified):
//   mem adapter 0 -------------master 2--+--> sf_memory_matrix       0 StreamDMA read   1 StreamDMA write   2 adapter of participant 0
//   mem adapter 1 -------------master 3--+                           3 adapter of participant 1   4 host (backdoor load / dump through the REAL port)
//   adapter i : load descriptor -> stream into participant i of sf_collective_core;  core result stream of participant i -> store descriptor
//   guards    : three vendored P64 permission tables (StreamDMA, adapter 0, adapter 1) -- the MemoryGuard stand-in the repository has
// StreamDMA stages the buffers: it copies host-filled SRAM buffers (memory type 1) into the compute scratchpad buffers (type 4) that
// the adapters load, and drains the result buffers back.  Nothing peeks into the SRAM arrays.
// =============================================================================
`default_nettype none
module sf_collective_mm_system
  import sf_collective_pkg::*;
#(
  parameter int MAX_LEN     = 1024,
  parameter int IN_DEPTH    = 4,
  parameter int OUT_DEPTH   = 4,
  parameter int DATA_WIDTH  = 128,
  parameter int NUM_BANKS   = 4,
  parameter int BANK_DEPTH  = 4096,
  parameter int READ_LATENCY= 1,
  parameter int MM_NSLOT    = 8,
  localparam int AW         = 32,
  localparam int MM_AW      = 20,
  localparam int DOM_W      = 4,
  localparam int MM_IDW     = 8,
  localparam int W          = DATA_WIDTH / 8,
  localparam int LW         = $clog2(DATA_WIDTH / 8),
  localparam int SZW        = (LW > 0) ? $clog2(LW + 1) : 1,
  localparam int NM         = 5
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // ---- collective core
  input  wire logic [31:0]          cfg_timeout,
  input  wire logic                 cmd_valid,
  output logic                      cmd_ready,
  input  wire logic [CMD_W-1:0]     cmd_data,
  output logic                      cpl_valid,
  input  wire logic                 cpl_ready,
  output logic [CID_W-1:0]          cpl_cid,
  output logic                      cpl_ok,
  output logic [3:0]                cpl_err,
  output logic                      core_idle,
  // ---- adapters (index = participant)
  input  wire logic [1:0]           ld_valid,
  output logic [1:0]                ld_ready,
  input  wire logic [2*CID_W-1:0]   ld_cid,
  input  wire logic [3:0]           ld_dtype,
  input  wire logic [5:0]           ld_op,
  input  wire logic [2*AW-1:0]      ld_iova,
  input  wire logic [2*LEN_W-1:0]   ld_len,
  input  wire logic [2*DOM_W-1:0]   ld_dom,
  output logic [1:0]                ldc_valid,
  input  wire logic [1:0]           ldc_ready,
  output logic [2*CID_W-1:0]        ldc_cid,
  output logic [5:0]                ldc_err,
  input  wire logic [1:0]           st_valid,
  output logic [1:0]                st_ready,
  input  wire logic [2*CID_W-1:0]   st_cid,
  input  wire logic [2*AW-1:0]      st_iova,
  input  wire logic [2*LEN_W-1:0]   st_len,
  input  wire logic [2*DOM_W-1:0]   st_dom,
  output logic [1:0]                stc_valid,
  input  wire logic [1:0]           stc_ready,
  output logic [2*CID_W-1:0]        stc_cid,
  output logic [5:0]                stc_err,
  // ---- StreamDMA
  input  wire logic                 desc_valid,
  output logic                      desc_ready,
  input  wire logic [255:0]         desc_data,
  input  wire logic [DOM_W-1:0]     desc_domain,
  output logic                      dcpl_valid,
  input  wire logic                 dcpl_ready,
  output logic [15:0]               dcpl_txn_id,
  output logic [3:0]                dcpl_status,
  output logic [7:0]                dcpl_err,
  output logic [31:0]               dcpl_bytes_done,
  // ---- guard table programming: sel 0 = StreamDMA, 1 = adapter 0, 2 = adapter 1
  input  wire logic [1:0]           tw_sel,
  input  wire logic                 tw_en,
  input  wire logic [3:0]           tw_idx,
  input  wire logic                 tw_valid,
  input  wire logic [DOM_W-1:0]     tw_domain,
  input  wire logic [3:0]           tw_asid,
  input  wire logic [AW-1:0]        tw_base,
  input  wire logic [AW:0]          tw_size,
  input  wire logic [AW-1:0]        tw_pa,
  input  wire logic [1:0]           tw_perm,
  // ---- host master (matrix master 4)
  input  wire logic                 host_req_valid,
  output logic                      host_req_ready,
  input  wire logic                 host_we,
  input  wire logic [MM_AW-1:0]     host_addr,
  input  wire logic [SZW-1:0]       host_size,
  input  wire logic [31:0]          host_wdata,
  input  wire logic [3:0]           host_be,
  output logic                      host_rsp_valid,
  output logic [31:0]               host_rsp_rdata,
  output logic [2:0]                host_rsp_status,
  // ---- matrix counters
  output logic [31:0]               mm_acc_rd, mm_acc_wr, mm_rej, mm_cycles,
  output logic [63:0]               core_perf_elems, core_perf_active
);
  // ---------------------------------------------------------------- collective core (NP = 2, both participants local)
  logic [1:0]            c_in_valid, c_in_ready, c_in_last, c_in_err, c_out_valid, c_out_ready, c_out_last, c_out_err;
  logic [2*CID_W-1:0]    c_in_cid, c_out_cid;
  logic [2*PID_W-1:0]    c_in_pid, c_out_pid;
  logic [2*IDX_W-1:0]    c_in_idx, c_out_idx;
  logic [3:0]            c_in_dtype, c_out_dtype;
  logic [5:0]            c_in_op, c_out_op;
  logic [2*DATA_W-1:0]   c_in_data, c_out_data;
  logic [63:0]           pd0, pd1;
  logic                  core_cpl_flags_unused;
  sf_collective_core #(.NP(2), .MAX_LEN(MAX_LEN), .IN_DEPTH(IN_DEPTH), .OUT_DEPTH(OUT_DEPTH)) u_core (
    .clk(clk), .rst_n(rst_n), .ctl_soft_reset(1'b0), .ctl_abort(1'b0), .cfg_timeout(cfg_timeout), .part_fail(2'b00),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_data(cmd_data),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_cid(cpl_cid), .cpl_ok(cpl_ok), .cpl_err(cpl_err), .cpl_ctype(), .cpl_flags(),
    .cpl_maskA(), .cpl_maskB(), .cpl_len(), .cpl_cycles(),
    .in_valid(c_in_valid), .in_ready(c_in_ready), .in_cid(c_in_cid), .in_pid(c_in_pid), .in_idx(c_in_idx), .in_dtype(c_in_dtype), .in_op(c_in_op),
    .in_data(c_in_data), .in_last(c_in_last), .in_err(c_in_err),
    .out_valid(c_out_valid), .out_ready(c_out_ready), .out_cid(c_out_cid), .out_pid(c_out_pid), .out_idx(c_out_idx), .out_dtype(c_out_dtype),
    .out_op(c_out_op), .out_data(c_out_data), .out_last(c_out_last), .out_err(c_out_err),
    .up_valid(), .up_ready(1'b1), .up_cid(), .up_pid(), .up_idx(), .up_dtype(), .up_op(), .up_data(), .up_last(), .up_err(),
    .dn_valid(1'b0), .dn_ready(), .dn_cid('0), .dn_pid('0), .dn_idx('0), .dn_dtype('0), .dn_op('0), .dn_data('0), .dn_last(1'b0), .dn_err(1'b0),
    .perf_clear(1'b0), .perf_sel(6'd2), .perf_data(pd0), .idle(core_idle), .caps()
  );
  assign core_perf_elems  = pd0;
  assign pd1 = 64'd0;
  assign core_perf_active = pd1;

  // ---------------------------------------------------------------- guard tables
  logic [2:0] gq_valid, gq_ready, gq_write, gq_id, gr_valid, gr_ready, gr_id, gr_ok, gt_ready, tw_rej;
  logic [DOM_W-1:0]   gq_dom [3];
  logic [3:0]         gq_asid [3], gr_fault [3];
  logic [AW-1:0]      gq_addr [3], gr_pa [3];
  logic [15:0]        gq_bytes [3];
  logic [31:0]        rej_count [3];
  generate
    for (genvar t = 0; t < 3; t++) begin : g_tab
      sfdma_perm_table #(.AW(AW), .DOM_W(DOM_W), .IDW(1), .NENT(16), .LAT(2)) u_table (
        .clk(clk), .rst_n(rst_n),
        .tw_en(tw_en && tw_sel == 2'(t)), .tw_idx(tw_idx), .tw_valid(tw_valid), .tw_domain(tw_domain), .tw_asid(tw_asid), .tw_base(tw_base),
        .tw_size(tw_size), .tw_pa(tw_pa), .tw_perm(tw_perm), .tw_rej(tw_rej[t]), .rej_count(rej_count[t]),
        .req_valid(gq_valid[t]), .req_ready(gt_ready[t]), .req_domain(gq_dom[t]), .req_asid(gq_asid[t]), .req_write(gq_write[t]),
        .req_addr(gq_addr[t]), .req_bytes(gq_bytes[t]), .req_id(gq_id[t]),
        .rsp_valid(gr_valid[t]), .rsp_ready(gr_ready[t]), .rsp_id(gr_id[t]), .rsp_ok(gr_ok[t]), .rsp_fault(gr_fault[t]), .rsp_pa(gr_pa[t]));
      assign gq_ready[t] = gt_ready[t];
    end
  endgenerate

  // ---------------------------------------------------------------- StreamDMA + bridge
  logic ar_valid, ar_ready, r_valid, r_ready, r_last, aw_valid, aw_ready, w_valid, w_ready, w_last, b_valid, b_ready;
  logic ar_id, r_id, aw_id, b_id;
  logic [AW-1:0] ar_addr, aw_addr;
  logic [7:0] ar_len, aw_len; logic [2:0] ar_size, aw_size; logic [1:0] ar_burst, aw_burst, r_resp, b_resp;
  logic [3:0] ar_mtype, aw_mtype; logic [DOM_W-1:0] ar_domain, aw_domain;
  logic [DATA_WIDTH-1:0] r_data, w_data; logic [W-1:0] w_strb;
  logic [47:0] dummy_bytes_total; logic [3:0] dcpl_domain_unused; logic [3:0] dcpl_detail; logic [AW-1:0] dcpl_err_addr; logic [31:0] dcpl_lat; logic dcpl_partial, irq, dbusy, dfenced;
  logic dsr_pending, dsr_active, dgproto;
  logic [30:0] dcpl_bytes_done_w, dcpl_bytes_total_w;
  logic [DOM_W-1:0] dcpl_domain;
  logic [63:0] dperf;

  sf_stream_dma #(.DATA_WIDTH(DATA_WIDTH), .ADDR_WIDTH(AW), .NUM_CHANNELS(1), .BURST_LENGTH(16), .FIFO_DEPTH(64), .MAX_OUTSTANDING_READS(2),
                  .MAX_OUTSTANDING_WRITES(2), .DESCRIPTOR_DEPTH(4), .DOM_W(DOM_W), .SEG_DEPTH(2), .PLAN_DEPTH(1), .WR_FIFO_DEPTH(32),
                  .MAX_SEG_LOG2(24), .MAX_TXN_LOG2(30)) u_dma (
    .clk(clk), .rst_n(rst_n), .ctl_abort(1'b0), .ctl_soft_reset(1'b0), .cfg_timeout(32'd0), .cfg_type_en(16'hFFFF),
    .desc_valid(desc_valid), .desc_ready(desc_ready), .desc_data(desc_data), .desc_domain(desc_domain),
    .cpl_valid(dcpl_valid), .cpl_ready(dcpl_ready), .cpl_txn_id(dcpl_txn_id), .cpl_domain(dcpl_domain), .cpl_status(dcpl_status),
    .cpl_err(dcpl_err), .cpl_detail(dcpl_detail), .cpl_bytes_done(dcpl_bytes_done_w), .cpl_bytes_total(dcpl_bytes_total_w),
    .cpl_err_addr(dcpl_err_addr), .cpl_latency(dcpl_lat), .cpl_partial(dcpl_partial), .irq(irq),
    .guard_req_valid(gq_valid[0]), .guard_req_ready(gq_ready[0]), .guard_req_domain(gq_dom[0]), .guard_req_asid(gq_asid[0]),
    .guard_req_write(gq_write[0]), .guard_req_addr(gq_addr[0]), .guard_req_bytes(gq_bytes[0]), .guard_req_id(gq_id[0]),
    .guard_rsp_valid(gr_valid[0]), .guard_rsp_ready(gr_ready[0]), .guard_rsp_id(gr_id[0]), .guard_rsp_ok(gr_ok[0]),
    .guard_rsp_fault(gr_fault[0]), .guard_rsp_pa(gr_pa[0]),
    .ar_valid(ar_valid), .ar_ready(ar_ready), .ar_id(ar_id), .ar_addr(ar_addr), .ar_len(ar_len), .ar_size(ar_size), .ar_burst(ar_burst),
    .ar_mtype(ar_mtype), .ar_domain(ar_domain), .r_valid(r_valid), .r_ready(r_ready), .r_id(r_id), .r_data(r_data), .r_resp(r_resp), .r_last(r_last),
    .aw_valid(aw_valid), .aw_ready(aw_ready), .aw_id(aw_id), .aw_addr(aw_addr), .aw_len(aw_len), .aw_size(aw_size), .aw_burst(aw_burst),
    .aw_mtype(aw_mtype), .aw_domain(aw_domain), .w_valid(w_valid), .w_ready(w_ready), .w_data(w_data), .w_strb(w_strb), .w_last(w_last),
    .b_valid(b_valid), .b_ready(b_ready), .b_id(b_id), .b_resp(b_resp),
    .busy(dbusy), .fenced(dfenced), .guard_proto_err(dgproto), .soft_reset_pending(dsr_pending), .soft_reset_active(dsr_active),
    .perf_clear(1'b0), .perf_sel(6'd0), .perf_data(dperf));
  assign dcpl_bytes_done = 32'(dcpl_bytes_done_w);

  logic rd_req_valid, rd_req_ready, rd_rsp_valid, rd_rsp_ready, wr_req_valid, wr_req_ready, wr_rsp_valid, wr_rsp_ready, bridge_proto_err;
  logic [MM_AW-1:0] rd_req_addr, wr_req_addr; logic [SZW-1:0] rd_req_size, wr_req_size; logic [MM_IDW-1:0] rd_req_id, rd_rsp_id, wr_req_id, wr_rsp_id;
  logic [1:0] rd_req_prot, wr_req_prot; logic [DATA_WIDTH-1:0] rd_rsp_rdata, wr_req_wdata; logic [2:0] rd_rsp_status, wr_rsp_status; logic [W-1:0] wr_req_be;
  sf_stream_dma_mm_bridge #(.DATA_WIDTH(DATA_WIDTH), .ADDR_WIDTH(AW), .MM_AW(MM_AW), .RIDW(1), .WIDW(1), .MM_IDW(MM_IDW), .AW_DEPTH(2), .DOM_W(DOM_W),
                            .TYPE_MASK(16'h0012), .SECURE_MASK(16'h0000)) u_bridge (
    .clk(clk), .rst_n(rst_n),
    .ar_valid(ar_valid), .ar_ready(ar_ready), .ar_id(ar_id), .ar_addr(ar_addr), .ar_len(ar_len), .ar_size(ar_size), .ar_burst(ar_burst),
    .ar_mtype(ar_mtype), .ar_domain(ar_domain), .r_valid(r_valid), .r_ready(r_ready), .r_id(r_id), .r_data(r_data), .r_resp(r_resp), .r_last(r_last),
    .aw_valid(aw_valid), .aw_ready(aw_ready), .aw_id(aw_id), .aw_addr(aw_addr), .aw_len(aw_len), .aw_size(aw_size), .aw_burst(aw_burst),
    .aw_mtype(aw_mtype), .aw_domain(aw_domain), .w_valid(w_valid), .w_ready(w_ready), .w_data(w_data), .w_strb(w_strb), .w_last(w_last),
    .b_valid(b_valid), .b_ready(b_ready), .b_id(b_id), .b_resp(b_resp),
    .rd_req_valid(rd_req_valid), .rd_req_ready(rd_req_ready), .rd_req_addr(rd_req_addr), .rd_req_size(rd_req_size), .rd_req_id(rd_req_id), .rd_req_prot(rd_req_prot),
    .rd_rsp_valid(rd_rsp_valid), .rd_rsp_ready(rd_rsp_ready), .rd_rsp_rdata(rd_rsp_rdata), .rd_rsp_id(rd_rsp_id), .rd_rsp_status(rd_rsp_status),
    .wr_req_valid(wr_req_valid), .wr_req_ready(wr_req_ready), .wr_req_addr(wr_req_addr), .wr_req_size(wr_req_size), .wr_req_wdata(wr_req_wdata),
    .wr_req_be(wr_req_be), .wr_req_id(wr_req_id), .wr_req_prot(wr_req_prot),
    .wr_rsp_valid(wr_rsp_valid), .wr_rsp_ready(wr_rsp_ready), .wr_rsp_id(wr_rsp_id), .wr_rsp_status(wr_rsp_status), .proto_err(bridge_proto_err));

  // ---------------------------------------------------------------- memory adapters (one per local participant)
  logic [1:0] am_req_valid, am_req_ready, am_req_we, am_rsp_valid, am_rsp_we;
  logic [2*MM_AW-1:0] am_req_addr; logic [2*SZW-1:0] am_req_size; logic [2*DATA_WIDTH-1:0] am_req_wdata, am_rsp_rdata; logic [2*W-1:0] am_req_be;
  logic [2*MM_IDW-1:0] am_req_id; logic [2*2-1:0] am_req_prot; logic [2*3-1:0] am_rsp_status;
  generate
    for (genvar a = 0; a < 2; a++) begin : g_ad
      logic [CID_W-1:0] s_cid, o_cid_l; logic [PID_W-1:0] s_pid; logic [IDX_W-1:0] s_idx; logic [1:0] s_dt; logic [2:0] s_op; logic [DATA_W-1:0] s_data;
      logic s_valid, s_ready, s_last, s_err, o_valid, o_ready, o_last, o_err; logic [IDX_W-1:0] o_idx_l; logic [DATA_W-1:0] o_data_l;
      logic evr, evw, evb;
      sf_collective_mem_adapter #(.AW(AW), .MM_AW(MM_AW), .DOM_W(DOM_W), .MAX_LEN(MAX_LEN), .PID(a), .DATA_WIDTH(DATA_WIDTH), .MM_IDW(MM_IDW),
                                  .MEMTYPE(4'd4), .SECURE_MASK(16'h0000)) u_ad (
        .clk(clk), .rst_n(rst_n), .sclr(1'b0),
        .ld_valid(ld_valid[a]), .ld_ready(ld_ready[a]), .ld_cid(ld_cid[a*CID_W +: CID_W]), .ld_dtype(ld_dtype[a*2 +: 2]), .ld_op(ld_op[a*3 +: 3]),
        .ld_iova(ld_iova[a*AW +: AW]), .ld_len(ld_len[a*LEN_W +: LEN_W]), .ld_dom(ld_dom[a*DOM_W +: DOM_W]),
        .ldc_valid(ldc_valid[a]), .ldc_ready(ldc_ready[a]), .ldc_cid(ldc_cid[a*CID_W +: CID_W]), .ldc_err(ldc_err[a*3 +: 3]),
        .st_valid(st_valid[a]), .st_ready(st_ready[a]), .st_cid(st_cid[a*CID_W +: CID_W]), .st_iova(st_iova[a*AW +: AW]), .st_len(st_len[a*LEN_W +: LEN_W]),
        .st_dom(st_dom[a*DOM_W +: DOM_W]),
        .stc_valid(stc_valid[a]), .stc_ready(stc_ready[a]), .stc_cid(stc_cid[a*CID_W +: CID_W]), .stc_err(stc_err[a*3 +: 3]),
        .s_valid(s_valid), .s_ready(s_ready), .s_cid(s_cid), .s_pid(s_pid), .s_idx(s_idx), .s_dtype(s_dt), .s_op(s_op), .s_data(s_data), .s_last(s_last), .s_err(s_err),
        .o_valid(o_valid), .o_ready(o_ready), .o_cid(o_cid_l), .o_idx(o_idx_l), .o_data(o_data_l), .o_last(o_last), .o_err(o_err),
        .guard_req_valid(gq_valid[a+1]), .guard_req_ready(gq_ready[a+1]), .guard_req_domain(gq_dom[a+1]), .guard_req_asid(gq_asid[a+1]),
        .guard_req_write(gq_write[a+1]), .guard_req_addr(gq_addr[a+1]), .guard_req_bytes(gq_bytes[a+1]), .guard_req_id(gq_id[a+1]),
        .guard_rsp_valid(gr_valid[a+1]), .guard_rsp_ready(gr_ready[a+1]), .guard_rsp_id(gr_id[a+1]), .guard_rsp_ok(gr_ok[a+1]), .guard_rsp_pa(gr_pa[a+1]),
        .m_req_valid(am_req_valid[a]), .m_req_ready(am_req_ready[a]), .m_req_we(am_req_we[a]), .m_req_addr(am_req_addr[a*MM_AW +: MM_AW]),
        .m_req_size(am_req_size[a*SZW +: SZW]), .m_req_wdata(am_req_wdata[a*DATA_WIDTH +: DATA_WIDTH]), .m_req_be(am_req_be[a*W +: W]),
        .m_req_id(am_req_id[a*MM_IDW +: MM_IDW]), .m_req_prot(am_req_prot[a*2 +: 2]),
        .m_rsp_valid(am_rsp_valid[a]), .m_rsp_ready(), .m_rsp_rdata(am_rsp_rdata[a*DATA_WIDTH +: DATA_WIDTH]), .m_rsp_we(am_rsp_we[a]),
        .m_rsp_status(am_rsp_status[a*3 +: 3]), .ev_rd_elem(evr), .ev_wr_elem(evw), .ev_busy(evb));
      // participant a of the core
      assign c_in_valid[a] = s_valid; assign s_ready = c_in_ready[a];
      assign c_in_cid[a*CID_W +: CID_W] = s_cid; assign c_in_pid[a*PID_W +: PID_W] = s_pid; assign c_in_idx[a*IDX_W +: IDX_W] = s_idx;
      assign c_in_dtype[a*2 +: 2] = s_dt; assign c_in_op[a*3 +: 3] = s_op; assign c_in_data[a*DATA_W +: DATA_W] = s_data;
      assign c_in_last[a] = s_last; assign c_in_err[a] = s_err;
      assign o_valid = c_out_valid[a]; assign c_out_ready[a] = o_ready;
      assign o_cid_l = c_out_cid[a*CID_W +: CID_W]; assign o_idx_l = c_out_idx[a*IDX_W +: IDX_W]; assign o_data_l = c_out_data[a*DATA_W +: DATA_W];
      assign o_last = c_out_last[a]; assign o_err = c_out_err[a];
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_ev = evr ^ evw ^ evb;
      /* verilator lint_on UNUSEDSIGNAL */
    end
  endgenerate

  // ---------------------------------------------------------------- MemoryMatrix
  logic [NM-1:0]               m_req_valid, m_req_ready, m_req_we, m_rsp_valid, m_rsp_ready, m_rsp_we, m_rsp_ce;
  logic [NM*MM_AW-1:0]         m_req_addr;
  logic [NM*SZW-1:0]           m_req_size;
  logic [NM*DATA_WIDTH-1:0]    m_req_wdata, m_rsp_rdata;
  logic [NM*W-1:0]             m_req_be;
  logic [NM*MM_IDW-1:0]        m_req_id, m_rsp_id;
  logic [NM*2-1:0]             m_req_prot;
  logic [NM*3-1:0]             m_rsp_status;
  assign m_req_valid = {host_req_valid, am_req_valid[1], am_req_valid[0], wr_req_valid, rd_req_valid};
  assign m_req_we    = {host_we, am_req_we[1], am_req_we[0], 1'b1, 1'b0};
  assign m_req_addr  = {host_addr, am_req_addr, wr_req_addr, rd_req_addr};
  assign m_req_size  = {host_size, am_req_size, wr_req_size, rd_req_size};
  assign m_req_wdata = {{{(DATA_WIDTH-32){1'b0}}, host_wdata}, am_req_wdata, wr_req_wdata, {DATA_WIDTH{1'b0}}};
  assign m_req_be    = {{{(W-4){1'b0}}, host_be}, am_req_be, wr_req_be, {W{1'b0}}};
  assign m_req_id    = {{MM_IDW{1'b0}}, am_req_id, wr_req_id, rd_req_id};
  assign m_req_prot  = {2'b11, am_req_prot, wr_req_prot, rd_req_prot};
  assign rd_req_ready = m_req_ready[0]; assign wr_req_ready = m_req_ready[1]; assign am_req_ready = m_req_ready[3:2]; assign host_req_ready = m_req_ready[4];
  assign m_rsp_ready = {1'b1, 1'b1, 1'b1, wr_rsp_ready, rd_rsp_ready};
  assign rd_rsp_valid = m_rsp_valid[0]; assign wr_rsp_valid = m_rsp_valid[1]; assign am_rsp_valid = m_rsp_valid[3:2];
  assign rd_rsp_rdata = m_rsp_rdata[0*DATA_WIDTH +: DATA_WIDTH]; assign rd_rsp_id = m_rsp_id[0*MM_IDW +: MM_IDW]; assign rd_rsp_status = m_rsp_status[0 +: 3];
  assign wr_rsp_id = m_rsp_id[1*MM_IDW +: MM_IDW]; assign wr_rsp_status = m_rsp_status[3 +: 3];
  assign am_rsp_rdata = m_rsp_rdata[2*DATA_WIDTH +: 2*DATA_WIDTH]; assign am_rsp_we = m_rsp_we[3:2]; assign am_rsp_status = m_rsp_status[2*3 +: 2*3];
  assign host_rsp_valid = m_rsp_valid[4]; assign host_rsp_rdata = m_rsp_rdata[4*DATA_WIDTH +: 32]; assign host_rsp_status = m_rsp_status[4*3 +: 3];

  localparam int NRG = 2;
  logic [31:0] pc_cycles; logic [NUM_BANKS*32-1:0] pc_acc_rd, pc_acc_wr, pc_conf, pc_lost, pc_busy;
  logic [NM*32-1:0] pc_mstall, pc_arbstall, pc_busystall, pc_selfconf, pc_starve, pc_reqs, pc_bytes_rd, pc_bytes_wr, pc_lat_cnt; logic [4*32-1:0] pc_starve_cls;
  logic [NM*40-1:0] pc_lat_sum; logic [NM*20-1:0] pc_lat_max; logic [31:0] pc_rej;
  logic [NUM_BANKS-1:0] ev_ce, ev_ue, trc_acc, trc_we; logic [NUM_BANKS*MM_AW-1:0] ev_addr; logic [NUM_BANKS*16-1:0] ce_cnt, ue_cnt; logic flush_busy, init_busy, mm_idle;
  localparam int MW_ = $clog2(NM); localparam int SW_ = $clog2(MM_NSLOT); localparam int K_ = (DATA_WIDTH / 8 + 2 * 8 - 2) / 8; localparam int KW_ = (K_ > 1) ? $clog2(K_) : 1;
  localparam int ROW_W_ = $clog2(BANK_DEPTH); localparam int STORE_W_ = 64; localparam int FBW_ = $clog2(STORE_W_); localparam int BW_ = $clog2(NUM_BANKS);
  logic [NUM_BANKS*MW_-1:0] trc_m; logic [NUM_BANKS*SW_-1:0] trc_slot; logic [NUM_BANKS*KW_-1:0] trc_k; logic [NUM_BANKS*ROW_W_-1:0] trc_row; logic [NUM_BANKS*STORE_W_-1:0] tst_rdata;
  sf_memory_matrix #(.NUM_BANKS(NUM_BANKS), .BANK_DEPTH(BANK_DEPTH), .WORD_WIDTH(64), .DATA_WIDTH(DATA_WIDTH), .READ_LATENCY(READ_LATENCY), .NUM_MASTERS(NM),
                     .ENABLE_ECC(0), .AW(MM_AW), .IDW(MM_IDW), .NSLOT(MM_NSLOT), .ISSUE_WINDOW(1), .INTERLEAVE_MODE(0), .ILV_GRAN_LOG2(0), .NUM_REGIONS(NRG),
                     .DEFAULT_ALLOW(1), .MCLASS(32'hFFFFFCAF)) u_mm (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr), .m_req_size(m_req_size), .m_req_wdata(m_req_wdata),
    .m_req_be(m_req_be), .m_req_id(m_req_id), .m_req_prot(m_req_prot),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we), .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .rg_base_i({NRG*MM_AW{1'b0}}), .rg_last_i({NRG*MM_AW{1'b0}}), .rg_perm_i({NRG*5{1'b0}}), .rg_mmask_i({NRG*NM{1'b0}}),
    .flush_i(1'b0), .flush_busy_o(flush_busy), .quiesce_i(1'b0), .idle_o(mm_idle), .init_start_i(1'b0), .init_busy_o(init_busy), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(ev_ce), .ev_ue_o(ev_ue), .ev_addr_o(ev_addr), .ce_cnt_o(ce_cnt), .ue_cnt_o(ue_cnt),
    .perf_clr_i(1'b0), .perf_cycles_o(pc_cycles), .perf_acc_rd_o(pc_acc_rd), .perf_acc_wr_o(pc_acc_wr), .perf_conf_o(pc_conf), .perf_lost_o(pc_lost), .perf_busy_o(pc_busy),
    .perf_mstall_o(pc_mstall), .perf_arbstall_o(pc_arbstall), .perf_busystall_o(pc_busystall), .perf_selfconf_o(pc_selfconf), .perf_starve_o(pc_starve),
    .perf_starve_cls_o(pc_starve_cls), .perf_reqs_o(pc_reqs), .perf_bytes_rd_o(pc_bytes_rd), .perf_bytes_wr_o(pc_bytes_wr), .perf_lat_sum_o(pc_lat_sum),
    .perf_lat_cnt_o(pc_lat_cnt), .perf_lat_max_o(pc_lat_max), .perf_rej_o(pc_rej),
    .trc_acc_o(trc_acc), .trc_we_o(trc_we), .trc_m_o(trc_m), .trc_slot_o(trc_slot), .trc_k_o(trc_k), .trc_row_o(trc_row),
    .tst_active_i(1'b0), .tst_sel_i({NUM_BANKS{1'b0}}), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i({ROW_W_{1'b0}}), .tst_wdata_i({STORE_W_{1'b0}}), .tst_rdata_o(tst_rdata),
    .fi_bank({BW_{1'b0}}), .fi_type(4'd0), .fi_row({ROW_W_{1'b0}}), .fi_row2({ROW_W_{1'b0}}), .fi_bit({FBW_{1'b0}}), .fi_bit2({FBW_{1'b0}}), .fi_val(1'b0), .fi_val2(1'b0),
    .seu_pulse(1'b0), .seu_row({ROW_W_{1'b0}}), .seu_mask({STORE_W_{1'b0}}));

  function automatic logic [31:0] sum_nb(input logic [NUM_BANKS*32-1:0] v);
    logic [31:0] s; s = 32'd0;
    for (int i = 0; i < NUM_BANKS; i++) s = s + v[i*32 +: 32];
    sum_nb = s;
  endfunction
  assign mm_acc_rd = sum_nb(pc_acc_rd); assign mm_acc_wr = sum_nb(pc_acc_wr); assign mm_rej = pc_rej; assign mm_cycles = pc_cycles;

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_all = &{1'b0, tw_rej, rej_count[0], rej_count[1], rej_count[2], gr_fault[0], gr_fault[1], gr_fault[2], dcpl_domain, dcpl_detail, dcpl_err_addr, dcpl_lat, dcpl_partial, irq, dbusy, dfenced,
                      dsr_pending, dsr_active, dgproto, dcpl_bytes_total_w, dperf, bridge_proto_err, m_rsp_ce, pc_busystall, pc_selfconf, pc_starve, pc_starve_cls, pc_reqs, pc_bytes_rd,
                      pc_bytes_wr, pc_lat_cnt, pc_lat_sum, pc_lat_max, pc_mstall, pc_arbstall, pc_conf, pc_lost, pc_busy, ev_ce, ev_ue, ev_addr, ce_cnt, ue_cnt, trc_acc, trc_we, trc_m,
                      trc_slot, trc_k, trc_row, tst_rdata, flush_busy, init_busy, mm_idle, dummy_bytes_total, dcpl_domain_unused, core_cpl_flags_unused, m_rsp_id[NM*MM_IDW-1:2*MM_IDW],
                      m_rsp_we[0], m_rsp_we[1], m_rsp_we[4], 1'b0};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
