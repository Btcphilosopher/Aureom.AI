// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_net_sim -- two-participant system with a REMOTE participant
//   participant 0: local, direct stream ports (p0_*)        participant 1: remote, through sf_collective_net_adapter (transport ports)
// The bench plays the remote node: it injects transport beats (reordered / duplicated / dropped / late) and consumes the TX beats,
// returns credits, and watches the completion acks.
// =============================================================================
`default_nettype none
module sf_collective_net_sim
  import sf_collective_pkg::*;
#(
  parameter int MAX_LEN   = 300,
  parameter int IN_DEPTH  = 4,
  parameter int OUT_DEPTH = 4,
  parameter int WIN       = 8,
  parameter int CREDITS   = 8
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic [31:0]         cfg_timeout,        // core watchdog
  input  wire logic [31:0]         link_timeout,       // adapter watchdog
  input  wire logic                ctl_clear,
  input  wire logic                link_down,
  input  wire logic                ctl_abort,
  // core command / completion
  input  wire logic                cmd_valid,
  output logic                     cmd_ready,
  input  wire logic [CMD_W-1:0]    cmd_data,
  output logic                     cpl_valid,
  input  wire logic                cpl_ready,
  output logic [CID_W-1:0]         cpl_cid,
  output logic                     cpl_ok,
  output logic [3:0]               cpl_err,
  output logic [8:0]               cpl_maskA,
  output logic [8:0]               cpl_maskB,
  output logic [5:0]               cpl_flags,
  // participant 0 (local)
  input  wire logic                p0_in_valid,
  output logic                     p0_in_ready,
  input  wire logic [CID_W-1:0]    p0_in_cid,
  input  wire logic [PID_W-1:0]    p0_in_pid,
  input  wire logic [IDX_W-1:0]    p0_in_idx,
  input  wire logic [1:0]          p0_in_dtype,
  input  wire logic [2:0]          p0_in_op,
  input  wire logic [DATA_W-1:0]   p0_in_data,
  input  wire logic                p0_in_last,
  input  wire logic                p0_in_err,
  output logic                     p0_out_valid,
  input  wire logic                p0_out_ready,
  output logic [CID_W-1:0]         p0_out_cid,
  output logic [PID_W-1:0]         p0_out_pid,
  output logic [IDX_W-1:0]         p0_out_idx,
  output logic [DATA_W-1:0]        p0_out_data,
  output logic                     p0_out_last,
  output logic                     p0_out_err,
  // participant 1 (remote) transport
  input  wire logic                rx_valid,
  output logic                     rx_ready,
  input  wire logic [CID_W-1:0]    rx_xfer,
  input  wire logic [IDX_W-1:0]    rx_seq,
  input  wire logic [1:0]          rx_dtype,
  input  wire logic [2:0]          rx_op,
  input  wire logic [DATA_W-1:0]   rx_data,
  input  wire logic                rx_last,
  input  wire logic                rx_err,
  output logic                     tx_valid,
  input  wire logic                tx_ready,
  output logic [CID_W-1:0]         tx_xfer,
  output logic [IDX_W-1:0]         tx_seq,
  output logic [DATA_W-1:0]        tx_data,
  output logic                     tx_last,
  output logic                     tx_err,
  input  wire logic                tx_credit,
  output logic                     ack_valid,
  input  wire logic                ack_ready,
  output logic [CID_W-1:0]         ack_cid,
  output logic                     ack_ok,
  output logic [3:0]               ack_err,
  output logic                     ack_blamed,
  // status
  output logic                     fail_out, st_timeout, st_down,
  output logic                     ev_rx, ev_tx, ev_dup, ev_stale, ev_reorder, ev_cred_stall, ev_ack_lost,
  output logic                     idle
);
  logic [1:0]        in_valid, in_ready, in_last, in_err, out_valid, out_ready, out_last, out_err;
  logic [2*CID_W-1:0]  in_cid, out_cid;
  logic [2*PID_W-1:0]  in_pid, out_pid;
  logic [2*IDX_W-1:0]  in_idx, out_idx;
  logic [3:0]          in_dtype, out_dtype;
  logic [5:0]          in_op, out_op;
  logic [2*DATA_W-1:0] in_data, out_data;
  logic                s1_valid, s1_ready, s1_last, s1_err;
  logic [CID_W-1:0]    s1_cid; logic [PID_W-1:0] s1_pid; logic [IDX_W-1:0] s1_idx; logic [1:0] s1_dt; logic [2:0] s1_op; logic [DATA_W-1:0] s1_data;
  logic                o1_ready;
  logic                cpl_hs;
  logic [8:0]          mA, mB;

  assign in_valid = {s1_valid, p0_in_valid};
  assign p0_in_ready = in_ready[0];
  assign s1_ready = in_ready[1];
  assign in_cid  = {s1_cid, p0_in_cid};   assign in_pid = {s1_pid, p0_in_pid};  assign in_idx = {s1_idx, p0_in_idx};
  assign in_dtype = {s1_dt, p0_in_dtype}; assign in_op = {s1_op, p0_in_op};    assign in_data = {s1_data, p0_in_data};
  assign in_last = {s1_last, p0_in_last}; assign in_err = {s1_err, p0_in_err};
  assign out_ready = {o1_ready, p0_out_ready};
  assign p0_out_valid = out_valid[0]; assign p0_out_cid = out_cid[0 +: CID_W]; assign p0_out_pid = out_pid[0 +: PID_W];
  assign p0_out_idx = out_idx[0 +: IDX_W]; assign p0_out_data = out_data[0 +: DATA_W]; assign p0_out_last = out_last[0]; assign p0_out_err = out_err[0];

  sf_collective_core #(.NP(2), .MAX_LEN(MAX_LEN), .IN_DEPTH(IN_DEPTH), .OUT_DEPTH(OUT_DEPTH)) u_core (
    .clk(clk), .rst_n(rst_n), .ctl_soft_reset(1'b0), .ctl_abort(ctl_abort), .cfg_timeout(cfg_timeout), .part_fail({fail_out, 1'b0}),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_data(cmd_data),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_cid(cpl_cid), .cpl_ok(cpl_ok), .cpl_err(cpl_err), .cpl_ctype(), .cpl_flags(cpl_flags),
    .cpl_maskA(mA), .cpl_maskB(mB), .cpl_len(), .cpl_cycles(),
    .in_valid(in_valid), .in_ready(in_ready), .in_cid(in_cid), .in_pid(in_pid), .in_idx(in_idx), .in_dtype(in_dtype), .in_op(in_op),
    .in_data(in_data), .in_last(in_last), .in_err(in_err),
    .out_valid(out_valid), .out_ready(out_ready), .out_cid(out_cid), .out_pid(out_pid), .out_idx(out_idx), .out_dtype(out_dtype),
    .out_op(out_op), .out_data(out_data), .out_last(out_last), .out_err(out_err),
    .up_valid(), .up_ready(1'b1), .up_cid(), .up_pid(), .up_idx(), .up_dtype(), .up_op(), .up_data(), .up_last(), .up_err(),
    .dn_valid(1'b0), .dn_ready(), .dn_cid('0), .dn_pid('0), .dn_idx('0), .dn_dtype('0), .dn_op('0), .dn_data('0), .dn_last(1'b0), .dn_err(1'b0),
    .perf_clear(1'b0), .perf_sel(6'd0), .perf_data(), .idle(idle), .caps()
  );
  assign cpl_maskA = mA; assign cpl_maskB = mB;
  assign cpl_hs = cpl_valid && cpl_ready;

  sf_collective_net_adapter #(.PID(1), .WIN(WIN), .CREDITS(CREDITS)) u_net (
    .clk(clk), .rst_n(rst_n), .sclr(1'b0), .cfg_timeout(link_timeout), .ctl_clear(ctl_clear), .link_down(link_down),
    .rx_valid(rx_valid), .rx_ready(rx_ready), .rx_xfer(rx_xfer), .rx_seq(rx_seq), .rx_dtype(rx_dtype), .rx_op(rx_op), .rx_data(rx_data),
    .rx_last(rx_last), .rx_err(rx_err),
    .s_valid(s1_valid), .s_ready(s1_ready), .s_cid(s1_cid), .s_pid(s1_pid), .s_idx(s1_idx), .s_dtype(s1_dt), .s_op(s1_op), .s_data(s1_data),
    .s_last(s1_last), .s_err(s1_err),
    .o_valid(out_valid[1]), .o_ready(o1_ready), .o_cid(out_cid[CID_W +: CID_W]), .o_idx(out_idx[IDX_W +: IDX_W]), .o_dtype(out_dtype[2 +: 2]),
    .o_op(out_op[3 +: 3]), .o_data(out_data[DATA_W +: DATA_W]), .o_last(out_last[1]), .o_err(out_err[1]),
    .tx_valid(tx_valid), .tx_ready(tx_ready), .tx_xfer(tx_xfer), .tx_seq(tx_seq), .tx_dtype(), .tx_op(), .tx_data(tx_data), .tx_last(tx_last), .tx_err(tx_err),
    .tx_credit(tx_credit),
    .cpl_hs(cpl_hs), .cpl_cid(cpl_cid), .cpl_ok(cpl_ok), .cpl_err(cpl_err), .cpl_blame(mA[1] | mB[1]),
    .ack_valid(ack_valid), .ack_ready(ack_ready), .ack_cid(ack_cid), .ack_ok(ack_ok), .ack_err(ack_err), .ack_blamed(ack_blamed),
    .fail_out(fail_out), .st_timeout(st_timeout), .st_down(st_down), .ev_rx(ev_rx), .ev_tx(ev_tx), .ev_dup(ev_dup), .ev_stale(ev_stale),
    .ev_reorder(ev_reorder), .ev_cred_stall(ev_cred_stall), .ev_ack_lost(ev_ack_lost)
  );
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ns = |{out_pid[PID_W +: PID_W], out_dtype[1:0], out_op[2:0]};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
