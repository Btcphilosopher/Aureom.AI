// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_tree_sim -- multi-node simulation top (fixed tree topology)
//
// A FAN-ary tree of height H built from sf_collective_core nodes.  Leaves are the participants (FAN**H of them).
//   level 0        FAN**(H-1) nodes, INTERIOR; port p of node i serves leaf i*FAN+p
//   level l        FAN**(H-1-l) nodes, INTERIOR; port p of node i is connected to node (l-1, i*FAN+p):
//                    child.up_*  -> parent.in_*[p]        parent.out_*[p] -> child.dn_*
//   level H-1      one node, the ROOT (INTERIOR = 0)
// Node ids are linear: level 0 first, root last (NC-1).  Each node has its own command and completion port: the control plane
// (the bench) issues the per-node commands (docs/04_TOPOLOGY.md, "command expansion").  Leaf streams use the same field layout
// as sf_collective_core's participant streams; leaf l occupies bits [l*W +: W].
//
// Data movement (all-reduce): leaf -> level-0 node (reduce its FAN leaves) -> up -> ... -> root (reduce) -> result goes down:
// root.out[p] -> child.dn -> child.out[p] ... -> leaf.  A failure anywhere travels the same links as an error terminator beat.
// Not synthesizable as such (it is a bench harness); every node is the synthesizable core.
// =============================================================================
`default_nettype none
module sf_collective_tree_sim
  import sf_collective_pkg::*;
#(
  parameter int FAN          = 2,
  parameter int H            = 2,
  parameter int MAX_LEN      = 300,
  parameter int IN_DEPTH     = 4,
  parameter int OUT_DEPTH    = 4,
  parameter int CMD_DEPTH    = 4,
  parameter int CPL_DEPTH    = 4,
  parameter int TERM_DEPTH   = 2,
  parameter bit FP32_EN      = 1'b0,
  localparam int LEAVES      = (H == 1) ? FAN : (H == 2) ? FAN*FAN : (H == 3) ? FAN*FAN*FAN : FAN*FAN*FAN*FAN,
  localparam int NC          = (H == 1) ? 1 : (H == 2) ? FAN + 1 : (H == 3) ? FAN*FAN + FAN + 1 : FAN*FAN*FAN + FAN*FAN + FAN + 1
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  input  wire logic                   ctl_soft_reset,
  input  wire logic                   ctl_abort,
  input  wire logic [31:0]            cfg_timeout,
  input  wire logic [LEAVES-1:0]      part_fail,
  // ---- per-node command / completion
  input  wire logic [NC-1:0]          cmd_valid,
  output logic [NC-1:0]               cmd_ready,
  input  wire logic [NC*CMD_W-1:0]    cmd_data,
  output logic [NC-1:0]               cpl_valid,
  input  wire logic [NC-1:0]          cpl_ready,
  output logic [NC*CID_W-1:0]         cpl_cid,
  output logic [NC-1:0]               cpl_ok,
  output logic [NC*4-1:0]             cpl_err,
  output logic [NC*6-1:0]             cpl_flags,
  output logic [NC*9-1:0]             cpl_maskA,
  output logic [NC*9-1:0]             cpl_maskB,
  // ---- leaf streams
  input  wire logic [LEAVES-1:0]        in_valid,
  output logic [LEAVES-1:0]             in_ready,
  input  wire logic [LEAVES*CID_W-1:0]  in_cid,
  input  wire logic [LEAVES*PID_W-1:0]  in_pid,
  input  wire logic [LEAVES*IDX_W-1:0]  in_idx,
  input  wire logic [LEAVES*2-1:0]      in_dtype,
  input  wire logic [LEAVES*3-1:0]      in_op,
  input  wire logic [LEAVES*DATA_W-1:0] in_data,
  input  wire logic [LEAVES-1:0]        in_last,
  input  wire logic [LEAVES-1:0]        in_err,
  output logic [LEAVES-1:0]             out_valid,
  input  wire logic [LEAVES-1:0]        out_ready,
  output logic [LEAVES*CID_W-1:0]       out_cid,
  output logic [LEAVES*PID_W-1:0]       out_pid,
  output logic [LEAVES*IDX_W-1:0]       out_idx,
  output logic [LEAVES*2-1:0]           out_dtype,
  output logic [LEAVES*3-1:0]           out_op,
  output logic [LEAVES*DATA_W-1:0]      out_data,
  output logic [LEAVES-1:0]             out_last,
  output logic [LEAVES-1:0]             out_err,
  output logic [NC-1:0]                 node_idle,
  output logic [NC*64-1:0]              perf_all,        // PC_ELEMS of every node (diagnostics), 64 bits each
  input  wire logic [5:0]               perf_sel
);
  // ---- node geometry
  function automatic int cnt_at(input int l);          // nodes at level l
    int n; n = 1;
    for (int k = 0; k < H - 1 - l; k++) n = n * FAN;
    cnt_at = n;
  endfunction
  function automatic int off_at(input int l);          // id of the first node of level l
    int o; o = 0;
    for (int k = 0; k < l; k++) o = o + cnt_at(k);
    off_at = o;
  endfunction

  // ---- link bundles, indexed by node id
  logic [NC-1:0]            up_valid, up_ready, up_last, up_err, dn_valid, dn_ready, dn_last, dn_err;
  logic [CID_W-1:0]         up_cid [NC];
  logic [PID_W-1:0]         up_pid [NC];
  logic [IDX_W-1:0]         up_idx [NC];
  logic [1:0]               up_dtype [NC];
  logic [2:0]               up_op [NC];
  logic [DATA_W-1:0]        up_data [NC];
  logic [CID_W-1:0]         dn_cid [NC];
  logic [PID_W-1:0]         dn_pid [NC];
  logic [IDX_W-1:0]         dn_idx [NC];
  logic [1:0]               dn_dtype [NC];
  logic [2:0]               dn_op [NC];
  logic [DATA_W-1:0]        dn_data [NC];
  // per-node participant-port vectors
  logic [FAN-1:0]           n_in_valid [NC], n_in_ready [NC], n_in_last [NC], n_in_err [NC];
  logic [FAN*CID_W-1:0]     n_in_cid [NC];
  logic [FAN*PID_W-1:0]     n_in_pid [NC];
  logic [FAN*IDX_W-1:0]     n_in_idx [NC];
  logic [FAN*2-1:0]         n_in_dtype [NC];
  logic [FAN*3-1:0]         n_in_op [NC];
  logic [FAN*DATA_W-1:0]    n_in_data [NC];
  logic [FAN-1:0]           n_out_valid [NC], n_out_ready [NC], n_out_last [NC], n_out_err [NC];
  logic [FAN*CID_W-1:0]     n_out_cid [NC];
  logic [FAN*PID_W-1:0]     n_out_pid [NC];
  logic [FAN*IDX_W-1:0]     n_out_idx [NC];
  logic [FAN*2-1:0]         n_out_dtype [NC];
  logic [FAN*3-1:0]         n_out_op [NC];
  logic [FAN*DATA_W-1:0]    n_out_data [NC];
  logic [FAN-1:0]           n_pf [NC];
  logic [63:0]              n_perf [NC];

  generate
    for (genvar l = 0; l < H; l++) begin : g_lvl
      for (genvar i = 0; i < cnt_at(l); i++) begin : g_node
        localparam int ID = off_at(l) + i;
        localparam bit ROOT = (l == H - 1);

        // ---- connect this node's participant ports: leaves (level 0) or children's up/dn links
        for (genvar p = 0; p < FAN; p++) begin : g_port
          if (l == 0) begin : g_leaf
            localparam int LF = i * FAN + p;
            assign n_in_valid[ID][p]                        = in_valid[LF];
            assign in_ready[LF]                             = n_in_ready[ID][p];
            assign n_in_cid[ID][p*CID_W +: CID_W]           = in_cid[LF*CID_W +: CID_W];
            assign n_in_pid[ID][p*PID_W +: PID_W]           = in_pid[LF*PID_W +: PID_W];
            assign n_in_idx[ID][p*IDX_W +: IDX_W]           = in_idx[LF*IDX_W +: IDX_W];
            assign n_in_dtype[ID][p*2 +: 2]                 = in_dtype[LF*2 +: 2];
            assign n_in_op[ID][p*3 +: 3]                    = in_op[LF*3 +: 3];
            assign n_in_data[ID][p*DATA_W +: DATA_W]        = in_data[LF*DATA_W +: DATA_W];
            assign n_in_last[ID][p]                         = in_last[LF];
            assign n_in_err[ID][p]                          = in_err[LF];
            assign out_valid[LF]                            = n_out_valid[ID][p];
            assign n_out_ready[ID][p]                       = out_ready[LF];
            assign out_cid[LF*CID_W +: CID_W]               = n_out_cid[ID][p*CID_W +: CID_W];
            assign out_pid[LF*PID_W +: PID_W]               = n_out_pid[ID][p*PID_W +: PID_W];
            assign out_idx[LF*IDX_W +: IDX_W]               = n_out_idx[ID][p*IDX_W +: IDX_W];
            assign out_dtype[LF*2 +: 2]                     = n_out_dtype[ID][p*2 +: 2];
            assign out_op[LF*3 +: 3]                        = n_out_op[ID][p*3 +: 3];
            assign out_data[LF*DATA_W +: DATA_W]            = n_out_data[ID][p*DATA_W +: DATA_W];
            assign out_last[LF]                             = n_out_last[ID][p];
            assign out_err[LF]                              = n_out_err[ID][p];
            assign n_pf[ID][p]                              = part_fail[LF];
          end else begin : g_child
            localparam int CH = off_at(l - 1) + i * FAN + p;     // child node id
            assign n_in_valid[ID][p]                        = up_valid[CH];
            assign up_ready[CH]                             = n_in_ready[ID][p];
            assign n_in_cid[ID][p*CID_W +: CID_W]           = up_cid[CH];
            assign n_in_pid[ID][p*PID_W +: PID_W]           = up_pid[CH];
            assign n_in_idx[ID][p*IDX_W +: IDX_W]           = up_idx[CH];
            assign n_in_dtype[ID][p*2 +: 2]                 = up_dtype[CH];
            assign n_in_op[ID][p*3 +: 3]                    = up_op[CH];
            assign n_in_data[ID][p*DATA_W +: DATA_W]        = up_data[CH];
            assign n_in_last[ID][p]                         = up_last[CH];
            assign n_in_err[ID][p]                          = up_err[CH];
            assign dn_valid[CH]                             = n_out_valid[ID][p];
            assign n_out_ready[ID][p]                       = dn_ready[CH];
            assign dn_cid[CH]                               = n_out_cid[ID][p*CID_W +: CID_W];
            assign dn_pid[CH]                               = n_out_pid[ID][p*PID_W +: PID_W];
            assign dn_idx[CH]                               = n_out_idx[ID][p*IDX_W +: IDX_W];
            assign dn_dtype[CH]                             = n_out_dtype[ID][p*2 +: 2];
            assign dn_op[CH]                                = n_out_op[ID][p*3 +: 3];
            assign dn_data[CH]                              = n_out_data[ID][p*DATA_W +: DATA_W];
            assign dn_last[CH]                              = n_out_last[ID][p];
            assign dn_err[CH]                               = n_out_err[ID][p];
            assign n_pf[ID][p]                              = 1'b0;
          end
        end

        // ---- the node
        logic [63:0] pd;
        sf_collective_core #(
          .NP(FAN), .MAX_LEN(MAX_LEN), .IN_DEPTH(IN_DEPTH), .OUT_DEPTH(OUT_DEPTH), .CMD_DEPTH(CMD_DEPTH), .CPL_DEPTH(CPL_DEPTH),
          .TERM_DEPTH(TERM_DEPTH), .INTERIOR(!ROOT), .UP_PID(i % FAN), .FP32_EN(FP32_EN)
        ) u_node (
          .clk(clk), .rst_n(rst_n), .ctl_soft_reset(ctl_soft_reset), .ctl_abort(ctl_abort), .cfg_timeout(cfg_timeout),
          .part_fail(n_pf[ID]),
          .cmd_valid(cmd_valid[ID]), .cmd_ready(cmd_ready[ID]), .cmd_data(cmd_data[ID*CMD_W +: CMD_W]),
          .cpl_valid(cpl_valid[ID]), .cpl_ready(cpl_ready[ID]), .cpl_cid(cpl_cid[ID*CID_W +: CID_W]), .cpl_ok(cpl_ok[ID]),
          .cpl_err(cpl_err[ID*4 +: 4]), .cpl_ctype(), .cpl_flags(cpl_flags[ID*6 +: 6]),
          .cpl_maskA(cpl_maskA[ID*9 +: 9]), .cpl_maskB(cpl_maskB[ID*9 +: 9]), .cpl_len(), .cpl_cycles(),
          .in_valid(n_in_valid[ID]), .in_ready(n_in_ready[ID]), .in_cid(n_in_cid[ID]), .in_pid(n_in_pid[ID]), .in_idx(n_in_idx[ID]),
          .in_dtype(n_in_dtype[ID]), .in_op(n_in_op[ID]), .in_data(n_in_data[ID]), .in_last(n_in_last[ID]), .in_err(n_in_err[ID]),
          .out_valid(n_out_valid[ID]), .out_ready(n_out_ready[ID]), .out_cid(n_out_cid[ID]), .out_pid(n_out_pid[ID]),
          .out_idx(n_out_idx[ID]), .out_dtype(n_out_dtype[ID]), .out_op(n_out_op[ID]), .out_data(n_out_data[ID]),
          .out_last(n_out_last[ID]), .out_err(n_out_err[ID]),
          .up_valid(up_valid[ID]), .up_ready(up_ready[ID]), .up_cid(up_cid[ID]), .up_pid(up_pid[ID]), .up_idx(up_idx[ID]),
          .up_dtype(up_dtype[ID]), .up_op(up_op[ID]), .up_data(up_data[ID]), .up_last(up_last[ID]), .up_err(up_err[ID]),
          .dn_valid(dn_valid[ID]), .dn_ready(dn_ready[ID]), .dn_cid(dn_cid[ID]), .dn_pid(dn_pid[ID]), .dn_idx(dn_idx[ID]),
          .dn_dtype(dn_dtype[ID]), .dn_op(dn_op[ID]), .dn_data(dn_data[ID]), .dn_last(dn_last[ID]), .dn_err(dn_err[ID]),
          .perf_clear(1'b0), .perf_sel(perf_sel), .perf_data(pd), .idle(node_idle[ID]), .caps()
        );
        assign n_perf[ID] = pd;
        assign perf_all[ID*64 +: 64] = pd;
        if (ROOT) begin : g_root_tie
          assign up_ready[ID] = 1'b1;                       // unused links of the root
          assign dn_valid[ID] = 1'b0; assign dn_cid[ID] = '0; assign dn_pid[ID] = '0; assign dn_idx[ID] = '0;
          assign dn_dtype[ID] = '0; assign dn_op[ID] = '0; assign dn_data[ID] = '0; assign dn_last[ID] = 1'b0; assign dn_err[ID] = 1'b0;
        end
      end
    end
  endgenerate
endmodule
`default_nettype wire
