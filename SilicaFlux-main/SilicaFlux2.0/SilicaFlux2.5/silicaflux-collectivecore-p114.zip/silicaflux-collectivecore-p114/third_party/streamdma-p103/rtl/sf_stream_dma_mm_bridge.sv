// =============================================================================
// StreamDMA :: sf_stream_dma_mm_bridge -- StreamDMA memory port (AXI4-style, INCR bursts, IDs, byte strobes)
//                                         ->  two master ports of SilicaFlux MemoryMatrix (Project 101, sf_memory_matrix)
//
//   Why: the repository's SRAM subsystem (MemoryMatrix) speaks neither AXI nor SFB2.  This block is the missing adapter
//   (docs/00_AUDIT.md section 3 listed it as a gap).  It is deliberately small and stateless w.r.t. data:
//
//     AR burst  -> (len+1) MatrixM read requests, one per beat, address += W, size = log2(W), id = {last, ARID}
//     AW burst  -> queued; each W beat -> one MatrixM write request, be = WSTRB, id = {last, AWID}
//     R beat    <- MatrixM read response  (MatrixM returns responses of one master in acceptance order -> R is in order)
//     B         <- emitted ONLY after the MatrixM write response of the LAST beat of the burst, i.e. after every beat of
//                  the burst has been performed by its bank ("acknowledged write", MatrixM contract).  Worst response of
//                  the beats wins (DECERR > SLVERR > OKAY).
//
//   Two MatrixM masters are used (read, write) so that reads are never queued behind writes inside one master's slot table;
//   ordering between a write and a LATER dependent read is the DMA's job (hazard interlock: it waits for B) and is
//   what MatrixM's contract M5 ("hand over by waiting for the write response") prescribes.
//
//   Fail closed.  A burst that is not exactly what the matrix serves -- memory type not in TYPE_MASK, size != full beat,
//   burst type != INCR, address bits above MM_AW, or a burst that would run past the top of the matrix address space --
//   is NOT forwarded as written: its beats are issued to the address {MM_AW{1}} (+size), which the matrix rejects with
//   SF_ST_RANGE (no array access, no side effect; elaboration refuses a matrix whose capacity equals 2**MM_AW), and
//   they come back as DECERR.  The DMA then completes the transaction with ERR_BUS_RD / ERR_BUS_WR.
//
//   Domain sideband.  ar_domain / aw_domain select the MatrixM `prot.secure` bit through SECURE_MASK, so MatrixM's own
//   region table (secure-only regions) is a SECOND, independent check of the trusted domain behind the MemoryGuard.
//
//   Status mapping:  SF_ST_OK -> OKAY(00) ; SF_ST_RANGE -> DECERR(11) ; every other status (PERM, ALIGN, BADOP, ECC_UE) -> SLVERR(10).
//
//   Limits (docs/10): one burst per direction is being expanded at a time (zero-bubble hand-over between bursts);
//   AW_DEPTH accepted write bursts may wait for their data; W data that arrives before its AW simply waits (w_ready = 0).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stream_dma_mm_bridge #(
  parameter int DATA_WIDTH = 128,
  parameter int ADDR_WIDTH = 40,               // DMA side (physical address from the MemoryGuard)
  parameter int MM_AW      = 20,               // MatrixM byte address width (sf_memory_matrix AW)
  parameter int RIDW       = 1,                // ARID / RID width of the DMA (1 when MAX_OUTSTANDING_READS == 1)
  parameter int WIDW       = 1,
  parameter int MM_IDW     = 8,                // MatrixM request id width, must hold {last, id}
  parameter int AW_DEPTH   = 2,                // accepted AW bursts waiting for W data
  parameter int DOM_W      = 4,
  parameter logic [15:0] TYPE_MASK   = 16'h0012,   // memory types the matrix serves: bit 1 SRAM, bit 4 COMPUTE scratchpad
  parameter logic [15:0] SECURE_MASK = 16'h0000,   // domains whose accesses carry prot.secure = 1
  localparam int W   = DATA_WIDTH / 8,
  localparam int LW  = $clog2(W),
  localparam int SZW = (LW > 0) ? $clog2(LW + 1) : 1,
  localparam int DOM_X = (DOM_W < 16) ? DOM_W : 16
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // ---------------------------------------------------------------- StreamDMA memory port (slave side of this bridge)
  input  wire logic                    ar_valid,
  output logic                         ar_ready,
  input  wire logic [RIDW-1:0]         ar_id,
  input  wire logic [ADDR_WIDTH-1:0]   ar_addr,
  input  wire logic [7:0]              ar_len,
  input  wire logic [2:0]              ar_size,
  input  wire logic [1:0]              ar_burst,
  input  wire logic [3:0]              ar_mtype,
  input  wire logic [DOM_W-1:0]        ar_domain,
  output logic                         r_valid,
  input  wire logic                    r_ready,
  output logic [RIDW-1:0]              r_id,
  output logic [DATA_WIDTH-1:0]        r_data,
  output logic [1:0]                   r_resp,
  output logic                         r_last,
  input  wire logic                    aw_valid,
  output logic                         aw_ready,
  input  wire logic [WIDW-1:0]         aw_id,
  input  wire logic [ADDR_WIDTH-1:0]   aw_addr,
  input  wire logic [7:0]              aw_len,
  input  wire logic [2:0]              aw_size,
  input  wire logic [1:0]              aw_burst,
  input  wire logic [3:0]              aw_mtype,
  input  wire logic [DOM_W-1:0]        aw_domain,
  input  wire logic                    w_valid,
  output logic                         w_ready,
  input  wire logic [DATA_WIDTH-1:0]   w_data,
  input  wire logic [W-1:0]            w_strb,
  input  wire logic                    w_last,
  output logic                         b_valid,
  input  wire logic                    b_ready,
  output logic [WIDW-1:0]              b_id,
  output logic [1:0]                   b_resp,
  // ---------------------------------------------------------------- MatrixM master "read"
  output logic                         rd_req_valid,
  input  wire logic                    rd_req_ready,
  output logic [MM_AW-1:0]             rd_req_addr,
  output logic [SZW-1:0]               rd_req_size,
  output logic [MM_IDW-1:0]            rd_req_id,
  output logic [1:0]                   rd_req_prot,
  input  wire logic                    rd_rsp_valid,
  output logic                         rd_rsp_ready,
  input  wire logic [DATA_WIDTH-1:0]   rd_rsp_rdata,
  input  wire logic [MM_IDW-1:0]       rd_rsp_id,
  input  wire logic [2:0]              rd_rsp_status,
  // ---------------------------------------------------------------- MatrixM master "write"
  output logic                         wr_req_valid,
  input  wire logic                    wr_req_ready,
  output logic [MM_AW-1:0]             wr_req_addr,
  output logic [SZW-1:0]               wr_req_size,
  output logic [DATA_WIDTH-1:0]        wr_req_wdata,
  output logic [W-1:0]                 wr_req_be,
  output logic [MM_IDW-1:0]            wr_req_id,
  output logic [1:0]                   wr_req_prot,
  input  wire logic                    wr_rsp_valid,
  output logic                         wr_rsp_ready,
  input  wire logic [MM_IDW-1:0]       wr_rsp_id,
  input  wire logic [2:0]              wr_rsp_status,
  // ---------------------------------------------------------------- diagnostics
  output logic                         proto_err          // sticky: WLAST disagrees with the AW length
);
  // ------------------------------------------------------------------ static configuration checks
  generate
    if (DATA_WIDTH < 32 || DATA_WIDTH > 512 || (DATA_WIDTH & (DATA_WIDTH - 1)) != 0) begin : g_chk_dw
      DATA_WIDTH_must_be_a_power_of_two_in_32_512 u_err ();
    end
    if (ADDR_WIDTH <= MM_AW) begin : g_chk_aw
      ADDR_WIDTH_must_exceed_MM_AW_so_that_out_of_aperture_addresses_can_be_detected u_err ();
    end
    if (MM_AW < 8 || MM_AW > 32) begin : g_chk_maw
      MM_AW_must_be_8_32 u_err ();
    end
    if (MM_IDW < ((RIDW > WIDW) ? RIDW : WIDW) + 1) begin : g_chk_id
      MM_IDW_must_hold_the_burst_id_and_a_last_flag u_err ();
    end
    if (AW_DEPTH < 1) begin : g_chk_awd
      AW_DEPTH_must_be_ge_1 u_err ();
    end
  endgenerate

  // status -> AXI response
  function automatic logic [1:0] st2resp(input logic [2:0] st);
    if (st == 3'd0)      st2resp = 2'b00;   // OKAY
    else if (st == 3'd1) st2resp = 2'b11;   // DECERR  (SF_ST_RANGE: outside the aperture)
    else                 st2resp = 2'b10;   // SLVERR  (permission, alignment, uncorrectable ECC, bad op)
  endfunction

  // contract check shared by AR and AW: is this burst exactly what the matrix serves?
  function automatic logic burst_bad(input logic [ADDR_WIDTH-1:0] a, input logic [7:0] len, input logic [2:0] sz,
                                     input logic [1:0] bt, input logic [3:0] mt);
    logic [MM_AW+1:0] bytes, endp;
    logic [8:0]       beats;
    logic             hi_nz, ovf;
    beats = {1'b0, len} + 9'd1;
    bytes = (MM_AW + 2)'(beats) << LW;
    endp  = {2'b00, a[MM_AW-1:0]} + bytes;
    ovf   = endp[MM_AW + 1] || (endp[MM_AW] && (endp[MM_AW-1:0] != '0));     // end > 2**MM_AW
    hi_nz = (a[ADDR_WIDTH-1:MM_AW] != '0);
    burst_bad = hi_nz || ovf || (bt != 2'b01) || (sz != 3'(LW)) || !TYPE_MASK[mt];
  endfunction

  localparam logic [MM_AW-1:0] OOR_ADDR = '1;     // rejected by the matrix: capacity < 2**MM_AW (checked in the integration top)

  // =================================================================== read side
  logic                rd_act, rd_bad, rd_sec;
  logic [MM_AW-1:0]    rd_addr;
  logic [7:0]          rd_cnt;
  logic [RIDW-1:0]     rd_id;
  wire                 rd_lastb = (rd_cnt == 8'd0);
  wire                 rd_acc   = rd_act && rd_req_ready;
  wire                 ar_acc   = ar_valid && ar_ready;
  assign ar_ready     = !rd_act || (rd_acc && rd_lastb);                 // zero-bubble hand-over between bursts
  assign rd_req_valid = rd_act;
  assign rd_req_addr  = rd_bad ? OOR_ADDR : rd_addr;
  assign rd_req_size  = SZW'(LW);
  assign rd_req_id    = MM_IDW'({rd_lastb, rd_id});
  assign rd_req_prot  = {rd_sec, 1'b0};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_act <= 1'b0; rd_bad <= 1'b0; rd_sec <= 1'b0; rd_addr <= '0; rd_cnt <= '0; rd_id <= '0;
    end else begin
      if (rd_acc) begin
        rd_addr <= rd_addr + MM_AW'(W);
        rd_cnt  <= rd_cnt - 8'd1;
        if (rd_lastb) rd_act <= 1'b0;
      end
      if (ar_acc) begin                                                  // wins over the retire above
        rd_act  <= 1'b1;
        rd_addr <= ar_addr[MM_AW-1:0];
        rd_cnt  <= ar_len;
        rd_id   <= ar_id;
        rd_bad  <= burst_bad(ar_addr, ar_len, ar_size, ar_burst, ar_mtype);
        rd_sec  <= SECURE_MASK[DOM_X'(ar_domain)];
      end
    end
  end

  assign r_valid      = rd_rsp_valid;
  assign rd_rsp_ready = r_ready;
  assign r_id         = rd_rsp_id[RIDW-1:0];
  assign r_last       = rd_rsp_id[RIDW];
  assign r_data       = rd_rsp_rdata;
  assign r_resp       = st2resp(rd_rsp_status);

  // =================================================================== write side
  localparam int AWQW = WIDW + MM_AW + 8 + 1 + 1;
  logic              awq_v, awq_pop;
  logic [AWQW-1:0]   awq_d;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(AW_DEPTH+1)-1:0] awq_level;
  /* verilator lint_on UNUSEDSIGNAL */
  sfd_fifo #(.WIDTH(AWQW), .DEPTH(AW_DEPTH)) u_awq (
    .clk(clk), .rst_n(rst_n), .flush(1'b0),
    .in_valid(aw_valid), .in_ready(aw_ready),
    .in_data({aw_id, aw_addr[MM_AW-1:0], aw_len, burst_bad(aw_addr, aw_len, aw_size, aw_burst, aw_mtype),
              SECURE_MASK[DOM_X'(aw_domain)]}),
    .out_valid(awq_v), .out_ready(awq_pop), .out_data(awq_d), .level(awq_level));

  wire [WIDW-1:0]   q_id   = awq_d[AWQW-1 -: WIDW];
  wire [MM_AW-1:0]  q_addr = awq_d[AWQW-1-WIDW -: MM_AW];
  wire [7:0]        q_len  = awq_d[AWQW-1-WIDW-MM_AW -: 8];
  wire              q_bad  = awq_d[1];
  wire              q_sec  = awq_d[0];

  logic              wb_act, wb_bad, wb_sec;
  logic [MM_AW-1:0]  wb_addr;
  logic [7:0]        wb_cnt;
  logic [WIDW-1:0]   wb_id;
  wire               wb_lastb = (wb_cnt == 8'd0);
  wire               wb_acc   = w_valid && w_ready;
  assign w_ready       = wb_act && wr_req_ready;
  assign wr_req_valid  = w_valid && wb_act;
  assign wr_req_addr   = wb_bad ? OOR_ADDR : wb_addr;
  assign wr_req_size   = SZW'(LW);
  assign wr_req_wdata  = w_data;
  assign wr_req_be     = w_strb;
  assign wr_req_id     = MM_IDW'({wb_lastb, wb_id});
  assign wr_req_prot   = {wb_sec, 1'b0};
  assign awq_pop       = awq_v && (!wb_act || (wb_acc && wb_lastb));     // next burst loads in the cycle the last beat leaves

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wb_act <= 1'b0; wb_bad <= 1'b0; wb_sec <= 1'b0; wb_addr <= '0; wb_cnt <= '0; wb_id <= '0; proto_err <= 1'b0;
    end else begin
      if (wb_acc) begin
        wb_addr <= wb_addr + MM_AW'(W);
        wb_cnt  <= wb_cnt - 8'd1;
        if (wb_lastb) wb_act <= 1'b0;
        if (w_last != wb_lastb) proto_err <= 1'b1;
      end
      if (awq_pop) begin
        wb_act  <= 1'b1;
        wb_addr <= q_addr; wb_cnt <= q_len; wb_id <= q_id; wb_bad <= q_bad; wb_sec <= q_sec;
      end
    end
  end

  // write responses (in acceptance order) -> one B per burst, after the last beat's response
  logic              b_v_q;
  logic [WIDW-1:0]   b_id_q;
  logic [1:0]        b_resp_q, b_acc;
  wire  [1:0]        rsp_r  = st2resp(wr_rsp_status);
  wire  [1:0]        worst  = (rsp_r > b_acc) ? rsp_r : b_acc;
  wire               rsp_hs = wr_rsp_valid && wr_rsp_ready;
  assign wr_rsp_ready = !b_v_q || b_ready;
  assign b_valid      = b_v_q;
  assign b_id         = b_id_q;
  assign b_resp       = b_resp_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      b_v_q <= 1'b0; b_id_q <= '0; b_resp_q <= 2'b00; b_acc <= 2'b00;
    end else begin
      if (b_v_q && b_ready) b_v_q <= 1'b0;
      if (rsp_hs) begin
        if (wr_rsp_id[WIDW]) begin                                       // last beat of the burst
          b_v_q <= 1'b1; b_id_q <= wr_rsp_id[WIDW-1:0]; b_resp_q <= worst; b_acc <= 2'b00;
        end else begin
          b_acc <= worst;
        end
      end
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = &{1'b0, awq_level, wr_rsp_id[MM_IDW-1:WIDW+1], rd_rsp_id[MM_IDW-1:RIDW+1], 1'b0};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
