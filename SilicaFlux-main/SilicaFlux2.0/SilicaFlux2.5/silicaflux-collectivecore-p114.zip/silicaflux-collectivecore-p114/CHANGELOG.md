# Changelog / development history (Project 114)

Defects and design corrections found during development, in the order found.  *Real* = a defect in the RTL; *Bench* = a defect in the testbench / reference; *Design* = a weakness found by reviewing behaviour while writing a test.

| # | kind | what | how it was found | fix |
|---|---|---|---|---|
| 1 | **Real** | When a collective failed while a result beat was on offer to a stalled consumer, the output port **replaced / flushed the offered beat** with the error terminator (stream-stability violation). | output-stability monitor in `output_timeout`, `reset_hard`, `random_faults` | per-port **output register** that holds an offered beat until accepted; terminator queued behind it (`sf_collective_outport`); later proved by BMC (`fv_outport`) |
| 2 | Design | "One terminator per port" lost the terminator of a second failure while a slow consumer had not yet taken the first | `random_faults` | per-port terminator **queue** (`TERM_DEPTH`) + explicit lost-terminator counter; the bench now requires every missing terminator to be accounted for by `PC_TERM_LOST` |
| 3 | Design | The timeout mask blamed every sender that had not finished, including a healthy sender back-pressured by a stalled peer | designing the `missing` test's expected mask | blame only senders that owe elements **and** have an empty input buffer (the ones the engine is waiting for) |
| 4 | **Real** (found before the first run of its bench) | Network adapter watchdog counted core back-pressure as link silence | review while writing `late_remote` / `credits` | count only while the next element is missing |
| 5 | **Real** | Network adapter: an arriving error beat could discard a beat already on offer to the core | review of the stability rule | accept an error beat only when nothing is on offer |
| 6 | Bench | `MAX_LEN` of the build and of the reference differed (build script) | `cmd_reject` | build script passes `MAX_LEN` always |
| 7 | Bench | a rejected "repeated id" command was streamed with the id of a legitimate collective (an id is an identity) | `cmd_reject` | no data for id-rejected commands |
| 8 | Bench | FP32 promotion happened before the operator was final (FP32 MAX) | FP32 tree bench | promotion at collective creation |
| 9 | Bench | memory tests assumed a burst can straddle two mappings (mappings are 4 KiB-granular; bursts never cross 4 KiB); arithmetic slip in a "run off the mapping" case; translation was identity everywhere | `burst_split`, `protection`, mutation survivor `mr-pa` | corrected expectations; added non-identity translation test |
| 10 | Design | `INT_OVF` is not a global property in a tree (interior nodes see wrapped partial sums) | designing the tree reference | defined as **node-local**; reference computes per-node flags; documented (docs/03 §4) |
| 11 | Tooling | Yosys 0.33 cannot read `module m import pkg::*;`, `int'()` casts; Z3 cannot finish the sequential harnesses | formal bring-up | `scripts/flatten_pkg.py`; one cast rewritten; Yosys SAT engine for sequential jobs |
| 12 | Bench | formal output-port harness let the producer push more than `exp_len` elements (the core's counters forbid it) | counter-example from the proof | explicit producer contract in the harness |
| 13 | Bench | adapter harness fixed the collective context for the whole run (state clearing between collectives not modelled) | formal sensitivity check (`sa-clr-leak` survived) | `act_valid` toggles; shadow model resets at the boundary |
| 14 | Bench | mutation campaign survivors → five real test gaps: non-sender data, watchdog "progress" semantics, stale-after-rejected-id hang, store-completion ordering at the record instant, non-identity translation (the other four survivors — `fn-order`, `fn-passthrough`, `rd-done`, `op-load-run` — were shown equivalent, docs/08 §6) | mutation run 1 (68/77 killed) | new scenarios `nonsender`, `fail_backlog`, `watchdog_progress`, stale-after-reject, ordering monitor, `translate`; the final campaign result is in reports/mutation.md |

## Version

Project 114, revision 1 (first and only delivery).  Delivered as a ZIP; **nothing was committed to the repository.**
