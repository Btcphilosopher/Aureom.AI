// Reduction datapath: one element reduced by the FIXED TREE equals an independent left-to-right fold over the present participants
// (SUM mod 2^32, MIN / MAX with the data type's ordering, AND / OR / XOR), and the INT overflow flag equals the exact-sum test.  Pop discipline.
module fv_red
  import sf_collective_pkg::*;
#(parameter NP = 4, parameter OPC = 6, parameter DTC = 2, parameter WIT = 0)
(
  input wire clk, input wire [NP-1:0] h_valid, input wire [NP*32-1:0] h_data, input wire [2:0] op_raw, input wire dt_raw,
  input wire [NP-1:0] mask_raw, input wire r_ready
);
  reg rst_n = 1'b0; always @(posedge clk) rst_n <= 1'b1;
  wire [2:0] op = (OPC < 6) ? OPC : op_raw; wire [1:0] dtype = (DTC < 2) ? DTC : {1'b0, dt_raw}; wire [NP-1:0] mask = mask_raw;     // OPC / DTC fix the operator / type for the job (6 / 2 = free)
  wire [NP-1:0] h_ready; wire r_valid; wire [31:0] r_data; wire [5:0] flags;
  /* verilator lint_off PINMISSING */
  sf_collective_reduction #(.NP(NP), .ALLGATHER_EN(1'b0), .FP32_EN(1'b0)) dut (
    .clk(clk), .rst_n(rst_n), .run(1'b1), .sclr(1'b0), .op(op), .dtype(dtype), .rm(3'd0), .send_mask(mask), .gather(1'b0),
    .len(21'd1), .res_len(21'd1), .h_valid(h_valid), .h_ready(h_ready), .h_data(h_data),
    .r_valid(r_valid), .r_ready(r_ready), .r_data(r_data), .r_idx(), .r_last(), .red_done(), .flags(flags), .busy(), .ev_fire(), .ev_starve(), .ev_stall());
  always @* begin assume(op <= 5); assume(mask != 0); end
  // spec: fold from the highest participant down (a different association than the RTL's tree)
  integer i; reg [31:0] acc; reg have; reg signed [63:0] ssum; reg [63:0] usum; reg exp_ovf; reg [31:0] x;
  always @* begin
    have = 0; acc = 0; ssum = 0; usum = 0;
    for (i = NP - 1; i >= 0; i = i - 1) if (mask[i]) begin
      x = h_data[i*32 +: 32];
      ssum = ssum + {{32{x[31]}}, x}; usum = usum + {32'd0, x};
      if (!have) begin acc = x; have = 1; end
      else case (op)
        3'd0: acc = acc + x;
        3'd1: acc = (dtype == 2'd1) ? ((x < acc) ? x : acc) : (($signed(x) < $signed(acc)) ? x : acc);
        3'd2: acc = (dtype == 2'd1) ? ((x > acc) ? x : acc) : (($signed(x) > $signed(acc)) ? x : acc);
        3'd3: acc = acc & x;
        3'd4: acc = acc | x;
        default: acc = acc ^ x;
      endcase
    end
    exp_ovf = (op == 3'd0) && ((dtype == 2'd1) ? (usum > 64'hFFFF_FFFF) : (ssum > 64'sd2147483647 || ssum < -64'sd2147483648));
  end
  reg fired = 0; reg [31:0] e_acc; reg e_ovf;
  always @(posedge clk) if (rst_n) begin
    fired <= (h_ready != 0); e_acc <= acc; e_ovf <= exp_ovf;
    if (fired) begin assert(r_valid); assert(r_data == e_acc); assert(flags[5] == e_ovf); end
  end
  always @* if (rst_n) begin
    if (WIT == 1) assert(!fired);                                                   // witness: an element can be reduced
    assert(h_ready == 0 || h_ready == mask);                                       // all present heads are popped together, or none
    if (h_ready != 0) assert((h_valid | ~mask) == {NP{1'b1}});                    // ... and only when every present head holds an element (alignment)
  end
endmodule
