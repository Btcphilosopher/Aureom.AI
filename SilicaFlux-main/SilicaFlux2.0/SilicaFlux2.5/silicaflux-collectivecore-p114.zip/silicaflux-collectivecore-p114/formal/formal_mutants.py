#!/usr/bin/env python3
"""Formal sensitivity check: inject a deliberate RTL bug and require that the NAMED formal job FAILS (counterexample).  A proof that stays green on a broken design proves nothing.
Mutations are shared with scripts/mutate.py (same patterns).  Writes reports/formal_mutants.md."""
import os, re, shutil, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_formal as rf
ROOT = rf.ROOT; os.chdir(ROOT)
src = open("scripts/mutate.py").read().split("# ---- bench configurations")[0].replace('ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))\nos.chdir(ROOT)', '')
g = {"os": os, "re": re, "shutil": shutil, "subprocess": None, "sys": sys, "cf": None, "time": None}; exec(src, g)
MUT = {m[0]: m for m in g["M"]}
JOB = {j[0]: j for j in rf.JOBS}
PLAN = [  # mutant, formal job that must fail
 ("sa-dup-off", "adapter_d3"), ("sa-seq-off", "adapter_d3"), ("sa-early-drop", "adapter_d3"), ("sa-cid-ignored", "adapter_d3"), ("sa-pid-off", "adapter_d3"),
 ("sa-sender-off", "adapter_d3"), ("sa-last-off", "adapter_d3"), ("sa-dtop-off", "adapter_d3"), ("sa-clr-leak", "adapter_d3"),
 ("op-hold", "outport_d2"), ("op-last", "outport_d2"),
 ("sc-done", "sched_np2"), ("sc-flush", "sched_np2"),
 ("pk-sum", "red_np2_sum_i32"), ("pk-unsigned-cmp", "red_np2_min_u32"), ("pk-signed-cmp", "red_np2_max_i32"), ("pk-max-swap", "red_np2_max_u32"), ("pk-xor", "red_np2_xor"),
 ("rd-ovf-signed", "red_np2_sum_i32"), ("rd-ovf-unsigned", "red_np2_sum_u32"), ("rd-pop", "red_np2_sum_u32"), ("rd-align", "red_np2_and"),
 ("pk-reduce-root", "cmd_np4_all"), ("pk-len-limit", "cmd_np4_all"), ("pk-op-legal", "cmd_np4_all"), ("pk-fp-rm", "cmd_np4_all"), ("pk-cid-after", "cid"),
]
rows = []; ok = True
for mid, job in PLAN:
    _, f, a, b, cls, ben, desc = MUT[mid]
    d = os.path.join(ROOT, "build", "fmut", mid); shutil.rmtree(d, ignore_errors=True); shutil.copytree("rtl", d)
    p = os.path.join(d, os.path.basename(f)); s = open(p).read(); assert s.count(a) == 1, mid; open(p, "w").write(s.replace(a, b))
    r = rf.run(JOB[job], d)
    killed = r[1] == "FAIL"
    ok &= killed; rows.append((mid, job, desc, "KILLED (counterexample)" if killed else f"SURVIVED ({r[1]})"))
    print(f"{'KILLED' if killed else r[1]:9s} {mid:16s} by {job:18s} {desc}", flush=True)
with open("reports/formal_mutants.md", "w") as fh:
    fh.write("# Formal sensitivity: injected bugs vs formal jobs\n\nEach row injects one deliberate RTL bug and runs ONE named formal job on the mutated design; the job must produce a counterexample.\n\n| mutant | formal job | injected bug | result |\n|---|---|---|---|\n")
    for r in rows: fh.write(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |\n")
    fh.write(f"\n**{sum(1 for r in rows if r[3].startswith('KILLED'))} of {len(rows)} injected bugs make their formal job fail.**\n")
sys.exit(0 if ok else 1)
