#!/usr/bin/env python3
"""Formal runner (Yosys 0.33 + yosys-smtbmc + Z3; the pipeline SymbiYosys wraps).  Each job: flatten the package (scripts/flatten_pkg.py, Yosys 0.33 cannot read
`import pkg::*` module headers), read RTL + harness with -formal, chparam, prep, async2sync, write_smt2, then BMC to the stated depth.
   depth 1 on a purely combinational harness = EXHAUSTIVE (every input value).  Sequential jobs are BOUNDED (BMC) and say so.
usage: run_formal.py [--only SUBSTR] [--rtl-dir DIR]      writes reports/formal.md"""
import argparse, os, shutil, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTLF = ["stream_adapter", "command_queue", "reduction", "outport", "output", "scheduler", "perf"]
JOBS = [  # name, harness, top, params, depth, rtl modules, claim.   depth 1 = exhaustive (SMT), depth > 1 = bounded (SAT).  names ending "_wit*" are REACHABILITY WITNESSES: they must FAIL
 ("cid",             "fv_cid.sv",   "fv_cid",   "",                                           1, [], "collective-ID order: irreflexive, asymmetric, total, successor, windowed transitivity"),
 ("cmd_np4_all",     "fv_cmd.sv",   "fv_cmd",   "NP=4 MAXLEN=100 RS=1 AG=1 FP=1 INT=0",       1, [], "cmd_validate == acceptance rules, root node, all options (all 2^64 commands)"),
 ("cmd_np8_min",     "fv_cmd.sv",   "fv_cmd",   "NP=8 MAXLEN=7 RS=0 AG=0 FP=0 INT=0",         1, [], "cmd_validate == rules, 8 participants, integer-only build"),
 ("cmd_np3_int",     "fv_cmd.sv",   "fv_cmd",   "NP=3 MAXLEN=33 RS=1 AG=1 FP=1 INT=1",        1, [], "cmd_validate == rules, tree-interior node"),
 ("cmd_np2_int",     "fv_cmd.sv",   "fv_cmd",   "NP=2 MAXLEN=5 RS=0 AG=0 FP=1 INT=1",         1, [], "cmd_validate == rules, tree-interior node, two ports"),
 ("adapter_d3",      "fv_adapter.sv", "fv_adapter", "PID=1 DEPTH=3",                        14, ["stream_adapter"], "ingress adapter: exactly-once, in-order, header-checked elements; stall-future / drop-stale rules; shadow queue"),
 ("adapter_d1",      "fv_adapter.sv", "fv_adapter", "PID=0 DEPTH=1",                        14, ["stream_adapter"], "ingress adapter, 1-deep buffer"),
 ("adapter_wit1",    "fv_adapter.sv", "fv_adapter", "PID=1 DEPTH=3 WIT=1",                  14, ["stream_adapter"], "WITNESS: two elements can be stored (must FAIL)"),
 ("adapter_wit2",    "fv_adapter.sv", "fv_adapter", "PID=1 DEPTH=3 WIT=2",                  14, ["stream_adapter"], "WITNESS: a protocol error can occur (must FAIL)"),
 ("adapter_wit3",    "fv_adapter.sv", "fv_adapter", "PID=1 DEPTH=3 WIT=3",                  14, ["stream_adapter"], "WITNESS: elements can be popped (must FAIL)"),
 ("outport_d2",      "fv_outport.sv", "fv_outport", "DEPTH=2 TD=2",                         16, ["outport"], "output port: an offered beat is stable until accepted; well-formed data beats and terminators"),
 ("outport_d1",      "fv_outport.sv", "fv_outport", "DEPTH=1 TD=1",                         16, ["outport"], "output port, minimal buffers"),
 ("outport_wit1",    "fv_outport.sv", "fv_outport", "DEPTH=2 TD=2 WIT=1",                   16, ["outport"], "WITNESS: a terminator can be offered (must FAIL)"),
 ("outport_wit2",    "fv_outport.sv", "fv_outport", "DEPTH=2 TD=2 WIT=2",                   16, ["outport"], "WITNESS: a complete stream can be offered (must FAIL)"),
 ("outport_wit3",    "fv_outport.sv", "fv_outport", "DEPTH=2 TD=2 WIT=3",                   16, ["outport"], "WITNESS: a beat can be stalled (must FAIL)"),
 ("sched_np2",       "fv_sched.sv", "fv_sched",  "NP=2",                                      16, ["scheduler"], "scheduler: one record per command, success only after the done conditions, flush before a failure record, context stable"),
 ("sched_np3",       "fv_sched.sv", "fv_sched",  "NP=3",                                      14, ["scheduler"], "scheduler, 3 participants"),
 ("sched_wit1",      "fv_sched.sv", "fv_sched",  "NP=2 WIT=1",                                16, ["scheduler"], "WITNESS: a successful non-empty collective can complete (must FAIL)"),
 ("sched_wit2",      "fv_sched.sv", "fv_sched",  "NP=2 WIT=2",                                16, ["scheduler"], "WITNESS: a failed collective can reach its record (must FAIL)"),
 ("sched_wit3",      "fv_sched.sv", "fv_sched",  "NP=2 WIT=3",                                16, ["scheduler"], "WITNESS: a rejected command can reach its record (must FAIL)"),
 ("red_wit",         "fv_red.sv",   "fv_red",   "NP=2 OPC=0 DTC=0 WIT=1",                     4, ["reduction"], "WITNESS: an element can be reduced (must FAIL)"),
 ("red_np2_sum_i32", "fv_red.sv", "fv_red", "NP=2 OPC=0 DTC=0", 4, ["reduction"], "tree reduction == independent fold (SUM INT32, 2 participants); overflow flag == exact-sum test; all-or-none aligned pop"),
 ("red_np2_sum_u32", "fv_red.sv", "fv_red", "NP=2 OPC=0 DTC=1", 4, ["reduction"], "tree reduction == independent fold (SUM UINT32, 2 participants); overflow flag == exact-sum test; all-or-none aligned pop"),
 ("red_np2_min_i32", "fv_red.sv", "fv_red", "NP=2 OPC=1 DTC=0", 4, ["reduction"], "tree reduction == independent fold (MIN INT32, 2 participants); all-or-none aligned pop"),
 ("red_np2_min_u32", "fv_red.sv", "fv_red", "NP=2 OPC=1 DTC=1", 4, ["reduction"], "tree reduction == independent fold (MIN UINT32, 2 participants); all-or-none aligned pop"),
 ("red_np2_max_i32", "fv_red.sv", "fv_red", "NP=2 OPC=2 DTC=0", 4, ["reduction"], "tree reduction == independent fold (MAX INT32, 2 participants); all-or-none aligned pop"),
 ("red_np2_max_u32", "fv_red.sv", "fv_red", "NP=2 OPC=2 DTC=1", 4, ["reduction"], "tree reduction == independent fold (MAX UINT32, 2 participants); all-or-none aligned pop"),
 ("red_np2_and", "fv_red.sv", "fv_red", "NP=2 OPC=3 DTC=0", 4, ["reduction"], "tree reduction == independent fold (AND, 2 participants); all-or-none aligned pop"),
 ("red_np2_or", "fv_red.sv", "fv_red", "NP=2 OPC=4 DTC=0", 4, ["reduction"], "tree reduction == independent fold (OR, 2 participants); all-or-none aligned pop"),
 ("red_np2_xor", "fv_red.sv", "fv_red", "NP=2 OPC=5 DTC=0", 4, ["reduction"], "tree reduction == independent fold (XOR, 2 participants); all-or-none aligned pop"),
 ("red_np3_sum_i32", "fv_red.sv", "fv_red", "NP=3 OPC=0 DTC=0", 4, ["reduction"], "tree reduction == independent fold (SUM INT32, 3 participants); overflow flag == exact-sum test; all-or-none aligned pop"),
 ("red_np3_sum_u32", "fv_red.sv", "fv_red", "NP=3 OPC=0 DTC=1", 4, ["reduction"], "tree reduction == independent fold (SUM UINT32, 3 participants); overflow flag == exact-sum test; all-or-none aligned pop"),
 ("red_np3_min_i32", "fv_red.sv", "fv_red", "NP=3 OPC=1 DTC=0", 4, ["reduction"], "tree reduction == independent fold (MIN INT32, 3 participants); all-or-none aligned pop"),
 ("red_np3_min_u32", "fv_red.sv", "fv_red", "NP=3 OPC=1 DTC=1", 4, ["reduction"], "tree reduction == independent fold (MIN UINT32, 3 participants); all-or-none aligned pop"),
 ("red_np3_max_i32", "fv_red.sv", "fv_red", "NP=3 OPC=2 DTC=0", 4, ["reduction"], "tree reduction == independent fold (MAX INT32, 3 participants); all-or-none aligned pop"),
 ("red_np3_max_u32", "fv_red.sv", "fv_red", "NP=3 OPC=2 DTC=1", 4, ["reduction"], "tree reduction == independent fold (MAX UINT32, 3 participants); all-or-none aligned pop"),
 ("red_np3_and", "fv_red.sv", "fv_red", "NP=3 OPC=3 DTC=0", 4, ["reduction"], "tree reduction == independent fold (AND, 3 participants); all-or-none aligned pop"),
 ("red_np3_or", "fv_red.sv", "fv_red", "NP=3 OPC=4 DTC=0", 4, ["reduction"], "tree reduction == independent fold (OR, 3 participants); all-or-none aligned pop"),
 ("red_np3_xor", "fv_red.sv", "fv_red", "NP=3 OPC=5 DTC=0", 4, ["reduction"], "tree reduction == independent fold (XOR, 3 participants); all-or-none aligned pop"),
 ("red_np4_sum_i32", "fv_red.sv", "fv_red", "NP=4 OPC=0 DTC=0", 4, ["reduction"], "tree reduction == independent fold (SUM INT32, 4 participants); overflow flag == exact-sum test; all-or-none aligned pop"),
 ("red_np4_sum_u32", "fv_red.sv", "fv_red", "NP=4 OPC=0 DTC=1", 4, ["reduction"], "tree reduction == independent fold (SUM UINT32, 4 participants); overflow flag == exact-sum test; all-or-none aligned pop"),
 ("red_np4_min_i32", "fv_red.sv", "fv_red", "NP=4 OPC=1 DTC=0", 4, ["reduction"], "tree reduction == independent fold (MIN INT32, 4 participants); all-or-none aligned pop"),
 ("red_np4_min_u32", "fv_red.sv", "fv_red", "NP=4 OPC=1 DTC=1", 4, ["reduction"], "tree reduction == independent fold (MIN UINT32, 4 participants); all-or-none aligned pop"),
 ("red_np4_max_i32", "fv_red.sv", "fv_red", "NP=4 OPC=2 DTC=0", 4, ["reduction"], "tree reduction == independent fold (MAX INT32, 4 participants); all-or-none aligned pop"),
 ("red_np4_max_u32", "fv_red.sv", "fv_red", "NP=4 OPC=2 DTC=1", 4, ["reduction"], "tree reduction == independent fold (MAX UINT32, 4 participants); all-or-none aligned pop"),
 ("red_np4_and", "fv_red.sv", "fv_red", "NP=4 OPC=3 DTC=0", 4, ["reduction"], "tree reduction == independent fold (AND, 4 participants); all-or-none aligned pop"),
 ("red_np4_or", "fv_red.sv", "fv_red", "NP=4 OPC=4 DTC=0", 4, ["reduction"], "tree reduction == independent fold (OR, 4 participants); all-or-none aligned pop"),
 ("red_np4_xor", "fv_red.sv", "fv_red", "NP=4 OPC=5 DTC=0", 4, ["reduction"], "tree reduction == independent fold (XOR, 4 participants); all-or-none aligned pop"),
]
def build_files(job, rtl_dir, out):
    name, h, top, params, depth, mods, claim = job
    srcs = [os.path.join(rtl_dir, f"sf_collective_{m}.sv") for m in mods] + [os.path.join(ROOT, "formal", h)]
    env = dict(os.environ); env["SF_RTL_DIR"] = rtl_dir
    subprocess.check_call([sys.executable, os.path.join(ROOT, "scripts", "flatten_pkg.py"), out] + srcs, env=env)
    return [os.path.join(out, os.path.basename(s)) for s in srcs]
def run(job, rtl_dir, tmo=1700):
    name, h, top, params, depth, mods, claim = job
    out = os.path.join(ROOT, "build", "formal", name); shutil.rmtree(out, ignore_errors=True); os.makedirs(out)
    files = build_files(job, rtl_dir, out)
    fifo = os.path.join(ROOT, "third_party/p61-clouddpu/rtl/sfd_fifo.sv")
    ys = ["read_verilog -formal -sv " + fifo + " " + " ".join(files)]
    for kv in params.split():
        k, v = kv.split("="); ys.append(f"chparam -set {k} {v} {top}")
    ys += [f"prep -top {top}", "flatten", "memory_map", "async2sync", "dffunmap"]
    t0 = time.time()
    if depth > 1:        # sequential: Yosys' built-in SAT engine (bounded model check from the reset state; Z3/smtbmc cannot finish these harnesses)
        ys.append(f"sat -verify -seq {depth} -prove-asserts -set-assumes -timeout {tmo}")
        try: r = subprocess.run(["yosys", "-q", "-l", f"{out}/log.txt", "-p", "; ".join(ys)], cwd=ROOT, capture_output=True, text=True, timeout=tmo + 120)
        except subprocess.TimeoutExpired: return name, "TIMEOUT", time.time() - t0, f"no result in {tmo} s at depth {depth}", claim
        log = open(f"{out}/log.txt").read() if os.path.exists(f"{out}/log.txt") else ""
        st = "PASS" if "no model found: SUCCESS" in log else ("FAIL" if "model found: FAIL" in log else "ERROR")
        return name, st, time.time() - t0, "" if st == "PASS" else (r.stdout + r.stderr + log)[-400:], claim
    ys += [f"write_smt2 -wires {out}/m.smt2"]
    r = subprocess.run(["yosys", "-q", "-p", "; ".join(ys)], cwd=ROOT, capture_output=True, text=True)
    if r.returncode: return name, "ERROR", 0.0, (r.stdout + r.stderr)[-500:], claim
    cmd = ["yosys-smtbmc", "-s", "z3", "-t", str(depth), "--presat", f"{out}/m.smt2"]
    try: b = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=tmo)
    except subprocess.TimeoutExpired: return name, "TIMEOUT", time.time() - t0, f"no result in {tmo} s at depth {depth}", claim
    log = b.stdout + b.stderr; open(f"{out}/smtbmc.log", "w").write(log)
    st = "PASS" if "Status: PASSED" in b.stdout else ("FAIL" if "Status: FAILED" in b.stdout else "ERROR")
    return name, st, time.time() - t0, "" if st == "PASS" else log[-500:], claim
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--only"); ap.add_argument("--rtl-dir", default=os.path.join(ROOT, "rtl")); ap.add_argument("--report", default="reports/formal.md"); a = ap.parse_args()
    rows = []
    for j in JOBS:
        if a.only and a.only not in j[0]: continue
        r = list(run(j, a.rtl_dir))
        if '_wit' in j[0]: r[1] = 'PASS' if r[1] == 'FAIL' else 'FAIL'; r[3] = ''      # witness: the event must be reachable, i.e. the 'impossible' assertion must be violated
        r = tuple(r); rows.append((r, j)); print(f"{r[1]:7s} {r[0]:14s} {r[2]:7.1f}s  depth {j[4]:2d}  {r[4]}" + (f"\n   {r[3]}" if r[1] != "PASS" else ""), flush=True)
    ok = all(r[0][1] == "PASS" for r in rows)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, a.report), "w") as f:
        f.write("# Formal verification results\n\nYosys 0.33 + yosys-smtbmc + Z3 4.8.12.  **Exhaustive** = purely combinational harness, depth 1, every input value (Z3).  **BMC** = bounded model check (Yosys SAT engine) to the stated depth from the reset state: "
                "no counterexample within that depth; NOT an unbounded proof.  Inputs of the sequential harnesses are free (the solver chooses them) except for the stated environment assumptions "
                "(a source holds a beat until accepted; short commands; pipelines do not become busy while nothing runs).\n\n| job | kind | depth | result | time | what is checked |\n|---|---|---|---|---|---|\n")
        for r, j in rows: f.write(f"| {r[0]} | {'exhaustive' if j[4] == 1 else ('witness (reachability)' if '_wit' in j[0] else 'BMC')} | {j[4]} | {r[1]} | {r[2]:.0f} s | {r[4]} |\n")
        f.write(f"\n**{sum(1 for r, j in rows if r[1] == 'PASS')} of {len(rows)} jobs pass.**\n")
    sys.exit(0 if ok else 1)
