// cmd_validate == the acceptance rules of docs/02_ABI.md section 5, restated independently.  Exhaustive over all 64-bit commands (SMT).
module fv_cmd
  import sf_collective_pkg::*;
#(parameter NP = 4, parameter MAXLEN = 100, parameter RS = 1, parameter AG = 1, parameter FP = 1, parameter INT = 0)
(
  input wire logic [63:0] c
);
  wire [15:0] cid = c[15:0];
  wire [2:0] ct = c[18:16], op = c[21:19]; wire [1:0] dt = c[23:22]; wire [2:0] rm = c[26:24];
  wire [7:0] sm = c[34:27], rmk = c[42:35]; wire [20:0] ln = c[63:43];
  wire [3:0] v = cmd_validate(c, NP, MAXLEN, RS[0], AG[0], FP[0], INT[0]);
  wire [7:0] vb = (NP >= 8) ? 8'hFF : ((8'd1 << NP) - 8'd1);
  function [3:0] pc(input [7:0] m); integer i; begin pc = 0; for (i = 0; i < 8; i = i + 1) pc = pc + m[i]; end endfunction
  wire [3:0] ns = pc(sm), nr = pc(rmk);
  wire type_ok = (ct <= 4) && (ct != 3 || RS != 0) && (ct != 4 || AG != 0) && !(INT != 0 && (ct == 3 || ct == 4));
  wire copy_t  = (ct == 1) || (ct == 4);
  wire op_ok   = (dt <= 2) && (copy_t ? (op == 6) : (op <= 5 && (dt != 2 || (FP != 0 && op == 0))));
  wire rm_ok   = !(dt == 2 && op == 0 && rm > 4);
  wire len_ok  = (ln <= MAXLEN) && !(ct == 3 && nr != 0 && (ln % nr) != 0);
  wire mask_ok = ((sm & ~vb) == 0) && ((rmk & ~vb) == 0);
  wire role_ok = (INT != 0) ? !(ns == 0 && nr == 0) && !(ct == 0 && nr > 1) && !(ct == 1 && ns > 1)
                            : (ns != 0 && nr != 0 && !(ct == 0 && nr != 1) && !(ct == 1 && ns != 1));
  wire spec_ok = type_ok && op_ok && rm_ok && len_ok && mask_ok && role_ok;
  wire [3:0] spec_code = !type_ok ? E_CMD_TYPE : (!op_ok || !rm_ok) ? E_CMD_OP : !len_ok ? E_CMD_LEN : !(mask_ok && role_ok) ? E_CMD_MASK : E_OK;
  always_comb begin
    assert((v == E_OK) == spec_ok);        // accepts exactly the specified commands
    assert(v == spec_code);                // and names the first failing rule in the documented order
    assert(v != E_CMD_CID);                // the ID rule belongs to the queue, not to this function
  end
  wire unused = &{1'b0, cid};
endmodule
