// Scheduler: exactly one completion record per popped command, none without a command; success only after the done conditions were observed;
// no completion of a failed command while FP pipelines are busy; context stable during a run; failure only in a running, not-done state.
module fv_sched
  import sf_collective_pkg::*;
#(parameter NP = 2, parameter WIT = 0)
(
  input wire clk, input wire qv_raw, input wire [63:0] qcmd_raw, input wire [3:0] qerr_raw, input wire [31:0] to_raw, input wire abort, input wire [NP-1:0] pfail,
  input wire [NP-1:0] ierr, input wire [NP*4-1:0] icode, input wire derr, input wire [3:0] dcode, input wire [NP-1:0] idone, input wire [NP-1:0] ihv, input wire rdone,
  input wire [5:0] rflags, input wire rbusy_raw, input wire odone, input wire [NP:0] pend, input wire prog, input wire cfull
);
  reg rst_n = 1'b0; always @(posedge clk) rst_n <= 1'b1;
  wire [31:0] cfg_to = {30'd0, to_raw[1:0]};
  // the command queue's FIFO semantics: a presented command stays (and stays stable) until popped
  reg qhold = 0; reg [63:0] hc; reg [3:0] he;
  wire q_valid = qhold | qv_raw; wire [63:0] q_cmd = qhold ? hc : qcmd_raw; wire [3:0] q_err = qhold ? he : qerr_raw;
  always @* assume(q_cmd[63:43] <= 21'd3);                                           // short commands keep the proof bounded
  wire q_pop, run, idle, ref_valid, act_gather, act_redscat, up_en, down_en, fail_pulse, cpl_push, ev_ok, ev_err;
  wire [15:0] ref_cid, cpl_cid; wire [2:0] a_ct, a_op, a_rm, cpl_ct; wire [1:0] a_dt; wire [NP-1:0] a_s, a_r; wire [20:0] a_len, res_len, out_len, cpl_len; wire cpl_ok;
  wire [3:0] cpl_err; wire [5:0] cpl_fl; wire [8:0] mA, mB; wire [31:0] cyc;
  reg run_d = 0, rbusy_d = 0;
  wire rbusy = rbusy_raw;
  always @* if (rst_n) assume(!(!run_d && !rbusy_d && rbusy_raw));                  // pipelines do not become busy while nothing runs
  sf_collective_scheduler #(.NP(NP), .INTERIOR(1'b0), .REDSCAT_EN(1'b0), .ALLGATHER_EN(1'b0)) dut (
    .clk(clk), .rst_n(rst_n), .sclr(1'b0), .q_valid(q_valid), .q_pop(q_pop), .q_cmd(q_cmd), .q_err(q_err), .cfg_timeout(cfg_to), .ctl_abort(abort), .part_fail(pfail),
    .run(run), .idle(idle), .ref_valid(ref_valid), .ref_cid(ref_cid), .act_ctype(a_ct), .act_op(a_op), .act_dtype(a_dt), .act_rm(a_rm), .act_send(a_s), .act_recv(a_r),
    .act_len(a_len), .act_gather(act_gather), .act_redscat(act_redscat), .res_len(res_len), .out_len(out_len), .up_en(up_en), .down_en(down_en), .fail_pulse(fail_pulse),
    .in_err_pulse(ierr), .in_err_code(icode), .dn_err_pulse(derr), .dn_err_code(dcode), .in_done(idone), .in_hvalid(ihv), .dn_done(1'b0), .dn_hvalid(1'b0), .red_done(rdone),
    .red_flags(rflags), .red_busy(rbusy), .out_done(odone), .pend_mask(pend), .progress(prog),
    .cpl_push(cpl_push), .cpl_full(cfull), .cpl_cid(cpl_cid), .cpl_ok(cpl_ok), .cpl_err(cpl_err), .cpl_ctype(cpl_ct), .cpl_flags(cpl_fl), .cpl_maskA(mA), .cpl_maskB(mB),
    .cpl_len(cpl_len), .cpl_cycles(cyc), .ev_cpl_ok(ev_ok), .ev_cpl_err(ev_err));
  always @(posedge clk) if (rst_n) begin qhold <= q_valid && !q_pop; hc <= q_cmd; he <= q_err; run_d <= run; rbusy_d <= rbusy; end
  // shadow
  reg inflight = 0, done_seen = 0, failed_seen = 0; reg [20:0] cmd_len; reg [3:0] cmd_err; reg [15:0] cmd_cid;
  reg [20:0] p_len; reg [15:0] p_ref; reg [NP-1:0] p_send; reg [2:0] p_op;
  wire done_now = run && ((a_s == 0) || rdone) && odone;
  always @(posedge clk) if (rst_n) begin
    if (q_pop) begin inflight <= 1; done_seen <= 0; failed_seen <= 0; cmd_len <= q_cmd[63:43]; cmd_err <= q_err; cmd_cid <= q_cmd[15:0]; end
    if (cpl_push) inflight <= 0;
    if (done_now) done_seen <= 1;
    if (fail_pulse) failed_seen <= 1;
    p_len <= a_len; p_ref <= ref_cid; p_send <= a_s; p_op <= a_op;
  end
  always @* if (rst_n) begin
    if (cpl_push) begin assert(inflight); assert(cpl_cid == cmd_cid); end             // a record only for a popped command, carrying its ID
    if (q_pop) assert(!inflight);                                                    // one command at a time
    if (run) assert(inflight);
    if (idle) assert(!inflight);
    if (cpl_push && cpl_ok && cmd_len != 0) begin assert(done_seen); assert(cmd_err == E_OK); end   // success only after the done conditions held
    if (cpl_push && cmd_err != E_OK) assert(!cpl_ok);                                // a rejected command never reports success
    if (cpl_push && failed_seen) begin assert(!cpl_ok); assert(!rbusy); end         // a failed command: error record, and only after the pipelines drained
    if (fail_pulse) begin assert(run); assert(!done_now); end
    if (cpl_push) assert(ev_ok == cpl_ok && ev_err == !cpl_ok);
    if (WIT == 1) assert(!(cpl_push && cpl_ok && cmd_len != 0));                    // witness: a successful non-empty collective
    if (WIT == 2) assert(!(cpl_push && failed_seen));                               // witness: a failed collective reaches its record
    if (WIT == 3) assert(!(cpl_push && cmd_err != E_OK));                           // witness: a rejected command reaches its record
  end
  always @(posedge clk) if (rst_n && run && run_d) begin                              // context is stable while a command runs
    assert(a_len == p_len); assert(ref_cid == p_ref); assert(a_s == p_send); assert(a_op == p_op);
  end
  wire unused = &{1'b0, act_gather, act_redscat, up_en, down_en, a_ct, a_rm, a_dt, a_r, res_len, out_len, cpl_ct, cpl_len, cpl_fl, mA, mB, cyc, ref_valid};
endmodule
