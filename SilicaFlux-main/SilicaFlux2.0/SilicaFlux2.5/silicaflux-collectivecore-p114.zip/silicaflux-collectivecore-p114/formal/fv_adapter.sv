// Ingress adapter: what enters the input buffer is EXACTLY the in-order, exactly-once, header-checked element stream of the running collective.
// Shadow queue: every stored element is checked against the beat that carried it; every popped element against the shadow; stall rule for future IDs.
module fv_adapter
  import sf_collective_pkg::*;
#(parameter PID = 1, parameter DEPTH = 3, parameter WIT = 0)
(
  input wire clk, input wire act_valid_raw, input wire v_raw, input wire [15:0] cid_raw, input wire [2:0] pid_raw, input wire [19:0] idx_raw, input wire [1:0] dt_raw,
  input wire [2:0] op_raw, input wire [31:0] data_raw, input wire last_raw, input wire err_raw, input wire hready_raw
);
  reg rst_n = 1'b0; always @(posedge clk) rst_n <= 1'b1;
  (* anyconst *) reg [15:0] act_cid; (* anyconst *) reg [20:0] act_len; (* anyconst *) reg act_en, ref_valid;
  wire act_valid = act_valid_raw;                 // the collective starts and ends at arbitrary times: state must be cleared at every boundary (* anyconst *) reg [1:0] act_dt; (* anyconst *) reg [2:0] act_op;
  always @* begin assume(act_len >= 1 && act_len <= 6); end
  // a source holds its beat stable until it is accepted
  reg held = 0; reg [15:0] h_cid; reg [2:0] h_pid; reg [19:0] h_idx; reg [1:0] h_dt; reg [2:0] h_op; reg [31:0] h_data; reg h_last, h_err;
  wire s_valid = held | v_raw;
  wire [15:0] s_cid = held ? h_cid : cid_raw; wire [2:0] s_pid = held ? h_pid : pid_raw; wire [19:0] s_idx = held ? h_idx : idx_raw;
  wire [1:0] s_dtype = held ? h_dt : dt_raw; wire [2:0] s_op = held ? h_op : op_raw; wire [31:0] s_data = held ? h_data : data_raw;
  wire s_last = held ? h_last : last_raw, s_err = held ? h_err : err_raw;
  wire s_ready, hv, err_pulse, in_done, ev_accept, ev_stale; wire [31:0] hd; wire [20:0] exp_idx; wire [$clog2(DEPTH+1)-1:0] level; wire [3:0] err_code;
  wire h_ready = hready_raw;
  sf_collective_stream_adapter #(.PID(PID), .IN_DEPTH(DEPTH)) dut (
    .clk(clk), .rst_n(rst_n), .sclr(1'b0), .s_valid(s_valid), .s_ready(s_ready), .s_cid(s_cid), .s_pid(s_pid), .s_idx(s_idx), .s_dtype(s_dtype), .s_op(s_op),
    .s_data(s_data), .s_last(s_last), .s_err(s_err), .ref_valid(ref_valid), .act_valid(act_valid), .act_cid(act_cid), .act_len(act_len), .act_dtype(act_dt),
    .act_op(act_op), .act_en(act_en), .h_valid(hv), .h_ready(h_ready), .h_data(hd), .exp_idx(exp_idx), .in_done(in_done), .level(level),
    .err_pulse(err_pulse), .err_code(err_code), .ev_accept(ev_accept), .ev_stale(ev_stale));
  always @(posedge clk) if (rst_n) begin
    held <= s_valid && !s_ready; h_cid <= s_cid; h_pid <= s_pid; h_idx <= s_idx; h_dt <= s_dtype; h_op <= s_op; h_data <= s_data; h_last <= s_last; h_err <= s_err;
  end
  // shadow
  reg [20:0] e = 0; reg [31:0] q [0:7]; reg [3:0] wr = 0, rd = 0;
  wire future = !ref_valid || cid_after(s_cid, act_cid);
  always @(posedge clk) if (rst_n) begin
    if (!act_valid) begin e <= 0; wr <= 0; rd <= 0; end                           // between collectives the buffer and the index counter are cleared
    else begin
      if (ev_accept) begin q[wr[2:0]] <= s_data; wr <= wr + 1; e <= e + 1; end
      if (hv && h_ready) rd <= rd + 1;
    end
  end
  always @* if (rst_n) begin
    if (ev_accept) begin                                                          // a stored element is the next element of THIS collective, from the right port, well formed
      assert(act_valid && ref_valid && act_en); assert(s_cid == act_cid); assert(s_pid == PID); assert(s_dtype == act_dt && s_op == act_op);
      assert(!s_err); assert({1'b0, s_idx} == e); assert({1'b0, s_idx} < act_len); assert(s_last == ({1'b0, s_idx} == act_len - 21'd1));
    end
    if (hv) assert(hd == q[rd[2:0]]);                                            // elements leave the buffer in order, unchanged, none lost or repeated
    assert(exp_idx == e);
    assert(level == wr - rd);
    assert(e <= act_len);
    if (s_valid && future) assert(!s_ready);                                      // a beat of a future collective is held, never consumed
    if (s_valid && !future && !(s_cid == act_cid && act_valid)) assert(s_ready); // a stale beat is always consumed (never blocks a port)
    if (s_valid && s_cid == act_cid && ref_valid && act_valid && s_ready && !ev_accept) assert(err_pulse);   // a consumed, not-stored beat of the running collective is an error
    if (err_pulse) assert(err_code != E_OK);
    if (WIT == 1) assert(!(ev_accept && wr >= 2));                                // witness: two elements can be stored
    if (WIT == 2) assert(!err_pulse);                                              // witness: a protocol error can occur
    if (WIT == 3) assert(!(hv && h_ready && rd >= 1));                             // witness: elements can be popped
  end
endmodule
