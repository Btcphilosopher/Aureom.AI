// Output port: the stream-stability rule (an offered beat is never withdrawn or changed until accepted -- the defect found by simulation),
// well-formed beats, terminators.  `run` and `fail` are free (fail only while running); pushes only while running.
module fv_outport
  import sf_collective_pkg::*;
#(parameter DEPTH = 2, parameter TD = 2, parameter WIT = 0)
(
  input wire clk, input wire run_raw, input wire fail_raw, input wire in_v_raw, input wire [31:0] in_data, input wire o_ready
);
  reg rst_n = 1'b0; always @(posedge clk) rst_n <= 1'b1;
  (* anyconst *) reg [15:0] cid; (* anyconst *) reg [20:0] exp_len; (* anyconst *) reg [1:0] dt; (* anyconst *) reg [2:0] op;
  always @* assume(exp_len >= 2 && exp_len <= 5);
  // environment contract (guaranteed by sf_collective_output / the reduction / the dn adapter): a collective pushes at most exp_len elements into a port
  reg [20:0] pushed = 0;
  wire run = run_raw; wire fail = fail_raw && run;
  wire in_v = in_v_raw && run && (pushed < exp_len);
  wire in_ready, o_valid, o_last, o_err, pend, term_busy, ev_beat, ev_tl; wire [15:0] o_cid; wire [2:0] o_pid, o_op; wire [19:0] o_idx; wire [1:0] o_dt; wire [31:0] o_data; wire [$clog2(DEPTH+1)-1:0] lvl;
  sf_collective_outport #(.DEPTH(DEPTH), .PID(1), .TERM_DEPTH(TD)) dut (
    .clk(clk), .rst_n(rst_n), .sclr(1'b0), .run(run), .fail(fail), .cid(cid), .dtype(dt), .op(op), .en(1'b1), .exp_len(exp_len),
    .in_valid(in_v), .in_ready(in_ready), .in_data(in_data), .o_valid(o_valid), .o_ready(o_ready), .o_cid(o_cid), .o_pid(o_pid), .o_idx(o_idx),
    .o_dtype(o_dt), .o_op(o_op), .o_data(o_data), .o_last(o_last), .o_err(o_err), .pend(pend), .term_busy(term_busy), .ev_beat(ev_beat), .ev_term_lost(ev_tl), .level(lvl));
  always @(posedge clk) if (rst_n) begin if (!run) pushed <= 0; else if (in_v && in_ready) pushed <= pushed + 1; end
  reg pv = 0, pr = 0; reg [15:0] p_cid; reg [19:0] p_idx; reg [31:0] p_data; reg p_last, p_err;
  always @(posedge clk) if (rst_n) begin
    pv <= o_valid; pr <= o_ready; p_cid <= o_cid; p_idx <= o_idx; p_data <= o_data; p_last <= o_last; p_err <= o_err;
    if (pv && !pr) begin                                                            // offered and not accepted -> identical next cycle
      assert(o_valid); assert(o_cid == p_cid); assert(o_idx == p_idx); assert(o_data == p_data); assert(o_last == p_last); assert(o_err == p_err);
    end
  end
  always @* if (rst_n) begin
    if (o_valid && o_err) begin assert(o_last); assert(o_data == 0); assert(o_pid == 1); end   // terminator: err beats are last, carry no data
    if (o_valid && !o_err) begin
      assert({1'b0, o_idx} < exp_len);                                              // no data beat beyond the expected length
      assert(o_last == ({1'b0, o_idx} == exp_len - 21'd1));                         // LAST exactly on the final element
      assert(o_pid == 1);
    end
  end
  always @* if (rst_n) begin
    if (WIT == 1) assert(!(o_valid && o_err));                                      // witness: a terminator can be offered
    if (WIT == 2) assert(!(o_valid && !o_err && o_last));                           // witness: a complete stream can be offered
    if (WIT == 3) assert(!(pv && !pr));                                             // witness: a beat can be stalled
  end
  wire unused = &{1'b0, in_ready, pend, term_busy, ev_beat, ev_tl, lvl, o_op, o_dt};
endmodule
