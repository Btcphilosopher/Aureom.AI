// Collective-ID serial-number order (sf_collective_pkg::cid_after): proved over the WHOLE 16-bit space.
module fv_cid
  import sf_collective_pkg::*;
(
  input wire logic [15:0] a, input wire logic [15:0] b, input wire logic [15:0] c, input wire logic [14:0] k
);
  wire [15:0] kk = {1'b0, k};
  always_comb begin
    assert(!cid_after(a, a));                                                     // irreflexive
    if (cid_after(a, b)) assert(!cid_after(b, a));                                // asymmetric
    if (a != b && (a - b) != 16'h8000) assert(cid_after(a, b) || cid_after(b, a));  // total except exactly half the circle apart
    if (k != 15'd0) begin assert(cid_after(a + kk, a)); assert(!cid_after(a, a + kk)); end   // k steps ahead (k < 2^15) is "after", never "before"
    if (((a - b) < 16'h4000) && ((b - c) < 16'h4000) && a != b && b != c) assert(cid_after(a, c));   // transitive inside a quarter-circle window
    assert(cid_after(a + 16'd1, a));                                              // the successor is after, across the wrap-around too
  end
endmodule
