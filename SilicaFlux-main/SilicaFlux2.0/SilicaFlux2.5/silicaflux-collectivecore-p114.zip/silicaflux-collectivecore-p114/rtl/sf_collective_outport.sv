// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_outport -- one output stream port
//
//   push (fork) -> FIFO -> OUTPUT REGISTER -> port.   Every beat the port ever offers comes out of the output register, which
//   holds it until the sink accepts it: an offered beat is NEVER withdrawn or replaced (stream stability rule), not even
//   by a collective failure.  A failure flushes the FIFO but leaves the register alone; the error terminator is queued
//   BEHIND the register's beat (priority over anything that a later collective pushes).
//
//   ld_cnt   data beats of the running collective loaded into the register (= index of the next beat)
//   del_cnt  data beats of the running collective ACCEPTED by the sink (completion counts these)
//   A beat that is still in the register when the collective ends (failure) is marked old: its acceptance does not count
//   for the next collective.  Loading is gated by `run`, so after the failure cycle nothing of the failed collective is added.
//   Terminator: {cid of the failed collective, idx = beats of that collective offered, last = 1, err = 1, data = 0}, armed only
//   if the port still owed beats.  Terminators wait in a small queue (TERM_DEPTH), in failure order, so a sink that is stalled
//   across several failed collectives still gets one per failed collective once it wakes up.  If the queue is full the newest
//   terminator is lost and `ev_term_lost` pulses (counted by the perf bank): a bounded, visible limit, never silent.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_outport
  import sf_collective_pkg::*;
#(
  parameter int DEPTH      = 4,
  parameter int PID        = 0,
  parameter int TERM_DEPTH = 2          // error terminators that can wait behind a stalled sink
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 sclr,
  input  wire logic                 run,
  input  wire logic                 fail,          // pulse while run: the collective is being abandoned
  // ---- context of the running collective
  input  wire logic [CID_W-1:0]     cid,
  input  wire logic [1:0]           dtype,
  input  wire logic [2:0]           op,
  input  wire logic                 en,            // this port is a destination of the running collective
  input  wire logic [LEN_W-1:0]     exp_len,       // beats this port must deliver
  // ---- push side
  input  wire logic                 in_valid,
  output logic                      in_ready,
  input  wire logic [DATA_W-1:0]    in_data,
  // ---- stream out
  output logic                      o_valid,
  input  wire logic                 o_ready,
  output logic [CID_W-1:0]          o_cid,
  output logic [PID_W-1:0]          o_pid,
  output logic [IDX_W-1:0]          o_idx,
  output logic [1:0]                o_dtype,
  output logic [2:0]                o_op,
  output logic [DATA_W-1:0]         o_data,
  output logic                      o_last,
  output logic                      o_err,
  // ---- status
  output logic                      pend,          // en && fewer than exp_len beats accepted so far
  output logic                      term_busy,     // a terminator is queued or sitting in the register
  output logic                      ev_beat,       // a data beat was accepted by the sink
  output logic                      ev_term_lost,  // a terminator could not be queued
  output logic [$clog2(DEPTH+1)-1:0] level
);
  wire clr = !run || sclr;

  logic              f_valid;
  logic [DATA_W-1:0] f_data;
  logic              ov_q, oe_q, old_q, ol_q;
  logic [CID_W-1:0]  oc_q;
  logic [1:0]        od_q;
  logic [2:0]        oo_q;
  logic [IDX_W-1:0]  oi_q;
  logic [DATA_W-1:0] odata_q;
  logic [LEN_W-1:0]  ld_cnt, del_cnt;
  logic              t_pend, tq_in_ready;
  logic [$clog2(TERM_DEPTH+1)-1:0] tq_level;
  logic [CID_W+IDX_W+5-1:0] t_word;

  wire slot_free  = !ov_q || o_ready;
  wire load_term  = slot_free && t_pend && !sclr;
  wire load_data  = slot_free && !t_pend && f_valid && run && !sclr;
  wire [LEN_W-1:0] ld_nx = ld_cnt + {{(LEN_W-1){1'b0}}, load_data};

  sfd_fifo #(.WIDTH(DATA_W), .DEPTH(DEPTH)) u_fifo (
    .clk(clk), .rst_n(rst_n), .flush(clr),
    .in_valid(in_valid), .in_ready(in_ready), .in_data(in_data),
    .out_valid(f_valid), .out_ready(load_data), .out_data(f_data), .level(level)
  );

  wire accept = ov_q && o_ready;
  wire arm    = fail && run && en && (ld_nx != exp_len);
  sfd_fifo #(.WIDTH(CID_W + IDX_W + 5), .DEPTH(TERM_DEPTH)) u_tq (
    .clk(clk), .rst_n(rst_n), .flush(sclr),
    .in_valid(arm), .in_ready(tq_in_ready), .in_data({op, dtype, IDX_W'(ld_nx), cid}),
    .out_valid(t_pend), .out_ready(load_term), .out_data(t_word), .level(tq_level)
  );
  assign ev_term_lost = arm && !tq_in_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ov_q <= 1'b0; oe_q <= 1'b0; old_q <= 1'b0; ol_q <= 1'b0;
      oc_q <= '0; od_q <= '0; oo_q <= '0; oi_q <= '0; odata_q <= '0;
      ld_cnt <= '0; del_cnt <= '0;
    end else begin
      // output register
      if (sclr) begin
        ov_q <= 1'b0;
      end else begin
        if (accept) ov_q <= 1'b0;
        if (load_term) begin
          ov_q <= 1'b1; oe_q <= 1'b1; old_q <= 1'b1; ol_q <= 1'b1;
          oc_q <= t_word[CID_W-1:0]; oi_q <= t_word[CID_W +: IDX_W]; od_q <= t_word[CID_W+IDX_W +: 2]; oo_q <= t_word[CID_W+IDX_W+2 +: 3];
          odata_q <= '0;
        end else if (load_data) begin
          ov_q <= 1'b1; oe_q <= 1'b0; old_q <= 1'b0; ol_q <= (ld_cnt == exp_len - 1'b1);
          oc_q <= cid; od_q <= dtype; oo_q <= op; oi_q <= IDX_W'(ld_cnt); odata_q <= f_data;
        end else if (!run) begin
          old_q <= 1'b1;                       // whatever is still in the register belongs to a finished collective
        end
      end
      // counters
      if (clr) begin
        ld_cnt <= '0; del_cnt <= '0;
      end else begin
        if (load_data) ld_cnt <= ld_cnt + 1'b1;
        if (accept && !oe_q && !old_q) del_cnt <= del_cnt + 1'b1;
      end
    end
  end

  assign o_valid = ov_q;
  assign o_cid   = oc_q;
  assign o_pid   = PID_W'(PID);
  assign o_idx   = oi_q;
  assign o_dtype = od_q;
  assign o_op    = oo_q;
  assign o_data  = odata_q;
  assign o_last  = ol_q;
  assign o_err   = oe_q;

  assign pend      = en && (del_cnt != exp_len);
  assign term_busy = t_pend || (ov_q && oe_q);
  assign ev_beat   = accept && !oe_q;
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_tq = |tq_level;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
