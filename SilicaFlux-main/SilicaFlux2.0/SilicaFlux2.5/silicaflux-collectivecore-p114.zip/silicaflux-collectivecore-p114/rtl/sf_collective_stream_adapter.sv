// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_stream_adapter
//
// Participant ingress adapter ("input stream controller" for ONE participant stream).  The same module serves a local
// participant (stream produced by a memory adapter), a remote participant (stream produced by the network adapter) and
// the `down` stream of a tree node; only PID and the `act_en` qualifier differ.
//
// Beat protocol (one beat = one 32-bit element):  s_valid/s_ready, s_cid, s_pid, s_idx, s_dtype, s_op, s_data, s_last, s_err.
// A source must hold a beat stable while s_valid && !s_ready.
//
// Decision for every presented beat (collective IDs are serial numbers, see sf_collective_pkg::cid_after):
//   * ID is not known yet (no collective activated since reset) or strictly AFTER the active/last ID  -> STALL (s_ready = 0).
//     The beat belongs to a collective that has not started; it is held, never dropped, never combined.
//   * ID equals the active collective's                                                              -> checked (below)
//   * ID is before the active/last ID, or equal to it while no collective is active (finished/failed) -> STALE: consumed
//     and discarded (counted).  Late retransmissions and the tails of aborted streams cannot block a port or corrupt
//     a later collective.
// Checks on a beat of the ACTIVE collective, first failing rule wins:  err flag -> E_PEER;  port not a sender, wrong pid,
// wrong data type or operation -> E_HDR;  idx < expected -> E_DUP;  idx > expected -> E_SEQ;  idx >= len or LAST not
// exactly on idx == len-1 -> E_LEN.  A failing beat is consumed, NOT stored, and reported with a one-cycle pulse; the
// scheduler fails the collective.  Elements therefore enter the FIFO strictly in index order 0,1,2,...: the FIFO's
// k-th entry IS element k, which is what makes element alignment in the reduction datapath positional.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_stream_adapter
  import sf_collective_pkg::*;
#(
  parameter int PID      = 0,
  parameter int IN_DEPTH = 4
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                sclr,            // soft reset
  // ---- stream in
  input  wire logic                s_valid,
  output logic                     s_ready,
  input  wire logic [CID_W-1:0]    s_cid,
  input  wire logic [PID_W-1:0]    s_pid,
  input  wire logic [IDX_W-1:0]    s_idx,
  input  wire logic [1:0]          s_dtype,
  input  wire logic [2:0]          s_op,
  input  wire logic [DATA_W-1:0]   s_data,
  input  wire logic                s_last,
  input  wire logic                s_err,
  // ---- context of the collective (from the scheduler)
  input  wire logic                ref_valid,       // some collective has been activated since reset: act_cid is meaningful
  input  wire logic                act_valid,       // a collective is running
  input  wire logic [CID_W-1:0]    act_cid,
  input  wire logic [LEN_W-1:0]    act_len,
  input  wire logic [1:0]          act_dtype,
  input  wire logic [2:0]          act_op,
  input  wire logic                act_en,          // this stream is a permitted source in the running collective
  // ---- head of the input buffer (to the reduction datapath)
  output logic                     h_valid,
  input  wire logic                h_ready,
  output logic [DATA_W-1:0]        h_data,
  // ---- status / events
  output logic [IDX_W:0]           exp_idx,         // elements accepted so far in the running collective
  output logic                     in_done,         // exp_idx == act_len
  output logic [$clog2(IN_DEPTH+1)-1:0] level,
  output logic                     err_pulse,       // a beat of the running collective failed a check (consumed, not stored)
  output logic [3:0]               err_code,
  output logic                     ev_accept,       // element stored
  output logic                     ev_stale         // beat discarded as stale
);
  wire clr = !act_valid || sclr;

  // ---- classification
  wire cid_eq = ref_valid && (s_cid == act_cid);
  wire early  = !ref_valid || cid_after(s_cid, act_cid);
  wire mine   = cid_eq && act_valid;
  wire stale  = !early && !mine;

  wire [LEN_W-1:0] idx_w = LEN_W'(s_idx);
  wire [LEN_W-1:0] exp_w = LEN_W'(exp_idx);
  wire [LEN_W-1:0] last_idx = act_len - 1'b1;

  logic [3:0] code;
  always_comb begin
    code = E_OK;
    if (s_err) code = E_PEER;
    else if (!act_en || s_pid != PID_W'(PID) || s_dtype != act_dtype || s_op != act_op) code = E_HDR;
    else if (idx_w < exp_w) code = E_DUP;
    else if (idx_w > exp_w) code = E_SEQ;
    else if (idx_w >= act_len || (s_last != (idx_w == last_idx))) code = E_LEN;
  end
  wire bad = mine && (code != E_OK);

  logic f_in_ready;
  assign s_ready = early ? 1'b0 : (mine && !bad) ? f_in_ready : 1'b1;

  wire push = s_valid && s_ready && mine && !bad;

  assign err_pulse = s_valid && s_ready && bad;
  assign err_code  = code;
  assign ev_accept = push;
  assign ev_stale  = s_valid && s_ready && stale;

  sfd_fifo #(.WIDTH(DATA_W), .DEPTH(IN_DEPTH)) u_fifo (
    .clk(clk), .rst_n(rst_n), .flush(clr),
    .in_valid(s_valid && mine && !bad), .in_ready(f_in_ready), .in_data(s_data),
    .out_valid(h_valid), .out_ready(h_ready), .out_data(h_data), .level(level)
  );

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)      exp_idx <= '0;
    else if (clr)    exp_idx <= '0;
    else if (push)   exp_idx <= exp_idx + 1'b1;
  end

  assign in_done = (LEN_W'(exp_idx) == act_len);
endmodule
`default_nettype wire
