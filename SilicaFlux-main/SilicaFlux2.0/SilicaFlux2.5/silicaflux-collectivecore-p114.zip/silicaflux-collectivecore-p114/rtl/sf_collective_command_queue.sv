// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_command_queue
//
// Collective Command Queue.  Accepts 64-bit collective commands on a ready/valid port, validates each one
// (sf_collective_pkg::cmd_validate) at enqueue time and stores {command, verdict}.  A command that fails validation is
// NOT dropped: it travels through the queue like any other and is turned into an error completion record by the
// scheduler, so completion records always appear in command order and every submitted command gets exactly one record.
//
// Collective IDs must be STRICTLY INCREASING in 16-bit serial-number order (RFC 1982).  This is what lets the stream
// adapters decide, for a beat that does not belong to the active collective, whether it is early (stall) or stale (drop).
// A command whose ID is not strictly after the last accepted ID is rejected with E_CMD_CID and does NOT move the
// reference ID.  Every other verdict (including rejections) moves it, so data streamed for a rejected collective is
// drained as stale instead of blocking the port.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_command_queue
  import sf_collective_pkg::*;
#(
  parameter int NP           = 2,
  parameter int MAX_LEN      = 4096,
  parameter int CMD_DEPTH    = 4,
  parameter bit REDSCAT_EN   = 1'b0,
  parameter bit ALLGATHER_EN = 1'b0,
  parameter bit FP32_EN      = 1'b0,
  parameter bit INTERIOR     = 1'b0
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 sclr,          // synchronous clear (soft reset): empties the queue, forgets the last ID
  // ---- submit port
  input  wire logic                 cmd_valid,
  output logic                      cmd_ready,
  input  wire logic [CMD_W-1:0]     cmd_data,
  // ---- to the scheduler
  output logic                      q_valid,
  input  wire logic                 q_pop,
  output logic [CMD_W-1:0]          q_cmd,
  output logic [3:0]                q_err,         // E_OK, or the reason the command will not run
  // ---- status
  output logic [$clog2(CMD_DEPTH+1)-1:0] q_level,
  output logic                      ev_reject      // pulse: a command was enqueued with a non-OK verdict
);
  logic        have_last;
  logic [15:0] last_cid;

  logic [3:0] verdict;
  always_comb begin
    if (have_last && !cid_after(cmd_cid(cmd_data), last_cid)) verdict = E_CMD_CID;
    else verdict = cmd_validate(cmd_data, NP, MAX_LEN, REDSCAT_EN, ALLGATHER_EN, FP32_EN, INTERIOR);
  end

  logic             f_in_ready, f_out_valid;
  logic [CMD_W+3:0] f_out;

  sfd_fifo #(.WIDTH(CMD_W + 4), .DEPTH(CMD_DEPTH)) u_fifo (
    .clk(clk), .rst_n(rst_n), .flush(sclr),
    .in_valid(cmd_valid), .in_ready(f_in_ready), .in_data({verdict, cmd_data}),
    .out_valid(f_out_valid), .out_ready(q_pop), .out_data(f_out), .level(q_level)
  );

  assign cmd_ready = f_in_ready;
  assign q_valid   = f_out_valid;
  assign q_cmd     = f_out[CMD_W-1:0];
  assign q_err     = f_out[CMD_W +: 4];

  wire push = cmd_valid && f_in_ready;
  assign ev_reject = push && (verdict != E_OK);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      have_last <= 1'b0;
      last_cid  <= '0;
    end else if (sclr) begin
      have_last <= 1'b0;
    end else if (push && verdict != E_CMD_CID) begin
      have_last <= 1'b1;
      last_cid  <= cmd_cid(cmd_data);
    end
  end
endmodule
`default_nettype wire
