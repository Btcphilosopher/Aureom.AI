// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_mem_rd -- local participant, LOAD engine (memory -> participant stream)
//
// One load descriptor = one buffer of `len` 32-bit elements at IOVA `iova` for domain `dom`.  Validation BEFORE any access:
//   alignment (iova % 4 == 0 -> else M_ALIGN), data length (len <= MAX_LEN and iova + 4*len <= 2**AW, computed without wrap -> else M_LEN),
//   empty buffer (len == 0 completes M_OK with no access and no stream beats).
// Protection: the buffer is cut into bursts that never cross a 4 KiB boundary; every burst is submitted to the MemoryGuard (the
// P64 IOMMU contract StreamDMA uses) and ONLY the physical address the guard returns is ever put on the memory port.  A refusal
// is M_PERM.  The physical burst must lie inside the memory aperture (2**MM_AW) or it is M_BUS without an access (fail closed).
// Element reads (size = 4 bytes) are issued while the stream FIFO has room for the answer, answers return in order.
// Failure: any error terminates the stream with an ERROR BEAT (err = 1, last = 1) after the good beats already read, so the core
// fails the collective (E_PEER) instead of waiting; the completion record carries the cause.  The completion record is issued
// only after the last beat (or the error beat) has been accepted by the core: "completion after delivery".
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_mem_rd
  import sf_collective_pkg::*;
#(
  parameter int AW         = 32,
  parameter int MM_AW      = 20,
  parameter int DOM_W      = 4,
  parameter int MAX_LEN    = 4096,
  parameter int FIFO_DEPTH = 4,
  parameter int PID        = 0,
  parameter logic [3:0] MEMTYPE = 4'd4
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 sclr,
  // ---- load descriptor / completion
  input  wire logic                 ld_valid,
  output logic                      ld_ready,
  input  wire logic [CID_W-1:0]     ld_cid,
  input  wire logic [1:0]           ld_dtype,
  input  wire logic [2:0]           ld_op,
  input  wire logic [AW-1:0]        ld_iova,
  input  wire logic [LEN_W-1:0]     ld_len,
  input  wire logic [DOM_W-1:0]     ld_dom,
  output logic                      cpl_valid,
  input  wire logic                 cpl_ready,
  output logic [CID_W-1:0]          cpl_cid,
  output logic [2:0]                cpl_err,
  // ---- stream to the core
  output logic                      s_valid,
  input  wire logic                 s_ready,
  output logic [CID_W-1:0]          s_cid,
  output logic [PID_W-1:0]          s_pid,
  output logic [IDX_W-1:0]          s_idx,
  output logic [1:0]                s_dtype,
  output logic [2:0]                s_op,
  output logic [DATA_W-1:0]         s_data,
  output logic                      s_last,
  output logic                      s_err,
  // ---- guard (engine side)
  output logic                      gq_valid,
  input  wire logic                 gq_ready,
  output logic [DOM_W-1:0]          gq_dom,
  output logic [3:0]                gq_asid,
  output logic [AW-1:0]             gq_addr,
  output logic [15:0]               gq_bytes,
  input  wire logic                 gr_valid,
  output logic                      gr_ready,
  input  wire logic                 gr_ok,
  input  wire logic [AW-1:0]        gr_pa,
  // ---- memory read port (engine side)
  output logic                      mq_valid,
  input  wire logic                 mq_ready,
  output logic [MM_AW-1:0]          mq_addr,
  input  wire logic                 mr_valid,
  input  wire logic [DATA_W-1:0]    mr_data,
  input  wire logic                 mr_err,
  // ---- events
  output logic                      ev_elem,
  output logic                      ev_busy
);
  typedef enum logic [2:0] {S_IDLE, S_GREQ, S_GWAIT, S_ISSUE, S_FINISH, S_ERRBEAT, S_CPL} st_t;
  st_t st_q;
  logic [CID_W-1:0]  cid_q; logic [1:0] dt_q; logic [2:0] op_q; logic [DOM_W-1:0] dom_q;
  logic [AW-1:0]     iova_q;                         // IOVA of the next burst
  logic [LEN_W-1:0]  len_q, rem_q;                   // total, elements still to be requested (bursts)
  logic [LEN_W-1:0]  bel_q;                          // elements of the current burst still to be issued
  logic [MM_AW-1:0]  pa_q;                           // next element's physical address
  logic [LEN_W-1:0]  out_q;                          // beats handed to the core
  logic [7:0]        outst_q;
  logic              err_q; logic [2:0] code_q;
  logic [AW-1:0]     burst_bytes_w;

  // ---- descriptor validation (no wrap: widths are one bit wider than the address)
  wire [AW+LEN_W+2:0] end_w   = {{(LEN_W+3){1'b0}}, ld_iova} + {{(AW+1){1'b0}}, ld_len, 2'b00};
  wire                misal   = (ld_iova[1:0] != 2'b00);
  wire                toolong = (ld_len > LEN_W'(MAX_LEN)) || (end_w > (({{(AW+LEN_W+2){1'b0}}, 1'b1}) << AW));

  // ---- burst geometry: never cross a 4 KiB boundary
  wire [12:0] to_page   = 13'd4096 - {1'b0, iova_q[11:0]};
  wire [LEN_W+1:0] rem_bytes = {rem_q, 2'b00};
  wire [LEN_W+1:0] page_b    = (LEN_W+2)'(to_page);
  wire [15:0]      burst_b   = (rem_bytes < page_b) ? 16'(rem_bytes) : 16'(to_page);
  wire [LEN_W-1:0] burst_el  = LEN_W'(burst_b[15:2]);
  assign burst_bytes_w = AW'(burst_b);

  assign gq_valid = (st_q == S_GREQ);
  assign gq_dom   = dom_q;
  assign gq_asid  = MEMTYPE;
  assign gq_addr  = iova_q;
  assign gq_bytes = burst_b;
  assign gr_ready = (st_q == S_GWAIT);
  wire [AW:0] pa_end = {1'b0, gr_pa} + {1'b0, burst_bytes_w};
  wire pa_in_ap = (gr_pa >> MM_AW) == '0 && (pa_end <= ((AW+1)'(1) << MM_AW));

  // ---- response FIFO -> stream
  logic f_in_ready, f_valid; logic [DATA_W-1:0] f_data; logic [$clog2(FIFO_DEPTH+1)-1:0] f_lvl;
  wire push = mr_valid && !mr_err && !err_q;
  sfd_fifo #(.WIDTH(DATA_W), .DEPTH(FIFO_DEPTH)) u_f (.clk(clk), .rst_n(rst_n), .flush(sclr), .in_valid(push), .in_ready(f_in_ready),
    .in_data(mr_data), .out_valid(f_valid), .out_ready(s_ready && (st_q != S_ERRBEAT)), .out_data(f_data), .level(f_lvl));
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_fi = f_in_ready;
  /* verilator lint_on UNUSEDSIGNAL */
  wire have_room = (({1'b0, f_lvl} + {1'b0, outst_q[$clog2(FIFO_DEPTH+1)-1:0]}) < (FIFO_DEPTH + 1)'(FIFO_DEPTH));

  assign mq_valid = (st_q == S_ISSUE) && (bel_q != '0) && have_room && !err_q;
  assign mq_addr  = pa_q;
  wire issue = mq_valid && mq_ready;

  wire last_beat = (out_q == len_q - 1'b1);
  assign s_valid = (st_q == S_ERRBEAT) ? 1'b1 : f_valid;
  assign s_cid   = cid_q; assign s_pid = PID_W'(PID); assign s_idx = IDX_W'(out_q); assign s_dtype = dt_q; assign s_op = op_q;
  assign s_data  = (st_q == S_ERRBEAT) ? '0 : f_data;
  assign s_last  = (st_q == S_ERRBEAT) ? 1'b1 : last_beat;
  assign s_err   = (st_q == S_ERRBEAT);
  wire beat_hs = s_valid && s_ready;

  assign ld_ready  = (st_q == S_IDLE);
  assign cpl_valid = (st_q == S_CPL);
  assign cpl_cid   = cid_q;
  assign cpl_err   = code_q;
  assign ev_elem   = issue;
  assign ev_busy   = (st_q != S_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE; cid_q <= '0; dt_q <= '0; op_q <= '0; dom_q <= '0; iova_q <= '0; len_q <= '0; rem_q <= '0; bel_q <= '0; pa_q <= '0;
      out_q <= '0; outst_q <= '0; err_q <= 1'b0; code_q <= M_OK;
    end else if (sclr) begin
      st_q <= S_IDLE; outst_q <= '0; err_q <= 1'b0;
    end else begin
      if (issue && !(mr_valid)) outst_q <= outst_q + 1'b1;
      else if (!issue && mr_valid) outst_q <= outst_q - 1'b1;
      if (mr_valid && mr_err && !err_q) begin err_q <= 1'b1; code_q <= M_BUS; end
      if (beat_hs && st_q != S_ERRBEAT) out_q <= out_q + 1'b1;
      case (st_q)
        S_IDLE: if (ld_valid) begin
          cid_q <= ld_cid; dt_q <= ld_dtype; op_q <= ld_op; dom_q <= ld_dom; iova_q <= ld_iova; len_q <= ld_len; rem_q <= ld_len; out_q <= '0;
          outst_q <= '0; err_q <= 1'b0; code_q <= M_OK;
          if (misal)              begin err_q <= 1'b1; code_q <= M_ALIGN; st_q <= S_FINISH; end
          else if (toolong)       begin err_q <= 1'b1; code_q <= M_LEN;   st_q <= S_FINISH; end
          else if (ld_len == '0)  st_q <= S_CPL;
          else                    st_q <= S_GREQ;
        end
        S_GREQ: if (gq_ready) st_q <= S_GWAIT;
        S_GWAIT: if (gr_valid) begin
          if (!gr_ok)            begin err_q <= 1'b1; code_q <= M_PERM; st_q <= S_FINISH; end
          else if (!pa_in_ap)    begin err_q <= 1'b1; code_q <= M_BUS;  st_q <= S_FINISH; end
          else begin pa_q <= gr_pa[MM_AW-1:0]; bel_q <= burst_el; st_q <= S_ISSUE; end
        end
        S_ISSUE: begin
          if (err_q) st_q <= S_FINISH;
          else if (issue) begin
            bel_q <= bel_q - 1'b1; pa_q <= pa_q + MM_AW'(4);
            if (bel_q == 1) begin
              rem_q  <= rem_q - burst_el; iova_q <= iova_q + burst_bytes_w;
              st_q   <= (rem_q == burst_el) ? S_FINISH : S_GREQ;
            end
          end
        end
        S_FINISH: if (outst_q == '0 && !(mr_valid)) begin
          if (err_q) begin if (!f_valid) st_q <= S_ERRBEAT; end
          else if (out_q == len_q) st_q <= S_CPL;
        end
        S_ERRBEAT: if (beat_hs) st_q <= S_CPL;
        S_CPL: if (cpl_ready) st_q <= S_IDLE;
        default: st_q <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
