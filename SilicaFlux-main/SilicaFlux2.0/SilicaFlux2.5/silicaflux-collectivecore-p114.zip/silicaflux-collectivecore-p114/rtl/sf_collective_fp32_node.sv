// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_fp32_node -- one node of the FP32 reduction tree
//
//   o = a + b      when both sub-trees contribute   (verified fp32_fma computing  a*1.0 + b  -- the product is exact, so
//                                                    the result and all five IEEE flags are those of IEEE-754 addition)
//   o = a          when only a contributes          (passes through UNCHANGED: no add, no flag, NaN payload untouched)
//   o = b          when only b contributes
//   none           nothing
// Elastic: a join on the two operand streams (an add is issued only when BOTH operands are present; both are consumed
// together), then the FMA pipeline (in order, valid/ready, stalls hold results).  `o_flags` carries the exception flags of
// the add whose result is being handed over this cycle (gated by the handshake) so the reduction can OR them into the
// collective's sticky flags exactly once per add.
// flush: operations still inside the FMA pipeline are DISCARDED as they emerge (the FMA has no flush input); `busy` stays
// high until the last one is out, so a failed collective cannot leak a stale partial sum into the next one.
// HAS_ADD = 0 builds a pass-through-only node (the two operands can never both be present).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_fp32_node #(
  parameter bit HAS_ADD = 1'b1
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         flush,
  input  wire logic [2:0]   rm,
  input  wire logic         pa,
  input  wire logic         pb,
  input  wire logic         a_valid,
  output logic              a_ready,
  input  wire logic [31:0]  a_data,
  input  wire logic         b_valid,
  output logic              b_ready,
  input  wire logic [31:0]  b_data,
  output logic              o_valid,
  input  wire logic         o_ready,
  output logic [31:0]       o_data,
  output logic [4:0]        o_flags,
  output logic              busy
);
  wire sel_add = HAS_ADD && pa && pb;
  wire sel_a   = pa && !(HAS_ADD && pb);
  wire sel_b   = !pa && pb;

  generate
    if (HAS_ADD) begin : g_add
      logic        f_in_ready, f_out_valid, f_out_ready;
      logic [31:0] f_res;
      logic [4:0]  f_flags;
      /* verilator lint_off UNUSEDSIGNAL */
      logic        f_tag;
      /* verilator lint_on UNUSEDSIGNAL */
      logic [7:0]  cnt_q;                       // operations inside the FMA pipeline (depth <= 6)

      wire issue = sel_add && a_valid && b_valid && !flush;
      fp32_fma #(.TAG_W(1)) u_fma (
        .clk(clk), .rst_n(rst_n),
        .in_valid(issue), .in_ready(f_in_ready),
        .in_a(a_data), .in_b(32'h3F800000), .in_c(b_data), .in_rm(rm), .in_tag(1'b0),
        .out_valid(f_out_valid), .out_ready(f_out_ready), .out_result(f_res), .out_flags(f_flags), .out_tag(f_tag)
      );
      assign f_out_ready = flush || !sel_add || o_ready;
      wire f_issue_hs  = issue && f_in_ready;
      wire f_retire_hs = f_out_valid && f_out_ready;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) cnt_q <= 8'd0;
        else cnt_q <= cnt_q + {7'd0, f_issue_hs} - {7'd0, f_retire_hs};
      end
      assign busy = (cnt_q != 8'd0);

      always_comb begin
        a_ready = 1'b0; b_ready = 1'b0; o_valid = 1'b0; o_data = a_data; o_flags = 5'd0;
        if (!flush) begin
          if (sel_add) begin
            a_ready = b_valid && f_in_ready;
            b_ready = a_valid && f_in_ready;
            o_valid = f_out_valid;
            o_data  = f_res;
            o_flags = (f_out_valid && o_ready) ? f_flags : 5'd0;
          end else if (sel_a) begin
            a_ready = o_ready; o_valid = a_valid; o_data = a_data;
          end else if (sel_b) begin
            b_ready = o_ready; o_valid = b_valid; o_data = b_data;
          end
        end
      end
    end else begin : g_nadd
      assign busy = 1'b0;
      always_comb begin
        a_ready = 1'b0; b_ready = 1'b0; o_valid = 1'b0; o_data = a_data; o_flags = 5'd0;
        if (!flush) begin
          if (sel_a)      begin a_ready = o_ready; o_valid = a_valid; o_data = a_data; end
          else if (sel_b) begin b_ready = o_ready; o_valid = b_valid; o_data = b_data; end
        end
      end
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_n = clk ^ rst_n ^ (|rm) ^ sel_add;
      /* verilator lint_on UNUSEDSIGNAL */
    end
  endgenerate
endmodule
`default_nettype wire
