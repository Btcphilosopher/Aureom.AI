// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_reduction
//
// Reduction datapath: element alignment -> operator selection -> arithmetic/logic reduction -> result stage -> completion counting.
//
//   h_*[p]  heads of the participants' input buffers.  The adapters store elements strictly in index order, so the head of
//           every participant IS the same element index: "alignment" is positional.  An element is combined only when EVERY
//           present participant's head is valid; all present heads are popped together.  Elements of different collectives
//           can never meet here: the adapters only store beats of the running collective and are cleared between collectives.
//   tree    a fixed balanced binary tree over participant index (leaf 0..7, node(2j,2j+1) ...).  For the integer operators the
//           tree is combinational (SUM/AND/OR/XOR are associative and commutative, MIN/MAX too, so the shape does not change a
//           result; it is fixed anyway because FP32 SUM is not associative and the same definition serves both).
//   FP32    (FP32_EN, FP32 SUM only) the same tree built from sf_collective_fp32_node: verified fp32_fma adds, elastic joins
//   gather  (ALLGATHER_EN) no arithmetic: participants' streams are concatenated in participant order.
//   stage   one elastic result register (r_*).  r_idx / r_last are derived from the element counter.
//   done    red_done = every one of res_len results has been accepted by the consumer of the result stage.
//
// SUM overflow: the wrapped (modulo 2^32) result is delivered; flag bit FL_INT_OVF is raised iff the exact sum of the
// contributions of any element does not fit the data type (signed range for INT32, unsigned for UINT32).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_reduction
  import sf_collective_pkg::*;
#(
  parameter int NP           = 2,
  parameter bit ALLGATHER_EN = 1'b0,
  parameter bit FP32_EN      = 1'b0
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 run,           // a collective is running (low = clear everything)
  input  wire logic                 sclr,          // soft reset
  // ---- collective context
  input  wire logic [2:0]           op,
  input  wire logic [1:0]           dtype,
  input  wire logic [2:0]           rm,
  input  wire logic [NP-1:0]        send_mask,
  input  wire logic                 gather,        // concatenate instead of reduce (ALLGATHER)
  input  wire logic [LEN_W-1:0]     len,           // elements per participant
  input  wire logic [LEN_W-1:0]     res_len,       // elements of the result stream
  // ---- heads of the participants' input buffers
  input  wire logic [NP-1:0]        h_valid,
  output logic [NP-1:0]             h_ready,       // pop
  input  wire logic [NP*DATA_W-1:0] h_data,
  // ---- result stream
  output logic                      r_valid,
  input  wire logic                 r_ready,
  output logic [DATA_W-1:0]         r_data,
  output logic [IDX_W-1:0]          r_idx,
  output logic                      r_last,
  // ---- status
  output logic                      red_done,
  output logic [5:0]                flags,         // sticky for this collective (see sf_collective_pkg FL_*)
  output logic                      busy,          // FP pipelines still hold operations
  output logic                      ev_fire,       // an element entered the result stage
  output logic                      ev_starve,     // waiting for a participant's element
  output logic                      ev_stall       // result stage blocked by its consumer
);
  localparam int PW = (NP > 1) ? $clog2(NP) : 1;
  wire clr = !run || sclr;

  // --------------------------------------------------------------- tree (combinational, integer operators)
  logic [8*DATA_W-1:0] v0;
  logic [7:0]          p0;
  logic [4*DATA_W-1:0] v1;
  logic [3:0]          p1;
  logic [2*DATA_W-1:0] v2;
  logic [1:0]          p2;
  logic [DATA_W-1:0]   v3;
  /* verilator lint_off UNUSEDSIGNAL */
  logic                p3;                       // root presence: only the value is used
  /* verilator lint_on UNUSEDSIGNAL */
  logic signed [34:0]  ssum;
  logic        [34:0]  usum;
  logic                int_ovf;

  always_comb begin
    v0 = '0;
    p0 = '0;
    for (int i = 0; i < NP; i++) begin
      v0[i*DATA_W +: DATA_W] = h_data[i*DATA_W +: DATA_W];
      p0[i]                  = send_mask[i];
    end
    for (int j = 0; j < 4; j++)
      {p1[j], v1[j*DATA_W +: DATA_W]} = red_node(op, dtype, v0[(2*j)*DATA_W +: DATA_W], p0[2*j], v0[(2*j+1)*DATA_W +: DATA_W], p0[2*j+1]);
    for (int j = 0; j < 2; j++)
      {p2[j], v2[j*DATA_W +: DATA_W]} = red_node(op, dtype, v1[(2*j)*DATA_W +: DATA_W], p1[2*j], v1[(2*j+1)*DATA_W +: DATA_W], p1[2*j+1]);
    {p3, v3} = red_node(op, dtype, v2[0 +: DATA_W], p2[0], v2[DATA_W +: DATA_W], p2[1]);

    // exact (unbounded) sum of the contributions, 35 bits are enough for 8 x 32
    ssum = '0;
    usum = '0;
    for (int i = 0; i < 8; i++) begin
      if (p0[i]) begin
        ssum = ssum + 35'($signed(v0[i*DATA_W +: DATA_W]));
        usum = usum + {3'd0, v0[i*DATA_W +: DATA_W]};
      end
    end
    int_ovf = (op == OP_SUM) && ((dtype == DT_U32) ? (usum[34:32] != 3'd0)
                                                   : (ssum != 35'($signed(ssum[31:0]))));
  end

  // --------------------------------------------------------------- gather pointer
  logic [LEN_W-1:0] elem_in;                       // elements that have entered the result stage
  logic [PW-1:0]    g_ptr_q;                       // participant being gathered (valid once elem_in != 0)
  logic [LEN_W-1:0] g_cnt_q;                       // elements already taken from it
  logic [PW-1:0]    g_first, g_next;
  logic             g_found;
  always_comb begin
    g_first = '0;
    for (int i = NP - 1; i >= 0; i--) if (send_mask[i]) g_first = PW'(i);
  end
  wire              first_elem = (elem_in == '0);
  wire  [PW-1:0]    g_cur      = first_elem ? g_first : g_ptr_q;
  always_comb begin                                // next present participant strictly after g_cur (lowest such)
    g_next  = g_cur;
    g_found = 1'b0;
    for (int i = NP - 1; i >= 0; i--) if (send_mask[i] && (PW'(i) > g_cur)) begin g_next = PW'(i); g_found = 1'b1; end
  end

  // --------------------------------------------------------------- FP32 SUM tree (verified fp32_fma nodes)
  //   Same tree shape as the integer one.  Participants' heads feed level 0; elements flow through elastic joins.
  //   Reduction order (docs/03_NUMERICS.md): node(l, r) = l + r for the participant range split in halves at power-of-two
  //   boundaries, an absent half is skipped; the result is a function of the participant mask only, never of timing.
  wire        fp_mode = FP32_EN && (dtype == DT_F32) && (op == OP_SUM) && !gather;
  logic [NP-1:0]      fp_h_ready;
  logic               fp_root_valid, fp_root_ready, fp_busy;
  logic [DATA_W-1:0]  fp_root_data;
  logic [4:0]         fp_flags_acc;

  generate
    if (FP32_EN) begin : g_fp
      logic [7:0]          l0_v, l0_r, l0_p;
      logic [8*DATA_W-1:0] l0_d;
      always_comb begin
        l0_v = '0; l0_p = '0; l0_d = '0;
        for (int i = 0; i < NP; i++) begin
          l0_v[i] = h_valid[i] && fp_mode;
          l0_p[i] = send_mask[i];
          l0_d[i*DATA_W +: DATA_W] = h_data[i*DATA_W +: DATA_W];
        end
      end
      // level 1: leaves (2j, 2j+1)
      logic [3:0]          l1_v, l1_r, l1_p, l1_b;
      logic [4*DATA_W-1:0] l1_d;
      logic [4*5-1:0]      l1_f;
      for (genvar j = 0; j < 4; j++) begin : g_l1
        assign l1_p[j] = l0_p[2*j] | l0_p[2*j+1];
        sf_collective_fp32_node #(.HAS_ADD(2*j+1 < NP)) u_n (
          .clk(clk), .rst_n(rst_n), .flush(clr), .rm(rm), .pa(l0_p[2*j]), .pb(l0_p[2*j+1]),
          .a_valid(l0_v[2*j]), .a_ready(l0_r[2*j]), .a_data(l0_d[(2*j)*DATA_W +: DATA_W]),
          .b_valid(l0_v[2*j+1]), .b_ready(l0_r[2*j+1]), .b_data(l0_d[(2*j+1)*DATA_W +: DATA_W]),
          .o_valid(l1_v[j]), .o_ready(l1_r[j]), .o_data(l1_d[j*DATA_W +: DATA_W]), .o_flags(l1_f[j*5 +: 5]), .busy(l1_b[j]));
      end
      // level 2: nodes (2j, 2j+1) of level 1
      logic [1:0]          l2_v, l2_r, l2_p, l2_b;
      logic [2*DATA_W-1:0] l2_d;
      logic [2*5-1:0]      l2_f;
      for (genvar j = 0; j < 2; j++) begin : g_l2
        assign l2_p[j] = l1_p[2*j] | l1_p[2*j+1];
        sf_collective_fp32_node #(.HAS_ADD(4*j+2 < NP)) u_n (
          .clk(clk), .rst_n(rst_n), .flush(clr), .rm(rm), .pa(l1_p[2*j]), .pb(l1_p[2*j+1]),
          .a_valid(l1_v[2*j]), .a_ready(l1_r[2*j]), .a_data(l1_d[(2*j)*DATA_W +: DATA_W]),
          .b_valid(l1_v[2*j+1]), .b_ready(l1_r[2*j+1]), .b_data(l1_d[(2*j+1)*DATA_W +: DATA_W]),
          .o_valid(l2_v[j]), .o_ready(l2_r[j]), .o_data(l2_d[j*DATA_W +: DATA_W]), .o_flags(l2_f[j*5 +: 5]), .busy(l2_b[j]));
      end
      // level 3: root
      logic       l3_b;
      logic [4:0] l3_f;
      sf_collective_fp32_node #(.HAS_ADD(4 < NP)) u_root (
        .clk(clk), .rst_n(rst_n), .flush(clr), .rm(rm), .pa(l2_p[0]), .pb(l2_p[1]),
        .a_valid(l2_v[0]), .a_ready(l2_r[0]), .a_data(l2_d[0 +: DATA_W]),
        .b_valid(l2_v[1]), .b_ready(l2_r[1]), .b_data(l2_d[DATA_W +: DATA_W]),
        .o_valid(fp_root_valid), .o_ready(fp_root_ready), .o_data(fp_root_data), .o_flags(l3_f), .busy(l3_b));

      assign fp_h_ready = l0_r[NP-1:0];
      assign fp_busy    = (|l1_b) | (|l2_b) | l3_b;
      always_comb begin
        fp_flags_acc = l3_f;
        for (int j = 0; j < 4; j++) fp_flags_acc = fp_flags_acc | l1_f[j*5 +: 5];
        for (int j = 0; j < 2; j++) fp_flags_acc = fp_flags_acc | l2_f[j*5 +: 5];
      end
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_fp = ((l0_r >> NP) != 8'd0) | (|l1_p) | l2_p[0];
      /* verilator lint_on UNUSEDSIGNAL */
    end else begin : g_nofp
      assign fp_h_ready    = '0;
      assign fp_root_valid = 1'b0;
      assign fp_root_data  = '0;
      assign fp_busy       = 1'b0;
      assign fp_flags_acc  = 5'd0;
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_nofp = fp_mode | fp_root_ready | (|rm);
      /* verilator lint_on UNUSEDSIGNAL */
    end
  endgenerate

  // --------------------------------------------------------------- result stage / control
  logic             rv_q;
  logic [DATA_W-1:0] rd_q;
  logic [5:0]       fl_q;

  wire more        = (elem_in != res_len);
  wire stage_free  = !rv_q || r_ready;
  wire pres_valid  = |send_mask;
  wire all_ok      = ((h_valid | ~send_mask) == {NP{1'b1}});
  wire g_head_ok   = h_valid[g_cur];

  wire fire_red    = run && !sclr && !gather && !fp_mode && pres_valid && all_ok && more && stage_free;
  wire fire_gat    = ALLGATHER_EN && run && !sclr && gather && pres_valid && g_head_ok && more && stage_free;
  assign fp_root_ready = run && !sclr && fp_mode && more && stage_free;
  wire fire_fp     = fp_root_valid && fp_root_ready;
  wire fire        = fire_red || fire_gat || fire_fp;

  always_comb begin
    h_ready = '0;
    if (fire_red) h_ready = send_mask;
    if (fire_gat) h_ready[g_cur] = 1'b1;
    if (fp_mode)  h_ready = fp_h_ready;
  end

  wire g_wrap = (g_cnt_q == len - 1'b1);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rv_q    <= 1'b0;
      rd_q    <= '0;
      fl_q    <= '0;
      elem_in <= '0;
      g_ptr_q <= '0;
      g_cnt_q <= '0;
    end else if (clr) begin
      rv_q    <= 1'b0;
      fl_q    <= '0;
      elem_in <= '0;
      g_ptr_q <= '0;
      g_cnt_q <= '0;
    end else begin
      if (r_valid && r_ready) rv_q <= 1'b0;
      fl_q[4:0] <= fl_q[4:0] | fp_flags_acc;
      if (fire) begin
        rv_q    <= 1'b1;
        elem_in <= elem_in + 1'b1;
        if (fire_red) begin
          rd_q <= v3;
          if (int_ovf) fl_q[FL_INT_OVF] <= 1'b1;
        end else if (fire_fp) begin
          rd_q <= fp_root_data;
        end else begin
          rd_q    <= h_data[g_cur*DATA_W +: DATA_W];
          g_ptr_q <= (g_wrap && g_found) ? g_next : g_cur;
          g_cnt_q <= g_wrap ? '0 : g_cnt_q + 1'b1;
        end
      end
    end
  end

  assign r_valid  = rv_q;
  assign r_data   = rd_q;
  assign r_idx    = IDX_W'(elem_in - 1'b1);        // the beat in the stage is the last one that entered
  assign r_last   = (elem_in == res_len);
  assign red_done = run && (elem_in == res_len) && !rv_q && (res_len != '0);
  assign flags    = fl_q;
  assign busy     = fp_busy;

  assign ev_fire   = fire;
  assign ev_starve = run && more && pres_valid && !(gather ? g_head_ok : all_ok);
  assign ev_stall  = run && rv_q && !r_ready;

endmodule
`default_nettype wire
