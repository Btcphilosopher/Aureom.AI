// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_output
//
// Output stream controller.  Two independent flows, both element-ordered:
//
//   UP flow    (tree interior node, up_en):  result stream  ->  `up` port.          Counts: res_len elements.
//   FORK flow  (recv_mask != 0):  source ->  per-participant output buffers.         Source = result stream (root node) or
//              the validated `down` stream (interior node, down_en).
//              Every destination buffer must have room before an element is forked (all-or-nothing), so the slowest receiver
//              back-pressures the others once its buffer is full; OUT_DEPTH bounds the skew between receivers.
//              REDSCAT: element i goes to ONE receiver: receiver r (r-th set bit of recv_mask) gets elements
//              [r*out_len, (r+1)*out_len) of the result, numbered from 0.
//
// A flow is complete when every one of its destinations has ACCEPTED all of its beats (out_done) -- a collective is not
// complete while any result beat is still in a buffer.  Per-port beat indices and `last` come from per-port delivery counters.
//
// Failure: `fail` (one pulse, in the cycle the scheduler abandons the collective) arms an ERROR TERMINATOR for every port that
// still owes beats: a beat {cid of the failed collective, idx = beats offered, last = 1, err = 1, data = 0}, offered right
// after the port's output register is free (a beat that is already on offer is never withdrawn: sf_collective_outport) and
// before anything of a later collective.  Receivers (adapters, `down` streams of child nodes) turn it into E_PEER.  One
// terminator per port is kept: a second failure while the first terminator is still undelivered does not add another
// (documented limit).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_output
  import sf_collective_pkg::*;
#(
  parameter int NP         = 2,
  parameter int OUT_DEPTH  = 4,
  parameter int UP_PID     = 0,
  parameter bit REDSCAT_EN = 1'b0,
  parameter int TERM_DEPTH = 2
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 sclr,
  input  wire logic                 run,
  input  wire logic                 fail,          // pulse (while run): the collective is being abandoned
  // ---- context
  input  wire logic [CID_W-1:0]     cid,
  input  wire logic [1:0]           dtype,
  input  wire logic [2:0]           op,
  input  wire logic [NP-1:0]        recv_mask,
  input  wire logic                 up_en,
  input  wire logic                 down_en,
  input  wire logic                 redscat,
  input  wire logic [LEN_W-1:0]     res_len,       // elements of the result stream (UP flow)
  input  wire logic [LEN_W-1:0]     out_len,       // elements every receiver must get
  // ---- result stream (from the reduction datapath)
  input  wire logic                 r_valid,
  output logic                      r_ready,
  input  wire logic [DATA_W-1:0]    r_data,
  // ---- `down` stream (from the down adapter's buffer)
  input  wire logic                 d_valid,
  output logic                      d_ready,
  input  wire logic [DATA_W-1:0]    d_data,
  // ---- per-participant output streams
  output logic [NP-1:0]             o_valid,
  input  wire logic [NP-1:0]        o_ready,
  output logic [NP*CID_W-1:0]       o_cid,
  output logic [NP*PID_W-1:0]       o_pid,
  output logic [NP*IDX_W-1:0]       o_idx,
  output logic [NP*2-1:0]           o_dtype,
  output logic [NP*3-1:0]           o_op,
  output logic [NP*DATA_W-1:0]      o_data,
  output logic [NP-1:0]             o_last,
  output logic [NP-1:0]             o_err,
  // ---- up stream
  output logic                      u_valid,
  input  wire logic                 u_ready,
  output logic [CID_W-1:0]          u_cid,
  output logic [PID_W-1:0]          u_pid,
  output logic [IDX_W-1:0]          u_idx,
  output logic [1:0]                u_dtype,
  output logic [2:0]                u_op,
  output logic [DATA_W-1:0]         u_data,
  output logic                      u_last,
  output logic                      u_err,
  // ---- status / events
  output logic                      out_done,      // every destination has accepted every beat it is owed
  output logic [NP:0]               pend_mask,     // [p] port p still owes beats (valid for p < NP), [NP] up port
  output logic                      term_busy,     // an error terminator is still waiting to be delivered
  output logic [NP:0]               ev_term_lost,  // per port (NP = up port): a terminator could not be queued
  output logic [NP-1:0]             ev_out_beat,   // data beat accepted by port p's sink
  output logic                      ev_up_beat,
  output logic                      ev_block,      // a source element is waiting for room in a destination buffer
  output logic [NP*$clog2(OUT_DEPTH+1)-1:0] lvl_out,
  output logic [$clog2(OUT_DEPTH+1)-1:0]    lvl_up
);
  localparam int LW = $clog2(OUT_DEPTH + 1);
  wire clr = !run || sclr;

  // ------------------------------------------------------------------ fork destination selection
  logic [LEN_W-1:0] fork_cnt;                // elements forked so far
  logic [LEN_W-1:0] rs_cnt;                  // elements forked into the current REDSCAT chunk
  logic [NP-1:0]    rs_dest_q;
  logic [NP-1:0]    rs_first, rs_cur, rs_next;
  logic             rs_found;
  always_comb begin
    rs_first = '0;
    for (int i = NP - 1; i >= 0; i--) if (recv_mask[i]) rs_first = NP'(1) << i;
  end
  assign rs_cur = (fork_cnt == '0) ? rs_first : rs_dest_q;
  always_comb begin                          // next receiver strictly above the current one
    rs_next  = rs_cur;
    rs_found = 1'b0;
    for (int i = NP - 1; i >= 0; i--) if (recv_mask[i] && ((NP'(1) << i) > rs_cur)) begin rs_next = NP'(1) << i; rs_found = 1'b1; end
  end
  wire [NP-1:0] dest_vec = (REDSCAT_EN && redscat) ? rs_cur : recv_mask;

  // ------------------------------------------------------------------ fork control
  logic [NP-1:0] f_in_ready;
  wire           fork_src_valid = down_en ? d_valid : r_valid;
  wire [DATA_W-1:0] fork_data   = down_en ? d_data  : r_data;
  wire           dests_ready    = ((f_in_ready | ~dest_vec) == {NP{1'b1}});
  wire           fork_fire      = run && !sclr && (recv_mask != '0) && fork_src_valid && dests_ready;
  assign d_ready = down_en && fork_fire;

  logic          up_f_in_ready;
  wire           up_fire = run && !sclr && up_en && r_valid && up_f_in_ready;
  assign r_ready = up_en ? up_fire : (!down_en && fork_fire);

  assign ev_block = run && ((fork_src_valid && (recv_mask != '0) && !dests_ready) || (up_en && r_valid && !up_f_in_ready));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fork_cnt  <= '0;
      rs_cnt    <= '0;
      rs_dest_q <= '0;
    end else if (clr) begin
      fork_cnt  <= '0;
      rs_cnt    <= '0;
      rs_dest_q <= '0;
    end else if (fork_fire) begin
      fork_cnt  <= fork_cnt + 1'b1;
      if (REDSCAT_EN && redscat) begin
        if (rs_cnt == out_len - 1'b1) begin
          rs_cnt    <= '0;
          rs_dest_q <= rs_found ? rs_next : rs_cur;
        end else begin
          rs_cnt    <= rs_cnt + 1'b1;
          rs_dest_q <= rs_cur;
        end
      end
    end
  end

  // ------------------------------------------------------------------ per-participant output ports
  logic [NP-1:0] pend_q, tb_p, tl_p;
  generate
    for (genvar p = 0; p < NP; p++) begin : g_port
      logic [LW-1:0] lvl;
      sf_collective_outport #(.DEPTH(OUT_DEPTH), .PID(p), .TERM_DEPTH(TERM_DEPTH)) u_port (
        .clk(clk), .rst_n(rst_n), .sclr(sclr), .run(run), .fail(fail),
        .cid(cid), .dtype(dtype), .op(op), .en(recv_mask[p]), .exp_len(out_len),
        .in_valid(fork_fire && dest_vec[p]), .in_ready(f_in_ready[p]), .in_data(fork_data),
        .o_valid(o_valid[p]), .o_ready(o_ready[p]),
        .o_cid(o_cid[p*CID_W +: CID_W]), .o_pid(o_pid[p*PID_W +: PID_W]), .o_idx(o_idx[p*IDX_W +: IDX_W]),
        .o_dtype(o_dtype[p*2 +: 2]), .o_op(o_op[p*3 +: 3]), .o_data(o_data[p*DATA_W +: DATA_W]),
        .o_last(o_last[p]), .o_err(o_err[p]),
        .pend(pend_q[p]), .term_busy(tb_p[p]), .ev_beat(ev_out_beat[p]), .ev_term_lost(tl_p[p]), .level(lvl)
      );
      assign lvl_out[p*LW +: LW] = lvl;
    end
  endgenerate

  // ------------------------------------------------------------------ up port
  logic up_pend, up_tb, up_tl;
  sf_collective_outport #(.DEPTH(OUT_DEPTH), .PID(UP_PID), .TERM_DEPTH(TERM_DEPTH)) u_up (
    .clk(clk), .rst_n(rst_n), .sclr(sclr), .run(run), .fail(fail),
    .cid(cid), .dtype(dtype), .op(op), .en(up_en), .exp_len(res_len),
    .in_valid(up_fire), .in_ready(up_f_in_ready), .in_data(r_data),
    .o_valid(u_valid), .o_ready(u_ready), .o_cid(u_cid), .o_pid(u_pid), .o_idx(u_idx),
    .o_dtype(u_dtype), .o_op(u_op), .o_data(u_data), .o_last(u_last), .o_err(u_err),
    .pend(up_pend), .term_busy(up_tb), .ev_beat(ev_up_beat), .ev_term_lost(up_tl), .level(lvl_up)
  );

  // ------------------------------------------------------------------ status
  assign pend_mask = {up_pend, pend_q};
  assign out_done  = (pend_mask == '0);
  assign term_busy = (|tb_p) | up_tb;
  assign ev_term_lost = {up_tl, tl_p};
endmodule
`default_nettype wire
