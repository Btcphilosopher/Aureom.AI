// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_mem_adapter -- local participant adapter (memory side)
//
//   load descriptor  -> [sf_collective_mem_rd]  -> participant input stream  ->  sf_collective_core
//   store descriptor <- [sf_collective_mem_wr]  <- participant output stream <-  sf_collective_core
//   Both engines share ONE MemoryMatrix (P101) master port and ONE MemoryGuard (P64 IOMMU contract) channel through small
//   round-robin arbiters with request locking (a request on offer is never withdrawn / swapped).  Responses are routed back by
//   m_rsp_we / guard id.  Element accesses are 4 bytes; the matrix takes care of bank spanning.
//   StreamDMA stages the buffers (docs/05_MEMORY_INTEGRATION.md): this adapter reads / writes the staging buffers it filled.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_mem_adapter
  import sf_collective_pkg::*;
#(
  parameter int AW         = 32,
  parameter int MM_AW      = 20,
  parameter int DOM_W      = 4,
  parameter int MAX_LEN    = 4096,
  parameter int FIFO_DEPTH = 4,
  parameter int MAXOUT     = 4,
  parameter int PID        = 0,
  parameter int DATA_WIDTH = 128,                      // MemoryMatrix data bus
  parameter int MM_IDW     = 8,
  parameter logic [3:0]  MEMTYPE     = 4'd4,
  parameter logic [15:0] SECURE_MASK = 16'h0000,
  localparam int W   = DATA_WIDTH / 8,
  localparam int LW  = $clog2(W),
  localparam int SZW = (LW > 0) ? $clog2(LW + 1) : 1
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 sclr,
  // ---- control plane
  input  wire logic                 ld_valid,
  output logic                      ld_ready,
  input  wire logic [CID_W-1:0]     ld_cid,
  input  wire logic [1:0]           ld_dtype,
  input  wire logic [2:0]           ld_op,
  input  wire logic [AW-1:0]        ld_iova,
  input  wire logic [LEN_W-1:0]     ld_len,
  input  wire logic [DOM_W-1:0]     ld_dom,
  output logic                      ldc_valid,
  input  wire logic                 ldc_ready,
  output logic [CID_W-1:0]          ldc_cid,
  output logic [2:0]                ldc_err,
  input  wire logic                 st_valid,
  output logic                      st_ready,
  input  wire logic [CID_W-1:0]     st_cid,
  input  wire logic [AW-1:0]        st_iova,
  input  wire logic [LEN_W-1:0]     st_len,
  input  wire logic [DOM_W-1:0]     st_dom,
  output logic                      stc_valid,
  input  wire logic                 stc_ready,
  output logic [CID_W-1:0]          stc_cid,
  output logic [2:0]                stc_err,
  // ---- participant stream to the core
  output logic                      s_valid,
  input  wire logic                 s_ready,
  output logic [CID_W-1:0]          s_cid,
  output logic [PID_W-1:0]          s_pid,
  output logic [IDX_W-1:0]          s_idx,
  output logic [1:0]                s_dtype,
  output logic [2:0]                s_op,
  output logic [DATA_W-1:0]         s_data,
  output logic                      s_last,
  output logic                      s_err,
  // ---- result stream from the core
  input  wire logic                 o_valid,
  output logic                      o_ready,
  input  wire logic [CID_W-1:0]     o_cid,
  input  wire logic [IDX_W-1:0]     o_idx,
  input  wire logic [DATA_W-1:0]    o_data,
  input  wire logic                 o_last,
  input  wire logic                 o_err,
  // ---- MemoryGuard
  output logic                      guard_req_valid,
  input  wire logic                 guard_req_ready,
  output logic [DOM_W-1:0]          guard_req_domain,
  output logic [3:0]                guard_req_asid,
  output logic                      guard_req_write,
  output logic [AW-1:0]             guard_req_addr,
  output logic [15:0]               guard_req_bytes,
  output logic                      guard_req_id,
  input  wire logic                 guard_rsp_valid,
  output logic                      guard_rsp_ready,
  input  wire logic                 guard_rsp_id,
  input  wire logic                 guard_rsp_ok,
  input  wire logic [AW-1:0]        guard_rsp_pa,
  // ---- MemoryMatrix master port
  output logic                      m_req_valid,
  input  wire logic                 m_req_ready,
  output logic                      m_req_we,
  output logic [MM_AW-1:0]          m_req_addr,
  output logic [SZW-1:0]            m_req_size,
  output logic [DATA_WIDTH-1:0]     m_req_wdata,
  output logic [W-1:0]              m_req_be,
  output logic [MM_IDW-1:0]         m_req_id,
  output logic [1:0]                m_req_prot,
  input  wire logic                 m_rsp_valid,
  output logic                      m_rsp_ready,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [DATA_WIDTH-1:0] m_rsp_rdata,                  // only the low 32 bits (one element) are used
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic                 m_rsp_we,
  input  wire logic [2:0]           m_rsp_status,
  // ---- events
  output logic                      ev_rd_elem,
  output logic                      ev_wr_elem,
  output logic                      ev_busy
);
  // ---- engines
  logic        rd_gq_valid, rd_gq_ready, rd_gr_valid, rd_gr_ready, rd_mq_valid, rd_mq_ready, rd_mr_valid;
  logic        wr_gq_valid, wr_gq_ready, wr_gr_valid, wr_gr_ready, wr_mq_valid, wr_mq_ready, wr_mr_valid;
  logic [DOM_W-1:0] rd_gq_dom, wr_gq_dom; logic [3:0] rd_gq_asid, wr_gq_asid; logic [AW-1:0] rd_gq_addr, wr_gq_addr; logic [15:0] rd_gq_bytes, wr_gq_bytes;
  logic [MM_AW-1:0] rd_mq_addr, wr_mq_addr; logic [DATA_W-1:0] wr_mq_data;
  logic rd_busy, wr_busy;
  wire  mr_err = (m_rsp_status != 3'd0);

  sf_collective_mem_rd #(.AW(AW), .MM_AW(MM_AW), .DOM_W(DOM_W), .MAX_LEN(MAX_LEN), .FIFO_DEPTH(FIFO_DEPTH), .PID(PID), .MEMTYPE(MEMTYPE)) u_rd (
    .clk(clk), .rst_n(rst_n), .sclr(sclr),
    .ld_valid(ld_valid), .ld_ready(ld_ready), .ld_cid(ld_cid), .ld_dtype(ld_dtype), .ld_op(ld_op), .ld_iova(ld_iova), .ld_len(ld_len), .ld_dom(ld_dom),
    .cpl_valid(ldc_valid), .cpl_ready(ldc_ready), .cpl_cid(ldc_cid), .cpl_err(ldc_err),
    .s_valid(s_valid), .s_ready(s_ready), .s_cid(s_cid), .s_pid(s_pid), .s_idx(s_idx), .s_dtype(s_dtype), .s_op(s_op), .s_data(s_data), .s_last(s_last), .s_err(s_err),
    .gq_valid(rd_gq_valid), .gq_ready(rd_gq_ready), .gq_dom(rd_gq_dom), .gq_asid(rd_gq_asid), .gq_addr(rd_gq_addr), .gq_bytes(rd_gq_bytes),
    .gr_valid(rd_gr_valid), .gr_ready(rd_gr_ready), .gr_ok(guard_rsp_ok), .gr_pa(guard_rsp_pa),
    .mq_valid(rd_mq_valid), .mq_ready(rd_mq_ready), .mq_addr(rd_mq_addr), .mr_valid(rd_mr_valid), .mr_data(m_rsp_rdata[DATA_W-1:0]), .mr_err(mr_err),
    .ev_elem(ev_rd_elem), .ev_busy(rd_busy));
  sf_collective_mem_wr #(.AW(AW), .MM_AW(MM_AW), .DOM_W(DOM_W), .MAX_LEN(MAX_LEN), .MAXOUT(MAXOUT), .MEMTYPE(MEMTYPE)) u_wr (
    .clk(clk), .rst_n(rst_n), .sclr(sclr),
    .st_valid(st_valid), .st_ready(st_ready), .st_cid(st_cid), .st_iova(st_iova), .st_len(st_len), .st_dom(st_dom),
    .cpl_valid(stc_valid), .cpl_ready(stc_ready), .cpl_cid(stc_cid), .cpl_err(stc_err),
    .o_valid(o_valid), .o_ready(o_ready), .o_cid(o_cid), .o_idx(o_idx), .o_data(o_data), .o_last(o_last), .o_err(o_err),
    .gq_valid(wr_gq_valid), .gq_ready(wr_gq_ready), .gq_dom(wr_gq_dom), .gq_asid(wr_gq_asid), .gq_addr(wr_gq_addr), .gq_bytes(wr_gq_bytes),
    .gr_valid(wr_gr_valid), .gr_ready(wr_gr_ready), .gr_ok(guard_rsp_ok), .gr_pa(guard_rsp_pa),
    .mq_valid(wr_mq_valid), .mq_ready(wr_mq_ready), .mq_addr(wr_mq_addr), .mq_data(wr_mq_data), .mr_valid(wr_mr_valid), .mr_err(mr_err),
    .ev_elem(ev_wr_elem), .ev_busy(wr_busy));
  assign ev_busy = rd_busy || wr_busy;

  // ---- guard channel: round-robin with locking
  logic g_lock_q, g_last_q, g_sel;
  always_comb begin
    if (g_lock_q) g_sel = g_last_q;
    else if (rd_gq_valid && wr_gq_valid) g_sel = !g_last_q;
    else g_sel = wr_gq_valid;
  end
  assign guard_req_valid  = g_sel ? wr_gq_valid : rd_gq_valid;
  assign guard_req_domain = g_sel ? wr_gq_dom : rd_gq_dom;
  assign guard_req_asid   = g_sel ? wr_gq_asid : rd_gq_asid;
  assign guard_req_write  = g_sel;
  assign guard_req_addr   = g_sel ? wr_gq_addr : rd_gq_addr;
  assign guard_req_bytes  = g_sel ? wr_gq_bytes : rd_gq_bytes;
  assign guard_req_id     = g_sel;
  assign rd_gq_ready = guard_req_ready && !g_sel && rd_gq_valid;
  assign wr_gq_ready = guard_req_ready &&  g_sel && wr_gq_valid;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin g_lock_q <= 1'b0; g_last_q <= 1'b0; end
    else if (sclr) g_lock_q <= 1'b0;
    else if (guard_req_valid) begin
      g_last_q <= g_sel;
      g_lock_q <= !guard_req_ready;
    end
  end
  assign rd_gr_valid = guard_rsp_valid && !guard_rsp_id;
  assign wr_gr_valid = guard_rsp_valid &&  guard_rsp_id;
  assign guard_rsp_ready = guard_rsp_id ? wr_gr_ready : rd_gr_ready;

  // ---- matrix master port: round-robin with locking
  logic m_lock_q, m_last_q, m_sel;
  always_comb begin
    if (m_lock_q) m_sel = m_last_q;
    else if (rd_mq_valid && wr_mq_valid) m_sel = !m_last_q;
    else m_sel = wr_mq_valid;
  end
  assign m_req_valid = m_sel ? wr_mq_valid : rd_mq_valid;
  assign m_req_we    = m_sel;
  assign m_req_addr  = m_sel ? wr_mq_addr : rd_mq_addr;
  assign m_req_size  = SZW'(2);
  assign m_req_wdata = {{(DATA_WIDTH-DATA_W){1'b0}}, wr_mq_data};
  assign m_req_be    = {{(W-4){1'b0}}, 4'hF};
  assign m_req_id    = {{(MM_IDW-1){1'b0}}, m_sel};
  wire [DOM_W-1:0] m_dom = m_sel ? wr_gq_dom : rd_gq_dom;
  assign m_req_prot  = {SECURE_MASK[m_dom[3:0]], 1'b0};
  assign rd_mq_ready = m_req_ready && !m_sel && rd_mq_valid;
  assign wr_mq_ready = m_req_ready &&  m_sel && wr_mq_valid;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin m_lock_q <= 1'b0; m_last_q <= 1'b0; end
    else if (sclr) m_lock_q <= 1'b0;
    else if (m_req_valid) begin
      m_last_q <= m_sel;
      m_lock_q <= !m_req_ready;
    end
  end
  assign m_rsp_ready = 1'b1;
  assign rd_mr_valid = m_rsp_valid && !m_rsp_we;
  assign wr_mr_valid = m_rsp_valid &&  m_rsp_we;
endmodule
`default_nettype wire
