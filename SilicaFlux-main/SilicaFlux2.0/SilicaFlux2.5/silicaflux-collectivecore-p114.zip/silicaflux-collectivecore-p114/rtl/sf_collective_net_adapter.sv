// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_net_adapter -- remote participant adapter (streaming transport)
//
// The core's stream protocol is exactly-once and in order.  A network is not.  This adapter sits between a TRANSPORT beat
// interface (below) and ONE participant port of sf_collective_core and turns the second into the first.
// (The repository contains no RDMAEngine, docs/00_AUDIT.md; this transport contract is what such an engine would have to
//  present: one 32-bit element per beat tagged with a transfer id and a sequence number.  Nothing here claims RDMA semantics.)
//
// RX  transport -> core input stream
//   * transfer id = collective id (serial-number order, as everywhere); sequence number = element index.
//   * one transfer at a time per link.  A beat of a LATER transfer waits (rx_ready = 0); a beat of an EARLIER / already finished
//     transfer is a stale retransmission: consumed and counted (ev_stale).
//   * reorder window of WIN elements (power of two): seq in [exp, exp+WIN) is stored in slot seq % WIN, delivered strictly in
//     index order; seq < exp or an occupied slot is a duplicate: consumed, counted (ev_dup), never delivered twice;
//     seq >= exp+WIN waits (rx_ready = 0) -- window flow control.
//   * an rx_err beat (peer declares the transfer failed) is passed on as an error beat (the core reports E_PEER).
//   * link watchdog: while a transfer is open and the NEXT element is missing (the adapter is waiting for the network, not
//     for the core), cfg_timeout cycles without any beat arriving -> st_timeout, link FAILED.  link_down does the same at once.  A failed link drives fail_out (the core's
//     part_fail[p]) until ctl_clear; its RX consumes and drops everything, its TX holds.  A beat on offer to the core is never
//     withdrawn: failure waits until it has been taken.
// TX  core output port -> transport
//   * beats pass through with transfer id / sequence number = the core's cid / idx; credit-based flow control
//     (CREDITS outstanding beats; the remote returns credits with tx_credit).
// ACK completion propagation: every completion record of the core (cpl_hs) is forwarded to the peer as an ack message
//   {cid, ok, err, blamed} where blamed = this participant is named in the record's masks.  Bounded queue (ACK_DEPTH); an
//   overflow is counted (ev_ack_lost), never silent.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_net_adapter
  import sf_collective_pkg::*;
#(
  parameter int PID       = 1,
  parameter int WIN       = 8,          // reorder window (power of two)
  parameter int CREDITS   = 8,
  parameter int ACK_DEPTH = 4
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                sclr,
  input  wire logic [31:0]         cfg_timeout,
  input  wire logic                ctl_clear,
  input  wire logic                link_down,
  // ---- transport RX
  input  wire logic                rx_valid,
  output logic                     rx_ready,
  input  wire logic [CID_W-1:0]    rx_xfer,
  input  wire logic [IDX_W-1:0]    rx_seq,
  input  wire logic [1:0]          rx_dtype,
  input  wire logic [2:0]          rx_op,
  input  wire logic [DATA_W-1:0]   rx_data,
  input  wire logic                rx_last,
  input  wire logic                rx_err,
  // ---- to the core's participant input
  output logic                     s_valid,
  input  wire logic                s_ready,
  output logic [CID_W-1:0]         s_cid,
  output logic [PID_W-1:0]         s_pid,
  output logic [IDX_W-1:0]         s_idx,
  output logic [1:0]               s_dtype,
  output logic [2:0]               s_op,
  output logic [DATA_W-1:0]        s_data,
  output logic                     s_last,
  output logic                     s_err,
  // ---- from the core's participant output
  input  wire logic                o_valid,
  output logic                     o_ready,
  input  wire logic [CID_W-1:0]    o_cid,
  input  wire logic [IDX_W-1:0]    o_idx,
  input  wire logic [1:0]          o_dtype,
  input  wire logic [2:0]          o_op,
  input  wire logic [DATA_W-1:0]   o_data,
  input  wire logic                o_last,
  input  wire logic                o_err,
  // ---- transport TX
  output logic                     tx_valid,
  input  wire logic                tx_ready,
  output logic [CID_W-1:0]         tx_xfer,
  output logic [IDX_W-1:0]         tx_seq,
  output logic [1:0]               tx_dtype,
  output logic [2:0]               tx_op,
  output logic [DATA_W-1:0]        tx_data,
  output logic                     tx_last,
  output logic                     tx_err,
  input  wire logic                tx_credit,
  // ---- completion snoop (core completion port handshake) and ack message
  input  wire logic                cpl_hs,
  input  wire logic [CID_W-1:0]    cpl_cid,
  input  wire logic                cpl_ok,
  input  wire logic [3:0]          cpl_err,
  input  wire logic                cpl_blame,
  output logic                     ack_valid,
  input  wire logic                ack_ready,
  output logic [CID_W-1:0]         ack_cid,
  output logic                     ack_ok,
  output logic [3:0]               ack_err,
  output logic                     ack_blamed,
  // ---- status
  output logic                     fail_out,
  output logic                     st_timeout,
  output logic                     st_down,
  output logic                     ev_rx,
  output logic                     ev_tx,
  output logic                     ev_dup,
  output logic                     ev_stale,
  output logic                     ev_reorder,
  output logic                     ev_cred_stall,
  output logic                     ev_ack_lost
);
  localparam int WB = $clog2(WIN);

  logic              cur_open, have_done, failed, pres_q;
  logic [CID_W-1:0]  cur_xfer, done_xfer;
  logic [IDX_W-1:0]  exp_seq;
  logic [WIN-1:0]    slot_v, slot_l;
  logic [DATA_W-1:0] slot_d [WIN];
  logic [1:0]        slot_dt [WIN];
  logic [2:0]        slot_op [WIN];
  logic              eb_pend;               // error beat to hand to the core
  logic [CID_W-1:0]  eb_cid;
  logic [IDX_W-1:0]  eb_idx;
  logic [31:0]       idle_cnt;

  wire [WB-1:0] exp_slot = exp_seq[WB-1:0];
  wire          head_v   = cur_open && slot_v[exp_slot];

  // ------------------------------------------------------------ RX classification
  wire              same_x   = cur_open && (rx_xfer == cur_xfer);
  wire              later_x  = cur_open && !same_x && cid_after(rx_xfer, cur_xfer);
  wire              stale_x  = cur_open ? (!same_x && !later_x)
                                        : (have_done && !cid_after(rx_xfer, done_xfer));
  wire [IDX_W-1:0]  dseq     = rx_seq - exp_seq;
  wire              seq_old  = same_x && (rx_seq < exp_seq);
  wire              seq_far  = same_x && !seq_old && (dseq >= IDX_W'(WIN));
  wire              seq_dup  = same_x && !seq_old && !seq_far && slot_v[rx_seq[WB-1:0]];
  wire              opens    = !cur_open && !stale_x;
  // open + store in one step: for an opening beat the window is [0, WIN) with exp_seq == 0
  wire              seq_ok_open = opens && (rx_seq < IDX_W'(WIN));

  logic accept_store, accept_err, drop_stale, drop_dup, drop_failed;
  always_comb begin
    rx_ready = 1'b1; accept_store = 1'b0; accept_err = 1'b0; drop_stale = 1'b0; drop_dup = 1'b0; drop_failed = 1'b0;
    if (failed) begin
      drop_failed = rx_valid;
    end else if (later_x) begin
      rx_ready = 1'b0;
    end else if (stale_x) begin
      drop_stale = rx_valid;
    end else if (rx_err) begin
      accept_err = rx_valid && !eb_pend && !s_valid;      // never discard a beat that is on offer to the core
      rx_ready   = !eb_pend && !s_valid;
    end else if (opens) begin
      if (seq_ok_open) accept_store = rx_valid; else rx_ready = 1'b0;
    end else if (seq_old || seq_dup) begin
      drop_dup = rx_valid;
    end else if (seq_far) begin
      rx_ready = 1'b0;
    end else begin
      accept_store = rx_valid;
    end
  end
  wire rx_hs = rx_valid && rx_ready;

  // ------------------------------------------------------------ delivery to the core
  wire present = (head_v || eb_pend) && (!failed || pres_q);
  assign s_valid = present;
  assign s_pid   = PID_W'(PID);
  always_comb begin
    s_cid = cur_xfer; s_idx = exp_seq; s_dtype = slot_dt[exp_slot]; s_op = slot_op[exp_slot];
    s_data = slot_d[exp_slot]; s_last = slot_l[exp_slot]; s_err = 1'b0;
    if (eb_pend && !head_v) begin s_cid = eb_cid; s_idx = eb_idx; s_dtype = '0; s_op = '0; s_data = '0; s_last = 1'b1; s_err = 1'b1; end
  end
  wire deliver = s_valid && s_ready;

  // ------------------------------------------------------------ watchdog / failure
  wire progress = rx_hs || deliver;
  wire to_hit   = (cfg_timeout != 32'd0) && cur_open && (idle_cnt >= cfg_timeout);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cur_open <= 1'b0; have_done <= 1'b0; failed <= 1'b0; pres_q <= 1'b0;
      cur_xfer <= '0; done_xfer <= '0; exp_seq <= '0; slot_v <= '0; slot_l <= '0;
      eb_pend <= 1'b0; eb_cid <= '0; eb_idx <= '0; idle_cnt <= '0; st_timeout <= 1'b0; st_down <= 1'b0;
    end else if (sclr) begin
      cur_open <= 1'b0; have_done <= 1'b0; failed <= 1'b0; pres_q <= 1'b0; exp_seq <= '0; slot_v <= '0; eb_pend <= 1'b0;
      idle_cnt <= '0; st_timeout <= 1'b0; st_down <= 1'b0;
    end else begin
      pres_q <= s_valid && !s_ready;
      if (progress || !cur_open || head_v) idle_cnt <= '0; else if (idle_cnt != 32'hFFFF_FFFF) idle_cnt <= idle_cnt + 1'b1;
      // failure entry
      if (link_down) begin failed <= 1'b1; st_down <= 1'b1; end
      if (to_hit)    begin failed <= 1'b1; st_timeout <= 1'b1; end
      if (ctl_clear) begin failed <= 1'b0; st_timeout <= 1'b0; st_down <= 1'b0; end
      // a failed link forgets its transfer once nothing is on offer; later beats of it are stale
      if (failed && !pres_q && !s_valid) begin
        if (cur_open) begin have_done <= 1'b1; done_xfer <= cur_xfer; end
        cur_open <= 1'b0; slot_v <= '0; exp_seq <= '0; eb_pend <= 1'b0;
      end else begin
        // accept a beat
        if (accept_store) begin
          if (opens) begin cur_open <= 1'b1; cur_xfer <= rx_xfer; exp_seq <= '0; end
          slot_v[rx_seq[WB-1:0]]  <= 1'b1;
          slot_l[rx_seq[WB-1:0]]  <= rx_last;
          slot_d[rx_seq[WB-1:0]]  <= rx_data;
          slot_dt[rx_seq[WB-1:0]] <= rx_dtype;
          slot_op[rx_seq[WB-1:0]] <= rx_op;
        end
        if (accept_err) begin
          eb_pend <= 1'b1; eb_cid <= rx_xfer; eb_idx <= opens ? '0 : exp_seq;
          if (opens) begin cur_open <= 1'b1; cur_xfer <= rx_xfer; exp_seq <= '0; end
          slot_v <= '0;                                        // nothing after an error beat is delivered
        end
        // deliver
        if (deliver) begin
          if (eb_pend && !head_v) begin
            eb_pend <= 1'b0; cur_open <= 1'b0; have_done <= 1'b1; done_xfer <= eb_cid; exp_seq <= '0; slot_v <= '0;
          end else begin
            slot_v[exp_slot] <= 1'b0;
            exp_seq <= exp_seq + 1'b1;
            if (slot_l[exp_slot]) begin
              cur_open <= 1'b0; have_done <= 1'b1; done_xfer <= cur_xfer; exp_seq <= '0; slot_v <= '0;
            end
          end
        end
      end
    end
  end
  assign fail_out = failed;

  // ------------------------------------------------------------ TX with credits
  logic [$clog2(CREDITS+1)-1:0] cred_q;
  wire tx_go = o_valid && (cred_q != '0) && !failed;
  assign tx_valid = tx_go;
  assign o_ready  = tx_go && tx_ready;
  assign tx_xfer = o_cid; assign tx_seq = o_idx; assign tx_dtype = o_dtype; assign tx_op = o_op;
  assign tx_data = o_data; assign tx_last = o_last; assign tx_err = o_err;
  wire tx_hs = tx_valid && tx_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)      cred_q <= ($clog2(CREDITS+1))'(CREDITS);
    else if (sclr)   cred_q <= ($clog2(CREDITS+1))'(CREDITS);
    else begin
      if (tx_credit && !tx_hs && cred_q != ($clog2(CREDITS+1))'(CREDITS)) cred_q <= cred_q + 1'b1;
      else if (!tx_credit && tx_hs) cred_q <= cred_q - 1'b1;
    end
  end

  // ------------------------------------------------------------ completion propagation
  logic ak_in_ready;
  logic [$clog2(ACK_DEPTH+1)-1:0] ak_level;
  sfd_fifo #(.WIDTH(CID_W + 1 + 4 + 1), .DEPTH(ACK_DEPTH)) u_ack (
    .clk(clk), .rst_n(rst_n), .flush(sclr),
    .in_valid(cpl_hs), .in_ready(ak_in_ready), .in_data({cpl_blame, cpl_err, cpl_ok, cpl_cid}),
    .out_valid(ack_valid), .out_ready(ack_ready), .out_data({ack_blamed, ack_err, ack_ok, ack_cid}), .level(ak_level)
  );
  assign ev_ack_lost = cpl_hs && !ak_in_ready;

  // ------------------------------------------------------------ events
  assign ev_rx         = rx_hs && (accept_store || accept_err);
  assign ev_tx         = tx_hs;
  assign ev_dup        = drop_dup;
  assign ev_stale      = drop_stale || drop_failed;          // stale retransmissions, and everything a failed link drops
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ak = |ak_level;
  /* verilator lint_on UNUSEDSIGNAL */
  assign ev_reorder    = accept_store && !opens && (rx_seq != exp_seq);
  assign ev_cred_stall = o_valid && (cred_q == '0);
endmodule
`default_nettype wire
