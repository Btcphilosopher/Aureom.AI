// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_perf -- performance counter bank
//
// PC_N counters of CNT_W bits (saturating), read through an index (sel -> data, 64 bit, zero-extended).  The core feeds
// the per-cycle events; the bank applies each counter's kind:  ADD  c += inc    MAX  c = max(c, inc)    SET  c = inc when inc != 0.
// Counters are cleared by `clear` (a pulse) and are NOT reset by the core's soft reset, so they can be read after a fault.
// Reads are not atomic with respect to counting: read when the core is idle (the benches do).
// Derived metrics are computed in software (benchmarks/REPORT.md), never in hardware:
//   elements per cycle        = ELEMS / ACTIVE            compute utilisation = ELEMS / ACTIVE (1 element/cycle peak)
//   bytes moved               = 4 * (BEATS_IN + BEATS_OUT)   effective throughput [B/cycle] = 4*BEATS_OUT / ACTIVE
//   mean latency              = LAT_SUM / (COLL_OK + COLL_ERR)    network stall share = STARVE / ACTIVE
//   mean input occupancy      = IN_OCC_SUM / ACTIVE       mean participant imbalance = IMB_SUM / ACTIVE
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_perf
  import sf_collective_pkg::*;
#(
  parameter int CNT_W = 48
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clear,
  input  wire logic              ev_active,
  input  wire logic              ev_fire,
  input  wire logic [4:0]        n_beats_in,
  input  wire logic [4:0]        n_beats_out,
  input  wire logic              ev_starve,
  input  wire logic              ev_stall,
  input  wire logic              ev_block,
  input  wire logic              ev_cpl_ok,
  input  wire logic              ev_cpl_err,
  input  wire logic [31:0]       cpl_cycles,
  input  wire logic              ev_reject,
  input  wire logic [4:0]        n_stale,
  input  wire logic [4:0]        n_perr,
  input  wire logic [4:0]        n_tlost,
  input  wire logic [15:0]       occ_in,
  input  wire logic [15:0]       occ_out,
  input  wire logic [IDX_W:0]    imb,
  input  wire logic [5:0]        sel,
  output logic [63:0]            data
);
  logic [CNT_W-1:0] c [PC_N];
  logic [31:0]      inc [PC_N];

  localparam logic [PC_N-1:0] MAXK = (PC_N'(1) << PC_LAT_MAX) | (PC_N'(1) << PC_IN_OCC_MAX) |
                                     (PC_N'(1) << PC_OUT_OCC_MAX) | (PC_N'(1) << PC_IMB_MAX);
  localparam logic [PC_N-1:0] SETK = (PC_N'(1) << PC_LAT_LAST);

  always_comb begin
    for (int i = 0; i < PC_N; i++) inc[i] = 32'd0;
    inc[PC_CYCLES]      = 32'd1;
    inc[PC_ACTIVE]      = {31'd0, ev_active};
    inc[PC_ELEMS]       = {31'd0, ev_fire};
    inc[PC_BEATS_IN]    = {27'd0, n_beats_in};
    inc[PC_BEATS_OUT]   = {27'd0, n_beats_out};
    inc[PC_STARVE]      = {31'd0, ev_starve};
    inc[PC_OUT_STALL]   = {31'd0, ev_stall};
    inc[PC_FORK_BLOCK]  = {31'd0, ev_block};
    inc[PC_COLL_OK]     = {31'd0, ev_cpl_ok};
    inc[PC_COLL_ERR]    = {31'd0, ev_cpl_err};
    inc[PC_CMD_REJECT]  = {31'd0, ev_reject};
    inc[PC_LAT_SUM]     = (ev_cpl_ok || ev_cpl_err) ? cpl_cycles : 32'd0;
    inc[PC_LAT_MAX]     = (ev_cpl_ok || ev_cpl_err) ? cpl_cycles : 32'd0;
    inc[PC_LAT_LAST]    = (ev_cpl_ok || ev_cpl_err) ? cpl_cycles : 32'd0;
    inc[PC_IN_OCC_SUM]  = ev_active ? {16'd0, occ_in}  : 32'd0;
    inc[PC_IN_OCC_MAX]  = ev_active ? {16'd0, occ_in}  : 32'd0;
    inc[PC_OUT_OCC_SUM] = ev_active ? {16'd0, occ_out} : 32'd0;
    inc[PC_OUT_OCC_MAX] = ev_active ? {16'd0, occ_out} : 32'd0;
    inc[PC_IMB_MAX]     = ev_active ? 32'(imb) : 32'd0;
    inc[PC_IMB_SUM]     = ev_active ? 32'(imb) : 32'd0;
    inc[PC_STALE]       = {27'd0, n_stale};
    inc[PC_PROTO_ERR]   = {27'd0, n_perr};
    inc[PC_TERM_LOST]   = {27'd0, n_tlost};
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < PC_N; i++) c[i] <= '0;
    end else if (clear) begin
      for (int i = 0; i < PC_N; i++) c[i] <= '0;
    end else begin
      for (int i = 0; i < PC_N; i++) begin
        logic [CNT_W:0] s;
        s = {1'b0, c[i]} + {{(CNT_W-31){1'b0}}, inc[i]};
        if (MAXK[i]) begin
          if ({{(CNT_W-32){1'b0}}, inc[i]} > c[i]) c[i] <= {{(CNT_W-32){1'b0}}, inc[i]};
        end else if (SETK[i]) begin
          if (inc[i] != 32'd0) c[i] <= {{(CNT_W-32){1'b0}}, inc[i]};
        end else begin
          c[i] <= s[CNT_W] ? {CNT_W{1'b1}} : s[CNT_W-1:0];
        end
      end
    end
  end

  always_comb begin
    data = 64'd0;
    for (int i = 0; i < PC_N; i++) if (sel == 6'(i)) data = 64'(c[i]);
  end
endmodule
`default_nettype wire
