// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_mem_wr -- local participant, STORE engine (result stream -> memory)
//
// One store descriptor = destination buffer (`iova`, `len` 32-bit elements, `dom`) for the result stream of collective `cid` at this
// participant.  Same validation and protection as the load engine (alignment, length / no wrap, per-4-KiB-burst MemoryGuard grant,
// physical address only from the guard, aperture check).  Result beats are written one 32-bit element each (byte enables 0xF).
// If the descriptor is refused (alignment, length, guard, aperture) the engine DISCARDS the rest of that result stream (so the
// core still completes and later collectives are not blocked) and reports the cause; nothing is written for refused bursts.
// A stream error (terminator beat, wrong index) stops the writes and reports M_STREAM: elements stored before it are correct
// prefix elements of the result and may be present in memory; the record says the buffer is NOT valid.
// Completion ordering: the completion record is issued only after EVERY write response has come back (acknowledged writes).
// Beats of another collective are never consumed (they belong to another descriptor) and never written.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_mem_wr
  import sf_collective_pkg::*;
#(
  parameter int AW      = 32,
  parameter int MM_AW   = 20,
  parameter int DOM_W   = 4,
  parameter int MAX_LEN = 4096,
  parameter int MAXOUT  = 4,
  parameter logic [3:0] MEMTYPE = 4'd4
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 sclr,
  // ---- store descriptor / completion
  input  wire logic                 st_valid,
  output logic                      st_ready,
  input  wire logic [CID_W-1:0]     st_cid,
  input  wire logic [AW-1:0]        st_iova,
  input  wire logic [LEN_W-1:0]     st_len,
  input  wire logic [DOM_W-1:0]     st_dom,
  output logic                      cpl_valid,
  input  wire logic                 cpl_ready,
  output logic [CID_W-1:0]          cpl_cid,
  output logic [2:0]                cpl_err,
  // ---- result stream from the core
  input  wire logic                 o_valid,
  output logic                      o_ready,
  input  wire logic [CID_W-1:0]     o_cid,
  input  wire logic [IDX_W-1:0]     o_idx,
  input  wire logic [DATA_W-1:0]    o_data,
  input  wire logic                 o_last,
  input  wire logic                 o_err,
  // ---- guard (engine side)
  output logic                      gq_valid,
  input  wire logic                 gq_ready,
  output logic [DOM_W-1:0]          gq_dom,
  output logic [3:0]                gq_asid,
  output logic [AW-1:0]             gq_addr,
  output logic [15:0]               gq_bytes,
  input  wire logic                 gr_valid,
  output logic                      gr_ready,
  input  wire logic                 gr_ok,
  input  wire logic [AW-1:0]        gr_pa,
  // ---- memory write port (engine side)
  output logic                      mq_valid,
  input  wire logic                 mq_ready,
  output logic [MM_AW-1:0]          mq_addr,
  output logic [DATA_W-1:0]         mq_data,
  input  wire logic                 mr_valid,
  input  wire logic                 mr_err,
  // ---- events
  output logic                      ev_elem,
  output logic                      ev_busy
);
  typedef enum logic [2:0] {S_IDLE, S_GREQ, S_GWAIT, S_STREAM, S_DISCARD, S_FINISH, S_CPL} st_t;
  st_t st_q;
  logic [CID_W-1:0] cid_q; logic [DOM_W-1:0] dom_q; logic [AW-1:0] iova_q;
  logic [LEN_W-1:0] rem_q, bel_q, exp_q;
  logic [MM_AW-1:0] pa_q;
  logic [7:0]       outst_q;
  logic [2:0]       code_q;
  logic [AW-1:0]    burst_bytes_w;

  wire [AW+LEN_W+2:0] end_w   = {{(LEN_W+3){1'b0}}, st_iova} + {{(AW+1){1'b0}}, st_len, 2'b00};
  wire                misal   = (st_iova[1:0] != 2'b00);
  wire                toolong = (st_len > LEN_W'(MAX_LEN)) || (end_w > (({{(AW+LEN_W+2){1'b0}}, 1'b1}) << AW));

  wire [12:0]      to_page  = 13'd4096 - {1'b0, iova_q[11:0]};
  wire [LEN_W+1:0] rem_bytes = {rem_q, 2'b00};
  wire [LEN_W+1:0] page_b    = (LEN_W+2)'(to_page);
  wire [15:0]      burst_b   = (rem_bytes < page_b) ? 16'(rem_bytes) : 16'(to_page);
  wire [LEN_W-1:0] burst_el  = LEN_W'(burst_b[15:2]);
  assign burst_bytes_w = AW'(burst_b);

  assign gq_valid = (st_q == S_GREQ);
  assign gq_dom = dom_q; assign gq_asid = MEMTYPE; assign gq_addr = iova_q; assign gq_bytes = burst_b;
  assign gr_ready = (st_q == S_GWAIT);
  wire [AW:0] pa_end = {1'b0, gr_pa} + {1'b0, burst_bytes_w};
  wire pa_in_ap = (gr_pa >> MM_AW) == '0 && (pa_end <= ((AW+1)'(1) << MM_AW));

  // beat qualification
  wire same_cid = (o_cid == cid_q);
  wire good     = o_valid && same_cid && !o_err && (LEN_W'(o_idx) == exp_q);
  wire is_err   = o_valid && same_cid && o_err;
  wire bad_idx  = o_valid && same_cid && !o_err && (LEN_W'(o_idx) != exp_q);

  assign mq_valid = (st_q == S_STREAM) && good && (outst_q < 8'(MAXOUT));
  assign mq_addr  = pa_q;
  assign mq_data  = o_data;
  wire issue = mq_valid && mq_ready;
  always_comb begin
    o_ready = 1'b0;
    if (st_q == S_STREAM)       o_ready = (good && mq_valid && mq_ready) || is_err || bad_idx;
    else if (st_q == S_DISCARD) o_ready = o_valid && same_cid;
  end
  wire beat_hs = o_valid && o_ready;

  assign st_ready  = (st_q == S_IDLE);
  assign cpl_valid = (st_q == S_CPL);
  assign cpl_cid   = cid_q;
  assign cpl_err   = code_q;
  assign ev_elem   = issue;
  assign ev_busy   = (st_q != S_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE; cid_q <= '0; dom_q <= '0; iova_q <= '0; rem_q <= '0; bel_q <= '0; exp_q <= '0; pa_q <= '0;
      outst_q <= '0; code_q <= M_OK;
    end else if (sclr) begin
      st_q <= S_IDLE; outst_q <= '0;
    end else begin
      if (issue && !mr_valid) outst_q <= outst_q + 1'b1;
      else if (!issue && mr_valid) outst_q <= outst_q - 1'b1;
      if (mr_valid && mr_err && code_q == M_OK) code_q <= M_BUS;
      case (st_q)
        S_IDLE: if (st_valid) begin
          cid_q <= st_cid; dom_q <= st_dom; iova_q <= st_iova; rem_q <= st_len; exp_q <= '0; outst_q <= '0; code_q <= M_OK;
          if (misal)             begin code_q <= M_ALIGN; st_q <= S_DISCARD; end
          else if (toolong)      begin code_q <= M_LEN;   st_q <= S_DISCARD; end
          else if (st_len == '0) st_q <= S_CPL;
          else                   st_q <= S_GREQ;
        end
        S_GREQ: if (gq_ready) st_q <= S_GWAIT;
        S_GWAIT: if (gr_valid) begin
          if (!gr_ok)         begin code_q <= M_PERM; st_q <= S_DISCARD; end
          else if (!pa_in_ap) begin code_q <= M_BUS;  st_q <= S_DISCARD; end
          else begin pa_q <= gr_pa[MM_AW-1:0]; bel_q <= burst_el; st_q <= S_STREAM; end
        end
        S_STREAM: begin
          if (issue) begin
            exp_q <= exp_q + 1'b1; bel_q <= bel_q - 1'b1; pa_q <= pa_q + MM_AW'(4);
            if (bel_q == 1) begin
              rem_q <= rem_q - burst_el; iova_q <= iova_q + burst_bytes_w;
              st_q  <= (rem_q == burst_el) ? S_FINISH : S_GREQ;
            end
          end else if (is_err || bad_idx) begin
            if (code_q == M_OK || code_q == M_BUS) code_q <= M_STREAM;
            st_q <= S_FINISH;
          end
        end
        S_DISCARD: if (beat_hs && (o_last || o_err)) st_q <= S_FINISH;
        S_FINISH:  if (outst_q == '0 && !mr_valid) st_q <= S_CPL;
        S_CPL:     if (cpl_ready) st_q <= S_IDLE;
        default:   st_q <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
