// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_scheduler
//
// Operation scheduler.  ONE collective runs at a time (documented limit); commands run strictly in submission order.
//
//   S_IDLE  pop the next command.  Rejected command -> S_CPL (error record).  len == 0 -> S_CPL (OK, nothing moves).
//           Otherwise latch the command, derive the lengths, update the ID reference -> S_RUN.
//   S_RUN   the datapath runs.  Leaves S_RUN when (a) the reduction is done AND every destination has accepted every beat
//           -> S_CPL (OK), or (b) a failure is detected -> S_FLUSH.   Success wins over a failure in the same cycle.
//   S_FLUSH `run` is low, so adapters, reduction and output buffers clear; FP pipelines drain (reduction `busy`).  -> S_CPL
//           (or -> S_IDLE for a soft reset, which produces no record).
//   S_CPL   push exactly one completion record (waits while the completion buffer is full) -> S_IDLE.
//
// Failure causes, in priority order when several arrive in the same cycle:
//   E_ABORT > protocol error from a stream adapter (lowest participant first, `down` last) > E_PART_FAIL > E_TIMEOUT.
// A failed collective NEVER reports success and never leaves partial state behind: everything is cleared, the receivers
// that were still owed data get an error terminator beat (sf_collective_output), and later collectives start clean.
//
// Watchdog: cfg_timeout cycles in S_RUN without any progress (a stream element accepted, an element reduced, a beat delivered)
// -> E_TIMEOUT.  0 disables it.  maskA = senders (parent link: bit 8) that still owe elements AND have an empty input buffer (= the ones the engine is waiting for; a sender that is merely back-pressured is not blamed), maskB = destinations
// (up port = bit 8) that still owe deliveries.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_scheduler
  import sf_collective_pkg::*;
#(
  parameter int NP           = 2,
  parameter bit INTERIOR     = 1'b0,
  parameter bit REDSCAT_EN   = 1'b0,
  parameter bit ALLGATHER_EN = 1'b0
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 sclr,
  // ---- command queue
  input  wire logic                 q_valid,
  output logic                      q_pop,
  input  wire logic [CMD_W-1:0]     q_cmd,
  input  wire logic [3:0]           q_err,
  // ---- control
  input  wire logic [31:0]          cfg_timeout,
  input  wire logic                 ctl_abort,
  input  wire logic [NP-1:0]        part_fail,
  // ---- context for the datapath
  output logic                      run,
  output logic                      idle,
  output logic                      ref_valid,
  output logic [CID_W-1:0]          ref_cid,
  output logic [2:0]                act_ctype,
  output logic [2:0]                act_op,
  output logic [1:0]                act_dtype,
  output logic [2:0]                act_rm,
  output logic [NP-1:0]             act_send,
  output logic [NP-1:0]             act_recv,
  output logic [LEN_W-1:0]          act_len,
  output logic                      act_gather,
  output logic                      act_redscat,
  output logic [LEN_W-1:0]          res_len,
  output logic [LEN_W-1:0]          out_len,
  output logic                      up_en,
  output logic                      down_en,
  output logic                      fail_pulse,
  // ---- from the datapath
  input  wire logic [NP-1:0]        in_err_pulse,
  input  wire logic [NP*4-1:0]      in_err_code,
  input  wire logic                 dn_err_pulse,
  input  wire logic [3:0]           dn_err_code,
  input  wire logic [NP-1:0]        in_done,
  input  wire logic [NP-1:0]        in_hvalid,       // input buffer of participant p holds an element
  input  wire logic                 dn_done,
  input  wire logic                 dn_hvalid,
  input  wire logic                 red_done,
  input  wire logic [5:0]           red_flags,
  input  wire logic                 red_busy,
  input  wire logic                 out_done,
  input  wire logic [NP:0]          pend_mask,
  input  wire logic                 progress,
  // ---- completion record
  output logic                      cpl_push,
  input  wire logic                 cpl_full,
  output logic [CID_W-1:0]          cpl_cid,
  output logic                      cpl_ok,
  output logic [3:0]                cpl_err,
  output logic [2:0]                cpl_ctype,
  output logic [5:0]                cpl_flags,
  output logic [8:0]                cpl_maskA,
  output logic [8:0]                cpl_maskB,
  output logic [LEN_W-1:0]          cpl_len,
  output logic [31:0]               cpl_cycles,
  // ---- events
  output logic                      ev_cpl_ok,
  output logic                      ev_cpl_err
);
  typedef enum logic [1:0] {S_IDLE = 2'd0, S_RUN = 2'd1, S_FLUSH = 2'd2, S_CPL = 2'd3} state_t;
  state_t state_q;

  logic [CMD_W-1:0] cmd_q;
  logic [3:0]       err_q;
  logic [8:0]       maskA_q, maskB_q;
  logic [5:0]       flags_q;
  logic [31:0]      lat_q, wd_q;
  logic             soft_q;                 // the FLUSH in progress came from a soft reset: no record
  logic [LEN_W-1:0] res_len_q, out_len_q;

  // ---- decode of the latched command
  wire [2:0]  c_ct = cmd_ctype(cmd_q);
  /* verilator lint_off UNUSEDSIGNAL */
  wire [7:0]    c_send8 = cmd_send(cmd_q);
  wire [7:0]    c_recv8 = cmd_recv(cmd_q);
  /* verilator lint_on UNUSEDSIGNAL */
  wire [NP-1:0] c_send  = c_send8[NP-1:0];
  wire [NP-1:0] c_recv  = c_recv8[NP-1:0];
  assign act_ctype   = c_ct;
  assign act_op      = cmd_op(cmd_q);
  assign act_dtype   = cmd_dt(cmd_q);
  assign act_rm      = cmd_rm(cmd_q);
  assign act_send    = c_send;
  assign act_recv    = c_recv;
  assign act_len     = cmd_len(cmd_q);
  assign act_gather  = ALLGATHER_EN && (c_ct == CT_ALLGATHER);
  assign act_redscat = REDSCAT_EN   && (c_ct == CT_REDSCAT);
  assign up_en       = INTERIOR && (c_send != '0);
  assign down_en     = INTERIOR && (c_recv != '0);
  assign res_len     = res_len_q;
  assign out_len     = out_len_q;
  assign run         = (state_q == S_RUN);
  assign idle        = (state_q == S_IDLE);

  // ---- derived lengths computed from the command being popped
  wire [LEN_W-1:0] q_len   = cmd_len(q_cmd);
  wire [3:0]       q_ns    = popcnt8(cmd_send(q_cmd));
  wire [3:0]       q_nr    = popcnt8(cmd_recv(q_cmd));
  wire [2:0]       q_ct    = cmd_ctype(q_cmd);
  logic [LEN_W-1:0] n_res, n_out;
  always_comb begin
    n_res = q_len;
    n_out = q_len;
    if (ALLGATHER_EN && q_ct == CT_ALLGATHER) begin
      n_res = q_len * LEN_W'(q_ns);
      n_out = q_len * LEN_W'(q_ns);
    end
    if (REDSCAT_EN && q_ct == CT_REDSCAT && q_nr != 4'd0) n_out = q_len / LEN_W'(q_nr);
  end

  // ---- queue handshake
  assign q_pop = (state_q == S_IDLE) && q_valid && !sclr;

  // ---- failure detection (only meaningful in S_RUN)
  wire [NP-1:0] inv       = (c_send & ~in_done) | pend_mask[NP-1:0];
  wire          any_proto = (|in_err_pulse) | dn_err_pulse;
  wire          pf_hit    = |(part_fail & inv);
  wire          to_hit    = (cfg_timeout != 32'd0) && (wd_q >= cfg_timeout);
  wire          red_ok    = (c_send == '0) || red_done;
  wire          done_now  = run && red_ok && out_done;

  logic [3:0] proto_code;
  always_comb begin
    proto_code = dn_err_code;
    for (int i = NP - 1; i >= 0; i--) if (in_err_pulse[i]) proto_code = in_err_code[i*4 +: 4];
  end

  logic [3:0] f_code;
  logic [8:0] f_maskA;
  always_comb begin
    f_code  = E_OK;
    f_maskA = 9'd0;
    if (ctl_abort) begin
      f_code = E_ABORT;
    end else if (any_proto) begin
      f_code = proto_code;
      f_maskA[NP-1:0] = in_err_pulse;
      f_maskA[8]      = dn_err_pulse;
    end else if (pf_hit) begin
      f_code = E_PART_FAIL;
      f_maskA[NP-1:0] = part_fail & inv;
    end else if (to_hit) begin
      f_code = E_TIMEOUT;
      f_maskA[NP-1:0] = c_send & ~in_done & ~in_hvalid;      // the senders the engine is actually waiting for
      f_maskA[8]      = down_en && !dn_done && !dn_hvalid;
    end
  end
  logic [8:0] f_maskB;
  always_comb begin
    f_maskB         = 9'd0;
    f_maskB[NP-1:0] = pend_mask[NP-1:0];
    f_maskB[8]      = pend_mask[NP];
  end
  wire fail_now = run && !done_now && (f_code != E_OK);
  assign fail_pulse = fail_now;

  // ---- completion record
  assign cpl_push   = (state_q == S_CPL) && !cpl_full && !sclr;
  assign cpl_cid    = cmd_cid(cmd_q);
  assign cpl_ok     = (err_q == E_OK);
  assign cpl_err    = err_q;
  assign cpl_ctype  = c_ct;
  assign cpl_flags  = flags_q;
  assign cpl_maskA  = maskA_q;
  assign cpl_maskB  = maskB_q;
  assign cpl_len    = cmd_len(cmd_q);
  assign cpl_cycles = lat_q;
  assign ev_cpl_ok  = cpl_push && (err_q == E_OK);
  assign ev_cpl_err = cpl_push && (err_q != E_OK);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state_q   <= S_IDLE;
      cmd_q     <= '0;
      err_q     <= E_OK;
      maskA_q   <= '0;
      maskB_q   <= '0;
      flags_q   <= '0;
      lat_q     <= '0;
      wd_q      <= '0;
      soft_q    <= 1'b0;
      ref_valid <= 1'b0;
      ref_cid   <= '0;
      res_len_q <= '0;
      out_len_q <= '0;
    end else if (sclr) begin
      state_q   <= S_FLUSH;
      soft_q    <= 1'b1;
      ref_valid <= 1'b0;
      err_q     <= E_OK;
      wd_q      <= '0;
    end else begin
      if (state_q != S_IDLE) lat_q <= lat_q + 1'b1;
      case (state_q)
        S_IDLE: begin
          if (q_valid) begin
            cmd_q     <= q_cmd;
            err_q     <= q_err;
            maskA_q   <= '0;
            maskB_q   <= '0;
            flags_q   <= '0;
            lat_q     <= 32'd1;
            wd_q      <= '0;
            res_len_q <= n_res;
            out_len_q <= n_out;
            if (q_err != E_CMD_CID) begin
              ref_valid <= 1'b1;
              ref_cid   <= cmd_cid(q_cmd);
            end
            if (q_err != E_OK || q_len == '0) state_q <= S_CPL;
            else                              state_q <= S_RUN;
          end
        end
        S_RUN: begin
          if (progress) wd_q <= '0;
          else if (wd_q != 32'hFFFF_FFFF) wd_q <= wd_q + 1'b1;
          flags_q <= red_flags;
          if (done_now) begin
            state_q <= S_CPL;
          end else if (fail_now) begin
            state_q <= S_FLUSH;
            err_q   <= f_code;
            maskA_q <= f_maskA;
            maskB_q <= f_maskB;
          end
        end
        S_FLUSH: begin
          if (!red_busy) begin
            if (soft_q) begin
              soft_q  <= 1'b0;
              state_q <= S_IDLE;
            end else begin
              state_q <= S_CPL;
            end
          end
        end
        S_CPL: begin
          if (!cpl_full) state_q <= S_IDLE;
        end
        default: state_q <= S_IDLE;
      endcase
    end
  end

endmodule
`default_nettype wire
