// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_pkg
//
// Single source of truth for the collective ABI: command layout, stream-beat fields, collective types, reduction
// operators, data types, error codes, collective-ID ordering, command validation and the *semantics* of every
// reduction operator.  docs/02_ABI.md is written from this file; tests/sf_collective_ref.h (the independent software
// reference) is written from docs/02_ABI.md, NOT from this file; scripts/check_abi.py compares the numeric constants.
//
// Reduction semantics (precise, see docs/03_NUMERICS.md):
//   SUM   two's-complement wrap-around modulo 2^32 for INT32 and UINT32 alike (same bits).  The completion flag
//         OVF is raised iff the EXACT (unbounded) sum of an element's contributions is not representable in the
//         data type (signed range for INT32, unsigned range for UINT32).  OVF is order-independent.
//   MIN/MAX  signed comparison for INT32, unsigned comparison for UINT32.  Equal operands are bit-identical.
//   AND/OR/XOR  bitwise, identical for INT32 and UINT32.  Not defined for FP32 (rejected).
//   FP32 SUM  IEEE-754 binary32 addition through the verified fp32_fma (a*1.0 + c), rounding mode from the command,
//         fixed balanced-binary-tree order over participant index (an absent contributor is SKIPPED, never replaced
//         by an identity element).  Canonical NaN 0x7FC00000.  Flags accumulate (OR) into the completion record.
// Classification: SYNTHESIZABLE (package of constants and pure functions)
// =============================================================================
`default_nettype none
package sf_collective_pkg;

  // ---------------------------------------------------------------- geometry
  localparam int MAXP   = 8;      // participants addressable by the ABI (masks are 8 bits)
  localparam int PID_W  = 3;
  localparam int CID_W  = 16;     // collective IDs are 16-bit serial numbers (RFC 1982 style ordering)
  localparam int IDX_W  = 20;     // element-index field of a stream beat
  localparam int LEN_W  = 21;     // command length field (one bit wider than IDX_W)
  localparam int DATA_W = 32;

  // ---------------------------------------------------------------- collective types
  localparam logic [2:0] CT_REDUCE    = 3'd0;  // reduce-to-root: every sender contributes, exactly one receiver gets the result
  localparam logic [2:0] CT_BROADCAST = 3'd1;  // exactly one sender; every receiver gets a bit-exact copy (no arithmetic)
  localparam logic [2:0] CT_ALLREDUCE = 3'd2;  // reduce, then every receiver gets the same result
  localparam logic [2:0] CT_REDSCAT   = 3'd3;  // reduce, then receiver r gets the r-th equal chunk of the result   (build option)
  localparam logic [2:0] CT_ALLGATHER = 3'd4;  // concatenate the senders' vectors in participant order; every receiver gets all (build option)

  // ---------------------------------------------------------------- operators / data types
  localparam logic [2:0] OP_SUM  = 3'd0;
  localparam logic [2:0] OP_MIN  = 3'd1;
  localparam logic [2:0] OP_MAX  = 3'd2;
  localparam logic [2:0] OP_AND  = 3'd3;
  localparam logic [2:0] OP_OR   = 3'd4;
  localparam logic [2:0] OP_XOR  = 3'd5;
  localparam logic [2:0] OP_COPY = 3'd6;       // BROADCAST / ALLGATHER only: data moves, nothing is computed

  localparam logic [1:0] DT_I32  = 2'd0;
  localparam logic [1:0] DT_U32  = 2'd1;
  localparam logic [1:0] DT_F32  = 2'd2;

  // ---------------------------------------------------------------- error codes (completion record, 4 bits)
  localparam logic [3:0] E_OK        = 4'd0;
  localparam logic [3:0] E_CMD_TYPE  = 4'd1;   // collective type unknown / not built / not allowed for this node role
  localparam logic [3:0] E_CMD_OP    = 4'd2;   // operator / data type / rounding mode illegal or not built
  localparam logic [3:0] E_CMD_LEN   = 4'd3;   // length above MAX_LEN, or not divisible where required
  localparam logic [3:0] E_CMD_MASK  = 4'd4;   // participant masks illegal for the type
  localparam logic [3:0] E_CMD_CID   = 4'd5;   // collective ID not strictly after the previous accepted one
  localparam logic [3:0] E_TIMEOUT   = 4'd6;   // no progress for cfg_timeout cycles
  localparam logic [3:0] E_PART_FAIL = 4'd7;   // an involved participant was declared failed
  localparam logic [3:0] E_SEQ       = 4'd8;   // element index gap (an element was skipped)
  localparam logic [3:0] E_DUP       = 4'd9;   // element index repeated (duplicate element)
  localparam logic [3:0] E_HDR       = 4'd10;  // header mismatch: participant id, data type, operation, or non-sender sent data
  localparam logic [3:0] E_LEN       = 4'd11;  // stream longer than the command, or LAST not on the final element
  localparam logic [3:0] E_PEER      = 4'd12;  // a source flagged its beat as erroneous (err bit)
  localparam logic [3:0] E_ABORT     = 4'd13;  // ctl_abort
  localparam logic [3:0] E_INTERNAL  = 4'd14;  // an internal invariant was violated (must never happen; formal + bench check it)

  // ---------------------------------------------------------------- completion flag bits
  //   [4:0] = IEEE exception flags {NV, DZ, OF, UF, NX} exactly as fp32_fma reports them (FP32 SUM only)
  localparam int FL_NX = 0, FL_UF = 1, FL_OF = 2, FL_DZ = 3, FL_NV = 4;
  localparam int FL_INT_OVF = 5;               // exact INT32/UINT32 SUM not representable (wrapped result delivered)

  // ---------------------------------------------------------------- memory-adapter completion codes (sf_collective_mem_*; 3 bits)
  localparam logic [2:0] M_OK     = 3'd0;
  localparam logic [2:0] M_ALIGN  = 3'd1;   // buffer address not 4-byte aligned (elements are 32-bit)
  localparam logic [2:0] M_LEN    = 3'd2;   // length above MAX_LEN, or buffer runs past the end of the address space
  localparam logic [2:0] M_PERM   = 3'd3;   // the guard refused (no mapping / permission / wrong domain / leaves its mapping)
  localparam logic [2:0] M_BUS    = 3'd4;   // the memory answered with an error status, or the physical address left the memory aperture
  localparam logic [2:0] M_STREAM = 3'd5;   // store: the result stream was erroneous (terminator, wrong cid, wrong index)

  // ---------------------------------------------------------------- performance counter map (sf_collective_perf)
  localparam int PC_CYCLES     = 0;   // every clock since clear
  localparam int PC_ACTIVE     = 1;   // cycles a collective was running
  localparam int PC_ELEMS      = 2;   // elements through the reduction / gather datapath (result elements produced)
  localparam int PC_BEATS_IN   = 3;   // stream beats accepted from participants (and the down stream); x4 = bytes
  localparam int PC_BEATS_OUT  = 4;   // stream beats accepted by receivers (and the up port); x4 = bytes
  localparam int PC_STARVE     = 5;   // running cycles with an element still owed by a participant (input / network stall)
  localparam int PC_OUT_STALL  = 6;   // running cycles with a result element blocked at the result stage
  localparam int PC_FORK_BLOCK = 7;   // running cycles with a source element waiting for room in a destination buffer
  localparam int PC_COLL_OK    = 8;
  localparam int PC_COLL_ERR   = 9;
  localparam int PC_CMD_REJECT = 10;
  localparam int PC_LAT_SUM    = 11;  // sum of per-collective latencies (cycles from command pop to completion)
  localparam int PC_LAT_MAX    = 12;
  localparam int PC_LAT_LAST   = 13;
  localparam int PC_IN_OCC_SUM = 14;  // sum over running cycles of the total input-buffer occupancy (elements)
  localparam int PC_IN_OCC_MAX = 15;
  localparam int PC_OUT_OCC_SUM= 16;  // same for the output buffers
  localparam int PC_OUT_OCC_MAX= 17;
  localparam int PC_IMB_MAX    = 18;  // largest observed difference (elements) between the most and least advanced sending participant
  localparam int PC_IMB_SUM    = 19;  // sum over running cycles of that difference
  localparam int PC_STALE      = 20;  // beats discarded as stale
  localparam int PC_PROTO_ERR  = 21;  // stream beats that failed a protocol check
  localparam int PC_TERM_LOST  = 22;  // error terminators that could not be queued (queue full)
  localparam int PC_N          = 23;

  // ---------------------------------------------------------------- command word (CMD_W = 64 bits)
  //   [15:0] cid  [18:16] ctype  [21:19] op  [23:22] dtype  [26:24] rm  [34:27] send_mask  [42:35] recv_mask  [63:43] len
  localparam int CMD_W = 64;
  localparam int C_CID  = 0,  C_CTYPE = 16, C_OP = 19, C_DT = 22, C_RM = 24, C_SEND = 27, C_RECV = 35, C_LEN = 43;

  function automatic logic [CMD_W-1:0] cmd_pack(input logic [15:0] cid, input logic [2:0] ctype, input logic [2:0] op,
                                                input logic [1:0] dt, input logic [2:0] rm,
                                                input logic [7:0] send, input logic [7:0] recv, input logic [LEN_W-1:0] len);
    cmd_pack = {len, recv, send, rm, dt, op, ctype, cid};
  endfunction
  function automatic logic [15:0]       cmd_cid  (input logic [CMD_W-1:0] c); cmd_cid   = c[C_CID  +: 16];    endfunction
  function automatic logic [2:0]        cmd_ctype(input logic [CMD_W-1:0] c); cmd_ctype = c[C_CTYPE +: 3];     endfunction
  function automatic logic [2:0]        cmd_op   (input logic [CMD_W-1:0] c); cmd_op    = c[C_OP    +: 3];     endfunction
  function automatic logic [1:0]        cmd_dt   (input logic [CMD_W-1:0] c); cmd_dt    = c[C_DT    +: 2];     endfunction
  function automatic logic [2:0]        cmd_rm   (input logic [CMD_W-1:0] c); cmd_rm    = c[C_RM    +: 3];     endfunction
  function automatic logic [7:0]        cmd_send (input logic [CMD_W-1:0] c); cmd_send  = c[C_SEND  +: 8];     endfunction
  function automatic logic [7:0]        cmd_recv (input logic [CMD_W-1:0] c); cmd_recv  = c[C_RECV  +: 8];     endfunction
  function automatic logic [LEN_W-1:0]  cmd_len  (input logic [CMD_W-1:0] c); cmd_len   = c[C_LEN   +: LEN_W];  endfunction

  // ---------------------------------------------------------------- helpers
  function automatic logic [3:0] popcnt8(input logic [7:0] m);
    logic [3:0] n;
    n = 4'd0;
    for (int i = 0; i < 8; i++) n = n + {3'd0, m[i]};
    popcnt8 = n;
  endfunction

  // Collective-ID serial-number order (RFC 1982, 16 bit): a is strictly after b iff 0 < (a-b mod 2^16) < 2^15.
  function automatic logic cid_after(input logic [15:0] a, input logic [15:0] b);
    logic [15:0] d;
    d = a - b;
    cid_after = (d != 16'd0) && (d[15] == 1'b0);
  endfunction

  // One reduction step.  Defined for the six integer operators; (a, b) are two contributions of the same element.
  function automatic logic [31:0] red_op(input logic [2:0] op, input logic [1:0] dt, input logic [31:0] a, input logic [31:0] b);
    logic lt;
    lt = (dt == DT_U32) ? (a < b) : ($signed(a) < $signed(b));
    case (op)
      OP_SUM:  red_op = a + b;
      OP_MIN:  red_op = lt ? a : b;
      OP_MAX:  red_op = lt ? b : a;
      OP_AND:  red_op = a & b;
      OP_OR:   red_op = a | b;
      OP_XOR:  red_op = a ^ b;
      default: red_op = a;
    endcase
  endfunction

  // One node of the fixed reduction tree: returns {present, value}.  An ABSENT operand (participant not in the send
  // mask, or a sub-tree without contributors) is skipped: the other operand passes through UNCHANGED.  No identity
  // element is ever added (for FP32 an identity does not exist under every rounding mode, and it would alter NaN payloads).
  function automatic logic [32:0] red_node(input logic [2:0] op, input logic [1:0] dt,
                                           input logic [31:0] a, input logic pa, input logic [31:0] b, input logic pb);
    if (pa && pb)      red_node = {1'b1, red_op(op, dt, a, b)};
    else if (pa)       red_node = {1'b1, a};
    else if (pb)       red_node = {1'b1, b};
    else               red_node = 33'd0;
  endfunction

  // Operator / data-type legality for a given type (rm is checked by cmd_validate).
  function automatic logic op_legal(input logic [2:0] ctype, input logic [2:0] op, input logic [1:0] dt, input logic fp32_en);
    logic is_copy_type;
    is_copy_type = (ctype == CT_BROADCAST) || (ctype == CT_ALLGATHER);
    if (dt > DT_F32) op_legal = 1'b0;
    else if (is_copy_type) op_legal = (op == OP_COPY);                                   // data movement: any 32-bit type
    else if (op > OP_XOR) op_legal = 1'b0;
    else if (dt == DT_F32) op_legal = fp32_en && (op == OP_SUM);                         // FP32: SUM only
    else op_legal = 1'b1;
  endfunction

  // Command validation.  `np` participants, `max_len` elements, build options.  Returns E_OK or the first failing rule.
  // `interior` = this node is an interior node of a reduction tree (it has up/down ports).  Rules:
  //   root node      REDUCE: send != 0, recv one-hot.   BROADCAST: send one-hot, recv != 0.   ALLREDUCE/REDSCAT/ALLGATHER: send != 0, recv != 0.
  //   interior node  REDUCE/BROADCAST/ALLREDUCE only; send/recv may be empty but not both; REDUCE: |recv| <= 1; BROADCAST: |send| <= 1.
  function automatic logic [3:0] cmd_validate(input logic [CMD_W-1:0] c, input int np, input int max_len,
                                              input logic redscat_en, input logic allgather_en, input logic fp32_en,
                                              input logic interior);
    logic [2:0] ct;
    logic [7:0] sm, rm_, valid_bits;
    logic [3:0] ns, nr;
    logic [LEN_W-1:0] ln;
    ct = cmd_ctype(c);
    sm = cmd_send(c);
    rm_ = cmd_recv(c);
    ln = cmd_len(c);
    ns = popcnt8(sm);
    nr = popcnt8(rm_);
    valid_bits = (np >= 8) ? 8'hFF : ((8'd1 << np) - 8'd1);
    cmd_validate = E_OK;
    if (ct > CT_ALLGATHER || (ct == CT_REDSCAT && !redscat_en) || (ct == CT_ALLGATHER && !allgather_en) ||
        (interior && (ct == CT_REDSCAT || ct == CT_ALLGATHER)))
      cmd_validate = E_CMD_TYPE;
    else if (!op_legal(ct, cmd_op(c), cmd_dt(c), fp32_en) ||
             ((cmd_dt(c) == DT_F32) && (cmd_op(c) == OP_SUM) && (cmd_rm(c) > 3'd4)))
      cmd_validate = E_CMD_OP;
    else if (ln > LEN_W'(max_len) || (ct == CT_REDSCAT && nr != 4'd0 && ((ln % LEN_W'(nr)) != '0)))
      cmd_validate = E_CMD_LEN;
    else if ((sm & ~valid_bits) != 8'd0 || (rm_ & ~valid_bits) != 8'd0)
      cmd_validate = E_CMD_MASK;
    else if (interior) begin
      if (ns == 4'd0 && nr == 4'd0) cmd_validate = E_CMD_MASK;
      else if (ct == CT_REDUCE    && nr > 4'd1) cmd_validate = E_CMD_MASK;
      else if (ct == CT_BROADCAST && ns > 4'd1) cmd_validate = E_CMD_MASK;
    end else begin
      if (ns == 4'd0 || nr == 4'd0) cmd_validate = E_CMD_MASK;
      else if (ct == CT_REDUCE    && nr != 4'd1) cmd_validate = E_CMD_MASK;
      else if (ct == CT_BROADCAST && ns != 4'd1) cmd_validate = E_CMD_MASK;
    end
  endfunction

endpackage
`default_nettype wire
