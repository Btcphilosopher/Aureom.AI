// =============================================================================
// SilicaFlux CollectiveCore (Project 114) :: sf_collective_core -- distributed compute and reduction engine (top)
//
//   cmd -> [Collective Command Queue] -> [Operation Scheduler] -> context -> per-participant [Input Stream Controller
//   (stream adapter + input buffer)] -> [Reduction Datapath] -> [Output Stream Controller] -> per-participant outputs / up
//                                              completion records <- scheduler   ;   performance counters <- events
//
// One node, NP participant ports (local or remote: the stream protocol is identical, adapters sit outside), ONE collective at a
// time, commands in order.  A node is either a ROOT (INTERIOR = 0: results are distributed to its own participant ports) or an
// INTERIOR node of a reduction tree (INTERIOR = 1: its reduced stream leaves on `up`, the final result arrives on `down`).
// A tree is built by connecting a child's `up_*` to a parent's participant input and the parent's participant output to the
// child's `dn_*`; the stream protocol is the same on every link (docs/04_TOPOLOGY.md).
//
// Per-participant stream beat (inputs in_*, outputs out_*, up_*, dn_*): valid/ready, cid, pid, idx, dtype, op, data, last, err.
// Flattened vectors: participant p occupies bits [p*W +: W].
// Scope: INT32/UINT32 SUM MIN MAX AND OR XOR; FP32 SUM when FP32_EN; REDUCE, BROADCAST, ALLREDUCE always; REDSCAT / ALLGATHER
// when enabled (caps tells exactly what this build implements).  Read docs/09_LIMITATIONS.md.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_collective_core
  import sf_collective_pkg::*;
#(
  parameter int NP           = 2,        // participants, 2..8
  parameter int MAX_LEN      = 4096,     // longest vector (elements per participant)
  parameter int IN_DEPTH     = 4,        // input buffer per participant (elements)
  parameter int OUT_DEPTH    = 4,        // output buffer per destination (elements)
  parameter int CMD_DEPTH    = 4,
  parameter int CPL_DEPTH    = 4,
  parameter int TERM_DEPTH   = 2,        // error terminators that may wait per output port
  parameter bit INTERIOR     = 1'b0,     // tree-interior node (up / down ports in use)
  parameter int UP_PID       = 0,        // this node's participant id at its parent
  parameter bit FP32_EN      = 1'b0,
  parameter bit REDSCAT_EN   = 1'b0,
  parameter bit ALLGATHER_EN = 1'b0
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // ---- control
  input  wire logic                 ctl_soft_reset,   // pulse: back to the post-reset state (counters kept)
  input  wire logic                 ctl_abort,        // pulse: abort the running collective (E_ABORT)
  input  wire logic [31:0]          cfg_timeout,      // no-progress watchdog in cycles; 0 = off
  input  wire logic [NP-1:0]        part_fail,        // level: participant declared failed by the transport / platform
  // ---- command submit
  input  wire logic                 cmd_valid,
  output logic                      cmd_ready,
  input  wire logic [CMD_W-1:0]     cmd_data,
  // ---- completion records (one per submitted command, in order)
  output logic                      cpl_valid,
  input  wire logic                 cpl_ready,
  output logic [CID_W-1:0]          cpl_cid,
  output logic                      cpl_ok,
  output logic [3:0]                cpl_err,
  output logic [2:0]                cpl_ctype,
  output logic [5:0]                cpl_flags,
  output logic [8:0]                cpl_maskA,        // senders (bit 8: parent link) that still owed elements
  output logic [8:0]                cpl_maskB,        // destinations (bit 8: up port) that still owed beats
  output logic [LEN_W-1:0]          cpl_len,
  output logic [31:0]               cpl_cycles,
  // ---- participant input streams
  input  wire logic [NP-1:0]        in_valid,
  output logic [NP-1:0]             in_ready,
  input  wire logic [NP*CID_W-1:0]  in_cid,
  input  wire logic [NP*PID_W-1:0]  in_pid,
  input  wire logic [NP*IDX_W-1:0]  in_idx,
  input  wire logic [NP*2-1:0]      in_dtype,
  input  wire logic [NP*3-1:0]      in_op,
  input  wire logic [NP*DATA_W-1:0] in_data,
  input  wire logic [NP-1:0]        in_last,
  input  wire logic [NP-1:0]        in_err,
  // ---- participant output streams
  output logic [NP-1:0]             out_valid,
  input  wire logic [NP-1:0]        out_ready,
  output logic [NP*CID_W-1:0]       out_cid,
  output logic [NP*PID_W-1:0]       out_pid,
  output logic [NP*IDX_W-1:0]       out_idx,
  output logic [NP*2-1:0]           out_dtype,
  output logic [NP*3-1:0]           out_op,
  output logic [NP*DATA_W-1:0]      out_data,
  output logic [NP-1:0]             out_last,
  output logic [NP-1:0]             out_err,
  // ---- up stream (INTERIOR only; idle otherwise)
  output logic                      up_valid,
  input  wire logic                 up_ready,
  output logic [CID_W-1:0]          up_cid,
  output logic [PID_W-1:0]          up_pid,
  output logic [IDX_W-1:0]          up_idx,
  output logic [1:0]                up_dtype,
  output logic [2:0]                up_op,
  output logic [DATA_W-1:0]         up_data,
  output logic                      up_last,
  output logic                      up_err,
  // ---- down stream (INTERIOR only; ignored otherwise)
  input  wire logic                 dn_valid,
  output logic                      dn_ready,
  input  wire logic [CID_W-1:0]     dn_cid,
  input  wire logic [PID_W-1:0]     dn_pid,
  input  wire logic [IDX_W-1:0]     dn_idx,
  input  wire logic [1:0]           dn_dtype,
  input  wire logic [2:0]           dn_op,
  input  wire logic [DATA_W-1:0]    dn_data,
  input  wire logic                 dn_last,
  input  wire logic                 dn_err,
  // ---- performance counters / status
  input  wire logic                 perf_clear,
  input  wire logic [5:0]           perf_sel,
  output logic [63:0]               perf_data,
  output logic                      idle,             // no command running, queued or completion waiting
  output logic [15:0]               caps              // what this build implements (see below)
);
  // caps: [0] REDUCE [1] BROADCAST [2] ALLREDUCE [3] REDUCE_SCATTER [4] ALL_GATHER | [8] INT32/UINT32 ops [9] FP32 SUM | [12] tree-interior node
  assign caps = {3'd0, INTERIOR, 2'd0, FP32_EN, 1'b1, 3'd0, (ALLGATHER_EN && !INTERIOR), (REDSCAT_EN && !INTERIOR), 3'b111};

  // elaboration-time parameter checks: an illegal parameter set instantiates a module that does not exist, so elaboration fails (negative tests: scripts/lint.sh)
  generate
    if (NP < 2 || NP > MAXP)                          begin : g_chk_np   sf_collective_core_illegal_parameter_NP_must_be_2_to_8          u_err (); end
    if (MAX_LEN < 1 || (MAX_LEN * NP) >= (1 << IDX_W)) begin : g_chk_len  sf_collective_core_illegal_parameter_MAX_LEN_times_NP_must_be_below_2_pow_20 u_err (); end
    if (IN_DEPTH < 1 || OUT_DEPTH < 1 || CMD_DEPTH < 1 || CPL_DEPTH < 1 || TERM_DEPTH < 1)
                                                      begin : g_chk_dep  sf_collective_core_illegal_parameter_depths_must_be_at_least_1 u_err (); end
    if (UP_PID < 0 || UP_PID > 7)                     begin : g_chk_pid  sf_collective_core_illegal_parameter_UP_PID_must_be_0_to_7      u_err (); end
  endgenerate

  wire sclr = ctl_soft_reset;

  // ------------------------------------------------------------------ command queue
  logic               q_valid, q_pop, ev_reject;
  logic [CMD_W-1:0]   q_cmd;
  logic [3:0]         q_err;
  logic [$clog2(CMD_DEPTH+1)-1:0] q_level;
  sf_collective_command_queue #(.NP(NP), .MAX_LEN(MAX_LEN), .CMD_DEPTH(CMD_DEPTH), .REDSCAT_EN(REDSCAT_EN),
                                .ALLGATHER_EN(ALLGATHER_EN), .FP32_EN(FP32_EN), .INTERIOR(INTERIOR)) u_cq (
    .clk(clk), .rst_n(rst_n), .sclr(sclr),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_data(cmd_data),
    .q_valid(q_valid), .q_pop(q_pop), .q_cmd(q_cmd), .q_err(q_err), .q_level(q_level), .ev_reject(ev_reject)
  );

  // ------------------------------------------------------------------ scheduler
  logic               run, sch_idle, ref_valid, act_gather, act_redscat, up_en, down_en, fail_pulse;
  logic [CID_W-1:0]   ref_cid;
  logic [2:0]         act_ctype, act_op, act_rm;
  logic [1:0]         act_dtype;
  logic [NP-1:0]      act_send, act_recv;
  logic [LEN_W-1:0]   act_len, res_len, out_len;
  logic [NP-1:0]      a_err_pulse, a_in_done;
  logic [NP*4-1:0]    a_err_code;
  logic               dn_err_pulse, dn_done, red_done, red_busy, out_done, progress;
  logic [3:0]         dn_err_code;
  logic [5:0]         red_flags;
  logic [NP:0]        pend_mask;
  logic               cpl_push, cpl_full, ev_cpl_ok, ev_cpl_err;
  logic [CID_W-1:0]   s_cpl_cid;
  logic               s_cpl_ok;
  logic [3:0]         s_cpl_err;
  logic [2:0]         s_cpl_ctype;
  logic [5:0]         s_cpl_flags;
  logic [8:0]         s_cpl_maskA, s_cpl_maskB;
  logic [LEN_W-1:0]   s_cpl_len;
  logic [31:0]        s_cpl_cycles;

  sf_collective_scheduler #(.NP(NP), .INTERIOR(INTERIOR), .REDSCAT_EN(REDSCAT_EN), .ALLGATHER_EN(ALLGATHER_EN)) u_sch (
    .clk(clk), .rst_n(rst_n), .sclr(sclr),
    .q_valid(q_valid), .q_pop(q_pop), .q_cmd(q_cmd), .q_err(q_err),
    .cfg_timeout(cfg_timeout), .ctl_abort(ctl_abort), .part_fail(part_fail),
    .run(run), .idle(sch_idle), .ref_valid(ref_valid), .ref_cid(ref_cid),
    .act_ctype(act_ctype), .act_op(act_op), .act_dtype(act_dtype), .act_rm(act_rm),
    .act_send(act_send), .act_recv(act_recv), .act_len(act_len), .act_gather(act_gather), .act_redscat(act_redscat),
    .res_len(res_len), .out_len(out_len), .up_en(up_en), .down_en(down_en), .fail_pulse(fail_pulse),
    .in_err_pulse(a_err_pulse), .in_err_code(a_err_code), .dn_err_pulse(dn_err_pulse), .dn_err_code(dn_err_code),
    .in_done(a_in_done), .in_hvalid(h_valid), .dn_done(dn_done), .dn_hvalid(d_valid), .red_done(red_done), .red_flags(red_flags), .red_busy(red_busy),
    .out_done(out_done), .pend_mask(pend_mask), .progress(progress),
    .cpl_push(cpl_push), .cpl_full(cpl_full), .cpl_cid(s_cpl_cid), .cpl_ok(s_cpl_ok), .cpl_err(s_cpl_err),
    .cpl_ctype(s_cpl_ctype), .cpl_flags(s_cpl_flags), .cpl_maskA(s_cpl_maskA), .cpl_maskB(s_cpl_maskB),
    .cpl_len(s_cpl_len), .cpl_cycles(s_cpl_cycles), .ev_cpl_ok(ev_cpl_ok), .ev_cpl_err(ev_cpl_err)
  );

  // ------------------------------------------------------------------ completion buffer
  localparam int CPL_W = CID_W + 1 + 4 + 3 + 6 + 9 + 9 + LEN_W + 32;
  logic               cf_in_ready;
  logic [$clog2(CPL_DEPTH+1)-1:0] cf_level;
  logic [CPL_W-1:0]   cf_out;
  sfd_fifo #(.WIDTH(CPL_W), .DEPTH(CPL_DEPTH)) u_cpl_fifo (
    .clk(clk), .rst_n(rst_n), .flush(sclr),
    .in_valid(cpl_push), .in_ready(cf_in_ready),
    .in_data({s_cpl_cycles, s_cpl_len, s_cpl_maskB, s_cpl_maskA, s_cpl_flags, s_cpl_ctype, s_cpl_err, s_cpl_ok, s_cpl_cid}),
    .out_valid(cpl_valid), .out_ready(cpl_ready), .out_data(cf_out), .level(cf_level)
  );
  assign cpl_full   = !cf_in_ready;
  assign cpl_cid    = cf_out[0 +: CID_W];
  assign cpl_ok     = cf_out[CID_W];
  assign cpl_err    = cf_out[CID_W+1 +: 4];
  assign cpl_ctype  = cf_out[CID_W+5 +: 3];
  assign cpl_flags  = cf_out[CID_W+8 +: 6];
  assign cpl_maskA  = cf_out[CID_W+14 +: 9];
  assign cpl_maskB  = cf_out[CID_W+23 +: 9];
  assign cpl_len    = cf_out[CID_W+32 +: LEN_W];
  assign cpl_cycles = cf_out[CID_W+32+LEN_W +: 32];

  // ------------------------------------------------------------------ input stream controllers (one adapter per participant)
  logic [NP-1:0]        h_valid, h_ready, a_accept, a_stale;
  logic [NP*DATA_W-1:0] h_data;
  logic [NP*(IDX_W+1)-1:0] a_exp;
  logic [NP*$clog2(IN_DEPTH+1)-1:0] a_level;

  generate
    for (genvar p = 0; p < NP; p++) begin : g_in
      sf_collective_stream_adapter #(.PID(p), .IN_DEPTH(IN_DEPTH)) u_ad (
        .clk(clk), .rst_n(rst_n), .sclr(sclr),
        .s_valid(in_valid[p]), .s_ready(in_ready[p]),
        .s_cid(in_cid[p*CID_W +: CID_W]), .s_pid(in_pid[p*PID_W +: PID_W]), .s_idx(in_idx[p*IDX_W +: IDX_W]),
        .s_dtype(in_dtype[p*2 +: 2]), .s_op(in_op[p*3 +: 3]), .s_data(in_data[p*DATA_W +: DATA_W]),
        .s_last(in_last[p]), .s_err(in_err[p]),
        .ref_valid(ref_valid), .act_valid(run), .act_cid(ref_cid), .act_len(act_len),
        .act_dtype(act_dtype), .act_op(act_op), .act_en(act_send[p]),
        .h_valid(h_valid[p]), .h_ready(h_ready[p]), .h_data(h_data[p*DATA_W +: DATA_W]),
        .exp_idx(a_exp[p*(IDX_W+1) +: IDX_W+1]), .in_done(a_in_done[p]),
        .level(a_level[p*$clog2(IN_DEPTH+1) +: $clog2(IN_DEPTH+1)]),
        .err_pulse(a_err_pulse[p]), .err_code(a_err_code[p*4 +: 4]),
        .ev_accept(a_accept[p]), .ev_stale(a_stale[p])
      );
    end
  endgenerate

  // ---- `down` stream adapter (INTERIOR only)
  logic              d_valid, d_ready, dn_accept, dn_stale;
  logic [DATA_W-1:0] d_data;
  logic [IDX_W:0]    dn_exp;
  logic [$clog2(IN_DEPTH+1)-1:0] dn_level;
  generate
    if (INTERIOR) begin : g_dn
      sf_collective_stream_adapter #(.PID(UP_PID), .IN_DEPTH(IN_DEPTH)) u_dn (
        .clk(clk), .rst_n(rst_n), .sclr(sclr),
        .s_valid(dn_valid), .s_ready(dn_ready),
        .s_cid(dn_cid), .s_pid(dn_pid), .s_idx(dn_idx), .s_dtype(dn_dtype), .s_op(dn_op), .s_data(dn_data),
        .s_last(dn_last), .s_err(dn_err),
        .ref_valid(ref_valid), .act_valid(run), .act_cid(ref_cid), .act_len(out_len),
        .act_dtype(act_dtype), .act_op(act_op), .act_en(down_en),
        .h_valid(d_valid), .h_ready(d_ready), .h_data(d_data),
        .exp_idx(dn_exp), .in_done(dn_done), .level(dn_level),
        .err_pulse(dn_err_pulse), .err_code(dn_err_code), .ev_accept(dn_accept), .ev_stale(dn_stale)
      );
    end else begin : g_nodn
      assign dn_ready    = 1'b0;
      assign d_valid     = 1'b0;
      assign d_data      = '0;
      assign dn_exp      = '0;
      assign dn_done     = 1'b0;
      assign dn_level    = '0;
      assign dn_err_pulse = 1'b0;
      assign dn_err_code = E_OK;
      assign dn_accept   = 1'b0;
      assign dn_stale    = 1'b0;
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_dn = d_ready | dn_valid | (|dn_cid) | (|dn_pid) | (|dn_idx) | (|dn_dtype) | (|dn_op) | (|dn_data) | dn_last | dn_err;
      /* verilator lint_on UNUSEDSIGNAL */
    end
  endgenerate

  // ------------------------------------------------------------------ reduction datapath
  logic              r_valid, r_ready, r_last, ev_fire, ev_starve, ev_stall;
  logic [DATA_W-1:0] r_data;
  logic [IDX_W-1:0]  r_idx;
  sf_collective_reduction #(.NP(NP), .ALLGATHER_EN(ALLGATHER_EN), .FP32_EN(FP32_EN)) u_red (
    .clk(clk), .rst_n(rst_n), .run(run), .sclr(sclr),
    .op(act_op), .dtype(act_dtype), .rm(act_rm), .send_mask(act_send), .gather(act_gather),
    .len(act_len), .res_len(res_len),
    .h_valid(h_valid), .h_ready(h_ready), .h_data(h_data),
    .r_valid(r_valid), .r_ready(r_ready), .r_data(r_data), .r_idx(r_idx), .r_last(r_last),
    .red_done(red_done), .flags(red_flags), .busy(red_busy),
    .ev_fire(ev_fire), .ev_starve(ev_starve), .ev_stall(ev_stall)
  );

  // ------------------------------------------------------------------ output stream controller
  logic [NP-1:0]  ev_out_beat;
  logic           ev_up_beat, ev_block, term_busy;
  logic [NP:0]    ev_term_lost;
  logic [NP*$clog2(OUT_DEPTH+1)-1:0] lvl_out;
  logic [$clog2(OUT_DEPTH+1)-1:0]    lvl_up;
  sf_collective_output #(.NP(NP), .OUT_DEPTH(OUT_DEPTH), .UP_PID(UP_PID), .REDSCAT_EN(REDSCAT_EN), .TERM_DEPTH(TERM_DEPTH)) u_out (
    .clk(clk), .rst_n(rst_n), .sclr(sclr), .run(run), .fail(fail_pulse),
    .cid(ref_cid), .dtype(act_dtype), .op(act_op), .recv_mask(act_recv), .up_en(up_en), .down_en(down_en),
    .redscat(act_redscat), .res_len(res_len), .out_len(out_len),
    .r_valid(r_valid), .r_ready(r_ready), .r_data(r_data),
    .d_valid(d_valid), .d_ready(d_ready), .d_data(d_data),
    .o_valid(out_valid), .o_ready(out_ready), .o_cid(out_cid), .o_pid(out_pid), .o_idx(out_idx),
    .o_dtype(out_dtype), .o_op(out_op), .o_data(out_data), .o_last(out_last), .o_err(out_err),
    .u_valid(up_valid), .u_ready(up_ready), .u_cid(up_cid), .u_pid(up_pid), .u_idx(up_idx),
    .u_dtype(up_dtype), .u_op(up_op), .u_data(up_data), .u_last(up_last), .u_err(up_err),
    .out_done(out_done), .pend_mask(pend_mask), .term_busy(term_busy), .ev_term_lost(ev_term_lost),
    .ev_out_beat(ev_out_beat), .ev_up_beat(ev_up_beat), .ev_block(ev_block), .lvl_out(lvl_out), .lvl_up(lvl_up)
  );

  // `r_idx` / `r_last` document the result stream; per-port indices are produced by the output controller's counters.
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_r = (|r_idx) | r_last | (|dn_exp) | (|dn_level) | dn_stale | (|dn_idx[0]) | (|dn_last);
  /* verilator lint_on UNUSEDSIGNAL */

  // ------------------------------------------------------------------ progress, imbalance, perf
  assign progress = (|a_accept) | dn_accept | ev_fire | (|ev_out_beat) | ev_up_beat;
  assign idle     = sch_idle && !q_valid && !cpl_valid && !term_busy;

  logic [IDX_W:0] imb, mx, mn;
  always_comb begin
    mx = '0;
    mn = {(IDX_W+1){1'b1}};
    for (int i = 0; i < NP; i++) if (act_send[i]) begin
      if (a_exp[i*(IDX_W+1) +: IDX_W+1] > mx) mx = a_exp[i*(IDX_W+1) +: IDX_W+1];
      if (a_exp[i*(IDX_W+1) +: IDX_W+1] < mn) mn = a_exp[i*(IDX_W+1) +: IDX_W+1];
    end
    imb = (act_send == '0) ? '0 : (mx - mn);
  end

  logic [4:0] n_in, n_out, n_stale, n_perr, n_tlost;
  logic [15:0] occ_in, occ_out;
  always_comb begin
    n_in = {4'd0, dn_accept}; n_out = {4'd0, ev_up_beat}; n_stale = {4'd0, dn_stale}; n_perr = {4'd0, dn_err_pulse}; n_tlost = {4'd0, ev_term_lost[NP]};
    occ_in = 16'(dn_level); occ_out = 16'(lvl_up);
    for (int i = 0; i < NP; i++) begin
      n_in    = n_in + 5'(a_accept[i]);
      n_out   = n_out + 5'(ev_out_beat[i]);
      n_stale = n_stale + 5'(a_stale[i]);
      n_perr  = n_perr + 5'(a_err_pulse[i]);
      n_tlost = n_tlost + 5'(ev_term_lost[i]);
      occ_in  = occ_in + 16'(a_level[i*$clog2(IN_DEPTH+1) +: $clog2(IN_DEPTH+1)]);
      occ_out = occ_out + 16'(lvl_out[i*$clog2(OUT_DEPTH+1) +: $clog2(OUT_DEPTH+1)]);
    end
  end

  sf_collective_perf u_perf (
    .clk(clk), .rst_n(rst_n), .clear(perf_clear),
    .ev_active(run), .ev_fire(ev_fire), .n_beats_in(n_in), .n_beats_out(n_out),
    .ev_starve(ev_starve), .ev_stall(ev_stall), .ev_block(ev_block),
    .ev_cpl_ok(ev_cpl_ok), .ev_cpl_err(ev_cpl_err), .cpl_cycles(s_cpl_cycles), .ev_reject(ev_reject),
    .n_stale(n_stale), .n_perr(n_perr), .n_tlost(n_tlost), .occ_in(occ_in), .occ_out(occ_out), .imb(imb),
    .sel(perf_sel), .data(perf_data)
  );

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_q = (|q_level) | (|cf_level) | (|act_ctype);
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
