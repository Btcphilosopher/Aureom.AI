// =============================================================================
// SilicaFlux CollectiveCore (Project 114) -- Verilator bench harness (flat node: sf_collective_core)
//
//   Source[p]  drives participant p's input stream from a scripted beat list (gaps, start delay, injected faults)
//   Sink[p]    accepts participant p's output stream with a ready pattern; records every beat
//   CmdDrv / CplSink   command submit port and completion port
//   monitors   (every cycle)  output / completion beats stable while stalled;  completion ordering;  stream indices;
//   scoreboard (end of scenario) every completion record and every output beat against ref::compute()
// =============================================================================
#pragma once
#include "Vsf_collective_core.h"
#include "tb_common.h"

#ifndef TB_NP
#define TB_NP 2
#endif
#ifndef TB_MAXLEN
#define TB_MAXLEN 300
#endif
#ifndef TB_REDSCAT
#define TB_REDSCAT 0
#endif
#ifndef TB_ALLGATHER
#define TB_ALLGATHER 0
#endif
#ifndef TB_FP32_EN
#define TB_FP32_EN 0
#endif
#ifndef TB_INTERIOR
#define TB_INTERIOR 0
#endif

static const int NPT = TB_NP;
static const ref::Build BUILD = {TB_NP, (uint32_t)TB_MAXLEN, TB_REDSCAT != 0, TB_ALLGATHER != 0, TB_FP32_EN != 0, TB_INTERIOR != 0};

struct Tb {
  Vsf_collective_core* d;
  VerilatedContext* ctx;
  uint64_t cyc = 0;
  std::mt19937_64 rng;
  int errors = 0;
  bool quiet = false;
  Source src[8];
  Sink   snk[8];
  // command driver / completion sink
  std::deque<uint64_t> cmdq; double p_cmd = 1.0; bool cmd_valid = false; uint64_t cmd_cur = 0;
  double p_cpl_ready = 1.0; int64_t cpl_stall_until = -1;
  std::vector<CplRec> cpls; bool cpl_prev_stall = false; CplRec cpl_prev{};
  std::vector<Exp> exps;
  uint16_t next_cid = 1;
  bool have_last_cid = false; uint16_t last_cid = 0;     // reference model of the queue's ID rule
  uint32_t part_fail = 0; bool abort_pulse = false; bool soft_pulse = false;
  uint32_t cfg_timeout = 0;
  uint64_t max_cycles = 2000000;
  // coverage-ish counters
  std::map<int, int> err_seen;
  uint64_t beats_out = 0, beats_in = 0, stale_sent = 0;
  // snapshot for completion-order check
  std::map<uint16_t, int> exp_of_cid;

  Tb(Vsf_collective_core* dut, VerilatedContext* c) : d(dut), ctx(c) {}

  // ---------------------------------------------------------------- diagnostics
  void fail(const char* fmt, ...) __attribute__((format(printf, 2, 3))) {
    errors++;
    if (errors <= 25 && !quiet) {
      char buf[512];
      va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
      printf("    FAIL @%" PRIu64 ": %s\n", cyc, buf);
    }
  }

  // ---------------------------------------------------------------- reset
  void clear_tb_state() {
    for (int p = 0; p < 8; p++) { src[p] = Source(); snk[p].rx.clear(); snk[p].prev_stall = false; snk[p].stall_until = -1; snk[p].never = false; }
    cmdq.clear(); cmd_valid = false; cpls.clear(); cpl_prev_stall = false; exps.clear(); exp_of_cid.clear();
    have_last_cid = false; part_fail = 0; abort_pulse = soft_pulse = false; cpl_stall_until = -1;
  }
  void eval() { d->eval(); }
  void half(int clk) { d->clk = clk; d->eval(); }
  void hard_reset(int cycles = 3) {
    d->rst_n = 0;
    d->cmd_valid = 0; d->in_valid = 0; d->out_ready = 0; d->cpl_ready = 0; d->up_ready = 0; d->dn_valid = 0;
    d->ctl_soft_reset = 0; d->ctl_abort = 0; d->part_fail = 0; d->perf_clear = 0; d->perf_sel = 0; d->cfg_timeout = 0;
    for (int i = 0; i < cycles; i++) { half(0); half(1); cyc++; }
    half(0);
    d->rst_n = 1;
    half(0);
    clear_tb_state();
  }
  // asynchronous reset asserted in the middle of a clock phase (rst_n falls while clk is low, between edges)
  void async_reset_midcycle() {
    d->rst_n = 0; half(0);
    clear_tb_state();
    d->cmd_valid = 0; d->in_valid = 0; d->out_ready = 0; d->cpl_ready = 0; d->part_fail = 0; d->ctl_soft_reset = 0; d->ctl_abort = 0;
    half(0); half(1); half(0); cyc++;
    d->rst_n = 1; half(0);
  }

  // ---------------------------------------------------------------- drive / sample one cycle
  double rnd() { return (double)(rng() >> 11) * (1.0 / 9007199254740992.0); }

  void drive() {
    // command port
    if (!cmd_valid && !cmdq.empty() && rnd() < p_cmd) { cmd_cur = cmdq.front(); cmd_valid = true; }
    d->cmd_valid = cmd_valid; d->cmd_data = cmd_cur;
    // participant sources
    for (int p = 0; p < NPT; p++) {
      Source& s = src[p];
      if (!s.valid && !s.jobs.empty()) {
        Job& j = s.jobs.front();
        if (!s.delay_armed) { s.delay = j.start_delay; s.delay_armed = true; }
        if (s.delay > 0) s.delay--;
        else if (s.bi < j.script.size() && rnd() < j.p_send) { s.cur = j.script[s.bi]; s.valid = true; }
        else if (s.bi >= j.script.size()) { s.jobs.pop_front(); s.bi = 0; s.delay_armed = false; }
      }
      setf(d->in_valid, p, 1, s.valid);
      setf(d->in_cid, p * 16, 16, s.cur.cid); setf(d->in_pid, p * 3, 3, s.cur.pid); setf(d->in_idx, p * 20, 20, s.cur.idx);
      setf(d->in_dtype, p * 2, 2, s.cur.dt); setf(d->in_op, p * 3, 3, s.cur.op); setf(d->in_data, p * 32, 32, s.cur.data);
      setf(d->in_last, p, 1, s.cur.last); setf(d->in_err, p, 1, s.cur.err);
    }
    // sinks
    for (int p = 0; p < NPT; p++) {
      Sink& k = snk[p];
      bool r = !k.never && (int64_t)cyc >= k.stall_until && rnd() < k.p_ready;
      setf(d->out_ready, p, 1, r);
    }
    d->up_ready = 1; d->dn_valid = 0;
    bool cr = ((int64_t)cyc >= cpl_stall_until) && rnd() < p_cpl_ready;
    d->cpl_ready = cr;
    d->part_fail = part_fail; d->ctl_abort = abort_pulse; d->ctl_soft_reset = soft_pulse; d->cfg_timeout = cfg_timeout;
    abort_pulse = false; soft_pulse = false;
  }

  void sample_and_commit() {
    // command
    if (cmd_valid && d->cmd_ready) { cmd_valid = false; cmdq.pop_front(); }
    // sources
    for (int p = 0; p < NPT; p++) {
      Source& s = src[p];
      if (s.valid && getf(d->in_ready, p, 1)) {
        s.valid = false; s.bi++; s.sent++; beats_in++;
        if (s.bi >= s.jobs.front().script.size()) { s.jobs.pop_front(); s.bi = 0; s.delay_armed = false; }
      }
    }
    // sinks: monitor stability, record
    for (int p = 0; p < NPT; p++) {
      Sink& k = snk[p];
      const bool v = getf(d->out_valid, p, 1), r = getf(d->out_ready, p, 1);
      Beat b; b.cid = getf(d->out_cid, p * 16, 16); b.pid = getf(d->out_pid, p * 3, 3); b.idx = getf(d->out_idx, p * 20, 20);
      b.dt = getf(d->out_dtype, p * 2, 2); b.op = getf(d->out_op, p * 3, 3); b.data = getf(d->out_data, p * 32, 32);
      b.last = getf(d->out_last, p, 1); b.err = getf(d->out_err, p, 1);
      if (k.prev_stall) {
        if (!v) fail("out[%d]: valid dropped while stalled", p);
        else if (!(b == k.prev)) fail("out[%d]: beat changed while stalled", p);
      }
      k.prev_stall = v && !r; k.prev = b;
      if (v && r) { k.rx.push_back({b, cyc}); beats_out++; }
    }
    // completion
    {
      const bool v = d->cpl_valid, r = d->cpl_ready;
      CplRec c{(uint16_t)d->cpl_cid, (bool)d->cpl_ok, (int)d->cpl_err, (int)d->cpl_ctype, (uint32_t)d->cpl_flags,
               (uint32_t)d->cpl_maskA, (uint32_t)d->cpl_maskB, (uint32_t)d->cpl_len, (uint32_t)d->cpl_cycles, cyc};
      if (cpl_prev_stall) {
        if (!v) fail("cpl: valid dropped while stalled");
        else if (c.cid != cpl_prev.cid || c.ok != cpl_prev.ok || c.err != cpl_prev.err || c.flags != cpl_prev.flags ||
                 c.maskA != cpl_prev.maskA || c.maskB != cpl_prev.maskB || c.cycles != cpl_prev.cycles)
          fail("cpl: record changed while stalled");
      }
      cpl_prev_stall = v && !r; cpl_prev = c;
      if (v && r) { cpls.push_back(c); on_cpl(c); }
    }
  }

  // completion-ordering monitor: an OK completion may only appear after every owed beat was accepted by its sink
  void on_cpl(const CplRec& c) {
    err_seen[c.err]++;
    const size_t i = cpls.size() - 1;
    if (i >= exps.size()) { fail("completion #%zu has no submitted command", i); return; }
    const Exp& e = exps[i];
    if (c.cid != e.cmd.cid) fail("completion #%zu: cid %u, expected %u (completions out of order)", i, c.cid, e.cmd.cid);
    if (c.ok) {
      const int nr = ref::popc(e.cmd.recv);
      uint32_t out_len = e.cmd.len;
      if (e.cmd.ctype == ref::CT_ALLGATHER) out_len = e.cmd.len * ref::popc(e.cmd.send);
      if (e.cmd.ctype == ref::CT_REDSCAT && nr) out_len = e.cmd.len / nr;
      for (int p = 0; p < NPT; p++) {
        if (!(e.cmd.recv >> p & 1)) continue;
        uint32_t n = 0;
        for (auto& rb : snk[p].rx) if (rb.b.cid == e.cmd.cid && !rb.b.err) n++;
        if (n != out_len) fail("cid %u OK completion before port %d received all beats (%u of %u)", c.cid, p, n, out_len);
      }
    }
  }

  void step() {
    drive();
    half(0);                       // settle combinational outputs for the driven inputs
    sample_and_commit();
    half(1);                       // rising edge
    half(0);
    cyc++;
  }

  // ---------------------------------------------------------------- run control
  bool all_idle() {
    if (!cmdq.empty() || cmd_valid) return false;
    for (int p = 0; p < NPT; p++) if (!src[p].idle()) return false;
    if (cpls.size() != exps.size()) return false;
    if (!d->idle) return false;
    for (int p = 0; p < NPT; p++) if (getf(d->out_valid, p, 1)) return false;
    return true;
  }
  bool run_until_idle(uint64_t maxc = 0) {
    if (!maxc) maxc = max_cycles;
    const uint64_t start = cyc;
    int quiet_cycles = 0;
    while (cyc - start < maxc) {
      step();
      if (all_idle()) { if (++quiet_cycles >= 6) return true; } else quiet_cycles = 0;
    }
    fail("HANG: not idle after %" PRIu64 " cycles (completions %zu of %zu)", maxc, cpls.size(), exps.size());
    return false;
  }
  void run_cycles(int n) { for (int i = 0; i < n; i++) step(); }

  // ---------------------------------------------------------------- scenario construction
  static std::vector<uint32_t> rand_vec(std::mt19937_64& r, int n, int mode) { return tb_rand_vec(r, n, mode); }

  struct Spec {
    int ctype = ref::CT_ALLREDUCE, op = ref::OP_SUM, dtype = ref::DT_I32, rm = -1;   // rm -1: random (0..4 for FP32 SUM, 0..7 otherwise: ignored)
    uint8_t send = (uint8_t)((1u << NPT) - 1), recv = (uint8_t)((1u << NPT) - 1);
    uint32_t len = 8;
    int data_mode = 0;
    // per-participant behaviour
    int start_delay[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    double p_send[8] = {1, 1, 1, 1, 1, 1, 1, 1};
    int fault_p = -1; int fault = F_NONE; int fault_at = 0;      // single injected fault on participant fault_p
    int extra_sender = -1;                                        // a participant that is NOT a sender nevertheless streams data (must be refused: E_HDR)
    bool stream_anyway = false;                                   // stream data even if the command will be rejected
    int64_t force_cid = -1;
    std::vector<std::vector<uint32_t>> data;                      // optional explicit data per participant
    int exp_err_override = -2;                                    // -2: derive;  else force the expectation
    int64_t exp_maskA = -1, exp_maskB = -1;
  };

  // Build the beat script of participant p for command c with a fault applied.
  std::vector<Beat> make_script(const ref::Cmd& c, int p, const std::vector<uint32_t>& data, int fault, int at, uint16_t cid_override = 0, bool use_override = false) {
    std::vector<Beat> s;
    const uint16_t cid = use_override ? cid_override : c.cid;
    auto mk = [&](uint32_t idx) {
      Beat b; b.cid = cid; b.pid = (uint8_t)p; b.idx = idx; b.dt = (uint8_t)c.dtype; b.op = (uint8_t)c.op;
      b.data = (idx < data.size()) ? data[idx] : 0; b.last = (idx == c.len - 1); b.err = false; return b;
    };
    for (uint32_t i = 0; i < c.len; i++) {
      Beat b = mk(i);
      if (fault != F_NONE && (int)i == at) {
        switch (fault) {
          case F_DROP: continue;
          case F_DUP: s.push_back(b); s.push_back(b); continue;
          case F_BAD_DATA_DUP: s.push_back(b); { Beat b2 = b; b2.data ^= 0x5A5A5A5Au; s.push_back(b2); } continue;
          case F_BAD_PID: b.pid = (uint8_t)((p + 1) & 7); break;
          case F_BAD_DT: b.dt = (uint8_t)((c.dtype + 1) % 3); break;
          case F_BAD_OP: b.op = (uint8_t)((c.op + 1) % 6); break;
          case F_BAD_LAST: b.last = !b.last; break;
          case F_EARLY_LAST: b.last = true; break;
          case F_ERR_FLAG: b.err = true; break;
          case F_STOP: return s;                       // stop before sending element `at`
          default: break;
        }
      }
      s.push_back(b);
    }
    if (fault == F_EXTRA) { Beat b = mk(c.len); b.last = false; s.push_back(b); }
    return s;
  }

  // Create one collective: queue the command and the participants' jobs; derive the expectation.  Returns the cid.
  uint16_t collective(const Spec& sp0) {
    Spec sp = sp0;
    if (sp.rm < 0) sp.rm = (sp.dtype == ref::DT_F32 && sp.op == ref::OP_SUM) ? (int)(rng() % 5) : (int)(rng() % 8);
    ref::Cmd c; c.cid = (sp.force_cid >= 0) ? (uint16_t)sp.force_cid : next_cid; c.ctype = sp.ctype; c.op = sp.op; c.dtype = sp.dtype; c.rm = sp.rm;
    c.send = sp.send; c.recv = sp.recv; c.len = sp.len;
    if (sp.force_cid < 0) next_cid++;
    Exp e; e.cmd = c;
    // queue-level verdict (independent restatement of the ID rule, then the command rules)
    int verdict;
    if (have_last_cid && !((uint16_t)(c.cid - last_cid) != 0 && ((uint16_t)(c.cid - last_cid) & 0x8000) == 0)) verdict = ref::E_CMD_CID;
    else verdict = ref::validate(c, BUILD);
    if (verdict != ref::E_CMD_CID) { have_last_cid = true; last_cid = c.cid; }
    int mode = sp.data_mode;
    if (c.dtype == ref::DT_F32 && mode < 5) mode = 5 + (int)(rng() % 3);
    if (c.dtype != ref::DT_F32 && mode >= 5) mode = (int)(rng() % 4);
    // data
    std::vector<std::vector<uint32_t>> in(8);
    for (int p = 0; p < NPT; p++) {
      if (!(c.send >> p & 1)) continue;
      if ((size_t)p < sp.data.size() && !sp.data[p].empty()) in[p] = sp.data[p];
      else in[p] = rand_vec(rng, std::max<int>(c.len, 1), mode);
    }
    // jobs
    if (verdict == ref::E_OK || sp.stream_anyway) {
      for (int p = 0; p < NPT; p++) {
        if (!(c.send >> p & 1)) continue;
        Job j;
        j.script = make_script(c, p, in[p], (p == sp.fault_p) ? sp.fault : F_NONE, sp.fault_at);
        j.start_delay = sp.start_delay[p]; j.p_send = sp.p_send[p];
        if (c.len > 0 || true) src[p].jobs.push_back(j);
      }
    }
    if (verdict == ref::E_OK && sp.extra_sender >= 0 && sp.extra_sender < NPT && !(c.send >> sp.extra_sender & 1)) {
      const int p = sp.extra_sender; std::vector<uint32_t> junk = rand_vec(rng, std::max<int>(c.len, 1), 0);
      Job j; j.script = make_script(c, p, junk, F_NONE, 0); j.start_delay = sp.start_delay[p]; j.p_send = sp.p_send[p]; src[p].jobs.push_back(j);
    }
    // expectation
    if (verdict != ref::E_OK) {
      e.exp_err = verdict;
    } else {
      e.res = ref::compute(c, BUILD, in); e.have_result = true;
      e.exp_err = ref::E_OK;
      if (sp.fault != F_NONE && sp.fault_p >= 0 && (c.send >> sp.fault_p & 1) && c.len > 0)
        e.exp_err = fault_expected_err(sp.fault, sp.fault_at, (int)c.len);
      if (sp.fault == F_EXTRA && c.len > 0) e.exp_err = ref::E_LEN;
      if (sp.extra_sender >= 0 && c.len > 0 && !(c.send >> sp.extra_sender & 1)) e.exp_err = ref::E_HDR;
    }
    if (sp.exp_err_override != -2) e.exp_err = sp.exp_err_override;
    e.exp_maskA = sp.exp_maskA; e.exp_maskB = sp.exp_maskB;
    exp_of_cid.emplace(c.cid, (int)exps.size());          // a rejected repeated ID keeps the mapping of the real command
    exps.push_back(e);
    cmdq.push_back(c.pack());
    return c.cid;
  }

  // ---------------------------------------------------------------- scoreboard
  void check_all(const char* tag) {
    (void)tag;
    int missing_terms = 0;
    if (cpls.size() != exps.size()) fail("completions %zu != submitted commands %zu", cpls.size(), exps.size());
    // every output beat must belong to a submitted command; per-port stream ordering
    for (int p = 0; p < NPT; p++) {
      int64_t last_cid_seen = -1; std::map<uint16_t, uint32_t> next_idx; std::map<uint16_t, bool> ended;
      for (auto& rb : snk[p].rx) {
        const Beat& b = rb.b;
        if (!exp_of_cid.count(b.cid)) { fail("port %d: beat for unknown cid %u", p, b.cid); continue; }
        if (last_cid_seen >= 0 && (int16_t)(uint16_t)(b.cid - (uint16_t)last_cid_seen) < 0)
          fail("port %d: cid went backwards (%u after %" PRId64 ")", p, b.cid, last_cid_seen);
        last_cid_seen = b.cid;
        if (b.pid != p) fail("port %d: beat pid %u", p, b.pid);
        if (ended[b.cid]) fail("port %d cid %u: beat after the stream ended", p, b.cid);
        if (b.idx != next_idx[b.cid] && !b.err) fail("port %d cid %u: idx %u, expected %u", p, b.cid, b.idx, next_idx[b.cid]);
        if (b.err) { if (!b.last) fail("port %d cid %u: error beat without last", p, b.cid); if (b.idx != next_idx[b.cid]) fail("port %d cid %u: terminator idx %u, delivered %u", p, b.cid, b.idx, next_idx[b.cid]); ended[b.cid] = true; }
        else { next_idx[b.cid]++; if (b.last) ended[b.cid] = true; }
      }
    }
    for (size_t i = 0; i < exps.size(); i++) {
      const Exp& e = exps[i];
      if (i >= cpls.size()) break;
      const CplRec& c = cpls[i];
      const int nr = ref::popc(e.cmd.recv);
      uint32_t out_len = e.cmd.len;
      if (e.cmd.ctype == ref::CT_ALLGATHER) out_len = e.cmd.len * ref::popc(e.cmd.send);
      if (e.cmd.ctype == ref::CT_REDSCAT && nr) out_len = e.cmd.len / nr;
      if (c.cid != e.cmd.cid) fail("cmd %zu: completion cid %u != %u", i, c.cid, e.cmd.cid);
      if (e.exp_err != -1 && c.err != e.exp_err) {
        fail("cmd %zu (cid %u %s): completion err %s, expected %s", i, e.cmd.cid, e.name.c_str(), ref::err_name(c.err), ref::err_name(e.exp_err));
      }
      if (c.ok != (c.err == 0)) fail("cmd %zu: ok bit inconsistent with err", i);
      if (c.err == ref::E_CMD_CID) continue;               // its ID is not an identity (it repeats / precedes a real one): no stream attribution
      if (e.exp_maskA >= 0 && c.maskA != (uint32_t)e.exp_maskA) fail("cmd %zu: maskA 0x%x, expected 0x%x", i, c.maskA, (unsigned)e.exp_maskA);
      if (e.exp_maskB >= 0 && c.maskB != (uint32_t)e.exp_maskB) fail("cmd %zu: maskB 0x%x, expected 0x%x", i, c.maskB, (unsigned)e.exp_maskB);
      if (c.len != e.cmd.len) fail("cmd %zu: cpl len %u != %u", i, c.len, e.cmd.len);
      if (c.ctype != e.cmd.ctype && c.err != ref::E_CMD_TYPE) fail("cmd %zu: cpl ctype %d != %d", i, c.ctype, e.cmd.ctype);
      // output streams
      for (int p = 0; p < NPT; p++) {
        std::vector<Beat> got;
        for (auto& rb : snk[p].rx) if (rb.b.cid == e.cmd.cid) got.push_back(rb.b);
        const bool is_recv = (e.cmd.recv >> p & 1) && c.err != ref::E_CMD_TYPE && e.have_result;
        if (!is_recv) { if (!got.empty() && !(c.err != 0 && got.size() == 1 && got[0].err && false)) fail("cmd %zu port %d: %zu unexpected beats", i, p, got.size()); continue; }
        const std::vector<uint32_t>& want = e.res.port[p];
        size_t ndata = 0; bool term = false;
        for (auto& b : got) {
          if (b.err) { term = true; continue; }
          if (ndata < want.size() && b.data != want[ndata]) fail("cmd %zu (cid %u) port %d elem %zu: got %08x want %08x", i, e.cmd.cid, p, ndata, b.data, want[ndata]);
          if (b.dt != e.cmd.dtype || b.op != e.cmd.op) fail("cmd %zu port %d: beat dtype/op mismatch", i, p);
          ndata++;
        }
        if (ndata > out_len) fail("cmd %zu port %d: %zu beats > %u", i, p, ndata, out_len);
        if (c.err == 0) {
          if (ndata != out_len) fail("cmd %zu port %d: %zu beats, expected %u", i, p, ndata, out_len);
          if (term) fail("cmd %zu port %d: terminator on a successful collective", i, p);
          if (!got.empty() && !got.back().last) fail("cmd %zu port %d: last flag missing", i, p);
          for (size_t k = 0; k + 1 < got.size(); k++) if (got[k].last) fail("cmd %zu port %d: early last", i, p);
        } else {
          // failed collective: partial results are exact prefixes (checked above); a port that did not receive everything MUST get a terminator
          if (e.cmd.len > 0 && ndata < out_len && !term) missing_terms++;       // must be explained by PC_TERM_LOST (checked below)
          if (ndata == out_len && term) fail("cmd %zu port %d: terminator after a complete stream", i, p);
        }
      }
      // flags of a successful collective
      if (c.err == 0 && e.have_result && c.flags != (e.res.flags)) fail("cmd %zu (cid %u): flags 0x%x, expected 0x%x", i, e.cmd.cid, c.flags, e.res.flags);
    }
    // every terminator that is missing must have been counted as lost (queue full); a lost one that was not needed is also an error
    d->perf_sel = 22; d->eval();
    const uint64_t lost = d->perf_data;
    if ((uint64_t)missing_terms > lost) fail("%d failed-collective port(s) without an error terminator but PC_TERM_LOST = %" PRIu64, missing_terms, lost);
  }
};
