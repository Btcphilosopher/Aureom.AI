// =============================================================================
// SilicaFlux CollectiveCore (Project 114) -- tree bench: a FAN-ary tree of sf_collective_core nodes (sim/sf_collective_tree_sim.sv)
//   tt_main [--seed N] [--test name|all] [--list] [--quiet]
// The bench plays the control plane (it expands each global collective into per-node commands) and the leaf accelerators.
// Checks: exact leaf results against ref::compute_tree (independent), per-node completion records (status, node-local flags),
// per-link-agnostic invariants (stability of leaf streams, ordering, terminators), recovery after failures.
// =============================================================================
#include "Vsf_collective_tree_sim.h"
#include "tb_common.h"
#include <cstring>
#include <algorithm>

#ifndef TB_FAN
#define TB_FAN 2
#endif
#ifndef TB_H
#define TB_H 2
#endif
#ifndef TB_MAXLEN
#define TB_MAXLEN 300
#endif
#ifndef TB_FP32_EN
#define TB_FP32_EN 0
#endif
using ref::CT_REDUCE; using ref::CT_BROADCAST; using ref::CT_ALLREDUCE;
using ref::OP_SUM; using ref::OP_COPY; using ref::DT_I32; using ref::DT_U32;

static const int FAN = TB_FAN, HT = TB_H;
static int LEAVES_() { int n = 1; for (int i = 0; i < HT; i++) n *= FAN; return n; }
static const int LV = LEAVES_();
static const int NC = ref::tree_nodes(TB_FAN, TB_H);
static int span(int l) { int n = 1; for (int i = 0; i < l; i++) n *= FAN; return n; }        // leaves under one child of a level-l node

struct NodeIO {
  std::deque<uint64_t> cmdq; bool cv = false; uint64_t cur = 0; double p_cmd = 1.0; int64_t hold_until = -1;
  std::vector<CplRec> cpls; bool prev_stall = false; CplRec prev{}; double p_cpl = 1.0;
  std::vector<int> exp_g;                    // global collectives this node must complete, in order
};

struct GExp {
  ref::CmdT cmd; std::vector<std::vector<uint32_t>> in; ref::ResultT res;
  int fault_leaf = -1, fault = F_NONE, fault_at = 0; int exp_err = ref::E_OK;   // exp_err: expected code on at least one node when a fault is injected
  bool free_outcome = false;                                                      // random-fault mode: any outcome, invariants only
  uint32_t out_len = 0;
};

struct TSpec {
  int ctype = CT_ALLREDUCE, op = OP_SUM, dtype = DT_I32, rm = -1; uint32_t len = 8;
  uint64_t send = 0, recv = 0; int data_mode = 0;
  int start_delay[64] = {0}; double p_send[64];
  int fault_leaf = -1, fault = F_NONE, fault_at = 0;
  TSpec() { for (auto& x : p_send) x = 1.0; send = recv = (LV >= 64 ? ~0ull : ((1ull << LV) - 1)); }
};

struct Tt {
  Vsf_collective_tree_sim* d; uint64_t cyc = 0; std::mt19937_64 rng; int errors = 0; bool quiet = false;
  Source src[64]; Sink snk[64]; NodeIO nio[64];
  std::vector<GExp> gx; uint16_t next_cid = 1; uint32_t part_fail = 0; bool abort_pulse = false;
  uint32_t cfg_timeout = 0; uint64_t max_cycles = 3000000; uint64_t beats_in = 0, beats_out = 0;
  std::map<uint16_t, int> g_of_cid;

  explicit Tt(Vsf_collective_tree_sim* dut) : d(dut) {}
  double rnd() { return (double)(rng() >> 11) * (1.0 / 9007199254740992.0); }
  int rndi(int lo, int hi) { return lo + (int)(rng() % (uint64_t)(hi - lo + 1)); }
  void fail(const char* fmt, ...) __attribute__((format(printf, 2, 3))) {
    errors++;
    if (errors <= 25 && !quiet) { char b[512]; va_list ap; va_start(ap, fmt); vsnprintf(b, sizeof b, fmt, ap); va_end(ap); printf("    FAIL @%" PRIu64 ": %s\n", cyc, b); }
  }
  void half(int clk) { d->clk = clk; d->eval(); }

  void clear_state() {
    for (int i = 0; i < 64; i++) { src[i] = Source(); snk[i].rx.clear(); snk[i].prev_stall = false; snk[i].never = false; snk[i].stall_until = -1; nio[i] = NodeIO(); }
    gx.clear(); g_of_cid.clear(); part_fail = 0; abort_pulse = false;
  }
  void hard_reset(int cycles = 3) {
    d->rst_n = 0; d->cmd_valid = 0; d->in_valid = 0; d->out_ready = 0; d->cpl_ready = 0; d->ctl_soft_reset = 0; d->ctl_abort = 0; d->part_fail = 0; d->cfg_timeout = 0; d->perf_sel = 0;
    for (int i = 0; i < cycles; i++) { half(0); half(1); cyc++; }
    half(0); d->rst_n = 1; half(0); clear_state();
  }
  void async_reset_midcycle() {
    d->rst_n = 0; half(0); clear_state();
    d->cmd_valid = 0; d->in_valid = 0; d->out_ready = 0; d->cpl_ready = 0; d->part_fail = 0; d->ctl_abort = 0;
    half(0); half(1); half(0); cyc++; d->rst_n = 1; half(0);
  }

  // ------------------------------------------------------------------ per-cycle
  void drive() {
    for (int n = 0; n < NC; n++) {
      NodeIO& io = nio[n];
      if (!io.cv && !io.cmdq.empty() && (int64_t)cyc >= io.hold_until && rnd() < io.p_cmd) { io.cur = io.cmdq.front(); io.cv = true; }
      setf(d->cmd_valid, n, 1, io.cv); setf64(d->cmd_data, n * 64, io.cur);
      setf(d->cpl_ready, n, 1, rnd() < io.p_cpl);
    }
    for (int p = 0; p < LV; p++) {
      Source& s = src[p];
      if (!s.valid && !s.jobs.empty()) {
        Job& j = s.jobs.front();
        if (!s.delay_armed) { s.delay = j.start_delay; s.delay_armed = true; }
        if (s.delay > 0) s.delay--;
        else if (s.bi < j.script.size() && rnd() < j.p_send) { s.cur = j.script[s.bi]; s.valid = true; }
        else if (s.bi >= j.script.size()) { s.jobs.pop_front(); s.bi = 0; s.delay_armed = false; }
      }
      setf(d->in_valid, p, 1, s.valid); setf(d->in_cid, p * 16, 16, s.cur.cid); setf(d->in_pid, p * 3, 3, s.cur.pid); setf(d->in_idx, p * 20, 20, s.cur.idx);
      setf(d->in_dtype, p * 2, 2, s.cur.dt); setf(d->in_op, p * 3, 3, s.cur.op); setf(d->in_data, p * 32, 32, s.cur.data);
      setf(d->in_last, p, 1, s.cur.last); setf(d->in_err, p, 1, s.cur.err);
      Sink& k = snk[p];
      setf(d->out_ready, p, 1, !k.never && (int64_t)cyc >= k.stall_until && rnd() < k.p_ready);
    }
    d->part_fail = part_fail; d->ctl_abort = abort_pulse; d->cfg_timeout = cfg_timeout; abort_pulse = false; d->ctl_soft_reset = 0;
  }
  void sample() {
    for (int n = 0; n < NC; n++) {
      NodeIO& io = nio[n];
      if (io.cv && getf(d->cmd_ready, n, 1)) { io.cv = false; io.cmdq.pop_front(); }
      const bool v = getf(d->cpl_valid, n, 1), r = getf(d->cpl_ready, n, 1);
      CplRec c{(uint16_t)getf(d->cpl_cid, n * 16, 16), (bool)getf(d->cpl_ok, n, 1), (int)getf(d->cpl_err, n * 4, 4), 0, (uint32_t)getf(d->cpl_flags, n * 6, 6),
               (uint32_t)getf(d->cpl_maskA, n * 9, 9), (uint32_t)getf(d->cpl_maskB, n * 9, 9), 0, 0, cyc};
      if (io.prev_stall) {
        if (!v) fail("node %d cpl: valid dropped while stalled", n);
        else if (c.cid != io.prev.cid || c.err != io.prev.err || c.flags != io.prev.flags || c.maskA != io.prev.maskA || c.maskB != io.prev.maskB) fail("node %d cpl: record changed while stalled", n);
      }
      io.prev_stall = v && !r; io.prev = c;
      if (v && r) io.cpls.push_back(c);
    }
    for (int p = 0; p < LV; p++) {
      Source& s = src[p];
      if (s.valid && getf(d->in_ready, p, 1)) { s.valid = false; s.bi++; s.sent++; beats_in++; if (s.bi >= s.jobs.front().script.size()) { s.jobs.pop_front(); s.bi = 0; s.delay_armed = false; } }
      Sink& k = snk[p];
      const bool v = getf(d->out_valid, p, 1), r = getf(d->out_ready, p, 1);
      Beat b; b.cid = getf(d->out_cid, p * 16, 16); b.pid = getf(d->out_pid, p * 3, 3); b.idx = getf(d->out_idx, p * 20, 20); b.dt = getf(d->out_dtype, p * 2, 2);
      b.op = getf(d->out_op, p * 3, 3); b.data = getf(d->out_data, p * 32, 32); b.last = getf(d->out_last, p, 1); b.err = getf(d->out_err, p, 1);
      if (k.prev_stall) { if (!v) fail("leaf %d: valid dropped while stalled", p); else if (!(b == k.prev)) fail("leaf %d: beat changed while stalled", p); }
      k.prev_stall = v && !r; k.prev = b;
      if (v && r) { k.rx.push_back({b, cyc}); beats_out++; }
    }
  }
  void step() { drive(); half(0); sample(); half(1); half(0); cyc++; }
  void run_cycles(int n) { for (int i = 0; i < n; i++) step(); }
  bool all_idle() {
    for (int n = 0; n < NC; n++) { if (!nio[n].cmdq.empty() || nio[n].cv) return false; if (nio[n].cpls.size() != nio[n].exp_g.size()) return false; if (!getf(d->node_idle, n, 1)) return false; }
    for (int p = 0; p < LV; p++) { if (!src[p].idle()) return false; if (getf(d->out_valid, p, 1)) return false; }
    return true;
  }
  bool run_until_idle(uint64_t maxc = 0) {
    if (!maxc) maxc = max_cycles;
    const uint64_t st = cyc; int q = 0;
    while (cyc - st < maxc) { step(); if (all_idle()) { if (++q >= 8) return true; } else q = 0; }
    int pend = 0; for (int n = 0; n < NC; n++) pend += (int)(nio[n].exp_g.size() - nio[n].cpls.size());
    fail("HANG: not idle after %" PRIu64 " cycles (%d node completions outstanding)", maxc, pend);
    return false;
  }

  // ------------------------------------------------------------------ scenario construction
  // expand a global (leaf-mask) collective into the per-node commands of the control plane
  void expand(const ref::CmdT& c, const std::vector<int>* only_nodes = nullptr) {
    (void)only_nodes;
    for (int l = 0; l < HT; l++) for (int i = 0; i < ref::tree_cnt(FAN, HT, l); i++) {
      const int id = ref::tree_off(FAN, HT, l) + i;
      uint8_t sm = 0, rm = 0;
      for (int p = 0; p < FAN; p++) {
        const int first = (i * FAN + p) * span(l);
        const uint64_t m = (span(l) >= 64) ? ~0ull : (((1ull << span(l)) - 1) << first);
        if (c.send & m) sm |= (uint8_t)(1u << p);
        if (c.recv & m) rm |= (uint8_t)(1u << p);
      }
      if (!sm && !rm) continue;
      ref::Cmd nc; nc.cid = c.cid; nc.ctype = c.ctype; nc.op = c.op; nc.dtype = c.dtype; nc.rm = c.rm; nc.send = sm; nc.recv = rm; nc.len = c.len;
      nio[id].cmdq.push_back(nc.pack());
      nio[id].exp_g.push_back((int)gx.size());
    }
  }
  static std::vector<uint32_t> rvec(std::mt19937_64& r, int n, int mode) { return tb_rand_vec(r, n, mode); }
  std::vector<Beat> script(const ref::CmdT& c, int p, const std::vector<uint32_t>& data, int fault, int at) {
    std::vector<Beat> s;
    auto mk = [&](uint32_t idx) { Beat b; b.cid = c.cid; b.pid = (uint8_t)(p % FAN); b.idx = idx; b.dt = (uint8_t)c.dtype; b.op = (uint8_t)c.op; b.data = idx < data.size() ? data[idx] : 0; b.last = (idx == c.len - 1); return b; };
    for (uint32_t i = 0; i < c.len; i++) {
      Beat b = mk(i);
      if (fault != F_NONE && (int)i == at) switch (fault) {
        case F_DROP: continue;
        case F_DUP: s.push_back(b); s.push_back(b); continue;
        case F_BAD_DATA_DUP: { s.push_back(b); Beat b2 = b; b2.data ^= 0x5A5A5A5Au; s.push_back(b2); } continue;
        case F_BAD_PID: b.pid = (uint8_t)((b.pid + 1) & 7); break;
        case F_BAD_DT: b.dt = (uint8_t)((c.dtype + 1) % 3); break;
        case F_BAD_OP: b.op = (uint8_t)((c.op + 1) % 6); break;
        case F_BAD_LAST: b.last = !b.last; break;
        case F_EARLY_LAST: b.last = true; break;
        case F_ERR_FLAG: b.err = true; break;
        case F_STOP: return s;
        default: break;
      }
      s.push_back(b);
    }
    if (fault == F_EXTRA) { Beat b = mk(c.len); b.last = false; s.push_back(b); }
    return s;
  }
  uint16_t collective(const TSpec& sp) {
    GExp g; ref::CmdT& c = g.cmd; c.cid = next_cid++;
    int dtv = sp.dtype;
    if (TB_FP32_EN && sp.op == OP_SUM && dtv != ref::DT_F32 && rnd() < 0.4) dtv = ref::DT_F32;      // FP32 SUM is part of every mix when built
    int mode = sp.data_mode; int rmv = sp.rm;
    if (rmv < 0) rmv = (dtv == ref::DT_F32 && sp.op == OP_SUM) ? (int)(rng() % 5) : (int)(rng() % 8);
    if (dtv == ref::DT_F32 && mode < 5) mode = 5 + (int)(rng() % 3);
    if (dtv != ref::DT_F32 && mode >= 5) mode = (int)(rng() % 4); c.ctype = sp.ctype; c.op = sp.op; c.dtype = dtv; c.rm = rmv; c.send = sp.send; c.recv = sp.recv; c.len = sp.len;
    g.in.assign(LV, {});
    for (int p = 0; p < LV; p++) if (c.send >> p & 1) g.in[p] = rvec(rng, std::max<int>(c.len, 1), mode);
    g.res = ref::compute_tree(c, FAN, HT, g.in);
    if (FAN == 2 && LV <= 8 && c.len > 0) {                       // claim of docs/03: a binary tree of nodes reduces in EXACTLY the flat balanced-tree order
      ref::Cmd fc; fc.cid = c.cid; fc.ctype = c.ctype; fc.op = c.op; fc.dtype = c.dtype; fc.rm = c.rm; fc.send = (uint8_t)c.send; fc.recv = (uint8_t)c.recv; fc.len = c.len;
      ref::Build fb; fb.np = LV; fb.max_len = TB_MAXLEN; fb.fp32 = true;
      ref::Result fr = ref::compute(fc, fb, g.in);
      if (fr.full != g.res.full) fail("reference self-check: binary tree order != flat balanced order (cid %u)", c.cid);
    }
    g.fault_leaf = sp.fault_leaf; g.fault = sp.fault; g.fault_at = sp.fault_at;
    if (sp.fault != F_NONE && sp.fault_leaf >= 0 && (c.send >> sp.fault_leaf & 1) && c.len > 0) g.exp_err = fault_expected_err(sp.fault, sp.fault_at, (int)c.len);
    if (sp.fault == F_EXTRA && c.len > 0 && (c.send >> sp.fault_leaf & 1)) g.exp_err = ref::E_LEN;
    g.out_len = c.len;
    for (int p = 0; p < LV; p++) {
      if (!(c.send >> p & 1)) continue;
      Job j; j.script = script(c, p, g.in[p], p == sp.fault_leaf ? sp.fault : F_NONE, sp.fault_at); j.start_delay = sp.start_delay[p]; j.p_send = sp.p_send[p];
      src[p].jobs.push_back(j);
    }
    g_of_cid[c.cid] = (int)gx.size();
    expand(c);
    gx.push_back(g);
    return c.cid;
  }

  // ------------------------------------------------------------------ scoreboard
  void check_all(const char* tag) {
    (void)tag;
    int missing_terms = 0;
    // 1. per node: one completion per commanded collective, in order
    for (int n = 0; n < NC; n++) {
      NodeIO& io = nio[n];
      if (io.cpls.size() != io.exp_g.size()) { fail("node %d: %zu completions, %zu commands", n, io.cpls.size(), io.exp_g.size()); continue; }
      for (size_t k = 0; k < io.cpls.size(); k++) if (io.cpls[k].cid != gx[io.exp_g[k]].cmd.cid) fail("node %d: completion %zu has cid %u, expected %u", n, k, io.cpls[k].cid, gx[io.exp_g[k]].cmd.cid);
    }
    // 2. leaf streams: ordering rules
    for (int p = 0; p < LV; p++) {
      int64_t lastc = -1; std::map<uint16_t, uint32_t> nxt; std::map<uint16_t, bool> ended;
      for (auto& rb : snk[p].rx) {
        const Beat& b = rb.b;
        if (!g_of_cid.count(b.cid)) { fail("leaf %d: beat for unknown cid %u", p, b.cid); continue; }
        if (lastc >= 0 && (int16_t)(uint16_t)(b.cid - (uint16_t)lastc) < 0) fail("leaf %d: cid went backwards", p);
        lastc = b.cid;
        if (b.pid != (p % FAN)) fail("leaf %d: pid %u", p, b.pid);
        if (ended[b.cid]) fail("leaf %d cid %u: beat after the end of the stream", p, b.cid);
        if (!b.err && b.idx != nxt[b.cid]) fail("leaf %d cid %u: idx %u expected %u", p, b.cid, b.idx, nxt[b.cid]);
        if (b.err) { if (!b.last || b.idx != nxt[b.cid]) fail("leaf %d cid %u: malformed terminator", p, b.cid); ended[b.cid] = true; }
        else { nxt[b.cid]++; if (b.last) ended[b.cid] = true; }
      }
    }
    // 3. per collective
    for (size_t gi = 0; gi < gx.size(); gi++) {
      const GExp& g = gx[gi]; const ref::CmdT& c = g.cmd;
      bool all_ok = true, any_expected = (g.exp_err == ref::E_OK); std::vector<int> codes;
      for (int n = 0; n < NC; n++) {
        for (size_t k = 0; k < nio[n].exp_g.size(); k++) if (nio[n].exp_g[k] == (int)gi && k < nio[n].cpls.size()) {
          const CplRec& r = nio[n].cpls[k]; codes.push_back(r.err);
          if (r.err != 0) all_ok = false;
          if (r.err == g.exp_err) any_expected = true;
          if (r.ok != (r.err == 0)) fail("node %d cid %u: ok/err inconsistent", n, c.cid);
        }
      }
      if (g.fault == F_NONE && !g.free_outcome && !all_ok) {
        std::string cs; for (int e : codes) { cs += ref::err_name(e); cs += " "; }
        fail("cid %u (clean, ctype %d op %d dt %d rm %d len %u): a node failed: %s", c.cid, c.ctype, c.op, c.dtype, c.rm, c.len, cs.c_str());
      }
      if (g.fault != F_NONE && g.exp_err != ref::E_OK && !g.free_outcome && !any_expected) fail("cid %u: no node reported the injected fault (%s, expected %s)", c.cid, fault_name(g.fault), ref::err_name(g.exp_err));
      // node-local flags of successful nodes
      if (all_ok) for (int n = 0; n < NC; n++) for (size_t k = 0; k < nio[n].exp_g.size(); k++) if (nio[n].exp_g[k] == (int)gi && k < nio[n].cpls.size())
        if (nio[n].cpls[k].flags != g.res.node_flags[n]) fail("node %d cid %u: flags 0x%x expected 0x%x", n, c.cid, nio[n].cpls[k].flags, g.res.node_flags[n]);
      // leaf receivers
      for (int p = 0; p < LV; p++) {
        std::vector<Beat> got; for (auto& rb : snk[p].rx) if (rb.b.cid == c.cid) got.push_back(rb.b);
        const bool is_recv = (c.recv >> p & 1);
        if (!is_recv) { if (!got.empty()) fail("cid %u leaf %d: %zu unexpected beats (not a receiver)", c.cid, p, got.size()); continue; }
        const std::vector<uint32_t>& want = g.res.leaf[p];
        size_t nd = 0; bool term = false;
        for (auto& b : got) { if (b.err) { term = true; continue; } if (nd < want.size() && b.data != want[nd]) fail("cid %u leaf %d elem %zu: got %08x want %08x", c.cid, p, nd, b.data, want[nd]); nd++; }
        if (all_ok) {
          if (nd != g.out_len) fail("cid %u leaf %d: %zu beats, expected %u", c.cid, p, nd, g.out_len);
          if (term) fail("cid %u leaf %d: terminator on a successful collective", c.cid, p);
          if (!got.empty() && !got.back().last) fail("cid %u leaf %d: last missing", c.cid, p);
        } else {
          if (nd > g.out_len) fail("cid %u leaf %d: too many beats", c.cid, p);
          if (c.len > 0 && nd < g.out_len && !term) missing_terms++;
          if (nd == g.out_len && term) fail("cid %u leaf %d: terminator after a complete stream", c.cid, p);
        }
      }
    }
    // terminators that could not be queued are counted by the nodes
    d->perf_sel = 22; d->eval(); uint64_t lost = 0;
    for (int n = 0; n < NC; n++) lost += getf(d->perf_all, n * 64, 32);
    if ((uint64_t)missing_terms > lost) fail("%d receiver(s) of failed collectives without a terminator; nodes counted %" PRIu64 " lost", missing_terms, lost);
  }
};

// ---------------------------------------------------------------------------------------------------- helpers
static uint64_t full_mask() { return LV >= 64 ? ~0ull : ((1ull << LV) - 1); }
static uint64_t rand_subset(Tt& t) { uint64_t m = 0; while (!m) m = t.rng() & full_mask(); return m; }
static uint64_t onehot(Tt& t) { return 1ull << t.rndi(0, LV - 1); }
static TSpec mkspec(Tt& t, int ctype, int op, int dt, uint32_t len) {
  TSpec s; s.ctype = ctype; s.op = op; s.dtype = dt; s.len = len;
  switch (ctype) {
    case CT_REDUCE:    s.send = (t.rnd() < 0.6) ? full_mask() : rand_subset(t); s.recv = onehot(t); break;
    case CT_BROADCAST: s.send = onehot(t); s.recv = (t.rnd() < 0.6) ? full_mask() : rand_subset(t); break;
    default:           s.send = (t.rnd() < 0.6) ? full_mask() : rand_subset(t); s.recv = (t.rnd() < 0.6) ? full_mask() : rand_subset(t); break;
  }
  return s;
}
static void finish(Tt& t, const char* tag) { t.run_until_idle(); t.check_all(tag); }
static void clean_recovery(Tt& t, int n = 1) {
  for (int i = 0; i < n; i++) { TSpec g = mkspec(t, CT_ALLREDUCE, t.rndi(0, 5), t.rndi(0, 1), (uint32_t)t.rndi(1, 12)); g.send = g.recv = full_mask(); t.collective(g); }
}

// ---------------------------------------------------------------------------------------------------- scenarios
static void t_tree_ops(Tt& t) {
  for (int rep = 0; rep < 2; rep++) for (int dt = DT_I32; dt <= DT_U32; dt++) for (int op = 0; op <= 5; op++) for (int ct : {CT_ALLREDUCE, CT_REDUCE}) {
    TSpec s = mkspec(t, ct, op, dt, (uint32_t)t.rndi(1, 17)); s.data_mode = t.rndi(0, 3); t.collective(s);
  }
  for (int dt = DT_I32; dt <= DT_U32; dt++) { TSpec s = mkspec(t, CT_BROADCAST, OP_COPY, dt, 9); t.collective(s); }
  if (TB_FP32_EN) for (int rm = 0; rm <= 4; rm++) { TSpec s = mkspec(t, CT_ALLREDUCE, OP_SUM, ref::DT_F32, 20); s.rm = rm; s.data_mode = 5 + rm % 3; t.collective(s); }
  finish(t, "ops");
}
static void t_tree_roots(Tt& t) {            // every leaf as root / as broadcaster / as the only receiver
  for (int p = 0; p < LV; p++) {
    TSpec a = mkspec(t, CT_REDUCE, OP_SUM, DT_I32, 7); a.send = full_mask(); a.recv = 1ull << p; t.collective(a);
    TSpec b = mkspec(t, CT_BROADCAST, OP_COPY, DT_U32, 7); b.send = 1ull << p; b.recv = full_mask(); t.collective(b);
    TSpec c = mkspec(t, CT_ALLREDUCE, ref::OP_MAX, DT_I32, 5); c.send = full_mask(); c.recv = 1ull << p; t.collective(c);
  }
  finish(t, "roots");
}
static void t_tree_overflow(Tt& t) {         // node-local OVF flags and wrap-around through the tree
  for (int rep = 0; rep < 6; rep++) for (int dt = DT_I32; dt <= DT_U32; dt++) {
    TSpec s = mkspec(t, CT_ALLREDUCE, OP_SUM, dt, 12); s.data_mode = 3; s.send = s.recv = full_mask(); t.collective(s);
  }
  finish(t, "overflow");
}
static void t_tree_sequential(Tt& t) {
  for (int i = 0; i < 60; i++) {
    int ct = t.rndi(0, 2); TSpec s = mkspec(t, ct, ct == CT_BROADCAST ? OP_COPY : t.rndi(0, 5), t.rndi(0, 1), (uint32_t)t.rndi(1, 40)); s.data_mode = t.rndi(0, 3);
    for (int p = 0; p < LV; p++) s.p_send[p] = t.rnd() < 0.5 ? 1.0 : 0.3;
    t.collective(s);
  }
  finish(t, "sequential");
}
static void t_tree_backpressure(Tt& t) {
  const double lv[] = {1.0, 0.6, 0.25, 0.07};
  for (int round = 0; round < 8; round++) {
    for (int p = 0; p < LV; p++) t.snk[p].p_ready = lv[t.rndi(0, 3)];
    for (int n = 0; n < NC; n++) { t.nio[n].p_cmd = lv[t.rndi(0, 3)]; t.nio[n].p_cpl = lv[t.rndi(0, 3)]; }
    for (int k = 0; k < 3; k++) { TSpec s = mkspec(t, t.rndi(0, 2), 0, t.rndi(0, 1), (uint32_t)t.rndi(1, 40)); s.op = s.ctype == CT_BROADCAST ? OP_COPY : t.rndi(0, 5); for (int p = 0; p < LV; p++) s.p_send[p] = lv[t.rndi(0, 3)]; t.collective(s); }
    finish(t, "backpressure");
  }
}
static void t_tree_delayed(Tt& t) {
  for (int rep = 0; rep < 5; rep++) {
    TSpec s = mkspec(t, CT_ALLREDUCE, t.rndi(0, 5), t.rndi(0, 1), (uint32_t)t.rndi(4, 40)); s.send = s.recv = full_mask();
    for (int p = 0; p < LV; p++) { s.start_delay[p] = (rep % 2) ? t.rndi(0, 500) : (p == rep % LV ? 400 : 0); s.p_send[p] = (p % 2) ? 0.2 : 1.0; }
    t.collective(s);
  }
  finish(t, "delayed");
}
// the control plane is late and uneven: leaves stream long before some nodes have their command; the root command comes last
static void t_tree_cmd_skew(Tt& t) {
  for (int rep = 0; rep < 6; rep++) {
    for (int n = 0; n < NC; n++) { t.nio[n].hold_until = (int64_t)t.cyc + t.rndi(0, 400); t.nio[n].p_cmd = (t.rnd() < 0.5) ? 1.0 : 0.05; }
    for (int k = 0; k < 3; k++) { TSpec s = mkspec(t, t.rndi(0, 2), 0, t.rndi(0, 1), (uint32_t)t.rndi(1, 25)); s.op = s.ctype == CT_BROADCAST ? OP_COPY : t.rndi(0, 5); t.collective(s); }
    finish(t, "cmd_skew");
  }
}
static void t_tree_faults(Tt& t) {
  t.cfg_timeout = 500;
  const int faults[] = {F_DROP, F_DUP, F_BAD_PID, F_BAD_DT, F_BAD_OP, F_BAD_LAST, F_EARLY_LAST, F_ERR_FLAG, F_EXTRA, F_STOP, F_BAD_DATA_DUP};
  for (int f : faults) for (int rep = 0; rep < 2; rep++) {
    const int len = t.rndi(4, 20);
    int at = t.rndi(0, len - 2);
    if (f == F_BAD_LAST || f == F_ERR_FLAG || f == F_BAD_PID || f == F_BAD_DT || f == F_BAD_OP) at = t.rndi(0, len - 1);
    TSpec s = mkspec(t, CT_ALLREDUCE, t.rndi(0, 5), t.rndi(0, 1), (uint32_t)len); s.send = s.recv = full_mask();
    s.fault_leaf = t.rndi(0, LV - 1); s.fault = f; s.fault_at = at;
    t.collective(s);
    clean_recovery(t, 2);                                    // the next collectives must be unaffected
  }
  finish(t, "faults");
}
static void t_tree_part_fail(Tt& t) {
  for (int p = 0; p < LV; p += std::max(1, LV / 4)) {
    TSpec s = mkspec(t, CT_ALLREDUCE, OP_SUM, DT_I32, 40); s.send = s.recv = full_mask();
    for (int q = 0; q < LV; q++) s.p_send[q] = 0.1;
    t.collective(s); t.gx.back().free_outcome = true;                       // outcome is the injected failure
    t.run_cycles(t.rndi(30, 150)); t.part_fail = 1u << p; t.run_until_idle(); t.part_fail = 0;
    clean_recovery(t, 1);
    t.run_until_idle();
  }
  t.check_all("part_fail");
  // the leaf node that owns the failed leaf must have reported it
  bool seen = false;
  for (int n = 0; n < NC; n++) for (auto& c : t.nio[n].cpls) if (c.err == ref::E_PART_FAIL) seen = true;
  if (!seen) t.fail("part_fail: no node reported E_PART_FAIL");
}
static void t_tree_abort(Tt& t) {
  for (int k = 0; k < 3; k++) {
    TSpec s = mkspec(t, CT_ALLREDUCE, OP_SUM, DT_I32, 50); s.send = s.recv = full_mask(); for (int q = 0; q < LV; q++) s.p_send[q] = 0.15;
    t.collective(s); t.gx.back().free_outcome = true; t.run_cycles(t.rndi(20, 200)); t.abort_pulse = true; t.run_until_idle();
    clean_recovery(t, 1); t.run_until_idle();
  }
  t.check_all("abort");
  bool seen = false;
  for (int n = 0; n < NC; n++) for (auto& c : t.nio[n].cpls) if (c.err == ref::E_ABORT) seen = true;
  if (!seen) t.fail("abort: no node reported E_ABORT");
}
static void t_tree_reset(Tt& t) {
  for (int k = 0; k < 20; k++) {
    t.hard_reset(); t.cfg_timeout = (k % 3 == 0) ? 400 : 0;
    for (int p = 0; p < LV; p++) t.snk[p].p_ready = (k % 2) ? 0.3 : 1.0;
    for (int i = 0; i < t.rndi(1, 3); i++) { TSpec s = mkspec(t, CT_ALLREDUCE, t.rndi(0, 5), t.rndi(0, 1), (uint32_t)t.rndi(4, 30)); s.send = s.recv = full_mask(); for (int q = 0; q < LV; q++) s.p_send[q] = 0.5; t.collective(s); }
    t.run_cycles(t.rndi(1, 200));
    t.async_reset_midcycle();
    t.cfg_timeout = 0; for (int p = 0; p < LV; p++) t.snk[p].p_ready = 1.0;
    clean_recovery(t, 1); finish(t, "reset");
  }
}
static void t_tree_random(Tt& t) {
  for (int round = 0; round < 10; round++) {
    const double lv[] = {1.0, 0.7, 0.3, 0.1};
    for (int p = 0; p < LV; p++) t.snk[p].p_ready = lv[t.rndi(0, 3)];
    for (int n = 0; n < NC; n++) { t.nio[n].p_cmd = lv[t.rndi(0, 3)]; t.nio[n].p_cpl = lv[t.rndi(0, 3)]; }
    for (int i = 0; i < t.rndi(1, 6); i++) {
      int ct = t.rndi(0, 2); TSpec s = mkspec(t, ct, ct == CT_BROADCAST ? OP_COPY : t.rndi(0, 5), t.rndi(0, 1), (uint32_t)t.rndi(0, 60)); s.data_mode = t.rndi(0, 3);
      for (int p = 0; p < LV; p++) { s.p_send[p] = lv[t.rndi(0, 3)]; s.start_delay[p] = t.rnd() < 0.2 ? t.rndi(0, 80) : 0; }
      t.collective(s);
    }
    finish(t, "random");
  }
}
static void t_tree_random_faults(Tt& t) {
  t.cfg_timeout = 400;
  for (int round = 0; round < 12; round++) {
    const double lv[] = {1.0, 0.6, 0.2};
    for (int p = 0; p < LV; p++) t.snk[p].p_ready = lv[t.rndi(0, 2)];
    for (int i = 0; i < t.rndi(2, 6); i++) {
      int ct = t.rndi(0, 2); TSpec s = mkspec(t, ct, ct == CT_BROADCAST ? OP_COPY : t.rndi(0, 5), t.rndi(0, 1), (uint32_t)t.rndi(1, 30));
      for (int p = 0; p < LV; p++) s.p_send[p] = lv[t.rndi(0, 2)];
      bool faulty = t.rnd() < 0.5;
      if (faulty) { const int cand[] = {F_DROP, F_DUP, F_BAD_PID, F_BAD_DT, F_BAD_OP, F_BAD_LAST, F_EARLY_LAST, F_ERR_FLAG, F_EXTRA, F_STOP, F_BAD_DATA_DUP};
        for (int p = 0; p < LV; p++) if (s.send >> p & 1) { s.fault_leaf = p; break; }
        s.fault = cand[t.rndi(0, 10)]; s.fault_at = t.rndi(0, (int)s.len - 1); }
      t.collective(s);
      t.gx.back().free_outcome = true;
      if (faulty) t.gx.back().exp_err = ref::E_OK;
    }
    finish(t, "random_faults");
  }
}


// latency / throughput of an all-reduce across the tree (cycles from the first command to the last result beat at the leaves)
static void t_tree_perf(Tt& t) {
  for (int len : {1, 16, 64, 256}) {
    if (len > TB_MAXLEN) continue;
    t.hard_reset(); t.cfg_timeout = 0; for (int p = 0; p < LV; p++) t.snk[p].p_ready = 1.0;
    for (int n = 0; n < NC; n++) { t.nio[n].p_cmd = 1.0; t.nio[n].p_cpl = 1.0; }
    TSpec s = mkspec(t, CT_ALLREDUCE, OP_SUM, DT_I32, (uint32_t)len); s.send = s.recv = full_mask(); s.dtype = DT_I32;
    const uint64_t c0 = t.cyc; t.collective(s); t.run_until_idle(); t.check_all("perf");
    uint64_t last = 0, firstb = ~0ull; for (int p = 0; p < LV; p++) { if (!t.snk[p].rx.empty()) { last = std::max(last, t.snk[p].rx.back().cyc); firstb = std::min(firstb, t.snk[p].rx.front().cyc); } }
    uint64_t lastcpl = 0; for (int n = 0; n < NC; n++) for (auto& c : t.nio[n].cpls) lastcpl = std::max(lastcpl, c.cyc);
    printf("PERF,tree,FAN=%d,H=%d,leaves=%d,nodes=%d,len=%d,cycles_to_last_result_beat=%" PRIu64 ",cycles_to_first_result_beat=%" PRIu64 ",cycles_to_last_completion=%" PRIu64 ",result_elem_per_cycle=%.4f\n",
           FAN, HT, LV, NC, len, last - c0, firstb - c0, lastcpl - c0, (double)len / (double)(last - firstb + 1));
  }
}

struct TDef { const char* name; void (*fn)(Tt&); };
static const TDef TESTS[] = {
  {"ops", t_tree_ops}, {"roots", t_tree_roots}, {"overflow", t_tree_overflow}, {"sequential", t_tree_sequential}, {"backpressure", t_tree_backpressure},
  {"delayed", t_tree_delayed}, {"cmd_skew", t_tree_cmd_skew}, {"faults", t_tree_faults}, {"part_fail", t_tree_part_fail}, {"abort", t_tree_abort},
  {"reset", t_tree_reset}, {"random", t_tree_random}, {"random_faults", t_tree_random_faults}, {"perf", t_tree_perf},
};

int main(int argc, char** argv) {
  VerilatedContext* ctx = new VerilatedContext; ctx->commandArgs(argc, argv);
  uint64_t seed = 1; std::string only = "all"; bool list = false, quiet = false;
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--seed") && i + 1 < argc) seed = strtoull(argv[++i], nullptr, 0);
    else if (!strcmp(argv[i], "--test") && i + 1 < argc) only = argv[++i];
    else if (!strcmp(argv[i], "--list")) list = true; else if (!strcmp(argv[i], "--quiet")) quiet = true;
  }
  if (list) { for (auto& t : TESTS) printf("%s\n", t.name); return 0; }
  Vsf_collective_tree_sim* dut = new Vsf_collective_tree_sim(ctx);
  Tt tb(dut); tb.quiet = quiet;
  int failed = 0, ran = 0; uint64_t total_colls = 0, total_cycles = 0;
  for (auto& t : TESTS) {
    if (only != "all" && only != t.name) continue;
    tb.hard_reset(); tb.errors = 0; tb.cfg_timeout = 0; tb.next_cid = (uint16_t)(1 + (seed * 7919) % 20000);
    for (int p = 0; p < 64; p++) tb.snk[p].p_ready = 1.0;
    uint64_t h = 1469598103934665603ull; for (const char* c = t.name; *c; c++) h = (h ^ (uint8_t)*c) * 1099511628211ull;
    tb.rng.seed(seed * 0x9E3779B97F4A7C15ull ^ h);
    const uint64_t c0 = tb.cyc; t.fn(tb); ran++; total_colls += tb.gx.size(); total_cycles += tb.cyc - c0;
    printf("  %-16s %s  (%" PRIu64 " cycles, %zu collectives)\n", t.name, tb.errors ? "FAIL" : "pass", tb.cyc - c0, tb.gx.size());
    if (tb.errors) { failed++; printf("    %d error(s)\n", tb.errors); }
  }
  printf("RESULT: %s  tests=%d failed=%d seed=%" PRIu64 " tree FAN=%d H=%d leaves=%d nodes=%d colls=%" PRIu64 " cycles=%" PRIu64 " beats_in=%" PRIu64 " beats_out=%" PRIu64 "\n",
         failed ? "FAIL" : "PASS", ran, failed, seed, FAN, HT, LV, NC, total_colls, total_cycles, tb.beats_in, tb.beats_out);
  dut->final(); delete dut; delete ctx;
  return failed ? 1 : 0;
}
