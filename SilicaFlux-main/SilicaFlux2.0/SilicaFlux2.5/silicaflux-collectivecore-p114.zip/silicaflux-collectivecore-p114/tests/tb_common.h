// =============================================================================
// SilicaFlux CollectiveCore (Project 114) -- bench pieces shared by the flat-node and the tree benches
//   bit-field access to flattened Verilator ports, stream beats, scripted sources with fault injection, sinks, expectations
// =============================================================================
#pragma once
#include "verilated.h"
#include "sf_coll_ref.h"
#include <deque>
#include <map>
#include <random>
#include <string>
#include <functional>
#include <type_traits>
#include <cinttypes>
#include <cstdarg>

// ------------------------------------------------------------------ bit-field access to flattened Verilator ports
template <typename T, typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
inline void setf(T& s, int lsb, int w, uint64_t v) {
  const uint64_t m = (w >= 64) ? ~0ull : ((1ull << w) - 1);
  uint64_t cur = (uint64_t)s;
  cur = (cur & ~(m << lsb)) | ((v & m) << lsb);
  s = (T)cur;
}
// 64-bit fields at arbitrary offsets of wide vectors
template <typename T> inline void setf64(T& s, int lsb, uint64_t v) { setf(s, lsb, 32, v & 0xFFFFFFFFull); setf(s, lsb + 32, 32, v >> 32); }
template <size_t N>
inline void setf(VlWide<N>& s, int lsb, int w, uint64_t v) {
  const int wi = lsb / 32, off = lsb % 32;
  const uint64_t m = (w >= 32) ? 0xFFFFFFFFull : ((1ull << w) - 1);
  uint64_t cur = (uint64_t)s[wi] | ((wi + 1 < (int)N) ? ((uint64_t)s[wi + 1] << 32) : 0);
  cur = (cur & ~(m << off)) | ((v & m) << off);
  s[wi] = (uint32_t)cur;
  if (wi + 1 < (int)N) s[wi + 1] = (uint32_t)(cur >> 32);
}
template <typename T, typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
inline uint64_t getf(const T& s, int lsb, int w) {
  const uint64_t m = (w >= 64) ? ~0ull : ((1ull << w) - 1);
  return ((uint64_t)s >> lsb) & m;
}
template <size_t N>
inline uint64_t getf(const VlWide<N>& s, int lsb, int w) {
  const int wi = lsb / 32, off = lsb % 32;
  const uint64_t m = (w >= 32) ? 0xFFFFFFFFull : ((1ull << w) - 1);
  uint64_t cur = (uint64_t)s[wi] | ((wi + 1 < (int)N) ? ((uint64_t)s[wi + 1] << 32) : 0);
  return (cur >> off) & m;
}

// ------------------------------------------------------------------ beats
struct Beat {
  uint16_t cid = 0; uint8_t pid = 0; uint32_t idx = 0; uint8_t dt = 0, op = 0; uint32_t data = 0; bool last = false, err = false;
  bool operator==(const Beat& o) const {
    return cid == o.cid && pid == o.pid && idx == o.idx && dt == o.dt && op == o.op && data == o.data && last == o.last && err == o.err;
  }
};

enum Fault { F_NONE = 0, F_DROP, F_DUP, F_BAD_PID, F_BAD_DT, F_BAD_OP, F_BAD_LAST, F_EARLY_LAST, F_ERR_FLAG, F_EXTRA, F_STOP, F_BAD_DATA_DUP };
inline const char* fault_name(int f) {
  static const char* n[] = {"none", "drop", "dup", "bad_pid", "bad_dtype", "bad_op", "bad_last", "early_last", "err_flag", "extra", "stop", "dup_other"};
  return n[f];
}
// error code the core must report for a fault injected at element `at` of a stream of `len` elements (single fault per collective)
inline int fault_expected_err(int f, int at, int len) {
  switch (f) {
    case F_DROP:       return (at == len - 1) ? ref::E_TIMEOUT : ref::E_SEQ;   // dropping the last element = missing data
    case F_DUP: case F_BAD_DATA_DUP: return ref::E_DUP;
    case F_BAD_PID: case F_BAD_DT: case F_BAD_OP: return ref::E_HDR;
    case F_BAD_LAST: case F_EARLY_LAST: case F_EXTRA: return ref::E_LEN;
    case F_ERR_FLAG:   return ref::E_PEER;
    case F_STOP:       return ref::E_TIMEOUT;
    default:           return ref::E_OK;
  }
}

struct Job {
  std::vector<Beat> script;
  int start_delay = 0;          // cycles to wait before the first beat of this job
  double p_send = 1.0;          // probability, per cycle, of starting the next beat
};

struct Source {
  std::deque<Job> jobs;
  size_t bi = 0;
  int delay = 0; bool delay_armed = false;
  bool valid = false; Beat cur;
  uint64_t sent = 0;
  bool idle() const { return jobs.empty() && !valid; }
};

struct RxBeat { Beat b; uint64_t cyc; };

struct Sink {
  double p_ready = 1.0;
  int64_t stall_until = -1;     // never ready before this cycle
  bool never = false;           // never ready
  std::vector<RxBeat> rx;
  bool prev_stall = false; Beat prev;
};

struct CplRec {
  uint16_t cid; bool ok; int err; int ctype; uint32_t flags, maskA, maskB, len, cycles; uint64_t cyc;
};

// ------------------------------------------------------------------ expectations
struct Exp {
  ref::Cmd cmd;
  int exp_err = ref::E_OK;          // expected completion error (known by construction); -1 = either OK-and-exact or any error
  int64_t exp_maskA = -1;           // expected cpl_maskA, -1 = do not check
  int64_t exp_maskB = -1;
  bool have_result = false;
  ref::Result res;
  std::string name;
};

// ------------------------------------------------------------------ data generators (modes 0..4 integer, 5..7 FP32)
inline uint32_t fp_normal(std::mt19937_64& r) { return ((uint32_t)(r() & 1) << 31) | ((uint32_t)(100 + r() % 60) << 23) | (uint32_t)(r() & 0x7FFFFF); }
inline uint32_t fp_special(std::mt19937_64& r) {
  static const uint32_t sp[] = {0x00000000u, 0x80000000u, 0x3F800000u, 0xBF800000u, 0x7F800000u, 0xFF800000u, 0x7FC00000u, 0x7FA00001u, 0xFFC12345u, 0xFF800001u,
                                0x00000001u, 0x807FFFFFu, 0x7F7FFFFFu, 0xFF7FFFFFu, 0x00800000u, 0x80800000u, 0x007FFFFFu, 0x7F000000u, 0x4B800000u, 0xCB800000u};
  return sp[r() % (sizeof sp / sizeof sp[0])];
}
inline uint32_t fp_cancel(std::mt19937_64& r) {
  static const int ex[] = {127 - 30, 127, 127 + 24, 127 + 25, 127 + 60, 127 + 1};
  return ((uint32_t)(r() & 1) << 31) | ((uint32_t)ex[r() % 6] << 23) | ((r() & 1) ? (uint32_t)(r() & 0x7FFFFF) : 0u);
}
inline std::vector<uint32_t> tb_rand_vec(std::mt19937_64& r, int n, int mode) {
  std::vector<uint32_t> v(n);
  for (int i = 0; i < n; i++) {
    switch (mode) {
      case 0: v[i] = (uint32_t)r(); break;                                              // full range
      case 1: v[i] = (uint32_t)((int32_t)(r() % 2001) - 1000); break;                   // small signed
      case 2: v[i] = (uint32_t)(r() % 17); break;                                       // small non-negative
      case 3: { static const uint32_t sp[] = {0u, 1u, 0xFFFFFFFFu, 0x7FFFFFFFu, 0x80000000u, 0x80000001u, 0x55555555u, 0xAAAAAAAAu};
                v[i] = sp[r() % 8]; } break;                                            // corner values
      case 4: v[i] = 0; break;
      case 5: v[i] = fp_normal(r); break;                                                // FP32: normal numbers, moderate exponent range
      case 6: v[i] = (r() % 10 < 6) ? fp_special(r) : fp_normal(r); break;              // FP32: specials (NaN, Inf, +-0, subnormals, extremes) mixed in
      case 7: v[i] = fp_cancel(r); break;                                                // FP32: magnitudes that cancel / absorb each other
      default: v[i] = (uint32_t)r(); break;
    }
  }
  return v;
}


