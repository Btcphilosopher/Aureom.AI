// =============================================================================
// SilicaFlux CollectiveCore (Project 114) -- independent software reference model
//
// Written from the semantics in docs/02_ABI.md / docs/03_NUMERICS.md, not by transcribing the RTL: integer operators are
// evaluated in 64-bit arithmetic over the exact values (so overflow is observed, not assumed), the tree-shaped FP32 reduction
// is a recursive definition over participant ranges (the RTL is a flat three-level array of nodes), results are produced
// per receiving participant by plain vector slicing.  Shares NO code with the RTL.
// =============================================================================
#pragma once
#include <cstdint>
#include <cstring>
#include <vector>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#ifdef TB_FP32
extern "C" {
#include "softfloat.h"
}
#endif

namespace ref {

// ---- ABI constants (docs/02_ABI.md; scripts/check_abi.py compares them with sf_collective_pkg.sv)
enum { CT_REDUCE = 0, CT_BROADCAST = 1, CT_ALLREDUCE = 2, CT_REDSCAT = 3, CT_ALLGATHER = 4 };
enum { OP_SUM = 0, OP_MIN = 1, OP_MAX = 2, OP_AND = 3, OP_OR = 4, OP_XOR = 5, OP_COPY = 6 };
enum { DT_I32 = 0, DT_U32 = 1, DT_F32 = 2 };
enum { E_OK = 0, E_CMD_TYPE = 1, E_CMD_OP = 2, E_CMD_LEN = 3, E_CMD_MASK = 4, E_CMD_CID = 5, E_TIMEOUT = 6, E_PART_FAIL = 7,
       E_SEQ = 8, E_DUP = 9, E_HDR = 10, E_LEN = 11, E_PEER = 12, E_ABORT = 13, E_INTERNAL = 14 };
enum { FL_NX = 0, FL_UF = 1, FL_OF = 2, FL_DZ = 3, FL_NV = 4, FL_INT_OVF = 5 };

inline const char* err_name(int e) {
  static const char* n[] = {"OK", "CMD_TYPE", "CMD_OP", "CMD_LEN", "CMD_MASK", "CMD_CID", "TIMEOUT", "PART_FAIL",
                            "SEQ", "DUP", "HDR", "LEN", "PEER", "ABORT", "INTERNAL", "?"};
  return n[e & 15];
}

struct Cmd {
  uint16_t cid = 0;
  int ctype = CT_ALLREDUCE, op = OP_SUM, dtype = DT_I32, rm = 0;
  uint8_t send = 0, recv = 0;
  uint32_t len = 0;
  uint64_t pack() const {
    return (uint64_t)cid | ((uint64_t)ctype << 16) | ((uint64_t)op << 19) | ((uint64_t)dtype << 22) | ((uint64_t)rm << 24) |
           ((uint64_t)send << 27) | ((uint64_t)recv << 35) | ((uint64_t)len << 43);
  }
};

inline int popc(unsigned m) { int n = 0; while (m) { n += m & 1; m >>= 1; } return n; }

// ---- configuration of the build under test (command validation depends on it)
struct Build { int np = 2; uint32_t max_len = 4096; bool redscat = false, allgather = false, fp32 = false, interior = false; };

// ---- expected verdict of the command queue (independent re-statement of the rules of docs/02_ABI.md section 5)
inline int validate(const Cmd& c, const Build& b) {
  const int ns = popc(c.send), nr = popc(c.recv);
  const unsigned valid_bits = (b.np >= 8) ? 0xFFu : ((1u << b.np) - 1u);
  if (c.ctype > CT_ALLGATHER || (c.ctype == CT_REDSCAT && !b.redscat) || (c.ctype == CT_ALLGATHER && !b.allgather) ||
      (b.interior && (c.ctype == CT_REDSCAT || c.ctype == CT_ALLGATHER)))
    return E_CMD_TYPE;
  const bool copy_type = (c.ctype == CT_BROADCAST || c.ctype == CT_ALLGATHER);
  bool op_ok;
  if (c.dtype > DT_F32) op_ok = false;
  else if (copy_type) op_ok = (c.op == OP_COPY);
  else if (c.op > OP_XOR) op_ok = false;
  else if (c.dtype == DT_F32) op_ok = b.fp32 && c.op == OP_SUM;
  else op_ok = true;
  if (!op_ok || (c.dtype == DT_F32 && c.op == OP_SUM && c.rm > 4)) return E_CMD_OP;
  if (c.len > b.max_len || (c.ctype == CT_REDSCAT && nr != 0 && (c.len % nr) != 0)) return E_CMD_LEN;
  if ((c.send & ~valid_bits) || (c.recv & ~valid_bits)) return E_CMD_MASK;
  if (b.interior) {
    if (ns == 0 && nr == 0) return E_CMD_MASK;
    if (c.ctype == CT_REDUCE && nr > 1) return E_CMD_MASK;
    if (c.ctype == CT_BROADCAST && ns > 1) return E_CMD_MASK;
  } else {
    if (ns == 0 || nr == 0) return E_CMD_MASK;
    if (c.ctype == CT_REDUCE && nr != 1) return E_CMD_MASK;
    if (c.ctype == CT_BROADCAST && ns != 1) return E_CMD_MASK;
  }
  return E_OK;
}

// ---- reduction of ONE element
struct Elem { bool present = false; uint32_t v = 0; };

#ifdef TB_FP32
inline uint32_t canon(uint32_t r) { return ((r & 0x7F800000u) == 0x7F800000u && (r & 0x007FFFFFu)) ? 0x7FC00000u : r; }
inline void set_rm(int rm) {
  static const uint_fast8_t map[5] = {softfloat_round_near_even, softfloat_round_minMag, softfloat_round_min, softfloat_round_max, softfloat_round_near_maxMag};
  softfloat_roundingMode = map[rm];
}
inline uint32_t fp_add(uint32_t a, uint32_t b, int rm, uint32_t& flags) {
  set_rm(rm);
  softfloat_exceptionFlags = 0;
  float32_t x, y; x.v = a; y.v = b;
  float32_t z = f32_add(x, y);
  flags |= softfloat_exceptionFlags & 0x1F;       // SoftFloat: inexact=1, underflow=2, overflow=4, infinite(DZ)=8, invalid=16 == {NX,UF,OF,DZ,NV}
  return canon(z.v);
}
#endif

// Balanced binary tree over participant range [lo, hi) (power-of-two aligned halves), absent leaves skipped.
inline Elem tree(const std::vector<Elem>& leaf, int lo, int hi, int op, int dt, int rm, uint32_t& flags) {
  if (hi - lo == 1) return leaf[lo];
  const int mid = (lo + hi) / 2;
  Elem a = tree(leaf, lo, mid, op, dt, rm, flags), b = tree(leaf, mid, hi, op, dt, rm, flags);
  if (a.present && b.present) {
    Elem r; r.present = true;
#ifdef TB_FP32
    if (dt == DT_F32) { r.v = fp_add(a.v, b.v, rm, flags); return r; }
#else
    (void)rm; (void)flags;
#endif
    // integer operators: evaluated in 64-bit, independent of the RTL's formulation
    const bool sg = (dt == DT_I32);
    int64_t x = sg ? (int64_t)(int32_t)a.v : (int64_t)a.v, y = sg ? (int64_t)(int32_t)b.v : (int64_t)b.v;
    switch (op) {
      case OP_SUM: r.v = (uint32_t)(uint64_t)(x + y); break;
      case OP_MIN: r.v = (uint32_t)(x < y ? x : y); break;
      case OP_MAX: r.v = (uint32_t)(x > y ? x : y); break;
      case OP_AND: r.v = a.v & b.v; break;
      case OP_OR:  r.v = a.v | b.v; break;
      case OP_XOR: r.v = a.v ^ b.v; break;
      default: std::abort();
    }
    return r;
  }
  return a.present ? a : b;
}

struct Result {
  uint32_t flags = 0;
  std::vector<uint32_t> full;                          // the full result vector (reduce types) / concatenation (gather)
  std::vector<std::vector<uint32_t>> port;             // expected stream per receiving participant (empty if not a receiver)
};

// Expected outputs of a collective whose senders streamed `in[p]` (len elements each; empty for non-senders).
inline Result compute(const Cmd& c, const Build& b, const std::vector<std::vector<uint32_t>>& in) {
  Result r;
  r.port.assign(b.np, {});
  int leaves = 1; while (leaves < b.np) leaves <<= 1;
  const int nr = popc(c.recv);
  if (c.ctype == CT_ALLGATHER) {
    for (int p = 0; p < b.np; p++) if (c.send >> p & 1) r.full.insert(r.full.end(), in[p].begin(), in[p].begin() + c.len);
  } else {
    for (uint32_t i = 0; i < c.len; i++) {
      std::vector<Elem> leaf(leaves);
      for (int p = 0; p < b.np; p++) if (c.send >> p & 1) { leaf[p].present = true; leaf[p].v = in[p][i]; }
      Elem e = tree(leaf, 0, leaves, c.op, c.dtype, c.rm, r.flags);
      r.full.push_back(e.v);
      if (c.op == OP_SUM && c.dtype != DT_F32) {           // exact-sum overflow flag, order independent
        int64_t s = 0;
        for (int p = 0; p < b.np; p++) if (c.send >> p & 1) s += (c.dtype == DT_I32) ? (int64_t)(int32_t)in[p][i] : (int64_t)in[p][i];
        const bool ov = (c.dtype == DT_I32) ? (s < INT32_MIN || s > INT32_MAX) : (s > (int64_t)UINT32_MAX);
        if (ov) r.flags |= 1u << FL_INT_OVF;
      }
    }
  }
  int rank = 0;
  for (int p = 0; p < b.np; p++) {
    if (!(c.recv >> p & 1)) continue;
    if (c.ctype == CT_REDSCAT) {
      const uint32_t chunk = c.len / nr;
      r.port[p].assign(r.full.begin() + rank * chunk, r.full.begin() + (rank + 1) * chunk);
    } else {
      r.port[p] = r.full;
    }
    rank++;
  }
  return r;
}

// ---- hierarchical (tree-of-nodes) reference.  Node ids are linear, level 0 first, root last (as in sf_collective_tree_sim).  Node (l, i)
// reduces the values of its FAN children with the balanced tree over its FAN ports (padded to a power of two, absent children
// skipped); leaves are level -1.  For FAN = 2 this equals the flat balanced tree over all leaves; for other FAN it is a different but
// fixed association (only FP32 can tell).  Flags are NODE-LOCAL: node n's INT_OVF is the exact-sum test over the values that
// node n itself receives (its children's already wrapped results); FP flags are those of node n's own additions.
struct CmdT { uint16_t cid = 0; int ctype = CT_ALLREDUCE, op = OP_SUM, dtype = DT_I32, rm = 0; uint64_t send = 0, recv = 0; uint32_t len = 0; };
struct ResultT { std::vector<uint32_t> node_flags; std::vector<uint32_t> full; std::vector<std::vector<uint32_t>> leaf; };

inline int tree_cnt(int fan, int H, int l) { int n = 1; for (int k = 0; k < H - 1 - l; k++) n *= fan; return n; }
inline int tree_off(int fan, int H, int l) { int o = 0; for (int k = 0; k < l; k++) o += tree_cnt(fan, H, k); return o; }
inline int tree_nodes(int fan, int H) { return tree_off(fan, H, H); }

inline Elem tree_node(const std::vector<Elem>& leaf, int fan, int H, int level, int idx, const CmdT& c, std::vector<uint32_t>& nflags) {
  if (level < 0) return leaf[idx];
  const int id = tree_off(fan, H, level) + idx;
  int pw = 1; while (pw < fan) pw <<= 1;
  std::vector<Elem> ch(pw);
  for (int p = 0; p < fan; p++) ch[p] = tree_node(leaf, fan, H, level - 1, idx * fan + p, c, nflags);
  if (c.op == OP_SUM && c.dtype != DT_F32) {                    // node-local exact-sum overflow
    int64_t s = 0;
    for (int p = 0; p < fan; p++) if (ch[p].present) s += (c.dtype == DT_I32) ? (int64_t)(int32_t)ch[p].v : (int64_t)ch[p].v;
    const bool ov = (c.dtype == DT_I32) ? (s < INT32_MIN || s > INT32_MAX) : (s > (int64_t)UINT32_MAX);
    if (ov) nflags[id] |= 1u << FL_INT_OVF;
  }
  return tree(ch, 0, pw, c.op, c.dtype, c.rm, nflags[id]);
}

// Expected outputs of a collective on a FAN-ary tree of height H (leaves = FAN^H): `c.send` / `c.recv` are LEAF masks (up to 64 leaves).
inline ResultT compute_tree(const CmdT& c, int fan, int H, const std::vector<std::vector<uint32_t>>& in) {
  ResultT r; int leaves = 1; for (int i = 0; i < H; i++) leaves *= fan;
  r.leaf.assign(leaves, {}); r.node_flags.assign(tree_nodes(fan, H), 0);
  for (uint32_t i = 0; i < c.len; i++) {
    std::vector<Elem> lf(leaves);
    for (int p = 0; p < leaves; p++) if (c.send >> p & 1) { lf[p].present = true; lf[p].v = in[p][i]; }
    Elem e = tree_node(lf, fan, H, H - 1, 0, c, r.node_flags);
    r.full.push_back(e.v);
  }
  for (int p = 0; p < leaves; p++) if (c.recv >> p & 1) r.leaf[p] = r.full;
  return r;
}

}  // namespace ref
