// =============================================================================
// SilicaFlux CollectiveCore (Project 114) -- performance bench (flat node).  Every figure is read from the core's own hardware counters
// (sf_collective_perf) or from completion records; nothing is estimated.  Output: CSV lines "PERF,<workload>,<key>=<value>,..." on stdout.
// Workloads: peak, length sweep (latency), consumer back-pressure, participant imbalance, late participant, input-buffer depth, network jitter.
// =============================================================================
#include "tb_harness.h"
#include <cstring>
#include <algorithm>
using namespace ref;

static uint64_t perf(Tb& t, int idx) { t.d->perf_sel = idx; t.eval(); return t.d->perf_data; }

struct Cfg { const char* name; int len = 256, reps = 6; double sink = 1.0, jitter = 1.0; int slow_p = -1; double slow_rate = 1.0; int late_p = -1; int late = 0; int op = OP_SUM; int dt = DT_I32; int ct = CT_ALLREDUCE; };

static void measure(Tb& t, const Cfg& c) {
  t.hard_reset(); t.cfg_timeout = 0;
  for (int p = 0; p < NPT; p++) t.snk[p].p_ready = c.sink;
  t.d->perf_clear = 1; t.step(); t.d->perf_clear = 0; t.step();
  const uint64_t c0 = t.cyc;
  for (int i = 0; i < c.reps; i++) {
    Tb::Spec s; s.ctype = c.ct; s.op = c.ct == CT_BROADCAST ? OP_COPY : c.op; s.dtype = c.dt; s.len = c.len; s.rm = 0; s.data_mode = (c.dt == DT_F32) ? 5 : 0;
    s.send = (c.ct == CT_BROADCAST) ? 1 : (uint8_t)((1u << NPT) - 1); s.recv = (uint8_t)((1u << NPT) - 1);
    for (int p = 0; p < NPT; p++) { s.p_send[p] = (p == c.slow_p) ? c.slow_rate : c.jitter; if (p == c.late_p && i == 0) s.start_delay[p] = c.late; }
    t.collective(s);
  }
  t.run_until_idle(); t.check_all(c.name);
  const uint64_t wall = t.cyc - c0;
  const uint64_t act = perf(t, 1), el = perf(t, 2), bi = perf(t, 3), bo = perf(t, 4), st = perf(t, 5), os = perf(t, 6), fb = perf(t, 7);
  const uint64_t ok = perf(t, 8), lsum = perf(t, 11), lmax = perf(t, 12), iocc = perf(t, 14), iomax = perf(t, 15), oocc = perf(t, 16), oomax = perf(t, 17), imax = perf(t, 18), isum = perf(t, 19);
  const double a = act ? (double)act : 1.0;
  printf("PERF,%s,NP=%d,len=%d,reps=%d,wall_cycles=%" PRIu64 ",active=%" PRIu64 ",elems=%" PRIu64 ",beats_in=%" PRIu64 ",beats_out=%" PRIu64 ",bytes_in=%" PRIu64 ",bytes_out=%" PRIu64
         ",starve=%" PRIu64 ",out_stall=%" PRIu64 ",fork_block=%" PRIu64 ",coll_ok=%" PRIu64 ",lat_mean=%.1f,lat_max=%" PRIu64
         ",elem_per_active_cycle=%.4f,elem_per_wall_cycle=%.4f,eff_bytes_per_cycle=%.3f,starve_share=%.4f,out_stall_share=%.4f,in_occ_mean=%.3f,in_occ_max=%" PRIu64 ",out_occ_mean=%.3f,out_occ_max=%" PRIu64 ",imb_max=%" PRIu64 ",imb_mean=%.3f\n",
         c.name, NPT, c.len, c.reps, wall, act, el, bi, bo, bi * 4, bo * 4, st, os, fb, ok, ok ? (double)lsum / ok : 0.0, lmax,
         (double)el / a, (double)el / (double)wall, (double)(bo * 4) / (double)wall, (double)st / a, (double)os / a, (double)iocc / a, iomax, (double)oocc / a, oomax, imax, (double)isum / a);
  if (t.errors) printf("PERF_ERROR,%s,%d errors\n", c.name, t.errors);
}

int main(int argc, char** argv) {
  VerilatedContext* ctx = new VerilatedContext; ctx->commandArgs(argc, argv);
  uint64_t seed = 1; std::string only = "all";
  for (int i = 1; i < argc; i++) { if (!strcmp(argv[i], "--seed") && i + 1 < argc) seed = strtoull(argv[++i], nullptr, 0); else if (!strcmp(argv[i], "--only") && i + 1 < argc) only = argv[++i]; }
  Vsf_collective_core* dut = new Vsf_collective_core(ctx); Tb t(dut, ctx); t.quiet = true; t.rng.seed(seed);
  auto run = [&](Cfg c) { if (only == "all" || only == c.name) measure(t, c); };
  const bool fp = TB_FP32_EN;
  // 1. peak: long collectives back to back, nobody stalls
  run({"peak", 256, 8});
  // 2. latency vs length (one collective at a time is measured by lat_mean of a single-collective run)
  for (int len : {1, 2, 4, 8, 16, 64, 256, 1024}) { Cfg c = {"len_sweep", len, 1}; if (len > TB_MAXLEN) continue; run(c); }
  // 3. slow consumer
  for (double r : {0.5, 0.25, 0.1}) { Cfg c = {"sink_rate", 256, 4}; c.sink = r; run(c); }
  // 4. network jitter on every participant
  for (double r : {0.75, 0.5, 0.25}) { Cfg c = {"jitter", 256, 4}; c.jitter = r; run(c); }
  // 5. participant imbalance: one participant at a fraction of the others' rate
  for (double r : {0.5, 0.25, 0.1}) { Cfg c = {"imbalance", 256, 4}; c.slow_p = NPT - 1; c.slow_rate = r; run(c); }
  // 6. a late participant (starts N cycles after the others) in the first collective of the run
  for (int d : {50, 200, 800}) { Cfg c = {"late_participant", 256, 4}; c.late_p = NPT - 1; c.late = d; run(c); }
  // 7. broadcast and reduce-to-root
  { Cfg c = {"broadcast", 256, 4}; c.ct = CT_BROADCAST; run(c); }
  { Cfg c = {"reduce_root", 256, 4}; c.ct = CT_REDUCE; run(c); }
  // 8. FP32
  if (fp) { Cfg c = {"fp32_peak", 256, 8}; c.dt = DT_F32; run(c); for (int len : {1, 2, 4, 8, 16, 64, 256, 1024}) { if (len > TB_MAXLEN) continue; Cfg l = {"fp32_len_sweep", len, 1}; l.dt = DT_F32; run(l); } }
  dut->final(); delete dut; delete ctx; return 0;
}
