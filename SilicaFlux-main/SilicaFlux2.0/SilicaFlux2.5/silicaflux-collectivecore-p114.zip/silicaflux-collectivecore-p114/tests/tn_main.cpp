// =============================================================================
// SilicaFlux CollectiveCore (Project 114) -- network-adapter bench (sim/sf_collective_net_sim.sv)
//   participant 0 = local accelerator (direct stream ports), participant 1 = REMOTE node behind sf_collective_net_adapter.
//   The remote node model drives the transport: sequence-numbered beats with reordering (inside aligned blocks of WIN), duplicates
//   (in-window, already-delivered, whole stale transfers), lost beats, late start, error beats, link-down; it consumes the TX beats
//   with random readiness, returns credits late, and watches the completion acks.
// Checks: results of both participants against ref::compute (independent), exactly-once delivery (duplicates counted, never
//   combined), credit limit never exceeded, link failure -> E_PART_FAIL -> terminators -> clear -> clean recovery, acks.
// =============================================================================
#include "Vsf_collective_net_sim.h"
#include "tb_common.h"
#include <cstring>
#include <algorithm>

using ref::OP_SUM; using ref::DT_I32;
#ifndef TB_WIN
#define TB_WIN 8
#endif
#ifndef TB_CREDITS
#define TB_CREDITS 8
#endif
#ifndef TB_MAXLEN
#define TB_MAXLEN 300
#endif

struct TB_ {                       // one transport beat
  uint16_t xfer; uint32_t seq; uint8_t dt, op; uint32_t data; bool last, err;
};
struct AckRec { uint16_t cid; bool ok; int err; bool blamed; };

struct Tn {
  Vsf_collective_net_sim* d; uint64_t cyc = 0; std::mt19937_64 rng; int errors = 0; bool quiet = false;
  Source p0; Sink s0;                                         // participant 0
  // remote -> adapter
  std::deque<TB_> rq; bool rv = false; TB_ rcur{}; double p_rx = 1.0; int rx_hold = 0;
  // adapter -> remote (TX) and credits
  double p_txr = 1.0; std::vector<TB_> txrx; std::deque<uint64_t> credit_due; int credit_delay_max = 3; int outstanding = 0, max_outstanding = 0;
  bool tx_prev_stall = false; TB_ tx_prev{};
  std::vector<AckRec> acks; double p_ack = 1.0;
  // control plane
  std::deque<uint64_t> cmdq; bool cv = false; uint64_t cur = 0;
  std::vector<CplRec> cpls; double p_cpl = 1.0;
  struct G { ref::Cmd cmd; std::vector<std::vector<uint32_t>> in; ref::Result res; int exp_err = 0; bool free_outcome = false; int injected_dups = 0; };
  std::vector<G> gx; uint16_t next_cid = 1;
  uint32_t cfg_timeout = 0, link_timeout = 0; bool clear_pulse = false, down_pulse = false, abort_pulse = false;
  uint64_t n_dup = 0, n_stale = 0, n_reorder = 0, n_ack_lost = 0, injected_dups = 0, n_rx = 0, n_tx = 0;
  uint64_t max_cycles = 2000000;

  explicit Tn(Vsf_collective_net_sim* dd) : d(dd) {}
  double rnd() { return (double)(rng() >> 11) * (1.0 / 9007199254740992.0); }
  int rndi(int lo, int hi) { return lo + (int)(rng() % (uint64_t)(hi - lo + 1)); }
  void fail(const char* fmt, ...) __attribute__((format(printf, 2, 3))) {
    errors++;
    if (errors <= 20 && !quiet) { char b[512]; va_list ap; va_start(ap, fmt); vsnprintf(b, sizeof b, fmt, ap); va_end(ap); printf("    FAIL @%" PRIu64 ": %s\n", cyc, b); }
  }
  void half(int c) { d->clk = c; d->eval(); }
  void clear_state() {
    p0 = Source(); s0.rx.clear(); s0.prev_stall = false; rq.clear(); rv = false; txrx.clear(); credit_due.clear(); outstanding = 0; acks.clear();
    cmdq.clear(); cv = false; cpls.clear(); gx.clear(); clear_pulse = down_pulse = abort_pulse = false; tx_prev_stall = false;
  }
  void hard_reset() {
    d->rst_n = 0; d->cmd_valid = 0; d->p0_in_valid = 0; d->rx_valid = 0; d->cpl_ready = 0; d->p0_out_ready = 0; d->tx_ready = 0; d->tx_credit = 0; d->ack_ready = 0;
    d->ctl_clear = 0; d->link_down = 0; d->ctl_abort = 0; d->cfg_timeout = 0; d->link_timeout = 0;
    for (int i = 0; i < 3; i++) { half(0); half(1); cyc++; }
    half(0); d->rst_n = 1; half(0); clear_state();
  }

  void drive() {
    if (!cv && !cmdq.empty()) { cur = cmdq.front(); cv = true; }
    d->cmd_valid = cv; d->cmd_data = cur; d->cpl_ready = rnd() < p_cpl;
    if (!p0.valid && !p0.jobs.empty()) {
      Job& j = p0.jobs.front();
      if (!p0.delay_armed) { p0.delay = j.start_delay; p0.delay_armed = true; }
      if (p0.delay > 0) p0.delay--;
      else if (p0.bi < j.script.size() && rnd() < j.p_send) { p0.cur = j.script[p0.bi]; p0.valid = true; }
      else if (p0.bi >= j.script.size()) { p0.jobs.pop_front(); p0.bi = 0; p0.delay_armed = false; }
    }
    d->p0_in_valid = p0.valid; d->p0_in_cid = p0.cur.cid; d->p0_in_pid = p0.cur.pid; d->p0_in_idx = p0.cur.idx; d->p0_in_dtype = p0.cur.dt;
    d->p0_in_op = p0.cur.op; d->p0_in_data = p0.cur.data; d->p0_in_last = p0.cur.last; d->p0_in_err = p0.cur.err;
    d->p0_out_ready = rnd() < s0.p_ready;
    // remote transmitter
    if (!rv && !rq.empty()) { if (rx_hold > 0) rx_hold--; else if (rnd() < p_rx) { rcur = rq.front(); rv = true; } }
    d->rx_valid = rv; d->rx_xfer = rcur.xfer; d->rx_seq = rcur.seq; d->rx_dtype = rcur.dt; d->rx_op = rcur.op; d->rx_data = rcur.data; d->rx_last = rcur.last; d->rx_err = rcur.err;
    // remote receiver / credits / acks
    d->tx_ready = rnd() < p_txr;
    bool cr = !credit_due.empty() && credit_due.front() <= cyc; d->tx_credit = cr;
    d->ack_ready = rnd() < p_ack;
    d->cfg_timeout = cfg_timeout; d->link_timeout = link_timeout; d->ctl_clear = clear_pulse; d->link_down = down_pulse; d->ctl_abort = abort_pulse;
    clear_pulse = down_pulse = abort_pulse = false;
  }
  void sample() {
    if (cv && d->cmd_ready) { cv = false; cmdq.pop_front(); }
    if (p0.valid && d->p0_in_ready) { p0.valid = false; p0.bi++; if (p0.bi >= p0.jobs.front().script.size()) { p0.jobs.pop_front(); p0.bi = 0; p0.delay_armed = false; } }
    {  // p0 sink
      const bool v = d->p0_out_valid, r = d->p0_out_ready;
      Beat b; b.cid = d->p0_out_cid; b.pid = d->p0_out_pid; b.idx = d->p0_out_idx; b.data = d->p0_out_data; b.last = d->p0_out_last; b.err = d->p0_out_err;
      if (s0.prev_stall) { if (!v) fail("p0 out: valid dropped while stalled"); else if (!(b.cid == s0.prev.cid && b.idx == s0.prev.idx && b.data == s0.prev.data && b.last == s0.prev.last && b.err == s0.prev.err)) fail("p0 out: beat changed while stalled"); }
      s0.prev_stall = v && !r; s0.prev = b; if (v && r) s0.rx.push_back({b, cyc});
    }
    if (rv && d->rx_ready) { rv = false; rq.pop_front(); n_rx++; }
    if (d->tx_credit) { credit_due.pop_front(); outstanding--; }
    {  // transport TX beats
      const bool v = d->tx_valid, r = d->tx_ready;
      TB_ t{(uint16_t)d->tx_xfer, (uint32_t)d->tx_seq, 0, 0, (uint32_t)d->tx_data, (bool)d->tx_last, (bool)d->tx_err};
      if (tx_prev_stall) { if (!v) fail("tx: valid dropped while stalled"); else if (t.xfer != tx_prev.xfer || t.seq != tx_prev.seq || t.data != tx_prev.data || t.last != tx_prev.last || t.err != tx_prev.err) fail("tx: beat changed while stalled"); }
      tx_prev_stall = v && !r; tx_prev = t;
      if (v && r) {
        txrx.push_back(t); n_tx++; outstanding++; max_outstanding = std::max(max_outstanding, outstanding);
        if (outstanding > TB_CREDITS) fail("credit limit exceeded: %d outstanding > %d", outstanding, TB_CREDITS);
        credit_due.push_back(cyc + 1 + rng() % (credit_delay_max + 1));
        // the remote consumes the beat and returns the credit later
      }
    }
    if (d->ack_valid && d->ack_ready) acks.push_back({(uint16_t)d->ack_cid, (bool)d->ack_ok, (int)d->ack_err, (bool)d->ack_blamed});
    if (d->cpl_valid && d->cpl_ready) cpls.push_back({(uint16_t)d->cpl_cid, (bool)d->cpl_ok, (int)d->cpl_err, 0, (uint32_t)d->cpl_flags, (uint32_t)d->cpl_maskA, (uint32_t)d->cpl_maskB, 0, 0, cyc});
    n_dup += d->ev_dup; n_stale += d->ev_stale; n_reorder += d->ev_reorder; n_ack_lost += d->ev_ack_lost;
  }
  void step() { drive(); half(0); sample(); half(1); half(0); cyc++; }
  void run_cycles(int n) { for (int i = 0; i < n; i++) step(); }
  bool run_until_cpls(size_t n, uint64_t maxc = 200000) { const uint64_t st = cyc; while (cpls.size() < n && cyc - st < maxc) step(); if (cpls.size() < n) { fail("no completion after %" PRIu64 " cycles", maxc); return false; } return true; }
  bool idle_now() { return cmdq.empty() && !cv && p0.idle() && rq.empty() && !rv && cpls.size() == gx.size() && d->idle && !d->p0_out_valid && !d->ack_valid && credit_due.empty() && !d->tx_valid; }
  bool run_until_idle(uint64_t maxc = 0) {
    if (!maxc) maxc = max_cycles; const uint64_t st = cyc; int q = 0;
    while (cyc - st < maxc) { step(); if (idle_now()) { if (++q >= 12) return true; } else q = 0; }
    fail("HANG: not idle after %" PRIu64 " cycles (completions %zu of %zu)", maxc, cpls.size(), gx.size()); return false;
  }

  // ---- scenario construction
  struct Opt {
    int ctype = ref::CT_ALLREDUCE, op = OP_SUM, dtype = DT_I32; uint32_t len = 16; uint8_t send = 3, recv = 3;
    double dup_p = 0, reorder = 0; int drop_at = -1; int err_at = -1; int start_delay = 0; int p0_delay = 0; double p0_send = 1.0;
    bool stale_after = false;               // after the transfer, resend some of its beats (late retransmission)
    int exp_err = -2;                       // -2: derive (OK)
  };
  uint16_t collective(const Opt& o) {
    G g; ref::Cmd& c = g.cmd; c.cid = next_cid++; c.ctype = o.ctype; c.op = o.op; c.dtype = o.dtype; c.send = o.send; c.recv = o.recv; c.len = o.len; c.rm = 0;
    ref::Build b; b.np = 2; b.max_len = TB_MAXLEN;
    g.in.assign(2, {});
    for (int p = 0; p < 2; p++) if (c.send >> p & 1) g.in[p] = tb_rand_vec(rng, std::max<int>(c.len, 1), rndi(0, 3));
    g.res = ref::compute(c, b, g.in);
    // participant 0: direct stream
    if (c.send & 1) { Job j; j.start_delay = o.p0_delay; j.p_send = o.p0_send;
      for (uint32_t i = 0; i < c.len; i++) { Beat bb; bb.cid = c.cid; bb.pid = 0; bb.idx = i; bb.dt = c.dtype; bb.op = c.op; bb.data = g.in[0][i]; bb.last = (i == c.len - 1); j.script.push_back(bb); }
      p0.jobs.push_back(j); }
    // participant 1: transport beats with impairments
    if (c.send & 2) {
      std::vector<TB_> v;
      for (uint32_t i = 0; i < c.len; i++) { if ((int)i == o.drop_at) continue; v.push_back({c.cid, i, (uint8_t)c.dtype, (uint8_t)c.op, g.in[1][i], i == c.len - 1, false}); }
      if (o.err_at >= 0) { v.resize(std::min<size_t>(o.err_at, v.size())); v.push_back({c.cid, (uint32_t)o.err_at, (uint8_t)c.dtype, (uint8_t)c.op, 0, true, true}); }   // the peer gives up: error beat, nothing after it
      if (o.reorder > 0) for (size_t k = 0; k < v.size(); k += TB_WIN) { size_t e = std::min(v.size(), k + TB_WIN); if (rnd() < o.reorder) std::shuffle(v.begin() + k, v.begin() + e, rng); }
      std::vector<TB_> w;
      for (auto& x : v) { w.push_back(x); if (!x.err && rnd() < o.dup_p) { w.push_back(x); injected_dups++; g.injected_dups++; } }
      if (o.stale_after) for (int k = 0; k < 3 && !v.empty(); k++) { w.push_back(v[rng() % v.size()]); injected_dups++; g.injected_dups++; }
      // (stale re-sends of the finished transfer are placed before the NEXT transfer's beats: they follow this one in the queue)
      if (rq.empty() && !rv) rx_hold = o.start_delay;
      for (auto& x : w) rq.push_back(x);
    }
    g.exp_err = (o.exp_err == -2) ? 0 : o.exp_err;
    gx.push_back(g);
    cmdq.push_back(c.pack());
    return c.cid;
  }

  void check_all(const char* tag) {
    (void)tag;
    if (cpls.size() != gx.size()) { fail("completions %zu != collectives %zu", cpls.size(), gx.size()); return; }
    for (size_t i = 0; i < gx.size(); i++) {
      const G& g = gx[i]; const CplRec& c = cpls[i]; const ref::Cmd& m = g.cmd;
      if (c.cid != m.cid) fail("completion %zu: cid %u != %u", i, c.cid, m.cid);
      if (!g.free_outcome && (int)c.err != g.exp_err) fail("cid %u: completion %s, expected %s", m.cid, ref::err_name(c.err), ref::err_name(g.exp_err));
      // ack for every completion (advisory; the ack queue may drop on overflow, counted)
      bool got = false; for (auto& a : acks) if (a.cid == m.cid) { got = true; if (a.err != (int)c.err || a.ok != c.ok) fail("cid %u: ack {ok=%d err=%s} != completion {ok=%d err=%s}", m.cid, a.ok, ref::err_name(a.err), c.ok, ref::err_name(c.err)); }
      if (!got && n_ack_lost == 0) fail("cid %u: no completion ack reached the remote", m.cid);
      // participant 0 stream
      std::vector<Beat> got0; for (auto& rb : s0.rx) if (rb.b.cid == m.cid) got0.push_back(rb.b);
      // remote stream
      std::vector<TB_> got1; for (auto& t : txrx) if (t.xfer == m.cid) got1.push_back(t);
      for (int p = 0; p < 2; p++) {
        const bool is_recv = m.recv >> p & 1;
        const size_t n = (p == 0) ? got0.size() : got1.size();
        if (!is_recv) { if (n) fail("cid %u p%d: %zu unexpected beats", m.cid, p, n); continue; }
        const std::vector<uint32_t>& want = g.res.port[p];
        size_t nd = 0; bool term = false;
        for (size_t k = 0; k < n; k++) {
          const bool err = (p == 0) ? got0[k].err : got1[k].err; const uint32_t data = (p == 0) ? got0[k].data : got1[k].data; const uint32_t idx = (p == 0) ? got0[k].idx : got1[k].seq;
          if (err) { term = true; continue; }
          if (idx != nd) fail("cid %u p%d: beat %zu has index %u", m.cid, p, nd, idx);
          if (nd < want.size() && data != want[nd]) fail("cid %u p%d elem %zu: %08x != %08x", m.cid, p, nd, data, want[nd]);
          nd++;
        }
        if (c.err == 0) { if (nd != m.len || term) fail("cid %u p%d: %zu beats (expected %u)%s", m.cid, p, nd, m.len, term ? " + terminator" : ""); }
        else { if (nd > m.len) fail("cid %u p%d: too many beats", m.cid, p); if (m.len > 0 && nd < m.len && !term) fail("cid %u p%d: failed collective, %zu of %u beats and no terminator", m.cid, p, nd, m.len); }
      }
    }
  }
};

static void finish(Tn& t, const char* tag) { t.run_until_idle(); t.check_all(tag); }

// ------------------------------------------------------------------------------------------------ scenarios
static void t_inorder(Tn& t) {
  for (int i = 0; i < 8; i++) { Tn::Opt o; o.len = t.rndi(1, 40); o.op = t.rndi(0, 5); t.collective(o); }
  finish(t, "inorder");
}
// reordering inside the window, duplicates (stored, delivered, finished transfer), random readiness
static void t_reorder_dup(Tn& t) {
  for (int round = 0; round < 12; round++) {
    t.p_rx = (round % 3 == 0) ? 0.3 : 1.0; t.p_txr = (round % 2) ? 0.4 : 1.0; t.s0.p_ready = (round % 4 == 1) ? 0.3 : 1.0;
    for (int k = 0; k < 3; k++) {
      Tn::Opt o; o.len = t.rndi(1, 60); o.op = t.rndi(0, 5); o.reorder = 0.9; o.dup_p = 0.25; o.stale_after = (k == 2);
      o.ctype = (k == 1) ? ref::CT_REDUCE : ref::CT_ALLREDUCE; o.recv = (k == 1) ? 2 : 3;
      t.collective(o);
    }
    finish(t, "reorder_dup");
  }
  // every injected duplicate was consumed and counted exactly once (as in-window duplicate or as stale retransmission); none was combined (results exact)
  if (t.n_dup + t.n_stale != t.injected_dups) t.fail("duplicates counted %" PRIu64 " + stale %" PRIu64 " != injected %" PRIu64, t.n_dup, t.n_stale, t.injected_dups);
  if (t.n_reorder == 0) t.fail("no reordering was exercised");
}
static void t_late_remote(Tn& t) {
  for (int k = 0; k < 4; k++) { Tn::Opt o; o.len = t.rndi(4, 30); o.start_delay = t.rndi(100, 700); o.p0_delay = (k % 2) ? 300 : 0; t.collective(o); }
  t.link_timeout = 0; t.cfg_timeout = 0;                // a slow peer is not a failure when no watchdog is configured
  finish(t, "late_remote");
}
static void t_broadcast(Tn& t) {
  for (int k = 0; k < 6; k++) {
    Tn::Opt o; o.len = t.rndi(1, 30); o.ctype = ref::CT_BROADCAST; o.op = ref::OP_COPY; o.send = (k % 2) ? 2 : 1; o.recv = 3; o.reorder = 0.5; t.collective(o);
  }
  finish(t, "broadcast");
}
// a lost element: the link watchdog declares the participant failed, the core reports it, receivers get terminators, the peer is told, and after the clear the next collective runs
static void t_lost_beat(Tn& t) {
  t.link_timeout = 150;
  for (int k = 0; k < 4; k++) {
    Tn::Opt o; o.len = 20; o.drop_at = t.rndi(0, 19); o.exp_err = ref::E_PART_FAIL; t.collective(o);
    t.run_until_cpls(t.gx.size());                        // the failure is reported (record) while the link is still failed
    if (!t.d->fail_out) t.fail("lost beat: fail_out not asserted");
    if (!t.d->st_timeout) t.fail("lost beat: st_timeout not set");
    t.clear_pulse = true; t.run_cycles(3);                // control plane clears the link
    Tn::Opt g; g.len = 12; g.reorder = 0.5; t.collective(g);
    t.run_until_idle();
  }
  t.check_all("lost_beat");
  bool blamed = false; for (auto& a : t.acks) if (a.err == ref::E_PART_FAIL && a.blamed) blamed = true;
  if (!blamed) t.fail("no ack named the failed participant");
}
static void t_link_down(Tn& t) {
  for (int k = 0; k < 4; k++) {
    Tn::Opt o; o.len = 40; o.exp_err = ref::E_PART_FAIL; t.p_rx = 0.15; t.collective(o);
    t.run_cycles(t.rndi(10, 120)); t.down_pulse = true; t.run_until_cpls(t.gx.size());
    if (!t.d->st_down || !t.d->fail_out) t.fail("link_down not reported");
    t.clear_pulse = true; t.run_cycles(3); t.p_rx = 1.0;
    Tn::Opt g; g.len = 9; t.collective(g); t.run_until_idle();
  }
  t.check_all("link_down");
}
static void t_err_beat(Tn& t) {
  for (int k = 0; k < 4; k++) {
    Tn::Opt o; o.len = 24; o.err_at = t.rndi(0, 20); o.exp_err = ref::E_PEER; t.collective(o);
    Tn::Opt g; g.len = 10; t.collective(g);
    finish(t, "err_beat");
  }
}
// credits: the remote keeps only a few beats in flight and returns credits late; results stay exact and the limit is never exceeded
static void t_credits(Tn& t) {
  t.p_txr = 0.5; t.credit_delay_max = 40;
  for (int k = 0; k < 6; k++) { Tn::Opt o; o.len = t.rndi(20, 100); o.op = t.rndi(0, 5); t.collective(o); }
  finish(t, "credits");
  if (t.max_outstanding < std::min(2, TB_CREDITS)) t.fail("credit window never used (max outstanding %d)", t.max_outstanding);
}
static void t_random(Tn& t) {
  t.link_timeout = 0;
  for (int round = 0; round < 20; round++) {
    t.p_rx = (t.rnd() < 0.5) ? 1.0 : 0.2; t.p_txr = (t.rnd() < 0.5) ? 1.0 : 0.3; t.s0.p_ready = (t.rnd() < 0.5) ? 1.0 : 0.3; t.p_cpl = (t.rnd() < 0.5) ? 1.0 : 0.2; t.p_ack = (t.rnd() < 0.5) ? 1.0 : 0.2;
    for (int k = 0; k < t.rndi(1, 5); k++) {
      Tn::Opt o; o.ctype = t.rndi(0, 2); o.op = (o.ctype == ref::CT_BROADCAST) ? ref::OP_COPY : t.rndi(0, 5); o.dtype = t.rndi(0, 1); o.len = t.rndi(0, 70);
      if (o.ctype == ref::CT_REDUCE) { o.send = 3; o.recv = 1 << t.rndi(0, 1); } else if (o.ctype == ref::CT_BROADCAST) { o.send = 1 << t.rndi(0, 1); o.recv = 3; } else { o.send = (t.rnd() < 0.7) ? 3 : (1 << t.rndi(0, 1)); o.recv = (t.rnd() < 0.7) ? 3 : (1 << t.rndi(0, 1)); }
      o.reorder = t.rnd(); o.dup_p = t.rnd() < 0.5 ? 0.15 : 0; o.p0_send = t.rnd() < 0.5 ? 1.0 : 0.3;
      t.collective(o);
    }
    finish(t, "random");
  }
}

struct TD { const char* name; void (*fn)(Tn&); };
static const TD TESTS[] = {{"inorder", t_inorder}, {"reorder_dup", t_reorder_dup}, {"late_remote", t_late_remote}, {"broadcast", t_broadcast}, {"lost_beat", t_lost_beat},
                           {"link_down", t_link_down}, {"err_beat", t_err_beat}, {"credits", t_credits}, {"random", t_random}};

int main(int argc, char** argv) {
  VerilatedContext* ctx = new VerilatedContext; ctx->commandArgs(argc, argv);
  uint64_t seed = 1; std::string only = "all"; bool quiet = false;
  for (int i = 1; i < argc; i++) { if (!strcmp(argv[i], "--seed") && i + 1 < argc) seed = strtoull(argv[++i], nullptr, 0); else if (!strcmp(argv[i], "--test") && i + 1 < argc) only = argv[++i]; else if (!strcmp(argv[i], "--quiet")) quiet = true; }
  Vsf_collective_net_sim* dut = new Vsf_collective_net_sim(ctx);
  Tn tb(dut); tb.quiet = quiet; int failed = 0, ran = 0; uint64_t total_colls = 0, total_cycles = 0, tdup = 0, tstale = 0;
  for (auto& t : TESTS) {
    if (only != "all" && only != t.name) continue;
    tb.hard_reset(); tb.errors = 0; tb.p_rx = tb.p_txr = tb.p_cpl = tb.p_ack = 1.0; tb.s0.p_ready = 1.0; tb.credit_delay_max = 3; tb.max_outstanding = 0;
    tb.n_dup = tb.n_stale = tb.n_reorder = tb.n_ack_lost = tb.injected_dups = 0; tb.cfg_timeout = 0; tb.link_timeout = 0; tb.next_cid = (uint16_t)(1 + (seed * 7919) % 20000);
    uint64_t h = 1469598103934665603ull; for (const char* c = t.name; *c; c++) h = (h ^ (uint8_t)*c) * 1099511628211ull;
    tb.rng.seed(seed * 0x9E3779B97F4A7C15ull ^ h);
    const uint64_t c0 = tb.cyc; t.fn(tb); ran++; total_colls += tb.gx.size(); total_cycles += tb.cyc - c0; tdup += tb.n_dup; tstale += tb.n_stale;
    printf("  %-14s %s  (%" PRIu64 " cycles, %zu collectives; dup=%" PRIu64 " stale=%" PRIu64 " reorder=%" PRIu64 ")\n", t.name, tb.errors ? "FAIL" : "pass", tb.cyc - c0, tb.gx.size(), tb.n_dup, tb.n_stale, tb.n_reorder);
    if (tb.errors) { failed++; printf("    %d error(s)\n", tb.errors); }
  }
  printf("RESULT: %s  tests=%d failed=%d seed=%" PRIu64 " WIN=%d CREDITS=%d colls=%" PRIu64 " cycles=%" PRIu64 " dup=%" PRIu64 " stale=%" PRIu64 "\n", failed ? "FAIL" : "PASS", ran, failed, seed, TB_WIN, TB_CREDITS, total_colls, total_cycles, tdup, tstale);
  dut->final(); delete dut; delete ctx; return failed ? 1 : 0;
}
