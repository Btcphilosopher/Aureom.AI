// =============================================================================
// SilicaFlux CollectiveCore (Project 114) -- scenario library and runner for the flat node (sf_collective_core)
//   tb_main [--seed N] [--test name|all] [--list] [--quiet]
// Every scenario: hard reset, build collectives (reference computed independently), run until idle, scoreboard.
// =============================================================================
#include "tb_harness.h"
#include <cstring>
#include <algorithm>

using ref::CT_REDUCE; using ref::CT_BROADCAST; using ref::CT_ALLREDUCE; using ref::CT_REDSCAT; using ref::CT_ALLGATHER;
using ref::OP_SUM; using ref::OP_MIN; using ref::OP_MAX; using ref::OP_AND; using ref::OP_OR; using ref::OP_XOR; using ref::OP_COPY;
using ref::DT_I32; using ref::DT_U32;

static uint8_t FULL() { return (uint8_t)((1u << NPT) - 1); }
static int rndi(Tb& t, int lo, int hi) { return lo + (int)(t.rng() % (uint64_t)(hi - lo + 1)); }

static uint64_t perf(Tb& t, int idx) { t.d->perf_sel = idx; t.eval(); return t.d->perf_data; }

// random legal masks for a collective type (flat node)
static void rand_masks(Tb& t, int ctype, uint8_t& send, uint8_t& recv) {
  auto nonempty = [&](bool prefer_full) {
    uint8_t m = 0;
    if (prefer_full && t.rnd() < 0.6) return FULL();
    while (m == 0) m = (uint8_t)(t.rng() & FULL());
    return m;
  };
  auto onehot = [&]() { return (uint8_t)(1u << rndi(t, 0, NPT - 1)); };
  switch (ctype) {
    case CT_REDUCE:    send = nonempty(true); recv = onehot(); break;
    case CT_BROADCAST: send = onehot(); recv = nonempty(true); break;
    default:           send = nonempty(true); recv = nonempty(true); break;
  }
}

// legal data type for an operator in this build: FP32 only for SUM
static int rdt(Tb& t, int op) { return (TB_FP32_EN && op == OP_SUM) ? rndi(t, 0, 2) : rndi(t, 0, 1); }
static Tb::Spec mk(Tb& t, int ctype, int op, int dt, uint32_t len) {
  Tb::Spec s; s.ctype = ctype; s.op = op; s.dtype = dt; s.len = len;
  rand_masks(t, ctype, s.send, s.recv);
  if (ctype == CT_REDSCAT) { int nr = ref::popc(s.recv); s.len = ((len + nr - 1) / nr) * nr; if (s.len > (uint32_t)TB_MAXLEN) s.len = (TB_MAXLEN / nr) * nr; }
  return s;
}
static void finish(Tb& t, const char* tag) { t.run_until_idle(); t.check_all(tag); }

// ---------------------------------------------------------------------------------------------------- scenarios
// SUM / MIN / MAX / AND / OR / XOR on INT32 and UINT32, REDUCE / ALLREDUCE / BROADCAST, assorted lengths and data
static void t_ops_all(Tb& t) {
  const int lens[] = {1, 2, 3, 8, 17};
  for (int rep = 0; rep < 3; rep++)
    for (int dt = DT_I32; dt <= DT_U32; dt++)
      for (int op = OP_SUM; op <= OP_XOR; op++)
        for (int ct : {CT_ALLREDUCE, CT_REDUCE}) {
          Tb::Spec s = mk(t, ct, op, dt, (uint32_t)lens[rndi(t, 0, 4)]);
          s.data_mode = rndi(t, 0, 3);
          t.collective(s);
        }
  for (int dt = DT_I32; dt <= DT_U32; dt++) { Tb::Spec s = mk(t, CT_BROADCAST, OP_COPY, dt, 9); t.collective(s); }
  finish(t, "ops_all");
}

// zero, negative, extreme values, overflow flag semantics, signed vs unsigned comparison
static void t_special_values(Tb& t) {
  struct V { int op, dt; uint32_t a, b; } cases[] = {
    {OP_SUM, DT_I32, 0x7FFFFFFFu, 1u},          {OP_SUM, DT_I32, 0x80000000u, 0xFFFFFFFFu}, {OP_SUM, DT_I32, 0x80000000u, 0x80000000u},
    {OP_SUM, DT_I32, 0xFFFFFFFFu, 1u},          {OP_SUM, DT_I32, 5u, 0xFFFFFFFBu},          {OP_SUM, DT_U32, 0xFFFFFFFFu, 1u},
    {OP_SUM, DT_U32, 0x80000000u, 0x80000000u}, {OP_SUM, DT_U32, 0x7FFFFFFFu, 0x7FFFFFFFu}, {OP_SUM, DT_U32, 0u, 0u},
    {OP_MIN, DT_I32, 0x80000000u, 1u},          {OP_MIN, DT_U32, 0x80000000u, 1u},          {OP_MAX, DT_I32, 0x80000000u, 1u},
    {OP_MAX, DT_U32, 0x80000000u, 1u},          {OP_MIN, DT_I32, 0xFFFFFFFFu, 0u},          {OP_MAX, DT_I32, 0xFFFFFFFFu, 0u},
    {OP_MIN, DT_U32, 0xFFFFFFFFu, 0u},          {OP_MAX, DT_U32, 0xFFFFFFFFu, 0u},          {OP_MIN, DT_I32, 0x7FFFFFFFu, 0x80000000u},
    {OP_AND, DT_I32, 0xFFFFFFFFu, 0u},          {OP_OR, DT_U32, 0xF0F0F0F0u, 0x0F0F0F0Fu},  {OP_XOR, DT_I32, 0xFFFFFFFFu, 0xFFFFFFFFu},
    {OP_XOR, DT_U32, 0xAAAAAAAAu, 0x55555555u}, {OP_MAX, DT_U32, 0u, 0u},                   {OP_MIN, DT_I32, 0u, 0u},
  };
  for (auto& c : cases) {
    Tb::Spec s; s.ctype = CT_ALLREDUCE; s.op = c.op; s.dtype = c.dt; s.len = 1;
    s.data.assign(8, {});
    s.data[0] = {c.a}; s.data[1] = {c.b};
    t.collective(s);
  }
  // all-zero and corner-value vectors over several lengths
  for (int mode : {3, 4}) for (int op = OP_SUM; op <= OP_XOR; op++) for (int dt = DT_I32; dt <= DT_U32; dt++) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, op, dt, 20); s.data_mode = mode; t.collective(s);
  }
  finish(t, "special");
}

static void t_lengths(Tb& t) {
  std::vector<int> lens;
  for (int i = 1; i <= 33; i++) lens.push_back(i);
  for (int i : {63, 64, 65, 127, 128, 129, 255, 256, 257, TB_MAXLEN - 1, TB_MAXLEN}) if (i >= 1 && i <= TB_MAXLEN) lens.push_back(i);
  for (int l : lens) { Tb::Spec s = mk(t, rndi(t, 0, 1) ? CT_ALLREDUCE : CT_REDUCE, rndi(t, 0, 5), rndi(t, 0, 1), (uint32_t)l); t.collective(s); }
  finish(t, "lengths");
}

static void t_empty(Tb& t) {
  for (int i = 0; i < 12; i++) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, (i % 3 == 0) ? 0u : (uint32_t)rndi(t, 1, 12));
    t.collective(s);
  }
  { Tb::Spec s = mk(t, CT_REDUCE, OP_MAX, DT_U32, 0); t.collective(s); }
  { Tb::Spec s = mk(t, CT_BROADCAST, OP_COPY, DT_I32, 0); t.collective(s); }
  finish(t, "empty");
  // an empty collective moves nothing: every port saw only the beats of the non-empty ones
  for (auto& e : t.exps) if (e.cmd.len == 0) for (int p = 0; p < NPT; p++) for (auto& r : t.snk[p].rx) if (r.b.cid == e.cmd.cid) t.fail("beat for empty collective %u", e.cmd.cid);
}

static void t_backpressure(Tb& t) {
  const double lv[] = {1.0, 0.6, 0.25, 0.07};
  for (int round = 0; round < 12; round++) {
    for (int p = 0; p < NPT; p++) { t.snk[p].p_ready = lv[rndi(t, 0, 3)]; }
    t.p_cpl_ready = lv[rndi(t, 0, 3)]; t.p_cmd = lv[rndi(t, 0, 3)];
    for (int k = 0; k < 3; k++) {
      Tb::Spec s = mk(t, rndi(t, 0, 1) ? CT_ALLREDUCE : CT_BROADCAST, 0, rndi(t, 0, 1), (uint32_t)rndi(t, 1, 40));
      if (s.ctype == CT_BROADCAST) s.op = OP_COPY; else s.op = rndi(t, 0, 5);
      for (int p = 0; p < NPT; p++) s.p_send[p] = lv[rndi(t, 0, 3)];
      t.collective(s);
    }
    finish(t, "backpressure");
  }
}

static void t_delayed(Tb& t) {
  for (int rep = 0; rep < 6; rep++) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, rndi(t, 0, 5), rndi(t, 0, 1), (uint32_t)rndi(t, 4, 60));
    s.send = FULL(); s.recv = FULL();
    for (int p = 0; p < NPT; p++) { s.start_delay[p] = (rep % 2) ? rndi(t, 0, 600) : (p == rep % NPT ? 500 : 0); s.p_send[p] = (p % 2) ? 0.2 : 1.0; }
    t.collective(s);
  }
  finish(t, "delayed");   // no timeout configured: a slow participant is not a failure
}

static void t_missing(Tb& t) {
  t.cfg_timeout = 300;
  for (int p = 0; p < NPT; p++) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 24);
    s.send = FULL(); s.recv = FULL(); s.fault_p = p; s.fault = F_STOP; s.fault_at = rndi(t, 0, 20); s.exp_maskA = 1 << p;
    t.collective(s);
    Tb::Spec g = mk(t, CT_ALLREDUCE, OP_XOR, DT_U32, 10); g.send = FULL(); g.recv = FULL(); t.collective(g);       // recovery
  }
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_MAX, DT_I32, 12); s.send = FULL(); s.recv = FULL(); s.fault_p = 0; s.fault = F_DROP; s.fault_at = 11; s.exp_maskA = 1; t.collective(s); }   // last element missing
  { Tb::Spec g = mk(t, CT_REDUCE, OP_MIN, DT_U32, 10); t.collective(g); }
  finish(t, "missing");
  if (perf(t, 9 /*PC_COLL_ERR*/) != (uint64_t)(NPT + 1)) t.fail("PC_COLL_ERR = %" PRIu64 ", expected %d", perf(t, 9), NPT + 1);
}

static void t_duplicate(Tb& t) {
  t.cfg_timeout = 400;
  for (int p = 0; p < NPT; p++) for (int f : {(int)F_DUP, (int)F_BAD_DATA_DUP}) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 16);
    s.send = FULL(); s.recv = FULL(); s.fault_p = p; s.fault = f; s.fault_at = rndi(t, 0, 14); s.exp_maskA = 1 << p;
    t.collective(s);
    Tb::Spec g = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 16); g.send = FULL(); g.recv = FULL(); t.collective(g);       // a duplicate must not leak into the next collective
  }
  finish(t, "duplicate");
}

static void t_faults(Tb& t) {
  t.cfg_timeout = 400;
  const int faults[] = {F_DROP, F_DUP, F_BAD_PID, F_BAD_DT, F_BAD_OP, F_BAD_LAST, F_EARLY_LAST, F_ERR_FLAG, F_EXTRA, F_STOP, F_BAD_DATA_DUP};
  for (int f : faults) for (int p = 0; p < NPT; p++) {
    const int len = rndi(t, 4, 20);
    int at = rndi(t, 0, len - 2);                    // not the last element: keeps the expected code unique
    if (f == F_BAD_LAST || f == F_ERR_FLAG || f == F_BAD_PID || f == F_BAD_DT || f == F_BAD_OP) at = rndi(t, 0, len - 1);
    if (f == F_DROP && rndi(t, 0, 3) == 0) at = len - 1;
    const int op_ = rndi(t, 0, 5);
    Tb::Spec s = mk(t, CT_ALLREDUCE, op_, rdt(t, op_), (uint32_t)len);
    s.send = FULL(); s.recv = FULL(); s.fault_p = p; s.fault = f; s.fault_at = at;
    for (int q = 0; q < NPT; q++) s.p_send[q] = (q == p) ? 1.0 : 0.7;
    t.collective(s);
    const int gop = rndi(t, 0, 5);
    Tb::Spec g = mk(t, CT_ALLREDUCE, gop, rdt(t, gop), (uint32_t)rndi(t, 1, 20)); g.send = FULL(); g.recv = FULL(); t.collective(g);
  }
  finish(t, "faults");
}

static void t_sequential(Tb& t) {
  for (int i = 0; i < 80; i++) {
    int ct = rndi(t, 0, 2);
    Tb::Spec s = mk(t, ct, (ct == CT_BROADCAST) ? OP_COPY : rndi(t, 0, 5), rndi(t, 0, 1), (uint32_t)rndi(t, 1, 50));
    s.data_mode = rndi(t, 0, 3);
    for (int p = 0; p < NPT; p++) s.p_send[p] = t.rnd() < 0.5 ? 1.0 : 0.3;
    t.collective(s);
  }
  for (int p = 0; p < NPT; p++) t.snk[p].p_ready = 0.5;
  finish(t, "sequential");
}

// data of collective N+1 arrives long before its command: it must be held (never dropped, never combined with N)
static void t_early_data(Tb& t) {
  t.p_cmd = 0.01;
  for (int i = 0; i < 10; i++) { Tb::Spec s = mk(t, CT_ALLREDUCE, rndi(t, 0, 5), rndi(t, 0, 1), (uint32_t)rndi(t, 1, 20)); s.send = FULL(); s.recv = FULL(); t.collective(s); }
  finish(t, "early_data");
}

static void t_cid_wrap(Tb& t) {
  t.next_cid = 0xFFF9;
  for (int i = 0; i < 20; i++) { Tb::Spec s = mk(t, CT_ALLREDUCE, rndi(t, 0, 5), rndi(t, 0, 1), (uint32_t)rndi(t, 1, 10)); s.send = FULL(); s.recv = FULL(); t.collective(s); }
  finish(t, "cid_wrap");
}

// beats of already finished collectives (late duplicates, retransmissions) are discarded and counted, never combined
static void t_stale(Tb& t) {
  t.cfg_timeout = 0;
  t.hard_reset();
  Tb::Spec a = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 6); a.send = FULL(); a.recv = FULL();
  uint16_t cid_a = t.collective(a);
  finish(t, "stale-1");
  const uint64_t base = perf(t, 20 /*PC_STALE*/);
  int pushed = 0;
  for (int p = 0; p < NPT; p++) {
    Job j; Beat b; b.cid = cid_a; b.pid = (uint8_t)p; b.dt = (uint8_t)a.dtype; b.op = (uint8_t)a.op;
    for (int k = 0; k < 3; k++) { b.idx = (uint32_t)k; b.data = 0xDEAD0000u + k; b.last = false; j.script.push_back(b); pushed++; }
    t.src[p].jobs.push_back(j);
  }
  Tb::Spec g = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 9); g.send = FULL(); g.recv = FULL(); t.collective(g);
  finish(t, "stale-2");
  const uint64_t got = perf(t, 20) - base;
  if (got != (uint64_t)pushed) t.fail("PC_STALE delta %" PRIu64 ", expected %d", got, pushed);
}

static void t_cmd_reject(Tb& t) {
  t.cfg_timeout = 0;
  auto good = [&]() { Tb::Spec s = mk(t, CT_ALLREDUCE, rndi(t, 0, 5), rndi(t, 0, 1), (uint32_t)rndi(t, 1, 10)); s.send = FULL(); s.recv = FULL(); t.collective(s); };
  good();
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 5); s.ctype = 7; s.stream_anyway = true; t.collective(s); }                       // unknown type
  good();
  { Tb::Spec s = mk(t, CT_ALLREDUCE, 7, DT_I32, 5); s.stream_anyway = true; t.collective(s); }                                          // op out of range
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, 3, 5); s.stream_anyway = true; t.collective(s); }                                          // dtype out of range
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, ref::DT_F32, 5); s.stream_anyway = true; t.collective(s); if (!TB_FP32_EN) {} }            // FP32 (rejected unless built; expectation follows the build)
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_COPY, DT_I32, 5); s.stream_anyway = true; t.collective(s); }                                    // COPY on a reduction
  { Tb::Spec s = mk(t, CT_BROADCAST, OP_SUM, DT_I32, 5); s.stream_anyway = true; t.collective(s); }                                     // reduction op on a broadcast
  good();
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, TB_MAXLEN + 1); s.stream_anyway = true; t.collective(s); }                         // too long
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 5); s.send = 0; s.stream_anyway = true; t.collective(s); }                         // no sender
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 5); s.recv = 0; s.stream_anyway = true; t.collective(s); }                         // no receiver
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 5); s.send = (uint8_t)(FULL() | (1u << NPT) | 0x80u); s.stream_anyway = true; t.collective(s); }   // participant out of range
  if (NPT >= 2) { Tb::Spec s = mk(t, CT_REDUCE, OP_SUM, DT_I32, 5); s.send = FULL(); s.recv = 3; s.stream_anyway = true; t.collective(s); }          // two roots
  if (NPT >= 2) { Tb::Spec s = mk(t, CT_BROADCAST, OP_COPY, DT_I32, 5); s.send = 3; s.recv = FULL(); s.stream_anyway = true; t.collective(s); }    // two broadcasters
  good();
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 5); s.force_cid = (int64_t)(t.next_cid - 3); t.collective(s); }     // ID going backwards (no data: the ID names an earlier collective)
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 5); s.force_cid = (int64_t)(t.last_cid); t.collective(s); }          // repeated ID (no data: it would collide with the real collective of that ID)
  good();
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 5); s.send = FULL(); s.recv = FULL(); t.collective(s); }
  finish(t, "cmd_reject");
  // the last thing the engine sees is a REJECTED backward ID, then stale beats of the last real collective: they must be discarded (the reference ID did not move back), not held forever
  { const uint16_t real = t.last_cid;
    Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 5); s.force_cid = (int64_t)(uint16_t)(real - 3); t.collective(s);
    for (int p = 0; p < NPT; p++) { Job j; for (int k = 0; k < 3; k++) { Beat b; b.cid = real; b.pid = (uint8_t)p; b.idx = (uint32_t)k; b.dt = DT_I32; b.op = OP_SUM; b.data = 0xBAD00000u + k; j.script.push_back(b); } t.src[p].jobs.push_back(j); }
    finish(t, "cmd_reject_stale"); }
}

static void t_part_fail(Tb& t) {
  for (int p = 0; p < NPT; p++) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 40); s.send = FULL(); s.recv = FULL();
    for (int q = 0; q < NPT; q++) s.p_send[q] = 0.1;
    s.exp_err_override = ref::E_PART_FAIL; s.exp_maskA = 1 << p;
    t.collective(s);
    t.run_cycles(rndi(t, 20, 120));
    t.part_fail = 1u << p;
    t.run_until_idle();
    t.part_fail = 0;
    Tb::Spec g = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 7); g.send = FULL(); g.recv = FULL(); t.collective(g);
    t.run_until_idle();
  }
  // a failed participant that takes no part in the collective is ignored
  if (NPT >= 3) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, OP_XOR, DT_U32, 12); s.send = 3; s.recv = 3; t.collective(s);
    t.part_fail = 1u << (NPT - 1);
    finish(t, "part_fail-ignored");
    t.part_fail = 0;
  }
  t.check_all("part_fail");
}

static void t_abort(Tb& t) {
  for (int k = 0; k < 4; k++) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, OP_MAX, DT_I32, 50); s.send = FULL(); s.recv = FULL();
    for (int q = 0; q < NPT; q++) s.p_send[q] = 0.15;
    s.exp_err_override = ref::E_ABORT;
    t.collective(s);
    t.run_cycles(rndi(t, 5, 150));
    t.abort_pulse = true;
    t.run_until_idle();
    Tb::Spec g = mk(t, CT_ALLREDUCE, OP_MIN, DT_I32, 9); g.send = FULL(); g.recv = FULL(); t.collective(g);
    t.run_until_idle();
  }
  t.check_all("abort");
}

// the consumer never takes the result: watchdog reports the destinations that still owe, the receivers get terminators once they wake up
static void t_output_timeout(Tb& t) {
  t.cfg_timeout = 200;
  Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 60); s.send = FULL(); s.recv = FULL();
  s.exp_err_override = ref::E_TIMEOUT; s.exp_maskB = FULL();
  t.snk[0].never = true;
  t.collective(s);
  t.run_cycles(600);
  t.snk[0].never = false;                                  // consumer comes back
  Tb::Spec g = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 7); g.send = FULL(); g.recv = FULL(); t.collective(g);
  finish(t, "output_timeout");
}

static void t_reset_hard(Tb& t) {
  for (int k = 0; k < 40; k++) {
    t.hard_reset();
    t.cfg_timeout = (k % 4 == 0) ? 150 : 0;
    for (int p = 0; p < NPT; p++) t.snk[p].p_ready = (k % 3 == 0) ? 0.3 : 1.0;
    const int n = rndi(t, 1, 3);
    for (int i = 0; i < n; i++) {
      const int op_ = rndi(t, 0, 5);
      Tb::Spec s = mk(t, CT_ALLREDUCE, op_, rdt(t, op_), (uint32_t)rndi(t, 4, 40)); s.send = FULL(); s.recv = FULL();
      if (k % 5 == 0) { s.fault_p = 0; s.fault = F_DUP; s.fault_at = 1; }
      for (int p = 0; p < NPT; p++) s.p_send[p] = 0.5;
      t.collective(s);
    }
    t.run_cycles(rndi(t, 1, 160));
    t.async_reset_midcycle();                                 // asynchronous reset in the middle of whatever is going on
    if (t.d->cpl_valid || t.d->out_valid || !t.d->idle || t.d->cmd_ready == 0) t.fail("reset %d: engine not clean after reset (cpl_valid=%d out_valid=%x idle=%d)", k, (int)t.d->cpl_valid, (unsigned)t.d->out_valid, (int)t.d->idle);
    // a fresh collective on the same cids must work
    t.cfg_timeout = 0;
    for (int p = 0; p < NPT; p++) t.snk[p].p_ready = 1.0;
    Tb::Spec g = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 11); g.send = FULL(); g.recv = FULL(); t.collective(g);
    finish(t, "reset_hard");
  }
}

static void t_reset_soft(Tb& t) {
  for (int k = 0; k < 40; k++) {
    t.hard_reset();
    for (int p = 0; p < NPT; p++) t.snk[p].p_ready = (k % 3 == 0) ? 0.3 : 1.0;
    const int n = rndi(t, 1, 3);
    for (int i = 0; i < n; i++) {
      Tb::Spec s = mk(t, CT_ALLREDUCE, rndi(t, 0, 5), rndi(t, 0, 1), (uint32_t)rndi(t, 4, 40)); s.send = FULL(); s.recv = FULL();
      for (int p = 0; p < NPT; p++) s.p_send[p] = 0.5;
      t.collective(s);
    }
    t.run_cycles(rndi(t, 1, 160));
    t.soft_pulse = true; t.step();
    t.clear_tb_state();                                       // platform contract: the stream sources are quiesced with the core
    t.d->in_valid = 0;
    t.run_cycles(8);
    if (t.d->cpl_valid || t.d->out_valid || !t.d->idle) t.fail("soft reset %d: engine not clean (cpl_valid=%d out_valid=%x idle=%d)", k, (int)t.d->cpl_valid, (unsigned)t.d->out_valid, (int)t.d->idle);
    for (int p = 0; p < NPT; p++) t.snk[p].p_ready = 1.0;
    Tb::Spec g = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 11); g.send = FULL(); g.recv = FULL(); t.collective(g);
    finish(t, "reset_soft");
  }
}


// REDUCE_SCATTER (receiver r gets chunk r of the reduced vector) and ALL_GATHER (concatenation in participant order); build options
static void t_redscat_gather(Tb& t) {
  if (!TB_REDSCAT && !TB_ALLGATHER) { return; }
  for (int rep = 0; rep < 12; rep++) {
    if (TB_REDSCAT) {
      Tb::Spec s = mk(t, CT_REDSCAT, rndi(t, 0, 5), rndi(t, 0, 1), (uint32_t)rndi(t, 1, 48)); s.data_mode = rndi(t, 0, 3);
      for (int p = 0; p < NPT; p++) s.p_send[p] = (rep % 2) ? 0.3 : 1.0;
      t.collective(s);
      Tb::Spec f = mk(t, CT_REDSCAT, OP_SUM, DT_I32, (uint32_t)(NPT * 6)); f.send = FULL(); f.recv = FULL(); t.collective(f);      // every participant gets an equal chunk
    }
    if (TB_ALLGATHER) {
      Tb::Spec s = mk(t, CT_ALLGATHER, OP_COPY, rndi(t, 0, 1), (uint32_t)rndi(t, 1, 30));
      for (int p = 0; p < NPT; p++) { s.p_send[p] = (rep % 2) ? 0.3 : 1.0; s.start_delay[p] = (rep % 3 == 0) ? rndi(t, 0, 200) : 0; }
      t.collective(s);
      Tb::Spec f = mk(t, CT_ALLGATHER, OP_COPY, DT_U32, 7); f.send = FULL(); f.recv = FULL(); t.collective(f);
    }
  }
  for (int p = 0; p < NPT; p++) t.snk[p].p_ready = 0.4;
  finish(t, "redscat_gather");
}


#ifdef TB_FP32
// ---------------------------------------------------------------------------------------------------- FP32 (builds with FP32_EN)
// bit-exact IEEE-754 binary32 sums in the fixed tree order, all five rounding modes, flags, specials
static void t_fp32_sum(Tb& t) {
  if (!TB_FP32_EN) return;
  for (int rep = 0; rep < 40; rep++) {
    Tb::Spec s = mk(t, rndi(t, 0, 1) ? CT_ALLREDUCE : CT_REDUCE, OP_SUM, ref::DT_F32, (uint32_t)rndi(t, 1, 24));
    s.data_mode = 5 + rep % 3; t.collective(s);
  }
  for (int rm = 0; rm <= 4; rm++) for (int mode = 5; mode <= 7; mode++) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, ref::DT_F32, 30); s.rm = rm; s.data_mode = mode; s.send = FULL(); s.recv = FULL(); t.collective(s);
  }
  { Tb::Spec s = mk(t, CT_BROADCAST, OP_COPY, ref::DT_F32, 20); s.data_mode = 6; t.collective(s); }          // FP32 broadcast is a bit-exact copy (NaN payloads included)
  { Tb::Spec s = mk(t, CT_REDUCE, OP_SUM, ref::DT_F32, 16); s.data_mode = 6; s.send = 1; s.recv = 1; t.collective(s); }   // single contributor: passes through untouched (no phantom add)
  finish(t, "fp32_sum");
}
// non-associativity is real, and the result does not depend on timing: same data, wildly different stalls -> identical bits
static void t_fp32_repro(Tb& t) {
  if (!TB_FP32_EN) return;
  std::vector<std::vector<uint32_t>> data(8);
  for (int p = 0; p < 8; p++) data[p] = Tb::rand_vec(t.rng, 64, 7);
  std::vector<std::vector<uint32_t>> first;
  for (int run = 0; run < 4; run++) {
    t.hard_reset();
    t.cfg_timeout = 0;
    for (int p = 0; p < NPT; p++) t.snk[p].p_ready = (run % 2) ? 0.15 : 1.0;
    Tb::Spec s; s.ctype = CT_ALLREDUCE; s.op = OP_SUM; s.dtype = ref::DT_F32; s.len = 64; s.rm = 0; s.data = data;
    for (int p = 0; p < NPT; p++) { s.p_send[p] = (run >= 2) ? 0.2 : 1.0; s.start_delay[p] = (run == 3) ? 37 * p : 0; }
    t.collective(s); finish(t, "fp32_repro");
    std::vector<uint32_t> got; for (auto& rb : t.snk[0].rx) got.push_back(rb.b.data);
    if (run == 0) first.push_back(got); else if (got != first[0]) t.fail("FP32 result changed with timing (run %d)", run);
  }
  // how much does the association matter?  (reference only: tree order vs sequential left-to-right)
  int differ = 0, total = 0;
  for (int k = 0; k < 2000; k++) {
    std::vector<uint32_t> v = Tb::rand_vec(t.rng, NPT, 7); uint32_t fl = 0, fl2 = 0;
    std::vector<ref::Elem> lf(8); for (int p = 0; p < NPT; p++) { lf[p].present = true; lf[p].v = v[p]; }
    int leaves = 1; while (leaves < NPT) leaves <<= 1;
    uint32_t tr = ref::tree(lf, 0, leaves, OP_SUM, ref::DT_F32, 0, fl).v;
    uint32_t sq = v[0]; for (int p = 1; p < NPT; p++) sq = ref::fp_add(sq, v[p], 0, fl2);
    total++; if (tr != sq && !((tr & 0x7F800000u) == 0x7F800000u && (tr & 0x7FFFFF))) differ++;
  }
  printf("    info: tree order != sequential order on %d of %d random %d-term FP32 sums (so identical results across reduction orders are NOT promised)\n", differ, total, NPT);
}
// a failure in the middle of an FP32 reduction must not leak stale partial sums into the next collective
static void t_fp32_flush(Tb& t) {
  if (!TB_FP32_EN) return;
  t.cfg_timeout = 300;
  const int faults[] = {F_DROP, F_DUP, F_ERR_FLAG, F_STOP, F_BAD_LAST, F_BAD_PID};
  for (int rep = 0; rep < 18; rep++) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, ref::DT_F32, 24); s.send = FULL(); s.recv = FULL();
    s.fault_p = rndi(t, 0, NPT - 1); s.fault = faults[rep % 6]; s.fault_at = rndi(t, 0, 12);
    t.collective(s);
    for (int k = 0; k < 2; k++) { Tb::Spec g = mk(t, CT_ALLREDUCE, OP_SUM, ref::DT_F32, 24); g.send = FULL(); g.recv = FULL(); t.collective(g); }
  }
  for (int p = 0; p < NPT; p++) t.snk[p].p_ready = 0.3;
  finish(t, "fp32_flush");
}
static void t_fp32_reject(Tb& t) {
  if (!TB_FP32_EN) return;
  for (int op : {OP_MIN, OP_MAX, OP_AND, OP_OR, OP_XOR}) { Tb::Spec s = mk(t, CT_ALLREDUCE, op, ref::DT_F32, 5); s.stream_anyway = true; t.collective(s); }   // E_CMD_OP: FP32 supports SUM only
  for (int rm = 5; rm <= 7; rm++) { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, ref::DT_F32, 5); s.rm = rm; s.stream_anyway = true; t.collective(s); }          // E_CMD_OP: bad rounding mode
  { Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, ref::DT_I32, 5); s.rm = 7; t.collective(s); }                                                                  // rm is ignored for integers
  { Tb::Spec g = mk(t, CT_ALLREDUCE, OP_SUM, ref::DT_F32, 9); g.send = FULL(); g.recv = FULL(); t.collective(g); }
  finish(t, "fp32_reject");
  for (auto& c : t.cpls) if (c.err == ref::E_CMD_OP) goto found;
  t.fail("no E_CMD_OP seen");
  found:;
}

#else
static void t_fp32_sum(Tb&) {}
static void t_fp32_repro(Tb&) {}
static void t_fp32_flush(Tb&) {}
static void t_fp32_reject(Tb&) {}
#endif


// a participant that is not a sender streams data anyway: refused (E_HDR), never accepted into its buffer; the next collective is clean
static void t_nonsender(Tb& t) {
  t.cfg_timeout = 400;
  for (int p = 0; p < NPT; p++) {
    Tb::Spec s = mk(t, CT_BROADCAST, OP_COPY, DT_I32, 12); s.send = (uint8_t)(1u << ((p + 1) % NPT)); s.recv = FULL(); s.extra_sender = p;
    t.collective(s);
    Tb::Spec g = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 9); g.send = FULL(); g.recv = FULL(); t.collective(g);
  }
  finish(t, "nonsender");
}
// a failure while result beats sit in the output buffers behind slow consumers: the beat on offer is not disturbed, terminators carry the right index
static void t_fail_backlog(Tb& t) {
  for (int k = 0; k < 8; k++) {
    for (int p = 0; p < NPT; p++) t.snk[p].p_ready = 0.04;
    Tb::Spec s = mk(t, CT_ALLREDUCE, rndi(t, 0, 5), DT_I32, 90); s.send = FULL(); s.recv = FULL();
    s.exp_err_override = (k % 2) ? ref::E_ABORT : ref::E_PART_FAIL;
    t.collective(s);
    t.run_cycles(rndi(t, 100, 260));                     // fast sources: the output buffers are full of result beats by now
    if (k % 2) t.abort_pulse = true; else t.part_fail = 1u << (k % NPT);
    t.run_until_idle(); t.part_fail = 0;
    for (int p = 0; p < NPT; p++) t.snk[p].p_ready = 1.0;
    Tb::Spec g = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 9); g.send = FULL(); g.recv = FULL(); t.collective(g);
    t.run_until_idle();
  }
  t.check_all("fail_backlog");
}
// the watchdog measures "no progress", not elapsed time: a slow but steady collective much longer than the timeout completes; a stall longer than it fails
static void t_watchdog_progress(Tb& t) {
  t.cfg_timeout = 50;
  for (int k = 0; k < 3; k++) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 120); s.send = FULL(); s.recv = FULL();
    for (int p = 0; p < NPT; p++) s.p_send[p] = 0.4;             // ~300 cycles in total, an element every ~2.5 cycles
    t.collective(s);
  }
  finish(t, "watchdog_ok");
  Tb::Spec s = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 20); s.send = FULL(); s.recv = FULL(); s.start_delay[NPT - 1] = 300; s.exp_err_override = ref::E_TIMEOUT; s.exp_maskA = 1u << (NPT - 1);
  t.collective(s);
  finish(t, "watchdog_stall");                           // the late participant's stream is blocked behind its own late data: let it drain before the next collective
  Tb::Spec g = mk(t, CT_ALLREDUCE, OP_SUM, DT_I32, 9); g.send = FULL(); g.recv = FULL(); t.collective(g);
  finish(t, "watchdog_recover");
}

// perf counters against the bench's own counts
static void t_perf_counts(Tb& t) {
  t.d->perf_clear = 1; t.step(); t.d->perf_clear = 0; t.step();
  uint64_t elems = 0, ok = 0, in_beats = 0, out_beats = 0;
  for (int i = 0; i < 15; i++) {
    Tb::Spec s = mk(t, CT_ALLREDUCE, rndi(t, 0, 5), rndi(t, 0, 1), (uint32_t)rndi(t, 1, 30)); t.collective(s);
    elems += s.len; ok++; in_beats += (uint64_t)ref::popc(s.send) * s.len; out_beats += (uint64_t)ref::popc(s.recv) * s.len;
  }
  finish(t, "perf");
  if (perf(t, 2) != elems) t.fail("PC_ELEMS %" PRIu64 " != %" PRIu64, perf(t, 2), elems);
  if (perf(t, 8) != ok) t.fail("PC_COLL_OK %" PRIu64 " != %" PRIu64, perf(t, 8), ok);
  if (perf(t, 3) != in_beats) t.fail("PC_BEATS_IN %" PRIu64 " != %" PRIu64, perf(t, 3), in_beats);
  if (perf(t, 4) != out_beats) t.fail("PC_BEATS_OUT %" PRIu64 " != %" PRIu64, perf(t, 4), out_beats);
  if (perf(t, 1) == 0 || perf(t, 1) > perf(t, 0)) t.fail("PC_ACTIVE %" PRIu64 " vs PC_CYCLES %" PRIu64, perf(t, 1), perf(t, 0));
  if (perf(t, 21) != 0) t.fail("PC_PROTO_ERR != 0 in a clean run");
}

// constrained random mix, no faults: every result must be exact
static void t_random(Tb& t) {
  for (int round = 0; round < 25; round++) {
    const double lv[] = {1.0, 0.7, 0.3, 0.1};
    for (int p = 0; p < NPT; p++) t.snk[p].p_ready = lv[rndi(t, 0, 3)];
    t.p_cmd = lv[rndi(t, 0, 3)]; t.p_cpl_ready = lv[rndi(t, 0, 3)];
    const int n = rndi(t, 1, 8);
    for (int i = 0; i < n; i++) {
      int ct = rndi(t, 0, 2 + ((TB_REDSCAT || TB_ALLGATHER) ? 2 : 0));
      if (ct == CT_REDSCAT && !TB_REDSCAT) ct = CT_ALLREDUCE;
      if (ct == CT_ALLGATHER && !TB_ALLGATHER) ct = CT_REDUCE;
      const int op_ = (ct == CT_BROADCAST || ct == CT_ALLGATHER) ? OP_COPY : rndi(t, 0, 5);
      Tb::Spec s = mk(t, ct, op_, (op_ == OP_COPY) ? rndi(t, 0, 2) : rdt(t, op_), (uint32_t)rndi(t, 0, (ct == CT_ALLGATHER) ? 40 : 90));
      s.data_mode = rndi(t, 0, 3);
      for (int p = 0; p < NPT; p++) { s.p_send[p] = lv[rndi(t, 0, 3)]; s.start_delay[p] = (t.rnd() < 0.2) ? rndi(t, 0, 80) : 0; }
      t.collective(s);
    }
    finish(t, "random");
  }
}

// random mix WITH faults and resets of the consumer side: outcomes are unconstrained but invariants are not
static void t_random_faults(Tb& t) {
  t.cfg_timeout = 250;
  for (int round = 0; round < 25; round++) {
    const double lv[] = {1.0, 0.6, 0.2};
    for (int p = 0; p < NPT; p++) t.snk[p].p_ready = lv[rndi(t, 0, 2)];
    const int n = rndi(t, 2, 8);
    for (int i = 0; i < n; i++) {
      int ct = rndi(t, 0, 2);
      const int op_ = (ct == CT_BROADCAST) ? OP_COPY : rndi(t, 0, 5);
      Tb::Spec s = mk(t, ct, op_, (op_ == OP_COPY) ? rndi(t, 0, 2) : rdt(t, op_), (uint32_t)rndi(t, 1, 40));
      for (int p = 0; p < NPT; p++) s.p_send[p] = lv[rndi(t, 0, 2)];
      if (t.rnd() < 0.5) {
        const int cand[] = {F_DROP, F_DUP, F_BAD_PID, F_BAD_DT, F_BAD_OP, F_BAD_LAST, F_EARLY_LAST, F_ERR_FLAG, F_EXTRA, F_STOP, F_BAD_DATA_DUP};
        for (int p = 0; p < NPT; p++) if (s.send >> p & 1) { s.fault_p = p; break; }
        s.fault = cand[rndi(t, 0, 10)]; s.fault_at = rndi(t, 0, (int)s.len - 1);
      }
      t.collective(s);
      t.exps.back().exp_err = -1;                        // outcome free (OK must still be exact, failures must be clean)
    }
    finish(t, "random_faults");
  }
}

// ---------------------------------------------------------------------------------------------------- runner
struct TestDef { const char* name; void (*fn)(Tb&); };
static const TestDef TESTS[] = {
  {"ops_all", t_ops_all}, {"special_values", t_special_values}, {"lengths", t_lengths}, {"empty", t_empty},
  {"backpressure", t_backpressure}, {"delayed", t_delayed}, {"missing", t_missing}, {"duplicate", t_duplicate},
  {"faults", t_faults}, {"sequential", t_sequential}, {"early_data", t_early_data}, {"cid_wrap", t_cid_wrap},
  {"stale", t_stale}, {"cmd_reject", t_cmd_reject}, {"part_fail", t_part_fail}, {"abort", t_abort},
  {"output_timeout", t_output_timeout}, {"reset_hard", t_reset_hard}, {"reset_soft", t_reset_soft},
  {"nonsender", t_nonsender}, {"fail_backlog", t_fail_backlog}, {"watchdog_progress", t_watchdog_progress}, {"fp32_sum", t_fp32_sum}, {"fp32_repro", t_fp32_repro}, {"fp32_flush", t_fp32_flush}, {"fp32_reject", t_fp32_reject}, {"redscat_gather", t_redscat_gather}, {"perf_counts", t_perf_counts}, {"random", t_random}, {"random_faults", t_random_faults},
};

int main(int argc, char** argv) {
  VerilatedContext* ctx = new VerilatedContext;
  ctx->commandArgs(argc, argv);
  uint64_t seed = 1; std::string only = "all"; bool list = false, quiet = false;
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--seed") && i + 1 < argc) seed = strtoull(argv[++i], nullptr, 0);
    else if (!strcmp(argv[i], "--test") && i + 1 < argc) only = argv[++i];
    else if (!strcmp(argv[i], "--list")) list = true;
    else if (!strcmp(argv[i], "--quiet")) quiet = true;
  }
  if (list) { for (auto& t : TESTS) printf("%s\n", t.name); return 0; }
  Vsf_collective_core* dut = new Vsf_collective_core(ctx);
  Tb tb(dut, ctx);
  tb.quiet = quiet;
  int failed = 0, ran = 0;
  uint64_t total_cycles = 0, total_colls = 0;
  for (auto& t : TESTS) {
    if (only != "all" && only != t.name) continue;
    tb.hard_reset();
    tb.errors = 0; tb.cfg_timeout = 0; tb.p_cmd = 1.0; tb.p_cpl_ready = 1.0; tb.next_cid = (uint16_t)(1 + (seed * 7919) % 20000);
    for (int p = 0; p < 8; p++) tb.snk[p].p_ready = 1.0;
    uint64_t h = 1469598103934665603ull; for (const char* c = t.name; *c; c++) h = (h ^ (uint8_t)*c) * 1099511628211ull;
    tb.rng.seed(seed * 0x9E3779B97F4A7C15ull ^ h);
    const uint64_t c0 = tb.cyc;
    t.fn(tb);
    ran++; total_cycles += tb.cyc - c0; total_colls += tb.exps.size();
    printf("  %-16s %s  (%" PRIu64 " cycles)\n", t.name, tb.errors ? "FAIL" : "pass", tb.cyc - c0);
    if (tb.errors) { failed++; printf("    %d error(s)\n", tb.errors); }
  }
  printf("RESULT: %s  tests=%d failed=%d seed=%" PRIu64 " build NP=%d MAXLEN=%d colls=%" PRIu64 " cycles=%" PRIu64 " beats_in=%" PRIu64 " beats_out=%" PRIu64 "\n",
         failed ? "FAIL" : "PASS", ran, failed, seed, NPT, TB_MAXLEN, total_colls, total_cycles, tb.beats_in, tb.beats_out);
  dut->final(); delete dut; delete ctx;
  return failed ? 1 : 0;
}
