// =============================================================================
// SilicaFlux CollectiveCore (Project 114) -- memory-system bench (sim/sf_collective_mm_system.sv)
//   host fills SRAM buffers -> StreamDMA stages them into scratchpad buffers -> memory adapters load them as participant streams ->
//   collective core -> result streams -> adapters store into result buffers -> StreamDMA drains them -> host reads and compares.
//   Plus the protection negatives: alignment, length / overflow, unmapped, range-crossing, read-only, wrong domain, beyond the memory.
// Memory is loaded / dumped only through the real MemoryMatrix host port.  Reference = ref::compute (independent).
// =============================================================================
#include "Vsf_collective_mm_system.h"
#include "tb_common.h"
#include <cstring>
#include <algorithm>

#ifndef TB_MAXLEN
#define TB_MAXLEN 1024
#endif
using ref::OP_SUM; using ref::DT_I32; using ref::CT_ALLREDUCE;
enum { M_OK = 0, M_ALIGN = 1, M_LEN = 2, M_PERM = 3, M_BUS = 4, M_STREAM = 5 };
static const char* mname(int e) { static const char* n[] = {"OK", "ALIGN", "LEN", "PERM", "BUS", "STREAM", "?", "?"}; return n[e & 7]; }

static const uint32_t A0 = 0x00000, A1 = 0x01000, D0 = 0x04000, D1 = 0x05000;     // SRAM (type 1): host-filled inputs, drained outputs
static const uint32_t B0 = 0x10000, B1 = 0x11000, C0 = 0x12000, C1 = 0x13000;     // compute scratchpad (type 4): staged inputs, results

struct Sm {
  Vsf_collective_mm_system* d; uint64_t cyc = 0; std::mt19937_64 rng; int errors = 0; bool quiet = false;
  // completion collectors (always ready)
  std::vector<std::pair<uint16_t, int>> core_cpl; std::vector<std::pair<uint16_t, int>> ldc[2], stc[2]; std::vector<std::pair<int, int>> dma_cpl;
  std::vector<uint32_t> stc_wr[2];                 // MemoryMatrix write-access counter at the instant each store-completion record is seen
  bool host_rsp = false; uint32_t host_data = 0; int host_status = 0;
  uint64_t t_dma_in = 0, t_coll = 0, t_dma_out = 0, rd_elems = 0, wr_elems = 0, n_flows = 0;
  explicit Sm(Vsf_collective_mm_system* dd) : d(dd) {}
  void fail(const char* fmt, ...) __attribute__((format(printf, 2, 3))) {
    errors++;
    if (errors <= 25 && !quiet) { char b[512]; va_list ap; va_start(ap, fmt); vsnprintf(b, sizeof b, fmt, ap); va_end(ap); printf("    FAIL @%" PRIu64 ": %s\n", cyc, b); }
  }
  void half(int c) { d->clk = c; d->eval(); }
  void step() {
    half(0);
    for (int a = 0; a < 2; a++) {
      if (getf(d->ldc_valid, a, 1) && getf(d->ldc_ready, a, 1)) ldc[a].push_back({(uint16_t)getf(d->ldc_cid, a * 16, 16), (int)getf(d->ldc_err, a * 3, 3)});
      if (getf(d->stc_valid, a, 1) && getf(d->stc_ready, a, 1)) { stc[a].push_back({(uint16_t)getf(d->stc_cid, a * 16, 16), (int)getf(d->stc_err, a * 3, 3)}); stc_wr[a].push_back(d->mm_acc_wr); }
    }
    if (d->cpl_valid && d->cpl_ready) core_cpl.push_back({(uint16_t)d->cpl_cid, (int)d->cpl_err});
    if (d->dcpl_valid && d->dcpl_ready) dma_cpl.push_back({(int)d->dcpl_txn_id, (int)d->dcpl_status});
    if (d->host_rsp_valid) { host_rsp = true; host_data = d->host_rsp_rdata; host_status = d->host_rsp_status; }
    half(1); half(0); cyc++;
  }
  void run(int n) { for (int i = 0; i < n; i++) step(); }
  void reset() {
    d->rst_n = 0; d->cmd_valid = 0; d->ld_valid = 0; d->st_valid = 0; d->desc_valid = 0; d->tw_en = 0; d->host_req_valid = 0; d->cfg_timeout = 0;
    d->cpl_ready = 1; d->ldc_ready = 3; d->stc_ready = 3; d->dcpl_ready = 1;
    for (int i = 0; i < 4; i++) { half(0); half(1); cyc++; } half(0); d->rst_n = 1; run(3);
    core_cpl.clear(); for (int a = 0; a < 2; a++) { ldc[a].clear(); stc[a].clear(); stc_wr[a].clear(); } dma_cpl.clear();
  }

  // ---- host port (matrix master 4): word access through the real memory interface
  uint32_t host_op(bool we, uint32_t addr, uint32_t wdata, int* status = nullptr) {
    d->host_req_valid = 1; d->host_we = we; d->host_addr = addr; d->host_size = 2; d->host_wdata = wdata; d->host_be = 0xF; host_rsp = false;
    for (int i = 0; i < 1000; i++) { half(0); const bool rdy = d->host_req_ready; step(); if (rdy) break; }
    d->host_req_valid = 0;
    for (int i = 0; i < 1000 && !host_rsp; i++) step();
    if (!host_rsp) { fail("host op timed out"); return 0; }
    if (status) *status = host_status;
    return host_data;
  }
  void load_words(uint32_t base, const std::vector<uint32_t>& v) { for (size_t i = 0; i < v.size(); i++) host_op(true, base + 4 * (uint32_t)i, v[i]); }
  std::vector<uint32_t> dump_words(uint32_t base, size_t n) { std::vector<uint32_t> v(n); for (size_t i = 0; i < n; i++) v[i] = host_op(false, base + 4 * (uint32_t)i, 0); return v; }

  // ---- guard tables
  void tw(int sel, int idx, int dom, int asid, uint32_t base, uint32_t size, uint32_t pa, int perm) {
    d->tw_sel = sel; d->tw_idx = idx; d->tw_valid = 1; d->tw_domain = dom; d->tw_asid = asid; d->tw_base = base; d->tw_size = size; d->tw_pa = pa; d->tw_perm = perm; d->tw_en = 1;
    step(); d->tw_en = 0; step();
  }
  void program_guards() {
    tw(0, 0, 1, 1, 0x00000, 0x8000, 0x00000, 3);       // StreamDMA: SRAM window RW
    tw(0, 1, 1, 4, 0x10000, 0x4000, 0x10000, 3);       // StreamDMA: scratchpad window RW
    for (int a = 1; a <= 2; a++) {
      tw(a, 0, 1, 4, 0x10000, 0x2000, 0x10000, 1);     // adapter: staged inputs  READ only
      tw(a, 1, 1, 4, 0x12000, 0x2000, 0x12000, 3);     // adapter: result buffers READ/WRITE
      tw(a, 2, 1, 4, 0x30000, 0x1000, 0x30000, 1);     // mapped but beyond the matrix capacity (128 KiB): the memory answers RANGE
      tw(a, 3, 1, 4, 0x40000, 0x1000, 0x200000, 1);    // maps to a physical address beyond the 1 MiB aperture: refused by the adapter
      tw(a, 4, 1, 4, 0x50000, 0x2000, 0x10000, 1);     // NON-IDENTITY translation: IOVA 0x50000.. -> PA 0x10000.. (staged inputs), read only
      tw(a, 5, 1, 4, 0x60000, 0x2000, 0x12000, 3);     // NON-IDENTITY translation: IOVA 0x60000.. -> PA 0x12000.. (result buffers), read/write
    }
  }

  // ---- StreamDMA: copy bytes between memory types; waits for the completion record
  int dma_copy(int src_type, uint32_t src, int dst_type, uint32_t dst, uint32_t bytes, int dom = 1) {
    static int txn = 100; txn++;
    d->desc_data[0] = 1u | (0u << 8) | ((0x1u | 0x2u | 0x8u) << 16);          // VERSION 1, COPY, FIRST|LAST|CPL_EN
    d->desc_data[1] = (uint32_t)txn | ((uint32_t)dom << 16);
    d->desc_data[2] = (uint32_t)src_type | ((uint32_t)dst_type << 4);
    d->desc_data[3] = bytes; d->desc_data[4] = src; d->desc_data[5] = 0; d->desc_data[6] = dst; d->desc_data[7] = 0;
    d->desc_domain = dom; d->desc_valid = 1;
    const size_t n0 = dma_cpl.size();
    for (int i = 0; i < 1000; i++) { half(0); const bool rdy = d->desc_ready; step(); if (rdy) break; }
    d->desc_valid = 0;
    for (int i = 0; i < 200000 && dma_cpl.size() == n0; i++) step();
    if (dma_cpl.size() == n0) { fail("StreamDMA completion timed out"); return -1; }
    return dma_cpl.back().second;                                              // 0 = OK
  }

  // ---- one collective over the memory system
  struct Run { int ctype = CT_ALLREDUCE, op = OP_SUM, dtype = DT_I32; uint32_t len = 16; uint8_t send = 3, recv = 3; };
  struct Desc { uint32_t iova; uint32_t len; int dom = 1; };
  uint16_t next_cid = 1;
  uint64_t cmd_issue_cycle = 0;

  void submit_cmd(const ref::Cmd& c) {
    d->cmd_data = c.pack(); d->cmd_valid = 1;
    for (int i = 0; i < 1000; i++) { half(0); const bool rdy = d->cmd_ready; step(); if (rdy) break; }
    d->cmd_valid = 0;
  }
  void submit_ld(int a, uint16_t cid, int dt, int op, const Desc& ds) {
    setf(d->ld_cid, a * 16, 16, cid); setf(d->ld_dtype, a * 2, 2, dt); setf(d->ld_op, a * 3, 3, op); setf(d->ld_iova, a * 32, 32, ds.iova);
    setf(d->ld_len, a * 21, 21, ds.len); setf(d->ld_dom, a * 4, 4, ds.dom); setf(d->ld_valid, a, 1, 1);
    for (int i = 0; i < 1000; i++) { half(0); const bool rdy = getf(d->ld_ready, a, 1); step(); if (rdy) break; }
    setf(d->ld_valid, a, 1, 0);
  }
  void submit_st(int a, uint16_t cid, const Desc& ds) {
    setf(d->st_cid, a * 16, 16, cid); setf(d->st_iova, a * 32, 32, ds.iova); setf(d->st_len, a * 21, 21, ds.len); setf(d->st_dom, a * 4, 4, ds.dom); setf(d->st_valid, a, 1, 1);
    for (int i = 0; i < 1000; i++) { half(0); const bool rdy = getf(d->st_ready, a, 1); step(); if (rdy) break; }
    setf(d->st_valid, a, 1, 0);
  }
  // wait until the core, both loads and both stores have completed (or give up)
  bool wait_all(size_t core_n, size_t ld_n, size_t st_n, uint64_t maxc = 400000) {
    for (uint64_t i = 0; i < maxc; i++) {
      if (core_cpl.size() >= core_n && ldc[0].size() >= ld_n && ldc[1].size() >= ld_n && stc[0].size() >= st_n && stc[1].size() >= st_n) { run(6); return true; }
      step();
    }
    fail("HANG: core %zu/%zu ld %zu,%zu/%zu st %zu,%zu/%zu", core_cpl.size(), core_n, ldc[0].size(), ldc[1].size(), ld_n, stc[0].size(), stc[1].size(), st_n);
    return false;
  }

  // Full flow with per-participant source/destination descriptors (default: the staged buffers).  Returns the reference result.
  struct Out { ref::Result res; std::vector<uint32_t> in0, in1; uint16_t cid; ref::Cmd cmd; uint32_t cbase[2] = {C0, C1}; };
  Out flow(const Run& r, const Desc* ld = nullptr, const Desc* st = nullptr, bool stage = true, const uint32_t* stage_dst = nullptr, const uint32_t* st_phys = nullptr, bool check_order = true) {
    n_flows++;
    Out o; ref::Cmd c; c.cid = next_cid++; c.ctype = r.ctype; c.op = r.op; c.dtype = r.dtype; c.send = r.send; c.recv = r.recv; c.len = r.len;
    ref::Build b; b.np = 2; b.max_len = TB_MAXLEN;
    std::vector<std::vector<uint32_t>> in(2);
    for (int p = 0; p < 2; p++) in[p] = tb_rand_vec(rng, std::max<int>(c.len, 1), (int)(rng() % 4));
    o.in0 = in[0]; o.in1 = in[1]; o.cid = c.cid; o.cmd = c;
    o.res = ref::compute(c, b, in);
    if (stage) {
      load_words(A0, in[0]); load_words(A1, in[1]);
      const uint64_t t0 = cyc;
      const uint32_t sd0 = stage_dst ? stage_dst[0] : B0, sd1 = stage_dst ? stage_dst[1] : B1;
      if (c.len) { if (dma_copy(1, A0, 4, sd0, 4 * c.len) != 0) fail("DMA stage-in 0 failed"); if (dma_copy(1, A1, 4, sd1, 4 * c.len) != 0) fail("DMA stage-in 1 failed"); }
      t_dma_in += cyc - t0;
    }
    const size_t core0 = core_cpl.size(), ld0 = ldc[0].size(), st0 = stc[0].size();
    const uint64_t t1 = cyc;
    half(0); const uint32_t wr0 = d->mm_acc_wr;
    submit_cmd(c);
    Desc dl[2] = {{B0, c.len}, {B1, c.len}}, ds[2] = {{C0, c.len}, {C1, c.len}};
    for (int a = 0; a < 2; a++) { submit_ld(a, c.cid, c.dtype, c.op, ld ? ld[a] : dl[a]); submit_st(a, c.cid, st ? st[a] : ds[a]); o.cbase[a] = st_phys ? st_phys[a] : (st ? st[a].iova : ds[a].iova); }
    wait_all(core0 + 1, ld0 + 1, st0 + 1);
    t_coll += cyc - t1;
    // completion ordering, checked at the instant each store-completion record appeared: every write of THAT adapter had already been performed
    if (check_order && c.len && stc_wr[0].size() > st0 && stc_wr[1].size() > st0 && stc[0][st0].second == 0 && stc[1][st0].second == 0) {
      const uint32_t w0v = stc_wr[0][st0] - wr0, w1v = stc_wr[1][st0] - wr0;
      if (std::min(w0v, w1v) < c.len) fail("store completion before its writes were performed: matrix writes at the record = %u / %u, adapter wrote %u", w0v, w1v, c.len);
      if (std::max(w0v, w1v) != 2 * c.len) fail("matrix writes %u at the later record, expected %u", std::max(w0v, w1v), 2 * c.len);
    }
    return o;
  }
};

// ------------------------------------------------------------------------------------------------ scenarios
static void check_results(Sm& s, const Sm::Out& o, const char* tag, bool drain = true) {
  const uint32_t n = o.cmd.len;
  const uint32_t* cbase = o.cbase; const uint32_t dbase[2] = {D0, D1};
  for (int p = 0; p < 2; p++) {
    if (!n) continue;
    // completion ordering: the store completion has been seen; the buffer must be complete NOW
    auto got = s.dump_words(cbase[p], n);
    if (got != o.res.port[p]) { size_t k = 0; while (k < n && got[k] == o.res.port[p][k]) k++; s.fail("%s p%d: result buffer differs at element %zu (%08x != %08x)", tag, p, k, got[k], o.res.port[p][k]); }
  }
  if (drain && n) {
    const uint64_t t0 = s.cyc;
    for (int p = 0; p < 2; p++) if (s.dma_copy(4, cbase[p], 1, dbase[p], 4 * n) != 0) s.fail("%s: DMA drain %d failed", tag, p);
    s.t_dma_out += s.cyc - t0;
    for (int p = 0; p < 2; p++) { auto got = s.dump_words(dbase[p], n); if (got != o.res.port[p]) s.fail("%s p%d: drained buffer differs", tag, p); }
  }
}
static void t_flow(Sm& s) {
  const uint32_t lens[] = {1, 2, 5, 16, 31, 64, 100, 257};
  for (int rep = 0; rep < 2; rep++) for (uint32_t len : lens) {
    Sm::Run r; r.len = len; r.op = (int)(s.rng() % 6); r.dtype = (int)(s.rng() % 2);
    Sm::Out o = s.flow(r);
    if (s.core_cpl.back().second != 0) s.fail("flow len %u op %d: core error %s", len, r.op, ref::err_name(s.core_cpl.back().second));
    for (int a = 0; a < 2; a++) { if (s.ldc[a].back().second != M_OK) s.fail("ld%d err %s", a, mname(s.ldc[a].back().second)); if (s.stc[a].back().second != M_OK) s.fail("st%d err %s", a, mname(s.stc[a].back().second)); }
    check_results(s, o, "flow");
  }
  // a collective of every operator on a 4 KiB-crossing buffer (guard bursts are cut at 4 KiB: B0 + 0xF00)
}
static void t_burst_split(Sm& s) {            // buffers that straddle 4 KiB pages: the engines must cut their guard requests at the page boundary
  for (int rep = 0; rep < 4; rep++) {
    const uint32_t len = 100 + 20 * rep;                                            // 400..640 bytes starting 128 bytes before a page end
    Sm::Run r; r.len = len; r.op = rep % 6;
    Sm::Desc ld[2] = {{B0 + 0xF80, len}, {B0 + 0x1800, len}}, st[2] = {{C0, len}, {C0 + 0xF80, len}};   // loads straddle 0x11000, store 1 straddles 0x13000
    const uint32_t sd[2] = {B0 + 0xF80, B0 + 0x1800};
    Sm::Out o = s.flow(r, ld, st, true, sd, nullptr, true);
    if (s.core_cpl.back().second != 0) s.fail("burst split: core %s", ref::err_name(s.core_cpl.back().second));
    for (int a = 0; a < 2; a++) { if (s.ldc[a].back().second != M_OK) s.fail("burst split: ld%d %s", a, mname(s.ldc[a].back().second)); if (s.stc[a].back().second != M_OK) s.fail("burst split: st%d %s", a, mname(s.stc[a].back().second)); }
    check_results(s, o, "burst_split");
  }
}

// only the physical address the guard returns may reach the memory: loads and stores through remapped IOVAs land where the guard says
static void t_translate(Sm& s) {
  for (int rep = 0; rep < 4; rep++) {
    const uint32_t len = 24 + 30 * rep;
    Sm::Run r; r.len = len; r.op = rep % 6;
    Sm::Desc ld[2] = {{0x50000, len}, {0x51000, len}}, st[2] = {{0x60000, len}, {0x61000, len}};
    const uint32_t phys[2] = {C0, C1};
    Sm::Out o = s.flow(r, ld, st, true, nullptr, phys, true);
    if (s.core_cpl.back().second != 0) s.fail("translate: core %s", ref::err_name(s.core_cpl.back().second));
    for (int a = 0; a < 2; a++) { if (s.ldc[a].back().second != M_OK) s.fail("translate: ld%d %s", a, mname(s.ldc[a].back().second)); if (s.stc[a].back().second != M_OK) s.fail("translate: st%d %s", a, mname(s.stc[a].back().second)); }
    check_results(s, o, "translate", false);
  }
}

struct Neg { const char* name; Sm::Desc ld[2]; Sm::Desc st[2]; int exp_ld[2]; int exp_st[2]; int exp_core; };
static void t_protection(Sm& s) {
  const uint32_t N = 64;
  Neg cases[] = {
    {"ld unaligned",       {{B0 + 2, N}, {B1, N}},        {{C0, N}, {C1, N}},             {M_ALIGN, M_OK}, {M_STREAM, M_STREAM}, ref::E_PEER},
    {"ld unmapped",        {{B0, N}, {0x18000, N}},        {{C0, N}, {C1, N}},             {M_OK, M_PERM},  {M_STREAM, M_STREAM}, ref::E_PEER},
    {"ld runs off mapping",{{0x13F80, N}, {B1, N}},        {{C0, N}, {C1, N}},             {M_PERM, M_OK},  {M_STREAM, M_STREAM}, ref::E_PEER},   // 32 elements fit, the second burst is unmapped
    {"ld wrong domain",    {{B0, N, 2}, {B1, N}},          {{C0, N}, {C1, N}},             {M_PERM, M_OK},  {M_STREAM, M_STREAM}, ref::E_PEER},
    {"ld too long",        {{B0, TB_MAXLEN + 1}, {B1, N}}, {{C0, N}, {C1, N}},             {M_LEN, M_OK},   {M_STREAM, M_STREAM}, ref::E_PEER},
    {"ld address wrap",    {{0xFFFFFFF0u, N}, {B1, N}},    {{C0, N}, {C1, N}},             {M_LEN, M_OK},   {M_STREAM, M_STREAM}, ref::E_PEER},
    {"ld beyond memory",   {{B0, N}, {0x30000, N}},        {{C0, N}, {C1, N}},             {M_OK, M_BUS},   {M_STREAM, M_STREAM}, ref::E_PEER},
    {"ld beyond aperture", {{0x40000, N}, {B1, N}},        {{C0, N}, {C1, N}},             {M_BUS, M_OK},   {M_STREAM, M_STREAM}, ref::E_PEER},
    {"st read-only",       {{B0, N}, {B1, N}},             {{C0, N}, {B1, N}},             {M_OK, M_OK},    {M_OK, M_PERM},       ref::E_OK},
    {"st wrong domain",    {{B0, N}, {B1, N}},             {{C0, N, 2}, {C1, N}},          {M_OK, M_OK},    {M_PERM, M_OK},       ref::E_OK},
    {"st unaligned",       {{B0, N}, {B1, N}},             {{C0, N}, {C1 + 1, N}},         {M_OK, M_OK},    {M_OK, M_ALIGN},      ref::E_OK},
    {"st beyond memory",   {{B0, N}, {B1, N}},             {{0x30000, N}, {C1, N}},        {M_OK, M_OK},    {M_PERM, M_OK},       ref::E_OK},   // 0x30000 is mapped READ-only: a write is refused
  };
  for (auto& n : cases) {
    // known content in the destinations: every refused / failed store must leave it alone
    std::vector<uint32_t> sentinel(N, 0xC0FFEE00u); s.load_words(C0, sentinel); s.load_words(C1, sentinel);
    Sm::Run r; r.len = N; r.op = OP_SUM;
    const size_t m0 = s.core_cpl.size(), l0 = s.ldc[0].size(), t0 = s.stc[0].size();
    Sm::Out o = s.flow(r, n.ld, n.st, true, nullptr, nullptr, false);
    const int core = s.core_cpl[m0].second;
    if (core != n.exp_core) s.fail("[%s] core %s, expected %s", n.name, ref::err_name(core), ref::err_name(n.exp_core));
    for (int a = 0; a < 2; a++) {
      const int le = s.ldc[a][l0].second, se = s.stc[a][t0].second;
      if (le != n.exp_ld[a]) s.fail("[%s] ld%d %s, expected %s", n.name, a, mname(le), mname(n.exp_ld[a]));
      if (se != n.exp_st[a]) s.fail("[%s] st%d %s, expected %s", n.name, a, mname(se), mname(n.exp_st[a]));
    }
    // a refused store wrote NOTHING; a failed collective's buffers are not asserted beyond that
    if (n.exp_st[0] == M_PERM || n.exp_st[0] == M_ALIGN) { auto g = s.dump_words(C0, N); if (g != sentinel) s.fail("[%s] refused store modified memory (p0)", n.name); }
    if (n.exp_st[1] == M_PERM || n.exp_st[1] == M_ALIGN) { auto g = s.dump_words(n.st[1].iova == B1 ? B1 : C1, N); if (n.st[1].iova == B1) { /* read-only staged input must still equal the staged data */ if (g != o.in1) s.fail("[%s] read-only buffer modified", n.name); } else if (g != sentinel) s.fail("[%s] refused store modified memory (p1)", n.name); }
    if (n.exp_core == ref::E_OK) {
      // the good participant's results are still correct
      const int good = (n.exp_st[0] == M_OK) ? 0 : 1;
      auto g = s.dump_words(good ? C1 : C0, N); if (g != o.res.port[good]) s.fail("[%s] good participant's result wrong", n.name);
    }
    // recovery: a clean collective right after
    Sm::Run rr; rr.len = 17; rr.op = ref::OP_XOR; Sm::Out ok = s.flow(rr);
    if (s.core_cpl.back().second != 0) s.fail("[%s] recovery collective failed (%s)", n.name, ref::err_name(s.core_cpl.back().second));
    check_results(s, ok, n.name, false);
  }
  // empty buffers
  { Sm::Run r; r.len = 0; Sm::Out o = s.flow(r, nullptr, nullptr, false, nullptr, nullptr, false); (void)o;
    if (s.core_cpl.back().second != 0 || s.ldc[0].back().second != M_OK || s.stc[1].back().second != M_OK) s.fail("empty collective over memory failed"); }
}

// throughput of the memory path (reported by benchmarks/)
static void t_perf(Sm& s) {
  s.t_dma_in = s.t_coll = s.t_dma_out = 0;
  const uint32_t lens[] = {64, 256, 1024};
  for (uint32_t len : lens) {
    s.t_dma_in = s.t_coll = s.t_dma_out = 0;
    Sm::Run r; r.len = len; r.op = OP_SUM; Sm::Out o = s.flow(r);
    const uint64_t t0 = s.cyc; (void)t0;
    check_results(s, o, "perf");
    printf("    PERF len=%u dma_in=%" PRIu64 " collective_with_memory=%" PRIu64 " dma_out=%" PRIu64 " cycles  (elements/cycle in the memory-fed collective: %.3f)\n",
           len, s.t_dma_in, s.t_coll, s.t_dma_out, (double)len / (double)s.t_coll);
  }
}

struct TD { const char* name; void (*fn)(Sm&); };
static const TD TESTS[] = {{"flow", t_flow}, {"burst_split", t_burst_split}, {"translate", t_translate}, {"protection", t_protection}, {"perf", t_perf}};

int main(int argc, char** argv) {
  VerilatedContext* ctx = new VerilatedContext; ctx->commandArgs(argc, argv);
  uint64_t seed = 1; std::string only = "all"; bool quiet = false;
  for (int i = 1; i < argc; i++) { if (!strcmp(argv[i], "--seed") && i + 1 < argc) seed = strtoull(argv[++i], nullptr, 0); else if (!strcmp(argv[i], "--test") && i + 1 < argc) only = argv[++i]; else if (!strcmp(argv[i], "--quiet")) quiet = true; }
  Vsf_collective_mm_system* dut = new Vsf_collective_mm_system(ctx);
  Sm s(dut); s.quiet = quiet; int failed = 0, ran = 0; uint64_t total_flows = 0, total_cycles = 0;
  for (auto& t : TESTS) {
    if (only != "all" && only != t.name) continue;
    s.reset(); s.errors = 0; s.program_guards(); s.next_cid = (uint16_t)(1 + (seed * 7919) % 20000);
    uint64_t h = 1469598103934665603ull; for (const char* c = t.name; *c; c++) h = (h ^ (uint8_t)*c) * 1099511628211ull;
    s.rng.seed(seed * 0x9E3779B97F4A7C15ull ^ h);
    const uint64_t c0 = s.cyc; s.n_flows = 0; t.fn(s); ran++; total_flows += s.n_flows; total_cycles += s.cyc - c0;
    printf("  %-12s %s  (%" PRIu64 " cycles)\n", t.name, s.errors ? "FAIL" : "pass", s.cyc - c0);
    if (s.errors) { failed++; printf("    %d error(s)\n", s.errors); }
  }
  printf("RESULT: %s  tests=%d failed=%d seed=%" PRIu64 " colls=%" PRIu64 " cycles=%" PRIu64 "\n", failed ? "FAIL" : "PASS", ran, failed, seed, total_flows, total_cycles);
  dut->final(); delete dut; delete ctx; return failed ? 1 : 0;
}
