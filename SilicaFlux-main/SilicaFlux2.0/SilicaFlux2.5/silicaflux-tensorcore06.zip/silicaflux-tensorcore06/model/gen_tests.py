#!/usr/bin/env python3
"""SilicaFlux TENSORCORE 06 - test generator.

Writes one directory per (configuration, test) under build/tests/:
  mem.hex   sparse $readmemh image (byte index from MEM_BASE): A and B element bytes
  cexp.hex  sparse expected-final image: 1xx = C byte xx expected, 200 = don't care;
            every byte not listed must be UNCHANGED at the end of the run
  cmds.txt  command stream (23 hex fields per command, see tb/tb_gemm.sv)
  meta.json shapes, flags, expected per-command results, analytical traffic, plusargs
Expected values come only from model/ttc_ref.py (plain Python integers).
Deterministic: every random choice is seeded from the test name.
"""
from __future__ import annotations

import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ttc_ref as R  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
MEM_BASE = 0x1000_0000
MEM_BYTES = 1 << 20
MEM_LO, MEM_HI = MEM_BASE, MEM_BASE + MEM_BYTES

BASE = dict(TM=4, TN=4, TK=64, NS=2, ASB=512, BSB=512, NBA=4, NBB=2, PMODE=1, RL=1, APAD=1, SLOTS=2,
            MAXOUT=8, FILLD=8, WDOG=16, MULP=0, ACCRL=1)
CONFIGS = {
    "base":   dict(BASE),
    "single": dict(BASE, NS=1),
    "r2x3":   dict(BASE, TM=2, TN=3, TK=16, ASB=128, BSB=128),
    "r8x8":   dict(BASE, TM=8, TN=8, TK=32, ASB=512, BSB=512, NBA=8, NBB=4),
    "r1x1":   dict(BASE, TM=1, TN=1, TK=8, ASB=64, BSB=64),
    "stress": dict(BASE, PMODE=0, MULP=1, ACCRL=3, SLOTS=1, MAXOUT=2, FILLD=2, APAD=0, RL=2),
    "wdog":   dict(BASE, WDOG=10),
}

# bus / array timing profiles (plusargs of tb_gemm)
PROFILES = {
    "ideal":   dict(lat_min=1, lat_max=1, bp=0, stall=0, cpl_bp=0, gap=0),
    "jitter":  dict(lat_min=1, lat_max=8, bp=20, stall=10, cpl_bp=30, gap=5),
    "slow":    dict(lat_min=20, lat_max=40, bp=0, stall=0, cpl_bp=0, gap=0),
    "vary":    dict(lat_min=1, lat_max=60, bp=10, stall=5, cpl_bp=10, gap=3),
    "heavy":   dict(lat_min=1, lat_max=30, bp=50, stall=30, cpl_bp=50, gap=10),
    "xbar":    dict(lat_min=1, lat_max=6, bp=10, stall=5, cpl_bp=10, gap=2, xbar=1),
}
FLAG_SETS_ALL = [0, 1, 2, 3, 4, 5, 6, 7]


class Image:
    """Memory image under construction plus the expected final image."""

    def __init__(self, seed: str):
        self.rng = random.Random(seed)
        self.mem: dict[int, int] = {}          # absolute address -> initial byte (A/B elements)
        self.exp: dict[int, int] = {}          # absolute address -> 0x100|byte, 0x200 don't care, 0 unchanged
        self.ptr = MEM_BASE + 64
        self.cmds: list[R.Cmd] = []

    def alloc(self, nbytes: int, align: int = 1, offset: int | None = None) -> int:
        self.ptr += self.rng.randint(4, 23)                 # canary gap between objects
        self.ptr = (self.ptr + align - 1) // align * align
        if offset is not None:
            self.ptr = (self.ptr // 4) * 4 + offset
        base = self.ptr
        self.ptr += nbytes
        assert self.ptr < MEM_BASE + MEM_BYTES - 64, "test does not fit the memory window"
        return base

    def values(self, rows: int, cols: int, kind: str):
        r = self.rng
        if kind == "max":
            return [[-128] * cols for _ in range(rows)]
        if kind == "ramp":
            return [[((i * 7 + j * 3) % 255) - 127 for j in range(cols)] for i in range(rows)]
        ext = (-128, 127, -127, 0, 1, -1)
        return [[(r.choice(ext) if r.random() < 0.15 else r.randint(-128, 127)) for _ in range(cols)]
                for _ in range(rows)]

    def put(self, addr: int, v: int):
        b = v & 0xFF
        assert self.mem.get(addr, b) == b, f"image conflict at {addr:#x}"
        self.mem[addr] = b

    def matrix(self, rows, cols, ld, kind, unaligned, vals=None):
        off = self.rng.randint(1, 3) if unaligned else 0          # unaligned=False: word-aligned base
        base = self.alloc((rows - 1) * ld + cols, offset=off)
        V = vals if vals is not None else self.values(rows, cols, kind)
        for i in range(rows):
            for j in range(cols):
                self.put(base + i * ld + j, V[i][j])
        return base, V

    def gemm(self, cfg, m, n, k, *, flags=0, kc=0, lda_pad=0, ldb_pad=0, ldc_pad=0, unaligned=True,
             kind="rand", A=None, B=None, a=None, b=None, rst_at=0, err_rd=None, dont_care=False):
        """Place a valid GEMM (or reuse given A/B placement) and record its expectation."""
        lda, ldb, ldc = k + lda_pad, n + ldb_pad, 4 * n + 4 * ldc_pad
        if A is None:
            a, A = self.matrix(m, k, lda, kind, unaligned)
        if B is None:
            b, B = self.matrix(k, n, ldb, kind, unaligned)
        c = self.alloc((m - 1) * ldc + 4 * n, align=4)
        cmd = R.Cmd(m=m, n=n, k=k, a=a, b=b, c=c, lda=lda, ldb=ldb, ldc=ldc, kc=kc, flags=flags,
                    tag=len(self.cmds) & 0xFF, rst_at=rst_at, A=A, B=B)
        cmd.exp_code = R.validate(cmd, cfg["TK"], MEM_LO, MEM_HI)
        assert cmd.exp_code == R.OK, (m, n, k, cmd.exp_code)
        Ae, Be = A, B
        if err_rd is not None:
            # every A/B element byte inside the failing word reads as 0 (R8: rdata = 0)
            word = err_rd
            Ae = [[0 if (a + i * lda + j) // 4 * 4 == word else A[i][j] for j in range(k)] for i in range(m)]
            Be = [[0 if (b + i * ldb + j) // 4 * 4 == word else B[i][j] for j in range(n)] for i in range(k)]
            cmd.exp_code, cmd.exp_err_addr = R.ERR_BUS_READ, word
        C = R.gemm(Ae, Be)
        for i in range(m):
            for j in range(n):
                addr = c + i * ldc + 4 * j
                v = C[i][j] & 0xFFFFFFFF
                for t in range(4):
                    self.exp[addr + t] = 0x200 if dont_care else (0x100 | ((v >> (8 * t)) & 0xFF))
        self.cmds.append(cmd)
        return cmd

    def bad(self, cfg, code, **kw):
        """A command that must be rejected with `code` (the model decides, and must agree)."""
        d = dict(m=4, n=4, k=8, a=MEM_BASE + 0x100, b=MEM_BASE + 0x200, c=MEM_BASE + 0x300, lda=8, ldb=4, ldc=16)
        d.update(kw)
        cmd = R.Cmd(**d)
        cmd.tag = len(self.cmds) & 0xFF
        cmd.exp_code = R.validate(cmd, cfg["TK"], MEM_LO, MEM_HI)
        assert cmd.exp_code == code, (kw, cmd.exp_code, code)
        self.cmds.append(cmd)
        return cmd

    # ------------------------------------------------------------------ output
    def write(self, d: Path, cfg: dict, meta: dict):
        d.mkdir(parents=True, exist_ok=True)
        with open(d / "mem.hex", "w") as fh:
            last = None
            for addr in sorted(self.mem):
                if last is None or addr != last + 1:
                    fh.write(f"@{addr - MEM_BASE:x}\n")
                fh.write(f"{self.mem[addr]:02x}\n")
                last = addr
        with open(d / "cexp.hex", "w") as fh:
            last = None
            for addr in sorted(self.exp):
                if self.exp[addr] == 0:
                    continue
                if last is None or addr != last + 1:
                    fh.write(f"@{addr - MEM_BASE:x}\n")
                fh.write(f"{self.exp[addr]:03x}\n")
                last = addr
        rows, cmeta = [], []
        for c in self.cmds:
            ok_like = c.exp_code in (R.OK, R.ERR_BUS_READ, R.ERR_BUS_WRITE)
            t, ch = R.tiles_and_chunks(c, cfg["TM"], cfg["TN"], cfg["TK"]) if ok_like else (0, 0)
            f = [c.tag, c.flags, c.a_layout, c.b_layout, c.c_layout, c.a_type, c.b_type, c.c_type,
                 c.m, c.n, c.k, c.kc, c.a, c.b, c.c, c.lda, c.ldb, c.ldc,
                 c.exp_code, c.exp_err_addr, t, ch, c.rst_at]
            rows.append(" ".join(f"{x & 0xFFFFFFFF:x}" for x in f))
            cm = dict(m=c.m, n=c.n, k=c.k, kc=c.kc or cfg["TK"], flags=c.flags, lda=c.lda, ldb=c.ldb, ldc=c.ldc,
                      a=c.a, b=c.b, c=c.c, code=c.exp_code, tiles=t, chunks=ch, rst_at=c.rst_at)
            if ok_like:
                cm["traffic"] = R.traffic(c, cfg["TM"], cfg["TN"], cfg["TK"], cfg["NS"])
                cm["macs"], cm["pad"] = R.macs(c, cfg["TM"], cfg["TN"], cfg["TK"])
            cmeta.append(cm)
        (d / "cmds.txt").write_text(f"{len(rows)}\n" + "\n".join(rows) + "\n")
        meta = dict(meta, cmds=cmeta, cfg=cfg)
        (d / "meta.json").write_text(json.dumps(meta, indent=1))


# ============================================================================ test catalogue
def t_stage1(cfg, img):
    """ONE tile, ONE K chunk: M <= TM, N <= TN, K <= TK."""
    TM, TN, TK = cfg["TM"], cfg["TN"], cfg["TK"]
    img.gemm(cfg, 1, 1, 1, unaligned=False)
    img.gemm(cfg, TM, TN, min(4, TK))
    img.gemm(cfg, TM, TN, TK)
    img.gemm(cfg, max(1, TM - 1), max(1, TN - 1), max(1, TK // 2 + 1), lda_pad=3, ldb_pad=1, ldc_pad=2)
    for fl in FLAG_SETS_ALL:
        img.gemm(cfg, TM, TN, min(TK, 5), flags=fl)


def t_stage2(cfg, img):
    """ONE output tile, MANY K chunks (incl. K beyond the operand-buffer capacity)."""
    TM, TN, TK = cfg["TM"], cfg["TN"], cfg["TK"]
    img.gemm(cfg, TM, TN, 2 * TK)                         # exactly two chunks
    img.gemm(cfg, TM, TN, 3 * TK + 5)                     # remainder chunk
    img.gemm(cfg, 1, 1, 10 * TK + 1)                      # K far beyond a set's capacity
    img.gemm(cfg, TM, TN, 29, kc=min(TK, 8))              # runtime chunk length
    img.gemm(cfg, max(1, TM - 1), TN, 4 * TK - 1, kc=min(TK, 3), lda_pad=1)
    for fl in FLAG_SETS_ALL:
        img.gemm(cfg, TM, TN, 2 * TK + 3, flags=fl)


def t_stage3(cfg, img):
    """Arbitrary M/N tiling with K chunks: the brief's shapes."""
    TK = cfg["TK"]
    img.gemm(cfg, 5, 7, 3)
    for fl in FLAG_SETS_ALL:
        img.gemm(cfg, 17, 13, 29, flags=fl)
    img.gemm(cfg, 17, 13, 29, kc=min(TK, 8), flags=3)    # 17x13x29 through 4 K chunks
    img.gemm(cfg, 17, 13, 29, kc=min(TK, 8), flags=0)
    img.gemm(cfg, 9, 11, 2 * TK + 7, flags=7)
    img.gemm(cfg, 9, 11, 2 * TK + 7, flags=1)


def t_boundary(cfg, img):
    """Boundary masks: every remainder of M and N, single rows/columns, padding canaries."""
    TM, TN = cfg["TM"], cfg["TN"]
    for m in sorted({1, TM - 1, TM, TM + 1, 2 * TM + 1}):
        for n in sorted({1, TN - 1, TN, TN + 1, 2 * TN + 1}):
            if m >= 1 and n >= 1:
                img.gemm(cfg, m, n, 7, ldc_pad=1 + (m + n) % 3, flags=(m + n) % 8)
    img.gemm(cfg, 1, 37, 9, flags=1)
    img.gemm(cfg, 37, 1, 9, flags=5)


def t_strides(cfg, img):
    """Different row strides and base alignments for A, B and C."""
    TK = cfg["TK"]
    k = TK + 9
    for i, (pa, pb, pc) in enumerate([(0, 0, 0), (1, 1, 1), (3, 2, 5), (4, 4, 0), (5, 7, 3), (64, 33, 8), (2, 0, 17)]):
        img.gemm(cfg, 6, 5, k, lda_pad=pa, ldb_pad=pb, ldc_pad=pc, unaligned=(i % 2 == 1), flags=[0, 3, 1, 7, 5, 2, 6][i])
    # dense, word-aligned A rows with K a multiple of 16 (exercises the A_PAD odd-word placement)
    img.gemm(cfg, 8, 8, 4 * TK, unaligned=False, flags=1)
    img.gemm(cfg, 8, 8, 4 * TK, unaligned=False, flags=0)


def t_multi(cfg, img):
    """Multiple consecutive GEMMs, back to back, sharing operands, different orders/flags."""
    TK = cfg["TK"]
    c0 = img.gemm(cfg, 10, 6, TK + 3, flags=3)
    img.gemm(cfg, 10, 6, TK + 3, flags=0, A=c0.A, B=c0.B, a=c0.a, b=c0.b, lda_pad=c0.lda - c0.k, ldb_pad=c0.ldb - c0.n)
    img.gemm(cfg, 3, 3, 3, flags=7)
    img.gemm(cfg, 1, 1, 1)
    img.gemm(cfg, 12, 12, 2 * TK, flags=5)
    img.gemm(cfg, 12, 12, 2 * TK, kc=max(1, TK // 4), flags=1)
    img.gemm(cfg, 7, 9, 11, flags=6)


def t_invalid(cfg, img):
    """Every validation rule, each as the first failing rule; then valid work still runs."""
    TK = cfg["TK"]
    img.bad(cfg, R.ERR_FLAGS, flags=0x08)
    img.bad(cfg, R.ERR_FLAGS, flags=0x80)
    img.bad(cfg, R.ERR_LAYOUT, a_layout=1)                 # column-major A: rejected, never transposed
    img.bad(cfg, R.ERR_LAYOUT, b_layout=1)
    img.bad(cfg, R.ERR_LAYOUT, c_layout=2)
    img.bad(cfg, R.ERR_DTYPE, a_type=1)
    img.bad(cfg, R.ERR_DTYPE, c_type=3)
    img.bad(cfg, R.ERR_DIM_ZERO, m=0)
    img.bad(cfg, R.ERR_DIM_ZERO, n=0)
    img.bad(cfg, R.ERR_DIM_ZERO, k=0)
    img.bad(cfg, R.ERR_DIM_RANGE, m=65536)
    img.bad(cfg, R.ERR_DIM_RANGE, n=0x10000000)
    img.bad(cfg, R.ERR_DIM_RANGE, k=131072, lda=131072)
    img.bad(cfg, R.ERR_CHUNK, kc=TK + 1)
    img.bad(cfg, R.ERR_CHUNK, kc=1, k=70000, lda=70000)    # 70000 chunks > 65535
    img.bad(cfg, R.ERR_LD, lda=7)
    img.bad(cfg, R.ERR_LD, ldb=3)
    img.bad(cfg, R.ERR_LD, ldc=12)
    img.bad(cfg, R.ERR_ALIGN, c=MEM_BASE + 0x302)
    img.bad(cfg, R.ERR_ALIGN, ldc=18)
    img.bad(cfg, R.ERR_ADDR_OVF, a=0xFFFF_FFF0)
    img.bad(cfg, R.ERR_ADDR_OVF, m=60000, ldc=0x20000, c=MEM_BASE)
    img.bad(cfg, R.ERR_RANGE, b=MEM_BASE - 16)
    img.bad(cfg, R.ERR_RANGE, c=MEM_BASE + MEM_BYTES - 32)
    img.bad(cfg, R.ERR_ALIAS, c=MEM_BASE + 0x104)            # C over A
    img.bad(cfg, R.ERR_ALIAS, c=MEM_BASE + 0x1f0, ldc=16)    # C over B
    img.gemm(cfg, 5, 7, 3, flags=3)
    img.bad(cfg, R.ERR_DIM_ZERO, m=0)
    img.gemm(cfg, 6, 6, TK + 1, flags=0)


def t_extreme(cfg, img):
    """Numeric boundary: K = 131071 extreme products (INT32 limit reached, never exceeded)."""
    k = R.K_MAX
    A = [[-128] * k]
    B = [[-128, 127] for _ in range(k)]
    img.gemm(cfg, 1, 2, k, A=A, B=B, a=img.matrix(1, k, k, "max", False, vals=A)[0],
             b=img.matrix(k, 2, 2, "max", False, vals=B)[0], flags=3)


def t_reset(cfg, img):
    """Reset in the middle of GEMMs (several points), then the same GEMM runs correctly."""
    TK = cfg["TK"]
    for i, at in enumerate([3, 40, 157, 600]):
        img.gemm(cfg, 9, 7, TK + 11, flags=[0, 1, 3, 7][i], rst_at=at)
    img.gemm(cfg, 5, 7, 3)


def t_buserr(cfg, img, which):
    TK = cfg["TK"]
    if which == "rd":
        c = img.gemm(cfg, 6, 6, TK + 5, flags=3)
        word = (c.a + 2 * c.lda + TK + 1) // 4 * 4          # an A word in the second K chunk
        img.cmds.pop()
        img.exp.clear()
        img.gemm(cfg, 6, 6, TK + 5, flags=3, A=c.A, B=c.B, a=c.a, b=c.b, err_rd=word)
        meta = dict(err_rd=word)
    else:
        c = img.gemm(cfg, 6, 6, TK + 5, flags=1)
        addr = c.c + 3 * c.ldc + 8                            # C[3][2] of THIS command
        for t in range(4):
            img.exp[addr + t] = 0                             # write answered with an error: no side effect
        c.exp_code, c.exp_err_addr = R.ERR_BUS_WRITE, addr
        meta = dict(err_wr=addr)
    img.gemm(cfg, 4, 4, 4)                                   # the next command is clean
    return meta


def t_watchdog(cfg, img):
    img.gemm(cfg, 8, 8, 40, flags=1, dont_care=True)
    img.cmds[-1].exp_code, img.cmds[-1].exp_err_addr = R.ERR_WATCHDOG, 0
    img.gemm(cfg, 5, 7, 3, flags=3)                          # after reset: works again


def t_large(cfg, img):
    """Larger GEMMs for the utilisation report and long-run stability."""
    img.gemm(cfg, 32, 32, 256, flags=3)
    img.gemm(cfg, 30, 34, 200, flags=1)


CATALOGUE = {
    # name: (function, stage, configs, profiles, simulators)
    "stage1":   (t_stage1,   1, ["base", "single", "r2x3", "r8x8", "r1x1", "stress"], ["ideal", "jitter"], "both"),
    "stage2":   (t_stage2,   2, ["base", "single", "r2x3", "r8x8", "r1x1", "stress"], ["ideal", "jitter"], "both"),
    "stage3":   (t_stage3,   3, ["base", "single", "r2x3", "r8x8", "r1x1", "stress"], ["ideal", "jitter"], "both"),
    "boundary": (t_boundary, 4, ["base", "r2x3", "r8x8", "stress"], ["ideal", "vary"], "both"),
    "strides":  (t_strides,  4, ["base", "single", "r8x8", "stress"], ["ideal", "jitter"], "both"),
    "multi":    (t_multi,    4, ["base", "single", "r2x3", "stress"], ["ideal", "heavy", "xbar"], "both"),
    "invalid":  (t_invalid,  4, ["base", "r2x3"], ["ideal", "jitter"], "both"),
    "backpressure": (t_stage3, 4, ["base", "single", "stress"], ["heavy"], "both"),
    "latency":  (t_stage3,   4, ["base", "single", "stress"], ["slow", "vary", "xbar"], "both"),
    "reset":    (t_reset,    4, ["base", "single", "stress"], ["ideal", "jitter"], "both"),
    "buserr_rd": (lambda c, i: t_buserr(c, i, "rd"), 4, ["base", "stress"], ["ideal", "jitter"], "both"),
    "buserr_wr": (lambda c, i: t_buserr(c, i, "wr"), 4, ["base", "stress"], ["ideal", "jitter"], "both"),
    "watchdog": (t_watchdog, 4, ["wdog"], ["ideal"], "both"),
    "extreme":  (t_extreme,  4, ["base"], ["ideal"], "verilator"),
    "large":    (t_large,    4, ["base", "single", "r8x8"], ["ideal", "jitter"], "verilator"),
}


def generate(out: Path) -> list[dict]:
    tests = []
    for name, (fn, stage, cfgs, profs, sims) in CATALOGUE.items():
        for cn in cfgs:
            cfg = CONFIGS[cn]
            img = Image(f"{name}/{cn}")
            meta = fn(cfg, img) or {}
            plus = {}
            if "err_rd" in meta:
                plus["err_rd"] = f"{meta['err_rd']:x}"
            if "err_wr" in meta:
                plus["err_wr"] = f"{meta['err_wr']:x}"
            if name == "watchdog":
                plus["hang_after"] = "60"
            d = out / f"{cn}__{name}"
            img.write(d, cfg, dict(name=name, stage=stage, config=cn))
            tests.append(dict(name=name, config=cn, stage=stage, dir=str(d), profiles=profs, sims=sims, plus=plus))
    (out / "manifest.json").write_text(json.dumps(dict(configs=CONFIGS, profiles=PROFILES, tests=tests,
                                                       mem_base=MEM_BASE, mem_bytes=MEM_BYTES), indent=1))
    return tests


if __name__ == "__main__":
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "build/tests"
    t = generate(out)
    print(f"generated {len(t)} test directories in {out}")
