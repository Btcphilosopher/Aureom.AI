"""SilicaFlux TENSORCORE 06 - independent reference model.

Plain Python integers only (no numpy, nothing shared with the RTL):

* ``gemm``          C = A x B for INT8 operands, exact, then checked to fit INT32.
* ``validate``      the command validation rules of docs/02_GEMM_CONTRACT.md, re-implemented
                    from the document (first failing rule wins).
* ``Layout``        where A, B, C live in memory (bases, byte strides) and the byte sets they
                    occupy - used to build the memory image and the expected final image.
* ``traffic``       analytical model of the controller's operand traffic for a loop order,
                    reuse policy and number of buffer sets (doc 03), compared with the
                    measured counters in reports/tile_utilisation.md.
"""
from __future__ import annotations

from dataclasses import dataclass, field

K_MAX = 131071            # largest K for which sum_k int8*int8 cannot overflow INT32
DIM_MAX = 65535
CHUNK_MAX = 65535

# completion codes (docs/02, rtl/ttc_defs.svh)
OK, ERR_FLAGS, ERR_LAYOUT, ERR_DTYPE, ERR_DIM_ZERO, ERR_DIM_RANGE, ERR_CHUNK, ERR_LD, ERR_ALIGN, \
    ERR_ADDR_OVF, ERR_RANGE, ERR_ALIAS = range(12)
ERR_BUS_READ, ERR_BUS_WRITE, ERR_ACC_OVF = 16, 17, 18
ERR_INTERNAL, ERR_WATCHDOG = 24, 25
CODE_NAMES = {OK: "OK", ERR_FLAGS: "FLAGS", ERR_LAYOUT: "LAYOUT", ERR_DTYPE: "DTYPE", ERR_DIM_ZERO: "DIM_ZERO",
              ERR_DIM_RANGE: "DIM_RANGE", ERR_CHUNK: "CHUNK", ERR_LD: "LD", ERR_ALIGN: "ALIGN",
              ERR_ADDR_OVF: "ADDR_OVF", ERR_RANGE: "RANGE", ERR_ALIAS: "ALIAS", ERR_BUS_READ: "BUS_READ",
              ERR_BUS_WRITE: "BUS_WRITE", ERR_ACC_OVF: "ACC_OVF", ERR_INTERNAL: "INTERNAL", ERR_WATCHDOG: "WATCHDOG"}

FL_OVERLAP, FL_REUSE, FL_NMAJOR = 1, 2, 4
FL_MASK = 0x07


def ceil_div(a: int, b: int) -> int:
    return -(-a // b)


def gemm(A, B):
    """Exact integer product of row lists A[M][K], B[K][N]; asserts the INT32 contract."""
    M, K, N = len(A), len(B), len(B[0])
    Bt = [[B[k][j] for k in range(K)] for j in range(N)]
    C = [[sum(a * b for a, b in zip(A[i], Bt[j])) for j in range(N)] for i in range(M)]
    for row in C:
        for v in row:
            assert -(1 << 31) <= v < (1 << 31), "reference result does not fit INT32"
    return C


@dataclass
class Cmd:
    """One GEMM command (fields as the RTL command port)."""
    m: int
    n: int
    k: int
    a: int
    b: int
    c: int
    lda: int
    ldb: int
    ldc: int
    kc: int = 0
    flags: int = 0
    tag: int = 0
    a_layout: int = 0
    b_layout: int = 0
    c_layout: int = 0
    a_type: int = 0
    b_type: int = 0
    c_type: int = 0
    rst_at: int = 0          # testbench: reset this many cycles after acceptance, then re-run
    # results filled by the generator
    exp_code: int = OK
    exp_err_addr: int = 0xFFFFFFFF
    A: list = field(default_factory=list)
    B: list = field(default_factory=list)


def footprint(base: int, rows: int, ld: int, row_bytes: int) -> tuple[int, int]:
    """First and last byte address of a row-major matrix (rows >= 1)."""
    return base, base + (rows - 1) * ld + row_bytes - 1


def validate(c: Cmd, tile_k: int, mem_lo: int, mem_hi: int) -> int:
    """Rule chain of docs/02_GEMM_CONTRACT.md section 3; first failure wins."""
    if c.flags & ~FL_MASK & 0xFF:
        return ERR_FLAGS
    if c.a_layout or c.b_layout or c.c_layout:
        return ERR_LAYOUT
    if c.a_type or c.b_type or c.c_type:
        return ERR_DTYPE
    if c.m == 0 or c.n == 0 or c.k == 0:
        return ERR_DIM_ZERO
    if c.m > DIM_MAX or c.n > DIM_MAX or c.k > K_MAX:
        return ERR_DIM_RANGE
    kc = c.kc or tile_k
    if c.kc > tile_k or ceil_div(c.k, kc) > CHUNK_MAX:
        return ERR_CHUNK
    if c.lda < c.k or c.ldb < c.n or c.ldc < 4 * c.n:
        return ERR_LD
    if c.c % 4 or c.ldc % 4:
        return ERR_ALIGN
    a0, a1 = footprint(c.a, c.m, c.lda, c.k)
    b0, b1 = footprint(c.b, c.k, c.ldb, c.n)
    c0, c1 = footprint(c.c, c.m, c.ldc, 4 * c.n)
    if max(a1, b1, c1) >= 1 << 32:
        return ERR_ADDR_OVF
    for lo, hi in ((a0, a1), (b0, b1), (c0, c1)):
        if lo < mem_lo or hi >= mem_hi:
            return ERR_RANGE
    if (c0 <= a1 and a0 <= c1) or (c0 <= b1 and b0 <= c1):
        return ERR_ALIAS
    return OK


def elem_bytes_A(c: Cmd):
    for i in range(c.m):
        for k in range(c.k):
            yield c.a + i * c.lda + k, ("A", i, k)


def elem_bytes_B(c: Cmd):
    for k in range(c.k):
        for j in range(c.n):
            yield c.b + k * c.ldb + j, ("B", k, j)


def tiles_and_chunks(c: Cmd, tm: int, tn: int, tk: int) -> tuple[int, int]:
    kc = c.kc or tk
    t = ceil_div(c.m, tm) * ceil_div(c.n, tn)
    return t, t * ceil_div(c.k, kc)


# ---------------------------------------------------------------------------- traffic model (doc 03)
def steps(m, n, k, tm, tn, kc, nmajor):
    """The controller's step sequence (ttc_tile_iter): yields (m0, n0, k0)."""
    outer, inner = (range(0, n, tn), range(0, m, tm)) if nmajor else (range(0, m, tm), range(0, n, tn))
    for o in outer:
        for i in inner:
            m0, n0 = (i, o) if nmajor else (o, i)
            for k0 in range(0, k, kc):
                yield m0, n0, k0


def row_words(start: int, length: int) -> int:
    return (start % 4 + length - 1) // 4 + 1


def traffic(c: Cmd, tm: int, tn: int, tk: int, num_sets: int):
    """Predicted operand traffic: A/B block loads, reuse hits, SFB2 read words, fill bytes."""
    kc = c.kc or tk
    nmajor = bool(c.flags & FL_NMAJOR)
    reuse = bool(c.flags & FL_REUSE)
    resA = [None] * num_sets
    resB = [None] * num_sets
    out = dict(a_loads=0, b_loads=0, a_reuse=0, b_reuse=0, rd_words=0, fill_bytes=0, steps=0)
    for s, (m0, n0, k0) in enumerate(steps(c.m, c.n, c.k, tm, tn, kc, nmajor)):
        st = s % num_sets
        em, en, ek = min(tm, c.m - m0), min(tn, c.n - n0), min(kc, c.k - k0)
        out["steps"] += 1
        if reuse and resA[st] == (m0, k0):
            out["a_reuse"] += 1
        else:
            out["a_loads"] += 1
            resA[st] = (m0, k0)
            for i in range(em):
                out["rd_words"] += row_words(c.a + (m0 + i) * c.lda + k0, ek)
            out["fill_bytes"] += em * ek
        if reuse and resB[st] == (k0, n0):
            out["b_reuse"] += 1
        else:
            out["b_loads"] += 1
            resB[st] = (k0, n0)
            for kk in range(ek):
                out["rd_words"] += row_words(c.b + (k0 + kk) * c.ldb + n0, en)
            out["fill_bytes"] += ek * en
    return out


def macs(c: Cmd, tm: int, tn: int, tk: int) -> tuple[int, int]:
    """Useful MACs and padded PE slots as TC02 counts them (pad = (R*C - em*en) per issued slice)."""
    kc = c.kc or tk
    useful = c.m * c.n * c.k
    pad = 0
    for m0, n0, k0 in steps(c.m, c.n, c.k, tm, tn, kc, False):
        em, en, ek = min(tm, c.m - m0), min(tn, c.n - n0), min(kc, c.k - k0)
        pad += (tm * tn - em * en) * ek
    return useful, pad


def k_major_slots(c: Cmd, tm: int, tn: int) -> int:
    """Accumulator slots a K-major traversal (k0 outermost) would need: every output tile open at once."""
    return ceil_div(c.m, tm) * ceil_div(c.n, tn)
