# 08 — Verification

## 1. Method

* **DUT:** `tensor_gemm_engine`, i.e. the controller with the *unmodified* TC02 array, TC03 operand buffer and TC04
  accumulator, and an SFB2 memory model (`tb/tb_gemm.sv`). This is an integration test of the real subsystems,
  not of models of them.
* **Independent reference:** `model/ttc_ref.py`, plain Python integers. It shares no code with the RTL and has
  its own validation rules. The generator (`model/gen_tests.py`) writes the memory image, the command stream
  and the **expected final memory image**. The testbench never computes a product.
* **What every run checks:**
  1. each completion record: code, error address, tiles, chunks, tag;
  2. **every SFB2 transaction**: aligned; reads only of words holding an A/B element byte of the running
     command; writes only to its C elements, with a full strobe; every C element written exactly once; zero
     transactions for a rejected command; requests never withdrawn (SFB2 R2 monitor);
  3. **the complete 1 MiB memory** at the end: every C element equal to the reference, and every other byte
     (row padding, canary bytes around the matrices, A, B) unchanged;
  4. counters vs the analytical model (doc 07);
  5. no RTL assertion fired (controller, TC03, SRAM library, FIFOs);
  6. Icarus and Verilator give **identical** completion records, including cycle counts, and identical
     counters for the same seed.
* **Memory model:** random `req_ready` back-pressure; per-request random latency; in-order responses (R5);
  writes performed only when their response is issued (R7), so a premature completion would be caught;
  error injection on chosen addresses (R8); a hang mode for the watchdog; optional crossbar rule R6 (one
  transaction in flight); reset drops everything in flight (R11).
* **Other stimulus:** random TC02 `stall_i`, random `cpl_ready` back-pressure, random idle gaps between
  commands.

## 2. Staged bring-up

The RTL supports all three levels from the start. Verification was staged, and `scripts/run_regress.py` runs
the stages strictly in order, stopping at the first failing one:

1. **one tile, one K chunk** (`M ≤ TM, N ≤ TN, K ≤ TK`; 1×1×1, TM×TN×4, TM×TN×TK, a partial tile with strides,
   and all 8 flag combinations);
2. **one tile, many K chunks** (2 chunks exactly; a remainder chunk; `1×1×(10·TK+1)` = 41 chunks, far beyond a
   set's capacity; runtime `kc` 8 and 3);
3. **arbitrary M/N tiling** (5×7×3; 17×13×29 under all 8 flag combinations and in 4 chunks with `kc = 8`;
   9×11×(2TK+7)).

## 3. Brief §10 → tests

| Required test | Where | Configurations |
|---|---|---|
| 1×1×1 | stage1 (first command), multi | all |
| 4×4×4 | stage1 (TM×TN×4 on the 4×4 configurations), 4×4×4 in buserr and perf | all |
| 5×7×3 | stage3, invalid, reset, watchdog | all |
| 17×13×29 | stage3 (8 flag sets + 2 chunked) | all |
| K exceeding buffer capacity | stage2 (`1×1×(10·TK+1)`, `TM×TN×(3TK+5)`); extreme (K = 131 071 in 2048 chunks); large | all |
| Boundary masks | boundary: every `m ∈ {1, TM−1, TM, TM+1, 2TM+1}` × `n ∈ {1, TN−1, TN, TN+1, 2TN+1}`, plus 1×37 and 37×1, with C row padding verified untouched | base, r2x3, r8x8, stress |
| Different row strides | strides: `lda − K ∈ {0,1,2,3,4,5,64}`, `ldb − N ∈ {0,1,2,4,7,33}`, `ldc − 4N ∈ {0,4,12,20,32,68}`, unaligned A/B bases, dense aligned K = 4·TK | base, single, r8x8, stress |
| Back-pressure | backpressure: 50 % `req_ready` low, 30 % array stall, 50 % `cpl_ready` low; multi under `heavy` | base, single, stress |
| DMA latency variation | latency: 20–40-cycle memory, 1–60 random, crossbar R6 mode | base, single, stress |
| Reset | reset: reset 3, 40, 157 and 600 cycles into four GEMMs (different flags), then re-run each; a final clean GEMM | base, single, stress |
| Invalid dimensions | invalid: 27 rejected commands covering all 11 rules of doc 02 §3, each as the first failing rule (incl. transposed layouts, M/N/K = 0, out-of-range values, address overflow, window, alias), interleaved with 2 valid GEMMs that must still be exact | base, r2x3 |
| Multiple consecutive GEMMs | multi: 7 back-to-back GEMMs with shared operands and different shapes/flags; every test runs several GEMMs in one simulation | base, single, r2x3, stress |
| (additional) bus read / write error | buserr_rd, buserr_wr: exact error code and address; the expected final memory includes the error's effect (zeroed operand bytes / untouched element) | base, stress |
| (additional) watchdog | watchdog: memory stops responding → `WATCHDOG`, HALT, reset, next GEMM exact | wdog |
| (additional) numeric extreme | extreme: `1×2×131071`, A = −128, B = (−128, 127) → C = (2 147 467 264, −2 130 690 176) | base (Verilator) |
| (additional) large | large: 32×32×256, 30×34×200 | base, single, r8x8 (Verilator) |

Configurations: doc 01 (six hardware configurations, from a 1×1 array to an 8×8 array, single and double
buffered, plus a stress configuration with minimum queues and the slowest subsystem options).

## 4. Results

See `reports/regression.md` (generated from the final run on these sources), `reports/mutation.md`,
`reports/lint.md` and `reports/synth.md`. The headline numbers are in the README.

## 5. What is not verified

No formal proof, no gate-level simulation, and no FPGA or silicon. The SFB2 memory is a model, not the
DataFabric crossbar plus SRAM slave RTL. Random stimulus covers timing, but the shapes are a fixed catalogue,
not random dimensions. Doc 09 lists the functional limits.
