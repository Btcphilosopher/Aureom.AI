# 09 — Known limitations and next actions

## 1. Evidence limits

* **Simulation only.** Icarus 12 and Verilator 5.020, self-checking against an independent Python model. There
  is no formal proof, no gate-level simulation, and no FPGA or silicon run.
* **Synthesis is Yosys mapping only** (generic gates, Xilinx 7-series). There is no place-and-route and no timing
  analysis, so **no clock frequency is claimed.** The controller contains several 32×17-bit address multipliers
  (`reports/synth.md`). They sit in single-cycle paths and are the most likely timing problem.
* **Cycle counts are RTL simulation cycles** against a modelled memory: 1-cycle and 8-cycle slaves with up to
  8 outstanding requests, and an R6 crossbar model with one transaction in flight. Real DataFabric latency
  depends on the crossbar and the SRAM slave in the system.

## 2. Functional scope

| Limitation | Consequence | Next action |
|---|---|---|
| INT8 × INT8 → INT32 only, dense, row-major only | Other types and layouts are rejected (`DTYPE`, `LAYOUT`), never converted or transposed. | A transposed-operand mode needs a column gather in the loader: K bytes at stride `lda` per lane. |
| **TC05 quantiser not integrated** | No bias, requantisation or ReLU; C is raw exact INT32 from TC04. | Route TC04 `oquant_*` through `tensor_quantize`, send one OPEN descriptor per tile from RESERVE, and make the store's element size a per-command field. |
| **Not integrated with the Module 06 command queue** | The controller has its own structured command port. | Implement the v2 descriptor of doc 02 §5 and a third M06 executor port. |
| One command at a time | Command *n+1* waits for every C write of command *n* to be acknowledged; no pipelining across commands. | Let VALIDATE / first loads of *n+1* overlap the STORE drain of *n* when the footprints do not alias. |
| **K-major order not implemented** | Needs MT·NT accumulator slots; TC04 is built with 2 (doc 03 §3). | Build TC04 with more slots for a K-major or blocked-K schedule. |
| Reuse depends on TC03's strict set alternation | Operand reuse happens only when NUM_SETS is a multiple of the chunk count KT (KT = 1, or KT = 2 with two sets); a long K (e.g. K = 256, TILE_K = 64, KT = 4) gets **no** reuse (measured, doc 03 §3). | Larger sets (KT ≤ 2), more sets, or a TC03 extension that lets the controller pick the set to fill. |
| ALIAS check is conservative (bounding intervals) | Interleaved but disjoint layouts are rejected, e.g. C rows inside A's row padding. | An exact row-interval test, if such layouts matter. |
| No abort input | A running GEMM can be stopped only by reset. | Add an abort that drains like a bus error. |
| Fatal errors halt until reset | `INTERNAL` / `WATCHDOG` cannot be drained safely (a subsystem may hold half a tile). None occurs in the regression except the deliberate watchdog test. | — |
| Watchdog is a fixed parameter | A memory that is legitimately slower than 2^`WDOG_LOG2` cycles per response would trip it. | Make the threshold a register. |

## 3. Memory-side behaviour to be aware of

* **SFB2 reads are whole words (R10).** A row's first and last word can carry bytes that are not in the row:
  the neighbouring row, row padding, or bytes just before `a_base` or after the last element. These bytes are
  discarded and never written anywhere. However, they **are read at the bus**, so the matrices must live in
  ordinary memory, not next to read-sensitive registers. No word without a matrix byte is ever read
  (testbench-checked).
* Operand traffic has word granularity. A B row of `eff_n ≤ 4` bytes costs one or two reads, depending on
  `(b_base + k·ldb + n0) mod 4`, so unaligned `ldb` can double B traffic (`RD_WORDS` / `FILL_BYTES` in the
  utilisation report).

## 4. Performance limits (measured, `reports/tile_utilisation.md`)

* **The single 32-bit SFB2 port is the bottleneck.** A 4×4 slice needs 2 operand words without reuse, so the
  slice rate is at most about 0.5. With M-major order and REUSE the A traffic largely disappears for K in one
  chunk or an even chunk count.
* **Behind the DataFabric crossbar (R6)**, only one transaction is in flight per port. Operand throughput then
  falls to about one word per memory latency, and the controller's `MAX_OUT` cannot help.
* **Fixed per-launch cost.** TC02 needs 1 + eff_m + eff_n fill/drain cycles and eff_m readout beats per launch,
  and TC03 tile set-up is about 16 cycles (hidden in overlap mode). Short chunks therefore lower utilisation.
* The controller does not choose the loop order, the chunk length or `REUSE` automatically: they are command
  fields. A host-side heuristic should pick them from M, N, K; doc 03 §4 gives the rules.

## 5. Implementation notes

* The address multipliers (validation products, block starts, C tile base, MAC check) are used once per command,
  step or tile. They could be time-shared or replaced by incremental pointers to save DSPs and timing.
* TC04's 16-bit tile tag wraps after 65 536 tiles in one GEMM. Both the sideband and the store path's tag check
  use the same truncated tag, so this is harmless.
