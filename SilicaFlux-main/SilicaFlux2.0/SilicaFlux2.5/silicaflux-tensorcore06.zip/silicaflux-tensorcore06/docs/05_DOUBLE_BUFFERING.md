# 05 — Double buffering

The ping-pong buffers are TC03's two operand sets (`NUM_SETS = 2`). TC03 already enforces ownership. This
module adds the decision of *when* to overlap, and the evidence that it is safe and that it helps.

## 1. Ownership: who may touch a set, when

```
        loader                                    scheduler
fill_begin ─▶ FILL ─(writes, all acked)─▶ fill_end ─▶ READY ─▶ cmp_begin ─▶ COMPUTE ─(last slice)─▶ cmp_end ─▶ EMPTY
```

* The loader writes only between its own `fill_begin` and `fill_end` handshakes. TC03 refuses any write to a set
  that is not in FILL (`OWNER`, no side effect). None was refused in the regression; an `OWNER` error would be a
  fatal `INTERNAL/FILL_RSP`.
* The loader issues `fill_end` only when **every** write of the step has been acknowledged by TC03
  (`issued == acked`), so a READY set is complete.
* The scheduler uses a set only between `cmp_begin` (READY) and `cmp_end`. TC03 accepts `cmp_end` only when its
  operand engine is drained, i.e. the array has accepted every slice.
* The set index always comes from TC03 (`fill_set`, `cmp_set`). The controller keeps no copy of the
  alternation that could drift.

## 2. The conditions for overlap

| Condition (brief §7) | How it holds |
|---|---|
| Buffer ownership correct | §1: every access is inside a TC03 ownership window, and the windows of one set never overlap (TC03 state machine). |
| No data hazards | **RAW on operands:** compute starts only after `fill_end`, which follows the last write acknowledgement. **WAR on operands:** a set is refilled only after `cmp_end`, which follows the last slice read. **The layout table:** the loader publishes a set's layout at `fill_begin`, when the set is EMPTY, so the scheduler has already consumed the previous layout. **The TC04 sideband:** it is latched at `LAUNCH`, after the previous launch is retired. **The store's tile table:** a FIFO in commit order, not a per-slot table, so the next tile's RESERVE cannot overwrite the address of a tile still being written. **C vs A/B:** C may not alias A or B (`ALIAS`), so stores cannot change operands that are still to be loaded or reused. |
| Completion tracked | fill acks → `fill_end`; slice handshakes → `cmp_end`; readout `m_last` + TC04 `PF_CHUNKS` → retire; SFB2 write acks → tile complete. No latency constant is used anywhere. |
| Performance actually improves | measured: §4 and `reports/tile_utilisation.md` §2 |

With **one set**, the same code runs safely: TC03 refuses `fill_begin` until `cmp_end`, so loads cannot overlap
compute and only the store/compute overlap remains.

## 3. What overlap mode changes (flags.OVERLAP)

| | serial (0) | overlap (1) |
|---|---|---|
| loader | starts step s only when the scheduler is in LOAD of step s | free-running, at most NUM_SETS steps ahead (TC03) |
| TC03 tile set-up of step s+1 | after step s is retired | while step s drains and reads out of the array |
| retire of step s (ACCUMULATE) | right after COMPUTE of step s | just before LAUNCH of step s+1 |
| store of tile t | the scheduler waits (STORE) before tile t+1 | in parallel with tile t+1 (2 TC04 slots) |

## 4. Measured benefit

The only claim is a measured one: the same GEMM on the same hardware, with only the flag or the set count
changed. All runs pass the full functional check. See `reports/tile_utilisation.md` §2 (1-cycle memory) and §5
(8-cycle memory). The `OVERLAP` counter (a fill write and a slice handshake in the same cycle, from TC03) shows
that loads really run under compute. It is 0 in every serial run and in every single-set run.

Where the benefit is small, the report says so. For a single tile with a single chunk there is nothing to
overlap: the GEMM is one load, one compute, one store.
