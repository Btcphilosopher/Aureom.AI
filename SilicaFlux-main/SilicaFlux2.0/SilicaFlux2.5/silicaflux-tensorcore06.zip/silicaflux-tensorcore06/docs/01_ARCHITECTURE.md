# 01 — Architecture

```
                     GEMM command (valid/ready)                    completion record (valid/ready)
                              │                                                 ▲
┌─────────────────────────────▼─────────────── tensor_tile_controller ─────────┴──────────────────────┐
│  ttc_validate ── scheduler FSM (st) ── ttc_tile_iter (scheduler copy)          ttc_perf (24 ctrs)   │
│        │              │  RESERVE/INIT        │ LOAD/TILE/ACCUMULATE/LAUNCH/COMPUTE      │ STORE       │
│        │              ▼                      ▼                                          ▼            │
│        │      TC04 cfg + ps sideband   TC03 cmp_begin/end, tile desc,            ttc_store           │
│        │                               TC02 cfg                                  (tile FIFO, lanes)  │
│  ttc_loader (own iterator, PLAN, row/word AGU, residency) ──┐                         │ C writes    │
│        │ fill_begin/end                                     │ A/B word reads          │             │
│        │                                     ┌──────────────▼─────────────────────────▼──────────┐  │
│        │                                     │ ttc_sfb_master: RR, request register, credits,    │  │
│        │                                     │ outstanding FIFO, fill FIFO  ──▶ TC03 fill port   │  │
│        │                                     └────────────────────┬──────────────────────────────┘  │
└────────┼──────────────────────────────────────────────────────────┼─────────────────────────────────┘
         │                                                          │ SFB2 master (DataFabric PROTOCOL rev 2.0)
         ▼                                                          ▼
 TC03 tensor_operand_buffer ──k-slices──▶ TC02 tensor_systolic_array ──rows──▶ TC04 tensor_acc_subsystem
 (2 sets: A 512 B + B 512 B)              (4×4, one tile per launch)        (2 slots, exact INT32, odma ──▶ store)
```

* **Unmodified subsystems.** TC02, TC03 and TC04 are the archived RTL, byte-identical (`third_party/`). Slices go
  TC03 → TC02 and readout rows go TC02 → TC04 directly. The controller only taps their handshakes and supplies
  the TC04 sideband.
* **One external port.** All A/B operand reads and all C writes use one SFB2 master port. Requests are
  round-robin between the loader and the store. Up to `MAX_OUT` (8) are outstanding, and responses come back
  in order (R5). Credits guarantee every response can be absorbed (`rsp_ready = 1`).
* **No assumed latency.** Every wait is on a handshake or an event of the unit that does the work (doc 06 §1).

## Modules

| File | Lines | Role |
|---|---|---|
| `rtl/tensor_tile_controller.sv` | 658 | **primary source**: command registers, scheduler FSM, fatal-error detection, watchdog, completion record, counter increments |
| `rtl/ttc_validate.sv` | 139 | validation rules (doc 02 §3), chunk-count divider, footprints |
| `rtl/ttc_tile_iter.sv` | 97 | M-/N-major traversal with K innermost; boundary geometry |
| `rtl/ttc_loader.sv` | 327 | A/B address generator, local placement, TC03 fill ownership, residency/reuse |
| `rtl/ttc_store.sv` | 115 | C address generator, commit-order tile FIFO, tag check, lane serialiser |
| `rtl/ttc_sfb_master.sv` | 184 | SFB2 master, arbitration, credits, response routing, TC03 fill driver |
| `rtl/ttc_perf.sv` | 34 | saturating counter bank |
| `rtl/ttc_defs.svh` | 122 | encodings: flags, codes, states, counter indices |
| `rtl/tensor_gemm_engine.sv` | 301 | integration top: controller + TC03 + TC02 + TC04 |

## Hardware parameters (engine)

| Parameter | Default | Meaning |
|---|---|---|
| `TILE_M`, `TILE_N` | 4, 4 | array size (TC02 rows/cols, TC03 lanes, TC04 rows/cols) |
| `TILE_K` | 64 | maximum K chunk. It must satisfy the capacity bounds of doc 04 §4 (elaboration check). |
| `NUM_SETS` | 2 | TC03 sets (1 = single buffer) |
| `A_SET_BYTES`, `B_SET_BYTES` | 512, 512 | TC03 set sizes |
| `A_BANKS`, `B_BANKS`, `PORT_MODE`, `SET_MAP`, `READ_LATENCY`, `A_STAGE`, `B_STAGE` | 4, 2, 1R1W, SHARED, 1, 2, 4 | TC03 banking |
| `A_PAD` | 1 | odd-word A row stride in the buffer (doc 04 §3) |
| `NUM_SLOTS` | 2 | TC04 accumulator tiles |
| `ACC_RD_LAT`, `MUL_PIPE` | 1, 0 | TC04 storage latency, TC02 product register |
| `MAX_OUT`, `FILL_DEPTH`, `TI_DEPTH` | 8, 8, 8 | SFB2 outstanding, read buffering, tiles awaiting store |
| `MEM_LO`, `MEM_HI` | 0, 2³² | memory window for A, B and C |
| `WDOG_LOG2` | 16 | watchdog |

The regression covers six configurations: `base`; `single` (one set); `r2x3` (a 2×3 array, TILE_K 16, 128 B
sets); `r8x8` (8×8, TILE_K 32, 8 + 4 banks); `r1x1` (1×1, TILE_K 8, 64 B sets); `stress` (1RW banks, TC03
read latency 2, MUL_PIPE 1, TC04 RD_LAT 3, one accumulator slot, MAX_OUT 2, FILL_DEPTH 2, A_PAD 0). A seventh,
`wdog`, has `WDOG_LOG2 = 10` for the watchdog test.
