# 03 — Tiling strategy and loop order

## 1. Partitioning

```
output tiles  TILE_M × TILE_N  (= the physical array, TC02 ARRAY_ROWS × ARRAY_COLS)
K chunks      kc ≤ TILE_K      (cmd_kc, 0 = TILE_K; TILE_K is sized so a block always fits one TC03 set)
MT = ⌈M/TILE_M⌉, NT = ⌈N/TILE_N⌉, KT = ⌈K/kc⌉,   steps = MT·NT·KT,   array launches = steps
```

The traversal is a nest of three loops: over M tiles, over N tiles and over K chunks
(`rtl/ttc_tile_iter.sv`, mirrored in `model/ttc_ref.py::steps`):

```
M-major (default)                         N-major (cmd flag NMAJOR)
for m0 in 0, TM, 2TM, … < M               for n0 in 0, TN, … < N
  for n0 in 0, TN, … < N                    for m0 in 0, TM, … < M
    for k0 in 0, kc, … < K                    for k0 in 0, kc, … < K
      step(m0, n0, k0)                          step(m0, n0, k0)
```

**Boundary tiles.** The last tile in each dimension is smaller than the array:
* `eff_m = min(TM, M − m0)`, `eff_n = min(TN, N − n0)`, `eff_k = min(kc, K − k0)`;
* only those rows, columns and K-steps are loaded, computed and stored;
* the array runs with `cfg_m = eff_m`, `cfg_n = eff_n` and masks the remaining PEs (their slots are counted as
  padded MAC slots);
* nothing outside the matrix is ever part of a step (doc 04 §2).

**K beyond the buffer.** A K that does not fit one set is simply `KT > 1` chunks. TC04 accumulates them:
chunk 0 initialises the accumulator, chunks 1 … KT−1 add, and the tile commits after chunk KT−1 (doc 00 §4).
The regression runs one tile through up to 41 chunks (`1×1×(10·TILE_K+1)`) and the numeric extreme
`1×2×131071` through 2048 chunks.

## 2. The baseline: output-stationary, K innermost

The baseline order is M-major with K innermost, run serially (flags = 0). It was brought up first, through the
three regression stages:

| stage | shapes | what it proves |
|---|---|---|
| 1 | M ≤ TM, N ≤ TN, K ≤ TK | one tile, one chunk: load, launch, readout, commit, store |
| 2 | M ≤ TM, N ≤ TN, K > TK | one tile, many chunks: chunk sideband, merge, commit after the last chunk |
| 3 | 5×7×3, 17×13×29 (also in 4 chunks), 9×11×(2TK+7) | multiple M and N tiles, boundary tiles, all flags |

Only after all three stages passed on every configuration were the overlap, reuse and N-major options enabled
in the system tests.

**Data-reuse properties of the baseline.**
* **C (output) reuse: complete.** A tile's partial sums stay in TC04 until all K chunks have been added. C is
  written exactly once and never read, which is the minimum possible output traffic.
* **A reuse: none in serial mode without REUSE.** Every step reloads its A block and its B block. Operand
  traffic per step is `eff_m·eff_k + eff_k·eff_n` bytes (plus word-boundary overhead, doc 04 §2).
* **Accumulator footprint:** one tile in flight (two with overlap, matching TC04's two slots).

Total operand traffic of the baseline:
`Σ_steps (eff_m + eff_n)·eff_k ≈ K·(M·NT + N·MT)` bytes, i.e. A is read NT times and B is read MT times.

## 3. Alternatives evaluated

| Order / policy | Implemented | Reuse it buys | Cost / requirement | Evaluation |
|---|---|---|---|---|
| **M-major, K inner** (baseline) | yes | C exactly once | A read NT×, B read MT× | measured |
| **N-major, K inner** (`NMAJOR`) | yes | C exactly once | the same totals as M-major; consecutive steps share B instead of A | measured |
| **A reuse** (`REUSE`, M-major) | yes | the A block (m0, k0) is not reloaded if the target set already holds it | residency tags; C must not alias A (validated) | measured; the model predicts every hit exactly |
| **B reuse** (`REUSE`, N-major) | yes | the B block (k0, n0) likewise | as above | measured |
| **K-major** (k0 outermost) | **no** | A reused across all n0 *and* B across all m0 within a chunk | needs MT·NT accumulator slots open at once; TC04 has 2 | model only (`reports/tile_utilisation.md` §3) |

**When reuse hits.** TC03 sets alternate strictly. The set about to be filled at step s was therefore last
filled at step s − NUM_SETS, and a block is resident exactly when that step loaded the same block. For A in
M-major order, step s − NUM_SETS has the same chunk index only if **NUM_SETS is a multiple of KT**:
* **KT = 1** (K fits one chunk): A is reused by every step except the first NUM_SETS steps of each tile row.
* **KT = NUM_SETS = 2:** chunk k always lands in set k, so A is reused for every tile of a row after the first.
* **any other KT (KT > NUM_SETS, or KT = 2 with one set):** the set was refilled in between with a different
  chunk, so **A is never resident**. For example, 32×32×256 with `TILE_K = 64` (KT = 4) gets no reuse at all
  (measured, `reports/tile_utilisation.md` §3).
B in N-major order follows the same rule.

The traffic model (`model/ttc_ref.py::traffic`) encodes exactly this rule. The regression checks the measured
A/B load and reuse counters against it on every run (`scripts/run_regress.py::perf_checks`).

**Why K-major was not built.** It needs every output tile's accumulator live for the whole reduction (MT·NT
slots, for example 64 for 32×32 on a 4×4 array). It also turns the C commit into a burst at the very end.
With TC04 at `NUM_TILES = 2` it cannot run. The model shows the A/B traffic it would save; the brief asks not
to introduce a complex scheduler before the baseline is right, and the baseline plus reuse already removes
most of the A traffic in the cases where K-major would help.

## 4. Choosing an order (from the measurements)

`reports/tile_utilisation.md` gives the numbers. In short:
* The single 32-bit SFB2 port is the bottleneck. A 4×4 slice needs two operand words, so without reuse the
  array can run at most about half the time.
* `OVERLAP` hides load behind compute, but only with two sets.
* `REUSE` with M-major order removes most A traffic when K fits one chunk or the chunk count is even. N-major
  order does the same for B when N is small relative to M.
* Everything else (validation, readout, tile set-up) is a fixed per-launch cost, so short chunks lower
  utilisation.
