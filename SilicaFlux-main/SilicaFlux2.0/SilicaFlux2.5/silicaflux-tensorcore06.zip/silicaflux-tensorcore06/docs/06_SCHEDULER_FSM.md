# 06 — Scheduler state machine

The controller is two cooperating finite-state machines plus two autonomous data paths:

* the **scheduler FSM** (`tensor_tile_controller.sv`, register `st`, exported as `state[3:0]`) walks the steps of
  the GEMM and issues every subsystem command;
* the **loader FSM** (`ttc_loader.sv`, exported as `ld_state[2:0]`) fills operand sets;
* the **store path** (`ttc_store.sv`) and the **SFB2 master** (`ttc_sfb_master.sv`) have no sequencing state of
  their own beyond a lane counter, credit counters and FIFOs.

A *step* is one block `(m0, n0, k0)`: an output tile of `eff_m × eff_n` and a K chunk of `eff_k`. Both FSMs
iterate the same step sequence with their own `ttc_tile_iter` instance (doc 03).

## 1. Scheduler states

| Code | State | Brief step | Does | Leaves when (real completion signal) |
|---|---|---|---|---|
| 0 | `IDLE` | — | `cmd_ready = 1` | command handshake |
| 1 | `VALIDATE` | — | runs `ttc_validate` (doc 02 §3) | `v_done`: error → `COMPLETE` (no side effect); OK → `RESERVE` |
| 2 | `RESERVE` | 1 | `acc_cfg_valid` for slot `slot_ptr` (TC04 `k_total = K`, `n_chunks = ⌈K/kc⌉`); pushes `{C tile address, tag}` to the store path | TC04 `cfg_ready` handshake (slot FREE) |
| 3 | `INIT` | 2 | TC04 initialises partial sums with the first chunk itself (no clear pass); this cycle checks `cfg_reject` | next cycle (a reject is fatal `INTERNAL/ACC_REJECT`) |
| 4 | `LOAD` | 3, 4, 5 | `cmp_begin_valid`. In serial mode this is also the loader's permit to load *this* step's A and B blocks | TC03 `cmp_begin_ready` = the loader has finished `fill_end` on the set |
| 5 | `TILE` | 6 (a) | TC03 tile descriptor for the block as loaded (`a_res, lda_loc, b_res, ldb_loc, eff_m, eff_n, eff_k`) | TC03 tile response (error or geometry ≠ iterator → fatal) |
| 6 | `ACCUMULATE` | 7, 8 | waits for the **previous** launch: its last readout beat accepted by TC04 (`m_valid·m_ready·m_last`) **and** TC04's `PF_CHUNKS` event for it (the chunk merged into the accumulator) | `launch_pend = 0` and `merged = launched` |
| 7 | `LAUNCH` | 6 (b) | array `cfg_valid` with the tile response geometry; latches the TC04 sideband (`ps_slot/tag/chunk/chunk_k`) for this launch | TC02 `cfg_ready` handshake (array IDLE) |
| 8 | `COMPUTE` | 6 (c) | slices flow TC03 → TC02 directly; after the last slice handshake, `cmp_end_valid` releases the set | TC03 `cmp_end_ready` |
| 9 | `STORE` | 10, 11, 12 | waits until every reserved tile has all its C elements acknowledged by memory | `tiles_done = tiles_reserved` (+ at the end: loader done, bus idle, nothing pending) |
| 10 | `COMPLETE` | — | completion record (OK or execution error) | `cpl_ready` → `IDLE` |
| 11 | `ERROR` | — | completion record with a fatal code | `cpl_ready` → `HALT` |
| 12 | `HALT` | — | nothing; `cmd_ready = 0` | reset only |

Steps 9–12 of the brief ("repeat across K chunks, apply output processing, write the output tile, mark it
complete") are not separate scheduler states, because other units already do them:
* **repeat across K** is the iterator advance (§3);
* **output processing** is TC04's commit (exact INT32, saturate policy, overflow and error flags), checked by
  the store path;
* **write** is the store path (`ttc_store`), one SFB2 write per C element;
* **mark complete** is the SFB2 write acknowledgement of a tile's last element, flagged `tile_last` in the
  outstanding FIFO: `tiles_done += 1`.

`STORE` is where the scheduler *waits* for those completions.

**Redundant interlocks (found by mutation testing, `reports/mutation.md`).** Two waits are backed up by a
second, independent mechanism, so removing either one alone changes timing but not results:
* ACCUMULATE's retire wait is also enforced by TC02, which raises `cfg_ready` only in IDLE, after its readout's
  last beat;
* STORE's `tiles_done = tiles_reserved` is also implied, at the end of a command, by `bus_idle` (every write
  acknowledged) together with an empty tile FIFO.

Both waits are kept: they make the states mean what they say, and they feed the ARRAY_WAIT counter and the
MERGE self-check.

## 2. Transitions

```
            cmd                v_done/err
  IDLE ──────────▶ VALIDATE ───────────────────────────────────────────────┐
   ▲                   │ v_done/ok                                          │
   │                   ▼                                                    ▼
   │   ┌────────▶ RESERVE ──acc cfg hs──▶ INIT ──▶ LOAD ──cmp_begin hs──▶ TILE
   │   │  (first     ▲                              ▲                       │ tile rsp
   │   │   chunk)    │                              │                       ▼
   │   │             │        (next chunk,          │                  ACCUMULATE ◀────────────────┐
   │   │             │         same tile)           │                       │ retire_ok             │
   │   │             │                              │      tile_armed ┌─────┴──────┐ !tile_armed    │
   │   │             │                              │                 ▼            ▼               │
   │   │             │                              │              LAUNCH     ┌─ last chunk or ──┐  │
   │   │             │                              │                 │ arr   │  last step: STORE│  │
   │   │             │                              │                 ▼ hs    │  else: LOAD (adv)│  │
   │   │             │                              │              COMPUTE    └──────────────────┘  │
   │   │             │◀──── overlap & !last_step ───┼──── cmp_end hs ─┤                              │
   │   │             │      (adv; last_k→RESERVE,   │                 │ serial, or last step         │
   │   │             │       else→LOAD)  ───────────┘                 └──────────────────────────────┘
   │   │
   │   └──── STORE (serial, !last_step, tiles stored; adv) ◀── ACCUMULATE
   │                    │ last step, all stored, all idle
   └──── COMPLETE ◀─────┘                ERROR ──▶ HALT   (from any executing state on a fatal error)
```

The iterator advances (`ex_adv`) in exactly three places:
* `COMPUTE → next step` (overlap mode);
* `ACCUMULATE → LOAD` (serial mode, next chunk of the same tile);
* `STORE → RESERVE` (serial mode, next tile).

A fatal error has priority over every transition and also suppresses `ex_adv`.

## 3. The two modes as sequences

**Serial (`OVERLAP = 0`) — the baseline, one operation at a time.** Per output tile:

```
RESERVE  INIT  { LOAD[loader: fill_begin, A rows, B rows, wait acks, fill_end]  TILE  ACCUMULATE(no-op)
                 LAUNCH  COMPUTE  ACCUMULATE(this launch)  } × chunks   STORE(this tile written)
```

This is the brief's 12-step sequence literally. The loader may start a step only when the scheduler is in
`LOAD` of that same step (`ld_permit = (st == LOAD) && (ld_step == ex_step)`).

**Overlap (`OVERLAP = 1`).**
* The loader free-runs and is limited only by TC03 ownership: `fill_begin` needs an EMPTY set, so it can be
  at most `NUM_SETS` steps ahead.
* `COMPUTE` returns straight to the next step's `RESERVE`/`LOAD`/`TILE`, so the TC03 tile set-up (~16 cycles
  in TC03) runs while the array drains and reads out the previous chunk.
* `ACCUMULATE` retires that previous launch just before the next `LAUNCH`.
* The store of tile *t* runs while tile *t+1* computes. `STORE` is entered once, at the end.

What makes this legal is listed in doc 05 §2.

## 4. Loader FSM

| State | Does | Leaves when |
|---|---|---|
| `L_IDLE` | — | `run && permit && !done` |
| `L_PLAN` | block start addresses (`a_base + m0·lda + k0`, `b_base + k0·ldb + n0`), local layout, reuse decision against TC03's `fill_set` | next cycle |
| `L_BEGIN` | `fill_begin_valid` | TC03 `fill_begin_ready` (set EMPTY). Publishes the set's layout for the scheduler. |
| `L_A` | one SFB2 read per word of each A row (doc 04) | last word of the last row granted (skipped when A is resident) |
| `L_B` | the same for the B rows | last word granted (skipped when B is resident) |
| `L_WAIT` | — | `issued == acked`: every fill write of the step acknowledged by TC03 |
| `L_END` | `fill_end_valid`; updates the residency tags | TC03 `fill_end_ready` → next step, or `L_DONE` |
| `L_DONE` | — | next command (`gemm_init`) |

## 5. Structured control, no combinational loops

* Every subsystem command (`acc_cfg_valid`, `cmp_begin_valid`, `tile_valid`, `arr_cfg_valid`,
  `cmp_end_valid`, `fill_begin/end_valid`, `cpl_valid`) is a Moore output: a function of the state register
  and of other registers (`ti_full`, `tile_sent`, `slices_done`). None depends combinationally on a ready
  signal.
* The SFB2 `req_valid` is a flop, and `rsp_ready` is the constant 1 (SFB2 R3/R4).
* The only ready-to-ready path is store → TC04: `odma_ready = write granted ∧ last lane`. The grant depends on
  the store's `wr_valid`, which depends on TC04's `odma_valid`, which TC04's router computes from its own
  valid and state, not from `odma_ready`.
* **Proof by tool:** Yosys `check -assert` passes on the flattened `tensor_gemm_engine` (controller + TC02 +
  TC03 + TC04, `reports/synth.md`). That command fails on any combinational loop. Verilator `-Wall` reports no
  `UNOPTFLAT` in the new RTL.

## 6. Reset and errors

* Reset is asynchronous assert (as TC03 and SFB2 R11), active low; TC02/TC04 reset synchronously from the same
  `rst_n`, which the integration holds for several cycles. All state, FIFOs, credits, residency tags and
  counters are cleared. The memory side drops in-flight transactions (R11). The regression resets in the
  middle of GEMMs at four different points and then requires the re-issued GEMM to be exact.
* Execution errors (`BUS_READ`, `BUS_WRITE`, `ACC_OVF`) are recorded (the first wins) and the command drains
  normally, so every subsystem is back in a consistent state before the record.
* Fatal errors (`INTERNAL`, `WATCHDOG`) cannot be drained safely: a subsystem may be holding a half-processed
  tile. The record is produced and the controller halts; only reset restarts it.
