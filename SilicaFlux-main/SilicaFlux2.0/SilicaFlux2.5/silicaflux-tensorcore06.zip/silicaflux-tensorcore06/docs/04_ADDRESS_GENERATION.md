# 04 — Address generation

Three address generators, all byte-exact, all with explicit byte strides:

| Generator | File | Produces |
|---|---|---|
| A / B source and buffer addresses | `rtl/ttc_loader.sv` | SFB2 read word addresses, TC03 fill-window word addresses, byte strobes |
| TC03 tile descriptor | `rtl/tensor_tile_controller.sv` (TILE state) | where the block sits inside the set |
| C destination addresses | `rtl/ttc_store.sv` (+ the C tile base computed at RESERVE) | SFB2 write word addresses |

## 1. Matrix addresses

```
A[m][k]  = a_base + m·lda + k                (INT8, 1 byte)
B[k][n]  = b_base + k·ldb + n                (INT8, 1 byte)
C[m][n]  = c_base + m·ldc + 4·n  .. +3       (INT32, little-endian)
```

For a step `(m0, n0, k0)` with `eff_m = min(TILE_M, M−m0)`, `eff_n = min(TILE_N, N−n0)`, `eff_k = min(kc, K−k0)`:

```
A block row i  (0 ≤ i < eff_m):  bytes [sA_i, sA_i + eff_k)   sA_i = a_base + (m0+i)·lda + k0
B block row k  (0 ≤ k < eff_k):  bytes [sB_k, sB_k + eff_n)   sB_k = b_base + (k0+k)·ldb + n0
C tile  row r  (0 ≤ r < eff_m):  words c_tile + r·ldc + 4j, 0 ≤ j < eff_n,   c_tile = c_base + m0·ldc + 4·n0
```

The block start (`a_base + m0·lda + k0`, `b_base + k0·ldb + n0`) and `c_tile` are computed with one multiply
each, once per step (or tile). They are 64-bit wide, so nothing wraps. Rows advance by adding the stride.

## 2. Word reads from memory (SFB2 has no read strobe)

SFB2 reads are whole aligned words (R10). For a row segment `[s, s + len)`:

```
words  w = ⌊s/4⌋ … ⌊(s + len − 1)/4⌋              (nw = ((s mod 4) + len − 1)/4 + 1 words)
strobe of word j: bytes b with  lo ≤ b ≤ hi,  lo = (j = 0 ? s mod 4 : 0),  hi = (j = nw−1 ? (s+len−1) mod 4 : 3)
```

* **No word that lacks a byte of the row is read.** In particular no word made only of row padding
  (`lda > K`) or of bytes beyond the matrix is read. The testbench checks every read against the element map
  of the running command.
* A boundary word of a row can contain bytes that are not elements of *this row segment*: the previous or next
  row, padding, or bytes before `a_base`. These come back with the word (SFB2 has no byte-granular read). They
  are **discarded**: the strobe stops them from reaching the buffer.

## 3. Local placement in the operand buffer (no byte shifter)

TC03 is told where the block sits inside the set with an ordinary tile descriptor, so the controller may choose
the local layout. It keeps every local row at the **same byte offset modulo 4** as its source row:

```
a_res   = sA_0 mod 4        lda_loc = smallest x ≥ eff_k with x ≡ lda (mod 4)   [+4 if A_PAD and x ≡ 0 (mod 8)]
b_res   = sB_0 mod 4        ldb_loc = smallest x ≥ eff_n with x ≡ ldb (mod 4)
A row i lives at in-set byte a_res + i·lda_loc,  B row k at b_res + k·ldb_loc
```

Because `sA_i ≡ a_res + i·lda_loc (mod 4)` for every i, source word `⌊sA_i/4⌋ + j` maps to exactly one local
word `⌊(a_res + i·lda_loc)/4⌋ + j` with the **same byte lanes**. So each read response becomes one fill
write with the strobe from §2: no alignment network, no read-modify-write, and unaligned bases and odd strides
cost nothing.

The descriptor TC03 receives is the block as a small matrix: `a_addr = a_res`, `lda = lda_loc`,
`b_addr = b_res`, `ldb = ldb_loc`, `m0 = n0 = k0 = 0`, `mat_m = eff_m`, `mat_n = eff_n`,
`mat_k = tile_k = eff_k`. TC03 re-validates it (LD, overflow, range). A rejection is a fatal internal error, and
none occurs in the regression.

**A_PAD.** With `lda ≡ 0 (mod 8)` (dense INT8, K a multiple of 8), `lda_loc` would be an even number of words,
and the four A rows would start in banks of the same parity. TC03 doc 03 shows this costs rate. `A_PAD = 1`
adds one word. Its effect is measured in `reports/tile_utilisation.md` §4.

TC03 fill-window address of a local word:
`A: set·A_SET_BYTES + local`; `B: REGION + set·B_SET_BYTES + local`, with
`REGION = max(NUM_SETS·A_SET_BYTES, NUM_SETS·B_SET_BYTES)` (TC03 `tob_dma_port`).

## 4. Checks

| Check | Where | How |
|---|---|---|
| **Integer overflow** | validation | every footprint end computed in 64 bits; `last ≥ 2³²` → `ADDR_OVF`. Per-step products are 64-bit; their high halves are provably 0 inside a validated footprint. |
| **Alignment** | validation | C base and `ldc` multiples of 4 (`ALIGN`); A/B unrestricted (§3); every SFB2 address is word-aligned by construction (testbench R9 monitor). |
| **Address range** | validation + runtime guards | footprints inside `[MEM_LO, MEM_HI)` (`RANGE`); C ∩ A/B = ∅ (`ALIAS`). At run time every read word must lie in `[a_base, a_last]` or `[b_base, b_last]` and every write in `[c_base, c_last]`, else the request is suppressed and `INTERNAL/GUARD_RD/WR` is raised (never seen in the regression). |
| **Buffer capacity** | elaboration | worst case over every legal command: `3 + (TILE_M−1)·(TILE_K+3+4·A_PAD) + TILE_K ≤ A_SET_BYTES`, `3 + (TILE_K−1)·(TILE_N+3) + TILE_N ≤ B_SET_BYTES`, else `$fatal` (checked in `reports/lint.md`). At run time `kc ≤ TILE_K` (`CHUNK`), so no command can overflow a set. A K larger than a set can hold is simply more chunks. |
| **Partial-tile masks** | iterator + TC02/TC03/TC04 | `eff_m/eff_n/eff_k` from the iterator. TC03 zeroes dead lanes and clears the mask bits. TC02 masks inactive PEs (`perf_pad` counts the lost slots). TC04 marks `o_col_mask`. The store writes exactly the masked-in lanes (contiguity is checked). Every boundary combination is tested, and the bytes between C rows and after the last column are verified unchanged. |
| **Leading dimensions** | validation | `lda ≥ K`, `ldb ≥ N`, `ldc ≥ 4N` (`LD`) |

## 5. Address sequence example

A 4×4×29 step from `a_base = 0x1000_0101`, `lda = 32`: `a_res = 1`; `29 + ((32 − 29) mod 4) = 32` is a multiple of 8, so with the default `A_PAD = 1`, `lda_loc = 36`:

| row | source bytes | words read | first / last strobe | local start |
|---|---|---|---|---|
| 0 | 0x101 … 0x11D | 0x100 … 0x11C (8) | `1110` / `0011` | 1 |
| 1 | 0x121 … 0x13D | 0x120 … 0x13C (8) | `1110` / `0011` | 37 |
| … | | | | |

32 reads move 116 bytes. The 12 extra bytes are discarded by the strobes.
