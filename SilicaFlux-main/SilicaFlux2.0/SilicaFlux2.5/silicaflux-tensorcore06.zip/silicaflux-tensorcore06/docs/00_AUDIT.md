# 00 — Repository audit

Scope: everything TENSORCORE 06 has to drive. Sources inspected are the archives in
`btcphilosopher/Aureom.AI` under `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. Nothing was assumed to exist
until its RTL was read and elaborated here (Icarus 12, Verilator 5.020).

## 1. Summary

| Subsystem | Archive | Exists? | Used here | How |
|---|---|---|---|---|
| Systolic array | `silicaflux-tensorcore02.zip` | **yes**, RTL + tests | **yes, unmodified** | `third_party/silicaflux-tensorcore02/` |
| Operand buffers | `silicaflux-tensorcore03.zip` | **yes**, RTL + tests | **yes, unmodified** | `third_party/silicaflux-tensorcore03/` (+ its SRAM-library subset and DataFabric `dma_fifo`) |
| Accumulator | `silicaflux-tensorcore04.zip` | **yes**, RTL + tests | **yes, unmodified** | `third_party/silicaflux-tensorcore04/` |
| Quantisation engine | `silicaflux-tensorcore05.zip` | **yes**, RTL + tests | **no** (deliberately, §6) | INT32 output only; TC04's `oquant_*` port stays the integration point |
| DMA | `silicaflux-hpc-m05-dma-adapter.zip` | **yes** (1-D copy engine) | **protocol reused, engine not** (§5) | the controller's own 2-D tile mover speaks the same SFB2 master protocol and the same Module-04 port protocol |
| HPC command queue | `silicaflux-hpc-m06-command-queue.zip` | **yes** (DMA + vector opcodes) | **no** (no tensor opcode, §7) | the controller exposes a structured GEMM command port; an M06 v2 descriptor mapping is proposed in doc 02 |

Every reused file is byte-identical to the archive copy (`third_party/SHA256SUMS`, `third_party/PROVENANCE.md`).
The TC02 copies embedded in the TC03 and TC04 archives were checked identical to the TC02 archive before
choosing one copy.

## 2. TENSORCORE 02 — `tensor_systolic_array`

* Output-stationary R×C array. `C[m,n] = A[m,K]·B[K,n]` for **one tile per launch**, `m ≤ R`, `n ≤ C`,
  `1 ≤ K < 2^K_WIDTH` (default 17 bits).
* Launch: `cfg_valid/cfg_ready` with `cfg_m, cfg_n, cfg_k`. `cfg_ready` is high only in IDLE. Illegal
  configurations pulse `cfg_reject` one cycle later and are dropped.
* Operands: one unskewed k-slice per handshake (`s_a = A[:,k]`, `s_b = B[k,:]`). The array skews internally.
  It exports `s_k`, the index of the slice it expects next.
* **The PE accumulators are cleared at every launch** (one-cycle CLEAR state). A launch therefore computes one
  K-chunk's partial sum only. Merging chunks is not the array's job.
* Completion is **real**: DRAIN ends only when every active PE has committed its `last`-tagged product;
  then READOUT streams M rows (`m_valid/m_ready`, `m_row`, `m_data`, `m_col_mask`, `m_last`). `tile_done`
  is high throughout READOUT. No fixed latency is involved.
* Per-launch counters, cleared at each launch: `perf_busy` (CLEAR+RUN+DRAIN cycles), `perf_issue` (= K),
  `perf_stall_up`, `perf_stall_ext`, `perf_mac` (useful MACs actually committed), `perf_pad` (PE slots lost to
  partial tiles per slice).
* Limits: one tile in flight; the next launch waits for readout to finish.

## 3. TENSORCORE 03 — `tensor_operand_buffer`

* Banked A and B buffers, `NUM_SETS` = 1 (single) or 2 (ping-pong), built from the SRAM wrapper library.
* **Fill port**: write-only, Module-04 port protocol (`dma_req_*`, `dma_rsp_*`), word granular with byte
  strobes. Window: A region `[0, NUM_SETS·A_SET_BYTES)`, B region from `REGION = max(A_TOTAL, B_TOTAL)`.
  Errors (RANGE, ALIGN, OWNER, UNSUP) have no side effect.
* **Ownership**: four valid/ready commands `fill_begin → fill_end → cmp_begin → cmp_end` move a set
  EMPTY → FILL → READY → COMPUTE → EMPTY. A write to a set that is not in FILL is refused (OWNER). `cmp_end`
  is accepted only when the operand engine has delivered every slice. Sets are used in strict alternation.
  **Set contents are not cleared by any transition** (arrays are never reset); this is what makes operand
  reuse possible (doc 03 §4).
* **Tile descriptor**: `a_addr, lda, b_addr, ldb` (byte addresses inside the compute set), `m0, n0, k0`,
  `mat_m, mat_n, mat_k`, `tile_k`. It is validated (EMPTY, LD, A/B overflow, A/B range), and answered on
  `tile_rsp_*` with `eff_m, eff_n, eff_k`, which are exactly the array's `cfg_m, cfg_n, cfg_k`. Unaligned
  `a_addr`/`b_addr` and any `lda ≥ mat_k` are supported.
* Slices are TC02-compatible (`s_valid/s_ready/s_a/s_b/s_k`, dead lanes zeroed, masks).
* Events (`ev_inc`, 20 × 8 bits): starvation (A/B), array back-pressure, bank conflicts, read/write stalls,
  forced writes, overlap (a DMA write and a slice in the same cycle), tile ok/err.
* Asynchronous active-low reset.
* What TC03 does **not** do: it does not know where the matrices live in system memory and does not move
  data. Its own integration test wrote a whole small matrix into one set from the testbench. Nothing in the
  repository tiles a large GEMM through it. That is this module's job.

## 4. TENSORCORE 04 — `tensor_acc_subsystem` (accumulator + storage + output router)

* `NUM_TILES` output-tile slots. A slot is opened with `cfg_*` (`slot, tag, m, n, k_total, n_chunks, bias,
  dest`); `cfg_ready` is high when the addressed slot is FREE. Illegal configurations pulse `cfg_reject`
  with a code one cycle later. With `STRICT_RANGE = 1` a tile whose `k_total` could overflow INT32 is
  rejected (`k_total ≤ 131 071` for INT8 operands without bias).
* Partial sums arrive straight from the array readout (`ps_*` = `m_*`) plus a sideband held for the launch:
  `ps_slot, ps_tag, ps_chunk, ps_chunk_k`. Chunk `c` of a row is applied exactly once; replays are dropped;
  a skipped chunk is an error. A beat for a FREE slot is dropped as `PE_NO_TILE`, so **the slot must be
  opened before the first chunk's readout**.
* **The first chunk initialises the accumulator directly** (no clear pass, no read of stale storage). This is
  how the brief's step 2 ("clear or initialise partial sums") is met; the controller issues no HC_CLEAR.
* A tile commits only after every row has applied `n_chunks` chunks and exactly `k_total` K-steps. Committed
  rows leave on the selected destination port (`osram/oquant/odma`, shared payload: exact `o_wide`, INT32
  `o_data`, `o_ovf`, `o_clip`, `o_err`) in commit order. The slot becomes FREE when its last commit read is
  issued; `cmt_done` pulses when the last row leaves.
* Event vector `ev_inc` (PF_CHUNKS = chunk merged on all rows, PF_COMMIT_TILES, …) and counters.
* Synchronous active-low reset (the TC02 array is also synchronous; TC03 is asynchronous). One `rst_n`
  held for several cycles resets all three correctly.

## 5. DMA — Module 05 `hpc_dma_adapter` and the DataFabric SFB2 protocol

* The adapter executes **one-dimensional** copies (`src, dst, len` bytes). Source and destination must be
  DW-aligned (4 bytes).
* SFB2 rules that matter here (`PROTOCOL.md`): R2 no withdrawal of a presented request; R3 `req_valid`
  must not depend combinationally on `req_ready`; R4 `rsp_ready` must not depend on `req_ready`; R5 exactly one
  response per request, **in order**; R7 a write response means the write was performed; R9 word-aligned
  addresses; **R10 reads always return the full word** (no read strobes); R11 reset cancels everything.
* Why the adapter is not used to move tiles:
  1. A tile is a **2-D strided gather** (`eff_m` rows of `eff_k` bytes at stride `lda`, `eff_k` rows of
     `eff_n` bytes at stride `ldb`). The adapter would need one descriptor per row (4 cycles of set-up per
     descriptor plus its completion handshake).
  2. INT8 rows start at arbitrary byte addresses (`a + r·lda + k0`). The adapter rejects unaligned
     sources and destinations (`SRC_ALIGN`/`DST_ALIGN`). The GEMM contract must accept, for example,
     `lda = 29`.
  3. The baseline engine moves 1 byte/cycle (4101 cycles for 4 KiB, M05 `reports/cycles.md`).
* So the controller contains a small **2-D tile mover** that speaks SFB2 on its master port (it can sit on the
  same DataFabric crossbar port as the adapter) and the Module-04 port protocol on the TC03 fill port.
  Unaligned rows are handled without a byte shifter: the controller places each row in the buffer at the
  same byte offset modulo 4 as in memory (doc 04 §3).

## 6. TENSORCORE 05 — `tensor_quantize`

* Exists and is verified (INT32 pass-through, bias, INT8 requantisation, ReLU, per-channel parameters).
* It consumes TC04's `oquant_*` port and needs a 256-bit OPEN descriptor per tile plus a parameter table.
* **Not integrated here.** The GEMM contract of this module is INT32 output, so output processing is the
  TC04 commit: exact INT32, saturate policy, overflow and error flags checked by the controller (doc 06).
  Requantised output would change the C element size and the store address generator. It is listed as the
  first integration step in doc 09.

## 7. Module 06 — `hpc_command_queue`

* Command ABI v1: 256-bit descriptors, opcodes NOP, DMA_LOAD/STORE, VECTOR_ADD/MUL/FMA, FENCE,
  RESET_COUNTERS. **No tensor opcode.** Every other code point is reserved and rejected.
* A GEMM needs nine operand fields (three bases, M, N, K, three strides) plus layout/type/flags. That does not
  fit the v1 layout without a new `VERSION`.
* The controller therefore exposes a **structured GEMM command port** (valid/ready, explicit fields) and
  one in-order completion record per command. Doc 02 §5 proposes the v2 descriptor and an opcode class (`0x4X`
  tensor) for a later M06 executor port. That integration is not implemented (doc 09).

## 8. Consequences for the design

1. K-chunk merging is done by TC04, driven by the controller's `ps_chunk` sideband. The controller does not add
   anything.
2. The controller must open the TC04 slot before launching chunk 0 of a tile.
3. Tile operands must be moved from system memory into a TC03 set in FILL state, then handed over with
   `fill_end`/`cmp_begin`, then described to TC03 as a small matrix.
4. Completion is tracked from real signals only: SFB2 responses, TC03 fill responses, `tile_rsp`, the slice
   handshakes, the array's `m_last` readout handshake, TC04's `ev_inc[PF_CHUNKS]` and committed beats, and the
   SFB2 write acknowledgements of every C element.
