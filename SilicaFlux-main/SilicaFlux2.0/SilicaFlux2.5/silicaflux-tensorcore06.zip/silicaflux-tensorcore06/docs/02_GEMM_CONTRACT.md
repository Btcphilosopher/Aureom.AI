# 02 — GEMM contract, command port and validation

## 1. Operation

```
C[M,N] = A[M,K] × B[K,N]          C[m][n] = Σ_k A[m][k] · B[k][n]
```

| Item | Contract |
|---|---|
| Matrices | dense |
| A, B elements | signed INT8 (two's complement) |
| Accumulation | exact; INT32 range guaranteed by `K ≤ 131 071` (largest K for which `K·(−128)²` fits INT32) |
| C elements | signed INT32, little-endian, naturally aligned |
| Layout | **row-major only**, explicit leading dimensions in **bytes** |
| `A[m][k]` | byte `a_base + m·lda + k` |
| `B[k][n]` | byte `b_base + k·ldb + n` |
| `C[m][n]` | bytes `c_base + m·ldc + 4n … +3` |
| Dimensions | `1 ≤ M, N ≤ 65 535`, `1 ≤ K ≤ 131 071` |
| Transposition | **never**. A column-major (transposed) operand or result is rejected with `LAYOUT`. |

A and B are read-only, C is write-only. C is written exactly once per element. No byte of memory outside the
C elements is written: padding between C rows (`ldc > 4N`) is never touched.

## 2. Command port

Valid/ready. One command is accepted when the controller is IDLE (`cmd_ready`). Commands run one at a time,
in order. Every accepted command produces exactly one completion record.

| Field | Width | Meaning |
|---|---|---|
| `cmd_tag` | 8 | echoed in the completion record |
| `cmd_flags` | 8 | bit 0 `OVERLAP` (prefetch / deferred retire / overlapped store), bit 1 `REUSE` (skip resident operand blocks), bit 2 `NMAJOR` (N-major tile order); bits 3–7 reserved, must be 0 |
| `cmd_a_layout`, `cmd_b_layout`, `cmd_c_layout` | 2 each | 0 = row-major (supported); 1 = column-major / transposed (rejected); 2, 3 reserved (rejected) |
| `cmd_a_type`, `cmd_b_type` | 2 each | 0 = INT8 (supported); others rejected |
| `cmd_c_type` | 2 | 0 = INT32 (supported); others rejected |
| `cmd_m`, `cmd_n`, `cmd_k` | 32 each | dimensions. They are 32-bit fields so that out-of-range values reach validation instead of being truncated. |
| `cmd_kc` | 32 | K chunk length; 0 = `TILE_K` (the hardware maximum, chosen so a block fits one buffer set) |
| `cmd_a_base`, `cmd_b_base`, `cmd_c_base` | 32 each | byte addresses |
| `cmd_lda`, `cmd_ldb`, `cmd_ldc` | 32 each | byte strides between consecutive rows |

The flags change only the schedule, never the result. The regression runs every flag combination on the same
problems and requires identical, reference-exact results.

## 3. Validation (before any side effect)

The rules run in this order and the first failure wins. A failing command performs **no bus access and no
subsystem command**; the regression checks zero SFB2 transactions. All address arithmetic is 64 bits wide, so
an overflow is detected rather than wrapped.

| # | Code | Name | Condition |
|---|---|---|---|
| 1 | 1 | `FLAGS` | `cmd_flags & 0xF8 ≠ 0` |
| 2 | 2 | `LAYOUT` | any layout ≠ row-major |
| 3 | 3 | `DTYPE` | A or B not INT8, or C not INT32 |
| 4 | 4 | `DIM_ZERO` | `M = 0`, `N = 0` or `K = 0` |
| 5 | 5 | `DIM_RANGE` | `M > 65535`, `N > 65535` or `K > 131071` |
| 6 | 6 | `CHUNK` | `kc > TILE_K`, or `⌈K / kc⌉ > 65535` (TC04 chunk counter width) |
| 7 | 7 | `LD` | `lda < K`, `ldb < N` or `ldc < 4N` (rows would overlap) |
| 8 | 8 | `ALIGN` | `c_base` or `ldc` not a multiple of 4 (INT32 natural alignment). A and B have **no** alignment requirement. |
| 9 | 9 | `ADDR_OVF` | last byte of A, B or C ≥ 2³²: `a + (M−1)·lda + K − 1`, `b + (K−1)·ldb + N − 1`, `c + (M−1)·ldc + 4N − 1` |
| 10 | 10 | `RANGE` | a footprint `[base, last]` leaves the memory window `[MEM_LO, MEM_HI)` (parameters) |
| 11 | 11 | `ALIAS` | the C footprint intersects the A or the B footprint (conservative bounding-interval test) |

Validation takes 21 cycles: one cycle for the three footprint products, 18 cycles for the chunk-count
division `⌈K/kc⌉` (a restoring divider, so no divider macro is needed), one cycle for the checks, and one
cycle for the transition. The products use only the low 16/17 bits of `M−1` / `K−1`. That is safe because an
out-of-range dimension has already failed rule 5.

The Python reference (`model/ttc_ref.py::validate`) implements the same table independently. The generator
asserts that every negative test fails *with the intended rule*, and the testbench checks the code.

## 4. Completion record

| Field | Meaning |
|---|---|
| `cpl_tag` | the command's tag |
| `cpl_err`, `cpl_code` | 0 = OK, else a code from §3 or the table below |
| `cpl_err_addr` | bus errors: the word address answered with an error; `INTERNAL`: the sub-code |
| `cpl_cycles` | cycles from acceptance to the completion record |
| `cpl_tiles` | output tiles completed (every C element of the tile written **and acknowledged**) |
| `cpl_chunks` | array launches (K chunks executed) |

| Code | Name | Behaviour |
|---|---|---|
| 16 | `BUS_READ` | an SFB2 read returned `rsp_error` (its data is 0, per SFB2 R8). The command drains completely: every tile is computed and written, with the failing word's operand bytes taken as 0. The first error is reported. |
| 17 | `BUS_WRITE` | an SFB2 write returned `rsp_error` (that element is unchanged, per R8). The command drains completely. |
| 18 | `ACC_OVF` | TC04 flagged an accumulation overflow. This is unreachable after rule 5 and is kept as a guard. |
| 24 | `INTERNAL` | a subsystem refused something the controller generated, or a self-check fired (sub-codes `TTC_IE_*` in `rtl/ttc_defs.svh`). **Fatal:** the record is produced, then the controller HALTs until reset. |
| 25 | `WATCHDOG` | no handshake anywhere for 2^`WDOG_LOG2` cycles while executing. Fatal, as above. |

The regression checks codes 16 and 17 exactly, including the expected final memory under the error.

## 5. Proposed Module 06 descriptor (not implemented)

Module 06's v1 descriptor (256 bits) cannot hold nine operand fields. A v2 descriptor for a tensor opcode
class `0x4X` would be:

| Word | Field |
|---|---|
| 0 | `HDR`: `OPCODE = 0x40 TENSOR_GEMM`, `VERSION = 2`, `FLAGS[23:16]` (M06 IRQ / BARRIER + this module's OVERLAP / REUSE / NMAJOR), `TID` |
| 1–3 | `A_BASE`, `B_BASE`, `C_BASE` |
| 4 | `M[15:0]`, `N[31:16]` |
| 5 | `K[16:0]`, `KC[31:17]` (0 = TILE_K) |
| 6–8 | `LDA`, `LDB`, `LDC` |
| 9 | layouts / types (2 bits each), reserved |
| 10–11 | reserved, must be 0 |

That is 384 bits. The M06 scheduler would need a third executor port (alongside DMA and vector) whose
start/done/fail contract maps onto this module's command/completion ports. Doc 09 lists it as open work.
