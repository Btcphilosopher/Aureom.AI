# 07 — Performance instrumentation

`perf_cnt` holds 24 saturating counters of `CNT_W` (40) bits, cleared by reset or `perf_clear`. Indices are in
`rtl/ttc_defs.svh`. Counters accumulate across commands. Each completion record also carries the per-command
`cycles`, `tiles` and `chunks`.

| # | Name | Increments by | Exact definition |
|---|---|---|---|
| 0 | `BUSY` | 1 | cycle with the scheduler not in IDLE / HALT |
| 1 | `GEMM_OK` | 1 | completion record handshake with code 0 |
| 2 | `GEMM_ERR` | 1 | completion record handshake with code ≠ 0 |
| 3 | **tiles completed** `TILES` | 1 | SFB2 write acknowledgement of a tile's last C element (all earlier ones acknowledged before it: SFB2 R5) |
| 4 | `CHUNKS` | 1 | array launch handshake (one K chunk) |
| 5 | **useful MACs** `MAC_USEFUL` | TC02 `perf_mac` | at each readout's `m_last` handshake, the array's own count of committed products of that launch; cross-checked against `eff_m·eff_n·eff_k` (mismatch = fatal `INTERNAL/MAC`) |
| 6 | **padded MAC slots** `MAC_PAD` | TC02 `perf_pad` | likewise: `(R·C − eff_m·eff_n)` PE slots per issued slice |
| 7 | **compute cycles** `COMPUTE_CYC` | 1 | TC02 `busy ∧ ¬tile_done` (CLEAR + RUN + DRAIN) |
| 8 | `ISSUE_CYC` | 1 | k-slice handshake TC03 → TC02 |
| 9 | **DMA wait cycles** `DMA_WAIT` | 1 | scheduler in LOAD and TC03 `cmp_begin_ready = 0`: the step's operands are not loaded yet |
| 10 | **operand starvation** `STARVE` | TC03 `ev_inc[EV_STARVE]` | a tile is active in TC03, its output stage could take a slice, and an operand word is missing (bank conflict / staging) |
| 11 | **output stalls** `OUT_STALL` | 1 | the store path has a C write ready that is not granted (bus busy or back-pressured, or lost arbitration to an operand read) |
| 12 | **buffer switch events** `BUF_SWITCH` | 1 | `cmp_begin` handshake onto a different TC03 set than the previous step's |
| 13, 14 | `A_LOADS`, `B_LOADS` | 1 | A / B block moved by DMA (at `fill_end`) |
| 15, 16 | `A_REUSE`, `B_REUSE` | 1 | A / B block DMA skipped because the set already held it |
| 17 | `RD_WORDS` | 1 | SFB2 read request granted |
| 18 | `FILL_BYTES` | 1–4 | strobed operand bytes written into TC03 (= useful bytes moved) |
| 19 | `WR_WORDS` | 1 | SFB2 write request granted (one C element) |
| 20 | `ACC_WAIT` | 1 | RESERVE without handshake: no free TC04 slot or the tile FIFO is full |
| 21 | `ARRAY_WAIT` | 1 | ACCUMULATE waiting for the previous launch to finish and merge |
| 22 | `OVERLAP` | TC03 `ev_inc[EV_OVERLAP]` | cycle with a TC03 fill write **and** a slice handshake |
| 23 | `BUS_STALL` | 1 | `req_valid ∧ ¬req_ready` |

The names in bold are those the brief requires.

## Verification of the counters

The counters are checked, not only printed. On every regression run whose counters were never reset (no
reset test, no fatal error), `scripts/run_regress.py::perf_checks` requires these to equal the independent
model:

| counter | model |
|---|---|
| `GEMM_OK`, `GEMM_ERR` | number of commands expected to pass / fail |
| `TILES`, `CHUNKS` | `Σ MT·NT`, `Σ MT·NT·KT` |
| `MAC_USEFUL` | `Σ M·N·K` |
| `MAC_PAD` | `Σ_steps (R·C − eff_m·eff_n)·eff_k` |
| `ISSUE_CYC` | `Σ MT·NT·K` |
| `WR_WORDS` | `Σ M·N` |
| `A_LOADS`, `B_LOADS`, `A_REUSE`, `B_REUSE`, `RD_WORDS`, `FILL_BYTES` | `ttc_ref.traffic()` (set alternation + residency rule, word-span rule of doc 04 §2) |

The check also requires `STARVE` to equal TC03's own STARVE counter, TC03's TILE_OK and SLICES counters to
equal `CHUNKS` and `ISSUE_CYC`, and TC04's COMMIT_TILES and CHUNKS counters to equal `TILES` and `CHUNKS`.
Any difference fails the run.

The timing counters (cycles, waits, stalls) have no closed form. Their consistency is shown in the utilisation
report, and Icarus and Verilator must agree on them exactly.
