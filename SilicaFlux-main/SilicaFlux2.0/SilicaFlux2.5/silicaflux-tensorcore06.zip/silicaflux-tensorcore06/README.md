# SilicaFlux TENSORCORE 06 — Matrix tiling, address generation and tensor scheduling

**Primary source:** `rtl/tensor_tile_controller.sv` · Aureom.AI | SilicaFlux-HPC

The tensor tile controller lets the small SilicaFlux systolic array execute `C[M,N] = A[M,K] × B[K,N]` of any
supported size (dense, row-major, explicit byte strides, signed INT8 operands, INT32 accumulation,
`1 ≤ M, N ≤ 65 535`, `1 ≤ K ≤ 131 071`). It turns one GEMM command into the ordered memory, compute,
accumulation and output operations of the **existing, unmodified** TENSORCORE 02 array, TENSORCORE 03 operand
buffers and TENSORCORE 04 accumulator, through its own SFB2 port to system memory.

> **Not committed to GitHub** — delivered as a plain archive.
> Every number below comes from the generated reports in `reports/` (final run on these sources). Simulation,
> lint and Yosys synthesis only: no hardware run, no timing / Fmax claim.

## Results

| Check | Result | Report |
|---|---|---|
| Staged regression, stage 1: one tile, one K chunk (6 hardware configurations, 2 simulators) | **36 / 36 runs pass** | `regression.md` |
| Stage 2: one tile, many K chunks (incl. K far beyond the buffer capacity) | **36 / 36 runs pass** | `regression.md` |
| Stage 3: arbitrary M/N tiling with K chunks (5×7×3, 17×13×29, …) | **36 / 36 runs pass** | `regression.md` |
| Stage 4: masks, strides, back-pressure, latency, crossbar R6, reset, invalid commands, consecutive GEMMs, bus errors, watchdog, K = 131 071, large GEMMs | **182 / 182 runs pass** | `regression.md` |
| Icarus 12 vs Verilator 5.020, same seed: identical completion records (incl. cycle counts) and counters | **140 / 140 run pairs identical** | `regression.md` |
| GEMMs executed and checked / C elements compared with the Python reference | **3,403 / 260,528** | `regression.json` |
| Counters vs analytical model (tiles, chunks, MACs, padded slots, block loads, reuse hits, read words, fill bytes, writes) | every run with un-reset counters | `regression.md` |
| Mutation testing: deliberate controller bugs detected by the regression | **13 / 16 killed; 3 survivors analysed as equivalent (redundant interlocks / schedule-only), 0 unexplained** | `mutation.md` |
| Performance sweep: runs passing the functional check and matching the traffic model exactly | **384 / 384** | `tile_utilisation.md` |
| Lint: Verilator `-Wall` (7 configs, 0 warnings in new RTL), Icarus elaboration, 8 illegal parameter sets rejected | **16 / 16 checks pass** | `lint.md` |
| Yosys 0.33: controller and whole engine, `check -assert` (no combinational loop) and no latch | **4 / 4 runs OK** | `synth.md` |

**Definition of done — met:** matrix dimensions larger than the physical array execute correctly through
repeated tiles and K chunks. Examples: 17×13×29 on a 4×4 array (20 tiles, also in 4 chunks of 8); 32×32×256
(64 tiles × 4 chunks); 1×2×131 071 (2048 chunks, results exactly ±INT32 limit); 37×1 and 1×37 on 8×8 and 2×3
arrays. Every element is compared with an independent reference, and the rest of memory is verified untouched.

## Headline measurements (`reports/tile_utilisation.md`)

| measurement (4×4 array, 1-cycle memory unless stated) | value |
|---|---|
| 32×32×256 (64 tiles × 4 chunks): serial → overlap with two sets | 61205 → 36729 cycles (**1.67×**); one set with overlap: 57129 |
| array utilisation 32×32×256, serial / overlap | 26.8 % / 44.6 % (bus bound ≈ 50 %: 2 operand words per slice, 1 word per cycle) |
| 64×16×64, overlap → overlap + reuse + N-major (B reused across 16 M tiles) | 10041 → 6461 cycles, U 40.8 % → **63.4 %** |
| 17×13×29 (20 boundary-heavy tiles), serial → overlap + reuse + N-major | 3202 → 1486 cycles |
| 32×32×256 with an 8-cycle memory, serial → overlap | 78997 → 54143 cycles |
| 32×32×256 behind a crossbar-R6 memory (1 transaction in flight, 4-cycle latency), serial → overlap | 196053 → 171640 cycles |
| A_PAD (odd-word A rows in the buffer), 32×32×256: operand starvation cycles | 3328 → 768 |
| validation latency (every rejected command) | 21 cycles, zero bus transactions |

## What it does, in one paragraph

A command (bases, M, N, K, `lda/ldb/ldc` in bytes, layouts, types, flags) is validated before any side effect
(11 rules: reserved flags, layout — transposed operands are **rejected, never silently transposed** — types,
zero / out-of-range dimensions, chunk count, leading dimensions, C alignment, 64-bit address overflow, memory
window, C/A/B aliasing). The GEMM is then cut into `TILE_M × TILE_N` output tiles and `TILE_K` K chunks
(boundary tiles smaller than the array). For each step the scheduler:
1. reserves a TC04 accumulator slot (first chunk only; TC04 initialises the partial sums with that chunk);
2. waits until the loader has placed the A and B blocks into a TC03 set;
3. describes the block to TC03 and launches the array;
4. after the last slice, releases the set;
5. retires the launch only on the array's real readout completion plus TC04's chunk-merged event.

Committed rows are written back as INT32 C elements, and a tile is complete when every write is acknowledged.
The loader reads only words that hold matrix bytes and keeps each row at its source byte offset modulo 4, so
unaligned bases and odd strides need no byte shifter. Options: ping-pong prefetch (`OVERLAP`), skipping
operand blocks already resident in the set (`REUSE`), and N-major instead of M-major traversal.

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Audit: array, operand buffers, accumulator, quantiser, DMA, command queue; nothing assumed | `docs/00_AUDIT.md` |
| 2 | GEMM contract; reject unsupported layouts / invalid dimensions; no silent transpose | `docs/02_GEMM_CONTRACT.md`, `rtl/ttc_validate.sv`; `invalid` test (27 rejected commands, all 11 rules) |
| 3 | M/N tiles, K chunks, nested traversal, boundary tiles, no reads outside the matrix | `rtl/ttc_tile_iter.sv`, `docs/03`, `docs/04` §2; bus-level element-map check in every run |
| 4 | 12-step per-tile sequence on real completion signals, no guessed latency | `docs/06_SCHEDULER_FSM.md` §1 (step ↔ state ↔ signal table) |
| 5 | Simple baseline first; reuse documented; M-major / N-major / K-major / A reuse / B reuse evaluated | `docs/03_TILING_AND_LOOP_ORDER.md`; measured in `reports/tile_utilisation.md` §3 (K-major by model) |
| 6 | A/B/C address calculation with byte strides; overflow, alignment, range, capacity, masks | `rtl/ttc_loader.sv`, `rtl/ttc_store.sv`, `docs/04_ADDRESS_GENERATION.md` |
| 7 | Optional ping-pong; overlap only with correct ownership, no hazards, tracked completion; benefit measured | `docs/05_DOUBLE_BUFFERING.md`; `reports/tile_utilisation.md` §2, §5 |
| 8 | Documented FSM with IDLE, VALIDATE, LOAD, COMPUTE, ACCUMULATE, STORE, COMPLETE, ERROR; no combinational loops | `docs/06_SCHEDULER_FSM.md`; Yosys `check -assert` on the flattened engine |
| 9 | Tiles, useful MACs, padded slots, compute cycles, DMA wait, starvation, output stalls, buffer switches | `docs/07_PERFORMANCE_COUNTERS.md` (24 counters, model-checked) |
| 10 | 1×1×1, 4×4×4, 5×7×3, 17×13×29, K > capacity, masks, strides, back-pressure, latency, reset, invalid, multi-GEMM; full-matrix compare with an independent reference | `docs/08_VERIFICATION.md` §3, `reports/regression.md` |
| 11 | Deliverables | table below |

## Deliverables

| Deliverable | Files |
|---|---|
| `tensor_tile_controller.sv` | `rtl/tensor_tile_controller.sv` (+ `rtl/ttc_defs.svh`, `rtl/ttc_validate.sv`, `rtl/ttc_tile_iter.sv`, `rtl/ttc_perf.sv`) |
| Address generators | `rtl/ttc_loader.sv` (A/B, buffer placement, reuse), `rtl/ttc_store.sv` (C), `rtl/ttc_sfb_master.sv` (SFB2 port, TC03 fill port) |
| Scheduler state documentation | `docs/06_SCHEDULER_FSM.md` |
| Integration tests | `rtl/tensor_gemm_engine.sv` (controller + unmodified TC02/03/04), `tb/tb_gemm.sv`, `model/ttc_ref.py`, `model/gen_tests.py`, `scripts/run_regress.py` |
| Tile-utilisation report | `reports/tile_utilisation.md` (+ `perf.json`), `scripts/run_perf.py` |
| Known limitations | `docs/09_KNOWN_LIMITATIONS.md` |
| Also | `docs/00`–`05`, `07`, `08`; `reports/regression`, `mutation`, `lint`, `synth`; `third_party/` with `SHA256SUMS` and `PROVENANCE.md` |

## Quick start

```bash
make quick        # lint + stage 1 (one tile, one K chunk), Verilator, about a minute
```

```bash
make regress      # stages 1 -> 2 -> 3 -> 4 in order, Icarus + Verilator (16 min on 4 cores, measured)
```

```bash
make perf synth   # utilisation sweep (under 1 min) and Yosys estimates (5 min)
```

Tools: Icarus Verilog 12, Verilator 5.020, Yosys 0.33 (Ubuntu 24.04 packages), Python ≥ 3.10 (standard library
only). The directory is self-contained: `third_party/` holds every reused source, byte-identical to the archives
in `btcphilosopher/Aureom.AI`.

## Layout

```
rtl/          tensor_tile_controller.sv  ttc_validate.sv  ttc_tile_iter.sv  ttc_loader.sv  ttc_store.sv
              ttc_sfb_master.sv  ttc_perf.sv  ttc_defs.svh  tensor_gemm_engine.sv  files.f
tb/           tb_gemm.sv                          system testbench + SFB2 memory model
model/        ttc_ref.py                          independent reference, validation rules, traffic model
              gen_tests.py                        test catalogue -> build/tests/
scripts/      run_regress.py run_perf.py make_report.py run_mutants.py run_lint.py run_synth.py common.py
docs/         00 audit · 01 architecture · 02 GEMM contract · 03 tiling & loop order · 04 address generation
              05 double buffering · 06 scheduler FSM · 07 counters · 08 verification · 09 limitations
reports/      regression · tile_utilisation · perf.json · mutation · lint · synth
third_party/  silicaflux-tensorcore02/03/04 RTL, silicaflux-sramlib subset, datafabric dma_fifo; SHA256SUMS, PROVENANCE.md
```

## Honest caveats

* Simulation only; no formal proof, gate-level simulation, FPGA or silicon. Synthesis numbers are Yosys estimates
  with no timing analysis.
* **The single 32-bit SFB2 port is the throughput limit.** A 4×4 INT8 slice needs two operand words, so without
  reuse the array is busy at most about half the time (measured). Behind the DataFabric crossbar's
  one-transaction-per-port rule (R6), the limit is lower still.
* Operand reuse works only when the chunk count is 1, or 2 with two sets (TC03's strict set alternation). A long
  K gets none (measured).
* The TC05 quantiser and the Module 06 command queue are audited but **not integrated**. Output is raw exact INT32.
* SFB2 reads are whole words: boundary bytes next to a row are read at the bus and discarded, so the matrices
  must live in ordinary memory.
* One command at a time; fatal errors halt until reset. Everything else is in `docs/09_KNOWN_LIMITATIONS.md`.
