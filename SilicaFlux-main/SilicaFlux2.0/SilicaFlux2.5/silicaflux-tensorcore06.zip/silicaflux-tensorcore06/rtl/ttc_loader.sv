// =============================================================================
// SilicaFlux TENSORCORE 06 :: ttc_loader
// Operand loader: moves the A and B blocks of every step of a GEMM from system
// memory (SFB2 word reads) into the TENSORCORE 03 fill set (strobed writes).
//
// ADDRESS GENERATION (docs/04_ADDRESS_GENERATION.md)
//   step (m0, n0, k0), block eff_m x eff_k of A and eff_k x eff_n of B
//   A row i : source bytes [sA_i, sA_i + eff_k),  sA_i = a_base + (m0+i)*lda + k0
//   B row k : source bytes [sB_k, sB_k + eff_n),  sB_k = b_base + (k0+k)*ldb + n0
//   Local placement inside the set (what TC03 is then told):
//     A row i at a_res + i*lda_loc,  a_res = sA_0 mod 4,  lda_loc = min x >= eff_k with x == lda (mod 4)
//     B row k at b_res + k*ldb_loc,  b_res = sB_0 mod 4,  ldb_loc = min x >= eff_n with x == ldb (mod 4)
//   so every local row starts at the SAME byte offset modulo 4 as its source
//   row: source word w of a row maps to exactly one local word, byte lanes
//   unchanged, and no byte shifter is needed.  (A_PAD: if lda_loc is a
//   multiple of 4 with an even word count, 4 bytes are added so consecutive A
//   rows start in different TC03 banks; measured in reports/.)
//   Word reads: words floor(s/4) .. floor((s+len-1)/4) of each row only, so no
//   word without a byte of the row is ever read; the write strobe covers
//   exactly the row's bytes, so nothing outside the block is written.
//   Guard: every read word must lie inside [a_base, a_last] / [b_base, b_last]
//   (word granular), else the request is suppressed and guard_err raised.
//
// OWNERSHIP:  L_BEGIN fill_begin (set EMPTY -> FILL), L_A / L_B issue reads,
//   L_WAIT until every write of the step is acknowledged by TC03, L_END
//   fill_end (FILL -> READY).  The set index is TC03's fill_set pointer.
//
// REUSE (cmd flag): TC03 never clears a set.  The loader records which A
//   block (m0,k0) and B block (k0,n0) each set holds; when the set it is about
//   to fill already holds the block, that block's DMA is skipped.  Residency is
//   invalidated at every command start (memory may have changed) and by reset.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "ttc_defs.svh"
`default_nettype none

module ttc_loader #(
  parameter int TILE_M      = 4,
  parameter int TILE_N      = 4,
  parameter int NUM_SETS    = 2,
  parameter int A_SET_BYTES = 512,
  parameter int B_SET_BYTES = 512,
  parameter int A_PAD       = 1,
  localparam int SW  = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1,
  localparam int MW  = $clog2(TILE_M + 1),
  localparam int NW  = $clog2(TILE_N + 1),
  localparam int A_TOT  = NUM_SETS * A_SET_BYTES,
  localparam int B_TOT  = NUM_SETS * B_SET_BYTES,
  localparam int REGION = (A_TOT > B_TOT) ? A_TOT : B_TOT           // = TC03 tob_dma_port REGION
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  // ---------------------------------------------------------- command
  input  wire logic           gemm_init,       // pulse: new command
  input  wire logic           run,             // command executing; 0 stops new requests
  input  wire logic           permit,          // may start the next step
  input  wire logic           nmajor,
  input  wire logic           reuse,
  input  wire logic [15:0]    m, n,
  input  wire logic [16:0]    k, kc,
  input  wire logic [31:0]    a_base, b_base, lda, ldb,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [31:0]    a_last, b_last,      // word-granular guard: bits [1:0] unused
  /* verilator lint_on UNUSEDSIGNAL */
  // ---------------------------------------------------------- TC03 ownership
  output logic                fill_begin_valid,
  input  wire logic           fill_begin_ready,
  output logic                fill_end_valid,
  input  wire logic           fill_end_ready,
  input  wire logic [SW-1:0]  fill_set,
  // ---------------------------------------------------------- read requests (to ttc_sfb_master)
  output logic                rd_valid,
  output logic [31:0]         rd_addr,         // SFB2 word address (aligned)
  output logic [31:0]         rd_dst,          // TC03 fill-window byte address (aligned)
  output logic [3:0]          rd_strb,         // bytes of the word that belong to the row
  input  wire logic           rd_gnt,
  input  wire logic           fill_ack,        // TC03 acknowledged one fill write
  // ---------------------------------------------------------- set layout (read by the scheduler)
  input  wire logic [SW-1:0]  si_sel,
  output logic [1:0]          si_a_res,
  output logic [16:0]         si_lda,
  output logic [1:0]          si_b_res,
  output logic [16:0]         si_ldb,
  output logic [MW-1:0]       si_eff_m,
  output logic [NW-1:0]       si_eff_n,
  output logic [16:0]         si_eff_k,
  // ---------------------------------------------------------- status / events
  output logic [2:0]          state,
  output logic [31:0]         step_idx,
  output logic                done,
  output logic                ev_a_load, ev_b_load, ev_a_reuse, ev_b_reuse,   // pulses at fill_end
  output logic                ev_fill_bytes_v,                                // with rd_gnt: strobe popcount below
  output logic [2:0]          ev_fill_bytes,
  output logic                guard_err
);
  // ============================================================ iterator
  logic [15:0]   it_m0, it_n0, it_kidx;
  logic [16:0]   it_k0, it_eff_k;
  logic [MW-1:0] it_eff_m;
  logic [NW-1:0] it_eff_n;
  logic          it_first_k, it_last_k, it_last_step, it_done, it_adv;
  logic [31:0]   it_step;

  ttc_tile_iter #(.TILE_M(TILE_M), .TILE_N(TILE_N)) u_it (
    .clk(clk), .rst_n(rst_n), .init(gemm_init), .adv(it_adv), .nmajor(nmajor),
    .m(m), .n(n), .k(k), .kc(kc),
    .m0(it_m0), .n0(it_n0), .k0(it_k0), .kidx(it_kidx), .eff_m(it_eff_m), .eff_n(it_eff_n), .eff_k(it_eff_k),
    .first_k(it_first_k), .last_k(it_last_k), .last_step(it_last_step), .done(it_done), .step_idx(it_step));

  // ============================================================ residency and set layout tables
  logic           resA_v  [NUM_SETS];
  logic [15:0]    resA_m0 [NUM_SETS];
  logic [16:0]    resA_k0 [NUM_SETS];
  logic           resB_v  [NUM_SETS];
  logic [16:0]    resB_k0 [NUM_SETS];
  logic [15:0]    resB_n0 [NUM_SETS];
  logic [1:0]     si_ar [NUM_SETS];
  logic [16:0]    si_la [NUM_SETS];
  logic [1:0]     si_br [NUM_SETS];
  logic [16:0]    si_lb [NUM_SETS];
  logic [MW-1:0]  si_em [NUM_SETS];
  logic [NW-1:0]  si_en [NUM_SETS];
  logic [16:0]    si_ek [NUM_SETS];

  assign si_a_res = si_ar[si_sel];
  assign si_lda   = si_la[si_sel];
  assign si_b_res = si_br[si_sel];
  assign si_ldb   = si_lb[si_sel];
  assign si_eff_m = si_em[si_sel];
  assign si_eff_n = si_en[si_sel];
  assign si_eff_k = si_ek[si_sel];

  // ============================================================ PLAN (combinational from the iterator)
  /* verilator lint_off UNUSEDSIGNAL */
  logic [63:0] a_blk, b_blk;            // < 2^32 inside a validated footprint (and guarded per word)
  /* verilator lint_on UNUSEDSIGNAL */
  logic [1:0]  pa_c, pb_c;              // (ld - eff) mod 4: residue padding of the local stride
  logic [16:0] lda_loc_c, ldb_loc_c;
  logic        reuse_a_c, reuse_b_c;
  assign a_blk = 64'(a_base) + 64'(it_m0) * 64'(lda) + 64'(it_k0);
  assign b_blk = 64'(b_base) + 64'(it_k0) * 64'(ldb) + 64'(it_n0);
  always_comb begin
    pa_c      = lda[1:0] - it_eff_k[1:0];
    pb_c      = ldb[1:0] - 2'(it_eff_n);
    lda_loc_c = it_eff_k + 17'(pa_c);
    if (A_PAD != 0 && lda_loc_c[2:0] == 3'b000) lda_loc_c = lda_loc_c + 17'd4;   // even word stride -> odd
    ldb_loc_c = 17'(it_eff_n) + 17'(pb_c);
    reuse_a_c = reuse && resA_v[fill_set] && resA_m0[fill_set] == it_m0 && resA_k0[fill_set] == it_k0;
    reuse_b_c = reuse && resB_v[fill_set] && resB_k0[fill_set] == it_k0 && resB_n0[fill_set] == it_n0;
  end

  // planned step
  logic [SW-1:0]  p_set;
  logic [31:0]    p_a_src, p_b_src;
  logic [16:0]    p_lda_loc, p_ldb_loc;
  logic [MW-1:0]  p_eff_m;
  logic [NW-1:0]  p_eff_n;
  logic [16:0]    p_eff_k;
  logic           p_reuse_a, p_reuse_b;
  logic [15:0]    p_m0, p_n0;
  logic [16:0]    p_k0;

  // ============================================================ row / word engine
  logic [2:0]   st;
  logic [16:0]  r_rows, r_idx;      // rows of the phase, current row
  logic [31:0]  sp, dp;             // source byte address of the row, in-set byte offset of the row
  logic [31:0]  ld_src, ld_loc;
  logic [16:0]  len;                // bytes per row
  logic [31:0]  wbase;              // TC03 window address of the set's region
  logic [15:0]  wj;                 // word index inside the row
  logic [31:0]  issued, acked;

  logic [17:0]  span;               // sp[1:0] + len - 1
  logic [15:0]  nw_m1;              // words in the row - 1
  logic [1:0]   lo_b, hi_b;
  logic [29:0]  word, lo_w, hi_w;
  logic         guard_ok, in_issue, phase_last;

  assign span   = 18'(sp[1:0]) + 18'(len) - 18'd1;
  assign nw_m1  = 16'(span >> 2);
  assign lo_b   = (wj == 16'd0)   ? sp[1:0]   : 2'd0;
  assign hi_b   = (wj == nw_m1)   ? span[1:0] : 2'd3;
  assign word   = sp[31:2] + 30'(wj);
  assign lo_w   = (st == `TTC_L_A) ? a_base[31:2] : b_base[31:2];
  assign hi_w   = (st == `TTC_L_A) ? a_last[31:2] : b_last[31:2];
  assign guard_ok = (word >= lo_w) && (word <= hi_w);
  assign in_issue = (st == `TTC_L_A) || (st == `TTC_L_B);

  always_comb begin
    for (int b = 0; b < 4; b++) rd_strb[b] = (2'(b) >= lo_b) && (2'(b) <= hi_b);
  end
  assign rd_valid  = in_issue && run && guard_ok;
  assign rd_addr   = {word, 2'b00};
  assign rd_dst    = wbase + {dp[31:2], 2'b00} + {14'd0, wj, 2'b00};
  assign guard_err = in_issue && run && !guard_ok;
  assign ev_fill_bytes_v = rd_valid && rd_gnt;
  assign ev_fill_bytes   = 3'(rd_strb[0]) + 3'(rd_strb[1]) + 3'(rd_strb[2]) + 3'(rd_strb[3]);
  assign phase_last = (wj == nw_m1) && (r_idx == r_rows - 17'd1);

  assign fill_begin_valid = (st == `TTC_L_BEGIN);
  assign fill_end_valid   = (st == `TTC_L_END);
  assign state    = st;
  assign step_idx = it_step;
  assign done     = (st == `TTC_L_DONE);
  assign it_adv   = fill_end_valid && fill_end_ready;
  assign ev_a_load  = it_adv && !p_reuse_a;
  assign ev_b_load  = it_adv && !p_reuse_b;
  assign ev_a_reuse = it_adv &&  p_reuse_a;
  assign ev_b_reuse = it_adv &&  p_reuse_b;

  // entering the B phase: from BEGIN when A is reused, or after the last A word
  logic enter_b;
  assign enter_b = ((st == `TTC_L_BEGIN) && fill_begin_ready && p_reuse_a) ||
                   ((st == `TTC_L_A) && rd_valid && rd_gnt && phase_last);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= `TTC_L_IDLE;
      r_rows <= '0; r_idx <= '0; sp <= '0; dp <= '0; ld_src <= '0; ld_loc <= '0; len <= '0; wbase <= '0; wj <= '0;
      issued <= '0; acked <= '0;
      p_set <= '0; p_a_src <= '0; p_b_src <= '0; p_lda_loc <= '0; p_ldb_loc <= '0;
      p_eff_m <= '0; p_eff_n <= '0; p_eff_k <= '0; p_reuse_a <= 1'b0; p_reuse_b <= 1'b0;
      p_m0 <= '0; p_n0 <= '0; p_k0 <= '0;
      for (int s = 0; s < NUM_SETS; s++) begin
        resA_v[s] <= 1'b0; resA_m0[s] <= '0; resA_k0[s] <= '0;
        resB_v[s] <= 1'b0; resB_k0[s] <= '0; resB_n0[s] <= '0;
        si_ar[s] <= '0; si_la[s] <= '0; si_br[s] <= '0; si_lb[s] <= '0;
        si_em[s] <= '0; si_en[s] <= '0; si_ek[s] <= '0;
      end
    end else if (gemm_init) begin
      st <= `TTC_L_IDLE;
      issued <= '0; acked <= '0;
      for (int s = 0; s < NUM_SETS; s++) begin resA_v[s] <= 1'b0; resB_v[s] <= 1'b0; end
    end else begin
      if (fill_ack) acked <= acked + 32'd1;
      if (rd_valid && rd_gnt) issued <= issued + 32'd1;

      case (st)
        `TTC_L_IDLE: if (run && permit && !it_done) st <= `TTC_L_PLAN;
        `TTC_L_PLAN: begin
          p_set     <= fill_set;
          p_a_src   <= a_blk[31:0];
          p_b_src   <= b_blk[31:0];
          p_lda_loc <= lda_loc_c;
          p_ldb_loc <= ldb_loc_c;
          p_eff_m   <= it_eff_m;
          p_eff_n   <= it_eff_n;
          p_eff_k   <= it_eff_k;
          p_reuse_a <= reuse_a_c;
          p_reuse_b <= reuse_b_c;
          p_m0      <= it_m0;
          p_n0      <= it_n0;
          p_k0      <= it_k0;
          st        <= `TTC_L_BEGIN;
        end
        `TTC_L_BEGIN: if (fill_begin_ready) begin
          // the set is EMPTY: nobody reads it any more; publish its new layout
          si_ar[p_set] <= p_a_src[1:0];
          si_la[p_set] <= p_lda_loc;
          si_br[p_set] <= p_b_src[1:0];
          si_lb[p_set] <= p_ldb_loc;
          si_em[p_set] <= p_eff_m;
          si_en[p_set] <= p_eff_n;
          si_ek[p_set] <= p_eff_k;
          issued <= '0;
          acked  <= '0;
          if (!p_reuse_a) begin
            st     <= `TTC_L_A;
            r_rows <= 17'(p_eff_m);
            r_idx  <= '0;
            sp     <= p_a_src;
            dp     <= {30'd0, p_a_src[1:0]};
            ld_src <= lda;
            ld_loc <= 32'(p_lda_loc);
            len    <= p_eff_k;
            wbase  <= 32'(p_set) * 32'(A_SET_BYTES);
            wj     <= '0;
          end
        end
        `TTC_L_A, `TTC_L_B: if (rd_valid && rd_gnt) begin
          if (wj == nw_m1) begin
            wj <= '0;
            if (r_idx == r_rows - 17'd1) begin
              if (st == `TTC_L_B) st <= `TTC_L_WAIT;      // A -> B handled by enter_b below
            end else begin
              r_idx <= r_idx + 17'd1;
              sp    <= sp + ld_src;
              dp    <= dp + ld_loc;
            end
          end else begin
            wj <= wj + 16'd1;
          end
        end
        `TTC_L_WAIT: if (issued == acked) st <= `TTC_L_END;
        `TTC_L_END: if (fill_end_ready) begin
          if (!p_reuse_a) begin resA_v[p_set] <= 1'b1; resA_m0[p_set] <= p_m0; resA_k0[p_set] <= p_k0; end
          if (!p_reuse_b) begin resB_v[p_set] <= 1'b1; resB_k0[p_set] <= p_k0; resB_n0[p_set] <= p_n0; end
          st <= it_last_step ? `TTC_L_DONE : `TTC_L_IDLE;
        end
        default: ;                                          // L_DONE: until the next gemm_init
      endcase
      if (enter_b) begin
        if (!p_reuse_b) begin
          st     <= `TTC_L_B;
          r_rows <= p_eff_k;
          r_idx  <= '0;
          sp     <= p_b_src;
          dp     <= {30'd0, p_b_src[1:0]};
          ld_src <= ldb;
          ld_loc <= 32'(p_ldb_loc);
          len    <= 17'(p_eff_n);
          wbase  <= 32'(REGION) + 32'(p_set) * 32'(B_SET_BYTES);
          wj     <= '0;
        end else begin
          st <= `TTC_L_WAIT;
        end
      end
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_ok;
  assign unused_ok = it_first_k ^ it_last_k ^ (|it_kidx);
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
