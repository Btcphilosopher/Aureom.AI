// =============================================================================
// SilicaFlux TENSORCORE 06  --  tensor_tile_controller.sv       (PRIMARY SOURCE)
// Matrix tiling, address generation and tensor scheduling
// Aureom.AI | SilicaFlux-HPC
//
//   C[M,N] = A[M,K] x B[K,N]     dense, row-major, explicit leading dimensions,
//                                signed INT8 operands, INT32 accumulation/output,
//                                1 <= M, N <= 65535, 1 <= K <= 131071
//
// Turns one GEMM command into the ordered memory, compute, accumulation and
// output operations of three existing, unmodified subsystems:
//   TENSORCORE 02  tensor_systolic_array   one TILE_M x TILE_N output tile, one K chunk per launch
//   TENSORCORE 03  tensor_operand_buffer   A/B operand sets (single or ping-pong), k-slice delivery
//   TENSORCORE 04  tensor_acc_subsystem    K-chunk accumulation, commit, output rows
// plus its own SFB2 master port to system memory (DataFabric PROTOCOL.md).
//
// ---------------------------------------------------------------------------
// TILING (ttc_tile_iter): output tiles TILE_M x TILE_N, K chunks of kc <= TILE_K.
//   K innermost; tiles M-major (default) or N-major (cmd flag).  Boundary tiles
//   use eff_m = min(TILE_M, M-m0), eff_n, eff_k: the array masks the rest.
//
// SCHEDULER FSM (this file; docs/06_SCHEDULER_FSM.md), per step (m0, n0, k0):
//   RESERVE    first chunk of a tile: open a TC04 accumulator slot (k_total = K,
//              n_chunks = ceil(K/kc)); push the tile's C address into the store
//              path; waits for a FREE slot.
//   INIT       TC04 initialises the partial sums with the first chunk itself
//              (no clear pass); INIT confirms the slot configuration was not rejected.
//   LOAD       operands: wait until the loader has filled a TC03 set (cmp_begin).
//   TILE       describe the loaded block to TC03; take the tile response.
//   ACCUMULATE wait until the previous launch has finished on the array (its
//              readout's last beat accepted by TC04) and TC04 reports the chunk
//              merged (ev_inc[PF_CHUNKS]).  Real completion, no latency constant.
//   LAUNCH     launch the array with the tile response geometry.
//   COMPUTE    slices stream TC03 -> array; after the last slice, cmp_end
//              releases the set (the loader may refill it).
//   STORE      wait until every reserved tile has all C elements written and
//              acknowledged by the memory (SFB2 write responses).
//   COMPLETE   one completion record.   ERROR -> HALT on a fatal error.
// Serial mode (flags.OVERLAP = 0): LOAD is the only time the loader may load,
//   ACCUMULATE follows COMPUTE directly, STORE follows the last chunk of every
//   tile: the brief's 12-step sequence, one operation at a time.
// Overlap mode (flags.OVERLAP = 1): the loader prefetches the next step into
//   the other set while this step computes; ACCUMULATE is deferred to just
//   before the next LAUNCH (TC03 tile set-up overlaps the array drain/readout);
//   the store of tile t overlaps the computation of tile t+1.
//
// COMPLETION SIGNALS USED: SFB2 responses, TC03 fill responses, fill/cmp
//   ownership handshakes, tile responses, slice handshakes, the array's readout
//   m_last handshake, TC04 PF_CHUNKS events and committed beats.
// ERRORS: validation errors complete without any side effect; bus errors
//   complete after a full drain; a subsystem refusing what the controller
//   generated, or the watchdog, is fatal (completion record, then HALT).
// Reset: asynchronous assert, active low (as TENSORCORE 03 / SFB2 R11).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "ttc_defs.svh"
`default_nettype none

module tensor_tile_controller #(
  parameter int          TILE_M      = 4,                  // = array rows
  parameter int          TILE_N      = 4,                  // = array columns
  parameter int          TILE_K      = 64,                 // maximum K chunk
  parameter int          NUM_SETS    = 2,                  // = TC03 NUM_SETS
  parameter int          A_SET_BYTES = 512,                // = TC03 A_SET_BYTES
  parameter int          B_SET_BYTES = 512,                // = TC03 B_SET_BYTES
  parameter int          A_PAD       = 1,                  // odd A word stride in the buffer
  parameter int          NUM_SLOTS   = 2,                  // = TC04 NUM_TILES
  parameter int          MAX_OUT     = 8,                  // SFB2 requests outstanding
  parameter int          FILL_DEPTH  = 8,                  // read responses buffered for TC03
  parameter int          TI_DEPTH    = 8,                  // tiles reserved but not yet stored
  parameter logic [32:0] MEM_LO      = 33'h0_0000_0000,    // memory window for A, B, C
  parameter logic [32:0] MEM_HI      = 33'h1_0000_0000,
  parameter int          WDOG_LOG2   = 16,
  parameter int          CNT_W       = 40,
  parameter int          TOB_TAG_W   = 8,
  localparam int SW     = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1,
  localparam int MW     = $clog2(TILE_M + 1),
  localparam int NW     = $clog2(TILE_N + 1),
  localparam int RIDW   = (TILE_M > 1) ? $clog2(TILE_M) : 1,
  localparam int SLOT_W = (NUM_SLOTS > 1) ? $clog2(NUM_SLOTS) : 1
) (
  input  wire logic                      clk,
  input  wire logic                      rst_n,
  // ---------------------------------------------------------- GEMM command
  input  wire logic                      cmd_valid,
  output logic                           cmd_ready,
  input  wire logic [7:0]                cmd_tag,
  input  wire logic [7:0]                cmd_flags,
  input  wire logic [1:0]                cmd_a_layout, cmd_b_layout, cmd_c_layout,
  input  wire logic [1:0]                cmd_a_type, cmd_b_type, cmd_c_type,
  input  wire logic [31:0]               cmd_m, cmd_n, cmd_k,
  input  wire logic [31:0]               cmd_kc,            // K chunk; 0 = TILE_K
  input  wire logic [31:0]               cmd_a_base, cmd_b_base, cmd_c_base,
  input  wire logic [31:0]               cmd_lda, cmd_ldb, cmd_ldc,   // bytes
  // ---------------------------------------------------------- completion record
  output logic                           cpl_valid,
  input  wire logic                      cpl_ready,
  output logic [7:0]                     cpl_tag,
  output logic                           cpl_err,
  output logic [4:0]                     cpl_code,
  output logic [31:0]                    cpl_err_addr,
  output logic [31:0]                    cpl_cycles,
  output logic [31:0]                    cpl_tiles,
  output logic [31:0]                    cpl_chunks,
  // ---------------------------------------------------------- SFB2 master port
  output logic                           req_valid,
  input  wire logic                      req_ready,
  output logic                           req_write,
  output logic [31:0]                    req_addr,
  output logic [31:0]                    req_wdata,
  output logic [3:0]                     req_wstrb,
  input  wire logic                      rsp_valid,
  output logic                           rsp_ready,
  input  wire logic [31:0]               rsp_rdata,
  input  wire logic                      rsp_error,
  // ---------------------------------------------------------- TENSORCORE 03: fill port
  output logic                           tob_dma_req_valid,
  input  wire logic                      tob_dma_req_ready,
  output logic                           tob_dma_req_we,
  output logic [31:0]                    tob_dma_req_addr,
  output logic [31:0]                    tob_dma_req_wdata,
  output logic [3:0]                     tob_dma_req_wstrb,
  output logic [TOB_TAG_W-1:0]           tob_dma_req_tag,
  input  wire logic                      tob_dma_rsp_valid,
  output logic                           tob_dma_rsp_ready,
  input  wire logic                      tob_dma_rsp_err,
  // ---------------------------------------------------------- TENSORCORE 03: ownership
  output logic                           tob_fill_begin_valid,
  input  wire logic                      tob_fill_begin_ready,
  output logic                           tob_fill_end_valid,
  input  wire logic                      tob_fill_end_ready,
  output logic                           tob_cmp_begin_valid,
  input  wire logic                      tob_cmp_begin_ready,
  output logic                           tob_cmp_end_valid,
  input  wire logic                      tob_cmp_end_ready,
  input  wire logic [SW-1:0]             tob_fill_set,
  input  wire logic [SW-1:0]             tob_cmp_set,
  // ---------------------------------------------------------- TENSORCORE 03: tiles and slice taps
  output logic                           tob_tile_valid,
  input  wire logic                      tob_tile_ready,
  output logic [31:0]                    tob_tile_a_addr, tob_tile_lda, tob_tile_b_addr, tob_tile_ldb,
  output logic [15:0]                    tob_tile_m0, tob_tile_n0, tob_tile_mat_m, tob_tile_mat_n,
  output logic [16:0]                    tob_tile_k0, tob_tile_mat_k, tob_tile_k,
  output logic [TOB_TAG_W-1:0]           tob_tile_tag,
  input  wire logic                      tob_tile_rsp_valid,
  output logic                           tob_tile_rsp_ready,
  input  wire logic                      tob_tile_rsp_err,
  input  wire logic [MW-1:0]             tob_tile_rsp_m,
  input  wire logic [NW-1:0]             tob_tile_rsp_n,
  input  wire logic [16:0]               tob_tile_rsp_k,
  input  wire logic                      tob_s_valid,       // taps of the TC03 -> TC02 slice stream
  input  wire logic                      tob_s_ready,
  input  wire logic                      tob_s_last,
  input  wire logic [16:0]               tob_s_k,
  input  wire logic [7:0]                tob_ev_starve,     // TC03 ev_inc[EV_STARVE]
  input  wire logic [7:0]                tob_ev_overlap,    // TC03 ev_inc[EV_OVERLAP]
  // ---------------------------------------------------------- TENSORCORE 02
  output logic                           arr_cfg_valid,
  input  wire logic                      arr_cfg_ready,
  output logic [MW-1:0]                  arr_cfg_m,
  output logic [NW-1:0]                  arr_cfg_n,
  output logic [16:0]                    arr_cfg_k,
  input  wire logic                      arr_cfg_reject,
  input  wire logic [16:0]               arr_s_k,           // index the array expects next
  input  wire logic                      arr_busy,
  input  wire logic                      arr_tile_done,
  input  wire logic                      arr_align_err,
  input  wire logic                      arr_m_valid,       // taps of the array readout
  input  wire logic                      arr_m_ready,
  input  wire logic                      arr_m_last,
  input  wire logic [39:0]               arr_perf_mac,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [39:0]               arr_perf_pad,      // per launch <= R*C*TILE_K: low 32 bits used
  /* verilator lint_on UNUSEDSIGNAL */
  // ---------------------------------------------------------- TENSORCORE 04
  output logic                           acc_cfg_valid,
  input  wire logic                      acc_cfg_ready,
  output logic [SLOT_W-1:0]              acc_cfg_slot,
  output logic [15:0]                    acc_cfg_tag,
  output logic [MW-1:0]                  acc_cfg_m,
  output logic [NW-1:0]                  acc_cfg_n,
  output logic [39:0]                    acc_cfg_k_total,
  output logic [15:0]                    acc_cfg_n_chunks,
  input  wire logic                      acc_cfg_reject,
  output logic [SLOT_W-1:0]              acc_ps_slot,       // sideband of the launch being read out
  output logic [15:0]                    acc_ps_tag,
  output logic [15:0]                    acc_ps_chunk,
  output logic [16:0]                    acc_ps_chunk_k,
  input  wire logic                      acc_err_pulse,
  input  wire logic                      acc_ev_chunk,      // TC04 ev_inc[PF_CHUNKS] != 0
  input  wire logic                      acc_o_valid,       // TC04 odma port
  output logic                           acc_o_ready,
  input  wire logic [RIDW-1:0]           acc_o_row,
  input  wire logic [TILE_N-1:0]         acc_o_col_mask,
  input  wire logic [TILE_N*32-1:0]      acc_o_data,
  input  wire logic                      acc_o_last,
  input  wire logic [15:0]               acc_o_tag,
  input  wire logic [TILE_N-1:0]         acc_o_ovf,
  input  wire logic                      acc_o_err,
  // ---------------------------------------------------------- status / performance
  output logic                           busy,
  output logic                           halted,
  output logic [3:0]                     state,
  output logic [2:0]                     ld_state,
  input  wire logic                      perf_clear,
  output logic [`TTC_NUM_PC*CNT_W-1:0]   perf_cnt
);
  // ============================================================ elaboration checks
  localparam int LDA_LOC_MAX = TILE_K + 3 + ((A_PAD != 0) ? 4 : 0);
  localparam int A_EXTENT = 3 + (TILE_M - 1) * LDA_LOC_MAX + TILE_K;     // last A byte + 1 (worst case)
  localparam int B_EXTENT = 3 + (TILE_K - 1) * (TILE_N + 3) + TILE_N;   // last B byte + 1 (worst case)
  // synthesis translate_off
  initial begin
    if (TILE_M < 1 || TILE_N < 1)             $fatal(1, "tensor_tile_controller: TILE_M, TILE_N must be >= 1");
    if (TILE_K < 1 || TILE_K > 131071)        $fatal(1, "tensor_tile_controller: TILE_K must be 1..131071 (TC02 K_WIDTH = 17)");
    if (NUM_SETS != 1 && NUM_SETS != 2)       $fatal(1, "tensor_tile_controller: NUM_SETS must be 1 or 2");
    if (A_EXTENT > A_SET_BYTES)               $fatal(1, "tensor_tile_controller: worst-case A block (%0d B) exceeds A_SET_BYTES", A_EXTENT);
    if (B_EXTENT > B_SET_BYTES)               $fatal(1, "tensor_tile_controller: worst-case B block (%0d B) exceeds B_SET_BYTES", B_EXTENT);
    if (NUM_SLOTS < 1)                        $fatal(1, "tensor_tile_controller: NUM_SLOTS must be >= 1");
    if ((1 << $clog2(MAX_OUT)) != MAX_OUT || MAX_OUT < 2)       $fatal(1, "tensor_tile_controller: MAX_OUT must be a power of two >= 2");
    if ((1 << $clog2(FILL_DEPTH)) != FILL_DEPTH || FILL_DEPTH < 2) $fatal(1, "tensor_tile_controller: FILL_DEPTH must be a power of two >= 2");
    if ((1 << $clog2(TI_DEPTH)) != TI_DEPTH || TI_DEPTH < 2)    $fatal(1, "tensor_tile_controller: TI_DEPTH must be a power of two >= 2");
    if (WDOG_LOG2 < 4 || WDOG_LOG2 > 31)      $fatal(1, "tensor_tile_controller: WDOG_LOG2 must be 4..31");
    if (CNT_W < 32 || CNT_W > 63)             $fatal(1, "tensor_tile_controller: CNT_W must be 32..63");
  end
  // synthesis translate_on

  // ============================================================ command registers
  logic [3:0]  st;
  logic [7:0]  c_tag, c_flags;
  logic [1:0]  c_al, c_bl, c_cl, c_at, c_bt, c_ct;
  logic [31:0] c_m, c_n, c_k, c_kc_raw;
  logic [31:0] c_a, c_b, c_c, c_lda, c_ldb, c_ldc;
  logic [16:0] c_kc;
  logic [15:0] c_nch;
  logic [31:0] c_alast, c_blast, c_clast;
  logic        ovl, reuse, nmajor;

  assign ovl    = c_flags[`TTC_FL_OVERLAP];
  assign reuse  = c_flags[`TTC_FL_REUSE];
  assign nmajor = c_flags[`TTC_FL_NMAJOR];

  logic cmd_hs;
  assign cmd_ready = (st == `TTC_S_IDLE);
  assign cmd_hs    = cmd_valid && cmd_ready;

  // ============================================================ validation
  logic        v_done;
  logic [4:0]  v_code;
  logic [16:0] v_kc;
  logic [15:0] v_nch;
  logic [31:0] v_alast, v_blast, v_clast;
  ttc_validate #(.TILE_K(TILE_K), .MEM_LO(MEM_LO), .MEM_HI(MEM_HI)) u_val (
    .clk(clk), .rst_n(rst_n), .start(cmd_hs),
    .flags(c_flags), .a_layout(c_al), .b_layout(c_bl), .c_layout(c_cl), .a_type(c_at), .b_type(c_bt), .c_type(c_ct),
    .m(c_m), .n(c_n), .k(c_k), .kc(c_kc_raw), .a_base(c_a), .b_base(c_b), .c_base(c_c),
    .lda(c_lda), .ldb(c_ldb), .ldc(c_ldc),
    .done(v_done), .code(v_code), .kc_eff(v_kc), .n_chunks(v_nch), .a_last(v_alast), .b_last(v_blast), .c_last(v_clast));

  logic gemm_init;
  assign gemm_init = (st == `TTC_S_VALIDATE) && v_done && (v_code == `TTC_OK);

  // ============================================================ scheduler-side iterator
  logic [15:0]   ex_m0, ex_n0, ex_kidx;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [16:0]   ex_k0;                          // observability only (waveforms)
  logic          ex_done;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [16:0]   ex_eff_k;
  logic [MW-1:0] ex_eff_m;
  logic [NW-1:0] ex_eff_n;
  logic          ex_first_k, ex_last_k, ex_last_step, ex_adv;
  logic [31:0]   ex_step;
  ttc_tile_iter #(.TILE_M(TILE_M), .TILE_N(TILE_N)) u_ex_it (
    .clk(clk), .rst_n(rst_n), .init(gemm_init), .adv(ex_adv), .nmajor(nmajor),
    .m(c_m[15:0]), .n(c_n[15:0]), .k(c_k[16:0]), .kc(c_kc),
    .m0(ex_m0), .n0(ex_n0), .k0(ex_k0), .kidx(ex_kidx), .eff_m(ex_eff_m), .eff_n(ex_eff_n), .eff_k(ex_eff_k),
    .first_k(ex_first_k), .last_k(ex_last_k), .last_step(ex_last_step), .done(ex_done), .step_idx(ex_step));

  // ============================================================ loader
  logic          ld_run, ld_permit, ld_done;
  logic [31:0]   ld_step;
  logic          ld_rd_valid, ld_rd_gnt, ld_guard_err;
  logic [31:0]   ld_rd_addr, ld_rd_dst;
  logic [3:0]    ld_rd_strb;
  logic          ev_a_load, ev_b_load, ev_a_reuse, ev_b_reuse, ev_fb_v;
  logic [2:0]    ev_fb;
  logic [SW-1:0] cur_set;
  logic [1:0]    si_a_res, si_b_res;
  logic [16:0]   si_lda, si_ldb, si_eff_k;
  logic [MW-1:0] si_eff_m;
  logic [NW-1:0] si_eff_n;
  logic          fill_ack;

  assign ld_run    = (st >= `TTC_S_RESERVE) && (st <= `TTC_S_STORE);
  assign ld_permit = ovl || ((st == `TTC_S_LOAD) && (ld_step == ex_step));
  assign fill_ack  = tob_dma_rsp_valid;          // tob_dma_rsp_ready = 1
  assign tob_dma_rsp_ready = 1'b1;

  ttc_loader #(.TILE_M(TILE_M), .TILE_N(TILE_N), .NUM_SETS(NUM_SETS), .A_SET_BYTES(A_SET_BYTES),
               .B_SET_BYTES(B_SET_BYTES), .A_PAD(A_PAD)) u_ld (
    .clk(clk), .rst_n(rst_n), .gemm_init(gemm_init), .run(ld_run), .permit(ld_permit),
    .nmajor(nmajor), .reuse(reuse), .m(c_m[15:0]), .n(c_n[15:0]), .k(c_k[16:0]), .kc(c_kc),
    .a_base(c_a), .b_base(c_b), .lda(c_lda), .ldb(c_ldb), .a_last(c_alast), .b_last(c_blast),
    .fill_begin_valid(tob_fill_begin_valid), .fill_begin_ready(tob_fill_begin_ready),
    .fill_end_valid(tob_fill_end_valid), .fill_end_ready(tob_fill_end_ready), .fill_set(tob_fill_set),
    .rd_valid(ld_rd_valid), .rd_addr(ld_rd_addr), .rd_dst(ld_rd_dst), .rd_strb(ld_rd_strb), .rd_gnt(ld_rd_gnt),
    .fill_ack(fill_ack),
    .si_sel(cur_set), .si_a_res(si_a_res), .si_lda(si_lda), .si_b_res(si_b_res), .si_ldb(si_ldb),
    .si_eff_m(si_eff_m), .si_eff_n(si_eff_n), .si_eff_k(si_eff_k),
    .state(ld_state), .step_idx(ld_step), .done(ld_done),
    .ev_a_load(ev_a_load), .ev_b_load(ev_b_load), .ev_a_reuse(ev_a_reuse), .ev_b_reuse(ev_b_reuse),
    .ev_fill_bytes_v(ev_fb_v), .ev_fill_bytes(ev_fb), .guard_err(ld_guard_err));

  // ============================================================ store path
  logic        ti_push, ti_full, ti_empty;
  logic [31:0] ti_ctile;
  logic        st_wr_valid, st_wr_gnt, st_wr_tlast;
  logic [31:0] st_wr_addr, st_wr_data;
  logic        ev_out_stall, ev_ovf, ev_beat_err, st_tag_err, st_guard_err;
  logic [15:0] tile_seq;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [63:0] ctile64;                          // < 2^32 for every tile of a validated command
  /* verilator lint_on UNUSEDSIGNAL */

  assign ctile64  = 64'(c_c) + 64'(ex_m0) * 64'(c_ldc) + 64'({ex_n0, 2'b00});
  assign ti_ctile = ctile64[31:0];

  ttc_store #(.TILE_M(TILE_M), .TILE_N(TILE_N), .TI_DEPTH(TI_DEPTH)) u_st (
    .clk(clk), .rst_n(rst_n), .ldc(c_ldc), .c_base(c_c), .c_last(c_clast),
    .ti_push(ti_push), .ti_ctile(ti_ctile), .ti_tag(tile_seq), .ti_full(ti_full), .ti_empty(ti_empty),
    .o_valid(acc_o_valid), .o_ready(acc_o_ready), .o_row(acc_o_row), .o_col_mask(acc_o_col_mask),
    .o_data(acc_o_data), .o_last(acc_o_last), .o_tag(acc_o_tag), .o_ovf(acc_o_ovf), .o_err(acc_o_err),
    .wr_valid(st_wr_valid), .wr_addr(st_wr_addr), .wr_data(st_wr_data), .wr_tlast(st_wr_tlast), .wr_gnt(st_wr_gnt),
    .ev_stall(ev_out_stall), .ev_ovf(ev_ovf), .ev_beat_err(ev_beat_err), .tag_err(st_tag_err), .guard_err(st_guard_err));

  // ============================================================ SFB2 master + TC03 fill driver
  logic        wr_ack, wr_ack_tlast, wr_ack_err, rd_rsp_err, bus_idle, ev_bus_stall, ev_fill_write;
  logic [31:0] rsp_addr;
  ttc_sfb_master #(.MAX_OUT(MAX_OUT), .FILL_DEPTH(FILL_DEPTH), .TOB_TAG_W(TOB_TAG_W)) u_bus (
    .clk(clk), .rst_n(rst_n),
    .rd_valid(ld_rd_valid), .rd_addr(ld_rd_addr), .rd_dst(ld_rd_dst), .rd_strb(ld_rd_strb), .rd_gnt(ld_rd_gnt),
    .wr_valid(st_wr_valid), .wr_addr(st_wr_addr), .wr_data(st_wr_data), .wr_tlast(st_wr_tlast), .wr_gnt(st_wr_gnt),
    .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write), .req_addr(req_addr),
    .req_wdata(req_wdata), .req_wstrb(req_wstrb),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error),
    .tob_req_valid(tob_dma_req_valid), .tob_req_ready(tob_dma_req_ready), .tob_req_we(tob_dma_req_we),
    .tob_req_addr(tob_dma_req_addr), .tob_req_wdata(tob_dma_req_wdata), .tob_req_wstrb(tob_dma_req_wstrb),
    .tob_req_tag(tob_dma_req_tag),
    .wr_ack(wr_ack), .wr_ack_tlast(wr_ack_tlast), .wr_ack_err(wr_ack_err), .rd_rsp_err(rd_rsp_err),
    .rsp_addr(rsp_addr), .idle(bus_idle), .ev_bus_stall(ev_bus_stall), .ev_fill_write(ev_fill_write));

  // ============================================================ scheduler state
  logic [SLOT_W-1:0] slot_ptr, cur_slot;
  logic [15:0]       cur_tag;
  logic [SW-1:0]     prev_set;
  logic              have_prev_set, tile_sent, tile_armed, launch_pend, slices_done;
  logic [MW-1:0]     l_m;
  logic [NW-1:0]     l_n;
  logic [16:0]       l_k;
  logic [39:0]       exp_mac;
  logic [31:0]       tiles_res, tiles_done, launched, merged, gemm_cyc;
  logic [4:0]        err_code;
  logic [31:0]       err_addr;

  // handshakes
  logic acc_cfg_hs, cmp_begin_hs, cmp_end_hs, tile_hs, tile_rsp_hs, arr_cfg_hs, slice_hs, rd_beat_hs, rd_last_hs;
  assign acc_cfg_hs   = acc_cfg_valid && acc_cfg_ready;
  assign cmp_begin_hs = tob_cmp_begin_valid && tob_cmp_begin_ready;
  assign cmp_end_hs   = tob_cmp_end_valid && tob_cmp_end_ready;
  assign tile_hs      = tob_tile_valid && tob_tile_ready;
  assign tile_rsp_hs  = tob_tile_rsp_valid && tob_tile_rsp_ready;
  assign arr_cfg_hs   = arr_cfg_valid && arr_cfg_ready;
  assign slice_hs     = tob_s_valid && tob_s_ready;
  assign rd_beat_hs   = arr_m_valid && arr_m_ready;
  assign rd_last_hs   = rd_beat_hs && arr_m_last;

  // ---------------------------------------------------------- subsystem commands (Moore outputs of the FSM)
  assign acc_cfg_valid    = (st == `TTC_S_RESERVE) && !ti_full;
  assign acc_cfg_slot     = slot_ptr;
  assign acc_cfg_tag      = tile_seq;
  assign acc_cfg_m        = ex_eff_m;
  assign acc_cfg_n        = ex_eff_n;
  assign acc_cfg_k_total  = 40'(c_k[16:0]);
  assign acc_cfg_n_chunks = c_nch;
  assign ti_push          = acc_cfg_hs;

  assign tob_cmp_begin_valid = (st == `TTC_S_LOAD);
  assign tob_tile_valid      = (st == `TTC_S_TILE) && !tile_sent;
  assign tob_tile_a_addr     = {30'd0, si_a_res};
  assign tob_tile_lda        = 32'(si_lda);
  assign tob_tile_b_addr     = {30'd0, si_b_res};
  assign tob_tile_ldb        = 32'(si_ldb);
  assign tob_tile_m0         = '0;
  assign tob_tile_n0         = '0;
  assign tob_tile_k0         = '0;
  assign tob_tile_mat_m      = 16'(si_eff_m);
  assign tob_tile_mat_n      = 16'(si_eff_n);
  assign tob_tile_mat_k      = si_eff_k;
  assign tob_tile_k          = si_eff_k;
  assign tob_tile_tag        = TOB_TAG_W'(ex_step);
  assign tob_tile_rsp_ready  = (st == `TTC_S_TILE);

  assign arr_cfg_valid = (st == `TTC_S_LAUNCH);
  assign arr_cfg_m     = l_m;
  assign arr_cfg_n     = l_n;
  assign arr_cfg_k     = l_k;

  assign tob_cmp_end_valid = (st == `TTC_S_COMPUTE) && slices_done;

  // ---------------------------------------------------------- completion conditions
  logic store_done_c, final_ok_c;
  assign store_done_c = (tiles_done == tiles_res);
  assign final_ok_c   = store_done_c && ld_done && bus_idle && !launch_pend && ti_empty;

  // ACCUMULATE exit: the previous launch is read out AND merged by TC04
  logic retire_ok;
  assign retire_ok = !launch_pend && (merged == launched);

  // ---------------------------------------------------------- fatal error detection
  logic       running, fatal;
  logic [7:0] fatal_sub;
  assign running = (st >= `TTC_S_VALIDATE) && (st <= `TTC_S_STORE);
  always_comb begin
    fatal_sub = 8'd0;
    if      (tob_dma_rsp_valid && tob_dma_rsp_err)                 fatal_sub = `TTC_IE_FILL_RSP;
    else if (tile_rsp_hs && tob_tile_rsp_err)                      fatal_sub = `TTC_IE_TILE_RSP;
    else if (tile_rsp_hs && (tob_tile_rsp_m != ex_eff_m || tob_tile_rsp_n != ex_eff_n ||
                             tob_tile_rsp_k != ex_eff_k))          fatal_sub = `TTC_IE_GEOM;
    else if (arr_cfg_reject)                                       fatal_sub = `TTC_IE_ARR_REJECT;
    else if (arr_align_err)                                        fatal_sub = `TTC_IE_ARR_ALIGN;
    else if ((st == `TTC_S_INIT) && acc_cfg_reject)                fatal_sub = `TTC_IE_ACC_REJECT;
    else if (acc_err_pulse || ev_beat_err)                         fatal_sub = `TTC_IE_ACC_BEAT;
    else if (slice_hs && (tob_s_k != arr_s_k))                     fatal_sub = `TTC_IE_SLICE_K;
    else if (ld_guard_err)                                         fatal_sub = `TTC_IE_GUARD_RD;
    else if (st_guard_err)                                         fatal_sub = `TTC_IE_GUARD_WR;
    else if (st_tag_err)                                           fatal_sub = `TTC_IE_OUT_TAG;
    else if (rd_last_hs && (arr_perf_mac != exp_mac))              fatal_sub = `TTC_IE_MAC;
    else if ((st == `TTC_S_STORE) && ex_last_step && store_done_c && (merged != launched))
                                                                   fatal_sub = `TTC_IE_MERGE;
  end

  // ---------------------------------------------------------- watchdog
  logic [WDOG_LOG2-1:0] wd;
  logic                 progress, wd_fire;
  assign progress = cmd_hs || v_done || (req_valid && req_ready) || rsp_valid || ev_fill_write || fill_ack ||
                    (tob_fill_begin_valid && tob_fill_begin_ready) || (tob_fill_end_valid && tob_fill_end_ready) ||
                    cmp_begin_hs || cmp_end_hs || tile_hs || tile_rsp_hs || slice_hs || arr_cfg_hs ||
                    rd_beat_hs || acc_cfg_hs || (acc_o_valid && acc_o_ready);
  assign wd_fire  = running && (wd == {WDOG_LOG2{1'b1}});
  assign fatal    = running && ((fatal_sub != 8'd0) || wd_fire);

  // iterator advance (one place per transition, see FSM)
  always_comb begin
    ex_adv = 1'b0;
    case (st)
      `TTC_S_COMPUTE:    ex_adv = cmp_end_hs && ovl && !ex_last_step;
      `TTC_S_ACCUMULATE: ex_adv = retire_ok && !tile_armed && !ex_last_step && !(ex_last_k);
      `TTC_S_STORE:      ex_adv = store_done_c && !ex_last_step;
      default:           ex_adv = 1'b0;
    endcase
    if (fatal) ex_adv = 1'b0;
  end

  // ============================================================ the FSM
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= `TTC_S_IDLE;
      c_tag <= '0; c_flags <= '0; c_al <= '0; c_bl <= '0; c_cl <= '0; c_at <= '0; c_bt <= '0; c_ct <= '0;
      c_m <= '0; c_n <= '0; c_k <= '0; c_kc_raw <= '0; c_a <= '0; c_b <= '0; c_c <= '0;
      c_lda <= '0; c_ldb <= '0; c_ldc <= '0; c_kc <= '0; c_nch <= '0; c_alast <= '0; c_blast <= '0; c_clast <= '0;
      slot_ptr <= '0; cur_slot <= '0; cur_tag <= '0; cur_set <= '0; prev_set <= '0; have_prev_set <= 1'b0;
      tile_sent <= 1'b0; tile_armed <= 1'b0; launch_pend <= 1'b0; slices_done <= 1'b0;
      l_m <= '0; l_n <= '0; l_k <= '0; exp_mac <= '0;
      acc_ps_slot <= '0; acc_ps_tag <= '0; acc_ps_chunk <= '0; acc_ps_chunk_k <= '0;
      tiles_res <= '0; tiles_done <= '0; launched <= '0; merged <= '0; gemm_cyc <= '0; tile_seq <= '0;
      err_code <= `TTC_OK; err_addr <= '0; wd <= '0;
    end else begin
      // ------------------------------------------------ bookkeeping that runs in every state
      if (running) gemm_cyc <= gemm_cyc + 32'd1;
      wd <= (progress || !running) ? '0 : wd + WDOG_LOG2'(1);
      if (rd_last_hs)                 launch_pend <= 1'b0;
      if (acc_ev_chunk)               merged      <= merged + 32'd1;
      if (wr_ack && wr_ack_tlast)     tiles_done  <= tiles_done + 32'd1;
      if (slice_hs && tob_s_last)     slices_done <= 1'b1;
      // execution errors: first one wins, the command keeps draining
      if (running && err_code == `TTC_OK) begin
        if (rd_rsp_err)                begin err_code <= `TTC_ERR_BUS_READ;  err_addr <= rsp_addr; end
        else if (wr_ack && wr_ack_err) begin err_code <= `TTC_ERR_BUS_WRITE; err_addr <= rsp_addr; end
        else if (ev_ovf)               begin err_code <= `TTC_ERR_ACC_OVF;   err_addr <= '0;       end
      end

      // ------------------------------------------------ transitions
      if (fatal) begin
        st       <= `TTC_S_ERROR;
        err_code <= wd_fire && fatal_sub == 8'd0 ? `TTC_ERR_WATCHDOG : `TTC_ERR_INTERNAL;
        err_addr <= {24'd0, fatal_sub};
      end else begin
        case (st)
          `TTC_S_IDLE: if (cmd_hs) begin
            c_tag <= cmd_tag; c_flags <= cmd_flags;
            c_al <= cmd_a_layout; c_bl <= cmd_b_layout; c_cl <= cmd_c_layout;
            c_at <= cmd_a_type; c_bt <= cmd_b_type; c_ct <= cmd_c_type;
            c_m <= cmd_m; c_n <= cmd_n; c_k <= cmd_k; c_kc_raw <= cmd_kc;
            c_a <= cmd_a_base; c_b <= cmd_b_base; c_c <= cmd_c_base;
            c_lda <= cmd_lda; c_ldb <= cmd_ldb; c_ldc <= cmd_ldc;
            err_code <= `TTC_OK; err_addr <= '0; gemm_cyc <= 32'd1;
            tiles_res <= '0; tiles_done <= '0; launched <= '0; merged <= '0;
            st <= `TTC_S_VALIDATE;
          end

          `TTC_S_VALIDATE: if (v_done) begin
            if (v_code != `TTC_OK) begin
              err_code <= v_code;                     // no side effect: nothing was started
              st <= `TTC_S_COMPLETE;
            end else begin
              c_kc <= v_kc; c_nch <= v_nch;
              c_alast <= v_alast; c_blast <= v_blast; c_clast <= v_clast;
              have_prev_set <= 1'b0; tile_armed <= 1'b0; launch_pend <= 1'b0;
              st <= `TTC_S_RESERVE;                   // step 0 is always the first chunk of a tile
            end
          end

          // 1. reserve accumulator storage
          `TTC_S_RESERVE: if (acc_cfg_hs) begin
            cur_slot  <= slot_ptr;
            cur_tag   <= tile_seq;
            slot_ptr  <= (32'(slot_ptr) == NUM_SLOTS - 1) ? '0 : slot_ptr + SLOT_W'(1);
            tile_seq  <= tile_seq + 16'd1;
            tiles_res <= tiles_res + 32'd1;
            st        <= `TTC_S_INIT;
          end

          // 2. initialise partial sums (TC04: first chunk initialises; confirm not rejected)
          `TTC_S_INIT: st <= `TTC_S_LOAD;

          // 3-5. load A, load B (loader), wait for the operands
          `TTC_S_LOAD: if (cmp_begin_hs) begin
            cur_set       <= tob_cmp_set;
            prev_set      <= tob_cmp_set;
            have_prev_set <= 1'b1;
            tile_sent     <= 1'b0;
            st            <= `TTC_S_TILE;
          end

          // 6a. describe the block to TC03
          `TTC_S_TILE: begin
            if (tile_hs) tile_sent <= 1'b1;
            if (tile_rsp_hs) begin                    // error / geometry mismatch: caught as fatal above
              l_m <= tob_tile_rsp_m; l_n <= tob_tile_rsp_n; l_k <= tob_tile_rsp_k;
              tile_armed <= 1'b1;
              st <= `TTC_S_ACCUMULATE;
            end
          end

          // 7-8. wait for the previous launch's real completion and merge
          `TTC_S_ACCUMULATE: if (retire_ok) begin
            if (tile_armed)                          st <= `TTC_S_LAUNCH;
            else if (ex_last_step || ex_last_k)      st <= `TTC_S_STORE;     // serial: store this tile; or final drain
            else                                     st <= `TTC_S_LOAD;      // serial: next K chunk (ex_adv)
          end

          // 6b. issue the systolic computation
          `TTC_S_LAUNCH: if (arr_cfg_hs) begin
            acc_ps_slot    <= cur_slot;
            acc_ps_tag     <= cur_tag;
            acc_ps_chunk   <= ex_kidx;
            acc_ps_chunk_k <= l_k;
            exp_mac        <= 40'(l_m) * 40'(l_n) * 40'(l_k);
            launch_pend    <= 1'b1;
            launched       <= launched + 32'd1;
            tile_armed     <= 1'b0;
            slices_done    <= 1'b0;
            st             <= `TTC_S_COMPUTE;
          end

          // 6c. slices stream; release the set after the last one
          `TTC_S_COMPUTE: if (cmp_end_hs) begin
            if (ovl && !ex_last_step) st <= ex_last_k ? `TTC_S_RESERVE : `TTC_S_LOAD;
            else                      st <= `TTC_S_ACCUMULATE;
          end

          // 10-12. output processing (TC04 commit), write, mark complete
          `TTC_S_STORE: if (store_done_c) begin
            if (!ex_last_step)        st <= `TTC_S_RESERVE;                  // serial: next tile
            else if (final_ok_c)      st <= `TTC_S_COMPLETE;
          end

          `TTC_S_COMPLETE: if (cpl_ready) st <= `TTC_S_IDLE;
          `TTC_S_ERROR:    if (cpl_ready) st <= `TTC_S_HALT;
          default: ;                                   // HALT: until reset
        endcase
      end
    end
  end

  // ============================================================ completion record
  assign cpl_valid    = (st == `TTC_S_COMPLETE) || (st == `TTC_S_ERROR);
  assign cpl_tag      = c_tag;
  assign cpl_code     = err_code;
  assign cpl_err      = (err_code != `TTC_OK);
  assign cpl_err_addr = err_addr;
  assign cpl_cycles   = gemm_cyc;
  assign cpl_tiles    = tiles_done;
  assign cpl_chunks   = launched;

  assign busy   = (st != `TTC_S_IDLE) && (st != `TTC_S_HALT);
  assign halted = (st == `TTC_S_HALT);
  assign state  = st;

  // ============================================================ performance counters
  localparam int IW = 32;
  logic [`TTC_NUM_PC*IW-1:0] pinc;
  logic cpl_hs;
  assign cpl_hs = cpl_valid && cpl_ready;
  always_comb begin
    pinc = '0;
    pinc[`TTC_PC_BUSY*IW        +: IW] = 32'(busy);
    pinc[`TTC_PC_GEMM_OK*IW     +: IW] = 32'(cpl_hs && !cpl_err);
    pinc[`TTC_PC_GEMM_ERR*IW    +: IW] = 32'(cpl_hs &&  cpl_err);
    pinc[`TTC_PC_TILES*IW       +: IW] = 32'(wr_ack && wr_ack_tlast);
    pinc[`TTC_PC_CHUNKS*IW      +: IW] = 32'(arr_cfg_hs);
    pinc[`TTC_PC_MAC_USEFUL*IW  +: IW] = rd_last_hs ? arr_perf_mac[31:0] : 32'd0;
    pinc[`TTC_PC_MAC_PAD*IW     +: IW] = rd_last_hs ? arr_perf_pad[31:0] : 32'd0;
    pinc[`TTC_PC_COMPUTE_CYC*IW +: IW] = 32'(arr_busy && !arr_tile_done);
    pinc[`TTC_PC_ISSUE_CYC*IW   +: IW] = 32'(slice_hs);
    pinc[`TTC_PC_DMA_WAIT*IW    +: IW] = 32'((st == `TTC_S_LOAD) && !tob_cmp_begin_ready);
    pinc[`TTC_PC_STARVE*IW      +: IW] = 32'(tob_ev_starve);
    pinc[`TTC_PC_OUT_STALL*IW   +: IW] = 32'(ev_out_stall);
    pinc[`TTC_PC_BUF_SWITCH*IW  +: IW] = 32'(cmp_begin_hs && have_prev_set && (tob_cmp_set != prev_set));
    pinc[`TTC_PC_A_LOADS*IW     +: IW] = 32'(ev_a_load);
    pinc[`TTC_PC_B_LOADS*IW     +: IW] = 32'(ev_b_load);
    pinc[`TTC_PC_A_REUSE*IW     +: IW] = 32'(ev_a_reuse);
    pinc[`TTC_PC_B_REUSE*IW     +: IW] = 32'(ev_b_reuse);
    pinc[`TTC_PC_RD_WORDS*IW    +: IW] = 32'(ld_rd_gnt);
    pinc[`TTC_PC_FILL_BYTES*IW  +: IW] = ev_fb_v ? 32'(ev_fb) : 32'd0;
    pinc[`TTC_PC_WR_WORDS*IW    +: IW] = 32'(st_wr_gnt);
    pinc[`TTC_PC_ACC_WAIT*IW    +: IW] = 32'((st == `TTC_S_RESERVE) && !acc_cfg_hs);
    pinc[`TTC_PC_ARRAY_WAIT*IW  +: IW] = 32'((st == `TTC_S_ACCUMULATE) && !retire_ok);
    pinc[`TTC_PC_OVERLAP*IW     +: IW] = 32'(tob_ev_overlap);
    pinc[`TTC_PC_BUS_STALL*IW   +: IW] = 32'(ev_bus_stall);
  end
  ttc_perf #(.NC(`TTC_NUM_PC), .IW(IW), .CNT_W(CNT_W)) u_perf (
    .clk(clk), .rst_n(rst_n), .clear(perf_clear), .inc(pinc), .cnt(perf_cnt));

`ifndef SYNTHESIS
  // ---------------------------------------------------------- simulation-only protocol checks
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n) begin
    if (rsp_valid && !rsp_ready)                 $error("tensor_tile_controller: SFB2 response refused");
    if (slice_hs && st != `TTC_S_COMPUTE)        $error("tensor_tile_controller: slice outside COMPUTE");
    if (acc_cfg_hs && !ex_first_k)               $error("tensor_tile_controller: accumulator reserved mid-tile");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
