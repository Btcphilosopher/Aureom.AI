// =============================================================================
// SilicaFlux TENSORCORE 06 :: ttc_validate
// GEMM command validation for tensor_tile_controller.
//
//   C[M,N] = A[M,K] x B[K,N]   dense, row-major, INT8 x INT8 -> INT32
//
//   A[m][k] at a_base + m*lda + k          (bytes; lda >= K)
//   B[k][n] at b_base + k*ldb + n          (bytes; ldb >= N)
//   C[m][n] at c_base + m*ldc + 4*n        (bytes; ldc >= 4N, c_base and ldc 4-aligned)
//
// Sequence (start pulse, fields stable until done):
//   V_MUL   register the three footprint products (M-1)*lda, (K-1)*ldb, (M-1)*ldc
//   V_DIV   restoring division: n_chunks = ceil(K / kc)       (18 iterations)
//   V_CHECK evaluate the rules in order, first failure wins   -> done pulse
// The products use the low 16/17 bits of M-1 / K-1: if M, N or K is out of
// range, an earlier rule (DIM_ZERO / DIM_RANGE) has already failed, so a
// truncated product can never decide the result.  All address arithmetic is
// 64 bits wide: nothing wraps, an overflow is detected, never computed modulo.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "ttc_defs.svh"
`default_nettype none

module ttc_validate #(
  parameter int          TILE_K   = 64,
  parameter int          K_MAX    = 131071,             // largest overflow-free INT8 x INT8 -> INT32 reduction
  parameter int          DIM_MAX  = 65535,
  parameter int          CHUNK_MAX = 65535,            // TC04 CHUNK_W = 16
  parameter logic [32:0] MEM_LO   = 33'h0_0000_0000,   // memory window [MEM_LO, MEM_HI)
  parameter logic [32:0] MEM_HI   = 33'h1_0000_0000
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        start,
  input  wire logic [7:0]  flags,
  input  wire logic [1:0]  a_layout, b_layout, c_layout,
  input  wire logic [1:0]  a_type, b_type, c_type,
  input  wire logic [31:0] m, n, k, kc,
  input  wire logic [31:0] a_base, b_base, c_base,
  input  wire logic [31:0] lda, ldb, ldc,
  output logic             done,                       // 1-cycle pulse
  output logic [4:0]       code,                       // TTC_OK or TTC_ERR_*
  output logic [16:0]      kc_eff,                     // chunk length used (kc, or TILE_K if kc == 0)
  output logic [15:0]      n_chunks,                   // ceil(K / kc_eff) (valid when code == OK)
  output logic [31:0]      a_last, b_last, c_last      // last byte of each footprint (valid when code == OK)
);
  localparam logic [1:0] V_IDLE = 2'd0, V_MUL = 2'd1, V_DIV = 2'd2, V_CHECK = 2'd3;

  logic [1:0]  st;
  logic [63:0] pa, pb, pc;
  logic [17:0] rem, num_q;
  logic [17:0] quo;
  logic [4:0]  it;
  logic [16:0] kc_e;

  logic [18:0] r2;
  logic [15:0] m_m1;
  logic [16:0] k_m1;
  assign m_m1 = m[15:0] - 16'd1;
  assign k_m1 = k[16:0] - 17'd1;
  assign kc_e = (kc == 32'd0) ? 17'(TILE_K) : kc[16:0];
  assign r2   = {rem, num_q[17]};

  // ---------------------------------------------------------------- sequencer
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= V_IDLE; pa <= '0; pb <= '0; pc <= '0; rem <= '0; num_q <= '0; quo <= '0; it <= '0;
    end else begin
      case (st)
        V_IDLE: if (start) st <= V_MUL;
        V_MUL: begin
          pa    <= 64'(m_m1) * 64'(lda);
          pb    <= 64'(k_m1) * 64'(ldb);
          pc    <= 64'(m_m1) * 64'(ldc);
          num_q <= 18'(k[16:0]) + 18'(kc_e) - 18'd1;    // ceil(K/kc) = floor((K + kc - 1)/kc)
          rem   <= '0;
          quo   <= '0;
          it    <= 5'd18;
          st    <= V_DIV;
        end
        V_DIV: begin
          // one restoring-division step per cycle, MSB first
          num_q <= {num_q[16:0], 1'b0};
          if (r2 >= 19'(kc_e)) begin
            rem <= 18'(r2 - 19'(kc_e));
            quo <= {quo[16:0], 1'b1};
          end else begin
            rem <= r2[17:0];
            quo <= {quo[16:0], 1'b0};
          end
          it <= it - 5'd1;
          if (it == 5'd1) st <= V_CHECK;
        end
        default: st <= V_IDLE;                          // V_CHECK: result produced combinationally below
      endcase
    end
  end

  // ---------------------------------------------------------------- rules (V_CHECK)
  logic [63:0] al, bl, cl;
  logic [4:0]  c_code;
  assign al = 64'(a_base) + pa + 64'(k[16:0]) - 64'd1;            // a + (M-1)*lda + K - 1
  assign bl = 64'(b_base) + pb + 64'(n[15:0]) - 64'd1;            // b + (K-1)*ldb + N - 1
  assign cl = 64'(c_base) + pc + 64'({n[15:0], 2'b00}) - 64'd1;   // c + (M-1)*ldc + 4N - 1

  /* verilator lint_off UNSIGNED */
  function automatic logic out_win(input logic [31:0] lo, input logic [63:0] hi);
    out_win = (33'(lo) < MEM_LO) || (hi >= 64'(MEM_HI));     // MEM_LO = 0 makes the first term constant
  endfunction
  /* verilator lint_on UNSIGNED */

  always_comb begin
    c_code = `TTC_OK;
    if ((flags & ~`TTC_FL_MASK) != 8'd0)                                         c_code = `TTC_ERR_FLAGS;
    else if (a_layout != `TTC_LAYOUT_ROW || b_layout != `TTC_LAYOUT_ROW ||
             c_layout != `TTC_LAYOUT_ROW)                                        c_code = `TTC_ERR_LAYOUT;
    else if (a_type != `TTC_TYPE_INT8 || b_type != `TTC_TYPE_INT8 ||
             c_type != `TTC_TYPE_INT32)                                          c_code = `TTC_ERR_DTYPE;
    else if (m == 32'd0 || n == 32'd0 || k == 32'd0)                             c_code = `TTC_ERR_DIM_ZERO;
    else if (m > 32'(DIM_MAX) || n > 32'(DIM_MAX) || k > 32'(K_MAX))            c_code = `TTC_ERR_DIM_RANGE;
    else if (kc > 32'(TILE_K) || quo > 18'(CHUNK_MAX))                          c_code = `TTC_ERR_CHUNK;
    else if (lda < k || ldb < n || 34'(ldc) < {n, 2'b00})                        c_code = `TTC_ERR_LD;
    else if (c_base[1:0] != 2'b00 || ldc[1:0] != 2'b00)                          c_code = `TTC_ERR_ALIGN;
    else if (al[63:32] != 32'd0 || bl[63:32] != 32'd0 || cl[63:32] != 32'd0)     c_code = `TTC_ERR_ADDR_OVF;
    else if (out_win(a_base, al) || out_win(b_base, bl) || out_win(c_base, cl))  c_code = `TTC_ERR_RANGE;
    else if ((64'(c_base) <= al && 64'(a_base) <= cl) ||
             (64'(c_base) <= bl && 64'(b_base) <= cl))                           c_code = `TTC_ERR_ALIAS;
  end

  assign done     = (st == V_CHECK);
  assign code     = c_code;
  assign kc_eff   = kc_e;
  assign n_chunks = quo[15:0];
  assign a_last   = al[31:0];
  assign b_last   = bl[31:0];
  assign c_last   = cl[31:0];
endmodule

`default_nettype wire
