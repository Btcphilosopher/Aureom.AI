// =============================================================================
// SilicaFlux TENSORCORE 06 :: ttc_store
// Output path: TENSORCORE 04 committed rows (odma port) -> SFB2 word writes of C.
//
//   C[m0+row][n0+j] (INT32, little-endian) at  c_tile + row*ldc + 4*j,
//   c_tile = c_base + m0*ldc + 4*n0           (computed by the scheduler at RESERVE)
//
// TC04 commits tiles in completion order, which is the order the scheduler
// reserved them (one array, chunks launched in tile order).  The scheduler
// therefore pushes {c_tile, tag} into the tile-info FIFO at RESERVE, and the
// store path takes the head for every beat; the beat's o_tag must equal the
// head's tag (otherwise tag_err: a bookkeeping failure, never silently written
// to a wrong address).  The head is popped with the tile's o_last beat.
//
// One SFB2 write per active lane (o_col_mask, contiguous from lane 0 because
// eff_n columns are active).  Masked lanes are never written, so the bytes of
// C beyond column N-1 and the padding between C rows (ldc > 4N) are untouched.
// The beat is popped (o_ready) in the cycle its last lane is granted.
// Guard: every address must lie inside [c_base, c_last] (validated footprint),
// else the write is suppressed and guard_err is raised.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module ttc_store #(
  parameter int TILE_M   = 4,
  parameter int TILE_N   = 4,
  parameter int TI_DEPTH = 8,                     // power of two >= 2
  localparam int RIDW = (TILE_M > 1) ? $clog2(TILE_M) : 1,
  localparam int LW   = (TILE_N > 1) ? $clog2(TILE_N) : 1,
  localparam int TIW  = $clog2(TI_DEPTH)
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic [31:0]           ldc, c_base, c_last,
  // ---------------------------------------------------------- tile info (scheduler, RESERVE)
  input  wire logic                  ti_push,
  input  wire logic [31:0]           ti_ctile,
  input  wire logic [15:0]           ti_tag,
  output logic                       ti_full,
  output logic                       ti_empty,
  // ---------------------------------------------------------- TC04 odma port
  input  wire logic                  o_valid,
  output logic                       o_ready,
  input  wire logic [RIDW-1:0]       o_row,
  input  wire logic [TILE_N-1:0]     o_col_mask,
  input  wire logic [TILE_N*32-1:0]  o_data,
  input  wire logic                  o_last,
  input  wire logic [15:0]           o_tag,
  input  wire logic [TILE_N-1:0]     o_ovf,
  input  wire logic                  o_err,
  // ---------------------------------------------------------- write requests (to ttc_sfb_master)
  output logic                       wr_valid,
  output logic [31:0]                wr_addr,
  output logic [31:0]                wr_data,
  output logic                       wr_tlast,    // last element of the tile
  input  wire logic                  wr_gnt,
  // ---------------------------------------------------------- status
  output logic                       ev_stall,    // a write was pending and not granted
  output logic                       ev_ovf,      // pulse: a beat with an overflow flag was stored
  output logic                       ev_beat_err, // pulse: a beat flagged o_err was stored
  output logic                       tag_err,     // beat for an unexpected tile / malformed mask
  output logic                       guard_err
);
  // ---------------------------------------------------------- tile-info FIFO
  logic [47:0]   ti_head;
  logic [TIW:0]  ti_cnt;
  logic          ti_pop;
  dma_fifo #(.WIDTH(48), .DEPTH(TI_DEPTH)) u_ti (
    .clk(clk), .rst_n(rst_n), .clr(1'b0), .push(ti_push), .wdata({ti_tag, ti_ctile}),
    .pop(ti_pop), .rdata(ti_head), .count(ti_cnt));
  assign ti_full  = (ti_cnt == (TIW+1)'(TI_DEPTH));
  assign ti_empty = (ti_cnt == '0);

  // ---------------------------------------------------------- lane sequencer
  logic [LW-1:0]  lane;
  logic [LW:0]    n_lanes;
  logic           mask_ok, tag_ok, guard_ok, last_lane, go;
  logic [31:0]    row_off;
  logic [63:0]    addr64;

  always_comb begin
    n_lanes = '0;
    for (int j = 0; j < TILE_N; j++) n_lanes = n_lanes + (LW+1)'(o_col_mask[j]);
  end
  // active lanes must be exactly 0 .. n_lanes-1 and at least one
  assign mask_ok   = (n_lanes != '0) &&
                     (o_col_mask == TILE_N'(({{TILE_N{1'b0}}, 1'b1} << n_lanes) - 1'b1));
  assign tag_ok    = !ti_empty && (o_tag == ti_head[47:32]) && mask_ok;
  assign row_off   = 32'(o_row) * ldc;
  assign addr64    = 64'(ti_head[31:0]) + 64'(row_off) + 64'({lane, 2'b00});
  assign guard_ok  = (addr64 >= 64'(c_base)) && (addr64 + 64'd3 <= 64'(c_last)) && (addr64[1:0] == 2'b00);
  assign last_lane = ((LW+1)'(lane) == n_lanes - (LW+1)'(1));

  assign wr_valid  = o_valid && tag_ok && guard_ok;
  assign wr_addr   = addr64[31:0];
  assign wr_data   = o_data[32*lane +: 32];
  assign wr_tlast  = o_last && last_lane;
  assign go        = wr_valid && wr_gnt;
  assign o_ready   = go && last_lane;
  assign ti_pop    = o_ready && o_last;

  assign ev_stall    = wr_valid && !wr_gnt;
  assign ev_ovf      = o_ready && (|o_ovf);
  assign ev_beat_err = o_ready && o_err;
  assign tag_err     = o_valid && !tag_ok;
  assign guard_err   = o_valid && tag_ok && !guard_ok;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)        lane <= '0;
    else if (go)       lane <= last_lane ? '0 : lane + LW'(1);
  end
endmodule

`default_nettype wire
