// =============================================================================
// SilicaFlux TENSORCORE 06 :: ttc_perf
// Saturating performance counters: counter i adds inc[i*IW +: IW] every cycle.
// perf_clear zeroes all counters (synchronous).  Definitions: ttc_defs.svh and
// docs/07_PERFORMANCE_COUNTERS.md.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module ttc_perf #(
  parameter int NC    = 24,
  parameter int IW    = 32,
  parameter int CNT_W = 40
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                clear,
  input  wire logic [NC*IW-1:0]    inc,
  output logic      [NC*CNT_W-1:0] cnt
);
  for (genvar i = 0; i < NC; i++) begin : g_c
    logic [CNT_W-1:0] q;
    logic [CNT_W:0]   s;
    assign s = (CNT_W+1)'(q) + (CNT_W+1)'(inc[i*IW +: IW]);
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n)      q <= '0;
      else if (clear)  q <= '0;
      else             q <= s[CNT_W] ? {CNT_W{1'b1}} : s[CNT_W-1:0];
    end
    assign cnt[i*CNT_W +: CNT_W] = q;
  end
endmodule

`default_nettype wire
