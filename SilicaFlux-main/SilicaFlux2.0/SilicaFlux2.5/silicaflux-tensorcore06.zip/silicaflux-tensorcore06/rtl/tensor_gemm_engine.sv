// =============================================================================
// SilicaFlux TENSORCORE 06 :: tensor_gemm_engine
// Integration top: tensor_tile_controller + the unmodified TENSORCORE 02 / 03 /
// 04 RTL.  One GEMM command port, one completion port, one SFB2 master port.
//
//      cmd -> [ tensor_tile_controller ] -> cpl
//                |  SFB2 master (A/B word reads, C word writes) <-> memory / DataFabric
//                |  fill port, ownership, tile descriptors
//                v
//      [ TC03 tensor_operand_buffer ] --k-slices--> [ TC02 tensor_systolic_array ]
//                                                         | readout rows (+ sideband
//                                                         v  slot/tag/chunk/chunk_k from the controller)
//                                              [ TC04 tensor_acc_subsystem ] --odma--> controller store path
//
// Slices go straight from TC03 to TC02 and readout rows straight from TC02 to
// TC04 (no controller logic on those data paths); the controller only taps the
// handshakes.  TC04 is configured with bias off and destination DMA only, so
// the committed exact INT32 rows leave on odma_*; osram/oquant are unused.
// array_stall_i is TC02's global freeze input, exposed for back-pressure tests.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "ttc_defs.svh"
`include "tob_defs.svh"
`default_nettype none

module tensor_gemm_engine #(
  parameter int          TILE_M       = 4,
  parameter int          TILE_N       = 4,
  parameter int          TILE_K       = 64,
  parameter int          NUM_SETS     = 2,
  parameter int          A_SET_BYTES  = 512,
  parameter int          B_SET_BYTES  = 512,
  parameter int          A_BANKS      = 4,
  parameter int          B_BANKS      = 2,
  parameter int          PORT_MODE    = `TOB_PORT_1R1W,
  parameter int          SET_MAP      = `TOB_SET_SHARED,
  parameter int          READ_LATENCY = 1,
  parameter int          A_STAGE      = 2,
  parameter int          B_STAGE      = 4,
  parameter int          A_PAD        = 1,
  parameter int          NUM_SLOTS    = 2,
  parameter int          ACC_RD_LAT   = 1,
  parameter int          MUL_PIPE     = 0,
  parameter int          MAX_OUT      = 8,
  parameter int          FILL_DEPTH   = 8,
  parameter int          TI_DEPTH     = 8,
  parameter logic [32:0] MEM_LO       = 33'h0_0000_0000,
  parameter logic [32:0] MEM_HI       = 33'h1_0000_0000,
  parameter int          WDOG_LOG2    = 16,
  parameter int          CNT_W        = 40,
  localparam int MW     = $clog2(TILE_M + 1),
  localparam int NW     = $clog2(TILE_N + 1),
  localparam int RIDW   = (TILE_M > 1) ? $clog2(TILE_M) : 1,
  localparam int SW     = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1,
  localparam int SLOT_W = (NUM_SLOTS > 1) ? $clog2(NUM_SLOTS) : 1,
  localparam int AEVW   = $clog2(TILE_N + 1),
  localparam int ANPERF = tensor_acc_pkg::NPERF
) (
  input  wire logic                      clk,
  input  wire logic                      rst_n,
  // command
  input  wire logic                      cmd_valid,
  output logic                           cmd_ready,
  input  wire logic [7:0]                cmd_tag,
  input  wire logic [7:0]                cmd_flags,
  input  wire logic [1:0]                cmd_a_layout, cmd_b_layout, cmd_c_layout,
  input  wire logic [1:0]                cmd_a_type, cmd_b_type, cmd_c_type,
  input  wire logic [31:0]               cmd_m, cmd_n, cmd_k, cmd_kc,
  input  wire logic [31:0]               cmd_a_base, cmd_b_base, cmd_c_base,
  input  wire logic [31:0]               cmd_lda, cmd_ldb, cmd_ldc,
  // completion
  output logic                           cpl_valid,
  input  wire logic                      cpl_ready,
  output logic [7:0]                     cpl_tag,
  output logic                           cpl_err,
  output logic [4:0]                     cpl_code,
  output logic [31:0]                    cpl_err_addr,
  output logic [31:0]                    cpl_cycles,
  output logic [31:0]                    cpl_tiles,
  output logic [31:0]                    cpl_chunks,
  // SFB2 master
  output logic                           req_valid,
  input  wire logic                      req_ready,
  output logic                           req_write,
  output logic [31:0]                    req_addr,
  output logic [31:0]                    req_wdata,
  output logic [3:0]                     req_wstrb,
  input  wire logic                      rsp_valid,
  output logic                           rsp_ready,
  input  wire logic [31:0]               rsp_rdata,
  input  wire logic                      rsp_error,
  // test hook / status / performance
  input  wire logic                      array_stall_i,
  output logic                           busy,
  output logic                           halted,
  output logic [3:0]                     state,
  output logic [2:0]                     ld_state,
  input  wire logic                      perf_clear,
  output logic [`TTC_NUM_PC*CNT_W-1:0]   perf_cnt,
  output logic [`TOB_NUM_EV*32-1:0]      tob_perf_cnt,
  output logic [ANPERF*40-1:0]           acc_perf_cnt
);
  // Subsystem outputs that the controller does not need are left unused on purpose
  // (observability ports of TC03/TC04, the TC04 host port, the TC02 per-launch counters).
  /* verilator lint_off UNUSEDSIGNAL */
  // ============================================================ TC03 <-> controller
  logic                 t_dreq_v, t_dreq_r, t_dreq_we, t_drsp_v, t_drsp_r, t_drsp_err, t_drsp_we;
  logic [31:0]          t_dreq_addr, t_dreq_wdata, t_drsp_rdata;
  logic [3:0]           t_dreq_wstrb;
  logic [7:0]           t_dreq_tag, t_drsp_tag;
  logic [2:0]           t_drsp_code;
  logic                 t_fb_v, t_fb_r, t_fe_v, t_fe_r, t_cb_v, t_cb_r, t_ce_v, t_ce_r;
  logic [SW-1:0]        t_fill_set, t_cmp_set;
  logic [NUM_SETS*2-1:0] t_set_state;
  logic                 t_tile_v, t_tile_r, t_rsp_v, t_rsp_r, t_rsp_err;
  logic [31:0]          t_a_addr, t_lda, t_b_addr, t_ldb;
  logic [15:0]          t_m0, t_n0, t_mat_m, t_mat_n;
  logic [16:0]          t_k0, t_mat_k, t_k;
  logic [7:0]           t_tag, t_rsp_tag;
  logic [3:0]           t_rsp_code;
  logic [MW-1:0]        t_rsp_m;
  logic [NW-1:0]        t_rsp_n;
  logic [16:0]          t_rsp_k;
  logic                 s_valid, s_ready, s_first, s_last;
  logic [TILE_M*8-1:0]  s_a;
  logic [TILE_N*8-1:0]  s_b;
  logic [16:0]          s_k, s_kg;
  logic [15:0]          s_m0, s_n0;
  logic [TILE_M-1:0]    s_row_mask;
  logic [TILE_N-1:0]    s_col_mask;
  logic [7:0]           s_tag;
  logic [SW-1:0]        s_set;
  logic                 t_busy, t_engine_idle;
  logic [`TOB_NUM_EV*8-1:0] t_ev;

  // ============================================================ TC02 <-> controller / TC04
  logic                 a_cfg_v, a_cfg_r, a_cfg_rej, a_busy, a_tile_done, a_align_err;
  logic [MW-1:0]        a_cfg_m;
  logic [NW-1:0]        a_cfg_n;
  logic [16:0]          a_cfg_k, a_s_k;
  logic                 m_valid, m_ready, m_last;
  logic [RIDW-1:0]      m_row;
  logic [TILE_N*32-1:0] m_data;
  logic [TILE_N-1:0]    m_col_mask;
  logic [39:0]          p_busy, p_issue, p_stall_up, p_stall_ext, p_mac, p_pad;

  // ============================================================ TC04 <-> controller
  logic                 c_cfg_v, c_cfg_r, c_cfg_rej;
  logic [2:0]           c_cfg_rej_code;
  logic [SLOT_W-1:0]    c_cfg_slot, c_ps_slot;
  logic [15:0]          c_cfg_tag, c_ps_tag, c_ps_chunk, c_cfg_nch;
  logic [MW-1:0]        c_cfg_m;
  logic [NW-1:0]        c_cfg_n;
  logic [39:0]          c_cfg_ktot;
  logic [16:0]          c_ps_chunk_k;
  logic                 odma_v, odma_r, osram_v, oquant_v;
  logic [15:0]          o_tag;
  logic [SLOT_W-1:0]    o_slot;
  logic [RIDW-1:0]      o_row;
  logic                 o_last, o_err;
  logic [TILE_N-1:0]    o_col_mask, o_ovf, o_clip;
  logic [TILE_N*32-1:0] o_wide, o_data;
  logic                 c_err_pulse, c_idle, c_cmt_done, c_cmt_ovf, c_cmt_clip, c_cmt_err;
  logic [2:0]           c_err_code;
  logic [7:0]           c_err_sticky;
  logic [SLOT_W-1:0]    c_cmt_slot;
  logic [15:0]          c_cmt_tag;
  logic [NUM_SLOTS*2-1:0] c_slot_state;
  logic [ANPERF*AEVW-1:0] c_ev_inc;
  logic                 c_hc_ready, c_hr_valid, c_hr_vld;
  logic [2:0]           c_hr_status;
  logic [TILE_N*32-1:0] c_hr_data;
  logic [TILE_N-1:0]    c_hr_ovf;
  logic [15:0]          c_hr_nchunk;
  logic [39:0]          c_hr_kacc;
  logic                 c_st_en, c_st_rd_req, c_st_rd_ready, c_st_wr_req, c_st_wr_ready;

  logic [((SET_MAP == `TOB_SET_SPLIT && NUM_SETS == 2) ? 2 : 1) * A_BANKS - 1:0] t_bank_conf;   // = TC03 NPA (A_REPL = 1)
  /* verilator lint_on UNUSEDSIGNAL */

  // ============================================================ controller
  tensor_tile_controller #(
    .TILE_M(TILE_M), .TILE_N(TILE_N), .TILE_K(TILE_K), .NUM_SETS(NUM_SETS), .A_SET_BYTES(A_SET_BYTES),
    .B_SET_BYTES(B_SET_BYTES), .A_PAD(A_PAD), .NUM_SLOTS(NUM_SLOTS), .MAX_OUT(MAX_OUT), .FILL_DEPTH(FILL_DEPTH),
    .TI_DEPTH(TI_DEPTH), .MEM_LO(MEM_LO), .MEM_HI(MEM_HI), .WDOG_LOG2(WDOG_LOG2), .CNT_W(CNT_W), .TOB_TAG_W(8)
  ) u_ctl (
    .clk(clk), .rst_n(rst_n),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_tag(cmd_tag), .cmd_flags(cmd_flags),
    .cmd_a_layout(cmd_a_layout), .cmd_b_layout(cmd_b_layout), .cmd_c_layout(cmd_c_layout),
    .cmd_a_type(cmd_a_type), .cmd_b_type(cmd_b_type), .cmd_c_type(cmd_c_type),
    .cmd_m(cmd_m), .cmd_n(cmd_n), .cmd_k(cmd_k), .cmd_kc(cmd_kc),
    .cmd_a_base(cmd_a_base), .cmd_b_base(cmd_b_base), .cmd_c_base(cmd_c_base),
    .cmd_lda(cmd_lda), .cmd_ldb(cmd_ldb), .cmd_ldc(cmd_ldc),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_tag(cpl_tag), .cpl_err(cpl_err), .cpl_code(cpl_code),
    .cpl_err_addr(cpl_err_addr), .cpl_cycles(cpl_cycles), .cpl_tiles(cpl_tiles), .cpl_chunks(cpl_chunks),
    .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write), .req_addr(req_addr),
    .req_wdata(req_wdata), .req_wstrb(req_wstrb),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error),
    .tob_dma_req_valid(t_dreq_v), .tob_dma_req_ready(t_dreq_r), .tob_dma_req_we(t_dreq_we),
    .tob_dma_req_addr(t_dreq_addr), .tob_dma_req_wdata(t_dreq_wdata), .tob_dma_req_wstrb(t_dreq_wstrb),
    .tob_dma_req_tag(t_dreq_tag), .tob_dma_rsp_valid(t_drsp_v), .tob_dma_rsp_ready(t_drsp_r), .tob_dma_rsp_err(t_drsp_err),
    .tob_fill_begin_valid(t_fb_v), .tob_fill_begin_ready(t_fb_r), .tob_fill_end_valid(t_fe_v), .tob_fill_end_ready(t_fe_r),
    .tob_cmp_begin_valid(t_cb_v), .tob_cmp_begin_ready(t_cb_r), .tob_cmp_end_valid(t_ce_v), .tob_cmp_end_ready(t_ce_r),
    .tob_fill_set(t_fill_set), .tob_cmp_set(t_cmp_set),
    .tob_tile_valid(t_tile_v), .tob_tile_ready(t_tile_r), .tob_tile_a_addr(t_a_addr), .tob_tile_lda(t_lda),
    .tob_tile_b_addr(t_b_addr), .tob_tile_ldb(t_ldb), .tob_tile_m0(t_m0), .tob_tile_n0(t_n0),
    .tob_tile_mat_m(t_mat_m), .tob_tile_mat_n(t_mat_n), .tob_tile_k0(t_k0), .tob_tile_mat_k(t_mat_k),
    .tob_tile_k(t_k), .tob_tile_tag(t_tag),
    .tob_tile_rsp_valid(t_rsp_v), .tob_tile_rsp_ready(t_rsp_r), .tob_tile_rsp_err(t_rsp_err),
    .tob_tile_rsp_m(t_rsp_m), .tob_tile_rsp_n(t_rsp_n), .tob_tile_rsp_k(t_rsp_k),
    .tob_s_valid(s_valid), .tob_s_ready(s_ready), .tob_s_last(s_last), .tob_s_k(s_k),
    .tob_ev_starve(t_ev[`TOB_EV_STARVE*8 +: 8]), .tob_ev_overlap(t_ev[`TOB_EV_OVERLAP*8 +: 8]),
    .arr_cfg_valid(a_cfg_v), .arr_cfg_ready(a_cfg_r), .arr_cfg_m(a_cfg_m), .arr_cfg_n(a_cfg_n), .arr_cfg_k(a_cfg_k),
    .arr_cfg_reject(a_cfg_rej), .arr_s_k(a_s_k), .arr_busy(a_busy), .arr_tile_done(a_tile_done),
    .arr_align_err(a_align_err), .arr_m_valid(m_valid), .arr_m_ready(m_ready), .arr_m_last(m_last),
    .arr_perf_mac(p_mac), .arr_perf_pad(p_pad),
    .acc_cfg_valid(c_cfg_v), .acc_cfg_ready(c_cfg_r), .acc_cfg_slot(c_cfg_slot), .acc_cfg_tag(c_cfg_tag),
    .acc_cfg_m(c_cfg_m), .acc_cfg_n(c_cfg_n), .acc_cfg_k_total(c_cfg_ktot), .acc_cfg_n_chunks(c_cfg_nch),
    .acc_cfg_reject(c_cfg_rej),
    .acc_ps_slot(c_ps_slot), .acc_ps_tag(c_ps_tag), .acc_ps_chunk(c_ps_chunk), .acc_ps_chunk_k(c_ps_chunk_k),
    .acc_err_pulse(c_err_pulse), .acc_ev_chunk(c_ev_inc[tensor_acc_pkg::PF_CHUNKS*AEVW +: AEVW] != '0),
    .acc_o_valid(odma_v), .acc_o_ready(odma_r), .acc_o_row(o_row), .acc_o_col_mask(o_col_mask),
    .acc_o_data(o_data), .acc_o_last(o_last), .acc_o_tag(o_tag), .acc_o_ovf(o_ovf), .acc_o_err(o_err),
    .busy(busy), .halted(halted), .state(state), .ld_state(ld_state),
    .perf_clear(perf_clear), .perf_cnt(perf_cnt));

  // ============================================================ TENSORCORE 03 (unmodified)
  tensor_operand_buffer #(
    .ARRAY_ROWS(TILE_M), .ARRAY_COLS(TILE_N), .WORD_BYTES(4), .A_SET_BYTES(A_SET_BYTES), .B_SET_BYTES(B_SET_BYTES),
    .A_BANKS(A_BANKS), .B_BANKS(B_BANKS), .A_REPL(1), .NUM_SETS(NUM_SETS), .SET_MAP(SET_MAP), .PORT_MODE(PORT_MODE),
    .READ_LATENCY(READ_LATENCY), .A_STAGE(A_STAGE), .B_STAGE(B_STAGE), .WR_STARVE_LIMIT(8), .ADDR_W(32),
    .DMA_BASE(64'h0), .IDX_W(16), .K_W(17), .TAG_W(8), .DMA_RSP_DEPTH(4), .PERF_EN(1), .CNT_W(32)
  ) u_tob (
    .clk(clk), .rst_n(rst_n),
    .dma_req_valid(t_dreq_v), .dma_req_ready(t_dreq_r), .dma_req_we(t_dreq_we), .dma_req_addr(t_dreq_addr),
    .dma_req_wdata(t_dreq_wdata), .dma_req_wstrb(t_dreq_wstrb), .dma_req_tag(t_dreq_tag),
    .dma_rsp_valid(t_drsp_v), .dma_rsp_ready(t_drsp_r), .dma_rsp_rdata(t_drsp_rdata), .dma_rsp_err(t_drsp_err),
    .dma_rsp_err_code(t_drsp_code), .dma_rsp_we(t_drsp_we), .dma_rsp_tag(t_drsp_tag),
    .fill_begin_valid(t_fb_v), .fill_begin_ready(t_fb_r), .fill_end_valid(t_fe_v), .fill_end_ready(t_fe_r),
    .cmp_begin_valid(t_cb_v), .cmp_begin_ready(t_cb_r), .cmp_end_valid(t_ce_v), .cmp_end_ready(t_ce_r),
    .fill_set(t_fill_set), .cmp_set(t_cmp_set), .set_state(t_set_state),
    .tile_valid(t_tile_v), .tile_ready(t_tile_r), .tile_a_addr(t_a_addr), .tile_lda(t_lda), .tile_b_addr(t_b_addr),
    .tile_ldb(t_ldb), .tile_m0(t_m0), .tile_n0(t_n0), .tile_k0(t_k0), .tile_mat_m(t_mat_m), .tile_mat_n(t_mat_n),
    .tile_mat_k(t_mat_k), .tile_k(t_k), .tile_tag(t_tag),
    .tile_rsp_valid(t_rsp_v), .tile_rsp_ready(t_rsp_r), .tile_rsp_tag(t_rsp_tag), .tile_rsp_err(t_rsp_err),
    .tile_rsp_code(t_rsp_code), .tile_rsp_m(t_rsp_m), .tile_rsp_n(t_rsp_n), .tile_rsp_k(t_rsp_k),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0),
    .s_row_mask(s_row_mask), .s_col_mask(s_col_mask), .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .busy(t_busy), .engine_idle(t_engine_idle), .ev_inc(t_ev), .ev_bank_conflict_a(t_bank_conf),
    .perf_clear(perf_clear), .perf_cnt(tob_perf_cnt));

  // ============================================================ TENSORCORE 02 (unmodified)
  tensor_systolic_array #(
    .ARRAY_ROWS(TILE_M), .ARRAY_COLS(TILE_N), .DATA_WIDTH(8), .ACC_WIDTH(32), .K_WIDTH(17),
    .MUL_PIPE(MUL_PIPE), .CHECK_ALIGN(1), .PERF_EN(1)
  ) u_arr (
    .clk(clk), .rst_n(rst_n),
    .cfg_valid(a_cfg_v), .cfg_ready(a_cfg_r), .cfg_m(a_cfg_m), .cfg_n(a_cfg_n), .cfg_k(a_cfg_k), .cfg_reject(a_cfg_rej),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(a_s_k), .stall_i(array_stall_i),
    .m_valid(m_valid), .m_ready(m_ready), .m_row(m_row), .m_data(m_data), .m_col_mask(m_col_mask), .m_last(m_last),
    .busy(a_busy), .tile_done(a_tile_done), .align_err(a_align_err),
    .perf_busy(p_busy), .perf_issue(p_issue), .perf_stall_up(p_stall_up), .perf_stall_ext(p_stall_ext),
    .perf_mac(p_mac), .perf_pad(p_pad));

  // ============================================================ TENSORCORE 04 (unmodified)
  tensor_acc_subsystem #(
    .ROWS(TILE_M), .COLS(TILE_N), .DATA_W(8), .PSUM_W(32), .ACC_W(32), .OUT_W(32), .BIAS_W(32),
    .NUM_TILES(NUM_SLOTS), .TAG_W(16), .CHUNK_W(16), .KC_W(17), .KTOT_W(40), .RD_LAT(ACC_RD_LAT),
    .OVF_POLICY(tensor_acc_pkg::OVF_SATURATE), .STRICT_RANGE(1), .PSUM_GUARD(1),
    .OFIFO_DEPTH(4), .HFIFO_DEPTH(4), .PERF_EN(1), .PERF_W(40)
  ) u_acc (
    .clk(clk), .rst_n(rst_n),
    .cfg_valid(c_cfg_v), .cfg_ready(c_cfg_r), .cfg_slot(c_cfg_slot), .cfg_tag(c_cfg_tag), .cfg_m(c_cfg_m),
    .cfg_n(c_cfg_n), .cfg_k_total(c_cfg_ktot), .cfg_n_chunks(c_cfg_nch), .cfg_bias_en(1'b0),
    .cfg_bias({TILE_N*32{1'b0}}), .cfg_dest(3'b100), .cfg_reject(c_cfg_rej), .cfg_reject_code(c_cfg_rej_code),
    .ps_valid(m_valid), .ps_ready(m_ready), .ps_slot(c_ps_slot), .ps_tag(c_ps_tag), .ps_chunk(c_ps_chunk),
    .ps_chunk_k(c_ps_chunk_k), .ps_row(m_row), .ps_data(m_data), .ps_col_mask(m_col_mask), .ps_last(m_last),
    .hc_valid(1'b0), .hc_ready(c_hc_ready), .hc_op(2'd0), .hc_slot({SLOT_W{1'b0}}), .hc_row({RIDW{1'b0}}),
    .hc_wdata({TILE_N*32{1'b0}}),
    .hr_valid(c_hr_valid), .hr_ready(1'b1), .hr_status(c_hr_status), .hr_data(c_hr_data), .hr_ovf(c_hr_ovf),
    .hr_vld(c_hr_vld), .hr_nchunk(c_hr_nchunk), .hr_kacc(c_hr_kacc),
    .st_rd_block(1'b0), .st_wr_block(1'b0),
    .osram_valid(osram_v), .osram_ready(1'b1), .oquant_valid(oquant_v), .oquant_ready(1'b1),
    .odma_valid(odma_v), .odma_ready(odma_r),
    .o_tag(o_tag), .o_slot(o_slot), .o_row(o_row), .o_last(o_last), .o_col_mask(o_col_mask), .o_wide(o_wide),
    .o_data(o_data), .o_ovf(o_ovf), .o_clip(o_clip), .o_err(o_err),
    .cmt_done(c_cmt_done), .cmt_slot(c_cmt_slot), .cmt_tag(c_cmt_tag), .cmt_ovf(c_cmt_ovf), .cmt_clip(c_cmt_clip),
    .cmt_err(c_cmt_err), .slot_state(c_slot_state), .idle(c_idle), .err_pulse(c_err_pulse), .err_code(c_err_code),
    .err_sticky(c_err_sticky), .perf_clr(perf_clear), .ev_inc(c_ev_inc), .perf_o(acc_perf_cnt),
    .st_en(c_st_en), .st_rd_req(c_st_rd_req), .st_rd_ready(c_st_rd_ready), .st_wr_req(c_st_wr_req),
    .st_wr_ready(c_st_wr_ready));

`ifndef SYNTHESIS
  // TC04 is configured DMA-only: the other two result ports must never fire
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n && (osram_v || oquant_v)) $error("tensor_gemm_engine: unexpected TC04 SRAM/QUANT beat");
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
