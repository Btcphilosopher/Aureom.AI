// =============================================================================
// SilicaFlux TENSORCORE 06 :: ttc_sfb_master
// The controller's single SFB2 master port (DataFabric PROTOCOL.md rev 2.0) and
// the TENSORCORE 03 fill-port driver.
//
//   requesters: loader (reads of A/B words)   store (writes of C elements)
//        | round-robin, credit-checked
//        v
//   request register  -- req_valid is a flop (R3), held with a stable payload
//        |               until accepted (R2: no withdrawal)
//   SFB2 master port  --> memory / DataFabric crossbar
//        |  outstanding FIFO: one record per ACCEPTED request (R5: one response
//        |  each, in order) -> tells a response what it answers
//   responses (rsp_ready = 1: always absorbed, R4)
//        +-- read  -> fill FIFO {TC03 address, strobe, data} -> TC03 fill port
//        +-- write -> write acknowledgement (tile_last flag, error)
//
// Credits (no response can ever be refused, so nothing can deadlock behind it):
//   out_cnt = requests granted and not yet answered        <= MAX_OUT
//   rd_cnt  = reads granted and not yet written into TC03  <= FILL_DEPTH
// A read error (rsp_error) returns rdata = 0 (R8); the word is still written to
// TC03 so the fill bookkeeping stays exact, and the error is reported.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module ttc_sfb_master #(
  parameter int MAX_OUT    = 8,          // power of two >= 2
  parameter int FILL_DEPTH = 8,          // power of two >= 2
  parameter int TOB_TAG_W  = 8,
  localparam int OW = $clog2(MAX_OUT),
  localparam int FW = $clog2(FILL_DEPTH)
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // ---------------------------------------------------------- loader reads
  input  wire logic                  rd_valid,
  input  wire logic [31:0]           rd_addr,
  input  wire logic [31:0]           rd_dst,
  input  wire logic [3:0]            rd_strb,
  output logic                       rd_gnt,
  // ---------------------------------------------------------- store writes
  input  wire logic                  wr_valid,
  input  wire logic [31:0]           wr_addr,
  input  wire logic [31:0]           wr_data,
  input  wire logic                  wr_tlast,
  output logic                       wr_gnt,
  // ---------------------------------------------------------- SFB2 master port
  output logic                       req_valid,
  input  wire logic                  req_ready,
  output logic                       req_write,
  output logic [31:0]                req_addr,
  output logic [31:0]                req_wdata,
  output logic [3:0]                 req_wstrb,
  input  wire logic                  rsp_valid,
  output logic                       rsp_ready,
  input  wire logic [31:0]           rsp_rdata,
  input  wire logic                  rsp_error,
  // ---------------------------------------------------------- TC03 fill port (Module 04 port protocol)
  output logic                       tob_req_valid,
  input  wire logic                  tob_req_ready,
  output logic                       tob_req_we,
  output logic [31:0]                tob_req_addr,
  output logic [31:0]                tob_req_wdata,
  output logic [3:0]                 tob_req_wstrb,
  output logic [TOB_TAG_W-1:0]       tob_req_tag,
  // ---------------------------------------------------------- results
  output logic                       wr_ack,          // pulse: a C write was acknowledged
  output logic                       wr_ack_tlast,
  output logic                       wr_ack_err,
  output logic                       rd_rsp_err,      // pulse: a read was answered with an error
  output logic [31:0]                rsp_addr,        // address of the transaction answered
  output logic                       idle,            // nothing in flight anywhere
  output logic                       ev_bus_stall,    // req_valid && !req_ready
  output logic                       ev_fill_write    // a TC03 fill write handshake
);
  // ---------------------------------------------------------- request register
  logic        rq_v, rq_w, rq_tl;
  logic [31:0] rq_addr, rq_data, rq_dst;
  logic [3:0]  rq_strb;
  logic        acc, can_load, rd_ok, wr_ok, pick_rd, pick_wr, rr_wr_next;
  logic [OW:0] out_cnt;
  logic [FW:0] rd_cnt;
  logic        rsp_go, fill_pop;

  assign acc      = rq_v && req_ready;
  assign can_load = !rq_v || acc;
  assign rd_ok    = rd_valid && (out_cnt < (OW+1)'(MAX_OUT)) && (rd_cnt < (FW+1)'(FILL_DEPTH));
  assign wr_ok    = wr_valid && (out_cnt < (OW+1)'(MAX_OUT));
  // round robin: rr_wr_next = 1 -> the writer wins a tie
  assign pick_wr  = can_load && wr_ok && (!rd_ok || rr_wr_next);
  assign pick_rd  = can_load && rd_ok && !pick_wr;
  assign rd_gnt   = pick_rd;
  assign wr_gnt   = pick_wr;

  assign req_valid = rq_v;
  assign req_write = rq_w;
  assign req_addr  = rq_addr;
  assign req_wdata = rq_w ? rq_data : 32'd0;
  assign req_wstrb = rq_w ? 4'hF    : 4'h0;
  assign ev_bus_stall = rq_v && !req_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rq_v <= 1'b0; rq_w <= 1'b0; rq_tl <= 1'b0; rq_addr <= '0; rq_data <= '0; rq_dst <= '0; rq_strb <= '0;
      rr_wr_next <= 1'b0;
    end else begin
      if (pick_rd) begin
        rq_v <= 1'b1; rq_w <= 1'b0; rq_tl <= 1'b0; rq_addr <= rd_addr; rq_data <= '0; rq_dst <= rd_dst; rq_strb <= rd_strb;
        rr_wr_next <= 1'b1;
      end else if (pick_wr) begin
        rq_v <= 1'b1; rq_w <= 1'b1; rq_tl <= wr_tlast; rq_addr <= wr_addr; rq_data <= wr_data; rq_dst <= '0; rq_strb <= 4'hF;
        rr_wr_next <= 1'b0;
      end else if (acc) begin
        rq_v <= 1'b0;
      end
    end
  end

  // ---------------------------------------------------------- outstanding FIFO {w, tlast, strb, dst, addr}
  localparam int RW = 1 + 1 + 4 + 32 + 32;
  logic [RW-1:0] of_head;
  logic [OW:0]   of_cnt;
  dma_fifo #(.WIDTH(RW), .DEPTH(MAX_OUT)) u_of (
    .clk(clk), .rst_n(rst_n), .clr(1'b0), .push(acc), .wdata({rq_w, rq_tl, rq_strb, rq_dst, rq_addr}),
    .pop(rsp_go), .rdata(of_head), .count(of_cnt));

  logic        h_w, h_tl;
  logic [3:0]  h_strb;
  logic [31:0] h_dst, h_addr;
  assign {h_w, h_tl, h_strb, h_dst, h_addr} = of_head;

  assign rsp_ready = 1'b1;
  assign rsp_go    = rsp_valid;                // a response is always absorbed (credits)

  assign wr_ack       = rsp_go && h_w;
  assign wr_ack_tlast = h_tl;
  assign wr_ack_err   = rsp_error;
  assign rd_rsp_err   = rsp_go && !h_w && rsp_error;
  assign rsp_addr     = h_addr;

  // ---------------------------------------------------------- fill FIFO {dst, strb, data}
  localparam int FWID = 32 + 4 + 32;
  logic [FWID-1:0] ff_head;
  logic [FW:0]     ff_cnt;
  logic            ff_push;
  assign ff_push = rsp_go && !h_w;
  dma_fifo #(.WIDTH(FWID), .DEPTH(FILL_DEPTH)) u_ff (
    .clk(clk), .rst_n(rst_n), .clr(1'b0), .push(ff_push),
    .wdata({h_dst, h_strb, rsp_error ? 32'd0 : rsp_rdata}),
    .pop(fill_pop), .rdata(ff_head), .count(ff_cnt));

  logic [TOB_TAG_W-1:0] tag_q;
  assign tob_req_valid = (ff_cnt != '0);
  assign tob_req_we    = 1'b1;
  assign {tob_req_addr, tob_req_wstrb, tob_req_wdata} = ff_head;
  assign tob_req_tag   = tag_q;
  assign fill_pop      = tob_req_valid && tob_req_ready;
  assign ev_fill_write = fill_pop;

  // ---------------------------------------------------------- credit counters
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      out_cnt <= '0; rd_cnt <= '0; tag_q <= '0;
    end else begin
      out_cnt <= out_cnt + (OW+1)'(pick_rd || pick_wr) - (OW+1)'(rsp_go);
      rd_cnt  <= rd_cnt  + (FW+1)'(pick_rd) - (FW+1)'(fill_pop);
      if (fill_pop) tag_q <= tag_q + TOB_TAG_W'(1);
    end
  end

  assign idle = !rq_v && (out_cnt == '0) && (rd_cnt == '0);

`ifndef SYNTHESIS
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n) begin
    if (rsp_valid && of_cnt == '0) $error("ttc_sfb_master: unsolicited SFB2 response");
    if (ff_push && ff_cnt == (FW+1)'(FILL_DEPTH) && !fill_pop) $error("ttc_sfb_master: fill FIFO overflow");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
