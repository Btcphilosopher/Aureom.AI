// =============================================================================
// SilicaFlux TENSORCORE 06 :: ttc_defs.svh
// Constants of the tensor tile controller (tensor_tile_controller).
//
// A `define header, not a package, following TENSORCORE 03 / Module 05: Yosys
// 0.33 cannot resolve package references in module parameter lists, and every
// synthesizable module here must elaborate unaided in Verilator 5.020,
// Icarus 12 and Yosys 0.33.
//
// Values are part of the public contract: never renumber, only append.
// =============================================================================
`ifndef TTC_DEFS_SVH
`define TTC_DEFS_SVH

// ------------------------------------------------------------ command field encodings
// layout (cmd_a_layout / cmd_b_layout / cmd_c_layout, 2 bits)
`define TTC_LAYOUT_ROW   2'd0   // row-major: X[r][c] at base + r*ld + c*elem      (the only supported layout)
`define TTC_LAYOUT_COL   2'd1   // column-major (= transposed operand): REJECTED, never silently transposed
// 2, 3 reserved: rejected

// element type (cmd_a_type / cmd_b_type / cmd_c_type, 2 bits)
`define TTC_TYPE_INT8    2'd0   // A, B: signed two's-complement 8-bit (the only supported operand type)
`define TTC_TYPE_INT32   2'd0   // C: signed 32-bit, little-endian, naturally aligned (the only supported C type)
// any other code: rejected

// flags (cmd_flags, 8 bits)
`define TTC_FL_OVERLAP   0      // 1: decoupled prefetch (load step s+1 while step s computes), deferred retire
`define TTC_FL_REUSE     1      // 1: skip the DMA of an operand block already resident in the target set
`define TTC_FL_NMAJOR    2      // 0: M-major traversal (mt outer, nt inner); 1: N-major (nt outer, mt inner)
`define TTC_FL_MASK      8'h07  // bits 3..7 reserved: must be 0

// ------------------------------------------------------------ completion codes (cpl_code, 5 bits)
// 1..11: command validation, first failing rule wins, NO side effect (no bus access,
//        no subsystem command).  16..18: execution errors; the controller drains
//        every in-flight operation, then completes with the code.  24, 25: fatal;
//        the completion is produced, then the controller halts until reset.
`define TTC_OK              5'd0
`define TTC_ERR_FLAGS       5'd1   // reserved flag bit set
`define TTC_ERR_LAYOUT      5'd2   // A, B or C layout not row-major
`define TTC_ERR_DTYPE       5'd3   // A/B not INT8 or C not INT32
`define TTC_ERR_DIM_ZERO    5'd4   // M, N or K is 0
`define TTC_ERR_DIM_RANGE   5'd5   // M or N > 65535, K > K_MAX (131 071: largest overflow-free INT8->INT32 reduction)
`define TTC_ERR_CHUNK       5'd6   // cmd_kc > TILE_K, or ceil(K/kc) > 65535 chunks (TC04 CHUNK_W)
`define TTC_ERR_LD          5'd7   // lda < K, ldb < N or ldc < 4*N (rows would overlap)
`define TTC_ERR_ALIGN       5'd8   // c_base or ldc not a multiple of 4 (INT32 natural alignment)
`define TTC_ERR_ADDR_OVF    5'd9   // last byte of A, B or C >= 2^32 (would wrap)
`define TTC_ERR_RANGE       5'd10  // a matrix footprint leaves the memory window [MEM_LO, MEM_HI)
`define TTC_ERR_ALIAS       5'd11  // C footprint intersects the A or B footprint
`define TTC_ERR_BUS_READ    5'd16  // an SFB2 read was answered with an error (cpl_err_addr = word address)
`define TTC_ERR_BUS_WRITE   5'd17  // an SFB2 write was answered with an error (cpl_err_addr = word address)
`define TTC_ERR_ACC_OVF     5'd18  // TC04 flagged an accumulation overflow (unreachable after validation)
`define TTC_ERR_INTERNAL    5'd24  // a subsystem refused something the controller generated (cpl_err_addr = TTC_IE_*)
`define TTC_ERR_WATCHDOG    5'd25  // no progress for 2^WDOG_LOG2 cycles

// internal-error sub-codes (cpl_err_addr[7:0] with TTC_ERR_INTERNAL)
`define TTC_IE_FILL_RSP     8'd1   // TC03 fill port answered an error
`define TTC_IE_TILE_RSP     8'd2   // TC03 rejected a tile descriptor
`define TTC_IE_ARR_REJECT   8'd3   // TC02 rejected a launch
`define TTC_IE_ARR_ALIGN    8'd4   // TC02 alignment checker fired
`define TTC_IE_ACC_REJECT   8'd5   // TC04 rejected a tile configuration
`define TTC_IE_ACC_BEAT     8'd6   // TC04 dropped a partial-sum beat as malformed / flagged o_err
`define TTC_IE_SLICE_K      8'd7   // slice index from TC03 != index the array expects
`define TTC_IE_GEOM         8'd8   // TC03 tile response geometry != the controller's iterator
`define TTC_IE_GUARD_RD     8'd9   // a generated read address left the validated A/B footprint
`define TTC_IE_GUARD_WR     8'd10  // a generated write address left the validated C footprint
`define TTC_IE_OUT_TAG      8'd11  // TC04 output beat for an unexpected tile
`define TTC_IE_MAC          8'd12  // array MAC count != eff_m*eff_n*eff_k of the launch
`define TTC_IE_MERGE        8'd13  // merged-chunk count != launched-chunk count at completion

// ------------------------------------------------------------ scheduler FSM (state_o, 4 bits)
`define TTC_S_IDLE        4'd0    // waiting for a command
`define TTC_S_VALIDATE    4'd1    // checking the command (multi-cycle: products, chunk count)
`define TTC_S_RESERVE     4'd2    // first K chunk of an output tile: open a TC04 accumulator slot
`define TTC_S_INIT        4'd3    // partial-sum initialisation check (TC04: first chunk initialises, no clear pass)
`define TTC_S_LOAD        4'd4    // operands of this step: wait until the loader has filled a set; cmp_begin
`define TTC_S_TILE        4'd5    // COMPUTE (a): describe the loaded block to TC03, take its tile response
`define TTC_S_ACCUMULATE  4'd6    // wait until the previous launch has finished on the array and merged in TC04
`define TTC_S_LAUNCH      4'd7    // COMPUTE (b): launch the array with the tile response geometry
`define TTC_S_COMPUTE     4'd8    // COMPUTE (c): slices streaming; after the last slice, release the set (cmp_end)
`define TTC_S_STORE       4'd9    // wait until every reserved tile has all C elements written and acknowledged
`define TTC_S_COMPLETE    4'd10   // completion record (OK or execution error)
`define TTC_S_ERROR       4'd11   // fatal error: completion record, then HALT
`define TTC_S_HALT        4'd12   // halted after a fatal error; only reset leaves it

// ------------------------------------------------------------ loader FSM (ld_state_o, 3 bits)
`define TTC_L_IDLE        3'd0
`define TTC_L_PLAN        3'd1    // block geometry, local layout, reuse decision
`define TTC_L_BEGIN       3'd2    // fill_begin on TC03's fill set
`define TTC_L_A           3'd3    // A block rows -> word reads
`define TTC_L_B           3'd4    // B block rows -> word reads
`define TTC_L_WAIT        3'd5    // every fill write of the step acknowledged by TC03
`define TTC_L_END         3'd6    // fill_end
`define TTC_L_DONE        3'd7    // every step of the command loaded

// ------------------------------------------------------------ performance counters (perf_cnt, CNT_W each)
`define TTC_PC_BUSY          0    // cycles not IDLE / HALT
`define TTC_PC_GEMM_OK       1    // commands completed with TTC_OK
`define TTC_PC_GEMM_ERR      2    // commands completed with any error
`define TTC_PC_TILES         3    // output tiles completed (every C element written and acknowledged)
`define TTC_PC_CHUNKS        4    // array launches (K chunks executed)
`define TTC_PC_MAC_USEFUL    5    // useful MACs, from the array's own perf_mac at each readout
`define TTC_PC_MAC_PAD       6    // padded PE slots, from the array's perf_pad (R*C - eff_m*eff_n per slice)
`define TTC_PC_COMPUTE_CYC   7    // cycles the array is busy computing (CLEAR/RUN/DRAIN, not READOUT)
`define TTC_PC_ISSUE_CYC     8    // cycles with a k-slice handshake into the array
`define TTC_PC_DMA_WAIT      9    // cycles the scheduler waited in LOAD for operands (cmp_begin not ready)
`define TTC_PC_STARVE       10    // operand starvation inside a tile (TC03 EV_STARVE)
`define TTC_PC_OUT_STALL    11    // cycles a C write of the store path was pending and not granted (bus busy / back-pressure / arbitration)
`define TTC_PC_BUF_SWITCH   12    // buffer switch events: cmp_begin onto a different set than the previous step
`define TTC_PC_A_LOADS      13    // A blocks moved by DMA
`define TTC_PC_B_LOADS      14    // B blocks moved by DMA
`define TTC_PC_A_REUSE      15    // A block DMAs skipped: block already resident in the set
`define TTC_PC_B_REUSE      16    // B block DMAs skipped
`define TTC_PC_RD_WORDS     17    // SFB2 read transactions (4 bytes each)
`define TTC_PC_FILL_BYTES   18    // operand bytes written into TC03 (strobed bytes)
`define TTC_PC_WR_WORDS     19    // SFB2 write transactions (one INT32 C element each)
`define TTC_PC_ACC_WAIT     20    // cycles RESERVE waited for a free accumulator slot / tile-info entry
`define TTC_PC_ARRAY_WAIT   21    // cycles ACCUMULATE waited for the previous launch to finish and merge
`define TTC_PC_OVERLAP      22    // cycles with a TC03 fill write AND a k-slice handshake (TC03 EV_OVERLAP)
`define TTC_PC_BUS_STALL    23    // cycles a presented SFB2 request was not accepted (req_valid && !req_ready)
`define TTC_NUM_PC          24

`endif // TTC_DEFS_SVH
