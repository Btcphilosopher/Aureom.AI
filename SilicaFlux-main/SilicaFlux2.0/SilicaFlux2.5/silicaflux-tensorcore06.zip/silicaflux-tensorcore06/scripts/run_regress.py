#!/usr/bin/env python3
"""TENSORCORE 06 staged regression.

Stages run strictly in order, a failing stage stops the run (the brief: one tile and one K
chunk first, then many K chunks, then arbitrary M/N tiling, then the system tests):
  stage 1  one output tile, one K chunk        (all hardware configurations)
  stage 2  one output tile, many K chunks
  stage 3  arbitrary M/N tiling with K chunks  (5x7x3, 17x13x29, ...)
  stage 4  boundary masks, strides, back-pressure, latency, reset, invalid commands,
           consecutive GEMMs, bus errors, watchdog, numeric extreme, large GEMMs
Every run is checked three ways: the testbench's own result (completion records, bus
bounds, whole-memory comparison with the Python reference), the completion records
re-checked here against meta.json, and the performance counters against the
analytical model (model/ttc_ref.py: tiles, chunks, MACs, padded slots, block loads,
reuse hits, SFB2 read words, fill bytes, C writes).
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
from common import BUILD, REPORTS, ROOT, build, parse, run, simulate, tool_versions  # noqa: E402
import gen_tests  # noqa: E402

SEEDS = {"ideal": [1], "jitter": [1, 2], "slow": [3], "vary": [4, 5], "heavy": [6, 7], "xbar": [8]}


def perf_checks(meta: dict, d: dict) -> list[str]:
    """Counters vs the analytical model; only for runs whose counters were never reset."""
    cmds = meta["cmds"]
    if any(c["rst_at"] for c in cmds) or any(c["code"] >= 24 for c in cmds):
        return []
    ok_like = [c for c in cmds if c["code"] in (0, 16, 17)]
    p = d["perf"]
    cfg = meta["cfg"]
    tm, tn = cfg["TM"], cfg["TN"]
    exp = dict(
        GEMM_OK=sum(1 for c in cmds if c["code"] == 0),
        GEMM_ERR=sum(1 for c in cmds if c["code"] != 0),
        TILES=sum(c["tiles"] for c in ok_like),
        CHUNKS=sum(c["chunks"] for c in ok_like),
        MAC_USEFUL=sum(c["macs"] for c in ok_like),
        MAC_PAD=sum(c["pad"] for c in ok_like),
        ISSUE_CYC=sum(-(-c["m"] // tm) * -(-c["n"] // tn) * c["k"] for c in ok_like),
        WR_WORDS=sum(c["m"] * c["n"] for c in ok_like),
        A_LOADS=sum(c["traffic"]["a_loads"] for c in ok_like),
        B_LOADS=sum(c["traffic"]["b_loads"] for c in ok_like),
        A_REUSE=sum(c["traffic"]["a_reuse"] for c in ok_like),
        B_REUSE=sum(c["traffic"]["b_reuse"] for c in ok_like),
        RD_WORDS=sum(c["traffic"]["rd_words"] for c in ok_like),
        FILL_BYTES=sum(c["traffic"]["fill_bytes"] for c in ok_like),
    )
    bad = [f"perf {k}: measured {p.get(k)} != model {v}" for k, v in exp.items() if p.get(k) != v]
    # TC03's own counters: one accepted tile per chunk, slices = issue cycles; TC04: one commit per tile
    if d["tob"].get(17) != exp["CHUNKS"]:
        bad.append(f"TC03 TILE_OK {d['tob'].get(17)} != chunks {exp['CHUNKS']}")
    if d["tob"].get(2) != exp["ISSUE_CYC"]:
        bad.append(f"TC03 SLICES {d['tob'].get(2)} != {exp['ISSUE_CYC']}")
    if d["acc"].get(9) != exp["TILES"]:
        bad.append(f"TC04 COMMIT_TILES {d['acc'].get(9)} != {exp['TILES']}")
    if d["acc"].get(10) != exp["CHUNKS"]:
        bad.append(f"TC04 CHUNKS {d['acc'].get(10)} != {exp['CHUNKS']}")
    if p.get("STARVE") != d["tob"].get(3):
        bad.append("STARVE counter != TC03 STARVE counter")
    return bad


def cpl_checks(meta: dict, d: dict) -> list[str]:
    bad = []
    if len(d["cpl"]) != len(meta["cmds"]):
        return [f"{len(d['cpl'])} completions for {len(meta['cmds'])} commands"]
    for c, r in zip(meta["cmds"], d["cpl"]):
        if r["code"] != c["code"]:
            bad.append(f"cmd {r['idx']}: code {r['code']} != {c['code']}")
        if c["code"] in (0, 16, 17) and (r["tiles"] != c["tiles"] or r["chunks"] != c["chunks"]):
            bad.append(f"cmd {r['idx']}: tiles/chunks {r['tiles']}/{r['chunks']} != {c['tiles']}/{c['chunks']}")
        if 0 < c["code"] < 16 and r["bus"] != 0:
            bad.append(f"cmd {r['idx']}: rejected command used the bus")
    return bad


def one(job, timeout=7200):
    sim, t, prof, seed, exe = job
    plus = dict(gen_tests.PROFILES[prof], dir=t["dir"], seed=seed, **t["plus"])
    t0 = time.time()
    try:
        rc, log = simulate(sim, exe, plus, timeout=timeout)
    except Exception as e:  # noqa: BLE001
        rc, log = -1, f"EXCEPTION {e}"
    dt = time.time() - t0
    d = parse(log)
    meta = json.loads((Path(t["dir"]) / "meta.json").read_text())
    reasons = []
    if d["result"] != "PASS":
        reasons.append("testbench: " + (d["errors"][0] if d["errors"] else f"no RESULT line (rc={rc})"))
    if d["assertions"]:
        reasons.append("RTL assertion: " + d["assertions"][0])
    reasons += cpl_checks(meta, d)
    reasons += perf_checks(meta, d)
    name = f"{sim}:{t['config']}:{t['name']}:{prof}:s{seed}"
    logdir = BUILD / "logs"
    logdir.mkdir(parents=True, exist_ok=True)
    (logdir / (name.replace(":", "__") + ".log")).write_text(log)
    return dict(name=name, sim=sim, config=t["config"], test=t["name"], stage=t["stage"], profile=prof, seed=seed,
                ok=not reasons, reasons=reasons[:5], secs=round(dt, 1),
                cycles=d["stats"].get("cycles"), c_bytes=d["stats"].get("c_bytes"),
                bytes_checked=d["stats"].get("bytes_checked"), ncmd=len(meta["cmds"]),
                perf=d["perf"], cpl=d["cpl"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", default="1,2,3,4")
    ap.add_argument("--sims", default="verilator,icarus")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--tests", default="")
    ap.add_argument("--configs", default="")
    ap.add_argument("--out", default="regression")
    a = ap.parse_args()
    tests = gen_tests.generate(BUILD / "tests")
    stages = [int(s) for s in a.stages.split(",")]
    sims = a.sims.split(",")
    sel_t = set(a.tests.split(",")) if a.tests else None
    sel_c = set(a.configs.split(",")) if a.configs else None
    results, builds = [], {}
    t_start = time.time()
    for stage in stages:
        jobs = []
        for t in tests:
            if t["stage"] != stage or (sel_t and t["name"] not in sel_t) or (sel_c and t["config"] not in sel_c):
                continue
            for sim in sims:
                if t["sims"] != "both" and t["sims"] != sim:
                    continue
                cfg = gen_tests.CONFIGS[t["config"]]
                key = (sim, t["config"])
                if key not in builds:
                    exe, log = build(sim, cfg)
                    if exe is None:
                        print(log[-3000:])
                        sys.exit(f"build failed: {key}")
                    builds[key] = exe
                for prof in t["profiles"]:
                    for seed in SEEDS[prof]:
                        jobs.append((sim, t, prof, seed, builds[key]))
        with ThreadPoolExecutor(a.jobs) as ex:
            res = list(ex.map(one, jobs))
        results += res
        npass = sum(r["ok"] for r in res)
        print(f"stage {stage}: {npass}/{len(res)} runs pass")
        for r in res:
            if not r["ok"]:
                print("  FAIL", r["name"], r["reasons"])
        if npass != len(res):
            print(f"stage {stage} failed: later stages not run")
            break
    # cross-simulator comparison: identical completion records (codes, tiles, chunks, cycle counts)
    cross = []
    by = {}
    for r in results:
        by.setdefault((r["config"], r["test"], r["profile"], r["seed"]), {})[r["sim"]] = r
    for k, v in sorted(by.items()):
        if "icarus" in v and "verilator" in v:
            same = v["icarus"]["cpl"] == v["verilator"]["cpl"] and v["icarus"]["perf"] == v["verilator"]["perf"]
            cross.append(dict(key=":".join(map(str, k)), identical=same))
    REPORTS.mkdir(exist_ok=True)
    summary = dict(tools=tool_versions(), seconds=round(time.time() - t_start), runs=len(results),
                   passed=sum(r["ok"] for r in results), cross=cross, results=results)
    (REPORTS / f"{a.out}.json").write_text(json.dumps(summary, indent=1))
    write_md(summary, REPORTS / f"{a.out}.md")
    print(f"total: {summary['passed']}/{summary['runs']} runs pass; cross-sim identical "
          f"{sum(c['identical'] for c in cross)}/{len(cross)}")
    sys.exit(0 if summary["passed"] == summary["runs"] and all(c["identical"] for c in cross) else 1)


def write_md(s: dict, path: Path):
    L = ["# Regression summary", "", "Generated by `scripts/run_regress.py` from the final run on these sources.", "",
         "Tools: " + ", ".join(f"{k} `{v}`" for k, v in s["tools"].items()), "",
         f"**{s['passed']} / {s['runs']} runs pass** ({s['seconds']} s wall clock, 4 jobs). "
         f"Cross-simulator (Icarus vs Verilator, same seed): **{sum(c['identical'] for c in s['cross'])} / "
         f"{len(s['cross'])}** runs with identical completion records (incl. cycle counts) and identical counters.", "",
         "Each run: every completion record checked; every SFB2 transaction checked against the command's element "
         "map; every C element written exactly once; the whole 1 MiB memory compared with the Python reference "
         "(C elements) or its initial content (everything else); counters checked against the analytical model.", ""]
    stages = sorted({r["stage"] for r in s["results"]})
    names = {1: "Stage 1: one tile, one K chunk", 2: "Stage 2: one tile, many K chunks",
             3: "Stage 3: arbitrary M/N tiling + K chunks", 4: "Stage 4: system tests"}
    for st in stages:
        rs = [r for r in s["results"] if r["stage"] == st]
        L += [f"## {names[st]}", "", "| test | config | sim | profile | seeds | GEMMs | C elements | cycles (max) | result |",
              "|---|---|---|---|---|---|---|---|---|"]
        grp = {}
        for r in rs:
            grp.setdefault((r["test"], r["config"], r["sim"], r["profile"]), []).append(r)
        for (t, c, sim, p), g in sorted(grp.items()):
            ok = all(x["ok"] for x in g)
            L.append(f"| {t} | {c} | {sim} | {p} | {len(g)} | {g[0]['ncmd']} | {(g[0]['c_bytes'] or 0) // 4} | "
                     f"{max((x['cycles'] or 0) for x in g)} | {'PASS' if ok else 'FAIL: ' + '; '.join(g[0]['reasons'])} |")
        L.append("")
    path.write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    main()
