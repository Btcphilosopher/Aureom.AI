#!/usr/bin/env python3
"""Fill README.md from scripts/readme_template.md with numbers taken from the generated reports (nothing typed by hand)."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
R = ROOT / "reports"


def main():
    reg = json.loads((R / "regression.json").read_text())
    res = reg["results"]
    sub = {}
    for st in (1, 2, 3, 4):
        rs = [r for r in res if r["stage"] == st]
        sub[f"__S{st}__"] = f"{sum(r['ok'] for r in rs)} / {len(rs)} runs pass"
    cr = reg["cross"]
    sub["__CROSS__"] = f"{sum(c['identical'] for c in cr)} / {len(cr)} run pairs identical"
    sub["__GEMMS__"] = f"{sum(r['ncmd'] for r in res):,}"
    sub["__CELEMS__"] = f"{sum((r['c_bytes'] or 0) // 4 for r in res):,}"
    mut = json.loads((R / "mutation.json").read_text())
    eq = re.search(r"(\d+) survivors analysed as behaviourally equivalent; (\d+) unexplained", (R / "mutation.md").read_text())
    sub["__MUT__"] = (f"{sum(m['killed'] for m in mut)} / {len(mut)} killed; {eq[1]} survivors analysed as equivalent "
                      f"(redundant interlocks / schedule-only), {eq[2]} unexplained")
    perf = json.loads((R / "perf.json").read_text())["runs"]
    sub["__PERF__"] = f"{sum(p['ok'] and p['model_ok'] for p in perf)} / {len(perf)}"
    lint = (R / "lint.md").read_text()
    sub["__LINT__"] = re.search(r"\*\*(\d+ / \d+) checks pass", lint)[1] + " checks pass"
    synth = (R / "synth.md").read_text()
    sub["__SYNTH__"] = f"{synth.count('| OK |')} / 4 runs OK"
    by = {(p["hw"], p["m"], p["n"], p["k"], p["flags"], p["bus"]): p for p in perf}

    def cyc(hw, s, f, b="ideal"):
        return by[(hw, *s, f, b)]["cycles"]

    def util(hw, s, f, b="ideal"):
        p = by[(hw, *s, f, b)]
        return 100.0 * p["perf"]["MAC_USEFUL"] / (p["cycles"] * p["R"] * p["C"])

    s1, s2, s3 = (32, 32, 256), (64, 16, 64), (17, 13, 29)
    H = ["| measurement (4×4 array, 1-cycle memory unless stated) | value |", "|---|---|",
         f"| 32×32×256 (64 tiles × 4 chunks): serial → overlap with two sets | {cyc('base', s1, 0)} → {cyc('base', s1, 1)} cycles "
         f"(**{cyc('base', s1, 0) / cyc('base', s1, 1):.2f}×**); one set with overlap: {cyc('single', s1, 1)} |",
         f"| array utilisation 32×32×256, serial / overlap | {util('base', s1, 0):.1f} % / {util('base', s1, 1):.1f} % "
         f"(bus bound ≈ 50 %: 2 operand words per slice, 1 word per cycle) |",
         f"| 64×16×64, overlap → overlap + reuse + N-major (B reused across 16 M tiles) | {cyc('base', s2, 1)} → {cyc('base', s2, 7)} cycles, "
         f"U {util('base', s2, 1):.1f} % → **{util('base', s2, 7):.1f} %** |",
         f"| 17×13×29 (20 boundary-heavy tiles), serial → overlap + reuse + N-major | {cyc('base', s3, 0)} → {cyc('base', s3, 7)} cycles |",
         f"| 32×32×256 with an 8-cycle memory, serial → overlap | {cyc('base', s1, 0, 'lat8')} → {cyc('base', s1, 1, 'lat8')} cycles |",
         f"| 32×32×256 behind a crossbar-R6 memory (1 transaction in flight, 4-cycle latency), serial → overlap | "
         f"{cyc('base', s1, 0, 'xbar4')} → {cyc('base', s1, 1, 'xbar4')} cycles |",
         f"| A_PAD (odd-word A rows in the buffer), 32×32×256: operand starvation cycles | "
         f"{by[('base_nopad', *s1, 3, 'ideal')]['perf']['STARVE']} → {by[('base', *s1, 3, 'ideal')]['perf']['STARVE']} |",
         "| validation latency (every rejected command) | 21 cycles, zero bus transactions |"]
    sub["__HEADLINE__"] = "\n".join(H)
    t = (ROOT / "scripts/readme_template.md").read_text()
    for k, v in sub.items():
        t = t.replace(k, v)
    assert "__" not in re.sub(r"`[^`]*`", "", t).replace("__init__", ""), "unfilled placeholder"
    (ROOT / "README.md").write_text(t)
    print("README.md written")


if __name__ == "__main__":
    main()
