#!/usr/bin/env python3
"""TENSORCORE 06 mutation testing: is the regression sensitive to realistic controller bugs?

Each mutant is one textual change to a copy of the NEW RTL (third-party RTL untouched). It is built with
Verilator for two configurations (base, stress) and run against a subset of the regression (stages 1-3 plus
boundary, strides, multi-GEMM and invalid commands; ideal and jittered timing). A mutant is KILLED if any run
fails any check (testbench, completion records, counters vs model, RTL assertions). Writes reports/mutation.md.
"""
from __future__ import annotations

import json
import shutil
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
import common  # noqa: E402
from common import BUILD, REPORTS, ROOT  # noqa: E402
import gen_tests  # noqa: E402
import run_regress  # noqa: E402

MUTANTS = [
    ("M01", "rtl/ttc_loader.sv", "(2'(b) >= lo_b) && (2'(b) <= hi_b)", "(2'(b) >= lo_b) && (2'(b) < hi_b)",
     "fill strobe drops the last byte of a row segment"),
    ("M02", "rtl/ttc_loader.sv", "lda_loc_c = it_eff_k + 17'(pa_c);", "lda_loc_c = it_eff_k;",
     "local A stride ignores the source residue (rows land at the wrong byte lanes)"),
    ("M03", "rtl/ttc_tile_iter.sv", "assign eff_k = last_k ? (k - k0)    : kc;", "assign eff_k = kc;",
     "last K chunk not shortened (reads/computes beyond K)"),
    ("M04", "rtl/ttc_tile_iter.sv", "assign last_m = (m_end >= 17'(m));", "assign last_m = (m_end > 17'(m));",
     "M boundary off by one (an extra empty tile row)"),
    ("M05", "rtl/tensor_tile_controller.sv", "assign retire_ok = !launch_pend && (merged == launched);",
     "assign retire_ok = 1'b1;", "ACCUMULATE does not wait for the array / merge (guessed completion)"),
    ("M06", "rtl/tensor_tile_controller.sv", "acc_ps_chunk   <= ex_kidx;", "acc_ps_chunk   <= '0;",
     "every launch tagged as chunk 0 (partial sums not merged correctly)"),
    ("M07", "rtl/ttc_loader.sv", "for (int s = 0; s < NUM_SETS; s++) begin resA_v[s] <= 1'b0; resB_v[s] <= 1'b0; end",
     "", "residency not invalidated at a new command (stale operands reused)"),
    ("M08", "rtl/ttc_store.sv", "assign row_off   = 32'(o_row) * ldc;", "assign row_off   = 32'(o_row) * 32'(4 * TILE_N);",
     "C row stride ignores ldc (dense stride assumed)"),
    ("M09", "rtl/ttc_loader.sv", "`TTC_L_WAIT: if (issued == acked) st <= `TTC_L_END;", "`TTC_L_WAIT: st <= `TTC_L_END;",
     "fill_end before every buffer write is acknowledged"),
    ("M10", "rtl/ttc_validate.sv", "else if (lda < k || ldb < n || 34'(ldc) < {n, 2'b00})", "else if (1'b0)",
     "leading-dimension rule removed"),
    ("M11", "rtl/tensor_tile_controller.sv", "assign store_done_c = (tiles_done == tiles_res);",
     "assign store_done_c = 1'b1;", "completion before the C writes are acknowledged"),
    ("M12", "rtl/ttc_loader.sv", "dp    <= dp + ld_loc;", "dp    <= dp + ld_src;",
     "local row pointer advances by the memory stride"),
    ("M13", "rtl/ttc_validate.sv", "else if ((64'(c_base) <= al && 64'(a_base) <= cl) ||", "else if (1'b0 &&",
     "C-over-A alias rule removed"),
    ("M14", "rtl/ttc_store.sv", "assign o_ready   = go && last_lane;", "assign o_ready   = go;",
     "only the first column of each committed row is written"),
    ("M15", "rtl/tensor_tile_controller.sv", "assign ld_permit = ovl || ((st == `TTC_S_LOAD) && (ld_step == ex_step));",
     "assign ld_permit = 1'b1;", "serial mode loses its load/compute serialisation (schedule only)"),
    ("M16", "rtl/ttc_loader.sv", "reuse_a_c = reuse && resA_v[fill_set] && resA_m0[fill_set] == it_m0 && resA_k0[fill_set] == it_k0;",
     "reuse_a_c = reuse && resA_v[fill_set] && resA_m0[fill_set] == it_m0;",
     "A residency tag ignores k0 (wrong chunk reused)"),
]
# Survivors are analysed, not ignored: why no observable behaviour changes.
EQUIVALENT = {
    "M05": "equivalent: TC02 raises cfg_ready only in IDLE, i.e. after its readout's last beat, so LAUNCH is held until "
           "the previous launch has finished even without ACCUMULATE's wait; TC04 orders the merge itself. The explicit "
           "retire is a redundant interlock (kept: it makes ACCUMULATE reflect real completion, feeds ARRAY_WAIT and "
           "the MERGE check).",
    "M11": "equivalent: the final completion also requires bus_idle (every write acknowledged) and an empty tile FIFO "
           "(every reserved tile's rows issued), which together imply every C element is acknowledged; in serial mode "
           "the next tile merely starts earlier. Redundant interlock.",
    "M15": "schedule-only: serial mode then prefetches like overlap mode; TC03 ownership (fill only an EMPTY set) keeps "
           "it correct, so results are identical by design. Only timing changes, which the regression does not pin.",
}
TESTS = ["stage1", "stage2", "stage3", "boundary", "strides", "multi", "invalid"]
CFGS = ["base", "stress"]


def mutate(mid, path, old, new):
    d = BUILD / "mut" / mid
    if d.exists():
        shutil.rmtree(d)
    shutil.copytree(ROOT / "rtl", d / "rtl")
    shutil.copytree(ROOT / "tb", d / "tb")
    shutil.copytree(ROOT / "third_party", d / "third_party")
    f = d / path
    s = f.read_text()
    assert s.count(old) == 1, (mid, old)
    f.write_text(s.replace(old, new))
    return d


def run_mutant(m):
    mid, path, old, new, desc = m
    d = mutate(mid, path, old, new)
    res = []
    tests = json.loads((BUILD / "tests/manifest.json").read_text())["tests"]
    for cn in CFGS:
        exe, log = common.build("verilator", gen_tests.CONFIGS[cn], root=d)   # built inside the mutant's tree
        if exe is None:
            return dict(id=mid, desc=desc, killed=True, by="build failed")
        for t in tests:
            if t["config"] != cn or t["name"] not in TESTS:
                continue
            for prof in t["profiles"]:
                r = run_regress.one(("verilator", t, prof, run_regress.SEEDS[prof][0], exe), timeout=300)
                res.append(r)
                if not r["ok"]:
                    return dict(id=mid, desc=desc, killed=True, by=f"{t['name']}/{cn}/{prof}: {r['reasons'][0][:140]}")
    return dict(id=mid, desc=desc, killed=False, by=f"survived {len(res)} runs")


def main():
    if "--report-only" in sys.argv:            # rebuild reports/mutation.md from reports/mutation.json
        out = json.loads((REPORTS / "mutation.json").read_text())
    else:
        gen_tests.generate(BUILD / "tests")
        run_regress.BUILD = BUILD / "mut"      # mutant run logs go to build/mut/logs, not over the regression's
        with ThreadPoolExecutor(2) as ex:
            out = list(ex.map(run_mutant, MUTANTS))
    k = sum(o["killed"] for o in out)
    L = ["# Mutation testing", "", "Generated by `scripts/run_mutants.py`. Each mutant is one deliberate bug in a copy "
         "of the new RTL; it is killed when any regression check fails (subset: stages 1-3, boundary, strides, "
         "multi-GEMM, invalid; configurations base and stress; ideal and jittered timing; Verilator).", "",
         f"**{k} / {len(out)} mutants killed.** "
         f"{sum(1 for o in out if not o['killed'] and o['id'] in EQUIVALENT)} survivors analysed as behaviourally "
         f"equivalent; {sum(1 for o in out if not o['killed'] and o['id'] not in EQUIVALENT)} unexplained.", "",
         "| id | injected bug | result | first failing check / analysis |",
         "|---|---|---|---|"]
    for o in out:
        L.append(f"| {o['id']} | {o['desc']} | {'killed' if o['killed'] else '**survived**'} | "
                 f"{o['by'] if o['killed'] else o['by'] + '. ' + EQUIVALENT.get(o['id'], '**not analysed**')} |")
    REPORTS.mkdir(exist_ok=True)
    (REPORTS / "mutation.md").write_text("\n".join(L) + "\n")
    (REPORTS / "mutation.json").write_text(json.dumps(out, indent=1))
    print(f"{k}/{len(out)} mutants killed")
    for o in out:
        print(o["id"], "killed" if o["killed"] else "SURVIVED", o["by"])


if __name__ == "__main__":
    main()
