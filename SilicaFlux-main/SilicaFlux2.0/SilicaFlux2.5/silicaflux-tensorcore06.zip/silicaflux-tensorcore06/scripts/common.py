"""Shared helpers for the TENSORCORE 06 scripts: file lists, builds, runs, log parsing."""
from __future__ import annotations

import hashlib
import os
import re
import subprocess
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
REPORTS = ROOT / "reports"
FILES_F = ROOT / "rtl/files.f"
TB = ROOT / "tb/tb_gemm.sv"
DEFINES = ["TOB_ASSERT", "SRAMLIB_ASSERT", "SRAMLIB_POISON"]
NEW_RTL = ["rtl/ttc_validate.sv", "rtl/ttc_tile_iter.sv", "rtl/ttc_loader.sv", "rtl/ttc_store.sv",
           "rtl/ttc_sfb_master.sv", "rtl/ttc_perf.sv", "rtl/tensor_tile_controller.sv", "rtl/tensor_gemm_engine.sv"]

PC_NAMES = ["BUSY", "GEMM_OK", "GEMM_ERR", "TILES", "CHUNKS", "MAC_USEFUL", "MAC_PAD", "COMPUTE_CYC", "ISSUE_CYC",
            "DMA_WAIT", "STARVE", "OUT_STALL", "BUF_SWITCH", "A_LOADS", "B_LOADS", "A_REUSE", "B_REUSE", "RD_WORDS",
            "FILL_BYTES", "WR_WORDS", "ACC_WAIT", "ARRAY_WAIT", "OVERLAP", "BUS_STALL"]

_lock = threading.Lock()


def run(cmd, cwd=ROOT, timeout=3600):
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
    return p.returncode, p.stdout


def cfg_key(cfg: dict) -> str:
    return "_".join(f"{k}{cfg[k]}" for k in sorted(cfg))


def source_hash(root: Path = ROOT) -> str:
    """Hash of every source that goes into a simulation build (RTL, third-party RTL, testbench, headers)."""
    h = hashlib.sha1()
    for p in sorted(list((root / "rtl").glob("*")) + list((root / "tb").glob("*")) +
                    [p for p in (root / "third_party").rglob("*") if p.is_file()]):
        h.update(p.name.encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def build(sim: str, cfg: dict, root: Path = ROOT) -> tuple[Path | None, str]:
    """Build the testbench for one hardware configuration (cached by configuration AND source content).
    `root` is the source tree (the mutation script builds modified copies)."""
    key = hashlib.sha1((cfg_key(cfg) + source_hash(root)).encode()).hexdigest()[:10]
    out = root / "build" / sim / key
    files_f, tb = root / "rtl/files.f", root / "tb/tb_gemm.sv"
    with _lock:
        out.mkdir(parents=True, exist_ok=True)
    if sim == "icarus":
        exe = out / "sim.vvp"
        if exe.exists():
            return exe, ""
        cmd = ["iverilog", "-g2012", "-o", str(exe), "-s", "tb_gemm"] + [f"-D{d}" for d in DEFINES]
        cmd += [f"-Ptb_gemm.{k}={v}" for k, v in cfg.items()] + ["-f", str(files_f), str(tb)]
        rc, log = run(cmd, cwd=root)
        return (exe if rc == 0 and exe.exists() else None), log
    exe = out / "Vtb_gemm"
    if exe.exists():
        return exe, ""
    cmd = ["verilator", "--binary", "--timing", "-O2", "-j", "2", "--top-module", "tb_gemm", "-Mdir", str(out),
           "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-INITIALDLY", "-Wno-MULTIDRIVEN",
           "-Wno-SYNCASYNCNET", "-Wno-BLKANDNBLK", "-Wno-UNOPTFLAT", "-Wno-CASEINCOMPLETE", "-Wno-WIDTH",
           "--x-assign", "unique", "--x-initial", "unique"]
    cmd += [f"+define+{d}" for d in DEFINES] + [f"-G{k}={v}" for k, v in cfg.items()]
    cmd += ["-f", str(files_f), str(tb)]
    rc, log = run(cmd, cwd=root, timeout=3600)
    return (exe if rc == 0 and exe.exists() else None), log


def simulate(sim: str, exe: Path, plus: dict, timeout=3600) -> tuple[int, str]:
    args = [f"+{k}={v}" for k, v in plus.items()]
    if sim == "icarus":
        return run(["vvp", "-n", str(exe)] + args, timeout=timeout)
    seed = int(plus.get("seed", 1))
    return run([str(exe), f"+verilator+seed+{seed}", "+verilator+rand+reset+2"] + args, timeout=timeout)


CPL_RE = re.compile(r"CPL (\d+) tag=(\d+) code=(\d+) err_addr=(\w+) cycles=(\d+) tiles=(\d+) chunks=(\d+) bus=(\d+)")


def parse(log: str) -> dict:
    d = dict(cpl=[], perf={}, tob={}, acc={}, result=None, errors=[], stats={}, assertions=[])
    for line in log.splitlines():
        m = CPL_RE.match(line)
        if m:
            d["cpl"].append(dict(idx=int(m[1]), tag=int(m[2]), code=int(m[3]), err_addr=int(m[4], 16),
                                 cycles=int(m[5]), tiles=int(m[6]), chunks=int(m[7]), bus=int(m[8])))
        elif line.startswith("PERF "):
            _, i, v = line.split()
            d["perf"][PC_NAMES[int(i)]] = int(v)
        elif line.startswith("TOBPERF "):
            _, i, v = line.split()
            d["tob"][int(i)] = int(v)
        elif line.startswith("ACCPERF "):
            _, i, v = line.split()
            d["acc"][int(i)] = int(v)
        elif line.startswith("STATS "):
            d["stats"] = {k: int(v) for k, v in (x.split("=") for x in line.split()[1:])}
        elif line.startswith("RESULT "):
            d["result"] = line.split()[1]
        elif "ERROR" in line or "FATAL" in line or "%Error" in line or "Assertion" in line:
            d["errors"].append(line.strip())
        # RTL assertions ($error in the controller, TC03, the SRAM library, dma_fifo): Icarus prints
        # "ERROR: file:line: ..." and CONTINUES, Verilator prints "%Error" and aborts - either fails the run
        if line.startswith("ERROR: ") or "%Error" in line or "Assertion failed" in line:
            d["assertions"].append(line.strip())
    return d


def file_sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def tool_versions() -> dict:
    v = {}
    for name, cmd in [("icarus", ["iverilog", "-V"]), ("verilator", ["verilator", "--version"]),
                      ("yosys", ["yosys", "-V"])]:
        try:
            v[name] = run(cmd)[1].splitlines()[0].strip()
        except Exception:  # noqa: BLE001
            v[name] = "n/a"
    v["python"] = os.sys.version.split()[0]
    return v
