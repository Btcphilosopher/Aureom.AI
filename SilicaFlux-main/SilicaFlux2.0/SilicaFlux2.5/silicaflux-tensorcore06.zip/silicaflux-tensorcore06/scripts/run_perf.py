#!/usr/bin/env python3
"""TENSORCORE 06 performance measurement -> reports/perf.json + reports/tile_utilisation.md.

One GEMM per simulation (Verilator, self-checking testbench: every run must also PASS the
functional checks).  Measured: completion cycles and the controller's counters.  Swept:
  shapes            from one tile up to 64 output tiles x 8 K chunks
  schedule flags    serial (0), overlap (1), overlap+reuse (3), overlap+reuse+N-major (7),
                    serial+reuse (2), N-major without reuse (5)
  hardware          base (2 sets), single (1 set), base_nopad (A_PAD = 0), r8x8 (8x8 array)
  bus               ideal (1-cycle memory) and lat8 (8-cycle memory)
Nothing here is assumed: double-buffering benefit, reuse savings and the A_PAD effect are
differences between measured runs, and the measured block loads / read words are compared
with the analytical model of model/ttc_ref.py.
"""
from __future__ import annotations

import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
from common import BUILD, REPORTS, build, parse, simulate, tool_versions  # noqa: E402
import gen_tests as G  # noqa: E402
import ttc_ref as R  # noqa: E402

HW = {
    "base": G.CONFIGS["base"],
    "single": G.CONFIGS["single"],
    "base_nopad": dict(G.CONFIGS["base"], APAD=0),
    "r8x8": G.CONFIGS["r8x8"],
}
BUS = {"ideal": dict(lat_min=1, lat_max=1), "lat8": dict(lat_min=8, lat_max=8),
       "xbar4": dict(lat_min=4, lat_max=4, xbar=1)}      # DataFabric crossbar R6: one transaction per port
SHAPES = [(4, 4, 4), (5, 7, 3), (17, 13, 29), (16, 16, 64), (32, 32, 256), (64, 16, 64), (8, 64, 512), (16, 16, 1024)]
FLAGS = {0: "serial", 1: "overlap", 3: "overlap+reuse", 7: "overlap+reuse+Nmajor", 2: "serial+reuse", 5: "overlap+Nmajor"}


def make(hw: str, shape, flags: int, bus: str) -> dict:
    cfg = HW[hw]
    m, n, k = shape
    img = G.Image(f"perf/{hw}/{m}x{n}x{k}")
    # dense row-major, word-aligned bases (the common case); strides = K, N, 4N
    c = img.gemm(cfg, m, n, k, flags=flags, unaligned=False)
    d = BUILD / "perf" / f"{hw}__{m}x{n}x{k}__f{flags}__{bus}"       # one directory per run (runs are parallel)
    img.write(d, cfg, dict(name="perf", stage=0, config=hw))
    return dict(dir=str(d), cmd=c, cfg=cfg)


def one(job):
    hw, shape, flags, bus, exe = job
    t = make(hw, shape, flags, bus)
    rc, log = simulate("verilator", exe, dict(BUS[bus], dir=t["dir"], seed=1), timeout=7200)
    d = parse(log)
    cfg, c = t["cfg"], t["cmd"]
    tr = R.traffic(c, cfg["TM"], cfg["TN"], cfg["TK"], cfg["NS"])
    macs, pad = R.macs(c, cfg["TM"], cfg["TN"], cfg["TK"])
    cyc = d["cpl"][0]["cycles"] if d["cpl"] else None
    p = d["perf"]
    return dict(hw=hw, m=shape[0], n=shape[1], k=shape[2], flags=flags, sched=FLAGS[flags], bus=bus,
                ok=d["result"] == "PASS" and not d["assertions"], cycles=cyc, perf=p, model=tr, model_macs=macs, model_pad=pad,
                R=cfg["TM"], C=cfg["TN"], TK=cfg["TK"], NS=cfg["NS"], APAD=cfg["APAD"],
                model_ok=all(p.get(k1.upper()) == tr[k1] for k1 in ("a_loads", "b_loads", "a_reuse", "b_reuse",
                                                                    "rd_words", "fill_bytes")))


def main():
    exes = {}
    for hw, cfg in HW.items():
        exe, log = build("verilator", cfg)
        if exe is None:
            print(log[-3000:])
            sys.exit(f"build failed {hw}")
        exes[hw] = exe
    jobs = []
    for hw in HW:
        for shape in SHAPES:
            for flags in FLAGS:
                for bus in BUS:
                    if hw in ("base_nopad", "r8x8") and flags not in (1, 3):
                        continue
                    jobs.append((hw, shape, flags, bus, exes[hw]))
    with ThreadPoolExecutor(4) as ex:
        res = list(ex.map(one, jobs))
    bad = [r for r in res if not r["ok"] or not r["model_ok"]]
    REPORTS.mkdir(exist_ok=True)
    (REPORTS / "perf.json").write_text(json.dumps(dict(tools=tool_versions(), runs=res), indent=1))
    print(f"{len(res)} perf runs, {len(res) - len(bad)} pass functionally and match the traffic model")
    for r in bad:
        print("  BAD", r["hw"], r["m"], r["n"], r["k"], r["sched"], r["bus"], r["ok"], r["model_ok"])
    import make_report
    make_report.utilisation(res)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
