// =============================================================================
// SilicaFlux TENSORCORE 06 :: tb_gemm
// System testbench: tensor_gemm_engine (controller + unmodified TC02/03/04)
// against an SFB2 memory model, driven by command files from model/gen_tests.py.
//
// Expected results come ONLY from the independent Python reference
// (model/ttc_ref.py, plain Python integers); this testbench never computes a
// matrix product.  It checks:
//   * every completion record (code, error address, tiles, chunks) against the file;
//   * every SFB2 read touches a word holding at least one A or B ELEMENT byte of
//     the running command (no read of padding / beyond the matrix), every write is
//     exactly one aligned INT32 C element with a full strobe, each C element is
//     written exactly once; validation failures produce no bus transaction at all;
//   * the WHOLE memory at the end: C elements equal the reference, every other
//     byte (padding between rows, canary around the matrices, A, B) unchanged.
//
// Memory model (SFB2 slave): req_ready random (+bp=percent not ready), each
// accepted request gets a random latency in [+lat_min, +lat_max], responses in
// order (R5), a write is performed when its response is issued (R7: so the
// completion must really wait for the acknowledgements), +err_rd / +err_wr word
// address answered with rsp_error (R8: no side effect), +hang_after=N stops
// responding after N responses (watchdog test), +xbar=1 limits it to one transaction
// in flight (crossbar rule R6).  Reset (R11) drops everything.
// Other plusargs: +dir=<test directory> +seed +stall=percent (TC02 stall_i)
// +cpl_bp=percent (cpl_ready low) +gap=max idle cycles between commands +maxcyc.
// =============================================================================
`timescale 1ns/1ps
`include "ttc_defs.svh"

module tb_gemm;
  parameter int TM = 4, TN = 4, TK = 64, NS = 2, ASB = 512, BSB = 512, NBA = 4, NBB = 2;
  parameter int PMODE = 1, RL = 1, APAD = 1, SLOTS = 2, MAXOUT = 8, FILLD = 8, WDOG = 16, MULP = 0, ACCRL = 1;
  parameter int MEM_BASE = 32'h1000_0000, MEM_BYTES = 1 << 20;
  localparam int NPC = `TTC_NUM_PC;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int errors = 0;
  `define ERR(args) begin errors = errors + 1; if (errors <= 40) begin $write("ERROR cyc=%0d: ", cyc); $display args ; end end

  // ------------------------------------------------------------ DUT
  logic        cmd_valid = 1'b0, cmd_ready;
  logic [7:0]  cmd_tag, cmd_flags;
  logic [1:0]  cmd_al, cmd_bl, cmd_cl, cmd_at, cmd_bt, cmd_ct;
  logic [31:0] cmd_m, cmd_n, cmd_k, cmd_kc, cmd_a, cmd_b, cmd_c, cmd_lda, cmd_ldb, cmd_ldc;
  logic        cpl_valid, cpl_ready, cpl_err;
  logic [7:0]  cpl_tag;
  logic [4:0]  cpl_code;
  logic [31:0] cpl_err_addr, cpl_cycles, cpl_tiles, cpl_chunks;
  logic        req_valid, req_ready, req_write, rsp_valid, rsp_ready, rsp_error;
  logic [31:0] req_addr, req_wdata, rsp_rdata;
  logic [3:0]  req_wstrb;
  logic        stall_i = 1'b0, busy, halted, perf_clear = 1'b0;
  logic [3:0]  state;
  logic [2:0]  ld_state;
  logic [NPC*40-1:0] perf_cnt;
  logic [20*32-1:0]  tob_perf;
  logic [16*40-1:0]  acc_perf;

  tensor_gemm_engine #(
    .TILE_M(TM), .TILE_N(TN), .TILE_K(TK), .NUM_SETS(NS), .A_SET_BYTES(ASB), .B_SET_BYTES(BSB),
    .A_BANKS(NBA), .B_BANKS(NBB), .PORT_MODE(PMODE), .READ_LATENCY(RL), .A_PAD(APAD), .NUM_SLOTS(SLOTS),
    .ACC_RD_LAT(ACCRL), .MUL_PIPE(MULP), .MAX_OUT(MAXOUT), .FILL_DEPTH(FILLD),
    .MEM_LO(33'(MEM_BASE)), .MEM_HI(33'(MEM_BASE) + 33'(MEM_BYTES)), .WDOG_LOG2(WDOG)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_tag(cmd_tag), .cmd_flags(cmd_flags),
    .cmd_a_layout(cmd_al), .cmd_b_layout(cmd_bl), .cmd_c_layout(cmd_cl),
    .cmd_a_type(cmd_at), .cmd_b_type(cmd_bt), .cmd_c_type(cmd_ct),
    .cmd_m(cmd_m), .cmd_n(cmd_n), .cmd_k(cmd_k), .cmd_kc(cmd_kc),
    .cmd_a_base(cmd_a), .cmd_b_base(cmd_b), .cmd_c_base(cmd_c), .cmd_lda(cmd_lda), .cmd_ldb(cmd_ldb), .cmd_ldc(cmd_ldc),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_tag(cpl_tag), .cpl_err(cpl_err), .cpl_code(cpl_code),
    .cpl_err_addr(cpl_err_addr), .cpl_cycles(cpl_cycles), .cpl_tiles(cpl_tiles), .cpl_chunks(cpl_chunks),
    .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write), .req_addr(req_addr),
    .req_wdata(req_wdata), .req_wstrb(req_wstrb),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error),
    .array_stall_i(stall_i), .busy(busy), .halted(halted), .state(state), .ld_state(ld_state),
    .perf_clear(perf_clear), .perf_cnt(perf_cnt), .tob_perf_cnt(tob_perf), .acc_perf_cnt(acc_perf));

  // ------------------------------------------------------------ random source (xorshift, per stream)
  int unsigned rs [0:7];
  function automatic int unsigned rnd(input int s);
    int unsigned x;
    x = rs[s]; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rs[s] = x; return x;
  endfunction
  function automatic bit pct(input int s, input int p);
    return (p > 0) && (int'(rnd(s) % 100) < p);
  endfunction

  // ------------------------------------------------------------ memory, expectations, roles
  logic [7:0] mem  [0:MEM_BYTES-1];
  logic [7:0] init [0:MEM_BYTES-1];
  logic [9:0] cexp [0:MEM_BYTES-1];     // 0: unchanged, 1xx: expected byte xx, 200: don't care
  logic [1:0] role [0:MEM_BYTES-1];     // bit0: A/B element of the running command, bit1: C element
  logic [7:0] wcnt [0:MEM_BYTES/4-1];   // writes per word during the running command

  function automatic bit inwin(input logic [31:0] a);
    return (a >= MEM_BASE) && (64'(a) < 64'(MEM_BASE) + 64'(MEM_BYTES));
  endfunction

  // ------------------------------------------------------------ SFB2 slave model
  int lat_min = 1, lat_max = 1, bp = 0, stall_pct = 0, cpl_bp = 0, gap = 0, hang_after = -1, xbar = 0;
  logic [31:0] err_rd = 32'hFFFF_FFFF, err_wr = 32'hFFFF_FFFF;
  localparam int QN = 256;
  logic        q_w   [0:QN-1];
  logic [31:0] q_a   [0:QN-1], q_d [0:QN-1];
  logic [3:0]  q_s   [0:QN-1];
  longint      q_t   [0:QN-1];
  int          q_head = 0, q_tail = 0, n_rsp = 0;
  longint      n_rd = 0, n_wr = 0, cmd_bus = 0;

  logic rsp_v_q = 1'b0, rsp_e_q = 1'b0; logic [31:0] rsp_d_q = '0;
  assign rsp_valid = rsp_v_q;
  assign rsp_error = rsp_e_q;
  assign rsp_rdata = rsp_d_q;

  logic rdy_q = 1'b0;
  // +xbar=1: DataFabric crossbar rule R6 - at most ONE transaction per port; the next request is accepted
  // no earlier than the cycle in which the previous response is accepted
  // (outst_q is updated with non-blocking assignments only, so req_ready never changes inside a clock edge)
  int outst_q = 0;                      // accepted requests whose response has not been accepted yet
  assign req_ready = rdy_q && rst_n && (outst_q < QN - 2) &&
                     (xbar == 0 || outst_q == 0 || (outst_q == 1 && rsp_v_q && rsp_ready));
  always @(posedge clk)
    if (!rst_n) outst_q <= 0;
    else        outst_q <= outst_q + ((req_valid && req_ready) ? 1 : 0) - ((rsp_v_q && rsp_ready) ? 1 : 0);

  always @(posedge clk) begin
    if (!rst_n) begin
      if (hang_after >= 0 && n_rsp >= hang_after) hang_after = -1;   // a hang lasts until the next reset
      q_head = 0; q_tail = 0; rsp_v_q <= 1'b0; rsp_e_q <= 1'b0; rsp_d_q <= '0; rdy_q <= 1'b0;
    end else begin
      // response side (in order); a response is held until rsp_ready (R4)
      if (rsp_v_q && rsp_ready) begin rsp_v_q <= 1'b0; n_rsp = n_rsp + 1; end
      if ((!rsp_v_q || rsp_ready) && q_head != q_tail && cyc >= q_t[q_head % QN] &&
          (hang_after < 0 || n_rsp + (rsp_v_q ? 1 : 0) < hang_after)) begin
        int h; logic [31:0] o; logic e;
        h = q_head % QN; q_head = q_head + 1;
        o = q_a[h] - MEM_BASE;
        e = !inwin(q_a[h]) || (q_w[h] ? (q_a[h] == err_wr) : (q_a[h] == err_rd));
        rsp_v_q <= 1'b1; rsp_e_q <= e;
        if (q_w[h]) begin
          rsp_d_q <= '0;
          if (!e) for (int b = 0; b < 4; b++) if (q_s[h][b]) mem[o + b] = q_d[h][8*b +: 8];   // performed now (R7)
        end else begin
          rsp_d_q <= e ? 32'd0 : {mem[o+3], mem[o+2], mem[o+1], mem[o]};
        end
      end else if (rsp_v_q && rsp_ready) begin
        rsp_v_q <= 1'b0;
      end
      // request side
      if (req_valid && req_ready) begin
        int t; t = q_tail % QN;
        q_w[t] = req_write; q_a[t] = req_addr; q_d[t] = req_wdata; q_s[t] = req_wstrb;
        q_t[t] = cyc + lat_min + ((lat_max > lat_min) ? longint'(rnd(1) % (lat_max - lat_min + 1)) : 0);
        q_tail = q_tail + 1;
        bus_check();
      end
      rdy_q   <= !pct(2, bp);
      stall_i <= pct(3, stall_pct);
    end
  end

  // optional trace (+trace): one line per cycle of the external handshakes
  bit trace = 0;
  initial trace = $test$plusargs("trace");
  always @(posedge clk) if (trace && rst_n)
    $display("T %0d t=%0t st=%0d ld=%0d rq=%b%b%b rs=%b cmd=%b%b cpl=%b%b stall=%b", cyc, $time, state, ld_state, req_valid, req_ready,
             req_write, rsp_valid, cmd_valid, cmd_ready, cpl_valid, cpl_ready, stall_i);

  // R2/R3 monitor: a presented request is held unchanged until accepted
  logic        pv = 1'b0, pw; logic [31:0] pa, pd; logic [3:0] ps;
  always @(posedge clk) begin
    if (!rst_n) pv <= 1'b0;
    else begin
      if (pv && !(req_valid && req_write == pw && req_addr == pa && req_wstrb == ps && (!pw || req_wdata == pd)))
        `ERR(("SFB2 R2: request withdrawn or changed before acceptance"))
      pv <= req_valid && !req_ready; pw <= req_write; pa <= req_addr; pd <= req_wdata; ps <= req_wstrb;
    end
  end

  // per-transaction bounds checks against the running command's element maps
  task automatic bus_check();
    logic [31:0] o;
    cmd_bus = cmd_bus + 1;
    if (req_addr[1:0] != 2'b00) `ERR(("SFB2 R9: misaligned address %h", req_addr))
    if (!inwin(req_addr)) `ERR(("bus access outside the memory window: %h", req_addr))
    else begin
      o = req_addr - MEM_BASE;
      if (!req_write) begin
        n_rd = n_rd + 1;
        if (!(role[o][0] || role[o+1][0] || role[o+2][0] || role[o+3][0]))
          `ERR(("read of word %h holds no A/B element byte of the running command", req_addr))
      end else begin
        n_wr = n_wr + 1;
        if (req_wstrb != 4'hF) `ERR(("C write with partial strobe %b at %h", req_wstrb, req_addr))
        if (!(role[o][1] && role[o+1][1] && role[o+2][1] && role[o+3][1]))
          `ERR(("write to %h is not a C element of the running command", req_addr))
        wcnt[o >> 2] = wcnt[o >> 2] + 8'd1;
      end
    end
  endtask

  // ------------------------------------------------------------ element maps of a command
  task automatic set_roles(input logic [31:0] m, n, k, a, b, c, lda, ldb, ldc, input bit on);
    longint x;
    for (longint i = 0; i < m; i++) for (longint j = 0; j < k; j++) begin
      x = longint'(a) + i * lda + j - MEM_BASE; if (x >= 0 && x < MEM_BYTES) role[x][0] = on;
    end
    for (longint i = 0; i < k; i++) for (longint j = 0; j < n; j++) begin
      x = longint'(b) + i * ldb + j - MEM_BASE; if (x >= 0 && x < MEM_BYTES) role[x][0] = on;
    end
    for (longint i = 0; i < m; i++) for (longint j = 0; j < 4 * n; j++) begin
      x = longint'(c) + i * ldc + j - MEM_BASE;
      if (x >= 0 && x < MEM_BYTES) begin role[x][1] = on; if (j % 4 == 0) wcnt[x >> 2] = 8'd0; end
    end
  endtask

  function automatic int count_c_once(input logic [31:0] m, n, c, ldc);
    int bad; longint x;
    bad = 0;
    for (longint i = 0; i < m; i++) for (longint j = 0; j < n; j++) begin
      x = longint'(c) + i * ldc + 4 * j - MEM_BASE;
      if (x >= 0 && x < MEM_BYTES && wcnt[x >> 2] != 8'd1) bad++;
    end
    return bad;
  endfunction

  // ------------------------------------------------------------ command stream
  string dir;
  int    fd, ncmd;
  logic [31:0] f [0:22];
  int    cpl_seen = 0;
  bit    rejected;

  initial begin
    if (!$value$plusargs("dir=%s", dir)) dir = ".";
    begin int s; if (!$value$plusargs("seed=%d", s)) s = 1;
      for (int i = 0; i < 8; i++) rs[i] = 32'h9E37_79B9 * (s + i * 7919) + 32'h1234_5 + i; end
    void'($value$plusargs("lat_min=%d", lat_min));
    void'($value$plusargs("lat_max=%d", lat_max));
    void'($value$plusargs("bp=%d", bp));
    void'($value$plusargs("stall=%d", stall_pct));
    void'($value$plusargs("cpl_bp=%d", cpl_bp));
    void'($value$plusargs("gap=%d", gap));
    void'($value$plusargs("hang_after=%d", hang_after));
    void'($value$plusargs("xbar=%d", xbar));
    void'($value$plusargs("err_rd=%h", err_rd));
    void'($value$plusargs("err_wr=%h", err_wr));
    if (lat_max < lat_min) lat_max = lat_min;
  end

  always @(posedge clk) cpl_ready <= !pct(4, cpl_bp);

  // all stimulus changes on the falling edge: no same-edge races in either simulator
  task automatic do_reset(input int cycles);
    @(negedge clk) rst_n <= 1'b0;
    repeat (cycles) @(posedge clk);
    @(negedge clk) rst_n <= 1'b1;
    repeat (2) @(posedge clk);
  endtask

  task automatic drive_cmd();
    @(negedge clk);
    cmd_valid <= 1'b1;
    cmd_tag <= f[0][7:0]; cmd_flags <= f[1][7:0];
    cmd_al <= f[2][1:0]; cmd_bl <= f[3][1:0]; cmd_cl <= f[4][1:0];
    cmd_at <= f[5][1:0]; cmd_bt <= f[6][1:0]; cmd_ct <= f[7][1:0];
    cmd_m <= f[8]; cmd_n <= f[9]; cmd_k <= f[10]; cmd_kc <= f[11];
    cmd_a <= f[12]; cmd_b <= f[13]; cmd_c <= f[14]; cmd_lda <= f[15]; cmd_ldb <= f[16]; cmd_ldc <= f[17];
    @(posedge clk); while (!cmd_ready) @(posedge clk);
    @(negedge clk) cmd_valid <= 1'b0;
  endtask

  // global time limit: a hang anywhere (e.g. a halted controller never raising cmd_ready) ends the run
  // without a RESULT line, i.e. as a failure
  longint maxcyc = 5_000_000;
  initial void'($value$plusargs("maxcyc=%d", maxcyc));
  always @(posedge clk) if (cyc > maxcyc) begin
    $display("FATAL: global timeout at cyc=%0d (state %0d, ld %0d)", cyc, state, ld_state);
    $finish;
  end

  initial begin
    int unused;
    // memory: canary everywhere, then A/B images and initial C contents from the generator
    for (int i = 0; i < MEM_BYTES; i++) begin
      mem[i] = 8'((i * 37 + 11) ^ (i >> 8) ^ (i >> 16));
      cexp[i] = 10'h000; role[i] = 2'b00;
    end
    for (int i = 0; i < MEM_BYTES / 4; i++) wcnt[i] = 8'd0;
    #1;
    $readmemh({dir, "/mem.hex"}, mem);
    $readmemh({dir, "/cexp.hex"}, cexp);
    for (int i = 0; i < MEM_BYTES; i++) init[i] = mem[i];

    do_reset(4);
    fd = $fopen({dir, "/cmds.txt"}, "r");
    if (fd == 0) begin $display("FATAL: no %s/cmds.txt", dir); $finish; end
    unused = $fscanf(fd, "%d\n", ncmd);
    for (int ci = 0; ci < ncmd; ci++) begin
      longint t0, b0;
      // fields: tag flags al bl cl at bt ct m n k kc a b c lda ldb ldc | exp_code exp_err_addr exp_tiles exp_chunks rst_at
      for (int j = 0; j < 23; j++) unused = $fscanf(fd, "%h", f[j]);
      repeat (int'(gap > 0 ? rnd(5) % (gap + 1) : 0)) @(posedge clk);
      // a command that must be rejected has no element map: any bus access is then an error
      rejected = (f[18] != 0 && f[18] < 16);
      if (!rejected) set_roles(f[8], f[9], f[10], f[12], f[13], f[14], f[15], f[16], f[17], 1'b1);
      if (f[22] != 0) begin
        // reset in the middle of this command, then run it again from the start
        drive_cmd();
        repeat (f[22]) @(posedge clk);
        $display("RESET cmd=%0d at cyc=%0d state=%0d ld_state=%0d", ci, cyc, state, ld_state);
        do_reset(3);
        set_roles(f[8], f[9], f[10], f[12], f[13], f[14], f[15], f[16], f[17], 1'b1);
      end
      b0 = cmd_bus; t0 = cyc;
      drive_cmd();
      while (!(cpl_valid && cpl_ready)) begin
        @(posedge clk);
      end
      $display("CPL %0d tag=%0d code=%0d err_addr=%h cycles=%0d tiles=%0d chunks=%0d bus=%0d",
               ci, cpl_tag, cpl_code, cpl_err_addr, cpl_cycles, cpl_tiles, cpl_chunks, cmd_bus - b0);
      if (cpl_tag !== f[0][7:0])  `ERR(("cmd %0d: completion tag %0d != %0d", ci, cpl_tag, f[0][7:0]))
      if (cpl_code !== f[18][4:0]) `ERR(("cmd %0d: completion code %0d != expected %0d", ci, cpl_code, f[18]))
      if (cpl_err !== (f[18] != 0)) `ERR(("cmd %0d: cpl_err inconsistent", ci))
      if (f[19] != 32'hFFFF_FFFF && cpl_err_addr !== f[19]) `ERR(("cmd %0d: err_addr %h != %h", ci, cpl_err_addr, f[19]))
      if (f[18] == 0 || f[18] == `TTC_ERR_BUS_READ || f[18] == `TTC_ERR_BUS_WRITE) begin
        int bad;
        if (cpl_tiles !== f[20])  `ERR(("cmd %0d: tiles %0d != %0d", ci, cpl_tiles, f[20]))
        if (cpl_chunks !== f[21]) `ERR(("cmd %0d: chunks %0d != %0d", ci, cpl_chunks, f[21]))
        bad = count_c_once(f[8], f[9], f[14], f[17]);
        if (bad != 0) `ERR(("cmd %0d: %0d C elements not written exactly once", ci, bad))
      end else if (f[18] < 16) begin
        if (cmd_bus != b0) `ERR(("cmd %0d: rejected command produced %0d bus transactions", ci, cmd_bus - b0))
        if (cpl_tiles !== 0 || cpl_chunks !== 0) `ERR(("cmd %0d: rejected command reports work", ci))
      end
      if (f[18] >= 24) begin
        @(posedge clk);
        if (!halted) `ERR(("cmd %0d: fatal error did not halt", ci))
        do_reset(3);
      end
      if (!rejected) set_roles(f[8], f[9], f[10], f[12], f[13], f[14], f[15], f[16], f[17], 1'b0);
      cpl_seen++;
    end
    repeat (10) @(posedge clk);
    if (busy) `ERR(("controller still busy after the last completion"))

    // ------------------------------------------------ whole-memory comparison
    begin
      longint chk, cel, mis;
      chk = 0; cel = 0; mis = 0;
      for (int i = 0; i < MEM_BYTES; i++) begin
        if (cexp[i] != 10'h200) begin
          chk++;
          if (cexp[i][8]) begin
            cel++;
            if (mem[i] !== cexp[i][7:0]) begin mis++; if (mis <= 20) `ERR(("C byte @%h = %h, reference %h", MEM_BASE + i, mem[i], cexp[i][7:0])) end
          end else if (mem[i] !== init[i]) begin
            mis++; if (mis <= 20) `ERR(("byte @%h modified: %h -> %h (not a C element)", MEM_BASE + i, init[i], mem[i]))
          end
        end
      end
      if (mis > 20) `ERR(("%0d mismatching bytes in total", mis))
      for (int i = 0; i < NPC; i++) $display("PERF %0d %0d", i, perf_cnt[i*40 +: 40]);
      for (int i = 0; i < 20; i++) $display("TOBPERF %0d %0d", i, tob_perf[i*32 +: 32]);
      for (int i = 0; i < 16; i++) $display("ACCPERF %0d %0d", i, acc_perf[i*40 +: 40]);
      $display("STATS cycles=%0d reads=%0d writes=%0d bytes_checked=%0d c_bytes=%0d", cyc, n_rd, n_wr, chk, cel);
      $display("RESULT %s errors=%0d cmds=%0d", (errors == 0 && cpl_seen == ncmd) ? "PASS" : "FAIL", errors, cpl_seen);
    end
    $finish;
  end
endmodule
