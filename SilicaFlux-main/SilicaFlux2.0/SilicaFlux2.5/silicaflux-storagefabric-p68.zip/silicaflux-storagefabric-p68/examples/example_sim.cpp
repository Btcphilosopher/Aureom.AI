// Runs examples/sfs_example.c against the Verilated fabric (simulated block device): the hypervisor side (this file) allocates a DMA
// window and a namespace for tenant 0; the tenant side (sfs_example.c) uses only libsfstor.
#include "tb_env.hpp"
extern "C" int sfs_example_run(const sfs_transport_t *tp, unsigned tenant, FILE *out);
using namespace sfsim;
int main(int argc, char **argv) {
  Harness::set_args(argc, argv);
  Tb tb(1);
  tb.power_on(); tb.configure(true, false, 256);
  int rc = sfs_example_run(&tb.tp[0], 0, stdout);
  printf("bus-isolation monitor violations: %llu\n", (unsigned long long)tb.h.st.violations);
  return rc || tb.h.st.violations ? 1 : 0;
}
