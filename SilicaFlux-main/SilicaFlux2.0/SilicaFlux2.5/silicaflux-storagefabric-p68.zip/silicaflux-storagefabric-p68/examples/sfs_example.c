/*
 * sfs_example.c - the libsfstor tour: discover a StorageFabric tenant page, create a queue pair, submit reads / writes /
 * FLUSH (asynchronously and synchronously), poll completions, read error status, inspect performance counters.
 *
 * Platform independent: everything goes through the sfs_transport_t the caller supplies (a real MMIO mapping + DMA-coherent
 * memory on hardware, or the Verilator co-simulation in examples/example_sim.cpp).  C99, no dynamic allocation.
 */
#include <stdio.h>
#include <string.h>
#include "sfstor.h"

#define CHECK(c, ...) do { if (!(c)) { fprintf(out, "  FAIL: " __VA_ARGS__); fprintf(out, "\n"); return 1; } } while (0)

int sfs_example_run(const sfs_transport_t *tp, unsigned tenant, FILE *out) {
  sfs_dev_t dev; sfs_queue_t q; sfs_buf_t wbuf, rbuf; sfs_cqe_t cq;
  int rc;

  /* 1. discover capabilities ------------------------------------------------------------------ */
  rc = sfs_dev_open(&dev, tp, tenant);
  CHECK(rc == SFS_OK, "sfs_dev_open: %s", sfs_strerror(rc));
  const sfs_caps_t *c = sfs_dev_caps(&dev);
  fprintf(out, "device: ABI version 0x%08x  MDTS %u blocks  SQ<=%u CQ<=%u  block %u B\n", c->version, c->mdts_blocks, c->sq_max, c->cq_max, 1u << c->block_shift);
  fprintf(out, "  backend type %u ready=%d  caps: discard=%d pi=%d enc=%d fua=%d hcrc=%d volatile_cache=%d  owned namespaces mask 0x%04x\n", c->backend_type, c->backend_ready,
          c->discard, c->pi, c->enc, c->fua, c->hcrc, c->volatile_cache, c->ns_mask);
  int ns = sfs_dev_first_ns(&dev);
  CHECK(ns >= 0, "this tenant owns no namespace");
  CHECK(c->backend_ready, "backend not ready");

  /* 2. queue pair ----------------------------------------------------------------------------- */
  rc = sfs_queue_create(&dev, &q, 32, 32);
  CHECK(rc == SFS_OK, "sfs_queue_create: %s", sfs_strerror(rc));
  rc = sfs_buf_alloc(&dev, 8 * SFS_BLOCK_BYTES, &wbuf); CHECK(rc == SFS_OK, "buffer: %s", sfs_strerror(rc));
  rc = sfs_buf_alloc(&dev, 8 * SFS_BLOCK_BYTES, &rbuf); CHECK(rc == SFS_OK, "buffer: %s", sfs_strerror(rc));

  uint64_t blocks = 0;
  rc = sfs_capacity_sync(&q, (unsigned)ns, &blocks, &cq);
  CHECK(rc == SFS_OK, "GET_CAPACITY: %s", sfs_strerror(rc));
  fprintf(out, "namespace %d: %llu blocks (%llu KiB)\n", ns, (unsigned long long)blocks, (unsigned long long)blocks / 2);

  /* 3. asynchronous writes: queue four, ring once, poll until all four completed ----------------- */
  unsigned i, done = 0;
  for (i = 0; i < 4; i++) {
    memset(wbuf.va, (int)(0x10 + i), 2 * SFS_BLOCK_BYTES);         /* pattern 0x10+i, 2 blocks at LBA 2*i */
    rc = sfs_submit_write(&q, (uint16_t)(100 + i), (unsigned)ns, 2u * i, 2, wbuf.iova, NULL, 0);
    CHECK(rc == SFS_OK, "submit write %u: %s", i, sfs_strerror(rc));
    /* the device reads the buffer when the command executes, so wait for this one before reusing it */
    rc = sfs_ring(&q); CHECK(rc >= 0, "ring: %s", sfs_strerror(rc));
    rc = sfs_wait(&q, &cq, 2000000); CHECK(rc == SFS_OK, "wait: %s", sfs_strerror(rc));
    CHECK(cq.status == SFS_ST_SUCCESS, "write %u: status %s", i, sfs_status_str(cq.status));
    fprintf(out, "  write txn %u: status %s  durable=%u  latency %u cycles\n", cq.txn, sfs_status_str(cq.status), cq.durable, cq.latency);
    done++;
  }

  /* 4. batched reads with several outstanding commands (distinct buffers) -------------------------- */
  {
    sfs_buf_t rb[4]; uint16_t seen = 0;
    for (i = 0; i < 4; i++) { rc = sfs_buf_alloc(&dev, 2 * SFS_BLOCK_BYTES, &rb[i]); CHECK(rc == SFS_OK, "buffer: %s", sfs_strerror(rc)); }
    for (i = 0; i < 4; i++) { rc = sfs_submit_read(&q, (uint16_t)(200 + i), (unsigned)ns, 2u * i, 2, rb[i].iova, 0); CHECK(rc == SFS_OK, "submit read: %s", sfs_strerror(rc)); }
    rc = sfs_ring(&q); CHECK(rc >= 0, "ring: %s", sfs_strerror(rc));
    while (seen < 4) {                                                /* completions may arrive in any order: match by TXN_ID */
      rc = sfs_wait(&q, &cq, 2000000); CHECK(rc == SFS_OK, "wait: %s", sfs_strerror(rc));
      CHECK(cq.status == SFS_ST_SUCCESS, "read txn %u: %s", cq.txn, sfs_status_str(cq.status));
      unsigned k = cq.txn - 200u;
      CHECK(k < 4 && ((const uint8_t *)rb[k].va)[0] == 0x10 + k && ((const uint8_t *)rb[k].va)[2 * SFS_BLOCK_BYTES - 1] == 0x10 + k, "read txn %u returned wrong data", cq.txn);
      seen++;
    }
    fprintf(out, "  4 reads verified byte-exact against what was written\n");
  }

  /* 5. FUA write and FLUSH: what "durable" means --------------------------------------------------- */
  memset(wbuf.va, 0x5A, SFS_BLOCK_BYTES);
  rc = sfs_write_sync(&q, (unsigned)ns, 10, 1, wbuf.iova, NULL, c->fua ? SFS_F_FUA : 0, &cq);
  CHECK(rc == SFS_OK, "write: %s", sfs_strerror(rc));
  fprintf(out, "  %s write: durable=%u%s\n", c->fua ? "FUA" : "plain", cq.durable, c->fua ? " (a FUA write completes only when the data is persistent)" : "");
  rc = sfs_flush_sync(&q, (unsigned)ns, &cq);
  CHECK(rc == SFS_OK, "flush: %s", sfs_strerror(rc));
  fprintf(out, "  FLUSH: status %s durable=%u (copied from the backend completion; a volatile-cache backend needs this)\n", sfs_status_str(cq.status), cq.durable);

  /* 6. errors are ordinary completions: a read past the end of the namespace ------------------------- */
  rc = sfs_read_sync(&q, (unsigned)ns, blocks - 1, 2, rbuf.iova, 0, &cq);
  CHECK(rc == SFS_E_STATUS, "an out-of-range read must complete with an error status (rc=%d)", rc);
  fprintf(out, "  read past the end: status %s detail %s  (host buffer untouched)\n", sfs_status_str(cq.status), sfs_detail_str(cq.status, cq.detail));
  CHECK(cq.status == SFS_ST_LBA_RANGE, "expected LBA_RANGE");
  rc = sfs_read_sync(&q, 7, 0, 1, rbuf.iova, 0, &cq);                  /* a namespace this tenant does not own */
  fprintf(out, "  read of a foreign namespace: status %s\n", sfs_status_str(cq.status));
  CHECK(rc == SFS_E_STATUS && cq.status != SFS_ST_SUCCESS, "foreign namespace must be refused");

  /* 7. performance: per-tenant counters and the latency the library accumulated ------------------------ */
  sfs_perf_t p; rc = sfs_perf_read(&dev, &p);
  CHECK(rc == SFS_OK, "perf: %s", sfs_strerror(rc));
  const sfs_lat_t *l = sfs_queue_latency(&q);
  fprintf(out, "counters: done %u err %u  read blocks %u  write blocks %u  flushes %u  throttled %u  isolation violations %u\n", p.done, p.err, p.rd_blk, p.wr_blk, p.flush, p.throttle, p.viol);
  fprintf(out, "latency (CQE.LATENCY, fabric cycles): n=%llu min=%u mean=%u max=%u\n", (unsigned long long)l->count, l->min, sfs_lat_mean(l), l->max);
  (void)done;
  sfs_queue_destroy(&q);
  fprintf(out, "example finished\n");
  return 0;
}
