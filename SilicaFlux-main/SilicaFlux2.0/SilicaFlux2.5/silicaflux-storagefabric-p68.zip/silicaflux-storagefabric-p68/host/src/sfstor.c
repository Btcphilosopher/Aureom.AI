/*
 * sfstor.c - libsfstor implementation (see sfstor.h).  C99, written from docs/02_HOST_INTERFACE.md only.
 *
 * Ordering rules implemented here (§3, §8):
 *   submit : write all 16 descriptor words -> barrier -> SQ_TAIL doorbell
 *   poll   : read CQE word 7 (PHASE) first -> acquire barrier -> read words 0..6 -> consume
 *            -> barrier -> CQ_HEAD doorbell
 * Ring occupancy never exceeds SQ_SIZE-1 (§8 SQ_TAIL rule).
 */
#include "sfstor.h"

#include <stdio.h>
#include <string.h>

#define SFS_RESET_POLLS        100000u
#define SFS_DEFAULT_SYNC_POLLS 1000000u

/* ------------------------------------------------------------------------------------------ */
/* low-level helpers                                                                           */
/* ------------------------------------------------------------------------------------------ */
static void compiler_barrier(void) {
#if defined(__GNUC__) || defined(__clang__)
  __asm__ __volatile__("" ::: "memory");
#else
  static volatile int sink;
  sink = 0;
#endif
}

static void dev_barrier(const sfs_dev_t *d) {
  if (d->tp.barrier) d->tp.barrier(d->tp.ctx);
  else compiler_barrier();
}

static void dev_yield(const sfs_dev_t *d) {
  if (d->tp.yield) d->tp.yield(d->tp.ctx);
}

static uint32_t rd(const sfs_dev_t *d, uint32_t off) { return d->tp.mmio_read32(d->tp.ctx, off); }
static void wr(const sfs_dev_t *d, uint32_t off, uint32_t v) { d->tp.mmio_write32(d->tp.ctx, off, v); }

/* explicit little-endian accessors: no reliance on host byte order or alignment */
static void st_le32(uint8_t *p, uint32_t v) {
  p[0] = (uint8_t)(v & 0xFFu);
  p[1] = (uint8_t)((v >> 8) & 0xFFu);
  p[2] = (uint8_t)((v >> 16) & 0xFFu);
  p[3] = (uint8_t)((v >> 24) & 0xFFu);
}
static uint32_t ld_le32(const uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static uint32_t ldv_le32(const volatile uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static int is_pow2_ge2(uint32_t v) { return v >= 2u && (v & (v - 1u)) == 0u; }

/* ------------------------------------------------------------------------------------------ */
/* errors / strings                                                                            */
/* ------------------------------------------------------------------------------------------ */
const char *sfs_strerror(int err) {
  switch (err) {
    case SFS_OK: return "ok";
    case SFS_E_INVAL: return "invalid argument";
    case SFS_E_NO_DEVICE: return "no device (ID mismatch)";
    case SFS_E_VERSION: return "unsupported ABI version";
    case SFS_E_UNSUPPORTED: return "unsupported capability";
    case SFS_E_NOMEM: return "out of memory";
    case SFS_E_ALIGN: return "misaligned memory";
    case SFS_E_FULL: return "submission ring full";
    case SFS_E_TIMEOUT: return "timeout";
    case SFS_E_STATE: return "bad state";
    case SFS_E_NOT_ENABLED: return "queue not enabled (hypervisor has not allowed it)";
    case SFS_E_BAD_SIZE: return "ring size rejected by device";
    case SFS_E_BUSY: return "commands in flight";
    case SFS_E_PROTO: return "protocol error (unexpected completion)";
    case SFS_E_STATUS: return "command completed with error status";
    case SFS_E_REFUSED: return "refused by device";
    case SFS_E_FATAL: return "queue fatal";
    default: return "unknown error";
  }
}

const char *sfs_status_str(unsigned status) {
  static const char *const names[SFS_ST_COUNT] = {
      "SUCCESS",       "INVALID_OPCODE", "INVALID_FIELD", "INVALID_NS",      "LBA_RANGE",
      "LEN_ERROR",     "TENANT_MISMATCH", "NS_READONLY",  "DMA_FAULT",       "DMA_ERROR",
      "DATA_CRC",      "INTEGRITY",      "MEDIA_ERROR",   "BACKEND_ERROR",   "TIMEOUT",
      "ABORTED_RESET", "ABORTED_POWER",  "UNSUPPORTED",   "CRYPTO_ERROR",    "INTERNAL"};
  return status < SFS_ST_COUNT ? names[status] : "UNKNOWN";
}

const char *sfs_detail_str(unsigned status, unsigned detail) {
  if (detail == 0) return "-";
  switch (status) {
    case SFS_ST_INVALID_FIELD:
      switch (detail) {
        case SFS_DET_FIELD_VERSION: return "VERSION";
        case SFS_DET_FIELD_RESERVED: return "RESERVED";
        case SFS_DET_FIELD_FLAGS: return "FLAGS";
        case SFS_DET_FIELD_ADDR_ALIGN: return "ADDR_ALIGN";
        default: return "UNKNOWN";
      }
    case SFS_ST_LEN_ERROR:
      switch (detail) {
        case SFS_DET_LEN_ZERO: return "ZERO";
        case SFS_DET_LEN_TOO_LARGE: return "TOO_LARGE";
        case SFS_DET_LEN_MISMATCH: return "MISMATCH";
        case SFS_DET_LEN_NOT_ZERO: return "NOT_ZERO";
        default: return "UNKNOWN";
      }
    case SFS_ST_DMA_FAULT:
      switch (detail) {
        case SFS_DET_DMA_NO_MAP: return "NO_MAP";
        case SFS_DET_DMA_PERM: return "PERM";
        case SFS_DET_DMA_DOMAIN: return "DOMAIN";
        case SFS_DET_DMA_RANGE: return "RANGE";
        default: return "FAULT_CODE";
      }
    case SFS_ST_INTEGRITY:
      switch (detail) {
        case SFS_DET_INTEG_GUARD: return "GUARD";
        case SFS_DET_INTEG_LBA_TAG: return "LBA_TAG";
        case SFS_DET_INTEG_NS_TAG: return "NS_TAG";
        case SFS_DET_INTEG_FORMAT: return "FORMAT";
        default: return "UNKNOWN";
      }
    case SFS_ST_TIMEOUT:
      switch (detail) {
        case SFS_DET_TMO_BACKEND: return "BACKEND";
        case SFS_DET_TMO_DMA: return "DMA";
        default: return "UNKNOWN";
      }
    case SFS_ST_CRYPTO_ERROR:
      switch (detail) {
        case SFS_DET_CRYPTO_KEY_NOT_READY: return "KEY_NOT_READY";
        case SFS_DET_CRYPTO_ENGINE: return "ENGINE";
        default: return "UNKNOWN";
      }
    default: return "code"; /* DMA_ERROR / MEDIA_ERROR / BACKEND_ERROR / INTERNAL: raw backend/fabric code */
  }
}

/* ------------------------------------------------------------------------------------------ */
/* CRC-32C                                                                                     */
/* ------------------------------------------------------------------------------------------ */
static const uint32_t crc32c_table[256] = {
  0x00000000u, 0xf26b8303u, 0xe13b70f7u, 0x1350f3f4u, 0xc79a971fu, 0x35f1141cu,
  0x26a1e7e8u, 0xd4ca64ebu, 0x8ad958cfu, 0x78b2dbccu, 0x6be22838u, 0x9989ab3bu,
  0x4d43cfd0u, 0xbf284cd3u, 0xac78bf27u, 0x5e133c24u, 0x105ec76fu, 0xe235446cu,
  0xf165b798u, 0x030e349bu, 0xd7c45070u, 0x25afd373u, 0x36ff2087u, 0xc494a384u,
  0x9a879fa0u, 0x68ec1ca3u, 0x7bbcef57u, 0x89d76c54u, 0x5d1d08bfu, 0xaf768bbcu,
  0xbc267848u, 0x4e4dfb4bu, 0x20bd8edeu, 0xd2d60dddu, 0xc186fe29u, 0x33ed7d2au,
  0xe72719c1u, 0x154c9ac2u, 0x061c6936u, 0xf477ea35u, 0xaa64d611u, 0x580f5512u,
  0x4b5fa6e6u, 0xb93425e5u, 0x6dfe410eu, 0x9f95c20du, 0x8cc531f9u, 0x7eaeb2fau,
  0x30e349b1u, 0xc288cab2u, 0xd1d83946u, 0x23b3ba45u, 0xf779deaeu, 0x05125dadu,
  0x1642ae59u, 0xe4292d5au, 0xba3a117eu, 0x4851927du, 0x5b016189u, 0xa96ae28au,
  0x7da08661u, 0x8fcb0562u, 0x9c9bf696u, 0x6ef07595u, 0x417b1dbcu, 0xb3109ebfu,
  0xa0406d4bu, 0x522bee48u, 0x86e18aa3u, 0x748a09a0u, 0x67dafa54u, 0x95b17957u,
  0xcba24573u, 0x39c9c670u, 0x2a993584u, 0xd8f2b687u, 0x0c38d26cu, 0xfe53516fu,
  0xed03a29bu, 0x1f682198u, 0x5125dad3u, 0xa34e59d0u, 0xb01eaa24u, 0x42752927u,
  0x96bf4dccu, 0x64d4cecfu, 0x77843d3bu, 0x85efbe38u, 0xdbfc821cu, 0x2997011fu,
  0x3ac7f2ebu, 0xc8ac71e8u, 0x1c661503u, 0xee0d9600u, 0xfd5d65f4u, 0x0f36e6f7u,
  0x61c69362u, 0x93ad1061u, 0x80fde395u, 0x72966096u, 0xa65c047du, 0x5437877eu,
  0x4767748au, 0xb50cf789u, 0xeb1fcbadu, 0x197448aeu, 0x0a24bb5au, 0xf84f3859u,
  0x2c855cb2u, 0xdeeedfb1u, 0xcdbe2c45u, 0x3fd5af46u, 0x7198540du, 0x83f3d70eu,
  0x90a324fau, 0x62c8a7f9u, 0xb602c312u, 0x44694011u, 0x5739b3e5u, 0xa55230e6u,
  0xfb410cc2u, 0x092a8fc1u, 0x1a7a7c35u, 0xe811ff36u, 0x3cdb9bddu, 0xceb018deu,
  0xdde0eb2au, 0x2f8b6829u, 0x82f63b78u, 0x709db87bu, 0x63cd4b8fu, 0x91a6c88cu,
  0x456cac67u, 0xb7072f64u, 0xa457dc90u, 0x563c5f93u, 0x082f63b7u, 0xfa44e0b4u,
  0xe9141340u, 0x1b7f9043u, 0xcfb5f4a8u, 0x3dde77abu, 0x2e8e845fu, 0xdce5075cu,
  0x92a8fc17u, 0x60c37f14u, 0x73938ce0u, 0x81f80fe3u, 0x55326b08u, 0xa759e80bu,
  0xb4091bffu, 0x466298fcu, 0x1871a4d8u, 0xea1a27dbu, 0xf94ad42fu, 0x0b21572cu,
  0xdfeb33c7u, 0x2d80b0c4u, 0x3ed04330u, 0xccbbc033u, 0xa24bb5a6u, 0x502036a5u,
  0x4370c551u, 0xb11b4652u, 0x65d122b9u, 0x97baa1bau, 0x84ea524eu, 0x7681d14du,
  0x2892ed69u, 0xdaf96e6au, 0xc9a99d9eu, 0x3bc21e9du, 0xef087a76u, 0x1d63f975u,
  0x0e330a81u, 0xfc588982u, 0xb21572c9u, 0x407ef1cau, 0x532e023eu, 0xa145813du,
  0x758fe5d6u, 0x87e466d5u, 0x94b49521u, 0x66df1622u, 0x38cc2a06u, 0xcaa7a905u,
  0xd9f75af1u, 0x2b9cd9f2u, 0xff56bd19u, 0x0d3d3e1au, 0x1e6dcdeeu, 0xec064eedu,
  0xc38d26c4u, 0x31e6a5c7u, 0x22b65633u, 0xd0ddd530u, 0x0417b1dbu, 0xf67c32d8u,
  0xe52cc12cu, 0x1747422fu, 0x49547e0bu, 0xbb3ffd08u, 0xa86f0efcu, 0x5a048dffu,
  0x8ecee914u, 0x7ca56a17u, 0x6ff599e3u, 0x9d9e1ae0u, 0xd3d3e1abu, 0x21b862a8u,
  0x32e8915cu, 0xc083125fu, 0x144976b4u, 0xe622f5b7u, 0xf5720643u, 0x07198540u,
  0x590ab964u, 0xab613a67u, 0xb831c993u, 0x4a5a4a90u, 0x9e902e7bu, 0x6cfbad78u,
  0x7fab5e8cu, 0x8dc0dd8fu, 0xe330a81au, 0x115b2b19u, 0x020bd8edu, 0xf0605beeu,
  0x24aa3f05u, 0xd6c1bc06u, 0xc5914ff2u, 0x37faccf1u, 0x69e9f0d5u, 0x9b8273d6u,
  0x88d28022u, 0x7ab90321u, 0xae7367cau, 0x5c18e4c9u, 0x4f48173du, 0xbd23943eu,
  0xf36e6f75u, 0x0105ec76u, 0x12551f82u, 0xe03e9c81u, 0x34f4f86au, 0xc69f7b69u,
  0xd5cf889du, 0x27a40b9eu, 0x79b737bau, 0x8bdcb4b9u, 0x988c474du, 0x6ae7c44eu,
  0xbe2da0a5u, 0x4c4623a6u, 0x5f16d052u, 0xad7d5351u,
};

uint32_t sfs_crc32c_update(uint32_t crc, const void *data, size_t len) {
  const uint8_t *p = (const uint8_t *)data;
  uint32_t c = crc ^ 0xFFFFFFFFu;
  size_t i;
  for (i = 0; i < len; ++i) c = crc32c_table[(c ^ p[i]) & 0xFFu] ^ (c >> 8);
  return c ^ 0xFFFFFFFFu;
}

uint32_t sfs_crc32c(const void *data, size_t len) { return sfs_crc32c_update(0u, data, len); }

/* ------------------------------------------------------------------------------------------ */
/* latency helpers                                                                             */
/* ------------------------------------------------------------------------------------------ */
void sfs_lat_reset(sfs_lat_t *l) {
  l->count = 0;
  l->sum = 0;
  l->min = 0xFFFFFFFFu;
  l->max = 0;
}

void sfs_lat_add(sfs_lat_t *l, uint32_t cycles) {
  if (l->count == 0) {
    l->min = cycles;
    l->max = cycles;
  } else {
    if (cycles < l->min) l->min = cycles;
    if (cycles > l->max) l->max = cycles;
  }
  l->count++;
  l->sum += cycles;
}

uint32_t sfs_lat_mean(const sfs_lat_t *l) { return l->count ? (uint32_t)(l->sum / l->count) : 0u; }

static void sift_down(uint32_t *a, size_t root, size_t end) {
  while (root * 2u + 1u < end) {
    size_t child = root * 2u + 1u;
    uint32_t t;
    if (child + 1u < end && a[child] < a[child + 1u]) child++;
    if (a[root] >= a[child]) return;
    t = a[root];
    a[root] = a[child];
    a[child] = t;
    root = child;
  }
}

static void heapsort_u32(uint32_t *a, size_t n) {
  size_t s, e;
  for (s = n / 2u; s-- > 0u;) sift_down(a, s, n);
  for (e = n; e-- > 1u;) {
    uint32_t t = a[0];
    a[0] = a[e];
    a[e] = t;
    sift_down(a, 0, e);
  }
}

int sfs_percentile(uint32_t *samples, size_t n, unsigned pct_x100, uint32_t *out) {
  uint64_t rank;
  if (!samples || !out || n == 0 || pct_x100 > 10000u) return SFS_E_INVAL;
  heapsort_u32(samples, n);
  rank = (((uint64_t)pct_x100 * (uint64_t)n) + 9999u) / 10000u; /* ceil(P/100 * N) */
  if (rank < 1u) rank = 1u;
  if (rank > (uint64_t)n) rank = (uint64_t)n;
  *out = samples[rank - 1u];
  return SFS_OK;
}

/* ------------------------------------------------------------------------------------------ */
/* descriptor / CQE codec                                                                      */
/* ------------------------------------------------------------------------------------------ */
void sfs_desc_pack(const sfs_desc_t *d, uint32_t w[SFS_DESC_WORDS]) {
  unsigned i;
  w[0] = (uint32_t)d->version | ((uint32_t)d->opcode << 8) | ((uint32_t)d->flags << 16);
  w[1] = (uint32_t)d->txn | ((uint32_t)d->nsid << 16) | ((uint32_t)d->rsv1 << 24);
  w[2] = (uint32_t)(d->lba & 0xFFFFFFFFu);
  w[3] = (uint32_t)(d->lba >> 32);
  w[4] = d->nblk;
  w[5] = d->data_len;
  w[6] = (uint32_t)(d->data_addr & 0xFFFFFFFFu);
  w[7] = (uint32_t)(d->data_addr >> 32);
  w[8] = (uint32_t)d->tenant_claim | ((uint32_t)d->rsv8 << 16);
  w[9] = d->host_crc;
  for (i = 0; i < 6u; ++i) w[10u + i] = d->rsv[i];
}

void sfs_desc_unpack(const uint32_t w[SFS_DESC_WORDS], sfs_desc_t *d) {
  unsigned i;
  d->version = (uint8_t)(w[0] & 0xFFu);
  d->opcode = (uint8_t)((w[0] >> 8) & 0xFFu);
  d->flags = (uint16_t)(w[0] >> 16);
  d->txn = (uint16_t)(w[1] & 0xFFFFu);
  d->nsid = (uint8_t)((w[1] >> 16) & 0xFFu);
  d->rsv1 = (uint8_t)(w[1] >> 24);
  d->lba = (uint64_t)w[2] | ((uint64_t)w[3] << 32);
  d->nblk = w[4];
  d->data_len = w[5];
  d->data_addr = (uint64_t)w[6] | ((uint64_t)w[7] << 32);
  d->tenant_claim = (uint16_t)(w[8] & 0xFFFFu);
  d->rsv8 = (uint16_t)(w[8] >> 16);
  d->host_crc = w[9];
  for (i = 0; i < 6u; ++i) d->rsv[i] = w[10u + i];
}

void sfs_cqe_unpack(const uint32_t w[SFS_CQE_WORDS], sfs_cqe_t *c) {
  unsigned i;
  c->txn = (uint16_t)(w[0] & 0xFFFFu);
  c->status = (uint8_t)((w[0] >> 16) & 0xFFu);
  c->detail = (uint8_t)((w[0] >> 24) & 0xFFu);
  c->durable = (uint8_t)((w[1] & SFS_CQE_DURABLE) ? 1u : 0u);
  c->pi_verified = (uint8_t)((w[1] & SFS_CQE_PI_VERIFIED) ? 1u : 0u);
  c->encrypted = (uint8_t)((w[1] & SFS_CQE_ENCRYPTED) ? 1u : 0u);
  c->crc_valid = (uint8_t)((w[1] & SFS_CQE_CRC_VALID) ? 1u : 0u);
  c->opcode = (uint8_t)((w[1] >> 8) & 0xFFu);
  c->nblk_done = (uint16_t)(w[1] >> 16);
  c->result0 = w[2];
  c->result1 = w[3];
  c->sq_head = (uint16_t)(w[4] & 0xFFFFu);
  c->tenant = (uint16_t)(w[4] >> 16);
  c->latency = w[5];
  c->phase = (uint8_t)(w[7] & 1u);
  for (i = 0; i < SFS_CQE_WORDS; ++i) c->raw[i] = w[i];
}

uint64_t sfs_cqe_capacity(const sfs_cqe_t *c) { return (uint64_t)c->result0 | ((uint64_t)c->result1 << 32); }

/* ------------------------------------------------------------------------------------------ */
/* device                                                                                      */
/* ------------------------------------------------------------------------------------------ */
static int read_caps(sfs_dev_t *dev) {
  sfs_caps_t *c = &dev->caps;
  uint32_t c0 = rd(dev, SFS_REG_CAPS0);
  uint32_t c1 = rd(dev, SFS_REG_CAPS1);
  c->caps0_raw = c0;
  c->caps1_raw = c1;
  c->mdts_blocks = (c0 >> SFS_CAPS0_MDTS_SHIFT) & SFS_CAPS0_MDTS_MASK;
  c->sq_max = (c0 >> SFS_CAPS0_SQ_MAX_SHIFT) & SFS_CAPS0_SQ_MAX_MASK;
  c->cq_max = (c0 >> SFS_CAPS0_CQ_MAX_SHIFT) & SFS_CAPS0_CQ_MAX_MASK;
  c->block_shift = (c0 >> SFS_CAPS0_BLK_SHIFT_SHIFT) & SFS_CAPS0_BLK_SHIFT_MASK;
  c->discard = (c1 & SFS_CAPS1_DISCARD) != 0u;
  c->pi = (c1 & SFS_CAPS1_PI) != 0u;
  c->enc = (c1 & SFS_CAPS1_ENC) != 0u;
  c->fua = (c1 & SFS_CAPS1_FUA) != 0u;
  c->hcrc = (c1 & SFS_CAPS1_HCRC) != 0u;
  c->volatile_cache = (c1 & SFS_CAPS1_VOLATILE_CACHE) != 0u;
  c->backend_ready = (c1 & SFS_CAPS1_BACKEND_READY) != 0u;
  c->backend_type = (c1 >> SFS_CAPS1_BE_TYPE_SHIFT) & SFS_CAPS1_BE_TYPE_MASK;
  c->ns_mask = (c1 >> SFS_CAPS1_NS_MASK_SHIFT) & SFS_CAPS1_NS_MASK_MASK;
  return SFS_OK;
}

int sfs_dev_open(sfs_dev_t *dev, const sfs_transport_t *tp, unsigned tenant) {
  uint32_t id, ver;
  if (!dev || !tp || !tp->mmio_read32 || !tp->mmio_write32 || !tp->mem_alloc || !tp->mem_free || tenant > 0xFFFFu)
    return SFS_E_INVAL;
  memset(dev, 0, sizeof(*dev));
  dev->tp = *tp;
  dev->tenant = tenant;
  id = rd(dev, SFS_REG_ID);
  if (id != SFS_ID_MAGIC) return SFS_E_NO_DEVICE;
  ver = rd(dev, SFS_REG_VERSION);
  if ((ver >> 16) != (SFS_ABI_VERSION >> 16)) return SFS_E_VERSION;
  dev->caps.id = id;
  dev->caps.version = ver;
  read_caps(dev);
  if (dev->caps.block_shift != SFS_BLOCK_SHIFT) return SFS_E_VERSION;
  if (dev->caps.mdts_blocks < 1u || dev->caps.sq_max < 2u || dev->caps.cq_max < 2u) return SFS_E_UNSUPPORTED;
  dev->is_open = 1;
  return SFS_OK;
}

int sfs_dev_refresh_caps(sfs_dev_t *dev) {
  if (!dev || !dev->is_open) return SFS_E_STATE;
  return read_caps(dev);
}

const sfs_caps_t *sfs_dev_caps(const sfs_dev_t *dev) { return dev ? &dev->caps : NULL; }

int sfs_dev_owns_ns(const sfs_dev_t *dev, unsigned nsid) {
  return dev && nsid < 16u && ((dev->caps.ns_mask >> nsid) & 1u) != 0u;
}

int sfs_dev_first_ns(const sfs_dev_t *dev) {
  unsigned n;
  if (!dev) return -1;
  for (n = 0; n < 16u; ++n)
    if ((dev->caps.ns_mask >> n) & 1u) return (int)n;
  return -1;
}

int sfs_buf_alloc(sfs_dev_t *dev, size_t bytes, sfs_buf_t *buf) {
  uint64_t iova = 0;
  void *va = NULL;
  if (!dev || !dev->is_open || !buf || bytes == 0) return SFS_E_INVAL;
  if (dev->tp.mem_alloc(dev->tp.ctx, bytes, 64u, &iova, &va) != 0 || !va) return SFS_E_NOMEM;
  if ((iova & 3u) != 0u) {
    dev->tp.mem_free(dev->tp.ctx, iova);
    return SFS_E_ALIGN;
  }
  buf->iova = iova;
  buf->va = va;
  buf->len = bytes;
  return SFS_OK;
}

void sfs_buf_free(sfs_dev_t *dev, sfs_buf_t *buf) {
  if (!dev || !buf || !buf->va) return;
  dev->tp.mem_free(dev->tp.ctx, buf->iova);
  buf->iova = 0;
  buf->va = NULL;
  buf->len = 0;
}

/* ------------------------------------------------------------------------------------------ */
/* queue                                                                                       */
/* ------------------------------------------------------------------------------------------ */
static int hw_reset(const sfs_dev_t *dev) {
  uint32_t i;
  wr(dev, SFS_REG_CTRL, SFS_CTRL_RESET);
  for (i = 0; i < SFS_RESET_POLLS; ++i) {
    if ((rd(dev, SFS_REG_CTRL) & SFS_CTRL_RESET) == 0u) return SFS_OK;
    dev_yield(dev);
  }
  return SFS_E_TIMEOUT;
}

static void zero_rings(sfs_queue_t *q) {
  size_t i, n;
  memset(q->sq_va, 0, (size_t)q->sq_entries * SFS_DESC_BYTES);
  n = (size_t)q->cq_entries * SFS_CQE_BYTES;
  for (i = 0; i < n; ++i) q->cq_va[i] = 0u; /* CQ memory is zero: phase 0 */
}

static void reset_state(sfs_queue_t *q) {
  q->sq_tail = 0;
  q->sq_db = 0;
  q->sq_head_abs = 0;
  q->cq_head = 0;
  q->cq_db = 0;
  q->cq_unacked = 0;
  q->cq_phase = 1u; /* PHASE starts at 1 (§3) */
  q->submitted = 0;
  q->completed = 0;
}

/* program ring registers (queue disabled), enable, verify.  Rings must already be zeroed. */
static int program_and_enable(sfs_queue_t *q) {
  sfs_dev_t *d = q->dev;
  uint32_t st;
  wr(d, SFS_REG_IRQ_STATUS, SFS_IRQ_STATUS_W1C_MASK); /* clear stale sticky errors so DB_ERR below is ours */
  wr(d, SFS_REG_SQ_BASE_LO, (uint32_t)(q->sq_iova & 0xFFFFFFFFu));
  wr(d, SFS_REG_SQ_BASE_HI, (uint32_t)(q->sq_iova >> 32));
  wr(d, SFS_REG_SQ_SIZE, q->sq_entries);
  wr(d, SFS_REG_CQ_BASE_LO, (uint32_t)(q->cq_iova & 0xFFFFFFFFu));
  wr(d, SFS_REG_CQ_BASE_HI, (uint32_t)(q->cq_iova >> 32));
  wr(d, SFS_REG_CQ_SIZE, q->cq_entries);
  if (rd(d, SFS_REG_IRQ_STATUS) & SFS_IRQ_DB_ERR) { /* an illegal SQ_SIZE/CQ_SIZE is ignored and sets DB_ERR */
    wr(d, SFS_REG_IRQ_STATUS, SFS_IRQ_DB_ERR);
    return SFS_E_BAD_SIZE;
  }
  dev_barrier(d); /* zeroed CQ must be globally visible before the device may write it */
  wr(d, SFS_REG_CTRL, SFS_CTRL_ENABLE);
  st = rd(d, SFS_REG_STATUS);
  if ((st & SFS_STATUS_ENABLED) == 0u) return SFS_E_NOT_ENABLED;
  return SFS_OK;
}

int sfs_queue_create(sfs_dev_t *dev, sfs_queue_t *q, uint32_t sq_entries, uint32_t cq_entries) {
  uint64_t iova = 0;
  void *va = NULL;
  uint32_t st;
  int rc;
  if (!dev || !dev->is_open || !q) return SFS_E_INVAL;
  if (!is_pow2_ge2(sq_entries) || sq_entries > dev->caps.sq_max) return SFS_E_INVAL;
  if (!is_pow2_ge2(cq_entries) || cq_entries > dev->caps.cq_max) return SFS_E_INVAL;
  memset(q, 0, sizeof(*q));
  q->dev = dev;
  q->sq_entries = sq_entries;
  q->cq_entries = cq_entries;
  q->cq_batch = 1u;
  q->autoring = 0;
  q->next_txn = 1u;
  q->sync_polls = SFS_DEFAULT_SYNC_POLLS;
  sfs_lat_reset(&q->lat);

  /* start from a clean queue: stale enable/error bits or ring pointers would desynchronise us */
  st = rd(dev, SFS_REG_STATUS);
  if ((st & (SFS_STATUS_ENABLED | SFS_STATUS_SQ_ERR | SFS_STATUS_CQ_ERR | SFS_STATUS_FATAL)) != 0u ||
      rd(dev, SFS_REG_SQ_TAIL) != 0u || rd(dev, SFS_REG_CQ_HEAD) != 0u || rd(dev, SFS_REG_SQ_HEAD) != 0u ||
      rd(dev, SFS_REG_CQ_TAIL) != 0u) {
    rc = hw_reset(dev);
    if (rc) return rc;
  }

  if (dev->tp.mem_alloc(dev->tp.ctx, (size_t)sq_entries * SFS_DESC_BYTES, 64u, &iova, &va) != 0 || !va) return SFS_E_NOMEM;
  q->sq_iova = iova;
  q->sq_va = (uint8_t *)va;
  if ((iova & 63u) != 0u) {
    rc = SFS_E_ALIGN;
    goto fail_sq;
  }
  iova = 0;
  va = NULL;
  if (dev->tp.mem_alloc(dev->tp.ctx, (size_t)cq_entries * SFS_CQE_BYTES, 32u, &iova, &va) != 0 || !va) {
    rc = SFS_E_NOMEM;
    goto fail_sq;
  }
  q->cq_iova = iova;
  q->cq_va = (volatile uint8_t *)va;
  if ((iova & 31u) != 0u) {
    rc = SFS_E_ALIGN;
    goto fail_cq;
  }
  zero_rings(q);
  reset_state(q);
  rc = program_and_enable(q);
  if (rc) {
    wr(dev, SFS_REG_CTRL, 0u);
    goto fail_cq;
  }
  q->active = 1;
  return SFS_OK;

fail_cq:
  dev->tp.mem_free(dev->tp.ctx, q->cq_iova);
fail_sq:
  dev->tp.mem_free(dev->tp.ctx, q->sq_iova);
  q->active = 0;
  q->sq_va = NULL;
  q->cq_va = NULL;
  return rc;
}

int sfs_queue_destroy(sfs_queue_t *q) {
  sfs_dev_t *d;
  int rc;
  if (!q || !q->active) return SFS_E_STATE;
  d = q->dev;
  wr(d, SFS_REG_CTRL, 0u); /* disable */
  rc = hw_reset(d);        /* abort whatever is in flight, clear the device's ring pointers */
  d->tp.mem_free(d->tp.ctx, q->cq_iova);
  d->tp.mem_free(d->tp.ctx, q->sq_iova);
  q->active = 0;
  q->sq_va = NULL;
  q->cq_va = NULL;
  return rc;
}

int sfs_queue_reset(sfs_queue_t *q) {
  int rc;
  if (!q || !q->dev) return SFS_E_STATE;
  if (!q->sq_va) return SFS_E_STATE;
  q->active = 0;
  rc = hw_reset(q->dev);
  if (rc) return rc;
  zero_rings(q);
  reset_state(q);
  rc = program_and_enable(q);
  if (rc) return rc;
  q->active = 1;
  return SFS_OK;
}

void sfs_queue_set_autoring(sfs_queue_t *q, int on) { q->autoring = on ? 1 : 0; }
void sfs_queue_set_cq_batch(sfs_queue_t *q, unsigned n) { q->cq_batch = n ? n : 1u; }
void sfs_queue_set_sync_polls(sfs_queue_t *q, uint32_t polls) { q->sync_polls = polls; }
const sfs_lat_t *sfs_queue_latency(const sfs_queue_t *q) { return &q->lat; }

uint32_t sfs_inflight(const sfs_queue_t *q) { return (uint32_t)(q->submitted - q->completed); }

/* entries the fabric has not yet consumed, as far as we know (a safe over-estimate) */
static uint32_t sq_used(const sfs_queue_t *q) { return (uint32_t)(q->submitted - q->sq_head_abs); }

int sfs_sq_space(sfs_queue_t *q) {
  uint32_t used, cap, reg, adv, mask;
  if (!q || !q->active) return SFS_E_STATE;
  cap = q->sq_entries - 1u; /* one slot stays free (§8) */
  /* Every completion consumed implies its descriptor was fetched: free bookkeeping, no MMIO. */
  if (q->completed > q->sq_head_abs && q->completed <= q->submitted) q->sq_head_abs = q->completed;
  used = sq_used(q);
  if (used >= cap) {
    mask = q->sq_entries - 1u;
    reg = rd(q->dev, SFS_REG_SQ_HEAD) & mask;
    adv = (reg - (uint32_t)(q->sq_head_abs & mask)) & mask;
    if (adv <= used) q->sq_head_abs += adv; /* the register is current: the head can only be in [known, tail] */
    used = sq_used(q);
  }
  return (int)(cap - used);
}

int sfs_ring(sfs_queue_t *q) {
  if (!q || !q->active) return SFS_E_STATE;
  if (q->sq_db == q->sq_tail) return SFS_OK;
  dev_barrier(q->dev); /* descriptor stores before the doorbell (§8 step 4) */
  wr(q->dev, SFS_REG_SQ_TAIL, q->sq_tail);
  q->sq_db = q->sq_tail;
  return SFS_OK;
}

static int sq_place(sfs_queue_t *q, const uint32_t w[SFS_DESC_WORDS]) {
  uint8_t *slot;
  unsigned i;
  int space;
  if (!q || !q->active) return SFS_E_STATE;
  space = sfs_sq_space(q);
  if (space < 0) return space;
  if (space == 0) return SFS_E_FULL;
  slot = q->sq_va + (size_t)q->sq_tail * SFS_DESC_BYTES;
  for (i = 0; i < SFS_DESC_WORDS; ++i) st_le32(slot + 4u * i, w[i]);
  q->sq_tail = (q->sq_tail + 1u) & (q->sq_entries - 1u);
  q->submitted++;
  if (q->autoring) return sfs_ring(q);
  return SFS_OK;
}

int sfs_submit_raw(sfs_queue_t *q, const uint32_t w[SFS_DESC_WORDS]) {
  if (!w) return SFS_E_INVAL;
  return sq_place(q, w);
}

int sfs_submit_desc(sfs_queue_t *q, const sfs_desc_t *d) {
  uint32_t w[SFS_DESC_WORDS];
  if (!d) return SFS_E_INVAL;
  sfs_desc_pack(d, w);
  return sq_place(q, w);
}

static void desc_init(const sfs_queue_t *q, sfs_desc_t *d, uint8_t op, uint16_t txn, unsigned nsid) {
  memset(d, 0, sizeof(*d));
  d->version = SFS_DESC_VERSION;
  d->opcode = op;
  d->txn = txn;
  d->nsid = (uint8_t)nsid;
  d->tenant_claim = (uint16_t)q->dev->tenant;
}

static int rw_args_ok(const sfs_queue_t *q, unsigned nsid, uint32_t nblk, uint64_t iova) {
  if (!q || !q->active) return SFS_E_STATE;
  if (nsid > 0xFFu) return SFS_E_INVAL;
  if (nblk < 1u || nblk > q->dev->caps.mdts_blocks) return SFS_E_INVAL;
  if ((iova & 3u) != 0u) return SFS_E_INVAL;
  return SFS_OK;
}

int sfs_submit_read(sfs_queue_t *q, uint16_t txn, unsigned nsid, uint64_t lba, uint32_t nblk, uint64_t data_iova,
                    uint32_t flags) {
  sfs_desc_t d;
  int rc = rw_args_ok(q, nsid, nblk, data_iova);
  if (rc) return rc;
  if ((flags & ~(uint32_t)SFS_F_RCRC) != 0u) return SFS_E_INVAL; /* FUA/HCRC are WRITE-only (§2) */
  desc_init(q, &d, SFS_OP_READ, txn, nsid);
  d.flags = (uint16_t)flags;
  d.lba = lba;
  d.nblk = nblk;
  d.data_len = nblk * SFS_BLOCK_BYTES;
  d.data_addr = data_iova;
  return sfs_submit_desc(q, &d);
}

int sfs_submit_write_crc(sfs_queue_t *q, uint16_t txn, unsigned nsid, uint64_t lba, uint32_t nblk, uint64_t data_iova,
                         uint32_t flags, uint32_t host_crc) {
  sfs_desc_t d;
  int rc = rw_args_ok(q, nsid, nblk, data_iova);
  if (rc) return rc;
  if ((flags & ~(uint32_t)(SFS_F_FUA | SFS_F_HCRC | SFS_F_RCRC)) != 0u) return SFS_E_INVAL;
  if ((flags & SFS_F_FUA) && !q->dev->caps.fua) return SFS_E_UNSUPPORTED;
  if ((flags & SFS_F_HCRC) && !q->dev->caps.hcrc) return SFS_E_UNSUPPORTED;
  desc_init(q, &d, SFS_OP_WRITE, txn, nsid);
  d.flags = (uint16_t)flags;
  d.lba = lba;
  d.nblk = nblk;
  d.data_len = nblk * SFS_BLOCK_BYTES;
  d.data_addr = data_iova;
  d.host_crc = (flags & SFS_F_HCRC) ? host_crc : 0u; /* must be 0 without HCRC (§2) */
  return sfs_submit_desc(q, &d);
}

int sfs_submit_write(sfs_queue_t *q, uint16_t txn, unsigned nsid, uint64_t lba, uint32_t nblk, uint64_t data_iova,
                     const void *data_va, uint32_t flags) {
  uint32_t crc = 0u;
  if (flags & SFS_F_HCRC) {
    if (!data_va || nblk < 1u) return SFS_E_INVAL;
    crc = sfs_crc32c(data_va, (size_t)nblk * SFS_BLOCK_BYTES);
  }
  return sfs_submit_write_crc(q, txn, nsid, lba, nblk, data_iova, flags, crc);
}

int sfs_submit_flush(sfs_queue_t *q, uint16_t txn, unsigned nsid) {
  sfs_desc_t d;
  if (!q || !q->active) return SFS_E_STATE;
  if (nsid > 0xFFu) return SFS_E_INVAL;
  desc_init(q, &d, SFS_OP_FLUSH, txn, nsid);
  return sfs_submit_desc(q, &d);
}

int sfs_submit_get_capacity(sfs_queue_t *q, uint16_t txn, unsigned nsid) {
  sfs_desc_t d;
  if (!q || !q->active) return SFS_E_STATE;
  if (nsid > 0xFFu) return SFS_E_INVAL;
  desc_init(q, &d, SFS_OP_GET_CAPACITY, txn, nsid);
  return sfs_submit_desc(q, &d);
}

int sfs_submit_discard(sfs_queue_t *q, uint16_t txn, unsigned nsid, uint64_t lba, uint32_t nblk) {
  sfs_desc_t d;
  if (!q || !q->active) return SFS_E_STATE;
  if (nsid > 0xFFu || nblk < 1u || nblk > SFS_DISCARD_MAX) return SFS_E_INVAL;
  if (!q->dev->caps.discard) return SFS_E_UNSUPPORTED;
  desc_init(q, &d, SFS_OP_DISCARD, txn, nsid);
  d.lba = lba;
  d.nblk = nblk;
  return sfs_submit_desc(q, &d);
}

/* ------------------------------------------------------------------------------------------ */
/* completions                                                                                 */
/* ------------------------------------------------------------------------------------------ */
int sfs_cq_doorbell(sfs_queue_t *q) {
  if (!q || !q->active) return SFS_E_STATE;
  if (q->cq_unacked == 0u) return SFS_OK;
  dev_barrier(q->dev); /* our reads of the consumed entries complete before the slots can be reused */
  wr(q->dev, SFS_REG_CQ_HEAD, q->cq_head);
  q->cq_db = q->cq_head;
  q->cq_unacked = 0u;
  return SFS_OK;
}

int sfs_poll(sfs_queue_t *q, sfs_cqe_t *cqe) {
  const volatile uint8_t *e;
  uint32_t w[SFS_CQE_WORDS];
  uint32_t i;
  if (!q || !q->active) return SFS_E_STATE;
  e = q->cq_va + (size_t)q->cq_head * SFS_CQE_BYTES;
  w[7] = ldv_le32(e + 28u); /* PHASE word first (§3) */
  if ((w[7] & 1u) != q->cq_phase) return 0;
  dev_barrier(q->dev); /* acquire: the remaining words are read only after the phase was seen */
  for (i = 0; i < 7u; ++i) w[i] = ldv_le32(e + 4u * i);
  if (cqe) sfs_cqe_unpack(w, cqe);
  sfs_lat_add(&q->lat, w[5]);
  q->completed++;
  q->cq_head++;
  if (q->cq_head == q->cq_entries) {
    q->cq_head = 0u;
    q->cq_phase ^= 1u; /* expected phase toggles on every wrap */
  }
  q->cq_unacked++;
  if (q->cq_unacked >= q->cq_batch) {
    int rc = sfs_cq_doorbell(q);
    if (rc) return rc;
  }
  return 1;
}

int sfs_wait(sfs_queue_t *q, sfs_cqe_t *cqe, uint32_t max_polls) {
  uint32_t n;
  int rc;
  if (!q || !q->active) return SFS_E_STATE;
  rc = sfs_ring(q); /* never wait for something that was not announced */
  if (rc) return rc;
  for (n = 0;; ++n) {
    rc = sfs_poll(q, cqe);
    if (rc > 0) return SFS_OK;
    if (rc < 0) return rc;
    if (q->cq_unacked) {
      rc = sfs_cq_doorbell(q); /* a batched head update must not starve the device of CQ space */
      if (rc) return rc;
    }
    if (max_polls != SFS_WAIT_FOREVER && n + 1u >= max_polls) return SFS_E_TIMEOUT;
    dev_yield(q->dev);
  }
}

/* ------------------------------------------------------------------------------------------ */
/* synchronous wrappers                                                                        */
/* ------------------------------------------------------------------------------------------ */
static uint16_t next_txn(sfs_queue_t *q) {
  uint16_t t = q->next_txn;
  q->next_txn = (uint16_t)(q->next_txn + 1u);
  if (q->next_txn == SFS_CQE_TXN_NO_DESC || q->next_txn == 0u) q->next_txn = 1u; /* 0xFFFF is reserved by §3 */
  return t;
}

static int sync_finish(sfs_queue_t *q, uint16_t txn, sfs_cqe_t *cqe_out) {
  sfs_cqe_t c;
  int rc = sfs_ring(q);
  if (rc) return rc;
  rc = sfs_wait(q, &c, q->sync_polls);
  if (rc) return rc;
  if (cqe_out) *cqe_out = c;
  if (c.txn != txn) return SFS_E_PROTO;
  return c.status == SFS_ST_SUCCESS ? SFS_OK : SFS_E_STATUS;
}

static int sync_begin(sfs_queue_t *q) {
  if (!q || !q->active) return SFS_E_STATE;
  if (sfs_inflight(q) != 0u) return SFS_E_BUSY;
  return SFS_OK;
}

int sfs_read_sync(sfs_queue_t *q, unsigned nsid, uint64_t lba, uint32_t nblk, uint64_t data_iova, uint32_t flags,
                  sfs_cqe_t *cqe_out) {
  int rc = sync_begin(q);
  uint16_t txn;
  if (rc) return rc;
  txn = next_txn(q);
  rc = sfs_submit_read(q, txn, nsid, lba, nblk, data_iova, flags);
  return rc ? rc : sync_finish(q, txn, cqe_out);
}

int sfs_write_sync(sfs_queue_t *q, unsigned nsid, uint64_t lba, uint32_t nblk, uint64_t data_iova, const void *data_va,
                   uint32_t flags, sfs_cqe_t *cqe_out) {
  int rc = sync_begin(q);
  uint16_t txn;
  if (rc) return rc;
  txn = next_txn(q);
  rc = sfs_submit_write(q, txn, nsid, lba, nblk, data_iova, data_va, flags);
  return rc ? rc : sync_finish(q, txn, cqe_out);
}

int sfs_flush_sync(sfs_queue_t *q, unsigned nsid, sfs_cqe_t *cqe_out) {
  int rc = sync_begin(q);
  uint16_t txn;
  if (rc) return rc;
  txn = next_txn(q);
  rc = sfs_submit_flush(q, txn, nsid);
  return rc ? rc : sync_finish(q, txn, cqe_out);
}

int sfs_discard_sync(sfs_queue_t *q, unsigned nsid, uint64_t lba, uint32_t nblk, sfs_cqe_t *cqe_out) {
  int rc = sync_begin(q);
  uint16_t txn;
  if (rc) return rc;
  txn = next_txn(q);
  rc = sfs_submit_discard(q, txn, nsid, lba, nblk);
  return rc ? rc : sync_finish(q, txn, cqe_out);
}

int sfs_capacity_sync(sfs_queue_t *q, unsigned nsid, uint64_t *blocks, sfs_cqe_t *cqe_out) {
  sfs_cqe_t c;
  int rc = sync_begin(q);
  uint16_t txn;
  if (rc) return rc;
  txn = next_txn(q);
  rc = sfs_submit_get_capacity(q, txn, nsid);
  if (rc) return rc;
  rc = sync_finish(q, txn, &c);
  if (cqe_out) *cqe_out = c;
  if (rc == SFS_OK && blocks) *blocks = sfs_cqe_capacity(&c);
  return rc;
}

/* ------------------------------------------------------------------------------------------ */
/* queue status, perf                                                                          */
/* ------------------------------------------------------------------------------------------ */
int sfs_queue_status(sfs_queue_t *q, sfs_qstatus_t *out) {
  const sfs_dev_t *d;
  if (!q || !q->dev || !out) return SFS_E_INVAL;
  d = q->dev;
  out->status_raw = rd(d, SFS_REG_STATUS);
  out->irq_raw = rd(d, SFS_REG_IRQ_STATUS);
  out->enabled = (out->status_raw & SFS_STATUS_ENABLED) != 0u;
  out->sq_err = (out->status_raw & SFS_STATUS_SQ_ERR) != 0u;
  out->cq_err = (out->status_raw & SFS_STATUS_CQ_ERR) != 0u;
  out->fatal = (out->status_raw & SFS_STATUS_FATAL) != 0u;
  out->sq_empty = (out->status_raw & SFS_STATUS_SQ_EMPTY) != 0u;
  out->idle = (out->status_raw & SFS_STATUS_IDLE) != 0u;
  out->last_err = (out->status_raw >> SFS_STATUS_LAST_ERR_SHIFT) & SFS_STATUS_LAST_ERR_MASK;
  out->irq_cq_nonempty = (out->irq_raw & SFS_IRQ_CQ_NONEMPTY) != 0u;
  out->irq_queue_err = (out->irq_raw & SFS_IRQ_QUEUE_ERR) != 0u;
  out->irq_db_err = (out->irq_raw & SFS_IRQ_DB_ERR) != 0u;
  out->sq_head = rd(d, SFS_REG_SQ_HEAD);
  out->cq_tail = rd(d, SFS_REG_CQ_TAIL);
  out->sq_tail = rd(d, SFS_REG_SQ_TAIL);
  out->cq_head = rd(d, SFS_REG_CQ_HEAD);
  out->inflight = rd(d, SFS_REG_INFLIGHT);
  return SFS_OK;
}

int sfs_queue_ack_irq(sfs_queue_t *q, uint32_t mask) {
  if (!q || !q->dev) return SFS_E_INVAL;
  wr(q->dev, SFS_REG_IRQ_STATUS, mask & SFS_IRQ_STATUS_W1C_MASK);
  return SFS_OK;
}

void sfs_qstatus_str(const sfs_qstatus_t *s, char *buf, size_t n) {
  size_t used = 0;
  int w;
  if (!buf || n == 0) return;
  buf[0] = '\0';
  if (!s) return;
#define SFS_APPEND(...)                                                  \
  do {                                                                   \
    if (used < n) {                                                      \
      w = snprintf(buf + used, n - used, __VA_ARGS__);                   \
      if (w > 0) used += (size_t)w;                                      \
    }                                                                    \
  } while (0)
  SFS_APPEND("%s", s->enabled ? "ENABLED" : "DISABLED");
  if (s->sq_err) SFS_APPEND(" SQ_ERR");
  if (s->cq_err) SFS_APPEND(" CQ_ERR");
  if (s->fatal) SFS_APPEND(" FATAL");
  if (s->sq_empty) SFS_APPEND(" SQ_EMPTY");
  if (s->idle) SFS_APPEND(" IDLE");
  SFS_APPEND(" last_err=0x%02x", (unsigned)s->last_err);
  if (s->irq_queue_err) SFS_APPEND(" IRQ_QUEUE_ERR");
  if (s->irq_db_err) SFS_APPEND(" DB_ERR");
#undef SFS_APPEND
  if (used >= n) buf[n - 1u] = '\0';
}

int sfs_perf_read(sfs_dev_t *dev, sfs_perf_t *out) {
  if (!dev || !dev->is_open || !out) return SFS_E_INVAL;
  out->inflight = rd(dev, SFS_REG_INFLIGHT);
  out->done = rd(dev, SFS_REG_CNT_DONE);
  out->err = rd(dev, SFS_REG_CNT_ERR);
  out->rd_blk = rd(dev, SFS_REG_CNT_RD_BLK);
  out->wr_blk = rd(dev, SFS_REG_CNT_WR_BLK);
  out->flush = rd(dev, SFS_REG_CNT_FLUSH);
  out->throttle = rd(dev, SFS_REG_CNT_THROTTLE);
  out->viol = rd(dev, SFS_REG_CNT_VIOL);
  out->bytes_lo = rd(dev, SFS_REG_CNT_BYTES_LO);
  return SFS_OK;
}

/* ------------------------------------------------------------------------------------------ */
/* management window (hypervisor side)                                                         */
/* ------------------------------------------------------------------------------------------ */
static uint32_t mrd(const sfs_mgmt_t *m, uint32_t off) { return m->tp.mmio_read32(m->tp.ctx, off); }
static void mwr(const sfs_mgmt_t *m, uint32_t off, uint32_t v) { m->tp.mmio_write32(m->tp.ctx, off, v); }

int sfs_mgmt_open(sfs_mgmt_t *mg, const sfs_mgmt_transport_t *tp) {
  uint32_t g0, g1, ver;
  if (!mg || !tp || !tp->mmio_read32 || !tp->mmio_write32) return SFS_E_INVAL;
  memset(mg, 0, sizeof(*mg));
  mg->tp = *tp;
  if (mrd(mg, SFS_MG_REG_ID) != SFS_MG_ID_MAGIC) return SFS_E_NO_DEVICE;
  ver = mrd(mg, SFS_MG_REG_VERSION);
  if ((ver >> 16) != (SFS_ABI_VERSION >> 16)) return SFS_E_VERSION;
  g0 = mrd(mg, SFS_MG_REG_GCAPS0);
  g1 = mrd(mg, SFS_MG_REG_GCAPS1);
  mg->caps.nt = (g0 >> SFS_GCAPS0_NT_SHIFT) & 0xFFu;
  mg->caps.nslot = (g0 >> SFS_GCAPS0_NSLOT_SHIFT) & 0xFFu;
  mg->caps.ns_n = (g0 >> SFS_GCAPS0_NS_N_SHIFT) & 0xFFu;
  mg->caps.mdts_blocks = (g0 >> SFS_GCAPS0_MDTS_SHIFT) & 0xFFu;
  mg->caps.sq_max = (g1 >> SFS_GCAPS1_SQ_MAX_SHIFT) & 0xFFu;
  mg->caps.cq_max = (g1 >> SFS_GCAPS1_CQ_MAX_SHIFT) & 0xFFu;
  mg->caps.xts = (g1 & SFS_GCAPS1_XTS) != 0u;
  mg->caps.virtio = (g1 & SFS_GCAPS1_VIRTIO) != 0u;
  mg->caps.backend_type = (g1 >> SFS_GCAPS1_BE_TYPE_SHIFT) & SFS_GCAPS1_BE_TYPE_MASK;
  mg->gctrl = 0u; /* ENABLE is 0 at reset (§9) */
  mg->is_open = 1;
  return SFS_OK;
}

#define MG_CHECK(mg) \
  do {               \
    if (!(mg) || !(mg)->is_open) return SFS_E_STATE; \
  } while (0)

int sfs_mgmt_set_gctrl(sfs_mgmt_t *mg, uint32_t flags) {
  MG_CHECK(mg);
  if ((flags & ~(uint32_t)SFS_GCTRL_RW_MASK) != 0u) return SFS_E_INVAL;
  mg->gctrl = flags;
  mwr(mg, SFS_MG_REG_GCTRL, mg->gctrl);
  return SFS_OK;
}

int sfs_mgmt_enable_fabric(sfs_mgmt_t *mg, int enable) {
  uint32_t f;
  MG_CHECK(mg);
  f = enable ? (mg->gctrl | SFS_GCTRL_ENABLE) : (mg->gctrl & ~(uint32_t)SFS_GCTRL_ENABLE);
  return sfs_mgmt_set_gctrl(mg, f);
}

int sfs_mgmt_soft_reset(sfs_mgmt_t *mg) {
  MG_CHECK(mg);
  mwr(mg, SFS_MG_REG_GCTRL, mg->gctrl | SFS_GCTRL_SOFT_RESET);
  return SFS_OK;
}

int sfs_mgmt_clear_counters(sfs_mgmt_t *mg) {
  MG_CHECK(mg);
  mwr(mg, SFS_MG_REG_GCTRL, mg->gctrl | SFS_GCTRL_CLR_COUNTERS);
  return SFS_OK;
}

int sfs_mgmt_gstatus(sfs_mgmt_t *mg, sfs_gstatus_t *out) {
  MG_CHECK(mg);
  if (!out) return SFS_E_INVAL;
  out->raw = mrd(mg, SFS_MG_REG_GSTATUS);
  out->backend_ready = (out->raw & SFS_GSTATUS_BE_READY) != 0u;
  out->pf_quiesce = (out->raw & SFS_GSTATUS_PF_QUIESCE) != 0u;
  out->fatal = (out->raw & SFS_GSTATUS_FATAL) != 0u;
  out->busy_slots = (out->raw >> SFS_GSTATUS_BUSY_SLOTS_SHIFT) & 0xFFu;
  out->backend_busy = (out->raw >> SFS_GSTATUS_BE_BUSY_SHIFT) & 0xFFu;
  return SFS_OK;
}

int sfs_mgmt_set_cmd_timeout(sfs_mgmt_t *mg, uint32_t cycles) {
  MG_CHECK(mg);
  mwr(mg, SFS_MG_REG_CMD_TIMEOUT, cycles);
  return SFS_OK;
}

int sfs_mgmt_set_sched(sfs_mgmt_t *mg, uint32_t wr_batch_max, uint32_t wr_age_max) {
  MG_CHECK(mg);
  if (wr_batch_max > 0xFFu || wr_age_max > 0xFFu) return SFS_E_INVAL;
  mwr(mg, SFS_MG_REG_SCHED_CFG,
      (wr_batch_max << SFS_SCHED_WR_BATCH_MAX_SHIFT) | (wr_age_max << SFS_SCHED_WR_AGE_MAX_SHIFT));
  return SFS_OK;
}

int sfs_mgmt_force_power_fail(sfs_mgmt_t *mg, int on) {
  MG_CHECK(mg);
  mwr(mg, SFS_MG_REG_PF_CTRL, on ? SFS_PF_FORCE_WARN : 0u);
  return SFS_OK;
}

static uint32_t tcfg_off(unsigned t, uint32_t reg) { return SFS_MG_TCFG_BASE + SFS_MG_TCFG_STRIDE * t + reg; }
static uint32_t ns_off(unsigned n, uint32_t reg) { return SFS_MG_NS_BASE + SFS_MG_NS_STRIDE * n + reg; }

int sfs_mgmt_tenant_cfg(sfs_mgmt_t *mg, unsigned tenant, const sfs_tcfg_t *cfg) {
  MG_CHECK(mg);
  if (!cfg || tenant >= mg->caps.nt) return SFS_E_INVAL;
  if (cfg->weight > 255u) return SFS_E_INVAL;
  /* program the limits first, ENABLE_ALLOWED last: the queue may only start once its limits are in place */
  mwr(mg, tcfg_off(tenant, SFS_TCFG_MAX_INFLIGHT), cfg->max_inflight);
  mwr(mg, tcfg_off(tenant, SFS_TCFG_WEIGHT), cfg->weight);
  mwr(mg, tcfg_off(tenant, SFS_TCFG_RATE), cfg->rate);
  mwr(mg, tcfg_off(tenant, SFS_TCFG_BURST), cfg->burst);
  mwr(mg, tcfg_off(tenant, SFS_TCFG_ENABLE_ALLOWED), cfg->enable_allowed ? 1u : 0u);
  return SFS_OK;
}

int sfs_mgmt_tenant_allow(sfs_mgmt_t *mg, unsigned tenant, int allow) {
  MG_CHECK(mg);
  if (tenant >= mg->caps.nt) return SFS_E_INVAL;
  mwr(mg, tcfg_off(tenant, SFS_TCFG_ENABLE_ALLOWED), allow ? 1u : 0u);
  return SFS_OK;
}

int sfs_mgmt_ns_config(sfs_mgmt_t *mg, unsigned nsid, const sfs_ns_cfg_t *cfg, uint32_t *ns_status) {
  uint32_t flags, st;
  MG_CHECK(mg);
  if (!cfg || nsid >= mg->caps.ns_n) return SFS_E_INVAL;
  if (cfg->owner > SFS_NSC_OWNER_MASK || cfg->key_slot > SFS_NSC_KEY_SLOT_MASK) return SFS_E_INVAL;
  flags = (cfg->readonly ? SFS_NSC_READONLY : 0u) | (cfg->enc ? SFS_NSC_ENC_EN : 0u) | (cfg->pi ? SFS_NSC_PI_EN : 0u) |
          (cfg->owner << SFS_NSC_OWNER_SHIFT) | (cfg->key_slot << SFS_NSC_KEY_SLOT_SHIFT);
  mwr(mg, ns_off(nsid, SFS_NS_CTRL), 0u); /* VALID = 0: BASE/SIZE/flags are writable only then */
  mwr(mg, ns_off(nsid, SFS_NS_BASE_LO), (uint32_t)(cfg->base & 0xFFFFFFFFu));
  mwr(mg, ns_off(nsid, SFS_NS_BASE_HI), (uint32_t)(cfg->base >> 32));
  mwr(mg, ns_off(nsid, SFS_NS_SIZE_LO), (uint32_t)(cfg->size & 0xFFFFFFFFu));
  mwr(mg, ns_off(nsid, SFS_NS_SIZE_HI), (uint32_t)(cfg->size >> 32));
  mwr(mg, ns_off(nsid, SFS_NS_CTRL), flags);               /* flags, still invalid */
  mwr(mg, ns_off(nsid, SFS_NS_CTRL), flags | SFS_NSC_VALID); /* writing VALID = 1 validates */
  st = mrd(mg, ns_off(nsid, SFS_NS_STATUS));
  if (ns_status) *ns_status = st;
  return (st & SFS_NSS_ACCEPTED) ? SFS_OK : SFS_E_REFUSED;
}

int sfs_mgmt_ns_invalidate(sfs_mgmt_t *mg, unsigned nsid) {
  MG_CHECK(mg);
  if (nsid >= mg->caps.ns_n) return SFS_E_INVAL;
  mwr(mg, ns_off(nsid, SFS_NS_CTRL), 0u);
  return SFS_OK;
}

static int pt_commit(sfs_mgmt_t *mg, uint32_t valid) {
  mwr(mg, SFS_MG_PT_BASE + SFS_PT_CTRL, valid);
  mwr(mg, SFS_MG_PT_BASE + SFS_PT_CTRL, valid | SFS_PT_CTRL_COMMIT);
  return (mrd(mg, SFS_MG_PT_BASE + SFS_PT_STATUS) & SFS_PT_STATUS_REJECTED) ? SFS_E_REFUSED : SFS_OK;
}

int sfs_mgmt_dma_window(sfs_mgmt_t *mg, unsigned idx, const sfs_dma_window_t *w) {
  MG_CHECK(mg);
  if (!w || idx < mg->caps.nt || idx >= SFS_PT_ENTRIES) return SFS_E_INVAL; /* 0..NT-1 are the fabric's own windows */
  mwr(mg, SFS_MG_PT_BASE + SFS_PT_IDX, idx);
  mwr(mg, SFS_MG_PT_BASE + SFS_PT_DOM, w->domain);
  mwr(mg, SFS_MG_PT_BASE + SFS_PT_BASE_LO, (uint32_t)(w->base & 0xFFFFFFFFu));
  mwr(mg, SFS_MG_PT_BASE + SFS_PT_BASE_HI, (uint32_t)(w->base >> 32));
  mwr(mg, SFS_MG_PT_BASE + SFS_PT_SIZE_LO, (uint32_t)(w->size & 0xFFFFFFFFu));
  mwr(mg, SFS_MG_PT_BASE + SFS_PT_SIZE_HI, (uint32_t)(w->size >> 32));
  mwr(mg, SFS_MG_PT_BASE + SFS_PT_PERM, (w->perm_r ? SFS_PT_PERM_R : 0u) | (w->perm_w ? SFS_PT_PERM_W : 0u));
  return pt_commit(mg, SFS_PT_CTRL_VALID);
}

int sfs_mgmt_dma_window_clear(sfs_mgmt_t *mg, unsigned idx) {
  MG_CHECK(mg);
  if (idx < mg->caps.nt || idx >= SFS_PT_ENTRIES) return SFS_E_INVAL;
  mwr(mg, SFS_MG_PT_BASE + SFS_PT_IDX, idx);
  return pt_commit(mg, 0u);
}

int sfs_mgmt_backend_info(sfs_mgmt_t *mg, sfs_be_info_t *out) {
  MG_CHECK(mg);
  if (!out) return SFS_E_INVAL;
  out->type = mrd(mg, SFS_MG_BE_BASE + SFS_BE_TYPE);
  out->caps = mrd(mg, SFS_MG_BE_BASE + SFS_BE_CAPS);
  out->capacity_blocks = (uint64_t)mrd(mg, SFS_MG_BE_BASE + SFS_BE_CAP_LO) |
                         ((uint64_t)mrd(mg, SFS_MG_BE_BASE + SFS_BE_CAP_HI) << 32);
  return SFS_OK;
}

int sfs_mgmt_backend_reset(sfs_mgmt_t *mg) {
  MG_CHECK(mg);
  mwr(mg, SFS_MG_BE_BASE + SFS_BE_CTRL, SFS_BE_CTRL_RESET);
  return SFS_OK;
}

int sfs_mgmt_key_load(sfs_mgmt_t *mg, unsigned slot, const uint8_t key[SFS_KEY_BYTES]) {
  unsigned i;
  MG_CHECK(mg);
  if (!key || slot > 15u) return SFS_E_INVAL;
  mwr(mg, SFS_MG_KEY_BASE + SFS_KEY_SEL, slot);
  for (i = 0; i < SFS_KEY_WORDS; ++i) mwr(mg, SFS_MG_KEY_BASE + SFS_KEY_W0 + 4u * i, ld_le32(key + 4u * i));
  mwr(mg, SFS_MG_KEY_BASE + SFS_KEY_CTRL, SFS_KEY_CTRL_COMMIT);
  return SFS_OK;
}

int sfs_mgmt_key_zeroize(sfs_mgmt_t *mg, unsigned slot) {
  MG_CHECK(mg);
  if (slot > 15u) return SFS_E_INVAL;
  mwr(mg, SFS_MG_KEY_BASE + SFS_KEY_SEL, slot);
  mwr(mg, SFS_MG_KEY_BASE + SFS_KEY_CTRL, SFS_KEY_CTRL_ZEROIZE);
  return SFS_OK;
}

int sfs_mgmt_perf_read(sfs_mgmt_t *mg, uint32_t sel, uint64_t *value) {
  uint32_t lo, hi;
  MG_CHECK(mg);
  if (!value) return SFS_E_INVAL;
  mwr(mg, SFS_MG_PERF_BASE + SFS_PERF_SEL, sel);
  lo = mrd(mg, SFS_MG_PERF_BASE + SFS_PERF_LO); /* reading LO latches HI: LO must come first */
  hi = mrd(mg, SFS_MG_PERF_BASE + SFS_PERF_HI);
  *value = (uint64_t)lo | ((uint64_t)hi << 32);
  return SFS_OK;
}

int sfs_mgmt_trace_status(sfs_mgmt_t *mg, uint32_t *entries, uint32_t *dropped) {
  uint32_t s;
  MG_CHECK(mg);
  s = mrd(mg, SFS_MG_TR_BASE + SFS_TR_STAT);
  if (entries) *entries = s & 0xFFFFu;
  if (dropped) *dropped = s >> 16;
  return SFS_OK;
}

int sfs_mgmt_trace_pop(sfs_mgmt_t *mg, sfs_trace_rec_t *rec) {
  uint32_t s, w[SFS_TR_WORDS];
  unsigned i;
  MG_CHECK(mg);
  if (!rec) return SFS_E_INVAL;
  s = mrd(mg, SFS_MG_TR_BASE + SFS_TR_STAT);
  if ((s & 0xFFFFu) == 0u) return 0;
  for (i = 0; i < SFS_TR_WORDS; ++i) w[i] = mrd(mg, SFS_MG_TR_BASE + SFS_TR_W0 + 4u * i);
  mwr(mg, SFS_MG_TR_BASE + SFS_TR_POP, 1u);
  rec->txn = (uint16_t)(w[0] & 0xFFFFu);
  rec->tenant = (w[0] >> 16) & 0xFFu;
  rec->opcode = (uint8_t)((w[0] >> 24) & 0xFFu);
  rec->status = (uint8_t)(w[1] & 0xFFu);
  rec->detail = (uint8_t)((w[1] >> 8) & 0xFFu);
  rec->nblk = (uint16_t)(w[1] >> 16);
  rec->cyc_fetch = w[2];
  rec->cyc_admit = w[3];
  rec->cyc_issue = w[4];
  rec->cyc_be_done = w[5];
  rec->cyc_post = w[6];
  rec->durable = (int)((w[7] >> 31) & 1u);
  rec->bytes = w[7] & 0x7FFFFFFFu;
  for (i = 0; i < SFS_TR_WORDS; ++i) rec->raw[i] = w[i];
  return 1;
}

uint32_t sfs_trace_queue_wait(const sfs_trace_rec_t *rec) { return rec->cyc_admit - rec->cyc_fetch; }
