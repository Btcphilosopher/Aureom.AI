// mock_fabric.hpp - a software StorageFabric used to test libsfstor.
//
// Implements, from docs/02_HOST_INTERFACE.md only: the tenant MMIO page (§8), the management window
// (§9) and the SQ/CQ ring protocol (§2,§3,§5) on top of memory the transport hands out.  Command
// validation and execution use sfref::Model (model/sfref.hpp); the mock adds only what the logical model
// does not know: DMA translation (own-tenant allocations are the "DMA windows"), ring mechanics,
// doorbell checking, registers, tracing and fault injection.
//
// The mock also *polices the host library*: it counts ABI violations (`abi_errors`) such as misaligned
// ring bases, a CQ that was not zeroed before ENABLE, or register accesses to undefined offsets
// (`bus_errors`); tests assert these stay 0.
#ifndef MOCK_FABRIC_HPP
#define MOCK_FABRIC_HPP

#include <array>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "sfref.hpp"
#include "sfstor_regs.h"

class MockFabric {
 public:
  struct Cfg {
    bool vol = true, discard = true, discard_zero = true, pi_native = true;
    unsigned nt = 2;
    unsigned sq_max = 64, cq_max = 64;
    uint64_t capacity = 1u << 20;
  };

  // ------------------------------------------------------------------ memory (IOVA space)
  struct Alloc {
    uint64_t iova;
    size_t len;
    unsigned tenant;
    void* p;
  };
  // fault-injection knobs for the allocator
  int fail_alloc_after = -1;  // >= 0: that many allocations still succeed, then one fails
  bool misalign_alloc = false;
  bool page_align_cq = false;   // give 32-byte-aligned (CQ) allocations their own 4 KiB page (for the access-order probe)
  int fetch_budget = -1;        // >= 0: the device fetches at most this many more descriptors, then stops

  int alloc(unsigned tenant, size_t bytes, size_t align, uint64_t* iova, void** va) {
    if (fail_alloc_after == 0) { fail_alloc_after = -1; return -1; }
    if (fail_alloc_after > 0) --fail_alloc_after;
    if (align < 8) align = 8;
    if (page_align_cq && align == 32) { align = 4096; bytes = (bytes + 4095) / 4096 * 4096; }
    size_t rounded = (bytes + align - 1) / align * align;
    void* p = std::aligned_alloc(align, rounded);
    if (!p) return -1;
    std::memset(p, 0xA7, rounded);  // poison: the library must not rely on zeroed memory it did not zero
    next_iova_ = (next_iova_ + align - 1) / align * align;
    Alloc a{next_iova_, rounded, tenant, p};
    next_iova_ += rounded + 4096;
    allocs_[a.iova] = a;
    *iova = a.iova + (misalign_alloc ? 4 : 0);
    *va = misalign_alloc ? static_cast<uint8_t*>(p) + 4 : p;
    return 0;
  }
  void free_mem(uint64_t iova) {
    // tolerate the misaligned-injection offset
    auto it = allocs_.find(iova);
    if (it == allocs_.end()) it = allocs_.find(iova - 4);
    if (it == allocs_.end()) { ++abi_errors; return; }
    std::free(it->second.p);
    allocs_.erase(it);
  }
  size_t live_allocs() const { return allocs_.size(); }
  // 0 ok; 1 no mapping; 3 domain (belongs to another tenant); 4 range (starts inside, runs past the end)
  int xlate(unsigned tenant, uint64_t iova, size_t len, uint8_t** out) const {
    auto it = allocs_.upper_bound(iova);
    if (it == allocs_.begin()) return 1;
    --it;
    const Alloc& a = it->second;
    if (iova >= a.iova + a.len) return 1;
    if (a.tenant != tenant) return 3;
    if (iova + len > a.iova + a.len) return 4;
    *out = static_cast<uint8_t*>(a.p) + (iova - a.iova);
    return 0;
  }

  // ------------------------------------------------------------------ construction
  explicit MockFabric(const Cfg& c)
      : cfg(c), model(c.nt, 8, 8, bcaps(c)), q_(c.nt), cnt_(c.nt) {}
  static sfref::BackendCaps bcaps(const Cfg& c) {
    sfref::BackendCaps b;
    b.capacity_blocks = c.capacity;
    b.volatile_cache = c.vol;
    b.discard = c.discard;
    b.discard_zero = c.discard_zero;
    b.pi_native = c.pi_native;
    return b;
  }
  ~MockFabric() {
    for (auto& kv : allocs_) std::free(kv.second.p);
  }

  Cfg cfg;
  sfref::Model model;

  // ------------------------------------------------------------------ knobs / observability
  unsigned delay = 0;          // ticks before a completion becomes visible
  bool ooo = false;            // allow legal out-of-order completion (§5.1)
  bool stall_fetch = false;    // device does not consume the SQ
  bool fail_next_fetch = false;
  bool reset_clears_cfg = false;  // CTRL.RESET also clears SQ/CQ base+size (the spec does not say, Q-19)
  uint32_t id_override = 0, version_override = 0, caps0_override = 0;
  bool use_overrides = false;
  uint32_t lie_sq_max = 0;     // if non-zero the device really only accepts this many SQ entries
  unsigned abi_errors = 0, bus_errors = 0, db_errors = 0;
  uint32_t cycle = 1000;
  unsigned soft_resets = 0, clr_counters = 0, be_resets = 0;
  struct Logged {
    unsigned tenant;
    sfref::Outcome o;
    uint32_t cqe[8];
  };
  std::vector<Logged> log;     // every completion posted (for cross-checks)
  struct PtEntry { bool valid; uint32_t dom; uint64_t base, size; uint32_t perm; };
  std::array<PtEntry, 16> pt{};
  uint8_t keys[16][64] = {};
  uint32_t perf_live = 0x1000;  // value returned for PERF_LO reads, increments after each read
  uint32_t perf_hi_live = 0;

  struct Counters {
    uint32_t done = 0, err = 0, rd_blk = 0, wr_blk = 0, flush = 0, throttle = 0, viol = 0, bytes = 0;
  };
  const Counters& counters(unsigned t) const { return cnt_[t]; }
  unsigned pending_count(unsigned t) const { return unsigned(q_[t].pend.size()); }
  uint32_t sq_head(unsigned t) const { return q_[t].sq_head; }
  uint32_t cq_tail(unsigned t) const { return q_[t].cq_tail; }
  bool enabled(unsigned t) const { return q_[t].enabled; }

  // ------------------------------------------------------------------ time
  void tick() {
    ++cycle;
    for (auto& q : q_)
      for (auto& p : q.pend)
        if (p.delay) --p.delay;
    pump();
  }

  // ------------------------------------------------------------------ tenant page (§8)
  uint32_t t_read(unsigned t, uint32_t off) {
    if (t >= q_.size() || (off & 3u)) { ++bus_errors; return 0; }
    Q& q = q_[t];
    switch (off) {
      case SFS_REG_ID: return use_overrides && id_override ? id_override : SFS_ID_MAGIC;
      case SFS_REG_VERSION: return use_overrides && version_override ? version_override : SFS_ABI_VERSION;
      case SFS_REG_CAPS0:
        if (use_overrides && caps0_override) return caps0_override;
        return uint32_t(8) | (cfg.sq_max << 8) | (cfg.cq_max << 16) | (9u << 24);
      case SFS_REG_CAPS1: {
        uint32_t v = 0;
        if (model.discard_supported()) v |= SFS_CAPS1_DISCARD;
        if (cfg.pi_native) v |= SFS_CAPS1_PI;
        v |= SFS_CAPS1_ENC | SFS_CAPS1_FUA | SFS_CAPS1_HCRC;
        if (cfg.vol) v |= SFS_CAPS1_VOLATILE_CACHE;
        v |= SFS_CAPS1_BACKEND_READY | (1u << SFS_CAPS1_BE_TYPE_SHIFT);
        v |= model.owned_mask(t) << SFS_CAPS1_NS_MASK_SHIFT;
        return v;
      }
      case SFS_REG_CTRL: return q.enabled ? SFS_CTRL_ENABLE : 0u;
      case SFS_REG_STATUS: {
        uint32_t v = 0;
        if (q.enabled) v |= SFS_STATUS_ENABLED;
        if (q.sq_err) v |= SFS_STATUS_SQ_ERR;
        if (q.cq_err) v |= SFS_STATUS_CQ_ERR;
        if (q.fatal) v |= SFS_STATUS_FATAL;
        if (q.sq_head == q.sq_tail) v |= SFS_STATUS_SQ_EMPTY;
        if (q.pend.empty() && q.sq_head == q.sq_tail) v |= SFS_STATUS_IDLE;
        v |= uint32_t(q.last_err) << SFS_STATUS_LAST_ERR_SHIFT;
        return v;
      }
      case SFS_REG_SQ_BASE_LO: return uint32_t(q.sq_base & ~uint64_t(63));
      case SFS_REG_SQ_BASE_HI: return uint32_t(q.sq_base >> 32);
      case SFS_REG_SQ_SIZE: return q.sq_size;
      case SFS_REG_CQ_BASE_LO: return uint32_t(q.cq_base);
      case SFS_REG_CQ_BASE_HI: return uint32_t(q.cq_base >> 32);
      case SFS_REG_CQ_SIZE: return q.cq_size;
      case SFS_REG_SQ_TAIL: return q.sq_tail;
      case SFS_REG_CQ_HEAD: return q.cq_head;
      case SFS_REG_SQ_HEAD: return q.sq_head;
      case SFS_REG_CQ_TAIL: return q.cq_tail;
      case SFS_REG_IRQ_EN: return q.irq_en;
      case SFS_REG_IRQ_STATUS:
        return (q.cq_tail != q.cq_head ? SFS_IRQ_CQ_NONEMPTY : 0u) | (q.irq_queue_err ? SFS_IRQ_QUEUE_ERR : 0u) |
               (q.irq_db_err ? SFS_IRQ_DB_ERR : 0u);
      case SFS_REG_INFLIGHT: return unsigned(q.pend.size());
      case SFS_REG_CNT_DONE: return cnt_[t].done;
      case SFS_REG_CNT_ERR: return cnt_[t].err;
      case SFS_REG_CNT_RD_BLK: return cnt_[t].rd_blk;
      case SFS_REG_CNT_WR_BLK: return cnt_[t].wr_blk;
      case SFS_REG_CNT_FLUSH: return cnt_[t].flush;
      case SFS_REG_CNT_THROTTLE: return cnt_[t].throttle;
      case SFS_REG_CNT_VIOL: return cnt_[t].viol;
      case SFS_REG_CNT_BYTES_LO: return cnt_[t].bytes;
      default: ++bus_errors; return 0;
    }
  }

  void t_write(unsigned t, uint32_t off, uint32_t v) {
    if (t >= q_.size() || (off & 3u)) { ++bus_errors; return; }
    Q& q = q_[t];
    auto dberr = [&]() { q.irq_db_err = true; ++db_errors; };
    switch (off) {
      case SFS_REG_CTRL:
        if (v & SFS_CTRL_RESET) { reset_queue(t); break; }
        if (v & SFS_CTRL_ENABLE) {
          if (q.hv_allowed && fabric_enable && !q.enabled && q.sq_size >= 2 && q.cq_size >= 2) {
            // §8 step 2: the CQ must be zero (phase 0) before the queue is enabled
            uint8_t* cq = nullptr;
            if (xlate(t, q.cq_base, size_t(q.cq_size) * 32, &cq) == 0) {
              for (size_t i = 0; i < size_t(q.cq_size) * 32; ++i)
                if (cq[i]) { ++abi_errors; break; }
            } else {
              ++abi_errors;
            }
            if (q.sq_base & 63u) ++abi_errors;
            if (q.cq_base & 31u) ++abi_errors;
            q.enabled = true;
          }
        } else {
          q.enabled = false;
        }
        break;
      case SFS_REG_SQ_BASE_LO: if (!q.enabled) q.sq_base = (q.sq_base & ~0xFFFFFFFFull) | v; break;
      case SFS_REG_SQ_BASE_HI: if (!q.enabled) q.sq_base = (q.sq_base & 0xFFFFFFFFull) | (uint64_t(v) << 32); break;
      case SFS_REG_CQ_BASE_LO: if (!q.enabled) q.cq_base = (q.cq_base & ~0xFFFFFFFFull) | v; break;
      case SFS_REG_CQ_BASE_HI: if (!q.enabled) q.cq_base = (q.cq_base & 0xFFFFFFFFull) | (uint64_t(v) << 32); break;
      case SFS_REG_SQ_SIZE: {
        const uint32_t lim = lie_sq_max ? lie_sq_max : cfg.sq_max;
        if (q.enabled || v < 2 || (v & (v - 1)) || v > lim) dberr();
        else q.sq_size = v;
        break;
      }
      case SFS_REG_CQ_SIZE:
        if (q.enabled || v < 2 || (v & (v - 1)) || v > cfg.cq_max) dberr();
        else q.cq_size = v;
        break;
      case SFS_REG_SQ_TAIL: {
        if (!q.enabled || v >= q.sq_size) { dberr(); break; }
        const uint32_t n = q.sq_size;
        const uint32_t add_mod = (v + n - q.sq_tail) % n;  // entries this doorbell adds
        const uint32_t out = (q.sq_tail + n - q.sq_head) % n;
        if (add_mod > (n - 1) - out) { dberr(); break; }  // would overflow the ring (more than SQ_SIZE-1 outstanding)
        q.sq_tail = v;
        pump();
        break;
      }
      case SFS_REG_CQ_HEAD: {
        if (!q.enabled || v >= q.cq_size) { dberr(); break; }
        const uint32_t n = q.cq_size;
        const uint32_t consume = (v + n - q.cq_head) % n;
        const uint32_t avail = (q.cq_tail + n - q.cq_head) % n;
        if (consume > avail) { dberr(); break; }  // beyond CQ_TAIL
        q.cq_head = v;
        pump();
        break;
      }
      case SFS_REG_IRQ_EN: q.irq_en = v & 3u; break;
      case SFS_REG_IRQ_STATUS:
        if (v & SFS_IRQ_QUEUE_ERR) q.irq_queue_err = false;
        if (v & SFS_IRQ_DB_ERR) q.irq_db_err = false;
        break;
      default: ++bus_errors; break;  // read-only or undefined register
    }
  }

  // ------------------------------------------------------------------ management window (§9)
  uint32_t m_read(uint32_t off) {
    if (off & 3u) { ++bus_errors; return 0; }
    switch (off) {
      case SFS_MG_REG_ID: return SFS_MG_ID_MAGIC;
      case SFS_MG_REG_VERSION: return SFS_ABI_VERSION;
      case SFS_MG_REG_GCAPS0: return cfg.nt | (8u << 8) | (8u << 16) | (8u << 24);
      case SFS_MG_REG_GCAPS1: return cfg.sq_max | (cfg.cq_max << 8) | SFS_GCAPS1_XTS | (1u << SFS_GCAPS1_BE_TYPE_SHIFT);
      case SFS_MG_REG_GCTRL: return gctrl_;
      case SFS_MG_REG_GSTATUS: {
        unsigned busy = 0;
        for (auto& q : q_) busy += unsigned(q.pend.size());
        return SFS_GSTATUS_BE_READY | (busy << SFS_GSTATUS_BUSY_SLOTS_SHIFT);
      }
      case SFS_MG_REG_CMD_TIMEOUT: return cmd_timeout_;
      case SFS_MG_REG_SCHED_CFG: return sched_cfg_;
      case SFS_MG_REG_PF_CTRL: return pf_ctrl_;
      default: break;
    }
    if (off >= SFS_MG_TCFG_BASE && off < SFS_MG_TCFG_BASE + SFS_MG_TCFG_STRIDE * cfg.nt) {
      const unsigned t = (off - SFS_MG_TCFG_BASE) / SFS_MG_TCFG_STRIDE;
      const uint32_t r = (off - SFS_MG_TCFG_BASE) % SFS_MG_TCFG_STRIDE;
      return r <= SFS_TCFG_BURST ? tcfg_[t][r / 4] : 0;
    }
    if (off >= SFS_MG_NS_BASE && off < SFS_MG_NS_BASE + SFS_MG_NS_STRIDE * 8) {
      const unsigned n = (off - SFS_MG_NS_BASE) / SFS_MG_NS_STRIDE;
      const uint32_t r = (off - SFS_MG_NS_BASE) % SFS_MG_NS_STRIDE;
      NsRegs& s = ns_[n];
      switch (r) {
        case SFS_NS_CTRL: return s.ctrl;
        case SFS_NS_BASE_LO: return uint32_t(s.base);
        case SFS_NS_BASE_HI: return uint32_t(s.base >> 32);
        case SFS_NS_SIZE_LO: return uint32_t(s.size);
        case SFS_NS_SIZE_HI: return uint32_t(s.size >> 32);
        case SFS_NS_STATUS: return s.status;
        default: ++bus_errors; return 0;
      }
    }
    if (off >= SFS_MG_PT_BASE && off <= SFS_MG_PT_BASE + SFS_PT_STATUS) {
      switch (off - SFS_MG_PT_BASE) {
        case SFS_PT_IDX: return pt_idx_;
        case SFS_PT_STATUS: return pt_rejected_ ? SFS_PT_STATUS_REJECTED : 0;
        default: return 0;
      }
    }
    switch (off) {
      case SFS_MG_BE_BASE + SFS_BE_TYPE: return 1;
      case SFS_MG_BE_BASE + SFS_BE_CAPS:
        return (cfg.pi_native ? SFS_BECAP_PI_NATIVE : 0u) | (cfg.vol ? SFS_BECAP_VOLATILE_CACHE : 0u) |
               (cfg.discard ? SFS_BECAP_DISCARD : 0u) | (cfg.discard_zero ? SFS_BECAP_DISCARD_ZERO : 0u);
      case SFS_MG_BE_BASE + SFS_BE_CAP_LO: return uint32_t(cfg.capacity);
      case SFS_MG_BE_BASE + SFS_BE_CAP_HI: return uint32_t(cfg.capacity >> 32);
      case SFS_MG_PERF_BASE + SFS_PERF_SEL: return perf_sel_;
      case SFS_MG_PERF_BASE + SFS_PERF_LO: {  // reading LO latches HI
        perf_hi_latched_ = perf_hi_live;
        const uint32_t v = perf_live;
        if (++perf_live == 0) ++perf_hi_live;  // the live counter keeps running between the LO and HI reads
        return v;
      }
      case SFS_MG_PERF_BASE + SFS_PERF_HI: return perf_hi_latched_;
      case SFS_MG_TR_BASE + SFS_TR_STAT: return uint32_t(trace_.size() & 0xFFFF) | (trace_dropped_ << 16);
      default: break;
    }
    if (off >= SFS_MG_TR_BASE + SFS_TR_W0 && off < SFS_MG_TR_BASE + SFS_TR_W0 + 32) {
      if (trace_.empty()) return 0;
      return trace_.front()[(off - SFS_MG_TR_BASE - SFS_TR_W0) / 4];
    }
    ++bus_errors;
    return 0;
  }

  void m_write(uint32_t off, uint32_t v) {
    if (off & 3u) { ++bus_errors; return; }
    switch (off) {
      case SFS_MG_REG_GCTRL:
        gctrl_ = v & SFS_GCTRL_RW_MASK;  // W1S bits are self-clearing
        fabric_enable = (v & SFS_GCTRL_ENABLE) != 0;
        if (v & SFS_GCTRL_SOFT_RESET) {
          ++soft_resets;
          for (unsigned t = 0; t < q_.size(); ++t) reset_queue(t);
        }
        if (v & SFS_GCTRL_CLR_COUNTERS) {
          ++clr_counters;
          for (auto& c : cnt_) c = Counters();
          model.clear_counters();
        }
        return;  // with ENABLE = 0 queues keep their state but do not run (see pump())
      case SFS_MG_REG_CMD_TIMEOUT: cmd_timeout_ = v; return;
      case SFS_MG_REG_SCHED_CFG: sched_cfg_ = v; return;
      case SFS_MG_REG_PF_CTRL: pf_ctrl_ = v & 1u; return;
      default: break;
    }
    if (off >= SFS_MG_TCFG_BASE && off < SFS_MG_TCFG_BASE + SFS_MG_TCFG_STRIDE * cfg.nt) {
      const unsigned t = (off - SFS_MG_TCFG_BASE) / SFS_MG_TCFG_STRIDE;
      const uint32_t r = (off - SFS_MG_TCFG_BASE) % SFS_MG_TCFG_STRIDE;
      if (r > SFS_TCFG_BURST) { ++bus_errors; return; }
      tcfg_[t][r / 4] = v;
      if (r == SFS_TCFG_ENABLE_ALLOWED) q_[t].hv_allowed = (v & 1u) != 0;
      return;
    }
    if (off >= SFS_MG_NS_BASE && off < SFS_MG_NS_BASE + SFS_MG_NS_STRIDE * 8) {
      const unsigned n = (off - SFS_MG_NS_BASE) / SFS_MG_NS_STRIDE;
      const uint32_t r = (off - SFS_MG_NS_BASE) % SFS_MG_NS_STRIDE;
      ns_write(n, r, v);
      return;
    }
    if (off >= SFS_MG_PT_BASE && off <= SFS_MG_PT_BASE + SFS_PT_STATUS) {
      pt_write(off - SFS_MG_PT_BASE, v);
      return;
    }
    if (off == SFS_MG_BE_BASE + SFS_BE_CTRL) { if (v & SFS_BE_CTRL_RESET) ++be_resets; return; }
    if (off == SFS_MG_KEY_BASE + SFS_KEY_SEL) { key_sel_ = v & 15u; return; }
    if (off >= SFS_MG_KEY_BASE + SFS_KEY_W0 && off < SFS_MG_KEY_BASE + SFS_KEY_W0 + 64) {
      const uint32_t i = (off - SFS_MG_KEY_BASE - SFS_KEY_W0) / 4;
      for (int b = 0; b < 4; ++b) key_stage_[i * 4 + b] = uint8_t(v >> (8 * b));
      return;
    }
    if (off == SFS_MG_KEY_BASE + SFS_KEY_CTRL) {
      if (v & SFS_KEY_CTRL_ZEROIZE) {
        std::memset(keys[key_sel_], 0, 64);
        model.set_key_ready(key_sel_, false);
      } else if (v & SFS_KEY_CTRL_COMMIT) {
        std::memcpy(keys[key_sel_], key_stage_, 64);
        model.set_key_ready(key_sel_, true);
      }
      return;
    }
    if (off == SFS_MG_PERF_BASE + SFS_PERF_SEL) { perf_sel_ = v; return; }
    if (off == SFS_MG_TR_BASE + SFS_TR_POP) { if (!trace_.empty()) trace_.pop_front(); return; }
    ++bus_errors;
  }

  bool fabric_enable = false;
  const std::array<uint32_t, 5>& tcfg(unsigned t) const { return tcfg_[t]; }
  uint32_t gctrl() const { return gctrl_; }
  uint32_t cmd_timeout() const { return cmd_timeout_; }
  uint32_t sched_cfg() const { return sched_cfg_; }
  uint32_t pf_ctrl() const { return pf_ctrl_; }

  // Run the device until nothing more can happen (used by tests that want to "let time pass" at delay 0).
  void settle() {
    for (int i = 0; i < 64; ++i) {
      tick();
    }
  }

 private:
  struct Pending {
    sfref::Outcome o;
    uint32_t cqe[8];
    unsigned delay;
    unsigned nsid;
    uint64_t lba;
    uint32_t nblk;
    uint8_t op;
    bool has_range;
    uint32_t fetch_cycle, admit_cycle, bytes;
  };
  struct Q {
    bool hv_allowed = false, enabled = false, fatal = false, sq_err = false, cq_err = false;
    bool irq_queue_err = false, irq_db_err = false;
    uint8_t last_err = 0;
    uint64_t sq_base = 0, cq_base = 0;
    uint32_t sq_size = 0, cq_size = 0;
    uint32_t sq_tail = 0, sq_head = 0, cq_tail = 0, cq_head = 0;
    uint32_t phase = 1;
    uint32_t irq_en = 0;
    std::deque<Pending> pend;
  };
  struct NsRegs {
    uint32_t ctrl = 0, status = 0;
    uint64_t base = 0, size = 0;
  };

  void ns_write(unsigned n, uint32_t r, uint32_t v) {
    NsRegs& s = ns_[n];
    const bool valid = (s.ctrl & SFS_NSC_VALID) != 0;
    switch (r) {
      case SFS_NS_CTRL: {
        if (v & SFS_NSC_VALID) {
          sfref::NsCfg c;
          c.owner = (v >> SFS_NSC_OWNER_SHIFT) & SFS_NSC_OWNER_MASK;
          c.key_slot = (v >> SFS_NSC_KEY_SLOT_SHIFT) & SFS_NSC_KEY_SLOT_MASK;
          c.readonly = (v & SFS_NSC_READONLY) != 0;
          c.enc = (v & SFS_NSC_ENC_EN) != 0;
          c.pi = (v & SFS_NSC_PI_EN) != 0;
          c.base = s.base;
          c.size = s.size;
          if (valid) break;  // already valid: flags are only writable while VALID = 0
          sfref::NsStatus st = model.cfg_ns(n, c);
          s.status = st.reg();
          s.ctrl = st.accepted ? v : (v & ~uint32_t(SFS_NSC_VALID));
        } else {
          model.invalidate_ns(n);
          s.ctrl = v;
        }
        break;
      }
      case SFS_NS_BASE_LO: if (!valid) s.base = (s.base & ~0xFFFFFFFFull) | v; break;
      case SFS_NS_BASE_HI: if (!valid) s.base = (s.base & 0xFFFFFFFFull) | (uint64_t(v) << 32); break;
      case SFS_NS_SIZE_LO: if (!valid) s.size = (s.size & ~0xFFFFFFFFull) | v; break;
      case SFS_NS_SIZE_HI: if (!valid) s.size = (s.size & 0xFFFFFFFFull) | (uint64_t(v) << 32); break;
      default: ++bus_errors; break;  // NS_STATUS is read-only
    }
  }

  void pt_write(uint32_t r, uint32_t v) {
    switch (r) {
      case SFS_PT_IDX: pt_idx_ = v; break;
      case SFS_PT_DOM: pt_stage_.dom = v; break;
      case SFS_PT_BASE_LO: pt_stage_.base = (pt_stage_.base & ~0xFFFFFFFFull) | v; break;
      case SFS_PT_BASE_HI: pt_stage_.base = (pt_stage_.base & 0xFFFFFFFFull) | (uint64_t(v) << 32); break;
      case SFS_PT_SIZE_LO: pt_stage_.size = (pt_stage_.size & ~0xFFFFFFFFull) | v; break;
      case SFS_PT_SIZE_HI: pt_stage_.size = (pt_stage_.size & 0xFFFFFFFFull) | (uint64_t(v) << 32); break;
      case SFS_PT_PERM: pt_stage_.perm = v & 3u; break;
      case SFS_PT_CTRL:
        pt_stage_.valid = (v & SFS_PT_CTRL_VALID) != 0;
        if (v & SFS_PT_CTRL_COMMIT) {
          const bool bad_idx = pt_idx_ < cfg.nt || pt_idx_ >= 16;
          const bool bad_rng = pt_stage_.valid && (pt_stage_.size == 0 || pt_stage_.base + pt_stage_.size < pt_stage_.base);
          pt_rejected_ = bad_idx || bad_rng;
          if (!pt_rejected_) pt[pt_idx_] = pt_stage_;
        }
        break;
      default: ++bus_errors; break;
    }
  }

  void reset_queue(unsigned t) {
    Q& q = q_[t];
    for (auto& p : q.pend) {  // §8 RESET: in-flight commands abort with no completion
      if (p.o.executed && p.o.wid) model.on_write_failed(p.o.wid, 0);
      if (p.o.executed && p.o.fid) model.on_flush_failed(t);
    }
    q.pend.clear();
    q.sq_tail = q.sq_head = q.cq_tail = q.cq_head = 0;
    q.phase = 1;
    q.enabled = false;
    q.fatal = q.sq_err = q.cq_err = false;
    if (reset_clears_cfg) q.sq_base = q.cq_base = q.sq_size = q.cq_size = 0;
  }

  // Fetch descriptors, run them, post completions.
  void pump() {
    if (pumping_) return;
    pumping_ = true;
    for (unsigned t = 0; t < q_.size(); ++t) {
      Q& q = q_[t];
      if (!q.enabled || !fabric_enable) continue;
      for (;;) {
        bool progress = false;
        while (!stall_fetch && fetch_budget != 0 && !q.fatal && q.sq_head != q.sq_tail && q.pend.size() < 8) {
          if (fetch_budget > 0) --fetch_budget;
          fetch_one(t);
          progress = true;
        }
        if (post_one(t)) progress = true;
        if (!progress) break;
      }
    }
    pumping_ = false;
  }

  void fetch_one(unsigned t) {
    Q& q = q_[t];
    uint8_t* slot = nullptr;
    if (fail_next_fetch || xlate(t, q.sq_base + uint64_t(q.sq_head) * 64, 64, &slot) != 0) {
      fail_next_fetch = false;
      // §3: the descriptor could not be read -> TXN_ID 0xFFFF, queue halts until RESET
      q.sq_err = true;
      q.fatal = true;
      q.irq_queue_err = true;
      q.last_err = 3;
      Pending p{};
      p.o.txn = 0xFFFF;
      p.o.status = sfref::ST_DMA_ERROR;
      p.o.detail = 3;
      p.o.tenant = t;
      p.delay = 0;
      build_cqe(t, p, q.sq_head);
      q.pend.push_back(p);
      return;
    }
    uint32_t w[16];
    for (int i = 0; i < 16; ++i)
      w[i] = uint32_t(slot[4 * i]) | (uint32_t(slot[4 * i + 1]) << 8) | (uint32_t(slot[4 * i + 2]) << 16) |
             (uint32_t(slot[4 * i + 3]) << 24);
    q.sq_head = (q.sq_head + 1) % q.sq_size;
    const uint32_t fetch_cycle = cycle;
    Pending p = execute(t, w);
    p.fetch_cycle = fetch_cycle;
    p.admit_cycle = cycle;
    p.delay = delay;
    build_cqe(t, p, q.sq_head);
    q.pend.push_back(p);
  }

  Pending execute(unsigned t, const uint32_t w[16]) {
    const sfref::Desc d = sfref::decode(w);
    Pending p{};
    p.op = d.opcode;
    p.nsid = d.nsid;
    p.lba = d.lba;
    p.nblk = d.nblk;
    sfref::Verdict v = model.validate(t, w, t);
    std::vector<uint8_t> payload;
    uint8_t* host = nullptr;
    int fault = 0;
    if (v.ok && (d.opcode == sfref::OP_READ || d.opcode == sfref::OP_WRITE)) {
      fault = xlate(t, d.data_addr, size_t(d.nblk) * 512, &host);
      if (fault == 0 && d.opcode == sfref::OP_WRITE) payload.assign(host, host + size_t(d.nblk) * 512);
    }
    if (fault) {
      p.o.v = v;
      p.o.txn = d.txn;
      p.o.opcode = d.opcode;
      p.o.tenant = t;
      p.o.status = sfref::ST_DMA_FAULT;
      p.o.detail = uint8_t(fault);
      p.o.durable = 0;
      p.o.crc_valid = 0;
      p.has_range = false;
      return p;
    }
    p.o = model.submit(t, w, payload.empty() ? nullptr : payload.data(), int(t));
    if (p.o.executed && d.opcode == sfref::OP_READ && p.o.status == sfref::ST_SUCCESS)
      std::memcpy(host, p.o.read_data.data(), p.o.read_data.size());
    p.has_range = p.o.executed && (d.opcode == sfref::OP_READ || d.opcode == sfref::OP_WRITE || d.opcode == sfref::OP_DISCARD);
    p.bytes = (p.o.executed && p.o.status == sfref::ST_SUCCESS && (d.opcode == sfref::OP_READ || d.opcode == sfref::OP_WRITE))
                  ? d.nblk * 512
                  : 0;
    return p;
  }

  void build_cqe(unsigned t, Pending& p, uint32_t sq_head) {
    const sfref::Outcome& o = p.o;
    uint32_t* c = p.cqe;
    std::memset(c, 0, 32);
    c[0] = uint32_t(o.txn) | (uint32_t(o.status) << 16) | (uint32_t(o.detail) << 24);
    uint32_t f = 0;
    if (o.durable == 1) f |= SFS_CQE_DURABLE;
    if (o.pi_verified == 1) f |= SFS_CQE_PI_VERIFIED;
    if (o.encrypted == 1) f |= SFS_CQE_ENCRYPTED;
    if (o.crc_valid == 1) f |= SFS_CQE_CRC_VALID;
    c[1] = f | (uint32_t(o.opcode) << 8) | (o.nblk_done << 16);
    c[2] = o.crc_valid == 1 ? o.crc : o.result0;
    c[3] = o.crc_valid == 1 ? 0 : o.result1;
    c[4] = (sq_head & 0xFFFFu) | (uint32_t(t) << 16);
    c[5] = 20 + 4 * o.nblk_done + 50 * delay;  // deterministic synthetic latency
    c[6] = 0;
    c[7] = 0;  // PHASE is stamped at post time
  }

  static bool conflicts(const Pending& a, const Pending& b) {  // §5.1
    if (a.op == sfref::OP_FLUSH || b.op == sfref::OP_FLUSH) return true;  // FLUSH is ordered against everything (§5.2)
    if (!a.has_range || !b.has_range) return false;
    if (a.nsid != b.nsid) return false;
    const bool wa = a.op != sfref::OP_READ, wb = b.op != sfref::OP_READ;
    if (!wa && !wb) return false;
    return a.lba < b.lba + b.nblk && b.lba < a.lba + a.nblk;
  }

  // Post at most one completion; returns true if one was posted.
  bool post_one(unsigned t) {
    Q& q = q_[t];
    if (q.pend.empty()) return false;
    if (((q.cq_tail + 1) % q.cq_size) == q.cq_head) return false;  // CQ full (one slot kept free)
    int pick = -1;
    if (!ooo) {
      if (q.pend.front().delay == 0) pick = 0;
    } else {
      for (int i = int(q.pend.size()) - 1; i >= 0 && pick < 0; --i) {
        if (q.pend[size_t(i)].delay) continue;
        bool ok = true;
        for (int j = 0; j < i && ok; ++j) ok = !conflicts(q.pend[size_t(j)], q.pend[size_t(i)]);
        if (ok) pick = i;
      }
    }
    if (pick < 0) return false;
    Pending p = q.pend[size_t(pick)];
    q.pend.erase(q.pend.begin() + pick);
    // hooks for the model's durability bookkeeping
    if (p.o.executed) {
      if (p.o.wid && p.o.status == sfref::ST_SUCCESS) model.on_write_complete(p.o.wid, p.o.durable == 1);
      if (p.o.fid && p.o.status == sfref::ST_SUCCESS) model.on_flush_complete(t);
    }
    // write the CQE in increasing address order, PHASE word last
    uint8_t* slot = nullptr;
    if (xlate(t, q.cq_base + uint64_t(q.cq_tail) * 32, 32, &slot) != 0) {
      q.cq_err = true;
      q.fatal = true;
      q.irq_queue_err = true;
      q.last_err = 4;
      return false;
    }
    p.cqe[7] = q.phase;
    for (int i = 0; i < 8; ++i)
      for (int b = 0; b < 4; ++b) slot[4 * i + b] = uint8_t(p.cqe[i] >> (8 * b));
    q.cq_tail = (q.cq_tail + 1) % q.cq_size;
    if (q.cq_tail == 0) q.phase ^= 1u;
    // counters
    Counters& c = cnt_[t];
    ++c.done;
    if (p.o.status != 0) ++c.err;
    if (p.o.status == sfref::ST_TENANT_MISMATCH || p.o.status == sfref::ST_INVALID_NS || p.o.status == sfref::ST_DMA_FAULT) ++c.viol;
    if (p.o.status == 0) {
      if (p.op == sfref::OP_READ) c.rd_blk += p.o.nblk_done;
      if (p.op == sfref::OP_WRITE) c.wr_blk += p.o.nblk_done;
      if (p.op == sfref::OP_FLUSH) ++c.flush;
    }
    c.bytes += p.bytes;
    log.push_back({t, p.o, {p.cqe[0], p.cqe[1], p.cqe[2], p.cqe[3], p.cqe[4], p.cqe[5], p.cqe[6], p.cqe[7]}});
    if (gctrl_ & SFS_GCTRL_TRACE_EN) {
      if (trace_.size() >= 16) {
        ++trace_dropped_;
      } else {
        std::array<uint32_t, 8> r{};
        r[0] = uint32_t(p.o.txn) | (t << 16) | (uint32_t(p.op) << 24);
        r[1] = uint32_t(p.o.status) | (uint32_t(p.o.detail) << 8) | (p.o.nblk_done << 16);
        r[2] = p.fetch_cycle;
        r[3] = p.admit_cycle + 3;
        r[4] = p.admit_cycle + 5;
        r[5] = cycle + 7;
        r[6] = cycle + 9;
        r[7] = (p.o.durable == 1 ? 0x80000000u : 0u) | p.bytes;
        trace_.push_back(r);
      }
    }
    return true;
  }

  std::map<uint64_t, Alloc> allocs_;
  uint64_t next_iova_ = 0x100000000ull;
  std::vector<Q> q_;
  std::vector<Counters> cnt_;
  bool pumping_ = false;

  uint32_t gctrl_ = 0, cmd_timeout_ = 0, sched_cfg_ = 0, pf_ctrl_ = 0;
  std::array<std::array<uint32_t, 5>, 16> tcfg_{};
  std::array<NsRegs, 8> ns_{};
  uint32_t pt_idx_ = 0;
  PtEntry pt_stage_{};
  bool pt_rejected_ = false;
  uint32_t key_sel_ = 0;
  uint8_t key_stage_[64] = {};
  uint32_t perf_sel_ = 0, perf_hi_latched_ = 0;
  std::deque<std::array<uint32_t, 8>> trace_;
  uint32_t trace_dropped_ = 0;
};

#endif  // MOCK_FABRIC_HPP
