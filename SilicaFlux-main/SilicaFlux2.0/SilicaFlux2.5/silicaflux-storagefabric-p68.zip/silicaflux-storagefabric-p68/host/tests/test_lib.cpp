// test_lib.cpp - tests for libsfstor against a software mock fabric (mock_fabric.hpp) that uses
// sfref::Model for validation/execution.  Plain checks; prints PASS/FAIL counts; exit code != 0 on failure.
#include <signal.h>
#include <sys/mman.h>
#include <unistd.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>

#include "mock_fabric.hpp"
#include "sfstor.h"

static int g_pass = 0, g_fail = 0;
#define CHECK(c)                                                  \
  do {                                                            \
    if (c) ++g_pass;                                              \
    else {                                                        \
      ++g_fail;                                                   \
      std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #c);    \
    }                                                             \
  } while (0)
#define CHECK_EQ(a, b)                                                                                   \
  do {                                                                                                   \
    const long long va_ = (long long)(a), vb_ = (long long)(b);                                          \
    if (va_ == vb_) ++g_pass;                                                                            \
    else {                                                                                               \
      ++g_fail;                                                                                          \
      std::printf("FAIL %s:%d: %s == %s  (%lld vs %lld)\n", __FILE__, __LINE__, #a, #b, va_, vb_);      \
    }                                                                                                    \
  } while (0)
static void section(const char* s) { std::printf("-- %s\n", s); }

// ---------------------------------------------------------------------------------------------
// transports bound to the mock
// ---------------------------------------------------------------------------------------------
struct TCtx {
  MockFabric* f = nullptr;
  unsigned t = 0;
  unsigned barrier_calls = 0, yield_calls = 0;
  std::map<uint32_t, unsigned> wr_count;  // MMIO writes by offset
  std::vector<std::pair<uint32_t, uint32_t>> wr_log;
  bool log_writes = false;
};
static uint32_t cb_read(void* c, uint32_t off) {
  TCtx* x = static_cast<TCtx*>(c);
  return x->f->t_read(x->t, off);
}
static void cb_write(void* c, uint32_t off, uint32_t v) {
  TCtx* x = static_cast<TCtx*>(c);
  x->wr_count[off]++;
  if (x->log_writes) x->wr_log.push_back({off, v});
  x->f->t_write(x->t, off, v);
}
static int cb_alloc(void* c, size_t bytes, size_t align, uint64_t* iova, void** va) {
  TCtx* x = static_cast<TCtx*>(c);
  return x->f->alloc(x->t, bytes, align, iova, va);
}
static void cb_free(void* c, uint64_t iova) { static_cast<TCtx*>(c)->f->free_mem(iova); }
static void cb_yield(void* c) {
  TCtx* x = static_cast<TCtx*>(c);
  ++x->yield_calls;
  x->f->tick();
}
static void cb_barrier(void* c) { ++static_cast<TCtx*>(c)->barrier_calls; }

struct MCtx {
  MockFabric* f = nullptr;
};
static uint32_t mcb_read(void* c, uint32_t off) { return static_cast<MCtx*>(c)->f->m_read(off); }
static void mcb_write(void* c, uint32_t off, uint32_t v) { static_cast<MCtx*>(c)->f->m_write(off, v); }
static void mcb_yield(void* c) { static_cast<MCtx*>(c)->f->tick(); }

struct Fixture {
  std::unique_ptr<MockFabric> f;
  TCtx c0, c1;
  MCtx mc;
  sfs_transport_t tp0, tp1;
  sfs_mgmt_transport_t mtp;
  sfs_mgmt_t mg;
  sfs_dev_t d0, d1;

  explicit Fixture(const MockFabric::Cfg& cfg = MockFabric::Cfg(), bool provision_now = true) {
    f.reset(new MockFabric(cfg));
    c0.f = c1.f = mc.f = f.get();
    c0.t = 0;
    c1.t = 1;
    tp0 = make_tp(&c0);
    tp1 = make_tp(&c1);
    mtp.ctx = &mc;
    mtp.mmio_read32 = mcb_read;
    mtp.mmio_write32 = mcb_write;
    mtp.yield = mcb_yield;
    std::memset(&mg, 0, sizeof(mg));
    std::memset(&d0, 0, sizeof(d0));
    std::memset(&d1, 0, sizeof(d1));
    if (provision_now) provision();
  }
  static sfs_transport_t make_tp(TCtx* c) {
    sfs_transport_t t;
    t.ctx = c;
    t.mmio_read32 = cb_read;
    t.mmio_write32 = cb_write;
    t.mem_alloc = cb_alloc;
    t.mem_free = cb_free;
    t.yield = cb_yield;
    t.barrier = cb_barrier;
    return t;
  }
  // hypervisor: namespaces, allow tenants, enable fabric; then open both tenant pages
  void provision() {
    CHECK_EQ(sfs_mgmt_open(&mg, &mtp), 0);
    sfs_ns_cfg_t n;
    std::memset(&n, 0, sizeof(n));
    n.owner = 0; n.base = 0; n.size = 1024;
    CHECK_EQ(sfs_mgmt_ns_config(&mg, 0, &n, nullptr), 0);
    std::memset(&n, 0, sizeof(n));
    n.owner = 0; n.base = 1024; n.size = 64; n.readonly = 1;
    CHECK_EQ(sfs_mgmt_ns_config(&mg, 1, &n, nullptr), 0);
    std::memset(&n, 0, sizeof(n));
    n.owner = 1; n.base = 2048; n.size = 512; n.enc = 1; n.key_slot = 3;
    CHECK_EQ(sfs_mgmt_ns_config(&mg, 2, &n, nullptr), 0);
    std::memset(&n, 0, sizeof(n));
    n.owner = 1; n.base = 4096; n.size = 256;
    CHECK_EQ(sfs_mgmt_ns_config(&mg, 3, &n, nullptr), 0);
    sfs_tcfg_t tc;
    std::memset(&tc, 0, sizeof(tc));
    tc.enable_allowed = 1;
    tc.weight = 1;
    CHECK_EQ(sfs_mgmt_tenant_cfg(&mg, 0, &tc), 0);
    CHECK_EQ(sfs_mgmt_tenant_cfg(&mg, 1, &tc), 0);
    CHECK_EQ(sfs_mgmt_enable_fabric(&mg, 1), 0);
    CHECK_EQ(sfs_dev_open(&d0, &tp0, 0), 0);
    CHECK_EQ(sfs_dev_open(&d1, &tp1, 1), 0);
  }
};

// ---------------------------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------------------------
static void cross_check_cqe(const sfs_cqe_t& c) {  // library decoder vs the independent decoder in sfref
  sfref::Cqe m = sfref::decode_cqe(c.raw);
  CHECK(c.txn == m.txn && c.status == m.status && c.detail == m.detail);
  CHECK((c.durable != 0) == m.durable && (c.pi_verified != 0) == m.pi_verified);
  CHECK((c.encrypted != 0) == m.encrypted && (c.crc_valid != 0) == m.crc_valid);
  CHECK(c.opcode == m.opcode && c.nblk_done == m.nblk_done);
  CHECK(c.result0 == m.result0 && c.result1 == m.result1 && c.sq_head == m.sq_head && c.tenant == m.tenant);
  CHECK(c.latency == m.latency && (c.phase != 0) == m.phase);
}
static int wait_ck(sfs_queue_t* q, sfs_cqe_t* c, uint32_t polls = 100000) {
  int rc = sfs_wait(q, c, polls);
  if (rc == 0) cross_check_cqe(*c);
  return rc;
}
static void fill_pat(uint8_t* p, size_t n, uint32_t seed) {
  uint32_t x = seed * 2654435761u + 12345u;
  for (size_t i = 0; i < n; ++i) {
    x = x * 1664525u + 1013904223u;
    p[i] = uint8_t(x >> 24);
  }
}
static uint32_t lcg(uint32_t& s) {
  s = s * 1664525u + 1013904223u;
  return s >> 8;
}
// ---------------------------------------------------------------------------------------------
static void test_helpers() {
  section("pure helpers: CRC, codecs, strings, percentile, latency");
  CHECK_EQ(sfs_crc32c("123456789", 9), 0xE3069283u);
  CHECK_EQ(sfs_crc32c("", 0), 0u);
  CHECK_EQ(sfs_crc32c_update(sfs_crc32c("12345", 5), "6789", 4), 0xE3069283u);
  uint8_t z[32] = {}, ff[32];
  std::memset(ff, 0xFF, 32);
  CHECK_EQ(sfs_crc32c(z, 32), 0x8A9136AAu);
  CHECK_EQ(sfs_crc32c(ff, 32), 0x62A8AB43u);
  std::vector<uint8_t> big(5000);
  fill_pat(big.data(), big.size(), 7);
  CHECK_EQ(sfs_crc32c(big.data(), big.size()), sfref::crc32c(big.data(), big.size()));

  // descriptor pack/unpack against the independent decoder
  uint32_t s = 99;
  for (int i = 0; i < 500; ++i) {
    sfs_desc_t d;
    std::memset(&d, 0, sizeof(d));
    d.version = uint8_t(lcg(s)); d.opcode = uint8_t(lcg(s)); d.flags = uint16_t(lcg(s));
    d.txn = uint16_t(lcg(s)); d.nsid = uint8_t(lcg(s)); d.rsv1 = uint8_t(lcg(s));
    d.lba = (uint64_t(lcg(s)) << 40) ^ (uint64_t(lcg(s)) << 20) ^ lcg(s);
    d.nblk = lcg(s) * 7919u; d.data_len = lcg(s) * 31u;
    d.data_addr = (uint64_t(lcg(s)) << 36) ^ lcg(s);
    d.tenant_claim = uint16_t(lcg(s)); d.rsv8 = uint16_t(lcg(s)); d.host_crc = lcg(s) * 17u;
    for (auto& r : d.rsv) r = lcg(s);
    uint32_t w[16];
    sfs_desc_pack(&d, w);
    sfref::Desc m = sfref::decode(w);
    CHECK(m.version == d.version && m.opcode == d.opcode && m.flags == d.flags && m.txn == d.txn && m.nsid == d.nsid);
    CHECK(m.rsv1 == d.rsv1 && m.lba == d.lba && m.nblk == d.nblk && m.data_len == d.data_len && m.data_addr == d.data_addr);
    CHECK(m.claim == d.tenant_claim && m.rsv8 == d.rsv8 && m.host_crc == d.host_crc);
    for (int k = 0; k < 6; ++k) CHECK(w[10 + k] == d.rsv[k]);
    sfs_desc_t e;
    sfs_desc_unpack(w, &e);
    CHECK(std::memcmp(&d, &e, sizeof(d)) == 0);
  }
  // CQE unpack against sfref::decode_cqe on random words
  for (int i = 0; i < 300; ++i) {
    uint32_t w[8];
    for (auto& x : w) x = lcg(s) * 2654435761u;
    sfs_cqe_t c;
    sfs_cqe_unpack(w, &c);
    cross_check_cqe(c);
    CHECK_EQ(sfs_cqe_capacity(&c), (uint64_t)w[2] | ((uint64_t)w[3] << 32));
  }
  // strings
  for (unsigned st = 0; st < 0x14; ++st) CHECK(std::strcmp(sfs_status_str(st), sfref::status_name(st)) == 0);
  CHECK(std::strcmp(sfs_status_str(0x14), "UNKNOWN") == 0 && std::strcmp(sfs_status_str(0xFF), "UNKNOWN") == 0);
  for (unsigned st : {2u, 5u, 0x12u})
    for (unsigned d = 0; d <= 4; ++d) {
      const char* a = sfs_detail_str(st, d);
      const char* b = sfref::detail_name(st, d);
      if (std::strcmp(b, "?") != 0) CHECK(std::strcmp(a, b) == 0);
    }
  CHECK(std::strcmp(sfs_detail_str(SFS_ST_DMA_FAULT, 1), "NO_MAP") == 0 && std::strcmp(sfs_detail_str(SFS_ST_DMA_FAULT, 3), "DOMAIN") == 0);
  CHECK(std::strcmp(sfs_detail_str(SFS_ST_INTEGRITY, 2), "LBA_TAG") == 0 && std::strcmp(sfs_detail_str(SFS_ST_TIMEOUT, 2), "DMA") == 0);
  CHECK(std::strcmp(sfs_detail_str(SFS_ST_MEDIA_ERROR, 0x33), "code") == 0 && std::strcmp(sfs_detail_str(0, 0), "-") == 0);
  std::set<std::string> errs;
  for (int e = 0; e >= -16; --e) {
    CHECK(sfs_strerror(e) != nullptr && sfs_strerror(e)[0] != 0);
    errs.insert(sfs_strerror(e));
  }
  CHECK_EQ(errs.size(), 17);

  // percentile: nearest-rank
  {
    uint32_t a[10] = {7, 3, 10, 1, 9, 2, 8, 5, 4, 6}, v = 0;
    CHECK_EQ(sfs_percentile(a, 10, 5000, &v), 0); CHECK_EQ(v, 5);     // ceil(0.5*10) = 5 -> 5th smallest
    CHECK_EQ(sfs_percentile(a, 10, 9000, &v), 0); CHECK_EQ(v, 9);     // p90 -> rank 9
    CHECK_EQ(sfs_percentile(a, 10, 9900, &v), 0); CHECK_EQ(v, 10);    // p99 -> ceil(9.9) = 10
    CHECK_EQ(sfs_percentile(a, 10, 10000, &v), 0); CHECK_EQ(v, 10);
    CHECK_EQ(sfs_percentile(a, 10, 0, &v), 0); CHECK_EQ(v, 1);        // p0 -> min
    CHECK_EQ(sfs_percentile(a, 10, 1, &v), 0); CHECK_EQ(v, 1);        // 0.01% -> rank 1
    CHECK_EQ(sfs_percentile(a, 10, 1000, &v), 0); CHECK_EQ(v, 1);     // p10 -> rank 1
    CHECK_EQ(sfs_percentile(a, 10, 1001, &v), 0); CHECK_EQ(v, 2);     // p10.01 -> ceil(1.001) = 2
    CHECK_EQ(sfs_percentile(a, 10, 2500, &v), 0); CHECK_EQ(v, 3);     // p25 -> ceil(2.5) = 3
    uint32_t one[1] = {42};
    CHECK_EQ(sfs_percentile(one, 1, 5000, &v), 0); CHECK_EQ(v, 42);
    CHECK_EQ(sfs_percentile(one, 1, 0, &v), 0); CHECK_EQ(v, 42);
    uint32_t dup[5] = {5, 5, 5, 5, 100};
    CHECK_EQ(sfs_percentile(dup, 5, 8000, &v), 0); CHECK_EQ(v, 5);    // rank 4
    CHECK_EQ(sfs_percentile(dup, 5, 8001, &v), 0); CHECK_EQ(v, 100);  // rank 5
    CHECK_EQ(sfs_percentile(a, 0, 5000, &v), SFS_E_INVAL);
    CHECK_EQ(sfs_percentile(a, 10, 10001, &v), SFS_E_INVAL);
    CHECK_EQ(sfs_percentile(nullptr, 10, 5000, &v), SFS_E_INVAL);
    CHECK_EQ(sfs_percentile(a, 10, 5000, nullptr), SFS_E_INVAL);
    // large random array vs a brute-force reference
    std::vector<uint32_t> r(1001), ref;
    for (auto& x : r) x = lcg(s) % 5000;
    ref = r;
    for (size_t i = 1; i < ref.size(); ++i)
      for (size_t j = i; j > 0 && ref[j - 1] > ref[j]; --j) std::swap(ref[j - 1], ref[j]);
    for (unsigned p : {0u, 1u, 50u, 5000u, 9500u, 9900u, 9990u, 10000u}) {
      std::vector<uint32_t> tmp = r;
      uint64_t rank = (uint64_t(p) * 1001 + 9999) / 10000;
      if (rank < 1) rank = 1;
      CHECK_EQ(sfs_percentile(tmp.data(), tmp.size(), p, &v), 0);
      CHECK_EQ(v, ref[rank - 1]);
    }
  }
  // latency accumulator
  {
    sfs_lat_t l;
    sfs_lat_reset(&l);
    CHECK(l.count == 0 && sfs_lat_mean(&l) == 0);
    sfs_lat_add(&l, 10); sfs_lat_add(&l, 30); sfs_lat_add(&l, 5); sfs_lat_add(&l, 0xFFFFFFFFu);
    CHECK_EQ(l.count, 4);
    CHECK_EQ(l.sum, 45ull + 0xFFFFFFFFull);
    CHECK_EQ(l.max, 0xFFFFFFFFu);
    CHECK_EQ(l.min, 5);
    CHECK_EQ(sfs_lat_mean(&l), (45ull + 0xFFFFFFFFull) / 4);
  }
}

// ---------------------------------------------------------------------------------------------
static void test_open_caps() {
  section("sfs_dev_open / caps (§8 ID, VERSION, CAPS0/1)");
  Fixture fx;
  const sfs_caps_t* c = sfs_dev_caps(&fx.d0);
  CHECK(c != nullptr);
  CHECK_EQ(c->id, SFS_ID_MAGIC);
  CHECK_EQ(c->version, SFS_ABI_VERSION);
  CHECK_EQ(c->mdts_blocks, 8);
  CHECK_EQ(c->sq_max, 64);
  CHECK_EQ(c->cq_max, 64);
  CHECK_EQ(c->block_shift, 9);
  CHECK(c->discard && c->pi && c->enc && c->fua && c->hcrc && c->volatile_cache && c->backend_ready);
  CHECK_EQ(c->backend_type, SFS_BE_STORE);
  CHECK_EQ(c->ns_mask, 0x3);                     // tenant 0 owns NSIDs 0 and 1
  CHECK_EQ(sfs_dev_caps(&fx.d1)->ns_mask, 0xC);  // tenant 1: NSIDs 2 and 3
  CHECK_EQ(sfs_dev_first_ns(&fx.d0), 0);
  CHECK_EQ(sfs_dev_first_ns(&fx.d1), 2);
  CHECK(sfs_dev_owns_ns(&fx.d0, 1) && !sfs_dev_owns_ns(&fx.d0, 2) && !sfs_dev_owns_ns(&fx.d0, 16));
  CHECK(sfs_dev_caps(nullptr) == nullptr);
  CHECK_EQ(sfs_dev_first_ns(nullptr), -1);

  // caps reflect the backend: no discard / write-through / no PI
  {
    MockFabric::Cfg cfg;
    cfg.vol = false; cfg.discard = false; cfg.pi_native = false;
    Fixture f2(cfg);
    const sfs_caps_t* k = sfs_dev_caps(&f2.d0);
    CHECK(!k->discard && !k->pi && !k->volatile_cache && k->fua && k->hcrc);
  }
  // refresh after the hypervisor changes the namespace table
  {
    Fixture f3(MockFabric::Cfg(), false);
    CHECK_EQ(sfs_dev_open(&f3.d0, &f3.tp0, 0), 0);
    CHECK_EQ(sfs_dev_caps(&f3.d0)->ns_mask, 0);
    CHECK_EQ(sfs_dev_first_ns(&f3.d0), -1);
    CHECK_EQ(sfs_mgmt_open(&f3.mg, &f3.mtp), 0);
    sfs_ns_cfg_t n;
    std::memset(&n, 0, sizeof(n));
    n.owner = 0; n.base = 0; n.size = 8;
    CHECK_EQ(sfs_mgmt_ns_config(&f3.mg, 5, &n, nullptr), 0);
    CHECK_EQ(sfs_dev_caps(&f3.d0)->ns_mask, 0);  // cached until refreshed
    CHECK_EQ(sfs_dev_refresh_caps(&f3.d0), 0);
    CHECK_EQ(sfs_dev_caps(&f3.d0)->ns_mask, 1u << 5);
    CHECK_EQ(sfs_dev_first_ns(&f3.d0), 5);
  }
  // wrong ID, wrong ABI major, minor differences tolerated, bad block size
  {
    Fixture f4(MockFabric::Cfg(), false);
    sfs_dev_t d;
    f4.f->use_overrides = true;
    f4.f->id_override = 0x12345678;
    CHECK_EQ(sfs_dev_open(&d, &f4.tp0, 0), SFS_E_NO_DEVICE);
    f4.f->id_override = 0;
    f4.f->version_override = 0x00020000;
    CHECK_EQ(sfs_dev_open(&d, &f4.tp0, 0), SFS_E_VERSION);
    f4.f->version_override = 0x00010007;
    CHECK_EQ(sfs_dev_open(&d, &f4.tp0, 0), 0);
    f4.f->version_override = 0;
    f4.f->caps0_override = 8u | (64u << 8) | (64u << 16) | (12u << 24);
    CHECK_EQ(sfs_dev_open(&d, &f4.tp0, 0), SFS_E_VERSION);
    f4.f->caps0_override = 0u | (64u << 8) | (64u << 16) | (9u << 24);  // MDTS 0
    CHECK_EQ(sfs_dev_open(&d, &f4.tp0, 0), SFS_E_UNSUPPORTED);
    f4.f->use_overrides = false;
    // argument checks
    sfs_transport_t bad = f4.tp0;
    bad.mem_alloc = nullptr;
    CHECK_EQ(sfs_dev_open(&d, &bad, 0), SFS_E_INVAL);
    bad = f4.tp0; bad.mmio_read32 = nullptr;
    CHECK_EQ(sfs_dev_open(&d, &bad, 0), SFS_E_INVAL);
    bad = f4.tp0; bad.mmio_write32 = nullptr;
    CHECK_EQ(sfs_dev_open(&d, &bad, 0), SFS_E_INVAL);
    bad = f4.tp0; bad.mem_free = nullptr;
    CHECK_EQ(sfs_dev_open(&d, &bad, 0), SFS_E_INVAL);
    CHECK_EQ(sfs_dev_open(nullptr, &f4.tp0, 0), SFS_E_INVAL);
    CHECK_EQ(sfs_dev_open(&d, nullptr, 0), SFS_E_INVAL);
    CHECK_EQ(sfs_dev_open(&d, &f4.tp0, 70000), SFS_E_INVAL);
    bad = f4.tp0; bad.yield = nullptr; bad.barrier = nullptr;  // optional hooks
    CHECK_EQ(sfs_dev_open(&d, &bad, 0), 0);
    CHECK_EQ(sfs_dev_refresh_caps(nullptr), SFS_E_STATE);
    sfs_dev_t never;
    std::memset(&never, 0, sizeof(never));
    CHECK_EQ(sfs_dev_refresh_caps(&never), SFS_E_STATE);
  }
  CHECK_EQ(fx.f->abi_errors, 0);
  CHECK_EQ(fx.f->bus_errors, 0);
}

// ---------------------------------------------------------------------------------------------
static void test_queue_lifecycle() {
  section("queue create / destroy / reset (§8 bring-up)");
  Fixture fx(MockFabric::Cfg(), false);
  MockFabric& f = *fx.f;
  CHECK_EQ(sfs_dev_open(&fx.d0, &fx.tp0, 0), 0);
  CHECK_EQ(sfs_mgmt_open(&fx.mg, &fx.mtp), 0);
  {
    sfs_ns_cfg_t ns0;
    std::memset(&ns0, 0, sizeof(ns0));
    ns0.owner = 0; ns0.base = 0; ns0.size = 1024;
    CHECK_EQ(sfs_mgmt_ns_config(&fx.mg, 0, &ns0, nullptr), 0);
  }
  sfs_queue_t q;
  std::memset(&q, 0, sizeof(q));

  // hypervisor has not allowed the queue / fabric not enabled: refused, nothing leaks
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), SFS_E_NOT_ENABLED);
  CHECK_EQ(f.live_allocs(), 0);
  CHECK_EQ(sfs_mgmt_tenant_allow(&fx.mg, 0, 1), 0);
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), SFS_E_NOT_ENABLED);  // fabric GCTRL.ENABLE still 0
  CHECK_EQ(f.live_allocs(), 0);
  CHECK_EQ(sfs_mgmt_enable_fabric(&fx.mg, 1), 0);
  // illegal sizes are rejected locally and nothing is allocated
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 1, 8), SFS_E_INVAL);
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 0, 8), SFS_E_INVAL);
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 3, 8), SFS_E_INVAL);
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 6), SFS_E_INVAL);
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 128, 8), SFS_E_INVAL);  // > SQ_MAX (64)
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 128), SFS_E_INVAL);  // > CQ_MAX
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), 0);  // and the legal one works
  CHECK(q.active);
  CHECK_EQ(f.live_allocs(), 2);
  CHECK(f.enabled(0));
  CHECK_EQ(q.sq_iova % 64, 0);
  CHECK_EQ(q.cq_iova % 32, 0);
  CHECK_EQ(q.sq_entries, 8);
  CHECK_EQ(q.cq_phase, 1);
  CHECK_EQ(f.abi_errors, 0);  // base alignment + zeroed CQ were checked by the mock at ENABLE
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  CHECK(!f.enabled(0));
  CHECK_EQ(f.live_allocs(), 0);
  CHECK_EQ(sfs_queue_destroy(&q), SFS_E_STATE);
  CHECK_EQ(sfs_poll(&q, nullptr), SFS_E_STATE);
  CHECK_EQ(sfs_ring(&q), SFS_E_STATE);
  CHECK_EQ(sfs_submit_flush(&q, 1, 0), SFS_E_STATE);

  // larger rings, different sizes for SQ and CQ, max sizes
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 64, 2), 0);
  CHECK_EQ(q.sq_entries, 64);
  CHECK_EQ(q.cq_entries, 2);
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 2, 64), 0);
  CHECK_EQ(sfs_queue_destroy(&q), 0);

  // sticky DB_ERR from a previous life is cleared by create
  fx.c0.wr_count.clear();
  fx.tp0.mmio_write32(fx.tp0.ctx, SFS_REG_SQ_SIZE, 3);  // illegal while disabled: ignored, sets DB_ERR
  sfs_qstatus_t st;
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(st.irq_db_err);
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), 0);
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(!st.irq_db_err && st.enabled && !st.fatal);
  CHECK_EQ(sfs_queue_destroy(&q), 0);

  // allocation failures: no leaks, correct errors
  f.fail_alloc_after = 0;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), SFS_E_NOMEM);
  CHECK_EQ(f.live_allocs(), 0);
  f.fail_alloc_after = 1;  // CQ allocation fails
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), SFS_E_NOMEM);
  CHECK_EQ(f.live_allocs(), 0);
  f.misalign_alloc = true;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), SFS_E_ALIGN);
  CHECK_EQ(f.live_allocs(), 0);
  f.misalign_alloc = false;
  // a device that rejects the SQ size although CAPS allowed it: BAD_SIZE (DB_ERR), no leak, queue not enabled
  f.lie_sq_max = 16;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 32, 8), SFS_E_BAD_SIZE);
  CHECK_EQ(f.live_allocs(), 0);
  CHECK(!f.enabled(0));
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 16, 8), 0);
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  f.lie_sq_max = 0;

  // stale state: another driver instance left the queue enabled with commands in flight
  f.delay = 1000;
  sfs_queue_t old;
  std::memset(&old, 0, sizeof(old));
  CHECK_EQ(sfs_queue_create(&fx.d0, &old, 8, 8), 0);
  sfs_buf_t b;
  CHECK_EQ(sfs_buf_alloc(&fx.d0, 4096, &b), 0);
  CHECK_EQ(sfs_submit_read(&old, 1, 0, 0, 1, b.iova, 0), 0);
  CHECK_EQ(sfs_ring(&old), 0);
  CHECK_EQ(f.pending_count(0), 1);
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), 0);  // must reset the stale queue first
  CHECK_EQ(f.pending_count(0), 0);
  CHECK_EQ(f.cq_tail(0), 0);
  f.delay = 0;
  sfs_cqe_t cqe;
  CHECK_EQ(sfs_poll(&q, &cqe), 0);  // the aborted command produced no completion
  uint64_t cap = 0;
  CHECK_EQ(sfs_capacity_sync(&q, 0, &cap, &cqe), 0);
  CHECK_EQ(cap, 1024);
  fx.d0.tp.mem_free(fx.d0.tp.ctx, old.sq_iova);
  fx.d0.tp.mem_free(fx.d0.tp.ctx, old.cq_iova);
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  sfs_buf_free(&fx.d0, &b);
  CHECK_EQ(f.live_allocs(), 0);

  // sfs_queue_reset: works whether or not the device keeps base/size across RESET
  for (int variant = 0; variant < 2; ++variant) {
    f.reset_clears_cfg = (variant == 1);
    CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), 0);
    sfs_buf_t bb;
    CHECK_EQ(sfs_buf_alloc(&fx.d0, 4096, &bb), 0);
    for (int i = 0; i < 5; ++i) CHECK_EQ(sfs_write_sync(&q, 0, uint64_t(i), 1, bb.iova, bb.va, 0, &cqe), 0);
    CHECK_EQ(sfs_queue_reset(&q), 0);
    CHECK(q.active && f.enabled(0));
    CHECK_EQ(q.submitted, 0);
    CHECK_EQ(q.cq_phase, 1);
    CHECK_EQ(f.sq_head(0), 0);
    for (int i = 0; i < 12; ++i) CHECK_EQ(sfs_read_sync(&q, 0, uint64_t(i), 1, bb.iova, 0, &cqe), 0);
    CHECK_EQ(sfs_queue_destroy(&q), 0);
    sfs_buf_free(&fx.d0, &bb);
  }
  f.reset_clears_cfg = false;
  CHECK_EQ(f.live_allocs(), 0);
  CHECK_EQ(sfs_queue_reset(&q), SFS_E_STATE);
  CHECK_EQ(f.abi_errors, 0);
}

// ---------------------------------------------------------------------------------------------
static void test_basic_io() {
  section("read/write/flush/discard/capacity wrappers; flags; CRC");
  Fixture fx;
  MockFabric& f = *fx.f;
  sfs_queue_t q;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 16, 16), 0);
  sfs_buf_t w, r;
  CHECK_EQ(sfs_buf_alloc(&fx.d0, 8 * 512, &w), 0);
  CHECK_EQ(sfs_buf_alloc(&fx.d0, 8 * 512, &r), 0);
  fill_pat(static_cast<uint8_t*>(w.va), w.len, 1);
  sfs_cqe_t c;

  // plain write (volatile cache backend: DURABLE = 0)
  int rc = sfs_write_sync(&q, 0, 10, 8, w.iova, w.va, 0, &c);
  CHECK_EQ(rc, 0);
  cross_check_cqe(c);
  CHECK(c.status == 0 && c.detail == 0 && c.nblk_done == 8 && !c.durable && !c.crc_valid && c.opcode == SFS_OP_WRITE);
  CHECK(c.tenant == 0 && c.txn == 1 && c.latency > 0);
  // read it back
  std::memset(r.va, 0xEE, r.len);
  CHECK_EQ(sfs_read_sync(&q, 0, 10, 8, r.iova, 0, &c), 0);
  CHECK(c.status == 0 && c.nblk_done == 8 && c.opcode == SFS_OP_READ);
  CHECK(std::memcmp(r.va, w.va, 8 * 512) == 0);
  std::string why;
  CHECK(f.model.check_read(0, 10, 8, static_cast<uint8_t*>(r.va), why));
  // partial: 3 blocks at an unaligned lba
  std::memset(r.va, 0xEE, r.len);
  CHECK_EQ(sfs_read_sync(&q, 0, 12, 3, r.iova, 0, &c), 0);
  CHECK(std::memcmp(r.va, static_cast<uint8_t*>(w.va) + 2 * 512, 3 * 512) == 0);
  CHECK(static_cast<uint8_t*>(r.va)[3 * 512] == 0xEE);  // nothing written beyond the transfer

  // never-written block reads zeros, SUCCESS
  CHECK_EQ(sfs_read_sync(&q, 0, 900, 2, r.iova, 0, &c), 0);
  bool zeros = true;
  for (int i = 0; i < 1024; ++i) zeros = zeros && static_cast<uint8_t*>(r.va)[i] == 0;
  CHECK(zeros);

  // FUA: durable on completion; RCRC on write; HCRC computed by the library
  fill_pat(static_cast<uint8_t*>(w.va), w.len, 2);
  CHECK_EQ(sfs_write_sync(&q, 0, 20, 2, w.iova, w.va, SFS_FLAG_FUA | SFS_FLAG_RCRC | SFS_FLAG_HCRC, &c), 0);
  CHECK(c.durable && c.crc_valid && c.result0 == sfs_crc32c(w.va, 1024) && c.result1 == 0);
  CHECK_EQ(sfs_read_sync(&q, 0, 20, 2, r.iova, SFS_FLAG_RCRC, &c), 0);
  CHECK(c.crc_valid && c.result0 == sfs_crc32c(r.va, 1024) && c.result0 == sfs_crc32c(w.va, 1024));
  // flush completes durable
  CHECK_EQ(sfs_flush_sync(&q, 0, &c), 0);
  CHECK(c.durable && c.opcode == SFS_OP_FLUSH && c.nblk_done == 0);
  // GET_CAPACITY
  uint64_t cap = 0;
  CHECK_EQ(sfs_capacity_sync(&q, 0, &cap, &c), 0);
  CHECK_EQ(cap, 1024);
  CHECK_EQ(sfs_capacity_sync(&q, 1, &cap, &c), 0);
  CHECK_EQ(cap, 64);
  CHECK_EQ(sfs_capacity_sync(&q, 0, nullptr, nullptr), 0);
  // DISCARD: blocks read as zeros afterwards
  CHECK_EQ(sfs_discard_sync(&q, 0, 20, 1, &c), 0);
  CHECK(c.nblk_done == 1 && !c.durable);
  CHECK_EQ(sfs_read_sync(&q, 0, 20, 2, r.iova, 0, &c), 0);
  zeros = true;
  for (int i = 0; i < 512; ++i) zeros = zeros && static_cast<uint8_t*>(r.va)[i] == 0;
  CHECK(zeros);
  CHECK(std::memcmp(static_cast<uint8_t*>(r.va) + 512, static_cast<uint8_t*>(w.va) + 512, 512) == 0);

  // read-only namespace: reads and flush fine, write rejected
  CHECK_EQ(sfs_read_sync(&q, 1, 0, 1, r.iova, 0, &c), 0);
  CHECK_EQ(sfs_flush_sync(&q, 1, &c), 0);

  // client-side argument checks
  CHECK_EQ(sfs_submit_read(&q, 1, 0, 0, 0, r.iova, 0), SFS_E_INVAL);      // nblk 0
  CHECK_EQ(sfs_submit_read(&q, 1, 0, 0, 9, r.iova, 0), SFS_E_INVAL);      // > MDTS
  CHECK_EQ(sfs_submit_read(&q, 1, 0, 0, 1, r.iova + 2, 0), SFS_E_INVAL);  // not 4-byte aligned
  CHECK_EQ(sfs_submit_read(&q, 1, 256, 0, 1, r.iova, 0), SFS_E_INVAL);    // NSID > 255
  CHECK_EQ(sfs_submit_read(&q, 1, 0, 0, 1, r.iova, SFS_FLAG_FUA), SFS_E_INVAL);
  CHECK_EQ(sfs_submit_read(&q, 1, 0, 0, 1, r.iova, SFS_FLAG_HCRC), SFS_E_INVAL);
  CHECK_EQ(sfs_submit_read(&q, 1, 0, 0, 1, r.iova, 0x8), SFS_E_INVAL);    // reserved flag bit
  CHECK_EQ(sfs_submit_write(&q, 1, 0, 0, 1, w.iova, nullptr, SFS_FLAG_HCRC), SFS_E_INVAL);  // HCRC needs data_va
  CHECK_EQ(sfs_submit_write(&q, 1, 0, 0, 1, w.iova, nullptr, 0x10), SFS_E_INVAL);
  CHECK_EQ(sfs_submit_discard(&q, 1, 0, 0, 0), SFS_E_INVAL);
  CHECK_EQ(sfs_submit_discard(&q, 1, 0, 0, 65536), SFS_E_INVAL);
  CHECK_EQ(sfs_submit_raw(&q, nullptr), SFS_E_INVAL);
  CHECK_EQ(sfs_submit_desc(&q, nullptr), SFS_E_INVAL);
  CHECK_EQ(sfs_inflight(&q), 0);  // none of those queued anything

  // write with caps that lack FUA/HCRC/discard -> UNSUPPORTED locally
  {
    sfs_dev_t d = fx.d0;
    d.caps.fua = 0; d.caps.hcrc = 0; d.caps.discard = 0;
    sfs_queue_t q2 = q;
    q2.dev = &d;
    CHECK_EQ(sfs_submit_write(&q2, 1, 0, 0, 1, w.iova, w.va, SFS_FLAG_FUA), SFS_E_UNSUPPORTED);
    CHECK_EQ(sfs_submit_write(&q2, 1, 0, 0, 1, w.iova, w.va, SFS_FLAG_HCRC), SFS_E_UNSUPPORTED);
    CHECK_EQ(sfs_submit_discard(&q2, 1, 0, 0, 1), SFS_E_UNSUPPORTED);
  }

  // sync wrappers refuse to run while other commands are in flight
  CHECK_EQ(sfs_submit_flush(&q, 77, 0), 0);
  CHECK_EQ(sfs_flush_sync(&q, 0, &c), SFS_E_BUSY);
  CHECK_EQ(sfs_read_sync(&q, 0, 0, 1, r.iova, 0, &c), SFS_E_BUSY);
  CHECK_EQ(wait_ck(&q, &c), 0);  // sfs_wait rings the unrung submission itself
  CHECK_EQ(c.txn, 77);
  CHECK_EQ(sfs_inflight(&q), 0);

  CHECK_EQ(f.db_errors, 0);
  CHECK_EQ(f.abi_errors, 0);
  CHECK_EQ(f.bus_errors, 0);

  // write-through backend: every write completes DURABLE
  {
    MockFabric::Cfg cfg;
    cfg.vol = false;
    Fixture f2(cfg);
    sfs_queue_t q2;
    CHECK_EQ(sfs_queue_create(&f2.d0, &q2, 8, 8), 0);
    sfs_buf_t b2;
    CHECK_EQ(sfs_buf_alloc(&f2.d0, 512, &b2), 0);
    fill_pat(static_cast<uint8_t*>(b2.va), 512, 5);
    CHECK_EQ(sfs_write_sync(&q2, 0, 0, 1, b2.iova, b2.va, 0, &c), 0);
    CHECK(c.durable);
    CHECK_EQ(sfs_discard_sync(&q2, 0, 0, 1, &c), 0);
    CHECK(c.durable);
    sfs_buf_free(&f2.d0, &b2);
    CHECK_EQ(sfs_queue_destroy(&q2), 0);
  }
  // backend without DISCARD: library says UNSUPPORTED, a raw descriptor gets the device's UNSUPPORTED status
  {
    MockFabric::Cfg cfg;
    cfg.discard = false;
    Fixture f2(cfg);
    sfs_queue_t q2;
    CHECK_EQ(sfs_queue_create(&f2.d0, &q2, 8, 8), 0);
    CHECK_EQ(sfs_discard_sync(&q2, 0, 0, 1, &c), SFS_E_UNSUPPORTED);
    sfs_desc_t d;
    std::memset(&d, 0, sizeof(d));
    d.version = 1; d.opcode = SFS_OP_DISCARD; d.txn = 9; d.nsid = 0; d.nblk = 1; d.tenant_claim = 0;
    CHECK_EQ(sfs_submit_desc(&q2, &d), 0);
    CHECK_EQ(wait_ck(&q2, &c), 0);
    CHECK_EQ(c.status, SFS_ST_UNSUPPORTED);
    CHECK_EQ(sfs_queue_destroy(&q2), 0);
  }
  // PI namespace: PI_VERIFIED on completions; refused on a backend without PI_NATIVE
  {
    Fixture f2;
    sfs_ns_cfg_t n;
    std::memset(&n, 0, sizeof(n));
    n.owner = 0; n.base = 8192; n.size = 100; n.pi = 1;
    uint32_t nss = 0;
    CHECK_EQ(sfs_mgmt_ns_config(&f2.mg, 4, &n, &nss), 0);
    CHECK_EQ(nss, SFS_NSS_ACCEPTED);
    CHECK_EQ(sfs_dev_refresh_caps(&f2.d0), 0);
    sfs_queue_t q2;
    CHECK_EQ(sfs_queue_create(&f2.d0, &q2, 8, 8), 0);
    sfs_buf_t b2;
    CHECK_EQ(sfs_buf_alloc(&f2.d0, 512, &b2), 0);
    CHECK_EQ(sfs_write_sync(&q2, 4, 0, 1, b2.iova, b2.va, 0, &c), 0);
    CHECK(c.pi_verified && !c.encrypted);
    CHECK_EQ(sfs_read_sync(&q2, 4, 0, 1, b2.iova, 0, &c), 0);
    CHECK(c.pi_verified);
    CHECK_EQ(sfs_read_sync(&q2, 4, 50, 1, b2.iova, 0, &c), 0);
    CHECK(!c.pi_verified);  // never-written block: PI_VERIFIED = 0 (§5.7)
    sfs_buf_free(&f2.d0, &b2);
    CHECK_EQ(sfs_queue_destroy(&q2), 0);
    MockFabric::Cfg nopi;
    nopi.pi_native = false;
    Fixture f3(nopi);
    CHECK_EQ(sfs_mgmt_ns_config(&f3.mg, 4, &n, &nss), SFS_E_REFUSED);
    CHECK_EQ(nss, SFS_NSS_PI_UNSUPPORTED);
  }
  sfs_buf_free(&fx.d0, &w);
  sfs_buf_free(&fx.d0, &r);
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  CHECK_EQ(f.live_allocs(), 0);
}

// ---------------------------------------------------------------------------------------------
static void test_desc_layout() {
  section("descriptors on the wire (§2): little-endian layout, reserved fields zero");
  Fixture fx;
  MockFabric& f = *fx.f;
  sfs_queue_t q;
  CHECK_EQ(sfs_queue_create(&fx.d1, &q, 16, 16), 0);
  f.stall_fetch = true;  // inspect before the device consumes
  sfs_buf_t b;
  CHECK_EQ(sfs_buf_alloc(&fx.d1, 8 * 512, &b), 0);
  fill_pat(static_cast<uint8_t*>(b.va), b.len, 3);

  auto slot_words = [&](unsigned slot, uint32_t w[16]) {
    const uint8_t* p = q.sq_va + slot * 64u;
    for (int i = 0; i < 16; ++i) w[i] = uint32_t(p[4 * i]) | (uint32_t(p[4 * i + 1]) << 8) | (uint32_t(p[4 * i + 2]) << 16) | (uint32_t(p[4 * i + 3]) << 24);
  };
  const uint64_t lba = 0x0102030405060708ull;
  CHECK_EQ(sfs_submit_read(&q, 0x1234, 3, lba, 5, b.iova + 8, SFS_FLAG_RCRC), 0);           // slot 0
  CHECK_EQ(sfs_submit_write(&q, 0xBEEF, 2, 7, 8, b.iova, b.va, SFS_FLAG_FUA | SFS_FLAG_HCRC | SFS_FLAG_RCRC), 0);  // slot 1
  CHECK_EQ(sfs_submit_flush(&q, 3, 3), 0);                                                   // slot 2
  CHECK_EQ(sfs_submit_get_capacity(&q, 4, 2), 0);                                            // slot 3
  CHECK_EQ(sfs_submit_discard(&q, 5, 3, 0x1FFFFFFFFull, 65535), 0);                          // slot 4
  CHECK_EQ(sfs_submit_write_crc(&q, 6, 3, 1, 1, b.iova, SFS_FLAG_HCRC, 0xDEADBEEFu), 0);     // slot 5
  CHECK_EQ(sfs_submit_write(&q, 7, 3, 1, 1, b.iova, nullptr, 0), 0);                         // slot 6
  CHECK_EQ(q.sq_tail, 7);
  CHECK_EQ(q.sq_db, 0);  // nothing rung yet
  uint32_t w[16];
  sfref::Desc d;
  slot_words(0, w);
  d = sfref::decode(w);
  CHECK(d.version == 1 && d.opcode == SFS_OP_READ && d.flags == SFS_F_RCRC && d.txn == 0x1234 && d.nsid == 3);
  CHECK(d.lba == lba && d.nblk == 5 && d.data_len == 5 * 512 && d.data_addr == b.iova + 8 && d.claim == 1 && d.host_crc == 0);
  CHECK(d.rsv1 == 0 && d.rsv8 == 0);
  for (int i = 10; i < 16; ++i) CHECK_EQ(w[i], 0);
  // raw byte positions (explicit little-endian, no host-endianness assumption)
  const uint8_t* p0 = q.sq_va;
  CHECK(p0[0] == 1 && p0[1] == SFS_OP_READ && p0[2] == SFS_F_RCRC && p0[3] == 0);
  CHECK(p0[4] == 0x34 && p0[5] == 0x12 && p0[6] == 3 && p0[7] == 0);
  for (int i = 0; i < 8; ++i) CHECK_EQ(p0[8 + i], 8 - i);  // LBA 0x0102030405060708, low byte first
  CHECK(p0[16] == 5 && p0[17] == 0 && p0[20] == 0x00 && p0[21] == 0x0A);  // NBLK=5, DATA_LEN=2560=0x0A00
  CHECK(p0[32] == 1 && p0[33] == 0);  // TENANT_CLAIM = 1 (this is tenant 1's page)
  slot_words(1, w);
  d = sfref::decode(w);
  CHECK(d.opcode == SFS_OP_WRITE && d.flags == (SFS_F_FUA | SFS_F_HCRC | SFS_F_RCRC) && d.txn == 0xBEEF && d.nsid == 2);
  CHECK(d.lba == 7 && d.nblk == 8 && d.data_len == 4096 && d.data_addr == b.iova);
  CHECK_EQ(d.host_crc, sfs_crc32c(b.va, 4096));
  CHECK(d.claim == 1 && d.rsv1 == 0 && d.rsv8 == 0);
  slot_words(2, w);
  d = sfref::decode(w);
  CHECK(d.opcode == SFS_OP_FLUSH && d.txn == 3 && d.nsid == 3 && d.nblk == 0 && d.data_len == 0 && d.data_addr == 0 && d.flags == 0 && d.lba == 0);
  slot_words(3, w);
  d = sfref::decode(w);
  CHECK(d.opcode == SFS_OP_GET_CAPACITY && d.txn == 4 && d.nsid == 2 && d.nblk == 0 && d.data_len == 0 && d.data_addr == 0);
  slot_words(4, w);
  d = sfref::decode(w);
  CHECK(d.opcode == SFS_OP_DISCARD && d.lba == 0x1FFFFFFFFull && d.nblk == 65535 && d.data_len == 0 && d.data_addr == 0 && d.flags == 0);
  slot_words(5, w);
  d = sfref::decode(w);
  CHECK(d.flags == SFS_F_HCRC && d.host_crc == 0xDEADBEEFu);
  slot_words(6, w);
  d = sfref::decode(w);
  CHECK(d.flags == 0 && d.host_crc == 0);  // HOST_CRC must be 0 without HCRC
  // every descriptor the library builds passes the model's §2 validation (reserved fields etc.)
  for (unsigned s = 0; s < 7; ++s) {
    slot_words(s, w);
    sfref::Verdict v = f.model.validate(1, w, 1);
    CHECK(v.ok || v.rule >= 10);  // LBA range of slot 0/4 is intentionally absurd; no earlier rule may fail
  }
  // doorbell: one write publishes the whole batch, after a barrier
  fx.c1.wr_count.clear();
  unsigned b0 = fx.c1.barrier_calls;
  CHECK_EQ(sfs_ring(&q), 0);
  CHECK_EQ(fx.c1.wr_count[SFS_REG_SQ_TAIL], 1);
  CHECK(fx.c1.barrier_calls > b0);
  CHECK_EQ(f.db_errors, 0);
  CHECK_EQ(sfs_ring(&q), 0);  // nothing new: no extra doorbell
  CHECK_EQ(fx.c1.wr_count[SFS_REG_SQ_TAIL], 1);
  f.stall_fetch = false;
  f.tick();
  sfs_cqe_t c;
  std::set<unsigned> txns;
  for (int i = 0; i < 7; ++i) {
    CHECK_EQ(wait_ck(&q, &c), 0);
    txns.insert(c.txn);
  }
  CHECK_EQ(txns.size(), 7);
  CHECK_EQ(sfs_inflight(&q), 0);
  sfs_buf_free(&fx.d1, &b);
  CHECK_EQ(sfs_queue_destroy(&q), 0);
}

// ---------------------------------------------------------------------------------------------
static void test_wrap_and_full() {
  section("ring wrap-around, phase flip, ring-full (§3, §8)");
  Fixture fx;
  MockFabric& f = *fx.f;
  sfs_queue_t q;
  const uint32_t SQN = 8, CQN = 8;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, SQN, CQN), 0);
  sfs_buf_t bufs[8];
  for (auto& b : bufs) CHECK_EQ(sfs_buf_alloc(&fx.d0, 512, &b), 0);
  sfs_buf_t wb;
  CHECK_EQ(sfs_buf_alloc(&fx.d0, 512, &wb), 0);
  const uint32_t NBLKS = 64;
  sfs_cqe_t c;
  uint8_t pat[512];
  for (uint32_t i = 0; i < NBLKS; ++i) {
    fill_pat(pat, 512, 1000 + i);
    std::memcpy(wb.va, pat, 512);
    CHECK_EQ(sfs_write_sync(&q, 0, i, 1, wb.iova, wb.va, 0, &c), 0);
  }
  const uint64_t base_done = q.completed;
  // batches of 1..7 reads, many more commands than 3x ring size
  uint32_t seed = 7, total = 0, wrong = 0, phase_err = 0, ooo_seen = 0;
  uint16_t txn = 100;
  while (total < 200) {
    const uint32_t k = 1 + lcg(seed) % 7;  // 1..7 == SQ_SIZE-1
    uint32_t lbas[8];
    for (uint32_t i = 0; i < k; ++i) {
      lbas[i] = lcg(seed) % NBLKS;
      std::memset(bufs[i].va, 0xCC, 512);
      CHECK_EQ(sfs_submit_read(&q, uint16_t(txn + i), 0, lbas[i], 1, bufs[i].iova, 0), 0);
    }
    CHECK_EQ(sfs_ring(&q), 0);
    for (uint32_t i = 0; i < k; ++i) {
      CHECK_EQ(sfs_wait(&q, &c, 1000), 0);
      const uint64_t idx = q.completed - 1;  // this completion's absolute index
      const uint32_t exp_phase = ((idx - 0) / CQN) % 2 == 0 ? 1u : 0u;
      // writes done before the loop also consumed CQ entries: phase follows absolute count
      if (c.phase != exp_phase) ++phase_err;
      const uint32_t j = uint16_t(c.txn - txn);
      if (j >= k) { ++wrong; continue; }
      if (j != i) ++ooo_seen;
      fill_pat(pat, 512, 1000 + lbas[j]);
      if (std::memcmp(bufs[j].va, pat, 512) != 0 || c.status != 0) ++wrong;
    }
    total += k;
    txn = uint16_t(txn + 8);
  }
  CHECK_EQ(wrong, 0);
  CHECK_EQ(phase_err, 0);
  CHECK(q.completed - base_done >= 200);
  CHECK(q.completed >= 3 * SQN && q.completed >= 3 * CQN);
  CHECK_EQ(ooo_seen, 0);  // this mock completes in order unless told otherwise
  CHECK_EQ(f.db_errors, 0);
  CHECK_EQ(q.cq_head, q.completed % CQN);
  CHECK_EQ(q.sq_tail, q.submitted % SQN);
  CHECK_EQ(f.cq_tail(0), q.completed % CQN);  // device and library agree on the ring state

  // ring-full: SQ_SIZE-1 entries fit, the next is refused (never written)
  f.stall_fetch = true;
  const uint16_t t0 = 500;
  for (uint32_t i = 0; i < SQN - 1; ++i) CHECK_EQ(sfs_submit_read(&q, uint16_t(t0 + i), 0, i, 1, bufs[i].iova, 0), 0);
  CHECK_EQ(sfs_sq_space(&q), 0);
  CHECK_EQ(sfs_submit_read(&q, 999, 0, 0, 1, bufs[0].iova, 0), SFS_E_FULL);
  CHECK_EQ(sfs_submit_flush(&q, 998, 0), SFS_E_FULL);
  CHECK_EQ(sfs_submit_get_capacity(&q, 997, 0), SFS_E_FULL);
  CHECK_EQ(sfs_submit_discard(&q, 996, 0, 0, 1), SFS_E_FULL);
  CHECK_EQ(sfs_submit_write(&q, 995, 0, 0, 1, wb.iova, wb.va, 0), SFS_E_FULL);
  sfs_desc_t dd;
  std::memset(&dd, 0, sizeof(dd));
  CHECK_EQ(sfs_submit_desc(&q, &dd), SFS_E_FULL);
  uint32_t raw[16] = {};
  CHECK_EQ(sfs_submit_raw(&q, raw), SFS_E_FULL);
  CHECK_EQ(sfs_inflight(&q), SQN - 1);
  CHECK_EQ(sfs_ring(&q), 0);  // exactly SQ_SIZE-1 outstanding: legal doorbell, no DB_ERR
  CHECK_EQ(f.db_errors, 0);
  // device consumes the SQ but completions are not yet consumed: space reappears from SQ_HEAD
  f.stall_fetch = false;
  f.delay = 50;
  f.tick();
  CHECK_EQ(f.sq_head(0), q.sq_tail);  // the device consumed everything we rang
  CHECK_EQ(sfs_sq_space(&q), (int)(SQN - 1));
  CHECK_EQ(sfs_submit_get_capacity(&q, 600, 0), 0);  // accepted without any completion having been consumed
  CHECK_EQ(sfs_ring(&q), 0);
  f.delay = 0;
  std::set<unsigned> seen;
  for (uint32_t i = 0; i < SQN; ++i) {
    CHECK_EQ(wait_ck(&q, &c, 100000), 0);
    seen.insert(c.txn);
  }
  CHECK_EQ(seen.size(), SQN);
  CHECK(seen.count(600) == 1);
  CHECK_EQ(sfs_sq_space(&q), (int)(SQN - 1));
  CHECK_EQ(f.db_errors, 0);

  // minimal rings: 2 entries each, one command at a time
  sfs_queue_t q2;
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  CHECK_EQ(sfs_queue_create(&fx.d0, &q2, 2, 2), 0);
  for (int i = 0; i < 25; ++i) {
    CHECK_EQ(sfs_submit_get_capacity(&q2, uint16_t(i + 1), 0), 0);
    CHECK_EQ(sfs_submit_get_capacity(&q2, 4000, 0), SFS_E_FULL);  // second one does not fit in a 2-entry ring
    CHECK_EQ(sfs_ring(&q2), 0);
    CHECK_EQ(wait_ck(&q2, &c), 0);
    CHECK_EQ(c.txn, i + 1);
    CHECK_EQ(c.phase, ((i / 2) % 2 == 0) ? 1 : 0);
  }
  CHECK_EQ(f.db_errors, 0);
  CHECK_EQ(sfs_queue_destroy(&q2), 0);

  // large rings wrap too (SQ 32, CQ 4: CQ wraps 8x faster)
  CHECK_EQ(sfs_queue_create(&fx.d0, &q2, 32, 4), 0);
  uint32_t n_ok = 0;
  for (int round = 0; round < 20; ++round) {
    for (int i = 0; i < 3; ++i) CHECK_EQ(sfs_submit_get_capacity(&q2, uint16_t(round * 3 + i), 0), 0);
    CHECK_EQ(sfs_ring(&q2), 0);
    for (int i = 0; i < 3; ++i) {
      CHECK_EQ(wait_ck(&q2, &c), 0);
      n_ok += (c.status == 0 && c.result0 == 1024);
    }
  }
  CHECK_EQ(n_ok, 60);
  CHECK_EQ(sfs_queue_destroy(&q2), 0);
  for (auto& b : bufs) sfs_buf_free(&fx.d0, &b);
  sfs_buf_free(&fx.d0, &wb);
  CHECK_EQ(f.live_allocs(), 0);
  CHECK_EQ(f.abi_errors, 0);
}

// ---------------------------------------------------------------------------------------------
static void test_poll_semantics() {
  section("poll with nothing pending, acquire ordering, wait timeout, batching, autoring");
  Fixture fx;
  MockFabric& f = *fx.f;
  sfs_queue_t q;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 4), 0);
  sfs_cqe_t c;
  std::memset(&c, 0x5A, sizeof(c));
  fx.c0.wr_count.clear();
  unsigned b0 = fx.c0.barrier_calls;
  for (int i = 0; i < 50; ++i) CHECK_EQ(sfs_poll(&q, &c), 0);
  CHECK_EQ(fx.c0.wr_count[SFS_REG_CQ_HEAD], 0);  // an empty poll rings nothing
  CHECK_EQ(c.txn, 0x5A5A);                       // and leaves the output untouched
  CHECK_EQ(fx.c0.barrier_calls, b0);             // no acquire barrier without a phase match

  // stale CQ contents: a half-written entry (words 0..6 present, PHASE word not yet) must not be consumed
  {
    volatile uint8_t* e = q.cq_va;
    e[0] = 0x34; e[1] = 0x12; e[2] = 0x05;  // looks like txn 0x1234 status 5
    CHECK_EQ(sfs_poll(&q, &c), 0);
  }
  for (int i = 0; i < 32; ++i) q.cq_va[i] = 0;  // restore the zero state the device expects

  // wait timeout
  unsigned y0 = fx.c0.yield_calls;
  CHECK_EQ(sfs_wait(&q, &c, 5), SFS_E_TIMEOUT);
  CHECK(fx.c0.yield_calls >= y0 + 4);

  // acquire barrier between the PHASE read and the rest, on every consumed entry
  CHECK_EQ(sfs_submit_get_capacity(&q, 1, 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  f.tick();
  b0 = fx.c0.barrier_calls;
  CHECK_EQ(sfs_poll(&q, &c), 1);
  CHECK(fx.c0.barrier_calls >= b0 + 1);
  cross_check_cqe(c);
  CHECK_EQ(c.txn, 1);
  CHECK_EQ(fx.c0.wr_count[SFS_REG_CQ_HEAD], 1);  // head doorbell written for the consumed entry
  CHECK_EQ(f.cq_tail(0), 1);
  // consume without an output struct
  CHECK_EQ(sfs_submit_get_capacity(&q, 2, 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  f.tick();
  CHECK_EQ(sfs_poll(&q, nullptr), 1);
  CHECK_EQ(sfs_poll(&q, nullptr), 0);

  // transports without yield/barrier use the compiler-barrier fallback and still work
  {
    sfs_transport_t tp = fx.tp0;
    tp.yield = nullptr;
    tp.barrier = nullptr;
    sfs_dev_t d;
    CHECK_EQ(sfs_dev_open(&d, &tp, 0), 0);
    CHECK_EQ(sfs_queue_destroy(&q), 0);
    sfs_queue_t qn;
    CHECK_EQ(sfs_queue_create(&d, &qn, 8, 8), 0);
    CHECK_EQ(sfs_submit_get_capacity(&qn, 3, 0), 0);
    CHECK_EQ(sfs_ring(&qn), 0);
    CHECK_EQ(sfs_wait(&qn, &c, 10), 0);
    CHECK_EQ(c.txn, 3);
    CHECK_EQ(sfs_wait(&qn, &c, 3), SFS_E_TIMEOUT);  // nothing pending, NULL yield is fine
    CHECK_EQ(sfs_queue_destroy(&qn), 0);
  }

  // autoring: one doorbell per submit; without it a batch needs one sfs_ring
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 16, 16), 0);
  fx.c0.wr_count.clear();
  for (int i = 0; i < 5; ++i) CHECK_EQ(sfs_submit_get_capacity(&q, uint16_t(10 + i), 0), 0);
  CHECK_EQ(fx.c0.wr_count[SFS_REG_SQ_TAIL], 0);
  CHECK_EQ(sfs_ring(&q), 0);
  CHECK_EQ(fx.c0.wr_count[SFS_REG_SQ_TAIL], 1);
  for (int i = 0; i < 5; ++i) CHECK_EQ(wait_ck(&q, &c), 0);
  sfs_queue_set_autoring(&q, 1);
  for (int i = 0; i < 4; ++i) CHECK_EQ(sfs_submit_get_capacity(&q, uint16_t(20 + i), 0), 0);
  CHECK_EQ(fx.c0.wr_count[SFS_REG_SQ_TAIL], 5);  // 1 + 4
  for (int i = 0; i < 4; ++i) CHECK_EQ(wait_ck(&q, &c), 0);
  sfs_queue_set_autoring(&q, 0);

  // CQ_HEAD batching: head doorbell every 4 consumed entries; sfs_wait never starves the device
  sfs_queue_set_cq_batch(&q, 4);
  fx.c0.wr_count.clear();
  for (int i = 0; i < 8; ++i) CHECK_EQ(sfs_submit_get_capacity(&q, uint16_t(30 + i), 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  f.tick();
  for (int i = 0; i < 8; ++i) CHECK_EQ(sfs_poll(&q, &c), 1);
  CHECK_EQ(fx.c0.wr_count[SFS_REG_CQ_HEAD], 2);
  CHECK_EQ(q.cq_unacked, 0);
  CHECK_EQ(sfs_submit_get_capacity(&q, 40, 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  f.tick();
  CHECK_EQ(sfs_poll(&q, &c), 1);
  CHECK_EQ(q.cq_unacked, 1);
  CHECK_EQ(fx.c0.wr_count[SFS_REG_CQ_HEAD], 2);
  CHECK_EQ(sfs_cq_doorbell(&q), 0);
  CHECK_EQ(fx.c0.wr_count[SFS_REG_CQ_HEAD], 3);
  CHECK_EQ(sfs_cq_doorbell(&q), 0);  // idempotent
  CHECK_EQ(fx.c0.wr_count[SFS_REG_CQ_HEAD], 3);
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  // tiny CQ (4 entries = 3 usable) + batch 4 + 12 commands: would deadlock if sfs_wait did not flush the head
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 16, 4), 0);
  sfs_queue_set_cq_batch(&q, 4);
  for (int i = 0; i < 12; ++i) CHECK_EQ(sfs_submit_get_capacity(&q, uint16_t(50 + i), 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  for (int i = 0; i < 12; ++i) CHECK_EQ(wait_ck(&q, &c, 1000), 0);
  CHECK_EQ(sfs_inflight(&q), 0);
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  CHECK_EQ(f.db_errors, 0);
  CHECK_EQ(f.abi_errors, 0);
}

// ---------------------------------------------------------------------------------------------
// §3: "The host must read word 7 (PHASE) first".  Observable without a second thread: the CQ lives in a
// page that is PROT_NONE when sfs_poll() starts; the SIGSEGV handler records the address of the FIRST access
// and then opens the page.
static volatile sig_atomic_t g_fault_hit = 0;
static volatile uintptr_t g_fault_addr = 0;
static void* volatile g_prot_page = nullptr;
static void segv_handler(int, siginfo_t* si, void*) {
  if (!g_fault_hit) {
    g_fault_hit = 1;
    g_fault_addr = reinterpret_cast<uintptr_t>(si->si_addr);
  }
  mprotect(g_prot_page, 4096, PROT_READ | PROT_WRITE);
}
static void test_phase_read_first() {
  section("CQE access order: PHASE word (word 7) is read first (§3)");
  struct sigaction sa, old;
  std::memset(&sa, 0, sizeof(sa));
  sa.sa_sigaction = segv_handler;
  sa.sa_flags = SA_SIGINFO;
  sigemptyset(&sa.sa_mask);
  CHECK_EQ(sigaction(SIGSEGV, &sa, &old), 0);

  Fixture fx;
  MockFabric& f = *fx.f;
  f.page_align_cq = true;
  sfs_queue_t q;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), 0);
  f.page_align_cq = false;
  CHECK_EQ(reinterpret_cast<uintptr_t>(q.cq_va) % 4096, 0);
  g_prot_page = const_cast<uint8_t*>(q.cq_va);
  sfs_cqe_t c;
  auto probe = [&](unsigned slot, int expect_rc) {
    g_fault_hit = 0;
    g_fault_addr = 0;
    CHECK_EQ(mprotect(g_prot_page, 4096, PROT_NONE), 0);
    int rc = sfs_poll(&q, &c);
    mprotect(g_prot_page, 4096, PROT_READ | PROT_WRITE);  // in case no access happened
    CHECK_EQ(rc, expect_rc);
    CHECK_EQ(g_fault_hit, 1);
    CHECK_EQ(g_fault_addr, reinterpret_cast<uintptr_t>(q.cq_va) + slot * 32u + 28u);  // word 7 of the head entry
  };
  probe(0, 0);  // empty ring: only the PHASE word is looked at
  for (unsigned i = 0; i < 3; ++i) {
    CHECK_EQ(sfs_submit_get_capacity(&q, uint16_t(i + 1), 0), 0);
    CHECK_EQ(sfs_ring(&q), 0);
    probe(i, 1);  // ready entry: first access is still word 7, then the rest
    CHECK_EQ(c.txn, i + 1);
  }
  probe(3, 0);
  // exact barrier accounting with doorbell batching off the table: empty poll = 0 barriers, consumed entry = 1
  sfs_queue_set_cq_batch(&q, 1000);
  unsigned b0 = fx.c0.barrier_calls;
  CHECK_EQ(sfs_poll(&q, &c), 0);
  CHECK_EQ(fx.c0.barrier_calls, b0);
  CHECK_EQ(sfs_submit_get_capacity(&q, 9, 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  b0 = fx.c0.barrier_calls;
  CHECK_EQ(sfs_poll(&q, &c), 1);
  CHECK_EQ(fx.c0.barrier_calls, b0 + 1);  // the acquire barrier between PHASE and the other words
  CHECK_EQ(sfs_cq_doorbell(&q), 0);
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  sigaction(SIGSEGV, &old, nullptr);
}

// ---------------------------------------------------------------------------------------------
static void test_partial_fetch() {
  section("a completion does not mean the SQ is drained (ring accounting)");
  Fixture fx;
  MockFabric& f = *fx.f;
  sfs_queue_t q;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), 0);
  sfs_cqe_t c;
  f.fetch_budget = 1;  // the device fetches only the first descriptor for now
  for (int i = 0; i < 6; ++i) CHECK_EQ(sfs_submit_get_capacity(&q, uint16_t(i + 1), 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  CHECK_EQ(wait_ck(&q, &c), 0);
  CHECK_EQ(c.txn, 1);
  CHECK_EQ(f.sq_head(0), 1);  // five descriptors are still in the ring
  CHECK_EQ(sfs_sq_space(&q), 2);  // 7 usable - 5 unconsumed
  CHECK_EQ(sfs_submit_get_capacity(&q, 7, 0), 0);
  CHECK_EQ(sfs_submit_get_capacity(&q, 8, 0), 0);
  CHECK_EQ(sfs_submit_get_capacity(&q, 9, 0), SFS_E_FULL);
  CHECK_EQ(sfs_ring(&q), 0);
  CHECK_EQ(f.db_errors, 0);  // exactly SQ_SIZE-1 outstanding: legal
  f.fetch_budget = -1;
  f.tick();
  std::set<unsigned> seen;
  for (int i = 0; i < 7; ++i) {
    CHECK_EQ(wait_ck(&q, &c), 0);
    seen.insert(c.txn);
  }
  CHECK_EQ(seen.size(), 7);
  CHECK_EQ(sfs_sq_space(&q), 7);
  CHECK_EQ(f.db_errors, 0);
  // a stale/odd completion count can never make the library over-estimate free space
  CHECK_EQ(sfs_queue_destroy(&q), 0);
}

// ---------------------------------------------------------------------------------------------
static void test_doorbell_errors() {
  section("doorbell error cases (§8: illegal SQ_TAIL / CQ_HEAD / SQ_SIZE -> ignored + DB_ERR)");
  Fixture fx;
  MockFabric& f = *fx.f;
  sfs_queue_t q;
  sfs_qstatus_t st;
  char txt[128];

  unsigned inj = 0;  // number of deliberately illegal doorbell/size writes so far
  auto inject = [&](uint32_t off, uint32_t val) {
    fx.tp0.mmio_write32(fx.tp0.ctx, off, val);
    ++inj;
  };
  // illegal ring sizes written while disabled: ignored, DB_ERR
  std::memset(&q, 0, sizeof(q));
  q.dev = &fx.d0;
  inject(SFS_REG_SQ_SIZE, 3);
  inject(SFS_REG_CQ_SIZE, 1);
  inject(SFS_REG_SQ_SIZE, 1024);
  CHECK_EQ(fx.tp0.mmio_read32(fx.tp0.ctx, SFS_REG_SQ_SIZE), 0);
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(st.irq_db_err && st.irq_raw == SFS_IRQ_DB_ERR);
  CHECK_EQ(sfs_queue_ack_irq(&q, SFS_IRQ_DB_ERR), 0);
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(!st.irq_db_err);

  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), 0);
  CHECK_EQ(f.db_errors, inj);  // create itself caused none
  // SQ_TAIL >= SQ_SIZE
  inject(SFS_REG_SQ_TAIL, 8);
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(st.irq_db_err && !st.irq_queue_err && st.enabled && !st.fatal);
  CHECK_EQ(st.sq_tail, 0);  // ignored
  sfs_qstatus_str(&st, txt, sizeof(txt));
  CHECK(std::strstr(txt, "DB_ERR") != nullptr && std::strstr(txt, "ENABLED") != nullptr);
  CHECK_EQ(sfs_queue_ack_irq(&q, SFS_IRQ_DB_ERR), 0);
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(!st.irq_db_err);
  sfs_qstatus_str(&st, txt, sizeof(txt));
  CHECK(std::strstr(txt, "DB_ERR") == nullptr);
  // SQ_TAIL that would overflow: 7 outstanding (max) then a doorbell back to the head
  f.stall_fetch = true;
  for (int i = 0; i < 7; ++i) CHECK_EQ(sfs_submit_get_capacity(&q, uint16_t(i + 1), 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  CHECK_EQ(f.db_errors, inj);  // a doorbell with SQ_SIZE-1 outstanding entries is legal
  inject(SFS_REG_SQ_TAIL, 0);  // 8 outstanding: would overflow
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(st.irq_db_err);
  CHECK_EQ(st.sq_tail, 7);  // unchanged
  CHECK_EQ(f.db_errors, inj);
  CHECK_EQ(sfs_queue_ack_irq(&q, SFS_IRQ_DB_ERR), 0);
  // CQ_HEAD beyond CQ_TAIL (nothing completed yet)
  inject(SFS_REG_CQ_HEAD, 3);
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(st.irq_db_err);
  CHECK_EQ(st.cq_head, 0);
  CHECK_EQ(sfs_queue_ack_irq(&q, SFS_IRQ_DB_ERR), 0);
  inject(SFS_REG_CQ_HEAD, 8);  // >= CQ_SIZE
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(st.irq_db_err);
  CHECK_EQ(sfs_queue_ack_irq(&q, SFS_IRQ_DB_ERR | SFS_IRQ_QUEUE_ERR), 0);
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(!st.irq_db_err && !st.irq_queue_err);
  // after all that the queue still works and the library's own view is intact
  f.stall_fetch = false;
  f.tick();
  sfs_cqe_t c;
  std::set<unsigned> seen;
  for (int i = 0; i < 7; ++i) {
    CHECK_EQ(wait_ck(&q, &c), 0);
    CHECK(c.status == 0 && c.result0 == 1024);
    seen.insert(c.txn);
  }
  CHECK_EQ(seen.size(), 7);
  CHECK_EQ(f.db_errors, inj);  // exactly the injected ones; the library never rang a bad doorbell
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(!st.irq_db_err);
  CHECK_EQ(st.sq_head, st.sq_tail);
  CHECK_EQ(st.cq_tail, st.cq_head);
  // doorbell writes while the queue is disabled are errors too
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  inject(SFS_REG_SQ_TAIL, 1);
  q.dev = &fx.d0;
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(st.irq_db_err && !st.enabled);
  CHECK_EQ(sfs_queue_ack_irq(&q, SFS_IRQ_DB_ERR), 0);
  CHECK_EQ(f.abi_errors, 0);
}

// ---------------------------------------------------------------------------------------------
static void test_errors_and_counters() {
  section("error statuses (§4) returned and decoded; perf counters (§8)");
  Fixture fx;
  MockFabric& f = *fx.f;
  sfs_queue_t q0, q1;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q0, 16, 16), 0);
  CHECK_EQ(sfs_queue_create(&fx.d1, &q1, 16, 16), 0);
  sfs_buf_t b0, b1;
  CHECK_EQ(sfs_buf_alloc(&fx.d0, 8 * 512, &b0), 0);
  CHECK_EQ(sfs_buf_alloc(&fx.d1, 8 * 512, &b1), 0);
  fill_pat(static_cast<uint8_t*>(b0.va), b0.len, 11);
  sfs_cqe_t c;

  auto run_raw = [&](sfs_queue_t* q, const sfs_desc_t& d) {
    CHECK_EQ(sfs_submit_desc(q, &d), 0);
    CHECK_EQ(wait_ck(q, &c), 0);
  };
  auto base = [&](unsigned op, unsigned tenant) {
    sfs_desc_t d;
    std::memset(&d, 0, sizeof(d));
    d.version = 1;
    d.opcode = uint8_t(op);
    d.txn = 0x77;
    d.nsid = tenant == 0 ? 0 : 3;
    d.tenant_claim = uint16_t(tenant);
    if (op == SFS_OP_READ || op == SFS_OP_WRITE) {
      d.nblk = 1;
      d.data_len = 512;
      d.data_addr = tenant == 0 ? b0.iova : b1.iova;
    }
    return d;
  };
  auto expect = [&](unsigned st, unsigned det, const char* sname, const char* dname) {
    CHECK_EQ(c.status, st);
    CHECK_EQ(c.detail, det);
    CHECK(std::strcmp(sfs_status_str(c.status), sname) == 0);
    CHECK(std::strcmp(sfs_detail_str(c.status, c.detail), dname) == 0);
    CHECK(!c.durable && !c.crc_valid && c.nblk_done == 0);
  };

  sfs_desc_t d = base(SFS_OP_READ, 0);
  d.opcode = 0x7F;
  run_raw(&q0, d);
  expect(SFS_ST_INVALID_OPCODE, 0, "INVALID_OPCODE", "-");
  d = base(SFS_OP_READ, 0); d.version = 2;
  run_raw(&q0, d);
  expect(SFS_ST_INVALID_FIELD, SFS_DET_FIELD_VERSION, "INVALID_FIELD", "VERSION");
  d = base(SFS_OP_READ, 0); d.tenant_claim = 1;  // tenant 0's queue claiming to be tenant 1
  run_raw(&q0, d);
  expect(SFS_ST_TENANT_MISMATCH, 0, "TENANT_MISMATCH", "-");
  CHECK_EQ(c.tenant, 0);  // hardware stamped, not what the descriptor claimed
  d = base(SFS_OP_READ, 0); d.rsv1 = 1;
  run_raw(&q0, d);
  expect(SFS_ST_INVALID_FIELD, SFS_DET_FIELD_RESERVED, "INVALID_FIELD", "RESERVED");
  d = base(SFS_OP_READ, 0); d.flags = SFS_F_HCRC;
  run_raw(&q0, d);
  expect(SFS_ST_INVALID_FIELD, SFS_DET_FIELD_FLAGS, "INVALID_FIELD", "FLAGS");
  d = base(SFS_OP_READ, 0); d.data_addr = b0.iova + 2;
  run_raw(&q0, d);
  expect(SFS_ST_INVALID_FIELD, SFS_DET_FIELD_ADDR_ALIGN, "INVALID_FIELD", "ADDR_ALIGN");
  // INVALID_NS: foreign and non-existent namespaces are indistinguishable
  d = base(SFS_OP_READ, 0); d.nsid = 2;
  run_raw(&q0, d);
  expect(SFS_ST_INVALID_NS, 0, "INVALID_NS", "-");
  sfs_cqe_t foreign = c;
  d = base(SFS_OP_READ, 0); d.nsid = 7;
  run_raw(&q0, d);
  expect(SFS_ST_INVALID_NS, 0, "INVALID_NS", "-");
  CHECK(foreign.raw[1] == c.raw[1] && foreign.raw[0] == c.raw[0]);
  // LBA_RANGE via the helpers: sync wrappers return SFS_E_STATUS and still deliver the CQE
  int rc = sfs_read_sync(&q0, 0, 1024, 1, b0.iova, 0, &c);
  CHECK_EQ(rc, SFS_E_STATUS);
  expect(SFS_ST_LBA_RANGE, 0, "LBA_RANGE", "-");
  rc = sfs_read_sync(&q0, 0, 1017, 8, b0.iova, 0, &c);
  CHECK_EQ(rc, SFS_E_STATUS);
  CHECK_EQ(c.status, SFS_ST_LBA_RANGE);
  rc = sfs_read_sync(&q0, 0, 1016, 8, b0.iova, 0, &c);  // LBA+NBLK == SIZE is fine
  CHECK_EQ(rc, 0);
  d = base(SFS_OP_READ, 0); d.lba = ~0ull; d.nblk = 1;
  run_raw(&q0, d);
  CHECK_EQ(c.status, SFS_ST_LBA_RANGE);  // 2^64 overflow
  // LEN_ERROR variants
  d = base(SFS_OP_READ, 0); d.nblk = 0;
  run_raw(&q0, d);
  expect(SFS_ST_LEN_ERROR, SFS_DET_LEN_ZERO, "LEN_ERROR", "ZERO");
  d = base(SFS_OP_WRITE, 0); d.nblk = 9; d.data_len = 9 * 512;
  run_raw(&q0, d);
  expect(SFS_ST_LEN_ERROR, SFS_DET_LEN_TOO_LARGE, "LEN_ERROR", "TOO_LARGE");
  d = base(SFS_OP_READ, 0); d.data_len = 100;
  run_raw(&q0, d);
  expect(SFS_ST_LEN_ERROR, SFS_DET_LEN_MISMATCH, "LEN_ERROR", "MISMATCH");
  d = base(SFS_OP_FLUSH, 0); d.nblk = 1;
  run_raw(&q0, d);
  expect(SFS_ST_LEN_ERROR, SFS_DET_LEN_NOT_ZERO, "LEN_ERROR", "NOT_ZERO");
  // NS_READONLY
  rc = sfs_write_sync(&q0, 1, 0, 1, b0.iova, b0.va, 0, &c);
  CHECK_EQ(rc, SFS_E_STATUS);
  expect(SFS_ST_NS_READONLY, 0, "NS_READONLY", "-");
  rc = sfs_discard_sync(&q0, 1, 0, 1, &c);
  CHECK_EQ(rc, SFS_E_STATUS);
  CHECK_EQ(c.status, SFS_ST_NS_READONLY);
  // DATA_CRC: explicit wrong host CRC; nothing is written
  fill_pat(static_cast<uint8_t*>(b0.va), b0.len, 21);
  CHECK_EQ(sfs_submit_write_crc(&q0, 5, 0, 300, 2, b0.iova, SFS_FLAG_HCRC, sfs_crc32c(b0.va, 1024) ^ 1u), 0);
  CHECK_EQ(wait_ck(&q0, &c), 0);
  expect(SFS_ST_DATA_CRC, 0, "DATA_CRC", "-");
  std::memset(b0.va, 0xEE, 1024);
  CHECK_EQ(sfs_read_sync(&q0, 0, 300, 2, b0.iova, 0, &c), 0);
  bool zeros = true;
  for (int i = 0; i < 1024; ++i) zeros = zeros && static_cast<uint8_t*>(b0.va)[i] == 0;
  CHECK(zeros);
  // DMA_FAULT: unmapped IOVA / other tenant's memory / range overrun
  CHECK_EQ(sfs_read_sync(&q0, 0, 0, 1, 0xDEAD0000ull, 0, &c), SFS_E_STATUS);
  expect(SFS_ST_DMA_FAULT, SFS_DET_DMA_NO_MAP, "DMA_FAULT", "NO_MAP");
  CHECK_EQ(sfs_read_sync(&q0, 0, 0, 1, b1.iova, 0, &c), SFS_E_STATUS);
  expect(SFS_ST_DMA_FAULT, SFS_DET_DMA_DOMAIN, "DMA_FAULT", "DOMAIN");
  CHECK_EQ(sfs_read_sync(&q0, 0, 0, 2, b0.iova + 8 * 512 - 512, 0, &c), SFS_E_STATUS);
  expect(SFS_ST_DMA_FAULT, SFS_DET_DMA_RANGE, "DMA_FAULT", "RANGE");

  // tenant 1: isolation + encryption key readiness
  CHECK_EQ(sfs_read_sync(&q1, 0, 0, 1, b1.iova, 0, &c), SFS_E_STATUS);  // tenant 0's namespace
  CHECK_EQ(c.status, SFS_ST_INVALID_NS);
  CHECK_EQ(c.tenant, 1);
  CHECK_EQ(sfs_read_sync(&q1, 2, 0, 1, b1.iova, 0, &c), SFS_E_STATUS);  // enc ns, no key yet
  expect(SFS_ST_CRYPTO_ERROR, SFS_DET_CRYPTO_KEY_NOT_READY, "CRYPTO_ERROR", "KEY_NOT_READY");
  uint8_t key[64];
  fill_pat(key, 64, 77);
  CHECK_EQ(sfs_mgmt_key_load(&fx.mg, 3, key), 0);
  CHECK_EQ(std::memcmp(f.keys[3], key, 64), 0);  // little-endian word order on the key window
  CHECK_EQ(sfs_write_sync(&q1, 2, 5, 1, b1.iova, b1.va, 0, &c), 0);
  CHECK(c.encrypted && !c.pi_verified);
  CHECK_EQ(sfs_read_sync(&q1, 2, 5, 1, b1.iova, 0, &c), 0);
  CHECK(c.encrypted && !c.pi_verified);
  CHECK_EQ(sfs_mgmt_key_zeroize(&fx.mg, 3), 0);
  CHECK_EQ(sfs_read_sync(&q1, 2, 0, 1, b1.iova, 0, &c), SFS_E_STATUS);
  CHECK_EQ(c.status, SFS_ST_CRYPTO_ERROR);
  // tenant 1 cannot claim tenant 0's id either
  d = base(SFS_OP_GET_CAPACITY, 1); d.tenant_claim = 0;
  run_raw(&q1, d);
  CHECK_EQ(c.status, SFS_ST_TENANT_MISMATCH);

  // perf counters: compare with the model's expectations for tenant 0 minus the DMA faults the model never saw
  sfs_perf_t p;
  CHECK_EQ(sfs_perf_read(&fx.d0, &p), 0);
  const MockFabric::Counters& mc = f.counters(0);
  CHECK_EQ(p.done, mc.done);
  CHECK_EQ(p.err, mc.err);
  CHECK_EQ(p.rd_blk, mc.rd_blk);
  CHECK_EQ(p.wr_blk, mc.wr_blk);
  CHECK_EQ(p.flush, mc.flush);
  CHECK_EQ(p.viol, mc.viol);
  CHECK_EQ(p.bytes_lo, mc.bytes);
  CHECK_EQ(p.throttle, 0);
  CHECK_EQ(p.inflight, 0);
  // exact accounting, counted by hand from the commands above: 23 commands, 2 successes (8-block read at 1016,
  // 2-block read at 300), violations = TENANT_MISMATCH + 2x INVALID_NS + 3x DMA_FAULT
  CHECK_EQ(p.done, 23);
  CHECK_EQ(p.err, 21);
  CHECK_EQ(p.viol, 6);
  CHECK_EQ(p.rd_blk, 10);
  CHECK_EQ(p.wr_blk, 0);
  CHECK_EQ(p.flush, 0);
  CHECK_EQ(p.bytes_lo, 10 * 512);
  // model counters agree for everything the model saw (all but the three DMA faults)
  const sfref::Model::Counters& mm = f.model.counters(0);
  CHECK_EQ(mm.done + 3, p.done);
  CHECK_EQ(mm.err + 3, p.err);
  CHECK_EQ(mm.viol + 3, p.viol);
  CHECK_EQ(mm.rd_blk, p.rd_blk);
  // tenant 1 counters are separate
  CHECK_EQ(sfs_perf_read(&fx.d1, &p), 0);
  CHECK_EQ(p.done, f.counters(1).done);
  CHECK(p.done == 6 && p.err == 4 && p.viol == 2 && p.rd_blk == 1 && p.wr_blk == 1);
  // global CLR_COUNTERS (W1S) clears them
  CHECK_EQ(sfs_mgmt_clear_counters(&fx.mg), 0);
  CHECK_EQ(f.clr_counters, 1);
  CHECK_EQ(sfs_perf_read(&fx.d0, &p), 0);
  CHECK(p.done == 0 && p.err == 0 && p.viol == 0 && p.bytes_lo == 0);
  CHECK_EQ(f.gctrl() & SFS_GCTRL_CLR_COUNTERS, 0);  // never re-written by later GCTRL accesses
  CHECK_EQ(f.abi_errors, 0);
  CHECK_EQ(f.bus_errors, 0);

  sfs_buf_free(&fx.d0, &b0);
  sfs_buf_free(&fx.d1, &b1);
  CHECK_EQ(sfs_queue_destroy(&q0), 0);
  CHECK_EQ(sfs_queue_destroy(&q1), 0);
}

// ---------------------------------------------------------------------------------------------
static void test_ooo_and_latency() {
  section("out-of-order completion matched by TXN_ID, ordering of overlapping commands, latency accounting");
  Fixture fx;
  MockFabric& f = *fx.f;
  f.delay = 3;
  f.ooo = true;
  sfs_queue_t q;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 32, 32), 0);
  sfs_buf_t b[8];
  for (auto& x : b) CHECK_EQ(sfs_buf_alloc(&fx.d0, 512, &x), 0);
  sfs_cqe_t c;
  // independent writes: complete in reverse order
  for (int i = 0; i < 6; ++i) {
    fill_pat(static_cast<uint8_t*>(b[i].va), 512, 300 + i);
    CHECK_EQ(sfs_submit_write(&q, uint16_t(i + 1), 0, uint64_t(100 + i), 1, b[i].iova, b[i].va, 0), 0);
  }
  CHECK_EQ(sfs_ring(&q), 0);
  sfs_perf_t p;
  CHECK_EQ(sfs_perf_read(&fx.d0, &p), 0);
  CHECK_EQ(p.inflight, 6);  // all six are owned by the fabric
  std::vector<unsigned> order;
  std::vector<uint32_t> lats;
  for (int i = 0; i < 6; ++i) {
    CHECK_EQ(wait_ck(&q, &c), 0);
    order.push_back(c.txn);
    lats.push_back(c.latency);
    CHECK(c.status == 0 && c.nblk_done == 1);
  }
  std::set<unsigned> s(order.begin(), order.end());
  CHECK_EQ(s.size(), 6);
  CHECK(order[0] != 1);  // genuinely out of submission order
  CHECK_EQ(order[0], 6);
  // the CQE.latency field is carried through and accounted
  CHECK_EQ(q.lat.count, 6);
  uint64_t sum = 0;
  uint32_t mx = 0;
  for (uint32_t l : lats) { sum += l; if (l > mx) mx = l; }
  CHECK_EQ(q.lat.sum, sum);
  CHECK_EQ(q.lat.max, mx);
  CHECK_EQ(sfs_queue_latency(&q)->count, 6);
  CHECK_EQ(sfs_lat_mean(sfs_queue_latency(&q)), sum / 6);
  CHECK_EQ(lats[0], 20 + 4 + 50 * 3);  // mock latency formula (nblk 1, delay 3)
  uint32_t pv = 0;
  CHECK_EQ(sfs_percentile(lats.data(), lats.size(), 5000, &pv), 0);
  CHECK_EQ(pv, 20 + 4 + 50 * 3);
  // overlapping write then read of the same block: serialised in submission order, so the read must see the data
  fill_pat(static_cast<uint8_t*>(b[0].va), 512, 999);
  std::memset(b[1].va, 0, 512);
  CHECK_EQ(sfs_submit_write(&q, 20, 0, 200, 1, b[0].iova, b[0].va, 0), 0);
  CHECK_EQ(sfs_submit_read(&q, 21, 0, 200, 1, b[1].iova, 0), 0);
  CHECK_EQ(sfs_submit_flush(&q, 22, 0), 0);
  CHECK_EQ(sfs_submit_get_capacity(&q, 23, 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  std::vector<unsigned> o2;
  for (int i = 0; i < 4; ++i) {
    CHECK_EQ(wait_ck(&q, &c), 0);
    o2.push_back(c.txn);
  }
  size_t pw = 0, pr = 0, pf = 0;
  for (size_t i = 0; i < o2.size(); ++i) {
    if (o2[i] == 20) pw = i;
    if (o2[i] == 21) pr = i;
    if (o2[i] == 22) pf = i;
  }
  CHECK(pw < pr);  // write completed before the overlapping read
  CHECK(pr < pf);  // FLUSH completes after every earlier command
  CHECK_EQ(std::memcmp(b[1].va, b[0].va, 512), 0);
  // a quirk of the mock only: everything above was submitted at delay 3
  f.delay = 0;
  f.ooo = false;
  CHECK_EQ(f.model.violations().size(), 0);
  CHECK_EQ(f.abi_errors, 0);
  for (auto& x : b) sfs_buf_free(&fx.d0, &x);
  CHECK_EQ(sfs_queue_destroy(&q), 0);
}

// ---------------------------------------------------------------------------------------------
static void test_fatal_and_reset() {
  section("queue FATAL (descriptor fetch failure): status decode, sfs_queue_reset recovery");
  Fixture fx;
  MockFabric& f = *fx.f;
  sfs_queue_t q;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), 0);
  sfs_cqe_t c;
  CHECK_EQ(sfs_capacity_sync(&q, 0, nullptr, &c), 0);
  f.fail_next_fetch = true;
  CHECK_EQ(sfs_submit_get_capacity(&q, 5, 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  CHECK_EQ(wait_ck(&q, &c), 0);  // §3: TXN_ID 0xFFFF when the descriptor could not be read
  CHECK_EQ(c.txn, SFS_CQE_TXN_NO_DESC);
  CHECK_EQ(c.status, SFS_ST_DMA_ERROR);
  CHECK_EQ(c.detail, 3);
  sfs_qstatus_t st;
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(st.fatal && st.sq_err && !st.cq_err && st.irq_queue_err && st.last_err == 3);
  char txt[160];
  sfs_qstatus_str(&st, txt, sizeof(txt));
  CHECK(std::strstr(txt, "FATAL") && std::strstr(txt, "SQ_ERR") && std::strstr(txt, "last_err=0x03") && std::strstr(txt, "IRQ_QUEUE_ERR"));
  char tiny[8];
  sfs_qstatus_str(&st, tiny, sizeof(tiny));
  CHECK_EQ(std::strlen(tiny), 7);  // truncated, still NUL terminated
  sfs_qstatus_str(&st, nullptr, 0);
  // the halted queue does not process further commands
  CHECK_EQ(sfs_submit_get_capacity(&q, 6, 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  CHECK_EQ(sfs_wait(&q, &c, 20), SFS_E_TIMEOUT);
  // RESET recovers it; library state restarts consistently
  CHECK_EQ(sfs_queue_reset(&q), 0);
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(st.enabled && !st.fatal && !st.sq_err);
  CHECK_EQ(sfs_queue_ack_irq(&q, SFS_IRQ_QUEUE_ERR), 0);
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(!st.irq_queue_err);
  uint64_t cap = 0;
  CHECK_EQ(sfs_capacity_sync(&q, 0, &cap, &c), 0);
  CHECK_EQ(cap, 1024);
  CHECK_EQ(sfs_inflight(&q), 0);

  // hypervisor SOFT_RESET disables the queue; the library notices through STATUS and can reset/re-enable
  CHECK_EQ(sfs_mgmt_soft_reset(&fx.mg), 0);
  CHECK_EQ(f.soft_resets, 1);
  CHECK_EQ(sfs_queue_status(&q, &st), 0);
  CHECK(!st.enabled);
  CHECK_EQ(f.gctrl() & SFS_GCTRL_SOFT_RESET, 0);
  CHECK_EQ(sfs_queue_reset(&q), 0);
  CHECK_EQ(sfs_capacity_sync(&q, 0, &cap, &c), 0);
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  CHECK_EQ(f.live_allocs(), 0);
}

// ---------------------------------------------------------------------------------------------
static void test_tenant_isolation() {
  section("two tenants on one fabric");
  Fixture fx;
  MockFabric& f = *fx.f;
  sfs_queue_t q0, q1;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q0, 8, 8), 0);
  CHECK_EQ(sfs_queue_create(&fx.d1, &q1, 8, 8), 0);
  sfs_buf_t b0, b1;
  CHECK_EQ(sfs_buf_alloc(&fx.d0, 512, &b0), 0);
  CHECK_EQ(sfs_buf_alloc(&fx.d1, 512, &b1), 0);
  sfs_cqe_t c;
  std::memset(b0.va, 0xA1, 512);
  std::memset(b1.va, 0xB2, 512);
  // both write "their" block 0; each reads back its own data
  CHECK_EQ(sfs_write_sync(&q0, 0, 0, 1, b0.iova, b0.va, 0, &c), 0);
  CHECK_EQ(sfs_write_sync(&q1, 3, 0, 1, b1.iova, b1.va, 0, &c), 0);
  std::memset(b0.va, 0, 512);
  std::memset(b1.va, 0, 512);
  CHECK_EQ(sfs_read_sync(&q0, 0, 0, 1, b0.iova, 0, &c), 0);
  CHECK_EQ(sfs_read_sync(&q1, 3, 0, 1, b1.iova, 0, &c), 0);
  CHECK(static_cast<uint8_t*>(b0.va)[0] == 0xA1 && static_cast<uint8_t*>(b0.va)[511] == 0xA1);
  CHECK(static_cast<uint8_t*>(b1.va)[0] == 0xB2);
  // interleaved submission on both queues, completions land on the right queue with the right TENANT
  for (int i = 0; i < 4; ++i) {
    CHECK_EQ(sfs_submit_get_capacity(&q0, uint16_t(i), 0), 0);
    CHECK_EQ(sfs_submit_get_capacity(&q1, uint16_t(100 + i), 3), 0);
  }
  CHECK_EQ(sfs_ring(&q0), 0);
  CHECK_EQ(sfs_ring(&q1), 0);
  for (int i = 0; i < 4; ++i) {
    CHECK_EQ(wait_ck(&q0, &c), 0);
    CHECK(c.tenant == 0 && c.txn < 100 && c.result0 == 1024);
    CHECK_EQ(wait_ck(&q1, &c), 0);
    CHECK(c.tenant == 1 && c.txn >= 100 && c.result0 == 256);
  }
  // owned-NSID masks follow the table
  CHECK_EQ(sfs_mgmt_ns_invalidate(&fx.mg, 3), 0);
  CHECK_EQ(sfs_dev_refresh_caps(&fx.d1), 0);
  CHECK_EQ(sfs_dev_caps(&fx.d1)->ns_mask, 0x4);
  CHECK_EQ(sfs_read_sync(&q1, 3, 0, 1, b1.iova, 0, &c), SFS_E_STATUS);
  CHECK_EQ(c.status, SFS_ST_INVALID_NS);
  CHECK_EQ(f.abi_errors, 0);
  sfs_buf_free(&fx.d0, &b0);
  sfs_buf_free(&fx.d1, &b1);
  CHECK_EQ(sfs_queue_destroy(&q0), 0);
  CHECK_EQ(sfs_queue_destroy(&q1), 0);
}

// ---------------------------------------------------------------------------------------------
static void test_mgmt() {
  section("management window helpers (§9)");
  Fixture fx(MockFabric::Cfg(), false);
  MockFabric& f = *fx.f;
  sfs_mgmt_t& mg = fx.mg;
  CHECK_EQ(sfs_mgmt_open(&mg, &fx.mtp), 0);
  CHECK(mg.caps.nt == 2 && mg.caps.nslot == 8 && mg.caps.ns_n == 8 && mg.caps.mdts_blocks == 8);
  CHECK(mg.caps.sq_max == 64 && mg.caps.cq_max == 64 && mg.caps.xts && !mg.caps.virtio && mg.caps.backend_type == SFS_BE_STORE);
  // argument / state checks
  sfs_mgmt_t none;
  std::memset(&none, 0, sizeof(none));
  CHECK_EQ(sfs_mgmt_enable_fabric(&none, 1), SFS_E_STATE);
  CHECK_EQ(sfs_mgmt_open(nullptr, &fx.mtp), SFS_E_INVAL);
  CHECK_EQ(sfs_mgmt_open(&none, nullptr), SFS_E_INVAL);
  // a tenant page is not a management window
  {
    sfs_mgmt_transport_t wrong = fx.mtp;
    wrong.mmio_read32 = [](void*, uint32_t) -> uint32_t { return SFS_ID_MAGIC; };
    CHECK_EQ(sfs_mgmt_open(&none, &wrong), SFS_E_NO_DEVICE);
  }
  // GCTRL: ENABLE shadowing, W1S bits not re-written
  CHECK_EQ(f.gctrl(), 0);
  CHECK_EQ(sfs_mgmt_set_gctrl(&mg, SFS_GCTRL_ENABLE | SFS_GCTRL_TRACE_EN | SFS_GCTRL_RD_PRIO | SFS_GCTRL_WR_BATCH), 0);
  CHECK_EQ(f.gctrl(), SFS_GCTRL_ENABLE | SFS_GCTRL_TRACE_EN | SFS_GCTRL_RD_PRIO | SFS_GCTRL_WR_BATCH);
  CHECK_EQ(sfs_mgmt_enable_fabric(&mg, 0), 0);
  CHECK_EQ(f.gctrl(), SFS_GCTRL_TRACE_EN | SFS_GCTRL_RD_PRIO | SFS_GCTRL_WR_BATCH);
  CHECK(!f.fabric_enable);
  CHECK_EQ(sfs_mgmt_enable_fabric(&mg, 1), 0);
  CHECK(f.fabric_enable);
  CHECK_EQ(sfs_mgmt_set_gctrl(&mg, SFS_GCTRL_SOFT_RESET), SFS_E_INVAL);  // W1S bits are not settable state
  CHECK_EQ(sfs_mgmt_set_gctrl(&mg, SFS_GCTRL_ENABLE | SFS_GCTRL_TRACE_EN), 0);
  CHECK_EQ(f.gctrl(), SFS_GCTRL_ENABLE | SFS_GCTRL_TRACE_EN);
  // gstatus
  sfs_gstatus_t gs;
  CHECK_EQ(sfs_mgmt_gstatus(&mg, &gs), 0);
  CHECK(gs.backend_ready && !gs.pf_quiesce && !gs.fatal && gs.busy_slots == 0);
  // timeouts and scheduler
  CHECK_EQ(sfs_mgmt_set_cmd_timeout(&mg, 123456), 0);
  CHECK_EQ(f.cmd_timeout(), 123456);
  CHECK_EQ(sfs_mgmt_set_sched(&mg, 4, 8), 0);
  CHECK_EQ(f.sched_cfg(), 4u | (8u << 8));
  CHECK_EQ(sfs_mgmt_set_sched(&mg, 256, 8), SFS_E_INVAL);
  CHECK_EQ(sfs_mgmt_force_power_fail(&mg, 1), 0);
  CHECK_EQ(f.pf_ctrl(), 1);
  CHECK_EQ(sfs_mgmt_force_power_fail(&mg, 0), 0);
  CHECK_EQ(f.pf_ctrl(), 0);
  // tenant config
  sfs_tcfg_t tc;
  tc.enable_allowed = 1; tc.max_inflight = 6; tc.weight = 200; tc.rate = 4096; tc.burst = 64;
  CHECK_EQ(sfs_mgmt_tenant_cfg(&mg, 1, &tc), 0);
  CHECK(f.tcfg(1)[0] == 1 && f.tcfg(1)[1] == 6 && f.tcfg(1)[2] == 200 && f.tcfg(1)[3] == 4096 && f.tcfg(1)[4] == 64);
  CHECK_EQ(sfs_mgmt_tenant_cfg(&mg, 2, &tc), SFS_E_INVAL);  // NT = 2
  tc.weight = 256;
  CHECK_EQ(sfs_mgmt_tenant_cfg(&mg, 1, &tc), SFS_E_INVAL);
  CHECK_EQ(sfs_mgmt_tenant_cfg(&mg, 1, nullptr), SFS_E_INVAL);
  CHECK_EQ(sfs_mgmt_tenant_allow(&mg, 0, 1), 0);
  CHECK_EQ(f.tcfg(0)[0], 1);
  CHECK_EQ(sfs_mgmt_tenant_allow(&mg, 5, 1), SFS_E_INVAL);

  // namespaces: accepted and each refusal reason
  sfs_ns_cfg_t n;
  uint32_t nss = 0xFFFF;
  std::memset(&n, 0, sizeof(n));
  n.owner = 1; n.base = 100; n.size = 50; n.readonly = 1; n.enc = 1; n.key_slot = 9;
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 6, &n, &nss), 0);
  CHECK_EQ(nss, SFS_NSS_ACCEPTED);
  CHECK(f.model.ns_valid(6));
  const sfref::NsCfg& mn = f.model.ns_cfg(6);
  CHECK(mn.owner == 1 && mn.base == 100 && mn.size == 50 && mn.readonly && mn.enc && !mn.pi && mn.key_slot == 9);
  n.base = (1ull << 20) - 10; n.size = 100;  // past the backend capacity
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 7, &n, &nss), SFS_E_REFUSED);
  CHECK_EQ(nss, SFS_NSS_NO_CAPACITY);
  CHECK(!f.model.ns_valid(7));
  n.base = (1ull << 20) - 100;  // exactly fits
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 7, &n, &nss), 0);
  n.base = 0; n.owner = 5;  // owner >= NT
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 5, &n, &nss), SFS_E_REFUSED);
  CHECK_EQ(nss, SFS_NSS_BAD_OWNER_SIZE);
  n.owner = 0; n.size = 0;  // zero size
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 5, &n, &nss), SFS_E_REFUSED);
  CHECK_EQ(nss, SFS_NSS_BAD_OWNER_SIZE);
  n.size = 10; n.base = (1ull << 33) + 5;  // 64-bit BASE across both words, beyond capacity
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 5, &n, &nss), SFS_E_REFUSED);
  CHECK_EQ(nss, SFS_NSS_NO_CAPACITY);
  n.owner = 16;
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 5, &n, &nss), SFS_E_INVAL);  // owner does not fit NS_CTRL[7:4]
  n.owner = 0; n.key_slot = 16;
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 5, &n, &nss), SFS_E_INVAL);
  n.key_slot = 0;
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 8, &n, &nss), SFS_E_INVAL);  // NSID >= NS_N
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 5, nullptr, &nss), SFS_E_INVAL);
  // re-configuring a valid namespace goes through VALID=0 first
  n.base = 7; n.size = 3; n.readonly = 0; n.enc = 0;
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 6, &n, &nss), 0);
  CHECK(f.model.ns_cfg(6).base == 7 && f.model.ns_cfg(6).size == 3 && !f.model.ns_cfg(6).readonly);
  CHECK_EQ(sfs_mgmt_ns_invalidate(&mg, 6), 0);
  CHECK(!f.model.ns_valid(6));
  CHECK_EQ(sfs_mgmt_ns_invalidate(&mg, 8), SFS_E_INVAL);

  // DMA windows: NT..15 only; device may reject a window
  sfs_dma_window_t w;
  w.domain = 3; w.base = 0x100000000ull; w.size = 0x20000; w.perm_r = 1; w.perm_w = 0;
  CHECK_EQ(sfs_mgmt_dma_window(&mg, 2, &w), 0);
  CHECK(f.pt[2].valid && f.pt[2].dom == 3 && f.pt[2].base == 0x100000000ull && f.pt[2].size == 0x20000 && f.pt[2].perm == SFS_PT_PERM_R);
  w.perm_w = 1;
  CHECK_EQ(sfs_mgmt_dma_window(&mg, 15, &w), 0);
  CHECK_EQ(f.pt[15].perm, SFS_PT_PERM_R | SFS_PT_PERM_W);
  CHECK_EQ(sfs_mgmt_dma_window(&mg, 0, &w), SFS_E_INVAL);   // fabric-local windows
  CHECK_EQ(sfs_mgmt_dma_window(&mg, 1, &w), SFS_E_INVAL);
  CHECK_EQ(sfs_mgmt_dma_window(&mg, 16, &w), SFS_E_INVAL);
  w.size = 0;
  CHECK_EQ(sfs_mgmt_dma_window(&mg, 3, &w), SFS_E_REFUSED);  // PT_STATUS.rejected
  CHECK(!f.pt[3].valid);
  CHECK_EQ(sfs_mgmt_dma_window_clear(&mg, 2), 0);
  CHECK(!f.pt[2].valid);
  CHECK_EQ(sfs_mgmt_dma_window_clear(&mg, 0), SFS_E_INVAL);

  // backend info / reset, keys
  sfs_be_info_t bi;
  CHECK_EQ(sfs_mgmt_backend_info(&mg, &bi), 0);
  CHECK(bi.type == 1 && bi.capacity_blocks == (1u << 20));
  CHECK_EQ(bi.caps, SFS_BECAP_PI_NATIVE | SFS_BECAP_VOLATILE_CACHE | SFS_BECAP_DISCARD | SFS_BECAP_DISCARD_ZERO);
  CHECK_EQ(sfs_mgmt_backend_reset(&mg), 0);
  CHECK_EQ(f.be_resets, 1);
  uint8_t key[64];
  for (int i = 0; i < 64; ++i) key[i] = uint8_t(i + 1);
  CHECK_EQ(sfs_mgmt_key_load(&mg, 5, key), 0);
  CHECK_EQ(std::memcmp(f.keys[5], key, 64), 0);
  CHECK(f.model.key_ready(5));
  CHECK_EQ(sfs_mgmt_key_zeroize(&mg, 5), 0);
  CHECK(!f.model.key_ready(5));
  CHECK_EQ(sfs_mgmt_key_load(&mg, 16, key), SFS_E_INVAL);
  CHECK_EQ(sfs_mgmt_key_load(&mg, 1, nullptr), SFS_E_INVAL);

  // performance counters: LO read latches HI (value keeps running underneath)
  uint64_t v = 0;
  f.perf_live = 0xFFFFFFFFu;
  f.perf_hi_live = 0;
  CHECK_EQ(sfs_mgmt_perf_read(&mg, 7, &v), 0);
  CHECK_EQ(v, 0x00000000FFFFFFFFull);  // reading HI before LO (or without latching) would give 0x1_FFFF_FFFF or garbage
  f.perf_live = 0x10;
  f.perf_hi_live = 0xABCDEF01u;
  CHECK_EQ(sfs_mgmt_perf_read(&mg, 9, &v), 0);
  CHECK_EQ(v, (0xABCDEF01ull << 32) | 0x10);
  CHECK_EQ(sfs_mgmt_perf_read(&mg, 9, nullptr), SFS_E_INVAL);

  // trace FIFO: records appear for completed commands when TRACE_EN is set
  CHECK_EQ(sfs_mgmt_set_gctrl(&mg, SFS_GCTRL_ENABLE | SFS_GCTRL_TRACE_EN), 0);
  CHECK_EQ(sfs_mgmt_tenant_allow(&mg, 0, 1), 0);
  sfs_ns_cfg_t n0;
  std::memset(&n0, 0, sizeof(n0));
  n0.owner = 0; n0.base = 0; n0.size = 1024;
  CHECK_EQ(sfs_mgmt_ns_config(&mg, 0, &n0, nullptr), 0);
  CHECK_EQ(sfs_dev_open(&fx.d0, &fx.tp0, 0), 0);
  sfs_queue_t q;
  CHECK_EQ(sfs_queue_create(&fx.d0, &q, 8, 8), 0);
  sfs_buf_t b;
  CHECK_EQ(sfs_buf_alloc(&fx.d0, 4096, &b), 0);
  sfs_cqe_t c;
  uint32_t ent = 99, drop = 99;
  CHECK_EQ(sfs_mgmt_trace_status(&mg, &ent, &drop), 0);
  CHECK(ent == 0 && drop == 0);
  sfs_trace_rec_t tr;
  CHECK_EQ(sfs_mgmt_trace_pop(&mg, &tr), 0);  // empty
  CHECK_EQ(sfs_write_sync(&q, 0, 0, 4, b.iova, b.va, SFS_FLAG_FUA, &c), 0);
  CHECK_EQ(sfs_read_sync(&q, 0, 0, 2, b.iova, 0, &c), 0);
  CHECK_EQ(sfs_read_sync(&q, 0, 5000, 1, b.iova, 0, &c), SFS_E_STATUS);
  CHECK_EQ(sfs_mgmt_trace_status(&mg, &ent, &drop), 0);
  CHECK(ent == 3 && drop == 0);
  CHECK_EQ(sfs_mgmt_trace_pop(&mg, &tr), 1);
  CHECK(tr.txn == 1 && tr.tenant == 0 && tr.opcode == SFS_OP_WRITE && tr.status == 0 && tr.detail == 0 && tr.nblk == 4);
  CHECK(tr.durable == 1 && tr.bytes == 2048);
  CHECK_EQ(sfs_trace_queue_wait(&tr), 3);  // W3 - W2
  CHECK(tr.cyc_post >= tr.cyc_be_done && tr.cyc_be_done >= tr.cyc_issue);
  CHECK_EQ(sfs_mgmt_trace_pop(&mg, &tr), 1);
  CHECK(tr.opcode == SFS_OP_READ && tr.nblk == 2 && tr.bytes == 1024 && tr.durable == 0);
  CHECK_EQ(sfs_mgmt_trace_pop(&mg, &tr), 1);
  CHECK(tr.opcode == SFS_OP_READ && tr.status == SFS_ST_LBA_RANGE && tr.nblk == 0 && tr.bytes == 0);
  CHECK_EQ(sfs_mgmt_trace_pop(&mg, &tr), 0);
  // overflow is counted as dropped
  for (int i = 0; i < 20; ++i) CHECK_EQ(sfs_capacity_sync(&q, 0, nullptr, &c), 0);
  CHECK_EQ(sfs_mgmt_trace_status(&mg, &ent, &drop), 0);
  CHECK(ent == 16 && drop == 4);
  CHECK_EQ(sfs_mgmt_trace_status(&mg, nullptr, nullptr), 0);
  // GSTATUS busy slots while commands are held in the fabric
  f.delay = 20;
  CHECK_EQ(sfs_submit_get_capacity(&q, 1, 0), 0);
  CHECK_EQ(sfs_submit_get_capacity(&q, 2, 0), 0);
  CHECK_EQ(sfs_ring(&q), 0);
  CHECK_EQ(sfs_mgmt_gstatus(&mg, &gs), 0);
  CHECK_EQ(gs.busy_slots, 2);
  f.delay = 0;
  CHECK_EQ(sfs_wait(&q, &c, 1000), 0);
  CHECK_EQ(sfs_wait(&q, &c, 1000), 0);
  sfs_buf_free(&fx.d0, &b);
  CHECK_EQ(sfs_queue_destroy(&q), 0);
  CHECK_EQ(f.abi_errors, 0);
  CHECK_EQ(f.bus_errors, 0);
}

// ---------------------------------------------------------------------------------------------
static void test_alloc_api() {
  section("buffer helper");
  Fixture fx;
  sfs_buf_t b;
  CHECK_EQ(sfs_buf_alloc(&fx.d0, 0, &b), SFS_E_INVAL);
  CHECK_EQ(sfs_buf_alloc(&fx.d0, 100, nullptr), SFS_E_INVAL);
  CHECK_EQ(sfs_buf_alloc(nullptr, 100, &b), SFS_E_INVAL);
  fx.f->fail_alloc_after = 0;
  CHECK_EQ(sfs_buf_alloc(&fx.d0, 100, &b), SFS_E_NOMEM);
  fx.f->misalign_alloc = true;  // iova+4 is still 4-byte aligned, which is all a data buffer needs
  CHECK_EQ(sfs_buf_alloc(&fx.d0, 100, &b), 0);
  CHECK_EQ(b.iova % 4, 0);
  CHECK_EQ(b.len, 100);
  sfs_buf_free(&fx.d0, &b);
  CHECK(b.va == nullptr && b.len == 0);
  fx.f->misalign_alloc = false;
  sfs_buf_free(&fx.d0, &b);  // double free is a no-op
  CHECK_EQ(fx.f->live_allocs(), 0);
  CHECK_EQ(fx.f->abi_errors, 0);
}

int main() {
  test_helpers();
  test_open_caps();
  test_queue_lifecycle();
  test_basic_io();
  test_desc_layout();
  test_wrap_and_full();
  test_poll_semantics();
  test_phase_read_first();
  test_partial_fetch();
  test_doorbell_errors();
  test_errors_and_counters();
  test_ooo_and_latency();
  test_fatal_and_reset();
  test_tenant_isolation();
  test_mgmt();
  test_alloc_api();
  std::printf("libsfstor test: %d PASS, %d FAIL\n", g_pass, g_fail);
  std::printf(g_fail ? "RESULT: FAIL\n" : "RESULT: PASS\n");
  return g_fail ? 1 : 0;
}
