/*
 * sfstor_regs.h - register offsets, field masks and code enums of the SilicaFlux StorageFabric host
 * interface (ABI v1.0).  Written from docs/02_HOST_INTERFACE.md only; section numbers refer to it.
 *
 * Items marked "(assumed)" are not pinned down by the spec text (see model/SPEC_QUESTIONS.md).
 * All offsets are byte offsets.  Tenant-page offsets are relative to the tenant's own 4 KiB page,
 * management offsets relative to the management window.
 */
#ifndef SFSTOR_REGS_H
#define SFSTOR_REGS_H

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------------------------------ */
/* §8 tenant MMIO page                                                                         */
/* ------------------------------------------------------------------------------------------ */
#define SFS_ID_MAGIC          0x53465354u /* "SFST" */
#define SFS_ABI_VERSION       0x00010000u /* major in [31:16], minor in [15:0] */

#define SFS_REG_ID            0x000u
#define SFS_REG_VERSION       0x004u
#define SFS_REG_CAPS0         0x008u
#define SFS_REG_CAPS1         0x00Cu
#define SFS_REG_CTRL          0x010u
#define SFS_REG_STATUS        0x014u
#define SFS_REG_SQ_BASE_LO    0x020u
#define SFS_REG_SQ_BASE_HI    0x024u
#define SFS_REG_SQ_SIZE       0x028u
#define SFS_REG_CQ_BASE_LO    0x030u
#define SFS_REG_CQ_BASE_HI    0x034u
#define SFS_REG_CQ_SIZE       0x038u
#define SFS_REG_SQ_TAIL       0x040u
#define SFS_REG_CQ_HEAD       0x044u
#define SFS_REG_SQ_HEAD       0x048u
#define SFS_REG_CQ_TAIL       0x04Cu
#define SFS_REG_IRQ_EN        0x050u
#define SFS_REG_IRQ_STATUS    0x054u
#define SFS_REG_INFLIGHT      0x060u
#define SFS_REG_CNT_DONE      0x080u
#define SFS_REG_CNT_ERR       0x084u
#define SFS_REG_CNT_RD_BLK    0x088u
#define SFS_REG_CNT_WR_BLK    0x08Cu
#define SFS_REG_CNT_FLUSH     0x090u
#define SFS_REG_CNT_THROTTLE  0x094u
#define SFS_REG_CNT_VIOL      0x098u
#define SFS_REG_CNT_BYTES_LO  0x09Cu
#define SFS_PAGE_BYTES        0x1000u

/* CAPS0 */
#define SFS_CAPS0_MDTS_SHIFT        0
#define SFS_CAPS0_MDTS_MASK         0xFFu
#define SFS_CAPS0_SQ_MAX_SHIFT      8
#define SFS_CAPS0_SQ_MAX_MASK       0xFFu
#define SFS_CAPS0_CQ_MAX_SHIFT      16
#define SFS_CAPS0_CQ_MAX_MASK       0xFFu
#define SFS_CAPS0_BLK_SHIFT_SHIFT   24
#define SFS_CAPS0_BLK_SHIFT_MASK    0xFFu

/* CAPS1 */
#define SFS_CAPS1_DISCARD           (1u << 0)
#define SFS_CAPS1_PI                (1u << 1)
#define SFS_CAPS1_ENC               (1u << 2)
#define SFS_CAPS1_FUA               (1u << 3)
#define SFS_CAPS1_HCRC              (1u << 4)
#define SFS_CAPS1_VOLATILE_CACHE    (1u << 5)
#define SFS_CAPS1_BACKEND_READY     (1u << 8)
#define SFS_CAPS1_BE_TYPE_SHIFT     12
#define SFS_CAPS1_BE_TYPE_MASK      0xFu
#define SFS_CAPS1_NS_MASK_SHIFT     16
#define SFS_CAPS1_NS_MASK_MASK      0xFFFFu

/* BACKEND_TYPE values (CAPS1[15:12], GCAPS1[27:24]) */
#define SFS_BE_SIMDEV   0u
#define SFS_BE_STORE    1u
#define SFS_BE_HOST_SW  2u
#define SFS_BE_NVME     3u

/* CTRL */
#define SFS_CTRL_ENABLE            (1u << 0)
#define SFS_CTRL_RESET             (1u << 1) /* W1S, self-clearing */

/* STATUS */
#define SFS_STATUS_ENABLED         (1u << 0)
#define SFS_STATUS_SQ_ERR          (1u << 1)
#define SFS_STATUS_CQ_ERR          (1u << 2)
#define SFS_STATUS_FATAL           (1u << 3)
#define SFS_STATUS_SQ_EMPTY        (1u << 4)
#define SFS_STATUS_IDLE            (1u << 5)
#define SFS_STATUS_LAST_ERR_SHIFT  8
#define SFS_STATUS_LAST_ERR_MASK   0xFFu

/* IRQ_EN / IRQ_STATUS (IRQ_STATUS is RW1C except bit 0, which is a level) */
#define SFS_IRQ_CQ_NONEMPTY        (1u << 0)
#define SFS_IRQ_QUEUE_ERR          (1u << 1)
#define SFS_IRQ_DB_ERR             (1u << 2) /* IRQ_STATUS only */
#define SFS_IRQ_STATUS_W1C_MASK    (SFS_IRQ_QUEUE_ERR | SFS_IRQ_DB_ERR)

/* ------------------------------------------------------------------------------------------ */
/* §2 submission descriptor (64 bytes) / §3 completion entry (32 bytes)                        */
/* ------------------------------------------------------------------------------------------ */
#define SFS_DESC_BYTES      64u
#define SFS_DESC_WORDS      16u
#define SFS_CQE_BYTES       32u
#define SFS_CQE_WORDS       8u
#define SFS_BLOCK_SHIFT     9u
#define SFS_BLOCK_BYTES     512u
#define SFS_DISCARD_MAX     65535u
#define SFS_DESC_VERSION    1u

#define SFS_OP_WRITE           0x01u
#define SFS_OP_READ            0x02u
#define SFS_OP_FLUSH           0x03u
#define SFS_OP_GET_CAPACITY    0x04u
#define SFS_OP_DISCARD         0x05u

#define SFS_F_FUA              0x0001u
#define SFS_F_HCRC             0x0002u
#define SFS_F_RCRC             0x0004u
#define SFS_F_RESERVED_MASK    0xFFF8u

/* CQE word 1 flags */
#define SFS_CQE_DURABLE        (1u << 0)
#define SFS_CQE_PI_VERIFIED    (1u << 1)
#define SFS_CQE_ENCRYPTED      (1u << 2)
#define SFS_CQE_CRC_VALID      (1u << 3)
#define SFS_CQE_TXN_NO_DESC    0xFFFFu /* TXN_ID when the descriptor could not be read */

/* §4 status codes */
#define SFS_ST_SUCCESS          0x00u
#define SFS_ST_INVALID_OPCODE   0x01u
#define SFS_ST_INVALID_FIELD    0x02u
#define SFS_ST_INVALID_NS       0x03u
#define SFS_ST_LBA_RANGE        0x04u
#define SFS_ST_LEN_ERROR        0x05u
#define SFS_ST_TENANT_MISMATCH  0x06u
#define SFS_ST_NS_READONLY      0x07u
#define SFS_ST_DMA_FAULT        0x08u
#define SFS_ST_DMA_ERROR        0x09u
#define SFS_ST_DATA_CRC         0x0Au
#define SFS_ST_INTEGRITY        0x0Bu
#define SFS_ST_MEDIA_ERROR      0x0Cu
#define SFS_ST_BACKEND_ERROR    0x0Du
#define SFS_ST_TIMEOUT          0x0Eu
#define SFS_ST_ABORTED_RESET    0x0Fu
#define SFS_ST_ABORTED_POWER    0x10u
#define SFS_ST_UNSUPPORTED      0x11u
#define SFS_ST_CRYPTO_ERROR     0x12u
#define SFS_ST_INTERNAL         0x13u
#define SFS_ST_COUNT            0x14u

/* §4 detail codes */
#define SFS_DET_NONE            0u
/* INVALID_FIELD */
#define SFS_DET_FIELD_VERSION     1u
#define SFS_DET_FIELD_RESERVED    2u
#define SFS_DET_FIELD_FLAGS       3u
#define SFS_DET_FIELD_ADDR_ALIGN  4u
/* LEN_ERROR */
#define SFS_DET_LEN_ZERO          1u
#define SFS_DET_LEN_TOO_LARGE     2u
#define SFS_DET_LEN_MISMATCH      3u
#define SFS_DET_LEN_NOT_ZERO      4u
/* DMA_FAULT (CloudDMA FAULT code) */
#define SFS_DET_DMA_NO_MAP        1u
#define SFS_DET_DMA_PERM          2u
#define SFS_DET_DMA_DOMAIN        3u
#define SFS_DET_DMA_RANGE         4u
/* INTEGRITY */
#define SFS_DET_INTEG_GUARD       1u
#define SFS_DET_INTEG_LBA_TAG     2u
#define SFS_DET_INTEG_NS_TAG      3u
#define SFS_DET_INTEG_FORMAT      4u
/* TIMEOUT */
#define SFS_DET_TMO_BACKEND       1u
#define SFS_DET_TMO_DMA           2u
/* CRYPTO_ERROR */
#define SFS_DET_CRYPTO_KEY_NOT_READY 1u
#define SFS_DET_CRYPTO_ENGINE        2u

/* ------------------------------------------------------------------------------------------ */
/* §9 management window (privileged)                                                           */
/* ------------------------------------------------------------------------------------------ */
#define SFS_MG_ID_MAGIC       0x53465347u /* "SFSG" */

#define SFS_MG_REG_ID           0x000u
#define SFS_MG_REG_VERSION      0x004u
#define SFS_MG_REG_GCAPS0       0x008u
#define SFS_MG_REG_GCAPS1       0x00Cu
#define SFS_MG_REG_GCTRL        0x010u
#define SFS_MG_REG_GSTATUS      0x014u
#define SFS_MG_REG_CMD_TIMEOUT  0x018u
#define SFS_MG_REG_SCHED_CFG    0x01Cu
#define SFS_MG_REG_PF_CTRL      0x020u

/* GCAPS0: [7:0] NT, [15:8] NSLOT, [23:16] NS_N, [31:24] MDTS_BLOCKS */
#define SFS_GCAPS0_NT_SHIFT     0
#define SFS_GCAPS0_NSLOT_SHIFT  8
#define SFS_GCAPS0_NS_N_SHIFT   16
#define SFS_GCAPS0_MDTS_SHIFT   24
/* GCAPS1: [7:0] SQ_MAX, [15:8] CQ_MAX, [16] XTS, [17] VirtIO adapter, [27:24] backend type */
#define SFS_GCAPS1_SQ_MAX_SHIFT 0
#define SFS_GCAPS1_CQ_MAX_SHIFT 8
#define SFS_GCAPS1_XTS          (1u << 16)
#define SFS_GCAPS1_VIRTIO       (1u << 17)
#define SFS_GCAPS1_BE_TYPE_SHIFT 24
#define SFS_GCAPS1_BE_TYPE_MASK  0xFu

/* GCTRL */
#define SFS_GCTRL_ENABLE        (1u << 0)
#define SFS_GCTRL_SOFT_RESET    (1u << 1) /* W1S */
#define SFS_GCTRL_TRACE_EN      (1u << 2)
#define SFS_GCTRL_CLR_COUNTERS  (1u << 3) /* W1S */
#define SFS_GCTRL_RD_PRIO       (1u << 4)
#define SFS_GCTRL_WR_BATCH      (1u << 5)
#define SFS_GCTRL_RW_MASK       (SFS_GCTRL_ENABLE | SFS_GCTRL_TRACE_EN | SFS_GCTRL_RD_PRIO | SFS_GCTRL_WR_BATCH)

/* GSTATUS */
#define SFS_GSTATUS_BE_READY    (1u << 0)
#define SFS_GSTATUS_PF_QUIESCE  (1u << 1)
#define SFS_GSTATUS_FATAL       (1u << 2)
#define SFS_GSTATUS_BUSY_SLOTS_SHIFT 8
#define SFS_GSTATUS_BE_BUSY_SHIFT    16

/* SCHED_CFG: [7:0] WR_BATCH_MAX (default 4), [15:8] WR_AGE_MAX (default 8) */
#define SFS_SCHED_WR_BATCH_MAX_SHIFT 0
#define SFS_SCHED_WR_AGE_MAX_SHIFT   8

/* PF_CTRL */
#define SFS_PF_FORCE_WARN       (1u << 0)

/* TCFG(t) at 0x100 + 0x20*t */
#define SFS_MG_TCFG_BASE        0x100u
#define SFS_MG_TCFG_STRIDE      0x20u
#define SFS_TCFG_ENABLE_ALLOWED 0x00u
#define SFS_TCFG_MAX_INFLIGHT   0x04u
#define SFS_TCFG_WEIGHT         0x08u
#define SFS_TCFG_RATE           0x0Cu
#define SFS_TCFG_BURST          0x10u

/* NS(n) at 0x300 + 0x20*n */
#define SFS_MG_NS_BASE          0x300u
#define SFS_MG_NS_STRIDE        0x20u
#define SFS_NS_CTRL             0x00u
#define SFS_NS_BASE_LO          0x04u
#define SFS_NS_BASE_HI          0x08u
#define SFS_NS_SIZE_LO          0x0Cu
#define SFS_NS_SIZE_HI          0x10u
#define SFS_NS_STATUS           0x14u
/* NS_CTRL */
#define SFS_NSC_VALID           (1u << 0)
#define SFS_NSC_READONLY        (1u << 1)
#define SFS_NSC_ENC_EN          (1u << 2)
#define SFS_NSC_PI_EN           (1u << 3)
#define SFS_NSC_OWNER_SHIFT     4
#define SFS_NSC_OWNER_MASK      0xFu
#define SFS_NSC_KEY_SLOT_SHIFT  8
#define SFS_NSC_KEY_SLOT_MASK   0xFu
/* NS_STATUS */
#define SFS_NSS_ACCEPTED        (1u << 0)
#define SFS_NSS_NO_CAPACITY     (1u << 1)
#define SFS_NSS_PI_UNSUPPORTED  (1u << 2)
#define SFS_NSS_BAD_OWNER_SIZE  (1u << 3)
#define SFS_NSS_ENC_UNSUPPORTED (1u << 4) /* ENC_EN without an XTS engine, or key slot out of range */
#define SFS_NSS_OVERLAP         (1u << 5) /* overlaps another valid namespace */

/* DMA windows at 0x500 (PT_*); entries 0..NT-1 belong to the fabric, the hypervisor programs NT..15 */
#define SFS_MG_PT_BASE          0x500u
#define SFS_PT_IDX              0x00u
#define SFS_PT_DOM              0x04u
#define SFS_PT_BASE_LO          0x08u
#define SFS_PT_BASE_HI          0x0Cu
#define SFS_PT_SIZE_LO          0x10u
#define SFS_PT_SIZE_HI          0x14u
#define SFS_PT_PERM             0x18u
#define SFS_PT_CTRL             0x1Cu
#define SFS_PT_STATUS           0x20u
#define SFS_PT_PERM_R           (1u << 0)
#define SFS_PT_PERM_W           (1u << 1)
#define SFS_PT_CTRL_VALID       (1u << 0)
#define SFS_PT_CTRL_COMMIT      (1u << 1) /* W1S */
#define SFS_PT_STATUS_REJECTED  (1u << 0)
#define SFS_PT_ENTRIES         16u

/* backend (assumed consecutive words from 0x600) */
#define SFS_MG_BE_BASE          0x600u
#define SFS_BE_TYPE             0x00u
#define SFS_BE_CAPS             0x04u
#define SFS_BE_CAP_LO           0x08u
#define SFS_BE_CAP_HI           0x0Cu
#define SFS_BE_CTRL             0x10u
#define SFS_BE_CTRL_RESET       (1u << 0) /* W1S */
/* be_caps bit positions follow the order of the names in §7 (assumed) */
#define SFS_BECAP_PI_NATIVE       (1u << 0)
#define SFS_BECAP_VOLATILE_CACHE  (1u << 1)
#define SFS_BECAP_DISCARD         (1u << 2)
#define SFS_BECAP_DISCARD_ZERO    (1u << 3)
#define SFS_BECAP_READONLY        (1u << 4)

/* keys (assumed consecutive words from 0x700) */
#define SFS_MG_KEY_BASE         0x700u
#define SFS_KEY_SEL             0x00u
#define SFS_KEY_W0              0x04u /* W0..W15 at +0x04 .. +0x40, write-only */
#define SFS_KEY_CTRL            0x44u
#define SFS_KEY_CTRL_COMMIT     (1u << 0)
#define SFS_KEY_CTRL_ZEROIZE    (1u << 1)
#define SFS_KEY_WORDS           16u
#define SFS_KEY_BYTES           64u /* XTS-AES-256: two 256-bit keys */

/* performance (assumed consecutive words from 0x800) */
#define SFS_MG_PERF_BASE        0x800u
#define SFS_PERF_SEL            0x00u
#define SFS_PERF_LO             0x04u /* reading LO latches HI */
#define SFS_PERF_HI             0x08u

/* trace FIFO (assumed consecutive words from 0x900) */
#define SFS_MG_TR_BASE          0x900u
#define SFS_TR_STAT             0x00u /* [15:0] entries, [31:16] dropped */
#define SFS_TR_W0               0x04u /* W0..W7 at +0x04 .. +0x20 (head record) */
#define SFS_TR_POP              0x24u /* write 1 */
#define SFS_TR_WORDS            8u

#ifdef __cplusplus
}
#endif

#endif /* SFSTOR_REGS_H */
