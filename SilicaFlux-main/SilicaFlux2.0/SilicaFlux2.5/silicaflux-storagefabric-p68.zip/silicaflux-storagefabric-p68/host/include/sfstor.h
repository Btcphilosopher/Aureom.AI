/*
 * sfstor.h - libsfstor: host/VM driver library for the SilicaFlux StorageFabric (ABI v1.0).
 *
 * Written from docs/02_HOST_INTERFACE.md only.  C99, no dynamic allocation: every object
 * (sfs_dev_t, sfs_queue_t, sfs_mgmt_t) is caller-allocated; ring and data memory come from the
 * transport (`mem_alloc`).  The library reaches the device ONLY through the transport structs, so the
 * same code runs against real MMIO, a Verilator co-simulation or a software mock.
 *
 * Conventions
 *   - Functions return 0 (or a count >= 0) on success and a negative SFS_E_* code on error.
 *   - All descriptor / completion words are stored little-endian, byte by byte (no reliance on host
 *     endianness).  Descriptors are written, then a barrier, then the SQ_TAIL doorbell.  Completions
 *     are read with the PHASE word first, then a barrier, then the rest (§3).
 *   - A queue holds at most SQ_SIZE-1 outstanding descriptors (§8 SQ_TAIL rule); submit helpers
 *     return SFS_E_FULL instead of ever writing an overflowing doorbell.
 *   - Not thread safe: one thread per sfs_queue_t.  Distinct queues / devices are independent.
 *   - Submit helpers validate only what the library can know locally (MDTS, alignment, capability
 *     bits).  To send an arbitrary (even illegal) descriptor use sfs_submit_desc()/sfs_submit_raw();
 *     the device then returns the §2 status.
 */
#ifndef SFSTOR_H
#define SFSTOR_H

#include <stddef.h>
#include <stdint.h>

#include "sfstor_regs.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------------------------------ */
/* Errors                                                                                      */
/* ------------------------------------------------------------------------------------------ */
#define SFS_OK              0
#define SFS_E_INVAL        (-1)  /* bad argument / illegal value for this device */
#define SFS_E_NO_DEVICE    (-2)  /* ID register mismatch */
#define SFS_E_VERSION      (-3)  /* ABI major version differs, or unsupported block size */
#define SFS_E_UNSUPPORTED  (-4)  /* capability absent (e.g. DISCARD, FUA, HCRC) */
#define SFS_E_NOMEM        (-5)  /* transport mem_alloc failed */
#define SFS_E_ALIGN        (-6)  /* transport returned insufficiently aligned memory */
#define SFS_E_FULL         (-7)  /* submission ring full (SQ_SIZE-1 entries outstanding) */
#define SFS_E_TIMEOUT      (-8)  /* wait loop exhausted */
#define SFS_E_STATE        (-9)  /* object not open / queue not created */
#define SFS_E_NOT_ENABLED  (-10) /* STATUS.ENABLED did not read back (hypervisor has not allowed the queue) */
#define SFS_E_BAD_SIZE     (-11) /* device rejected SQ_SIZE/CQ_SIZE (DB_ERR) */
#define SFS_E_BUSY         (-12) /* synchronous call while other commands are in flight */
#define SFS_E_PROTO        (-13) /* unexpected completion (TXN_ID mismatch) */
#define SFS_E_STATUS       (-14) /* command completed with STATUS != SUCCESS (CQE returned to caller) */
#define SFS_E_REFUSED      (-15) /* management request refused by the device */
#define SFS_E_FATAL        (-16) /* queue reports FATAL */

/* Human-readable text for an SFS_E_* code (never NULL). */
const char *sfs_strerror(int err);

/* ------------------------------------------------------------------------------------------ */
/* Transport                                                                                   */
/* ------------------------------------------------------------------------------------------ */
typedef struct sfs_transport {
  void *ctx;
  /* offset inside THIS tenant's 4 KiB page; 32-bit aligned accesses only */
  uint32_t (*mmio_read32)(void *ctx, uint32_t off);
  void (*mmio_write32)(void *ctx, uint32_t off, uint32_t val);
  /* Tenant memory in the IOVA space the device DMAs in; `va` gives the library CPU access to the same
   * bytes.  Returns 0 on success.  Memory must be zero-initialised or the library zeroes what it needs. */
  int (*mem_alloc)(void *ctx, size_t bytes, size_t align, uint64_t *iova, void **va);
  void (*mem_free)(void *ctx, uint64_t iova);
  void (*yield)(void *ctx);   /* called inside wait loops; may be NULL */
  void (*barrier)(void *ctx); /* memory barrier; may be NULL (compiler-barrier fallback) */
} sfs_transport_t;

/* ------------------------------------------------------------------------------------------ */
/* Device: discovery (§8 ID/VERSION/CAPS)                                                      */
/* ------------------------------------------------------------------------------------------ */
typedef struct sfs_caps {
  uint32_t id;
  uint32_t version;          /* raw VERSION register */
  uint32_t mdts_blocks;      /* CAPS0[7:0]: max blocks per READ/WRITE */
  uint32_t sq_max;           /* CAPS0[15:8]: max SQ entries */
  uint32_t cq_max;           /* CAPS0[23:16] */
  uint32_t block_shift;      /* CAPS0[31:24], 9 */
  int discard;               /* CAPS1 bits, 0/1 */
  int pi;
  int enc;
  int fua;
  int hcrc;
  int volatile_cache;
  int backend_ready;
  uint32_t backend_type;     /* SFS_BE_* */
  uint32_t ns_mask;          /* bit n set: NSID n is valid and owned by this tenant (CAPS1[31:16]) */
  uint32_t caps0_raw, caps1_raw;
} sfs_caps_t;

typedef struct sfs_dev {
  sfs_transport_t tp;
  sfs_caps_t caps;
  uint32_t tenant;           /* hardware binding index, put in every descriptor's TENANT_CLAIM */
  int is_open;
} sfs_dev_t;

/* Open the tenant page: checks ID and the VERSION major, reads CAPS0/CAPS1.  `tenant` is this
 * function's hardware binding (the value the platform bound the page to): the ABI has no register
 * that reports it (model/SPEC_QUESTIONS.md Q-08), but every descriptor must carry it as TENANT_CLAIM
 * (§2, rule 3).  The transport
 * struct is copied.  mmio_read32/mmio_write32/mem_alloc/mem_free are mandatory. */
int sfs_dev_open(sfs_dev_t *dev, const sfs_transport_t *tp, unsigned tenant);
/* Re-read CAPS0/CAPS1 (e.g. after the hypervisor configured namespaces: ns_mask, backend_ready). */
int sfs_dev_refresh_caps(sfs_dev_t *dev);
const sfs_caps_t *sfs_dev_caps(const sfs_dev_t *dev);
/* Lowest NSID owned by this tenant, or -1 if it owns none. */
int sfs_dev_first_ns(const sfs_dev_t *dev);
int sfs_dev_owns_ns(const sfs_dev_t *dev, unsigned nsid);

/* DMA-able buffer helper (thin wrapper over the transport allocator; 4-byte aligned minimum). */
typedef struct sfs_buf {
  uint64_t iova;
  void *va;
  size_t len;
} sfs_buf_t;
int sfs_buf_alloc(sfs_dev_t *dev, size_t bytes, sfs_buf_t *buf);
void sfs_buf_free(sfs_dev_t *dev, sfs_buf_t *buf);

/* ------------------------------------------------------------------------------------------ */
/* Descriptor and completion structures (§2, §3)                                               */
/* ------------------------------------------------------------------------------------------ */
typedef struct sfs_desc {
  uint8_t version;       /* word0[7:0]   must be 1 */
  uint8_t opcode;        /* word0[15:8] */
  uint16_t flags;        /* word0[31:16] */
  uint16_t txn;          /* word1[15:0] */
  uint8_t nsid;          /* word1[23:16] */
  uint8_t rsv1;          /* word1[31:24] reserved, must be 0 */
  uint64_t lba;          /* words 2,3 */
  uint32_t nblk;         /* word 4 */
  uint32_t data_len;     /* word 5 */
  uint64_t data_addr;    /* words 6,7 (IOVA) */
  uint16_t tenant_claim; /* word8[15:0] */
  uint16_t rsv8;         /* word8[31:16] reserved, must be 0 */
  uint32_t host_crc;     /* word 9 */
  uint32_t rsv[6];       /* words 10..15, must be 0 */
} sfs_desc_t;

void sfs_desc_pack(const sfs_desc_t *d, uint32_t w[SFS_DESC_WORDS]);
void sfs_desc_unpack(const uint32_t w[SFS_DESC_WORDS], sfs_desc_t *d);

typedef struct sfs_cqe {
  uint16_t txn;
  uint8_t status;      /* SFS_ST_* */
  uint8_t detail;
  uint8_t durable;     /* 0/1 */
  uint8_t pi_verified;
  uint8_t encrypted;
  uint8_t crc_valid;
  uint8_t opcode;
  uint16_t nblk_done;
  uint32_t result0;    /* payload CRC-32C if crc_valid; GET_CAPACITY: capacity[31:0] */
  uint32_t result1;    /* GET_CAPACITY: capacity[63:32] */
  uint16_t sq_head;
  uint16_t tenant;
  uint32_t latency;    /* fabric cycles, descriptor fetch complete -> completion posted */
  uint8_t phase;
  uint32_t raw[SFS_CQE_WORDS];
} sfs_cqe_t;

void sfs_cqe_unpack(const uint32_t w[SFS_CQE_WORDS], sfs_cqe_t *c);
/* GET_CAPACITY result in blocks. */
uint64_t sfs_cqe_capacity(const sfs_cqe_t *c);

/* Latency accounting (client side, from CQE.latency).  Plain running statistics. */
typedef struct sfs_lat {
  uint64_t count;
  uint64_t sum;
  uint32_t min;
  uint32_t max;
} sfs_lat_t;
void sfs_lat_reset(sfs_lat_t *l);
void sfs_lat_add(sfs_lat_t *l, uint32_t cycles);
/* Mean in cycles (integer division, rounds down); 0 if empty. */
uint32_t sfs_lat_mean(const sfs_lat_t *l);
/* Nearest-rank percentile of `n` samples.  `pct_x100` is the percentile in hundredths of a percent
 * (5000 = median, 9900 = p99, 9990 = p99.9, 10000 = max, 0 = min).  rank = ceil(pct_x100 * n / 10000),
 * clamped to [1, n]; the result is the rank-th smallest sample.  The array is SORTED IN PLACE
 * (copy first if the order matters).  Returns SFS_E_INVAL for n == 0, pct_x100 > 10000 or NULL. */
int sfs_percentile(uint32_t *samples, size_t n, unsigned pct_x100, uint32_t *out);

/* ------------------------------------------------------------------------------------------ */
/* Queue (§8 bring-up)                                                                         */
/* ------------------------------------------------------------------------------------------ */
typedef struct sfs_queue {
  sfs_dev_t *dev;
  int active;
  uint32_t sq_entries, cq_entries;
  uint64_t sq_iova, cq_iova;
  uint8_t *sq_va;
  volatile uint8_t *cq_va;
  uint32_t sq_tail;       /* next slot to fill (library's producer index) */
  uint32_t sq_db;         /* last value written to SQ_TAIL */
  uint64_t sq_head_abs;   /* descriptors known to be consumed by the fabric (lower bound; see sfs_sq_space) */
  uint32_t cq_head;       /* next CQE slot to consume */
  uint32_t cq_db;         /* last value written to CQ_HEAD */
  uint32_t cq_unacked;    /* consumed entries not yet announced by a CQ_HEAD write */
  uint32_t cq_batch;      /* write CQ_HEAD every this many consumed entries (1 = every one) */
  uint32_t cq_phase;      /* expected PHASE bit of the next entry (starts at 1) */
  int autoring;
  uint64_t submitted, completed;
  uint16_t next_txn;
  uint32_t sync_polls;    /* poll budget of the *_sync helpers */
  sfs_lat_t lat;          /* accumulates CQE.latency of every consumed completion */
} sfs_queue_t;

/* Create and enable the queue pair: allocate SQ (64-byte aligned) and CQ (32-byte aligned) through the
 * transport, zero the CQ (phase 0), program SQ_BASE/SQ_SIZE/CQ_BASE/CQ_SIZE with the queue disabled,
 * set CTRL.ENABLE and verify STATUS.ENABLED.  Entries must be powers of two, 2 <= n <= SQ_MAX/CQ_MAX.
 * If the queue carries stale state (enabled, error bits, non-zero pointers) it is CTRL.RESET first.
 * SFS_E_NOT_ENABLED means the hypervisor has not set TCFG.ENABLE_ALLOWED. */
int sfs_queue_create(sfs_dev_t *dev, sfs_queue_t *q, uint32_t sq_entries, uint32_t cq_entries);
/* Disable, reset (clears the device's ring pointers; in-flight commands are aborted without
 * completions), free the rings. */
int sfs_queue_destroy(sfs_queue_t *q);
/* CTRL.RESET (e.g. after FATAL), clear library ring state, re-zero the CQ, re-program and re-enable.
 * In-flight commands are lost (no completions). */
int sfs_queue_reset(sfs_queue_t *q);
/* If non-zero every submit helper also rings the doorbell (default 0: call sfs_ring() to batch). */
void sfs_queue_set_autoring(sfs_queue_t *q, int on);
/* Write CQ_HEAD only after every `n` consumed completions (default 1).  sfs_wait() and
 * sfs_cq_doorbell() flush a pending head update. */
void sfs_queue_set_cq_batch(sfs_queue_t *q, unsigned n);
void sfs_queue_set_sync_polls(sfs_queue_t *q, uint32_t polls);
const sfs_lat_t *sfs_queue_latency(const sfs_queue_t *q);

/* Free submission slots (a lower bound).  Completions consumed imply descriptors fetched; only when that
 * view says "full" is the SQ_HEAD register read, so the value can under-report while commands are in
 * flight but never over-reports.  CQE.SQ_HEAD is reported to the
 * caller but deliberately not used for ring accounting: a masked index cannot tell a stale hint from a
 * full lap of progress. */
int sfs_sq_space(sfs_queue_t *q);
/* Commands submitted whose completion has not been consumed. */
uint32_t sfs_inflight(const sfs_queue_t *q);

/* ------------------------------------------------------------------------------------------ */
/* Submit                                                                                      */
/* ------------------------------------------------------------------------------------------ */
#define SFS_FLAG_FUA   SFS_F_FUA   /* WRITE only: completion not posted before the data is durable */
#define SFS_FLAG_HCRC  SFS_F_HCRC  /* WRITE only: device checks HOST_CRC (sfs_submit_write computes it) */
#define SFS_FLAG_RCRC  SFS_F_RCRC  /* READ/WRITE: completion carries the payload CRC-32C */

/* Raw: place a descriptor exactly as given (no checks) at the SQ tail.  Rings if autoring. */
int sfs_submit_desc(sfs_queue_t *q, const sfs_desc_t *d);
int sfs_submit_raw(sfs_queue_t *q, const uint32_t w[SFS_DESC_WORDS]);

/* data_iova: tenant IOVA of the buffer, 4-byte aligned.  nblk: 1..MDTS. */
int sfs_submit_read(sfs_queue_t *q, uint16_t txn, unsigned nsid, uint64_t lba, uint32_t nblk, uint64_t data_iova,
                    uint32_t flags);
/* With SFS_FLAG_HCRC the library computes HOST_CRC (CRC-32C) over nblk*512 bytes at `data_va` (must be
 * non-NULL then).  Without HCRC data_va may be NULL (HOST_CRC is sent as 0). */
int sfs_submit_write(sfs_queue_t *q, uint16_t txn, unsigned nsid, uint64_t lba, uint32_t nblk, uint64_t data_iova,
                     const void *data_va, uint32_t flags);
/* Same, with an explicit HOST_CRC (use with SFS_FLAG_HCRC to inject a wrong CRC). */
int sfs_submit_write_crc(sfs_queue_t *q, uint16_t txn, unsigned nsid, uint64_t lba, uint32_t nblk, uint64_t data_iova,
                         uint32_t flags, uint32_t host_crc);
/* FLUSH needs a valid owned NSID like every command (the flush itself is queue-wide, §5.2; Q-01). */
int sfs_submit_flush(sfs_queue_t *q, uint16_t txn, unsigned nsid);
int sfs_submit_discard(sfs_queue_t *q, uint16_t txn, unsigned nsid, uint64_t lba, uint32_t nblk);
int sfs_submit_get_capacity(sfs_queue_t *q, uint16_t txn, unsigned nsid);

/* Publish everything submitted since the last ring: barrier, then SQ_TAIL.  No-op if nothing new. */
int sfs_ring(sfs_queue_t *q);

/* ------------------------------------------------------------------------------------------ */
/* Completions (§3)                                                                            */
/* ------------------------------------------------------------------------------------------ */
/* Returns 1 and fills *cqe (may be NULL: just consume) if a completion was ready, 0 if none, <0 on
 * error.  Reads word 7 (PHASE) first, barrier, then words 0..6; tracks the expected phase across
 * wraps; advances the head and writes CQ_HEAD (subject to the batch setting). */
int sfs_poll(sfs_queue_t *q, sfs_cqe_t *cqe);
/* Poll until a completion arrives.  Any submission not yet rung is rung first.  max_polls == 0 waits
 * forever (SFS_WAIT_FOREVER).  Returns 0 with *cqe filled, or SFS_E_TIMEOUT. */
#define SFS_WAIT_FOREVER 0u
int sfs_wait(sfs_queue_t *q, sfs_cqe_t *cqe, uint32_t max_polls);
/* Announce consumed completions now (CQ_HEAD). */
int sfs_cq_doorbell(sfs_queue_t *q);

/* ------------------------------------------------------------------------------------------ */
/* Synchronous convenience wrappers                                                            */
/* ------------------------------------------------------------------------------------------ */
/* Each needs the queue idle (SFS_E_BUSY otherwise), submits one command with an automatic TXN_ID,
 * rings, waits.  Return 0 on SUCCESS; SFS_E_STATUS if the command completed with STATUS != SUCCESS (the
 * CQE is still returned through `cqe_out`, which may be NULL); other negatives are library errors. */
int sfs_read_sync(sfs_queue_t *q, unsigned nsid, uint64_t lba, uint32_t nblk, uint64_t data_iova, uint32_t flags,
                  sfs_cqe_t *cqe_out);
int sfs_write_sync(sfs_queue_t *q, unsigned nsid, uint64_t lba, uint32_t nblk, uint64_t data_iova, const void *data_va,
                   uint32_t flags, sfs_cqe_t *cqe_out);
int sfs_flush_sync(sfs_queue_t *q, unsigned nsid, sfs_cqe_t *cqe_out);
int sfs_discard_sync(sfs_queue_t *q, unsigned nsid, uint64_t lba, uint32_t nblk, sfs_cqe_t *cqe_out);
/* GET_CAPACITY: *blocks receives the namespace size in blocks. */
int sfs_capacity_sync(sfs_queue_t *q, unsigned nsid, uint64_t *blocks, sfs_cqe_t *cqe_out);

/* ------------------------------------------------------------------------------------------ */
/* Errors: status decode and queue status                                                      */
/* ------------------------------------------------------------------------------------------ */
const char *sfs_status_str(unsigned status);                 /* §4 name, "SUCCESS", "INVALID_NS", ... */
const char *sfs_detail_str(unsigned status, unsigned detail);  /* §4 detail name; "-" for 0; "code" for backend/DMA codes */

typedef struct sfs_qstatus {
  uint32_t status_raw, irq_raw;
  int enabled, sq_err, cq_err, fatal, sq_empty, idle;
  uint32_t last_err;          /* STATUS[15:8]: last queue-error code (CloudDMA ERR) */
  int irq_cq_nonempty, irq_queue_err, irq_db_err;
  uint32_t sq_head, cq_tail;  /* fabric indices */
  uint32_t sq_tail, cq_head;  /* doorbell registers */
  uint32_t inflight;          /* INFLIGHT register */
} sfs_qstatus_t;
int sfs_queue_status(sfs_queue_t *q, sfs_qstatus_t *out);
/* Clear the sticky IRQ_STATUS bits in `mask` (SFS_IRQ_QUEUE_ERR | SFS_IRQ_DB_ERR). */
int sfs_queue_ack_irq(sfs_queue_t *q, uint32_t mask);
/* Format e.g. "ENABLED SQ_ERR last_err=0x03 DB_ERR" into buf (always NUL terminated). */
void sfs_qstatus_str(const sfs_qstatus_t *s, char *buf, size_t n);

/* ------------------------------------------------------------------------------------------ */
/* Performance counters (§8 0x060, 0x080..0x09C)                                               */
/* ------------------------------------------------------------------------------------------ */
typedef struct sfs_perf {
  uint32_t inflight, done, err, rd_blk, wr_blk, flush, throttle, viol, bytes_lo;
} sfs_perf_t;
int sfs_perf_read(sfs_dev_t *dev, sfs_perf_t *out);

/* ------------------------------------------------------------------------------------------ */
/* CRC-32C (Castagnoli, reflected, init/xorout 0xFFFFFFFF); sfs_crc32c("123456789") == 0xE3069283 */
/* ------------------------------------------------------------------------------------------ */
uint32_t sfs_crc32c(const void *data, size_t len);
/* Chaining: sfs_crc32c_update(sfs_crc32c(a), b) == sfs_crc32c(a||b); start from 0. */
uint32_t sfs_crc32c_update(uint32_t crc, const void *data, size_t len);

/* ------------------------------------------------------------------------------------------ */
/* Hypervisor side: management window (§9).  Separate transport; never given to a tenant.      */
/* ------------------------------------------------------------------------------------------ */
typedef struct sfs_mgmt_transport {
  void *ctx;
  uint32_t (*mmio_read32)(void *ctx, uint32_t off); /* offset inside the management window */
  void (*mmio_write32)(void *ctx, uint32_t off, uint32_t val);
  void (*yield)(void *ctx); /* may be NULL */
} sfs_mgmt_transport_t;

typedef struct sfs_gcaps {
  uint32_t nt, nslot, ns_n, mdts_blocks;
  uint32_t sq_max, cq_max;
  int xts, virtio;
  uint32_t backend_type;
} sfs_gcaps_t;

typedef struct sfs_mgmt {
  sfs_mgmt_transport_t tp;
  sfs_gcaps_t caps;
  uint32_t gctrl; /* shadow of the RW bits of GCTRL (the W1S bits are never re-written) */
  int is_open;
} sfs_mgmt_t;

int sfs_mgmt_open(sfs_mgmt_t *mg, const sfs_mgmt_transport_t *tp);

/* GCTRL.ENABLE (0 at reset: no queue starts) */
int sfs_mgmt_enable_fabric(sfs_mgmt_t *mg, int enable);
/* Set the RW bits of GCTRL exactly to `flags` (SFS_GCTRL_ENABLE|TRACE_EN|RD_PRIO|WR_BATCH). */
int sfs_mgmt_set_gctrl(sfs_mgmt_t *mg, uint32_t flags);
int sfs_mgmt_soft_reset(sfs_mgmt_t *mg);      /* GCTRL.SOFT_RESET */
int sfs_mgmt_clear_counters(sfs_mgmt_t *mg);  /* GCTRL.CLR_COUNTERS */

typedef struct sfs_gstatus {
  int backend_ready, pf_quiesce, fatal;
  uint32_t busy_slots, backend_busy, raw;
} sfs_gstatus_t;
int sfs_mgmt_gstatus(sfs_mgmt_t *mg, sfs_gstatus_t *out);
/* CMD_TIMEOUT in fabric cycles (0 = disabled).  Commands exceeding it complete TIMEOUT. */
int sfs_mgmt_set_cmd_timeout(sfs_mgmt_t *mg, uint32_t cycles);
/* SCHED_CFG: WR_BATCH_MAX (default 4), WR_AGE_MAX (default 8). */
int sfs_mgmt_set_sched(sfs_mgmt_t *mg, uint32_t wr_batch_max, uint32_t wr_age_max);
int sfs_mgmt_force_power_fail(sfs_mgmt_t *mg, int on); /* PF_CTRL test hook */

typedef struct sfs_tcfg {
  int enable_allowed;
  uint32_t max_inflight; /* 0 = NSLOT */
  uint32_t weight;       /* DRR quantum 1..255 (0 reads as 1) */
  uint32_t rate;         /* blocks per 1024 cycles, 0 = unlimited */
  uint32_t burst;        /* bucket depth, blocks */
} sfs_tcfg_t;
int sfs_mgmt_tenant_cfg(sfs_mgmt_t *mg, unsigned tenant, const sfs_tcfg_t *cfg);
int sfs_mgmt_tenant_allow(sfs_mgmt_t *mg, unsigned tenant, int allow); /* TCFG.ENABLE_ALLOWED only */

typedef struct sfs_ns_cfg {
  unsigned owner;
  uint64_t base;  /* backend blocks */
  uint64_t size;  /* blocks */
  int readonly, enc, pi;
  unsigned key_slot;
} sfs_ns_cfg_t;
/* §9 sequence: VALID=0, BASE/SIZE/flags, then VALID=1, read NS_STATUS.  Returns 0 if accepted,
 * SFS_E_REFUSED otherwise; *ns_status (may be NULL) receives the SFS_NSS_* bits either way. */
int sfs_mgmt_ns_config(sfs_mgmt_t *mg, unsigned nsid, const sfs_ns_cfg_t *cfg, uint32_t *ns_status);
int sfs_mgmt_ns_invalidate(sfs_mgmt_t *mg, unsigned nsid);

typedef struct sfs_dma_window {
  uint32_t domain;
  uint64_t base, size;
  int perm_r, perm_w;
} sfs_dma_window_t;
/* Program PT entry `idx` (NT..15; 0..NT-1 belong to the fabric): IDX/DOM/BASE/SIZE/PERM, then VALID, then COMMIT;
 * SFS_E_REFUSED if PT_STATUS.rejected. */
int sfs_mgmt_dma_window(sfs_mgmt_t *mg, unsigned idx, const sfs_dma_window_t *w);
int sfs_mgmt_dma_window_clear(sfs_mgmt_t *mg, unsigned idx);

typedef struct sfs_be_info {
  uint32_t type, caps;
  uint64_t capacity_blocks;
} sfs_be_info_t;
int sfs_mgmt_backend_info(sfs_mgmt_t *mg, sfs_be_info_t *out);
int sfs_mgmt_backend_reset(sfs_mgmt_t *mg);

/* XTS-AES-256 key = 64 bytes (two 256-bit keys), written as little-endian words W0..W15, then commit. */
int sfs_mgmt_key_load(sfs_mgmt_t *mg, unsigned slot, const uint8_t key[SFS_KEY_BYTES]);
int sfs_mgmt_key_zeroize(sfs_mgmt_t *mg, unsigned slot);

/* Global performance counter `sel` (ids are defined in the RTL package, not in the ABI text):
 * writes PERF_SEL, reads PERF_LO (which latches HI), then PERF_HI. */
int sfs_mgmt_perf_read(sfs_mgmt_t *mg, uint32_t sel, uint64_t *value);

typedef struct sfs_trace_rec {
  uint16_t txn;
  uint32_t tenant;    /* word0[23:16] */
  uint8_t opcode;     /* word0[31:24] */
  uint8_t status;     /* word1[7:0] */
  uint8_t detail;     /* word1[15:8] */
  uint16_t nblk;      /* word1[31:16] */
  uint32_t cyc_fetch; /* W2: descriptor fetch complete */
  uint32_t cyc_admit; /* W3: admitted to a slot */
  uint32_t cyc_issue; /* W4: backend request issued */
  uint32_t cyc_be_done; /* W5: backend completed */
  uint32_t cyc_post;  /* W6: completion posted */
  int durable;        /* W7[31] (assumed position) */
  uint32_t bytes;     /* W7[30:0] (assumed) */
  uint32_t raw[SFS_TR_WORDS];
} sfs_trace_rec_t;
int sfs_mgmt_trace_status(sfs_mgmt_t *mg, uint32_t *entries, uint32_t *dropped);
/* Returns 1 and fills *rec if a record was popped, 0 if the FIFO is empty. */
int sfs_mgmt_trace_pop(sfs_mgmt_t *mg, sfs_trace_rec_t *rec);
/* Queue wait of a trace record in cycles (W3 - W2, 32-bit wraparound safe). */
uint32_t sfs_trace_queue_wait(const sfs_trace_rec_t *rec);

#ifdef __cplusplus
}
#endif

#endif /* SFSTOR_H */
