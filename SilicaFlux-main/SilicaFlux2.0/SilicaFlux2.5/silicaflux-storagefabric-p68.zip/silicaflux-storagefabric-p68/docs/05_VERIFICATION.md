# 05 — Verification

Simulation only (Verilator, cycle-accurate RTL; `07_LIMITATIONS.md`). Everything in this chapter was produced by `scripts/run_all.sh`; the raw logs are in `reports/` and the totals in `reports/SUMMARY.txt`.

## 1. Strategy and oracles

No test trusts the RTL to check itself. Each command goes through **independent** oracles:

| Oracle | What it is | Independence |
|---|---|---|
| **Reference model** `model/sfref.hpp` | logical block-device model: validation verdict for every descriptor (the 12 ordered rules), expected completion (status, detail, durable, PI-verified, CRC, `NBLK_DONE`, counters), expected read data, per-block "old / new" sets after failed or lost writes, volatile-cache and power-loss semantics | written by a separate agent from `02_HOST_INTERFACE.md` only; self-test 489 896 checks; ambiguities in `model/SPEC_QUESTIONS.md` |
| **Host library** `host/` (libsfstor, C99) | the only way the testbench builds queues, submits, polls and configures the hypervisor side | written from the same spec only; unit-tested against a software mock fabric (10 404 checks) |
| **Bus monitor** (`sim/sfs_harness.hpp`) | an AXI4 slave that records the windows the hypervisor programmed and checks **every beat** (domain, address range, read/write permission, asid); any beat outside every window, or any local-memory (asid 1) beat on the host port, is a failure | shares no code with the RTL or CloudDMA |
| **VirtIO guest-DMA monitor** (`sim/virtio_test.cpp`) | rebuilds the P63 permission table from the management writes it observes and re-checks every guest-memory beat | independent of the engine's own gate |
| **Device backdoor** | the simulated device exposes any stored unit (cache first, else medium), the dirty-block count and "never touched" per block: used to check the exact stored trailer bytes, that FLUSH reaches the backend, and that no block outside a namespace was ever written | — |
| **OpenSSL** | XTS-AES-256 ciphertext on the medium vs `EVP_aes_256_xts` over the 528-byte unit with the backend-absolute LBA as tweak | external |
| **Mutation testing** | single-bug RTL mutants must be caught (§6) | — |

Command streams are a mix of directed cases and model-driven random generation (valid and invalid descriptors by construction, hot LBAs for overlap, up to 24 outstanding commands, random bus back-pressure, 4 tenants contending, multi-block, unaligned and out-of-range requests). Every completion is compared with the model: a mismatch fails the run. After every test the whole logical content of every namespace is read back and compared (`verify_all`).

## 2. Test catalogue

| Test | What it exercises |
|---|---|
| `basic` | reads, writes, overwrites, FLUSH, GET_CAPACITY, DISCARD on every tenant; exact data; per-tenant counters vs the model |
| `random` | mixed valid + invalid traffic from all tenants, queue depth ≤ 24, random AXI back-pressure, hot LBAs (overlap serialisation), multi-block |
| `invalid` | every validation rule in the documented order, stacked faults, unaligned / illegal / out-of-bounds requests; verdicts from the model |
| `isolation` | foreign namespaces, wrong `TENANT_CLAIM`, data buffers and SQ/CQ rings outside the tenant's DMA windows (fatal queue), tenant pages, other tenants' data untouched; bus monitor |
| `durability` | volatile-cache vs durable completions, FLUSH, FUA (internal backend flush), power loss with a volatile write cache (any subset of unflushed blocks survives), acknowledged-durable data exact after recovery |
| `backend_fail` | device failure, media error on one block (`NBLK_DONE`, no data to the host), hang → `TIMEOUT` after the configured time → backend reset → recovery, `BE_CTRL` reset with a slow request in flight |
| `corruption` | one-bit flips in data and in every field of the protection trailer (guard, NS tag, tenant, LBA tag, version), misdirected read, partial multi-block read; **no corrupted data reaches the host**; stored trailer bytes checked against an independent CRC-32C |
| `reset` | queue reset and fabric soft reset with commands in flight: no late completion, queues disabled, backend ready, everything works afterwards |
| `fairness` | weights, in-flight quotas, token-bucket rate limit, a tenant that stops draining its CQ cannot starve the others, no monopolisation |
| `powerfail` | power-fail warning: admission stops, `GSTATUS` quiesce flag, resumes |
| `pfinflight` | warning with commands waiting for a slow backend: the one at the backend finishes, waiting ones `ABORTED_POWER` (`NBLK_DONE = 0`, data not written), un-admitted ones held and run afterwards |
| `nscfg` | every namespace-configuration refusal reason with exact `NS_STATUS` bits (expectations from the spec, not the RTL), overlap, invalidate-and-reuse |
| `xts` (separate build) | encrypted + PI namespaces, key lifecycle, key words unreadable, ciphertext vs OpenSSL, tampered ciphertext detected, wrong key → no plaintext |
| STORE `random` / `invalid` / `isolation` | the same model-checked tests against the **real P60 chip** (RISC-V firmware, BCH ECC, NAND twin) |
| STORE `powerloss` | cuts chip power (`por_n` and NAND `vcc`) with 17–27 commands in flight, twice per run; reboot, FTL re-mount, then every acknowledged write exact and every unacknowledged block old-or-new |
| host-sw `random` / `invalid` / `isolation` | the same generic tests against the software mailbox backend |
| host-sw `swfail` / `swstall` / `withdraw` | software-reported failures, unresponsive and late software (stale sequence number ignored), withdrawing software (prompt abort, fail-fast `NOT_READY`, recovery with data intact) |
| VirtIO `basic fill random invalid window faults durability concurrent` | see `04_BACKENDS_VIRTIO_NVME.md` §6: whole-disk fill and read-back, random queued traffic with SG splits / misaligned buffers / FLUSH vs a byte-array reference and the backend backdoor, invalid requests, out-of-window buffers (no bus access, victim memory intact), failure / media error / **bit-rot → IOERR**, FLUSH reaching the backend and power loss, native tenants running concurrently |

## 3. Results

Unit level: independent reference-model self-test **489 896 checks, 0 failures**; host library vs mock fabric **10 404 checks, 0 failures**; Verilator `-Wall` lint of the fabric and the three adapters clean; `make example` runs the library tour with 0 bus-monitor violations; vendored P59/P60/P63/P64 trees byte-identical to their originals (`reports/vendor_check.txt`). Tools: Verilator from the PyPI `verilator` 5.48.0 wheel (headers report 5.49), gcc 13.3, OpenSSL 3.0.13.

Every run of the model-driven suites (fabric, STORE, host-software) also checks, at its end, the AXI bus monitor (zero violations) and the model's own consistency report (zero violations); the VirtIO suite has its own guest-DMA monitor (zero violations). Counts below are summed over the seeds listed; the STORE suite is slow (the real RISC-V firmware runs on the simulated chip: 4–27 million simulated cycles per test) so it was run with seed 1 for all four tests and seed 2 for `random`.

**Fabric + simulated block device (`make suite`, seeds 1–3)**

| test | runs (seeds) | checks | failures | commands | simulated cycles |
|---|---:|---:|---:|---:|---:|
| `basic` | 3 | 1671 | 0 | 564 | 1033128 |
| `random` | 3 | 3396 | 0 | 1392 | 926517 |
| `invalid` | 3 | 3619 | 0 | 1679 | 241775 |
| `isolation` | 3 | 816 | 0 | 228 | 458643 |
| `durability` | 3 | 3382 | 0 | 661 | 1283811 |
| `backend_fail` | 3 | 477 | 0 | 141 | 260916 |
| `corruption` | 3 | 543 | 0 | 162 | 238059 |
| `reset` | 3 | 477 | 0 | 102 | 362613 |
| `fairness` | 3 | 384 | 0 | 96 | 8163975 |
| `powerfail` | 3 | 357 | 0 | 102 | 218280 |
| `nscfg` | 3 | 483 | 0 | 105 | 207756 |
| `pfinflight` | 3 | 408 | 0 | 117 | 226233 |
| **total** | | **16013** | **0** | | |

**Optional XTS-AES-256 build (`make suite-xts`)**

| test | runs (seeds) | checks | failures | commands | simulated cycles |
|---|---:|---:|---:|---:|---:|
| `xts` | 1 | 238 | 0 | 30 | 405841 |
| **total** | | **238** | **0** | | |

**Fabric + SilicaFlux-STORE (P60 chip, real firmware, BCH ECC, NAND twin; fresh medium per test)**

| test | runs (seeds) | checks | failures | commands | simulated cycles |
|---|---:|---:|---:|---:|---:|
| `random` | 2 | 877 | 0 | 328 | 25802840 |
| `invalid` | 1 | 1201 | 0 | 557 | 4756251 |
| `isolation` | 1 | 272 | 0 | 76 | 8576084 |
| `powerloss` | 1 | 646 | 0 | 228 | 26735829 |
| **total** | | **2996** | **0** | | |

**Fabric + host-software mailbox backend + software service model**

| test | runs (seeds) | checks | failures | commands | simulated cycles |
|---|---:|---:|---:|---:|---:|
| `random` | 2 | 877 | 0 | 328 | 759764 |
| `invalid` | 2 | 2410 | 0 | 1118 | 175452 |
| `isolation` | 2 | 544 | 0 | 152 | 587284 |
| `swfail` | 2 | 264 | 0 | 78 | 304182 |
| `swstall` | 2 | 266 | 0 | 76 | 447894 |
| `withdraw` | 2 | 288 | 0 | 82 | 300802 |
| **total** | | **4649** | **0** | | |

**VirtIO block path (P63 engine + guest library + adapter; 8 tests per seed, one simulator process per test)**

| seed | tests | checks | failures |
|---|---:|---:|---:|
| 1 | 8 | 2479 | 0 |
| 2 | 8 | 2517 | 0 |
| 3 | 8 | 2493 | 0 |
| **total** | | **7489** | **0** |


## 4. Notes on the three backends

* **Simulated device** — the baseline; every injected fault (device failure, hang, media error, bit corruption, misdirected read, power loss) comes from its sideband. The same fabric RTL is then run unchanged against the other backends; **STORE was integrated only after the fabric passed on the simulated device**, as the brief required.
* **SilicaFlux-STORE** — the real P60 chip: the RISC-V ControlCore executes the firmware image, BCH ECC runs in hardware, the NAND digital twin provides the medium (`--timing` build). Each test starts from a **fresh NAND medium** (`make store-suite` copies the NAND-twin configuration into a clean directory and deletes any previous array file). The power-loss test cuts `por_n` and the NAND `vcc` with 17–27 commands in flight, reboots the chip (the firmware mounts the FTL from the NAND — no re-format of a non-blank medium), re-initialises the adapter, and then requires every acknowledged write to be exact and every other block old-or-new. P60's own regression, formal proofs and benchmarks were **not** repeated.
* **Host software** — see `04_BACKENDS_VIRTIO_NVME.md` §5; the software service model is deliberately a bus-level state machine (one mailbox register access per transaction), so protocol errors in the adapter cannot be masked by a back-door shortcut.
* **VirtIO** — the guest driver is the unmodified P63 C library driving the unmodified P63 engine; the harness implements its `sfv_transport_t` (virtio-mmio window, management window, guest memory and a single-outstanding DMA responder with random back-pressure and latency). Seeds 1–3 vary back-pressure, latency and traffic.

## 5. Defects found by verification (and fixed)

Verification is only credible if it finds things. In order of discovery:

| # | Found by | Defect | Fix |
|---|---|---|---|
| 1 | `random` (hang) | descriptor-parse and CQE-post engines of a queue shared one local-memory client; a grant was credited to the wrong requester | per-requester grant qualification |
| 2 | `isolation` / `random` | valid CQ doorbells were rejected (`DB_ERR`): the doorbell check used the CQ tail, which lags the DMA-visible entries | separate write pointer (`cq_wp`) for visibility |
| 3 | `invalid` | `RESULT0` leaked the payload CRC without `CRC_VALID` | gated on `CRC_VALID` |
| 4 | management tests | write-only registers (e.g. `BE_CTRL`, key words) returned an error response because the read mux decided the access error | read-only/write-only flags decoupled from read decoding |
| 5 | `xts` | key-load race and a stale cached key after a new key was committed | wait for key generation; invalidate on commit |
| 6 | STORE bring-up | init poll deadlock; two drivers on the bounce RAM | poll state added; single writer arbitration |
| 7 | STORE `powerloss` | **a lost backend left commands hanging**: the reset event was delivered only when the backend came back, and commands needing the backend waited for it forever | event delivered when the reset is asserted; commands that need a missing backend fail fast `BACKEND_ERROR / NOT_READY` (mutation 13 re-creates it) |
| 8 | VirtIO `faults` | **adapter deadlock**: a command completed by the fabric with an error before the data move left the adapter waiting for a data request that never came; the guest request hung | adapter consumes an early completion in the data phase and reports an error (mutation 14) |
| 9 | spec review during integration | NS tag encoding stated two ways; key / trace register offsets and `NS_STATUS` bits 4–5 missing; `SOFT_RESET` described wrongly; fetch-failure behaviour unstated | `02_HOST_INTERFACE.md` corrected; the model follows the corrected text |
| 10 | mutation testing | surviving mutants 10 (power-fail admission) and 12 (namespace overlap) exposed missing tests and a model that did not know the overlap rule | tests `pfinflight` and `nscfg` added; model extended |
| — | STORE random test | *false alarm*: "garbage returned for never-written LBAs" was stale data from a previous run in the NAND twin's persisted array | none needed in RTL; every STORE run now starts from a fresh medium; the sidecar "written map" built on the false premise was removed |

## 6. Mutation testing

`scripts/mutate.py` copies the tree, plants **one** bug, rebuilds, runs a fast test subset (tests ordered fast-first; the first failing test kills the mutant, a hang counts as a kill via a hard timeout). The project tree is never modified.

| # | planted bug | killed by |
|---|---|---|
| 1 | validation: tenant-claim check removed | `invalid` |
| 2 | validation: namespace-ownership check removed | `invalid` |
| 3 | validation: LBA range check off by one | `invalid` |
| 4 | validation: read-only namespace accepts WRITE | `invalid` |
| 5 | durability: WRITE completion always claims durable | `isolation` |
| 6 | integrity: CRC-32C guard never compared | `corruption` |
| 7 | integrity: LBA tag never compared (misdirected reads) | `corruption` |
| 8 | isolation: DMA issued in the wrong protection domain | `invalid` |
| 9 | durability: FUA no longer forces a backend flush | `corruption` |
| 10 | PowerSafe: admission not stopped on power-fail warning | `pfinflight` |
| 11 | timeout: fires 4000 cycles late | `backend_fail` |
| 12 | management: overlapping namespaces accepted | `nscfg` |
| 13 | robustness: no fail-fast when the backend is gone | `withdraw(timeout)` |
| 14 | VirtIO adapter: early (error) completion never consumed | `faults(timeout)` |
| 15 | timeout: the command that timed out reports ABORTED_RESET | `backend_fail` |
| 16 | host-sw adapter: stale commit (old sequence number) accepted | `swstall` |

**16 of 16 mutants killed.** Two mutants (13: no fail-fast on a missing backend; 14: VirtIO adapter never consumes an early completion) are *hangs* by nature and are detected by a hard wall-clock timeout (240–300 s without the test finishing) — which is itself the failure the bug causes. In the first mutation round two mutants (10: power-fail admission; 12: namespace overlap) **survived**; that is how the `pfinflight` and `nscfg` tests came to exist, and both are now killed.

Not covered by mutation testing: the scheduler's fairness policies (their evidence is the benchmark tables, which describe behaviour, not correctness), CloudDMA and the other vendored blocks (not modified, not mutated), the host library and model (they are oracles, not the design under test).

## 7. What this verification does not cover

* No formal verification of P68 RTL, no line / toggle / functional-coverage measurement (test counts are the only quantitative coverage), no X-propagation analysis (Verilator is two-state; registers are randomly initialised with `--x-initial unique`), no clock-domain or reset-domain crossing analysis (single clock), no gate-level simulation.
* Three seeds per suite for the fabric and VirtIO paths, two (one for most tests) for the real-chip STORE path; no long soak run.
* The STORE suite uses one NAND-twin configuration (`ideal`: no injected raw bit errors or bad blocks); P60's own ECC and bad-block campaigns are P60's claims and were not repeated. A `nominal` configuration is shipped but was not run.
* Back-pressure and latency randomisation are bounded (the harness AXI slave, the VirtIO DMA responder); pathological interconnects (reordering, split transactions beyond what CloudDMA issues) are not modelled.
* The independence of the model and library is organisational (separate author, spec-only), not formal; ambiguities they exposed are in `model/SPEC_QUESTIONS.md` with their resolutions.
