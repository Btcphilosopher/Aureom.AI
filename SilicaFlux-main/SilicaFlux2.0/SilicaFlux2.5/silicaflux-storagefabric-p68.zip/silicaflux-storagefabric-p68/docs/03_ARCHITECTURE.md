# 03 — Architecture

Primary RTL: `rtl/silicaflux_storage_fabric.sv` (Aureom.AI | SilicaFlux-CLOUD, Project 68 StorageFabric).
The normative host ABI (descriptor, completion, status codes, durability rules, register maps) is `02_HOST_INTERFACE.md`; this document explains how the
RTL implements it and why.

## 1. Pipeline

```
 tenant memory (SQ ring, data, CQ ring)                       tenant MMIO page (function id bound in hardware)
          │  protected DMA (P64 CloudDMA, per-domain permission table)         │
          ▼                                                                    ▼
  ┌──────────────┐   ┌────────────┐   ┌───────────────┐   ┌─────────────┐  ┌──────────────┐  ┌──────────┐  ┌─────────────┐
  │ queue        │──►│ validation │──►│ scheduler     │──►│ command slot│─►│ protected DMA│─►│ transform│─►│ backend     │
  │ sf_stor_queue│   │ (12 rules) │   │ DRR · quota · │   │ ×NSLOT      │  │ host ↔ staging│ │ CRC-32C PI│  │ contract    │
  │ fetch · CQ   │   └────────────┘   │ token bucket  │   │ sf_stor_slot│  │ sf_stor_dmaseq│ │ (XTS opt.)│  │ sf_stor_mover
  └──────▲───────┘                    │ rd-prio · wr  │   └──────┬──────┘  └──────────────┘  └──────────┘  └──────┬──────┘
         │ completion (CQE + phase)   │ batch · FLUSH │          │ completion: status · detail · durable · nblk_done · latency
         └────────────────────────────┴── barriers ───┴──────────┘                                                  │
   ext source (VirtIO adapter) ──► sf_stor_extq (one hardware-bound pseudo-tenant, data via the staging memory) ─────┘
                                                                                                                   ▼
        backend adapters (one per build):  simulated block device │ SilicaFlux-STORE driver │ host-software mailbox │ (NVMe: future)
```

Write path: host buffer → domain validation → optional encryption → integrity metadata → backend → durable completion.
Read path: backend → verify integrity → optional decryption → host buffer → completion.
No step is skipped and no command bypasses validation, including the VirtIO path.

## 2. Modules

| Module | Responsibility |
|---|---|
| `silicaflux_storage_fabric` | top: selects the backend, exposes tenant MMIO, privileged management MMIO, the AXI4 master (domain / asid sidebands), per-tenant IRQ, `pf_warn_i` |
| `sf_stor_queue` ×NT | tenant register page, SQ fetch (batches of `SQ_BATCH` descriptors through CloudDMA), descriptor parse, head FIFO, CQE build and posting with a phase bit, doorbell / geometry checks, queue FATAL handling |
| `sf_stor_validate` | the 12 ordered checks of ABI §2 (version, opcode, tenant claim, reserved, flags, namespace ownership, capability, read-only, length, alignment, range, key readiness) |
| `sf_stor_sched` | admission: DRR with weights, per-tenant in-flight quota, token bucket, reserved slot for tenants with work, optional read priority with bounded write aging, optional write batching, FLUSH / overlap barriers |
| `sf_stor_slot` ×NSLOT | one in-flight command (FSM), per-slot timeout timer, completion record (durability copied from the backend completion) |
| `sf_stor_dmaseq` | sequences every host-memory transfer onto P64 CloudDMA channels (SQ fetch, CQ write, payload in / out); the only block that issues host addresses |
| `sf_stor_xform` | CRC-32C guard, protection-information trailer build / verify, payload CRC (`HCRC` / `RCRC`), optional XTS-AES-256 |
| `sf_stor_mover` | moves unit streams between the staging memory and the backend contract; one job at a time |
| `sf_stor_lmem`, `sf_stor_lm_arb`, `sf_stor_axi_lmem`, `sf_stor_axi_xbar` | 64-bit staging memory (`NSLOT × MDTS × 528 B` plus queue buffers), port-B arbitration, AXI plumbing between CloudDMA and the staging memory (asid 1) and tenant memory (asid 0) |
| `sf_stor_mgmt` | privileged window: global control, tenant config, namespaces, DMA windows, backend info / reset, keys, performance counters, trace FIFO |
| `sf_stor_extq` | the extra command source for the VirtIO adapter (hardware-fixed tenant id `EXT_TENANT`) |
| `sf_stor_be_simdev` | simulated block device (baseline backend, fault injection) |
| `adapters/sf_stor_be_store` · `sf_stor_be_hostsw` · `sf_stor_virtio_adapter` | backend adapters and the VirtIO front-end adapter (`04_BACKENDS_VIRTIO_NVME.md`) |

## 3. Isolation: how a tenant is confined (and what checks it)

| Mechanism | Where | Independent check |
|---|---|---|
| The tenant id of a queue is the **hardware function id** of the MMIO access — never a descriptor field. `TENANT_CLAIM` in the descriptor must equal it (rule 3) | `sf_stor_queue`, `sf_stor_validate` | model + `invalid` / `isolation` tests; mutation 1 |
| A namespace belongs to one tenant; a command naming another tenant's namespace is `INVALID_NS` | `sf_stor_validate` | mutation 2; `nscfg` |
| Namespaces cannot overlap; refusal leaves the namespace invalid | `sf_stor_mgmt` | `nscfg`; mutation 12 |
| Every host-memory access goes through CloudDMA with `domain = tenant id`; the per-domain permission table is programmed by the hypervisor only | `sf_stor_dmaseq`, P64 | testbench AXI monitor re-checks every beat against the windows it saw programmed; mutation 8 |
| The local (staging) memory is asid 1 and can never reach the host port | `sf_stor_axi_xbar` | monitor fails any asid-1 beat on the host port |
| A backend never sees a tenant address; it only sees namespace-window LBAs chosen by the fabric | `sf_stor_core` | STORE adapter bounce RAM; VirtIO suite checks that every backend LBA outside the guest's namespace stays untouched |
| The management window is separate from tenant pages | top | tenant page decode tests |
| VirtIO guest: the engine's own permission windows bind the guest to its memory; the adapter binds the device to one namespace (`VNS`) | P63 + adapter | VirtIO `window` / `isolation` checks, independent DMA-window monitor |

## 4. Command lifecycle and ordering

Descriptors of one queue start in submission order and may complete out of order (TXN_ID). Overlapping ranges where either side writes are serialised; FLUSH is a
barrier for its queue. Per slot: `IDLE → (WDMA → WDMAW) → (XW → XWW) → BE → BEWAIT → (XR → XRW) → (RDMA → RDMAW) → FIN`. A failed validation completes immediately
without touching backend or buffers. A queue reset abandons its commands silently (no CQE) at the next safe point.

## 5. Scheduler (baseline fair policy)

* **Fairness:** Deficit Round Robin; quantum = tenant `WEIGHT` blocks; cost = blocks (1 for FLUSH/DISCARD).
* **Isolation of capacity:** per-tenant `MAX_INFLIGHT`; a *reserved slot* rule — slots are never all consumed by tenants that already hold one while another enabled tenant with work holds none; a tenant that stops draining its CQ cannot starve the others.
* **Rate limiting:** token bucket (blocks per 1024 cycles, burst depth); may go negative by one command; `throttle` cycles are counted.
* **Read prioritisation / write batching:** optional (`GCTRL.RD_PRIO`, `GCTRL.WR_BATCH`); a write can be bypassed by reads at most `WR_AGE_MAX` times, so writes cannot starve; batching stays with a tenant for at most `WR_BATCH_MAX` consecutive writes.
* **Admission control & back-pressure:** a command is admitted only when a slot is free and every rule above holds; otherwise it stays in its tenant's head FIFO, which back-pressures descriptor fetch, which back-pressures the SQ (`SFS_E_FULL` in the library). One admission per two cycles.
* Measured behaviour (policy comparison, noisy neighbour, weights) is in `06_BENCHMARKS.md`. No claim of optimality is made.

## 6. Backends and what the fabric does to the data for each

All backends implement the same contract (`02_HOST_INTERFACE.md` §7): request / write-data / read-data / completion channels with units of 512 B or 528 B,
capabilities `PI_NATIVE`, `VOLATILE_CACHE`, `DISCARD`, `DISCARD_ZERO`, `READONLY`, per-unit flags `ERR` / `UNMAPPED`, and a reset pulse.

| | Simulated block device | SilicaFlux-STORE (P60) | Host-software mailbox | VirtIO block front end | NVMe adapter |
|---|---|---|---|---|---|
| Role | backend, baseline | backend | backend | *front end* (guest-facing) feeding the fabric's ext source | **future** backend |
| Unit | 528 B (PI-native) or 512 B | 512 B (not PI-native) | 528 B (PI-native, stored verbatim by the software) | 512 B sectors → fabric blocks (`sf_stor_virtio_adapter`) | — |
| PI trailer (CRC-32C guard, NS tag, LBA tag, version) | stored in the 16 spare bytes | **not stored**: a namespace with `PI_EN` is refused (`NS_STATUS` bit 2); the chip's own BCH + CRC-16 + FTL CRC protect the medium. `HCRC` (host data CRC) still available | stored by the software as opaque bytes | follows the namespace flags of `VNS` | — |
| Encryption (optional XTS-AES-256) | tweak = backend-absolute LBA, unit = data ‖ trailer | P60 has its own XTS at rest (not used by the adapter); fabric XTS is independent | works (unit is opaque) | works if `VNS` has `ENC_EN` | — |
| Volatile cache | yes (bounded write-back cache, configurable) | no (P60 acknowledges durably) — **inherited, not proven here** | software decides, reports `durable` per completion | via the namespace | — |
| `DURABLE` source | backend completion | backend completion = chip CQE success | software's `CPL_FLAGS.durable` | not exposed to the guest (virtio has FLUSH only) | — |
| DISCARD | yes, zero-fill | yes (P60 TRIM) | yes (software erases), zero-fill | not offered (virtio feature absent → `UNSUPP`) | — |
| Concurrency | queue depth QD in the model | one command at a time | one request at a time (mailbox) | one sector op at a time, combined per sector | — |
| Failure injection | full sideband (fail, hang, media, corruption, misdirect, power loss) | chip power cut (`por_n`, NAND `vcc`) | software service model (fail, media error, stall, withdraw) | via the simulated device behind it | — |

## 7. Durability and PowerSafe coordination

* `DURABLE` in a CQE is **copied from the backend completion**. Data that entered the fabric's staging SRAM is never counted as durable.
* `FLUSH` completes only when the backend reports that everything it accepted is persistent; a backend that answers a FLUSH with `durable = 0` makes the command fail (`BACKEND_ERROR`, detail 14).
* `FUA` on a volatile-cache backend: the write is followed by an internal backend flush and completes with `DURABLE = 1`, or fails — never completes early.
* **Power-fail warning** (`pf_warn_i` or `PF_CTRL`): fetch and admission stop; commands already at the backend finish (their durability is whatever the backend reports); commands admitted but not yet at the backend complete `ABORTED_POWER` with `NBLK_DONE = 0` (data **not** written); un-admitted commands are held, not lost, and run after the warning is withdrawn; `GSTATUS` bit 1 / `pf_quiesced_o` report the quiesce. Verified by `powerfail` and `pfinflight`.
* **Backend loss** (`be_ready` falls, timeout, `BE_CTRL.RESET`, `SOFT_RESET`): the reset event is delivered when the reset is *asserted* (not when the backend comes back): commands waiting on the backend complete `ABORTED_RESET` (`TIMEOUT` for the one that timed out), and a command that needs a missing backend fails **fast** with `BACKEND_ERROR / NOT_READY` — tenants never hang on a dead backend (found by the STORE power-loss test; mutation 13).
* The STORE backend's durability rests on P60's "no volatile write cache" contract. P60 documents that its completion path trusts the firmware; P68 does not and cannot prove this. P60's own crash campaigns (claimed) and P68's power-cut test (acknowledged writes survive, unacknowledged blocks are old-or-new) are the evidence. **There is no PLP hardware, no capacitor model, and no silicon.**

## 8. Timeouts, errors and integrity

* **Timeout:** `CMD_TIMEOUT` (cycles, 0 = off) bounds a command at the backend; expiry completes the command `TIMEOUT` and resets the backend, which aborts the other waiting commands.
* **Backend error propagation:** the backend status (`MEDIA_ERR`, `DEV_ERR`, `RANGE`, `RO`, `UNSUPPORTED`, `NOT_READY`, `RESET`) maps to the ABI status with the backend code in `DETAIL`; `NBLK_DONE` reports the leading good blocks; **no data reaches the host buffer on a failed READ**.
* **Length validation:** rule 9 (zero / too large / not matching `NBLK × 512` / non-zero where forbidden), alignment (rule 10), range with 65-bit overflow-safe arithmetic (rule 11).
* **Integrity:** every READ of a PI namespace verifies guard (CRC-32C of the 512 plaintext bytes), NS tag (`NSID | TENANT << 8`), LBA tag (48-bit namespace-relative) and format version; any mismatch → `INTEGRITY` with a detail code, and the data is not delivered. A misdirected read, a stale block, a wrong namespace and a one-bit flip are all caught (test `corruption`, mutations 6 and 7).
* **Optional host CRC:** `HCRC` makes the fabric check a CRC-32C supplied in the descriptor over the payload *before* the write (`DATA_CRC`); `RCRC` returns the payload CRC in the CQE. **CRC-32C is an error-detection code, not authentication**; XTS-AES provides confidentiality at rest, **not authentication** either (the trailer's guard detects accidental or random corruption, not forgery).

## 9. Performance counters and trace

32 global 64-bit counters (`PC_*`, `PERF_SEL/LO/HI`): cycles, commands done / error, reads / writes / flushes / discards, blocks, bytes, DMA-in / DMA-out active cycles, DMA bytes (CloudDMA's own pulse counter — benchmarks use the testbench's independent AXI byte count instead), backend busy cycles, **backend stall cycles** (the mover wanted to move a beat), queue-wait integral, slot occupancy integral, isolation violations, rejects, integrity / media errors, timeouts, DMA faults, aborts, throttle cycles, transform cycles, fetched descriptors, CQ posted / CQ stall cycles, power-fail events, CRC errors, backend resets. Per-tenant counters (`done`, `err`, read / write blocks, flushes, throttle, violations, bytes) live in each tenant page. A 64-record trace FIFO (`TR_*`) timestamps every command at fetch / admit / backend issue / backend done / post, which is where **queue wait** (admit − fetch) comes from. Percentiles reported in `06_BENCHMARKS.md` are computed from samples actually collected (CQE latency fields and trace records), never estimated.

## 10. What is *not* here

No PCIe endpoint or SR-IOV, no NVMe initiator, no NVMe-oF, no hardware PLP, no multi-queue VirtIO, no packed virtqueue, no tenant-visible DISCARD on the VirtIO path, no FPGA / silicon evidence. See `07_LIMITATIONS.md`.
