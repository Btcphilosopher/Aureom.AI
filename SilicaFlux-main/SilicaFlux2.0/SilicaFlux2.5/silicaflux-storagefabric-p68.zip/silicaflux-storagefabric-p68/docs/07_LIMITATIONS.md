# 07 — Limitations and honesty ledger

This is everything P68 does **not** show. It is meant to be read before any number in `06_BENCHMARKS.md` or any claim in the README.

## Evidence level

* **Simulation only.** Verilator 5.48 cycle-accurate RTL simulation with C/C++ testbenches. **No FPGA, no silicon, no place-and-route, no timing closure, no power or area numbers, no gate-level or formal verification of P68 RTL.** (P60's formal proofs are P60's.)
* **All performance numbers are in fabric clock cycles** on a simulated block device with a deterministic, low-jitter latency model. There is **no frequency, no wall-clock, and no real-media latency distribution**. A p99 here is a p99 of that model; with near-deterministic service times it sits next to the median and says nothing about a production tail.
* The testbench's AXI4 memory slave is an ideal-ish model (fixed 4-cycle latency, configurable back-pressure). Real interconnect, IOMMU and DRAM effects are absent.

## What is not implemented

| Item | State |
|---|---|
| NVMe hardware backend adapter | **not written** (documented as future, `04_BACKENDS_VIRTIO_NVME.md` §4). No PCIe root complex or NVMe initiator exists in the repository |
| NVMe-oF | **not claimed**; no transport |
| PCIe endpoint / SR-IOV | not implemented; the tenant "function id" is an abstract hardware binding on the MMIO port |
| P61 CloudDPU integration | **documented, not performed** (`08_P61_INTEGRATION.md`); P61 is unmodified and still refuses `OP_STORAGE` |
| VirtIO | one queue, split ring only, no indirect / packed / multiqueue, no DISCARD / WRITE_ZEROES; one outstanding DMA (P63's deliberate v1 choice) |
| Backend concurrency | STORE and host-software adapters serve one command at a time; the VirtIO adapter one sector operation at a time |
| Command size | `MDTS` = 8 blocks (4 KiB) per command |
| Tenants / slots | `NT` = 4, `NSLOT` = 8, `NS_N` = 8 (elaboration parameters; larger values were not explored) |

## Durability, integrity, security claims and their limits

* **Durability of the STORE backend is inherited from P60's "no volatile write cache" contract**, which itself rests on P60's firmware completion path (P60 limitation: *the completion path trusts the firmware*). P68's power-cut test shows that acknowledged writes survived the chip power cuts it injected (two per run, with 17–27 commands in flight) in simulation; it is not a proof. **There is no PLP hardware, no capacitor/energy model and no real NAND.**
* **The simulated device's cache model is a model.** "Any subset of unflushed blocks survives, each block atomically" is the assumption encoded in the reference model and the device; real devices can tear writes in other ways (partial pages, shorn writes) that are not modelled.
* **A multi-block WRITE is not atomic** (each 512 B block is all-old or all-new; `NBLK_DONE` reports the leading good blocks). A VirtIO request that fails part-way may leave earlier sectors written (the VirtIO specification allows it).
* **CRC-32C is error detection, not authentication.** The protection-information trailer detects accidental corruption, misdirected and stale reads; it does not stop a forger who can write the medium (they can compute a valid trailer).
* **XTS-AES-256 provides confidentiality at rest, not authentication or integrity** (malleability at 16-byte granularity); here the guard inside the encrypted unit detects random tampering with probability 1 − 2⁻³² per block, nothing more. Key handling: write-only key registers, staging wiped on commit; there is no key hierarchy, rotation, or side-channel analysis. The vendored XTS engine is P59's; its constant-time / power-analysis properties are not assessed.
* **Isolation evidence is simulation-based.** An independent bus monitor checked every AXI beat against the windows the hypervisor programmed (zero violations in every run) and mutation tests show the checks have teeth; this is not a proof of isolation and does not cover side channels (timing, shared-scheduler interference is *measured* in `06_BENCHMARKS.md`, not eliminated).
* The reference model and the C host library were written by an independent agent from `02_HOST_INTERFACE.md` only; independence is organisational, not formal. Spec ambiguities found are listed in `model/SPEC_QUESTIONS.md`. The model was later extended with two refusal reasons (`NS_STATUS` bits 4 and 5) after a surviving mutation showed that the original spec text did not cover them.

## Known behavioural gaps and design caveats

* **Scheduler weights are not exact proportional shares at saturation** (observed 1 : 1 : 1.7 : 2.9 for weights 1 : 1 : 2 : 4); write batching hurt read latency and fairness in the mixed workload; read priority improves read latency at a large write-latency cost. See `06_BENCHMARKS.md`. No optimality claim.
* **Throughput is capped by the single transform engine** (≈ 3.8 B/cycle for 4 KiB reads at QD ≥ 4, transform engine 95 % busy): a baseline design choice, not a fundamental limit; parallel CRC lanes or a pipelined transform would raise it. Backend latency barely matters in this regime.
* The VirtIO adapter holds one sector and treats the fabric as its only writer; it is not invalidated by management writes (reset the device when reconfiguring `VNS`).
* The host-software mailbox accepts data-window writes only while a request is pending, but trusts the software for correctness of what it stores; a malicious software backend can return wrong data, which the namespace's protection information (not available when the software disables PI) would detect.
* If `be_ready` drops, commands waiting on the backend complete `ABORTED_RESET` and new ones `BACKEND_ERROR / NOT_READY`; the fabric does **not** retry. Retry policy is the host's.
* `CMD_TIMEOUT` bounds time at the backend (`BEWAIT`) only; a command stuck in DMA is bounded by the DMA engine's own error handling.
* Vendored third-party RTL (P59 / P60 / P63 / P64) is included **unmodified** and hashed (`third_party/MANIFEST.sha256`); their licence terms are not stated in the source trees — treat redistribution as unresolved until the owner confirms.

## Environment notes

* The NAND digital twin persists its array in `<NANDLAB_DIR>/target0.nlsf`. `make store-smoke` / `store-suite` start every test from a fresh copy of the configuration; a stale file from a previous run corrupts the comparison with the reference model (this once looked like a controller defect — it was not).
* P60 was built as chip + NAND twin with a C++ harness; its own full testbench (≈ 5 GB, > 25 min to build) was not rebuilt.
