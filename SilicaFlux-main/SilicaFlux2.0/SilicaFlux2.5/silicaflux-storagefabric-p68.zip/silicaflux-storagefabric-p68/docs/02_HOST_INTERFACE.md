# 02 — Host interface (ABI v1.0): descriptors, completions, registers, semantics

This document is **normative**. The RTL (`rtl/silicaflux_storage_fabric_pkg.sv`, `rtl/sf_stor_queue.sv` / `rtl/sf_stor_mgmt.sv`), the host library
(`host/include/sfstor.h`) and the independent reference model (`model/sfref.hpp`) are all written from it. Where the
three disagree with this text, the text wins and the disagreement is a bug.

All multi-byte values are **little-endian**. A descriptor or completion is an array of 32-bit words; word *n* is the
bytes `4n..4n+3`; a 64-bit field is two words, low word first.

## 1. Model

```
 tenant (VM / function)                      privileged software (hypervisor / ControlCore)
   │  tenant MMIO page (hardware-bound)        │  management window (never mapped into a tenant)
   │  SQ ring + CQ ring in tenant memory       │  namespace table, quotas, DMA windows, keys, backend control
   ▼                                           ▼
 ┌──────────────────────── silicaflux_storage_fabric ────────────────────────┐
 │ queue pair t → descriptor fetch → validate → per-tenant pending queue      │
 │   → fair scheduler (quota, DRR, read priority, write batching, barriers)   │
 │   → command slot → protected DMA (host ⇄ local buffer) → data integrity    │
 │   → [optional XTS-AES] → backend adapter → durable/volatile completion     │
 └────────────────────────────────────────────────────────────────────────────┘
```

* A **tenant** is a hardware-bound queue pair (index `t`, `0 ≤ t < NT`). The platform binds a PCIe function / VF to
  `t`; the fabric takes `t` from that binding (`tmmio_fn` for MMIO, the queue index for DMA). **Nothing a tenant writes
  chooses its tenant id.** The descriptor field `TENANT_CLAIM` is only a *claim* and is compared with the binding.
* A **namespace** (`NSID`) is a window of the backend's logical block space, owned by exactly one tenant. A tenant
  addresses blocks by *namespace-relative* LBA; the fabric adds the namespace base. **There is no physical addressing:**
  no field of a descriptor can name a backend-absolute block, a physical page or a backend queue.
* Logical block size is **512 bytes**. Maximum transfer (`MDTS`) is `MDTS_BLOCKS` blocks (default 8 = 4 KiB).
* Reading an NSID that does not exist and reading one that belongs to someone else are indistinguishable
  (`INVALID_NS`), so a tenant cannot probe for other tenants' namespaces.

## 2. Submission descriptor (64 bytes, ring entry in tenant memory, 64-byte aligned)

| Word | Bits | Field | Rule |
|---|---|---|---|
| 0 | [7:0] | `VERSION` | must be `1`, else `INVALID_FIELD` (detail `VERSION`) |
| 0 | [15:8] | `OPCODE` | `01` WRITE · `02` READ · `03` FLUSH · `04` GET_CAPACITY · `05` DISCARD (optional) · all else `INVALID_OPCODE` |
| 0 | [31:16] | `FLAGS` | bit0 `FUA` · bit1 `HCRC` · bit2 `RCRC` · bits 3..15 reserved, must be 0 |
| 1 | [15:0] | `TXN_ID` | chosen by software; echoed in the completion; the fabric never interprets it |
| 1 | [23:16] | `NSID` | namespace id |
| 1 | [31:24] | reserved | must be 0 |
| 2,3 | [63:0] | `LBA` | namespace-relative first block |
| 4 | [31:0] | `NBLK` | blocks, 1-based. READ/WRITE/DISCARD: 1..MDTS (DISCARD: 1..`DISCARD_MAX` = 65535). FLUSH, GET_CAPACITY: must be 0 |
| 5 | [31:0] | `DATA_LEN` | bytes. READ/WRITE: must equal `NBLK*512`. Others: must be 0 |
| 6,7 | [63:0] | `DATA_ADDR` | tenant IOVA of the data buffer. READ/WRITE: 4-byte aligned. Others: must be 0 |
| 8 | [15:0] | `TENANT_CLAIM` | must equal the hardware binding, else `TENANT_MISMATCH` (isolation violation, counted) |
| 8 | [31:16] | reserved | must be 0 |
| 9 | [31:0] | `HOST_CRC` | CRC-32C of the payload, meaningful only with `HCRC` (WRITE only); must be 0 otherwise |
| 10–15 | | reserved | must be 0 |

Flags: `FUA` — completion is not posted until the data is durable (`CQE.DURABLE = 1`); on a backend with a volatile
cache the fabric issues an internal FLUSH after the write. `HCRC` — WRITE only: the fabric computes the CRC-32C of the
staged payload and fails the command with `DATA_CRC` if it differs from `HOST_CRC`; nothing reaches the backend.
`RCRC` — READ/WRITE: the completion carries the CRC-32C of the payload that was transferred (`CRC_VALID = 1`).

**Validation order** (first failing rule determines the status; all rules are evaluated in hardware before any
backend or data-DMA activity; a rejected command moves no data):
1. `VERSION` → `INVALID_FIELD`/`VERSION`
2. `OPCODE` → `INVALID_OPCODE`
3. `TENANT_CLAIM` ≠ binding → `TENANT_MISMATCH`
4. reserved bits/words non-zero, flag/opcode combination illegal (`HCRC` on non-WRITE, `FUA` on non-WRITE, `RCRC` on non-data ops) → `INVALID_FIELD`/`RESERVED` or `FLAGS`
5. `NSID` not valid or not owned by the tenant → `INVALID_NS`
6. opcode needs a capability the namespace/backend lacks (`DISCARD` unsupported) → `UNSUPPORTED`
7. WRITE/DISCARD to a read-only namespace → `NS_READONLY`
8. `NBLK` / `DATA_LEN` rules → `LEN_ERROR` (detail `ZERO`, `TOO_LARGE`, `MISMATCH`, `NOT_ZERO`)
9. `DATA_ADDR` alignment / must-be-zero → `INVALID_FIELD`/`ADDR_ALIGN`
10. range: `LBA + NBLK ≤ NS_SIZE` evaluated without overflow in 65-bit arithmetic → `LBA_RANGE`
11. encryption required (`ENC_EN`) but key slot not ready → `CRYPTO_ERROR`/`KEY_NOT_READY`

## 3. Completion entry (32 bytes, ring entry in tenant memory, 32-byte aligned)

| Word | Bits | Field |
|---|---|---|
| 0 | [15:0] | `TXN_ID` (echo; `0xFFFF` if the descriptor could not be read) |
| 0 | [23:16] | `STATUS` (§4) |
| 0 | [31:24] | `DETAIL` (§4) |
| 1 | [0] | `DURABLE` — the data covered by this completion is on persistent media |
| 1 | [1] | `PI_VERIFIED` — end-to-end protection information was verified (READ) / generated (WRITE) |
| 1 | [2] | `ENCRYPTED` — the data is stored encrypted |
| 1 | [3] | `CRC_VALID` — `RESULT0` holds the payload CRC-32C |
| 1 | [15:8] | `OPCODE` (echo) |
| 1 | [31:16] | `NBLK_DONE` — blocks completed (full transfer on success; on error the count of blocks that were fully processed before the error) |
| 2 | [31:0] | `RESULT0` — payload CRC-32C if `CRC_VALID`; GET_CAPACITY: capacity bits 31:0 |
| 3 | [31:0] | `RESULT1` — GET_CAPACITY: capacity bits 63:32 (blocks); else 0 |
| 4 | [15:0] | `SQ_HEAD` — the fabric's consumer index when this entry was built (host may reuse SQ slots below it) |
| 4 | [31:16] | `TENANT` — hardware-stamped tenant id |
| 5 | [31:0] | `LATENCY` — fabric cycles from descriptor fetch complete to completion posted |
| 6 | [31:0] | reserved (0) |
| 7 | [0] | `PHASE` — toggles each time the CQ wraps; starts at 1 |
| 7 | [31:1] | reserved (0) |

The entry is written with one DMA transfer in increasing address order. **The host must read word 7 (PHASE) first and
only then the remaining words** (acquire ordering), and may consume the entry only when `PHASE` equals its expected
phase. After consuming entries the host writes `CQ_HEAD`.

On error `DURABLE = 0` unless the status text below says otherwise. A write that fails never reports `DURABLE`.

## 4. Status and detail codes

| STATUS | Name | Meaning / DETAIL |
|---|---|---|
| `00` | `SUCCESS` | detail 0 |
| `01` | `INVALID_OPCODE` | |
| `02` | `INVALID_FIELD` | detail: 1 `VERSION`, 2 `RESERVED`, 3 `FLAGS`, 4 `ADDR_ALIGN` |
| `03` | `INVALID_NS` | nonexistent **or** not owned (not distinguishable) |
| `04` | `LBA_RANGE` | |
| `05` | `LEN_ERROR` | detail: 1 `ZERO`, 2 `TOO_LARGE`, 3 `MISMATCH`, 4 `NOT_ZERO` |
| `06` | `TENANT_MISMATCH` | isolation violation |
| `07` | `NS_READONLY` | |
| `08` | `DMA_FAULT` | permission/domain/range refusal by the DMA protection checker; detail = CloudDMA `FAULT` code (1 NO_MAP, 2 PERM, 3 DOMAIN, 4 RANGE …); no byte moved outside the tenant's windows |
| `09` | `DMA_ERROR` | bus error / protocol / DMA timeout; detail = CloudDMA `ERR` code |
| `0A` | `DATA_CRC` | host CRC (`HCRC`) mismatch |
| `0B` | `INTEGRITY` | end-to-end protection information failed on READ; detail: 1 `GUARD`, 2 `LBA_TAG`, 3 `NS_TAG`, 4 `FORMAT` |
| `0C` | `MEDIA_ERROR` | backend reported an unrecoverable media error; detail = backend code |
| `0D` | `BACKEND_ERROR` | backend failed/unavailable/refused; detail = backend code (§7) |
| `0E` | `TIMEOUT` | command timeout expired; detail 1 = backend, 2 = DMA |
| `0F` | `ABORTED_RESET` | queue/fabric/backend reset while the command was in flight |
| `10` | `ABORTED_POWER` | power-fail quiesce; the command was not (fully) executed |
| `11` | `UNSUPPORTED` | opcode valid, capability absent (e.g. DISCARD on a backend without it) |
| `12` | `CRYPTO_ERROR` | detail 1 `KEY_NOT_READY`, 2 `ENGINE` |
| `13` | `INTERNAL` | should not happen; detail = fabric state code |

A command that fails *before* execution (validation) never touches backend or data buffers. A command that fails
*during* execution may have written some blocks: **a multi-block WRITE is not atomic**; each 512-byte block is
all-old or all-new. `NBLK_DONE` tells the host how many leading blocks were fully processed.

## 5. Ordering, barriers and durability (normative)

1. Descriptors from one queue are **started in submission order**. They may **complete out of order** (TXN_ID matches
   them up). Commands of one queue that touch an overlapping block range, where at least one is a write or discard,
   are **serialised in submission order** (a later one does not start until the earlier one has completed). Commands
   from different tenants are independent (different namespaces cannot overlap).
2. **FLUSH** starts only after every earlier command of the same queue has completed, then flushes the backend, and
   completes `SUCCESS` with `DURABLE = 1` only when the backend reports that everything it had accepted is persistent.
   Later commands of the queue do not start until the FLUSH has been issued.
3. **WRITE** completes `SUCCESS` when the backend has accepted the data. `DURABLE = 1` iff the backend reported the data
   persistent (write-through / non-volatile) at completion. A WRITE with `DURABLE = 0` is only guaranteed durable after
   a later `FLUSH` (of the same queue) completes `SUCCESS`. A WRITE with `FUA` is never completed before it is durable:
   if the backend reports `DURABLE = 0` the fabric flushes the backend internally and completes with `DURABLE = 1`,
   or fails the command (`BACKEND_ERROR`).
4. **The fabric never reports `DURABLE = 1` because data entered one of its own buffers.** `DURABLE` is copied from the
   backend completion; the fabric's SRAM is volatile and is never counted.
5. **Power loss.** After a power loss and backend recovery, every block of a command that completed with `DURABLE = 1`
   (or was covered by a later successful FLUSH) holds exactly that data (or a later write's data). A block written
   with `DURABLE = 0` and not flushed holds any version of that block written since its last durable version (a
   volatile cache may have flushed any prefix of its history). No block holds data that was never written to it.
6. **DISCARD** (when supported): after completion every discarded block reads as zeros. Not durable until flushed
   (`DURABLE` follows the same rule as WRITE).
7. **READ of a never-written (or discarded) block returns zeros** with `SUCCESS` (and `PI_VERIFIED = 0` for that
   block).

## 6. Data transformations

Applied identically to all backends, selected per **namespace** by `NS_CTRL`:

| Namespace flag | WRITE | READ |
|---|---|---|
| `PI_EN` | compute a 16-byte protection trailer per block (§6.1) and store it with the block | verify the trailer; mismatch → `INTEGRITY`, **no data is returned to the host** (the host buffer is not written) |
| `ENC_EN` | XTS-AES-256 encrypt each unit (data, plus trailer if `PI_EN`) with the namespace's key slot; tweak = backend-absolute LBA | decrypt before verification |
| neither | data stored as is | data returned as is |

`PI_EN` requires a backend that stores 528-byte units (capability `PI_NATIVE`). Configuring `PI_EN` on a backend
without it is **refused** (the namespace stays invalid); the fabric never silently downgrades a protection request.
`ENC_EN` works with every backend (the ciphertext replaces the plaintext in the same 512 or 528 bytes).
CRC-32C is an **accidental-corruption check, not authentication**; XTS gives confidentiality only (no tamper
proof). A deliberate attacker who can modify the backend can also recompute the CRC of unencrypted data; with `ENC_EN`
modification yields garbage that fails the check with probability 1 − 2⁻³² per block.

### 6.1 Protection trailer (16 bytes)

| Bytes | Field |
|---|---|
| 0–3 | `GUARD` = CRC-32C (Castagnoli, reflected, init/xorout `FFFFFFFF`) of the 512 data bytes (the plaintext) |
| 4–5 | `NS_TAG` = 16-bit little-endian value `NSID | (TENANT << 8)`, i.e. byte 4 = `NSID`, byte 5 = `{4'b0, TENANT[3:0]}` |
| 6–11 | `LBA_TAG` = namespace-relative LBA, 48 bits |
| 12 | `VERSION` = 1 |
| 13–15 | reserved 0 |

With `ENC_EN` the 528-byte unit `data ‖ trailer` is encrypted as one XTS data unit (33 AES blocks).

## 7. Backend contract (what every backend adapter must provide)

Request/response in units of blocks; data moves as 64-bit beats, one stream per direction in request order.

* **Capabilities:** `be_ready`, `be_capacity` (blocks), `be_caps` bits: `PI_NATIVE`, `VOLATILE_CACHE`, `DISCARD`,
  `DISCARD_ZERO` (reads of discarded blocks return zeros), `READONLY`.
* **Unit size** = 512 bytes, or 528 bytes (`data ‖ trailer`) for a `PI_NATIVE` backend.
* **Operations:** READ(lba,n), WRITE(lba,n), FLUSH, DISCARD(lba,n). One completion per request with
  `status ∈ {OK, MEDIA_ERR, DEV_ERR, RANGE, RO, UNSUPPORTED, NOT_READY, RESET}`, `durable` (data persistent), and `nblk_done`.
* A read unit may be flagged `UNMAPPED` (never written / discarded): data is zeros, trailer is not meaningful.
* A READ that hits a media error flags the unit `ERR` and the completion carries `MEDIA_ERR`.
* `be_reset` (pulse from the fabric) must abandon all requests; the backend returns to ready.
* `be_ready` low means the backend is absent (power cut, service withdrawn). The fabric reacts when `be_ready` **falls**: it pulses `be_reset`, completes every command waiting on the
  backend `ABORTED_RESET` immediately (not when the backend returns), and completes any command that needs the backend while it is absent `BACKEND_ERROR` with detail 6 (`NOT_READY`).
  Commands are never retried by the fabric and never wait for an absent backend.
* A backend that completes a FLUSH with `durable = 0` makes the FLUSH fail (`BACKEND_ERROR`, detail 14); a WRITE with `FUA` and `durable = 0` is followed by an internal FLUSH (see §5).
* Backends that cannot supply `PI_NATIVE` are not wrong: the namespace simply runs without stored protection
  information (see the table in `docs/03_ARCHITECTURE.md` §6 for what each shipped backend provides).

## 8. Tenant MMIO page (4 KiB per tenant; selected by the hardware function binding)

| Offset | Name | Access | Description |
|---|---|---|---|
| `000` | `ID` | RO | `0x53465354` ("SFST") |
| `004` | `VERSION` | RO | `0x0001_0000` |
| `008` | `CAPS0` | RO | [7:0] `MDTS_BLOCKS`, [15:8] `SQ_MAX`, [23:16] `CQ_MAX`, [31:24] block shift (9) |
| `00C` | `CAPS1` | RO | [0] DISCARD, [1] PI, [2] ENC, [3] FUA, [4] HCRC, [5] VOLATILE_CACHE, [8] BACKEND_READY, [15:12] BACKEND_TYPE (0 simdev, 1 STORE, 2 host-sw, 3 NVMe adapter), [31:16] bitmask of owned NSIDs |
| `010` | `CTRL` | RW | [0] `ENABLE` (only takes effect if the hypervisor allowed it), [1] `RESET` (W1S, self-clearing: aborts this queue's in-flight commands with `ABORTED_RESET` — no completion is written — clears the rings' pointers, queue stays disabled) |
| `014` | `STATUS` | RO | [0] enabled, [1] `SQ_ERR`, [2] `CQ_ERR`, [3] `FATAL` (queue halted; needs `RESET`), [4] SQ empty, [5] idle (nothing in flight), [15:8] last queue-error code (CloudDMA `ERR`) |
| `020`/`024` | `SQ_BASE` | RW | 64-bit, 64-byte aligned (low 6 bits read 0); write only while disabled |
| `028` | `SQ_SIZE` | RW | entries, power of two, 2..`SQ_MAX`; write only while disabled; an illegal value is ignored and sets `DB_ERR` |
| `030`/`034` | `CQ_BASE` | RW | 64-bit, 32-byte aligned |
| `038` | `CQ_SIZE` | RW | entries, power of two, 2..`CQ_MAX` |
| `040` | `SQ_TAIL` | RW | submission doorbell: producer index, `< SQ_SIZE`; a value that would make the ring overflow (more than `SQ_SIZE-1` entries outstanding) is ignored and sets `DB_ERR` |
| `044` | `CQ_HEAD` | RW | completion doorbell: consumer index; a value beyond `CQ_TAIL` is ignored and sets `DB_ERR` |
| `048` | `SQ_HEAD` | RO | fabric consumer index |
| `04C` | `CQ_TAIL` | RO | fabric producer index |
| `050` | `IRQ_EN` | RW | [0] interrupt while the CQ is non-empty, [1] on queue error |
| `054` | `IRQ_STATUS` | RW1C | [0] CQ non-empty (level, reflects `CQ_TAIL ≠ CQ_HEAD`; not clearable), [1] queue error, [2] `DB_ERR` |
| `060` | `INFLIGHT` | RO | commands currently owned by the fabric for this queue |
| `080` | `CNT_DONE` | RO | commands completed |
| `084` | `CNT_ERR` | RO | commands completed with `STATUS ≠ SUCCESS` |
| `088` | `CNT_RD_BLK` | RO | blocks read |
| `08C` | `CNT_WR_BLK` | RO | blocks written |
| `090` | `CNT_FLUSH` | RO | flushes completed |
| `094` | `CNT_THROTTLE` | RO | cycles the queue's head command was held back by its quota / rate limit |
| `098` | `CNT_VIOL` | RO | isolation violations (`TENANT_MISMATCH`, `INVALID_NS`, `DMA_FAULT`) |
| `09C` | `CNT_BYTES_LO` | RO | payload bytes moved (low 32 bits) |

Accessing an undefined offset, writing a read-only register, or a misaligned access returns an error response.

### Queue fatal conditions

* A DMA failure while fetching descriptors (SQ memory not mapped for this tenant, bus error, permission denial) sets `STATUS.SQ_ERR` and
  `STATUS.FATAL`, latches the DMA error code in `STATUS[15:8]`, raises the queue-error interrupt and halts the queue: no further descriptor is
  fetched, commands already admitted complete normally.  Recovery is `CTRL.RESET` followed by the bring-up sequence.
* A completion that cannot be written because the CQ memory faults sets `CQ_ERR` (and `FATAL`); the CQE is lost, so the host must treat every command
  that was in flight as unknown (re-read / re-flush after `RESET`).
* A doorbell value that would overrun a ring (`SQ_TAIL` beyond free space, `CQ_HEAD` beyond the produced entries) is refused (`DB_ERR` bit of the queue interrupt-status register, offset `054`),
  the pointer does not move.

### Queue bring-up (what `sfs_queue_create` does)
1. (hypervisor) program the tenant's DMA windows, namespaces and quotas (management window), set `TCFG.ENABLE_ALLOWED`.
2. (tenant) write `SQ_BASE`, `SQ_SIZE`, `CQ_BASE`, `CQ_SIZE` with the queue disabled; zero the CQ memory (phase 0).
3. write `CTRL.ENABLE = 1`; read `STATUS.ENABLED`.
4. submit: write descriptors at `SQ[tail]`, advance `tail`, write `SQ_TAIL`.
5. complete: poll CQ word 7 for the expected phase; consume; write `CQ_HEAD`.

## 9. Management window (privileged; **must never be reachable by a tenant**)

| Offset | Name | Description |
|---|---|---|
| `000` | `ID` | `0x53465347` ("SFSG") |
| `004` | `VERSION` | `0x0001_0000` |
| `008` | `GCAPS0` | [7:0] `NT`, [15:8] `NSLOT`, [23:16] `NS_N`, [31:24] `MDTS_BLOCKS` |
| `00C` | `GCAPS1` | [7:0] `SQ_MAX`, [15:8] `CQ_MAX`, [16] XTS present, [17] VirtIO adapter present, [27:24] backend type |
| `010` | `GCTRL` | [0] `ENABLE` (0 at reset: no queue starts), [1] `SOFT_RESET` (W1S: equivalent to `CTRL.RESET` on every tenant queue plus a backend reset — queues are disabled and their pointers cleared, commands in flight are abandoned WITHOUT a CQE and stop at the next safe point, the backend is reset; hosts re-run the queue bring-up), [2] `TRACE_EN`, [3] `CLR_COUNTERS` (W1S), [4] `RD_PRIO` (reads bypass queued writes), [5] `WR_BATCH` (prefer consecutive writes of the selected tenant) |
| `014` | `GSTATUS` | [0] backend ready, [1] power-fail quiesce active, [2] fatal, [15:8] busy slots, [23:16] backend busy |
| `018` | `CMD_TIMEOUT` | cycles from slot allocation to completion after which the command fails `TIMEOUT` (0 = disabled) |
| `01C` | `SCHED_CFG` | [7:0] `WR_BATCH_MAX` (default 4), [15:8] `WR_AGE_MAX` (a write may be bypassed by reads at most this many times; default 8) |
| `020` | `PF_CTRL` | [0] force power-fail warning (test hook; the pin `pf_warn_i` has the same effect) |
| `100 + 20·t` | `TCFG` (tenant `t`) | +00 [0] `ENABLE_ALLOWED`; +04 `MAX_INFLIGHT` (0 = `NSLOT`); +08 `WEIGHT` (DRR quantum, blocks, 1..255, 0 reads as 1); +0C `RATE` (blocks per 1024 cycles, 0 = unlimited); +10 `BURST` (bucket depth, blocks) |
| `300 + 20·n` | `NS` (namespace `n`) | +00 `NS_CTRL` [0] `VALID`, [1] `READONLY`, [2] `ENC_EN`, [3] `PI_EN`, [7:4] `OWNER`, [11:8] `KEY_SLOT`; +04/+08 `BASE` (backend blocks, 64-bit); +0C/+10 `SIZE` (blocks, 64-bit); +14 `NS_STATUS` [0] last `VALID` request accepted, [1] refused: out of backend capacity, [2] refused: PI unsupported, [3] refused: bad owner / zero size, [4] refused: `ENC_EN` without an XTS engine or with a key slot out of range, [5] refused: overlaps another valid namespace. Exactly one of bits [5:1] is set on a refusal (checked in the order 3, 1, 2, 4, 5). BASE/SIZE/CTRL flags are writable only while `VALID = 0`; writing `VALID = 1` validates |
| `500..` | DMA windows | `PT_IDX` (+00), `PT_DOM` (+04), `PT_BASE` (+08/+0C), `PT_SIZE` (+10/+14), `PT_PERM` (+18, bit0 R, bit1 W), `PT_CTRL` (+1C, bit0 valid, bit1 commit W1S), `PT_STATUS` (+20, bit0 rejected). Entries `0..NT-1` are reserved for the fabric's local-memory windows; the hypervisor programs `NT..15` |
| `600..` | backend | `BE_TYPE`, `BE_CAPS`, `BE_CAP_LO/HI`, `BE_CTRL` [0] `BE_RESET` (W1S) |
| `700..` | keys (XTS) | `KEY_SEL` (`700`), `KEY_W0..W15` (`704..740`, write-only, read as 0), `KEY_CTRL` (`744`) [0] commit the staged key into slot `KEY_SEL` (the staging words are wiped), [1] zeroize every slot, [2] with commit: 128-bit keys (two 128-bit halves) instead of 256-bit; `KEY_STATUS` (`748`, RO) bit *k* = slot *k* holds a key. Key material is never readable. |
| `800..` | performance | `PERF_SEL` (`800`), `PERF_LO` (`804`), `PERF_HI` (`808`; reading LO latches HI) — counter ids `PC_*` in `silicaflux_storage_fabric_pkg.sv` (also tabulated in `docs/03_ARCHITECTURE.md` §9) |
| `900..` | trace | `TR_STAT` (`900`) [15:0] entries, [31:16] dropped (new records are dropped, never overwritten, when the FIFO is full); `TR_W0..W7` (`904..920`) head record; `TR_POP` (`924`, write 1 removes the head) |

Trace record (8 words): W0 `{op[7:0], status[7:0], tenant[3:0], flags[3:0], txn[15:0]}` is split as
W0 = `txn[15:0] | tenant<<16 | op<<24`, W1 = `status | detail<<8 | nblk<<16`, W2 = cycle of descriptor fetch complete,
W3 = cycle the command was admitted to a slot (queue wait = W3 − W2), W4 = cycle the backend request was issued,
W5 = cycle the backend completed, W6 = cycle the completion was posted, W7 = `{durable[31], payload bytes[30:0]}`. Only commands that were admitted to a slot produce a record.
Cycle counts are 32-bit free-running.
