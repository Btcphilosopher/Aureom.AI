# 08 — Integrating StorageFabric into SilicaFlux CloudDPU (P61)

**Status: documented, not performed.** P61 is unmodified in this deliverable. Today P61 refuses `OP_STORAGE` with `ERR_BLOCKED`, `ENABLE_STORAGE` must be 0 (an elaboration error otherwise) and `BLOCK_STATUS.STORAGE` reads *blocked* (P61 `docs/00_AUDIT.md`, `01_ARCHITECTURE.md`, `DPU_MEMORY_MAP.md`). P68 provides the missing block; this note is the wiring plan.

## What P61 would instantiate

| P61 resource | StorageFabric port | Notes |
|---|---|---|
| tenant register pages (hardware-bound function) | `tmmio_*` with `tmmio_fn` = tenant id | the fabric trusts only the hardware binding, never a descriptor field |
| privileged management window (ControlCore / hypervisor) | `mmio_*` | namespaces, DMA windows, quotas, keys, counters, trace; must never be mapped to a tenant |
| P61's CloudDMA / DataFabric AXI | `m_*` AXI4 master (`m_*_domain`, `m_*_asid`) | domain = tenant id; asid 0 = tenant memory; an external firewall / IOMMU can re-check the sidebands. P68 contains its own CloudDMA instance; a shared one would need the same per-domain permission table |
| interrupts | `irq[NT-1:0]`, `pf_quiesced_o` | per-tenant completion / queue-error |
| power-fail warning (PowerSafe) | `pf_warn_i` | admission stops, un-issued commands abort `ABORTED_POWER`, issued ones finish |
| VirtIO front end | `ext_*` source (one pseudo-tenant) | already integrated here with P63 |
| `OP_STORAGE` | would become a *management-plane* command: "bind queue pair / namespace for tenant *t*" executed by ControlCore firmware through the management window; the data plane is the tenant's own SQ/CQ, not P61's command queue | P61's `OP_STORAGE` today carries no block I/O semantics |

## Steps

1. Allow `ENABLE_STORAGE = 1` in P61 and instantiate `silicaflux_storage_fabric` (`BACKEND` chosen per build: `BE_EXTERN` + `sf_stor_be_store`, `sf_stor_be_hostsw`, or the simulated device for bring-up).
2. Map the tenant pages and the management window into the DPU memory map (`DPU_MEMORY_MAP.md`: new `STORAGE` block base; the `BLOCK_STATUS.STORAGE` field becomes live).
3. Control firmware: program per-tenant DMA windows (`PT_*`), namespaces (`NS_*`), quotas (`TCFG`), enable the fabric (`GCTRL.ENABLE`) — the same sequence `Tb::configure()` performs in `sim/tb_env.hpp`; hand the tenant its page.
4. Add the isolation tests of P61 `02_TENANT_ISOLATION.md` for the storage block (cross-tenant namespace, DMA outside windows, queue memory outside windows) — P68's `isolation`, `invalid`, `window` tests are the starting point.
5. Re-run P61's regression with `ENABLE_STORAGE = 1` (not done here).

Nothing in this plan has been synthesized, placed, or timed.
