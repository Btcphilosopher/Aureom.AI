# 00 — Repository audit (what existed, what was reused, what had to be written)

Scope: the SilicaFlux storage-related projects found in the repository before this project started. For every item: what it is,
its software/hardware API, the verification status **as claimed by that project's own README** (marked *claimed*), and — where this
project actually built, ran or integrated the block — what **P68 re-ran** (marked *re-run here*). Nothing in this table is a silicon,
FPGA or standards-conformance claim: every project in the repository is simulation-only, and so is P68.

## 1. Summary

| Need (brief §1) | Found | Used by P68 as | Verdict |
|---|---|---|---|
| SSD controller + FTL + ECC + NAND channel | **P60 StorageChip** (`silicaflux_storage_top`): P51 StorageCore command controller, ControlCore RV32IM running the FTL firmware (P56/P58 FTL library), P54 BCH ECC, P53 FlashLink channel, P52 NANDLab twin | **Backend #2** behind a driver adapter (`sf_stor_be_store`) — not a second controller | reused unmodified |
| NVMe host core | **P57 NVMe HostCore**: NVMe *controller* front end (BAR0 registers, SQ/CQ in host memory, PRP) on top of P51 | **Not used.** It is the *host-facing* side of an SSD. P68 needs the opposite direction (initiator toward a backend) | gap, see `04_BACKENDS_VIRTIO_NVME.md` §4 |
| NAND controller / ECC | P53 FlashLink, P54 ECCCore, P52 NANDLab | inside P60 | reused (transitively) |
| CloudDMA | **P64 CloudDMA**: protected scatter-gather engine, per-domain permission table, multichannel | **The only host-memory master of the fabric** (vendored unmodified) | reused unmodified |
| VirtIO | **P63 VirtIO** block engine (split queue, descriptor validation, permission windows) + C host library | Guest-facing front end; its storage port `sc_*` feeds the fabric through `sf_stor_virtio_adapter` | reused unmodified |
| Buffers | P55 BufferCore (host↔NAND buffer/DMA system) | **Not used** — it belongs to the SSD datapath inside P60; P68 needs only a small staging memory | not applicable |
| Power-loss protection | P58 PowerSafe (recovery + FTL), inside P60 | durability of backend #2 is *inherited* | reused (transitively) |
| Encryption / integrity | **P59 SecureStore**: XTS-AES engine, record guard, RAS | its XTS-AES-256 engine is vendored for the optional per-namespace encryption | reused unmodified. *(An early draft of this audit said "no SecureStore found"; it exists in `securestore-p59`.)* |
| Control CPU / interconnect | P21 ControlCore, P03 DataFabric | not instantiated in P68 (inside P60 as ControlCore) | n/a |
| RAS | P26 RAS | not used | n/a |
| CloudDPU integration point | **P61 CloudDPU**: `OP_STORAGE` is refused with `ERR_BLOCKED`; `ENABLE_STORAGE` must be 0 | P68 is the block that makes `ENABLE_STORAGE` implementable — see `08_P61_INTEGRATION.md` | integration documented, **P61 not modified** |
| Storage fabric: queues, validation, scheduler, integrity, tenancy | **does not exist** | **written in P68** | new |
| NVMe initiator / PCIe root complex / NVMe-oF transport | **does not exist** | not written; documented as a future backend | gap |

## 2. Project-by-project

| Project | Role | API (what a user touches) | Verification status |
|---|---|---|---|
| **P60 StorageChip** | programmable SSD controller (host command queue → DMA → buffer → ECC → NAND channel → NAND twin) run by real firmware | host BAR with SQ/CQ (32-byte SQ entries, 16-byte CQ entries with a phase bit), doorbells, host-memory master port, management mailbox, boot via ROM + firmware image | *claimed:* 19/19 full-chip regression runs, 23 473 checks, 28 injected power cuts with 0 acknowledged writes lost, ECC k ≤ 8 corrected, XTS ciphertext == OpenSSL, 2 formal proofs. **Simulation only, no FPGA/silicon.** *Re-run here:* the chip is built with its NAND twin (Verilator, `--timing`), firmware boots, and P68's STORE suites run model-checked traffic + chip power cuts through it (`05_VERIFICATION.md` §4). P60's own 19-run regression was **not** repeated (a full TB build exceeded the budget). |
| **P51 StorageCore** | command controller + SRAM + ECC + NAND controller SoC | SFB2 host BAR | *claimed:* SoC 4/4, unit 6/6 (inside P60) |
| **P52 NANDLab** | NAND digital twin and fault simulator | SV model + Python twin; persistent array in `<dir>/target<ID>.nlsf` | *claimed:* Python 32/32, SV 128/128 checks. **Note:** the twin persists its array between runs — P68 therefore starts every STORE test from a fresh medium (a stale file once produced a false "garbage for never-written LBAs" suspicion; it was a test artefact, not a P60 defect) |
| **P53 FlashLink** | ONFI-style SDR NAND channel controller | abstract ops (READ_PAGE, PROGRAM, ERASE, …) | *claimed* (inside P60) |
| **P54 ECCCore** | BCH ECC engine (t = 8 per 512 B) | encode/decode pipeline + status | *claimed:* 65/65 reference checks |
| **P55 BufferCore** | host↔NAND buffer and DMA system | SFB2 | *claimed*; not used |
| **P56 FlashMap / P58 PowerSafe** | FTL (page mapping, GC, wear levelling, bad blocks) and power-loss recovery | firmware library + recovery controller | *claimed:* crash campaigns at 31 named points, mount sweep at every NAND op, all pass |
| **P57 NVMe HostCore** | NVMe controller front end (BAR0, doorbells, PRP, admin subset) over P51 | PCIe TLP-level user interface (simulated: **no physical PCIe**) | *claimed:* DoD met in simulation; **not NVMe-conformant** (documented subset) |
| **P59 SecureStore** | XTS-AES, integrity records, RAS | engine ports | *claimed:* pass in simulation + mutation check. *Re-run here:* its XTS engine inside P68's `suite-xts` against OpenSSL |
| **P63 VirtIO** | VirtIO block-device engine | virtio-mmio v2 window + privileged management window + C library (`sfvirtio.h`) | *claimed:* 23/23 directed, model-checked (66 304-completion wrap test). *Re-run here:* the engine and its library are driven by P68's VirtIO suite (`05_VERIFICATION.md` §5) |
| **P64 CloudDMA** | protected scatter-gather DMA | task interface, per-domain permission table, AXI4 master | *claimed:* baseline 15 configs × 3 seeds, multichannel 4/4. *Re-run here:* exercised by every P68 test; its isolation is re-checked by P68's independent bus monitor |
| **P61 CloudDPU** | the DPU the fabric must plug into | command queue with opcodes; `OP_STORAGE` currently blocked | *claimed* by P61; unchanged |
| P62 PacketCore, P65 MemoryPool, P21 ControlCore, P03 DataFabric, P26 RAS, P37 IOSHELL, HPC-M05 | other DPU blocks | — | not used |

## 3. Consequences for the design

1. **One SSD controller, one FTL.** The STORE backend drives P60's existing host ABI. P68 contains no FTL, no wear levelling, no ECC.
2. **The fabric owns host memory access** (through CloudDMA); no backend ever sees a tenant address. P60's own host-memory master is served from a
   private bounce RAM inside the adapter.
3. **The simulated block device comes first** (baseline backend, fault injection, reference for every other adapter); STORE was integrated only after
   the fabric passed the full suite on the simulated device, as the brief required.
4. **NVMe is a taxonomy, not a feature** (`04_BACKENDS_VIRTIO_NVME.md` §4). P57 is a device-side controller; there is no NVMe initiator, root complex or
   fabric transport in the repository, so none is claimed.
5. **Durability for STORE is inherited**, not proven here (P60 limitation: the completion path trusts the firmware).
