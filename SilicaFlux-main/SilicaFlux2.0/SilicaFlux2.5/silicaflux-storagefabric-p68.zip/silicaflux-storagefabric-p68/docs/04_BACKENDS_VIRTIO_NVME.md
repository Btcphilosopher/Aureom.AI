# 04 — Backends, the VirtIO block front end, and the NVMe taxonomy

Everything here is simulation evidence only. Test names refer to `05_VERIFICATION.md`.

## 1. One contract, interchangeable backends

A backend implements the contract of `02_HOST_INTERFACE.md` §7 (`be_*` ports): a **request** (op READ / WRITE / FLUSH / DISCARD, backend LBA, block count, tag), a
**write-data** stream and a **read-data** stream of 64-bit words in units of 66 words (528 B, PI-native) or 64 words (512 B), a **completion** (tag, status, `durable`,
`nblk_done`), capability bits (`PI_NATIVE`, `VOLATILE_CACHE`, `DISCARD`, `DISCARD_ZERO`, `READONLY`), per-unit read flags (`ERR`, `UNMAPPED`), a capacity, `be_ready` and a
`be_reset` pulse. The fabric core is identical for all of them; only the adapter differs.

| Backend | RTL | Status |
|---|---|---|
| Simulated block device | `rtl/sf_stor_be_simdev.sv` | baseline; full suite |
| SilicaFlux-STORE (P60 StorageChip) | `rtl/adapters/sf_stor_be_store.sv` + P60 chip (vendored) | integrated after the fabric passed on the simulated device; STORE suite (4 tests) passes on a fresh NAND medium |
| Host software | `rtl/adapters/sf_stor_be_hostsw.sv` | suite (6 tests) passes with a C++ software service model |
| NVMe hardware adapter | — | **not implemented** (future); see §4 |
| VirtIO block *front end* | `rtl/adapters/sf_stor_virtio_adapter.sv` + P63 engine (vendored) | VirtIO suite (8 tests × 3 seeds) passes |

## 2. Simulated block device (`sf_stor_be_simdev`)

A behavioural model of a block device (not synthesizable by intent). Persistent array with a per-block *unmapped* bit; optional bounded write-back **volatile cache**
(`SIM_VOLATILE_CACHE`, `SIM_CACHE_N`) — writes complete with `durable = 0` until a FLUSH; power loss keeps any subset of the unflushed blocks; per-unit atomic commit. Latency model: base + per-block
cycles + LFSR jitter, `QD` requests queued. Testbench sideband: device failure, hang, media error on an LBA, bit corruption of a stored unit, misdirected read, power loss, backdoor read of any stored unit
(`sim_dbg_*`), dirty-block count (`sim_dirty`). Everything the brief asks to verify (backend failure, corruption, power loss, timeouts) is injected here because real media cannot be made to fail on demand.

## 3. SilicaFlux-STORE backend (`sf_stor_be_store`)

**It is a driver, not a controller.** The adapter turns one backend request at a time into the P60 host ABI:

1. *Bring-up* (after the platform has booted the chip firmware through the chip's own mailbox — the adapter exposes a management **passthrough** to the same BAR while it is idle between commands): clear interrupt control, enable the controller, poll `STATUS.READY`, read the queue depth and the capacity.
2. *WRITE*: collect the units from the fabric into a private **bounce RAM**; write the 8-word SQ entry (opcode, TXN id, LBA, block count, data address = bounce base) through the BAR, ring the SQ doorbell, poll the CQ for the phase bit, read the status word, advance the CQ head.
3. *READ*: zero-fill the bounce RAM (never-written blocks must read as zeros), submit, poll, then stream the units to the fabric (`UNMAPPED` flag never set: the chip returns zeros).
4. *FLUSH / DISCARD*: the matching P60 commands (TRIM for DISCARD).
5. Status mapping: P60 `0x00` → OK, `0x08` → RANGE, `0x10` → MEDIA_ERR, `0x11` → RO, `0x05/0x07` → RESET, else DEV_ERR.

Isolation: the chip is a bus master for its own data DMA; it is attached to the adapter's **bounce RAM only** — any other address returns a bus error. Tenant addresses and fabric LBAs never reach the chip; it sees only
namespace-window LBAs. One command at a time (baseline), at most `MDTS` blocks (8 KiB bounce).

Properties and limits (also in `07_LIMITATIONS.md`):

* **Not PI-native.** The chip keeps its own BCH + CRC-16 + FTL CRC-32/LPN tag inside the page; the fabric's 16-byte trailer cannot be stored. Namespaces with `PI_EN` are refused on this backend (`NS_STATUS` bit 2). `HCRC` / `RCRC` still work.
* **Durability is inherited.** P60 acknowledges a write only after the page is programmed (no volatile write cache), so the adapter reports `durable = 1`. P60 itself documents that its completion path trusts the firmware; P68 cannot prove otherwise.
* **Chip loss.** If the chip's `host_ready` falls (power cut, reset) the adapter returns to *offline*: `be_ready` falls, the fabric aborts what was waiting (`ABORTED_RESET`) and fails new commands fast (`BACKEND_ERROR / NOT_READY`); after the chip reboots and re-mounts its FTL the adapter re-initialises and service resumes.
* Evidence: `store-suite` — `random`, `invalid`, `isolation` (model-checked traffic through the real RISC-V firmware, BCH ECC and NAND twin) and `powerloss` (two rounds of cutting chip power with 17–27 commands in flight; every acknowledged write survives, every unacknowledged block is old-or-new). The suite **starts every test from a fresh NAND medium**: the twin persists its array in `<dir>/target0.nlsf`, and an earlier version of this work mistook stale data from a previous run for a P60 defect ("garbage for never-written LBAs"). That was a test artefact; the adapter's sidecar "written map" built on that mistake was removed.
* Not re-run: P60's own 19-run regression, its formal proofs, its benchmarks (`reports/` of P60 claim 5.3 k read IOPS at 512 B QD1 at an *assumed* 100 MHz; P68 does not repeat or endorse that number).

## 4. NVMe: four different things (and what is claimed)

| # | Thing | Direction | In the repository? | Used by P68? |
|---|---|---|---|---|
| 1 | **Host-facing NVMe control** — a device presents NVMe registers / queues / PRPs to a host driver | host → device | **P57 NVMe HostCore** (controller front end, subset, *not conformant*, PCIe side is a transaction-level simulation) | no. (P68's tenant interface is its own versioned queue ABI, `02_HOST_INTERFACE.md`; it is deliberately not NVMe so that nothing implies NVMe conformance) |
| 2 | **Backend access over NVMe** — an initiator submits NVMe commands to an *external* NVMe drive | DPU → drive | **absent**: needs a PCIe root complex / host controller and an NVMe initiator (hardware or firmware) | **future adapter**, not written |
| 3 | **Controller hardware** — the SSD controller itself (FTL, ECC, NAND channels) | inside the drive | **P60 StorageChip** (+ P51–P56, P58) | yes, as backend #2 via its own simple host ABI, *not* via NVMe |
| 4 | **PCIe endpoint** — link, TLPs, SR-IOV, config space | — | **absent** (P57 only models TLP-level user interface) | no |
| 5 | **NVMe-oF** — NVMe over RDMA / TCP / FC | DPU → remote target | **absent** (no transport) | **not claimed** |

**No NVMe-oF, NVMe conformance, PCIe link, or SR-IOV claim is made anywhere in P68.**

How a *future* NVMe adapter would plug in (design note, not implemented): it implements the same `be_*` contract. READ → NVMe `Read` (0x02), WRITE → `Write` (0x01), FLUSH → `Flush` (0x00), DISCARD → `Dataset Management` with the
deallocate attribute (0x09); `PI_NATIVE` only if the namespace is formatted with an NVMe protection-information type and the adapter maps the fabric trailer to NVMe PI (otherwise not PI-native, like STORE);
`VOLATILE_CACHE` from Identify Controller `VWC`; `durable` from FUA or Flush completion; the fabric's `be_reset` → controller reset / queue deletion. Data is staged in an adapter-owned bounce buffer addressed by PRP, so the backend never sees tenant memory.
Preconditions that do not exist today: a PCIe host controller or root complex IP, an NVMe initiator state machine (or a firmware driver on a control CPU, which could use the host-software mailbox of §5), and a physical NVMe device. **NVMe-oF** would additionally need a network transport and is outside this project.

## 5. Host-software backend (`sf_stor_be_hostsw`)

The contract is served by **software** (a service on the DPU management CPU or the host) through a 32-bit mailbox window, one request at a time. The software owns the storage; the adapter owns the staging RAM and the protocol.

| Offset | Name | Access |
|---|---|---|
| `000` `ID` = `0x53464853` · `004` `VERSION` = 1 · `008` `CTRL` [0] `READY` · `00C` `CAPS` · `010/014` `CAPACITY` | identity, service up/down, capabilities (PI_NATIVE is always reported: the unit format is fixed), capacity | RO / RW (caps and capacity writable while `READY = 0`) |
| `020` `REQ_STATUS` [0] pending [3:1] op [4] aborted [15:8] tag [31:16] **seq** · `024/028` `REQ_LBA` · `02C` `REQ_NBLK` | the live request | RO |
| `030` `CPL_STATUS` · `034` `CPL_NBLK` · `038` `CPL_FLAGS` [0] durable · `03C` `CPL_COMMIT` [15:0] = seq | the answer; **a commit whose seq does not match the live request is ignored** (stale answer after a reset) | WO |
| `080 + 4u` `UFLAGS` | per-unit read flags (ERR / UNMAPPED) | WO |
| `2000 + 4i` `DATA` | staging RAM, 32-bit little-endian words, unit *u* at word `u·132`; writable only while the request is pending | RW |

Behaviour: a WRITE's units are collected before the request is shown (`PENDING`); the software reads LBA / NBLK (and the data), writes the answer and the commit. A READ's data and flags are written before the commit; the adapter then streams them to the fabric. `durable` is
whatever the software reports — **the software owns the durability claim**. A fabric backend reset (timeout, `BE_CTRL`, power-fail) drops the request, latches `ABORTED`, bumps `seq`; the software withdrawing (`READY = 0`) aborts like a reset.
Evidence (`hostsw-suite`): the generic model-checked `random` / `invalid` / `isolation` tests run unchanged against this backend, plus `swfail` (device failure and media error propagate exactly; no data reaches the host on a failed READ), `swstall` (unresponsive software → `TIMEOUT` after the configured time; a slow software's late answer carries the old sequence number, is counted in `hs_stale` and **never completes a newer request**), `withdraw` (in-flight command aborted promptly; commands while the software is gone fail fast with `BACKEND_ERROR / NOT_READY`; data stored earlier is served again when it returns). The software here is a C++ state machine that speaks only the mailbox, one register access per transaction; it demonstrates the protocol, it is not a production storage service.

## 6. VirtIO block device front end

```
 guest VM driver ──virtio-mmio v2──► P63 silicaflux_virtio_engine ──sc_* (64-bit, byte-enabled, byte addresses)──► sf_stor_virtio_adapter ──ext source──► fabric
     │  split virtqueue in guest memory                │ every guest-memory access ► permission windows (domain-tagged)         (tenant EXT_TENANT, namespace VNS)
     └── DMA port (domain tag) ◄───────────────────────┘ privileged management window (hypervisor): bind domain, program windows, perf counters
```

* **Protected virtual queue processing** is P63's (unmodified): descriptor-chain walking with bounded length, loop / order / flag / length validation, every access checked against the tenant's windows, fatal causes latch `DEVICE_NEEDS_RESET`. P68 re-ran its guest library against it and added an *independent* DMA-window monitor (`05_VERIFICATION.md` §5).
* **Only the assigned logical region:** the device is hard-bound to **one namespace** (`VNS`, owned by the hardware-fixed `EXT_TENANT`); the fabric's validation (ownership, range) applies to every command it issues. The guest sees sectors 0..*capacity*−1 of that namespace and has no way to name a backend address; the VirtIO suite checks that **no backend block outside the namespace is ever modified**, that the guest's memory outside its window is never read or written, and that native tenants' namespaces are unaffected (and unreachable) while the guest runs.
* **Block mapping:** sector *s* ↔ fabric block *s* of `VNS` (512 B). The adapter keeps a one-sector buffer: reads fill it with a READ (1 block) and serve the 64-bit accesses from it; writes are byte-combined and the sector is committed with a WRITE (1 block) when all 512 bytes have been written; the **last** sc response of a write is withheld until the fabric completes the block, and any error becomes `sc_resp_err` → `VIRTIO_BLK_S_IOERR`. A partially written sector (only possible if a request fails part-way) is merged by read-modify-write on the next sector change or FLUSH.
* **FLUSH** (feature offered by P63) → fabric FLUSH. A guest write completes when the block is accepted by the backend; with a volatile-cache backend it is durable only after the guest's FLUSH — the same contract as a write-back virtio-blk disk. The VirtIO suite checks both directions against the simulated device's dirty-block count: dirty after a write, clean after FLUSH, and flushed data survives a power cut while unflushed blocks are old-or-new.
* **Errors:** device failure, media error, **integrity failure (a bit flipped in a stored block)** all surface as `IOERR` and the corrupted bytes are never delivered; unsupported request types → `UNSUPP`; out-of-range / non-multiple-of-512 → `IOERR` (engine); out-of-window buffers → refused by the engine without any bus access.
* **Found and fixed by this suite:** when the fabric completed a command with an error *before* the data move (device failure, integrity error) the adapter waited forever for the data-move request and the guest request hung. The adapter now consumes an early completion in the data phase and reports it as an error (mutation 14 re-creates the bug and is caught).
* Limits: one outstanding DMA (P63, deliberate), one sector operation at a time, single queue, no multiqueue / packed ring / indirect descriptors / DISCARD / WRITE_ZEROES. Reconfiguring the namespace under a running device is a hypervisor operation that must be accompanied by a device reset (the one-sector buffer is not invalidated by management writes).

## 7. Host software interface

`host/include/sfstor.h`, `host/src/sfstor.c` — a small C99 library (no dynamic allocation, transport-struct based, runs unchanged against real MMIO or the co-simulation): discover capabilities, create a queue pair, submit READ / WRITE / FLUSH / DISCARD / GET_CAPACITY (asynchronously with TXN ids, or synchronously), poll or wait for completions, decode status / detail, read per-tenant performance counters and latency statistics, plus the hypervisor-side management helpers (namespaces, DMA windows, tenant quotas, keys, trace). `examples/sfs_example.c` is a tour; `make example` runs it against the Verilated fabric. The library was written from `02_HOST_INTERFACE.md` only, independently of the RTL.
