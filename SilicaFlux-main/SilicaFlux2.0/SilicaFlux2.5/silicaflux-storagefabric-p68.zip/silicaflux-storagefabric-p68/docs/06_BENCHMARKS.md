# 06 — Benchmarks (simulated block device, cycle counts)

**Read `07_LIMITATIONS.md` first.** Everything below is RTL simulation of the fabric on the *simulated block device*; units are **fabric clock cycles** (no frequency, no wall-clock, no real-media behaviour). The service times are nearly deterministic, so p99 sits next to p50 for steady closed-loop workloads: those percentiles are real samples from this model, not a statement about a production tail.

## Method

* Closed-loop generator (`bench/bench_fabric.cpp`) built on the verification environment: the real host library submits, the reference model checks **every** completion (benchmark traffic is correctness-checked; a non-zero model failure would print a `WARNING` line and none occurred), an independent AXI monitor checks every beat (zero violations).
* Each workload: prefill the namespaces, warm up 30 000 cycles, then measure a window (300 000 cycles; 1 500 000 for latency-focused workloads so that every direction has ≥ 100 samples and p99 is meaningful). A percentile is printed `n/a` when fewer than 100 samples exist. Percentiles are nearest-rank (`sfs_percentile`) over samples actually collected — never estimated.
* Metrics: **IOPS** (commands per million cycles, including error completions), **bytes/cycle** (payload of successful reads/writes), **read / write latency** two ways — *host* (submission → host observes the CQE; polling granularity 8 cycles) and *device* (CQE `LATENCY`, descriptor fetched → completion posted, exact) — as p50 / p99 / max, **queue wait** (trace FIFO, admit − fetch), **backend time** (trace, backend done − issue), **DMA throughput** (bytes the testbench's independent AXI slave saw, per cycle; the fabric's own DMA byte counter is not used), **backend stall** (cycles the mover wanted to move a beat and the backend stalled it), **transform busy**, slot occupancy, **error rate**, and **tenant fairness** (Jain's index over per-tenant blocks divided by weight, 1.0 = perfectly proportional).
* The trace pass is a second run of the same workload with the trace FIFO enabled and popped over MMIO (popping costs simulated time, so the throughput pass runs with the trace off).
* Backend: simulated device, read latency 40 / write latency 80 cycles unless stated, 2 cycles per block, queue depth 4, no jitter. The testbench memory slave has 4-cycle latency and no back-pressure. 4 tenants, 8 slots, MDTS 8 blocks, 64-bit local datapath.
* Reproduce: `make bench` (≈ 80 min, writes `reports/bench_raw.txt`), then `python3 bench/make_report.py reports/bench_raw.txt [partial re-run files…]`. Raw output of the exact run used here is in `reports/`.

## What the numbers say (and where this baseline is weak)

1. **The fabric saturates at ≈ 3.8 bytes/cycle (≈ 920 4-KiB commands per million cycles) from queue depth 4 up.** At QD 1 a 4-KiB read takes 2 154 cycles (465 IOPS/Mcycle); QD 2 reaches 673, QD 4 reaches 916, QD 8/16 add nothing (919 / 924) and only add latency: p50 = QD × ≈ 1 095 cycles (4 380 / 8 760 / 17 520), i.e. Little's law on a saturated closed loop. Writes behave the same (452 → 852 → 860).
2. **The bottleneck is the single transform engine, not the backend.** At saturation the transform engine is **95 % busy** for reads (84 % for writes), DMA-out 85 %, while the backend is 100 % "busy" only because a request is always outstanding — the mover is stalled by the backend 46 % of the time but the backend's own streaming rate is the same order as the transform's. For writes the backend is busy only **8 %** and DMA-in 55–60 %. The engine processes one 64-bit word per cycle over the 66-word unit (CRC-32C guard, trailer build/verify). Wider or pipelined transform lanes are the obvious next step; this baseline leaves ~4× headroom to the 8 B/cycle AXI peak unused.
3. **Per-command cost is ≈ 85 cycles + ≈ 120–130 cycles per 512-B block** (1 block: 4 803 IOPS/Mcycle = 208 cycles; 8 blocks: 940 IOPS/Mcycle = 1 064 cycles). Small I/O is IOPS-efficient, large I/O bytes/cycle-efficient (2.46 → 3.85 B/cycle from 512 B to 4 KiB).
4. **Backend latency barely matters in this regime**: with the device's read latency swept 10 → 100 → 400 cycles at QD 8, throughput changed 940 → 937 → 920 (−2 %) and backend time only 5 471 → 5 591 cycles, because the simulated device pipelines queued requests and the transform engine is the limit. This is a property of this model + this fabric, **not** of real flash.
5. **Scheduler policy trade-offs** (tenants 0/1 read QD 4, tenants 2/3 write QD 16):
   * FIFO/DRR (default): read p50/p99 = 18 084 / 23 044 cycles, write 72 752 / 84 718; Jain 1.000; total 908 IOPS/Mcycle.
   * **Read priority**: read p50/p99 → 10 950 / 19 044 (−39 % / −17 %), write p50 → 126 288 (+74 %); total throughput +0.6 %; readers get 2.3× the IOPS of writers; Jain (by weight) falls to 0.863. A latency-for-fairness trade, bounded by the write-aging limit (writes still complete; no starvation).
   * **Write batching alone is harmful here**: read p50 doubles (36 844) and tenants become unequal (Jain 0.755; tenant 2 gets 644 commands, tenant 3 337). With read priority enabled, batching changes nothing (identical numbers). Both options default **off**; the recommendation from these numbers is DRR (+ read priority where read latency matters more than write latency). No claim of optimality.
6. **Fairness.** Four identical tenants: Jain 1.000 (344–349 commands each). Weights 1 : 1 : 2 : 4: commands 213 / 211 / 355 / 609 = **1 : 1 : 1.67 : 2.9** — the right direction, not exact proportionality (weight-normalised Jain 0.982); the 8-slot limit and the reserved-slot rule compress the ratio.
7. **Noisy neighbour** (tenant 0: QD 32 writes; tenants 1–3: QD 2 reads; reference = the three light tenants alone: read p50 6 568, p99 6 572 cycles, 306 IOPS/Mcycle each):
   | | victims' read p50 / p99 | victims' IOPS/Mcycle each | aggressor IOPS/Mcycle |
   |---|---|---|---|
   | victims alone | 6 568 / 6 572 | 306 | — |
   | aggressor unlimited | 11 705 / 17 693 (1.8× / 2.7×) | 171 (−44 %) | 412 |
   | aggressor `MAX_INFLIGHT` = 2 | 8 773 / 14 725 (1.3× / 2.2×) | 223 (−27 %) | 262 |
   | aggressor token bucket 2 blocks/1024 cycles | 8 820 / 12 679 (1.3× / 1.9×) | 225 (−26 %) | 264 |

   Quotas and rate limits **reduce** the interference substantially (victim p99 −28 % / −36 %), they do **not** remove it: the transform engine and the backend are shared, and the victims still queue behind already-admitted commands. The tenant quotas are a fairness and capacity-isolation tool, not a latency guarantee.
8. **Error path.** With a media error on one block (≈ 1 in 32 4-KiB reads hits it): error rate 3.08 % (43 of 1 397), every one `MEDIA_ERROR` as expected by the model, good reads unaffected (p50 8 760 cycles, same as without errors), no data delivered on the failed reads. Other workloads run error-free by construction; error behaviour is *verified* in `05_VERIFICATION.md`, not benchmarked.
9. **Observability.** Queue wait is visible in the trace: ≈ 10 cycles when slots are free, 4 268 cycles at QD 16 (slots exhausted), 3 466 / 10 651 (mean / p99) for QD 16 writes. `mean heads waiting for a slot` and `slot occupancy` from the counters agree (QD 16: ≈ 1 head waiting, 8.0 of 8 slots busy).


## Results (generated: `python3 bench/make_report.py reports/bench_raw.txt reports/bench_raw_noisy.txt reports/bench_raw_media.txt`)

<!-- GENERATED by bench/make_report.py from reports/bench_raw.txt -->
_seed=1 scale=100%  (cycles are fabric clock cycles; simulated block device)_

### Queue-depth sweep: 4 KiB random read (one tenant)

| workload | cmds | IOPS / Mcycle | B / cycle | err rate | host read p50/p99/max | host write p50/p99/max | device read p50/p99/max | device write p50/p99/max |
|---|---:|---:|---:|---:|---|---|---|---|
| rr4k_qd1 | 698 | 465.3 | 1.906 | 0.0000 | 2154/2154/2154 | n/a/n/a/n/a | 2013/2013/2013 | n/a/n/a/n/a |
| rr4k_qd2 | 1009 | 672.7 | 2.755 | 0.0000 | 2976/2980/2988 | n/a/n/a/n/a | 2797/2820/2820 | n/a/n/a/n/a |
| rr4k_qd4 | 1374 | 916.0 | 3.752 | 0.0000 | 4380/4380/4462 | n/a/n/a/n/a | 4196/4197/4197 | n/a/n/a/n/a |
| rr4k_qd8 | 1378 | 918.7 | 3.763 | 0.0000 | 8760/8760/8778 | n/a/n/a/n/a | 8576/8577/8577 | n/a/n/a/n/a |
| rr4k_qd16 | 1386 | 924.0 | 3.785 | 0.0000 | 17520/17520/17529 | n/a/n/a/n/a | 13020/13028/13028 | n/a/n/a/n/a |

### Queue-depth sweep: 4 KiB random write

| workload | cmds | IOPS / Mcycle | B / cycle | err rate | host read p50/p99/max | host write p50/p99/max | device read p50/p99/max | device write p50/p99/max |
|---|---:|---:|---:|---:|---|---|---|---|
| rw4k_qd1 | 678 | 452.0 | 1.851 | 0.0000 | n/a/n/a/n/a | 2214/2218/2218 | n/a/n/a/n/a | 2074/2074/2074 |
| rw4k_qd4 | 1278 | 852.0 | 3.490 | 0.0000 | n/a/n/a/n/a | 4576/6062/7894 | n/a/n/a/n/a | 4387/5876/7146 |
| rw4k_qd16 | 1290 | 860.0 | 3.523 | 0.0000 | n/a/n/a/n/a | 18732/22882/26326 | n/a/n/a/n/a | 10682/14262/18486 |

### Queue-depth sweep: 70 % read / 30 % write, 4 KiB

| workload | cmds | IOPS / Mcycle | B / cycle | err rate | host read p50/p99/max | host write p50/p99/max | device read p50/p99/max | device write p50/p99/max |
|---|---:|---:|---:|---:|---|---|---|---|
| mix70r_4k_qd1 | 692 | 461.3 | 1.890 | 0.0000 | 2154/2154/2154 | 2214/2218/2218 | 2013/2013/2013 | 2074/2074/2074 |
| mix70r_4k_qd4 | 1313 | 875.3 | 3.585 | 0.0000 | 4644/6686/7728 | 3976/7498/9466 | 4252/6226/6995 | 3527/7141/9120 |
| mix70r_4k_qd16 | 1357 | 904.7 | 3.705 | 0.0000 | 17626/22804/24640 | 18464/25420/26312 | 11623/16997/17977 | 12096/19774/21212 |

### Transfer-size sweep, QD 8 (random read / sequential write)

| workload | cmds | IOPS / Mcycle | B / cycle | err rate | host read p50/p99/max | host write p50/p99/max | device read p50/p99/max | device write p50/p99/max |
|---|---:|---:|---:|---:|---|---|---|---|
| rr_1blk_qd8 | 1441 | 4803.3 | 2.459 | 0.0000 | 1676/2314/2321 | n/a/n/a/n/a | 1103/1728/1728 | n/a/n/a/n/a |
| rr_2blk_qd8 | 998 | 3326.7 | 3.406 | 0.0000 | 2424/2424/2424 | n/a/n/a/n/a | 1886/1886/1886 | n/a/n/a/n/a |
| rr_4blk_qd8 | 537 | 1790.0 | 3.666 | 0.0000 | 4536/4536/4546 | n/a/n/a/n/a | 4233/4233/4233 | n/a/n/a/n/a |
| rr_8blk_qd8 | 282 | 940.0 | 3.850 | 0.0000 | 8760/8760/8770 | n/a/n/a/n/a | 8576/8577/8577 | n/a/n/a/n/a |
| sw_1blk_qd8 | 1523 | 5076.6 | 2.599 | 0.0000 | n/a/n/a/n/a | 1584/1584/1588 | n/a/n/a/n/a | 1236/1236/1236 |
| sw_4blk_qd8 | 490 | 1633.3 | 3.345 | 0.0000 | n/a/n/a/n/a | 4980/5004/5056 | n/a/n/a/n/a | 4795/4819/4826 |
| sw_8blk_qd8 | 270 | 900.0 | 3.686 | 0.0000 | n/a/n/a/n/a | 9144/9520/9520 | n/a/n/a/n/a | 8959/9334/9335 |

### Backend latency sensitivity (4 KiB random read, QD 8; write latency = 2 × read latency)

| workload | cmds | IOPS / Mcycle | B / cycle | err rate | host read p50/p99/max | host write p50/p99/max | device read p50/p99/max | device write p50/p99/max |
|---|---:|---:|---:|---:|---|---|---|---|
| rr4k_qd8_belat10 | 282 | 940.0 | 3.850 | 0.0000 | 8760/8760/8774 | n/a/n/a/n/a | 8576/8577/8577 | n/a/n/a/n/a |
| rr4k_qd8_belat100 | 281 | 936.7 | 3.837 | 0.0000 | 8792/8792/8802 | n/a/n/a/n/a | 8608/8609/8609 | n/a/n/a/n/a |
| rr4k_qd8_belat400 | 276 | 920.0 | 3.768 | 0.0000 | 8952/8952/8960 | n/a/n/a/n/a | 8768/8768/8768 | n/a/n/a/n/a |

### Scheduler modes (tenants 0/1 read QD 4, tenants 2/3 write QD 16)

| workload | cmds | IOPS / Mcycle | B / cycle | err rate | host read p50/p99/max | host write p50/p99/max | device read p50/p99/max | device write p50/p99/max |
|---|---:|---:|---:|---:|---|---|---|---|
| sched_fifo | 1362 | 908.0 | 3.719 | 0.0000 | 18084/23044/23342 | 72752/84718/88748 | 17331/21773/22782 | 25532/34397/38975 |
| sched_rdprio | 1370 | 913.3 | 3.741 | 0.0000 | 10950/19044/19413 | 126288/127990/136097 | 10767/18315/18363 | 38947/40269/44286 |
| sched_fifo+wrbatch | 1337 | 891.3 | 3.651 | 0.0000 | 36844/39674/40456 | 43468/110374/115806 | 35834/38775/39084 | 19165/45796/49872 |
| sched_rdprio+wrbatch | 1370 | 913.3 | 3.741 | 0.0000 | 10950/19044/19337 | 126288/127986/136093 | 10767/18315/18363 | 38947/40269/44284 |

### Fairness and noisy neighbour

| workload | cmds | IOPS / Mcycle | B / cycle | err rate | host read p50/p99/max | host write p50/p99/max | device read p50/p99/max | device write p50/p99/max |
|---|---:|---:|---:|---:|---|---|---|---|
| fair_equal4 | 1385 | 923.3 | 3.782 | 0.0000 | 35204/45166/49970 | 35140/45194/49886 | 26034/33937/37908 | 26256/34414/35686 |
| fair_weights_1_1_2_4 | 1388 | 925.3 | 3.790 | 0.0000 | 31994/67720/73128 | 30688/68302/76912 | 24744/44576/49425 | 23437/45515/48174 |
| noisy_neighbour_unlimited | 1389 | 926.0 | 3.793 | 0.0000 | 11705/17693/18875 | 80894/99047/107477 | 11017/16704/17579 | 17071/27674/32297 |
| noisy_neighbour_inflight_cap2 | 1386 | 924.0 | 3.785 | 0.0000 | 8773/14725/16353 | 130240/144093/145525 | 8403/14011/15598 | 23441/30732/31098 |
| noisy_neighbour_rate_cap | 1402 | 934.7 | 3.828 | 0.0000 | 8820/12679/16248 | 131572/141364/143488 | 8411/12272/15890 | 23185/30921/33456 |
| noisy_neighbour_victims_only | 1376 | 917.3 | 3.757 | 0.0000 | 6568/6572/6616 | n/a/n/a/n/a | 6386/6387/6387 | n/a/n/a/n/a |

### Error path (media error on one block; error rate = failed / completed)

| workload | cmds | IOPS / Mcycle | B / cycle | err rate | host read p50/p99/max | host write p50/p99/max | device read p50/p99/max | device write p50/p99/max |
|---|---:|---:|---:|---:|---|---|---|---|
| rr4k_qd8_media_error_lba5 | 1397 | 931.3 | 3.697 | 0.0308 | 8760/9332/10014 | n/a/n/a/n/a | 8576/9147/9831 | n/a/n/a/n/a |

### Resource utilisation (counters over the measurement window)

| workload | backend busy | backend stalled mover | DMA-in active | DMA-out active | AXI read B/cyc | AXI write B/cyc | transform busy | mean busy slots | mean heads waiting for a slot | throttled | Jain (by weight) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| rr4k_qd1 | 0.276 | 0.000 | 0.028 | 0.419 | 0.030 | 1.915 | 0.257 | 0.93 | 0.00 | 0.0000 | 1.000 |
| rr4k_qd2 | 0.567 | 0.167 | 0.112 | 0.604 | 0.043 | 2.771 | 0.527 | 1.78 | 0.01 | 0.0000 | 1.000 |
| rr4k_qd4 | 1.000 | 0.456 | 0.069 | 0.846 | 0.059 | 3.770 | 0.953 | 3.82 | 0.01 | 0.0000 | 1.000 |
| rr4k_qd8 | 1.000 | 0.456 | 0.069 | 0.847 | 0.059 | 3.770 | 0.953 | 7.82 | 0.01 | 0.0000 | 1.000 |
| rr4k_qd16 | 1.000 | 0.456 | 0.070 | 0.852 | 0.059 | 3.770 | 0.953 | 7.99 | 1.00 | 0.9918 | 1.000 |
| rw4k_qd1 | 0.043 | 0.000 | 0.307 | 0.025 | 1.877 | 0.014 | 0.246 | 0.93 | 0.00 | 0.0000 | 1.000 |
| rw4k_qd4 | 0.082 | 0.074 | 0.599 | 0.078 | 3.535 | 0.027 | 0.840 | 3.58 | 0.13 | 0.0000 | 1.000 |
| rw4k_qd16 | 0.082 | 0.074 | 0.554 | 0.254 | 3.530 | 0.027 | 0.839 | 5.91 | 0.88 | 0.3059 | 1.000 |
| mix70r_4k_qd1 | 0.210 | 0.000 | 0.108 | 0.307 | 0.556 | 1.375 | 0.254 | 0.93 | 0.00 | 0.0000 | 1.000 |
| mix70r_4k_qd4 | 0.643 | 0.295 | 0.279 | 0.640 | 1.102 | 2.555 | 0.851 | 3.58 | 0.06 | 0.0000 | 1.000 |
| mix70r_4k_qd16 | 0.703 | 0.524 | 0.252 | 0.656 | 1.119 | 2.631 | 0.922 | 6.90 | 0.94 | 0.6086 | 1.000 |
| rr_1blk_qd8 | 0.578 | 0.048 | 0.663 | 0.971 | 0.305 | 2.597 | 0.372 | 5.22 | 0.01 | 0.0000 | 1.000 |
| rr_2blk_qd8 | 1.000 | 0.399 | 0.611 | 1.000 | 0.211 | 3.486 | 0.792 | 6.21 | 0.01 | 0.0000 | 1.000 |
| rr_4blk_qd8 | 1.000 | 0.436 | 0.326 | 0.975 | 0.113 | 3.669 | 0.896 | 7.45 | 0.01 | 0.0000 | 1.000 |
| rr_8blk_qd8 | 1.000 | 0.456 | 0.069 | 0.847 | 0.059 | 3.770 | 0.953 | 7.82 | 0.01 | 0.0000 | 1.000 |
| sw_1blk_qd8 | 0.414 | 0.399 | 0.849 | 0.353 | 2.909 | 0.162 | 0.586 | 6.22 | 0.01 | 0.0000 | 1.000 |
| sw_4blk_qd8 | 0.141 | 0.137 | 0.704 | 0.114 | 3.393 | 0.051 | 0.806 | 7.69 | 0.01 | 0.0000 | 1.000 |
| sw_8blk_qd8 | 0.084 | 0.082 | 0.622 | 0.062 | 3.640 | 0.028 | 0.881 | 7.83 | 0.01 | 0.0000 | 1.000 |
| rr4k_qd8_belat10 | 1.000 | 0.483 | 0.069 | 0.847 | 0.059 | 3.770 | 0.980 | 7.82 | 0.01 | 0.0000 | 1.000 |
| rr4k_qd8_belat100 | 1.000 | 0.403 | 0.069 | 0.844 | 0.058 | 3.756 | 0.898 | 7.82 | 0.01 | 0.0000 | 1.000 |
| rr4k_qd8_belat400 | 1.000 | 0.146 | 0.068 | 0.829 | 0.057 | 3.690 | 0.633 | 7.83 | 0.01 | 0.0000 | 1.000 |
| sched_fifo | 0.536 | 0.532 | 0.388 | 0.582 | 1.838 | 1.858 | 0.886 | 8.00 | 3.98 | 0.0000 | 1.000 |
| sched_rdprio | 0.745 | 0.644 | 0.288 | 0.741 | 1.094 | 2.623 | 0.890 | 7.99 | 3.60 | 0.0000 | 0.863 |
| sched_fifo+wrbatch | 0.337 | 0.334 | 0.490 | 0.448 | 2.647 | 0.978 | 0.849 | 8.00 | 4.00 | 0.0000 | 0.755 |
| sched_rdprio+wrbatch | 0.745 | 0.644 | 0.288 | 0.741 | 1.094 | 2.623 | 0.890 | 7.99 | 3.60 | 0.0000 | 0.863 |
| fair_equal4 | 0.718 | 0.593 | 0.279 | 0.668 | 1.134 | 2.652 | 0.942 | 8.00 | 4.00 | 0.0000 | 1.000 |
| fair_weights_1_1_2_4 | 0.717 | 0.598 | 0.289 | 0.693 | 1.137 | 2.655 | 0.943 | 8.00 | 4.00 | 0.0000 | 0.982 |
| noisy_neighbour_unlimited | 0.579 | 0.544 | 0.365 | 0.630 | 1.656 | 2.117 | 0.935 | 7.95 | 1.93 | 0.0000 | 0.832 |
| noisy_neighbour_inflight_cap2 | 0.744 | 0.669 | 0.274 | 0.737 | 1.043 | 2.723 | 0.942 | 7.68 | 1.01 | 0.9714 | 0.994 |
| noisy_neighbour_rate_cap | 0.736 | 0.668 | 0.301 | 0.717 | 1.049 | 2.761 | 0.948 | 7.53 | 1.05 | 0.9171 | 0.994 |
| noisy_neighbour_victims_only | 1.000 | 0.456 | 0.069 | 0.846 | 0.059 | 3.770 | 0.953 | 5.82 | 0.01 | 0.0000 | 1.000 |
| rr4k_qd8_media_error_lba5 | 1.000 | 0.448 | 0.075 | 0.833 | 0.059 | 3.704 | 0.936 | 7.81 | 0.01 | 0.0000 | 1.000 |

### Trace-FIFO view (separate pass with the trace enabled)

| workload | trace samples | queue wait mean / p99 / max | backend time mean / p99 | fetch→post mean / p99 / max |
|---|---:|---|---|---|
| rr4k_qd1 | 695 | 10.0 / 10 / 10 | 594.0 / 594 | 2075.0 / 2075 / 2075 |
| rr4k_qd2 | 1010 | 10.0 / 10 / 10 | 863.3 / 1114 | 2782.2 / 2892 / 2892 |
| rr4k_qd4 | 1368 | 10.0 / 10 / 10 | 2277.1 / 2280 | 4279.1 / 4280 / 4288 |
| rr4k_qd8 | 1367 | 10.0 / 10 / 10 | 5471.0 / 5471 | 8659.0 / 8660 / 8668 |
| rr4k_qd16 | 1367 | 4268.0 / 4276 / 4276 | 5471.0 / 5471 | 13186.0 / 13194 / 13194 |
| rw4k_qd1 | 677 | 10.0 / 10 / 10 | 96.0 / 96 | 2136.0 / 2136 / 2136 |
| rw4k_qd4 | 1273 | 247.6 / 2859 / 4116 | 96.0 / 96 | 4569.2 / 5960 / 7808 |
| rw4k_qd16 | 1270 | 3466.5 / 10651 / 11859 | 96.0 / 96 | 10916.7 / 15214 / 18570 |
| mix70r_4k_qd1 | 690 | 10.0 / 10 / 10 | 455.4 / 594 | 2092.0 / 2136 / 2136 |
| mix70r_4k_qd4 | 1307 | 113.1 / 2589 / 3508 | 1197.1 / 2933 | 4411.5 / 7115 / 9367 |
| mix70r_4k_qd16 | 1338 | 3883.3 / 9940 / 11137 | 2152.2 / 5657 | 11919.2 / 18132 / 21724 |
| rr_1blk_qd8 | 1418 | 3.0 / 3 / 3 | 123.5 / 123 | 1314.7 / 1939 / 2620 |
| rr_2blk_qd8 | 984 | 4.0 / 4 / 4 | 1029.8 / 1311 | 1889.8 / 2180 / 2316 |
| rr_4blk_qd8 | 526 | 6.0 / 6 / 6 | 2830.9 / 2831 | 4314.0 / 4320 / 4320 |
| rr_8blk_qd8 | 272 | 10.0 / 10 / 10 | 5471.0 / 5471 | 8656.5 / 8660 / 8668 |
| sw_1blk_qd8 | 1504 | 3.0 / 3 / 3 | 82.0 / 82 | 1234.6 / 1234 / 1740 |
| sw_4blk_qd8 | 479 | 6.0 / 6 / 6 | 88.0 / 88 | 4877.0 / 4892 / 4999 |
| sw_8blk_qd8 | 261 | 10.0 / 10 / 10 | 96.0 / 96 | 9057.7 / 9418 / 9419 |
| rr4k_qd8_belat10 | 272 | 10.0 / 10 / 10 | 5471.0 / 5471 | 8656.4 / 8660 / 8668 |
| rr4k_qd8_belat100 | 271 | 10.0 / 10 / 10 | 5491.0 / 5491 | 8688.7 / 8692 / 8700 |
| rr4k_qd8_belat400 | 266 | 10.0 / 10 / 10 | 5591.0 / 5591 | 8850.7 / 8851 / 8851 |
| sched_fifo | 1320 | 12342.5 / 23505 / 28547 | 912.7 / 3604 | 21899.7 / 33251 / 39047 |
| sched_rdprio | 1329 | 10820.4 / 31351 / 36403 | 2451.2 / 5526 | 20314.3 / 40089 / 45140 |
| sched_fifo+wrbatch | 1294 | 15311.8 / 36577 / 37068 | 510.4 / 2529 | 25208.1 / 46196 / 50607 |
| sched_rdprio+wrbatch | 1329 | 10820.4 / 31352 / 36402 | 2451.2 / 5526 | 20313.9 / 40089 / 45138 |
| fair_equal4 | 1352 | 17347.9 / 24814 / 26803 | 2233.4 / 5678 | 26652.8 / 34108 / 36817 |
| fair_weights_1_1_2_4 | 1354 | 17207.0 / 35164 / 38916 | 2218.7 / 5673 | 26472.4 / 45851 / 49586 |
| noisy_neighbour_unlimited | 1347 | 5220.9 / 15419 / 22245 | 1299.0 / 5184 | 14470.7 / 26288 / 33210 |
| noisy_neighbour_inflight_cap2 | 1345 | 4355.2 / 21382 / 23300 | 2174.1 / 5384 | 13209.8 / 29366 / 31803 |
| noisy_neighbour_rate_cap | 1362 | 4310.5 / 19048 / 23462 | 1944.5 / 5494 | 12873.8 / 29154 / 34403 |
| noisy_neighbour_victims_only | 1367 | 10.0 / 10 / 10 | 4466.3 / 4470 | 6469.0 / 6470 / 6478 |
| rr4k_qd8_media_error_lba5 | 1386 | 10.0 / 10 / 10 | 5396.8 / 5471 | 8534.8 / 9231 / 9915 |

### Per-tenant results

| workload | tenant | cmds | IOPS / Mcycle | B / cycle | host read p50/p99/max | host write p50/p99/max |
|---|---:|---:|---:|---:|---|---|
| sched_fifo | 0 | 340 | 226.7 | 0.928 | 18084/22968/23342 | n/a/n/a/n/a |
| sched_fifo | 1 | 337 | 224.7 | 0.920 | 18084/23044/23246 | n/a/n/a/n/a |
| sched_fifo | 2 | 347 | 231.3 | 0.948 | n/a/n/a/n/a | 72436/80244/83678 |
| sched_fifo | 3 | 338 | 225.3 | 0.923 | n/a/n/a/n/a | 73060/86368/88748 |
| sched_rdprio | 0 | 479 | 319.3 | 1.308 | 10950/19044/19092 | n/a/n/a/n/a |
| sched_rdprio | 1 | 479 | 319.3 | 1.308 | 10950/19044/19413 | n/a/n/a/n/a |
| sched_rdprio | 2 | 206 | 137.3 | 0.562 | n/a/n/a/n/a | 126288/127990/135173 |
| sched_rdprio | 3 | 206 | 137.3 | 0.562 | n/a/n/a/n/a | 126288/127542/136097 |
| sched_fifo+wrbatch | 0 | 179 | 119.3 | 0.489 | 36852/39674/39782 | n/a/n/a/n/a |
| sched_fifo+wrbatch | 1 | 177 | 118.0 | 0.483 | 36844/40024/40456 | n/a/n/a/n/a |
| sched_fifo+wrbatch | 2 | 644 | 429.3 | 1.759 | n/a/n/a/n/a | 38050/58172/62698 |
| sched_fifo+wrbatch | 3 | 337 | 224.7 | 0.920 | n/a/n/a/n/a | 71206/111936/115806 |
| sched_rdprio+wrbatch | 0 | 479 | 319.3 | 1.308 | 10950/19044/19092 | n/a/n/a/n/a |
| sched_rdprio+wrbatch | 1 | 479 | 319.3 | 1.308 | 10950/19044/19337 | n/a/n/a/n/a |
| sched_rdprio+wrbatch | 2 | 206 | 137.3 | 0.562 | n/a/n/a/n/a | 126288/127986/135173 |
| sched_rdprio+wrbatch | 3 | 206 | 137.3 | 0.562 | n/a/n/a/n/a | 126288/127546/136093 |
| fair_equal4 | 0 | 344 | 229.3 | 0.939 | 35496/46300/49970 | 34936/45872/46254 |
| fair_equal4 | 1 | 343 | 228.7 | 0.937 | 35542/45166/47130 | 35968/47372/49886 |
| fair_equal4 | 2 | 349 | 232.7 | 0.953 | 34818/43664/45854 | 34750/43484/44038 |
| fair_equal4 | 3 | 349 | 232.7 | 0.953 | 35032/41926/42810 | 34976/n/a/44968 |
| fair_weights_1_1_2_4 | 0 | 213 | 142.0 | 0.582 | 58720/69566/69628 | 57716/n/a/70370 |
| fair_weights_1_1_2_4 | 1 | 211 | 140.7 | 0.576 | 58282/72412/73128 | 58540/n/a/76912 |
| fair_weights_1_1_2_4 | 2 | 355 | 236.7 | 0.969 | 35130/43392/46172 | 35056/n/a/44590 |
| fair_weights_1_1_2_4 | 3 | 609 | 406.0 | 1.663 | 19690/28864/32548 | 19558/29010/30351 |
| noisy_neighbour_unlimited | 0 | 618 | 412.0 | 1.688 | n/a/n/a/n/a | 80894/99047/107477 |
| noisy_neighbour_unlimited | 1 | 257 | 171.3 | 0.702 | 11781/17229/18142 | n/a/n/a/n/a |
| noisy_neighbour_unlimited | 2 | 257 | 171.3 | 0.702 | 11891/16215/18651 | n/a/n/a/n/a |
| noisy_neighbour_unlimited | 3 | 257 | 171.3 | 0.702 | 11448/18199/18875 | n/a/n/a/n/a |
| noisy_neighbour_inflight_cap2 | 0 | 393 | 262.0 | 1.073 | n/a/n/a/n/a | 130240/144093/145525 |
| noisy_neighbour_inflight_cap2 | 1 | 335 | 223.3 | 0.915 | 8772/14336/14908 | n/a/n/a/n/a |
| noisy_neighbour_inflight_cap2 | 2 | 337 | 224.7 | 0.920 | 8776/14240/14768 | n/a/n/a/n/a |
| noisy_neighbour_inflight_cap2 | 3 | 321 | 214.0 | 0.876 | 8776/14909/16353 | n/a/n/a/n/a |
| noisy_neighbour_rate_cap | 0 | 396 | 264.0 | 1.081 | n/a/n/a/n/a | 131572/141364/143488 |
| noisy_neighbour_rate_cap | 1 | 338 | 225.3 | 0.923 | 8788/12439/13121 | n/a/n/a/n/a |
| noisy_neighbour_rate_cap | 2 | 338 | 225.3 | 0.923 | 8799/12893/13796 | n/a/n/a/n/a |
| noisy_neighbour_rate_cap | 3 | 330 | 220.0 | 0.901 | 8856/13309/16248 | n/a/n/a/n/a |
| noisy_neighbour_victims_only | 1 | 459 | 306.0 | 1.253 | 6568/6572/6616 | n/a/n/a/n/a |
| noisy_neighbour_victims_only | 2 | 459 | 306.0 | 1.253 | 6568/6572/6584 | n/a/n/a/n/a |
| noisy_neighbour_victims_only | 3 | 458 | 305.3 | 1.251 | 6568/6572/6572 | n/a/n/a/n/a |

