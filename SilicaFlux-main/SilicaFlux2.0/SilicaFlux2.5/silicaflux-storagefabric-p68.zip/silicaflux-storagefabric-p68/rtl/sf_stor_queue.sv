// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_queue -- one tenant queue pair (docs/02_HOST_INTERFACE.md §2, §3, §8)
//
//   * tenant register page (rings, doorbells, status, interrupt, per-tenant counters)
//   * descriptor fetch: batches of up to SQ_BATCH descriptors from the tenant's SQ ring, through the PROTECTED DMA
//     (domain = TID, hardware-bound); a fetch outside the tenant's windows fails in the DMA checker, not here
//   * parse + validation (sf_stor_validate); valid data commands go to the in-order command FIFO for the scheduler,
//     validation failures and GET_CAPACITY become "immediate" commands completed by this block
//   * completion posting: builds the 32-byte completion entry in local memory and writes it to the CQ through the
//     protected DMA, phase bit last in the entry; never overruns the CQ (stalls until the host advances CQ_HEAD)
//
//   The tenant id of everything this block produces is TID, a parameter fixed by the instance: nothing a tenant writes
//   can change it.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_queue
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int TID        = 0,
  parameter int NS_N       = 8,
  parameter int MDTS       = 8,
  parameter int SQ_MAX     = 32,
  parameter int CQ_MAX     = 32,
  parameter int SQ_BATCH   = 4,
  parameter int PQ         = 4,
  parameter int AW         = 48,
  parameter int WORDS_LOG2 = 13,
  parameter int LM_SQ_WORD = 32,     // word address of this tenant's SQ landing buffer
  parameter int LM_CQ_WORD = 160,    // word address of this tenant's CQE build buffer
  parameter int LM_SQ_BYTE = 256,    // the same, in bytes (DMA addresses)
  parameter int LM_CQ_BYTE = 1280
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  input  wire logic [31:0]            now_i,
  // ---- tenant MMIO (already selected by the hardware function binding)
  input  wire logic                   t_valid,
  input  wire logic                   t_we,
  input  wire logic [11:0]            t_addr,
  input  wire logic [31:0]            t_wdata,
  output logic [31:0]                 t_rdata,
  output logic                        t_err,
  // ---- management plane / global
  input  wire logic                   cfg_allowed,
  input  wire logic                   glb_enable,
  input  wire logic                   rst_req_i,          // fabric soft reset
  input  wire logic                   pf_active_i,
  input  wire logic [31:0]            caps0_i,
  input  wire logic [31:0]            caps1_hi_i,         // CAPS1 without the owned-namespace mask
  input  wire logic                   be_discard_i,
  input  wire logic [NS_N-1:0]        ns_valid_i,
  input  wire logic [NS_N*4-1:0]      ns_owner_i,
  input  wire logic [NS_N-1:0]        ns_ro_i,
  input  wire logic [NS_N-1:0]        ns_enc_i,
  input  wire logic [NS_N-1:0]        ns_keyok_i,         // key slot of the namespace is ready
  input  wire logic [NS_N*64-1:0]     ns_size_i,
  input  wire logic [7:0]             inflight_i,
  input  wire logic                   throttle_i,         // scheduler held this queue's head back this cycle
  // ---- to the scheduler
  output cmd_t                        head_o,
  output logic                        head_valid_o,       // a normal (slot-needing) command is at the head
  input  wire logic                   head_pop_i,
  output logic                        enabled_o,
  output logic                        abort_o,            // pulse: abort this tenant's in-flight commands (queue reset)
  // ---- completions from slots
  input  wire logic                   cpl_valid_i,
  output logic                        cpl_ready_o,
  input  wire cpl_t                   cpl_i,
  // ---- protected-DMA tasks: 0 = descriptor fetch, 1 = completion post
  output logic [1:0]                  d_valid,
  input  wire logic [1:0]             d_gnt,
  output logic [1:0]                  d_dir,
  output logic [2*AW-1:0]             d_host,
  output logic [2*16-1:0]             d_lm,
  output logic [2*24-1:0]             d_len,
  input  wire logic [1:0]             d_rsp,
  input  wire logic [1:0]             d_ok,
  input  wire logic [2*8-1:0]         d_err,
  input  wire logic [2*4-1:0]         d_fault,
  // ---- local-memory client
  output logic                        lm_req,
  output logic                        lm_we,
  output logic [WORDS_LOG2-1:0]       lm_addr,
  output logic [63:0]                 lm_wdata,
  input  wire logic                   lm_gnt,
  input  wire logic                   lm_rvalid,
  input  wire logic [63:0]            lm_rdata,
  // ---- outputs
  output logic                        irq_o,
  output logic                        ev_post,            // pulse: a completion entry was committed to the CQ
  output cpl_t                        ev_cpl,
  output logic [31:0]                 ev_t_post,
  output logic                        ev_viol,
  output logic                        ev_reject,
  output logic                        ev_fetch,
  output logic                        ev_cq_stall,        // level: a completion is waiting for CQ space
  output logic                        ev_dma_fault,
  output logic                        idle_o,
  output logic                        fatal_o
);
  // ------------------------------------------------------------------ registers
  logic [63:0] sq_base, cq_base;
  logic [7:0]  sq_size, cq_size;
  logic [7:0]  sq_head, sq_tail, cq_head, cq_tail;   // cq_tail: entries whose DMA completed;  cq_wp: write pointer (advanced when a post is issued)
  logic [7:0]  cq_wp;
  logic        phase;
  logic        enabled, fatal, sq_err, cq_err, db_err, qerr_irq;
  logic [7:0]  last_qerr;
  logic [1:0]  irq_en;
  logic [31:0] c_done, c_err, c_rd, c_wr, c_flush, c_thr, c_viol, c_bytes;
  assign enabled_o = enabled;
  assign fatal_o   = fatal;

  wire [7:0] sq_mask = sq_size - 8'd1;
  wire [7:0] cq_mask = cq_size - 8'd1;
  wire sq_geom_ok = (sq_size >= 8'd2) && (sq_size <= 8'(SQ_MAX)) && ((sq_size & (sq_size - 8'd1)) == 8'd0) && (sq_base[5:0] == 6'h0);
  wire cq_geom_ok = (cq_size >= 8'd2) && (cq_size <= 8'(CQ_MAX)) && ((cq_size & (cq_size - 8'd1)) == 8'd0) && (cq_base[4:0] == 5'h0);

  // owned-namespace mask for CAPS1
  logic [15:0] owned;
  always_comb begin
    owned = '0;
    for (int n = 0; n < NS_N; n++) if (n < 16) owned[n] = ns_valid_i[n] && (ns_owner_i[n*4 +: 4] == 4'(TID));
  end

  wire [7:0] sq_avail  = (sq_tail - sq_head) & sq_mask;
  wire       cq_nonempty = (cq_wp != cq_head);

  // ------------------------------------------------------------------ command FIFO (in order)
  cmd_t        fifo [PQ];
  logic [$clog2(PQ):0] f_cnt;
  logic [$clog2(PQ)-1:0] f_rp, f_wp;
  wire  f_full  = (int'(f_cnt) == PQ);
  wire  f_empty = (int'(f_cnt) == 0);
  cmd_t f_head;
  assign f_head       = fifo[f_rp];
  assign head_o       = f_head;
  assign head_valid_o = !f_empty && !f_head.imm && enabled && !fatal;

  // ------------------------------------------------------------------ register reads
  always_comb begin
    t_rdata = 32'h0; t_err = 1'b0;
    case (t_addr[11:2])
      10'h000: t_rdata = SFS_ID_TENANT;
      10'h001: t_rdata = SFS_ABI_VERSION;
      10'h002: t_rdata = caps0_i;
      10'h003: t_rdata = {owned, caps1_hi_i[15:0]};
      10'h004: t_rdata = {30'h0, 1'b0, enabled};                                  // CTRL (reset bit reads 0)
      10'h005: t_rdata = {16'h0, last_qerr, 2'b0, idle_o, (sq_avail == 8'd0), fatal, cq_err, sq_err, enabled};
      10'h008: t_rdata = sq_base[31:0];
      10'h009: t_rdata = sq_base[63:32];
      10'h00A: t_rdata = {24'h0, sq_size};
      10'h00C: t_rdata = cq_base[31:0];
      10'h00D: t_rdata = cq_base[63:32];
      10'h00E: t_rdata = {24'h0, cq_size};
      10'h010: t_rdata = {24'h0, sq_tail};
      10'h011: t_rdata = {24'h0, cq_head};
      10'h012: t_rdata = {24'h0, sq_head};
      10'h013: t_rdata = {24'h0, cq_wp};
      10'h014: t_rdata = {30'h0, irq_en};
      10'h015: t_rdata = {29'h0, db_err, qerr_irq, cq_nonempty};
      10'h018: t_rdata = {24'h0, inflight_i};
      10'h020: t_rdata = c_done;
      10'h021: t_rdata = c_err;
      10'h022: t_rdata = c_rd;
      10'h023: t_rdata = c_wr;
      10'h024: t_rdata = c_flush;
      10'h025: t_rdata = c_thr;
      10'h026: t_rdata = c_viol;
      10'h027: t_rdata = c_bytes;
      default: t_err = 1'b1;
    endcase
    if (t_addr[1:0] != 2'b00) t_err = 1'b1;
  end
  assign irq_o = (irq_en[0] && cq_nonempty) || (irq_en[1] && qerr_irq);

  // ------------------------------------------------------------------ fetch / parse state
  typedef enum logic [3:0] {F_IDLE, F_DMA, F_DMAW, F_RD, F_RDW, F_PUSH, F_FATAL} fstate_t;
  fstate_t     fst;
  logic [2:0]  f_n, f_k;                 // descriptors in the batch / index being parsed
  logic [3:0]  f_w;                      // word index 0..7
  logic [511:0] dbuf;
  logic [15:0] nfetch_dbg;

  // validation of dbuf
  logic        v_ok;
  logic [7:0]  v_status, v_detail, v_op, v_nsid;
  logic [15:0] v_flags, v_txn;
  logic [63:0] v_lba, v_addr;
  logic [31:0] v_nblk, v_hcrc;
  wire  [7:0]  nsid_q   = dbuf[32*1+16 +: 8];
  wire         ns_known = (int'(nsid_q) < NS_N);
  logic        ns_v_s, ns_ro_s, ns_enc_s, ns_key_s;
  logic [3:0]  ns_own_s;
  logic [63:0] ns_size_s;
  always_comb begin
    ns_v_s = 1'b0; ns_ro_s = 1'b0; ns_enc_s = 1'b0; ns_key_s = 1'b0; ns_own_s = 4'hF; ns_size_s = '0;
    for (int n = 0; n < NS_N; n++) if (int'(nsid_q) == n) begin
      ns_v_s = ns_valid_i[n]; ns_ro_s = ns_ro_i[n]; ns_enc_s = ns_enc_i[n]; ns_key_s = ns_keyok_i[n];
      ns_own_s = ns_owner_i[n*4 +: 4]; ns_size_s = ns_size_i[n*64 +: 64];
    end
  end
  sf_stor_validate #(.MDTS(MDTS)) u_val (
    .desc_i(dbuf), .tenant_i(4'(TID)), .ns_known_i(ns_known), .ns_valid_i(ns_v_s), .ns_owner_i(ns_own_s), .ns_ro_i(ns_ro_s),
    .ns_size_i(ns_size_s), .be_discard_i, .ns_enc_i(ns_enc_s), .key_ready_i(ns_key_s),
    .ok_o(v_ok), .status_o(v_status), .detail_o(v_detail), .op_o(v_op), .flags_o(v_flags), .txn_o(v_txn), .nsid_o(v_nsid),
    .lba_o(v_lba), .nblk_o(v_nblk), .addr_o(v_addr), .hcrc_o(v_hcrc)
  );

  cmd_t push_cmd;
  always_comb begin
    push_cmd = '0;
    push_cmd.op = v_op; push_cmd.flags = v_flags; push_cmd.txn = v_txn; push_cmd.nsid = v_nsid; push_cmd.lba = v_lba;
    push_cmd.nblk = v_nblk; push_cmd.addr = v_addr; push_cmd.hcrc = v_hcrc; push_cmd.status = v_status;
    push_cmd.detail = v_detail; push_cmd.t_fetch = now_i;
    push_cmd.imm = !v_ok || (v_op == OP_GET_CAPACITY);
    if (v_ok && v_op == OP_GET_CAPACITY) push_cmd.lba = ns_size_s;      // result carried in .lba
  end
  cpl_t imm_cpl;
  always_comb begin
    imm_cpl = '0;
    imm_cpl.txn = f_head.txn; imm_cpl.status = f_head.status; imm_cpl.detail = f_head.detail; imm_cpl.op = f_head.op;
    imm_cpl.t_fetch = f_head.t_fetch; imm_cpl.t_admit = now_i; imm_cpl.t_issue = now_i; imm_cpl.t_bedone = now_i;
    if (f_head.op == OP_GET_CAPACITY && f_head.status == ST_SUCCESS) begin
      imm_cpl.res0 = f_head.lba[31:0]; imm_cpl.res1 = f_head.lba[63:32];
    end
  end

  // fetch sizing
  wire [7:0] ring_room = sq_size - sq_head;                       // entries to the end of the ring
  logic [7:0] n_fetch;
  logic [7:0] fifo_room;
  always_comb begin
    fifo_room = 8'(PQ) - 8'(f_cnt);
    n_fetch   = sq_avail;
    if (n_fetch > ring_room)       n_fetch = ring_room;
    if (n_fetch > 8'(SQ_BATCH))    n_fetch = 8'(SQ_BATCH);
    if (n_fetch > fifo_room)       n_fetch = fifo_room;
  end
  wire can_fetch = enabled && !fatal && glb_enable && !pf_active_i && (n_fetch != 8'd0);

  // lm client for the parse path / post path (shared; only one active at a time by construction)
  logic        pr_req;  logic [WORDS_LOG2-1:0] pr_addr;
  logic        po_req;  logic po_we; logic [WORDS_LOG2-1:0] po_addr; logic [63:0] po_wdata;
  // The parse (read) path and the completion-build (write) path share this client port and can be active together.
  // The completion path has priority, so a grant belongs to the parse path only when the completion path is idle.
  wire pr_gnt = lm_gnt && !po_req;
  assign lm_req   = pr_req || po_req;
  assign lm_we    = po_req && po_we;
  assign lm_addr  = po_req ? po_addr : pr_addr;
  assign lm_wdata = po_wdata;

  assign d_valid[0] = (fst == F_DMA);
  assign d_dir[0]   = 1'b0;
  assign d_host[0*AW +: AW] = sq_base[AW-1:0] + AW'({sq_head, 6'h0});
  assign d_lm[0*16 +: 16]   = 16'(LM_SQ_BYTE);
  assign d_len[0*24 +: 24]  = 24'(f_n) * 24'd64;

  // ------------------------------------------------------------------ completion posting state
  typedef enum logic [3:0] {P_IDLE, P_SPACE, P_BUILD, P_DMA, P_DMAW} pstate_t;
  pstate_t pst;
  cpl_t    cur;
  logic    cur_from_imm;
  logic [7:0] cq_slot_q;                // CQ slot of the post in flight
  logic [2:0] p_w;
  logic    p_alt;                       // alternate between immediate and slot completions
  wire     imm_head = !f_empty && f_head.imm;
  wire [7:0] cq_next = (cq_wp + 8'd1) & cq_mask;
  wire     cq_has_space = (cq_next != cq_head);
  assign   ev_cq_stall = (pst == P_SPACE) && !cq_has_space;
  logic [31:0] cur_latency;
  logic        cq_phase_q;              // phase bit of the entry being built (phase at its slot)
  logic [63:0] cqe_word [4];
  always_comb begin
    cqe_word[0] = {  // W1 | W0
      cur.nblk_done, cur.op, 4'h0, cur.crc_valid, cur.enc, cur.pi_ver, cur.durable,
      cur.detail, cur.status, cur.txn };
    cqe_word[1] = {cur.res1, cur.res0};
    cqe_word[2] = {cur_latency, 16'(TID), 8'h0, sq_head};
    cqe_word[3] = {31'h0, cq_phase_q, 32'h0};
  end
  assign d_valid[1] = (pst == P_DMA);
  assign d_dir[1]   = 1'b1;
  assign d_host[1*AW +: AW] = cq_base[AW-1:0] + AW'({cq_slot_q, 5'h0});
  assign d_lm[1*16 +: 16]   = 16'(LM_CQ_BYTE);
  assign d_len[1*24 +: 24]  = 24'd32;

  assign idle_o = (inflight_i == 8'd0) && f_empty && (pst == P_IDLE) && (fst == F_IDLE);

  // ------------------------------------------------------------------ doorbell / geometry checks (combinational on the write data)
  logic db_sq_ok, db_cq_ok, sz_sq_ok, sz_cq_ok;
  logic [7:0] db_kk, db_oldo, db_adv, db_outs;
  always_comb begin
    db_kk   = (t_wdata[7:0] - sq_tail) & sq_mask;
    db_oldo = (sq_tail - sq_head) & sq_mask;
    db_sq_ok = enabled && (t_wdata[31:8] == 24'h0) && (t_wdata[7:0] < sq_size) && ((db_oldo + db_kk) < sq_size);
    db_adv  = (t_wdata[7:0] - cq_head) & cq_mask;
    db_outs = (cq_wp - cq_head) & cq_mask;
    db_cq_ok = enabled && (t_wdata[31:8] == 24'h0) && (t_wdata[7:0] < cq_size) && (db_adv <= db_outs);
    sz_sq_ok = (t_wdata[31:8] == 24'h0) && (t_wdata[7:0] >= 8'd2) && (t_wdata[7:0] <= 8'(SQ_MAX)) &&
               ((t_wdata[7:0] & (t_wdata[7:0] - 8'd1)) == 8'd0);
    sz_cq_ok = (t_wdata[31:8] == 24'h0) && (t_wdata[7:0] >= 8'd2) && (t_wdata[7:0] <= 8'(CQ_MAX)) &&
               ((t_wdata[7:0] & (t_wdata[7:0] - 8'd1)) == 8'd0);
  end

  // ------------------------------------------------------------------ completion source selection (combinational)
  logic pick_slot, pick_imm, drop_slot, drop_imm, pop_imm;
  always_comb begin
    pick_slot = 1'b0; pick_imm = 1'b0; drop_slot = 1'b0; drop_imm = 1'b0;
    if (pst == P_IDLE) begin
      if (cq_err) begin drop_slot = cpl_valid_i; drop_imm = imm_head; end
      else if (cpl_valid_i && (!imm_head || p_alt)) pick_slot = 1'b1;
      else if (imm_head) pick_imm = 1'b1;
    end
  end
  assign pop_imm     = pick_imm || drop_imm;
  assign cpl_ready_o = pick_slot || drop_slot;

  // ------------------------------------------------------------------ sequential logic
  logic        reset_q;                 // queue reset request (register write or fabric reset)
  assign abort_o = reset_q || rst_req_i;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sq_base <= '0; cq_base <= '0; sq_size <= '0; cq_size <= '0; sq_head <= '0; sq_tail <= '0; cq_head <= '0; cq_tail <= '0; cq_wp <= '0; cq_slot_q <= '0; cq_phase_q <= 1'b1;
      phase <= 1'b1; enabled <= 1'b0; fatal <= 1'b0; sq_err <= 1'b0; cq_err <= 1'b0; db_err <= 1'b0; qerr_irq <= 1'b0;
      last_qerr <= '0; irq_en <= '0;
      c_done <= '0; c_err <= '0; c_rd <= '0; c_wr <= '0; c_flush <= '0; c_thr <= '0; c_viol <= '0; c_bytes <= '0;
      f_cnt <= '0; f_rp <= '0; f_wp <= '0; fst <= F_IDLE; f_n <= '0; f_k <= '0; f_w <= '0; dbuf <= '0; pr_req <= 1'b0; pr_addr <= '0;
      pst <= P_IDLE; cur <= '0; cur_from_imm <= 1'b0; p_w <= '0; p_alt <= 1'b0; po_req <= 1'b0; po_we <= 1'b0; po_addr <= '0;
      po_wdata <= '0; cur_latency <= '0; reset_q <= 1'b0;
      ev_post <= 1'b0; ev_cpl <= '0; ev_t_post <= '0; ev_viol <= 1'b0; ev_reject <= 1'b0; ev_fetch <= 1'b0; ev_dma_fault <= 1'b0;
      nfetch_dbg <= '0;
      for (int i = 0; i < PQ; i++) fifo[i] <= '0;
    end else begin
      ev_post <= 1'b0; ev_viol <= 1'b0; ev_reject <= 1'b0; ev_fetch <= 1'b0; ev_dma_fault <= 1'b0;
      reset_q <= 1'b0;
      if (throttle_i) c_thr <= c_thr + 32'd1;

      // ---------------- register writes
      if (t_valid && t_we && !t_err) begin
        case (t_addr[11:2])
          10'h004: begin                                       // CTRL
            if (t_wdata[1]) reset_q <= 1'b1;
            if (t_wdata[0] && !t_wdata[1]) begin
              if (cfg_allowed && sq_geom_ok && cq_geom_ok) begin enabled <= 1'b1; end
              else if (!enabled) begin sq_err <= 1'b1; qerr_irq <= 1'b1; last_qerr <= 8'hFE; end
            end else if (!t_wdata[0]) enabled <= 1'b0;
          end
          10'h008: if (!enabled) sq_base[31:0]  <= t_wdata;
          10'h009: if (!enabled) sq_base[63:32] <= t_wdata;
          10'h00A: if (!enabled) begin if (sz_sq_ok) sq_size <= t_wdata[7:0]; else db_err <= 1'b1; end
          10'h00C: if (!enabled) cq_base[31:0]  <= t_wdata;
          10'h00D: if (!enabled) cq_base[63:32] <= t_wdata;
          10'h00E: if (!enabled) begin if (sz_cq_ok) cq_size <= t_wdata[7:0]; else db_err <= 1'b1; end
          10'h010: begin if (db_sq_ok) sq_tail <= t_wdata[7:0]; else db_err <= 1'b1; end   // SQ_TAIL doorbell
          10'h011: begin if (db_cq_ok) cq_head <= t_wdata[7:0]; else db_err <= 1'b1; end   // CQ_HEAD doorbell
          10'h014: irq_en <= t_wdata[1:0];
          10'h015: begin if (t_wdata[1]) qerr_irq <= 1'b0; if (t_wdata[2]) db_err <= 1'b0; end
          default: ;
        endcase
      end

      // ---------------- queue reset (register or fabric)
      if (reset_q || rst_req_i) begin
        enabled <= 1'b0; fatal <= 1'b0; sq_err <= 1'b0; cq_err <= 1'b0; last_qerr <= '0;
        sq_head <= '0; sq_tail <= '0; cq_head <= '0; cq_tail <= '0; cq_wp <= '0; cq_slot_q <= '0; phase <= 1'b1;
        f_cnt <= '0; f_rp <= '0; f_wp <= '0; fst <= F_IDLE; pr_req <= 1'b0; pst <= P_IDLE; po_req <= 1'b0;
        reset_q <= 1'b0;
      end else begin
        // ---------------- descriptor fetch / parse
        case (fst)
          F_IDLE: if (can_fetch) begin f_n <= 3'(n_fetch); fst <= F_DMA; end
          F_DMA:  if (d_gnt[0]) fst <= F_DMAW;
          F_DMAW: if (d_rsp[0]) begin
                    if (d_ok[0]) begin
                      sq_head <= (sq_head + 8'(f_n)) & sq_mask;
                      f_k <= '0; f_w <= '0; fst <= F_RD; pr_req <= 1'b1;
                      pr_addr <= WORDS_LOG2'(LM_SQ_WORD);
                      ev_fetch <= 1'b1;
                    end else begin
                      fatal <= 1'b1; sq_err <= 1'b1; qerr_irq <= 1'b1; last_qerr <= d_err[7:0]; ev_dma_fault <= 1'b1; fst <= F_FATAL;
                    end
                  end
          F_RD:   if (pr_gnt && pr_req) begin pr_req <= 1'b0; fst <= F_RDW; end
          F_RDW:  if (lm_rvalid) begin
                    dbuf[64*int'(f_w[2:0]) +: 64] <= lm_rdata;
                    if (f_w == 4'd7) fst <= F_PUSH;
                    else begin
                      f_w <= f_w + 4'd1; fst <= F_RD; pr_req <= 1'b1;
                      pr_addr <= WORDS_LOG2'(LM_SQ_WORD + 8 * int'(f_k) + int'(f_w) + 1);
                    end
                  end
          F_PUSH: begin
                    fifo[f_wp] <= push_cmd; f_wp <= f_wp + 1'b1;
                    if (!v_ok) ev_reject <= 1'b1;
                    if (!v_ok && (v_status == ST_TENANT_MISMATCH || v_status == ST_INVALID_NS)) ev_viol <= 1'b1;
                    if (f_k + 3'd1 == f_n) fst <= F_IDLE;
                    else begin
                      f_k <= f_k + 3'd1; f_w <= '0; fst <= F_RD; pr_req <= 1'b1;
                      pr_addr <= WORDS_LOG2'(LM_SQ_WORD + 8 * (int'(f_k) + 1));
                    end
                  end
          F_FATAL: ;
          default: fst <= F_IDLE;
        endcase

        // ---------------- completion posting
        case (pst)
          P_IDLE: begin
            if (pick_slot)     begin cur <= cpl_i;   cur_from_imm <= 1'b0; pst <= P_SPACE; p_alt <= 1'b0; end
            else if (pick_imm) begin cur <= imm_cpl; cur_from_imm <= 1'b1; pst <= P_SPACE; p_alt <= 1'b1; end
          end
          P_SPACE: if (cq_has_space) begin
            cq_slot_q <= cq_wp; cq_phase_q <= phase; cq_wp <= cq_next; if (cq_next == 8'd0) phase <= !phase;     // reserve the slot now (the host may consume it as soon as the DMA lands)
            cur_latency <= now_i - cur.t_fetch;
            p_w <= '0; po_req <= 1'b1; po_we <= 1'b1; po_addr <= WORDS_LOG2'(LM_CQ_WORD); po_wdata <= cqe_word[0]; pst <= P_BUILD;
          end
          P_BUILD: if (lm_gnt && po_req) begin
            if (p_w == 3'd3) begin po_req <= 1'b0; pst <= P_DMA; end
            else begin
              p_w <= p_w + 3'd1; po_addr <= WORDS_LOG2'(LM_CQ_WORD + int'(p_w) + 1); po_wdata <= cqe_word[p_w[1:0] + 2'd1];
            end
          end
          P_DMA:  if (d_gnt[1]) pst <= P_DMAW;
          P_DMAW: if (d_rsp[1]) begin
            if (d_ok[1]) begin
              cq_tail <= (cq_slot_q + 8'd1) & cq_mask;
              ev_post <= 1'b1; ev_cpl <= cur; ev_t_post <= now_i;
              c_done <= c_done + 32'd1;
              if (cur.status != ST_SUCCESS) c_err <= c_err + 32'd1;
              if (cur.status == ST_TENANT_MISMATCH || cur.status == ST_INVALID_NS || cur.status == ST_DMA_FAULT) c_viol <= c_viol + 32'd1;
              if (cur.status == ST_SUCCESS) begin
                if (cur.op == OP_READ)  c_rd <= c_rd + 32'(cur.nblk_done);
                if (cur.op == OP_WRITE) c_wr <= c_wr + 32'(cur.nblk_done);
              end
              if (cur.op == OP_FLUSH && cur.status == ST_SUCCESS) c_flush <= c_flush + 32'd1;
              c_bytes <= c_bytes + cur.bytes;
            end else begin
              cq_err <= 1'b1; fatal <= 1'b1; qerr_irq <= 1'b1; last_qerr <= d_err[15:8]; ev_dma_fault <= 1'b1;
            end
            pst <= P_IDLE;
          end
          default: pst <= P_IDLE;
        endcase

        // ---------------- FIFO pop (scheduler for normal commands, this block for immediate ones)
        if (head_pop_i || pop_imm) begin f_rp <= f_rp + 1'b1; end
        f_cnt <= f_cnt + (($bits(f_cnt))'(fst == F_PUSH)) - (($bits(f_cnt))'(head_pop_i || pop_imm));
      end
    end
  end
  wire unused_ok = &{1'b0, d_fault, d_err[15:8], nfetch_dbg, cur_from_imm, f_full};
endmodule
`default_nettype wire
