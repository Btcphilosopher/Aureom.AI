// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_be_store -- backend adapter for SilicaFlux-STORE (Project 60 StorageChip)  (type 1)
//
//   Turns the backend contract (docs/02 §7) into the P51/P60 host ABI: submission-queue entries written through the
//   chip's host BAR, doorbell, completion-queue polling.  It is a *driver*, not a second controller: the SSD controller,
//   FTL, ECC, NAND channel and PowerSafe-style recovery are the verified P60 blocks (docs/00_AUDIT.md).
//
//   * Isolation: P60 is the bus master for its data; it only ever sees the adapter's private BOUNCE RAM through its
//     host-memory port (hm_*).  Any other address returns a bus error.  The fabric's tenant addresses and backend LBAs
//     never reach the chip except as namespace-window LBAs chosen by the fabric.
//   * One command at a time (baseline).  WRITE: data -> bounce RAM -> chip DMA;  READ: chip DMA -> bounce RAM -> data.
//   * Units are 512 bytes: this backend is NOT PI-native (the chip keeps its own BCH + CRC-16 + FTL CRC-32/LPN tag
//     inside the page; a CRC-32C trailer cannot be stored).  Namespaces with PI_EN are refused on this backend.
//   * Durability: the chip has no volatile write cache (P60 docs/03 §1: every acknowledged WRITE is durable, TRIM is
//     acknowledged after its journal record is programmed).  The adapter therefore reports durable = 1 for WRITE / FLUSH /
//     DISCARD completions of the chip -- an assumption inherited from the chip's contract, exercised by the power-loss
//     tests in tb/, and NOT independently provable here (P60 limitation 10: completion path trusts the firmware).
//   * Never-written blocks: P60 documents that unmapped LBAs read as zeros.  The adapter zero-fills its bounce RAM before every
//     READ, so the contract holds even if a firmware path does not DMA an unmapped block.  (An early test suspicion that the chip
//     returned garbage for never-written LBAs was a TEST artefact: the NAND twin persists its array on disk between runs.)
//   * Management passthrough (mg_*): the chip's own boot / key / mailbox traffic uses the same BAR; passthrough requests
//     are served only while the adapter is not mid-command.
// Classification: SYNTHESIZABLE (bounce RAM is a flop array)
// =============================================================================
`default_nettype none
module sf_stor_be_store
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int BOUNCE_BYTES = 8192,          // staging for one command (<= P60 MDTS blocks)
  parameter logic [31:0] BOUNCE_BASE = 32'h0001_0000   // address of the bounce RAM in the chip's host window
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            be_reset_i,
  // backend contract
  output logic                 be_ready,
  output logic [63:0]          be_capacity,
  output logic [7:0]           be_caps,
  input  wire logic            be_req_valid,
  output logic                 be_req_ready,
  input  wire logic [2:0]      be_req_op,
  input  wire logic [63:0]     be_req_lba,
  input  wire logic [15:0]     be_req_nblk,
  input  wire logic [3:0]      be_req_tag,
  input  wire logic            be_wd_valid,
  output logic                 be_wd_ready,
  input  wire logic [63:0]     be_wd_data,
  input  wire logic            be_wd_ulast,
  input  wire logic [3:0]      be_wd_tag,
  output logic                 be_rd_valid,
  input  wire logic            be_rd_ready,
  output logic [3:0]           be_rd_tag,
  output logic [63:0]          be_rd_data,
  output logic                 be_rd_ulast,
  output logic [1:0]           be_rd_uflags,
  output logic                 be_cpl_valid,
  input  wire logic            be_cpl_ready,
  output logic [3:0]           be_cpl_tag,
  output logic [3:0]           be_cpl_status,
  output logic                 be_cpl_durable,
  output logic [15:0]          be_cpl_nblk,
  // chip host BAR (SFB2: one transaction at a time)
  output logic                 hb_req_valid,
  input  wire logic            hb_req_ready,
  output logic                 hb_req_write,
  output logic [31:0]          hb_req_addr,
  output logic [31:0]          hb_req_wdata,
  input  wire logic            hb_rsp_valid,
  input  wire logic [31:0]     hb_rsp_rdata,
  input  wire logic            hb_rsp_error,
  // chip host-memory port (served from the bounce RAM)
  input  wire logic            hm_req_valid,
  output logic                 hm_req_ready,
  input  wire logic            hm_req_write,
  input  wire logic [31:0]     hm_req_addr,
  input  wire logic [31:0]     hm_req_wdata,
  input  wire logic [3:0]      hm_req_wstrb,
  output logic                 hm_rsp_valid,
  input  wire logic            hm_rsp_ready,
  output logic [31:0]          hm_rsp_rdata,
  output logic                 hm_rsp_error,
  input  wire logic            st_host_ready_i,    // chip firmware booted (host_ready_o)
  // management passthrough to the chip BAR
  input  wire logic            mg_req_valid,
  output logic                 mg_req_ready,
  input  wire logic            mg_req_write,
  input  wire logic [31:0]     mg_req_addr,
  input  wire logic [31:0]     mg_req_wdata,
  output logic                 mg_rsp_valid,
  output logic [31:0]          mg_rsp_rdata,
  output logic                 mg_rsp_error,
  output logic [7:0]           stat_state,
  output logic [31:0]          stat_cmds,
  output logic [31:0]          stat_bar_ops
);
  localparam logic [31:0] SHC = 32'h8000_0000;
  localparam logic [31:0] A_CTRL = SHC + 32'h20, A_STATUS = SHC + 32'h24, A_INTC = SHC + 32'h28, A_CAP = SHC + 32'h08,
                          A_CAPLO = SHC + 32'h10, A_SQT = SHC + 32'h40, A_CQH = SHC + 32'h48;
  localparam logic [31:0] A_SQ = SHC + 32'h1000, A_CQ = SHC + 32'h2000;
  localparam int BW = BOUNCE_BYTES / 8;               // bounce words (64-bit)
  localparam int BAW = $clog2(BW);

  assign be_caps = {3'b0, 1'b0, 1'b1, 1'b1, 1'b0, 1'b0};     // DISCARD + DISCARD_ZERO; write-through; not PI-native

  // ------------------------------------------------------------------ bounce RAM (64-bit words)
  logic [63:0] bram [BW];
  // chip-side port (32-bit accesses)
  logic        hm_busy;
  logic        hmw_en; logic [BAW-1:0] hmw_idx; logic [63:0] hmw_dat; logic [7:0] hmw_be;
  logic [BAW-1:0] hm_widx;
  wire         hm_in_range = (hm_req_addr >= BOUNCE_BASE) && (hm_req_addr < BOUNCE_BASE + 32'(BOUNCE_BYTES)) && (hm_req_addr[1:0] == 2'b00);
  wire  [31:0] hm_off      = hm_req_addr - BOUNCE_BASE;
  assign hm_req_ready = !hm_busy;
  // fabric-side port
  logic        wr_en;  logic [BAW-1:0] wr_idx; logic [63:0] wr_dat;
  logic [BAW-1:0] rd_idx;
  // ------------------------------------------------------------------ BAR master
  typedef enum logic [1:0] {B_IDLE, B_REQ, B_RSP} bst_t;
  bst_t        bst;
  logic        b_go, b_we, b_done;
  logic [31:0] b_addr, b_wd, b_rd;
  logic        drv_hold;                 // the driver owns the BAR for a whole command
  logic        pass_active;
  // passthrough: served only when the driver is idle between commands
  wire pass_ok = !drv_hold && (bst == B_IDLE) && !b_go;
  assign mg_req_ready = pass_ok && !pass_active;

  // ------------------------------------------------------------------ driver FSM
  typedef enum logic [4:0] {
    A_OFF, A_I0, A_I1, A_I2, A_I2P, A_I3, A_I4, A_IDLE, A_WDATA, A_CLR, A_SQW, A_SQT_W, A_POLL, A_CQ0, A_CQ1, A_CQH_W, A_RSTR, A_CPL, A_DRAIN
  } ast_t;
  ast_t        st;
  logic [2:0]  op;
  logic [63:0] lba;
  logic [15:0] nb, units;
  logic [3:0]  tag;
  logic [3:0]  sidx;                      // SQ word being written
  logic [7:0]  hqd;                       // queue entries (from CAP)
  logic [7:0]  sq_slot, cq_slot;
  logic        phase;
  logic [15:0] tid;
  logic        drop;                      // abandon the result (backend reset while a chip command was outstanding)
  logic [31:0] cq_w0, cq_w3;
  logic [3:0]  rstatus;
  logic        rdur;
  logic [15:0] ndone;
  logic [BAW:0] widx;                     // fabric <-> bounce word index
  logic [6:0]  uw;                        // word within unit
  logic [15:0] ucnt;
  logic [15:0] poll_wait;
  logic [31:0] cmds, barops;
  logic        ready_q;
  assign be_ready   = ready_q && !drop;
  assign stat_state = {3'b0, st};
  assign stat_cmds  = cmds;
  assign stat_bar_ops = barops;
  assign be_req_ready = (st == A_IDLE) && ready_q && !drop;
  assign be_wd_ready  = (st == A_WDATA);
  assign be_rd_tag    = tag;
  assign be_cpl_tag   = tag;

  wire [8:0] sq_n9 = {1'b0, sq_slot} + 9'd1;
  wire [8:0] cq_n9 = {1'b0, cq_slot} + 9'd1;
  wire       sq_wrap = (sq_n9 >= {1'b0, hqd});
  wire       cq_wrap = (cq_n9 >= {1'b0, hqd});
  wire [7:0] sq_next = sq_wrap ? 8'd0 : sq_n9[7:0];
  wire [7:0] cq_next = cq_wrap ? 8'd0 : cq_n9[7:0];
  // SQ words
  logic [31:0] sqw [8];
  always_comb begin
    for (int i = 0; i < 8; i++) sqw[i] = 32'h0;
    sqw[0] = {tid, 8'h00, (op == BOP_WRITE) ? 8'h01 : (op == BOP_READ) ? 8'h02 : (op == BOP_FLUSH) ? 8'h00 : 8'h09};
    sqw[2] = lba[31:0]; sqw[3] = lba[63:32];
    sqw[4] = (op == BOP_FLUSH) ? 32'h0 : {16'h0, nb};
    sqw[5] = (op == BOP_READ || op == BOP_WRITE) ? BOUNCE_BASE : 32'h0;
  end

  function automatic logic [3:0] map_status(input logic [6:0] s);
    case (s)
      7'h00: map_status = BST_OK;
      7'h08: map_status = BST_RANGE;
      7'h10: map_status = BST_MEDIA_ERR;
      7'h11: map_status = BST_RO;
      7'h05, 7'h07: map_status = BST_RESET;
      default: map_status = BST_DEV_ERR;
    endcase
  endfunction

  // ------------------------------------------------------------------ BAR master + passthrough mux
  assign hb_req_valid = (bst == B_REQ) || (pass_active && !pass_got_req);
  logic pass_got_req, pass_rsp_pend;
  logic        pass_we; logic [31:0] pass_addr, pass_wd;
  assign hb_req_write = (bst == B_REQ) ? b_we : pass_we;
  assign hb_req_addr  = (bst == B_REQ) ? b_addr : pass_addr;
  assign hb_req_wdata = (bst == B_REQ) ? b_wd : pass_wd;
  assign b_done = (bst == B_RSP) && hb_rsp_valid;
  assign b_rd   = hb_rsp_rdata;
  assign mg_rsp_valid = pass_rsp_pend && hb_rsp_valid;
  assign mg_rsp_rdata = hb_rsp_rdata;
  assign mg_rsp_error = hb_rsp_error;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      bst <= B_IDLE; pass_active <= 1'b0; pass_got_req <= 1'b0; pass_rsp_pend <= 1'b0; pass_we <= 1'b0; pass_addr <= '0; pass_wd <= '0;
    end else begin
      case (bst)
        B_IDLE: if (b_go) bst <= B_REQ;
        B_REQ:  if (hb_req_ready) bst <= B_RSP;
        B_RSP:  if (hb_rsp_valid) bst <= B_IDLE;
        default: bst <= B_IDLE;
      endcase
      // passthrough transaction
      if (mg_req_valid && mg_req_ready) begin
        pass_active <= 1'b1; pass_got_req <= 1'b0; pass_we <= mg_req_write; pass_addr <= mg_req_addr; pass_wd <= mg_req_wdata;
      end
      if (pass_active && !pass_got_req && hb_req_ready) begin pass_got_req <= 1'b1; pass_rsp_pend <= 1'b1; end
      if (pass_rsp_pend && hb_rsp_valid) begin pass_rsp_pend <= 1'b0; pass_active <= 1'b0; end
    end
  end

  // ------------------------------------------------------------------ chip-side host-memory slave
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin hm_busy <= 1'b0; hm_rsp_valid <= 1'b0; hm_rsp_rdata <= '0; hm_rsp_error <= 1'b0; hm_widx <= '0; hmw_en <= 1'b0; hmw_idx <= '0; hmw_dat <= '0; hmw_be <= '0; end
    else begin
      hmw_en <= 1'b0;
      if (hm_req_valid && hm_req_ready) begin
        hm_busy <= 1'b1; hm_rsp_valid <= 1'b1;
        if (!hm_in_range) begin hm_rsp_error <= 1'b1; hm_rsp_rdata <= '0; end
        else begin
          hm_rsp_error <= 1'b0;
          hm_widx <= BAW'(hm_off[BAW+2:3]);
          if (hm_req_write) begin
            hmw_en <= 1'b1; hmw_idx <= BAW'(hm_off[BAW+2:3]); hmw_dat <= hm_off[2] ? {hm_req_wdata, 32'h0} : {32'h0, hm_req_wdata};
            hmw_be <= hm_off[2] ? {hm_req_wstrb, 4'h0} : {4'h0, hm_req_wstrb};
            hm_rsp_rdata <= '0;
          end else hm_rsp_rdata <= hm_off[2] ? bram[hm_off[BAW+2:3]][63:32] : bram[hm_off[BAW+2:3]][31:0];
        end
      end
      if (hm_rsp_valid && hm_rsp_ready) begin hm_rsp_valid <= 1'b0; hm_busy <= 1'b0; end
    end
  end
  // the only process that writes the bounce RAM: chip-side writes (registered above) and fabric-side writes never overlap in time
  always_ff @(posedge clk) begin
    if (hmw_en) for (int b = 0; b < 8; b++) if (hmw_be[b]) bram[hmw_idx][8*b +: 8] <= hmw_dat[8*b +: 8];
    if (wr_en) bram[wr_idx] <= wr_dat;
    be_rd_data <= bram[rd_idx];
  end

  // ------------------------------------------------------------------ main FSM
  wire [31:0] cq_w3_addr = A_CQ + {20'h0, cq_slot, 4'h0} + 32'd12;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= A_OFF; op <= '0; lba <= '0; nb <= '0; units <= '0; tag <= '0; sidx <= '0; hqd <= 8'd16; sq_slot <= '0; cq_slot <= '0; phase <= 1'b1;
      tid <= 16'h0001; drop <= 1'b0; cq_w0 <= '0; cq_w3 <= '0; rstatus <= BST_OK; rdur <= 1'b0; ndone <= '0; widx <= '0; uw <= '0; ucnt <= '0;
      poll_wait <= '0; cmds <= '0; barops <= '0; ready_q <= 1'b0; b_go <= 1'b0; b_we <= 1'b0; b_addr <= '0; b_wd <= '0; drv_hold <= 1'b0;
      be_capacity <= '0; be_rd_valid <= 1'b0; be_rd_ulast <= 1'b0; be_rd_uflags <= '0; be_cpl_valid <= 1'b0; be_cpl_status <= '0;
      be_cpl_durable <= 1'b0; be_cpl_nblk <= '0; wr_en <= 1'b0; wr_idx <= '0; wr_dat <= '0; rd_idx <= '0;
    end else begin
      b_go <= 1'b0; wr_en <= 1'b0;
      if (b_done) barops <= barops + 32'd1;
      // chip lost (power cycle / firmware not running): back to offline
      if (!st_host_ready_i && st != A_OFF) begin
        st <= A_OFF; ready_q <= 1'b0; drv_hold <= 1'b0; drop <= 1'b0; be_rd_valid <= 1'b0; be_cpl_valid <= 1'b0; b_go <= 1'b0;
        sq_slot <= '0; cq_slot <= '0; phase <= 1'b1;
      end else begin
        // backend reset requested by the fabric: ignore any result from here on
        if (be_reset_i && st != A_OFF && st != A_IDLE) begin
          drop <= 1'b1; be_rd_valid <= 1'b0; be_cpl_valid <= 1'b0;
          if (st == A_WDATA || st == A_CLR) begin st <= A_IDLE; drop <= 1'b0; drv_hold <= 1'b0; end
        end
        case (st)
          A_OFF: if (st_host_ready_i && bst == B_IDLE && !pass_active) begin
            sq_slot <= '0; cq_slot <= '0; phase <= 1'b1; ready_q <= 1'b0; drv_hold <= 1'b1;
            b_we <= 1'b1; b_addr <= A_INTC; b_wd <= 32'h0; b_go <= 1'b1; st <= A_I0;
          end
          A_I0: if (b_done) begin b_we <= 1'b1; b_addr <= A_CTRL; b_wd <= 32'h1; b_go <= 1'b1; st <= A_I1; end
          A_I1: if (b_done) begin b_we <= 1'b0; b_addr <= A_STATUS; b_go <= 1'b1; st <= A_I2; end
          A_I2: if (b_done) begin
            if (b_rd[0]) begin b_we <= 1'b0; b_addr <= A_CAP; b_go <= 1'b1; st <= A_I3; end
            else begin poll_wait <= 16'd200; st <= A_I2P; end                                 // not ready yet: poll again later
          end
          A_I2P: begin
            if (poll_wait != 0) poll_wait <= poll_wait - 16'd1;
            else if (!b_go && bst == B_IDLE && !b_done) begin b_we <= 1'b0; b_addr <= A_STATUS; b_go <= 1'b1; st <= A_I2; end
          end
          A_I3: if (b_done) begin hqd <= b_rd[7:0]; b_we <= 1'b0; b_addr <= A_CAPLO; b_go <= 1'b1; st <= A_I4; end
          A_I4: if (b_done) begin be_capacity <= {32'h0, b_rd}; ready_q <= 1'b1; drv_hold <= 1'b0; st <= A_IDLE; end
          // ---------------- idle: accept a request
          A_IDLE: begin
            drop <= 1'b0;
            if (be_req_valid && be_req_ready) begin
              op <= be_req_op; lba <= be_req_lba; nb <= be_req_nblk; tag <= be_req_tag; rstatus <= BST_OK; rdur <= 1'b0; ndone <= '0;
              widx <= '0; uw <= '0; ucnt <= '0; units <= '0; drv_hold <= 1'b1; cmds <= cmds + 32'd1;
              if (be_req_op == BOP_WRITE) st <= A_WDATA;
              else if (be_req_op == BOP_READ) st <= A_CLR;          // zero the bounce RAM first (never-written blocks must read as zeros)
              else begin sidx <= '0; st <= A_SQW; end
            end
          end
          // ---------------- WRITE: collect the units into the bounce RAM
          A_WDATA: begin
            if (be_wd_valid && be_wd_ready) begin
              wr_en <= 1'b1; wr_idx <= BAW'(widx); wr_dat <= be_wd_data; widx <= widx + 1'b1;
              if (be_wd_ulast) begin
                units <= units + 16'd1;
                if (units + 16'd1 == nb) begin sidx <= '0; st <= A_SQW; end
              end
            end
          end
          // ---------------- pre-clear the bounce RAM (nb blocks)
          A_CLR: begin
            wr_en <= 1'b1; wr_idx <= BAW'(widx); wr_dat <= 64'h0;
            if (widx + 1'b1 == {nb[BAW-6:0], 6'h0}) begin widx <= '0; sidx <= '0; st <= A_SQW; end
            else widx <= widx + 1'b1;
          end
          // ---------------- submit
          A_SQW: begin
            if (!b_go && bst == B_IDLE && !b_done) begin
              b_we <= 1'b1; b_addr <= A_SQ + {19'h0, sq_slot, 5'h0} + {26'h0, sidx, 2'b00}; b_wd <= sqw[sidx[2:0]]; b_go <= 1'b1;
              st <= A_SQT_W;
            end
          end
          A_SQT_W: if (b_done) begin
            if (sidx == 4'd7) begin
              b_we <= 1'b1; b_addr <= A_SQT; b_wd <= {24'h0, sq_next}; b_go <= 1'b1; sidx <= 4'd8;
            end else if (sidx == 4'd8) begin
              sq_slot <= sq_next; poll_wait <= '0; st <= A_POLL;
            end else begin sidx <= sidx + 4'd1; st <= A_SQW; end
          end
          // ---------------- poll the completion queue (phase bit)
          A_POLL: begin
            if (poll_wait != 0) poll_wait <= poll_wait - 16'd1;
            else if (!b_go && bst == B_IDLE && !b_done) begin b_we <= 1'b0; b_addr <= cq_w3_addr; b_go <= 1'b1; st <= A_CQ0; end
          end
          A_CQ0: if (b_done) begin
            if (b_rd[16] == phase) begin cq_w3 <= b_rd; b_we <= 1'b0; b_addr <= A_CQ + {20'h0, cq_slot, 4'h0}; b_go <= 1'b1; st <= A_CQ1; end
            else begin poll_wait <= 16'd32; st <= A_POLL; end
          end
          A_CQ1: if (b_done) begin
            cq_w0 <= b_rd;
            rstatus <= map_status(cq_w3[23:17]);
            ndone   <= (cq_w3[23:17] == 7'h00) ? nb : b_rd[15:0];
            rdur    <= (cq_w3[23:17] == 7'h00);                // the chip has no volatile write cache (see header)
            cq_slot <= cq_next;
            if (cq_wrap) phase <= !phase;
            b_we <= 1'b1; b_addr <= A_CQH; b_wd <= {24'h0, cq_next}; b_go <= 1'b1; st <= A_CQH_W;
          end
          A_CQH_W: if (b_done) begin
            tid <= tid + 16'd1; drv_hold <= 1'b0;
            if (drop) begin st <= A_IDLE; end
            else if (op == BOP_READ && rstatus == BST_OK) begin st <= A_RSTR; widx <= '0; uw <= '0; ucnt <= '0; rd_idx <= '0; end
            else begin st <= A_CPL; end
          end
          // ---------------- READ: bounce RAM -> fabric
          A_RSTR: begin
            if (!be_rd_valid) begin
              be_rd_valid <= 1'b1; be_rd_ulast <= 1'b0; be_rd_uflags <= '0; rd_idx <= BAW'(widx + 1'b1);
            end else if (be_rd_ready) begin
              if (uw == 7'd63) begin
                be_rd_uflags <= '0;
                uw <= '0; ucnt <= ucnt + 16'd1;
                if (ucnt + 16'd1 == nb) begin be_rd_valid <= 1'b0; be_rd_ulast <= 1'b0; st <= A_CPL; end
                else begin widx <= widx + 1'b1; rd_idx <= BAW'(widx + 2'd2); be_rd_ulast <= 1'b0; end
              end else begin
                uw <= uw + 7'd1; widx <= widx + 1'b1; rd_idx <= BAW'(widx + 2'd2);
                be_rd_ulast <= (uw + 7'd1 == 7'd63);
              end
            end
          end
          // ---------------- completion to the fabric
          A_CPL: begin
            if (!be_cpl_valid) begin
              be_cpl_valid <= 1'b1; be_cpl_status <= rstatus; be_cpl_durable <= rdur && (op != BOP_READ); be_cpl_nblk <= ndone;
            end else if (be_cpl_ready) begin be_cpl_valid <= 1'b0; st <= A_IDLE; end
          end
          default: st <= A_IDLE;
        endcase
      end
    end
  end
  wire unused_ok = &{1'b0, hb_rsp_error, be_wd_tag, be_rd_tag, hm_widx, cq_w0};
endmodule
`default_nettype wire
