// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_virtio_adapter -- VirtIO block-device integration (P63 VirtIO engine -> fabric)
//
//   The VirtIO engine (Project 63, vendored unmodified) terminates the guest's split virtqueue, validates descriptors and
//   checks every guest-memory access against the tenant's permission windows.  Its storage port (sc_*) issues 64-bit,
//   byte-enabled accesses at *byte addresses of the exported device*.  This adapter turns them into 512-byte block
//   commands on the fabric's ext command source:
//        sc READ   -> sector cache hit, else READ(1 block) through the fabric
//        sc WRITE  -> write-combining sector buffer; when all 512 bytes were written the sector is committed with
//                     WRITE(1 block) and the LAST sc response is withheld until the fabric completion arrives (errors
//                     propagate as sc_resp_err -> VIRTIO_BLK_S_IOERR)
//        sc FLUSH  -> persist a partially written sector (read-modify-write), then FLUSH through the fabric
//   Isolation: the device is bound to ONE namespace (VNS) owned by the hardware-fixed ext tenant; the fabric's validation
//   (ownership, bounds) applies to every command, so the guest can only reach its assigned logical region.  The guest never
//   sees a backend address.
//   Durability: a guest write is acknowledged only after the fabric reports the block written; "durable" follows the fabric /
//   backend rules (a volatile-cache backend needs the guest's FLUSH, which the engine offers via VIRTIO_BLK_F_FLUSH).
//   virtio-blk requests are whole sectors (the engine returns IOERR otherwise), so the combine buffer is always completed
//   by the request that fills it; a partial buffer is flushed on a sector change or sc FLUSH (read-modify-write).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_virtio_adapter
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int VNS      = 7,            // namespace bound to the virtio device
  parameter int SADDR_W  = 32
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // VirtIO engine storage port
  input  wire logic                sc_req_valid,
  output logic                     sc_req_ready,
  input  wire logic [1:0]          sc_req_op,
  input  wire logic [SADDR_W-1:0]  sc_req_addr,
  input  wire logic [63:0]         sc_req_wdata,
  input  wire logic [7:0]          sc_req_be,
  output logic                     sc_resp_valid,
  output logic [63:0]              sc_resp_rdata,
  output logic                     sc_resp_err,
  // fabric ext source
  output logic                     ext_cmd_valid,
  input  wire logic                ext_cmd_ready,
  output logic [7:0]               ext_op,
  output logic [7:0]               ext_nsid,
  output logic [63:0]              ext_lba,
  output logic [15:0]              ext_nblk,
  output logic [15:0]              ext_txn,
  input  wire logic                ext_cpl_valid,
  output logic                     ext_cpl_ready,
  input  wire logic [7:0]          ext_cpl_status,
  input  wire logic                ext_in_req,
  output logic                     ext_in_done,
  input  wire logic                ext_out_req,
  output logic                     ext_out_done,
  input  wire logic [12:0]         ext_data_base,
  output logic                     ext_lm_req,
  output logic                     ext_lm_we,
  output logic [12:0]              ext_lm_addr,
  output logic [63:0]              ext_lm_wdata,
  input  wire logic                ext_lm_gnt,
  input  wire logic                ext_lm_rvalid,
  input  wire logic [63:0]         ext_lm_rdata,
  // statistics
  output logic [31:0]              stat_loads,
  output logic [31:0]              stat_stores,
  output logic [31:0]              stat_flushes,
  output logic [31:0]              stat_errors
);
  localparam logic [1:0] OPR = 2'd0, OPW = 2'd1, OPF = 2'd2;

  // ------------------------------------------------------------------ sector buffer
  logic [63:0] data  [64];
  logic [7:0]  wmask [64];
  logic [SADDR_W-10:0] sec;               // sector held in the buffer
  logic        sec_v;                     // buffer holds the whole sector's data
  logic        dirty;                     // bytes written since the last persist
  logic        full;                      // every byte of the sector was written since the last persist
  always_comb begin
    full = 1'b1;
    for (int i = 0; i < 64; i++) if (wmask[i] != 8'hFF) full = 1'b0;
  end

  // ------------------------------------------------------------------ request latch
  logic [1:0]  rq_op;
  logic [SADDR_W-1:0] rq_addr;
  logic [63:0] rq_wd;
  logic [7:0]  rq_be;
  wire  [SADDR_W-10:0] rq_sec = rq_addr[SADDR_W-1:9];
  wire  [5:0]  rq_w   = rq_addr[8:3];
  logic [63:0] resp_data;

  // ------------------------------------------------------------------ procedure runner: one fabric command with its data move
  typedef enum logic [2:0] {PR_IDLE, PR_CMD, PR_DATA, PR_CPL} pr_t;
  pr_t         pst;
  logic        pr_go, pr_done, pr_err;
  logic [2:0]  pr_op;
  logic [SADDR_W-10:0] pr_sec;
  logic [6:0]  wi;
  logic        w_pend;
  logic [15:0] txn;
  logic        mv_done_pulse;

  assign ext_nsid  = 8'(VNS);
  assign ext_txn   = txn;
  assign ext_op    = (pr_op == BOP_WRITE) ? OP_WRITE : (pr_op == BOP_READ) ? OP_READ : OP_FLUSH;
  assign ext_lba   = (pr_op == BOP_FLUSH) ? 64'h0 : 64'(pr_sec);
  assign ext_nblk  = (pr_op == BOP_FLUSH) ? 16'h0 : 16'd1;
  assign ext_cmd_valid = (pst == PR_CMD);
  // a completion in PR_DATA means the command ended before its data move finished (validation / backend / integrity error): consume it
  assign ext_cpl_ready = ((pst == PR_CPL) || (pst == PR_DATA)) && ext_cpl_valid;
  assign ext_in_done   = mv_done_pulse && (pr_op == BOP_WRITE);
  assign ext_out_done  = mv_done_pulse && (pr_op == BOP_READ);
  wire   slot_ready    = (pr_op == BOP_WRITE) ? ext_in_req : ext_out_req;
  assign ext_lm_req    = (pst == PR_DATA) && slot_ready && (wi < 7'd64) && !w_pend && !ext_cpl_valid;
  assign ext_lm_we     = (pr_op == BOP_WRITE);
  assign ext_lm_addr   = ext_data_base + 13'(wi);
  assign ext_lm_wdata  = data[wi[5:0]];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pst <= PR_IDLE; pr_done <= 1'b0; pr_err <= 1'b0; wi <= '0; w_pend <= 1'b0; txn <= 16'h0001; mv_done_pulse <= 1'b0;
    end else begin
      pr_done <= 1'b0; mv_done_pulse <= 1'b0;
      case (pst)
        PR_IDLE: if (pr_go) begin wi <= '0; w_pend <= 1'b0; pr_err <= 1'b0; pst <= PR_CMD; end
        PR_CMD:  if (ext_cmd_ready) pst <= (pr_op == BOP_FLUSH) ? PR_CPL : PR_DATA;
        PR_DATA: begin
          if (ext_cpl_valid) begin
            // early completion: no data command succeeds before its data has moved, so this is an error whatever the status says
            pr_err <= 1'b1; pr_done <= 1'b1; txn <= txn + 16'd1; w_pend <= 1'b0; pst <= PR_IDLE;
          end else if (slot_ready) begin
            if (pr_op == BOP_WRITE) begin
              if (wi < 7'd64) begin if (ext_lm_gnt) wi <= wi + 7'd1; end
              else begin mv_done_pulse <= 1'b1; pst <= PR_CPL; end
            end else begin
              if (!w_pend && wi < 7'd64 && ext_lm_gnt) w_pend <= 1'b1;
              if (w_pend && ext_lm_rvalid) begin
                for (int b = 0; b < 8; b++) if (!wmask[wi[5:0]][b]) data[wi[5:0]][8*b +: 8] <= ext_lm_rdata[8*b +: 8];
                w_pend <= 1'b0; wi <= wi + 7'd1;
                if (wi + 7'd1 == 7'd64) begin mv_done_pulse <= 1'b1; pst <= PR_CPL; end
              end
            end
          end
        end
        PR_CPL: if (ext_cpl_valid) begin
          pr_err <= (ext_cpl_status != ST_SUCCESS); pr_done <= 1'b1; txn <= txn + 16'd1; pst <= PR_IDLE;
        end
        default: pst <= PR_IDLE;
      endcase
    end
  end

  // ------------------------------------------------------------------ request handler
  typedef enum logic [4:0] {
    M_IDLE, M_DEC, M_FD, M_FD_LOAD, M_FD_STORE, M_LOAD, M_NEWSEC, M_MERGE, M_CHK, M_COMMIT, M_FLUSHCMD, M_WAIT, M_RESP
  } mst_t;
  mst_t        mst;
  typedef enum logic [1:0] {A_READ, A_WRITE, A_FLUSH} aft_t;
  aft_t        after;
  mst_t        wait_next;                 // state to enter when the running procedure completes OK

  assign sc_req_ready  = (mst == M_IDLE);
  assign sc_resp_valid = (mst == M_RESP);
  assign sc_resp_rdata = resp_data;

  task automatic start_proc(input logic [2:0] op, input logic [SADDR_W-10:0] sct, input mst_t nxt);
    pr_go <= 1'b1; pr_op <= op; pr_sec <= sct; wait_next <= nxt; mst <= M_WAIT;
  endtask

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mst <= M_IDLE; after <= A_READ; wait_next <= M_IDLE; pr_go <= 1'b0; pr_op <= '0; pr_sec <= '0; sec <= '0; sec_v <= 1'b0; dirty <= 1'b0;
      rq_op <= '0; rq_addr <= '0; rq_wd <= '0; rq_be <= '0; resp_data <= '0; sc_resp_err <= 1'b0;
      stat_loads <= '0; stat_stores <= '0; stat_flushes <= '0; stat_errors <= '0;
      for (int i = 0; i < 64; i++) begin data[i] <= '0; wmask[i] <= '0; end
    end else begin
      pr_go <= 1'b0;
      case (mst)
        M_IDLE: begin
          sc_resp_err <= 1'b0;
          if (sc_req_valid) begin rq_op <= sc_req_op; rq_addr <= sc_req_addr; rq_wd <= sc_req_wdata; rq_be <= sc_req_be; mst <= M_DEC; end
        end
        M_DEC: begin
          case (rq_op)
            OPR: begin
              if (sec_v && sec == rq_sec) begin resp_data <= data[rq_w]; mst <= M_RESP; end
              else if (dirty && sec != rq_sec) begin after <= A_READ; mst <= M_FD; end
              else begin after <= A_READ; mst <= M_LOAD; end
            end
            OPW: begin
              if (sec != rq_sec && dirty) begin after <= A_WRITE; mst <= M_FD; end
              else if (sec != rq_sec || (!sec_v && !dirty)) mst <= M_NEWSEC;
              else mst <= M_MERGE;
            end
            OPF: begin
              if (dirty) begin after <= A_FLUSH; mst <= M_FD; end
              else mst <= M_FLUSHCMD;
            end
            default: begin sc_resp_err <= 1'b1; mst <= M_RESP; end
          endcase
        end
        // ---- persist the dirty buffer: load the missing bytes first when the buffer was only partly written
        M_FD: begin
          if (!sec_v && !full) begin start_proc(BOP_READ, sec, M_FD_LOAD); stat_loads <= stat_loads + 32'd1; end
          else begin start_proc(BOP_WRITE, sec, M_FD_STORE); stat_stores <= stat_stores + 32'd1; end
        end
        M_FD_LOAD: begin sec_v <= 1'b1; start_proc(BOP_WRITE, sec, M_FD_STORE); stat_stores <= stat_stores + 32'd1; end
        M_FD_STORE: begin
          dirty <= 1'b0; sec_v <= 1'b1; for (int i = 0; i < 64; i++) wmask[i] <= '0;
          case (after)
            A_READ:  mst <= M_LOAD;
            A_WRITE: mst <= M_NEWSEC;
            default: mst <= M_FLUSHCMD;
          endcase
        end
        // ---- read a sector into the buffer (bytes written since the last persist are kept)
        M_LOAD: begin
          start_proc(BOP_READ, rq_sec, M_RESP); stat_loads <= stat_loads + 32'd1;
          sec <= rq_sec;
          // after the data move the response word is selected below (M_RESP gets resp_data from the buffer)
        end
        M_NEWSEC: begin
          sec <= rq_sec; sec_v <= 1'b0; dirty <= 1'b0;
          for (int i = 0; i < 64; i++) wmask[i] <= '0;
          mst <= M_MERGE;
        end
        M_MERGE: begin
          for (int b = 0; b < 8; b++) if (rq_be[b]) data[rq_w][8*b +: 8] <= rq_wd[8*b +: 8];
          wmask[rq_w] <= wmask[rq_w] | rq_be;
          dirty <= 1'b1;
          mst <= M_CHK;
        end
        M_CHK: begin
          if (full) begin sec_v <= 1'b1; start_proc(BOP_WRITE, sec, M_COMMIT); stat_stores <= stat_stores + 32'd1; end
          else mst <= M_RESP;                      // buffered: acknowledged now, committed with the sector's last bytes
        end
        M_COMMIT: begin dirty <= 1'b0; for (int i = 0; i < 64; i++) wmask[i] <= '0; mst <= M_RESP; end
        M_FLUSHCMD: begin start_proc(BOP_FLUSH, '0, M_RESP); stat_flushes <= stat_flushes + 32'd1; end
        M_WAIT: begin
          if (pr_done) begin
            if (pr_err) begin
              stat_errors <= stat_errors + 32'd1;
              sec_v <= 1'b0; dirty <= 1'b0; for (int i = 0; i < 64; i++) wmask[i] <= '0;
              sc_resp_err <= 1'b1; resp_data <= '0; mst <= M_RESP;
            end else begin
              if (pr_op == BOP_READ && wait_next == M_RESP) begin sec_v <= 1'b1; resp_data <= data[rq_w]; end
              mst <= wait_next;
            end
          end
        end
        M_RESP: mst <= M_IDLE;
        default: mst <= M_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
