// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_be_hostsw -- HOST-SOFTWARE backend adapter (backend type 2)
//
//   The backend contract (docs/02 §7) is served by SOFTWARE: a service on the DPU management CPU (or the host) that owns the
//   real storage (a file, an SPDK bdev, a network block service, ...).  The adapter is a mailbox: it surfaces ONE request at a
//   time through a small 32-bit register window, stages the data in a private RAM the software reads / writes through the same
//   window, and turns the software's completion back into the contract's completion.
//
//   Why one request at a time: the mailbox has a single request register set.  Throughput is limited by software polling latency;
//   this is the lowest-performance, highest-flexibility backend and the proof that the contract does not depend on the medium.
//
//   Units are 528 bytes (PI-native: the software stores the whole unit verbatim, including the 16-byte PI trailer the fabric
//   appends -- the software never interprets it).  The software sets the capabilities and capacity, then READY.
//
//   Mailbox registers (offsets in the 4 KiB window, 32-bit accesses):
//     0x000 ID        RO  0x53464853 ("SFHS")           0x004 VERSION RO  1
//     0x008 CTRL      RW  [0] READY (service up; 0 withdraws the backend)
//     0x00C CAPS      RW  backend caps (contract bit positions; PI_NATIVE is always reported: the unit format is fixed); writable while READY = 0
//     0x010/0x014 CAP RW  capacity in blocks (lo/hi); writable while READY = 0
//     0x020 REQ_STATUS RO [0] PENDING  [3:1] op (1 READ 2 WRITE 3 FLUSH 4 DISCARD)  [4] ABORTED  [15:8] tag  [31:16] seq
//     0x024/0x028 REQ_LBA RO lo/hi    0x02C REQ_NBLK RO
//     0x030 CPL_STATUS WO [3:0] contract status (0 OK 1 MEDIA 2 DEV 3 RANGE 4 RO 5 UNSUPPORTED)
//     0x034 CPL_NBLK   WO blocks completed         0x038 CPL_FLAGS WO [0] durable
//     0x03C CPL_COMMIT WO [15:0] = REQ_STATUS.seq of the request being completed: a commit whose seq does not match the live
//                         request (stale answer after a backend reset) is IGNORED.
//     0x080 + 4*u UFLAGS WO per-unit read flags ([0] ERR [1] UNMAPPED)
//     0x2000 + 4*i DATA  RW staging RAM, little-endian 32-bit words; unit u (528 B = 132 words) starts at word u*132; writable only
//                         while the request is PENDING
//   Request lifecycle: contract request -> (WRITE: units collected) -> PENDING -> software reads LBA/NBLK (+ data), writes
//   (read data), CPL_* then CPL_COMMIT -> (READ OK: units streamed to the fabric) -> contract completion.
//   Fabric backend reset (timeout / power fail): the request is dropped, ABORTED latches until the next request, nothing the
//   software commits for it reaches the fabric.
// Classification: SYNTHESIZABLE (staging RAM is a flop array)
// =============================================================================
`default_nettype none
module sf_stor_be_hostsw
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int MAX_UNITS = 8                       // staging for one command (>= fabric MDTS)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            be_reset_i,
  // backend contract
  output logic                 be_ready,
  output logic [63:0]          be_capacity,
  output logic [7:0]           be_caps,
  input  wire logic            be_req_valid,
  output logic                 be_req_ready,
  input  wire logic [2:0]      be_req_op,
  input  wire logic [63:0]     be_req_lba,
  input  wire logic [15:0]     be_req_nblk,
  input  wire logic [3:0]      be_req_tag,
  input  wire logic            be_wd_valid,
  output logic                 be_wd_ready,
  input  wire logic [63:0]     be_wd_data,
  input  wire logic            be_wd_ulast,
  input  wire logic [3:0]      be_wd_tag,
  output logic                 be_rd_valid,
  input  wire logic            be_rd_ready,
  output logic [3:0]           be_rd_tag,
  output logic [63:0]          be_rd_data,
  output logic                 be_rd_ulast,
  output logic [1:0]           be_rd_uflags,
  output logic                 be_cpl_valid,
  input  wire logic            be_cpl_ready,
  output logic [3:0]           be_cpl_tag,
  output logic [3:0]           be_cpl_status,
  output logic                 be_cpl_durable,
  output logic [15:0]          be_cpl_nblk,
  // software mailbox (32-bit register window)
  input  wire logic            mb_req_valid,
  output logic                 mb_req_ready,
  input  wire logic            mb_req_we,
  input  wire logic [13:0]     mb_req_addr,
  input  wire logic [31:0]     mb_req_wdata,
  output logic                 mb_rsp_valid,
  output logic [31:0]          mb_rsp_rdata,
  // statistics
  output logic [31:0]          stat_reqs,
  output logic [31:0]          stat_stale_commits,
  output logic [31:0]          stat_aborts
);
  localparam int UW   = 66;                          // 64-bit words per unit (512 B data + 16 B PI trailer)
  localparam int UW32 = 2 * UW;
  localparam int BW   = MAX_UNITS * UW;              // staging words (64-bit)
  localparam int BAW  = $clog2(BW);

  // ------------------------------------------------------------------ registers
  logic        sw_ready;
  logic [7:0]  caps_q;
  logic [63:0] cap_q;
  assign be_ready    = sw_ready;
  assign be_capacity = cap_q;
  assign be_caps     = caps_q | 8'h01;                // PI-native units are the adapter's fixed format

  // ------------------------------------------------------------------ staging RAM (64-bit words), two writers: fabric side and mailbox
  logic [63:0] ram [BW];
  logic [BAW-1:0] fw_idx;  logic fw_en;  logic [63:0] fw_dat;       // fabric-side write
  logic [BAW-1:0] fr_idx;                                            // fabric-side read (combinational)
  logic        mw_en;  logic [BAW-1:0] mw_idx; logic [31:0] mw_dat; logic mw_hi;   // mailbox write of one 32-bit half
  always_ff @(posedge clk) begin
    if (fw_en) ram[fw_idx] <= fw_dat;
    else if (mw_en) begin
      if (mw_hi) ram[mw_idx][63:32] <= mw_dat; else ram[mw_idx][31:0] <= mw_dat;
    end
  end
  wire [63:0] fr_dat = ram[fr_idx];

  // ------------------------------------------------------------------ request state
  typedef enum logic [2:0] {S_IDLE, S_WDATA, S_PEND, S_RSTR, S_CPL} st_t;
  st_t         st;
  logic [2:0]  op;
  logic [63:0] lba;
  logic [15:0] nb, units_done, seq;
  logic [3:0]  tag;
  logic        aborted;
  logic [3:0]  c_status; logic [15:0] c_nblk; logic c_dur;
  logic [1:0]  uflags [MAX_UNITS];
  logic [BAW-1:0] widx; logic [7:0] uw; logic [15:0] ucnt;
  logic [31:0] cnt_reqs, cnt_stale, cnt_aborts;

  assign be_req_ready = (st == S_IDLE) && sw_ready;
  assign be_wd_ready  = (st == S_WDATA);
  assign be_rd_tag    = tag;
  assign be_cpl_tag   = tag;
  assign stat_reqs = cnt_reqs; assign stat_stale_commits = cnt_stale; assign stat_aborts = cnt_aborts;

  // read stream
  assign fr_idx       = widx;
  assign be_rd_valid  = (st == S_RSTR);
  assign be_rd_data   = fr_dat;
  assign be_rd_ulast  = (uw == 8'(UW - 1));
  assign be_rd_uflags = uflags[ucnt[2:0]];
  assign be_cpl_valid = (st == S_CPL);
  assign be_cpl_status = c_status; assign be_cpl_durable = c_dur; assign be_cpl_nblk = c_nblk;

  // ------------------------------------------------------------------ mailbox access decode
  assign mb_req_ready = 1'b1;
  logic        mb_rd_pend; logic [13:0] mb_rd_addr_q;
  wire         mb_acc   = mb_req_valid && mb_req_ready;
  wire         is_data  = (mb_req_addr[13] == 1'b1);                          // 0x2000..0x3FFF
  wire  [10:0] data_w32 = mb_req_addr[12:2];                                   // 32-bit word index within the data window
  wire  [BAW:0] data_i64 = (BAW+1)'(data_w32[10:1]);
  wire         data_ok  = is_data && (32'(data_w32[10:1]) < BW) && (st == S_PEND);   // software may touch the RAM only while it owns the request

  logic [31:0] rd_mux;
  always_comb begin
    rd_mux = 32'h0;
    case (mb_rd_addr_q[7:0])
      8'h00: rd_mux = 32'h5346_4853;
      8'h04: rd_mux = 32'd1;
      8'h08: rd_mux = {31'b0, sw_ready};
      8'h0C: rd_mux = {24'b0, caps_q};
      8'h10: rd_mux = cap_q[31:0];
      8'h14: rd_mux = cap_q[63:32];
      8'h20: rd_mux = {seq, 4'h0, tag, 3'b0, aborted, op, (st == S_PEND)};
      8'h24: rd_mux = lba[31:0];
      8'h28: rd_mux = lba[63:32];
      8'h2C: rd_mux = {16'b0, nb};
      default: rd_mux = 32'h0;
    endcase
  end
  logic [63:0] ram_rd_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin mb_rsp_valid <= 1'b0; mb_rsp_rdata <= '0; mb_rd_pend <= 1'b0; mb_rd_addr_q <= '0; end
    else begin
      mb_rsp_valid <= 1'b0;
      mb_rd_pend <= 1'b0;
      if (mb_acc && !mb_req_we) begin
        mb_rd_addr_q <= mb_req_addr;
        mb_rd_pend <= 1'b1;
      end
      if (mb_acc && mb_req_we) mb_rsp_valid <= 1'b1;                           // writes are acknowledged the next cycle too
      if (mb_rd_pend) begin
        mb_rsp_valid <= 1'b1;
        mb_rsp_rdata <= mb_rd_addr_q[13] ? (mb_rd_addr_q[2] ? ram_rd_q[63:32] : ram_rd_q[31:0]) : rd_mux;
      end
    end
  end
  // data-window read: the RAM word is looked up in the request cycle (registered for the response)
  wire [BAW-1:0] mb_ridx = BAW'(data_i64);
  always_ff @(posedge clk) if (mb_acc && !mb_req_we) ram_rd_q <= ram[mb_ridx];

  // mailbox write side-effects (one cycle of mw_en per data write)
  always_comb begin
    mw_en = 1'b0; mw_idx = BAW'(data_i64); mw_dat = mb_req_wdata; mw_hi = mb_req_addr[2];
    if (mb_acc && mb_req_we && data_ok) mw_en = 1'b1;
  end

  // ------------------------------------------------------------------ main FSM
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; op <= '0; lba <= '0; nb <= '0; units_done <= '0; seq <= 16'h0001; tag <= '0; aborted <= 1'b0;
      c_status <= '0; c_nblk <= '0; c_dur <= 1'b0; widx <= '0; uw <= '0; ucnt <= '0; fw_en <= 1'b0; fw_idx <= '0; fw_dat <= '0;
      sw_ready <= 1'b0; caps_q <= '0; cap_q <= '0; cnt_reqs <= '0; cnt_stale <= '0; cnt_aborts <= '0;
      for (int i = 0; i < MAX_UNITS; i++) uflags[i] <= '0;
    end else begin
      fw_en <= 1'b0;
      // software-side register writes (live in every state; the guards below keep a stale software from corrupting a request)
      if (mb_acc && mb_req_we && !is_data) begin
        case (mb_req_addr[7:0])
          8'h08: begin sw_ready <= mb_req_wdata[0]; end
          8'h0C: if (!sw_ready) caps_q <= mb_req_wdata[7:0];
          8'h10: if (!sw_ready) cap_q[31:0] <= mb_req_wdata;
          8'h14: if (!sw_ready) cap_q[63:32] <= mb_req_wdata;
          8'h30: if (st == S_PEND) c_status <= mb_req_wdata[3:0];
          8'h34: if (st == S_PEND) c_nblk <= mb_req_wdata[15:0];
          8'h38: if (st == S_PEND) c_dur <= mb_req_wdata[0];
          default: ;
        endcase
        if (mb_req_addr[7:0] >= 8'h80 && mb_req_addr[7:0] < 8'h80 + 8'(4 * MAX_UNITS) && st == S_PEND) uflags[3'((mb_req_addr[7:0] - 8'h80) >> 2)] <= mb_req_wdata[1:0];
      end
      // backend reset (timeout / power fail): drop whatever is in flight
      if (be_reset_i) begin
        if (st != S_IDLE) begin aborted <= 1'b1; cnt_aborts <= cnt_aborts + 32'd1; seq <= seq + 16'd1; end
        st <= S_IDLE;
      end else begin
        case (st)
          S_IDLE: if (be_req_valid && be_req_ready) begin
            op <= be_req_op; lba <= be_req_lba; nb <= be_req_nblk; tag <= be_req_tag; aborted <= 1'b0; cnt_reqs <= cnt_reqs + 32'd1;
            c_status <= BST_OK; c_nblk <= be_req_nblk; c_dur <= 1'b0; widx <= '0; uw <= '0; ucnt <= '0; units_done <= '0;
            for (int i = 0; i < MAX_UNITS; i++) uflags[i] <= '0;
            st <= (be_req_op == BOP_WRITE) ? S_WDATA : S_PEND;
          end
          S_WDATA: if (be_wd_valid && be_wd_ready) begin
            fw_en <= 1'b1; fw_idx <= widx; fw_dat <= be_wd_data; widx <= widx + 1'b1;
            if (be_wd_ulast) begin
              units_done <= units_done + 16'd1;
              if (units_done + 16'd1 == nb) st <= S_PEND;
            end
          end
          S_PEND: if (mb_acc && mb_req_we && mb_req_addr[7:0] == 8'h3C && !is_data) begin
            if (mb_req_wdata[15:0] == seq) begin
              if (op == BOP_READ && c_status == BST_OK) begin widx <= '0; uw <= '0; ucnt <= '0; st <= S_RSTR; end
              else st <= S_CPL;
            end else cnt_stale <= cnt_stale + 32'd1;           // stale commit: ignored
          end
          S_RSTR: if (be_rd_ready) begin
            if (uw == 8'(UW - 1)) begin
              uw <= '0; ucnt <= ucnt + 16'd1; widx <= widx + 1'b1;
              if (ucnt + 16'd1 == nb) st <= S_CPL;
            end else begin uw <= uw + 8'd1; widx <= widx + 1'b1; end
          end
          S_CPL: if (be_cpl_ready) begin st <= S_IDLE; seq <= seq + 16'd1; end
          default: st <= S_IDLE;
        endcase
      end
      // the software that WITHDRAWS (READY=0) while a request is live aborts it like a reset
      if (mb_acc && mb_req_we && !is_data && mb_req_addr[7:0] == 8'h08 && !mb_req_wdata[0] && st != S_IDLE) begin
        st <= S_IDLE; aborted <= 1'b1; seq <= seq + 16'd1; cnt_aborts <= cnt_aborts + 32'd1;
      end
    end
  end
  wire unused_ok = &{1'b0, be_wd_tag, mb_req_addr[1:0], mb_req_addr[12:8]};
endmodule
`default_nettype wire
