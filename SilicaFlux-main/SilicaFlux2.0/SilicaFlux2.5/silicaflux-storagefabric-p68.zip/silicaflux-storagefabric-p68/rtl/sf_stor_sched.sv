// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_sched -- admission control and fair request scheduler
//
//   Each cycle the scheduler may admit the head command of ONE tenant queue into a free command slot.
//   A head command is *eligible* only if all of these hold (docs/03_ARCHITECTURE.md §5):
//     - fabric enabled, queue enabled, no power-fail quiesce
//     - quota:     the tenant has fewer than MAX_INFLIGHT slots in use
//     - reservation: slots are never all consumed by tenants that already hold one while another enabled tenant with
//                  work holds none (a tenant that stops draining its CQ can therefore never starve the others)
//     - rate:      token bucket (blocks per 1024 cycles, burst depth); the bucket may go negative by one command
//     - ordering:  no in-flight FLUSH of the same queue; a FLUSH waits for every earlier command of its queue; a command
//                  whose block range overlaps an in-flight command of the same queue where either side writes waits
//   Among eligible heads: optional read priority (reads before writes, a write can be bypassed at most WR_AGE_MAX times),
//   optional write batching (stay with the tenant that just issued a write up to WR_BATCH_MAX times), otherwise
//   Deficit Round Robin (quantum = WEIGHT blocks; cost = blocks, 1 for FLUSH/DISCARD).
//   One admission per two cycles (the slot table must be refreshed between grants).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_sched
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int NT    = 4,
  parameter int NSLOT = 8,
  parameter int NS_N  = 8,
  parameter int MDTS  = 8
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  input  wire logic                    glb_enable,
  input  wire logic                    pf_active,
  input  wire logic                    rd_prio,
  input  wire logic                    wr_batch,
  input  wire logic [7:0]              wr_batch_max,
  input  wire logic [7:0]              wr_age_max,
  // queue heads
  input  wire logic [NT-1:0]           q_valid,
  input  wire logic [NT*CMD_W-1:0]     q_head,
  output logic [NT-1:0]                q_pop,
  // per-tenant configuration
  input  wire logic [NT*8-1:0]         t_maxinfl,
  input  wire logic [NT*8-1:0]         t_weight,
  input  wire logic [NT*16-1:0]        t_rate,
  input  wire logic [NT*16-1:0]        t_burst,
  // namespace attributes
  input  wire logic [NS_N*64-1:0]      ns_base,
  input  wire logic [NS_N-1:0]         ns_pi,
  input  wire logic [NS_N-1:0]         ns_enc,
  input  wire logic [NS_N*4-1:0]       ns_key,
  // slot table
  input  wire logic [NSLOT-1:0]        s_busy,
  input  wire logic [NSLOT*4-1:0]      s_tenant,
  input  wire logic [NSLOT*64-1:0]     s_abs,
  input  wire logic [NSLOT*16-1:0]     s_nblk,
  input  wire logic [NSLOT-1:0]        s_wr,
  input  wire logic [NSLOT-1:0]        s_flush,
  // admission
  output logic                         iss_valid,
  output logic [3:0]                   iss_slot,
  output logic [3:0]                   iss_tenant,
  output cmd_t                         iss_cmd,
  output logic [63:0]                  iss_abs,
  output logic                         iss_pi,
  output logic                         iss_enc,
  output logic [3:0]                   iss_key,
  // statistics
  output logic [NT-1:0]                throttle,       // head held back by quota / rate this cycle
  output logic [7:0]                   waiting         // heads waiting (valid, not admitted)
);
  localparam int TW = (NT > 1) ? $clog2(NT) : 1;
  localparam int DEF_CAP = 4096;

  cmd_t head [NT];
  logic [NT-1:0] has, elig, cls_wr, is_flush_v, is_write_v, quota_ok, token_ok, reserve_ok, conflict_v;
  logic [7:0]    infl [NT];
  logic [7:0]    free_cnt;
  logic [3:0]    free_idx;
  logic [7:0]    cost [NT];
  logic [63:0]   abs_start [NT];
  logic [NT-1:0] other_waiting;

  // token bucket / DRR state
  logic signed [31:0] tokens [NT];
  logic [15:0]  acc [NT];
  logic signed [31:0] deficit [NT];
  logic [TW-1:0] rr;
  logic         last_valid, last_was_write;
  logic [TW-1:0] last_t;
  logic [7:0]   batch_cnt, age_cnt;

  always_comb begin
    free_cnt = 8'd0; free_idx = 4'd0;
    for (int s = NSLOT - 1; s >= 0; s--) if (!s_busy[s]) begin free_cnt = free_cnt + 8'd1; free_idx = 4'(s); end
    for (int t = 0; t < NT; t++) begin
      head[t] = q_head[t*CMD_W +: CMD_W];
      infl[t] = 8'd0;
      for (int s = 0; s < NSLOT; s++) if (s_busy[s] && s_tenant[s*4 +: 4] == 4'(t)) infl[t] = infl[t] + 8'd1;
    end
    for (int t = 0; t < NT; t++) begin
      automatic logic [7:0] op = head[t].op;
      automatic int         nsi = int'(head[t].nsid);
      automatic logic [64:0] a_end;
      automatic logic [64:0] b_end;
      automatic logic        ov;
      automatic logic        anyfl;
      automatic logic [7:0]  maxi;
      automatic int          others;
      has[t]        = q_valid[t];
      is_flush_v[t] = (op == OP_FLUSH);
      is_write_v[t] = (op == OP_WRITE) || (op == OP_DISCARD);
      cls_wr[t]     = is_write_v[t] || is_flush_v[t];
      cost[t]       = (op == OP_READ || op == OP_WRITE) ? 8'(head[t].nblk) : 8'd1;
      abs_start[t]  = 64'h0;
      for (int n = 0; n < NS_N; n++) if (nsi == n) abs_start[t] = ns_base[n*64 +: 64] + head[t].lba;
      a_end = {1'b0, abs_start[t]} + {33'h0, (is_flush_v[t] ? 32'h0 : head[t].nblk)};
      ov = 1'b0; anyfl = 1'b0;
      for (int s = 0; s < NSLOT; s++) begin
        if (s_busy[s] && s_tenant[s*4 +: 4] == 4'(t)) begin
          if (s_flush[s]) anyfl = 1'b1;
          b_end = {1'b0, s_abs[s*64 +: 64]} + {49'h0, s_nblk[s*16 +: 16]};
          if (!s_flush[s] && !is_flush_v[t] && (s_wr[s] || is_write_v[t]) &&
              ({1'b0, abs_start[t]} < b_end) && ({1'b0, s_abs[s*64 +: 64]} < a_end)) ov = 1'b1;
        end
      end
      conflict_v[t] = anyfl || (is_flush_v[t] && infl[t] != 8'd0) || ov;
      maxi = t_maxinfl[t*8 +: 8];
      if (maxi == 8'd0 || maxi > 8'(NSLOT)) maxi = 8'(NSLOT);
      quota_ok[t] = (infl[t] < maxi);
      token_ok[t] = (t_rate[t*16 +: 16] == 16'h0) || (tokens[t] > 32'sd0);
      others = 0;
      for (int u = 0; u < NT; u++) if (u != t && q_valid[u] && infl[u] == 8'd0) others++;
      reserve_ok[t] = (infl[t] == 8'd0) ? (free_cnt >= 8'd1) : (int'(free_cnt) > others);
      elig[t] = has[t] && glb_enable && !pf_active && !conflict_v[t] && quota_ok[t] && token_ok[t] && reserve_ok[t] &&
                (free_cnt != 8'd0);
      throttle[t] = has[t] && (!quota_ok[t] || !token_ok[t]);
    end
  end

  // ---- selection
  logic [NT-1:0] rd_set, wr_set, act;
  logic          force_wr;
  logic          found;
  logic [TW-1:0] pick;
  logic          pick_batch;
  logic          need_replenish;
  always_comb begin
    rd_set = '0; wr_set = '0;
    for (int t = 0; t < NT; t++) begin
      if (elig[t] && !cls_wr[t]) rd_set[t] = 1'b1;
      if (elig[t] &&  cls_wr[t]) wr_set[t] = 1'b1;
    end
    force_wr = (age_cnt >= wr_age_max) && (wr_set != '0);
    if (rd_prio) act = force_wr ? wr_set : ((rd_set != '0) ? rd_set : wr_set);
    else         act = elig;
    found = 1'b0; pick = '0; pick_batch = 1'b0; need_replenish = 1'b0;
    // write batching: stay with the tenant that just issued a write
    if (wr_batch && last_valid && last_was_write && (batch_cnt < wr_batch_max) &&
        act[last_t] && (head[last_t].op == OP_WRITE)) begin
      found = 1'b1; pick = last_t; pick_batch = 1'b1;
    end
    if (!found) begin
      for (int k = 0; k < NT; k++) begin
        automatic int t = (int'(rr) + k) % NT;
        if (!found && act[t] && (deficit[t] >= 32'(cost[t]))) begin found = 1'b1; pick = TW'(t); end
      end
    end
    if (!found && act != '0) need_replenish = 1'b1;
  end

  wire do_grant = found && !iss_valid;

  always_comb begin
    waiting = 8'd0;
    for (int t = 0; t < NT; t++) if (q_valid[t] && !(do_grant && int'(pick) == t)) waiting = waiting + 8'd1;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      iss_valid <= 1'b0; iss_slot <= '0; iss_tenant <= '0; iss_cmd <= '0; iss_abs <= '0; iss_pi <= 1'b0; iss_enc <= 1'b0;
      iss_key <= '0; q_pop <= '0; rr <= '0; last_valid <= 1'b0; last_was_write <= 1'b0; last_t <= '0; batch_cnt <= '0; age_cnt <= '0;
      for (int t = 0; t < NT; t++) begin tokens[t] <= 32'sd0; acc[t] <= '0; deficit[t] <= 32'sd0; end
    end else begin
      iss_valid <= 1'b0; q_pop <= '0;
      // token buckets (refill, then debit for a grant in the same cycle)
      for (int t = 0; t < NT; t++) begin
        automatic logic [16:0] an = {1'b0, acc[t]} + {1'b0, t_rate[t*16 +: 16]};
        automatic logic signed [31:0] tk = tokens[t];
        if (t_rate[t*16 +: 16] == 16'h0) begin
          tokens[t] <= 32'(signed'({16'h0, t_burst[t*16 +: 16]}));       // bucket starts full when a rate is first configured
          acc[t] <= '0;
        end else begin
          if (an >= 17'd1024) begin
            acc[t] <= 16'(an - 17'd1024);
            if (tk < 32'(signed'({16'h0, t_burst[t*16 +: 16]}))) tk = tk + 32'sd1;
          end else acc[t] <= 16'(an);
          if (do_grant && int'(pick) == t) tk = tk - 32'(cost[t]);
          tokens[t] <= tk;
        end
        if (!has[t]) deficit[t] <= 32'sd0;
      end
      if (need_replenish) begin
        for (int t = 0; t < NT; t++) if (act[t]) begin
          automatic logic [7:0] w = t_weight[t*8 +: 8];
          if (w == 8'd0) w = 8'd1;
          if (deficit[t] < 32'(DEF_CAP)) deficit[t] <= deficit[t] + 32'(signed'({24'h0, w}));
        end
      end
      if (do_grant) begin
        iss_valid <= 1'b1; iss_slot <= free_idx; iss_tenant <= 4'(pick); iss_cmd <= head[pick];
        iss_abs <= abs_start[pick]; q_pop[pick] <= 1'b1;
        iss_pi <= 1'b0; iss_enc <= 1'b0; iss_key <= 4'h0;
        for (int n = 0; n < NS_N; n++) if (int'(head[pick].nsid) == n) begin
          iss_pi <= ns_pi[n]; iss_enc <= ns_enc[n]; iss_key <= ns_key[n*4 +: 4];
        end
        deficit[pick] <= deficit[pick] - 32'(cost[pick]);
        rr <= TW'((int'(pick) + 1) % NT);
        // class bookkeeping
        last_valid <= 1'b1; last_t <= pick; last_was_write <= (head[pick].op == OP_WRITE);
        if (pick_batch) batch_cnt <= batch_cnt + 8'd1; else batch_cnt <= 8'd1;
        if (rd_prio) begin
          if (!cls_wr[pick]) begin if (wr_set != '0) age_cnt <= age_cnt + 8'd1; end
          else age_cnt <= 8'd0;
        end
      end
    end
  end
  wire unused_ok = &{1'b0, is_write_v, last_was_write};
endmodule
`default_nettype wire
