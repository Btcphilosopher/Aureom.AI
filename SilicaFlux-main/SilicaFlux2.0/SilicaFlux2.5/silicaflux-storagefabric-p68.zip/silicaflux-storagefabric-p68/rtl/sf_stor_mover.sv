// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_mover -- fabric side of the backend contract (docs/02 §7)
//
//   Jobs {slot, op, absolute LBA, nblk} from the command slots are turned into backend requests (tag = slot).
//   WRITE: after the request is accepted, the staged units (512 data bytes [+ 16 trailer bytes for a PI-native
//          backend]) are streamed to the backend as 64-bit beats, in request order.
//   READ : the request is issued; the data that comes back (in request order, tagged) is written into the slot's
//          staging area as it arrives; per-unit flags (media error / never-written) are kept per slot.
//   The job is "granted" (m_gnt of the slot) when the request was accepted and, for a WRITE, all data was handed over.
//   The completion of the backend request arrives separately on the backend completion channel (routed by the top).
//   A backend reset flushes every in-flight transfer here.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_mover
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int NSLOT      = 8,
  parameter int MDTS       = 8,
  parameter int WORDS_LOG2 = 13,
  parameter int DATA0_WORD = 512,
  parameter int SLOT_WORDS = 528
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  input  wire logic                    be_pi_native_i,
  input  wire logic                    be_rst_i,
  // job
  input  wire logic                    job_valid,
  input  wire logic [3:0]              job_slot,
  input  wire logic [2:0]              job_op,
  input  wire logic [63:0]             job_abs,
  input  wire logic [15:0]             job_nblk,
  output logic                         job_start,       // job accepted by the mover (arbiter hold)
  output logic                         job_done,        // pulse: request issued and (WRITE) data handed over
  output logic [3:0]                   job_done_slot,
  // backend
  output logic                         be_req_valid,
  input  wire logic                    be_req_ready,
  output logic [2:0]                   be_req_op,
  output logic [63:0]                  be_req_lba,
  output logic [15:0]                  be_req_nblk,
  output logic [3:0]                   be_req_tag,
  output logic                         be_wd_valid,
  input  wire logic                    be_wd_ready,
  output logic [63:0]                  be_wd_data,
  output logic                         be_wd_ulast,
  output logic [3:0]                   be_wd_tag,
  input  wire logic                    be_rd_valid,
  output logic                         be_rd_ready,
  input  wire logic [3:0]              be_rd_tag,
  input  wire logic [63:0]             be_rd_data,
  input  wire logic                    be_rd_ulast,
  input  wire logic [1:0]              be_rd_uflags,
  // local memory
  output logic                         lm_req,
  output logic                         lm_we,
  output logic [WORDS_LOG2-1:0]        lm_addr,
  output logic [63:0]                  lm_wdata,
  input  wire logic                    lm_gnt,
  input  wire logic                    lm_rvalid,
  input  wire logic [63:0]             lm_rdata,
  // per-slot read-unit flags
  output logic [NSLOT*16-1:0]          uunm_o,
  output logic [NSLOT*16-1:0]          uerr_o,
  output logic                         stall_o              // pulse: a beat was ready but the backend / memory stalled it
);
  localparam int MET_OFF = MDTS * 64;
  wire [6:0] uw = be_pi_native_i ? 7'd66 : 7'd64;

  // ------------------------------------------------------------------ job FSM (requests + write data)
  typedef enum logic [2:0] {M_IDLE, M_REQ, M_STREAM, M_DONE} mst_t;
  mst_t        mst;
  logic [3:0]  slot_q;
  logic [2:0]  op_q;
  logic [63:0] abs_q;
  logic [15:0] nblk_q;
  logic [15:0] u_iss, u_rcv;           // write stream: unit index of the next word to issue / to hand over
  logic [6:0]  w_iss, w_rcv;
  logic        all_iss;
  // source read pipeline (2-entry FIFO of words + last flag)
  logic [63:0] sf_data [2];
  logic        sf_last [2];
  logic [1:0]  sf_cnt;
  logic        sf_rp, sf_wp;
  logic        infl;                   // a read was issued last cycle
  logic        infl_last;

  wire can_take = (mst == M_IDLE) && !job_done;     // job_done is visible while the slot still shows m_valid: do not re-take it
  assign job_start = can_take && job_valid;
  assign be_req_valid = (mst == M_REQ);
  assign be_req_op    = op_q;
  assign be_req_lba   = abs_q;
  assign be_req_nblk  = nblk_q;
  assign be_req_tag   = slot_q;

  // source read request
  wire [WORDS_LOG2-1:0] slot_base_w = WORDS_LOG2'(DATA0_WORD + SLOT_WORDS * int'(slot_q));
  wire [WORDS_LOG2-1:0] src_addr = (w_iss < 7'd64) ? (slot_base_w + WORDS_LOG2'(int'(u_iss) * 64 + int'(w_iss))) :
                                   (slot_base_w + WORDS_LOG2'(MET_OFF + int'(u_iss) * 2 + int'(w_iss) - 64));
  wire src_credit = (({1'b0, sf_cnt} + {2'b0, infl}) < 3'd2);
  wire src_want   = (mst == M_STREAM) && !all_iss && src_credit;

  // sink write request
  logic [15:0] k_u [NSLOT];            // per-tag unit index
  logic [6:0]  k_w [NSLOT];            // per-tag word index
  logic [3:0]  snk_tag;
  assign snk_tag = be_rd_tag;
  wire [WORDS_LOG2-1:0] snk_base = WORDS_LOG2'(DATA0_WORD + SLOT_WORDS * int'(snk_tag));
  wire [WORDS_LOG2-1:0] snk_addr = (k_w[snk_tag[2:0]] < 7'd64) ?
        (snk_base + WORDS_LOG2'(int'(k_u[snk_tag[2:0]]) * 64 + int'(k_w[snk_tag[2:0]]))) :
        (snk_base + WORDS_LOG2'(MET_OFF + int'(k_u[snk_tag[2:0]]) * 2 + int'(k_w[snk_tag[2:0]]) - 64));
  wire snk_want = be_rd_valid && (int'(be_rd_tag) < NSLOT);

  assign lm_req   = snk_want || src_want;
  assign lm_we    = snk_want;
  assign lm_addr  = snk_want ? snk_addr : src_addr;
  assign lm_wdata = be_rd_data;
  assign be_rd_ready = snk_want && lm_gnt;
  wire src_grant = src_want && !snk_want && lm_gnt;

  // backend write data
  assign be_wd_valid = (sf_cnt != 2'd0);
  assign be_wd_data  = sf_data[sf_rp];
  assign be_wd_ulast = sf_last[sf_rp];
  assign be_wd_tag   = slot_q;
  wire wd_hs = be_wd_valid && be_wd_ready;

  assign stall_o = (be_wd_valid && !be_wd_ready) || (snk_want && !lm_gnt);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mst <= M_IDLE; slot_q <= '0; op_q <= '0; abs_q <= '0; nblk_q <= '0; u_iss <= '0; u_rcv <= '0; w_iss <= '0; w_rcv <= '0;
      all_iss <= 1'b0; sf_cnt <= '0; sf_rp <= 1'b0; sf_wp <= 1'b0; infl <= 1'b0; infl_last <= 1'b0; job_done <= 1'b0;
      job_done_slot <= '0; uunm_o <= '0; uerr_o <= '0;
      for (int i = 0; i < NSLOT; i++) begin k_u[i] <= '0; k_w[i] <= '0; end
      sf_data[0] <= '0; sf_data[1] <= '0; sf_last[0] <= 1'b0; sf_last[1] <= 1'b0;
    end else begin
      job_done <= 1'b0;
      if (be_rst_i) begin
        mst <= M_IDLE; sf_cnt <= '0; sf_rp <= 1'b0; sf_wp <= 1'b0; infl <= 1'b0; all_iss <= 1'b0;
        for (int i = 0; i < NSLOT; i++) begin k_u[i] <= '0; k_w[i] <= '0; end
      end else begin
        // ---------------- request / stream FSM
        case (mst)
          M_IDLE: if (job_valid && !job_done) begin
            slot_q <= job_slot; op_q <= job_op; abs_q <= job_abs; nblk_q <= job_nblk; mst <= M_REQ;
            u_iss <= '0; w_iss <= '0; u_rcv <= '0; w_rcv <= '0; all_iss <= 1'b0;
            if (job_op == BOP_READ) begin
              k_u[job_slot[2:0]] <= '0; k_w[job_slot[2:0]] <= '0;
              uunm_o[int'(job_slot[2:0])*16 +: 16] <= '0; uerr_o[int'(job_slot[2:0])*16 +: 16] <= '0;
            end
          end
          M_REQ: if (be_req_ready) begin
            if (op_q == BOP_WRITE) mst <= M_STREAM; else mst <= M_DONE;
          end
          M_STREAM: begin
            if (u_rcv == nblk_q) begin mst <= M_DONE; end
          end
          M_DONE: begin job_done <= 1'b1; job_done_slot <= slot_q; mst <= M_IDLE; end
          default: mst <= M_IDLE;
        endcase

        // ---------------- write source: issue reads
        infl <= src_grant; infl_last <= (w_iss == uw - 7'd1);
        if (src_grant) begin
          if (w_iss == uw - 7'd1) begin
            w_iss <= '0; u_iss <= u_iss + 16'd1;
            if (u_iss + 16'd1 == nblk_q) all_iss <= 1'b1;
          end else w_iss <= w_iss + 7'd1;
        end
        if (infl) begin
          sf_data[sf_wp] <= lm_rdata; sf_last[sf_wp] <= infl_last; sf_wp <= !sf_wp;
        end
        if (wd_hs) begin
          sf_rp <= !sf_rp;
          if (be_wd_ulast) u_rcv <= u_rcv + 16'd1;
        end
        sf_cnt <= sf_cnt + {1'b0, infl} - {1'b0, wd_hs};

        // ---------------- read sink bookkeeping
        if (be_rd_ready) begin
          if (be_rd_ulast) begin
            if (be_rd_uflags[UF_ERR])      uerr_o[int'(snk_tag[2:0])*16 + int'(k_u[snk_tag[2:0]][3:0])] <= 1'b1;
            if (be_rd_uflags[UF_UNMAPPED]) uunm_o[int'(snk_tag[2:0])*16 + int'(k_u[snk_tag[2:0]][3:0])] <= 1'b1;
            k_u[snk_tag[2:0]] <= k_u[snk_tag[2:0]] + 16'd1; k_w[snk_tag[2:0]] <= '0;
          end else k_w[snk_tag[2:0]] <= k_w[snk_tag[2:0]] + 7'd1;
        end
      end
    end
  end
  wire unused_ok = &{1'b0, w_rcv, job_slot[3], lm_rvalid};
endmodule
`default_nettype wire
