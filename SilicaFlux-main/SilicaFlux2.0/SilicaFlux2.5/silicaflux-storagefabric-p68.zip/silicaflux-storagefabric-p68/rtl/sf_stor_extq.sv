// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_extq -- extra command source ("ext" pseudo-queue) for in-fabric adapters
//   (the VirtIO block adapter).  A single command is validated with the SAME rules as a tenant descriptor
//   (sf_stor_validate, docs/02 §2) under a hardware-fixed tenant id (EXT_TENANT), so namespace ownership, bounds and
//   length rules apply unchanged; the command then competes in the scheduler like any queue.  Data does not go through the
//   protected DMA: the adapter fills / drains the slot's staging buffer through the local-memory port.
//   Validation failures complete immediately without a slot.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_extq
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int NS_N       = 8,
  parameter int MDTS       = 8,
  parameter int EXT_TENANT = 3
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic [31:0]       now_i,
  input  wire logic              enable_i,
  // adapter side
  input  wire logic              ext_cmd_valid,
  output logic                   ext_cmd_ready,
  input  wire logic [7:0]        ext_op,
  input  wire logic [7:0]        ext_nsid,
  input  wire logic [63:0]       ext_lba,
  input  wire logic [15:0]       ext_nblk,
  input  wire logic [15:0]       ext_txn,
  // namespace table
  input  wire logic              be_discard_i,
  input  wire logic [NS_N-1:0]   ns_valid_i,
  input  wire logic [NS_N*4-1:0] ns_owner_i,
  input  wire logic [NS_N-1:0]   ns_ro_i,
  input  wire logic [NS_N-1:0]   ns_enc_i,
  input  wire logic [NS_N-1:0]   ns_keyok_i,
  input  wire logic [NS_N*64-1:0] ns_size_i,
  // scheduler side
  output cmd_t                   head_o,
  output logic                   head_valid_o,
  input  wire logic              head_pop_i,
  // immediate completions (validation failures)
  output logic                   icpl_valid,
  input  wire logic              icpl_ready,
  output cpl_t                   icpl
);
  logic        have;
  logic [7:0]  op_q, nsid_q;
  logic [63:0] lba_q;
  logic [15:0] nblk_q, txn_q;
  logic [31:0] t_fetch;
  logic [511:0] desc;
  always_comb begin
    desc = '0;
    desc[7:0]     = SFS_DESC_VERSION;
    desc[15:8]    = op_q;
    desc[32+:16]  = txn_q;
    desc[48+:8]   = nsid_q;
    desc[64+:64]  = lba_q;
    desc[128+:32] = {16'h0, nblk_q};
    desc[160+:32] = (op_q == OP_WRITE || op_q == OP_READ) ? {7'h0, nblk_q, 9'h0} : 32'h0;
    desc[256+:16] = 16'(EXT_TENANT);                 // TENANT_CLAIM = the hardware binding of this source
  end
  logic        v_ok;
  logic [7:0]  v_status, v_detail, v_op, v_nsid;
  logic [15:0] v_flags, v_txn;
  logic [63:0] v_lba, v_addr;
  logic [31:0] v_nblk, v_hcrc;
  wire  [7:0]  nsi = nsid_q;
  logic        ns_v_s, ns_ro_s, ns_enc_s, ns_key_s;
  logic [3:0]  ns_own_s;
  logic [63:0] ns_size_s;
  always_comb begin
    ns_v_s = 1'b0; ns_ro_s = 1'b0; ns_enc_s = 1'b0; ns_key_s = 1'b0; ns_own_s = 4'hF; ns_size_s = '0;
    for (int n = 0; n < NS_N; n++) if (int'(nsi) == n) begin
      ns_v_s = ns_valid_i[n]; ns_ro_s = ns_ro_i[n]; ns_enc_s = ns_enc_i[n]; ns_key_s = ns_keyok_i[n];
      ns_own_s = ns_owner_i[n*4 +: 4]; ns_size_s = ns_size_i[n*64 +: 64];
    end
  end
  sf_stor_validate #(.MDTS(MDTS)) u_val (
    .desc_i(desc), .tenant_i(4'(EXT_TENANT)), .ns_known_i(int'(nsi) < NS_N), .ns_valid_i(ns_v_s), .ns_owner_i(ns_own_s), .ns_ro_i(ns_ro_s),
    .ns_size_i(ns_size_s), .be_discard_i, .ns_enc_i(ns_enc_s), .key_ready_i(ns_key_s),
    .ok_o(v_ok), .status_o(v_status), .detail_o(v_detail), .op_o(v_op), .flags_o(v_flags), .txn_o(v_txn), .nsid_o(v_nsid),
    .lba_o(v_lba), .nblk_o(v_nblk), .addr_o(v_addr), .hcrc_o(v_hcrc)
  );
  logic icpl_done;
  assign ext_cmd_ready = !have && enable_i;
  assign head_valid_o  = have && v_ok && (op_q != OP_GET_CAPACITY);
  always_comb begin
    head_o = '0;
    head_o.op = v_op; head_o.flags = v_flags; head_o.txn = v_txn; head_o.nsid = v_nsid; head_o.lba = v_lba; head_o.nblk = v_nblk;
    head_o.addr = v_addr; head_o.hcrc = v_hcrc; head_o.t_fetch = t_fetch;
    icpl = '0;
    icpl.txn = txn_q; icpl.status = v_status; icpl.detail = v_detail; icpl.op = op_q; icpl.t_fetch = t_fetch;
    icpl.t_admit = now_i; icpl.t_issue = now_i; icpl.t_bedone = now_i;
  end
  assign icpl_valid = have && (!v_ok || op_q == OP_GET_CAPACITY);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin have <= 1'b0; op_q <= '0; nsid_q <= '0; lba_q <= '0; nblk_q <= '0; txn_q <= '0; t_fetch <= '0; end
    else begin
      if (ext_cmd_valid && ext_cmd_ready) begin
        have <= 1'b1; op_q <= ext_op; nsid_q <= ext_nsid; lba_q <= ext_lba; nblk_q <= ext_nblk; txn_q <= ext_txn; t_fetch <= now_i;
      end
      if ((head_pop_i && head_valid_o) || (icpl_valid && icpl_ready)) have <= 1'b0;
    end
  end
  wire unused_ok = &{1'b0, v_addr, v_flags, v_hcrc, v_nsid, ns_enc_s};
endmodule
`default_nettype wire
