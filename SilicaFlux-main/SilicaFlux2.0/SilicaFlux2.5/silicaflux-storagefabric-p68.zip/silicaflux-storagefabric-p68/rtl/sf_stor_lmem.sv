// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_lmem -- local staging memory, true dual port, 64-bit, byte enables
//   Port A: AXI slave side (CloudDMA moves host data in and out).   Port B: fabric-internal clients (via sf_stor_lm_arb).
//   Synchronous read (data one cycle after the request).  Simultaneous access to the SAME word from both ports is
//   a design error (ownership of staging regions is exclusive per slot/phase); port B wins a write collision.
//   Simulation / FPGA-inferrable.  An ASIC needs a two-port SRAM macro (docs/11: not available in the repository).
// Classification: SYNTHESIZABLE (flop array; macro-mappable)
// =============================================================================
`default_nettype none
module sf_stor_lmem #(
  parameter int WORDS_LOG2 = 13
) (
  input  wire logic                   clk,
  input  wire logic                   a_en,
  input  wire logic                   a_we,
  input  wire logic [WORDS_LOG2-1:0]  a_addr,
  input  wire logic [63:0]            a_wdata,
  input  wire logic [7:0]             a_be,
  output logic [63:0]                 a_rdata,
  input  wire logic                   b_en,
  input  wire logic                   b_we,
  input  wire logic [WORDS_LOG2-1:0]  b_addr,
  input  wire logic [63:0]            b_wdata,
  input  wire logic [7:0]             b_be,
  output logic [63:0]                 b_rdata
);
  logic [63:0] mem [0:(1<<WORDS_LOG2)-1];
  always_ff @(posedge clk) begin
    if (a_en) begin
      if (a_we) for (int i = 0; i < 8; i++) if (a_be[i]) mem[a_addr][8*i +: 8] <= a_wdata[8*i +: 8];
      a_rdata <= mem[a_addr];
    end
    if (b_en) begin
      if (b_we) for (int i = 0; i < 8; i++) if (b_be[i]) mem[b_addr][8*i +: 8] <= b_wdata[8*i +: 8];
      b_rdata <= mem[b_addr];
    end
  end
endmodule
`default_nettype wire
