// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_validate -- command validation (combinational; docs/02_HOST_INTERFACE.md §2)
//   Input : the 64-byte descriptor (16 words), the hardware tenant binding, the addressed namespace entry.
//   Output: ok, STATUS/DETAIL of the FIRST failing rule (order fixed by the ABI), decoded fields.
//   A rejected command never reaches a slot, the DMA or the backend.
//   The namespace entry is selected by the caller from the descriptor NSID (nsid_o); `ns_known_i` is 0 when NSID is
//   outside the table.  Ownership is evaluated here so existence and ownership are indistinguishable.
// Classification: SYNTHESIZABLE (combinational)
// =============================================================================
`default_nettype none
module sf_stor_validate
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int MDTS = 8
) (
  input  wire logic [511:0]  desc_i,             // word n = desc_i[32n +: 32]
  input  wire logic [3:0]    tenant_i,           // hardware binding
  // namespace entry for desc NSID
  input  wire logic          ns_known_i,         // NSID < NS_N
  input  wire logic          ns_valid_i,
  input  wire logic [3:0]    ns_owner_i,
  input  wire logic          ns_ro_i,
  input  wire logic [63:0]   ns_size_i,
  // capabilities
  input  wire logic          be_discard_i,       // backend supports DISCARD with zero-fill semantics
  input  wire logic          ns_enc_i,
  input  wire logic          key_ready_i,        // key slot of the namespace is loaded (only meaningful if ns_enc_i)
  output logic               ok_o,
  output logic [7:0]         status_o,
  output logic [7:0]         detail_o,
  output logic [7:0]         op_o,
  output logic [15:0]        flags_o,
  output logic [15:0]        txn_o,
  output logic [7:0]         nsid_o,
  output logic [63:0]        lba_o,
  output logic [31:0]        nblk_o,
  output logic [63:0]        addr_o,
  output logic [31:0]        hcrc_o
);
  function automatic logic [31:0] w(input int n);
    return desc_i[32*n +: 32];
  endfunction
  logic [7:0] ver, op;
  logic [15:0] flags;
  assign ver = w(0)[7:0];  assign op = w(0)[15:8];  assign flags = w(0)[31:16];
  assign op_o = op; assign flags_o = flags; assign txn_o = w(1)[15:0]; assign nsid_o = w(1)[23:16];
  assign lba_o = {w(3), w(2)}; assign nblk_o = w(4); assign addr_o = {w(7), w(6)}; assign hcrc_o = w(9);

  wire is_wr   = (op == OP_WRITE);
  wire is_rd   = (op == OP_READ);
  wire is_fl   = (op == OP_FLUSH);
  wire is_cap  = (op == OP_GET_CAPACITY);
  wire is_dis  = (op == OP_DISCARD);
  wire is_data = is_wr || is_rd;
  wire op_ok   = is_wr || is_rd || is_fl || is_cap || is_dis;

  wire f_fua  = flags[FLG_FUA];
  wire f_hcrc = flags[FLG_HCRC];
  wire f_rcrc = flags[FLG_RCRC];
  wire rsv_flags = |flags[15:3];
  wire rsv_words = (w(1)[31:24] != 8'h0) || (w(8)[31:16] != 16'h0) || (|desc_i[32*10 +: 32*6]);
  wire flag_combo_bad = (f_hcrc && !is_wr) || (f_fua && !is_wr) || (f_rcrc && !is_data);
  wire hcrc_word_bad  = !f_hcrc && (w(9) != 32'h0);

  wire        ns_mine   = ns_known_i && ns_valid_i && (ns_owner_i == tenant_i);
  wire [31:0] nblk      = w(4);
  wire [31:0] dlen      = w(5);
  wire [63:0] lba       = lba_o;
  wire [63:0] daddr     = addr_o;
  wire [63:0] want_len  = {23'h0, nblk, 9'h0} >> 0;     // nblk*512 (41 bits used)
  // length rules
  logic       len_bad;
  logic [7:0] len_detail;
  always_comb begin
    len_bad = 1'b0; len_detail = 8'h0;
    if (is_data) begin
      if (nblk == 32'h0)                       begin len_bad = 1'b1; len_detail = DT_LEN_ZERO; end
      else if (nblk > 32'(MDTS))               begin len_bad = 1'b1; len_detail = DT_LEN_TOO_LARGE; end
      else if ({32'h0, dlen} != want_len)      begin len_bad = 1'b1; len_detail = DT_LEN_MISMATCH; end
    end else if (is_dis) begin
      if (nblk == 32'h0)                       begin len_bad = 1'b1; len_detail = DT_LEN_ZERO; end
      else if (nblk > 32'(SFS_DISCARD_MAX))    begin len_bad = 1'b1; len_detail = DT_LEN_TOO_LARGE; end
      else if (dlen != 32'h0)                  begin len_bad = 1'b1; len_detail = DT_LEN_NOT_ZERO; end
    end else begin // FLUSH, GET_CAPACITY
      if (nblk != 32'h0 || dlen != 32'h0)      begin len_bad = 1'b1; len_detail = DT_LEN_NOT_ZERO; end
    end
  end
  wire addr_bad = is_data ? (daddr[1:0] != 2'b00) : (daddr != 64'h0);
  // range: lba + nblk <= size, no overflow (65-bit)
  wire [64:0] end_lba   = {1'b0, lba} + {33'h0, nblk};
  wire        range_bad = (is_data || is_dis) && (end_lba > {1'b0, ns_size_i});   // FLUSH / GET_CAPACITY: LBA unused
  always_comb begin
    ok_o = 1'b0; status_o = ST_SUCCESS; detail_o = 8'h0;
    if (ver != SFS_DESC_VERSION)                         begin status_o = ST_INVALID_FIELD;   detail_o = DT_VERSION; end
    else if (!op_ok)                                     begin status_o = ST_INVALID_OPCODE; end
    else if (w(8)[15:0] != {12'h0, tenant_i})            begin status_o = ST_TENANT_MISMATCH; end
    else if (rsv_flags || rsv_words || hcrc_word_bad)    begin status_o = ST_INVALID_FIELD;   detail_o = DT_RESERVED; end
    else if (flag_combo_bad)                             begin status_o = ST_INVALID_FIELD;   detail_o = DT_FLAGS; end
    else if (!ns_mine)                                   begin status_o = ST_INVALID_NS; end
    else if (is_dis && !be_discard_i)                    begin status_o = ST_UNSUPPORTED; end
    else if ((is_wr || is_dis) && ns_ro_i)               begin status_o = ST_NS_READONLY; end
    else if (len_bad)                                    begin status_o = ST_LEN_ERROR;       detail_o = len_detail; end
    else if (addr_bad)                                   begin status_o = ST_INVALID_FIELD;   detail_o = DT_ADDR_ALIGN; end
    else if (range_bad)                                  begin status_o = ST_LBA_RANGE; end
    else if (is_data && ns_enc_i && !key_ready_i)        begin status_o = ST_CRYPTO_ERROR;    detail_o = DT_KEY_NOT_READY; end
    else ok_o = 1'b1;
  end
endmodule
`default_nettype wire
