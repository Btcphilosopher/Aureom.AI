// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_core -- the fabric without a backend (backend contract on its ports)
//
//   Cloud/VM storage request -> command validation -> queue scheduler -> protected DMA -> data integrity ->
//   storage backend -> completion.
//   See silicaflux_storage_fabric.sv for the version with a selectable backend and docs/03_ARCHITECTURE.md.
// Classification: SYNTHESIZABLE (local memory is a flop array; macros needed for silicon)
// =============================================================================
`default_nettype none
module sf_stor_core
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int NT         = 4,      // tenants (hardware-bound queue pairs), <= 16
  parameter int NS_N       = 8,      // namespaces, <= 16
  parameter int NSLOT      = 8,      // in-flight commands, <= 8 (per-slot flag arrays are 8 wide)
  parameter int MDTS       = 8,      // blocks per command, <= 16
  parameter int SQ_MAX     = 32,
  parameter int CQ_MAX     = 32,
  parameter int SQ_BATCH   = 4,      // descriptors fetched per DMA
  parameter int PQ         = 4,      // parsed commands buffered per tenant
  parameter int AW         = 48,
  parameter int DOM_W      = 4,
  parameter int NUM_CH     = 2,
  parameter int BE_TYPE    = 0,
  parameter bit ENABLE_XTS = 1'b0,
  parameter bit HAS_VIRTIO = 1'b0,
  parameter int EXT_TENANT = 3,      // hardware-fixed tenant id of the ext command source (VirtIO adapter)
  parameter int NKEY       = 4,
  parameter int TRACE_DEPTH = 64
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // ---- tenant MMIO (function id is hardware-bound by the platform)
  input  wire logic                    tmmio_valid,
  input  wire logic                    tmmio_we,
  input  wire logic [3:0]              tmmio_fn,
  input  wire logic [11:0]             tmmio_addr,
  input  wire logic [31:0]             tmmio_wdata,
  output logic                         tmmio_rsp_valid,
  output logic [31:0]                  tmmio_rsp_rdata,
  output logic                         tmmio_rsp_err,
  // ---- management MMIO (privileged)
  input  wire logic                    mmio_valid,
  input  wire logic                    mmio_we,
  input  wire logic [11:0]             mmio_addr,
  input  wire logic [31:0]             mmio_wdata,
  output logic                         mmio_rsp_valid,
  output logic [31:0]                  mmio_rsp_rdata,
  output logic                         mmio_rsp_err,
  output logic [NT-1:0]                irq,
  // ---- power-fail warning (PowerSafe handshake)
  input  wire logic                    pf_warn_i,
  output logic                         pf_quiesced_o,
  // ---- AXI4 master to tenant memory (host side; carries domain / asid sidebands)
  output logic                         m_ar_valid, input wire logic m_ar_ready,
  output logic [3:0]                   m_ar_id,
  output logic [AW-1:0]                m_ar_addr,
  output logic [7:0]                   m_ar_len,
  output logic [2:0]                   m_ar_size,
  output logic [1:0]                   m_ar_burst,
  output logic [3:0]                   m_ar_asid,
  output logic [DOM_W-1:0]             m_ar_domain,
  input  wire logic                    m_r_valid, output logic m_r_ready,
  input  wire logic [3:0]              m_r_id,
  input  wire logic [63:0]             m_r_data,
  input  wire logic [1:0]              m_r_resp,
  input  wire logic                    m_r_last,
  output logic                         m_aw_valid, input wire logic m_aw_ready,
  output logic [3:0]                   m_aw_id,
  output logic [AW-1:0]                m_aw_addr,
  output logic [7:0]                   m_aw_len,
  output logic [2:0]                   m_aw_size,
  output logic [1:0]                   m_aw_burst,
  output logic [3:0]                   m_aw_asid,
  output logic [DOM_W-1:0]             m_aw_domain,
  output logic                         m_w_valid, input wire logic m_w_ready,
  output logic [63:0]                  m_w_data,
  output logic [7:0]                   m_w_strb,
  output logic                         m_w_last,
  input  wire logic                    m_b_valid, output logic m_b_ready,
  input  wire logic [3:0]              m_b_id,
  input  wire logic [1:0]              m_b_resp,
  // ---- backend contract (docs/02 §7)
  input  wire logic                    be_ready,
  input  wire logic [63:0]             be_capacity,
  input  wire logic [7:0]              be_caps,
  output logic                         be_reset,
  output logic                         be_req_valid,
  input  wire logic                    be_req_ready,
  output logic [2:0]                   be_req_op,
  output logic [63:0]                  be_req_lba,
  output logic [15:0]                  be_req_nblk,
  output logic [3:0]                   be_req_tag,
  output logic                         be_wd_valid,
  input  wire logic                    be_wd_ready,
  output logic [63:0]                  be_wd_data,
  output logic                         be_wd_ulast,
  output logic [3:0]                   be_wd_tag,
  input  wire logic                    be_rd_valid,
  output logic                         be_rd_ready,
  input  wire logic [3:0]              be_rd_tag,
  input  wire logic [63:0]             be_rd_data,
  input  wire logic                    be_rd_ulast,
  input  wire logic [1:0]              be_rd_uflags,
  input  wire logic                    be_cpl_valid,
  output logic                         be_cpl_ready,
  input  wire logic [3:0]              be_cpl_tag,
  input  wire logic [3:0]              be_cpl_status,
  input  wire logic                    be_cpl_durable,
  input  wire logic [15:0]             be_cpl_nblk,
  // ---- optional extra command source (VirtIO adapter): one command at a time, data through the staging memory
  input  wire logic                    ext_cmd_valid,
  output logic                         ext_cmd_ready,
  input  wire logic [7:0]              ext_op,
  input  wire logic [7:0]              ext_nsid,
  input  wire logic [63:0]             ext_lba,
  input  wire logic [15:0]             ext_nblk,
  input  wire logic [15:0]             ext_txn,
  output logic                         ext_cpl_valid,
  input  wire logic                    ext_cpl_ready,
  output logic [7:0]                   ext_cpl_status,
  output logic [7:0]                   ext_cpl_detail,
  output logic                         ext_cpl_durable,
  output logic [15:0]                  ext_cpl_nblk,
  output logic                         ext_in_req,         // fill the staging buffer now (WRITE data)
  input  wire logic                    ext_in_done,
  output logic                         ext_out_req,        // the staging buffer holds READ data
  input  wire logic                    ext_out_done,
  output logic [12:0]                  ext_data_base,      // word address of the active command's staging data area
  input  wire logic                    ext_lm_req,
  input  wire logic                    ext_lm_we,
  input  wire logic [12:0]             ext_lm_addr,
  input  wire logic [63:0]             ext_lm_wdata,
  output logic                         ext_lm_gnt,
  output logic                         ext_lm_rvalid,
  output logic [63:0]                  ext_lm_rdata
);
  // ------------------------------------------------------------------ geometry
  localparam int SLOT_BYTES   = MDTS * 528;
  localparam int SLOT_WORDS   = MDTS * 66;
  localparam int SQ_BYTE0     = 'h100;
  localparam int CQ_BYTE0     = SQ_BYTE0 + NT * SQ_BATCH * 64;
  localparam int DATA_BYTE0   = (((CQ_BYTE0 + NT * 32) + 4095) / 4096) * 4096;
  localparam int LMEM_NEED    = DATA_BYTE0 + NSLOT * SLOT_BYTES;
  localparam int WORDS_LOG2   = clog2i((LMEM_NEED + 7) / 8);
  localparam int LMEM_BYTES   = (1 << WORDS_LOG2) * 8;
  localparam int DATA0_WORD   = DATA_BYTE0 / 8;
  localparam int MXO          = 4;
  localparam int IDW          = ((NUM_CH > 1) ? $clog2(NUM_CH) : 1) + 2 + 1;     // must equal CloudDMA ID_W (RD_OUT=WR_OUT=4)
  localparam int NCLI         = NT + 4;                                           // local-memory port-B clients
  localparam int NREQ         = 2 * NT + NSLOT;
  localparam int NQ           = NT + 1;                                           // scheduler sources: tenant queues + ext

  // ------------------------------------------------------------------ time, reset sequencing
  logic [31:0] now;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) now <= '0; else now <= now + 32'd1;
  end

  // ------------------------------------------------------------------ management
  logic        glb_enable, soft_rst, trace_en, clr_counters, rd_prio, wr_batch, pf_force;
  logic [31:0] cmd_timeout;
  logic [7:0]  wr_batch_max, wr_age_max;
  logic [NT-1:0]     t_allowed;
  logic [NT*8-1:0]   t_maxinfl, t_weight;
  logic [NT*16-1:0]  t_rate, t_burst;
  logic [NS_N-1:0]   ns_valid, ns_ro, ns_enc, ns_pi;
  logic [NS_N*4-1:0] ns_owner, ns_key;
  logic [NS_N*64-1:0] ns_base, ns_size;
  logic        mg_be_reset;
  logic        pt_wr, pt_valid, pt_rej, dma_init_done;
  logic [3:0]  pt_idx, pt_dom;
  logic [AW-1:0] pt_base;
  logic [AW:0]   pt_size;
  logic [1:0]    pt_perm;
  logic [NKEY-1:0] key_valid, key256;
  logic [NKEY*256-1:0] key1, key2;
  logic        key_zero, key_commit;
  logic        tr_valid;
  logic [255:0] tr_rec;
  logic [PC_N*64-1:0] perf_flat;
  logic        pf_active;
  logic [7:0]  busy_slots, be_busy;
  logic [31:0] m_rdata_w; logic m_err_w;

  wire be_pi_native  = be_caps[BCAP_PI_NATIVE];
  wire be_volatile   = be_caps[BCAP_VOLATILE_CACHE];
  wire be_discard_ok = be_caps[BCAP_DISCARD] && be_caps[BCAP_DISCARD_ZERO];

  sf_stor_mgmt #(.NT(NT), .NSLOT(NSLOT), .NS_N(NS_N), .MDTS(MDTS), .SQ_MAX(SQ_MAX), .CQ_MAX(CQ_MAX), .AW(AW),
                 .HAS_XTS(ENABLE_XTS), .HAS_VIRTIO(HAS_VIRTIO), .BE_TYPE(BE_TYPE), .NKEY(NKEY), .TRACE_DEPTH(TRACE_DEPTH)) u_mgmt (
    .clk, .rst_n, .m_valid(mmio_valid), .m_we(mmio_we), .m_addr(mmio_addr), .m_wdata(mmio_wdata), .m_rdata(m_rdata_w), .m_err(m_err_w),
    .glb_enable, .soft_rst, .trace_en, .clr_counters, .rd_prio, .wr_batch, .cmd_timeout, .wr_batch_max, .wr_age_max, .pf_force,
    .t_allowed, .t_maxinfl, .t_weight, .t_rate, .t_burst,
    .ns_valid, .ns_owner, .ns_ro, .ns_enc, .ns_pi, .ns_key, .ns_base, .ns_size,
    .be_ready_i(be_ready), .be_capacity_i(be_capacity), .be_caps_i(be_caps), .be_reset_pulse(mg_be_reset),
    .pt_wr, .pt_idx, .pt_valid, .pt_dom, .pt_base, .pt_size, .pt_perm, .pt_rej_i(pt_rej),
    .key_valid, .key1, .key2, .key256, .key_zero, .key_commit,
    .pf_active_i(pf_active), .fatal_i(!dma_init_done), .busy_slots_i(busy_slots), .be_busy_i(be_busy), .perf_i(perf_flat),
    .tr_valid_i(tr_valid), .tr_rec_i(tr_rec)
  );
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin mmio_rsp_valid <= 1'b0; mmio_rsp_rdata <= '0; mmio_rsp_err <= 1'b0; end
    else begin mmio_rsp_valid <= mmio_valid; mmio_rsp_rdata <= m_rdata_w; mmio_rsp_err <= m_err_w && mmio_valid; end
  end
  logic [31:0] key_ok_mask;
  logic [NS_N-1:0] ns_keyok;
  always_comb begin
    for (int n = 0; n < NS_N; n++) ns_keyok[n] = (int'(ns_key[n*4 +: 4]) < NKEY) && key_valid[ns_key[n*4 +: 2]];
    key_ok_mask = '0;
  end

  // ------------------------------------------------------------------ power-fail
  logic [2:0] pf_sync;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) pf_sync <= '0; else pf_sync <= {pf_sync[1:0], pf_warn_i};
  end
  assign pf_active = pf_sync[2] || pf_force;

  // ------------------------------------------------------------------ queues
  cmd_t        q_head   [NT];
  cmd_t        x_head;
  logic        x_hvalid, x_icpl_valid, x_icpl_ready;
  cpl_t        x_icpl;
  logic [NT-1:0] q_hvalid, q_enabled, q_abort, q_idle, q_fatal, q_irq;
  logic [NQ-1:0] sq_pop, sq_valid;
  logic [NQ*CMD_W-1:0] q_head_flat;
  logic [NT-1:0] q_pop;
  logic [NT-1:0] cpl_v, cpl_r;
  cpl_t        cpl_q [NT];
  logic [NT-1:0] ev_post, ev_viol, ev_reject, ev_fetch, ev_cqstall, ev_dmaf;
  cpl_t        ev_cpl [NT];
  logic [31:0] ev_tpost [NT];
  logic [7:0]  infl_cnt [NT];
  logic [NT-1:0] tq_valid;
  logic [31:0] tq_rdata [NT];
  logic [NT-1:0] tq_err;
  logic [1:0]  q_dvalid [NT], q_dgnt [NT], q_ddir [NT], q_drsp [NT], q_dok [NT];
  logic [2*AW-1:0] q_dhost [NT];
  logic [2*16-1:0] q_dlm [NT];
  logic [2*24-1:0] q_dlen [NT];
  logic [2*8-1:0]  q_derr [NT];
  logic [2*4-1:0]  q_dfault [NT];
  logic [NT-1:0] qlm_req, qlm_we, qlm_gnt, qlm_rv;
  logic [WORDS_LOG2-1:0] qlm_addr [NT];
  logic [63:0] qlm_wdata [NT];
  logic [63:0] lm_rdata_b;

  wire [31:0] caps0 = {8'(SFS_BLK_SHIFT), 8'(CQ_MAX), 8'(SQ_MAX), 8'(MDTS)};
  wire [31:0] caps1_hi = {16'h0, 4'(BE_TYPE), 3'b0, be_ready, 2'b0, be_volatile, 1'b1, 1'b1, ENABLE_XTS, be_pi_native, be_discard_ok};

  // tenant MMIO demux
  always_comb begin
    for (int t = 0; t < NT; t++) tq_valid[t] = tmmio_valid && (int'(tmmio_fn) == t);
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin tmmio_rsp_valid <= 1'b0; tmmio_rsp_rdata <= '0; tmmio_rsp_err <= 1'b0; end
    else begin
      tmmio_rsp_valid <= tmmio_valid;
      tmmio_rsp_rdata <= 32'h0; tmmio_rsp_err <= tmmio_valid && (int'(tmmio_fn) >= NT);
      for (int t = 0; t < NT; t++) if (int'(tmmio_fn) == t) begin tmmio_rsp_rdata <= tq_rdata[t]; tmmio_rsp_err <= tq_err[t] && tmmio_valid; end
    end
  end

  // slot table (from slots)
  logic [NSLOT-1:0]    s_busy, s_wr, s_flush, s_to, s_bewait, s_bepend, s_xin, s_xout;
  logic [NSLOT*4-1:0]  s_tenant;
  logic [NSLOT*64-1:0] s_abs;
  logic [NSLOT*16-1:0] s_nblk;
  logic        iss_valid;
  logic [3:0]  iss_slot, iss_tenant, iss_key;
  wire  [3:0]  iss_ten_real = (iss_tenant == 4'(NT)) ? 4'(EXT_TENANT) : iss_tenant;
  cmd_t        iss_cmd;
  logic [63:0] iss_abs;
  logic        iss_pi, iss_enc;
  logic [NQ-1:0] sch_throttle;
  logic [7:0]  sch_waiting;

  always_comb begin
    for (int t = 0; t < NT; t++) begin
      infl_cnt[t] = 8'd0;
      for (int s = 0; s < NSLOT; s++) if (s_busy[s] && s_tenant[s*4 +: 4] == 4'(t)) infl_cnt[t] = infl_cnt[t] + 8'd1;
      q_head_flat[t*CMD_W +: CMD_W] = q_head[t];
    end
    q_head_flat[NT*CMD_W +: CMD_W] = x_head;
    sq_valid = {x_hvalid, q_hvalid};
    q_pop    = sq_pop[NT-1:0];
  end

  genvar gt;
  generate
    for (gt = 0; gt < NT; gt++) begin : g_q
      sf_stor_queue #(.TID(gt), .NS_N(NS_N), .MDTS(MDTS), .SQ_MAX(SQ_MAX), .CQ_MAX(CQ_MAX), .SQ_BATCH(SQ_BATCH), .PQ(PQ), .AW(AW),
                      .WORDS_LOG2(WORDS_LOG2), .LM_SQ_WORD((SQ_BYTE0 + gt * SQ_BATCH * 64) / 8), .LM_CQ_WORD((CQ_BYTE0 + gt * 32) / 8),
                      .LM_SQ_BYTE(SQ_BYTE0 + gt * SQ_BATCH * 64), .LM_CQ_BYTE(CQ_BYTE0 + gt * 32)) u_q (
        .clk, .rst_n, .now_i(now),
        .t_valid(tq_valid[gt]), .t_we(tmmio_we), .t_addr(tmmio_addr), .t_wdata(tmmio_wdata), .t_rdata(tq_rdata[gt]), .t_err(tq_err[gt]),
        .cfg_allowed(t_allowed[gt]), .glb_enable, .rst_req_i(soft_rst), .pf_active_i(pf_active),
        .caps0_i(caps0), .caps1_hi_i(caps1_hi), .be_discard_i(be_discard_ok),
        .ns_valid_i(ns_valid), .ns_owner_i(ns_owner), .ns_ro_i(ns_ro), .ns_enc_i(ns_enc), .ns_keyok_i(ns_keyok), .ns_size_i(ns_size),
        .inflight_i(infl_cnt[gt]), .throttle_i(sch_throttle[gt]),
        .head_o(q_head[gt]), .head_valid_o(q_hvalid[gt]), .head_pop_i(q_pop[gt]), .enabled_o(q_enabled[gt]), .abort_o(q_abort[gt]),
        .cpl_valid_i(cpl_v[gt]), .cpl_ready_o(cpl_r[gt]), .cpl_i(cpl_q[gt]),
        .d_valid(q_dvalid[gt]), .d_gnt(q_dgnt[gt]), .d_dir(q_ddir[gt]), .d_host(q_dhost[gt]), .d_lm(q_dlm[gt]), .d_len(q_dlen[gt]),
        .d_rsp(q_drsp[gt]), .d_ok(q_dok[gt]), .d_err(q_derr[gt]), .d_fault(q_dfault[gt]),
        .lm_req(qlm_req[gt]), .lm_we(qlm_we[gt]), .lm_addr(qlm_addr[gt]), .lm_wdata(qlm_wdata[gt]), .lm_gnt(qlm_gnt[gt]),
        .lm_rvalid(qlm_rv[gt]), .lm_rdata(lm_rdata_b),
        .irq_o(q_irq[gt]), .ev_post(ev_post[gt]), .ev_cpl(ev_cpl[gt]), .ev_t_post(ev_tpost[gt]), .ev_viol(ev_viol[gt]),
        .ev_reject(ev_reject[gt]), .ev_fetch(ev_fetch[gt]), .ev_cq_stall(ev_cqstall[gt]), .ev_dma_fault(ev_dmaf[gt]), .idle_o(q_idle[gt]),
        .fatal_o(q_fatal[gt])
      );
    end
  endgenerate
  assign irq = q_irq;

  // ------------------------------------------------------------------ scheduler
  logic [NQ*8-1:0]  sq_maxinfl, sq_weight;
  logic [NQ*16-1:0] sq_rate, sq_burst;
  always_comb begin
    sq_maxinfl = {t_maxinfl[EXT_TENANT*8 +: 8], t_maxinfl}; sq_weight = {t_weight[EXT_TENANT*8 +: 8], t_weight};
    sq_rate = {t_rate[EXT_TENANT*16 +: 16], t_rate}; sq_burst = {t_burst[EXT_TENANT*16 +: 16], t_burst};
  end
  sf_stor_sched #(.NT(NQ), .NSLOT(NSLOT), .NS_N(NS_N), .MDTS(MDTS)) u_sched (
    .clk, .rst_n, .glb_enable, .pf_active, .rd_prio, .wr_batch, .wr_batch_max, .wr_age_max,
    .q_valid(sq_valid), .q_head(q_head_flat), .q_pop(sq_pop),
    .t_maxinfl(sq_maxinfl), .t_weight(sq_weight), .t_rate(sq_rate), .t_burst(sq_burst),
    .ns_base, .ns_pi, .ns_enc, .ns_key,
    .s_busy, .s_tenant, .s_abs, .s_nblk, .s_wr, .s_flush,
    .iss_valid, .iss_slot, .iss_tenant, .iss_cmd, .iss_abs, .iss_pi, .iss_enc, .iss_key,
    .throttle(sch_throttle), .waiting(sch_waiting)
  );

  // ------------------------------------------------------------------ slots
  logic [NSLOT-1:0]   sd_valid, sd_gnt, sd_dir, sd_rsp, sd_ok;
  logic [NSLOT*DOM_W-1:0] sd_dom;
  logic [NSLOT*AW-1:0]    sd_host;
  logic [NSLOT*16-1:0]    sd_lm;
  logic [NSLOT*24-1:0]    sd_len;
  logic [NSLOT*8-1:0]     sd_err;
  logic [NSLOT*4-1:0]     sd_fault;
  logic [NSLOT-1:0]   sx_valid, sx_gnt, sx_done;
  xjob_t              sx_job [NSLOT];
  xres_t              x_res_w;
  logic [NSLOT-1:0]   sm_valid, sm_gnt, sm_bc;
  logic [2:0]         sm_op [NSLOT];
  logic [63:0]        sm_abs [NSLOT];
  logic [15:0]        sm_nblk [NSLOT];
  logic [NSLOT-1:0]   scpl_valid, scpl_ready;
  cpl_t               scpl [NSLOT];
  logic [NSLOT*16-1:0] uunm_flat, uerr_flat;
  logic               be_rst_evt;

  genvar gs;
  generate
    for (gs = 0; gs < NSLOT; gs++) begin : g_slot
      logic [3:0]  ten_w;
      sf_stor_slot #(.AW(AW), .DATA_BYTE(DATA_BYTE0 + gs * SLOT_BYTES)) u_slot (
        .clk, .rst_n, .now_i(now),
        .iss_valid(iss_valid && (int'(iss_slot) == gs)), .iss_cmd, .iss_tenant(iss_ten_real), .iss_src(iss_tenant), .iss_ext(iss_tenant == 4'(NT)), .iss_abs, .iss_pi, .iss_enc, .iss_key,
        .busy_o(s_busy[gs]), .src_o(ten_w), .abs_o(s_abs[gs*64 +: 64]), .nblk_o(s_nblk[gs*16 +: 16]), .wr_o(s_wr[gs]), .flush_o(s_flush[gs]),
        .abort_i((int'(ten_w) < NT) && q_abort[ten_w[1:0]]), .pf_active_i(pf_active), .be_rst_evt_i(be_rst_evt), .be_ready_i(be_ready), .cmd_timeout_i(cmd_timeout),
        .be_durable_flush_i(be_volatile), .be_pi_native_i(be_pi_native), .to_evt_o(s_to[gs]), .ext_in_req_o(s_xin[gs]), .ext_in_done_i(ext_in_done && s_xin[gs]),
        .ext_out_req_o(s_xout[gs]), .ext_out_done_i(ext_out_done && s_xout[gs]), .be_wait_o(s_bewait[gs]), .be_pend_o(s_bepend[gs]),
        .d_valid(sd_valid[gs]), .d_gnt(sd_gnt[gs]), .d_dir(sd_dir[gs]), .d_dom(sd_dom[gs*DOM_W +: DOM_W]), .d_host(sd_host[gs*AW +: AW]),
        .d_lm(sd_lm[gs*16 +: 16]), .d_len(sd_len[gs*24 +: 24]), .d_rsp(sd_rsp[gs]), .d_ok(sd_ok[gs]), .d_err(sd_err[gs*8 +: 8]),
        .d_fault(sd_fault[gs*4 +: 4]),
        .x_valid(sx_valid[gs]), .x_gnt(sx_gnt[gs]), .x_job(sx_job[gs]), .x_done(sx_done[gs]), .x_res(x_res_w),
        .m_valid(sm_valid[gs]), .m_gnt(sm_gnt[gs]), .m_op(sm_op[gs]), .m_abs(sm_abs[gs]), .m_nblk(sm_nblk[gs]),
        .bc_valid(sm_bc[gs]), .bc_status(be_cpl_status), .bc_durable(be_cpl_durable), .bc_nblk(be_cpl_nblk),
        .uunm_i(uunm_flat[gs*16 +: 16]),
        .cpl_valid(scpl_valid[gs]), .cpl_ready(scpl_ready[gs]), .cpl_o(scpl[gs])
      );
      assign s_tenant[gs*4 +: 4] = ten_w;
    end
  endgenerate

  // completion routing: per tenant, pick one completing slot (round robin)
  logic [3:0] cpl_rr [NT];
  always_comb begin
    for (int t = 0; t < NT; t++) begin
      cpl_v[t] = 1'b0; cpl_q[t] = '0;
      for (int k = 0; k < NSLOT; k++) begin
        automatic int s = (int'(cpl_rr[t]) + k) % NSLOT;
        if (!cpl_v[t] && scpl_valid[s] && s_tenant[s*4 +: 4] == 4'(t)) begin cpl_v[t] = 1'b1; cpl_q[t] = scpl[s]; end
      end
    end
    scpl_ready = '0;
    for (int t = 0; t < NT; t++) if (cpl_r[t]) begin
      automatic logic done_one = 1'b0;
      for (int k = 0; k < NSLOT; k++) begin
        automatic int s = (int'(cpl_rr[t]) + k) % NSLOT;
        if (!done_one && scpl_valid[s] && s_tenant[s*4 +: 4] == 4'(t)) begin scpl_ready[s] = 1'b1; done_one = 1'b1; end
      end
    end
    scpl_ready = scpl_ready | xs_rdy_vec;
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) for (int t = 0; t < NT; t++) cpl_rr[t] <= '0;
    else for (int t = 0; t < NT; t++) if (cpl_r[t]) cpl_rr[t] <= cpl_rr[t] + 4'd1;
  end

  // ---- ext completion (slots with src == NT) and ext immediate completions
  logic [3:0]  xcpl_rr;
  logic        xs_v; cpl_t xs_c; logic [NSLOT-1:0] xs_rdy_vec;
  always_comb begin
    xs_v = 1'b0; xs_c = '0;
    for (int k = 0; k < NSLOT; k++) begin
      automatic int s = (int'(xcpl_rr) + k) % NSLOT;
      if (!xs_v && scpl_valid[s] && int'(s_tenant[s*4 +: 4]) == NT) begin xs_v = 1'b1; xs_c = scpl[s]; end
    end
  end
  wire        x_take_imm  = x_icpl_valid && (!xs_v || xcpl_rr[0]);
  assign ext_cpl_valid    = x_take_imm ? 1'b1 : xs_v;
  wire cpl_t  x_sel_cpl   = x_take_imm ? x_icpl : xs_c;
  assign ext_cpl_status = x_sel_cpl.status; assign ext_cpl_detail = x_sel_cpl.detail; assign ext_cpl_durable = x_sel_cpl.durable;
  assign ext_cpl_nblk   = x_sel_cpl.nblk_done;
  assign x_icpl_ready   = x_take_imm && ext_cpl_ready;
  always_comb begin
    for (int s = 0; s < NSLOT; s++) xs_rdy_vec[s] = 1'b0;
    if (!x_take_imm && xs_v && ext_cpl_ready) begin
      automatic logic done_one = 1'b0;
      for (int k = 0; k < NSLOT; k++) begin
        automatic int s = (int'(xcpl_rr) + k) % NSLOT;
        if (!done_one && scpl_valid[s] && int'(s_tenant[s*4 +: 4]) == NT) begin xs_rdy_vec[s] = 1'b1; done_one = 1'b1; end
      end
    end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) xcpl_rr <= '0; else if (ext_cpl_valid && ext_cpl_ready) xcpl_rr <= xcpl_rr + 4'd1;
  end
  // ext staging-memory hand-over: the slot that is waiting for / holding data
  always_comb begin
    ext_in_req = |s_xin; ext_out_req = |s_xout; ext_data_base = '0;
    for (int s = NSLOT - 1; s >= 0; s--) if (s_xin[s] || s_xout[s]) ext_data_base = 13'(DATA0_WORD + SLOT_WORDS * s);
  end
  sf_stor_extq #(.NS_N(NS_N), .MDTS(MDTS), .EXT_TENANT(EXT_TENANT)) u_extq (
    .clk, .rst_n, .now_i(now), .enable_i(HAS_VIRTIO && glb_enable && !pf_active),
    .ext_cmd_valid, .ext_cmd_ready, .ext_op, .ext_nsid, .ext_lba, .ext_nblk, .ext_txn,
    .be_discard_i(be_discard_ok), .ns_valid_i(ns_valid), .ns_owner_i(ns_owner), .ns_ro_i(ns_ro), .ns_enc_i(ns_enc), .ns_keyok_i(ns_keyok),
    .ns_size_i(ns_size), .head_o(x_head), .head_valid_o(x_hvalid), .head_pop_i(sq_pop[NT]), .icpl_valid(x_icpl_valid), .icpl_ready(x_icpl_ready),
    .icpl(x_icpl)
  );

  // ------------------------------------------------------------------ DMA sequencer
  logic [NREQ-1:0]       rq_valid, rq_gnt, rq_dir, rq_rsp, rq_ok;
  logic [NREQ*DOM_W-1:0] rq_dom;
  logic [NREQ*AW-1:0]    rq_host;
  logic [NREQ*16-1:0]    rq_lm;
  logic [NREQ*24-1:0]    rq_len;
  logic [NREQ*8-1:0]     rq_err;
  logic [NREQ*4-1:0]     rq_fault;
  always_comb begin
    for (int t = 0; t < NT; t++) begin
      for (int k = 0; k < 2; k++) begin
        rq_valid[2*t+k] = q_dvalid[t][k]; rq_dir[2*t+k] = q_ddir[t][k];
        rq_dom[(2*t+k)*DOM_W +: DOM_W] = DOM_W'(t);
        rq_host[(2*t+k)*AW +: AW] = q_dhost[t][k*AW +: AW];
        rq_lm[(2*t+k)*16 +: 16]   = q_dlm[t][k*16 +: 16];
        rq_len[(2*t+k)*24 +: 24]  = q_dlen[t][k*24 +: 24];
        q_dgnt[t][k] = rq_gnt[2*t+k]; q_drsp[t][k] = rq_rsp[2*t+k]; q_dok[t][k] = rq_ok[2*t+k];
        q_derr[t][k*8 +: 8] = rq_err[(2*t+k)*8 +: 8]; q_dfault[t][k*4 +: 4] = rq_fault[(2*t+k)*4 +: 4];
      end
    end
    for (int s = 0; s < NSLOT; s++) begin
      rq_valid[2*NT+s] = sd_valid[s]; rq_dir[2*NT+s] = sd_dir[s];
      rq_dom[(2*NT+s)*DOM_W +: DOM_W] = sd_dom[s*DOM_W +: DOM_W];
      rq_host[(2*NT+s)*AW +: AW] = sd_host[s*AW +: AW];
      rq_lm[(2*NT+s)*16 +: 16]   = sd_lm[s*16 +: 16];
      rq_len[(2*NT+s)*24 +: 24]  = sd_len[s*24 +: 24];
      sd_gnt[s] = rq_gnt[2*NT+s]; sd_rsp[s] = rq_rsp[2*NT+s]; sd_ok[s] = rq_ok[2*NT+s];
      sd_err[s*8 +: 8] = rq_err[(2*NT+s)*8 +: 8]; sd_fault[s*4 +: 4] = rq_fault[(2*NT+s)*4 +: 4];
    end
  end

  logic [IDW-1:0] dm_ar_id, dm_aw_id, dm_r_id, dm_b_id;
  logic           dm_ar_valid, dm_ar_ready, dm_r_valid, dm_r_ready, dm_aw_valid, dm_aw_ready, dm_w_valid, dm_w_ready, dm_b_valid, dm_b_ready;
  logic [AW-1:0]  dm_ar_addr, dm_aw_addr;
  logic [7:0]     dm_ar_len, dm_aw_len;
  logic [2:0]     dm_ar_size, dm_aw_size;
  logic [1:0]     dm_ar_burst, dm_aw_burst, dm_r_resp, dm_b_resp;
  logic [3:0]     dm_ar_asid, dm_aw_asid;
  logic [DOM_W-1:0] dm_ar_dom, dm_aw_dom;
  logic [63:0]    dm_r_data, dm_w_data;
  logic [7:0]     dm_w_strb;
  logic           dm_r_last, dm_w_last;
  logic           dma_lm_req, dma_lm_gnt;
  logic [WORDS_LOG2-1:0] dma_lm_addr;
  logic [63:0]    dma_lm_wdata;
  logic [NUM_CH-1:0] dma_ch_busy;
  logic           dma_viol, dma_in_act, dma_out_act;
  logic [31:0]    dma_bytes_pulse;

  sf_stor_dmaseq #(.NT(NT), .NSLOT(NSLOT), .NUM_CH(NUM_CH), .AW(AW), .DOM_W(DOM_W), .DW(64), .WORDS_LOG2(WORDS_LOG2), .LMEM_BYTES(LMEM_BYTES)) u_dma (
    .clk, .rst_n, .cfg_timeout(cmd_timeout),
    .req_valid(rq_valid), .req_gnt(rq_gnt), .req_dir(rq_dir), .req_dom(rq_dom), .req_host(rq_host), .req_lm(rq_lm), .req_len(rq_len),
    .rsp_valid(rq_rsp), .rsp_ok(rq_ok), .rsp_err(rq_err), .rsp_fault(rq_fault),
    .lm_req(dma_lm_req), .lm_addr(dma_lm_addr), .lm_wdata(dma_lm_wdata), .lm_gnt(dma_lm_gnt),
    .pt_wr, .pt_idx, .pt_valid, .pt_dom, .pt_base, .pt_size, .pt_perm, .pt_rej, .init_done(dma_init_done),
    .m_ar_valid(dm_ar_valid), .m_ar_ready(dm_ar_ready), .m_ar_id(dm_ar_id), .m_ar_addr(dm_ar_addr), .m_ar_len(dm_ar_len),
    .m_ar_size(dm_ar_size), .m_ar_burst(dm_ar_burst), .m_ar_asid(dm_ar_asid), .m_ar_domain(dm_ar_dom),
    .m_r_valid(dm_r_valid), .m_r_ready(dm_r_ready), .m_r_id(dm_r_id), .m_r_data(dm_r_data), .m_r_resp(dm_r_resp), .m_r_last(dm_r_last),
    .m_aw_valid(dm_aw_valid), .m_aw_ready(dm_aw_ready), .m_aw_id(dm_aw_id), .m_aw_addr(dm_aw_addr), .m_aw_len(dm_aw_len),
    .m_aw_size(dm_aw_size), .m_aw_burst(dm_aw_burst), .m_aw_asid(dm_aw_asid), .m_aw_domain(dm_aw_dom),
    .m_w_valid(dm_w_valid), .m_w_ready(dm_w_ready), .m_w_data(dm_w_data), .m_w_strb(dm_w_strb), .m_w_last(dm_w_last),
    .m_b_valid(dm_b_valid), .m_b_ready(dm_b_ready), .m_b_id(dm_b_id), .m_b_resp(dm_b_resp),
    .ch_busy(dma_ch_busy), .viol_evt(dma_viol), .stat_in_active(dma_in_act), .stat_out_active(dma_out_act), .stat_bytes_pulse(dma_bytes_pulse)
  );

  // AXI router + local-memory AXI slave
  logic s1_ar_valid, s1_ar_ready, s1_r_valid, s1_r_ready, s1_r_last, s1_aw_valid, s1_aw_ready, s1_w_valid, s1_w_ready, s1_w_last, s1_b_valid, s1_b_ready;
  logic [IDW-1:0] s1_ar_id, s1_r_id, s1_aw_id, s1_b_id;
  logic [AW-1:0]  s1_ar_addr, s1_aw_addr;
  logic [7:0]     s1_ar_len, s1_aw_len, s1_w_strb;
  logic [2:0]     s1_ar_size, s1_aw_size;
  logic [1:0]     s1_ar_burst, s1_aw_burst, s1_r_resp, s1_b_resp;
  logic [63:0]    s1_r_data, s1_w_data;
  logic [IDW-1:0] s0_ar_id, s0_aw_id, s0_r_id, s0_b_id;
  assign m_ar_id = 4'(s0_ar_id); assign m_aw_id = 4'(s0_aw_id);
  assign s0_r_id = IDW'(m_r_id); assign s0_b_id = IDW'(m_b_id);
  sf_stor_axi_xbar #(.AW(AW), .DW(64), .ID_W(IDW), .DOM_W(DOM_W)) u_xbar (
    .clk, .rst_n,
    .m_ar_valid(dm_ar_valid), .m_ar_ready(dm_ar_ready), .m_ar_id(dm_ar_id), .m_ar_addr(dm_ar_addr), .m_ar_len(dm_ar_len),
    .m_ar_size(dm_ar_size), .m_ar_burst(dm_ar_burst), .m_ar_asid(dm_ar_asid), .m_ar_domain(dm_ar_dom),
    .m_r_valid(dm_r_valid), .m_r_ready(dm_r_ready), .m_r_id(dm_r_id), .m_r_data(dm_r_data), .m_r_resp(dm_r_resp), .m_r_last(dm_r_last),
    .m_aw_valid(dm_aw_valid), .m_aw_ready(dm_aw_ready), .m_aw_id(dm_aw_id), .m_aw_addr(dm_aw_addr), .m_aw_len(dm_aw_len),
    .m_aw_size(dm_aw_size), .m_aw_burst(dm_aw_burst), .m_aw_asid(dm_aw_asid), .m_aw_domain(dm_aw_dom),
    .m_w_valid(dm_w_valid), .m_w_ready(dm_w_ready), .m_w_data(dm_w_data), .m_w_strb(dm_w_strb), .m_w_last(dm_w_last),
    .m_b_valid(dm_b_valid), .m_b_ready(dm_b_ready), .m_b_id(dm_b_id), .m_b_resp(dm_b_resp),
    .s0_ar_valid(m_ar_valid), .s0_ar_ready(m_ar_ready), .s0_ar_id(s0_ar_id), .s0_ar_addr(m_ar_addr), .s0_ar_len(m_ar_len),
    .s0_ar_size(m_ar_size), .s0_ar_burst(m_ar_burst), .s0_ar_asid(m_ar_asid), .s0_ar_domain(m_ar_domain),
    .s0_r_valid(m_r_valid), .s0_r_ready(m_r_ready), .s0_r_id(s0_r_id), .s0_r_data(m_r_data), .s0_r_resp(m_r_resp), .s0_r_last(m_r_last),
    .s0_aw_valid(m_aw_valid), .s0_aw_ready(m_aw_ready), .s0_aw_id(s0_aw_id), .s0_aw_addr(m_aw_addr), .s0_aw_len(m_aw_len),
    .s0_aw_size(m_aw_size), .s0_aw_burst(m_aw_burst), .s0_aw_asid(m_aw_asid), .s0_aw_domain(m_aw_domain),
    .s0_w_valid(m_w_valid), .s0_w_ready(m_w_ready), .s0_w_data(m_w_data), .s0_w_strb(m_w_strb), .s0_w_last(m_w_last),
    .s0_b_valid(m_b_valid), .s0_b_ready(m_b_ready), .s0_b_id(s0_b_id), .s0_b_resp(m_b_resp),
    .s1_ar_valid, .s1_ar_ready, .s1_ar_id, .s1_ar_addr, .s1_ar_len, .s1_ar_size, .s1_ar_burst,
    .s1_r_valid, .s1_r_ready, .s1_r_id, .s1_r_data, .s1_r_resp, .s1_r_last,
    .s1_aw_valid, .s1_aw_ready, .s1_aw_id, .s1_aw_addr, .s1_aw_len, .s1_aw_size, .s1_aw_burst,
    .s1_w_valid, .s1_w_ready, .s1_w_data, .s1_w_strb, .s1_w_last,
    .s1_b_valid, .s1_b_ready, .s1_b_id, .s1_b_resp
  );
  logic a_en, a_we; logic [WORDS_LOG2-1:0] a_addr; logic [63:0] a_wdata, a_rdata; logic [7:0] a_be;
  sf_stor_axi_lmem #(.AW(AW), .ID_W(IDW), .WORDS_LOG2(WORDS_LOG2)) u_axil (
    .clk, .rst_n,
    .s_ar_valid(s1_ar_valid), .s_ar_ready(s1_ar_ready), .s_ar_id(s1_ar_id), .s_ar_addr(s1_ar_addr), .s_ar_len(s1_ar_len),
    .s_ar_size(s1_ar_size), .s_ar_burst(s1_ar_burst),
    .s_r_valid(s1_r_valid), .s_r_ready(s1_r_ready), .s_r_id(s1_r_id), .s_r_data(s1_r_data), .s_r_resp(s1_r_resp), .s_r_last(s1_r_last),
    .s_aw_valid(s1_aw_valid), .s_aw_ready(s1_aw_ready), .s_aw_id(s1_aw_id), .s_aw_addr(s1_aw_addr), .s_aw_len(s1_aw_len),
    .s_aw_size(s1_aw_size), .s_aw_burst(s1_aw_burst),
    .s_w_valid(s1_w_valid), .s_w_ready(s1_w_ready), .s_w_data(s1_w_data), .s_w_strb(s1_w_strb), .s_w_last(s1_w_last),
    .s_b_valid(s1_b_valid), .s_b_ready(s1_b_ready), .s_b_id(s1_b_id), .s_b_resp(s1_b_resp),
    .a_en, .a_we, .a_addr, .a_wdata, .a_be, .a_rdata
  );

  // ------------------------------------------------------------------ transform, mover
  logic        x_job_valid, x_job_gnt, x_done_w;
  logic [3:0]  x_job_slot, x_done_slot;
  xjob_t       x_job_w;
  logic [3:0]  x_rr;
  logic        xlm_req, xlm_we, xlm_gnt, xlm_rv, xbusy;
  logic [WORDS_LOG2-1:0] xlm_addr;
  logic [63:0] xlm_wdata;
  always_comb begin
    x_job_valid = 1'b0; x_job_slot = '0; x_job_w = '0;
    for (int k = 0; k < NSLOT; k++) begin
      automatic int s = (int'(x_rr) + k) % NSLOT;
      if (!x_job_valid && sx_valid[s]) begin x_job_valid = 1'b1; x_job_slot = 4'(s); x_job_w = sx_job[s]; end
    end
    for (int s = 0; s < NSLOT; s++) begin
      sx_gnt[s]  = x_job_gnt && (int'(x_job_slot) == s);
      sx_done[s] = x_done_w && (int'(x_done_slot) == s);
    end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) x_rr <= '0; else if (x_job_gnt) x_rr <= 4'((int'(x_job_slot) + 1) % NSLOT);
  end
  sf_stor_xform #(.MDTS(MDTS), .WORDS_LOG2(WORDS_LOG2), .DATA0_WORD(DATA0_WORD), .SLOT_WORDS(SLOT_WORDS), .ENABLE_XTS(ENABLE_XTS), .NKEY(NKEY)) u_xform (
    .clk, .rst_n, .be_pi_native_i(be_pi_native),
    .job_valid(x_job_valid), .job_slot(x_job_slot), .job(x_job_w), .job_gnt(x_job_gnt), .done(x_done_w), .done_slot(x_done_slot), .res(x_res_w),
    .key_valid_i(key_valid), .key1_i(key1), .key2_i(key2), .key256_i(key256), .key_zero_i(key_zero), .key_commit_i(key_commit),
    .lm_req(xlm_req), .lm_we(xlm_we), .lm_addr(xlm_addr), .lm_wdata(xlm_wdata), .lm_gnt(xlm_gnt), .lm_rvalid(xlm_rv), .lm_rdata(lm_rdata_b),
    .busy_o(xbusy)
  );

  logic        mv_valid, mv_start, mv_done;
  logic [3:0]  mv_slot, mv_done_slot, mv_rr;
  logic [2:0]  mv_op;
  logic [63:0] mv_abs;
  logic [15:0] mv_nblk;
  logic        mlm_req, mlm_we, mlm_gnt, mlm_rv, mv_stall, be_rst_active;
  logic [WORDS_LOG2-1:0] mlm_addr;
  logic [63:0] mlm_wdata;
  always_comb begin
    mv_valid = 1'b0; mv_slot = '0; mv_op = '0; mv_abs = '0; mv_nblk = '0;
    for (int k = 0; k < NSLOT; k++) begin
      automatic int s = (int'(mv_rr) + k) % NSLOT;
      if (!mv_valid && sm_valid[s]) begin mv_valid = 1'b1; mv_slot = 4'(s); mv_op = sm_op[s]; mv_abs = sm_abs[s]; mv_nblk = sm_nblk[s]; end
    end
    for (int s = 0; s < NSLOT; s++) sm_gnt[s] = mv_done && (int'(mv_done_slot) == s);
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) mv_rr <= '0; else if (mv_start) mv_rr <= 4'((int'(mv_slot) + 1) % NSLOT);
  end
  logic be_wd_valid_i, be_req_valid_i, be_rd_ready_i;
  sf_stor_mover #(.NSLOT(NSLOT), .MDTS(MDTS), .WORDS_LOG2(WORDS_LOG2), .DATA0_WORD(DATA0_WORD), .SLOT_WORDS(SLOT_WORDS)) u_mover (
    .clk, .rst_n, .be_pi_native_i(be_pi_native), .be_rst_i(be_rst_active),
    .job_valid(mv_valid && !be_rst_active), .job_slot(mv_slot), .job_op(mv_op), .job_abs(mv_abs), .job_nblk(mv_nblk),
    .job_start(mv_start), .job_done(mv_done), .job_done_slot(mv_done_slot),
    .be_req_valid(be_req_valid_i), .be_req_ready(be_req_ready && !be_rst_active), .be_req_op, .be_req_lba, .be_req_nblk, .be_req_tag,
    .be_wd_valid(be_wd_valid_i), .be_wd_ready(be_wd_ready && !be_rst_active), .be_wd_data, .be_wd_ulast, .be_wd_tag,
    .be_rd_valid(be_rd_valid && !be_rst_active), .be_rd_ready(be_rd_ready_i), .be_rd_tag, .be_rd_data, .be_rd_ulast, .be_rd_uflags,
    .lm_req(mlm_req), .lm_we(mlm_we), .lm_addr(mlm_addr), .lm_wdata(mlm_wdata), .lm_gnt(mlm_gnt), .lm_rvalid(mlm_rv), .lm_rdata(lm_rdata_b),
    .uunm_o(uunm_flat), .uerr_o(uerr_flat), .stall_o(mv_stall)
  );
  assign be_req_valid = be_req_valid_i && !be_rst_active;
  assign be_wd_valid  = be_wd_valid_i && !be_rst_active;
  assign be_rd_ready  = be_rd_ready_i;

  // ------------------------------------------------------------------ backend completion routing and reset sequencing
  always_comb begin
    for (int s = 0; s < NSLOT; s++) sm_bc[s] = be_cpl_valid && !be_rst_active && (int'(be_cpl_tag) == s);
  end
  assign be_cpl_ready = 1'b1;

  typedef enum logic [2:0] {R_IDLE, R_ASSERT, R_WAIT, R_EVT} rst_t;
  rst_t       rst_st;
  logic [3:0] rst_cnt;
  logic       be_ready_q;
  logic       to_any;
  always_comb begin
    to_any = 1'b0;
    for (int s = 0; s < NSLOT; s++) if (s_to[s]) to_any = 1'b1;
  end
  assign be_rst_active = (rst_st == R_ASSERT) || (rst_st == R_WAIT);
  assign be_reset      = (rst_st == R_ASSERT);
  assign be_rst_evt    = (rst_st == R_ASSERT) && (rst_cnt == 4'd0);   // delivered when the reset has been asserted (not when the backend returns)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin rst_st <= R_IDLE; rst_cnt <= '0; be_ready_q <= 1'b1; end
    else begin
      be_ready_q <= be_ready;
      case (rst_st)
        R_IDLE: if (mg_be_reset || to_any || soft_rst || (be_ready_q && !be_ready) ) begin rst_st <= R_ASSERT; rst_cnt <= 4'd4; end
        R_ASSERT: begin if (rst_cnt == 4'd0) rst_st <= R_WAIT; else rst_cnt <= rst_cnt - 4'd1; end
        R_WAIT: if (be_ready) rst_st <= R_EVT;
        R_EVT:  rst_st <= R_IDLE;
        default: rst_st <= R_IDLE;
      endcase
    end
  end

  // ------------------------------------------------------------------ local memory + port-B arbitration
  logic [NCLI-1:0]            c_req, c_we, c_gnt, c_rv;
  logic [NCLI*WORDS_LOG2-1:0] c_addr;
  logic [NCLI*64-1:0]         c_wdata;
  logic [NCLI*8-1:0]          c_be;
  logic b_en, b_we; logic [WORDS_LOG2-1:0] b_addr; logic [63:0] b_wdata, b_rdata; logic [7:0] b_be;
  always_comb begin
    c_req = '0; c_we = '0; c_addr = '0; c_wdata = '0; c_be = '1;
    c_req[0] = dma_lm_req; c_we[0] = 1'b1; c_addr[0 +: WORDS_LOG2] = dma_lm_addr; c_wdata[0 +: 64] = dma_lm_wdata;
    for (int t = 0; t < NT; t++) begin
      c_req[1+t] = qlm_req[t]; c_we[1+t] = qlm_we[t]; c_addr[(1+t)*WORDS_LOG2 +: WORDS_LOG2] = qlm_addr[t]; c_wdata[(1+t)*64 +: 64] = qlm_wdata[t];
      qlm_gnt[t] = c_gnt[1+t]; qlm_rv[t] = c_rv[1+t];
    end
    c_req[NT+1] = xlm_req; c_we[NT+1] = xlm_we; c_addr[(NT+1)*WORDS_LOG2 +: WORDS_LOG2] = xlm_addr; c_wdata[(NT+1)*64 +: 64] = xlm_wdata;
    xlm_gnt = c_gnt[NT+1]; xlm_rv = c_rv[NT+1];
    c_req[NT+2] = mlm_req; c_we[NT+2] = mlm_we; c_addr[(NT+2)*WORDS_LOG2 +: WORDS_LOG2] = mlm_addr; c_wdata[(NT+2)*64 +: 64] = mlm_wdata;
    mlm_gnt = c_gnt[NT+2]; mlm_rv = c_rv[NT+2];
    c_req[NT+3] = ext_lm_req; c_we[NT+3] = ext_lm_we; c_addr[(NT+3)*WORDS_LOG2 +: WORDS_LOG2] = ext_lm_addr[WORDS_LOG2-1:0]; c_wdata[(NT+3)*64 +: 64] = ext_lm_wdata;
    ext_lm_gnt = c_gnt[NT+3]; ext_lm_rvalid = c_rv[NT+3]; ext_lm_rdata = lm_rdata_b;
    dma_lm_gnt = c_gnt[0];
  end
  sf_stor_lm_arb #(.NCLI(NCLI), .WORDS_LOG2(WORDS_LOG2)) u_lmarb (
    .clk, .rst_n, .c_req, .c_we, .c_addr, .c_wdata, .c_be, .c_gnt, .c_rvalid(c_rv), .c_rdata(lm_rdata_b),
    .b_en, .b_we, .b_addr, .b_wdata, .b_be, .b_rdata
  );
  sf_stor_lmem #(.WORDS_LOG2(WORDS_LOG2)) u_lmem (
    .clk, .a_en, .a_we, .a_addr, .a_wdata, .a_be, .a_rdata, .b_en, .b_we, .b_addr, .b_wdata, .b_be, .b_rdata
  );

  // ------------------------------------------------------------------ status, power-fail quiesce
  always_comb begin
    busy_slots = 8'd0; be_busy = 8'd0;
    for (int s = 0; s < NSLOT; s++) begin
      if (s_busy[s]) busy_slots = busy_slots + 8'd1;
      if (s_bewait[s]) be_busy = be_busy + 8'd1;
    end
  end
  assign pf_quiesced_o = pf_active && (|s_bewait == 1'b0) && !(|s_bepend) && (be_wd_valid_i == 1'b0);

  // ------------------------------------------------------------------ performance counters
  logic [63:0] pc [PC_N];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n || clr_counters) begin
      if (!rst_n) begin for (int i = 0; i < PC_N; i++) pc[i] <= '0; end
      else begin for (int i = 1; i < PC_N; i++) pc[i] <= '0; end
      if (!rst_n) pc[0] <= '0;
    end
    if (rst_n && !clr_counters) begin
      pc[PC_CYCLES] <= pc[PC_CYCLES] + 64'd1;
      for (int t = 0; t < NT; t++) begin
        if (ev_post[t]) begin
          pc[PC_CMDS_DONE] <= pc[PC_CMDS_DONE] + 64'd1;
          if (ev_cpl[t].status != ST_SUCCESS) pc[PC_CMDS_ERR] <= pc[PC_CMDS_ERR] + 64'd1;
          case (ev_cpl[t].op)
            OP_READ:    begin pc[PC_RD_CMDS] <= pc[PC_RD_CMDS] + 64'd1; pc[PC_RD_BLOCKS] <= pc[PC_RD_BLOCKS] + 64'(ev_cpl[t].nblk_done); end
            OP_WRITE:   begin pc[PC_WR_CMDS] <= pc[PC_WR_CMDS] + 64'd1; pc[PC_WR_BLOCKS] <= pc[PC_WR_BLOCKS] + 64'(ev_cpl[t].nblk_done); end
            OP_FLUSH:   pc[PC_FLUSH_CMDS] <= pc[PC_FLUSH_CMDS] + 64'd1;
            OP_DISCARD: pc[PC_DISCARD_CMDS] <= pc[PC_DISCARD_CMDS] + 64'd1;
            default: ;
          endcase
          pc[PC_BYTES] <= pc[PC_BYTES] + 64'(ev_cpl[t].bytes);
          if (ev_cpl[t].status == ST_INTEGRITY)     pc[PC_INTEG_ERR] <= pc[PC_INTEG_ERR] + 64'd1;
          if (ev_cpl[t].status == ST_MEDIA_ERROR)   pc[PC_MEDIA_ERR] <= pc[PC_MEDIA_ERR] + 64'd1;
          if (ev_cpl[t].status == ST_TIMEOUT)       pc[PC_TIMEOUTS] <= pc[PC_TIMEOUTS] + 64'd1;
          if (ev_cpl[t].status == ST_DMA_FAULT)     pc[PC_DMA_FAULTS] <= pc[PC_DMA_FAULTS] + 64'd1;
          if (ev_cpl[t].status == ST_ABORTED_RESET || ev_cpl[t].status == ST_ABORTED_POWER) pc[PC_ABORTS] <= pc[PC_ABORTS] + 64'd1;
          if (ev_cpl[t].status == ST_DATA_CRC)      pc[PC_CRC_ERR] <= pc[PC_CRC_ERR] + 64'd1;
          pc[PC_CQ_POSTED] <= pc[PC_CQ_POSTED] + 64'd1;
        end
        if (ev_viol[t])   pc[PC_VIOL]    <= pc[PC_VIOL] + 64'd1;
        if (ev_reject[t]) pc[PC_REJECTS] <= pc[PC_REJECTS] + 64'd1;
        if (ev_fetch[t])  pc[PC_FETCHED] <= pc[PC_FETCHED] + 64'd1;
        if (ev_cqstall[t]) pc[PC_CQ_STALL_CYC] <= pc[PC_CQ_STALL_CYC] + 64'd1;
        if (sch_throttle[t]) pc[PC_THROTTLE_CYC] <= pc[PC_THROTTLE_CYC] + 64'd1;
      end
      if (dma_in_act)   pc[PC_DMA_IN_CYC]  <= pc[PC_DMA_IN_CYC] + 64'd1;
      if (dma_out_act)  pc[PC_DMA_OUT_CYC] <= pc[PC_DMA_OUT_CYC] + 64'd1;
      pc[PC_DMA_BYTES]     <= pc[PC_DMA_BYTES] + 64'(dma_bytes_pulse);
      if (be_busy != 8'd0) pc[PC_BE_BUSY_CYC] <= pc[PC_BE_BUSY_CYC] + 64'd1;
      if (mv_stall)        pc[PC_BE_STALL_CYC] <= pc[PC_BE_STALL_CYC] + 64'd1;
      pc[PC_QWAIT_CYC]     <= pc[PC_QWAIT_CYC] + 64'(sch_waiting);
      pc[PC_SLOT_BUSY_CYC] <= pc[PC_SLOT_BUSY_CYC] + 64'(busy_slots);
      if (xbusy)           pc[PC_XFORM_CYC] <= pc[PC_XFORM_CYC] + 64'd1;
      if (pf_active && !pf_active_q) pc[PC_PF_EVENTS] <= pc[PC_PF_EVENTS] + 64'd1;
      if (rst_st == R_ASSERT && rst_cnt == 4'd4) pc[PC_BE_RESETS] <= pc[PC_BE_RESETS] + 64'd1;
    end
  end
  logic pf_active_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) pf_active_q <= 1'b0; else pf_active_q <= pf_active;
  end
  always_comb for (int i = 0; i < PC_N; i++) perf_flat[i*64 +: 64] = pc[i];

  // ------------------------------------------------------------------ completion trace (one record per posted completion)
  logic [NT-1:0] th_v;
  logic [255:0]  th_rec [NT];
  logic [3:0]    th_rr;
  function automatic logic [255:0] mk_rec(input cpl_t c, input logic [3:0] ten, input logic [31:0] tpost);
    logic [255:0] r;
    r = '0;
    r[31:0]    = {c.op, 4'h0, ten, c.txn};
    r[63:32]   = {c.nblk_done, c.detail, c.status};
    r[95:64]   = c.t_fetch;
    r[127:96]  = c.t_admit;
    r[159:128] = c.t_issue;
    r[191:160] = c.t_bedone;
    r[223:192] = tpost;
    r[255:224] = {c.durable, 15'h0, c.bytes[15:0]};
    return r;
  endfunction
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin th_v <= '0; th_rr <= '0; tr_valid <= 1'b0; tr_rec <= '0; for (int t = 0; t < NT; t++) th_rec[t] <= '0; end
    else begin
      tr_valid <= 1'b0;
      for (int t = 0; t < NT; t++) if (ev_post[t]) begin th_v[t] <= 1'b1; th_rec[t] <= mk_rec(ev_cpl[t], 4'(t), ev_tpost[t]); end
      begin
        automatic logic got = 1'b0;
        for (int k = 0; k < NT; k++) begin
          automatic int t = (int'(th_rr) + k) % NT;
          if (!got && th_v[t] && !ev_post[t]) begin
            got = 1'b1; tr_valid <= 1'b1; tr_rec <= th_rec[t]; th_v[t] <= 1'b0; th_rr <= 4'((t + 1) % NT);
          end
        end
      end
    end
  end
  wire unused_ok = &{1'b0, q_enabled, q_idle, q_fatal, ev_dmaf, dma_ch_busy, dma_viol, uerr_flat, key_ok_mask, tq_valid, tmmio_we, be_discard_ok, SLOT_WORDS[0]};
endmodule
`default_nettype wire
