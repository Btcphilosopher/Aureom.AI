// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_lm_arb -- round-robin arbiter for local-memory port B
//   Clients hold `req` (and its payload) until `gnt`.  A granted read returns its data on `rdata` one cycle later with
//   `rvalid[client]` asserted for that client only.  One access per cycle.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_lm_arb #(
  parameter int NCLI       = 5,
  parameter int WORDS_LOG2 = 13
) (
  input  wire logic                         clk,
  input  wire logic                         rst_n,
  input  wire logic [NCLI-1:0]              c_req,
  input  wire logic [NCLI-1:0]              c_we,
  input  wire logic [NCLI*WORDS_LOG2-1:0]   c_addr,
  input  wire logic [NCLI*64-1:0]           c_wdata,
  input  wire logic [NCLI*8-1:0]            c_be,
  output logic [NCLI-1:0]                   c_gnt,
  output logic [NCLI-1:0]                   c_rvalid,
  output logic [63:0]                       c_rdata,
  // memory port B
  output logic                              b_en,
  output logic                              b_we,
  output logic [WORDS_LOG2-1:0]             b_addr,
  output logic [63:0]                       b_wdata,
  output logic [7:0]                        b_be,
  input  wire logic [63:0]                  b_rdata
);
  localparam int CW = (NCLI > 1) ? $clog2(NCLI) : 1;
  logic [CW-1:0] ptr;
  logic          have;
  logic [CW-1:0] sel;
  always_comb begin
    have = 1'b0; sel = '0;
    for (int k = 0; k < NCLI; k++) begin
      automatic int i = (int'(ptr) + k) % NCLI;
      if (!have && c_req[i]) begin have = 1'b1; sel = CW'(i); end
    end
    c_gnt = '0;
    if (have) c_gnt[sel] = 1'b1;
  end
  assign b_en    = have;
  assign b_we    = have && c_we[sel];
  assign b_addr  = c_addr[int'(sel)*WORDS_LOG2 +: WORDS_LOG2];
  assign b_wdata = c_wdata[int'(sel)*64 +: 64];
  assign b_be    = c_be[int'(sel)*8 +: 8];
  logic [NCLI-1:0] rv_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin ptr <= '0; rv_q <= '0; end
    else begin
      rv_q <= '0;
      if (have) begin
        ptr <= CW'((int'(sel) + 1) % NCLI);
        if (!c_we[sel]) rv_q[sel] <= 1'b1;
      end
    end
  end
  assign c_rvalid = rv_q;
  assign c_rdata  = b_rdata;
endmodule
`default_nettype wire
