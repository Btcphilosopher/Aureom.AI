// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_be_simdev -- SIMULATED BLOCK DEVICE (backend type 0)   [SIMULATION MODEL]
//
//   A behavioural block device implementing the full backend contract (docs/02 §7).  It is the baseline backend and the
//   reference for every other adapter.  Not synthesizable by intent (array copies, initial block).
//
//   * 528-byte units (PI_NATIVE = 1) or 512-byte units; block = 66 (or 64) 64-bit words.
//   * Medium: persistent array + per-block "unmapped" bit (never written / discarded -> reads return zeros, flagged).
//   * VOLATILE_CACHE = 1: a bounded write-back cache (CACHE_N entries, oldest-first eviction).  A WRITE / DISCARD completes
//     with durable = 0 while its data lives in the cache; FLUSH writes everything back and completes durable = 1.
//     VOLATILE_CACHE = 0: write-through, every write completes durable = 1.
//   * Power loss (power_loss_i pulse, or rst_n): the cache is lost, except that each dirty block independently survives
//     with probability 1/2 (LFSR) when power_loss_i is used -- i.e. any subset of the unflushed history may persist.
//   * Latency model: base + per-block cycles + LFSR jitter; requests are processed one at a time, queued (depth QD).
//   * Fault injection (testbench sideband): device failure, hang, media error on a block, bit corruption of a stored unit,
//     misdirected read, power loss.
//   Units are committed atomically (one 528-byte unit is all-old or all-new).
// =============================================================================
`default_nettype none
module sf_stor_be_simdev
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int CAP_BLOCKS     = 4096,
  parameter bit PI_NATIVE      = 1'b1,
  parameter bit VOLATILE_CACHE = 1'b1,
  parameter bit HAS_DISCARD    = 1'b1,
  parameter bit READONLY       = 1'b0,
  parameter int CACHE_N        = 16,
  parameter int QD             = 4,
  parameter logic [31:0] SEED  = 32'hACE1_2468
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            be_reset_i,
  // contract: capabilities
  output logic                 be_ready,
  output logic [63:0]          be_capacity,
  output logic [7:0]           be_caps,
  // requests
  input  wire logic            be_req_valid,
  output logic                 be_req_ready,
  input  wire logic [2:0]      be_req_op,
  input  wire logic [63:0]     be_req_lba,
  input  wire logic [15:0]     be_req_nblk,
  input  wire logic [3:0]      be_req_tag,
  // write data
  input  wire logic            be_wd_valid,
  output logic                 be_wd_ready,
  input  wire logic [63:0]     be_wd_data,
  input  wire logic            be_wd_ulast,
  input  wire logic [3:0]      be_wd_tag,
  // read data
  output logic                 be_rd_valid,
  input  wire logic            be_rd_ready,
  output logic [3:0]           be_rd_tag,
  output logic [63:0]          be_rd_data,
  output logic                 be_rd_ulast,
  output logic [1:0]           be_rd_uflags,
  // completion
  output logic                 be_cpl_valid,
  input  wire logic            be_cpl_ready,
  output logic [3:0]           be_cpl_tag,
  output logic [3:0]           be_cpl_status,
  output logic                 be_cpl_durable,
  output logic [15:0]          be_cpl_nblk,
  // testbench sideband
  input  wire logic [15:0]     cfg_rd_lat,
  input  wire logic [15:0]     cfg_wr_lat,
  input  wire logic [15:0]     cfg_fl_lat,
  input  wire logic [7:0]      cfg_blk_lat,
  input  wire logic [7:0]      cfg_jitter_mask,
  input  wire logic            inj_fail,
  input  wire logic            inj_hang,
  input  wire logic            inj_media_en,
  input  wire logic [63:0]     inj_media_lba,
  input  wire logic            inj_corrupt,          // pulse
  input  wire logic [63:0]     inj_corrupt_lba,
  input  wire logic [9:0]      inj_corrupt_bit,      // bit within the stored unit
  input  wire logic            inj_misdirect_en,
  input  wire logic [63:0]     inj_misdirect_lba,    // reads of this LBA return the data of LBA ^ 1
  input  wire logic            power_loss_i,         // pulse
  input  wire logic [63:0]     dbg_lba,              // backdoor: stored unit of this block (cache first, else medium)
  input  wire logic [6:0]      dbg_word,
  output logic [63:0]          dbg_data,
  output logic                 dbg_unmapped,
  output logic [31:0]          stat_dirty
);
  localparam int UW = PI_NATIVE ? 66 : 64;

  assign be_capacity = 64'(CAP_BLOCKS);
  assign be_caps     = {3'b0, READONLY, HAS_DISCARD, HAS_DISCARD, VOLATILE_CACHE, PI_NATIVE};

  // ------------------------------------------------------------------ storage
  logic [63:0] mmem [0:CAP_BLOCKS*UW-1];
  logic        mum  [0:CAP_BLOCKS-1];
  logic        c_v  [CACHE_N];
  logic        c_unm[CACHE_N];
  logic [63:0] c_lba[CACHE_N];
  logic [31:0] c_seq[CACHE_N];
  logic [63:0] c_dat[CACHE_N][UW];
  logic [31:0] seqno;
  initial begin
    for (int i = 0; i < CAP_BLOCKS; i++) mum[i] = 1'b1;
    for (int i = 0; i < CAP_BLOCKS*UW; i++) mmem[i] = 64'h0;
    for (int i = 0; i < CACHE_N; i++) begin c_v[i] = 1'b0; c_unm[i] = 1'b0; c_lba[i] = '0; c_seq[i] = '0; end
  end

  // ------------------------------------------------------------------ request queue
  logic [2:0]  q_op  [QD];
  logic [63:0] q_lba [QD];
  logic [15:0] q_nb  [QD];
  logic [3:0]  q_tag [QD];
  logic [$clog2(QD):0] q_cnt;
  logic [$clog2(QD)-1:0] q_rp, q_wp;
  assign be_req_ready = (int'(q_cnt) < QD) && ready_q;

  typedef enum logic [3:0] {D_IDLE, D_WDATA, D_WLAT, D_RLAT, D_RSTREAM, D_FLUSH, D_DISC, D_CPL} dst_t;
  dst_t        st;
  logic        ready_q;
  logic [5:0]  rec_cnt;
  logic [2:0]  op;
  logic [63:0] lba;
  logic [15:0] nb, blk;
  logic [3:0]  tag;
  logic [3:0]  rstatus;
  logic        rdur;
  logic        drain;                  // WRITE refused: consume the data units and discard them
  logic [15:0] lat;
  logic [6:0]  widx;
  logic [63:0] ubuf [UW];
  logic [63:0] rbuf [UW];
  logic        r_unm, r_err;
  logic [15:0] nblk_done;
  logic [31:0] lfsr;
  assign be_ready = ready_q;

  function automatic logic [31:0] lfsr_next(input logic [31:0] x);
    return {x[30:0], x[31] ^ x[21] ^ x[1] ^ x[0]};
  endfunction

  // find cache entry for an lba
  function automatic int cfind(input logic [63:0] l);
    int r;
    r = -1;
    for (int i = 0; i < CACHE_N; i++) if (c_v[i] && c_lba[i] == l) r = i;
    return r;
  endfunction
  // write a cache entry back to the medium
  task automatic wb_entry(input int i);
    int b;
    b = int'(c_lba[i]);
    if (c_unm[i]) begin
      mum[b] = 1'b1;
      for (int w = 0; w < UW; w++) mmem[b*UW + w] = 64'h0;
    end else begin
      mum[b] = 1'b0;
      for (int w = 0; w < UW; w++) mmem[b*UW + w] = c_dat[i][w];
    end
    c_v[i] = 1'b0;
  endtask
  // store one unit (data in ubuf, or "unmapped" marker) to the cache / medium
  task automatic store_unit(input logic [63:0] l, input bit unm);
    int e, old, fr, b;
    b = int'(l);
    if (!VOLATILE_CACHE) begin
      mum[b] = unm;
      for (int w = 0; w < UW; w++) mmem[b*UW + w] = unm ? 64'h0 : ubuf[w];
    end else begin
      e = cfind(l);
      if (e < 0) begin
        fr = -1; old = 0;
        for (int i = CACHE_N - 1; i >= 0; i--) if (!c_v[i]) fr = i;
        if (fr < 0) begin                       // evict the oldest entry
          for (int i = 1; i < CACHE_N; i++) if (c_seq[i] < c_seq[old]) old = i;
          wb_entry(old); fr = old;
        end
        e = fr;
      end
      c_v[e] = 1'b1; c_lba[e] = l; c_unm[e] = unm; c_seq[e] = seqno;
      for (int w = 0; w < UW; w++) c_dat[e][w] = unm ? 64'h0 : ubuf[w];
    end
  endtask
  // load one unit for reading into rbuf; returns "unmapped"
  task automatic load_unit(input logic [63:0] l, output bit unm);
    int e, b;
    b = int'(l); e = VOLATILE_CACHE ? cfind(l) : -1;
    if (e >= 0) begin
      unm = c_unm[e];
      for (int w = 0; w < UW; w++) rbuf[w] = unm ? 64'h0 : c_dat[e][w];
    end else begin
      unm = mum[b];
      for (int w = 0; w < UW; w++) rbuf[w] = unm ? 64'h0 : mmem[b*UW + w];
    end
  endtask

  // ------------------------------------------------------------------ main process
  wire in_range = ({1'b0, lba} + {49'h0, nb}) <= 65'(CAP_BLOCKS);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= D_IDLE; ready_q <= 1'b1; rec_cnt <= '0; q_cnt <= '0; q_rp <= '0; q_wp <= '0; op <= '0; lba <= '0; nb <= '0; blk <= '0; tag <= '0;
      rstatus <= BST_OK; rdur <= 1'b0; drain <= 1'b0; lat <= '0; widx <= '0; r_unm <= 1'b0; r_err <= 1'b0; nblk_done <= '0;
      lfsr <= SEED; seqno <= '0;
      be_wd_ready <= 1'b0; be_rd_valid <= 1'b0; be_rd_tag <= '0; be_rd_data <= '0; be_rd_ulast <= 1'b0; be_rd_uflags <= '0;
      be_cpl_valid <= 1'b0; be_cpl_tag <= '0; be_cpl_status <= '0; be_cpl_durable <= 1'b0; be_cpl_nblk <= '0;
      // a hard reset of the power domain loses the cache (the medium array persists)
      for (int i = 0; i < CACHE_N; i++) c_v[i] = 1'b0;
    end else begin
      lfsr <= lfsr_next(lfsr);
      // ---- enqueue
      if (be_req_valid && be_req_ready) begin
        q_op[q_wp] <= be_req_op; q_lba[q_wp] <= be_req_lba; q_nb[q_wp] <= be_req_nblk; q_tag[q_wp] <= be_req_tag;
        q_wp <= q_wp + 1'b1;
      end
      q_cnt <= q_cnt + ($bits(q_cnt))'(be_req_valid && be_req_ready);

      // ---- fault injection that mutates the stored state
      if (inj_corrupt) begin
        automatic int b = int'(inj_corrupt_lba);
        automatic int e = cfind(inj_corrupt_lba);
        automatic int wi = int'(inj_corrupt_bit) / 64;
        automatic int bi = int'(inj_corrupt_bit) % 64;
        if (wi < UW) begin
          if (e >= 0) c_dat[e][wi][bi] = ~c_dat[e][wi][bi];
          else        mmem[b*UW + wi][bi] = ~mmem[b*UW + wi][bi];
        end
      end

      // ---- power loss / backend reset
      if (power_loss_i || be_reset_i) begin
        if (power_loss_i) begin
          for (int i = 0; i < CACHE_N; i++) if (c_v[i]) begin
            if (lfsr[i % 32]) wb_entry(i); else c_v[i] = 1'b0;
          end
          ready_q <= 1'b0; rec_cnt <= 6'd40;
        end
        st <= D_IDLE; q_cnt <= '0; q_rp <= '0; q_wp <= '0; be_wd_ready <= 1'b0; be_rd_valid <= 1'b0; be_cpl_valid <= 1'b0;
      end else begin
        if (!ready_q) begin
          if (rec_cnt != 0) rec_cnt <= rec_cnt - 1'b1; else ready_q <= 1'b1;
        end
        // ---- engine
        case (st)
          D_IDLE: if (int'(q_cnt) != 0 && ready_q && !inj_hang) begin
            op <= q_op[q_rp]; lba <= q_lba[q_rp]; nb <= q_nb[q_rp]; tag <= q_tag[q_rp]; q_rp <= q_rp + 1'b1;
            q_cnt <= q_cnt + ($bits(q_cnt))'(be_req_valid && be_req_ready) - 1'b1;
            blk <= '0; widx <= '0; rstatus <= BST_OK; rdur <= 1'b0; drain <= 1'b0; nblk_done <= '0; r_err <= 1'b0;
            case (q_op[q_rp])
              BOP_WRITE:   begin st <= D_WDATA; be_wd_ready <= 1'b1; end
              BOP_READ:    begin st <= D_RLAT; lat <= cfg_rd_lat + {8'h0, cfg_blk_lat} * q_nb[q_rp] + {8'h0, lfsr[7:0] & cfg_jitter_mask}; end
              BOP_FLUSH:   begin st <= D_FLUSH; end
              BOP_DISCARD: begin st <= D_DISC; end
              default:     begin st <= D_CPL; rstatus <= BST_UNSUPPORTED; end
            endcase
          end
          // ---------------- WRITE: collect units
          D_WDATA: begin
            if (be_wd_valid && be_wd_ready) begin
              ubuf[widx] <= be_wd_data;
              if (be_wd_ulast) begin
                widx <= '0;
                // commit the unit (ubuf is complete one cycle after the last word): handled in D_WLAT-commit below
                st <= D_WLAT; be_wd_ready <= 1'b0; lat <= 16'd1;
              end else widx <= widx + 7'd1;
            end
          end
          D_WLAT: begin
            // first cycle after the last word of a unit: commit; then either take the next unit or pay the write latency
            if (lat == 16'd1) begin
              if (!drain) begin
                if (!in_range) begin drain <= 1'b1; rstatus <= BST_RANGE; end
                else if (READONLY) begin drain <= 1'b1; rstatus <= BST_RO; end
                else if (inj_fail) begin drain <= 1'b1; rstatus <= BST_DEV_ERR; end
                else begin
                  store_unit(lba + 64'(blk), 1'b0); seqno <= seqno + 32'd1; nblk_done <= nblk_done + 16'd1;
                end
              end
              blk <= blk + 16'd1;
              if (blk + 16'd1 == nb) begin
                lat <= cfg_wr_lat + {8'h0, cfg_blk_lat} * nb + {8'h0, lfsr[7:0] & cfg_jitter_mask}; st <= D_CPL;
                rdur <= !VOLATILE_CACHE;
              end else begin st <= D_WDATA; be_wd_ready <= 1'b1; end
            end
          end
          // ---------------- READ
          D_RLAT: begin
            if (inj_hang) begin end
            else if (lat != 0) lat <= lat - 1'b1;
            else if (!in_range) begin rstatus <= BST_RANGE; st <= D_CPL; end
            else if (inj_fail)  begin rstatus <= BST_DEV_ERR; st <= D_CPL; end
            else begin st <= D_RSTREAM; widx <= '0; blk <= '0; end
          end
          D_RSTREAM: begin
            // prepare the unit on its first word
            if (widx == 0 && !be_rd_valid) begin
              automatic bit u;
              automatic logic [63:0] src = (inj_misdirect_en && (lba + 64'(blk)) == inj_misdirect_lba) ? ((lba + 64'(blk)) ^ 64'd1) : (lba + 64'(blk));
              load_unit(src, u);
              r_unm <= u;
              r_err <= inj_media_en && ((lba + 64'(blk)) == inj_media_lba);
              be_rd_valid <= 1'b1; be_rd_tag <= tag; be_rd_data <= (inj_media_en && ((lba + 64'(blk)) == inj_media_lba)) ? 64'h0 : rbuf[0];
              be_rd_ulast <= 1'b0; be_rd_uflags <= '0;
              widx <= 7'd1;
              // rbuf is loaded combinationally via the task above (blocking assignments), usable next cycle
            end else if (be_rd_valid && be_rd_ready) begin
              if (widx == UW[6:0]) begin
                // last beat accepted
                be_rd_valid <= 1'b0; be_rd_ulast <= 1'b0; widx <= '0;
                if (r_err) begin rstatus <= BST_MEDIA_ERR; end
                else if (rstatus == BST_OK) nblk_done <= nblk_done + 16'd1;
                blk <= blk + 16'd1;
                if (blk + 16'd1 == nb) begin st <= D_CPL; lat <= '0; end
              end else begin
                be_rd_data <= r_err ? 64'h0 : rbuf[widx];
                be_rd_ulast <= (widx == UW[6:0] - 7'd1);
                be_rd_uflags <= (widx == UW[6:0] - 7'd1) ? {r_unm, r_err} : 2'b00;
                widx <= widx + 7'd1;
              end
            end
          end
          // ---------------- FLUSH
          D_FLUSH: begin
            if (!inj_hang) begin
              if (inj_fail) begin rstatus <= BST_DEV_ERR; st <= D_CPL; end
              else begin
                for (int i = 0; i < CACHE_N; i++) if (c_v[i]) wb_entry(i);
                rdur <= 1'b1; lat <= cfg_fl_lat + {8'h0, lfsr[7:0] & cfg_jitter_mask}; st <= D_CPL;
              end
            end
          end
          // ---------------- DISCARD
          D_DISC: begin
            if (!HAS_DISCARD) begin rstatus <= BST_UNSUPPORTED; st <= D_CPL; end
            else if (!in_range) begin rstatus <= BST_RANGE; st <= D_CPL; end
            else if (READONLY) begin rstatus <= BST_RO; st <= D_CPL; end
            else if (inj_fail) begin rstatus <= BST_DEV_ERR; st <= D_CPL; end
            else begin
              for (int k = 0; k < int'(nb); k++) store_unit(lba + 64'(k), 1'b1);
              seqno <= seqno + 32'd1; nblk_done <= nb; rdur <= !VOLATILE_CACHE;
              lat <= cfg_wr_lat + {8'h0, lfsr[7:0] & cfg_jitter_mask}; st <= D_CPL;
            end
          end
          // ---------------- completion
          D_CPL: begin
            if (!be_cpl_valid) begin
              if (inj_hang) begin end
              else if (lat != 0) lat <= lat - 1'b1;
              else begin
                be_cpl_valid <= 1'b1; be_cpl_tag <= tag; be_cpl_status <= rstatus; be_cpl_durable <= (rstatus == BST_OK) && rdur;
                be_cpl_nblk <= nblk_done;
              end
            end else if (be_cpl_ready) begin be_cpl_valid <= 1'b0; st <= D_IDLE; end
          end
          default: st <= D_IDLE;
        endcase
      end
    end
  end
  // backdoor read (simulation only): the stored unit, exactly as the fabric wrote it (cipher text with encryption)
  always_comb begin
    automatic int e = cfind(dbg_lba);
    automatic int b = int'(dbg_lba);
    dbg_data = 64'h0; dbg_unmapped = 1'b1;
    if (e >= 0) begin dbg_unmapped = c_unm[e]; if (int'(dbg_word) < UW) dbg_data = c_dat[e][dbg_word]; end
    else if (b >= 0 && b < CAP_BLOCKS) begin dbg_unmapped = mum[b]; if (int'(dbg_word) < UW) dbg_data = mmem[b*UW + int'(dbg_word)]; end
  end
  // dirty-count statistic (entries that are volatile)
  always_comb begin
    stat_dirty = 32'd0;
    for (int i = 0; i < CACHE_N; i++) if (c_v[i]) stat_dirty = stat_dirty + 32'd1;
  end
endmodule
`default_nettype wire
