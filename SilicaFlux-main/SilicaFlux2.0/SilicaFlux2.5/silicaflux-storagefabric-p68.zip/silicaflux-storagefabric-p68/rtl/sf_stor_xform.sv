// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_xform -- data integrity and optional encryption of staged blocks
//
//   WRITE job (per 512-byte block, in the staging memory):
//        read data  -> CRC-32C guard (per block) and payload CRC (whole job)
//        write the 16-byte protection trailer (guard, NS tag, LBA tag, version) [PI-native backend only]
//        [XTS-AES-256 encrypt the 528- (or 512-) byte unit in place]
//        after the last block: compare the payload CRC with HCRC when requested (mismatch -> DATA_CRC, nothing written)
//   READ job (per block): skip never-written blocks;  [XTS decrypt in place];  CRC guard over the data;
//        verify trailer (guard, NS tag, LBA tag, version) when the namespace has PI;  payload CRC over the data.
//   A failing block stops the job (nblk_ok = number of leading good blocks); the caller never moves data to the host.
//   CRC-32C is an accidental-corruption check; XTS provides confidentiality only (docs/02 §6).
//   One job at a time; ~2 cycles per word without encryption.
// Classification: SYNTHESIZABLE (AES core is third-party, vendored; see third_party/p59-securestore)
// =============================================================================
`default_nettype none
module sf_stor_xform
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int MDTS       = 8,
  parameter int WORDS_LOG2 = 13,
  parameter int DATA0_WORD = 512,      // word address of slot 0 staging data area
  parameter int SLOT_WORDS = 528,      // words per slot (data + meta areas)
  parameter bit ENABLE_XTS = 1'b0,
  parameter int NKEY       = 4
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  input  wire logic                    be_pi_native_i,
  // job
  input  wire logic                    job_valid,
  input  wire logic [3:0]              job_slot,
  input  wire xjob_t                   job,
  output logic                         job_gnt,
  output logic                         done,
  output logic [3:0]                   done_slot,
  output xres_t                        res,
  // key store (management plane writes it)
  input  wire logic [NKEY-1:0]         key_valid_i,
  input  wire logic [NKEY*256-1:0]     key1_i,
  input  wire logic [NKEY*256-1:0]     key2_i,
  input  wire logic [NKEY-1:0]         key256_i,
  input  wire logic                    key_zero_i,        // zeroise pulse
  input  wire logic                    key_commit_i,      // a key slot was (re)written: drop the cached key schedule
  // local memory client
  output logic                         lm_req,
  output logic                         lm_we,
  output logic [WORDS_LOG2-1:0]        lm_addr,
  output logic [63:0]                  lm_wdata,
  input  wire logic                    lm_gnt,
  input  wire logic                    lm_rvalid,
  input  wire logic [63:0]             lm_rdata,
  output logic                         busy_o
);
  localparam int MET_OFF = MDTS * 64;    // word offset of the meta area inside a slot

  // ------------------------------------------------------------------ CRC engines
  logic        g_clr, g_en, p_clr, p_en;
  logic [63:0] crc_din;
  logic [31:0] g_crc, p_crc;
  sf_stor_crc32c u_crc_g (.clk, .rst_n, .clr(g_clr), .en(g_en), .data_i(crc_din), .nbytes_i(4'd8), .crc_o(g_crc));
  sf_stor_crc32c u_crc_p (.clk, .rst_n, .clr(p_clr), .en(p_en), .data_i(crc_din), .nbytes_i(4'd8), .crc_o(p_crc));

  // ------------------------------------------------------------------ job registers
  typedef enum logic [3:0] {X_IDLE, X_KEYLD, X_KEYG, X_KEYW, X_RDP, X_WMETA, X_XTS, X_CMP, X_NEXT, X_DONE} xst_t;
  xst_t        st;
  xjob_t       j;
  logic [3:0]  slot_q;
  logic [15:0] blk;
  logic [7:0]  iss, rcv;               // read stream: words issued / received
  logic [63:0] meta0, meta1;
  logic        wm_idx;
  logic        ok;
  logic [7:0]  r_status, r_detail;
  logic [15:0] nblk_ok;
  logic        pi_all;
  logic        xts_after_rd;           // WRITE: encrypt after trailer;  READ: decrypt before read pass (handled by entry state)
  logic        xts_done_flag;
  logic [2:0]  kw_cnt;

  wire [WORDS_LOG2-1:0] slot_base = WORDS_LOG2'(DATA0_WORD + SLOT_WORDS * int'(slot_q));
  wire [WORDS_LOG2-1:0] data_w    = slot_base + WORDS_LOG2'(int'(blk) * 64);
  wire [WORDS_LOG2-1:0] meta_w    = slot_base + WORDS_LOG2'(MET_OFF + int'(blk) * 2);
  wire [47:0]           lba_b     = j.lba_rel + 48'(blk);
  wire [63:0]           dun       = j.lba_abs + 64'(blk);
  wire                  unit_has_meta = be_pi_native_i;

  assign busy_o  = (st != X_IDLE);
  assign job_gnt = (st == X_IDLE) && job_valid;

  // ------------------------------------------------------------------ XTS engine (optional)
  logic         xe_key_load, xe_key_idle, xe_key_ok, xe_key_eq, xe_du_start, xe_du_ready, xe_len_err;
  logic [255:0] xe_k1, xe_k2;
  logic         xe_k256;
  logic         xe_s_valid, xe_s_ready, xe_m_valid, xe_m_ready, xe_m_last, xe_busy;
  logic [127:0] xe_s_data, xe_m_data;
  logic [127:0] xe_tweak;
  logic [20:0]  xe_nblk;
  logic         xe_dec;
  logic [3:0]   loaded_key;
  logic         loaded_valid;
  if (ENABLE_XTS) begin : g_xts
    sfsec_xts_engine u_xts (
      .clk, .rst_n, .zeroize_i(key_zero_i), .key_load_i(xe_key_load), .key1_i(xe_k1), .key2_i(xe_k2), .key256_i(xe_k256),
      .key_idle_o(xe_key_idle), .key_ok_o(xe_key_ok), .key_eq_o(xe_key_eq), .du_start_i(xe_du_start), .du_dec_i(xe_dec),
      .du_tweak_i(xe_tweak), .du_nblk_i(xe_nblk), .du_ready_o(xe_du_ready), .du_len_err_o(xe_len_err), .abort_i(1'b0),
      .s_valid_i(xe_s_valid), .s_ready_o(xe_s_ready), .s_data_i(xe_s_data), .m_valid_o(xe_m_valid), .m_ready_i(xe_m_ready),
      .m_data_o(xe_m_data), .m_last_o(xe_m_last), .busy_o(xe_busy)
    );
  end else begin : g_noxts
    assign xe_key_idle = 1'b1; assign xe_key_ok = 1'b0; assign xe_key_eq = 1'b0; assign xe_du_ready = 1'b0; assign xe_len_err = 1'b0;
    assign xe_s_ready = 1'b0; assign xe_m_valid = 1'b0; assign xe_m_data = '0; assign xe_m_last = 1'b0; assign xe_busy = 1'b0;
  end
  function automatic logic [63:0] bswap64(input logic [63:0] w);
    return {w[7:0], w[15:8], w[23:16], w[31:24], w[39:32], w[47:40], w[55:48], w[63:56]};
  endfunction
  assign xe_tweak = {bswap64(dun), 64'h0};
  assign xe_nblk  = unit_has_meta ? 21'd33 : 21'd32;

  // xts sub-sequencer
  typedef enum logic [3:0] {XS_START, XS_STARTW, XS_RD0, XS_RD0W, XS_RD1, XS_RD1W, XS_PUSH, XS_POP, XS_WR0, XS_WR1, XS_FIN} xs_t;
  xs_t         xs;
  logic [5:0]  xs_k;                   // 16-byte block index within the unit
  logic [63:0] xs_w0, xs_w1;
  logic [127:0] xs_out;
  wire  [5:0]  xs_n = unit_has_meta ? 6'd33 : 6'd32;
  wire  [WORDS_LOG2-1:0] xs_addr0 = (xs_k < 6'd32) ? (data_w + WORDS_LOG2'(int'(xs_k) * 2)) : meta_w;
  wire  [WORDS_LOG2-1:0] xs_addr1 = xs_addr0 + WORDS_LOG2'(1);
  logic        xs_req, xs_we; logic [WORDS_LOG2-1:0] xs_addr; logic [63:0] xs_wdata;
  always_comb begin
    xs_req = 1'b0; xs_we = 1'b0; xs_addr = xs_addr0; xs_wdata = 64'h0;
    case (xs)
      XS_RD0: begin xs_req = 1'b1; xs_addr = xs_addr0; end
      XS_RD1: begin xs_req = 1'b1; xs_addr = xs_addr1; end
      XS_WR0: begin xs_req = 1'b1; xs_we = 1'b1; xs_addr = xs_addr0; xs_wdata = bswap64(xs_out[127:64]); end
      XS_WR1: begin xs_req = 1'b1; xs_we = 1'b1; xs_addr = xs_addr1; xs_wdata = bswap64(xs_out[63:0]); end
      default: ;
    endcase
  end
  assign xe_s_valid = (xs == XS_PUSH);
  assign xe_s_data  = {bswap64(xs_w0), bswap64(xs_w1)};
  assign xe_m_ready = (xs == XS_POP);

  // ------------------------------------------------------------------ local-memory request mux
  logic        rd_req;
  logic        wm_req;
  logic [WORDS_LOG2-1:0] rd_addr;
  wire need_xts_dec_w;
  wire [7:0] rd_total_c = (j.mode && j.pi && !j.unm[blk[3:0]] && unit_has_meta) ? 8'd66 : 8'd64;
  assign rd_req  = (st == X_RDP) && !need_xts_dec_w && (iss < rd_total_c);
  assign rd_addr = (iss < 8'd64) ? (data_w + WORDS_LOG2'(iss)) : (meta_w + WORDS_LOG2'(iss - 8'd64));
  assign wm_req  = (st == X_WMETA);
  assign lm_req   = rd_req || wm_req || ((st == X_XTS) && xs_req);
  assign lm_we    = wm_req || ((st == X_XTS) && xs_we);
  assign lm_addr  = wm_req ? (meta_w + WORDS_LOG2'(wm_idx)) : ((st == X_XTS) ? xs_addr : rd_addr);
  // trailer: real protection information for a PI namespace, all zeros otherwise (PI-native backend stores 528-byte units)
  wire [63:0] wm_w0 = j.pi ? pi_word0(g_crc, j.nsid, j.tenant, lba_b) : 64'h0;
  wire [63:0] wm_w1 = j.pi ? pi_word1(lba_b) : 64'h0;
  assign lm_wdata = wm_req ? (wm_idx ? wm_w1 : wm_w0) : xs_wdata;

  // CRC feed: every received read word below 64 (data) feeds the guard and payload CRCs
  assign crc_din = lm_rdata;
  logic fed_valid;
  assign fed_valid = (st == X_RDP) && lm_rvalid && (rcv < 8'd64);
  assign g_en = fed_valid;
  assign p_en = fed_valid;

  // ------------------------------------------------------------------ expected trailer (READ)
  wire [63:0] exp0 = pi_word0(g_crc, j.nsid, j.tenant, lba_b);
  wire [63:0] exp1 = pi_word1(lba_b);

  logic cmp_guard_bad, cmp_ns_bad, cmp_lba_bad, cmp_fmt_bad;
  always_comb begin
    cmp_guard_bad = (meta0[31:0]  != g_crc);
    cmp_ns_bad    = (meta0[47:32] != exp0[47:32]);
    cmp_lba_bad   = (meta0[63:48] != exp0[63:48]) || (meta1[31:0] != exp1[31:0]);
    cmp_fmt_bad   = (meta1[39:32] != 8'h01) || (meta1[63:40] != 24'h0);
  end

  // ------------------------------------------------------------------ main FSM
  wire is_read = j.mode;
  wire this_unm = j.unm[blk[3:0]];
  logic       cmp_bad;
  logic [7:0] cmp_dt;
  always_comb begin
    cmp_bad = 1'b0; cmp_dt = 8'h0;
    if (j.pi && !this_unm) begin
      if (cmp_fmt_bad)        begin cmp_bad = 1'b1; cmp_dt = DT_PI_FORMAT; end
      else if (cmp_guard_bad) begin cmp_bad = 1'b1; cmp_dt = DT_PI_GUARD; end
      else if (cmp_ns_bad)    begin cmp_bad = 1'b1; cmp_dt = DT_PI_NS_TAG; end
      else if (cmp_lba_bad)   begin cmp_bad = 1'b1; cmp_dt = DT_PI_LBA_TAG; end
    end
  end
  wire need_xts_dec = ENABLE_XTS && j.enc && is_read && !this_unm;
  assign need_xts_dec_w = need_xts_dec && !xts_done_flag;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= X_IDLE; j <= '0; slot_q <= '0; blk <= '0; iss <= '0; rcv <= '0; meta0 <= '0; meta1 <= '0; wm_idx <= 1'b0;
      ok <= 1'b1; r_status <= '0; r_detail <= '0; nblk_ok <= '0; pi_all <= 1'b1; done <= 1'b0; done_slot <= '0; res <= '0;
      g_clr <= 1'b0; p_clr <= 1'b0; xs <= XS_START; xs_k <= '0; xs_w0 <= '0; xs_w1 <= '0; xs_out <= '0;
      xe_key_load <= 1'b0; xe_du_start <= 1'b0; xe_dec <= 1'b0; xe_k1 <= '0; xe_k2 <= '0; xe_k256 <= 1'b0; loaded_key <= '0; loaded_valid <= 1'b0;
      xts_after_rd <= 1'b0; xts_done_flag <= 1'b0; kw_cnt <= '0;
    end else begin
      done <= 1'b0; g_clr <= 1'b0; p_clr <= 1'b0; xe_key_load <= 1'b0; xe_du_start <= 1'b0;
      if (key_zero_i || key_commit_i) loaded_valid <= 1'b0;
      case (st)
        X_IDLE: if (job_valid) begin
          j <= job; slot_q <= job_slot; blk <= '0; ok <= 1'b1; r_status <= ST_SUCCESS; r_detail <= '0; nblk_ok <= '0; pi_all <= 1'b1;
          p_clr <= 1'b1; g_clr <= 1'b1; iss <= '0; rcv <= '0;
          if (ENABLE_XTS && job.enc) begin
            if (int'(job.key) >= NKEY || !key_valid_i[job.key[1:0]]) begin
              st <= X_DONE; ok <= 1'b0; r_status <= ST_CRYPTO_ERROR; r_detail <= DT_KEY_NOT_READY;
            end else if (loaded_valid && loaded_key == job.key) st <= X_RDP;
            else st <= X_KEYLD;
          end else if (job.enc) begin
            st <= X_DONE; ok <= 1'b0; r_status <= ST_CRYPTO_ERROR; r_detail <= DT_CRYPTO_ENGINE;
          end else st <= X_RDP;
          // READ with encryption: decrypt first (entry decided after the key is loaded)
        end
        X_KEYLD: if (xe_key_idle) begin
          xe_key_load <= 1'b1; xe_k1 <= key1_i[int'(j.key[1:0])*256 +: 256]; xe_k2 <= key2_i[int'(j.key[1:0])*256 +: 256];
          xe_k256 <= key256_i[j.key[1:0]]; loaded_key <= j.key; kw_cnt <= 3'd4; st <= X_KEYG;
        end
        X_KEYG: begin if (kw_cnt != 3'd0) kw_cnt <= kw_cnt - 3'd1; else st <= X_KEYW; end      // let the engine leave idle before polling it
        X_KEYW: if (xe_key_idle) begin
          if (xe_key_ok && !xe_key_eq) begin loaded_valid <= 1'b1; st <= X_RDP; end
          else begin st <= X_DONE; ok <= 1'b0; r_status <= ST_CRYPTO_ERROR; r_detail <= DT_CRYPTO_ENGINE; end
        end
        // ---- start of a block: READ+enc decrypts first; others read straight away
        X_RDP: begin
          if (need_xts_dec_w) begin
            st <= X_XTS; xs <= XS_START; xs_k <= '0;
          end else begin
            if (rd_req && lm_gnt) iss <= iss + 8'd1;
            if (lm_rvalid) begin
              if (rcv == 8'd64) meta0 <= lm_rdata;
              if (rcv == 8'd65) meta1 <= lm_rdata;
              rcv <= rcv + 8'd1;
              if (rcv + 8'd1 == rd_total_c) begin
                st <= is_read ? X_CMP : X_WMETA; wm_idx <= 1'b0;
              end
            end
          end
        end
        // ---- WRITE: store the trailer, then encrypt
        X_WMETA: begin
          if (!unit_has_meta) begin
            if (ENABLE_XTS && j.enc) begin st <= X_XTS; xs <= XS_START; xs_k <= '0; end else st <= X_NEXT;
          end else if (lm_gnt) begin
            if (wm_idx) begin
              if (ENABLE_XTS && j.enc) begin st <= X_XTS; xs <= XS_START; xs_k <= '0; end else st <= X_NEXT;
            end else wm_idx <= 1'b1;
          end
        end
        // ---- XTS pass over the unit (WRITE: encrypt, READ: decrypt)
        X_XTS: begin
          case (xs)
            XS_START: if (xe_du_ready) begin xe_du_start <= 1'b1; xe_dec <= is_read; xs <= XS_STARTW; end
            XS_STARTW: begin xs <= XS_RD0; end
            XS_RD0:   if (lm_gnt) xs <= XS_RD0W;
            XS_RD0W:  if (lm_rvalid) begin xs_w0 <= lm_rdata; xs <= XS_RD1; end
            XS_RD1:   if (lm_gnt) xs <= XS_RD1W;
            XS_RD1W:  if (lm_rvalid) begin xs_w1 <= lm_rdata; xs <= XS_PUSH; end
            XS_PUSH:  if (xe_s_ready) xs <= XS_POP;
            XS_POP:   if (xe_m_valid) begin xs_out <= xe_m_data; xs <= XS_WR0; end
            XS_WR0:   if (lm_gnt) xs <= XS_WR1;
            XS_WR1:   if (lm_gnt) begin
                        if (xs_k + 6'd1 == xs_n) xs <= XS_FIN;
                        else begin xs_k <= xs_k + 6'd1; xs <= XS_RD0; end
                      end
            XS_FIN: begin
              if (is_read) begin xts_done_flag <= 1'b1; st <= X_RDP; end      // decrypted: now read + verify
              else st <= X_NEXT;
            end
            default: xs <= XS_START;
          endcase
        end
        // ---- READ: compare
        X_CMP: begin
          if (j.pi && this_unm) pi_all <= 1'b0;
          if (cmp_bad) begin ok <= 1'b0; r_status <= ST_INTEGRITY; r_detail <= cmp_dt; st <= X_DONE; end
          else st <= X_NEXT;
        end
        X_NEXT: begin
          nblk_ok <= nblk_ok + 16'd1;
          xts_done_flag <= 1'b0;
          if (blk + 16'd1 == j.nblk) begin
            // job complete: HCRC check (WRITE)
            if (!is_read && j.hcrc_en && (p_crc != j.hcrc)) begin ok <= 1'b0; r_status <= ST_DATA_CRC; r_detail <= 8'h0; nblk_ok <= '0; end
            st <= X_DONE;
          end else begin
            blk <= blk + 16'd1; iss <= '0; rcv <= '0; g_clr <= 1'b1; st <= X_RDP;
          end
        end
        X_DONE: begin
          done <= 1'b1; done_slot <= slot_q; st <= X_IDLE;
          res.ok <= ok; res.status <= r_status; res.detail <= r_detail; res.crc <= p_crc;
          res.pi_ver <= j.pi && pi_all && ok; res.nblk_ok <= nblk_ok;
        end
        default: st <= X_IDLE;
      endcase
    end
  end
  wire unused_ok = &{1'b0, xts_after_rd, xe_busy, xe_len_err, xe_m_last};
endmodule
`default_nettype wire
