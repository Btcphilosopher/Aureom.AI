// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_slot -- one in-flight command
//
//   WRITE : protected DMA (tenant memory -> staging) -> [HCRC check, protection trailer, encrypt] -> backend write
//           -> (FUA and not durable: backend flush) -> completion
//   READ  : backend read -> [decrypt, verify protection trailer] -> protected DMA (staging -> tenant memory) -> completion
//   FLUSH / DISCARD : backend operation -> completion
//   The completion is built here; durability is copied from the backend completion, never inferred.
//   Abort (queue reset): the slot is released silently at the next point where nothing outstanding refers to it.
//   Backend reset: a slot waiting for the backend completes ABORTED_RESET (TIMEOUT if it caused the reset); the event is delivered when the
//   reset is asserted, NOT when the backend returns.  A slot that needs the backend while it is not ready completes BACKEND_ERROR/NOT_READY
//   (fail fast: tenants never hang on a dead backend).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_slot
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int AW         = 48,
  parameter int DATA_BYTE  = 4096     // byte address of this slot's staging buffer in local memory
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic [31:0]     now_i,
  // admission
  input  wire logic            iss_valid,
  input  wire cmd_t            iss_cmd,
  input  wire logic [3:0]      iss_tenant,
  input  wire logic [3:0]      iss_src,
  input  wire logic            iss_ext,
  input  wire logic [63:0]     iss_abs,
  input  wire logic            iss_pi,
  input  wire logic            iss_enc,
  input  wire logic [3:0]      iss_key,
  // table
  output logic                 busy_o,
  output logic [3:0]           src_o,
  output logic [63:0]          abs_o,
  output logic [15:0]          nblk_o,
  output logic                 wr_o,
  output logic                 flush_o,
  // control
  input  wire logic            abort_i,
  input  wire logic            pf_active_i,
  input  wire logic            be_rst_evt_i,
  input  wire logic            be_ready_i,           // backend present: a command that needs it while it is gone fails fast
  input  wire logic [31:0]     cmd_timeout_i,
  input  wire logic            be_durable_flush_i,   // backend has a volatile cache (FUA needs a flush when not durable)
  input  wire logic            be_pi_native_i,       // backend stores 528-byte units (trailer must be written)
  output logic                 to_evt_o,
  output logic                 ext_in_req_o,      // ext source: the staging buffer must be filled now (WRITE)
  input  wire logic            ext_in_done_i,
  output logic                 ext_out_req_o,     // ext source: the staging buffer holds the read data (READ)
  input  wire logic            ext_out_done_i,
  output logic                 be_wait_o,
  output logic                 be_pend_o,
  // protected-DMA task
  output logic                 d_valid,
  input  wire logic            d_gnt,
  output logic                 d_dir,
  output logic [3:0]           d_dom,
  output logic [AW-1:0]        d_host,
  output logic [15:0]          d_lm,
  output logic [23:0]          d_len,
  input  wire logic            d_rsp,
  input  wire logic            d_ok,
  input  wire logic [7:0]      d_err,
  input  wire logic [3:0]      d_fault,
  // transform job
  output logic                 x_valid,
  input  wire logic            x_gnt,
  output xjob_t                x_job,
  input  wire logic            x_done,
  input  wire xres_t           x_res,
  // backend job
  output logic                 m_valid,
  input  wire logic            m_gnt,
  output logic [2:0]           m_op,
  output logic [63:0]          m_abs,
  output logic [15:0]          m_nblk,
  input  wire logic            bc_valid,
  input  wire logic [3:0]      bc_status,
  input  wire logic            bc_durable,
  input  wire logic [15:0]     bc_nblk,
  input  wire logic [15:0]     uunm_i,
  // completion
  output logic                 cpl_valid,
  input  wire logic            cpl_ready,
  output cpl_t                 cpl_o
);
  typedef enum logic [3:0] {
    S_IDLE, S_WDMA, S_WDMAW, S_XW, S_XWW, S_BE, S_BEWAIT, S_XR, S_XRW, S_RDMA, S_RDMAW, S_FIN, S_EXTIN, S_EXTOUT
  } sstate_t;
  sstate_t st;
  cmd_t        c;
  logic [3:0]  ten;
  logic [3:0]  src_q;
  logic        ext_q;
  logic [63:0] abs_q;
  logic        pi_q, enc_q;
  logic [3:0]  key_q;
  logic        aborted;
  logic [7:0]  status;
  logic [7:0]  detail;
  logic [15:0] nblk_done;
  logic        durable, pi_ver, crc_valid;
  logic [31:0] res0;
  logic [31:0] t_admit, t_issue, t_bedone;
  logic [2:0]  be_op;                  // current backend operation (a FUA write is followed by a flush)
  logic        fua_flush;              // the backend op in progress is the internal flush of a FUA write
  logic [31:0] to_cnt;
  logic        to_fired;
  logic [15:0] unm_q;

  wire is_wr   = (c.op == OP_WRITE);
  wire is_rd   = (c.op == OP_READ);
  wire is_fl   = (c.op == OP_FLUSH);
  wire is_dis  = (c.op == OP_DISCARD);
  wire fua     = c.flags[FLG_FUA];
  wire rcrc    = c.flags[FLG_RCRC];
  wire [15:0] nb16 = c.nblk[15:0];
  wire need_xw = pi_q || enc_q || c.flags[FLG_HCRC] || rcrc || be_pi_native_i;
  wire need_xr = pi_q || enc_q || rcrc;

  assign busy_o   = (st != S_IDLE);
  assign src_o    = src_q;
  assign ext_in_req_o  = (st == S_EXTIN);
  assign ext_out_req_o = (st == S_EXTOUT);
  assign abs_o    = abs_q;
  assign nblk_o   = is_fl ? 16'h0 : nb16;
  assign wr_o     = is_wr || is_dis;
  assign flush_o  = is_fl;

  // DMA task
  assign d_valid = ((st == S_WDMA) || (st == S_RDMA)) && !ext_q;
  assign d_dir   = (st == S_RDMA);
  assign d_dom   = ten;
  assign d_host  = c.addr[AW-1:0];
  assign d_lm    = 16'(DATA_BYTE);
  assign d_len   = {nb16[14:0], 9'h0};

  // transform job
  assign x_valid = (st == S_XW) || (st == S_XR);
  always_comb begin
    x_job = '0;
    x_job.mode = (st == S_XR); x_job.nblk = nb16; x_job.pi = pi_q; x_job.enc = enc_q; x_job.key = key_q; x_job.tenant = ten;
    x_job.nsid = c.nsid; x_job.lba_rel = c.lba[47:0]; x_job.lba_abs = abs_q;
    x_job.hcrc_en = c.flags[FLG_HCRC]; x_job.hcrc = c.hcrc; x_job.unm = unm_q;
  end

  // backend job
  assign m_valid = (st == S_BE);
  assign m_op    = be_op;
  assign m_abs   = abs_q;
  assign m_nblk  = (be_op == BOP_FLUSH) ? 16'h0 : nb16;

  // completion
  assign cpl_valid = (st == S_FIN) && !aborted;
  always_comb begin
    cpl_o = '0;
    cpl_o.txn = c.txn; cpl_o.status = status; cpl_o.detail = detail; cpl_o.op = c.op; cpl_o.nblk_done = nblk_done;
    cpl_o.durable = durable; cpl_o.pi_ver = pi_ver; cpl_o.enc = enc_q && (is_wr || is_rd) && (status == ST_SUCCESS);
    cpl_o.crc_valid = crc_valid; cpl_o.res0 = crc_valid ? res0 : 32'h0; cpl_o.res1 = 32'h0;
    cpl_o.t_fetch = c.t_fetch; cpl_o.t_admit = t_admit; cpl_o.t_issue = t_issue; cpl_o.t_bedone = t_bedone;
    cpl_o.bytes = (status == ST_SUCCESS && (is_wr || is_rd)) ? {7'h0, nb16, 9'h0} : 32'h0;
  end
  assign be_wait_o = (st == S_BEWAIT);
  assign be_pend_o = (st == S_BE);
  assign to_evt_o = (st == S_BEWAIT) && (cmd_timeout_i != 32'h0) && (to_cnt >= cmd_timeout_i) && !to_fired;

  // backend status -> completion status
  function automatic logic [15:0] map_be(input logic [3:0] bs);   // {detail, status}
    case (bs)
      BST_OK:          map_be = {8'h0, ST_SUCCESS};
      BST_MEDIA_ERR:   map_be = {8'(bs), ST_MEDIA_ERROR};
      BST_RESET:       map_be = {8'(bs), ST_ABORTED_RESET};
      BST_UNSUPPORTED: map_be = {8'(bs), ST_UNSUPPORTED};
      default:         map_be = {8'(bs), ST_BACKEND_ERROR};
    endcase
  endfunction
  function automatic logic [15:0] map_dma(input logic [7:0] err, input logic [3:0] fault);
    if (err == 8'h34)      map_dma = {DT_TO_DMA, ST_TIMEOUT};
    else if (fault != 4'h0) map_dma = {4'h0, fault, ST_DMA_FAULT};
    else if (err >= 8'h20 && err <= 8'h24) map_dma = {err, ST_DMA_FAULT};
    else                    map_dma = {err, ST_DMA_ERROR};
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; c <= '0; ten <= '0; src_q <= '0; ext_q <= 1'b0; abs_q <= '0; pi_q <= 1'b0; enc_q <= 1'b0; key_q <= '0; aborted <= 1'b0;
      status <= '0; detail <= '0; nblk_done <= '0; durable <= 1'b0; pi_ver <= 1'b0; crc_valid <= 1'b0; res0 <= '0;
      t_admit <= '0; t_issue <= '0; t_bedone <= '0; be_op <= '0; fua_flush <= 1'b0; to_cnt <= '0; to_fired <= 1'b0; unm_q <= '0;
    end else begin
      // abort (queue reset of this tenant)
      if (abort_i && st != S_IDLE) aborted <= 1'b1;
      to_cnt <= (st == S_BEWAIT) ? to_cnt + 32'd1 : 32'd0;
      if (to_evt_o) to_fired <= 1'b1;
      case (st)
        S_IDLE: begin
          aborted <= 1'b0;
          if (iss_valid) begin
            c <= iss_cmd; ten <= iss_tenant; src_q <= iss_src; ext_q <= iss_ext; abs_q <= iss_abs; pi_q <= iss_pi; enc_q <= iss_enc; key_q <= iss_key;
            status <= ST_SUCCESS; detail <= '0; nblk_done <= '0; durable <= 1'b0; pi_ver <= 1'b0; crc_valid <= 1'b0; res0 <= '0;
            t_admit <= now_i; t_issue <= now_i; t_bedone <= now_i; fua_flush <= 1'b0; to_fired <= 1'b0; unm_q <= '0;
            case (iss_cmd.op)
              OP_WRITE:   begin st <= iss_ext ? S_EXTIN : S_WDMA; be_op <= BOP_WRITE; end
              OP_READ:    begin st <= S_BE;   be_op <= BOP_READ;  end
              OP_FLUSH:   begin st <= S_BE;   be_op <= BOP_FLUSH; end
              OP_DISCARD: begin st <= S_BE;   be_op <= BOP_DISCARD; end
              default:    begin st <= S_FIN;  status <= ST_INTERNAL; detail <= 8'h01; end
            endcase
          end
        end
        // ---------------- WRITE: host -> staging
        S_EXTIN: if (aborted) st <= S_IDLE; else if (ext_in_done_i) st <= need_xw ? S_XW : S_BE;
        S_EXTOUT: if (aborted) st <= S_IDLE; else if (ext_out_done_i) st <= S_FIN;
        S_WDMA:  if (aborted) st <= S_IDLE; else if (d_gnt) st <= S_WDMAW;
        S_WDMAW: if (d_rsp) begin
          if (aborted) st <= S_IDLE;
          else if (d_ok) st <= need_xw ? S_XW : S_BE;
          else begin {detail, status} <= map_dma(d_err, d_fault); st <= S_FIN; end
        end
        S_XW:  if (aborted) st <= S_IDLE; else if (x_gnt) st <= S_XWW;
        S_XWW: if (x_done) begin
          res0 <= x_res.crc; pi_ver <= x_res.pi_ver;
          if (aborted) st <= S_IDLE;
          else if (x_res.ok) begin crc_valid <= rcrc; st <= S_BE; end
          else begin status <= x_res.status; detail <= x_res.detail; nblk_done <= x_res.nblk_ok; st <= S_FIN; end
        end
        // ---------------- backend operation
        S_BE: begin
          if (aborted) st <= S_IDLE;
          else if (pf_active_i && !fua_flush) begin status <= ST_ABORTED_POWER; detail <= '0; st <= S_FIN; end
          else if (!be_ready_i) begin status <= ST_BACKEND_ERROR; detail <= 8'(BST_NOT_READY); durable <= 1'b0; crc_valid <= 1'b0; nblk_done <= '0; st <= S_FIN; end
          else if (m_gnt) begin t_issue <= now_i; st <= S_BEWAIT; end
        end
        S_BEWAIT: begin
          if (be_rst_evt_i) begin
            if (aborted) st <= S_IDLE;
            else begin
              status <= to_fired ? ST_TIMEOUT : ST_ABORTED_RESET; detail <= to_fired ? DT_TO_BACKEND : 8'h0;
              durable <= 1'b0; crc_valid <= 1'b0; st <= S_FIN;
            end
          end else if (bc_valid) begin
            t_bedone <= now_i;
            if (aborted) st <= S_IDLE;
            else if (bc_status != BST_OK) begin
              {detail, status} <= map_be(bc_status); nblk_done <= bc_nblk; crc_valid <= 1'b0; durable <= 1'b0; st <= S_FIN;
            end else begin
              case (be_op)
                BOP_WRITE: begin
                  durable <= bc_durable; nblk_done <= nb16;
                  if (fua && !bc_durable) begin
                    if (be_durable_flush_i) begin be_op <= BOP_FLUSH; fua_flush <= 1'b1; st <= S_BE; end
                    else begin status <= ST_BACKEND_ERROR; detail <= 8'h0F; crc_valid <= 1'b0; st <= S_FIN; end
                  end else st <= S_FIN;
                end
                BOP_FLUSH: begin
                  if (!bc_durable) begin status <= ST_BACKEND_ERROR; detail <= 8'h0E; durable <= 1'b0; end
                  else durable <= 1'b1;
                  if (fua_flush) nblk_done <= nb16;
                  st <= S_FIN;
                end
                BOP_DISCARD: begin durable <= bc_durable; nblk_done <= nb16; st <= S_FIN; end
                BOP_READ: begin unm_q <= uunm_i; nblk_done <= nb16; st <= need_xr ? S_XR : S_RDMA; end
                default: st <= S_FIN;
              endcase
            end
          end
        end
        // ---------------- READ: decode / verify, then staging -> host
        S_XR:  if (aborted) st <= S_IDLE; else if (x_gnt) st <= S_XRW;
        S_XRW: if (x_done) begin
          res0 <= x_res.crc; pi_ver <= x_res.pi_ver;
          if (aborted) st <= S_IDLE;
          else if (x_res.ok) begin crc_valid <= rcrc; st <= S_RDMA; end
          else begin status <= x_res.status; detail <= x_res.detail; nblk_done <= x_res.nblk_ok; crc_valid <= 1'b0; st <= S_FIN; end
        end
        S_RDMA:  if (aborted) st <= S_IDLE; else if (ext_q) st <= S_EXTOUT; else if (d_gnt) st <= S_RDMAW;
        S_RDMAW: if (d_rsp) begin
          if (aborted) st <= S_IDLE;
          else if (d_ok) st <= S_FIN;
          else begin {detail, status} <= map_dma(d_err, d_fault); nblk_done <= '0; crc_valid <= 1'b0; st <= S_FIN; end
        end
        S_FIN: begin
          if (aborted) st <= S_IDLE;
          else if (cpl_ready) st <= S_IDLE;
        end
        default: st <= S_IDLE;
      endcase
    end
  end
  wire unused_ok = &{1'b0, is_rd, is_fl};
endmodule
`default_nettype wire
