// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_axi_xbar -- one AXI4 master (CloudDMA) to two slaves, routed by `asid`
//   asid == ASID_LMEM (1) -> slave 1 (local staging memory);  every other asid -> slave 0 (host memory, off-chip).
//   AW routing is remembered in a small FIFO so W beats follow their AW; R bursts are merged without interleaving.
//   IDs are passed through unchanged.  The off-chip slave sees the DMA's domain/asid sidebands unchanged.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_axi_xbar #(
  parameter int AW   = 48,
  parameter int DW   = 64,
  parameter int ID_W = 4,
  parameter int DOM_W = 4
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // master side
  input  wire logic                m_ar_valid, output logic m_ar_ready,
  input  wire logic [ID_W-1:0]     m_ar_id,
  input  wire logic [AW-1:0]       m_ar_addr,
  input  wire logic [7:0]          m_ar_len,
  input  wire logic [2:0]          m_ar_size,
  input  wire logic [1:0]          m_ar_burst,
  input  wire logic [3:0]          m_ar_asid,
  input  wire logic [DOM_W-1:0]    m_ar_domain,
  output logic                     m_r_valid, input wire logic m_r_ready,
  output logic [ID_W-1:0]          m_r_id,
  output logic [DW-1:0]            m_r_data,
  output logic [1:0]               m_r_resp,
  output logic                     m_r_last,
  input  wire logic                m_aw_valid, output logic m_aw_ready,
  input  wire logic [ID_W-1:0]     m_aw_id,
  input  wire logic [AW-1:0]       m_aw_addr,
  input  wire logic [7:0]          m_aw_len,
  input  wire logic [2:0]          m_aw_size,
  input  wire logic [1:0]          m_aw_burst,
  input  wire logic [3:0]          m_aw_asid,
  input  wire logic [DOM_W-1:0]    m_aw_domain,
  input  wire logic                m_w_valid, output logic m_w_ready,
  input  wire logic [DW-1:0]       m_w_data,
  input  wire logic [DW/8-1:0]     m_w_strb,
  input  wire logic                m_w_last,
  output logic                     m_b_valid, input wire logic m_b_ready,
  output logic [ID_W-1:0]          m_b_id,
  output logic [1:0]               m_b_resp,
  // slave 0 : host
  output logic                     s0_ar_valid, input wire logic s0_ar_ready,
  output logic [ID_W-1:0]          s0_ar_id,
  output logic [AW-1:0]            s0_ar_addr,
  output logic [7:0]               s0_ar_len,
  output logic [2:0]               s0_ar_size,
  output logic [1:0]               s0_ar_burst,
  output logic [3:0]               s0_ar_asid,
  output logic [DOM_W-1:0]         s0_ar_domain,
  input  wire logic                s0_r_valid, output logic s0_r_ready,
  input  wire logic [ID_W-1:0]     s0_r_id,
  input  wire logic [DW-1:0]       s0_r_data,
  input  wire logic [1:0]          s0_r_resp,
  input  wire logic                s0_r_last,
  output logic                     s0_aw_valid, input wire logic s0_aw_ready,
  output logic [ID_W-1:0]          s0_aw_id,
  output logic [AW-1:0]            s0_aw_addr,
  output logic [7:0]               s0_aw_len,
  output logic [2:0]               s0_aw_size,
  output logic [1:0]               s0_aw_burst,
  output logic [3:0]               s0_aw_asid,
  output logic [DOM_W-1:0]         s0_aw_domain,
  output logic                     s0_w_valid, input wire logic s0_w_ready,
  output logic [DW-1:0]            s0_w_data,
  output logic [DW/8-1:0]          s0_w_strb,
  output logic                     s0_w_last,
  input  wire logic                s0_b_valid, output logic s0_b_ready,
  input  wire logic [ID_W-1:0]     s0_b_id,
  input  wire logic [1:0]          s0_b_resp,
  // slave 1 : local memory
  output logic                     s1_ar_valid, input wire logic s1_ar_ready,
  output logic [ID_W-1:0]          s1_ar_id,
  output logic [AW-1:0]            s1_ar_addr,
  output logic [7:0]               s1_ar_len,
  output logic [2:0]               s1_ar_size,
  output logic [1:0]               s1_ar_burst,
  input  wire logic                s1_r_valid, output logic s1_r_ready,
  input  wire logic [ID_W-1:0]     s1_r_id,
  input  wire logic [DW-1:0]       s1_r_data,
  input  wire logic [1:0]          s1_r_resp,
  input  wire logic                s1_r_last,
  output logic                     s1_aw_valid, input wire logic s1_aw_ready,
  output logic [ID_W-1:0]          s1_aw_id,
  output logic [AW-1:0]            s1_aw_addr,
  output logic [7:0]               s1_aw_len,
  output logic [2:0]               s1_aw_size,
  output logic [1:0]               s1_aw_burst,
  output logic                     s1_w_valid, input wire logic s1_w_ready,
  output logic [DW-1:0]            s1_w_data,
  output logic [DW/8-1:0]          s1_w_strb,
  output logic                     s1_w_last,
  input  wire logic                s1_b_valid, output logic s1_b_ready,
  input  wire logic [ID_W-1:0]     s1_b_id,
  input  wire logic [1:0]          s1_b_resp
);
  localparam logic [3:0] ASID_LMEM = 4'd1;

  // ---------------- AR
  wire ar_to1 = (m_ar_asid == ASID_LMEM);
  assign s0_ar_valid = m_ar_valid && !ar_to1;
  assign s1_ar_valid = m_ar_valid &&  ar_to1;
  assign m_ar_ready  = ar_to1 ? s1_ar_ready : s0_ar_ready;
  assign {s0_ar_id, s0_ar_addr, s0_ar_len, s0_ar_size, s0_ar_burst} = {m_ar_id, m_ar_addr, m_ar_len, m_ar_size, m_ar_burst};
  assign s0_ar_asid = m_ar_asid;
  assign s0_ar_domain = m_ar_domain;
  assign {s1_ar_id, s1_ar_addr, s1_ar_len, s1_ar_size, s1_ar_burst} = {m_ar_id, m_ar_addr, m_ar_len, m_ar_size, m_ar_burst};

  // ---------------- AW + W routing
  wire aw_to1 = (m_aw_asid == ASID_LMEM);
  logic [7:0] wq_dest;           // 8-deep FIFO of destinations
  logic [3:0] wq_cnt;
  logic [2:0] wq_rp, wq_wp;
  wire wq_full  = (wq_cnt == 4'd8);
  wire wq_empty = (wq_cnt == 4'd0);
  assign s0_aw_valid = m_aw_valid && !aw_to1 && !wq_full;
  assign s1_aw_valid = m_aw_valid &&  aw_to1 && !wq_full;
  assign m_aw_ready  = !wq_full && (aw_to1 ? s1_aw_ready : s0_aw_ready);
  assign {s0_aw_id, s0_aw_addr, s0_aw_len, s0_aw_size, s0_aw_burst} = {m_aw_id, m_aw_addr, m_aw_len, m_aw_size, m_aw_burst};
  assign s0_aw_asid = m_aw_asid;
  assign s0_aw_domain = m_aw_domain;
  assign {s1_aw_id, s1_aw_addr, s1_aw_len, s1_aw_size, s1_aw_burst} = {m_aw_id, m_aw_addr, m_aw_len, m_aw_size, m_aw_burst};
  wire w_dest = wq_dest[wq_rp];
  assign s0_w_valid = m_w_valid && !wq_empty && !w_dest;
  assign s1_w_valid = m_w_valid && !wq_empty &&  w_dest;
  assign m_w_ready  = !wq_empty && (w_dest ? s1_w_ready : s0_w_ready);
  assign {s0_w_data, s0_w_strb, s0_w_last} = {m_w_data, m_w_strb, m_w_last};
  assign {s1_w_data, s1_w_strb, s1_w_last} = {m_w_data, m_w_strb, m_w_last};
  wire aw_hs = m_aw_valid && m_aw_ready;
  wire w_pop = m_w_valid && m_w_ready && m_w_last;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin wq_cnt <= '0; wq_rp <= '0; wq_wp <= '0; wq_dest <= '0; end
    else begin
      if (aw_hs) begin wq_dest[wq_wp] <= aw_to1; wq_wp <= wq_wp + 3'd1; end
      if (w_pop) wq_rp <= wq_rp + 3'd1;
      wq_cnt <= wq_cnt + {3'b0, aw_hs} - {3'b0, w_pop};
    end
  end

  // ---------------- R merge (burst granularity)
  logic r_lock, r_sel;           // r_lock: a burst is in progress on slave r_sel
  wire  r_pick1 = r_lock ? r_sel : (!s0_r_valid && s1_r_valid);
  wire  r_any   = r_lock ? (r_sel ? s1_r_valid : s0_r_valid) : (s0_r_valid || s1_r_valid);
  assign m_r_valid = r_any;
  assign m_r_id    = r_pick1 ? s1_r_id   : s0_r_id;
  assign m_r_data  = r_pick1 ? s1_r_data : s0_r_data;
  assign m_r_resp  = r_pick1 ? s1_r_resp : s0_r_resp;
  assign m_r_last  = r_pick1 ? s1_r_last : s0_r_last;
  assign s0_r_ready = m_r_ready && r_any && !r_pick1;
  assign s1_r_ready = m_r_ready && r_any &&  r_pick1;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin r_lock <= 1'b0; r_sel <= 1'b0; end
    else if (m_r_valid && m_r_ready) begin
      if (m_r_last) r_lock <= 1'b0; else begin r_lock <= 1'b1; r_sel <= r_pick1; end
    end
  end

  // ---------------- B merge
  logic b_rr;
  wire  b_pick1 = (s0_b_valid && s1_b_valid) ? b_rr : s1_b_valid;
  assign m_b_valid = s0_b_valid || s1_b_valid;
  assign m_b_id    = b_pick1 ? s1_b_id   : s0_b_id;
  assign m_b_resp  = b_pick1 ? s1_b_resp : s0_b_resp;
  assign s0_b_ready = m_b_ready && s0_b_valid && !b_pick1;
  assign s1_b_ready = m_b_ready && s1_b_valid &&  b_pick1;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) b_rr <= 1'b0;
    else if (m_b_valid && m_b_ready) b_rr <= !b_pick1;
  end
endmodule
`default_nettype wire
