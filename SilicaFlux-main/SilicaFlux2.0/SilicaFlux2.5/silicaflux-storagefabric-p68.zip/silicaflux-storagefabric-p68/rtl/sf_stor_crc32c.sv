// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_crc32c -- streaming CRC-32C (Castagnoli), up to 8 bytes per cycle
//   reflected, init / xorout 0xFFFFFFFF; byte 0 = data_i[7:0].  `clr` loads the init value (priority over `en`).
//   crc_o is the final value (xorout applied) over the bytes consumed since the last clr.
//   NOT a cryptographic primitive: detects accidental corruption only.
//   Cross-checked against the vendored SecureStore sfsec_crc (MODE 0) in tb/tb_crc_xcheck.sv and against the
//   standard check value crc32c("123456789") = E3069283.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_crc32c
  import silicaflux_storage_fabric_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        clr,
  input  wire logic        en,
  input  wire logic [63:0] data_i,
  input  wire logic [3:0]  nbytes_i,    // 1..8
  output logic [31:0]      crc_o
);
  logic [31:0] st, nxt;
  always_comb begin
    nxt = st;
    for (int i = 0; i < 8; i++)
      if (i < int'(nbytes_i)) nxt = crc32c_byte(nxt, data_i[8*i +: 8]);
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)    st <= 32'hFFFF_FFFF;
    else if (clr)  st <= 32'hFFFF_FFFF;
    else if (en)   st <= nxt;
  end
  assign crc_o = ~st;
endmodule
`default_nettype wire
