// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_mgmt -- privileged management window (docs/02_HOST_INTERFACE.md §9)
//   Global control, per-tenant quotas, namespace table (with isolation checks), DMA window programming, key store,
//   backend control, performance counters, completion trace FIFO.
//   This port must never be reachable by a tenant.  Keys are write-only.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_mgmt
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int NT         = 4,
  parameter int NSLOT      = 8,
  parameter int NS_N       = 8,
  parameter int MDTS       = 8,
  parameter int SQ_MAX     = 32,
  parameter int CQ_MAX     = 32,
  parameter int AW         = 48,
  parameter bit HAS_XTS    = 1'b0,
  parameter bit HAS_VIRTIO = 1'b0,
  parameter int BE_TYPE    = 0,
  parameter int NKEY       = 4,
  parameter int TRACE_DEPTH = 64
) (
  input  wire logic                     clk,
  input  wire logic                     rst_n,
  // management bus
  input  wire logic                     m_valid,
  input  wire logic                     m_we,
  input  wire logic [11:0]              m_addr,
  input  wire logic [31:0]              m_wdata,
  output logic [31:0]                   m_rdata,
  output logic                          m_err,
  // global control
  output logic                          glb_enable,
  output logic                          soft_rst,
  output logic                          trace_en,
  output logic                          clr_counters,
  output logic                          rd_prio,
  output logic                          wr_batch,
  output logic [31:0]                   cmd_timeout,
  output logic [7:0]                    wr_batch_max,
  output logic [7:0]                    wr_age_max,
  output logic                          pf_force,
  // tenant configuration
  output logic [NT-1:0]                 t_allowed,
  output logic [NT*8-1:0]               t_maxinfl,
  output logic [NT*8-1:0]               t_weight,
  output logic [NT*16-1:0]              t_rate,
  output logic [NT*16-1:0]              t_burst,
  // namespace table
  output logic [NS_N-1:0]               ns_valid,
  output logic [NS_N*4-1:0]             ns_owner,
  output logic [NS_N-1:0]               ns_ro,
  output logic [NS_N-1:0]               ns_enc,
  output logic [NS_N-1:0]               ns_pi,
  output logic [NS_N*4-1:0]             ns_key,
  output logic [NS_N*64-1:0]            ns_base,
  output logic [NS_N*64-1:0]            ns_size,
  // backend
  input  wire logic                     be_ready_i,
  input  wire logic [63:0]              be_capacity_i,
  input  wire logic [7:0]               be_caps_i,
  output logic                          be_reset_pulse,
  // DMA windows
  output logic                          pt_wr,
  output logic [3:0]                    pt_idx,
  output logic                          pt_valid,
  output logic [3:0]                    pt_dom,
  output logic [AW-1:0]                 pt_base,
  output logic [AW:0]                   pt_size,
  output logic [1:0]                    pt_perm,
  input  wire logic                     pt_rej_i,
  // keys
  output logic [NKEY-1:0]               key_valid,
  output logic [NKEY*256-1:0]           key1,
  output logic [NKEY*256-1:0]           key2,
  output logic [NKEY-1:0]               key256,
  output logic                          key_zero,
  output logic                          key_commit,
  // status
  input  wire logic                     pf_active_i,
  input  wire logic                     fatal_i,
  input  wire logic [7:0]               busy_slots_i,
  input  wire logic [7:0]               be_busy_i,
  input  wire logic [PC_N*64-1:0]       perf_i,
  // trace
  input  wire logic                     tr_valid_i,
  input  wire logic [255:0]             tr_rec_i
);
  // ------------------------------------------------------------------ state
  logic [7:0]   ttab_maxinfl [NT];
  logic [7:0]   ttab_weight  [NT];
  logic [15:0]  ttab_rate    [NT];
  logic [15:0]  ttab_burst   [NT];
  logic         ttab_allowed [NT];
  logic         nsv [NS_N];
  logic         nsro [NS_N];
  logic         nsenc [NS_N];
  logic         nspi [NS_N];
  logic [3:0]   nsown [NS_N];
  logic [3:0]   nskey [NS_N];
  logic [63:0]  nsbase [NS_N];
  logic [63:0]  nssize [NS_N];
  logic [7:0]   nsstat [NS_N];
  logic [3:0]   pt_sel_idx;  logic [3:0] pt_dom_q;  logic [63:0] pt_base_q, pt_size_q; logic [1:0] pt_perm_q; logic pt_valid_q; logic pt_status;
  logic [3:0]   key_sel;
  logic [31:0]  key_stage [16];
  logic [7:0]   perf_sel;
  logic [31:0]  perf_hi_lat;
  logic         pf_force_q;
  logic         enable_q, trace_en_q, rd_prio_q, wr_batch_q;
  logic [31:0]  timeout_q;
  logic [7:0]   wbm_q, wam_q;

  assign glb_enable = enable_q; assign trace_en = trace_en_q; assign rd_prio = rd_prio_q; assign wr_batch = wr_batch_q;
  assign cmd_timeout = timeout_q; assign wr_batch_max = wbm_q; assign wr_age_max = wam_q; assign pf_force = pf_force_q;

  always_comb begin
    for (int t = 0; t < NT; t++) begin
      t_allowed[t] = ttab_allowed[t];
      t_maxinfl[t*8 +: 8] = ttab_maxinfl[t]; t_weight[t*8 +: 8] = ttab_weight[t];
      t_rate[t*16 +: 16] = ttab_rate[t]; t_burst[t*16 +: 16] = ttab_burst[t];
    end
    for (int n = 0; n < NS_N; n++) begin
      ns_valid[n] = nsv[n]; ns_ro[n] = nsro[n]; ns_enc[n] = nsenc[n]; ns_pi[n] = nspi[n];
      ns_owner[n*4 +: 4] = nsown[n]; ns_key[n*4 +: 4] = nskey[n]; ns_base[n*64 +: 64] = nsbase[n]; ns_size[n*64 +: 64] = nssize[n];
    end
  end

  // ------------------------------------------------------------------ namespace overlap check (against every valid namespace)
  logic ns_ov_w;
  always_comb begin
    automatic int ni = (int'(m_addr[11:2]) - 'hC0) / 8;
    ns_ov_w = 1'b0;
    for (int n = 0; n < NS_N; n++) if (n == ni) begin
      for (int o = 0; o < NS_N; o++) if (o != n && nsv[o]) begin
        if ({1'b0, nsbase[n]} < ({1'b0, nsbase[o]} + {1'b0, nssize[o]}) &&
            {1'b0, nsbase[o]} < ({1'b0, nsbase[n]} + {1'b0, nssize[n]})) ns_ov_w = 1'b1;
      end
    end
  end

  // ------------------------------------------------------------------ trace FIFO
  logic [31:0] tr_mem [TRACE_DEPTH][8];
  logic [$clog2(TRACE_DEPTH):0] tr_cnt;
  logic [$clog2(TRACE_DEPTH)-1:0] tr_rp, tr_wp;
  logic [15:0] tr_drop;
  logic        tr_pop;
  assign tr_pop = m_valid && m_we && !m_err && (m_addr[11:2] == 10'h249);

  // ------------------------------------------------------------------ reads
  always_comb begin
    m_rdata = 32'h0; m_err = 1'b0;
    case (m_addr[11:2])
      10'h000: m_rdata = SFS_ID_MGMT;
      10'h001: m_rdata = SFS_ABI_VERSION;
      10'h002: m_rdata = {8'(MDTS), 8'(NS_N), 8'(NSLOT), 8'(NT)};
      10'h003: m_rdata = {4'h0, 4'(BE_TYPE), 6'h0, HAS_VIRTIO, HAS_XTS, 8'(CQ_MAX), 8'(SQ_MAX)};
      10'h004: m_rdata = {26'h0, wr_batch_q, rd_prio_q, 1'b0, trace_en_q, 1'b0, enable_q};
      10'h005: m_rdata = {8'h0, be_busy_i, busy_slots_i, 5'h0, fatal_i, pf_active_i, be_ready_i};
      10'h006: m_rdata = timeout_q;
      10'h007: m_rdata = {16'h0, wam_q, wbm_q};
      10'h008: m_rdata = {31'h0, pf_force_q};
      // tenant configuration
      default: begin
        if (m_addr[11:2] >= 10'h040 && m_addr[11:2] < 10'h040 + 10'(NT * 8)) begin
          automatic int t = (int'(m_addr[11:2]) - 'h40) / 8;
          automatic int r = (int'(m_addr[11:2]) - 'h40) % 8;
          case (r)
            0: m_rdata = {31'h0, ttab_allowed[t]};
            1: m_rdata = {24'h0, ttab_maxinfl[t]};
            2: m_rdata = {24'h0, ttab_weight[t]};
            3: m_rdata = {16'h0, ttab_rate[t]};
            4: m_rdata = {16'h0, ttab_burst[t]};
            default: m_err = 1'b1;
          endcase
        end else if (m_addr[11:2] >= 10'h0C0 && m_addr[11:2] < 10'h0C0 + 10'(NS_N * 8)) begin
          automatic int n = (int'(m_addr[11:2]) - 'hC0) / 8;
          automatic int r = (int'(m_addr[11:2]) - 'hC0) % 8;
          case (r)
            0: m_rdata = {20'h0, nskey[n], nsown[n], nspi[n], nsenc[n], nsro[n], nsv[n]};
            1: m_rdata = nsbase[n][31:0];
            2: m_rdata = nsbase[n][63:32];
            3: m_rdata = nssize[n][31:0];
            4: m_rdata = nssize[n][63:32];
            5: m_rdata = {24'h0, nsstat[n]};
            default: m_err = 1'b1;
          endcase
        end else begin
          case (m_addr[11:2])
            10'h140: m_rdata = {28'h0, pt_sel_idx};
            10'h141: m_rdata = {28'h0, pt_dom_q};
            10'h142: m_rdata = pt_base_q[31:0];
            10'h143: m_rdata = pt_base_q[63:32];
            10'h144: m_rdata = pt_size_q[31:0];
            10'h145: m_rdata = pt_size_q[63:32];
            10'h146: m_rdata = {30'h0, pt_perm_q};
            10'h147: m_rdata = {31'h0, pt_valid_q};
            10'h148: m_rdata = {31'h0, pt_status};
            10'h180: m_rdata = 32'(BE_TYPE);
            10'h184: m_rdata = 32'h0;                                                       // BE_CTRL (W1S)
            10'h1D1: m_rdata = 32'h0;                                                       // KEY_CTRL (W1S)
            10'h249: m_rdata = 32'h0;                                                       // TR_POP (W1S)
            10'h181: m_rdata = {24'h0, be_caps_i};
            10'h182: m_rdata = be_capacity_i[31:0];
            10'h183: m_rdata = be_capacity_i[63:32];
            10'h1C0: m_rdata = {28'h0, key_sel};
            10'h1C1, 10'h1C2, 10'h1C3, 10'h1C4, 10'h1C5, 10'h1C6, 10'h1C7, 10'h1C8, 10'h1C9, 10'h1CA, 10'h1CB, 10'h1CC,
            10'h1CD, 10'h1CE, 10'h1CF, 10'h1D0: m_rdata = 32'h0;                          // key words: write-only
            10'h1D2: begin m_rdata = 32'h0; for (int k = 0; k < NKEY; k++) m_rdata[k] = key_valid[k]; end  // KEY_STATUS @0x748
            10'h200: m_rdata = {24'h0, perf_sel};
            10'h201: m_rdata = perf_i[int'(perf_sel[4:0])*64 +: 32];
            10'h202: m_rdata = perf_hi_lat;
            10'h240: m_rdata = {tr_drop, 16'(tr_cnt)};
            10'h241, 10'h242, 10'h243, 10'h244, 10'h245, 10'h246, 10'h247, 10'h248:
                     m_rdata = (tr_cnt != 0) ? tr_mem[tr_rp][int'(m_addr[11:2]) - 'h241] : 32'h0;
            default: m_err = 1'b1;
          endcase
        end
      end
    endcase
    if (m_addr[1:0] != 2'b00) m_err = 1'b1;
    // a write to a read-only register is an error as well (and has no effect)
    if (m_we && m_ro) m_err = 1'b1;
  end
  logic m_ro;
  always_comb begin
    automatic int w = int'(m_addr[11:2]);
    m_ro = (w <= 3) || (w == 5) || (w == 'h148) || (w >= 'h180 && w <= 'h183) || (w == 'h1D2) || (w == 'h201) || (w == 'h202) ||
           (w >= 'h240 && w <= 'h248);
    if (w >= 'hC0 && w < 'hC0 + NS_N * 8 && ((w - 'hC0) % 8) == 5) m_ro = 1'b1;       // NS_STATUS
  end

  // ------------------------------------------------------------------ writes
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      enable_q <= 1'b0; trace_en_q <= 1'b0; rd_prio_q <= 1'b0; wr_batch_q <= 1'b0; timeout_q <= '0; wbm_q <= 8'd4; wam_q <= 8'd8;
      pf_force_q <= 1'b0; soft_rst <= 1'b0; clr_counters <= 1'b0; be_reset_pulse <= 1'b0; key_zero <= 1'b0; key_commit <= 1'b0;
      pt_wr <= 1'b0; pt_idx <= '0; pt_valid <= 1'b0; pt_dom <= '0; pt_base <= '0; pt_size <= '0; pt_perm <= '0;
      pt_sel_idx <= '0; pt_dom_q <= '0; pt_base_q <= '0; pt_size_q <= '0; pt_perm_q <= '0; pt_valid_q <= 1'b0; pt_status <= 1'b0;
      key_sel <= '0; key_valid <= '0; key1 <= '0; key2 <= '0; key256 <= '0; perf_sel <= '0; perf_hi_lat <= '0;
      tr_cnt <= '0; tr_rp <= '0; tr_wp <= '0; tr_drop <= '0;
      for (int t = 0; t < NT; t++) begin ttab_maxinfl[t] <= 8'd0; ttab_weight[t] <= 8'd1; ttab_rate[t] <= 16'd0; ttab_burst[t] <= 16'd16; ttab_allowed[t] <= 1'b0; end
      for (int n = 0; n < NS_N; n++) begin nsv[n] <= 1'b0; nsro[n] <= 1'b0; nsenc[n] <= 1'b0; nspi[n] <= 1'b0; nsown[n] <= 4'h0; nskey[n] <= 4'h0;
                                           nsbase[n] <= '0; nssize[n] <= '0; nsstat[n] <= '0; end
      for (int w = 0; w < 16; w++) key_stage[w] <= '0;
    end else begin
      soft_rst <= 1'b0; clr_counters <= 1'b0; be_reset_pulse <= 1'b0; key_zero <= 1'b0; key_commit <= 1'b0; pt_wr <= 1'b0;
      pf_force_q <= pf_force_q;
      if (pt_rej_i) pt_status <= 1'b1;
      // trace push
      if (tr_valid_i && trace_en_q) begin
        if (int'(tr_cnt) == TRACE_DEPTH) begin if (tr_drop != 16'hFFFF) tr_drop <= tr_drop + 16'd1; end
        else begin
          for (int w = 0; w < 8; w++) tr_mem[tr_wp][w] <= tr_rec_i[32*w +: 32];
          tr_wp <= tr_wp + 1'b1;
        end
      end
      if (m_valid && m_we && !m_err) begin
        case (m_addr[11:2])
          10'h004: begin
            enable_q <= m_wdata[0]; trace_en_q <= m_wdata[2]; rd_prio_q <= m_wdata[4]; wr_batch_q <= m_wdata[5];
            if (m_wdata[1]) soft_rst <= 1'b1;
            if (m_wdata[3]) begin clr_counters <= 1'b1; tr_drop <= '0; end
          end
          10'h006: timeout_q <= m_wdata;
          10'h007: begin wbm_q <= m_wdata[7:0]; wam_q <= m_wdata[15:8]; end
          10'h008: pf_force_q <= m_wdata[0];
          10'h140: pt_sel_idx <= m_wdata[3:0];
          10'h141: pt_dom_q <= m_wdata[3:0];
          10'h142: pt_base_q[31:0] <= m_wdata;
          10'h143: pt_base_q[63:32] <= m_wdata;
          10'h144: pt_size_q[31:0] <= m_wdata;
          10'h145: pt_size_q[63:32] <= m_wdata;
          10'h146: pt_perm_q <= m_wdata[1:0];
          10'h147: begin
            pt_valid_q <= m_wdata[0];
            if (m_wdata[1]) begin
              pt_wr <= 1'b1; pt_idx <= (pt_sel_idx < 4'(NT)) ? 4'(NT) : pt_sel_idx;     // entries 0..NT-1 belong to the fabric
              pt_valid <= m_wdata[0]; pt_dom <= pt_dom_q; pt_base <= pt_base_q[AW-1:0]; pt_size <= pt_size_q[AW:0]; pt_perm <= pt_perm_q;
              pt_status <= 1'b0;
              if (pt_sel_idx < 4'(NT)) pt_status <= 1'b1;                                // refused: reserved entry
            end
          end
          10'h181: ;
          10'h184: if (m_wdata[0]) be_reset_pulse <= 1'b1;
          10'h1C0: key_sel <= m_wdata[3:0];
          10'h1D1: begin                                                                   // KEY_CTRL @0x744
            if (m_wdata[0] && int'(key_sel) < NKEY) begin
              for (int i = 0; i < 32; i++) begin
                key1[int'(key_sel[1:0])*256 + 255 - 8*i -: 8] <= key_stage[i/4][8*(i%4) +: 8];
                key2[int'(key_sel[1:0])*256 + 255 - 8*i -: 8] <= key_stage[8 + i/4][8*(i%4) +: 8];
              end
              key256[key_sel[1:0]] <= !m_wdata[2]; key_valid[key_sel[1:0]] <= 1'b1; key_commit <= 1'b1;
              for (int w = 0; w < 16; w++) key_stage[w] <= '0;                           // staging buffer is wiped
            end
            if (m_wdata[1]) begin
              key_valid <= '0; key1 <= '0; key2 <= '0; key256 <= '0; key_zero <= 1'b1;
              for (int w = 0; w < 16; w++) key_stage[w] <= '0;
            end
          end
          10'h200: perf_sel <= m_wdata[7:0];
          10'h249: ;                                                                       // TR_POP @ 0x924 (handled above)
          default: begin
            if (m_addr[11:2] >= 10'h1C1 && m_addr[11:2] <= 10'h1D0) key_stage[int'(m_addr[11:2]) - 'h1C1] <= m_wdata;
            else if (m_addr[11:2] >= 10'h040 && m_addr[11:2] < 10'h040 + 10'(NT * 8)) begin
              automatic int t = (int'(m_addr[11:2]) - 'h40) / 8;
              automatic int r = (int'(m_addr[11:2]) - 'h40) % 8;
              case (r)
                0: ttab_allowed[t] <= m_wdata[0];
                1: ttab_maxinfl[t] <= m_wdata[7:0];
                2: ttab_weight[t]  <= m_wdata[7:0];
                3: ttab_rate[t]    <= m_wdata[15:0];
                4: ttab_burst[t]   <= m_wdata[15:0];
                default: ;
              endcase
            end else if (m_addr[11:2] >= 10'h0C0 && m_addr[11:2] < 10'h0C0 + 10'(NS_N * 8)) begin
              automatic int n = (int'(m_addr[11:2]) - 'hC0) / 8;
              automatic int r = (int'(m_addr[11:2]) - 'hC0) % 8;
              case (r)
                0: begin
                  if (!m_wdata[0]) begin nsv[n] <= 1'b0; nsstat[n] <= 8'h0; end
                  else if (!nsv[n]) begin
                    nsro[n] <= m_wdata[1]; nsenc[n] <= m_wdata[2]; nspi[n] <= m_wdata[3]; nsown[n] <= m_wdata[7:4]; nskey[n] <= m_wdata[11:8];
                    // evaluate against the values just written: owner/key/flags come from m_wdata, base/size from the table
                    if ((int'(m_wdata[7:4]) >= NT) || (nssize[n] == 64'h0))                       nsstat[n] <= 8'h08;
                    else if ({1'b0, nsbase[n]} + {1'b0, nssize[n]} > {1'b0, be_capacity_i})        nsstat[n] <= 8'h02;
                    else if (m_wdata[3] && !be_caps_i[BCAP_PI_NATIVE])                              nsstat[n] <= 8'h04;
                    else if (m_wdata[2] && (!HAS_XTS || int'(m_wdata[11:8]) >= NKEY))               nsstat[n] <= 8'h10;
                    else begin
                      if (ns_ov_w) nsstat[n] <= 8'h20;
                      else begin nsv[n] <= 1'b1; nsstat[n] <= 8'h01; end
                    end
                  end
                end
                1: if (!nsv[n]) nsbase[n][31:0]  <= m_wdata;
                2: if (!nsv[n]) nsbase[n][63:32] <= m_wdata;
                3: if (!nsv[n]) nssize[n][31:0]  <= m_wdata;
                4: if (!nsv[n]) nssize[n][63:32] <= m_wdata;
                default: ;
              endcase
            end
          end
        endcase
      end
      // latch the high half of a perf counter when the low half is read
      if (m_valid && !m_we && m_addr[11:2] == 10'h201) perf_hi_lat <= perf_i[int'(perf_sel[4:0])*64 + 32 +: 32];
      // trace pop (head entry consumed)
      if (tr_pop && tr_cnt != 0) tr_rp <= tr_rp + 1'b1;
      tr_cnt <= tr_cnt + ($bits(tr_cnt))'(tr_valid_i && trace_en_q && int'(tr_cnt) != TRACE_DEPTH) - ($bits(tr_cnt))'(tr_pop && tr_cnt != 0);
    end
  end
  wire unused_ok = &{1'b0, pf_force_q};
endmodule
`default_nettype wire
