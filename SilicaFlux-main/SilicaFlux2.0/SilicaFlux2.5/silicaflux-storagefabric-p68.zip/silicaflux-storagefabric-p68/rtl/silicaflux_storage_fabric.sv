// =============================================================================
// SilicaFlux StorageFabric (Project 68) :: silicaflux_storage_fabric -- PRIMARY RTL (cloud storage processing accelerator)
//
//   Cloud/VM storage request -> command validation -> queue scheduler -> protected DMA -> data integrity ->
//   storage backend -> completion.
//
//   sf_stor_core holds everything except the storage backend.  This top attaches exactly one backend, selected at
//   elaboration with BACKEND (all speak the same contract, docs/02_HOST_INTERFACE.md §7):
//       BE_SIMDEV (0)  simulated block device (sf_stor_be_simdev)           -- baseline, fully verified
//       BE_EXTERN (4)  the contract is exposed on the xbe_* ports            -- attach any adapter outside
//   (the SilicaFlux-STORE and host-software backend adapters and the VirtIO front-end adapter are in rtl/adapters/ and are
//    attached to the xbe_* / ext_* ports by the generated wrappers in tb/; an NVMe backend adapter is a documented FUTURE
//    backend that is NOT implemented; see docs/03_ARCHITECTURE.md §6 and docs/04_BACKENDS_VIRTIO_NVME.md.)
//
//   Interfaces: tenant MMIO (function id hardware-bound), privileged management MMIO, AXI4 master to tenant memory
//   (domain/asid sidebands for an independent firewall / IOMMU), power-fail warning, per-tenant interrupt.
// Classification: SYNTHESIZABLE except the simulated block device
// =============================================================================
`default_nettype none
module silicaflux_storage_fabric
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int NT         = 4,
  parameter int NS_N       = 8,
  parameter int NSLOT      = 8,
  parameter int MDTS       = 8,
  parameter int SQ_MAX     = 32,
  parameter int CQ_MAX     = 32,
  parameter int SQ_BATCH   = 4,
  parameter int PQ         = 4,
  parameter int AW         = 48,
  parameter int DOM_W      = 4,
  parameter int NUM_CH     = 2,
  parameter int BACKEND    = BE_SIMDEV,
  parameter int XBE_TYPE   = BE_EXTERN,          // backend type reported to software when BACKEND == BE_EXTERN
  parameter bit ENABLE_XTS = 1'b0,
  parameter bit HAS_VIRTIO = 1'b0,
  parameter int NKEY       = 4,
  parameter int EXT_TENANT = 3,
  parameter int TRACE_DEPTH = 64,
  // simulated block device
  parameter int SIM_CAP_BLOCKS     = 4096,
  parameter bit SIM_PI_NATIVE      = 1'b1,
  parameter bit SIM_VOLATILE_CACHE = 1'b1,
  parameter int SIM_CACHE_N        = 16
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // tenant MMIO
  input  wire logic                    tmmio_valid,
  input  wire logic                    tmmio_we,
  input  wire logic [3:0]              tmmio_fn,
  input  wire logic [11:0]             tmmio_addr,
  input  wire logic [31:0]             tmmio_wdata,
  output logic                         tmmio_rsp_valid,
  output logic [31:0]                  tmmio_rsp_rdata,
  output logic                         tmmio_rsp_err,
  // management MMIO
  input  wire logic                    mmio_valid,
  input  wire logic                    mmio_we,
  input  wire logic [11:0]             mmio_addr,
  input  wire logic [31:0]             mmio_wdata,
  output logic                         mmio_rsp_valid,
  output logic [31:0]                  mmio_rsp_rdata,
  output logic                         mmio_rsp_err,
  output logic [NT-1:0]                irq,
  input  wire logic                    pf_warn_i,
  output logic                         pf_quiesced_o,
  // AXI4 master (tenant memory)
  output logic                         m_ar_valid, input wire logic m_ar_ready,
  output logic [3:0]                   m_ar_id,
  output logic [AW-1:0]                m_ar_addr,
  output logic [7:0]                   m_ar_len,
  output logic [2:0]                   m_ar_size,
  output logic [1:0]                   m_ar_burst,
  output logic [3:0]                   m_ar_asid,
  output logic [DOM_W-1:0]             m_ar_domain,
  input  wire logic                    m_r_valid, output logic m_r_ready,
  input  wire logic [3:0]              m_r_id,
  input  wire logic [63:0]             m_r_data,
  input  wire logic [1:0]              m_r_resp,
  input  wire logic                    m_r_last,
  output logic                         m_aw_valid, input wire logic m_aw_ready,
  output logic [3:0]                   m_aw_id,
  output logic [AW-1:0]                m_aw_addr,
  output logic [7:0]                   m_aw_len,
  output logic [2:0]                   m_aw_size,
  output logic [1:0]                   m_aw_burst,
  output logic [3:0]                   m_aw_asid,
  output logic [DOM_W-1:0]             m_aw_domain,
  output logic                         m_w_valid, input wire logic m_w_ready,
  output logic [63:0]                  m_w_data,
  output logic [7:0]                   m_w_strb,
  output logic                         m_w_last,
  input  wire logic                    m_b_valid, output logic m_b_ready,
  input  wire logic [3:0]              m_b_id,
  input  wire logic [1:0]              m_b_resp,
  // optional extra command source (VirtIO adapter)
  input  wire logic                    ext_cmd_valid,
  output logic                         ext_cmd_ready,
  input  wire logic [7:0]              ext_op,
  input  wire logic [7:0]              ext_nsid,
  input  wire logic [63:0]             ext_lba,
  input  wire logic [15:0]             ext_nblk,
  input  wire logic [15:0]             ext_txn,
  output logic                         ext_cpl_valid,
  input  wire logic                    ext_cpl_ready,
  output logic [7:0]                   ext_cpl_status,
  output logic [7:0]                   ext_cpl_detail,
  output logic                         ext_cpl_durable,
  output logic [15:0]                  ext_cpl_nblk,
  output logic                         ext_in_req,
  input  wire logic                    ext_in_done,
  output logic                         ext_out_req,
  input  wire logic                    ext_out_done,
  output logic [12:0]                  ext_data_base,
  input  wire logic                    ext_lm_req,
  input  wire logic                    ext_lm_we,
  input  wire logic [12:0]             ext_lm_addr,
  input  wire logic [63:0]             ext_lm_wdata,
  output logic                         ext_lm_gnt,
  output logic                         ext_lm_rvalid,
  output logic [63:0]                  ext_lm_rdata,
  // simulated-block-device sideband (testbench; ignored by other backends)
  input  wire logic [15:0]             sim_rd_lat,
  input  wire logic [15:0]             sim_wr_lat,
  input  wire logic [15:0]             sim_fl_lat,
  input  wire logic [7:0]              sim_blk_lat,
  input  wire logic [7:0]              sim_jitter_mask,
  input  wire logic                    sim_inj_fail,
  input  wire logic                    sim_inj_hang,
  input  wire logic                    sim_inj_media_en,
  input  wire logic [63:0]             sim_inj_media_lba,
  input  wire logic                    sim_inj_corrupt,
  input  wire logic [63:0]             sim_inj_corrupt_lba,
  input  wire logic [9:0]              sim_inj_corrupt_bit,
  input  wire logic                    sim_inj_misdirect_en,
  input  wire logic [63:0]             sim_inj_misdirect_lba,
  input  wire logic                    sim_power_loss,
  input  wire logic [63:0]             sim_dbg_lba,
  input  wire logic [6:0]              sim_dbg_word,
  output logic [63:0]                  sim_dbg_data,
  output logic                         sim_dbg_unmapped,
  output logic [31:0]                  sim_dirty,
  // external backend (BACKEND == BE_EXTERN)
  output logic                         xbe_reset,
  input  wire logic                    xbe_ready,
  input  wire logic [63:0]             xbe_capacity,
  input  wire logic [7:0]              xbe_caps,
  output logic                         xbe_req_valid,
  input  wire logic                    xbe_req_ready,
  output logic [2:0]                   xbe_req_op,
  output logic [63:0]                  xbe_req_lba,
  output logic [15:0]                  xbe_req_nblk,
  output logic [3:0]                   xbe_req_tag,
  output logic                         xbe_wd_valid,
  input  wire logic                    xbe_wd_ready,
  output logic [63:0]                  xbe_wd_data,
  output logic                         xbe_wd_ulast,
  output logic [3:0]                   xbe_wd_tag,
  input  wire logic                    xbe_rd_valid,
  output logic                         xbe_rd_ready,
  input  wire logic [3:0]              xbe_rd_tag,
  input  wire logic [63:0]             xbe_rd_data,
  input  wire logic                    xbe_rd_ulast,
  input  wire logic [1:0]              xbe_rd_uflags,
  input  wire logic                    xbe_cpl_valid,
  output logic                         xbe_cpl_ready,
  input  wire logic [3:0]              xbe_cpl_tag,
  input  wire logic [3:0]              xbe_cpl_status,
  input  wire logic                    xbe_cpl_durable,
  input  wire logic [15:0]             xbe_cpl_nblk
);
  // ---- core <-> backend
  logic        cb_reset, cb_ready, cb_req_valid, cb_req_ready, cb_wd_valid, cb_wd_ready, cb_wd_ulast, cb_rd_valid, cb_rd_ready, cb_rd_ulast;
  logic        cb_cpl_valid, cb_cpl_ready, cb_cpl_durable;
  logic [63:0] cb_capacity, cb_req_lba, cb_wd_data, cb_rd_data;
  logic [7:0]  cb_caps;
  logic [2:0]  cb_req_op;
  logic [15:0] cb_req_nblk, cb_cpl_nblk;
  logic [3:0]  cb_req_tag, cb_wd_tag, cb_rd_tag, cb_cpl_tag, cb_cpl_status;
  logic [1:0]  cb_rd_uflags;

  sf_stor_core #(.NT(NT), .NS_N(NS_N), .NSLOT(NSLOT), .MDTS(MDTS), .SQ_MAX(SQ_MAX), .CQ_MAX(CQ_MAX), .SQ_BATCH(SQ_BATCH), .PQ(PQ), .AW(AW),
                 .DOM_W(DOM_W), .NUM_CH(NUM_CH), .BE_TYPE((BACKEND == BE_EXTERN) ? XBE_TYPE : BACKEND), .ENABLE_XTS(ENABLE_XTS), .HAS_VIRTIO(HAS_VIRTIO), .EXT_TENANT(EXT_TENANT), .NKEY(NKEY),
                 .TRACE_DEPTH(TRACE_DEPTH)) u_core (
    .clk, .rst_n,
    .tmmio_valid, .tmmio_we, .tmmio_fn, .tmmio_addr, .tmmio_wdata, .tmmio_rsp_valid, .tmmio_rsp_rdata, .tmmio_rsp_err,
    .mmio_valid, .mmio_we, .mmio_addr, .mmio_wdata, .mmio_rsp_valid, .mmio_rsp_rdata, .mmio_rsp_err, .irq,
    .pf_warn_i, .pf_quiesced_o,
    .m_ar_valid, .m_ar_ready, .m_ar_id, .m_ar_addr, .m_ar_len, .m_ar_size, .m_ar_burst, .m_ar_asid, .m_ar_domain,
    .m_r_valid, .m_r_ready, .m_r_id, .m_r_data, .m_r_resp, .m_r_last,
    .m_aw_valid, .m_aw_ready, .m_aw_id, .m_aw_addr, .m_aw_len, .m_aw_size, .m_aw_burst, .m_aw_asid, .m_aw_domain,
    .m_w_valid, .m_w_ready, .m_w_data, .m_w_strb, .m_w_last,
    .m_b_valid, .m_b_ready, .m_b_id, .m_b_resp,
    .be_ready(cb_ready), .be_capacity(cb_capacity), .be_caps(cb_caps), .be_reset(cb_reset),
    .be_req_valid(cb_req_valid), .be_req_ready(cb_req_ready), .be_req_op(cb_req_op), .be_req_lba(cb_req_lba), .be_req_nblk(cb_req_nblk),
    .be_req_tag(cb_req_tag),
    .be_wd_valid(cb_wd_valid), .be_wd_ready(cb_wd_ready), .be_wd_data(cb_wd_data), .be_wd_ulast(cb_wd_ulast), .be_wd_tag(cb_wd_tag),
    .be_rd_valid(cb_rd_valid), .be_rd_ready(cb_rd_ready), .be_rd_tag(cb_rd_tag), .be_rd_data(cb_rd_data), .be_rd_ulast(cb_rd_ulast),
    .be_rd_uflags(cb_rd_uflags),
    .be_cpl_valid(cb_cpl_valid), .be_cpl_ready(cb_cpl_ready), .be_cpl_tag(cb_cpl_tag), .be_cpl_status(cb_cpl_status),
    .be_cpl_durable(cb_cpl_durable), .be_cpl_nblk(cb_cpl_nblk),
    .ext_cmd_valid, .ext_cmd_ready, .ext_op, .ext_nsid, .ext_lba, .ext_nblk, .ext_txn, .ext_cpl_valid, .ext_cpl_ready, .ext_cpl_status,
    .ext_cpl_detail, .ext_cpl_durable, .ext_cpl_nblk, .ext_in_req, .ext_in_done, .ext_out_req, .ext_out_done, .ext_data_base,
    .ext_lm_req, .ext_lm_we, .ext_lm_addr, .ext_lm_wdata, .ext_lm_gnt, .ext_lm_rvalid, .ext_lm_rdata
  );

  if (BACKEND == BE_SIMDEV) begin : g_sim
    sf_stor_be_simdev #(.CAP_BLOCKS(SIM_CAP_BLOCKS), .PI_NATIVE(SIM_PI_NATIVE), .VOLATILE_CACHE(SIM_VOLATILE_CACHE), .CACHE_N(SIM_CACHE_N)) u_dev (
      .clk, .rst_n, .be_reset_i(cb_reset), .be_ready(cb_ready), .be_capacity(cb_capacity), .be_caps(cb_caps),
      .be_req_valid(cb_req_valid), .be_req_ready(cb_req_ready), .be_req_op(cb_req_op), .be_req_lba(cb_req_lba), .be_req_nblk(cb_req_nblk),
      .be_req_tag(cb_req_tag),
      .be_wd_valid(cb_wd_valid), .be_wd_ready(cb_wd_ready), .be_wd_data(cb_wd_data), .be_wd_ulast(cb_wd_ulast), .be_wd_tag(cb_wd_tag),
      .be_rd_valid(cb_rd_valid), .be_rd_ready(cb_rd_ready), .be_rd_tag(cb_rd_tag), .be_rd_data(cb_rd_data), .be_rd_ulast(cb_rd_ulast),
      .be_rd_uflags(cb_rd_uflags),
      .be_cpl_valid(cb_cpl_valid), .be_cpl_ready(cb_cpl_ready), .be_cpl_tag(cb_cpl_tag), .be_cpl_status(cb_cpl_status),
      .be_cpl_durable(cb_cpl_durable), .be_cpl_nblk(cb_cpl_nblk),
      .cfg_rd_lat(sim_rd_lat), .cfg_wr_lat(sim_wr_lat), .cfg_fl_lat(sim_fl_lat), .cfg_blk_lat(sim_blk_lat), .cfg_jitter_mask(sim_jitter_mask),
      .inj_fail(sim_inj_fail), .inj_hang(sim_inj_hang), .inj_media_en(sim_inj_media_en), .inj_media_lba(sim_inj_media_lba),
      .inj_corrupt(sim_inj_corrupt), .inj_corrupt_lba(sim_inj_corrupt_lba), .inj_corrupt_bit(sim_inj_corrupt_bit),
      .inj_misdirect_en(sim_inj_misdirect_en), .inj_misdirect_lba(sim_inj_misdirect_lba), .power_loss_i(sim_power_loss), .dbg_lba(sim_dbg_lba), .dbg_word(sim_dbg_word), .dbg_data(sim_dbg_data), .dbg_unmapped(sim_dbg_unmapped), .stat_dirty(sim_dirty)
    );
    assign xbe_reset = 1'b0; assign xbe_req_valid = 1'b0; assign xbe_req_op = '0; assign xbe_req_lba = '0; assign xbe_req_nblk = '0;
    assign xbe_req_tag = '0; assign xbe_wd_valid = 1'b0; assign xbe_wd_data = '0; assign xbe_wd_ulast = 1'b0; assign xbe_wd_tag = '0;
    assign xbe_rd_ready = 1'b0; assign xbe_cpl_ready = 1'b0;
  end else begin : g_ext
    assign xbe_reset = cb_reset;
    assign cb_ready = xbe_ready; assign cb_capacity = xbe_capacity; assign cb_caps = xbe_caps;
    assign xbe_req_valid = cb_req_valid; assign cb_req_ready = xbe_req_ready; assign xbe_req_op = cb_req_op; assign xbe_req_lba = cb_req_lba;
    assign xbe_req_nblk = cb_req_nblk; assign xbe_req_tag = cb_req_tag;
    assign xbe_wd_valid = cb_wd_valid; assign cb_wd_ready = xbe_wd_ready; assign xbe_wd_data = cb_wd_data; assign xbe_wd_ulast = cb_wd_ulast;
    assign xbe_wd_tag = cb_wd_tag;
    assign cb_rd_valid = xbe_rd_valid; assign xbe_rd_ready = cb_rd_ready; assign cb_rd_tag = xbe_rd_tag; assign cb_rd_data = xbe_rd_data;
    assign cb_rd_ulast = xbe_rd_ulast; assign cb_rd_uflags = xbe_rd_uflags;
    assign cb_cpl_valid = xbe_cpl_valid; assign xbe_cpl_ready = cb_cpl_ready; assign cb_cpl_tag = xbe_cpl_tag; assign cb_cpl_status = xbe_cpl_status;
    assign cb_cpl_durable = xbe_cpl_durable; assign cb_cpl_nblk = xbe_cpl_nblk;
    assign sim_dirty = '0; assign sim_dbg_data = '0; assign sim_dbg_unmapped = 1'b1;
  end
endmodule
`default_nettype wire
