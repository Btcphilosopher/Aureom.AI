// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_dmaseq -- protected-DMA task sequencer around the CloudDMA (P64) engine
//
//   Requesters (descriptor-fetch / completion-post per tenant, and one per command slot) post a *task*
//        { direction, domain (tenant), host IOVA, local-memory byte address, length }
//   The sequencer builds a one-element CloudDMA descriptor in the local memory, submits it on a free CloudDMA channel
//   with the requester's HARDWARE-bound domain, and returns {ok, CloudDMA err/fault code} when the engine reports
//   completion (after the destination writes were acknowledged).
//
//   Protection: every host access made on behalf of a task is checked by CloudDMA's permission checker against the
//   domain's windows (programmed only through pt_*, i.e. by the management plane).  The domain is never taken from
//   anything a tenant can write.  Channel 0 is reserved for control-plane tasks (SQ fetch, CQ post) when NUM_CH > 1,
//   so data transfers can not delay descriptor fetch or completion posting.
//
//   Reuse: silicaflux_cloud_dma (Project 64) is instantiated UNMODIFIED from third_party/p64-clouddma.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_dmaseq
  import silicaflux_storage_fabric_pkg::*;
#(
  parameter int NT         = 4,
  parameter int NSLOT      = 8,
  parameter int NUM_CH     = 2,
  parameter int AW         = 48,
  parameter int DOM_W      = 4,
  parameter int DW         = 64,
  parameter int MAXB       = 32,       // CloudDMA burst, beats
  parameter int RD_OUT     = 4,
  parameter int WR_OUT     = 4,
  parameter int BUF_BYTES  = 2048,
  parameter int WORDS_LOG2 = 13,
  parameter int LMEM_BYTES = 65536,    // size of the local-memory window granted to every domain
  localparam int NCTRL = 2 * NT,
  localparam int NREQ  = 2 * NT + NSLOT,
  localparam int MXO   = (RD_OUT > WR_OUT) ? RD_OUT : WR_OUT,
  localparam int SWW   = (MXO > 1) ? $clog2(MXO) : 1,
  localparam int CHW   = (NUM_CH > 1) ? $clog2(NUM_CH) : 1,
  localparam int ID_W  = CHW + SWW + 1,
  localparam int RQW   = (NREQ > 1) ? $clog2(NREQ) : 1
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  input  wire logic [31:0]            cfg_timeout,        // CloudDMA no-progress timeout (cycles, 0 = off)
  // ---- task requesters
  input  wire logic [NREQ-1:0]        req_valid,
  output logic [NREQ-1:0]             req_gnt,            // one-cycle pulse: the task was accepted
  input  wire logic [NREQ-1:0]        req_dir,            // 0: host -> local memory   1: local memory -> host
  input  wire logic [NREQ*DOM_W-1:0]  req_dom,
  input  wire logic [NREQ*AW-1:0]     req_host,
  input  wire logic [NREQ*16-1:0]     req_lm,
  input  wire logic [NREQ*24-1:0]     req_len,
  output logic [NREQ-1:0]             rsp_valid,          // one-cycle pulse per finished task
  output logic [NREQ-1:0]             rsp_ok,
  output logic [NREQ*8-1:0]           rsp_err,
  output logic [NREQ*4-1:0]           rsp_fault,
  // ---- local memory client (descriptor writes)
  output logic                        lm_req,
  output logic [WORDS_LOG2-1:0]       lm_addr,
  output logic [63:0]                 lm_wdata,
  input  wire logic                   lm_gnt,
  // ---- management-plane DMA window programming
  input  wire logic                   pt_wr,
  input  wire logic [3:0]             pt_idx,
  input  wire logic                   pt_valid,
  input  wire logic [DOM_W-1:0]       pt_dom,
  input  wire logic [AW-1:0]          pt_base,
  input  wire logic [AW:0]            pt_size,
  input  wire logic [1:0]             pt_perm,
  output logic                        pt_rej,
  output logic                        init_done,
  // ---- AXI4 master (to sf_stor_axi_xbar)
  output logic                        m_ar_valid, input wire logic m_ar_ready,
  output logic [ID_W-1:0]             m_ar_id,
  output logic [AW-1:0]               m_ar_addr,
  output logic [7:0]                  m_ar_len,
  output logic [2:0]                  m_ar_size,
  output logic [1:0]                  m_ar_burst,
  output logic [3:0]                  m_ar_asid,
  output logic [DOM_W-1:0]            m_ar_domain,
  input  wire logic                   m_r_valid, output logic m_r_ready,
  input  wire logic [ID_W-1:0]        m_r_id,
  input  wire logic [DW-1:0]          m_r_data,
  input  wire logic [1:0]             m_r_resp,
  input  wire logic                   m_r_last,
  output logic                        m_aw_valid, input wire logic m_aw_ready,
  output logic [ID_W-1:0]             m_aw_id,
  output logic [AW-1:0]               m_aw_addr,
  output logic [7:0]                  m_aw_len,
  output logic [2:0]                  m_aw_size,
  output logic [1:0]                  m_aw_burst,
  output logic [3:0]                  m_aw_asid,
  output logic [DOM_W-1:0]            m_aw_domain,
  output logic                        m_w_valid, input wire logic m_w_ready,
  output logic [DW-1:0]               m_w_data,
  output logic [DW/8-1:0]             m_w_strb,
  output logic                        m_w_last,
  input  wire logic                   m_b_valid, output logic m_b_ready,
  input  wire logic [ID_W-1:0]        m_b_id,
  input  wire logic [1:0]             m_b_resp,
  // ---- status / statistics
  output logic [NUM_CH-1:0]           ch_busy,
  output logic                        viol_evt,
  output logic                        stat_in_active,     // >=1 host->local task in flight
  output logic                        stat_out_active,
  output logic [31:0]                 stat_bytes_pulse    // bytes of a task finishing OK (valid with rsp pulse; else 0)
);
  // ------------------------------------------------------------------ CloudDMA
  logic        csr_valid, csr_ready, csr_write, csr_rsp_valid, csr_rsp_err, irq_unused;
  logic [11:0] csr_addr;
  logic [31:0] csr_wdata, csr_rdata;
  logic [NUM_CH-1:0]        c_valid, c_ready, d_valid, d_ready;
  logic [NUM_CH*64-1:0]     c_head;
  logic [NUM_CH*DOM_W-1:0]  c_dom;
  logic [NUM_CH*4-1:0]      c_asid;
  logic [NUM_CH*16-1:0]     d_txn;
  logic [NUM_CH*4-1:0]      d_status;
  logic [NUM_CH*8-1:0]      d_err;
  logic [NUM_CH*4-1:0]      d_fault;
  logic [NUM_CH*DOM_W-1:0]  d_domain;
  logic [NUM_CH*32-1:0]     d_bytes, d_crc;
  logic [NUM_CH-1:0]        d_viol;
  logic                     p_en, p_valid, p_rej;
  logic [3:0]               p_idx;
  logic [DOM_W-1:0]         p_dom;
  logic [3:0]               p_asid;
  logic [AW-1:0]            p_base, p_pa;
  logic [AW:0]              p_size;
  logic [1:0]               p_perm;

  logic io_rv, io_wr, io_rr; logic [DOM_W-1:0] io_dom; logic [3:0] io_asid; logic [AW-1:0] io_addr; logic [15:0] io_bytes;
  logic [$clog2(4*NUM_CH > 1 ? 4*NUM_CH : 2)-1:0] io_id;
  silicaflux_cloud_dma #(
    .NUM_CH(NUM_CH), .DW(DW), .AW(AW), .DOM_W(DOM_W), .MAX_BURST_BEATS(MAXB), .RD_OUT(RD_OUT), .WR_OUT(WR_OUT),
    .BUF_BYTES(BUF_BYTES), .ELQ(2), .CMDQ(2), .MAX_CHAIN(4), .REORDER_OK(1'b1), .CRC_ON(1'b0), .USE_EXT_IOMMU(1'b0),
    .PERM_ENTRIES(16), .PERM_LAT(1), .TRACE_DEPTH(8), .TIMEOUT_DEF(0)
  ) u_dma (
    .clk, .rst_n,
    .csr_req_valid(csr_valid), .csr_req_ready(csr_ready), .csr_req_write(csr_write), .csr_req_addr(csr_addr),
    .csr_req_wdata(csr_wdata), .csr_rsp_valid(csr_rsp_valid), .csr_rsp_rdata(csr_rdata), .csr_rsp_err(csr_rsp_err),
    .irq(irq_unused),
    .cmd_valid(c_valid), .cmd_ready(c_ready), .cmd_head(c_head), .cmd_domain(c_dom), .cmd_asid(c_asid),
    .done_valid(d_valid), .done_ready(d_ready), .done_txn(d_txn), .done_status(d_status), .done_err(d_err),
    .done_fault(d_fault), .done_domain(d_domain), .done_bytes(d_bytes), .done_crc(d_crc), .viol_evt(d_viol),
    .m_ar_valid, .m_ar_ready, .m_ar_id, .m_ar_addr, .m_ar_len, .m_ar_size, .m_ar_burst, .m_ar_asid, .m_ar_domain,
    .m_r_valid, .m_r_ready, .m_r_id, .m_r_data, .m_r_resp, .m_r_last,
    .m_aw_valid, .m_aw_ready, .m_aw_id, .m_aw_addr, .m_aw_len, .m_aw_size, .m_aw_burst, .m_aw_asid, .m_aw_domain,
    .m_w_valid, .m_w_ready, .m_w_data, .m_w_strb, .m_w_last,
    .m_b_valid, .m_b_ready, .m_b_id, .m_b_resp,
    .iommu_req_valid(io_rv), .iommu_req_ready(1'b0), .iommu_req_domain(io_dom), .iommu_req_asid(io_asid), .iommu_req_write(io_wr),
    .iommu_req_addr(io_addr), .iommu_req_bytes(io_bytes), .iommu_req_id(io_id),
    .iommu_rsp_valid(1'b0), .iommu_rsp_ready(io_rr), .iommu_rsp_id('0), .iommu_rsp_ok(1'b0), .iommu_rsp_fault('0),
    .iommu_rsp_pa('0),
    .ptbl_en(p_en), .ptbl_idx(p_idx), .ptbl_valid(p_valid), .ptbl_domain(p_dom), .ptbl_asid(p_asid),
    .ptbl_base(p_base), .ptbl_size(p_size), .ptbl_pa(p_pa), .ptbl_perm(p_perm), .ptbl_rej(p_rej)
  );
  wire unused_ok = &{1'b0, io_rv, io_wr, io_rr, io_dom, io_asid, io_addr, io_bytes, io_id, csr_ready, csr_rsp_valid, csr_rsp_err, csr_rdata, irq_unused, d_txn, d_domain, d_crc};

  // ------------------------------------------------------------------ bring-up: window table, timeout, enable
  typedef enum logic [2:0] {I_PT, I_TO, I_EN, I_DONE} init_t;
  init_t        ist;
  logic [3:0]   i_idx;
  logic [31:0]  to_sent;
  logic         to_dirty;
  assign init_done = (ist == I_DONE);

  always_comb begin
    p_en = 1'b0; p_idx = '0; p_valid = 1'b0; p_dom = '0; p_asid = '0; p_base = '0; p_size = '0; p_pa = '0; p_perm = '0;
    csr_valid = 1'b0; csr_write = 1'b1; csr_addr = '0; csr_wdata = '0;
    case (ist)
      I_PT: begin  // one entry per tenant domain: the whole local memory (asid 1), read+write, identity mapped
        p_en = 1'b1; p_idx = i_idx; p_valid = 1'b1; p_dom = DOM_W'(i_idx); p_asid = ASID_LMEM;
        p_base = '0; p_size = (AW+1)'(LMEM_BYTES); p_pa = '0; p_perm = 2'b11;
      end
      I_TO: begin csr_valid = 1'b1; csr_addr = 12'h020; csr_wdata = cfg_timeout; end
      I_EN: begin csr_valid = 1'b1; csr_addr = 12'h010; csr_wdata = 32'h1; end
      default: begin
        p_en = pt_wr; p_idx = pt_idx; p_valid = pt_valid; p_dom = pt_dom; p_asid = ASID_HOST;
        p_base = pt_base; p_size = pt_size; p_pa = pt_base; p_perm = pt_perm;
        if (to_dirty) begin csr_valid = 1'b1; csr_addr = 12'h020; csr_wdata = cfg_timeout; end
      end
    endcase
  end
  assign pt_rej = p_rej && (ist == I_DONE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin ist <= I_PT; i_idx <= '0; to_sent <= '0; to_dirty <= 1'b0; end
    else begin
      case (ist)
        I_PT: begin
          if (int'(i_idx) == NT - 1) begin ist <= I_TO; i_idx <= '0; end else i_idx <= i_idx + 4'd1;
        end
        I_TO: begin to_sent <= cfg_timeout; ist <= I_EN; end
        I_EN: ist <= I_DONE;
        default: begin
          if (to_dirty) begin to_sent <= cfg_timeout; to_dirty <= 1'b0; end
          else if (cfg_timeout != to_sent) to_dirty <= 1'b1;
        end
      endcase
    end
  end

  // ------------------------------------------------------------------ task bookkeeping per channel
  logic [NUM_CH-1:0]      ch_cmd_v;
  logic [RQW-1:0]         ch_req   [NUM_CH];
  logic [23:0]            ch_len   [NUM_CH];
  logic                   ch_dir   [NUM_CH];
  logic [DOM_W-1:0]       ch_dom_q [NUM_CH];
  assign ch_busy = ch_cmd_v | c_busy_q;
  logic [NUM_CH-1:0] c_busy_q;       // task owned by the channel (descriptor written ... done)

  // descriptor writer (one at a time)
  logic             dw_busy;
  logic [3:0]       dw_idx;
  logic [3:0]       dw_ch;
  logic [RQW-1:0]   dw_rq;
  logic [DOM_W-1:0] dw_dom;
  logic             dw_dir;
  logic [AW-1:0]    dw_host;
  logic [15:0]      dw_lm;
  logic [23:0]      dw_len;

  // ---- arbitration: pick a requester and a channel
  logic [RQW-1:0] ptr_ctrl, ptr_data;
  logic           prio_ctrl;
  logic [RQW-1:0] pick_ctrl, pick_data;
  logic           have_ctrl, have_data;
  logic [NREQ-1:0] mask_ctrl, mask_data;
  int             free_data_ch;
  logic           free_ctrl_ch;
  always_comb begin
    mask_ctrl = '0; mask_data = '0;
    for (int r = 0; r < NREQ; r++) begin
      if (r < NCTRL) mask_ctrl[r] = req_valid[r]; else mask_data[r] = req_valid[r];
    end
    have_ctrl = 1'b0; pick_ctrl = '0; have_data = 1'b0; pick_data = '0;
    for (int k = 0; k < NREQ; k++) begin
      int r;
      r = (int'(ptr_ctrl) + k) % NREQ;
      if (!have_ctrl && mask_ctrl[r]) begin have_ctrl = 1'b1; pick_ctrl = RQW'(r); end
      r = (int'(ptr_data) + k) % NREQ;
      if (!have_data && mask_data[r]) begin have_data = 1'b1; pick_data = RQW'(r); end
    end
    free_ctrl_ch = !ch_busy[0];
    free_data_ch = -1;
    for (int c = NUM_CH - 1; c >= ((NUM_CH > 1) ? 1 : 0); c--) if (!ch_busy[c]) free_data_ch = c;
  end
  wire can_ctrl = have_ctrl && free_ctrl_ch;
  wire can_data = have_data && (free_data_ch >= 0) && !((NUM_CH == 1) && can_ctrl && prio_ctrl);
  wire start_ok = init_done && !dw_busy;
  wire do_ctrl  = start_ok && can_ctrl && (!can_data || prio_ctrl || NUM_CH > 1);
  wire do_data  = start_ok && can_data && !do_ctrl;

  logic [NREQ-1:0] gnt_vec;
  assign req_gnt = gnt_vec;
  always_comb begin
    gnt_vec = '0;
    if (do_ctrl) gnt_vec[pick_ctrl] = 1'b1;
    if (do_data) gnt_vec[pick_data] = 1'b1;
  end

  // ---- per-channel signal registers
  logic [NUM_CH*64-1:0]    head_flat;
  always_comb begin
    for (int c = 0; c < NUM_CH; c++) head_flat[c*64 +: 64] = 64'(LM_DESC_OFF + 64 * c);
  end
  assign c_head  = head_flat;
  assign c_valid = ch_cmd_v;
  always_comb begin
    for (int c = 0; c < NUM_CH; c++) begin
      c_dom[c*DOM_W +: DOM_W] = ch_dom_q[c];
      c_asid[c*4 +: 4]        = ASID_LMEM;
    end
  end

  // ---- descriptor words (docs: P64 docs/02_DESCRIPTOR_FORMAT.md)
  logic [63:0] dword [8];
  wire  [3:0]  src_asid = dw_dir ? ASID_LMEM : ASID_HOST;
  wire  [3:0]  dst_asid = dw_dir ? ASID_HOST : ASID_LMEM;
  always_comb begin
    for (int i = 0; i < 8; i++) dword[i] = 64'h0;
    dword[0] = {16'(dw_dom), 16'(dw_rq), 16'h0005, 8'h00, SFS_DESC_VERSION};  // {W1: DOMAIN,TXN | W0: FLAGS=HEAD|LAST, OP=COPY, VER=1}
    dword[1] = {32'(dw_len), 24'h0, dst_asid, src_asid};                      // {W3: LENGTH | W2: DST_ASID,SRC_ASID}
    dword[2] = dw_dir ? 64'(dw_lm)   : 64'(dw_host);                          // SRC_ADDR (W4,W5)
    dword[3] = dw_dir ? 64'(dw_host) : 64'(dw_lm);                            // DST_ADDR (W6,W7)
  end
  assign lm_req   = dw_busy && (dw_idx < 4'd8);
  assign lm_addr  = WORDS_LOG2'((LM_DESC_OFF / 8) + 8 * int'(dw_ch) + int'(dw_idx));
  assign lm_wdata = dword[dw_idx[2:0]];

  // ---- responses
  logic [NREQ-1:0]   rsp_v;
  logic [NREQ-1:0]   rsp_o;
  logic [NREQ*8-1:0] rsp_e;
  logic [NREQ*4-1:0] rsp_f;
  logic [31:0]       bytes_pulse;
  assign rsp_valid = rsp_v;
  assign rsp_ok    = rsp_o;
  assign rsp_err   = rsp_e;
  assign rsp_fault = rsp_f;
  assign stat_bytes_pulse = bytes_pulse;
  assign d_ready = '1;
  assign viol_evt = |d_viol;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ch_cmd_v <= '0; c_busy_q <= '0; dw_busy <= 1'b0; dw_idx <= '0; dw_ch <= '0; dw_rq <= '0; dw_dom <= '0;
      dw_dir <= 1'b0; dw_host <= '0; dw_lm <= '0; dw_len <= '0;
      ptr_ctrl <= '0; ptr_data <= '0; prio_ctrl <= 1'b0;
      rsp_v <= '0; rsp_o <= '0; rsp_e <= '0; rsp_f <= '0; bytes_pulse <= '0;
      for (int c = 0; c < NUM_CH; c++) begin ch_req[c] <= '0; ch_len[c] <= '0; ch_dir[c] <= 1'b0; ch_dom_q[c] <= '0; end
    end else begin
      rsp_v <= '0; bytes_pulse <= '0;
      // accept a task
      if (do_ctrl || do_data) begin
        automatic int      ch  = do_ctrl ? 0 : free_data_ch;
        automatic int      rq  = do_ctrl ? int'(pick_ctrl) : int'(pick_data);
        dw_busy <= 1'b1; dw_idx <= '0; dw_ch <= 4'(ch); dw_rq <= RQW'(rq);
        dw_dom  <= req_dom[rq*DOM_W +: DOM_W]; dw_dir <= req_dir[rq]; dw_host <= req_host[rq*AW +: AW];
        dw_lm   <= req_lm[rq*16 +: 16];        dw_len <= req_len[rq*24 +: 24];
        c_busy_q[ch] <= 1'b1;
        ch_req[ch] <= RQW'(rq); ch_len[ch] <= req_len[rq*24 +: 24]; ch_dir[ch] <= req_dir[rq];
        ch_dom_q[ch] <= req_dom[rq*DOM_W +: DOM_W];
        if (do_ctrl) begin ptr_ctrl <= RQW'((int'(pick_ctrl) + 1) % NREQ); prio_ctrl <= 1'b0; end
        else         begin ptr_data <= RQW'((int'(pick_data) + 1) % NREQ); prio_ctrl <= 1'b1; end
      end
      // descriptor words
      if (dw_busy) begin
        if (dw_idx < 4'd8) begin
          if (lm_gnt) dw_idx <= dw_idx + 4'd1;
        end else begin
          for (int c = 0; c < NUM_CH; c++) if (int'(dw_ch) == c) ch_cmd_v[c] <= 1'b1;
          dw_busy <= 1'b0;
        end
      end
      // CloudDMA accepted the command
      for (int c = 0; c < NUM_CH; c++) begin
        if (ch_cmd_v[c] && c_ready[c]) ch_cmd_v[c] <= 1'b0;
        if (d_valid[c]) begin
          automatic int rq = int'(ch_req[c]);
          rsp_v[rq] <= 1'b1;
          rsp_o[rq] <= (d_status[c*4 +: 4] == 4'd0) && (d_bytes[c*32 +: 32] == {8'h0, ch_len[c]});
          rsp_e[rq*8 +: 8] <= d_err[c*8 +: 8];
          rsp_f[rq*4 +: 4] <= d_fault[c*4 +: 4];
          c_busy_q[c] <= 1'b0;
          if (d_status[c*4 +: 4] == 4'd0) bytes_pulse <= bytes_pulse + {8'h0, ch_len[c]};
        end
      end
    end
  end

  // ---- activity statistics
  always_comb begin
    stat_in_active = 1'b0; stat_out_active = 1'b0;
    for (int c = 0; c < NUM_CH; c++) if (c_busy_q[c]) begin
      if (ch_dir[c]) stat_out_active = 1'b1; else stat_in_active = 1'b1;
    end
  end
endmodule
`default_nettype wire
