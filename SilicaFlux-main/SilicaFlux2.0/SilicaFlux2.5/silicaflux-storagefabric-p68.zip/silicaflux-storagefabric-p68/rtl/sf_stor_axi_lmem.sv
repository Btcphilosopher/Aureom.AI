// =============================================================================
// SilicaFlux StorageFabric :: sf_stor_axi_lmem -- AXI4 slave in front of the local staging memory (port A)
//   64-bit data, INCR bursts only, full-width beats (size = 3).  Anything else, or an address outside the memory,
//   is answered with SLVERR (the beats are consumed / produced so the master stays in protocol).
//   Reads and writes are served alternately on the single memory port, up to one beat per cycle.
//   Responses are in order (one read burst and one write burst at a time).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stor_axi_lmem #(
  parameter int AW         = 48,
  parameter int ID_W       = 4,
  parameter int WORDS_LOG2 = 13
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 s_ar_valid,
  output logic                      s_ar_ready,
  input  wire logic [ID_W-1:0]      s_ar_id,
  input  wire logic [AW-1:0]        s_ar_addr,
  input  wire logic [7:0]           s_ar_len,
  input  wire logic [2:0]           s_ar_size,
  input  wire logic [1:0]           s_ar_burst,
  output logic                      s_r_valid,
  input  wire logic                 s_r_ready,
  output logic [ID_W-1:0]           s_r_id,
  output logic [63:0]               s_r_data,
  output logic [1:0]                s_r_resp,
  output logic                      s_r_last,
  input  wire logic                 s_aw_valid,
  output logic                      s_aw_ready,
  input  wire logic [ID_W-1:0]      s_aw_id,
  input  wire logic [AW-1:0]        s_aw_addr,
  input  wire logic [7:0]           s_aw_len,
  input  wire logic [2:0]           s_aw_size,
  input  wire logic [1:0]           s_aw_burst,
  input  wire logic                 s_w_valid,
  output logic                      s_w_ready,
  input  wire logic [63:0]          s_w_data,
  input  wire logic [7:0]           s_w_strb,
  input  wire logic                 s_w_last,
  output logic                      s_b_valid,
  input  wire logic                 s_b_ready,
  output logic [ID_W-1:0]           s_b_id,
  output logic [1:0]                s_b_resp,
  // memory port A
  output logic                      a_en,
  output logic                      a_we,
  output logic [WORDS_LOG2-1:0]     a_addr,
  output logic [63:0]               a_wdata,
  output logic [7:0]                a_be,
  input  wire logic [63:0]          a_rdata
);
  localparam int BYTE_AW = WORDS_LOG2 + 3;

  // ------------------------------------------------------------------ read side
  logic              rd_busy;
  logic [ID_W-1:0]   rd_id;
  logic [WORDS_LOG2-1:0] rd_wa;
  logic [8:0]        rd_left;
  logic              rd_bad;
  logic              rd_infl, rd_infl_last, rd_infl_bad;     // a memory read was issued last cycle
  logic [ID_W-1:0]   rd_infl_id;
  // 2-entry response FIFO
  logic [63:0]       rf_data [2];
  logic              rf_last [2];
  logic              rf_bad  [2];
  logic [ID_W-1:0]   rf_id   [2];
  logic [1:0]        rf_cnt;
  logic              rf_rp, rf_wp;

  wire rd_ar_ok  = (s_ar_burst == 2'b01) && (s_ar_size == 3'd3) && ((s_ar_addr >> BYTE_AW) == '0) &&
                   (s_ar_addr[2:0] == 3'd0);
  assign s_ar_ready = !rd_busy;

  wire rd_credit = (({1'b0, rf_cnt} + {2'b0, rd_infl}) < 3'd2);
  wire rd_want   = rd_busy && (rd_left != 9'd0) && rd_credit;
  logic wr_want;
  logic prio_wr;
  wire grant_rd = rd_want && !(wr_want && prio_wr);
  wire grant_wr = wr_want && !(rd_want && !prio_wr);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_busy <= 1'b0; rd_left <= '0; rd_wa <= '0; rd_id <= '0; rd_bad <= 1'b0;
      rd_infl <= 1'b0; rd_infl_last <= 1'b0; rd_infl_bad <= 1'b0; rd_infl_id <= '0;
      rf_cnt <= '0; rf_rp <= 1'b0; rf_wp <= 1'b0; prio_wr <= 1'b0;
    end else begin
      prio_wr <= (rd_want && wr_want) ? !prio_wr : prio_wr;
      if (s_ar_valid && s_ar_ready) begin
        rd_busy <= 1'b1; rd_id <= s_ar_id; rd_wa <= s_ar_addr[BYTE_AW-1:3];
        rd_left <= {1'b0, s_ar_len} + 9'd1; rd_bad <= !rd_ar_ok;
      end
      // issue
      rd_infl <= grant_rd;
      if (grant_rd) begin
        rd_infl_last <= (rd_left == 9'd1); rd_infl_bad <= rd_bad; rd_infl_id <= rd_id;
        rd_left <= rd_left - 9'd1; rd_wa <= rd_wa + 1'b1;
        if (rd_left == 9'd1) rd_busy <= 1'b0;
      end
      // push the beat that returned
      if (rd_infl) begin
        rf_data[rf_wp] <= a_rdata; rf_last[rf_wp] <= rd_infl_last; rf_bad[rf_wp] <= rd_infl_bad; rf_id[rf_wp] <= rd_infl_id;
        rf_wp <= !rf_wp;
      end
      if (s_r_valid && s_r_ready) rf_rp <= !rf_rp;
      rf_cnt <= rf_cnt + {1'b0, rd_infl} - {1'b0, (s_r_valid && s_r_ready)};
    end
  end
  assign s_r_valid = (rf_cnt != 2'd0);
  assign s_r_data  = rf_bad[rf_rp] ? 64'h0 : rf_data[rf_rp];
  assign s_r_last  = rf_last[rf_rp];
  assign s_r_id    = rf_id[rf_rp];
  assign s_r_resp  = rf_bad[rf_rp] ? 2'b10 : 2'b00;

  // ------------------------------------------------------------------ write side
  logic              wr_busy, wr_done;
  logic [ID_W-1:0]   wr_id;
  logic [WORDS_LOG2-1:0] wr_wa;
  logic              wr_bad;
  assign s_aw_ready = !wr_busy && !wr_done;
  wire wr_aw_ok = (s_aw_burst == 2'b01) && (s_aw_size == 3'd3) && ((s_aw_addr >> BYTE_AW) == '0) &&
                  (s_aw_addr[2:0] == 3'd0);
  assign wr_want   = wr_busy && s_w_valid;
  assign s_w_ready = wr_busy && (wr_bad || grant_wr);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wr_busy <= 1'b0; wr_done <= 1'b0; wr_id <= '0; wr_wa <= '0; wr_bad <= 1'b0;
    end else begin
      if (s_aw_valid && s_aw_ready) begin
        wr_busy <= 1'b1; wr_id <= s_aw_id; wr_wa <= s_aw_addr[BYTE_AW-1:3]; wr_bad <= !wr_aw_ok;
      end
      if (s_w_valid && s_w_ready) begin
        wr_wa <= wr_wa + 1'b1;
        if (s_w_last) begin wr_busy <= 1'b0; wr_done <= 1'b1; end
      end
      if (s_b_valid && s_b_ready) wr_done <= 1'b0;
    end
  end
  assign s_b_valid = wr_done;
  assign s_b_id    = wr_id;
  assign s_b_resp  = wr_bad ? 2'b10 : 2'b00;

  // ------------------------------------------------------------------ port A
  assign a_en    = grant_rd || (grant_wr && s_w_valid && !wr_bad);
  assign a_we    = grant_wr && !grant_rd;
  assign a_addr  = grant_rd ? rd_wa : wr_wa;
  assign a_wdata = s_w_data;
  assign a_be    = s_w_strb;
endmodule
`default_nettype wire
