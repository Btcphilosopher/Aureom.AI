// =============================================================================
// SilicaFlux StorageFabric (Project 68) :: silicaflux_storage_fabric_pkg
//
// Storage command package: opcodes, flags, status / detail codes, descriptor and completion word layouts,
// backend contract codes, local-memory map helpers, performance-counter ids.
// Single source of truth for the RTL; normative text is docs/02_HOST_INTERFACE.md (ABI 1.0).
// Classification: SYNTHESIZABLE (constants and pure functions only)
// =============================================================================
`default_nettype none

package silicaflux_storage_fabric_pkg;

  // ---------------------------------------------------------------- versions / ids
  localparam logic [7:0]  SFS_DESC_VERSION  = 8'd1;
  localparam logic [31:0] SFS_ABI_VERSION   = 32'h0001_0000;
  localparam logic [31:0] SFS_ID_TENANT     = 32'h5346_5354;   // "SFST"
  localparam logic [31:0] SFS_ID_MGMT       = 32'h5346_5347;   // "SFSG"
  localparam int          SFS_BLK_SHIFT     = 9;               // 512-byte logical block
  localparam int          SFS_BLK_BYTES     = 512;
  localparam int          SFS_PI_BYTES      = 16;
  localparam int          SFS_DESC_BYTES    = 64;
  localparam int          SFS_CQE_BYTES     = 32;
  localparam int          SFS_DISCARD_MAX   = 65535;

  // ---------------------------------------------------------------- opcodes
  localparam logic [7:0] OP_WRITE        = 8'h01;
  localparam logic [7:0] OP_READ         = 8'h02;
  localparam logic [7:0] OP_FLUSH        = 8'h03;
  localparam logic [7:0] OP_GET_CAPACITY = 8'h04;
  localparam logic [7:0] OP_DISCARD      = 8'h05;

  // ---------------------------------------------------------------- descriptor flags (W0[31:16])
  localparam int FLG_FUA  = 0;
  localparam int FLG_HCRC = 1;
  localparam int FLG_RCRC = 2;

  // ---------------------------------------------------------------- completion status / detail
  localparam logic [7:0] ST_SUCCESS         = 8'h00;
  localparam logic [7:0] ST_INVALID_OPCODE  = 8'h01;
  localparam logic [7:0] ST_INVALID_FIELD   = 8'h02;
  localparam logic [7:0] ST_INVALID_NS      = 8'h03;
  localparam logic [7:0] ST_LBA_RANGE       = 8'h04;
  localparam logic [7:0] ST_LEN_ERROR       = 8'h05;
  localparam logic [7:0] ST_TENANT_MISMATCH = 8'h06;
  localparam logic [7:0] ST_NS_READONLY     = 8'h07;
  localparam logic [7:0] ST_DMA_FAULT       = 8'h08;
  localparam logic [7:0] ST_DMA_ERROR       = 8'h09;
  localparam logic [7:0] ST_DATA_CRC        = 8'h0A;
  localparam logic [7:0] ST_INTEGRITY       = 8'h0B;
  localparam logic [7:0] ST_MEDIA_ERROR     = 8'h0C;
  localparam logic [7:0] ST_BACKEND_ERROR   = 8'h0D;
  localparam logic [7:0] ST_TIMEOUT         = 8'h0E;
  localparam logic [7:0] ST_ABORTED_RESET   = 8'h0F;
  localparam logic [7:0] ST_ABORTED_POWER   = 8'h10;
  localparam logic [7:0] ST_UNSUPPORTED     = 8'h11;
  localparam logic [7:0] ST_CRYPTO_ERROR    = 8'h12;
  localparam logic [7:0] ST_INTERNAL        = 8'h13;

  // INVALID_FIELD details
  localparam logic [7:0] DT_VERSION    = 8'd1;
  localparam logic [7:0] DT_RESERVED   = 8'd2;
  localparam logic [7:0] DT_FLAGS      = 8'd3;
  localparam logic [7:0] DT_ADDR_ALIGN = 8'd4;
  // LEN_ERROR details
  localparam logic [7:0] DT_LEN_ZERO     = 8'd1;
  localparam logic [7:0] DT_LEN_TOO_LARGE= 8'd2;
  localparam logic [7:0] DT_LEN_MISMATCH = 8'd3;
  localparam logic [7:0] DT_LEN_NOT_ZERO = 8'd4;
  // INTEGRITY details
  localparam logic [7:0] DT_PI_GUARD   = 8'd1;
  localparam logic [7:0] DT_PI_LBA_TAG = 8'd2;
  localparam logic [7:0] DT_PI_NS_TAG  = 8'd3;
  localparam logic [7:0] DT_PI_FORMAT  = 8'd4;
  // TIMEOUT details
  localparam logic [7:0] DT_TO_BACKEND = 8'd1;
  localparam logic [7:0] DT_TO_DMA     = 8'd2;
  // CRYPTO details
  localparam logic [7:0] DT_KEY_NOT_READY = 8'd1;
  localparam logic [7:0] DT_CRYPTO_ENGINE = 8'd2;

  // ---------------------------------------------------------------- backend contract (docs/02 §7)
  localparam logic [2:0] BOP_READ    = 3'd1;
  localparam logic [2:0] BOP_WRITE   = 3'd2;
  localparam logic [2:0] BOP_FLUSH   = 3'd3;
  localparam logic [2:0] BOP_DISCARD = 3'd4;

  localparam logic [3:0] BST_OK          = 4'd0;
  localparam logic [3:0] BST_MEDIA_ERR   = 4'd1;
  localparam logic [3:0] BST_DEV_ERR     = 4'd2;
  localparam logic [3:0] BST_RANGE       = 4'd3;
  localparam logic [3:0] BST_RO          = 4'd4;
  localparam logic [3:0] BST_UNSUPPORTED = 4'd5;
  localparam logic [3:0] BST_NOT_READY   = 4'd6;
  localparam logic [3:0] BST_RESET       = 4'd7;

  // be_caps bit positions
  localparam int BCAP_PI_NATIVE      = 0;
  localparam int BCAP_VOLATILE_CACHE = 1;
  localparam int BCAP_DISCARD        = 2;
  localparam int BCAP_DISCARD_ZERO   = 3;
  localparam int BCAP_READONLY       = 4;

  // backend types (CAPS1[15:12])
  localparam int BE_SIMDEV  = 0;
  localparam int BE_STORE   = 1;
  localparam int BE_HOSTSW  = 2;
  localparam int BE_NVME    = 3;
  localparam int BE_EXTERN  = 4;

  // read-unit flags (be_rd_uflags)
  localparam int UF_ERR      = 0;
  localparam int UF_UNMAPPED = 1;

  // ---------------------------------------------------------------- CloudDMA (P64) constants used by the fabric
  localparam logic [3:0] ASID_HOST = 4'd0;
  localparam logic [3:0] ASID_LMEM = 4'd1;

  // ---------------------------------------------------------------- performance counter ids (mgmt PERF_SEL)
  localparam int PC_CYCLES        = 0;   // free-running cycles
  localparam int PC_CMDS_DONE     = 1;
  localparam int PC_CMDS_ERR      = 2;
  localparam int PC_RD_CMDS       = 3;
  localparam int PC_WR_CMDS       = 4;
  localparam int PC_FLUSH_CMDS    = 5;
  localparam int PC_DISCARD_CMDS  = 6;
  localparam int PC_RD_BLOCKS     = 7;
  localparam int PC_WR_BLOCKS     = 8;
  localparam int PC_BYTES         = 9;   // payload bytes completed OK
  localparam int PC_DMA_IN_CYC    = 10;  // cycles with at least one host->local DMA task active
  localparam int PC_DMA_OUT_CYC   = 11;
  localparam int PC_DMA_BYTES     = 12;
  localparam int PC_BE_BUSY_CYC   = 13;  // cycles with >=1 backend request outstanding
  localparam int PC_BE_STALL_CYC  = 14;  // cycles the mover wanted to move a beat but the backend stalled it
  localparam int PC_QWAIT_CYC     = 15;  // sum over cycles of (heads waiting for a slot)
  localparam int PC_SLOT_BUSY_CYC = 16;  // sum over cycles of busy slots (occupancy integral)
  localparam int PC_VIOL          = 17;  // isolation violations
  localparam int PC_REJECTS       = 18;  // commands rejected by validation
  localparam int PC_INTEG_ERR     = 19;
  localparam int PC_MEDIA_ERR     = 20;
  localparam int PC_TIMEOUTS      = 21;
  localparam int PC_DMA_FAULTS    = 22;
  localparam int PC_ABORTS        = 23;
  localparam int PC_THROTTLE_CYC  = 24;
  localparam int PC_XFORM_CYC     = 25;
  localparam int PC_FETCHED       = 26;  // descriptors fetched
  localparam int PC_CQ_POSTED     = 27;
  localparam int PC_CQ_STALL_CYC  = 28;  // completions waiting for CQ space
  localparam int PC_PF_EVENTS     = 29;
  localparam int PC_CRC_ERR       = 30;  // HCRC mismatches
  localparam int PC_BE_RESETS     = 31;
  localparam int PC_N             = 32;

  // ---------------------------------------------------------------- local memory map (byte addresses)
  // The map is a function of the parameters; helper functions keep the arithmetic in one place.
  localparam int LM_DESC_OFF = 0;       // NUM_CH * 64 bytes  : CloudDMA descriptors (one per channel)
  localparam int LM_SQ_OFF   = 'h100;   // NT * SQ_BATCH * 64 : fetched submission descriptors
  // LM_CQ_OFF and LM_DATA_OFF depend on NT / SQ_BATCH: see sf_stor_map below.

  function automatic int unsigned clog2i(input int unsigned v);
    int unsigned r;
    begin
      r = 0;
      while ((32'd1 << r) < v) r++;
      return r;
    end
  endfunction

  // ---------------------------------------------------------------- CRC-32C reference (bytewise, for tests / protection trailer)
  function automatic logic [31:0] crc32c_byte(input logic [31:0] c, input logic [7:0] b);
    logic [31:0] x;
    begin
      x = c ^ {24'h0, b};
      for (int i = 0; i < 8; i++) x = x[0] ? ((x >> 1) ^ 32'h82F6_3B78) : (x >> 1);
      return x;
    end
  endfunction

  // ---------------------------------------------------------------- records passed between blocks
  // A parsed command (queue -> scheduler -> slot).  `imm` commands (validation failures, GET_CAPACITY) never take a slot.
  typedef struct packed {
    logic [7:0]  op;
    logic [15:0] flags;
    logic [15:0] txn;
    logic [7:0]  nsid;
    logic [63:0] lba;       // namespace-relative
    logic [31:0] nblk;
    logic [63:0] addr;      // tenant IOVA
    logic [31:0] hcrc;
    logic [7:0]  status;    // validation result (imm commands)
    logic [7:0]  detail;
    logic        imm;
    logic [31:0] t_fetch;   // cycle the descriptor became available
  } cmd_t;
  localparam int CMD_W = $bits(cmd_t);

  // A completion record (slot -> tenant queue -> completion entry).
  typedef struct packed {
    logic [15:0] txn;
    logic [7:0]  status;
    logic [7:0]  detail;
    logic [7:0]  op;
    logic [15:0] nblk_done;
    logic        durable;
    logic        pi_ver;
    logic        enc;
    logic        crc_valid;
    logic [31:0] res0;
    logic [31:0] res1;
    logic [31:0] t_fetch;
    logic [31:0] t_admit;
    logic [31:0] t_issue;
    logic [31:0] t_bedone;
    logic [31:0] bytes;
  } cpl_t;
  localparam int CPL_W = $bits(cpl_t);

  // Data-transform job (slot -> sf_stor_xform) and its result.
  typedef struct packed {
    logic        mode;        // 0 = WRITE path (CRC, protection trailer, encrypt)   1 = READ path (decrypt, verify)
    logic [15:0] nblk;
    logic        pi;          // namespace has protection information
    logic        enc;
    logic [3:0]  key;
    logic [3:0]  tenant;
    logic [7:0]  nsid;
    logic [47:0] lba_rel;
    logic [63:0] lba_abs;
    logic        hcrc_en;
    logic [31:0] hcrc;
    logic [15:0] unm;         // READ: blocks the backend reported as never-written / discarded
  } xjob_t;
  localparam int XJOB_W = $bits(xjob_t);
  typedef struct packed {
    logic        ok;
    logic [7:0]  status;
    logic [7:0]  detail;
    logic [31:0] crc;         // CRC-32C of the payload (all nblk*512 data bytes)
    logic        pi_ver;      // protection information generated / verified for every block that has one
    logic [15:0] nblk_ok;     // leading blocks processed without error
  } xres_t;
  localparam int XRES_W = $bits(xres_t);

  // ---------------------------------------------------------------- protection trailer (docs/02 §6.1)
  // Two 64-bit words, little-endian: bytes 0..7 and 8..15.
  function automatic logic [63:0] pi_word0(input logic [31:0] guard, input logic [7:0] nsid, input logic [3:0] tenant,
                                          input logic [47:0] lba_rel);
    return {lba_rel[15:0], 4'h0, tenant, nsid, guard};
  endfunction
  function automatic logic [63:0] pi_word1(input logic [47:0] lba_rel);
    return {24'h0, 8'h01, lba_rel[47:16]};
  endfunction

endpackage

`default_nettype wire
