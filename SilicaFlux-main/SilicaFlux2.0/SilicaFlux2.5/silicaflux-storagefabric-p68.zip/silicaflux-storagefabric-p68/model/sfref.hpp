// sfref.hpp - independent *logical* reference model of the SilicaFlux StorageFabric (P68), ABI v1.0.
//
// Written ONLY from docs/02_HOST_INTERFACE.md (the normative spec). It knows nothing about the RTL.
// Header-only, C++17, namespace sfref.  Every public function carries a "§n" comment that maps it to
// the spec section it implements.  Places where the spec is ambiguous are tagged "Q-nn" and listed in
// model/SPEC_QUESTIONS.md; the chosen interpretation is the *default* and can be flipped through
// `Interp` where that is cheap.
//
// What the model is:
//   * a validator for 64-byte submission descriptors (§2, rules 1..11, first failing rule wins),
//   * a logical block device (per-block version history) that executes commands that passed
//     validation in *submission order per tenant* (§5.1) and yields the expected completion
//     (status/detail/durable/nblk_done/CRC/capacity/read data),
//   * a durability model (§5.2-5.6): versions are volatile until a durable completion or a FLUSH;
//     power_loss() leaves each block indeterminate within [durable floor .. latest],
//   * test helpers: CQE decoder/checker, random descriptor generator (`Gen`), CRC-32C, PI trailer.
//
// What it is not: cycle accurate, DMA-window aware, or a corruption injector.
#ifndef SFREF_HPP
#define SFREF_HPP

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <deque>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace sfref {

// ------------------------------------------------------------------------------------------------
// Constants (§1, §2, §3, §4)
// ------------------------------------------------------------------------------------------------
inline constexpr uint32_t BLOCK_BYTES = 512;      // §1 logical block size
inline constexpr uint32_t DISCARD_MAX = 65535;    // §2 NBLK table row
inline constexpr unsigned DESC_WORDS = 16;        // §2 (64 bytes)
inline constexpr unsigned CQE_WORDS = 8;          // §3 (32 bytes)
inline constexpr unsigned MAX_KEY_SLOTS = 16;     // §9 NS_CTRL.KEY_SLOT is [11:8]

// §2 opcodes
inline constexpr uint8_t OP_WRITE = 1, OP_READ = 2, OP_FLUSH = 3, OP_GET_CAPACITY = 4, OP_DISCARD = 5;
// §2 flags
inline constexpr uint16_t F_FUA = 1u << 0, F_HCRC = 1u << 1, F_RCRC = 1u << 2;
// §4 status codes
inline constexpr uint8_t ST_SUCCESS = 0x00, ST_INVALID_OPCODE = 0x01, ST_INVALID_FIELD = 0x02,
                         ST_INVALID_NS = 0x03, ST_LBA_RANGE = 0x04, ST_LEN_ERROR = 0x05,
                         ST_TENANT_MISMATCH = 0x06, ST_NS_READONLY = 0x07, ST_DMA_FAULT = 0x08,
                         ST_DMA_ERROR = 0x09, ST_DATA_CRC = 0x0A, ST_INTEGRITY = 0x0B,
                         ST_MEDIA_ERROR = 0x0C, ST_BACKEND_ERROR = 0x0D, ST_TIMEOUT = 0x0E,
                         ST_ABORTED_RESET = 0x0F, ST_ABORTED_POWER = 0x10, ST_UNSUPPORTED = 0x11,
                         ST_CRYPTO_ERROR = 0x12, ST_INTERNAL = 0x13;
// §4 details
inline constexpr uint8_t DET_NONE = 0;
inline constexpr uint8_t DET_VERSION = 1, DET_RESERVED = 2, DET_FLAGS = 3, DET_ADDR_ALIGN = 4;  // INVALID_FIELD
inline constexpr uint8_t DET_LEN_ZERO = 1, DET_LEN_TOO_LARGE = 2, DET_LEN_MISMATCH = 3, DET_LEN_NOT_ZERO = 4;
inline constexpr uint8_t DET_KEY_NOT_READY = 1, DET_ENGINE = 2;  // CRYPTO_ERROR
// §9 NS_STATUS bits
inline constexpr uint32_t NSS_ACCEPTED = 1u << 0, NSS_NO_CAPACITY = 1u << 1, NSS_PI_UNSUPPORTED = 1u << 2,
                          NSS_BAD_OWNER_SIZE = 1u << 3, NSS_ENC_UNSUPPORTED = 1u << 4, NSS_OVERLAP = 1u << 5;

inline const char* status_name(unsigned s) {
  static const char* const n[] = {"SUCCESS",      "INVALID_OPCODE", "INVALID_FIELD", "INVALID_NS",
                                  "LBA_RANGE",    "LEN_ERROR",      "TENANT_MISMATCH", "NS_READONLY",
                                  "DMA_FAULT",    "DMA_ERROR",      "DATA_CRC",      "INTEGRITY",
                                  "MEDIA_ERROR",  "BACKEND_ERROR",  "TIMEOUT",       "ABORTED_RESET",
                                  "ABORTED_POWER", "UNSUPPORTED",   "CRYPTO_ERROR",  "INTERNAL"};
  return s < sizeof(n) / sizeof(n[0]) ? n[s] : "?";
}
inline const char* detail_name(unsigned status, unsigned d) {
  if (d == 0) return "-";
  switch (status) {
    case ST_INVALID_FIELD:
      return d == 1 ? "VERSION" : d == 2 ? "RESERVED" : d == 3 ? "FLAGS" : d == 4 ? "ADDR_ALIGN" : "?";
    case ST_LEN_ERROR:
      return d == 1 ? "ZERO" : d == 2 ? "TOO_LARGE" : d == 3 ? "MISMATCH" : d == 4 ? "NOT_ZERO" : "?";
    case ST_CRYPTO_ERROR: return d == 1 ? "KEY_NOT_READY" : d == 2 ? "ENGINE" : "?";
    default: return "code";
  }
}

// ------------------------------------------------------------------------------------------------
// CRC-32C (Castagnoli), reflected, init/xorout 0xFFFFFFFF  (§6.1, used for HOST_CRC / RESULT0 / GUARD)
// crc32c("123456789") == 0xE3069283.  `crc` chains: crc32c(b, nb, crc32c(a, na)) == crc32c(a||b).
// ------------------------------------------------------------------------------------------------
namespace detail {
struct Crc32cTable {
  uint32_t t[256];
  Crc32cTable() {
    for (uint32_t i = 0; i < 256; ++i) {
      uint32_t c = i;
      for (int k = 0; k < 8; ++k) c = (c & 1u) ? (c >> 1) ^ 0x82F63B78u : (c >> 1);
      t[i] = c;
    }
  }
};
inline const Crc32cTable& crc_tab() {
  static const Crc32cTable tab;
  return tab;
}
}  // namespace detail

inline uint32_t crc32c(const void* data, size_t n, uint32_t crc = 0) {
  const uint8_t* p = static_cast<const uint8_t*>(data);
  const uint32_t* t = detail::crc_tab().t;
  uint32_t c = crc ^ 0xFFFFFFFFu;
  for (size_t i = 0; i < n; ++i) c = t[(c ^ p[i]) & 0xFFu] ^ (c >> 8);
  return c ^ 0xFFFFFFFFu;
}

// §6.1 protection trailer (16 bytes) for one block.  The spec gives two inconsistent formulas for NS_TAG
// (Q-17); `tenant_shift` selects: 8 -> NSID | (TENANT<<8) (default; the RTL and docs/02 §6.1 after the Q-17 erratum), 12 -> {TENANT[3:0],4'b0,NSID[7:0]} (the superseded reading).
inline std::array<uint8_t, 16> pi_trailer(const uint8_t* block512, unsigned tenant, unsigned nsid,
                                          uint64_t ns_rel_lba, unsigned tenant_shift = 8) {
  std::array<uint8_t, 16> t{};
  uint32_t g = crc32c(block512, BLOCK_BYTES);
  for (int i = 0; i < 4; ++i) t[i] = uint8_t(g >> (8 * i));
  uint16_t ns_tag = uint16_t((nsid & 0xFFu) | ((tenant & 0xFu) << tenant_shift));
  t[4] = uint8_t(ns_tag);
  t[5] = uint8_t(ns_tag >> 8);
  for (int i = 0; i < 6; ++i) t[6 + i] = uint8_t(ns_rel_lba >> (8 * i));  // 48-bit LBA_TAG
  t[12] = 1;                                                              // VERSION
  return t;
}

// ------------------------------------------------------------------------------------------------
// Configuration types
// ------------------------------------------------------------------------------------------------
// §7 backend capabilities.  (`READONLY` is deliberately absent: its effect on completions is not
// defined by the spec, see Q-20.)
struct BackendCaps {
  uint64_t capacity_blocks = 0;
  bool volatile_cache = false;
  bool discard = false;
  bool discard_zero = false;
  bool pi_native = false;
};

// §8 CAPS1 fabric feature bits that are optional per build.  A flag whose feature is absent is
// refused in rule 6 (UNSUPPORTED), Q-10.
struct Features {
  bool fua = true;
  bool hcrc = true;
};

// §9 namespace table entry (NS_CTRL / BASE / SIZE).
struct NsCfg {
  unsigned owner = 0;
  uint64_t base = 0;
  uint64_t size = 0;
  bool readonly = false;
  bool enc = false;
  bool pi = false;
  unsigned key_slot = 0;  // NS_CTRL[11:8]
};

// §9 NS_STATUS.  `bits` is one bit chosen by the model's priority (bad owner/size > PI > capacity);
// `all` is every applicable refusal reason (the spec does not say whether the register is one-hot, Q-02).
struct NsStatus {
  bool accepted = false;
  bool bad_index = false;  // nsid >= NS_N: the write would be ignored; no register value exists
  uint32_t bits = 0;
  uint32_t all = 0;
  uint32_t reg() const { return bits; }
  // Tolerant comparison with a register value read from hardware: accepted must match exactly,
  // a refusal must be non-zero, not contain bit0 and be a subset of the applicable reasons.
  bool consistent_with(uint32_t rtl) const {
    if (accepted) return rtl == NSS_ACCEPTED;
    return rtl != 0 && (rtl & NSS_ACCEPTED) == 0 && (rtl & ~all) == 0;
  }
};

// Switches for the ambiguous spots (defaults = documented interpretation).
struct Interp {
  uint8_t rsv_flags_detail = DET_RESERVED;  // Q-04: detail for FLAGS bits 3..15 != 0 (RESERVED or FLAGS)
  bool hostcrc_nz_is_flags = false;         // Q-05: HOST_CRC!=0 without HCRC -> FLAGS instead of RESERVED
  bool discard_needs_zero = true;           // Q-09: DISCARD supported iff DISCARD && DISCARD_ZERO
  bool range_all_ops = false;               // Q-11: apply rule 10 to FLUSH/GET_CAPACITY as well (LBA+0<=SIZE)
  bool key_all_ops = false;                 // Q-12: apply rule 11 to non-data opcodes as well
  bool refuse_overlap = false;              // Q-16: overlapping valid namespaces are refused (NS_STATUS bit 5).  false = the model's own unit tests may alias
                                            // namespaces on purpose; the RTL verification environment (tb_env.hpp) sets true
};

// ------------------------------------------------------------------------------------------------
// Descriptor (§2)
// ------------------------------------------------------------------------------------------------
struct Desc {
  uint32_t raw[DESC_WORDS] = {};
  uint8_t version = 0;
  uint8_t opcode = 0;
  uint16_t flags = 0;
  uint16_t txn = 0;
  uint8_t nsid = 0;
  uint8_t rsv1 = 0;  // word 1 [31:24]
  uint64_t lba = 0;
  uint32_t nblk = 0;
  uint32_t data_len = 0;
  uint64_t data_addr = 0;
  uint16_t claim = 0;  // TENANT_CLAIM
  uint16_t rsv8 = 0;   // word 8 [31:16]
  uint32_t host_crc = 0;
};

// §2 table: field extraction.
inline Desc decode(const uint32_t w[DESC_WORDS]) {
  Desc d;
  std::memcpy(d.raw, w, sizeof(d.raw));
  d.version = uint8_t(w[0] & 0xFFu);
  d.opcode = uint8_t((w[0] >> 8) & 0xFFu);
  d.flags = uint16_t(w[0] >> 16);
  d.txn = uint16_t(w[1] & 0xFFFFu);
  d.nsid = uint8_t((w[1] >> 16) & 0xFFu);
  d.rsv1 = uint8_t(w[1] >> 24);
  d.lba = uint64_t(w[2]) | (uint64_t(w[3]) << 32);
  d.nblk = w[4];
  d.data_len = w[5];
  d.data_addr = uint64_t(w[6]) | (uint64_t(w[7]) << 32);
  d.claim = uint16_t(w[8] & 0xFFFFu);
  d.rsv8 = uint16_t(w[8] >> 16);
  d.host_crc = w[9];
  return d;
}
// Inverse of decode (all fields, including the reserved ones, so negative tests can set them);
// words 10..15 are taken from raw[10..15].
inline void encode(const Desc& d, uint32_t w[DESC_WORDS]) {
  w[0] = uint32_t(d.version) | (uint32_t(d.opcode) << 8) | (uint32_t(d.flags) << 16);
  w[1] = uint32_t(d.txn) | (uint32_t(d.nsid) << 16) | (uint32_t(d.rsv1) << 24);
  w[2] = uint32_t(d.lba);
  w[3] = uint32_t(d.lba >> 32);
  w[4] = d.nblk;
  w[5] = d.data_len;
  w[6] = uint32_t(d.data_addr);
  w[7] = uint32_t(d.data_addr >> 32);
  w[8] = uint32_t(d.claim) | (uint32_t(d.rsv8) << 16);
  w[9] = d.host_crc;
  for (unsigned i = 10; i < DESC_WORDS; ++i) w[i] = d.raw[i];
}

// Result of §2 validation.  `rule` is the number (1..11) of the first failing rule, 0 if ok.
struct Verdict {
  bool ok = true;
  uint8_t status = ST_SUCCESS;
  uint8_t detail = 0;
  int rule = 0;
  bool same(const Verdict& o) const { return ok == o.ok && status == o.status && detail == o.detail; }
};

// §3 completion entry
struct Cqe {
  uint16_t txn = 0;
  uint8_t status = 0, detail = 0;
  bool durable = false, pi_verified = false, encrypted = false, crc_valid = false;
  uint8_t opcode = 0;
  uint16_t nblk_done = 0;
  uint32_t result0 = 0, result1 = 0;
  uint16_t sq_head = 0, tenant = 0;
  uint32_t latency = 0;
  uint32_t w1_rsv = 0;  // word 1 bits not assigned (must be 0)
  uint32_t w6 = 0;
  bool phase = false;
  uint32_t w7_rsv = 0;  // word 7 [31:1]
};
inline Cqe decode_cqe(const uint32_t w[CQE_WORDS]) {  // §3
  Cqe c;
  c.txn = uint16_t(w[0] & 0xFFFFu);
  c.status = uint8_t((w[0] >> 16) & 0xFFu);
  c.detail = uint8_t(w[0] >> 24);
  c.durable = (w[1] & 1u) != 0;
  c.pi_verified = (w[1] & 2u) != 0;
  c.encrypted = (w[1] & 4u) != 0;
  c.crc_valid = (w[1] & 8u) != 0;
  c.opcode = uint8_t((w[1] >> 8) & 0xFFu);
  c.nblk_done = uint16_t(w[1] >> 16);
  c.w1_rsv = w[1] & 0xF0u;  // bits 7:4
  c.result0 = w[2];
  c.result1 = w[3];
  c.sq_head = uint16_t(w[4] & 0xFFFFu);
  c.tenant = uint16_t(w[4] >> 16);
  c.latency = w[5];
  c.w6 = w[6];
  c.phase = (w[7] & 1u) != 0;
  c.w7_rsv = w[7] >> 1;
  return c;
}

// Expected completion for one command (what a correct fabric must report).  Tri-state ints:
// 0 / 1 = required value, -1 = the spec does not define it (don't care).
struct Outcome {
  Verdict v;                 // §2 verdict (v.ok == passed validation)
  bool executed = false;     // reached execution (passed validation)
  uint16_t txn = 0;          // §3 TXN_ID echo
  uint8_t opcode = 0;        // §3 OPCODE echo (raw low byte of word0[15:8], even if invalid)
  unsigned tenant = 0;       // §3 TENANT (hardware stamped)
  uint8_t status = 0, detail = 0;
  int durable = 0;           // §5.3/5.6
  int pi_verified = -1;      // §3, §5.7, §6
  int encrypted = -1;
  int crc_valid = 0;         // 1 iff RCRC and data moved
  uint32_t crc = 0;          // CRC-32C of the payload when crc_valid == 1
  uint32_t nblk_done = 0;    // §3/§4
  uint32_t result0 = 0, result1 = 0;  // GET_CAPACITY (§3); CRC lives in `crc`
  std::vector<uint8_t> read_data;     // READ + SUCCESS: expected payload (latest logical version)
  bool read_indeterminate = false;    // READ touched blocks whose content is not determined (after loss / failed write)
  uint64_t wid = 0;          // WRITE/DISCARD identity for on_write_complete(wid,..)
  uint64_t fid = 0;          // FLUSH identity
  bool bad_hcrc = false;     // WRITE failed with DATA_CRC (nothing applied)
};

// ------------------------------------------------------------------------------------------------
// The model
// ------------------------------------------------------------------------------------------------
class Model {
 public:
  using Block = std::array<uint8_t, BLOCK_BYTES>;

  // Expected value of the per-tenant counters of §8 (0x080..0x09C), accounted at submit().
  struct Counters {
    uint32_t done = 0, err = 0, rd_blk = 0, wr_blk = 0, flush = 0, viol = 0;
    uint64_t bytes = 0;
  };

  Model(unsigned nt, unsigned ns_n, unsigned mdts_blocks, BackendCaps caps, Interp ip = Interp(),
        Features ft = Features())
      : nt_(nt), mdts_(mdts_blocks), caps_(caps), ip_(ip), ft_(ft), ns_(ns_n), key_ready_{},
        pend_by_tenant_(nt), flushq_(nt), counters_(nt) {}

  // §2 field extraction (same as the free function sfref::decode; provided here so a reviewer finds the
  // whole descriptor pipeline on Model).
  static Desc decode(const uint32_t w[DESC_WORDS]) { return sfref::decode(w); }

  // ---- accessors ------------------------------------------------------------------------------
  unsigned nt() const { return nt_; }
  unsigned ns_n() const { return unsigned(ns_.size()); }
  unsigned mdts() const { return mdts_; }
  const BackendCaps& caps() const { return caps_; }
  const Features& features() const { return ft_; }
  const Interp& interp() const { return ip_; }
  bool ns_valid(unsigned nsid) const { return nsid < ns_.size() && ns_[nsid].valid; }
  const NsCfg& ns_cfg(unsigned nsid) const { return ns_.at(nsid).c; }
  // §9 / §8 CAPS1[31:16]: bitmask of NSIDs owned (and valid) for `tenant`.
  uint32_t owned_mask(unsigned tenant) const {
    uint32_t m = 0;
    for (unsigned i = 0; i < ns_.size() && i < 16; ++i)
      if (ns_[i].valid && ns_[i].c.owner == tenant) m |= 1u << i;
    return m;
  }
  // §2 rule 6 as the model evaluates it: is DISCARD supported?
  bool discard_supported() const { return caps_.discard && (!ip_.discard_needs_zero || caps_.discard_zero); }
  bool key_ready(unsigned slot) const { return slot < MAX_KEY_SLOTS && key_ready_[slot]; }
  const Counters& counters(unsigned tenant) const { return counters_.at(tenant); }
  void clear_counters() { for (auto& c : counters_) c = Counters(); }  // §9 GCTRL.CLR_COUNTERS
  // Protocol violations noticed by the hooks (e.g. a FLUSH completing before an earlier write).
  const std::vector<std::string>& violations() const { return violations_; }
  void clear_violations() { violations_.clear(); }

  // ---- §9 namespace table / §6 keys ----------------------------------------------------------
  // Sequence BASE/SIZE/flags then VALID=1, result is NS_STATUS.  The namespace is invalid first
  // (config is only writable while VALID=0) and stays invalid if refused.
  NsStatus cfg_ns(unsigned nsid, const NsCfg& c) {
    NsStatus s;
    if (nsid >= ns_.size()) {
      s.bad_index = true;
      return s;
    }
    ns_[nsid].valid = false;
    uint32_t all = 0;
    if (c.owner >= nt_ || c.owner > 15 || c.size == 0) all |= NSS_BAD_OWNER_SIZE;
    if (c.pi && !caps_.pi_native) all |= NSS_PI_UNSUPPORTED;
    const uint64_t end = c.base + c.size;  // 65-bit check: carry or end > capacity
    if (end < c.base || end > caps_.capacity_blocks) all |= NSS_NO_CAPACITY;
    if (ip_.refuse_overlap)
    for (unsigned o = 0; o < ns_.size(); o++)          // two valid namespaces must never share a backend block
      if (o != nsid && ns_[o].valid && c.base < ns_[o].c.base + ns_[o].c.size && ns_[o].c.base < c.base + c.size) all |= NSS_OVERLAP;
    if (all == 0) {
      ns_[nsid].valid = true;
      ns_[nsid].c = c;
      ns_[nsid].c.key_slot = c.key_slot & 0xFu;
      s.accepted = true;
      s.bits = s.all = NSS_ACCEPTED;
      return s;
    }
    s.all = all;
    // documented precedence (docs/02 §9): bad owner/size, capacity, PI, ENC, overlap
    s.bits = (all & NSS_BAD_OWNER_SIZE) ? NSS_BAD_OWNER_SIZE : (all & NSS_NO_CAPACITY) ? NSS_NO_CAPACITY : (all & NSS_PI_UNSUPPORTED) ? NSS_PI_UNSUPPORTED : (all & NSS_ENC_UNSUPPORTED) ? NSS_ENC_UNSUPPORTED : NSS_OVERLAP;
    return s;
  }
  void invalidate_ns(unsigned nsid) {  // NS_CTRL.VALID = 0
    if (nsid < ns_.size()) ns_[nsid].valid = false;
  }
  void set_key_ready(unsigned slot, bool ready) {  // §2 rule 11 / §9 KEY_CTRL commit|zeroize
    if (slot < MAX_KEY_SLOTS) key_ready_[slot] = ready;
  }

  // ---- §2 validation --------------------------------------------------------------------------
  // `tenant` = queue the descriptor was fetched from (ownership is checked against it);
  // `hw_binding` = the hardware binding TENANT_CLAIM must equal.  They are equal on real hardware.
  Verdict validate(unsigned tenant, const uint32_t w[DESC_WORDS], unsigned hw_binding) const {
    const Desc d = decode(w);
    auto fail = [](int rule, uint8_t st, uint8_t det) {
      Verdict v;
      v.ok = false;
      v.rule = rule;
      v.status = st;
      v.detail = det;
      return v;
    };
    // rule 1: VERSION
    if (d.version != 1) return fail(1, ST_INVALID_FIELD, DET_VERSION);
    // rule 2: OPCODE (DISCARD is a legal opcode even if the backend lacks it: that is rule 6)
    if (d.opcode < OP_WRITE || d.opcode > OP_DISCARD) return fail(2, ST_INVALID_OPCODE, DET_NONE);
    // rule 3: TENANT_CLAIM
    if (d.claim != hw_binding) return fail(3, ST_TENANT_MISMATCH, DET_NONE);
    const bool is_w = d.opcode == OP_WRITE, is_r = d.opcode == OP_READ;
    const bool is_data = is_w || is_r;
    // rule 4: reserved bits/words (in word order), then flag/opcode legality (Q-03, Q-04, Q-05)
    if (d.flags & 0xFFF8u) return fail(4, ST_INVALID_FIELD, ip_.rsv_flags_detail);
    if (d.rsv1) return fail(4, ST_INVALID_FIELD, DET_RESERVED);
    if (d.rsv8) return fail(4, ST_INVALID_FIELD, DET_RESERVED);
    if (!(d.flags & F_HCRC) && d.host_crc != 0)
      return fail(4, ST_INVALID_FIELD, ip_.hostcrc_nz_is_flags ? DET_FLAGS : DET_RESERVED);
    for (unsigned i = 10; i < DESC_WORDS; ++i)
      if (w[i]) return fail(4, ST_INVALID_FIELD, DET_RESERVED);
    if ((d.flags & F_HCRC) && !is_w) return fail(4, ST_INVALID_FIELD, DET_FLAGS);
    if ((d.flags & F_FUA) && !is_w) return fail(4, ST_INVALID_FIELD, DET_FLAGS);
    if ((d.flags & F_RCRC) && !is_data) return fail(4, ST_INVALID_FIELD, DET_FLAGS);
    // rule 5: NSID valid and owned (nonexistent and foreign are indistinguishable)
    if (!ns_valid(d.nsid) || ns_[d.nsid].c.owner != tenant) return fail(5, ST_INVALID_NS, DET_NONE);
    const NsCfg& ns = ns_[d.nsid].c;
    // rule 6: capability absent
    if (d.opcode == OP_DISCARD && !discard_supported()) return fail(6, ST_UNSUPPORTED, DET_NONE);
    if (is_w && (d.flags & F_FUA) && !ft_.fua) return fail(6, ST_UNSUPPORTED, DET_NONE);
    if (is_w && (d.flags & F_HCRC) && !ft_.hcrc) return fail(6, ST_UNSUPPORTED, DET_NONE);
    // rule 7: read-only namespace
    if ((is_w || d.opcode == OP_DISCARD) && ns.readonly) return fail(7, ST_NS_READONLY, DET_NONE);
    // rule 8: NBLK / DATA_LEN
    switch (d.opcode) {
      case OP_READ:
      case OP_WRITE:
        if (d.nblk == 0) return fail(8, ST_LEN_ERROR, DET_LEN_ZERO);
        if (d.nblk > mdts_) return fail(8, ST_LEN_ERROR, DET_LEN_TOO_LARGE);
        if (uint64_t(d.data_len) != uint64_t(d.nblk) * BLOCK_BYTES) return fail(8, ST_LEN_ERROR, DET_LEN_MISMATCH);
        break;
      case OP_DISCARD:
        if (d.nblk == 0) return fail(8, ST_LEN_ERROR, DET_LEN_ZERO);
        if (d.nblk > DISCARD_MAX) return fail(8, ST_LEN_ERROR, DET_LEN_TOO_LARGE);
        if (d.data_len != 0) return fail(8, ST_LEN_ERROR, DET_LEN_NOT_ZERO);
        break;
      default:  // FLUSH, GET_CAPACITY
        if (d.nblk != 0 || d.data_len != 0) return fail(8, ST_LEN_ERROR, DET_LEN_NOT_ZERO);
        break;
    }
    // rule 9: DATA_ADDR alignment (R/W) / must-be-zero (others)
    if (is_data ? (d.data_addr & 3u) != 0 : d.data_addr != 0) return fail(9, ST_INVALID_FIELD, DET_ADDR_ALIGN);
    // rule 10: LBA + NBLK <= NS_SIZE in 65-bit arithmetic (carry detected explicitly)  (Q-11)
    if (is_data || d.opcode == OP_DISCARD || ip_.range_all_ops) {
      const uint64_t end = d.lba + d.nblk;
      if (end < d.lba || end > ns.size) return fail(10, ST_LBA_RANGE, DET_NONE);
    }
    // rule 11: encryption needs a ready key slot (Q-12: data ops only by default)
    if (ns.enc && (is_data || ip_.key_all_ops) && !key_ready(ns.key_slot))
      return fail(11, ST_CRYPTO_ERROR, DET_KEY_NOT_READY);
    Verdict ok;
    return ok;
  }
  Verdict validate(unsigned tenant, const uint32_t w[DESC_WORDS]) const { return validate(tenant, w, tenant); }

  // ---- §2/§3/§5 execution ---------------------------------------------------------------------
  // Validate and (if valid) apply the command to the logical store.  Call in submission order per
  // tenant.  `wdata` points at NBLK*512 payload bytes (required for a WRITE that passes validation).
  // The expected completion is returned; durability bookkeeping is finished by the on_* hooks.
  Outcome submit(unsigned tenant, const uint32_t w[DESC_WORDS], const uint8_t* wdata, int hw_binding = -1) {
    const Desc d = decode(w);
    Outcome o;
    o.txn = d.txn;
    o.opcode = d.opcode;
    o.tenant = tenant;
    o.v = validate(tenant, w, hw_binding < 0 ? tenant : unsigned(hw_binding));
    if (!o.v.ok) {  // a rejected command moves no data and touches no state (§2, §4)
      o.status = o.v.status;
      o.detail = o.v.detail;
      o.durable = 0;
      o.crc_valid = 0;
      o.pi_verified = o.encrypted = -1;
      account(tenant, o, d);
      return o;
    }
    o.executed = true;
    const NsCfg& ns = ns_[d.nsid].c;
    const bool rcrc = (d.flags & F_RCRC) != 0;
    switch (d.opcode) {
      case OP_WRITE: {  // §5.3
        if ((d.flags & F_HCRC) && wdata &&
            crc32c(wdata, size_t(d.nblk) * BLOCK_BYTES) != d.host_crc) {  // §2 HCRC: nothing reaches the backend
          o.status = ST_DATA_CRC;
          o.bad_hcrc = true;
          o.durable = 0;
          o.crc_valid = -1;
          o.pi_verified = o.encrypted = -1;
          break;
        }
        o.wid = ++seq_;
        apply_write(tenant, ns, d, wdata, o.wid);
        o.status = ST_SUCCESS;
        o.nblk_done = d.nblk;
        o.durable = (!caps_.volatile_cache || (d.flags & F_FUA)) ? 1 : 0;  // §5.3, §5.4
        o.pi_verified = ns.pi ? 1 : 0;
        o.encrypted = ns.enc ? 1 : 0;
        if (rcrc) {
          o.crc_valid = 1;
          o.crc = wdata ? crc32c(wdata, size_t(d.nblk) * BLOCK_BYTES) : 0;
        }
        break;
      }
      case OP_READ: {  // §5.1 (sees every earlier-submitted write), §5.7
        o.read_data.resize(size_t(d.nblk) * BLOCK_BYTES);
        unsigned mapped = 0;
        for (uint32_t i = 0; i < d.nblk; ++i) {
          const uint64_t abs = ns.base + d.lba + i;
          bool ind = false, m = false;
          Block b = latest_block(abs, &ind, &m);
          std::memcpy(o.read_data.data() + size_t(i) * BLOCK_BYTES, b.data(), BLOCK_BYTES);
          if (ind) o.read_indeterminate = true;
          if (m) ++mapped;
        }
        o.status = ST_SUCCESS;
        o.nblk_done = d.nblk;
        o.durable = -1;  // Q-13
        // §5.7: PI_VERIFIED = 0 for never-written blocks; one CQE bit for N blocks => don't care when mixed (Q-14)
        if (!ns.pi) o.pi_verified = 0;
        else if (o.read_indeterminate) o.pi_verified = -1;
        else o.pi_verified = (mapped == d.nblk) ? 1 : (mapped == 0 ? 0 : -1);
        if (!ns.enc) o.encrypted = 0;
        else o.encrypted = (!o.read_indeterminate && mapped == d.nblk) ? 1 : -1;
        if (rcrc) {
          o.crc_valid = 1;
          o.crc = crc32c(o.read_data.data(), o.read_data.size());
        }
        break;
      }
      case OP_FLUSH: {  // §5.2
        o.fid = ++seq_;
        flushq_[tenant].push_back({o.fid, o.fid});  // cutoff: only writes submitted before this FLUSH are covered
        o.status = ST_SUCCESS;
        o.durable = 1;
        o.pi_verified = o.encrypted = -1;
        break;
      }
      case OP_GET_CAPACITY: {  // §3 RESULT0/1
        o.status = ST_SUCCESS;
        o.result0 = uint32_t(ns.size);
        o.result1 = uint32_t(ns.size >> 32);
        o.durable = -1;
        o.pi_verified = o.encrypted = -1;
        break;
      }
      case OP_DISCARD: {  // §5.6: discarded blocks read zeros; durability like WRITE
        o.wid = ++seq_;
        apply_discard(tenant, ns, d, o.wid);
        o.status = ST_SUCCESS;
        o.nblk_done = d.nblk;
        o.durable = caps_.volatile_cache ? 0 : 1;
        o.pi_verified = o.encrypted = -1;
        break;
      }
      default: break;
    }
    o.detail = 0;
    account(tenant, o, d);
    return o;
  }

  // ---- completion-time hooks (§5) -------------------------------------------------------------
  // The testbench calls these when the matching CQE is observed (SUCCESS only; for failures use the
  // *_failed variants).  `durable` is the CQE.DURABLE value actually reported.
  //
  // WRITE/DISCARD completion, identified by (tenant, ns, lba, nblk): resolves to the oldest pending
  // write of that tenant with that exact range (same-range writes overlap, hence complete in order, §5.1).
  void on_write_complete(unsigned tenant, unsigned nsid, uint64_t lba, uint32_t nblk, bool durable) {
    for (uint64_t wid : pend_by_tenant_.at(tenant)) {
      const Pending& p = pending_.at(wid);
      if (p.nsid == nsid && p.lba == lba && p.nblk == nblk) {
        finish_write(wid, durable);
        return;
      }
    }
    violations_.push_back("on_write_complete: no pending write for tenant " + std::to_string(tenant) + " ns " +
                          std::to_string(nsid) + " lba " + std::to_string(lba) + " nblk " + std::to_string(nblk));
  }
  void on_write_complete(uint64_t wid, bool durable) {  // exact variant using Outcome::wid
    if (!pending_.count(wid)) {
      violations_.push_back("on_write_complete: unknown wid " + std::to_string(wid));
      return;
    }
    finish_write(wid, durable);
  }
  // §4: a WRITE/DISCARD that failed during execution (or was aborted by reset / power-fail with no
  // CQE: pass nblk_done = 0).  Leading nblk_done blocks are applied (volatile); the rest are
  // "old or new" (each 512 B block is all-old or all-new).  Use check_read_after_loss() afterwards.
  void on_write_failed(uint64_t wid, uint32_t nblk_done) {
    auto it = pending_.find(wid);
    if (it == pending_.end()) return;
    const Pending p = it->second;
    for (uint32_t i = 0; i < p.nblk; ++i) {
      auto h = hist_.find(p.abs_base + i);
      if (h == hist_.end()) continue;
      for (auto& v : h->second.v)
        if (v.wid == wid) {
          v.completed = true;
          if (i >= nblk_done) v.maybe = true;
        }
    }
    drop_pending(wid);
  }
  // FLUSH completed SUCCESS/DURABLE (§5.2): covers every write of `tenant` submitted before the FLUSH.
  // FLUSHes of one queue complete in order, so this pops the oldest outstanding FLUSH of the tenant.
  void on_flush_complete(unsigned tenant) {
    auto& q = flushq_.at(tenant);
    if (q.empty()) {  // FLUSH was not submitted through the model: cover everything submitted so far
      do_flush(tenant, seq_ + 1);
      return;
    }
    const uint64_t cutoff = q.front().cutoff;
    q.pop_front();
    do_flush(tenant, cutoff);
  }
  void on_flush_failed(unsigned tenant) {  // FLUSH completed with an error: nothing becomes durable
    auto& q = flushq_.at(tenant);
    if (!q.empty()) q.pop_front();
  }
  // §5.5: power loss followed by backend recovery.  Call at a point where every command has either
  // completed (hooks called) or been abandoned (on_write_failed(wid, 0)); anything still pending is
  // treated as abandoned.  After this every block with versions newer than its durable floor is
  // indeterminate: a read may return any version in [floor, latest].
  void power_loss() {
    for (auto& kv : hist_) {
      auto& v = kv.second.v;
      for (size_t i = 1; i < v.size(); ++i) {
        v[i].maybe = true;
        v[i].completed = true;
      }
    }
    pending_.clear();
    for (auto& l : pend_by_tenant_) l.clear();
    for (auto& q : flushq_) q.clear();
    ++power_losses_;
  }
  unsigned power_loss_count() const { return power_losses_; }

  // ---- read-back checks (§5, §6) --------------------------------------------------------------
  // Fill `out` with the latest logical content of ns-relative blocks (no indeterminacy handling).
  bool expected_read(unsigned nsid, uint64_t lba, uint32_t nblk, uint8_t* out) const {
    if (!ns_valid(nsid)) return false;
    const NsCfg& ns = ns_[nsid].c;
    for (uint32_t i = 0; i < nblk; ++i) {
      bool ind = false, m = false;
      Block b = latest_block(ns.base + lba + i, &ind, &m);
      std::memcpy(out + size_t(i) * BLOCK_BYTES, b.data(), BLOCK_BYTES);
    }
    return true;
  }
  // True iff every block in the range has exactly one acceptable content.
  bool is_determinate(unsigned nsid, uint64_t lba, uint32_t nblk) const {
    if (!ns_valid(nsid)) return true;
    const NsCfg& ns = ns_[nsid].c;
    for (uint32_t i = 0; i < nblk; ++i) {
      auto it = hist_.find(ns.base + lba + i);
      if (it != hist_.end() && last_definite(it->second) != it->second.v.size() - 1) return false;
    }
    return true;
  }
  // Normal operation: the data read must equal the latest logical version exactly.  Fails (with a
  // hint) if the range is indeterminate - use check_read_after_loss() then.
  bool check_read(unsigned nsid, uint64_t lba, uint32_t nblk, const uint8_t* got, std::string& why) const {
    if (!ns_valid(nsid)) {
      why = "check_read: nsid not valid";
      return false;
    }
    const NsCfg& ns = ns_[nsid].c;
    for (uint32_t i = 0; i < nblk; ++i) {
      const uint64_t abs = ns.base + lba + i;
      auto it = hist_.find(abs);
      const uint8_t* g = got + size_t(i) * BLOCK_BYTES;
      if (it == hist_.end()) {
        if (!is_zero(g)) return mismatch(why, nsid, lba, i, nullptr, g, "never-written block must read zeros (§5.7)");
        continue;
      }
      const Hist& h = it->second;
      if (last_definite(h) != h.v.size() - 1) {
        std::ostringstream s;
        s << "check_read: ns " << nsid << " lba " << (lba + i) << " is indeterminate (power loss / failed write); use check_read_after_loss";
        why = s.str();
        return false;
      }
      if (!eq(h.v.back(), g)) return mismatch(why, nsid, lba, i, &h.v.back(), g, "data differs from latest version");
    }
    return true;
  }
  // After a power loss (or a failed write): accept, per block, any version in [durable floor, latest]
  // (zeros are the initial version).  Never accept content that was not written to that block (§5.5).
  // On success the history of each block collapses to the observed version.
  bool check_read_after_loss(unsigned nsid, uint64_t lba, uint32_t nblk, const uint8_t* got, std::string& why) {
    if (!ns_valid(nsid)) {
      why = "check_read_after_loss: nsid not valid";
      return false;
    }
    const NsCfg& ns = ns_[nsid].c;
    std::vector<size_t> hit(nblk, 0);
    for (uint32_t i = 0; i < nblk; ++i) {
      const uint64_t abs = ns.base + lba + i;
      auto it = hist_.find(abs);
      const uint8_t* g = got + size_t(i) * BLOCK_BYTES;
      if (it == hist_.end()) {
        if (!is_zero(g)) return mismatch(why, nsid, lba, i, nullptr, g, "never-written block must read zeros");
        continue;
      }
      const Hist& h = it->second;
      bool found = false;
      for (size_t k = last_definite(h); k < h.v.size(); ++k)
        if (eq(h.v[k], g)) {
          hit[i] = k;
          found = true;
          break;
        }
      if (!found) {
        std::ostringstream s;
        s << "ns " << nsid << " lba " << (lba + i) << ": read-back matches none of the " << (h.v.size() - last_definite(h))
          << " acceptable versions (data never written to this block, or an older/lost durable version) (§5.5)";
        why = s.str();
        return false;
      }
    }
    for (uint32_t i = 0; i < nblk; ++i) {  // collapse
      auto it = hist_.find(ns.base + lba + i);
      if (it == hist_.end()) continue;
      Hist& h = it->second;
      Version keep = h.v[hit[i]];
      keep.maybe = false;
      keep.completed = true;
      keep.wid = 0;
      h.v.assign(1, keep);
      dirty_.erase(it->first);
    }
    return true;
  }
  // Number of acceptable contents of one block (1 = determinate).  Handy for statistics in tests.
  size_t candidates(unsigned nsid, uint64_t lba) const {
    if (!ns_valid(nsid)) return 1;
    auto it = hist_.find(ns_[nsid].c.base + lba);
    return it == hist_.end() ? 1 : it->second.v.size() - last_definite(it->second);
  }

  // ---- §3 CQE check ---------------------------------------------------------------------------
  // Compare a decoded completion with the expectation.  Don't-care fields (-1) are skipped.
  bool check_cqe(const Outcome& o, const Cqe& c, std::string& why) const {
    std::ostringstream s;
    auto bad = [&](const char* f, uint64_t exp, uint64_t got) {
      s << f << ": expected 0x" << std::hex << exp << " got 0x" << got << " (txn 0x" << o.txn << " op " << unsigned(o.opcode)
        << " exp status " << status_name(o.status) << ")";
      why = s.str();
      return false;
    };
    if (c.txn != o.txn) return bad("TXN_ID", o.txn, c.txn);
    if (c.status != o.status) return bad("STATUS", o.status, c.status);
    if (c.detail != o.detail) return bad("DETAIL", o.detail, c.detail);
    if (c.opcode != o.opcode) return bad("OPCODE", o.opcode, c.opcode);
    if (c.tenant != o.tenant) return bad("TENANT", o.tenant, c.tenant);
    if (c.nblk_done != o.nblk_done) return bad("NBLK_DONE", o.nblk_done, c.nblk_done);
    if (o.durable >= 0 && int(c.durable) != o.durable) return bad("DURABLE", unsigned(o.durable), c.durable);
    if (o.pi_verified >= 0 && int(c.pi_verified) != o.pi_verified) return bad("PI_VERIFIED", unsigned(o.pi_verified), c.pi_verified);
    if (o.encrypted >= 0 && int(c.encrypted) != o.encrypted) return bad("ENCRYPTED", unsigned(o.encrypted), c.encrypted);
    if (o.crc_valid >= 0 && int(c.crc_valid) != o.crc_valid) return bad("CRC_VALID", unsigned(o.crc_valid), c.crc_valid);
    if (o.crc_valid == 1) {
      if (c.result0 != o.crc) return bad("RESULT0(crc)", o.crc, c.result0);
      if (c.result1 != 0) return bad("RESULT1", 0, c.result1);
    } else if (o.crc_valid == 0) {
      if (c.result0 != o.result0) return bad("RESULT0", o.result0, c.result0);
      if (c.result1 != o.result1) return bad("RESULT1", o.result1, c.result1);
    }
    if (c.w1_rsv) return bad("CQE word1 reserved bits", 0, c.w1_rsv);
    if (c.w6) return bad("CQE word6 (reserved)", 0, c.w6);
    if (c.w7_rsv) return bad("CQE word7[31:1] (reserved)", 0, c.w7_rsv);
    return true;
  }

 private:
  struct NsEntry {
    bool valid = false;
    NsCfg c;
  };
  struct Version {
    std::shared_ptr<const Block> data;  // null = zeros
    bool mapped = false;                // written and not discarded since
    uint64_t wid = 0;
    uint8_t tenant = 0;
    bool completed = true;
    bool maybe = false;                 // may be absent from the media (lost cache / failed write tail)
  };
  struct Hist {
    std::vector<Version> v;  // v[0] = durable floor; later entries in write order
  };
  struct Pending {
    unsigned tenant, nsid;
    uint64_t lba;
    uint32_t nblk;
    uint64_t abs_base;
  };
  struct FlushRec {
    uint64_t fid, cutoff;
  };

  static bool is_zero(const uint8_t* g) {
    for (uint32_t i = 0; i < BLOCK_BYTES; ++i)
      if (g[i]) return false;
    return true;
  }
  static bool eq(const Version& v, const uint8_t* g) {
    return v.data ? std::memcmp(v.data->data(), g, BLOCK_BYTES) == 0 : is_zero(g);
  }
  static size_t last_definite(const Hist& h) {
    size_t m = h.v.size() - 1;
    while (m > 0 && h.v[m].maybe) --m;
    return m;
  }
  static bool mismatch(std::string& why, unsigned nsid, uint64_t lba, uint32_t i, const Version* exp, const uint8_t* g,
                       const char* msg) {
    std::ostringstream s;
    const uint8_t* e = exp && exp->data ? exp->data->data() : nullptr;
    uint32_t off = 0;
    for (; off < BLOCK_BYTES; ++off)
      if ((e ? e[off] : 0) != g[off]) break;
    s << "ns " << nsid << " lba " << (lba + i) << ": " << msg << "; first diff at byte " << off << " expected 0x" << std::hex
      << unsigned(off < BLOCK_BYTES ? (e ? e[off] : 0) : 0) << " got 0x" << unsigned(off < BLOCK_BYTES ? g[off] : 0);
    why = s.str();
    return false;
  }

  Hist& hist_for_write(uint64_t abs) {
    auto it = hist_.find(abs);
    if (it == hist_.end()) {
      Hist h;
      h.v.push_back(Version());  // initial version: zeros, unmapped, durable
      it = hist_.emplace(abs, std::move(h)).first;
    }
    return it->second;
  }
  Block latest_block(uint64_t abs, bool* indeterminate, bool* mapped) const {
    Block b;
    auto it = hist_.find(abs);
    *indeterminate = false;
    *mapped = false;
    if (it == hist_.end()) {
      b.fill(0);
      return b;
    }
    const Hist& h = it->second;
    if (last_definite(h) != h.v.size() - 1) *indeterminate = true;
    const Version& v = h.v.back();
    *mapped = v.mapped;
    if (v.data) b = *v.data;
    else b.fill(0);
    return b;
  }
  void note_dirty(uint64_t abs, const Hist& h) {
    if (h.v.size() > 1) dirty_.insert(abs);
    else dirty_.erase(abs);
  }
  void apply_write(unsigned tenant, const NsCfg& ns, const Desc& d, const uint8_t* wdata, uint64_t wid) {
    Pending p{tenant, d.nsid, d.lba, d.nblk, ns.base + d.lba};
    for (uint32_t i = 0; i < d.nblk; ++i) {
      const uint64_t abs = p.abs_base + i;
      Hist& h = hist_for_write(abs);
      Version v;
      auto b = std::make_shared<Block>();
      if (wdata) std::memcpy(b->data(), wdata + size_t(i) * BLOCK_BYTES, BLOCK_BYTES);
      else b->fill(0);
      v.data = b;
      v.mapped = true;
      v.wid = wid;
      v.tenant = uint8_t(tenant);
      v.completed = false;
      h.v.push_back(std::move(v));
      note_dirty(abs, h);
    }
    pending_[wid] = p;
    pend_by_tenant_[tenant].push_back(wid);
  }
  void apply_discard(unsigned tenant, const NsCfg& ns, const Desc& d, uint64_t wid) {
    Pending p{tenant, d.nsid, d.lba, d.nblk, ns.base + d.lba};
    for (uint32_t i = 0; i < d.nblk; ++i) {
      const uint64_t abs = p.abs_base + i;
      auto it = hist_.find(abs);
      if (it == hist_.end()) continue;  // never touched: already zeros, nothing to record
      Version v;                        // zero version, unmapped
      v.wid = wid;
      v.tenant = uint8_t(tenant);
      v.completed = false;
      it->second.v.push_back(std::move(v));
      note_dirty(abs, it->second);
    }
    pending_[wid] = p;
    pend_by_tenant_[tenant].push_back(wid);
  }
  void drop_pending(uint64_t wid) {
    auto it = pending_.find(wid);
    if (it == pending_.end()) return;
    auto& l = pend_by_tenant_[it->second.tenant];
    l.erase(std::remove(l.begin(), l.end(), wid), l.end());
    pending_.erase(it);
  }
  // Version at index k becomes the durable floor: everything older is superseded (§5.5, "or a later write's data").
  void promote(uint64_t abs, Hist& h, size_t k) {
    h.v[k].maybe = false;
    h.v[k].completed = true;
    h.v.erase(h.v.begin(), h.v.begin() + long(k));
    note_dirty(abs, h);
  }
  void finish_write(uint64_t wid, bool durable) {
    const Pending p = pending_.at(wid);
    for (uint32_t i = 0; i < p.nblk; ++i) {
      const uint64_t abs = p.abs_base + i;
      auto it = hist_.find(abs);
      if (it == hist_.end()) continue;
      Hist& h = it->second;
      for (size_t k = 0; k < h.v.size(); ++k)
        if (h.v[k].wid == wid) {
          h.v[k].completed = true;
          if (durable) promote(abs, h, k);
          break;
        }
    }
    drop_pending(wid);
  }
  void do_flush(unsigned tenant, uint64_t cutoff) {
    for (uint64_t wid : pend_by_tenant_[tenant])
      if (wid < cutoff) {
        violations_.push_back("FLUSH completed while earlier write wid " + std::to_string(wid) + " of tenant " +
                              std::to_string(tenant) + " was still incomplete (§5.2)");
        break;
      }
    std::vector<uint64_t> keys(dirty_.begin(), dirty_.end());
    for (uint64_t abs : keys) {
      Hist& h = hist_.at(abs);
      for (size_t k = h.v.size(); k-- > 1;) {
        const Version& v = h.v[k];
        if (v.tenant == tenant && v.wid != 0 && v.wid < cutoff && v.completed && !v.maybe) {
          promote(abs, h, k);
          break;
        }
      }
    }
  }
  // CNT_* accounting (§8): every completed command counts in CNT_DONE (Q-15).
  void account(unsigned tenant, const Outcome& o, const Desc& d) {
    if (tenant >= counters_.size()) return;
    Counters& c = counters_[tenant];
    ++c.done;
    if (o.status != ST_SUCCESS) ++c.err;
    if (o.status == ST_TENANT_MISMATCH || o.status == ST_INVALID_NS || o.status == ST_DMA_FAULT) ++c.viol;
    if (o.status == ST_SUCCESS) {
      if (d.opcode == OP_READ) {
        c.rd_blk += d.nblk;
        c.bytes += uint64_t(d.nblk) * BLOCK_BYTES;
      } else if (d.opcode == OP_WRITE) {
        c.wr_blk += d.nblk;
        c.bytes += uint64_t(d.nblk) * BLOCK_BYTES;
      } else if (d.opcode == OP_FLUSH) {
        ++c.flush;
      }
    }
  }

  unsigned nt_, mdts_;
  BackendCaps caps_;
  Interp ip_;
  Features ft_;
  std::vector<NsEntry> ns_;
  bool key_ready_[MAX_KEY_SLOTS];
  std::unordered_map<uint64_t, Hist> hist_;  // key: backend-absolute block
  std::unordered_set<uint64_t> dirty_;       // blocks with more than the floor version
  std::unordered_map<uint64_t, Pending> pending_;
  std::vector<std::vector<uint64_t>> pend_by_tenant_;
  std::vector<std::deque<FlushRec>> flushq_;
  std::vector<Counters> counters_;
  std::vector<std::string> violations_;
  uint64_t seq_ = 0;
  unsigned power_losses_ = 0;
};

// ------------------------------------------------------------------------------------------------
// Random descriptor generator: valid commands and deliberately invalid ones with the verdict known
// *by construction* (not by calling Model::validate), so a test can cross-check model and DUT.
// ------------------------------------------------------------------------------------------------
enum Fault : int {
  F_NONE = -1,
  F_VERSION = 0,      // rule 1
  F_OPCODE,           // 2
  F_CLAIM,            // 3
  F_RSV_FLAGS,        // 4  FLAGS[15:3] != 0
  F_RSV_W1,           // 4  word1[31:24]
  F_RSV_W8,           // 4  word8[31:16]
  F_RSV_W10_15,       // 4  words 10..15
  F_HOSTCRC_NZ,       // 4  HOST_CRC != 0 without HCRC   (ambiguous, Q-05)
  F_HCRC_NONWRITE,    // 4  FLAGS
  F_FUA_NONWRITE,     // 4  FLAGS
  F_RCRC_NONDATA,     // 4  FLAGS
  F_NS_NOEXIST,       // 5
  F_NS_FOREIGN,       // 5
  F_NS_UNCONFIGURED,  // 5
  F_UNSUP_DISCARD,    // 6
  F_NS_READONLY,      // 7
  F_LEN_ZERO,         // 8
  F_LEN_TOO_LARGE,    // 8
  F_LEN_MISMATCH,     // 8
  F_LEN_NOTZERO_NBLK, // 8  FLUSH/GET_CAPACITY with NBLK != 0
  F_LEN_NOTZERO_DLEN, // 8  FLUSH/GET_CAPACITY/DISCARD with DATA_LEN != 0
  F_ADDR_ALIGN,       // 9  READ/WRITE misaligned
  F_ADDR_NOTZERO,     // 9  non-data op with DATA_ADDR != 0
  F_RANGE_PAST_END,   // 10 LBA+NBLK = SIZE+1 (and a bit beyond)
  F_RANGE_LBA_HIGH,   // 10 LBA near 2^64
  F_RANGE_OVERFLOW,   // 10 LBA+NBLK == 2^64 exactly (wraps to 0 in 64-bit)
  F_KEY_NOT_READY,    // 11
  F__COUNT
};
struct FaultInfo {
  int rule;
  uint8_t status, detail;
  const char* name;
  bool ambiguous;
};
inline FaultInfo fault_info(Fault f, const Interp& ip = Interp()) {
  switch (f) {
    case F_VERSION: return {1, ST_INVALID_FIELD, DET_VERSION, "VERSION", false};
    case F_OPCODE: return {2, ST_INVALID_OPCODE, 0, "OPCODE", false};
    case F_CLAIM: return {3, ST_TENANT_MISMATCH, 0, "CLAIM", false};
    case F_RSV_FLAGS: return {4, ST_INVALID_FIELD, ip.rsv_flags_detail, "RSV_FLAGS", ip.rsv_flags_detail != DET_RESERVED};
    case F_RSV_W1: return {4, ST_INVALID_FIELD, DET_RESERVED, "RSV_W1", false};
    case F_RSV_W8: return {4, ST_INVALID_FIELD, DET_RESERVED, "RSV_W8", false};
    case F_RSV_W10_15: return {4, ST_INVALID_FIELD, DET_RESERVED, "RSV_W10_15", false};
    case F_HOSTCRC_NZ: return {4, ST_INVALID_FIELD, ip.hostcrc_nz_is_flags ? DET_FLAGS : DET_RESERVED, "HOSTCRC_NZ", true};
    case F_HCRC_NONWRITE: return {4, ST_INVALID_FIELD, DET_FLAGS, "HCRC_NONWRITE", false};
    case F_FUA_NONWRITE: return {4, ST_INVALID_FIELD, DET_FLAGS, "FUA_NONWRITE", false};
    case F_RCRC_NONDATA: return {4, ST_INVALID_FIELD, DET_FLAGS, "RCRC_NONDATA", false};
    case F_NS_NOEXIST: return {5, ST_INVALID_NS, 0, "NS_NOEXIST", false};
    case F_NS_FOREIGN: return {5, ST_INVALID_NS, 0, "NS_FOREIGN", false};
    case F_NS_UNCONFIGURED: return {5, ST_INVALID_NS, 0, "NS_UNCONFIGURED", false};
    case F_UNSUP_DISCARD: return {6, ST_UNSUPPORTED, 0, "UNSUP_DISCARD", false};
    case F_NS_READONLY: return {7, ST_NS_READONLY, 0, "NS_READONLY", false};
    case F_LEN_ZERO: return {8, ST_LEN_ERROR, DET_LEN_ZERO, "LEN_ZERO", false};
    case F_LEN_TOO_LARGE: return {8, ST_LEN_ERROR, DET_LEN_TOO_LARGE, "LEN_TOO_LARGE", false};
    case F_LEN_MISMATCH: return {8, ST_LEN_ERROR, DET_LEN_MISMATCH, "LEN_MISMATCH", false};
    case F_LEN_NOTZERO_NBLK: return {8, ST_LEN_ERROR, DET_LEN_NOT_ZERO, "LEN_NOTZERO_NBLK", false};
    case F_LEN_NOTZERO_DLEN: return {8, ST_LEN_ERROR, DET_LEN_NOT_ZERO, "LEN_NOTZERO_DLEN", false};
    case F_ADDR_ALIGN: return {9, ST_INVALID_FIELD, DET_ADDR_ALIGN, "ADDR_ALIGN", false};
    case F_ADDR_NOTZERO: return {9, ST_INVALID_FIELD, DET_ADDR_ALIGN, "ADDR_NOTZERO", false};
    case F_RANGE_PAST_END: return {10, ST_LBA_RANGE, 0, "RANGE_PAST_END", false};
    case F_RANGE_LBA_HIGH: return {10, ST_LBA_RANGE, 0, "RANGE_LBA_HIGH", false};
    case F_RANGE_OVERFLOW: return {10, ST_LBA_RANGE, 0, "RANGE_OVERFLOW", false};
    case F_KEY_NOT_READY: return {11, ST_CRYPTO_ERROR, DET_KEY_NOT_READY, "KEY_NOT_READY", false};
    default: return {0, 0, 0, "NONE", false};
  }
}

struct GenCmd {
  bool valid_cmd = false;           // false if the generator could not build the request (see Gen::can_*)
  uint32_t w[DESC_WORDS] = {};
  std::vector<uint8_t> payload;     // WRITE data (NBLK*512 bytes) when the descriptor is a WRITE
  unsigned tenant = 0, hw_binding = 0;
  Verdict expect;                   // verdict known by construction
  Fault fault = F_NONE;             // primary injected fault
  int stacked = 0;                  // number of additional later-rule faults stacked on top
  bool bad_hcrc = false;            // valid descriptor but HOST_CRC deliberately wrong (-> DATA_CRC at execution)
  uint8_t opcode = 0;
};

struct GenOpts {
  unsigned p_invalid_pct = 30;   // next(): share of invalid commands
  unsigned hot_lbas = 0;         // if > 0, valid LBAs are drawn from [0, hot_lbas) to force overlaps
  bool allow_ambiguous = false;  // include faults whose verdict depends on Q-nn interpretation
  unsigned p_bad_hcrc_pct = 0;   // share of HCRC writes with a wrong HOST_CRC
  bool stack = true;             // invalid(): randomly stack later-rule faults
};

class Gen {
 public:
  Gen(const Model& m, uint64_t seed, GenOpts o = GenOpts()) : m_(m), o_(o), s_(seed * 0x9E3779B97F4A7C15ull + 0x1234567ull) {
    for (int i = 0; i < 4; ++i) rnd();
  }
  GenOpts& opts() { return o_; }
  uint64_t rnd() {  // xorshift64*: deterministic across platforms
    s_ ^= s_ >> 12;
    s_ ^= s_ << 25;
    s_ ^= s_ >> 27;
    return s_ * 0x2545F4914F6CDD1Dull;
  }
  uint64_t rnd(uint64_t n) { return n ? rnd() % n : 0; }

  // Does `tenant` own at least one valid namespace?
  bool has_ns(unsigned tenant) const { return !owned(tenant, Any).empty(); }
  bool applicable(unsigned tenant, Fault f) const {
    switch (f) {
      case F_NS_FOREIGN: return foreign_ns(tenant) >= 0;
      case F_NS_UNCONFIGURED: return unconfigured_ns() >= 0;
      case F_UNSUP_DISCARD: return !m_.discard_supported() && has_ns(tenant);
      case F_NS_READONLY: return !owned(tenant, ReadOnly).empty();
      case F_KEY_NOT_READY: return !owned(tenant, EncNotReady).empty();
      case F_LEN_ZERO: case F_LEN_TOO_LARGE: case F_LEN_MISMATCH: case F_LEN_NOTZERO_NBLK: case F_LEN_NOTZERO_DLEN:
      case F_ADDR_ALIGN: case F_ADDR_NOTZERO: case F_RANGE_PAST_END: case F_RANGE_LBA_HIGH: case F_RANGE_OVERFLOW:
        return has_ns(tenant);
      case F_HOSTCRC_NZ: return o_.allow_ambiguous;
      default: return true;
    }
  }

  // A valid command of the given opcode (0 = random mix).  `valid_cmd == false` if impossible.
  GenCmd valid(unsigned tenant, uint8_t opcode = 0) {
    GenCmd g;
    g.tenant = g.hw_binding = tenant;
    int ns = -1;
    if (opcode == 0) {
      for (int tries = 0; tries < 12 && ns < 0; ++tries) {
        opcode = pick_opcode(tenant);
        ns = choose_ns(tenant, opcode);
      }
      if (ns < 0) {
        opcode = OP_FLUSH;
        ns = choose_ns(tenant, opcode);
      }
    } else {
      ns = choose_ns(tenant, opcode);
    }
    if (ns < 0) return g;
    build(g, tenant, opcode, unsigned(ns));
    g.valid_cmd = true;
    return g;
  }
  // A command that fails *exactly* the rule of `f` (earlier rules pass).  With stacking, additional
  // faults of strictly later rules are added; the expected verdict is still that of `f`.
  GenCmd invalid(unsigned tenant, Fault f, bool stack) {
    GenCmd g;
    g.tenant = g.hw_binding = tenant;
    g.fault = f;
    if (!applicable(tenant, f)) return g;
    const FaultInfo fi = fault_info(f, m_.interp());
    uint8_t op = fault_opcode(tenant, f);
    int ns = choose_ns_for_fault(tenant, f, op);
    if (ns < 0) {  // rules <= 5 do not need a usable namespace
      if (fi.rule > 5) return g;
      ns = 0;
    }
    build_loose(g, tenant, op, unsigned(ns));
    apply_fault(g, f, unsigned(ns));
    g.expect = Verdict();
    g.expect.ok = false;
    g.expect.rule = fi.rule;
    g.expect.status = fi.status;
    g.expect.detail = fi.detail;
    if (stack) stack_faults(g, fi.rule);
    g.valid_cmd = true;
    return g;
  }
  // Mix of valid / invalid according to GenOpts.
  GenCmd next(unsigned tenant) {
    if (rnd(100) < o_.p_invalid_pct) {
      for (int tries = 0; tries < 16; ++tries) {
        Fault f = Fault(rnd(F__COUNT));
        if (!applicable(tenant, f)) continue;
        GenCmd g = invalid(tenant, f, o_.stack && (rnd(2) != 0));
        if (g.valid_cmd) return g;
      }
    }
    return valid(tenant);
  }

 private:
  enum Pred { Any, Writable, ReadOnly, DataOk, WritableDataOk, EncNotReady };
  const Model& m_;
  GenOpts o_;
  uint64_t s_;

  bool pred_ok(unsigned n, Pred p) const {
    const NsCfg& c = m_.ns_cfg(n);
    const bool key_ok = !c.enc || m_.key_ready(c.key_slot);
    switch (p) {
      case Any: return true;
      case Writable: return !c.readonly;
      case ReadOnly: return c.readonly;
      case DataOk: return key_ok;
      case WritableDataOk: return key_ok && !c.readonly;
      case EncNotReady: return c.enc && !m_.key_ready(c.key_slot);
    }
    return false;
  }
  std::vector<unsigned> owned(unsigned tenant, Pred p) const {
    std::vector<unsigned> v;
    for (unsigned n = 0; n < m_.ns_n(); ++n)
      if (m_.ns_valid(n) && m_.ns_cfg(n).owner == tenant && pred_ok(n, p)) v.push_back(n);
    return v;
  }
  int pick(const std::vector<unsigned>& v) { return v.empty() ? -1 : int(v[rnd(v.size())]); }
  int foreign_ns(unsigned tenant) const {
    for (unsigned n = 0; n < m_.ns_n(); ++n)
      if (m_.ns_valid(n) && m_.ns_cfg(n).owner != tenant) return int(n);
    return -1;
  }
  int unconfigured_ns() const {
    for (unsigned n = 0; n < m_.ns_n(); ++n)
      if (!m_.ns_valid(n)) return int(n);
    return -1;
  }
  uint8_t pick_opcode(unsigned tenant) {
    (void)tenant;
    const unsigned r = unsigned(rnd(100));
    if (r < 35) return OP_READ;
    if (r < 70) return OP_WRITE;
    if (r < 80) return OP_FLUSH;
    if (r < 86) return OP_GET_CAPACITY;
    return m_.discard_supported() ? OP_DISCARD : OP_READ;
  }
  int choose_ns(unsigned tenant, uint8_t op) {
    switch (op) {
      case OP_WRITE: return pick(owned(tenant, WritableDataOk));
      case OP_READ: return pick(owned(tenant, DataOk));
      case OP_DISCARD: return pick(owned(tenant, m_.interp().key_all_ops ? WritableDataOk : Writable));
      default: return pick(owned(tenant, m_.interp().key_all_ops ? DataOk : Any));
    }
  }
  uint8_t fault_opcode(unsigned tenant, Fault f) {
    auto any_op = [&]() { return uint8_t(1 + rnd(5)); };
    switch (f) {
      case F_HCRC_NONWRITE: case F_FUA_NONWRITE: {
        static const uint8_t ops[] = {OP_READ, OP_FLUSH, OP_GET_CAPACITY, OP_DISCARD};
        return ops[rnd(4)];
      }
      case F_RCRC_NONDATA: {
        static const uint8_t ops[] = {OP_FLUSH, OP_GET_CAPACITY, OP_DISCARD};
        return ops[rnd(3)];
      }
      case F_UNSUP_DISCARD: return OP_DISCARD;
      case F_NS_READONLY: return (m_.discard_supported() && rnd(2)) ? OP_DISCARD : OP_WRITE;
      case F_LEN_ZERO: case F_LEN_TOO_LARGE: case F_LEN_MISMATCH: case F_ADDR_ALIGN: case F_RANGE_PAST_END:
      case F_RANGE_LBA_HIGH: case F_RANGE_OVERFLOW: {
        uint8_t ops[3] = {OP_READ, OP_WRITE, OP_DISCARD};
        uint8_t o = ops[rnd(3)];
        if (o == OP_DISCARD && !m_.discard_supported()) o = OP_READ;
        if (f == F_LEN_MISMATCH && o == OP_DISCARD) o = OP_WRITE;  // MISMATCH is a READ/WRITE rule
        return o;
      }
      case F_LEN_NOTZERO_NBLK: return rnd(2) ? OP_FLUSH : OP_GET_CAPACITY;
      case F_LEN_NOTZERO_DLEN: {
        uint8_t o = uint8_t(OP_FLUSH + rnd(3));  // FLUSH, GET_CAPACITY, DISCARD
        if (o == OP_DISCARD && !m_.discard_supported()) o = OP_FLUSH;
        return o;
      }
      case F_ADDR_NOTZERO: {
        uint8_t o = uint8_t(OP_FLUSH + rnd(3));
        if (o == OP_DISCARD && !m_.discard_supported()) o = OP_GET_CAPACITY;
        return o;
      }
      case F_KEY_NOT_READY: {
        bool w_ok = false;
        for (unsigned n : owned(tenant, EncNotReady)) w_ok = w_ok || !m_.ns_cfg(n).readonly;
        return (w_ok && rnd(2)) ? OP_WRITE : OP_READ;
      }
      default: return any_op();
    }
  }
  int choose_ns_for_fault(unsigned tenant, Fault f, uint8_t op) {
    switch (f) {
      case F_NS_READONLY: return pick(owned(tenant, ReadOnly));
      case F_KEY_NOT_READY: {
        auto v = owned(tenant, EncNotReady);
        std::vector<unsigned> w;
        for (unsigned n : v)
          if (op != OP_WRITE || !m_.ns_cfg(n).readonly) w.push_back(n);
        return pick(w);
      }
      case F_UNSUP_DISCARD: return pick(owned(tenant, Any));
      case F_NS_NOEXIST: case F_NS_FOREIGN: case F_NS_UNCONFIGURED: return pick(owned(tenant, Any));
      case F_LEN_ZERO: case F_LEN_TOO_LARGE: case F_LEN_MISMATCH: case F_LEN_NOTZERO_NBLK: case F_LEN_NOTZERO_DLEN:
      case F_ADDR_ALIGN: case F_ADDR_NOTZERO: case F_RANGE_PAST_END: case F_RANGE_LBA_HIGH: case F_RANGE_OVERFLOW:
        // earlier rules (readonly = 7) must pass: pick a writable, key-ready namespace when the opcode writes
        if (op == OP_WRITE || op == OP_DISCARD) return pick(owned(tenant, op == OP_WRITE ? WritableDataOk : Writable));
        if (op == OP_READ) return pick(owned(tenant, DataOk));
        return pick(owned(tenant, Any));
      default: return pick(owned(tenant, Any));
    }
  }

  // Build a descriptor with valid field values for `op` on `ns` (the namespace is assumed usable).
  void build(GenCmd& g, unsigned tenant, uint8_t op, unsigned ns) {
    build_loose(g, tenant, op, ns);
    g.expect = Verdict();
  }
  // Same, but does not insist that the namespace passes rules 6..11 (callers inject their own fault).
  void build_loose(GenCmd& g, unsigned tenant, uint8_t op, unsigned ns) {
    Desc d;
    d.version = 1;
    d.opcode = op;
    d.txn = uint16_t(rnd(0x10000));
    d.nsid = uint8_t(ns);
    d.claim = uint16_t(tenant);
    g.opcode = op;
    const uint64_t size = ns < m_.ns_n() && m_.ns_valid(ns) ? m_.ns_cfg(ns).size : 1;
    if (op == OP_READ || op == OP_WRITE || op == OP_DISCARD) {
      uint64_t maxn = op == OP_DISCARD ? DISCARD_MAX : m_.mdts();
      if (maxn > size) maxn = size;
      if (maxn == 0) maxn = 1;
      uint32_t nblk;
      if (op == OP_DISCARD) nblk = rnd(8) == 0 ? uint32_t(1 + rnd(maxn)) : uint32_t(1 + rnd(std::min<uint64_t>(maxn, 32)));
      else {
        const unsigned r = unsigned(rnd(8));
        nblk = r == 0 ? 1 : r == 1 ? uint32_t(maxn) : uint32_t(1 + rnd(maxn));
      }
      d.nblk = nblk;
      uint64_t span = size >= nblk ? size - nblk + 1 : 1;  // number of legal start positions
      if (o_.hot_lbas && o_.hot_lbas < span) span = o_.hot_lbas;
      const unsigned r = unsigned(rnd(10));
      d.lba = (r == 0) ? 0 : (r == 1 && !o_.hot_lbas) ? span - 1 : rnd(span);
      if (op != OP_DISCARD) {
        d.data_len = nblk * BLOCK_BYTES;
        d.data_addr = rnd() & ~uint64_t(3);
      }
      if (op == OP_READ && rnd(4) == 0) d.flags |= F_RCRC;
      if (op == OP_WRITE) {
        if (rnd(4) == 0) d.flags |= F_RCRC;
        if (m_.features().fua && rnd(4) == 0) d.flags |= F_FUA;
        g.payload.resize(size_t(nblk) * BLOCK_BYTES);
        fill_payload(g.payload);
        if (m_.features().hcrc && rnd(3) == 0) {
          d.flags |= F_HCRC;
          d.host_crc = crc32c(g.payload.data(), g.payload.size());
          if (rnd(100) < o_.p_bad_hcrc_pct) {
            d.host_crc ^= uint32_t(1u << rnd(32));
            g.bad_hcrc = true;
          }
        }
      }
    }
    encode(d, g.w);
  }
  void fill_payload(std::vector<uint8_t>& p) {
    const unsigned mode = unsigned(rnd(4));
    if (mode == 0) {  // constant fill
      std::fill(p.begin(), p.end(), uint8_t(rnd(256)));
    } else if (mode == 1) {  // all zeros (indistinguishable from unwritten: weak, so keep it rare)
      const uint8_t b = rnd(8) == 0 ? 0 : uint8_t(1 + rnd(255));
      std::fill(p.begin(), p.end(), b);
    } else {
      for (size_t i = 0; i < p.size(); i += 8) {
        const uint64_t r = rnd();
        for (size_t k = 0; k < 8 && i + k < p.size(); ++k) p[i + k] = uint8_t(r >> (8 * k));
      }
    }
  }

  void apply_fault(GenCmd& g, Fault f, unsigned ns) {
    Desc d = decode(g.w);
    const uint8_t op = d.opcode;
    const NsCfg* c = (ns < m_.ns_n() && m_.ns_valid(ns)) ? &m_.ns_cfg(ns) : nullptr;
    switch (f) {
      case F_VERSION: do d.version = uint8_t(rnd(256)); while (d.version == 1); break;
      case F_OPCODE: {
        do d.opcode = uint8_t(rnd(256)); while (d.opcode >= OP_WRITE && d.opcode <= OP_DISCARD);
        g.opcode = d.opcode;
        g.payload.clear();
        break;
      }
      case F_CLAIM: {  // the descriptor claims somebody else; the hardware binding (= queue's tenant) is unchanged
        do d.claim = uint16_t(rnd(4) == 0 ? rnd(0x10000) : rnd(m_.nt() + 3)); while (d.claim == g.hw_binding);
        break;
      }
      case F_RSV_FLAGS: d.flags |= uint16_t((1 + rnd(0x1FFF)) << 3); break;
      case F_RSV_W1: d.rsv1 = uint8_t(1 + rnd(255)); break;
      case F_RSV_W8: d.rsv8 = uint16_t(1 + rnd(0xFFFF)); break;
      case F_RSV_W10_15: {
        const unsigned wi = 10 + unsigned(rnd(6));
        d.raw[wi] = uint32_t(1u << rnd(32));
        break;
      }
      case F_HOSTCRC_NZ: d.flags &= uint16_t(~F_HCRC); d.host_crc = uint32_t(1 + rnd(0xFFFFFFFEu)); break;
      case F_HCRC_NONWRITE: d.flags |= F_HCRC; d.host_crc = uint32_t(rnd()); break;
      case F_FUA_NONWRITE: d.flags |= F_FUA; break;
      case F_RCRC_NONDATA: d.flags |= F_RCRC; break;
      case F_NS_NOEXIST: d.nsid = uint8_t(m_.ns_n() + rnd(256 - m_.ns_n())); break;
      case F_NS_FOREIGN: d.nsid = uint8_t(foreign_ns(g.tenant)); break;
      case F_NS_UNCONFIGURED: d.nsid = uint8_t(unconfigured_ns()); break;
      case F_UNSUP_DISCARD: break;  // already DISCARD on a backend without it
      case F_NS_READONLY: break;    // WRITE/DISCARD on a read-only namespace
      case F_LEN_ZERO: d.nblk = 0; break;
      case F_LEN_TOO_LARGE:
        d.nblk = op == OP_DISCARD ? uint32_t(DISCARD_MAX + 1 + rnd(1000)) : uint32_t(m_.mdts() + 1 + rnd(8));
        if (op != OP_DISCARD) d.data_len = d.nblk * BLOCK_BYTES;  // keep DATA_LEN consistent: TOO_LARGE precedes MISMATCH anyway
        break;
      case F_LEN_MISMATCH: do d.data_len = uint32_t(rnd(rnd(2) ? 16384ull : 4294967296ull)); while (d.data_len == d.nblk * BLOCK_BYTES); break;
      case F_LEN_NOTZERO_NBLK: d.nblk = uint32_t(1 + rnd(0xFFFFFFFEu)); d.data_len = 0; break;
      case F_LEN_NOTZERO_DLEN: d.nblk = (op == OP_DISCARD) ? d.nblk : 0; d.data_len = uint32_t(1 + rnd(0xFFFFFFFEu)); break;
      case F_ADDR_ALIGN: d.data_addr = (d.data_addr & ~uint64_t(3)) | (1 + rnd(3)); break;
      case F_ADDR_NOTZERO: d.data_addr = rnd(2) ? (rnd() | 1u) : ((rnd() & ~uint64_t(3)) | 4u); break;
      case F_RANGE_PAST_END: {
        const uint64_t size = c ? c->size : 1;
        const uint64_t nb = d.nblk;
        uint64_t lba = size >= nb ? size - nb + 1 : 0;  // LBA+NBLK == SIZE+1, or NBLK > SIZE
        if (size >= nb) lba += rnd(3);
        if (lba + nb < lba) lba = size - nb + 1;
        d.lba = lba;
        break;
      }
      case F_RANGE_LBA_HIGH: d.lba = ~uint64_t(0); if (!c || c->size < ~uint64_t(0) - 16) d.lba -= rnd(16); break;
      case F_RANGE_OVERFLOW: d.lba = uint64_t(0) - uint64_t(d.nblk); break;  // LBA+NBLK == 2^64
      case F_KEY_NOT_READY: break;  // namespace chosen with ENC_EN and an unready key
      default: break;
    }
    // For range faults keep everything before rule 10 legal: nblk/len already valid from build_loose.
    uint32_t w[DESC_WORDS];
    encode(d, w);
    std::memcpy(g.w, w, sizeof(w));
    if (f == F_OPCODE) g.opcode = d.opcode;
  }

  // Add faults of strictly later rules.  Each mutator only touches fields that no earlier rule reads.
  void stack_faults(GenCmd& g, int rule) {
    Desc d = decode(g.w);
    const uint8_t op = d.opcode;
    const bool opv = op >= OP_WRITE && op <= OP_DISCARD;
    int n = 0;
    if (rule < 2 && rnd(2)) { do d.opcode = uint8_t(rnd(256)); while (d.opcode >= OP_WRITE && d.opcode <= OP_DISCARD); ++n; }
    if (rule < 3 && rnd(2)) { do d.claim = uint16_t(rnd(m_.nt() + 3)); while (d.claim == g.hw_binding); ++n; }
    if (rule < 4 && rnd(2)) {  // exactly ONE rule-4 mutation (their relative order is a Q-nn)
      if (rnd(2)) d.rsv8 = uint16_t(1 + rnd(0xFFFF));
      else if (opv && op != OP_WRITE) d.flags |= F_FUA;
      else d.raw[10 + rnd(6)] = 1;
      ++n;
    }
    if (rule < 5 && rnd(2)) { d.nsid = uint8_t(m_.ns_n() + rnd(256 - m_.ns_n())); ++n; }
    const bool data = op == OP_READ || op == OP_WRITE;
    if (rule < 8 && opv && rnd(2)) {
      if (data || op == OP_DISCARD) d.nblk = 0; else d.nblk = 1 + uint32_t(rnd(100));
      ++n;
    }
    if (rule < 9 && opv && rnd(2)) {
      if (data) d.data_addr |= 1; else d.data_addr = 4;
      ++n;
    }
    if (rule < 10 && opv && (data || op == OP_DISCARD) && rnd(2)) { d.lba = ~uint64_t(0); ++n; }
    uint32_t w[DESC_WORDS];
    encode(d, w);
    std::memcpy(g.w, w, sizeof(w));
    g.stacked = n;
    if (d.opcode != op) g.opcode = d.opcode;
  }
};

}  // namespace sfref

#endif  // SFREF_HPP
