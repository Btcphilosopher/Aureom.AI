// test_sfref.cpp - self-test of model/sfref.hpp.  Plain checks, prints PASS/FAIL counts, exits non-zero on failure.
// Everything expected here is derived from docs/02_HOST_INTERFACE.md, not from sfref.hpp internals.
#include <cstdio>
#include <cstdlib>
#include <deque>
#include <map>
#include <set>

#include "sfref.hpp"

using namespace sfref;

static int g_pass = 0, g_fail = 0;
#define CHECK(c)                                                         \
  do {                                                                   \
    if (c) ++g_pass;                                                     \
    else {                                                               \
      ++g_fail;                                                          \
      std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #c);           \
    }                                                                    \
  } while (0)
#define CHECK_MSG(c, msg)                                                \
  do {                                                                   \
    if (c) ++g_pass;                                                     \
    else {                                                               \
      ++g_fail;                                                          \
      std::printf("FAIL %s:%d: %s  [%s]\n", __FILE__, __LINE__, #c, std::string(msg).c_str()); \
    }                                                                    \
  } while (0)
static void section(const char* s) { std::printf("-- %s\n", s); }

// ---------------------------------------------------------------------------------------------
// Descriptor builder (independent of encode(): packs words by hand from the §2 table)
// ---------------------------------------------------------------------------------------------
struct W {
  uint32_t w[16];
  uint32_t& operator[](int i) { return w[i]; }
};
static W mk(uint8_t op, unsigned nsid, uint64_t lba, uint32_t nblk, uint32_t dlen, uint64_t addr, unsigned claim,
            uint16_t flags = 0, uint32_t hcrc = 0, uint16_t txn = 0xBEEF) {
  W c;
  std::memset(c.w, 0, sizeof(c.w));
  c.w[0] = 1u | (uint32_t(op) << 8) | (uint32_t(flags) << 16);
  c.w[1] = uint32_t(txn) | (uint32_t(nsid) << 16);
  c.w[2] = uint32_t(lba & 0xFFFFFFFFu);
  c.w[3] = uint32_t(lba >> 32);
  c.w[4] = nblk;
  c.w[5] = dlen;
  c.w[6] = uint32_t(addr & 0xFFFFFFFFu);
  c.w[7] = uint32_t(addr >> 32);
  c.w[8] = claim;
  c.w[9] = hcrc;
  return c;
}
static W rd(unsigned t, unsigned ns, uint64_t lba, uint32_t n, uint16_t fl = 0) {
  return mk(OP_READ, ns, lba, n, n * 512, 0x1000, t, fl);
}
static W wr(unsigned t, unsigned ns, uint64_t lba, uint32_t n, uint16_t fl = 0, uint32_t hcrc = 0) {
  return mk(OP_WRITE, ns, lba, n, n * 512, 0x2000, t, fl, hcrc);
}
static W flush(unsigned t, unsigned ns) { return mk(OP_FLUSH, ns, 0, 0, 0, 0, t); }
static W getcap(unsigned t, unsigned ns) { return mk(OP_GET_CAPACITY, ns, 0, 0, 0, 0, t); }
static W disc(unsigned t, unsigned ns, uint64_t lba, uint32_t n) { return mk(OP_DISCARD, ns, lba, n, 0, 0, t); }

static Verdict V(const Model& m, unsigned t, W c) { return m.validate(t, c.w, t); }
static bool is(const Verdict& v, uint8_t st, uint8_t det, int rule) {
  return !v.ok && v.status == st && v.detail == det && v.rule == rule;
}
static bool okv(const Verdict& v) { return v.ok && v.status == ST_SUCCESS && v.detail == 0 && v.rule == 0; }

// Standard model M0:  nt=4, ns_n=8, mdts=8, 1 Mi block backend
//   ns0 t0 rw   base 0     size 1024
//   ns1 t0 RO   base 1024  size 64
//   ns2 t1 ENC  base 2048  size 512  key slot 3 (NOT ready)
//   ns3 t0 PI   base 4096  size 100
//   ns4 t2 rw   base 8192  size 256
//   ns5..7 unconfigured; tenant 3 owns nothing
static Model make_m0(bool vol = true, bool discard = true, bool dz = true, bool pi = true, Interp ip = Interp(),
                     Features ft = Features()) {
  BackendCaps c;
  c.capacity_blocks = 1u << 20;
  c.volatile_cache = vol;
  c.discard = discard;
  c.discard_zero = dz;
  c.pi_native = pi;
  Model m(4, 8, 8, c, ip, ft);
  NsCfg n;
  n = NsCfg();
  n.owner = 0; n.base = 0; n.size = 1024;
  CHECK(m.cfg_ns(0, n).accepted);
  n = NsCfg();
  n.owner = 0; n.base = 1024; n.size = 64; n.readonly = true;
  CHECK(m.cfg_ns(1, n).accepted);
  n = NsCfg();
  n.owner = 1; n.base = 2048; n.size = 512; n.enc = true; n.key_slot = 3;
  CHECK(m.cfg_ns(2, n).accepted);
  if (pi) {
    n = NsCfg();
    n.owner = 0; n.base = 4096; n.size = 100; n.pi = true;
    CHECK(m.cfg_ns(3, n).accepted);
  }
  n = NsCfg();
  n.owner = 2; n.base = 8192; n.size = 256;
  CHECK(m.cfg_ns(4, n).accepted);
  return m;
}

static std::vector<uint8_t> fillv(uint32_t nblk, uint8_t b) { return std::vector<uint8_t>(size_t(nblk) * 512, b); }

// ---------------------------------------------------------------------------------------------
static void test_crc() {
  section("CRC-32C (§6.1)");
  CHECK(crc32c("123456789", 9) == 0xE3069283u);
  CHECK(crc32c("", 0) == 0u);
  uint8_t z[32] = {}, f[32], inc[32], dec[32];
  for (int i = 0; i < 32; ++i) { f[i] = 0xFF; inc[i] = uint8_t(i); dec[i] = uint8_t(31 - i); }
  CHECK(crc32c(z, 32) == 0x8A9136AAu);  // RFC 3720 B.4 vectors
  CHECK(crc32c(f, 32) == 0x62A8AB43u);
  CHECK(crc32c(inc, 32) == 0x46DD794Eu);
  CHECK(crc32c(dec, 32) == 0x113FDB5Cu);
  CHECK(crc32c("6789", 4, crc32c("12345", 5)) == 0xE3069283u);  // chaining
}

static void test_pi_trailer() {
  section("PI trailer layout (§6.1)");
  uint8_t blk[512];
  for (int i = 0; i < 512; ++i) blk[i] = uint8_t(i * 7);
  auto t = pi_trailer(blk, 3, 5, 0x0123456789ABull);
  uint32_t g = crc32c(blk, 512);
  CHECK(t[0] == uint8_t(g) && t[1] == uint8_t(g >> 8) && t[2] == uint8_t(g >> 16) && t[3] == uint8_t(g >> 24));
  CHECK(t[4] == 0x05 && t[5] == 0x03);  // default: NSID | (TENANT<<8) (docs/02 §6.1 after the Q-17 erratum)
  auto t12 = pi_trailer(blk, 3, 5, 0, 12);
  CHECK(t12[4] == 0x05 && t12[5] == 0x30);  // {TENANT[3:0],4'b0,NSID}: the superseded reading (Q-17)
  CHECK(t[6] == 0xAB && t[7] == 0x89 && t[8] == 0x67 && t[9] == 0x45 && t[10] == 0x23 && t[11] == 0x01);
  CHECK(t[12] == 1 && t[13] == 0 && t[14] == 0 && t[15] == 0);
}

static void test_codec() {
  section("descriptor / CQE codec");
  uint32_t w[16];
  for (int i = 0; i < 16; ++i) w[i] = 0x01234567u * (i + 3);
  Desc d = decode(w);
  uint32_t w2[16];
  encode(d, w2);
  CHECK(std::memcmp(w, w2, sizeof(w)) == 0);
  W c = mk(OP_WRITE, 0x7B, 0x1122334455667788ull, 8, 4096, 0xAABBCCDDEEFF0010ull, 0x0102, F_FUA | F_RCRC, 0xCAFEF00D, 0x4321);
  Desc e = decode(c.w);
  CHECK(e.version == 1 && e.opcode == OP_WRITE && e.flags == (F_FUA | F_RCRC) && e.txn == 0x4321 && e.nsid == 0x7B);
  CHECK(e.lba == 0x1122334455667788ull && e.nblk == 8 && e.data_len == 4096 && e.data_addr == 0xAABBCCDDEEFF0010ull);
  CHECK(e.claim == 0x0102 && e.host_crc == 0xCAFEF00Du && e.rsv1 == 0 && e.rsv8 == 0);

  // CQE: pack by hand per the §3 table
  uint32_t q[8] = {};
  q[0] = 0x1234u | (0x0Bu << 16) | (0x02u << 24);
  q[1] = 1u | 2u | 8u | (0x02u << 8) | (77u << 16);
  q[2] = 0xDEADBEEFu;
  q[3] = 0x11u;
  q[4] = 9u | (3u << 16);
  q[5] = 1000u;
  q[7] = 1u;
  Cqe c2 = decode_cqe(q);
  CHECK(c2.txn == 0x1234 && c2.status == 0x0B && c2.detail == 2 && c2.durable && c2.pi_verified && !c2.encrypted && c2.crc_valid);
  CHECK(c2.opcode == 2 && c2.nblk_done == 77 && c2.result0 == 0xDEADBEEFu && c2.result1 == 0x11 && c2.sq_head == 9 &&
        c2.tenant == 3 && c2.latency == 1000 && c2.phase && c2.w6 == 0 && c2.w7_rsv == 0 && c2.w1_rsv == 0);
}

// ---------------------------------------------------------------------------------------------
static void test_cfg_ns() {
  section("cfg_ns / NS_STATUS (§9)");
  BackendCaps c;
  c.capacity_blocks = 1000;
  Model m(2, 4, 8, c);
  NsCfg n;
  n.owner = 0; n.base = 0; n.size = 1000;
  NsStatus s = m.cfg_ns(0, n);  // exactly fits
  CHECK(s.accepted && s.reg() == NSS_ACCEPTED && m.ns_valid(0));
  n.base = 1; n.size = 1000;  // one block too many
  s = m.cfg_ns(1, n);
  CHECK(!s.accepted && s.reg() == NSS_NO_CAPACITY && !m.ns_valid(1));
  n.base = 1000; n.size = 1;
  s = m.cfg_ns(1, n);
  CHECK(!s.accepted && s.reg() == NSS_NO_CAPACITY);
  n.base = ~uint64_t(0); n.size = 2;  // 65-bit overflow must not wrap into capacity
  s = m.cfg_ns(1, n);
  CHECK(!s.accepted && s.reg() == NSS_NO_CAPACITY);
  n.base = 5; n.size = ~uint64_t(0);
  s = m.cfg_ns(1, n);
  CHECK(!s.accepted && s.reg() == NSS_NO_CAPACITY);
  // PI on a backend without PI_NATIVE: refused, stays invalid
  n = NsCfg(); n.owner = 0; n.base = 0; n.size = 10; n.pi = true;
  s = m.cfg_ns(1, n);
  CHECK(!s.accepted && s.reg() == NSS_PI_UNSUPPORTED && !m.ns_valid(1));
  // bad owner / zero size
  n = NsCfg(); n.owner = 2; n.base = 0; n.size = 10;  // nt == 2 -> owner 2 invalid
  s = m.cfg_ns(1, n);
  CHECK(!s.accepted && s.reg() == NSS_BAD_OWNER_SIZE);
  n = NsCfg(); n.owner = 1; n.base = 0; n.size = 0;
  s = m.cfg_ns(1, n);
  CHECK(!s.accepted && s.reg() == NSS_BAD_OWNER_SIZE && !m.ns_valid(1));
  // several reasons at once: `all` lists every one, `bits` picks one; consistent_with() is tolerant
  n = NsCfg(); n.owner = 9; n.base = 5000; n.size = 0; n.pi = true;
  s = m.cfg_ns(1, n);
  CHECK(s.all == (NSS_BAD_OWNER_SIZE | NSS_PI_UNSUPPORTED | NSS_NO_CAPACITY));
  CHECK(s.consistent_with(NSS_BAD_OWNER_SIZE) && s.consistent_with(NSS_NO_CAPACITY) && !s.consistent_with(NSS_ACCEPTED) &&
        !s.consistent_with(0));
  CHECK(!s.consistent_with(NSS_BAD_OWNER_SIZE | NSS_ACCEPTED));
  // refusal of a re-configuration leaves the namespace invalid (VALID had to be 0 to write the config)
  n = NsCfg(); n.owner = 1; n.base = 0; n.size = 10;
  CHECK(m.cfg_ns(2, n).accepted && m.ns_valid(2));
  n.size = 0;
  CHECK(!m.cfg_ns(2, n).accepted && !m.ns_valid(2));
  CHECK(m.cfg_ns(7, n).bad_index);  // nsid >= NS_N
  m.invalidate_ns(0);
  CHECK(!m.ns_valid(0));
  CHECK(m.owned_mask(0) == 0 && m.owned_mask(1) == 0);
  n = NsCfg(); n.owner = 1; n.base = 0; n.size = 10;
  CHECK(m.cfg_ns(3, n).accepted && m.cfg_ns(1, n).accepted);
  CHECK(m.owned_mask(1) == 0x0Au);  // NSIDs 1 and 3
}

// ---------------------------------------------------------------------------------------------
static void test_rules() {
  section("validation order §2 rules 1..11 (directed)");
  Model m = make_m0();
  const unsigned T0 = 0, T1 = 1, T2 = 2;

  // sanity: every opcode, valid
  CHECK(okv(V(m, T0, rd(0, 0, 0, 1))));
  CHECK(okv(V(m, T0, wr(0, 0, 0, 8))));
  CHECK(okv(V(m, T0, flush(0, 0))));
  CHECK(okv(V(m, T0, getcap(0, 0))));
  CHECK(okv(V(m, T0, disc(0, 0, 0, 16))));
  CHECK(okv(V(m, T0, rd(0, 1, 0, 1))));  // read of a read-only namespace is fine
  CHECK(okv(V(m, T0, flush(0, 1))));
  CHECK(okv(V(m, T0, getcap(0, 1))));
  CHECK(okv(V(m, T0, wr(0, 0, 0, 1, F_FUA | F_HCRC | F_RCRC, 0x1234))));  // all three flags on WRITE
  CHECK(okv(V(m, T0, rd(0, 0, 0, 1, F_RCRC))));

  // rule 1: VERSION
  for (unsigned v : {0u, 2u, 3u, 0x80u, 0xFFu}) {
    W c = rd(0, 0, 0, 1);
    c[0] = (c[0] & ~0xFFu) | v;
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_VERSION, 1));
  }
  { W c = mk(0x7F, 0, 0, 0, 0, 0, 3, 0xFFFF);  // bad everything: VERSION still wins
    c[0] &= ~0xFFu; c[1] |= 0xFF000000u;
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_VERSION, 1)); }

  // rule 2: OPCODE
  for (unsigned op : {0u, 6u, 7u, 0x10u, 0x80u, 0xFFu}) {
    W c = rd(0, 0, 0, 1);
    c[0] = (c[0] & ~0xFF00u) | (op << 8);
    CHECK(is(V(m, T0, c), ST_INVALID_OPCODE, 0, 2));
    c[8] = 3;  // + wrong claim: opcode precedes TENANT_CLAIM
    CHECK(is(V(m, T0, c), ST_INVALID_OPCODE, 0, 2));
  }
  { // opcode 5 is *legal* even on a backend without DISCARD (that is rule 6, not rule 2)
    Model nd = make_m0(true, false, false, true);
    CHECK(is(V(nd, T0, disc(0, 0, 0, 1)), ST_UNSUPPORTED, 0, 6)); }

  // rule 3: TENANT_CLAIM (compared with the hardware binding, not with the NS owner)
  for (unsigned cl : {1u, 2u, 3u, 4u, 0xFFFFu, 0x100u}) {
    CHECK(is(V(m, T0, rd(cl, 0, 0, 1)), ST_TENANT_MISMATCH, 0, 3));
  }
  CHECK(okv(V(m, T1, mk(OP_GET_CAPACITY, 2, 0, 0, 0, 0, 1))));  // tenant 1 claims 1 on its own ns
  {  // validate(tenant, w, hw_binding): the 3-arg form compares with hw_binding
    W c = rd(0, 0, 0, 1);
    CHECK(okv(m.validate(0, c.w, 0)));
    CHECK(is(m.validate(0, c.w, 1), ST_TENANT_MISMATCH, 0, 3));
  }
  { W c = rd(1, 0, 0, 1);  // claim is T1's id but it was fetched from T0's queue
    CHECK(is(V(m, T0, c), ST_TENANT_MISMATCH, 0, 3)); }
  { W c = rd(3, 200, 0, 0, F_HCRC); c[8] |= 0x30000;  // mismatch beats reserved + bad ns + len
    CHECK(is(V(m, T0, c), ST_TENANT_MISMATCH, 0, 3)); }

  // rule 4: reserved bits/words
  for (int b = 3; b < 16; ++b) {
    W c = rd(0, 0, 0, 1);
    c[0] |= 1u << (16 + b);
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_RESERVED, 4));
  }
  for (int b = 24; b < 32; ++b) {
    W c = rd(0, 0, 0, 1);
    c[1] |= 1u << b;
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_RESERVED, 4));
  }
  for (int b = 16; b < 32; ++b) {
    W c = rd(0, 0, 0, 1);
    c[8] |= 1u << b;
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_RESERVED, 4));
  }
  for (int wi = 10; wi < 16; ++wi)
    for (int b : {0, 7, 31}) {
      W c = rd(0, 0, 0, 1);
      c[wi] = 1u << b;
      CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_RESERVED, 4));
    }
  { W c = rd(0, 0, 0, 1); c[9] = 1;  // HOST_CRC must be 0 without HCRC (Q-05: RESERVED)
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_RESERVED, 4)); }
  { W c = wr(0, 0, 0, 1); c[9] = 0xFFFFFFFFu;
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_RESERVED, 4)); }
  CHECK(okv(V(m, T0, wr(0, 0, 0, 1, F_HCRC, 0))));  // HOST_CRC == 0 with HCRC is a legitimate CRC value
  // flag/opcode legality
  for (uint8_t op : {OP_READ, OP_FLUSH, OP_GET_CAPACITY, OP_DISCARD}) {
    W c = mk(op, 0, 0, 0, 0, 0, 0, F_HCRC, 0x55);
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_FLAGS, 4));
    c = mk(op, 0, 0, 0, 0, 0, 0, F_FUA);
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_FLAGS, 4));
  }
  for (uint8_t op : {OP_FLUSH, OP_GET_CAPACITY, OP_DISCARD}) {
    W c = mk(op, 0, 0, 0, 0, 0, 0, F_RCRC);
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_FLAGS, 4));
  }
  CHECK(okv(V(m, T0, rd(0, 0, 0, 1, F_RCRC))));
  CHECK(okv(V(m, T0, wr(0, 0, 0, 1, F_RCRC))));
  // rule 4 beats rules 5..11
  { W c = rd(0, 77, 5000, 0, F_FUA); c[8] |= 0; c[10] = 1;
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_RESERVED, 4)); }
  { W c = flush(0, 77); c[0] |= uint32_t(F_RCRC) << 16;
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_FLAGS, 4)); }
  // reserved bits are checked before flag legality (both rule 4; detail decides)
  { W c = flush(0, 0); c[0] |= uint32_t(F_RCRC) << 16; c[10] = 1;
    CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_RESERVED, 4)); }

  // rule 5: NSID (non-existent, unconfigured, foreign: indistinguishable)
  Verdict nx = V(m, T0, rd(0, 200, 0, 1));
  CHECK(is(nx, ST_INVALID_NS, 0, 5));
  CHECK(V(m, T0, rd(0, 5, 0, 1)).same(nx));    // unconfigured index
  CHECK(V(m, T0, rd(0, 8, 0, 1)).same(nx));    // == NS_N
  CHECK(V(m, T0, rd(0, 255, 0, 1)).same(nx));
  CHECK(V(m, T0, rd(0, 2, 0, 1)).same(nx));    // ns2 exists but belongs to tenant 1
  CHECK(V(m, T0, rd(0, 4, 0, 1)).same(nx));    // ns4 belongs to tenant 2
  CHECK(V(m, T1, rd(1, 0, 0, 1)).same(nx));    // and the other way round
  CHECK(V(m, 3, rd(3, 0, 0, 1)).same(nx));  // tenant 3 owns nothing
  for (uint8_t op : {OP_FLUSH, OP_GET_CAPACITY}) {
    CHECK(is(V(m, T0, mk(op, 2, 0, 0, 0, 0, 0)), ST_INVALID_NS, 0, 5));
    CHECK(is(V(m, T0, mk(op, 99, 0, 0, 0, 0, 0)), ST_INVALID_NS, 0, 5));
  }
  CHECK(is(V(m, T0, disc(0, 2, 0, 1)), ST_INVALID_NS, 0, 5));
  CHECK(is(V(m, T0, wr(0, 2, 0, 1)), ST_INVALID_NS, 0, 5));
  // rule 5 beats 6, 7, 8, 9, 10, 11
  { W c = wr(0, 2, 99999, 0, 0, 0); c[7] = 1;
    CHECK(is(V(m, T0, c), ST_INVALID_NS, 0, 5)); }
  m.invalidate_ns(4);  // VALID cleared: the owner now sees INVALID_NS as well
  CHECK(is(V(m, T2, rd(2, 4, 0, 1)), ST_INVALID_NS, 0, 5));

  // rule 6: UNSUPPORTED (DISCARD on a backend without it)
  {
    Model nd = make_m0(true, false, false, true);
    CHECK(is(V(nd, T0, disc(0, 0, 0, 1)), ST_UNSUPPORTED, 0, 6));
    CHECK(is(V(nd, T0, disc(0, 1, 0, 1)), ST_UNSUPPORTED, 0, 6));  // beats NS_READONLY (rule 7)
    CHECK(is(V(nd, T0, disc(0, 0, 0, 0)), ST_UNSUPPORTED, 0, 6));  // beats LEN_ERROR (rule 8)
    CHECK(is(V(nd, T0, disc(0, 0, 5000, 1)), ST_UNSUPPORTED, 0, 6));  // beats LBA_RANGE
    CHECK(is(V(nd, T0, disc(0, 9, 0, 1)), ST_INVALID_NS, 0, 5));  // but rule 5 beats 6
    CHECK(okv(V(nd, T0, wr(0, 0, 0, 1))));
    Model dz = make_m0(true, true, false, true);  // DISCARD but not DISCARD_ZERO (Q-09: unsupported)
    CHECK(is(V(dz, T0, disc(0, 0, 0, 1)), ST_UNSUPPORTED, 0, 6));
    Interp ip;
    ip.discard_needs_zero = false;
    Model dz2 = make_m0(true, true, false, true, ip);
    CHECK(okv(V(dz2, T0, disc(0, 0, 0, 1))));
    Features ft;
    ft.fua = false;
    Model nf = make_m0(true, true, true, true, Interp(), ft);
    CHECK(is(V(nf, T0, wr(0, 0, 0, 1, F_FUA)), ST_UNSUPPORTED, 0, 6));
    CHECK(okv(V(nf, T0, wr(0, 0, 0, 1, F_RCRC))));
    ft = Features();
    ft.hcrc = false;
    Model nh = make_m0(true, true, true, true, Interp(), ft);
    CHECK(is(V(nh, T0, wr(0, 0, 0, 1, F_HCRC)), ST_UNSUPPORTED, 0, 6));
  }

  // rule 7: NS_READONLY (WRITE and DISCARD only)
  CHECK(is(V(m, T0, wr(0, 1, 0, 1)), ST_NS_READONLY, 0, 7));
  CHECK(is(V(m, T0, disc(0, 1, 0, 1)), ST_NS_READONLY, 0, 7));
  CHECK(is(V(m, T0, wr(0, 1, 0, 0)), ST_NS_READONLY, 0, 7));        // beats LEN_ERROR
  CHECK(is(V(m, T0, wr(0, 1, 1000000, 1)), ST_NS_READONLY, 0, 7));  // beats LBA_RANGE
  { W c = wr(0, 1, 0, 1); c[7] = 1;
    CHECK(is(V(m, T0, c), ST_NS_READONLY, 0, 7)); }
  CHECK(okv(V(m, T0, rd(0, 1, 63, 1))));
  CHECK(okv(V(m, T0, flush(0, 1))));

  // rule 8: NBLK / DATA_LEN
  CHECK(is(V(m, T0, rd(0, 0, 0, 0)), ST_LEN_ERROR, DET_LEN_ZERO, 8));
  CHECK(is(V(m, T0, mk(OP_READ, 0, 0, 0, 512, 0x1000, 0)), ST_LEN_ERROR, DET_LEN_ZERO, 8));
  CHECK(is(V(m, T0, wr(0, 0, 0, 0)), ST_LEN_ERROR, DET_LEN_ZERO, 8));
  CHECK(is(V(m, T0, rd(0, 0, 0, 9)), ST_LEN_ERROR, DET_LEN_TOO_LARGE, 8));  // MDTS = 8
  CHECK(is(V(m, T0, wr(0, 0, 0, 9)), ST_LEN_ERROR, DET_LEN_TOO_LARGE, 8));
  CHECK(is(V(m, T0, mk(OP_READ, 0, 0, 0xFFFFFFFFu, 0xFFFFFE00u, 0x1000, 0)), ST_LEN_ERROR, DET_LEN_TOO_LARGE, 8));
  CHECK(is(V(m, T0, mk(OP_READ, 0, 0, 9, 0, 0x1000, 0)), ST_LEN_ERROR, DET_LEN_TOO_LARGE, 8));  // TOO_LARGE before MISMATCH
  CHECK(okv(V(m, T0, rd(0, 0, 0, 8))));
  CHECK(is(V(m, T0, mk(OP_READ, 0, 0, 2, 512, 0x1000, 0)), ST_LEN_ERROR, DET_LEN_MISMATCH, 8));
  CHECK(is(V(m, T0, mk(OP_WRITE, 0, 0, 2, 1536, 0x1000, 0)), ST_LEN_ERROR, DET_LEN_MISMATCH, 8));
  CHECK(is(V(m, T0, mk(OP_WRITE, 0, 0, 1, 0, 0x1000, 0)), ST_LEN_ERROR, DET_LEN_MISMATCH, 8));
  CHECK(is(V(m, T0, mk(OP_READ, 0, 0, 1, 0x200 + (1u << 31), 0x1000, 0)), ST_LEN_ERROR, DET_LEN_MISMATCH, 8));
  // DISCARD: 1..65535 (not bounded by MDTS)
  CHECK(okv(V(m, T0, disc(0, 0, 0, 100))));
  CHECK(is(V(m, T0, disc(0, 0, 0, 0)), ST_LEN_ERROR, DET_LEN_ZERO, 8));
  CHECK(is(V(m, T0, disc(0, 0, 0, 65536)), ST_LEN_ERROR, DET_LEN_TOO_LARGE, 8));
  CHECK(is(V(m, T0, disc(0, 0, 0, 0xFFFFFFFFu)), ST_LEN_ERROR, DET_LEN_TOO_LARGE, 8));
  CHECK(is(V(m, T0, mk(OP_DISCARD, 0, 0, 1, 512, 0, 0)), ST_LEN_ERROR, DET_LEN_NOT_ZERO, 8));
  // FLUSH / GET_CAPACITY: NBLK and DATA_LEN must be 0
  for (uint8_t op : {OP_FLUSH, OP_GET_CAPACITY}) {
    CHECK(is(V(m, T0, mk(op, 0, 0, 1, 0, 0, 0)), ST_LEN_ERROR, DET_LEN_NOT_ZERO, 8));
    CHECK(is(V(m, T0, mk(op, 0, 0, 0, 1, 0, 0)), ST_LEN_ERROR, DET_LEN_NOT_ZERO, 8));
    CHECK(is(V(m, T0, mk(op, 0, 0, 0xFFFFFFFFu, 0xFFFFFFFFu, 0, 0)), ST_LEN_ERROR, DET_LEN_NOT_ZERO, 8));
  }
  // rule 8 beats 9, 10, 11
  { W c = rd(0, 0, 99999, 0); c[6] = 3;
    CHECK(is(V(m, T0, c), ST_LEN_ERROR, DET_LEN_ZERO, 8)); }

  // rule 9: DATA_ADDR
  for (uint64_t a : {1ull, 2ull, 3ull, 5ull, 0x1001ull, 0xFFFFFFFFFFFFFFFFull, 0x100000002ull, 0x8000000000000001ull}) {
    CHECK(is(V(m, T0, mk(OP_READ, 0, 0, 1, 512, a, 0)), ST_INVALID_FIELD, DET_ADDR_ALIGN, 9));
    CHECK(is(V(m, T0, mk(OP_WRITE, 0, 0, 1, 512, a, 0)), ST_INVALID_FIELD, DET_ADDR_ALIGN, 9));
  }
  for (uint64_t a : {0ull, 4ull, 8ull, 0x1000ull, 0xFFFFFFFFFFFFFFFCull, 0x100000000ull}) {
    CHECK(okv(V(m, T0, mk(OP_READ, 0, 0, 1, 512, a, 0))));  // alignment only; no range check on IOVA here (DMA checker's job)
    CHECK(okv(V(m, T0, mk(OP_WRITE, 0, 0, 1, 512, a, 0))));
  }
  for (uint8_t op : {OP_FLUSH, OP_GET_CAPACITY, OP_DISCARD})
    for (uint64_t a : {4ull, 1ull, 0x100000000ull, 0x8000000000000000ull}) {
      W c = mk(op, 0, 0, op == OP_DISCARD ? 1 : 0, 0, a, 0);
      CHECK(is(V(m, T0, c), ST_INVALID_FIELD, DET_ADDR_ALIGN, 9));
    }
  // rule 9 beats rule 10 and 11
  CHECK(is(V(m, T0, mk(OP_READ, 0, 5000, 1, 512, 1, 0)), ST_INVALID_FIELD, DET_ADDR_ALIGN, 9));

  // rule 10: range, ns0 has 1024 blocks
  CHECK(okv(V(m, T0, rd(0, 0, 1016, 8))));   // LBA+NBLK == SIZE
  CHECK(is(V(m, T0, rd(0, 0, 1017, 8)), ST_LBA_RANGE, 0, 10));  // SIZE+1
  CHECK(okv(V(m, T0, rd(0, 0, 1023, 1))));
  CHECK(is(V(m, T0, rd(0, 0, 1024, 1)), ST_LBA_RANGE, 0, 10));
  CHECK(is(V(m, T0, rd(0, 0, 1023, 2)), ST_LBA_RANGE, 0, 10));
  CHECK(okv(V(m, T0, wr(0, 0, 1023, 1))));
  CHECK(is(V(m, T0, wr(0, 0, 1020, 8)), ST_LBA_RANGE, 0, 10));
  CHECK(okv(V(m, T0, disc(0, 0, 0, 1024))));    // discard the whole namespace
  CHECK(is(V(m, T0, disc(0, 0, 0, 1025)), ST_LBA_RANGE, 0, 10));
  CHECK(is(V(m, T0, disc(0, 0, 1, 1024)), ST_LBA_RANGE, 0, 10));
  CHECK(is(V(m, T0, rd(0, 0, 1ull << 40, 1)), ST_LBA_RANGE, 0, 10));
  CHECK(is(V(m, T0, rd(0, 3, 100, 1)), ST_LBA_RANGE, 0, 10));  // ns3 has size 100
  CHECK(okv(V(m, T0, rd(0, 3, 99, 1))));
  CHECK(okv(V(m, T0, rd(0, 3, 92, 8))));
  CHECK(is(V(m, T0, rd(0, 3, 93, 8)), ST_LBA_RANGE, 0, 10));
  // 2^64 wrap: 64-bit arithmetic would accept these
  CHECK(is(V(m, T0, rd(0, 0, ~0ull, 1)), ST_LBA_RANGE, 0, 10));
  CHECK(is(V(m, T0, rd(0, 0, ~0ull - 7, 8)), ST_LBA_RANGE, 0, 10));   // LBA+NBLK == 2^64 -> 0
  CHECK(is(V(m, T0, rd(0, 0, ~0ull - 6, 8)), ST_LBA_RANGE, 0, 10));   // 2^64 + 1 -> 1
  CHECK(is(V(m, T0, wr(0, 0, ~0ull, 8)), ST_LBA_RANGE, 0, 10));
  CHECK(is(V(m, T0, disc(0, 0, ~0ull, 65535)), ST_LBA_RANGE, 0, 10));
  CHECK(is(V(m, T0, disc(0, 0, ~0ull - 65534, 65535)), ST_LBA_RANGE, 0, 10));
  // FLUSH/GET_CAPACITY: LBA is not constrained (Q-11)
  { W c = flush(0, 0); c[2] = 0xFFFFFFFFu; c[3] = 0xFFFFFFFFu;
    CHECK(okv(V(m, T0, c))); }
  { W c = getcap(0, 0); c[2] = 5000;
    CHECK(okv(V(m, T0, c))); }
  {
    Interp ip;
    ip.range_all_ops = true;
    Model ma = make_m0(true, true, true, true, ip);
    W c = flush(0, 0); c[2] = 5000;
    CHECK(is(V(ma, T0, c), ST_LBA_RANGE, 0, 10));
    c[2] = 1024;  // LBA == SIZE with NBLK 0 still fits
    CHECK(okv(V(ma, T0, c)));
  }
  // huge namespace (2^64-1 blocks): bounds near 2^64
  {
    BackendCaps c;
    c.capacity_blocks = ~0ull;
    c.discard = c.discard_zero = true;
    Model big(2, 4, 8, c);
    NsCfg n;
    n.owner = 0; n.base = 0; n.size = ~0ull;
    CHECK(big.cfg_ns(0, n).accepted);
    CHECK(okv(V(big, T0, rd(0, 0, ~0ull - 1, 1))));      // end == 2^64-1 == SIZE
    CHECK(is(V(big, T0, rd(0, 0, ~0ull, 1)), ST_LBA_RANGE, 0, 10));  // 2^64 -> carry
    CHECK(is(V(big, T0, rd(0, 0, ~0ull - 7, 8)), ST_LBA_RANGE, 0, 10));  // exactly 2^64 -> wraps to 0
    CHECK(okv(V(big, T0, rd(0, 0, ~0ull - 8, 8))));      // end == 2^64-1
    CHECK(okv(V(big, T0, rd(0, 0, 1ull << 63, 8))));
    CHECK(okv(V(big, T0, disc(0, 0, ~0ull - 65535, 65535))));
    n.base = ~0ull - 9; n.size = 10;  // base+size == 2^64: refused (capacity)
    CHECK(!big.cfg_ns(1, n).accepted);
    n.size = 9;
    CHECK(big.cfg_ns(1, n).accepted);
  }

  // rule 11: ENC_EN with key not ready
  CHECK(is(V(m, T1, rd(1, 2, 0, 1)), ST_CRYPTO_ERROR, DET_KEY_NOT_READY, 11));
  CHECK(is(V(m, T1, wr(1, 2, 0, 1)), ST_CRYPTO_ERROR, DET_KEY_NOT_READY, 11));
  CHECK(is(V(m, T1, rd(1, 2, 0, 9)), ST_LEN_ERROR, DET_LEN_TOO_LARGE, 8));          // earlier rules first
  CHECK(is(V(m, T1, rd(1, 2, 512, 1)), ST_LBA_RANGE, 0, 10));
  CHECK(okv(V(m, T1, flush(1, 2))));               // Q-12: no key needed for non-data ops
  CHECK(okv(V(m, T1, getcap(1, 2))));
  CHECK(okv(V(m, T1, disc(1, 2, 0, 4))));
  m.set_key_ready(2, true);                       // another slot: still not ready
  CHECK(is(V(m, T1, rd(1, 2, 0, 1)), ST_CRYPTO_ERROR, DET_KEY_NOT_READY, 11));
  m.set_key_ready(3, true);
  CHECK(okv(V(m, T1, rd(1, 2, 0, 1))));
  CHECK(okv(V(m, T1, wr(1, 2, 0, 1))));
  m.set_key_ready(3, false);                      // zeroize
  CHECK(is(V(m, T1, rd(1, 2, 0, 1)), ST_CRYPTO_ERROR, DET_KEY_NOT_READY, 11));
  {
    Interp ip;
    ip.key_all_ops = true;
    Model mk2 = make_m0(true, true, true, true, ip);
    CHECK(is(V(mk2, T1, flush(1, 2)), ST_CRYPTO_ERROR, DET_KEY_NOT_READY, 11));
  }
}

// ---------------------------------------------------------------------------------------------
static void test_interp_detail() {
  section("Interp switches (Q-04, Q-05)");
  Interp ip;
  ip.rsv_flags_detail = DET_FLAGS;
  ip.hostcrc_nz_is_flags = true;
  Model m = make_m0(true, true, true, true, ip);
  W c = rd(0, 0, 0, 1);
  c[0] |= 1u << 20;
  CHECK(is(V(m, 0, c), ST_INVALID_FIELD, DET_FLAGS, 4));
  c = rd(0, 0, 0, 1);
  c[9] = 7;
  CHECK(is(V(m, 0, c), ST_INVALID_FIELD, DET_FLAGS, 4));
  c = rd(0, 0, 0, 1);
  c[1] |= 1u << 28;  // a *word* reserved field stays RESERVED
  CHECK(is(V(m, 0, c), ST_INVALID_FIELD, DET_RESERVED, 4));
}

// ---------------------------------------------------------------------------------------------
static void test_exec() {
  section("execution: WRITE/READ/FLUSH/DISCARD/GET_CAPACITY");
  Model m = make_m0();
  const unsigned T0 = 0;
  // never-written reads zeros, SUCCESS (§5.7)
  {
    Outcome o = m.submit(T0, rd(0, 0, 0, 4).w, nullptr);
    CHECK(o.v.ok && o.status == ST_SUCCESS && o.nblk_done == 4 && o.read_data.size() == 2048);
    CHECK(std::all_of(o.read_data.begin(), o.read_data.end(), [](uint8_t b) { return b == 0; }));
    CHECK(o.txn == 0xBEEF && o.opcode == OP_READ && o.tenant == 0 && o.crc_valid == 0 && o.pi_verified == 0);
    CHECK(o.durable == -1);
  }
  // write then read back (multi-block, offset lba) - ordering: read sees the earlier write
  auto d1 = fillv(3, 0xA5);
  d1[512] = 0x01;  // distinguish the middle block
  Outcome w1 = m.submit(T0, wr(0, 0, 100, 3).w, d1.data());
  CHECK(w1.v.ok && w1.status == ST_SUCCESS && w1.nblk_done == 3 && w1.durable == 0 && w1.wid != 0);
  CHECK(w1.encrypted == 0 && w1.pi_verified == 0 && w1.crc_valid == 0);
  Outcome r1 = m.submit(T0, rd(0, 0, 99, 5).w, nullptr);
  CHECK(r1.status == ST_SUCCESS && r1.read_data.size() == 5 * 512);
  CHECK(std::all_of(r1.read_data.begin(), r1.read_data.begin() + 512, [](uint8_t b) { return b == 0; }));
  CHECK(std::memcmp(r1.read_data.data() + 512, d1.data(), 1536) == 0);
  CHECK(std::all_of(r1.read_data.begin() + 2048, r1.read_data.end(), [](uint8_t b) { return b == 0; }));
  std::string why;
  CHECK_MSG(m.check_read(0, 100, 3, d1.data(), why), why);
  CHECK(!m.check_read(0, 100, 3, fillv(3, 0xA5).data(), why));  // block 1 differs (byte 0 = 0x01)
  CHECK(why.find("differs") != std::string::npos);
  // a later write supersedes
  auto d2 = fillv(1, 0x3C);
  m.submit(T0, wr(0, 0, 101, 1).w, d2.data());
  CHECK(m.check_read(0, 101, 1, d2.data(), why));
  CHECK(!m.check_read(0, 101, 1, d1.data() + 512, why));
  // a rejected command moves no data / touches no state
  {
    auto dd = fillv(1, 0xEE);
    Outcome bad = m.submit(T0, wr(0, 0, 101, 1, 0).w, dd.data(), 1);  // hw binding 1 != claim 0 -> TENANT_MISMATCH
    CHECK(!bad.v.ok && bad.status == ST_TENANT_MISMATCH && bad.nblk_done == 0 && bad.durable == 0 && bad.wid == 0);
    CHECK(m.check_read(0, 101, 1, d2.data(), why));
    W c = wr(0, 0, 5000, 1);  // LBA_RANGE
    Outcome b2 = m.submit(T0, c.w, dd.data());
    CHECK(b2.status == ST_LBA_RANGE && b2.nblk_done == 0 && b2.wid == 0 && !b2.executed);
  }
  // GET_CAPACITY: namespace size, 64-bit split over RESULT0/1
  {
    Outcome o = m.submit(T0, getcap(0, 0).w, nullptr);
    CHECK(o.status == ST_SUCCESS && o.result0 == 1024 && o.result1 == 0 && o.nblk_done == 0);
    BackendCaps c;
    c.capacity_blocks = ~0ull;
    Model big(1, 2, 8, c);
    NsCfg n;
    n.owner = 0; n.base = 0; n.size = (7ull << 32) | 0x89ABCDEFu;
    CHECK(big.cfg_ns(0, n).accepted);
    Outcome g = big.submit(0, getcap(0, 0).w, nullptr);
    CHECK(g.result0 == 0x89ABCDEFu && g.result1 == 7 && g.status == ST_SUCCESS);
  }
  // FLUSH: SUCCESS, durable
  {
    Outcome o = m.submit(T0, flush(0, 0).w, nullptr);
    CHECK(o.status == ST_SUCCESS && o.durable == 1 && o.nblk_done == 0 && o.fid != 0);
    m.on_flush_complete(0);
  }
  // DISCARD: zeros afterwards, multi-block, durability follows WRITE
  {
    Outcome o = m.submit(T0, disc(0, 0, 100, 2).w, nullptr);
    CHECK(o.status == ST_SUCCESS && o.nblk_done == 2 && o.durable == 0);  // volatile cache backend
    CHECK(m.check_read(0, 100, 1, fillv(1, 0).data(), why));
    CHECK(m.check_read(0, 101, 1, fillv(1, 0).data(), why));
    CHECK(m.check_read(0, 102, 1, d1.data() + 1024, why));  // block 102 untouched
    Outcome r = m.submit(T0, rd(0, 0, 100, 3).w, nullptr);
    CHECK(std::all_of(r.read_data.begin(), r.read_data.begin() + 1024, [](uint8_t b) { return b == 0; }));
    CHECK(std::memcmp(r.read_data.data() + 1024, d1.data() + 1024, 512) == 0);
  }
  // HCRC: good CRC accepted; bad CRC -> DATA_CRC, nothing written, nblk_done 0
  {
    auto dd = fillv(2, 0x77);
    uint32_t good = crc32c(dd.data(), dd.size());
    Outcome ok = m.submit(T0, wr(0, 0, 200, 2, F_HCRC, good).w, dd.data());
    CHECK(ok.status == ST_SUCCESS && ok.nblk_done == 2);
    CHECK(m.check_read(0, 200, 2, dd.data(), why));
    Outcome bad = m.submit(T0, wr(0, 0, 300, 2, F_HCRC, good ^ 1u).w, dd.data());
    CHECK(bad.v.ok && bad.executed && bad.status == ST_DATA_CRC && bad.bad_hcrc && bad.nblk_done == 0 && bad.durable == 0 &&
          bad.wid == 0);
    CHECK(m.check_read(0, 300, 2, fillv(2, 0).data(), why));
    // HOST_CRC == 0 legitimately equal to a CRC? only mismatch counts
    Outcome z = m.submit(T0, wr(0, 0, 301, 1, F_HCRC, 0).w, fillv(1, 0x11).data());
    CHECK(z.status == ST_DATA_CRC);
  }
  // RCRC: CRC-32C of the payload moved (WRITE: host data; READ: data returned)
  {
    auto dd = fillv(2, 0x42);
    Outcome o = m.submit(T0, wr(0, 0, 400, 2, F_RCRC).w, dd.data());
    CHECK(o.crc_valid == 1 && o.crc == crc32c(dd.data(), dd.size()));
    Outcome r = m.submit(T0, rd(0, 0, 400, 2, F_RCRC).w, nullptr);
    CHECK(r.crc_valid == 1 && r.crc == crc32c(dd.data(), dd.size()));
    Outcome r2 = m.submit(T0, rd(0, 0, 500, 1, F_RCRC).w, nullptr);  // zeros
    uint8_t z[512] = {};
    CHECK(r2.crc_valid == 1 && r2.crc == crc32c(z, 512));
    Outcome r3 = m.submit(T0, rd(0, 0, 400, 1).w, nullptr);  // no RCRC
    CHECK(r3.crc_valid == 0);
  }
  // FUA / durability flag (volatile-cache backend)
  {
    Outcome a = m.submit(T0, wr(0, 0, 600, 1).w, fillv(1, 1).data());
    Outcome b = m.submit(T0, wr(0, 0, 601, 1, F_FUA).w, fillv(1, 2).data());
    CHECK(a.durable == 0 && b.durable == 1);
    m.on_write_complete(a.wid, false);
    m.on_write_complete(b.wid, true);
  }
  {  // write-through backend: durable always
    Model wt = make_m0(false, true, true, true);
    Outcome a = wt.submit(0, wr(0, 0, 0, 1).w, fillv(1, 1).data());
    Outcome d = wt.submit(0, disc(0, 0, 0, 1).w, nullptr);
    CHECK(a.durable == 1 && d.durable == 1);
  }
  // PI / ENC flags on completions
  {
    auto dd = fillv(1, 0x66);
    Outcome w = m.submit(T0, wr(0, 3, 0, 1).w, dd.data());
    CHECK(w.pi_verified == 1 && w.encrypted == 0);
    Outcome r = m.submit(T0, rd(0, 3, 0, 1).w, nullptr);
    CHECK(r.pi_verified == 1);
    Outcome rz = m.submit(T0, rd(0, 3, 10, 1).w, nullptr);  // never written: PI_VERIFIED = 0 (§5.7)
    CHECK(rz.pi_verified == 0);
    Outcome rm = m.submit(T0, rd(0, 3, 0, 2).w, nullptr);   // mixed: one bit for 2 blocks -> don't care
    CHECK(rm.pi_verified == -1);
    Outcome rn = m.submit(T0, rd(0, 0, 0, 1).w, nullptr);   // namespace without PI
    CHECK(rn.pi_verified == 0);
    m.set_key_ready(3, true);
    Outcome we = m.submit(1, wr(1, 2, 0, 1).w, dd.data());
    CHECK(we.status == ST_SUCCESS && we.encrypted == 1 && we.pi_verified == 0);
    Outcome re = m.submit(1, rd(1, 2, 0, 1).w, nullptr);
    CHECK(re.encrypted == 1 && re.pi_verified == 0);
  }
  // overlapping ranges: later read sees the earlier write even if neither completed yet; an earlier read keeps old data
  {
    Model m2 = make_m0();
    auto a = fillv(2, 0x10), b = fillv(2, 0x20);
    m2.submit(0, wr(0, 0, 0, 2).w, a.data());
    Outcome rbefore = m2.submit(0, rd(0, 0, 0, 2).w, nullptr);
    m2.submit(0, wr(0, 0, 1, 2).w, b.data());
    Outcome rafter = m2.submit(0, rd(0, 0, 0, 3).w, nullptr);
    CHECK(std::memcmp(rbefore.read_data.data(), a.data(), 1024) == 0);
    CHECK(rafter.read_data[0] == 0x10 && rafter.read_data[512] == 0x20 && rafter.read_data[1024] == 0x20);
  }
  // namespaces are windows of one backend: BASE offsets, no cross-talk
  {
    Model m2 = make_m0();
    m2.submit(0, wr(0, 0, 5, 1).w, fillv(1, 0x99).data());
    Outcome o = m2.submit(2, rd(2, 4, 5, 1).w, nullptr);
    CHECK(o.status == ST_SUCCESS && o.read_data[0] == 0);
  }
}

// ---------------------------------------------------------------------------------------------
static void test_counters_and_cqe() {
  section("counters (§8) and CQE check (§3)");
  Model m = make_m0();
  auto d = fillv(4, 0x5A);
  m.submit(0, wr(0, 0, 0, 4).w, d.data());                 // ok write 4 blk
  m.submit(0, rd(0, 0, 0, 2).w, nullptr);                  // ok read 2 blk
  m.submit(0, flush(0, 0).w, nullptr);                     // flush
  m.submit(0, rd(0, 2, 0, 1).w, nullptr);                  // INVALID_NS  (viol)
  m.submit(0, rd(1, 0, 0, 1).w, nullptr);                  // TENANT_MISMATCH (viol)
  m.submit(0, rd(0, 0, 5000, 1).w, nullptr);               // LBA_RANGE
  m.submit(0, wr(0, 0, 8, 1, F_HCRC, 1).w, d.data());      // DATA_CRC (exec failure)
  const auto& c = m.counters(0);
  CHECK(c.done == 7 && c.err == 4 && c.rd_blk == 2 && c.wr_blk == 4 && c.flush == 1 && c.viol == 2 && c.bytes == 6 * 512);
  CHECK(m.counters(1).done == 0);
  m.clear_counters();
  CHECK(m.counters(0).done == 0);

  // check_cqe: hand-pack a correct CQE for a READ with RCRC and tweak it
  auto dd = fillv(2, 0x31);
  m.submit(0, wr(0, 0, 10, 2).w, dd.data());
  Outcome o = m.submit(0, rd(0, 0, 10, 2, F_RCRC).w, nullptr);
  uint32_t q[8] = {};
  q[0] = o.txn | (uint32_t(ST_SUCCESS) << 16);
  q[1] = 8u | (uint32_t(OP_READ) << 8) | (2u << 16);
  q[2] = o.crc;
  q[4] = 5u | (0u << 16);
  q[5] = 123;
  q[7] = 1;
  std::string why;
  CHECK_MSG(m.check_cqe(o, decode_cqe(q), why), why);
  uint32_t t[8];
  std::memcpy(t, q, sizeof(t)); t[0] ^= 1u << 16;
  CHECK(!m.check_cqe(o, decode_cqe(t), why) && why.find("STATUS") != std::string::npos);
  std::memcpy(t, q, sizeof(t)); t[2] ^= 4;
  CHECK(!m.check_cqe(o, decode_cqe(t), why) && why.find("RESULT0") != std::string::npos);
  std::memcpy(t, q, sizeof(t)); t[1] &= ~8u;
  CHECK(!m.check_cqe(o, decode_cqe(t), why));
  std::memcpy(t, q, sizeof(t)); t[1] |= 1;  // durable on a READ: don't care
  CHECK_MSG(m.check_cqe(o, decode_cqe(t), why), why);
  std::memcpy(t, q, sizeof(t)); t[6] = 1;
  CHECK(!m.check_cqe(o, decode_cqe(t), why));
  std::memcpy(t, q, sizeof(t)); t[7] = 3;
  CHECK(!m.check_cqe(o, decode_cqe(t), why));
  std::memcpy(t, q, sizeof(t)); t[1] = (t[1] & 0xFFFFu) | (1u << 16);
  CHECK(!m.check_cqe(o, decode_cqe(t), why) && why.find("NBLK_DONE") != std::string::npos);
  // write: DURABLE is checked
  Outcome w = m.submit(0, wr(0, 0, 20, 1).w, dd.data());
  uint32_t qw[8] = {};
  qw[0] = w.txn;
  qw[1] = (uint32_t(OP_WRITE) << 8) | (1u << 16);
  qw[7] = 1;
  CHECK_MSG(m.check_cqe(w, decode_cqe(qw), why), why);
  qw[1] |= 1;
  CHECK(!m.check_cqe(w, decode_cqe(qw), why) && why.find("DURABLE") != std::string::npos);
  // error completion
  Outcome e = m.submit(0, rd(0, 2, 0, 1).w, nullptr);
  uint32_t qe[8] = {};
  qe[0] = e.txn | (uint32_t(ST_INVALID_NS) << 16);
  qe[1] = uint32_t(OP_READ) << 8;
  qe[7] = 1;
  CHECK_MSG(m.check_cqe(e, decode_cqe(qe), why), why);
  // GET_CAPACITY
  Outcome gc = m.submit(0, getcap(0, 0).w, nullptr);
  uint32_t qg[8] = {};
  qg[0] = gc.txn;
  qg[1] = uint32_t(OP_GET_CAPACITY) << 8;
  qg[2] = 1024;
  qg[7] = 1;
  CHECK_MSG(m.check_cqe(gc, decode_cqe(qg), why), why);
  qg[3] = 1;
  CHECK(!m.check_cqe(gc, decode_cqe(qg), why));
}

// ---------------------------------------------------------------------------------------------
// §5 durability / power loss
static void test_durability() {
  section("durability + power loss (§5)");
  std::string why;
  const unsigned T0 = 0;

  { // volatile write: indeterminate after loss, then collapses
    Model m = make_m0();
    auto a = fillv(2, 0x11);
    Outcome o = m.submit(T0, wr(0, 0, 10, 2).w, a.data());
    CHECK(o.durable == 0);
    m.on_write_complete(T0, 0, 10, 2, false);
    CHECK(m.check_read(0, 10, 2, a.data(), why));
    m.power_loss();
    CHECK(m.power_loss_count() == 1);
    CHECK(!m.is_determinate(0, 10, 2));
    CHECK(!m.check_read(0, 10, 2, a.data(), why) && why.find("indeterminate") != std::string::npos);
    CHECK(m.candidates(0, 10) == 2);
    // zeros (the initial version) and the written data are both fine, per block
    std::vector<uint8_t> mix(1024, 0);
    std::memcpy(mix.data() + 512, a.data(), 512);  // block 10 lost, block 11 survived
    CHECK_MSG(m.check_read_after_loss(0, 10, 2, mix.data(), why), why);
    CHECK(m.is_determinate(0, 10, 2));
    CHECK(m.check_read(0, 10, 2, mix.data(), why));   // collapsed: now exact
    CHECK(!m.check_read(0, 10, 2, a.data(), why));
    m.power_loss();                                    // nothing volatile left: stays
    CHECK(m.is_determinate(0, 10, 2));
    CHECK(m.check_read(0, 10, 2, mix.data(), why));
  }
  { // data never written to the block is never acceptable
    Model m = make_m0();
    m.submit(T0, wr(0, 0, 10, 1).w, fillv(1, 0x11).data());
    m.on_write_complete(T0, 0, 10, 1, false);
    m.power_loss();
    CHECK(!m.check_read_after_loss(0, 10, 1, fillv(1, 0x12).data(), why));
    CHECK(why.find("none of the") != std::string::npos);
    auto bad = fillv(1, 0x11);
    bad[300] ^= 1;  // a single flipped bit
    CHECK(!m.check_read_after_loss(0, 10, 1, bad.data(), why));
    CHECK(!m.check_read_after_loss(0, 11, 1, fillv(1, 0x11).data(), why));  // block 11 never written: only zeros
    CHECK(m.check_read_after_loss(0, 11, 1, fillv(1, 0).data(), why));
    CHECK(m.check_read_after_loss(0, 10, 1, fillv(1, 0x11).data(), why));  // failed checks did not collapse anything
  }
  { // FUA / durable completion: exactly that data survives
    Model m = make_m0();
    Outcome o = m.submit(T0, wr(0, 0, 10, 1, F_FUA).w, fillv(1, 0x22).data());
    CHECK(o.durable == 1);
    m.on_write_complete(o.wid, true);
    m.power_loss();
    CHECK(m.is_determinate(0, 10, 1));
    CHECK(m.check_read(0, 10, 1, fillv(1, 0x22).data(), why));
    CHECK(!m.check_read_after_loss(0, 10, 1, fillv(1, 0).data(), why));  // lost a durable write: model must complain
    // a later volatile write may or may not survive; the durable one is the floor
    Outcome o2 = m.submit(T0, wr(0, 0, 10, 1).w, fillv(1, 0x23).data());
    m.on_write_complete(o2.wid, false);
    m.power_loss();
    CHECK(m.candidates(0, 10) == 2);
    CHECK(!m.check_read_after_loss(0, 10, 1, fillv(1, 0).data(), why));
    CHECK(m.check_read_after_loss(0, 10, 1, fillv(1, 0x22).data(), why));
  }
  { // later durable write supersedes older volatile versions: the older ones may not reappear
    Model m = make_m0();
    Outcome a = m.submit(T0, wr(0, 0, 5, 1).w, fillv(1, 0x31).data());
    m.on_write_complete(a.wid, false);
    Outcome b = m.submit(T0, wr(0, 0, 5, 1, F_FUA).w, fillv(1, 0x32).data());
    m.on_write_complete(b.wid, true);
    m.power_loss();
    CHECK(!m.check_read_after_loss(0, 5, 1, fillv(1, 0x31).data(), why));
    CHECK(!m.check_read_after_loss(0, 5, 1, fillv(1, 0).data(), why));
    CHECK(m.check_read_after_loss(0, 5, 1, fillv(1, 0x32).data(), why));
  }
  { // history window: W1 flushed, W2, W3 volatile -> any of {W1,W2,W3}; observation collapses
    Model m = make_m0();
    Outcome w1 = m.submit(T0, wr(0, 0, 20, 1).w, fillv(1, 0x41).data());
    m.on_write_complete(w1.wid, false);
    Outcome f = m.submit(T0, flush(0, 0).w, nullptr);
    Outcome w2 = m.submit(T0, wr(0, 0, 20, 1).w, fillv(1, 0x42).data());
    m.on_write_complete(w2.wid, false);          // completes before the FLUSH completes: NOT covered
    m.on_flush_complete(T0);                      // covers w1 only
    CHECK(f.durable == 1 && m.violations().empty());
    Outcome w3 = m.submit(T0, wr(0, 0, 20, 1).w, fillv(1, 0x43).data());
    m.on_write_complete(w3.wid, false);
    m.power_loss();
    CHECK(m.candidates(0, 20) == 3);
    CHECK(!m.check_read_after_loss(0, 20, 1, fillv(1, 0).data(), why));   // below the floor (W1 was flushed)
    CHECK(!m.check_read_after_loss(0, 20, 1, fillv(1, 0x44).data(), why));
    CHECK(m.check_read_after_loss(0, 20, 1, fillv(1, 0x42).data(), why));  // the middle one
    CHECK(m.candidates(0, 20) == 1);
    CHECK(!m.check_read(0, 20, 1, fillv(1, 0x43).data(), why));            // collapsed to W2
    CHECK(!m.check_read(0, 20, 1, fillv(1, 0x41).data(), why));
    m.power_loss();                                                         // second loss: W2 stays
    CHECK(m.check_read(0, 20, 1, fillv(1, 0x42).data(), why));
  }
  { // FLUSH covers every earlier completed write of the tenant (multi-block, many blocks), later writes stay volatile
    Model m = make_m0();
    auto pa = fillv(8, 0x51);
    Outcome a = m.submit(T0, wr(0, 0, 100, 8).w, pa.data());
    Outcome b = m.submit(T0, disc(0, 0, 104, 2).w, nullptr);
    m.on_write_complete(a.wid, false);
    m.on_write_complete(b.wid, false);
    m.submit(T0, flush(0, 0).w, nullptr);
    Outcome c = m.submit(T0, wr(0, 0, 100, 1).w, fillv(1, 0x52).data());   // after the flush
    m.on_flush_complete(T0);
    m.on_write_complete(c.wid, false);
    m.power_loss();
    // blocks 100: {0x51, 0x52}; 101..103,106,107: exactly 0x51; 104,105: exactly zero (discard flushed)
    CHECK(m.candidates(0, 100) == 2);
    for (uint64_t l : {101, 102, 103, 106, 107}) CHECK(m.candidates(0, l) == 1);
    CHECK(m.candidates(0, 104) == 1 && m.candidates(0, 105) == 1);
    CHECK(m.check_read(0, 101, 3, pa.data() + 512, why));
    CHECK(m.check_read(0, 104, 2, fillv(2, 0).data(), why));
    CHECK(!m.check_read(0, 104, 2, pa.data() + 4 * 512, why));
  }
  { // FLUSH of tenant A does not cover tenant B's writes (conservative per-tenant coverage); alias namespaces (Q-16)
    BackendCaps c;
    c.capacity_blocks = 1000;
    c.volatile_cache = true;
    Model m(2, 2, 8, c);
    NsCfg n;
    n.owner = 0; n.base = 0; n.size = 100;
    CHECK(m.cfg_ns(0, n).accepted);
    n.owner = 1;
    CHECK(m.cfg_ns(1, n).accepted);
    Outcome w = m.submit(1, wr(1, 1, 0, 1).w, fillv(1, 0x61).data());
    m.on_write_complete(w.wid, false);
    m.submit(0, flush(0, 0).w, nullptr);
    m.on_flush_complete(0);
    m.power_loss();
    CHECK(m.check_read_after_loss(1, 0, 1, fillv(1, 0).data(), why));  // still allowed to be lost
    Model m2(2, 2, 8, c);
    CHECK(m2.cfg_ns(0, n).accepted);
    Outcome w2 = m2.submit(1, wr(1, 0, 0, 1).w, fillv(1, 0x61).data());
    m2.on_write_complete(w2.wid, false);
    m2.submit(1, flush(1, 0).w, nullptr);
    m2.on_flush_complete(1);
    m2.power_loss();
    CHECK(!m2.check_read_after_loss(1, 0, 1, fillv(1, 0).data(), why));  // own-tenant flush covers it
  }
  { // FLUSH completing before an earlier write of the same queue completed is a protocol violation (§5.2)
    Model m = make_m0();
    Outcome w = m.submit(T0, wr(0, 0, 0, 1).w, fillv(1, 1).data());
    m.submit(T0, flush(0, 0).w, nullptr);
    m.on_flush_complete(T0);
    CHECK(m.violations().size() == 1);
    m.on_write_complete(w.wid, false);
    m.clear_violations();
    CHECK(m.violations().empty());
    m.on_write_complete(T0, 0, 12345, 1, false);  // unknown write
    CHECK(m.violations().size() == 1);
  }
  { // failed FLUSH makes nothing durable
    Model m = make_m0();
    Outcome w = m.submit(T0, wr(0, 0, 0, 1).w, fillv(1, 7).data());
    m.on_write_complete(w.wid, false);
    m.submit(T0, flush(0, 0).w, nullptr);
    m.on_flush_failed(T0);
    m.power_loss();
    CHECK(m.check_read_after_loss(0, 0, 1, fillv(1, 0).data(), why));
  }
  { // write-through backend: completed writes are durable
    Model m = make_m0(false);
    Outcome w = m.submit(T0, wr(0, 0, 3, 2).w, fillv(2, 0x71).data());
    CHECK(w.durable == 1);
    m.on_write_complete(w.wid, true);
    m.power_loss();
    CHECK(m.is_determinate(0, 3, 2));
    CHECK(m.check_read(0, 3, 2, fillv(2, 0x71).data(), why));
    Outcome d = m.submit(T0, disc(0, 0, 3, 1).w, nullptr);
    CHECK(d.durable == 1);
    m.on_write_complete(d.wid, true);
    m.power_loss();
    CHECK(m.check_read(0, 3, 1, fillv(1, 0).data(), why));
    CHECK(m.check_read(0, 4, 1, fillv(1, 0x71).data(), why));
  }
  { // DISCARD on a volatile backend is not durable until flushed
    Model m = make_m0();
    Outcome w = m.submit(T0, wr(0, 0, 30, 1, F_FUA).w, fillv(1, 0x81).data());
    m.on_write_complete(w.wid, true);
    Outcome d = m.submit(T0, disc(0, 0, 30, 1).w, nullptr);
    CHECK(d.durable == 0);
    m.on_write_complete(d.wid, false);
    CHECK(m.check_read(0, 30, 1, fillv(1, 0).data(), why));   // reads zeros immediately (§5.6)
    m.power_loss();
    CHECK(m.candidates(0, 30) == 2);                          // zeros or the old durable data
    CHECK(m.check_read_after_loss(0, 30, 1, fillv(1, 0x81).data(), why));
    // durable discard
    Model m2 = make_m0();
    Outcome w2 = m2.submit(T0, wr(0, 0, 30, 1, F_FUA).w, fillv(1, 0x81).data());
    m2.on_write_complete(w2.wid, true);
    Outcome d2 = m2.submit(T0, disc(0, 0, 30, 1).w, nullptr);
    m2.on_write_complete(d2.wid, false);
    m2.submit(T0, flush(0, 0).w, nullptr);
    m2.on_flush_complete(T0);
    m2.power_loss();
    CHECK(m2.is_determinate(0, 30, 1));
    CHECK(m2.check_read(0, 30, 1, fillv(1, 0).data(), why));
    // discard of untouched blocks creates no history and stays zeros
    Model m3 = make_m0();
    m3.submit(T0, disc(0, 0, 0, 1024).w, nullptr);
    CHECK(m3.check_read(0, 500, 4, fillv(4, 0).data(), why));
  }
  { // failed WRITE: leading blocks applied, the rest old-or-new; ABORTED (nblk_done = 0): all old-or-new
    Model m = make_m0();
    Outcome w = m.submit(T0, wr(0, 0, 40, 4).w, fillv(4, 0x51).data());
    m.on_write_failed(w.wid, 2);
    CHECK(m.check_read(0, 40, 2, fillv(2, 0x51).data(), why));
    CHECK(!m.check_read(0, 42, 2, fillv(2, 0).data(), why));            // indeterminate: strict check refuses
    std::vector<uint8_t> got(4 * 512, 0);
    std::memcpy(got.data(), fillv(2, 0x51).data(), 1024);                // 40,41 new; 42,43 old
    CHECK_MSG(m.check_read_after_loss(0, 40, 4, got.data(), why), why);
    std::vector<uint8_t> got2(4 * 512, 0);                               // 40,41 reverted: impossible
    Model m2 = make_m0();
    Outcome w2 = m2.submit(T0, wr(0, 0, 40, 4).w, fillv(4, 0x51).data());
    m2.on_write_failed(w2.wid, 2);
    CHECK(!m2.check_read_after_loss(0, 40, 4, got2.data(), why));
    Model m3 = make_m0();
    Outcome w3 = m3.submit(T0, wr(0, 0, 40, 4).w, fillv(4, 0x51).data());
    m3.on_write_failed(w3.wid, 0);
    CHECK(m3.check_read_after_loss(0, 40, 4, fillv(4, 0).data(), why));
    Model m4 = make_m0();
    Outcome w4 = m4.submit(T0, wr(0, 0, 40, 4).w, fillv(4, 0x51).data());
    m4.on_write_failed(w4.wid, 0);
    CHECK(m4.check_read_after_loss(0, 40, 4, fillv(4, 0x51).data(), why));
  }
  { // power loss abandons pending commands (treated as maybe-applied)
    Model m = make_m0();
    m.submit(T0, wr(0, 0, 50, 1).w, fillv(1, 0x91).data());  // never completed
    m.power_loss();
    CHECK(m.check_read_after_loss(0, 50, 1, fillv(1, 0).data(), why));
    Model m2 = make_m0();
    m2.submit(T0, wr(0, 0, 50, 1).w, fillv(1, 0x91).data());
    m2.power_loss();
    CHECK(m2.check_read_after_loss(0, 50, 1, fillv(1, 0x91).data(), why));
  }
  { // write after recovery, then a second loss: both the observed pre-loss content and the new data are possible
    Model m = make_m0();
    Outcome a = m.submit(T0, wr(0, 0, 60, 1).w, fillv(1, 0xA1).data());
    m.on_write_complete(a.wid, false);
    m.power_loss();
    CHECK(m.check_read_after_loss(0, 60, 1, fillv(1, 0xA1).data(), why));  // observed: survived
    Outcome b = m.submit(T0, wr(0, 0, 60, 1).w, fillv(1, 0xA2).data());
    m.on_write_complete(b.wid, false);
    CHECK(m.check_read(0, 60, 1, fillv(1, 0xA2).data(), why));
    m.power_loss();
    CHECK(!m.check_read_after_loss(0, 60, 1, fillv(1, 0).data(), why));      // the survived one is the floor now
    CHECK(m.check_read_after_loss(0, 60, 1, fillv(1, 0xA1).data(), why));
  }
  { // post-recovery write while pre-loss versions are still unobserved: reads must return the new data
    Model m = make_m0();
    Outcome a = m.submit(T0, wr(0, 0, 70, 1).w, fillv(1, 0xB1).data());
    m.on_write_complete(a.wid, false);
    m.power_loss();
    Outcome b = m.submit(T0, wr(0, 0, 70, 1).w, fillv(1, 0xB2).data());
    m.on_write_complete(b.wid, false);
    CHECK(m.is_determinate(0, 70, 1));
    CHECK(m.check_read(0, 70, 1, fillv(1, 0xB2).data(), why));
    CHECK(!m.check_read(0, 70, 1, fillv(1, 0xB1).data(), why));
    m.power_loss();                                          // now old and new are all possible
    CHECK(m.candidates(0, 70) == 3);
  }
  { // Outcome of a READ reports indeterminacy
    Model m = make_m0();
    Outcome a = m.submit(T0, wr(0, 0, 80, 1).w, fillv(1, 0xC1).data());
    m.on_write_complete(a.wid, false);
    m.power_loss();
    Outcome r = m.submit(T0, rd(0, 0, 80, 1).w, nullptr);
    CHECK(r.read_indeterminate);
    Outcome r2 = m.submit(T0, rd(0, 0, 81, 1).w, nullptr);
    CHECK(!r2.read_indeterminate);
  }
}

// ---------------------------------------------------------------------------------------------
// Property test: model vs. a simulated backend with a volatile write cache that evicts at random,
// persists on FLUSH / FUA, and loses an arbitrary per-block prefix of its pending history on power loss.
struct Rng {
  uint64_t s;
  explicit Rng(uint64_t x) : s(x * 0x9E3779B97F4A7C15ull + 99) {}
  uint64_t next() { s ^= s >> 12; s ^= s << 25; s ^= s >> 27; return s * 0x2545F4914F6CDD1Dull; }
  uint64_t operator()(uint64_t n) { return next() % n; }
};
static void tag_block(uint32_t tag, uint8_t* b) {  // unique, non-zero content per tag; tag 0 = zeros
  if (tag == 0) { std::memset(b, 0, 512); return; }
  uint64_t x = tag * 0x9E3779B97F4A7C15ull;
  for (int i = 0; i < 512; i += 8) {
    x ^= x >> 13; x *= 0xFF51AFD7ED558CCDull; x ^= x >> 29;
    for (int k = 0; k < 8; ++k) b[i + k] = uint8_t(x >> (8 * k));
  }
  b[0] = uint8_t(tag); b[1] = uint8_t(tag >> 8); b[2] = uint8_t(tag >> 16); b[3] = uint8_t(tag >> 24);
}

struct SimBackend {
  std::map<uint64_t, uint32_t> media;                  // block -> tag
  std::map<uint64_t, std::deque<uint32_t>> cache;      // block -> pending tags, oldest first
  std::map<uint64_t, std::set<uint32_t>> ever;         // every tag ever written to the block (incl. 0)
  uint32_t visible(uint64_t b) const {
    auto c = cache.find(b);
    if (c != cache.end() && !c->second.empty()) return c->second.back();
    auto m = media.find(b);
    return m == media.end() ? 0 : m->second;
  }
  void write(uint64_t b, uint32_t tag) { cache[b].push_back(tag); ever[b].insert(tag); ever[b].insert(0); }
  void persist_block(uint64_t b) {  // FUA: this write and everything before it on the block
    auto& q = cache[b];
    if (!q.empty()) { media[b] = q.back(); q.clear(); }
  }
  void flush_all() { for (auto& kv : cache) persist_block(kv.first); }
  void evict(Rng& r) {
    std::vector<uint64_t> k;
    for (auto& kv : cache) if (!kv.second.empty()) k.push_back(kv.first);
    if (k.empty()) return;
    uint64_t b = k[r(k.size())];
    media[b] = cache[b].front();
    cache[b].pop_front();
  }
  void power_loss(Rng& r) {
    for (auto& kv : cache) {
      auto& q = kv.second;
      uint64_t keep = r(q.size() + 1);  // any prefix of the history reached the media
      if (keep) media[kv.first] = q[keep - 1];
      q.clear();
    }
  }
  uint32_t persistent(uint64_t b) const { auto m = media.find(b); return m == media.end() ? 0 : m->second; }
};

static void run_property(uint64_t seed, bool vol_wt) {
  Rng r(seed);
  BackendCaps c;
  c.capacity_blocks = 256;
  c.volatile_cache = !vol_wt;
  c.discard = c.discard_zero = true;
  Model m(2, 2, 4, c);
  NsCfg n;
  n.owner = 0; n.base = 0; n.size = 24;
  CHECK(m.cfg_ns(0, n).accepted);
  n.owner = 1; n.base = 24; n.size = 24;
  CHECK(m.cfg_ns(1, n).accepted);
  SimBackend sim;
  uint32_t next_tag = 1;
  std::string why;
  const unsigned size = 24;

  struct Op { unsigned t; Outcome o; uint64_t lba; uint32_t n; bool fua; bool disc; };
  for (int step = 0; step < 400; ++step) {
    const unsigned act = unsigned(r(100));
    if (act < 55) {  // 1..3 disjoint writes/discards of one tenant, completed in random order
      const unsigned t = unsigned(r(2));
      std::vector<Op> ops;
      std::vector<bool> used(size, false);
      const unsigned k = 1 + unsigned(r(3));
      for (unsigned i = 0; i < k; ++i) {
        uint32_t nb = 1 + uint32_t(r(4));
        uint64_t lba = r(size - nb + 1);
        bool clash = false;
        for (uint32_t j = 0; j < nb; ++j) clash = clash || used[lba + j];
        if (clash) continue;
        for (uint32_t j = 0; j < nb; ++j) used[lba + j] = true;
        const bool isd = r(6) == 0;
        const bool fua = !isd && r(4) == 0;
        std::vector<uint8_t> payload(nb * 512);
        W cmd = isd ? disc(t, t, lba, nb) : wr(t, t, lba, nb, fua ? F_FUA : 0);
        const uint64_t abs = (t ? 24 : 0) + lba;
        if (!isd)
          for (uint32_t j = 0; j < nb; ++j) tag_block(next_tag + j, payload.data() + j * 512);
        Outcome o = m.submit(t, cmd.w, isd ? nullptr : payload.data());
        CHECK(o.status == ST_SUCCESS);
        CHECK(o.durable == ((vol_wt || fua) ? 1 : 0));
        for (uint32_t j = 0; j < nb; ++j) {
          sim.write(abs + j, isd ? 0 : next_tag + j);
          if (!isd && (fua || vol_wt)) sim.persist_block(abs + j);
          if (isd && vol_wt) sim.persist_block(abs + j);
        }
        if (!isd) next_tag += nb;
        ops.push_back({t, o, lba, nb, fua, isd});
      }
      while (!ops.empty()) {  // random completion order
        size_t i = size_t(r(ops.size()));
        Op op = ops[i];
        ops.erase(ops.begin() + long(i));
        const bool dur = op.o.durable == 1;
        if (r(2)) m.on_write_complete(op.o.wid, dur);
        else m.on_write_complete(op.t, op.t, op.lba, op.n, dur);
      }
    } else if (act < 70) {  // FLUSH
      const unsigned t = unsigned(r(2));
      Outcome o = m.submit(t, flush(t, t).w, nullptr);
      CHECK(o.status == ST_SUCCESS && o.durable == 1);
      sim.flush_all();  // a backend FLUSH persists everything it has accepted
      m.on_flush_complete(t);
    } else if (act < 82) {
      sim.evict(r);  // spontaneous cache write-back: invisible to the model
    } else if (act < 92) {  // read compare (normal operation)
      const unsigned t = unsigned(r(2));
      uint32_t nb = 1 + uint32_t(r(4));
      uint64_t lba = r(size - nb + 1);
      Outcome o = m.submit(t, rd(t, t, lba, nb).w, nullptr);
      std::vector<uint8_t> got(nb * 512);
      for (uint32_t j = 0; j < nb; ++j) tag_block(sim.visible((t ? 24 : 0) + lba + j), got.data() + j * 512);
      CHECK_MSG(o.read_data == got, "model read_data differs from simulated backend");
      CHECK_MSG(m.check_read(t, lba, nb, got.data(), why), why);
    } else {  // power loss + exhaustive verification of every block
      sim.power_loss(r);
      m.power_loss();
      for (unsigned t = 0; t < 2; ++t) {
        for (uint64_t lba = 0; lba < size; ++lba) {
          const uint64_t abs = (t ? 24 : 0) + lba;
          // soundness: every content the backend can really hold is accepted
          uint8_t blk[512];
          tag_block(sim.persistent(abs), blk);
          // (accepting collapses the history, so probe with a copy of the check on a fresh clone for the negative probes)
          // completeness probes (never-written data) must be rejected without side effects:
          uint8_t bogus[512];
          tag_block(0x7FFF0000u + uint32_t(r(1000)), bogus);
          CHECK(!m.check_read_after_loss(t, lba, 1, bogus, why));
          CHECK_MSG(m.check_read_after_loss(t, lba, 1, blk, why),
                    why + " seed " + std::to_string(seed) + " step " + std::to_string(step));
          CHECK(m.is_determinate(t, lba, 1));
        }
      }
    }
  }
}

static void test_property() {
  section("property test: model vs simulated volatile-cache backend (§5.5)");
  for (uint64_t s = 1; s <= 60; ++s) run_property(s, false);
  for (uint64_t s = 1; s <= 10; ++s) run_property(s + 1000, true);
}

// ---------------------------------------------------------------------------------------------
static void test_gen() {
  section("Gen: valid / invalid descriptors with by-construction verdicts");
  struct Cfg { bool vol, discard, dz, pi; Interp ip; Features ft; };
  Interp ip2;
  ip2.rsv_flags_detail = DET_FLAGS;
  ip2.hostcrc_nz_is_flags = true;
  Interp ip3;
  ip3.key_all_ops = true;
  ip3.range_all_ops = true;
  Features nof;
  nof.fua = false;
  nof.hcrc = false;
  std::vector<Cfg> cfgs = {{true, true, true, true, Interp(), Features()}, {false, false, false, true, Interp(), Features()},
                           {true, true, false, true, Interp(), Features()}, {true, true, true, true, ip2, Features()},
                           {true, true, true, true, ip3, Features()}, {true, true, true, true, Interp(), nof}};
  uint64_t checked = 0, executed = 0;
  std::set<int> seen;
  for (size_t ci = 0; ci < cfgs.size(); ++ci) {
    const Cfg& cf = cfgs[ci];
    Model m = make_m0(cf.vol, cf.discard, cf.dz, cf.pi, cf.ip, cf.ft);
    m.set_key_ready(3, ci == 4);  // ns2 key ready only in cfg 4 (so valid data ops on ns2 also appear there)
    GenOpts go;
    go.allow_ambiguous = true;
    go.p_bad_hcrc_pct = 10;
    Gen g(m, 1234 + ci, go);
    for (unsigned t = 0; t < 4; ++t) {
      for (int f = 0; f < F__COUNT; ++f) {
        if (!g.applicable(t, Fault(f))) continue;
        for (int k = 0; k < 120; ++k) {
          GenCmd c = g.invalid(t, Fault(f), (k & 1) != 0);
          if (!c.valid_cmd) continue;
          Verdict v = m.validate(t, c.w, c.hw_binding);
          ++checked;
          seen.insert(f);
          CHECK_MSG(v.same(c.expect) && v.rule == c.expect.rule,
                    std::string("cfg ") + std::to_string(ci) + " tenant " + std::to_string(t) + " fault " +
                        fault_info(Fault(f)).name + " stacked " + std::to_string(c.stacked) + ": model " +
                        status_name(v.status) + "/" + std::to_string(v.detail) + " rule " + std::to_string(v.rule) +
                        " expected " + status_name(c.expect.status) + "/" + std::to_string(c.expect.detail) + " rule " +
                        std::to_string(c.expect.rule));
        }
      }
      // valid commands
      for (int k = 0; k < 600; ++k) {
        GenCmd c = g.valid(t);
        if (!c.valid_cmd) { CHECK(t == 3 || !g.has_ns(t)); break; }
        Verdict v = m.validate(t, c.w, c.hw_binding);
        CHECK_MSG(v.ok, std::string("valid cmd rejected: ") + status_name(v.status) + "/" + std::to_string(v.detail) + " rule " + std::to_string(v.rule));
        Outcome o = m.submit(t, c.w, c.payload.empty() ? nullptr : c.payload.data());
        CHECK(o.executed);
        CHECK(o.status == (c.bad_hcrc ? ST_DATA_CRC : ST_SUCCESS));
        if (o.wid) m.on_write_complete(o.wid, o.durable == 1);
        if (o.fid) m.on_flush_complete(t);
        ++executed;
      }
      // next(): the verdict always equals the by-construction expectation
      for (int k = 0; k < 600; ++k) {
        GenCmd c = g.next(t);
        if (!c.valid_cmd) break;
        Verdict v = m.validate(t, c.w, c.hw_binding);
        CHECK(v.same(c.expect));
        Outcome o = m.submit(t, c.w, c.payload.empty() ? nullptr : c.payload.data(), int(c.hw_binding));
        if (o.wid) m.on_write_complete(o.wid, o.durable == 1);
        if (o.fid) m.on_flush_complete(t);
      }
    }
    CHECK(m.violations().empty());
  }
  CHECK(checked > 20000 && executed > 5000);
  // all faults exercised at least once in some configuration
  for (int f = 0; f < F__COUNT; ++f) CHECK_MSG(seen.count(f) != 0, std::string("fault never generated: ") + fault_info(Fault(f)).name);

  // hot-LBA mode produces overlapping accesses; the model stays consistent with itself
  Model m = make_m0();
  GenOpts go;
  go.hot_lbas = 4;
  go.p_invalid_pct = 0;
  Gen g(m, 77, go);
  std::map<uint64_t, std::vector<uint8_t>> shadow;  // independent shadow of ns0 block contents
  std::string why;
  for (int k = 0; k < 3000; ++k) {
    GenCmd c = g.valid(0);
    if (!c.valid_cmd) continue;
    Desc d = decode(c.w);
    Outcome o = m.submit(0, c.w, c.payload.empty() ? nullptr : c.payload.data());
    if (o.wid) m.on_write_complete(o.wid, o.durable == 1);
    if (d.nsid != 0) continue;
    if (d.opcode == OP_WRITE && o.status == ST_SUCCESS)
      for (uint32_t i = 0; i < d.nblk; ++i) shadow[d.lba + i].assign(c.payload.begin() + i * 512, c.payload.begin() + (i + 1) * 512);
    if (d.opcode == OP_DISCARD)
      for (uint32_t i = 0; i < d.nblk; ++i) shadow.erase(d.lba + i);
    if (d.opcode == OP_READ) {
      bool good = true;
      for (uint32_t i = 0; i < d.nblk; ++i) {
        auto it = shadow.find(d.lba + i);
        const uint8_t* got = o.read_data.data() + i * 512;
        if (it == shadow.end()) { for (int b = 0; b < 512; ++b) good = good && got[b] == 0; }
        else good = good && std::memcmp(it->second.data(), got, 512) == 0;
      }
      CHECK(good);
    }
  }
}

static void test_codec_random() {
  section("decode/encode round trip, random words");
  Rng r(5);
  for (int i = 0; i < 2000; ++i) {
    uint32_t w[16], w2[16];
    for (auto& x : w) x = uint32_t(r.next());
    encode(decode(w), w2);
    CHECK(std::memcmp(w, w2, sizeof(w)) == 0);
  }
}

int main() {
  test_crc();
  test_pi_trailer();
  test_codec();
  test_codec_random();
  test_cfg_ns();
  test_rules();
  test_interp_detail();
  test_exec();
  test_counters_and_cqe();
  test_durability();
  test_property();
  test_gen();
  std::printf("sfref self-test: %d PASS, %d FAIL\n", g_pass, g_fail);
  std::printf(g_fail ? "RESULT: FAIL\n" : "RESULT: PASS\n");
  return g_fail ? 1 : 0;
}
