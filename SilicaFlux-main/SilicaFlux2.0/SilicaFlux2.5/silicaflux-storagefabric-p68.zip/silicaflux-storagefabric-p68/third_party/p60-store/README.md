# SilicaFlux Project 60 — StorageChip (`silicaflux_storage_top`)

A programmable storage controller assembled from the previous SilicaFlux storage projects and verified **in simulation** end to end:
host command queue → DMA → buffer SRAM → (XTS-AES) → BCH ECC → NAND channel → NAND digital twin, run by a **RISC-V ControlCore executing real firmware** (FTL with garbage collection, wear levelling, bad-block management, crash recovery).

> **Read this first.** Everything here is RTL/host simulation and open-source synthesis/PD *estimates*. **There is no FPGA, silicon or real-NAND evidence, no signoff, no certified endurance rating, no JEDEC/NVMe conformance.**
> Only `SILICAFLUX_STORE_MIN` is delivered; `SILICAFLUX_STORE_HPC` is not. See [`docs/12_RELEASE_READINESS.md`](docs/12_RELEASE_READINESS.md) and [`docs/11_KNOWN_LIMITATIONS.md`](docs/11_KNOWN_LIMITATIONS.md).

## Headline results (all simulation; reproduced by the `make` targets below)
| | |
|---|---|
| Full-chip regression | 19/19 runs pass, 23 473 checks, 0 failures ([`reports/regression_summary.md`](reports/regression_summary.md)) |
| Power-loss recovery | 28 injected power cuts (17 nested in recovery, 46 commands in flight) — **0 acknowledged writes lost** |
| ECC | k ≤ 8 raw bit errors per 512 B corrected exactly; k = 9…12 → explicit `MEDIA_UNREC` (never wrong data) |
| Boot policy | never formats a non-blank medium automatically; explicit `REBUILD`/`FORMAT` commands (scenario `noformat`) |
| Encryption | XTS-AES-256 at rest; ciphertext on the NAND equals an independent OpenSSL XTS computation (48 pages, 0 mismatches) |
| Formal | SFB2 host-BAR splitter and power-fail filter proven (SymbiYosys) |
| Benchmarks | RTL cycles at an assumed 100 MHz ([`reports/BENCH.md`](reports/BENCH.md)); read ≈ 5.3 k IOPS (512 B, QD1), WA 1.57 over the bench run |
| FPGA estimate | ≈ 29 k LUT6 / 14.8 k FF / 29.5 RAMB36 (Yosys, pre-P&R; [`reports/fpga_resource_estimate.md`](reports/fpga_resource_estimate.md)) |
| Physical design | one block (page engine) through OpenROAD on open sky130hd up to global routing (detailed route **not** completed), typical corner, **not signoff** ([`docs/09_PHYSICAL_DESIGN.md`](docs/09_PHYSICAL_DESIGN.md)) |

## Layout
```
rtl/top/            silicaflux_storage_top + reset sync, power-fail filter, host-BAR splitter, top control (IRQ, counters)
rtl/storage/        sfx_page_engine (SFB2 master: BCH enc/dec + XTS in place)            rtl/security/   XTS-AES-256 (sfx_aes_*)
rtl/soc/            sfs_storage_subsys.sv (GENERATED from vendor/p51 + patches/subsys_page_engine.patch)
vendor/             p51 StorageCore + ControlCore, p52 NAND twin, p54 BCH ECC (+N512T8U16 layout), p58b FTL library, p07 TestCore
fw/                 firmware (app/, include/) — builds p60_fw.hex (plain) and p60_fw_xts.hex (XTS)
tb/soc/             full-chip testbench + scenarios; tb/storage, tb/security unit benches; tb/models NAND model wrapper
formal/             SymbiYosys harnesses          endurance/  host FTL wear model          bench/  benchmark parser
fpga/               board-independent wrapper, UART host, constraint TEMPLATES, evidence/ (empty)
dft/                DFT status and plans          pd/  physical-design flow + open sky130hd views
scripts/            build, regress, coverage, synthesis, packaging       reports/  generated results       docs/  documentation
dashboard/          storage_health_dashboard.html (GET_LOG telemetry + endurance + benchmarks, simulation data)
```

## Quick start (Ubuntu 24.04; tools listed in the Makefile header)
```bash
make deps vectors fw      # tool check, P54 golden vectors for the new page layout, firmware images
make tb                   # Verilate the full chip (≈ 4–9 min)
make quick                # fast scenario subset (a few minutes)
make regress              # the full matrix (≈ 1 h with 3 jobs)  -> reports/regression_summary.md
make unit formal          # page-engine, XTS, FPGA-bridge unit benches; SymbiYosys proofs
make bench endurance dashboard
make synth fpga-synth cov pd zip
```
`make zip` builds the release archive (`scripts/package.sh`); it does not touch git.

## Documentation
| | |
|---|---|
| [`docs/00_AUDIT_P51_P59.md`](docs/00_AUDIT_P51_P59.md) | audit of the nine predecessor projects (what existed, what was re-run, classification) |
| [`docs/01_ARCHITECTURE.md`](docs/01_ARCHITECTURE.md) | top-level architecture, memory map, block provenance |
| [`docs/02_HOST_INTERFACE.md`](docs/02_HOST_INTERFACE.md) | SQ/CQ ABI, management commands, registers |
| [`docs/03_DATAPATH_AND_DURABILITY.md`](docs/03_DATAPATH_AND_DURABILITY.md) | write/read chains, page format, durability and recovery, boot policy |
| [`docs/04_SECURITY.md`](docs/04_SECURITY.md) | XTS-AES, key handling, what is and is not protected |
| [`docs/05_VERIFICATION.md`](docs/05_VERIFICATION.md) | verification layers, scenarios, defects found, results |
| [`docs/06_BENCHMARKS.md`](docs/06_BENCHMARKS.md) · [`docs/07_ENDURANCE.md`](docs/07_ENDURANCE.md) | benchmark method; endurance/wear model |
| [`docs/08_FPGA.md`](docs/08_FPGA.md) · [`docs/09_PHYSICAL_DESIGN.md`](docs/09_PHYSICAL_DESIGN.md) · [`docs/10_DFT.md`](docs/10_DFT.md) | FPGA, physical design, DFT/manufacturing status |
| [`docs/11_KNOWN_LIMITATIONS.md`](docs/11_KNOWN_LIMITATIONS.md) · [`docs/12_RELEASE_READINESS.md`](docs/12_RELEASE_READINESS.md) | limitations; release readiness against the brief |

## Licence and third-party material
No licence file exists in the source repository this was built from; **the owner must choose one before any redistribution.** `vendor/` contains earlier SilicaFlux projects as found (the only edits to them are listed in `docs/01_ARCHITECTURE.md` and are keepable as `.p54orig` backups / `patches/`). `pd/pdk/` holds open SkyWater sky130hd views (Apache-2.0, `pd/pdk/NOTICE.md`). P54 bundles a GPL-2.0 `bch.c` used only as a software cross-check; it is not part of any P60 hardware or firmware artefact.
