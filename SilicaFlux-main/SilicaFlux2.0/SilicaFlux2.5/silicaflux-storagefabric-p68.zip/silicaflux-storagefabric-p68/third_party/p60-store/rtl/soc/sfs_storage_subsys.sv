// =============================================================================
// SilicaFlux StorageCore :: sfs_storage_subsys -- everything storage-specific
//   *** P60 (SilicaFlux-STORE) variant: derived from the Project 51 file by scripts/make_subsys.py ***
//   Adds the page engine (sfx_page_engine: BCH ECC + XTS-AES) as storage-fabric master M_PE (BUF only)
//   with register page 15 (0x4000_F000).  See patches/subsys_page_engine.patch for the exact delta.
//
//   host BAR (SHC window) ──► sfs_host_if ──cmd──► sfs_cmd_ctrl ──tags──► firmware
//                                 ▲  └──cpl◄──────────┘ (validation, tag table)
//   ControlCore acc_rb pages 10..14 ─► SYS / CMD / DMA / NAND / HIF registers
//
//   Storage DataFabric (sfb_crossbar, DataFabric, unmodified; DW = DMA_DATA_WIDTH)
//     masters: m0 ControlCore EXT (via sfs_sfb_upsizer when DW > 32)
//              m1 sfs_dma
//              m2+c sfs_nand_ctrl channel c   (BUF only)
//     slaves : s0 BUF     buffer SRAM: sfras_sfb_ecc_slave (Project 26, SECDED,
//                         ENABLE_RAS = 1) or sfb_sram_slave (DataFabric)
//              s1 HOSTMEM host-memory window -> sfs_sfb_gate (refused unless the
//                         host enabled the controller) -> hm_* master port
//   NAND channel c pins -> external flash device(s)
//
// One clock (clk); reset rst_n = the ControlCore's accelerator-domain reset
// (sys reset AND NOT PMU.ACC_CTRL.RST): firmware can reset the whole storage
// subsystem.  Asynchronous inputs: nand_rb_n (per channel), pwr_fail_ni.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "sfras_defs.svh"
`default_nettype none

module sfs_storage_subsys
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
#(
  parameter int NUM_NAND_CHANNELS  = 1,
  parameter int CHANNEL_DATA_WIDTH = 8,
  parameter int BUFFER_SIZE_BYTES  = 16384,
  parameter int DMA_DATA_WIDTH     = 32,
  parameter int ADDRESS_WIDTH      = 32,
  parameter int CMD_QUEUE_DEPTH    = 8,
  parameter int ENABLE_ECC         = 1,
  parameter int ENABLE_RAS         = 1,
  parameter int NAND_PAGE_BYTES    = 512,
  parameter int SRAM_BACKEND       = `SRAM_BACKEND_GENERIC,
  localparam int NCH  = NUM_NAND_CHANNELS,
  localparam int CDW  = CHANNEL_DATA_WIDTH,
  localparam int DW   = DMA_DATA_WIDTH,
  localparam int SB   = DW / 8,
  localparam int HQD  = (2 * CMD_QUEUE_DEPTH > 64) ? 64 : 2 * CMD_QUEUE_DEPTH
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // ---------------------------------------------------------------- ControlCore EXT (SFB2 slave, 32-bit)
  input  wire logic              x_req_valid,
  output logic                   x_req_ready,
  input  wire logic              x_req_write,
  input  wire logic [31:0]       x_req_addr,
  input  wire logic [31:0]       x_req_wdata,
  input  wire logic [3:0]        x_req_wstrb,
  output logic                   x_rsp_valid,
  input  wire logic              x_rsp_ready,
  output logic [31:0]            x_rsp_rdata,
  output logic                   x_rsp_error,
  // ---------------------------------------------------------------- ControlCore accelerator register port
  input  wire logic              rb_sel,
  input  wire logic              rb_we,
  input  wire logic [15:0]       rb_addr,
  input  wire logic [31:0]       rb_wdata,
  output logic [31:0]            rb_rdata,
  output logic                   rb_err,
  // ---------------------------------------------------------------- host BAR, SHC window (SFB2 slave, 32-bit)
  input  wire logic              s_req_valid,
  output logic                   s_req_ready,
  input  wire logic              s_req_write,
  input  wire logic [31:0]       s_req_addr,
  input  wire logic [31:0]       s_req_wdata,
  input  wire logic [3:0]        s_req_wstrb,
  output logic                   s_rsp_valid,
  input  wire logic              s_rsp_ready,
  output logic [31:0]            s_rsp_rdata,
  output logic                   s_rsp_error,
  output logic                   host_irq,
  // ---------------------------------------------------------------- host memory (SFB2 master, DW)
  output logic                   hm_req_valid,
  input  wire logic              hm_req_ready,
  output logic                   hm_req_write,
  output logic [31:0]            hm_req_addr,
  output logic [DW-1:0]          hm_req_wdata,
  output logic [SB-1:0]          hm_req_wstrb,
  input  wire logic              hm_rsp_valid,
  output logic                   hm_rsp_ready,
  input  wire logic [DW-1:0]     hm_rsp_rdata,
  input  wire logic              hm_rsp_error,
  // ---------------------------------------------------------------- NAND channels
  output logic [NCH-1:0]         nand_ce_n,
  output logic [NCH-1:0]         nand_cle,
  output logic [NCH-1:0]         nand_ale,
  output logic [NCH-1:0]         nand_we_n,
  output logic [NCH-1:0]         nand_re_n,
  output logic [NCH-1:0]         nand_wp_n,
  output logic [NCH*CDW-1:0]     nand_dq_o,
  output logic [NCH-1:0]         nand_dq_oe,
  input  wire logic [NCH*CDW-1:0] nand_dq_i,
  input  wire logic [NCH-1:0]    nand_rb_n,
  // ---------------------------------------------------------------- system
  input  wire logic              pwr_fail_ni,
  input  wire logic              ev_sec_viol,        // host management access refused (SoC host gate)
  output logic                   mgmt_lock,
  output logic                   irq_io,
  output logic                   irq_evt,
  output logic                   busy_nand,
  output logic                   busy_io,
  output logic                   ext_warn,
  output logic                   ext_fatal
);
  // ================================================================ register-page routing (acc_rb_addr = {1, page-8, off})
  wire [2:0]  fidx = rb_addr[14:12];
  wire [11:0] roff = rb_addr[11:0];
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_rb = rb_addr[15];               // always 1 (forwarded page marker)
  /* verilator lint_on UNUSEDSIGNAL */
  wire sel_sys  = rb_sel && fidx == 3'(SFS_PG_SYS  - 8);
  wire sel_cmd  = rb_sel && fidx == 3'(SFS_PG_CMD  - 8);
  wire sel_dma  = rb_sel && fidx == 3'(SFS_PG_DMA  - 8);
  wire sel_nand = rb_sel && fidx == 3'(SFS_PG_NAND - 8);
  wire sel_hif  = rb_sel && fidx == 3'(SFS_PG_HIF  - 8);
  localparam int SFX_PG_PE = 15;                      // P60: page engine register page
  wire sel_pe   = rb_sel && fidx == 3'(SFX_PG_PE - 8);
  logic [31:0] rd_sys, rd_cmd, rd_dma, rd_hif, rd_nand, rd_pe;
  logic        er_sys, er_cmd, er_dma, er_hif, er_nand, er_pe;
  always_comb begin
    rb_rdata = 32'h0;
    rb_err   = 1'b1;                     // pages 8, 9: absent in the storage SoC
    if (fidx == 3'(SFS_PG_SYS - 8))  begin rb_rdata = rd_sys;  rb_err = er_sys;  end
    if (fidx == 3'(SFS_PG_CMD - 8))  begin rb_rdata = rd_cmd;  rb_err = er_cmd;  end
    if (fidx == 3'(SFS_PG_DMA - 8))  begin rb_rdata = rd_dma;  rb_err = er_dma;  end
    if (fidx == 3'(SFS_PG_NAND - 8)) begin rb_rdata = rd_nand; rb_err = er_nand; end
    if (fidx == 3'(SFS_PG_HIF - 8))  begin rb_rdata = rd_hif;  rb_err = er_hif;  end
    if (fidx == 3'(SFX_PG_PE - 8))   begin rb_rdata = rd_pe;   rb_err = er_pe;   end
  end

  // ================================================================ host interface + command controller
  sfs_cmd_t cmd;
  sfs_cpl_t cpl;
  logic cmd_valid, cmd_ready, cpl_valid, cpl_ready;
  logic [63:0] capacity;
  logic [15:0] mdts;
  logic outstanding_zero, plp_quiesce, wp_force, phys_en;
  logic hif_en, hif_rdy, hif_resetting, irq_hif, irq_cmd;
  logic pe_fetch, pe_cpl, pe_cq_full, ev_db_err, ev_cmd_fw, pe_lat_valid;
  logic [31:0] pe_lat;

  sfs_host_if #(.SQD(HQD), .CQD(HQD), .CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH), .ADDRESS_WIDTH(ADDRESS_WIDTH)) u_hif (
    .clk, .rst_n,
    .h_req_valid(s_req_valid), .h_req_ready(s_req_ready), .h_req_write(s_req_write), .h_req_addr(s_req_addr),
    .h_req_wdata(s_req_wdata), .h_req_wstrb(s_req_wstrb), .h_rsp_valid(s_rsp_valid), .h_rsp_ready(s_rsp_ready),
    .h_rsp_rdata(s_rsp_rdata), .h_rsp_error(s_rsp_error), .host_irq,
    .rb_sel(sel_hif), .rb_we, .rb_addr(roff), .rb_wdata, .rb_rdata(rd_hif), .rb_err(er_hif), .irq_hif,
    .cmd_valid, .cmd_ready, .cmd, .cpl_valid, .cpl_ready, .cpl,
    .capacity, .mdts, .outstanding_zero, .plp_quiesce,
    .en_o(hif_en), .rdy_o(hif_rdy), .resetting_o(hif_resetting),
    .ev_fetch(pe_fetch), .ev_cpl(pe_cpl), .ev_cq_stall(pe_cq_full), .ev_db_err
  );

  sfs_cmd_ctrl #(.CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH), .ADDRESS_WIDTH(ADDRESS_WIDTH), .HBUF_ALIGN(SB)) u_cmd (
    .clk, .rst_n,
    .cmd_valid, .cmd_ready, .cmd, .cpl_valid, .cpl_ready, .cpl,
    .rb_sel(sel_cmd), .rb_we, .rb_addr(roff), .rb_wdata, .rb_rdata(rd_cmd), .rb_err(er_cmd),
    .phys_en, .plp_quiesce, .resetting(hif_resetting),
    .capacity, .mdts, .outstanding_zero, .irq_cmd, .ev_fw_err(ev_cmd_fw),
    .ev_lat_valid(pe_lat_valid), .ev_lat(pe_lat)
  );

  // ================================================================ storage fabric
  localparam int M_PE = 2 + NCH;                      // P60: page engine master index
  localparam int NM = 3 + NCH;
  localparam int NS = 2;
  function automatic logic [NM*NS-1:0] f_en();
    f_en = '0;
    f_en[0*NS + 0] = 1'b1; f_en[0*NS + 1] = 1'b1;    // ControlCore -> BUF, HOSTMEM
    f_en[1*NS + 0] = 1'b1; f_en[1*NS + 1] = 1'b1;    // DMA         -> BUF, HOSTMEM
    for (int c = 0; c < NCH; c++) f_en[(2 + c)*NS + 0] = 1'b1;   // NAND -> BUF only
    f_en[M_PE*NS + 0] = 1'b1;                                    // P60 page engine -> BUF only
  endfunction
  localparam logic [NM*NS-1:0] MST_SLV_EN = f_en();
  localparam logic [NS*32-1:0] SLV_BASE   = {SFS_HOSTMEM_BASE, SFS_BUF_BASE};
  localparam logic [NS*32-1:0] SLV_MASK   = {~(SFS_HOSTMEM_WIN - 32'd1), ~(32'(BUFFER_SIZE_BYTES) - 32'd1)};

  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*32-1:0] m_req_addr;
  logic [NM*DW-1:0] m_req_wdata, m_rsp_rdata;
  logic [NM*SB-1:0] m_req_wstrb;
  logic [NS-1:0]    s_rq_valid, s_rq_ready, s_rq_write, s_rs_valid, s_rs_ready, s_rs_error;
  logic [NS*32-1:0] s_rq_addr;
  logic [NS*DW-1:0] s_rq_wdata, s_rs_rdata;
  logic [NS*SB-1:0] s_rq_wstrb;
  logic             fab_err_evt;
  logic [31:0]      fab_err_addr;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(NM)-1:0] fab_err_m;
  logic             fab_err_w;
  logic [NM-1:0]    fev_acc, fev_stall, fev_loss, fev_rstall;
  /* verilator lint_on UNUSEDSIGNAL */

  sfb_crossbar #(
    .NM(NM), .NS(NS), .AW(32), .DW(DW), .ARB_MODE(1), .CHECK_ALIGN(1),
    .SLV_BASE(SLV_BASE), .SLV_MASK(SLV_MASK), .MST_SLV_EN(MST_SLV_EN)
  ) u_fabric (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid(s_rq_valid), .s_req_ready(s_rq_ready), .s_req_write(s_rq_write), .s_req_addr(s_rq_addr),
    .s_req_wdata(s_rq_wdata), .s_req_wstrb(s_rq_wstrb), .s_rsp_valid(s_rs_valid), .s_rsp_ready(s_rs_ready),
    .s_rsp_rdata(s_rs_rdata), .s_rsp_error(s_rs_error),
    .err_evt(fab_err_evt), .err_addr(fab_err_addr), .err_master(fab_err_m), .err_write(fab_err_w),
    .ev_req_accept(fev_acc), .ev_req_stall(fev_stall), .ev_arb_loss(fev_loss), .ev_rsp_stall(fev_rstall)
  );

  // ---------------------------------------------------------------- m0: ControlCore EXT
  sfs_sfb_upsizer #(.DW(DW)) u_up (
    .clk, .rst_n,
    .s_req_valid(x_req_valid), .s_req_ready(x_req_ready), .s_req_write(x_req_write), .s_req_addr(x_req_addr),
    .s_req_wdata(x_req_wdata), .s_req_wstrb(x_req_wstrb), .s_rsp_valid(x_rsp_valid), .s_rsp_ready(x_rsp_ready),
    .s_rsp_rdata(x_rsp_rdata), .s_rsp_error(x_rsp_error),
    .m_req_valid(m_req_valid[0]), .m_req_ready(m_req_ready[0]), .m_req_write(m_req_write[0]),
    .m_req_addr(m_req_addr[0 +: 32]), .m_req_wdata(m_req_wdata[0 +: DW]), .m_req_wstrb(m_req_wstrb[0 +: SB]),
    .m_rsp_valid(m_rsp_valid[0]), .m_rsp_ready(m_rsp_ready[0]), .m_rsp_rdata(m_rsp_rdata[0 +: DW]),
    .m_rsp_error(m_rsp_error[0])
  );

  // ---------------------------------------------------------------- m1: storage DMA
  logic irq_dma, dma_busy, pe_dma_word, ev_dma_err, ev_dma_fw;
  sfs_dma #(.DW(DW)) u_dma (
    .clk, .rst_n,
    .rb_sel(sel_dma), .rb_we, .rb_addr(roff), .rb_wdata, .rb_rdata(rd_dma), .rb_err(er_dma),
    .m_req_valid(m_req_valid[1]), .m_req_ready(m_req_ready[1]), .m_req_write(m_req_write[1]),
    .m_req_addr(m_req_addr[32 +: 32]), .m_req_wdata(m_req_wdata[DW +: DW]), .m_req_wstrb(m_req_wstrb[SB +: SB]),
    .m_rsp_valid(m_rsp_valid[1]), .m_rsp_ready(m_rsp_ready[1]), .m_rsp_rdata(m_rsp_rdata[DW +: DW]),
    .m_rsp_error(m_rsp_error[1]),
    .irq_dma, .busy(dma_busy), .ev_word(pe_dma_word), .ev_err(ev_dma_err), .ev_fw_err(ev_dma_fw)
  );

  // ---------------------------------------------------------------- m(2+NCH): P60 page engine (BCH ECC + XTS-AES)
  logic pe_busy, pe_ev_corr, pe_ev_unc, pe_ev_int, pe_fault;
  /* verilator lint_off UNUSEDSIGNAL */
  logic pe_ev_scrub_u;
  /* verilator lint_on UNUSEDSIGNAL */
  sfx_page_engine #(.XTS_KEYBITS(256)) u_pe (
    .clk, .rst_n,
    .rb_sel(sel_pe), .rb_we, .rb_addr(roff), .rb_wdata, .rb_rdata(rd_pe), .rb_err(er_pe),
    .m_req_valid(m_req_valid[M_PE]), .m_req_ready(m_req_ready[M_PE]), .m_req_write(m_req_write[M_PE]),
    .m_req_addr(m_req_addr[M_PE*32 +: 32]), .m_req_wdata(m_req_wdata[M_PE*DW +: 32]),
    .m_req_wstrb(m_req_wstrb[M_PE*SB +: 4]), .m_rsp_valid(m_rsp_valid[M_PE]), .m_rsp_ready(m_rsp_ready[M_PE]),
    .m_rsp_rdata(m_rsp_rdata[M_PE*DW +: 32]), .m_rsp_error(m_rsp_error[M_PE]),
    .busy(pe_busy), .ev_ecc_corr(pe_ev_corr), .ev_ecc_unc(pe_ev_unc), .ev_integrity(pe_ev_int),
    .ev_scrub(pe_ev_scrub_u), .ev_fault(pe_fault)
  );

  // ---------------------------------------------------------------- m2+c: NAND channels
  logic [NCH-1:0] ch_irq, ch_busy, ch_rd, ch_pg, ch_er, ch_ce, ch_ue, ch_tmo, ch_fw;
  logic [NCH*32-1:0] ch_rdata;
  logic [NCH-1:0]    ch_err;
  wire [3:0] nsel = roff[11:8];
  genvar gc;
  for (gc = 0; gc < NCH; gc++) begin : g_ch
    localparam int M = 2 + gc;
    sfs_nand_ctrl #(
      .CH(gc), .CDW(CDW), .DW(DW), .PAGE_BYTES(NAND_PAGE_BYTES), .ENABLE_ECC(ENABLE_ECC)
    ) u_nand (
      .clk, .rst_n,
      .rb_sel(sel_nand && nsel == 4'(gc)), .rb_we, .rb_addr(roff[7:0]), .rb_wdata,
      .rb_rdata(ch_rdata[gc*32 +: 32]), .rb_err(ch_err[gc]),
      .m_req_valid(m_req_valid[M]), .m_req_ready(m_req_ready[M]), .m_req_write(m_req_write[M]),
      .m_req_addr(m_req_addr[M*32 +: 32]), .m_req_wdata(m_req_wdata[M*DW +: DW]),
      .m_req_wstrb(m_req_wstrb[M*SB +: SB]), .m_rsp_valid(m_rsp_valid[M]), .m_rsp_ready(m_rsp_ready[M]),
      .m_rsp_rdata(m_rsp_rdata[M*DW +: DW]), .m_rsp_error(m_rsp_error[M]),
      .nand_ce_n(nand_ce_n[gc]), .nand_cle(nand_cle[gc]), .nand_ale(nand_ale[gc]), .nand_we_n(nand_we_n[gc]),
      .nand_re_n(nand_re_n[gc]), .nand_wp_n(nand_wp_n[gc]), .nand_dq_o(nand_dq_o[gc*CDW +: CDW]),
      .nand_dq_oe(nand_dq_oe[gc]), .nand_dq_i(nand_dq_i[gc*CDW +: CDW]), .nand_rb_n(nand_rb_n[gc]),
      .wp_force, .irq(ch_irq[gc]), .busy(ch_busy[gc]),
      .ev_rd_page(ch_rd[gc]), .ev_prog(ch_pg[gc]), .ev_erase(ch_er[gc]), .ev_ce(ch_ce[gc]), .ev_ue(ch_ue[gc]),
      .ev_tmo(ch_tmo[gc]), .ev_fw_err(ch_fw[gc])
    );
  end
  always_comb begin
    rd_nand = 32'h0;
    er_nand = 1'b1;
    for (int c = 0; c < NCH; c++) if (nsel == 4'(c)) begin
      rd_nand = ch_rdata[c*32 +: 32];
      er_nand = ch_err[c];
    end
  end
  function automatic logic [3:0] popc(input logic [NCH-1:0] v);
    popc = '0;
    for (int i = 0; i < NCH; i++) popc = popc + 4'(v[i]);
  endfunction

  // ---------------------------------------------------------------- s0: buffer SRAM
  localparam int BDEPTH = BUFFER_SIZE_BYTES / SB;
  localparam int BAW    = $clog2(BDEPTH);
  logic           buf_ready, buf_ev_ce, buf_ev_ue, fi_arm, fi_aen, fi_armed;
  logic [BAW-1:0] buf_ev_addr;
  logic [1:0]     fi_mode;
  logic [31:0]    fi_mask;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0]    fi_addr;                    // word index: BAW bits used
  /* verilator lint_on UNUSEDSIGNAL */
  generate
    if (ENABLE_RAS != 0) begin : g_buf_ecc
      localparam int KC = DW + 1;                         // data + poison bit
      localparam int R  = $clog2(KC + $clog2(KC + 1) + 1);
      localparam int N  = KC + R + 1;
      /* verilator lint_off UNUSEDSIGNAL */
      logic rsp_poison_u, scr_ready_u, scr_rv_u, scr_ce_u, scr_ue_u, scr_po_u, scr_wb_u, init_busy_u, tst_ready_u;
      logic [1:0] scr_op_u;
      logic [BAW-1:0] scr_addr_u, fi_faddr_u;
      logic fi_fired_u;
      logic [N-1:0] tst_rdata_u;
      logic ev_valid, ev_poison_u;
      logic [2:0] ev_org_u;
      logic [R:0] ev_syn_u;
      logic [$clog2(N)-1:0] ev_idx_u;
      /* verilator lint_on UNUSEDSIGNAL */
      logic ev_ce_raw, ev_ue_raw;
      sfras_sfb_ecc_slave #(.DW(DW), .DEPTH(BDEPTH), .READ_LATENCY(1), .BACKEND(SRAM_BACKEND), .FI_EN(1)) u_buf (
        .clk, .rst_n,
        .req_valid(s_rq_valid[0]), .req_ready(s_rq_ready[0]), .req_write(s_rq_write[0]), .req_addr(s_rq_addr[0 +: 32]),
        .req_wdata(s_rq_wdata[0 +: DW]), .req_wstrb(s_rq_wstrb[0 +: SB]), .rsp_valid(s_rs_valid[0]),
        .rsp_ready(s_rs_ready[0]), .rsp_rdata(s_rs_rdata[0 +: DW]), .rsp_error(s_rs_error[0]), .rsp_poison(rsp_poison_u),
        .scr_req_valid(1'b0), .scr_req_ready(scr_ready_u), .scr_req_op(2'b0), .scr_req_addr('0),
        .scr_rsp_valid(scr_rv_u), .scr_rsp_op(scr_op_u), .scr_rsp_addr(scr_addr_u), .scr_rsp_ce(scr_ce_u),
        .scr_rsp_ue(scr_ue_u), .scr_rsp_poison(scr_po_u), .scr_rsp_wb(scr_wb_u),
        .init_req_i(1'b0), .init_busy_o(init_busy_u), .init_done_o(buf_ready),
        .tst_active(1'b0), .tst_ready(tst_ready_u), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0),
        .tst_rdata(tst_rdata_u),
        .ev_valid, .ev_ce(ev_ce_raw), .ev_ue(ev_ue_raw), .ev_poison(ev_poison_u), .ev_org(ev_org_u),
        .ev_addr(buf_ev_addr), .ev_syn(ev_syn_u), .ev_idx(ev_idx_u),
        .fi_arm_i(fi_arm), .fi_mode_i(fi_mode), .fi_mask_i(N'(fi_mask)), .fi_addr_en_i(fi_aen),
        .fi_addr_i(fi_addr[BAW-1:0]), .fi_armed_o(fi_armed), .fi_fired_o(fi_fired_u), .fi_fired_addr_o(fi_faddr_u)
      );
      assign buf_ev_ce = ev_valid && ev_ce_raw;
      assign buf_ev_ue = ev_valid && ev_ue_raw;
    end else begin : g_buf_plain
      /* verilator lint_off UNUSEDSIGNAL */
      logic [DW-1:0] tst_rdata_u;
      wire unused_fi = fi_arm ^ fi_aen ^ ^fi_mode ^ ^fi_mask ^ ^fi_addr;
      /* verilator lint_on UNUSEDSIGNAL */
      sfb_sram_slave #(.DW(DW), .DEPTH(BDEPTH), .READ_LATENCY(1), .BACKEND(SRAM_BACKEND)) u_buf (
        .clk, .rst_n,
        .req_valid(s_rq_valid[0]), .req_ready(s_rq_ready[0]), .req_write(s_rq_write[0]), .req_addr(s_rq_addr[0 +: 32]),
        .req_wdata(s_rq_wdata[0 +: DW]), .req_wstrb(s_rq_wstrb[0 +: SB]), .rsp_valid(s_rs_valid[0]),
        .rsp_ready(s_rs_ready[0]), .rsp_rdata(s_rs_rdata[0 +: DW]), .rsp_error(s_rs_error[0]),
        .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(tst_rdata_u)
      );
      assign buf_ready   = 1'b1;
      assign buf_ev_ce   = 1'b0;
      assign buf_ev_ue   = 1'b0;
      assign buf_ev_addr = '0;
      assign fi_armed    = 1'b0;
    end
  endgenerate

  // ---------------------------------------------------------------- s1: host memory window -> hm_* (bus mastering gate)
  logic hm_refused;
  sfs_sfb_gate #(.DW(DW)) u_hm_gate (
    .clk, .rst_n,
    .s_req_valid(s_rq_valid[1]), .s_req_ready(s_rq_ready[1]), .s_req_write(s_rq_write[1]),
    .s_req_addr(s_rq_addr[32 +: 32] - SFS_HOSTMEM_BASE), .s_req_wdata(s_rq_wdata[DW +: DW]),
    .s_req_wstrb(s_rq_wstrb[SB +: SB]), .s_rsp_valid(s_rs_valid[1]), .s_rsp_ready(s_rs_ready[1]),
    .s_rsp_rdata(s_rs_rdata[DW +: DW]), .s_rsp_error(s_rs_error[1]),
    .m_req_valid(hm_req_valid), .m_req_ready(hm_req_ready), .m_req_write(hm_req_write), .m_req_addr(hm_req_addr),
    .m_req_wdata(hm_req_wdata), .m_req_wstrb(hm_req_wstrb), .m_rsp_valid(hm_rsp_valid), .m_rsp_ready(hm_rsp_ready),
    .m_rsp_rdata(hm_rsp_rdata), .m_rsp_error(hm_rsp_error),
    .refuse(!hif_en), .refused_evt(hm_refused)
  );

  // ================================================================ system page
  sfs_sys_regs #(
    .NUM_NAND_CHANNELS(NCH), .CHANNEL_DATA_WIDTH(CDW), .BUFFER_SIZE_BYTES(BUFFER_SIZE_BYTES),
    .DMA_DATA_WIDTH(DW), .ADDRESS_WIDTH(ADDRESS_WIDTH), .CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH),
    .ENABLE_ECC(ENABLE_ECC), .ENABLE_RAS(ENABLE_RAS), .NAND_PAGE_BYTES(NAND_PAGE_BYTES),
    .HOST_QUEUE_DEPTH(HQD), .BUF_AW(BAW)
  ) u_sys (
    .clk, .rst_n,
    .rb_sel(sel_sys), .rb_we, .rb_addr(roff), .rb_wdata, .rb_rdata(rd_sys), .rb_err(er_sys),
    .buf_ready, .nand_idle(ch_busy == '0), .dma_idle(!dma_busy && !pe_busy), .hif_en, .hif_rdy, .cmd_idle(outstanding_zero),
    .src_cmd(irq_cmd), .src_dma(irq_dma), .src_nand(|ch_irq), .src_hif(irq_hif),
    .irq_io, .irq_evt,
    .pwr_fail_ni, .plp_quiesce, .wp_force,
    .phys_en, .mgmt_lock, .ev_sec_viol,
    .ev_buf_ce(buf_ev_ce), .ev_buf_ue(buf_ev_ue), .ev_buf_addr(buf_ev_addr),
    .ev_nand_ce_n(popc(ch_ce) + 4'(pe_ev_corr)), .ev_nand_ue_n(popc(ch_ue) + 4'(pe_ev_unc || pe_ev_int)),
    .ev_dma_err(ev_dma_err || hm_refused || pe_fault), .ev_nand_tmo(|ch_tmo), .ev_fab_dec(fab_err_evt), .ev_fab_addr(fab_err_addr),
    .ev_fw_proto(ev_cmd_fw || ev_dma_fw || (|ch_fw)), .ev_hif_db(ev_db_err),
    .ext_warn, .ext_fatal,
    .fi_arm, .fi_mode, .fi_mask, .fi_addr_en(fi_aen), .fi_addr, .fi_armed,
    .pe_fetch, .pe_cpl, .pe_dma_word, .pe_nand_rd_n(popc(ch_rd)), .pe_nand_pg_n(popc(ch_pg)),
    .pe_nand_er_n(popc(ch_er)), .pe_nand_busy(|ch_busy), .pe_fab_stall(|(m_req_valid & ~m_req_ready)),
    .pe_cq_full(pe_cq_full), .pe_lat_valid, .pe_lat
  );

  assign busy_nand = |ch_busy;
  assign busy_io   = dma_busy || pe_busy || !outstanding_zero;
endmodule

`default_nettype wire
