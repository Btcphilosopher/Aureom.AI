// =============================================================================
// SilicaFlux-STORE P60 :: sfx_hb_split -- host BAR splitter (SFB2 slave -> SoC host port | top-level local window)
//   address[31:28] == 4'hC : local window (top control, TestCore registers) via a request/done port
//   otherwise              : the SoC host port (management window 0x0000_0000.., storage host controller 0x8000_0000..)
// One transaction outstanding (SFB2 host rule).  Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sfx_hb_split (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // host (SFB2 slave)
  input  wire logic        s_req_valid,
  output logic             s_req_ready,
  input  wire logic        s_req_write,
  input  wire logic [31:0] s_req_addr,
  input  wire logic [31:0] s_req_wdata,
  input  wire logic [3:0]  s_req_wstrb,
  output logic             s_rsp_valid,
  input  wire logic        s_rsp_ready,
  output logic [31:0]      s_rsp_rdata,
  output logic             s_rsp_error,
  // SoC host port (SFB2 master)
  output logic             m_req_valid,
  input  wire logic        m_req_ready,
  output logic             m_req_write,
  output logic [31:0]      m_req_addr,
  output logic [31:0]      m_req_wdata,
  output logic [3:0]       m_req_wstrb,
  input  wire logic        m_rsp_valid,
  output logic             m_rsp_ready,
  input  wire logic [31:0] m_rsp_rdata,
  input  wire logic        m_rsp_error,
  // local window: request held until done
  output logic             l_req,
  output logic             l_we,
  output logic [15:0]      l_addr,
  output logic [31:0]      l_wdata,
  input  wire logic        l_done,
  input  wire logic [31:0] l_rdata,
  input  wire logic        l_err
);
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_wstrb = |s_req_wstrb;
  /* verilator lint_on UNUSEDSIGNAL */
  wire is_local = (s_req_addr[31:28] == 4'hC);
  typedef enum logic [1:0] { S_IDLE, S_SOC, S_LOC, S_RSP } st_e;
  st_e st;
  logic [31:0] rd_q;
  logic        err_q;
  logic [15:0] la_q; logic [31:0] ld_q; logic lw_q;     // local request, captured at acceptance (the host drops it)

  assign m_req_valid = s_req_valid && !is_local && (st == S_IDLE);
  assign m_req_write = s_req_write;
  assign m_req_addr  = s_req_addr;
  assign m_req_wdata = s_req_wdata;
  assign m_req_wstrb = s_req_wstrb;
  assign s_req_ready = (st == S_IDLE) && (is_local ? 1'b1 : m_req_ready);

  assign l_req   = (st == S_LOC);
  assign l_we    = lw_q;
  assign l_addr  = la_q;
  assign l_wdata = ld_q;

  always_comb begin
    s_rsp_valid = 1'b0; s_rsp_rdata = 32'h0; s_rsp_error = 1'b0; m_rsp_ready = 1'b0;
    case (st)
      S_SOC: begin s_rsp_valid = m_rsp_valid; s_rsp_rdata = m_rsp_rdata; s_rsp_error = m_rsp_error; m_rsp_ready = s_rsp_ready; end
      S_RSP: begin s_rsp_valid = 1'b1; s_rsp_rdata = rd_q; s_rsp_error = err_q; end
      default: ;
    endcase
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin st <= S_IDLE; rd_q <= '0; err_q <= 1'b0; la_q <= '0; ld_q <= '0; lw_q <= 1'b0; end
    else begin
      case (st)
        S_IDLE: if (s_req_valid) begin
          if (is_local) begin st <= S_LOC; la_q <= s_req_addr[15:0]; ld_q <= s_req_wdata; lw_q <= s_req_write; end
          else if (m_req_ready) st <= S_SOC;
        end
        S_SOC: if (m_rsp_valid && s_rsp_ready) st <= S_IDLE;
        S_LOC: if (l_done) begin rd_q <= l_rdata; err_q <= l_err; st <= S_RSP; end
        S_RSP: if (s_rsp_ready) st <= S_IDLE;
        default: st <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
