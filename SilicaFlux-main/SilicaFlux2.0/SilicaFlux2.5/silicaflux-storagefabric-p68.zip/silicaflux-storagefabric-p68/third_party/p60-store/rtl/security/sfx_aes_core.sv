// -----------------------------------------------------------------------------
// sfx_aes_core -- iterative AES-128/256 block cipher (encrypt and decrypt),
// one round per clock, FIPS-197 "straightforward" inverse cipher.
//
// Project : SilicaFlux-STORE P60 (SecureStore)
//
// The expanded key schedule is an INPUT (flat vector, round key r at
// rk[128*r +: 128], r = 0..Nr, Nr = KEYBITS/32+6).  Within a round key, word
// w[4r+c] sits at bits [32*c +: 32] and key byte b of that word at [8*b +: 8],
// i.e. byte i of the 16-byte round-key string is rk[128*r + 8*i +: 8].
// Block byte i is blk[8*i +: 8] (FIPS-197 state s[r][c] = byte r+4c).
//
// Handshake / timing (cycle 0 = cycle in which `start` is sampled high):
//   * start is honoured only while !busy; blk_in, dec and rk[round 0 / Nr] are
//     used in that cycle only (dec is latched internally).  rk[] must then stay
//     stable while busy.
//   * busy is high in cycles 1..Nr, vld goes high in cycle Nr+1 (11 for AES-128,
//     15 for AES-256) and stays high, with blk_out holding the result, until the
//     next accepted start (or clr / reset).  vld is low in cycle 1..Nr.
//   * clr (synchronous, e.g. key zeroize) and !rst_n clear the state register.
// -----------------------------------------------------------------------------
module sfx_aes_core #(
  parameter int KEYBITS = 128                  // 128 or 256
) (
  input  logic                           clk,
  input  logic                           rst_n,
  input  logic                           clr,      // synchronous clear, highest priority
  input  logic [128*(KEYBITS/32+7)-1:0]  rk,       // expanded key schedule
  input  logic                           start,
  input  logic                           dec,      // 0 = encrypt, 1 = decrypt (sampled with start)
  input  logic [127:0]                   blk_in,
  output logic                           busy,
  output logic                           vld,
  output logic [127:0]                   blk_out
);

  localparam int NR = KEYBITS/32 + 6;
  localparam logic [3:0] NR4 = 4'(NR);

  // ---------------------------------------------------------------- functions
  function automatic logic [7:0] xtime(input logic [7:0] b);
    xtime = {b[6:0], 1'b0} ^ (b[7] ? 8'h1b : 8'h00);
  endfunction

  function automatic logic [31:0] mixcol(input logic [31:0] c);
    logic [7:0] a0, a1, a2, a3;
    a0 = c[7:0];
    a1 = c[15:8];
    a2 = c[23:16];
    a3 = c[31:24];
    mixcol[7:0]   = xtime(a0) ^ (xtime(a1) ^ a1) ^ a2 ^ a3;
    mixcol[15:8]  = a0 ^ xtime(a1) ^ (xtime(a2) ^ a2) ^ a3;
    mixcol[23:16] = a0 ^ a1 ^ xtime(a2) ^ (xtime(a3) ^ a3);
    mixcol[31:24] = (xtime(a0) ^ a0) ^ a1 ^ a2 ^ xtime(a3);
  endfunction

  // GF(2^8) multiples used by InvMixColumns
  function automatic logic [7:0] mul9(input logic [7:0] b);
    mul9 = xtime(xtime(xtime(b))) ^ b;
  endfunction

  function automatic logic [7:0] mul11(input logic [7:0] b);
    mul11 = xtime(xtime(xtime(b))) ^ xtime(b) ^ b;
  endfunction

  function automatic logic [7:0] mul13(input logic [7:0] b);
    mul13 = xtime(xtime(xtime(b))) ^ xtime(xtime(b)) ^ b;
  endfunction

  function automatic logic [7:0] mul14(input logic [7:0] b);
    mul14 = xtime(xtime(xtime(b))) ^ xtime(xtime(b)) ^ xtime(b);
  endfunction

  function automatic logic [31:0] invmixcol(input logic [31:0] c);
    logic [7:0] a0, a1, a2, a3;
    a0 = c[7:0];
    a1 = c[15:8];
    a2 = c[23:16];
    a3 = c[31:24];
    invmixcol[7:0]   = mul14(a0) ^ mul11(a1) ^ mul13(a2) ^ mul9(a3);
    invmixcol[15:8]  = mul9(a0)  ^ mul14(a1) ^ mul11(a2) ^ mul13(a3);
    invmixcol[23:16] = mul13(a0) ^ mul9(a1)  ^ mul14(a2) ^ mul11(a3);
    invmixcol[31:24] = mul11(a0) ^ mul13(a1) ^ mul9(a2)  ^ mul14(a3);
  endfunction

  function automatic logic [127:0] shift_rows(input logic [127:0] s);
    for (int c = 0; c < 4; c++) begin
      for (int r = 0; r < 4; r++) begin
        shift_rows[8*(4*c+r) +: 8] = s[8*(4*((c+r)%4)+r) +: 8];
      end
    end
  endfunction

  function automatic logic [127:0] inv_shift_rows(input logic [127:0] s);
    for (int c = 0; c < 4; c++) begin
      for (int r = 0; r < 4; r++) begin
        inv_shift_rows[8*(4*((c+r)%4)+r) +: 8] = s[8*(4*c+r) +: 8];
      end
    end
  endfunction

  function automatic logic [127:0] mix_columns(input logic [127:0] s);
    for (int c = 0; c < 4; c++) begin
      mix_columns[32*c +: 32] = mixcol(s[32*c +: 32]);
    end
  endfunction

  function automatic logic [127:0] inv_mix_columns(input logic [127:0] s);
    for (int c = 0; c < 4; c++) begin
      inv_mix_columns[32*c +: 32] = invmixcol(s[32*c +: 32]);
    end
  endfunction

  // ---------------------------------------------------------------- registers
  logic [127:0] state_q;
  logic [3:0]   ridx_q;      // round-key index used by the round being computed
  logic         dec_q;
  logic         busy_q;
  logic         vld_q;

  // ---------------------------------------------------------------- datapath
  logic [127:0] sb_f, sb_i;  // S-box / inverse S-box of every state byte

  for (genvar i = 0; i < 16; i++) begin : g_sbox
    sfx_aes_sbox #(.INV(1'b0)) u_f (.a(state_q[8*i +: 8]), .y(sb_f[8*i +: 8]));
    sfx_aes_sbox #(.INV(1'b1)) u_i (.a(state_q[8*i +: 8]), .y(sb_i[8*i +: 8]));
  end

  // round key of the round being computed (ridx_q is always within 0..NR)
  wire [127:0] rk_cur = rk[128*ridx_q +: 128];

  wire          last_round = dec_q ? (ridx_q == 4'd0) : (ridx_q == NR4);

  wire [127:0] enc_t      = shift_rows(sb_f);
  wire [127:0] enc_n      = (last_round ? enc_t : mix_columns(enc_t)) ^ rk_cur;
  wire [127:0] dec_t      = inv_shift_rows(sb_i) ^ rk_cur;
  wire [127:0] dec_n      = last_round ? dec_t : inv_mix_columns(dec_t);
  wire [127:0] next_state = dec_q ? dec_n : enc_n;

  // round 0 (initial AddRoundKey) happens in the start cycle
  wire [127:0] rk_first = dec ? rk[128*NR +: 128] : rk[127:0];

  always_ff @(posedge clk) begin
    if (!rst_n || clr) begin
      state_q <= '0;
      ridx_q  <= '0;
      dec_q   <= 1'b0;
      busy_q  <= 1'b0;
      vld_q   <= 1'b0;
    end else if (start && !busy_q) begin
      state_q <= blk_in ^ rk_first;
      dec_q   <= dec;
      ridx_q  <= dec ? (NR4 - 4'd1) : 4'd1;
      busy_q  <= 1'b1;
      vld_q   <= 1'b0;
    end else if (busy_q) begin
      state_q <= next_state;
      ridx_q  <= dec_q ? (ridx_q - 4'd1) : (ridx_q + 4'd1);
      if (last_round) begin
        busy_q <= 1'b0;
        vld_q  <= 1'b1;
      end
    end
  end

  assign busy    = busy_q;
  assign vld     = vld_q;
  assign blk_out = state_q;

endmodule
