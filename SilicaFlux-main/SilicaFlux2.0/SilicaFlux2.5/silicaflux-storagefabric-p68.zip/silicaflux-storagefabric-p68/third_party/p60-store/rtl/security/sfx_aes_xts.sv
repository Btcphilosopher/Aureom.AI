// -----------------------------------------------------------------------------
// sfx_aes_xts -- XTS-AES storage-encryption core (IEEE Std 1619-2007 /
// NIST SP 800-38E), whole 16-byte blocks only (no ciphertext stealing).
//
// Project : SilicaFlux-STORE P60 (SecureStore)
//
// One data unit = `nblocks` (1..65535) 16-byte blocks.  One block at a time is
// processed by an iterative AES core (1 round/cycle).  Full interface, timing,
// reset/zeroize/ignore rules and resource numbers: see README.md.
//
//   T_0 = AES_Enc(key2, tweak);  T_j = T_0 * alpha^j  (GF(2^128), x^128+x^7+x^2+x+1,
//   little-endian: multiply-by-alpha = 128-bit left shift, 0x87 fed into byte 0)
//   C_j = AES_Enc(key1, P_j ^ T_j) ^ T_j       (decrypt: AES_Dec(key1, .))
//
// Key handling: key words are written with key_we/key_widx/key_wdata directly
// into words 0..Nk-1 of the two round-key register files (rk1_q = key1, rk2_q =
// key2); key_commit expands the remaining schedule words in place.  Key
// registers have no read path to any output port.  key_zeroize (or reset)
// clears raw key, expanded schedules, tweak/T state, AES state and aborts any
// unit.
// -----------------------------------------------------------------------------
module sfx_aes_xts #(
  parameter int KEYBITS = 128                   // size of EACH key: 128 or 256
) (
  input  logic         clk,
  input  logic         rst_n,                   // synchronous active-low reset
  // ---- key interface (write-only) ----
  input  logic         key_we,
  input  logic [4:0]   key_widx,
  input  logic [31:0]  key_wdata,
  input  logic         key_commit,
  input  logic         key_zeroize,
  output logic         key_ready,
  // ---- unit control ----
  input  logic         start,
  input  logic         decrypt,
  input  logic [127:0] tweak,
  input  logic [15:0]  nblocks,
  output logic         start_err,
  // ---- data stream ----
  input  logic         in_valid,
  output logic         in_ready,
  input  logic [127:0] in_data,
  output logic         out_valid,
  input  logic         out_ready,
  output logic [127:0] out_data,
  output logic         out_last,
  output logic         busy
);

  localparam int NK  = KEYBITS/32;              // words per key
  localparam int NR  = NK + 6;                  // rounds
  localparam int NW  = 4*(NR+1);                // schedule words per key
  localparam int RKW = 32*NW;                   // schedule bits per key

  // main FSM
  localparam logic [2:0] S_IDLE = 3'd0;         // idle: key load / commit / start
  localparam logic [2:0] S_EXA  = 3'd1;         // key1 expansion: load window
  localparam logic [2:0] S_EXB  = 3'd2;         // key1 expansion: running
  localparam logic [2:0] S_EXC  = 3'd3;         // key2 expansion: load window
  localparam logic [2:0] S_EXD  = 3'd4;         // key2 expansion: running
  localparam logic [2:0] S_T0   = 3'd5;         // computing T_0 = AES_Enc(key2, tweak)
  localparam logic [2:0] S_IN   = 3'd6;         // waiting for the next input beat
  localparam logic [2:0] S_BLK  = 3'd7;         // AES running / result presented

  function automatic logic [127:0] alpha_mul(input logic [127:0] t);
    alpha_mul = {t[126:0], 1'b0} ^ (t[127] ? 128'h87 : 128'h0);
  endfunction

  // ---------------------------------------------------------------- state
  logic [2:0]        state_q;
  logic              key_ready_q;
  logic [2*NK-1:0]   kmask_q;                   // key words written since last zeroize/reset
  logic [127:0]      t_q;                       // current tweak value T_j
  logic              dec_q;
  logic [15:0]       remain_q;                  // blocks of the unit not yet delivered
  logic              start_err_q;

  wire [RKW-1:0]     rk1_q;                     // key1 (data key) schedule, word w at [32*w +: 32]
  wire [RKW-1:0]     rk2_q;                     // key2 (tweak key) schedule

  wire clear = !rst_n || key_zeroize;           // synchronous clear of all key/state registers

  // ------------------------------------------------------------ AES core, expander
  logic [127:0] core_blk_out;
  logic         core_vld, core_busy;
  logic         core_start, core_dec;
  logic [127:0] core_blk;

  wire          k2sel     = (state_q == S_IDLE) || (state_q == S_T0);   // T_0 uses key2
  wire [RKW-1:0] core_rk  = k2sel ? rk2_q : rk1_q;

  sfx_aes_core #(.KEYBITS(KEYBITS)) u_core (
    .clk(clk), .rst_n(rst_n), .clr(key_zeroize),
    .rk(core_rk), .start(core_start), .dec(core_dec), .blk_in(core_blk),
    .busy(core_busy), .vld(core_vld), .blk_out(core_blk_out)
  );

  logic          kx_start, kx_done, kx_we;
  logic [5:0]    kx_idx;
  logic [31:0]   kx_data;
  wire  [KEYBITS-1:0] kx_key = (state_q == S_EXC) ? rk2_q[KEYBITS-1:0] : rk1_q[KEYBITS-1:0];
  wire           kx_sel = (state_q == S_EXC) || (state_q == S_EXD);   // 1 = writing key2 schedule

  assign kx_start = (state_q == S_EXA) || (state_q == S_EXC);

  sfx_aes_keyexp #(.KEYBITS(KEYBITS)) u_kx (
    .clk(clk), .rst_n(rst_n), .clr(key_zeroize),
    .start(kx_start), .key_in(kx_key),
    .done(kx_done), .wr_en(kx_we), .wr_idx(kx_idx), .wr_data(kx_data)
  );

  // ------------------------------------------------------------ request decode
  wire idle    = (state_q == S_IDLE);
  // priority: key_zeroize > key_we > key_commit > start
  wire kwe_ok  = key_we && idle && (key_widx < 5'(2*NK));
  wire kcm_ok  = key_commit && idle && !key_we && (&kmask_q);
  wire st_ok   = start && idle && key_ready_q && !key_we && !key_commit
                 && (nblocks != 16'd0) && !key_zeroize;

  // one-hot of the key word being written, for the "all key words written" mask
  logic [2*NK-1:0] kmask_set;
  for (genvar m = 0; m < 2*NK; m++) begin : g_kmask
    assign kmask_set[m] = (key_widx == 5'(m));
  end

  wire [127:0] t_next = alpha_mul(t_q);               // T_{j+1} = T_j * alpha

  wire in_acc  = in_valid && in_ready;
  wire out_xfer = out_valid && out_ready;

  assign core_start = st_ok || in_acc;
  assign core_dec   = (state_q == S_IN) ? dec_q : 1'b0;
  assign core_blk   = (state_q == S_IN) ? (in_data ^ t_q) : tweak;

  // ------------------------------------------------------------ key register files
  // Each 32-bit word has exactly one writer: words [0, Nk) come from the key
  // interface, words [Nk, 4(Nr+1)) from the expander.
  for (genvar g = 0; g < NW; g++) begin : g_rk
    logic [31:0] w1_q, w2_q;
    if (g < NK) begin : g_key
      always_ff @(posedge clk) begin
        if (clear) begin
          w1_q <= 32'h0;
          w2_q <= 32'h0;
        end else begin
          if (kwe_ok && (key_widx == 5'(g)))      w1_q <= key_wdata;
          if (kwe_ok && (key_widx == 5'(NK + g))) w2_q <= key_wdata;
        end
      end
    end else begin : g_exp
      always_ff @(posedge clk) begin
        if (clear) begin
          w1_q <= 32'h0;
          w2_q <= 32'h0;
        end else if (kx_we && (kx_idx == 6'(g))) begin
          if (kx_sel) w2_q <= kx_data;
          else        w1_q <= kx_data;
        end
      end
    end
    assign rk1_q[32*g +: 32] = w1_q;
    assign rk2_q[32*g +: 32] = w2_q;
  end

  // ------------------------------------------------------------ control FSM
  always_ff @(posedge clk) begin
    if (clear) begin
      state_q     <= S_IDLE;
      key_ready_q <= 1'b0;
      kmask_q     <= '0;
      t_q         <= 128'h0;
      dec_q       <= 1'b0;
      remain_q    <= 16'h0;
    end else begin
      case (state_q)
        S_IDLE: begin
          if (kwe_ok) begin
            key_ready_q <= 1'b0;                          // schedule no longer matches key
            kmask_q     <= kmask_q | kmask_set;
          end else if (kcm_ok) begin
            key_ready_q <= 1'b0;
            state_q     <= S_EXA;
          end else if (st_ok) begin
            state_q     <= S_T0;
            dec_q       <= decrypt;
            remain_q    <= nblocks;
          end
        end
        S_EXA: state_q <= S_EXB;
        S_EXB: if (kx_done) state_q <= S_EXC;
        S_EXC: state_q <= S_EXD;
        S_EXD: begin
          if (kx_done) begin
            state_q     <= S_IDLE;
            key_ready_q <= 1'b1;
          end
        end
        S_T0: begin
          if (core_vld) begin
            t_q     <= core_blk_out;                      // T_0
            state_q <= S_IN;
          end
        end
        S_IN: if (in_acc) state_q <= S_BLK;
        S_BLK: begin
          if (out_xfer) begin
            remain_q <= remain_q - 16'd1;
            if (remain_q == 16'd1) begin
              state_q <= S_IDLE;                          // unit complete
              t_q     <= 128'h0;
            end else begin
              state_q <= S_IN;
              t_q     <= t_next;                          // T_{j+1}
            end
          end
        end
        default: state_q <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) start_err_q <= 1'b0;
    else        start_err_q <= start && !st_ok;
  end

  // ------------------------------------------------------------ outputs
  wire blk_vld = (state_q == S_BLK) && core_vld && !key_zeroize;

  assign in_ready   = (state_q == S_IN) && !core_busy && !key_zeroize;
  assign out_valid  = blk_vld;
  assign out_data   = blk_vld ? (core_blk_out ^ t_q) : 128'h0;
  assign out_last   = blk_vld && (remain_q == 16'd1);
  assign busy       = (state_q == S_T0) || (state_q == S_IN) || (state_q == S_BLK);
  assign key_ready  = key_ready_q;
  assign start_err  = start_err_q;

endmodule
