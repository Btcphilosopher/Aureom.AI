// SilicaFlux-STORE P60 :: sfx_pwr_cond -- power-fail input (active low, asynchronous): 2-flop synchroniser + glitch filter;
// asserts after FILTER consecutive low clocks, releases after FILTER consecutive highs.  Classification: SYNTHESIZABLE
`default_nettype none
module sfx_pwr_cond #(
  parameter int FILTER = 4
) (
  input  wire logic clk,
  input  wire logic rst_n,
  input  wire logic pwr_fail_n_i,           // asynchronous, active low
  output logic      pwr_fail_n_o,           // conditioned, active low
  output logic      pf_event                // one-cycle pulse when the fault asserts
);
  localparam int CW = (FILTER > 1) ? $clog2(FILTER + 1) : 1;
  logic s0, s1, st;
  logic [CW-1:0] cnt;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin s0 <= 1'b1; s1 <= 1'b1; st <= 1'b1; cnt <= '0; pf_event <= 1'b0; end
    else begin
      s0 <= pwr_fail_n_i; s1 <= s0;
      pf_event <= 1'b0;
      if (s1 == st) cnt <= '0;
      else if (cnt == CW'(FILTER - 1)) begin st <= s1; cnt <= '0; if (!s1) pf_event <= 1'b1; end
      else cnt <= cnt + 1'b1;
    end
  end
  assign pwr_fail_n_o = st;
endmodule
`default_nettype wire
