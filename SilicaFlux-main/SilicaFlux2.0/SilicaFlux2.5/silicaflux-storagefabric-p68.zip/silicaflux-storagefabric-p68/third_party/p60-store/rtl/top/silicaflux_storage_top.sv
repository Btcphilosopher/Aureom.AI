// =============================================================================
// SilicaFlux-STORE P60 :: silicaflux_storage_top -- complete storage-controller top level
//
//   host BAR (SFB2 slave) --> sfx_hb_split --+--> silicaflux_storage_soc   (P51 base, P60 patched subsystem)
//                                            |      ControlCore RV32IM + INTC/WDT/PMU/perf/RAS/mailbox/secmon
//                                            |      storage command processor: sfs_host_if (SQ/CQ) + sfs_cmd_ctrl
//                                            |      host DMA (sfs_dma), storage DataFabric (sfb_crossbar)
//                                            |      SRAM buffer (SECDED RAS slave), NAND channel controller(s)
//                                            |      page engine: ECCCore BCH t=8 + SecureStore XTS-AES (P60)
//                                            |      power-fail / write-protect / quiesce, security locks (sfs_sys_regs)
//                                            +--> local window 0xC000_0000: sfx_top_ctrl
//                                                   chip IRQ controller, pin-level performance counters, reset cause,
//                                                   DFT status, TestCore (P07: JTAG TAP + MBIST engine + test-mode ctl)
//   reset: por_n (async) -> 2-flop synchroniser -> rst_n;  power fail: synchroniser + glitch filter
//
// SILICAFLUX_STORE_MIN : 1 NAND channel, 512 B logical block, BCH t=8, optional XTS-AES, firmware FTL with
//                        crash recovery (the configuration verified in this release).
// SILICAFLUX_STORE_HPC : NUM_NAND_CHANNELS up to 4 elaborates at RTL level (the P51 subsystem and the page engine
//                        are channel-count generic) but the firmware, HAL and verification are MIN ONLY; the NVMe front
//                        end (P57) and the physical PCIe endpoint are NOT integrated (no PCIe IP in the repository).
// Classification: SYNTHESIZABLE (NAND model, host memory and firmware loader are testbench items)
// =============================================================================
`default_nettype none

module silicaflux_storage_top #(
  parameter int NUM_NAND_CHANNELS  = 1,
  parameter int CHANNEL_DATA_WIDTH = 8,
  parameter int BUFFER_SIZE_BYTES  = 16384,
  parameter int DMA_DATA_WIDTH     = 32,
  parameter int ADDRESS_WIDTH      = 32,
  parameter int CMD_QUEUE_DEPTH    = 8,
  parameter int NAND_PAGE_BYTES    = 544,
  parameter int PF_FILTER          = 4,
  parameter int HPC                = 0,
  parameter int SRAM_BACKEND       = 0,          // 0 generic flop array (simulation/ASIC study), 1 FPGA block-RAM inference, 2 ASIC macros (not available)
  localparam int NCH = NUM_NAND_CHANNELS,
  localparam int CDW = CHANNEL_DATA_WIDTH,
  localparam int DW  = DMA_DATA_WIDTH,
  localparam int SB  = DW / 8
) (
  input  wire logic              clk,
  input  wire logic              por_n,                   // power-on reset (asynchronous, active low)
  input  wire logic              pwr_fail_n,              // supply-fail warning (asynchronous, active low)
  input  wire logic [1:0]        boot_mode,               // ControlCore boot source (host load in this release)
  input  wire logic              host_rst_req,
  // ---------------------------------------------------------------- host BAR (SFB2 slave, 32 bit)
  input  wire logic              hb_req_valid,
  output logic                   hb_req_ready,
  input  wire logic              hb_req_write,
  input  wire logic [31:0]       hb_req_addr,
  input  wire logic [31:0]       hb_req_wdata,
  input  wire logic [3:0]        hb_req_wstrb,
  output logic                   hb_rsp_valid,
  input  wire logic              hb_rsp_ready,
  output logic [31:0]            hb_rsp_rdata,
  output logic                   hb_rsp_error,
  // ---------------------------------------------------------------- host memory (SFB2 master, DW)
  output logic                   hm_req_valid,
  input  wire logic              hm_req_ready,
  output logic                   hm_req_write,
  output logic [31:0]            hm_req_addr,
  output logic [DW-1:0]          hm_req_wdata,
  output logic [SB-1:0]          hm_req_wstrb,
  input  wire logic              hm_rsp_valid,
  output logic                   hm_rsp_ready,
  input  wire logic [DW-1:0]     hm_rsp_rdata,
  input  wire logic              hm_rsp_error,
  // ---------------------------------------------------------------- NAND channels
  output logic [NCH-1:0]         nand_ce_n,
  output logic [NCH-1:0]         nand_cle,
  output logic [NCH-1:0]         nand_ale,
  output logic [NCH-1:0]         nand_we_n,
  output logic [NCH-1:0]         nand_re_n,
  output logic [NCH-1:0]         nand_wp_n,
  output logic [NCH*CDW-1:0]     nand_dq_o,
  output logic [NCH-1:0]         nand_dq_oe,
  input  wire logic [NCH*CDW-1:0] nand_dq_i,
  input  wire logic [NCH-1:0]    nand_rb_n,
  // ---------------------------------------------------------------- JTAG / DFT
  input  wire logic              tck,
  input  wire logic              trst_n,
  input  wire logic              tms,
  input  wire logic              tdi,
  output logic                   tdo,
  output logic                   tdo_oe,
  input  wire logic              hw_dbg_en,               // strap: JTAG debug permitted
  input  wire logic              hw_test_en,              // strap: production test permitted
  input  wire logic              scan_mode_pin,
  input  wire logic              scan_en_pin,
  // ---------------------------------------------------------------- status
  output logic                   irq_o,                   // chip-level aggregate (sfx_top_ctrl IRQ_MASK)
  output logic                   host_irq_o,
  output logic                   mgmt_irq_o,
  output logic                   host_ready_o,
  output logic                   cmdproc_ready_o,
  output logic                   ras_fatal_o,
  output logic                   diag_valid_o,
  output logic [7:0]             diag_char_o,
  output logic                   test_done_o,
  output logic                   test_fail_o,
  output logic [15:0]            test_code_o,
  output logic                   cpu_sleep_o
);
  // ---------------------------------------------------------------- reset / power conditioning
  logic rst_n, pwr_fail_clean_n, pf_event;
  sfx_rst_sync u_rst (.clk, .arst_n(por_n), .scan_mode(scan_mode_pin), .rst_n);
  sfx_pwr_cond #(.FILTER(PF_FILTER)) u_pf (.clk, .rst_n, .pwr_fail_n_i(pwr_fail_n), .pwr_fail_n_o(pwr_fail_clean_n), .pf_event);

  // ---------------------------------------------------------------- TestCore (JTAG TAP + test-mode controller + MBIST engine)
  logic tc_req, tc_we, tc_gnt, tc_err, tc_irq, tc_mbist_busy, tc_scan_mode, tc_jtag_mode, tc_diag_mode;
  /* verilator lint_off UNUSEDSIGNAL */
  logic tc_scan_en;                                  // scan enable: routed to the scan-chain controller in the DFT insertion step
  /* verilator lint_on UNUSEDSIGNAL */
  /* verilator lint_off UNUSEDSIGNAL */
  logic tc_test_done, tc_test_pass, tc_test_fail;   // wafer-probe status pins: bonded out only in the production package variant
  /* verilator lint_on UNUSEDSIGNAL */
  logic [11:0] tc_addr; logic [31:0] tc_wdata, tc_rdata; logic [2:0] tc_mode;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        tc_b_req, tc_b_we, tc_acq_req, tc_scrub_done, tc_owner_clr, tc_scan_en_u, tc_test_pass_u, tc_test_done_u, tc_test_fail_u;
  logic [7:0]  tc_b_addr; logic [31:0] tc_b_wdata;
  /* verilator lint_on UNUSEDSIGNAL */
  sftc_testcore_top #(.BANK_COUNT(1), .MAX_W(32), .MAX_DEPTH(256)) u_tc (
    .tck, .trst_n, .tms, .tdi, .tdo, .tdo_oe,
    .clk, .rst_n,
    .hw_dbg_en, .hw_test_en, .cpu_halted(cpu_sleep_o), .scan_mode_pin, .scan_en_pin,
    .s_req(tc_req), .s_we(tc_we), .s_addr(tc_addr), .s_wdata(tc_wdata), .s_gnt(tc_gnt), .s_rdata(tc_rdata), .s_err(tc_err),
    .b_req(tc_b_req), .b_we(tc_b_we), .b_addr(tc_b_addr), .b_wdata(tc_b_wdata),
    .b_gnt(1'b0), .b_rvalid(1'b0), .b_rdata(32'h0), .b_rerr(1'b0),            // no SRAM bank is MBIST-wrapped in this release (documented gap)
    .acq_req(tc_acq_req), .scrub_done(tc_scrub_done), .mbist_busy(tc_mbist_busy), .owner_fault_clear(tc_owner_clr),
    .owner_state(3'b000), .owned(1'b0), .owner_dirty(1'b0), .owner_ev_fault(1'b0), .owner_ev_intrusion(1'b0), .owner_ev_reinit(1'b0),
    .mode(tc_mode), .scan_mode(tc_scan_mode), .scan_en(tc_scan_en), .irq(tc_irq),
    .test_done_o(tc_test_done), .test_pass_o(tc_test_pass), .test_fail_o(tc_test_fail),
    .jtag_mode_o(tc_jtag_mode), .diag_mode_o(tc_diag_mode)
  );

  // ---------------------------------------------------------------- host BAR splitter + chip control
  logic        soc_hb_req_valid, soc_hb_req_ready, soc_hb_req_write, soc_hb_rsp_valid, soc_hb_rsp_ready, soc_hb_rsp_error;
  logic [31:0] soc_hb_req_addr, soc_hb_req_wdata, soc_hb_rsp_rdata;
  logic [3:0]  soc_hb_req_wstrb;
  logic        l_req, l_we, l_done, l_err;
  logic [15:0] l_addr; logic [31:0] l_wdata, l_rdata;
  sfx_hb_split u_split (
    .clk, .rst_n,
    .s_req_valid(hb_req_valid), .s_req_ready(hb_req_ready), .s_req_write(hb_req_write), .s_req_addr(hb_req_addr),
    .s_req_wdata(hb_req_wdata), .s_req_wstrb(hb_req_wstrb),
    .s_rsp_valid(hb_rsp_valid), .s_rsp_ready(hb_rsp_ready), .s_rsp_rdata(hb_rsp_rdata), .s_rsp_error(hb_rsp_error),
    .m_req_valid(soc_hb_req_valid), .m_req_ready(soc_hb_req_ready), .m_req_write(soc_hb_req_write), .m_req_addr(soc_hb_req_addr),
    .m_req_wdata(soc_hb_req_wdata), .m_req_wstrb(soc_hb_req_wstrb),
    .m_rsp_valid(soc_hb_rsp_valid), .m_rsp_ready(soc_hb_rsp_ready), .m_rsp_rdata(soc_hb_rsp_rdata), .m_rsp_error(soc_hb_rsp_error),
    .l_req, .l_we, .l_addr, .l_wdata, .l_done, .l_rdata, .l_err
  );

  logic soc_host_irq, soc_mgmt_irq, soc_host_ready, soc_cmdproc_ready, soc_ras_fatal, soc_test_done;
  sfx_top_ctrl #(.NCH(NCH), .CDW(CDW), .DW(DW), .CFG(HPC != 0 ? 2 : 1)) u_ctrl (
    .clk, .rst_n,
    .l_req, .l_we, .l_addr, .l_wdata, .l_done, .l_rdata, .l_err,
    .host_irq(soc_host_irq), .mgmt_irq(soc_mgmt_irq), .ras_fatal(soc_ras_fatal), .cmdproc_ready(soc_cmdproc_ready),
    .pf_event, .pwr_fail_n(pwr_fail_clean_n), .host_rst_req, .test_done(soc_test_done),
    .hm_req_valid, .hm_req_ready, .hm_req_write,
    .bar_req_valid(hb_req_valid), .bar_req_ready(hb_req_ready), .bar_req_write(hb_req_write),
    .nand_rb_n(nand_rb_n[0]),
    .hw_dbg_en, .hw_test_en, .scan_mode(tc_scan_mode | scan_mode_pin), .mbist_busy(tc_mbist_busy), .jtag_mode(tc_jtag_mode),
    .diag_mode(tc_diag_mode), .tc_mode, .tc_irq,
    .tc_req, .tc_we, .tc_addr, .tc_wdata, .tc_gnt, .tc_rdata, .tc_err,
    .irq_o
  );

  // ---------------------------------------------------------------- the storage SoC
  silicaflux_storage_soc #(
    .NUM_NAND_CHANNELS(NCH), .CHANNEL_DATA_WIDTH(CDW), .BUFFER_SIZE_BYTES(BUFFER_SIZE_BYTES), .DMA_DATA_WIDTH(DW),
    .ADDRESS_WIDTH(ADDRESS_WIDTH), .CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH), .ENABLE_ECC(0), .ENABLE_RAS(1), .NAND_PAGE_BYTES(NAND_PAGE_BYTES), .SRAM_BACKEND(SRAM_BACKEND)
  ) u_soc (
    .clk, .rst_ni(rst_n), .test_mode(tc_scan_mode | scan_mode_pin), .boot_mode_i(boot_mode), .host_rst_req_i(host_rst_req),
    .pwr_fail_ni(pwr_fail_clean_n),
    .hb_req_valid(soc_hb_req_valid), .hb_req_ready(soc_hb_req_ready), .hb_req_write(soc_hb_req_write), .hb_req_addr(soc_hb_req_addr),
    .hb_req_wdata(soc_hb_req_wdata), .hb_req_wstrb(soc_hb_req_wstrb),
    .hb_rsp_valid(soc_hb_rsp_valid), .hb_rsp_ready(soc_hb_rsp_ready), .hb_rsp_rdata(soc_hb_rsp_rdata), .hb_rsp_error(soc_hb_rsp_error),
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .host_irq_o(soc_host_irq), .mgmt_irq_o(soc_mgmt_irq), .host_ready_o(soc_host_ready), .cmdproc_ready_o(soc_cmdproc_ready),
    .ras_fatal_o(soc_ras_fatal),
    .nand_ce_n, .nand_cle, .nand_ale, .nand_we_n, .nand_re_n, .nand_wp_n, .nand_dq_o, .nand_dq_oe, .nand_dq_i, .nand_rb_n,
    .diag_valid_o(diag_valid_o), .diag_char_o(diag_char_o), .test_done_o(soc_test_done), .test_fail_o(test_fail_o),
    .test_code_o(test_code_o), .cpu_sleep_o(cpu_sleep_o)
  );
  assign host_irq_o      = soc_host_irq;
  assign mgmt_irq_o      = soc_mgmt_irq;
  assign host_ready_o    = soc_host_ready;
  assign cmdproc_ready_o = soc_cmdproc_ready;
  assign ras_fatal_o     = soc_ras_fatal;
  assign test_done_o     = soc_test_done;
endmodule

`default_nettype wire
