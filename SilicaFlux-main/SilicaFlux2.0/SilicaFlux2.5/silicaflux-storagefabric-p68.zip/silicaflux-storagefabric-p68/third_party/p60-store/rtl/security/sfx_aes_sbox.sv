// -----------------------------------------------------------------------------
// sfx_aes_sbox -- AES S-box (INV=0) / inverse S-box (INV=1), combinational 256x8 ROM.
// FIPS-197 Figure 7 / Figure 14.  Tables generated from the GF(2^8) definition by
// model/xts_ref.py (SBOX[0x00]=0x63, SBOX[0x53]=0xed, INV[0x63]=0x00) and checked
// end to end by the FIPS-197 / SP 800-38A KATs in tb/security/tb_sfx_aes_xts.sv.
// Entry i is TBL[8*i +: 8]; each row below holds 16 entries, entry 16r in the low byte.
// (Written as a constant vector rather than a case statement so that Yosys does not
//  infer a ROM and retime the state register into duplicated read-data flops.)
// Project: SilicaFlux-STORE P60 (SecureStore)
// -----------------------------------------------------------------------------
module sfx_aes_sbox #(
  parameter bit INV = 1'b0
) (
  input  logic [7:0] a,
  output logic [7:0] y
);

  localparam logic [2047:0] TBL_F = {
    128'h16bb54b00f2d99416842e6bf0d89a18c,  // 0xf0..0xff
    128'hdf2855cee9871e9b948ed9691198f8e1,  // 0xe0..0xef
    128'h9e1dc186b95735610ef6034866b53e70,  // 0xd0..0xdf
    128'h8a8bbd4b1f74dde8c6b4a61c2e2578ba,  // 0xc0..0xcf
    128'h08ae7a65eaf4566ca94ed58d6d37c8e7,  // 0xb0..0xbf
    128'h79e4959162acd3c25c2406490a3a32e0,  // 0xa0..0xaf
    128'hdb0b5ede14b8ee4688902a22dc4f8160,  // 0x90..0x9f
    128'h73195d643d7ea7c41744975fec130ccd,  // 0x80..0x8f
    128'hd2f3ff1021dab6bcf5389d928f40a351,  // 0x70..0x7f
    128'ha89f3c507f02f94585334d43fbaaefd0,  // 0x60..0x6f
    128'hcf584c4a39becb6a5bb1fc20ed00d153,  // 0x50..0x5f
    128'h842fe329b3d63b52a05a6e1b1a2c8309,  // 0x40..0x4f
    128'h75b227ebe28012079a059618c323c704,  // 0x30..0x3f
    128'h1531d871f1e5a534ccf73f362693fdb7,  // 0x20..0x2f
    128'hc072a49cafa2d4adf04759fa7dc982ca,  // 0x10..0x1f
    128'h76abd7fe2b670130c56f6bf27b777c63   // 0x00..0x0f
  };

  localparam logic [2047:0] TBL_I = {
    128'h7d0c2155631469e126d677ba7e042b17,  // 0xf0..0xff
    128'h619953833cbbebc8b0f52aae4d3be0a0,  // 0xe0..0xef
    128'hef9cc9939f7ae52d0d4ab519a97f5160,  // 0xd0..0xdf
    128'h5fec8027591012b131c7078833a8dd1f,  // 0xc0..0xcf
    128'hf45acd78fec0db9a2079d2c64b3e56fc,  // 0xb0..0xbf
    128'h1bbe18aa0e62b76f89c5291d711af147,  // 0xa0..0xaf
    128'h6edf751ce837f9e28535ade72274ac96,  // 0x90..0x9f
    128'h73e6b4f0cecff297eadc674f4111913a,  // 0x80..0x8f
    128'h6b8a130103bdafc1020f3fca8f1e2cd0,  // 0x70..0x7f
    128'h0645b3b80558e4f70ad3bc8c00abd890,  // 0x60..0x6f
    128'h849d8da75746155edab9edfd5048706c,  // 0x50..0x5f
    128'h92b6655dcc5ca4d41698688664f6f872,  // 0x40..0x4f
    128'h25d18b6d49a25b76b224d92866a12e08,  // 0x30..0x3f
    128'h4ec3fa420b954cee3d23c2a632947b54,  // 0x20..0x2f
    128'hcbe9dec444438e3487ff2f9b8239e37c,  // 0x10..0x1f
    128'hfbd7f3819ea340bf38a53630d56a0952   // 0x00..0x0f
  };

  localparam logic [2047:0] TBL = INV ? TBL_I : TBL_F;

  // two-level lookup: row = a[7:4] (16 entries of 128 bit), then byte = a[3:0]
  wire [127:0] row = TBL[{a[7:4], 7'b0000000} +: 128];
  assign y = row[{a[3:0], 3'b000} +: 8];

endmodule
