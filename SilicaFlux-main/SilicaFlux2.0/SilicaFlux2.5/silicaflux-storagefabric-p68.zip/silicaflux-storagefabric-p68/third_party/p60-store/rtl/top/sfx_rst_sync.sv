// SilicaFlux-STORE P60 :: sfx_rst_sync -- asynchronous assertion, synchronous release (2 flops); scan_mode bypass
// Classification: SYNTHESIZABLE
`default_nettype none
module sfx_rst_sync (
  input  wire logic clk,
  input  wire logic arst_n,
  input  wire logic scan_mode,              // DFT: bypass so that scan can control the reset
  output logic      rst_n
);
  logic [1:0] q;
  always_ff @(posedge clk or negedge arst_n) begin
    if (!arst_n) q <= 2'b00;
    else         q <= {q[0], 1'b1};
  end
  assign rst_n = scan_mode ? arst_n : q[1];
endmodule

`default_nettype wire
