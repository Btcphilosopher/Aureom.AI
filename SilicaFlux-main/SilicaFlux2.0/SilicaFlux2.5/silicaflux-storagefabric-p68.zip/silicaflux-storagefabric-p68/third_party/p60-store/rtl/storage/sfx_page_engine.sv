// =============================================================================
// SilicaFlux-STORE P60 :: sfx_page_engine -- page processing engine
//
//   One SFB2 master (DW = 32, one transaction outstanding, request held until
//   accepted) that pumps a buffer-SRAM "page slot" through
//     * the ECCCore (P54) page engine  silicaflux_storage_ecc  (BCH, t = 8,
//       512 B sector + 16 B FTL metadata, config N512T8U16), and
//     * the SecureStore XTS-AES core    sfx_aes_xts           (P60, new; P59 does
//       not exist in the repository),
//   under firmware control through one register page.
//
//   Slot layouts (little-endian bytes in 32-bit words):
//     S slot ("plain",  528 B): [0..511] page data  [512..527] 16-B FTL spare record
//     R slot ("raw",    544 B): [0..511] page data (cipher text when XTS is used)
//                               [512..543] spare area = RSVD/BBM(1) | UMETA(16) | CRC-16(2) | parity(13)
//
//   Operations (register SUBMIT, one outstanding; STATUS.BUSY / DONE):
//     1 BCH_ENC  S -> R   data + metadata -> BCH-encoded raw page image
//     2 BCH_DEC  R -> S   raw page image -> corrected data + metadata (+ status);
//                         the raw page is fed spare-area first, as ECCCore needs
//     3 XTS_ENC  S -> S   in place, data bytes [0..511], tweak = TWEAK_HI:TWEAK_LO
//     4 XTS_DEC  S -> S   in place
//
//   Order of use by firmware:  write:  XTS_ENC (optional) -> BCH_ENC -> NAND PROGRAM
//                              read :  NAND READ -> BCH_DEC -> XTS_DEC (optional, skipped for
//                                      an erased page) -> FTL CRC-32 / LPN check.
//   Failures never hang the engine: a fabric error is recorded (STATUS.ERR, code 4) and the
//   operation still runs to completion so that the ECC/XTS pipelines are left clean.
//
//   Register page (byte offsets, 32-bit registers; unknown offsets -> rb_err)
//     000 ID      "SFXP"               004 VERSION 0x0001_0000
//     008 CAPS0   {SPARE[15:0], DATA[15:0]}   00C CAPS1 {16'b0, T[7:0], UMETA[7:0]} (XTS key bits in [31:16])
//     010 CTRL    [0] W1: clear counters
//     014 STATUS  [0] BUSY [1] DONE [2] ERR [3] KEY_READY [11:8] LAST_OP [15:12] ERR_CODE
//                 ERR_CODE: 1 submit while busy (ignored)  2 bad opcode  3 XTS without key
//                           4 fabric error                  5 ECC framing error  6 XTS start refused
//     018 S_BASE  fabric address of the S slot     01C R_BASE  fabric address of the R slot
//     020 TWEAK_LO  024 TWEAK_HI   (XTS tweak = {64'b0, HI, LO})
//     028 SUBMIT  (WO) operation code
//     02C RESULT0 [2:0] sector status (0 clean 1 corrected 2 erased 3 uncorrectable 4 integrity)
//                 [15:8] bits corrected  [16] page all-erased  [17] page ok  [18] scrub hint
//                 [19] frame error  [20] sector CRC-16 ok  [31:24] bad-block marker byte
//     030 RESULT1 [15:0] total flips  [31:24] max flips
//     040 KEY_CTRL (WO) [0] commit (expand key schedules)  [1] zeroize
//     044 KEY_STATUS [0] key ready  [1] engine busy
//     080..0BC KEY_W0..KEY_W15 (WO; reads 0): XTS key words, key1 then key2 (never readable)
//     0C0 N_BCH_ENC 0C4 N_BCH_DEC 0C8 N_XTS 0CC N_ERR  (counters)
//     100..1FF ECCCore register window (ID "SECC", counters CW_CORRECTED, BITS_CORRECTED, ...)
//
// Classification: SYNTHESIZABLE (plain Verilog-2005-style SystemVerilog; no packages)
// =============================================================================
`include "sfecc_defs.svh"
`include "sfecc_cfg.svh"
`default_nettype none

/* verilator lint_off SYNCASYNCNET */   // XTS core uses a synchronous reset, the rest async (same net)
module sfx_page_engine #(
  parameter int XTS_KEYBITS = 256
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // ------------------------------------------------------------ firmware register page
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // ------------------------------------------------------------ SFB2 master (DW = 32)
  output logic             m_req_valid,
  input  wire logic        m_req_ready,
  output logic             m_req_write,
  output logic [31:0]      m_req_addr,
  output logic [31:0]      m_req_wdata,
  output logic [3:0]       m_req_wstrb,
  input  wire logic        m_rsp_valid,
  output logic             m_rsp_ready,
  input  wire logic [31:0] m_rsp_rdata,
  input  wire logic        m_rsp_error,
  // ------------------------------------------------------------ status / events
  output logic             busy,
  output logic             ev_ecc_corr,       // one-cycle pulses (RAS)
  output logic             ev_ecc_unc,
  output logic             ev_integrity,
  output logic             ev_scrub,
  output logic             ev_fault           // fabric error during an operation
);
  // ---------------------------------------------------------------- constants
  localparam int DATA_W  = 128;               // data words in a page (512 B)
  localparam int UM_W    = 4;                 // metadata words (16 B)
  localparam int SPARE_W = 8;                 // spare-area words (32 B)
  localparam int RAW_W   = DATA_W + SPARE_W;  // 136
  localparam int S_W     = DATA_W + UM_W;     // 132
  localparam int NKW     = 2 * XTS_KEYBITS / 32;   // key words (key1 + key2)

  localparam logic [3:0] OP_NOP = 4'd0, OP_BCH_ENC = 4'd1, OP_BCH_DEC = 4'd2, OP_XTS_ENC = 4'd3, OP_XTS_DEC = 4'd4;
  localparam logic [3:0] E_NONE = 4'd0, E_BUSY = 4'd1, E_OPCODE = 4'd2, E_NOKEY = 4'd3, E_FABRIC = 4'd4,
                         E_FRAME = 4'd5, E_XTSREF = 4'd6;

  // ---------------------------------------------------------------- registers
  logic [31:0] s_base_q, r_base_q, tweak_lo_q, tweak_hi_q;
  logic        act_q, done_q, err_q;
  logic [3:0]  op_q, last_op_q, errc_q;
  logic [31:0] n_enc_q, n_dec_q, n_xts_q, n_err_q;
  logic [31:0] res0_q, res1_q;

  wire reg_wr = rb_sel && rb_we;
  wire is_ecc_win = (rb_addr[11:8] == 4'h1);
  wire submit_wr = reg_wr && (rb_addr[11:0] == 12'h028);
  wire key_wr   = reg_wr && (rb_addr[11:6] == 6'b000010);                  // 0x080..0x0BF
  wire kctl_wr  = reg_wr && (rb_addr[11:0] == 12'h040);

  // ---------------------------------------------------------------- ECCCore instance
  logic        wr_pay_valid, wr_pay_ready, wr_pay_last, wr_um_valid, wr_um_ready;
  logic [7:0]  wr_pay_data, wr_um_data;
  logic        wr_raw_valid, wr_raw_ready;
  logic [7:0]  wr_raw_data;
  logic        rd_raw_valid, rd_raw_ready, rd_raw_last;
  logic [7:0]  rd_raw_data;
  logic        rd_pay_valid, rd_pay_ready, rd_um_valid, rd_um_ready;
  logic [7:0]  rd_pay_data, rd_um_data;
  logic        rd_sst_valid, rd_pst_valid;
  logic [2:0]  rd_sst_code;
  logic [7:0]  rd_sst_nerr;
  logic        rd_sst_crc_ok;
  logic [7:0]  rd_pst_max_flips, rd_pst_bbm;
  logic [15:0] rd_pst_tot_flips;
  logic        rd_pst_all_erased, rd_pst_ok, rd_pst_scrub, rd_pst_frame_err;
  logic [31:0] ecc_rdata;
  logic        ecc_irq, ecc_enc_busy, ecc_dec_busy;
  /* verilator lint_off UNUSEDSIGNAL */
  wire         unused_irq = ecc_irq;
  logic        wr_raw_last, rd_pay_last;
  logic [7:0]  rd_sst_aux, rd_sst_sector, rd_pst_n_corr, rd_pst_n_uncorr, rd_pst_n_integ, rd_pst_n_erased;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_storage_ecc #(`SFECC_PAGE_N512T8U16) u_ecc (
    .clk, .rst_n,
    .rb_sel(rb_sel && is_ecc_win), .rb_we, .rb_addr(rb_addr[7:0]), .rb_wdata, .rb_rdata(ecc_rdata),
    .wr_pay_valid, .wr_pay_ready, .wr_pay_data, .wr_pay_last,
    .wr_um_valid, .wr_um_ready, .wr_um_data,
    .wr_raw_valid, .wr_raw_ready, .wr_raw_data, .wr_raw_last,
    .rd_raw_valid, .rd_raw_ready, .rd_raw_data, .rd_raw_last,
    .rd_pay_valid, .rd_pay_ready, .rd_pay_data, .rd_pay_last,
    .rd_um_valid, .rd_um_ready, .rd_um_data,
    .rd_sst_valid, .rd_sst_ready(1'b1), .rd_sst_code, .rd_sst_nerr, .rd_sst_aux,
    .rd_sst_sector, .rd_sst_crc_ok,
    .rd_pst_valid, .rd_pst_ready(1'b1), .rd_pst_n_corr, .rd_pst_n_uncorr,
    .rd_pst_n_integ, .rd_pst_n_erased, .rd_pst_max_flips, .rd_pst_tot_flips,
    .rd_pst_all_erased, .rd_pst_bbm, .rd_pst_ok, .rd_pst_scrub, .rd_pst_frame_err,
    .ev_corrected(ev_ecc_corr), .ev_uncorr(ev_ecc_unc), .ev_integrity, .ev_scrub,
    .irq(ecc_irq), .enc_busy(ecc_enc_busy), .dec_busy(ecc_dec_busy)
  );

  // ---------------------------------------------------------------- XTS core
  logic        x_key_we, x_key_commit, x_key_zero, x_key_ready, x_start, x_dec, x_start_err;
  logic [4:0]  x_key_widx;
  logic [31:0] x_key_wdata;
  logic        x_in_valid, x_in_ready, x_out_valid, x_out_ready, x_busy;
  logic [127:0] x_in_data, x_out_data;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        x_out_last;
  /* verilator lint_on UNUSEDSIGNAL */
  sfx_aes_xts #(.KEYBITS(XTS_KEYBITS)) u_xts (
    .clk, .rst_n,
    .key_we(x_key_we), .key_widx(x_key_widx), .key_wdata(x_key_wdata), .key_commit(x_key_commit),
    .key_zeroize(x_key_zero), .key_ready(x_key_ready),
    .start(x_start), .decrypt(x_dec), .tweak({32'h0, 32'h0, tweak_hi_q, tweak_lo_q}), .nblocks(16'(DATA_W / 4)),
    .start_err(x_start_err),
    .in_valid(x_in_valid), .in_ready(x_in_ready), .in_data(x_in_data),
    .out_valid(x_out_valid), .out_ready(x_out_ready), .out_data(x_out_data), .out_last(x_out_last),
    .busy(x_busy)
  );

  assign x_key_we    = key_wr;
  assign x_key_widx  = {1'b0, rb_addr[5:2]};
  assign x_key_wdata = rb_wdata;
  assign x_key_commit = kctl_wr && rb_wdata[0];
  assign x_key_zero   = kctl_wr && rb_wdata[1];

  // ---------------------------------------------------------------- input byte FIFO (8 bytes, loaded 4 at a time)
  logic [7:0] ibf [0:7];
  logic [2:0] ibf_rp, ibf_wp;
  logic [3:0] ibf_cnt;
  logic [9:0] ib_cnt;                          // bytes popped in this operation
  wire        ibf_nonempty = (ibf_cnt != 4'd0);
  wire [7:0]  ibf_head = ibf[ibf_rp];
  logic       ibf_pop, ibf_push;
  logic [31:0] ibf_push_data;

  // ---------------------------------------------------------------- stream wiring (op dependent)
  wire is_enc = act_q && (op_q == OP_BCH_ENC);
  wire is_dec = act_q && (op_q == OP_BCH_DEC);
  wire is_xts = act_q && (op_q == OP_XTS_ENC || op_q == OP_XTS_DEC);

  assign wr_pay_valid = is_enc && ibf_nonempty && (ib_cnt < 10'(DATA_W * 4));
  assign wr_pay_data  = ibf_head;
  assign wr_pay_last  = (ib_cnt == 10'(DATA_W * 4 - 1));
  assign wr_um_valid  = is_enc && ibf_nonempty && (ib_cnt >= 10'(DATA_W * 4)) && (ib_cnt < 10'(S_W * 4));
  assign wr_um_data   = ibf_head;
  assign rd_raw_valid = is_dec && ibf_nonempty && (ib_cnt < 10'(RAW_W * 4));
  assign rd_raw_data  = ibf_head;
  assign rd_raw_last  = (ib_cnt == 10'(RAW_W * 4 - 1));
  assign ibf_pop = (wr_pay_valid && wr_pay_ready) || (wr_um_valid && wr_um_ready) || (rd_raw_valid && rd_raw_ready);

  // ---------------------------------------------------------------- output assemblers
  // pa: raw bytes (ENC) or corrected payload (DEC) -> words;  ua: corrected metadata (DEC) -> words
  logic [23:0] pa_acc, ua_acc;
  logic [1:0]  pa_bc, ua_bc;
  logic        pa_wv, ua_wv;
  logic [31:0] pa_word, ua_word;
  logic [7:0]  pa_wcnt;
  logic [2:0]  ua_wcnt;
  wire pa_ready = !(pa_wv && pa_bc == 2'd3);
  wire ua_ready = !(ua_wv && ua_bc == 2'd3);
  assign wr_raw_ready = is_enc && pa_ready;
  assign rd_pay_ready = is_dec && pa_ready;
  assign rd_um_ready  = is_dec && ua_ready;
  wire pa_in_v = (wr_raw_valid && wr_raw_ready) || (rd_pay_valid && rd_pay_ready);
  wire [7:0] pa_in_d = is_enc ? wr_raw_data : rd_pay_data;
  wire ua_in_v = rd_um_valid && rd_um_ready;

  // xts datapath registers
  logic [127:0] xi_q, xo_q;
  logic [2:0]   xi_cnt, xo_rem;
  logic [7:0]   xo_wcnt;
  assign x_in_valid  = is_xts && (xi_cnt == 3'd4);
  assign x_in_data   = xi_q;
  assign x_out_ready = is_xts && (xo_rem == 3'd0);
  wire xo_wv = (xo_rem != 3'd0);

  // ---------------------------------------------------------------- master engine
  typedef enum logic [1:0] { M_IDLE, M_REQ, M_RSP } m_e;
  m_e          m_st;
  logic        m_is_wr;
  logic [1:0]  m_src;                          // 0 pa, 1 ua, 2 xo (write source)
  logic [31:0] m_addr, m_wdata;
  logic [8:0]  rd_idx;
  logic [8:0]  rd_total;

  wire [31:0] rd_addr_enc = s_base_q + {21'b0, rd_idx, 2'b00};
  wire [31:0] rd_addr_dec = (rd_idx < 9'(SPARE_W)) ? (r_base_q + 32'(DATA_W * 4) + {21'b0, rd_idx, 2'b00})
                                                   : (r_base_q + {21'b0, rd_idx - 9'(SPARE_W), 2'b00});
  wire [31:0] rd_addr = is_dec ? rd_addr_dec : rd_addr_enc;
  wire need_rd = act_q && (rd_idx < rd_total) &&
                 ((is_xts) ? (xi_cnt != 3'd4) : (ibf_cnt <= 4'd4));

  wire [31:0] pa_addr = (is_enc ? r_base_q : s_base_q) + {22'b0, pa_wcnt, 2'b00};
  wire [31:0] ua_addr = s_base_q + 32'(DATA_W * 4) + {27'b0, ua_wcnt, 2'b00};
  wire [31:0] xo_addr = s_base_q + {22'b0, xo_wcnt, 2'b00};
  logic [31:0] xo_word;
  always_comb begin
    case (xo_rem)
      3'd4:    xo_word = xo_q[31:0];
      3'd3:    xo_word = xo_q[63:32];
      3'd2:    xo_word = xo_q[95:64];
      default: xo_word = xo_q[127:96];
    endcase
  end

  assign m_req_valid = (m_st == M_REQ);
  assign m_req_write = m_is_wr;
  assign m_req_addr  = m_addr;
  assign m_req_wdata = m_wdata;
  assign m_req_wstrb = 4'hF;
  assign m_rsp_ready = 1'b1;

  assign busy = act_q;

  // ---------------------------------------------------------------- completion detect
  logic pst_seen_q;
  wire all_written = is_enc ? (pa_wcnt == 8'(RAW_W)) :
                     is_dec ? (pa_wcnt == 8'(DATA_W) && ua_wcnt == 3'(UM_W) && pst_seen_q) :
                     is_xts ? (xo_wcnt == 8'(DATA_W)) : 1'b0;
  wire finish = act_q && all_written && (m_st == M_IDLE) && !x_busy && !ecc_enc_busy && !ecc_dec_busy;

  // ---------------------------------------------------------------- sequential logic
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s_base_q <= '0; r_base_q <= '0; tweak_lo_q <= '0; tweak_hi_q <= '0;
      act_q <= 1'b0; done_q <= 1'b0; err_q <= 1'b0; op_q <= OP_NOP; last_op_q <= OP_NOP; errc_q <= E_NONE;
      n_enc_q <= '0; n_dec_q <= '0; n_xts_q <= '0; n_err_q <= '0; res0_q <= '0; res1_q <= '0;
      ibf_rp <= '0; ibf_wp <= '0; ibf_cnt <= '0; ib_cnt <= '0;
      pa_acc <= '0; ua_acc <= '0; pa_bc <= '0; ua_bc <= '0; pa_wv <= 1'b0; ua_wv <= 1'b0; pa_word <= '0; ua_word <= '0;
      pa_wcnt <= '0; ua_wcnt <= '0;
      xi_q <= '0; xo_q <= '0; xi_cnt <= '0; xo_rem <= '0; xo_wcnt <= '0;
      x_start <= 1'b0; x_dec <= 1'b0;
      m_st <= M_IDLE; m_is_wr <= 1'b0; m_src <= '0; m_addr <= '0; m_wdata <= '0; rd_idx <= '0; rd_total <= '0;
      pst_seen_q <= 1'b0;
      for (int i = 0; i < 8; i++) ibf[i] <= '0;
    end else begin
      x_start <= 1'b0;
      // ------------------------------------------------ register writes
      if (reg_wr) begin
        case (rb_addr[11:0])
          12'h010: if (rb_wdata[0]) begin n_enc_q <= '0; n_dec_q <= '0; n_xts_q <= '0; n_err_q <= '0; end
          12'h018: if (!act_q) s_base_q <= rb_wdata;
          12'h01C: if (!act_q) r_base_q <= rb_wdata;
          12'h020: if (!act_q) tweak_lo_q <= rb_wdata;
          12'h024: if (!act_q) tweak_hi_q <= rb_wdata;
          default: ;
        endcase
      end

      // ------------------------------------------------ operation start
      if (submit_wr) begin
        if (act_q) begin
          err_q <= 1'b1; errc_q <= E_BUSY; n_err_q <= n_err_q + 32'd1;
        end else begin
          last_op_q <= rb_wdata[3:0];
          done_q <= 1'b0; err_q <= 1'b0; errc_q <= E_NONE;
          if (rb_wdata[3:0] < OP_BCH_ENC || rb_wdata[3:0] > OP_XTS_DEC) begin
            err_q <= 1'b1; errc_q <= E_OPCODE; done_q <= 1'b1; n_err_q <= n_err_q + 32'd1;
          end else if ((rb_wdata[3:0] == OP_XTS_ENC || rb_wdata[3:0] == OP_XTS_DEC) && !x_key_ready) begin
            err_q <= 1'b1; errc_q <= E_NOKEY; done_q <= 1'b1; n_err_q <= n_err_q + 32'd1;
          end else begin
            op_q <= rb_wdata[3:0];
            act_q <= 1'b1;
            ibf_rp <= '0; ibf_wp <= '0; ibf_cnt <= '0; ib_cnt <= '0;
            pa_bc <= '0; ua_bc <= '0; pa_wv <= 1'b0; ua_wv <= 1'b0; pa_wcnt <= '0; ua_wcnt <= '0;
            xi_cnt <= '0; xo_rem <= '0; xo_wcnt <= '0;
            rd_idx <= '0; pst_seen_q <= 1'b0;
            res0_q <= '0; res1_q <= '0;
            rd_total <= (rb_wdata[3:0] == OP_BCH_ENC) ? 9'(S_W) :
                        (rb_wdata[3:0] == OP_BCH_DEC) ? 9'(RAW_W) : 9'(DATA_W);
            if (rb_wdata[3:0] == OP_XTS_ENC || rb_wdata[3:0] == OP_XTS_DEC) begin
              x_start <= 1'b1; x_dec <= (rb_wdata[3:0] == OP_XTS_DEC);
            end
          end
        end
      end

      // ------------------------------------------------ XTS start refusal
      if (x_start_err && act_q && is_xts) begin
        err_q <= 1'b1; errc_q <= E_XTSREF;
      end

      // ------------------------------------------------ input FIFO push / pop
      if (ibf_push) begin
        ibf[ibf_wp]        <= ibf_push_data[7:0];
        ibf[ibf_wp + 3'd1] <= ibf_push_data[15:8];
        ibf[ibf_wp + 3'd2] <= ibf_push_data[23:16];
        ibf[ibf_wp + 3'd3] <= ibf_push_data[31:24];
        ibf_wp <= ibf_wp + 3'd4;
      end
      if (ibf_pop) begin ibf_rp <= ibf_rp + 3'd1; ib_cnt <= ib_cnt + 10'd1; end
      ibf_cnt <= ibf_cnt + (ibf_push ? 4'd4 : 4'd0) - (ibf_pop ? 4'd1 : 4'd0);

      // ------------------------------------------------ output assemblers
      if (pa_in_v) begin
        if (pa_bc == 2'd3) begin
          pa_word <= {pa_in_d, pa_acc}; pa_wv <= 1'b1; pa_bc <= 2'd0;
        end else begin
          case (pa_bc)
            2'd0: pa_acc[7:0]   <= pa_in_d;
            2'd1: pa_acc[15:8]  <= pa_in_d;
            default: pa_acc[23:16] <= pa_in_d;
          endcase
          pa_bc <= pa_bc + 2'd1;
        end
      end
      if (ua_in_v) begin
        if (ua_bc == 2'd3) begin
          ua_word <= {rd_um_data, ua_acc}; ua_wv <= 1'b1; ua_bc <= 2'd0;
        end else begin
          case (ua_bc)
            2'd0: ua_acc[7:0]   <= rd_um_data;
            2'd1: ua_acc[15:8]  <= rd_um_data;
            default: ua_acc[23:16] <= rd_um_data;
          endcase
          ua_bc <= ua_bc + 2'd1;
        end
      end

      // ------------------------------------------------ ECC status capture
      if (rd_sst_valid && is_dec) begin
        res0_q[2:0]  <= rd_sst_code;
        res0_q[15:8] <= rd_sst_nerr;
        res0_q[20]   <= rd_sst_crc_ok;
      end
      if (rd_pst_valid && is_dec) begin
        res0_q[16] <= rd_pst_all_erased;
        res0_q[17] <= rd_pst_ok;
        res0_q[18] <= rd_pst_scrub;
        res0_q[19] <= rd_pst_frame_err;
        res0_q[31:24] <= rd_pst_bbm;
        res1_q <= {rd_pst_max_flips, 8'h00, rd_pst_tot_flips};
        pst_seen_q <= 1'b1;
        if (rd_pst_frame_err) begin err_q <= 1'b1; errc_q <= E_FRAME; end
      end

      // ------------------------------------------------ XTS data path
      if (is_xts) begin
        if (x_in_valid && x_in_ready) xi_cnt <= 3'd0;
        if (x_out_valid && x_out_ready) begin xo_q <= x_out_data; xo_rem <= 3'd4; end
      end

      // ------------------------------------------------ master FSM
      case (m_st)
        M_IDLE: begin
          if (pa_wv || ua_wv || xo_wv) begin
            m_is_wr <= 1'b1;
            if (pa_wv) begin m_src <= 2'd0; m_addr <= pa_addr; m_wdata <= pa_word; end
            else if (ua_wv) begin m_src <= 2'd1; m_addr <= ua_addr; m_wdata <= ua_word; end
            else begin m_src <= 2'd2; m_addr <= xo_addr; m_wdata <= xo_word; end
            m_st <= M_REQ;
          end else if (need_rd) begin
            m_is_wr <= 1'b0; m_addr <= rd_addr; m_st <= M_REQ;
          end
        end
        M_REQ: if (m_req_ready) m_st <= M_RSP;        // a presented request is never withdrawn (SFB2)
        M_RSP: if (m_rsp_valid) begin
          m_st <= M_IDLE;
          if (m_rsp_error) begin
            err_q <= 1'b1; errc_q <= E_FABRIC; n_err_q <= n_err_q + 32'd1;
          end
          if (m_is_wr) begin
            case (m_src)
              2'd0: begin pa_wv <= 1'b0; pa_wcnt <= pa_wcnt + 8'd1; end
              2'd1: begin ua_wv <= 1'b0; ua_wcnt <= ua_wcnt + 3'd1; end
              default: begin xo_rem <= xo_rem - 3'd1; xo_wcnt <= xo_wcnt + 8'd1; end
            endcase
          end else begin
            rd_idx <= rd_idx + 9'd1;
            if (is_xts) begin
              case (xi_cnt)
                3'd0: xi_q[31:0]   <= m_rsp_rdata;
                3'd1: xi_q[63:32]  <= m_rsp_rdata;
                3'd2: xi_q[95:64]  <= m_rsp_rdata;
                default: xi_q[127:96] <= m_rsp_rdata;
              endcase
              xi_cnt <= xi_cnt + 3'd1;
            end
          end
        end
        default: m_st <= M_IDLE;
      endcase

      // ------------------------------------------------ completion
      if (finish) begin
        act_q <= 1'b0; done_q <= 1'b1;
        case (op_q)
          OP_BCH_ENC: n_enc_q <= n_enc_q + 32'd1;
          OP_BCH_DEC: n_dec_q <= n_dec_q + 32'd1;
          default:    n_xts_q <= n_xts_q + 32'd1;
        endcase
        if (err_q) n_err_q <= n_err_q + 32'd1;
      end
    end
  end

  // the input FIFO is filled by the master response of a read in ENC/DEC mode
  assign ibf_push      = (m_st == M_RSP) && m_rsp_valid && !m_is_wr && !is_xts;
  assign ibf_push_data = m_rsp_rdata;

  assign ev_fault = (m_st == M_RSP) && m_rsp_valid && m_rsp_error;

  // ---------------------------------------------------------------- register read
  always_comb begin
    rb_rdata = 32'h0;
    rb_err   = 1'b0;
    if (is_ecc_win) begin
      rb_rdata = ecc_rdata;
    end else begin
      case (rb_addr[11:0])
        12'h000: rb_rdata = 32'h5346_5850;                               // "SFXP"
        12'h004: rb_rdata = 32'h0001_0000;
        12'h008: rb_rdata = {16'(SPARE_W * 4), 16'(DATA_W * 4)};
        12'h00C: rb_rdata = {16'(XTS_KEYBITS), 8'd8, 8'd16};
        12'h010: rb_rdata = 32'h0;
        12'h014: rb_rdata = {16'h0, errc_q, last_op_q, 4'h0, x_key_ready, err_q, done_q, act_q};
        12'h018: rb_rdata = s_base_q;
        12'h01C: rb_rdata = r_base_q;
        12'h020: rb_rdata = tweak_lo_q;
        12'h024: rb_rdata = tweak_hi_q;
        12'h028: rb_rdata = 32'h0;
        12'h02C: rb_rdata = res0_q;
        12'h030: rb_rdata = res1_q;
        12'h040: rb_rdata = 32'h0;
        12'h044: rb_rdata = {30'h0, x_busy, x_key_ready};
        12'h0C0: rb_rdata = n_enc_q;
        12'h0C4: rb_rdata = n_dec_q;
        12'h0C8: rb_rdata = n_xts_q;
        12'h0CC: rb_rdata = n_err_q;
        default: begin
          if (rb_addr[11:6] == 6'b000010 && (NKW >= 16 || (32'(rb_addr[5:2]) < 32'(NKW)))) rb_rdata = 32'h0;   // key window: write-only
          else rb_err = 1'b1;
        end
      endcase
      if (rb_we && (rb_addr[11:0] == 12'h000 || rb_addr[11:0] == 12'h004 || rb_addr[11:0] == 12'h008 ||
                    rb_addr[11:0] == 12'h00C || rb_addr[11:0] == 12'h014 || rb_addr[11:0] == 12'h02C ||
                    rb_addr[11:0] == 12'h030 || rb_addr[11:0] == 12'h044 || rb_addr[11:0] == 12'h0C0 ||
                    rb_addr[11:0] == 12'h0C4 || rb_addr[11:0] == 12'h0C8 || rb_addr[11:0] == 12'h0CC))
        rb_err = 1'b1;
    end
  end
endmodule

/* verilator lint_on SYNCASYNCNET */
`default_nettype wire
