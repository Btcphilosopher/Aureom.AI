// -----------------------------------------------------------------------------
// sfx_aes_keyexp -- iterative AES key-schedule generator (FIPS-197 5.2),
// one 32-bit schedule word per clock.
//
// Project : SilicaFlux-STORE P60 (SecureStore)
//
// A `start` pulse (while idle) loads the raw key (key_in, word k at
// key_in[32*k +: 32], key byte i = key_in[8*i +: 8]) into a Nk-word sliding window.
// In the following cycles busy=1 and the engine emits the schedule words
// w[Nk] .. w[4*(Nr+1)-1], one per clock, on wr_en/wr_idx/wr_data (the caller
// stores them; words w[0..Nk-1] are the key itself).  After the last word
// `done` pulses for one cycle (cycle after the last wr_en) and the window is
// cleared, so no key copy remains inside the engine once it is idle.
//   words to generate = 4*(Nr+1)-Nk = 40 (KEYBITS=128) / 52 (KEYBITS=256)
//   start (cycle 0) -> wr_en cycles 1..W -> done in cycle W+1
// clr / !rst_n clear everything (synchronous).
// -----------------------------------------------------------------------------
module sfx_aes_keyexp #(
  parameter int KEYBITS = 128
) (
  input  logic               clk,
  input  logic               rst_n,
  input  logic               clr,
  input  logic               start,
  input  logic [KEYBITS-1:0] key_in,
  output logic               done,
  output logic               wr_en,
  output logic [5:0]         wr_idx,
  output logic [31:0]        wr_data
);

  localparam int NK = KEYBITS/32;
  localparam int NW = 4*(NK+7);                 // total schedule words
  localparam logic [5:0] LASTW = 6'(NW - 1);
  localparam logic [3:0] NKM1  = 4'(NK - 1);

  logic [KEYBITS-1:0] win_q;                    // win_q[32*k +: 32] = w[i-Nk+k]
  logic [5:0]         idx_q;                    // index i of the word generated this cycle
  logic [3:0]         sub_q;                    // i mod Nk
  logic [7:0]         rcon_q;
  logic               busy_q;
  logic               done_q;

  wire [31:0] prev    = win_q[KEYBITS-32 +: 32];            // w[i-1]
  wire [31:0] rotw    = {prev[7:0], prev[31:8]};            // RotWord
  wire        is_rot  = (sub_q == 4'd0);
  wire        is_sub  = is_rot || ((NK == 8) && (sub_q == 4'd4));
  wire [31:0] sb_in   = is_rot ? rotw : prev;
  logic [31:0] sb_out;

  for (genvar b = 0; b < 4; b++) begin : g_sbox
    sfx_aes_sbox #(.INV(1'b0)) u_sb (.a(sb_in[8*b +: 8]), .y(sb_out[8*b +: 8]));
  end

  wire [31:0] temp = is_sub ? (sb_out ^ (is_rot ? {24'h0, rcon_q} : 32'h0)) : prev;
  wire [31:0] neww = win_q[31:0] ^ temp;                    // w[i] = w[i-Nk] ^ temp

  always_ff @(posedge clk) begin
    if (!rst_n || clr) begin
      win_q  <= '0;
      idx_q  <= '0;
      sub_q  <= '0;
      rcon_q <= '0;
      busy_q <= 1'b0;
      done_q <= 1'b0;
    end else begin
      done_q <= 1'b0;
      if (start && !busy_q) begin
        win_q  <= key_in;
        idx_q  <= 6'(NK);
        sub_q  <= 4'd0;
        rcon_q <= 8'h01;
        busy_q <= 1'b1;
      end else if (busy_q) begin
        win_q  <= {neww, win_q[KEYBITS-1:32]};
        idx_q  <= idx_q + 6'd1;
        sub_q  <= (sub_q == NKM1) ? 4'd0 : (sub_q + 4'd1);
        if (is_rot) rcon_q <= {rcon_q[6:0], 1'b0} ^ (rcon_q[7] ? 8'h1b : 8'h00);
        if (idx_q == LASTW) begin
          busy_q <= 1'b0;
          done_q <= 1'b1;
          win_q  <= '0;
          rcon_q <= '0;
        end
      end
    end
  end

  assign done    = done_q;
  assign wr_en   = busy_q;
  assign wr_idx  = idx_q;
  assign wr_data = neww;

endmodule
