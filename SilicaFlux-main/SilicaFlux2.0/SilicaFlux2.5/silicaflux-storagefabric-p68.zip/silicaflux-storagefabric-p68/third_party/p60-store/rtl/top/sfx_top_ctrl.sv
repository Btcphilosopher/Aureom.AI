// =============================================================================
// SilicaFlux-STORE P60 :: sfx_top_ctrl -- chip-level control, interrupt controller, performance counters, DFT access
//
// Local window of the host BAR (0xC000_0000 + offset):
//   0x0000 ID "SFST" 0x53465354     0x0004 VERSION 0x0060_0100      0x0008 CONFIG {NCH[7:0], CDW[15:8], DW[23:16], CFG[31:24]}
//   0x0010 RESET_CAUSE (W1C)  [0] power-on [1] host reset request [2] power-fail event
//   0x0014 IRQ_STATUS  (W1C, sticky)   0x0018 IRQ_MASK   0x001C IRQ_RAW (live levels)
//          sources: [0] host_irq [1] mgmt_irq [2] ras_fatal [3] power fail [4] TestCore irq [5] test_done [6] cmdproc_ready fell
//   0x0020 CTRL [0] W1: clear performance counters
//   0x0040 CYCLES_LO 0x0044 CYCLES_HI 0x0048 HM_RD_BEATS 0x004C HM_WR_BEATS 0x0050 NAND_BUSY_CYCLES 0x0054 NAND_OPS
//          0x0058 BAR_RD 0x005C BAR_WR 0x0060 PF_EVENTS 0x0064 PF_CYCLES        (all observed on pins: independent of firmware)
//   0x0080 DFT_STATUS [0] hw_dbg_en [1] hw_test_en [2] scan_mode [3] mbist_busy [4] jtag_mode [5] diag_mode [8+] tc mode[2:0]
//   0x1000..0x1FFF  TestCore (P07) register file: JTAG-accessible diagnostics, test-mode controller, MBIST (see TestCore docs)
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sfx_top_ctrl #(
  parameter int NCH = 1,
  parameter int CDW = 8,
  parameter int DW  = 32,
  parameter int CFG = 1                     // 1 = SILICAFLUX_STORE_MIN
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // local window request/done port (from sfx_hb_split)
  input  wire logic        l_req,
  input  wire logic        l_we,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [15:0] l_addr,                       // bits [15:13] unused: the local window is 8 KiB
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [31:0] l_wdata,
  output logic             l_done,
  output logic [31:0]      l_rdata,
  output logic             l_err,
  // observed chip signals
  input  wire logic        host_irq,
  input  wire logic        mgmt_irq,
  input  wire logic        ras_fatal,
  input  wire logic        cmdproc_ready,
  input  wire logic        pf_event,
  input  wire logic        pwr_fail_n,
  input  wire logic        host_rst_req,
  input  wire logic        test_done,
  input  wire logic        hm_req_valid,
  input  wire logic        hm_req_ready,
  input  wire logic        hm_req_write,
  input  wire logic        bar_req_valid,
  input  wire logic        bar_req_ready,
  input  wire logic        bar_req_write,
  input  wire logic        nand_rb_n,
  // DFT straps / status
  input  wire logic        hw_dbg_en,
  input  wire logic        hw_test_en,
  input  wire logic        scan_mode,
  input  wire logic        mbist_busy,
  input  wire logic        jtag_mode,
  input  wire logic        diag_mode,
  input  wire logic [2:0]  tc_mode,
  input  wire logic        tc_irq,
  // TestCore register port
  output logic             tc_req,
  output logic             tc_we,
  output logic [11:0]      tc_addr,
  output logic [31:0]      tc_wdata,
  input  wire logic        tc_gnt,
  input  wire logic [31:0] tc_rdata,
  input  wire logic        tc_err,
  // interrupt out
  output logic             irq_o
);
  // ---------------------------------------------------------------- counters
  logic [63:0] cyc_q;
  logic [31:0] hm_rd_q, hm_wr_q, nbusy_q, nops_q, bar_rd_q, bar_wr_q, pfe_q, pfc_q;
  logic        rb_prev;
  logic        clr_pc;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cyc_q <= '0; hm_rd_q <= '0; hm_wr_q <= '0; nbusy_q <= '0; nops_q <= '0; bar_rd_q <= '0; bar_wr_q <= '0; pfe_q <= '0; pfc_q <= '0;
      rb_prev <= 1'b1;
    end else begin
      rb_prev <= nand_rb_n;
      if (clr_pc) begin
        cyc_q <= '0; hm_rd_q <= '0; hm_wr_q <= '0; nbusy_q <= '0; nops_q <= '0; bar_rd_q <= '0; bar_wr_q <= '0; pfe_q <= '0; pfc_q <= '0;
      end else begin
        cyc_q <= cyc_q + 64'd1;
        if (hm_req_valid && hm_req_ready && !hm_req_write) hm_rd_q <= hm_rd_q + 32'd1;
        if (hm_req_valid && hm_req_ready &&  hm_req_write) hm_wr_q <= hm_wr_q + 32'd1;
        if (!nand_rb_n) nbusy_q <= nbusy_q + 32'd1;
        if (rb_prev && !nand_rb_n) nops_q <= nops_q + 32'd1;
        if (bar_req_valid && bar_req_ready && !bar_req_write) bar_rd_q <= bar_rd_q + 32'd1;
        if (bar_req_valid && bar_req_ready &&  bar_req_write) bar_wr_q <= bar_wr_q + 32'd1;
        if (pf_event) pfe_q <= pfe_q + 32'd1;
        if (!pwr_fail_n) pfc_q <= pfc_q + 32'd1;
      end
    end
  end

  // ---------------------------------------------------------------- interrupt controller + reset cause
  logic [6:0] st_q, mask_q;
  logic [2:0] cause_q;
  logic       cmd_prev, done_prev;
  wire [6:0] raw = {~cmdproc_ready & cmd_prev, test_done & ~done_prev, tc_irq, ~pwr_fail_n, ras_fatal, mgmt_irq, host_irq};
  logic       win_wr, win_sel_top, tc_active;
  logic [31:0] top_rd;
  logic        top_err;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= '0; mask_q <= '0; cause_q <= 3'b001; cmd_prev <= 1'b0; done_prev <= 1'b0;
    end else begin
      cmd_prev <= cmdproc_ready; done_prev <= test_done;
      st_q <= st_q | raw;                                         // sticky; level sources re-set while they stay asserted
      if (host_rst_req) cause_q[1] <= 1'b1;
      if (pf_event) cause_q[2] <= 1'b1;
      if (win_wr && win_sel_top) begin
        case (l_addr[11:2])
          10'h004: cause_q <= (cause_q & ~l_wdata[2:0]) | (host_rst_req ? 3'b010 : 3'b0) | (pf_event ? 3'b100 : 3'b0);
          10'h005: st_q <= (st_q & ~l_wdata[6:0]) | raw;
          10'h006: mask_q <= l_wdata[6:0];
          default: ;
        endcase
      end
    end
  end
  assign irq_o = |(st_q & mask_q);
  assign clr_pc = win_wr && win_sel_top && (l_addr[11:2] == 10'h008) && l_wdata[0];

  // ---------------------------------------------------------------- local window decode
  assign win_sel_top = !l_addr[12];
  assign win_wr = l_req && l_we && !tc_active;
  assign tc_active = l_req && l_addr[12];
  assign tc_req   = tc_active;
  assign tc_we    = l_we;
  assign tc_addr  = l_addr[11:0];
  assign tc_wdata = l_wdata;

  always_comb begin
    top_rd = 32'h0; top_err = 1'b0;
    case (l_addr[11:2])
      10'h000: top_rd = 32'h5346_5354;
      10'h001: top_rd = 32'h0060_0100;
      10'h002: top_rd = {8'(CFG), 8'(DW), 8'(CDW), 8'(NCH)};
      10'h004: top_rd = {29'h0, cause_q};
      10'h005: top_rd = {25'h0, st_q};
      10'h006: top_rd = {25'h0, mask_q};
      10'h007: top_rd = {25'h0, raw};
      10'h008: top_rd = 32'h0;
      10'h010: top_rd = cyc_q[31:0];
      10'h011: top_rd = cyc_q[63:32];
      10'h012: top_rd = hm_rd_q;
      10'h013: top_rd = hm_wr_q;
      10'h014: top_rd = nbusy_q;
      10'h015: top_rd = nops_q;
      10'h016: top_rd = bar_rd_q;
      10'h017: top_rd = bar_wr_q;
      10'h018: top_rd = pfe_q;
      10'h019: top_rd = pfc_q;
      10'h020: top_rd = {21'h0, tc_mode, 2'b00, diag_mode, jtag_mode, mbist_busy, scan_mode, hw_test_en, hw_dbg_en};
      default: top_err = 1'b1;
    endcase
    if (l_we && (l_addr[11:2] != 10'h004 && l_addr[11:2] != 10'h005 && l_addr[11:2] != 10'h006 && l_addr[11:2] != 10'h008)) top_err = 1'b1;
  end
  // the local port answers in the same cycle for the top window; the TestCore window waits for its grant
  assign l_done  = tc_active ? tc_gnt : l_req;
  assign l_rdata = tc_active ? tc_rdata : top_rd;
  assign l_err   = tc_active ? tc_err : top_err;
endmodule
`default_nettype wire
