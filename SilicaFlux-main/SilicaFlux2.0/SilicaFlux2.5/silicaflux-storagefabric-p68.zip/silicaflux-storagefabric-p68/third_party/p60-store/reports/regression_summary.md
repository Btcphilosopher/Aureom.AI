# Full-chip regression summary

Verilated RTL (silicaflux_storage_top) + real firmware on the RTL CPU + P52 NAND twin. Cycles are simulation cycles.

Binaries: testbench `build/tb_fin/v/Vtb` (sha256 57f211e3442a…), firmware `p60_fw.hex` (sha256 feed76323e64…), `p60_fw_xts.hex` (sha256 ecea8c9efb76…). Run: 2026-11-13 05:55 UTC.

| run | scenario | seed | checks | failures | cycles | wall s | verdict |
|---|---|---|---|---|---|---|---|
| smoke | smoke | +seed=1 | 32 | 0 | 5095789 | 31 | **PASS** |
| invalid | invalid | +seed=1 | 48 | 0 | 5183984 | 32 | **PASS** |
| top | top | +seed=1 | 61 | 0 | 5392157 | 32 | **PASS** |
| ecc | ecc | +seed=1 | 77 | 0 | 6404995 | 47 | **PASS** |
| concurrency | concurrency | +seed=1 | 94 | 0 | 6869849 | 51 | **PASS** |
| backpressure | backpressure | +seed=1 | 95 | 0 | 6706473 | 50 | **PASS** |
| ctrlreset | ctrlreset | +seed=1 | 800 | 0 | 10954285 | 104 | **PASS** |
| plp | plp | +seed=1 | 800 | 0 | 16096250 | 202 | **PASS** |
| integrity | integrity | +seed=1 | 2278 | 0 | 92787257 | 1002 | **PASS** |
| random_s1 | random | +seed=1 | 2066 | 0 | 54368242 | 531 | **PASS** |
| random_s2 | random | +seed=2 | 2032 | 0 | 61138519 | 554 | **PASS** |
| random_stress | random | +seed=3 | 1762 | 0 | 44697495 | 673 | **PASS** |
| badblock | badblock | +seed=1 | 3173 | 0 | 134237892 | 1794 | **PASS** |
| security_xts | security | +seed=1 | 960 | 0 | 24129975 | 422 | **PASS** |
| noformat | noformat | +seed=1 | 2517 | 0 | 42121557 | 698 | **PASS** |
| crash_s1 | crash | +seed=1 | 1896 | 0 | 100444852 | 1166 | **PASS** |
| crash_s2 | crash | +seed=2 | 1894 | 0 | 105414973 | 957 | **PASS** |
| crash_s3 | crash | +seed=3 | 1884 | 0 | 108488670 | 785 | **PASS** |
| crash_xts_s4 | crash | +seed=4 | 1004 | 0 | 59378082 | 480 | **PASS** |

19/19 runs PASS; 23473 checks in total.

* smoke: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* invalid: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* top: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* ecc: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* concurrency: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* backpressure: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* ctrlreset: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 1; acknowledged data lost 0
* plp: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* integrity: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* random_s1: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* random_s2: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* random_stress: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* badblock: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* security_xts: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* noformat: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* crash_s1: crashes 8 (in-flight commands at cut: 12 total; distribution 0..7: 0 5 2 1 0 0 0 0); unacknowledged cmds that had taken effect 9; acknowledged data lost 0
* crash_s2: crashes 8 (in-flight commands at cut: 10 total; distribution 0..7: 0 6 2 0 0 0 0 0); unacknowledged cmds that had taken effect 8; acknowledged data lost 0
* crash_s3: crashes 8 (in-flight commands at cut: 14 total; distribution 0..7: 0 4 2 2 0 0 0 0); unacknowledged cmds that had taken effect 6; acknowledged data lost 0
* crash_xts_s4: crashes 4 (in-flight commands at cut: 10 total; distribution 0..7: 0 0 2 2 0 0 0 0); unacknowledged cmds that had taken effect 4; acknowledged data lost 0
