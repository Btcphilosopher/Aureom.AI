# 12 — Release readiness report (SILICAFLUX_STORE_MIN)

**Verdict.** `SILICAFLUX_STORE_MIN` is a **simulation release candidate**: a programmable storage controller (RISC-V ControlCore + P51 StorageCore subsystem + BCH ECC page engine + XTS-AES + FTL firmware) that, in RTL simulation with the real firmware against a NAND digital twin, passes its deterministic and random regressions, returns correct data after write/overwrite/TRIM, **recovered every acknowledged write in every injected power-loss campaign run**, corrects up to 8 raw bit errors per 512 B and reports larger error counts explicitly, and never acknowledged a write early in the sampled space.
It is **not** FPGA-, silicon- or product-ready: no hardware, no real NAND, no signoff evidence exists. `SILICAFLUX_STORE_HPC` is **not delivered** beyond parameterisation. Of the nine predecessor projects, 51, 52, 54, 56 and the P58 "1.1" FTL library are integrated (plus the P07 TestCore block); P59 did not exist and was created; P53, P55, P57 and the P58 RTL completion gate are not integrated (reasons in `00_AUDIT_P51_P59.md`, `11_KNOWN_LIMITATIONS.md`).

## 1. Brief's minimum release criteria

| # | Criterion | Status | Evidence |
|---|---|---|---|
| 1 | RTL elaboration | **MET** | Verilator `--lint-only -Wall` of `silicaflux_storage_top`: 0 errors; 8 style/reset-net warnings, **all in vendored ControlCore files, none in P60-authored RTL** (`reports/logs/lint_full.txt`); every regression run elaborates the same RTL |
| 2 | Synthesis | **MET (generic cells + FPGA/ASIC-library estimates, not signoff)** | Yosys whole-top synthesis (145 075 generic cells, ≈ 14.9 k flops, 29 memories) with `check -assert` clean and exactly one latch — the intentional clock-gate enable latch in ControlCore (`reports/logs/synth_whole_top.txt`); 7-series and ECP5 estimates (`reports/fpga_resource_estimate.md`); page-engine block through OpenROAD up to global routing — detailed routing not completed (`09_PHYSICAL_DESIGN.md`) |
| 3 | Deterministic regression passes | **MET** | `reports/regression_summary.md`: 19/19 runs pass, 23 473 checks, 0 failures |
| 4 | Random regression passes | **MET** | three seeded `random` runs (one with the harsh NAND profile), the `integrity` run and the `badblock` run (which embeds it); seeds are fixed so every run is reproducible |
| 5 | Correct data after write / overwrite / TRIM | **MET** | per-LBA oracle in `integrity`, `random`, `smoke`, `badblock`, `crash` |
| 6 | **Recovery of acknowledged durable data after injected crashes** | **MET in the sampled space** | `crash` ×3 seeds (8 cuts each, nested cuts during recovery) + XTS crash run: 28 power cuts in 4 campaigns, 46 commands in flight at the cuts, 17 further cuts *during* recovery, 27 unacknowledged commands that had taken effect (allowed), **0 acknowledged writes lost**; **acknowledged data lost: 0**. Statistical, not exhaustive (`11_KNOWN_LIMITATIONS.md` §C) |
| 7 | Correctable errors handled | **MET** | `ecc`: k = 0…8 injected raw bit errors per page corrected exactly, corrected-bit counter checked |
| 8 | Uncorrectable errors reported explicitly | **MET** | `ecc`: k = 9…12 → `MEDIA_UNREC` + NAND-ECC error code, never wrong data; XTS crypto-erase and wrong-key paths also fail explicitly |
| 9 | No dropped / duplicated transactions | **MET** | every run counts unknown, duplicate and missing completions (all zero); `concurrency` fills the queue to depth; `backpressure` fills the CQ |
| 10 | Correct firmware/host interaction | **MET** | real firmware on the RTL CPU in every run; `invalid`, `ctrlreset`, `plp`, `top`, `noformat` exercise the control plane |
| 11 | Reproducible benchmarks | **MET (simulation cycles)** | `make bench` → `reports/BENCH.md`; assumptions stated; no hardware numbers |
| 12 | Zero unresolved critical correctness failures | **MET at this evidence level** | the critical defects found (NAND timing mode after power cycle; unsafe auto-format; rebuild-writes-checkpoint hazard) are fixed and have regression scenarios (`05_VERIFICATION.md` §3). Open items below are limitations, not known failures |
| 13 | FPGA/ASIC claims only with separate hardware/signoff evidence | **NOT MET — and not claimed** | `fpga/evidence/` is empty; PD is one block, typical corner, no DRC/LVS |

## 2. Things deliberately *not* done (so nobody assumes otherwise)
* **No hardware evidence of any kind**: no FPGA bitstream, no board, no real NAND, no silicon.
* **HPC configuration**: no multi-channel firmware/HAL, no NVMe/PCIe front end (no endpoint IP exists), no DRAM, no LDPC path.
* **No physical power-loss protection**: durability is write-through + per-page spare records + checkpoints; behaviour with a real supply collapse mid-program is modelled by the twin (torn program), not measured.
* **Security**: confidentiality at rest only (XTS-AES-256, host-supplied key); no authentication, secure boot, key hierarchy or TRNG; the FTL record leaks a 32-bit plaintext hash per page.
* **DFT/manufacturing**: TAP/test-mode only; MBIST not wired; no scan/ATPG; manufacturer ID placeholder.
* **Physical design**: one block, open PDK, typical corner, taken to global routing only (detailed route not converged), no signoff.
* **Endurance**: a scaled, uncalibrated model; no rating; JEDEC documents not accessible.
* **Licence**: none present in the source repository; the owner must choose one before redistribution (P54 bundles a GPL-2.0 reference file that is not part of any P60 artefact).

## 3. Residual risks to carry forward
1. The completion path trusts the firmware; an independent hardware completion gate (P58's RTL controller) is the natural next integration.
2. ECC strength (BCH t = 8) is not based on real NAND data; under the twin's `stress` profile it is inadequate (`07_ENDURANCE.md`).
3. Capacity is 758 × 512 B (map in 32 KiB DMEM); a real drive needs a DRAM-backed map and an FTL with partial-map checkpointing.
4. A power cut during the very first format of a new device requires one explicit REBUILD/FORMAT management command (by design, to avoid silent data loss).
5. One firmware thread and a synchronous executor: queue depth adds latency, not throughput (`reports/BENCH.md`).

## 4. Recommended next steps (in order)
1. FPGA bring-up following `fpga/README.md` (record evidence under `fpga/evidence/`), using a real NAND daughterboard; re-derive NAND timings; run the crash campaign by cutting the board supply.
2. Integrate the P58 completion gate and P53 FlashLink; extend the HAL to several channels; overlap NAND operations in firmware.
3. Replace flop-array SRAMs with macros (or BRAM) incl. the P54 decoder buffers; wrap MBIST; run scan insertion and ATPG.
4. Characterise real NAND (RBER vs P/E, retention, read disturb) and derive ECC/endurance from it; only then consider a JESD218/219 flow.
5. Pick a licence; add key management (KDF/TRNG/OTP) and authenticated firmware boot (P28).

## 5. How to reproduce this report
`make deps vectors fw tb unit formal regress bench endurance dashboard synth fpga-synth cov pd` (hours on 4 cores; the full regression alone is ≈ 1 h with 3 parallel jobs).
Every artefact cited above is produced by one of those targets; `scripts/package.sh` assembles the zip (it never touches git).
