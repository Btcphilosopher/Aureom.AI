# 03 — End-to-end transactions, page format, durability and recovery

## 1. Write transaction (what is acknowledged, and when)
```
host SQ entry + doorbell
 → sfs_host_if copies the entry; sfs_cmd_ctrl validates it in hardware (opcode, fields, LBA range, host buffer, TID uniqueness)
 → tag allocated, firmware queue; firmware pops the tag                                         [command validation]
 → per LBA: sfs_dma  host memory → staging slot (buffer SRAM, SECDED-protected)                  [DMA input]
 → CPU copies the block to the FTL buffer; FTL builds the 16-B spare record                      [integrity metadata]
      { 0xFF, type 0xD1, LPN (4 B), SEQ (48 bit), CRC-32 over data + record[1..11] }
 → HAL: data + record → plain slot S; [XTS-AES-256 encrypt data, tweak = physical page number]   [optional encryption]
 → page engine BCH_ENC: raw page = data(512) | RSVD/BBM(1) | record(16) | CRC-16(2) | parity(13)  [ECC encoding]
 → FTL allocates the next page of the open block (wear-aware, GC if needed)                      [NAND allocation]
 → sfs_nand_ctrl PROGRAM (raw 544 B), then READ STATUS; failure → block retired, retry elsewhere [NAND programming]
 → FTL commits the L2P entry; journal/checkpoint records as required                             [mapping persistence]
 → firmware CPL_POST → CQ entry, phase tag, interrupt                                            [completion]
```
**Durability contract.** `sfftl_write` returns OK only after the page is programmed (status confirmed) *and* mapped; the
completion is posted only after that. Each page carries its LPN and a global sequence number in the spare record, so an
acknowledged write survives power loss **without any checkpoint** (roll-forward at mount). There is no volatile write cache in
the P60 firmware, so every acknowledged WRITE is durable; `FUA` additionally flushes pending journal records; `FLUSH` makes
pending TRIM/journal records durable; a TRIM is acknowledged only after its journal record is programmed.
A command in flight at power loss: each logical page is old **or** new (atomic per page); a multi-block command is not atomic as a whole.

## 2. Read transaction
```
host read → hardware validation → firmware → FTL L2P lookup (unmapped LBA reads as zeros)
 → READ_PAGE raw 544 B into slot R → page engine BCH_DEC (spare area first): sector status CLEAN / CORRECTED(n) / ERASED / UNCORR / INTEGRITY
 → UNCORR or INTEGRITY ⇒ HAL returns UNCORRECTABLE ⇒ FTL retries (read_retries) ⇒ EIO ⇒ completion MEDIA_UNREC     [error propagation]
 → else [XTS-AES decrypt, skipped for an erased page]                                                             [optional decryption]
 → FTL verifies CRC-32 of the plain data and the LPN tag (end-to-end; catches ECC miscorrection, torn pages that ECC "corrects",
   misdirected reads, wrong key)                                                                                  [integrity check]
 → CPU → staging slot → sfs_dma → host memory → completion (result1 = corrected bits)                             [host DMA, completion]
```

## 3. Layers of protection
| Layer | Mechanism | Evidence in this release |
|---|---|---|
| Buffer SRAM | SECDED per 32-bit word (RAS wrapper), poison on uncorrectable | P51/P26 tests (audited); not re-verified by fault injection in P60 |
| NAND media | BCH t=8 per 512 B (4 344-bit codeword), CRC-16 inside the codeword against miscorrection | P54 vectors 115 833 checks; P60 chain tests: k = 0..8 flips corrected exactly, k = 9..12 explicit uncorrectable |
| End to end | FTL CRC-32 (plain data) + LPN tag + SEQ | integrity/crash/ECC scenarios |
| Metadata | commit-last checkpoints in a metadata ring with A/B retention + journal; roll-forward by SEQ | crash campaign (see report) |

Known leak: the CRC-32 in the spare record is computed over *plaintext* and the record is not encrypted, so a 32-bit hash of each
plaintext page, the LPN and the write sequence are visible on the medium in XTS mode (documented in `04_SECURITY.md`).

## 4. Recovery
Mount (`fw/app/ftl_glue.c`, `ftl_boot()`) is **strictly conservative: automatic boot never destroys data and never "recovers into emptiness"**.

1. `sfftl_mount()` — newest valid checkpoint (A/B retention) + journal + roll-forward of the per-page spare records. This is the normal path
   after every clean or unclean shutdown.
2. If there is no loadable checkpoint (`SFFTL_ENOFS`):
   * the medium is **verifiably blank** — page 0 and the last page of every block read back as erased (data and spare all `0xFF`); pages are
     programmed in order, so an erased page 0 means the block was never programmed after its last erase → **first-boot format**;
   * otherwise → `FTL_NOT_BLANK`: the controller stays *not ready*, the medium is untouched, the boot stage reports FATAL, and the host
     management plane must issue an explicit **REBUILD** (mailbox `0x58`, magic `0x52424C44`: mount from the spare records alone, keep whatever
     survives, write a recovery checkpoint) or **FORMAT** (mailbox `0x57`, magic `0x464D5421`: destroys content). Both are refused while the FTL is mounted.

Why not "rebuild, and format if the rebuild finds nothing" (the original policy of this release)? Two defects were found by the crash campaign
(see `05_VERIFICATION.md`): a rebuild-mount *writes a checkpoint*, so after an automatic rebuild on a medium that was merely unreadable the next boot
would find a valid **empty** checkpoint and serve an empty device over unreadable data; and the policy turned a NAND-timing configuration fault into a
format of good data. The price of the conservative policy is explicit: **a crash during the very first format of a fresh device leaves a non-blank
medium without a checkpoint and needs one management command (REBUILD or FORMAT)**; this is a manufacturing-time situation, not a field-time one.

A torn page is detected by BCH failure or, when "ECC corrects it into garbage", by the CRC-32. Nested crashes (power cut again during recovery)
are part of the campaign. Boot after an unclean shutdown reads page 0 of every block plus the metadata ring (≈ 2.7 M cycles in simulation, ≈ 27 ms at the assumed 100 MHz;
`TB boot:` lines in the logs). NAND timing is programmed to ONFI mode 0 by the firmware at every boot, because the NAND's volatile timing mode returns to mode 0 at power-up.

## 5. Page and slot formats
| Slot (544 B stride) | Layout |
|---|---|
| S (plain, 528 B) | data[0..511] · FTL spare record[512..527] |
| R (raw, 544 B) | data(512, cipher text when XTS) · RSVD/BBM(1) · record(16) · CRC-16(2) · parity(13) — one BCH codeword; the BBM byte is outside the codeword (factory marker, `0x00` on bad blocks, scanned before any erase) |
