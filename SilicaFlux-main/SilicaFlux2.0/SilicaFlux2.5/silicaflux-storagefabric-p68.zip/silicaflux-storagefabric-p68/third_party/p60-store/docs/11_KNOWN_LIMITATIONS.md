# 11 — Known limitations (read before relying on anything in this release)

## A. Scope decisions against the brief
1. **Not all nine projects are integrated.** Used in the verified build: P51 (base), P52 (media twin), P54 (BCH), P56/P58 "1.1" (FTL), plus P07 TestCore.
   **Not integrated:** P53 FlashLink (P51's NAND sequencer is used), P55 BufferCore (page-format conflict with the FTL record and with P54), P57 NVMe HostCore (HPC front end),
   P58's RTL completion-gate controller. P59 SecureStore did not exist and was written new.
2. **SILICAFLUX_STORE_HPC is not implemented beyond RTL parameterisation.** No firmware/HAL/verification for >1 channel, no NVMe front end, no PCIe endpoint (no IP in the repository),
   no DRAM/larger buffer, no LDPC path, no "enterprise telemetry" beyond GET_LOG page 0.
3. **No FPGA result, no silicon result, no real-NAND result exists.** Everything is RTL simulation, host simulation, and open-source synthesis/PD estimates.

## B. Media, ECC, endurance
4. The NAND model is **synthetic** (P52): timing, RBER, failure rates and the ONFI command subset are not calibrated to any device. **ECC strength (t = 8) was not derived from real error data.**
   NAND array times were scaled ×1/10 in simulation; errors are injected deterministically (`bd_flip`) or from the twin's uncalibrated profiles.
5. BCH t = 8 per 512 B suits SLC / light MLC only. LDPC / read-retry sequencing / read-disturb handling / refresh are not implemented in this build (the FTL has hooks; the retry loop is simply re-read).
6. **No certified endurance rating can be derived**; the endurance results use a scaled rated endurance and mean-P/E-driven faults (wear levelling's tighter spread therefore does not extend modelled life). JESD218/JESD219 were not accessible; the JESD219-style workload is from memory.
7. Capacity is tiny (758 × 512 B) because the L2P table lives in 32 KiB of DMEM (4 B/page). A real drive needs a DRAM-backed map; P55's DRAM adapter targets a simulated controller only.

## C. Durability and recovery
8. **No physical power-loss protection.** `PLP_PRESENT` semantics are not used; durability relies on write-through + per-page spare records + checkpoints. The capacitor/hold-up *models* in P58 use placeholder values.
9. A multi-block host command is **not atomic**; each 512-B block is old-or-new. Acknowledged writes are durable; unacknowledged ones may or may not have taken effect.
10. The completion path trusts the firmware (no independent hardware completion gate, as P58's RTL controller is not integrated). A firmware bug could acknowledge early; only the testbench oracle would catch it.
11. P58 "1.1" has no journal mirroring: an acknowledged TRIM can be lost if its journal page is damaged *after* programming. (P58 had mirroring; the two forks are incompatible.)
12. The recovery campaign covers a bounded number of crash points per run (see `reports/regression_summary.md`); it is statistical coverage of the power-cut space, not exhaustive. Crash-in-recovery is sampled, not enumerated.
13. Automatic boot never formats a medium that is not verifiably blank (`03_DATAPATH_AND_DURABILITY.md` §4). Consequence: **a power cut during the very first format of a new device, or any unreadable non-blank medium without a valid checkpoint, leaves the controller not-ready until the host issues an explicit REBUILD or FORMAT management command.** This is deliberate (it prevents silent data loss) and is covered by a scenario.

## D. Security
14. XTS-AES gives confidentiality at rest only; no authentication, no key hierarchy/KDF/TRNG/OTP, no secure boot (P28 not integrated), **firmware integrity = CRC32**, host-supplied key over a mailbox.
15. The FTL record (LPN, SEQ, CRC-32 of plaintext) is stored in clear: it leaks a 32-bit plaintext hash per page and the write pattern.
16. Side-channel resistance, formal verification of the AES core, and CAVP vectors: not done. Only IEEE-1619 vectors 1–3 are hard-coded (typed from memory).

## E. Interface and performance
17. Host interface is the **private SQ/CQ ABI** of P51, not NVMe/PCIe/AXI; no OS-driver or conformance test of any kind exists. 32-bit host addresses, 256 MiB window, DW-aligned buffers.
18. SFB2 allows one outstanding transaction per port (≈ 1 word / 4 cycles); the firmware is synchronous and single-threaded; throughput is small-block and latency-bound (see `reports/BENCH.md`). Benchmarks are **simulation cycles at an assumed 100 MHz**; there are no wall-clock numbers.
19. NAND channel scaling, buffer-occupancy and multi-LUN/plane behaviours are not measurable on this build.

## F. DFT, physical design, FPGA
20. MBIST engine instantiated but **no SoC SRAM is MBIST-wrapped**; no scan insertion/ATPG on the P60 design; TAP has no boundary-scan register; the JTAG IDCODE manufacturer field is a **placeholder**.
21. Physical design: only the **page-engine block** was taken through an open-source sky130hd flow up to **global routing** (typical corner; **detailed routing did not converge and was stopped**: 27 642 violations after iteration 1; no DRC/LVS, no signoff, no SRAM macros). The full chip was synthesised to generic cells only; ~112 KiB of memories need macros that are not available. `pd/` documents the flow and its failures honestly.
22. Technology files used are the open sky130hd views (Apache-2.0) present in the repository. The P40 floorplan archive is incomplete and unused. **No foundry signoff is claimed or fabricated.**
23. FPGA wrapper is simulated only at the bridge level; resource numbers are Yosys pre-P&R estimates (`reports/fpga_resource_estimate.md`); no place-and-route, timing, bitstream or board result exists.

## G. Tooling and process
24. Verilator 5.020 (apt) was used for all full-chip simulation; one simulator for the 30-minute scenarios (Icarus runs only the unit benches). Coverage is a mix of functional counters and (where stated) Verilator line coverage; **no UVM-style coverage database, no mutation testing of the P60-authored RTL/firmware** (the crypto core had 21 injected-bug mutants caught by its own bench).
25. No licence file exists in the source repository; the owner must choose one. P54 bundles GPL-2.0 `bch.c` (reference only; not part of any P60 artefact).
26. Four audit sub-agents and one crypto-core sub-agent contributed; their results were re-checked only where stated in the reports (the page-engine testbench was re-run against the final crypto RTL).
27. P54's `sfecc_bch_kes.sv:146` contains out-of-range part-selects (Yosys warns `Range [-1:-8] select out of bounds`; simulation treats them as zero). Not changed in the vendored code; to be reviewed before any ASIC flow (`09_PHYSICAL_DESIGN.md` §4a).
