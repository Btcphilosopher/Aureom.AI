# 02 — Host interface, completion statuses, telemetry, management

## 1. Command ABI (P51 `sfs_*`, unchanged)
SQ entry (32 B): W0 `[7:0] opcode  [8] PHYSICAL  [9] FUA  [31:16] TID`, W2/W3 LBA, W4 length in blocks (1-based), W5 host buffer
(32-bit, DW-aligned, inside the 256 MiB host window). CQ entry (16 B): W0 result0 (blocks transferred), W1 result1
(**ECC bits corrected while serving the command**), W3 `[15:0] TID [16] phase [23:17] status [31:24] error`.
Opcodes implemented by the firmware: `READ 02h`, `WRITE 01h` (FUA flag honoured), `FLUSH 00h`, `DEALLOCATE 09h` (TRIM),
`IDENTIFY 80h`, `GET_LOG 81h`. `PHYSICAL` addressing and physical `ERASE 90h` are refused (the FTL owns the medium).
Logical block = 512 B, **758 LBAs** in the MIN geometry (64 blocks × 16 pages; 2 factory-bad blocks possible), MDTS = 16 blocks.

## 2. Validation and status (hardware validates before firmware sees a command)
`INVALID_OPCODE 01`, `INVALID_FIELD 02` (reserved bits, LEN=0 → `LEN_ZERO`, LEN>MDTS → `LEN_MAX`, misaligned/outside host buffer →
`HOST_ADDR`, address bits above the implemented width), `LBA_RANGE 08`, `ACCESS_DENIED 0A` (physical addressing disabled),
`CID_CONFLICT 03`, `ABORT_PWR_LOSS 05` (+`QUIESCED`), `ABORT_RESET 07`. Firmware-generated:

| Condition | Completion status / error |
|---|---|
| success | `00` / none; result1 = corrected ECC bits |
| page uncorrectable (BCH beyond t, or CRC-16 integrity fail, or FTL CRC-32 / LPN-tag mismatch) | `MEDIA_UNREC 10` / `NAND_ECC_UE 09` — **never wrong data with SUCCESS** |
| no free space (GC cannot progress) | `CAPACITY 09` |
| device read-only / program-erase failure not recoverable | `MEDIA_WRITE 11` / `NAND_FAIL 0A` |
| DMA bus error | `DATA_XFER_ERR 04` / `DMA_READ 07` or `DMA_WRITE 08` |
| power-fail in progress | `ABORT_PWR_LOSS 05` / `QUIESCED 0E` |
| FTL not mounted | `INTERNAL_ERR 06` / `NOT_READY 0F` |

## 3. GET_LOG page 0 (`0x81`, 512 B, 32-bit words; consumed by `dashboard/`)
| Word | Content | Word | Content |
|---|---|---|---|
| 0 | magic `0x474F4C53` ("SLOG") | 1 | layout version `0x00600001` |
| 2–3 | commands done / completed with error | 4–7 | FTL host write cmds / read cmds / LBAs written / LBAs read |
| 8–10 | NAND programs: host / relocation (GC) / metadata | 11–12 | erases: data / metadata |
| 13–14 | GC victims / pages moved | 15 | checkpoints written |
| 16–18 | blocks retired / program failures / erase failures | 19–22 | read uncorrectable / corrected (FTL) / CRC errors / LPN mismatches |
| 23–27 | ECC bits corrected / pages corrected / uncorrectable / integrity fails / erased-page reads (HAL) | 28–31 | free blocks / closed blocks / factory-bad / grown-bad |
| 32–35 | erase count min / max / sum / blocks | 36–37 | valid pages / namespace LBAs |
| 38 | mounts clean \| unclean<<8 \| rebuild<<16 | 39–41 | last mount: pages replayed / torn / fallback |
| 42 | read-only flag | 43 | XTS mode \| key_ready<<1 |
| 44–47 | page engine: BCH enc / BCH dec / XTS ops / errors | 48–51 | NAND CE / UE counters, buffer CE / UE counters (hardware RAS) |
| 52–53 | RAS status / firmware errors | 54–61 | hardware perf: cycles, host cmds, DMA bytes, NAND rd/pg/er, cmd latency max, NAND busy |
| 62–64 | HAL reads / programs / erases | 65–69 | HAL cycles: read / program / erase / page engine / buffer copies |
| 70–71 | NAND timeouts / page-engine errors | | |

WA (write amplification) = (w8+w9+w10) / w6.

## 4. Management (mailbox, host-loaded; the management window is locked once firmware runs)
`PING`, `STATS 0x52`, `KEY_LOAD 0x54` (arg1 = first word index, arg2..7 = ≤ 6 key words; 3 messages for XTS-AES-256),
`KEY_COMMIT 0x55` (expand schedules; staging copy zeroised), `KEY_ZEROIZE 0x56` (crypto-erase), `SHUTDOWN` (end of test),
and the two **boot-recovery commands** that are accepted while the controller is *not ready* because automatic boot refused an unreadable, non-blank medium
(boot stage `FATAL`, `STATUS.CFS` set; see `03_DATAPATH_AND_DURABILITY.md` §4):

| command | arg1 (magic) | effect | refused when |
|---|---|---|---|
| `REBUILD 0x58` | `0x52424C44` ("RBLD") | mount from the page spare records alone, keep whatever survives, write a recovery checkpoint, then become ready | wrong magic → `BAD_CMD`; FTL already mounted → `ACC_ERROR` |
| `FORMAT 0x57` | `0x464D5421` ("FMT!") | erase and format the medium (destroys content), then become ready | wrong magic → `BAD_CMD`; FTL already mounted → `ACC_ERROR` |

The reply to either command is an immediate acknowledgement; the normal boot-complete message (capacity, XTS mode) follows when the controller is ready.
Controller enable/reset/shutdown follow the P51 EN/RDY/SHN handshake; shutdown writes a clean checkpoint and the FTL is
remounted on the next enable.

## 5. Chip-local window (`0xC000_0000`, `sfx_top_ctrl`)
`ID 0x5346_5354`, `VERSION 0x0060_0100`, `CONFIG {cfg,DW,CDW,NCH}`, `RESET_CAUSE` (W1C), `IRQ_STATUS`/`IRQ_MASK`/`IRQ_RAW`
(sources: host_irq, mgmt_irq, ras_fatal, power-fail, TestCore irq, test_done, cmdproc_ready fall), `CTRL` (clear counters),
perf counters observed on pins (cycles, host-memory read/write beats, NAND busy cycles, NAND operations = R/B# falling edges,
BAR reads/writes, power-fail events and cycles), `DFT_STATUS`. `0xC000_1000..` = TestCore register file.

## 6. Page engine registers (`0x4000_F000`)
See the header of `rtl/storage/sfx_page_engine.sv` (source of truth) and `fw/include/sfx_regs.h`. Operations:
`BCH_ENC (S→R)`, `BCH_DEC (R→S, spare area read first)`, `XTS_ENC/XTS_DEC (S in place)`; key window `0x080..0x0BC` is **write-only**.
