# Vendored third-party RTL (unmodified)

| Directory | Source project (repository path of the original archive) | What is vendored | State |
|---|---|---|---|
| `p64-clouddma/` | Project 64 CloudDMA (`silicaflux-clouddma-p64`) | RTL + docs needed to build the protected DMA engine | byte-identical to the original archive (checked) |
| `p63-virtio/` | Project 63 VirtIO (`silicaflux-virtualio`) | engine RTL, C guest library (`sfvirtio.h`, `sfv_core.c`, `sfv_blk.c`), docs | byte-identical; `docs/README.md` added by P68 |
| `p59-securestore/` | Project 59 SecureStore (`silicaflux-securestore`) | XTS-AES engine, AES core, package | byte-identical; `PROVENANCE.md` (P68's note on this vendoring) and `xts_cavp.memh` (test-vector memory file) added by P68 |
| `p60-store/` | Project 60 StorageChip (`silicaflux_p60_storagechip`) | chip RTL, vendored P51 / P52 / P54 / P58 / ControlCore blocks, prebuilt firmware image, NAND model wrapper | byte-identical; `files.f` added by P68 |

* `MANIFEST.sha256` lists the SHA-256 of every vendored file; `python3 scripts/vendor_check.py` verifies it, `--against NAME=DIR` compares with an original project directory (result of the run used for this delivery: `reports/vendor_check.txt`).
* **Nothing here is modified.** (During bring-up a *working copy* of the NAND-model wrapper's typing was adjusted to build under Verilator; the delivered file is the original.)
* **Licence:** none of these source trees state a licence; redistribution terms are unresolved. This package contains them only so the verification can be reproduced.
