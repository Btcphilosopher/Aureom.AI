#!/bin/bash
# Full evidence run: lint, unit tests, every suite (several seeds), the example, mutation testing.  Logs -> reports/, summary -> reports/SUMMARY.txt
# (the benchmark is separate: `make bench`, ~80 min).  Needs Verilator >= 5.040 on PATH (see README), gcc, OpenSSL (libcrypto), python3.
cd "$(dirname "$0")/.." || exit 2
mkdir -p reports; S=reports/SUMMARY.txt; : > $S
note() { echo "$*" | tee -a $S; }
run() { name=$1; shift; echo "== $name" ; if "$@" > "reports/$name.log" 2>&1; then note "PASS  $name"; else note "FAIL  $name  (see reports/$name.log)"; fi; }
note "StorageFabric P68 evidence run $(date -u +%FT%TZ)  verilator: $(verilator --version 2>/dev/null | head -1)"
run lint                make lint
run lint_adapters       make lint-adapters
run model_selftest      make -C model test
run host_lib_test       make -C host test
for s in 1 2 3; do run suite_seed$s make suite TEST=all SEED=$s NCMD=400; done
run suite_xts           make suite-xts SEED=1 NCMD=200
run store_suite_seed1   make store-suite TEST=all SEED=1 NCMD=100
run store_suite_seed2   make store-suite TEST=random SEED=2 NCMD=100
for s in 1 2; do run hostsw_suite_seed$s make hostsw-suite TEST=all SEED=$s NCMD=100; done
for s in 1 2 3; do SEED=$s TMO=900 run virtio_seed$s scripts/run_virtio.sh; done
run example             make example
run mutation            python3 scripts/mutate.py --work "${TMPDIR:-/tmp}/p68_mut" --out reports/mutation_results.json
{ echo; echo "---- counts ----"; grep -hE "checks, [0-9]+ failures|SUITE (PASS|FAIL)|RESULT|self-test|test: " reports/*.log | grep -E "PASS|FAIL" | sort | uniq -c | sort -rn | head -60; } >> $S
echo; cat $S
