#!/bin/bash
# Run every VirtIO integration test in its own process (own DUT, own timeout); logs to reports/virtio_<test>.log
cd "$(dirname "$0")/.." || exit 2
SEED=${SEED:-1}; NCMD=${NCMD:-300}; TMO=${TMO:-900}
rc=0
for t in basic fill random invalid window faults durability concurrent; do
  VT_REPORT=1 timeout "$TMO" build/virtio/Vvirtio_test "$t" "$SEED" "$NCMD" > "reports/virtio_$t.log" 2>&1
  r=$?; if [ $r -eq 124 ]; then echo "[$t] TIMEOUT after ${TMO}s" | tee -a "reports/virtio_$t.log"; rc=1; elif [ $r -ne 0 ]; then rc=1; fi
  tail -n 3 "reports/virtio_$t.log"
done
exit $rc
