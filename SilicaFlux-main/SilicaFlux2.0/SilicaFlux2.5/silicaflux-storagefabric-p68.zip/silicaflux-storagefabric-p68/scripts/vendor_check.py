#!/usr/bin/env python3
"""Vendored third-party RTL provenance.
  vendor_check.py --write            regenerate third_party/MANIFEST.sha256 (sha256 of every vendored file)
  vendor_check.py                    verify the tree against third_party/MANIFEST.sha256
  vendor_check.py --against NAME=DIR compare a vendored tree byte-for-byte with the original project directory (repeatable)
                                     e.g. --against p63-virtio=/path/to/silicaflux-virtualio"""
import os, sys, hashlib
root = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "third_party")
def h(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def files(d):
    for dp, dn, fn in sorted(os.walk(d)):
        dn.sort()
        for f in sorted(fn):
            if f == "MANIFEST.sha256" and os.path.abspath(dp) == os.path.abspath(root): continue     # this tool's own manifest
            yield os.path.relpath(os.path.join(dp, f), root)
args = sys.argv[1:]
if "--write" in args:
    with open(os.path.join(root, "MANIFEST.sha256"), "w") as o:
        for f in files(root): o.write("%s  %s\n" % (h(os.path.join(root, f)), f))
    print("manifest written")
elif "--against" in args:
    bad = 0
    for a in args:
        if "=" not in a: continue
        name, orig = a.split("=", 1)
        same = diff = extra = 0
        for f in files(os.path.join(root, name)):
            rel = os.path.relpath(os.path.join(root, f), os.path.join(root, name)); o = os.path.join(orig, rel)
            if not os.path.exists(o): extra += 1; print("  %s: %s not in the original (added by P68)" % (name, rel))
            elif h(os.path.join(root, f)) == h(o): same += 1
            else: diff += 1; bad += 1; print("  %s: %s DIFFERS from the original" % (name, rel))
        print("%s: %d byte-identical, %d differ, %d added" % (name, same, diff, extra))
    sys.exit(1 if bad else 0)
else:
    bad = 0
    for l in open(os.path.join(root, "MANIFEST.sha256")):
        d, f = l.split(None, 1); f = f.strip()
        if not os.path.exists(os.path.join(root, f)) or h(os.path.join(root, f)) != d: print("MISMATCH", f); bad += 1
    print("manifest OK" if not bad else "%d mismatches" % bad); sys.exit(1 if bad else 0)
