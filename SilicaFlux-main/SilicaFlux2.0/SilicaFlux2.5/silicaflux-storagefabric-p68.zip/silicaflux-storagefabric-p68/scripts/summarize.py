#!/usr/bin/env python3
"""Turn reports/*.log into markdown result tables (used for docs/05_VERIFICATION.md).  Parses the per-test result lines the suites print:
   [test] PASS|FAIL: N checks, M failures, K commands completed (E with error), C cycles      (fabric / STORE / host-sw suites)
   [test] PASS|FAIL (N checks)  ... VIRTIO SUITE ...                                         (VirtIO suite)"""
import re, glob, collections, sys
rx = re.compile(r"^\[(\w+)\] (PASS|FAIL): (\d+) checks, (\d+) failures, (\d+) commands completed \((\d+) with error\), (\d+) cycles")
rv = re.compile(r"^\[(\w+)\] (PASS|FAIL) \((\d+) (?:checks|failures)\)")
def collect(pattern, kind):
    res = collections.OrderedDict()
    for f in sorted(glob.glob(pattern)):
        for l in open(f, errors="replace"):
            m = rx.match(l)
            if m and kind != "virtio":
                t, st, chk, fail, cmds, err, cyc = m.groups(); r = res.setdefault(t, {"runs": 0, "checks": 0, "fail": 0, "cmds": 0, "cyc": 0})
                r["runs"] += 1; r["checks"] += int(chk); r["fail"] += int(fail) + (st == "FAIL" and int(fail) == 0); r["cmds"] += int(cmds); r["cyc"] += int(cyc)
            m = rv.match(l)
            if m and kind == "virtio":
                t, st, n = m.groups(); r = res.setdefault(t, {"runs": 0, "checks": 0, "fail": 0, "cmds": 0, "cyc": 0})
                r["runs"] += 1; r["checks"] += int(n) if st == "PASS" else 0; r["fail"] += 0 if st == "PASS" else int(n)
    return res
def table(title, res):
    print("**%s**\n" % title); print("| test | runs (seeds) | checks | failures | commands | simulated cycles |"); print("|---|---:|---:|---:|---:|---:|")
    tc = tf = 0
    for t, r in res.items():
        print("| `%s` | %d | %d | %d | %s | %s |" % (t, r["runs"], r["checks"], r["fail"], r["cmds"] or "–", ("%d" % r["cyc"]) if r["cyc"] else "–")); tc += r["checks"]; tf += r["fail"]
    print("| **total** | | **%d** | **%d** | | |\n" % (tc, tf))
for title, pat, kind in [("Fabric + simulated block device (`make suite`, seeds 1–3)", "reports/suite_seed*.log", "f"), ("Optional XTS-AES-256 build (`make suite-xts`)", "reports/suite_xts.log", "f"),
                         ("Fabric + SilicaFlux-STORE (P60 chip, real firmware, BCH ECC, NAND twin; fresh medium per test)", "reports/store_suite_seed*.log", "f"),
                         ("Fabric + host-software mailbox backend + software service model", "reports/hostsw_suite_seed*.log", "f"),
                         ("VirtIO block path (P63 engine + guest library + adapter), seeds 1–3", "reports/virtio_[a-z]*.log", "virtio")]:
    r = collect(pat, kind)
    if r: table(title, r)
