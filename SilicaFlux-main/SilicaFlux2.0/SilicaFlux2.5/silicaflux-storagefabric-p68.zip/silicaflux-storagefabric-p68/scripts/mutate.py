#!/usr/bin/env python3
"""Mutation check (first failing test kills; tests ordered fast-first): plant ONE bug at a time into a COPY of the RTL, rebuild the verification suite and run a fast test subset.
A mutation is KILLED when any test fails (or the simulation hangs / times out); SURVIVED mutations are reported honestly.
The project tree itself is never modified (work copy under --work).
usage: mutate.py --work DIR [--only N,N] [--tests a,b,c] [--ncmd 200]"""
import argparse, os, shutil, subprocess, sys, time, json

MUTS = [
 # (id, file, old, new, description, suite)
 (1, "rtl/sf_stor_validate.sv", "w(8)[15:0] != {12'h0, tenant_i}", "1'b0", "validation: tenant-claim check removed", "fabric"),
 (2, "rtl/sf_stor_validate.sv", "else if (!ns_mine)", "else if (1'b0)", "validation: namespace-ownership check removed", "fabric"),
 (3, "rtl/sf_stor_validate.sv", "(end_lba > {1'b0, ns_size_i})", "(end_lba > ({1'b0, ns_size_i} + 65'd1))", "validation: LBA range check off by one", "fabric"),
 (4, "rtl/sf_stor_validate.sv", "(is_wr || is_dis) && ns_ro_i", "is_dis && ns_ro_i", "validation: read-only namespace accepts WRITE", "fabric"),
 (5, "rtl/sf_stor_slot.sv", "durable <= bc_durable; nblk_done <= nb16;\n                  if (fua && !bc_durable)", "durable <= 1'b1; nblk_done <= nb16;\n                  if (fua && !bc_durable)", "durability: WRITE completion always claims durable", "fabric"),
 (6, "rtl/sf_stor_xform.sv", "cmp_guard_bad = (meta0[31:0]  != g_crc);", "cmp_guard_bad = 1'b0;", "integrity: CRC-32C guard never compared", "fabric"),
 (7, "rtl/sf_stor_xform.sv", "cmp_lba_bad   = (meta0[63:48] != exp0[63:48]) || (meta1[31:0] != exp1[31:0]);", "cmp_lba_bad   = 1'b0;", "integrity: LBA tag never compared (misdirected reads)", "fabric"),
 (8, "rtl/sf_stor_slot.sv", "assign d_dom   = ten;", "assign d_dom   = '0;", "isolation: DMA issued in the wrong protection domain", "fabric"),
 (9, "rtl/sf_stor_slot.sv", "if (fua && !bc_durable) begin", "if (1'b0) begin", "durability: FUA no longer forces a backend flush", "fabric"),
 (10, "rtl/sf_stor_slot.sv", "else if (pf_active_i && !fua_flush)", "else if (1'b0)", "PowerSafe: admission not stopped on power-fail warning", "fabric"),
 (11, "rtl/sf_stor_slot.sv", "(to_cnt >= cmd_timeout_i)", "(to_cnt >= cmd_timeout_i + 32'd4000)", "timeout: fires 4000 cycles late", "fabric"),
 (12, "rtl/sf_stor_mgmt.sv", "ns_ov_w = 1'b1;", "ns_ov_w = 1'b0;", "management: overlapping namespaces accepted", "fabric"),
 (13, "rtl/sf_stor_slot.sv", "else if (!be_ready_i) begin", "else if (1'b0) begin", "robustness: no fail-fast when the backend is gone", "hostsw"),
 (14, "rtl/adapters/sf_stor_virtio_adapter.sv", "assign ext_cpl_ready = ((pst == PR_CPL) || (pst == PR_DATA)) && ext_cpl_valid;", "assign ext_cpl_ready = (pst == PR_CPL) && ext_cpl_valid;", "VirtIO adapter: early (error) completion never consumed", "virtio"),
 (15, "rtl/sf_stor_slot.sv", "status <= to_fired ? ST_TIMEOUT : ST_ABORTED_RESET;", "status <= ST_ABORTED_RESET;", "timeout: the command that timed out reports ABORTED_RESET", "fabric"),
 (16, "rtl/adapters/sf_stor_be_hostsw.sv", "if (mb_req_wdata[15:0] == seq) begin", "if (1'b1) begin", "host-sw adapter: stale commit (old sequence number) accepted", "hostsw"),
]

def sh(cmd, cwd, env=None, timeout=None):
    # the timeout is enforced by coreutils `timeout` (exit status 124): subprocess's own timeout would only kill the shell, not the simulator
    if timeout: cmd = "timeout -k 5 %d %s" % (timeout, cmd)
    r = subprocess.run(cmd, shell=True, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if timeout and r.returncode == 124: raise subprocess.TimeoutExpired(cmd, timeout)
    return r

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", required=True); ap.add_argument("--only", default=""); ap.add_argument("--tests", default="invalid,isolation,nscfg,backend_fail,corruption,reset,powerfail,pfinflight,durability,random")
    ap.add_argument("--ncmd", type=int, default=200); ap.add_argument("--out", default="reports/mutation_results.json")
    a = ap.parse_args()
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    only = {int(x) for x in a.only.split(",") if x}
    env = dict(os.environ)
    results = []
    for (mid, f, old, new, desc, suite) in MUTS:
        if only and mid not in only: continue
        work = os.path.join(a.work, "m%d" % mid)
        if os.path.exists(work): shutil.rmtree(work)
        shutil.copytree(root, work, ignore=shutil.ignore_patterns("build", "reports", "*.nlsf", ".git"))
        p = os.path.join(work, f); s = open(p).read()
        if s.count(old) != 1:
            print("M%d: pattern found %d times in %s -- skipped" % (mid, s.count(old), f)); results.append({"id": mid, "desc": desc, "result": "pattern-error"}); continue
        open(p, "w").write(s.replace(old, new))
        t0 = time.time(); killed_by = []
        if suite == "fabric":
            r = sh("make suite TEST=none", work, env)               # builds the suite binary (the 'none' test exits 2)
            binp = os.path.join(work, "build/suite/Vtest_fabric")
            if not os.path.exists(binp): print("M%d: BUILD ERROR\n%s" % (mid, r.stdout[-800:])); results.append({"id": mid, "desc": desc, "result": "build-error"}); continue
            for t in a.tests.split(","):
                try: rr = sh("%s %s 1 %d" % (binp, t, a.ncmd), work, env, timeout=900)
                except subprocess.TimeoutExpired: killed_by.append(t + "(timeout)"); break
                if rr.returncode != 0: killed_by.append(t); break
        elif suite == "hostsw":
            r = sh("make hostsw-suite TEST=none", work, env)
            binp = os.path.join(work, "build/hostsw/Vhostsw_suite")
            if not os.path.exists(binp): print("M%d: BUILD ERROR\n%s" % (mid, r.stdout[-800:])); results.append({"id": mid, "desc": desc, "result": "build-error"}); continue
            for t in ("swfail", "swstall", "withdraw"):
                try: rr = sh("%s %s 1 100" % (binp, t), work, env, timeout=240)
                except subprocess.TimeoutExpired: killed_by.append(t + "(timeout)"); break
                if rr.returncode != 0: killed_by.append(t); break
        elif suite == "virtio":
            r = sh("make virtio-suite TEST=none", work, env)
            binp = os.path.join(work, "build/virtio/Vvirtio_test")
            if not os.path.exists(binp): print("M%d: BUILD ERROR\n%s" % (mid, r.stdout[-800:])); results.append({"id": mid, "desc": desc, "result": "build-error"}); continue
            for t in ("faults", "invalid", "basic"):
                try: rr = sh("%s %s 1 100" % (binp, t), work, env, timeout=300)
                except subprocess.TimeoutExpired: killed_by.append(t + "(timeout)"); break
                if rr.returncode != 0: killed_by.append(t); break
        res = "KILLED" if killed_by else "SURVIVED"
        print("M%-2d %-9s %-62s killed by: %s  (%.0fs)" % (mid, res, desc, ",".join(killed_by) or "-", time.time() - t0), flush=True)
        results.append({"id": mid, "desc": desc, "file": f, "suite": suite, "result": res, "killed_by": killed_by})
        shutil.rmtree(work)
    os.makedirs(os.path.dirname(os.path.join(root, a.out)), exist_ok=True)
    json.dump(results, open(os.path.join(root, a.out), "w"), indent=1)
    k = sum(1 for r in results if r["result"] == "KILLED"); n = sum(1 for r in results if r["result"] in ("KILLED", "SURVIVED"))
    print("mutation score: %d / %d killed" % (k, n))

if __name__ == "__main__":
    main()
