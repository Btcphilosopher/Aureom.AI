#!/usr/bin/env python3
"""vendor_p60.py <p60-project-dir> <dest>: copy exactly the files the P60 StorageChip RTL build needs (from rtl/files.f), plus the
prebuilt firmware images and the NAND digital-twin model/config, into third_party/p60-store.  Writes files.f with paths relative to dest."""
import os, re, shutil, sys, hashlib
src, dst = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
lines = [l.strip() for l in open(os.path.join(src, "rtl/files.f")) if l.strip() and not l.strip().startswith("//")]
files, incdirs = [], []
for l in lines:
    l = l.replace("${P60}", src)
    if l.startswith("+incdir+"): incdirs.append(l[8:])
    else: files.append(l)
copied = set()
def cp(p):
    rel = os.path.relpath(p, src)
    d = os.path.join(dst, rel)
    os.makedirs(os.path.dirname(d), exist_ok=True)
    shutil.copy2(p, d); copied.add(rel); return rel
out = []
for d in incdirs:
    for f in sorted(os.listdir(d)):
        fp = os.path.join(d, f)
        if os.path.isfile(fp) and f.endswith((".svh", ".vh", ".sv", ".v", ".memh", ".hex", ".mem")): cp(fp)
    out.append("+incdir+" + os.path.relpath(d, src))
for f in files: out.append(cp(f))
# firmware images, NAND twin
for rel in ["fw/prebuilt/p60_fw.hex", "fw/prebuilt/p60_fw_xts.hex", "tb/models/nand_flash_model_p60.sv", "vendor/p52/nand_flash_model.sv",
            "vendor/p52/MODEL_LIMITATIONS.md", "vendor/p52/README.md", "patches/nand_model_bd_flip.patch", "docs/11_KNOWN_LIMITATIONS.md",
            "docs/03_DATAPATH_AND_DURABILITY.md", "docs/02_HOST_INTERFACE.md", "docs/12_RELEASE_READINESS.md", "reports/regression_summary.md",
            "README.md", "SHA256SUMS.txt"]:
    if os.path.exists(os.path.join(src, rel)): cp(os.path.join(src, rel))
open(os.path.join(dst, "files.f"), "w").write("\n".join(out) + "\n")
# hashes: run `python3 scripts/vendor_check.py --write` (one manifest for every vendored tree)
print(len(copied), "files copied;", sum(os.path.getsize(os.path.join(dst, r)) for r in copied) // 1024, "KiB")
