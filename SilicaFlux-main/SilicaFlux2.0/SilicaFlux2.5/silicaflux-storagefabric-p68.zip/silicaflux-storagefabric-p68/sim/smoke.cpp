// Bring-up smoke test: one tenant, one PI namespace, write then read back through the full pipeline.
#include "sfs_harness.hpp"
using namespace sfsim;
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf("FAIL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

int main(int argc, char **argv) {
  Harness::set_args(argc, argv);
  Harness h;
  h.reset();
  CHECK(h.m_read(0) == 0x53465347, "mgmt id %08x", h.m_read(0));
  CHECK(h.t_read(0, 0) == 0x53465354, "tenant id");
  printf("GCAPS0=%08x GCAPS1=%08x BE caps=%02x cap=%u\n", h.m_read(8), h.m_read(12), h.m_read(0x604), h.m_read(0x608));
  h.run(50);
  printf("fabric core DMA init (GSTATUS)=%08x\n", h.m_read(0x14));
  // windows for tenant 0
  h.add_window(0, 0x10000, 0x100000);
  uint32_t nsst = h.ns_config(0, 0, 0, 1024, false, false, true);
  printf("ns0 status=%02x\n", nsst);
  h.tenant_cfg(0, true);
  h.m_write(0x10, 1 | 4);            // GCTRL enable + trace
  // queue
  const uint64_t SQ = 0x10000, CQ = 0x11000, BUF = 0x20000;
  h.t_write(0, 0x20, (uint32_t)SQ); h.t_write(0, 0x24, 0); h.t_write(0, 0x28, 16);
  h.t_write(0, 0x30, (uint32_t)CQ); h.t_write(0, 0x34, 0); h.t_write(0, 0x38, 16);
  h.t_write(0, 0x10, 1);
  CHECK(h.t_read(0, 0x14) & 1, "queue enabled, status=%08x", h.t_read(0, 0x14));
  // WRITE one block
  for (int i = 0; i < 512; i++) h.mem[BUF + i] = (uint8_t)(i * 7 + 3);
  auto put = [&](unsigned slot, uint32_t op, uint32_t flags, uint32_t txn, uint32_t ns, uint64_t lba, uint32_t nblk, uint64_t addr) {
    uint32_t w[16] = {0};
    w[0] = 1 | (op << 8) | (flags << 16); w[1] = txn | (ns << 16);
    w[2] = (uint32_t)lba; w[3] = (uint32_t)(lba >> 32); w[4] = nblk; w[5] = nblk * 512;
    w[6] = (uint32_t)addr; w[7] = (uint32_t)(addr >> 32); w[8] = 0;
    memcpy(&h.mem[SQ + slot * 64], w, 64);
  };
  put(0, 1, 0, 0x11, 0, 5, 1, BUF);
  h.t_write(0, 0x40, 1);
  uint64_t t0 = h.cycles;
  uint32_t cqe[8] = {0};
  bool got = false;
  for (int i = 0; i < 20000 && !got; i++) {
    h.step();
    uint32_t ph; memcpy(&ph, &h.mem[CQ + 28], 4);
    if (ph & 1) { memcpy(cqe, &h.mem[CQ], 32); got = true; }
  }
  printf("write done after %llu cycles: txn=%04x status=%02x detail=%02x durable=%u pi=%u nblk_done=%u lat=%u\n",
         (unsigned long long)(h.cycles - t0), cqe[0] & 0xFFFF, (cqe[0] >> 16) & 0xFF, cqe[0] >> 24, cqe[1] & 1, (cqe[1] >> 1) & 1, cqe[1] >> 16, cqe[5]);
  CHECK(got, "no completion");
  CHECK(((cqe[0] >> 16) & 0xFF) == 0, "write status %02x", (cqe[0] >> 16) & 0xFF);
  h.t_write(0, 0x44, 1);
  // READ it back into another buffer
  const uint64_t RB = 0x30000;
  put(1, 2, 0, 0x12, 0, 5, 1, RB);
  h.t_write(0, 0x40, 2);
  got = false;
  for (int i = 0; i < 20000 && !got; i++) {
    h.step();
    uint32_t ph; memcpy(&ph, &h.mem[CQ + 32 + 28], 4);
    if (ph & 1) { memcpy(cqe, &h.mem[CQ + 32], 32); got = true; }
  }
  printf("read done: txn=%04x status=%02x detail=%02x pi=%u\n", cqe[0] & 0xFFFF, (cqe[0] >> 16) & 0xFF, cqe[0] >> 24, (cqe[1] >> 1) & 1);
  CHECK(got, "no read completion");
  CHECK(memcmp(&h.mem[BUF], &h.mem[RB], 512) == 0, "read data mismatch");
  CHECK(h.st.violations == 0, "bus violations: %s", h.last_violation.c_str());
  printf("axi: ar=%llu aw=%llu rbeats=%llu wbeats=%llu\n", (unsigned long long)h.st.ar, (unsigned long long)h.st.aw,
         (unsigned long long)h.st.r_beats, (unsigned long long)h.st.w_beats);
  printf(fails ? "SMOKE FAIL (%d)\n" : "SMOKE PASS\n", fails);
  return fails ? 1 : 0;
}
