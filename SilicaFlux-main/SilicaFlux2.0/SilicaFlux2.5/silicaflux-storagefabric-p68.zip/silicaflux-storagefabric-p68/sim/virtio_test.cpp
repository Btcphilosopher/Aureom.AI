// =============================================================================
// VirtIO block-device integration test.
//
//   guest driver (P63 libsfvirtio, unmodified)  -->  virtio-mmio window  -->  P63 VirtIO engine (unmodified)
//        --> sf_stor_virtio_adapter --> fabric ext source --> validation / scheduler / PI --> simulated block device
//
//   Oracles:
//     * a byte-array reference of the guest's logical disk (sector -> 512 bytes), updated in submission order
//     * an independent DMA-window monitor on the guest-memory port (rebuilt from the hypervisor's management writes)
//     * the simulated device's backdoor: bytes at backend LBA VBASE+sector, "never touched" for every LBA outside the
//       namespace, volatile-cache dirty count (durability), PI trailer
//   Coverage: whole-disk fill, random SG-split / misaligned / queued R/W/FLUSH traffic, invalid requests, out-of-window buffers,
//   backend failure / media error / bit corruption propagation (guest sees IOERR, never silently wrong data), FLUSH reaching the
//   backend, power loss with the volatile cache, isolation of every other namespace, concurrent native tenants.
// =============================================================================
#define SFS_TOP_CLASS Vtb_fabric_virtio_top
#define SFS_TOP_HEADER "Vtb_fabric_virtio_top.h"
#define SFS_NO_XBE
#define SFS_NO_EXT
#define SFS_VIRTIO_TOP
#include "sfs_harness.hpp"
extern "C" {
#include "sfstor.h"
#include "sfvirtio.h"
}
#include <algorithm>
#include <memory>

using namespace sfsim;

static constexpr unsigned VNS = 7;
static constexpr uint64_t VBASE = 1024, VSEC = 1024;                    // namespace 7: backend blocks [1024, 2048)
static constexpr uint64_t GBASE = 0x10000, GLIM = 0x7FFFF;              // guest window (domain DOM)
static constexpr uint64_t VICTIM = 0x80000, VICTIM_END = 0xFFFFF;       // another VM's memory: must never be touched
static constexpr unsigned DOM = 5;
static constexpr uint64_t BUFS = 0x20000, BUFSZ = 0x4000;               // 8 request buffers of 16 KiB
static constexpr uint64_t WIN_BASE = 0x100000, WIN_SIZE = 0x200000;     // native tenants' memory (in the harness' h.mem)

static uint64_t g_checks = 0, g_fails = 0;
#define CHECK(c, ...) do { g_checks++; if (!(c)) { g_fails++; if (g_fails <= 40) { printf("  FAIL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } } while (0)

struct TT { struct VT *vt; unsigned t; uint64_t next; };
static void ph(const char *m) { static bool on = getenv("VT_TRACE") != nullptr; if (on) { printf("  .. %s\n", m); fflush(stdout); } }

struct VT {
  Harness h;
  std::vector<uint8_t> gm;                         // guest memory (1 MiB)
  struct Win { bool v = false, r = false, w = false; uint16_t dom = 0; uint64_t base = 0, lim = 0; } win[8];
  bool dom_v = false; unsigned dom = 0;
  uint64_t viol = 0, dma_rd = 0, dma_wr = 0; std::string first_viol;
  bool pend = false; uint64_t due = 0, rdata = 0; bool derr = false;
  int bp = 30, lat_min = 1, lat_max = 3;
  uint64_t alloc_ptr = GBASE;
  sfv_transport_t tr{}; sfv_mgmt_transport_t mt{};
  sfs_mgmt_transport_t ftp{}; sfs_mgmt_t fmg;
  sfs_transport_t ttp[2]; TT tt[2]; sfs_dev_t tdev[2]; sfs_queue_t tq[2];
  sfv_blk_t blk;
  std::vector<uint8_t> ref;                        // reference disk
  std::vector<uint8_t> written;                    // per sector: ever written through the guest
  std::mt19937_64 rng;

  explicit VT(uint64_t seed) : h(16u << 20, seed), gm(1u << 20, 0), ref(VSEC * 512, 0), written(VSEC, 0), rng(seed * 7919 + 1) {
    h.pre_edge = [this] { dma_cycle(); };
    tr.ctx = this;
    tr.mmio_read32 = [](void *c, uint32_t o) { return ((VT *)c)->bus(false, false, o, 0); };
    tr.mmio_write32 = [](void *c, uint32_t o, uint32_t v) { ((VT *)c)->bus(false, true, o, v); };
    tr.dma_alloc = [](void *c, size_t sz, size_t al, uint64_t *iova) {
      VT *v = (VT *)c; if (al < 4) al = 4; uint64_t a = (v->alloc_ptr + al - 1) & ~(uint64_t)(al - 1);
      if (a + sz > BUFS) return -1;                  // ring / header allocations live below the data buffers
      v->alloc_ptr = a + sz; *iova = a; return 0; };
    tr.mem_write = [](void *c, uint64_t a, const void *p, size_t n) { memcpy(&((VT *)c)->gm[a], p, n); };
    tr.mem_read = [](void *c, uint64_t a, void *p, size_t n) { memcpy(p, &((VT *)c)->gm[a], n); };
    tr.mb = [](void *) {};
    tr.wait_irq = [](void *c, uint32_t budget) { VT *v = (VT *)c; for (uint32_t i = 0; i < budget; i++) { if (v->h.d->v_irq) return 1; v->h.step(); } return (int)v->h.d->v_irq; };
    mt.ctx = this;
    mt.read32 = [](void *c, uint32_t o) { return ((VT *)c)->bus(true, false, o, 0); };
    mt.write32 = [](void *c, uint32_t o, uint32_t v) { ((VT *)c)->mgmt_shadow(o, v); ((VT *)c)->bus(true, true, o, v); };
    ftp.ctx = this;
    ftp.mmio_read32 = [](void *c, uint32_t o) { return ((VT *)c)->h.m_read(o); };
    ftp.mmio_write32 = [](void *c, uint32_t o, uint32_t v) { ((VT *)c)->h.m_write(o, v); };
    ftp.yield = [](void *c) { ((VT *)c)->h.run(2); };
    for (unsigned t = 0; t < 2; t++) {
      tt[t] = {this, t, WIN_BASE + t * WIN_SIZE + 0x10000};
      ttp[t].ctx = &tt[t];
      ttp[t].mmio_read32 = [](void *c, uint32_t o) { TT *x = (TT *)c; return x->vt->h.t_read(x->t, o); };
      ttp[t].mmio_write32 = [](void *c, uint32_t o, uint32_t v) { TT *x = (TT *)c; x->vt->h.t_write(x->t, o, v); };
      ttp[t].mem_alloc = [](void *c, size_t n, size_t al, uint64_t *iova, void **va) {
        TT *x = (TT *)c; if (al < 4) al = 4; uint64_t a = (x->next + al - 1) & ~(uint64_t)(al - 1);
        if (a + n > WIN_BASE + (x->t + 1) * WIN_SIZE) return -1;
        memset(&x->vt->h.mem[a], 0, n); x->next = a + n; *iova = a; *va = &x->vt->h.mem[a]; return 0; };
      ttp[t].mem_free = [](void *, uint64_t) {};
      ttp[t].yield = [](void *c) { ((TT *)c)->vt->h.run(8); };
      ttp[t].barrier = nullptr;
    }
  }

  // ------------------------------------------------------------------ guest-memory DMA port (single outstanding request)
  void monitor(bool we, unsigned domain, uint64_t a, uint8_t be) {
    bool ok = dom_v && domain == dom;
    for (int i = 0; i < 8 && ok; i++) if ((be >> i) & 1) {
      uint64_t x = a + i; bool f = false;
      for (auto &w : win) if (w.v && w.dom == domain && x >= w.base && x <= w.lim && (we ? w.w : w.r)) f = true;
      if (!f) ok = false;
    }
    if (!ok) {
      viol++;
      char b[160]; snprintf(b, sizeof b, "%s domain %u addr 0x%llx be 0x%02x outside every window", we ? "WRITE" : "READ", domain, (unsigned long long)a, be);
      if (first_viol.empty()) first_viol = b;
    }
  }
  void dma_cycle() {
    auto *d = h.d;
    bool resp = pend && due <= h.cycles;
    d->v_dma_resp_valid = resp; d->v_dma_resp_rdata = resp ? rdata : 0; d->v_dma_resp_err = resp ? derr : 0;
    bool rdy = !pend && h.rnd(100 - bp);
    d->v_dma_req_ready = rdy;
    d->eval();
    if (resp) { pend = false; return; }
    if (rdy && d->v_dma_req_valid) {
      uint64_t a = d->v_dma_req_addr & ~7ull; bool we = d->v_dma_req_we; uint8_t be = d->v_dma_req_be;
      monitor(we, d->v_dma_req_domain, a, be);
      derr = false; rdata = 0;
      if (a + 8 > gm.size()) derr = true;
      else if (we) { for (int i = 0; i < 8; i++) if ((be >> i) & 1) gm[a + i] = (d->v_dma_req_wdata >> (8 * i)) & 0xFF; dma_wr++; }
      else { memcpy(&rdata, &gm[a], 8); dma_rd++; }
      pend = true; due = h.cycles + lat_min + (lat_max > lat_min ? h.rng() % (lat_max - lat_min + 1) : 0);
    }
  }
  void mgmt_shadow(uint32_t off, uint32_t v) {
    if (off == 0x010) { dom_v = v >> 31; dom = v & 0xFFFF; return; }
    if (off >= 0x40 && off < 0x40 + 0x20 * 8) {
      unsigned i = (off - 0x40) / 0x20, f = ((off - 0x40) % 0x20) / 4; Win &w = win[i];
      switch (f) {
        case 0: w.v = v & 1; w.r = (v >> 1) & 1; w.w = (v >> 2) & 1; break;
        case 1: w.dom = v & 0xFFFF; break;
        case 2: w.base = (w.base & ~0xFFFFFFFFull) | v; break;
        case 3: w.base = (w.base & 0xFFFFFFFFull) | ((uint64_t)v << 32); break;
        case 4: w.lim = (w.lim & ~0xFFFFFFFFull) | v; break;
        case 5: w.lim = (w.lim & 0xFFFFFFFFull) | ((uint64_t)v << 32); break;
      }
    }
  }
  // blocking register access on the guest window (mgmt=false) or the privileged window (mgmt=true)
  uint32_t bus(bool mgmt, bool we, uint32_t addr, uint32_t wd) {
    auto *d = h.d; int guard = 0;
    for (;;) {
      if (mgmt) { d->v_mgmt_req_valid = 1; d->v_mgmt_req_we = we; d->v_mgmt_req_addr = addr; d->v_mgmt_req_wdata = wd; }
      else { d->v_mmio_req_valid = 1; d->v_mmio_req_we = we; d->v_mmio_req_addr = addr; d->v_mmio_req_wdata = wd; d->v_mmio_req_be = 0xF; }
      d->eval();
      bool rdy = mgmt ? d->v_mgmt_req_ready : d->v_mmio_req_ready;
      h.step();
      if (rdy) break;
      if (++guard > 400000) { CHECK(false, "bus request never accepted (addr 0x%x)", addr); break; }
    }
    d->v_mgmt_req_valid = 0; d->v_mmio_req_valid = 0; d->eval();
    for (guard = 0; guard < 400000; guard++) {
      bool rv = mgmt ? d->v_mgmt_resp_valid : d->v_mmio_resp_valid;
      if (rv) return mgmt ? d->v_mgmt_resp_rdata : d->v_mmio_resp_rdata;
      h.step();
    }
    CHECK(false, "bus response timeout (addr 0x%x)", addr);
    return 0xDEADBEEF;
  }

  // ------------------------------------------------------------------ bring-up
  void fabric_config() {
    sfs_mgmt_open(&fmg, &ftp);
    sfs_be_info_t bi{}; sfs_mgmt_backend_info(&fmg, &bi);
    bool pi = bi.caps & 1;
    struct N { unsigned n, owner; uint64_t base, size; } ns[] = {{0, 0, 0, 256}, {1, 1, 256, 256}, {2, 2, 512, 256}, {VNS, 3, VBASE, VSEC}};
    for (auto &x : ns) {
      sfs_ns_cfg_t nc{x.owner, x.base, x.size, 0, 0, pi, 0}; uint32_t st = 0;
      int r = sfs_mgmt_ns_config(&fmg, x.n, &nc, &st);
      CHECK(r == 0, "ns %u refused (status %02x)", x.n, st);
    }
    for (unsigned t = 0; t < 4; t++) { sfs_tcfg_t tc{}; tc.enable_allowed = 1; tc.weight = 1; tc.burst = 16; sfs_mgmt_tenant_cfg(&fmg, t, &tc); }
    h.windows.clear(); h.pt_next = 4;
    for (unsigned t = 0; t < 2; t++) h.add_window(t, WIN_BASE + t * WIN_SIZE, WIN_SIZE);
    sfs_mgmt_enable_fabric(&fmg, 1);
    sfs_mgmt_set_gctrl(&fmg, SFS_GCTRL_ENABLE | SFS_GCTRL_TRACE_EN);
  }
  void hv_config() {
    uint32_t ver = 0, caps = 0;
    CHECK(sfv_hv_probe(&mt, &ver, &caps) == SFV_OK, "engine probe");
    sfv_hv_bind_domain(&mt, DOM);
    sfv_hv_set_window(&mt, 0, DOM, GBASE, GLIM, 1, 1);
  }
  void power_on() { h.reset(); h.run(50); fabric_config(); hv_config(); open_blk(); }
  void open_blk() {
    alloc_ptr = GBASE;
    int r = sfv_blk_open(&blk, &tr, 64);
    CHECK(r == SFV_OK, "sfv_blk_open: %s", sfv_strerror(r));
    CHECK(blk.capacity == VSEC, "capacity %llu sectors, expected %llu", (unsigned long long)blk.capacity, (unsigned long long)VSEC);
    CHECK(blk.has_flush, "FLUSH feature not negotiated");
  }
  void reopen() { sfv_blk_close(&blk); open_blk(); }
  // after an attack the engine may have latched DEVICE_NEEDS_RESET (fatal descriptor error): the guest driver resets and re-probes
  void recover_if_needed(int s) { if (s == 254 || s == 255 || (sfv_dev_status(&blk.dev) & VIRTIO_STATUS_DEVICE_NEEDS_RESET)) reopen(); }

  // ------------------------------------------------------------------ backend backdoor
  uint64_t dbg_word(uint64_t lba, unsigned w) { h.d->sim_dbg_lba = lba; h.d->sim_dbg_word = w; h.d->eval(); return h.d->sim_dbg_data; }
  bool dbg_unmapped(uint64_t lba) { h.d->sim_dbg_lba = lba; h.d->sim_dbg_word = 0; h.d->eval(); return h.d->sim_dbg_unmapped; }
  // backend block of guest sector s == fabric namespace 7 LBA s == backend LBA VBASE+s; data bytes are the first 512 of the unit
  bool backend_matches(uint64_t sector, const uint8_t *exp) {
    for (unsigned w = 0; w < 64; w++) { uint64_t e; memcpy(&e, exp + 8 * w, 8); if (dbg_word(VBASE + sector, w) != e) return false; }
    return true;
  }
  void pulse_corrupt(uint64_t lba, unsigned bit) {
    h.d->sim_inj_corrupt_lba = lba; h.d->sim_inj_corrupt_bit = bit; h.d->sim_inj_corrupt = 1; h.run(1); h.d->sim_inj_corrupt = 0; h.run(2);
  }

  // ------------------------------------------------------------------ guest requests
  struct Req { uint32_t type; uint64_t sector, nsec, bytes; unsigned slot; unsigned off; std::vector<uint8_t> expect; bool is_read, expect_ok; uint8_t pre; };
  std::vector<uint8_t> pattern(size_t n) { std::vector<uint8_t> v(n); uint64_t x = rng() | 1; for (auto &b : v) { x ^= x << 13; x ^= x >> 7; x ^= x << 17; b = (uint8_t)x; } return v; }
  // build the SG list for `bytes` at `buf`, split at random byte offsets
  std::vector<sfv_sg_t> make_sg(uint64_t buf, uint32_t bytes, bool dev_writable, bool split) {
    std::vector<sfv_sg_t> sg; uint32_t pos = 0;
    while (pos < bytes) {
      uint32_t n = bytes - pos;
      if (split && n > 1 && sg.size() < 5 && (rng() % 3) != 0) n = 1 + rng() % std::min<uint32_t>(n - 1, 700);
      sg.push_back({buf + pos, n, (uint8_t)dev_writable}); pos += n;
    }
    return sg;
  }
  // queue a read/write/flush; applies the model in submission order.  Returns false if it could not be queued.
  struct Pending { uint16_t head; Req r; };
  std::vector<Pending> pending;
  bool submit(uint32_t type, uint64_t sector, uint64_t nsec, unsigned slot, bool split, bool apply_model = true, uint8_t pre = 0xCC) {
    Req r{}; r.type = type; r.sector = sector; r.nsec = nsec; r.bytes = (uint32_t)(nsec * 512); r.slot = slot; r.is_read = (type == VIRTIO_BLK_T_IN); r.expect_ok = true; r.pre = pre;
    r.off = rng() % 8;
    uint64_t buf = BUFS + slot * BUFSZ + r.off;
    std::vector<sfv_sg_t> sg;
    if (type == VIRTIO_BLK_T_OUT) {
      auto data = pattern(r.bytes); memcpy(&gm[buf], data.data(), r.bytes);
      sg = make_sg(buf, r.bytes, false, split);
      if (apply_model) { memcpy(&ref[sector * 512], data.data(), r.bytes); for (uint64_t s = 0; s < nsec; s++) written[sector + s] = 1; }
    } else if (type == VIRTIO_BLK_T_IN) {
      memset(&gm[BUFS + slot * BUFSZ], pre, BUFSZ);                 // sentinel: unwritten bytes and overruns are detectable
      sg = make_sg(buf, r.bytes, true, split);
      r.expect.assign(ref.begin() + sector * 512, ref.begin() + sector * 512 + r.bytes);
    }
    uint16_t head = 0;
    int rc = sfv_blk_submit(&blk, type, sector, sg.data(), (unsigned)sg.size(), nullptr, &head);
    if (rc) { CHECK(false, "sfv_blk_submit rc=%d", rc); return false; }
    pending.push_back({head, r});
    return true;
  }
  // kick and collect every pending completion; check status, data, sentinels, used length
  void finish_all(int expect_status = VIRTIO_BLK_S_OK) {
    if (pending.empty()) return;
    sfv_vq_kick(&blk.vq);
    for (auto &p : pending) {
      sfv_blk_completion_t c; int rc = sfv_blk_wait(&blk, &c, 50u * 1000u * 1000u);
      if (rc < 0) { CHECK(false, "wait rc=%d (%s)", rc, sfv_strerror(rc)); break; }
      CHECK(c.head == p.head, "completion order: head %u expected %u", c.head, p.head);
      CHECK(c.status == expect_status, "request type %u sector %llu nsec %llu status %u, expected %u", p.r.type, (unsigned long long)p.r.sector,
            (unsigned long long)p.r.nsec, c.status, expect_status);
      if (expect_status == VIRTIO_BLK_S_OK) {
        if (p.r.is_read) {
          uint64_t buf = BUFS + p.r.slot * BUFSZ + p.r.off;
          bool same = memcmp(&gm[buf], p.r.expect.data(), p.r.bytes) == 0;
          CHECK(same, "READ sector %llu nsec %llu: data differs from the reference", (unsigned long long)p.r.sector, (unsigned long long)p.r.nsec);
          bool guard_ok = true;
          for (uint64_t i = BUFS + p.r.slot * BUFSZ; i < buf; i++) guard_ok &= gm[i] == p.r.pre;
          for (uint64_t i = buf + p.r.bytes; i < BUFS + (p.r.slot + 1) * BUFSZ; i++) guard_ok &= gm[i] == p.r.pre;
          CHECK(guard_ok, "READ overran its buffer");
          CHECK(c.used_len == p.r.bytes + 1, "used.len %u, expected %llu", c.used_len, (unsigned long long)p.r.bytes + 1);
        } else CHECK(c.used_len == 1, "used.len %u for a non-read (expected 1)", c.used_len);
      }
    }
    pending.clear();
  }
  int simple(uint32_t type, uint64_t sector, uint64_t nsec) { return simple_buf(type, sector, nsec, BUFS, nsec * 512, nullptr); }
  // one synchronous request with an arbitrary buffer; returns the virtio status (255 on library error)
  int simple_buf(uint32_t type, uint64_t sector, uint64_t nsec, uint64_t buf, uint64_t bytes, int *fatal) {
    (void)nsec;
    sfv_sg_t sg{buf, (uint32_t)bytes, (uint8_t)(type == VIRTIO_BLK_T_IN)};
    uint16_t head; int rc = sfv_blk_submit(&blk, type, sector, &sg, bytes ? 1 : 0, nullptr, &head);
    if (rc) return 255;
    sfv_vq_kick(&blk.vq);
    sfv_blk_completion_t c; rc = sfv_blk_wait(&blk, &c, 4u * 1000u * 1000u);
    if (rc < 0) { if (fatal) *fatal = rc; return 254; }
    return c.status;
  }
  int do_flush() { return simple(VIRTIO_BLK_T_FLUSH, 0, 0); }
  void run_idle(unsigned n) { h.run(n); }
  uint32_t dirty() { h.d->eval(); return h.d->sim_dirty; }
  bool victim_intact() { for (uint64_t i = VICTIM; i <= VICTIM_END; i++) if (gm[i] != 0xEE) return false; return true; }
};

// ---------------------------------------------------------------------------------------------------------------------
static void t_basic(VT &v) {
  // one sector write + read, backend byte check
  v.submit(VIRTIO_BLK_T_OUT, 0, 1, 0, false); v.finish_all();
  v.submit(VIRTIO_BLK_T_IN, 0, 1, 1, false); v.finish_all();
  CHECK(v.backend_matches(0, &v.ref[0]), "backend LBA %llu does not hold guest sector 0", (unsigned long long)VBASE);
  // multi-sector, misaligned buffers
  v.submit(VIRTIO_BLK_T_OUT, 5, 8, 2, true); v.finish_all();
  v.submit(VIRTIO_BLK_T_IN, 4, 10, 3, true); v.finish_all();
  for (uint64_t s = 5; s < 13; s++) CHECK(v.backend_matches(s, &v.ref[s * 512]), "backend sector %llu", (unsigned long long)s);
  // never-written sectors read zeros through the whole stack
  v.submit(VIRTIO_BLK_T_IN, 900, 4, 4, false); v.finish_all();
  // capacity edges: last sector
  v.submit(VIRTIO_BLK_T_OUT, VSEC - 1, 1, 5, false); v.submit(VIRTIO_BLK_T_IN, VSEC - 1, 1, 6, false); v.finish_all();
}

static void t_fill(VT &v) {
  for (uint64_t s = 0; s < VSEC; s += 8) { v.submit(VIRTIO_BLK_T_OUT, s, 8, (s / 8) % 8, false); if ((s / 8) % 4 == 3) v.finish_all(); }
  v.finish_all();
  CHECK(v.do_flush() == VIRTIO_BLK_S_OK, "flush after fill");
  CHECK(v.dirty() == 0, "volatile cache still dirty (%u) after FLUSH", v.dirty());
  for (uint64_t s = 0; s < VSEC; s += 16) { v.submit(VIRTIO_BLK_T_IN, s, 16, (s / 16) % 4, false); if ((s / 16) % 4 == 3) v.finish_all(); }
  v.finish_all();
  unsigned bad = 0; for (uint64_t s = 0; s < VSEC; s++) if (!v.backend_matches(s, &v.ref[s * 512])) bad++;
  CHECK(bad == 0, "%u sectors differ between the reference and the backend", bad);
}

static void t_random(VT &v, int n) {
  int issued = 0;
  while (issued < n) {
    unsigned depth = 1 + v.rng() % 4;
    for (unsigned k = 0; k < depth && issued < n; k++, issued++) {
      unsigned r = v.rng() % 100;
      uint64_t nsec = 1 + v.rng() % 8, sector = v.rng() % (VSEC - nsec + 1);
      if (r < 8) v.submit(VIRTIO_BLK_T_FLUSH, 0, 0, k, false);
      else if (r < 55) v.submit(VIRTIO_BLK_T_OUT, sector, nsec, k, v.rng() % 2);
      else v.submit(VIRTIO_BLK_T_IN, sector, nsec, k, v.rng() % 2);
    }
    v.finish_all();
  }
  // the hypervisor-visible state must now agree sector by sector with the backend (data written through the guest only)
  unsigned bad = 0, seen = 0;
  for (uint64_t s = 0; s < VSEC; s++) if (v.written[s]) { seen++; if (!v.backend_matches(s, &v.ref[s * 512])) bad++; }
  CHECK(bad == 0, "random traffic: %u of %u written sectors differ in the backend", bad, seen);
}

static void t_invalid(VT &v) {
  auto snapshot = v.ref;
  // out-of-range
  CHECK(v.simple(VIRTIO_BLK_T_IN, VSEC, 1) == VIRTIO_BLK_S_IOERR, "read at capacity");
  CHECK(v.simple(VIRTIO_BLK_T_OUT, VSEC, 1) == VIRTIO_BLK_S_IOERR, "write at capacity");
  CHECK(v.simple(VIRTIO_BLK_T_OUT, VSEC - 1, 2) == VIRTIO_BLK_S_IOERR, "write straddling capacity");
  CHECK(v.simple(VIRTIO_BLK_T_IN, ~0ull, 1) == VIRTIO_BLK_S_IOERR, "read at sector 2^64-1");
  CHECK(v.simple(VIRTIO_BLK_T_IN, 1ull << 63, 1) == VIRTIO_BLK_S_IOERR, "read at sector 2^63");
  // length errors: not a multiple of 512
  CHECK(v.simple_buf(VIRTIO_BLK_T_OUT, 3, 1, BUFS, 100, nullptr) == VIRTIO_BLK_S_IOERR, "100-byte write");
  CHECK(v.simple_buf(VIRTIO_BLK_T_IN, 3, 1, BUFS, 513, nullptr) == VIRTIO_BLK_S_IOERR, "513-byte read");
  // unsupported request types (DISCARD / WRITE_ZEROES not offered)
  CHECK(v.simple(VIRTIO_BLK_T_DISCARD, 0, 1) == VIRTIO_BLK_S_UNSUPP, "DISCARD must be UNSUPP");
  CHECK(v.simple(99, 0, 0) == VIRTIO_BLK_S_UNSUPP, "unknown request type must be UNSUPP");
  // none of the above may have changed the disk (compare through the guest and the backend)
  v.submit(VIRTIO_BLK_T_IN, 0, 16, 0, false); v.submit(VIRTIO_BLK_T_IN, VSEC - 16, 16, 1, false); v.finish_all();
  CHECK(v.ref == snapshot, "reference changed by invalid requests");
  // the engine is still alive and in-order after all those errors
  v.submit(VIRTIO_BLK_T_OUT, 20, 2, 0, false); v.submit(VIRTIO_BLK_T_IN, 20, 2, 1, false); v.finish_all();
}

// attacks on guest memory: buffers outside the VM's window must never produce a bus beat
static void t_window(VT &v) {
  memset(&v.gm[VICTIM], 0xEE, VICTIM_END - VICTIM + 1);
  auto snapshot = v.ref;
  uint64_t viol0 = v.viol;
  // WRITE request whose payload lives in another VM's memory (would leak it onto the disk)
  int fatal = 0;
  int s = v.simple_buf(VIRTIO_BLK_T_OUT, 30, 1, VICTIM + 0x100, 512, &fatal);
  CHECK(s == VIRTIO_BLK_S_IOERR || s == 254, "write from foreign memory returned status %d", s);
  v.recover_if_needed(s);
  // READ request whose destination is another VM's memory (would overwrite it)
  s = v.simple_buf(VIRTIO_BLK_T_IN, 30, 1, VICTIM + 0x400, 512, &fatal);
  CHECK(s == VIRTIO_BLK_S_IOERR || s == 254, "read into foreign memory returned status %d", s);
  v.recover_if_needed(s);
  // buffer straddling the end of the window
  s = v.simple_buf(VIRTIO_BLK_T_IN, 31, 1, GLIM + 1 - 256, 512, &fatal);
  CHECK(s == VIRTIO_BLK_S_IOERR || s == 254, "read straddling the window end returned status %d", s);
  v.recover_if_needed(s);
  CHECK(v.viol == viol0, "DMA monitor: %llu beat(s) outside the guest window (%s)", (unsigned long long)(v.viol - viol0), v.first_viol.c_str());
  CHECK(v.victim_intact(), "foreign VM memory was modified");
  CHECK(v.ref == snapshot, "reference modified");
  v.submit(VIRTIO_BLK_T_IN, 30, 1, 0, false); v.finish_all();      // the device recovered and still shows the old data
  CHECK(v.backend_matches(30, &v.ref[30 * 512]) || !v.written[30], "sector 30 changed by an attack");
}

static void t_durability(VT &v) {
  CHECK(v.do_flush() == VIRTIO_BLK_S_OK, "initial flush");
  CHECK(v.dirty() == 0, "dirty after flush");
  for (int k = 0; k < 4; k++) v.submit(VIRTIO_BLK_T_OUT, 100 + k, 1, k, false);
  v.finish_all();
  CHECK(v.dirty() > 0, "a guest write must sit in the backend's volatile cache until FLUSH (dirty=%u): the write was acknowledged, not durable", v.dirty());
  CHECK(v.do_flush() == VIRTIO_BLK_S_OK, "flush");
  CHECK(v.dirty() == 0, "FLUSH did not reach the backend (dirty=%u)", v.dirty());
  // sectors 100..103 are flushed; 110..115 are written afterwards and NOT flushed
  std::vector<uint8_t> old(6 * 512); memcpy(old.data(), &v.ref[110 * 512], 6 * 512);
  for (int k = 0; k < 6; k++) v.submit(VIRTIO_BLK_T_OUT, 110 + k, 1, k, false);
  v.finish_all();
  std::vector<uint8_t> nw(6 * 512); memcpy(nw.data(), &v.ref[110 * 512], 6 * 512);
  CHECK(v.dirty() > 0, "unflushed writes must be dirty");
  // power loss: the device keeps a random subset of the unflushed blocks, the whole chip (engine, fabric) restarts
  v.h.d->sim_power_loss = 1; v.h.run(2); v.h.d->sim_power_loss = 0;
  v.pend = false; v.h.reset(12); v.h.run(100);
  v.fabric_config(); v.hv_config(); v.open_blk();
  for (int k = 0; k < 4; k++) { v.submit(VIRTIO_BLK_T_IN, 100 + k, 1, k, false); }
  v.finish_all();                                         // flushed data survived (compared with the model in finish_all)
  for (int k = 0; k < 6; k++) {
    // the model cannot predict which unflushed blocks survive: accept old-or-new per sector
    uint64_t s = 110 + k; std::vector<uint8_t> got(512);
    v.submit(VIRTIO_BLK_T_IN, s, 1, 6, false, true);
    sfv_vq_kick(&v.blk.vq); sfv_blk_completion_t c; int rc = sfv_blk_wait(&v.blk, &c, 50u * 1000u * 1000u);
    CHECK(rc == 1 && c.status == 0, "post-power-loss read of sector %llu", (unsigned long long)s);
    memcpy(got.data(), &v.gm[BUFS + 6 * BUFSZ + v.pending.back().r.off], 512);
    bool is_old = memcmp(got.data(), &old[k * 512], 512) == 0, is_new = memcmp(got.data(), &nw[k * 512], 512) == 0;
    CHECK(is_old || is_new, "sector %llu after power loss is neither the old nor the new block (torn / corrupted)", (unsigned long long)s);
    if (is_old && !is_new) memcpy(&v.ref[s * 512], &old[k * 512], 512);   // adopt the surviving state as the new reference
    v.pending.clear();
  }
}

static void t_faults(VT &v) {
  // --- device failure: the guest sees IOERR, the data is untouched, the stack recovers
  v.submit(VIRTIO_BLK_T_OUT, 200, 2, 0, false); v.finish_all();                    // sectors 200, 201 hold known data
  CHECK(v.do_flush() == VIRTIO_BLK_S_OK, "flush");
  ph("inject device failure"); v.h.d->sim_inj_fail = 1;
  CHECK(v.simple(VIRTIO_BLK_T_IN, 200, 1) == VIRTIO_BLK_S_IOERR, "read during device failure must be IOERR"); ph("read failed ok");
  { auto data = v.pattern(512); memcpy(&v.gm[BUFS], data.data(), 512);
    CHECK(v.simple(VIRTIO_BLK_T_OUT, 201, 1) == VIRTIO_BLK_S_IOERR, "write during device failure must be IOERR"); }
  ph("write failed"); CHECK(v.do_flush() == VIRTIO_BLK_S_IOERR, "flush during device failure must be IOERR"); ph("flush failed ok");
  v.h.d->sim_inj_fail = 0; v.run_idle(50);
  v.submit(VIRTIO_BLK_T_IN, 200, 1, 0, false); v.submit(VIRTIO_BLK_T_IN, 201, 1, 1, false); v.finish_all();   // healthy again; failed write left no trace
  // --- media error on one block: IOERR for that sector only
  ph("media error");
  v.h.d->sim_inj_media_en = 1; v.h.d->sim_inj_media_lba = VBASE + 300;
  CHECK(v.simple(VIRTIO_BLK_T_IN, 300, 1) == VIRTIO_BLK_S_IOERR, "media error must be IOERR");
  CHECK(v.simple(VIRTIO_BLK_T_IN, 301, 1) == VIRTIO_BLK_S_OK, "neighbour sector must be readable");
  v.h.d->sim_inj_media_en = 0;
  ph("bit rot");
  // --- bit rot in the stored block: end-to-end integrity detects it; the guest never receives the corrupted bytes
  v.submit(VIRTIO_BLK_T_OUT, 400, 1, 0, false); v.finish_all();
  CHECK(v.do_flush() == VIRTIO_BLK_S_OK, "flush");
  v.submit(VIRTIO_BLK_T_IN, 401, 1, 2, false); v.finish_all();                        // the adapter's one-sector buffer moves off sector 400
  v.pulse_corrupt(VBASE + 400, 77);
  memset(&v.gm[BUFS + 5 * BUFSZ], 0xCC, 512);
  { sfv_sg_t sg{BUFS + 5 * BUFSZ, 512, 1}; uint16_t hd; sfv_blk_submit(&v.blk, VIRTIO_BLK_T_IN, 400, &sg, 1, nullptr, &hd); sfv_vq_kick(&v.blk.vq);
    sfv_blk_completion_t c; int rc = sfv_blk_wait(&v.blk, &c, 50u * 1000u * 1000u);
    CHECK(rc == 1 && c.status == VIRTIO_BLK_S_IOERR, "a corrupted block must produce IOERR, got status %d", rc == 1 ? c.status : rc);
    // the guest buffer must not hold the corrupted block (the correct data with one flipped bit)
    unsigned diffbits = 0; for (int i = 0; i < 512; i++) diffbits += __builtin_popcount((uint8_t)(v.gm[BUFS + 5 * BUFSZ + i] ^ v.ref[400 * 512 + i]));
    CHECK(diffbits != 1, "the corrupted block was delivered to the guest (one-bit difference)"); }
  // rewriting repairs it
  v.submit(VIRTIO_BLK_T_OUT, 400, 1, 0, false); v.submit(VIRTIO_BLK_T_IN, 400, 1, 1, false); v.finish_all();
}

static void t_isolation(VT &v, uint64_t native_lo = 0, uint64_t native_hi = 0) {   // [native_lo, native_hi): blocks the native tenants legitimately wrote
  // no backend block outside [VBASE, VBASE+VSEC) was ever written by the guest, no matter what it did
  unsigned touched = 0;
  for (uint64_t lba = 0; lba < 4096; lba++) if ((lba < VBASE || lba >= VBASE + VSEC) && !(lba >= native_lo && lba < native_hi) && !v.dbg_unmapped(lba)) touched++;
  CHECK(touched == 0, "%u backend blocks outside the guest's namespace were modified", touched);
  CHECK(v.victim_intact(), "foreign VM memory modified");
  CHECK(v.viol == 0, "DMA monitor: %llu beat(s) outside the guest window (%s)", (unsigned long long)v.viol, v.first_viol.c_str());
}

// native tenants (their own queues in their own memory) run in the same simulation while the guest keeps the VirtIO path busy
static void t_concurrent(VT &v, int rounds) {
  for (unsigned t = 0; t < 2; t++) {
    int r = sfs_dev_open(&v.tdev[t], &v.ttp[t], t); CHECK(r == 0, "tenant %u open", t);
    r = sfs_queue_create(&v.tdev[t], &v.tq[t], 32, 32); CHECK(r == 0, "tenant %u queue", t);
  }
  std::vector<uint8_t> tref[2] = {std::vector<uint8_t>(256 * 512, 0), std::vector<uint8_t>(256 * 512, 0)};
  sfs_buf_t tb[2]; for (unsigned t = 0; t < 2; t++) sfs_buf_alloc(&v.tdev[t], 8 * 512, &tb[t]);
  for (int rd = 0; rd < rounds; rd++) {
    // guest burst in flight (not waited for yet)
    for (unsigned k = 0; k < 4; k++) {
      uint64_t nsec = 1 + v.rng() % 8, sec = v.rng() % (VSEC - nsec + 1);
      if (v.rng() % 3) v.submit(VIRTIO_BLK_T_OUT, sec, nsec, k, v.rng() % 2); else v.submit(VIRTIO_BLK_T_IN, sec, nsec, k, v.rng() % 2);
    }
    sfv_vq_kick(&v.blk.vq);
    // native tenants hammer their own namespaces meanwhile
    for (unsigned t = 0; t < 2; t++) {
      uint32_t nb = 1 + v.rng() % 8; uint64_t lba = v.rng() % (256 - nb + 1);
      auto data = v.pattern(nb * 512); memcpy(tb[t].va, data.data(), nb * 512);
      sfs_cqe_t cq; int r = sfs_write_sync(&v.tq[t], t, lba, nb, tb[t].iova, nullptr, 0, &cq);
      CHECK(r == 0, "tenant %u write: %s status %u", t, sfs_strerror(r), cq.status);
      memcpy(&tref[t][lba * 512], data.data(), nb * 512);
      memset(tb[t].va, 0xCC, 8 * 512);
      r = sfs_read_sync(&v.tq[t], t, lba, nb, tb[t].iova, 0, &cq);
      CHECK(r == 0, "tenant %u read: %s", t, sfs_strerror(r));
      CHECK(memcmp(tb[t].va, &tref[t][lba * 512], nb * 512) == 0, "tenant %u read-back differs", t);
    }
    // collect the guest burst (kick already done: finish_all kicks again, which is a harmless no-op notify)
    v.finish_all();
  }
  // tenants may not touch the guest's namespace, and the guest path may not touch theirs
  sfs_cqe_t cq; int r = sfs_read_sync(&v.tq[0], VNS, 0, 1, tb[0].iova, 0, &cq);
  CHECK(r == SFS_E_STATUS && (cq.status == SFS_ST_INVALID_NS || cq.status == SFS_ST_TENANT_MISMATCH), "tenant 0 reaching namespace %u: status %u", VNS, cq.status);
  r = sfs_write_sync(&v.tq[1], VNS, 0, 1, tb[1].iova, nullptr, 0, &cq);
  CHECK(r == SFS_E_STATUS && (cq.status == SFS_ST_INVALID_NS || cq.status == SFS_ST_TENANT_MISMATCH), "tenant 1 writing namespace %u: status %u", VNS, cq.status);
  unsigned bad = 0;
  for (unsigned t = 0; t < 2; t++) for (uint64_t b = 0; b < 256; b++) {
    bool nz = false; for (int i = 0; i < 512; i++) if (tref[t][b * 512 + i]) { nz = true; break; }
    if (nz) { uint64_t lba = t * 256 + b; bool ok = true; for (unsigned w = 0; w < 64; w++) { uint64_t e; memcpy(&e, &tref[t][b * 512 + 8 * w], 8); if (v.dbg_word(lba, w) != e) ok = false; } if (!ok) bad++; }
  }
  CHECK(bad == 0, "%u native-tenant blocks differ from the tenants' own reference after concurrent guest traffic", bad);
  for (unsigned t = 0; t < 2; t++) sfs_queue_destroy(&v.tq[t]);
}

static void report(VT &v) {
  auto p = [&](uint32_t off) { return sfv_hv_perf32(&v.mt, off); };
  printf("  engine counters: desc %u  req %u  rd_bytes %llu  wr_bytes %llu  ioerr %u  unsupp %u  fatal %u  viol %u  stall %u\n", p(SFV_PERF_DESC), p(SFV_PERF_REQ),
         (unsigned long long)sfv_hv_perf64(&v.mt, SFV_PERF_RD_BYTES), (unsigned long long)sfv_hv_perf64(&v.mt, SFV_PERF_WR_BYTES), p(SFV_PERF_IOERR), p(SFV_PERF_UNSUPP),
         p(SFV_PERF_FATAL), p(SFV_PERF_VIOL), p(SFV_PERF_STALL));
  printf("  adapter: sector loads %u  stores %u  flushes %u  errors %u;  guest DMA beats rd %llu wr %llu;  cycles %llu\n", v.h.d->v_ad_loads, v.h.d->v_ad_stores,
         v.h.d->v_ad_flushes, v.h.d->v_ad_errors, (unsigned long long)v.dma_rd, (unsigned long long)v.dma_wr, (unsigned long long)v.h.cycles);
}

int main(int argc, char **argv) {
  Harness::set_args(argc, argv);
  std::string which = argc > 1 ? argv[1] : "all";
  uint64_t seed = argc > 2 ? strtoull(argv[2], nullptr, 0) : 1;
  int n = argc > 3 ? atoi(argv[3]) : 300;
  int rc = 0;
  struct T { const char *name; std::function<void(VT &)> f; };
  std::vector<T> tests = {
    {"basic", t_basic}, {"fill", t_fill}, {"random", [n](VT &v) { t_random(v, n); }}, {"invalid", t_invalid}, {"window", t_window},
    {"faults", t_faults}, {"durability", t_durability}, {"concurrent", [n](VT &v) { t_concurrent(v, std::max(4, n / 20)); }},
  };
  int ran = 0;
  for (auto &t : tests) {
    if (which != "all" && which != t.name) continue;
    ran++;
    uint64_t c0 = g_checks, f0 = g_fails;
    std::unique_ptr<VT> v(new VT(seed));
    v->bp = (int)(seed % 4) * 15; v->lat_max = 1 + (int)(seed % 5);
    memset(&v->gm[VICTIM], 0xEE, VICTIM_END - VICTIM + 1);
    v->power_on();
    t.f(*v);
    if (std::string(t.name) == "concurrent") t_isolation(*v, 0, 512); else t_isolation(*v);
    if (g_fails == f0) printf("[%s] PASS (%llu checks)\n", t.name, (unsigned long long)(g_checks - c0));
    else { printf("[%s] FAIL (%llu failures)\n", t.name, (unsigned long long)(g_fails - f0)); rc = 1; }
    if (getenv("VT_REPORT")) report(*v);
  }
  if (!ran) { printf("unknown test %s\n", which.c_str()); return 2; }
  printf("VIRTIO SUITE %s: %llu checks, %llu failures\n", rc ? "FAIL" : "PASS", (unsigned long long)g_checks, (unsigned long long)g_fails);
  return rc;
}
