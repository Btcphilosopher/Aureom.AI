// SilicaFlux-STORE integration smoke test: boot the P60 chip (real firmware on its RISC-V ControlCore) behind the fabric's STORE
// adapter, then run block I/O through the full fabric pipeline.
#define SFS_TOP_CLASS Vtb_fabric_store_top
#define SFS_TOP_HEADER "Vtb_fabric_store_top.h"
#define SFS_NO_XBE
#define SFS_STORE_TOP
#define SFS_TIMING
#include "sfs_harness.hpp"
using namespace sfsim;
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf("FAIL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

static uint32_t store_bar(Harness &h, bool wr, uint32_t a, uint32_t wd = 0) {
  h.d->store_mg_req_valid = 1; h.d->store_mg_req_write = wr; h.d->store_mg_req_addr = a; h.d->store_mg_req_wdata = wd;
  int g = 0;
  h.d->eval();
  while (!h.d->store_mg_req_ready && g++ < 2000000) h.step();
  h.step(); h.d->store_mg_req_valid = 0;
  g = 0; while (!h.d->store_mg_rsp_valid && g++ < 2000000) h.step();
  uint32_t r = h.d->store_mg_rsp_rdata;
  h.step();
  return r;
}
static void store_boot(Harness &h, const char *fw) {
  h.d->store_por_n = 1; h.run(20);
  uint32_t v = 0; int tries = 0;
  do { v = store_bar(h, false, 0x40000030); } while (v != 3 && tries++ < 200000);
  FILE *f = fopen(fw, "r"); std::vector<uint32_t> img; unsigned w; while (fscanf(f, "%x\n", &w) == 1) img.push_back(w); fclose(f);
  for (size_t i = 0; i < img.size(); i++) store_bar(h, true, 0x00010000 + 4 * i, img[i]);
  store_bar(h, true, 0x40005004, 0); store_bar(h, true, 0x40005000, 1); store_bar(h, true, 0x40005044, 1);
  uint64_t t0 = h.cycles;
  while (!h.d->store_mgmt_irq && h.cycles - t0 < 3000000) h.step();
  for (int i = 0; i < 8; i++) store_bar(h, false, 0x40005020 + 4 * i);
  store_bar(h, true, 0x40005050, 0);
  t0 = h.cycles;
  while (!h.d->store_host_ready && h.cycles - t0 < 60000000) h.step();
  printf("STORE chip host_ready=%d after %llu cycles\n", h.d->store_host_ready, (unsigned long long)(h.cycles - t0));
  for (int i = 0; i < 4000; i++) h.step();
  // consume the boot-complete mailbox message
  if (h.d->store_mgmt_irq) { for (int i = 0; i < 8; i++) store_bar(h, false, 0x40005020 + 4 * i); store_bar(h, true, 0x40005050, 0); }
}

int main(int argc, char **argv) {
  Harness::set_args(argc, argv);
  const char *fw = argc > 1 ? argv[1] : "third_party/p60-store/fw/prebuilt/p60_fw.hex";
  Harness h;
  h.reset();
  store_boot(h, fw);
  // wait for the adapter to enable the chip and publish its capacity
  uint64_t t0 = h.cycles;
  while (!(h.m_read(0x14) & 1) && h.cycles - t0 < 200000) h.run(100);
  printf("adapter state=%u cmds=%u after %llu cycles of waiting\n", h.d->store_ad_state, h.d->store_ad_cmds, (unsigned long long)(h.cycles - t0));
  uint32_t capl = h.m_read(0x608);
  printf("fabric sees backend: type=%u caps=%02x capacity=%u blocks (GSTATUS=%08x)\n", h.m_read(0x600), h.m_read(0x604), capl, h.m_read(0x14));
  CHECK((h.m_read(0x14) & 1) && capl > 0, "backend not ready");
  h.add_window(0, 0x10000, 0x100000);
  uint32_t nsst = h.ns_config(0, 0, 0, capl > 700 ? 700 : capl, false, false, false);
  CHECK((nsst & 1) == 1, "namespace refused: %02x", nsst);
  uint32_t pst = h.ns_config(1, 1, 0, 10, false, false, true);           // PI on a non-PI backend must be refused
  CHECK((pst & 4) != 0, "PI namespace on a non-PI-native backend was not refused (%02x)", pst);
  h.tenant_cfg(0, true);
  h.m_write(0x10, 1 | 4);
  const uint64_t SQ = 0x10000, CQ = 0x11000, BUF = 0x20000, RB = 0x30000;
  h.t_write(0, 0x20, (uint32_t)SQ); h.t_write(0, 0x24, 0); h.t_write(0, 0x28, 16);
  h.t_write(0, 0x30, (uint32_t)CQ); h.t_write(0, 0x34, 0); h.t_write(0, 0x38, 16);
  h.t_write(0, 0x10, 1);
  int sqt = 0, cqh = 0; uint32_t phase = 1;
  auto submit = [&](uint32_t op, uint32_t flags, uint32_t txn, uint64_t lba, uint32_t nblk, uint64_t addr, uint32_t *cqe, uint64_t budget = 40000000) {
    uint32_t w[16] = {0};
    w[0] = 1 | (op << 8) | (flags << 16); w[1] = txn | (0 << 16);
    w[2] = (uint32_t)lba; w[3] = (uint32_t)(lba >> 32); w[4] = (op == 1 || op == 2 || op == 5) ? nblk : 0; w[5] = (op == 1 || op == 2) ? nblk * 512 : 0;
    w[6] = (uint32_t)addr; w[7] = (uint32_t)(addr >> 32);
    memcpy(&h.mem[SQ + sqt * 64], w, 64);
    sqt = (sqt + 1) % 16;
    h.t_write(0, 0x40, sqt);
    uint64_t c0 = h.cycles;
    for (;;) {
      uint32_t ph; memcpy(&ph, &h.mem[CQ + cqh * 32 + 28], 4);
      if ((ph & 1) == phase) { memcpy(cqe, &h.mem[CQ + cqh * 32], 32); break; }
      h.step();
      if (h.cycles - c0 > budget) { cqe[0] = 0xDEAD; return (uint64_t)0; }
    }
    cqh = (cqh + 1) % 16; if (cqh == 0) phase ^= 1;
    h.t_write(0, 0x44, cqh);
    return h.cycles - c0;
  };
  uint32_t cqe[8];
  {   // never-written blocks read as zeros (P60 contract; the adapter also zero-fills its bounce RAM before every READ)
    for (int lb : {0, 5, 100, 259, 300}) {
      for (int i = 0; i < 512; i++) h.mem[RB + i] = 0x77;
      submit(2, 0, 0x40 + lb % 50, lb, 1, RB, cqe);
      int nz = 0; for (int i = 0; i < 512; i++) if (h.mem[RB + i] != 0) nz++;
      CHECK(((cqe[0] >> 16) & 0xFF) == 0 && nz == 0, "never-written block %d: status %02x, %d non-zero bytes", lb, (cqe[0] >> 16) & 0xFF, nz);
    }
  }
  for (int b = 0; b < 4; b++) for (int i = 0; i < 512; i++) h.mem[BUF + b * 512 + i] = (uint8_t)(i * 13 + b * 5 + 1);
  uint64_t lat = submit(1, 0, 0x21, 10, 4, BUF, cqe);
  printf("WRITE 4 blocks via STORE: status=%02x detail=%02x durable=%u nblk_done=%u cycles=%llu\n", (cqe[0] >> 16) & 0xFF, cqe[0] >> 24, cqe[1] & 1, cqe[1] >> 16, (unsigned long long)lat);
  CHECK(((cqe[0] >> 16) & 0xFF) == 0, "write status");
  CHECK((cqe[1] & 1) == 1, "write durable flag (chip has no volatile write cache)");
  lat = submit(2, 0, 0x22, 10, 4, RB, cqe);
  printf("READ  4 blocks via STORE: status=%02x detail=%02x cycles=%llu\n", (cqe[0] >> 16) & 0xFF, cqe[0] >> 24, (unsigned long long)lat);
  CHECK(((cqe[0] >> 16) & 0xFF) == 0, "read status");
  CHECK(memcmp(&h.mem[BUF], &h.mem[RB], 2048) == 0, "read data differs from written data");
  lat = submit(3, 0, 0x23, 0, 0, 0, cqe);
  printf("FLUSH via STORE: status=%02x durable=%u cycles=%llu\n", (cqe[0] >> 16) & 0xFF, cqe[1] & 1, (unsigned long long)lat);
  CHECK(((cqe[0] >> 16) & 0xFF) == 0 && (cqe[1] & 1), "flush");
  lat = submit(5, 0, 0x24, 11, 2, 0, cqe);
  printf("DISCARD via STORE: status=%02x cycles=%llu\n", (cqe[0] >> 16) & 0xFF, (unsigned long long)lat);
  lat = submit(2, 0, 0x25, 10, 4, RB, cqe);
  bool z1 = true, z2 = true;
  for (int i = 0; i < 512; i++) { if (h.mem[RB + i] != h.mem[BUF + i]) z1 = false; }     // block 10 still there
  for (int i = 512; i < 2048; i++) if (h.mem[RB + i] != 0) z2 = false;                      // blocks 11..13: 11,12 discarded -> zero, 13 untouched
  printf("after DISCARD(11,2): block10 intact=%d, status=%02x\n", z1, (cqe[0] >> 16) & 0xFF);
  CHECK(z1, "block 10 changed by discard of 11..12");
  bool z12 = true; for (int i = 512; i < 1536; i++) if (h.mem[RB + i] != 0) z12 = false;
  CHECK(z12, "discarded blocks do not read as zeros");
  {   // DISCARD of a never-written range keeps reading zeros
    for (int i = 0; i < 4096; i++) h.mem[RB + i] = 0x77;
    submit(5, 0, 0x31, 300, 4, 0, cqe);
    submit(2, 0, 0x32, 300, 4, RB, cqe);
    int nz = 0; for (int i = 0; i < 2048; i++) if (h.mem[RB + i] != 0) nz++;
    CHECK(((cqe[0] >> 16) & 0xFF) == 0 && nz == 0, "never-written range after DISCARD: %d non-zero bytes", nz);
  }
  CHECK(h.st.violations == 0, "bus violations %s", h.last_violation.c_str());
  printf(fails ? "STORE SMOKE FAIL (%d)\n" : "STORE SMOKE PASS\n", fails);
  return fails ? 1 : 0;
}
