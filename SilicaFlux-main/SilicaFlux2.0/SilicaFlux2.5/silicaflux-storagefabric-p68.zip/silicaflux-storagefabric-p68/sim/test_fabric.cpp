// =============================================================================
// StorageFabric verification suite.  Usage: test_fabric <test|all> [seed] [ncmd]
// Every command goes through the independent C host library, the Verilated DUT and is checked against the independent
// C++ reference model (validation verdict, completion fields, read data, durability).  The AXI bus monitor checks that no
// DMA beat ever leaves the domain's windows.
// =============================================================================
#include "tb_env.hpp"
#include <functional>
#include <openssl/evp.h>
using namespace sfsim;

static Tb *g_tb;
static int run_test(const char *name, uint64_t seed, int ncmd, const std::function<void(Tb &, uint64_t, int)> &fn) {
  Tb *tb = new Tb(seed);
  g_tb = tb;
  tb->verbose = getenv("TB_VERBOSE") != nullptr;
  printf("[%s] seed=%llu\n", name, (unsigned long long)seed);
  fn(*tb, seed, ncmd);
  TB_CHECK(*tb, tb->h.st.violations == 0, "bus-isolation monitor: %llu violations (%s)", (unsigned long long)tb->h.st.violations, tb->h.last_violation.c_str());
  for (auto &v : tb->model->violations()) TB_CHECK(*tb, false, "model: %s", v.c_str());
  printf("[%s] %s: %llu checks, %llu failures, %llu commands completed (%llu with error), %llu cycles\n", name, tb->st.fails ? "FAIL" : "PASS",
         (unsigned long long)tb->st.checks, (unsigned long long)tb->st.fails, (unsigned long long)tb->completed, (unsigned long long)tb->errors,
         (unsigned long long)tb->h.cycles);
  int f = tb->st.fails ? 1 : 0;
  delete tb;
  return f;
}

// ---------------------------------------------------------------------------------------------------------------------
// basic: reads, writes, overwrites, flush, capacity, discard on every tenant, one command at a time, exact data checks
// ---------------------------------------------------------------------------------------------------------------------
static void t_basic(Tb &tb, uint64_t seed, int) {
  tb.power_on(); tb.configure(true, false, 256); tb.open_all();
  std::mt19937_64 r(seed);
  for (unsigned t = 0; t < Tb::NT; t++) {
    uint64_t buf = tb.alloc(t, 8192);
    uint64_t cap = 0; sfs_cqe_t cq;
    int rc = sfs_capacity_sync(&tb.q[t], t, &cap, &cq);
    TB_CHECK(tb, rc == 0 && cap == tb.ns_blocks, "GET_CAPACITY tenant %u: rc=%d cap=%llu", t, rc, (unsigned long long)cap);
    for (int rep = 0; rep < 3; rep++) {                       // write, read, overwrite, read
      uint64_t lba = r() % (tb.ns_blocks - 8);
      uint32_t n = 1 + (uint32_t)(r() % 8);
      Cmd w; w.tenant = t; w.payload.resize(n * 512);
      for (auto &b : w.payload) b = (uint8_t)r();
      Tb::build(w.w, 1, 0, (uint16_t)(0x100 + rep * 4), t, lba, n, buf, t);
      tb.issue_wait(w); tb.ring_all(); tb.drain();
      Cmd rd; rd.tenant = t;
      Tb::build(rd.w, 2, 0, (uint16_t)(0x101 + rep * 4), t, lba, n, buf + 4096, t);
      tb.issue_wait(rd); tb.ring_all(); tb.drain();
      Cmd w2; w2.tenant = t; w2.payload.resize(n * 512);
      for (auto &b : w2.payload) b = (uint8_t)r();
      Tb::build(w2.w, 1, 0, (uint16_t)(0x102 + rep * 4), t, lba, n, buf, t);
      tb.issue_wait(w2); tb.ring_all(); tb.drain();
      Cmd rd2; rd2.tenant = t;
      Tb::build(rd2.w, 2, 0, (uint16_t)(0x103 + rep * 4), t, lba, n, buf + 4096, t);
      tb.issue_wait(rd2); tb.ring_all(); tb.drain();
    }
    Cmd f; f.tenant = t; Tb::build(f.w, 3, 0, 0x200, t, 0, 0, 0, t); tb.issue_wait(f); tb.ring_all(); tb.drain();
    Cmd d; d.tenant = t; Tb::build(d.w, 5, 0, 0x201, t, 4, 3, 0, t); tb.issue_wait(d); tb.ring_all(); tb.drain();
    Cmd rd; rd.tenant = t; Tb::build(rd.w, 2, 0, 0x202, t, 2, 8, buf + 4096, t); tb.issue_wait(rd); tb.ring_all(); tb.drain();
  }
  tb.verify_all();
  // per-tenant counters vs model
  for (unsigned t = 0; t < Tb::NT; t++) {
    sfs_perf_t p; sfs_perf_read(&tb.dev[t], &p);
    const auto &c = tb.model->counters(t);
    TB_CHECK(tb, p.done == c.done + 1 && p.err == c.err && p.rd_blk == c.rd_blk && p.wr_blk == c.wr_blk && p.flush == c.flush,
             "tenant %u counters rtl{done=%u err=%u rd=%u wr=%u fl=%u} model{done=%u err=%u rd=%u wr=%u fl=%u}", t, p.done, p.err, p.rd_blk, p.wr_blk,
             p.flush, c.done, c.err, c.rd_blk, c.wr_blk, c.flush);
  }
}

// ---------------------------------------------------------------------------------------------------------------------
// random: mixed valid and invalid traffic from all tenants, queue depth up to 24, random bus back-pressure, hot LBAs for overlaps
// ---------------------------------------------------------------------------------------------------------------------
static void t_random(Tb &tb, uint64_t seed, int ncmd) {
  tb.power_on(); tb.configure(true, false, 128); tb.open_all();
  tb.h.p_ready = 70; tb.h.p_valid = 80; tb.h.mem_lat = 6;
  sfref::GenOpts go; go.p_invalid_pct = 15; go.hot_lbas = 24; go.p_bad_hcrc_pct = 10;
  sfref::Gen gen(*tb.model, seed, go);
  std::vector<uint64_t> bufs[Tb::NT];
  std::vector<char> bbusy[Tb::NT];
  std::map<std::pair<unsigned, uint16_t>, int> bidx;
  for (unsigned t = 0; t < Tb::NT; t++) { for (int i = 0; i < 24; i++) bufs[t].push_back(tb.alloc(t, 8192 + 64, 64)); bbusy[t].assign(24, 0); }
  tb.on_done = [&](unsigned t, uint16_t txn) { auto it = bidx.find({t, txn}); if (it != bidx.end()) { bbusy[t][it->second] = 0; bidx.erase(it); } };
  std::mt19937_64 r(seed ^ 0x5555);
  int issued = 0;
  while (issued < ncmd) {
    unsigned t = r() % Tb::NT;
    sfref::GenCmd g = gen.next(t);
    if (!g.valid_cmd) continue;
    Cmd c; c.tenant = t; memcpy(c.w, g.w, 64); c.payload = g.payload; c.fault = g.fault;
    sfref::Desc d = sfref::decode(c.w);
    c.w[1] = (c.w[1] & ~0xFFFFu) | (uint16_t)(1 + (issued % 60000));     // unique txn
    int bi = -1;
    if (g.expect.ok || g.fault == sfref::F_NONE) {
      if (d.opcode == 1 || d.opcode == 2) {      // exclusive in-window buffer for this command (random 4-byte alignment)
        uint64_t guard = tb.h.cycles;
        for (;;) {
          bi = (int)(r() % bufs[t].size());
          if (!bbusy[t][bi]) break;
          bool any = false; for (char f : bbusy[t]) if (!f) any = true;
          if (!any) { tb.ring_all(); tb.poll_all(); tb.h.run(16); }
          if (tb.h.cycles - guard > 5000000) { TB_CHECK(tb, false, "no free buffer"); return; }
        }
        bbusy[t][bi] = 1;
        uint64_t b = bufs[t][bi] + 4 * (r() % 16);
        c.w[6] = (uint32_t)b; c.w[7] = (uint32_t)(b >> 32);
      }
    }
    if (bi >= 0) bidx[{t, (uint16_t)(c.w[1] & 0xFFFF)}] = bi;
    tb.issue_wait(c);
    issued++;
    if (r() % 3 == 0) tb.ring_all();
    if (r() % 5 == 0) { tb.poll_all(); }
    // never reuse a buffer that is still in flight: keep depth moderate
    if (tb.inflight.size() > 40) { tb.ring_all(); while (tb.inflight.size() > 12) { tb.poll_all(); tb.h.run(16); } }
  }
  tb.ring_all(); tb.drain();
  tb.verify_all();
}


// ---------------------------------------------------------------------------------------------------------------------
// helpers shared by the directed tests
// ---------------------------------------------------------------------------------------------------------------------
static std::vector<uint8_t> pat(std::mt19937_64 &r, size_t n) { std::vector<uint8_t> v(n); for (auto &b : v) b = (uint8_t)r(); return v; }
static Cmd wr_cmd(unsigned t, uint16_t txn, unsigned ns, uint64_t lba, uint32_t nblk, uint64_t buf, std::vector<uint8_t> data, uint16_t flags = 0) {
  Cmd c; c.tenant = t; c.payload = std::move(data); Tb::build(c.w, 1, flags, txn, ns, lba, nblk, buf, t); return c;
}
static Cmd rd_cmd(unsigned t, uint16_t txn, unsigned ns, uint64_t lba, uint32_t nblk, uint64_t buf, uint16_t flags = 0) {
  Cmd c; c.tenant = t; Tb::build(c.w, 2, flags, txn, ns, lba, nblk, buf, t); return c;
}
static Cmd op_cmd(unsigned t, uint8_t op, uint16_t txn, unsigned ns, uint64_t lba = 0, uint32_t nblk = 0) {
  Cmd c; c.tenant = t; Tb::build(c.w, op, 0, txn, ns, lba, nblk, 0, t); return c;
}

// ---------------------------------------------------------------------------------------------------------------------
// invalid: every validation rule, unaligned / invalid / out-of-bounds requests, stacked faults -- verdicts from the model
// ---------------------------------------------------------------------------------------------------------------------
static void t_invalid(Tb &tb, uint64_t seed, int) {
  tb.power_on(); tb.configure(true, false, 128, true); tb.open_all();
  sfref::GenOpts go; go.p_invalid_pct = 100; go.allow_ambiguous = false;
  sfref::Gen gen(*tb.model, seed, go);
  int txn = 1, n = 0;
  for (int rep = 0; rep < 6; rep++)
    for (int f = 0; f < sfref::F__COUNT; f++)
      for (unsigned t = 0; t < Tb::NT; t++) {
        sfref::GenCmd g = gen.invalid(t, sfref::Fault(f), rep & 1);
        if (!g.valid_cmd) continue;
        Cmd c; c.tenant = t; memcpy(c.w, g.w, 64); c.fault = f; c.w[1] = (c.w[1] & ~0xFFFFu) | (uint16_t)txn++;
        tb.issue_wait(c); n++;
        if (n % 5 == 0) { tb.ring_all(); tb.poll_all(); }
      }
  tb.ring_all(); tb.drain();
  printf("  %d invalid commands, all 26 rule classes\n", n);
  // boundary cases around the namespace end, with exact expectations
  for (unsigned t = 0; t < Tb::NT; t++) {
    uint64_t buf = tb.alloc(t, 8192), S = 128;
    struct B { uint64_t lba; uint32_t n; int exp; } cases[] = {{S - 1, 1, 0}, {S - 8, 8, 0}, {S - 7, 8, 0x04}, {S, 1, 0x04}, {S + 1, 1, 0x04}, {0, 9, 0x05}, {~0ull, 1, 0x04},
                                                              {~0ull - 3, 8, 0x04}, {0x8000000000000000ull, 1, 0x04}};
    for (auto &b : cases) {
      if (t == 3) continue;                                          // ns 3 is read-only in this configuration
      Cmd c = (b.n <= 8) ? rd_cmd(t, (uint16_t)txn++, t, b.lba, b.n, buf) : rd_cmd(t, (uint16_t)txn++, t, b.lba, b.n, buf);
      if (b.n == 9) c.w[5] = 9 * 512;
      sfs_cqe_t cq = tb.run_one(c);
      TB_CHECK(tb, cq.status == b.exp, "boundary read lba=%llx n=%u: status %02x expected %02x", (unsigned long long)b.lba, b.n, cq.status, b.exp);
    }
    // unaligned data address / length
    Cmd c = rd_cmd(t, (uint16_t)txn++, t, 0, 1, buf + 2);
    sfs_cqe_t cq = tb.run_one(c);
    TB_CHECK(tb, cq.status == 0x02 && cq.detail == 4, "unaligned buffer: status %02x detail %u", cq.status, cq.detail);
    c = rd_cmd(t, (uint16_t)txn++, t, 0, 1, buf); c.w[5] = 500;
    cq = tb.run_one(c);
    TB_CHECK(tb, cq.status == 0x05 && cq.detail == 3, "unaligned length: status %02x detail %u", cq.status, cq.detail);
  }
}

// ---------------------------------------------------------------------------------------------------------------------
// isolation: namespaces, claims, DMA windows (buffers, rings), tenant pages
// ---------------------------------------------------------------------------------------------------------------------
static void t_isolation(Tb &tb, uint64_t seed, int) {
  tb.power_on(); tb.configure(true, false, 128); tb.open_all();
  std::mt19937_64 r(seed);
  const uint64_t W1 = Tb::WIN_BASE + 1 * Tb::WIN_SIZE;
  // canaries in tenant 1 and tenant 2 memory (outside what tenant 0 owns)
  for (uint64_t a = W1 + 0x80000; a < W1 + 0x80000 + 0x4000; a++) tb.h.mem[a] = 0xC3;
  uint64_t buf0 = tb.alloc(0, 8192), buf1 = tb.alloc(1, 8192);
  // tenants write their own data
  std::vector<uint8_t> d0 = pat(r, 1024), d1 = pat(r, 1024);
  { Cmd c = wr_cmd(0, 1, 0, 0, 2, buf0, d0); tb.run_one(c); Cmd c1 = wr_cmd(1, 1, 1, 0, 2, buf1, d1); tb.run_one(c1); }
  uint64_t canary_before = 0; for (uint64_t a = W1 + 0x80000; a < W1 + 0x80000 + 0x4000; a++) canary_before += tb.h.mem[a];
  uint16_t txn = 100;
  // (a) another tenant's namespace -> INVALID_NS (indistinguishable from a non-existent one), no data moves
  for (unsigned ns = 0; ns < Tb::NS_N; ns++) {
    if (ns == 0) continue;
    Cmd c = rd_cmd(0, txn++, ns, 0, 1, buf0 + 4096); c.ov_status = 0x03; sfs_cqe_t cq = tb.run_one(c);
    TB_CHECK(tb, cq.status == 0x03, "tenant 0 read of ns %u: status %02x", ns, cq.status);
  }
  // (b) forged tenant claim
  { Cmd c = rd_cmd(0, txn++, 0, 0, 1, buf0 + 4096); c.w[8] = 1; c.ov_status = 0x06; sfs_cqe_t cq = tb.run_one(c);
    TB_CHECK(tb, cq.status == 0x06, "forged claim: status %02x", cq.status); }
  // (c) DMA buffer inside another tenant's window / straddling the window edge / unmapped: refused by the DMA protection checker
  struct Bad { uint64_t addr; const char *what; } bad[] = {{W1 + 0x80000, "foreign window"}, {W1 + 0x80100, "foreign window (unaligned)"},
                                                            {Tb::WIN_BASE + Tb::WIN_SIZE - 256, "straddles own window end"}, {0x10000, "below every window"},
                                                            {0x7fffffffe000ull, "far outside memory"}, {Tb::WIN_BASE - 16, "straddles own window start"}};
  for (auto &b : bad) {
    for (int op = 1; op <= 2; op++) {                            // WRITE (DMA read of the buffer) and READ (DMA write into it)
      Cmd c; c.tenant = 0; Tb::build(c.w, op, 0, txn++, 0, 0, 1, b.addr, 0);
      c.ov_status = 0x08; c.ov_detail = -1;
      // bypass the model: the command passes validation but must be stopped by the DMA checker and apply nothing
      sfs_cqe_t cq = tb.direct(0, c.w);
      TB_CHECK(tb, cq.status == 0x08, "%s (%s): status %02x detail %02x, expected DMA_FAULT", b.what, op == 1 ? "WRITE" : "READ", cq.status, cq.detail);
    }
  }
  uint64_t canary_after = 0; for (uint64_t a = W1 + 0x80000; a < W1 + 0x80000 + 0x4000; a++) canary_after += tb.h.mem[a];
  TB_CHECK(tb, canary_before == canary_after, "another tenant's memory was modified by a refused DMA");
  // tenant 0's data unchanged by the refused writes: read it back through the model
  { Cmd c = rd_cmd(0, txn++, 0, 0, 2, buf0 + 4096); tb.run_one(c); }
  // (d) ring bases inside another tenant's window: queue goes FATAL, nothing is read from / written to the foreign memory
  {
    sfs_queue_t qq; sfs_dev_t dd; sfs_dev_open(&dd, &tb.tp[0], 0);
    tb.h.t_write(0, 0x10, 0x2);                                   // RESET
    tb.h.run(20);
    tb.h.t_write(0, 0x20, (uint32_t)(W1 + 0x90000)); tb.h.t_write(0, 0x24, 0); tb.h.t_write(0, 0x28, 16);
    uint64_t cqa = tb.alloc(0, 1024); tb.h.t_write(0, 0x30, (uint32_t)cqa); tb.h.t_write(0, 0x34, 0); tb.h.t_write(0, 0x38, 16);
    tb.h.t_write(0, 0x10, 1);
    tb.h.t_write(0, 0x40, 1);                                     // doorbell: the fabric fetches a descriptor from the foreign window
    tb.h.run(4000);
    uint32_t stt = tb.h.t_read(0, 0x14);
    TB_CHECK(tb, (stt & 0x2) && (stt & 0x8), "SQ in foreign memory: STATUS=%08x (expected SQ_ERR and FATAL)", stt);
    tb.h.t_write(0, 0x10, 0x2); tb.h.run(20);
    // CQ in foreign memory
    uint64_t sqa = tb.alloc(0, 4096, 64);
    tb.h.t_write(0, 0x20, (uint32_t)sqa); tb.h.t_write(0, 0x28, 16);
    tb.h.t_write(0, 0x30, (uint32_t)(W1 + 0xA0000)); tb.h.t_write(0, 0x34, 0); tb.h.t_write(0, 0x38, 16);
    for (uint64_t a = W1 + 0xA0000; a < W1 + 0xA0000 + 512; a++) tb.h.mem[a] = 0x5A;
    tb.h.t_write(0, 0x10, 1);
    uint32_t w[16]; Tb::build(w, 3, 0, 0x77, 0, 0, 0, 0, 0); memcpy(&tb.h.mem[sqa], w, 64);
    tb.h.t_write(0, 0x40, 1);
    tb.h.run(6000);
    stt = tb.h.t_read(0, 0x14);
    bool untouched = true; for (uint64_t a = W1 + 0xA0000; a < W1 + 0xA0000 + 512; a++) if (tb.h.mem[a] != 0x5A) untouched = false;
    TB_CHECK(tb, (stt & 0x4) && (stt & 0x8), "CQ in foreign memory: STATUS=%08x (expected CQ_ERR and FATAL)", stt);
    TB_CHECK(tb, untouched, "completion entry was written into another tenant's memory");
    tb.h.t_write(0, 0x10, 0x2); tb.h.run(20);
    tb.qopen[0] = false; tb.open_queue(0);                        // recover: a clean queue works again
    Cmd c = rd_cmd(0, txn++, 0, 0, 2, buf0 + 4096); tb.run_one(c);
  }
  // (e) the page of tenant 1 does not let tenant 0 reach queue 0 or the other way round: register state is per function
  { uint32_t a = tb.h.t_read(1, 0x20); tb.h.t_write(1, 0x20, 0xdead0000); uint32_t b = tb.h.t_read(0, 0x20);
    TB_CHECK(tb, b != 0xdead0000, "tenant page 1 write visible in tenant page 0"); tb.h.t_write(1, 0x20, a); }
  // (f) isolated namespaces: tenant 1's data is intact and tenant 0 cannot read it by LBA arithmetic
  { Cmd c = rd_cmd(0, txn++, 0, 128, 1, buf0 + 4096); sfs_cqe_t cq = tb.direct(0, c.w); TB_CHECK(tb, cq.status == 0x04, "LBA past the namespace end reached the neighbour (status %02x)", cq.status); }
  tb.verify_all();
  TB_CHECK(tb, tb.h.st.violations == 0, "bus monitor reported %llu isolation violations", (unsigned long long)tb.h.st.violations);
}

// ---------------------------------------------------------------------------------------------------------------------
// durability: volatile vs durable completions, FLUSH, FUA, power loss with a volatile write cache, recovery
// ---------------------------------------------------------------------------------------------------------------------
static void t_durability(Tb &tb, uint64_t seed, int ncmd) {
  tb.power_on(); tb.configure(true, false, 64); tb.open_all();
  std::mt19937_64 r(seed);
  uint64_t buf = tb.alloc(0, 16384);
  uint16_t txn = 1;
  // plain write is volatile, FLUSH makes it durable, FUA write is durable at completion
  { Cmd w = wr_cmd(0, txn++, 0, 5, 1, buf, pat(r, 512)); sfs_cqe_t cq = tb.run_one(w);
    TB_CHECK(tb, cq.status == 0 && cq.durable == 0, "plain write on a volatile-cache backend reported durable=%d", cq.durable);
    Cmd f = op_cmd(0, 3, txn++, 0); cq = tb.run_one(f);
    TB_CHECK(tb, cq.status == 0 && cq.durable == 1, "FLUSH: status %02x durable=%d", cq.status, cq.durable);
    Cmd w2 = wr_cmd(0, txn++, 0, 6, 2, buf, pat(r, 1024), 1); cq = tb.run_one(w2);
    TB_CHECK(tb, cq.status == 0 && cq.durable == 1, "FUA write: status %02x durable=%d", cq.status, cq.durable); }
  // power-loss campaign: random traffic with writes in flight at the instant of power loss; the device persists a random subset of
  // its unflushed history; after recovery every acknowledged-durable block must be exact and every other block must hold a version
  // that was actually written to it (model: check_read_after_loss)
  const int rounds = 6;
  for (int round = 0; round < rounds; round++) {
    sfref::GenOpts go; go.p_invalid_pct = 0; go.hot_lbas = 24; go.p_bad_hcrc_pct = 0;
    sfref::Gen gen(*tb.model, seed * 31 + round, go);
    std::vector<uint64_t> bufs[Tb::NT]; std::vector<char> bb[Tb::NT];
    for (unsigned t = 0; t < Tb::NT; t++) { for (int i = 0; i < 16; i++) bufs[t].push_back(tb.alloc(t, 8192 + 64, 64)); bb[t].assign(16, 0); }
    std::map<std::pair<unsigned, uint16_t>, int> bidx;
    tb.on_done = [&](unsigned t, uint16_t x) { auto it = bidx.find({t, x}); if (it != bidx.end()) { bb[t][it->second] = 0; bidx.erase(it); } };
    int n = ncmd / rounds, issued = 0;
    while (issued < n) {
      unsigned t = r() % Tb::NT;
      sfref::GenCmd g = gen.valid(t);
      if (!g.valid_cmd) continue;
      Cmd c; c.tenant = t; memcpy(c.w, g.w, 64); c.payload = g.payload;
      sfref::Desc d = sfref::decode(c.w);
      c.w[1] = (c.w[1] & ~0xFFFFu) | (uint16_t)(1 + (round * 5000 + issued));
      int bi = -1;
      if (d.opcode == 1 || d.opcode == 2) {
        int tries = 0; do { bi = (int)(r() % bufs[t].size()); if (++tries > 200) { tb.ring_all(); tb.poll_all(); tb.h.run(16); tries = 0; } } while (bb[t][bi]);
        bb[t][bi] = 1; uint64_t b = bufs[t][bi] + 4 * (r() % 8); c.w[6] = (uint32_t)b; c.w[7] = (uint32_t)(b >> 32);
        bidx[{t, (uint16_t)(c.w[1] & 0xFFFF)}] = bi;
      }
      tb.issue_wait(c); issued++;
      if (r() % 3 == 0) tb.ring_all();
      if (r() % 4 == 0) tb.poll_all();
    }
    tb.ring_all();
    // let a random part of the traffic complete, then cut power with commands still in flight
    uint64_t t0 = tb.h.cycles; uint64_t cut = 300 + r() % 3000;
    while (tb.h.cycles - t0 < cut) { tb.poll_all(); tb.h.run(8); }
    tb.poll_all();
    int lost = 0;
    for (auto &kv : tb.inflight) {
      sfref::Desc d = sfref::decode(kv.second.w);
      if (kv.second.out.executed && (d.opcode == 1 || d.opcode == 5)) { tb.model->on_write_failed(kv.second.out.wid, 0); }
      lost++;
    }
    printf("  round %d: power cut with %d commands in flight, %u unflushed device cache entries\n", round, lost, tb.h.d->sim_dirty);
    tb.inflight.clear();
    tb.on_done = nullptr;
    tb.model->power_loss();
    tb.power_cycle(true, false);
    tb.open_all();
    tb.verify_all(true);
  }
}

// ---------------------------------------------------------------------------------------------------------------------
// backend failure, media error, hang + timeout, reset of the backend
// ---------------------------------------------------------------------------------------------------------------------
static void t_backend_fail(Tb &tb, uint64_t seed, int) {
  tb.power_on(); tb.configure(true, false, 64); tb.open_all();
  std::mt19937_64 r(seed);
  uint64_t buf = tb.alloc(0, 16384), buf1 = tb.alloc(1, 16384);
  uint16_t txn = 1;
  { Cmd w = wr_cmd(0, txn++, 0, 0, 8, buf, pat(r, 4096)); tb.run_one(w); }
  // device failure: every op fails with BACKEND_ERROR (detail = backend DEV_ERR), the host buffer is untouched, the fabric survives
  tb.h.d->sim_inj_fail = 1;
  { Cmd w = wr_cmd(0, txn++, 0, 8, 2, buf, pat(r, 1024)); w.ov_status = 0x0D; w.ov_detail = 2; tb.run_one(w);
    Cmd rd = rd_cmd(0, txn++, 0, 0, 2, buf + 8192); rd.ov_status = 0x0D; rd.ov_detail = 2; tb.run_one(rd);
    Cmd f = op_cmd(0, 3, txn++, 0); f.ov_status = 0x0D; tb.run_one(f);
    Cmd w1 = wr_cmd(1, 1, 1, 0, 1, buf1, pat(r, 512)); w1.ov_status = 0x0D; tb.run_one(w1); }
  tb.h.d->sim_inj_fail = 0;
  // media error on one block: MEDIA_ERROR, nblk_done = leading good blocks, the host buffer is not modified
  { Cmd w = wr_cmd(0, txn++, 0, 16, 8, buf, pat(r, 4096)); tb.run_one(w);
    Cmd f = op_cmd(0, 3, txn++, 0); tb.run_one(f);
    tb.h.d->sim_inj_media_en = 1; tb.h.d->sim_inj_media_lba = 16 + 3;
    Cmd rd = rd_cmd(0, txn++, 0, 16, 8, buf + 8192); rd.ov_status = 0x0C; rd.ov_detail = 1;
    sfs_cqe_t cq = tb.run_one(rd);
    TB_CHECK(tb, cq.nblk_done == 3, "media error at block 3: nblk_done=%u", cq.nblk_done);
    tb.h.d->sim_inj_media_en = 0;
    Cmd rd2 = rd_cmd(0, txn++, 0, 16, 8, buf + 8192); tb.run_one(rd2); }          // the device is healthy again: exact data
  // hang + command timeout: the stuck command completes with TIMEOUT after the configured time, the backend is reset, other commands that
  // were waiting in the backend are aborted (or time out too), and the fabric recovers
  sfs_mgmt_set_cmd_timeout(&tb.mg, 3000);
  tb.h.d->sim_inj_hang = 1;
  {
    Cmd rd = rd_cmd(0, txn++, 0, 16, 2, buf + 8192); rd.ov_status = 0x0E; rd.ov_alt = 0x0F;      // whichever command's timer fires first gets TIMEOUT,
    Cmd rd1 = rd_cmd(1, txn++, 1, 0, 2, buf1 + 8192); rd1.ov_status = 0x0E; rd1.ov_alt = 0x0F;     // the other one TIMEOUT or ABORTED_RESET
    tb.issue_wait(rd); tb.issue_wait(rd1); tb.ring_all();
    uint64_t c0 = tb.h.cycles;
    while (!tb.inflight.empty() && tb.h.cycles - c0 < 60000) { tb.poll_all(); tb.h.run(50); }
    TB_CHECK(tb, tb.inflight.empty(), "timeout did not complete the stuck commands");
    TB_CHECK(tb, tb.h.cycles - c0 >= 3000, "TIMEOUT before the configured limit (%llu cycles)", (unsigned long long)(tb.h.cycles - c0));
    TB_CHECK(tb, tb.h.cycles - c0 < 6000, "TIMEOUT far too late (%llu cycles)", (unsigned long long)(tb.h.cycles - c0));
    bool one_to = false; for (auto &kv : tb.last_cqe) if (kv.second.status == 0x0E && kv.second.detail == 1) one_to = true;
    TB_CHECK(tb, one_to, "no command completed with TIMEOUT/backend");
  }
  tb.h.d->sim_inj_hang = 0; tb.h.run(1000);
  TB_CHECK(tb, tb.h.m_read(0x14) & 1, "backend not ready after the timeout recovery");
  sfs_mgmt_set_cmd_timeout(&tb.mg, 0);
  { Cmd rd = rd_cmd(0, txn++, 0, 16, 8, buf + 8192); tb.run_one(rd); Cmd w = wr_cmd(0, txn++, 0, 30, 3, buf, pat(r, 1536)); tb.run_one(w); }
  // explicit backend reset (BE_CTRL) with a slow request in flight: the command is aborted with ABORTED_RESET promptly
  {
    tb.h.d->sim_rd_lat = 2000; tb.h.d->sim_wr_lat = 2000;
    Cmd rd = rd_cmd(0, txn++, 0, 16, 2, buf + 8192); rd.ov_status = 0x0F; tb.issue_wait(rd); tb.ring_all(); tb.h.run(300);
    uint64_t c0 = tb.h.cycles;
    sfs_mgmt_backend_reset(&tb.mg);
    while (!tb.inflight.empty() && tb.h.cycles - c0 < 20000) { tb.poll_all(); tb.h.run(20); }
    TB_CHECK(tb, tb.inflight.empty(), "command stuck after BE_RESET");
    TB_CHECK(tb, tb.h.cycles - c0 < 1500, "BE_RESET took %llu cycles to abort the command", (unsigned long long)(tb.h.cycles - c0));
    tb.h.d->sim_rd_lat = 10; tb.h.d->sim_wr_lat = 10; tb.h.run(500);
    Cmd rd2 = rd_cmd(0, txn++, 0, 16, 8, buf + 8192); tb.run_one(rd2);
  }
  uint64_t v = 0; sfs_mgmt_perf_read(&tb.mg, 21, &v); TB_CHECK(tb, v >= 1, "TIMEOUT counter did not count (%llu)", (unsigned long long)v);
  uint64_t br = 0; sfs_mgmt_perf_read(&tb.mg, 31, &br); TB_CHECK(tb, br >= 2, "backend reset counter %llu", (unsigned long long)br);
  tb.verify_all();
}

// ---------------------------------------------------------------------------------------------------------------------
// corruption: stored data / trailer bit flips and misdirected reads are caught by the protection information
// ---------------------------------------------------------------------------------------------------------------------
static void t_corruption(Tb &tb, uint64_t seed, int) {
  tb.power_on(); tb.configure(true, false, 64); tb.open_all();
  std::mt19937_64 r(seed);
  uint64_t buf = tb.alloc(0, 16384);
  uint16_t txn = 1;
  std::vector<uint8_t> data = pat(r, 4096);
  { Cmd w = wr_cmd(0, txn++, 0, 8, 8, buf, data, 1); tb.run_one(w); }          // FUA: the data is on the medium, not in the cache
  struct F { int bit; int exp_detail; const char *what; } flips[] = {
      {5, 1, "data bit"}, {511 * 8 + 7, 1, "last data bit"}, {64 * 64 + 3, 1, "guard CRC bit"}, {64 * 64 + 34, 3, "NS tag (nsid) bit"},
      {64 * 64 + 41, 3, "NS tag (tenant) bit"}, {64 * 64 + 50, 2, "LBA tag bit"}, {65 * 64 + 2, 2, "LBA tag (high) bit"}, {65 * 64 + 33, 4, "trailer version"}};
  for (auto &f : flips) {
    uint64_t lba = 8 + (r() % 8);
    tb.h.d->sim_inj_corrupt_lba = lba; tb.h.d->sim_inj_corrupt_bit = f.bit; tb.h.d->sim_inj_corrupt = 1; tb.h.run(1); tb.h.d->sim_inj_corrupt = 0;
    Cmd rd = rd_cmd(0, txn++, 0, lba, 1, buf + 8192); rd.ov_status = 0x0B; rd.ov_detail = f.exp_detail;
    sfs_cqe_t cq = tb.run_one(rd);
    TB_CHECK(tb, cq.status == 0x0B && cq.detail == f.exp_detail, "%s: status %02x detail %u (expected INTEGRITY/%d)", f.what, cq.status, cq.detail, f.exp_detail);
    // restore the block by rewriting it
    Cmd w = wr_cmd(0, txn++, 0, lba, 1, buf, std::vector<uint8_t>(data.begin() + (lba - 8) * 512, data.begin() + (lba - 8) * 512 + 512), 1); tb.run_one(w);
  }
  // misdirected read (the device returns the neighbour block): the LBA tag catches it
  { tb.h.d->sim_inj_misdirect_en = 1; tb.h.d->sim_inj_misdirect_lba = 10;
    Cmd rd = rd_cmd(0, txn++, 0, 10, 1, buf + 8192); rd.ov_status = 0x0B; rd.ov_detail = 2; tb.run_one(rd);
    tb.h.d->sim_inj_misdirect_en = 0; }
  // multi-block read with one bad block in the middle: nblk_done = leading good blocks; no data reaches the host
  { tb.h.d->sim_inj_corrupt_lba = 12; tb.h.d->sim_inj_corrupt_bit = 700; tb.h.d->sim_inj_corrupt = 1; tb.h.run(1); tb.h.d->sim_inj_corrupt = 0;
    Cmd rd = rd_cmd(0, txn++, 0, 8, 8, buf + 8192); rd.ov_status = 0x0B; rd.ov_detail = 1; sfs_cqe_t cq = tb.run_one(rd);
    TB_CHECK(tb, cq.nblk_done == 4, "integrity failure at block 4: nblk_done=%u", cq.nblk_done);
    Cmd w = wr_cmd(0, txn++, 0, 12, 1, buf, std::vector<uint8_t>(data.begin() + 4 * 512, data.begin() + 5 * 512), 1); tb.run_one(w); }
  // the trailer is physically what the ABI says (independent of the RTL): guard = CRC-32C(data), NS tag, LBA tag, version
  { Cmd w = wr_cmd(0, txn++, 0, 20, 1, buf, std::vector<uint8_t>(data.begin(), data.begin() + 512), 1); tb.run_one(w);
    tb.h.d->sim_dbg_lba = 20;
    auto word = [&](int i) { tb.h.d->sim_dbg_word = i; tb.h.d->eval(); return tb.h.d->sim_dbg_data; };
    uint32_t guard = sfs_crc32c(data.data(), 512);
    uint64_t t0 = word(64), t1 = word(65);
    TB_CHECK(tb, (uint32_t)t0 == guard, "stored guard %08x, expected CRC-32C %08x", (uint32_t)t0, guard);
    TB_CHECK(tb, ((t0 >> 32) & 0xFFFF) == (0u | (0u << 8)), "stored NS tag %04llx", (unsigned long long)((t0 >> 32) & 0xFFFF));   // nsid 0, tenant 0
    uint64_t lba48 = ((t0 >> 48) & 0xFFFF) | ((t1 & 0xFFFFFFFFull) << 16);
    TB_CHECK(tb, lba48 == 20, "stored LBA tag %llu", (unsigned long long)lba48);
    TB_CHECK(tb, ((t1 >> 32) & 0xFF) == 1 && (t1 >> 40) == 0, "stored trailer version/reserved %016llx", (unsigned long long)t1);
    // tenant 2 / ns 2 trailer carries the tenant in bits 15:8 of the NS tag
    uint64_t b2 = tb.alloc(2, 4096);
    Cmd w2 = wr_cmd(2, txn++, 2, 3, 1, b2, pat(r, 512), 1); tb.run_one(w2);
    tb.h.d->sim_dbg_lba = 2 * 64 + 3; uint64_t u0 = word(64);
    TB_CHECK(tb, ((u0 >> 32) & 0xFFFF) == (2u | (2u << 8)), "tenant-2 NS tag %04llx expected 0202", (unsigned long long)((u0 >> 32) & 0xFFFF)); }
  tb.verify_all();
}

// ---------------------------------------------------------------------------------------------------------------------
// reset: queue reset, fabric soft reset, in-flight commands vanish without completions, everything works afterwards
// ---------------------------------------------------------------------------------------------------------------------
static void t_reset(Tb &tb, uint64_t seed, int) {
  tb.power_on(); tb.configure(true, false, 64); tb.open_all();
  std::mt19937_64 r(seed);
  uint64_t buf = tb.alloc(0, 65536);
  uint16_t txn = 1;
  tb.h.d->sim_wr_lat = 600; tb.h.d->sim_rd_lat = 600;
  // queue reset with commands in flight: no completions appear later
  for (int i = 0; i < 12; i++) { Cmd w = wr_cmd(0, txn++, 0, i * 2, 2, buf + i * 4096, pat(r, 1024)); tb.issue_wait(w); }
  tb.ring_all(); tb.h.run(400);
  tb.poll_all();
  for (auto &kv : tb.inflight) { sfref::Desc d = sfref::decode(kv.second.w); if (kv.second.out.executed && d.opcode == 1) tb.model->on_write_failed(kv.second.out.wid, 0); }
  tb.inflight.clear();
  sfs_queue_reset(&tb.q[0]);
  tb.h.run(20000);
  sfs_cqe_t cq; int stale = sfs_poll(&tb.q[0], &cq);
  TB_CHECK(tb, stale == 0, "completion appeared after queue reset (txn %04x)", cq.txn);
  tb.h.d->sim_wr_lat = 10; tb.h.d->sim_rd_lat = 10;
  { Cmd w = wr_cmd(0, txn++, 0, 40, 4, buf, pat(r, 2048)); tb.run_one(w); }
  // fabric soft reset with traffic from all tenants in flight
  tb.h.d->sim_wr_lat = 500; tb.h.d->sim_rd_lat = 500;
  for (unsigned t = 0; t < Tb::NT; t++) { uint64_t b = tb.alloc(t, 16384); for (int i = 0; i < 4; i++) { Cmd w = wr_cmd(t, 500 + i, t, i * 3, 2, b + i * 2048, pat(r, 1024)); tb.issue_wait(w); } }
  tb.ring_all(); tb.h.run(300);
  tb.poll_all();
  for (auto &kv : tb.inflight) { sfref::Desc d = sfref::decode(kv.second.w); if (kv.second.out.executed && d.opcode == 1) tb.model->on_write_failed(kv.second.out.wid, 0); }
  tb.inflight.clear();
  sfs_mgmt_soft_reset(&tb.mg);
  tb.h.run(30000);
  for (unsigned t = 0; t < Tb::NT; t++) { uint32_t stt = tb.h.t_read(t, 0x14); TB_CHECK(tb, (stt & 1) == 0, "queue %u still enabled after the fabric soft reset", t); tb.qopen[t] = false; }
  TB_CHECK(tb, (tb.h.m_read(0x14) & 1), "backend not ready after soft reset (GSTATUS %08x)", tb.h.m_read(0x14));
  tb.h.d->sim_wr_lat = 10; tb.h.d->sim_rd_lat = 10;
  tb.open_all();
  { Cmd w = wr_cmd(1, txn++, 1, 50, 4, tb.alloc(1, 8192), pat(r, 2048)); tb.run_one(w); }
  tb.verify_all();
}

// ---------------------------------------------------------------------------------------------------------------------
// fairness: weights, quotas, rate limit, non-draining tenant, one tenant cannot monopolise the shared queues
// ---------------------------------------------------------------------------------------------------------------------
struct Load { Tb &tb; unsigned t; uint64_t buf; int depth; unsigned n_done = 0; bool drain_cq = true; uint16_t txn = 1; uint64_t lba = 0; bool wr = false; };
static void t_fairness(Tb &tb, uint64_t seed, int) {
  tb.power_on(); tb.configure(true, false, 256); tb.open_all(32, 32);
  tb.h.d->sim_rd_lat = 40; tb.h.d->sim_wr_lat = 40; tb.h.d->sim_blk_lat = 4;
  std::mt19937_64 r(seed);
  // prefill each namespace so reads return mapped data
  for (unsigned t = 0; t < Tb::NT; t++) { uint64_t b = tb.alloc(t, 4096); for (uint64_t l = 0; l < 64; l += 8) { Cmd w = wr_cmd(t, (uint16_t)(0x4000 + l), t, l, 8, b, pat(r, 4096)); tb.run_one(w); } }
  auto measure = [&](const char *name, unsigned cycles, std::vector<unsigned> weight, std::vector<unsigned> maxinfl, std::vector<unsigned> rate, bool starve0, std::vector<double> &share, std::vector<uint64_t> &cnt) {
    for (unsigned t = 0; t < Tb::NT; t++) { sfs_tcfg_t tc{}; tc.enable_allowed = 1; tc.max_inflight = maxinfl[t]; tc.weight = weight[t]; tc.rate = rate[t]; tc.burst = 32; sfs_mgmt_tenant_cfg(&tb.mg, t, &tc); }
    uint64_t bufs[Tb::NT]; for (unsigned t = 0; t < Tb::NT; t++) bufs[t] = tb.alloc(t, 16 * 4096);
    cnt.assign(Tb::NT, 0); std::vector<int> infl(Tb::NT, 0); std::vector<uint16_t> txn(Tb::NT, 1);
    std::map<std::pair<unsigned, uint16_t>, int> pend;
    uint64_t c0 = tb.h.cycles;
    tb.on_done = nullptr;
    while (tb.h.cycles - c0 < cycles) {
      for (unsigned t = 0; t < Tb::NT; t++) {
        while (infl[t] < 24 && sfs_sq_space(&tb.q[t]) > 1) {
          uint32_t w[16]; Tb::build(w, 2, 0, txn[t], t, (txn[t] * 8) % 56, 8, bufs[t] + (txn[t] % 16) * 4096, t);
          // fairness load bypasses the model (read-only traffic on prefilled data; correctness is covered by the other tests)
          if (sfs_submit_raw(&tb.q[t], w)) break;
          txn[t]++; infl[t]++;
        }
        sfs_ring(&tb.q[t]);
      }
      tb.h.run(20);
      for (unsigned t = 0; t < Tb::NT; t++) {
        if (starve0 && t == 0) continue;                         // tenant 0 never consumes its completion queue
        sfs_cqe_t cq; while (sfs_poll(&tb.q[t], &cq) == 1) { infl[t]--; cnt[t]++; }
      }
    }
    uint64_t tot = 0; for (auto c : cnt) tot += c;
    share.assign(Tb::NT, 0); for (unsigned t = 0; t < Tb::NT; t++) share[t] = tot ? (double)cnt[t] / tot : 0;
    printf("  %-34s completed per tenant: %llu %llu %llu %llu  (shares %.2f %.2f %.2f %.2f)\n", name, (unsigned long long)cnt[0], (unsigned long long)cnt[1],
           (unsigned long long)cnt[2], (unsigned long long)cnt[3], share[0], share[1], share[2], share[3]);
    // drain what is left so the next phase starts clean
    for (unsigned t = 0; t < Tb::NT; t++) { sfs_queue_reset(&tb.q[t]); }
    tb.h.run(50000);
    for (unsigned t = 0; t < Tb::NT; t++) { tb.qopen[t] = false; tb.open_queue(t, 32, 32); }
  };
  std::vector<double> sh; std::vector<uint64_t> cn;
  measure("equal weights", 400000, {1, 1, 1, 1}, {0, 0, 0, 0}, {0, 0, 0, 0}, false, sh, cn);
  double lo = 1, hi = 0; for (double x : sh) { lo = std::min(lo, x); hi = std::max(hi, x); }
  double sum = 0, sq = 0; for (double x : sh) { sum += x; sq += x * x; } double jain = sum * sum / (4 * sq);
  TB_CHECK(tb, jain > 0.98, "Jain fairness index %.3f with equal weights", jain);
  measure("weights 4:2:1:1", 400000, {4, 2, 1, 1}, {0, 0, 0, 0}, {0, 0, 0, 0}, false, sh, cn);
  TB_CHECK(tb, sh[0] > sh[1] * 1.4 && sh[1] > sh[2] * 1.4, "weighted shares do not follow the weights (%.2f %.2f %.2f %.2f)", sh[0], sh[1], sh[2], sh[3]);
  measure("tenant 3 quota = 1 slot", 400000, {1, 1, 1, 1}, {0, 0, 0, 1}, {0, 0, 0, 0}, false, sh, cn);
  TB_CHECK(tb, sh[3] < sh[0] * 0.8, "quota of one slot did not reduce tenant 3's share (%.2f vs %.2f)", sh[3], sh[0]);
  measure("tenant 2 rate-limited (1 blk/1024cy)", 600000, {1, 1, 1, 1}, {0, 0, 0, 0}, {0, 0, 1, 0}, false, sh, cn);
  // 1 block per 1024 cycles = 586 blocks in 600000 cycles + a 32-block burst = ~77 reads of 8 blocks (the unthrottled tenants complete ~135)
  TB_CHECK(tb, cn[2] >= 55 && cn[2] <= 100, "rate-limited tenant completed %llu commands (expected ~77)", (unsigned long long)cn[2]);
  TB_CHECK(tb, cn[0] > cn[2] * 1.4, "the rate limit did not reduce the tenant's throughput relative to its peers");
  { sfs_perf_t pp; sfs_perf_read(&tb.dev[2], &pp); TB_CHECK(tb, pp.throttle > 100000, "CNT_THROTTLE for the rate-limited tenant = %u", pp.throttle); }
  measure("tenant 0 never drains its CQ", 600000, {1, 1, 1, 1}, {0, 0, 0, 0}, {0, 0, 0, 0}, true, sh, cn);
  TB_CHECK(tb, cn[1] >= 120 && cn[2] >= 120 && cn[3] >= 120, "a non-draining tenant starved the others (%llu %llu %llu)", (unsigned long long)cn[1], (unsigned long long)cn[2], (unsigned long long)cn[3]);
}

// ---------------------------------------------------------------------------------------------------------------------
// power-fail warning: admission stops, new commands wait, nothing is lost, normal operation resumes
// ---------------------------------------------------------------------------------------------------------------------
static void t_powerfail(Tb &tb, uint64_t seed, int) {
  tb.power_on(); tb.configure(true, false, 64); tb.open_all();
  std::mt19937_64 r(seed);
  uint64_t buf = tb.alloc(0, 65536);
  uint16_t txn = 1;
  { Cmd w = wr_cmd(0, txn++, 0, 0, 4, buf, pat(r, 2048), 1); tb.run_one(w); }
  tb.h.d->pf_warn_i = 1; tb.h.run(100);
  TB_CHECK(tb, tb.h.d->pf_quiesced_o, "fabric did not report the power-fail quiesce");
  Cmd w = wr_cmd(0, txn++, 0, 8, 2, buf + 4096, pat(r, 1024)); tb.issue_wait(w); tb.ring_all();
  tb.h.run(3000); tb.poll_all();
  TB_CHECK(tb, tb.inflight.size() == 1, "a command was admitted during the power-fail quiesce");
  tb.h.d->pf_warn_i = 0; tb.h.run(100);
  tb.drain();
  tb.verify_all();
}


// ---------------------------------------------------------------------------------------------------------------------
// nscfg: every namespace-configuration refusal reason, exact NS_STATUS bits (expectations written from docs/02 §9, not from the RTL);
// a refused namespace stays invalid; overlapping namespaces can never exist at the same time
// ---------------------------------------------------------------------------------------------------------------------
static void t_nscfg(Tb &tb, uint64_t seed, int) {
  tb.power_on(); tb.configure(true, false, 64); tb.open_all();
  (void)seed;
  uint64_t cap = tb.be_cap; uint16_t txn = 1;
  uint64_t buf = tb.alloc(1, 8192);
  bool xts = (tb.h.m_read(0x00C) >> 16) & 1;
  struct C { const char *what; unsigned nsid, owner; uint64_t base, size; bool enc; uint32_t exp; };
  std::vector<C> cases = {
    {"overlaps namespace 1 ([64,128))", 4, 1, 100, 10, false, SFS_NSS_OVERLAP},
    {"identical to namespace 1", 4, 1, 64, 64, false, SFS_NSS_OVERLAP},
    {"starts inside namespace 0, ends outside", 4, 1, 60, 20, false, SFS_NSS_OVERLAP},
    {"swallows namespace 2", 4, 1, 100, 400, false, SFS_NSS_OVERLAP},
    {"adjacent (no overlap) is fine", 4, 1, 256, 64, false, SFS_NSS_ACCEPTED},
    {"past the backend capacity", 5, 1, cap - 4, 10, false, SFS_NSS_NO_CAPACITY},
    {"base + size wraps 64 bits", 5, 1, ~0ull - 3, 10, false, SFS_NSS_NO_CAPACITY},
    {"zero size", 5, 1, 1000, 0, false, SFS_NSS_BAD_OWNER_SIZE},
    {"owner is not a tenant", 5, 9, 1000, 8, false, SFS_NSS_BAD_OWNER_SIZE},
    {"bad owner wins over bad capacity", 5, 9, cap - 4, 10, false, SFS_NSS_BAD_OWNER_SIZE},
    {"duplicate of namespace 4 (just accepted)", 6, 2, 256, 64, false, SFS_NSS_OVERLAP},
    {"valid, far from everything", 6, 2, 2000, 16, false, SFS_NSS_ACCEPTED},
  };
  if (!xts) cases.push_back({"ENC_EN without an XTS engine", 7, 3, 3000, 8, true, SFS_NSS_ENC_UNSUPPORTED});
  for (auto &c : cases) {
    sfs_ns_cfg_t nc{c.owner, c.base, c.size, 0, c.enc, 0, 0}; uint32_t nss = 0xFFFF;
    int r = sfs_mgmt_ns_config(&tb.mg, c.nsid, &nc, &nss);
    bool acc = c.exp == SFS_NSS_ACCEPTED;
    TB_CHECK(tb, (r == 0) == acc, "%s: accepted=%d expected %d", c.what, r == 0, acc);
    TB_CHECK(tb, nss == c.exp, "%s: NS_STATUS %02x, expected %02x", c.what, nss, c.exp);
    sfref::NsCfg mc; mc.owner = c.owner; mc.base = c.base; mc.size = c.size; mc.enc = c.enc; mc.pi = false; mc.readonly = false; mc.key_slot = 0;
    if (!c.enc) { sfref::NsStatus ms = tb.model->cfg_ns(c.nsid, mc); TB_CHECK(tb, ms.accepted == acc && (acc || ms.bits == c.exp), "%s: model verdict differs (accepted=%d bits %02x)", c.what, ms.accepted, ms.bits); }
  }
  // namespace 4 was accepted for tenant 1: usable; namespace 5 was refused every time: not usable (INVALID_NS)
  { Cmd w = wr_cmd(1, txn++, 4, 0, 2, buf, std::vector<uint8_t>(1024, 0x6B)); tb.run_one(w);
    Cmd rd = rd_cmd(1, txn++, 4, 0, 2, buf + 4096); tb.run_one(rd);
    Cmd bad = rd_cmd(1, txn++, 5, 0, 1, buf + 4096); bad.ov_status = 0x03; tb.run_one(bad); }
  // a valid namespace can be re-configured only by invalidating it first; invalidating frees its blocks for another namespace
  { sfs_ns_cfg_t nc{1, 256, 64, 0, 0, 0, 0}; uint32_t nss = 0;
    TB_CHECK(tb, sfs_mgmt_ns_config(&tb.mg, 6, &nc, &nss) != 0 && nss == SFS_NSS_OVERLAP, "namespace 6 overlapping namespace 4: %02x", nss);
    sfs_mgmt_ns_invalidate(&tb.mg, 4); tb.model->invalidate_ns(4);
    TB_CHECK(tb, sfs_mgmt_ns_config(&tb.mg, 6, &nc, &nss) == 0 && nss == SFS_NSS_ACCEPTED, "after invalidating namespace 4: %02x", nss); }
  tb.verify_all();
}

// ---------------------------------------------------------------------------------------------------------------------
// pfinflight: power-fail warning with a queue of commands waiting for a slow backend: commands that already reached the backend finish,
// commands that have not are aborted ABORTED_POWER (data not written) -- never silently dropped, never half-applied
// ---------------------------------------------------------------------------------------------------------------------
static void t_pfinflight(Tb &tb, uint64_t seed, int) {
  tb.power_on(); tb.configure(true, false, 64); tb.open_all();
  std::mt19937_64 r(seed);
  uint64_t buf = tb.alloc(0, 65536); uint16_t txn = 1;
  tb.h.d->sim_wr_lat = 400; tb.h.d->sim_rd_lat = 400;
  for (int i = 0; i < 6; i++) { Cmd w = wr_cmd(0, txn++, 0, i * 4, 2, buf + i * 4096, pat(r, 1024)); w.ov_status = 0x10; w.ov_alt = 0x00; tb.issue_wait(w); }
  tb.ring_all();
  // raise the warning the moment the first command is at the backend (GSTATUS[23:16] = backend busy): it must finish, the commands that
  // are admitted but still waiting for the backend must be aborted, the ones not yet admitted must be held (not lost)
  uint64_t c0 = tb.h.cycles;
  while (((tb.h.m_read(0x14) >> 16) & 0xFF) == 0 && tb.h.cycles - c0 < 20000) tb.h.run(5);
  TB_CHECK(tb, ((tb.h.m_read(0x14) >> 16) & 0xFF) != 0, "no command ever reached the backend");
  tb.h.d->pf_warn_i = 1; tb.h.run(6000); tb.poll_all();
  int ok = 0, aborted = 0;
  for (auto &kv : tb.last_cqe) { if (kv.second.status == 0x00) ok++; else if (kv.second.status == 0x10) { aborted++; TB_CHECK(tb, kv.second.nblk_done == 0, "ABORTED_POWER with nblk_done %u", kv.second.nblk_done); }
                                else TB_CHECK(tb, false, "unexpected status %02x during power-fail", kv.second.status); }
  TB_CHECK(tb, ok >= 1, "the command that had reached the backend did not finish (ok=%d aborted=%d)", ok, aborted);
  TB_CHECK(tb, aborted >= 1, "no waiting command was aborted by the power-fail warning (ok=%d aborted=%d)", ok, aborted);
  size_t held = tb.inflight.size();
  TB_CHECK(tb, (size_t)(ok + aborted) + held == 6, "ok %d + aborted %d + held %zu != 6", ok, aborted, held);
  tb.h.d->pf_warn_i = 0; tb.h.run(200);
  tb.drain();                                                  // the held commands complete once the warning is gone
  tb.h.d->sim_wr_lat = 10; tb.h.d->sim_rd_lat = 10;
  { Cmd w = wr_cmd(0, txn++, 0, 40, 2, buf, pat(r, 1024)); tb.run_one(w); }                     // admission resumed
  tb.verify_all();
}

// ---------------------------------------------------------------------------------------------------------------------
// xts: optional encryption.  Needs the ENABLE_XTS build.  Cipher text on the medium is compared with OpenSSL's XTS-AES-256 over the
// 528-byte unit (data || protection trailer), tweak = backend-absolute LBA.
// ---------------------------------------------------------------------------------------------------------------------
static bool xts_ref(const uint8_t key[64], uint64_t dun, const uint8_t *in, size_t n, uint8_t *out) {
  uint8_t iv[16] = {0}; for (int i = 0; i < 8; i++) iv[i] = (uint8_t)(dun >> (8 * i));
  EVP_CIPHER_CTX *c = EVP_CIPHER_CTX_new(); int l = 0, fl = 0;
  bool ok = EVP_EncryptInit_ex(c, EVP_aes_256_xts(), nullptr, key, iv) == 1 && EVP_EncryptUpdate(c, out, &l, in, (int)n) == 1 && EVP_EncryptFinal_ex(c, out + l, &fl) == 1;
  EVP_CIPHER_CTX_free(c); return ok;
}
static void t_xts(Tb &tb, uint64_t seed, int) {
  tb.power_on(); tb.configure(true, true, 64); tb.open_all();
  std::mt19937_64 r(seed);
  uint64_t buf = tb.alloc(0, 16384);
  uint16_t txn = 1;
  // no key yet: refused by validation (CRYPTO_ERROR / KEY_NOT_READY), nothing reaches the backend
  { Cmd w = wr_cmd(0, txn++, 0, 0, 1, buf, pat(r, 512)); sfs_cqe_t cq = tb.run_one(w);
    TB_CHECK(tb, cq.status == 0x12 && cq.detail == 1, "write without key: status %02x detail %u", cq.status, cq.detail); }
  uint8_t keys[4][64];
  for (int k = 0; k < 4; k++) { for (int i = 0; i < 64; i++) keys[k][i] = (uint8_t)r(); keys[k][0] ^= 1; sfs_mgmt_key_load(&tb.mg, k, keys[k]); tb.model->set_key_ready(k, true); }
  uint32_t ks = tb.h.m_read(0x748); TB_CHECK(tb, ks == 0xF, "KEY_STATUS %08x", ks);
  TB_CHECK(tb, tb.h.m_read(0x704) == 0, "key words are readable");
  // normal traffic through the encrypted + PI namespaces, exact data
  for (unsigned t = 0; t < Tb::NT; t++) {
    uint64_t b = tb.alloc(t, 16384);
    for (int rep = 0; rep < 3; rep++) {
      uint64_t lba = r() % 50; uint32_t n = 1 + r() % 8; std::vector<uint8_t> d = pat(r, n * 512);
      Cmd w = wr_cmd(t, (uint16_t)(0x200 + rep * 2), t, lba, n, b, d, 1); sfs_cqe_t cq = tb.run_one(w);
      TB_CHECK(tb, cq.status == 0 && cq.encrypted == 1 && cq.pi_verified == 1, "encrypted write: status %02x enc=%d pi=%d", cq.status, cq.encrypted, cq.pi_verified);
      Cmd rd = rd_cmd(t, (uint16_t)(0x201 + rep * 2), t, lba, n, b + 8192); tb.run_one(rd);
      // the unit on the medium is exactly XTS-AES-256(data || trailer), tweak = absolute LBA
      for (uint32_t i = 0; i < n; i++) {
        uint64_t abs = t * tb.ns_blocks + lba + i;
        uint8_t plain[528]; memcpy(plain, &d[i * 512], 512);
        uint32_t g = sfs_crc32c(plain, 512); memcpy(plain + 512, &g, 4);
        plain[516] = (uint8_t)t; plain[517] = (uint8_t)t;                                  // NS tag: nsid | tenant << 8
        uint64_t l48 = lba + i; for (int k = 0; k < 6; k++) plain[518 + k] = (uint8_t)(l48 >> (8 * k));
        plain[524] = 1; plain[525] = plain[526] = plain[527] = 0;
        uint8_t want[528]; xts_ref(keys[t], abs, plain, 528, want);
        uint8_t got[528]; tb.h.d->sim_dbg_lba = abs;
        for (int wd = 0; wd < 66; wd++) { tb.h.d->sim_dbg_word = wd; tb.h.d->eval(); uint64_t v = tb.h.d->sim_dbg_data; memcpy(got + wd * 8, &v, 8); }
        TB_CHECK(tb, memcmp(want, got, 528) == 0, "tenant %u block %llu: stored unit differs from XTS-AES-256 reference", t, (unsigned long long)abs);
        TB_CHECK(tb, memcmp(got, &d[i * 512], 64) != 0, "stored data is not encrypted");
      }
    }
  }
  // tamper with cipher text: detected by the guard (garbage after decryption)
  { uint64_t b = tb.alloc(0, 8192); std::vector<uint8_t> d = pat(r, 512);
    Cmd w = wr_cmd(0, txn++, 0, 7, 1, b, d, 1); tb.run_one(w);
    tb.h.d->sim_inj_corrupt_lba = 7; tb.h.d->sim_inj_corrupt_bit = 1000; tb.h.d->sim_inj_corrupt = 1; tb.h.run(1); tb.h.d->sim_inj_corrupt = 0;
    Cmd rd = rd_cmd(0, txn++, 0, 7, 1, b + 4096); rd.ov_status = 0x0B; sfs_cqe_t cq = tb.run_one(rd);
    TB_CHECK(tb, cq.status == 0x0B, "tampered cipher text not detected (status %02x)", cq.status); }
  // wrong key: reads fail the integrity check, no plaintext is returned
  { uint64_t b = tb.alloc(1, 8192); std::vector<uint8_t> d = pat(r, 512);
    Cmd w = wr_cmd(1, txn++, 1, 9, 1, b, d, 1); tb.run_one(w);
    uint8_t other[64]; for (int i = 0; i < 64; i++) other[i] = (uint8_t)r(); other[0] ^= 1; sfs_mgmt_key_load(&tb.mg, 1, other);
    Cmd rd = rd_cmd(1, txn++, 1, 9, 1, b + 4096); rd.ov_status = 0x0B; sfs_cqe_t cq = tb.run_one(rd);
    TB_CHECK(tb, cq.status == 0x0B, "wrong key not detected (status %02x)", cq.status);
    sfs_mgmt_key_load(&tb.mg, 1, keys[1]); }
  // zeroise: the keys are gone, the namespaces refuse data commands
  sfs_mgmt_key_zeroize(&tb.mg, 0); tb.model->set_key_ready(0, false);
  { Cmd rd = rd_cmd(0, txn++, 0, 7, 1, tb.alloc(0, 4096)); sfs_cqe_t cq = tb.run_one(rd);
    TB_CHECK(tb, cq.status == 0x12, "read after key zeroise: status %02x", cq.status); }
}

#ifndef NO_MAIN
int main(int argc, char **argv) {
  Harness::set_args(argc, argv);
  std::string which = argc > 1 ? argv[1] : "all";
  uint64_t seed = argc > 2 ? strtoull(argv[2], nullptr, 0) : 1;
  int ncmd = argc > 3 ? atoi(argv[3]) : 400;
  struct T { const char *n; std::function<void(Tb &, uint64_t, int)> f; };
  std::vector<T> tests = {{"basic", t_basic}, {"random", t_random}, {"invalid", t_invalid}, {"isolation", t_isolation}, {"durability", t_durability},
                          {"backend_fail", t_backend_fail}, {"corruption", t_corruption}, {"reset", t_reset}, {"fairness", t_fairness}, {"powerfail", t_powerfail},
                          {"nscfg", t_nscfg}, {"pfinflight", t_pfinflight}
#ifdef WITH_XTS
                          , {"xts", t_xts}
#endif
                          };
  int fails = 0, ran = 0;
  for (auto &t : tests) if (which == "all" || which == t.n) { fails += run_test(t.n, seed, ncmd, t.f); ran++; }
  if (!ran) { printf("unknown test %s\n", which.c_str()); return 2; }
  printf("%s (%d failing test%s)\n", fails ? "SUITE FAIL" : "SUITE PASS", fails, fails == 1 ? "" : "s");
  return fails ? 1 : 0;
}
#endif
