// =============================================================================
// Host-software backend suite: the fabric, the host-software mailbox adapter and a SOFTWARE SERVICE MODEL (C++ state machine that
// talks to the adapter only through its 32-bit mailbox, one register access at a time, like a driver on a management CPU).
// The generic model-checked tests (random / invalid / isolation) run unchanged against this backend; extra tests cover software
// failure, an unresponsive / slow service with timeouts and stale answers after a reset, and a service that withdraws.
// =============================================================================
#define SFS_TOP_CLASS Vtb_fabric_hostsw_top
#define SFS_TOP_HEADER "Vtb_fabric_hostsw_top.h"
#define SFS_NO_XBE
#define SFS_HOSTSW_TOP
#define NO_MAIN
#include "test_fabric.cpp"
#include <array>
#include <deque>

struct SwSvc {
  Harness &h;
  std::map<uint64_t, std::vector<uint8_t>> med;           // the software's storage: backend block -> 528-byte unit (stored verbatim)
  uint64_t capacity = 4096; uint32_t caps = 0x0C;          // DISCARD | DISCARD_ZERO (the adapter adds PI_NATIVE)
  bool serve = true; int poll_gap = 16;
  int64_t media_fail_lba = -1; bool dev_fail = false;
  uint32_t hold_before_commit = 0;                         // cycles the software sits on a finished request before committing
  uint32_t seq_done = 0; uint64_t n_req = 0;
  struct Step { bool we; uint32_t addr, wd; std::function<void(uint32_t)> cb; uint32_t delay; };
  std::deque<Step> script; enum { IDLE, ISSUE, WAIT } st = IDLE; int gap = 0; uint32_t delay_left = 0; bool delay_armed = false;
  explicit SwSvc(Harness &hh) : h(hh) { h.pre_edge = [this] { tick(); }; }

  void push(bool we, uint32_t a, uint32_t wd, std::function<void(uint32_t)> cb = nullptr, uint32_t delay = 0) { script.push_back({we, a, wd, cb, delay}); }
  void reset_state() { script.clear(); st = IDLE; gap = 0; delay_armed = false; seq_done = 0; }
  void tick() {
    auto *d = h.d;
    d->mb_req_valid = 0;
    if (st == IDLE) {
      if (script.empty()) { if (gap > 0) gap--; else if (serve) poll(); }
      if (!script.empty()) { st = ISSUE; delay_armed = false; }
    }
    if (st == ISSUE) {
      Step &s = script.front();
      if (!delay_armed) { delay_left = s.delay; delay_armed = true; }
      if (delay_left > 0) { delay_left--; return; }
      d->mb_req_valid = 1; d->mb_req_we = s.we; d->mb_req_addr = s.addr; d->mb_req_wdata = s.wd; d->eval();
      if (d->mb_req_ready) st = WAIT;
      return;
    }
    if (st == WAIT) {
      d->mb_req_valid = 0; d->eval();
      if (d->mb_rsp_valid) {
        uint32_t rd = d->mb_rsp_rdata; auto cb = script.front().cb; script.pop_front();
        st = IDLE; if (cb) cb(rd);
      }
    }
  }
  // ---- init: capabilities, capacity, READY
  void start() {
    reset_state();
    push(true, 0x0C, caps); push(true, 0x10, (uint32_t)capacity); push(true, 0x14, (uint32_t)(capacity >> 32)); push(true, 0x08, 1);
  }
  bool idle() const { return script.empty() && st == IDLE; }
  void withdraw() { push(true, 0x08, 0); }
  void resume() { push(true, 0x08, 1); }
  // ---- service loop
  void poll() {
    gap = poll_gap;
    push(false, 0x20, 0, [this](uint32_t s) {
      uint32_t seq = s >> 16; int op = (s >> 1) & 7;
      if (!(s & 1) || !serve || seq == seq_done) return;
      push(false, 0x24, 0, [=](uint32_t lo) { push(false, 0x28, 0, [=](uint32_t hi) { push(false, 0x2C, 0, [=](uint32_t nb) {
        service(seq, op, ((uint64_t)hi << 32) | lo, nb); }); }); });
    });
  }
  void finish(uint32_t seq, unsigned status, uint32_t nblk, bool durable) {
    push(true, 0x30, status); push(true, 0x34, nblk); push(true, 0x38, durable ? 1 : 0);
    push(true, 0x3C, seq, [this, seq](uint32_t) { seq_done = seq; }, hold_before_commit);
  }
  void service(uint32_t seq, int op, uint64_t lba, uint32_t nb) {
    n_req++;
    if (dev_fail) { finish(seq, 2, 0, false); return; }
    auto bad = [&](uint64_t b) { return media_fail_lba >= 0 && (uint64_t)media_fail_lba == b; };
    if (op == 2) {                                   // WRITE: read nb units from the staging window
      auto buf = std::make_shared<std::vector<uint32_t>>(); buf->reserve(nb * 132);
      for (uint32_t k = 0; k < nb * 132; k++) push(false, 0x2000 + 4 * k, 0, [=](uint32_t v) {
        buf->push_back(v);
        if (buf->size() == nb * 132) {
          for (uint32_t u = 0; u < nb; u++) { auto &m = med[lba + u]; m.resize(528); memcpy(m.data(), &(*buf)[u * 132], 528); }
          finish(seq, 0, nb, true);
        }
      });
    } else if (op == 1) {                            // READ
      for (uint32_t u = 0; u < nb; u++) if (bad(lba + u)) { finish(seq, 1, u, false); return; }
      for (uint32_t u = 0; u < nb; u++) {
        auto it = med.find(lba + u);
        push(true, 0x80 + 4 * u, it == med.end() ? 2 : 0);
        for (uint32_t k = 0; k < 132; k++) {
          uint32_t v = 0; if (it != med.end()) memcpy(&v, &it->second[4 * k], 4);
          push(true, 0x2000 + 4 * (u * 132 + k), v);
        }
      }
      finish(seq, 0, nb, false);
    } else if (op == 3) {                            // FLUSH: the medium is the software's persistent store
      finish(seq, 0, 0, true);
    } else if (op == 4) {                            // DISCARD
      for (uint32_t u = 0; u < nb; u++) med.erase(lba + u);
      finish(seq, 0, nb, true);
    } else finish(seq, 5, 0, false);
  }
};

static SwSvc *g_svc;
static void hook(Tb &tb) {
  tb.drain_limit = 40000000;
  g_svc = new SwSvc(tb.h);
  tb.power_hook = [&tb]() {
    g_svc->start();
    uint64_t t0 = tb.h.cycles; while (!g_svc->idle() && tb.h.cycles - t0 < 100000) tb.h.step();
    t0 = tb.h.cycles; while (!(tb.h.m_read(0x14) & 1) && tb.h.cycles - t0 < 100000) tb.h.run(50);
  };
}
static void h_random(Tb &tb, uint64_t seed, int n) { hook(tb); t_random(tb, seed, n); }
static void h_invalid(Tb &tb, uint64_t seed, int n) { hook(tb); t_invalid(tb, seed, n); }
static void h_isolation(Tb &tb, uint64_t seed, int n) { hook(tb); t_isolation(tb, seed, n); }

// the software reports errors: device failure and a media error; the fabric propagates them exactly and recovers
static void h_swfail(Tb &tb, uint64_t seed, int) {
  hook(tb); tb.power_on(); tb.configure(true, false, 64); tb.open_all();
  std::mt19937_64 r(seed); uint16_t txn = 1;
  uint64_t buf = tb.alloc(0, 16384);
  { Cmd w = wr_cmd(0, txn++, 0, 0, 8, buf, pat(r, 4096)); tb.run_one(w); }
  g_svc->dev_fail = true;
  { Cmd w = wr_cmd(0, txn++, 0, 8, 2, buf, pat(r, 1024)); w.ov_status = 0x0D; w.ov_detail = 2; tb.run_one(w);
    Cmd rd = rd_cmd(0, txn++, 0, 0, 2, buf + 8192); rd.ov_status = 0x0D; rd.ov_detail = 2; tb.run_one(rd);
    Cmd f = op_cmd(0, 3, txn++, 0); f.ov_status = 0x0D; tb.run_one(f); }
  g_svc->dev_fail = false;
  { Cmd w = wr_cmd(0, txn++, 0, 16, 8, buf, pat(r, 4096)); tb.run_one(w);
    g_svc->media_fail_lba = 16 + 3;
    Cmd rd = rd_cmd(0, txn++, 0, 16, 8, buf + 8192); rd.ov_status = 0x0C; rd.ov_detail = 1;
    sfs_cqe_t cq = tb.run_one(rd);
    TB_CHECK(tb, cq.nblk_done == 3, "media error at block 3: nblk_done=%u", cq.nblk_done);
    g_svc->media_fail_lba = -1;
    Cmd rd2 = rd_cmd(0, txn++, 0, 16, 8, buf + 8192); tb.run_one(rd2); }
  TB_CHECK(tb, g_svc->n_req >= 5, "the software saw only %llu requests", (unsigned long long)g_svc->n_req);
  tb.verify_all();
}

// unresponsive software: TIMEOUT; software that answers late: the stale commit is ignored and never completes a newer request
static void h_swstall(Tb &tb, uint64_t seed, int) {
  hook(tb); tb.power_on(); tb.configure(true, false, 64); tb.open_all();
  std::mt19937_64 r(seed); uint16_t txn = 1;
  uint64_t buf = tb.alloc(0, 16384);
  { Cmd w = wr_cmd(0, txn++, 0, 0, 4, buf, pat(r, 2048)); tb.run_one(w); }
  // (a) the software stops answering: the command completes with TIMEOUT/backend after the configured time, the fabric recovers
  sfs_mgmt_set_cmd_timeout(&tb.mg, 8000);
  g_svc->serve = false;
  { Cmd rd = rd_cmd(0, txn++, 0, 0, 2, buf + 8192); rd.ov_status = 0x0E; tb.issue_wait(rd); tb.ring_all();
    uint64_t c0 = tb.h.cycles;
    while (!tb.inflight.empty() && tb.h.cycles - c0 < 60000) { tb.poll_all(); tb.h.run(50); }
    TB_CHECK(tb, tb.inflight.empty(), "unanswered request never timed out");
    TB_CHECK(tb, tb.h.cycles - c0 >= 8000 && tb.h.cycles - c0 < 12000, "TIMEOUT after %llu cycles (limit 8000)", (unsigned long long)(tb.h.cycles - c0)); }
  g_svc->serve = true; tb.h.run(2000);
  { Cmd rd = rd_cmd(0, txn++, 0, 0, 4, buf + 8192); tb.run_one(rd); }                           // recovered, data intact
  // (b) slow software: it reads the request, then sits on its answer past the timeout.  The fabric times out and resets the backend; the
  //     answer that arrives afterwards carries the OLD sequence number and must be ignored; a request issued meanwhile must complete correctly.
  g_svc->hold_before_commit = 30000;
  { Cmd rd = rd_cmd(0, txn++, 0, 0, 2, buf + 8192); rd.ov_status = 0x0E; tb.issue_wait(rd); tb.ring_all();
    uint64_t c0 = tb.h.cycles;
    while (!tb.inflight.empty() && tb.h.cycles - c0 < 60000) { tb.poll_all(); tb.h.run(50); }
    TB_CHECK(tb, tb.inflight.empty(), "slow answer: the request did not time out"); }
  g_svc->hold_before_commit = 0;
  sfs_mgmt_set_cmd_timeout(&tb.mg, 0);
  { Cmd w = wr_cmd(0, txn++, 0, 40, 2, buf, pat(r, 1024)); tb.run_one(w); }                     // queued behind the sleeping software, answered later
  tb.h.run(40000);
  uint32_t stale = tb.h.d->hs_stale;
  TB_CHECK(tb, stale >= 1, "the stale commit was not detected (hs_stale=%u)", stale);
  { Cmd rd = rd_cmd(0, txn++, 0, 40, 2, buf + 8192); tb.run_one(rd); }
  tb.verify_all();
}

// the service withdraws (READY=0): in-flight commands are aborted, commands while it is gone fail fast, everything works after it returns
static void h_withdraw(Tb &tb, uint64_t seed, int) {
  hook(tb); tb.power_on(); tb.configure(true, false, 64); tb.open_all();
  std::mt19937_64 r(seed); uint16_t txn = 1;
  uint64_t buf = tb.alloc(0, 16384);
  { Cmd w = wr_cmd(0, txn++, 0, 0, 8, buf, pat(r, 4096)); tb.run_one(w); }
  g_svc->serve = false;                                                                           // the request will sit PENDING
  { Cmd rd = rd_cmd(0, txn++, 0, 0, 4, buf + 8192); rd.ov_status = 0x0F; tb.issue_wait(rd); tb.ring_all(); tb.h.run(500);
    TB_CHECK(tb, !tb.inflight.empty(), "request should be pending in the software");
    uint64_t c0 = tb.h.cycles; g_svc->withdraw();
    while (!tb.inflight.empty() && tb.h.cycles - c0 < 20000) { tb.poll_all(); tb.h.run(20); }
    TB_CHECK(tb, tb.inflight.empty(), "in-flight command not aborted when the software withdrew");
    TB_CHECK(tb, tb.h.cycles - c0 < 3000, "abort took %llu cycles", (unsigned long long)(tb.h.cycles - c0)); }
  tb.h.run(500);
  TB_CHECK(tb, !(tb.h.m_read(0x14) & 1), "backend still reported ready after the software withdrew");
  // commands while the backend is gone: prompt BACKEND_ERROR / NOT_READY (detail 6), never a hang
  for (int i = 0; i < 3; i++) {
    Cmd rd = rd_cmd(0, txn++, 0, 0, 2, buf + 8192); rd.ov_status = 0x0D; rd.ov_detail = 6;
    uint64_t c0 = tb.h.cycles; tb.run_one(rd);
    TB_CHECK(tb, tb.h.cycles - c0 < 5000, "command took %llu cycles to fail on a missing backend", (unsigned long long)(tb.h.cycles - c0));
  }
  { Cmd w = wr_cmd(0, txn++, 0, 8, 2, buf, pat(r, 1024)); w.ov_status = 0x0D; w.ov_detail = 6; tb.run_one(w); }
  // the service returns: the data it stored earlier is served again
  g_svc->serve = true; g_svc->resume();
  uint64_t t0 = tb.h.cycles; while (!(tb.h.m_read(0x14) & 1) && tb.h.cycles - t0 < 50000) tb.h.run(50);
  TB_CHECK(tb, tb.h.m_read(0x14) & 1, "backend not ready after the software returned");
  { Cmd rd = rd_cmd(0, txn++, 0, 0, 8, buf + 8192); tb.run_one(rd); }
  { Cmd w = wr_cmd(0, txn++, 0, 8, 2, buf, pat(r, 1024)); tb.run_one(w); Cmd rd = rd_cmd(0, txn++, 0, 8, 2, buf + 8192); tb.run_one(rd); }
  tb.verify_all();
}

int main(int argc, char **argv) {
  Harness::set_args(argc, argv);
  std::string which = argc > 1 ? argv[1] : "all";
  uint64_t seed = argc > 2 ? strtoull(argv[2], nullptr, 0) : 1;
  int ncmd = argc > 3 ? atoi(argv[3]) : 100;
  struct T { const char *n; std::function<void(Tb &, uint64_t, int)> f; };
  std::vector<T> tests = {{"random", h_random}, {"invalid", h_invalid}, {"isolation", h_isolation}, {"swfail", h_swfail}, {"swstall", h_swstall}, {"withdraw", h_withdraw}};
  int fails = 0, ran = 0;
  for (auto &t : tests) if (which == "all" || which == t.n) { fails += run_test(t.n, seed, ncmd, t.f); ran++; }
  if (!ran) { printf("unknown test %s\n", which.c_str()); return 2; }
  printf("%s (%d failing test%s)\n", fails ? "HOSTSW SUITE FAIL" : "HOSTSW SUITE PASS", fails, fails == 1 ? "" : "s");
  return fails ? 1 : 0;
}
