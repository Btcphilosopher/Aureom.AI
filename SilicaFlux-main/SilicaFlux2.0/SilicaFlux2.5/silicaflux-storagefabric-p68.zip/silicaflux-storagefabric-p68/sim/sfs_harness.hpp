// =============================================================================
// StorageFabric co-simulation harness (Verilator C++): clock, MMIO ports, AXI4 tenant-memory slave with random
// latency / back-pressure, independent bus monitor (domain isolation), sideband controls for the simulated device.
// =============================================================================
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <functional>
#include <map>
#include <random>
#include <string>
#include <vector>
#ifndef SFS_TOP_CLASS
#define SFS_TOP_CLASS Vsilicaflux_storage_fabric
#define SFS_TOP_HEADER "Vsilicaflux_storage_fabric.h"
#endif
#include SFS_TOP_HEADER
#include "verilated.h"

namespace sfsim {

struct Window { unsigned domain; uint64_t base, size; bool r, w; };

struct AxiStats {
  uint64_t ar = 0, aw = 0, r_beats = 0, w_beats = 0, b = 0;
  uint64_t violations = 0;
  uint64_t bytes_r = 0, bytes_w = 0;
};

class Harness {
 public:
  SFS_TOP_CLASS *d;
  VerilatedContext *ctx;
  uint64_t cycles = 0;
  std::vector<uint8_t> mem;           // tenant memory (IOVA == physical in the model)
  std::vector<Window> windows;        // independent record of what each domain may touch
  AxiStats st;
  std::mt19937_64 rng;
  // AXI slave behaviour
  int p_ready = 100;                  // percent: ar/aw/w ready probability
  int p_valid = 100;                  // percent: r/b valid probability
  int mem_lat = 4;                    // cycles from AR / last W to first R / B
  bool verbose = false;
  std::string last_violation;
  std::function<void()> pre_edge;     // optional per-cycle hook: drive extra inputs / sample extra outputs just before the clock edge

  static inline int g_argc = 0; static inline char **g_argv = nullptr;
  static void set_args(int argc, char **argv) { g_argc = argc; g_argv = argv; }
  explicit Harness(size_t mem_bytes = 16u << 20, uint64_t seed = 1) : mem(mem_bytes, 0), rng(seed) {
    ctx = new VerilatedContext;
    if (g_argv) ctx->commandArgs(g_argc, g_argv);
    d = new SFS_TOP_CLASS(ctx);
    zero_inputs();
    d->clk = 0; d->rst_n = 0;
    d->eval();
  }
  ~Harness() { d->final(); delete d; delete ctx; }

  void zero_inputs() {
    d->tmmio_valid = 0; d->tmmio_we = 0; d->tmmio_fn = 0; d->tmmio_addr = 0; d->tmmio_wdata = 0;
    d->mmio_valid = 0; d->mmio_we = 0; d->mmio_addr = 0; d->mmio_wdata = 0;
    d->pf_warn_i = 0;
    d->m_ar_ready = 0; d->m_r_valid = 0; d->m_r_id = 0; d->m_r_data = 0; d->m_r_resp = 0; d->m_r_last = 0;
    d->m_aw_ready = 0; d->m_w_ready = 0; d->m_b_valid = 0; d->m_b_id = 0; d->m_b_resp = 0;
#ifndef SFS_NO_EXT
    d->ext_cmd_valid = 0; d->ext_op = 0; d->ext_nsid = 0; d->ext_lba = 0; d->ext_nblk = 0; d->ext_txn = 0; d->ext_cpl_ready = 1;
    d->ext_in_done = 0; d->ext_out_done = 0;
    d->ext_lm_req = 0; d->ext_lm_we = 0; d->ext_lm_addr = 0; d->ext_lm_wdata = 0;
#endif
#ifdef SFS_HOSTSW_TOP
    d->mb_req_valid = 0; d->mb_req_we = 0; d->mb_req_addr = 0; d->mb_req_wdata = 0;
#endif
#ifdef SFS_VIRTIO_TOP
    d->v_mmio_req_valid = 0; d->v_mmio_req_we = 0; d->v_mmio_req_addr = 0; d->v_mmio_req_wdata = 0; d->v_mmio_req_be = 0xF;
    d->v_mgmt_req_valid = 0; d->v_mgmt_req_we = 0; d->v_mgmt_req_addr = 0; d->v_mgmt_req_wdata = 0;
    d->v_dma_req_ready = 0; d->v_dma_resp_valid = 0; d->v_dma_resp_rdata = 0; d->v_dma_resp_err = 0;
#endif
    d->sim_rd_lat = 10; d->sim_wr_lat = 10; d->sim_fl_lat = 20; d->sim_blk_lat = 1; d->sim_jitter_mask = 0;
    d->sim_inj_fail = 0; d->sim_inj_hang = 0; d->sim_inj_media_en = 0; d->sim_inj_media_lba = 0;
    d->sim_inj_corrupt = 0; d->sim_inj_corrupt_lba = 0; d->sim_inj_corrupt_bit = 0;
    d->sim_inj_misdirect_en = 0; d->sim_inj_misdirect_lba = 0; d->sim_power_loss = 0; d->sim_dbg_lba = 0; d->sim_dbg_word = 0;
#ifndef SFS_NO_XBE
    d->xbe_ready = 0; d->xbe_capacity = 0; d->xbe_caps = 0; d->xbe_req_ready = 0; d->xbe_wd_ready = 0; d->xbe_rd_valid = 0;
    d->xbe_rd_tag = 0; d->xbe_rd_data = 0; d->xbe_rd_ulast = 0; d->xbe_rd_uflags = 0; d->xbe_cpl_valid = 0; d->xbe_cpl_tag = 0;
    d->xbe_cpl_status = 0; d->xbe_cpl_durable = 0; d->xbe_cpl_nblk = 0;
#endif
#ifdef SFS_STORE_TOP
    d->store_por_n = 0; d->store_nand_vcc = 1; d->store_pwr_fail_n = 1; d->store_mg_req_valid = 0; d->store_mg_req_write = 0;
    d->store_mg_req_addr = 0; d->store_mg_req_wdata = 0;
#endif
  }

  // ---------------------------------------------------------------- host-side AXI memory slave
  struct RdBurst { unsigned id; uint64_t addr; int beats; int sent; uint64_t avail; bool bad; };
  struct WrBurst { unsigned id; uint64_t addr; int beats; int got; bool bad; };
  struct BResp { unsigned id; uint64_t at; bool bad; };
  std::deque<RdBurst> rq;
  std::deque<WrBurst> wq;
  std::deque<BResp> bq;

  bool rnd(int pct) { return pct >= 100 || (int)(rng() % 100) < pct; }

  void monitor(bool write, unsigned dom, uint64_t addr, uint64_t bytes, unsigned asid) {
    bool ok = false;
    for (auto &w : windows)
      if (w.domain == dom && addr >= w.base && addr + bytes <= w.base + w.size && (write ? w.w : w.r)) ok = true;
    if (asid == 1) ok = false;      // the local-memory address space must never reach the host port
    if (!ok) {
      st.violations++;
      char b[160];
      snprintf(b, sizeof b, "%s domain %u addr 0x%llx bytes %llu asid %u outside every window", write ? "WRITE" : "READ", dom,
               (unsigned long long)addr, (unsigned long long)bytes, asid);
      last_violation = b;
      if (verbose) fprintf(stderr, "[MON] %s\n", b);
    }
  }

  // half clock period; with --timing models (NAND twin) the pending delayed events are stepped through one by one
  void half(int c) {
#ifdef SFS_TIMING
    uint64_t target = ctx->time() + 5000;
    d->clk = c; d->eval();
    while (d->eventsPending() && d->nextTimeSlot() <= target) { ctx->time(d->nextTimeSlot()); d->eval(); }
    ctx->time(target); d->eval();
#else
    d->clk = c; d->eval();
    ctx->timeInc(1);
#endif
  }
  // One clock cycle: drive inputs, sample the handshakes that happen at the coming edge, clock.
  void step() {
    // ---- choose this cycle's AXI inputs
    bool ar_rdy = rnd(p_ready) && rq.size() < 16;
    bool aw_rdy = rnd(p_ready) && wq.size() < 16;
    bool w_rdy = false;
    for (auto &w : wq) if (w.got < w.beats) { w_rdy = rnd(p_ready); break; }
    bool r_v = false; RdBurst *rb = nullptr;
    if (!rq.empty() && rq.front().avail <= cycles && rnd(p_valid)) { r_v = true; rb = &rq.front(); }
    bool b_v = !bq.empty() && bq.front().at <= cycles && rnd(p_valid);
    d->m_ar_ready = ar_rdy; d->m_aw_ready = aw_rdy; d->m_w_ready = w_rdy;
    d->m_r_valid = r_v;
    if (r_v) {
      uint64_t a = rb->addr + (uint64_t)rb->sent * 8;
      uint64_t v = 0;
      if (!rb->bad && a + 8 <= mem.size()) memcpy(&v, &mem[a], 8);
      d->m_r_data = v; d->m_r_id = rb->id; d->m_r_last = (rb->sent + 1 == rb->beats); d->m_r_resp = rb->bad ? 2 : 0;
    }
    d->m_b_valid = b_v;
    if (b_v) { d->m_b_id = bq.front().id; d->m_b_resp = bq.front().bad ? 2 : 0; }
    d->eval();
    if (pre_edge) pre_edge();
    // ---- handshakes at the coming edge
    if (d->m_ar_valid && ar_rdy) {
      uint64_t bytes = ((uint64_t)d->m_ar_len + 1) * 8;
      monitor(false, d->m_ar_domain, d->m_ar_addr, bytes, d->m_ar_asid);
      rq.push_back({d->m_ar_id, d->m_ar_addr, (int)d->m_ar_len + 1, 0, cycles + mem_lat, d->m_ar_addr + bytes > mem.size()});
      st.ar++; st.bytes_r += bytes;
    }
    if (d->m_aw_valid && aw_rdy) {
      uint64_t bytes = ((uint64_t)d->m_aw_len + 1) * 8;
      monitor(true, d->m_aw_domain, d->m_aw_addr, bytes, d->m_aw_asid);
      wq.push_back({d->m_aw_id, d->m_aw_addr, (int)d->m_aw_len + 1, 0, d->m_aw_addr + bytes > mem.size()});
      st.aw++;
    }
    if (d->m_w_valid && w_rdy) {
      for (auto &w : wq) if (w.got < w.beats) {
        uint64_t a = w.addr + (uint64_t)w.got * 8;
        if (!w.bad) for (int i = 0; i < 8; i++) if ((d->m_w_strb >> i) & 1) mem[a + i] = (d->m_w_data >> (8 * i)) & 0xFF;
        w.got++; st.w_beats++; st.bytes_w += __builtin_popcount(d->m_w_strb);
        if (w.got == w.beats) bq.push_back({w.id, cycles + mem_lat, w.bad});
        break;
      }
      while (!wq.empty() && wq.front().got == wq.front().beats) wq.pop_front();
    }
    if (r_v && d->m_r_ready) {
      st.r_beats++;
      if (++rb->sent == rb->beats) rq.pop_front();
    }
    if (b_v && d->m_b_ready) { bq.pop_front(); st.b++; }
    // ---- clock
    half(1); half(0);
    cycles++;
  }
  void run(uint64_t n) { for (uint64_t i = 0; i < n; i++) step(); }

  void axi_reset() { rq.clear(); wq.clear(); bq.clear(); }       // a bus reset drops every transaction in flight
  void reset(int n = 8) {
    axi_reset(); d->rst_n = 0; run(n); axi_reset(); d->rst_n = 1; run(2);
  }

  // ---------------------------------------------------------------- MMIO
  uint32_t t_access(unsigned fn, uint32_t off, bool we, uint32_t wd, bool *err = nullptr) {
    d->tmmio_valid = 1; d->tmmio_we = we; d->tmmio_fn = fn; d->tmmio_addr = off; d->tmmio_wdata = wd;
    step();
    d->tmmio_valid = 0; d->tmmio_we = 0;
    d->eval();
    uint32_t r = d->tmmio_rsp_rdata; if (err) *err = d->tmmio_rsp_err;
    return r;
  }
  uint32_t t_read(unsigned fn, uint32_t off, bool *err = nullptr) { return t_access(fn, off, false, 0, err); }
  void t_write(unsigned fn, uint32_t off, uint32_t v, bool *err = nullptr) { t_access(fn, off, true, v, err); }
  uint32_t m_access(uint32_t off, bool we, uint32_t wd, bool *err = nullptr) {
    d->mmio_valid = 1; d->mmio_we = we; d->mmio_addr = off; d->mmio_wdata = wd;
    step();
    d->mmio_valid = 0; d->mmio_we = 0;
    d->eval();
    uint32_t r = d->mmio_rsp_rdata; if (err) *err = d->mmio_rsp_err;
    return r;
  }
  uint32_t m_read(uint32_t off, bool *err = nullptr) { return m_access(off, false, 0, err); }
  void m_write(uint32_t off, uint32_t v, bool *err = nullptr) { m_access(off, true, v, err); }

  // ---------------------------------------------------------------- management helpers (hypervisor view)
  int pt_next = 4;                    // entries 0..NT-1 are fabric-owned
  void add_window(unsigned dom, uint64_t base, uint64_t size, bool r = true, bool w = true) {
    m_write(0x500, pt_next);          // PT_IDX (the fabric forces >= NT)
    m_write(0x504, dom);
    m_write(0x508, (uint32_t)base); m_write(0x50C, (uint32_t)(base >> 32));
    m_write(0x510, (uint32_t)size); m_write(0x514, (uint32_t)(size >> 32));
    m_write(0x518, (r ? 1 : 0) | (w ? 2 : 0));
    m_write(0x51C, 3);                // valid + commit
    windows.push_back({dom, base, size, r, w});
    pt_next++;
  }
  uint32_t ns_config(unsigned n, unsigned owner, uint64_t base, uint64_t size, bool ro, bool enc, bool pi, unsigned key = 0) {
    uint32_t o = 0x300 + 0x20 * n;
    m_write(o + 4, (uint32_t)base); m_write(o + 8, (uint32_t)(base >> 32));
    m_write(o + 12, (uint32_t)size); m_write(o + 16, (uint32_t)(size >> 32));
    m_write(o, 1 | (ro ? 2 : 0) | (enc ? 4 : 0) | (pi ? 8 : 0) | (owner << 4) | (key << 8));
    return m_read(o + 0x14);
  }
  void tenant_cfg(unsigned t, bool allowed, unsigned maxinfl = 0, unsigned weight = 1, unsigned rate = 0, unsigned burst = 16) {
    uint32_t o = 0x100 + 0x20 * t;
    m_write(o, allowed ? 1 : 0); m_write(o + 4, maxinfl); m_write(o + 8, weight); m_write(o + 12, rate); m_write(o + 16, burst);
  }
};

}  // namespace sfsim
