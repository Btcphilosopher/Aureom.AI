// =============================================================================
// SilicaFlux-STORE integration suite: the SAME reference-model / host-library checks as the simulated-device suite, but the backend
// is the real Project 60 StorageChip (RISC-V ControlCore running the FTL firmware, BCH ECC, NAND digital twin) behind the STORE adapter.
// =============================================================================
#define SFS_TOP_CLASS Vtb_fabric_store_top
#define SFS_TOP_HEADER "Vtb_fabric_store_top.h"
#define SFS_NO_XBE
#define SFS_STORE_TOP
#define SFS_TIMING
#define NO_MAIN
#include "test_fabric.cpp"

static const char *FW = "third_party/p60-store/fw/prebuilt/p60_fw.hex";
static uint32_t store_bar(Harness &h, bool wr, uint32_t a, uint32_t wd = 0) {
  h.d->store_mg_req_valid = 1; h.d->store_mg_req_write = wr; h.d->store_mg_req_addr = a; h.d->store_mg_req_wdata = wd;
  int g = 0; h.d->eval();
  while (!h.d->store_mg_req_ready && g++ < 4000000) h.step();
  h.step(); h.d->store_mg_req_valid = 0;
  g = 0; while (!h.d->store_mg_rsp_valid && g++ < 4000000) h.step();
  uint32_t r = h.d->store_mg_rsp_rdata; h.step(); return r;
}
// ROM -> host-loaded firmware image -> mailbox IMAGE_READY -> wait for host_ready (FTL mounted / formatted) -> the adapter enables the controller
static void store_boot(Harness &h) {
  h.d->store_por_n = 1; h.run(20);
  uint32_t v = 0; int tries = 0;
  do { v = store_bar(h, false, 0x40000030); } while (v != 3 && tries++ < 200000);
  FILE *f = fopen(FW, "r"); if (!f) { printf("cannot open %s\n", FW); exit(2); }
  std::vector<uint32_t> img; unsigned w; while (fscanf(f, "%x\n", &w) == 1) img.push_back(w); fclose(f);
  for (size_t i = 0; i < img.size(); i++) store_bar(h, true, 0x00010000 + 4 * i, img[i]);
  store_bar(h, true, 0x40005004, 0); store_bar(h, true, 0x40005000, 1); store_bar(h, true, 0x40005044, 1);
  uint64_t t0 = h.cycles; while (!h.d->store_mgmt_irq && h.cycles - t0 < 3000000) h.step();
  for (int i = 0; i < 8; i++) store_bar(h, false, 0x40005020 + 4 * i);
  store_bar(h, true, 0x40005050, 0);
  t0 = h.cycles; while (!h.d->store_host_ready && h.cycles - t0 < 80000000) h.step();
  if (!h.d->store_host_ready) { printf("STORE chip did not reach host_ready\n"); exit(2); }
  for (int i = 0; i < 4000; i++) h.step();
  if (h.d->store_mgmt_irq) { for (int i = 0; i < 8; i++) store_bar(h, false, 0x40005020 + 4 * i); store_bar(h, true, 0x40005050, 0); }
  t0 = h.cycles; while (!(h.m_read(0x14) & 1) && h.cycles - t0 < 400000) h.run(100);      // adapter enabled the chip, capacity published
}

static void hook(Tb &tb) { tb.drain_limit = 40000000; tb.power_hook = [&tb]() { store_boot(tb.h); }; }

static void s_random(Tb &tb, uint64_t seed, int ncmd) { hook(tb); t_random(tb, seed, ncmd); }
static void s_isolation(Tb &tb, uint64_t seed, int n) { hook(tb); t_isolation(tb, seed, n); }
static void s_invalid(Tb &tb, uint64_t seed, int n) { hook(tb); t_invalid(tb, seed, n); }

// power-cycle the chip (and its NAND) with commands in flight; every acknowledged write must survive (the chip has no volatile write cache)
static void s_powerloss(Tb &tb, uint64_t seed, int ncmd) {
  hook(tb); tb.power_on(); tb.configure(false, false, 128); tb.open_all();
  std::mt19937_64 r(seed);
  const int rounds = 2;
  for (int round = 0; round < rounds; round++) {
    sfref::GenOpts go; go.p_invalid_pct = 0; go.hot_lbas = 16; sfref::Gen gen(*tb.model, seed * 17 + round, go);
    std::vector<uint64_t> bufs[Tb::NT]; std::vector<char> bb[Tb::NT];
    for (unsigned t = 0; t < Tb::NT; t++) { for (int i = 0; i < 8; i++) bufs[t].push_back(tb.alloc(t, 8192 + 64, 64)); bb[t].assign(8, 0); }
    std::map<std::pair<unsigned, uint16_t>, int> bidx;
    tb.on_done = [&](unsigned t, uint16_t x) { auto it = bidx.find({t, x}); if (it != bidx.end()) { bb[t][it->second] = 0; bidx.erase(it); } };
    int issued = 0, n = ncmd / rounds;
    // issue a burst of writes / reads, cut power while they are in flight
    while (issued < n) {
      unsigned t = r() % Tb::NT;
      sfref::GenCmd g = gen.valid(t);
      if (!g.valid_cmd) continue;
      sfref::Desc d0 = sfref::decode(g.w);
      if (d0.opcode == 5) continue;
      Cmd c; c.tenant = t; memcpy(c.w, g.w, 64); c.payload = g.payload;
      sfref::Desc d = sfref::decode(c.w);
      c.w[1] = (c.w[1] & ~0xFFFFu) | (uint16_t)(1 + round * 1000 + issued);
      c.ov_status = 0x0F; c.ov_alt = 0x00; c.ov_alt2 = 0x0D;                      // aborted by the reset, completed before the cut, or BACKEND_ERROR/NOT_READY while it was gone
      int bi = -1;
      if (d.opcode == 1 || d.opcode == 2) {
        int tries = 0; do { bi = (int)(r() % bufs[t].size()); if (++tries > 200) { tb.ring_all(); tb.poll_all(); tb.h.run(500); tries = 0; } } while (bb[t][bi]);
        bb[t][bi] = 1; uint64_t b = bufs[t][bi]; c.w[6] = (uint32_t)b; c.w[7] = (uint32_t)(b >> 32); bidx[{t, (uint16_t)(c.w[1] & 0xFFFF)}] = bi;
      }
      tb.issue_wait(c); issued++;
      if (issued % 2 == 0) tb.ring_all();
      tb.poll_all();
    }
    tb.ring_all();
    uint64_t t0 = tb.h.cycles; uint64_t cut = 20000 + r() % 80000;
    while (tb.h.cycles - t0 < cut) { tb.poll_all(); tb.h.run(100); }
    tb.poll_all();
    printf("  round %d: cutting chip power with %zu commands in flight\n", round, tb.inflight.size());
    tb.h.d->store_por_n = 0; tb.h.d->store_nand_vcc = 0; tb.h.d->store_pwr_fail_n = 1; tb.h.run(200);
    tb.h.d->store_nand_vcc = 1; tb.h.run(50);
    // the fabric sees the backend go away: in-flight commands are aborted with a completion; wait for them
    uint64_t c0 = tb.h.cycles; while (!tb.inflight.empty() && tb.h.cycles - c0 < 400000) { tb.poll_all(); tb.h.run(200); }
    TB_CHECK(tb, tb.inflight.empty(), "%zu commands never completed after the chip lost power", tb.inflight.size());
    for (auto &kv : tb.inflight) { sfref::Desc d = sfref::decode(kv.second.w); if (kv.second.out.executed && d.opcode == 1) tb.model->on_write_failed(kv.second.out.wid, 0); }
    tb.inflight.clear(); tb.on_done = nullptr;
    store_boot(tb.h);                                                         // reboot: the FTL mounts from the NAND (no format of a non-blank medium)
    // every acknowledged write must be exact; unacknowledged ones are old-or-new per block
    tb.verify_all(true);
  }
}

int main(int argc, char **argv) {
  Harness::set_args(argc, argv);
  std::string which = argc > 1 ? argv[1] : "all";
  uint64_t seed = argc > 2 ? strtoull(argv[2], nullptr, 0) : 1;
  int ncmd = argc > 3 ? atoi(argv[3]) : 150;
  struct T { const char *n; std::function<void(Tb &, uint64_t, int)> f; };
  std::vector<T> tests = {{"random", s_random}, {"invalid", s_invalid}, {"isolation", s_isolation}, {"powerloss", s_powerloss}};
  int fails = 0, ran = 0;
  for (auto &t : tests) if (which == "all" || which == t.n) { fails += run_test(t.n, seed, ncmd, t.f); ran++; }
  if (!ran) { printf("unknown test %s\n", which.c_str()); return 2; }
  printf("%s (%d failing test%s)\n", fails ? "STORE SUITE FAIL" : "STORE SUITE PASS", fails, fails == 1 ? "" : "s");
  return fails ? 1 : 0;
}
