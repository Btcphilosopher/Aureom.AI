// =============================================================================
// Verification environment: DUT (Verilated fabric) + host library (libsfstor, independent C) + reference model (sfref.hpp,
// independent C++), tenant memory model with a bus monitor, command tracker that compares EVERY completion with the model.
// =============================================================================
#pragma once
#include "sfs_harness.hpp"
#include "sfstor.h"
#include "sfref.hpp"
#include <algorithm>
#include <memory>
#include <set>
#include <functional>

namespace sfsim {

struct Stats {
  uint64_t checks = 0, fails = 0;
};
#define TB_CHECK(tb, cond, ...) do { (tb).st.checks++; if (!(cond)) { (tb).st.fails++; if ((tb).st.fails <= 40) { printf("  FAIL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } } while (0)

struct Cmd {
  unsigned tenant = 0;
  uint32_t w[16] = {0};
  std::vector<uint8_t> payload;
  sfref::Outcome out;
  uint64_t buf = 0;          // IOVA of the data buffer (0: none)
  uint32_t nbytes = 0;
  uint64_t t_submit = 0;
  bool bad_hcrc = false;
  int fault = -1;
  int ov_status = -1, ov_detail = -1, ov_alt = -1, ov_alt2 = -1;   // expected status/detail for commands the model cannot predict (injected faults)
};

class Tb;
struct TCtx { Tb *tb; unsigned t; };

class Tb {
 public:
  static constexpr unsigned NT = 4;
  static constexpr unsigned NS_N = 8;
  static constexpr unsigned MDTS = 8;
  static constexpr uint64_t WIN_BASE = 0x100000, WIN_SIZE = 0x200000;       // per tenant: 2 MiB
  Harness h;
  Stats st;
  std::unique_ptr<sfref::Model> model;
  sfs_mgmt_t mg;
  sfs_mgmt_transport_t mtp;
  sfs_transport_t tp[NT];
  TCtx tctx[NT];
  sfs_dev_t dev[NT];
  sfs_queue_t q[NT];
  uint64_t next_alloc[NT];
  bool qopen[NT] = {false, false, false, false};
  std::map<std::pair<unsigned, uint16_t>, Cmd> inflight;       // (tenant, txn) -> command
  std::map<std::pair<unsigned, uint16_t>, sfs_cqe_t> last_cqe;
  std::vector<uint32_t> lat;                                    // CQE latencies of successful data commands
  uint64_t completed = 0, errors = 0;
  int pt_next = 4;
  unsigned yield_cycles = 8;
  bool verbose = false;
  std::function<void(unsigned, uint16_t)> on_done;
  uint64_t ns_blocks = 256;
  bool use_pi = true, use_enc = false;
  bool xts = false;
  uint8_t be_caps = 0; uint64_t be_cap = 0;
  uint64_t unreclaimed = 0;

  explicit Tb(uint64_t seed = 1, size_t mem = 16u << 20) : h(mem, seed) {
    for (unsigned t = 0; t < NT; t++) { tctx[t] = {this, t}; next_alloc[t] = WIN_BASE + t * WIN_SIZE + 0x10000; }
    mtp.ctx = this;
    mtp.mmio_read32 = [](void *c, uint32_t off) { return ((Tb *)c)->h.m_read(off); };
    mtp.mmio_write32 = [](void *c, uint32_t off, uint32_t v) { ((Tb *)c)->h.m_write(off, v); };
    mtp.yield = [](void *c) { ((Tb *)c)->h.run(2); };
    for (unsigned t = 0; t < NT; t++) {
      tp[t].ctx = &tctx[t];
      tp[t].mmio_read32 = [](void *c, uint32_t off) { TCtx *x = (TCtx *)c; return x->tb->h.t_read(x->t, off); };
      tp[t].mmio_write32 = [](void *c, uint32_t off, uint32_t v) { TCtx *x = (TCtx *)c; x->tb->h.t_write(x->t, off, v); };
      tp[t].mem_alloc = [](void *c, size_t bytes, size_t align, uint64_t *iova, void **va) {
        TCtx *x = (TCtx *)c; Tb *tb = x->tb; uint64_t a = tb->next_alloc[x->t];
        if (align < 4) align = 4;
        a = (a + align - 1) & ~(uint64_t)(align - 1);
        if (a + bytes > WIN_BASE + (x->t + 1) * WIN_SIZE) return -1;
        memset(&tb->h.mem[a], 0, bytes);
        tb->next_alloc[x->t] = a + bytes; *iova = a; *va = &tb->h.mem[a]; return 0;
      };
      tp[t].mem_free = [](void *, uint64_t) {};
      tp[t].yield = [](void *c) { TCtx *x = (TCtx *)c; x->tb->h.run(x->tb->yield_cycles); };
      tp[t].barrier = nullptr;
    }
  }

  // ------------------------------------------------------------------ bring-up
  std::function<void()> power_hook;                                  // e.g. boot the SilicaFlux-STORE chip
  void power_on(int settle = 200) { h.reset(); if (power_hook) power_hook(); h.run(settle); }

  // Hypervisor configuration: DMA windows, namespaces (one per tenant: ns t), quotas, fabric enable.  Mirrors it into the model.
  void configure(bool pi = true, bool enc = false, uint64_t blocks = 256, bool ro_ns3 = false, bool fresh_model = true) {
    use_pi = pi; use_enc = enc; ns_blocks = blocks; pt_next = 4; h.windows.clear();
    sfs_mgmt_open(&mg, &mtp);
    sfs_be_info_t bi{}; sfs_mgmt_backend_info(&mg, &bi);
    be_caps = (uint8_t)bi.caps; be_cap = bi.capacity_blocks;
    sfref::BackendCaps bc;
    bc.capacity_blocks = bi.capacity_blocks;
    bc.pi_native = bi.caps & 1; bc.volatile_cache = (bi.caps >> 1) & 1; bc.discard = (bi.caps >> 2) & 1; bc.discard_zero = (bi.caps >> 3) & 1;
    sfref::Interp ip; ip.refuse_overlap = true;                      // the RTL refuses overlapping namespaces (NS_STATUS bit 5)
    if (fresh_model) model.reset(new sfref::Model(NT, NS_N, MDTS, bc, ip));
    for (unsigned t = 0; t < NT; t++) {
      sfs_dma_window_t w{t, WIN_BASE + t * WIN_SIZE, WIN_SIZE, 1, 1};
      int r = sfs_mgmt_dma_window(&mg, pt_next++, &w);
      TB_CHECK(*this, r == 0, "dma window %u refused (%d)", t, r);
      h.windows.push_back({t, w.base, w.size, true, true});
      sfs_ns_cfg_t nc{t, t * blocks, blocks, ro_ns3 && t == 3, enc, pi && bc.pi_native, enc ? t : 0};
      uint32_t nss = 0;
      r = sfs_mgmt_ns_config(&mg, t, &nc, &nss);
      sfref::NsCfg mc; mc.owner = t; mc.base = t * blocks; mc.size = blocks; mc.readonly = nc.readonly; mc.enc = enc; mc.pi = nc.pi; mc.key_slot = nc.key_slot;
      sfref::NsStatus ms; ms.accepted = (r == 0);
      if (fresh_model) ms = model->cfg_ns(t, mc);
      TB_CHECK(*this, (r == 0) == ms.accepted, "ns %u acceptance differs: rtl=%d model=%d status=%02x", t, r == 0, ms.accepted, nss);
      sfs_tcfg_t tc{}; tc.enable_allowed = 1; tc.max_inflight = 0; tc.weight = 1; tc.rate = 0; tc.burst = 16;
      sfs_mgmt_tenant_cfg(&mg, t, &tc);
    }
    sfs_mgmt_enable_fabric(&mg, 1);
    sfs_mgmt_set_gctrl(&mg, SFS_GCTRL_ENABLE | SFS_GCTRL_TRACE_EN);
  }
  // one command, start to finish (the queue must be idle)
  sfs_cqe_t run_one(Cmd &c) {
    uint16_t txn = (uint16_t)(c.w[1] & 0xFFFF);
    issue_wait(c); ring_all(); drain();
    return last_cqe[{c.tenant, txn}];
  }
  // submit a descriptor WITHOUT involving the model (attack / injected-fault commands whose effect the model must not apply)
  sfs_cqe_t direct(unsigned t, const uint32_t w[16], uint64_t max_cycles = 2000000) {
    sfs_cqe_t cq; memset(&cq, 0, sizeof cq); cq.status = 0xEE;
    int r = sfs_submit_raw(&q[t], w);
    if (r) { printf("direct: submit failed %s\n", sfs_strerror(r)); return cq; }
    sfs_ring(&q[t]);
    uint64_t c0 = h.cycles;
    while (h.cycles - c0 < max_cycles) { int n = sfs_poll(&q[t], &cq); if (n == 1) return cq; h.run(8); }
    cq.status = 0xEF; return cq;                                     // no completion
  }
  // hard reset of the fabric (power cycle) with an optional power loss on the simulated device; the host side is re-configured
  void power_cycle(bool device_loses_power, bool fresh = false) {
    for (unsigned t = 0; t < NT; t++) qopen[t] = false;
    if (device_loses_power) { h.d->sim_power_loss = 1; h.run(2); h.d->sim_power_loss = 0; }
    h.axi_reset(); h.d->rst_n = 0; h.run(12); h.axi_reset(); h.d->rst_n = 1; h.run(200);
    for (unsigned t = 0; t < NT; t++) next_alloc[t] = std::max<uint64_t>(next_alloc[t], WIN_BASE + t * WIN_SIZE + 0x10000);
    configure(use_pi, use_enc, ns_blocks, false, fresh);
  }
  void open_queue(unsigned t, unsigned sq = 32, unsigned cq = 32) {
    int r = sfs_dev_open(&dev[t], &tp[t], t);
    TB_CHECK(*this, r == 0, "dev_open tenant %u: %s", t, sfs_strerror(r));
    r = sfs_queue_create(&dev[t], &q[t], sq, cq);
    TB_CHECK(*this, r == 0, "queue_create tenant %u: %s", t, sfs_strerror(r));
    qopen[t] = (r == 0);
  }
  void open_all(unsigned sq = 32, unsigned cq = 32) { for (unsigned t = 0; t < NT; t++) open_queue(t, sq, cq); }

  // ------------------------------------------------------------------ buffers
  uint64_t alloc(unsigned t, size_t bytes, size_t align = 4096) {
    uint64_t iova; void *va;
    int r = tp[t].mem_alloc(&tctx[t], bytes, align, &iova, &va);
    if (r) { printf("out of tenant memory\n"); exit(2); }
    return iova;
  }

  // ------------------------------------------------------------------ descriptors
  static void build(uint32_t w[16], uint8_t op, uint16_t flags, uint16_t txn, uint8_t nsid, uint64_t lba, uint32_t nblk, uint64_t addr,
                    uint16_t claim, uint32_t hcrc = 0) {
    memset(w, 0, 64);
    w[0] = 1u | ((uint32_t)op << 8) | ((uint32_t)flags << 16);
    w[1] = txn | ((uint32_t)nsid << 16);
    w[2] = (uint32_t)lba; w[3] = (uint32_t)(lba >> 32);
    w[4] = nblk; w[5] = (op == 1 || op == 2) ? nblk * 512 : 0;
    w[6] = (uint32_t)addr; w[7] = (uint32_t)(addr >> 32);
    w[8] = claim; w[9] = hcrc;
  }

  // Submit one command: run the model first (submission order), place payload, post the descriptor.
  // Returns false if the SQ is full (caller must drain completions).
  bool issue(Cmd &c) {
    uint16_t txn = (uint16_t)(c.w[1] & 0xFFFF);
    c.out = model->submit(c.tenant, c.w, c.payload.empty() ? nullptr : c.payload.data());
    sfref::Desc d = sfref::decode(c.w);
    // data placement
    if (d.opcode == 1 && !c.payload.empty() && d.data_addr + c.payload.size() <= h.mem.size()) memcpy(&h.mem[d.data_addr], c.payload.data(), c.payload.size());
    if (d.opcode == 2 && d.data_addr + d.nblk * 512ull <= h.mem.size()) memset(&h.mem[d.data_addr], 0xA5, d.nblk * 512ull);
    c.buf = d.data_addr; c.nbytes = d.nblk * 512;
    if (verbose) printf("    [cmd] t%u txn %04x op %u ns %u lba %llu n %u flags %04x\n", c.tenant, txn, d.opcode, d.nsid, (unsigned long long)d.lba, d.nblk, d.flags);
    int r = sfs_submit_raw(&q[c.tenant], c.w);
    TB_CHECK(*this, r == 0, "submit_raw failed: %s", sfs_strerror(r));
    c.t_submit = h.cycles;
    inflight[{c.tenant, txn}] = c;
    return true;
  }

  // Process one completion
  void on_cqe(unsigned t, const sfs_cqe_t &cq) {
    auto it = inflight.find({t, cq.txn});
    if (it == inflight.end()) { TB_CHECK(*this, false, "completion for unknown txn %04x tenant %u", cq.txn, t); return; }
    Cmd c = it->second; inflight.erase(it);
    completed++;
    last_cqe[{t, cq.txn}] = cq;
    if (on_done) on_done(t, cq.txn);
    sfref::Cqe e; e.txn = cq.txn; e.status = cq.status; e.detail = cq.detail; e.durable = cq.durable; e.pi_verified = cq.pi_verified;
    e.encrypted = cq.encrypted; e.crc_valid = cq.crc_valid; e.opcode = cq.opcode; e.nblk_done = cq.nblk_done; e.result0 = cq.result0;
    e.result1 = cq.result1; e.sq_head = cq.sq_head; e.tenant = cq.tenant; e.latency = cq.latency; e.phase = cq.phase;
    e.w1_rsv = cq.raw[1] & 0xF0u; e.w6 = cq.raw[6]; e.w7_rsv = cq.raw[7] >> 1;
    last_cqe[{t, cq.txn}] = cq;
    std::string why;
    if (c.ov_status >= 0) {
      TB_CHECK(*this, (cq.status == c.ov_status && (c.ov_detail < 0 || cq.detail == c.ov_detail)) || (c.ov_alt >= 0 && cq.status == c.ov_alt) || (c.ov_alt2 >= 0 && cq.status == c.ov_alt2), "tenant %u txn %04x: expected status %02x detail %d, got status %02x detail %02x",
               t, cq.txn, c.ov_status, c.ov_detail, cq.status, cq.detail);
    } else {
      bool ok = model->check_cqe(c.out, e, why);
      TB_CHECK(*this, ok, "CQE mismatch tenant %u txn %04x op %u: %s [rtl status=%02x detail=%02x durable=%d nblk_done=%u]", t, cq.txn,
               sfref::decode(c.w).opcode, why.c_str(), cq.status, cq.detail, cq.durable, cq.nblk_done);
    }
    if (cq.status != 0) errors++;
    if (c.ov_status >= 0 && cq.status == 0) { /* unexpected success of an injected-fault command: fall through to data handling */ }
    sfref::Desc d = sfref::decode(c.w);
    if (cq.status == 0) {
      if (d.opcode == 1 || d.opcode == 5) model->on_write_complete(c.out.wid, cq.durable);
      if (d.opcode == 3) model->on_flush_complete(t);
      if (d.opcode == 2 && c.out.executed) {
        std::string w2;
        const uint8_t *got = &h.mem[c.buf];
        if (c.out.read_indeterminate) {
          bool ok2 = model->check_read_after_loss(d.nsid, d.lba, d.nblk, got, w2);
          TB_CHECK(*this, ok2, "read-after-loss mismatch tenant %u ns %u lba %llu: %s", t, d.nsid, (unsigned long long)d.lba, w2.c_str());
        } else {
          bool same = memcmp(got, c.out.read_data.data(), c.out.read_data.size()) == 0;
          TB_CHECK(*this, same, "READ DATA mismatch tenant %u ns %u lba %llu nblk %u (txn %04x)", t, d.nsid, (unsigned long long)d.lba, d.nblk, cq.txn);
          if (!same && st.fails <= 3) {
            size_t k = 0; while (k < c.out.read_data.size() && got[k] == c.out.read_data[k]) k++;
            printf("    first difference at byte %zu (block %zu): got %02x%02x%02x%02x expected %02x%02x%02x%02x; got-zero-block=%d\n", k, k / 512, got[k], got[k+1], got[k+2], got[k+3],
                   c.out.read_data[k], c.out.read_data[k+1], c.out.read_data[k+2], c.out.read_data[k+3], [&]{ for (size_t i = (k/512)*512; i < (k/512)*512+512; i++) if (got[i]) return 0; return 1; }());
          }
        }
      }
      if (d.opcode == 1 || d.opcode == 2) lat.push_back(cq.latency);
    } else {
      // failed commands: no data may reach the host buffer on a failed READ, and no write may be applied for validation failures
      if (d.opcode == 1 && c.out.executed) model->on_write_failed(c.out.wid, cq.nblk_done);
      if (d.opcode == 2 && c.buf && c.buf + c.nbytes <= h.mem.size() && cq.status != 0x0F && cq.status != 0x10) {
        bool untouched = true;
        for (uint32_t i = 0; i < c.nbytes; i++) if (h.mem[c.buf + i] != 0xA5) { untouched = false; break; }
        TB_CHECK(*this, untouched || cq.status == 0x0E || cq.status == 0x09 || cq.status == 0x08, "failed READ (status %02x) modified the host buffer", cq.status);
      }
      if ((d.opcode == 5) && c.out.executed) model->on_write_failed(c.out.wid, cq.nblk_done);
    }
  }

  // Drain all completions that are available now; returns count
  int poll_all() {
    int n = 0;
    for (unsigned t = 0; t < NT; t++) {
      if (!qopen[t]) continue;
      sfs_cqe_t cq;
      while (sfs_poll(&q[t], &cq) == 1) { on_cqe(t, cq); n++; }
    }
    return n;
  }
  // Wait until everything in flight completed (bounded)
  uint64_t drain_limit = 1500000;                                   // cycles without progress before a hang is reported
  bool drain(uint64_t max_cycles = 0) {
    if (!max_cycles) max_cycles = drain_limit;
    uint64_t c0 = h.cycles;
    for (unsigned t = 0; t < NT; t++) if (qopen[t]) sfs_ring(&q[t]);
    while (!inflight.empty()) {
      poll_all();
      if (inflight.empty()) break;
      h.run(16);
      if (h.cycles - c0 > max_cycles) {
        TB_CHECK(*this, false, "drain timeout with %zu commands in flight", inflight.size());
        for (auto &kv : inflight) {
          sfref::Desc d = sfref::decode(kv.second.w);
          printf("    stuck: tenant %u txn %04x op %u ns %u lba %llu nblk %u flags %04x fault=%d\n", kv.first.first, kv.first.second, d.opcode, d.nsid,
                 (unsigned long long)d.lba, d.nblk, d.flags, kv.second.fault);
        }
        for (unsigned t = 0; t < NT; t++) if (qopen[t]) {
          sfs_qstatus_t qs; sfs_queue_status(&q[t], &qs); char b[160]; sfs_qstatus_str(&qs, b, sizeof b);
          printf("    tenant %u: %s sq_head=%u sq_tail=%u cq_tail=%u cq_head=%u inflight=%u\n", t, b, qs.sq_head, qs.sq_tail, qs.cq_tail, qs.cq_head, qs.inflight);
        }
        printf("    GSTATUS=%08x\n", h.m_read(0x14));
#ifdef SFS_STORE_TOP
        printf("    store adapter state=%u cmds=%u host_ready=%d\n", h.d->store_ad_state, h.d->store_ad_cmds, h.d->store_host_ready);
#endif
        return false;
      }
    }
    return true;
  }
  // Submit with back-pressure handling: poll completions while the ring is full
  void issue_wait(Cmd &c) {
    uint64_t c0 = h.cycles;
    while (!issue_try(c)) {
      poll_all(); h.run(16);
      if (h.cycles - c0 > drain_limit) { TB_CHECK(*this, false, "SQ stuck full"); return; }
    }
  }
  bool issue_try(Cmd &c) {
    if (sfs_sq_space(&q[c.tenant]) <= 0) return false;
    uint16_t txn = (uint16_t)(c.w[1] & 0xFFFF);
    if (inflight.count({c.tenant, txn})) return false;
    return issue(c);
  }
  void ring_all() { for (unsigned t = 0; t < NT; t++) if (qopen[t]) sfs_ring(&q[t]); }

  // Verify the whole logical content of every namespace against the model
  void verify_all(bool after_loss = false) {
    for (unsigned t = 0; t < NT; t++) {
      if (!qopen[t] || !model->ns_valid(t)) continue;
      uint64_t buf = alloc(t, 4096);
      for (uint64_t lba = 0; lba < ns_blocks; lba += MDTS) {
        uint32_t n = (uint32_t)std::min<uint64_t>(MDTS, ns_blocks - lba);
        Cmd c; c.tenant = t;
        build(c.w, 2, 0, (uint16_t)(0xF000 + (lba / MDTS)), t, lba, n, buf, t);
        issue_wait(c);
        ring_all();
        drain();
      }
      (void)after_loss;
    }
  }
};

}  // namespace sfsim
