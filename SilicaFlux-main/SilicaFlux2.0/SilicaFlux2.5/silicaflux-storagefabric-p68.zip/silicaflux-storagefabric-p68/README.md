# SilicaFlux StorageFabric — Project 68
### Cloud storage processing accelerator for the SilicaFlux CloudDPU · Aureom.AI | SilicaFlux-CLOUD

**Primary RTL:** [`rtl/silicaflux_storage_fabric.sv`](rtl/silicaflux_storage_fabric.sv) (+ [`rtl/silicaflux_storage_fabric_pkg.sv`](rtl/silicaflux_storage_fabric_pkg.sv))

A storage-request offload subsystem for a cloud DPU: tenants (and, through a VirtIO block front end, virtual machines) submit block commands on hardware-bound
queue pairs; the fabric **validates** every command, **schedules** them fairly across tenants, moves the data between tenant memory and a **storage backend** through a
**protected DMA** engine, applies **end-to-end data integrity** (CRC-32C protection information, optional XTS-AES-256, optional host CRC), and posts a completion that
reports status **and durability** truthfully. The backend is interchangeable: a simulated block device (baseline), **SilicaFlux-STORE** (the verified P60 SSD controller, driven — not
re-implemented), a host-software service, with an NVMe hardware adapter documented as a future backend.

```
 tenant / VM ─► queue ─► validation ─► scheduler ─► protected DMA ─► integrity (CRC-32C PI · XTS) ─► backend adapter ─► completion
                                                                         simulated device │ SilicaFlux-STORE │ host software │ (NVMe: future)
```

> ## Read this first — what this is and is not
> * **Simulation only.** Verilator cycle-accurate RTL simulation with C/C++ testbenches. **No FPGA, no silicon, no timing/area/power numbers, no formal proof of P68 RTL.** All performance numbers are in fabric clock cycles on a *simulated* block device.
> * **STORE durability is inherited** from P60's "no volatile write cache" contract (which trusts P60's firmware); P68 shows it survives the injected chip power cuts, it does not prove it. No PLP hardware.
> * **No PCIe, SR-IOV, NVMe conformance, NVMe initiator, NVMe-oF** (no transport exists). The NVMe backend adapter is **not implemented**; `docs/04_BACKENDS_VIRTIO_NVME.md` §4 explains the taxonomy and what a future adapter needs.
> * **Not integrated into P61** (documented plan: `docs/08_P61_INTEGRATION.md`); P61 still refuses `OP_STORAGE`.
> * CRC-32C and XTS-AES are **not authentication**. Everything in `docs/07_LIMITATIONS.md` applies.
> * Delivered as an archive; **nothing was committed or pushed to GitHub.**

## Definition of done (met in simulation)
*The CloudDPU storage fabric processes logical block operations through a real simulation backend, preserves data integrity, and reports completion and durability status correctly.* — the
fabric passes a model-checked verification suite on three backends (see Results), including power loss, backend failure, corruption, reset, isolation and the VirtIO path.

## Quick start
Needs: Verilator ≥ 5.040 (tested with the PyPI `verilator` 5.48.0 wheel, headers 5.49; for the PyPI wheel set `PATH` to its `bin/` and `VERILATOR_ROOT` to the package directory), g++ ≥ 11 with `-fcoroutines`, gcc, OpenSSL (`libcrypto`), GNU make, python3.

```bash
make lint lint-adapters       # Verilator -Wall lint of the fabric and the three adapters
make -C model test            # independent reference model self-test
make -C host test             # host library vs a software mock fabric
make suite TEST=all           # fabric + simulated device: 12 model-checked tests (TEST=<name>, SEED=, NCMD=)
make suite-xts                # optional XTS-AES-256 (ciphertext compared with OpenSSL)
make store-suite TEST=all     # real SilicaFlux-STORE chip (RISC-V firmware, BCH ECC, NAND twin), fresh NAND medium per test
make hostsw-suite TEST=all    # host-software mailbox backend + C++ software service model
make virtio-suite TEST=all    # P63 VirtIO engine + guest library + adapter (or scripts/run_virtio.sh: one process per test)
make example                  # the libsfstor tour (examples/sfs_example.c) against the simulated fabric
python3 scripts/mutate.py --work /tmp/p68_mut     # mutation check of key RTL rules (copies the tree; never edits it)
make bench                    # benchmark sweep (~80 min); python3 bench/make_report.py reports/bench_raw.txt
scripts/run_all.sh            # everything above except the benchmark; logs in reports/, summary in reports/SUMMARY.txt
```

## Layout
```
rtl/                    silicaflux_storage_fabric.sv (top) · _pkg · sf_stor_{queue,validate,sched,slot,dmaseq,xform,mover,mgmt,core,extq,lmem,...}.sv · sf_stor_be_simdev.sv
rtl/adapters/           sf_stor_be_store.sv (SilicaFlux-STORE driver) · sf_stor_be_hostsw.sv (software mailbox) · sf_stor_virtio_adapter.sv (VirtIO front end)
tb/                     generated wrappers (scripts/gen_*_top.py): fabric + STORE chip + NAND twin · fabric + host-sw adapter · fabric + P63 engine + adapter
sim/                    Verilator harness (AXI4 memory slave, independent bus monitor), verification environment, test_fabric.cpp, store_suite.cpp, hostsw_suite.cpp, virtio_test.cpp
model/                  sfref.hpp — INDEPENDENT logical block-device reference model (+ self-test, SPEC_QUESTIONS.md)
host/                   libsfstor (C99): discovery, queues, submit/poll, flush, errors, performance counters, hypervisor management helpers (+ unit test with a mock fabric)
examples/               sfs_example.c (tour) + simulation runner
bench/                  bench_fabric.cpp, make_report.py
scripts/                generators, mutation tester, evidence-run and vendoring scripts
third_party/            P59 XTS engine · P60 StorageChip · P63 VirtIO · P64 CloudDMA — vendored UNMODIFIED, hashed (MANIFEST.sha256, PROVENANCE.md)
docs/                   00 audit · 01 requirements trace · 02 host interface (normative) · 03 architecture · 04 backends/VirtIO/NVMe · 05 verification · 06 benchmarks · 07 limitations · 08 P61 integration
reports/                logs and results of the runs used for this delivery
```

## Documentation
| | |
|---|---|
| [`docs/00_AUDIT.md`](docs/00_AUDIT.md) | what existed in the repository, API and verification status (claimed vs re-run), what was reused |
| [`docs/01_REQUIREMENTS_TRACE.md`](docs/01_REQUIREMENTS_TRACE.md) | every item of the brief → implementation → evidence |
| [`docs/02_HOST_INTERFACE.md`](docs/02_HOST_INTERFACE.md) | **normative** ABI: descriptor, completion, status codes, ordering and durability rules, tenant page, management window |
| [`docs/03_ARCHITECTURE.md`](docs/03_ARCHITECTURE.md) | pipeline, modules, isolation, scheduler, per-backend data transformations, durability / PowerSafe, counters |
| [`docs/04_BACKENDS_VIRTIO_NVME.md`](docs/04_BACKENDS_VIRTIO_NVME.md) | the three backends, the VirtIO block front end, the NVMe taxonomy, the host library |
| [`docs/05_VERIFICATION.md`](docs/05_VERIFICATION.md) | strategy, oracles, results, defects found, mutation results |
| [`docs/06_BENCHMARKS.md`](docs/06_BENCHMARKS.md) | method, results, interpretation (cycle counts, simulated device) |
| [`docs/07_LIMITATIONS.md`](docs/07_LIMITATIONS.md) | the honesty ledger |
| [`docs/08_P61_INTEGRATION.md`](docs/08_P61_INTEGRATION.md) | how the fabric would plug into P61 CloudDPU (not performed) |
