// =============================================================================
// StorageFabric benchmark suite (simulated block device backend, cycle-accurate RTL simulation).
//
//   Closed-loop workloads driven through the real host library; every command is also checked against the reference model, so the
//   benchmark traffic is correctness-verified.  All numbers are in FABRIC CLOCK CYCLES: there is no frequency, wall-clock or silicon
//   claim.  Latencies are measured two ways:
//     host   : cycles from the doorbell-side submission to the host observing the CQE (polling granularity 8 cycles)
//     device : the CQE.LATENCY field (descriptor fetched -> completion posted) -- exact
//   Percentiles are nearest-rank over the samples actually collected; a percentile is reported "n/a" when fewer than 100 samples
//   (p99) exist.  Queue wait / backend time come from the trace FIFO, sampled by a separate pass of the same workload (popping the
//   FIFO over MMIO costs simulated time, so the throughput pass runs with the trace off).
//   Output: one CSV row per (workload, tenant-or-total) on stdout; the report generator renders it.
// =============================================================================
#include "tb_env.hpp"
#include <algorithm>
#include <cmath>
#include <functional>
using namespace sfsim;
// global performance counter ids (RTL package silicaflux_storage_fabric_pkg, PC_*)
enum { PC_DMA_IN_CYC = 10, PC_DMA_OUT_CYC = 11, PC_XFORM_CYC = 25, PC_BE_BUSY_CYC = 13, PC_BE_STALL_CYC = 14, PC_QWAIT_CYC = 15, PC_SLOT_BUSY_CYC = 16, PC_THROTTLE_CYC = 24 };

struct TenantWL { unsigned qd = 0; int rd_pct = 100; unsigned nblk = 8; unsigned weight = 1; unsigned max_infl = 0; unsigned rate = 0; unsigned burst = 16; bool seq = false; };
struct WL {
  std::string name;
  TenantWL t[4];
  bool rd_prio = false, wr_batch = false;
  int rd_lat = 40, wr_lat = 80, blk_lat = 2, jitter = 0;
  int media_err_lba = -1;                              // simulated device: media error on this backend LBA (error-path cost / error-rate row)
  uint64_t window = 300000, warm = 30000;
};

struct Meta { uint64_t t_submit; int op; unsigned nblk; };
struct Samples { std::vector<uint32_t> v; void add(uint32_t x) { v.push_back(x); } };
static std::string pct(Samples &s, unsigned p) {
  if (s.v.empty()) return "n/a";
  if (p == 9900 && s.v.size() < 100) return "n/a";
  std::vector<uint32_t> c = s.v; uint32_t out = 0;
  if (sfs_percentile(c.data(), c.size(), p, &out) != 0) return "n/a";
  return std::to_string(out);
}
static double mean(const Samples &s) { if (s.v.empty()) return 0; double a = 0; for (auto x : s.v) a += x; return a / s.v.size(); }

struct Res {
  uint64_t cmds[4] = {0}, blocks[4] = {0}, errs[4] = {0}, rd[4] = {0}, wr[4] = {0};
  Samples hostlat[4][2], devlat[4][2];                 // [tenant][0 = read, 1 = write]
  Samples qwait, bedur, total;                         // trace pass
  uint64_t c0[32], c1[32];
  uint64_t axi_r0 = 0, axi_r1 = 0, axi_w0 = 0, axi_w1 = 0;      // bytes seen by the testbench's independent AXI4 memory slave
};

static uint64_t perf(Tb &tb, unsigned id) { uint64_t v = 0; sfs_mgmt_perf_read(&tb.mg, id, &v); return v; }

static void run_pass(const WL &w, uint64_t seed, bool trace, Res &R, uint64_t &window_cycles) {
  Tb tb(seed, 32u << 20);
  tb.power_on(); tb.configure(true, false, 256); tb.open_all();
  tb.h.d->sim_rd_lat = w.rd_lat; tb.h.d->sim_wr_lat = w.wr_lat; tb.h.d->sim_blk_lat = w.blk_lat; tb.h.d->sim_jitter_mask = w.jitter;
  if (w.media_err_lba >= 0) { tb.h.d->sim_inj_media_en = 1; tb.h.d->sim_inj_media_lba = (uint64_t)w.media_err_lba; }
  for (unsigned t = 0; t < 4; t++) {
    sfs_tcfg_t tc{}; tc.enable_allowed = 1; tc.max_inflight = w.t[t].max_infl; tc.weight = w.t[t].weight; tc.rate = w.t[t].rate; tc.burst = w.t[t].burst;
    sfs_mgmt_tenant_cfg(&tb.mg, t, &tc);
  }
  sfs_mgmt_set_gctrl(&tb.mg, SFS_GCTRL_ENABLE | (trace ? SFS_GCTRL_TRACE_EN : 0) | (w.rd_prio ? SFS_GCTRL_RD_PRIO : 0) | (w.wr_batch ? SFS_GCTRL_WR_BATCH : 0));
  std::mt19937_64 r(seed * 977 + 5);
  const unsigned NBUF = 32;
  uint64_t bufs[4][NBUF];
  std::vector<uint8_t> base(8 * 512); for (auto &b : base) b = (uint8_t)r();
  for (unsigned t = 0; t < 4; t++) for (unsigned i = 0; i < NBUF; i++) bufs[t][i] = tb.alloc(t, 8 * 512, 64);
  // prefill every namespace so reads return real data
  uint16_t pf = 0x8000;
  for (unsigned t = 0; t < 4; t++) for (uint64_t lba = 0; lba < 256; lba += 8) {
    Cmd c; c.tenant = t; c.payload = base; Tb::build(c.w, 1, 0, pf++, t, lba, 8, bufs[t][0], t); tb.issue_wait(c); tb.ring_all(); tb.drain();
  }
  tb.drain();
  // closed-loop measurement
  std::map<std::pair<unsigned, uint16_t>, Meta> meta; unsigned out[4] = {0}; uint16_t txn[4] = {1, 1, 1, 1}; uint64_t seqp[4] = {0};
  bool measuring = false; uint64_t t_start = 0, t_end = 0;
  tb.on_done = [&](unsigned t, uint16_t x) {
    auto it = meta.find({t, x}); if (it == meta.end()) return;
    Meta m = it->second; meta.erase(it); out[t]--;
    if (!measuring) return;
    const sfs_cqe_t &cq = tb.last_cqe[{t, x}];
    R.cmds[t]++; if (cq.status != 0) R.errs[t]++;
    else if (m.op == 1 || m.op == 2) {
      int k = m.op == 2 ? 0 : 1; R.blocks[t] += m.nblk; (k == 0 ? R.rd[t] : R.wr[t])++;
      R.hostlat[t][k].add((uint32_t)(tb.h.cycles - m.t_submit)); R.devlat[t][k].add(cq.latency);
    }
  };
  uint64_t end_total = w.warm + w.window, c_start = tb.h.cycles;
  uint64_t last_pop = tb.h.cycles;
  while (tb.h.cycles - c_start < end_total) {
    if (!measuring && tb.h.cycles - c_start >= w.warm) {
      measuring = true; t_start = tb.h.cycles; for (unsigned i = 0; i < 32; i++) R.c0[i] = perf(tb, i); R.axi_r0 = tb.h.st.bytes_r; R.axi_w0 = tb.h.st.bytes_w;
      if (trace) { uint32_t e, d; sfs_mgmt_trace_status(&tb.mg, &e, &d); sfs_trace_rec_t rec; while (sfs_mgmt_trace_pop(&tb.mg, &rec) == 1) {} }
    }
    for (unsigned t = 0; t < 4; t++) {
      const TenantWL &tw = w.t[t];
      while (out[t] < tw.qd) {
        Cmd c; c.tenant = t; bool rd = (int)(r() % 100) < tw.rd_pct; unsigned n = tw.nblk;
        uint64_t lba = tw.seq ? (seqp[t] % (256 / n)) * n : (r() % (256 / n)) * n; seqp[t]++;
        uint16_t x = txn[t]++; if (x >= 0x8000) { txn[t] = 1; x = txn[t]++; }
        unsigned bi = x % NBUF;
        if (!rd) c.payload.assign(base.begin(), base.begin() + n * 512);
        Tb::build(c.w, rd ? 2 : 1, 0, x, t, lba, n, bufs[t][bi], t);
        if (w.media_err_lba >= 0 && rd && t == 0 && (uint64_t)w.media_err_lba >= lba && (uint64_t)w.media_err_lba < lba + n) c.ov_status = 0x0C;   // MEDIA_ERROR is expected for exactly these reads
        if (!tb.issue_try(c)) break;
        meta[{t, x}] = {tb.h.cycles, rd ? 2 : 1, n}; out[t]++;
      }
    }
    tb.ring_all(); tb.h.run(4); tb.poll_all();
    if (trace && measuring && tb.h.cycles - last_pop > 2000) {
      last_pop = tb.h.cycles;
      sfs_trace_rec_t rec; int guard = 0;
      while (guard++ < 80 && sfs_mgmt_trace_pop(&tb.mg, &rec) == 1)
        if (rec.opcode == 1 || rec.opcode == 2) { R.qwait.add(sfs_trace_queue_wait(&rec)); R.bedur.add(rec.cyc_be_done - rec.cyc_issue); R.total.add(rec.cyc_post - rec.cyc_fetch); }
    }
  }
  t_end = tb.h.cycles; window_cycles = t_end - t_start;
  for (unsigned i = 0; i < 32; i++) R.c1[i] = perf(tb, i);
  R.axi_r1 = tb.h.st.bytes_r; R.axi_w1 = tb.h.st.bytes_w;
  tb.drain(); tb.on_done = nullptr;
  if (tb.st.fails) printf("# WARNING: %llu model/monitor failures in workload %s\n", (unsigned long long)tb.st.fails, w.name.c_str());
  if (tb.h.st.violations) printf("# WARNING: bus isolation violations in workload %s\n", w.name.c_str());
}

static double jain(const std::vector<double> &x) { double s = 0, s2 = 0; for (double v : x) { s += v; s2 += v * v; } return s2 > 0 ? s * s / (x.size() * s2) : 0; }

static void report(const WL &w, uint64_t seed) {
  Res R; uint64_t cyc = 0, cyc2 = 0;
  run_pass(w, seed, false, R, cyc);
  Res T; run_pass(w, seed, true, T, cyc2);
  auto d = [&](unsigned id) { return (double)(R.c1[id] - R.c0[id]); };
  uint64_t cmds = 0, blocks = 0, errs = 0, rd = 0, wr = 0; Samples hl[2], dl[2];
  std::vector<double> share; std::vector<unsigned> active;
  for (unsigned t = 0; t < 4; t++) {
    cmds += R.cmds[t]; blocks += R.blocks[t]; errs += R.errs[t]; rd += R.rd[t]; wr += R.wr[t];
    for (int k = 0; k < 2; k++) { for (auto x : R.hostlat[t][k].v) hl[k].add(x); for (auto x : R.devlat[t][k].v) dl[k].add(x); }
    if (w.t[t].qd) { active.push_back(t); share.push_back((double)R.blocks[t] / std::max(1u, w.t[t].weight)); }
  }
  double Mc = cyc / 1e6;
  // header-less CSV; columns documented in bench/make_report.py
  auto row = [&](const char *scope, unsigned t, uint64_t c, uint64_t b, uint64_t e, uint64_t nrd, uint64_t nwr, Samples *h, Samples *dv) {
    printf("ROW,%s,%s,%u,%llu,%llu,%.1f,%.4f,%llu,%.4f,%llu,%llu,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n", w.name.c_str(), scope, t, (unsigned long long)cyc, (unsigned long long)c,
           c / Mc, (double)b * 512 / cyc, (unsigned long long)e, c ? (double)e / c : 0.0, (unsigned long long)nrd, (unsigned long long)nwr,
           pct(h[0], 5000).c_str(), pct(h[0], 9900).c_str(), pct(h[0], 10000).c_str(), pct(h[1], 5000).c_str(), pct(h[1], 9900).c_str(), pct(h[1], 10000).c_str(),
           pct(dv[0], 5000).c_str(), pct(dv[0], 9900).c_str(), pct(dv[0], 10000).c_str(), pct(dv[1], 5000).c_str(), pct(dv[1], 9900).c_str(), pct(dv[1], 10000).c_str());
  };
  row("total", 99, cmds, blocks, errs, rd, wr, hl, dl);
  for (unsigned t : active) row("tenant", t, R.cmds[t], R.blocks[t], R.errs[t], R.rd[t], R.wr[t], R.hostlat[t], R.devlat[t]);
  printf("SYS,%s,%llu,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.3f,%zu,%.1f,%s,%s,%.1f,%s,%.1f,%s,%s\n", w.name.c_str(), (unsigned long long)cyc,
         d(PC_BE_BUSY_CYC) / cyc, d(PC_BE_STALL_CYC) / cyc, d(PC_DMA_IN_CYC) / cyc, d(PC_DMA_OUT_CYC) / cyc, (double)(R.axi_r1 - R.axi_r0) / cyc, (double)(R.axi_w1 - R.axi_w0) / cyc, d(PC_XFORM_CYC) / cyc, d(PC_SLOT_BUSY_CYC) / cyc,
         d(PC_QWAIT_CYC) / cyc, d(PC_THROTTLE_CYC) / cyc, jain(share), T.qwait.v.size(), mean(T.qwait), pct(T.qwait, 9900).c_str(), pct(T.qwait, 10000).c_str(),
         mean(T.bedur), pct(T.bedur, 9900).c_str(), mean(T.total), pct(T.total, 9900).c_str(), pct(T.total, 10000).c_str());
  fflush(stdout);
}

int main(int argc, char **argv) {
  Harness::set_args(argc, argv);
  std::string which = argc > 1 ? argv[1] : "all";
  uint64_t seed = argc > 2 ? strtoull(argv[2], nullptr, 0) : 1;
  uint64_t scale = argc > 3 ? strtoull(argv[3], nullptr, 0) : 100;          // window length in percent of the default
  std::vector<WL> wls;
  auto single = [&](const char *nm, unsigned qd, int rd_pct, unsigned nblk, bool seq = false) {
    WL w; w.name = nm; w.t[0].qd = qd; w.t[0].rd_pct = rd_pct; w.t[0].nblk = nblk; w.t[0].seq = seq; wls.push_back(w);
  };
  // 1. queue-depth sweep, 4 KiB random read / write / 70-30 mix (one tenant)
  for (unsigned qd : {1u, 2u, 4u, 8u, 16u}) { char b[64]; snprintf(b, sizeof b, "rr4k_qd%u", qd); single(b, qd, 100, 8); }
  for (unsigned qd : {1u, 4u, 16u}) { char b[64]; snprintf(b, sizeof b, "rw4k_qd%u", qd); single(b, qd, 0, 8); }
  for (unsigned qd : {1u, 4u, 16u}) { char b[64]; snprintf(b, sizeof b, "mix70r_4k_qd%u", qd); single(b, qd, 70, 8); }
  // 2. transfer-size sweep at QD 8
  for (unsigned n : {1u, 2u, 4u, 8u}) { char b[64]; snprintf(b, sizeof b, "rr_%ublk_qd8", n); single(b, 8, 100, n); }
  for (unsigned n : {1u, 4u, 8u}) { char b[64]; snprintf(b, sizeof b, "sw_%ublk_qd8", n); single(b, 8, 0, n, true); }
  { WL w; w.name = "rr4k_qd8_media_error_lba5"; w.t[0].qd = 8; w.t[0].nblk = 8; w.media_err_lba = 5; wls.push_back(w); }     // ~1 in 32 reads hits the bad block
  // 3. backend latency sensitivity (4 KiB random read, QD 8)
  for (int lat : {10, 100, 400}) { WL w; char b[64]; snprintf(b, sizeof b, "rr4k_qd8_belat%d", lat); w.name = b; w.t[0].qd = 8; w.t[0].nblk = 8; w.rd_lat = lat; w.wr_lat = lat * 2; wls.push_back(w); }
  // 4. scheduler modes under a mixed load (reads QD 4 vs writes QD 16, one tenant each of 4: tenants 0/1 read-heavy, 2/3 write-heavy)
  for (int mode = 0; mode < 4; mode++) {
    WL w; char b[64]; snprintf(b, sizeof b, "sched_%s%s", (mode & 1) ? "rdprio" : "fifo", (mode & 2) ? "+wrbatch" : ""); w.name = b;
    w.rd_prio = mode & 1; w.wr_batch = mode & 2; w.rd_lat = 60; w.wr_lat = 160;
    w.t[0].qd = 4; w.t[0].rd_pct = 100; w.t[1].qd = 4; w.t[1].rd_pct = 100; w.t[2].qd = 16; w.t[2].rd_pct = 0; w.t[3].qd = 16; w.t[3].rd_pct = 0;
    wls.push_back(w);
  }
  // 5. fairness: four equal tenants; weights 1:1:2:4; one noisy neighbour against three light tenants; token-bucket quota on the noisy tenant
  { WL w; w.name = "fair_equal4"; for (auto &t : w.t) { t.qd = 8; t.rd_pct = 70; } wls.push_back(w); }
  { WL w; w.name = "fair_weights_1_1_2_4"; unsigned wt[4] = {1, 1, 2, 4}; for (int i = 0; i < 4; i++) { w.t[i].qd = 8; w.t[i].rd_pct = 70; w.t[i].weight = wt[i]; } wls.push_back(w); }
  { WL w; w.name = "noisy_neighbour_unlimited"; w.t[0].qd = 32; w.t[0].rd_pct = 0; for (int i = 1; i < 4; i++) { w.t[i].qd = 2; w.t[i].rd_pct = 100; } wls.push_back(w); }
  { WL w; w.name = "noisy_neighbour_inflight_cap2"; w.t[0].qd = 32; w.t[0].rd_pct = 0; w.t[0].max_infl = 2; for (int i = 1; i < 4; i++) { w.t[i].qd = 2; w.t[i].rd_pct = 100; } wls.push_back(w); }
  // saturated system moves about 7.6 blocks per 1024 cycles, so a 2-block-per-1024-cycles bucket actually binds the aggressor
  { WL w; w.name = "noisy_neighbour_rate_cap"; w.t[0].qd = 32; w.t[0].rd_pct = 0; w.t[0].rate = 2; w.t[0].burst = 8; for (int i = 1; i < 4; i++) { w.t[i].qd = 2; w.t[i].rd_pct = 100; } wls.push_back(w); }
  // reference: the three light tenants alone (what they would see without a noisy neighbour)
  { WL w; w.name = "noisy_neighbour_victims_only"; for (int i = 1; i < 4; i++) { w.t[i].qd = 2; w.t[i].rd_pct = 100; } wls.push_back(w); }
  printf("# seed=%llu scale=%llu%%  (cycles are fabric clock cycles; simulated block device)\n", (unsigned long long)seed, (unsigned long long)scale);
  printf("# ROW cols: workload,scope,tenant,window_cycles,cmds,iops_per_Mcycle,bytes_per_cycle,errors,error_rate,reads,writes,host_rd_p50,p99,max,host_wr_p50,p99,max,dev_rd_p50,p99,max,dev_wr_p50,p99,max\n");
  printf("# SYS cols: workload,window_cycles,be_busy,be_stall,dma_in,dma_out,axi_rd_B_per_cycle,axi_wr_B_per_cycle,xform_busy,slot_occupancy,queue_wait_heads,throttle,jain_by_weight,trace_samples,qwait_mean,qwait_p99,qwait_max,bedur_mean,bedur_p99,total_mean,total_p99,total_max\n");
  for (auto &w : wls) {
    if (which != "all" && w.name.find(which) == std::string::npos) continue;
    WL x = w;
    bool lat_focus = w.name.rfind("rr4k_qd", 0) == 0 || w.name.rfind("rw4k_qd", 0) == 0 || w.name.rfind("mix70r", 0) == 0 || w.name.rfind("sched_", 0) == 0 ||
                     w.name.rfind("noisy_", 0) == 0 || w.name.rfind("fair_", 0) == 0;
    if (lat_focus && w.name.find("belat") == std::string::npos) x.window = 1500000;       // long enough for >= 100 samples per direction at the saturated rate
    x.window = x.window * scale / 100; x.warm = x.warm * scale / 100;
    report(x, seed);
  }
  return 0;
}
