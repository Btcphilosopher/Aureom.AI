"""sfperf -- analysis tooling for the SilicaFlux performance-monitoring subsystem."""
__version__ = "1.0.0"
