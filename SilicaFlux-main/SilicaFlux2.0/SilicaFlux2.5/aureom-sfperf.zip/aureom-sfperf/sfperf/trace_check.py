#!/usr/bin/env python3
"""Independent trace-level checker for the SilicaFlux performance monitor.

Re-derives all 57 counters (plus FLAGS and the overflow bitmap) from the raw per-cycle tap trace
(`trace.csv`) and the CSR command log (`cmds.csv`) and compares the result with the values the hardware
actually produced (`snapshots.csv`).

Independence rule: this file is written ONLY from docs/METRICS.md (Part B definitions, Part C file formats),
spec/pm_counters.json (via sfperf/spec.py) and the data files.  It deliberately knows nothing about the RTL.
Section letters in comments (`# B.3` ...) cite docs/METRICS.md.

Usage (from the project root):
    python3 -m sfperf.trace_check DIR [DIR ...]  [--summary] [--limit N] [--cmd-offset K]

DIR is a directory holding trace.csv / cmds.csv / snapshots.csv.  A DIR without trace.csv is searched
recursively for such directories.  Exit status is 0 only if every directory passes.

History of the interpretation choices.  The first version of this file was written against an earlier METRICS.md and
listed thirteen ambiguities (A1-A13).  Those that mattered were resolved IN THE SPEC afterwards and are now normative
(B.2, B.6, B.7, Part C); this file follows the current text.  Remaining notes:
  * `cmd_cycle` (snapshots.csv) equals `cycle` (cmds.csv): CMD_OFFSET = 0 (it was off by one in the first testbench; fixed).
  * the trace `cycle` column is decimal and must be contiguous.
  * CLEAR and SNAP_CLR clear the sticky overflow bits; SNAPSHOT does not (B.6).
  * `snap_trig` is not represented in trace files and is assumed never asserted; every snapshot row must match a command,
    except commands named `NOREAD` (snapshot commands whose shadow was deliberately not read back).
  * `seq`/`seq_after` are not checked here (their definition is in Part C; the unit testbench checks SNAP_SEQ directly).
  * the `en` column is cross-checked against the ENABLE bit of the CTRL writes: en[E+1] == bit 0 of the last CTRL write
    executed at an edge <= E.
Coverage limits of this checker are listed in docs/VERIFICATION.md section 3.
"""
from __future__ import annotations

import argparse
import csv
import os
import sys

try:
    from .spec import NAMES, INDEX, KIND, SLOT_NAMES, CLASS_NAMES, NT, LANES, SPEC
except ImportError:  # executed as a plain script instead of `-m sfperf.trace_check`
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from sfperf.spec import NAMES, INDEX, KIND, SLOT_NAMES, CLASS_NAMES, NT, LANES, SPEC

# --------------------------------------------------------------------------------------------------------------
# Constants taken from the spec
# --------------------------------------------------------------------------------------------------------------
CW = SPEC["counter_width_default"]          # counter width (40); saturation value 2^CW - 1 (B.5 last paragraph)
CMAX = (1 << CW) - 1
NOPROG_MAX = (1 << 32) - 1                  # B.7: noprog is a 32-bit saturating counter

CTRL_SHADOW = 2                             # B.2: redirect shadow depth
OPC_HALT = 0x1F                             # B.2
OPC_DFSYNC = 0x0E                           # B.3 / B.5

# CTRL write data bits (C)
CTRL_ENABLE = 1 << 0
CTRL_SNAPSHOT = 1 << 8
CTRL_SNAP_CLR = 1 << 9
CTRL_CLEAR = 1 << 10

# FLAGS bits (B.7)
FLAG_OVF_ANY = 1 << 0
FLAG_WDOG_TRIP = 1 << 1
FLAG_PROG_DONE = 1 << 2

# B.4 issue-class table: opcode -> counter name; every other opcode is ISS_NOP.
ISSUE_CLASS = {}
for _ops, _name in (
    ((0x01, 0x02, 0x03, 0x06), "ISS_SALU"),
    ((0x04, 0x05), "ISS_SMEM"),
    ((0x07, 0x08, 0x09), "ISS_BRANCH"),
    ((0x0A, 0x0B, 0x16, 0x17), "ISS_DFMEM"),
    ((0x0C, 0x0D, 0x0E), "ISS_DFCTL"),
    ((0x0F, 0x10, 0x11, 0x12, 0x14, 0x15), "ISS_VEC"),
    ((0x13,), "ISS_TENSOR"),
):
    for _op in _ops:
        ISSUE_CLASS[_op] = _name

STALL_SLOTS = ("SLOT_STALL_DEP", "SLOT_STALL_SYNC", "SLOT_STALL_EXEC_VEC",
               "SLOT_STALL_EXEC_TENSOR", "SLOT_STALL_MEM", "SLOT_STALL_DISP_OTHER")   # B.3 is_stall_slot

# C: trace.csv columns, in order
TRACE_COLS = ("cycle en is_valid is_opcode id_stall load_use sync_stall flush br_taken ex_valid ex_opcode wb_valid "
              "sched_valid sched_ready tok_valid tgt_tile tile_busy tile_done tile_state vec_issue lane_active "
              "tensor_busy mem_fire mem_blocked mem_resp mem_align noc_occ noc_inj_fire noc_inj_blocked").split()
SNAP_HDR = ["seq", "seq_after", "cmd_cycle", "is_window", "flags", "ovf0", "ovf1"]

CMD_OFFSET = 0                              # A1 resolved: snapshots.csv:cmd_cycle == cmds.csv:cycle (testbench fixed)


class CheckError(Exception):
    """Malformed input file (not a counter mismatch)."""


def popcount(x: int) -> int:
    return bin(x).count("1")


# --------------------------------------------------------------------------------------------------------------
# File parsing (Part C)
# --------------------------------------------------------------------------------------------------------------
def read_trace(path):
    """Return a list of dicts, one per clock edge.  Every column except `cycle` is hex (C); AMBIGUITY A2."""
    rows = []
    with open(path, newline="") as f:
        rd = csv.reader(f)
        hdr = [h.strip() for h in next(rd)]
        if hdr != TRACE_COLS:
            raise CheckError(f"{path}: unexpected header {hdr}")
        for ln, raw in enumerate(rd, start=2):
            if len(raw) != len(TRACE_COLS):
                raise CheckError(f"{path}:{ln}: expected {len(TRACE_COLS)} columns, got {len(raw)}")
            r = {}
            for name, txt in zip(TRACE_COLS, raw):
                r[name] = int(txt) if name == "cycle" else int(txt, 16)
            if r["cycle"] != len(rows):
                raise CheckError(f"{path}:{ln}: cycle {r['cycle']} not contiguous (expected {len(rows)})")
            rows.append(r)
    return rows


def read_cmds(path):
    """Return {edge: [(name, value), ...]} in file order."""
    cmds = {}
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            cmds.setdefault(int(r["cycle"]), []).append((r["name"].strip(), int(r["value_hex"], 16)))
    return cmds


def read_snapshots(path):
    """Return a list of dicts: header fields (ints) plus 'counters' = {name: int}."""
    snaps = []
    with open(path, newline="") as f:
        rd = csv.reader(f)
        hdr = [h.strip() for h in next(rd)]
        if hdr[:len(SNAP_HDR)] != SNAP_HDR:
            raise CheckError(f"{path}: unexpected snapshot header prefix {hdr[:len(SNAP_HDR)]}")
        if hdr[len(SNAP_HDR):] != NAMES:      # counter order = spec/pm_counters.json (C)
            raise CheckError(f"{path}: counter columns do not match spec/pm_counters.json order")
        for ln, raw in enumerate(rd, start=2):
            if len(raw) != len(hdr):
                raise CheckError(f"{path}:{ln}: expected {len(hdr)} columns, got {len(raw)}")
            s = {"seq": int(raw[0]), "seq_after": int(raw[1]), "cmd_cycle": int(raw[2]),
                 "is_window": int(raw[3]), "flags": int(raw[4], 16),
                 "ovf0": int(raw[5], 16), "ovf1": int(raw[6], 16)}
            s["counters"] = {n: int(v) for n, v in zip(NAMES, raw[len(SNAP_HDR):])}
            snaps.append(s)
    return snaps


# --------------------------------------------------------------------------------------------------------------
# Reference model: one object holds the B.2 tracking state, the live counters, and the B.6/B.7 window state
# --------------------------------------------------------------------------------------------------------------
class Model:
    def __init__(self):
        # B.2 tracking state -- updated on every edge, independent of ENABLE, not touched by CLEAR (A3)
        self.prog_done = 0
        self.redir = 0               # CTRL_SHADOW-bit shift register: bit0 = flush 1 cycle ago, bit1 = 2 cycles ago
        self.mem_out = 0             # NT+1 bits, one per memory controller (bit NT = control core)
        self.ex_fresh = 0
        self.mem_fresh = 0
        self.wb_fresh = 0
        # counting state -- B.2 streak, B.7 watchdog, B.6 live counters
        self.streak = 0
        self.noprog = 0
        self.trip = 0
        self.thresh = 0              # WDOG_THRESH, reset value 0 == disabled (B.7: "thresh != 0")
        self.live = [0] * len(NAMES)
        self.ovf = [0] * len(NAMES)  # sticky per-counter overflow bits (B.5 last paragraph)

    # ---- B.3 ---------------------------------------------------------------------------------------------
    def classify(self, r):
        """Exactly one slot per cycle, first match wins.  Uses pre-edge taps and pre-edge tracking state."""
        if self.prog_done:                                           # B.3: prog_done -> IDLE
            return "SLOT_IDLE"
        if r["flush"]:
            return "SLOT_BUBBLE_CTRL"
        if r["id_stall"]:
            if r["sync_stall"]:
                return "SLOT_STALL_SYNC"
            if r["load_use"]:
                return "SLOT_STALL_DEP"
            if r["sched_valid"] and not r["sched_ready"]:
                if r["ex_opcode"] == OPC_DFSYNC:                     # DFSYNC held at dispatch is the barrier waiting
                    return "SLOT_STALL_SYNC"
                tgt = r["tgt_tile"]
                blk = (r["tile_state"] >> (3 * tgt)) & 7 if tgt < NT else None   # tile_state: 3 bits per tile
                if blk == 1:
                    return "SLOT_STALL_MEM"
                if blk == 2:
                    return "SLOT_STALL_EXEC_VEC"
                if blk == 3:
                    return "SLOT_STALL_EXEC_TENSOR"
                return "SLOT_STALL_DISP_OTHER"                       # idle/other state or tgt_tile out of range
            return "SLOT_STALL_DISP_OTHER"                           # "unreachable on a consistent core"
        if r["is_valid"]:
            return "SLOT_ISSUE"
        if self.redir:                                               # shadow_any = shadow[0] | shadow[1]
            return "SLOT_BUBBLE_CTRL"
        if r["ex_valid"] or r["tile_busy"] != 0 or self.mem_out != 0:   # mach_busy (B.2)
            return "SLOT_BUBBLE_FRONT"
        return "SLOT_IDLE"

    # ---- B.5 ---------------------------------------------------------------------------------------------
    def events(self, r, slot, streak_next):
        """Event value each counter receives in a counted cycle (B.5).  Every counter is assigned explicitly."""
        ev = {}
        ev["CYCLES"] = 1
        for n in SLOT_NAMES:                                         # SLOT_*: 1 for the classified slot
            ev[n] = 1 if n == slot else 0
        cls = ISSUE_CLASS.get(r["is_opcode"], "ISS_NOP") if slot == "SLOT_ISSUE" else None   # B.4
        for n in CLASS_NAMES:                                        # ISS_*: only on ISSUE slots
            ev[n] = 1 if n == cls else 0
        ev["RET_SCALAR"] = r["wb_valid"] & self.wb_fresh
        ev["RET_TILE"] = popcount(r["tile_done"])
        ev["TOK_DISPATCHED"] = popcount(r["tok_valid"])
        drop = r["sched_valid"] & r["sched_ready"] & (1 if r["tok_valid"] == 0 else 0)
        is_sync = 1 if r["ex_opcode"] == OPC_DFSYNC else 0
        ev["DROP_SYNC"] = drop & is_sync
        ev["DROP_OP"] = drop & (1 - is_sync)
        ev["BRANCH_TAKEN"] = r["br_taken"]
        for t in range(NT):
            ev[f"TILE_TOK_{t}"] = (r["tok_valid"] >> t) & 1
            ev[f"TILE_BUSY_{t}"] = (r["tile_busy"] >> t) & 1
        lanes_active = partial = 0
        for t in range(NT):
            if (r["vec_issue"] >> t) & 1:
                pc = popcount((r["lane_active"] >> (LANES * t)) & ((1 << LANES) - 1))
                lanes_active += pc
                if 0 < pc < LANES:
                    partial += 1
        ev["VEC_ISSUES"] = popcount(r["vec_issue"])
        ev["VEC_LANES_ACTIVE"] = lanes_active
        ev["VEC_ISSUES_PARTIAL"] = partial
        ev["VEC_BUSY_CYC"] = sum(1 for t in range(NT) if ((r["tile_state"] >> (3 * t)) & 7) == 2)
        ev["TENSOR_BUSY_CYC"] = popcount(r["tensor_busy"])
        ev["MEM_REQ_ACCEPTED"] = popcount(r["mem_fire"])
        ev["MEM_RESP"] = popcount(r["mem_resp"])
        ev["MEM_REQ_BLOCKED"] = popcount(r["mem_blocked"])
        ev["MEM_ALIGN_ERR"] = popcount(r["mem_align"])
        moc = popcount(self.mem_out)                                 # state value at the start of the cycle
        ev["MEM_OUT_SUM"] = moc
        ev["MEM_BUSY_CYC"] = 1 if moc != 0 else 0
        ev["MEM_OUT_PEAK"] = moc
        ev["MEM_OUT_NOW"] = moc
        ev["Q_DISP_SUM"] = r["sched_valid"]
        ev["Q_DISP_NOW"] = r["sched_valid"]
        tb = popcount(r["tile_busy"])
        ev["Q_TOK_SUM"] = ev["Q_TOK_PEAK"] = ev["Q_TOK_NOW"] = tb
        ev["Q_NOC_SUM"] = ev["Q_NOC_PEAK"] = ev["Q_NOC_NOW"] = r["noc_occ"]
        ev["NOC_FLITS"] = popcount(r["noc_inj_fire"])
        ev["NOC_INJ_BLOCKED"] = popcount(r["noc_inj_blocked"])
        ev["STALL_STREAK_MAX"] = streak_next                         # value streak' takes this cycle
        if set(ev) != set(NAMES):                                    # guard: an unassigned counter is a checker bug
            raise AssertionError(f"events() missing {set(NAMES) - set(ev)} extra {set(ev) - set(NAMES)}")
        return ev

    def _apply(self, ev):
        """Fold one counted cycle's event values into the live counters according to the counter kind (B.5)."""
        live, ovf = self.live, self.ovf
        for n, v in ev.items():
            i = INDEX[n]
            k = KIND[n]
            if k in ("count", "sum"):                                # accumulate, saturating, sticky overflow bit
                nv = live[i] + v
                if nv > CMAX:
                    nv = CMAX
                    ovf[i] = 1
                live[i] = nv
            elif k == "peak":                                        # running max within the epoch
                if v > live[i]:
                    live[i] = v
            elif k == "gauge":                                       # last event value
                live[i] = v
            else:
                raise CheckError(f"unknown counter kind {k!r} for {n}")

    # ---- one clock edge ----------------------------------------------------------------------------------
    def step(self, r, ctrl, wdog):
        """Process edge r.  `ctrl` = CTRL write data executed at this edge or None, `wdog` = new WDOG_THRESH or None.
        Returns None, or a snapshot capture dict {'is_window', 'flags', 'values'} for a SNAPSHOT / SNAP_CLR edge."""
        counted = bool(r["en"])                                      # ENABLE before this edge (Conventions)
        slot = self.classify(r)                                      # B.3 (also needed for tracking when not counted)
        is_stall = slot in STALL_SLOTS

        # B.2 streak' / B.7 noprog' / WDOG_TRIP, only meaningful on counted cycles
        streak_next = self.streak + 1 if is_stall else 0
        progress = ((slot == "SLOT_ISSUE") or bool(r["wb_valid"] & self.wb_fresh)
                    or r["tile_done"] != 0 or r["tok_valid"] != 0)   # B.7
        noprog_next = 0 if progress else min(self.noprog + 1, NOPROG_MAX)
        trip_next = self.trip
        if self.thresh != 0 and not progress and noprog_next >= self.thresh:
            trip_next = 1                                            # sticky; uses the threshold written BEFORE this edge

        ctrl = 0 if ctrl is None else ctrl
        do_clear = bool(ctrl & CTRL_CLEAR)
        do_snapclr = bool(ctrl & CTRL_SNAP_CLR) and not do_clear     # B.6 precedence CLEAR > SNAP_CLR > SNAPSHOT
        do_snap = bool(ctrl & CTRL_SNAPSHOT) and not do_clear and not do_snapclr

        capture = None
        if do_clear:
            # B.6 CLEAR: counters and overflow bits -> 0; events of this cycle are discarded; streak/watchdog restart.
            self.live = [0] * len(NAMES)
            self.ovf = [0] * len(NAMES)
            self.streak = 0
            self.noprog = 0
            self.trip = 0
        else:
            if do_snap or do_snapclr:
                # B.6: shadow receives the live values BEFORE this edge; B.7: FLAGS are also pre-edge values.
                flags = ((FLAG_OVF_ANY if any(self.ovf) else 0)
                         | (FLAG_WDOG_TRIP if self.trip else 0)
                         | (FLAG_PROG_DONE if self.prog_done else 0))
                capture = {"is_window": do_snapclr, "flags": flags,
                           "values": dict(zip(NAMES, self.live)), "ovf": list(self.ovf)}
            if do_snapclr:
                # B.6 SNAP_CLR: live counters restart as value := event(E) if counting else 0, and the overflow
                # bits restart with them (a SNAP_CLR window is a new epoch).  Nothing overflows in the shipped data.
                self.live = [0] * len(NAMES)
                self.ovf = [0] * len(NAMES)
            if counted:
                self._apply(self.events(r, slot, streak_next))
                self.streak = streak_next                            # B.2: updated only on counted cycles
                self.noprog = noprog_next                            # B.7: only on counted cycles
                self.trip = trip_next
            # SNAP_CLR does NOT clear streak / noprog / WDOG_TRIP (B.2, B.7)

        # B.2 tracking state, every edge, independent of ENABLE and CLEAR.  All updates use pre-edge values.
        new_prog_done = self.prog_done | (1 if (slot == "SLOT_ISSUE" and r["is_opcode"] == OPC_HALT) else 0)
        new_redir = ((self.redir & 1) << 1) | r["flush"]                 # shadow' = {shadow[0], flush}
        new_mem_out = 0
        for c in range(NT + 1):
            fire = (r["mem_fire"] >> c) & 1
            resp = (r["mem_resp"] >> c) & 1
            cur = (self.mem_out >> c) & 1
            new_mem_out |= (1 if fire else (0 if resp else cur)) << c
        new_ex_fresh = 1 if slot == "SLOT_ISSUE" else 0
        new_mem_fresh = self.ex_fresh & r["ex_valid"] & (1 - r["sched_valid"])
        new_wb_fresh = self.mem_fresh
        self.prog_done, self.redir, self.mem_out = new_prog_done, new_redir, new_mem_out
        self.ex_fresh, self.mem_fresh, self.wb_fresh = new_ex_fresh, new_mem_fresh, new_wb_fresh

        if wdog is not None:                                         # B.7: takes effect for the following edge
            self.thresh = wdog
        return capture


# --------------------------------------------------------------------------------------------------------------
# Directory check
# --------------------------------------------------------------------------------------------------------------
class Result:
    def __init__(self, path):
        self.path = path
        self.nsnap = 0
        self.mismatches = []          # (snapshot_index, cmd_cycle, counter, expected, got)
        self.error = None
        self.notes = []

    @property
    def ok(self):
        return self.error is None and not self.mismatches


def check_dir(path, cmd_offset=CMD_OFFSET):
    res = Result(path)
    try:
        trace = read_trace(os.path.join(path, "trace.csv"))
        cmds = read_cmds(os.path.join(path, "cmds.csv"))
        snaps = read_snapshots(os.path.join(path, "snapshots.csv"))
    except (OSError, CheckError, ValueError, KeyError, StopIteration) as e:
        res.error = f"{type(e).__name__}: {e}"
        return res
    res.nsnap = len(snaps)
    mm = res.mismatches

    # ---- replay the trace (B.2-B.7) ------------------------------------------------------------------------
    model = Model()
    captures = {}                       # edge E -> capture
    ctrl_state = 0                      # ENABLE bit as written by the last CTRL write (for the A8 cross-check)
    en_bad = []
    noread = set()
    for e, r in enumerate(trace):
        # A8: en[e] must be the ENABLE bit written at an edge < e (0 after reset)
        if r["en"] != ctrl_state:
            en_bad.append((e, ctrl_state, r["en"]))
        ctrl = wdog = None
        for name, val in cmds.get(e, ()):
            if name == "WDOG":                                       # A9
                wdog = val
            else:
                if name == "NOREAD": noread.add(e)                   # snapshot command whose shadow was deliberately not read
                if ctrl is not None:
                    res.error = f"more than one CTRL write at edge {e} (precedence between writes is unspecified)"
                    return res
                ctrl = val
        cap = model.step(r, ctrl, wdog)
        if ctrl is not None:
            ctrl_state = ctrl & CTRL_ENABLE
        if cap is not None:
            captures[e] = cap
    for e in cmds:
        if e >= len(trace):
            res.notes.append(f"command at edge {e} lies beyond the trace (len {len(trace)})")
    for e, want, got in en_bad[:3]:
        mm.append((-1, e, "en(trace)_vs_ENABLE(cmds)", want, got))

    # ---- match snapshot rows to snapshot edges and compare --------------------------------------------------
    used = set()
    for idx, s in enumerate(snaps):
        E = s["cmd_cycle"] + cmd_offset                              # A1
        cap = captures.get(E)
        if cap is None:
            mm.append((idx, s["cmd_cycle"], "SNAPSHOT_EDGE", "SNAPSHOT/SNAP_CLR cmd at edge %d" % E, "none"))
            continue
        used.add(E)
        cc = s["cmd_cycle"]
        if int(cap["is_window"]) != s["is_window"]:                  # A10
            mm.append((idx, cc, "is_window", int(cap["is_window"]), s["is_window"]))
        exp = cap["values"]
        got = s["counters"]
        for n in NAMES:                                              # counter order of pm_counters.json
            if exp[n] != got[n]:
                mm.append((idx, cc, n, exp[n], got[n]))
        # B.7 FLAGS
        if cap["flags"] != s["flags"]:
            mm.append((idx, cc, "FLAGS", f"0x{cap['flags']:08x}", f"0x{s['flags']:08x}"))
        # overflow bitmap: no counter reaches 2^CW in these runs, so it must be zero (and it must match the model)
        exp_ovf = sum(b << i for i, b in enumerate(cap["ovf"]))
        got_ovf = s["ovf0"] | (s["ovf1"] << 32)
        if exp_ovf != got_ovf:
            mm.append((idx, cc, "OVF", f"0x{exp_ovf:016x}", f"0x{got_ovf:016x}"))
        # identities I1: sum(SLOT_*) == CYCLES ; sum(ISS_*) == SLOT_ISSUE  (checked on the hardware values)
        ssum = sum(got[n] for n in SLOT_NAMES)
        if ssum != got["CYCLES"]:
            mm.append((idx, cc, "I1:sum(SLOT_*)==CYCLES", got["CYCLES"], ssum))
        isum = sum(got[n] for n in CLASS_NAMES)
        if isum != got["SLOT_ISSUE"]:
            mm.append((idx, cc, "I2:sum(ISS_*)==SLOT_ISSUE", got["SLOT_ISSUE"], isum))
        # same identities on the model itself (a failure here means a bug in THIS file)
        assert sum(exp[n] for n in SLOT_NAMES) == exp["CYCLES"], "model violates I1"
        assert sum(exp[n] for n in CLASS_NAMES) == exp["SLOT_ISSUE"], "model violates I2"
    for E in sorted(set(captures) - used - noread):
        mm.append((-1, E - cmd_offset, "SNAPSHOT_ROW", "row for command at edge %d" % E, "missing"))
    mm.sort(key=lambda m: m[1])                                      # by cmd_cycle; stable, counter order kept
    return res


# --------------------------------------------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------------------------------------------
def find_dirs(arg):
    """DIR itself if it holds trace.csv, else every descendant directory that does."""
    if os.path.isfile(os.path.join(arg, "trace.csv")):
        return [arg]
    found = []
    for root, dirs, files in os.walk(arg):
        dirs.sort()
        if "trace.csv" in files:
            found.append(root)
    return found or [arg]


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python3 -m sfperf.trace_check",
                                 description="Independent re-derivation of the perf-monitor counters from trace.csv.")
    ap.add_argument("dirs", nargs="+", metavar="DIR", help="directory with trace.csv, cmds.csv, snapshots.csv")
    ap.add_argument("--summary", action="store_true", help="print one line per directory only")
    ap.add_argument("--limit", type=int, default=10, help="mismatches to print per failing directory (0 = all)")
    ap.add_argument("--cmd-offset", type=int, default=CMD_OFFSET,
                    help="edge = snapshots.csv cmd_cycle + this (default %(default)s; see ambiguity A1)")
    args = ap.parse_args(argv)

    dirs = []
    for d in args.dirs:
        dirs.extend(find_dirs(d))
    n_ok = n_snap = 0
    for d in dirs:
        res = check_dir(d, args.cmd_offset)
        n_snap += res.nsnap
        if res.ok:
            n_ok += 1
            print(f"PASS  {d}  snapshots={res.nsnap}")
        elif res.error:
            print(f"FAIL  {d}  snapshots={res.nsnap}  error: {res.error}")
        else:
            print(f"FAIL  {d}  snapshots={res.nsnap}  mismatches={len(res.mismatches)}")
            if not args.summary:
                shown = res.mismatches if args.limit == 0 else res.mismatches[:args.limit]
                for (idx, cc, name, exp, got) in shown:
                    print(f"  {d}  {idx if idx >= 0 else '-'}  {cc}  {name}  {exp}  {got}")
        if not args.summary:
            for note in res.notes:
                print(f"  note: {note}")
    print(f"{'ALL PASS' if n_ok == len(dirs) else 'FAILURES'}: {n_ok}/{len(dirs)} directories passed, "
          f"{n_snap} snapshots checked")
    return 0 if n_ok == len(dirs) else 1


if __name__ == "__main__":
    sys.exit(main())
