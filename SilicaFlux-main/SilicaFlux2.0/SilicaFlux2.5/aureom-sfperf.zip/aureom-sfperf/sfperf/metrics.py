"""Derived metrics from counter totals (docs/METRICS.md Part A).  Pure functions on {counter: int}."""
from . import spec

NT, LANES = spec.NT, spec.LANES

# CPI-stack groups used by charts and the classifier (hue count is limited, so related slots are folded)
GROUPS = [
    ("Issue",              ["SLOT_ISSUE"]),
    ("Dependency (RAW)",   ["SLOT_STALL_DEP"]),
    ("Barrier wait",       ["SLOT_STALL_SYNC"]),
    ("Execution unit",     ["SLOT_STALL_EXEC_VEC", "SLOT_STALL_EXEC_TENSOR"]),
    ("Memory",             ["SLOT_STALL_MEM"]),
    ("Control flow",       ["SLOT_BUBBLE_CTRL"]),
    ("Other",              ["SLOT_STALL_DISP_OTHER", "SLOT_BUBBLE_FRONT"]),
    ("Idle",               ["SLOT_IDLE"]),
]

def derive(t):
    """t: totals dict (sum over windows). Returns a flat dict of derived metrics."""
    g = lambda k: t[k]
    cyc = g("CYCLES"); idle = g("SLOT_IDLE"); act = max(cyc - idle, 1)
    d = {"cycles": cyc, "idle": idle, "active": cyc - idle}
    d["issued"] = g("SLOT_ISSUE"); d["ipc"] = g("SLOT_ISSUE") / act
    d["useful_ipc"] = (g("SLOT_ISSUE") - g("ISS_NOP")) / act
    d["retired"] = g("RET_SCALAR") + g("RET_TILE")
    for name, members in GROUPS:
        d["frac_" + name] = sum(g(m) for m in members) / act if name != "Idle" else idle / max(cyc, 1)
    d["stall_frac"] = sum(g(k) for k in ("SLOT_STALL_DEP", "SLOT_STALL_SYNC", "SLOT_STALL_EXEC_VEC", "SLOT_STALL_EXEC_TENSOR",
                                         "SLOT_STALL_MEM", "SLOT_STALL_DISP_OTHER")) / act
    d["bubble_frac"] = (g("SLOT_BUBBLE_CTRL") + g("SLOT_BUBBLE_FRONT")) / act
    # execution units
    d["lane_util"] = g("VEC_LANES_ACTIVE") / (act * NT * LANES)
    d["vec_busy"] = g("VEC_BUSY_CYC") / act                     # tile-cycles per cycle (0..NT)
    d["tensor_busy"] = g("TENSOR_BUSY_CYC") / act
    d["partial_issue_frac"] = g("VEC_ISSUES_PARTIAL") / g("VEC_ISSUES") if g("VEC_ISSUES") else 0.0
    # tiles
    d["tile_tok"] = [g(f"TILE_TOK_{i}") for i in range(NT)]
    d["tile_busy_frac"] = [g(f"TILE_BUSY_{i}") / act for i in range(NT)]
    # memory
    d["mem_avg_out"] = g("MEM_OUT_SUM") / act
    d["mem_peak"] = g("MEM_OUT_PEAK")
    d["mem_busy_frac"] = g("MEM_BUSY_CYC") / act
    d["mem_latency"] = g("MEM_OUT_SUM") / g("MEM_RESP") if g("MEM_RESP") else None
    d["mem_blocked"] = g("MEM_REQ_BLOCKED")
    # queues
    d["q_disp_occ"] = g("Q_DISP_SUM") / act
    d["q_tok_avg"] = g("Q_TOK_SUM") / act; d["q_tok_peak"] = g("Q_TOK_PEAK")
    d["q_noc_avg"] = g("Q_NOC_SUM") / act; d["q_noc_peak"] = g("Q_NOC_PEAK")
    # control flow
    d["taken_rate"] = g("BRANCH_TAKEN") / g("ISS_BRANCH") if g("ISS_BRANCH") else 0.0
    d["ctrl_per_taken"] = g("SLOT_BUBBLE_CTRL") / g("BRANCH_TAKEN") if g("BRANCH_TAKEN") else None
    # health / conservation
    d["streak_max"] = g("STALL_STREAK_MAX")
    d["tokens_unretired"] = g("TOK_DISPATCHED") - g("RET_TILE")
    d["conservation_gap"] = g("SLOT_ISSUE") - (g("RET_SCALAR") + g("RET_TILE") + g("DROP_SYNC") + g("DROP_OP"))
    d["dropped_ops"] = g("DROP_OP")
    return d
