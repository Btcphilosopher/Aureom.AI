"""Directed experiments that reproduce each documented defect of the SUPPLIED RTL (docs/BASELINE_FINDINGS.md).

Each experiment runs a tiny program on the instrumented supplied core (build/sim_pm.vvp), reads the evidence back from
the monitor counters / architectural trace, and records whether the defect was observed.  Nothing here is assumed:
if an observation does not hold, the finding is reported as NOT reproduced.
"""
import csv, json, pathlib, re, subprocess
from .isa import Prog, I, D, V, R, write_hex
from . import run, snapshot

ROOT = pathlib.Path(__file__).resolve().parent.parent

def _run(name, prog, out, maxc=800, variant="pm", trace=True):
    d = pathlib.Path(out) / name; d.mkdir(parents=True, exist_ok=True)
    hexf = d / "prog.hex"; write_hex(prog.assemble(), hexf)
    summ, log = run.run_sim(variant, hexf, d, maxc, 0, 1 if trace else 0, 0)
    snaps = snapshot.load(d / "snapshots.csv"); t = snapshot.totals(snaps)
    arch = [l.strip().split(",") for l in open(d / "arch.csv")]
    regs = {int(x[1]): int(x[2]) for x in arch if x[0] == "R"}
    tiles = [x for x in arch if x[0] == "T"]; mem = [x for x in arch if x[0] == "M"]
    sc = {int(x[1]): int(x[2]) for x in arch if x[0] == "SC"}
    return dict(summ=summ, t=t, regs=regs, tiles=tiles, mem=mem, sc=sc, dir=d, arch=arch)

def N(p, n): p.nop(n); return p

def experiments(out):
    out = pathlib.Path(out); res = {}

    # F4 -- DFEXEC never completes: its tile stays busy and the next DFSYNC waits forever
    p = Prog(); p.emit(D("DFEXEC", 0, 0, 0, 0)); p.dfsync(1); p.mov(8, 99); p.halt()
    r = _run("F4_dfexec_hang", p, out, maxc=600)
    res["F4"] = dict(title="DFEXEC/DFMAP never complete: the tile stays busy and the next barrier hangs",
        observed=r["t"]["TOK_DISPATCHED"] - r["t"]["RET_TILE"] >= 1 and r["t"]["Q_TOK_NOW"] >= 1 and r["summ"]["drained"] == "0",
        evidence=dict(TOK_DISPATCHED=r["t"]["TOK_DISPATCHED"], RET_TILE=r["t"]["RET_TILE"], tokens_never_completed=r["t"]["TOK_DISPATCHED"] - r["t"]["RET_TILE"], Q_TOK_NOW=r["t"]["Q_TOK_NOW"],
                      SLOT_STALL_SYNC=r["t"]["SLOT_STALL_SYNC"], CYCLES=r["t"]["CYCLES"], drained=r["summ"]["drained"]))

    # F5 -- a taken branch lets wrong-path instructions commit
    p = Prog(); p.mov(1, 0); p.branch("BEQ", 1, "tgt")
    for i, r_ in enumerate((10, 11, 12, 13, 14)): p.mov(r_, 111 * (i + 1))
    p.label("tgt"); p.mov(9, 77); p.halt()
    r = _run("F5_wrong_path", p, out)
    wp = {k: v for k, v in r["regs"].items() if 10 <= k <= 14 and v != 0}
    res["F5"] = dict(title="Wrong-path instructions commit after a taken branch", observed=len(wp) > 0 and r["regs"].get(9) == 77,
        evidence=dict(committed_wrong_path_regs=wp, BRANCH_TAKEN=r["t"]["BRANCH_TAKEN"], BUBBLE_CTRL=r["t"]["SLOT_BUBBLE_CTRL"]))

    # F6 -- a stalled EX instruction is replayed into WB every stall cycle
    p = Prog(); p.mov(1, 1); p.dfload(0, 8, 0); p.dfsync(1); p.alu("ADD", 1, 1, 1); p.alu("ADD", 5, 1, 1); p.halt()
    r = _run("F6_replay", p, out)
    rows = list(csv.DictReader(open(r["dir"] / "trace.csv")))
    raw_wb = sum(int(x["wb_valid"]) for x in rows if int(x["en"]))
    res["F6"] = dict(title="A stalled EX instruction is replayed into write-back every stall cycle", observed=raw_wb > r["t"]["RET_SCALAR"] + 3,
        evidence=dict(wb_valid_cycles=raw_wb, RET_SCALAR=r["t"]["RET_SCALAR"], SLOT_ISSUE=r["t"]["SLOT_ISSUE"]))

    # F7 -- HALT is only a fetch-time flag
    p = Prog(); p.dfload(0, 31, 0); p.vec("MATMUL"); p.halt()
    r = _run("F7_halt", p, out, maxc=1500)
    hc = int(r["summ"]["halt_cycle"]); last = max([int(x[1]) for x in r["tiles"]] or [0])
    res["F7"] = dict(title="`halt` is raised when HALT is fetched; the pipeline and tiles keep running", observed=last > hc + 10,
        evidence=dict(halt_cycle=hc, last_tile_completion_cycle=last))

    # F8 -- tile results never reach the register files
    p = Prog(); p.vec("VADD", 3, 1, 2); p.nop(2); p.vec("DOT", 0, 1, 2); p.nop(2); p.vec("REDUCE", 0, 1, 1); p.nop(4); p.halt()
    r = _run("F8_no_writeback", p, out)
    vec_results = [x for x in r["tiles"] if int(x[3]) != 0 or int(x[4], 16) != 0]
    # preloaded v3 is {16*3+4,..} (testbench pattern); a VADD writing v3 would change it
    vr = [l for l in r["arch"] if l[0] == "V" and l[1] == "3"][0][2]
    res["F8"] = dict(title="Tile results are never written to scalar or vector registers", observed=len(vec_results) > 0 and vr.lower() == f"{52:08x}{51:08x}{50:08x}{49:08x}",
        evidence=dict(nonzero_tile_results=len(vec_results), final_v3=vr, scalar_regs_nonzero={k: v for k, v in r["regs"].items() if v}))

    # F10 -- no forwarding / interlock for distance-1 dependences
    p = Prog(); N(p, 2); p.mov(2, 3); p.alu("ADD", 3, 2, 2); N(p, 4); p.mov(4, 3); p.nop(1); p.alu("ADD", 5, 4, 4)
    N(p, 4); p.mov(6, 3); p.nop(2); p.alu("ADD", 7, 6, 6); p.halt()
    r = _run("F10_raw_distance", p, out)
    res["F10"] = dict(title="Distance-1 RAW dependences read a stale operand (no forwarding, no interlock)",
        observed=r["regs"].get(3) != 6 and r["regs"].get(5) == 6 and r["regs"].get(7) == 6,
        evidence=dict(dist1_ADD_result=r["regs"].get(3), dist2_ADD_result=r["regs"].get(5), dist3_ADD_result=r["regs"].get(7), expected=6,
                      SLOT_STALL_DEP=r["t"]["SLOT_STALL_DEP"]))

    # F11 -- scalar LOAD returns its address; STORE writes zero
    p = Prog(); p.mov(10, 64); N(p, 4); p.load(11, 10, 0); N(p, 6); p.mov(14, 77); N(p, 3); p.emit(I("STORE", 0, 10, 12)); N(p, 6); p.halt()
    r = _run("F11_scalar_mem", p, out)
    res["F11"] = dict(title="Scalar LOAD returns the address instead of the data; STORE writes zero (I-format has no source register)",
        observed=r["regs"].get(11) == 64 and r["sc"].get(19) == 0,
        evidence=dict(r11_after_LOAD=r["regs"].get(11), memory_word16_expected=5016, ctrl_sram_word19_after_STORE=r["sc"].get(19), word19_before=5019))

    # F12 -- back-to-back scalar memory requests: the second is lost
    p = Prog(); p.mov(10, 64); N(p, 4); p.load(11, 10, 0); p.load(12, 10, 4); N(p, 8); p.halt()
    r = _run("F12_lost_request", p, out)
    res["F12"] = dict(title="Scalar memory requests ignore `ready`: a request issued during a busy cycle is lost",
        observed=r["t"]["MEM_REQ_BLOCKED"] >= 1 and r["t"]["ISS_SMEM"] == 2 and r["t"]["MEM_REQ_ACCEPTED"] == 1,
        evidence=dict(ISS_SMEM=r["t"]["ISS_SMEM"], MEM_REQ_ACCEPTED=r["t"]["MEM_REQ_ACCEPTED"], MEM_REQ_BLOCKED=r["t"]["MEM_REQ_BLOCKED"]))

    # F3 -- V-format ops always target tile 0
    p = Prog()
    for _ in range(3): p.vec("VADD"); p.dfsync(0)
    p.halt()
    r = _run("F3_tile_zero", p, out)
    res["F3"] = dict(title="V-format instructions carry no tile id: all vector/tensor ops run on tile 0",
        observed=r["t"]["TILE_TOK_0"] >= 3 and r["t"]["TILE_TOK_1"] + r["t"]["TILE_TOK_2"] + r["t"]["TILE_TOK_3"] == 0,
        evidence={f"TILE_TOK_{i}": r["t"][f"TILE_TOK_{i}"] for i in range(4)})

    # F1/F2 are measured by the workload suite (dep_load_use, compute_tensor_queue, mem_conflict_queue); summarised in the report.
    # F9 -- out-of-range select (static, found by yosys-slang)
    try:
        files = subprocess.run([str(ROOT / "scripts/rtl_files.sh"), "rtl/supplied", "nopm"], cwd=ROOT, capture_output=True, text=True).stdout.split()
        q = subprocess.run(["yowasp-yosys", "-q", "-p", "read_slang -j 1 --single-unit -I rtl/supplied --top silicaflux_top " + " ".join(files)],
                           cwd=ROOT, capture_output=True, text=True, timeout=300)
        msg = [l for l in (q.stdout + q.stderr).splitlines() if "range-oob" in l]
        res["F9"] = dict(title="compute_tile.sv:226 selects bits [2:0] of a 2-bit field (rejected by yosys-slang)", observed=bool(msg), evidence=dict(message=msg[0].strip() if msg else None))
    except Exception as e:
        res["F9"] = dict(title="compute_tile.sv:226 out-of-range select", observed=None, evidence=dict(not_run=str(e)))
    json.dump(res, open(out / "findings.json", "w"), indent=1, default=str)
    return res

if __name__ == "__main__":
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else ROOT / "results" / "findings"
    for k, v in sorted(experiments(out).items(), key=lambda kv: int(kv[0][1:])):
        print(f"{k:4s} {'REPRODUCED' if v['observed'] else 'NOT reproduced' if v['observed'] is False else 'not run':15s} {v['title']}\n       {v['evidence']}")
