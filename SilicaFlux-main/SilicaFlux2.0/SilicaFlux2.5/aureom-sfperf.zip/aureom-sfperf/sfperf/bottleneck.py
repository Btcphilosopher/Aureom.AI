"""Rule-based bottleneck attribution from counters.

The classifier uses only counters read from the monitor.  Every finding carries its evidence so a
reader can check it against docs/METRICS.md.  Thresholds are module constants (below) and are
documented in docs/ANALYSIS.md; they are not tuned per workload.
"""
from dataclasses import dataclass, field
from . import metrics

SIG = 0.05          # a slot category must cost >= 5 % of active cycles to be called a bottleneck
ATTRIB = 0.60       # barrier stall is attributed to a unit if it was busy for >= 60 % of the barrier-stall cycles
HANG_MIN = 200      # a stall streak at least this long ...
HANG_FRAC = 0.5     # ... and covering at least this share of active cycles is a hang

@dataclass
class Finding:
    family: str            # compute | memory | dependency | divergence | defect
    label: str
    weight: float          # share of active cycles it explains (0..1)
    evidence: list = field(default_factory=list)
    advice: str = ""

def classify(t):
    """t = counter totals. Returns (primary Finding, [all findings], [defects], derived metrics)."""
    d = metrics.derive(t)
    act = max(d["active"], 1)
    F, defects = [], []

    # ---- defects / health first: these invalidate the performance reading
    if t["STALL_STREAK_MAX"] >= HANG_MIN and t["STALL_STREAK_MAX"] >= HANG_FRAC * act:
        dom = max(("SLOT_STALL_DEP", "SLOT_STALL_SYNC", "SLOT_STALL_EXEC_VEC", "SLOT_STALL_EXEC_TENSOR", "SLOT_STALL_MEM",
                   "SLOT_STALL_DISP_OTHER"), key=lambda k: t[k])
        fam = "dependency" if dom == "SLOT_STALL_DEP" else "defect"
        defects.append(Finding("dependency" if dom == "SLOT_STALL_DEP" else "defect",
            f"HANG: one stall run of {t['STALL_STREAK_MAX']} cycles ({t['STALL_STREAK_MAX']/act:.0%} of the run), dominated by {dom}",
            t["STALL_STREAK_MAX"] / act, [f"STALL_STREAK_MAX={t['STALL_STREAK_MAX']}", f"{dom}={t[dom]}", f"SLOT_ISSUE={t['SLOT_ISSUE']}"],
            "load-use interlock never clears (is_ex frozen under id_stall): apply optional fix F1" if dom == "SLOT_STALL_DEP"
            else "a tile token that never completes (DFEXEC/DFMAP) or an out-of-range tile target"))
    if t["DROP_OP"] > 0:
        defects.append(Finding("defect", f"LOST OPS: {t['DROP_OP']} scheduler ops consumed without being dispatched",
            t["DROP_OP"] / max(t["SLOT_ISSUE"], 1), [f"DROP_OP={t['DROP_OP']}", f"TOK_DISPATCHED={t['TOK_DISPATCHED']}"],
            "scheduler.instr_ready accepts while the tile is still busy (tile_done cycle): apply optional fix F2"))
    if t["MEM_REQ_BLOCKED"] > 0:
        defects.append(Finding("memory", f"LOST MEMORY REQUESTS: {t['MEM_REQ_BLOCKED']} requests presented to a busy controller",
            t["MEM_REQ_BLOCKED"] / max(t["MEM_REQ_ACCEPTED"] + t["MEM_REQ_BLOCKED"], 1),
            [f"MEM_REQ_BLOCKED={t['MEM_REQ_BLOCKED']}", f"MEM_REQ_ACCEPTED={t['MEM_REQ_ACCEPTED']}"],
            "control_core ignores mem_req_ready: back-to-back scalar accesses need a gap or a ready-aware issue"))
    if d["tokens_unretired"] > 0 and not any("HANG" in f.label for f in defects):
        defects.append(Finding("defect", f"STUCK TOKENS: {d['tokens_unretired']} dispatched tokens never completed",
            0.0, [f"TOK_DISPATCHED={t['TOK_DISPATCHED']}", f"RET_TILE={t['RET_TILE']}"], "DFEXEC/DFMAP never signal done in the supplied RTL"))

    # ---- barrier attribution: what was the barrier waiting on?
    sync = t["SLOT_STALL_SYNC"]
    waiting = None
    if sync:
        cand = {"tensor unit": t["TENSOR_BUSY_CYC"], "memory": t["MEM_BUSY_CYC"], "vector engine": t["VEC_BUSY_CYC"]}
        unit, busy = max(cand.items(), key=lambda kv: kv[1])
        # tile-cycles can exceed barrier cycles when the unit also ran outside the barrier; cap at 1.0
        cov = min(busy / sync, 1.0)
        if cov >= ATTRIB: waiting = (unit, cov)

    # ---- slot categories -> performance findings
    def frac(*ks): return sum(t[k] for k in ks) / act
    cats = [
        ("dependency", "RAW (load-use) interlock stalls", frac("SLOT_STALL_DEP"), ["SLOT_STALL_DEP"],
         "schedule independent work between a LOAD and its consumer"),
        ("divergence", "control-flow bubbles from taken branches", frac("SLOT_BUBBLE_CTRL"), ["SLOT_BUBBLE_CTRL", "BRANCH_TAKEN"],
         "3 issue slots are lost per taken branch: unroll, hoist or predicate branches"),
        ("compute", "execution-unit contention (vector engine)", frac("SLOT_STALL_EXEC_VEC"), ["SLOT_STALL_EXEC_VEC", "VEC_BUSY_CYC"],
         "single vector engine on tile 0 (V-format ops carry no tile id): interleave independent work or add tile addressing"),
        ("compute", "execution-unit contention (tensor unit)", frac("SLOT_STALL_EXEC_TENSOR"), ["SLOT_STALL_EXEC_TENSOR", "TENSOR_BUSY_CYC"],
         "one serial 4x4 tensor unit (~66 cycles per MATMUL): batch work or overlap with other tiles"),
        ("memory", "memory backpressure / latency (tile occupied by a transaction)", frac("SLOT_STALL_MEM"), ["SLOT_STALL_MEM", "MEM_BUSY_CYC"],
         "spread bursts across tiles to raise memory-level parallelism"),
    ]
    if sync:
        sw = frac("SLOT_STALL_SYNC")
        if waiting and waiting[0] == "tensor unit":
            F.append(Finding("compute", "barrier waiting on the tensor unit (execution-unit bound)", sw,
                             ["SLOT_STALL_SYNC", f"TENSOR_BUSY_CYC covers {waiting[1]:.0%} of it"], "overlap the tensor op with independent work before the DFSYNC"))
        elif waiting and waiting[0] == "vector engine":
            F.append(Finding("compute", "barrier waiting on the vector engine (execution-unit bound)", sw,
                             ["SLOT_STALL_SYNC", f"VEC_BUSY_CYC covers {waiting[1]:.0%} of it"], "overlap vector ops with independent work"))
        elif waiting and waiting[0] == "memory":
            F.append(Finding("memory", "barrier waiting on memory transactions (memory-latency bound)", sw,
                             ["SLOT_STALL_SYNC", f"MEM_BUSY_CYC covers {waiting[1]:.0%} of it"], "issue loads on several tiles before the DFSYNC to overlap latency"))
        else:
            F.append(Finding("dependency", "barrier (dataflow dependency) waits", sw, ["SLOT_STALL_SYNC"], "reduce DFSYNC frequency / widen the work between barriers"))
    for fam, label, w, ev, adv in cats:
        if w > 0: F.append(Finding(fam, label, w, [f"{k}={t[k]}" for k in ev], adv))
    other = frac("SLOT_STALL_DISP_OTHER", "SLOT_BUBBLE_FRONT")
    if other > 0: F.append(Finding("compute", "front-end / dispatch turnaround", other, ["SLOT_STALL_DISP_OTHER", "SLOT_BUBBLE_FRONT"], ""))

    F = [f for f in F if f.weight >= SIG] or []
    F.sort(key=lambda f: -f.weight)
    if not F:
        F = [Finding("compute", "issue-bound (single-issue scalar throughput)", d["frac_Issue"],
                     [f"IPC={d['ipc']:.2f}", "no stall or bubble category reaches %d%% of active cycles" % int(SIG * 100)],
                     "the issue slot is the limit: IPC cannot exceed 1 on this core")]
    return F[0], F, defects, d
