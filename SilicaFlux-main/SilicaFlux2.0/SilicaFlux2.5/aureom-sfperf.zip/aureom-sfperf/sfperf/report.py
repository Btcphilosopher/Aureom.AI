"""Build results/REPORT.md, summary.csv and summary.json from the raw run outputs.

Everything in the report is read back from files produced by simulation (counters read through the RTL CSR path,
architectural traces, fingerprints); nothing is typed in.  Sections whose inputs are missing say so.
"""
import csv, json, pathlib, subprocess, shutil, datetime
from . import snapshot, bottleneck, metrics, spec
from .workloads import all_workloads

ROOT = pathlib.Path(__file__).resolve().parent.parent

def meets(spec_, val):
    if isinstance(spec_, tuple):
        k = spec_[0]
        return val >= spec_[1] if k == "ge" else val <= spec_[1] if k == "le" else spec_[1] <= val <= spec_[2]
    return val == spec_

def fmt_spec(s):
    if isinstance(s, tuple):
        if s[0] == "ge": return f">= {s[1]}"
        if s[0] == "le": return f"<= {s[1]}"
        return f"in [{s[1]}, {s[2]}]"
    return f"== {s}"

def tool_versions():
    def v(cmd):
        try: return subprocess.run(cmd, capture_output=True, text=True, timeout=20).stdout.splitlines()[0].strip()
        except Exception: return "n/a"
    return {"iverilog": v(["iverilog", "-V"]), "verilator": v(["verilator", "--version"]), "yosys (native)": v(["yosys", "-V"]),
            "python": v(["python3", "--version"])}

def evaluate(results):
    results = pathlib.Path(results); man = json.load(open(results / "run_manifest.json")); rows = []
    for cfg in ("supplied", "fixed"):
        for wl in all_workloads():
            p = results / cfg / wl.name / "pm" / "snapshots.csv"
            snaps = snapshot.load(p); t = snapshot.totals(snaps)
            prim, allf, defects, d = bottleneck.classify(t)
            exp = wl.expect.get(cfg, {}); fails = []
            for k, s in exp.items():
                if not meets(s, t[k]): fails.append(f"{k}={t[k]} (expected {fmt_spec(s)})")
            m = man[f"{cfg}/{wl.name}"]
            inv = snapshot.check_invariants(t, snaps[-1].ovf)
            rows.append(dict(cfg=cfg, wl=wl, totals=t, derived=d, primary=prim, findings=allf, defects=defects,
                             n_expect=len(exp), expect_fail=fails, inv=inv, man=m, snaps=snaps,
                             coherent=all(s.coherent for s in snaps)))
    return rows

def write(results, syn_dir=None, verification=None, out=None):
    results = pathlib.Path(results); rows = evaluate(results); out = pathlib.Path(out or results)
    # ---------------- machine-readable
    with open(out / "summary.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["config", "workload", "family", "cycles", "active", "idle", "ipc"] + [g for g, _ in metrics.GROUPS[:-1]] +
                   ["primary_family", "primary_label", "primary_weight", "defects", "expect_checked", "expect_failed", "invariants_ok",
                    "arch_identical", "cycle_exact", "model_mismatches"])
        for r in rows:
            d = r["derived"]; m = r["man"]
            w.writerow([r["cfg"], r["wl"].name, r["wl"].family, d["cycles"], d["active"], d["idle"], f"{d['ipc']:.4f}"] +
                       [f"{d['frac_' + g]:.4f}" for g, _ in metrics.GROUPS[:-1]] +
                       [r["primary"].family, r["primary"].label, f"{r['primary'].weight:.4f}", "; ".join(x.label.split(":")[0] for x in r["defects"]),
                        r["n_expect"], len(r["expect_fail"]), not r["inv"], m["arch_identical"], m["cycle_exact"], m["model_mismatches"]])
    json.dump({f"{r['cfg']}/{r['wl'].name}": {"totals": r["totals"], "derived": {k: v for k, v in r["derived"].items()},
               "primary": r["primary"].label, "defects": [x.label for x in r["defects"]]} for r in rows},
              open(out / "summary.json", "w"), indent=1)
    # ---------------- REPORT.md
    L = []; A = L.append
    A("# Measured results"); A("")
    A(f"Generated {datetime.date.today()} by `python -m sfperf report` from raw simulation outputs in `results/`. Every number below was read back "
      "from the RTL monitor's CSR interface (or from the architectural traces); none is typed in.")
    A(""); A("Tools: " + "; ".join(f"{k} `{v}`" for k, v in tool_versions().items())); A("")
    A("Configurations: **supplied** = the RTL exactly as supplied; **fixed** = supplied RTL plus the two optional patches F1 (load-use livelock) and F2 "
      "(dispatch drop). See `docs/BASELINE_FINDINGS.md`."); A("")
    tot_e = sum(r["n_expect"] for r in rows); bad_e = sum(len(r["expect_fail"]) for r in rows)
    eq = sum(1 for r in rows if r["man"]["arch_identical"] and r["man"]["cycle_exact"])
    A("## 1. Headline checks"); A("")
    A(f"| Check | Result |"); A("|---|---|")
    A(f"| Instrumented vs uninstrumented: identical architectural trace **and** cycle-exact fingerprint | **{eq}/{len(rows)}** runs |")
    A(f"| RTL counters vs behavioural reference model, every counter every cycle | {sum(r['man']['model_mismatches'] for r in rows)} mismatches in {len(rows)} runs |")
    A(f"| Snapshot invariants I1-I3, I5 hold in every run | {sum(1 for r in rows if not r['inv'])}/{len(rows)} runs |")
    A(f"| Coherent CSR reads (SNAP_SEQ equal before/after every multi-word read) | {sum(1 for r in rows if r['coherent'])}/{len(rows)} runs |")
    A(f"| Conservation I4: `SLOT_ISSUE == RET_SCALAR + RET_TILE + DROP_SYNC + DROP_OP` (drained runs; includes runs whose wrong-path instructions commit) | exact in **{sum(1 for r in rows if r['derived']['conservation_gap'] == 0)}/{len(rows)}** runs |")
    A(f"| Workload expectations (exact or bounded counter values declared with each workload) | **{tot_e - bad_e}/{tot_e}** hold |")
    if verification:
        for k, v in verification.items(): A(f"| {k} | {v} |")
    A("")
    A("## 2. Bottleneck verdict per workload"); A("")
    A("Primary = the largest finding the classifier (`sfperf/bottleneck.py`) derives from the counters; it is never told which workload it is looking at.")
    A(""); A("| config | workload | cycles | active | IPC | primary finding (share of active cycles) | defects flagged by the monitor |"); A("|---|---|---|---|---|---|---|")
    for r in rows:
        d = r["derived"]; p = r["primary"]
        A(f"| {r['cfg']} | `{r['wl'].name}` | {d['cycles']} | {d['active']} | {d['ipc']:.2f} | **{p.family}**: {p.label} ({p.weight:.0%}) | "
          + ("<br>".join(x.label for x in r["defects"]) or "-") + " |")
    A(""); A("## 3. Issue-slot breakdown (share of active cycles; IDLE excluded)"); A("")
    hdr = [g for g, _ in metrics.GROUPS[:-1]]
    A("| config | workload | " + " | ".join(hdr) + " |"); A("|---|---|" + "---|" * len(hdr))
    for r in rows:
        d = r["derived"]; A(f"| {r['cfg']} | `{r['wl'].name}` | " + " | ".join(f"{d['frac_' + g]:.1%}" for g in hdr) + " |")
    A(""); A("## 4. Memory, queues and execution units"); A("")
    A("| config | workload | avg mem outstanding | peak | latency (cyc, Little) | blocked reqs | avg tokens in flight | peak | tensor busy | vector busy | lane util |"); A("|---|---|---|---|---|---|---|---|---|---|---|")
    for r in rows:
        d = r["derived"]; lat = f"{d['mem_latency']:.1f}" if d["mem_latency"] else "-"
        A(f"| {r['cfg']} | `{r['wl'].name}` | {d['mem_avg_out']:.2f} | {d['mem_peak']} | {lat} | {d['mem_blocked']} | {d['q_tok_avg']:.2f} | {d['q_tok_peak']} | {d['tensor_busy']:.2f} | {d['vec_busy']:.2f} | {d['lane_util']:.3f} |")
    A(""); A("## 5. Declared expectations (exact counter values the workload was designed to produce)"); A("")
    A("| config | workload | checked | failed |"); A("|---|---|---|---|")
    for r in rows: A(f"| {r['cfg']} | `{r['wl'].name}` | {r['n_expect']} | " + ("none" if not r["expect_fail"] else "; ".join(r["expect_fail"])) + " |")
    A(""); A("## 6. Instrumentation transparency (per run)"); A("")
    A("| config | workload | cycles (uninstr.) | cycles (instr.) | fingerprint equal | arch trace byte-identical | sim wall s (uninstr. / instr.) |"); A("|---|---|---|---|---|---|---|")
    for r in rows:
        m = r["man"]; A(f"| {r['cfg']} | `{r['wl'].name}` | {m['base']['cycles']} | {m['pm']['cycles']} | {m['cycle_exact']} | {m['arch_identical']} | {m['base']['wall_s']} / {m['pm']['wall_s']} |")
    if syn_dir and (pathlib.Path(syn_dir) / "syn_sup" / "summary.json").exists():
        A(""); A("## 7. Synthesis overhead (Yosys proxies; see docs/OVERHEAD.md for method and caveats)"); A("")
        A("| variant | flip-flops | generic gates | LUT6 | logic depth (gates) | logic depth (LUT6) |"); A("|---|---|---|---|---|---|")
        for n, lab in (("sup", "supplied"), ("pm0", "instrumented, PM_EN=0"), ("pm1", "instrumented, PM_EN=1")):
            p = pathlib.Path(syn_dir) / f"syn_{n}" / "summary.json"
            if p.exists():
                s = json.load(open(p)); g, l = s["generic_gates"], s["lut6"]
                A(f"| {lab} | {g['ff']:,} | {g['comb']:,} | {l['comb']:,} | {g['ltp']} | {l['ltp']} |")
        sw = [(cw, pathlib.Path(syn_dir) / f"syn_{n}" / "summary.json") for cw, n in ((16, "cw16"), (24, "cw24"), (32, "cw32"), (40, "pm_only"), (48, "cw48"))]
        if all(p.exists() for _, p in sw):
            A(""); A("Standalone monitor, same flow, versus counter width `CW` (snapshot shadow + live counters scale linearly):"); A("")
            A("| CW | flip-flops | generic gates | LUT6 | logic depth (gates / LUT6) |"); A("|---|---|---|---|---|")
            for cw, p in sw:
                s_ = json.load(open(p)); g, l = s_["generic_gates"], s_["lut6"]; A(f"| {cw} | {g['ff']:,} | {g['comb']:,} | {l['comb']:,} | {g['ltp']} / {l['ltp']} |")
    sp = out / "simspeed.json"
    if sp.exists():
        A(""); A("## 8. Simulation wall-clock overhead (Icarus Verilog, median of repeated runs)"); A("")
        A("| workload | build | median s | min..max s | vs uninstrumented |"); A("|---|---|---|---|---|")
        for w, row in json.load(open(sp)).items():
            for k, v in row.items(): A(f"| `{w}` | {k} | {v['median_s']:.3f} | {v['min_s']:.3f}..{v['max_s']:.3f} | x{v['vs_uninstrumented']:.2f} |")
    (out / "REPORT.md").write_text("\n".join(L) + "\n")
    return rows
