"""Random-program equivalence fuzzing: instrumented vs uninstrumented core.

For each seed a random program is run on
    supplied : sup (pristine)  vs  pm (instrumented, CSR snapshots read mid-run)  vs  pm_nopm (taps only, PM_EN=0)
    fixed    : fix             vs  pmfix
and the run is accepted only if arch.csv is byte-identical and cycle count + fingerprint match.  The instrumented run
additionally cross-checks the RTL counters against the reference model (zero mismatches) and the snapshot invariants.

Programs deliberately include things a well-behaved compiler would never emit: reserved opcodes, tile ids 4..7,
misaligned scalar accesses, DFEXEC/DFMAP (never complete), loads followed by dependants (livelock on the supplied RTL),
back-to-back dispatch to a busy tile (dropped ops), branches to arbitrary targets.
"""
import argparse, filecmp, pathlib, random, shutil, sys, time
from .isa import OP, R, I, D, V, write_hex
from . import run, snapshot

ROOT = pathlib.Path(__file__).resolve().parent.parent

def random_program(seed, n=96):
    rng = random.Random(seed); w = []
    reg = lambda: rng.randrange(0, 32)
    for _ in range(n):
        c = rng.random()
        if   c < 0.22: w.append(R(rng.choice(["ADD", "SUB", "MUL"]), reg(), reg(), reg()))
        elif c < 0.32: w.append(I("MOV", reg(), 0, rng.randrange(-2000, 2000)))
        elif c < 0.38: w.append(I("LOAD", reg(), reg(), rng.randrange(0, 256)))
        elif c < 0.42: w.append(I("STORE", reg(), reg(), rng.randrange(0, 256)))
        elif c < 0.50: w.append(I(rng.choice(["BEQ", "BNE"]), 0, reg(), rng.randrange(-6, 12)))
        elif c < 0.51: w.append(I("JMP", 0, reg(), rng.randrange(0, 40)))
        elif c < 0.58: w.append(D("DFLOAD", rng.randrange(8), reg(), rng.randrange(0, 32), rng.randrange(0, 1024)))
        elif c < 0.63: w.append(D("DFSTORE", rng.randrange(8), reg(), rng.randrange(0, 32), rng.randrange(0, 1024)))
        elif c < 0.70: w.append(D("DFSYNC", rng.randrange(8), 0, 0, 0))
        elif c < 0.72: w.append(D(rng.choice(["DFEXEC", "DFMAP"]), rng.randrange(8), reg(), rng.randrange(0, 32), rng.randrange(0, 1024)))
        elif c < 0.88: w.append(V(rng.choice(["VADD", "VMUL", "VSUB", "DOT", "REDUCE", "BCAST", "VLOAD", "VSTORE"]), rng.randrange(16), rng.randrange(16), rng.randrange(16), rng.randrange(256)))
        elif c < 0.92: w.append(V("MATMUL", rng.randrange(16), rng.randrange(16), rng.randrange(16), 0))
        elif c < 0.96: w.append(0)
        elif c < 0.985: w.append((rng.randrange(0x18, 0x1F) << 27) | rng.randrange(1 << 27))     # reserved opcodes
        else: w.append(0x1F << 27)                                                                # HALT mid-stream
    w.append(0x1F << 27)
    return w

def one(seed, results, maxc=1500, snapint=192):
    d = pathlib.Path(results) / f"seed{seed}"; d.mkdir(parents=True, exist_ok=True)
    hexf = d / "prog.hex"; write_hex(random_program(seed), hexf)
    bad = []
    for cfg, (base, pm) in run.VARIANTS.items():
        sb, _ = run.run_sim(base, hexf, d / cfg / "base", maxc)
        sp, log = run.run_sim(pm, hexf, d / cfg / "pm", maxc, snapint=snapint)
        mm = int([l for l in log.splitlines() if "model mismatches" in l][0].split("=")[1])
        same_arch = filecmp.cmp(d / cfg / "base" / "arch.csv", d / cfg / "pm" / "arch.csv", shallow=False)
        if not same_arch: bad.append(f"{cfg}: arch.csv differs")
        if sb["cycles"] != sp["cycles"] or sb["fingerprint"] != sp["fingerprint"]: bad.append(f"{cfg}: fingerprint/cycles differ")
        if mm: bad.append(f"{cfg}: {mm} model mismatches")
        snaps = snapshot.load(d / cfg / "pm" / "snapshots.csv")
        for s in snaps:
            if not s.coherent: bad.append(f"{cfg}: incoherent snapshot seq")
            inv = snapshot.check_invariants(s.v, s.ovf, windowed=True)      # one SNAP_CLR window
            if inv: bad.append(f"{cfg}: snapshot {s.seq}: {inv}")
        inv = snapshot.check_invariants(snapshot.totals(snaps), snaps[-1].ovf)   # whole epoch: strict
        if inv: bad.append(f"{cfg}: epoch totals: {inv}")
        if cfg == "supplied":      # taps present, monitor compiled out
            sn, _ = run.run_sim("pm_nopm", hexf, d / cfg / "nopm", maxc)
            if not filecmp.cmp(d / cfg / "base" / "arch.csv", d / cfg / "nopm" / "arch.csv", shallow=False) or sn["fingerprint"] != sb["fingerprint"]:
                bad.append("supplied: PM_EN=0 differs from pristine")
    return bad

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--seeds", type=int, default=40); ap.add_argument("--first", type=int, default=1)
    ap.add_argument("--results", default=str(ROOT / "build" / "fuzz")); ap.add_argument("--keep", action="store_true")
    a = ap.parse_args()
    run.build(("sup", "pm", "fix", "pmfix"))
    import subprocess; subprocess.run([str(ROOT / "scripts/build_sim.sh"), "pm", "0"], cwd=ROOT, check=True, capture_output=True)
    t0 = time.time(); fails = 0
    for s in range(a.first, a.first + a.seeds):
        bad = one(s, a.results)
        if bad: fails += 1; print(f"seed {s}: FAIL {bad}")
        if not a.keep and not bad: shutil.rmtree(pathlib.Path(a.results) / f"seed{s}")
    print(f"fuzz: {a.seeds} programs x 3 builds ({time.time()-t0:.0f}s): {'ALL IDENTICAL' if not fails else str(fails)+' FAILED'}")
    sys.exit(1 if fails else 0)
