"""SilicaFlux assembler (encodings taken from decoder.sv and verified in simulation).

Formats (opcode in [31:27]):
  R: rd[26:22] rs1[21:17] rs2[16:12] func[11:0]            ADD SUB MUL
  I: rd[26:22] rs1[21:17] imm17[16:0]                      LOAD STORE MOV BEQ BNE JMP
  D: tile[26:24] reg[23:19] len[18:14] addr14[13:0]        DFLOAD DFSTORE DFMAP DFEXEC DFSYNC
  V: vrd[26:23] vrs1[22:19] vrs2[18:15] func[7:0]          VADD VMUL VSUB DOT MATMUL REDUCE BCAST VLOAD VSTORE

Quirks of the supplied RTL that shape how programs must be written (docs/BASELINE_FINDINGS.md):
  * BEQ/BNE compare rs1 with r0 (the I format has no rs2): taken iff rs1 == 0 (BEQ) / != 0 (BNE).
  * V-format instructions carry no tile id: they always execute on tile 0 (VLOAD/VSTORE use address 0).
  * a result produced by the instruction immediately before (distance 1) is NOT forwarded: keep >= 2 apart.
"""
from __future__ import annotations
from dataclasses import dataclass, field

OP = dict(NOP=0x00, ADD=0x01, SUB=0x02, MUL=0x03, LOAD=0x04, STORE=0x05, MOV=0x06, BEQ=0x07, BNE=0x08, JMP=0x09,
          DFLOAD=0x0A, DFSTORE=0x0B, DFMAP=0x0C, DFEXEC=0x0D, DFSYNC=0x0E,
          VADD=0x0F, VMUL=0x10, VSUB=0x11, DOT=0x12, MATMUL=0x13, REDUCE=0x14, BCAST=0x15, VLOAD=0x16, VSTORE=0x17,
          HALT=0x1F)
OPNAME = {v: k for k, v in OP.items()}

def R(op, rd, rs1, rs2, func=0):  return (OP[op] << 27) | (rd << 22) | (rs1 << 17) | (rs2 << 12) | (func & 0xFFF)
def I(op, rd, rs1, imm):          return (OP[op] << 27) | (rd << 22) | (rs1 << 17) | (imm & 0x1FFFF)
def D(op, tile, reg, ln, addr):   return (OP[op] << 27) | (tile << 24) | (reg << 19) | (ln << 14) | (addr & 0x3FFF)
def V(op, vrd, vrs1, vrs2, func=0): return (OP[op] << 27) | (vrd << 23) | (vrs1 << 19) | (vrs2 << 15) | (func & 0xFF)

def decode(word: int) -> str:
    op = (word >> 27) & 0x1F
    return OPNAME.get(op, f"OP{op:02x}")

@dataclass
class Prog:
    """Tiny program builder with labels and relative branches."""
    words: list = field(default_factory=list)
    labels: dict = field(default_factory=dict)
    fixups: list = field(default_factory=list)   # (index, op, rs1, label)

    def pc(self): return len(self.words)
    def emit(self, w): self.words.append(w & 0xFFFFFFFF); return self
    def nop(self, n=1):
        for _ in range(n): self.emit(0)
        return self
    def label(self, name): self.labels[name] = self.pc(); return self
    def branch(self, op, rs1, label):
        self.fixups.append((self.pc(), op, rs1, label)); return self.emit(0)
    # convenience
    def mov(self, rd, imm): return self.emit(I('MOV', rd, 0, imm))
    def alu(self, op, rd, a, b): return self.emit(R(op, rd, a, b))
    def load(self, rd, base, off): return self.emit(I('LOAD', rd, base, off))
    def dfload(self, tile, ln, addr): return self.emit(D('DFLOAD', tile, 0, ln, addr))
    def dfstore(self, tile, ln, addr): return self.emit(D('DFSTORE', tile, 0, ln, addr))
    def dfsync(self, tile=0): return self.emit(D('DFSYNC', tile, 0, 0, 0))
    def vec(self, op, vrd=3, a=1, b=2, func=0): return self.emit(V(op, vrd, a, b, func))
    def halt(self): return self.emit(0x1F << 27)

    def assemble(self):
        out = list(self.words)
        for idx, op, rs1, label in self.fixups:
            off = self.labels[label] - idx
            out[idx] = I(op, 0, rs1, off)
        return out

def write_hex(words, path):
    with open(path, "w") as f:
        for w in words: f.write(f"{w & 0xFFFFFFFF:08x}\n")
