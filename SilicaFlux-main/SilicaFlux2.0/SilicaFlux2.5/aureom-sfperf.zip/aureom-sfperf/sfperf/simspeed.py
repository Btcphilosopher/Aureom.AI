"""Simulation wall-clock overhead of the instrumentation (Icarus Verilog).

Runs the same workload on: uninstrumented (sup), instrumented with the monitor compiled out (PM_EN=0, taps only) and fully
instrumented (PM_EN=1, including the reference model, so this OVER-states the cost of the RTL monitor alone: the
`+TRACE=0 +SNAPINT=0` runs still instantiate pm_ref_model).  A fourth build without the model would isolate the RTL itself;
see the `pm_rtl_only` row: the same instrumented RTL with the testbench model compiled out.
Repeats N times, reports median and min..max.  Wall-clock on a shared machine is noisy: treat <10 % differences as noise.
"""
import json, pathlib, statistics, subprocess, sys, time
from . import run
from .isa import write_hex
from .workloads import compute_alu, mixed_kernel, mem_burst_parallel

ROOT = pathlib.Path(__file__).resolve().parent.parent

def build_rtl_only():
    """Instrumented RTL but without the testbench's reference model / tap hierarchy (PM_BUILD, PM_EN=1, no PM_MODEL)."""
    D = ROOT / "build" / "rtl_pm"
    cmd = ["iverilog", "-g2012", "-DPM_BUILD", "-DPM_EN_VAL=1", f"-I{D}", "-Irtl/perfmon", "-o", "build/sim_pm_rtlonly.vvp"]
    files = subprocess.run([str(ROOT / "scripts/rtl_files.sh"), str(D.relative_to(ROOT)), "pm"], cwd=ROOT, capture_output=True, text=True).stdout.split()
    subprocess.run(cmd + files + ["tb/tb_sys.sv"], cwd=ROOT, capture_output=True, check=True)

def timed(variant, hexf, out, maxc, reps):
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        subprocess.run(["vvp", f"build/sim_{variant}.vvp", f"+HEX={hexf}", f"+OUT={out}", f"+MAXC={maxc}", "+SNAPINT=0", "+TRACE=0"], cwd=ROOT, capture_output=True, check=True)
        ts.append(time.perf_counter() - t0)
    return ts

def main(reps=5):
    run.build(("sup", "pm")); subprocess.run([str(ROOT / "scripts/build_sim.sh"), "pm", "0"], cwd=ROOT, check=True, capture_output=True)
    build_rtl_only()
    res = {}
    out = ROOT / "build" / "simspeed"; out.mkdir(parents=True, exist_ok=True)
    for wl in (compute_alu(600), mixed_kernel(6), mem_burst_parallel(12)):
        hexf = out / f"{wl.name}.hex"; write_hex(wl.words(), hexf); row = {}
        for label, v in (("uninstrumented", "sup"), ("taps_only(PM_EN=0)", "pm_nopm"), ("pm_rtl_only", "pm_rtlonly"), ("pm_rtl+ref_model", "pm")):
            (out / v).mkdir(exist_ok=True)
            ts = timed(v, hexf, out / v, wl.maxc * 4, reps)
            row[label] = dict(median_s=statistics.median(ts), min_s=min(ts), max_s=max(ts), reps=reps)
        base = row["uninstrumented"]["median_s"]
        for k in row: row[k]["vs_uninstrumented"] = row[k]["median_s"] / base
        res[wl.name] = row
    json.dump(res, open(ROOT / "results" / "simspeed.json", "w"), indent=1)
    for w, row in res.items():
        print(w); [print(f"   {k:22s} median {v['median_s']:.3f}s  [{v['min_s']:.3f}..{v['max_s']:.3f}]  x{v['vs_uninstrumented']:.2f}") for k, v in row.items()]

if __name__ == "__main__": main()
