"""Build + run workloads on the four RTL variants and collect outputs.

  supplied : sup (uninstrumented)  / pm (instrumented)
  fixed    : fix (uninstrumented)  / pmfix (instrumented)
"""
import pathlib, subprocess, shutil, json, sys, os, time, filecmp
from .isa import write_hex
from .workloads import all_workloads

ROOT = pathlib.Path(__file__).resolve().parent.parent
VARIANTS = {"supplied": ("sup", "pm"), "fixed": ("fix", "pmfix")}

def build(variants=("sup", "pm", "fix", "pmfix")):
    for v in variants:
        subprocess.run([str(ROOT / "scripts/build_sim.sh"), v], cwd=ROOT, check=True, capture_output=True)

def run_sim(variant, hexfile, outdir, maxc, snapint=0, trace=0, wdog=0):
    outdir = pathlib.Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    cmd = ["vvp", f"build/sim_{variant}.vvp", f"+HEX={hexfile}", f"+OUT={outdir}", f"+MAXC={maxc}",
           f"+SNAPINT={snapint}", f"+TRACE={trace}", f"+WDOG={wdog}"]
    t0 = time.perf_counter()
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=1800)
    wall = time.perf_counter() - t0
    if r.returncode != 0: raise RuntimeError(f"{variant}: {r.stderr[-400:]}")
    with open(outdir / "summary.txt") as f_: summ = dict(l.strip().split("=", 1) for l in f_ if "=" in l)
    summ["wall_s"] = f"{wall:.3f}"
    return summ, r.stdout

def run_workload(wl, cfg, results, trace=0, uninstrumented=True):
    base, pm = VARIANTS[cfg]
    d = pathlib.Path(results) / cfg / wl.name
    d.mkdir(parents=True, exist_ok=True)
    hexf = d / "prog.hex"; write_hex(wl.words(), hexf)
    out = {}
    out["pm"], log = run_sim(pm, hexf, d / "pm", wl.maxc, wl.snapint, trace, wl.wdog)
    out["model_mismatches"] = int([l for l in log.splitlines() if "model mismatches" in l][0].split("=")[1])
    if uninstrumented:
        out["base"], _ = run_sim(base, hexf, d / "base", wl.maxc, 0, 0, 0)
        out["arch_identical"] = filecmp.cmp(d / "base" / "arch.csv", d / "pm" / "arch.csv", shallow=False)
        out["cycle_exact"] = (out["base"]["cycles"] == out["pm"]["cycles"] and out["base"]["fingerprint"] == out["pm"]["fingerprint"])
    return out

def run_all(results=None, trace=0):
    """Run every workload on both configurations; write results/run_manifest.json."""
    results = pathlib.Path(results or ROOT / "results")
    manifest = {}
    for cfg in VARIANTS:
        for wl in all_workloads():
            manifest[f"{cfg}/{wl.name}"] = run_workload(wl, cfg, results, trace=trace)
    results.mkdir(parents=True, exist_ok=True)
    json.dump(manifest, open(results / "run_manifest.json", "w"), indent=1)
    return manifest

