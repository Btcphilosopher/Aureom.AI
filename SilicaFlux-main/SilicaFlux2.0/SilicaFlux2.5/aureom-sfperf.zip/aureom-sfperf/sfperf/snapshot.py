"""Parse snapshots.csv written by tb_sys (values read through the real CSR path) and check invariants."""
import csv
from . import spec

class Snap:
    def __init__(self, row, header):
        d = dict(zip(header, row))
        self.seq = int(d["seq"]); self.seq_after = int(d["seq_after"]); self.cmd_cycle = int(d["cmd_cycle"])
        self.is_window = int(d["is_window"]); self.flags = int(d["flags"], 16)
        ov = (int(d["ovf1"], 16) << 32) | int(d["ovf0"], 16)
        self.ovf = {n: (ov >> i) & 1 for i, n in enumerate(spec.NAMES)}
        self.v = {n: int(d[n]) for n in spec.NAMES}
    @property
    def coherent(self): return self.seq == self.seq_after

def load(path):
    with open(path) as f:
        r = csv.reader(f); header = next(r)
        return [Snap(row, header) for row in r if row]

def totals(snaps):
    """Sum of accumulating counters over windows; peaks -> max; gauges -> last. Returns dict."""
    out = {n: 0 for n in spec.NAMES}
    for s in snaps:
        for n in spec.NAMES:
            k = spec.KIND[n]
            if k in ("count", "sum"): out[n] += s.v[n]
            elif k == "peak": out[n] = max(out[n], s.v[n])
            else: out[n] = s.v[n]
    return out

def check_invariants(v, ovf=None, windowed=False):
    """Return list of violated-invariant strings for one snapshot/window dict (empty == OK).

    windowed=False: `v` covers a whole epoch (a SNAPSHOT since CLEAR, or the sum of consecutive windows): I5 is strict.
    windowed=True : `v` is one SNAP_CLR window. A request accepted in the previous window may respond in this one, and at most
                    NT+1 = 5 requests (one per memory controller) can straddle the boundary, so I5 is MEM_RESP <= ACCEPTED + 5.
    """
    bad = []
    if ovf and any(ovf.values()): return ["overflow flagged: invariants not applicable"]
    if sum(v[n] for n in spec.SLOT_NAMES) != v["CYCLES"]: bad.append(f"I1 sum(SLOT)={sum(v[n] for n in spec.SLOT_NAMES)} != CYCLES={v['CYCLES']}")
    if sum(v[n] for n in spec.CLASS_NAMES) != v["SLOT_ISSUE"]: bad.append("I2 sum(ISS)!=SLOT_ISSUE")
    if sum(v[f"TILE_TOK_{t}"] for t in range(4)) != v["TOK_DISPATCHED"]: bad.append("I3 tile tokens != TOK_DISPATCHED")
    slack = (spec.NT + 1) if windowed else 0
    if v["MEM_RESP"] > v["MEM_REQ_ACCEPTED"] + slack: bad.append(f"I5 MEM_RESP {v['MEM_RESP']} > MEM_REQ_ACCEPTED {v['MEM_REQ_ACCEPTED']} + {slack}")
    if v["MEM_OUT_PEAK"] > 5: bad.append("I5 MEM_OUT_PEAK > 5")
    return bad
