"""Workload generators that isolate one bottleneck each.

Every workload returns a Workload with (a) the program, (b) the bottleneck it is designed to expose, and
(c) `expect`: exact or bounded counter expectations per configuration that the test-suite asserts against the
counters read from the RTL monitor -- not against the Python model.

Configurations
  supplied : the supplied RTL, unmodified.
  fixed    : supplied RTL + optional patches F1 (load-use livelock) and F2 (dispatch drop).
`expect[cfg]` maps counter name -> int (exact) | ('ge', n) | ('le', n) | ('between', lo, hi).
"""
from __future__ import annotations
from dataclasses import dataclass, field
import random
from .isa import Prog

@dataclass
class Workload:
    name: str
    family: str                      # compute | memory | dependency | divergence | mixed | pathology
    description: str
    bottleneck: str                  # what a correct analysis must conclude
    prog: Prog
    maxc: int = 12000
    snapint: int = 0                 # SNAP_CLR window for the timeline (0 = none)
    wdog: int = 0
    expect: dict = field(default_factory=dict)       # cfg -> {counter: spec}
    params: dict = field(default_factory=dict)
    configs: tuple = ("supplied", "fixed")

    def words(self): return self.prog.assemble()

def _pad(p: Prog): return p

# ------------------------------------------------------------------------------------------------ compute
def compute_alu(n=256):
    """Straight-line independent scalar ALU stream (dependence distance >= 3: fully forwarded)."""
    p = Prog()
    for r in range(1, 9): p.mov(r, r + 1)
    ops = ["ADD", "SUB", "MUL", "ADD"]
    for i in range(n):
        rd = 1 + (i % 8); a = 1 + ((i - 3) % 8); b = 1 + ((i - 4) % 8)
        p.alu(ops[i % 4], rd, a, b)
    p.halt()
    e = {"ISS_SALU": n + 8, "ISS_NOP": 1, "SLOT_ISSUE": n + 9, "SLOT_STALL_DEP": 0, "SLOT_STALL_SYNC": 0,
         "SLOT_STALL_EXEC_VEC": 0, "SLOT_STALL_EXEC_TENSOR": 0, "SLOT_STALL_MEM": 0, "SLOT_BUBBLE_CTRL": 0,
         "RET_SCALAR": n + 9, "DROP_OP": 0, "BRANCH_TAKEN": 0}
    return Workload("compute_alu", "compute", f"{n} independent scalar ALU ops, no hazards, no branches.",
                    "issue-bound (scalar compute): IPC ~ 1, no stall category above noise", p,
                    expect={"supplied": e, "fixed": e}, params={"n": n})

def compute_tensor_sync(reps=8):
    """MATMUL followed by DFSYNC, repeated: every repetition waits for the 4x4 tensor unit (tile 0)."""
    p = Prog()
    for _ in range(reps):
        p.vec("MATMUL"); p.dfsync(0)
    p.halt()
    base = {"ISS_TENSOR": reps, "ISS_DFCTL": reps, "DROP_OP": 0, "ISS_SALU": 0}
    sup = dict(base, TOK_DISPATCHED=reps, RET_TILE=reps, DROP_SYNC=reps, SLOT_STALL_SYNC=("ge", reps * 55),
               TENSOR_BUSY_CYC=("between", reps * 60, reps * 72))
    fix = dict(base, TOK_DISPATCHED=2 * reps, RET_TILE=2 * reps, DROP_SYNC=0, SLOT_STALL_SYNC=("ge", reps * 55),
               TENSOR_BUSY_CYC=("between", reps * 60, reps * 72))
    return Workload("compute_tensor_sync", "compute",
                    f"{reps} x (MATMUL; DFSYNC): serial dependence on the 4x4 tensor unit (~66 cycles each).",
                    "execution-unit bound (tensor unit); stall shows as barrier wait, attribution via TENSOR_BUSY_CYC",
                    p, maxc=2000, expect={"supplied": sup, "fixed": fix}, params={"reps": reps})

def compute_tensor_queue(n=8):
    """Back-to-back MATMULs to the single tensor unit: contention. Exposes defect F2 on the supplied RTL."""
    p = Prog()
    for _ in range(n): p.vec("MATMUL")
    p.dfsync(0); p.halt()
    sup = {"ISS_TENSOR": n, "DROP_OP": n // 2, "TOK_DISPATCHED": ("between", n // 2, n // 2 + 2),
           "SLOT_STALL_EXEC_TENSOR": ("ge", (n // 2) * 55)}
    fix = {"ISS_TENSOR": n, "DROP_OP": 0, "TOK_DISPATCHED": n + 1, "RET_TILE": n + 1,
           "SLOT_STALL_EXEC_TENSOR": ("ge", (n - 1) * 55)}
    return Workload("compute_tensor_queue", "compute",
                    f"{n} back-to-back MATMUL to the one tensor unit (execution-unit contention).",
                    "execution-unit contention (tensor); on the supplied RTL half the ops are silently dropped",
                    p, maxc=2500, expect={"supplied": sup, "fixed": fix}, params={"n": n})

def compute_vector_queue(n=32):
    """Back-to-back VMUL on tile 0's vector engine."""
    p = Prog()
    for _ in range(n): p.vec("VMUL")
    p.dfsync(0); p.halt()
    sup = {"ISS_VEC": n, "DROP_OP": ("ge", n // 3), "VEC_LANES_ACTIVE": ("ge", 4)}
    fix = {"ISS_VEC": n, "DROP_OP": 0, "RET_TILE": n + 1, "VEC_ISSUES": n, "VEC_LANES_ACTIVE": n * 4,
           "VEC_ISSUES_PARTIAL": 0, "SLOT_STALL_EXEC_VEC": ("ge", n)}
    return Workload("compute_vector_queue", "compute",
                    f"{n} back-to-back VMUL on tile 0's SIMD engine (V-format ops always target tile 0).",
                    "execution-unit contention (vector engine, single tile)",
                    p, maxc=2500, expect={"supplied": sup, "fixed": fix}, params={"n": n})

# ------------------------------------------------------------------------------------------------ memory
def mem_burst_serial(reps=8, ln=31):
    p = Prog()
    for _ in range(reps):
        p.dfload(0, ln, 0); p.dfsync(0)
    p.halt()
    sup = {"ISS_DFMEM": reps, "MEM_REQ_ACCEPTED": reps, "MEM_RESP": reps, "MEM_OUT_PEAK": 1, "MEM_REQ_BLOCKED": 0,
           "DROP_OP": 0, "MEM_OUT_SUM": ("between", reps * (ln + 1), reps * (ln + 8))}
    fix = dict(sup)
    return Workload("mem_burst_serial", "memory",
                    f"{reps} x (DFLOAD {ln} words on tile 0; DFSYNC): memory latency, no overlap.",
                    "memory-latency bound, memory-level parallelism = 1", p, maxc=2500,
                    expect={"supplied": sup, "fixed": fix}, params={"reps": reps, "len": ln})

def mem_burst_parallel(rounds=4, ln=31):
    p = Prog()
    for _ in range(rounds):
        for t in range(4): p.dfload(t, ln, 0)
        p.dfsync(0)
    p.halt()
    sup = {"ISS_DFMEM": 4 * rounds, "MEM_REQ_ACCEPTED": 4 * rounds, "MEM_RESP": 4 * rounds, "MEM_OUT_PEAK": 4,
           "MEM_REQ_BLOCKED": 0, "DROP_OP": 0}
    fix = dict(sup)
    return Workload("mem_burst_parallel", "memory",
                    f"{rounds} rounds of 4 concurrent {ln}-word DFLOADs (one per tile) then DFSYNC.",
                    "memory-level parallelism = 4 (4 tile scratchpads in parallel)", p, maxc=2500,
                    expect={"supplied": sup, "fixed": fix}, params={"rounds": rounds, "len": ln})

def mem_conflict_queue(n=8, ln=31):
    p = Prog()
    for _ in range(n): p.dfload(0, ln, 0)
    p.dfsync(0); p.halt()
    sup = {"ISS_DFMEM": n, "DROP_OP": ("ge", n // 3), "SLOT_STALL_MEM": ("ge", (n // 2) * 25)}
    fix = {"ISS_DFMEM": n, "DROP_OP": 0, "MEM_REQ_ACCEPTED": n, "MEM_RESP": n, "MEM_OUT_PEAK": 1,
           "SLOT_STALL_MEM": ("ge", (n - 1) * 25)}
    return Workload("mem_conflict_queue", "memory",
                    f"{n} back-to-back {ln}-word DFLOADs on the same tile (one memory controller).",
                    "memory backpressure: requests queue behind a busy scratchpad controller", p, maxc=2500,
                    expect={"supplied": sup, "fixed": fix}, params={"n": n, "len": ln})

def mem_scalar_backtoback(n=16):
    p = Prog()
    p.mov(10, 64); p.nop(4)
    for i in range(n): p.load(11 + (i % 4), 10, 4 * i)
    p.nop(4); p.halt()
    e = {"ISS_SMEM": n, "MEM_REQ_BLOCKED": n // 2, "MEM_REQ_ACCEPTED": n // 2}
    return Workload("mem_scalar_backtoback", "memory",
                    f"{n} consecutive scalar LOADs: the control core fires one-shot requests ignoring ready.",
                    "memory backpressure (lost requests): half of the requests hit a busy controller", p,
                    maxc=1000, expect={"supplied": e, "fixed": e}, params={"n": n})

# ------------------------------------------------------------------------------------------------ dependency
def dep_load_use(pairs=32):
    p = Prog()
    p.mov(10, 64); p.nop(4)
    for i in range(pairs):
        d = 11 + (i % 4)
        p.load(d, 10, 4 * i)
        p.alu("ADD", 20, d, d)       # consumes the load result immediately -> load-use interlock
        p.nop(3)
    p.halt()
    sup = {"SLOT_STALL_DEP": ("ge", 100), "STALL_STREAK_MAX": ("ge", 100)}     # livelock (defect F1)
    fix = {"SLOT_STALL_DEP": pairs, "ISS_SMEM": pairs, "MEM_REQ_BLOCKED": 0}
    return Workload("dep_load_use", "dependency",
                    f"{pairs} x (LOAD; dependent ADD): exercises the scalar RAW interlock.",
                    "dependency (RAW) stalls: exactly one slot per pair when the interlock works; "
                    "a permanent hang on the supplied RTL", p, maxc=1500, wdog=400,
                    expect={"supplied": sup, "fixed": fix}, params={"pairs": pairs})

def dep_sync_chain(rounds=8):
    p = Prog()
    for _ in range(rounds):
        p.dfload(0, 16, 0); p.dfsync(1); p.vec("VADD"); p.dfsync(1)
    p.halt()
    sup = {"ISS_DFMEM": rounds, "ISS_VEC": rounds, "ISS_DFCTL": 2 * rounds, "DROP_OP": 0,
           "SLOT_STALL_SYNC": ("ge", rounds * 15)}
    return Workload("dep_sync_chain", "dependency",
                    f"{rounds} x (DFLOAD; DFSYNC; VADD; DFSYNC): producer/consumer ordering through barriers.",
                    "dataflow dependency (barrier waits)", p, maxc=2500,
                    expect={"supplied": sup, "fixed": dict(sup)}, params={"rounds": rounds})

def dep_alu_chain(n=128):
    p = Prog()
    for r in range(1, 4): p.mov(r, r)
    for i in range(n):
        rd = 1 + (i % 3); p.alu("ADD", rd, rd, rd) if False else p.alu("ADD", rd, 1 + ((i - 3) % 3), 1 + ((i - 3) % 3))
    p.halt()
    e = {"SLOT_STALL_DEP": 0, "SLOT_ISSUE": n + 4, "DROP_OP": 0, "BRANCH_TAKEN": 0}
    return Workload("dep_alu_chain", "dependency",
                    f"{n}-long dependent ALU chain (distance 3): control experiment, forwarding hides the dependence.",
                    "no stall: the RAW dependence is hidden by forwarding (negative control)", p, maxc=1000,
                    expect={"supplied": e, "fixed": e}, params={"n": n})

# ------------------------------------------------------------------------------------------------ divergence
def div_branch_sweep(p_taken=0.5, sites=48, body=4, seed=7):
    """`sites` forward branches; each is taken with probability p_taken (data from MOV constants)."""
    rng = random.Random(seed)
    k = round(p_taken * sites)
    taken = [True] * k + [False] * (sites - k)
    rng.shuffle(taken)
    p = Prog()
    for i, t in enumerate(taken):
        p.mov(1, 0 if t else 1)      # BEQ r1,r0 is taken iff r1 == 0
        p.nop(2)                     # keep the BEQ >= 3 instructions after the MOV (no stale operand)
        p.branch("BEQ", 1, f"s{i}")
        for j in range(body): p.alu("ADD", 20 + j, 21 + j, 22 + j)   # skipped when taken
        p.label(f"s{i}")
    p.halt()
    n_taken = k
    e = {"BRANCH_TAKEN": n_taken, "SLOT_BUBBLE_CTRL": 3 * n_taken, "ISS_BRANCH": sites, "SLOT_STALL_DEP": 0,
         "SLOT_STALL_SYNC": 0, "DROP_OP": 0}
    name = f"div_branch_p{int(round(p_taken * 100)):03d}"
    return Workload(name, "divergence",
                    f"{sites} data-dependent forward branches, {int(round(p_taken*100))}% taken, {body}-instruction skipped body.",
                    "control-flow divergence: 3 slots lost per taken branch (flush + 2-cycle redirect shadow)", p,
                    maxc=3000, expect={"supplied": e, "fixed": e}, params={"p_taken": p_taken, "sites": sites})

def div_loop_taken(iters=64):
    p = Prog()
    p.mov(1, iters); p.mov(3, 5); p.mov(4, 1); p.nop(3)
    p.label("loop")
    p.alu("ADD", 2, 2, 3)
    p.alu("SUB", 1, 1, 4)
    p.nop(2)
    p.branch("BNE", 1, "loop")
    p.nop(3); p.halt()
    e = {"BRANCH_TAKEN": iters - 1, "SLOT_BUBBLE_CTRL": 3 * (iters - 1), "ISS_BRANCH": ("ge", iters)}
    return Workload("div_loop_taken", "divergence",
                    f"tight loop, {iters} iterations, one taken backward branch per iteration.",
                    "control-flow bubbles dominate a short loop body", p, maxc=3000,
                    expect={"supplied": e, "fixed": e}, params={"iters": iters})

# ------------------------------------------------------------------------------------------------ mixed
def mixed_kernel(rounds=10):
    """Phased kernel: ALU burst | tile-1 load | tensor + sync | branchy tail. For the time-line chart."""
    p = Prog()
    for r in range(rounds):
        for i in range(24):
            p.alu(["ADD", "SUB", "MUL"][i % 3], 1 + (i % 8), 1 + ((i - 3) % 8), 1 + ((i - 4) % 8))
        p.dfload(1, 24, 0); p.dfload(2, 24, 0); p.dfsync(3)
        p.vec("MATMUL"); p.dfsync(0)
        for i in range(6):
            p.mov(1, 0 if i % 2 == 0 else 1); p.nop(2)
            p.branch("BEQ", 1, f"m{r}_{i}")
            p.alu("ADD", 20, 21, 22); p.alu("ADD", 23, 24, 25)
            p.label(f"m{r}_{i}")
    p.halt()
    return Workload("mixed_kernel", "mixed",
                    f"{rounds} phases of ALU burst, parallel scratchpad loads, tensor op behind a barrier, branchy tail.",
                    "phase-dependent: compute -> memory -> barrier/tensor -> control", p, maxc=8000, snapint=140,
                    expect={"supplied": {"DROP_OP": 0, "BRANCH_TAKEN": 3 * rounds}, "fixed": {"DROP_OP": 0, "BRANCH_TAKEN": 3 * rounds}},
                    params={"rounds": rounds})

def all_workloads():
    w = [compute_alu(), compute_tensor_sync(), compute_tensor_queue(), compute_vector_queue(),
         mem_burst_serial(), mem_burst_parallel(), mem_conflict_queue(), mem_scalar_backtoback(),
         dep_load_use(), dep_sync_chain(), dep_alu_chain()]
    w += [div_branch_sweep(p) for p in (0.0, 0.25, 0.5, 0.75, 1.0)]
    w += [div_loop_taken(), mixed_kernel()]
    return w
