"""matplotlib charts (PNG) following the dataviz method: validated categorical palette in fixed slot order,
text in ink tokens (never series colour), surface-coloured gaps between stacked segments, recessive grid,
small multiples instead of dual axes, legend + selective direct labels.  Each chart also writes its data as CSV.
"""
import csv, json, pathlib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from . import metrics, snapshot, bottleneck, spec

# --- design tokens (palette validated with the dataviz validate_palette.js; see docs/ANALYSIS.md)
THEMES = {
    "light": dict(surface="#fcfcfb", ink="#0b0b0b", ink2="#52514e", grid="#e7e6e2", idle="#c9c8c4",
                  series=["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6"],
                  seq=["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]),
    "dark":  dict(surface="#1a1a19", ink="#f0efec", ink2="#c3c2b7", grid="#2e2e2c", idle="#4a4a47",
                  series=["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#0ca30c", "#9085e9"],
                  seq=["#0d366b", "#184f95", "#256abf", "#2a78d6", "#3987e5", "#6da7ec", "#9ec5f4"]),
}
STACK_ORDER = ["Issue", "Dependency (RAW)", "Barrier wait", "Execution unit", "Memory", "Control flow", "Other"]

def _lum(h):
    c = [int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    c = [x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4 for x in c]
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
def _label_ink(fill, T):          # choose black or white for the label ON a fill by contrast (ink tokens only)
    lf = _lum(fill)
    cb = (lf + 0.05) / (_lum("#0b0b0b") + 0.05); cw = (_lum("#ffffff") + 0.05) / (lf + 0.05)
    return "#0b0b0b" if cb >= cw else "#ffffff"

def _style(T):
    plt.rcParams.update({"figure.facecolor": T["surface"], "axes.facecolor": T["surface"], "savefig.facecolor": T["surface"],
        "text.color": T["ink"], "axes.labelcolor": T["ink2"], "xtick.color": T["ink2"], "ytick.color": T["ink2"],
        "axes.edgecolor": T["grid"], "font.size": 9.5, "axes.titlesize": 11, "axes.titleweight": "bold",
        "axes.spines.top": False, "axes.spines.right": False, "grid.color": T["grid"], "grid.linewidth": 0.8})

def _save(fig, path, rows=None, header=None):
    path = pathlib.Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=150, bbox_inches="tight"); plt.close(fig)
    if rows is not None:
        with open(path.with_suffix(".csv"), "w", newline="") as f:
            w = csv.writer(f); w.writerow(header); w.writerows(rows)

def load_runs(results, cfg):
    """{workload: (totals, derived, snaps)} for one configuration."""
    out = {}
    for d in sorted((pathlib.Path(results) / cfg).iterdir()):
        sp = d / "pm" / "snapshots.csv"
        if sp.exists():
            snaps = snapshot.load(sp); t = snapshot.totals(snaps)
            out[d.name] = (t, metrics.derive(t), snaps)
    return out

def _legend(ax, T, names, colors, extra=None, ncol=None):
    h = [Patch(facecolor=c, edgecolor=T["surface"], label=n) for n, c in zip(names, colors)]
    if extra: h += extra
    ax.legend(handles=h, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=ncol or len(h), frameon=False,
              fontsize=8.5, labelcolor=T["ink2"], handlelength=1.2, columnspacing=1.1)

# ------------------------------------------------------------------------------------------------ 1. CPI stack
def cpi_stack(results, cfg, out, theme="light", order=None):
    T = THEMES[theme]; _style(T); runs = load_runs(results, cfg)
    names = order or list(runs)
    names = [n for n in names if n in runs]
    fig, ax = plt.subplots(figsize=(10.5, 0.36 * len(names) + 1.7))
    rows = []
    for i, n in enumerate(names):
        d = runs[n][1]; left = 0.0
        for k, g in enumerate(STACK_ORDER):
            w = d["frac_" + g] * 100
            if w <= 0: continue
            ax.barh(i, w, left=left, height=0.62, color=T["series"][k], edgecolor=T["surface"], linewidth=1.6)
            if w >= 7: ax.text(left + w / 2, i, f"{w:.0f}%", ha="center", va="center", fontsize=8, color=_label_ink(T["series"][k], T))
            left += w
        hung = runs[n][0]["STALL_STREAK_MAX"] >= bottleneck.HANG_MIN and runs[n][0]["STALL_STREAK_MAX"] >= bottleneck.HANG_FRAC * d["active"]
        ax.text(101.5, i, f"IPC {d['ipc']:.2f}   {d['active']} cyc" + ("   HANG" if hung else ""), va="center", fontsize=8,
                color=T["ink"] if hung else T["ink2"], fontweight="bold" if hung else "normal")
        rows.append([n] + [f"{d['frac_' + g]:.4f}" for g in STACK_ORDER] + [f"{d['ipc']:.4f}", d["active"], d["idle"]])
    ax.set_yticks(range(len(names))); ax.set_yticklabels(names); ax.invert_yaxis()
    ax.set_xlim(0, 100); ax.set_xlabel("share of active cycles (IDLE excluded)  -  mutually exclusive issue-slot categories")
    ax.xaxis.grid(True); ax.set_axisbelow(True); ax.tick_params(length=0)
    for s in ("left", "bottom"): ax.spines[s].set_visible(False)
    ax.set_title(f"Why the issue slot is lost -- {cfg} RTL" , loc="left", pad=34)
    _legend(ax, T, STACK_ORDER, T["series"])
    _save(fig, out, rows, ["workload"] + STACK_ORDER + ["ipc", "active_cycles", "idle_cycles"])

# ------------------------------------------------------------------------------------------------ 2. timeline
def timeline(results, cfg, wl, out, theme="light"):
    T = THEMES[theme]; _style(T)
    snaps = snapshot.load(pathlib.Path(results) / cfg / wl / "pm" / "snapshots.csv")
    fig, ax = plt.subplots(figsize=(10.5, 3.6)); rows = []; t0 = 0
    for i, s in enumerate(snaps):
        d = metrics.derive(s.v); left = 0.0
        for k, g in enumerate(STACK_ORDER):
            w = d["frac_" + g] * 100
            if w > 0: ax.bar(i, w, bottom=left, width=0.72, color=T["series"][k], edgecolor=T["surface"], linewidth=1.6)
            if w >= 9: ax.text(i, left + w / 2, f"{w:.0f}", ha="center", va="center", fontsize=7.5, color=_label_ink(T["series"][k], T))
            left += w
        rows.append([i, s.cmd_cycle, s.v["CYCLES"]] + [f"{d['frac_' + g]:.4f}" for g in STACK_ORDER])
    ax.set_xticks(range(len(snaps))); ax.set_xticklabels([f"{s.cmd_cycle}" for s in snaps], rotation=0, fontsize=8)
    ax.set_xlabel("cycle at which the window was closed (each bar = one SNAP_CLR window)"); ax.set_ylabel("% of active cycles in window")
    ax.set_ylim(0, 100); ax.yaxis.grid(True); ax.set_axisbelow(True); ax.tick_params(length=0)
    for s in ("left", "bottom"): ax.spines[s].set_visible(False)
    ax.set_title(f"{wl}: stall composition per snapshot window ({cfg})", loc="left", pad=30)
    _legend(ax, T, STACK_ORDER, T["series"])
    _save(fig, out, rows, ["window", "cmd_cycle", "cycles"] + STACK_ORDER)

# ------------------------------------------------------------------------------------------------ 3. divergence sweep
def divergence_sweep(results, cfg, out, theme="light"):
    T = THEMES[theme]; _style(T); runs = load_runs(results, cfg)
    pts = sorted((runs[n][1]["taken_rate"] * 100, runs[n][1]["frac_Control flow"] * 100, runs[n][1]["ipc"], runs[n][0]["SLOT_BUBBLE_CTRL"], runs[n][0]["BRANCH_TAKEN"])
                 for n in runs if n.startswith("div_branch_p"))
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(6.6, 5.4), sharex=True)
    xs = [p[0] for p in pts]
    a1.plot(xs, [p[1] for p in pts], "-o", color=T["series"][5], lw=2, ms=7, mfc=T["series"][5], mec=T["surface"], mew=2)
    a2.plot(xs, [p[2] for p in pts], "-o", color=T["series"][0], lw=2, ms=7, mfc=T["series"][0], mec=T["surface"], mew=2)
    for p in pts:
        a1.annotate(f"{p[1]:.0f}%", (p[0], p[1]), textcoords="offset points", xytext=(0, 9), ha="center", fontsize=8, color=T["ink2"])
        a2.annotate(f"{p[2]:.2f}", (p[0], p[2]), textcoords="offset points", xytext=(0, 9), ha="center", fontsize=8, color=T["ink2"])
    a1.set_ylabel("slots lost to control flow\n(% of active cycles)"); a2.set_ylabel("IPC (issued / active cycle)")
    a2.set_xlabel("measured taken-branch rate (BRANCH_TAKEN / ISS_BRANCH, %)")
    a1.set_ylim(-3, max(p[1] for p in pts) * 1.25); a2.set_ylim(0.5, 1.08)
    for a in (a1, a2): a.yaxis.grid(True); a.set_axisbelow(True); a.tick_params(length=0)
    a1.set_title(f"Control-flow divergence cost vs taken rate ({cfg})", loc="left")
    _save(fig, out, [[f"{p[0]:.1f}", f"{p[1]:.2f}", f"{p[2]:.4f}", p[3], p[4]] for p in pts],
          ["taken_rate_pct", "ctrl_slots_pct_active", "ipc", "SLOT_BUBBLE_CTRL", "BRANCH_TAKEN"])

# ------------------------------------------------------------------------------------------------ 4. memory parallelism
def memory_parallelism(results, cfg, out, theme="light"):
    T = THEMES[theme]; _style(T); runs = load_runs(results, cfg)
    names = [n for n in ("mem_burst_serial", "mem_burst_parallel", "mem_conflict_queue") if n in runs]
    panels = [("avg outstanding requests\n(MEM_OUT_SUM / active)", lambda d: d["mem_avg_out"], "{:.2f}"),
              ("peak outstanding\n(MEM_OUT_PEAK)", lambda d: d["mem_peak"], "{:.0f}"),
              ("latency per request, cycles\n(Little: MEM_OUT_SUM / MEM_RESP)", lambda d: d["mem_latency"] or 0, "{:.1f}"),
              ("memory share of issue slots lost\n(SLOT_STALL_MEM + memory-wait barrier)", None, "{:.0f}%")]
    fig, axs = plt.subplots(1, 4, figsize=(11.5, 3.6)); rows = []
    for ax, (title, fn, fmt) in zip(axs, panels):
        for i, n in enumerate(names):
            d = runs[n][1]; t = runs[n][0]
            v = fn(d) if fn else (t["SLOT_STALL_MEM"] + t["SLOT_STALL_SYNC"]) / max(d["active"], 1) * 100
            ax.bar(i, v, width=0.6, color=T["series"][0] if i == 0 else T["series"][2] if i == 1 else T["series"][4], edgecolor=T["surface"], linewidth=1.6)
            ax.text(i, v, fmt.format(v), ha="center", va="bottom", fontsize=8.5, color=T["ink"])
        ax.set_xticks(range(len(names))); ax.set_xticklabels([n.replace("mem_", "").replace("_", "\n") for n in names], fontsize=8)
        ax.set_title(title, fontsize=8.5, loc="left", fontweight="normal", color=T["ink2"]); ax.yaxis.grid(True); ax.set_axisbelow(True); ax.tick_params(length=0)
        ax.set_ylim(0, ax.get_ylim()[1] * 1.15)
    for n in names:
        d = runs[n][1]; t = runs[n][0]
        rows.append([n, f"{d['mem_avg_out']:.3f}", d["mem_peak"], f"{(d['mem_latency'] or 0):.2f}", t["SLOT_STALL_MEM"], t["SLOT_STALL_SYNC"], d["active"]])
    fig.suptitle(f"Memory-level parallelism and backpressure ({cfg})", x=0.01, ha="left", fontweight="bold", fontsize=11)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    _save(fig, out, rows, ["workload", "avg_outstanding", "peak_outstanding", "latency_cycles", "SLOT_STALL_MEM", "SLOT_STALL_SYNC", "active_cycles"])

# ------------------------------------------------------------------------------------------------ 5. utilisation heatmap
def utilisation(results, cfg, out, theme="light"):
    T = THEMES[theme]; _style(T); runs = load_runs(results, cfg)
    cols = [("IPC", lambda d, t: d["ipc"], "{:.2f}"), ("tensor unit\nbusy", lambda d, t: d["tensor_busy"], "{:.2f}"),
            ("vector eng.\nbusy", lambda d, t: d["vec_busy"], "{:.2f}"), ("lane\nutil", lambda d, t: d["lane_util"], "{:.3f}"),
            ("mem busy\nfraction", lambda d, t: d["mem_busy_frac"], "{:.2f}"), ("avg mem\noutstanding", lambda d, t: d["mem_avg_out"], "{:.2f}"),
            ("avg tokens\nin flight", lambda d, t: d["q_tok_avg"], "{:.2f}"), ("dispatch slot\noccupancy", lambda d, t: d["q_disp_occ"], "{:.2f}")]
    names = list(runs)
    import numpy as np
    M = np.array([[fn(runs[n][1], runs[n][0]) for _, fn, _ in cols] for n in names], float)
    N = M / np.where(M.max(0) > 0, M.max(0), 1)
    from matplotlib.colors import LinearSegmentedColormap
    cm = LinearSegmentedColormap.from_list("seq", T["seq"] if theme == "light" else T["seq"])
    fig, ax = plt.subplots(figsize=(10.2, 0.34 * len(names) + 1.9))
    ax.imshow(N, aspect="auto", cmap=cm, vmin=0, vmax=1)
    for i in range(len(names)):
        for j, (_, _, fmt) in enumerate(cols):
            c = cm(N[i, j]); lum = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
            ax.text(j, i, fmt.format(M[i, j]), ha="center", va="center", fontsize=8, color="#0b0b0b" if lum > 0.45 else "#ffffff")
    ax.set_xticks(range(len(cols))); ax.set_xticklabels([c[0] for c in cols], fontsize=8); ax.xaxis.tick_top()
    ax.set_yticks(range(len(names))); ax.set_yticklabels(names); ax.tick_params(length=0)
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_xticks([x - .5 for x in range(1, len(cols))], minor=True); ax.set_yticks([y - .5 for y in range(1, len(names))], minor=True)
    ax.grid(which="minor", color=T["surface"], linewidth=1.6); ax.tick_params(which="minor", length=0)
    fig.suptitle(f"Unit activity, memory parallelism and queue occupancy ({cfg}) -- colour scaled per column, values printed", x=0.01, ha="left", fontweight="bold", fontsize=10.5, y=0.995)
    _save(fig, out, [[n] + [f"{v:.4f}" for v in M[i]] for i, n in enumerate(names)], ["workload"] + [c[0].replace("\n", " ") for c in cols])

# ------------------------------------------------------------------------------------------------ 6. supplied vs fixed
def supplied_vs_fixed(results, out, theme="light"):
    T = THEMES[theme]; _style(T); a = load_runs(results, "supplied"); b = load_runs(results, "fixed")
    names = [n for n in a if n in b and (a[n][1]["cycles"] != b[n][1]["cycles"] or a[n][0]["DROP_OP"] != b[n][0]["DROP_OP"] or a[n][0]["STALL_STREAK_MAX"] > 400)]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 0.45 * len(names) + 1.8), sharey=True); rows = []
    h = 0.36
    for i, n in enumerate(names):
        for ax, key, fmt in ((ax1, lambda r: r[1]["cycles"], "{:.0f}"), (ax2, lambda r: r[0]["DROP_OP"], "{:.0f}")):
            va, vb = key(a[n]), key(b[n])
            ax.barh(i - h / 2, va, height=h, color=T["series"][1], edgecolor=T["surface"], linewidth=1.4)
            ax.barh(i + h / 2, vb, height=h, color=T["series"][0], edgecolor=T["surface"], linewidth=1.4)
            for yy, v in ((i - h / 2, va), (i + h / 2, vb)): ax.text(v, yy, " " + fmt.format(v), va="center", fontsize=8, color=T["ink2"])
        rows.append([n, a[n][1]["cycles"], b[n][1]["cycles"], a[n][0]["DROP_OP"], b[n][0]["DROP_OP"]])
    ax1.set_yticks(range(len(names))); ax1.set_yticklabels(names); ax1.invert_yaxis()
    ax1.set_title("run length (cycles)  [hung runs stop at the cycle limit]", loc="left", fontsize=9.5); ax2.set_title("scheduler ops lost (DROP_OP)", loc="left", fontsize=9.5)
    for ax in (ax1, ax2): ax.xaxis.grid(True); ax.set_axisbelow(True); ax.tick_params(length=0); ax.spines["left"].set_visible(False); ax.spines["bottom"].set_visible(False); ax.set_xlim(0, ax.get_xlim()[1] * 1.12)
    ax1.legend(handles=[Patch(facecolor=T["series"][1], label="supplied RTL"), Patch(facecolor=T["series"][0], label="with optional fixes F1+F2")],
               loc="lower center", bbox_to_anchor=(1.0, 1.08), ncol=2, frameon=False, fontsize=8.5, labelcolor=T["ink2"])
    _save(fig, out, rows, ["workload", "cycles_supplied", "cycles_fixed", "DROP_OP_supplied", "DROP_OP_fixed"])

# ------------------------------------------------------------------------------------------------ 7. overhead
def overhead(syn_dir, out, theme="light", sim=None):
    T = THEMES[theme]; _style(T); syn = pathlib.Path(syn_dir)
    S = {n: json.load(open(syn / f"syn_{n}" / "summary.json")) for n in ("sup", "pm0", "pm1") if (syn / f"syn_{n}" / "summary.json").exists()}
    if "sup" not in S or "pm1" not in S: return False
    panels = [("flip-flops", lambda s: s["generic_gates"]["ff"]), ("generic 2-input gates", lambda s: s["generic_gates"]["comb"]),
              ("LUT6", lambda s: s["lut6"]["comb"]), ("logic depth, LUT6 levels\n(longest path)", lambda s: s["lut6"]["ltp"] or 0)]
    labels = [("supplied", "sup"), ("taps only\n(PM_EN=0)", "pm0"), ("instrumented\n(PM_EN=1)", "pm1")]
    labels = [l for l in labels if l[1] in S]
    fig, axs = plt.subplots(1, 4, figsize=(11.5, 3.5)); rows = []
    for ax, (title, fn) in zip(axs, panels):
        base = fn(S["sup"])
        for i, (lab, key) in enumerate(labels):
            v = fn(S[key]); ax.bar(i, v, width=0.6, color=T["series"][[0, 2, 1][i]], edgecolor=T["surface"], linewidth=1.6)
            ax.text(i, v, f"{v:,}" + ("" if i == 0 else f"\n{(v - base) / base:+.1%}"), ha="center", va="bottom", fontsize=8, color=T["ink"])
        ax.set_xticks(range(len(labels))); ax.set_xticklabels([l[0] for l in labels], fontsize=8); ax.set_title(title, fontsize=9, loc="left", color=T["ink2"], fontweight="normal")
        ax.set_ylim(0, ax.get_ylim()[1] * 1.22); ax.yaxis.grid(True); ax.set_axisbelow(True); ax.tick_params(length=0)
    for k, v in S.items(): rows.append([k, v["generic_gates"]["ff"], v["generic_gates"]["comb"], v["lut6"]["comb"], v["generic_gates"]["ltp"], v["lut6"]["ltp"], v["generic_gates"]["mem_bits"]])
    fig.suptitle("Instrumentation overhead -- Yosys synthesis proxies (not silicon area or timing); memories excluded", x=0.01, ha="left", fontweight="bold", fontsize=10.5)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    _save(fig, out, rows, ["variant", "ff", "generic_gates", "lut6", "ltp_gates", "ltp_lut6", "mem_bits"])
    return True

def all_charts(results, out_dir, syn_dir=None):
    out = pathlib.Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    order = ["compute_alu", "compute_tensor_sync", "compute_tensor_queue", "compute_vector_queue", "mem_burst_serial", "mem_burst_parallel",
             "mem_conflict_queue", "mem_scalar_backtoback", "dep_load_use", "dep_sync_chain", "dep_alu_chain",
             "div_branch_p000", "div_branch_p025", "div_branch_p050", "div_branch_p075", "div_branch_p100", "div_loop_taken", "mixed_kernel"]
    for cfg in ("supplied", "fixed"):
        cpi_stack(results, cfg, out / f"cpi_stack_{cfg}.png", "light", order)
        utilisation(results, cfg, out / f"utilisation_{cfg}.png")
        divergence_sweep(results, cfg, out / f"divergence_sweep_{cfg}.png")
        memory_parallelism(results, cfg, out / f"memory_parallelism_{cfg}.png")
        timeline(results, cfg, "mixed_kernel", out / f"timeline_mixed_kernel_{cfg}.png")
    cpi_stack(results, "supplied", out / "cpi_stack_supplied_dark.png", "dark", order)
    timeline(results, "fixed", "mixed_kernel", out / "timeline_mixed_kernel_fixed_dark.png", "dark")
    supplied_vs_fixed(results, out / "supplied_vs_fixed.png")
    if syn_dir: overhead(syn_dir, out / "overhead.png")
