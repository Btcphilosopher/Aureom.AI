"""Counter specification loader (single source of truth: spec/pm_counters.json)."""
import json, pathlib
ROOT = pathlib.Path(__file__).resolve().parent.parent
with open(ROOT / "spec" / "pm_counters.json") as _f: SPEC = json.load(_f)
COUNTERS = SPEC["counters"]
NAMES = [c["name"] for c in COUNTERS]
INDEX = {n: i for i, n in enumerate(NAMES)}
KIND = {c["name"]: c["kind"] for c in COUNTERS}
SLOT_NAMES = [c["name"] for c in COUNTERS if c.get("exclusive_set") == "slot"]
CLASS_NAMES = [c["name"] for c in COUNTERS if c.get("exclusive_set") == "issue_class"]
NT, LANES = 4, 4
