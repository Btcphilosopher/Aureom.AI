"""python -m sfperf <command>   (run from the project root)

  run        build the four simulators, run every workload on both configurations, write results/run_manifest.json
  report     build results/REPORT.md + summary.csv/json from results/
  charts     render the PNG charts (+ CSV data) into results/charts
  analyze    decode one run directory:  python -m sfperf analyze results/supplied/mem_burst_serial
  check      independent trace re-derivation (sfperf.trace_check) on run directories
  fuzz       random-program equivalence fuzzing
  all        run + report + charts
"""
import argparse, json, pathlib, sys
from . import run, report, charts, snapshot, bottleneck, metrics, spec

ROOT = pathlib.Path(__file__).resolve().parent.parent

def cmd_analyze(path):
    snaps = snapshot.load(pathlib.Path(path) / "pm" / "snapshots.csv") if (pathlib.Path(path) / "pm").exists() else snapshot.load(pathlib.Path(path) / "snapshots.csv")
    t = snapshot.totals(snaps); prim, allf, defects, d = bottleneck.classify(t)
    print(f"cycles {d['cycles']}  active {d['active']}  idle {d['idle']}  IPC {d['ipc']:.3f}  windows {len(snaps)}")
    print("issue-slot breakdown (share of active cycles):")
    for g, _ in metrics.GROUPS[:-1]: print(f"  {g:18s}{d['frac_' + g]:7.1%}")
    print(f"memory: avg outstanding {d['mem_avg_out']:.2f} peak {d['mem_peak']} latency {d['mem_latency']}  blocked {d['mem_blocked']}")
    print(f"queues: tokens avg {d['q_tok_avg']:.2f} peak {d['q_tok_peak']}   dispatch-slot occupancy {d['q_disp_occ']:.2f}")
    print(f"primary bottleneck: [{prim.family}] {prim.label} ({prim.weight:.0%})")
    for e in prim.evidence: print("   evidence:", e)
    if prim.advice: print("   advice:  ", prim.advice)
    for f in allf[1:]: print(f"also: [{f.family}] {f.label} ({f.weight:.0%})")
    for x in defects: print(f"DEFECT: {x.label}\n   {x.advice}")
    inv = snapshot.check_invariants(t, snaps[-1].ovf); print("invariants:", "OK" if not inv else inv)

def main(argv=None):
    ap = argparse.ArgumentParser(prog="sfperf", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["run", "report", "charts", "analyze", "check", "fuzz", "all"]); ap.add_argument("args", nargs="*")
    ap.add_argument("--results", default=str(ROOT / "results")); ap.add_argument("--syn", default=str(ROOT / "results" / "synthesis")); ap.add_argument("--trace", action="store_true", help="also dump per-cycle tap traces (needed by trace-check)")
    a = ap.parse_args(argv)
    if a.cmd == "analyze": return cmd_analyze(a.args[0])
    if a.cmd in ("run", "all"): run.build(); run.run_all(a.results, trace=1 if a.trace else 0)
    if a.cmd in ("report", "all"):
        vf = pathlib.Path(a.results) / "verification.json"
        report.write(a.results, a.syn, json.load(open(vf)) if vf.exists() else None)
    if a.cmd in ("charts", "all"): charts.all_charts(a.results, pathlib.Path(a.results) / "charts", a.syn)
    if a.cmd == "check":
        from . import trace_check; sys.exit(trace_check.main(a.args))
    if a.cmd == "fuzz":
        from . import fuzz; sys.argv = ["fuzz"] + a.args; runpy = __import__("runpy"); runpy.run_module("sfperf.fuzz", run_name="__main__")
if __name__ == "__main__": main()
