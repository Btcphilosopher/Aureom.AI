# Mutation test report

26 single-point mutants of `rtl/perfmon/` against `tb/tb_pm_unit.sv` (survivors re-run with SVA under Verilator). **25/25 non-equivalent mutants killed**; 1 mutant proven equivalent (not scored).

| id | mutation | result | evidence |
|---|---|---|---|
| M01 | priority: load-use before barrier (`sf_pm_events.sv`) | KILLED | 2 FAIL, 7 MISMATCH; first: [FAIL] classify: sync_stall beats load_use -> STALL_SYNC |
| M02 | flush no longer beats a stall (`sf_pm_events.sv`) | KILLED | 6 FAIL, 7 MISMATCH; first: [FAIL] classify: flush beats stall -> BUBBLE_CTRL |
| M03 | DFSYNC held at dispatch not counted as barrier wait (`sf_pm_events.sv`) | KILLED | 7 FAIL, 7 MISMATCH; first: [FAIL] classify: DFSYNC held at dispatch behind busy tile -> STALL_SYNC (not EXEC) |
| M04 | redirect shadow too long (3) (`sf_perfmon.sv`) | KILLED | 7 FAIL, 7 MISMATCH; first: [FAIL] classify: after shadow, EX busy -> BUBBLE_FRONT |
| M05 | retirement ignores replay filtering (`sf_pm_events.sv`) | KILLED | 12 FAIL, 7 MISMATCH; first: [FAIL] T2 shadow equals reference model |
| M06 | drop detector ignores dispatched token (`sf_pm_events.sv`) | KILLED | 12 FAIL, 7 MISMATCH; first: [FAIL] T2 shadow equals reference model |
| M07 | outstanding tracker never clears (`sf_pm_events.sv`) | KILLED | 15 FAIL, 7 MISMATCH; first: [FAIL] T2 shadow equals reference model |
| M08 | HALT never ends the program (`sf_pm_events.sv`) | KILLED | 3 FAIL, 7 MISMATCH; first: [FAIL] classify: after HALT, valid instr -> IDLE |
| M09 | lane count not qualified by vec_issue (`sf_pm_events.sv`) | KILLED | 12 FAIL, 7 MISMATCH; first: [FAIL] T2 shadow equals reference model |
| M10 | stall streak never resets (`sf_pm_events.sv`) | KILLED | 12 FAIL, 7 MISMATCH; first: [FAIL] T2 shadow equals reference model |
| M11 | SNAP_CLR loses the event of the command cycle (`sf_pm_counter.sv`) | KILLED | 8 FAIL, 7 MISMATCH; first: [FAIL] T5 window 1: shadow==model and invariants hold |
| M12 | wrap instead of saturate (`sf_pm_counter.sv`) | KILLED | 5 FAIL, 7 MISMATCH; first: [FAIL] T8 saturates at 2^40-1 and sets sticky OVF + FLAGS.OVF_ANY |
| M13 | overflow flag not sticky (`sf_pm_counter.sv`) | KILLED | 1 FAIL, 7 MISMATCH; first: [FAIL] T14 lock-step: DUT == reference model on every cycle, every counter, both widths (241468 mismatches) |
| M14 | CLEAR leaves the shadow intact (`sf_pm_regs.sv`) | KILLED | 1 FAIL, 0 MISMATCH; first: [FAIL] T6 CLEAR zeroes the shadow |
| M15 | HI word reads LO (`sf_pm_regs.sv`) | KILLED | 20 FAIL, 0 MISMATCH; first: [FAIL] T2 counting starts after the ENABLE write cycle |
| M16 | watchdog off by one (`sf_pm_regs.sv`) | KILLED | 1 FAIL, 2 MISMATCH; first: [FAIL] T14 lock-step: DUT == reference model on every cycle, every counter, both widths (2 mismatches) |
| M17 | counters ignore ENABLE (`sf_pm_regs.sv`) | KILLED | 6 FAIL, 7 MISMATCH; first: [FAIL] T2 nothing counted while disabled |
| M18 | SNAP_SEQ not incremented by snapshots (`sf_pm_regs.sv`) | KILLED | 2 FAIL, 0 MISMATCH; first: [FAIL] T4 second SNAPSHOT increments SNAP_SEQ by exactly 1 |
| M19 | FLAGS drops PROG_DONE (`sf_pm_regs.sv`) | KILLED | 1 FAIL, 0 MISMATCH; first: [FAIL] T3 PROG_DONE flag set after HALT issued |
| M20 | snapshot not suppressed by CLEAR (`sf_pm_regs.sv`) | EQUIVALENT (not killable) | `snap_fire`'s only consumer is the `else if (snap_fire)` branch that follows `if (cmd_clear)` in the shadow update, so CLEAR already has priority; the `&& !cmd_clear` guard is redundant (the SVA antecedents also test `!cmd_clear`). |
| M21 | out-of-range target uses tile 0 state (`sf_pm_events.sv`) | KILLED | 9 FAIL, 7 MISMATCH; first: [FAIL] T4 CSR shadow == model snapshot (all 57 counters + overflow bitmap) |
| M22 | VSTORE not classified as tile memory op (`sf_pm_events.sv`) | KILLED | 8 FAIL, 7 MISMATCH; first: [FAIL] T2 shadow equals reference model |
| M23 | peak counter degraded to gauge (`sf_pm_counter.sv`) | KILLED | 11 FAIL, 7 MISMATCH; first: [FAIL] T2 shadow equals reference model |
| M24 | fresh tag ignores flush / post-HALT (`sf_pm_events.sv`) | KILLED | 6 FAIL, 7 MISMATCH; first: [FAIL] T4 CSR shadow == model snapshot (all 57 counters + overflow bitmap) |
| M25 | irq ignores IRQ_EN (`sf_pm_regs.sv`) | KILLED | 1 FAIL, 0 MISMATCH; first: [FAIL] T15 irq stays low while IRQ_EN is clear, although the watchdog tripped |
| M26 | empty machine counted as front-end bubble, never IDLE (`sf_pm_events.sv`) | KILLED | 7 FAIL, 7 MISMATCH; first: [FAIL] classify: empty machine -> IDLE |
