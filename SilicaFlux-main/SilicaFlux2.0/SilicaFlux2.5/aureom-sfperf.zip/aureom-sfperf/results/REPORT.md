# Measured results

Generated 2026-11-24 by `python -m sfperf report` from raw simulation outputs in `results/`. Every number below was read back from the RTL monitor's CSR interface (or from the architectural traces); none is typed in.

Tools: iverilog `Icarus Verilog version 12.0 (stable) ()`; verilator `Verilator 5.020 2024-01-01 rev (Debian 5.020-1)`; yosys (native) `Yosys 0.33 (git sha1 2584903a060)`; python `Python 3.13.18`

Configurations: **supplied** = the RTL exactly as supplied; **fixed** = supplied RTL plus the two optional patches F1 (load-use livelock) and F2 (dispatch drop). See `docs/BASELINE_FINDINGS.md`.

## 1. Headline checks

| Check | Result |
|---|---|
| Instrumented vs uninstrumented: identical architectural trace **and** cycle-exact fingerprint | **36/36** runs |
| RTL counters vs behavioural reference model, every counter every cycle | 0 mismatches in 36 runs |
| Snapshot invariants I1-I3, I5 hold in every run | 36/36 runs |
| Coherent CSR reads (SNAP_SEQ equal before/after every multi-word read) | 36/36 runs |
| Conservation I4: `SLOT_ISSUE == RET_SCALAR + RET_TILE + DROP_SYNC + DROP_OP` (drained runs; includes runs whose wrong-path instructions commit) | exact in **36/36** runs |
| Workload expectations (exact or bounded counter values declared with each workload) | **195/195** hold |

## 2. Bottleneck verdict per workload

Primary = the largest finding the classifier (`sfperf/bottleneck.py`) derives from the counters; it is never told which workload it is looking at.

| config | workload | cycles | active | IPC | primary finding (share of active cycles) | defects flagged by the monitor |
|---|---|---|---|---|---|---|
| supplied | `compute_alu` | 305 | 265 | 1.00 | **compute**: issue-bound (single-issue scalar throughput) (100%) | - |
| supplied | `compute_tensor_sync` | 603 | 561 | 0.03 | **compute**: barrier waiting on the tensor unit (execution-unit bound) (97%) | - |
| supplied | `compute_tensor_queue` | 325 | 282 | 0.04 | **compute**: execution-unit contention (tensor unit) (96%) | LOST OPS: 4 scheduler ops consumed without being dispatched |
| supplied | `compute_vector_queue` | 109 | 66 | 0.52 | **compute**: execution-unit contention (vector engine) (48%) | LOST OPS: 16 scheduler ops consumed without being dispatched |
| supplied | `mem_burst_serial` | 331 | 289 | 0.06 | **memory**: barrier waiting on memory transactions (memory-latency bound) (94%) | - |
| supplied | `mem_burst_parallel` | 199 | 154 | 0.14 | **memory**: barrier waiting on memory transactions (memory-latency bound) (86%) | - |
| supplied | `mem_conflict_queue` | 189 | 146 | 0.07 | **memory**: memory backpressure / latency (tile occupied by a transaction) (93%) | LOST OPS: 4 scheduler ops consumed without being dispatched |
| supplied | `mem_scalar_backtoback` | 67 | 26 | 1.00 | **compute**: issue-bound (single-issue scalar throughput) (100%) | LOST MEMORY REQUESTS: 8 requests presented to a busy controller |
| supplied | `dep_load_use` | 1499 | 1498 | 0.00 | **dependency**: RAW (load-use) interlock stalls (100%) | HANG: one stall run of 1492 cycles (100% of the run), dominated by SLOT_STALL_DEP<br>LOST MEMORY REQUESTS: 745 requests presented to a busy controller |
| supplied | `dep_sync_chain` | 243 | 199 | 0.17 | **memory**: barrier waiting on memory transactions (memory-latency bound) (83%) | - |
| supplied | `dep_alu_chain` | 173 | 132 | 1.00 | **compute**: issue-bound (single-issue scalar throughput) (100%) | - |
| supplied | `div_branch_p000` | 425 | 385 | 1.00 | **compute**: issue-bound (single-issue scalar throughput) (100%) | - |
| supplied | `div_branch_p025` | 437 | 397 | 0.91 | **divergence**: control-flow bubbles from taken branches (9%) | - |
| supplied | `div_branch_p050` | 449 | 408 | 0.82 | **divergence**: control-flow bubbles from taken branches (18%) | - |
| supplied | `div_branch_p075` | 461 | 420 | 0.74 | **divergence**: control-flow bubbles from taken branches (26%) | - |
| supplied | `div_branch_p100` | 473 | 432 | 0.67 | **divergence**: control-flow bubbles from taken branches (33%) | - |
| supplied | `div_loop_taken` | 685 | 645 | 0.71 | **divergence**: control-flow bubbles from taken branches (29%) | - |
| supplied | `mixed_kernel` | 1801 | 1691 | 0.38 | **compute**: barrier waiting on the tensor unit (execution-unit bound) (56%) | - |
| fixed | `compute_alu` | 305 | 265 | 1.00 | **compute**: issue-bound (single-issue scalar throughput) (100%) | - |
| fixed | `compute_tensor_sync` | 619 | 576 | 0.03 | **compute**: barrier waiting on the tensor unit (execution-unit bound) (97%) | - |
| fixed | `compute_tensor_queue` | 605 | 562 | 0.02 | **compute**: execution-unit contention (tensor unit) (85%) | - |
| fixed | `compute_vector_queue` | 173 | 130 | 0.26 | **compute**: execution-unit contention (vector engine) (48%) | - |
| fixed | `mem_burst_serial` | 347 | 304 | 0.06 | **memory**: barrier waiting on memory transactions (memory-latency bound) (94%) | - |
| fixed | `mem_burst_parallel` | 199 | 155 | 0.14 | **memory**: barrier waiting on memory transactions (memory-latency bound) (86%) | - |
| fixed | `mem_conflict_queue` | 333 | 290 | 0.03 | **memory**: memory backpressure / latency (tile occupied by a transaction) (82%) | - |
| fixed | `mem_scalar_backtoback` | 67 | 26 | 1.00 | **compute**: issue-bound (single-issue scalar throughput) (100%) | LOST MEMORY REQUESTS: 8 requests presented to a busy controller |
| fixed | `dep_load_use` | 239 | 198 | 0.84 | **dependency**: RAW (load-use) interlock stalls (16%) | - |
| fixed | `dep_sync_chain` | 243 | 199 | 0.17 | **memory**: barrier waiting on memory transactions (memory-latency bound) (83%) | - |
| fixed | `dep_alu_chain` | 173 | 132 | 1.00 | **compute**: issue-bound (single-issue scalar throughput) (100%) | - |
| fixed | `div_branch_p000` | 425 | 385 | 1.00 | **compute**: issue-bound (single-issue scalar throughput) (100%) | - |
| fixed | `div_branch_p025` | 437 | 397 | 0.91 | **divergence**: control-flow bubbles from taken branches (9%) | - |
| fixed | `div_branch_p050` | 449 | 408 | 0.82 | **divergence**: control-flow bubbles from taken branches (18%) | - |
| fixed | `div_branch_p075` | 461 | 420 | 0.74 | **divergence**: control-flow bubbles from taken branches (26%) | - |
| fixed | `div_branch_p100` | 473 | 432 | 0.67 | **divergence**: control-flow bubbles from taken branches (33%) | - |
| fixed | `div_loop_taken` | 685 | 645 | 0.71 | **divergence**: control-flow bubbles from taken branches (29%) | - |
| fixed | `mixed_kernel` | 1801 | 1711 | 0.38 | **compute**: barrier waiting on the tensor unit (execution-unit bound) (57%) | - |

## 3. Issue-slot breakdown (share of active cycles; IDLE excluded)

| config | workload | Issue | Dependency (RAW) | Barrier wait | Execution unit | Memory | Control flow | Other |
|---|---|---|---|---|---|---|---|---|
| supplied | `compute_alu` | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| supplied | `compute_tensor_sync` | 3.0% | 0.0% | 97.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| supplied | `compute_tensor_queue` | 3.5% | 0.0% | 0.0% | 96.5% | 0.0% | 0.0% | 0.0% |
| supplied | `compute_vector_queue` | 51.5% | 0.0% | 0.0% | 48.5% | 0.0% | 0.0% | 0.0% |
| supplied | `mem_burst_serial` | 5.9% | 0.0% | 94.1% | 0.0% | 0.0% | 0.0% | 0.0% |
| supplied | `mem_burst_parallel` | 13.6% | 0.0% | 86.4% | 0.0% | 0.0% | 0.0% | 0.0% |
| supplied | `mem_conflict_queue` | 6.8% | 0.0% | 0.0% | 0.0% | 93.2% | 0.0% | 0.0% |
| supplied | `mem_scalar_backtoback` | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| supplied | `dep_load_use` | 0.4% | 99.6% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| supplied | `dep_sync_chain` | 16.6% | 0.0% | 83.4% | 0.0% | 0.0% | 0.0% | 0.0% |
| supplied | `dep_alu_chain` | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| supplied | `div_branch_p000` | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| supplied | `div_branch_p025` | 90.9% | 0.0% | 0.0% | 0.0% | 0.0% | 9.1% | 0.0% |
| supplied | `div_branch_p050` | 82.4% | 0.0% | 0.0% | 0.0% | 0.0% | 17.6% | 0.0% |
| supplied | `div_branch_p075` | 74.3% | 0.0% | 0.0% | 0.0% | 0.0% | 25.7% | 0.0% |
| supplied | `div_branch_p100` | 66.7% | 0.0% | 0.0% | 0.0% | 0.0% | 33.3% | 0.0% |
| supplied | `div_loop_taken` | 70.7% | 0.0% | 0.0% | 0.0% | 0.0% | 29.3% | 0.0% |
| supplied | `mixed_kernel` | 38.5% | 0.0% | 56.2% | 0.0% | 0.0% | 5.3% | 0.0% |
| fixed | `compute_alu` | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| fixed | `compute_tensor_sync` | 3.0% | 0.0% | 97.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| fixed | `compute_tensor_queue` | 1.8% | 0.0% | 12.3% | 84.7% | 0.0% | 0.0% | 1.2% |
| fixed | `compute_vector_queue` | 26.2% | 0.0% | 2.3% | 47.7% | 0.0% | 0.0% | 23.8% |
| fixed | `mem_burst_serial` | 5.6% | 0.0% | 94.4% | 0.0% | 0.0% | 0.0% | 0.0% |
| fixed | `mem_burst_parallel` | 13.5% | 0.0% | 86.5% | 0.0% | 0.0% | 0.0% | 0.0% |
| fixed | `mem_conflict_queue` | 3.4% | 0.0% | 12.1% | 0.0% | 82.1% | 0.0% | 2.4% |
| fixed | `mem_scalar_backtoback` | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| fixed | `dep_load_use` | 83.8% | 16.2% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| fixed | `dep_sync_chain` | 16.6% | 0.0% | 83.4% | 0.0% | 0.0% | 0.0% | 0.0% |
| fixed | `dep_alu_chain` | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| fixed | `div_branch_p000` | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% |
| fixed | `div_branch_p025` | 90.9% | 0.0% | 0.0% | 0.0% | 0.0% | 9.1% | 0.0% |
| fixed | `div_branch_p050` | 82.4% | 0.0% | 0.0% | 0.0% | 0.0% | 17.6% | 0.0% |
| fixed | `div_branch_p075` | 74.3% | 0.0% | 0.0% | 0.0% | 0.0% | 25.7% | 0.0% |
| fixed | `div_branch_p100` | 66.7% | 0.0% | 0.0% | 0.0% | 0.0% | 33.3% | 0.0% |
| fixed | `div_loop_taken` | 70.7% | 0.0% | 0.0% | 0.0% | 0.0% | 29.3% | 0.0% |
| fixed | `mixed_kernel` | 38.0% | 0.0% | 56.7% | 0.0% | 0.0% | 5.3% | 0.0% |

## 4. Memory, queues and execution units

| config | workload | avg mem outstanding | peak | latency (cyc, Little) | blocked reqs | avg tokens in flight | peak | tensor busy | vector busy | lane util |
|---|---|---|---|---|---|---|---|---|---|---|
| supplied | `compute_alu` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| supplied | `compute_tensor_sync` | 0.00 | 0 | - | 0 | 0.98 | 1 | 0.94 | 0.00 | 0.000 |
| supplied | `compute_tensor_queue` | 0.00 | 0 | - | 0 | 0.98 | 1 | 0.94 | 0.00 | 0.000 |
| supplied | `compute_vector_queue` | 0.00 | 0 | - | 0 | 0.74 | 1 | 0.00 | 0.48 | 0.061 |
| supplied | `mem_burst_serial` | 0.91 | 1 | 33.0 | 0 | 0.97 | 1 | 0.00 | 0.00 | 0.000 |
| supplied | `mem_burst_parallel` | 3.43 | 4 | 33.0 | 0 | 3.64 | 4 | 0.00 | 0.00 | 0.000 |
| supplied | `mem_conflict_queue` | 0.90 | 1 | 33.0 | 0 | 0.97 | 1 | 0.00 | 0.00 | 0.000 |
| supplied | `mem_scalar_backtoback` | 0.62 | 1 | 2.0 | 8 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| supplied | `dep_load_use` | 0.99 | 1 | 2.0 | 745 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| supplied | `dep_sync_chain` | 0.72 | 1 | 18.0 | 0 | 1.01 | 2 | 0.00 | 0.08 | 0.010 |
| supplied | `dep_alu_chain` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| supplied | `div_branch_p000` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| supplied | `div_branch_p025` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| supplied | `div_branch_p050` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| supplied | `div_branch_p075` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| supplied | `div_branch_p100` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| supplied | `div_loop_taken` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| supplied | `mixed_kernel` | 0.31 | 2 | 26.0 | 0 | 0.75 | 3 | 0.39 | 0.00 | 0.000 |
| fixed | `compute_alu` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| fixed | `compute_tensor_sync` | 0.00 | 0 | - | 0 | 0.97 | 1 | 0.92 | 0.00 | 0.000 |
| fixed | `compute_tensor_queue` | 0.00 | 0 | - | 0 | 0.98 | 1 | 0.94 | 0.00 | 0.000 |
| fixed | `compute_vector_queue` | 0.00 | 0 | - | 0 | 0.75 | 1 | 0.00 | 0.49 | 0.062 |
| fixed | `mem_burst_serial` | 0.87 | 1 | 33.0 | 0 | 0.95 | 1 | 0.00 | 0.00 | 0.000 |
| fixed | `mem_burst_parallel` | 3.41 | 4 | 33.0 | 0 | 3.64 | 4 | 0.00 | 0.00 | 0.000 |
| fixed | `mem_conflict_queue` | 0.91 | 1 | 33.0 | 0 | 0.97 | 1 | 0.00 | 0.00 | 0.000 |
| fixed | `mem_scalar_backtoback` | 0.62 | 1 | 2.0 | 8 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| fixed | `dep_load_use` | 0.32 | 1 | 2.0 | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| fixed | `dep_sync_chain` | 0.72 | 1 | 18.0 | 0 | 1.01 | 2 | 0.00 | 0.08 | 0.010 |
| fixed | `dep_alu_chain` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| fixed | `div_branch_p000` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| fixed | `div_branch_p025` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| fixed | `div_branch_p050` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| fixed | `div_branch_p075` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| fixed | `div_branch_p100` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| fixed | `div_loop_taken` | 0.00 | 0 | - | 0 | 0.00 | 0 | 0.00 | 0.00 | 0.000 |
| fixed | `mixed_kernel` | 0.30 | 2 | 26.0 | 0 | 0.74 | 3 | 0.39 | 0.00 | 0.000 |

## 5. Declared expectations (exact counter values the workload was designed to produce)

| config | workload | checked | failed |
|---|---|---|---|
| supplied | `compute_alu` | 12 | none |
| supplied | `compute_tensor_sync` | 9 | none |
| supplied | `compute_tensor_queue` | 4 | none |
| supplied | `compute_vector_queue` | 3 | none |
| supplied | `mem_burst_serial` | 7 | none |
| supplied | `mem_burst_parallel` | 6 | none |
| supplied | `mem_conflict_queue` | 3 | none |
| supplied | `mem_scalar_backtoback` | 3 | none |
| supplied | `dep_load_use` | 2 | none |
| supplied | `dep_sync_chain` | 5 | none |
| supplied | `dep_alu_chain` | 4 | none |
| supplied | `div_branch_p000` | 6 | none |
| supplied | `div_branch_p025` | 6 | none |
| supplied | `div_branch_p050` | 6 | none |
| supplied | `div_branch_p075` | 6 | none |
| supplied | `div_branch_p100` | 6 | none |
| supplied | `div_loop_taken` | 3 | none |
| supplied | `mixed_kernel` | 2 | none |
| fixed | `compute_alu` | 12 | none |
| fixed | `compute_tensor_sync` | 9 | none |
| fixed | `compute_tensor_queue` | 5 | none |
| fixed | `compute_vector_queue` | 7 | none |
| fixed | `mem_burst_serial` | 7 | none |
| fixed | `mem_burst_parallel` | 6 | none |
| fixed | `mem_conflict_queue` | 6 | none |
| fixed | `mem_scalar_backtoback` | 3 | none |
| fixed | `dep_load_use` | 3 | none |
| fixed | `dep_sync_chain` | 5 | none |
| fixed | `dep_alu_chain` | 4 | none |
| fixed | `div_branch_p000` | 6 | none |
| fixed | `div_branch_p025` | 6 | none |
| fixed | `div_branch_p050` | 6 | none |
| fixed | `div_branch_p075` | 6 | none |
| fixed | `div_branch_p100` | 6 | none |
| fixed | `div_loop_taken` | 3 | none |
| fixed | `mixed_kernel` | 2 | none |

## 6. Instrumentation transparency (per run)

| config | workload | cycles (uninstr.) | cycles (instr.) | fingerprint equal | arch trace byte-identical | sim wall s (uninstr. / instr.) |
|---|---|---|---|---|---|---|
| supplied | `compute_alu` | 306 | 306 | True | True | 0.298 / 1.306 |
| supplied | `compute_tensor_sync` | 603 | 603 | True | True | 0.331 / 2.157 |
| supplied | `compute_tensor_queue` | 325 | 325 | True | True | 0.278 / 1.371 |
| supplied | `compute_vector_queue` | 109 | 109 | True | True | 0.265 / 1.086 |
| supplied | `mem_burst_serial` | 331 | 331 | True | True | 0.265 / 1.539 |
| supplied | `mem_burst_parallel` | 199 | 199 | True | True | 0.272 / 1.297 |
| supplied | `mem_conflict_queue` | 189 | 189 | True | True | 0.320 / 1.171 |
| supplied | `mem_scalar_backtoback` | 67 | 67 | True | True | 0.244 / 0.789 |
| supplied | `dep_load_use` | 1500 | 1500 | True | True | 0.400 / 6.405 |
| supplied | `dep_sync_chain` | 243 | 243 | True | True | 0.261 / 1.463 |
| supplied | `dep_alu_chain` | 173 | 173 | True | True | 0.283 / 0.898 |
| supplied | `div_branch_p000` | 426 | 426 | True | True | 0.292 / 1.611 |
| supplied | `div_branch_p025` | 438 | 438 | True | True | 0.423 / 1.675 |
| supplied | `div_branch_p050` | 449 | 449 | True | True | 0.289 / 1.631 |
| supplied | `div_branch_p075` | 461 | 461 | True | True | 0.299 / 2.004 |
| supplied | `div_branch_p100` | 473 | 473 | True | True | 0.321 / 2.031 |
| supplied | `div_loop_taken` | 686 | 686 | True | True | 0.321 / 2.740 |
| supplied | `mixed_kernel` | 1732 | 1732 | True | True | 0.382 / 5.287 |
| fixed | `compute_alu` | 306 | 306 | True | True | 0.291 / 1.244 |
| fixed | `compute_tensor_sync` | 619 | 619 | True | True | 0.276 / 2.176 |
| fixed | `compute_tensor_queue` | 605 | 605 | True | True | 0.279 / 1.940 |
| fixed | `compute_vector_queue` | 173 | 173 | True | True | 0.255 / 1.404 |
| fixed | `mem_burst_serial` | 347 | 347 | True | True | 0.301 / 1.555 |
| fixed | `mem_burst_parallel` | 199 | 199 | True | True | 0.257 / 1.409 |
| fixed | `mem_conflict_queue` | 333 | 333 | True | True | 0.280 / 1.480 |
| fixed | `mem_scalar_backtoback` | 67 | 67 | True | True | 0.292 / 0.789 |
| fixed | `dep_load_use` | 239 | 239 | True | True | 0.285 / 1.909 |
| fixed | `dep_sync_chain` | 243 | 243 | True | True | 0.310 / 1.491 |
| fixed | `dep_alu_chain` | 173 | 173 | True | True | 0.272 / 0.972 |
| fixed | `div_branch_p000` | 426 | 426 | True | True | 0.330 / 1.572 |
| fixed | `div_branch_p025` | 438 | 438 | True | True | 0.305 / 1.552 |
| fixed | `div_branch_p050` | 449 | 449 | True | True | 0.286 / 1.825 |
| fixed | `div_branch_p075` | 461 | 461 | True | True | 0.288 / 2.034 |
| fixed | `div_branch_p100` | 473 | 473 | True | True | 0.304 / 2.091 |
| fixed | `div_loop_taken` | 686 | 686 | True | True | 0.331 / 2.517 |
| fixed | `mixed_kernel` | 1752 | 1752 | True | True | 0.389 / 5.106 |

## 7. Synthesis overhead (Yosys proxies; see docs/OVERHEAD.md for method and caveats)

| variant | flip-flops | generic gates | LUT6 | logic depth (gates) | logic depth (LUT6) |
|---|---|---|---|---|---|
| supplied | 4,241 | 13,580 | 4,538 | 66 | 15 |
| instrumented, PM_EN=0 | 4,241 | 13,597 | 4,539 | 64 | 15 |
| instrumented, PM_EN=1 | 8,420 | 28,258 | 11,021 | 64 | 15 |

Standalone monitor, same flow, versus counter width `CW` (snapshot shadow + live counters scale linearly):

| CW | flip-flops | generic gates | LUT6 | logic depth (gates / LUT6) |
|---|---|---|---|---|
| 16 | 1,919 | 7,320 | 3,054 | 57 / 12 |
| 24 | 2,727 | 10,105 | 4,295 | 56 / 12 |
| 32 | 3,535 | 12,867 | 5,592 | 57 / 12 |
| 40 | 4,343 | 15,659 | 6,796 | 63 / 14 |
| 48 | 5,151 | 18,409 | 8,036 | 71 / 16 |

## 8. Simulation wall-clock overhead (Icarus Verilog, median of repeated runs)

| workload | build | median s | min..max s | vs uninstrumented |
|---|---|---|---|---|
| `compute_alu` | uninstrumented | 0.400 | 0.356..0.528 | x1.00 |
| `compute_alu` | taps_only(PM_EN=0) | 0.392 | 0.377..0.511 | x0.98 |
| `compute_alu` | pm_rtl_only | 1.204 | 1.012..1.344 | x3.01 |
| `compute_alu` | pm_rtl+ref_model | 2.206 | 2.063..2.482 | x5.52 |
| `mixed_kernel` | uninstrumented | 0.358 | 0.350..0.508 | x1.00 |
| `mixed_kernel` | taps_only(PM_EN=0) | 0.398 | 0.343..0.605 | x1.11 |
| `mixed_kernel` | pm_rtl_only | 2.108 | 1.824..2.342 | x5.89 |
| `mixed_kernel` | pm_rtl+ref_model | 3.311 | 3.289..3.486 | x9.24 |
| `mem_burst_parallel` | uninstrumented | 0.314 | 0.285..0.390 | x1.00 |
| `mem_burst_parallel` | taps_only(PM_EN=0) | 0.304 | 0.285..0.339 | x0.97 |
| `mem_burst_parallel` | pm_rtl_only | 1.393 | 1.309..1.430 | x4.44 |
| `mem_burst_parallel` | pm_rtl+ref_model | 2.311 | 2.291..3.031 | x7.36 |
