// =============================================================================
// tb_sys -- system testbench for silicaflux_top (supplied or instrumented)
//
//   Build flags:  -DPM_BUILD   DUT has the perfmon CSR ports (patched top)
//                 -DPM_EN_VAL=0|1   value of the PM_EN parameter (default 1)
//   Plusargs:     +HEX=<file>   program, one 32-bit word per line (rest of IMEM = NOP)
//                 +OUT=<dir>    output directory (must exist)
//                 +MAXC=<n>     maximum cycles after reset release (default 20000)
//                 +SNAPINT=<n>  SNAP_CLR window length in cycles (0 = only the final snapshot)
//                 +TRACE=1      dump per-cycle tap trace (PM build)
//                 +WDOG=<n>     watchdog threshold (PM build, 0=off)
//
//   Outputs (all under +OUT):
//     arch.csv       architectural events (regfile writes, tile completions, top outputs) + final state
//     summary.txt    cycle count, halt cycle, cycle-exact fingerprint (FNV-1a over core signals)
//     snapshots.csv  (PM) one row per snapshot: seq,cycle_cmd,value of every counter read via CSR
//     trace.csv      (PM, +TRACE=1) one row per cycle with every tap value
//     cmds.csv       (PM) cycle index of each CSR command edge
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"

`ifndef PM_EN_VAL
 `define PM_EN_VAL 1
`endif

module tb_sys;
  import silicaflux_pkg::*;
`ifdef PM_BUILD
  import sf_pm_pkg::*;
`endif

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic                imem_wr_en = 0;
  logic [PC_WIDTH-1:0] imem_wr_addr = 0;
  logic [XLEN-1:0]     imem_wr_data = 0;
  logic [7:0]          tx_data; logic tx_valid; logic tx_credit = 1; logic [7:0] rx_data = 0; logic rx_valid = 0; logic rx_credit;
  logic                halt; logic [XLEN-1:0] dbg_r1;

`ifdef PM_BUILD
  logic pm_en = 0, pm_we = 0; logic [7:0] pm_addr = 0; logic [31:0] pm_wdata = 0; wire [31:0] pm_rdata; wire pm_rvalid; logic pm_trig = 0; wire pm_irq;
  silicaflux_top #(.LANES(4), .PM_EN(`PM_EN_VAL)) dut (
    .clk, .rst_n, .imem_wr_en, .imem_wr_addr, .imem_wr_data,
    .tile_phy_tx_data(tx_data), .tile_phy_tx_valid(tx_valid), .tile_phy_tx_credit(tx_credit),
    .tile_phy_rx_data(rx_data), .tile_phy_rx_valid(rx_valid), .tile_phy_rx_credit(rx_credit),
    .halt, .debug_scalar_r1(dbg_r1),
    .pm_csr_en(pm_en), .pm_csr_we(pm_we), .pm_csr_addr(pm_addr), .pm_csr_wdata(pm_wdata),
    .pm_csr_rdata(pm_rdata), .pm_csr_rvalid(pm_rvalid), .pm_snap_trig(pm_trig), .pm_irq(pm_irq));
`else
  silicaflux_top #(.LANES(4)) dut (
    .clk, .rst_n, .imem_wr_en, .imem_wr_addr, .imem_wr_data,
    .tile_phy_tx_data(tx_data), .tile_phy_tx_valid(tx_valid), .tile_phy_tx_credit(tx_credit),
    .tile_phy_rx_data(rx_data), .tile_phy_rx_valid(rx_valid), .tile_phy_rx_credit(rx_credit),
    .halt, .debug_scalar_r1(dbg_r1));
`endif

  // ---------------------------------------------------------------------------
  string  hexf, outd, f_arch, f_sum;
  integer maxc, snapint, trace_on, wdog_thr;
  integer fh_arch, fh_sum;
  logic [31:0] prog [0:IMEM_DEPTH-1];
  longint unsigned cyc = 0;              // posedges since reset release
  longint unsigned fp = 64'hcbf29ce484222325;   // FNV-1a state
  longint unsigned halt_cyc = 0; bit halt_seen = 0;
  longint unsigned fp_end = 0, cyc_end = 0;   // frozen when the core's run ends (before any PM read-out)
  bit end_flag = 0; integer idle_run = 0; integer fi; integer i;
  // The end of the run is decided ONLY from core signals (halt, scheduler idle, cycle limit) by this
  // independent block, so a long CSR read-out in the instrumented build cannot move it.
  always @(negedge clk) if (rst_n && !end_flag) begin
    if (halt) begin
      if (dut.u_sched.tile_busy == 0 && !dut.sched_valid) idle_run = idle_run + 1; else idle_run = 0;
    end
    if (idle_run >= 40 || cyc >= maxc) begin
      end_flag = 1; fp_end = fp; cyc_end = cyc;
      // architectural state is captured HERE, at the monitor-independent end of the run (not after the CSR read-out)
          for (fi = 1; fi < NUM_SREGS; fi++) $fdisplay(fh_arch, "R,%0d,%0d", fi, dut.u_regs.sregs[fi]);
          for (fi = 0; fi < NUM_VREGS; fi++) $fdisplay(fh_arch, "V,%0d,%h", fi, dut.u_regs.vregs[fi]);
          for (fi = 0; fi < SRAM_DEPTH; fi++) begin
            $fdisplay(fh_arch, "S0,%0d,%0d", fi, dut.g_tiles[0].u_tile.u_mem.sram[fi]);
            $fdisplay(fh_arch, "S1,%0d,%0d", fi, dut.g_tiles[1].u_tile.u_mem.sram[fi]);
            $fdisplay(fh_arch, "S2,%0d,%0d", fi, dut.g_tiles[2].u_tile.u_mem.sram[fi]);
            $fdisplay(fh_arch, "S3,%0d,%0d", fi, dut.g_tiles[3].u_tile.u_mem.sram[fi]);
          end
          for (fi = 0; fi < SRAM_DEPTH; fi++) $fdisplay(fh_arch, "SC,%0d,%0d", fi, dut.u_ctrl_mem.sram[fi]);
          end
  end

  task automatic fp_mix(input longint unsigned v);
    fp = (fp ^ v) * 64'h100000001b3;
  endtask

  // ------------------------------------------------------------ architectural trace + fingerprint
  // Sampled at the posedge (pre-edge values), identical code for every build.
  always @(posedge clk) if (rst_n) cyc <= cyc + 1;          // the cycle index keeps running (trace and cmds files use it)

  always @(posedge clk) if (rst_n && !end_flag) begin       // logging + fingerprint freeze at the independent end of run
    // fingerprint: control and datapath signals that exist in both builds
    fp_mix({dut.if_id.pc, dut.id_is.valid, dut.id_is.instr.opcode, dut.id_stall, dut.pipeline_flush_int});
    fp_mix({dut.u_ctrl.is_ex.valid, dut.u_ctrl.is_ex.instr.opcode, dut.sched_valid, dut.sched_ready, dut.sync_stall});
    fp_mix({dut.u_sched.tile_busy, dut.tile_done_flat, dut.tile_error_flat});
    fp_mix({dut.g_tiles[0].u_tile.tstate, dut.g_tiles[1].u_tile.tstate, dut.g_tiles[2].u_tile.tstate, dut.g_tiles[3].u_tile.tstate});
    fp_mix({dut.wb_s_wr_en, dut.wb_s_wr_addr, dut.wb_s_wr_data});
    fp_mix({dut.mem_req_valid, dut.mem_req_ready, dut.mem_resp_valid, dut.mem_resp_rdata});
    fp_mix({halt, dbg_r1, tx_valid, tx_data});
    if (dut.wb_s_wr_en) $fdisplay(fh_arch, "W,%0d,%0d,%0d", cyc, dut.wb_s_wr_addr, dut.wb_s_wr_data);
    for (int t = 0; t < NUM_TILES; t++)
      if (dut.tile_done_flat[t])
        $fdisplay(fh_arch, "T,%0d,%0d,%0d,%h", cyc, t, dut.tile_scalar_flat[t*XLEN +: XLEN], dut.tile_vector_flat[t*VLEN +: VLEN]);
    if (dut.u_ctrl.mem_req_valid) $fdisplay(fh_arch, "M,%0d,%0d,%0d,%0d", cyc, dut.mem_req_opcode, dut.mem_req_addr, dut.mem_req_wdata);
    if (halt && !halt_seen) begin halt_seen <= 1; halt_cyc <= cyc; $fdisplay(fh_arch, "H,%0d", cyc); end
    if (tx_valid) $fdisplay(fh_arch, "X,%0d,%0d", cyc, tx_data);
  end

  // ------------------------------------------------------------ PM: CSR master, snapshots, tap trace, ref model
`ifdef PM_BUILD
  integer fh_snap, fh_cmd, fh_trace;
  logic [63:0] snap_val [0:PM_NC-1];
  logic [31:0] snap_flags, snap_seq, snap_ovf0, snap_ovf1, snap_status;

  // blocking CSR helpers (used only in the setup / teardown phases and the sampler FSM below)
  task automatic csr_wr(input [7:0] a, input [31:0] d);
    @(negedge clk); pm_en = 1; pm_we = 1; pm_addr = a; pm_wdata = d;
    @(negedge clk); pm_en = 0; pm_we = 0;
  endtask
  task automatic csr_rd(input [7:0] a, output [31:0] d);
    @(negedge clk); pm_en = 1; pm_we = 0; pm_addr = a;
    @(negedge clk); pm_en = 0; d = pm_rdata;
  endtask

  // CSR write whose edge index is logged: cycle index of the edge at which the command executes
  longint unsigned last_cmd_cyc = 0;
  task automatic csr_cmd(input [7:0] a, input [31:0] d, input string name);
    @(negedge clk); pm_en = 1; pm_we = 1; pm_addr = a; pm_wdata = d;
    last_cmd_cyc = cyc;                                 // cyc == index of the posedge that will execute it
    $fdisplay(fh_cmd, "%0d,%s,%h", cyc, name, d);
    @(negedge clk); pm_en = 0; pm_we = 0;
  endtask

  // Pipelined shadow read: 1 word per cycle; core keeps running meanwhile (this runs in its own process).
  logic [31:0] rd_words [0:2*PM_NC + 8];
  task automatic read_shadow_pipelined(output integer nwords);
    integer n, k;
    logic [7:0] alist [0:2*PM_NC + 8];
    n = 0;
    alist[n++] = ADDR_SNAP_SEQ; alist[n++] = ADDR_FLAGS; alist[n++] = ADDR_OVF_BASE; alist[n++] = ADDR_OVF_BASE + 1;
    for (k = 0; k < PM_NC; k++) begin alist[n++] = ADDR_CNT_BASE + 2*k; alist[n++] = ADDR_CNT_BASE + 2*k + 1; end
    alist[n++] = ADDR_SNAP_SEQ;
    for (k = 0; k <= n; k++) begin
      @(negedge clk);
      if (k > 0) rd_words[k-1] = pm_rdata;               // data of address k-1
      if (k < n) begin pm_en = 1; pm_we = 0; pm_addr = alist[k]; end else pm_en = 0;
    end
    nwords = n;
  endtask

  task automatic do_snapshot(input bit clear_window, input string tag);
    integer n; logic [31:0] seq_after; longint unsigned cmd_cyc;
    csr_cmd(ADDR_CTRL, clear_window ? 32'h201 : 32'h101, tag);
    cmd_cyc = last_cmd_cyc;                      // index of the posedge that executed the command (== cmds.csv)
    read_shadow_pipelined(n);
    snap_seq = rd_words[0]; snap_flags = rd_words[1]; snap_ovf0 = rd_words[2]; snap_ovf1 = rd_words[3];
    seq_after = rd_words[n-1];
    for (int i = 0; i < PM_NC; i++) snap_val[i] = {rd_words[4 + 2*i + 1], rd_words[4 + 2*i]};
    $fwrite(fh_snap, "%0d,%0d,%0d,%0d,%h,%h,%h", snap_seq, seq_after, cmd_cyc, clear_window ? 1 : 0, snap_flags, snap_ovf0, snap_ovf1);
    for (int i = 0; i < PM_NC; i++) $fwrite(fh_snap, ",%0d", snap_val[i]);
    $fwrite(fh_snap, "\n");
  endtask

`ifdef PM_MODEL   // hierarchical references into the monitor exist only when it is instantiated
  // ---- independent reference model on the REAL taps
  wire m_is_valid = dut.g_pm.u_pm.is_valid_i, m_id_stall = dut.g_pm.u_pm.id_stall_i, m_load_use = dut.g_pm.u_pm.load_use_i;
  wire m_sync = dut.g_pm.u_pm.sync_stall_i, m_flush = dut.g_pm.u_pm.flush_i, m_br = dut.g_pm.u_pm.br_taken_i;
  wire m_ex_valid = dut.g_pm.u_pm.ex_valid_i, m_wb = dut.g_pm.u_pm.wb_valid_i, m_sv = dut.g_pm.u_pm.sched_valid_i, m_sr = dut.g_pm.u_pm.sched_ready_i;
  wire [4:0] m_is_op = dut.g_pm.u_pm.is_opcode_i, m_ex_op = dut.g_pm.u_pm.ex_opcode_i;
  wire [NUM_TILES-1:0] m_tok = dut.g_pm.u_pm.tok_valid_i, m_busy = dut.g_pm.u_pm.tile_busy_i, m_done = dut.g_pm.u_pm.tile_done_i;
  wire [2:0] m_tgt = dut.g_pm.u_pm.tgt_tile_i;
  wire [NUM_TILES*3-1:0] m_tstate = dut.g_pm.u_pm.tile_state_i;
  wire [NUM_TILES-1:0] m_vi = dut.g_pm.u_pm.vec_issue_i, m_tb = dut.g_pm.u_pm.tensor_busy_i, m_nif = dut.g_pm.u_pm.noc_inj_fire_i, m_nib = dut.g_pm.u_pm.noc_inj_blocked_i;
  wire [NUM_TILES*4-1:0] m_la = dut.g_pm.u_pm.lane_active_i;
  wire [NUM_TILES:0] m_mf = dut.g_pm.u_pm.mem_fire_i, m_mb = dut.g_pm.u_pm.mem_blocked_i, m_mr = dut.g_pm.u_pm.mem_resp_i, m_ma = dut.g_pm.u_pm.mem_align_i;
  wire [7:0] m_noc = dut.g_pm.u_pm.noc_occ_i;
  wire [PM_NC*64-1:0] mm_live, mm_snap; wire [PM_NC-1:0] mm_lovf, mm_sovf; wire [31:0] mm_sfl, mm_seq; wire mm_sv, mm_wd, mm_pd; wire [PM_SLOT_N-1:0] mm_slot;
  pm_ref_model #(.NT(NUM_TILES), .LANES(4), .CW(40)) u_model (
    .clk, .rst_n, .csr_en_i(pm_en), .csr_we_i(pm_we), .csr_addr_i(pm_addr), .csr_wdata_i(pm_wdata), .snap_trig_i(pm_trig),
    .is_valid_i(m_is_valid), .is_opcode_i(m_is_op), .id_stall_i(m_id_stall), .load_use_i(m_load_use), .sync_stall_i(m_sync),
    .flush_i(m_flush), .br_taken_i(m_br), .ex_valid_i(m_ex_valid), .ex_opcode_i(m_ex_op), .wb_valid_i(m_wb),
    .sched_valid_i(m_sv), .sched_ready_i(m_sr), .tok_valid_i(m_tok), .tgt_tile_i(m_tgt), .tile_busy_i(m_busy),
    .tile_done_i(m_done), .tile_state_i(m_tstate), .vec_issue_i(m_vi), .lane_active_i(m_la), .tensor_busy_i(m_tb),
    .mem_fire_i(m_mf), .mem_blocked_i(m_mb), .mem_resp_i(m_mr), .mem_align_i(m_ma), .noc_occ_i(m_noc),
    .noc_inj_fire_i(m_nif), .noc_inj_blocked_i(m_nib),
    .live_o(mm_live), .live_ovf_o(mm_lovf), .snap_o(mm_snap), .snap_ovf_o(mm_sovf), .snap_flags_o(mm_sfl),
    .snap_seq_o(mm_seq), .snap_valid_o(mm_sv), .wdog_trip_o(mm_wd), .prog_done_o(mm_pd), .slot_o(mm_slot));

  longint unsigned model_mismatch = 0;
  always @(negedge clk) if (rst_n && `PM_EN_VAL) begin
    for (int i = 0; i < PM_NC; i++)
      if (dut.g_pm.u_pm.u_regs.live_q[i*40 +: 40] !== mm_live[i*64 +: 40]) begin
        model_mismatch++;
        if (model_mismatch < 6) $display("[MODEL-MISMATCH] cycle %0d counter %0d dut=%0d model=%0d", cyc, i,
            dut.g_pm.u_pm.u_regs.live_q[i*40 +: 40], mm_live[i*64 +: 40]);
      end
  end

  // ---- per-cycle tap trace
  always @(posedge clk) if (rst_n && trace_on) begin
    $fdisplay(fh_trace, "%0d,%b,%b,%h,%b,%b,%b,%b,%b,%b,%h,%b,%b,%b,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h",
      cyc, dut.g_pm.u_pm.u_regs.en_q,
      m_is_valid, m_is_op, m_id_stall, m_load_use, m_sync, m_flush, m_br, m_ex_valid, m_ex_op, m_wb, m_sv, m_sr,
      m_tok, m_tgt, m_busy, m_done, m_tstate, m_vi, m_la, m_tb, m_mf, m_mb, m_mr, m_ma, m_noc, m_nif, m_nib);
  end
`endif  // PM_MODEL
`endif

  // ---------------------------------------------------------------------------
  // Main sequence
  // ---------------------------------------------------------------------------
  longint unsigned next_snap, last_snap_start;
  integer nwords;

  initial begin
    if (!$value$plusargs("HEX=%s", hexf))   hexf = "prog.hex";
    if (!$value$plusargs("OUT=%s", outd))   outd = ".";
    if (!$value$plusargs("MAXC=%d", maxc))  maxc = 20000;
    if (!$value$plusargs("SNAPINT=%d", snapint)) snapint = 0;
    if (!$value$plusargs("TRACE=%d", trace_on))  trace_on = 0;
    if (!$value$plusargs("WDOG=%d", wdog_thr))   wdog_thr = 0;
    f_arch = {outd, "/arch.csv"}; f_sum = {outd, "/summary.txt"};
    fh_arch = $fopen(f_arch, "w"); fh_sum = $fopen(f_sum, "w");
`ifdef PM_BUILD
    fh_snap = $fopen({outd, "/snapshots.csv"}, "w"); fh_cmd = $fopen({outd, "/cmds.csv"}, "w");
    $fdisplay(fh_snap, "%s", "seq,seq_after,cmd_cycle,is_window,flags,ovf0,ovf1,CYCLES,SLOT_ISSUE,SLOT_STALL_DEP,SLOT_STALL_SYNC,SLOT_STALL_EXEC_VEC,SLOT_STALL_EXEC_TENSOR,SLOT_STALL_MEM,SLOT_STALL_DISP_OTHER,SLOT_BUBBLE_CTRL,SLOT_BUBBLE_FRONT,SLOT_IDLE,ISS_NOP,ISS_SALU,ISS_SMEM,ISS_BRANCH,ISS_DFMEM,ISS_DFCTL,ISS_VEC,ISS_TENSOR,RET_SCALAR,RET_TILE,TOK_DISPATCHED,DROP_SYNC,DROP_OP,BRANCH_TAKEN,TILE_TOK_0,TILE_TOK_1,TILE_TOK_2,TILE_TOK_3,TILE_BUSY_0,TILE_BUSY_1,TILE_BUSY_2,TILE_BUSY_3,VEC_ISSUES,VEC_LANES_ACTIVE,VEC_ISSUES_PARTIAL,VEC_BUSY_CYC,TENSOR_BUSY_CYC,MEM_REQ_ACCEPTED,MEM_RESP,MEM_REQ_BLOCKED,MEM_ALIGN_ERR,MEM_OUT_SUM,MEM_BUSY_CYC,MEM_OUT_PEAK,MEM_OUT_NOW,Q_DISP_SUM,Q_DISP_NOW,Q_TOK_SUM,Q_TOK_PEAK,Q_TOK_NOW,Q_NOC_SUM,Q_NOC_PEAK,Q_NOC_NOW,NOC_FLITS,NOC_INJ_BLOCKED,STALL_STREAK_MAX");
`ifdef PM_MODEL
    if (trace_on) begin
      fh_trace = $fopen({outd, "/trace.csv"}, "w");
      $fdisplay(fh_trace, "cycle,en,is_valid,is_opcode,id_stall,load_use,sync_stall,flush,br_taken,ex_valid,ex_opcode,wb_valid,sched_valid,sched_ready,tok_valid,tgt_tile,tile_busy,tile_done,tile_state,vec_issue,lane_active,tensor_busy,mem_fire,mem_blocked,mem_resp,mem_align,noc_occ,noc_inj_fire,noc_inj_blocked");
    end
`endif
    $fdisplay(fh_cmd, "cycle,name,value_hex");
`endif
    for (i = 0; i < IMEM_DEPTH; i++) prog[i] = 32'h0;
    $readmemh(hexf, prog);

    // ---- load program through the real write port while the core is held in reset
    rst_n = 0; repeat (3) @(negedge clk);
    imem_wr_en = 1;
    for (i = 0; i < IMEM_DEPTH; i++) begin imem_wr_addr = i[PC_WIDTH-1:0]; imem_wr_data = prog[i]; @(negedge clk); end
    imem_wr_en = 0; imem_wr_addr = 0; imem_wr_data = 0;

    // ---- deterministic backdoor data preload (identical for every build)
    for (i = 0; i < SRAM_DEPTH; i++) begin
      dut.g_tiles[0].u_tile.u_mem.sram[i] = 32'(1000 + i);
      dut.g_tiles[1].u_tile.u_mem.sram[i] = 32'(2000 + i);
      dut.g_tiles[2].u_tile.u_mem.sram[i] = 32'(3000 + i);
      dut.g_tiles[3].u_tile.u_mem.sram[i] = 32'(4000 + i);
      dut.u_ctrl_mem.sram[i]              = 32'(5000 + i);
    end
    repeat (2) @(negedge clk);
    rst_n = 1;
    cyc = 0;
    // Vector registers are preloaded here, at the negedge right after reset release and before the first active edge:
    // while rst_n is low the register file's asynchronous reset re-clears them on every clock edge.
    for (i = 0; i < NUM_VREGS; i++)
      dut.u_regs.vregs[i] = {32'(16*i+4), 32'(16*i+3), 32'(16*i+2), 32'(16*i+1)};

`ifdef PM_BUILD
    if (`PM_EN_VAL) begin
      csr_cmd(ADDR_CTRL, 32'h401, "CLEAR");      // CLEAR (+ENABLE bit set): counting starts at cycle 2, before the first instruction issues
      csr_cmd(ADDR_CTRL, 32'h1,   "ENABLE");
      if (wdog_thr != 0) csr_cmd(ADDR_WDOG_THRESH, wdog_thr, "WDOG");   // after ENABLE so it cannot delay the start of counting
    end
`endif

    // ---- run
    next_snap = snapint; last_snap_start = 0;
    while (!end_flag) begin
      @(negedge clk);
`ifdef PM_BUILD
      if (`PM_EN_VAL && snapint > 0 && cyc >= next_snap && !end_flag) begin
        last_snap_start = cyc;
        do_snapshot(1'b1, "SNAP_CLR");
        next_snap = last_snap_start + snapint;     // period = max(snapint, read-out time of ~127 cycles)
      end
`endif
    end

`ifdef PM_BUILD
    if (`PM_EN_VAL) begin
      do_snapshot(1'b0, "SNAPSHOT_FINAL");
`ifdef PM_MODEL
      $display("model mismatches = %0d", model_mismatch);
`else
      $display("model mismatches = 0");
`endif
      csr_cmd(ADDR_CTRL, 32'h0, "DISABLE");
    end
`endif
    repeat (4) @(negedge clk);

    $fdisplay(fh_sum, "cycles=%0d", cyc_end);
    $fdisplay(fh_sum, "cycles_incl_readout=%0d", cyc);
    $fdisplay(fh_sum, "halt_cycle=%0d", halt_seen ? halt_cyc : -1);
    $fdisplay(fh_sum, "halted=%0d", halt_seen);
    $fdisplay(fh_sum, "drained=%0d", (idle_run >= 40));
    $fdisplay(fh_sum, "fingerprint=%h", fp_end);
    $display("tb_sys done: cycles=%0d halted=%0d drained=%0d fingerprint=%h", cyc_end, halt_seen, (idle_run >= 40), fp_end);
    $fclose(fh_arch); $fclose(fh_sum);
`ifdef PM_BUILD
    $fclose(fh_snap); $fclose(fh_cmd);
`ifdef PM_MODEL
    if (trace_on) $fclose(fh_trace);
`endif
`endif
    $finish;
  end

endmodule
