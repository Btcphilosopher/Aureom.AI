// =============================================================================
// tb_pm_unit -- stand-alone verification of sf_perfmon
//   * Two DUTs on identical taps: CW=40 (production) and CW=8 (fast overflow).
//   * Each DUT is checked EVERY CYCLE against pm_ref_model (live counters, flags,
//     slot classification) and after every snapshot through the real CSR path.
//   * Directed tests for the normative behaviours in docs/ARCHITECTURE.md.
// Output lines "[PASS] ..." / "[FAIL] ..." are consumed by the Makefile.
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"

module tb_pm_unit;
  import silicaflux_pkg::*;
  import sf_pm_pkg::*;

  localparam int NT = 4, LANES = 4;
  localparam int CWA = 40, CWB = 8;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---- shared taps ----
  logic is_valid, id_stall, load_use, sync_stall, flush, br_taken, ex_valid, wb_valid, sched_valid, sched_ready;
  logic [4:0] is_opcode, ex_opcode;
  logic [NT-1:0] tok_valid, tile_busy, tile_done, vec_issue, tensor_busy, noc_inj_fire, noc_inj_blocked;
  logic [2:0] tgt_tile;
  logic [NT*3-1:0] tile_state;
  logic [NT*LANES-1:0] lane_active;
  logic [NT:0] mem_fire, mem_blocked, mem_resp, mem_align;
  logic [7:0] noc_occ;

  // ---- CSR buses (A and B independent) ----
  logic a_en = 0, a_we = 0; logic [CSR_AW-1:0] a_addr = 0; logic [31:0] a_wdata = 0; wire [31:0] a_rdata; wire a_rvalid;
  logic b_en = 0, b_we = 0; logic [CSR_AW-1:0] b_addr = 0; logic [31:0] b_wdata = 0; wire [31:0] b_rdata; wire b_rvalid;
  logic a_trig = 0, b_trig = 0; wire a_irq, b_irq;

  `define TAPS(dut_pfx) \
    .is_valid_i(is_valid), .is_opcode_i(is_opcode), .id_stall_i(id_stall), .load_use_i(load_use), \
    .sync_stall_i(sync_stall), .flush_i(flush), .br_taken_i(br_taken), .ex_valid_i(ex_valid), \
    .ex_opcode_i(ex_opcode), .wb_valid_i(wb_valid), .sched_valid_i(sched_valid), .sched_ready_i(sched_ready), \
    .tok_valid_i(tok_valid), .tgt_tile_i(tgt_tile), .tile_busy_i(tile_busy), .tile_done_i(tile_done), \
    .tile_state_i(tile_state), .vec_issue_i(vec_issue), .lane_active_i(lane_active), .tensor_busy_i(tensor_busy), \
    .mem_fire_i(mem_fire), .mem_blocked_i(mem_blocked), .mem_resp_i(mem_resp), .mem_align_i(mem_align), \
    .noc_occ_i(noc_occ), .noc_inj_fire_i(noc_inj_fire), .noc_inj_blocked_i(noc_inj_blocked)

  sf_perfmon #(.NT(NT), .LANES(LANES), .CW(CWA)) dutA (
    .clk, .rst_n, .csr_en_i(a_en), .csr_we_i(a_we), .csr_addr_i(a_addr), .csr_wdata_i(a_wdata),
    .csr_rdata_o(a_rdata), .csr_rvalid_o(a_rvalid), .snap_trig_i(a_trig), .irq_o(a_irq), `TAPS(A));
  sf_perfmon #(.NT(NT), .LANES(LANES), .CW(CWB), .ENABLE_AT_RESET(1'b1)) dutB (
    .clk, .rst_n, .csr_en_i(b_en), .csr_we_i(b_we), .csr_addr_i(b_addr), .csr_wdata_i(b_wdata),
    .csr_rdata_o(b_rdata), .csr_rvalid_o(b_rvalid), .snap_trig_i(b_trig), .irq_o(b_irq), `TAPS(B));

  // ---- reference models ----
  wire [PM_NC*64-1:0] mA_live, mA_snap, mB_live, mB_snap;
  wire [PM_NC-1:0]    mA_lovf, mA_sovf, mB_lovf, mB_sovf;
  wire [31:0]         mA_sflags, mA_seq, mB_sflags, mB_seq;
  wire                mA_valid, mA_wd, mA_pd, mB_valid, mB_wd, mB_pd;
  wire [PM_SLOT_N-1:0] mA_slot, mB_slot;

  pm_ref_model #(.NT(NT), .LANES(LANES), .CW(CWA)) mA (
    .clk, .rst_n, .csr_en_i(a_en), .csr_we_i(a_we), .csr_addr_i(a_addr), .csr_wdata_i(a_wdata), .snap_trig_i(a_trig),
    `TAPS(M), .live_o(mA_live), .live_ovf_o(mA_lovf), .snap_o(mA_snap), .snap_ovf_o(mA_sovf),
    .snap_flags_o(mA_sflags), .snap_seq_o(mA_seq), .snap_valid_o(mA_valid), .wdog_trip_o(mA_wd),
    .prog_done_o(mA_pd), .slot_o(mA_slot));
  pm_ref_model #(.NT(NT), .LANES(LANES), .CW(CWB), .ENABLE_AT_RESET(1'b1)) mB (
    .clk, .rst_n, .csr_en_i(b_en), .csr_we_i(b_we), .csr_addr_i(b_addr), .csr_wdata_i(b_wdata), .snap_trig_i(b_trig),
    `TAPS(M), .live_o(mB_live), .live_ovf_o(mB_lovf), .snap_o(mB_snap), .snap_ovf_o(mB_sovf),
    .snap_flags_o(mB_sflags), .snap_seq_o(mB_seq), .snap_valid_o(mB_valid), .wdog_trip_o(mB_wd),
    .prog_done_o(mB_pd), .slot_o(mB_slot));

  // ---------------------------------------------------------------------------
  // Pass/fail bookkeeping
  // ---------------------------------------------------------------------------
  int n_pass = 0, n_fail = 0, live_mismatch = 0;
  task automatic check(input bit cond, input string name);
    if (cond) begin n_pass++; $display("[PASS] %s", name); end
    else      begin n_fail++; $display("[FAIL] %s", name); end
  endtask

  // ---------------------------------------------------------------------------
  // Per-cycle lock-step comparison, DUT vs model (sampled mid-cycle, after NBA)
  // ---------------------------------------------------------------------------
  logic cmp_en = 1;
  always @(negedge clk) if (cmp_en && rst_n) begin
    for (int i = 0; i < PM_NC; i++) begin
      if (dutA.u_regs.live_q[i*CWA +: CWA] !== mA_live[i*64 +: CWA] || dutA.u_regs.live_ovf[i] !== mA_lovf[i]) begin
        live_mismatch++;
        if (live_mismatch < 8) $display("[MISMATCH] t=%0t A counter %0d dut=%0d model=%0d ovf dut=%b model=%b", $time, i,
          dutA.u_regs.live_q[i*CWA +: CWA], mA_live[i*64 +: CWA], dutA.u_regs.live_ovf[i], mA_lovf[i]);
      end
      if (dutB.u_regs.live_q[i*CWB +: CWB] !== mB_live[i*64 +: CWB] || dutB.u_regs.live_ovf[i] !== mB_lovf[i]) begin
        live_mismatch++;
        if (live_mismatch < 8) $display("[MISMATCH] t=%0t B counter %0d dut=%0d model=%0d ovf dut=%b model=%b", $time, i,
          dutB.u_regs.live_q[i*CWB +: CWB], mB_live[i*64 +: CWB], dutB.u_regs.live_ovf[i], mB_lovf[i]);
      end
    end
    if (^dutA.u_regs.snap_q === 1'bx || ^dutA.u_regs.live_q === 1'bx) begin
      live_mismatch++; if (live_mismatch < 8) $display("[MISMATCH] t=%0t X in DUT A state", $time);
    end
    if (dutA.u_regs.wdog_trip_q !== mA_wd || dutA.u_events.prog_done_q !== mA_pd) begin
      live_mismatch++; if (live_mismatch < 8) $display("[MISMATCH] t=%0t wd/pd dut=%b%b model=%b%b", $time,
        dutA.u_regs.wdog_trip_q, dutA.u_events.prog_done_q, mA_wd, mA_pd);
    end
  end

  // ---------------------------------------------------------------------------
  // Independent tally of enabled cycles (no reference to the model) for the window-tiling test
  // ---------------------------------------------------------------------------
  longint unsigned tally = 0, tally_cap = 0;   // cumulative since the last CLEAR (SNAP_CLR does not reset it)
  always @(posedge clk) begin
    bit w, clr, snp;
    w   = a_en && a_we && (a_addr == ADDR_CTRL);
    clr = w && a_wdata[CTRL_CLEAR];
    snp = (w && (a_wdata[CTRL_SNAPSHOT] || a_wdata[CTRL_SNAP_CLR])) && !clr;
    if (!rst_n) tally <= 0;
    else begin
      if (snp) tally_cap <= tally;                 // enabled cycles strictly before this edge
      if (clr) tally <= 0;
      else if (dutA.u_regs.en_q) tally <= tally + 1;
    end
  end

  // ---------------------------------------------------------------------------
  // CSR helpers
  // ---------------------------------------------------------------------------
  task automatic a_write(input [CSR_AW-1:0] ad, input [31:0] d);
    @(negedge clk); a_en = 1; a_we = 1; a_addr = ad; a_wdata = d;
    @(negedge clk); a_en = 0; a_we = 0;
  endtask
  task automatic a_write_now(input [CSR_AW-1:0] ad, input [31:0] d);   // caller is already at a negedge
    a_en = 1; a_we = 1; a_addr = ad; a_wdata = d;
    @(negedge clk); a_en = 0; a_we = 0;
  endtask
  task automatic drain_mem();                                           // clear the monitor's outstanding-request trackers
    @(negedge clk); quiet(); mem_resp = {(NT+1){1'b1}};
    @(negedge clk); quiet();
  endtask
  task automatic b_write(input [CSR_AW-1:0] ad, input [31:0] d);
    @(negedge clk); b_en = 1; b_we = 1; b_addr = ad; b_wdata = d;
    @(negedge clk); b_en = 0; b_we = 0;
  endtask
  task automatic a_read(input [CSR_AW-1:0] ad, output [31:0] d);
    @(negedge clk); a_en = 1; a_we = 0; a_addr = ad;
    @(negedge clk); a_en = 0; d = a_rdata;
  endtask
  task automatic b_read(input [CSR_AW-1:0] ad, output [31:0] d);
    @(negedge clk); b_en = 1; b_we = 0; b_addr = ad;
    @(negedge clk); b_en = 0; d = b_rdata;
  endtask

  // read the complete shadow of DUT A through the CSR path
  logic [63:0] rd_cnt [0:PM_NC-1];
  logic [PM_NC-1:0] rd_ovf; logic [31:0] rd_flags, rd_seq0, rd_seq1;
  task automatic a_read_shadow;
    logic [31:0] lo, hi, w;
    a_read(ADDR_SNAP_SEQ, rd_seq0);
    for (int i = 0; i < PM_NC; i++) begin
      a_read(ADDR_CNT_BASE + 2*i, lo); a_read(ADDR_CNT_BASE + 2*i + 1, hi);
      rd_cnt[i] = {hi, lo};
    end
    a_read(ADDR_OVF_BASE, w);     rd_ovf[31:0]  = w;
    a_read(ADDR_OVF_BASE + 1, w); rd_ovf[PM_NC-1:32] = w[PM_NC-33:0];
    a_read(ADDR_FLAGS, rd_flags);
    a_read(ADDR_SNAP_SEQ, rd_seq1);
  endtask
  logic [63:0] bsh [0:PM_NC-1];
  task automatic b_read_shadow;
    logic [31:0] lo, hi;
    for (int i = 0; i < PM_NC; i++) begin
      b_read(ADDR_CNT_BASE + 2*i, lo); b_read(ADDR_CNT_BASE + 2*i + 1, hi); bsh[i] = {hi, lo};
    end
  endtask

  function automatic bit shadow_matches_model_A();
    bit ok; ok = 1;
    for (int i = 0; i < PM_NC; i++) begin
      if (rd_cnt[i] !== mA_snap[i*64 +: 64]) begin ok = 0; $display("   shadow[%0d] csr=%0d model=%0d", i, rd_cnt[i], mA_snap[i*64 +: 64]); end
      if (rd_ovf[i] !== mA_sovf[i]) ok = 0;
    end
    return ok;
  endfunction

  // snapshot invariants (docs/REGMAP.md I1, I2, I3)
  function automatic bit invariants_ok();
    longint unsigned s, k, tk, tt;
    s = 0; for (int i = 0; i < PM_SLOT_N; i++) s += rd_cnt[PM_SLOT_FIRST + i];
    k = 0; for (int i = 0; i < PM_CLASS_N; i++) k += rd_cnt[PM_CLASS_FIRST + i];
    tt = 0; for (int i = 0; i < 4; i++) tt += rd_cnt[CNT_TILE_TOK_0 + i];
    return (s == rd_cnt[CNT_CYCLES]) && (k == rd_cnt[CNT_SLOT_ISSUE]) && (tt == rd_cnt[CNT_TOK_DISPATCHED]);
  endfunction

  // ---------------------------------------------------------------------------
  // Constrained-random tap stimulus (internally consistent: id_stall is derived)
  // ---------------------------------------------------------------------------
  int p_issue = 80, p_ldst = 5, p_sync = 5, p_notready = 40, p_flush = 3, p_busy = 30;
  function automatic logic [4:0] pick_op(input int k);
    case (k)
      0: return OP_NOP;    1: return OP_ADD;    2: return OP_SUB;    3: return OP_MUL;    4: return OP_LOAD;
      5: return OP_STORE;  6: return OP_MOV;    7: return OP_BEQ;    8: return OP_BNE;    9: return OP_JMP;
      10: return OP_DFLOAD; 11: return OP_DFSTORE; 12: return OP_DFMAP; 13: return OP_DFEXEC; 14: return OP_DFSYNC;
      15: return OP_VADD;  16: return OP_VMUL;  17: return OP_VSUB;  18: return OP_DOT;   19: return OP_MATMUL;
      20: return OP_REDUCE; 21: return OP_BCAST; 22: return OP_VLOAD; 23: return OP_VSTORE;
      24: return 5'h18; 25: return 5'h19; 26: return 5'h1A; 27: return 5'h1B; 28: return 5'h1C; 29: return 5'h1D; default: return 5'h1E;
    endcase
  endfunction
  bit allow_halt = 0;

  function automatic bit is_sched_opc(input [4:0] o);
    return (o >= OP_DFLOAD && o <= OP_VSTORE);
  endfunction
  function automatic bit pr(input int p); return ($urandom_range(99) < p); endfunction

  task automatic drive_random();
    bit ex_sched;
    is_valid    = pr(p_issue);
    is_opcode   = pick_op($urandom_range(30));
    if (allow_halt && pr(2)) is_opcode = 5'h1F;
    ex_valid    = pr(85);
    ex_opcode   = pick_op($urandom_range(30));
    ex_sched    = ex_valid && is_sched_opc(ex_opcode);
    sched_valid = ex_sched;
    sched_ready = !pr(p_notready);
    load_use    = ex_valid && (ex_opcode == OP_LOAD) && pr(p_ldst * 4);
    sync_stall  = pr(p_sync);
    id_stall    = load_use || sync_stall || (sched_valid && !sched_ready);
    flush       = pr(p_flush);
    br_taken    = ex_valid && (ex_opcode == OP_BEQ || ex_opcode == OP_BNE || ex_opcode == OP_JMP) && pr(50);
    wb_valid    = pr(70);
    tok_valid   = '0;
    if (sched_valid && sched_ready && pr(85)) tok_valid[$urandom_range(NT-1)] = 1'b1;
    tgt_tile    = $urandom_range(5);   // includes out-of-range targets 4,5
    tile_busy   = $urandom; tile_busy = tile_busy & {NT{1'b1}};
    if (!pr(p_busy)) tile_busy = '0;
    tile_done   = pr(25) ? (1 << $urandom_range(NT-1)) : 0;
    for (int t = 0; t < NT; t++) tile_state[t*3 +: 3] = pr(40) ? 3'd0 : 3'($urandom_range(3));
    vec_issue   = pr(30) ? $urandom : 0; vec_issue = vec_issue & {NT{1'b1}};
    lane_active = {NT*LANES{1'b1}};
    if (pr(30)) lane_active = $urandom;            // partial masks exercise divergence counters
    tensor_busy = $urandom; tensor_busy = tensor_busy & {NT{1'b1}};
    mem_fire    = pr(30) ? $urandom : 0; mem_blocked = pr(10) ? $urandom : 0;
    mem_resp    = pr(30) ? $urandom : 0; mem_align   = pr(3) ? $urandom : 0;
    noc_occ     = pr(30) ? $urandom_range(40) : 0;
    noc_inj_fire = pr(10) ? $urandom : 0; noc_inj_blocked = pr(10) ? $urandom : 0;
    mem_fire &= {(NT+1){1'b1}}; mem_blocked &= {(NT+1){1'b1}}; mem_resp &= {(NT+1){1'b1}}; mem_align &= {(NT+1){1'b1}};
  endtask

  task automatic quiet();    // all taps idle
    is_valid = 0; is_opcode = 0; id_stall = 0; load_use = 0; sync_stall = 0; flush = 0; br_taken = 0;
    ex_valid = 0; ex_opcode = 0; wb_valid = 0; sched_valid = 0; sched_ready = 1; tok_valid = 0; tgt_tile = 0;
    tile_busy = 0; tile_done = 0; tile_state = 0; vec_issue = 0; lane_active = 0; tensor_busy = 0;
    mem_fire = 0; mem_blocked = 0; mem_resp = 0; mem_align = 0; noc_occ = 0; noc_inj_fire = 0; noc_inj_blocked = 0;
  endtask

  task automatic run_random(input int cycles);
    repeat (cycles) begin @(negedge clk); drive_random(); end
  endtask
  task automatic run_quiet(input int cycles);
    repeat (cycles) begin @(negedge clk); quiet(); end
  endtask
  task automatic set_mode(input int m);
    case (m % 6)
      0: begin p_issue=90; p_ldst=2;  p_sync=2;  p_notready=10; p_flush=1;  p_busy=10; end
      1: begin p_issue=70; p_ldst=60; p_sync=2;  p_notready=10; p_flush=1;  p_busy=20; end
      2: begin p_issue=70; p_ldst=2;  p_sync=2;  p_notready=80; p_flush=1;  p_busy=80; end
      3: begin p_issue=70; p_ldst=2;  p_sync=60; p_notready=30; p_flush=1;  p_busy=70; end
      4: begin p_issue=80; p_ldst=2;  p_sync=2;  p_notready=20; p_flush=40; p_busy=20; end
      5: begin p_issue=30; p_ldst=10; p_sync=10; p_notready=50; p_flush=10; p_busy=50; end
    endcase
  endtask

  // ---------------------------------------------------------------------------
  // Directed classification table: one cycle, expected exclusive slot
  // ---------------------------------------------------------------------------
  task automatic classify_case(input string name, input int expect_slot);
    logic [PM_NC*CWA-1:0] before_q, after_q; int hit; int nhit;
    before_q = dutA.u_regs.live_q;
    @(negedge clk);   // exactly one posedge: the case inputs (set by the caller at a negedge) are sampled once
    after_q = dutA.u_regs.live_q;
    hit = -1; nhit = 0;
    for (int s = 0; s < PM_SLOT_N; s++)
      if (after_q[(PM_SLOT_FIRST+s)*CWA +: CWA] != before_q[(PM_SLOT_FIRST+s)*CWA +: CWA]) begin hit = s; nhit++; end
    check(nhit == 1 && hit == expect_slot, {"classify: ", name});
  endtask

  // ---------------------------------------------------------------------------
  // Main
  // ---------------------------------------------------------------------------
  logic [31:0] r, r2;
  longint unsigned win_sum [0:PM_NC-1];
  longint unsigned total_ev [0:PM_NC-1];
  int seq_before;
  bit ok;

  initial begin
    quiet();
    rst_n = 0; repeat (4) @(negedge clk); rst_n = 1;
    @(negedge clk);

    // ------------------------------------------------------------------ T1 identification / reset values
    a_read(ADDR_ID, r);       check(r == 32'h5346504D, "T1 ID == 'SFPM'");
    a_read(ADDR_VERSION, r);  check(r == 32'h0001_0000, "T1 VERSION == 1.0.0");
    a_read(ADDR_GEOM, r);     check(r == {8'd4, 8'd4, 8'd40, 8'(PM_NC)}, "T1 GEOM = {NT,LANES,CW,NC}");
    a_read(ADDR_FEATURES, r); check(r == 32'd1, "T1 FEATURES: NOC_TAP only (ENABLE_AT_RESET=0)");
    b_read(ADDR_FEATURES, r); check(r == 32'd3, "T1 FEATURES (B): NOC_TAP|ENABLE_AT_RESET");
    a_read(ADDR_CTRL, r);     check(r == 0, "T1 CTRL resets to 0 (disabled)");
    a_read(ADDR_STATUS, r);   check(r == 0, "T1 STATUS resets to 0 (no snapshot)");
    a_read(ADDR_SNAP_SEQ, r); check(r == 0, "T1 SNAP_SEQ resets to 0");
    a_read(8'hFE, r);         check(r == 0, "T1 unmapped address reads 0");
    a_read(ADDR_CNT_BASE + 2*PM_NC, r); check(r == 0, "T1 counter index == NC reads 0 (out of range)");
    a_write(ADDR_ID, 32'hFFFFFFFF); a_read(ADDR_ID, r); check(r == 32'h5346504D, "T1 write to RO register ignored");

    // ------------------------------------------------------------------ T2 enable gating
    set_mode(0); run_random(40);
    a_write(ADDR_CTRL, 32'h100);                // SNAPSHOT while disabled
    a_read_shadow;
    check(rd_cnt[CNT_CYCLES] == 0, "T2 nothing counted while disabled");
    a_write(ADDR_CTRL, 32'h1);                  // ENABLE (counting starts the cycle AFTER this write)
    run_random(50);
    a_write(ADDR_CTRL, 32'h101);                // SNAPSHOT (+keep enabled)
    a_read_shadow;
    check(rd_cnt[CNT_CYCLES] > 50 && rd_cnt[CNT_CYCLES] <= 56, "T2 counting starts after the ENABLE write cycle");
    check(shadow_matches_model_A(), "T2 shadow equals reference model");
    check(invariants_ok(), "T2 invariants I1/I2/I3 hold in snapshot");

    // ------------------------------------------------------------------ T3 classification priority table
    a_write(ADDR_CTRL, 32'h400); a_write(ADDR_CTRL, 32'h1);  // CLEAR then enable
    drain_mem();
    // IDLE: nothing valid, nothing in flight
    classify_case("empty machine -> IDLE", S_IDLE);
    // ISSUE
    is_valid = 1; is_opcode = OP_ADD; classify_case("valid, no stall -> ISSUE", S_ISSUE); quiet();
    // front-end bubble (work in flight, nothing at IS)
    ex_valid = 1; ex_opcode = OP_ADD; classify_case("EX busy, IS empty -> BUBBLE_FRONT", S_BUB_FRONT); quiet();
    // load-use
    ex_valid = 1; ex_opcode = OP_LOAD; load_use = 1; id_stall = 1; is_valid = 1;
    classify_case("load-use -> STALL_DEP", S_DEP); quiet();
    // sync_stall beats load_use
    ex_valid = 1; ex_opcode = OP_LOAD; load_use = 1; sync_stall = 1; id_stall = 1; is_valid = 1;
    classify_case("sync_stall beats load_use -> STALL_SYNC", S_SYNC); quiet();
    // dispatch blocked on a memory-busy tile
    ex_valid = 1; ex_opcode = OP_DFLOAD; sched_valid = 1; sched_ready = 0; id_stall = 1; tgt_tile = 2; tile_state = 12'(3'd1) << 6; is_valid = 1;
    classify_case("dispatch blocked, tile in MEMWAIT -> STALL_MEM", S_MEM); quiet();
    ex_valid = 1; ex_opcode = OP_VADD; sched_valid = 1; sched_ready = 0; id_stall = 1; tgt_tile = 1; tile_state = 12'(3'd2) << 3; is_valid = 1;
    classify_case("dispatch blocked, tile in VECEXEC -> STALL_EXEC_VEC", S_EXEC_VEC); quiet();
    ex_valid = 1; ex_opcode = OP_MATMUL; sched_valid = 1; sched_ready = 0; id_stall = 1; tgt_tile = 0; tile_state = 12'(3'd3); is_valid = 1;
    classify_case("dispatch blocked, tile in TENSOR -> STALL_EXEC_TENSOR", S_EXEC_TENS); quiet();
    ex_valid = 1; ex_opcode = OP_VADD; sched_valid = 1; sched_ready = 0; id_stall = 1; tgt_tile = 3; tile_state = 0; is_valid = 1;
    classify_case("dispatch blocked, target tile idle -> STALL_DISP_OTHER", S_DISP_OTHER); quiet();
    ex_valid = 1; ex_opcode = OP_VADD; sched_valid = 1; sched_ready = 0; id_stall = 1; tgt_tile = 5; is_valid = 1;
    classify_case("dispatch blocked, target tile out of range -> STALL_DISP_OTHER", S_DISP_OTHER); quiet();
    ex_valid = 1; ex_opcode = OP_DFSYNC; sched_valid = 1; sched_ready = 0; id_stall = 1; tgt_tile = 0; tile_state = 12'(3'd3); is_valid = 1;
    classify_case("DFSYNC held at dispatch behind busy tile -> STALL_SYNC (not EXEC)", S_SYNC); quiet();
    // flush beats stall and valid
    flush = 1; is_valid = 1; ex_valid = 1; ex_opcode = OP_LOAD; load_use = 1; id_stall = 1;
    classify_case("flush beats stall -> BUBBLE_CTRL", S_BUB_CTRL); quiet();
    // redirect shadow: 2 cycles after a flush with IS empty are CTRL bubbles, 3rd is not
    flush = 1; @(negedge clk); quiet(); ex_valid = 1; ex_opcode = OP_ADD;
    classify_case("redirect shadow cycle 1 -> BUBBLE_CTRL", S_BUB_CTRL);
    classify_case("redirect shadow cycle 2 -> BUBBLE_CTRL", S_BUB_CTRL);
    classify_case("after shadow, EX busy -> BUBBLE_FRONT", S_BUB_FRONT); quiet();
    // HALT issues, then everything is IDLE
    is_valid = 1; is_opcode = 5'h1F; classify_case("HALT issues -> ISSUE", S_ISSUE);
    is_valid = 1; is_opcode = OP_ADD; ex_valid = 1; classify_case("after HALT, valid instr -> IDLE", S_IDLE);
    a_read(ADDR_STATUS, r);
    quiet();
    a_write(ADDR_CTRL, 32'h100); a_read(ADDR_FLAGS, r); check(r[2] == 1, "T3 PROG_DONE flag set after HALT issued");
    // reset to clear prog_done for the rest of the test
    rst_n = 0; repeat (3) @(negedge clk); rst_n = 1; quiet(); @(negedge clk);

    // ------------------------------------------------------------------ T4 coherent snapshot + stability
    a_write(ADDR_CTRL, 32'h1);
    for (int m = 0; m < 12; m++) begin set_mode(m); run_random(60); end
    a_write(ADDR_CTRL, 32'h101); a_read_shadow;
    check(rd_seq0 == rd_seq1, "T4 SNAP_SEQ stable across the multi-word read");
    check(shadow_matches_model_A(), "T4 CSR shadow == model snapshot (all 57 counters + overflow bitmap)");
    check(invariants_ok(), "T4 invariants I1/I2/I3 hold");
    seq_before = rd_seq1;
    // activity continues; shadow must not move
    set_mode(5); run_random(200);
    begin
      logic [63:0] keep [0:PM_NC-1];
      for (int i = 0; i < PM_NC; i++) keep[i] = rd_cnt[i];
      a_read_shadow; ok = 1;
      for (int i = 0; i < PM_NC; i++) if (keep[i] !== rd_cnt[i]) ok = 0;
      check(ok, "T4 shadow is stable while live counters keep running");
    end
    a_write(ADDR_CTRL, 32'h101); a_read_shadow;
    check(rd_seq1 == seq_before + 1, "T4 second SNAPSHOT increments SNAP_SEQ by exactly 1");
    check(shadow_matches_model_A() && invariants_ok(), "T4 second snapshot matches model and invariants");
    check(rd_cnt[CNT_CYCLES] > 200, "T4 later snapshot advanced CYCLES");

    // ------------------------------------------------------------------ T5 SNAP_CLR windows tile the timeline
    a_write(ADDR_CTRL, 32'h401); a_write(ADDR_CTRL, 32'h1);   // CLEAR, enable
    for (int i = 0; i < PM_NC; i++) win_sum[i] = 0;
    // independent total: free-running copy of the model's events is the DUT-lockstep model of a no-snap run;
    // instead verify tiling through the identity: sum of windows + final live == one big snapshot of a twin.
    for (int w = 0; w < 6; w++) begin
      set_mode(w); run_random(70 + 13*w);
      a_write(ADDR_CTRL, 32'h201 /* SNAP_CLR | ENABLE */); a_read_shadow;
      ok = shadow_matches_model_A(); if (!ok) $display("  window %0d mismatch", w);
      check(ok && invariants_ok(), $sformatf("T5 window %0d: shadow==model and invariants hold", w));
      for (int i = 0; i < PM_NC; i++) if ((PM_KIND_V[2*i +: 2]) == KIND_ACC) win_sum[i] += rd_cnt[i];
    end
    // After SNAP_CLR the new epoch started: first window after clear contains only post-command cycles.
    a_write(ADDR_CTRL, 32'h101); a_read_shadow;
    for (int i = 0; i < PM_NC; i++) if ((PM_KIND_V[2*i +: 2]) == KIND_ACC) win_sum[i] += rd_cnt[i];
    check(win_sum[CNT_CYCLES] > 0 && invariants_ok(), "T5 trailing window consistent");
    check(win_sum[CNT_CYCLES] == tally_cap, $sformatf("T5 sum of window CYCLES (%0d) == independently tallied enabled cycles (%0d): no event lost or double counted", win_sum[CNT_CYCLES], tally_cap));
    begin
      bit all_ok; all_ok = 1;
      for (int i = 0; i < 4; i++) if (win_sum[CNT_TILE_TOK_0+i] > win_sum[CNT_TOK_DISPATCHED]) all_ok = 0;
      check(all_ok, "T5 per-tile token windows consistent with TOK_DISPATCHED");
    end

    // ------------------------------------------------------------------ T6 CLEAR
    a_write(ADDR_CTRL, 32'h1); set_mode(0); run_random(30);
    a_read(ADDR_SNAP_SEQ, r); seq_before = r;
    a_write(ADDR_CTRL, 32'h401);
    check(dutA.u_regs.live_q[CNT_CYCLES*CWA +: CWA] == 0, "T6 live counters are zero right after CLEAR (events in the clear cycle discarded)");
    a_read(ADDR_STATUS, r2);
    check(r2[0] == 0, "T6 CLEAR invalidates the snapshot (SNAP_VALID=0)");
    a_read(ADDR_SNAP_SEQ, r); check(r == seq_before + 1, "T6 CLEAR increments SNAP_SEQ (does not reset it)");
    a_read(ADDR_CNT_BASE + 2*CNT_CYCLES, r); check(r == 0, "T6 CLEAR zeroes the shadow");

    // ------------------------------------------------------------------ T12/T13 trigger + command priority
    a_write(ADDR_CTRL, 32'h1); run_random(20);
    a_read(ADDR_SNAP_SEQ, r); seq_before = r;
    @(negedge clk); a_trig = 1; @(negedge clk); a_trig = 0;
    a_read(ADDR_SNAP_SEQ, r); check(r == seq_before + 1, "T12 snap_trig_i behaves as SNAPSHOT");
    a_read(ADDR_STATUS, r); check(r[0] == 1, "T12 SNAP_VALID set by hardware trigger");
    a_read(ADDR_SNAP_SEQ, r); seq_before = r;
    a_write(ADDR_CTRL, 32'h701);   // CLEAR | SNAP_CLR | SNAPSHOT | ENABLE in one write
    a_read(ADDR_STATUS, r); check(r[0] == 0, "T13 CLEAR has priority over SNAPSHOT/SNAP_CLR in the same write");
    a_read(ADDR_SNAP_SEQ, r); check(r == seq_before + 1, "T13 exactly one SEQ increment for a combined command");

    // ------------------------------------------------------------------ T10 watchdog
    a_write(ADDR_CTRL, 32'h401); a_write(ADDR_CTRL, 32'h1);
    a_write(ADDR_WDOG_THRESH, 32'd60);
    a_read(ADDR_WDOG_THRESH, r); check(r == 60, "T10 WDOG_THRESH readback");
    quiet(); is_valid = 0; run_quiet(10);
    a_write(ADDR_CTRL, 32'h101); a_read(ADDR_FLAGS, r); check(r[1] == 0, "T10 watchdog does not trip before the threshold");
    // inject one progress event, then 25 idle cycles
    @(negedge clk); tile_done = 4'b0001; @(negedge clk); tile_done = 0;
    run_quiet(70);
    a_write(ADDR_CTRL, 32'h101); a_read(ADDR_FLAGS, r); check(r[1] == 1, "T10 watchdog trips after THRESH cycles without progress");
    a_read(ADDR_STATUS, r); check(r[3] == 1, "T10 STATUS.WDOG_LIVE sticky");
    a_write(ADDR_CTRL, 32'h401); a_read(ADDR_STATUS, r); check(r[3] == 0, "T10 CLEAR resets the watchdog flag");
    a_write(ADDR_WDOG_THRESH, 32'd0);

    // ------------------------------------------------------------------ T15 irq
    a_write(ADDR_CTRL, 32'h3);   // ENABLE | IRQ_EN
    check(a_irq == 0, "T15 irq low with no event");
    a_write(ADDR_WDOG_THRESH, 32'd5); run_quiet(12);
    check(a_irq == 1, "T15 irq asserts on watchdog trip when IRQ_EN set");
    a_write(ADDR_CTRL, 32'h401); a_write(ADDR_CTRL, 32'h3);
    check(a_irq == 0, "T15 irq deasserts after CLEAR");
    a_write(ADDR_WDOG_THRESH, 32'd0); a_write(ADDR_CTRL, 32'h1);
    // the interrupt must stay low when IRQ_EN is clear, even with a latched watchdog trip
    a_write(ADDR_CTRL, 32'h401); a_write(ADDR_CTRL, 32'h1);
    a_write(ADDR_WDOG_THRESH, 32'd5); run_quiet(12);
    a_read(ADDR_STATUS, r); check(r[3] == 1, "T15 (sanity) watchdog tripped with IRQ_EN clear");
    check(a_irq == 0, "T15 irq stays low while IRQ_EN is clear, although the watchdog tripped");
    a_write(ADDR_WDOG_THRESH, 32'd0); a_write(ADDR_CTRL, 32'h401); a_write(ADDR_CTRL, 32'h1);

    // ------------------------------------------------------------------ T8 40-bit counters: HI word and saturation
    a_write(ADDR_CTRL, 32'h401); a_write(ADDR_CTRL, 32'h1); quiet(); @(negedge clk);
    force_counter_A(CNT_CYCLES, 64'hFFFF_FFFC);                 // 4 below 2^32
    run_quiet(10);
    a_write(ADDR_CTRL, 32'h101); a_read_shadow;
    check(rd_cnt[CNT_CYCLES][63:32] == 32'd1, "T8 CYCLES crossed 2^32: HI word reads 1");
    check(shadow_matches_model_A(), "T8 40-bit shadow == model across the 32-bit boundary");
    force_counter_A(CNT_CYCLES, 64'hFF_FFFF_FFFD);              // 2 below saturation (2^40-1 = FF_FFFF_FFFF)
    run_quiet(2);                                               // +1 +1 -> exactly 2^40-1
    a_write_now(ADDR_CTRL, 32'h101); a_read_shadow;             // command lands on the very next edge
    check(rd_cnt[CNT_CYCLES] == 64'hFF_FFFF_FFFF && rd_ovf[CNT_CYCLES] == 0, "T8 lands exactly on 2^40-1: no overflow flagged (nothing lost)");
    run_quiet(3);
    a_write(ADDR_CTRL, 32'h101); a_read_shadow; a_read(ADDR_FLAGS, r);
    check(rd_cnt[CNT_CYCLES] == 64'hFF_FFFF_FFFF && rd_ovf[CNT_CYCLES] == 1 && r[0] == 1, "T8 saturates at 2^40-1 and sets sticky OVF + FLAGS.OVF_ANY");
    check(shadow_matches_model_A(), "T8 saturated shadow == model");
    run_quiet(5); a_write(ADDR_CTRL, 32'h101); a_read_shadow;
    check(rd_ovf[CNT_CYCLES] == 1, "T8 overflow bit is sticky until CLEAR");
    a_write(ADDR_CTRL, 32'h401); a_write(ADDR_CTRL, 32'h1); a_write(ADDR_CTRL, 32'h101); a_read_shadow;
    check(rd_ovf == 0 && rd_cnt[CNT_CYCLES] <= 3, "T8 CLEAR clears overflow bits and counters");
    sva_gate(0);

    // ------------------------------------------------------------------ T7 overflow with CW=8 (DUT B, enabled at reset)
    b_write(ADDR_CTRL, 32'h401); b_write(ADDR_CTRL, 32'h3); // clear, enable, irq_en
    set_mode(0); run_random(400);
    b_write(ADDR_CTRL, 32'h103); b_read_shadow;
    ok = 1; for (int i = 0; i < PM_NC; i++) if (bsh[i] !== mB_snap[i*64 +: 64]) begin ok = 0; $display("   B shadow[%0d] csr=%0d model=%0d", i, bsh[i], mB_snap[i*64 +: 64]); end
    check(ok, "T7 CW=8 shadow (with saturation) == model for all counters");
    check(bsh[CNT_CYCLES] == 8'hFF, "T7 CYCLES saturated at 2^8-1 = 255");
    b_read(ADDR_OVF_BASE, r); b_read(ADDR_OVF_BASE + 1, r2);
    begin
      logic [63:0] ov64; ov64 = {r2, r};
      check(ov64[CNT_CYCLES] == 1, "T7 CYCLES sticky overflow bit set");
      check(ov64[CNT_MEM_OUT_PEAK] == 0 && ov64[CNT_STALL_STREAK_MAX] == 0 && ov64[CNT_Q_NOC_NOW] == 0, "T7 peak and gauge counters never flag overflow");
    end
    check(b_irq == 1, "T7 irq asserts on counter overflow when IRQ_EN set");
    b_read(ADDR_STATUS, r); check(r[2] == 1, "T7 STATUS.OVF_LIVE");

    // ------------------------------------------------------------------ T9 asynchronous reset mid-run
    set_mode(2); run_random(30);
    #2; rst_n = 0; #1;     // between clock edges
    check(dutA.u_regs.live_q == '0 && dutA.u_regs.snap_q == '0 && dutA.u_regs.en_q == 0, "T9 asynchronous reset clears counters, shadow and ENABLE immediately");
    check(dutB.u_regs.en_q == 1 && dutB.u_regs.live_q == '0, "T9 ENABLE_AT_RESET=1 re-enables DUT B, counters zero");
    repeat (3) @(negedge clk); rst_n = 1; quiet(); @(negedge clk);
    a_read(ADDR_SNAP_SEQ, r); check(r == 0, "T9 SNAP_SEQ cleared by reset");

    // ------------------------------------------------------------------ T14 long constrained-random lock-step soak
    a_write(ADDR_CTRL, 32'h1); b_write(ADDR_CTRL, 32'h401); b_write(ADDR_CTRL, 32'h1);
    for (int m = 0; m < 60; m++) begin
      set_mode($urandom_range(5)); run_random(120);
      if (m % 7 == 3) a_write(ADDR_CTRL, 32'h201);
      if (m % 11 == 5) a_write(ADDR_CTRL, 32'h101);
      if (m % 17 == 9) b_write(ADDR_CTRL, 32'h101);
    end
    a_write(ADDR_CTRL, 32'h101); a_read_shadow;
    check(shadow_matches_model_A() && invariants_ok(), "T14 soak: final CSR shadow == model, invariants hold");
    check(rd_seq0 == rd_seq1, "T14 soak: SEQ stable during final read");
    check(live_mismatch == 0, $sformatf("T14 lock-step: DUT == reference model on every cycle, every counter, both widths (%0d mismatches)", live_mismatch));

    $display("");
    $display("tb_pm_unit: PASS=%0d FAIL=%0d", n_pass, n_fail);
    if (n_fail == 0) $display("ALL TESTS PASSED"); else $display("SOME TESTS FAILED");
    $finish;
  end

  // Deposit into DUT A's live counter and the matching model counter (simulation backdoor)
  task automatic sva_gate(input bit off);
`ifdef SF_PM_SVA
    dutA.u_sva.tb_sva_off = off;
`endif
  endtask
  task automatic force_counter_A(input int idx, input longint unsigned v);
    sva_gate(1);     // deposit is not a reachable transition: gate the assertions until the next CLEAR
    cmp_en = 0;
    @(negedge clk);
    case (idx)
      CNT_CYCLES: begin dutA.u_regs.g_cnt[CNT_CYCLES].u_cnt.q_o = v[CWA-1:0]; mA.cnt[CNT_CYCLES] = v; mA.publish(); end
      default: ;
    endcase
    cmp_en = 1;
  endtask

  initial begin
    #50_000_000; $display("[FAIL] timeout"); $finish;
  end
endmodule
