// =============================================================================
// pm_ref_model -- behavioural, cycle-accurate reference model of sf_perfmon
//
// Written from the specification (docs/METRICS.md, docs/ARCHITECTURE.md) in a
// deliberately different style from the RTL: procedural if/else with blocking
// arithmetic on 64-bit integers instead of an explicit priority chain on
// packed vectors.  NOT synthesizable; testbench use only.
//
// Exposes live counters, shadow registers and flags so a testbench can compare
// them against the DUT every cycle and after every snapshot.
// =============================================================================
`include "silicaflux_pkg.sv"

module pm_ref_model
  import silicaflux_pkg::*;
  import sf_pm_pkg::*;
#(
  parameter int NT = 4, parameter int LANES = 4, parameter int CW = 40,
  parameter int CTRL_SHADOW = 2, parameter bit ENABLE_AT_RESET = 1'b0
) (
  input  logic clk, rst_n,
  input  logic csr_en_i, csr_we_i, input logic [CSR_AW-1:0] csr_addr_i, input logic [31:0] csr_wdata_i,
  input  logic snap_trig_i,
  input  logic is_valid_i, input logic [4:0] is_opcode_i, input logic id_stall_i, load_use_i, sync_stall_i,
  input  logic flush_i, br_taken_i, ex_valid_i, input logic [4:0] ex_opcode_i, input logic wb_valid_i,
  input  logic sched_valid_i, sched_ready_i, input logic [NT-1:0] tok_valid_i, input logic [2:0] tgt_tile_i,
  input  logic [NT-1:0] tile_busy_i, tile_done_i, input logic [NT*3-1:0] tile_state_i,
  input  logic [NT-1:0] vec_issue_i, input logic [NT*LANES-1:0] lane_active_i, input logic [NT-1:0] tensor_busy_i,
  input  logic [NT:0] mem_fire_i, mem_blocked_i, mem_resp_i, mem_align_i,
  input  logic [7:0] noc_occ_i, input logic [NT-1:0] noc_inj_fire_i, noc_inj_blocked_i,
  output logic [PM_NC*64-1:0] live_o,
  output logic [PM_NC-1:0]    live_ovf_o,
  output logic [PM_NC*64-1:0] snap_o,
  output logic [PM_NC-1:0]    snap_ovf_o,
  output logic [31:0]         snap_flags_o, snap_seq_o,
  output logic                snap_valid_o, wdog_trip_o, prog_done_o,
  output logic [PM_SLOT_N-1:0] slot_o      // classification of the cycle just processed
);
  localparam longint unsigned MAXV = (64'd1 << CW) - 64'd1;

  longint unsigned cnt [0:PM_NC-1];
  longint unsigned scnt[0:PM_NC-1];
  longint unsigned ev  [0:PM_NC-1];
  bit              ovf [0:PM_NC-1];
  bit              sovf[0:PM_NC-1];
  bit en, irq_en, prog_done, wdog_trip, snap_valid, exf, mf, wf;
  bit [CTRL_SHADOW-1:0] shadow;
  bit [NT:0] mout;
  longint unsigned streak, noprog;
  bit [31:0] thresh, seq, sflags;

  function automatic int pop(input logic [63:0] v);
    int n; n = 0; for (int i = 0; i < 64; i++) if (v[i]) n++; return n;
  endfunction

  int slot_idx;   // which SLOT_* is hit this cycle (0..PM_SLOT_N-1)

  // Outputs are published at the end of every clock step (iverilog does not reliably
  // re-trigger always_comb on array-word changes, so no always_comb over arrays here).
  task automatic publish();
    for (int i = 0; i < PM_NC; i++) begin
      live_o[i*64 +: 64] = cnt[i];
      snap_o[i*64 +: 64] = scnt[i];
      live_ovf_o[i]      = ovf[i];
      snap_ovf_o[i]      = sovf[i];
    end
    snap_flags_o = sflags; snap_seq_o = seq; snap_valid_o = snap_valid;
    wdog_trip_o = wdog_trip; prog_done_o = prog_done;
  endtask

  always @(posedge clk or negedge rst_n) begin
    bit clr, sn, sc, snapfire, restart, stall, iss, ret_s, drop, anytok, progress, mach_busy, shadow_any, wr;
    int blk, cls;
    longint unsigned sum, streak_n, noprog_n;
    slot_o = '0;
    if (!rst_n) begin
      for (int i = 0; i < PM_NC; i++) begin cnt[i] = 0; scnt[i] = 0; ev[i] = 0; ovf[i] = 0; sovf[i] = 0; end
      en = ENABLE_AT_RESET; irq_en = 0; prog_done = 0; wdog_trip = 0; snap_valid = 0; exf = 0; mf = 0; wf = 0;
      shadow = '0; mout = '0; streak = 0; noprog = 0; thresh = 0; seq = 0; sflags = 0;
    end else begin
      wr  = csr_en_i && csr_we_i;
      clr = wr && csr_addr_i == ADDR_CTRL && csr_wdata_i[CTRL_CLEAR];
      sn  = wr && csr_addr_i == ADDR_CTRL && csr_wdata_i[CTRL_SNAPSHOT];
      sc  = wr && csr_addr_i == ADDR_CTRL && csr_wdata_i[CTRL_SNAP_CLR];
      snapfire = (sn || sc || snap_trig_i) && !clr;
      restart  = sc && !clr;

      // ---------------- classify this cycle (software style) ----------------
      stall = id_stall_i;
      mach_busy  = ex_valid_i || (|tile_busy_i) || (|mout);
      shadow_any = |shadow;
      blk = 7;
      for (int t = 0; t < NT; t++) if (tgt_tile_i == t) blk = tile_state_i[t*3 +: 3];
      slot_idx = -1;
      if (prog_done)                       slot_idx = S_IDLE;
      else if (flush_i)                    slot_idx = S_BUB_CTRL;
      else if (stall) begin
        if (sync_stall_i)                  slot_idx = S_SYNC;
        else if (load_use_i)               slot_idx = S_DEP;
        else if (sched_valid_i && !sched_ready_i) begin
          if (ex_opcode_i == OP_DFSYNC)    slot_idx = S_SYNC;
          else if (blk == 1)               slot_idx = S_MEM;
          else if (blk == 2)               slot_idx = S_EXEC_VEC;
          else if (blk == 3)               slot_idx = S_EXEC_TENS;
          else                             slot_idx = S_DISP_OTHER;
        end else                           slot_idx = S_DISP_OTHER;
      end
      else if (is_valid_i)                 slot_idx = S_ISSUE;
      else if (shadow_any)                 slot_idx = S_BUB_CTRL;
      else if (mach_busy)                  slot_idx = S_BUB_FRONT;
      else                                 slot_idx = S_IDLE;
      slot_o[slot_idx] = 1'b1;
      iss = (slot_idx == S_ISSUE);

      case (is_opcode_i)
        OP_ADD, OP_SUB, OP_MUL, OP_MOV: cls = K_SALU;
        OP_LOAD, OP_STORE: cls = K_SMEM;
        OP_BEQ, OP_BNE, OP_JMP: cls = K_BRANCH;
        OP_DFLOAD, OP_DFSTORE, OP_VLOAD, OP_VSTORE: cls = K_DFMEM;
        OP_DFMAP, OP_DFEXEC, OP_DFSYNC: cls = K_DFCTL;
        OP_VADD, OP_VSUB, OP_VMUL, OP_DOT, OP_REDUCE, OP_BCAST: cls = K_VEC;
        OP_MATMUL: cls = K_TENSOR;
        default: cls = K_NOP;
      endcase

      ret_s  = wb_valid_i && wf;
      anytok = |tok_valid_i;
      drop   = sched_valid_i && sched_ready_i && !anytok;
      progress = iss || ret_s || (|tile_done_i) || anytok;
      stall = (slot_idx == S_DEP) || (slot_idx == S_SYNC) || (slot_idx == S_EXEC_VEC) ||
              (slot_idx == S_EXEC_TENS) || (slot_idx == S_MEM) || (slot_idx == S_DISP_OTHER);
      streak_n = stall ? ((streak == MAXV) ? streak : streak + 1) : 0;

      // ---------------- per-counter event values ----------------
      for (int i = 0; i < PM_NC; i++) ev[i] = 0;
      ev[CNT_CYCLES] = 1;
      for (int s = 0; s < PM_SLOT_N; s++) ev[PM_SLOT_FIRST + s] = (slot_idx == s);
      if (iss) ev[PM_CLASS_FIRST + cls] = 1;
      ev[CNT_RET_SCALAR]     = ret_s;
      ev[CNT_RET_TILE]       = pop(tile_done_i);
      ev[CNT_TOK_DISPATCHED] = pop(tok_valid_i);
      ev[CNT_DROP_SYNC]      = drop && (ex_opcode_i == OP_DFSYNC);
      ev[CNT_DROP_OP]        = drop && (ex_opcode_i != OP_DFSYNC);
      ev[CNT_BRANCH_TAKEN]   = br_taken_i;
      for (int t = 0; t < 4; t++) begin
        ev[CNT_TILE_TOK_0  + t] = tok_valid_i[t];
        ev[CNT_TILE_BUSY_0 + t] = tile_busy_i[t];
      end
      begin
        int lanes, part, vb;
        lanes = 0; part = 0; vb = 0;
        for (int t = 0; t < NT; t++) begin
          if (vec_issue_i[t]) begin
            int a; a = 0;
            for (int l = 0; l < LANES; l++) if (lane_active_i[t*LANES + l]) a++;
            lanes += a; if (a > 0 && a < LANES) part++;
          end
          if (tile_state_i[t*3 +: 3] == 3'd2) vb++;
        end
        ev[CNT_VEC_ISSUES] = pop(vec_issue_i); ev[CNT_VEC_LANES_ACTIVE] = lanes;
        ev[CNT_VEC_ISSUES_PARTIAL] = part; ev[CNT_VEC_BUSY_CYC] = vb;
        ev[CNT_TENSOR_BUSY_CYC] = pop(tensor_busy_i);
      end
      ev[CNT_MEM_REQ_ACCEPTED] = pop(mem_fire_i);   ev[CNT_MEM_RESP] = pop(mem_resp_i);
      ev[CNT_MEM_REQ_BLOCKED]  = pop(mem_blocked_i); ev[CNT_MEM_ALIGN_ERR] = pop(mem_align_i);
      ev[CNT_MEM_OUT_SUM] = pop(mout); ev[CNT_MEM_BUSY_CYC] = (|mout);
      ev[CNT_MEM_OUT_PEAK] = pop(mout); ev[CNT_MEM_OUT_NOW] = pop(mout);
      ev[CNT_Q_DISP_SUM] = sched_valid_i; ev[CNT_Q_DISP_NOW] = sched_valid_i;
      ev[CNT_Q_TOK_SUM] = pop(tile_busy_i); ev[CNT_Q_TOK_PEAK] = pop(tile_busy_i); ev[CNT_Q_TOK_NOW] = pop(tile_busy_i);
      ev[CNT_Q_NOC_SUM] = noc_occ_i; ev[CNT_Q_NOC_PEAK] = noc_occ_i; ev[CNT_Q_NOC_NOW] = noc_occ_i;
      ev[CNT_NOC_FLITS] = pop(noc_inj_fire_i); ev[CNT_NOC_INJ_BLOCKED] = pop(noc_inj_blocked_i);
      ev[CNT_STALL_STREAK_MAX] = streak_n;

      // ---------------- shadow capture (pre-update values) ----------------
      if (clr) begin
        for (int i = 0; i < PM_NC; i++) begin scnt[i] = 0; sovf[i] = 0; end
        sflags = 0; snap_valid = 0; seq = seq + 1;
      end else if (snapfire) begin
        bit anyovf; anyovf = 0;
        for (int i = 0; i < PM_NC; i++) begin scnt[i] = cnt[i]; sovf[i] = ovf[i]; anyovf |= ovf[i]; end
        sflags = {29'd0, prog_done, wdog_trip, anyovf}; snap_valid = 1; seq = seq + 1;
      end

      // ---------------- live counter update ----------------
      for (int i = 0; i < PM_NC; i++) begin
        int kind; kind = PM_KIND_V[2*i +: 2];
        if (clr) begin cnt[i] = 0; ovf[i] = 0; end
        else if (restart) begin cnt[i] = en ? ev[i] : 0; ovf[i] = 0; end
        else if (en) begin
          if (kind == KIND_ACC) begin
            sum = cnt[i] + ev[i];
            if (sum > MAXV) begin cnt[i] = MAXV; ovf[i] = 1; end else cnt[i] = sum;
          end else if (kind == KIND_PEAK) begin
            if (ev[i] > cnt[i]) cnt[i] = ev[i];
          end else cnt[i] = ev[i];
        end
      end

      // ---------------- watchdog ----------------
      noprog_n = progress ? 0 : ((noprog == 64'hFFFFFFFF) ? noprog : noprog + 1);
      if (clr) begin noprog = 0; wdog_trip = 0; end
      else if (en) begin
        noprog = noprog_n;
        if (thresh != 0 && !progress && noprog_n >= thresh) wdog_trip = 1;
      end

      // ---------------- tracking state ----------------
      if (iss && is_opcode_i == 5'h1F) prog_done = 1;
      shadow = {shadow, flush_i};   // shift in at LSB: bit0 newest
      // unique-instruction tag pipeline: next-state from PRE-edge values
      begin
        bit nexf, nmf, nwf;
        nexf = iss;
        nmf  = exf && ex_valid_i && !sched_valid_i;
        nwf  = mf;
        exf = nexf; mf = nmf; wf = nwf;
      end
      for (int c = 0; c <= NT; c++) begin
        if (mem_fire_i[c]) mout[c] = 1; else if (mem_resp_i[c]) mout[c] = 0;
      end
      if (clr) streak = 0; else if (en) streak = streak_n;

      // ---------------- CSR write side effects ----------------
      if (wr && csr_addr_i == ADDR_CTRL) begin en = csr_wdata_i[CTRL_ENABLE]; irq_en = csr_wdata_i[CTRL_IRQ_EN]; end
      if (wr && csr_addr_i == ADDR_WDOG_THRESH) thresh = csr_wdata_i;
    end
    publish();
  end

endmodule
