// =============================================================================
// tb_pm_dump -- random taps + random CSR command sequence, dumped in the documented
// trace format (docs/METRICS.md Part C) so an INDEPENDENT checker can re-derive every
// counter.  Exercises what the real core never produces: partial lane masks, NoC
// traffic, alignment errors, out-of-range tile targets, peaks, HALT, watchdog, CLEAR,
// SNAP_CLR windows, ENABLE toggling.
//   +OUT=<dir> +SEED=<n> +CYCLES=<n>
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"
module tb_pm_dump;
  import silicaflux_pkg::*;
  import sf_pm_pkg::*;
  localparam int NT = 4, LANES = 4, CW = 40;
  logic clk = 0, rst_n = 0; always #5 clk = ~clk;
  logic is_valid, id_stall, load_use, sync_stall, flush, br_taken, ex_valid, wb_valid, sched_valid, sched_ready;
  logic [4:0] is_opcode, ex_opcode; logic [NT-1:0] tok_valid, tile_busy, tile_done, vec_issue, tensor_busy, noc_inj_fire, noc_inj_blocked;
  logic [2:0] tgt_tile; logic [NT*3-1:0] tile_state; logic [NT*LANES-1:0] lane_active; logic [NT:0] mem_fire, mem_blocked, mem_resp, mem_align; logic [7:0] noc_occ;
  logic c_en = 0, c_we = 0; logic [CSR_AW-1:0] c_addr = 0; logic [31:0] c_wdata = 0; wire [31:0] c_rdata; wire c_rvalid; wire irq;

  sf_perfmon #(.NT(NT), .LANES(LANES), .CW(CW)) dut (
    .clk, .rst_n, .csr_en_i(c_en), .csr_we_i(c_we), .csr_addr_i(c_addr), .csr_wdata_i(c_wdata),
    .csr_rdata_o(c_rdata), .csr_rvalid_o(c_rvalid), .snap_trig_i(1'b0), .irq_o(irq),
    .is_valid_i(is_valid), .is_opcode_i(is_opcode), .id_stall_i(id_stall), .load_use_i(load_use), .sync_stall_i(sync_stall),
    .flush_i(flush), .br_taken_i(br_taken), .ex_valid_i(ex_valid), .ex_opcode_i(ex_opcode), .wb_valid_i(wb_valid),
    .sched_valid_i(sched_valid), .sched_ready_i(sched_ready), .tok_valid_i(tok_valid), .tgt_tile_i(tgt_tile),
    .tile_busy_i(tile_busy), .tile_done_i(tile_done), .tile_state_i(tile_state), .vec_issue_i(vec_issue),
    .lane_active_i(lane_active), .tensor_busy_i(tensor_busy), .mem_fire_i(mem_fire), .mem_blocked_i(mem_blocked),
    .mem_resp_i(mem_resp), .mem_align_i(mem_align), .noc_occ_i(noc_occ), .noc_inj_fire_i(noc_inj_fire), .noc_inj_blocked_i(noc_inj_blocked));

  string outd; integer seed, ncyc, fh_t, fh_c, fh_s; longint unsigned cyc = 0;
  int p_issue = 80, p_ldst = 5, p_sync = 5, p_notready = 40, p_flush = 3, p_busy = 30; bit allow_halt = 0; bit quiet_mode = 0; int p_noise = 0; bit noread = 0;   // noread: a snapshot command whose shadow is deliberately not read back
  function automatic logic [4:0] pick_op(input int k);
    case (k)
      0: return OP_NOP; 1: return OP_ADD; 2: return OP_SUB; 3: return OP_MUL; 4: return OP_LOAD; 5: return OP_STORE; 6: return OP_MOV;
      7: return OP_BEQ; 8: return OP_BNE; 9: return OP_JMP; 10: return OP_DFLOAD; 11: return OP_DFSTORE; 12: return OP_DFMAP;
      13: return OP_DFEXEC; 14: return OP_DFSYNC; 15: return OP_VADD; 16: return OP_VMUL; 17: return OP_VSUB; 18: return OP_DOT;
      19: return OP_MATMUL; 20: return OP_REDUCE; 21: return OP_BCAST; 22: return OP_VLOAD; 23: return OP_VSTORE;
      24: return 5'h18; 25: return 5'h19; 26: return 5'h1A; 27: return 5'h1B; 28: return 5'h1C; 29: return 5'h1D; default: return 5'h1E;
    endcase
  endfunction
  function automatic bit pr(input int p); return ($urandom_range(99) < p); endfunction
  task automatic set_mode(input int m);
    case (m % 6)
      0: begin p_issue=90; p_ldst=2;  p_sync=2;  p_notready=10; p_flush=1;  p_busy=10; end
      1: begin p_issue=70; p_ldst=60; p_sync=2;  p_notready=10; p_flush=1;  p_busy=20; end
      2: begin p_issue=70; p_ldst=2;  p_sync=2;  p_notready=80; p_flush=1;  p_busy=80; end
      3: begin p_issue=70; p_ldst=2;  p_sync=60; p_notready=30; p_flush=1;  p_busy=70; end
      4: begin p_issue=80; p_ldst=2;  p_sync=2;  p_notready=20; p_flush=40; p_busy=20; end
      5: begin p_issue=30; p_ldst=10; p_sync=10; p_notready=50; p_flush=10; p_busy=50; end
    endcase
  endtask
  task automatic drive_random();
    bit ex_sched;
    is_valid = pr(p_issue); is_opcode = pick_op($urandom_range(30)); if (allow_halt && pr(1)) is_opcode = 5'h1F;
    ex_valid = pr(85); ex_opcode = pick_op($urandom_range(30)); ex_sched = ex_valid && (ex_opcode >= OP_DFLOAD && ex_opcode <= OP_VSTORE);
    sched_valid = ex_sched; sched_ready = !pr(p_notready);
    load_use = ex_valid && (ex_opcode == OP_LOAD) && pr(p_ldst * 4); sync_stall = pr(p_sync);
    id_stall = load_use || sync_stall || (sched_valid && !sched_ready);
    flush = pr(p_flush); br_taken = ex_valid && (ex_opcode == OP_BEQ || ex_opcode == OP_BNE || ex_opcode == OP_JMP) && pr(50);
    wb_valid = pr(70); tok_valid = '0; if (sched_valid && sched_ready && pr(85)) tok_valid[$urandom_range(NT-1)] = 1'b1;
    tgt_tile = $urandom_range(5); tile_busy = $urandom; tile_busy = tile_busy & {NT{1'b1}}; if (!pr(p_busy)) tile_busy = '0;
    tile_done = pr(25) ? (1 << $urandom_range(NT-1)) : 0;
    for (int t = 0; t < NT; t++) tile_state[t*3 +: 3] = pr(40) ? 3'd0 : 3'($urandom_range(3));
    vec_issue = pr(30) ? $urandom : 0; vec_issue = vec_issue & {NT{1'b1}};
    lane_active = {NT*LANES{1'b1}}; if (pr(40)) lane_active = $urandom;
    tensor_busy = $urandom; tensor_busy = tensor_busy & {NT{1'b1}};
    mem_fire = pr(30) ? $urandom : 0; mem_blocked = pr(10) ? $urandom : 0; mem_resp = pr(30) ? $urandom : 0; mem_align = pr(3) ? $urandom : 0;
    noc_occ = pr(30) ? $urandom_range(40) : 0; noc_inj_fire = pr(10) ? $urandom : 0; noc_inj_blocked = pr(10) ? $urandom : 0;
    mem_fire &= {(NT+1){1'b1}}; mem_blocked &= {(NT+1){1'b1}}; mem_resp &= {(NT+1){1'b1}}; mem_align &= {(NT+1){1'b1}};
    if (pr(p_noise)) id_stall = 1;                       // stall with no identifiable cause -> STALL_DISP_OTHER fall-through
    if (quiet_mode) begin is_valid = 0; tok_valid = 0; tile_done = 0; wb_valid = 0; id_stall = 0; load_use = 0; sync_stall = 0; sched_valid = 0; end
  endtask

  // ---- sampler: one trace row per posedge + one cmds row per CTRL/WDOG write
  always @(posedge clk) if (rst_n) begin
    $fdisplay(fh_t, "%0d,%b,%b,%h,%b,%b,%b,%b,%b,%b,%h,%b,%b,%b,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h,%h",
      cyc, dut.u_regs.en_q, is_valid, is_opcode, id_stall, load_use, sync_stall, flush, br_taken, ex_valid, ex_opcode, wb_valid,
      sched_valid, sched_ready, tok_valid, tgt_tile, tile_busy, tile_done, tile_state, vec_issue, lane_active, tensor_busy,
      mem_fire, mem_blocked, mem_resp, mem_align, noc_occ, noc_inj_fire, noc_inj_blocked);
    if (c_en && c_we && c_addr == ADDR_CTRL)        $fdisplay(fh_c, "%0d,%s,%08h", cyc, noread ? "NOREAD" : "CTRL", c_wdata);
    if (c_en && c_we && c_addr == ADDR_WDOG_THRESH) $fdisplay(fh_c, "%0d,WDOG,%08h", cyc, c_wdata);
    cyc <= cyc + 1;
  end

  logic [31:0] words [0:2*PM_NC + 8]; longint unsigned snap_cmd_cyc, last_cmd_cyc;
  task automatic csr_cmd(input [CSR_AW-1:0] a, input [31:0] d);
    @(negedge clk); drive_random(); c_en = 1; c_we = 1; c_addr = a; c_wdata = d; last_cmd_cyc = cyc;
    @(negedge clk); drive_random(); c_en = 0; c_we = 0;
  endtask
  task automatic snapshot(input bit clr);
    integer n, k; logic [CSR_AW-1:0] al [0:2*PM_NC + 8];
    csr_cmd(ADDR_CTRL, clr ? 32'h201 : 32'h101);
    snap_cmd_cyc = last_cmd_cyc;           // posedge that executed the command (== cmds.csv)
    n = 0; al[n++] = ADDR_SNAP_SEQ; al[n++] = ADDR_FLAGS; al[n++] = ADDR_OVF_BASE; al[n++] = ADDR_OVF_BASE + 1;
    for (k = 0; k < PM_NC; k++) begin al[n++] = ADDR_CNT_BASE + 2*k; al[n++] = ADDR_CNT_BASE + 2*k + 1; end
    al[n++] = ADDR_SNAP_SEQ;
    for (k = 0; k <= n; k++) begin
      @(negedge clk); drive_random();
      if (k > 0) words[k-1] = c_rdata;
      if (k < n) begin c_en = 1; c_we = 0; c_addr = al[k]; end else c_en = 0;
    end
    $fwrite(fh_s, "%0d,%0d,%0d,%0d,%h,%h,%h", words[0], words[n-1], snap_cmd_cyc, clr ? 1 : 0, words[1], words[2], words[3]);
    for (k = 0; k < PM_NC; k++) $fwrite(fh_s, ",%0d", {words[4 + 2*k + 1], words[4 + 2*k]});
    $fwrite(fh_s, "\n");
  endtask

  initial begin
    if (!$value$plusargs("OUT=%s", outd)) outd = ".";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    if (!$value$plusargs("CYCLES=%d", ncyc)) ncyc = 12000;
    void'($urandom(seed));
    fh_t = $fopen({outd, "/trace.csv"}, "w"); fh_c = $fopen({outd, "/cmds.csv"}, "w"); fh_s = $fopen({outd, "/snapshots.csv"}, "w");
    $fdisplay(fh_t, "cycle,en,is_valid,is_opcode,id_stall,load_use,sync_stall,flush,br_taken,ex_valid,ex_opcode,wb_valid,sched_valid,sched_ready,tok_valid,tgt_tile,tile_busy,tile_done,tile_state,vec_issue,lane_active,tensor_busy,mem_fire,mem_blocked,mem_resp,mem_align,noc_occ,noc_inj_fire,noc_inj_blocked");
    $fdisplay(fh_c, "cycle,name,value_hex");
    begin : hdr
      string h; h = "seq,seq_after,cmd_cycle,is_window,flags,ovf0,ovf1";
      $fdisplay(fh_s, "%s,CYCLES,SLOT_ISSUE,SLOT_STALL_DEP,SLOT_STALL_SYNC,SLOT_STALL_EXEC_VEC,SLOT_STALL_EXEC_TENSOR,SLOT_STALL_MEM,SLOT_STALL_DISP_OTHER,SLOT_BUBBLE_CTRL,SLOT_BUBBLE_FRONT,SLOT_IDLE,ISS_NOP,ISS_SALU,ISS_SMEM,ISS_BRANCH,ISS_DFMEM,ISS_DFCTL,ISS_VEC,ISS_TENSOR,RET_SCALAR,RET_TILE,TOK_DISPATCHED,DROP_SYNC,DROP_OP,BRANCH_TAKEN,TILE_TOK_0,TILE_TOK_1,TILE_TOK_2,TILE_TOK_3,TILE_BUSY_0,TILE_BUSY_1,TILE_BUSY_2,TILE_BUSY_3,VEC_ISSUES,VEC_LANES_ACTIVE,VEC_ISSUES_PARTIAL,VEC_BUSY_CYC,TENSOR_BUSY_CYC,MEM_REQ_ACCEPTED,MEM_RESP,MEM_REQ_BLOCKED,MEM_ALIGN_ERR,MEM_OUT_SUM,MEM_BUSY_CYC,MEM_OUT_PEAK,MEM_OUT_NOW,Q_DISP_SUM,Q_DISP_NOW,Q_TOK_SUM,Q_TOK_PEAK,Q_TOK_NOW,Q_NOC_SUM,Q_NOC_PEAK,Q_NOC_NOW,NOC_FLITS,NOC_INJ_BLOCKED,STALL_STREAK_MAX", h);
    end
    is_valid = 0; is_opcode = 0; id_stall = 0; load_use = 0; sync_stall = 0; flush = 0; br_taken = 0; ex_valid = 0; ex_opcode = 0; wb_valid = 0;
    sched_valid = 0; sched_ready = 1; tok_valid = 0; tgt_tile = 0; tile_busy = 0; tile_done = 0; tile_state = 0; vec_issue = 0; lane_active = 0;
    tensor_busy = 0; mem_fire = 0; mem_blocked = 0; mem_resp = 0; mem_align = 0; noc_occ = 0; noc_inj_fire = 0; noc_inj_blocked = 0;
    repeat (3) @(negedge clk); rst_n = 1; cyc = 0;
    csr_cmd(ADDR_CTRL, 32'h401);   // CLEAR + (ENABLE bit set)
    csr_cmd(ADDR_CTRL, 32'h1);
    for (int step = 0; cyc < ncyc; step++) begin
      set_mode($urandom_range(5));
      if (cyc > (ncyc * 7) / 10) allow_halt = 1;
      repeat ($urandom_range(40, 160)) begin @(negedge clk); drive_random(); end
      p_noise = pr(15) ? 6 : 0;
      case ($urandom_range(17))
        0, 1, 2: snapshot(1'b0);
        3, 4, 5: snapshot(1'b1);
        6: begin csr_cmd(ADDR_CTRL, 32'h401); end                      // CLEAR (ENABLE stays 1)
        7: begin csr_cmd(ADDR_CTRL, 32'h0); repeat ($urandom_range(5, 30)) begin @(negedge clk); drive_random(); end csr_cmd(ADDR_CTRL, 32'h1); end
        8: csr_cmd(ADDR_WDOG_THRESH, $urandom_range(10, 60));
        9: csr_cmd(ADDR_WDOG_THRESH, 0);
        10: begin                                                      // quiet phase: no progress -> watchdog trips if armed
          csr_cmd(ADDR_WDOG_THRESH, $urandom_range(8, 40)); quiet_mode = 1;
          repeat ($urandom_range(60, 120)) begin @(negedge clk); drive_random(); end
          quiet_mode = 0; snapshot(1'b0);
        end
        11: begin                                                      // SNAPSHOT / SNAP_CLR while counting is disabled
          csr_cmd(ADDR_CTRL, 32'h0); repeat (4) begin @(negedge clk); drive_random(); end
          snapshot(1'b0);                                              // writes 0x101: re-enables as a side effect of the command value
          csr_cmd(ADDR_CTRL, 32'h0); repeat (4) begin @(negedge clk); drive_random(); end
          snapshot(1'b1);
        end
        12: begin csr_cmd(ADDR_CTRL, 32'h701); end                     // CLEAR | SNAP_CLR | SNAPSHOT | ENABLE: CLEAR wins
        13: begin csr_cmd(ADDR_CTRL, 32'h601); end                     // CLEAR | SNAP_CLR | ENABLE
        14: begin noread = 1; csr_cmd(ADDR_CTRL, 32'h301); noread = 0; repeat (3) begin @(negedge clk); drive_random(); end end   // SNAP_CLR | SNAPSHOT: SNAP_CLR wins (no read-back)
        default: ;
      endcase
    end
    snapshot(1'b0);
    repeat (4) @(negedge clk);
    $fclose(fh_t); $fclose(fh_c); $fclose(fh_s);
    $display("tb_pm_dump done: cycles=%0d", cyc); $finish;
  end
endmodule
