// =============================================================================
// sf_pm_sva -- concurrent assertions for sf_perfmon
//
// Instantiated inside sf_perfmon when SF_PM_SVA is defined (Verilator --assert,
// commercial simulators, formal).  Synthesis ignores it (guarded by `ifdef).
// Three groups:
//   [TAP]  protocol checks on the integration: the core must feed consistent taps
//   [SPEC] normative behaviours of the monitor itself (docs/ARCHITECTURE.md)
//   [PASS] passivity / no-X
// A failing [TAP] assertion means the taps were wired wrongly or the core changed;
// a failing [SPEC] assertion is a monitor bug.
// =============================================================================
module sf_pm_sva
  import sf_pm_pkg::*;
#(
  parameter int NT = 4,
  parameter int CW = 40
) (
  input logic                  clk,
  input logic                  rst_n,
  // taps
  input logic                  id_stall_i, load_use_i, sync_stall_i, sched_valid_i, sched_ready_i,
  input logic [NT-1:0]         tok_valid_i,
  // internal observation points
  input logic                  en_q,
  input logic                  cmd_clear, cmd_snapclr, snap_fire,
  input logic [PM_SLOT_N-1:0] slot,
  input logic [PM_CLASS_N-1:0] cls_ev,                 // per-class event bits (issue && class)
  input logic [PM_NC*CW-1:0]   live_q,
  input logic [PM_NC-1:0]      live_ovf,
  input logic [PM_NC*CW-1:0]   snap_q,
  input logic [31:0]           snap_seq_q,
  input logic                  prog_done_q,
  input logic                  csr_en_i, csr_we_i,
  input logic                  csr_rvalid_o,
  input logic [31:0]           csr_rdata_o,
  input logic                  irq_o
);
  // Testbench backdoor: a test that deposits values directly into counters (to reach 2^32 / 2^CW quickly)
  // sets this to 1 for the duration, because the deposit is not a physically reachable transition.
  logic tb_sva_off = 1'b0;
  // NOTE: clock and reset-disable are explicit in every property (Verilator 5.020 lacks `default disable iff`).

  // ---------------------------------------------------------------- [TAP]
  // Every stall slot has an identifiable cause (otherwise SLOT_STALL_DISP_OTHER silently absorbs it).
  ap_tap_stall_has_cause: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) id_stall_i |-> (sync_stall_i || load_use_i || (sched_valid_i && !sched_ready_i)))
    else $error("[TAP] id_stall without a known cause (sync/load-use/dispatch-blocked)");
  // A dispatched token requires the scheduler to be presenting an op that the control core sees as accepted.
  ap_tap_tok_needs_sched: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) (|tok_valid_i) |-> (sched_valid_i && sched_ready_i))
    else $error("[TAP] token dispatched while scheduler handshake was not complete");
  ap_tap_tok_onehot0: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) $onehot0(tok_valid_i))
    else $error("[TAP] more than one tile accepted a token in one cycle");

  // ---------------------------------------------------------------- [SPEC] exclusivity / partition
  ap_slot_onehot: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) $onehot(slot))
    else $error("[SPEC] issue-slot classification is not exactly one-hot");
  ap_class_onehot0: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) $onehot0(cls_ev))
    else $error("[SPEC] issue class not one-hot0");
  ap_class_iff_issue: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) (|cls_ev) == slot[S_ISSUE])
    else $error("[SPEC] issue-class event must fire exactly when a slot is issued");
  ap_post_halt_idle: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) prog_done_q |-> slot[S_IDLE])
    else $error("[SPEC] after HALT issued every slot must be IDLE");
  ap_prog_done_sticky: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) prog_done_q |=> prog_done_q)
    else $error("[SPEC] prog_done must be sticky until reset");

  // ---------------------------------------------------------------- [SPEC] counter semantics
  genvar gi;
  generate
    for (gi = 0; gi < PM_NC; gi++) begin : g_ctr
      localparam int KIND = int'(PM_KIND_V[2*gi +: 2]);
      wire          o = live_ovf[gi];
      if (KIND != KIND_GAUGE) begin : g_mono
        ap_monotonic: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) !cmd_clear && !cmd_snapclr |=> (live_q[gi*CW +: CW] >= $past(live_q[gi*CW +: CW])))
          else $error("[SPEC] counter %0d decreased without CLEAR/SNAP_CLR", gi);
      end
      ap_ovf_sticky: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) o && !cmd_clear && !cmd_snapclr |=> live_ovf[gi])
        else $error("[SPEC] overflow bit %0d not sticky", gi);
      if (KIND == KIND_ACC) begin : g_sat
        // saturating: once all ones the value never changes until clear/restart
        ap_saturate: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) (&live_q[gi*CW +: CW]) && !cmd_clear && !cmd_snapclr |=> (&live_q[gi*CW +: CW]))
          else $error("[SPEC] saturated counter %0d moved", gi);
      end else begin : g_noovf
        ap_no_ovf_peak_gauge: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) !live_ovf[gi])
          else $error("[SPEC] peak/gauge counter %0d flagged overflow", gi);
      end
    end
  endgenerate

  // CYCLES advances by exactly one per enabled cycle (unless saturated / commanded)
  ap_cycles_step: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) en_q && !cmd_clear && !cmd_snapclr && !live_ovf[CNT_CYCLES] && !(&live_q[CNT_CYCLES*CW +: CW])
                                   |=> live_q[CNT_CYCLES*CW +: CW] == $past(live_q[CNT_CYCLES*CW +: CW]) + 1'b1)
    else $error("[SPEC] CYCLES did not advance by exactly 1");
  ap_disabled_holds: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) !en_q && !cmd_clear && !cmd_snapclr |=> live_q == $past(live_q))
    else $error("[SPEC] counters changed while disabled");

  // ---------------------------------------------------------------- [SPEC] snapshot coherence
  function automatic logic [CW+7:0] slot_sum(input logic [PM_NC*CW-1:0] v);
    logic [CW+7:0] s; s = '0;
    for (int i = 0; i < PM_SLOT_N; i++) s += (CW+8)'(v[(PM_SLOT_FIRST+i)*CW +: CW]);
    return s;
  endfunction
  function automatic logic [CW+7:0] cls_sum(input logic [PM_NC*CW-1:0] v);
    logic [CW+7:0] s; s = '0;
    for (int i = 0; i < PM_CLASS_N; i++) s += (CW+8)'(v[(PM_CLASS_FIRST+i)*CW +: CW]);
    return s;
  endfunction

  // I1/I2 in every captured snapshot (only meaningful if no counter saturated: I6)
  ap_snapshot_I1: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) (snap_fire && !cmd_clear && !(|live_ovf)) |=> slot_sum(snap_q) == {8'd0, snap_q[CNT_CYCLES*CW +: CW]})
    else $error("[SPEC] I1 violated in snapshot: sum(SLOT_*) != CYCLES");
  ap_snapshot_I2: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) (snap_fire && !cmd_clear && !(|live_ovf)) |=> cls_sum(snap_q) == {8'd0, snap_q[CNT_SLOT_ISSUE*CW +: CW]})
    else $error("[SPEC] I2 violated in snapshot: sum(ISS_*) != SLOT_ISSUE");
  // The same invariants hold on the LIVE counters at every cycle (counted events are atomic per cycle)
  ap_live_I1: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) !(|live_ovf) |-> slot_sum(live_q) == {8'd0, live_q[CNT_CYCLES*CW +: CW]})
    else $error("[SPEC] I1 violated on live counters");
  ap_live_I2: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) !(|live_ovf) |-> cls_sum(live_q) == {8'd0, live_q[CNT_SLOT_ISSUE*CW +: CW]})
    else $error("[SPEC] I2 violated on live counters");

  ap_shadow_stable: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) !snap_fire && !cmd_clear |=> $stable(snap_q))
    else $error("[SPEC] shadow changed without a snapshot/clear command");
  ap_seq_step: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) (snap_fire || cmd_clear) |=> snap_seq_q == $past(snap_seq_q) + 32'd1)
    else $error("[SPEC] SNAP_SEQ must increment by exactly one per command");
  ap_seq_stable: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) !snap_fire && !cmd_clear |=> $stable(snap_seq_q))
    else $error("[SPEC] SNAP_SEQ changed without a command");
  ap_snapshot_value: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) (snap_fire && !cmd_clear) |=> snap_q == $past(live_q))
    else $error("[SPEC] snapshot must equal the live counters at the start of the command cycle");

  // ---------------------------------------------------------------- [SPEC] CSR protocol
  ap_rvalid_follows: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) (csr_en_i && !csr_we_i) |=> csr_rvalid_o)
    else $error("[SPEC] rvalid must follow a read by exactly one cycle");
  ap_rvalid_only_after_read: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) !(csr_en_i && !csr_we_i) |=> !csr_rvalid_o)
    else $error("[SPEC] spurious rvalid");

  // ---------------------------------------------------------------- [PASS] no-X
  ap_no_x_out: assert property (@(posedge clk) disable iff (!rst_n || tb_sva_off) !$isunknown({csr_rvalid_o, csr_rdata_o, irq_o}))
    else $error("[PASS] X on monitor outputs");
endmodule
