import unittest
from sfperf import isa

class TestIsa(unittest.TestCase):
    def test_encodings_match_decoder_fields(self):
        # R: op[31:27] rd[26:22] rs1[21:17] rs2[16:12]
        self.assertEqual(isa.R("ADD", 3, 1, 2), (1 << 27) | (3 << 22) | (1 << 17) | (2 << 12))
        # I: imm17 is masked, sign handled by two's complement
        self.assertEqual(isa.I("MOV", 5, 0, -1), (6 << 27) | (5 << 22) | 0x1FFFF)
        # D: tile[26:24] reg[23:19] len[18:14] addr[13:0]
        self.assertEqual(isa.D("DFLOAD", 2, 1, 31, 7), (0xA << 27) | (2 << 24) | (1 << 19) | (31 << 14) | 7)
        # V: vrd[26:23] vrs1[22:19] vrs2[18:15] func[7:0]
        self.assertEqual(isa.V("MATMUL", 3, 1, 2), (0x13 << 27) | (3 << 23) | (1 << 19) | (2 << 15))

    def test_halt_and_decode(self):
        p = isa.Prog().halt()
        self.assertEqual(p.assemble()[0] >> 27, 0x1F)
        self.assertEqual(isa.decode(isa.R("MUL", 1, 2, 3)), "MUL")

    def test_branch_offsets(self):
        p = isa.Prog()
        p.label("top"); p.nop(2); p.branch("BNE", 1, "top"); p.branch("BEQ", 1, "end"); p.nop(1); p.label("end"); p.halt()
        w = p.assemble()
        self.assertEqual(w[2] & 0x1FFFF, (-2) & 0x1FFFF)        # backward by 2 from pc 2 to pc 0
        self.assertEqual(w[3] & 0x1FFFF, 2)                     # forward from pc 3 to pc 5

if __name__ == "__main__": unittest.main()
