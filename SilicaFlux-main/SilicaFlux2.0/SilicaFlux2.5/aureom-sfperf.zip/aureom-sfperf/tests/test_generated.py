import pathlib, unittest, importlib.util, json
ROOT = pathlib.Path(__file__).resolve().parent.parent

def _gen():
    spec = importlib.util.spec_from_file_location("gen_pm", ROOT / "scripts" / "gen_pm.py")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

class TestGenerated(unittest.TestCase):
    def test_idx_header_in_sync(self):
        g = _gen()
        self.assertEqual((ROOT / "rtl/perfmon/sf_pm_idx.svh").read_text(), g.svh(), "run scripts/gen_pm.py")
    def test_regmap_in_sync(self):
        g = _gen()
        self.assertEqual((ROOT / "docs/REGMAP.md").read_text(), g.md(), "run scripts/gen_pm.py")
    def test_spec_consistency(self):
        s = json.load(open(ROOT / "spec/pm_counters.json"))
        names = [c["name"] for c in s["counters"]]
        self.assertEqual(len(names), len(set(names)))
        for c in s["counters"]: self.assertIn(c["kind"], ("count", "sum", "peak", "gauge"))
        slots = [c for c in s["counters"] if c.get("exclusive_set") == "slot"]
        self.assertEqual(len(slots), 10)
    def test_python_and_rtl_agree_on_counter_order(self):
        from sfperf import spec
        txt = (ROOT / "rtl/perfmon/sf_pm_idx.svh").read_text()
        for i, n in enumerate(spec.NAMES): self.assertIn(f"CNT_{n} = {i};", txt)

if __name__ == "__main__": unittest.main()
