import unittest
from sfperf import workloads, isa

class TestWorkloads(unittest.TestCase):
    def test_all_assemble_and_end_in_halt(self):
        for w in workloads.all_workloads():
            words = w.words()
            self.assertTrue(len(words) < 1000, w.name)                       # fits the 1024-word IMEM with room to spare
            self.assertEqual(words[-1] >> 27, 0x1F, w.name)                  # HALT terminates every program
            for x in words: self.assertEqual(x >> 32, 0)
    def test_names_unique(self):
        names = [w.name for w in workloads.all_workloads()]
        self.assertEqual(len(names), len(set(names)))
    def test_expectations_reference_real_counters(self):
        from sfperf import spec
        for w in workloads.all_workloads():
            for cfg, e in w.expect.items():
                for k in e: self.assertIn(k, spec.INDEX, f"{w.name}/{cfg}/{k}")
    def test_branch_sweep_taken_count_matches_probability(self):
        w = workloads.div_branch_sweep(0.25, sites=48)
        self.assertEqual(w.expect["supplied"]["BRANCH_TAKEN"], 12)
        # every BEQ target is forward and inside the program
        words = w.words()
        for i, x in enumerate(words):
            if (x >> 27) == isa.OP["BEQ"]:
                off = x & 0x1FFFF; self.assertTrue(0 < off < 40); self.assertLess(i + off, len(words))

if __name__ == "__main__": unittest.main()
