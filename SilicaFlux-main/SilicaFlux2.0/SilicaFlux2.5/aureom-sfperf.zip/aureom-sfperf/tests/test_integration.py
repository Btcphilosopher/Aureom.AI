"""Runs real simulations (needs iverilog; builds the simulators on first use)."""
import filecmp, pathlib, shutil, unittest, tempfile
from sfperf import run, snapshot, workloads, report

ROOT = pathlib.Path(__file__).resolve().parent.parent
HAVE = shutil.which("iverilog") and shutil.which("vvp") and shutil.which("patch")

@unittest.skipUnless(HAVE, "iverilog/vvp/patch not available")
class TestSim(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        run.build(); cls.tmp = tempfile.mkdtemp()
    @classmethod
    def tearDownClass(cls): shutil.rmtree(cls.tmp, ignore_errors=True)

    def _check(self, wl, cfg):
        r = run.run_workload(wl, cfg, self.tmp)
        d = pathlib.Path(self.tmp) / cfg / wl.name
        self.assertTrue(r["arch_identical"], f"{wl.name}/{cfg}: architectural trace differs")
        self.assertTrue(r["cycle_exact"], f"{wl.name}/{cfg}: cycle count/fingerprint differs")
        self.assertEqual(r["model_mismatches"], 0)
        snaps = snapshot.load(d / "pm" / "snapshots.csv"); t = snapshot.totals(snaps)
        self.assertTrue(all(s.coherent for s in snaps))
        self.assertEqual(snapshot.check_invariants(t, snaps[-1].ovf), [])
        for k, s in wl.expect.get(cfg, {}).items():
            self.assertTrue(report.meets(s, t[k]), f"{wl.name}/{cfg}: {k}={t[k]} expected {report.fmt_spec(s)}")

    def test_compute_alu(self):
        for cfg in ("supplied", "fixed"): self._check(workloads.compute_alu(64), cfg)
    def test_load_use_hang_on_supplied_and_fix_on_fixed(self):
        w = workloads.dep_load_use(8); w.maxc = 600
        for cfg in ("supplied", "fixed"): self._check(w, cfg)
    def test_dispatch_drop_exposed_and_fixed(self):
        for cfg in ("supplied", "fixed"): self._check(workloads.compute_tensor_queue(4), cfg)
    def test_branch_divergence(self):
        for cfg in ("supplied", "fixed"): self._check(workloads.div_branch_sweep(0.5, sites=16), cfg)

if __name__ == "__main__": unittest.main()
