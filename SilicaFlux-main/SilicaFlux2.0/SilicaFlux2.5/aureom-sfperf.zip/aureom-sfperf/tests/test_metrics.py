import unittest
from sfperf import spec, metrics, bottleneck, snapshot

def zero(): return {n: 0 for n in spec.NAMES}

def totals(**kw):
    t = zero(); t.update(kw)
    t["CYCLES"] = sum(t[n] for n in spec.SLOT_NAMES)
    return t

class TestMetrics(unittest.TestCase):
    def test_ipc_excludes_idle(self):
        t = totals(SLOT_ISSUE=80, SLOT_STALL_DEP=20, SLOT_IDLE=100, ISS_SALU=80)
        d = metrics.derive(t)
        self.assertAlmostEqual(d["ipc"], 0.8); self.assertEqual(d["active"], 100)
        self.assertAlmostEqual(d["frac_Dependency (RAW)"], 0.2)

    def test_invariants(self):
        t = totals(SLOT_ISSUE=5, SLOT_STALL_MEM=3, ISS_SALU=5)
        self.assertEqual(snapshot.check_invariants(t), [])
        t["ISS_SALU"] = 4
        self.assertTrue(snapshot.check_invariants(t))

    def test_i5_is_strict_for_an_epoch_but_allows_window_straddle(self):
        t = totals(SLOT_ISSUE=5, ISS_DFMEM=5, MEM_REQ_ACCEPTED=3, MEM_RESP=5)       # 2 responses to requests of an earlier window
        self.assertTrue(snapshot.check_invariants(t))                                # whole epoch: impossible
        self.assertEqual(snapshot.check_invariants(t, windowed=True), [])            # one SNAP_CLR window: fine (<= 5 may straddle)
        t["MEM_RESP"] = 9
        self.assertTrue(snapshot.check_invariants(t, windowed=True))                 # more than one per controller: still a violation


class TestBottleneck(unittest.TestCase):
    def cls(self, **kw): return bottleneck.classify(totals(**kw))
    def test_issue_bound(self):
        p, *_ = self.cls(SLOT_ISSUE=100, ISS_SALU=100, RET_SCALAR=100)
        self.assertEqual((p.family, "issue-bound" in p.label), ("compute", True))
    def test_dependency(self):
        p, *_ = self.cls(SLOT_ISSUE=80, SLOT_STALL_DEP=20, ISS_SALU=80)
        self.assertEqual(p.family, "dependency")
    def test_divergence(self):
        p, *_ = self.cls(SLOT_ISSUE=70, SLOT_BUBBLE_CTRL=30, ISS_SALU=70, BRANCH_TAKEN=10)
        self.assertEqual(p.family, "divergence")
    def test_memory_stall(self):
        p, *_ = self.cls(SLOT_ISSUE=10, SLOT_STALL_MEM=90, ISS_DFMEM=10)
        self.assertEqual(p.family, "memory")
    def test_barrier_attribution_to_tensor(self):
        p, *_ = self.cls(SLOT_ISSUE=10, SLOT_STALL_SYNC=90, ISS_TENSOR=10, TENSOR_BUSY_CYC=88)
        self.assertEqual(p.family, "compute"); self.assertIn("tensor", p.label)
    def test_barrier_attribution_to_memory(self):
        p, *_ = self.cls(SLOT_ISSUE=10, SLOT_STALL_SYNC=90, ISS_DFMEM=10, MEM_BUSY_CYC=85)
        self.assertEqual(p.family, "memory")
    def test_barrier_unattributed_is_dependency(self):
        p, *_ = self.cls(SLOT_ISSUE=10, SLOT_STALL_SYNC=90, ISS_DFCTL=10)
        self.assertEqual(p.family, "dependency")
    def test_hang_is_flagged(self):
        _, _, defects, _ = self.cls(SLOT_ISSUE=5, SLOT_STALL_DEP=995, ISS_SALU=5, STALL_STREAK_MAX=995)
        self.assertTrue(any("HANG" in d.label for d in defects))
    def test_lost_ops_flagged(self):
        _, _, defects, _ = self.cls(SLOT_ISSUE=10, SLOT_STALL_EXEC_TENSOR=50, ISS_TENSOR=10, DROP_OP=3)
        self.assertTrue(any("LOST OPS" in d.label for d in defects))
    def test_small_stalls_below_significance_are_ignored(self):
        p, *_ = self.cls(SLOT_ISSUE=97, SLOT_STALL_DEP=3, ISS_SALU=97)
        self.assertIn("issue-bound", p.label)

if __name__ == "__main__": unittest.main()
