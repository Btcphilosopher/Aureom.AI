# Aureom.AI SilicaFlux -- performance-monitoring subsystem and stall-analysis tool

`sf_perfmon` is a passive, synthesizable SystemVerilog monitor that tells you **why the SilicaFlux execution core did not issue
an instruction this cycle**, with 57 counters read coherently through a small CSR interface. `sfperf` is the Python tool that
decodes the snapshots, attributes the bottleneck, runs workloads that isolate each bottleneck, and draws the charts.

The RTL that was supplied (`SilicaFlux-main/silicaflux.zip`) is a **single-issue in-order scalar pipeline that dispatches vector,
tensor and memory work to four compute tiles**. It is not a SIMT GPU core (no warps, no lane masks) and it has a number of
functional defects (`docs/BASELINE_FINDINGS.md`). The monitor measures that core exactly as supplied.

**Nothing was committed to git.** This archive is the deliverable.

## What is in the box

| You asked for | Where |
|---|---|
| Inspect the supplied RTL; document issue / execution / memory / retirement interfaces | `docs/INTERFACES.md` (file:line references, measured latencies) |
| Instructions issued/retired, active lanes, dependency stalls, unit contention, memory backpressure, barrier waits, idle cycles, outstanding memory requests, queue occupancy | 57 counters: `docs/METRICS.md` (meaning of every one), `docs/REGMAP.md` |
| Mutually exclusive stall categories; overlapping counters kept separate | 10 exclusive issue-slot categories + 8 exclusive issue classes; everything else separate (`METRICS.md` A.1/A.2) |
| Overflow, reset, snapshot, read consistency specified | `docs/ARCHITECTURE.md` section 4 (normative) |
| Synthesizable counters, coherent software-readable snapshot | `rtl/perfmon/` (atomic shadow snapshot, `SNAP_SEQ`, `SNAP_CLR` windows) |
| Workloads isolating compute / memory / dependency / divergence | `sfperf/workloads.py`: 18 workloads, each with declared expected counter values |
| Results exported to Python charts | `results/charts/*.png` + `.csv`, `results/REPORT.md` |
| RTL, tests, assertions, integration, metric explanations | `rtl/`, `tb/` + `tests/`, `sva/`, `docs/INTEGRATION.md`, `docs/METRICS.md` |
| Instrumented vs uninstrumented architectural outputs | `results/REPORT.md` section 6, `docs/VERIFICATION.md` section 4 |
| Instrumentation overhead where tools permit; never invent results | `docs/OVERHEAD.md` (synthesis proxies, simulation wall-clock); **no timing/area/power numbers exist because no such tool was available** |

## Quick start

```bash
# needs: iverilog >= 12, python3 (+ matplotlib, numpy for charts), patch.  Optional: verilator >= 5.020, yosys.
make unit            # stand-alone monitor testbench against the reference model   (about 1.5 min, 86 checks)
make results         # all workloads x {supplied, fixed} x {instrumented, uninstrumented} (about 1.5 min)
make report charts   # results/REPORT.md and results/charts/
python3 -m sfperf analyze results/supplied/mem_burst_parallel
make sva             # same unit testbench under Verilator with every SVA assertion
make test            # generated files + patches + unit + python tests + results + random dump + independent
                     # trace check + 8-seed fuzz.  NOT included (slow / need extra tools): make sva, make mutation
                     # (about 17 min), make synth (tens of minutes; needs yowasp-yosys + native yosys), make simspeed
```
Timings are wall-clock on the 4-core machine used here. A clean extraction of this archive was verified: `make check-gen
check-patches unit`, the 28 Python tests, the independent checker on the shipped data, and a full `make results`, whose
output is **byte-identical** (288 files) to the `results/` shipped in the archive.

## Headline results (every figure read back from files in `results/`)

| Claim | Result |
|---|---|
| Instrumented and uninstrumented cores give **byte-identical architectural traces and cycle-exact fingerprints** | **36/36** runs on the workload suite; **20 random programs x 3 builds all identical** (`results/fuzz.txt`) |
| Monitor counters equal a behavioural reference model on **every counter, every cycle**, and in every snapshot read through the CSR path | 0 mismatches in 36 runs; unit testbench 86 checks pass (Icarus) and 86 under Verilator with all 25 SVA properties silent |
| An **independent** re-derivation written from the spec alone (never saw the RTL) reproduces all 57 counters | 44/44 run directories, 546 snapshots (system runs + 8 random-tap/command streams) |
| The verification suite catches seeded bugs | **25/25 non-equivalent RTL mutants killed** (1 further mutant proven equivalent: `results/mutation_report.md`) |
| Issued = retired + dropped, exactly (conservation identity I4) | exact in **36/36** runs |
| Each workload produces the counter values it was designed to produce | **195/195** hold (declared per workload in `sfperf/workloads.py`) |
| Overhead on the core | **0 cycles** (above). Synthesis proxies, memories excluded: monitor adds 4,179 flip-flops (+98.5%), 14,661 generic gates (+108.1%), 6,482 LUT6 (+142.9%); no change in logic depth (15 -> 15 LUT6 levels). Taps alone (monitor removed): +0 FF, +17 gates (+0.1%), +1 LUT6. Size is linear in counter width (`CW` 32: 3,535 FF standalone vs 4,343 at 40). **Not measured: silicon area, power, timing.** |

Bottleneck verdict per workload on the **supplied** RTL (the classifier is not told what the workload is; share = of active cycles):

| workload | designed to isolate | IPC | verdict from counters |
|---|---|---|---|
| `compute_alu` | compute | 1.00 | compute: issue-bound (single-issue scalar throughput) (100%) |
| `compute_tensor_sync` | compute | 0.03 | compute: barrier waiting on the tensor unit (execution-unit bound) (97%) |
| `compute_tensor_queue` | compute | 0.04 | compute: execution-unit contention (tensor unit) (96%) **+ LOST OPS** |
| `compute_vector_queue` | compute | 0.52 | compute: execution-unit contention (vector engine) (48%) **+ LOST OPS** |
| `mem_burst_serial` | memory | 0.06 | memory: barrier waiting on memory transactions (memory-latency bound) (94%) |
| `mem_burst_parallel` | memory | 0.14 | memory: barrier waiting on memory transactions (memory-latency bound) (86%) |
| `mem_conflict_queue` | memory | 0.07 | memory: memory backpressure / latency (tile occupied by a transaction) (93%) **+ LOST OPS** |
| `mem_scalar_backtoback` | memory | 1.00 | compute: issue-bound (single-issue scalar throughput) (100%) **+ LOST MEMORY REQUESTS** |
| `dep_load_use` | dependency | 0.00 | dependency: RAW (load-use) interlock stalls (100%) **+ HANG; LOST MEMORY REQUESTS** |
| `dep_sync_chain` | dependency | 0.17 | memory: barrier waiting on memory transactions (memory-latency bound) (83%) |
| `dep_alu_chain` | dependency | 1.00 | compute: issue-bound (single-issue scalar throughput) (100%) |
| `div_branch_p000` | divergence | 1.00 | compute: issue-bound (single-issue scalar throughput) (100%) |
| `div_branch_p025` | divergence | 0.91 | divergence: control-flow bubbles from taken branches (9%) |
| `div_branch_p050` | divergence | 0.82 | divergence: control-flow bubbles from taken branches (18%) |
| `div_branch_p075` | divergence | 0.74 | divergence: control-flow bubbles from taken branches (26%) |
| `div_branch_p100` | divergence | 0.67 | divergence: control-flow bubbles from taken branches (33%) |
| `div_loop_taken` | divergence | 0.71 | divergence: control-flow bubbles from taken branches (29%) |
| `mixed_kernel` | mixed | 0.38 | compute: barrier waiting on the tensor unit (execution-unit bound) (56%) |

Reading the table: `dep_sync_chain` is *designed* as a barrier-dependency test (DFLOAD, DFSYNC, VADD, DFSYNC) and the classifier
attributes its barrier waits to the memory operations the barrier is waiting for -- a barrier is where a dependency is
*expressed*, not its cause. The two `LOST` flags are not performance findings but defects the monitor detects (F2, F12), and
`dep_load_use` on the supplied RTL is a hang (F1; run to the 1,500-cycle limit). The fixed-config verdicts are in
`results/REPORT.md` section 2.

Selected measurements (supplied RTL unless noted), all computed from the counters: a taken branch costs **3.00 issue slots** (flush + redirect shadow; 48 branches all taken lose 33% of slots, IPC 0.67); a 31-word scratchpad DFLOAD has a Little's-law latency of **33 cycles**; four tiles in parallel reach **3.43 average / 4 peak outstanding requests** and **3.8x** the load throughput of one tile (cycles per DFLOAD 36.1 vs 9.6); a `MATMUL` keeps the tensor unit busy **66 cycles**; with fix F1 (fixed config), 32 load-use pairs cost **32** dependency slots.

## What the supplied RTL turned out to do (`docs/BASELINE_FINDINGS.md`)

* **F1** Load-use interlock livelocks (the only RAW stall mechanism hangs the machine; measured by workload `dep_load_use`)
* **F2** A dispatch that has to wait is silently dropped (measured by `compute_tensor_queue`, `compute_vector_queue`, `mem_conflict_queue`)
* **F3** V-format instructions carry no tile id: all vector/tensor ops run on tile 0
* **F4** DFEXEC/DFMAP never complete: the tile stays busy and the next barrier hangs
* **F5** Wrong-path instructions commit after a taken branch
* **F6** A stalled EX instruction is replayed into write-back every stall cycle
* **F7** `halt` is raised when HALT is fetched; the pipeline and tiles keep running
* **F8** Tile results are never written to scalar or vector registers
* **F9** compute_tile.sv:226 selects bits [2:0] of a 2-bit field (rejected by yosys-slang)
* **F10** Distance-1 RAW dependences read a stale operand (no forwarding, no interlock)
* **F11** Scalar LOAD returns the address instead of the data; STORE writes zero (I-format has no source register)
* **F12** Scalar memory requests ignore `ready`: a request issued during a busy cycle is lost

All 12 are reproduced by programs in `sfperf/findings.py` and the workload suite; evidence in `results/findings/findings.json` and `docs/BASELINE_FINDINGS.md`.

The two optional patches (`patches/optional/`) fix F1 and F2 *only* so that the dependency and contention bottlenecks can be
measured instead of hanging or losing work. The default is the RTL as supplied.

## Limits, stated plainly

* **No SIMT divergence on this core.** `VEC_ISSUES_PARTIAL` is structurally 0 here because the core has no lane masks. The lane
  counters are verified with synthetic masks; control-flow divergence (3 slots lost per taken branch) is what is measured.
* **Overhead numbers are proxies.** Synthesis results are Yosys generic-gate / LUT6 counts and path lengths, not area, power or
  timing. Absolute values depend on ABC; use ratios between variants run through the same flow. The core's memories are excluded.
* **Not verified:** gate-level behaviour, formal properties, FPGA/ASIC timing, any core other than the supplied one, `NT != 4`.
* **Retirement is defined, not observed:** the core has no commit stage. `METRICS.md` A.3 states the definition and the
  monitor reports the conservation gap instead of assuming it is zero.
* The `fixed` configuration is not a repaired core; ten of its twelve known defects remain.

## Layout

```
rtl/supplied/        the supplied RTL, untouched (sha256 in rtl/SUPPLIED.sha256)
rtl/perfmon/         sf_perfmon: sf_pm_events (core adapter), sf_pm_regs (counters/snapshot/CSR), sf_pm_counter, sf_pm_pkg
patches/             0001 passive taps + instance (additive); optional/ 0002 + 0003 bug fixes F1 / F2
sva/                 25 SVA properties          tb/  unit TB, reference model, system TB, random-trace dump TB
sfperf/              isa, workloads, run, snapshot, metrics, bottleneck, charts, report, trace_check (independent), fuzz, findings
spec/pm_counters.json  single source of truth -> rtl/perfmon/sf_pm_idx.svh and docs/REGMAP.md (scripts/gen_pm.py)
scripts/             build_variant, build_sim, synth_stat / synth_overhead, mutation_test, make_patches, package
results/             REPORT.md, summary.csv/json, charts/, findings/, mutation_report.md, simspeed.json, fuzz.txt, trace_check.txt,
                     synthesis/ (Yosys summaries), random_dump/ (8 random tap+command traces), supplied/ and fixed/ (every run:
                     program, instrumented and uninstrumented outputs, snapshots, per-cycle trace)
docs/                INTERFACES, METRICS, ARCHITECTURE, REGMAP, INTEGRATION, ANALYSIS, VERIFICATION, BASELINE_FINDINGS, OVERHEAD
```
