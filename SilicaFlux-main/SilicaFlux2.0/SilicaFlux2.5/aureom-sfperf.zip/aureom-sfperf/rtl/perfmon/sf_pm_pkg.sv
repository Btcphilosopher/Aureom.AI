// =============================================================================
// sf_pm_pkg.sv -- SilicaFlux performance-monitor shared definitions
//
// Counter indices (CNT_*), PM_NC and the per-counter kind vector come from the
// generated header sf_pm_idx.svh (spec/pm_counters.json is the single source).
// =============================================================================
`ifndef SF_PM_PKG_SV
`define SF_PM_PKG_SV

package sf_pm_pkg;

  `include "sf_pm_idx.svh"

  // Counter kinds (encoded in PM_KIND_V, 2 bits per counter)
  localparam int KIND_ACC   = 0;   // saturating accumulate (+0/+1 events and small sums)
  localparam int KIND_PEAK  = 1;   // running maximum
  localparam int KIND_GAUGE = 2;   // last sampled value

  localparam int PM_CW_DEFAULT = 40;

  // Read-only identification
  localparam logic [31:0] PM_ID_MAGIC = 32'h5346504D;   // "SFPM"
  localparam logic [31:0] PM_VERSION  = 32'h0001_0000;  // {8'h0, major, minor, patch} = 1.0.0

  // CSR word addresses
  localparam int CSR_AW           = 8;
  localparam logic [CSR_AW-1:0] ADDR_ID          = 8'h00;
  localparam logic [CSR_AW-1:0] ADDR_VERSION     = 8'h01;
  localparam logic [CSR_AW-1:0] ADDR_GEOM        = 8'h02;
  localparam logic [CSR_AW-1:0] ADDR_FEATURES    = 8'h03;
  localparam logic [CSR_AW-1:0] ADDR_CTRL        = 8'h04;
  localparam logic [CSR_AW-1:0] ADDR_STATUS      = 8'h05;
  localparam logic [CSR_AW-1:0] ADDR_SNAP_SEQ    = 8'h06;
  localparam logic [CSR_AW-1:0] ADDR_WDOG_THRESH = 8'h07;
  localparam logic [CSR_AW-1:0] ADDR_FLAGS       = 8'h08;
  localparam logic [CSR_AW-1:0] ADDR_OVF_BASE    = 8'h10;
  localparam logic [CSR_AW-1:0] ADDR_CNT_BASE    = 8'h20;

  // CTRL bits
  localparam int CTRL_ENABLE   = 0;
  localparam int CTRL_IRQ_EN   = 1;
  localparam int CTRL_SNAPSHOT = 8;    // write-1 command
  localparam int CTRL_SNAP_CLR = 9;    // write-1 command
  localparam int CTRL_CLEAR    = 10;   // write-1 command

  // Issue-slot one-hot positions (== counter index - PM_SLOT_FIRST)
  localparam int S_ISSUE      = CNT_SLOT_ISSUE            - PM_SLOT_FIRST;
  localparam int S_DEP        = CNT_SLOT_STALL_DEP        - PM_SLOT_FIRST;
  localparam int S_SYNC       = CNT_SLOT_STALL_SYNC       - PM_SLOT_FIRST;
  localparam int S_EXEC_VEC   = CNT_SLOT_STALL_EXEC_VEC   - PM_SLOT_FIRST;
  localparam int S_EXEC_TENS  = CNT_SLOT_STALL_EXEC_TENSOR- PM_SLOT_FIRST;
  localparam int S_MEM        = CNT_SLOT_STALL_MEM        - PM_SLOT_FIRST;
  localparam int S_DISP_OTHER = CNT_SLOT_STALL_DISP_OTHER - PM_SLOT_FIRST;
  localparam int S_BUB_CTRL   = CNT_SLOT_BUBBLE_CTRL      - PM_SLOT_FIRST;
  localparam int S_BUB_FRONT  = CNT_SLOT_BUBBLE_FRONT     - PM_SLOT_FIRST;
  localparam int S_IDLE       = CNT_SLOT_IDLE             - PM_SLOT_FIRST;

  // Issue-class one-hot positions (== counter index - PM_CLASS_FIRST)
  localparam int K_NOP    = CNT_ISS_NOP    - PM_CLASS_FIRST;
  localparam int K_SALU   = CNT_ISS_SALU   - PM_CLASS_FIRST;
  localparam int K_SMEM   = CNT_ISS_SMEM   - PM_CLASS_FIRST;
  localparam int K_BRANCH = CNT_ISS_BRANCH - PM_CLASS_FIRST;
  localparam int K_DFMEM  = CNT_ISS_DFMEM  - PM_CLASS_FIRST;
  localparam int K_DFCTL  = CNT_ISS_DFCTL  - PM_CLASS_FIRST;
  localparam int K_VEC    = CNT_ISS_VEC    - PM_CLASS_FIRST;
  localparam int K_TENSOR = CNT_ISS_TENSOR - PM_CLASS_FIRST;

  // Population count of up to 64 bits (synthesizable: constant loop bound)
  function automatic int unsigned popcnt(input logic [63:0] v);
    int unsigned n;
    n = 0;
    for (int i = 0; i < 64; i++) n = n + int'(v[i]);
    return n;
  endfunction

endpackage

`endif
