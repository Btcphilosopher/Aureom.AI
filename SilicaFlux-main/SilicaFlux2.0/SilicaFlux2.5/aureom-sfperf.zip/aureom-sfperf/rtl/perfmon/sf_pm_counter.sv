// =============================================================================
// sf_pm_counter -- one performance value (accumulator, peak tracker or gauge)
//
// Overflow policy (KIND_ACC): SATURATING.  The value sticks at 2^CW-1 and the
// sticky ovf_o bit is set iff at least one increment was (partly) discarded.
// A counter that lands exactly on 2^CW-1 without losing an increment does not
// set ovf_o.  ovf_o is cleared only by clear_i / reset (restart_i also starts a
// fresh epoch, so it clears too).
//
// Command semantics (all synchronous, evaluated at the clock edge):
//   clear_i    value := 0, ovf := 0; this cycle's event is DISCARDED.
//   restart_i  value := (en_i ? ev_i : 0), ovf := 0; this cycle's event is
//              counted in the NEW epoch (used by SNAP_CLR so no event is lost
//              or double counted between consecutive windows).
//   otherwise, when en_i: accumulate / track max / sample.  When !en_i: hold.
// =============================================================================
module sf_pm_counter #(
  parameter int CW   = 40,
  parameter int KIND = 0     // 0 accumulate, 1 peak, 2 gauge
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          en_i,
  input  logic          clear_i,
  input  logic          restart_i,
  input  logic [CW-1:0] ev_i,
  output logic [CW-1:0] q_o,
  output logic          ovf_o
);
  logic [CW:0] sum;
  assign sum = {1'b0, q_o} + {1'b0, ev_i};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      q_o   <= '0;
      ovf_o <= 1'b0;
    end else if (clear_i) begin
      q_o   <= '0;
      ovf_o <= 1'b0;
    end else if (restart_i) begin
      q_o   <= en_i ? ev_i : '0;
      ovf_o <= 1'b0;
    end else if (en_i) begin
      if (KIND == 0) begin
        if (sum[CW]) begin
          q_o   <= {CW{1'b1}};
          ovf_o <= 1'b1;
        end else begin
          q_o   <= sum[CW-1:0];
        end
      end else if (KIND == 1) begin
        if (ev_i > q_o) q_o <= ev_i;
      end else begin
        q_o <= ev_i;
      end
    end
  end
endmodule
