// =============================================================================
// sf_pm_regs -- generic counter bank, atomic snapshot shadow and CSR interface
//
// Contract with the event layer: ev_flat carries one CW-bit event value per
// counter for the *current* cycle.  This layer is core independent.
//
// SNAPSHOT / READ CONSISTENCY (normative)
//   * Live counters are never read by software.  A SNAPSHOT (CSR command or
//     snap_trig_i), SNAP_CLR or CLEAR is an atomic, single-edge operation.
//   * At the edge ending the command cycle, ALL shadow registers (every counter,
//     the overflow bitmap and the flags) are loaded from the live registers
//     together.  The captured value is the live value at the START of the
//     command cycle, i.e. it covers every enabled cycle strictly before it.
//     The events of the command cycle itself belong to the next window.
//   * Because every counter (including CYCLES) is captured at the same edge,
//     invariants such as sum(SLOT_*) == CYCLES hold inside every snapshot.
//   * The shadow only changes on those commands, so it is stable while
//     software reads it.  SNAP_SEQ increments on every command; software reads
//     it before and after a multi-word read and retries on mismatch (needed
//     only if another agent may issue commands concurrently).
//   * Command priority in one cycle: CLEAR > SNAP_CLR > SNAPSHOT/trigger.
//   * SNAP_CLR = snapshot, then the live counters restart with the command
//     cycle's own events -- consecutive windows tile the timeline exactly.
//
// RESET: asynchronous assert (same style as the core).  All state -> 0;
//   ENABLE resets to ENABLE_AT_RESET.  CLEAR zeroes live counters, flags,
//   shadow and SNAP_VALID but does NOT reset SNAP_SEQ (it increments).
// OVERFLOW: counters saturate; a sticky per-counter bit records lost increments.
// =============================================================================
module sf_pm_regs
  import sf_pm_pkg::*;
#(
  parameter int NT              = 4,
  parameter int LANES           = 4,
  parameter int CW              = 40,
  parameter bit ENABLE_AT_RESET = 1'b0,
  parameter bit NOC_TAP         = 1'b1
) (
  input  logic                clk,
  input  logic                rst_n,

  // CSR bus: single-cycle write, 1-cycle registered read (rvalid follows ren by 1 cycle)
  input  logic                csr_en_i,
  input  logic                csr_we_i,
  input  logic [CSR_AW-1:0]   csr_addr_i,
  input  logic [31:0]         csr_wdata_i,
  output logic [31:0]         csr_rdata_o,
  output logic                csr_rvalid_o,

  input  logic                snap_trig_i,     // hardware snapshot trigger (1-cycle pulse)

  // from the event layer
  input  logic [PM_NC*CW-1:0] ev_flat_i,
  input  logic                progress_i,
  input  logic                prog_done_i,

  // to the event layer / outside
  output logic                en_o,
  output logic                clear_o,
  output logic                irq_o
);

  // ---------------------------------------------------------------------------
  // Control registers
  // ---------------------------------------------------------------------------
  logic        en_q, irq_en_q;
  logic [31:0] wdog_thresh_q;

  logic csr_wr;
  assign csr_wr = csr_en_i && csr_we_i;

  logic cmd_snap, cmd_snapclr, cmd_clear, snap_fire, restart;
  assign cmd_snap    = csr_wr && (csr_addr_i == ADDR_CTRL) && csr_wdata_i[CTRL_SNAPSHOT];
  assign cmd_snapclr = csr_wr && (csr_addr_i == ADDR_CTRL) && csr_wdata_i[CTRL_SNAP_CLR];
  assign cmd_clear   = csr_wr && (csr_addr_i == ADDR_CTRL) && csr_wdata_i[CTRL_CLEAR];

  assign clear_o   = cmd_clear;
  assign restart   = cmd_snapclr && !cmd_clear;
  assign snap_fire = (cmd_snap || cmd_snapclr || snap_trig_i) && !cmd_clear;
  assign en_o      = en_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q          <= ENABLE_AT_RESET;
      irq_en_q      <= 1'b0;
      wdog_thresh_q <= '0;
    end else if (csr_wr) begin
      if (csr_addr_i == ADDR_CTRL) begin
        en_q     <= csr_wdata_i[CTRL_ENABLE];
        irq_en_q <= csr_wdata_i[CTRL_IRQ_EN];
      end
      if (csr_addr_i == ADDR_WDOG_THRESH) wdog_thresh_q <= csr_wdata_i;
    end
  end

  // ---------------------------------------------------------------------------
  // Counter bank
  // ---------------------------------------------------------------------------
  logic [PM_NC*CW-1:0] live_q;
  logic [PM_NC-1:0]    live_ovf;

  genvar gi;
  generate
    for (gi = 0; gi < PM_NC; gi++) begin : g_cnt
      sf_pm_counter #(.CW(CW), .KIND(int'(PM_KIND_V[2*gi +: 2]))) u_cnt (
        .clk       (clk),
        .rst_n     (rst_n),
        .en_i      (en_q),
        .clear_i   (cmd_clear),
        .restart_i (restart),
        .ev_i      (ev_flat_i[gi*CW +: CW]),
        .q_o       (live_q[gi*CW +: CW]),
        .ovf_o     (live_ovf[gi])
      );
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // Watchdog: N consecutive enabled cycles without forward progress
  // ---------------------------------------------------------------------------
  logic [31:0] noprog_q, noprog_nxt;
  logic        wdog_trip_q;

  assign noprog_nxt = progress_i ? 32'd0 : ((&noprog_q) ? noprog_q : noprog_q + 32'd1);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      noprog_q    <= '0;
      wdog_trip_q <= 1'b0;
    end else if (cmd_clear) begin
      noprog_q    <= '0;
      wdog_trip_q <= 1'b0;
    end else if (en_q) begin
      noprog_q <= noprog_nxt;
      if (wdog_thresh_q != 32'd0 && !progress_i && noprog_nxt >= wdog_thresh_q)
        wdog_trip_q <= 1'b1;
    end
  end

  // ---------------------------------------------------------------------------
  // Snapshot shadow (atomic, single-edge capture)
  // ---------------------------------------------------------------------------
  logic [PM_NC*CW-1:0] snap_q;
  logic [PM_NC-1:0]    snap_ovf_q;
  logic [31:0]         snap_flags_q;
  logic [31:0]         snap_seq_q;
  logic                snap_valid_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      snap_q       <= '0;
      snap_ovf_q   <= '0;
      snap_flags_q <= '0;
      snap_seq_q   <= '0;
      snap_valid_q <= 1'b0;
    end else if (cmd_clear) begin
      snap_q       <= '0;
      snap_ovf_q   <= '0;
      snap_flags_q <= '0;
      snap_valid_q <= 1'b0;
      snap_seq_q   <= snap_seq_q + 32'd1;
    end else if (snap_fire) begin
      snap_q       <= live_q;
      snap_ovf_q   <= live_ovf;
      snap_flags_q <= {29'd0, prog_done_i, wdog_trip_q, |live_ovf};
      snap_valid_q <= 1'b1;
      snap_seq_q   <= snap_seq_q + 32'd1;
    end
  end

  assign irq_o = irq_en_q && ((|live_ovf) || wdog_trip_q);

  // ---------------------------------------------------------------------------
  // CSR read mux (reads the SHADOW only)
  // ---------------------------------------------------------------------------
  logic [31:0] rd_mux;
  logic [CSR_AW-2:0] cnt_word;   // counter index candidate (address bit 0 selects LO/HI)
  int unsigned       cnt_idx;
  logic [63:0]       cnt_val64;

  assign cnt_word = csr_addr_i[CSR_AW-1:1] - ADDR_CNT_BASE[CSR_AW-1:1];
  assign cnt_idx  = int'(cnt_word);

  always_comb begin
    rd_mux    = 32'd0;
    cnt_val64 = 64'd0;
    if (cnt_idx < PM_NC) cnt_val64 = 64'(snap_q[cnt_idx*CW +: CW]);

    if (csr_addr_i >= ADDR_CNT_BASE) begin
      if (cnt_idx < PM_NC) rd_mux = csr_addr_i[0] ? cnt_val64[63:32] : cnt_val64[31:0];
    end else if (csr_addr_i >= ADDR_OVF_BASE) begin
      for (int k = 0; k < 8; k++)
        if (csr_addr_i == ADDR_OVF_BASE + CSR_AW'(k))
          for (int b = 0; b < 32; b++)
            if (k*32 + b < PM_NC) rd_mux[b] = snap_ovf_q[k*32 + b];
    end else begin
      case (csr_addr_i)
        ADDR_ID:          rd_mux = PM_ID_MAGIC;
        ADDR_VERSION:     rd_mux = PM_VERSION;
        ADDR_GEOM:        rd_mux = {8'(NT), 8'(LANES), 8'(CW), 8'(PM_NC)};
        ADDR_FEATURES:    rd_mux = {30'd0, ENABLE_AT_RESET, NOC_TAP};
        ADDR_CTRL:        rd_mux = {30'd0, irq_en_q, en_q};
        ADDR_STATUS:      rd_mux = {28'd0, wdog_trip_q, |live_ovf, en_q, snap_valid_q};
        ADDR_SNAP_SEQ:    rd_mux = snap_seq_q;
        ADDR_WDOG_THRESH: rd_mux = wdog_thresh_q;
        ADDR_FLAGS:       rd_mux = snap_flags_q;
        default:          rd_mux = 32'd0;
      endcase
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      csr_rdata_o  <= '0;
      csr_rvalid_o <= 1'b0;
    end else begin
      csr_rvalid_o <= csr_en_i && !csr_we_i;
      if (csr_en_i && !csr_we_i) csr_rdata_o <= rd_mux;
    end
  end

endmodule
