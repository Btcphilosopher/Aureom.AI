// =============================================================================
// sf_perfmon -- SilicaFlux performance-monitoring subsystem (top)
//
// Passive: every port except the CSR/irq outputs is an input tap.  Nothing here
// drives the core, so the core's behaviour is cycle-exact with or without it.
// See docs/ARCHITECTURE.md (design), docs/INTEGRATION.md (wiring), docs/METRICS.md.
// =============================================================================
module sf_perfmon
  import sf_pm_pkg::*;
#(
  parameter int NT              = 4,
  parameter int LANES           = 4,
  parameter int CW              = 40,
  parameter int CTRL_SHADOW     = 2,
  parameter bit ENABLE_AT_RESET = 1'b0,
  parameter bit NOC_TAP         = 1'b1
) (
  input  logic                 clk,
  input  logic                 rst_n,

  // CSR slave
  input  logic                 csr_en_i,
  input  logic                 csr_we_i,
  input  logic [CSR_AW-1:0]    csr_addr_i,
  input  logic [31:0]          csr_wdata_i,
  output logic [31:0]          csr_rdata_o,
  output logic                 csr_rvalid_o,
  input  logic                 snap_trig_i,
  output logic                 irq_o,

  // ---- taps (see sf_pm_events for exact semantics) ----
  input  logic                 is_valid_i,
  input  logic [4:0]           is_opcode_i,
  input  logic                 id_stall_i,
  input  logic                 load_use_i,
  input  logic                 sync_stall_i,
  input  logic                 flush_i,
  input  logic                 br_taken_i,
  input  logic                 ex_valid_i,
  input  logic [4:0]           ex_opcode_i,
  input  logic                 wb_valid_i,
  input  logic                 sched_valid_i,
  input  logic                 sched_ready_i,
  input  logic [NT-1:0]        tok_valid_i,
  input  logic [2:0]           tgt_tile_i,
  input  logic [NT-1:0]        tile_busy_i,
  input  logic [NT-1:0]        tile_done_i,
  input  logic [NT*3-1:0]      tile_state_i,
  input  logic [NT-1:0]        vec_issue_i,
  input  logic [NT*LANES-1:0]  lane_active_i,
  input  logic [NT-1:0]        tensor_busy_i,
  input  logic [NT:0]          mem_fire_i,
  input  logic [NT:0]          mem_blocked_i,
  input  logic [NT:0]          mem_resp_i,
  input  logic [NT:0]          mem_align_i,
  input  logic [7:0]           noc_occ_i,
  input  logic [NT-1:0]        noc_inj_fire_i,
  input  logic [NT-1:0]        noc_inj_blocked_i
);

  logic [PM_NC*CW-1:0] ev_flat;
  logic                progress, prog_done, en, clear;

  sf_pm_events #(.NT(NT), .LANES(LANES), .CW(CW), .CTRL_SHADOW(CTRL_SHADOW)) u_events (
    .clk(clk), .rst_n(rst_n), .en_i(en), .clear_i(clear),
    .is_valid_i, .is_opcode_i, .id_stall_i, .load_use_i, .sync_stall_i, .flush_i, .br_taken_i,
    .ex_valid_i, .ex_opcode_i, .wb_valid_i,
    .sched_valid_i, .sched_ready_i, .tok_valid_i, .tgt_tile_i, .tile_busy_i, .tile_done_i, .tile_state_i,
    .vec_issue_i, .lane_active_i, .tensor_busy_i,
    .mem_fire_i, .mem_blocked_i, .mem_resp_i, .mem_align_i,
    .noc_occ_i, .noc_inj_fire_i, .noc_inj_blocked_i,
    .ev_flat, .progress_o(progress), .prog_done_o(prog_done)
  );

  sf_pm_regs #(.NT(NT), .LANES(LANES), .CW(CW), .ENABLE_AT_RESET(ENABLE_AT_RESET), .NOC_TAP(NOC_TAP)) u_regs (
    .clk, .rst_n,
    .csr_en_i, .csr_we_i, .csr_addr_i, .csr_wdata_i, .csr_rdata_o, .csr_rvalid_o,
    .snap_trig_i,
    .ev_flat_i(ev_flat), .progress_i(progress), .prog_done_i(prog_done),
    .en_o(en), .clear_o(clear), .irq_o
  );


`ifdef SF_PM_SVA
  // Assertions (simulation / formal only; never synthesized)
  logic [PM_CLASS_N-1:0] cls_ev_w;
  always_comb begin
    for (int k = 0; k < PM_CLASS_N; k++) cls_ev_w[k] = (ev_flat[(PM_CLASS_FIRST + k)*CW +: CW] != '0);
  end
  sf_pm_sva #(.NT(NT), .CW(CW)) u_sva (
    .clk, .rst_n,
    .id_stall_i, .load_use_i, .sync_stall_i, .sched_valid_i, .sched_ready_i, .tok_valid_i,
    .en_q(u_regs.en_q), .cmd_clear(u_regs.cmd_clear), .cmd_snapclr(u_regs.cmd_snapclr), .snap_fire(u_regs.snap_fire),
    .slot(u_events.slot), .cls_ev(cls_ev_w),
    .live_q(u_regs.live_q), .live_ovf(u_regs.live_ovf), .snap_q(u_regs.snap_q), .snap_seq_q(u_regs.snap_seq_q),
    .prog_done_q(u_events.prog_done_q),
    .csr_en_i, .csr_we_i, .csr_rvalid_o, .csr_rdata_o, .irq_o
  );
`endif

endmodule
