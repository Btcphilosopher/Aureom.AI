// =============================================================================
// sf_pm_events -- SilicaFlux event adapter (the ONLY core-specific part)
//
// Turns the passive tap signals of the supplied SilicaFlux RTL into one
// per-cycle event value per performance counter (ev_flat).  Everything here is
// observation only: no output of this module can reach the core.
//
// To retarget the monitor to another core, replace this module and keep the
// ev_flat / progress_o / prog_done_o contract used by sf_pm_regs.
//
// Pipeline model (supplied RTL):  IF -> ID -> IS -> EX -> MEM -> WB
//   The "issue slot" is the IS->EX hand-off in control_core.  Each enabled
//   cycle is classified into EXACTLY ONE slot category (priority chain below),
//   so SLOT_* always sum to CYCLES.
// =============================================================================
`include "silicaflux_pkg.sv"

module sf_pm_events
  import silicaflux_pkg::*;
  import sf_pm_pkg::*;
#(
  parameter int NT          = 4,   // compute tiles
  parameter int LANES       = 4,   // SIMD lanes per tile vector engine
  parameter int CW          = 40,  // counter width (event values are CW bits)
  parameter int CTRL_SHADOW = 2    // redirect-shadow length after a branch flush (IF->IS distance)
) (
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic                 en_i,        // counting enabled (CTRL.ENABLE)
  input  logic                 clear_i,     // CLEAR command: reset streak tracking

  // ---- issue / front end (control_core, decoder) ----
  input  logic                 is_valid_i,   // id_is.valid: instruction presented at IS
  input  logic [4:0]           is_opcode_i,  // id_is.instr.opcode
  input  logic                 id_stall_i,   // control_core.id_stall
  input  logic                 load_use_i,   // control_core.load_use_hazard
  input  logic                 sync_stall_i, // scheduler.sync_stall
  input  logic                 flush_i,      // control_core.pipeline_flush
  input  logic                 br_taken_i,   // branch/jump taken, resolved in EX (br_taken_comb && is_ex.valid)
  // ---- EX / WB ----
  input  logic                 ex_valid_i,   // is_ex.valid
  input  logic [4:0]           ex_opcode_i,  // is_ex.instr.opcode
  input  logic                 wb_valid_i,   // mem_wb.valid
  // ---- scheduler / dispatch ----
  input  logic                 sched_valid_i,// control_core.sched_valid (== scheduler op in EX)
  input  logic                 sched_ready_i,// scheduler.instr_ready
  input  logic [NT-1:0]        tok_valid_i,  // token accepted by tile t
  input  logic [2:0]           tgt_tile_i,   // scheduler target tile id
  input  logic [NT-1:0]        tile_busy_i,  // scheduler scoreboard
  input  logic [NT-1:0]        tile_done_i,  // tile completion pulses
  input  logic [NT*3-1:0]      tile_state_i, // compute_tile FSM state (0 idle,1 mem,2 vec,3 tensor)
  // ---- execution units ----
  input  logic [NT-1:0]        vec_issue_i,
  input  logic [NT*LANES-1:0]  lane_active_i,// per-lane active mask, meaningful when vec_issue_i
  input  logic [NT-1:0]        tensor_busy_i,
  // ---- memory controllers: [NT-1:0] tiles, [NT] control-core scalar path ----
  input  logic [NT:0]          mem_fire_i,    // req_valid && req_ready
  input  logic [NT:0]          mem_blocked_i, // req_valid && !req_ready
  input  logic [NT:0]          mem_resp_i,    // resp_valid
  input  logic [NT:0]          mem_align_i,   // alignment_err
  // ---- NoC ----
  input  logic [7:0]           noc_occ_i,       // occupied router buffer slots
  input  logic [NT-1:0]        noc_inj_fire_i,  // injection accepted
  input  logic [NT-1:0]        noc_inj_blocked_i,

  // ---- outputs to sf_pm_regs ----
  output logic [PM_NC*CW-1:0]  ev_flat,
  output logic                 progress_o,   // forward progress this cycle (watchdog)
  output logic                 prog_done_o   // HALT has issued
);

  localparam logic [4:0] OPC_HALT = 5'h1F;

  // ---------------------------------------------------------------------------
  // Tracking state.  Runs regardless of en_i so enabling mid-run is exact.
  // ---------------------------------------------------------------------------
  logic                  prog_done_q;
  logic [CTRL_SHADOW-1:0] shadow_q;       // redirect shadow after a flush
  logic                  ex_fresh_q, mem_fresh_q, wb_fresh_q;   // unique-instruction tags
  logic [NT:0]           mem_out_q;       // per-controller outstanding request
  logic [CW-1:0]         streak_q;        // current consecutive-stall run (enabled cycles)

  // ---------------------------------------------------------------------------
  // Slot classification (mutually exclusive, exhaustive)
  // ---------------------------------------------------------------------------
  logic [PM_SLOT_N-1:0]  slot;
  logic [PM_CLASS_N-1:0] cls;
  logic                  disp_blocked, mach_busy, shadow_any, iss_cnt;
  logic [2:0]            blk_state;

  assign disp_blocked = sched_valid_i && !sched_ready_i;
  assign shadow_any   = |shadow_q;
  assign mach_busy    = ex_valid_i || (|tile_busy_i) || (|mem_out_q);

  always_comb begin
    blk_state = 3'd7;   // unknown / out-of-range target
    for (int t = 0; t < NT; t++)
      if (tgt_tile_i == 3'(t)) blk_state = tile_state_i[t*3 +: 3];
  end

  always_comb begin
    slot = '0;
    if (prog_done_q) begin
      slot[S_IDLE] = 1'b1;                       // everything after HALT issued
    end else if (flush_i) begin
      slot[S_BUB_CTRL] = 1'b1;                   // slot squashed by taken branch
    end else if (id_stall_i) begin
      if (sync_stall_i)        slot[S_SYNC] = 1'b1;
      else if (load_use_i)     slot[S_DEP]  = 1'b1;
      else if (disp_blocked) begin
        if (ex_opcode_i == OP_DFSYNC) slot[S_SYNC] = 1'b1;     // the DFSYNC itself waiting
        else case (blk_state)
          3'd1:    slot[S_MEM]       = 1'b1;
          3'd2:    slot[S_EXEC_VEC]  = 1'b1;
          3'd3:    slot[S_EXEC_TENS] = 1'b1;
          default: slot[S_DISP_OTHER]= 1'b1;
        endcase
      end else                 slot[S_DISP_OTHER] = 1'b1;     // unreachable (SVA: stall has a cause)
    end else if (is_valid_i)   slot[S_ISSUE]     = 1'b1;
    else if (shadow_any)       slot[S_BUB_CTRL]  = 1'b1;
    else if (mach_busy)        slot[S_BUB_FRONT] = 1'b1;
    else                       slot[S_IDLE]      = 1'b1;
  end

  assign iss_cnt = slot[S_ISSUE];

  // Instruction class of the issued instruction
  always_comb begin
    cls = '0;
    case (is_opcode_i)
      OP_ADD, OP_SUB, OP_MUL, OP_MOV:                          cls[K_SALU]   = 1'b1;
      OP_LOAD, OP_STORE:                                       cls[K_SMEM]   = 1'b1;
      OP_BEQ, OP_BNE, OP_JMP:                                  cls[K_BRANCH] = 1'b1;
      OP_DFLOAD, OP_DFSTORE, OP_VLOAD, OP_VSTORE:              cls[K_DFMEM]  = 1'b1;
      OP_DFMAP, OP_DFEXEC, OP_DFSYNC:                          cls[K_DFCTL]  = 1'b1;
      OP_VADD, OP_VSUB, OP_VMUL, OP_DOT, OP_REDUCE, OP_BCAST:  cls[K_VEC]    = 1'b1;
      OP_MATMUL:                                               cls[K_TENSOR] = 1'b1;
      default:                                                 cls[K_NOP]    = 1'b1;
    endcase
  end

  // ---------------------------------------------------------------------------
  // Derived per-cycle conditions
  // ---------------------------------------------------------------------------
  logic stall_slot, retire_scalar, drop, drop_sync, any_tok;
  logic [CW-1:0] streak_nxt;

  assign stall_slot    = slot[S_DEP] | slot[S_SYNC] | slot[S_EXEC_VEC] | slot[S_EXEC_TENS] |
                         slot[S_MEM] | slot[S_DISP_OTHER];
  assign retire_scalar = wb_valid_i && wb_fresh_q;
  assign any_tok       = |tok_valid_i;
  // scheduler op consumed by the control core (sched_ready) but no token produced
  assign drop          = sched_valid_i && sched_ready_i && !any_tok;
  assign drop_sync     = (ex_opcode_i == OP_DFSYNC);
  assign streak_nxt    = stall_slot ? ((&streak_q) ? streak_q : streak_q + 1'b1) : '0;

  assign progress_o    = iss_cnt || retire_scalar || (|tile_done_i) || any_tok;
  assign prog_done_o   = prog_done_q;

  // ---------------------------------------------------------------------------
  // Tracking registers
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      prog_done_q <= 1'b0;
      shadow_q    <= '0;
      ex_fresh_q  <= 1'b0;
      mem_fresh_q <= 1'b0;
      wb_fresh_q  <= 1'b0;
      mem_out_q   <= '0;
      streak_q    <= '0;
    end else begin
      // HALT issued -> program over (sticky until reset)
      if (iss_cnt && is_opcode_i == OPC_HALT) prog_done_q <= 1'b1;

      // redirect shadow: shift in flush
      shadow_q <= {shadow_q[CTRL_SHADOW-2:0], flush_i};

      // Unique-instruction tag follows the instruction through EX -> MEM -> WB.
      // The supplied RTL replays a stalled EX instruction into WB every stall
      // cycle; only the first copy (fresh) is a real retirement.
      ex_fresh_q  <= iss_cnt;
      mem_fresh_q <= ex_fresh_q && ex_valid_i && !sched_valid_i;
      wb_fresh_q  <= mem_fresh_q;

      // outstanding memory request per controller (accept -> response)
      for (int c = 0; c <= NT; c++)
        mem_out_q[c] <= mem_fire_i[c] ? 1'b1 : (mem_resp_i[c] ? 1'b0 : mem_out_q[c]);

      // stall streak (only while counting)
      if (clear_i)    streak_q <= '0;
      else if (en_i)  streak_q <= streak_nxt;
    end
  end

  // ---------------------------------------------------------------------------
  // Event vector: one CW-bit event value per counter
  // ---------------------------------------------------------------------------
  function automatic logic [CW-1:0] w(input int unsigned x);
    return CW'(x);
  endfunction

  always_comb begin
    ev_flat = '0;
    ev_flat[CNT_CYCLES*CW +: CW] = w(1);
    for (int s = 0; s < PM_SLOT_N; s++)
      ev_flat[(PM_SLOT_FIRST + s)*CW +: CW] = w(int'(slot[s]));
    for (int k = 0; k < PM_CLASS_N; k++)
      ev_flat[(PM_CLASS_FIRST + k)*CW +: CW] = w(int'(iss_cnt && cls[k]));

    ev_flat[CNT_RET_SCALAR*CW     +: CW] = w(int'(retire_scalar));
    ev_flat[CNT_RET_TILE*CW       +: CW] = w(popcnt(64'(tile_done_i)));
    ev_flat[CNT_TOK_DISPATCHED*CW +: CW] = w(popcnt(64'(tok_valid_i)));
    ev_flat[CNT_DROP_SYNC*CW      +: CW] = w(int'(drop &&  drop_sync));
    ev_flat[CNT_DROP_OP*CW        +: CW] = w(int'(drop && !drop_sync));
    ev_flat[CNT_BRANCH_TAKEN*CW   +: CW] = w(int'(br_taken_i));

    ev_flat[CNT_TILE_TOK_0*CW  +: CW] = w(int'(tok_valid_i[0]));
    ev_flat[CNT_TILE_TOK_1*CW  +: CW] = w(int'(tok_valid_i[1]));
    ev_flat[CNT_TILE_TOK_2*CW  +: CW] = w(int'(tok_valid_i[2]));
    ev_flat[CNT_TILE_TOK_3*CW  +: CW] = w(int'(tok_valid_i[3]));
    ev_flat[CNT_TILE_BUSY_0*CW +: CW] = w(int'(tile_busy_i[0]));
    ev_flat[CNT_TILE_BUSY_1*CW +: CW] = w(int'(tile_busy_i[1]));
    ev_flat[CNT_TILE_BUSY_2*CW +: CW] = w(int'(tile_busy_i[2]));
    ev_flat[CNT_TILE_BUSY_3*CW +: CW] = w(int'(tile_busy_i[3]));

    begin : exec_ev
      int unsigned lanes, partial, vbusy;
      logic [LANES-1:0] la;
      lanes = 0; partial = 0; vbusy = 0;
      for (int t = 0; t < NT; t++) begin
        la = lane_active_i[t*LANES +: LANES];
        if (vec_issue_i[t]) begin
          lanes   = lanes + popcnt(64'(la));
          partial = partial + int'((|la) && !(&la));
        end
        vbusy = vbusy + int'(tile_state_i[t*3 +: 3] == 3'd2);
      end
      ev_flat[CNT_VEC_ISSUES*CW         +: CW] = w(popcnt(64'(vec_issue_i)));
      ev_flat[CNT_VEC_LANES_ACTIVE*CW   +: CW] = w(lanes);
      ev_flat[CNT_VEC_ISSUES_PARTIAL*CW +: CW] = w(partial);
      ev_flat[CNT_VEC_BUSY_CYC*CW       +: CW] = w(vbusy);
      ev_flat[CNT_TENSOR_BUSY_CYC*CW    +: CW] = w(popcnt(64'(tensor_busy_i)));
    end

    ev_flat[CNT_MEM_REQ_ACCEPTED*CW +: CW] = w(popcnt(64'(mem_fire_i)));
    ev_flat[CNT_MEM_RESP*CW         +: CW] = w(popcnt(64'(mem_resp_i)));
    ev_flat[CNT_MEM_REQ_BLOCKED*CW  +: CW] = w(popcnt(64'(mem_blocked_i)));
    ev_flat[CNT_MEM_ALIGN_ERR*CW    +: CW] = w(popcnt(64'(mem_align_i)));
    ev_flat[CNT_MEM_OUT_SUM*CW      +: CW] = w(popcnt(64'(mem_out_q)));
    ev_flat[CNT_MEM_BUSY_CYC*CW     +: CW] = w(int'(|mem_out_q));
    ev_flat[CNT_MEM_OUT_PEAK*CW     +: CW] = w(popcnt(64'(mem_out_q)));
    ev_flat[CNT_MEM_OUT_NOW*CW      +: CW] = w(popcnt(64'(mem_out_q)));

    ev_flat[CNT_Q_DISP_SUM*CW  +: CW] = w(int'(sched_valid_i));
    ev_flat[CNT_Q_DISP_NOW*CW  +: CW] = w(int'(sched_valid_i));
    ev_flat[CNT_Q_TOK_SUM*CW   +: CW] = w(popcnt(64'(tile_busy_i)));
    ev_flat[CNT_Q_TOK_PEAK*CW  +: CW] = w(popcnt(64'(tile_busy_i)));
    ev_flat[CNT_Q_TOK_NOW*CW   +: CW] = w(popcnt(64'(tile_busy_i)));
    ev_flat[CNT_Q_NOC_SUM*CW   +: CW] = w(int'(noc_occ_i));
    ev_flat[CNT_Q_NOC_PEAK*CW  +: CW] = w(int'(noc_occ_i));
    ev_flat[CNT_Q_NOC_NOW*CW   +: CW] = w(int'(noc_occ_i));
    ev_flat[CNT_NOC_FLITS*CW        +: CW] = w(popcnt(64'(noc_inj_fire_i)));
    ev_flat[CNT_NOC_INJ_BLOCKED*CW  +: CW] = w(popcnt(64'(noc_inj_blocked_i)));

    ev_flat[CNT_STALL_STREAK_MAX*CW +: CW] = streak_nxt;
  end

endmodule
