#!/usr/bin/env bash
# Assemble an RTL variant from the pristine supplied RTL + patches.
#   usage: build_variant.sh <sup|pm|fix|pmfix> <outdir>
#   sup    pristine supplied RTL (uninstrumented, as supplied)
#   pm     + 0001 perfmon taps                      (instrumented, as supplied behaviour)
#   fix    + 0002 + 0003 optional bug fixes         (uninstrumented, fixed core)
#   pmfix  + 0001 + 0002 + 0003                     (instrumented, fixed core)
set -euo pipefail
V=$1; OUT=$2
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
rm -rf "$OUT"; mkdir -p "$OUT"; cp "$ROOT"/rtl/supplied/*.sv "$OUT"/
apply() { patch -s -p1 -d "$OUT" --no-backup-if-mismatch < "$ROOT/patches/$1" || { echo "patch $1 failed for variant $V" >&2; exit 1; }; }
case "$V" in
  sup)   ;;
  pm)    apply 0001-perfmon-taps.patch ;;
  fix)   apply optional/0002-fix-load-use-livelock.patch; apply optional/0003-fix-dispatch-drop.patch ;;
  pmfix) apply 0001-perfmon-taps.patch; apply optional/0002-fix-load-use-livelock.patch; apply optional/0003-fix-dispatch-drop.patch ;;
  *) echo "unknown variant $V" >&2; exit 2 ;;
esac
echo "$OUT"
