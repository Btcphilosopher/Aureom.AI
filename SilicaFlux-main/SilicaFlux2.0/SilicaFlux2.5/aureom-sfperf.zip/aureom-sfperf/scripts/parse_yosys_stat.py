#!/usr/bin/env python3
"""Parse native Yosys `stat` + `ltp` logs into JSON (last statistics block in each log)."""
import re, sys, json

def parse(path):
    txt = open(path, errors="replace").read()
    i = txt.rfind("Printing statistics.")
    blk = txt[i:] if i >= 0 else txt
    out = {"cells": {}}
    for line in blk.splitlines():
        m = re.match(r"^\s+(\\?\$\w+)\s+(\d+)\s*$", line)         # '     $_AND_      5539'
        if m: out["cells"][m.group(1).lstrip("\\")] = out["cells"].get(m.group(1).lstrip("\\"), 0) + int(m.group(2))
        m = re.match(r"^\s+Number of cells:\s+(\d+)", line)
        if m: out["total_cells"] = int(m.group(1))
        m = re.match(r"^\s+Number of memory bits:\s+(\d+)", line)
        if m: out["mem_bits"] = int(m.group(1))
    cells = out["cells"]
    out["ff"] = sum(v for k, v in cells.items() if "DFF" in k or "DLATCH" in k)
    out["mem_cells"] = sum(v for k, v in cells.items() if k.startswith("$mem"))
    out["comb"] = sum(v for k, v in cells.items() if not ("DFF" in k or "DLATCH" in k or k.startswith("$mem")))
    out.setdefault("mem_bits", 0)
    m = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", txt)
    out["ltp"] = int(m.group(1)) if m else None
    return out

g, l = parse(sys.argv[1]), parse(sys.argv[2])
print(json.dumps({"generic_gates": g, "lut6": l}, indent=1))
