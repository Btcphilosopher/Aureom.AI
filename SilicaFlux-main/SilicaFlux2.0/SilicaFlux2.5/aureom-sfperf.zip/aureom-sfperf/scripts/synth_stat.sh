#!/usr/bin/env bash
# Area / logic-depth PROXIES from Yosys.  These are NOT silicon area, power or timing.
#   usage: synth_stat.sh <top> <outdir> <incdirs,comma> <file...>   [env: GEN="-G PM_EN=0"]
# Flow (two tools, because each lacks something the other has):
#   1. yosys 0.71 (YoWASP) + yosys-slang  : elaborates the supplied SV (the distro Yosys 0.33 rejects
#                                            `return {...}` in silicaflux_pkg.sv); memories stay as $mem.
#                                            Its abc pass cannot spawn processes inside WASM, so it stops after
#                                            techmap (all arithmetic -> primitive gates, memories stay $mem) and
#                                            hands over the netlist via write_verilog.
#   2. native yosys 0.33 + ABC            : technology-maps that netlist to (a) generic 2-input gates and
#                                            (b) 6-input LUTs and reports cells, flip-flops, memory bits, longest path.
# `-Wno-range-oob` is only needed for the supplied RTL (compute_tile.sv:226 selects [2:0] of a 2-bit field).
set -euo pipefail
TOP=$1; OUT=$2; INCS=$3; shift 3
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
mkdir -p "$OUT"
INC=""; IFS=',' read -ra A <<< "$INCS"; for d in "${A[@]}"; do INC="$INC -I $d"; done
YW=${YOSYS_ELAB:-yowasp-yosys}
$YW -q -p "read_slang -j 1 --single-unit -Wno-range-oob ${GEN:-} $INC --top $TOP $*; hierarchy -top $TOP; synth -top $TOP -flatten -run begin:fine; opt -full; techmap; opt -fast; write_verilog -noattr $OUT/coarse.v" > "$OUT/elab.log" 2>&1 \
  || { echo "elaboration failed ($OUT/elab.log)"; tail -5 "$OUT/elab.log"; exit 1; }
# native back end
yosys -p "read_verilog -sv $OUT/coarse.v; hierarchy -top $TOP; proc; opt; memory -nomap; opt; techmap; opt; abc -g AND,NAND,OR,NOR,XOR,XNOR,ANDNOT,ORNOT,MUX; opt_clean; stat; ltp -noff" > "$OUT/gates.log" 2>&1 \
  || { echo "gate mapping failed ($OUT/gates.log)"; tail -5 "$OUT/gates.log"; exit 1; }
yosys -p "read_verilog -sv $OUT/coarse.v; hierarchy -top $TOP; proc; opt; memory -nomap; opt; techmap; opt; abc -lut 6; opt_clean; stat; ltp -noff" > "$OUT/lut6.log" 2>&1 \
  || { echo "LUT mapping failed ($OUT/lut6.log)"; tail -5 "$OUT/lut6.log"; exit 1; }
python3 scripts/parse_yosys_stat.py "$OUT/gates.log" "$OUT/lut6.log" > "$OUT/summary.json"
