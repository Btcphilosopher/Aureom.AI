#!/usr/bin/env bash
# Build a simulation binary for one variant.   usage: build_sim.sh <sup|pm|fix|pmfix> [pm_en=1]
# Output: build/sim_<variant>[_nopm].vvp
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
V=$1; PMEN=${2:-1}
D=build/rtl_$V; [ -d "$D" ] || scripts/build_variant.sh "$V" "$D" >/dev/null
case "$V" in pm|pmfix) FL="-DPM_BUILD -DPM_EN_VAL=$PMEN"; [ "$PMEN" != 0 ] && FL="$FL -DPM_MODEL"; M=pm; EXTRA="tb/pm_ref_model.sv"; SUF=""; [ "$PMEN" = 0 ] && SUF="_nopm";; *) FL=""; M=nopm; EXTRA=""; SUF="";; esac
OUT=build/sim_${V}${SUF}.vvp
iverilog -g2012 $FL -I"$D" -Irtl/perfmon -o "$OUT" $(scripts/rtl_files.sh "$D" $M) $EXTRA tb/tb_sys.sv 2>&1 | grep -v 'sorry: constant selects' || true
echo "$OUT"
