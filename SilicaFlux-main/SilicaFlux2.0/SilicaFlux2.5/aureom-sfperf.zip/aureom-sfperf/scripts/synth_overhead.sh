#!/usr/bin/env bash
# Instrumentation-overhead measurement: synthesize three variants of silicaflux_top with the same flow.
#   sup  : supplied RTL, unmodified
#   pm0  : instrumented RTL with PM_EN=0   (taps exist, monitor not instantiated; must equal `sup`)
#   pm1  : instrumented RTL with PM_EN=1   (monitor included)
# Output: build/syn_<name>/summary.json  (+ logs).  Results are PROXIES (see scripts/synth_stat.sh).
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
for v in sup pm; do [ -d build/rtl_$v ] || scripts/build_variant.sh $v build/rtl_$v >/dev/null; done
run() { # name variantdir gen files...
  local name=$1 dir=$2 gen=$3; shift 3
  if [ -n "${SKIP_EXISTING:-}" ] && [ -f build/syn_$name/summary.json ]; then echo "== $name: kept"; return; fi
  echo "== synthesizing $name"; GEN="$gen" scripts/synth_stat.sh silicaflux_top build/syn_$name "$dir,rtl/perfmon" "$@"
}
SUP=$(scripts/rtl_files.sh build/rtl_sup nopm | tr '\n' ' ')
PM=$(scripts/rtl_files.sh build/rtl_pm pm | tr '\n' ' ')
run sup build/rtl_sup "" $SUP
run pm0 build/rtl_pm "-G PM_EN=0" $PM
run pm1 build/rtl_pm "" $PM
echo "done"
