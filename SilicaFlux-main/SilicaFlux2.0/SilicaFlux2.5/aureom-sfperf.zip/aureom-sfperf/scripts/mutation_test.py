#!/usr/bin/env python3
"""Mutation testing of the monitor RTL against tb_pm_unit (and, for survivors, the SVA run under Verilator).

Each mutant applies ONE textual change to a copy of rtl/perfmon/.  A mutant is KILLED if the unit testbench reports any
[FAIL]/[MISMATCH], fails to compile or hangs.  Survivors are re-run under Verilator with SVA enabled.
Anchors must match exactly once so the mutants cannot silently drift from the RTL.
    python3 scripts/mutation_test.py [--jobs N] [--sva]  ->  results/mutation_report.md
"""
import argparse, concurrent.futures as cf, pathlib, shutil, subprocess, sys, time
ROOT = pathlib.Path(__file__).resolve().parent.parent
M = []   # (id, file, old, new, description)
def m(id_, f, old, new, desc): M.append((id_, f, old, new, desc))

E, R, C, P = "sf_pm_events.sv", "sf_pm_regs.sv", "sf_pm_counter.sv", "sf_perfmon.sv"
m("M01", E, "      if (sync_stall_i)        slot[S_SYNC] = 1'b1;\n      else if (load_use_i)     slot[S_DEP]  = 1'b1;",
            "      if (load_use_i)          slot[S_DEP]  = 1'b1;\n      else if (sync_stall_i)   slot[S_SYNC] = 1'b1;", "priority: load-use before barrier")
m("M02", E, "    end else if (flush_i) begin\n      slot[S_BUB_CTRL] = 1'b1;", "    end else if (flush_i && !id_stall_i) begin\n      slot[S_BUB_CTRL] = 1'b1;", "flush no longer beats a stall")
m("M03", E, "if (ex_opcode_i == OP_DFSYNC) slot[S_SYNC] = 1'b1;", "if (1'b0) slot[S_SYNC] = 1'b1;", "DFSYNC held at dispatch not counted as barrier wait")
m("M04", P, "parameter int CTRL_SHADOW     = 2,", "parameter int CTRL_SHADOW     = 3,", "redirect shadow too long (3)")
m("M05", E, "assign retire_scalar = wb_valid_i && wb_fresh_q;", "assign retire_scalar = wb_valid_i;", "retirement ignores replay filtering")
m("M06", E, "assign drop          = sched_valid_i && sched_ready_i && !any_tok;", "assign drop          = sched_valid_i && sched_ready_i;", "drop detector ignores dispatched token")
m("M07", E, "(mem_resp_i[c] ? 1'b0 : mem_out_q[c])", "mem_out_q[c]", "outstanding tracker never clears")
m("M08", E, "if (iss_cnt && is_opcode_i == OPC_HALT) prog_done_q <= 1'b1;", "if (1'b0) prog_done_q <= 1'b1;", "HALT never ends the program")
m("M09", E, "        if (vec_issue_i[t]) begin\n          lanes   = lanes", "        if (1'b1) begin\n          lanes   = lanes", "lane count not qualified by vec_issue")
m("M10", E, "assign streak_nxt    = stall_slot ? ((&streak_q) ? streak_q : streak_q + 1'b1) : '0;", "assign streak_nxt    = stall_slot ? ((&streak_q) ? streak_q : streak_q + 1'b1) : streak_q;", "stall streak never resets")
m("M11", C, "q_o   <= en_i ? ev_i : '0;", "q_o   <= '0;", "SNAP_CLR loses the event of the command cycle")
m("M12", C, "          q_o   <= {CW{1'b1}};\n          ovf_o <= 1'b1;", "          q_o   <= sum[CW-1:0];\n          ovf_o <= 1'b1;", "wrap instead of saturate")
m("M13", C, "          q_o   <= sum[CW-1:0];\n        end", "          q_o   <= sum[CW-1:0];\n          ovf_o <= 1'b0;\n        end", "overflow flag not sticky")
m("M14", R, "    end else if (cmd_clear) begin\n      snap_q       <= '0;", "    end else if (cmd_clear) begin\n      snap_q       <= snap_q;", "CLEAR leaves the shadow intact")
m("M15", R, "csr_addr_i[0] ? cnt_val64[63:32] : cnt_val64[31:0]", "cnt_val64[31:0]", "HI word reads LO")
m("M16", R, "noprog_nxt >= wdog_thresh_q", "noprog_nxt > wdog_thresh_q", "watchdog off by one")
m("M17", R, ".en_i      (en_q),", ".en_i      (1'b1),", "counters ignore ENABLE")
m("M18", R, "      snap_valid_q <= 1'b1;\n      snap_seq_q   <= snap_seq_q + 32'd1;", "      snap_valid_q <= 1'b1;", "SNAP_SEQ not incremented by snapshots")
m("M19", R, "{29'd0, prog_done_i, wdog_trip_q, |live_ovf}", "{29'd0, 1'b0, wdog_trip_q, |live_ovf}", "FLAGS drops PROG_DONE")
m("M20", R, "assign snap_fire = (cmd_snap || cmd_snapclr || snap_trig_i) && !cmd_clear;", "assign snap_fire = (cmd_snap || cmd_snapclr || snap_trig_i);", "snapshot not suppressed by CLEAR")
m("M21", E, "blk_state = 3'd7;   // unknown / out-of-range target", "blk_state = tile_state_i[2:0];", "out-of-range target uses tile 0 state")
m("M22", E, "OP_DFLOAD, OP_DFSTORE, OP_VLOAD, OP_VSTORE:", "OP_DFLOAD, OP_DFSTORE, OP_VLOAD:", "VSTORE not classified as tile memory op")
m("M23", C, "if (ev_i > q_o) q_o <= ev_i;", "q_o <= ev_i;", "peak counter degraded to gauge")
m("M24", E, "ex_fresh_q  <= iss_cnt;", "ex_fresh_q  <= is_valid_i && !id_stall_i;", "fresh tag ignores flush / post-HALT")
m("M25", R, "assign irq_o = irq_en_q && ((|live_ovf) || wdog_trip_q);", "assign irq_o = ((|live_ovf) || wdog_trip_q);", "irq ignores IRQ_EN")
m("M26", E, "slot[S_BUB_FRONT] = 1'b1;\n    else                       slot[S_IDLE]      = 1'b1;", "slot[S_BUB_FRONT] = 1'b1;\n    else                       slot[S_BUB_FRONT] = 1'b1;", "empty machine counted as front-end bubble, never IDLE")

# Mutants proven to be behaviourally equivalent to the original RTL (cannot be killed by any test); excluded from the score.
EQUIVALENT = {"M20": "`snap_fire`'s only consumer is the `else if (snap_fire)` branch that follows `if (cmd_clear)` in the shadow update, "
                     "so CLEAR already has priority; the `&& !cmd_clear` guard is redundant (the SVA antecedents also test `!cmd_clear`)."}
SRC = ["silicaflux_pkg.sv"]
def build_and_run(item, tmp, sva=False):
    id_, f, old, new, desc = item
    d = tmp / id_; d.mkdir(parents=True, exist_ok=True)
    for p in (ROOT / "rtl/perfmon").glob("*"): shutil.copy(p, d / p.name)
    t = (d / f).read_text()
    if t.count(old) != 1: return id_, "BAD-ANCHOR", f"{old!r} found {t.count(old)}x"
    (d / f).write_text(t.replace(old, new))
    files = [str(ROOT / "rtl/supplied/silicaflux_pkg.sv")] + [str(d / x) for x in ("sf_pm_pkg.sv", "sf_pm_counter.sv", "sf_pm_events.sv", "sf_pm_regs.sv")]
    if sva: files += [str(ROOT / "sva/sf_pm_sva.sv")]
    files += [str(d / "sf_perfmon.sv"), str(ROOT / "tb/pm_ref_model.sv"), str(ROOT / "tb/tb_pm_unit.sv")]
    if not sva:
        r = subprocess.run(["iverilog", "-g2012", f"-I{d}", f"-I{ROOT/'rtl/supplied'}", "-o", str(d / "t.vvp")] + files, capture_output=True, text=True)
        if r.returncode: return id_, "KILLED", "compile error"
        try: r = subprocess.run(["vvp", str(d / "t.vvp")], capture_output=True, text=True, timeout=400, cwd=d)
        except subprocess.TimeoutExpired: return id_, "KILLED", "timeout"
        out = r.stdout
    else:
        b = subprocess.run(["verilator", "--binary", "--timing", "--assert", "-DSF_PM_SVA", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-SYNCASYNCNET", "-Wno-WIDTH",
                            "-Wno-CASEINCOMPLETE", "-Wno-UNOPTFLAT", "-Wno-INITIALDLY", "-Wno-BLKSEQ", f"-I{d}", f"-I{ROOT/'rtl/supplied'}", "--top-module", "tb_pm_unit",
                            "-Mdir", str(d / "vl"), "-o", "t"] + files, capture_output=True, text=True)
        if b.returncode: return id_, "KILLED", "compile error"
        r = subprocess.run([str(d / "vl" / "t")], capture_output=True, text=True, timeout=600, cwd=d); out = r.stdout + r.stderr
    nfail = out.count("[FAIL]"); nmis = out.count("[MISMATCH]"); asserts = out.count("Assertion failed")
    if nfail or nmis or asserts or "ALL TESTS PASSED" not in out:
        why = f"{nfail} FAIL, {nmis} MISMATCH" + (f", {asserts} assertion(s)" if asserts else "")
        first = next((l for l in out.splitlines() if "[FAIL]" in l or "Assertion failed" in l), "")
        return id_, "KILLED", f"{why}; first: {first.strip()[:110]}"
    return id_, "SURVIVED", ""

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--jobs", type=int, default=4); ap.add_argument("--sva", action="store_true"); ap.add_argument("--only", default=""); a = ap.parse_args()
    import json
    tmp = ROOT / "build" / "mut"; shutil.rmtree(tmp, ignore_errors=True); tmp.mkdir(parents=True)
    jpath = ROOT / "results" / "mutation_results.json"
    res = {k: tuple(v) for k, v in json.load(open(jpath)).items()} if (a.only and jpath.exists()) else {}
    todo = [m_ for m_ in M if not a.only or m_[0] in a.only.split(",")]
    t0 = time.time()
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for id_, st, info in ex.map(lambda it: build_and_run(it, tmp), todo): res[id_] = (st, info); print(id_, st, info, flush=True)
    surv = [i for i in todo if res[i[0]][0] == "SURVIVED"]
    if surv and a.sva:
        print(f"re-running {len(surv)} survivors under Verilator + SVA ...")
        with cf.ThreadPoolExecutor(min(a.jobs, 2)) as ex:
            for id_, st, info in ex.map(lambda it: build_and_run(it, tmp / "sva", True), surv):
                if st == "KILLED": res[id_] = ("KILLED (SVA)", info)
                print(id_, "SVA:", st, info, flush=True)
    jpath.parent.mkdir(exist_ok=True); json.dump(res, open(jpath, "w"), indent=1)
    killed = sum(1 for k, v in res.items() if v[0].startswith("KILLED"))
    equiv = [k for k in res if k in EQUIVALENT and res[k][0] == "SURVIVED"]
    scored = len(M) - len(equiv)
    L = ["# Mutation test report", "",
         f"{len(M)} single-point mutants of `rtl/perfmon/` against `tb/tb_pm_unit.sv` (survivors re-run with SVA under Verilator). "
         f"**{killed}/{scored} non-equivalent mutants killed**" + (f"; {len(equiv)} mutant proven equivalent (not scored)." if equiv else "."), "",
         "| id | mutation | result | evidence |", "|---|---|---|---|"]
    for id_, f, old, new, desc in M:
        st, info = res[id_]
        if id_ in EQUIVALENT and st == "SURVIVED": st, info = "EQUIVALENT (not killable)", EQUIVALENT[id_]
        L.append(f"| {id_} | {desc} (`{f}`) | {st} | {info} |")
    out = ROOT / "results" / "mutation_report.md"; out.write_text("\n".join(L) + "\n")
    print(f"{killed}/{scored} killed (+{len(equiv)} equivalent) in {time.time()-t0:.0f}s -> {out}")
    sys.exit(0 if killed == scored else 1)
