#!/usr/bin/env python3
"""Regenerate patches/*.patch from rtl/supplied/ (provenance script).

Every edit must match EXACTLY ONCE or the script aborts, so the patches can only
ever contain the changes listed here.  The shipped .patch files are the
artefact; this script documents how they were produced and lets you verify them
(`make check-patches` re-runs it and diffs against the shipped patches).

  0001-perfmon-taps.patch               passive taps + sf_perfmon instance (additive only)
  optional/0002-fix-load-use-livelock.patch   F1: load-use interlock deadlock (control_core)
  optional/0003-fix-dispatch-drop.patch       F2: dispatch of a queued op is dropped (scheduler)
"""
import pathlib, shutil, subprocess, sys, tempfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
SUP = ROOT / "rtl/supplied"

def edit(text, old, new, name):
    n = text.count(old)
    if n != 1:
        sys.exit(f"EDIT FAILED ({name}): anchor found {n} times:\n{old}")
    return text.replace(old, new)

def rd(d, f): return (d / f).read_text()
def wr(d, f, t): (d / f).write_text(t)

# ---------------------------------------------------------------- 0001 taps
def taps(d):
    f = "control_core.sv"; t = rd(d, f)
    t = edit(t, "  input  logic            sync_stall\n);",
"""  input  logic            sync_stall,

  // --- Performance-monitor taps (passive observation only; see sf_perfmon) ---
  output logic            pm_load_use,
  output logic            pm_ex_valid,
  output logic [4:0]      pm_ex_opcode,
  output logic            pm_br_taken,
  output logic            pm_wb_valid
);""", f)
    t = edit(t, "\nendmodule\n",
"""
  // ---------------------------------------------------------------------------
  // Performance-monitor taps (read-only views of existing signals)
  // ---------------------------------------------------------------------------
  assign pm_load_use  = load_use_hazard;
  assign pm_ex_valid  = is_ex.valid;
  assign pm_ex_opcode = is_ex.instr.opcode;
  assign pm_br_taken  = br_taken_comb && is_ex.valid;
  assign pm_wb_valid  = mem_wb.valid;

endmodule
""", f)
    wr(d, f, t)

    f = "scheduler.sv"; t = rd(d, f)
    t = edit(t, "  output logic            sync_stall\n);",
"""  output logic            sync_stall,

  // --- Performance-monitor taps (passive observation only) ---
  output logic [NUM_TILES-1:0] pm_tile_busy,
  output logic [2:0]           pm_tgt_tile
);""", f)
    t = edit(t, "\nendmodule\n",
"""
  assign pm_tile_busy = tile_busy;
  assign pm_tgt_tile  = target_tile;

endmodule
""", f)
    wr(d, f, t)

    f = "compute_tile.sv"; t = rd(d, f)
    t = edit(t, "  output logic          noc_flit_in_ready\n);",
"""  output logic          noc_flit_in_ready,

  // --- Performance-monitor taps (passive observation only) ---
  output logic [2:0]       pm_state,        // tile FSM: 0 idle, 1 memwait, 2 vecexec, 3 tensor
  output logic             pm_vec_issue,
  output logic [LANES-1:0] pm_lane_active,  // SilicaFlux has no lane masks: all lanes active on issue
  output logic             pm_tensor_busy,
  output logic             pm_mem_fire,
  output logic             pm_mem_blocked,
  output logic             pm_mem_resp,
  output logic             pm_mem_align
);""", f)
    t = edit(t, ".alignment_err (/* tie off */),", ".alignment_err (pm_mem_align),", f)
    t = edit(t, "\nendmodule\n",
"""
  // ---------------------------------------------------------------------------
  // Performance-monitor taps
  // ---------------------------------------------------------------------------
  assign pm_state       = tstate;
  assign pm_vec_issue   = vec_issue_valid;
  assign pm_lane_active = {LANES{vec_issue_valid}};
  assign pm_tensor_busy = tensor_busy;
  assign pm_mem_fire    = mem_req_valid &&  mem_req_ready;
  assign pm_mem_blocked = mem_req_valid && !mem_req_ready;
  assign pm_mem_resp    = mem_resp_valid;

endmodule
""", f)
    wr(d, f, t)

    f = "noc_router.sv"; t = rd(d, f)
    t = edit(t, "  output logic [42:0] west_out_data,  output logic west_out_valid,  input  logic west_out_ready\n);",
"""  output logic [42:0] west_out_data,  output logic west_out_valid,  input  logic west_out_ready,

  // --- Performance-monitor tap: occupied input+output buffer slots (0..10) ---
  output logic [3:0]  pm_occ
);""", f)
    t = edit(t, "\nendmodule\n",
"""
  assign pm_occ = 4'(ivld[0]) + 4'(ivld[1]) + 4'(ivld[2]) + 4'(ivld[3]) + 4'(ivld[4])
                + 4'(ovld[0]) + 4'(ovld[1]) + 4'(ovld[2]) + 4'(ovld[3]) + 4'(ovld[4]);

endmodule
""", f)
    wr(d, f, t)

    f = "noc_interconnect.sv"; t = rd(d, f)
    t = edit(t, "  output logic [NOC_WIDTH-1:0] ej_data_flat_3\n);",
"""  output logic [NOC_WIDTH-1:0] ej_data_flat_3,

  // --- Performance-monitor tap: occupied router buffer slots, all routers (0..40) ---
  output logic [7:0] pm_occ
);""", f)
    for r in ("00", "01", "10", "11"):
        t = edit(t, f"noc_router #(.MY_ROW({r[0]}),.MY_COL({r[1]})) r{r} (\n    .clk(clk),.rst_n(rst_n),",
                    f"noc_router #(.MY_ROW({r[0]}),.MY_COL({r[1]})) r{r} (\n    .clk(clk),.rst_n(rst_n),.pm_occ(pm_occ_r{r}),", f)
    t = edit(t, "  logic [NOC_WIDTH-1:0] ej_data[0:1][0:1];",
"""  logic [3:0] pm_occ_r00, pm_occ_r01, pm_occ_r10, pm_occ_r11;
  assign pm_occ = 8'(pm_occ_r00) + 8'(pm_occ_r01) + 8'(pm_occ_r10) + 8'(pm_occ_r11);
  logic [NOC_WIDTH-1:0] ej_data[0:1][0:1];""", f)
    wr(d, f, t)

    f = "silicaflux_top.sv"; t = rd(d, f)
    t = edit(t, "  parameter int LANES = LANES_DEFAULT   // SIMD lane count per tile\n)",
"""  parameter int LANES = LANES_DEFAULT,  // SIMD lane count per tile
  parameter bit PM_EN = 1'b1            // instantiate sf_perfmon (taps are always present)
)""", f)
    t = edit(t, "  output logic [XLEN-1:0]       debug_scalar_r1   // r1 value for test observation\n);",
"""  output logic [XLEN-1:0]       debug_scalar_r1,  // r1 value for test observation

  // --- Performance monitor (sf_perfmon) CSR slave -- inert when PM_EN = 0 ---
  input  logic                  pm_csr_en,
  input  logic                  pm_csr_we,
  input  logic [7:0]            pm_csr_addr,
  input  logic [31:0]           pm_csr_wdata,
  output logic [31:0]           pm_csr_rdata,
  output logic                  pm_csr_rvalid,
  input  logic                  pm_snap_trig,
  output logic                  pm_irq
);""", f)
    t = edit(t, "    .alignment_err (/* unused */),", "    .alignment_err (pm_ctrl_mem_align),", f)
    t = edit(t, "    .mem_resp_rdata   (mem_resp_rdata),\n    .sync_stall       (sync_stall)\n  );",
"""    .mem_resp_rdata   (mem_resp_rdata),
    .sync_stall       (sync_stall),
    .pm_load_use      (pm_load_use),
    .pm_ex_valid      (pm_ex_valid),
    .pm_ex_opcode     (pm_ex_opcode),
    .pm_br_taken      (pm_br_taken),
    .pm_wb_valid      (pm_wb_valid)
  );""", f)
    t = edit(t, "    .wb_data          (sched_wb_data),\n    .sync_stall       (sync_stall)\n  );",
"""    .wb_data          (sched_wb_data),
    .sync_stall       (sync_stall),
    .pm_tile_busy     (pm_tile_busy),
    .pm_tgt_tile      (pm_tgt_tile)
  );""", f)
    t = edit(t, "        .noc_flit_in_ready(tile_noc_iready[t])\n      );",
"""        .noc_flit_in_ready(tile_noc_iready[t]),
        .pm_state        (pm_tile_state[t*3 +: 3]),
        .pm_vec_issue    (pm_vec_issue[t]),
        .pm_lane_active  (pm_lane_active[t*LANES +: LANES]),
        .pm_tensor_busy  (pm_tensor_busy[t]),
        .pm_mem_fire     (pm_mem_fire[t]),
        .pm_mem_blocked  (pm_mem_blocked[t]),
        .pm_mem_resp     (pm_mem_resp[t]),
        .pm_mem_align    (pm_mem_align[t])
      );""", f)
    t = edit(t, "    .ej_data_flat_3    (/* unused */)\n  );",
"""    .ej_data_flat_3    (/* unused */),
    .pm_occ            (pm_noc_occ)
  );""", f)
    t = edit(t, "  // Tile interface (chiplet boundary) for tile 0\n",
"""  // Performance-monitor tap wires (observation only)
  logic                   pm_load_use, pm_ex_valid, pm_br_taken, pm_wb_valid;
  logic [4:0]             pm_ex_opcode;
  logic [NUM_TILES-1:0]   pm_tile_busy;
  logic [2:0]             pm_tgt_tile;
  logic [NUM_TILES*3-1:0] pm_tile_state;
  logic [NUM_TILES-1:0]   pm_vec_issue, pm_tensor_busy;
  logic [NUM_TILES*LANES-1:0] pm_lane_active;
  logic [NUM_TILES-1:0]   pm_mem_fire, pm_mem_blocked, pm_mem_resp, pm_mem_align;
  logic                   pm_ctrl_mem_align;
  logic [7:0]             pm_noc_occ;

  // Tile interface (chiplet boundary) for tile 0
""", f)
    t = edit(t, "  // ---------------------------------------------------------------------------\n  // Halt Detection",
"""  // ---------------------------------------------------------------------------
  // Performance Monitor (passive; no output reaches the core)
  // ---------------------------------------------------------------------------
  logic [NUM_TILES-1:0] pm_tok_valid, pm_noc_inj_fire, pm_noc_inj_blocked;
  logic                 pm_is_valid;
  logic [4:0]           pm_is_opcode;
  assign pm_is_valid  = id_is.valid;           // plain wires: Icarus mis-sizes nested struct
  assign pm_is_opcode = id_is.instr.opcode;    // member selects used directly in port lists
  generate
    for (genvar pt = 0; pt < NUM_TILES; pt++) begin : g_pm_tok
      assign pm_tok_valid[pt] = tile_token_valid[pt];
    end
  endgenerate
  assign pm_noc_inj_fire[0]    = noc_inject_valid[0][0] &&  noc_inject_ready[0][0];
  assign pm_noc_inj_fire[1]    = noc_inject_valid[0][1] &&  noc_inject_ready[0][1];
  assign pm_noc_inj_fire[2]    = noc_inject_valid[1][0] &&  noc_inject_ready[1][0];
  assign pm_noc_inj_fire[3]    = noc_inject_valid[1][1] &&  noc_inject_ready[1][1];
  assign pm_noc_inj_blocked[0] = noc_inject_valid[0][0] && !noc_inject_ready[0][0];
  assign pm_noc_inj_blocked[1] = noc_inject_valid[0][1] && !noc_inject_ready[0][1];
  assign pm_noc_inj_blocked[2] = noc_inject_valid[1][0] && !noc_inject_ready[1][0];
  assign pm_noc_inj_blocked[3] = noc_inject_valid[1][1] && !noc_inject_ready[1][1];

  generate
    if (PM_EN) begin : g_pm
      sf_perfmon #(.NT(NUM_TILES), .LANES(LANES)) u_pm (
        .clk(clk), .rst_n(rst_n),
        .csr_en_i(pm_csr_en), .csr_we_i(pm_csr_we), .csr_addr_i(pm_csr_addr),
        .csr_wdata_i(pm_csr_wdata), .csr_rdata_o(pm_csr_rdata), .csr_rvalid_o(pm_csr_rvalid),
        .snap_trig_i(pm_snap_trig), .irq_o(pm_irq),
        .is_valid_i(pm_is_valid), .is_opcode_i(pm_is_opcode),
        .id_stall_i(id_stall), .load_use_i(pm_load_use), .sync_stall_i(sync_stall),
        .flush_i(pipeline_flush_int), .br_taken_i(pm_br_taken),
        .ex_valid_i(pm_ex_valid), .ex_opcode_i(pm_ex_opcode), .wb_valid_i(pm_wb_valid),
        .sched_valid_i(sched_valid), .sched_ready_i(sched_ready),
        .tok_valid_i(pm_tok_valid), .tgt_tile_i(pm_tgt_tile),
        .tile_busy_i(pm_tile_busy), .tile_done_i(tile_done_flat), .tile_state_i(pm_tile_state),
        .vec_issue_i(pm_vec_issue), .lane_active_i(pm_lane_active), .tensor_busy_i(pm_tensor_busy),
        .mem_fire_i   ({mem_req_valid &&  mem_req_ready, pm_mem_fire}),
        .mem_blocked_i({mem_req_valid && !mem_req_ready, pm_mem_blocked}),
        .mem_resp_i   ({mem_resp_valid,                  pm_mem_resp}),
        .mem_align_i  ({pm_ctrl_mem_align,               pm_mem_align}),
        .noc_occ_i(pm_noc_occ), .noc_inj_fire_i(pm_noc_inj_fire), .noc_inj_blocked_i(pm_noc_inj_blocked)
      );
    end else begin : g_no_pm
      assign pm_csr_rdata  = 32'd0;
      assign pm_csr_rvalid = 1'b0;
      assign pm_irq        = 1'b0;
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // Halt Detection""", f)
    wr(d, f, t)

# ---------------------------------------------------------------- 0002 F1
def fix_load_use(d):
    f = "control_core.sv"; t = rd(d, f)
    t = edit(t, "    end else if (pipeline_flush) begin\n      is_ex <= '0;\n    end else if (!id_stall) begin",
"""    end else if (pipeline_flush) begin
      is_ex <= '0;
    end else if (load_use_hazard) begin
      // OPTIONAL FIX F1: let the LOAD leave EX and insert a bubble.  In the supplied RTL
      // is_ex is frozen while id_stall is high, so load_use_hazard (which depends on
      // is_ex) can never clear: any LOAD followed by a dependent op deadlocks.
      is_ex <= '0;
    end else if (!id_stall) begin""", f)
    wr(d, f, t)

# ---------------------------------------------------------------- 0003 F2
def fix_dispatch(d):
    f = "scheduler.sv"; t = rd(d, f)
    old = """  assign instr_ready = !sync_stall && (
    (target_tile==3'd0 && (tile_tok_ready_0 || !tile_busy[0])) ||
    (target_tile==3'd1 && (tile_tok_ready_1 || !tile_busy[1])) ||
    (target_tile==3'd2 && (tile_tok_ready_2 || !tile_busy[2])) ||
    (target_tile==3'd3 && (tile_tok_ready_3 || !tile_busy[3])));"""
    new = """  // OPTIONAL FIX F2: report ready only when the token is actually dispatched.  In the
  // supplied RTL instr_ready used (tok_ready || !busy) while dispatch_ok needs
  // (tok_ready && !busy); on the cycle a tile completes tok_ready=1 and busy=1, so the
  // control core retired the queued op without any token being sent (op silently lost).
  assign instr_ready = !sync_stall && (
    (target_tile==3'd0 && (tile_tok_ready_0 && !tile_busy[0])) ||
    (target_tile==3'd1 && (tile_tok_ready_1 && !tile_busy[1])) ||
    (target_tile==3'd2 && (tile_tok_ready_2 && !tile_busy[2])) ||
    (target_tile==3'd3 && (tile_tok_ready_3 && !tile_busy[3])));"""
    t = edit(t, old, new, f)
    wr(d, f, t)

PATCHES = [("0001-perfmon-taps.patch", [taps]),
           ("optional/0002-fix-load-use-livelock.patch", [fix_load_use]),
           ("optional/0003-fix-dispatch-drop.patch", [fix_dispatch])]

def build_patch(fns, out):
    with tempfile.TemporaryDirectory() as tmp:
        tmp = pathlib.Path(tmp)
        a, b = tmp / "a", tmp / "b"
        shutil.copytree(SUP, a); shutil.copytree(SUP, b)
        for fn in fns: fn(b)
        r = subprocess.run(["diff", "-ruN", "a", "b"], cwd=tmp, capture_output=True, text=True)
        txt = r.stdout.replace("a/", "a/rtl/supplied/", 1) if False else r.stdout
        # keep paths simple: a/<file> b/<file>; strip timestamps for reproducibility
        lines = []
        for ln in txt.splitlines():
            if ln.startswith(("--- ", "+++ ")):
                ln = ln.split("\t")[0]
            lines.append(ln)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text("\n".join(lines) + "\n")

if __name__ == "__main__":
    check = "--check" in sys.argv
    for name, fns in PATCHES:
        dest = ROOT / "patches" / name
        if check:
            with tempfile.TemporaryDirectory() as t:
                tmp = pathlib.Path(t) / "x.patch"; build_patch(fns, tmp)
                same = tmp.read_text() == dest.read_text()
                print(f"{'OK  ' if same else 'DIFF'} {name}")
                if not same: sys.exit(1)
        else:
            build_patch(fns, dest); print("wrote", dest.relative_to(ROOT))
