#!/usr/bin/env python3
"""Create the distributable zip (no git involved):  python3 scripts/package.py [out.zip]

Contains sources, docs, patches, verification collateral and the measured results; excludes build products
(build/), caches and simulator binaries.  A MANIFEST.sha256 of every packaged file is embedded.
"""
import hashlib, pathlib, sys, zipfile
ROOT = pathlib.Path(__file__).resolve().parent.parent
TOP = "aureom-sfperf"
INCLUDE = ["README.md", "Makefile", "docs", "rtl", "patches", "sva", "tb", "scripts", "sfperf", "spec", "tests", "results"]
SKIP_DIRS = {"__pycache__", "build", ".pytest_cache"}
SKIP_SUFFIX = {".pyc", ".vvp", ".o"}

def files():
    for name in INCLUDE:
        p = ROOT / name
        if p.is_file(): yield p
        else:
            for f in sorted(p.rglob("*")):
                if f.is_file() and not (set(f.relative_to(ROOT).parts) & SKIP_DIRS) and f.suffix not in SKIP_SUFFIX: yield f

def main(out):
    fl = list(files()); lines = []
    for f in fl: lines.append(f"{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.relative_to(ROOT).as_posix()}")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in fl:
            info = zipfile.ZipInfo.from_file(f, f"{TOP}/{f.relative_to(ROOT).as_posix()}")
            if f.suffix in (".sh", ".py") and f.parent.name == "scripts": info.external_attr = 0o755 << 16
            else: info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, f.read_bytes())
        z.writestr(f"{TOP}/MANIFEST.sha256", "\n".join(lines) + "\n")
    print(f"{out}: {len(fl)} files, {pathlib.Path(out).stat().st_size/1e6:.1f} MB")

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else str(ROOT / "build" / "aureom-sfperf.zip"))
