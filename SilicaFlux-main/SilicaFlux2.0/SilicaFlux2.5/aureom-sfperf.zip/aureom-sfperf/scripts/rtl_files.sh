#!/usr/bin/env bash
# Print the RTL compile order for a variant directory.   usage: rtl_files.sh <variant_dir> <pm|nopm>
D=$1; M=${2:-nopm}
for f in silicaflux_pkg alu forwarding_unit fetch_unit decoder register_bank vector_engine tensor_unit memory_controller control_core scheduler compute_tile noc_router noc_interconnect tile_interface; do echo "$D/$f.sv"; done
if [ "$M" = pm ]; then
  R="rtl/perfmon"   # relative to the project root (all scripts run from there; WASM tools cannot resolve absolute paths)
  for f in sf_pm_pkg sf_pm_counter sf_pm_events sf_pm_regs sf_perfmon; do echo "$R/$f.sv"; done
fi
echo "$D/silicaflux_top.sv"
