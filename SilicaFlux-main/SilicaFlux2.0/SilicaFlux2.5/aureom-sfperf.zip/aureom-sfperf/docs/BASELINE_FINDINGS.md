# Findings about the supplied RTL

While building the monitor the supplied SilicaFlux RTL was exercised far outside its own testbenches (whose top-level test
only prints `[INFO] ... observe waveforms`). Twelve behaviours were found that matter for performance measurement or for
correctness. **None of them was changed in the instrumented design**: the monitor measures the core as supplied, and where a
defect is visible to a counter the monitor flags it (`bottleneck.py`).

Every row was reproduced by a directed program run on the supplied core: `python3 -m sfperf.findings results/findings`
(F1 and F2 are measured by workloads of the main suite). The evidence column is copied from `results/findings/findings.json`
and `results/REPORT.md`, i.e. read back from simulation.

| # | Finding | Evidence (measured) | Effect on measurement | Monitor sees it as |
|---|---|---|---|---|
| **F1** | **Load-use interlock livelocks.** `is_ex` is frozen while `id_stall` is high, but `load_use_hazard` is computed from `is_ex`, so it can never clear | `dep_load_use`: 5 instructions issue, then 1,492 consecutive `SLOT_STALL_DEP` slots (`STALL_STREAK_MAX` = 1492) until the cycle limit; watchdog trips | the only RAW stall mechanism hangs the machine | `HANG` defect, `STALL_STREAK_MAX`, `FLAGS.WDOG_TRIP` |
| **F2** | **A queued op is silently dropped.** `instr_ready` uses `tok_ready \|\| !busy`, `dispatch_ok` uses `tok_ready && !busy`; on the cycle a tile completes both `tok_ready` and `busy` are 1, so the control core retires the op although no token was sent | `compute_tensor_queue`: 8 MATMULs issued, 4 lost (`DROP_OP` = 4; 5 tokens dispatched incl. the DFSYNC). `compute_vector_queue`: 16 of 32 VMULs lost. `mem_conflict_queue`: 4 of 8 DFLOADs lost | every dispatch that has to wait is lost: contention costs time *and* work | `DROP_OP`, `LOST OPS` defect |
| **F3** | **V-format instructions have no tile field**, so every vector/tensor op executes on tile 0 (VLOAD/VSTORE also use address 0) | `TILE_TOK_0` = 3, `TILE_TOK_1..3` = 0 for three VADDs | one vector engine and one tensor unit serve the whole cluster | `TILE_TOK_t`, `SLOT_STALL_EXEC_*` |
| **F4** | **DFEXEC / DFMAP never complete.** The tile FSM's `default:` arm returns to idle without `tile_done`, so the scheduler's `tile_busy` bit stays set and the next DFSYNC waits forever. This also means the NoC (only fed by DFEXEC completion) is unreachable | 2 tokens dispatched, 1 completed, `Q_TOK_NOW` = 1, 595 of 599 slots barrier-stalled, never drains | hangs; no program using DFEXEC can finish | `TOK_DISPATCHED - RET_TILE`, `Q_TOK_NOW`, `STUCK TOKENS` |
| **F5** | **Wrong-path instructions commit after a taken branch.** Flush and fetch redirect are both registered, one cycle after resolution, so instructions already in flight still reach write-back (the leak path of the second committed instruction was not traced) | after one taken BEQ, wrong-path registers r10 = 111 and r14 = 555 were written (the correct value is 0 for both) | issued/retired counts include wrong-path work; correctness of any branching code is at risk | `BRANCH_TAKEN`; cost = `SLOT_BUBBLE_CTRL` = 3 per taken branch |
| **F6** | **A stalled EX instruction is replayed into write-back every stall cycle** (`ex_mem` loads `is_ex` each cycle regardless of stall) | barrier-stall program: 174 cycles with `wb_valid` but only 4 distinct instructions retired | a naive `wb_valid` counter over-counts retirements (~40x in this program) | unique-instruction tag (`RET_SCALAR` = 4) |
| **F7** | **`halt` is a fetch-time flag.** It is set when HALT is *fetched*; fetch, the pipeline and the tiles keep running | halt at cycle 5, last tile completion at cycle 39 | "halt" cannot delimit a measurement | `prog_done` = HALT *issued*; `SLOT_IDLE` thereafter |
| **F8** | **Tile results never reach architectural state.** `v_wr_en` is tied to 0 and the scheduler's write-back address `wb_reg` is hard-wired to register 0 (writes to r0 are discarded) | VADD/DOT/REDUCE produced non-zero tile results (2 observed), but v3 stayed at its preloaded value and no scalar register changed | vector/tensor kernels have no architecturally visible result: only timing and the tile-completion events can be compared | `RET_TILE` counts completions; architectural trace includes `tile_done` payloads |
| **F9** | **Out-of-range select** `noc_flit_in.src_col[2:0]` of a 2-bit field (`compute_tile.sv:226`) | yosys-slang: `cannot select range of [2:0] from 'logic[1:0]' [-Wrange-oob]` | the supplied RTL does not elaborate in a strict front end without `-Wno-range-oob`; this flag is used (and disclosed) for the overhead flow | n/a |
| **F10** | **No forwarding or interlock for a distance-1 RAW dependence** (the instruction in EX is not a forwarding source). `forwarding_unit.sv` and `alu.sv` are compiled but never instantiated | `ADD r3,r2,r2` right after `MOV r2,3` gave 0 (expected 6); distance 2 and 3 gave 6; `SLOT_STALL_DEP` = 0 | dependence on the previous instruction is *invisible to every stall counter*; it produces wrong data instead | (nothing to count: the hazard has no stall) |
| **F11** | **Scalar LOAD returns the address, not the data; STORE stores zero** (load data arrives after the write-back stage has sampled; the I-format has no `rs2`, so STORE data is r0) | `LOAD r11,[64]` left r11 = 64 (the memory word holds 5016); `STORE` overwrote word 19 (5019) with 0 | scalar memory ops generate real traffic and latency (2 and 1 cycles) but no useful data | `MEM_*`, `ISS_SMEM` |
| **F12** | **Scalar memory requests ignore `ready`.** `control_core` fires a one-cycle request per LOAD/STORE; the controller only samples `req_valid` while idle, so a request in the cycle after another is lost | two back-to-back LOADs: 2 issued, 1 accepted, 1 blocked; `mem_scalar_backtoback`: 16 issued, 8 blocked | half of back-to-back scalar accesses never happen | `MEM_REQ_BLOCKED`, `LOST MEMORY REQUESTS` defect |

## The two optional fixes

`patches/optional/0002-fix-load-use-livelock.patch` (F1, 5 added lines incl. comment): when `load_use_hazard` holds, bubble `is_ex` so the LOAD
leaves EX and the hazard can clear.
`patches/optional/0003-fix-dispatch-drop.patch` (F2, 4 lines changed plus comments): `instr_ready` uses `tok_ready && !busy`, i.e. ready means a token
is dispatched.

They exist only so that the dependency and contention bottlenecks can be *measured* rather than shown to hang or to lose work.
They are separate from the instrumentation, off by default, and nothing in `rtl/perfmon` depends on them. With them applied:

* `dep_load_use`: 32 load-use pairs cost exactly 32 `SLOT_STALL_DEP` slots (one per pair), 237 cycles instead of a hang.
* `compute_tensor_queue`: 8 MATMULs all execute (`DROP_OP` = 0, 9 tokens incl. DFSYNC), 605 cycles instead of 325 --
  the "faster" supplied run was faster because it skipped half the work.
* Ten workloads (`compute_alu`, `mem_scalar_backtoback`, `dep_sync_chain`, `dep_alu_chain`, `div_branch_p000..p100`,
  `div_loop_taken`) produce **bit-identical counters in all 57 values** in both configurations; the other eight workloads
  exercise F1/F2 paths and differ (`results/summary.csv`).

Neither fix is a complete repair of the core: F3-F12 remain. They were not attempted because they change the ISA or the
write-back architecture, which is outside the scope of a performance monitor.

## How these shaped the monitor

| Monitor decision | Because |
|---|---|
| unique-instruction freshness tag for retirement | F6 |
| `DROP_OP` / `DROP_SYNC` counters and the conservation identity `ISSUED = RET_SCALAR + RET_TILE + DROP_SYNC + DROP_OP` | F2, F4 |
| HALT-at-issue (`prog_done`) instead of the core's `halt` | F7 |
| stall-streak peak and watchdog | F1, F4 |
| `MEM_REQ_BLOCKED` on the scalar path | F12 |
| redirect shadow of 2 cycles, flush slot counted as control loss | F5 (measured: flush cycle + 2 bubble cycles = 3 slots per taken branch) |
| architectural trace compares tile-completion payloads, SRAM contents and the register files | F8 |
