# Verification

The monitor has to satisfy three different claims, and each is checked by a different mechanism so that no single
author's assumption (including mine) decides the outcome.

| Claim | Mechanism | Where |
|---|---|---|
| **A. The counters implement the specification** (classification, tracking, window semantics, overflow, CSR, watchdog) | 1) directed + constrained-random unit test, lock-step against a behavioural reference model, **every counter every cycle**, at CW = 40 and CW = 8; 2) 25 SVA properties (generated per counter where applicable); 3) an **independent** Python re-derivation from the written spec | `tb/tb_pm_unit.sv`, `tb/pm_ref_model.sv`, `sva/sf_pm_sva.sv`, `sfperf/trace_check.py` |
| **B. The tests would notice a bug** | 26 seeded single-point mutants of the RTL | `scripts/mutation_test.py` |
| **C. The instrumentation does not change the core** | instrumented vs uninstrumented: byte-identical architectural trace and cycle-exact fingerprint on every workload and on random programs | `tb/tb_sys.sv`, `sfperf/fuzz.py` |

## 1. Unit testbench (`tb_pm_unit`)

Two DUTs (CW = 40 and CW = 8 with `ENABLE_AT_RESET`) see identical constrained-random taps (six traffic modes: mostly-issue,
load-use heavy, dispatch-blocked heavy, barrier heavy, flush heavy, starved). Each is compared with `pm_ref_model` on every
cycle (all 57 live counters, overflow bits, watchdog and `prog_done`) and, after every snapshot, through the real CSR path.
Directed tests: reset values and unmapped reads; ENABLE gating and its one-cycle latency; a 17-case classification table (each
expected slot written by hand, not taken from the model: priority of flush > barrier > load-use, DFSYNC held at dispatch,
out-of-range tile target, redirect shadow length, HALT -> IDLE); snapshot atomicity and shadow stability; `SNAP_CLR` window
tiling checked against an **independent tally of enabled cycles**; `CLEAR`; hardware trigger; command precedence; watchdog and
its flag; interrupt; 40-bit HI word, exact-fit versus lost-increment saturation, sticky overflow; CW = 8 saturation of every
counter and "peaks/gauges never overflow"; asynchronous reset mid-run; a 7,200-cycle random soak with random commands.

## 2. Assertions (`sva/sf_pm_sva.sv`)

Concurrent assertions, compiled with `-DSF_PM_SVA` (Verilator `--assert`; usable in commercial simulators and formal):

* **[TAP]** protocol of the integration: a stall always has a cause; a token implies a completed handshake; at most one tile
  accepts per cycle. (These check *the core*, so they fire if the taps are mis-wired.)
* **[SPEC]** slot one-hot; issue class one-hot and iff-issue; everything after HALT is IDLE; `prog_done` sticky; every counter
  monotone (except gauges) and sticky overflow; accumulate counters stay saturated; peak/gauge never overflow; `CYCLES`
  advances by exactly 1 per counted cycle; counters hold while disabled; **invariants I1/I2 on every snapshot and on the
  live counters at every cycle**; shadow stable without a command; `SNAP_SEQ` +1 per command; snapshot equals the live
  value at the start of the command cycle; `rvalid` follows a read by exactly one cycle.
* **[PASS]** no X on any monitor output.

The full unit testbench is run under Verilator with all of them enabled (`make sva`). A testbench that deposits values
directly into counters (to reach 2^32) sets `tb_sva_off` for that period, because a deposit is not a reachable transition:
the assertion `ap_cycles_step` correctly flagged the first attempt.

## 3. Independent re-derivation (`sfperf/trace_check.py`)

Written by a separate agent that was given **only** `docs/METRICS.md`, `spec/pm_counters.json` and the data files, and was
forbidden from reading any RTL or testbench. It replays `trace.csv` (every tap, every cycle), applies the commands in `cmds.csv`,
and compares all 57 counters, the FLAGS and the overflow bitmap of every row of `snapshots.csv`.

Its first run found real defects in this project's deliverables, all fixed: (1) `snapshots.csv:cmd_cycle` was one cycle off
against `cmds.csv` (testbench bug); (2) the spec left a dozen behaviours open (what `CLEAR` leaves alone, `SNAP_CLR` and the
overflow bits, a `CLEAR` combined with a snapshot, `seq` semantics, the word "shadow" used for two things, the
`WDOG_TRIP` description disagreeing with B.7); (3) it listed the behaviours the data did **not** pin down. Those gaps were then
covered by extending the random dump (VSTORE and the reserved opcodes, stall-without-cause, quiet phases that trip the
watchdog, snapshots while counting is disabled, combined CLEAR/SNAP_CLR/SNAPSHOT writes, unread snapshot commands), and the
spec was tightened. It now passes on every run directory: see `results/trace_check.txt`.

Not covered by this checker, by construction: counter saturation and overflow (covered by the unit testbench against the model),
`snap_trig_i` (covered by the unit testbench), tile-FSM states 4-7.

## 4. Instrumented vs uninstrumented (claim C)

Each workload and each random program is run on four builds of the core and compared:

| | supplied | fixed (F1+F2) |
|---|---|---|
| uninstrumented | `sup` (pristine) | `fix` |
| instrumented | `pm` (+ patch 0001, CSR snapshots read **during** the run) | `pmfix` |
| taps wired, monitor removed (`PM_EN=0`) | `pm_nopm` | |

For every run `arch.csv` (every scalar register write with its cycle, every tile completion with its payload, every control-core
memory request, HALT cycle, final scalar/vector registers and all five scratchpads) must be **byte-identical**, and the
cycle count and an FNV-1a fingerprint of the core's pipeline control, scheduler scoreboard, tile FSM states, register-file write port, control-core memory interface and top-level outputs, mixed in every cycle, must match. The comparison window ends at a point decided
only by core signals (halt + drained, or the cycle limit), so the instrumented run's CSR read-out cannot move it.

Three testbench problems were found and fixed by this check and the checks around it (worth knowing about): the end of the run
used to depend on snapshot read-out; in a hung run the architectural logger kept appending replayed-LOAD events during that
read-out; and the vector registers were being wiped by the register file's asynchronous reset after my backdoor preload (so
vector data had been all zeros -- counters were unaffected, data values were). A fourth item was a flaw in a *stated
invariant*, not in any RTL: the fuzzer's first run flagged `MEM_RESP > MEM_REQ_ACCEPTED` in some `SNAP_CLR` windows, because a
request can be accepted in one window and answered in the next. The cumulative identity held at every window boundary
(checked on the failing seeds); I5 is now stated strictly per epoch and with a 5-request slack per window.
The random programs (`sfperf/fuzz.py`) contain reserved opcodes, tile ids 4-7, misaligned accesses, DFEXEC/DFMAP, load-use
pairs, back-to-back dispatch and arbitrary branch targets.

Results: `results/REPORT.md` section 6 (per workload) and `results/fuzz.txt`.

## 5. Mutation testing

26 single-point mutants (priority swaps, a wrong shadow length, retirement without replay filtering, a drop detector that
ignores tokens, an outstanding tracker that never clears, wrap instead of saturate, non-sticky overflow, `CLEAR` leaving the
shadow, HI word reading LO, off-by-one watchdog, counters ignoring ENABLE, missing `SNAP_SEQ` increment, FLAGS without
PROG_DONE, wrong command precedence, a degraded peak counter, and others). A mutant is killed if the unit testbench reports a
failure, fails to compile or hangs; survivors are re-run with SVA. Result: **25/25 non-equivalent mutants killed**
(`results/mutation_report.md`).

What the first run taught (it killed 23/26): two survivors were real gaps in the unit testbench, not in the RTL -- its random
opcode pool never contained `VSTORE`, and the interrupt test never checked that `irq_o` stays low when `IRQ_EN` is clear. Both
tests were added and the suite re-run in full. The third survivor, M20 (snapshot not suppressed by `CLEAR`), is an
**equivalent mutant**: `snap_fire` is consumed only by an `else if` that already follows `if (cmd_clear)`, so the guard is
redundant and no test can distinguish it. It is reported as such and excluded from the score rather than hidden.

## 6. What is **not** verified

* No gate-level simulation, no formal proof, no FPGA/ASIC implementation, no timing closure.
* The monitor's behaviour with `NT != 4` (see `ARCHITECTURE.md`).
* Behaviour on a core other than the supplied one.
* The supplied core's own functional correctness (it has none to speak of: `BASELINE_FINDINGS.md`).
