# Analysis tool (`sfperf`)

Everything the Python side knows about the counters comes from `spec/pm_counters.json` (the same file that generates the RTL
index header), so the decoder cannot drift from the hardware.

## Commands (run from the project root)

```bash
python3 -m sfperf run        # build the 4 simulators, run all 18 workloads x 2 configurations, instrumented + uninstrumented twin
python3 -m sfperf report     # results/REPORT.md, summary.csv, summary.json
python3 -m sfperf charts     # results/charts/*.png + the data behind every chart as *.csv
python3 -m sfperf analyze results/supplied/mem_burst_parallel    # one run: breakdown, evidence, advice, defects
python3 -m sfperf.trace_check --summary results/supplied results/fixed build/dump   # independent re-derivation
python3 -m sfperf.findings results/findings        # reproduce each documented defect of the supplied RTL
python3 -m sfperf.fuzz --seeds 20                  # instrumented == uninstrumented on random programs
```

Library entry points: `sfperf.snapshot.load()` (read a `snapshots.csv`), `sfperf.metrics.derive()` (derived metrics),
`sfperf.bottleneck.classify()` (attribution), `sfperf.charts.*`.

## Reading the output of `analyze`

```
issue-slot breakdown (share of active cycles):         <- mutually exclusive, sums to 100 %
memory: avg outstanding 3.43 peak 4 latency 33.0       <- Little's law from MEM_OUT_SUM / MEM_RESP
primary bottleneck: [memory] barrier waiting on memory transactions (86%)
   evidence: MEM_BUSY_CYC covers 100% of it            <- the counters the verdict rests on
DEFECT: ...                                            <- things that are wrong with the core, not slow
```

## How the bottleneck is chosen (`sfperf/bottleneck.py`)

The classifier sees only the 57 counters of the window(s); it is never told what the workload is.

1. **Defects first** (they invalidate a performance reading): a stall streak >= 200 cycles *and* >= 50 % of the run
   (`HANG`); `DROP_OP > 0` (ops consumed without dispatch); `MEM_REQ_BLOCKED > 0` (lost scalar memory requests);
   dispatched tokens that never completed.
2. **Slot categories**: each category that costs >= 5 % of active cycles becomes a finding, ranked by share:

| Category | Finding family |
|---|---|
| `STALL_DEP` | dependency |
| `BUBBLE_CTRL` | divergence (control-flow) |
| `STALL_EXEC_VEC`, `STALL_EXEC_TENSOR` | compute (execution-unit contention) |
| `STALL_MEM` | memory |
| `STALL_SYNC` | **attributed to what the barrier waits on**: if a unit was busy for >= 60 % of the barrier-stall cycles -> that unit (tensor/vector = compute, memory = memory); otherwise plain dataflow dependency |
| `STALL_DISP_OTHER`, `BUBBLE_FRONT` | front-end / turnaround |

3. If nothing reaches 5 %, the verdict is **issue-bound**: the single issue slot is the limit (IPC cannot exceed 1).

The 5 % and 60 % thresholds are constants at the top of the file, are not tuned per workload, and are the main judgement
calls in the tool. A barrier is an *expression* of a wait, not a cause; that is why `STALL_SYNC` is attributed rather than
reported as "barrier".

## Charts

| File | What it shows |
|---|---|
| `cpi_stack_{supplied,fixed}.png` | 100 % stacked issue-slot breakdown per workload (+ `_dark` variant) |
| `timeline_mixed_kernel_*.png` | the same breakdown per `SNAP_CLR` window: how the bottleneck moves between phases |
| `divergence_sweep_*.png` | control-flow slots lost and IPC vs measured taken-branch rate |
| `memory_parallelism_*.png` | outstanding requests, peak, Little's-law latency, memory share of lost slots |
| `utilisation_*.png` | heat map of unit activity, memory parallelism and queue occupancy |
| `supplied_vs_fixed.png` | where the two optional fixes change behaviour (run length, ops lost) |
| `overhead.png` | synthesis proxies for supplied / taps-only / instrumented |

Every PNG has a sibling `.csv` with the plotted data (table view), and the 7-hue stacked charts print the share inside every
segment >= 7 %.

Colour: the categorical palette is the validated default of the dataviz method, assigned in fixed slot order and folded to
seven hues (vector + tensor contention are one segment, dispatch-other + front-end are one segment) because a stack must not
cycle hues. Validator result, both modes: lightness band, chroma floor, adjacent-pair CVD separation (worst dE 9.1 light / 8.4
dark) and normal-vision floor (19.6 / 19.3) all pass. The validator warns that three light-mode slots (aqua, yellow, magenta)
fall below 3:1 contrast against the surface; the *relief rule* is therefore applied -- visible labels in the segments, a legend,
and the CSV table next to each image.

## Limitations of the analysis

* The verdicts are counter-based and rule-based. They tell you *where issue slots go*, not what to change in a kernel; the
  `advice` strings are starting points.
* `dep_sync_chain` is classified as memory-bound: the barrier is waiting on a producer's memory latency, which is the honest
  reading; there is no separate "pure dependency" cost on this core to isolate beyond the load-use interlock.
* Counters of a snapshot with an overflow bit are not evaluated (`snapshot.check_invariants`).
