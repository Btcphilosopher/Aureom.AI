# Register map (generated)

Generated from `spec/pm_counters.json` by `scripts/gen_pm.py`. Do not edit by hand.

All registers are 32-bit, word addressed (`csr_addr` is a word index). Counter values are read from the
**snapshot shadow**, never from the live counters (see `ARCHITECTURE.md`, *Snapshot and read consistency*).

## Control / status registers

| Word addr | Name | Access | Description |
|---|---|---|---|
| 0x00 | ID | RO | `0x5346504D` (`SFPM`) |
| 0x01 | VERSION | RO | `{major[23:16], minor[15:8], patch[7:0]}` of the RTL/spec |
| 0x02 | GEOM | RO | `{NUM_TILES[31:24], LANES[23:16], CW[15:8], NC[7:0]}` |
| 0x03 | FEATURES | RO | bit0 NOC_TAP wired, bit1 ENABLE_AT_RESET |
| 0x04 | CTRL | RW | bit0 ENABLE, bit1 IRQ_EN (level), bit8 SNAPSHOT*, bit9 SNAP_CLR*, bit10 CLEAR* (*write-1 command, reads 0) |
| 0x05 | STATUS | RO | bit0 SNAP_VALID, bit1 ENABLED (live), bit2 OVF_LIVE (live sticky), bit3 WDOG_LIVE (live sticky) |
| 0x06 | SNAP_SEQ | RO | Increments on every SNAPSHOT, SNAP_CLR and CLEAR (32-bit wrap; compare for equality only) |
| 0x07 | WDOG_THRESH | RW | Watchdog threshold in enabled cycles of no progress; 0 disables |
| 0x08 | FLAGS | RO | Shadow flags captured with the snapshot: bit0 OVF_ANY, bit1 WDOG_TRIP, bit2 PROG_DONE |
| 0x10.. | OVF[k] | RO | Shadow per-counter sticky overflow bitmap; bit `i%32` of word `i//32` is counter `i` |
| 0x20+2i | CNT_i_LO | RO | Shadow counter i bits [31:0] |
| 0x20+2i+1 | CNT_i_HI | RO | Shadow counter i bits [CW-1:32] (zero-extended) |

## Counters

Kind: **count** = +0/+1 per enabled cycle; **sum** = + small integer per enabled cycle; **peak** = running maximum;
**gauge** = value sampled in the last enabled cycle before the snapshot. Exclusive set `slot` partitions CYCLES;
exclusive set `issue_class` partitions SLOT_ISSUE.

| Idx | Word addr (LO) | Name | Kind | Group | Exclusive set | Description |
|---|---|---|---|---|---|---|
| 0 | 0x20 | `CYCLES` | count | time | - | Enabled cycles. Every enabled cycle is counted in exactly one SLOT_* counter (invariant I1). |
| 1 | 0x22 | `SLOT_ISSUE` | count | slot | slot | Slot used: an instruction advanced from the IS stage into EX (== instructions issued). Excludes slots squashed by a branch flush and everything after the HALT instruction issued. |
| 2 | 0x24 | `SLOT_STALL_DEP` | count | slot | slot | Slot lost to the scalar RAW (load-use) interlock. |
| 3 | 0x26 | `SLOT_STALL_SYNC` | count | slot | slot | Slot lost waiting at a DFSYNC barrier: scheduler barrier active with tiles busy, or the DFSYNC itself held at dispatch behind a busy tile. |
| 4 | 0x28 | `SLOT_STALL_EXEC_VEC` | count | slot | slot | Dispatch of a non-DFSYNC op blocked because the target tile's vector engine is busy (execution-unit contention). |
| 5 | 0x2A | `SLOT_STALL_EXEC_TENSOR` | count | slot | slot | Dispatch of a non-DFSYNC op blocked because the target tile's tensor unit is busy (execution-unit contention). |
| 6 | 0x2C | `SLOT_STALL_MEM` | count | slot | slot | Dispatch of a non-DFSYNC op blocked because the target tile is occupied by a memory transaction (memory backpressure). |
| 7 | 0x2E | `SLOT_STALL_DISP_OTHER` | count | slot | slot | Dispatch blocked, target tile not in a compute/memory state (accept/turnaround cycle, tile stuck on a token that never completes, or target tile id out of range). |
| 8 | 0x30 | `SLOT_BUBBLE_CTRL` | count | slot | slot | Slot lost to control flow: the cycle a taken branch squashes the pipeline plus the redirect-shadow cycles with no valid instruction at IS. |
| 9 | 0x32 | `SLOT_BUBBLE_FRONT` | count | slot | slot | No valid instruction at IS, no stall, not in a redirect shadow, but work is still in flight (front-end starved / pipeline fill). |
| 10 | 0x34 | `SLOT_IDLE` | count | slot | slot | No useful work: machine empty before the first instruction, or any cycle after the HALT instruction issued. |
| 11 | 0x36 | `ISS_NOP` | count | issue_class | issue_class | Issued NOP / reserved / HALT opcodes. |
| 12 | 0x38 | `ISS_SALU` | count | issue_class | issue_class | Issued scalar ALU ops (ADD SUB MUL MOV). |
| 13 | 0x3A | `ISS_SMEM` | count | issue_class | issue_class | Issued scalar LOAD/STORE. |
| 14 | 0x3C | `ISS_BRANCH` | count | issue_class | issue_class | Issued BEQ/BNE/JMP. |
| 15 | 0x3E | `ISS_DFMEM` | count | issue_class | issue_class | Issued tile memory ops (DFLOAD DFSTORE VLOAD VSTORE). |
| 16 | 0x40 | `ISS_DFCTL` | count | issue_class | issue_class | Issued DFMAP/DFEXEC/DFSYNC. |
| 17 | 0x42 | `ISS_VEC` | count | issue_class | issue_class | Issued SIMD vector ops (VADD VSUB VMUL DOT REDUCE BCAST). |
| 18 | 0x44 | `ISS_TENSOR` | count | issue_class | issue_class | Issued MATMUL. |
| 19 | 0x46 | `RET_SCALAR` | count | retire | - | Unique scalar-pipeline instructions reaching write-back (replayed stall copies excluded). |
| 20 | 0x48 | `RET_TILE` | count | retire | - | Tile-executed ops completed (tile_done pulses summed over tiles). |
| 21 | 0x4A | `TOK_DISPATCHED` | count | retire | - | Work tokens accepted by tiles. |
| 22 | 0x4C | `DROP_SYNC` | count | retire | - | DFSYNC consumed by the control core without a token (benign: barrier semantics still applied). |
| 23 | 0x4E | `DROP_OP` | count | retire | - | Non-DFSYNC scheduler op consumed by the control core without a token: the op was LOST (defect indicator). |
| 24 | 0x50 | `BRANCH_TAKEN` | count | retire | - | Taken branches / jumps resolved in EX. |
| 25 | 0x52 | `TILE_TOK_0` | count | tile | - | Tokens dispatched to tile 0. |
| 26 | 0x54 | `TILE_TOK_1` | count | tile | - | Tokens dispatched to tile 1. |
| 27 | 0x56 | `TILE_TOK_2` | count | tile | - | Tokens dispatched to tile 2. |
| 28 | 0x58 | `TILE_TOK_3` | count | tile | - | Tokens dispatched to tile 3. |
| 29 | 0x5A | `TILE_BUSY_0` | count | tile | - | Cycles tile 0 is marked busy in the scheduler scoreboard. |
| 30 | 0x5C | `TILE_BUSY_1` | count | tile | - | Cycles tile 1 is marked busy in the scheduler scoreboard. |
| 31 | 0x5E | `TILE_BUSY_2` | count | tile | - | Cycles tile 2 is marked busy in the scheduler scoreboard. |
| 32 | 0x60 | `TILE_BUSY_3` | count | tile | - | Cycles tile 3 is marked busy in the scheduler scoreboard. |
| 33 | 0x62 | `VEC_ISSUES` | count | exec | - | Vector-engine issues, all tiles. |
| 34 | 0x64 | `VEC_LANES_ACTIVE` | sum | exec | - | Sum over cycles of active SIMD lanes, all tiles. Utilisation = this / (CYCLES * NUM_TILES * LANES). |
| 35 | 0x66 | `VEC_ISSUES_PARTIAL` | count | exec | - | Vector issues with 0 < active lanes < LANES (lane under-utilisation / divergence). |
| 36 | 0x68 | `VEC_BUSY_CYC` | sum | exec | - | Tile-cycles with the tile FSM in the vector-execute state. |
| 37 | 0x6A | `TENSOR_BUSY_CYC` | sum | exec | - | Tile-cycles with the tensor unit busy. |
| 38 | 0x6C | `MEM_REQ_ACCEPTED` | sum | memory | - | Memory requests accepted (req_valid && req_ready), all controllers. |
| 39 | 0x6E | `MEM_RESP` | sum | memory | - | Memory responses delivered, all controllers. |
| 40 | 0x70 | `MEM_REQ_BLOCKED` | sum | memory | - | Request cycles presented while the controller was not ready (backpressure; a one-shot request is lost). |
| 41 | 0x72 | `MEM_ALIGN_ERR` | sum | memory | - | Alignment-error responses. |
| 42 | 0x74 | `MEM_OUT_SUM` | sum | memory | - | Sum over cycles of outstanding memory requests. Avg outstanding = this / CYCLES; Little's law latency = this / MEM_RESP. |
| 43 | 0x76 | `MEM_BUSY_CYC` | count | memory | - | Cycles with at least one memory request outstanding. |
| 44 | 0x78 | `MEM_OUT_PEAK` | peak | memory | - | Peak simultaneous outstanding memory requests. |
| 45 | 0x7A | `MEM_OUT_NOW` | gauge | memory | - | Outstanding memory requests at the snapshot instant. |
| 46 | 0x7C | `Q_DISP_SUM` | count | queue | - | Cycles the 1-deep dispatch slot (EX-stage scheduler op) is occupied. |
| 47 | 0x7E | `Q_DISP_NOW` | gauge | queue | - | Dispatch slot occupancy at the snapshot instant. |
| 48 | 0x80 | `Q_TOK_SUM` | sum | queue | - | Sum over cycles of in-flight tokens (scheduler scoreboard busy tiles). |
| 49 | 0x82 | `Q_TOK_PEAK` | peak | queue | - | Peak in-flight tokens. |
| 50 | 0x84 | `Q_TOK_NOW` | gauge | queue | - | In-flight tokens at the snapshot instant. |
| 51 | 0x86 | `Q_NOC_SUM` | sum | queue | - | Sum over cycles of occupied NoC router buffer slots (capacity 10 per router). |
| 52 | 0x88 | `Q_NOC_PEAK` | peak | queue | - | Peak NoC buffer occupancy. |
| 53 | 0x8A | `Q_NOC_NOW` | gauge | queue | - | NoC buffer occupancy at the snapshot instant. |
| 54 | 0x8C | `NOC_FLITS` | count | queue | - | Flits accepted by the NoC at tile injection ports. |
| 55 | 0x8E | `NOC_INJ_BLOCKED` | sum | queue | - | Tile injection ports presenting a flit the NoC did not accept. |
| 56 | 0x90 | `STALL_STREAK_MAX` | peak | health | - | Longest run of consecutive stall slots (DEP/SYNC/EXEC/MEM/DISP_OTHER). A very large value indicates a hang. |

## Invariants (checked by hardware assertions, the testbenches and `sfperf check`)

* **I1** `sum(SLOT_*) == CYCLES` in every snapshot.
* **I2** `sum(ISS_*) == SLOT_ISSUE` in every snapshot.
* **I3** `sum(TILE_TOK_t) == TOK_DISPATCHED` and `sum(TILE_BUSY_t) <= NUM_TILES*CYCLES`.
* **I4** (machine drained, no stuck tokens, and counting enabled before the first instruction issued) `SLOT_ISSUE == RET_SCALAR + RET_TILE + DROP_SYNC + DROP_OP`; `RET_TILE <= TOK_DISPATCHED`. If counting is enabled mid-flight the gap is the number of instructions issued before enabling and retired after it.
* **I5** over a whole epoch `MEM_RESP <= MEM_REQ_ACCEPTED`; within one `SNAP_CLR` window `MEM_RESP <= MEM_REQ_ACCEPTED + NUM_TILES + 1` (a request can be accepted in one window and answered in the next; at most one per controller straddles a boundary). Always `MEM_OUT_PEAK <= NUM_TILES+1`.
* **I6** If the OVF bit of any counter in an equation is set, the equation is not valid.
