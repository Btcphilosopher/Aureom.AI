# sf_perfmon -- architecture and normative behaviour

`sf_perfmon` is a passive, synthesizable performance-monitoring subsystem for the SilicaFlux execution core. It answers one
question -- *why did the issue slot not issue this cycle?* -- every clock, and keeps 57 counters, peaks and gauges that a
host reads coherently through a small CSR interface.

Companion documents: `METRICS.md` (exact meaning of every counter), `REGMAP.md` (generated register map),
`INTEGRATION.md` (wiring), `VERIFICATION.md` (how it was checked).

## 1. Structure

```
                       silicaflux_top (supplied RTL + passive taps, patches/0001)
   fetch -> decode -> control_core -> scheduler -> compute_tile x4 -> memory_controller x4(+1)    noc (5x2 buffers/router)
               |            |             |              |                  |                        |
               +-- taps ----+-------------+--------------+------------------+------------------------+
                                   (read-only views of existing signals)
                                              |
                                +-------------v--------------+
                                |  sf_pm_events  (adapter)   |   the ONLY core-specific block
                                |  tracking state + classify |
                                |  -> ev_flat[57 x CW]       |
                                +-------------+--------------+
                                              | 1 event value per counter per cycle
                                +-------------v--------------+        +--------------------+
   csr_* <---------------------->  sf_pm_regs  (generic)     |        |  sf_pm_sva (SVA)   |
   irq_o <----------------------+  57 x sf_pm_counter (live)  |<-------+  simulation only   |
   snap_trig_i ---------------->|  atomic snapshot shadow     |        +--------------------+
                                |  watchdog, flags, CSR mux   |
                                +-----------------------------+
```

* **Passive by construction.** Every port of `sf_perfmon` except `csr_rdata_o`, `csr_rvalid_o` and `irq_o` is an input.
  Nothing computed by the monitor reaches the core, so the core is cycle-exact with or without it
  (proved by simulation: `VERIFICATION.md` section 4).
* **Two layers.** `sf_pm_events` turns core signals into per-cycle events (core specific). `sf_pm_regs` + `sf_pm_counter`
  are core independent: porting to another core means replacing `sf_pm_events` and keeping the `ev_flat` contract.
* **Single source of truth.** `spec/pm_counters.json` generates `sf_pm_idx.svh` and `REGMAP.md` (`scripts/gen_pm.py`;
  `make check-gen` fails if they drift).

## 2. Per-cycle event derivation (`sf_pm_events`)

The monitor classifies the **issue slot** (the IS->EX hand-off) into exactly one of ten categories every counted cycle
(`METRICS.md` B.3). Because the classification is one priority chain over mutually exclusive outcomes, the categories
always partition `CYCLES` (invariant I1). Everything else (instruction mix, retirement, units, memory, queues) is derived
from the same tap values in the same cycle, so all counters describe the same cycles.

Tracking state that must follow the core regardless of whether counting is enabled (so that enabling mid-run is exact):
`prog_done`, the redirect shift register, per-controller outstanding-request bits, and the unique-instruction tags that
filter the supplied core's replayed write-back copies (`METRICS.md` B.2).

## 3. Counter bank (`sf_pm_counter`, generated 57 instances)

| Kind | Update when counted | Notes |
|---|---|---|
| accumulate (`count`, `sum`) | `q := sat(q + event)` | event is +0/+1 or a small integer per cycle |
| peak | `q := max(q, event)` | |
| gauge | `q := event` | value at the last counted cycle before the snapshot |

All counters are `CW` bits wide (`CW` = 40 by default). The CSR map holds each counter in two 32-bit words (LO then HI), which
supports `CW` up to 64; the testbenches exercise `CW` = 40 and `CW` = 8. Every counter has an independent sticky overflow bit.

## 4. Normative semantics

### 4.1 Overflow

* Accumulating counters **saturate** at `2^CW - 1`; they never wrap.
* The overflow bit of a counter is set **iff at least one increment was (partly) discarded**. A counter that lands exactly
  on `2^CW - 1` without losing an increment does *not* set its bit; the next non-zero increment does.
* The bit is sticky until `CLEAR`, `SNAP_CLR` or reset. `FLAGS.OVF_ANY` is the OR of all bits at the snapshot edge;
  `STATUS.OVF_LIVE` and (with `IRQ_EN`) `irq_o` report it live.
* Peak and gauge counters cannot overflow (their event values are small); their bits are always 0.
* **Any derived metric that uses a counter whose overflow bit is set is invalid.** The invariants in `REGMAP.md` do not apply
  to a snapshot with overflow. `sfperf` refuses to evaluate them and prints the offending counter.
* Headroom: at 1 GHz a 40-bit counter saturates after 2^40 ns = 18.3 minutes; use `SNAP_CLR` windows for long runs
  (each window restarts every counter) or raise `CW`.
* `SNAP_SEQ` is a 32-bit wrapping command counter; compare it only for equality.

### 4.2 Reset

* Asynchronous assertion, same style as the core (`always_ff @(posedge clk or negedge rst_n)`); the core's own reset
  scheme is reused. Deassertion should be synchronous to `clk` (as for the core).
* Reset clears every counter, overflow bit, the shadow, flags, `SNAP_SEQ` (to 0), `SNAP_VALID`, the watchdog, the stall
  streak, `WDOG_THRESH` and all tracking state (including `prog_done`).
* `ENABLE` resets to the parameter `ENABLE_AT_RESET` (default 0: counting is off until software enables it).
* `CLEAR` (a software command, not a reset) clears counters, overflow bits, shadow, flags, `SNAP_VALID`, watchdog and
  streak, **increments** `SNAP_SEQ`, and **does not** touch `prog_done`, the redirect shift register, the outstanding
  tracker or the unique-instruction tags (they mirror the core, which `CLEAR` does not reset).

### 4.3 Enable, clear and snapshot (what a window contains)

Let `E` be the edge at which a CSR command executes.

```
cycle:        ... E-2   E-1    E     E+1  ...
events:            e(E-2) e(E-1) e(E) e(E+1)
SNAPSHOT at E:   shadow = sum of events of counted cycles < E     (live counters keep running: e(E) is counted)
SNAP_CLR at E:   shadow = sum of events of counted cycles < E; live := e(E)  -> windows tile the timeline [E_k, E_k+1)
CLEAR    at E:   shadow := 0; live := 0 (e(E) is discarded)
ENABLE=1 at E:   cycles > E are counted
```

* The shadow is loaded **at one clock edge for all 57 counters, the overflow bitmap and the flags together**. Hence every
  invariant that holds on the live counters holds inside the snapshot (`sum(SLOT_*) == CYCLES`, etc.; asserted in
  `sf_pm_sva` for every snapshot).
* Command precedence within one cycle: `CLEAR > SNAP_CLR > SNAPSHOT / snap_trig_i`. A combined write executes the
  highest-priority command only, and `SNAP_SEQ` increments exactly once.
* `snap_trig_i` (a one-cycle pulse from hardware, e.g. a debug trigger or program-done) behaves exactly like `SNAPSHOT`.
* `SNAP_CLR` windows are the supported way to get a time series without any software race.

### 4.4 Read consistency

Software never reads live counters; it reads the **shadow**, which changes only on `SNAPSHOT`, `SNAP_CLR`, `snap_trig_i`,
`CLEAR` or reset. Consequently:

1. A multi-word value (LO/HI) and any set of counters read between two commands are mutually consistent -- no tearing and
   no "stop the counters first" step.
2. If another agent can issue commands concurrently, bracket the read with `SNAP_SEQ`:

```c
do {
    seq0 = read(SNAP_SEQ);
    for (i = 0; i < NC; i++) { lo = read(CNT_BASE + 2*i); hi = read(CNT_BASE + 2*i + 1); v[i] = ((u64)hi << 32) | lo; }
    ovf = read(OVF_BASE) | (u64)read(OVF_BASE + 1) << 32;  flags = read(FLAGS);
    seq1 = read(SNAP_SEQ);
} while (seq0 != seq1);          // a command intervened: retry
```

3. A read returns the shadow as it is at the edge the read is accepted. `csr_rvalid_o` is high exactly one cycle after the
   read request, with `csr_rdata_o` registered; there are no wait states and no error response (unmapped addresses read 0,
   writes to read-only registers are ignored).
4. `SNAP_VALID` (STATUS bit 0) is 0 after reset and after `CLEAR` until the first snapshot; the shadow reads 0 until then.

### 4.5 Watchdog

`WDOG_THRESH` = N (non-zero) latches `FLAGS.WDOG_TRIP` (sticky until `CLEAR`) after N consecutive counted cycles with no
issue, scalar retirement, tile completion or token dispatch. It is the hang detector: it fired on the supplied core's
load-use livelock in `results/supplied/dep_load_use` (`REPORT.md`). Choose N above the longest legitimate silent period
(a `MATMUL` takes about 66 cycles).

## 5. Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `NT` | 4 | compute tiles. **Fixed at 4 in this spec revision**: the per-tile counters (`TILE_TOK_0..3`, `TILE_BUSY_0..3`) are generated for four tiles and the event adapter indexes them directly. Another tile count means editing `pm_counters.json` and `sf_pm_events.sv` |
| `LANES` | 4 | SIMD lanes per tile (width of `lane_active_i`) |
| `CW` | 40 | counter width (<= 64 by construction of the CSR map; verified at 8 and 40) |
| `CTRL_SHADOW` | 2 | redirect-shadow length = fetch-to-IS distance after a branch flush in this core |
| `ENABLE_AT_RESET` | 0 | counting enabled out of reset |
| `NOC_TAP` | 1 | reported in `FEATURES`; tie `noc_occ_i`/`noc_inj_*` to 0 if the NoC is not instrumented |
| `PM_EN` (top) | 1 | instantiate the monitor (taps stay wired); 0 removes it entirely |

## 6. Cost drivers and trade-offs

The dominant cost is storage: 57 live counters + 57 shadow registers of `CW` bits. Options: lower `CW` (counters and shadow
shrink linearly; the CSR map does not change); tie the NoC taps off (the only source of NoC flits is `DFEXEC`, which never
completes on the supplied core, `BASELINE_FINDINGS.md` F4); or remove counters from `spec/pm_counters.json` and regenerate
(this *does* change the register map and the Python decoder follows it automatically). Measured cost: `OVERHEAD.md`.

## 7. Known limitations (stated, not hidden)

* **No SIMT divergence on this core.** SilicaFlux has no lane masks or warps; `lane_active_i` is `{LANES{vec_issue}}`, so
  `VEC_ISSUES_PARTIAL` is structurally 0 on the supplied RTL. The counters and their arithmetic are verified with synthetic
  partial masks (`tb_pm_unit`, `tb_pm_dump`). Control-flow divergence (branch bubbles) is measured instead.
* **Event timing is not pipelined.** Tap logic, classification and the counter adders are one combinational path per cycle.
  For a high-frequency target, register the taps (adding one cycle of latency to every window edge) -- this is not
  implemented, and changing it shifts the window semantics of section 4.3 by one cycle.
* **Retirement is a model, not a commit stage.** The supplied core has no commit/ROB; "retired" is defined in
  `METRICS.md` A.3 (first write-back for scalar ops, `tile_done` for dispatched ops).
* `snap_trig_i` is verified by the unit testbench but is not representable in the trace format of the independent checker.
