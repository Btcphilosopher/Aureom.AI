# The supplied core: issue, execution, memory and retirement interfaces

Source inspected: `rtl/supplied/` (16 files, SilicaFlux v1.0 cluster, `silicaflux.zip` from the repository; checksums in
`rtl/SUPPLIED.sha256`). It is a **single-issue, in-order scalar pipeline that hands vector / tensor / memory work to four
compute tiles through a scheduler** -- not a SIMT machine: there are no warps, no thread masks, no scoreboard per register,
and no commit stage. The sections below describe exactly what is there, because the monitor's definitions follow from it.
Line numbers refer to the supplied files. The **Tap** column names the monitor input that observes each signal
(`METRICS.md` B.1).

```
 imem -> fetch_unit -> [if_id] -> decoder -> [id_is] -> control_core:  IS --- EX --- MEM --- WB --> register_bank
                                                            |            \
                                              scalar LOAD/STORE            \ sched_* (vector, DF*, MATMUL)
                                                            |               v
                                                      memory_controller  scheduler --token--> compute_tile[0..3]
                                                      (control path)       | tile_busy, sync barrier    | FSM: IDLE/MEMWAIT/VECEXEC/TENSOR
                                                                           |                            +-- vector_engine (2-stage, LANES=4)
                                                                           |                            +-- tensor_unit (4x4, serial MAC)
                                                                           |                            +-- memory_controller (256 x 32 scratchpad)
                                                                           +<-- tile_done ----------------+-- noc_flit_* --> noc_interconnect (2x2)
```

## 1. Issue interface

| Signal | File:line | Meaning | Tap |
|---|---|---|---|
| `if_id`, `id_is` (`id_is_reg_t`) | `silicaflux_pkg.sv`, `fetch_unit`, `decoder` | instruction presented to the IS stage: `valid`, `instr.opcode`, operands, `pc` | `is_valid_i`, `is_opcode_i` |
| `id_stall` | `control_core.sv:120` | `load_use_hazard \|\| sync_stall \|\| (sched_valid && !sched_ready)`; freezes IF, ID and IS | `id_stall_i` |
| `load_use_hazard` | `control_core.sv:114` | a LOAD in EX whose `rd` equals a source of the instruction in IS | `load_use_i` |
| `pipeline_flush` | `control_core.sv:216` | high the cycle after a taken branch resolves in EX; clears `is_ex` and `id_is` | `flush_i` |
| `is_ex` (IS->EX register) | `control_core.sv:126-141` | loaded when `!id_stall`; **held (not bubbled) while stalled** | `ex_valid_i`, `ex_opcode_i` |
| `sched_valid` | `control_core.sv:198` | EX-stage instruction is a dataflow/vector op (`is_sched_op`) | `sched_valid_i` |
| `sched_ready` = `scheduler.instr_ready` | `scheduler.sv:136` | scheduler accepts the op | `sched_ready_i` |

*Issue slot used by the monitor:* the IS->EX hand-off, `id_is.valid && !id_stall && !flush`. One instruction per cycle at most.
*Branch resolution:* in EX (`br_taken_comb`, `control_core.sv:150-182`); redirect reaches IS three cycles later
(flush cycle + two bubbles, measured: exactly 3 lost slots per taken branch, `REPORT.md` section 5).
*Instruction formats:* `docs/SUPPLIED_ISA_REFERENCE.md`. V-format has no tile field, so **every vector/tensor op targets tile 0**.

## 2. Execution interfaces

| Unit | Interface | Behaviour (as measured) | Tap |
|---|---|---|---|
| Scalar ALU | inside `control_core` EX (`control_core.sv:146-182`) | ADD SUB MUL MOV and address generation, 1 cycle | counted via `ISS_SALU` |
| Scheduler scoreboard | `scheduler.sv:73-89` `tile_busy[3:0]` | set when a token is accepted, cleared on `tile_done` | `tile_busy_i` |
| Barrier | `scheduler.sv:97-108` `sync_barrier_active`, `sync_stall` | DFSYNC arms the barrier; `sync_stall` while any tile is busy | `sync_stall_i` |
| Dispatch | `scheduler.sv:129-148` `dispatch_ok`, `tile_tok_valid_t` | one-hot token to the target tile | `tok_valid_i`, `tgt_tile_i` |
| Compute tile FSM | `compute_tile.sv:184-335` | `T_IDLE`(0) `T_MEMWAIT`(1) `T_VECEXEC`(2) `T_TENSOR`(3); one token at a time (`token_ready`) | `tile_state_i`, `tile_done_i` |
| Vector engine | `vector_engine.sv`, `compute_tile.sv:120-133` | 4 lanes x 32 bit, VADD VSUB VMUL DOT REDUCE BCAST, issue pulse -> result next cycle (tile stays 2 cycles in the vector state, measured); **no lane mask** | `vec_issue_i`, `lane_active_i` |
| Tensor unit | `tensor_unit.sv`, `compute_tile.sv:143-161` | 4x4 signed MATMUL, serial MAC, 66 cycles busy (measured, every MATMUL) (`busy`, `done`) | `tensor_busy_i` |
| NoC | `noc_router.sv` | 5 single-entry input + 5 single-entry output buffers per router, XY routing; flits are only produced by DFEXEC completion | `noc_occ_i`, `noc_inj_*` |

## 3. Memory interfaces

| Interface | Definition | Behaviour (as measured) | Tap |
|---|---|---|---|
| Control-core scalar path | `control_core.sv:233-258` -> `u_ctrl_mem` (`silicaflux_top.sv:233`) | one-shot `mem_req_valid` per LOAD/STORE; **`mem_req_ready` is not looked at** | `mem_*_i[NT]` |
| Tile scratchpad controller | `memory_controller.sv` (one per tile, `compute_tile.sv:88`) | request/response: `req_valid/req_ready/req_opcode/req_addr/req_length`, `resp_valid`; one transaction at a time; 256 x 32-bit words | `mem_*_i[0..NT-1]` |
| Latency | `memory_controller.sv:179-232` | scalar LOAD: response 2 cycles after accept; STORE: 1; DFLOAD/DFSTORE: `length + 2` (a 31-word DFLOAD measured 33 cycles by Little's law and by trace); VLOAD/VSTORE: 4-word burst | `MEM_OUT_SUM/MEM_RESP` |
| Alignment | `memory_controller.sv` `alignment_err` | pulse + immediate response on a misaligned byte address | `mem_align_i` |
| Outstanding requests | 0 or 1 per controller, 5 controllers | derived by the monitor: set on accept, cleared on response | `MEM_OUT_*` |

There are no request queues: **backpressure is a controller that is not ready**. Tile ops wait in the scheduler's dispatch
slot (the instruction stays in EX); the control core's scalar requests do not wait at all (they are lost).

## 4. Retirement interface

There is no commit stage. Architectural effects happen at:

| Effect | Where | Notes | Monitor event |
|---|---|---|---|
| Scalar register write | `control_core.sv:281-299` (`s_wr_*`), muxed with scheduler write-back at `silicaflux_top.sv:178` | ADD SUB MUL MOV LOAD only | `RET_SCALAR` (first WB of each issued instruction) |
| Tile completion | `tile_done` pulse (`compute_tile.sv`, `tile_status_done`) | DFLOAD DFSTORE vector, MATMUL, DFSYNC complete; **DFEXEC/DFMAP never do** | `RET_TILE` |
| Scheduler scalar write-back | `scheduler.sv:158-173` | `wb_reg` is hard-wired to register 0, so it is discarded | (none) |
| Vector register write | `control_core.sv:285-287` | `v_wr_en` is constant 0: vector registers are never written | (none) |
| Program end | `silicaflux_top.sv:457-462` `halt` | set when HALT is **fetched**; nothing stops | `prog_done` (HALT *issues*) |

Consequences used by the monitor and documented as defects in `BASELINE_FINDINGS.md`: write-back copies are replayed under
stall (so raw `mem_wb.valid` over-counts), dispatched work can be lost, and tile results do not reach architectural state.
The monitor therefore defines retirement explicitly (`METRICS.md` A.3) and reports the conservation gap rather than
assuming it is zero.

## 5. Where the monitor attaches

All taps are read-only views of existing signals, added by `patches/0001-perfmon-taps.patch` to `control_core`
(`pm_load_use`, `pm_ex_valid`, `pm_ex_opcode`, `pm_br_taken`, `pm_wb_valid`), `scheduler` (`pm_tile_busy`, `pm_tgt_tile`),
`compute_tile` (`pm_state`, `pm_vec_issue`, `pm_lane_active`, `pm_tensor_busy`, `pm_mem_{fire,blocked,resp,align}`),
`noc_router`/`noc_interconnect` (`pm_occ`) and `silicaflux_top` (instance, CSR ports, remaining tap wiring).
