# Integration guide

## 1. What you are integrating

| Piece | Path | Role |
|---|---|---|
| Monitor RTL | `rtl/perfmon/*.sv` | `sf_perfmon` and its sub-blocks. Needs `silicaflux_pkg.sv` (opcode constants) |
| Supplied core | `rtl/supplied/*.sv` | **untouched**, checksummed in `rtl/SUPPLIED.sha256` |
| Tap patch | `patches/0001-perfmon-taps.patch` | additive taps + a `sf_perfmon` instance + CSR ports on `silicaflux_top` |
| Optional fixes | `patches/optional/0002..0003` | **not** part of the instrumentation; see `BASELINE_FINDINGS.md` |
| Assertions | `sva/sf_pm_sva.sv` | compiled in with `-DSF_PM_SVA` |

The tap patch changes 6 files. Of its 17 removed lines, every one is a port-list line that needed a trailing comma or a
tie-off connection (`.alignment_err (/* unused */)`) that became a wire; no logic is removed or altered. The patch is
regenerated and verified by `make check-patches` (it re-derives the patch from the pristine files with exact-once anchors).

## 2. Build the variants

```bash
make variants           # build/rtl_{sup,pm,fix,pmfix}: supplied, instrumented, fixed, instrumented+fixed
scripts/build_variant.sh pm build/rtl_pm            # or one variant by hand (uses `patch -p1`)
```

| Variant | Contents | Use |
|---|---|---|
| `sup` | supplied RTL | the reference ("uninstrumented") |
| `pm` | supplied + 0001 | **the instrumented supplied core** |
| `fix` | supplied + 0002 + 0003 | reference for the fixed core |
| `pmfix` | supplied + 0001 + 0002 + 0003 | instrumented fixed core |

## 3. Instantiate

`silicaflux_top` gains one parameter and eight ports; nothing else about its interface changes.

```systemverilog
silicaflux_top #(.LANES(4), .PM_EN(1'b1)) u_core (
    /* existing ports unchanged ... */
    .pm_csr_en    (csr_en),     // 1 = access this cycle
    .pm_csr_we    (csr_we),     // 1 = write, 0 = read
    .pm_csr_addr  (csr_addr),   // [7:0] word address
    .pm_csr_wdata (csr_wdata),
    .pm_csr_rdata (csr_rdata),  // valid one cycle after a read request
    .pm_csr_rvalid(csr_rvalid),
    .pm_snap_trig (1'b0),       // optional hardware snapshot trigger (1-cycle pulse)
    .pm_irq       (irq)         // level: IRQ_EN && (counter overflow || watchdog trip)
);
```

`PM_EN = 0` keeps the taps but removes the monitor (`pm_csr_rdata` = 0). The synthesised netlist of that configuration
was compared with the supplied RTL: `OVERHEAD.md`.

**Clock and reset.** One clock (the core's), asynchronous-assert reset (`rst_n`, active low) -- exactly the core's.
If the CSR master lives in another clock domain, bridge with a normal request/acknowledge CDC: the shadow is static between
commands, so only the command write and the read data need synchronising.

**CSR bridge.** The bus is intentionally trivial (no wait states, no errors): connect it to APB/AXI-Lite with a
one-state FSM that issues `csr_en` for one cycle and waits for `csr_rvalid`.

## 4. Software sequence

```c
pm_write(WDOG_THRESH, 400);                 // optional hang detector (cycles); 0 disables
pm_write(CTRL, CLEAR | ENABLE);             // start a fresh epoch and begin counting
/* ... run the kernel ... */
pm_write(CTRL, SNAPSHOT | ENABLE);          // atomic capture (SNAP_CLR | ENABLE to also start the next window)
do { seq0 = pm_read(SNAP_SEQ);
     read_all_counters(v);                  // LO/HI pairs, OVF words, FLAGS
     seq1 = pm_read(SNAP_SEQ); } while (seq0 != seq1);
if (flags & OVF_ANY) discard_or_widen();    // any counter with its overflow bit set is invalid
```

Decoding and analysis on the host:

```bash
python3 -m sfperf analyze <dir containing snapshots.csv>      # or use sfperf.snapshot / sfperf.bottleneck from Python
```

`snapshots.csv` is exactly what the system testbench writes after reading the shadow through the CSR bus; any host that can
produce rows in that format (`docs/METRICS.md` Part C) can use the whole analysis stack.

## 5. Simulation and lint

```bash
make test                 # unit testbench (Icarus), system equivalence, independent trace check
make sva                  # unit testbench under Verilator with every SVA assertion enabled
verilator --lint-only -Wall -DSF_PM_SVA --assert -Irtl/perfmon -Irtl/supplied -Isva \
          --top-module sf_perfmon rtl/supplied/silicaflux_pkg.sv rtl/perfmon/sf_pm_pkg.sv rtl/perfmon/sf_pm_counter.sv \
          rtl/perfmon/sf_pm_events.sv rtl/perfmon/sf_pm_regs.sv sva/sf_pm_sva.sv rtl/perfmon/sf_perfmon.sv
```

Tool notes, all hit during this work:

* Icarus 12 mis-sizes nested struct member selects used directly in port connections (`id_is.instr.opcode`); the patch routes
  them through `assign` wires. Icarus also lacks `break`, array-literal initialisers and `default disable iff`.
* Verilator 5.020 needs `--timing --binary` for the SV testbenches, and has no `default disable iff` (the SVA states
  `disable iff` per property). `SYNCASYNCNET` is expected: `rst_n` is an async reset in the RTL and a sampled disable in SVA.
* `sf_pm_sva` has a testbench-only gate `tb_sva_off`, used when a test deposits values into counters to reach 2^32 quickly.

## 6. Synthesis

The monitor is plain synthesizable SystemVerilog (no `initial`, delays or latches; asynchronous-reset flip-flops; constant
loop bounds). Hand-checked flow: `scripts/synth_stat.sh` (slang front end + ABC mapping, see `OVERHEAD.md`). The supplied
RTL needs `-Wno-range-oob` in yosys-slang because of `compute_tile.sv:226` (finding F9). Distro Yosys 0.33 cannot read the
supplied `silicaflux_pkg.sv` (`return {...}` in a function).

## 7. Porting to another core

1. Keep `sf_pm_regs`, `sf_pm_counter`, `sf_pm_pkg`, `spec/pm_counters.json`.
2. Replace `sf_pm_events.sv`. Its contract: produce `ev_flat` (one `CW`-bit event per counter per cycle, indices from
   `sf_pm_idx.svh`), `progress_o`, `prog_done_o`.
3. Re-express the tap table of `METRICS.md` B.1 for your core and re-derive the slot priority chain (B.3). Keep the chain a
   single `if / else if` so the categories stay mutually exclusive by construction.
4. Delete counters your core cannot support from the JSON and run `python3 scripts/gen_pm.py` (the register map and the
   Python decoder follow).
5. Re-run `tb_pm_unit` with your adapter and your reference model; write the independent trace check from your spec.

## 8. Integration checklist

- [ ] `sum(SLOT_*) == CYCLES` in every snapshot (assertion `ap_snapshot_I1`).
- [ ] `ap_tap_*` assertions silent: a stall always has a cause, a token implies a completed handshake.
- [ ] `SLOT_STALL_DISP_OTHER` is small on a healthy workload (it is the catch-all for unmodelled stall causes).
- [ ] Conservation after drain: `SLOT_ISSUE == RET_SCALAR + RET_TILE + DROP_SYNC + DROP_OP` (`METRICS.md` I4).
- [ ] Instrumented and uninstrumented runs give identical architectural traces and cycle counts (`make test`).
