# Instrumentation overhead

Two kinds of overhead were measured with the tools available in this environment. **Neither is silicon area, power or
timing**: there is no PDK, no place-and-route and no static timing analysis here, so those were *not* measured and no number
for them is given.

## 1. Architectural / performance overhead on the core: exactly zero (measured)

`sf_perfmon` has no output that reaches the core. Instrumented and uninstrumented runs were compared on every workload and on
random programs: byte-identical architectural traces, identical cycle counts, identical per-cycle fingerprints
(`VERIFICATION.md` section 4, `REPORT.md` section 6, `results/fuzz.txt`). The monitor adds **0 cycles** and cannot stall,
reorder or perturb the core; reading the counters through the CSR bus (about 125 cycles for all 57 counters, one word per
cycle) happens while the core keeps running.

## 2. Synthesis cost (Yosys proxies)

### Method

`scripts/synth_stat.sh` / `scripts/synth_overhead.sh`, same flow for every variant:

1. **yosys 0.71 (YoWASP) + yosys-slang** elaborates the SystemVerilog (the distro Yosys 0.33 cannot parse
   `silicaflux_pkg.sv`), flattens, runs the coarse `synth` steps and `techmap`s all arithmetic to primitive gates. Memories stay
   as `$mem` cells and are *not* counted as flip-flops. The slang diagnostic `-Wno-range-oob` is passed because of
   finding F9 (it is needed for the supplied RTL, not for the monitor).
2. The netlist is handed to **native yosys 0.33 + ABC** (the WASM build cannot start ABC's helper process), which maps to
   (a) generic 2-input gates (`AND NAND OR NOR XOR XNOR ANDNOT ORNOT MUX`) and (b) 6-input LUTs, and reports cell counts,
   flip-flops and the longest topological path (`ltp`).

Three variants of `silicaflux_top`: `sup` (supplied RTL), `pm0` (instrumented RTL with `PM_EN = 0`: taps wired, monitor
absent) and `pm1` (instrumented RTL with `PM_EN = 1`). `pm0` must equal `sup` if the tap patch is free; `pm1 - pm0` is the
monitor.

### Results

**In one sentence: the monitor roughly doubles the *logic* of this core** (+98.5 % flip-flops, +108 % generic gates, +143 %
LUT6, memories excluded), adds no logic depth in this flow, and the tap wiring alone is free to within +0.13 % gates. The cost
is almost entirely storage: 57 live counters and a 57-entry shadow at 40 bits, and it is linear in the counter width (table
below). The core's own logic is small here because its instruction memory and scratchpads are `$mem` cells and are excluded,
so the *relative* number is large and the absolute cost relative to the whole die would be far smaller; neither was measured.

Source: `results/synthesis/syn_*/summary.json`, rendered by `python3 -m sfperf report` into `results/REPORT.md` section 7
and `results/charts/overhead.png`. The tables below are copies of that section at packaging time.

| variant | flip-flops | generic gates | LUT6 | logic depth (gates) | logic depth (LUT6) |
|---|---|---|---|---|---|
| supplied | 4,241 | 13,580 | 4,538 | 66 | 15 |
| instrumented, PM_EN=0 | 4,241 | 13,597 | 4,539 | 64 | 15 |
| instrumented, PM_EN=1 | 8,420 | 28,258 | 11,021 | 64 | 15 |

Standalone monitor, same flow, versus counter width `CW` (snapshot shadow + live counters scale linearly):

| CW | flip-flops | generic gates | LUT6 | logic depth (gates / LUT6) |
|---|---|---|---|---|
| 16 | 1,919 | 7,320 | 3,054 | 57 / 12 |
| 24 | 2,727 | 10,105 | 4,295 | 56 / 12 |
| 32 | 3,535 | 12,867 | 5,592 | 57 / 12 |
| 40 | 4,343 | 15,659 | 6,796 | 63 / 14 |
| 48 | 5,151 | 18,409 | 8,036 | 71 / 16 |

### Caveats (read before quoting any number)

* **Proxies.** Generic-gate and LUT6 counts and "logic depth" are not area or timing. ABC's result depends on its heuristics
  and on netlist ordering: the taps-only variant contains no extra logic yet differs from the supplied RTL by 17 gates and 2
  logic levels in the gate-level depth. That variability was **not quantified** (no repeated or permuted runs), so treat
  differences below roughly 1 % as noise and use ratios between variants processed by the same flow, not absolute values.
* **Memories excluded.** Instruction memory, the five scratchpads and (depending on inference) the register files are kept as
  `$mem` cells. Counting them as flip-flops would multiply the baseline and shrink the monitor's relative share.
* **Logic depth.** In this flow the standalone monitor's longest path is 14 LUT6 levels (63 gate levels) and the combined design's
  is 15 LUT6 levels, the same as the supplied core's, so the monitor does not lengthen the critical path *here*. Whether that
  survives placement, routing and real cell delays is unknown: no static timing analysis was available.
* **Frequency target.** The monitor evaluates tap logic, classification and 57 adders in a single cycle. For a high-frequency
  implementation register the taps (costing one cycle of latency on every window edge) or reduce `CW`; neither was
  implemented or measured.

## 3. Simulation wall-clock overhead (measured)

`python3 -m sfperf.simspeed` (Icarus Verilog, median of 5 runs, min..max reported). Rows: `uninstrumented`; `taps_only`
(monitor removed); `pm_rtl_only` (monitor in the design, CSR enable and a full 57-counter read-out included, no testbench
model); `pm_rtl+ref_model` (additionally the testbench's reference model comparing every counter every cycle, which is
verification infrastructure, not part of the design). Results: `results/simspeed.json` and the table below.

Reading it: the taps alone cost nothing measurable (x0.97-x1.11, within the min..max spread of repeated runs). The monitor RTL
costs **x3 to x6** wall-clock in Icarus on these short runs (0.3-0.4 s uninstrumented). That is the price of event-driven
simulation of 114 forty-bit registers and wide per-cycle event vectors, and it includes about 125 extra read-out cycles in
runs of only a few hundred cycles; it says nothing about hardware cost. Wall-clock on a shared machine is noisy.

| workload | build | median s | min..max s | vs uninstrumented |
|---|---|---|---|---|
| `compute_alu` | uninstrumented | 0.400 | 0.356..0.528 | x1.00 |
| `compute_alu` | taps_only(PM_EN=0) | 0.392 | 0.377..0.511 | x0.98 |
| `compute_alu` | pm_rtl_only | 1.204 | 1.012..1.344 | x3.01 |
| `compute_alu` | pm_rtl+ref_model | 2.206 | 2.063..2.482 | x5.52 |
| `mixed_kernel` | uninstrumented | 0.358 | 0.350..0.508 | x1.00 |
| `mixed_kernel` | taps_only(PM_EN=0) | 0.398 | 0.343..0.605 | x1.11 |
| `mixed_kernel` | pm_rtl_only | 2.108 | 1.824..2.342 | x5.89 |
| `mixed_kernel` | pm_rtl+ref_model | 3.311 | 3.289..3.486 | x9.24 |
| `mem_burst_parallel` | uninstrumented | 0.314 | 0.285..0.390 | x1.00 |
| `mem_burst_parallel` | taps_only(PM_EN=0) | 0.304 | 0.285..0.339 | x0.97 |
| `mem_burst_parallel` | pm_rtl_only | 1.393 | 1.309..1.430 | x4.44 |
| `mem_burst_parallel` | pm_rtl+ref_model | 2.311 | 2.291..3.031 | x7.36 |
