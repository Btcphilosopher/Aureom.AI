# Metric definitions

This document is **normative**: `rtl/perfmon/sf_pm_events.sv`, the behavioural reference model
(`tb/pm_ref_model.sv`) and the independent Python re-derivation (`sfperf/trace_check.py`) are all required to
agree with it. Part A explains what each metric means and how to read it. Part B is the exact, implementable
definition. Part C defines the trace files used to check it.

Conventions: a *cycle* is one rising clock edge. Tap values are the **pre-edge** values sampled at that edge.
"Counting" means the monitor's `ENABLE` bit was 1 *before* that edge (a write that sets ENABLE takes effect for the
following edge). NT = 4 tiles, LANES = 4.

---------------------------------------------------------------------------------------------------------------

## Part A -- What the metrics tell you

### A.1 The issue-slot ("CPI stack") accounting -- mutually exclusive

SilicaFlux has **one issue slot**: the IS->EX hand-off of `control_core`. Every counted cycle is assigned to
exactly **one** of ten categories, so the categories always sum to `CYCLES` (invariant I1) and can be drawn as one
stacked bar whose segments are directly comparable.

| Category (`SLOT_*`) | Meaning | Typical cause |
|---|---|---|
| `ISSUE` | An instruction advanced into EX. This is **instructions issued**. | useful work (including NOPs: see `ISS_NOP`) |
| `STALL_DEP` | Lost to the scalar RAW (load-use) interlock | LOAD followed by a dependent instruction |
| `STALL_SYNC` | Waiting at a `DFSYNC` barrier | explicit dataflow dependency: wait for all tiles |
| `STALL_EXEC_VEC` | Dispatch of a non-`DFSYNC` op blocked: target tile's **vector engine** busy | execution-unit contention |
| `STALL_EXEC_TENSOR` | ... target tile's **tensor unit** busy | execution-unit contention |
| `STALL_MEM` | ... target tile occupied by a **memory transaction** | memory latency / backpressure |
| `STALL_DISP_OTHER` | Dispatch blocked, tile in none of those states | turnaround cycle, tile stuck on a token that never completes, tile id out of range |
| `BUBBLE_CTRL` | Slot squashed by a taken branch, or an empty slot in the redirect shadow | control flow / branch divergence |
| `BUBBLE_FRONT` | No instruction at IS, no stall, work still in flight | pipeline fill, front-end starvation |
| `IDLE` | Nothing to do: machine empty before the first instruction, or **any cycle after HALT issued** | end of program |

Reading it: the largest non-`ISSUE` segment is the first-order reason the core is not issuing every cycle.
`IPC = ISSUE / (CYCLES - IDLE)`.

`STALL_SYNC` deliberately includes a `DFSYNC` that is itself held at dispatch behind a busy tile: that *is* the
barrier waiting. To see **what** the barrier is waiting for, read the unit-activity counters over the same window
(`TENSOR_BUSY_CYC`, `VEC_BUSY_CYC`, `MEM_BUSY_CYC`, `TILE_BUSY_t`); `sfperf` does this when it attributes a bottleneck.

### A.2 Overlapping counters -- *not* mutually exclusive

These can all be non-zero in the same cycle, so **never add them to the slot categories**:

* instruction mix (`ISS_*`) -- exclusive among themselves, sums to `SLOT_ISSUE`;
* retirement and flow: `RET_SCALAR`, `RET_TILE`, `TOK_DISPATCHED`, `DROP_SYNC`, `DROP_OP`, `BRANCH_TAKEN`;
* per-tile activity: `TILE_TOK_t`, `TILE_BUSY_t`;
* execution units: `VEC_*`, `TENSOR_BUSY_CYC`;
* memory: `MEM_*`;
* queues: `Q_*`, `NOC_*`;
* health: `STALL_STREAK_MAX`.

### A.3 Instructions issued vs retired

* **Issued** (`SLOT_ISSUE`): the instruction left IS for EX. Counted once, ignoring replays and branch squashes.
* **Retired**: `RET_SCALAR` counts a scalar-pipeline instruction when it reaches write-back **the first time**
  (the supplied RTL replays a stalled EX instruction into WB every stall cycle; those copies are *not* retirements).
  `RET_TILE` counts tile completions (`tile_done`).
* **Conservation** (invariant I4): once the machine has drained, with no stuck tokens, and provided counting was enabled before
  the first instruction issued, `SLOT_ISSUE = RET_SCALAR + RET_TILE + DROP_SYNC + DROP_OP` (it holds exactly in 36 of 36
  shipped runs, including runs with taken branches whose wrong-path instructions commit). The tracking state follows the core
  whether or not counting is enabled, so enabling mid-flight leaves a gap equal to the instructions issued before enabling and
  retired after it. A shortfall of `RET_TILE` against
  `TOK_DISPATCHED` means a token was accepted but the tile never reported completion (a hung tile);
  `DROP_OP > 0` means the control core retired a scheduler op **without ever sending it** (an op was lost).

### A.4 Active-lane utilisation

`VEC_LANES_ACTIVE / (CYCLES * NT * LANES)` is the fraction of vector-lane-cycles that did work.
`VEC_ISSUES_PARTIAL` counts vector issues with 0 < active < LANES. **SilicaFlux has no lane masks**, so the tap
reports all lanes active on every vector issue and `VEC_ISSUES_PARTIAL` is structurally zero on this core. The
counters are real and are verified in `tb_pm_unit` with synthetic partial masks; they will show lane divergence the
day the core grows masking. Control-flow divergence on this core shows up in `SLOT_BUBBLE_CTRL`/`BRANCH_TAKEN`.

### A.5 Memory

Each of the five memory controllers (4 tile scratchpads + the control core's scalar path) serves one request at a
time. `outstanding` is 0/1 per controller, 0..5 in total. Average outstanding = `MEM_OUT_SUM / CYCLES`; peak =
`MEM_OUT_PEAK`; **Little's-law latency** = `MEM_OUT_SUM / MEM_RESP` cycles per request. `MEM_REQ_BLOCKED` counts
request cycles presented to a controller that was not ready (**backpressure**); the control core fires one-shot
requests without honouring `ready`, so a blocked request is **lost**.

### A.6 Queues

SilicaFlux has no deep queues. The real occupancy structures are: the 1-deep **dispatch slot** (`Q_DISP_*`), the
**in-flight token scoreboard**, 0..4 (`Q_TOK_*`), the **memory outstanding** set, 0..5 (`MEM_OUT_*`), and the **NoC
router buffers**, 0..40 (`Q_NOC_*`). Each queue reports an integral (`*_SUM`, divide by `CYCLES` for the mean), a
peak and the value at the snapshot instant (`*_NOW`).

### A.7 Health

`STALL_STREAK_MAX` is the longest run of consecutive stall slots. A value approaching `CYCLES` means the machine is
hung. The watchdog (`WDOG_THRESH`) latches `FLAGS.WDOG_TRIP` after that many consecutive counted cycles with no
issue, scalar retirement, tile completion or token dispatch; set it above the longest legitimate operation (a
`MATMUL` takes about 66 cycles).

---------------------------------------------------------------------------------------------------------------

## Part B -- Exact definitions (implementers read this)

### B.1 Tap signals (per cycle, pre-edge)

| Name | Meaning in the supplied RTL |
|---|---|
| `is_valid`, `is_opcode[4:0]` | instruction presented at the IS stage (`id_is.valid`, `id_is.instr.opcode`) |
| `id_stall` | `control_core.id_stall` (= `load_use \| sync_stall \| (sched_valid & !sched_ready)`) |
| `load_use`, `sync_stall` | load-use hazard; scheduler barrier stall |
| `flush` | `pipeline_flush` (high the cycle after a taken branch resolves in EX) |
| `br_taken` | a branch/jump resolved taken in EX this cycle |
| `ex_valid`, `ex_opcode` | instruction in the EX stage (`is_ex`) |
| `wb_valid` | `mem_wb.valid` (also high on replayed stall copies) |
| `sched_valid` | EX-stage instruction is a dataflow/vector op awaiting dispatch |
| `sched_ready` | scheduler `instr_ready` |
| `tok_valid[t]` | tile `t` accepted a work token this cycle |
| `tgt_tile` | target tile id of the EX-stage scheduler op (0..7; >=4 is out of range) |
| `tile_busy[t]` | scheduler scoreboard bit for tile `t` |
| `tile_done[t]` | tile `t` completion pulse |
| `tile_state[t]` | tile FSM: 0 idle, 1 memory wait, 2 vector execute, 3 tensor |
| `vec_issue[t]`, `lane_active[t][l]` | vector engine issue pulse; per-lane active mask (meaningful when `vec_issue[t]`) |
| `tensor_busy[t]` | tensor unit busy |
| `mem_fire[c]`, `mem_blocked[c]`, `mem_resp[c]`, `mem_align[c]` | per controller `c` (0..3 tiles, 4 control core): accepted, blocked, response, alignment error |
| `noc_occ` | occupied router buffer slots, 0..40 |
| `noc_inj_fire[t]`, `noc_inj_blocked[t]` | tile `t` NoC injection accepted / presented but not accepted |

### B.2 Tracking state (updated every clock edge, **independent of ENABLE**)

* `prog_done`: set after a cycle whose slot is `ISSUE` and whose `is_opcode == 0x1F` (HALT). Sticky until reset.
* `redir`: the **redirect shift register** (not to be confused with the snapshot shadow of B.6), `CTRL_SHADOW = 2` bits;
  `redir' = {redir[0], flush}` (bit 0 = flush one cycle ago, bit 1 = two cycles ago). `redir_any = redir[0] | redir[1]`.
* `mem_out[c]` (c = 0..4): `mem_out' = mem_fire[c] ? 1 : (mem_resp[c] ? 0 : mem_out[c])`.
  `mem_out_count = popcount(mem_out)`.
* `mach_busy = ex_valid | (tile_busy != 0) | (mem_out != 0)`.
* Unique-instruction tags: `ex_fresh' = (slot == ISSUE)`; `mem_fresh' = ex_fresh & ex_valid & !sched_valid`;
  `wb_fresh' = mem_fresh`.
* `streak` (CW bits, saturating): updated **only on counted cycles**: `streak' = is_stall_slot ? streak + 1 : 0`;
  cleared by CLEAR. It is **not** cleared by SNAP_CLR (so a stall that straddles a window boundary reports its full
  current run length in the new window).
* **CLEAR touches none of the B.2 tracking state except `streak`** (and the watchdog state of B.7): `prog_done`, `redir`,
  `mem_out` and the fresh tags keep following the core. Only reset clears them.

### B.3 Slot classification (exactly one per cycle, first match wins)

```
if   prog_done                                        -> IDLE
elif flush                                            -> BUBBLE_CTRL
elif id_stall:
       if   sync_stall                                -> STALL_SYNC
       elif load_use                                  -> STALL_DEP
       elif sched_valid and not sched_ready:
              if ex_opcode == DFSYNC (0x0E)           -> STALL_SYNC
              else  blk = tile_state[tgt_tile] if tgt_tile < NT else "out of range"
                    blk == 1 -> STALL_MEM ; blk == 2 -> STALL_EXEC_VEC ; blk == 3 -> STALL_EXEC_TENSOR
                    otherwise                         -> STALL_DISP_OTHER
       else                                           -> STALL_DISP_OTHER   (unreachable on a consistent core)
elif is_valid                                         -> ISSUE
elif redir_any                                        -> BUBBLE_CTRL
elif mach_busy                                        -> BUBBLE_FRONT
else                                                  -> IDLE
```
`is_stall_slot` = slot in {STALL_DEP, STALL_SYNC, STALL_EXEC_VEC, STALL_EXEC_TENSOR, STALL_MEM, STALL_DISP_OTHER}.

### B.4 Issue class (for cycles whose slot is `ISSUE`; by `is_opcode`)

| Counter | Opcodes |
|---|---|
| `ISS_SALU` | ADD 0x01, SUB 0x02, MUL 0x03, MOV 0x06 |
| `ISS_SMEM` | LOAD 0x04, STORE 0x05 |
| `ISS_BRANCH` | BEQ 0x07, BNE 0x08, JMP 0x09 |
| `ISS_DFMEM` | DFLOAD 0x0A, DFSTORE 0x0B, VLOAD 0x16, VSTORE 0x17 |
| `ISS_DFCTL` | DFMAP 0x0C, DFEXEC 0x0D, DFSYNC 0x0E |
| `ISS_VEC` | VADD 0x0F, VMUL 0x10, VSUB 0x11, DOT 0x12, REDUCE 0x14, BCAST 0x15 |
| `ISS_TENSOR` | MATMUL 0x13 |
| `ISS_NOP` | every other opcode (NOP 0x00, HALT 0x1F, reserved) |

### B.5 Event value added to each counter in a counted cycle

| Counter | Event value |
|---|---|
| `CYCLES` | 1 |
| `SLOT_*` | 1 for the classified slot, else 0 |
| `ISS_*` | 1 if slot is ISSUE and the class matches |
| `RET_SCALAR` | `wb_valid & wb_fresh` |
| `RET_TILE` | `popcount(tile_done)` |
| `TOK_DISPATCHED` | `popcount(tok_valid)` |
| `DROP_SYNC` / `DROP_OP` | `drop & (ex_opcode == DFSYNC)` / `drop & (ex_opcode != DFSYNC)`, where `drop = sched_valid & sched_ready & (tok_valid == 0)` |
| `BRANCH_TAKEN` | `br_taken` |
| `TILE_TOK_t` / `TILE_BUSY_t` | `tok_valid[t]` / `tile_busy[t]` |
| `VEC_ISSUES` | `popcount(vec_issue)` |
| `VEC_LANES_ACTIVE` | `sum over tiles with vec_issue[t] of popcount(lane_active[t])` |
| `VEC_ISSUES_PARTIAL` | number of tiles with `vec_issue[t]` and `0 < popcount(lane_active[t]) < LANES` |
| `VEC_BUSY_CYC` | number of tiles with `tile_state[t] == 2` |
| `TENSOR_BUSY_CYC` | `popcount(tensor_busy)` |
| `MEM_REQ_ACCEPTED` / `MEM_RESP` / `MEM_REQ_BLOCKED` / `MEM_ALIGN_ERR` | popcount of `mem_fire` / `mem_resp` / `mem_blocked` / `mem_align` |
| `MEM_OUT_SUM` | `mem_out_count` (state value at the start of the cycle) |
| `MEM_BUSY_CYC` | `mem_out_count != 0` |
| `MEM_OUT_PEAK` (peak) / `MEM_OUT_NOW` (gauge) | `mem_out_count` |
| `Q_DISP_SUM` (sum) / `Q_DISP_NOW` (gauge) | `sched_valid` |
| `Q_TOK_SUM` / `Q_TOK_PEAK` / `Q_TOK_NOW` | `popcount(tile_busy)` |
| `Q_NOC_SUM` / `Q_NOC_PEAK` / `Q_NOC_NOW` | `noc_occ` |
| `NOC_FLITS` / `NOC_INJ_BLOCKED` | `popcount(noc_inj_fire)` / `popcount(noc_inj_blocked)` |
| `STALL_STREAK_MAX` (peak) | the value `streak'` would take this cycle |

Counter kinds: *accumulate* adds the event value (saturating at `2^CW - 1`, sticky overflow bit if an increment is
lost); *peak* keeps the maximum event value seen; *gauge* stores the latest event value.

### B.6 Windows (what a snapshot contains)

* `CLEAR` executed at edge `E`: all counters, overflow bits and the shadow become 0; **the events of cycle `E` are discarded**;
  streak and watchdog restart.
* `SNAPSHOT` at edge `E`: the shadow receives the live counter values **before** edge `E`: every counted cycle in the
  current epoch with index `< E`. The events of cycle `E` stay in the live counters.
* `SNAP_CLR` at edge `E`: as `SNAPSHOT`, and then the live counters restart: `value := event(E)` if counting else 0.
  Consecutive `SNAP_CLR` windows therefore tile the timeline exactly: `[E_k, E_(k+1))`.
* Precedence in one cycle: `CLEAR` > `SNAP_CLR` > `SNAPSHOT`/`snap_trig`. A `CLEAR` written together with SNAPSHOT or
  SNAP_CLR bits executes as a plain `CLEAR` (no snapshot is taken, `SNAP_SEQ` increments once). `SNAP_CLR` together with
  `SNAPSHOT` executes as `SNAP_CLR`.
* `snap_trig` (hardware trigger input) behaves exactly as `SNAPSHOT`. It is **not represented in trace files**; the trace
  checker assumes it is never asserted (the unit testbench covers it directly).
* The epoch starts at the `CLEAR` edge (or reset). `ENABLE` set at edge `E` makes cycles `> E` counted; the `ENABLE`
  written by a CTRL write takes effect for edges after the write edge.
* A `SNAPSHOT`/`SNAP_CLR` executed while counting is disabled is legal: `SNAPSHOT` captures the current values;
  `SNAP_CLR` captures them and then sets every live counter to 0 (nothing is counted at the restart edge).
* Overflow bits: `CLEAR` and `SNAP_CLR` both clear them (a `SNAP_CLR` window is a new epoch); `SNAPSHOT` does not.
* Gauges and peaks are updated **only on counted cycles**; while disabled they hold their last value.
* `seq` in `snapshots.csv` is the value of `SNAP_SEQ` read before the data words; it equals the number of CLEAR + SNAPSHOT +
  SNAP_CLR commands executed since reset (so it skips numbers when a CLEAR intervenes). `seq_after` is `SNAP_SEQ` re-read
  after the data words; the read was coherent iff the two are equal.

### B.7 Watchdog and flags

* `progress` (evaluated every counted cycle) = `(slot == ISSUE) | (wb_valid & wb_fresh) | (tile_done != 0) | (tok_valid != 0)`.
* Watchdog state `noprog` (32-bit, saturating), updated **only on counted cycles**:
  `noprog' = progress ? 0 : noprog + 1`. `WDOG_TRIP` (sticky) is set at the end of a counted cycle if
  `thresh != 0 && !progress && noprog' >= thresh`. `thresh` is the value last written to `WDOG_THRESH`
  (it takes effect for the following edge). `CLEAR` resets `noprog` and `WDOG_TRIP`; `SNAP_CLR` does not.
* `FLAGS` captured by a snapshot (values **before** the snapshot edge): bit 0 = any counter overflow bit set,
  bit 1 = `WDOG_TRIP`, bit 2 = `prog_done`. `CLEAR` zeroes the captured flags (it does not reset `prog_done`, so the next
  snapshot reports it again).
* `tile_state` values 4-7 never occur on this core; a dispatch blocked by such a state is classified `STALL_DISP_OTHER`.
* Overflow-bit layout: bit `i` of `{ovf1, ovf0}` is counter `i` (`ovf0` = bits 31:0).

---------------------------------------------------------------------------------------------------------------

## Part C -- Check files

`trace.csv` (one row per clock edge after reset release; header line included; the `cycle` column is a **decimal** counter
0,1,2,...; every other non-1-bit column is hexadecimal), columns in order:

`cycle, en, is_valid, is_opcode, id_stall, load_use, sync_stall, flush, br_taken, ex_valid, ex_opcode, wb_valid,
sched_valid, sched_ready, tok_valid, tgt_tile, tile_busy, tile_done, tile_state, vec_issue, lane_active,
tensor_busy, mem_fire, mem_blocked, mem_resp, mem_align, noc_occ, noc_inj_fire, noc_inj_blocked`

1-bit columns are `0/1`; every other column is **hexadecimal** (`is_opcode`, `ex_opcode`: 5-bit; `tok_valid`,
`tile_busy`, `tile_done`, `vec_issue`, `tensor_busy`, `noc_inj_*`: NT bits, tile 0 = LSB; `tile_state`: 3 bits per tile,
tile 0 in the low bits; `lane_active`: LANES bits per tile, tile 0 in the low bits; `mem_*`: NT+1 bits, bit NT = control
core; `noc_occ`: 8 bits). `en` is the value of ENABLE **before** that edge (whether the cycle is counted).

`cmds.csv`: `cycle,name,value_hex` -- the cycle index of the edge that executes each CSR command. A row named `WDOG` is a
watchdog-threshold write (value = threshold); **every other row is a `CTRL` write** whatever its descriptive name (`CTRL`,
`CLEAR`, `ENABLE`, `SNAPSHOT_FINAL`, ...), value bit 0 ENABLE, bit 8 SNAPSHOT, bit 9 SNAP_CLR, bit 10 CLEAR.

`snapshots.csv`: one row per snapshot: `seq, seq_after, cmd_cycle, is_window, flags, ovf0, ovf1, <57 counters>`
(counter order = `spec/pm_counters.json`). `cmd_cycle` is the edge that executed the SNAPSHOT/SNAP_CLR command and equals the
`cycle` of the matching row in `cmds.csv`. `is_window` is 1 for SNAP_CLR rows.
Checking procedure: replay `trace.csv` (using `en`, the tracking state of B.2 and the rules of B.3-B.6) and compare the
counters accumulated over the window ending at `cmd_cycle` with the row.
