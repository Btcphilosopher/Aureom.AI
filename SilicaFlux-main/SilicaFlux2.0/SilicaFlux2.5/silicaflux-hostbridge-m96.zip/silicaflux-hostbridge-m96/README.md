# SilicaFlux HostBridge — Module 96: Host Transaction Interface

`sf_albion_host_bridge.sv` is a **synthesizable, transaction-level adapter** between the SilicaFlux interconnect
(AlbionCore **ALP v1**) and a host. In simulation the host is a bus-functional model; in a product the host-facing side
is meant to be driven by a thin shim around a licensed PCIe endpoint IP block or an FPGA hard block.

> ### What this is not
> * **Not a PCIe PHY, SERDES, data-link layer or transaction layer.** No TLP is generated, parsed or simulated.
> * **No claim of PCIe electrical, protocol or interoperability compliance**, or of compatibility with any vendor's IP.
> * **The PCIe shim is specified ([docs/PCIE_INTEGRATION.md](docs/PCIE_INTEGRATION.md)), not built.**
> * **No timing, area, power or throughput numbers.** Yosys is used for elaboration and latch checks only.
> * **"DomainGuard" did not exist in the repository** (the Module 94 audit says so). The bridge defines the guard
>   *contract*; the module `sf_albion_host_domain_guard` is a small reference implementation, not Citadel and not a
>   security proof. Citadel's plug-in is documented ([docs/DOMAIN_GUARD_SEAM.md](docs/DOMAIN_GUARD_SEAM.md)), not built.
> * Full list: [docs/LIMITATIONS.md](docs/LIMITATIONS.md).

## What it does

```
        host side (HTI v1)                                    fabric side (ALP v1)
 hreq/hw  host MMIO + memory requests ──►  req_path : validate, aperture-translate, DomainGuard, split ──► ALP initiator
 hcpl     completions (in order)      ◄──            into 16-byte words, rebuild completions        ◄──  (SRAM, registers, ...)
 dreq/dw  DMA requests to host memory ◄──  dma_path : split at MPS/MRRS, tag pool, out-of-order
 dcpl     completions from the host   ──►            completion matching, reorder buffer, in-order results ◄── DMA client port
 err_evt  {source, status, tag, addr}      cancel_i (soft)   rst_ni (hard)   grd_* DomainGuard check port
```

* **Host MMIO / memory reads and writes** with explicit `valid/ready`, address, write data, byte enables, tag,
  length and status; posted and non-posted writes.
* **Device-initiated DMA** reads and writes of host memory, burst-split at `MPS_BYTES` / `MRRS_BYTES` (never crossing a
  4 KiB boundary), tracked by tag, completions matched **out of order across tags** and returned to the client in order.
* **Transaction management:** request buffering, back-pressure on every channel, multiple outstanding requests
  (`MAX_OUT` ALP words, `NUM_TAGS` host-bound tags), tag tracking, completion matching, boundary / aperture / length /
  wrap / rights checking, completion timeout, error events.
* **Reset and cancel:** hard reset discards everything and produces no completion for a pre-reset request; soft
  `cancel_i` ends accepted-but-not-issued requests with `ABORTED` and abandons outstanding DMA tags.
* **Security:** the host cannot choose its own privilege (apertures assign the ALP attribute and rights); every
  host-originated request is offered to a DomainGuard on the `grd_*` port **before** it can reach the fabric; the demo
  guard is default-deny.
* **Integration with the existing interconnect:** the bridge's fabric port is a plain ALP v1 initiator. Stage 1 connects
  it to AlbionCore's reference subsystem (SRAM-backed demonstration). Stage 2 (`sf_albion_host_soc_demo`) adds a register
  block, a DMA engine, a two-way ALP arbiter and a small fabric.

Interface, rules and parameters: [docs/HOSTBRIDGE_SPEC.md](docs/HOSTBRIDGE_SPEC.md).

## Quick start

Needs Verilator ≥ 5.020 (with `--timing`), Yosys 0.33, Python 3, GNU make, g++.

```bash
make help        # targets
make all         # style + lint + synthesis check + all 31 simulations (about 4-5 minutes on 4 cores)
make sim-quick   # smoke + host path + system only
make mutants     # mutation campaign (slow)
```

One testbench, one configuration:

```bash
scripts/sim.sh tb_hb_system
scripts/sim.sh tb_hb_dma -GNUM_TAGS=3 -GMPS_BYTES=16 -GMRRS_BYTES=32
```

Each simulation is self-checking and ends with one `HB_TB_RESULT <tb> PASS|FAIL checks=<n> errors=<n>` line.

## Results (this package, final tree)

| Check | Result |
|---|---|
| Style rules (17, AlbionCore RTL rules) | OK |
| Verilator `-Wall` lint (warnings fatal) | 15 / 15 |
| Yosys 0.33 elaboration + generic synthesis, zero latches | 16 / 16 |
| Self-checking simulations | 31 / 31 pass, 2,966,277 checks, 0 errors |
| Mutation campaign | 58 planted bugs: 56 killed, 0 survivors, 2 provably equivalent |

Details, test inventory, mutation list, coverage, bug log and what the evidence does **not** cover:
[docs/VERIFICATION.md](docs/VERIFICATION.md).

## Layout

```
README.md                 this file
Makefile                  all / style / lint / synth / sim / seeds / mutants / dist
rtl/
  sf_albion_host_bridge.sv        PRIMARY MODULE: top of the bridge (req_path + dma_path + events)
  sf_albion_host_pkg.sv           HTI constants, status codes, ALP status mapping, byte-mask helpers
  sf_albion_host_req_path.sv      host -> device: queue, validate, translate, DomainGuard, split, complete
  sf_albion_host_dma_path.sv      device -> host: split, tags, out-of-order matching, reorder buffer
  sf_albion_host_domain_guard.sv  REFERENCE DomainGuard (window table, default deny)
  sf_albion_host_csr.sv           demo register block (ID, scratch, guard windows, DMA, error log)
  sf_albion_host_dma_engine.sv    demo DMA engine (SRAM <-> host)
  sf_albion_host_alp_arb2.sv      demo 2-initiator ALP arbiter
  sf_albion_host_alp_fabric.sv    demo ALP decode: SRAM + register window + error responder
  sf_albion_host_soc_demo.sv      stage-2 demonstration SoC
third_party/albioncore/   nine UNMODIFIED AlbionCore files (ALP package, FIFO, skid, tag tracker, reference
                          memory / subsystem, protocol checkers); checksums in docs/third_party.sha256
tb/                       host BFM, DMA client BFM, environments, 13 testbenches (testbench-only code)
scripts/                  lint, sim, synth, regression runner, mutation campaign, style check, dist
docs/
  HOSTBRIDGE_SPEC.md      HTI v1 + bridge specification
  PCIE_INTEGRATION.md     how a shim connects third-party PCIe endpoint IP (specification only)
  DOMAIN_GUARD_SEAM.md    the guard contract, Citadel plug-in (specification only), reference guard
  VERIFICATION.md         what was run and found
  LIMITATIONS.md          non-claims and known limitations
  PROVENANCE.md           what is vendored, what is new
```

## The PCIe seam in one paragraph

Four HTI channels map onto the four streams a PCIe endpoint core exposes to the application: completer request →
`hreq`/`hw`, completer completion ← `hcpl`, requester request ← `dreq`/`dw`, requester completion → `dcpl`. The shim
(not provided) does header decode/encode, byte-enable translation, tag tables, completion packetizing, width and clock
conversion, and reset mapping; HostBridge owns everything behind it. [docs/PCIE_INTEGRATION.md](docs/PCIE_INTEGRATION.md)
lists the exact obligations of the shim, field by field, and the checklist that carries HostBridge's tested guarantees
over to a real link. **Confirm every PCIe statement there against the PCI-SIG specification revision and the IP product
guide you actually license.**

## Provenance and repository state

AlbionCore (ALP v1) files are vendored unmodified for self-containment ([docs/PROVENANCE.md](docs/PROVENANCE.md)). All
other files are new work for Module 96. This package was produced as a standalone zip; **nothing was committed or
pushed to any repository.**
