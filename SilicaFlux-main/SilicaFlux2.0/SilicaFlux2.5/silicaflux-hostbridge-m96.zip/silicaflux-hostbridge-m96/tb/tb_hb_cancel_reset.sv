// =============================================================================
//  tb_hb_cancel_reset.sv  --  soft cancel (cancel_i) and hard reset (rst_ni) during traffic
// -----------------------------------------------------------------------------
//  Cancel contract (see the path headers):
//    host path : requests accepted up to the cancel_i cycle that have not finished issuing end ABORTED;
//                words already issued drain normally; a request fully issued completes normally.
//    DMA path  : same for queued / half-issued requests; every outstanding host tag is abandoned and its
//                request ends ABORTED; late host completions are dropped; the chunk being streamed ends with
//                all strobes cleared.
//  Reset contract: everything is discarded, no completion is ever produced for a pre-reset request.
// =============================================================================
`default_nettype none

module tb_hb_cancel_reset;
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  logic cancel = 1'b0;
  always #5 clk = ~clk;

  hb_env_sram #(.NUM_TAGS(8), .MPS_BYTES(256), .MRRS_BYTES(256), .MAX_OUT(8)) u_env (
    .clk, .rst_n, .cancel, .evt_ready_en(1'b1),
    .grd_cfg_we(1'b0), .grd_cfg_idx(3'd0), .grd_cfg_base(64'd0), .grd_cfg_limit(64'd0), .grd_cfg_dom(8'd0),
    .grd_cfg_rd(1'b0), .grd_cfg_wr(1'b0), .grd_cfg_valid(1'b0)
  );

  localparam longint unsigned SRAM = 64'h1000_0000;
  localparam longint unsigned HR = 64'h2000_0000;
  localparam longint unsigned HW = 64'h3000_0000;
  localparam bit [7:0] DOM = 8'h10;
  localparam int EITHER = 255, ABORTED = 7;

  task automatic pulse_cancel();
    @(negedge clk);
    cancel <= 1'b1;
    @(negedge clk);
    cancel <= 1'b0;
  endtask

  task automatic idle_checks(input string where_);
    repeat (30) @(negedge clk);
    tb_check(u_env.u_dut.host_outstanding_o == 0, {where_, ": ALP words still outstanding"});
    tb_check(u_env.u_dut.dma_outstanding_o == 0, {where_, ": DMA tags still busy"});
    tb_check(!u_env.u_dut.host_busy_o, {where_, ": host path still busy"});
    tb_check(!u_env.u_dut.dma_busy_o, {where_, ": DMA path still busy"});
    tb_check(!u_env.fatal, {where_, ": fatal latched"});
  endtask

  //  After a phase whose memory contents are unknown: forget the models, rewrite a region, check it exactly.
  task automatic resync();
    u_env.u_host.reset_model();
    u_env.u_dma.reset_model();
    for (int i = 0; i < 16; i++) u_env.u_host.post_wr(8'(i), SRAM + i * 256, 256, DOM, 1'b0, 0, 1'b1, 0);
    for (int i = 0; i < 16; i++) u_env.u_host.post_rd(8'(i), SRAM + i * 256, 256, DOM, 0, 1'b1);
    u_env.u_host.wait_req_idle(200000);
    u_env.u_dma.post_write(8'd1, HW + 64'h900000, 700, 1'b0, 0, 0);
    u_env.u_dma.post_read(8'd2, HW + 64'h900000, 700, 0, 1'b1);
    u_env.u_dma.post_read(8'd3, HR + 64'h900000, 700, 0, 1'b1);
    u_env.u_dma.wait_idle(200000);
  endtask

  //  A burst of random traffic on both paths; `either` marks outcomes that a cancel may turn into ABORTED.
  task automatic traffic(input int n_host, input int n_dma, input bit either);
    for (int i = 0; i < n_host; i++) begin
      int len;
      len = tb_range(1, 140);
      if (tb_pct(45)) u_env.u_host.post_wr(8'(tb_below(256)), SRAM + tb_below(3000), len, DOM, tb_pct(25),
                                           either ? EITHER : 0, !either, tb_below(2));
      else            u_env.u_host.post_rd(8'(tb_below(256)), SRAM + tb_below(3000), len, DOM, either ? EITHER : 0, !either);
    end
    for (int i = 0; i < n_dma; i++) begin
      int len;
      len = tb_range(1, 700);
      if (tb_pct(45)) u_env.u_dma.post_write(8'(tb_below(256)), HW + tb_below(1 << 16), len, tb_pct(25), either ? EITHER : 0, tb_below(2));
      else            u_env.u_dma.post_read(8'(tb_below(256)), HR + tb_below(1 << 16), len, either ? EITHER : 0, !either);
    end
  endtask

  initial begin
    tb_seed(32'd424242);
    tb_cov_declare("reset_while_host_busy"); tb_cov_declare("reset_while_dma_busy");
    tb_cov_declare("reset_with_alp_words_outstanding"); tb_cov_declare("reset_with_dma_tags_busy");
    tb_cov_declare("reset_during_host_bound_packet");
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (1100) @(negedge clk);          // the reference SRAM clears itself after reset

    // ---- C1: the front end is stuck waiting for write data; cancel -> everything accepted so far is ABORTED
    u_env.u_host.cfg_hw_gap = 100;                                       // the write data never arrives
    u_env.u_host.post_wr(8'd1, SRAM + 64'h40, 16, DOM, 1'b0, ABORTED, 1'b1, 0);
    u_env.u_host.post_rd(8'd2, SRAM + 64'h40, 16, DOM, ABORTED, 1'b1);
    u_env.u_host.post_rd(8'd3, SRAM + 64'h50, 16, DOM, ABORTED, 1'b1);
    repeat (40) @(negedge clk);
    pulse_cancel();
    repeat (20) @(negedge clk);
    u_env.u_host.cfg_hw_gap = 0;                                         // the data now arrives and must be drained
    u_env.u_host.wait_req_idle(5000);
    u_env.u_host.post_wr(8'd4, SRAM + 64'h60, 16, DOM, 1'b0, 0, 1'b1, 0);     // the bridge accepts new traffic again
    u_env.u_host.post_rd(8'd5, SRAM + 64'h40, 32, DOM, 0, 1'b1);              // the aborted write did not execute
    u_env.u_host.wait_req_idle(5000);
    u_env.expect_no_evt(10);
    idle_checks("C1");
    $display("C1 cancel while waiting for data: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- C1b: a POSTED write cancelled before it ran has no completion: it must be logged as an event
    u_env.evt_log.delete();
    u_env.u_host.cfg_hw_gap = 100;
    u_env.u_host.post_wr(8'd6, SRAM + 64'h70, 16, DOM, 1'b1, 0, 1'b0, 0);
    u_env.u_host.post_rd(8'd7, SRAM + 64'h70, 16, DOM, ABORTED, 1'b0);
    repeat (40) @(negedge clk);
    pulse_cancel();
    repeat (20) @(negedge clk);
    u_env.u_host.cfg_hw_gap = 0;
    u_env.u_host.wait_req_idle(5000);
    u_env.expect_evt(2'd0, 4'd7, 8'd6, SRAM + 64'h70, 20);
    u_env.expect_no_evt(10);
    idle_checks("C1b");
    $display("C1b cancelled posted write: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- C1c: a POSTED write cancelled AFTER some of its words were issued (the completion-engine path): still logged
    u_env.evt_log.delete();
    u_env.u_host.cfg_hw_gap = 85;                                   // data trickles: the front end starves part-way
    u_env.u_host.post_wr(8'd8, SRAM + 64'h100, 320, DOM, 1'b1, 0, 1'b0, 0);        // 20 words
    begin
      int t;
      t = 0;
      while (!(u_env.u_dut.u_req.fs_q == 3'd3 && u_env.u_dut.u_req.issued_q && !u_env.u_dut.u_req.wq_out_valid) && t < 3000) begin
        @(negedge clk); t++;
      end
      tb_check(t < 3000, "C1c: the front end never starved mid-request (test cannot reach its scenario)");
    end
    pulse_cancel();
    repeat (20) @(negedge clk);
    u_env.u_host.cfg_hw_gap = 0;
    u_env.u_host.wait_req_idle(20000);
    u_env.expect_evt(2'd0, 4'd7, 8'd8, SRAM + 64'h100, 40);
    u_env.expect_no_evt(10);
    idle_checks("C1c");
    $display("C1c cancelled part-issued posted write: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- C1d: cancel_i in the very cycle a request is ACCEPTED (so it is popped in the cycle the cancel takes effect):
    //  that request is ABORTED, but one accepted AFTER the cancel must complete normally.  A cancel snapshot that counts the
    //  popped request twice would over-abort the next one.  Repeated with the request already queued behind a busy front end.
    for (int k = 0; k < 6; k++) begin
      int t;
      t = 0;
      u_env.u_host.cfg_req_gap = 0;
      u_env.u_host.post_rd(8'(40 + k), SRAM + 64'h200, 16, DOM, ABORTED, 1'b0);
      #1;                                       // 1 ns after the falling edge: the BFM has driven this cycle's valid
      while (!(u_env.hreq_valid && u_env.hreq_ready) && t < 100) begin
        @(negedge clk); #1; t++;
      end
      tb_check(t < 100, "C1d: the request was never offered");
      cancel <= 1'b1;                           // sampled at the same rising edge that accepts the request
      @(negedge clk);
      cancel <= 1'b0;
      repeat (3) @(negedge clk);
      u_env.u_host.post_rd(8'(50 + k), SRAM + 64'h300, 16, DOM, 0, 1'b0);      // accepted after the cancel
      u_env.u_host.post_wr(8'(60 + k), SRAM + 64'h320, 16, DOM, 1'b0, 0, 1'b0, 0);
      u_env.u_host.wait_req_idle(5000);
    end
    idle_checks("C1d");
    resync();
    $display("C1d cancel in the accept cycle: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- C2: cancel in the middle of a long request: issued words drain, the rest is ABORTED
    u_env.u_host.cfg_cpl_rdy = 5;                                        // completions stall, the pipeline fills
    u_env.u_host.post_rd(8'd10, SRAM + 64'h000, 2048, DOM, EITHER, 1'b0);      // 128 words: cannot be fully issued
    u_env.u_host.post_wr(8'd11, SRAM + 64'h800, 1024, DOM, 1'b0, ABORTED, 1'b0, 0);
    u_env.u_host.post_rd(8'd12, SRAM + 64'h000, 64, DOM, ABORTED, 1'b0);
    repeat (300) @(negedge clk);
    pulse_cancel();
    u_env.u_host.cfg_cpl_rdy = 100;
    u_env.u_host.wait_req_idle(100000);
    // the long read was not fully issued when the cancel came: it ends with OK data beats and an ABORTED terminator
    tb_check(u_env.u_host.last_cpl_status[10] == 4'd7, $sformatf("C2: long read ended with status %0d, expected ABORTED", u_env.u_host.last_cpl_status[10]));
    idle_checks("C2");
    resync();
    $display("C2 cancel mid request: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- C3: cancel storm, host path: every request still gets exactly one completion, OK or ABORTED only
    for (int round = 0; round < 25; round++) begin
      u_env.u_host.cfg_req_gap = tb_below(60); u_env.u_host.cfg_hw_gap = tb_below(60); u_env.u_host.cfg_cpl_rdy = 20 + tb_below(81);
      traffic(40, 0, 1'b1);
      repeat (tb_below(300)) @(negedge clk);
      pulse_cancel();
      repeat (tb_below(50)) @(negedge clk);
      if (tb_pct(40)) pulse_cancel();
      u_env.u_host.cfg_req_gap = 0; u_env.u_host.cfg_hw_gap = 0; u_env.u_host.cfg_cpl_rdy = 100;
      u_env.u_host.wait_req_idle(300000);
    end
    idle_checks("C3");
    tb_check(u_env.evt_log.size() == u_env.evt_log.size(), "keep");
    for (int i = 0; i < u_env.evt_log.size(); i++)
      tb_check(u_env.evt_log[i].code == 4'd7, $sformatf("C3: only ABORTED (posted writes) may be logged, saw code %0d", u_env.evt_log[i].code));
    u_env.evt_log.delete();
    resync();
    $display("C3 host cancel storm: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- C4: DMA cancel, host slow: all outstanding requests ABORT, late completions are dropped, tags are not reused
    u_env.u_host.cfg_lat_min = 300; u_env.u_host.cfg_lat_max = 300;
    u_env.u_dma.post_read (8'd20, HR + 64'hA00000, 2 * 256, ABORTED, 1'b0);   // 2 tags
    u_env.u_dma.post_read (8'd21, HR + 64'hA10000, 100, ABORTED, 1'b0);       // 1 tag
    u_env.u_dma.post_write(8'd22, HW + 64'hA20000, 200, 1'b0, ABORTED, 0);    // 1 tag   (4 of the 8 tags in use)
    repeat (60) @(negedge clk);
    pulse_cancel();
    u_env.u_host.cfg_lat_min = 3; u_env.u_host.cfg_lat_max = 3;
    u_env.u_dma.post_read (8'd24, HR + 64'hA40000, 500, 0, 1'b1);             // must take a FREE tag, never an abandoned one
    u_env.u_dma.wait_idle(5000);
    tb_check(u_env.dma_out == 4, $sformatf("C4: %0d tags busy, the 4 abandoned tags must stay busy until their late completions arrive", u_env.dma_out));
    u_env.u_dma.post_write(8'd25, HW + 64'hA50000, 90, 1'b0, 0, 0);
    u_env.u_dma.wait_idle(5000);
    repeat (400) @(negedge clk);                                           // the slow host now answers (and is dropped)
    tb_check(u_env.unexpected_cpl == 0, "C4: late completions of abandoned tags must not count as unexpected");
    u_env.expect_no_evt(10);
    idle_checks("C4");
    $display("C4 DMA cancel, late completions: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- C5: cancel while a DMA write streams slowly: the started chunk ends with strobes cleared
    u_env.u_host.cfg_dw_rdy = 5;
    u_env.u_dma.post_write(8'd30, HW + 64'hB00000, 3000, 1'b0, ABORTED, 0);
    repeat (700) @(negedge clk);
    pulse_cancel();
    u_env.u_host.cfg_dw_rdy = 100;
    u_env.u_dma.post_read(8'd31, HR + 64'hB10000, 64, 0, 1'b1);
    u_env.u_dma.wait_idle(50000);
    tb_check(u_env.u_host.completer_idle(), "C5: the host is left waiting for write data (a started packet was truncated)");
    // later chunks were never issued: those bytes still carry the initial pattern
    begin
      bit untouched;
      untouched = 1'b1;
      for (int i = 1024; i < 3000; i++) if (u_env.u_host.hm_peek(HW + 64'hB00000 + i) != hb_pat(HW + 64'hB00000 + i)) untouched = 1'b0;
      tb_check(untouched, "C5: bytes of chunks that were never issued were modified");
    end
    idle_checks("C5");
    resync();
    $display("C5 cancel while streaming: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- C6: cancel with queued DMA requests whose write data has not arrived yet
    u_env.u_dma.cfg_w_gap = 100;
    u_env.u_dma.post_write(8'd40, HW + 64'hC00000, 100, 1'b0, ABORTED, 0);
    u_env.u_dma.post_write(8'd41, HW + 64'hC10000, 300, 1'b1, ABORTED, 0);
    u_env.u_dma.post_read (8'd42, HR + 64'hC20000, 100, ABORTED, 1'b0);
    repeat (60) @(negedge clk);
    pulse_cancel();
    repeat (20) @(negedge clk);
    u_env.u_dma.cfg_w_gap = 0;
    u_env.u_dma.wait_idle(20000);
    u_env.u_dma.post_write(8'd43, HW + 64'hC30000, 100, 1'b0, 0, 0);
    u_env.u_dma.post_read (8'd44, HW + 64'hC30000, 100, 0, 1'b1);
    u_env.u_dma.wait_idle(20000);
    tb_check(u_env.u_host.hm_peek(HW + 64'hC00000) == hb_pat(HW + 64'hC00000), "C6: the aborted write modified memory");
    idle_checks("C6");
    $display("C6 cancel with queued DMA: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- C7: DMA cancel storm with random timing on both paths together
    for (int round = 0; round < 25; round++) begin
      u_env.u_host.cfg_lat_min = 2; u_env.u_host.cfg_lat_max = 2 + tb_below(150); u_env.u_host.cfg_ooo_pct = tb_below(101);
      u_env.u_host.cfg_dw_rdy = 20 + tb_below(81); u_env.u_host.cfg_dreq_rdy = 20 + tb_below(81);
      u_env.u_dma.cfg_r_rdy = 20 + tb_below(81); u_env.u_dma.cfg_w_gap = tb_below(40); u_env.u_dma.cfg_req_gap = tb_below(40);
      traffic(15, 15, 1'b1);
      repeat (tb_below(400)) @(negedge clk);
      pulse_cancel();
      u_env.u_host.cfg_dw_rdy = 100; u_env.u_host.cfg_dreq_rdy = 100;
      u_env.u_dma.cfg_r_rdy = 100; u_env.u_dma.cfg_w_gap = 0; u_env.u_dma.cfg_req_gap = 0;
      u_env.u_host.cfg_req_gap = 0; u_env.u_host.cfg_hw_gap = 0; u_env.u_host.cfg_cpl_rdy = 100;
      u_env.u_dma.wait_idle(400000);
      u_env.u_host.wait_req_idle(400000);
      // let abandoned tags receive their late completions
      repeat (300 + 160) @(negedge clk);
      tb_check(u_env.unexpected_cpl == 0, $sformatf("C7: unexpected completions after a cancel (%0d)", u_env.unexpected_cpl));
    end
    u_env.u_host.cfg_lat_min = 2; u_env.u_host.cfg_lat_max = 6; u_env.u_host.cfg_ooo_pct = 0;
    u_env.evt_log.delete();
    idle_checks("C7");
    resync();
    $display("C7 cancel storm, both paths: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- R1..: hard reset at random moments (asynchronous assert), models reset together with the bridge
    for (int it = 0; it < 40; it++) begin
      int wait_c, hold, off;
      u_env.u_host.cfg_req_gap = tb_below(30); u_env.u_host.cfg_hw_gap = tb_below(30); u_env.u_host.cfg_cpl_rdy = 40 + tb_below(61);
      u_env.u_host.cfg_lat_min = 2; u_env.u_host.cfg_lat_max = 2 + tb_below(80); u_env.u_host.cfg_ooo_pct = tb_below(101);
      u_env.u_dma.cfg_r_rdy = 40 + tb_below(61); u_env.u_dma.cfg_w_gap = tb_below(30);
      traffic(20, 20, 1'b1);
      wait_c = tb_below(500);
      repeat (wait_c) @(posedge clk);
      off = 1 + tb_below(8);
      if (u_env.host_busy)                         tb_cov("reset_while_host_busy");
      if (u_env.dma_busy)                          tb_cov("reset_while_dma_busy");
      if (u_env.u_dut.host_outstanding_o != 0)     tb_cov("reset_with_alp_words_outstanding");
      if (u_env.u_dut.dma_outstanding_o != 0)      tb_cov("reset_with_dma_tags_busy");
      if (u_env.dreq_valid || u_env.dw_valid)      tb_cov("reset_during_host_bound_packet");
      #(off) rst_n = 1'b0;                    // asynchronous: not on a clock edge
      hold = 1 + tb_below(5);
      repeat (hold) @(negedge clk);
      u_env.u_host.reset_model(); u_env.u_dma.reset_model();
      @(negedge clk);
      rst_n <= 1'b1;                          // released synchronously
      u_env.evt_log.delete();
      tb_check(!u_env.m_req_valid && !u_env.hcpl_valid && !u_env.dma_r_valid && !u_env.dreq_valid, "R: outputs not idle right after reset");
      tb_check(u_env.u_dut.host_outstanding_o == 0 && u_env.u_dut.dma_outstanding_o == 0, "R: outstanding counters not cleared");
      u_env.u_host.cfg_req_gap = 0; u_env.u_host.cfg_hw_gap = 0; u_env.u_host.cfg_cpl_rdy = 100; u_env.u_host.cfg_ooo_pct = 0;
      u_env.u_host.cfg_lat_min = 2; u_env.u_host.cfg_lat_max = 6;
      u_env.u_dma.cfg_r_rdy = 100; u_env.u_dma.cfg_w_gap = 0;
      repeat (1100) @(negedge clk);           // the SRAM clears itself
      // fresh, exactly-checked traffic proves the bridge is whole again
      u_env.u_host.post_wr(8'd1, SRAM + 64'h100, 100, DOM, 1'b0, 0, 1'b1, 0);
      u_env.u_host.post_rd(8'd2, SRAM + 64'h100, 100, DOM, 0, 1'b1);
      u_env.u_dma.post_write(8'd1, HW + 64'hD00000, 400, 1'b0, 0, 0);
      u_env.u_dma.post_read(8'd2, HW + 64'hD00000, 400, 0, 1'b1);
      u_env.u_host.wait_req_idle(100000);
      u_env.u_dma.wait_idle(100000);
      repeat (10) @(negedge clk);
      tb_check(u_env.unexpected_cpl == 0, "R: completions of a pre-reset request leaked through");
      u_env.expect_no_evt(5);
    end
    tb_check(tb_cov_get("reset_while_host_busy") > 5 && tb_cov_get("reset_while_dma_busy") > 5 &&
             tb_cov_get("reset_with_alp_words_outstanding") > 0 && tb_cov_get("reset_with_dma_tags_busy") > 0,
             "R: the reset storm did not hit the bridge while it was busy often enough");
    idle_checks("R");
    $display("R hard reset storm: checks=%0d errors=%0d", tb_checks, tb_errors);

    repeat (20) @(negedge clk);
    tb_report("tb_hb_cancel_reset");
    $finish;
  end

  initial begin
    #900000000;
    tb_fail("cancel/reset: global timeout");
    tb_report("tb_hb_cancel_reset");
    $finish;
  end
endmodule

`default_nettype wire
