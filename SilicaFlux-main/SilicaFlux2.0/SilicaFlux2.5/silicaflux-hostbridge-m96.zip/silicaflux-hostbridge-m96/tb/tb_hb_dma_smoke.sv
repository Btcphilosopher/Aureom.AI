// =============================================================================
//  tb_hb_dma_smoke.sv  --  first-light test of the DMA path
// =============================================================================
`default_nettype none

module tb_hb_dma_smoke;
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  always #5 clk = ~clk;

  hb_env_sram u_env (
    .clk, .rst_n, .cancel(1'b0), .evt_ready_en(1'b1),
    .grd_cfg_we(1'b0), .grd_cfg_idx(3'd0), .grd_cfg_base(64'd0), .grd_cfg_limit(64'd0), .grd_cfg_dom(8'd0),
    .grd_cfg_rd(1'b0), .grd_cfg_wr(1'b0), .grd_cfg_valid(1'b0)
  );

  task automatic phase(input string name, input int ooo);
    u_env.u_host.cfg_ooo_pct = ooo;
    u_env.u_dma.post_read (8'd1, 64'h2000_0000, 64,   0, 1'b1);
    u_env.u_dma.post_write(8'd2, 64'h3000_0000, 64,   1'b0, 0, 0);
    u_env.u_dma.post_read (8'd3, 64'h3000_0000, 64,   0, 1'b1);
    u_env.u_dma.post_read (8'd4, 64'h2000_0013, 37,   0, 1'b1);
    u_env.u_dma.post_write(8'd5, 64'h3000_0107, 301,  1'b0, 0, 0);
    u_env.u_dma.post_read (8'd6, 64'h3000_0100, 320,  0, 1'b1);
    u_env.u_dma.post_read (8'd7, 64'h2000_0F10, 1000, 0, 1'b1);     // crosses a 4 KiB boundary, 4+ chunks
    u_env.u_dma.post_write(8'd8, 64'h3000_0FF0, 1500, 1'b1, 0, 0);  // posted, crosses 4 KiB
    u_env.u_dma.post_read (8'd9, 64'h3000_0FF0, 1500, 0, 1'b1);
    u_env.u_dma.wait_idle(200000);
    $display("%s: checks=%0d errors=%0d  dreq(rd/wr/wrp)=%0d/%0d/%0d max_tags=%0d ooo_switches=%0d", name,
             tb_checks, tb_errors, u_env.u_host.n_dreq_rd, u_env.u_host.n_dreq_wr, u_env.u_host.n_dreq_wrp,
             u_env.u_host.max_tags_seen, u_env.u_host.n_ooo_switches);
  endtask

  initial begin
    tb_seed(32'd11);
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (4) @(negedge clk);
    phase("in-order host", 0);
    phase("out-of-order host", 100);
    repeat (20) @(negedge clk);
    tb_report("tb_hb_dma_smoke");
    $finish;
  end

  initial begin
    #5000000;
    tb_fail("dma smoke: global timeout");
    tb_report("tb_hb_dma_smoke");
    $finish;
  end
endmodule

`default_nettype wire
