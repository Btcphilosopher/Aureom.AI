// =============================================================================
//  hb_env_soc.sv  --  stage-2 verification environment: the demonstration SoC (testbench only)
// -----------------------------------------------------------------------------
//  sf_albion_host_soc_demo (bridge + DomainGuard + CSR block + DMA engine + ALP arbiter + fabric with SRAM) driven
//  by the host bus-functional model on the HTI channels.  The AlbionCore ALP link checker is bound to four links:
//  the bridge's, the DMA engine's, the merged link into the fabric, and the link into the register block.
// =============================================================================
`default_nettype none

module hb_env_soc #(
  parameter int unsigned NUM_TAGS    = 8,
  parameter int unsigned MPS_BYTES   = 256,
  parameter int unsigned MRRS_BYTES  = 256,
  parameter int unsigned CPL_TIMEOUT = 0
) (
  input wire logic clk,
  input wire logic rst_n,
  input wire logic cancel
);
  import sf_hb_tb_pkg::*;

  logic        hreq_valid, hreq_ready, hw_valid, hw_ready, hw_last;
  logic [1:0]  hreq_kind;
  logic [63:0] hreq_addr;
  logic [12:0] hreq_len;
  logic [7:0]  hreq_tag, hreq_dom;
  logic [127:0] hw_data;
  logic [15:0]  hw_be;
  logic        hcpl_valid, hcpl_ready, hcpl_last;
  logic [7:0]  hcpl_tag;
  logic [3:0]  hcpl_status;
  logic [127:0] hcpl_data;
  logic        dreq_valid, dreq_ready, dw_valid, dw_ready, dw_last;
  logic [1:0]  dreq_kind;
  logic [63:0] dreq_addr;
  logic [12:0] dreq_len;
  logic [7:0]  dreq_tag;
  logic [127:0] dw_data;
  logic [15:0]  dw_be;
  logic        dcpl_valid, dcpl_ready, dcpl_last;
  logic [7:0]  dcpl_tag;
  logic [3:0]  dcpl_status;
  logic [127:0] dcpl_data;
  logic [31:0] deny_count;
  logic        fatal;

  sf_albion_host_soc_demo #(.NUM_TAGS(NUM_TAGS), .MPS_BYTES(MPS_BYTES), .MRRS_BYTES(MRRS_BYTES), .CPL_TIMEOUT(CPL_TIMEOUT)) u_soc (
    .clk_i(clk), .rst_ni(rst_n), .cancel_i(cancel),
    .hreq_valid_i(hreq_valid), .hreq_ready_o(hreq_ready), .hreq_kind_i(hreq_kind), .hreq_addr_i(hreq_addr),
    .hreq_len_i(hreq_len), .hreq_tag_i(hreq_tag), .hreq_dom_i(hreq_dom),
    .hw_valid_i(hw_valid), .hw_ready_o(hw_ready), .hw_data_i(hw_data), .hw_be_i(hw_be), .hw_last_i(hw_last),
    .hcpl_valid_o(hcpl_valid), .hcpl_ready_i(hcpl_ready), .hcpl_tag_o(hcpl_tag), .hcpl_status_o(hcpl_status),
    .hcpl_data_o(hcpl_data), .hcpl_last_o(hcpl_last),
    .dreq_valid_o(dreq_valid), .dreq_ready_i(dreq_ready), .dreq_kind_o(dreq_kind), .dreq_addr_o(dreq_addr),
    .dreq_len_o(dreq_len), .dreq_tag_o(dreq_tag),
    .dw_valid_o(dw_valid), .dw_ready_i(dw_ready), .dw_data_o(dw_data), .dw_be_o(dw_be), .dw_last_o(dw_last),
    .dcpl_valid_i(dcpl_valid), .dcpl_ready_o(dcpl_ready), .dcpl_tag_i(dcpl_tag), .dcpl_status_i(dcpl_status),
    .dcpl_data_i(dcpl_data), .dcpl_last_i(dcpl_last),
    .guard_deny_count_o(deny_count), .fatal_o(fatal)
  );

  sf_hti_host_bfm #(.NUM_TAGS_MAX(NUM_TAGS), .MPS(MPS_BYTES), .MRRS(MRRS_BYTES)) u_host (
    .clk, .rst_n, .cancel_i(cancel),
    .hreq_valid, .hreq_ready, .hreq_kind, .hreq_addr, .hreq_len, .hreq_tag, .hreq_dom,
    .hw_valid, .hw_ready, .hw_data, .hw_be, .hw_last,
    .hcpl_valid, .hcpl_ready, .hcpl_tag, .hcpl_status, .hcpl_data, .hcpl_last,
    .dreq_valid, .dreq_ready, .dreq_kind, .dreq_addr, .dreq_len, .dreq_tag,
    .dw_valid, .dw_ready, .dw_data, .dw_be, .dw_last,
    .dcpl_valid, .dcpl_ready, .dcpl_tag, .dcpl_status, .dcpl_data, .dcpl_last
  );

  // ---- ALP protocol monitors on the four links ----------------------------------------------------------------
  logic [15:0] o_b, o_e, o_t, o_c;
  sf_albion_link_checker #(.MAX_OUTSTANDING(8)) u_chk_bridge (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(u_soc.b_req_valid), .req_ready_i(u_soc.b_req_ready), .req_i(u_soc.b_req),
    .rsp_valid_i(u_soc.b_rsp_valid), .rsp_ready_i(u_soc.b_rsp_ready), .rsp_i(u_soc.b_rsp),
    .waive_req_i(1'b0), .outstanding_o(o_b)
  );
  sf_albion_link_checker #(.MAX_OUTSTANDING(8)) u_chk_engine (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(u_soc.e_req_valid), .req_ready_i(u_soc.e_req_ready), .req_i(u_soc.e_req),
    .rsp_valid_i(u_soc.e_rsp_valid), .rsp_ready_i(u_soc.e_rsp_ready), .rsp_i(u_soc.e_rsp),
    .waive_req_i(1'b0), .outstanding_o(o_e)
  );
  sf_albion_link_checker #(.MAX_OUTSTANDING(40)) u_chk_merged (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(u_soc.t_req_valid), .req_ready_i(u_soc.t_req_ready), .req_i(u_soc.t_req),
    .rsp_valid_i(u_soc.t_rsp_valid), .rsp_ready_i(u_soc.t_rsp_ready), .rsp_i(u_soc.t_rsp),
    .waive_req_i(1'b0), .outstanding_o(o_t)
  );
  sf_albion_link_checker #(.MAX_OUTSTANDING(40)) u_chk_csr (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(u_soc.c_req_valid), .req_ready_i(u_soc.c_req_ready), .req_i(u_soc.c_req),
    .rsp_valid_i(u_soc.c_rsp_valid), .rsp_ready_i(u_soc.c_rsp_ready), .rsp_i(u_soc.c_rsp),
    .waive_req_i(1'b0), .outstanding_o(o_c)
  );

  always @(posedge clk) if (rst_n && fatal) tb_fail("SoC bridge latched a fatal ALP link error");
  //  neither initiator may put an illegal request on its ALP link
  always @(posedge clk) begin
    if (rst_n && u_soc.b_req_valid && u_soc.b_req_ready)
      tb_check(sf_albion_pkg::sf_req_check(u_soc.b_req) == sf_albion_pkg::SF_ST_OKAY, "the bridge issued an ILLEGAL ALP request");
    if (rst_n && u_soc.e_req_valid && u_soc.e_req_ready)
      tb_check(sf_albion_pkg::sf_req_check(u_soc.e_req) == sf_albion_pkg::SF_ST_OKAY, "the DMA engine issued an ILLEGAL ALP request");
  end
  always @(posedge clk) begin
    if (!rst_n) tb_check(!hcpl_valid && !dreq_valid && !dw_valid && !u_soc.b_req_valid && !u_soc.e_req_valid,
                         "a valid output is high while rst_n is low");
  end

  int max_merged = 0;
  always @(posedge clk) if (rst_n && o_t > max_merged) max_merged = o_t;
endmodule

`default_nettype wire
