// =============================================================================
//  tb_hb_dma_timeout.sv  --  completion timeout, abandoned tags, late completions
// -----------------------------------------------------------------------------
//  CPL_TIMEOUT = 200 cycles.  A tag with no completion is abandoned with SF_HS_TIMEOUT after the first period
//  and released after the second even if the host never answers; a late completion for an abandoned tag is
//  dropped without side effects.
// =============================================================================
`default_nettype none

module tb_hb_dma_timeout #(
  parameter int unsigned TMO = 200
);
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  always #5 clk = ~clk;

  hb_env_sram #(.NUM_TAGS(8), .MPS_BYTES(256), .MRRS_BYTES(256), .CPL_TIMEOUT(TMO)) u_env (
    .clk, .rst_n, .cancel(1'b0), .evt_ready_en(1'b1),
    .grd_cfg_we(1'b0), .grd_cfg_idx(3'd0), .grd_cfg_base(64'd0), .grd_cfg_limit(64'd0), .grd_cfg_dom(8'd0),
    .grd_cfg_rd(1'b0), .grd_cfg_wr(1'b0), .grd_cfg_valid(1'b0)
  );

  localparam longint unsigned HR = 64'h2000_0000;
  localparam longint unsigned HW = 64'h3000_0000;
  localparam longint unsigned SIL = 64'h2080_0000;   // silent region
  localparam bit [3:0] TIMEOUT = 4'd8;
  longint t0, t1;

  initial begin
    tb_seed(32'd5150);
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (4) @(negedge clk);

    // ---- T1: a silent read times out after TMO cycles; the tag is released after a second period
    u_env.u_host.set_error_window(0, SIL, SIL + 64'hFFFF, 4'h0, 1'b1, 1'b1, 0, 1'b1);
    t0 = $time;
    u_env.u_dma.post_read(8'd1, SIL + 64'h100, 32, int'(TIMEOUT), 1'b0);
    u_env.u_dma.wait_idle(5000);
    t1 = $time;
    tb_check((t1 - t0) / 10 >= TMO - 5 && (t1 - t0) / 10 <= TMO + 40,
             $sformatf("T1: timeout after %0d cycles, configured %0d", (t1 - t0) / 10, TMO));
    tb_check(u_env.dma_out == 1, "T1: the abandoned tag must stay busy until its second period ends");
    u_env.expect_evt(2'd1, TIMEOUT, 8'd1, SIL + 64'h100, 40);
    repeat (TMO + 40) @(negedge clk);
    tb_check(u_env.dma_out == 0, "T1: the abandoned tag was not released after the second period");
    u_env.u_host.forget_tag(8'd0);
    u_env.u_dma.post_read(8'd2, HR + 64'h100, 64, 0, 1'b1);                       // the system is healthy again
    u_env.u_dma.wait_idle(5000);
    u_env.expect_no_evt(10);
    $display("T1 timeout + release: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- T2: late completion of an abandoned tag is dropped silently and releases the tag
    u_env.u_dma.post_read(8'd3, SIL + 64'h200, 32, int'(TIMEOUT), 1'b0);          // 2 words, silent
    u_env.u_dma.wait_idle(5000);
    u_env.expect_evt(2'd1, TIMEOUT, 8'd3, SIL + 64'h200, 40);
    tb_check(u_env.dma_out == 1, "T2: tag should still be busy");
    u_env.u_host.send_raw_cpl(8'd0, 4'h0, 128'hDEAD, 1'b0);                       // the host answers LATE (2 words)
    u_env.u_host.send_raw_cpl(8'd0, 4'h0, 128'hBEEF, 1'b1);
    repeat (20) @(negedge clk);
    tb_check(u_env.dma_out == 0, "T2: the late completion should have released the tag");
    tb_check(u_env.unexpected_cpl == 0, "T2: a late completion for an abandoned tag is not 'unexpected'");
    u_env.expect_no_evt(10);
    u_env.u_host.forget_tag(8'd0);
    u_env.u_host.send_raw_cpl(8'd0, 4'h0, 128'h1, 1'b1);                           // a SECOND late beat: now unexpected
    repeat (20) @(negedge clk);
    tb_check(u_env.unexpected_cpl == 1, "T2: a beat for a released tag must count as unexpected");
    u_env.evt_log.delete();
    u_env.u_dma.post_read(8'd4, HR + 64'h300, 48, 0, 1'b1);
    u_env.u_dma.wait_idle(5000);
    $display("T2 late completion: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- T3: a non-posted write whose acknowledgement never comes
    u_env.u_dma.post_write(8'd5, SIL + 64'h300, 32, 1'b0, int'(TIMEOUT), 0);
    u_env.u_dma.wait_idle(5000);
    u_env.expect_evt(2'd1, TIMEOUT, 8'd5, SIL + 64'h300, 40);
    repeat (TMO + 40) @(negedge clk);
    tb_check(u_env.dma_out == 0, "T3: tag of the silent write was not released");
    u_env.u_host.forget_tag(8'd0);
    $display("T3 silent write ack: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- T4: slow but in time (latency < timeout): nothing may time out
    u_env.u_host.clear_error_windows();
    u_env.u_host.cfg_lat_min = TMO / 2; u_env.u_host.cfg_lat_max = TMO - 60; u_env.u_host.cfg_ooo_pct = 100;
    for (int i = 0; i < 60; i++) begin
      if (tb_pct(30)) u_env.u_dma.post_write(8'(100 + i), HW + 64'h10000 + i * 300, 1 + tb_below(500), 1'b0, 0, 0);
      else            u_env.u_dma.post_read(8'(100 + i), HR + 64'h10000 + i * 300, 1 + tb_below(500), 0, 1'b1);
    end
    u_env.u_dma.wait_idle(500000);
    u_env.expect_no_evt(10);
    u_env.u_host.cfg_lat_min = 2; u_env.u_host.cfg_lat_max = 6; u_env.u_host.cfg_ooo_pct = 0;
    $display("T4 slow in-time traffic: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- T5: the MIDDLE chunk of a read is silent: chunk 1 data, then TIMEOUT; chunk 3 is discarded
    begin
      longint unsigned base;
      base = HR + 64'h40000;
      u_env.u_host.set_error_window(0, base + 256, base + 256 + 3, 4'h0, 1'b1, 1'b0, 0, 1'b1);
      u_env.u_dma.post_read(8'd150, base, 3 * 256, int'(TIMEOUT), 1'b1);
      u_env.u_dma.post_read(8'd151, base + 64'h10000, 300, 0, 1'b1);
      u_env.u_dma.wait_idle(10000);
      u_env.expect_evt(2'd1, TIMEOUT, 8'd150, base + 256, 40);
      repeat (2 * TMO + 40) @(negedge clk);
      tb_check(u_env.dma_out == 0, "T5: tags not all released");
      u_env.u_host.forget_tag(8'd1);
      u_env.u_host.clear_error_windows();
      u_env.expect_no_evt(10);
    end
    $display("T5 silent middle chunk: checks=%0d errors=%0d", tb_checks, tb_errors);

    tb_check(!u_env.u_dut.dma_busy_o, "DMA path still busy at the end");
    tb_check(!u_env.fatal, "fatal latched");
    repeat (20) @(negedge clk);
    tb_report("tb_hb_dma_timeout");
    $finish;
  end

  initial begin
    #300000000;
    tb_fail("dma timeout: global timeout");
    tb_report("tb_hb_dma_timeout");
    $finish;
  end
endmodule

`default_nettype wire
