// =============================================================================
//  sf_hb_alp_corrupt.sv  --  response fault injector for the ALP link (testbench only)
// -----------------------------------------------------------------------------
//  Sits between a conforming ALP target and the bridge.  It watches the requests that were accepted (in order,
//  ALP-ORD-01), so each response can be matched with the request it answers, and mutates the response by
//  address-window rules set by the test:
//    mode 0  replace the status by `status` and zero the data     (what a failing target looks like)
//    mode 1  corrupt the tag                                       (protocol violation: bridge must latch fatal)
//    mode 2  flip meta.is_write                                    (non-conforming: bridge reports PROTO)
//    mode 3  non-OKAY status with non-zero data / bad flags        (not well-formed: bridge reports PROTO)
//  With no rule active the module is a wire.
// =============================================================================
`default_nettype none

module sf_hb_alp_corrupt (
  input  wire logic clk,
  input  wire logic rst_n,
  input  wire logic req_valid,
  input  wire logic req_ready,
  input  sf_albion_pkg::sf_req_t req,
  input  wire logic fab_rsp_valid,
  output logic      fab_rsp_ready,
  input  sf_albion_pkg::sf_rsp_t fab_rsp,
  output logic      br_rsp_valid,
  input  wire logic br_rsp_ready,
  output sf_albion_pkg::sf_rsp_t br_rsp
);
  typedef struct { bit [63:0] addr; } r_t;
  r_t q [$];
  logic [63:0] head_addr_q;
  logic        head_valid_q;

  // rules (set by the test)
  bit        rule_on   [4];
  bit [63:0] rule_lo   [4];
  bit [63:0] rule_hi   [4];
  bit [3:0]  rule_status [4];
  int        rule_mode [4];
  int        n_mutated = 0;
  initial for (int i = 0; i < 4; i++) rule_on[i] = 1'b0;

  task automatic set_rule(input int i, input bit [63:0] lo, input bit [63:0] hi, input bit [3:0] status, input int mode);
    rule_lo[i] = lo; rule_hi[i] = hi; rule_status[i] = status; rule_mode[i] = mode; rule_on[i] = 1'b1;
  endtask
  task automatic clear_rules();
    for (int i = 0; i < 4; i++) rule_on[i] = 1'b0;
  endtask

  always @(posedge clk) begin
    r_t e;
    if (!rst_n) begin
      q.delete();
      head_valid_q <= 1'b0; head_addr_q <= '0;
    end else begin
      if (fab_rsp_valid && br_rsp_ready && q.size() > 0) q.pop_front();
      if (req_valid && req_ready) begin
        e.addr = req.addr;
        q.push_back(e);
      end
      head_valid_q <= (q.size() > 0);
      head_addr_q  <= (q.size() > 0) ? q[0].addr : 64'd0;
    end
  end

  always_comb begin
    br_rsp        = fab_rsp;
    br_rsp_valid  = fab_rsp_valid;
    fab_rsp_ready = br_rsp_ready;
    if (fab_rsp_valid && head_valid_q) begin
      for (int i = 0; i < 4; i++) begin
        if (rule_on[i] && head_addr_q >= rule_lo[i] && head_addr_q <= rule_hi[i]) begin
          case (rule_mode[i])
            0: begin
              br_rsp.status        = rule_status[i];
              br_rsp.data          = '0;
              br_rsp.meta.poisoned = (rule_status[i] == sf_albion_pkg::SF_ST_ECC_UNCORR);
            end
            1: br_rsp.tag = fab_rsp.tag ^ 8'h80;
            2: br_rsp.meta.is_write = !fab_rsp.meta.is_write;
            3: begin
              br_rsp.status = sf_albion_pkg::SF_ST_TARGET_ERR;
              br_rsp.data   = {fab_rsp.data[127:1], 1'b1};          // data must be zero for a non-OKAY status
            end
            default: ;
          endcase
        end
      end
    end
  end
endmodule

`default_nettype wire
