// =============================================================================
//  tb_hb_system.sv  --  the demonstration SoC end to end: MMIO + DomainGuard + DMA round trips
// -----------------------------------------------------------------------------
//  Everything the host does goes through the HTI channels, exactly as it would through a PCIe shim:
//    S0  register identification            S1  scratch register, byte lanes, mixed-rights word
//    S2  guard window programming through CSR registers, tenant isolation, defense in depth
//    S3  DMA host -> SRAM                   S4  DMA SRAM -> host, then the full round trip, with host traffic
//    S5  DMA faults: host error, alignment, SRAM-side error; error log registers
//    S6  cancel through the CONTROL register mid-DMA
//    S7  contention storm: host traffic + DMA, out-of-order host completions, back-pressure
//    S8  reset in the middle of a DMA: registers back to defaults, guard back to default-deny
// =============================================================================
`default_nettype none

module tb_hb_system;
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  logic cancel = 1'b0;
  always #5 clk = ~clk;

  hb_env_soc u_env (.clk, .rst_n, .cancel);

  localparam longint unsigned SRAMH = 64'h1000_0000;                 // host address of the SRAM window
  localparam longint unsigned SRAMD = 64'h0000_0001_1000_0000;       // device address of the SRAM
  localparam longint unsigned CSRD  = 64'h0000_0001_2000_0000;       // device address of the register block
  localparam bit [7:0] ROOT = 8'h00, MGMT = 8'h01, T1 = 8'h10, T2 = 8'h11, T3 = 8'h12, T4 = 8'h13;
  localparam int DENIED = 2, UR = 1, CA = 3, ABORTED = 7, BAD_REQ = 9;

  // ---- register helpers (host address of a register = its CSR offset) -------------------------------------------------
  int tg = 0;
  function automatic bit [7:0] ntag();
    tg = (tg + 1) % 250;
    return 8'(tg + 1);
  endfunction

  task automatic csr_wr(input longint unsigned off, input bit [31:0] val, input bit [7:0] dom, input int exp_st);
    u_env.u_host.post_wr_val(ntag(), off, 4, dom, 1'b0, exp_st, {96'h0, val});
    u_env.u_host.wait_req_idle(20000);
  endtask

  task automatic csr_rd_st(input longint unsigned off, input bit [7:0] dom, input int exp_st, output bit [31:0] val);
    bit [7:0] t;
    t = ntag();
    u_env.u_host.post_rd(t, off, 4, dom, exp_st, 1'b0);
    u_env.u_host.wait_req_idle(20000);
    val = u_env.u_host.last_cpl_data[int'(t)] >> (8 * off[3:0]);
  endtask

  function automatic bit [31:0] csr_rd(input longint unsigned off, input bit [7:0] dom);
    bit [31:0] v;
    csr_rd_st(off, dom, 0, v);
    return v;
  endfunction

  task automatic expect_reg(input string name, input longint unsigned off, input bit [7:0] dom, input bit [31:0] exp_v);
    bit [31:0] v;
    v = csr_rd(off, dom);
    tb_check(v == exp_v, $sformatf("%s (offset %h): read %h, expected %h", name, off, v, exp_v));
  endtask

  task automatic grd_prog(input int i, input longint unsigned base, input longint unsigned limit, input bit [7:0] wdom,
                          input bit rd, input bit wr, input bit v, input bit [7:0] by);
    longint unsigned r;
    r = 64'h100 + i * 32;
    csr_wr(r + 0,  base[31:0],  by, 0);
    csr_wr(r + 4,  base[63:32], by, 0);
    csr_wr(r + 8,  limit[31:0], by, 0);
    csr_wr(r + 12, limit[63:32], by, 0);
    csr_wr(r + 16, {16'h0, wdom, 5'h0, wr, rd, v}, by, 0);
  endtask

  //  Run one DMA transfer through the registers and wait for done; returns the DMA_STATUS value.
  task automatic dma_run(input longint unsigned src, input longint unsigned dst, input bit [31:0] len, input bit dir,
                         input bit posted, output bit [31:0] st);
    int polls;
    csr_wr(64'h040, src[31:0],  ROOT, 0);
    csr_wr(64'h044, src[63:32], ROOT, 0);
    csr_wr(64'h048, dst[31:0],  ROOT, 0);
    csr_wr(64'h04C, dst[63:32], ROOT, 0);
    csr_wr(64'h050, len,        ROOT, 0);
    csr_wr(64'h054, {29'h0, posted, dir, 1'b1}, ROOT, 0);          // start
    polls = 0;
    st = 32'h0;
    while (!st[1] && polls < 4000) begin
      repeat (12) @(negedge clk);
      st = csr_rd(64'h058, ROOT);
      polls++;
    end
    tb_check(st[1], "DMA did not finish (timeout)");
  endtask

  task automatic sram_read_root(input longint unsigned off, input int len);
    u_env.u_host.post_rd(ntag(), SRAMH + off, len, ROOT, 0, 1'b1);
  endtask

  initial begin
    bit [31:0] v, st, c0, c1;
    tb_seed(32'd96);
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (1100) @(negedge clk);                 // the SRAM clears itself after reset

    // ---- S0: identification
    expect_reg("ID",      64'h000, ROOT, 32'h4842_0096);
    expect_reg("VERSION", 64'h004, ROOT, 32'h0000_0100);
    expect_reg("CAPS",    64'h008, ROOT, 32'h0808_8000);
    csr_rd_st(64'h000, T1, DENIED, v);            // a tenant has no guard window: the guard denies, the register is not reached
    csr_rd_st(64'h000, MGMT, DENIED, v);          // MGMT has no window yet either (only ROOT bypasses)
    $display("S0 identification, default deny: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- S1: scratch register, byte lanes, rights of a mixed word
    csr_wr(64'h00C, 32'hDEAD_BEEF, ROOT, 0);
    expect_reg("SCRATCH", 64'h00C, ROOT, 32'hDEAD_BEEF);
    u_env.u_host.post_wr_val(ntag(), 64'h00D, 1, ROOT, 1'b0, 0, 128'h55);           // one byte lane
    u_env.u_host.wait_req_idle(20000);
    expect_reg("SCRATCH after byte write", 64'h00C, ROOT, 32'hDEAD_55EF);
    u_env.u_host.post_wr_val(ntag(), 64'h000, 16, ROOT, 1'b0, DENIED, {32'hAAAA_AAAA, 32'hBBBB_BBBB, 32'hCCCC_CCCC, 32'hDDDD_DDDD});
    u_env.u_host.wait_req_idle(20000);                                               // ID/VERSION/CAPS are read-only: whole word denied
    expect_reg("SCRATCH unchanged by a denied word", 64'h00C, ROOT, 32'hDEAD_55EF);
    begin
      bit [7:0] t;
      t = ntag();
      u_env.u_host.post_rd(t, 64'h00C, 4, ROOT, 0, 1'b0);
      u_env.u_host.wait_req_idle(20000);
      // register 0x00C is lane 12..15 of its word: every other lane of the completion beat must be zero
      tb_check((u_env.u_host.last_cpl_data[int'(t)] & ((128'h1 << 96) - 128'h1)) == 128'h0,
               "S1: lanes outside the 4-byte read must be zero");
    end
    csr_rd_st(64'h200, ROOT, UR, v);                                                 // offset beyond the register space
    $display("S1 scratch / lanes / rights: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- S2: guard window programming through the registers; isolation; defense in depth
    grd_prog(0, SRAMD + 64'h000, SRAMD + 64'h7FF, T1,   1'b1, 1'b1, 1'b1, ROOT);    // tenant 0x10: first 2 KiB of SRAM
    grd_prog(1, SRAMD + 64'h800, SRAMD + 64'hBFF, T2,   1'b1, 1'b0, 1'b1, ROOT);    // tenant 0x11: read-only
    grd_prog(2, CSRD  + 64'h000, CSRD  + 64'h1FF, MGMT, 1'b1, 1'b1, 1'b1, ROOT);    // MGMT: the register block
    grd_prog(3, CSRD  + 64'h000, CSRD  + 64'h1FF, T3,   1'b1, 1'b1, 1'b1, ROOT);    // tenant 0x12: ALSO the register block (misconfigured)
    expect_reg("window 0 BASE_LO", 64'h100, ROOT, 32'h1000_0000);
    expect_reg("window 0 BASE_HI", 64'h104, ROOT, 32'h0000_0001);
    expect_reg("window 0 LIMIT_LO", 64'h108, ROOT, 32'h1000_07FF);
    expect_reg("window 0 ATTR", 64'h110, ROOT, 32'h0000_1007);
    //  tenant isolation on SRAM
    u_env.u_host.post_wr(ntag(), SRAMH + 64'h10, 100, T1, 1'b0, 0, 1'b1, 0);
    u_env.u_host.post_rd(ntag(), SRAMH + 64'h10, 100, T1, 0, 1'b1);
    u_env.u_host.post_rd(ntag(), SRAMH + 64'h10, 100, T2, DENIED, 1'b1);              // another tenant's memory
    u_env.u_host.post_rd(ntag(), SRAMH + 64'h810, 100, T2, 0, 1'b1);                  // its own window, read
    u_env.u_host.post_wr(ntag(), SRAMH + 64'h810, 16, T2, 1'b0, DENIED, 1'b1, 0);     // read-only window
    u_env.u_host.post_rd(ntag(), SRAMH + 64'h1000, 16, T1, DENIED, 1'b1);             // outside every window
    u_env.u_host.wait_req_idle(50000);
    //  the register block: tenant 0x10 has no window, MGMT has one
    csr_rd_st(64'h000, T1, DENIED, v);
    expect_reg("MGMT reads ID", 64'h000, MGMT, 32'h4842_0096);
    csr_wr(64'h00C, 32'h1234_5678, MGMT, 0);
    expect_reg("MGMT wrote SCRATCH", 64'h00C, MGMT, 32'h1234_5678);
    //  defense in depth: tenant 0x12 reaches the block through its (misconfigured) window, the CSR still protects privileged registers
    expect_reg("T3 reads ID (read-only register)", 64'h000, T3, 32'h4842_0096);
    csr_wr(64'h00C, 32'hCAFE_0001, T3, 0);                                            // scratch is not privileged
    expect_reg("T3 wrote SCRATCH", 64'h00C, T3, 32'hCAFE_0001);
    csr_wr(64'h050, 32'h40, T3, DENIED);                                              // DMA_LEN: privileged
    csr_wr(64'h010, 32'h1, T3, DENIED);                                               // CONTROL: privileged (cancel)
    csr_rd_st(64'h110, T3, DENIED, v);                                                // reading the policy: privileged
    csr_wr(64'h100 + 4 * 32 + 16, 32'h0000_1307, T3, DENIED);                          // a tenant cannot grant itself anything
    //  MGMT may program a window (management plane), the new tenant then works
    grd_prog(4, SRAMD + 64'h1000, SRAMD + 64'h13FF, T4, 1'b1, 1'b1, 1'b1, MGMT);
    u_env.u_host.post_wr(ntag(), SRAMH + 64'h1000, 64, T4, 1'b0, 0, 1'b1, 0);
    u_env.u_host.post_rd(ntag(), SRAMH + 64'h1000, 64, T4, 0, 1'b1);
    u_env.u_host.wait_req_idle(50000);
    tb_check(u_env.deny_count > 0, "S2: the guard's deny counter did not move");
    $display("S2 guard windows through registers, isolation, defense in depth: checks=%0d errors=%0d deny_count=%0d",
             tb_checks, tb_errors, u_env.deny_count);

    // ---- S3: DMA host -> SRAM
    csr_wr(64'h010, 32'h2, ROOT, 0);                                                  // clear the error log
    for (int i = 0; i < 1024; i++) u_env.u_host.dref[SRAMH + 64'h100 + i] = hb_pat(64'h4000_1000 + i);
    dma_run(64'h4000_1000, SRAMD + 64'h100, 32'd1024, 1'b0, 1'b0, st);
    tb_check(st == 32'h0000_0002, $sformatf("S3: DMA_STATUS %h, expected 00000002", st));
    expect_reg("S3 bytes", 64'h05C, ROOT, 32'd1024);
    sram_read_root(64'h100, 1024);
    u_env.u_host.wait_req_idle(100000);
    $display("S3 DMA host->SRAM: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- S4: DMA SRAM -> host, then the full round trip, with host traffic running alongside
    u_env.u_host.post_wr(ntag(), SRAMH + 64'h500, 512, ROOT, 1'b0, 0, 1'b1, 0);      // random data written by the host
    u_env.u_host.wait_req_idle(50000);
    dma_run(SRAMD + 64'h500, 64'h5000_0000, 32'd512, 1'b1, 1'b0, st);                 // D2H, non-posted
    tb_check(st == 32'h0000_0002, $sformatf("S4: D2H DMA_STATUS %h", st));
    begin
      bit ok;
      ok = 1'b1;
      for (int i = 0; i < 512; i++) if (u_env.u_host.hm_peek(64'h5000_0000 + i) != u_env.u_host.dref_peek(SRAMH + 64'h500 + i)) ok = 1'b0;
      tb_check(ok, "S4: host memory does not hold the SRAM data after the D2H DMA");
    end
    // round trip: host memory -> a different SRAM area (0x1800, outside every tenant window, read as ROOT)
    for (int i = 0; i < 512; i++) u_env.u_host.dref[SRAMH + 64'h1800 + i] = u_env.u_host.dref_peek(SRAMH + 64'h500 + i);
    // host traffic on another area while the DMA runs
    for (int i = 0; i < 40; i++) begin
      if (tb_pct(50)) u_env.u_host.post_wr(ntag(), SRAMH + 64'h2000 + tb_below(1000), tb_range(1, 100), ROOT, tb_pct(20), 0, 1'b1, 0);
      else            u_env.u_host.post_rd(ntag(), SRAMH + 64'h2000 + tb_below(1000), tb_range(1, 100), ROOT, 0, 1'b1);
    end
    dma_run(64'h5000_0000, SRAMD + 64'h1800, 32'd512, 1'b0, 1'b0, st);
    tb_check(st == 32'h0000_0002, $sformatf("S4: round-trip H2D DMA_STATUS %h", st));
    u_env.u_host.wait_req_idle(50000);
    sram_read_root(64'h1800, 512);
    // posted D2H: the engine finishes when the host side has the data
    dma_run(SRAMD + 64'h1800, 64'h5100_0000, 32'd512, 1'b1, 1'b1, st);
    tb_check(st == 32'h0000_0002, $sformatf("S4: posted D2H DMA_STATUS %h", st));
    u_env.u_host.wait_req_idle(50000);
    repeat (40) @(negedge clk);
    begin
      bit ok;
      ok = 1'b1;
      for (int i = 0; i < 512; i++) if (u_env.u_host.hm_peek(64'h5100_0000 + i) != u_env.u_host.dref_peek(SRAMH + 64'h1800 + i)) ok = 1'b0;
      tb_check(ok, "S4: host memory after the posted D2H DMA differs from the SRAM");
    end
    expect_reg("S4 error log stays empty during normal DMA", 64'h020, ROOT, 32'h0);
    $display("S4 DMA round trips: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- S5: DMA faults and the error log
    csr_wr(64'h010, 32'h2, ROOT, 0);                                                  // clear the log
    expect_reg("ERR_COUNT cleared", 64'h020, ROOT, 32'h0);
    //  (a) the host answers UR to the source read
    u_env.u_host.set_error_window(0, 64'h6000_0000, 64'h6000_FFFF, 4'd1, 1'b1, 1'b0, 0, 1'b0);
    dma_run(64'h6000_0000, SRAMD + 64'h100, 32'd256, 1'b0, 1'b0, st);
    tb_check(st == 32'h0000_0012, $sformatf("S5a: DMA_STATUS %h, expected 00000012 (UR)", st));
    expect_reg("S5a bytes of a failed transfer", 64'h05C, ROOT, 32'h0);
    expect_reg("ERR_COUNT after one failure", 64'h020, ROOT, 32'h1);
    expect_reg("ERR_INFO (src=DMA, code=UR, id=1)", 64'h024, ROOT, {18'h0, 2'd1, 4'd1, 8'd1});
    expect_reg("ERR_ADDR_LO", 64'h028, ROOT, 32'h6000_0000);
    //  (b) a length that is not a multiple of 16: rejected by the engine at once
    dma_run(64'h4000_0000, SRAMD + 64'h100, 32'd17, 1'b0, 1'b0, st);
    tb_check(st == 32'h0000_0092, $sformatf("S5b: DMA_STATUS %h, expected 00000092 (BAD_REQ)", st));
    //  (c) the SRAM side fails: destination beyond the backed memory -> DECODE_ERR -> UR
    u_env.u_host.clear_error_windows();
    dma_run(64'h4000_2000, SRAMD + 64'h4000, 32'd64, 1'b0, 1'b0, st);
    tb_check(st == 32'h0000_0012, $sformatf("S5c: DMA_STATUS %h, expected 00000012 (UR from the SRAM side)", st));
    //  (d) the host rejects the DMA write (non-posted acknowledgement with CA)
    u_env.u_host.set_error_window(0, 64'h7000_0000, 64'h7000_FFFF, 4'd3, 1'b0, 1'b1, 0, 1'b0);
    dma_run(SRAMD + 64'h100, 64'h7000_0000, 32'd128, 1'b1, 1'b0, st);
    tb_check(st == 32'h0000_0032, $sformatf("S5d: DMA_STATUS %h, expected 00000032 (CA)", st));
    u_env.u_host.clear_error_windows();
    //  (e) the engine tries to write into the privileged register window: the fabric's region access check denies it
    dma_run(64'h4000_8000, CSRD + 64'h10, 32'd64, 1'b0, 1'b0, st);
    tb_check(st == 32'h0000_0022, $sformatf("S5e: DMA_STATUS %h, expected 00000022 (DENIED by the region check)", st));
    expect_reg("S5e SCRATCH unchanged", 64'h00C, ROOT, 32'hCAFE_0001);
    //  (f) the engine READS a register that needs no privilege: only the fabric's region check (privileged window)
    //      stands between it and the data
    dma_run(CSRD + 64'h0, 64'h7100_0000, 32'd64, 1'b1, 1'b0, st);
    tb_check(st == 32'h0000_0022, $sformatf("S5f: DMA_STATUS %h, expected 00000022 (read denied by the region check)", st));
    //  after every failure the engine and the bridge are healthy
    dma_run(64'h4000_3000, SRAMD + 64'h200, 32'd256, 1'b0, 1'b0, st);
    tb_check(st == 32'h0000_0002, $sformatf("S5: DMA after faults: %h", st));
    tb_check(u_env.u_soc.u_bridge.dma_outstanding_o == 0, "S5: DMA tags still busy");
    $display("S5 DMA faults and error log: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- S6: cancel through the CONTROL register in the middle of a DMA
    u_env.u_host.cfg_lat_min = 700; u_env.u_host.cfg_lat_max = 700;
    csr_wr(64'h040, 32'h4000_4000, ROOT, 0); csr_wr(64'h044, 32'h0, ROOT, 0);
    csr_wr(64'h048, SRAMD[31:0] + 32'h300, ROOT, 0); csr_wr(64'h04C, SRAMD[63:32], ROOT, 0);
    csr_wr(64'h050, 32'd2048, ROOT, 0);
    csr_wr(64'h054, 32'h1, ROOT, 0);
    repeat (80) @(negedge clk);
    expect_reg("S6 DMA busy before cancel", 64'h058, ROOT, 32'h1);
    csr_wr(64'h010, 32'h1, ROOT, 0);                                                  // cancel
    st = 32'h0;
    for (int i = 0; i < 600 && !st[1]; i++) begin repeat (10) @(negedge clk); st = csr_rd(64'h058, ROOT); end
    tb_check(st == 32'h0000_0072, $sformatf("S6: DMA_STATUS %h, expected 00000072 (ABORTED)", st));
    u_env.u_host.cfg_lat_min = 2; u_env.u_host.cfg_lat_max = 6;
    repeat (900) @(negedge clk);                                                       // the slow host answers; late completions are dropped
    expect_reg("S6 unexpected completions", 64'h030, ROOT, 32'h0);
    dma_run(64'h4000_5000, SRAMD + 64'h300, 32'd256, 1'b0, 1'b0, st);
    tb_check(st == 32'h0000_0002, $sformatf("S6: DMA after cancel: %h", st));
    $display("S6 cancel via register: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- S7: contention storm: host traffic + DMA, out-of-order host completions, back-pressure
    u_env.u_host.cfg_ooo_pct = 100; u_env.u_host.cfg_lat_min = 2; u_env.u_host.cfg_lat_max = 60;
    u_env.u_host.cfg_dreq_rdy = 50; u_env.u_host.cfg_dw_rdy = 50; u_env.u_host.cfg_cpl_rdy = 60;
    u_env.u_host.cfg_req_gap = 20; u_env.u_host.cfg_hw_gap = 20;
    for (int round = 0; round < 6; round++) begin
      for (int i = 0; i < 40; i++) begin
        longint unsigned off;
        off = 64'h2000 + tb_below(2000);            // the DMA keeps to 0x300.. and 0x1800; host traffic uses 0x2000..
        if (tb_pct(50)) u_env.u_host.post_wr(ntag(), SRAMH + off, tb_range(1, 150), ROOT, tb_pct(20), 0, 1'b1, tb_below(2));
        else            u_env.u_host.post_rd(ntag(), SRAMH + off, tb_range(1, 150), ROOT, 0, 1'b1);
      end
      for (int i = 0; i < 1024; i++) u_env.u_host.dref[SRAMH + 64'h300 + i] = hb_pat(64'h4100_0000 + round * 4096 + i);
      dma_run(64'h4100_0000 + round * 4096, SRAMD + 64'h300, 32'd1024, 1'b0, 1'b0, st);
      tb_check(st == 32'h0000_0002, $sformatf("S7: H2D status %h", st));
      u_env.u_host.wait_req_idle(100000);
      sram_read_root(64'h300, 1024);
      dma_run(SRAMD + 64'h300, 64'h5200_0000 + round * 4096, 32'd1024, 1'b1, tb_pct(50), st);
      tb_check(st == 32'h0000_0002, $sformatf("S7: D2H status %h", st));
      u_env.u_host.wait_req_idle(100000);
      repeat (40) @(negedge clk);
      begin
        bit ok;
        ok = 1'b1;
        for (int i = 0; i < 1024; i++) if (u_env.u_host.hm_peek(64'h5200_0000 + round * 4096 + i) != hb_pat(64'h4100_0000 + round * 4096 + i)) ok = 1'b0;
        tb_check(ok, $sformatf("S7 round %0d: host memory after H2D+D2H differs from the source", round));
      end
    end
    u_env.u_host.cfg_ooo_pct = 0; u_env.u_host.cfg_lat_min = 2; u_env.u_host.cfg_lat_max = 6;
    u_env.u_host.cfg_dreq_rdy = 100; u_env.u_host.cfg_dw_rdy = 100; u_env.u_host.cfg_cpl_rdy = 100;
    u_env.u_host.cfg_req_gap = 0; u_env.u_host.cfg_hw_gap = 0;
    tb_check(u_env.max_merged > 4, $sformatf("S7: the arbiter never carried concurrent traffic (max %0d)", u_env.max_merged));
    $display("S7 contention storm: checks=%0d errors=%0d (max merged outstanding %0d)", tb_checks, tb_errors, u_env.max_merged);

    // ---- S8: reset in the middle of a DMA: registers and the guard are back to their defaults
    csr_wr(64'h040, 32'h4000_6000, ROOT, 0); csr_wr(64'h044, 32'h0, ROOT, 0);
    csr_wr(64'h048, SRAMD[31:0] + 32'h300, ROOT, 0); csr_wr(64'h04C, SRAMD[63:32], ROOT, 0);
    csr_wr(64'h050, 32'd4096, ROOT, 0);
    csr_wr(64'h054, 32'h1, ROOT, 0);
    u_env.u_host.post_wr(ntag(), SRAMH + 64'h2000, 200, ROOT, 1'b0, 0, 1'b0, 0);
    repeat (60) @(negedge clk);
    tb_check(u_env.u_soc.u_engine.busy_o, "S8: the engine should be busy when reset hits");
    #3 rst_n = 1'b0;
    repeat (3) @(negedge clk);
    u_env.u_host.reset_model();
    @(negedge clk);
    rst_n <= 1'b1;
    repeat (1100) @(negedge clk);
    expect_reg("S8 SCRATCH after reset", 64'h00C, ROOT, 32'h0);
    expect_reg("S8 DMA_STATUS after reset", 64'h058, ROOT, 32'h0);
    expect_reg("S8 ERR_COUNT after reset", 64'h020, ROOT, 32'h0);
    csr_rd_st(64'h000, MGMT, DENIED, v);                                               // the guard is back to default-deny
    u_env.u_host.post_rd(ntag(), SRAMH + 64'h10, 16, T1, DENIED, 1'b1);
    u_env.u_host.wait_req_idle(20000);
    dma_run(64'h4000_7000, SRAMD + 64'h100, 32'd128, 1'b0, 1'b0, st);
    tb_check(st == 32'h0000_0002, $sformatf("S8: DMA after reset: %h", st));
    $display("S8 reset: checks=%0d errors=%0d", tb_checks, tb_errors);

    tb_check(!u_env.fatal, "fatal latched");
    repeat (20) @(negedge clk);
    tb_report("tb_hb_system");
    $finish;
  end

  initial begin
    #1500000000;
    tb_fail("system: global timeout");
    tb_report("tb_hb_system");
    $finish;
  end
endmodule

`default_nettype wire
