// =============================================================================
//  hb_env_sram.sv  --  stage-1 verification environment (testbench only)
// -----------------------------------------------------------------------------
//  The SRAM-backed demonstration: sf_albion_host_bridge wired to the AlbionCore reference subsystem
//  (sf_albion_ref_subsystem: one SRAM region + error responder, order queue, ALP v1 decode) with
//
//    * the AlbionCore ALP link checker bound to the bridge's fabric link (ALP-REQ/RSP/TAG/ORD/OUT/RST),
//    * the host bus-functional model on all four HTI channels,
//    * an error-event logger,
//    * an optional DomainGuard (sf_albion_host_domain_guard, programmed through guard_* ports).
//
//  Memory map seen by the host (defaults of the bridge): host 0x0000_0000 + 1 MiB -> device CSR
//  window (NOT backed in this environment: the fabric answers DECODE_ERR), host 0x1000_0000 + 16 KiB
//  -> device SRAM at 0x1_1000_0000.
// =============================================================================
`default_nettype none

module hb_env_sram #(
  parameter int unsigned MAX_OUT       = 8,
  parameter int unsigned REQ_Q_DEPTH   = 4,
  parameter int unsigned WDATA_Q_DEPTH = 16,
  parameter int unsigned NUM_TAGS      = 8,
  parameter int unsigned MPS_BYTES     = 256,
  parameter int unsigned MRRS_BYTES    = 256,
  parameter int unsigned CPL_TIMEOUT   = 0,
  parameter bit          GUARD_EN      = 1'b0,
  parameter int unsigned MEM_EXTRA_LAT = 2,
  parameter int unsigned MEM_RSP_DEPTH = 2,
  parameter logic [7:0]  SRAM_ATTR     = 8'h27,       // region attribute of the fabric SRAM
  parameter logic [3:0]  AP_PERM       = 4'b1111,     // aperture rights {ap1 write, ap1 read, ap0 write, ap0 read}
  parameter int unsigned BOUNDARY_LOG2 = 12,
  parameter int unsigned MAX_REQ_BYTES = 4096,
  parameter logic [63:0] AP1_SIZE      = 64'h4000,    // host SRAM aperture size in bytes
  parameter int unsigned GUARD_LAT_MAX = 0,           // DomainGuard verdict latency 0..GUARD_LAT_MAX cycles (0 = combinational)
  parameter bit          ALLOW_FATAL   = 1'b0         // 1: a latched fatal link error is expected by the test
) (
  input  wire logic clk,
  input  wire logic rst_n,
  input  wire logic cancel,
  input  wire logic evt_ready_en,           // 0: stall the event consumer
  // guard programming (only used when GUARD_EN = 1)
  input  wire logic         grd_cfg_we,
  input  wire logic [2:0]   grd_cfg_idx,
  input  wire logic [63:0]  grd_cfg_base,
  input  wire logic [63:0]  grd_cfg_limit,
  input  wire logic [7:0]   grd_cfg_dom,
  input  wire logic         grd_cfg_rd,
  input  wire logic         grd_cfg_wr,
  input  wire logic         grd_cfg_valid
);
  import sf_hb_tb_pkg::*;

  // ---- HTI wires -----------------------------------------------------------------------------
  logic        hreq_valid, hreq_ready, hw_valid, hw_ready, hw_last;
  logic [1:0]  hreq_kind;
  logic [63:0] hreq_addr;
  logic [12:0] hreq_len;
  logic [7:0]  hreq_tag, hreq_dom;
  logic [127:0] hw_data;
  logic [15:0]  hw_be;
  logic        hcpl_valid, hcpl_ready, hcpl_last;
  logic [7:0]  hcpl_tag;
  logic [3:0]  hcpl_status;
  logic [127:0] hcpl_data;
  logic        dreq_valid, dreq_ready, dw_valid, dw_ready, dw_last;
  logic [1:0]  dreq_kind;
  logic [63:0] dreq_addr;
  logic [12:0] dreq_len;
  logic [7:0]  dreq_tag;
  logic [127:0] dw_data;
  logic [15:0]  dw_be;
  logic        dcpl_valid, dcpl_ready, dcpl_last;
  logic [7:0]  dcpl_tag;
  logic [3:0]  dcpl_status;
  logic [127:0] dcpl_data;
  // ---- DMA client (driven by the testbench through u_dma) ----------------------------------------
  logic        dma_req_valid, dma_req_ready, dma_req_write, dma_req_posted;
  logic [63:0] dma_req_addr;
  logic [23:0] dma_req_len;
  logic [7:0]  dma_req_id;
  logic        dma_w_valid, dma_w_ready, dma_w_last;
  logic [127:0] dma_w_data;
  logic [15:0]  dma_w_be;
  logic        dma_r_valid, dma_r_ready, dma_r_is_write, dma_r_last;
  logic [7:0]  dma_r_id;
  logic [3:0]  dma_r_status;
  logic [127:0] dma_r_data;
  logic [15:0]  dma_r_be;
  // ---- ALP link ---------------------------------------------------------------------------------------
  logic        m_req_valid, m_req_ready, m_rsp_valid, m_rsp_ready;
  logic        fab_rsp_valid, fab_rsp_ready;
  sf_albion_pkg::sf_req_t m_req;
  sf_albion_pkg::sf_rsp_t m_rsp, fab_rsp;
  // ---- guard ---------------------------------------------------------------------------------------------
  logic        grd_req_valid, grd_rsp_valid, grd_permit;
  logic [7:0]  grd_dom, grd_attr;
  logic [3:0]  grd_op, grd_status;
  logic [63:0] grd_addr;
  logic [31:0] grd_len;
  // ---- events / status --------------------------------------------------------------------------------------
  logic        err_valid, err_ready;
  logic [1:0]  err_src;
  logic [3:0]  err_code;
  logic [7:0]  err_tag;
  logic [63:0] err_addr;
  logic        host_busy, dma_busy, fatal;
  logic [$clog2(MAX_OUT+1)-1:0]  host_out;
  logic [$clog2(NUM_TAGS+1)-1:0] dma_out;
  logic [15:0] unexpected_cpl;

  logic cancel_d;
  assign cancel_d = cancel;

  sf_albion_host_bridge #(
    .REQ_Q_DEPTH(REQ_Q_DEPTH), .WDATA_Q_DEPTH(WDATA_Q_DEPTH), .MAX_OUT(MAX_OUT), .GUARD_EN(GUARD_EN),
    .AP_PERM(AP_PERM), .AP_SIZE({AP1_SIZE, 64'h0000_0000_0010_0000}), .BOUNDARY_LOG2(BOUNDARY_LOG2), .MAX_REQ_BYTES(MAX_REQ_BYTES),
    .NUM_TAGS(NUM_TAGS), .MPS_BYTES(MPS_BYTES), .MRRS_BYTES(MRRS_BYTES), .CPL_TIMEOUT(CPL_TIMEOUT),
    .CK_Q_DEPTH(NUM_TAGS + 4)
  ) u_dut (
    .clk_i(clk), .rst_ni(rst_n), .cancel_i(cancel_d),
    .hreq_valid_i(hreq_valid), .hreq_ready_o(hreq_ready), .hreq_kind_i(hreq_kind), .hreq_addr_i(hreq_addr),
    .hreq_len_i(hreq_len), .hreq_tag_i(hreq_tag), .hreq_dom_i(hreq_dom),
    .hw_valid_i(hw_valid), .hw_ready_o(hw_ready), .hw_data_i(hw_data), .hw_be_i(hw_be), .hw_last_i(hw_last),
    .hcpl_valid_o(hcpl_valid), .hcpl_ready_i(hcpl_ready), .hcpl_tag_o(hcpl_tag), .hcpl_status_o(hcpl_status),
    .hcpl_data_o(hcpl_data), .hcpl_last_o(hcpl_last),
    .m_req_valid_o(m_req_valid), .m_req_ready_i(m_req_ready), .m_req_o(m_req),
    .m_rsp_valid_i(m_rsp_valid), .m_rsp_ready_o(m_rsp_ready), .m_rsp_i(m_rsp),
    .grd_req_valid_o(grd_req_valid), .grd_dom_o(grd_dom), .grd_op_o(grd_op), .grd_attr_o(grd_attr),
    .grd_addr_o(grd_addr), .grd_len_o(grd_len),
    .grd_rsp_valid_i(grd_rsp_valid), .grd_permit_i(grd_permit), .grd_status_i(grd_status),
    .dma_req_valid_i(dma_req_valid), .dma_req_ready_o(dma_req_ready), .dma_req_write_i(dma_req_write),
    .dma_req_posted_i(dma_req_posted), .dma_req_addr_i(dma_req_addr), .dma_req_len_i(dma_req_len),
    .dma_req_id_i(dma_req_id),
    .dma_w_valid_i(dma_w_valid), .dma_w_ready_o(dma_w_ready), .dma_w_data_i(dma_w_data), .dma_w_be_i(dma_w_be),
    .dma_w_last_i(dma_w_last),
    .dma_r_valid_o(dma_r_valid), .dma_r_ready_i(dma_r_ready), .dma_r_id_o(dma_r_id), .dma_r_status_o(dma_r_status),
    .dma_r_is_write_o(dma_r_is_write), .dma_r_data_o(dma_r_data), .dma_r_be_o(dma_r_be), .dma_r_last_o(dma_r_last),
    .dreq_valid_o(dreq_valid), .dreq_ready_i(dreq_ready), .dreq_kind_o(dreq_kind), .dreq_addr_o(dreq_addr),
    .dreq_len_o(dreq_len), .dreq_tag_o(dreq_tag),
    .dw_valid_o(dw_valid), .dw_ready_i(dw_ready), .dw_data_o(dw_data), .dw_be_o(dw_be), .dw_last_o(dw_last),
    .dcpl_valid_i(dcpl_valid), .dcpl_ready_o(dcpl_ready), .dcpl_tag_i(dcpl_tag), .dcpl_status_i(dcpl_status),
    .dcpl_data_i(dcpl_data), .dcpl_last_i(dcpl_last),
    .err_evt_valid_o(err_valid), .err_evt_ready_i(err_ready), .err_evt_src_o(err_src), .err_evt_code_o(err_code),
    .err_evt_tag_o(err_tag), .err_evt_addr_o(err_addr),
    .host_busy_o(host_busy), .dma_busy_o(dma_busy), .host_outstanding_o(host_out), .dma_outstanding_o(dma_out),
    .unexpected_cpl_o(unexpected_cpl), .fatal_o(fatal)
  );

  // ---- fabric: the AlbionCore reference subsystem (SRAM region + error responder) -------------------------------
  sf_albion_ref_subsystem #(
    .MAX_OUT(MAX_OUT), .REGION_BASE(64'h0000_0001_1000_0000), .REGION_BYTES(16384),
    .REGION_ATTR(SRAM_ATTR), .MEM_WORDS(1024), .MEM_RSP_DEPTH(MEM_RSP_DEPTH), .MEM_EXTRA_LAT(MEM_EXTRA_LAT),
    .ERR_RSP_DEPTH(2)
  ) u_fab (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(m_req_valid), .req_ready_o(m_req_ready), .req_i(m_req),
    .rsp_valid_o(fab_rsp_valid), .rsp_ready_i(fab_rsp_ready), .rsp_o(fab_rsp)
  );

  // ---- response fault injector (a wire unless the test sets a rule) ----------------------------------------------
  sf_hb_alp_corrupt u_corrupt (
    .clk, .rst_n,
    .req_valid(m_req_valid), .req_ready(m_req_ready), .req(m_req),
    .fab_rsp_valid, .fab_rsp_ready, .fab_rsp,
    .br_rsp_valid(m_rsp_valid), .br_rsp_ready(m_rsp_ready), .br_rsp(m_rsp)
  );

  // ---- ALP protocol monitor on the bridge's fabric link -------------------------------------------------------------
  logic [15:0] alp_outstanding;
  sf_albion_link_checker #(.MAX_OUTSTANDING(MAX_OUT)) u_alp_chk (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(m_req_valid), .req_ready_i(m_req_ready), .req_i(m_req),
    .rsp_valid_i(fab_rsp_valid), .rsp_ready_i(fab_rsp_ready), .rsp_i(fab_rsp),
    .waive_req_i(1'b0), .outstanding_o(alp_outstanding)
  );

  // ---- host model ----------------------------------------------------------------------------------------------------------
  sf_hti_host_bfm #(.NUM_TAGS_MAX(NUM_TAGS), .MPS(MPS_BYTES), .MRRS(MRRS_BYTES)) u_host (
    .clk, .rst_n, .cancel_i(cancel),
    .hreq_valid, .hreq_ready, .hreq_kind, .hreq_addr, .hreq_len, .hreq_tag, .hreq_dom,
    .hw_valid, .hw_ready, .hw_data, .hw_be, .hw_last,
    .hcpl_valid, .hcpl_ready, .hcpl_tag, .hcpl_status, .hcpl_data, .hcpl_last,
    .dreq_valid, .dreq_ready, .dreq_kind, .dreq_addr, .dreq_len, .dreq_tag,
    .dw_valid, .dw_ready, .dw_data, .dw_be, .dw_last,
    .dcpl_valid, .dcpl_ready, .dcpl_tag, .dcpl_status, .dcpl_data, .dcpl_last
  );

  // ---- DomainGuard ---------------------------------------------------------------------------------------------------------------
  typedef struct { bit [7:0] dom; bit [3:0] op; bit [7:0] attr; bit [63:0] addr; bit [31:0] len; bit permit; bit [3:0] status; } grd_t;
  grd_t grd_log [$];
  if (GUARD_EN) begin : gen_guard
    logic        g_rsp_valid, g_permit;
    logic [3:0]  g_status;
    sf_albion_host_domain_guard #(.NUM_WIN(8)) u_guard (
      .clk_i(clk), .rst_ni(rst_n),
      .cfg_we_i(grd_cfg_we), .cfg_idx_i(grd_cfg_idx), .cfg_base_i(grd_cfg_base), .cfg_limit_i(grd_cfg_limit),
      .cfg_dom_i(grd_cfg_dom), .cfg_rd_i(grd_cfg_rd), .cfg_wr_i(grd_cfg_wr), .cfg_valid_i(grd_cfg_valid),
      .chk_valid_i(grd_req_valid), .chk_dom_i(grd_dom), .chk_op_i(grd_op), .chk_attr_i(grd_attr),
      .chk_addr_i(grd_addr), .chk_len_i(grd_len),
      .chk_rsp_valid_o(g_rsp_valid), .chk_permit_o(g_permit), .chk_status_o(g_status),
      .deny_count_o()
    );
    // verdict latency: the verdict is delayed by a random number of cycles; the bridge must hold its fields
    logic        pend_q;
    logic [7:0]  cnt_q, lat_q;
    always @(posedge clk) begin
      if (!rst_n) begin
        pend_q <= 1'b0; cnt_q <= 8'd0; lat_q <= 8'd0;
      end else if (grd_req_valid && !pend_q) begin
        pend_q <= 1'b1; cnt_q <= 8'd0; lat_q <= 8'(tb_below(GUARD_LAT_MAX + 1));
      end else if (!grd_req_valid) begin
        pend_q <= 1'b0;
      end else if (cnt_q < lat_q) begin
        cnt_q <= cnt_q + 8'd1;
      end
    end
    if (GUARD_LAT_MAX == 0) begin : gen_comb
      assign grd_rsp_valid = g_rsp_valid;
    end else begin : gen_lat
      assign grd_rsp_valid = grd_req_valid && pend_q && (cnt_q >= lat_q);
    end
    //  test hook: replace the verdict by a denial carrying an arbitrary ALP status (checks the bridge's status mapping)
    bit        force_deny = 1'b0;
    bit [3:0]  force_status = 4'h0;
    assign grd_permit = force_deny ? 1'b0 : g_permit;
    assign grd_status = force_deny ? force_status : g_status;
    // what the guard was shown must be stable while it is evaluating, and is logged once per request
    bit            gprev_v = 1'b0;
    bit [127:0]    gprev;
    always @(posedge clk) begin
      grd_t e;
      if (!rst_n) begin
        gprev_v = 1'b0;
      end else begin
        if (gprev_v && grd_req_valid) tb_check({grd_dom, grd_op, grd_attr, grd_addr, grd_len} == gprev[119:0],
                                               "guard check fields changed while the verdict was pending");
        if (gprev_v && !grd_req_valid) tb_fail("guard request withdrawn before its verdict");
        gprev_v = grd_req_valid && !grd_rsp_valid;
        gprev   = {8'd0, grd_dom, grd_op, grd_attr, grd_addr, grd_len};
        if (grd_req_valid && grd_rsp_valid) begin
          e.dom = grd_dom; e.op = grd_op; e.attr = grd_attr; e.addr = grd_addr; e.len = grd_len;
          e.permit = grd_permit; e.status = grd_status;
          grd_log.push_back(e);
        end
      end
    end
  end else begin : gen_no_guard
    assign grd_rsp_valid = 1'b0;
    assign grd_permit    = 1'b0;
    assign grd_status    = 4'h0;
  end

  // ---- DMA client ---------------------------------------------------------------------------------------------------------------
  sf_hb_dma_client_bfm u_dma (
    .clk, .rst_n, .cancel_i(cancel),
    .dma_req_valid, .dma_req_ready, .dma_req_write, .dma_req_posted, .dma_req_addr, .dma_req_len, .dma_req_id,
    .dma_w_valid, .dma_w_ready, .dma_w_data, .dma_w_be, .dma_w_last,
    .dma_r_valid, .dma_r_ready, .dma_r_id, .dma_r_status, .dma_r_is_write, .dma_r_data, .dma_r_be, .dma_r_last
  );

  //  Host memory is written only through this task, so the host model and the DMA client's shadow agree.
  task automatic poke_host(input longint unsigned a, input byte unsigned b);
    u_host.hm_poke(a, b);
    u_dma.sh_poke(a, b);
  endtask

  //  Independent view of the SRAM: the stored bytes, read behind the bridge's back.  An address-translation error
  //  that is consistent between a write and its read-back (a constant offset, an alias) cannot hide from this.
  function automatic byte unsigned sram_peek(input longint unsigned byte_off);
    logic [127:0] w;
    w = u_fab.u_mem.mem_q[int'(byte_off >> 4)];
    return w[8 * int'(byte_off[3:0]) +: 8];
  endfunction

  //  The bridge must never put an illegal request on the ALP link: every rejection happens locally.
  always @(posedge clk) begin
    if (rst_n && m_req_valid && m_req_ready)
      tb_check(sf_albion_pkg::sf_req_check(m_req) == sf_albion_pkg::SF_ST_OKAY,
               $sformatf("the bridge issued an ILLEGAL ALP request (status %0d): op=%0d dom=%h be=%h addr=%h",
                         sf_albion_pkg::sf_req_check(m_req), m_req.op, m_req.dom, m_req.be, m_req.addr));
  end

  // ---- ALP request / response counters (what actually crossed the fabric link) ----------------------------------------------------------
  int alp_reqs = 0, alp_rd = 0, alp_wr = 0, alp_rsps = 0, alp_err_rsps = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      alp_reqs = 0; alp_rd = 0; alp_wr = 0; alp_rsps = 0; alp_err_rsps = 0;
    end else begin
      if (m_req_valid && m_req_ready) begin
        alp_reqs++;
        if (m_req.op == sf_albion_pkg::SF_OP_WRITE) alp_wr++; else alp_rd++;
      end
      if (m_rsp_valid && m_rsp_ready) begin
        alp_rsps++;
        if (m_rsp.status != sf_albion_pkg::SF_ST_OKAY) alp_err_rsps++;
      end
    end
  end

  // ---- event logger --------------------------------------------------------------------------------------------------------------------
  typedef struct { bit [1:0] src; bit [3:0] code; bit [7:0] tag; bit [63:0] addr; } evt_t;
  evt_t evt_log [$];
  int   evt_total = 0;
  bit   evt_rdy_r = 1'b1;
  assign err_ready = evt_rdy_r;
  always @(negedge clk) evt_rdy_r <= evt_ready_en;
  bit [77:0] evt_prev;            // {src[1:0], code[3:0], tag[7:0], addr[63:0]}
  bit        evt_hold = 1'b0;
  always @(posedge clk) begin
    evt_t e;
    if (!rst_n) begin
      evt_hold = 1'b0;
    end else begin
      if (evt_hold) begin
        tb_check(err_valid, "err_evt valid dropped before it was taken");
        tb_check({err_src, err_code, err_tag, err_addr} == evt_prev, "err_evt payload changed while stalled");
      end
      evt_hold = err_valid && !err_ready;
      evt_prev = {err_src, err_code, err_tag, err_addr};
      if (err_valid && err_ready) begin
        e.src = err_src; e.code = err_code; e.tag = err_tag; e.addr = err_addr;
        evt_log.push_back(e);
        evt_total++;
        tb_cov($sformatf("err_evt_code_%0d", err_code));
      end
    end
  end

  //  Pop the oldest logged event and check it.  Waits up to `wait_cycles` for it to arrive.
  task automatic expect_evt(input bit [1:0] src, input bit [3:0] code, input bit [7:0] tag, input bit [63:0] addr,
                            input int wait_cycles);
    int t;
    t = 0;
    while (evt_log.size() == 0 && t < wait_cycles) begin @(negedge clk); t++; end
    if (evt_log.size() == 0) begin
      tb_fail($sformatf("expected event (src=%0d code=%0d tag=%0d) never arrived", src, code, tag));
    end else begin
      tb_check(evt_log[0].src == src,   $sformatf("event src %0d expected %0d", evt_log[0].src, src));
      tb_check(evt_log[0].code == code, $sformatf("event code %0d expected %0d (tag %0d)", evt_log[0].code, code, tag));
      tb_check(evt_log[0].tag == tag,   $sformatf("event tag %0d expected %0d", evt_log[0].tag, tag));
      tb_check(evt_log[0].addr == addr, $sformatf("event addr %h expected %h", evt_log[0].addr, addr));
      evt_log.pop_front();
    end
  endtask

  task automatic expect_no_evt(input int wait_cycles);
    repeat (wait_cycles) @(negedge clk);
    tb_check(evt_log.size() == 0, $sformatf("unexpected error event(s): %0d logged (first code %0d tag %0d)",
                                            evt_log.size(), evt_log.size() > 0 ? evt_log[0].code : 0,
                                            evt_log.size() > 0 ? evt_log[0].tag : 0));
    evt_log.delete();
  endtask

  // fatal must never rise in a legal test
  always @(posedge clk) if (rst_n && fatal && !ALLOW_FATAL) tb_fail("bridge latched a fatal ALP link error");

  // ---- clocked checker for reset hygiene (ALP-RST-01 and HTI): no valid while reset is low ------------------------------------------------------
  always @(posedge clk) begin
    if (!rst_n) begin
      tb_check(!m_req_valid && !hcpl_valid && !dreq_valid && !dw_valid && !dma_r_valid,
               "a valid output is high while rst_n is low");
    end
  end
endmodule

`default_nettype wire
