// =============================================================================
//  tb_hb_host_path.sv  --  host -> device path: MMIO / memory accesses, boundaries, errors, posted writes
// -----------------------------------------------------------------------------
//  Environment: bridge + AlbionCore ref subsystem (stage-1 SRAM demo).  Host SRAM aperture
//  0x1000_0000 + 16 KiB -> device SRAM; CSR aperture 0 + 1 MiB is NOT backed here (fabric: DECODE_ERR).
//  Parameter AP1_SIZE (default 16 KiB) lets a variant run put the aperture edge off a 4 KiB boundary.
// =============================================================================
`default_nettype none

module tb_hb_host_path #(
  parameter logic [63:0] AP1_SIZE = 64'h4000
);
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  always #5 clk = ~clk;

  hb_env_sram #(.AP1_SIZE(AP1_SIZE)) u_env (
    .clk, .rst_n, .cancel(1'b0), .evt_ready_en(1'b1),
    .grd_cfg_we(1'b0), .grd_cfg_idx(3'd0), .grd_cfg_base(64'd0), .grd_cfg_limit(64'd0), .grd_cfg_dom(8'd0),
    .grd_cfg_rd(1'b0), .grd_cfg_wr(1'b0), .grd_cfg_valid(1'b0)
  );

  localparam longint unsigned SRAM = 64'h1000_0000;
  localparam bit [7:0]        DOM  = 8'h10;
  localparam bit [3:0] UR = 4'd1, DENIED = 4'd2, BAD_LEN = 4'd5, BOUNDARY = 4'd6, BAD_REQ = 4'd9;
  longint unsigned SRAM_END;       // first byte after the SRAM aperture

  function automatic bit [7:0] rtag();
    return 8'(tb_below(256));
  endfunction

  task automatic rd(input longint unsigned a, input int len);
    u_env.u_host.post_rd(rtag(), a, len, DOM, 0, 1'b1);
  endtask
  task automatic wr(input longint unsigned a, input int len, input bit posted, input int strobe);
    u_env.u_host.post_wr(rtag(), a, len, DOM, posted, 0, 1'b1, strobe);
  endtask
  task automatic bad_rd(input longint unsigned a, input int len, input int st);
    u_env.u_host.post_rd(rtag(), a, len, DOM, st, 1'b1);
  endtask
  task automatic bad_wr(input longint unsigned a, input int len, input int st);
    u_env.u_host.post_wr(rtag(), a, len, DOM, 1'b0, st, 1'b1, 0);
  endtask
  task automatic drain(input int cyc);
    u_env.u_host.wait_req_idle(cyc);
  endtask

  // a rejected request: its event {HOST, status, tag, address} must follow
  task automatic bad_with_evt(input bit is_wr, input longint unsigned a, input int len, input int st,
                              input bit [7:0] dom, input bit [1:0] kind_raw, input bit use_raw);
    bit [7:0] t;
    t = rtag();
    if (use_raw) u_env.u_host.post_any(kind_raw, t, a, len, dom, st, 1'b1, 0, -1);
    else if (is_wr) u_env.u_host.post_wr(t, a, len, dom, 1'b0, st, 1'b1, 0);
    else u_env.u_host.post_rd(t, a, len, dom, st, 1'b1);
    drain(3000);
    u_env.expect_evt(2'd0, 4'(st), t, a, 20);
  endtask

  initial begin
    SRAM_END = SRAM + AP1_SIZE;
    tb_seed(32'd2024);
    for (int c = 1; c <= 15; c++) tb_cov_declare($sformatf("hcpl_status_%0d", c));
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (4) @(negedge clk);

    // ---- P1: idle after reset
    tb_check(u_env.u_dut.hreq_ready_o, "P1: hreq_ready must be high after reset");
    tb_check(!u_env.m_req_valid && !u_env.hcpl_valid, "P1: no traffic after reset");

    // ---- P2: single accesses of every size at every legal offset (and word straddles)
    for (int sz = 1; sz <= 16; sz = sz << 1) begin
      for (int off = 0; off < 32; off++) begin
        wr(SRAM + 64'h40 + off, sz, 1'b0, 0);
        rd(SRAM + 64'h40 + off, sz);
      end
    end
    drain(40000);
    $display("P2 single accesses: checks=%0d errors=%0d alp_reqs=%0d", tb_checks, tb_errors, u_env.alp_reqs);

    // ---- P3: exhaustive offset x length sweep (write then read the same span, then a wider read)
    for (int off = 0; off < 16; off++) begin
      for (int len = 1; len <= 48; len++) begin
        wr(SRAM + 64'h200 + off, len, 1'b0, 0);
        rd(SRAM + 64'h200 + off, len);
        if (len % 7 == 0) rd(SRAM + 64'h1F0, 96);
      end
      drain(100000);
    end
    $display("P3 offset x length sweep: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- P4: byte-strobe holes keep the old data in the holes
    for (int i = 0; i < 40; i++) begin
      int off, len;
      off = tb_below(16); len = tb_range(1, 80);
      wr(SRAM + 64'h800 + off, len, 1'b0, 1);
      rd(SRAM + 64'h7F0, len + 40);
    end
    drain(100000);
    $display("P4 strobe holes: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- P5: large bursts up to the 4 KiB limit
    wr(SRAM + 64'h0000, 4096, 1'b0, 0);
    rd(SRAM + 64'h0000, 4096);
    wr(SRAM + 64'h0800, 2048, 1'b0, 0);
    rd(SRAM + 64'h0000, 4096);
    if (AP1_SIZE >= 64'h2000) begin
      wr(SRAM + 64'h1001, 4095 - 1, 1'b0, 0);                     // unaligned, ends at the page end - 1
      rd(SRAM + 64'h1000, 4096);
    end else begin
      wr(SRAM + 64'h1001, 1000, 1'b0, 0);                         // small aperture: stay inside it
      rd(SRAM + 64'h1000, 1024);
    end
    drain(300000);
    $display("P5 large bursts: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- P6: boundary / aperture / length / kind / domain cases with exact status and event
    u_env.evt_log.delete();
    // last byte of the aperture is fine, the byte after is not mapped
    wr(SRAM_END - 16, 16, 1'b0, 0);
    rd(SRAM_END - 16, 16);
    wr(SRAM_END - 1, 1, 1'b0, 0);
    rd(SRAM_END - 1, 1);
    drain(5000);
    u_env.expect_no_evt(10);
    bad_with_evt(1'b0, SRAM_END,       1,  UR, DOM, 2'd0, 1'b0);     // first byte past the aperture
    bad_with_evt(1'b1, SRAM_END + 64'h100, 16, UR, DOM, 2'd0, 1'b0);
    bad_with_evt(1'b0, SRAM - 1,       1,  UR, DOM, 2'd0, 1'b0);     // just below the aperture
    bad_with_evt(1'b0, 64'h0FFF_FFF0, 16,  UR, DOM, 2'd0, 1'b0);    // between the apertures
    bad_with_evt(1'b0, 64'hFFFF_FFFF_FFFF_FFF0, 16, UR, DOM, 2'd0, 1'b0);   // last 16 bytes of the space: unmapped, no wrap
    bad_with_evt(1'b0, SRAM_END - 8,   16, BOUNDARY, DOM, 2'd0, 1'b0);       // straddles the aperture end
    bad_with_evt(1'b1, SRAM_END - 3,   64, BOUNDARY, DOM, 2'd0, 1'b0);
    bad_with_evt(1'b0, SRAM + 64'h0FF8, 16, BOUNDARY, DOM, 2'd0, 1'b0);     // crosses a 4 KiB boundary
    bad_with_evt(1'b1, SRAM + 64'h0FFF, 2,  BOUNDARY, DOM, 2'd0, 1'b0);
    bad_with_evt(1'b0, SRAM + 64'h1000 - 1, 4096, BOUNDARY, DOM, 2'd0, 1'b0);
    bad_with_evt(1'b0, 64'hFFFF_FFFF_FFFF_FFF0, 32, BOUNDARY, DOM, 2'd0, 1'b0);    // wraps the 64-bit space
    bad_with_evt(1'b1, 64'hFFFF_FFFF_FFFF_FFFF, 2,  BOUNDARY, DOM, 2'd0, 1'b0);
    bad_with_evt(1'b0, SRAM, 0,    BAD_LEN, DOM, 2'd0, 1'b0);
    bad_with_evt(1'b1, SRAM + 3, 0, BAD_LEN, DOM, 2'd0, 1'b0);              // zero-length write: zero data beats
    bad_with_evt(1'b0, SRAM, 4097, BAD_LEN, DOM, 2'd0, 1'b0);
    bad_with_evt(1'b1, SRAM + 5, 4097, BAD_LEN, DOM, 2'd0, 1'b0);           // data of 257 beats is drained
    bad_with_evt(1'b1, SRAM + 13, 8191, BAD_LEN, DOM, 2'd0, 1'b0);          // data of 513 beats is drained
    bad_with_evt(1'b0, SRAM, 16, BAD_REQ, DOM, 2'd0, 1'b1);                 // kind NONE
    bad_with_evt(1'b0, SRAM, 16, DENIED, 8'hFF, 2'd1, 1'b1);                // reserved domain 0xFF (read)
    bad_with_evt(1'b1, SRAM, 16, DENIED, 8'hFF, 2'd2, 1'b1);                // reserved domain 0xFF (write)
    // CSR aperture: the bridge accepts, the stage-1 fabric has no target there -> UR from the fabric
    bad_with_evt(1'b0, 64'h0, 16, UR, DOM, 2'd0, 1'b0);
    bad_with_evt(1'b1, 64'h10, 4, UR, DOM, 2'd0, 1'b0);
    // none of the rejected writes changed memory: read back the whole region we have been using
    rd(SRAM, 4096);
    rd(SRAM_END - 64, 64);
    drain(100000);
    u_env.expect_no_evt(10);
    $display("P6 boundary/error cases: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- P7: posted writes keep order with later reads; a failing posted write is only an event
    for (int i = 0; i < 20; i++) begin
      wr(SRAM + 64'h300 + 16*i, 16, 1'b1, 0);
      rd(SRAM + 64'h300 + 16*i, 16);
    end
    for (int i = 0; i < 10; i++) wr(SRAM + 64'h400 + i*3, 3, 1'b1, 0);
    rd(SRAM + 64'h400, 64);
    drain(100000);
    u_env.expect_no_evt(10);
    begin
      bit [7:0] t;
      t = 8'd77;
      u_env.u_host.post_wr(t, SRAM_END + 64'h20, 16, DOM, 1'b1, 0, 1'b0, 0);      // posted, unmapped: no completion
      u_env.u_host.post_wr(8'd78, SRAM + 64'h0FFF, 2, DOM, 1'b1, 0, 1'b0, 0);     // posted, crosses 4 KiB
      u_env.u_host.post_wr(8'd79, SRAM, 0, DOM, 1'b1, 0, 1'b0, 0);                // posted, zero length
      rd(SRAM, 32);
      drain(5000);
      u_env.expect_evt(2'd0, UR, 8'd77, SRAM_END + 64'h20, 30);
      u_env.expect_evt(2'd0, BOUNDARY, 8'd78, SRAM + 64'h0FFF, 30);
      u_env.expect_evt(2'd0, BAD_LEN, 8'd79, SRAM, 30);
      u_env.expect_no_evt(10);
    end
    $display("P7 posted writes: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- P8: data presented before its request, dirty lanes, all channels throttled
    u_env.u_host.cfg_data_first = 1;
    u_env.u_host.cfg_req_gap = 40; u_env.u_host.cfg_hw_gap = 40; u_env.u_host.cfg_cpl_rdy = 30;
    for (int i = 0; i < 60; i++) begin
      int off, len;
      off = tb_below(16); len = tb_range(1, 130);
      wr(SRAM + 64'hC00 + off, len, tb_pct(30), tb_below(2));
      rd(SRAM + 64'hBF0, len + 40);
    end
    drain(400000);
    u_env.u_host.cfg_data_first = 0;
    u_env.u_host.cfg_req_gap = 0; u_env.u_host.cfg_hw_gap = 0; u_env.u_host.cfg_cpl_rdy = 100;
    $display("P8 data-first + throttled: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- P9: whole-memory sweep: write every word of the SRAM aperture then read it all back
    for (int w = 0; w < AP1_SIZE / 256; w++) wr(SRAM + w*256, 256, 1'b0, 0);
    for (int w = 0; w < AP1_SIZE / 256; w++) rd(SRAM + w*256, 256);
    drain(600000);
    u_env.expect_no_evt(10);

    // ---- backdoor: the bytes really stored in the SRAM equal the reference model, byte for byte, over the whole
    //      aperture.  This is an independent view: a constant address offset or an alias would pass every read-back above.
    repeat (60) @(negedge clk);
    begin
      int bad;
      bad = 0;
      for (int i = 0; i < int'(AP1_SIZE); i++) if (u_env.sram_peek(i) != u_env.u_host.dref_peek(SRAM + i)) bad++;
      tb_check(bad == 0, $sformatf("backdoor: %0d SRAM bytes differ from the reference model", bad));
    end
    tb_check(u_env.u_dut.host_outstanding_o == 0, "bridge shows outstanding ALP words at the end");
    tb_check(!u_env.u_dut.host_busy_o, "bridge host path still busy at the end");
    tb_check(!u_env.fatal, "fatal latched");
    tb_cov_declare("alp_reqs_seen");
    for (int i = 0; i < u_env.alp_reqs; i++) if (i % 100 == 0) tb_cov("alp_reqs_seen");
    repeat (20) @(negedge clk);
    $display("alp: reqs=%0d (rd=%0d wr=%0d) err_rsps=%0d", u_env.alp_reqs, u_env.alp_rd, u_env.alp_wr, u_env.alp_err_rsps);
    tb_report("tb_hb_host_path");
    $finish;
  end

  initial begin
    #200000000;
    tb_fail("host path: global timeout");
    tb_report("tb_hb_host_path");
    $finish;
  end
endmodule

`default_nettype wire
