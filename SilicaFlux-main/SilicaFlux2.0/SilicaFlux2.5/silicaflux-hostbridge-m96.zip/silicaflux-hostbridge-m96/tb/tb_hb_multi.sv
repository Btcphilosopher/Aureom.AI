// =============================================================================
//  tb_hb_multi.sv  --  multiple outstanding transactions, back-pressure, event back-pressure
// -----------------------------------------------------------------------------
//    M1  the outstanding-word limit is reached and never exceeded (ALP-OUT-01 is also asserted by the link checker)
//    M2  hreq_ready / hw_ready really go low when the pipeline is full, nothing is lost, order is kept
//    M3  a stalled event consumer loses no event: every rejected request is logged, in order, with tag and address
//    M4  mixed random traffic under random throttling on every channel
// =============================================================================
`default_nettype none

module tb_hb_multi #(
  parameter int unsigned MAX_OUT   = 8,
  parameter int unsigned RSP_DEPTH = 2        // response FIFO depth of the fabric SRAM: its buffering bounds what can be outstanding
);
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  logic evt_en = 1'b1;
  always #5 clk = ~clk;

  hb_env_sram #(.MAX_OUT(MAX_OUT), .MEM_EXTRA_LAT(6), .MEM_RSP_DEPTH(RSP_DEPTH)) u_env (
    .clk, .rst_n, .cancel(1'b0), .evt_ready_en(evt_en),
    .grd_cfg_we(1'b0), .grd_cfg_idx(3'd0), .grd_cfg_base(64'd0), .grd_cfg_limit(64'd0), .grd_cfg_dom(8'd0),
    .grd_cfg_rd(1'b0), .grd_cfg_wr(1'b0), .grd_cfg_valid(1'b0)
  );

  localparam longint unsigned SRAM = 64'h1000_0000;
  localparam bit [7:0] DOM = 8'h10;
  localparam bit [3:0] UR = 4'd1;
  int max_alp_out = 0;
  int hreq_low = 0, hw_low = 0;

  always @(posedge clk) begin
    if (rst_n) begin
      if (u_env.alp_outstanding > max_alp_out) max_alp_out = u_env.alp_outstanding;
      if (!u_env.hreq_ready) hreq_low++;
      if (!u_env.hw_ready)   hw_low++;
    end
  end

  initial begin
    tb_seed(32'd7777 + MAX_OUT);
    tb_cov_declare("hreq_backpressure_seen"); tb_cov_declare("hw_backpressure_seen");
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (1100) @(negedge clk);

    // ---- M1: a slow consumer lets words pile up until the outstanding limit is reached
    u_env.u_host.cfg_cpl_rdy = 10;
    for (int i = 0; i < 6; i++) u_env.u_host.post_rd(8'(10 + i), SRAM + i * 1024, 1024, DOM, 0, 1'b1);
    u_env.u_host.wait_req_idle(400000);
    u_env.u_host.cfg_cpl_rdy = 100;
    //  The bridge may have MAX_OUT words outstanding; a target may back-pressure earlier (ALP-OUT-02): the stage-1
    //  fabric buffers about RSP_DEPTH + 2 * 6 + 4 responses, so with a deep fabric FIFO the limit itself is reached.
    if (MAX_OUT <= 16 || RSP_DEPTH >= 64) tb_check(max_alp_out == MAX_OUT, $sformatf("M1: outstanding ALP words peaked at %0d, expected exactly MAX_OUT=%0d", max_alp_out, MAX_OUT));
    else                                  tb_check(max_alp_out >= 16 && max_alp_out <= MAX_OUT, $sformatf("M1: peak %0d (fabric-limited)", max_alp_out));
    $display("M1 outstanding limit (MAX_OUT=%0d, peak %0d): checks=%0d errors=%0d", MAX_OUT, max_alp_out, tb_checks, tb_errors);

    // ---- M2: completions stall -> the pipeline fills -> hreq_ready goes low; nothing is lost
    u_env.u_host.cfg_cpl_rdy = 0;
    for (int i = 0; i < 60; i++) begin
      if (i % 3 == 0) u_env.u_host.post_wr(8'(i), SRAM + 64'h2000 + i * 32, 32, DOM, 1'b0, 0, 1'b1, 0);
      else            u_env.u_host.post_rd(8'(i), SRAM + 64'h2000 + (i - i % 3) * 32, 32, DOM, 0, 1'b1);
    end
    repeat (400) @(negedge clk);
    tb_check(!u_env.hreq_ready, "M2: hreq_ready is still high although completions are stalled");
    if (hreq_low > 0) tb_cov("hreq_backpressure_seen");
    tb_check(u_env.u_host.outstanding_cpl > 0, "M2: nothing outstanding while stalled?");
    u_env.u_host.cfg_cpl_rdy = 100;
    u_env.u_host.wait_req_idle(100000);
    //  data first, requests blocked: the write-data queue fills and hw_ready goes low
    u_env.u_host.cfg_data_first = 1; u_env.u_host.cfg_req_gap = 100;
    for (int i = 0; i < 10; i++) u_env.u_host.post_wr(8'(100 + i), SRAM + 64'h3000 + i * 128, 128, DOM, 1'b0, 0, 1'b1, 0);
    repeat (300) @(negedge clk);
    tb_check(!u_env.hw_ready, "M2: hw_ready is still high although 80 beats were offered and no request was accepted");
    if (hw_low > 0) tb_cov("hw_backpressure_seen");
    u_env.u_host.cfg_req_gap = 0;
    u_env.u_host.wait_req_idle(100000);
    u_env.u_host.cfg_data_first = 0;
    $display("M2 back-pressure (hreq low %0d cycles, hw low %0d cycles): checks=%0d errors=%0d", hreq_low, hw_low, tb_checks, tb_errors);

    // ---- M3: a stalled event consumer loses nothing
    u_env.evt_log.delete();
    evt_en = 1'b0;
    for (int i = 0; i < 50; i++) u_env.u_host.post_rd(8'(i + 1), 64'h0FFF_0000 + i * 16, 16, DOM, 4'(UR), 1'b1);   // all unmapped -> UR
    repeat (300) @(negedge clk);
    tb_check(!u_env.hreq_ready, "M3: the host path should stall behind the full event FIFO");
    tb_check(u_env.u_host.outstanding_cpl > 0, "M3: completions must wait for their event to be logged");
    evt_en = 1'b1;
    u_env.u_host.wait_req_idle(100000);
    repeat (20) @(negedge clk);
    tb_check(u_env.evt_log.size() == 50, $sformatf("M3: %0d events logged for 50 rejected requests", u_env.evt_log.size()));
    for (int i = 0; i < u_env.evt_log.size() && i < 50; i++) begin
      tb_check(u_env.evt_log[i].code == UR && u_env.evt_log[i].tag == 8'(i + 1) && u_env.evt_log[i].addr == 64'h0FFF_0000 + i * 16,
               $sformatf("M3: event %0d wrong (code %0d tag %0d addr %h)", i, u_env.evt_log[i].code, u_env.evt_log[i].tag, u_env.evt_log[i].addr));
    end
    u_env.evt_log.delete();
    $display("M3 event back-pressure: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- M3b: host-path AND DMA-path events at the same time, consumer stalled: merge keeps the payload stable
    //  (the env's logger asserts stability on every stalled cycle) and no event is lost
    u_env.u_host.set_error_window(0, 64'h6000_0000, 64'h6000_FFFF, 4'd1, 1'b1, 1'b0, 0, 1'b0);
    evt_en = 1'b0;
    for (int i = 0; i < 12; i++) begin
      u_env.u_host.post_rd(8'(i + 1), 64'h0FFF_0000 + i * 16, 16, DOM, 4'(UR), 1'b1);                  // host path: UR
      u_env.u_dma.post_read(8'(i + 1), 64'h6000_0000 + i * 64, 32, 4'(UR), 1'b0);                       // DMA path: UR from the host
    end
    repeat (400) @(negedge clk);
    evt_en = 1'b1;
    u_env.u_host.wait_req_idle(100000);
    u_env.u_dma.wait_idle(100000);
    repeat (20) @(negedge clk);
    begin
      int nh, nd;
      nh = 0; nd = 0;
      for (int i = 0; i < u_env.evt_log.size(); i++) if (u_env.evt_log[i].src == 2'd0) nh++; else if (u_env.evt_log[i].src == 2'd1) nd++;
      tb_check(nh == 12 && nd == 12, $sformatf("M3b: %0d host and %0d DMA events logged, expected 12 and 12", nh, nd));
    end
    u_env.evt_log.delete();
    u_env.u_host.clear_error_windows();
    $display("M3b merged event streams: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- M4: mixed random traffic under random throttling
    for (int round = 0; round < 8; round++) begin
      u_env.u_host.cfg_req_gap = tb_below(80); u_env.u_host.cfg_hw_gap = tb_below(80); u_env.u_host.cfg_cpl_rdy = 5 + tb_below(96);
      u_env.u_host.cfg_data_first = tb_below(2);
      evt_en = tb_pct(50);
      for (int i = 0; i < 120; i++) begin
        int len;
        longint unsigned off;
        len = tb_pct(10) ? tb_range(100, 600) : tb_range(1, 70);
        off = tb_below(16384);
        if (int'(off % 4096) + len > 4096) len = 4096 - int'(off % 4096);          // legal: inside one 4 KiB page, inside the aperture
        if (tb_pct(45)) u_env.u_host.post_wr(8'(tb_below(256)), SRAM + off, len, DOM, tb_pct(25), 0, 1'b1, tb_below(2));
        else            u_env.u_host.post_rd(8'(tb_below(256)), SRAM + off, len, DOM, 0, 1'b1);
      end
      u_env.u_host.wait_req_idle(600000);
      evt_en = 1'b1;
    end
    u_env.u_host.cfg_req_gap = 0; u_env.u_host.cfg_hw_gap = 0; u_env.u_host.cfg_cpl_rdy = 100; u_env.u_host.cfg_data_first = 0;
    repeat (50) @(negedge clk);
    u_env.expect_no_evt(5);
    tb_check(max_alp_out <= MAX_OUT, "M4: outstanding limit exceeded");
    tb_check(u_env.u_dut.host_outstanding_o == 0 && !u_env.u_dut.host_busy_o, "bridge not idle at the end");
    $display("M4 random mix: checks=%0d errors=%0d", tb_checks, tb_errors);

    repeat (20) @(negedge clk);
    tb_report("tb_hb_multi");
    $finish;
  end

  initial begin
    #900000000;
    tb_fail("multi: global timeout");
    tb_report("tb_hb_multi");
    $finish;
  end
endmodule

`default_nettype wire
