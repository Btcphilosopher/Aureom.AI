// =============================================================================
//  tb_hb_dma.sv  --  device -> host path: DMA reads / writes, splitting, tags, out-of-order completions,
//                    back-pressure, host faults, rogue completions
// -----------------------------------------------------------------------------
//  Environment: bridge + host model (host memory + completer) + DMA client model.  Parameters select the
//  tag count / chunk sizes so the same test runs on several configurations.
// =============================================================================
`default_nettype none

module tb_hb_dma #(
  parameter int unsigned NUM_TAGS  = 8,
  parameter int unsigned MPS_BYTES = 256,
  parameter int unsigned MRRS_BYTES = 256
);
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  always #5 clk = ~clk;

  hb_env_sram #(.NUM_TAGS(NUM_TAGS), .MPS_BYTES(MPS_BYTES), .MRRS_BYTES(MRRS_BYTES)) u_env (
    .clk, .rst_n, .cancel(1'b0), .evt_ready_en(1'b1),
    .grd_cfg_we(1'b0), .grd_cfg_idx(3'd0), .grd_cfg_base(64'd0), .grd_cfg_limit(64'd0), .grd_cfg_dom(8'd0),
    .grd_cfg_rd(1'b0), .grd_cfg_wr(1'b0), .grd_cfg_valid(1'b0)
  );

  localparam longint unsigned HR = 64'h2000_0000;   // host region used for reads (initial pattern)
  localparam longint unsigned HW = 64'h3000_0000;   // host region used for writes
  localparam bit [3:0] UR = 4'd1, CA = 4'd3, POISON = 4'd4, PROTO = 4'd10;
  byte unsigned nid = 8'd0;

  function automatic bit [7:0] next_id();
    nid++;
    return nid;
  endfunction

  task automatic rd(input longint unsigned a, input int len);
    u_env.u_dma.post_read(next_id(), a, len, 0, 1'b1);
  endtask
  task automatic wr(input longint unsigned a, input int len, input bit posted, input int strobe);
    u_env.u_dma.post_write(next_id(), a, len, posted, 0, strobe);
  endtask
  task automatic drain(input int cyc);
    u_env.u_dma.wait_idle(cyc);
  endtask
  task automatic knobs(input int dreq_rdy, input int dw_rdy, input int r_rdy, input int req_gap, input int w_gap);
    u_env.u_host.cfg_dreq_rdy = dreq_rdy; u_env.u_host.cfg_dw_rdy = dw_rdy;
    u_env.u_dma.cfg_r_rdy = r_rdy; u_env.u_dma.cfg_req_gap = req_gap; u_env.u_dma.cfg_w_gap = w_gap;
  endtask
  task automatic report(input string name);
    $display("%-34s checks=%0d errors=%0d  dreq rd/wr/wrp=%0d/%0d/%0d max_tags=%0d ooo_sw=%0d unexpected=%0d",
             name, tb_checks, tb_errors, u_env.u_host.n_dreq_rd, u_env.u_host.n_dreq_wr, u_env.u_host.n_dreq_wrp,
             u_env.u_host.max_tags_seen, u_env.u_host.n_ooo_switches, u_env.unexpected_cpl);
  endtask

  initial begin
    int nwd;
    int lens [] = '{1, 2, 3, 15, 16, 17, 31, 32, 33, 47, 63, 64, 65, 255, 256, 257, 511, 512, 513, 1023, 1024, 1025};
    tb_seed(32'd99);
    nwd = (MRRS_BYTES >= 64) ? 4 : 2;
    for (int c = 1; c <= 15; c++) tb_cov_declare($sformatf("dma_status_%0d", c));
    tb_cov_declare("dma_ooo_forced");
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (4) @(negedge clk);

    // ---- D1: read sweep, every offset 0..15 x a set of lengths
    for (int off = 0; off < 16; off++) begin
      foreach (lens[i]) rd(HR + 64'h10000 + off + i*4096, lens[i]);
      drain(300000);
    end
    report("D1 read sweep");

    // ---- D2: write sweep with and without strobe holes, then read everything back through the bridge
    for (int off = 0; off < 16; off++) begin
      foreach (lens[i]) wr(HW + 64'h10000 + off + i*4096, lens[i], tb_pct(30), (i + off) % 2);
      drain(300000);
    end
    for (int off = 0; off < 16; off++) begin
      foreach (lens[i]) rd(HW + 64'h10000 + off + i*4096 - 8, lens[i] + 16);
      drain(300000);
    end
    report("D2 write sweep + read back");

    // ---- D3: requests that cross 4 KiB boundaries repeatedly
    rd(HR + 64'h0FFF, 2);
    rd(HR + 64'h0FF0, 32);
    rd(HR + 64'h0001, 3 * 4096 + 7);
    wr(HW + 64'h0FF8, 16, 1'b0, 0);
    wr(HW + 64'h1FFF, 9000, 1'b0, 1);
    rd(HW + 64'h1FF0, 9040);
    drain(400000);
    report("D3 4 KiB crossings");

    // ---- D4: more outstanding reads than tags, slow host: the tag pool saturates, nothing is lost
    // issue rate x latency must exceed the pool size for it to saturate: scale the latency with the pool
    u_env.u_host.cfg_lat_min = 40 + 8 * NUM_TAGS; u_env.u_host.cfg_lat_max = 90 + 8 * NUM_TAGS;
    for (int i = 0; i < 4 * NUM_TAGS; i++) rd(HR + 64'h80000 + i*64, 32 + (i % 5) * MRRS_BYTES / 2);
    drain(600000);
    tb_check(u_env.u_host.max_tags_seen == NUM_TAGS, $sformatf("D4: tag pool did not saturate (%0d of %0d)", u_env.u_host.max_tags_seen, NUM_TAGS));
    u_env.u_host.cfg_lat_min = 2; u_env.u_host.cfg_lat_max = 6;
    report("D4 tag exhaustion");

    // ---- D5: out-of-order completions: random permutation / interleaving of beats across tags
    u_env.u_host.cfg_ooo_pct = 100; u_env.u_host.cfg_lat_min = 2; u_env.u_host.cfg_lat_max = 80;
    for (int i = 0; i < 300; i++) begin
      int len;
      len = tb_range(1, 3 * MRRS_BYTES);
      if (tb_pct(35)) wr(HW + 64'h200000 + tb_below(32) * 64'h4000 + tb_below(16), len, tb_pct(40), tb_below(2));
      else            rd(HR + 64'h100000 + tb_below(1 << 16), len);
    end
    drain(1500000);
    // switching between streams needs several tags in flight
    if (NUM_TAGS >= 4) tb_check(u_env.u_host.n_ooo_switches > 20, "D5: no out-of-order stream switching was exercised");
    report("D5 out-of-order random");

    // ---- D6: forced reordering: the oldest request is answered LAST, the client still gets request order
    u_env.u_host.cfg_ooo_pct = 0;
    u_env.u_host.cfg_lat_min = 400; u_env.u_host.cfg_lat_max = 400;
    rd(HR + 64'h300000, 3 * MRRS_BYTES);                      // slow
    repeat (30) @(negedge clk);
    u_env.u_host.cfg_lat_min = 3; u_env.u_host.cfg_lat_max = 3;
    for (int i = 0; i < NUM_TAGS - 1; i++) rd(HR + 64'h310000 + i * 512, 100 + i);   // fast, issued later
    repeat (30) @(negedge clk);
    tb_check(u_env.u_dma.outstanding == NUM_TAGS && u_env.u_host.n_tag_out >= 1,
             "D6: the fast requests should be complete but held behind the slow oldest one");
    tb_cov("dma_ooo_forced");
    drain(100000);
    u_env.u_host.cfg_lat_min = 2; u_env.u_host.cfg_lat_max = 6;
    report("D6 forced reorder");

    // ---- D7: back-pressure on every channel, data before request
    knobs(20, 20, 20, 50, 50);
    u_env.u_dma.cfg_data_first = 1;
    u_env.u_host.cfg_ooo_pct = 50;
    for (int i = 0; i < 150; i++) begin
      int len;
      len = tb_range(1, 2 * MPS_BYTES + 40);
      if (tb_pct(50)) wr(HW + 64'h400000 + tb_below(1 << 14), len, tb_pct(30), tb_below(2));
      else            rd(HW + 64'h400000 + tb_below(1 << 14), len);
    end
    drain(3000000);
    knobs(100, 100, 100, 0, 0);
    u_env.u_dma.cfg_data_first = 0;
    u_env.u_host.cfg_ooo_pct = 0;
    report("D7 back-pressure everywhere");

    // ---- D8: faults reported by the host
    u_env.evt_log.delete();
    // immediate error completion of a single-chunk read
    u_env.u_host.set_error_window(0, HR + 64'h500000, HR + 64'h5000FF, UR, 1'b1, 1'b0, 0, 1'b0);
    u_env.u_dma.post_read(8'd201, HR + 64'h500010, 32, int'(UR), 1'b1);
    u_env.u_dma.post_read(8'd202, HR + 64'h600000, 64, 0, 1'b1);         // fine again: tag was released
    drain(50000);
    u_env.expect_evt(2'd1, UR, 8'd201, HR + 64'h500010, 40);
    // CA after 2 beats of a 5-word read (the error replaces the rest; the chunk's data is discarded)
    u_env.u_host.set_error_window(0, HR + 64'h510000, HR + 64'h5100FF, CA, 1'b1, 1'b0, 2, 1'b0);
    u_env.u_dma.post_read(8'd203, HR + 64'h510000, 80, int'(CA), 1'b1);
    // poisoned data
    u_env.u_host.set_error_window(1, HR + 64'h520000, HR + 64'h5200FF, POISON, 1'b1, 1'b0, 0, 1'b0);
    u_env.u_dma.post_read(8'd204, HR + 64'h520000, 16, int'(POISON), 1'b1);
    drain(50000);
    u_env.expect_evt(2'd1, CA, 8'd203, HR + 64'h510000, 40);
    u_env.expect_evt(2'd1, POISON, 8'd204, HR + 64'h520000, 40);
    // the MIDDLE chunk of a multi-chunk read fails: chunk 1 data is delivered, then ONE error beat; chunks 3..n
    // are drained and discarded, and the next request is unaffected
    u_env.u_host.clear_error_windows();
    begin
      longint unsigned base;
      base = HR + 64'h530000;
      u_env.u_host.set_error_window(0, base + 2 * MRRS_BYTES, base + 2 * MRRS_BYTES + 3, CA, 1'b1, 1'b0, 0, 1'b0);
      u_env.u_dma.post_read(8'd205, base, 5 * MRRS_BYTES, int'(CA), 1'b1);
      u_env.u_dma.post_read(8'd206, base + 64'h10000, 5 * MRRS_BYTES, 0, 1'b1);
      drain(100000);
      u_env.expect_evt(2'd1, CA, 8'd205, base + 2 * MRRS_BYTES, 40);
    end
    // every defined error code a host completion can carry reaches the client unchanged (DENIED, BAD_REQ were not yet used above)
    u_env.u_host.clear_error_windows();
    u_env.u_host.set_error_window(0, HR + 64'h580000, HR + 64'h5800FF, 4'd2, 1'b1, 1'b0, 0, 1'b0);
    u_env.u_host.set_error_window(1, HR + 64'h581000, HR + 64'h5810FF, 4'd9, 1'b1, 1'b0, 0, 1'b0);
    u_env.u_dma.post_read(8'd212, HR + 64'h580000, 16, 2, 1'b1);
    u_env.u_dma.post_read(8'd213, HR + 64'h581000, 48, 9, 1'b1);
    drain(50000);
    u_env.expect_evt(2'd1, 4'd2, 8'd212, HR + 64'h580000, 40);
    u_env.expect_evt(2'd1, 4'd9, 8'd213, HR + 64'h581000, 40);
    // write acknowledged with an error
    u_env.u_host.clear_error_windows();
    u_env.u_host.set_error_window(0, HW + 64'h540000, HW + 64'h5400FF, UR, 1'b0, 1'b1, 0, 1'b0);
    u_env.u_dma.post_write(8'd207, HW + 64'h540010, 32, 1'b0, int'(UR), 0);
    u_env.u_dma.post_write(8'd208, HW + 64'h550000, 32, 1'b0, 0, 0);
    drain(50000);
    u_env.expect_evt(2'd1, UR, 8'd207, HW + 64'h540010, 40);
    u_env.u_host.clear_error_windows();
    u_env.expect_no_evt(20);
    tb_check(u_env.dma_out == 0, "D8: tags still busy after the fault phase");
    report("D8 host faults");

    // ---- D9: rogue completion beats (protocol violations of the host side)
    //  (a) beats for tags that are not outstanding: dropped, counted, one coalesced PROTO event
    u_env.u_host.send_raw_cpl(8'd200, 4'h0, 128'h1234, 1'b1);
    u_env.u_host.send_raw_cpl(8'd3, 4'h0, 128'h5678, 1'b1);
    u_env.u_host.send_raw_cpl(8'd3, 4'h0, 128'h5678, 1'b0);
    repeat (40) @(negedge clk);
    tb_check(u_env.unexpected_cpl == 3, $sformatf("D9a: unexpected_cpl=%0d expected 3", u_env.unexpected_cpl));
    //  coalescing merges only beats that arrive while an event is still pending, so 1..3 events are legal; the
    //  exact number of dropped beats is in unexpected_cpl (checked above)
    tb_check(u_env.evt_log.size() >= 1 && u_env.evt_log.size() <= 3,
             $sformatf("D9a: %0d events for 3 rogue beats", u_env.evt_log.size()));
    tb_check(u_env.evt_log.size() == 0 || (u_env.evt_log[0].tag == 8'd200 && u_env.evt_log[0].src == 2'd1),
             "D9a: first event must name the first rogue tag");
    for (int i = 0; i < u_env.evt_log.size(); i++) tb_check(u_env.evt_log[i].code == PROTO, "D9a: event code must be PROTO");
    u_env.evt_log.delete();
    //  (b) a short completion: `last` arrives before all words of a one-chunk request  -> PROTO to the client
    //      (one chunk of nwd words, nwd = 4, or 2 when MRRS is 32)
    u_env.u_host.set_error_window(0, HR + 64'h560000, HR + 64'h5600FF, 4'h0, 1'b1, 1'b0, 0, 1'b1);   // host stays silent
    u_env.u_dma.post_read(8'd210, HR + 64'h560000, nwd * 16, int'(PROTO), 1'b0);
    repeat (30) @(negedge clk);
    for (int k = 0; k < nwd / 2 - 1; k++) u_env.u_host.send_raw_cpl(8'd0, 4'h0, 128'hA, 1'b0);
    u_env.u_host.send_raw_cpl(8'd0, 4'h0, 128'hB, 1'b1);
    drain(20000);
    u_env.u_host.forget_tag(8'd0);
    //  (c) more beats than requested: a further beat arrives after all words -> PROTO
    u_env.u_dma.post_read(8'd211, HR + 64'h560000, nwd * 16, int'(PROTO), 1'b0);
    repeat (30) @(negedge clk);
    for (int k = 0; k < nwd + 1; k++) u_env.u_host.send_raw_cpl(8'd0, 4'h0, 128'(k), 1'b0);
    drain(20000);
    u_env.u_host.forget_tag(8'd0);
    u_env.u_host.clear_error_windows();
    u_env.expect_evt(2'd1, PROTO, 8'd210, HR + 64'h560000, 40);
    u_env.expect_evt(2'd1, PROTO, 8'd211, HR + 64'h560000, 40);
    // the bridge recovered: normal traffic still works
    rd(HR + 64'h700000, 300);
    wr(HW + 64'h700000, 300, 1'b0, 0);
    rd(HW + 64'h700000, 300);
    drain(50000);
    u_env.expect_no_evt(20);
    tb_check(u_env.dma_out == 0, "D9: tags still busy after the rogue phase");
    report("D9 rogue completions");

    // ---- D10: a POSTED write is complete for the client only once the host side has ACCEPTED its data
    u_env.u_host.cfg_dw_rdy = 5;                                        // the host takes data very slowly
    begin
      bit complete;
      u_env.u_dma.post_write(8'd230, HW + 64'h800000, 1000, 1'b1, 0, 0);
      u_env.u_dma.wait_idle(200000);                                    // returns when the client has its result
      complete = 1'b1;
      for (int i = 0; i < 1000; i++) if (u_env.u_host.hm_peek(HW + 64'h800000 + i) != u_env.u_dma.sh_peek(HW + 64'h800000 + i)) complete = 1'b0;
      tb_check(complete && u_env.u_host.completer_idle(), "D10: the posted write was reported complete before the host side had all its data");
    end
    u_env.u_host.cfg_dw_rdy = 100;
    report("D10 posted completion");

    // ---- D11: invalid DMA requests (zero length, address-space wrap) and the very top of the address space
    //  Rejected writes still consume (drain) their data beats; the client gets one error result per request and the
    //  next request is unaffected.  A request that ENDS exactly at 2^64 is legal (no wrap).
    u_env.evt_log.delete();
    u_env.u_dma.post_read(8'd240, HR + 64'h900000, 0, 5, 1'b0);                              // BAD_LEN
    u_env.u_dma.post_write(8'd241, HW + 64'h900000, 0, 1'b0, 5, 0);                          // BAD_LEN (non-posted write)
    u_env.u_dma.post_write(8'd242, HW + 64'h900010, 0, 1'b1, 5, 0);                          // BAD_LEN (posted write)
    u_env.u_dma.post_read(8'd243, 64'hFFFF_FFFF_FFFF_FFF0, 17, 6, 1'b0);                     // BOUNDARY: wraps
    u_env.u_dma.post_read(8'd244, 64'hFFFF_FFFF_FFFF_FFFF, 2, 6, 1'b0);                      // BOUNDARY: wraps after 1 byte
    u_env.u_dma.post_write(8'd245, 64'hFFFF_FFFF_FFFF_FFE8, 40, 1'b0, 6, 0);                 // BOUNDARY, data drained
    u_env.u_dma.post_write(8'd246, 64'hFFFF_FFFF_FFFF_FFFF, 2, 1'b1, 6, 1);                  // BOUNDARY, posted, strobe holes
    u_env.u_dma.post_write(8'd247, HW + 64'h900100, 100, 1'b0, 0, 0);                        // fine: data was not mis-aligned
    u_env.u_dma.post_read(8'd248, HW + 64'h900100, 100, 0, 1'b1);                            // ... and reads back
    drain(100000);
    u_env.expect_evt(2'd1, 4'd5, 8'd240, HR + 64'h900000, 40);
    u_env.expect_evt(2'd1, 4'd5, 8'd241, HW + 64'h900000, 40);
    u_env.expect_evt(2'd1, 4'd5, 8'd242, HW + 64'h900010, 40);
    u_env.expect_evt(2'd1, 4'd6, 8'd243, 64'hFFFF_FFFF_FFFF_FFF0, 40);
    u_env.expect_evt(2'd1, 4'd6, 8'd244, 64'hFFFF_FFFF_FFFF_FFFF, 40);
    u_env.expect_evt(2'd1, 4'd6, 8'd245, 64'hFFFF_FFFF_FFFF_FFE8, 40);
    u_env.expect_evt(2'd1, 4'd6, 8'd246, 64'hFFFF_FFFF_FFFF_FFFF, 40);
    u_env.expect_no_evt(20);
    //  the top of the address space is reachable: requests that end exactly at 2^64
    rd(64'hFFFF_FFFF_FFFF_FFF0, 16);
    rd(64'hFFFF_FFFF_FFFF_FFC1, 63);
    rd(64'hFFFF_FFFF_FFFF_FF00, 256);
    wr(64'hFFFF_FFFF_FFFF_FFF0, 16, 1'b0, 0);
    wr(64'hFFFF_FFFF_FFFF_FFC1, 63, 1'b1, 1);
    rd(64'hFFFF_FFFF_FFFF_FFC0, 64);
    drain(100000);
    u_env.expect_no_evt(20);
    tb_check(u_env.dma_out == 0, "D11: tags still busy after invalid / top-of-memory requests");
    report("D11 invalid DMA requests, top of memory");

    tb_check(!u_env.u_dut.dma_busy_o, "bridge DMA path still busy at the end");
    tb_check(!u_env.fatal, "fatal latched");
    repeat (20) @(negedge clk);
    tb_report("tb_hb_dma");
    $finish;
  end

  initial begin
    #900000000;
    tb_fail("dma: global timeout");
    tb_report("tb_hb_dma");
    $finish;
  end
endmodule

`default_nettype wire
