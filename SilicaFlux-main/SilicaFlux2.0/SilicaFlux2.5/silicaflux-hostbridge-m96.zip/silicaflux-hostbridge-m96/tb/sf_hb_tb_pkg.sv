// =============================================================================
//  sf_hb_tb_pkg.sv  --  HostBridge testbench helpers (never synthesized)
// -----------------------------------------------------------------------------
//  * deterministic PRNG (xorshift64*): a seed gives identical stimulus on every host,
//  * check / failure counters and one end-of-test report line,
//  * functional-coverage bins (named counters) printed in machine-readable form,
//  * the host-memory byte pattern shared by the host model and the reference models.
//
//  Report format (same shape as the AlbionCore suite, parsed by scripts/run_all.py):
//    COV <testbench> <bin> <count>
//    HB_TB_RESULT <testbench> PASS|FAIL checks=<n> errors=<n>
// =============================================================================
`default_nettype none

package sf_hb_tb_pkg;

  int unsigned tb_errors = 0;
  int unsigned tb_checks = 0;
  logic [63:0] tb_rng_state = 64'h9E37_79B9_7F4A_7C15;
  int unsigned tb_cov_cnt [string];
  bit          tb_failfast_checked = 1'b0;
  bit          tb_failfast = 1'b0;

  function automatic void tb_seed(input int unsigned seed);
    tb_rng_state = {32'(seed) ^ 32'hA5A5_5A5A, 32'(seed) * 32'h9E37_79B1 + 32'h7F4A_7C15};
    if (tb_rng_state == 64'h0) tb_rng_state = 64'h1;
  endfunction

  function automatic logic [63:0] tb_rand64();
    logic [63:0] x;
    x = tb_rng_state;
    x = x ^ (x >> 12);
    x = x ^ (x << 25);
    x = x ^ (x >> 27);
    tb_rng_state = x;
    return x * 64'h2545_F491_4F6C_DD1D;
  endfunction

  function automatic logic [31:0] tb_rand32();
    logic [63:0] r;
    r = tb_rand64();
    return r[63:32];
  endfunction

  // Uniform value in [0, n).  n == 0 returns 0.
  function automatic int unsigned tb_below(input int unsigned n);
    logic [31:0] r;
    if (n == 0) return 0;
    r = tb_rand32();
    return int'(r % n);
  endfunction

  // Uniform value in [lo, hi] (inclusive).
  function automatic int unsigned tb_range(input int unsigned lo, input int unsigned hi);
    if (hi < lo) begin
      $display("TB_ERROR: tb_range(%0d, %0d): inverted range", lo, hi);
      tb_errors++;
      return lo;
    end
    return lo + tb_below(hi - lo + 1);
  endfunction

  // True with probability pct / 100.
  function automatic logic tb_pct(input int unsigned pct);
    return tb_below(100) < pct;
  endfunction

  function automatic logic [127:0] tb_rand128();
    return {tb_rand64(), tb_rand64()};
  endfunction

  // ---------------------------------------------------------------------------
  // Byte pattern of untouched HOST memory: a function of the address only.
  // ---------------------------------------------------------------------------
  function automatic logic [7:0] hb_pat(input longint unsigned addr);
    logic [63:0] x;
    x = addr * 64'h9E37_79B9_7F4A_7C15;
    x = x ^ (x >> 29);
    x = x * 64'hBF58_476D_1CE4_E5B9;
    x = x ^ (x >> 32);
    return x[7:0];
  endfunction

  // ---------------------------------------------------------------------------
  // Checks and coverage
  // ---------------------------------------------------------------------------
  function automatic void tb_note_failure(input string msg);
    tb_errors++;
    if (tb_errors <= 25) $display("TB_ERROR @%0t: %s", $time, msg);
    if (!tb_failfast_checked) begin
      tb_failfast_checked = 1'b1;
      tb_failfast = $test$plusargs("hb_failfast");
    end
    if (tb_failfast) begin
      $display("HB_TB_RESULT failfast FAIL checks=%0d errors=%0d", tb_checks, tb_errors);
      $finish;
    end
  endfunction

  function automatic void tb_check(input logic cond, input string msg);
    tb_checks++;
    if (!cond) tb_note_failure(msg);
  endfunction

  function automatic void tb_fail(input string msg);
    tb_checks++;
    tb_note_failure(msg);
  endfunction

  function automatic void tb_cov(input string bin_name);
    if (tb_cov_cnt.exists(bin_name)) tb_cov_cnt[bin_name]++;
    else                             tb_cov_cnt[bin_name] = 1;
  endfunction

  // Declare a bin with zero hits so an un-hit bin is reported rather than silently absent.
  function automatic void tb_cov_declare(input string bin_name);
    if (!tb_cov_cnt.exists(bin_name)) tb_cov_cnt[bin_name] = 0;
  endfunction

  function automatic int unsigned tb_cov_get(input string bin_name);
    if (tb_cov_cnt.exists(bin_name)) return tb_cov_cnt[bin_name];
    return 0;
  endfunction

  function automatic void tb_report(input string tb_name);
    string key;
    if (tb_cov_cnt.first(key)) begin
      do begin
        $display("COV %s %s %0d", tb_name, key, tb_cov_cnt[key]);
      end while (tb_cov_cnt.next(key));
    end
    if (tb_errors == 0 && tb_checks > 0)
      $display("HB_TB_RESULT %s PASS checks=%0d errors=%0d", tb_name, tb_checks, tb_errors);
    else
      $display("HB_TB_RESULT %s FAIL checks=%0d errors=%0d", tb_name, tb_checks, tb_errors);
  endfunction

endpackage

`default_nettype wire
