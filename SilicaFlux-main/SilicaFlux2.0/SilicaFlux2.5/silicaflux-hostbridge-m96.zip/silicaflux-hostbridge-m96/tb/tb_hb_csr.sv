// =============================================================================
//  tb_hb_csr.sv  --  unit test of sf_albion_host_csr driven directly over ALP
// -----------------------------------------------------------------------------
//  The host path always supplies the privileged attribute of its aperture, so the rights of the register block can only be
//  exercised completely at the ALP level: every domain x privilege combination against every register class.
//  The ALP link checker watches the link.
// =============================================================================
`default_nettype none

module tb_hb_csr;
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  always #5 clk = ~clk;

  logic              req_valid = 1'b0, req_ready, rsp_valid, rsp_ready = 1'b1;
  sf_albion_pkg::sf_req_t req;
  sf_albion_pkg::sf_rsp_t rsp;
  logic              cancel_o, grd_we, grd_rd, grd_wr, grd_valid, dma_dir, dma_posted, dma_start;
  logic [2:0]        grd_idx;
  logic [63:0]       grd_base, grd_limit, dma_src, dma_dst;
  logic [7:0]        grd_dom;
  logic [31:0]       dma_len;
  logic              evt_valid = 1'b0;
  logic [1:0]        evt_src = 2'd0;
  logic [3:0]        evt_code = 4'd0;
  logic [7:0]        evt_tag = 8'd0;
  logic [63:0]       evt_addr = 64'd0;
  logic              evt_ready;

  sf_albion_host_csr #(.NUM_WIN(8), .NUM_TAGS(8), .MAX_OUT(8), .GUARD_EN(1'b1)) u_csr (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(req_valid), .req_ready_o(req_ready), .req_i(req),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_o(rsp),
    .host_busy_i(1'b1), .dma_busy_i(1'b0), .fatal_i(1'b0), .host_outstanding_i(16'd3), .dma_outstanding_i(16'd2),
    .unexpected_cpl_i(16'd7),
    .evt_valid_i(evt_valid), .evt_ready_o(evt_ready), .evt_src_i(evt_src), .evt_code_i(evt_code), .evt_tag_i(evt_tag), .evt_addr_i(evt_addr),
    .cancel_o(cancel_o),
    .grd_cfg_we_o(grd_we), .grd_cfg_idx_o(grd_idx), .grd_cfg_base_o(grd_base), .grd_cfg_limit_o(grd_limit),
    .grd_cfg_dom_o(grd_dom), .grd_cfg_rd_o(grd_rd), .grd_cfg_wr_o(grd_wr), .grd_cfg_valid_o(grd_valid),
    .dma_src_o(dma_src), .dma_dst_o(dma_dst), .dma_len_o(dma_len), .dma_dir_o(dma_dir), .dma_posted_o(dma_posted),
    .dma_start_o(dma_start), .dma_busy_eng_i(1'b0), .dma_done_i(1'b1), .dma_status_i(4'd0), .dma_bytes_i(32'd1234)
  );

  logic [15:0] outst;
  sf_albion_link_checker #(.MAX_OUTSTANDING(8)) u_chk (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(req_valid), .req_ready_i(req_ready), .req_i(req),
    .rsp_valid_i(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_i(rsp), .waive_req_i(1'b0), .outstanding_o(outst)
  );

  // pulses counted on the controls
  int n_cancel = 0, n_start = 0, n_gwe = 0;
  always @(posedge clk) if (rst_n) begin
    if (cancel_o) n_cancel++;
    if (dma_start) n_start++;
    if (grd_we) n_gwe++;
  end

  byte unsigned tg = 0;

  //  One ALP transfer, one at a time.  op 1 = read, 2 = write.
  task automatic xfer(input int op, input longint unsigned addr, input bit [15:0] be, input bit [127:0] data,
                      input bit [7:0] dom, input bit priv, output bit [3:0] status, output bit [127:0] rdata);
    sf_albion_pkg::sf_req_t r;
    tg++;
    r = '0;
    r.op = 4'(op); r.tag = tg; r.dom = dom; r.attr = priv ? 8'h06 : 8'h02; r.addr = addr; r.be = be; r.data = data;
    @(negedge clk);
    req <= r; req_valid <= 1'b1;
    do @(posedge clk); while (!req_ready);
    @(negedge clk);
    req_valid <= 1'b0;
    while (!rsp_valid) @(negedge clk);
    status = rsp.status; rdata = rsp.data;
    tb_check(rsp.tag == tg, "response tag");
    tb_check(rsp.meta.is_write == (op == 2), "response operation flag");
    if (rsp.status != 0) tb_check(rsp.data == '0, "error response carries data");
    @(negedge clk);
  endtask

  task automatic wr32(input longint unsigned off, input bit [31:0] v, input bit [7:0] dom, input bit priv, input int exp_st);
    bit [3:0] st; bit [127:0] rd;
    xfer(2, {off[63:4], 4'h0}, 16'hF << (4 * off[3:2]), {96'h0, v} << (32 * off[3:2]), dom, priv, st, rd);
    tb_check(st == 4'(exp_st), $sformatf("write %h dom=%h priv=%0b: status %0d expected %0d", off, dom, priv, st, exp_st));
  endtask

  task automatic rd32(input longint unsigned off, input bit [7:0] dom, input bit priv, input int exp_st, input bit [31:0] exp_v);
    bit [3:0] st; bit [127:0] rd; bit [31:0] v;
    xfer(1, {off[63:4], 4'h0}, 16'hF << (4 * off[3:2]), '0, dom, priv, st, rd);
    v = rd >> (32 * off[3:2]);
    tb_check(st == 4'(exp_st), $sformatf("read %h dom=%h priv=%0b: status %0d expected %0d", off, dom, priv, st, exp_st));
    if (exp_st == 0 && exp_v !== 32'hxxxx_xxxx) tb_check(v == exp_v, $sformatf("read %h: %h expected %h", off, v, exp_v));
    if (exp_st == 0) tb_check((rd & ~(128'hFFFF_FFFF << (32 * off[3:2]))) == '0, "lanes outside the byte enables must be zero");
  endtask

  initial begin
    bit [7:0] doms [4] = '{8'h00, 8'h01, 8'h02, 8'h10};
    bit [3:0] st; bit [127:0] rd;
    tb_seed(32'd909);
    #1 rst_n = 1'b0;
    repeat (4) @(negedge clk);
    rst_n <= 1'b1;
    repeat (3) @(negedge clk);

    // ---- ID, version, capabilities, status are readable by every domain and privilege
    foreach (doms[i]) for (int p = 0; p < 2; p++) begin
      rd32(64'h000, doms[i], p[0], 0, 32'h4842_0096);
      rd32(64'h004, doms[i], p[0], 0, 32'h0000_0100);
      rd32(64'h008, doms[i], p[0], 0, 32'h0808_8000);
      rd32(64'h014, doms[i], p[0], 0, 32'h0000_0001);      // {engine busy 0, fatal 0, dma busy 0, host busy 1}
    end
    // ---- scratch: any domain, any privilege
    foreach (doms[i]) for (int p = 0; p < 2; p++) begin
      wr32(64'h00C, 32'hA5A5_0000 + i * 16 + p, doms[i], p[0], 0);
      rd32(64'h00C, doms[i], p[0], 0, 32'hA5A5_0000 + i * 16 + p);
    end
    // ---- read-only registers: nobody may write them
    foreach (doms[i]) for (int p = 0; p < 2; p++) begin
      wr32(64'h000, 32'h1, doms[i], p[0], 2);
      wr32(64'h014, 32'h1, doms[i], p[0], 2);
      wr32(64'h058, 32'h1, doms[i], p[0], 2);
    end
    // ---- privileged registers: only ROOT/MGMT WITH the privileged attribute
    foreach (doms[i]) for (int p = 0; p < 2; p++) begin
      bit allowed;
      int c0;
      allowed = (doms[i] <= 8'h01) && p[0];
      wr32(64'h050, 32'h40 + i, doms[i], p[0], allowed ? 0 : 2);                     // DMA_LEN
      if (allowed) rd32(64'h050, doms[i], p[0], 0, 32'h40 + i);
      c0 = n_cancel;
      wr32(64'h010, 32'h1, doms[i], p[0], allowed ? 0 : 2);                          // CONTROL: cancel
      repeat (3) @(negedge clk);
      tb_check((n_cancel - c0) == (allowed ? 1 : 0), $sformatf("cancel pulses %0d for dom=%h priv=%0b", n_cancel - c0, doms[i], p[0]));
      rd32(64'h110, doms[i], p[0], allowed ? 0 : 2, 32'hxxxx_xxxx);                  // guard window 0 ATTR: privileged read
    end
    // ---- a word that mixes a privileged and a read-only register: denied as a whole, nothing changes
    xfer(2, 64'h040, 16'hFFFF, {32'h4, 32'h3, 32'h2, 32'h1}, 8'h10, 1'b1, st, rd);
    tb_check(st == 4'd2, "mixed word by an unprivileged domain must be denied");
    // ---- illegal requests: legality status takes precedence
    //  (ALP-LEG-01 precedence: opcode, alignment, byte enable, attributes, domain)
    xfer(2, 64'h000, 16'h0000, '0, 8'h00, 1'b1, st, rd);  tb_check(st == 4'd4, "BE == 0 -> BAD_BE");
    xfer(2, 64'h00D, 16'h0F00, '0, 8'h00, 1'b1, st, rd);  tb_check(st == 4'd5, "unaligned -> ALIGN_ERR");
    xfer(2, 64'h00D, 16'h0000, '0, 8'h00, 1'b1, st, rd);  tb_check(st == 4'd5, "alignment has precedence over BE == 0");
    xfer(2, 64'h000, 16'hF000, '0, 8'hFF, 1'b1, st, rd);  tb_check(st == 4'd2, "domain 0xFF -> ACCESS_DENIED");
    xfer(5, 64'h000, 16'hF000, '0, 8'h00, 1'b1, st, rd);  tb_check(st == 4'd3, "reserved opcode -> BAD_OPCODE");
    xfer(1, 64'h200, 16'hFFFF, '0, 8'h00, 1'b1, st, rd);  tb_check(st == 4'd1, "beyond the register space -> DECODE_ERR");
    // ---- byte lanes of a register
    wr32(64'h00C, 32'hFFFF_FFFF, 8'h00, 1'b1, 0);
    xfer(2, 64'h000, 16'h2000, 128'h5A << (8 * 13), 8'h10, 1'b0, st, rd);                // lane 13 only: a byte of SCRATCH
    tb_check(st == 4'd0, "a one-byte write to SCRATCH must be allowed");
    rd32(64'h00C, 8'h10, 1'b0, 0, 32'hFFFF_5AFF);
    xfer(2, 64'h000, 16'h0002, 128'h77 << 8, 8'h10, 1'b0, st, rd);                       // lane 1 is in the read-only ID register
    tb_check(st == 4'd2, "a one-byte write into the read-only ID register must be denied");
    rd32(64'h000, 8'h10, 1'b0, 0, 32'h4842_0096);
    // ---- guard window commit: all five registers through the ALP interface
    begin
      int g0;
      g0 = n_gwe;
      wr32(64'h100 + 3 * 32 + 0,  32'h1000_0000, 8'h00, 1'b1, 0);
      wr32(64'h100 + 3 * 32 + 4,  32'h0000_0001, 8'h00, 1'b1, 0);
      wr32(64'h100 + 3 * 32 + 8,  32'h1000_07FF, 8'h00, 1'b1, 0);
      wr32(64'h100 + 3 * 32 + 12, 32'h0000_0001, 8'h00, 1'b1, 0);
      tb_check(n_gwe == g0, "guard window committed before its ATTR write");
      wr32(64'h100 + 3 * 32 + 16, 32'h0000_1507, 8'h00, 1'b1, 0);
      repeat (3) @(negedge clk);
      tb_check(n_gwe == g0 + 1, "guard window not committed by the ATTR write");
      tb_check(grd_idx == 3'd3 && grd_base == 64'h1_1000_0000 && grd_limit == 64'h1_1000_07FF && grd_dom == 8'h15 && grd_rd && grd_wr && grd_valid,
               $sformatf("guard cfg outputs wrong: idx=%0d base=%h limit=%h dom=%h rd=%0b wr=%0b v=%0b", grd_idx, grd_base, grd_limit, grd_dom, grd_rd, grd_wr, grd_valid));
      wr32(64'h100 + 3 * 32 + 16, 32'h0000_1500, 8'h01, 1'b1, 0);                       // MGMT may revoke
      repeat (3) @(negedge clk);
      tb_check(!grd_valid, "revocation did not reach the guard");
      wr32(64'h100 + 3 * 32 + 16, 32'h0000_1507, 8'h10, 1'b1, 2);                       // a tenant may not
      wr32(64'h100 + 3 * 32 + 16, 32'h0000_1507, 8'h00, 1'b0, 2);                       // ROOT without the privileged attribute may not
    end
    // ---- DMA registers drive the engine, the start bit pulses once
    begin
      int s0;
      s0 = n_start;
      wr32(64'h040, 32'hAAAA_0001, 8'h00, 1'b1, 0); wr32(64'h044, 32'h2, 8'h00, 1'b1, 0);
      wr32(64'h048, 32'hBBBB_0002, 8'h00, 1'b1, 0); wr32(64'h04C, 32'h3, 8'h00, 1'b1, 0);
      wr32(64'h050, 32'h100, 8'h00, 1'b1, 0);
      wr32(64'h054, 32'h0000_0007, 8'h00, 1'b1, 0);
      repeat (4) @(negedge clk);
      tb_check(n_start == s0 + 1, "start must pulse exactly once");
      tb_check(dma_src == 64'h2_AAAA_0001 && dma_dst == 64'h3_BBBB_0002 && dma_len == 32'h100 && dma_dir && dma_posted, "DMA register outputs");
      rd32(64'h058, 8'h10, 1'b0, 0, 32'h0000_0002);                                     // done, status OK, not busy
      rd32(64'h05C, 8'h10, 1'b0, 0, 32'd1234);
      rd32(64'h018, 8'h10, 1'b0, 0, 32'd3);
      rd32(64'h01C, 8'h10, 1'b0, 0, 32'd2);
      rd32(64'h030, 8'h10, 1'b0, 0, 32'd7);
    end
    // ---- error log: counts every event, keeps the FIRST until cleared
    @(negedge clk); evt_valid <= 1'b1; evt_src <= 2'd1; evt_code <= 4'd3; evt_tag <= 8'h2A; evt_addr <= 64'hDEAD_BEEF_0000_1234;
    @(negedge clk); evt_code <= 4'd1; evt_tag <= 8'd9; evt_addr <= 64'h77;
    @(negedge clk); evt_valid <= 1'b0;
    repeat (2) @(negedge clk);
    rd32(64'h020, 8'h10, 1'b0, 0, 32'd2);
    rd32(64'h024, 8'h10, 1'b0, 0, {18'h0, 2'd1, 4'd3, 8'h2A});
    rd32(64'h028, 8'h10, 1'b0, 0, 32'h0000_1234);
    rd32(64'h02C, 8'h10, 1'b0, 0, 32'hDEAD_BEEF);
    wr32(64'h010, 32'h2, 8'h00, 1'b1, 0);                                               // clear
    rd32(64'h020, 8'h10, 1'b0, 0, 32'd0);
    rd32(64'h024, 8'h10, 1'b0, 0, 32'd0);

    tb_report("tb_hb_csr");
    $finish;
  end
  initial begin #5000000; tb_fail("csr: timeout"); tb_report("tb_hb_csr"); $finish; end
endmodule

`default_nettype wire
