// =============================================================================
//  sf_hti_host_bfm.sv  --  HostBridge host bus-functional model (never synthesized)
// -----------------------------------------------------------------------------
//  Plays the HOST on the four HTI channels of sf_albion_host_bridge:
//
//    REQUESTER   drives hreq / hw (MMIO and host memory requests), receives hcpl, checks every
//                completion against a reference model of device memory and against the order and
//                shape rules of HTI (tag, beat count, status on the last beat, zero data on error).
//    COMPLETER   plays host MEMORY: receives dreq / dw (DMA requests of the device), applies writes
//                with their byte strobes, answers reads and non-posted writes on dcpl with a
//                configurable latency, beat-level interleaving across tags (out-of-order across
//                tags, in order within a tag), error windows and rogue (unsolicited) beats.
//    CHECKER     passive rules on what the BRIDGE drives: valid / payload stability, tag uniqueness,
//                chunk length and boundary limits, write data ownership and strobes inside the span.
//
//  House rules (same as the AlbionCore suite): every DUT-facing output changes on the falling clock
//  edge through a non-blocking assignment; everything that observes the DUT runs on the rising edge.
//  Test code talks to the model by calling the tasks below hierarchically (post_rd, post_wr, ...).
// =============================================================================
`default_nettype none

module sf_hti_host_bfm #(
  parameter int NUM_TAGS_MAX = 8,       // dreq tags must be below this
  parameter int MPS          = 256,     // write chunk limit the bridge must obey
  parameter int MRRS         = 256      // read chunk limit the bridge must obey
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         cancel_i,      // probe of the cancel pin: used to check that nothing accepted AFTER a cancel is aborted
  // ---- requester: host -> device ------------------------------------------------------------
  output logic              hreq_valid,
  input  wire logic         hreq_ready,
  output logic [1:0]        hreq_kind,
  output logic [63:0]       hreq_addr,
  output logic [12:0]       hreq_len,
  output logic [7:0]        hreq_tag,
  output logic [7:0]        hreq_dom,
  output logic              hw_valid,
  input  wire logic         hw_ready,
  output logic [127:0]      hw_data,
  output logic [15:0]       hw_be,
  output logic              hw_last,
  input  wire logic         hcpl_valid,
  output logic              hcpl_ready,
  input  wire logic [7:0]   hcpl_tag,
  input  wire logic [3:0]   hcpl_status,
  input  wire logic [127:0] hcpl_data,
  input  wire logic         hcpl_last,
  // ---- completer: device -> host --------------------------------------------------------------
  input  wire logic         dreq_valid,
  output logic              dreq_ready,
  input  wire logic [1:0]   dreq_kind,
  input  wire logic [63:0]  dreq_addr,
  input  wire logic [12:0]  dreq_len,
  input  wire logic [7:0]   dreq_tag,
  input  wire logic         dw_valid,
  output logic              dw_ready,
  input  wire logic [127:0] dw_data,
  input  wire logic [15:0]  dw_be,
  input  wire logic         dw_last,
  output logic              dcpl_valid,
  input  wire logic         dcpl_ready,
  output logic [7:0]        dcpl_tag,
  output logic [3:0]        dcpl_status,
  output logic [127:0]      dcpl_data,
  output logic              dcpl_last
);
  import sf_hb_tb_pkg::*;

  // ---------------------------------------------------------------------------
  // Configuration knobs (set hierarchically by the test)
  // ---------------------------------------------------------------------------
  int cfg_req_gap      = 0;    // % chance to idle a cycle before presenting the next hreq
  int cfg_hw_gap       = 0;    // % chance to idle a cycle before presenting the next hw beat
  int cfg_cpl_rdy      = 100;  // % chance hcpl_ready is high in a cycle
  int cfg_data_first   = 0;    // 1: write data may be presented before its request is accepted
  int cfg_dirty_lanes  = 1;    // 1: garbage data AND strobes outside the request span (the bridge must mask)
  int cfg_dreq_rdy     = 100;  // % chance dreq_ready is high in a cycle
  int cfg_dw_rdy       = 100;  // % chance dw_ready is high in a cycle
  int cfg_lat_min      = 2;    // completion latency in cycles after the request was accepted
  int cfg_lat_max      = 6;
  int cfg_beat_gap     = 0;    // % chance to skip a dcpl beat slot
  int cfg_ooo_pct      = 0;    // % chance a beat is taken from a random ready stream instead of the oldest
  int cfg_check_order  = 1;    // 1: hcpl completions must return in request order
  int cfg_chk_dreq     = 1;    // 1: enforce the chunk rules on dreq (off for deliberately broken DUT tests)

  // ---------------------------------------------------------------------------
  // Requester state
  // ---------------------------------------------------------------------------
  typedef struct {
    bit               is_wr;
    bit               posted;
    bit [1:0]         kind;
    longint unsigned  addr;
    int               len;
    bit [7:0]         tag;
    bit [7:0]         dom;
    int               exp_status;
    longint unsigned  rid;
    int               nbeats;       // write data beats
    bit               chk;          // compare read data with the reference model
    bit               expect_cpl;
  } rq_t;

  typedef struct {
    longint unsigned  rid;
    longint unsigned  addr;
    int               len;
    int               nbeats;
    int               beat;
    bit               eligible;
  } wj_t;

  rq_t rq_q [$];            // requests waiting to be driven on hreq
  rq_t ex_q [$];            // requests whose completion is expected (in order)
  wj_t wj_q [$];            // write-data jobs
  byte unsigned dref   [longint unsigned];   // reference model of DEVICE memory behind the host apertures (byte addr)
  byte unsigned pay    [longint unsigned];   // write payload bytes, key = rid*8192 + index
  bit           pstb   [longint unsigned];   // write payload strobes
  byte unsigned expd   [longint unsigned];   // expected read bytes, key = rid*8192 + index
  longint unsigned next_rid = 1;
  longint unsigned acc_cyc [longint unsigned];     // rid -> cycle at which hreq accepted the request
  longint unsigned cancel_edges [$];               // cycles at which cancel_i was sampled high
  longint unsigned cyc_req = 0;                    // free-running cycle counter of the requester side
  bit           use_val = 1'b0;                 // post_wr_val: payload bytes come from val_override
  bit [127:0]   val_override = '0;
  bit           hreq_busy = 1'b0, hw_busy = 1'b0;
  bit           hreq_acc_f = 1'b0, hw_acc_f = 1'b0;
  longint unsigned cur_rid;
  int           cb_idx = 0;                 // beat index inside the completion being received
  int           n_posted = 0, n_cpl_ok = 0, n_cpl_err = 0, n_reqs = 0;
  int           outstanding_cpl = 0;
  bit [127:0]   last_cpl_data   [int];      // by tag: first data beat of the latest completion
  bit [3:0]     last_cpl_status [int];
  int           cpl_count_by_tag [int];

  // ---------------------------------------------------------------------------
  // Completer (host memory) state
  // ---------------------------------------------------------------------------
  byte unsigned hmem [longint unsigned];

  typedef struct {
    bit [1:0]        kind;
    longint unsigned addr;
    int              len;
    bit [7:0]        tag;
    int              nbeats;
    int              got;
    bit              fail;
    bit [3:0]        fail_status;
    bit              silent;
  } wp_t;

  typedef struct {
    bit [7:0]        tag;
    int              nbeats;
    int              sent;
    longint unsigned ready_cyc;
    longint unsigned csid;
    bit              is_ack;
    bit              fail;
    bit [3:0]        fail_status;
    int              fail_after;    // data beats sent before the error beat
  } cs_t;

  typedef struct {
    longint unsigned lo, hi;
    bit [3:0]        status;
    bit              on_read, on_write;
    int              after;
    bit              silent;
    bit              used;
  } ew_t;

  typedef struct {
    bit [7:0] tag; bit [3:0] status; bit [127:0] data; bit last;
  } raw_t;

  wp_t   wp_q [$];                  // writes accepted on dreq, still collecting dw beats
  cs_t   cs_q [$];                  // completion streams
  raw_t  raw_q [$];                 // rogue beats to inject
  ew_t   ew [4];
  bit [127:0] csd [longint unsigned];   // stream data beats, key = csid*4096 + beat
  longint unsigned next_csid = 1;
  longint unsigned cyc = 0;
  bit    tag_out [int];             // tags outstanding at the bridge (dreq tags of RD / WR)
  int    n_tag_out = 0;
  int    n_dreq = 0, n_dw_beats = 0, n_ooo_switches = 0, n_dreq_rd = 0, n_dreq_wr = 0, n_dreq_wrp = 0;
  int    max_tags_seen = 0;
  bit    dreq_busy_prev = 1'b0, dw_busy_prev = 1'b0;
  bit [1:0]  dreq_kind_prev; bit [63:0] dreq_addr_prev; bit [12:0] dreq_len_prev; bit [7:0] dreq_tag_prev;
  bit [127:0] dw_data_prev; bit [15:0] dw_be_prev; bit dw_last_prev;
  int    last_stream = -1;

  initial begin
    for (int i = 0; i < 4; i++) ew[i].used = 1'b0;
  end

  // ===========================================================================
  // Helpers
  // ===========================================================================
  function automatic int nwords_of(input longint unsigned addr, input int len);
    return (int'(addr[3:0]) + len + 15) / 16;
  endfunction

  //  exp_status 255 = "either": the request may legally end OK or ABORTED (a cancel raced with it)
  function automatic bit st_match(input int exp_st, input bit [3:0] got);
    if (exp_st == 255) return (got == 4'd0) || (got == 4'd7);
    return got == 4'(exp_st);
  endfunction

  task automatic reset_model();
    dref.delete(); hmem.delete();
  endtask

  function automatic byte unsigned hm_peek(input longint unsigned a);
    if (hmem.exists(a)) return hmem[a];
    return hb_pat(a);
  endfunction

  task automatic hm_poke(input longint unsigned a, input byte unsigned b);
    hmem[a] = b;
  endtask

  function automatic byte unsigned dref_peek(input longint unsigned a);
    if (dref.exists(a)) return dref[a];
    return 8'h00;
  endfunction

  task automatic set_error_window(input int idx, input longint unsigned lo, input longint unsigned hi,
                                  input bit [3:0] status, input bit on_read, input bit on_write,
                                  input int after, input bit silent);
    ew[idx].lo = lo; ew[idx].hi = hi; ew[idx].status = status;
    ew[idx].on_read = on_read; ew[idx].on_write = on_write; ew[idx].after = after;
    ew[idx].silent = silent; ew[idx].used = 1'b1;
  endtask

  task automatic clear_error_windows();
    for (int i = 0; i < 4; i++) ew[i].used = 1'b0;
  endtask

  // ===========================================================================
  // REQUESTER API
  // ===========================================================================
  //  Common poster.  chk = maintain / compare the reference model (SRAM style memory).
  task automatic post_any(input bit [1:0] kind, input bit [7:0] tag, input longint unsigned addr,
                          input int len, input bit [7:0] dom, input int exp_status,
                          input bit chk, input int strobe_mode, input int nbeats_override);
    rq_t r;
    wj_t j;
    int  nb;
    bit  is_wr, posted;
    longint unsigned a;
    is_wr  = (kind == 2'd2) || (kind == 2'd3);
    posted = (kind == 2'd3);
    r.is_wr = is_wr; r.posted = posted; r.kind = kind; r.addr = addr; r.len = len; r.tag = tag; r.dom = dom;
    r.exp_status = exp_status; r.rid = next_rid; r.chk = chk;
    r.expect_cpl = !posted;
    nb = is_wr ? ((nbeats_override >= 0) ? nbeats_override : nwords_of(addr, len)) : 0;
    if (len == 0 && nbeats_override < 0) nb = 0;
    r.nbeats = nb;
    if (is_wr && nb > 0) begin
      // payload, strobes
      for (int i = 0; i < len; i++) begin
        pay [r.rid*8192 + i] = use_val ? val_override[8*(i % 16) +: 8] : byte'(tb_rand32());
        pstb[r.rid*8192 + i] = (strobe_mode == 0) ? 1'b1 : !tb_pct(25);
      end
      if (exp_status == 0 && chk) begin
        for (int i = 0; i < len; i++) begin
          if (pstb[r.rid*8192 + i]) dref[addr + i] = pay[r.rid*8192 + i];
        end
      end
      j.rid = r.rid; j.addr = addr; j.len = len; j.nbeats = nb; j.beat = 0; j.eligible = (cfg_data_first != 0);
      wj_q.push_back(j);
    end
    if (!is_wr && chk) begin
      for (int i = 0; i < len; i++) begin
        a = addr + i;
        expd[r.rid*8192 + i] = dref_peek(a);
      end
    end
    next_rid++;
    rq_q.push_back(r);
    if (r.expect_cpl) begin
      ex_q.push_back(r);
      outstanding_cpl++;
    end else begin
      n_posted++;
    end
    n_reqs++;
  endtask

  task automatic post_rd(input bit [7:0] tag, input longint unsigned addr, input int len,
                         input bit [7:0] dom, input int exp_status, input bit chk);
    post_any(2'd1, tag, addr, len, dom, exp_status, chk, 0, -1);
  endtask

  //  A write whose payload bytes are given: byte i of the request = val[8*i +: 8] (len <= 16).
  task automatic post_wr_val(input bit [7:0] tag, input longint unsigned addr, input int len, input bit [7:0] dom,
                             input bit posted, input int exp_status, input bit [127:0] val);
    use_val = 1'b1; val_override = val;
    post_any(posted ? 2'd3 : 2'd2, tag, addr, len, dom, exp_status, 1'b0, 0, -1);
    use_val = 1'b0;
  endtask

  task automatic post_wr(input bit [7:0] tag, input longint unsigned addr, input int len,
                         input bit [7:0] dom, input bit posted, input int exp_status, input bit chk,
                         input int strobe_mode);
    post_any(posted ? 2'd3 : 2'd2, tag, addr, len, dom, exp_status, chk, strobe_mode, -1);
  endtask

  //  A request completed OK has fully executed; tests wait for this before reading results.
  function automatic bit req_idle();
    return (rq_q.size() == 0) && (wj_q.size() == 0) && !hreq_busy && !hw_busy && (outstanding_cpl == 0);
  endfunction

  task automatic wait_req_idle(input int timeout_cycles);
    int t;
    t = 0;
    while (!req_idle() && t < timeout_cycles) begin
      @(negedge clk);
      t++;
    end
    tb_check(req_idle(), "wait_req_idle: host requests did not drain (timeout)");
  endtask

  // ===========================================================================
  // REQUESTER drivers (falling edge)
  // ===========================================================================
  always @(posedge clk) begin
    cyc_req++;
    if (rst_n && cancel_i) cancel_edges.push_back(cyc_req);
    if (rst_n && hreq_valid && hreq_ready) begin hreq_acc_f = 1'b1; acc_cyc[cur_rid] = cyc_req; end
    if (rst_n && hw_valid && hw_ready)     hw_acc_f   = 1'b1;
  end

  always @(negedge clk) begin
    rq_t r;
    wj_t j;
    logic [127:0] d;
    logic [15:0]  b;
    longint unsigned wa, idx;
    longint unsigned base;
    if (!rst_n) begin
      hreq_valid <= 1'b0; hw_valid <= 1'b0; hcpl_ready <= 1'b0;
      hreq_kind <= '0; hreq_addr <= '0; hreq_len <= '0; hreq_tag <= '0; hreq_dom <= '0;
      hw_data <= '0; hw_be <= '0; hw_last <= 1'b0;
      hreq_busy = 1'b0; hw_busy = 1'b0; hreq_acc_f = 1'b0; hw_acc_f = 1'b0;
      rq_q.delete(); ex_q.delete(); wj_q.delete(); outstanding_cpl = 0; cb_idx = 0;
    end else begin
      // ---- request channel
      if (hreq_busy && hreq_acc_f) begin
        hreq_busy = 1'b0; hreq_acc_f = 1'b0;
        // data may follow once its request has been accepted
        for (int i = 0; i < wj_q.size(); i++) if (wj_q[i].rid == cur_rid) wj_q[i].eligible = 1'b1;
      end
      if (!hreq_busy) begin
        if (rq_q.size() > 0 && !tb_pct(cfg_req_gap)) begin
          r = rq_q.pop_front();
          cur_rid = r.rid;
          hreq_busy = 1'b1;
          hreq_valid <= 1'b1; hreq_kind <= r.kind; hreq_addr <= r.addr; hreq_len <= 13'(r.len);
          hreq_tag <= r.tag; hreq_dom <= r.dom;
        end else begin
          hreq_valid <= 1'b0;
        end
      end
      // ---- write-data channel
      if (hw_busy && hw_acc_f) begin
        hw_busy = 1'b0; hw_acc_f = 1'b0;
        wj_q[0].beat++;
        if (wj_q[0].beat == wj_q[0].nbeats) begin
          wj_q.pop_front();
        end
      end
      if (!hw_busy) begin
        if (wj_q.size() > 0 && wj_q[0].eligible && !tb_pct(cfg_hw_gap)) begin
          j = wj_q[0];
          base = {j.addr[63:4], 4'h0} + 16 * j.beat;
          d = '0; b = '0;
          for (int l = 0; l < 16; l++) begin
            wa = base + l;
            if (wa >= j.addr && (wa - j.addr) < 64'(j.len)) begin
              idx = wa - j.addr;
              d[l*8 +: 8] = pay [j.rid*8192 + idx];
              b[l]        = pstb[j.rid*8192 + idx];
            end else if (cfg_dirty_lanes != 0) begin
              d[l*8 +: 8] = byte'(tb_rand32());
              b[l]        = tb_pct(50);
            end
          end
          hw_busy = 1'b1;
          hw_valid <= 1'b1; hw_data <= d; hw_be <= b; hw_last <= (j.beat == j.nbeats - 1);
        end else begin
          hw_valid <= 1'b0;
        end
      end
      hcpl_ready <= tb_pct(cfg_cpl_rdy);
    end
  end

  // ===========================================================================
  // REQUESTER completion monitor (rising edge)
  // ===========================================================================
  always @(posedge clk) begin
    rq_t h;
    int  nw;
    bit  exp_last;
    logic [127:0] exp_d;
    longint unsigned wa, idx, base;
    if (rst_n && hcpl_valid && hcpl_ready) begin
      if (ex_q.size() == 0) begin
        tb_fail($sformatf("hcpl beat with nothing outstanding (tag=%0d status=%0d)", hcpl_tag, hcpl_status));
      end else begin
        h = ex_q[0];
        if (cfg_check_order != 0)
          tb_check(hcpl_tag == h.tag, $sformatf("hcpl tag %0d but oldest request has tag %0d (order)", hcpl_tag, h.tag));
        nw = nwords_of(h.addr, h.len);
        if (h.is_wr) begin
          tb_check(hcpl_last, "write completion must be a single beat");
          tb_check(st_match(h.exp_status, hcpl_status),
                   $sformatf("write completion status %0d, expected %0d (tag %0d)", hcpl_status, h.exp_status, h.tag));
          tb_check(hcpl_data == '0, "write completion data must be zero");
        end else if (h.exp_status != 0 && h.exp_status != 255 && h.exp_status < 16) begin
          tb_check(hcpl_last, "error read completion must be a single, last beat");
          tb_check(hcpl_status == 4'(h.exp_status),
                   $sformatf("read completion status %0d, expected %0d (tag %0d)", hcpl_status, h.exp_status, h.tag));
          tb_check(hcpl_data == '0, "error completion data must be zero");
        end else if (hcpl_status != 4'h0) begin
          // exp OK or either: a failed read ends with ONE terminating beat (earlier beats were OK data)
          tb_check((h.exp_status == 255 && hcpl_status == 4'd7) || (h.exp_status >= 16 && h.exp_status < 255 && hcpl_status == 4'(h.exp_status - 16)),
                   $sformatf("read ended with status %0d, expected %0d (tag %0d)", hcpl_status, h.exp_status, h.tag));
          tb_check(hcpl_last, "error beat of a read must be last");
          tb_check(hcpl_data == '0, "error completion data must be zero");
        end else begin
          exp_last = (cb_idx == nw - 1);
          tb_check(hcpl_last == exp_last,
                   $sformatf("read beat %0d last=%0b expected %0b (nw=%0d tag %0d)", cb_idx, hcpl_last, exp_last, nw, h.tag));
          if (h.chk) begin
            base = {h.addr[63:4], 4'h0} + 16 * cb_idx;
            exp_d = '0;
            for (int l = 0; l < 16; l++) begin
              wa = base + l;
              if (wa >= h.addr && (wa - h.addr) < 64'(h.len)) begin
                idx = wa - h.addr;
                exp_d[l*8 +: 8] = expd[h.rid*8192 + idx];
              end
            end
            tb_check(hcpl_data == exp_d,
                     $sformatf("read data beat %0d tag %0d addr %h: got %h expected %h", cb_idx, h.tag, h.addr, hcpl_data, exp_d));
          end
          if (cb_idx == 0) last_cpl_data[int'(h.tag)] = hcpl_data;
        end
        if (h.is_wr || h.exp_status != 0) last_cpl_data[int'(h.tag)] = hcpl_data;
        last_cpl_status[int'(h.tag)] = hcpl_status;
        // a request accepted AFTER every cancel so far must never end ABORTED (cancel covers requests accepted up to its cycle)
        //   (only for requests posted as "OK or ABORTED": a test that expects ABORTED explicitly, e.g. a fabric CANCELLED status, has asserted it)
        if (hcpl_last && hcpl_status == 4'd7 && h.exp_status == 255) begin
          bit covered;
          covered = 1'b0;
          for (int e = 0; e < cancel_edges.size(); e++) if (cancel_edges[e] + 2 >= acc_cyc[h.rid]) covered = 1'b1;
          tb_check(covered, $sformatf("request tag %0d (accepted at cycle %0d) was ABORTED although no cancel covers it", h.tag, acc_cyc[h.rid]));
          tb_cov("hcpl_aborted");
        end
        cb_idx++;
        if (hcpl_last) begin
          if (!h.is_wr && hcpl_status == 0) tb_check(cb_idx == nw, $sformatf("read completion has %0d beats, expected %0d", cb_idx, nw));
          // a request declared as "OK beats, then error status S" must really end with S
          if (!h.is_wr && h.exp_status >= 16 && h.exp_status < 255)
            tb_check(hcpl_status == 4'(h.exp_status - 16), $sformatf("read (tag %0d) ended with status %0d, the test injected %0d", h.tag, hcpl_status, h.exp_status - 16));
          cb_idx = 0;
          ex_q.pop_front();
          outstanding_cpl--;
          if (hcpl_status == 0) n_cpl_ok++; else n_cpl_err++;
          if (cpl_count_by_tag.exists(int'(h.tag))) cpl_count_by_tag[int'(h.tag)]++; else cpl_count_by_tag[int'(h.tag)] = 1;
          tb_cov($sformatf("hcpl_status_%0d", hcpl_status));
        end
      end
    end
  end

  // ===========================================================================
  // COMPLETER: capture requests and write data (rising edge)
  // ===========================================================================
  function automatic int find_window(input longint unsigned lo, input longint unsigned hi, input bit is_wr);
    for (int i = 0; i < 4; i++) begin
      if (ew[i].used && lo <= ew[i].hi && hi >= ew[i].lo && (is_wr ? ew[i].on_write : ew[i].on_read)) return i;
    end
    return -1;
  endfunction

  always @(posedge clk) begin
    wp_t w;
    cs_t s;
    int  nw, wi, lat;
    longint unsigned hi, a, base;
    logic [127:0] d;
    int lim;
    bit incomplete;
    cyc++;
    if (!rst_n) begin
      wp_q.delete(); cs_q.delete(); raw_q.delete(); tag_out.delete(); n_tag_out = 0;
      dreq_busy_prev = 1'b0; dw_busy_prev = 1'b0;
    end else begin
      // ---- stability of what the bridge drives
      if (dreq_busy_prev) begin
        tb_check(dreq_valid, "dreq valid dropped before it was accepted");
        tb_check(dreq_kind == dreq_kind_prev && dreq_addr == dreq_addr_prev && dreq_len == dreq_len_prev &&
                 dreq_tag == dreq_tag_prev, "dreq payload changed while waiting for ready");
      end
      if (dw_busy_prev) begin
        tb_check(dw_valid, "dw valid dropped before it was accepted");
        tb_check(dw_data == dw_data_prev && dw_be == dw_be_prev && dw_last == dw_last_prev,
                 "dw payload changed while waiting for ready");
      end
      dreq_busy_prev = dreq_valid && !dreq_ready;
      dw_busy_prev   = dw_valid && !dw_ready;
      dreq_kind_prev = dreq_kind; dreq_addr_prev = dreq_addr; dreq_len_prev = dreq_len; dreq_tag_prev = dreq_tag;
      dw_data_prev = dw_data; dw_be_prev = dw_be; dw_last_prev = dw_last;

      // ---- dreq accepted
      if (dreq_valid && dreq_ready) begin
        n_dreq++;
        hi = dreq_addr + dreq_len - 1;
        if (cfg_chk_dreq != 0) begin
          tb_check(dreq_kind != 2'd0, "dreq kind NONE");
          tb_check(dreq_len >= 1, "dreq length zero");
          lim = (dreq_kind == 2'd1) ? MRRS : MPS;
          tb_check(dreq_len <= lim, $sformatf("dreq length %0d exceeds limit %0d", dreq_len, lim));
          tb_check((dreq_addr / lim) == (hi / lim),
                   $sformatf("dreq crosses a %0d-byte boundary: addr=%h len=%0d", lim, dreq_addr, dreq_len));
          tb_check((dreq_addr >> 12) == (hi >> 12), "dreq crosses a 4 KiB boundary");
          tb_check(hi >= dreq_addr, "dreq wraps the address space");
          incomplete = 1'b0;
          for (int i = 0; i < wp_q.size(); i++) if (wp_q[i].got < wp_q[i].nbeats) incomplete = 1'b1;
          tb_check(!incomplete, "dreq presented while the previous write's data is incomplete");
        end
        if (dreq_kind == 2'd1 || dreq_kind == 2'd2) begin
          tb_check(!tag_out.exists(int'(dreq_tag)), $sformatf("dreq reuses outstanding tag %0d", dreq_tag));
          tb_check(int'(dreq_tag) < NUM_TAGS_MAX, $sformatf("dreq tag %0d >= NUM_TAGS %0d", dreq_tag, NUM_TAGS_MAX));
          tag_out[int'(dreq_tag)] = 1'b1;
          n_tag_out++;
          if (n_tag_out > max_tags_seen) max_tags_seen = n_tag_out;
        end
        nw = nwords_of(dreq_addr, dreq_len);
        lat = tb_range(cfg_lat_min, cfg_lat_max);
        wi = find_window(dreq_addr, hi, dreq_kind[1]);
        if (dreq_kind == 2'd1) begin
          n_dreq_rd++;
          s.tag = dreq_tag; s.nbeats = nw; s.sent = 0; s.ready_cyc = cyc + lat; s.csid = next_csid++; s.is_ack = 1'b0;
          s.fail = 1'b0; s.fail_status = 4'h0; s.fail_after = 0;
          base = {dreq_addr[63:4], 4'h0};
          for (int k = 0; k < nw; k++) begin
            d = '0;
            for (int l = 0; l < 16; l++) begin
              a = base + 16*k + l;
              if (a >= dreq_addr && a <= hi) d[l*8 +: 8] = hm_peek(a);
              else                           d[l*8 +: 8] = byte'(tb_rand32());   // garbage outside the span
            end
            csd[s.csid*4096 + k] = d;
          end
          if (wi >= 0) begin
            s.fail = 1'b1; s.fail_status = ew[wi].status;
            s.fail_after = (ew[wi].after < nw) ? ew[wi].after : nw - 1;     // the error always replaces a beat
            tb_cov("host_read_error_injected");
            if (ew[wi].silent) begin
              s.nbeats = -1;        // never answered
              tb_cov("host_read_silent");
            end
          end
          if (s.nbeats >= 0) cs_q.push_back(s);
          else begin
            // silent: keep the tag outstanding forever (no stream)
          end
        end else if (dreq_kind == 2'd2 || dreq_kind == 2'd3) begin
          if (dreq_kind == 2'd2) n_dreq_wr++; else n_dreq_wrp++;
          w.kind = dreq_kind; w.addr = dreq_addr; w.len = dreq_len; w.tag = dreq_tag;
          w.nbeats = nw; w.got = 0; w.fail = (wi >= 0); w.fail_status = (wi >= 0) ? ew[wi].status : 4'h0;
          w.silent = (wi >= 0) ? ew[wi].silent : 1'b0;
          wp_q.push_back(w);
        end else begin
          tb_fail($sformatf("dreq with invalid kind %0d", dreq_kind));
        end
      end

      // ---- dw beat accepted
      if (dw_valid && dw_ready) begin
        n_dw_beats++;
        wi = -1;
        for (int i = 0; i < wp_q.size(); i++) if (wi < 0 && wp_q[i].got < wp_q[i].nbeats) wi = i;
        if (wi < 0) begin
          tb_fail("dw beat with no write request waiting for data");
        end else begin
          w = wp_q[wi];
          base = {w.addr[63:4], 4'h0} + 16 * w.got;
          for (int l = 0; l < 16; l++) begin
            a = base + l;
            if (dw_be[l]) begin
              if (a >= w.addr && (a - w.addr) < 64'(w.len)) begin
                if (!w.fail) hm_poke(a, dw_data[l*8 +: 8]);
              end else begin
                tb_fail($sformatf("dw strobe set for a lane outside the request span (addr=%h len=%0d beat=%0d lane=%0d)",
                                  w.addr, w.len, w.got, l));
              end
            end
          end
          tb_check(dw_last == (w.got == w.nbeats - 1),
                   $sformatf("dw_last=%0b at beat %0d of %0d", dw_last, w.got, w.nbeats));
          w.got++;
          wp_q[wi] = w;
          if (w.got == w.nbeats) begin
            if (w.kind == 2'd2 && !w.silent) begin
              s.tag = w.tag; s.nbeats = 1; s.sent = 0; s.ready_cyc = cyc + tb_range(cfg_lat_min, cfg_lat_max);
              s.csid = next_csid++; s.is_ack = 1'b1; s.fail = w.fail; s.fail_status = w.fail_status; s.fail_after = 0;
              cs_q.push_back(s);
            end
            wp_q.delete(wi);
          end
        end
      end
    end
  end

  // ===========================================================================
  // COMPLETER drivers (falling edge): dreq / dw ready, dcpl beats
  // ===========================================================================
  bit dcpl_acc_f = 1'b0;
  always @(posedge clk) if (rst_n && dcpl_valid && dcpl_ready) dcpl_acc_f = 1'b1;

  bit  dcpl_busy = 1'b0;
  always @(negedge clk) begin
    int cand [$];
    int pick;
    cs_t s;
    raw_t rw;
    bit [127:0] d;
    if (!rst_n) begin
      dreq_ready <= 1'b0; dw_ready <= 1'b0;
      dcpl_valid <= 1'b0; dcpl_tag <= '0; dcpl_status <= '0; dcpl_data <= '0; dcpl_last <= 1'b0;
      dcpl_busy = 1'b0; dcpl_acc_f = 1'b0; last_stream = -1;
    end else begin
      dreq_ready <= tb_pct(cfg_dreq_rdy);
      dw_ready   <= tb_pct(cfg_dw_rdy);
      if (dcpl_busy && dcpl_acc_f) begin dcpl_busy = 1'b0; dcpl_acc_f = 1'b0; end
      if (!dcpl_busy) begin
        dcpl_valid <= 1'b0;
        if (raw_q.size() > 0) begin
          rw = raw_q.pop_front();
          dcpl_busy = 1'b1;
          dcpl_valid <= 1'b1; dcpl_tag <= rw.tag; dcpl_status <= rw.status; dcpl_data <= rw.data; dcpl_last <= rw.last;
          tb_cov("host_raw_beat");
        end else if (!tb_pct(cfg_beat_gap)) begin
          cand.delete();
          for (int i = 0; i < cs_q.size(); i++) if (cs_q[i].ready_cyc <= cyc) cand.push_back(i);
          if (cand.size() > 0) begin
            pick = cand[0];
            if (tb_pct(cfg_ooo_pct)) pick = cand[tb_below(cand.size())];
            s = cs_q[pick];
            if (last_stream >= 0 && last_stream != pick && s.sent > 0) n_ooo_switches++;
            dcpl_busy = 1'b1;
            dcpl_valid <= 1'b1;
            dcpl_tag <= s.tag;
            if (s.is_ack) begin
              dcpl_status <= s.fail ? s.fail_status : 4'h0;
              dcpl_data <= '0; dcpl_last <= 1'b1;
              s.sent = s.nbeats;
            end else if (s.fail && s.sent >= s.fail_after) begin
              dcpl_status <= s.fail_status; dcpl_data <= '0; dcpl_last <= 1'b1;
              s.sent = s.nbeats;
            end else begin
              dcpl_status <= 4'h0;
              dcpl_data   <= csd[s.csid*4096 + s.sent];
              s.sent++;
              dcpl_last   <= (s.sent == s.nbeats);
            end
            if (s.sent >= s.nbeats) begin
              cs_q.delete(pick);
              if (tag_out.exists(int'(s.tag))) begin tag_out.delete(int'(s.tag)); n_tag_out--; end
              last_stream = -1;
            end else begin
              cs_q[pick] = s;
              last_stream = pick;
            end
          end
        end
      end
    end
  end

  //  The host gives up on a request it never answered (used after a completion timeout in the bridge).
  task automatic forget_tag(input bit [7:0] tag);
    if (tag_out.exists(int'(tag))) begin tag_out.delete(int'(tag)); n_tag_out--; end
  endtask

  // Rogue beat injection (protocol-violation tests)
  task automatic send_raw_cpl(input bit [7:0] tag, input bit [3:0] status, input bit [127:0] data, input bit last);
    raw_t r;
    r.tag = tag; r.status = status; r.data = data; r.last = last;
    raw_q.push_back(r);
  endtask

  function automatic bit completer_idle();
    return (wp_q.size() == 0) && (cs_q.size() == 0) && (raw_q.size() == 0) && !dcpl_busy;
  endfunction

endmodule

`default_nettype wire
