// =============================================================================
//  tb_hb_perm.sv  --  aperture access rights (AP_PERM)
// -----------------------------------------------------------------------------
//  Aperture 0 (host 0 + 1 MiB, the CSR window; unbacked in stage 1) is READ-ONLY, aperture 1 (host SRAM window)
//  is WRITE-ONLY.  A forbidden access is rejected by the bridge with SF_HS_DENIED and never reaches the fabric; a
//  permitted access is forwarded (aperture 0 read -> the stage-1 fabric has no register block there -> UR).
// =============================================================================
`default_nettype none

module tb_hb_perm;
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  always #5 clk = ~clk;

  hb_env_sram #(.AP_PERM(4'b1001)) u_env (     // {ap1 write, ap1 read, ap0 write, ap0 read} = {1,0,0,1}
    .clk, .rst_n, .cancel(1'b0), .evt_ready_en(1'b1),
    .grd_cfg_we(1'b0), .grd_cfg_idx(3'd0), .grd_cfg_base(64'd0), .grd_cfg_limit(64'd0), .grd_cfg_dom(8'd0),
    .grd_cfg_rd(1'b0), .grd_cfg_wr(1'b0), .grd_cfg_valid(1'b0)
  );
  localparam longint unsigned SRAM = 64'h1000_0000;
  localparam bit [7:0] DOM = 8'h10;
  localparam int UR = 1, DENIED = 2;

  initial begin
    int a0;
    tb_seed(32'd55);
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (1100) @(negedge clk);

    a0 = u_env.alp_reqs;
    u_env.u_host.post_rd(8'd1, SRAM + 64'h10, 16, DOM, DENIED, 1'b0);          // SRAM window is write-only
    u_env.u_host.post_wr(8'd2, 64'h20, 16, DOM, 1'b0, DENIED, 1'b0, 0);        // CSR window is read-only
    u_env.u_host.post_wr(8'd3, 64'h20, 100, DOM, 1'b0, DENIED, 1'b0, 0);       // (and its data is drained)
    u_env.u_host.post_wr(8'd4, 64'h30, 16, DOM, 1'b1, 0, 1'b0, 0);             // posted: dropped, event only
    u_env.u_host.wait_req_idle(20000);
    tb_check(u_env.alp_reqs == a0, "a request forbidden by the aperture rights reached the fabric");
    u_env.expect_evt(2'd0, 4'(DENIED), 8'd1, SRAM + 64'h10, 20);
    u_env.expect_evt(2'd0, 4'(DENIED), 8'd2, 64'h20, 20);
    u_env.expect_evt(2'd0, 4'(DENIED), 8'd3, 64'h20, 20);
    u_env.expect_evt(2'd0, 4'(DENIED), 8'd4, 64'h30, 20);
    u_env.expect_no_evt(10);

    u_env.u_host.post_wr(8'd5, SRAM + 64'h40, 100, DOM, 1'b0, 0, 1'b0, 0);     // permitted write
    u_env.u_host.post_rd(8'd6, 64'h40, 16, DOM, UR, 1'b0);                     // permitted read of the CSR window -> fabric UR
    u_env.u_host.wait_req_idle(20000);
    tb_check(u_env.alp_reqs > a0, "permitted requests did not reach the fabric");
    u_env.expect_evt(2'd0, 4'(UR), 8'd6, 64'h40, 20);
    u_env.expect_no_evt(10);
    tb_check(!u_env.fatal, "fatal latched");
    repeat (20) @(negedge clk);
    tb_report("tb_hb_perm");
    $finish;
  end
  initial begin #50000000; tb_fail("perm: timeout"); tb_report("tb_hb_perm"); $finish; end
endmodule

`default_nettype wire
