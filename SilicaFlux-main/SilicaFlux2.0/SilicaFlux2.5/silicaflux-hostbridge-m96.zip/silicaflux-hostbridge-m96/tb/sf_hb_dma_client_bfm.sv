// =============================================================================
//  sf_hb_dma_client_bfm.sv  --  DMA client bus-functional model (never synthesized)
// -----------------------------------------------------------------------------
//  Plays the device-side agent that uses the bridge's DMA client port: drives dma_req / dma_w and checks
//  every dma_r beat.  A shadow of HOST memory (overlay over the host model's byte pattern) is updated in
//  request order, which is exactly the order in which the bridge sends requests to the host, so a read
//  posted after a write observes the write.
//
//  Checks on dma_r (results must come back in request order):
//    * id of the oldest outstanding request, one stream per request, `last` only on the final beat
//    * read OK     : one beat per word of the span, data = span bytes with ZERO elsewhere, be = span lanes
//    * read failed : zero or more OK data beats (verified), then ONE terminating beat with the expected
//                    status, last = 1, zero data and zero be
//    * write       : exactly one beat, is_write = 1, expected status, zero data
// =============================================================================
`default_nettype none

module sf_hb_dma_client_bfm (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         cancel_i,      // probe of the cancel pin (see sf_hti_host_bfm)
  output logic              dma_req_valid,
  input  wire logic         dma_req_ready,
  output logic              dma_req_write,
  output logic              dma_req_posted,
  output logic [63:0]       dma_req_addr,
  output logic [23:0]       dma_req_len,
  output logic [7:0]        dma_req_id,
  output logic              dma_w_valid,
  input  wire logic         dma_w_ready,
  output logic [127:0]      dma_w_data,
  output logic [15:0]       dma_w_be,
  output logic              dma_w_last,
  input  wire logic         dma_r_valid,
  output logic              dma_r_ready,
  input  wire logic [7:0]   dma_r_id,
  input  wire logic [3:0]   dma_r_status,
  input  wire logic         dma_r_is_write,
  input  wire logic [127:0] dma_r_data,
  input  wire logic [15:0]  dma_r_be,
  input  wire logic         dma_r_last
);
  import sf_hb_tb_pkg::*;

  int cfg_req_gap     = 0;     // % chance to idle before presenting a request
  int cfg_w_gap       = 0;     // % chance to idle before presenting a write beat
  int cfg_r_rdy       = 100;   // % chance dma_r_ready is high
  int cfg_dirty_lanes = 1;     // garbage data AND strobes outside the span on write beats
  int cfg_data_first  = 0;     // 1: data may be offered before the request is accepted

  typedef struct {
    bit               is_wr, posted;
    longint unsigned  addr;
    int               len;
    bit [7:0]         id;
    int               exp_status;
    longint unsigned  rid;
    int               nbeats;
    bit               chk;
  } dq_t;

  typedef struct {
    longint unsigned rid, addr;
    int len, nbeats, beat;
    bit eligible;
  } dj_t;

  dq_t dq_q  [$];
  dq_t dex_q [$];
  dj_t dj_q  [$];
  byte unsigned shadow [longint unsigned];    // host memory overlay
  byte unsigned pay    [longint unsigned];
  bit           pstb   [longint unsigned];
  byte unsigned expd   [longint unsigned];
  longint unsigned next_rid = 1;
  longint unsigned acc_cyc [longint unsigned];
  longint unsigned cancel_edges [$];
  longint unsigned cyc_c = 0;
  bit  req_busy = 1'b0, w_busy = 1'b0, req_acc_f = 1'b0, w_acc_f = 1'b0;
  longint unsigned cur_rid;
  int  rb_idx = 0;           // beats received for the current result
  int  outstanding = 0;
  int  n_ok = 0, n_err = 0, n_reqs = 0;
  bit [3:0] last_status;

  function automatic int nwords_of(input longint unsigned addr, input int len);
    return (int'(addr[3:0]) + len + 15) / 16;
  endfunction

  //  exp_status 255 = "either": the request may legally end OK or ABORTED (a cancel raced with it)
  function automatic bit st_match(input int exp_st, input bit [3:0] got);
    if (exp_st == 255) return (got == 4'd0) || (got == 4'd7);
    return got == 4'(exp_st);
  endfunction

  task automatic reset_model();
    shadow.delete();
  endtask

  function automatic byte unsigned sh_peek(input longint unsigned a);
    if (shadow.exists(a)) return shadow[a];
    return hb_pat(a);
  endfunction

  task automatic sh_poke(input longint unsigned a, input byte unsigned b);
    shadow[a] = b;
  endtask

  // ---------------------------------------------------------------------------
  //  API
  // ---------------------------------------------------------------------------
  task automatic post_any(input bit is_wr, input bit posted, input bit [7:0] id, input longint unsigned addr,
                          input int len, input int exp_status, input bit chk, input int strobe_mode,
                          input int nbeats_override);
    dq_t r;
    dj_t j;
    int  nb;
    r.is_wr = is_wr; r.posted = posted; r.addr = addr; r.len = len; r.id = id; r.exp_status = exp_status;
    r.rid = next_rid; r.chk = chk;
    nb = is_wr ? ((nbeats_override >= 0) ? nbeats_override : nwords_of(addr, len)) : 0;
    if (len == 0 && nbeats_override < 0) nb = 0;
    r.nbeats = nb;
    if (is_wr && nb > 0) begin
      for (int i = 0; i < len; i++) begin
        pay [r.rid*(1<<24) + i] = byte'(tb_rand32());
        pstb[r.rid*(1<<24) + i] = (strobe_mode == 0) ? 1'b1 : !tb_pct(25);
      end
      if (exp_status == 0) begin
        for (int i = 0; i < len; i++) if (pstb[r.rid*(1<<24) + i]) shadow[addr + i] = pay[r.rid*(1<<24) + i];
      end
      j.rid = r.rid; j.addr = addr; j.len = len; j.nbeats = nb; j.beat = 0; j.eligible = (cfg_data_first != 0);
      dj_q.push_back(j);
    end
    if (!is_wr && chk) begin
      for (int i = 0; i < len; i++) expd[r.rid*(1<<24) + i] = sh_peek(addr + i);
    end
    next_rid++;
    dq_q.push_back(r);
    dex_q.push_back(r);
    outstanding++;
    n_reqs++;
  endtask

  task automatic post_read(input bit [7:0] id, input longint unsigned addr, input int len,
                           input int exp_status, input bit chk);
    post_any(1'b0, 1'b0, id, addr, len, exp_status, chk, 0, -1);
  endtask

  task automatic post_write(input bit [7:0] id, input longint unsigned addr, input int len, input bit posted,
                            input int exp_status, input int strobe_mode);
    post_any(1'b1, posted, id, addr, len, exp_status, 1'b0, strobe_mode, -1);
  endtask

  function automatic bit is_idle();
    return (dq_q.size() == 0) && (dj_q.size() == 0) && !req_busy && !w_busy && (outstanding == 0);
  endfunction

  task automatic wait_idle(input int timeout_cycles);
    int t;
    t = 0;
    while (!is_idle() && t < timeout_cycles) begin
      @(negedge clk);
      t++;
    end
    tb_check(is_idle(), "dma client wait_idle: requests did not drain (timeout)");
  endtask

  // ---------------------------------------------------------------------------
  //  Drivers (falling edge)
  // ---------------------------------------------------------------------------
  always @(posedge clk) begin
    cyc_c++;
    if (rst_n && cancel_i) cancel_edges.push_back(cyc_c);
    if (rst_n && dma_req_valid && dma_req_ready) begin req_acc_f = 1'b1; acc_cyc[cur_rid] = cyc_c; end
    if (rst_n && dma_w_valid && dma_w_ready)     w_acc_f   = 1'b1;
  end

  always @(negedge clk) begin
    dq_t r;
    dj_t j;
    logic [127:0] d;
    logic [15:0]  b;
    longint unsigned wa, idx, base;
    if (!rst_n) begin
      dma_req_valid <= 1'b0; dma_w_valid <= 1'b0; dma_r_ready <= 1'b0;
      dma_req_write <= 1'b0; dma_req_posted <= 1'b0; dma_req_addr <= '0; dma_req_len <= '0; dma_req_id <= '0;
      dma_w_data <= '0; dma_w_be <= '0; dma_w_last <= 1'b0;
      req_busy = 1'b0; w_busy = 1'b0; req_acc_f = 1'b0; w_acc_f = 1'b0;
      dq_q.delete(); dex_q.delete(); dj_q.delete(); outstanding = 0; rb_idx = 0;
    end else begin
      if (req_busy && req_acc_f) begin
        req_busy = 1'b0; req_acc_f = 1'b0;
        for (int i = 0; i < dj_q.size(); i++) if (dj_q[i].rid == cur_rid) dj_q[i].eligible = 1'b1;
      end
      if (!req_busy) begin
        if (dq_q.size() > 0 && !tb_pct(cfg_req_gap)) begin
          r = dq_q.pop_front();
          cur_rid = r.rid;
          req_busy = 1'b1;
          dma_req_valid <= 1'b1; dma_req_write <= r.is_wr; dma_req_posted <= r.posted;
          dma_req_addr <= r.addr; dma_req_len <= 24'(r.len); dma_req_id <= r.id;
        end else begin
          dma_req_valid <= 1'b0;
        end
      end
      if (w_busy && w_acc_f) begin
        w_busy = 1'b0; w_acc_f = 1'b0;
        dj_q[0].beat++;
        if (dj_q[0].beat == dj_q[0].nbeats) dj_q.pop_front();
      end
      if (!w_busy) begin
        if (dj_q.size() > 0 && dj_q[0].eligible && !tb_pct(cfg_w_gap)) begin
          j = dj_q[0];
          base = {j.addr[63:4], 4'h0} + 16 * j.beat;
          d = '0; b = '0;
          for (int l = 0; l < 16; l++) begin
            wa = base + l;
            if (wa >= j.addr && (wa - j.addr) < 64'(j.len)) begin
              idx = wa - j.addr;
              d[l*8 +: 8] = pay [j.rid*(1<<24) + idx];
              b[l]        = pstb[j.rid*(1<<24) + idx];
            end else if (cfg_dirty_lanes != 0) begin
              d[l*8 +: 8] = byte'(tb_rand32());
              b[l]        = tb_pct(50);
            end
          end
          w_busy = 1'b1;
          dma_w_valid <= 1'b1; dma_w_data <= d; dma_w_be <= b; dma_w_last <= (j.beat == j.nbeats - 1);
        end else begin
          dma_w_valid <= 1'b0;
        end
      end
      dma_r_ready <= tb_pct(cfg_r_rdy);
    end
  end

  // ---------------------------------------------------------------------------
  //  Result monitor (rising edge)
  // ---------------------------------------------------------------------------
  always @(posedge clk) begin
    dq_t h;
    int  nw;
    logic [127:0] exp_d;
    logic [15:0]  exp_b;
    longint unsigned wa, idx, base;
    bit  final_word;
    if (rst_n && dma_r_valid && dma_r_ready) begin
      if (dex_q.size() == 0) begin
        tb_fail($sformatf("dma_r beat with nothing outstanding (id=%0d status=%0d)", dma_r_id, dma_r_status));
      end else begin
        h  = dex_q[0];
        nw = nwords_of(h.addr, h.len);
        tb_check(dma_r_id == h.id, $sformatf("dma_r id %0d, oldest request has id %0d (order)", dma_r_id, h.id));
        tb_check(dma_r_is_write == h.is_wr, "dma_r is_write does not match the request");
        if (h.is_wr) begin
          tb_check(dma_r_last, "write result must be a single beat");
          tb_check(st_match(h.exp_status, dma_r_status),
                   $sformatf("dma write status %0d, expected %0d (id %0d)", dma_r_status, h.exp_status, h.id));
          tb_check(dma_r_data == '0 && dma_r_be == '0, "write result must carry no data");
        end else begin
          if (dma_r_status == 4'h0) begin
            final_word = (rb_idx == nw - 1);
            tb_check(dma_r_last == final_word,
                     $sformatf("dma read beat %0d last=%0b expected %0b (nw=%0d id %0d)", rb_idx, dma_r_last, final_word, nw, h.id));
            base = {h.addr[63:4], 4'h0} + 16 * rb_idx;
            exp_d = '0; exp_b = '0;
            for (int l = 0; l < 16; l++) begin
              wa = base + l;
              if (wa >= h.addr && (wa - h.addr) < 64'(h.len)) begin
                idx = wa - h.addr;
                exp_b[l] = 1'b1;
                if (h.chk) exp_d[l*8 +: 8] = expd[h.rid*(1<<24) + idx];
              end
            end
            tb_check(dma_r_be == exp_b, $sformatf("dma read beat %0d be=%h expected %h (id %0d)", rb_idx, dma_r_be, exp_b, h.id));
            if (h.chk) tb_check(dma_r_data == exp_d,
                     $sformatf("dma read beat %0d id %0d addr %h: got %h expected %h", rb_idx, h.id, h.addr, dma_r_data, exp_d));
            // data beats may precede an error terminator; only a FINAL ok beat means the request succeeded
            if (dma_r_last) tb_check(h.exp_status == 0 || h.exp_status == 255,
                                     $sformatf("dma read id %0d succeeded but status %0d was expected", h.id, h.exp_status));
          end else begin
            tb_check(dma_r_last, "error beat of a read must be last");
            tb_check(st_match(h.exp_status, dma_r_status),
                     $sformatf("dma read status %0d, expected %0d (id %0d)", dma_r_status, h.exp_status, h.id));
            tb_check(dma_r_data == '0 && dma_r_be == '0, "error beat must carry no data");
          end
        end
        last_status = dma_r_status;
        if (dma_r_last && dma_r_status == 4'd7 && h.exp_status == 255) begin
          bit covered;
          covered = 1'b0;
          for (int e = 0; e < cancel_edges.size(); e++) if (cancel_edges[e] + 2 >= acc_cyc[h.rid]) covered = 1'b1;
          tb_check(covered, $sformatf("DMA request id %0d (accepted at cycle %0d) was ABORTED although no cancel covers it", h.id, acc_cyc[h.rid]));
          tb_cov("dma_aborted");
        end
        rb_idx++;
        if (dma_r_last) begin
          rb_idx = 0;
          dex_q.pop_front();
          outstanding--;
          if (dma_r_status == 0) n_ok++; else n_err++;
          tb_cov($sformatf("dma_status_%0d", dma_r_status));
        end
      end
    end
  end
endmodule

`default_nettype wire
