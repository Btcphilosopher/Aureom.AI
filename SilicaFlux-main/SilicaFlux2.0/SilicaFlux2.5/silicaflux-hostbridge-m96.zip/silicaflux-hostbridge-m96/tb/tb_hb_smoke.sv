// =============================================================================
//  tb_hb_smoke.sv  --  first-light test: a few directed host requests through the stage-1 environment
// =============================================================================
`default_nettype none

module tb_hb_smoke;
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  always #5 clk = ~clk;

  hb_env_sram u_env (
    .clk, .rst_n, .cancel(1'b0), .evt_ready_en(1'b1),
    .grd_cfg_we(1'b0), .grd_cfg_idx(3'd0), .grd_cfg_base(64'd0), .grd_cfg_limit(64'd0), .grd_cfg_dom(8'd0),
    .grd_cfg_rd(1'b0), .grd_cfg_wr(1'b0), .grd_cfg_valid(1'b0)
  );

  localparam longint unsigned SRAM = 64'h1000_0000;

  initial begin
    tb_seed(32'd7);
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (4) @(negedge clk);

    // one full word, then read it back
    u_env.u_host.post_wr(8'd1, SRAM + 64'h00, 16, 8'h10, 1'b0, 0, 1'b1, 0);
    u_env.u_host.post_rd(8'd2, SRAM + 64'h00, 16, 8'h10, 0, 1'b1);
    u_env.u_host.wait_req_idle(2000);
    $display("smoke: after word write/read: checks=%0d errors=%0d", tb_checks, tb_errors);

    // unaligned multi-word write (spans 3 words), read back the same span and a larger one
    u_env.u_host.post_wr(8'd3, SRAM + 64'h0105, 40, 8'h10, 1'b0, 0, 1'b1, 0);
    u_env.u_host.post_rd(8'd4, SRAM + 64'h0105, 40, 8'h10, 0, 1'b1);
    u_env.u_host.post_rd(8'd5, SRAM + 64'h0100, 64, 8'h10, 0, 1'b1);
    u_env.u_host.wait_req_idle(4000);
    $display("smoke: after unaligned burst: checks=%0d errors=%0d", tb_checks, tb_errors);

    repeat (10) @(negedge clk);
    tb_report("tb_hb_smoke");
    $finish;
  end

  initial begin
    #2000000;
    tb_fail("smoke: global timeout");
    tb_report("tb_hb_smoke");
    $finish;
  end
endmodule

`default_nettype wire
