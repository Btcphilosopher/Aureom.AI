// =============================================================================
//  tb_hb_soak.sv  --  constrained-random soak: host path and DMA path together, every knob random
// -----------------------------------------------------------------------------
//  Parameters (set by the runner): SEED, ROUNDS, NUM_TAGS, MPS_BYTES, MRRS_BYTES, MAX_OUT.  Every round draws new
//  throttling on all eight channels, a new ordering policy / latency range for host completions, and a mix of
//  legal host-originated and DMA requests of random length and alignment.  All data is checked exactly.
// =============================================================================
`default_nettype none

module tb_hb_soak #(
  parameter int unsigned SEED      = 1,
  parameter int unsigned ROUNDS    = 20,
  parameter int unsigned NUM_TAGS  = 8,
  parameter int unsigned MPS_BYTES = 256,
  parameter int unsigned MRRS_BYTES = 256,
  parameter int unsigned MAX_OUT   = 8
);
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  always #5 clk = ~clk;

  hb_env_sram #(.NUM_TAGS(NUM_TAGS), .MPS_BYTES(MPS_BYTES), .MRRS_BYTES(MRRS_BYTES), .MAX_OUT(MAX_OUT)) u_env (
    .clk, .rst_n, .cancel(1'b0), .evt_ready_en(1'b1),
    .grd_cfg_we(1'b0), .grd_cfg_idx(3'd0), .grd_cfg_base(64'd0), .grd_cfg_limit(64'd0), .grd_cfg_dom(8'd0),
    .grd_cfg_rd(1'b0), .grd_cfg_wr(1'b0), .grd_cfg_valid(1'b0)
  );

  localparam longint unsigned SRAM = 64'h1000_0000;
  localparam longint unsigned HR = 64'h2000_0000, HW = 64'h3000_0000;
  localparam bit [7:0] DOM = 8'h10;

  initial begin
    tb_seed(SEED);
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (1100) @(negedge clk);
    for (int round = 0; round < ROUNDS; round++) begin
      int nh, nd;
      // ---- draw the round's personality
      u_env.u_host.cfg_req_gap = tb_pct(40) ? 0 : tb_below(70);
      u_env.u_host.cfg_hw_gap  = tb_pct(40) ? 0 : tb_below(70);
      u_env.u_host.cfg_cpl_rdy = tb_pct(40) ? 100 : 10 + tb_below(91);
      u_env.u_host.cfg_data_first = tb_below(2);
      u_env.u_host.cfg_dreq_rdy = tb_pct(40) ? 100 : 10 + tb_below(91);
      u_env.u_host.cfg_dw_rdy   = tb_pct(40) ? 100 : 10 + tb_below(91);
      u_env.u_host.cfg_lat_min  = 1 + tb_below(5);
      u_env.u_host.cfg_lat_max  = u_env.u_host.cfg_lat_min + tb_below(tb_pct(30) ? 120 : 20);
      u_env.u_host.cfg_ooo_pct  = tb_pct(30) ? 0 : tb_below(101);
      u_env.u_host.cfg_beat_gap = tb_pct(60) ? 0 : tb_below(50);
      u_env.u_host.cfg_dirty_lanes = tb_below(2);
      u_env.u_dma.cfg_req_gap = tb_pct(40) ? 0 : tb_below(60);
      u_env.u_dma.cfg_w_gap   = tb_pct(40) ? 0 : tb_below(60);
      u_env.u_dma.cfg_r_rdy   = tb_pct(40) ? 100 : 10 + tb_below(91);
      u_env.u_dma.cfg_dirty_lanes = tb_below(2);
      u_env.u_dma.cfg_data_first  = tb_below(2);
      nh = 30 + tb_below(60);
      nd = 30 + tb_below(60);
      if ($test$plusargs("hb_progress"))
        $display("soak round %0d t=%0t alp_reqs=%0d dreq=%0d host_out=%0d dma_out=%0d cs_q=%0d", round, $time, u_env.alp_reqs,
                 u_env.u_host.n_dreq, u_env.u_dut.host_outstanding_o, u_env.u_dut.dma_outstanding_o, u_env.u_host.cs_q.size());
      // ---- host-originated traffic (legal: inside one 4 KiB page and the aperture)
      for (int i = 0; i < nh; i++) begin
        int len;
        longint unsigned off;
        len = tb_pct(8) ? tb_range(100, 900) : tb_range(1, 80);
        off = tb_below(16384);
        if (int'(off % 4096) + len > 4096) len = 4096 - int'(off % 4096);
        if (tb_pct(45)) u_env.u_host.post_wr(8'(tb_below(256)), SRAM + off, len, DOM, tb_pct(25), 0, 1'b1, tb_below(2));
        else            u_env.u_host.post_rd(8'(tb_below(256)), SRAM + off, len, DOM, 0, 1'b1);
      end
      // ---- DMA traffic (any alignment, may cross pages; writes to a region reads may overlap: order is checked too)
      for (int i = 0; i < nd; i++) begin
        int len;
        longint unsigned a;
        len = tb_pct(10) ? tb_range(400, 400 + 3 * MRRS_BYTES) : tb_range(1, 200);   // (hi >= lo for every MRRS)
        a = (tb_pct(50) ? HW : HR) + tb_below(1 << 13);
        if (tb_pct(40)) u_env.u_dma.post_write(8'(tb_below(256)), HW + (a & 64'h1FFF), len, tb_pct(25), 0, tb_below(2));
        else            u_env.u_dma.post_read(8'(tb_below(256)), a, len, 0, 1'b1);
      end
      u_env.u_host.wait_req_idle(2000000);
      u_env.u_dma.wait_idle(2000000);
      if ($test$plusargs("hb_progress"))
        $display("soak round %0d drained t=%0t errors=%0d dma_pending=%0d host_pending=%0d", round, $time, tb_errors,
                 u_env.u_dma.outstanding, u_env.u_host.outstanding_cpl);
      tb_check(u_env.u_dut.dma_outstanding_o == 0, "soak: DMA tags still busy at the end of a round");
    end
    tb_check(!u_env.fatal && u_env.unexpected_cpl == 0, "soak: fatal or unexpected completions");
    u_env.expect_no_evt(10);
    tb_cov_declare("soak_ooo_switches");
    for (int i = 0; i < u_env.u_host.n_ooo_switches; i += 50) tb_cov("soak_ooo_switches");
    $display("soak seed=%0d rounds=%0d: checks=%0d errors=%0d  alp_reqs=%0d dreq=%0d ooo_sw=%0d max_tags=%0d",
             SEED, ROUNDS, tb_checks, tb_errors, u_env.alp_reqs, u_env.u_host.n_dreq, u_env.u_host.n_ooo_switches, u_env.u_host.max_tags_seen);
    repeat (20) @(negedge clk);
    tb_report("tb_hb_soak");
    $finish;
  end

  initial begin
    #3000000000;
    tb_fail("soak: global timeout");
    tb_report("tb_hb_soak");
    $finish;
  end
endmodule

`default_nettype wire
