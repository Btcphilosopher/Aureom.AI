// =============================================================================
//  tb_hb_fabric_faults.sv  --  fault responses coming back from the fabric (ALP) side
// -----------------------------------------------------------------------------
//  The ALP responses are mutated by sf_hb_alp_corrupt (address-window rules).  Checks:
//    F1  every ALP status maps to the documented HTI status (independent table below), read and write
//    F2  a read that fails at word 0 / in the middle / at the last word: OK beats, ONE error beat, the rest drained
//    F3  a write reports the FIRST error of its words;   F4 a failing posted write is only an event
//    F5  non-conforming responses (wrong operation flag, not well-formed) become PROTO
//    F6  a response with a wrong tag latches the fatal error, the bridge stops issuing, reset recovers it
//    F7  randomized storm: expected status computed per word from the fault windows; no interference
// =============================================================================
`default_nettype none

module tb_hb_fabric_faults;
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  always #5 clk = ~clk;

  hb_env_sram #(.ALLOW_FATAL(1'b1)) u_env (
    .clk, .rst_n, .cancel(1'b0), .evt_ready_en(1'b1),
    .grd_cfg_we(1'b0), .grd_cfg_idx(3'd0), .grd_cfg_base(64'd0), .grd_cfg_limit(64'd0), .grd_cfg_dom(8'd0),
    .grd_cfg_rd(1'b0), .grd_cfg_wr(1'b0), .grd_cfg_valid(1'b0)
  );

  localparam longint unsigned SRAM  = 64'h1000_0000;
  localparam longint unsigned DOFF  = 64'h0000_0001_0000_0000;     // device address = host address + DOFF
  localparam bit [7:0] DOM = 8'h10;

  //  ALP status -> HTI status, written from the specification text (docs/HOSTBRIDGE_SPEC.md, status table)
  function automatic int hti_of_alp(input int alp);
    case (alp)
      1:  return 1;    // DECODE_ERR      -> UR
      2:  return 2;    // ACCESS_DENIED   -> DENIED
      3:  return 9;    // BAD_OPCODE      -> BAD_REQ
      4:  return 9;    // BAD_BE          -> BAD_REQ
      5:  return 9;    // ALIGN_ERR       -> BAD_REQ
      6:  return 9;    // BAD_ATTR        -> BAD_REQ
      7:  return 3;    // TARGET_ERR      -> CA
      8:  return 8;    // TIMEOUT         -> TIMEOUT
      9:  return 7;    // CANCELLED       -> ABORTED
      10: return 4;    // ECC_UNCORR      -> POISON
      11: return 10;   // PROTOCOL_ERR    -> PROTO
      default: return -1;
    endcase
  endfunction

  task automatic drain();
    u_env.u_host.wait_req_idle(100000);
  endtask

  initial begin
    tb_seed(32'd8086);
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (1100) @(negedge clk);

    // ---- F1: every status, read and write
    for (int a = 1; a <= 11; a++) begin
      longint unsigned lo;
      lo = SRAM + 64'h2000 + a * 64'h100;
      u_env.u_corrupt.set_rule(a % 4, lo + DOFF, lo + DOFF + 64'hFF, 4'(a), 0);
      u_env.u_host.post_rd(8'(a), lo, 16, DOM, hti_of_alp(a), 1'b0);
      u_env.u_host.post_wr(8'(a + 16), lo + 16, 16, DOM, 1'b0, hti_of_alp(a), 1'b0, 0);
      drain();
      // (the rule slot is reused modulo 4: only the one just set matters because the windows are disjoint)
      // every failure is logged, except an ABORTED completion of a non-posted request (a deliberate cancel)
      if (hti_of_alp(a) != 7) begin
        u_env.expect_evt(2'd0, 4'(hti_of_alp(a)), 8'(a),      lo,      20);
        u_env.expect_evt(2'd0, 4'(hti_of_alp(a)), 8'(a + 16), lo + 16, 20);
      end
      u_env.u_corrupt.clear_rules();
    end
    u_env.expect_no_evt(10);
    $display("F1 status mapping: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- F2: read fails at word k of an 8-word read (word 0, middle, last): k OK beats then one error beat
    for (int k = 0; k < 8; k += 3) begin
      longint unsigned base, fail_dev;
      base = SRAM + 64'h2800 + k * 64'h200;
      fail_dev = base + DOFF + 16 * k;
      u_env.u_corrupt.set_rule(0, fail_dev, fail_dev + 15, 4'd7, 0);       // TARGET_ERR on word k only
      u_env.u_host.cfg_cpl_rdy = (k == 3) ? 25 : 100;
      u_env.u_host.post_rd(8'(40 + k), base, 128, DOM, 16 + 3, 1'b0);      // OK beats may precede the CA terminator
      u_env.u_host.post_rd(8'(60 + k), base, 128, DOM, 16 + 3, 1'b0);      // the failure is persistent
      drain();                                                              // (the rule must outlive the queued requests)
      u_env.u_corrupt.clear_rules();
      u_env.u_host.cfg_cpl_rdy = 100;
      // after the failed request the bridge is healthy: a clean read of the same memory works
      u_env.u_host.post_rd(8'(80 + k), base, 128, DOM, 0, 1'b0);
      drain();
      u_env.expect_evt(2'd0, 4'd3, 8'(40 + k), base, 20);
      u_env.expect_evt(2'd0, 4'd3, 8'(60 + k), base, 20);
    end
    u_env.expect_no_evt(10);
    $display("F2 read fails mid-way: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- F3: write: first error wins (word 2: TARGET_ERR -> CA, word 4: ACCESS_DENIED -> DENIED)
    begin
      longint unsigned base;
      base = SRAM + 64'h3400;
      u_env.u_corrupt.set_rule(0, base + DOFF + 32, base + DOFF + 47, 4'd7, 0);
      u_env.u_corrupt.set_rule(1, base + DOFF + 64, base + DOFF + 79, 4'd2, 0);
      u_env.u_host.post_wr(8'd100, base, 128, DOM, 1'b0, 3, 1'b0, 0);      // first error = word 2 = CA
      u_env.u_host.post_wr(8'd101, base + 64, 64, DOM, 1'b0, 2, 1'b0, 0);  // words 4.. only: DENIED
      drain();
      u_env.expect_evt(2'd0, 4'd3, 8'd100, base, 20);
      u_env.expect_evt(2'd0, 4'd2, 8'd101, base + 64, 20);
      u_env.u_corrupt.clear_rules();
    end
    // ---- F4: a posted write that fails at the target: no completion, one event (with the request address)
    begin
      longint unsigned base;
      base = SRAM + 64'h3800;
      u_env.u_corrupt.set_rule(0, base + DOFF, base + DOFF + 255, 4'd7, 0);
      u_env.u_host.post_wr(8'd110, base, 64, DOM, 1'b1, 0, 1'b0, 0);
      u_env.u_host.post_wr(8'd111, base + 100, 20, DOM, 1'b1, 0, 1'b0, 0);
      u_env.u_host.post_rd(8'd112, SRAM + 64'h100, 16, DOM, 0, 1'b0);      // an unrelated read still completes
      drain();
      u_env.expect_evt(2'd0, 4'd3, 8'd110, base, 20);
      u_env.expect_evt(2'd0, 4'd3, 8'd111, base + 100, 20);
      u_env.u_corrupt.clear_rules();
    end
    u_env.expect_no_evt(10);
    $display("F3/F4 write error aggregation, posted failure: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- F5: non-conforming responses never reach the host as data
    begin
      longint unsigned lo;
      lo = SRAM + 64'h3C00;
      u_env.u_corrupt.set_rule(0, lo + DOFF, lo + DOFF + 63, 4'd0, 2);           // wrong is_write flag
      u_env.u_corrupt.set_rule(1, lo + DOFF + 64, lo + DOFF + 127, 4'd0, 3);     // not well-formed
      u_env.u_host.post_rd(8'd120, lo, 16, DOM, 10, 1'b0);
      u_env.u_host.post_wr(8'd121, lo + 16, 16, DOM, 1'b0, 10, 1'b0, 0);
      u_env.u_host.post_rd(8'd122, lo + 64, 16, DOM, 10, 1'b0);
      u_env.u_host.post_wr(8'd123, lo + 80, 16, DOM, 1'b0, 10, 1'b0, 0);
      drain();
      for (int i = 0; i < 4; i++) u_env.expect_evt(2'd0, 4'd10, 8'(120 + i), lo + 16 * i + (i >= 2 ? 32 : 0), 20);
      u_env.u_corrupt.clear_rules();
    end
    $display("F5 non-conforming responses: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- F7: randomized storm (before F6, because F6 ends with a reset)
    begin
      int n_fail;
      longint unsigned A_LO, B_LO;
      A_LO = SRAM + 64'h2000;                  // CA window: host 0x2000..0x20FF
      B_LO = SRAM + 64'h2400;                  // POISON window: host 0x2400..0x24FF
      u_env.u_corrupt.set_rule(0, A_LO + DOFF, A_LO + DOFF + 255, 4'd7, 0);
      u_env.u_corrupt.set_rule(1, B_LO + DOFF, B_LO + DOFF + 255, 4'd10, 0);
      u_env.expect_no_evt(5);
      n_fail = 0;
      for (int round = 0; round < 4; round++) begin
        u_env.u_host.cfg_req_gap = tb_below(40); u_env.u_host.cfg_hw_gap = tb_below(40); u_env.u_host.cfg_cpl_rdy = 30 + tb_below(71);
        for (int i = 0; i < 200; i++) begin
          longint unsigned off, a;
          int len, exp_st, k, nwd;
          bit w, p;
          if (tb_pct(40)) begin
            // clean region: exact data checks, no interference from the faulty windows
            off = tb_below(1500); len = tb_range(1, 300);
            if (tb_pct(50)) u_env.u_host.post_wr(8'(tb_below(256)), SRAM + 64'h400 + off, len, DOM, 1'b0, 0, 1'b1, 0);
            else            u_env.u_host.post_rd(8'(tb_below(256)), SRAM + 64'h400 + off, len, DOM, 0, 1'b1);
          end else begin
            off = tb_below(2048); len = tb_range(1, 200);
            a = SRAM + 64'h2000 + off;
            w = tb_pct(50); p = w && tb_pct(25);
            // first failing word decides
            exp_st = 0; k = -1; nwd = (int'(a[3:0]) + len + 15) / 16;
            for (int j = 0; j < nwd && exp_st == 0; j++) begin
              longint unsigned wa;
              wa = {a[63:4], 4'h0} + 16 * j;
              if (wa >= A_LO && wa <= A_LO + 255)      begin exp_st = 3;  k = j; end
              else if (wa >= B_LO && wa <= B_LO + 255) begin exp_st = 4;  k = j; end
            end
            if (exp_st != 0) n_fail++;
            if (w) u_env.u_host.post_wr(8'(tb_below(256)), a, len, DOM, p, exp_st, 1'b0, tb_below(2));
            else   u_env.u_host.post_rd(8'(tb_below(256)), a, len, DOM, exp_st == 0 ? 0 : 16 + exp_st, 1'b0);
          end
        end
        drain();
      end
      tb_check(u_env.evt_log.size() == n_fail, $sformatf("F7: %0d events for %0d failing requests", u_env.evt_log.size(), n_fail));
      for (int i = 0; i < u_env.evt_log.size(); i++)
        tb_check(u_env.evt_log[i].code == 4'd3 || u_env.evt_log[i].code == 4'd4, "F7: event code must be CA or POISON");
      u_env.evt_log.delete();
      u_env.u_corrupt.clear_rules();
      u_env.u_host.cfg_req_gap = 0; u_env.u_host.cfg_hw_gap = 0; u_env.u_host.cfg_cpl_rdy = 100;
      $display("F7 random storm (%0d failing requests): checks=%0d errors=%0d", n_fail, tb_checks, tb_errors);
    end

    // ---- F6: a response with a wrong tag is a protocol violation: fatal, no more issuing; reset recovers
    begin
      longint unsigned lo;
      int reqs0;
      lo = SRAM + 64'h3F00;
      u_env.u_corrupt.set_rule(0, lo + DOFF, lo + DOFF + 15, 4'd0, 1);
      u_env.u_host.post_rd(8'd130, lo, 16, DOM, 0, 1'b0);
      repeat (60) @(negedge clk);
      tb_check(u_env.fatal, "F6: the bridge did not latch the fatal error");
      tb_check(u_env.u_dut.fatal_o, "F6: fatal_o");
      u_env.expect_evt(2'd0, 4'd10, 8'd0, 64'd0, 40);                         // the fatal event {PROTO, tag 0, addr 0}
      u_env.u_corrupt.clear_rules();
      reqs0 = u_env.alp_reqs;
      u_env.u_host.post_rd(8'd131, SRAM + 64'h100, 16, DOM, 0, 1'b0);           // must not be issued
      u_env.u_host.post_wr(8'd132, SRAM + 64'h100, 16, DOM, 1'b0, 0, 1'b0, 0);
      repeat (300) @(negedge clk);
      tb_check(u_env.alp_reqs == reqs0, "F6: the bridge issued ALP requests after a fatal link error");
      tb_check(u_env.u_host.outstanding_cpl > 0, "F6: requests completed although the link is fatal");
      // hard reset recovers
      #3 rst_n = 1'b0;
      repeat (3) @(negedge clk);
      u_env.u_host.reset_model(); u_env.u_dma.reset_model();
      @(negedge clk);
      rst_n <= 1'b1;
      u_env.evt_log.delete();
      repeat (1100) @(negedge clk);
      tb_check(!u_env.fatal, "F6: fatal not cleared by reset");
      u_env.u_host.post_wr(8'd133, SRAM + 64'h100, 64, DOM, 1'b0, 0, 1'b1, 0);
      u_env.u_host.post_rd(8'd134, SRAM + 64'h100, 64, DOM, 0, 1'b1);
      drain();
      u_env.expect_no_evt(10);
    end
    $display("F6 fatal and recovery: checks=%0d errors=%0d", tb_checks, tb_errors);

    repeat (20) @(negedge clk);
    tb_report("tb_hb_fabric_faults");
    $finish;
  end

  initial begin
    #300000000;
    tb_fail("fabric faults: global timeout");
    tb_report("tb_hb_fabric_faults");
    $finish;
  end
endmodule

`default_nettype wire
