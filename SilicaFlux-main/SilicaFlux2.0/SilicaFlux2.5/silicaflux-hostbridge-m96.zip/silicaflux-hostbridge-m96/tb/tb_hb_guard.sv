// =============================================================================
//  tb_hb_guard.sv  --  host-originated requests through DomainGuard
// -----------------------------------------------------------------------------
//  Claims checked
//    G0  default deny: with no window programmed, a tenant request is DENIED and NOTHING reaches the fabric
//    G1  the guard is shown the TRANSLATED device range, the aperture-assigned attribute, the host's domain
//    G2  permit / deny follow the window table exactly (rights, domain, boundaries, windows that touch)
//    G3  an independent policy model predicts every verdict of a random request storm (exact status, memory
//        effect, number of ALP words), and a separate monitor proves that every ALP word issued is permitted
//    G4  verdict latency 0..N cycles changes nothing, and the fields offered to the guard stay stable meanwhile
//    G5  revocation takes effect for the next request; a denied write's data is drained and changes nothing
//    G6  no layout oracle: "another tenant's memory" and "nothing mapped" give the same status
// =============================================================================
`default_nettype none

module tb_hb_guard #(
  parameter int unsigned LAT = 0
);
  import sf_hb_tb_pkg::*;
  logic clk = 1'b0;
  logic rst_n = 1'b1;
  always #5 clk = ~clk;

  logic         cfg_we = 1'b0;
  logic [2:0]   cfg_idx = 3'd0;
  logic [63:0]  cfg_base = '0, cfg_limit = '0;
  logic [7:0]   cfg_dom = '0;
  logic         cfg_rd = 1'b0, cfg_wr = 1'b0, cfg_valid = 1'b0;

  hb_env_sram #(.GUARD_EN(1'b1), .GUARD_LAT_MAX(LAT)) u_env (
    .clk, .rst_n, .cancel(1'b0), .evt_ready_en(1'b1),
    .grd_cfg_we(cfg_we), .grd_cfg_idx(cfg_idx), .grd_cfg_base(cfg_base), .grd_cfg_limit(cfg_limit),
    .grd_cfg_dom(cfg_dom), .grd_cfg_rd(cfg_rd), .grd_cfg_wr(cfg_wr), .grd_cfg_valid(cfg_valid)
  );

  localparam longint unsigned SRAM  = 64'h1000_0000;                // host side
  localparam longint unsigned DSRAM = 64'h0000_0001_1000_0000;      // device side of the same bytes
  localparam bit [3:0] DENIED = 4'd2, UR = 4'd1;

  // ---- independent window model (device addresses) ---------------------------------------------------------------
  typedef struct { bit v; bit [7:0] dom; longint unsigned base, limit; bit rd, wr; } win_t;
  win_t win [8];

  task automatic prog(input int idx, input bit v, input bit [7:0] dom, input longint unsigned base_dev,
                      input longint unsigned limit_dev, input bit rd, input bit wr);
    @(negedge clk);
    cfg_we <= 1'b1; cfg_idx <= 3'(idx); cfg_base <= base_dev; cfg_limit <= limit_dev; cfg_dom <= dom;
    cfg_rd <= rd; cfg_wr <= wr; cfg_valid <= v;
    @(negedge clk);
    cfg_we <= 1'b0;
    win[idx].v = v; win[idx].dom = dom; win[idx].base = base_dev; win[idx].limit = limit_dev; win[idx].rd = rd; win[idx].wr = wr;
  endtask

  // does the model permit [a, a+len-1] (device addresses) for this domain / operation?
  function automatic bit permit(input bit [7:0] dom, input bit is_wr, input longint unsigned a, input int len);
    longint unsigned last;
    last = a + len - 1;
    if (dom == 8'hFF) return 1'b0;
    if (dom == 8'h00) return 1'b1;                                   // ROOT_BYPASS (reference guard default)
    for (int i = 0; i < 8; i++) begin
      if (win[i].v && win[i].dom == dom && a >= win[i].base && last <= win[i].limit && (is_wr ? win[i].wr : win[i].rd)) return 1'b1;
    end
    return 1'b0;
  endfunction

  function automatic int words_of(input longint unsigned a, input int len);
    return (int'(a[3:0]) + len + 15) / 16;
  endfunction

  // ---- invariant: every ALP word that crossed the fabric link is permitted by the model --------------------------------
  int alp_violations = 0;
  always @(posedge clk) begin
    if (rst_n && u_env.m_req_valid && u_env.m_req_ready) begin
      longint unsigned a;
      bit              w;
      a = u_env.m_req.addr;
      w = (u_env.m_req.op == sf_albion_pkg::SF_OP_WRITE);
      if (!permit(u_env.m_req.dom, w, a, 16)) begin
        alp_violations++;
        tb_fail($sformatf("ALP word reached the fabric although the policy denies it: dom=%h op=%0d addr=%h", u_env.m_req.dom, u_env.m_req.op, a));
      end
    end
  end

  task automatic rd(input bit [7:0] dom, input longint unsigned off, input int len, input int exp_st);
    u_env.u_host.post_rd(8'(tb_below(256)), SRAM + off, len, dom, exp_st, 1'b1);
  endtask
  task automatic wr(input bit [7:0] dom, input longint unsigned off, input int len, input int exp_st, input bit posted);
    u_env.u_host.post_wr(8'(tb_below(256)), SRAM + off, len, dom, posted, exp_st, 1'b1, 0);
  endtask
  task automatic drain();
    u_env.u_host.wait_req_idle(400000);
  endtask

  initial begin
    int alp0;
    tb_seed(32'd31337 + LAT);
    for (int i = 0; i < 8; i++) win[i].v = 1'b0;
    #1 rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n <= 1'b1;
    repeat (1100) @(negedge clk);

    // ---- G0: default deny
    tb_check(u_env.gen_guard.u_guard.w_valid_q == '0, "G0: guard windows must be invalid after reset (default deny)");
    alp0 = u_env.alp_reqs;
    u_env.u_host.post_rd(8'd91, SRAM + 64'h40, 16, 8'h10, int'(DENIED), 1'b1);
    u_env.u_host.post_wr(8'd92, SRAM + 64'h40, 16, 8'h10, 1'b0, int'(DENIED), 1'b1, 0);
    u_env.u_host.post_wr(8'd93, SRAM + 64'h40, 100, 8'h10, 1'b0, int'(DENIED), 1'b1, 0);    // 7 words of data are drained
    drain();
    tb_check(u_env.alp_reqs == alp0, "G0: a denied request produced ALP traffic");
    u_env.expect_evt(2'd0, DENIED, 8'd91, SRAM + 64'h40, 20);
    u_env.expect_evt(2'd0, DENIED, 8'd92, SRAM + 64'h40, 20);
    u_env.expect_evt(2'd0, DENIED, 8'd93, SRAM + 64'h40, 20);
    u_env.expect_no_evt(10);
    // ROOT is the only domain that can act with no window (bootstrap)
    wr(8'h00, 64'h40, 16, 0, 1'b0);
    rd(8'h00, 64'h40, 16, 0);
    drain();
    $display("G0 default deny: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- program windows (device addresses; all 16-byte aligned)
    prog(0, 1'b1, 8'h10, DSRAM + 64'h000, DSRAM + 64'h7FF, 1'b1, 1'b1);     // tenant 0x10: first 2 KiB, read/write
    prog(1, 1'b1, 8'h11, DSRAM + 64'h800, DSRAM + 64'hBFF, 1'b1, 1'b0);     // tenant 0x11: next 1 KiB, read only
    prog(2, 1'b1, 8'h12, DSRAM + 64'hC00, DSRAM + 64'hDFF, 1'b1, 1'b1);     // tenant 0x12: two ADJACENT windows
    prog(3, 1'b1, 8'h12, DSRAM + 64'hE00, DSRAM + 64'hFFF, 1'b1, 1'b1);

    // ---- G1: what the guard is shown
    u_env.grd_log.delete();
    wr(8'h10, 64'h47, 20, 0, 1'b0);
    rd(8'h11, 64'h900, 8, 0);
    drain();
    tb_check(u_env.grd_log.size() == 2, $sformatf("G1: guard saw %0d checks, expected 2", u_env.grd_log.size()));
    if (u_env.grd_log.size() >= 2) begin
      tb_check(u_env.grd_log[0].dom == 8'h10 && u_env.grd_log[0].op == sf_albion_pkg::SF_OP_WRITE &&
               u_env.grd_log[0].addr == DSRAM + 64'h47 && u_env.grd_log[0].len == 20 && u_env.grd_log[0].attr == 8'h00,
               $sformatf("G1: check 0 shown as dom=%h op=%0d addr=%h len=%0d attr=%h", u_env.grd_log[0].dom, u_env.grd_log[0].op,
                         u_env.grd_log[0].addr, u_env.grd_log[0].len, u_env.grd_log[0].attr));
      tb_check(u_env.grd_log[1].dom == 8'h11 && u_env.grd_log[1].op == sf_albion_pkg::SF_OP_READ &&
               u_env.grd_log[1].addr == DSRAM + 64'h900 && u_env.grd_log[1].len == 8 && u_env.grd_log[1].permit,
               "G1: check 1 (translated address / length / permit) wrong");
    end
    $display("G1 what the guard sees: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- G2: exact permit / deny
    alp0 = u_env.alp_reqs;
    wr(8'h10, 64'h000, 2048, 0, 1'b0);                        // the whole window
    rd(8'h10, 64'h000, 2048, 0);
    wr(8'h10, 64'h7F0, 16, 0, 1'b0);                          // last word of the window
    wr(8'h10, 64'h7F8, 16, int'(DENIED), 1'b0);               // one word hangs out of the window
    wr(8'h10, 64'h800, 16, int'(DENIED), 1'b0);               // the neighbour's window
    rd(8'h11, 64'h800, 1024, 0);                              // read-only tenant reads its window
    wr(8'h11, 64'h800, 16, int'(DENIED), 1'b0);               // ... but may not write
    wr(8'h11, 64'h800, 16, int'(DENIED), 1'b1);               // posted: dropped, event only
    rd(8'h11, 64'h7F0, 16, int'(DENIED));                     // another tenant's memory
    rd(8'h13, 64'h000, 16, int'(DENIED));                     // a tenant with no window at all
    rd(8'h12, 64'hC00, 512, 0);                               // tenant 0x12, first of its two windows
    rd(8'h12, 64'hDF0, 32, int'(DENIED));                     // spans two windows that BOTH allow it: denied by policy
    rd(8'h12, 64'hE00, 512, 0);
    drain();
    $display("G2 exact permit/deny: checks=%0d errors=%0d (alp words issued %0d)", tb_checks, tb_errors, u_env.alp_reqs - alp0);

    // ---- G6: no layout oracle: foreign memory and "no window anywhere" are indistinguishable
    //  (both DENIED above: the statuses are equal by construction; the aperture-only UR exists for addresses outside every aperture)
    rd(8'h10, 64'h3F00, 16, int'(DENIED));                    // inside the aperture, nobody's window
    drain();

    // ---- G5: revocation and re-grant
    prog(0, 1'b0, 8'h10, DSRAM + 64'h000, DSRAM + 64'h7FF, 1'b1, 1'b1);     // revoke tenant 0x10
    rd(8'h10, 64'h000, 16, int'(DENIED));
    wr(8'h10, 64'h000, 64, int'(DENIED), 1'b0);
    drain();                                                                  // the requests above must meet the revoked window
    prog(0, 1'b1, 8'h10, DSRAM + 64'h000, DSRAM + 64'h3FF, 1'b1, 1'b1);     // re-grant a smaller window
    rd(8'h10, 64'h000, 1024, 0);
    rd(8'h10, 64'h400, 16, int'(DENIED));
    drain();
    $display("G5 revocation: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- G3: random storm checked against the independent policy model
    prog(0, 1'b1, 8'h10, DSRAM + 64'h000, DSRAM + 64'h7FF, 1'b1, 1'b1);
    for (int round = 0; round < 6; round++) begin
      int n_perm, n_deny;
      n_perm = 0; n_deny = 0;
      u_env.u_host.cfg_req_gap = tb_below(40); u_env.u_host.cfg_hw_gap = tb_below(40); u_env.u_host.cfg_cpl_rdy = 30 + tb_below(71);
      for (int i = 0; i < 150; i++) begin
        bit [7:0] dom;
        bit       w, p;
        longint unsigned off, dev;
        int len, st;
        case (tb_below(6))
          0: dom = 8'h10; 1: dom = 8'h11; 2: dom = 8'h12; 3: dom = 8'h13; 4: dom = 8'h00; default: dom = 8'h10;
        endcase
        w   = tb_pct(50);
        p   = w && tb_pct(20);
        off = tb_below(4096 - 4);
        len = tb_range(1, 4096 - int'(off));
        if (len > 600) len = tb_range(1, 600);
        if (off + len > 4096) len = 4096 - int'(off);
        dev = DSRAM + off;
        st  = permit(dom, w, dev, len) ? 0 : int'(DENIED);
        if (st == 0) n_perm++; else n_deny++;
        if (w) u_env.u_host.post_wr(8'(tb_below(256)), SRAM + off, len, dom, p, st, 1'b1, tb_below(2));
        else   u_env.u_host.post_rd(8'(tb_below(256)), SRAM + off, len, dom, st, 1'b1);
      end
      drain();
      tb_cov("guard_storm_permit");   tb_cov("guard_storm_deny");
      $display("G3 round %0d: permitted=%0d denied=%0d  checks=%0d errors=%0d", round, n_perm, n_deny, tb_checks, tb_errors);
      u_env.evt_log.delete();
    end
    tb_check(alp_violations == 0, "G3: ALP words issued although denied");

    // ---- G7: the guard's verdict status is mapped to the host-visible status (OKAY with no permit is never a grant)
    prog(0, 1'b1, 8'h10, DSRAM + 64'h000, DSRAM + 64'h7FF, 1'b1, 1'b1);
    begin
      //  ALP status of the denial -> expected HTI status
      int stat [11] = '{0, 1, 2, 3, 6, 7, 8, 10, 11, 4, 5};
      int hexp [11] = '{2, 1, 2, 9, 9, 3, 8, 4, 10, 9, 9};
      u_env.gen_guard.force_deny = 1'b1;
      for (int i = 0; i < 11; i++) begin
        u_env.gen_guard.force_status = 4'(stat[i]);
        u_env.u_host.post_rd(8'(200 + i), SRAM + 64'h10, 16, 8'h10, hexp[i], 1'b1);
        drain();
      end
      u_env.gen_guard.force_deny = 1'b0;
    end
    $display("G7 guard status mapping: checks=%0d errors=%0d", tb_checks, tb_errors);

    // ---- final accounting
    tb_check(u_env.u_dut.host_outstanding_o == 0 && !u_env.u_dut.host_busy_o, "bridge not idle at the end");
    tb_check(!u_env.fatal, "fatal latched");
    repeat (20) @(negedge clk);
    tb_report("tb_hb_guard");
    $finish;
  end

  initial begin
    #600000000;
    tb_fail("guard: global timeout");
    tb_report("tb_hb_guard");
    $finish;
  end
endmodule

`default_nettype wire
