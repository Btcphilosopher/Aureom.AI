// =============================================================================
//  sf_albion_host_csr.sv  --  HostBridge demonstration register block (ALP v1 target)
// -----------------------------------------------------------------------------
//  Memory-mapped registers of the demonstration SoC: identification, scratch, bridge control and status, the
//  error log, the DMA engine and the DomainGuard window table.  Register map: sf_albion_host_pkg (SF_HB_CSR_*).
//  32-bit registers at a 4-byte stride; the four registers of one 16-byte word are lanes [3:0] .. [15:12].
//
//  ALP target behaviour
//    * legality (ALP-LEG-01) first; an offset beyond the 512-byte register space -> DECODE_ERR; then rights
//    * the response appears at least one cycle after acceptance, is held until accepted, in order
//    * reads return zero in lanes whose byte enable is clear (ALP-RSP-07); an error response carries zero data
//    * writes take effect at acceptance and only if the WHOLE request is permitted: a word in which any enabled
//      register is not writable by the requester is denied with no partial effect
//
//  Rights (the demonstration policy)
//    read-only registers (ID, VERSION, CAPS, STATUS, OUT_*, ERR_*, UNEXP_CPL, DMA_STATUS, DMA_BYTES): a write is denied
//    privileged registers (CONTROL, DMA_SRC..DMA_CTRL writes, every GUARD_* access): require the privileged
//    attribute AND domain ROOT or MGMT, the same rule Citadel's configuration port applies.  The guard window table
//    is therefore programmable only from the management plane, never by a tenant, even if a guard window let the
//    tenant's request reach this block.
//
//  Guard window i (8 registers at GUARD_BASE + i*32): BASE_LO, BASE_HI, LIMIT_LO, LIMIT_HI, ATTR.  Writing ATTR
//  commits the window: {dom[15:8], wr[2], rd[1], valid[0]}.
// =============================================================================
`default_nettype none

module sf_albion_host_csr #(
  parameter int unsigned NUM_WIN  = 8,
  parameter int unsigned NUM_TAGS = 8,
  parameter int unsigned MAX_OUT  = 8,
  parameter bit          GUARD_EN = 1'b1
) (
  input  wire logic                         clk_i,
  input  wire logic                         rst_ni,
  // ---- ALP v1 target -----------------------------------------------------------------
  input  wire logic                         req_valid_i,
  output logic                              req_ready_o,
  input  sf_albion_pkg::sf_req_t            req_i,
  output logic                              rsp_valid_o,
  input  wire logic                         rsp_ready_i,
  output sf_albion_pkg::sf_rsp_t            rsp_o,
  // ---- bridge status and event log ---------------------------------------------------------
  input  wire logic                         host_busy_i,
  input  wire logic                         dma_busy_i,
  input  wire logic                         fatal_i,
  input  wire logic [15:0]                  host_outstanding_i,
  input  wire logic [15:0]                  dma_outstanding_i,
  input  wire logic [15:0]                  unexpected_cpl_i,
  input  wire logic                         evt_valid_i,
  output logic                              evt_ready_o,
  input  wire logic [1:0]                   evt_src_i,
  input  wire logic [3:0]                   evt_code_i,
  input  wire logic [7:0]                   evt_tag_i,
  input  wire logic [63:0]                  evt_addr_i,
  // ---- controls ------------------------------------------------------------------------------
  output logic                              cancel_o,
  output logic                              grd_cfg_we_o,
  output logic [(NUM_WIN > 1 ? $clog2(NUM_WIN) : 1)-1:0] grd_cfg_idx_o,
  output logic [63:0]                       grd_cfg_base_o,
  output logic [63:0]                       grd_cfg_limit_o,
  output logic [7:0]                        grd_cfg_dom_o,
  output logic                              grd_cfg_rd_o,
  output logic                              grd_cfg_wr_o,
  output logic                              grd_cfg_valid_o,
  // ---- DMA engine ----------------------------------------------------------------------------------
  output logic [63:0]                       dma_src_o,
  output logic [63:0]                       dma_dst_o,
  output logic [31:0]                       dma_len_o,
  output logic                              dma_dir_o,
  output logic                              dma_posted_o,
  output logic                              dma_start_o,
  input  wire logic                         dma_busy_eng_i,
  input  wire logic                         dma_done_i,
  input  wire logic [3:0]                   dma_status_i,
  input  wire logic [31:0]                  dma_bytes_i
);
  localparam int unsigned IW = (NUM_WIN > 1) ? $clog2(NUM_WIN) : 1;
  localparam int unsigned GW0 = sf_albion_host_pkg::SF_HB_CSR_GUARD_BASE / 4;      // first guard register index
  localparam int unsigned GWN = GW0 + 8 * NUM_WIN;                                 // one past the last

  if (NUM_WIN < 1 || NUM_WIN > 8) begin : gen_param_check_win
    $error("sf_albion_host_csr: NUM_WIN must be in 1..8");
  end

  // ---------------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------------
  logic [31:0] scratch_q, scratch_d;
  logic [63:0] src_q, src_d, dst_q, dst_d;
  logic [31:0] len_q, len_d;
  logic        dir_q, dir_d, posted_q, posted_d;
  logic        start_q, start_d, cancel_q, cancel_d;
  logic [63:0] gw_base_q [NUM_WIN];
  logic [63:0] gw_base_d [NUM_WIN];
  logic [63:0] gw_limit_q [NUM_WIN];
  logic [63:0] gw_limit_d [NUM_WIN];
  logic [31:0] gw_attr_q [NUM_WIN];
  logic [31:0] gw_attr_d [NUM_WIN];
  logic        gcfg_we_q, gcfg_we_d;
  logic [IW-1:0] gcfg_idx_q, gcfg_idx_d;
  logic [31:0] err_cnt_q, err_cnt_d;
  logic        err_first_q, err_first_d;
  logic [31:0] err_info_q, err_info_d;
  logic [63:0] err_addr_q, err_addr_d;
  logic        err_clear;

  assign evt_ready_o = 1'b1;

  // ---------------------------------------------------------------------------
  // Request decode (combinational on the live request; the response is registered in a FIFO)
  // ---------------------------------------------------------------------------
  logic [6:0]  ridx [4];            // register index of each dword of the word
  logic [3:0]  dbe  [4];            // byte enables of each dword
  logic [31:0] rv   [4];            // current value / read value of each register
  logic        r_ro [4];            // the register is read-only
  logic        r_pw [4];            // writing it needs privilege
  logic        r_pr [4];            // reading it needs privilege
  logic        priv_ok;
  logic        in_space;
  logic        is_write;
  logic        deny;
  logic [3:0]  legal, status;
  logic        accept;
  logic        do_write;

  // Tool hazard (Yosys 0.33): a bit-select of a packed-struct member with a package-scoped index segfaults the
  // front end.  Select the bit from a plain vector copy of the field instead.
  logic [sf_albion_pkg::SF_ATTR_W-1:0] req_attr;
  assign req_attr = req_i.attr;
  assign is_write = (req_i.op == sf_albion_pkg::SF_OP_WRITE);
  assign priv_ok  = (req_i.dom <= sf_albion_pkg::SF_DOM_MGMT) && req_attr[sf_albion_pkg::SF_ATTR_PRIV_BIT];
  assign in_space = (req_i.addr[sf_albion_pkg::SF_ADDR_W-1:9] == '0);

  always_comb begin
    for (int unsigned d = 0; d < 4; d++) begin
      ridx[d] = {req_i.addr[8:4], 2'(d)};
      dbe[d]  = req_i.be[4*d +: 4];
      rv[d]   = 32'h0;
      r_ro[d] = 1'b0;
      r_pw[d] = 1'b0;
      r_pr[d] = 1'b0;
      if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_ID / 4)) begin
        rv[d] = sf_albion_host_pkg::SF_HB_ID_VALUE; r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_VERSION / 4)) begin
        rv[d] = {8'h00, 8'(sf_albion_host_pkg::SF_HB_LIB_MAJOR), 8'(sf_albion_host_pkg::SF_HB_LIB_MINOR),
                 8'(sf_albion_host_pkg::SF_HB_LIB_PATCH)};
        r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_CAPS / 4)) begin
        rv[d] = {8'(NUM_TAGS), 8'(MAX_OUT), GUARD_EN, 15'h0}; r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_SCRATCH / 4)) begin
        rv[d] = scratch_q;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_CONTROL / 4)) begin
        r_pw[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_STATUS / 4)) begin
        rv[d] = {28'h0, dma_busy_eng_i, fatal_i, dma_busy_i, host_busy_i}; r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_OUT_HOST / 4)) begin
        rv[d] = {16'h0, host_outstanding_i}; r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_OUT_DMA / 4)) begin
        rv[d] = {16'h0, dma_outstanding_i}; r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_ERR_COUNT / 4)) begin
        rv[d] = err_cnt_q; r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_ERR_INFO / 4)) begin
        rv[d] = err_info_q; r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_ERR_ALO / 4)) begin
        rv[d] = err_addr_q[31:0]; r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_ERR_AHI / 4)) begin
        rv[d] = err_addr_q[63:32]; r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_UNEXP_CPL / 4)) begin
        rv[d] = {16'h0, unexpected_cpl_i}; r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_SRC_LO / 4)) begin
        rv[d] = src_q[31:0];  r_pw[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_SRC_HI / 4)) begin
        rv[d] = src_q[63:32]; r_pw[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_DST_LO / 4)) begin
        rv[d] = dst_q[31:0];  r_pw[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_DST_HI / 4)) begin
        rv[d] = dst_q[63:32]; r_pw[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_LEN / 4)) begin
        rv[d] = len_q;        r_pw[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_CTRL / 4)) begin
        rv[d] = {29'h0, posted_q, dir_q, 1'b0}; r_pw[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_STATUS / 4)) begin
        rv[d] = {24'h0, dma_status_i, 2'b00, dma_done_i, dma_busy_eng_i}; r_ro[d] = 1'b1;
      end else if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_BYTES / 4)) begin
        rv[d] = dma_bytes_i; r_ro[d] = 1'b1;
      end else if ({1'b0, ridx[d]} >= 8'(GW0) && {1'b0, ridx[d]} < 8'(GWN)) begin   // GWN can be 128: 8-bit compare
        // guard window table: privileged for read and write
        r_pw[d] = 1'b1;
        r_pr[d] = 1'b1;
        for (int unsigned w = 0; w < NUM_WIN; w++) begin
          if (ridx[d] == 7'(GW0 + 8*w + 0)) rv[d] = gw_base_q[w][31:0];
          if (ridx[d] == 7'(GW0 + 8*w + 1)) rv[d] = gw_base_q[w][63:32];
          if (ridx[d] == 7'(GW0 + 8*w + 2)) rv[d] = gw_limit_q[w][31:0];
          if (ridx[d] == 7'(GW0 + 8*w + 3)) rv[d] = gw_limit_q[w][63:32];
          if (ridx[d] == 7'(GW0 + 8*w + 4)) rv[d] = gw_attr_q[w];
        end
      end
    end
  end

  always_comb begin
    deny = 1'b0;
    for (int unsigned d = 0; d < 4; d++) begin
      if (dbe[d] != 4'h0) begin
        if (is_write) begin
          if (r_ro[d] || (r_pw[d] && !priv_ok)) deny = 1'b1;
        end else begin
          if (r_pr[d] && !priv_ok) deny = 1'b1;
        end
      end
    end
    legal  = sf_albion_pkg::sf_req_check_bits(req_i);
    status = sf_albion_pkg::SF_ST_OKAY;
    if (legal != sf_albion_pkg::SF_ST_OKAY)  status = legal;
    else if (!in_space)                      status = sf_albion_pkg::SF_ST_DECODE_ERR;
    else if (deny)                           status = sf_albion_pkg::SF_ST_ACCESS_DENIED;
  end

  // ---------------------------------------------------------------------------
  // Response FIFO (one entry per accepted request, in order)
  // ---------------------------------------------------------------------------
  logic [sf_albion_pkg::SF_RSP_W-1:0] rsp_d_bits, rsp_q_bits;
  sf_albion_pkg::sf_rsp_t              rsp_d;
  logic [127:0]                        rd_word, be_exp;
  logic                                fifo_in_ready;

  always_comb begin
    rd_word = {rv[3], rv[2], rv[1], rv[0]};
    for (int unsigned b = 0; b < 16; b++) be_exp[b*8 +: 8] = {8{req_i.be[b]}};
    rsp_d               = '0;
    rsp_d.tag           = req_i.tag;
    rsp_d.status        = status;
    rsp_d.meta.last     = 1'b1;
    rsp_d.meta.is_write = is_write;
    rsp_d.data          = (status == sf_albion_pkg::SF_ST_OKAY && !is_write) ? (rd_word & be_exp) : 128'h0;
    rsp_d_bits          = rsp_d;
  end

  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(sf_albion_pkg::SF_RSP_W), .DEPTH(2)) u_rsp_fifo (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (req_valid_i), .in_ready_o(fifo_in_ready), .in_data_i(rsp_d_bits),
    .out_valid_o(rsp_valid_o), .out_ready_i(rsp_ready_i), .out_data_o(rsp_q_bits),
    .count_o(), .full_o(), .empty_o()
  );
  /* verilator lint_on PINCONNECTEMPTY */
  assign rsp_o       = rsp_q_bits;
  assign req_ready_o = fifo_in_ready;
  assign accept      = req_valid_i && fifo_in_ready;
  assign do_write    = accept && is_write && (status == sf_albion_pkg::SF_ST_OKAY);

  // ---------------------------------------------------------------------------
  // Register updates
  // ---------------------------------------------------------------------------
  logic [31:0] wnew [4];
  logic [31:0] wmask [4];
  always_comb begin
    for (int unsigned d = 0; d < 4; d++) begin
      wmask[d] = {{8{dbe[d][3]}}, {8{dbe[d][2]}}, {8{dbe[d][1]}}, {8{dbe[d][0]}}};
      wnew[d]  = (rv[d] & ~wmask[d]) | (req_i.data[32*d +: 32] & wmask[d]);
    end

    scratch_d = scratch_q;
    src_d = src_q; dst_d = dst_q; len_d = len_q; dir_d = dir_q; posted_d = posted_q;
    start_d = 1'b0; cancel_d = 1'b0; err_clear = 1'b0;
    gcfg_we_d = 1'b0; gcfg_idx_d = gcfg_idx_q;
    for (int unsigned w = 0; w < NUM_WIN; w++) begin
      gw_base_d[w] = gw_base_q[w]; gw_limit_d[w] = gw_limit_q[w]; gw_attr_d[w] = gw_attr_q[w];
    end

    if (do_write) begin
      for (int unsigned d = 0; d < 4; d++) begin
        if (dbe[d] != 4'h0) begin
          if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_SCRATCH / 4))     scratch_d = wnew[d];
          if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_CONTROL / 4)) begin
            if (wnew[d][0] && dbe[d][0]) cancel_d = 1'b1;
            if (wnew[d][1] && dbe[d][0]) err_clear = 1'b1;
          end
          if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_SRC_LO / 4))  src_d[31:0]  = wnew[d];
          if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_SRC_HI / 4))  src_d[63:32] = wnew[d];
          if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_DST_LO / 4))  dst_d[31:0]  = wnew[d];
          if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_DST_HI / 4))  dst_d[63:32] = wnew[d];
          if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_LEN / 4))     len_d        = wnew[d];
          if (ridx[d] == 7'(sf_albion_host_pkg::SF_HB_CSR_DMA_CTRL / 4)) begin
            dir_d    = wnew[d][1];
            posted_d = wnew[d][2];
            if (wnew[d][0] && dbe[d][0]) start_d = 1'b1;
          end
          for (int unsigned w = 0; w < NUM_WIN; w++) begin
            if (ridx[d] == 7'(GW0 + 8*w + 0)) gw_base_d[w][31:0]   = wnew[d];
            if (ridx[d] == 7'(GW0 + 8*w + 1)) gw_base_d[w][63:32]  = wnew[d];
            if (ridx[d] == 7'(GW0 + 8*w + 2)) gw_limit_d[w][31:0]  = wnew[d];
            if (ridx[d] == 7'(GW0 + 8*w + 3)) gw_limit_d[w][63:32] = wnew[d];
            if (ridx[d] == 7'(GW0 + 8*w + 4)) begin
              gw_attr_d[w] = wnew[d];
              gcfg_we_d    = 1'b1;                       // writing ATTR commits the window to the guard
              gcfg_idx_d   = IW'(w);
            end
          end
        end
      end
    end

    // error log: count every event, keep the first one until it is cleared
    err_cnt_d = err_cnt_q; err_first_d = err_first_q; err_info_d = err_info_q; err_addr_d = err_addr_q;
    if (err_clear) begin
      err_cnt_d = 32'h0; err_first_d = 1'b0; err_info_d = 32'h0; err_addr_d = 64'h0;
    end else if (evt_valid_i) begin
      if (err_cnt_q != 32'hFFFF_FFFF) err_cnt_d = err_cnt_q + 32'd1;
      if (!err_first_q) begin
        err_first_d = 1'b1;
        err_info_d  = {18'h0, evt_src_i, evt_code_i, evt_tag_i};
        err_addr_d  = evt_addr_i;
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      scratch_q   <= 32'h0;
      src_q       <= 64'h0;
      dst_q       <= 64'h0;
      len_q       <= 32'h0;
      dir_q       <= 1'b0;
      posted_q    <= 1'b0;
      start_q     <= 1'b0;
      cancel_q    <= 1'b0;
      gcfg_we_q   <= 1'b0;
      gcfg_idx_q  <= '0;
      err_cnt_q   <= 32'h0;
      err_first_q <= 1'b0;
      err_info_q  <= 32'h0;
      err_addr_q  <= 64'h0;
      for (int unsigned w = 0; w < NUM_WIN; w++) begin
        gw_base_q[w] <= 64'h0; gw_limit_q[w] <= 64'h0; gw_attr_q[w] <= 32'h0;
      end
    end else begin
      scratch_q   <= scratch_d;
      src_q       <= src_d;
      dst_q       <= dst_d;
      len_q       <= len_d;
      dir_q       <= dir_d;
      posted_q    <= posted_d;
      start_q     <= start_d;
      cancel_q    <= cancel_d;
      gcfg_we_q   <= gcfg_we_d;
      gcfg_idx_q  <= gcfg_idx_d;
      err_cnt_q   <= err_cnt_d;
      err_first_q <= err_first_d;
      err_info_q  <= err_info_d;
      err_addr_q  <= err_addr_d;
      for (int unsigned w = 0; w < NUM_WIN; w++) begin
        gw_base_q[w] <= gw_base_d[w]; gw_limit_q[w] <= gw_limit_d[w]; gw_attr_q[w] <= gw_attr_d[w];
      end
    end
  end

  // outputs
  assign cancel_o        = cancel_q;
  assign dma_src_o       = src_q;
  assign dma_dst_o       = dst_q;
  assign dma_len_o       = len_q;
  assign dma_dir_o       = dir_q;
  assign dma_posted_o    = posted_q;
  assign dma_start_o     = start_q;
  assign grd_cfg_we_o    = gcfg_we_q;
  assign grd_cfg_idx_o   = gcfg_idx_q;
  assign grd_cfg_base_o  = gw_base_q[gcfg_idx_q];
  assign grd_cfg_limit_o = gw_limit_q[gcfg_idx_q];
  assign grd_cfg_dom_o   = gw_attr_q[gcfg_idx_q][15:8];
  assign grd_cfg_rd_o    = gw_attr_q[gcfg_idx_q][1];
  assign grd_cfg_wr_o    = gw_attr_q[gcfg_idx_q][2];
  assign grd_cfg_valid_o = gw_attr_q[gcfg_idx_q][0];
endmodule

`default_nettype wire
