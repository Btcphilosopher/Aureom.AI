// =============================================================================
//  sf_albion_host_dma_engine.sv  --  demonstration DMA copy engine (DMA client of HostBridge)
// -----------------------------------------------------------------------------
//  Copies between HOST memory (through the bridge's DMA client port) and device SRAM (through an ALP v1
//  initiator link).  Programmed through the CSR block: source, destination, length, direction, posted flag, start.
//
//    dir = 0  host -> SRAM :  src = host address, dst = device (ALP) address
//    dir = 1  SRAM -> host :  src = device (ALP) address, dst = host address
//
//  Addresses and length must be multiples of 16 (one ALP word); anything else ends at once with SF_HS_BAD_REQ.
//  The bridge itself accepts any alignment; the restriction is this engine's.
//
//  No data buffer: H2D turns every dma_r beat directly into one ALP WRITE; D2H turns every ALP READ response
//  directly into one dma_w beat.  A failure on either side is remembered (first one wins), the transfer is
//  completed in a protocol-correct way (a started write packet always receives all its beats, with strobes cleared
//  for words that could not be read) and the status is reported when the transfer ends.
//
//  ALP side: tags and the outstanding limit come from sf_albion_tag_tracker; the request link register holds its
//  payload until accepted (ALP-REQ-02); responses are always accepted in H2D mode, and in D2H mode m_rsp_ready_o
//  depends only on dma_w_ready_i (ALP-RSP-06).
// =============================================================================
`default_nettype none

module sf_albion_host_dma_engine #(
  parameter int unsigned MAX_OUT = 8,
  parameter logic [7:0]  DOM     = 8'h02,      // SF_DOM_SYS_DMA: the engine acts for itself
  parameter logic [7:0]  ATTR    = 8'h00       // ALP attribute byte of its SRAM accesses
) (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,
  // ---- control (CSR block) --------------------------------------------------------------------
  input  wire logic              start_i,
  input  wire logic [63:0]       src_i,
  input  wire logic [63:0]       dst_i,
  input  wire logic [31:0]       len_i,
  input  wire logic              dir_i,
  input  wire logic              posted_i,
  output logic                   busy_o,
  output logic                   done_o,
  output logic [3:0]             status_o,
  output logic [31:0]            bytes_o,
  // ---- ALP v1 initiator (SRAM side) -------------------------------------------------------------
  output logic                   m_req_valid_o,
  input  wire logic              m_req_ready_i,
  output sf_albion_pkg::sf_req_t m_req_o,
  input  wire logic              m_rsp_valid_i,
  output logic                   m_rsp_ready_o,
  input  sf_albion_pkg::sf_rsp_t m_rsp_i,
  // ---- HostBridge DMA client port -----------------------------------------------------------------
  output logic                   dma_req_valid_o,
  input  wire logic              dma_req_ready_i,
  output logic                   dma_req_write_o,
  output logic                   dma_req_posted_o,
  output logic [63:0]            dma_req_addr_o,
  output logic [23:0]            dma_req_len_o,
  output logic [7:0]             dma_req_id_o,
  output logic                   dma_w_valid_o,
  input  wire logic              dma_w_ready_i,
  output logic [127:0]           dma_w_data_o,
  output logic [15:0]            dma_w_be_o,
  output logic                   dma_w_last_o,
  input  wire logic              dma_r_valid_i,
  output logic                   dma_r_ready_o,
  input  wire logic [7:0]        dma_r_id_i,
  input  wire logic [3:0]        dma_r_status_i,
  input  wire logic              dma_r_is_write_i,
  input  wire logic [127:0]      dma_r_data_i,
  input  wire logic [15:0]       dma_r_be_i,
  input  wire logic              dma_r_last_i
);
  localparam logic [2:0] E_IDLE = 3'd0;
  localparam logic [2:0] E_REQ  = 3'd1;
  localparam logic [2:0] E_H2D  = 3'd2;
  localparam logic [2:0] E_D2H  = 3'd3;
  localparam logic [2:0] E_FIN  = 3'd4;

  localparam int unsigned NW_W = 21;      // words of a transfer: len / 16, len <= 2**24 - 16

  logic [2:0]            st_q, st_d;
  logic [63:0]           src_q, src_d, dst_q, dst_d;
  logic [23:0]           len_q, len_d;
  logic [NW_W-1:0]       nw_q, nw_d;
  logic                  dir_q, dir_d, posted_q, posted_d;
  logic [NW_W-1:0]       ridx_q, ridx_d;       // words issued (D2H reads) or consumed (H2D beats)
  logic [NW_W-1:0]       widx_q, widx_d;       // D2H: words forwarded to dma_w
  logic [3:0]            err_q, err_d;
  logic                  last_seen_q, last_seen_d;   // H2D: the final beat or an error terminator was taken
  logic                  r_seen_q, r_seen_d;         // D2H: the write result was received
  logic                  busy_q, busy_d, done_q, done_d;
  logic [3:0]            status_q, status_d;
  logic [31:0]           bytes_q, bytes_d;
  logic                  mv_q, mv_d;
  logic [sf_albion_pkg::SF_REQ_W-1:0] mreq_q, mreq_d;

  // ---- ALP tag tracker -----------------------------------------------------------------------------------
  logic                  alloc_valid, alloc_ready;
  logic [sf_albion_pkg::SF_TAG_W-1:0] alloc_tag;
  logic                  free_valid;
  logic                  trk_empty;
  logic [$clog2(MAX_OUT+1)-1:0] trk_out;
  logic                  trk_sticky;

  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_tag_tracker #(.NUM_TAGS(MAX_OUT), .CTX_W(1), .CHECK_ORDER(1'b1)) u_trk (
    .clk_i, .rst_ni,
    .alloc_valid_i(alloc_valid), .alloc_ready_o(alloc_ready), .alloc_tag_o(alloc_tag), .alloc_ctx_i(1'b0),
    .free_valid_i (free_valid),  .free_tag_i(m_rsp_i.tag), .free_ctx_o(),
    .free_drop_o(), .free_unexpected_o(), .free_order_err_o(),
    .abandon_valid_i(1'b0), .abandon_tag_i('0), .abandon_all_i(1'b0),
    .outstanding_o(trk_out), .full_o(), .empty_o(trk_empty), .sticky_err_o(trk_sticky)
  );
  /* verilator lint_on PINCONNECTEMPTY */

  logic unused_trk;
  assign unused_trk = &{1'b0, trk_out, trk_sticky};

  // ---- datapath ---------------------------------------------------------------------------------------------
  logic                  can_load;
  logic                  r_take, rd_go;
  logic                  rsp_ok;
  logic [3:0]            rsp_st;
  logic                  rsp_take;
  logic                  start_ok;
  logic                  len_bad;
  sf_albion_pkg::sf_req_t mreq_new;

  assign can_load = alloc_ready && (!mv_q || m_req_ready_i);
  assign len_bad  = (len_i == 32'd0) || (len_i[3:0] != 4'h0) || (len_i[31:24] != 8'h00) ||
                    (src_i[3:0] != 4'h0) || (dst_i[3:0] != 4'h0);
  assign start_ok = start_i && (st_q == E_IDLE);

  assign rsp_ok = sf_albion_pkg::sf_rsp_wellformed_bits(m_rsp_i) && (m_rsp_i.status == sf_albion_pkg::SF_ST_OKAY);
  assign rsp_st = sf_albion_pkg::sf_rsp_wellformed_bits(m_rsp_i)
                    ? sf_albion_host_pkg::sf_hti_status_from_alp(m_rsp_i.status)
                    : sf_albion_host_pkg::SF_HS_PROTO;

  // One request is in flight: a result beat that does not belong to it, or a data beat with missing strobes, is a
  // protocol violation of the bridge side and ends the transfer with SF_HS_PROTO.
  logic h2d_beat_bad, d2h_res_bad;
  assign h2d_beat_bad = (dma_r_id_i != 8'h01) || dma_r_is_write_i ||
                        ((dma_r_status_i == sf_albion_host_pkg::SF_HS_OK) && (dma_r_be_i != 16'hFFFF));
  assign d2h_res_bad  = (dma_r_id_i != 8'h01) || !dma_r_is_write_i || !dma_r_last_i;

  // H2D: a result beat becomes an ALP write when the link register is free
  assign dma_r_ready_o = (st_q == E_D2H) || ((st_q == E_H2D) && !last_seen_q && can_load);
  assign r_take        = dma_r_valid_i && dma_r_ready_o && (st_q == E_H2D);
  // D2H: read issue
  assign rd_go         = (st_q == E_D2H) && (ridx_q < nw_q) && can_load;

  assign alloc_valid = (r_take && (dma_r_status_i == sf_albion_host_pkg::SF_HS_OK)) || rd_go;

  always_comb begin
    mreq_new      = '0;
    mreq_new.op   = (st_q == E_H2D) ? sf_albion_pkg::SF_OP_WRITE : sf_albion_pkg::SF_OP_READ;
    mreq_new.tag  = alloc_tag;
    mreq_new.dom  = DOM;
    mreq_new.attr = ATTR;
    mreq_new.be   = 16'hFFFF;
    mreq_new.data = (st_q == E_H2D) ? dma_r_data_i : 128'h0;
    mreq_new.addr = (st_q == E_H2D) ? (dst_q + {{(64-NW_W-4){1'b0}}, ridx_q, 4'h0})
                                    : (src_q + {{(64-NW_W-4){1'b0}}, ridx_q, 4'h0});
  end

  // ALP responses
  assign m_rsp_ready_o = (st_q == E_D2H) ? dma_w_ready_i : 1'b1;
  assign rsp_take      = m_rsp_valid_i && m_rsp_ready_o;
  assign free_valid    = rsp_take;

  // D2H: each ALP response is one dma_w beat (strobes cleared when the word could not be read)
  assign dma_w_valid_o = (st_q == E_D2H) && m_rsp_valid_i && (widx_q < nw_q);
  assign dma_w_data_o  = rsp_ok ? m_rsp_i.data : 128'h0;
  assign dma_w_be_o    = rsp_ok ? 16'hFFFF : 16'h0000;
  assign dma_w_last_o  = (widx_q == nw_q - NW_W'(1));

  // DMA request
  assign dma_req_valid_o  = (st_q == E_REQ);
  assign dma_req_write_o  = dir_q;
  assign dma_req_posted_o = dir_q && posted_q;
  assign dma_req_addr_o   = dir_q ? dst_q : src_q;
  assign dma_req_len_o    = len_q;
  assign dma_req_id_o     = 8'h01;

  assign m_req_valid_o = mv_q;
  assign m_req_o       = mreq_q;
  assign busy_o        = busy_q;
  assign done_o        = done_q;
  assign status_o      = status_q;
  assign bytes_o       = bytes_q;

  always_comb begin
    st_d = st_q; src_d = src_q; dst_d = dst_q; len_d = len_q; nw_d = nw_q; dir_d = dir_q; posted_d = posted_q;
    ridx_d = ridx_q; widx_d = widx_q; err_d = err_q; last_seen_d = last_seen_q; r_seen_d = r_seen_q;
    busy_d = busy_q; done_d = done_q; status_d = status_q; bytes_d = bytes_q;
    mv_d = mv_q; mreq_d = mreq_q;

    if (mv_q && m_req_ready_i) mv_d = 1'b0;
    if (alloc_valid) begin
      mv_d   = 1'b1;
      mreq_d = mreq_new;
    end

    // first error wins
    if (rsp_take && (st_q == E_H2D) && !rsp_ok && (err_q == sf_albion_host_pkg::SF_HS_OK)) err_d = rsp_st;

    case (st_q)
      E_IDLE: begin
        if (start_ok) begin
          busy_d = 1'b1; done_d = 1'b0; status_d = sf_albion_host_pkg::SF_HS_OK; bytes_d = 32'h0;
          err_d = sf_albion_host_pkg::SF_HS_OK; last_seen_d = 1'b0; r_seen_d = 1'b0; ridx_d = '0; widx_d = '0;
          if (len_bad) begin
            err_d = sf_albion_host_pkg::SF_HS_BAD_REQ;
            st_d  = E_FIN;
          end else begin
            src_d = src_i; dst_d = dst_i; len_d = len_i[23:0]; nw_d = NW_W'(len_i[23:4]);
            dir_d = dir_i; posted_d = posted_i;
            st_d  = E_REQ;
          end
        end
      end
      E_REQ: begin
        if (dma_req_ready_i) st_d = dir_q ? E_D2H : E_H2D;
      end
      E_H2D: begin
        if (r_take) begin
          if (h2d_beat_bad && (err_q == sf_albion_host_pkg::SF_HS_OK)) err_d = sf_albion_host_pkg::SF_HS_PROTO;
          if (dma_r_status_i == sf_albion_host_pkg::SF_HS_OK) begin
            ridx_d = ridx_q + NW_W'(1);
            if (dma_r_last_i) last_seen_d = 1'b1;
          end else begin
            if (err_q == sf_albion_host_pkg::SF_HS_OK) err_d = dma_r_status_i;
            last_seen_d = 1'b1;
          end
        end
        if (last_seen_q && trk_empty && !mv_q) st_d = E_FIN;
      end
      E_D2H: begin
        if (rd_go) ridx_d = ridx_q + NW_W'(1);
        if (dma_w_valid_o && dma_w_ready_i) begin
          widx_d = widx_q + NW_W'(1);
          if (!rsp_ok && (err_q == sf_albion_host_pkg::SF_HS_OK)) err_d = rsp_st;
        end
        if (dma_r_valid_i) begin
          r_seen_d = 1'b1;
          if (d2h_res_bad && err_q == sf_albion_host_pkg::SF_HS_OK) err_d = sf_albion_host_pkg::SF_HS_PROTO;
          else if (dma_r_status_i != sf_albion_host_pkg::SF_HS_OK && err_q == sf_albion_host_pkg::SF_HS_OK)
            err_d = dma_r_status_i;
        end
        if (widx_q == nw_q && r_seen_q) st_d = E_FIN;
      end
      E_FIN: begin
        busy_d   = 1'b0;
        done_d   = 1'b1;
        status_d = err_q;
        bytes_d  = (err_q == sf_albion_host_pkg::SF_HS_OK) ? {7'h0, nw_q, 4'h0} : 32'h0;
        st_d     = E_IDLE;
      end
      default: st_d = E_IDLE;
    endcase
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q <= E_IDLE; busy_q <= 1'b0; done_q <= 1'b0; status_q <= 4'h0; bytes_q <= 32'h0; mv_q <= 1'b0;
      err_q <= 4'h0; last_seen_q <= 1'b0; r_seen_q <= 1'b0; ridx_q <= '0; widx_q <= '0;
    end else begin
      st_q <= st_d; busy_q <= busy_d; done_q <= done_d; status_q <= status_d; bytes_q <= bytes_d; mv_q <= mv_d;
      err_q <= err_d; last_seen_q <= last_seen_d; r_seen_q <= r_seen_d; ridx_q <= ridx_d; widx_q <= widx_d;
    end
  end

  always_ff @(posedge clk_i) begin
    src_q <= src_d; dst_q <= dst_d; len_q <= len_d; nw_q <= nw_d; dir_q <= dir_d; posted_q <= posted_d;
    mreq_q <= mreq_d;
  end
endmodule

`default_nettype wire
