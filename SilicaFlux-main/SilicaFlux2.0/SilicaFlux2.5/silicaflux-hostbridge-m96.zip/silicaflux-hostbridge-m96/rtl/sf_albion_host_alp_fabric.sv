// =============================================================================
//  sf_albion_host_alp_fabric.sv  --  demonstration ALP v1 target fabric: SRAM + register block + error responder
// -----------------------------------------------------------------------------
//  One ALP link in, three targets behind it, in the structure of AlbionCore's sf_albion_ref_subsystem:
//
//      req --> input skid --> decode --+--> SRAM   (sf_albion_ref_mem, region SRAM)
//                                      +--> CSR    (link ports: sf_albion_host_csr, region CSR)
//                                      +--> error responder (everything else, or an access check that fails)
//      rsp <-- output skid <-- in-order response merge <-- order queue
//
//  Decode (the same precedence as ref_subsystem):
//    1. address outside every region                     -> error responder, SF_ST_DECODE_ERR
//    2. region access check fails (sf_access_check_bits)  -> error responder, ACCESS_DENIED / BAD_ATTR
//    3. otherwise the target, with the address made relative to the region base
//  Regions use the Albion full-catalogue map: SRAM 256 MiB at SF_HB_DEMO_SRAM_BASE (attribute 0x27, backed
//  SRAM_WORDS words), CSR 1 MiB at SF_HB_DEMO_CSR_BASE (attribute 0x8B: device memory type, privileged only).
//  Legality (ALP-LEG-01) is not repeated here: every target checks the request it receives and gives the
//  legality status precedence.
//
//  Ordering (ALP-ORD-01): the targets have different latencies; the order queue records the target of each
//  accepted request and the merge releases responses in that order.
// =============================================================================
`default_nettype none

module sf_albion_host_alp_fabric #(
  parameter int unsigned MAX_OUT     = 16,       // order-queue depth (requests in flight: MAX_OUT + 4)
  parameter int unsigned SRAM_WORDS  = 1024,
  parameter int unsigned SRAM_EXTRA_LAT = 2
) (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,
  // ---- ALP v1 target link -------------------------------------------------------------------
  input  wire logic              req_valid_i,
  output logic                   req_ready_o,
  input  sf_albion_pkg::sf_req_t req_i,
  output logic                   rsp_valid_o,
  input  wire logic              rsp_ready_i,
  output sf_albion_pkg::sf_rsp_t rsp_o,
  // ---- link to the register block (initiator side) -----------------------------------------------
  output logic                   csr_req_valid_o,
  input  wire logic              csr_req_ready_i,
  output sf_albion_pkg::sf_req_t csr_req_o,
  input  wire logic              csr_rsp_valid_i,
  output logic                   csr_rsp_ready_o,
  input  sf_albion_pkg::sf_rsp_t csr_rsp_i
);
  localparam int unsigned REQ_W = sf_albion_pkg::SF_REQ_W;
  localparam int unsigned RSP_W = sf_albion_pkg::SF_RSP_W;
  localparam logic [63:0] SRAM_BASE  = sf_albion_host_pkg::SF_HB_DEMO_SRAM_BASE;
  localparam logic [63:0] SRAM_SIZE  = 64'h0000_0000_1000_0000;
  localparam logic [63:0] CSR_BASE   = sf_albion_host_pkg::SF_HB_DEMO_CSR_BASE;
  localparam logic [63:0] CSR_SIZE   = 64'h0000_0000_0010_0000;
  localparam logic [1:0]  T_SRAM = 2'd0;
  localparam logic [1:0]  T_CSR  = 2'd1;
  localparam logic [1:0]  T_ERR  = 2'd2;

  if (MAX_OUT < 1 || MAX_OUT > 256) begin : gen_param_check_out
    $error("sf_albion_host_alp_fabric: MAX_OUT must be in 1..256");
  end

  // ---------------------------------------------------------------- input stage
  logic                   dec_valid, dec_ready;
  logic [REQ_W-1:0]       dec_bits;
  sf_albion_pkg::sf_req_t dec_req;

  sf_albion_skid #(.WIDTH(REQ_W)) u_in_skid (
    .clk_i, .rst_ni,
    .in_valid_i (req_valid_i), .in_ready_o (req_ready_o), .in_data_i (req_i),
    .out_valid_o(dec_valid),   .out_ready_i(dec_ready),   .out_data_o(dec_bits)
  );
  assign dec_req = dec_bits;

  // ---------------------------------------------------------------- decode
  logic [1:0]                 tgt;
  logic                       in_sram, in_csr;
  sf_albion_pkg::sf_status_t  acc_status, err_status;
  sf_albion_pkg::sf_req_t     tgt_req;

  always_comb begin
    in_sram = ((dec_req.addr - SRAM_BASE) < SRAM_SIZE);
    in_csr  = ((dec_req.addr - CSR_BASE)  < CSR_SIZE);
    tgt     = T_ERR;
    acc_status = sf_albion_pkg::SF_ST_OKAY;
    err_status = sf_albion_pkg::SF_ST_DECODE_ERR;
    tgt_req = dec_req;
    if (in_sram) begin
      acc_status = sf_albion_pkg::sf_access_check_bits(sf_albion_host_pkg::SF_HB_DEMO_SRAM_ATTR, dec_req);
      tgt_req.addr = dec_req.addr - SRAM_BASE;
      if (acc_status == sf_albion_pkg::SF_ST_OKAY) tgt = T_SRAM; else err_status = acc_status;
    end else if (in_csr) begin
      acc_status = sf_albion_pkg::sf_access_check_bits(sf_albion_host_pkg::SF_HB_DEMO_CSR_ATTR, dec_req);
      tgt_req.addr = dec_req.addr - CSR_BASE;
      if (acc_status == sf_albion_pkg::SF_ST_OKAY) tgt = T_CSR; else err_status = acc_status;
    end
  end

  // ---------------------------------------------------------------- targets
  logic                   sram_req_ready, err_req_ready;
  logic                   sram_rsp_valid, err_rsp_valid;
  logic                   sram_rsp_ready, err_rsp_ready;
  sf_albion_pkg::sf_rsp_t sram_rsp, err_rsp;
  logic                   ord_in_ready;
  logic                   fire;
  logic                   tgt_ready;

  always_comb begin
    case (tgt)
      T_SRAM:  tgt_ready = sram_req_ready;
      T_CSR:   tgt_ready = csr_req_ready_i;
      default: tgt_ready = err_req_ready;
    endcase
  end
  assign dec_ready = dec_valid && ord_in_ready && tgt_ready;
  assign fire      = dec_valid && dec_ready;

  sf_albion_ref_mem #(
    .WORDS(SRAM_WORDS), .RSP_DEPTH(2), .EXTRA_LAT(SRAM_EXTRA_LAT), .INIT_ZERO(1'b1)
  ) u_sram (
    .clk_i, .rst_ni,
    .req_valid_i(fire && (tgt == T_SRAM)), .req_ready_o(sram_req_ready), .req_i(tgt_req),
    .rsp_valid_o(sram_rsp_valid),          .rsp_ready_i(sram_rsp_ready), .rsp_o(sram_rsp)
  );

  assign csr_req_valid_o = fire && (tgt == T_CSR);
  assign csr_req_o       = tgt_req;

  sf_albion_err_resp #(.DEPTH(2), .CHECK_LEGALITY(1'b1)) u_err (
    .clk_i, .rst_ni,
    .req_valid_i(fire && (tgt == T_ERR)), .req_ready_o(err_req_ready), .req_i(dec_req),
    .status_i(err_status),
    .rsp_valid_o(err_rsp_valid),          .rsp_ready_i(err_rsp_ready), .rsp_o(err_rsp)
  );

  // ---------------------------------------------------------------- order queue and merge
  logic [1:0] ord_head;
  logic       ord_valid, ord_pop;
  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(2), .DEPTH(MAX_OUT)) u_order (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (fire),      .in_ready_o (ord_in_ready), .in_data_i (tgt),
    .out_valid_o(ord_valid), .out_ready_i(ord_pop),      .out_data_o(ord_head),
    .count_o(), .full_o(), .empty_o()
  );
  /* verilator lint_on PINCONNECTEMPTY */

  logic             merge_valid, merge_ready;
  logic [RSP_W-1:0] merge_bits;
  always_comb begin
    case (ord_head)
      T_SRAM:  begin merge_valid = ord_valid && sram_rsp_valid; merge_bits = sram_rsp; end
      T_CSR:   begin merge_valid = ord_valid && csr_rsp_valid_i; merge_bits = csr_rsp_i; end
      default: begin merge_valid = ord_valid && err_rsp_valid;  merge_bits = err_rsp;  end
    endcase
  end
  assign sram_rsp_ready  = ord_valid && (ord_head == T_SRAM) && merge_ready;
  assign csr_rsp_ready_o = ord_valid && (ord_head == T_CSR)  && merge_ready;
  assign err_rsp_ready   = ord_valid && (ord_head != T_SRAM) && (ord_head != T_CSR) && merge_ready;
  assign ord_pop         = merge_valid && merge_ready;

  sf_albion_skid #(.WIDTH(RSP_W)) u_out_skid (
    .clk_i, .rst_ni,
    .in_valid_i (merge_valid), .in_ready_o (merge_ready), .in_data_i (merge_bits),
    .out_valid_o(rsp_valid_o), .out_ready_i(rsp_ready_i), .out_data_o(rsp_o)
  );
endmodule

`default_nettype wire
