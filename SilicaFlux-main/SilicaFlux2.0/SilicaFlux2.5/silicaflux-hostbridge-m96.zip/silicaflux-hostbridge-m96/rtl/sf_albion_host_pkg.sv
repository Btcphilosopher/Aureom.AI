// =============================================================================
//  sf_albion_host_pkg.sv  --  SilicaFlux HostBridge common package (HTI v1)
// -----------------------------------------------------------------------------
//  Project   : Aureom.AI / SilicaFlux Albion / Module 96 (HostBridge)
//  Role      : Single source of truth for the HostBridge Transaction Interface
//              (HTI) version 1: field widths, request kinds, completion status
//              codes, the mapping from ALP status codes to HTI status codes, the
//              demonstration CSR map and the pure helper functions that the RTL
//              and the testbenches share.
//
//  HTI is a TRANSACTION-LEVEL interface.  It is what a PCIe endpoint's
//  application-side TLP interface looks like after a thin shim has decoded the
//  packet headers (see docs/PCIE_INTEGRATION.md).  It models memory reads and
//  memory writes only.  It is not a PCIe physical layer, data-link layer or
//  transaction layer and makes no PCIe electrical or protocol-compliance claim.
//
//  Fabric side  : HostBridge is an ALP v1 initiator (sf_albion_pkg), unchanged.
//  Tool rules   : same as sf_albion_pkg (docs/albion/NAMING_RULES.md of AlbionCore):
//                 no wildcard import, package items fully qualified inside
//                 functions, flat-vector function arguments, no enum casts, no
//                 `return`, no preprocessor.
//
//  This file contains no process-node, timing or performance claims.
// =============================================================================
`default_nettype none

/* verilator lint_off UNUSEDPARAM */
/* verilator lint_off UNUSEDSIGNAL */
package sf_albion_host_pkg;

  // ===========================================================================
  // 1. Identity and versioning
  // ===========================================================================
  localparam int unsigned SF_HB_LIB_MAJOR     = 0;   // HostBridge library release
  localparam int unsigned SF_HB_LIB_MINOR     = 1;
  localparam int unsigned SF_HB_LIB_PATCH     = 0;
  localparam int unsigned SF_HTI_VERSION_MAJOR = 1;  // HostBridge Transaction Interface
  localparam int unsigned SF_HTI_VERSION_MINOR = 0;

  // ===========================================================================
  // 2. Widths (fixed; the fabric side is ALP v1 and its widths are fixed too)
  // ===========================================================================
  localparam int unsigned SF_HTI_ADDR_W     = 64;
  localparam int unsigned SF_HTI_DATA_W     = 128;                   // one beat = one 16-byte word
  localparam int unsigned SF_HTI_BE_W       = SF_HTI_DATA_W / 8;     // 16 byte lanes
  localparam int unsigned SF_HTI_LANE_W     = 4;                     // log2(SF_HTI_BE_W)
  localparam int unsigned SF_HTI_TAG_W      = 8;
  localparam int unsigned SF_HTI_DOM_W      = 8;
  localparam int unsigned SF_HTI_KIND_W     = 2;
  localparam int unsigned SF_HTI_STATUS_W   = 4;
  localparam int unsigned SF_HTI_LEN_W      = 13;   // host-originated request length in bytes: 0 .. 8191
  localparam int unsigned SF_HTI_DMA_LEN_W  = 24;   // DMA client request length in bytes: 0 .. 16 MiB - 1
  localparam int unsigned SF_HTI_ID_W       = 8;    // DMA client request identifier
  localparam int unsigned SF_HTI_MAX_REQ_LIMIT = 4096;  // largest legal single HTI request, in bytes
  localparam int unsigned SF_HTI_WORDS_W    = 10;   // word counter of one host request (<= 513 words)

  // ===========================================================================
  // 3. Request kinds  (hreq_kind / dreq_kind)
  // ===========================================================================
  //  Code 2'd0 is deliberately INVALID so that an all-zero request is never
  //  mistaken for a legal one.  A request with an invalid kind is completed
  //  with SF_HS_BAD_REQ and is treated as a request WITHOUT write data.
  typedef enum logic [1:0] {
    SF_HK_NONE = 2'd0,   // invalid
    SF_HK_RD   = 2'd1,   // memory read; answered by a read completion
    SF_HK_WR   = 2'd2,   // memory write, non-posted: answered by a write completion
    SF_HK_WRP  = 2'd3    // memory write, posted: no completion; a failure is reported as an error event
  } sf_hti_kind_e;

  // ===========================================================================
  // 4. HTI completion status codes
  // ===========================================================================
  //  Carried in every completion beat.  The status is meaningful on the LAST
  //  beat of a completion; every earlier beat carries SF_HS_OK.  SF_HS_OK is the
  //  only success code.  A completion whose last beat is not SF_HS_OK has failed
  //  as a whole and its data must be discarded.
  typedef enum logic [3:0] {
    SF_HS_OK       = 4'h0,  // success
    SF_HS_UR       = 4'h1,  // unsupported request: no aperture / no target for the address
    SF_HS_DENIED   = 4'h2,  // permission: aperture rights, reserved domain, DomainGuard or fabric access check
    SF_HS_CA       = 4'h3,  // completer abort: the target failed the access
    SF_HS_POISON   = 4'h4,  // uncorrectable data error: data poisoned
    SF_HS_BAD_LEN  = 4'h5,  // request length is zero or exceeds the maximum
    SF_HS_BOUNDARY = 4'h6,  // request crosses a boundary (4 KiB rule, aperture edge, address wrap)
    SF_HS_ABORTED  = 4'h7,  // cancelled before completion (cancel_i)
    SF_HS_TIMEOUT  = 4'h8,  // no completion arrived within the completion timeout
    SF_HS_BAD_REQ  = 4'h9,  // invalid request kind, or the fabric rejected the request as malformed
    SF_HS_PROTO    = 4'hA   // protocol violation by the other side (unexpected / mis-sized completion)
  } sf_hti_status_e;

  // Error-event source codes (err_evt_src_o).
  localparam logic [1:0] SF_HB_SRC_HOST = 2'd0;   // host-originated request path
  localparam logic [1:0] SF_HB_SRC_DMA  = 2'd1;   // device-originated DMA path
  localparam logic [1:0] SF_HB_SRC_CORE = 2'd2;   // bridge internal (fatal link error)

  // Demonstration address map: the bases and attributes of the full Albion
  // catalogue (sf_albion_memmap_pkg).  Kept here as constants so the RTL does
  // not depend on the generated map package.
  localparam logic [63:0] SF_HB_DEMO_SRAM_BASE = 64'h0000_0001_1000_0000;  // = SF_MM_SRAM_BASE
  localparam logic [7:0]  SF_HB_DEMO_SRAM_ATTR = 8'h27;                    // = SF_MM_SRAM_ATTR
  localparam logic [63:0] SF_HB_DEMO_CSR_BASE  = 64'h0000_0001_2000_0000;  // = SF_MM_DMA_BASE
  localparam logic [7:0]  SF_HB_DEMO_CSR_ATTR  = 8'h8B;                    // = SF_MM_DMA_ATTR (device, priv only)
  //  Request attribute bytes a host aperture assigns (sf_attr_t):
  //  bit7 rsvd, [6:5] qos, bit4 instr, bit3 secure, bit2 priv, [1:0] mem_type (2 = device).
  localparam logic [7:0]  SF_HB_ATTR_NORMAL      = 8'h00;   // non-privileged, non-secure, normal write-back memory
  localparam logic [7:0]  SF_HB_ATTR_DEVICE_PRIV = 8'h06;   // privileged, device memory type

  // ===========================================================================
  // 5. Demonstration CSR map  (byte offsets inside the CSR window; 32-bit registers, 4-byte stride)
  // ===========================================================================
  localparam logic [31:0] SF_HB_ID_VALUE      = 32'h4842_0096;   // 'H' 'B' module 0x96
  localparam int unsigned SF_HB_CSR_ID        = 32'h000;   // RO
  localparam int unsigned SF_HB_CSR_VERSION   = 32'h004;   // RO  {8'h0, major, minor, patch}
  localparam int unsigned SF_HB_CSR_CAPS      = 32'h008;   // RO  {dma_tags[7:0], max_out[7:0], guard_en, 15'h0}
  localparam int unsigned SF_HB_CSR_SCRATCH   = 32'h00C;   // RW
  localparam int unsigned SF_HB_CSR_CONTROL   = 32'h010;   // W   bit0 = cancel, bit1 = clear error log
  localparam int unsigned SF_HB_CSR_STATUS    = 32'h014;   // RO  bit0 host_busy, bit1 dma_busy, bit2 fatal
  localparam int unsigned SF_HB_CSR_OUT_HOST  = 32'h018;   // RO  outstanding ALP words of the host path
  localparam int unsigned SF_HB_CSR_OUT_DMA   = 32'h01C;   // RO  outstanding DMA tags
  localparam int unsigned SF_HB_CSR_ERR_COUNT = 32'h020;   // RO  error events logged
  localparam int unsigned SF_HB_CSR_ERR_INFO  = 32'h024;   // RO  {src[1:0], code[3:0], tag[7:0]} of the first event
  localparam int unsigned SF_HB_CSR_ERR_ALO   = 32'h028;   // RO  first event address, low half
  localparam int unsigned SF_HB_CSR_ERR_AHI   = 32'h02C;   // RO  first event address, high half
  localparam int unsigned SF_HB_CSR_UNEXP_CPL = 32'h030;   // RO  host completion beats dropped (matched no tag)
  localparam int unsigned SF_HB_CSR_DMA_SRC_LO = 32'h040;  // RW
  localparam int unsigned SF_HB_CSR_DMA_SRC_HI = 32'h044;  // RW
  localparam int unsigned SF_HB_CSR_DMA_DST_LO = 32'h048;  // RW
  localparam int unsigned SF_HB_CSR_DMA_DST_HI = 32'h04C;  // RW
  localparam int unsigned SF_HB_CSR_DMA_LEN    = 32'h050;  // RW  bytes, multiple of 16
  //  DMA_CTRL: bit0 start (self-clearing), bit1 dir (0 = host->SRAM, 1 = SRAM->host), bit2 posted
  localparam int unsigned SF_HB_CSR_DMA_CTRL   = 32'h054;  // RW
  localparam int unsigned SF_HB_CSR_DMA_STATUS = 32'h058;  // RO  bit0 busy, bit1 done, [7:4] HTI status
  localparam int unsigned SF_HB_CSR_DMA_BYTES  = 32'h05C;  // RO  bytes moved
  //  Guard window i at GUARD_BASE + i*GUARD_STRIDE: BASE_LO, BASE_HI, LIMIT_LO, LIMIT_HI, ATTR
  localparam int unsigned SF_HB_CSR_GUARD_BASE = 32'h100;  // RW
  localparam int unsigned SF_HB_CSR_GUARD_STRIDE = 32;
  localparam int unsigned SF_HB_CSR_NUM_REGS   = 128;      // register index space: 128 x 4 bytes = 512 bytes

  // ===========================================================================
  // 6. Pure functions
  // ===========================================================================

  //  ALP status code -> HTI status code (the HOST-visible meaning of a fabric status).
  function automatic logic [3:0] sf_hti_status_from_alp(input logic [3:0] st);
    begin
      sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_CA;                   // default: anything unexpected
      if (st == sf_albion_pkg::SF_ST_OKAY)                sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_OK;
      else if (st == sf_albion_pkg::SF_ST_DECODE_ERR)     sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_UR;
      else if (st == sf_albion_pkg::SF_ST_ACCESS_DENIED)  sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_DENIED;
      else if (st == sf_albion_pkg::SF_ST_BAD_OPCODE)     sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_BAD_REQ;
      else if (st == sf_albion_pkg::SF_ST_BAD_BE)         sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_BAD_REQ;
      else if (st == sf_albion_pkg::SF_ST_ALIGN_ERR)      sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_BAD_REQ;
      else if (st == sf_albion_pkg::SF_ST_BAD_ATTR)       sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_BAD_REQ;
      else if (st == sf_albion_pkg::SF_ST_TARGET_ERR)     sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_CA;
      else if (st == sf_albion_pkg::SF_ST_TIMEOUT)        sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_TIMEOUT;
      else if (st == sf_albion_pkg::SF_ST_CANCELLED)      sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_ABORTED;
      else if (st == sf_albion_pkg::SF_ST_ECC_UNCORR)     sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_POISON;
      else if (st == sf_albion_pkg::SF_ST_PROTOCOL_ERR)   sf_hti_status_from_alp = sf_albion_host_pkg::SF_HS_PROTO;
    end
  endfunction

  //  Number of 16-byte words a request [addr, addr+len) touches: ((addr[3:0] + len + 15) >> 4) for len > 0,
  //  0 for len == 0.  The write-data beat count of a request is ALWAYS this number, whether or not the
  //  request is legal, so the bridge can always drain the data of a rejected write.
  function automatic logic [31:0] sf_hti_nwords(input logic [3:0] lo, input logic [31:0] len);
    logic [31:0] sum;
    begin
      sum = {28'h0, lo} + len + 32'd15;
      if (len == 32'd0) sf_hti_nwords = 32'd0;
      else              sf_hti_nwords = sum >> 4;
    end
  endfunction

  //  Byte-lane mask of the first word of a span that starts at lane `lo`.
  function automatic logic [15:0] sf_hti_first_mask(input logic [3:0] lo);
    sf_hti_first_mask = 16'hFFFF << lo;
  endfunction

  //  Byte-lane mask of the last word of a span whose last byte is at lane `last_lo`.
  function automatic logic [15:0] sf_hti_last_mask(input logic [3:0] last_lo);
    sf_hti_last_mask = 16'hFFFF >> (4'd15 - last_lo);
  endfunction

  //  Expand a 16-bit byte mask to a 128-bit bit mask.
  function automatic logic [127:0] sf_hti_expand_be(input logic [15:0] be);
    for (int unsigned b = 0; b < 16; b++) sf_hti_expand_be[b*8 +: 8] = {8{be[b]}};
  endfunction

endpackage
/* verilator lint_on UNUSEDSIGNAL */
/* verilator lint_on UNUSEDPARAM */

`default_nettype wire
