// =============================================================================
//  sf_albion_host_soc_demo.sv  --  HostBridge demonstration SoC (host memory-mapped + DMA + guard)
// -----------------------------------------------------------------------------
//  The smallest system that exercises every part of the bridge against real fabric pieces.  Only the HTI
//  channels, clock, reset and a cancel pin are visible: a host (a bus-functional model in simulation, a shim
//  around licensed PCIe endpoint IP in a product) sees a register space and an SRAM, and can have the device
//  copy data to and from HOST memory.
//
//                host (HTI)
//                    |
//        +-----------+-----------------------------------------------+
//        |   sf_albion_host_bridge  ---- DomainGuard (check port) ----+--> sf_albion_host_domain_guard
//        |        |ALP initiator            |DMA client port           |         ^ window programming
//        |        v                         v                          |         | (management plane only)
//        |   sf_albion_host_alp_arb2   sf_albion_host_dma_engine       |   sf_albion_host_csr <-- error events
//        |        ^ m0                    | m1 (ALP initiator)         |         ^   cancel / DMA registers
//        |        +--------+--------------+                            |         |
//        |                 v                                          |         |
//        |        sf_albion_host_alp_fabric  ---- CSR link -------------+---------+
//        |            SRAM (ref_mem) | error responder                 |
//        +-----------------------------------------------------------+
//
//  Address map seen by the host (bridge apertures)
//    host 0x0000_0000 .. +1 MiB  -> CSR window  (device 0x1_2000_0000, privileged device memory)
//    host 0x1000_0000 .. +16 KiB -> SRAM        (device 0x1_1000_0000, normal memory)
//  The CSR window is reachable through the DomainGuard like everything else: a tenant domain needs a window.
//  The guard's window table is programmed through CSR registers, which accept writes only from ROOT / MGMT
//  with the privileged attribute, so the table is never programmable by a tenant.
//
//  Not claimed: this is a functional demonstration; no timing, area or power claims, no PCIe compliance.
// =============================================================================
`default_nettype none

module sf_albion_host_soc_demo #(
  parameter int unsigned MAX_OUT     = 8,       // bridge: outstanding ALP words
  parameter int unsigned ENG_MAX_OUT = 8,       // DMA engine: outstanding ALP words
  parameter int unsigned NUM_TAGS    = 8,       // bridge: outstanding host-bound requests
  parameter int unsigned MPS_BYTES   = 256,
  parameter int unsigned MRRS_BYTES  = 256,
  parameter int unsigned CPL_TIMEOUT = 0,
  parameter int unsigned SRAM_WORDS  = 1024
) (
  input  wire logic                                       clk_i,
  input  wire logic                                       rst_ni,
  input  wire logic                                       cancel_i,        // external cancel (a CSR bit does the same)
  // ---- HTI: host -> device requests -------------------------------------------------------------
  input  wire logic                                       hreq_valid_i,
  output logic                                            hreq_ready_o,
  input  wire logic [sf_albion_host_pkg::SF_HTI_KIND_W-1:0]  hreq_kind_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_ADDR_W-1:0]  hreq_addr_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_LEN_W-1:0]   hreq_len_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]   hreq_tag_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DOM_W-1:0]   hreq_dom_i,
  input  wire logic                                       hw_valid_i,
  output logic                                            hw_ready_o,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]  hw_data_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_BE_W-1:0]    hw_be_i,
  input  wire logic                                       hw_last_i,
  // ---- HTI: completions (device -> host) ----------------------------------------------------------
  output logic                                            hcpl_valid_o,
  input  wire logic                                       hcpl_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]        hcpl_tag_o,
  output logic [sf_albion_host_pkg::SF_HTI_STATUS_W-1:0]     hcpl_status_o,
  output logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]       hcpl_data_o,
  output logic                                            hcpl_last_o,
  // ---- HTI: device -> host requests and their completions ------------------------------------------------
  output logic                                            dreq_valid_o,
  input  wire logic                                       dreq_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_KIND_W-1:0]          dreq_kind_o,
  output logic [sf_albion_host_pkg::SF_HTI_ADDR_W-1:0]          dreq_addr_o,
  output logic [sf_albion_host_pkg::SF_HTI_LEN_W-1:0]           dreq_len_o,
  output logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]           dreq_tag_o,
  output logic                                            dw_valid_o,
  input  wire logic                                       dw_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]          dw_data_o,
  output logic [sf_albion_host_pkg::SF_HTI_BE_W-1:0]            dw_be_o,
  output logic                                            dw_last_o,
  input  wire logic                                       dcpl_valid_i,
  output logic                                            dcpl_ready_o,
  input  wire logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]      dcpl_tag_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_STATUS_W-1:0]   dcpl_status_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]     dcpl_data_i,
  input  wire logic                                       dcpl_last_i,
  // ---- status ---------------------------------------------------------------------------------------------
  output logic [31:0]                                     guard_deny_count_o,   // checks the DomainGuard denied
  output logic                                            fatal_o
);
  // ---------------------------------------------------------------------------
  // Wires
  // ---------------------------------------------------------------------------
  // bridge ALP link
  logic                     b_req_valid, b_req_ready, b_rsp_valid, b_rsp_ready;
  sf_albion_pkg::sf_req_t   b_req;
  sf_albion_pkg::sf_rsp_t   b_rsp;
  // DMA engine ALP link
  logic                     e_req_valid, e_req_ready, e_rsp_valid, e_rsp_ready;
  sf_albion_pkg::sf_req_t   e_req;
  sf_albion_pkg::sf_rsp_t   e_rsp;
  // merged link into the fabric
  logic                     t_req_valid, t_req_ready, t_rsp_valid, t_rsp_ready;
  sf_albion_pkg::sf_req_t   t_req;
  sf_albion_pkg::sf_rsp_t   t_rsp;
  // CSR link
  logic                     c_req_valid, c_req_ready, c_rsp_valid, c_rsp_ready;
  sf_albion_pkg::sf_req_t   c_req;
  sf_albion_pkg::sf_rsp_t   c_rsp;
  // guard
  logic                     grd_req_valid, grd_rsp_valid, grd_permit;
  logic [7:0]               grd_dom, grd_attr;
  logic [3:0]               grd_op, grd_status;
  logic [63:0]              grd_addr;
  logic [31:0]              grd_len;
  logic                     gcfg_we, gcfg_rd, gcfg_wr, gcfg_valid;
  logic [2:0]               gcfg_idx;
  logic [63:0]              gcfg_base, gcfg_limit;
  logic [7:0]               gcfg_dom;
  // DMA client port
  logic                     dma_req_valid, dma_req_ready, dma_req_write, dma_req_posted;
  logic [63:0]              dma_req_addr;
  logic [23:0]              dma_req_len;
  logic [7:0]               dma_req_id;
  logic                     dma_w_valid, dma_w_ready, dma_w_last;
  logic [127:0]             dma_w_data;
  logic [15:0]              dma_w_be;
  logic                     dma_r_valid, dma_r_ready, dma_r_is_write, dma_r_last;
  logic [7:0]               dma_r_id;
  logic [3:0]               dma_r_status;
  logic [127:0]             dma_r_data;
  logic [15:0]              dma_r_be;
  // CSR <-> engine / bridge
  logic                     csr_cancel;
  logic [63:0]              e_src, e_dst;
  logic [31:0]              e_len, e_bytes;
  logic                     e_dir, e_posted, e_start, e_busy, e_done;
  logic [3:0]               e_status;
  logic                     err_valid, err_ready;
  logic [1:0]               err_src;
  logic [3:0]               err_code;
  logic [7:0]               err_tag;
  logic [63:0]              err_addr;
  logic                     host_busy, dma_busy;
  logic [$clog2(MAX_OUT+1)-1:0]  host_out;
  logic [$clog2(NUM_TAGS+1)-1:0] dma_out;
  logic [15:0]              unexpected_cpl;

  // ---------------------------------------------------------------------------
  // The bridge
  // ---------------------------------------------------------------------------
  sf_albion_host_bridge #(
    .MAX_OUT(MAX_OUT), .MAX_REQ_BYTES(4096), .BOUNDARY_LOG2(12), .NUM_APERT(2),
    .AP_HBASE({64'h0000_0000_1000_0000, 64'h0000_0000_0000_0000}),
    .AP_SIZE ({64'h0000_0000_0000_4000, 64'h0000_0000_0010_0000}),
    .AP_DBASE({sf_albion_host_pkg::SF_HB_DEMO_SRAM_BASE, sf_albion_host_pkg::SF_HB_DEMO_CSR_BASE}),
    .AP_ATTR ({sf_albion_host_pkg::SF_HB_ATTR_NORMAL, sf_albion_host_pkg::SF_HB_ATTR_DEVICE_PRIV}),
    .AP_PERM (4'b1111), .GUARD_EN(1'b1),
    .NUM_TAGS(NUM_TAGS), .MPS_BYTES(MPS_BYTES), .MRRS_BYTES(MRRS_BYTES), .CPL_TIMEOUT(CPL_TIMEOUT),
    .CK_Q_DEPTH(NUM_TAGS + 4)
  ) u_bridge (
    .clk_i, .rst_ni, .cancel_i(cancel_i | csr_cancel),
    .hreq_valid_i, .hreq_ready_o, .hreq_kind_i, .hreq_addr_i, .hreq_len_i, .hreq_tag_i, .hreq_dom_i,
    .hw_valid_i, .hw_ready_o, .hw_data_i, .hw_be_i, .hw_last_i,
    .hcpl_valid_o, .hcpl_ready_i, .hcpl_tag_o, .hcpl_status_o, .hcpl_data_o, .hcpl_last_o,
    .m_req_valid_o(b_req_valid), .m_req_ready_i(b_req_ready), .m_req_o(b_req),
    .m_rsp_valid_i(b_rsp_valid), .m_rsp_ready_o(b_rsp_ready), .m_rsp_i(b_rsp),
    .grd_req_valid_o(grd_req_valid), .grd_dom_o(grd_dom), .grd_op_o(grd_op), .grd_attr_o(grd_attr),
    .grd_addr_o(grd_addr), .grd_len_o(grd_len),
    .grd_rsp_valid_i(grd_rsp_valid), .grd_permit_i(grd_permit), .grd_status_i(grd_status),
    .dma_req_valid_i(dma_req_valid), .dma_req_ready_o(dma_req_ready), .dma_req_write_i(dma_req_write),
    .dma_req_posted_i(dma_req_posted), .dma_req_addr_i(dma_req_addr), .dma_req_len_i(dma_req_len),
    .dma_req_id_i(dma_req_id),
    .dma_w_valid_i(dma_w_valid), .dma_w_ready_o(dma_w_ready), .dma_w_data_i(dma_w_data), .dma_w_be_i(dma_w_be),
    .dma_w_last_i(dma_w_last),
    .dma_r_valid_o(dma_r_valid), .dma_r_ready_i(dma_r_ready), .dma_r_id_o(dma_r_id), .dma_r_status_o(dma_r_status),
    .dma_r_is_write_o(dma_r_is_write), .dma_r_data_o(dma_r_data), .dma_r_be_o(dma_r_be), .dma_r_last_o(dma_r_last),
    .dreq_valid_o, .dreq_ready_i, .dreq_kind_o, .dreq_addr_o, .dreq_len_o, .dreq_tag_o,
    .dw_valid_o, .dw_ready_i, .dw_data_o, .dw_be_o, .dw_last_o,
    .dcpl_valid_i, .dcpl_ready_o, .dcpl_tag_i, .dcpl_status_i, .dcpl_data_i, .dcpl_last_i,
    .err_evt_valid_o(err_valid), .err_evt_ready_i(err_ready), .err_evt_src_o(err_src), .err_evt_code_o(err_code),
    .err_evt_tag_o(err_tag), .err_evt_addr_o(err_addr),
    .host_busy_o(host_busy), .dma_busy_o(dma_busy), .host_outstanding_o(host_out), .dma_outstanding_o(dma_out),
    .unexpected_cpl_o(unexpected_cpl), .fatal_o
  );

  // ---------------------------------------------------------------------------
  // DomainGuard: the check port is the bridge's; the window table is programmed only by the CSR block
  // ---------------------------------------------------------------------------
  sf_albion_host_domain_guard #(.NUM_WIN(8), .ROOT_BYPASS(1'b1)) u_guard (
    .clk_i, .rst_ni,
    .cfg_we_i(gcfg_we), .cfg_idx_i(gcfg_idx), .cfg_base_i(gcfg_base), .cfg_limit_i(gcfg_limit),
    .cfg_dom_i(gcfg_dom), .cfg_rd_i(gcfg_rd), .cfg_wr_i(gcfg_wr), .cfg_valid_i(gcfg_valid),
    .chk_valid_i(grd_req_valid), .chk_dom_i(grd_dom), .chk_op_i(grd_op), .chk_attr_i(grd_attr),
    .chk_addr_i(grd_addr), .chk_len_i(grd_len),
    .chk_rsp_valid_o(grd_rsp_valid), .chk_permit_o(grd_permit), .chk_status_o(grd_status),
    .deny_count_o(guard_deny_count_o)
  );

  // ---------------------------------------------------------------------------
  // Register block and DMA engine
  // ---------------------------------------------------------------------------
  sf_albion_host_csr #(.NUM_WIN(8), .NUM_TAGS(NUM_TAGS), .MAX_OUT(MAX_OUT), .GUARD_EN(1'b1)) u_csr (
    .clk_i, .rst_ni,
    .req_valid_i(c_req_valid), .req_ready_o(c_req_ready), .req_i(c_req),
    .rsp_valid_o(c_rsp_valid), .rsp_ready_i(c_rsp_ready), .rsp_o(c_rsp),
    .host_busy_i(host_busy), .dma_busy_i(dma_busy), .fatal_i(fatal_o),
    .host_outstanding_i(16'(host_out)), .dma_outstanding_i(16'(dma_out)), .unexpected_cpl_i(unexpected_cpl),
    .evt_valid_i(err_valid), .evt_ready_o(err_ready), .evt_src_i(err_src), .evt_code_i(err_code),
    .evt_tag_i(err_tag), .evt_addr_i(err_addr),
    .cancel_o(csr_cancel),
    .grd_cfg_we_o(gcfg_we), .grd_cfg_idx_o(gcfg_idx), .grd_cfg_base_o(gcfg_base), .grd_cfg_limit_o(gcfg_limit),
    .grd_cfg_dom_o(gcfg_dom), .grd_cfg_rd_o(gcfg_rd), .grd_cfg_wr_o(gcfg_wr), .grd_cfg_valid_o(gcfg_valid),
    .dma_src_o(e_src), .dma_dst_o(e_dst), .dma_len_o(e_len), .dma_dir_o(e_dir), .dma_posted_o(e_posted),
    .dma_start_o(e_start), .dma_busy_eng_i(e_busy), .dma_done_i(e_done), .dma_status_i(e_status), .dma_bytes_i(e_bytes)
  );

  sf_albion_host_dma_engine #(.MAX_OUT(ENG_MAX_OUT)) u_engine (
    .clk_i, .rst_ni,
    .start_i(e_start), .src_i(e_src), .dst_i(e_dst), .len_i(e_len), .dir_i(e_dir), .posted_i(e_posted),
    .busy_o(e_busy), .done_o(e_done), .status_o(e_status), .bytes_o(e_bytes),
    .m_req_valid_o(e_req_valid), .m_req_ready_i(e_req_ready), .m_req_o(e_req),
    .m_rsp_valid_i(e_rsp_valid), .m_rsp_ready_o(e_rsp_ready), .m_rsp_i(e_rsp),
    .dma_req_valid_o(dma_req_valid), .dma_req_ready_i(dma_req_ready), .dma_req_write_o(dma_req_write),
    .dma_req_posted_o(dma_req_posted), .dma_req_addr_o(dma_req_addr), .dma_req_len_o(dma_req_len),
    .dma_req_id_o(dma_req_id),
    .dma_w_valid_o(dma_w_valid), .dma_w_ready_i(dma_w_ready), .dma_w_data_o(dma_w_data), .dma_w_be_o(dma_w_be),
    .dma_w_last_o(dma_w_last),
    .dma_r_valid_i(dma_r_valid), .dma_r_ready_o(dma_r_ready), .dma_r_id_i(dma_r_id), .dma_r_status_i(dma_r_status),
    .dma_r_is_write_i(dma_r_is_write), .dma_r_data_i(dma_r_data), .dma_r_be_i(dma_r_be), .dma_r_last_i(dma_r_last)
  );

  // ---------------------------------------------------------------------------
  // ALP interconnect: two initiators -> arbiter -> fabric (SRAM, CSR, error responder)
  // ---------------------------------------------------------------------------
  sf_albion_host_alp_arb2 #(.ORD_DEPTH(32)) u_arb (
    .clk_i, .rst_ni,
    .m0_req_valid_i(b_req_valid), .m0_req_ready_o(b_req_ready), .m0_req_i(b_req),
    .m0_rsp_valid_o(b_rsp_valid), .m0_rsp_ready_i(b_rsp_ready), .m0_rsp_o(b_rsp),
    .m1_req_valid_i(e_req_valid), .m1_req_ready_o(e_req_ready), .m1_req_i(e_req),
    .m1_rsp_valid_o(e_rsp_valid), .m1_rsp_ready_i(e_rsp_ready), .m1_rsp_o(e_rsp),
    .t_req_valid_o(t_req_valid), .t_req_ready_i(t_req_ready), .t_req_o(t_req),
    .t_rsp_valid_i(t_rsp_valid), .t_rsp_ready_o(t_rsp_ready), .t_rsp_i(t_rsp)
  );

  sf_albion_host_alp_fabric #(.MAX_OUT(32), .SRAM_WORDS(SRAM_WORDS)) u_fabric (
    .clk_i, .rst_ni,
    .req_valid_i(t_req_valid), .req_ready_o(t_req_ready), .req_i(t_req),
    .rsp_valid_o(t_rsp_valid), .rsp_ready_i(t_rsp_ready), .rsp_o(t_rsp),
    .csr_req_valid_o(c_req_valid), .csr_req_ready_i(c_req_ready), .csr_req_o(c_req),
    .csr_rsp_valid_i(c_rsp_valid), .csr_rsp_ready_o(c_rsp_ready), .csr_rsp_i(c_rsp)
  );
endmodule

`default_nettype wire
