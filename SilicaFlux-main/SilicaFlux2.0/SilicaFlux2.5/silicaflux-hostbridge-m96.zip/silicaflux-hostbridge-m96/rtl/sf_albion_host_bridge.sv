// =============================================================================
//  sf_albion_host_bridge.sv  --  SilicaFlux HostBridge (Module 96): host transaction interface
// -----------------------------------------------------------------------------
//  A transaction-level adapter between SilicaFlux and a host.  In simulation the host is a bus-
//  functional model; in a product the host-facing side is meant to be driven by a thin shim around a
//  licensed PCIe endpoint IP block (docs/PCIE_INTEGRATION.md).  This module is NOT a PCIe PHY, link
//  layer or transaction layer and makes no PCIe electrical or protocol-compliance claim.
//
//                          +------------------- sf_albion_host_bridge --------------------+
//   HTI host -> device     |  sf_albion_host_req_path                                      |
//   hreq / hw      ------> |  queue, validate, translate, DomainGuard, split to words  ----+--> ALP v1 initiator
//   hcpl           <------ |  in-order completion builder                              <---+--- (fabric)
//                          |                                                               |
//   HTI device -> host     |  sf_albion_host_dma_path                                      |
//   dreq / dw      <------ |  split at MPS / MRRS, tag pool, out-of-order completion       |   DMA client
//   dcpl           ------> |  matching, reorder buffer, in-order results               <---+-- dma_req / dma_w
//                          |                                                           ----+-> dma_r
//                          |  event merge, status, cancel                                  |
//                          +---------------------------------------------------------------+
//
//  Host -> device : host MMIO and host memory reads / writes become ALP READ / WRITE requests.
//                   Memory-mapped registers and SRAM are reached through the same path.  Every
//                   request is checked (kind, length, wrap, boundary, aperture, rights, domain) and,
//                   when GUARD_EN = 1, offered to a DomainGuard on the grd_* port BEFORE it can reach
//                   the fabric.
//  Device -> host : DMA reads and writes of host memory, burst-split at MPS / MRRS, tracked by tag,
//                   completions matched out of order, results returned in request order.
//
//  Reset and cancel
//    rst_ni    hard reset (asynchronous assert, synchronous release by the integrator): every queue,
//              tag and outstanding request is discarded and NO completion is ever produced for it.
//    cancel_i  soft cancel, one pulse: requests accepted up to and including this cycle that have not
//              finished issuing end with SF_HS_ABORTED; outstanding DMA tags are abandoned (late host
//              completions are dropped); ALP words already issued drain normally.  See the headers of
//              the two path modules for the exact contract.
//
//  Error events
//    err_evt_*   one event per rejected request, failed posted write, client-visible DMA failure or
//                protocol violation: {source, HTI status code, tag, address}.  Valid / ready; the
//                payload is stable while valid is high and ready is low.
//
//  Parameters are passed through to the two path modules (see them for ranges).
// =============================================================================
`default_nettype none

module sf_albion_host_bridge #(
  // ---- host -> device path -----------------------------------------------------------------
  parameter int unsigned REQ_Q_DEPTH    = 4,
  parameter int unsigned WDATA_Q_DEPTH  = 16,
  parameter int unsigned MAX_OUT        = 8,          // outstanding ALP words (1 .. 256)
  parameter int unsigned MAX_REQ_BYTES  = 4096,       // longest legal host request (<= 4096)
  parameter int unsigned BOUNDARY_LOG2  = 12,         // requests may not cross a 2**BOUNDARY_LOG2 boundary
  parameter int unsigned NUM_APERT      = 2,
  parameter logic [NUM_APERT*64-1:0] AP_HBASE = {64'h0000_0000_1000_0000, 64'h0000_0000_0000_0000},
  parameter logic [NUM_APERT*64-1:0] AP_SIZE  = {64'h0000_0000_0000_4000, 64'h0000_0000_0010_0000},
  parameter logic [NUM_APERT*64-1:0] AP_DBASE = {64'h0000_0001_1000_0000, 64'h0000_0001_2000_0000},
  parameter logic [NUM_APERT*8-1:0]  AP_ATTR  = {8'h00, 8'h06},
  parameter logic [NUM_APERT*2-1:0]  AP_PERM  = {2'b11, 2'b11},
  parameter bit          GUARD_EN       = 1'b1,
  // ---- device -> host path -----------------------------------------------------------------
  parameter int unsigned NUM_TAGS       = 8,          // outstanding host-bound requests with a tag (1 .. 64)
  parameter int unsigned MPS_BYTES      = 256,        // largest host write chunk
  parameter int unsigned MRRS_BYTES     = 256,        // largest host read chunk
  parameter int unsigned DMA_REQ_Q_DEPTH   = 4,
  parameter int unsigned DMA_WDATA_Q_DEPTH = 16,
  parameter int unsigned CK_Q_DEPTH     = 12,
  parameter int unsigned CPL_TIMEOUT    = 0,          // cycles; 0 = no completion timeout
  parameter int unsigned EVT_Q_DEPTH    = 4
) (
  input  wire logic                                       clk_i,
  input  wire logic                                       rst_ni,
  input  wire logic                                       cancel_i,
  // ===== HTI: host -> device requests ==========================================================
  input  wire logic                                       hreq_valid_i,
  output logic                                            hreq_ready_o,
  input  wire logic [sf_albion_host_pkg::SF_HTI_KIND_W-1:0]  hreq_kind_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_ADDR_W-1:0]  hreq_addr_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_LEN_W-1:0]   hreq_len_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]   hreq_tag_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DOM_W-1:0]   hreq_dom_i,
  input  wire logic                                       hw_valid_i,
  output logic                                            hw_ready_o,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]  hw_data_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_BE_W-1:0]    hw_be_i,
  input  wire logic                                       hw_last_i,
  // ===== HTI: completions of host requests (device -> host) ====================================
  output logic                                            hcpl_valid_o,
  input  wire logic                                       hcpl_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]        hcpl_tag_o,
  output logic [sf_albion_host_pkg::SF_HTI_STATUS_W-1:0]     hcpl_status_o,
  output logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]       hcpl_data_o,
  output logic                                            hcpl_last_o,
  // ===== ALP v1 initiator (to the fabric) ======================================================
  output logic                                            m_req_valid_o,
  input  wire logic                                       m_req_ready_i,
  output sf_albion_pkg::sf_req_t                          m_req_o,
  input  wire logic                                       m_rsp_valid_i,
  output logic                                            m_rsp_ready_o,
  input  sf_albion_pkg::sf_rsp_t                          m_rsp_i,
  // ===== DomainGuard check port (host-originated requests only) ================================
  output logic                                            grd_req_valid_o,
  output logic [sf_albion_pkg::SF_DOM_W-1:0]              grd_dom_o,
  output logic [sf_albion_pkg::SF_OP_W-1:0]               grd_op_o,
  output logic [sf_albion_pkg::SF_ATTR_W-1:0]             grd_attr_o,
  output logic [sf_albion_pkg::SF_ADDR_W-1:0]             grd_addr_o,
  output logic [31:0]                                     grd_len_o,
  input  wire logic                                       grd_rsp_valid_i,
  input  wire logic                                       grd_permit_i,
  input  wire logic [sf_albion_pkg::SF_STATUS_W-1:0]      grd_status_i,
  // ===== DMA client (device-originated host memory access) =====================================
  input  wire logic                                       dma_req_valid_i,
  output logic                                            dma_req_ready_o,
  input  wire logic                                       dma_req_write_i,
  input  wire logic                                       dma_req_posted_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_ADDR_W-1:0]     dma_req_addr_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DMA_LEN_W-1:0]  dma_req_len_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_ID_W-1:0]       dma_req_id_i,
  input  wire logic                                       dma_w_valid_i,
  output logic                                            dma_w_ready_o,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]     dma_w_data_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_BE_W-1:0]       dma_w_be_i,
  input  wire logic                                       dma_w_last_i,
  output logic                                            dma_r_valid_o,
  input  wire logic                                       dma_r_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_ID_W-1:0]            dma_r_id_o,
  output logic [sf_albion_host_pkg::SF_HTI_STATUS_W-1:0]        dma_r_status_o,
  output logic                                            dma_r_is_write_o,
  output logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]          dma_r_data_o,
  output logic [sf_albion_host_pkg::SF_HTI_BE_W-1:0]            dma_r_be_o,
  output logic                                            dma_r_last_o,
  // ===== HTI: device -> host requests ============================================================
  output logic                                            dreq_valid_o,
  input  wire logic                                       dreq_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_KIND_W-1:0]          dreq_kind_o,
  output logic [sf_albion_host_pkg::SF_HTI_ADDR_W-1:0]          dreq_addr_o,
  output logic [sf_albion_host_pkg::SF_HTI_LEN_W-1:0]           dreq_len_o,
  output logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]           dreq_tag_o,
  output logic                                            dw_valid_o,
  input  wire logic                                       dw_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]          dw_data_o,
  output logic [sf_albion_host_pkg::SF_HTI_BE_W-1:0]            dw_be_o,
  output logic                                            dw_last_o,
  // ===== HTI: completions of device requests (host -> device) ===================================
  input  wire logic                                       dcpl_valid_i,
  output logic                                            dcpl_ready_o,
  input  wire logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]      dcpl_tag_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_STATUS_W-1:0]   dcpl_status_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]     dcpl_data_i,
  input  wire logic                                       dcpl_last_i,
  // ===== error events and status ==================================================================
  output logic                                            err_evt_valid_o,
  input  wire logic                                       err_evt_ready_i,
  output logic [1:0]                                      err_evt_src_o,
  output logic [sf_albion_host_pkg::SF_HTI_STATUS_W-1:0]     err_evt_code_o,
  output logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]        err_evt_tag_o,
  output logic [sf_albion_host_pkg::SF_HTI_ADDR_W-1:0]       err_evt_addr_o,
  output logic                                            host_busy_o,
  output logic                                            dma_busy_o,
  output logic [$clog2(MAX_OUT+1)-1:0]                    host_outstanding_o,
  output logic [$clog2(NUM_TAGS+1)-1:0]                   dma_outstanding_o,
  output logic [15:0]                                     unexpected_cpl_o,
  output logic                                            fatal_o
);
  localparam int unsigned ADDR_W = sf_albion_host_pkg::SF_HTI_ADDR_W;
  localparam int unsigned TAG_W  = sf_albion_host_pkg::SF_HTI_TAG_W;

  // ---------------------------------------------------------------------------
  // The two paths
  // ---------------------------------------------------------------------------
  logic                h_evt_valid, h_evt_ready;
  logic [3:0]          h_evt_code;
  logic [TAG_W-1:0]    h_evt_tag;
  logic [ADDR_W-1:0]   h_evt_addr;
  logic                d_evt_valid, d_evt_ready;
  logic [3:0]          d_evt_code;
  logic [TAG_W-1:0]    d_evt_tag;
  logic [ADDR_W-1:0]   d_evt_addr;

  sf_albion_host_req_path #(
    .REQ_Q_DEPTH(REQ_Q_DEPTH), .WDATA_Q_DEPTH(WDATA_Q_DEPTH), .MAX_OUT(MAX_OUT),
    .MAX_REQ_BYTES(MAX_REQ_BYTES), .BOUNDARY_LOG2(BOUNDARY_LOG2), .EVT_Q_DEPTH(EVT_Q_DEPTH),
    .NUM_APERT(NUM_APERT), .AP_HBASE(AP_HBASE), .AP_SIZE(AP_SIZE), .AP_DBASE(AP_DBASE),
    .AP_ATTR(AP_ATTR), .AP_PERM(AP_PERM), .GUARD_EN(GUARD_EN)
  ) u_req (
    .clk_i, .rst_ni, .cancel_i,
    .hreq_valid_i, .hreq_ready_o, .hreq_kind_i, .hreq_addr_i, .hreq_len_i, .hreq_tag_i, .hreq_dom_i,
    .hw_valid_i, .hw_ready_o, .hw_data_i, .hw_be_i, .hw_last_i,
    .hcpl_valid_o, .hcpl_ready_i, .hcpl_tag_o, .hcpl_status_o, .hcpl_data_o, .hcpl_last_o,
    .m_req_valid_o, .m_req_ready_i, .m_req_o, .m_rsp_valid_i, .m_rsp_ready_o, .m_rsp_i,
    .grd_req_valid_o, .grd_dom_o, .grd_op_o, .grd_attr_o, .grd_addr_o, .grd_len_o,
    .grd_rsp_valid_i, .grd_permit_i, .grd_status_i,
    .evt_valid_o(h_evt_valid), .evt_ready_i(h_evt_ready), .evt_code_o(h_evt_code),
    .evt_tag_o(h_evt_tag), .evt_addr_o(h_evt_addr),
    .busy_o(host_busy_o), .outstanding_o(host_outstanding_o), .fatal_o
  );

  sf_albion_host_dma_path #(
    .NUM_TAGS(NUM_TAGS), .MPS_BYTES(MPS_BYTES), .MRRS_BYTES(MRRS_BYTES),
    .REQ_Q_DEPTH(DMA_REQ_Q_DEPTH), .WDATA_Q_DEPTH(DMA_WDATA_Q_DEPTH), .CK_Q_DEPTH(CK_Q_DEPTH),
    .EVT_Q_DEPTH(EVT_Q_DEPTH), .CPL_TIMEOUT(CPL_TIMEOUT)
  ) u_dma (
    .clk_i, .rst_ni, .cancel_i,
    .dma_req_valid_i, .dma_req_ready_o, .dma_req_write_i, .dma_req_posted_i,
    .dma_req_addr_i, .dma_req_len_i, .dma_req_id_i,
    .dma_w_valid_i, .dma_w_ready_o, .dma_w_data_i, .dma_w_be_i, .dma_w_last_i,
    .dma_r_valid_o, .dma_r_ready_i, .dma_r_id_o, .dma_r_status_o, .dma_r_is_write_o,
    .dma_r_data_o, .dma_r_be_o, .dma_r_last_o,
    .dreq_valid_o, .dreq_ready_i, .dreq_kind_o, .dreq_addr_o, .dreq_len_o, .dreq_tag_o,
    .dw_valid_o, .dw_ready_i, .dw_data_o, .dw_be_o, .dw_last_o,
    .dcpl_valid_i, .dcpl_ready_o, .dcpl_tag_i, .dcpl_status_i, .dcpl_data_i, .dcpl_last_i,
    .evt_valid_o(d_evt_valid), .evt_ready_i(d_evt_ready), .evt_code_o(d_evt_code),
    .evt_tag_o(d_evt_tag), .evt_addr_o(d_evt_addr),
    .busy_o(dma_busy_o), .outstanding_o(dma_outstanding_o), .unexpected_cpl_o
  );

  // ---------------------------------------------------------------------------
  // Event merge: round robin, choice locked while the consumer stalls (stable payload)
  // ---------------------------------------------------------------------------
  logic rr_q;        // 1: the DMA path has priority when both are valid
  logic lock_q;      // an event is on the output and has not been taken
  logic sel_q;       // locked choice: 1 = DMA
  logic pick_dma;

  always_comb begin
    if (lock_q)                                   pick_dma = sel_q;
    else if (d_evt_valid && (!h_evt_valid || rr_q)) pick_dma = 1'b1;
    else                                          pick_dma = 1'b0;

    err_evt_valid_o = h_evt_valid || d_evt_valid;
    err_evt_src_o   = pick_dma ? sf_albion_host_pkg::SF_HB_SRC_DMA : sf_albion_host_pkg::SF_HB_SRC_HOST;
    err_evt_code_o  = pick_dma ? d_evt_code : h_evt_code;
    err_evt_tag_o   = pick_dma ? d_evt_tag  : h_evt_tag;
    err_evt_addr_o  = pick_dma ? d_evt_addr : h_evt_addr;
    h_evt_ready     = err_evt_ready_i && !pick_dma;
    d_evt_ready     = err_evt_ready_i &&  pick_dma;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rr_q   <= 1'b0;
      lock_q <= 1'b0;
      sel_q  <= 1'b0;
    end else begin
      if (err_evt_valid_o && err_evt_ready_i) begin
        rr_q   <= !pick_dma;          // whoever was served last has the lower priority next time
        lock_q <= 1'b0;
      end else if (err_evt_valid_o) begin
        lock_q <= 1'b1;
        sel_q  <= pick_dma;
      end
    end
  end
endmodule

`default_nettype wire
