// =============================================================================
//  sf_albion_host_alp_arb2.sv  --  ALP v1 two-initiator arbiter
// -----------------------------------------------------------------------------
//  Merges two ALP initiator links (m0, m1) onto one target link (t).  AlbionCore has no crossbar; this is the
//  smallest conforming one the demonstration SoC needs (HostBridge and the DMA engine both reach the SRAM).
//
//  Request side
//    A registered, free-running turn bit decides which initiator may be accepted in a cycle, so every ready
//    output depends on registered state only (ALP-REQ-03).  Each initiator therefore gets at most one request
//    every other cycle.  The merged request is held in a skid register: valid and payload stay stable until the
//    target accepts (ALP-REQ-02).
//
//  Tags (ALP-TAG-03)
//    The arbiter is the initiator of the target link.  It stamps every request with its own running tag
//    (unique among outstanding while ORD_DEPTH <= 128) and restores the initiator's own tag on the response, so
//    ALP-TAG-01 holds on all three links even if both initiators use the same tag value.
//
//  Response side
//    ALP responses return in order (ALP-ORD-01); an order FIFO remembers which initiator each accepted request
//    belongs to and the response is steered to it with its own tag restored.
//
//  Reset (ALP-RST-02): everything is cleared; no response is generated for a request accepted before reset.
// =============================================================================
`default_nettype none

module sf_albion_host_alp_arb2 #(
  parameter int unsigned ORD_DEPTH = 32       // requests in flight on the merged link (2 .. 128)
) (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,
  // ---- initiator 0 ---------------------------------------------------------------------
  input  wire logic              m0_req_valid_i,
  output logic                   m0_req_ready_o,
  input  sf_albion_pkg::sf_req_t m0_req_i,
  output logic                   m0_rsp_valid_o,
  input  wire logic              m0_rsp_ready_i,
  output sf_albion_pkg::sf_rsp_t m0_rsp_o,
  // ---- initiator 1 ---------------------------------------------------------------------
  input  wire logic              m1_req_valid_i,
  output logic                   m1_req_ready_o,
  input  sf_albion_pkg::sf_req_t m1_req_i,
  output logic                   m1_rsp_valid_o,
  input  wire logic              m1_rsp_ready_i,
  output sf_albion_pkg::sf_rsp_t m1_rsp_o,
  // ---- target link ---------------------------------------------------------------------
  output logic                   t_req_valid_o,
  input  wire logic              t_req_ready_i,
  output sf_albion_pkg::sf_req_t t_req_o,
  input  wire logic              t_rsp_valid_i,
  output logic                   t_rsp_ready_o,
  input  sf_albion_pkg::sf_rsp_t t_rsp_i
);
  localparam int unsigned REQ_W = sf_albion_pkg::SF_REQ_W;
  localparam int unsigned RSP_W = sf_albion_pkg::SF_RSP_W;

  if (ORD_DEPTH < 2 || ORD_DEPTH > 128) begin : gen_param_check_ord
    $error("sf_albion_host_alp_arb2: ORD_DEPTH must be in 2..128");
  end

  logic                     turn_q;                  // 0: initiator 0 may be taken, 1: initiator 1
  logic [7:0]               tctr_q;                  // tag of the next merged request
  logic                     sel_valid, take, xfer;
  sf_albion_pkg::sf_req_t   sel_req, mreq;
  logic                     skid_in_ready;
  logic                     ord_in_ready;
  logic                     ord_out_valid, ord_out_ready;
  logic [8:0]               ord_out;
  logic                     ord_src;
  logic [7:0]               ord_tag;
  logic [RSP_W-1:0]         rsp_bits;
  sf_albion_pkg::sf_rsp_t   rsp_rest;

  // ---------------------------------------------------------------------------- requests
  assign sel_valid = turn_q ? m1_req_valid_i : m0_req_valid_i;
  assign sel_req   = turn_q ? m1_req_i : m0_req_i;
  assign take      = skid_in_ready && ord_in_ready;               // registered state only
  assign xfer      = sel_valid && take;
  assign m0_req_ready_o = !turn_q && take;
  assign m1_req_ready_o =  turn_q && take;

  always_comb begin
    mreq     = sel_req;
    mreq.tag = tctr_q;
  end

  sf_albion_skid #(.WIDTH(REQ_W)) u_req_skid (
    .clk_i, .rst_ni,
    .in_valid_i (xfer),          .in_ready_o(skid_in_ready), .in_data_i(mreq),
    .out_valid_o(t_req_valid_o), .out_ready_i(t_req_ready_i), .out_data_o(t_req_o)
  );

  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(9), .DEPTH(ORD_DEPTH)) u_ord (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (xfer),          .in_ready_o(ord_in_ready), .in_data_i({turn_q, sel_req.tag}),
    .out_valid_o(ord_out_valid), .out_ready_i(ord_out_ready), .out_data_o(ord_out),
    .count_o(), .full_o(), .empty_o()
  );
  /* verilator lint_on PINCONNECTEMPTY */
  assign {ord_src, ord_tag} = ord_out;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      turn_q <= 1'b0;
      tctr_q <= 8'h00;
    end else begin
      turn_q <= !turn_q;
      if (xfer) tctr_q <= tctr_q + 8'd1;
    end
  end

  // ---------------------------------------------------------------------------- responses
  always_comb begin
    rsp_rest     = t_rsp_i;
    rsp_rest.tag = ord_tag;
    rsp_bits     = rsp_rest;
  end
  assign m0_rsp_valid_o = t_rsp_valid_i && ord_out_valid && !ord_src;
  assign m1_rsp_valid_o = t_rsp_valid_i && ord_out_valid &&  ord_src;
  assign m0_rsp_o       = rsp_bits;
  assign m1_rsp_o       = rsp_bits;
  assign t_rsp_ready_o  = ord_out_valid && (ord_src ? m1_rsp_ready_i : m0_rsp_ready_i);
  assign ord_out_ready  = t_rsp_valid_i && t_rsp_ready_o;
endmodule

`default_nettype wire
