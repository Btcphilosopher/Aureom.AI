// =============================================================================
//  sf_albion_host_domain_guard.sv  --  reference DomainGuard for HostBridge (check-port compatible)
// -----------------------------------------------------------------------------
//  WHY THIS MODULE EXISTS.  The task for Module 96 asks for host-originated requests to pass through
//  "DomainGuard".  The repository audit of Module 94 (formal/albion, item U-DOMAINGUARD) recorded that
//  NO RTL named DomainGuard exists: domain protection is implemented by the Albion fabric permission
//  stage and by Citadel (P89: sf_citadel_domain_table / sf_citadel_permission / sf_citadel_gate).  This
//  module is therefore a small REFERENCE guard written to the check-port contract HostBridge drives; it
//  is not a replacement for Citadel, and it makes no security-certification claim.  Citadel's
//  sf_citadel_permission can be placed behind the same port (docs/DOMAIN_GUARD_SEAM.md).
//
//  Check port (the HELD request of HostBridge, never the live input; same fields as Citadel's chk_*)
//    chk_valid_i     a request is offered; fields stay stable until the verdict
//    chk_dom_i       claimed protection domain  (sf_albion_pkg domain space)
//    chk_op_i        SF_OP_READ / SF_OP_WRITE
//    chk_attr_i      ALP attribute byte of the request
//    chk_addr_i      first byte (device address)       chk_len_i  length in bytes (>= 1)
//    chk_rsp_valid_o verdict valid (combinational here: equal to chk_valid_i)
//    chk_permit_o    1 = permit      chk_status_o  ALP status: OKAY, BAD_OPCODE, BAD_ATTR or ACCESS_DENIED
//
//  Policy (DEFAULT DENY; the first failing rule decides)
//    1 domain 0xFF                                  -> ACCESS_DENIED
//    2 op not READ / WRITE                          -> BAD_OPCODE
//    3 attr reserved bit, memory type 3, instruction fetch + WRITE -> BAD_ATTR
//    4 len == 0, or addr + len - 1 wraps 2**64      -> ACCESS_DENIED
//    5 ROOT_BYPASS and domain ROOT                  -> PERMIT   (the platform root of trust bootstraps windows)
//    6 some VALID window has the same domain, contains [addr, addr+len-1] wholly, and grants the right
//                                                   -> PERMIT
//    7 otherwise                                    -> ACCESS_DENIED
//  A request that spans two windows is denied even if both would allow it (software splits per window).
//  The requester sees only the four coarse statuses above: unmapped, other-tenant and overflowing
//  addresses are indistinguishable (no layout oracle).
//
//  Window programming (cfg_*) is a PRIVILEGED MANAGEMENT port.  It must be driven only from the platform's
//  management plane (secure monitor / ControlCore), NEVER from a host-originated request.  After reset
//  every window is invalid.  A window is {valid, domain, base, limit (inclusive last byte), read, write}.
// =============================================================================
`default_nettype none

module sf_albion_host_domain_guard #(
  parameter int unsigned NUM_WIN     = 8,       // windows (1 .. 64)
  parameter bit          ROOT_BYPASS = 1'b1     // domain ROOT is permitted without a window
) (
  input  wire logic                                   clk_i,
  input  wire logic                                   rst_ni,
  // ---- privileged window programming ----------------------------------------------------------
  input  wire logic                                   cfg_we_i,
  input  wire logic [(NUM_WIN > 1 ? $clog2(NUM_WIN) : 1)-1:0] cfg_idx_i,
  input  wire logic [sf_albion_pkg::SF_ADDR_W-1:0]    cfg_base_i,
  input  wire logic [sf_albion_pkg::SF_ADDR_W-1:0]    cfg_limit_i,
  input  wire logic [sf_albion_pkg::SF_DOM_W-1:0]     cfg_dom_i,
  input  wire logic                                   cfg_rd_i,
  input  wire logic                                   cfg_wr_i,
  input  wire logic                                   cfg_valid_i,
  // ---- check port ------------------------------------------------------------------------------
  input  wire logic                                   chk_valid_i,
  input  wire logic [sf_albion_pkg::SF_DOM_W-1:0]     chk_dom_i,
  input  wire logic [sf_albion_pkg::SF_OP_W-1:0]      chk_op_i,
  input  wire logic [sf_albion_pkg::SF_ATTR_W-1:0]    chk_attr_i,
  input  wire logic [sf_albion_pkg::SF_ADDR_W-1:0]    chk_addr_i,
  input  wire logic [31:0]                            chk_len_i,
  output logic                                        chk_rsp_valid_o,
  output logic                                        chk_permit_o,
  output logic [sf_albion_pkg::SF_STATUS_W-1:0]       chk_status_o,
  // ---- audit ---------------------------------------------------------------------------------------
  output logic [31:0]                                 deny_count_o   // checks that ended in a denial
);
  localparam int unsigned AW = sf_albion_pkg::SF_ADDR_W;
  localparam int unsigned IW = (NUM_WIN > 1) ? $clog2(NUM_WIN) : 1;

  if (NUM_WIN < 1 || NUM_WIN > 64) begin : gen_param_check_win
    $error("sf_albion_host_domain_guard: NUM_WIN must be in 1..64");
  end

  logic [NUM_WIN-1:0] w_valid_q, w_rd_q, w_wr_q;
  logic [AW-1:0]      w_base_q  [NUM_WIN];
  logic [AW-1:0]      w_limit_q [NUM_WIN];
  logic [7:0]         w_dom_q   [NUM_WIN];

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      w_valid_q <= '0;                      // default deny: every window invalid after reset
      w_rd_q    <= '0;
      w_wr_q    <= '0;
    end else if (cfg_we_i) begin
      for (int unsigned i = 0; i < NUM_WIN; i++) begin
        if (cfg_idx_i == IW'(i)) begin
          w_valid_q[i] <= cfg_valid_i;
          w_rd_q[i]    <= cfg_rd_i;
          w_wr_q[i]    <= cfg_wr_i;
        end
      end
    end
  end

  always_ff @(posedge clk_i) begin
    if (cfg_we_i) begin
      for (int unsigned i = 0; i < NUM_WIN; i++) begin
        if (cfg_idx_i == IW'(i)) begin
          w_base_q[i]  <= cfg_base_i;
          w_limit_q[i] <= cfg_limit_i;
          w_dom_q[i]   <= cfg_dom_i;
        end
      end
    end
  end

  // ---- the decision ------------------------------------------------------------------------------------
  logic              op_rd, op_wr, attr_bad, len_zero, ovf, win_ok;
  logic [AW:0]       sum;
  logic [AW-1:0]     last;

  assign op_rd    = (chk_op_i == sf_albion_pkg::SF_OP_READ);
  assign op_wr    = (chk_op_i == sf_albion_pkg::SF_OP_WRITE);
  assign attr_bad = chk_attr_i[sf_albion_pkg::SF_ATTR_RSVD_BIT] ||
                    (chk_attr_i[sf_albion_pkg::SF_ATTR_MEMTYPE_LSB +: 2] == 2'd3) ||
                    (chk_attr_i[sf_albion_pkg::SF_ATTR_INSTR_BIT] && op_wr);
  assign len_zero = (chk_len_i == 32'd0);
  assign sum      = {1'b0, chk_addr_i} + {{(AW+1-32){1'b0}}, chk_len_i};
  assign ovf      = sum[AW] && (sum[AW-1:0] != '0);
  assign last     = sum[AW-1:0] - {{(AW-1){1'b0}}, 1'b1};

  always_comb begin
    win_ok = 1'b0;
    for (int unsigned i = 0; i < NUM_WIN; i++) begin
      if (w_valid_q[i] && (w_dom_q[i] == chk_dom_i) &&
          (chk_addr_i >= w_base_q[i]) && (last <= w_limit_q[i]) &&
          (op_rd ? w_rd_q[i] : w_wr_q[i])) begin
        win_ok = 1'b1;
      end
    end
  end

  always_comb begin
    chk_permit_o = 1'b0;
    chk_status_o = sf_albion_pkg::SF_ST_ACCESS_DENIED;
    if (chk_dom_i == sf_albion_pkg::SF_DOM_INVALID) begin
      chk_status_o = sf_albion_pkg::SF_ST_ACCESS_DENIED;
    end else if (!(op_rd || op_wr)) begin
      chk_status_o = sf_albion_pkg::SF_ST_BAD_OPCODE;
    end else if (attr_bad) begin
      chk_status_o = sf_albion_pkg::SF_ST_BAD_ATTR;
    end else if (len_zero || ovf) begin
      chk_status_o = sf_albion_pkg::SF_ST_ACCESS_DENIED;
    end else if (ROOT_BYPASS && (chk_dom_i == sf_albion_pkg::SF_DOM_ROOT)) begin
      chk_permit_o = 1'b1;
      chk_status_o = sf_albion_pkg::SF_ST_OKAY;
    end else if (win_ok) begin
      chk_permit_o = 1'b1;
      chk_status_o = sf_albion_pkg::SF_ST_OKAY;
    end
  end

  assign chk_rsp_valid_o = chk_valid_i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)                              deny_count_o <= '0;
    else if (chk_valid_i && !chk_permit_o && (deny_count_o != 32'hFFFF_FFFF)) deny_count_o <= deny_count_o + 32'd1;
  end
endmodule

`default_nettype wire
