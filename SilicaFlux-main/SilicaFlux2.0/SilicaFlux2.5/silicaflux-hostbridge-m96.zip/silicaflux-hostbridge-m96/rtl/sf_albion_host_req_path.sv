// =============================================================================
//  sf_albion_host_req_path.sv  --  HostBridge host-originated request path
// -----------------------------------------------------------------------------
//  Direction : host -> device.  Host MMIO and host memory requests (HREQ + HW
//              channels) become ALP v1 READ / WRITE requests on a fabric link;
//              ALP responses become HTI completions (HCPL channel).
//
//      hreq/hw --> queues --> validate + translate --> DomainGuard --> split
//                                                          |              |
//                          local error completions --------+     ALP request link
//                                       |                                |
//      hcpl <-- skid <-- in-order completion builder <-- ALP response link
//
//  What this module does, in the order a request meets it
//    1. QUEUES       hreq_* and hw_* are decoupled by FIFOs (request queue, write-data queue).
//    2. VALIDATE     kind, length (1 .. MAX_REQ_BYTES), 64-bit wrap, boundary crossing
//                    (2**BOUNDARY_LOG2 bytes), aperture match (a request must lie wholly inside
//                    ONE aperture), aperture read / write rights, reserved domain 0xFF.  The first
//                    failing check decides the status.  A rejected request never reaches the fabric.
//    3. TRANSLATE    host address -> device address with the aperture's base offset; the aperture
//                    also assigns the ALP attribute byte (privilege, memory type), so the host
//                    can never choose its own privilege.
//    4. GUARD        (GUARD_EN) the translated range is offered to a DomainGuard on the grd_*
//                    check port; the ALP request is created only after a PERMIT verdict.  There is
//                    no other path to the fabric (tb_hb_guard checks it).
//    5. SPLIT        one HTI request -> one ALP request per 16-byte word it touches.  Byte enables
//                    are the span mask ANDed with the host's per-beat strobes; a write word whose
//                    enables are all zero is skipped (ALP forbids BE == 0).
//    6. COMPLETE     ALP responses return in order (ALP-ORD-01), so completions return in request
//                    order.  A read completion is a stream of beats ending with hcpl_last; the first
//                    error ends it with one error beat and the rest of that request's responses are
//                    drained.  A write completion is one beat.
//
//  Write data.  Beat k of a write carries the word at (addr & ~15) + 16*k; lane j is byte j of that
//  word.  The number of beats is always sf_hti_nwords(addr[3:0], len): the bridge drains exactly that
//  many beats of a rejected write.  hw_last must mark the final beat; a mismatch is reported as a
//  protocol event and does not change the beat count.
//
//  Cancel (cancel_i).  Requests ACCEPTED no later than the cancel_i cycle that have not finished
//  issuing receive SF_HS_ABORTED (non-posted) or are dropped with an error event (posted).  Words
//  already issued cannot be recalled (ALP-CAN-01): their responses are consumed, and a write that was
//  part-issued reports ABORTED.  A request that had fully issued completes normally.
//  Reset (rst_ni) is the hard cancel: nothing is completed and every queue is empty afterwards.
//
//  Error events.  Every rejected request, every posted-write failure and every protocol violation
//  becomes one event {code, tag, address}.  Events go through a small FIFO; writers never drop an
//  event, they wait (fatal > completion engine > front end).
//
//  ALP conformance.  The request link register holds its payload until accepted (ALP-REQ-02); tags
//  come from sf_albion_tag_tracker (unique among outstanding, ALP-TAG-01; in-order response check
//  armed, ALP-TAG-02 / ALP-ORD-01).  m_rsp_ready_o depends on registered state and hcpl back-pressure
//  only (ALP-RSP-06).  A response that violates the protocol latches fatal_o until reset (ALP-RST-02).
// =============================================================================
`default_nettype none

module sf_albion_host_req_path #(
  parameter int unsigned REQ_Q_DEPTH    = 4,          // host request queue entries (>= 2)
  parameter int unsigned WDATA_Q_DEPTH  = 16,         // write-data beats buffered (>= 2)
  parameter int unsigned MAX_OUT        = 8,          // outstanding ALP words (1 .. 256)
  parameter int unsigned MAX_REQ_BYTES  = 4096,       // longest legal request, <= 4096
  parameter int unsigned BOUNDARY_LOG2  = 12,         // requests may not cross a 2**BOUNDARY_LOG2 boundary (4..12)
  parameter int unsigned EVT_Q_DEPTH    = 4,          // error-event FIFO entries (>= 2)
  parameter int unsigned NUM_APERT      = 2,          // apertures (1 .. 8)
  //  aperture i: host range [HBASE, HBASE+SIZE) -> device DBASE, ALP attribute ATTR, rights PERM {write, read}
  parameter logic [NUM_APERT*64-1:0] AP_HBASE = {64'h0000_0000_1000_0000, 64'h0000_0000_0000_0000},
  parameter logic [NUM_APERT*64-1:0] AP_SIZE  = {64'h0000_0000_0000_4000, 64'h0000_0000_0010_0000},
  parameter logic [NUM_APERT*64-1:0] AP_DBASE = {64'h0000_0001_1000_0000, 64'h0000_0001_2000_0000},
  parameter logic [NUM_APERT*8-1:0]  AP_ATTR  = {8'h00, 8'h06},
  parameter logic [NUM_APERT*2-1:0]  AP_PERM  = {2'b11, 2'b11},
  parameter bit          GUARD_EN       = 1'b1
) (
  input  wire logic                                       clk_i,
  input  wire logic                                       rst_ni,
  input  wire logic                                       cancel_i,
  // ---- HTI request channel (host -> device) -----------------------------------------
  input  wire logic                                       hreq_valid_i,
  output logic                                            hreq_ready_o,
  input  wire logic [sf_albion_host_pkg::SF_HTI_KIND_W-1:0]  hreq_kind_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_ADDR_W-1:0]  hreq_addr_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_LEN_W-1:0]   hreq_len_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]   hreq_tag_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DOM_W-1:0]   hreq_dom_i,
  // ---- HTI write-data channel (host -> device) ---------------------------------------
  input  wire logic                                       hw_valid_i,
  output logic                                            hw_ready_o,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]  hw_data_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_BE_W-1:0]    hw_be_i,
  input  wire logic                                       hw_last_i,
  // ---- HTI completion channel (device -> host) ---------------------------------------
  output logic                                            hcpl_valid_o,
  input  wire logic                                       hcpl_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]        hcpl_tag_o,
  output logic [sf_albion_host_pkg::SF_HTI_STATUS_W-1:0]     hcpl_status_o,
  output logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]       hcpl_data_o,
  output logic                                            hcpl_last_o,
  // ---- ALP v1 initiator link ------------------------------------------------------------
  output logic                                            m_req_valid_o,
  input  wire logic                                       m_req_ready_i,
  output sf_albion_pkg::sf_req_t                          m_req_o,
  input  wire logic                                       m_rsp_valid_i,
  output logic                                            m_rsp_ready_o,
  input  sf_albion_pkg::sf_rsp_t                          m_rsp_i,
  // ---- DomainGuard check port -------------------------------------------------------------
  output logic                                            grd_req_valid_o,
  output logic [sf_albion_pkg::SF_DOM_W-1:0]              grd_dom_o,
  output logic [sf_albion_pkg::SF_OP_W-1:0]               grd_op_o,
  output logic [sf_albion_pkg::SF_ATTR_W-1:0]             grd_attr_o,
  output logic [sf_albion_pkg::SF_ADDR_W-1:0]             grd_addr_o,
  output logic [31:0]                                     grd_len_o,
  input  wire logic                                       grd_rsp_valid_i,
  input  wire logic                                       grd_permit_i,
  input  wire logic [sf_albion_pkg::SF_STATUS_W-1:0]      grd_status_i,
  // ---- error events -------------------------------------------------------------------------
  output logic                                            evt_valid_o,
  input  wire logic                                       evt_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_STATUS_W-1:0]     evt_code_o,
  output logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]        evt_tag_o,
  output logic [sf_albion_host_pkg::SF_HTI_ADDR_W-1:0]       evt_addr_o,
  // ---- status ------------------------------------------------------------------------------------
  output logic                                            busy_o,
  output logic [$clog2(MAX_OUT+1)-1:0]                    outstanding_o,
  output logic                                            fatal_o
);
  localparam int unsigned ADDR_W   = sf_albion_host_pkg::SF_HTI_ADDR_W;
  localparam int unsigned DATA_W   = sf_albion_host_pkg::SF_HTI_DATA_W;
  localparam int unsigned BE_W     = sf_albion_host_pkg::SF_HTI_BE_W;
  localparam int unsigned TAG_W    = sf_albion_host_pkg::SF_HTI_TAG_W;
  localparam int unsigned DOM_W    = sf_albion_host_pkg::SF_HTI_DOM_W;
  localparam int unsigned LEN_W    = sf_albion_host_pkg::SF_HTI_LEN_W;
  localparam int unsigned KIND_W   = sf_albion_host_pkg::SF_HTI_KIND_W;
  localparam int unsigned WORDS_W  = sf_albion_host_pkg::SF_HTI_WORDS_W;
  localparam int unsigned RQ_W     = KIND_W + ADDR_W + LEN_W + TAG_W + DOM_W;
  localparam int unsigned WQ_W     = DATA_W + BE_W + 1;
  localparam int unsigned CW_W     = 2 + 1 + 1 + 1 + 1 + 4 + TAG_W;
  localparam int unsigned CW_DEPTH = MAX_OUT + 4;
  localparam int unsigned RQ_CNT_W = $clog2(REQ_Q_DEPTH + 1);
  localparam int unsigned BEAT_W   = TAG_W + 4 + DATA_W + 1;
  localparam int unsigned EVT_W    = 4 + TAG_W + ADDR_W;

  if (REQ_Q_DEPTH < 2) begin : gen_param_check_rqd
    $error("sf_albion_host_req_path: REQ_Q_DEPTH must be >= 2");
  end
  if (WDATA_Q_DEPTH < 2) begin : gen_param_check_wqd
    $error("sf_albion_host_req_path: WDATA_Q_DEPTH must be >= 2");
  end
  if (EVT_Q_DEPTH < 2) begin : gen_param_check_evd
    $error("sf_albion_host_req_path: EVT_Q_DEPTH must be >= 2");
  end
  if (MAX_OUT < 1 || MAX_OUT > sf_albion_pkg::SF_MAX_OUTSTANDING_LIMIT) begin : gen_param_check_out
    $error("sf_albion_host_req_path: MAX_OUT must be in 1..256");
  end
  if (MAX_REQ_BYTES < 16 || MAX_REQ_BYTES > sf_albion_host_pkg::SF_HTI_MAX_REQ_LIMIT) begin : gen_param_check_max
    $error("sf_albion_host_req_path: MAX_REQ_BYTES must be in 16..4096");
  end
  if (BOUNDARY_LOG2 < 4 || BOUNDARY_LOG2 > 12) begin : gen_param_check_bnd
    $error("sf_albion_host_req_path: BOUNDARY_LOG2 must be in 4..12");
  end
  if (NUM_APERT < 1 || NUM_APERT > 8) begin : gen_param_check_ap
    $error("sf_albion_host_req_path: NUM_APERT must be in 1..8");
  end
  for (genvar a = 0; a < NUM_APERT; a++) begin : gen_param_check_apert
    if (AP_SIZE[a*64 +: 64] < 64'd16) begin : gen_param_check_apsize
      $error("sf_albion_host_req_path: aperture size must be >= 16 bytes");
    end
    if (AP_DBASE[a*64 +: 4] != AP_HBASE[a*64 +: 4]) begin : gen_param_check_apalign
      $error("sf_albion_host_req_path: aperture device and host bases must have equal low 4 address bits");
    end
    if (AP_ATTR[a*8 + 7] || (AP_ATTR[a*8 +: 2] == 2'd3)) begin : gen_param_check_apattr
      $error("sf_albion_host_req_path: aperture attribute byte is illegal (reserved bit or memory type 3)");
    end
  end

  // ---------------------------------------------------------------------------
  // State encoding of the front end and completion-work entry types
  // ---------------------------------------------------------------------------
  localparam logic [2:0] S_IDLE  = 3'd0;
  localparam logic [2:0] S_VAL   = 3'd1;
  localparam logic [2:0] S_GUARD = 3'd2;
  localparam logic [2:0] S_ISSUE = 3'd3;
  localparam logic [2:0] S_DRAIN = 3'd4;
  localparam logic [2:0] S_END   = 3'd5;
  localparam logic [2:0] S_LOCAL = 3'd6;

  localparam logic [1:0] CW_WORD  = 2'd0;   // one ALP word in flight: its response is a completion beat
  localparam logic [1:0] CW_END   = 2'd1;   // end of a request that issued ALP words
  localparam logic [1:0] CW_LOCAL = 2'd2;   // a request answered locally (never reached the fabric)

  // ---------------------------------------------------------------------------
  // Request queue and write-data queue
  // ---------------------------------------------------------------------------
  logic                rq_out_valid, rq_out_ready;
  logic [RQ_W-1:0]     rq_out_bits;
  logic [RQ_CNT_W-1:0] rq_count;
  logic                wq_out_valid, wq_out_ready;
  logic [WQ_W-1:0]     wq_out_bits;

  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(RQ_W), .DEPTH(REQ_Q_DEPTH)) u_rq (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (hreq_valid_i), .in_ready_o(hreq_ready_o),
    .in_data_i  ({hreq_kind_i, hreq_addr_i, hreq_len_i, hreq_tag_i, hreq_dom_i}),
    .out_valid_o(rq_out_valid), .out_ready_i(rq_out_ready), .out_data_o(rq_out_bits),
    .count_o(rq_count), .full_o(), .empty_o()
  );

  sf_albion_fifo #(.WIDTH(WQ_W), .DEPTH(WDATA_Q_DEPTH)) u_wq (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (hw_valid_i), .in_ready_o(hw_ready_o),
    .in_data_i  ({hw_data_i, hw_be_i, hw_last_i}),
    .out_valid_o(wq_out_valid), .out_ready_i(wq_out_ready), .out_data_o(wq_out_bits),
    .count_o(), .full_o(), .empty_o()
  );

  /* verilator lint_on PINCONNECTEMPTY */

  logic [DATA_W-1:0] wq_data;
  logic [BE_W-1:0]   wq_be;
  logic              wq_last;
  assign {wq_data, wq_be, wq_last} = wq_out_bits;

  // ---------------------------------------------------------------------------
  // Front-end registers
  // ---------------------------------------------------------------------------
  logic [2:0]               fs_q, fs_d;
  logic [KIND_W-1:0]        kind_q, kind_d;
  logic [ADDR_W-1:0]        addr_q, addr_d;
  logic [LEN_W-1:0]         len_q, len_d;
  logic [TAG_W-1:0]         tag_q, tag_d;
  logic [DOM_W-1:0]         dom_q, dom_d;
  logic [ADDR_W-1:0]        daddr_q, daddr_d;           // translated device address of the first byte
  logic [7:0]               attr_q, attr_d;             // ALP attribute byte assigned by the aperture
  logic [3:0]               err_q, err_d;               // HTI status of a rejected request
  logic [WORDS_W-1:0]       widx_q, widx_d;             // word index inside the request
  logic                     issued_q, issued_d;         // at least one ALP word issued
  logic                     proto_q, proto_d;           // hw_last disagreed with the beat count
  logic                     abort_cur_q, abort_cur_d;   // current request is being cancelled
  logic [RQ_CNT_W-1:0]      abort_cnt_q, abort_cnt_d;   // queued requests still to be cancelled
  logic                     cancel_q;                   // cancel_i registered: all snapshots are consistent

  logic                     mv_q, mv_d;                 // ALP request link register
  logic [sf_albion_pkg::SF_REQ_W-1:0] mreq_q, mreq_d;

  // ---------------------------------------------------------------------------
  // Properties of the latched request and its validation (combinational)
  // ---------------------------------------------------------------------------
  logic                     has_data;
  logic                     is_write;
  logic                     posted;
  logic [31:0]              nwords32;
  logic [WORDS_W-1:0]       nwords;
  logic [ADDR_W:0]          sum65;
  logic [ADDR_W-1:0]        last_addr;
  logic                     ovf;
  logic                     len_zero, len_big, kind_bad, dom_bad;
  logic                     bound_cross;
  logic [NUM_APERT-1:0]     ap_start, ap_full;
  logic                     any_start, any_full;
  logic [ADDR_W-1:0]        v_daddr;
  logic [7:0]               v_attr;
  logic                     v_perm_ok;
  logic [3:0]               v_status;

  assign has_data = kind_q[1];
  assign is_write = (kind_q == sf_albion_host_pkg::SF_HK_WR) || (kind_q == sf_albion_host_pkg::SF_HK_WRP);
  assign posted   = (kind_q == sf_albion_host_pkg::SF_HK_WRP);
  assign nwords32 = sf_albion_host_pkg::sf_hti_nwords(addr_q[3:0], 32'(len_q));
  assign nwords   = nwords32[WORDS_W-1:0];
  logic unused_nwords;                  // a request has at most 513 words: the upper bits are always zero
  assign unused_nwords = &{1'b0, nwords32[31:WORDS_W]};

  assign sum65     = {1'b0, addr_q} + {{(ADDR_W+1-LEN_W){1'b0}}, len_q};
  assign last_addr = sum65[ADDR_W-1:0] - 64'd1;
  assign ovf       = sum65[ADDR_W] && (sum65[ADDR_W-1:0] != '0);
  assign len_zero  = (len_q == '0);
  assign len_big   = (len_q > LEN_W'(MAX_REQ_BYTES));
  assign kind_bad  = (kind_q == sf_albion_host_pkg::SF_HK_NONE);
  assign dom_bad   = (dom_q == sf_albion_pkg::SF_DOM_INVALID);
  assign bound_cross = (addr_q[ADDR_W-1:BOUNDARY_LOG2] != last_addr[ADDR_W-1:BOUNDARY_LOG2]);

  for (genvar a = 0; a < NUM_APERT; a++) begin : gen_ap
    localparam logic [63:0] AP_B = AP_HBASE[a*64 +: 64];
    localparam logic [63:0] AP_S = AP_SIZE[a*64 +: 64];
    // offset compare: an address below the base wraps to a huge offset and is outside
    assign ap_start[a] = ((addr_q - AP_B) < AP_S);
    assign ap_full[a]  = ap_start[a] && ((last_addr - AP_B) < AP_S);
  end

  assign any_start = (ap_start != '0);
  assign any_full  = (ap_full  != '0);

  always_comb begin
    v_daddr   = addr_q;
    v_attr    = 8'h00;
    v_perm_ok = 1'b0;
    // the lowest matching aperture decides translation, attribute and rights (loop runs high to low)
    for (int unsigned a = NUM_APERT; a > 0; a--) begin
      if (ap_start[a-1]) begin
        v_daddr   = AP_DBASE[(a-1)*64 +: 64] + (addr_q - AP_HBASE[(a-1)*64 +: 64]);
        v_attr    = AP_ATTR[(a-1)*8 +: 8];
        v_perm_ok = is_write ? AP_PERM[(a-1)*2 + 1] : AP_PERM[(a-1)*2];
      end
    end

    // first failing check decides
    v_status = sf_albion_host_pkg::SF_HS_OK;
    if (abort_cur_q)              v_status = sf_albion_host_pkg::SF_HS_ABORTED;
    else if (kind_bad)            v_status = sf_albion_host_pkg::SF_HS_BAD_REQ;
    else if (len_zero || len_big) v_status = sf_albion_host_pkg::SF_HS_BAD_LEN;
    else if (ovf)                 v_status = sf_albion_host_pkg::SF_HS_BOUNDARY;
    else if (bound_cross)         v_status = sf_albion_host_pkg::SF_HS_BOUNDARY;
    else if (dom_bad)             v_status = sf_albion_host_pkg::SF_HS_DENIED;
    else if (!any_start)          v_status = sf_albion_host_pkg::SF_HS_UR;
    else if (!any_full)           v_status = sf_albion_host_pkg::SF_HS_BOUNDARY;
    else if (!v_perm_ok)          v_status = sf_albion_host_pkg::SF_HS_DENIED;
  end

  // ---------------------------------------------------------------------------
  // Tag tracker (ALP tags, outstanding limit, in-order response check)
  // ---------------------------------------------------------------------------
  logic                     alloc_valid, alloc_ready;
  logic [sf_albion_pkg::SF_TAG_W-1:0] alloc_tag;
  logic                     free_valid;
  logic                     trk_sticky;

  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_tag_tracker #(.NUM_TAGS(MAX_OUT), .CTX_W(1), .CHECK_ORDER(1'b1)) u_trk (
    .clk_i, .rst_ni,
    .alloc_valid_i(alloc_valid), .alloc_ready_o(alloc_ready), .alloc_tag_o(alloc_tag), .alloc_ctx_i(1'b0),
    .free_valid_i (free_valid),  .free_tag_i(m_rsp_i.tag), .free_ctx_o(),
    .free_drop_o(), .free_unexpected_o(), .free_order_err_o(),
    .abandon_valid_i(1'b0), .abandon_tag_i('0), .abandon_all_i(1'b0),
    .outstanding_o(outstanding_o), .full_o(), .empty_o(), .sticky_err_o(trk_sticky)
  );
  /* verilator lint_on PINCONNECTEMPTY */
  assign fatal_o = trk_sticky;

  // ---------------------------------------------------------------------------
  // Completion-work FIFO: one entry per issued ALP word, per request end, per local completion
  // ---------------------------------------------------------------------------
  logic              cw_in_valid, cw_in_ready;
  logic [CW_W-1:0]   cw_in_bits;
  logic              cw_out_valid, cw_out_ready;
  logic [CW_W-1:0]   cw_out_bits;
  logic [1:0]        cw_typ;
  logic              cw_is_wr, cw_posted, cw_last, cw_abrt;
  logic [3:0]        cw_status;
  logic [TAG_W-1:0]  cw_tag;

  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(CW_W), .DEPTH(CW_DEPTH)) u_cw (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (cw_in_valid), .in_ready_o(cw_in_ready), .in_data_i(cw_in_bits),
    .out_valid_o(cw_out_valid), .out_ready_i(cw_out_ready), .out_data_o(cw_out_bits),
    .count_o(), .full_o(), .empty_o()
  );
  /* verilator lint_on PINCONNECTEMPTY */
  assign {cw_typ, cw_is_wr, cw_posted, cw_last, cw_abrt, cw_status, cw_tag} = cw_out_bits;

  // Address side FIFO: one entry per CW_END entry (pushed and popped together), so an event raised when a
  // request ends can name the request's address.
  logic                ea_in_valid, ea_out_ready, ea_out_valid;
  logic [ADDR_W-1:0]   ea_out;

  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(ADDR_W), .DEPTH(CW_DEPTH)) u_ea (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (ea_in_valid), .in_ready_o(), .in_data_i(addr_q),
    .out_valid_o(ea_out_valid), .out_ready_i(ea_out_ready), .out_data_o(ea_out),
    .count_o(), .full_o(), .empty_o()
  );
  /* verilator lint_on PINCONNECTEMPTY */

  // ---------------------------------------------------------------------------
  // Error-event FIFO and the three writers (fixed priority; a lower writer waits)
  // ---------------------------------------------------------------------------
  logic              evq_in_valid, evq_in_ready;
  logic [EVT_W-1:0]  evq_in_bits;
  logic              fatal_seen_q;
  logic              fat_req, eng_req, fe_req;
  logic              grant_fat, grant_eng, grant_fe;
  logic [3:0]        fe_evt_code;
  logic              local_evt_needed;

  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(EVT_W), .DEPTH(EVT_Q_DEPTH)) u_evq (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (evq_in_valid), .in_ready_o(evq_in_ready), .in_data_i(evq_in_bits),
    .out_valid_o(evt_valid_o),  .out_ready_i(evt_ready_i),
    .out_data_o ({evt_code_o, evt_tag_o, evt_addr_o}),
    .count_o(), .full_o(), .empty_o()
  );

  /* verilator lint_on PINCONNECTEMPTY */

  // ---------------------------------------------------------------------------
  // Front-end datapath
  // ---------------------------------------------------------------------------
  logic                     pop_now;
  logic                     last_word;
  logic [BE_W-1:0]          span_mask, word_be;
  logic                     word_skip;
  logic                     can_alp, issuing, issue_fire, skip_fire;
  logic [ADDR_W-1:0]        word_addr;
  logic [WORDS_W-1:0]       widx_next;
  sf_albion_pkg::sf_req_t   mreq_new;
  logic                     drain_beat;
  logic                     rem_beats;         // beats of the current request still to be drained

  assign pop_now      = (fs_q == S_IDLE) && rq_out_valid;
  assign rq_out_ready = pop_now;
  assign last_word    = (widx_q == nwords - WORDS_W'(1));
  assign widx_next    = widx_q + WORDS_W'(1);
  assign rem_beats    = has_data && (widx_q < nwords);

  always_comb begin
    span_mask = 16'hFFFF;
    if (widx_q == '0) span_mask = span_mask & sf_albion_host_pkg::sf_hti_first_mask(addr_q[3:0]);
    if (last_word)    span_mask = span_mask & sf_albion_host_pkg::sf_hti_last_mask(last_addr[3:0]);
    word_be   = is_write ? (span_mask & wq_be) : span_mask;
    word_skip = is_write && (word_be == '0);
    word_addr = {daddr_q[ADDR_W-1:4] + {{(ADDR_W-4-WORDS_W){1'b0}}, widx_q}, 4'h0};
  end

  assign can_alp    = alloc_ready && cw_in_ready && (!mv_q || m_req_ready_i);
  assign issuing    = (fs_q == S_ISSUE) && !abort_cur_q;
  assign issue_fire = issuing && !word_skip && (!is_write || wq_out_valid) && can_alp;
  assign skip_fire  = issuing && word_skip && wq_out_valid;
  assign drain_beat = (fs_q == S_DRAIN) && wq_out_valid;

  always_comb begin
    mreq_new      = '0;
    mreq_new.op   = is_write ? sf_albion_pkg::SF_OP_WRITE : sf_albion_pkg::SF_OP_READ;
    mreq_new.tag  = alloc_tag;
    mreq_new.dom  = dom_q;
    mreq_new.attr = attr_q;
    mreq_new.addr = word_addr;
    mreq_new.be   = word_be;
    mreq_new.data = is_write ? wq_data : '0;
  end

  assign alloc_valid  = issue_fire;
  assign wq_out_ready = ((issue_fire || skip_fire) && is_write) || drain_beat;

  // An error event is recorded for every rejected request except a cancelled non-posted one.
  assign local_evt_needed = (err_q != sf_albion_host_pkg::SF_HS_OK) &&
                            ((err_q != sf_albion_host_pkg::SF_HS_ABORTED) || (is_write && posted));
  assign fe_req = ((fs_q == S_LOCAL) && local_evt_needed) || ((fs_q == S_END) && proto_q);
  assign fe_evt_code = (fs_q == S_END) ? sf_albion_host_pkg::SF_HS_PROTO : err_q;

  // completion-work pushes
  logic end_push, local_push;
  assign end_push   = (fs_q == S_END)   && cw_in_ready && (!proto_q || grant_fe);
  assign local_push = (fs_q == S_LOCAL) && cw_in_ready && (!local_evt_needed || grant_fe);

  always_comb begin
    cw_in_valid = 1'b0;
    cw_in_bits  = '0;
    ea_in_valid = end_push;
    if (issue_fire) begin
      cw_in_valid = 1'b1;
      cw_in_bits  = {CW_WORD, is_write, posted, last_word, 1'b0, 4'h0, tag_q};
    end else if (end_push) begin
      cw_in_valid = 1'b1;
      cw_in_bits  = {CW_END, is_write, posted, 1'b0, abort_cur_q, 4'h0, tag_q};
    end else if (local_push) begin
      cw_in_valid = 1'b1;
      cw_in_bits  = {CW_LOCAL, is_write, posted, 1'b1, 1'b0, err_q, tag_q};
    end
  end

  // ---------------------------------------------------------------------------
  // Front-end FSM next state
  // ---------------------------------------------------------------------------
  always_comb begin
    fs_d     = fs_q;
    kind_d   = kind_q;
    addr_d   = addr_q;
    len_d    = len_q;
    tag_d    = tag_q;
    dom_d    = dom_q;
    daddr_d  = daddr_q;
    attr_d   = attr_q;
    err_d    = err_q;
    widx_d   = widx_q;
    issued_d = issued_q;
    proto_d  = proto_q;

    case (fs_q)
      S_IDLE: begin
        if (rq_out_valid) begin
          {kind_d, addr_d, len_d, tag_d, dom_d} = rq_out_bits;
          widx_d   = '0;
          issued_d = 1'b0;
          proto_d  = 1'b0;
          err_d    = sf_albion_host_pkg::SF_HS_OK;
          fs_d     = S_VAL;
        end
      end
      S_VAL: begin
        daddr_d = v_daddr;
        attr_d  = v_attr;
        if (v_status != sf_albion_host_pkg::SF_HS_OK) begin
          err_d = v_status;
          fs_d  = (has_data && (nwords != '0)) ? S_DRAIN : S_LOCAL;
        end else if (GUARD_EN) begin
          fs_d = S_GUARD;
        end else begin
          fs_d = S_ISSUE;
        end
      end
      S_GUARD: begin
        if (grd_rsp_valid_i) begin
          if (abort_cur_q) begin
            err_d = sf_albion_host_pkg::SF_HS_ABORTED;
            fs_d  = (has_data && (nwords != '0)) ? S_DRAIN : S_LOCAL;
          end else if (grd_permit_i) begin
            fs_d = S_ISSUE;
          end else begin
            // a deny verdict must not carry OKAY; if it does, treat it as DENIED
            err_d = (grd_status_i == sf_albion_pkg::SF_ST_OKAY)
                      ? sf_albion_host_pkg::SF_HS_DENIED
                      : sf_albion_host_pkg::sf_hti_status_from_alp(grd_status_i);
            fs_d  = (has_data && (nwords != '0)) ? S_DRAIN : S_LOCAL;
          end
        end
      end
      S_ISSUE: begin
        if (abort_cur_q) begin
          err_d = sf_albion_host_pkg::SF_HS_ABORTED;
          if (rem_beats)      fs_d = S_DRAIN;
          else if (issued_q)  fs_d = S_END;
          else                fs_d = S_LOCAL;
        end else if (issue_fire || skip_fire) begin
          widx_d = widx_next;
          if (issue_fire)  issued_d = 1'b1;
          if (is_write && (wq_last != last_word)) proto_d = 1'b1;
          if (last_word)   fs_d = S_END;
        end
      end
      S_DRAIN: begin
        if (drain_beat) begin
          widx_d = widx_next;
          if (widx_next == nwords) fs_d = issued_q ? S_END : S_LOCAL;
        end
      end
      S_END:   if (end_push)   fs_d = S_IDLE;
      S_LOCAL: if (local_push) fs_d = S_IDLE;
      default: fs_d = S_IDLE;
    endcase
  end

  // cancel bookkeeping (see the header comment for the exact contract)
  always_comb begin
    abort_cnt_d = abort_cnt_q;
    abort_cur_d = abort_cur_q;
    if (pop_now) begin
      abort_cur_d = 1'b0;
      if (abort_cnt_q != '0) begin
        abort_cnt_d = abort_cnt_q - RQ_CNT_W'(1);
        abort_cur_d = 1'b1;
      end
    end
    if (cancel_q) begin
      abort_cnt_d = rq_count - (pop_now ? RQ_CNT_W'(1) : RQ_CNT_W'(0));
      if (pop_now || (fs_q == S_VAL) || (fs_q == S_GUARD) || (fs_q == S_ISSUE)) abort_cur_d = 1'b1;
    end
  end

  // ALP request link register
  always_comb begin
    mv_d   = mv_q;
    mreq_d = mreq_q;
    if (mv_q && m_req_ready_i) mv_d = 1'b0;
    if (issue_fire) begin
      mv_d   = 1'b1;
      mreq_d = mreq_new;
    end
  end

  assign m_req_valid_o = mv_q;
  assign m_req_o       = mreq_q;

  // DomainGuard check port: the HELD request, never the live input
  assign grd_req_valid_o = GUARD_EN && (fs_q == S_GUARD);
  assign grd_dom_o       = dom_q;
  assign grd_op_o        = is_write ? sf_albion_pkg::SF_OP_WRITE : sf_albion_pkg::SF_OP_READ;
  assign grd_attr_o      = attr_q;
  assign grd_addr_o      = daddr_q;
  assign grd_len_o       = 32'(len_q);

  // ---------------------------------------------------------------------------
  // Completion builder: consumes the completion-work FIFO and the ALP response link
  // ---------------------------------------------------------------------------
  logic                out_in_valid, out_in_ready;
  logic [BEAT_W-1:0]   out_in_bits;
  logic [BEAT_W-1:0]   out_bits;
  logic [3:0]          agg_q, agg_d;      // first error of the current write request
  logic [3:0]          rerr_q, rerr_d;    // status that ended the current read request (OK if it ended well)
  logic                term_q, term_d;    // the current read request already ended its completion
  logic [3:0]          end_st;            // final status of the request whose END entry is at the head
  logic                end_ev, end_emit;
  logic                eng_clear;
  logic [3:0]          rsp_hs;
  logic                rsp_ok;
  logic                rsp_conf;
  logic                needs_out;
  logic [3:0]          eng_evt_code;

  sf_albion_skid #(.WIDTH(BEAT_W)) u_out (
    .clk_i, .rst_ni,
    .in_valid_i (out_in_valid), .in_ready_o(out_in_ready), .in_data_i(out_in_bits),
    .out_valid_o(hcpl_valid_o), .out_ready_i(hcpl_ready_i), .out_data_o(out_bits)
  );
  assign {hcpl_tag_o, hcpl_status_o, hcpl_data_o, hcpl_last_o} = out_bits;

  //  A response that is not well-formed (ALP-RSP-05) or whose operation flag does not match the request it
  //  answers (ALP-RSP-04) is never forwarded as data: it becomes SF_HS_PROTO.
  assign rsp_conf = sf_albion_pkg::sf_rsp_wellformed_bits(m_rsp_i) && (m_rsp_i.meta.is_write == cw_is_wr);
  assign rsp_hs   = rsp_conf ? sf_albion_host_pkg::sf_hti_status_from_alp(m_rsp_i.status)
                             : sf_albion_host_pkg::SF_HS_PROTO;
  assign rsp_ok   = rsp_conf && (m_rsp_i.status == sf_albion_pkg::SF_ST_OKAY);

  // Final status of the request whose END entry is at the head: a write reports its first error, a read the
  // status that ended it; a cancelled request that was not already complete reports ABORTED.
  always_comb begin
    if (cw_is_wr) begin
      end_st = (agg_q != sf_albion_host_pkg::SF_HS_OK) ? agg_q
             : (cw_abrt ? sf_albion_host_pkg::SF_HS_ABORTED : sf_albion_host_pkg::SF_HS_OK);
    end else begin
      end_st = (rerr_q != sf_albion_host_pkg::SF_HS_OK) ? rerr_q
             : ((cw_abrt && !term_q) ? sf_albion_host_pkg::SF_HS_ABORTED : sf_albion_host_pkg::SF_HS_OK);
    end
    // the host expects a completion beat from a non-posted write, and from a read that is not yet ended
    end_emit = cw_is_wr ? !cw_posted : (cw_abrt && !term_q);
    // every failure is logged, except the deliberate cancel of a request that has a completion to carry it
    end_ev   = (end_st != sf_albion_host_pkg::SF_HS_OK) &&
               ((end_st != sf_albion_host_pkg::SF_HS_ABORTED) || (cw_is_wr && cw_posted));
  end
  assign eng_req      = cw_out_valid && (cw_typ == CW_END) && end_ev && ea_out_valid;
  assign eng_evt_code = end_st;

  always_comb begin
    cw_out_ready  = 1'b0;
    out_in_valid  = 1'b0;
    out_in_bits   = '0;
    m_rsp_ready_o = 1'b0;
    free_valid    = 1'b0;
    agg_d         = agg_q;
    rerr_d        = rerr_q;
    term_d        = term_q;
    eng_clear     = 1'b0;
    ea_out_ready  = 1'b0;

    needs_out     = 1'b0;

    if (cw_out_valid) begin
      if (cw_typ == CW_LOCAL) begin
        if (cw_is_wr && cw_posted) begin
          cw_out_ready = 1'b1;                                  // posted: nothing goes back to the host
        end else if (out_in_ready) begin
          out_in_valid = 1'b1;
          out_in_bits  = {cw_tag, cw_status, {DATA_W{1'b0}}, 1'b1};
          cw_out_ready = 1'b1;
        end
      end else if (cw_typ == CW_END) begin
        if (ea_out_valid && (!end_emit || out_in_ready) && (!end_ev || grant_eng)) begin
          if (end_emit) begin
            out_in_valid = 1'b1;
            out_in_bits  = {cw_tag, end_st, {DATA_W{1'b0}}, 1'b1};
          end
          cw_out_ready = 1'b1;
          ea_out_ready = 1'b1;
          eng_clear    = 1'b1;
        end
      end else begin   // CW_WORD: one ALP response belongs to this entry
        needs_out     = !cw_is_wr && !term_q;
        m_rsp_ready_o = !needs_out || out_in_ready;
        free_valid    = m_rsp_valid_i && m_rsp_ready_o;
        if (m_rsp_valid_i && m_rsp_ready_o) begin
          cw_out_ready = 1'b1;
          if (cw_is_wr) begin
            if ((agg_q == sf_albion_host_pkg::SF_HS_OK) && !rsp_ok) agg_d = rsp_hs;
          end else if (!term_q) begin
            out_in_valid = 1'b1;
            if (rsp_ok) begin
              out_in_bits = {cw_tag, sf_albion_host_pkg::SF_HS_OK, m_rsp_i.data, cw_last};
              term_d      = cw_last;
            end else begin
              out_in_bits = {cw_tag, rsp_hs, {DATA_W{1'b0}}, 1'b1};
              term_d      = 1'b1;
              rerr_d      = rsp_hs;
            end
          end
        end
      end
    end

    if (eng_clear) begin
      agg_d  = sf_albion_host_pkg::SF_HS_OK;
      rerr_d = sf_albion_host_pkg::SF_HS_OK;
      term_d = 1'b0;
    end
  end

  // event arbitration
  assign fat_req   = trk_sticky && !fatal_seen_q;
  assign grant_fat = fat_req && evq_in_ready;
  assign grant_eng = eng_req && evq_in_ready && !fat_req;
  assign grant_fe  = fe_req  && evq_in_ready && !fat_req && !eng_req;

  always_comb begin
    evq_in_valid = grant_fat || grant_eng || grant_fe;
    evq_in_bits  = '0;
    if (grant_fat)      evq_in_bits = {sf_albion_host_pkg::SF_HS_PROTO, {TAG_W{1'b0}}, {ADDR_W{1'b0}}};
    else if (grant_eng) evq_in_bits = {eng_evt_code, cw_tag, ea_out};
    else if (grant_fe)  evq_in_bits = {fe_evt_code, tag_q, addr_q};
  end

  assign busy_o = (fs_q != S_IDLE) || rq_out_valid || cw_out_valid || mv_q || hcpl_valid_o;

  // ---------------------------------------------------------------------------
  // Registers
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      fs_q         <= S_IDLE;
      issued_q     <= 1'b0;
      proto_q      <= 1'b0;
      abort_cur_q  <= 1'b0;
      abort_cnt_q  <= '0;
      cancel_q     <= 1'b0;
      mv_q         <= 1'b0;
      agg_q        <= sf_albion_host_pkg::SF_HS_OK;
      rerr_q       <= sf_albion_host_pkg::SF_HS_OK;
      term_q       <= 1'b0;
      fatal_seen_q <= 1'b0;
      err_q        <= sf_albion_host_pkg::SF_HS_OK;
      widx_q       <= '0;
    end else begin
      fs_q         <= fs_d;
      issued_q     <= issued_d;
      proto_q      <= proto_d;
      abort_cur_q  <= abort_cur_d;
      abort_cnt_q  <= abort_cnt_d;
      cancel_q     <= cancel_i;
      mv_q         <= mv_d;
      agg_q        <= agg_d;
      rerr_q       <= rerr_d;
      term_q       <= term_d;
      err_q        <= err_d;
      widx_q       <= widx_d;
      if (grant_fat) fatal_seen_q <= 1'b1;
    end
  end

  // payload registers: not reset, qualified by the state / valid bits above
  always_ff @(posedge clk_i) begin
    kind_q  <= kind_d;
    addr_q  <= addr_d;
    len_q   <= len_d;
    tag_q   <= tag_d;
    dom_q   <= dom_d;
    daddr_q <= daddr_d;
    attr_q  <= attr_d;
    mreq_q  <= mreq_d;
  end
endmodule

`default_nettype wire
