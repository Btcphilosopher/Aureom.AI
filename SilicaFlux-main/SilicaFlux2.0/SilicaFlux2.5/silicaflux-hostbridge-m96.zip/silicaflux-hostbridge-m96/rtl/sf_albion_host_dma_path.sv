// =============================================================================
//  sf_albion_host_dma_path.sv  --  HostBridge device-originated DMA path
// -----------------------------------------------------------------------------
//  Direction : device -> host.  A DMA client (a copy engine, a queue manager, ...) asks for
//              memory reads and writes of HOST memory.  The bridge splits each request into
//              host requests, tracks them by tag, matches the (possibly out-of-order) host
//              completions, reassembles read data and hands the client one in-order result per
//              request.
//
//      dma_req/dma_w --> queues --> chunk splitter --> dreq / dw        (host-bound requests)
//                                        |
//                                    tag pool + chunk queue
//                                        |
//      dma_r <-- skid <-- drain <-- reorder buffer <-- dcpl             (host completions)
//
//  Client interface (all channels valid/ready)
//    dma_req   write, posted, addr (host address, any alignment), len (bytes, 1 .. 2**24-1), id
//    dma_w     write data beats, lane-aligned exactly like hw_* of the request path:
//              beat k = word at (addr & ~15) + 16*k; beat count = sf_hti_nwords(addr[3:0], len)
//    dma_r     one stream per request, in REQUEST ORDER:
//                read  : the words of the span, lanes outside [addr, addr+len) zero, dma_r_be = lanes
//                        that belong to the span; the last beat has dma_r_last = 1.  A failure ends
//                        the stream with ONE error beat (last = 1); earlier beats carry SF_HS_OK.
//                write : one beat (last = 1, is_write = 1): for a non-posted write when the host has
//                        acknowledged every chunk, for a posted write when the host side has accepted
//                        the data of every chunk.
//
//  Host-bound interface (HTI)
//    dreq/dw   kind (RD / WR / WRP), exact byte address and length, tag; write data beats follow
//              the request, lane-aligned, with byte strobes.  A request is presented only after the
//              previous write's data has been accepted, and a write's data only after its dreq was
//              accepted, so a host-side shim always sees whole packets in order.
//    dcpl      completion beats, tagged, any interleaving across tags, strictly in address order
//              within a tag; status is meaningful on the last beat; a non-OK status ends the request.
//              dcpl_ready_o is constant 1: every beat is consumed at once.
//
//  Splitting.  A request is cut at multiples of MPS_BYTES (writes) / MRRS_BYTES (reads), which are
//  powers of two <= 4096; hence no host request crosses a 4 KiB boundary and every interior chunk
//  edge is 16-byte aligned (no re-alignment of data is ever needed between chunks).
//
//  Ordering.  Host requests leave in the order the client's requests were accepted.  Host
//  completions may arrive in any order across tags (the out-of-order case this module is built for).
//  Results reach the client in request order.
//
//  Cancel (cancel_i).  Requests ACCEPTED no later than the cancel_i cycle that have not finished
//  issuing are ended with SF_HS_ABORTED.  Every outstanding host tag is ABANDONED: its request gets
//  SF_HS_ABORTED at once; the tag stays busy until its late completion arrives (data dropped) and is
//  then reused, so a stale completion can never be matched to a new request.  The chunk being
//  streamed is completed with all strobes cleared (a started packet is never truncated).
//  Timeout (CPL_TIMEOUT > 0).  A tag without completion for CPL_TIMEOUT cycles is abandoned with
//  SF_HS_TIMEOUT; after a second period it is released even if no completion ever arrives.
//  Reset (rst_ni) is the hard cancel.
//
//  Errors.  Every client-visible failure (not a deliberate cancel) becomes one error event.
//  Beats that match no outstanding tag are dropped and counted (unexpected_cpl_o, exact, saturating).  They are
//  also reported as PROTO events, coalesced: beats that arrive while an event is still pending add to the count
//  but not to the event stream, so a misbehaving host can never stall the bridge or flood the event log.
// =============================================================================
`default_nettype none

module sf_albion_host_dma_path #(
  parameter int unsigned NUM_TAGS      = 8,      // outstanding host requests that carry a tag (1 .. 64)
  parameter int unsigned MPS_BYTES     = 256,    // largest host write chunk (power of two, 16 .. 4096)
  parameter int unsigned MRRS_BYTES    = 256,    // largest host read chunk  (power of two, 32 .. 4096)
  parameter int unsigned REQ_Q_DEPTH   = 4,      // client request queue entries (>= 2)
  parameter int unsigned WDATA_Q_DEPTH = 16,     // client write-data beats buffered (>= 2)
  parameter int unsigned CK_Q_DEPTH    = 12,     // chunk queue entries (>= NUM_TAGS + 2)
  parameter int unsigned EVT_Q_DEPTH   = 4,      // error-event FIFO entries (>= 2)
  parameter int unsigned CPL_TIMEOUT   = 0       // completion timeout in cycles; 0 = disabled
) (
  input  wire logic                                       clk_i,
  input  wire logic                                       rst_ni,
  input  wire logic                                       cancel_i,
  // ---- DMA client: request ---------------------------------------------------------------
  input  wire logic                                       dma_req_valid_i,
  output logic                                            dma_req_ready_o,
  input  wire logic                                       dma_req_write_i,
  input  wire logic                                       dma_req_posted_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_ADDR_W-1:0]     dma_req_addr_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DMA_LEN_W-1:0]  dma_req_len_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_ID_W-1:0]       dma_req_id_i,
  // ---- DMA client: write data ---------------------------------------------------------------
  input  wire logic                                       dma_w_valid_i,
  output logic                                            dma_w_ready_o,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]     dma_w_data_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_BE_W-1:0]       dma_w_be_i,
  input  wire logic                                       dma_w_last_i,
  // ---- DMA client: result ------------------------------------------------------------------------
  output logic                                            dma_r_valid_o,
  input  wire logic                                       dma_r_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_ID_W-1:0]            dma_r_id_o,
  output logic [sf_albion_host_pkg::SF_HTI_STATUS_W-1:0]        dma_r_status_o,
  output logic                                            dma_r_is_write_o,
  output logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]          dma_r_data_o,
  output logic [sf_albion_host_pkg::SF_HTI_BE_W-1:0]            dma_r_be_o,
  output logic                                            dma_r_last_o,
  // ---- HTI request channel (device -> host) ---------------------------------------------------
  output logic                                            dreq_valid_o,
  input  wire logic                                       dreq_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_KIND_W-1:0]          dreq_kind_o,
  output logic [sf_albion_host_pkg::SF_HTI_ADDR_W-1:0]          dreq_addr_o,
  output logic [sf_albion_host_pkg::SF_HTI_LEN_W-1:0]           dreq_len_o,
  output logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]           dreq_tag_o,
  // ---- HTI write-data channel (device -> host) --------------------------------------------------
  output logic                                            dw_valid_o,
  input  wire logic                                       dw_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]          dw_data_o,
  output logic [sf_albion_host_pkg::SF_HTI_BE_W-1:0]            dw_be_o,
  output logic                                            dw_last_o,
  // ---- HTI completion channel (host -> device) --------------------------------------------------
  input  wire logic                                       dcpl_valid_i,
  output logic                                            dcpl_ready_o,
  input  wire logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]      dcpl_tag_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_STATUS_W-1:0]   dcpl_status_i,
  input  wire logic [sf_albion_host_pkg::SF_HTI_DATA_W-1:0]     dcpl_data_i,
  input  wire logic                                       dcpl_last_i,
  // ---- error events -----------------------------------------------------------------------------------
  output logic                                            evt_valid_o,
  input  wire logic                                       evt_ready_i,
  output logic [sf_albion_host_pkg::SF_HTI_STATUS_W-1:0]        evt_code_o,
  output logic [sf_albion_host_pkg::SF_HTI_TAG_W-1:0]           evt_tag_o,
  output logic [sf_albion_host_pkg::SF_HTI_ADDR_W-1:0]          evt_addr_o,
  // ---- status ------------------------------------------------------------------------------------------
  output logic                                            busy_o,
  output logic [$clog2(NUM_TAGS+1)-1:0]                   outstanding_o,
  output logic [15:0]                                     unexpected_cpl_o   // saturating count of dropped beats
);
  localparam int unsigned ADDR_W   = sf_albion_host_pkg::SF_HTI_ADDR_W;
  localparam int unsigned DATA_W   = sf_albion_host_pkg::SF_HTI_DATA_W;
  localparam int unsigned BE_W     = sf_albion_host_pkg::SF_HTI_BE_W;
  localparam int unsigned TAG_W    = sf_albion_host_pkg::SF_HTI_TAG_W;
  localparam int unsigned ID_W     = sf_albion_host_pkg::SF_HTI_ID_W;
  localparam int unsigned LEN_W    = sf_albion_host_pkg::SF_HTI_LEN_W;
  localparam int unsigned DLEN_W   = sf_albion_host_pkg::SF_HTI_DMA_LEN_W;
  localparam int unsigned WORDS_W  = sf_albion_host_pkg::SF_HTI_WORDS_W;
  localparam int unsigned CWORDS_W = DLEN_W - 3;                 // client beat counters (<= 2**20 + 1 words)
  localparam int unsigned TIDX_W   = (NUM_TAGS > 1) ? $clog2(NUM_TAGS) : 1;
  localparam int unsigned CHW_LOG2 = $clog2(MRRS_BYTES / 16);    // ROB words per tag = 2 ** CHW_LOG2
  localparam int unsigned ROB_AW   = TIDX_W + CHW_LOG2;
  localparam int unsigned CNT_W    = $clog2(NUM_TAGS + 1);
  localparam int unsigned RQ_W     = 1 + 1 + ADDR_W + DLEN_W + ID_W;
  localparam int unsigned WQ_W     = DATA_W + BE_W + 1;
  localparam int unsigned CK_W     = 2 + 1 + 1 + 1 + TAG_W + ID_W + 4 + LEN_W + 4;
  localparam int unsigned RES_W    = ID_W + 4 + 1 + DATA_W + BE_W + 1;
  localparam int unsigned EVT_W    = 4 + TAG_W + ADDR_W;
  localparam int unsigned RQ_CNT_W = $clog2(REQ_Q_DEPTH + 1);
  localparam int unsigned TMO_W    = (CPL_TIMEOUT > 1) ? $clog2(CPL_TIMEOUT + 1) : 1;

  if (NUM_TAGS < 1 || NUM_TAGS > 64) begin : gen_param_check_tags
    $error("sf_albion_host_dma_path: NUM_TAGS must be in 1..64");
  end
  if (MPS_BYTES < 16 || MPS_BYTES > 4096 || (MPS_BYTES & (MPS_BYTES - 1)) != 0) begin : gen_param_check_mps
    $error("sf_albion_host_dma_path: MPS_BYTES must be a power of two in 16..4096");
  end
  if (MRRS_BYTES < 32 || MRRS_BYTES > 4096 || (MRRS_BYTES & (MRRS_BYTES - 1)) != 0) begin : gen_param_check_mrrs
    $error("sf_albion_host_dma_path: MRRS_BYTES must be a power of two in 32..4096");
  end
  if (REQ_Q_DEPTH < 2 || WDATA_Q_DEPTH < 2 || EVT_Q_DEPTH < 2) begin : gen_param_check_depth
    $error("sf_albion_host_dma_path: queue depths must be >= 2");
  end
  if (CK_Q_DEPTH < NUM_TAGS + 2) begin : gen_param_check_ck
    $error("sf_albion_host_dma_path: CK_Q_DEPTH must be >= NUM_TAGS + 2");
  end

  // chunk-queue entry types
  localparam logic [1:0] CK_CHUNK = 2'd0;   // one host request
  localparam logic [1:0] CK_LOCAL = 2'd1;   // end of a request ended locally (error / cancel)

  // front-end states
  localparam logic [2:0] D_IDLE   = 3'd0;
  localparam logic [2:0] D_VAL    = 3'd1;
  localparam logic [2:0] D_CHUNK  = 3'd2;
  localparam logic [2:0] D_WDATA  = 3'd3;
  localparam logic [2:0] D_PUSH   = 3'd4;
  localparam logic [2:0] D_DRAINL = 3'd5;
  localparam logic [2:0] D_LOCAL  = 3'd6;
  localparam logic [2:0] D_PEVT   = 3'd7;

  // ---------------------------------------------------------------------------
  // Client queues
  // ---------------------------------------------------------------------------
  logic                rq_out_valid, rq_out_ready;
  logic [RQ_W-1:0]     rq_out_bits;
  logic [RQ_CNT_W-1:0] rq_count;
  logic                wq_out_valid, wq_out_ready;
  logic [WQ_W-1:0]     wq_out_bits;
  logic [DATA_W-1:0]   wq_data;
  logic [BE_W-1:0]     wq_be;
  logic                wq_last;

  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(RQ_W), .DEPTH(REQ_Q_DEPTH)) u_rq (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (dma_req_valid_i), .in_ready_o(dma_req_ready_o),
    .in_data_i  ({dma_req_write_i, dma_req_posted_i, dma_req_addr_i, dma_req_len_i, dma_req_id_i}),
    .out_valid_o(rq_out_valid), .out_ready_i(rq_out_ready), .out_data_o(rq_out_bits),
    .count_o(rq_count), .full_o(), .empty_o()
  );

  sf_albion_fifo #(.WIDTH(WQ_W), .DEPTH(WDATA_Q_DEPTH)) u_wq (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (dma_w_valid_i), .in_ready_o(dma_w_ready_o),
    .in_data_i  ({dma_w_data_i, dma_w_be_i, dma_w_last_i}),
    .out_valid_o(wq_out_valid), .out_ready_i(wq_out_ready), .out_data_o(wq_out_bits),
    .count_o(), .full_o(), .empty_o()
  );
  /* verilator lint_on PINCONNECTEMPTY */
  assign {wq_data, wq_be, wq_last} = wq_out_bits;

  // ---------------------------------------------------------------------------
  // Front-end registers
  // ---------------------------------------------------------------------------
  logic [2:0]          fs_q, fs_d;
  logic                wr_q, wr_d;
  logic                posted_q, posted_d;
  logic [ADDR_W-1:0]   addr_q, addr_d;          // request start (events)
  logic [DLEN_W-1:0]   len_q, len_d;
  logic [ID_W-1:0]     id_q, id_d;
  logic [ADDR_W-1:0]   cur_q, cur_d;            // start of the next chunk
  logic [DLEN_W-1:0]   rem_q, rem_d;            // bytes still to issue
  logic [LEN_W-1:0]    clen_q, clen_d;          // current chunk length
  logic                clast_q, clast_d;        // current chunk ends the request
  logic [TAG_W-1:0]    ctag_q, ctag_d;          // current chunk tag
  logic [WORDS_W-1:0]  wbeat_q, wbeat_d;        // beats of the current chunk loaded so far
  logic [WORDS_W-1:0]  wnb_q, wnb_d;            // beats of the current chunk in total
  logic [CWORDS_W-1:0] wcons_q, wcons_d;        // client beats consumed for this request
  logic [CWORDS_W-1:0] wtot_q, wtot_d;          // client beats the request owns
  logic                null_q, null_d;          // a chunk of this request was sent with strobes cleared
  logic                wproto_q, wproto_d;      // dma_w_last disagreed with the beat count
  logic [3:0]          err_q, err_d;            // status of a request ended locally
  logic                abort_cur_q, abort_cur_d;
  logic [RQ_CNT_W-1:0] abort_cnt_q, abort_cnt_d;
  logic                cancel_q;

  // registered host-bound request / data channels
  logic                                         dq_valid_q, dq_valid_d;
  logic [sf_albion_host_pkg::SF_HTI_KIND_W-1:0] dq_kind_q, dq_kind_d;
  logic [ADDR_W-1:0]                            dq_addr_q, dq_addr_d;
  logic [LEN_W-1:0]                             dq_len_q, dq_len_d;
  logic [TAG_W-1:0]                             dq_tag_q, dq_tag_d;
  logic                                         dwv_q, dwv_d;
  logic [DATA_W-1:0]                            dwd_q, dwd_d;
  logic [BE_W-1:0]                              dwb_q, dwb_d;
  logic                                         dwl_q, dwl_d;

  assign dreq_valid_o = dq_valid_q;
  assign dreq_kind_o  = dq_kind_q;
  assign dreq_addr_o  = dq_addr_q;
  assign dreq_len_o   = dq_len_q;
  assign dreq_tag_o   = dq_tag_q;
  assign dw_valid_o   = dwv_q;
  assign dw_data_o    = dwd_q;
  assign dw_be_o      = dwb_q;
  assign dw_last_o    = dwl_q;

  // ---------------------------------------------------------------------------
  // Per-tag state
  // ---------------------------------------------------------------------------
  logic [NUM_TAGS-1:0]   t_busy_q, t_done_q, t_aband_q, t_drained_q, t_to_q, t_wr_q;
  logic [NUM_TAGS-1:0]   t_busy_d, t_done_d, t_aband_d, t_drained_d, t_to_d, t_wr_d;
  logic [3:0]            t_err_q   [NUM_TAGS];
  logic [3:0]            t_err_d   [NUM_TAGS];
  logic [WORDS_W-1:0]    t_exp_q   [NUM_TAGS];
  logic [WORDS_W-1:0]    t_got_q   [NUM_TAGS];
  logic [WORDS_W-1:0]    t_got_d   [NUM_TAGS];
  logic [ADDR_W-1:0]     t_addr_q  [NUM_TAGS];
  logic [DATA_W-1:0]     rob_q     [2**ROB_AW];
  logic [NUM_TAGS-1:0]   t_free;
  logic [NUM_TAGS-1:0]   cn_mark, tmo_abort, tmo_force, dr_set;
  logic                  alloc_fire;

  assign t_free = t_busy_q & t_done_q & t_drained_q;
  // a cancel abandons every tag that has been issued and has not completed
  assign cn_mark = {NUM_TAGS{cancel_q}} & t_busy_q & ~t_done_q & ~t_aband_q;

  // allocation: lowest free tag
  logic                  tag_avail;
  logic [TIDX_W-1:0]     tag_idx;
  always_comb begin
    tag_avail = 1'b0;
    tag_idx   = '0;
    for (int unsigned i = 0; i < NUM_TAGS; i++) begin
      if (!tag_avail && !t_busy_q[i]) begin
        tag_avail = 1'b1;
        tag_idx   = TIDX_W'(i);
      end
    end
  end

  always_comb begin
    outstanding_o = '0;
    for (int unsigned i = 0; i < NUM_TAGS; i++) outstanding_o = outstanding_o + CNT_W'(t_busy_q[i]);
  end

  // ---------------------------------------------------------------------------
  // Chunk queue
  // ---------------------------------------------------------------------------
  logic              ck_in_valid, ck_in_ready;
  logic [CK_W-1:0]   ck_in_bits;
  logic              ck_out_valid, ck_out_ready;
  logic [CK_W-1:0]   ck_out_bits;
  logic [1:0]        ck_typ;
  logic              ck_is_wr, ck_posted, ck_plast;
  logic [TAG_W-1:0]  ck_tag;
  logic [ID_W-1:0]   ck_id;
  logic [3:0]        ck_lo;
  logic [LEN_W-1:0]  ck_len;
  logic [3:0]        ck_status;

  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(CK_W), .DEPTH(CK_Q_DEPTH)) u_ck (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (ck_in_valid), .in_ready_o(ck_in_ready), .in_data_i(ck_in_bits),
    .out_valid_o(ck_out_valid), .out_ready_i(ck_out_ready), .out_data_o(ck_out_bits),
    .count_o(), .full_o(), .empty_o()
  );
  /* verilator lint_on PINCONNECTEMPTY */
  assign {ck_typ, ck_is_wr, ck_posted, ck_plast, ck_tag, ck_id, ck_lo, ck_len, ck_status} = ck_out_bits;

  // ---------------------------------------------------------------------------
  // Error events (priority: drain engine > front end > unexpected completions)
  // ---------------------------------------------------------------------------
  logic              evq_in_valid, evq_in_ready;
  logic [EVT_W-1:0]  evq_in_bits;
  logic              eng_req, fe_req, unx_req;
  logic              grant_eng, grant_fe, grant_unx;
  logic [3:0]        eng_code, fe_code;
  logic [TAG_W-1:0]  eng_etag;
  logic [ADDR_W-1:0] eng_eaddr;
  logic              unx_pend_q, unx_pend_d;
  logic [TAG_W-1:0]  unx_tag_q, unx_tag_d;
  logic [15:0]       unx_cnt_q, unx_cnt_d;

  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(EVT_W), .DEPTH(EVT_Q_DEPTH)) u_evq (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (evq_in_valid), .in_ready_o(evq_in_ready), .in_data_i(evq_in_bits),
    .out_valid_o(evt_valid_o),  .out_ready_i(evt_ready_i),
    .out_data_o ({evt_code_o, evt_tag_o, evt_addr_o}),
    .count_o(), .full_o(), .empty_o()
  );
  /* verilator lint_on PINCONNECTEMPTY */

  assign grant_eng = eng_req && evq_in_ready;
  assign grant_fe  = fe_req  && evq_in_ready && !eng_req;
  assign grant_unx = unx_req && evq_in_ready && !eng_req && !fe_req;
  assign unexpected_cpl_o = unx_cnt_q;

  always_comb begin
    evq_in_valid = grant_eng || grant_fe || grant_unx;
    evq_in_bits  = '0;
    if (grant_eng)      evq_in_bits = {eng_code, eng_etag, eng_eaddr};
    else if (grant_fe)  evq_in_bits = {fe_code, id_q, addr_q};
    else if (grant_unx) evq_in_bits = {sf_albion_host_pkg::SF_HS_PROTO, unx_tag_q, {ADDR_W{1'b0}}};
  end

  // ---------------------------------------------------------------------------
  // Front end: request validation and chunk computation
  // ---------------------------------------------------------------------------
  logic                pop_now;
  logic [ADDR_W:0]     sum65;
  logic                v_wrap, v_zero;
  logic [3:0]          v_status;
  logic [31:0]         v_nw32;
  logic                posted_wr;
  logic [12:0]         cmax, to_bound;
  logic [DLEN_W-1:0]   to_bound_x;
  logic                last_chunk;
  logic [LEN_W-1:0]    clen_c;
  logic [31:0]         cnw32;
  logic                res_ok, can_dq;
  logic [3:0]          clast_lo_r;
  logic [CWORDS_W-1:0] rem_beats;
  logic                wd_last_beat, wd_load, wd_pop, drain_pop;
  logic [BE_W-1:0]     wd_mask, wd_be;
  logic                local_evt_needed;

  assign pop_now      = (fs_q == D_IDLE) && rq_out_valid;
  assign rq_out_ready = pop_now;

  assign sum65  = {1'b0, addr_q} + {{(ADDR_W+1-DLEN_W){1'b0}}, len_q};
  assign v_wrap = sum65[ADDR_W] && (sum65[ADDR_W-1:0] != '0);
  assign v_zero = (len_q == '0);
  assign v_nw32 = wr_q ? sf_albion_host_pkg::sf_hti_nwords(addr_q[3:0], 32'(len_q)) : 32'd0;

  always_comb begin
    v_status = sf_albion_host_pkg::SF_HS_OK;
    if (abort_cur_q)  v_status = sf_albion_host_pkg::SF_HS_ABORTED;
    else if (v_zero)  v_status = sf_albion_host_pkg::SF_HS_BAD_LEN;
    else if (v_wrap)  v_status = sf_albion_host_pkg::SF_HS_BOUNDARY;
  end

  assign posted_wr  = wr_q && posted_q;
  assign cmax       = wr_q ? 13'(MPS_BYTES) : 13'(MRRS_BYTES);
  assign to_bound   = cmax - {1'b0, cur_q[11:0] & (cmax[11:0] - 12'd1)};
  assign to_bound_x = {{(DLEN_W-13){1'b0}}, to_bound};
  assign last_chunk = (rem_q <= to_bound_x);
  assign clen_c     = last_chunk ? rem_q[LEN_W-1:0] : to_bound;
  assign cnw32      = sf_albion_host_pkg::sf_hti_nwords(cur_q[3:0], 32'(clen_c));
  assign clast_lo_r = cur_q[3:0] + clen_q[3:0] - 4'd1;
  logic unused_nw;      // word counts of a request / chunk fit in CWORDS_W / WORDS_W bits: upper bits are zero
  assign unused_nw = &{1'b0, v_nw32[31:CWORDS_W], cnw32[31:WORDS_W]};

  assign res_ok     = ck_in_ready && (posted_wr || tag_avail);
  assign can_dq     = !dq_valid_q && !dwv_q;
  assign alloc_fire = (fs_q == D_CHUNK) && !abort_cur_q && res_ok && can_dq && !posted_wr;

  // client write data: chunk streaming and draining of an ended request
  assign rem_beats    = wtot_q - wcons_q;
  assign wd_last_beat = (wbeat_q == wnb_q - WORDS_W'(1));
  always_comb begin
    wd_mask = 16'hFFFF;
    if (wbeat_q == '0) wd_mask = wd_mask & sf_albion_host_pkg::sf_hti_first_mask(cur_q[3:0]);
    if (wd_last_beat)  wd_mask = wd_mask & sf_albion_host_pkg::sf_hti_last_mask(clast_lo_r);
    wd_be = wq_be & wd_mask;
  end
  assign wd_load   = (fs_q == D_WDATA) && !dq_valid_q && (wbeat_q != wnb_q) &&
                     (!dwv_q || dw_ready_i) && (abort_cur_q || wq_out_valid);
  assign wd_pop    = wd_load && !abort_cur_q;
  assign drain_pop = (fs_q == D_DRAINL) && (rem_beats != '0) && wq_out_valid;
  assign wq_out_ready = wd_pop || drain_pop;

  assign local_evt_needed = (err_q != sf_albion_host_pkg::SF_HS_OK) && (err_q != sf_albion_host_pkg::SF_HS_ABORTED);
  assign fe_req  = ((fs_q == D_LOCAL) && local_evt_needed) || (fs_q == D_PEVT);
  assign fe_code = (fs_q == D_PEVT) ? sf_albion_host_pkg::SF_HS_PROTO : err_q;

  // chunk-queue pushes
  logic push_chunk, push_local;
  assign push_chunk = (fs_q == D_PUSH) && ck_in_ready;
  assign push_local = (fs_q == D_LOCAL) && ck_in_ready && (!local_evt_needed || grant_fe);

  always_comb begin
    ck_in_valid = 1'b0;
    ck_in_bits  = '0;
    if (push_chunk) begin
      ck_in_valid = 1'b1;
      ck_in_bits  = {CK_CHUNK, wr_q, posted_q, (clast_q && !null_q), ctag_q, id_q, cur_q[3:0], clen_q, 4'h0};
    end else if (push_local) begin
      ck_in_valid = 1'b1;
      ck_in_bits  = {CK_LOCAL, wr_q, posted_q, 1'b1, {TAG_W{1'b0}}, id_q, 4'h0, {LEN_W{1'b0}}, err_q};
    end
  end

  // ---------------------------------------------------------------------------
  // Front end FSM
  // ---------------------------------------------------------------------------
  always_comb begin
    fs_d     = fs_q;
    wr_d     = wr_q;
    posted_d = posted_q;
    addr_d   = addr_q;
    len_d    = len_q;
    id_d     = id_q;
    cur_d    = cur_q;
    rem_d    = rem_q;
    clen_d   = clen_q;
    clast_d  = clast_q;
    ctag_d   = ctag_q;
    wbeat_d  = wbeat_q;
    wnb_d    = wnb_q;
    wcons_d  = wcons_q;
    wtot_d   = wtot_q;
    null_d   = null_q;
    wproto_d = wproto_q;
    err_d    = err_q;
    dq_valid_d = dq_valid_q && !dreq_ready_i;
    dq_kind_d  = dq_kind_q;
    dq_addr_d  = dq_addr_q;
    dq_len_d   = dq_len_q;
    dq_tag_d   = dq_tag_q;
    dwv_d      = dwv_q && !dw_ready_i;
    dwd_d      = dwd_q;
    dwb_d      = dwb_q;
    dwl_d      = dwl_q;

    case (fs_q)
      D_IDLE: begin
        if (rq_out_valid) begin
          {wr_d, posted_d, addr_d, len_d, id_d} = rq_out_bits;
          cur_d    = addr_d;
          rem_d    = len_d;
          wcons_d  = '0;
          null_d   = 1'b0;
          wproto_d = 1'b0;
          err_d    = sf_albion_host_pkg::SF_HS_OK;
          fs_d     = D_VAL;
        end
      end
      D_VAL: begin
        wtot_d = v_nw32[CWORDS_W-1:0];
        if (v_status != sf_albion_host_pkg::SF_HS_OK) begin
          err_d = v_status;
          fs_d  = D_DRAINL;
        end else begin
          fs_d = D_CHUNK;
        end
      end
      D_CHUNK: begin
        if (abort_cur_q) begin
          err_d = sf_albion_host_pkg::SF_HS_ABORTED;
          fs_d  = D_DRAINL;
        end else if (res_ok && can_dq) begin
          dq_valid_d = 1'b1;
          dq_kind_d  = !wr_q ? sf_albion_host_pkg::SF_HK_RD
                             : (posted_q ? sf_albion_host_pkg::SF_HK_WRP : sf_albion_host_pkg::SF_HK_WR);
          dq_addr_d  = cur_q;
          dq_len_d   = clen_c;
          dq_tag_d   = posted_wr ? {TAG_W{1'b0}} : TAG_W'(tag_idx);
          clen_d     = clen_c;
          clast_d    = last_chunk;
          ctag_d     = posted_wr ? {TAG_W{1'b0}} : TAG_W'(tag_idx);
          wnb_d      = cnw32[WORDS_W-1:0];
          wbeat_d    = '0;
          fs_d       = wr_q ? D_WDATA : D_PUSH;
        end
      end
      D_WDATA: begin
        if (wd_load) begin
          dwv_d   = 1'b1;
          dwd_d   = abort_cur_q ? {DATA_W{1'b0}} : wq_data;
          dwb_d   = abort_cur_q ? {BE_W{1'b0}}   : wd_be;
          dwl_d   = wd_last_beat;
          wbeat_d = wbeat_q + WORDS_W'(1);
          if (abort_cur_q) begin
            null_d = 1'b1;
          end else begin
            wcons_d = wcons_q + CWORDS_W'(1);
            if (wq_last != (wcons_q == wtot_q - CWORDS_W'(1))) wproto_d = 1'b1;
          end
          if (wd_last_beat) fs_d = D_PUSH;
        end
      end
      D_PUSH: begin
        if (ck_in_ready) begin
          cur_d = cur_q + {{(ADDR_W-LEN_W){1'b0}}, clen_q};
          rem_d = rem_q - {{(DLEN_W-LEN_W){1'b0}}, clen_q};
          if (clast_q && !null_q) fs_d = wproto_q ? D_PEVT : D_IDLE;
          else                    fs_d = D_CHUNK;
        end
      end
      D_DRAINL: begin
        if (rem_beats == '0) begin
          fs_d = D_LOCAL;
        end else if (drain_pop) begin
          wcons_d = wcons_q + CWORDS_W'(1);
          if (rem_beats == CWORDS_W'(1)) fs_d = D_LOCAL;
        end
      end
      D_LOCAL: begin
        if (push_local) fs_d = D_IDLE;
      end
      D_PEVT: begin
        if (grant_fe) fs_d = D_IDLE;
      end
      default: fs_d = D_IDLE;
    endcase
  end

  // cancel bookkeeping (same scheme as the request path)
  always_comb begin
    abort_cnt_d = abort_cnt_q;
    abort_cur_d = abort_cur_q;
    if (pop_now) begin
      abort_cur_d = 1'b0;
      if (abort_cnt_q != '0) begin
        abort_cnt_d = abort_cnt_q - RQ_CNT_W'(1);
        abort_cur_d = 1'b1;
      end
    end
    if (cancel_q) begin
      abort_cnt_d = rq_count - (pop_now ? RQ_CNT_W'(1) : RQ_CNT_W'(0));
      if (pop_now || (fs_q == D_VAL) || (fs_q == D_CHUNK) || (fs_q == D_WDATA) || (fs_q == D_PUSH)) begin
        abort_cur_d = 1'b1;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Host completions: tag match, reorder buffer, per-tag state
  // ---------------------------------------------------------------------------
  logic [TIDX_W-1:0]  dc_idx;
  logic               dc_inrange, dc_hit, dc_unexp;
  logic               dc_wr, dc_aband, dc_ok;
  logic [WORDS_W-1:0] dc_got, dc_exp;
  logic               rob_we;
  logic [ROB_AW-1:0]  rob_waddr;
  logic               dc_term;
  logic [3:0]         dc_err;

  assign dcpl_ready_o = 1'b1;
  assign dc_idx       = dcpl_tag_i[TIDX_W-1:0];
  assign dc_inrange   = (dcpl_tag_i < TAG_W'(NUM_TAGS));
  assign dc_hit       = dcpl_valid_i && dc_inrange && t_busy_q[dc_idx] && !t_done_q[dc_idx];
  assign dc_unexp     = dcpl_valid_i && !dc_hit;
  assign dc_wr        = t_wr_q[dc_idx];
  assign dc_aband     = t_aband_q[dc_idx];
  assign dc_got       = t_got_q[dc_idx];
  assign dc_exp       = t_exp_q[dc_idx];
  assign dc_ok        = (dcpl_status_i == sf_albion_host_pkg::SF_HS_OK);
  assign rob_we       = dc_hit && !dc_wr && !dc_aband && dc_ok && (dc_got < dc_exp);
  assign rob_waddr    = {dc_idx, dc_got[CHW_LOG2-1:0]};

  always_comb begin
    dc_term = 1'b0;
    dc_err  = sf_albion_host_pkg::SF_HS_OK;
    if (dc_wr) begin                                   // write acknowledgement: any beat ends it
      dc_term = 1'b1;
      dc_err  = dcpl_status_i;
    end else if (!dc_ok) begin                         // a failed read ends at once
      dc_term = 1'b1;
      dc_err  = dcpl_status_i;
    end else if (dc_aband) begin                       // late data of an abandoned read: drop, end at last
      dc_term = dcpl_last_i;
    end else if (dc_got >= dc_exp) begin               // more beats than the request owns
      dc_term = 1'b1;
      dc_err  = sf_albion_host_pkg::SF_HS_PROTO;
    end else begin
      dc_term = dcpl_last_i;
      if (dc_got + WORDS_W'(1) != dc_exp) dc_err = sf_albion_host_pkg::SF_HS_PROTO;   // short completion
    end
  end

  always_ff @(posedge clk_i) begin
    if (rob_we) rob_q[rob_waddr] <= dcpl_data_i;
  end

  // timeout: a tag that has been issued and has not completed counts cycles
  if (CPL_TIMEOUT > 0) begin : gen_tmo
    logic [TMO_W-1:0] t_tmo_q [NUM_TAGS];
    logic [TMO_W-1:0] t_tmo_d [NUM_TAGS];
    always_comb begin
      for (int unsigned i = 0; i < NUM_TAGS; i++) begin
        t_tmo_d[i]   = t_tmo_q[i] + TMO_W'(1);
        tmo_abort[i] = 1'b0;
        tmo_force[i] = 1'b0;
        if (!(t_busy_q[i] && !t_done_q[i]) || cn_mark[i]) begin
          t_tmo_d[i] = '0;
        end else if (t_tmo_q[i] == TMO_W'(CPL_TIMEOUT - 1)) begin
          t_tmo_d[i]   = '0;
          tmo_abort[i] = !t_aband_q[i];
          tmo_force[i] = t_aband_q[i];
        end
      end
    end
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        for (int unsigned i = 0; i < NUM_TAGS; i++) t_tmo_q[i] <= '0;
      end else begin
        for (int unsigned i = 0; i < NUM_TAGS; i++) t_tmo_q[i] <= t_tmo_d[i];
      end
    end
  end else begin : gen_no_tmo
    assign tmo_abort = '0;
    assign tmo_force = '0;
  end

  always_comb begin
    for (int unsigned i = 0; i < NUM_TAGS; i++) begin
      t_busy_d[i]    = t_busy_q[i];
      t_done_d[i]    = t_done_q[i];
      t_aband_d[i]   = t_aband_q[i];
      t_drained_d[i] = t_drained_q[i];
      t_to_d[i]      = t_to_q[i];
      t_wr_d[i]      = t_wr_q[i];
      t_err_d[i]     = t_err_q[i];
      t_got_d[i]     = t_got_q[i];
      if (t_free[i]) begin
        t_busy_d[i]    = 1'b0;
        t_done_d[i]    = 1'b0;
        t_aband_d[i]   = 1'b0;
        t_drained_d[i] = 1'b0;
        t_to_d[i]      = 1'b0;
      end else begin
        if (alloc_fire && (tag_idx == TIDX_W'(i))) begin
          t_busy_d[i]    = 1'b1;
          t_done_d[i]    = 1'b0;
          t_aband_d[i]   = 1'b0;
          t_drained_d[i] = 1'b0;
          t_to_d[i]      = 1'b0;
          t_wr_d[i]      = wr_q;
          t_err_d[i]     = sf_albion_host_pkg::SF_HS_OK;
          t_got_d[i]     = '0;
        end
        if (dc_hit && (dc_idx == TIDX_W'(i))) begin
          if (rob_we) t_got_d[i] = t_got_q[i] + WORDS_W'(1);
          if (dc_term) begin
            t_done_d[i] = 1'b1;
            t_err_d[i]  = dc_err;
          end
        end
        if (cn_mark[i])    t_aband_d[i] = 1'b1;
        if (tmo_abort[i]) begin
          t_aband_d[i] = 1'b1;
          t_to_d[i]    = 1'b1;
        end
        if (tmo_force[i])  t_done_d[i] = 1'b1;
        if (dr_set[i])     t_drained_d[i] = 1'b1;
      end
    end
  end

  // unexpected completion beats: counted, reported as one coalesced event
  assign unx_req = unx_pend_q;
  always_comb begin
    unx_cnt_d  = unx_cnt_q;
    unx_pend_d = unx_pend_q;
    unx_tag_d  = unx_tag_q;
    if (grant_unx) unx_pend_d = 1'b0;
    if (dc_unexp) begin
      if (unx_cnt_q != 16'hFFFF) unx_cnt_d = unx_cnt_q + 16'd1;
      if (!unx_pend_q || grant_unx) begin
        unx_pend_d = 1'b1;
        unx_tag_d  = dcpl_tag_i;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Drain engine: one in-order result per client request
  // ---------------------------------------------------------------------------
  logic                res_in_valid, res_in_ready;
  logic [RES_W-1:0]    res_in_bits, res_bits;
  logic [WORDS_W-1:0]  dr_k_q, dr_k_d;
  logic                pterm_q, pterm_d;        // the current read request already ended its stream
  logic [3:0]          pagg_q, pagg_d;          // first error of the current write request
  logic [TIDX_W-1:0]   tagi;
  logic                t_done, t_aband, t_to, pw;
  logic [3:0]          t_err, chunk_status, agg_new;
  logic                chunk_ready, ev_need;
  logic [31:0]         dr_nw32;
  logic [WORDS_W-1:0]  dr_nw;
  logic [BE_W-1:0]     dr_mask;
  logic [3:0]          dr_last_lo;
  logic [DATA_W-1:0]   dr_word;
  logic                dr_clear;

  sf_albion_skid #(.WIDTH(RES_W)) u_res (
    .clk_i, .rst_ni,
    .in_valid_i (res_in_valid), .in_ready_o(res_in_ready), .in_data_i(res_in_bits),
    .out_valid_o(dma_r_valid_o), .out_ready_i(dma_r_ready_i), .out_data_o(res_bits)
  );
  assign {dma_r_id_o, dma_r_status_o, dma_r_is_write_o, dma_r_data_o, dma_r_be_o, dma_r_last_o} = res_bits;

  assign tagi         = ck_tag[TIDX_W-1:0];
  assign t_done       = t_done_q[tagi];
  assign t_aband      = t_aband_q[tagi];
  assign t_to         = t_to_q[tagi];
  assign t_err        = t_err_q[tagi];
  assign pw           = ck_is_wr && ck_posted;
  assign chunk_ready  = pw ? !dwv_q : (t_done || t_aband);
  assign chunk_status = pw ? sf_albion_host_pkg::SF_HS_OK
                      : (t_aband ? (t_to ? sf_albion_host_pkg::SF_HS_TIMEOUT : sf_albion_host_pkg::SF_HS_ABORTED)
                                 : t_err);
  // One event per client-visible failure: a write request whose first error was already logged stays quiet
  // (a read request skips its later chunks, so it can only fail once).
  assign ev_need      = (chunk_status != sf_albion_host_pkg::SF_HS_OK) &&
                        (chunk_status != sf_albion_host_pkg::SF_HS_ABORTED) &&
                        (!ck_is_wr || (pagg_q == sf_albion_host_pkg::SF_HS_OK));
  assign agg_new      = (pagg_q != sf_albion_host_pkg::SF_HS_OK) ? pagg_q : chunk_status;

  assign dr_nw32    = sf_albion_host_pkg::sf_hti_nwords(ck_lo, 32'(ck_len));
  assign dr_nw      = dr_nw32[WORDS_W-1:0];
  logic unused_dr;      // ck_tag is a wire tag; only the tag index bits are used, and the word count fits WORDS_W
  assign unused_dr = &{1'b0, dr_nw32[31:WORDS_W], ck_tag[TAG_W-1:TIDX_W]};
  assign dr_last_lo = ck_lo + ck_len[3:0] - 4'd1;
  always_comb begin
    dr_mask = 16'hFFFF;
    if (dr_k_q == '0)                 dr_mask = dr_mask & sf_albion_host_pkg::sf_hti_first_mask(ck_lo);
    if (dr_k_q == dr_nw - WORDS_W'(1)) dr_mask = dr_mask & sf_albion_host_pkg::sf_hti_last_mask(dr_last_lo);
    dr_word = rob_q[{tagi, dr_k_q[CHW_LOG2-1:0]}] & sf_albion_host_pkg::sf_hti_expand_be(dr_mask);
  end

  always_comb begin
    ck_out_ready = 1'b0;
    res_in_valid = 1'b0;
    res_in_bits  = '0;
    dr_k_d       = dr_k_q;
    pterm_d      = pterm_q;
    pagg_d       = pagg_q;
    dr_clear     = 1'b0;
    dr_set       = '0;
    eng_req      = 1'b0;
    eng_code     = chunk_status;
    eng_etag     = ck_id;
    eng_eaddr    = t_addr_q[tagi];

    if (ck_out_valid) begin
      if (ck_typ == CK_LOCAL) begin
        if (ck_is_wr) begin
          if (res_in_ready) begin
            res_in_valid = 1'b1;
            res_in_bits  = {ck_id, (pagg_q != sf_albion_host_pkg::SF_HS_OK) ? pagg_q : ck_status,
                            1'b1, {DATA_W{1'b0}}, {BE_W{1'b0}}, 1'b1};
            ck_out_ready = 1'b1;
            dr_clear     = 1'b1;
          end
        end else if (pterm_q) begin
          ck_out_ready = 1'b1;
          dr_clear     = 1'b1;
        end else if (res_in_ready) begin
          res_in_valid = 1'b1;
          res_in_bits  = {ck_id, ck_status, 1'b0, {DATA_W{1'b0}}, {BE_W{1'b0}}, 1'b1};
          ck_out_ready = 1'b1;
          dr_clear     = 1'b1;
        end
      end else if (chunk_ready) begin
        if (ck_is_wr) begin
          // one chunk of a write request
          eng_req = ev_need;
          if (ck_plast) begin
            if (res_in_ready && (!ev_need || grant_eng)) begin
              res_in_valid = 1'b1;
              res_in_bits  = {ck_id, agg_new, 1'b1, {DATA_W{1'b0}}, {BE_W{1'b0}}, 1'b1};
              ck_out_ready = 1'b1;
              dr_clear     = 1'b1;
              dr_set[tagi] = !pw;
            end
          end else if (!ev_need || grant_eng) begin
            ck_out_ready = 1'b1;
            pagg_d       = agg_new;
            dr_set[tagi] = !pw;
          end
        end else if (pterm_q) begin
          // an earlier chunk of this read request failed: this chunk is only released
          ck_out_ready = 1'b1;
          dr_set[tagi] = 1'b1;
          if (ck_plast) dr_clear = 1'b1;
        end else if (chunk_status != sf_albion_host_pkg::SF_HS_OK) begin
          eng_req = ev_need;
          if (res_in_ready && (!ev_need || grant_eng)) begin
            res_in_valid = 1'b1;
            res_in_bits  = {ck_id, chunk_status, 1'b0, {DATA_W{1'b0}}, {BE_W{1'b0}}, 1'b1};
            ck_out_ready = 1'b1;
            dr_set[tagi] = 1'b1;
            pterm_d      = !ck_plast;
            if (ck_plast) dr_clear = 1'b1;
          end
        end else if (res_in_ready) begin
          // stream the words of a completed read chunk
          res_in_valid = 1'b1;
          res_in_bits  = {ck_id, sf_albion_host_pkg::SF_HS_OK, 1'b0, dr_word, dr_mask,
                          (ck_plast && (dr_k_q == dr_nw - WORDS_W'(1)))};
          if (dr_k_q == dr_nw - WORDS_W'(1)) begin
            ck_out_ready = 1'b1;
            dr_set[tagi] = 1'b1;
            dr_k_d       = '0;
            if (ck_plast) dr_clear = 1'b1;
          end else begin
            dr_k_d = dr_k_q + WORDS_W'(1);
          end
        end
      end
    end

    if (dr_clear) begin
      pterm_d = 1'b0;
      pagg_d  = sf_albion_host_pkg::SF_HS_OK;
    end
  end

  assign busy_o = (fs_q != D_IDLE) || rq_out_valid || ck_out_valid || (t_busy_q != '0) ||
                  dma_r_valid_o || dq_valid_q || dwv_q;

  // ---------------------------------------------------------------------------
  // Registers
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      fs_q        <= D_IDLE;
      abort_cur_q <= 1'b0;
      abort_cnt_q <= '0;
      cancel_q    <= 1'b0;
      err_q       <= sf_albion_host_pkg::SF_HS_OK;
      null_q      <= 1'b0;
      wproto_q    <= 1'b0;
      dq_valid_q  <= 1'b0;
      dwv_q       <= 1'b0;
      t_busy_q    <= '0;
      t_done_q    <= '0;
      t_aband_q   <= '0;
      t_drained_q <= '0;
      t_to_q      <= '0;
      t_wr_q      <= '0;
      dr_k_q      <= '0;
      pterm_q     <= 1'b0;
      pagg_q      <= sf_albion_host_pkg::SF_HS_OK;
      unx_pend_q  <= 1'b0;
      unx_cnt_q   <= '0;
      wcons_q     <= '0;
      wtot_q      <= '0;
      wbeat_q     <= '0;
      wnb_q       <= '0;
    end else begin
      fs_q        <= fs_d;
      abort_cur_q <= abort_cur_d;
      abort_cnt_q <= abort_cnt_d;
      cancel_q    <= cancel_i;
      err_q       <= err_d;
      null_q      <= null_d;
      wproto_q    <= wproto_d;
      dq_valid_q  <= dq_valid_d;
      dwv_q       <= dwv_d;
      t_busy_q    <= t_busy_d;
      t_done_q    <= t_done_d;
      t_aband_q   <= t_aband_d;
      t_drained_q <= t_drained_d;
      t_to_q      <= t_to_d;
      t_wr_q      <= t_wr_d;
      dr_k_q      <= dr_k_d;
      pterm_q     <= pterm_d;
      pagg_q      <= pagg_d;
      unx_pend_q  <= unx_pend_d;
      unx_cnt_q   <= unx_cnt_d;
      wcons_q     <= wcons_d;
      wtot_q      <= wtot_d;
      wbeat_q     <= wbeat_d;
      wnb_q       <= wnb_d;
    end
  end

  // payload registers and per-tag values: not reset, always qualified by the state / valid bits above
  always_ff @(posedge clk_i) begin
    wr_q      <= wr_d;
    posted_q  <= posted_d;
    addr_q    <= addr_d;
    len_q     <= len_d;
    id_q      <= id_d;
    cur_q     <= cur_d;
    rem_q     <= rem_d;
    clen_q    <= clen_d;
    clast_q   <= clast_d;
    ctag_q    <= ctag_d;
    dq_kind_q <= dq_kind_d;
    dq_addr_q <= dq_addr_d;
    dq_len_q  <= dq_len_d;
    dq_tag_q  <= dq_tag_d;
    dwd_q     <= dwd_d;
    dwb_q     <= dwb_d;
    dwl_q     <= dwl_d;
    unx_tag_q <= unx_tag_d;
    for (int unsigned i = 0; i < NUM_TAGS; i++) begin
      t_err_q[i] <= t_err_d[i];
      t_got_q[i] <= t_got_d[i];
      if (alloc_fire && (tag_idx == TIDX_W'(i))) begin
        t_exp_q[i]  <= cnw32[WORDS_W-1:0];
        t_addr_q[i] <= cur_q;
      end
    end
  end
endmodule

`default_nettype wire
