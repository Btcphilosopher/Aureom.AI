// =============================================================================
//  sf_albion_fifo.sv  --  synchronous valid/ready FIFO
// -----------------------------------------------------------------------------
//  Single-clock, first-word-fall-through FIFO with independent valid/ready
//  handshakes on both sides.
//
//  Parameters
//    WIDTH  payload width in bits                       (>= 1)
//    DEPTH  number of entries; any integer >= 1, it need not be a power of two
//
//  Interface contract
//    push side  in_valid_i / in_ready_o / in_data_i
//    pop  side  out_valid_o / out_ready_i / out_data_o   (head shown directly)
//    flush_i    synchronous clear (cancellation, rule ALP-CAN-03)
//    count_o / full_o / empty_o   occupancy, for flow control and test
//
//  Behaviour
//    * A push is accepted in a cycle with in_valid_i && in_ready_o.
//      A pop happens in a cycle with out_valid_o && out_ready_i.
//    * in_ready_o  = !full && !flush_i.  It depends only on registered state
//      and flush_i: there is NO combinational path from out_ready_i or
//      in_valid_i to in_ready_o.  A full FIFO therefore does not accept a push
//      in the cycle in which it is popped.  Sustained one-transfer-per-cycle
//      throughput needs DEPTH >= 2; use sf_albion_skid / sf_albion_regslice
//      for single-entry stages.
//    * out_valid_o = !empty, a function of registered state only.
//    * Data is delivered in push order, with no loss and no duplication.
//    * out_data_o is stable while out_valid_o && !out_ready_i, except across
//      a flush (the only event allowed to withdraw a valid).
//    * flush_i takes effect at the next clock edge: the FIFO becomes empty.  It
//      empties this queue only: entries already handed on to a following stage
//      (for example a skid buffer behind the FIFO) are not recalled.
//      A pop in the flush cycle is still delivered; no push is accepted
//      (in_ready_o is low while flush_i is high).
//    * Storage is not reset (only pointers and the count are); out_data_o is
//      meaningful only while out_valid_o is high.
//
//  Reset: asynchronous assertion, active-low rst_ni, see RESET_CLOCK_CONTRACT.
// =============================================================================
`default_nettype none

module sf_albion_fifo #(
  parameter int unsigned WIDTH = 8,
  parameter int unsigned DEPTH = 4
) (
  input  wire logic                          clk_i,
  input  wire logic                          rst_ni,
  input  wire logic                          flush_i,
  // push side
  input  wire logic                          in_valid_i,
  output logic                               in_ready_o,
  input  wire logic [WIDTH-1:0]              in_data_i,
  // pop side
  output logic                               out_valid_o,
  input  wire logic                          out_ready_i,
  output logic [WIDTH-1:0]                   out_data_o,
  // occupancy
  output logic [$clog2(DEPTH+1)-1:0]         count_o,
  output logic                               full_o,
  output logic                               empty_o
);
  localparam int unsigned PTR_W = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  localparam int unsigned CNT_W = $clog2(DEPTH + 1);

  if (WIDTH < 1 || DEPTH < 1 || DEPTH > 1048576) begin : gen_param_check
    $error("sf_albion_fifo: WIDTH must be >= 1 and DEPTH must be in 1..1048576");
  end

  logic [WIDTH-1:0] mem_q [DEPTH];
  logic [PTR_W-1:0] wr_ptr_q, wr_ptr_d;
  logic [PTR_W-1:0] rd_ptr_q, rd_ptr_d;
  logic [CNT_W-1:0] count_q,  count_d;
  logic             push;
  logic             pop;

  function automatic logic [PTR_W-1:0] ptr_inc(input logic [PTR_W-1:0] ptr);
    if (ptr == PTR_W'(DEPTH - 1)) ptr_inc = '0;
    else                          ptr_inc = ptr + 1'b1;
  endfunction

  assign full_o      = (count_q == CNT_W'(DEPTH));
  assign empty_o     = (count_q == '0);
  assign count_o     = count_q;
  assign in_ready_o  = !full_o && !flush_i;
  assign out_valid_o = !empty_o;
  assign out_data_o  = mem_q[rd_ptr_q];

  assign push = in_valid_i && in_ready_o;
  assign pop  = out_valid_o && out_ready_i;

  always_comb begin
    wr_ptr_d = wr_ptr_q;
    rd_ptr_d = rd_ptr_q;
    count_d  = count_q;
    if (push) wr_ptr_d = ptr_inc(wr_ptr_q);
    if (pop)  rd_ptr_d = ptr_inc(rd_ptr_q);
    if (push && !pop)      count_d = count_q + 1'b1;
    else if (!push && pop) count_d = count_q - 1'b1;
    if (flush_i) begin
      wr_ptr_d = '0;
      rd_ptr_d = '0;
      count_d  = '0;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      wr_ptr_q <= '0;
      rd_ptr_q <= '0;
      count_q  <= '0;
    end else begin
      wr_ptr_q <= wr_ptr_d;
      rd_ptr_q <= rd_ptr_d;
      count_q  <= count_d;
    end
  end

  always_ff @(posedge clk_i) begin
    if (push) mem_q[wr_ptr_q] <= in_data_i;
  end
endmodule

`default_nettype wire
