// =============================================================================
//  sf_albion_skid.sv  --  two-entry skid buffer (fully registered both ways)
// -----------------------------------------------------------------------------
//  A full-throughput pipeline stage that cuts BOTH the forward (valid/data)
//  and the backward (ready) paths.  Storage: one output register plus one
//  spill register.
//
//  Parameter
//    WIDTH  payload width in bits (>= 1)
//
//  Behaviour
//    * in_ready_o = !spill_valid.  Registered state only: no combinational
//      path from out_ready_i, in_valid_i or in_data_i to in_ready_o.
//    * out_valid_o / out_data_o come straight from the output register.
//    * One transfer per cycle in steady state (input and output both moving).
//    * When the output stalls, the one extra item the upstream already
//      committed to is caught in the spill register; nothing is lost or
//      duplicated; order is preserved.
//    * Output data and valid are stable while out_valid_o && !out_ready_i.
//
//  There is no flush: a skid stage is a short pipeline element that drains on
//  its own.  Cancellation is handled at the transaction level (tag tracker)
//  and by flushing queues that are internal to a component (sf_albion_fifo).
// =============================================================================
`default_nettype none

module sf_albion_skid #(
  parameter int unsigned WIDTH = 8
) (
  input  wire logic             clk_i,
  input  wire logic             rst_ni,
  input  wire logic             in_valid_i,
  output logic                  in_ready_o,
  input  wire logic [WIDTH-1:0] in_data_i,
  output logic                  out_valid_o,
  input  wire logic             out_ready_i,
  output logic [WIDTH-1:0]      out_data_o
);
  if (WIDTH < 1) begin : gen_param_check
    $error("sf_albion_skid: WIDTH must be >= 1");
  end

  logic [WIDTH-1:0] main_data_q,  main_data_d;
  logic             main_valid_q, main_valid_d;
  logic [WIDTH-1:0] spill_data_q, spill_data_d;
  logic             spill_valid_q, spill_valid_d;

  assign in_ready_o  = !spill_valid_q;
  assign out_valid_o = main_valid_q;
  assign out_data_o  = main_data_q;

  always_comb begin
    main_data_d   = main_data_q;
    main_valid_d  = main_valid_q;
    spill_data_d  = spill_data_q;
    spill_valid_d = spill_valid_q;
    if (spill_valid_q) begin
      // The spill register is only occupied while the output register is full.
      if (out_ready_i) begin
        main_data_d   = spill_data_q;
        main_valid_d  = 1'b1;
        spill_valid_d = 1'b0;
      end
    end else if (!main_valid_q || out_ready_i) begin
      // Output register is empty or being emptied: new data goes straight in.
      main_valid_d = in_valid_i;
      if (in_valid_i) main_data_d = in_data_i;
    end else if (in_valid_i) begin
      // Output stalled but the upstream was told "ready": catch the item.
      spill_data_d  = in_data_i;
      spill_valid_d = 1'b1;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      main_valid_q  <= 1'b0;
      spill_valid_q <= 1'b0;
    end else begin
      main_valid_q  <= main_valid_d;
      spill_valid_q <= spill_valid_d;
    end
  end

  always_ff @(posedge clk_i) begin
    main_data_q  <= main_data_d;
    spill_data_q <= spill_data_d;
  end
endmodule

`default_nettype wire
