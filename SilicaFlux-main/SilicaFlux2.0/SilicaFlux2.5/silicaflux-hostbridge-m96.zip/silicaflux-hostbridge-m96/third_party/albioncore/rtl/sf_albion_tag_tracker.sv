// =============================================================================
//  sf_albion_tag_tracker.sv  --  initiator-side transaction tag tracker
// -----------------------------------------------------------------------------
//  Allocates transaction tags, enforces the outstanding-request limit, keeps a
//  per-tag context word, supports cancellation by abandoning a tag, and
//  (optionally) checks that responses return in request order.
//  Implements the initiator obligations ALP-TAG-01, ALP-OUT-01 and the
//  abandon form of cancellation, ALP-CAN-02.
//
//  Parameters
//    NUM_TAGS     number of tags = maximum outstanding transactions.
//                 1 .. 256.  Tag values are 0 .. NUM_TAGS-1.
//    CTX_W        width of the per-tag context word (>= 1), returned when the
//                 tag is freed (e.g. original request id, destination index)
//    CHECK_ORDER  1: flag any response that is not for the oldest outstanding
//                 transaction (ALP-ORD-01) -- costs a NUM_TAGS-deep FIFO
//
//  Allocation   (alloc_valid_i / alloc_ready_o, handshake)
//    alloc_ready_o is high while a tag is free and no fatal error is latched.
//    alloc_tag_o shows the lowest free tag NOW, which is the tag assigned when
//    alloc_valid_i is high in this cycle.  It changes in any cycle in which a tag
//    is freed, so the caller must take the tag when it CREATES the request (assert
//    alloc_valid_i when the request is loaded into the register that drives the
//    link, and keep the tag in that register).  A request that is held on a link
//    under back-pressure must not re-read alloc_tag_o.  alloc_ctx_i is stored with
//    the tag.
//
//  Completion   (free_valid_i, free_tag_i; one response accepted per cycle)
//    Combinational flags, valid while free_valid_i is high:
//      free_ctx_o         the context stored when the tag was allocated
//      free_drop_o        the tag was abandoned: DISCARD this response
//      free_unexpected_o  the tag is not outstanding (spurious or duplicate
//                         response); latches the fatal error
//      free_order_err_o   response is for a tag other than the oldest
//                         outstanding (CHECK_ORDER); latches the fatal error
//    A tag freed in a cycle becomes allocatable in the NEXT cycle, so a tag
//    is never reused in the cycle its response is accepted.
//
//  Cancellation
//    abandon_valid_i / abandon_tag_i   mark one outstanding tag abandoned
//    abandon_all_i                     mark every tag outstanding at the start
//                                      of the cycle abandoned
//    An abandoned tag STAYS busy until its response arrives (the target will
//    still produce it, ALP-CAN-01); the response is then reported with
//    free_drop_o.  Abandoning in the cycle the response arrives is too late:
//    the response is delivered normally.
//
//  Fatal error: after free_unexpected_o or free_order_err_o the link has
//  violated the protocol.  sticky_err_o latches and alloc_ready_o stays low
//  until reset (ALP-RST-02).  full_o reports only that every tag is busy; it
//  does not include the fatal error (alloc_ready_o is the authoritative flag).
// =============================================================================
`default_nettype none

module sf_albion_tag_tracker #(
  parameter int unsigned NUM_TAGS    = 8,
  parameter int unsigned CTX_W       = 1,
  parameter bit          CHECK_ORDER = 1'b1
) (
  input  wire logic                                 clk_i,
  input  wire logic                                 rst_ni,
  // allocation
  input  wire logic                                 alloc_valid_i,
  output logic                                      alloc_ready_o,
  output logic [sf_albion_pkg::SF_TAG_W-1:0]        alloc_tag_o,
  input  wire logic [CTX_W-1:0]                     alloc_ctx_i,
  // completion
  input  wire logic                                 free_valid_i,
  input  wire logic [sf_albion_pkg::SF_TAG_W-1:0]   free_tag_i,
  output logic [CTX_W-1:0]                          free_ctx_o,
  output logic                                      free_drop_o,
  output logic                                      free_unexpected_o,
  output logic                                      free_order_err_o,
  // cancellation
  input  wire logic                                 abandon_valid_i,
  input  wire logic [sf_albion_pkg::SF_TAG_W-1:0]   abandon_tag_i,
  input  wire logic                                 abandon_all_i,
  // status
  output logic [$clog2(NUM_TAGS+1)-1:0]             outstanding_o,
  output logic                                      full_o,
  output logic                                      empty_o,
  output logic                                      sticky_err_o
);
  localparam int unsigned TAG_W = sf_albion_pkg::SF_TAG_W;
  localparam int unsigned CNT_W = $clog2(NUM_TAGS + 1);
  localparam int unsigned IDX_W = (NUM_TAGS > 1) ? $clog2(NUM_TAGS) : 1;

  if (NUM_TAGS < 1 || NUM_TAGS > sf_albion_pkg::SF_MAX_OUTSTANDING_LIMIT) begin : gen_param_check_tags
    $error("sf_albion_tag_tracker: NUM_TAGS must be in 1..256");
  end
  if (CTX_W < 1) begin : gen_param_check_ctx
    $error("sf_albion_tag_tracker: CTX_W must be >= 1");
  end

  logic [NUM_TAGS-1:0] busy_q, busy_d;
  logic [NUM_TAGS-1:0] aband_q, aband_d;
  logic [CTX_W-1:0]    ctx_q [NUM_TAGS];
  logic [CNT_W-1:0]    count_q, count_d;
  logic                sticky_q, sticky_d;

  // ---------------------------------------------------------------- allocation
  logic                alloc_found;
  logic [TAG_W-1:0]    alloc_idx;
  logic                alloc_fire;

  always_comb begin
    alloc_found = 1'b0;
    alloc_idx   = '0;
    for (int unsigned i = 0; i < NUM_TAGS; i++) begin
      if (!alloc_found && !busy_q[i]) begin
        alloc_found = 1'b1;
        alloc_idx   = TAG_W'(i);
      end
    end
  end

  assign alloc_tag_o   = alloc_idx;
  assign alloc_ready_o = alloc_found && !sticky_q;
  assign alloc_fire    = alloc_valid_i && alloc_ready_o;
  assign full_o        = !alloc_found;
  assign empty_o       = (count_q == '0);
  assign outstanding_o = count_q;
  assign sticky_err_o  = sticky_q;

  // ---------------------------------------------------------------- order queue
  logic [TAG_W-1:0] head_tag;
  logic             head_valid;
  logic             free_ok;        // free event accepted and tag valid

  if (CHECK_ORDER) begin : gen_order
    logic ord_in_ready;
    logic ord_pop;
    // count_o / full_o / empty_o are intentionally unused.
    /* verilator lint_off PINCONNECTEMPTY */
    sf_albion_fifo #(.WIDTH(TAG_W), .DEPTH(NUM_TAGS)) u_order (
      .clk_i, .rst_ni, .flush_i(1'b0),
      .in_valid_i (alloc_fire),
      .in_ready_o (ord_in_ready),
      .in_data_i  (alloc_idx),
      .out_valid_o(head_valid),
      .out_ready_i(ord_pop),
      .out_data_o (head_tag),
      .count_o    (),
      .full_o     (),
      .empty_o    ()
    );
    /* verilator lint_on PINCONNECTEMPTY */
    assign ord_pop = free_ok;
    // The order queue holds exactly the busy tags, so it can never overflow
    // while at most NUM_TAGS tags exist; ord_in_ready is therefore unused.
    logic unused_ord;
    assign unused_ord = ord_in_ready;
  end else begin : gen_no_order
    assign head_tag   = '0;
    assign head_valid = 1'b0;
  end

  // ---------------------------------------------------------------- completion
  // Look up the tag being freed.  A tag value >= NUM_TAGS matches no entry and
  // is therefore "not busy" (an unexpected response).
  logic             tag_busy;
  logic [CTX_W-1:0] ctx_rd;
  logic             aband_rd;
  always_comb begin
    tag_busy = 1'b0;
    ctx_rd   = '0;
    aband_rd = 1'b0;
    for (int unsigned i = 0; i < NUM_TAGS; i++) begin
      if (free_tag_i == TAG_W'(i)) begin
        tag_busy = busy_q[i];
        ctx_rd   = ctx_q[i];
        aband_rd = aband_q[i];
      end
    end
  end

  assign free_unexpected_o = free_valid_i && !tag_busy;
  assign free_order_err_o  = free_valid_i && tag_busy && CHECK_ORDER &&
                             (!head_valid || (free_tag_i != head_tag));
  assign free_ok           = free_valid_i && tag_busy && !free_order_err_o;
  assign free_drop_o       = free_ok && aband_rd;
  assign free_ctx_o        = ctx_rd;

  // ---------------------------------------------------------------- next state
  always_comb begin
    busy_d   = busy_q;
    aband_d  = aband_q;
    count_d  = count_q;
    sticky_d = sticky_q;

    if (abandon_all_i) aband_d = aband_q | busy_q;
    if (abandon_valid_i) begin
      for (int unsigned i = 0; i < NUM_TAGS; i++) begin
        if (abandon_tag_i == TAG_W'(i) && busy_q[i]) aband_d[i] = 1'b1;
      end
    end
    if (free_ok) begin
      for (int unsigned i = 0; i < NUM_TAGS; i++) begin
        if (free_tag_i == TAG_W'(i)) begin
          busy_d[i]  = 1'b0;
          aband_d[i] = 1'b0;
        end
      end
    end
    if (alloc_fire) begin
      for (int unsigned i = 0; i < NUM_TAGS; i++) begin
        if (alloc_idx == TAG_W'(i)) begin
          busy_d[i]  = 1'b1;
          aband_d[i] = 1'b0;
        end
      end
    end

    if (alloc_fire && !free_ok)      count_d = count_q + 1'b1;
    else if (!alloc_fire && free_ok) count_d = count_q - 1'b1;

    if (free_unexpected_o || free_order_err_o) sticky_d = 1'b1;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      busy_q   <= '0;
      aband_q  <= '0;
      count_q  <= '0;
      sticky_q <= 1'b0;
    end else begin
      busy_q   <= busy_d;
      aband_q  <= aband_d;
      count_q  <= count_d;
      sticky_q <= sticky_d;
    end
  end

  // alloc_idx < NUM_TAGS whenever alloc_fire is high (a free tag was found).
  always_ff @(posedge clk_i) begin
    if (alloc_fire) ctx_q[alloc_idx[IDX_W-1:0]] <= alloc_ctx_i;
  end
endmodule

`default_nettype wire
