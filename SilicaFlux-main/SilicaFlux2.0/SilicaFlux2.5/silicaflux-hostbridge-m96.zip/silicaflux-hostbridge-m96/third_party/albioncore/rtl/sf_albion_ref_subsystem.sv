// =============================================================================
//  sf_albion_ref_subsystem.sv  --  reference ALP target subsystem
// -----------------------------------------------------------------------------
//  One initiator-facing ALP link in; a one-region memory map behind it.
//
//      req_i --> input skid --> decode --+--> sf_albion_ref_mem   (the region)
//                                        |
//                                        +--> sf_albion_err_resp  (everything else)
//      rsp_o <-- output skid <-- in-order response merge <--+
//
//  Decode:
//    1. address outside [REGION_BASE, +REGION_BYTES) -> err_resp, SF_ST_DECODE_ERR
//    2. region access check fails                    -> err_resp, ACCESS_DENIED / BAD_ATTR
//    3. otherwise                                    -> ref_mem at offset (addr - REGION_BASE)
//  Legality (ALP-LEG-01) is not repeated here: BOTH targets check the request they
//  receive and give the legality status precedence over every other status (ref_mem
//  and an sf_albion_err_resp with CHECK_LEGALITY = 1), so an illegal request is
//  answered with its legality status wherever the decode sends it and never changes
//  memory.  The decode only chooses the target.
//
//  Ordering (ALP-ORD-01): the two targets have different latencies; an order
//  queue records which target each accepted request went to, and the merge
//  releases responses strictly in that order.  MAX_OUT bounds the requests in
//  flight in the subsystem (ALP-OUT-01).
//
//  Parameters
//    MAX_OUT       order-queue depth, 1..256.  Requests in flight in the subsystem are
//                  bounded by MAX_OUT + 4 (input skid 2 + order queue + output skid 2)
//    REGION_BASE   base address of the region (aligned to REGION_BYTES)
//    REGION_BYTES  region size, a power of two >= 16
//    REGION_ATTR   sf_region_attr_t word of the region
//    MEM_WORDS     16-byte words actually backed by memory (<= REGION_BYTES/16)
//    MEM_RSP_DEPTH / MEM_EXTRA_LAT / ERR_RSP_DEPTH   buffering and latency of the targets
// =============================================================================
`default_nettype none

module sf_albion_ref_subsystem #(
  parameter int unsigned MAX_OUT       = 8,
  parameter logic [63:0] REGION_BASE   = 64'h0000_0001_0000_0000,
  parameter int unsigned REGION_BYTES  = 4096,
  parameter logic [7:0]  REGION_ATTR   = 8'b00_0_0_0_0_11,   // read + write, normal memory
  parameter int unsigned MEM_WORDS     = 64,
  parameter int unsigned MEM_RSP_DEPTH = 2,
  parameter int unsigned MEM_EXTRA_LAT = 2,
  parameter int unsigned ERR_RSP_DEPTH = 2
) (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,
  input  wire logic              req_valid_i,
  output logic                   req_ready_o,
  input  sf_albion_pkg::sf_req_t req_i,
  output logic                   rsp_valid_o,
  input  wire logic              rsp_ready_i,
  output sf_albion_pkg::sf_rsp_t rsp_o
);
  localparam int unsigned REQ_W = sf_albion_pkg::SF_REQ_W;
  localparam int unsigned RSP_W = sf_albion_pkg::SF_RSP_W;

  if (REGION_BYTES < 16 || (REGION_BYTES & (REGION_BYTES - 1)) != 0) begin : gen_param_check_size
    $error("sf_albion_ref_subsystem: REGION_BYTES must be a power of two >= 16");
  end
  if ((REGION_BASE & (64'(REGION_BYTES) - 64'd1)) != 64'd0) begin : gen_param_check_align
    $error("sf_albion_ref_subsystem: REGION_BASE must be aligned to REGION_BYTES");
  end
  if (MAX_OUT < 1 || MAX_OUT > 256) begin : gen_param_check_out
    $error("sf_albion_ref_subsystem: MAX_OUT must be in 1..256");
  end
  if (MEM_WORDS < 1 || MEM_WORDS * 16 > REGION_BYTES) begin : gen_param_check_mem
    $error("sf_albion_ref_subsystem: MEM_WORDS must be in 1..REGION_BYTES/16");
  end

  // ---------------------------------------------------------------- input stage
  logic              dec_valid;
  logic              dec_ready;
  logic [REQ_W-1:0]  dec_bits;
  sf_albion_pkg::sf_req_t dec_req;

  sf_albion_skid #(.WIDTH(REQ_W)) u_in_skid (
    .clk_i, .rst_ni,
    .in_valid_i (req_valid_i), .in_ready_o (req_ready_o), .in_data_i (req_i),
    .out_valid_o(dec_valid),   .out_ready_i(dec_ready),   .out_data_o(dec_bits)
  );
  assign dec_req = dec_bits;

  // ---------------------------------------------------------------- decode
  logic                       to_mem;
  sf_albion_pkg::sf_status_t  err_status;
  sf_albion_pkg::sf_status_t  acc_status;
  logic                       in_region;
  sf_albion_pkg::sf_req_t     mem_req;

  always_comb begin
    acc_status = sf_albion_pkg::sf_access_check_bits(REGION_ATTR, dec_req);
    // unsigned 64-bit arithmetic: an address below REGION_BASE wraps to a huge offset
    in_region  = ((dec_req.addr - REGION_BASE) < 64'(REGION_BYTES));
    err_status = sf_albion_pkg::SF_ST_OKAY;
    if (!in_region)                                   err_status = sf_albion_pkg::SF_ST_DECODE_ERR;
    else if (acc_status != sf_albion_pkg::SF_ST_OKAY) err_status = acc_status;
    to_mem = (err_status == sf_albion_pkg::SF_ST_OKAY);
    mem_req      = dec_req;
    mem_req.addr = dec_req.addr - REGION_BASE;
  end

  // ---------------------------------------------------------------- targets
  logic              mem_req_ready, err_req_ready;
  logic              mem_rsp_valid, err_rsp_valid;
  logic              mem_rsp_ready, err_rsp_ready;
  sf_albion_pkg::sf_rsp_t mem_rsp, err_rsp;
  logic              ord_in_ready;
  logic              fire;

  assign dec_ready = dec_valid && ord_in_ready && (to_mem ? mem_req_ready : err_req_ready);
  assign fire      = dec_valid && dec_ready;

  sf_albion_ref_mem #(
    .WORDS(MEM_WORDS), .RSP_DEPTH(MEM_RSP_DEPTH), .EXTRA_LAT(MEM_EXTRA_LAT), .INIT_ZERO(1'b1)
  ) u_mem (
    .clk_i, .rst_ni,
    .req_valid_i(fire && to_mem), .req_ready_o(mem_req_ready), .req_i(mem_req),
    .rsp_valid_o(mem_rsp_valid),  .rsp_ready_i(mem_rsp_ready), .rsp_o(mem_rsp)
  );

  sf_albion_err_resp #(.DEPTH(ERR_RSP_DEPTH), .CHECK_LEGALITY(1'b1)) u_err (
    .clk_i, .rst_ni,
    .req_valid_i(fire && !to_mem), .req_ready_o(err_req_ready), .req_i(dec_req),
    .status_i(err_status),
    .rsp_valid_o(err_rsp_valid),   .rsp_ready_i(err_rsp_ready), .rsp_o(err_rsp)
  );

  // ---------------------------------------------------------------- order queue + merge
  logic ord_head_mem;
  logic ord_valid;
  logic ord_pop;
  // count_o / full_o / empty_o are intentionally unused.
  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(1), .DEPTH(MAX_OUT)) u_order (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (fire),        .in_ready_o (ord_in_ready), .in_data_i (to_mem),
    .out_valid_o(ord_valid),   .out_ready_i(ord_pop),      .out_data_o(ord_head_mem),
    .count_o(), .full_o(), .empty_o()
  );
  /* verilator lint_on PINCONNECTEMPTY */

  logic              merge_valid;
  logic              merge_ready;
  logic [RSP_W-1:0]  merge_bits;
  always_comb begin
    merge_valid = ord_valid && (ord_head_mem ? mem_rsp_valid : err_rsp_valid);
    merge_bits  = ord_head_mem ? mem_rsp : err_rsp;
  end
  assign mem_rsp_ready = ord_valid &&  ord_head_mem && merge_ready;
  assign err_rsp_ready = ord_valid && !ord_head_mem && merge_ready;
  assign ord_pop       = merge_valid && merge_ready;

  sf_albion_skid #(.WIDTH(RSP_W)) u_out_skid (
    .clk_i, .rst_ni,
    .in_valid_i (merge_valid), .in_ready_o (merge_ready), .in_data_i (merge_bits),
    .out_valid_o(rsp_valid_o), .out_ready_i(rsp_ready_i), .out_data_o(rsp_o)
  );
endmodule

`default_nettype wire
