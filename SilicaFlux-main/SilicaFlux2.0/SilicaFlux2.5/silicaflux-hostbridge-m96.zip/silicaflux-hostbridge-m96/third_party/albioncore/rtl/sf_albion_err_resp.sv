// =============================================================================
//  sf_albion_err_resp.sv  --  error response generator (terminating target)
// -----------------------------------------------------------------------------
//  Accepts requests and completes every one of them with an ERROR response.
//  Use it as
//    * the default target of an address decoder (unmapped address -> DECODE_ERR),
//    * the sink for requests rejected by a protection check (ACCESS_DENIED),
//    * the local completion for an abandoned / cancelled request (CANCELLED; an
//      illegal request still gets its legality status when CHECK_LEGALITY = 1,
//      because legality has precedence -- use CHECK_LEGALITY = 0 to force status_i).
//  It never touches memory and never returns data.
//
//  Status selection, per request (ALP-LEG-01 precedence is preserved):
//    1. if CHECK_LEGALITY and the request is itself illegal
//       (sf_albion_pkg::sf_req_check_bits != OKAY) -> that legality status
//    2. else status_i, supplied by the caller together with the request
//    3. else, if status_i is OKAY (a caller error)        -> SF_ST_DECODE_ERR
//    4. else, if status_i is an undefined code (> 11)     -> SF_ST_TARGET_ERR
//       The generator can therefore never return success or an undefined code.
//
//  Response format (always well-formed, ALP-RSP-05):
//    tag        echo of the request tag
//    status     as selected above
//    meta       last = 1, is_write = (op == WRITE), poisoned = (status == ECC_UNCORR)
//    data       all-zero
//
//  Timing / buffering
//    A DEPTH-entry in-order response FIFO decouples the two channels:
//    req_ready_o is high while the FIFO has room.  Responses appear at least
//    one cycle after their request is accepted (ALP-RSP-03) and are held
//    until accepted.  DEPTH >= 2 sustains one request per cycle.
//    The request-to-response path is combinational only up to the FIFO
//    storage; there is no combinational valid -> ready path.
// =============================================================================
`default_nettype none

module sf_albion_err_resp #(
  parameter int unsigned DEPTH          = 2,
  parameter bit          CHECK_LEGALITY = 1'b1
) (
  input  wire logic                           clk_i,
  input  wire logic                           rst_ni,
  // request channel
  input  wire logic                           req_valid_i,
  output logic                                req_ready_o,
  input  sf_albion_pkg::sf_req_t              req_i,
  input  wire logic [sf_albion_pkg::SF_STATUS_W-1:0] status_i,
  // response channel
  output logic                                rsp_valid_o,
  input  wire logic                           rsp_ready_i,
  output sf_albion_pkg::sf_rsp_t              rsp_o
);
  if (DEPTH < 1) begin : gen_param_check
    $error("sf_albion_err_resp: DEPTH must be >= 1");
  end

  sf_albion_pkg::sf_status_t legal_status;
  sf_albion_pkg::sf_status_t status;
  sf_albion_pkg::sf_rsp_t    rsp_d;
  logic [sf_albion_pkg::SF_RSP_W-1:0] rsp_bits_d;
  logic [sf_albion_pkg::SF_RSP_W-1:0] rsp_bits_q;

  always_comb begin
    legal_status = sf_albion_pkg::sf_req_check_bits(req_i);
    if (CHECK_LEGALITY && legal_status != sf_albion_pkg::SF_ST_OKAY)   status = legal_status;
    else if (status_i == sf_albion_pkg::SF_ST_OKAY)                    status = sf_albion_pkg::SF_ST_DECODE_ERR;
    else if (status_i > sf_albion_pkg::SF_ST_PROTOCOL_ERR)             status = sf_albion_pkg::SF_ST_TARGET_ERR;
    else                                                               status = status_i;

    rsp_d             = '0;
    rsp_d.tag         = req_i.tag;
    rsp_d.status      = status;
    rsp_d.meta.last   = 1'b1;
    rsp_d.meta.is_write = (req_i.op == sf_albion_pkg::SF_OP_WRITE);
    rsp_d.meta.poisoned = (status == sf_albion_pkg::SF_ST_ECC_UNCORR);
    rsp_bits_d        = rsp_d;
  end

  // count_o / full_o / empty_o are intentionally unused.
  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(sf_albion_pkg::SF_RSP_W), .DEPTH(DEPTH)) u_rsp_fifo (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (req_valid_i),
    .in_ready_o (req_ready_o),
    .in_data_i  (rsp_bits_d),
    .out_valid_o(rsp_valid_o),
    .out_ready_i(rsp_ready_i),
    .out_data_o (rsp_bits_q),
    .count_o    (),
    .full_o     (),
    .empty_o    ()
  );
  /* verilator lint_on PINCONNECTEMPTY */

  assign rsp_o = rsp_bits_q;
endmodule

`default_nettype wire
