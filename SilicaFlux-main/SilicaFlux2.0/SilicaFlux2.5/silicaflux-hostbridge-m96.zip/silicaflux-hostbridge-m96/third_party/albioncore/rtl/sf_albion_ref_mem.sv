// =============================================================================
//  sf_albion_ref_mem.sv  --  reference memory target (ALP v1)
// -----------------------------------------------------------------------------
//  A small, synthesizable memory that serves READ and WRITE requests with byte
//  enables.  It is the reference TARGET used by the system tests and by the
//  profile-elaboration builds; it shows how a target meets the ALP contract.
//
//  Parameters
//    WORDS      number of 16-byte words (>= 1).  Offsets beyond WORDS*16 return
//               SF_ST_DECODE_ERR (device-level decode, distinct from the
//               fabric-level decode in sf_albion_ref_subsystem).
//    RSP_DEPTH  response FIFO depth (>= 1)
//    EXTRA_LAT  extra response pipeline stages (0..8), each a skid buffer; used
//               to give different targets different latencies
//    INIT_ZERO  1: after reset the memory is cleared word by word and
//               req_ready_o stays low until the clear finishes, so unwritten
//               locations read as zero.  0: contents are undefined until written.
//
//  Behaviour (each rule id refers to docs/albion/ARCHITECTURE_CONTRACT.md)
//    * Requests execute in acceptance order, one at a time (ALP-ORD-02): a
//      WRITE takes effect at acceptance; a READ samples memory at acceptance.
//    * Illegal requests (sf_req_check_bits) return their legality status and
//      do not touch memory (ALP-LEG-01).  An offset outside the memory returns
//      SF_ST_DECODE_ERR.
//    * READ returns the enabled byte lanes, other lanes zero; any non-OKAY
//      response and every write response carries all-zero data (ALP-RSP-05).
//    * The response is visible at least one cycle after acceptance (ALP-RSP-03),
//      is held until accepted (ALP-RSP-02) and returns in order (ALP-ORD-01).
//    * Write completion means the data is visible to any later read (ALP-ORD-03).
// =============================================================================
`default_nettype none

module sf_albion_ref_mem #(
  parameter int unsigned WORDS     = 64,
  parameter int unsigned RSP_DEPTH = 2,
  parameter int unsigned EXTRA_LAT = 0,
  parameter bit          INIT_ZERO = 1'b1
) (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,
  input  wire logic              req_valid_i,
  output logic                   req_ready_o,
  input  sf_albion_pkg::sf_req_t req_i,
  output logic                   rsp_valid_o,
  input  wire logic              rsp_ready_i,
  output sf_albion_pkg::sf_rsp_t rsp_o
);
  localparam int unsigned IDX_W = (WORDS > 1) ? $clog2(WORDS) : 1;
  localparam int unsigned DATA_W = sf_albion_pkg::SF_DATA_W;
  localparam int unsigned RSP_W  = sf_albion_pkg::SF_RSP_W;

  if (WORDS < 1) begin : gen_param_check_words
    $error("sf_albion_ref_mem: WORDS must be >= 1");
  end
  if (RSP_DEPTH < 1) begin : gen_param_check_depth
    $error("sf_albion_ref_mem: RSP_DEPTH must be >= 1");
  end
  if (EXTRA_LAT > 8) begin : gen_param_check_lat
    $error("sf_albion_ref_mem: EXTRA_LAT must be <= 8");
  end

  logic [DATA_W-1:0] mem_q [WORDS];

  // ---------------------------------------------------------------- memory clear
  logic              init_done;
  logic [IDX_W-1:0]  init_idx_q;
  logic              init_done_q;

  if (INIT_ZERO) begin : gen_init
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        init_idx_q  <= '0;
        init_done_q <= 1'b0;
      end else if (!init_done_q) begin
        if (init_idx_q == IDX_W'(WORDS - 1)) init_done_q <= 1'b1;
        else                                 init_idx_q  <= init_idx_q + 1'b1;
      end
    end
    assign init_done = init_done_q;
  end else begin : gen_no_init
    assign init_idx_q  = '0;
    assign init_done_q = 1'b1;
    assign init_done   = 1'b1;
  end

  // ---------------------------------------------------------------- request execution
  logic                                  fifo_in_ready;
  logic                                  accept;
  sf_albion_pkg::sf_status_t             status;
  logic                                  in_range;
  logic [IDX_W-1:0]                      idx;
  logic [DATA_W-1:0]                     rd_word, byte_mask, wr_word;
  logic [DATA_W-1:0]                     rd_data;
  sf_albion_pkg::sf_rsp_t                rsp_d;
  logic [RSP_W-1:0]                      rsp_bits_d;

  assign req_ready_o = fifo_in_ready && init_done;
  assign accept      = req_valid_i && req_ready_o;

  always_comb begin
    in_range = (req_i.addr[sf_albion_pkg::SF_ADDR_W-1:sf_albion_pkg::SF_LANE_W] <
                (sf_albion_pkg::SF_ADDR_W - sf_albion_pkg::SF_LANE_W)'(WORDS));
    idx      = req_i.addr[sf_albion_pkg::SF_LANE_W +: IDX_W];
    status   = sf_albion_pkg::sf_req_check_bits(req_i);
    if (status == sf_albion_pkg::SF_ST_OKAY && !in_range) status = sf_albion_pkg::SF_ST_DECODE_ERR;

    for (int unsigned b = 0; b < sf_albion_pkg::SF_BE_W; b++) byte_mask[b*8 +: 8] = {8{req_i.be[b]}};
    rd_word = mem_q[idx];
    wr_word = (rd_word & ~byte_mask) | (req_i.data & byte_mask);
    rd_data = (status == sf_albion_pkg::SF_ST_OKAY && req_i.op == sf_albion_pkg::SF_OP_READ)
              ? (rd_word & byte_mask) : '0;

    rsp_d               = '0;
    rsp_d.tag           = req_i.tag;
    rsp_d.status        = status;
    rsp_d.meta.last     = 1'b1;
    rsp_d.meta.is_write = (req_i.op == sf_albion_pkg::SF_OP_WRITE);
    rsp_d.data          = rd_data;
    rsp_bits_d          = rsp_d;
  end

  // Memory write: clear sequence, or an accepted legal in-range WRITE.
  always_ff @(posedge clk_i) begin
    if (INIT_ZERO && !init_done_q) begin
      mem_q[init_idx_q] <= '0;
    end else if (accept && status == sf_albion_pkg::SF_ST_OKAY && req_i.op == sf_albion_pkg::SF_OP_WRITE) begin
      mem_q[idx] <= wr_word;
    end
  end

  // ---------------------------------------------------------------- response path
  logic [RSP_W-1:0] fifo_out;
  logic             fifo_out_valid;
  logic             fifo_out_ready;

  // count_o / full_o / empty_o are intentionally unused.
  /* verilator lint_off PINCONNECTEMPTY */
  sf_albion_fifo #(.WIDTH(RSP_W), .DEPTH(RSP_DEPTH)) u_rsp_fifo (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i (req_valid_i && init_done),
    .in_ready_o (fifo_in_ready),
    .in_data_i  (rsp_bits_d),
    .out_valid_o(fifo_out_valid),
    .out_ready_i(fifo_out_ready),
    .out_data_o (fifo_out),
    .count_o    (),
    .full_o     (),
    .empty_o    ()
  );
  /* verilator lint_on PINCONNECTEMPTY */

  // Chain of EXTRA_LAT skid stages between the FIFO and the output.
  logic [RSP_W-1:0] chain_data  [EXTRA_LAT+1];
  logic             chain_valid [EXTRA_LAT+1];
  logic             chain_ready [EXTRA_LAT+1];
  assign chain_data[0]  = fifo_out;
  assign chain_valid[0] = fifo_out_valid;
  assign fifo_out_ready = chain_ready[0];
  for (genvar i = 0; i < EXTRA_LAT; i++) begin : gen_lat
    sf_albion_skid #(.WIDTH(RSP_W)) u_stage (
      .clk_i, .rst_ni,
      .in_valid_i (chain_valid[i]),   .in_ready_o (chain_ready[i]),   .in_data_i (chain_data[i]),
      .out_valid_o(chain_valid[i+1]), .out_ready_i(chain_ready[i+1]), .out_data_o(chain_data[i+1])
    );
  end
  assign rsp_valid_o            = chain_valid[EXTRA_LAT];
  assign chain_ready[EXTRA_LAT] = rsp_ready_i;
  assign rsp_o                  = chain_data[EXTRA_LAT];
endmodule

`default_nettype wire
