Unmodified copies of AlbionCore 0.1.0 files (ALP v1). See ../../docs/PROVENANCE.md for the source archive, checksums and
the role of each file. Do not edit these files in this package: update them from AlbionCore and refresh docs/third_party.sha256.
