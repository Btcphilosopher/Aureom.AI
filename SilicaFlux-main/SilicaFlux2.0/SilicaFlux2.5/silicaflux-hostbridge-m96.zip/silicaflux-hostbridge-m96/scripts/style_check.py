#!/usr/bin/env python3
"""Albion RTL style checker -- the coding rules of docs/albion/NAMING_RULES.md as executable checks.

Applies to the synthesizable sources (manifest groups core, cdc, ref, generated).
Lexical, not a full parser: it relies on the restricted style the rules themselves
impose, and is covered by fixtures (tests/albion/fixtures/style/) that make every
rule fire.

  style_check.py                 check all RTL
  style_check.py FILE...         check the given files (used by the fixtures)
  style_check.py --list          print the rules
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
import albion_lib as lib  # noqa: E402

RULES = {
    "S01": "file begins with a header comment block",
    "S02": "`default_nettype none before the first module/package and `default_nettype wire at the end",
    "S03": "module names are sf_albion_<lower_snake>; package names end in _pkg",
    "S04": "parameter, localparam and enum member names are UPPER_SNAKE_CASE",
    "S05": "signal, function, typedef and field names are lower_snake_case; typedefs end in _t or _e",
    "S06": "port suffixes: input _i or _ni, output _o or _no, inout _io",
    "S07": "always_ff uses non-blocking assignments only",
    "S08": "always_comb uses no non-blocking assignments",
    "S09": "only always_ff, always_comb and assign: no always @, always #, always_latch",
    "S10": "always_ff sensitivity is `posedge clk` or `posedge clk or negedge rst` (asynchronous low reset)",
    "S11": "no simulation constructs (initial, final, $display, $finish, $random, #delay, force, fork, assert, ...)",
    "S12": "$error only inside a generate block named gen_param_check*",
    "S13": "generate blocks are named gen_*; instances are named u_*",
    "S14": "no tabs, no trailing white space, lines <= 120 columns",
    "S15": "tool compatibility: no int'() cast, no return, no assignment pattern, no import",
    "S16": "no preprocessor use other than `default_nettype",
    "S17": "explicit types: parameters are typed; ports have an explicit logic or package data type",
}

SNAKE = re.compile(r"^[a-z][a-z0-9_]*$")
UPPER = re.compile(r"^[A-Z][A-Z0-9_]*$")
SIM_WORDS = re.compile(
    r"\b(initial|final|force|release|fork|join|join_any|join_none|wait|program|endprogram|class|endclass|"
    r"assert|assume|cover|expect|property|sequence|covergroup)\b|"
    r"\$(display|displayb|displayh|write|strobe|monitor|finish|stop|fatal|warning|info|random|urandom|"
    r"urandom_range|time|stime|realtime|fopen|fclose|fscanf|fdisplay|readmemh|readmemb|dumpfile|dumpvars|"
    r"test\$plusargs|value\$plusargs|sformatf|swrite)\b")
DELAY = re.compile(r"(?<![\w#])#\s*\d")          # '#(' is a parameter list, not a delay


def line_of(text, pos):
    return text.count("\n", 0, pos) + 1


def match_end(text, start, open_kw, close_kw):
    """Index just past the matching close keyword for an open keyword at `start`."""
    depth, pos = 0, start
    pat = re.compile(r"\b(%s|%s)\b" % (open_kw, close_kw))
    for m in pat.finditer(text, start):
        depth += 1 if m.group(1) == open_kw else -1
        if depth == 0:
            return m.end()
    return len(text)


def skip_parens(text, pos):
    """pos is at '(' -> index after the matching ')'."""
    depth = 0
    for i in range(pos, len(text)):
        if text[i] == "(":
            depth += 1
        elif text[i] == ")":
            depth -= 1
            if depth == 0:
                return i + 1
    return len(text)


def parse_stmt(text, pos):
    """Return the end index of the statement starting at pos (restricted grammar)."""
    m = re.compile(r"\s*").match(text, pos)
    pos = m.end()
    word = re.compile(r"[A-Za-z_]\w*").match(text, pos)
    w = word.group(0) if word else ""
    if w == "begin":
        return match_end(text, pos, "begin", "end")
    if w == "if":
        i = text.index("(", pos)
        e = parse_stmt(text, skip_parens(text, i))
        nxt = re.compile(r"\s*else\b").match(text, e)
        if nxt:
            return parse_stmt(text, nxt.end())
        return e
    if w in ("case", "casez", "casex", "unique", "priority"):
        return match_end(text, pos, r"case|casez|casex", "endcase") if w.startswith("case") else \
            match_end(text, text.index("case", pos), r"case|casez|casex", "endcase")
    if w == "for":
        i = text.index("(", pos)
        return parse_stmt(text, skip_parens(text, i))
    j = text.find(";", pos)
    return len(text) if j < 0 else j + 1


def blocking_assigns(body):
    """Yield positions of blocking '=' at parenthesis depth 0 (for-headers sit inside parentheses)."""
    depth = 0
    for i, ch in enumerate(body):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "=" and depth == 0:
            prev = body[i - 1] if i else ""
            nxt = body[i + 1] if i + 1 < len(body) else ""
            if prev in "<>=!" or nxt == "=":
                continue
            yield i


def nonblocking_assigns(body):
    depth = 0
    for i in range(len(body) - 1):
        ch = body[i]
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "<" and body[i + 1] == "=" and depth == 0:
            if i and body[i - 1] in "<>":
                continue
            yield i


def split_top(s, sep=","):
    out, depth, cur = [], 0, []
    for ch in s:
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        if ch == sep and depth == 0:
            out.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    out.append("".join(cur))
    return out


def decl_names(decl):
    """Identifiers declared by a declaration fragment such as 'logic [3:0] a, b [2]'."""
    d = re.sub(r"\[[^\]]*\]", " ", decl)
    d = re.sub(r"=.*", "", d, flags=re.S) if "," not in d else d
    names = []
    for part in split_top(d):
        part = re.sub(r"=.*", "", part, flags=re.S)
        toks = re.findall(r"[A-Za-z_]\w*(?:::\w+)?", part)
        toks = [t for t in toks if t not in {"logic", "wire", "reg", "bit", "int", "unsigned", "signed", "input",
                                             "output", "inout", "genvar", "integer", "automatic", "var"}
                and "::" not in t]
        if toks:
            names.append(toks[-1])
    return names


def check_file(path, text_override=None):
    raw = text_override if text_override is not None else lib.read(path)
    text = lib.strip_comments(raw)
    out = []

    def add(rule, pos_or_line, msg, is_line=False):
        ln = pos_or_line if is_line else line_of(text, pos_or_line)
        out.append((ln, rule, msg))

    # ---- S01 / S02 / S14 on the raw file
    lines = raw.split("\n")
    first = next((l for l in lines if l.strip()), "")
    if not first.lstrip().startswith("//"):
        add("S01", 1, "the file must begin with a // header comment", True)
    code_lines = [(i + 1, l) for i, l in enumerate(lines) if l.strip()]
    pk = re.search(r"^\s*(module|package)\b", text, re.M)
    nn = [m for m in re.finditer(r"`default_nettype\s+(\w+)", text)]
    if not nn or nn[0].group(1) != "none" or (pk and nn[0].start() > pk.start()):
        add("S02", 1, "`default_nettype none must precede the first module/package", True)
    if not code_lines or code_lines[-1][1].strip() != "`default_nettype wire":
        add("S02", code_lines[-1][0] if code_lines else 1, "the last line must be `default_nettype wire", True)
    for i, l in enumerate(lines, 1):
        if "\t" in l:
            add("S14", i, "tab character", True)
        if l != l.rstrip():
            add("S14", i, "trailing white space", True)
        if len(l) > 120:
            add("S14", i, "line longer than 120 columns (%d)" % len(l), True)

    # ---- S03 module / package names
    for m in re.finditer(r"^\s*module\s+(\w+)", text, re.M):
        if not re.fullmatch(r"sf_albion_[a-z0-9_]+", m.group(1)):
            add("S03", m.start(), "module '%s' must be sf_albion_<lower_snake>" % m.group(1))
    for m in re.finditer(r"^\s*package\s+(\w+)", text, re.M):
        if not re.fullmatch(r"sf_albion_([a-z0-9_]+_)?pkg", m.group(1)):
            add("S03", m.start(), "package '%s' must be sf_albion_..._pkg" % m.group(1))

    # ---- S04 / S17 parameters
    for m in re.finditer(r"\b(parameter|localparam)\b([^=;]*?)=", text):
        head = m.group(2)
        names = re.findall(r"[A-Za-z_]\w*", re.sub(r"\[[^\]]*\]", " ", head))
        names = [n for n in names if n not in {"int", "unsigned", "signed", "bit", "logic", "string", "integer"}
                 and "::" not in n]
        if not names:
            continue
        nm = names[-1]
        if not UPPER.match(nm):
            add("S04", m.start(), "%s '%s' must be UPPER_SNAKE_CASE" % (m.group(1), nm))
        if m.group(1) == "parameter" and not re.match(r"\s*(int\s+unsigned|bit|logic|string)\b", head):
            add("S17", m.start(), "parameter '%s' needs an explicit type (int unsigned / bit / logic [..])" % nm)
    for m in re.finditer(r"typedef\s+enum\s+logic\s*\[[^\]]*\]\s*\{(.*?)\}", text, re.S):
        for member in split_top(m.group(1)):
            nm = member.split("=")[0].strip()
            if nm and not UPPER.match(nm):
                add("S04", m.start(), "enum member '%s' must be UPPER_SNAKE_CASE" % nm)

    # ---- S05 typedefs, struct fields, functions
    for m in re.finditer(r"\}\s*(\w+)\s*;", text):
        if not SNAKE.match(m.group(1)) or not m.group(1).endswith(("_t", "_e")):
            add("S05", m.start(), "type '%s' must be lower_snake and end in _t or _e" % m.group(1))
    for m in re.finditer(r"typedef\s+logic\s*\[[^\]]*\]\s*(\w+)\s*;", text):
        if not SNAKE.match(m.group(1)) or not m.group(1).endswith("_t"):
            add("S05", m.start(), "type '%s' must be lower_snake and end in _t" % m.group(1))
    for m in re.finditer(r"typedef\s+struct\s+packed\s*\{(.*?)\}", text, re.S):
        for f in m.group(1).split(";"):
            names = decl_names(f)
            for nm in names:
                if not SNAKE.match(nm):
                    add("S05", m.start(), "struct field '%s' must be lower_snake_case" % nm)
    for m in re.finditer(r"\bfunction\b[^;(]*?(\w+)\s*\(", text):
        if not SNAKE.match(m.group(1)):
            add("S05", m.start(), "function '%s' must be lower_snake_case" % m.group(1))

    # ---- module header ports (S05/S06/S17) and body declarations (S05)
    for mm in re.finditer(r"^\s*module\s+\w+", text, re.M):
        i = mm.end()
        j = text.find("(", i)
        if j < 0:
            continue
        if text[i:j].strip().startswith("#"):
            j = skip_parens(text, j)
            j = text.find("(", j)
        k = skip_parens(text, j)
        header = text[j + 1:k - 1]
        for port in split_top(header):
            p = port.strip()
            if not p:
                continue
            dm = re.match(r"(input|output|inout)\b(.*)", p, re.S)
            if not dm:
                continue
            direction, rest = dm.group(1), dm.group(2)
            if not re.match(r"\s*(wire\s+logic|logic|wire\s+sf_albion_pkg::\w+|sf_albion_pkg::\w+|var\s+logic)\b", rest):
                add("S17", mm.start() + j, "port '%s' needs an explicit logic / package data type" % p.split()[-1])
            nm = (decl_names(rest) or ["?"])[0]
            suffixes = {"input": ("_i", "_ni"), "output": ("_o", "_no"), "inout": ("_io",)}[direction]
            if not nm.endswith(suffixes):
                add("S06", line_of(text, j + text[j:].find(p)) if False else mm.start(),
                    "%s port '%s' must end in %s" % (direction, nm, " or ".join(suffixes)), False)
            if not SNAKE.match(nm):
                add("S05", mm.start(), "port '%s' must be lower_snake_case" % nm)
    body_decl = re.compile(r"^\s*(?:logic|wire|reg|bit|genvar|integer|sf_albion_pkg::\w+)\b([^;()]*(?:\([^;]*\))?[^;]*);", re.M)
    for m in body_decl.finditer(text):
        for nm in decl_names(m.group(0).rstrip(";")):
            if not SNAKE.match(nm):
                add("S05", m.start(), "signal '%s' must be lower_snake_case" % nm)

    # ---- S07-S10 always blocks
    for m in re.finditer(r"\balways\w*\b", text):
        kw = m.group(0)
        if kw == "always_ff":
            sm = re.compile(r"\s*@\s*\(([^)]*)\)").match(text, m.end())
            if not sm:
                add("S10", m.start(), "always_ff needs an @(posedge ...) sensitivity list")
                continue
            if not re.fullmatch(r"\s*posedge\s+\w+(\s+or\s+negedge\s+\w+)?\s*", sm.group(1)):
                add("S10", m.start(), "always_ff sensitivity '%s' must be 'posedge clk [or negedge rst]'" % sm.group(1).strip())
            end = parse_stmt(text, sm.end())
            for b in blocking_assigns(text[sm.end():end]):
                add("S07", sm.end() + b, "blocking assignment in always_ff (use <=)")
        elif kw == "always_comb":
            end = parse_stmt(text, m.end())
            for b in nonblocking_assigns(text[m.end():end]):
                add("S08", m.end() + b, "non-blocking assignment in always_comb (use =)")
        else:
            add("S09", m.start(), "'%s' is not allowed; use always_ff / always_comb / assign" % kw)

    # ---- S11 / S12 / S15 / S16
    for m in SIM_WORDS.finditer(text):
        add("S11", m.start(), "simulation construct '%s' in synthesizable RTL" % m.group(0))
    for m in DELAY.finditer(text):
        add("S11", m.start(), "delay '%s' in synthesizable RTL" % m.group(0).strip())
    ok_ranges = []
    for m in re.finditer(r"begin\s*:\s*gen_param_check\w*", text):
        ok_ranges.append((m.start(), match_end(text, m.start(), "begin", "end")))
    for m in re.finditer(r"\$(error|fatal|warning|info)\b", text):
        if m.group(1) != "error" or not any(a <= m.start() < b for a, b in ok_ranges):
            add("S12", m.start(), "$%s only allowed inside a gen_param_check generate block" % m.group(1))
    for rx, msg in ((r"\bint'\s*\(", "int'() cast (Yosys 0.33 rejects it; use widening arithmetic)"),
                    (r"\breturn\b", "'return' (Yosys 0.33: assign to the function name)"),
                    (r"'\{", "assignment pattern '{ (Yosys 0.33 rejects struct patterns in constants)"),
                    (r"^\s*import\b", "'import' (Yosys 0.33: use scoped sf_albion_pkg::NAME)")):
        for m in re.finditer(rx, text, re.M):
            add("S15", m.start(), msg)
    for m in re.finditer(r"`(\w+)", text):
        if m.group(1) != "default_nettype":
            add("S16", m.start(), "preprocessor directive `%s is not allowed" % m.group(1))

    # ---- S13 names of generate blocks and instances
    for m in re.finditer(r"\bbegin\s*:\s*(\w+)", text):
        if not m.group(1).startswith("gen_"):
            add("S13", m.start(), "block label '%s' must start with gen_" % m.group(1))
    for m in re.finditer(r"^\s*(sf_albion_\w+)\s*(?:#\s*\(.*?\)\s*)?(\w+)\s*\(", text, re.M | re.S):
        if not m.group(2).startswith("u_"):
            add("S13", m.start(2), "instance '%s' of %s must start with u_" % (m.group(2), m.group(1)))
    return sorted(set(out))


def rtl_files():
    man = lib.load_yaml(os.path.join(lib.ROOT, "tools", "albion", "config", "manifest.yaml"))
    return [os.path.join(lib.ROOT, f) for g in ("core", "cdc", "ref", "generated") for f in man[g]]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="*")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()
    if a.list:
        for k, v in RULES.items():
            print("%s  %s" % (k, v))
        return 0
    files = a.files or rtl_files()
    total = 0
    for f in files:
        for ln, rule, msg in check_file(f):
            total += 1
            print("%s:%d: [%s] %s" % (lib.rel(f), ln, rule, msg))
    if total:
        print("style_check: %d violation(s)" % total)
        return 1
    if not a.quiet:
        print("style_check: OK -- %d files, %d rules" % (len(files), len(RULES)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
