#!/usr/bin/env python3
"""Deterministic zip of the project (sorted entries, fixed timestamps, no build/ or caches).

  make_dist.py [--out PATH]      default: ../silicaflux-hostbridge-m96.zip next to the project directory
Nothing is committed or pushed anywhere: this only writes the archive.
"""
import argparse
import os
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = os.path.basename(ROOT)
SKIP_DIRS = {"build", "__pycache__", ".git"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(ROOT), NAME + ".zip"))
    a = ap.parse_args()
    files = []
    for d, dirs, fs in os.walk(ROOT):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
        for f in sorted(fs):
            if f.endswith((".pyc", ".swp")):
                continue
            files.append(os.path.join(d, f))
    with zipfile.ZipFile(a.out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(files):
            rel = os.path.join(NAME, os.path.relpath(p, ROOT))
            zi = zipfile.ZipInfo(rel, date_time=(2026, 11, 17, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = (0o755 if os.access(p, os.X_OK) else 0o644) << 16
            with open(p, "rb") as fh:
                z.writestr(zi, fh.read())
    print("wrote %s (%d files)" % (a.out, len(files)))


if __name__ == "__main__":
    main()
