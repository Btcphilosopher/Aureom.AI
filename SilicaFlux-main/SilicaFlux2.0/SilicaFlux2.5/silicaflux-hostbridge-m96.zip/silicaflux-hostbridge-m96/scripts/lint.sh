#!/usr/bin/env bash
# Verilator -Wall lint (fatal) of one RTL top, with the vendored AlbionCore dependencies.
# usage: scripts/lint.sh <top_module> [extra verilator args...]
set -u
HERE="$(cd "$(dirname "$0")/.." && pwd)"
TOP="$1"; shift
T3="$HERE/third_party/albioncore/rtl"
FILES="$T3/sf_albion_pkg.sv $HERE/rtl/sf_albion_host_pkg.sv $T3/sf_albion_fifo.sv $T3/sf_albion_skid.sv \
 $T3/sf_albion_tag_tracker.sv $T3/sf_albion_err_resp.sv $T3/sf_albion_ref_mem.sv"
RTL=$(ls "$HERE"/rtl/sf_albion_host_*.sv | grep -v 'host_pkg.sv')
exec verilator --lint-only -Wall --top-module "$TOP" "$@" $FILES $RTL
