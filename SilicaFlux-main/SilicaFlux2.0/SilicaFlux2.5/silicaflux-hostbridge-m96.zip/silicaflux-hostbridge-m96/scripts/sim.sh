#!/usr/bin/env bash
# Build and run one self-checking testbench with Verilator.
# usage: scripts/sim.sh <tb_top> [-G... parameter overrides] [-- runtime plusargs]
# Prints the testbench output; exit status 0 only when the single HB_TB_RESULT line says PASS.
set -u
HERE="$(cd "$(dirname "$0")/.." && pwd)"
TB="$1"; shift
GARGS=(); RARGS=()
while [ $# -gt 0 ]; do
  if [ "$1" = "--" ]; then shift; RARGS=("$@"); break; fi
  GARGS+=("$1"); shift
done
T3="$HERE/third_party/albioncore"
OUT="${HB_BUILD_DIR:-$HERE/build}/sim/$TB"
mkdir -p "$OUT"
FILES="$T3/rtl/sf_albion_pkg.sv $HERE/rtl/sf_albion_host_pkg.sv $T3/rtl/sf_albion_fifo.sv $T3/rtl/sf_albion_skid.sv \
 $T3/rtl/sf_albion_tag_tracker.sv $T3/rtl/sf_albion_err_resp.sv $T3/rtl/sf_albion_ref_mem.sv \
 $T3/rtl/sf_albion_ref_subsystem.sv $T3/tests/sf_albion_chan_checker.sv $T3/tests/sf_albion_link_checker.sv \
 $(ls $HERE/rtl/sf_albion_host_*.sv | grep -v host_pkg.sv) $HERE/tb/sf_hb_tb_pkg.sv"
TBF=$(ls $HERE/tb/*.sv | grep -v sf_hb_tb_pkg.sv)
VFLAGS="--binary --timing --assert -Wno-fatal -Wno-WIDTHTRUNC -Wno-WIDTHEXPAND -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM \
 -Wno-DECLFILENAME -Wno-INITIALDLY -Wno-PINCONNECTEMPTY -Wno-UNOPTFLAT -Wno-BLKSEQ -Wno-STMTDLY -Wno-CASEINCOMPLETE \
 -Wno-LATCH -Wno-SYNCASYNCNET -Wno-MULTIDRIVEN -Wno-UNDRIVEN -Wno-WIDTHCONCAT -Wno-CASTCONST -Wno-ENUMVALUE -Wno-IMPLICIT"
verilator $VFLAGS -j 0 --top-module "$TB" -Mdir "$OUT/obj" ${GARGS[@]+"${GARGS[@]}"} $FILES $TBF -o sim > "$OUT/build.log" 2>&1
rc=$?
if [ $rc -ne 0 ]; then echo "BUILD FAILED ($TB)"; grep -E "^%Error" "$OUT/build.log" | head -20; exit 2; fi
cd "$OUT" && stdbuf -oL ./obj/sim +verilator+rand+reset+2 +verilator+seed+${HB_SEED:-1} ${RARGS[@]+"${RARGS[@]}"} > run.log 2>&1
cat run.log | grep -v "^COV " | tail -${HB_TAIL:-40}
grep -q "HB_TB_RESULT $TB PASS" run.log
