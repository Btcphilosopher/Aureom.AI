#!/usr/bin/env bash
# Yosys (>= 0.33) elaboration + generic synthesis check of one RTL top with the vendored AlbionCore files.
# Fails on: front-end errors, undriven / implicitly declared nets, inferred latches, and unresolved hierarchy.
# usage: scripts/synth.sh <top_module> [NAME=VALUE ...]   (parameter overrides; no timing / area claim is made)
set -u
HERE="$(cd "$(dirname "$0")/.." && pwd)"
TOP="$1"; shift
T3="$HERE/third_party/albioncore/rtl"
FILES="$T3/sf_albion_pkg.sv $HERE/rtl/sf_albion_host_pkg.sv $T3/sf_albion_fifo.sv $T3/sf_albion_skid.sv \
 $T3/sf_albion_tag_tracker.sv $T3/sf_albion_err_resp.sv $T3/sf_albion_ref_mem.sv \
 $(ls $HERE/rtl/sf_albion_host_*.sv | grep -v host_pkg.sv | tr "\n" " ")"
OUT="${HB_BUILD_DIR:-$HERE/build}/synth"
mkdir -p "$OUT"
CH=""
for kv in "$@"; do CH="$CH chparam -set ${kv%%=*} ${kv#*=} $TOP;"; done
LOG="$OUT/$TOP.log"
yosys -q -l "$LOG" -p "
  read_verilog -sv -defer $FILES;
  $CH
  hierarchy -check -top $TOP;
  proc; opt_clean; flatten; opt; memory -nomap; opt_clean;
  tee -o $OUT/$TOP.latches.txt select -count t:\$dlatch t:\$adlatch t:\$dlatchsr;
  check -assert;
  stat" > "$OUT/$TOP.run.txt" 2>&1
rc=$?
lat=$(cat "$OUT/$TOP.latches.txt" 2>/dev/null | grep -oE "[0-9]+ objects" | head -1 | grep -oE "[0-9]+")
warn=$(grep -ciE "warning: .*(latch|no driver|implicit|undriven)" "$LOG" 2>/dev/null)
echo "$TOP rc=$rc latches=${lat:-?} suspicious_warnings=${warn:-0}"
[ $rc -eq 0 ] && [ "${lat:-1}" = "0" ] && [ "${warn:-0}" = "0" ]
