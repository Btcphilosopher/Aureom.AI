#!/usr/bin/env python3
"""Mutation campaign: plant a bug in the RTL, run the simulations that should notice, require one to FAIL.

  mutate.py [--jobs N] [--only ID] [--list] [--all-on-survivor]

Each mutant is applied to a private copy of the project (build/mut/<id>/), so the working tree is never touched.
A mutant is KILLED when at least one of its test simulations prints HB_TB_RESULT ... FAIL (fail-fast is used) or
the simulation aborts on a protocol assertion; it is reported as BUILD when the mutant no longer compiles (a weak
kill); it SURVIVES when every selected simulation passes.  With --all-on-survivor a survivor is retried against every
simulation configuration so that "survived the quick tests" is separated from "no test can see it".

The mutant list is hand-written and aims at the places where a wrong bit costs something: byte masks, address and
length arithmetic, boundary / aperture / permission checks, the DomainGuard handshake, completion ordering and
error aggregation, tag lifecycle, reorder-buffer addressing, cancel / timeout bookkeeping, the ALP arbiter, the
CSR rights.  Mutants that the design makes provably equivalent are listed with equivalent=True so they are not
counted against the testbenches.
"""
import argparse
import concurrent.futures as cf
import json
import os
import re
import shlex
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import run_all  # noqa: E402

SIM = {n: (t, g) for (n, t, g) in list(run_all.SIMS) + run_all.soak_items(6)}

REQ = "rtl/sf_albion_host_req_path.sv"
DMA = "rtl/sf_albion_host_dma_path.sv"
GRD = "rtl/sf_albion_host_domain_guard.sv"
CSR = "rtl/sf_albion_host_csr.sv"
ARB = "rtl/sf_albion_host_alp_arb2.sv"
ENG = "rtl/sf_albion_host_dma_engine.sv"
BRG = "rtl/sf_albion_host_bridge.sv"
FAB = "rtl/sf_albion_host_alp_fabric.sv"
PKG = "rtl/sf_albion_host_pkg.sv"

# id, file, old, new, tests, description, equivalent
M = []
def mut(i, f, old, new, tests, desc, equivalent=False):
    M.append(dict(id=i, file=f, old=old, new=new, tests=tests, desc=desc, equivalent=equivalent))

# ---------------------------------------------------------------- host -> device path
mut("req_last_mask", REQ, "span_mask & sf_albion_host_pkg::sf_hti_last_mask(last_addr[3:0])",
    "span_mask & sf_albion_host_pkg::sf_hti_last_mask(addr_q[3:0])", ["smoke", "host_path"], "last-word byte mask uses the start lane")
mut("req_first_mask", REQ, "if (widx_q == '0) span_mask", "if (widx_q == WORDS_W'(1)) span_mask", ["smoke", "host_path"],
    "first-word byte mask applied to the wrong word")
mut("req_strobe_and", REQ, "word_be   = is_write ? (span_mask & wq_be) : span_mask;", "word_be   = span_mask;",
    ["host_path"], "host byte strobes ignored on writes")
mut("req_span_and", REQ, "word_be   = is_write ? (span_mask & wq_be) : span_mask;", "word_be   = is_write ? wq_be : span_mask;",
    ["host_path"], "span mask not applied to write strobes (dirty lanes leak)")
mut("req_skip_zero_be", REQ, "word_skip = is_write && (word_be == '0);", "word_skip = 1'b0;", ["host_path"],
    "zero-strobe words are issued (illegal ALP BE == 0)")
mut("req_word_addr", REQ, "{daddr_q[ADDR_W-1:4] + {{(ADDR_W-4-WORDS_W){1'b0}}, widx_q}, 4'h0}",
    "{daddr_q[ADDR_W-1:4] + {{(ADDR_W-4-WORDS_W){1'b0}}, widx_q} + 60'd1, 4'h0}", ["host_path"],
    "ALP word address off by one word (self-consistent through read-back: needs the SRAM backdoor)")
mut("req_boundary", REQ, "else if (bound_cross)         v_status", "else if (1'b0)                v_status",
    ["host_path"], "4 KiB boundary check removed")
mut("req_wrap", REQ, "else if (ovf)                 v_status", "else if (1'b0)                v_status",
    ["host_path"], "address-wrap check removed (made redundant by the boundary check)", equivalent=True)
mut("req_len_off1", REQ, "(len_q > LEN_W'(MAX_REQ_BYTES))", "(len_q >= LEN_W'(MAX_REQ_BYTES))", ["host_path"],
    "maximum request length off by one")
mut("req_len_zero", REQ, "else if (len_zero || len_big) v_status", "else if (len_big) v_status", ["host_path"],
    "zero length accepted")
mut("req_aperture_full", REQ, "assign ap_full[a]  = ap_start[a] && ((last_addr - AP_B) < AP_S);",
    "assign ap_full[a]  = ap_start[a];", ["host_path_ap6k"], "request may straddle the aperture end")
mut("req_perm_swap", REQ, "v_perm_ok = is_write ? AP_PERM[(a-1)*2 + 1] : AP_PERM[(a-1)*2];",
    "v_perm_ok = is_write ? AP_PERM[(a-1)*2] : AP_PERM[(a-1)*2 + 1];", ["perm"], "aperture read / write rights swapped")
mut("req_unmapped", REQ, "else if (!any_start)          v_status = sf_albion_host_pkg::SF_HS_UR;",
    "else if (1'b0)                v_status = sf_albion_host_pkg::SF_HS_UR;", ["host_path"], "unmapped addresses accepted")
mut("req_dom_ff", REQ, "else if (dom_bad)             v_status", "else if (1'b0)                v_status", ["host_path"],
    "reserved domain 0xFF reaches the fabric (needs the 'no illegal ALP request' monitor)")
mut("req_kind_none", REQ, "else if (kind_bad)            v_status", "else if (1'b0)                v_status", ["host_path"],
    "invalid request kind accepted")
mut("req_guard_ignored", REQ, "end else if (grd_permit_i) begin", "end else if (1'b1) begin", ["guard_lat0"],
    "DomainGuard verdict ignored (everything permitted)")
mut("req_guard_inverted_status", REQ, "err_d = (grd_status_i == sf_albion_pkg::SF_ST_OKAY)", "err_d = (grd_status_i != sf_albion_pkg::SF_ST_OKAY)",
    ["guard_lat0"], "deny verdict status mangled (needs a guard that returns every ALP status)")
mut("req_guard_bypass_when_valid", REQ, "assign grd_req_valid_o = GUARD_EN && (fs_q == S_GUARD);",
    "assign grd_req_valid_o = GUARD_EN && (fs_q == S_GUARD) && !grd_rsp_valid_i;", ["guard_lat9"],
    "request offered to the guard drops while the verdict is pending")
mut("req_drain_count", REQ, "if (widx_next == nwords) fs_d = issued_q ? S_END : S_LOCAL;",
    "if (widx_next == nwords - WORDS_W'(1)) fs_d = issued_q ? S_END : S_LOCAL;", ["host_path"],
    "one beat too few drained from a rejected write")
mut("req_first_error", REQ, "if ((agg_q == sf_albion_host_pkg::SF_HS_OK) && !rsp_ok) agg_d = rsp_hs;",
    "if (!rsp_ok) agg_d = rsp_hs;", ["fabric_faults"], "write reports the LAST error instead of the first")
mut("req_read_term", REQ, "term_d      = cw_last;", "term_d      = 1'b1;", ["smoke", "host_path"],
    "a read ends after its first beat")
mut("req_conf_flag", REQ, "&& (m_rsp_i.meta.is_write == cw_is_wr);", ";", ["fabric_faults"],
    "operation flag of the response not checked")
mut("req_cancel_count", REQ, "abort_cnt_d = rq_count - (pop_now ? RQ_CNT_W'(1) : RQ_CNT_W'(0));", "abort_cnt_d = rq_count;",
    ["cancel_reset"], "cancel snapshot counts the popped request twice (over-aborts a request accepted after the cancel)")
mut("req_abort_issue", REQ, "        if (abort_cur_q) begin\n          err_d = sf_albion_host_pkg::SF_HS_ABORTED;\n          if (rem_beats)",
    "        if (1'b0) begin\n          err_d = sf_albion_host_pkg::SF_HS_ABORTED;\n          if (rem_beats)", ["cancel_reset"],
    "cancel does not stop a half-issued request")
mut("req_posted_event", REQ, "(cw_is_wr && cw_posted));\n  end\n  assign eng_req", "1'b0);\n  end\n  assign eng_req", ["cancel_reset"],
    "an ABORTED posted write is not logged (it has no completion to carry the news)")
mut("req_event_addr", REQ, ".in_valid_i (ea_in_valid), .in_ready_o(), .in_data_i(addr_q),",
    ".in_valid_i (ea_in_valid), .in_ready_o(), .in_data_i(~addr_q),", ["fabric_faults"], "request address of an event corrupted")

# ---------------------------------------------------------------- device -> host path
mut("dma_chunk_align", DMA, "assign to_bound   = cmax - {1'b0, cur_q[11:0] & (cmax[11:0] - 12'd1)};", "assign to_bound   = cmax;",
    ["dma_smoke"], "chunks not cut at MPS / MRRS boundaries")
mut("dma_mps_mrrs", DMA, "assign cmax       = wr_q ? 13'(MPS_BYTES) : 13'(MRRS_BYTES);", "assign cmax       = 13'(MRRS_BYTES);",
    ["dma_t5_128_512"], "writes use the read request size")
mut("dma_posted_ready", DMA, "assign chunk_ready  = pw ? !dwv_q : (t_done || t_aband);", "assign chunk_ready  = pw ? 1'b1 : (t_done || t_aband);",
    ["dma_t8_256_256"], "posted write completes before the host side accepted its data")
mut("dma_short_cpl", DMA, "if (dc_got + WORDS_W'(1) != dc_exp) dc_err = sf_albion_host_pkg::SF_HS_PROTO;   // short completion",
    ";", ["dma_t8_256_256"], "short completion not detected")
mut("dma_busy_check", DMA, "t_busy_q[dc_idx] && !t_done_q[dc_idx];", "!t_done_q[dc_idx];", ["dma_t8_256_256"],
    "completion beats accepted for tags that are not busy")
mut("dma_cancel_abandon", DMA, "assign cn_mark = {NUM_TAGS{cancel_q}} & t_busy_q & ~t_done_q & ~t_aband_q;",
    "assign cn_mark = '0;", ["cancel_reset"], "cancel does not abandon outstanding tags")
mut("dma_free_early", DMA, "assign t_free = t_busy_q & t_done_q & t_drained_q;", "assign t_free = t_busy_q & t_done_q;",
    ["dma_t8_256_256", "soak_s1"], "tag released before its data was drained")
mut("dma_tmo_force", DMA, "tmo_force[i] = t_aband_q[i];", "tmo_force[i] = 1'b0;", ["dma_timeout"],
    "abandoned tag is never released without a completion")
mut("dma_pterm", DMA, "        end else if (pterm_q) begin\n          // an earlier chunk of this read request failed",
    "        end else if (1'b0) begin\n          // an earlier chunk of this read request failed", ["dma_t8_256_256"],
    "chunks after a failed chunk are delivered to the client")
mut("dma_wr_first_mask", DMA, "if (wbeat_q == '0) wd_mask = wd_mask & sf_albion_host_pkg::sf_hti_first_mask(cur_q[3:0]);",
    "if (1'b0) wd_mask = wd_mask & sf_albion_host_pkg::sf_hti_first_mask(cur_q[3:0]);", ["dma_t8_256_256"],
    "write strobes below the start lane not cleared")
mut("dma_ev_dedupe", DMA, "(!ck_is_wr || (pagg_q == sf_albion_host_pkg::SF_HS_OK));", "1'b1;", ["dma_t3_16_32"],
    "one event per FAILING CHUNK of a write instead of per request")
mut("dma_rob_addr", DMA, "assign rob_waddr    = {dc_idx, dc_got[CHW_LOG2-1:0]};", "assign rob_waddr    = {dc_idx, dc_got[CHW_LOG2-1:0] + CHW_LOG2'(1)};",
    ["dma_smoke"], "reorder buffer written one word off")
mut("dma_lowest_tag", DMA, "if (!tag_avail && !t_busy_q[i]) begin", "if (!t_busy_q[i]) begin", ["dma_t8_256_256"],
    "tag allocator picks the highest free tag (unique, but the documented behaviour is lowest-free)")
mut("dma_zero_len", DMA, "assign v_zero = (len_q == '0);", "assign v_zero = 1'b0;", ["dma_t8_256_256"],
    "zero-length DMA request accepted")
mut("dma_wrap", DMA, "assign v_wrap = sum65[ADDR_W] && (sum65[ADDR_W-1:0] != '0);", "assign v_wrap = 1'b0;", ["dma_t8_256_256"],
    "DMA request that wraps the 64-bit address space accepted")
mut("dma_wrap_exact", DMA, "assign v_wrap = sum65[ADDR_W] && (sum65[ADDR_W-1:0] != '0);", "assign v_wrap = sum65[ADDR_W];", ["dma_t8_256_256"],
    "a DMA request that ends exactly at 2^64 is rejected as a wrap")

# ---------------------------------------------------------------- DomainGuard
mut("grd_limit", GRD, "(chk_addr_i >= w_base_q[i]) && (last <= w_limit_q[i]) &&", "(chk_addr_i >= w_base_q[i]) && (chk_addr_i <= w_limit_q[i]) &&",
    ["guard_lat0"], "only the first byte of a request is checked against the window")
mut("grd_dom", GRD, "if (w_valid_q[i] && (w_dom_q[i] == chk_dom_i) &&", "if (w_valid_q[i] && 1'b1 &&", ["guard_lat0"],
    "window domain not compared (tenants see each other's memory)")
mut("grd_rw", GRD, "(op_rd ? w_rd_q[i] : w_wr_q[i])) begin", "(op_rd ? w_wr_q[i] : w_rd_q[i])) begin", ["guard_lat0"],
    "read / write rights swapped")
mut("grd_reset", GRD, "w_valid_q <= '0;                      // default deny", "w_valid_q <= '1;                      // default deny",
    ["guard_lat0"], "windows valid after reset (default permit; un-reset contents hide it from behaviour: needs a state check)")
mut("grd_wrap", GRD, "assign ovf      = sum[AW] && (sum[AW-1:0] != '0);", "assign ovf      = 1'b0;", ["guard_lat0"],
    "address overflow not caught by the guard (the bridge also catches it: equivalent)", equivalent=True)

# ---------------------------------------------------------------- CSR block
mut("csr_priv_write", CSR, "if (r_ro[d] || (r_pw[d] && !priv_ok)) deny = 1'b1;", "if (r_ro[d]) deny = 1'b1;", ["system"],
    "privileged registers writable by any domain")
mut("csr_ro_write", CSR, "if (r_ro[d] || (r_pw[d] && !priv_ok)) deny = 1'b1;", "if ((r_pw[d] && !priv_ok)) deny = 1'b1;", ["system"],
    "read-only registers writable")
mut("csr_priv_read", CSR, "if (r_pr[d] && !priv_ok) deny = 1'b1;", "if (1'b0) deny = 1'b1;", ["system"],
    "guard window table readable by any domain")
mut("csr_priv_attr", CSR, "&& req_attr[sf_albion_pkg::SF_ATTR_PRIV_BIT];", ";", ["csr_unit"],
    "privileged attribute not required (domain alone decides)")
mut("csr_guard_commit", CSR, "gcfg_we_d    = 1'b1;                       // writing ATTR commits the window to the guard",
    "gcfg_we_d    = 1'b0;", ["system"], "guard window never committed")

# ---------------------------------------------------------------- fabric pieces
mut("arb_tag_restore", ARB, "rsp_rest.tag = ord_tag;", "rsp_rest.tag = t_rsp_i.tag;", ["system"],
    "initiator tag not restored on the response")
mut("arb_route", ARB, "assign m0_rsp_valid_o = t_rsp_valid_i && ord_out_valid && !ord_src;",
    "assign m0_rsp_valid_o = t_rsp_valid_i && ord_out_valid && ord_src;", ["system"], "response steered to the wrong initiator")
mut("eng_d2h_addr", ENG, ": (src_q + {{(64-NW_W-4){1'b0}}, ridx_q, 4'h0});", ": (src_q);", ["system"], "SRAM read address does not advance")
mut("eng_last", ENG, "assign dma_w_last_o  = (widx_q == nw_q - NW_W'(1));", "assign dma_w_last_o  = 1'b0;", ["system"],
    "DMA write never marks its last beat (shows up only as a PROTO event in the error log)")
mut("fab_csr_check", FAB, "acc_status = sf_albion_pkg::sf_access_check_bits(sf_albion_host_pkg::SF_HB_DEMO_CSR_ATTR, dec_req);",
    "acc_status = sf_albion_pkg::SF_ST_OKAY;", ["system"], "fabric region access check of the register window removed")
mut("brg_evt_lock", BRG, "    if (lock_q)                                   pick_dma = sel_q;", "    if (1'b0)                                     pick_dma = sel_q;",
    ["multi_out8"], "event merge may flip while the consumer stalls")

# ----------------------------------------------------------------------------------------------------------------
def prepare(m):
    d = os.path.join(ROOT, "build", "mut", m["id"])
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    for item in ("rtl", "tb", "third_party", "scripts"):
        shutil.copytree(os.path.join(ROOT, item), os.path.join(d, item), ignore=shutil.ignore_patterns("build", "__pycache__"))
    p = os.path.join(d, m["file"])
    text = open(p).read()
    n = text.count(m["old"])
    if n != 1:
        return d, "PATCH_FAIL (pattern found %d times)" % n
    open(p, "w").write(text.replace(m["old"], m["new"]))
    return d, None


def run_tests(d, names, failfast=True):
    for n in names:
        top, g = SIM[n] if n in SIM else (None, None)
        if top is None:
            return "NOTEST", n
        cmd = "scripts/sim.sh %s %s -- %s" % (top, " ".join(shlex.quote(x) for x in g), "+hb_failfast" if failfast else "")
        env = dict(os.environ, HB_BUILD_DIR=os.path.join(d, "build"), HB_TAIL="40")
        p = subprocess.run(cmd, shell=True, cwd=d, env=env, capture_output=True, text=True)
        out = p.stdout + p.stderr
        if "BUILD FAILED" in out:
            return "BUILD", n
        if re.search(r"HB_TB_RESULT\s+\S+\s+FAIL", out) or (p.returncode != 0):
            return "KILLED", n
    return "SURVIVED", ",".join(names)


def baseline(names, jobs):
    """Every selected test must PASS on the UNMUTATED tree; otherwise a 'kill' proves nothing."""
    d = os.path.join(ROOT, "build", "mut", "_baseline")
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    for item in ("rtl", "tb", "third_party", "scripts"):
        shutil.copytree(os.path.join(ROOT, item), os.path.join(d, item), ignore=shutil.ignore_patterns("build", "__pycache__"))
    def one_test(n):
        top, g = SIM[n]
        env = dict(os.environ, HB_BUILD_DIR=os.path.join(d, "build", n), HB_TAIL="40")
        p = subprocess.run("scripts/sim.sh %s %s" % (top, " ".join(shlex.quote(x) for x in g)), shell=True, cwd=d, env=env,
                           capture_output=True, text=True)
        return n, p.returncode == 0 and re.search(r"HB_TB_RESULT\s+\S+\s+PASS", p.stdout) is not None
    with cf.ThreadPoolExecutor(jobs) as ex:
        res = list(ex.map(one_test, sorted(names)))
    shutil.rmtree(d, ignore_errors=True)
    return [n for n, ok in res if not ok]


def one(m, all_on_survivor):
    d, err = prepare(m)
    if err:
        return dict(m, status=err, by="")
    st, by = run_tests(d, m["tests"])
    if st == "SURVIVED" and all_on_survivor:
        everything = [n for (n, _, _) in run_all.SIMS if n not in m["tests"]]
        st2, by2 = run_tests(d, everything)
        if st2 == "KILLED":
            st, by = "KILLED_BY_OTHER", by2
    shutil.rmtree(d, ignore_errors=True)
    return dict(m, status=st, by=by)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", default="")
    ap.add_argument("--ids", default="", help="comma separated mutant ids")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--all-on-survivor", action="store_true")
    a = ap.parse_args()
    ms = [m for m in M if a.only in m["id"] and (not a.ids or m["id"] in a.ids.split(","))]
    if a.list:
        for m in ms:
            print("%-26s %-34s %s%s" % (m["id"], ",".join(m["tests"]), m["desc"], "  [equivalent]" if m["equivalent"] else ""))
        print(len(ms), "mutants")
        return 0
    os.makedirs(os.path.join(ROOT, "build", "reports"), exist_ok=True)
    bad_base = baseline({t for m in ms for t in m["tests"]}, a.jobs)
    if bad_base:
        print("BASELINE FAILS on the unmutated tree for: %s -- fix these tests first; no mutant was run" % ", ".join(bad_base))
        return 2
    print("baseline: every selected test passes on the unmutated tree")
    res = []
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        futs = [ex.submit(one, m, a.all_on_survivor) for m in ms]
        for f in cf.as_completed(futs):
            r = f.result()
            res.append(r)
            print("%-9s %-26s by=%-18s %s" % (r["status"], r["id"], r["by"], r["desc"]))
            sys.stdout.flush()
    res.sort(key=lambda r: r["id"])
    json.dump(res, open(os.path.join(ROOT, "build", "reports", "mutation.json"), "w"), indent=1)
    killed = [r for r in res if r["status"].startswith("KILLED")]
    build = [r for r in res if r["status"] in ("BUILD",)]
    surv = [r for r in res if r["status"] == "SURVIVED" and not r["equivalent"]]
    eq = [r for r in res if r["equivalent"]]
    bad = [r for r in res if r["status"].startswith("PATCH") or r["status"] == "NOTEST"]
    with open(os.path.join(ROOT, "build", "reports", "mutation.md"), "w") as f:
        f.write("# Mutation campaign\n\n%d mutants: %d killed by simulation, %d build failures, %d survivors, %d equivalent, %d broken patches\n\n"
                % (len(res), len(killed), len(build), len(surv), len(eq), len(bad)))
        for r in res:
            f.write("* %s `%s` (%s) %s%s\n" % (r["status"], r["id"], r["by"], r["desc"], " [equivalent]" if r["equivalent"] else ""))
    print("\n%d mutants: %d killed, %d build failures, %d SURVIVORS, %d equivalent, %d broken patches" %
          (len(res), len(killed), len(build), len(surv), len(eq), len(bad)))
    for r in surv:
        print("  SURVIVOR: %s -- %s" % (r["id"], r["desc"]))
    for r in bad:
        print("  BROKEN:   %s -- %s" % (r["id"], r["status"]))
    return 1 if (surv or bad) else 0


if __name__ == "__main__":
    sys.exit(main())
