"""Shared helpers for the AlbionCore build tools.

Only the Python standard library and PyYAML are used.  Nothing here executes
design code; the SystemVerilog scanners are deliberately simple lexical tools
that work on the restricted style the library itself enforces.
"""
import os
import re
import sys

ROOT = os.path.abspath(os.environ.get("ALBION_ROOT") or os.path.join(os.path.dirname(__file__), "..", "..", ".."))

RTL_DIRS = ["rtl/albion", "rtl/albion/cdc", "rtl/albion/ref", "rtl/albion/generated"]
TEST_DIRS = ["tests/albion/common", "tests/albion/unit", "tests/albion/system",
             "tests/albion/cdc", "tests/albion/formal"]


def rel(path):
    return os.path.relpath(path, ROOT)


def read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def load_yaml(path):
    try:
        import yaml
    except ImportError:
        sys.exit("error: PyYAML is required (pip install pyyaml)")
    with open(path, encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def strip_comments(text):
    """Remove // and /* */ comments and string literals' contents (keeps newlines)."""
    out = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if text.startswith("//", i):
            j = text.find("\n", i)
            j = n if j < 0 else j
            i = j
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            j = n if j < 0 else j + 2
            out.append("\n" * text.count("\n", i, j))
            i = j
        elif c == '"':
            j = i + 1
            while j < n and text[j] != '"':
                j += 2 if text[j] == "\\" else 1
            out.append('""')
            i = j + 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


KEYWORDS = {
    "module", "endmodule", "package", "endpackage", "interface", "endinterface", "program",
    "function", "endfunction", "task", "endtask", "generate", "endgenerate", "if", "else", "for",
    "case", "endcase", "begin", "end", "always_ff", "always_comb", "always", "assign", "initial",
    "logic", "wire", "reg", "input", "output", "inout", "parameter", "localparam", "typedef",
    "struct", "enum", "packed", "automatic", "int", "unsigned", "bit", "genvar", "import", "return",
    "default", "unique", "priority", "assert", "assume", "cover", "string", "void", "time",
}

DECL_RE = re.compile(r"^\s*(module|package)\s+(?:automatic\s+)?([A-Za-z_]\w*)", re.M)


def scan_defs(path):
    """Return {'modules': [...], 'packages': [...]} defined in the file."""
    text = strip_comments(read(path))
    mods, pkgs = [], []
    for m in DECL_RE.finditer(text):
        (mods if m.group(1) == "module" else pkgs).append(m.group(2))
    return {"modules": mods, "packages": pkgs}


def collect_sv(dirs, profile=None):
    """All .sv files in the given repo-relative directories (+ generated profile files)."""
    files = []
    for d in dirs:
        p = os.path.join(ROOT, d)
        if os.path.isdir(p):
            for f in sorted(os.listdir(p)):
                if f.endswith(".sv"):
                    files.append(os.path.join(p, f))
    if profile:
        gd = os.path.join(ROOT, "build", "gen", profile)
        if os.path.isdir(gd):
            for f in sorted(os.listdir(gd)):
                if f.endswith(".sv"):
                    files.append(os.path.join(gd, f))
    return files


class Index:
    """Definition index and dependency resolver over a set of SV files."""

    def __init__(self, files, overrides=None):
        # overrides: {repo-relative path -> replacement absolute path} (mutation runs)
        self.overrides = overrides or {}
        self.defs = {}        # name -> file (modules and packages share one namespace here)
        self.kind = {}        # name -> 'module' | 'package'
        self.files = {}       # file -> {'modules', 'packages', 'text'}
        self.dups = []
        for f in files:
            src = self.overrides.get(rel(f), f)
            d = scan_defs(src)
            text = strip_comments(read(src))
            self.files[f] = {"modules": d["modules"], "packages": d["packages"], "text": text, "src": src}
            for name in d["modules"] + d["packages"]:
                if name in self.defs and self.defs[name] != f:
                    self.dups.append((name, rel(self.defs[name]), rel(f)))
                self.defs[name] = f
                self.kind[name] = "module" if name in d["modules"] else "package"
        self._tok = re.compile(r"[A-Za-z_]\w*")

    def deps_of(self, f):
        """Files that file f depends on (modules instantiated, packages referenced)."""
        info = self.files[f]
        own = set(info["modules"]) | set(info["packages"])
        found = set()
        for m in self._tok.finditer(info["text"]):
            name = m.group(0)
            if name in self.defs and name not in own:
                found.add(self.defs[name])
        found.discard(f)
        return found

    def closure(self, tops):
        """Topologically ordered file list needed to elaborate the given top module names."""
        order, state = [], {}

        def visit(f, stack):
            if state.get(f) == 2:
                return
            if state.get(f) == 1:
                raise ValueError("dependency cycle: " + " -> ".join(rel(x) for x in stack + [f]))
            state[f] = 1
            # packages first, then modules, each group in a stable order
            deps = sorted(self.deps_of(f), key=lambda x: (0 if self.files[x]["packages"] else 1, rel(x)))
            for d in deps:
                visit(d, stack + [f])
            state[f] = 2
            order.append(f)

        for t in tops:
            if t not in self.defs:
                raise KeyError("top module '%s' is not defined in any scanned file" % t)
            visit(self.defs[t], [])
        return order


def run(cmd, cwd=None, env=None, timeout=None, log=None):
    """Run a command, return (rc, combined_output).  Never uses a shell."""
    import subprocess
    try:
        p = subprocess.run(cmd, cwd=cwd or ROOT, env=env, timeout=timeout,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        out, rc = p.stdout, p.returncode
    except subprocess.TimeoutExpired as e:
        out, rc = (e.stdout or "") + "\nTIMEOUT after %ss\n" % timeout, 124
    except FileNotFoundError:
        out, rc = "command not found: %s\n" % cmd[0], 127
    if log:
        os.makedirs(os.path.dirname(log), exist_ok=True)
        with open(log, "w", encoding="utf-8") as fh:
            fh.write(out)
    return rc, out


def tool_version(cmd, pattern):
    rc, out = run(cmd)
    m = re.search(pattern, out)
    return m.group(1) if (rc == 0 and m) else None


def eval_const(expr, env):
    """Evaluate a SystemVerilog constant integer expression (+ - * / and names) safely."""
    expr = " ".join(expr.split())          # multi-line expressions
    e = re.sub(r"(\d+)'[sS]?[hH]([0-9a-fA-F_]+)", lambda m: str(int(m.group(2).replace("_", ""), 16)), expr)
    e = re.sub(r"(\d+)'[sS]?[dD]([0-9_]+)", lambda m: str(int(m.group(2).replace("_", ""))), e)
    e = re.sub(r"(\d+)'[sS]?[bB]([01_]+)", lambda m: str(int(m.group(2).replace("_", ""), 2)), e)
    e = e.replace("/", "//")
    toks = re.findall(r"[A-Za-z_]\w*", e)
    for t in toks:
        if t not in env:
            raise ValueError("unknown identifier '%s' in constant expression '%s'" % (t, expr))
    if not re.fullmatch(r"[\w\s+\-*/()<>]*", e):
        raise ValueError("unsupported constant expression: " + expr)
    return int(eval(e, {"__builtins__": {}}, dict(env)))  # noqa: S307  (restricted charset checked above)
