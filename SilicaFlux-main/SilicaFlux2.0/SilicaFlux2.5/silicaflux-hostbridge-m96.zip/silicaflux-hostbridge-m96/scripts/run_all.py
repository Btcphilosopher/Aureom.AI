#!/usr/bin/env python3
"""HostBridge regression runner: style, lint, Yosys synthesis check, every simulation configuration.

  run_all.py [--jobs N] [--only SUBSTR] [--seeds N] [group ...]     groups: style lint synth sim   (default: all)

Every simulation is built in its own directory (build/sims/<name>) and must print exactly one
    HB_TB_RESULT <tb> PASS checks=<n> errors=<n>
line.  Results and a summary are written to build/reports/ (results.json, summary.md).
Exit status is non-zero if anything failed.  No timing / area / PCIe-compliance claim is made by any step.
"""
import argparse
import concurrent.futures as cf
import json
import os
import re
import shlex
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "build")

TOPS = ["sf_albion_host_bridge", "sf_albion_host_req_path", "sf_albion_host_dma_path", "sf_albion_host_domain_guard",
        "sf_albion_host_csr", "sf_albion_host_dma_engine", "sf_albion_host_alp_arb2", "sf_albion_host_alp_fabric",
        "sf_albion_host_soc_demo"]

# (name, top, [-G overrides])
SIMS = [
    ("smoke", "tb_hb_smoke", []),
    ("dma_smoke", "tb_hb_dma_smoke", []),
    ("host_path", "tb_hb_host_path", []),
    ("host_path_ap6k", "tb_hb_host_path", ["-GAP1_SIZE=64'h1800"]),
    ("dma_t8_256_256", "tb_hb_dma", ["-GNUM_TAGS=8", "-GMPS_BYTES=256", "-GMRRS_BYTES=256"]),
    ("dma_t1_256_256", "tb_hb_dma", ["-GNUM_TAGS=1", "-GMPS_BYTES=256", "-GMRRS_BYTES=256"]),
    ("dma_t2_64_64", "tb_hb_dma", ["-GNUM_TAGS=2", "-GMPS_BYTES=64", "-GMRRS_BYTES=64"]),
    ("dma_t3_16_32", "tb_hb_dma", ["-GNUM_TAGS=3", "-GMPS_BYTES=16", "-GMRRS_BYTES=32"]),
    ("dma_t5_128_512", "tb_hb_dma", ["-GNUM_TAGS=5", "-GMPS_BYTES=128", "-GMRRS_BYTES=512"]),
    ("dma_t16_4096_4096", "tb_hb_dma", ["-GNUM_TAGS=16", "-GMPS_BYTES=4096", "-GMRRS_BYTES=4096"]),
    ("dma_t64_256_256", "tb_hb_dma", ["-GNUM_TAGS=64", "-GMPS_BYTES=256", "-GMRRS_BYTES=256"]),
    ("dma_timeout", "tb_hb_dma_timeout", []),
    ("cancel_reset", "tb_hb_cancel_reset", []),
    ("guard_lat0", "tb_hb_guard", ["-GLAT=0"]),
    ("guard_lat1", "tb_hb_guard", ["-GLAT=1"]),
    ("guard_lat3", "tb_hb_guard", ["-GLAT=3"]),
    ("guard_lat9", "tb_hb_guard", ["-GLAT=9"]),
    ("fabric_faults", "tb_hb_fabric_faults", []),
    ("perm", "tb_hb_perm", []),
    ("csr_unit", "tb_hb_csr", []),
    ("multi_out1", "tb_hb_multi", ["-GMAX_OUT=1"]),
    ("multi_out2", "tb_hb_multi", ["-GMAX_OUT=2"]),
    ("multi_out8", "tb_hb_multi", ["-GMAX_OUT=8"]),
    ("multi_out32", "tb_hb_multi", ["-GMAX_OUT=32", "-GRSP_DEPTH=64"]),
    ("system", "tb_hb_system", []),
]
SOAK_CFG = [(8, 256, 256, 8), (3, 64, 128, 2), (16, 4096, 4096, 32), (1, 256, 256, 1), (5, 16, 32, 4), (64, 128, 128, 16)]

def soak_items(n):
    """The constrained-random soak runs: (name, top, -G overrides), one per soak configuration / seed."""
    items = []
    for i in range(n):
        t, mps, mrrs, mo = SOAK_CFG[i % len(SOAK_CFG)]
        items.append(("soak_s%d" % (i + 1), "tb_hb_soak",
                      ["-GSEED=%d" % (i + 1), "-GROUNDS=14", "-GNUM_TAGS=%d" % t, "-GMPS_BYTES=%d" % mps,
                       "-GMRRS_BYTES=%d" % mrrs, "-GMAX_OUT=%d" % mo]))
    return items


SYNTH_VARIANTS = [
    ("sf_albion_host_dma_path", ["CPL_TIMEOUT=100"]),
    ("sf_albion_host_dma_path", ["NUM_TAGS=5", "MRRS_BYTES=32", "MPS_BYTES=16", "CK_Q_DEPTH=8"]),
    ("sf_albion_host_dma_path", ["NUM_TAGS=1", "CK_Q_DEPTH=4"]),
    ("sf_albion_host_req_path", ["GUARD_EN=0", "MAX_OUT=1"]),
    ("sf_albion_host_bridge", ["GUARD_EN=0", "NUM_TAGS=64", "CK_Q_DEPTH=66"]),
    ("sf_albion_host_domain_guard", ["NUM_WIN=1"]),
    ("sf_albion_host_csr", ["NUM_WIN=1"]),
]
LINT_VARIANTS = [
    ("sf_albion_host_dma_path", ["-GCPL_TIMEOUT=100"]),
    ("sf_albion_host_dma_path", ["-GNUM_TAGS=5", "-GMRRS_BYTES=32", "-GMPS_BYTES=16", "-GCK_Q_DEPTH=8"]),
    ("sf_albion_host_dma_path", ["-GNUM_TAGS=64", "-GCK_Q_DEPTH=66", "-GCPL_TIMEOUT=7"]),
    ("sf_albion_host_req_path", ["-GMAX_OUT=1"]),
    ("sf_albion_host_req_path", ["-GMAX_OUT=64", "-GGUARD_EN=0"]),
    ("sf_albion_host_csr", ["-GNUM_WIN=1"]),
]


def sh(cmd, env=None, timeout=3600):
    e = dict(os.environ)
    if env:
        e.update(env)
    t0 = time.time()
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=ROOT, env=e, timeout=timeout)
    return p.returncode, p.stdout + p.stderr, time.time() - t0


def run_sim(item, seed):
    name, top, gargs = item
    bdir = os.path.join(BUILD, "sims", name)
    rc, out, dt = sh("scripts/sim.sh %s %s" % (top, " ".join(shlex.quote(g) for g in gargs)),
                     env={"HB_BUILD_DIR": bdir, "HB_SEED": str(seed), "HB_TAIL": "400"})
    m = re.search(r"HB_TB_RESULT\s+(\S+)\s+(PASS|FAIL)\s+checks=(\d+)\s+errors=(\d+)", out)
    cov = {}
    runlog = os.path.join(bdir, "sim", top, "run.log")
    if os.path.exists(runlog):
        for l in open(runlog):
            c = re.match(r"COV\s+\S+\s+(\S+)\s+(\d+)", l)
            if c:
                cov[c.group(1)] = int(c.group(2))
    if "BUILD FAILED" in out:
        return dict(name=name, status="BUILD_FAIL", checks=0, errors=0, secs=round(dt, 1), seed=seed, detail=out[-800:], cov=cov)
    if not m:
        return dict(name=name, status="NO_RESULT", checks=0, errors=0, secs=round(dt, 1), seed=seed, detail=out[-800:], cov=cov)
    ok = (m.group(2) == "PASS") and rc == 0
    return dict(name=name, status="PASS" if ok else "FAIL", checks=int(m.group(3)), errors=int(m.group(4)),
                secs=round(dt, 1), seed=seed, detail="" if ok else out[-1500:], cov=cov)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("groups", nargs="*", default=["style", "lint", "synth", "sim"])
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2)))
    ap.add_argument("--only", default="")
    ap.add_argument("--seeds", type=int, default=1, help="run every simulation with this many simulator seeds")
    ap.add_argument("--soak-seeds", type=int, default=6)
    a = ap.parse_args()
    os.makedirs(os.path.join(BUILD, "reports"), exist_ok=True)
    results = {"style": [], "lint": [], "synth": [], "sim": []}
    failed = False

    if "style" in a.groups:
        rc, out, _ = sh("python3 -I scripts/style_check.py rtl/*.sv")
        results["style"].append(dict(name="style_check", status="PASS" if rc == 0 else "FAIL", detail=out.strip()[-600:]))
        print("style: %s" % out.strip().splitlines()[-1])
        failed |= rc != 0

    if "lint" in a.groups:
        jobs = [(t, []) for t in TOPS] + LINT_VARIANTS
        def lint(j):
            t, g = j
            rc, out, _ = sh("scripts/lint.sh %s %s" % (t, " ".join(shlex.quote(x) for x in g)))
            n = len(re.findall(r"^%(Warning|Error)", out, re.M))
            return dict(name="%s %s" % (t, " ".join(g)), status="PASS" if rc == 0 and n == 0 else "FAIL", detail=out[-600:])
        with cf.ThreadPoolExecutor(a.jobs) as ex:
            results["lint"] = list(ex.map(lint, jobs))
        for r in results["lint"]:
            print("lint  %-4s %s" % (r["status"], r["name"]))
        failed |= any(r["status"] != "PASS" for r in results["lint"])

    if "synth" in a.groups:
        jobs = [(t, []) for t in TOPS] + SYNTH_VARIANTS
        def syn(j):
            t, g = j
            rc, out, _ = sh("scripts/synth.sh %s %s" % (t, " ".join(shlex.quote(x) for x in g)), env={"HB_BUILD_DIR": BUILD})
            return dict(name="%s %s" % (t, " ".join(g)), status="PASS" if rc == 0 else "FAIL", detail=out.strip()[-300:])
        with cf.ThreadPoolExecutor(max(1, a.jobs // 2)) as ex:
            results["synth"] = list(ex.map(syn, jobs))
        for r in results["synth"]:
            print("synth %-4s %s" % (r["status"], r["name"]))
        failed |= any(r["status"] != "PASS" for r in results["synth"])

    if "sim" in a.groups:
        items = list(SIMS) + soak_items(a.soak_seeds)
        if a.only:
            items = [i for i in items if a.only in i[0]]
        jobs = [(it, 1 + s) for it in items for s in range(a.seeds)]
        t0 = time.time()
        with cf.ThreadPoolExecutor(a.jobs) as ex:
            futs = {ex.submit(run_sim, it, seed): (it, seed) for it, seed in jobs}
            for f in cf.as_completed(futs):
                r = f.result()
                results["sim"].append(r)
                print("sim   %-4s %-22s checks=%-8d errors=%-4d %6.1fs seed=%d" % (r["status"], r["name"], r["checks"], r["errors"], r["secs"], r["seed"]))
                sys.stdout.flush()
        results["sim"].sort(key=lambda r: (r["name"], r["seed"]))
        failed |= any(r["status"] != "PASS" for r in results["sim"])
        print("simulations took %.0fs" % (time.time() - t0))

    json.dump(results, open(os.path.join(BUILD, "reports", "results.json"), "w"), indent=1)
    with open(os.path.join(BUILD, "reports", "summary.md"), "w") as f:
        f.write("# HostBridge regression summary\n\n")
        for g in ("style", "lint", "synth", "sim"):
            if not results[g]:
                continue
            npass = sum(1 for r in results[g] if r["status"] == "PASS")
            f.write("## %s: %d / %d pass\n\n" % (g, npass, len(results[g])))
            for r in results[g]:
                extra = " checks=%d errors=%d seed=%s" % (r["checks"], r["errors"], r["seed"]) if g == "sim" else ""
                f.write("* %s `%s`%s\n" % (r["status"], r["name"], extra))
            f.write("\n")
        tot = sum(r["checks"] for r in results["sim"])
        f.write("Total simulation checks: %d\n" % tot)
        cov = {}
        for r in results["sim"]:
            for k, v in r["cov"].items():
                cov[k] = cov.get(k, 0) + v
        f.write("\n## Functional coverage bins (summed over simulations; a bin with count 0 was declared and never hit)\n\n")
        for k in sorted(cov):
            f.write("* `%s`: %d\n" % (k, cov[k]))
    for g in results:
        for r in results[g]:
            if r["status"] != "PASS":
                print("\n--- FAILED: %s %s\n%s" % (g, r["name"], r.get("detail", "")))
    print("\nOVERALL: %s" % ("FAIL" if failed else "PASS"))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
