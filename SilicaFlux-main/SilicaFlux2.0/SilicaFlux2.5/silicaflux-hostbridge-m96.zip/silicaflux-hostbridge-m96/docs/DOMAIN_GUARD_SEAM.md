# DomainGuard seam — how host-originated requests meet the protection unit

## 1. What "DomainGuard" is in this repository

The task asks for host-originated memory requests to pass through "DomainGuard" before reaching protected memory.
**No module with that name exists in the repository.** The Module 94 audit (`formal/albion`, item `U-DOMAINGUARD`)
recorded exactly that and named the real enforcement points instead:

* Albion's fabric permission stage (`sf_albion_datafabric` + `sf_albion_perm`, P90, a 32-bit non-ALP bus), and
* **Citadel** (P89, ALP v1): `sf_citadel_domain_table`, `sf_citadel_permission`, `sf_citadel_gate`.

HostBridge therefore defines the **contract** a DomainGuard must meet (the `grd_*` check port, below), ships a small
reference implementation of it (`sf_albion_host_domain_guard`) so the demonstration is self-contained, and documents how
Citadel plugs in. The reference guard is **not** Citadel, is not formally verified and makes no security-certification claim.

## 2. The check port (HostBridge side)

Driven by `sf_albion_host_req_path`; the fields are those of the **held** request, never the live input.

| Signal | Dir | Meaning |
|---|---|---|
| `grd_req_valid_o` | out | a request awaits a verdict; high until `grd_rsp_valid_i`; fields stable meanwhile |
| `grd_dom_o` [7:0] | out | claimed domain (from `hreq_dom`) |
| `grd_op_o` [3:0] | out | `SF_OP_READ` / `SF_OP_WRITE` |
| `grd_attr_o` [7:0] | out | ALP attribute byte assigned by the **aperture** (the host cannot choose it) |
| `grd_addr_o` [63:0] | out | first byte, **device address** (after aperture translation) |
| `grd_len_o` [31:0] | out | length in bytes of the **whole request** (1 … 4096) |
| `grd_rsp_valid_i` | in | verdict valid (may equal `grd_req_valid_o` combinationally, or arrive later) |
| `grd_permit_i`, `grd_status_i` [3:0] | in | PERMIT, or an ALP status: `OKAY` is never a denial; any other status becomes the host-visible status through the table in the spec (typically `ACCESS_DENIED` → `SF_HS_DENIED`) |

Guarantees (tested, `tb_hb_guard`, verdict latency 0, 1, 3, 9):

* **No ALP request exists before a PERMIT.** The state that creates ALP requests is reachable only through the verdict;
  a monitor in the testbench checks every ALP word ever issued against an independent policy model (900 random requests,
  zero violations) and counts ALP traffic around denied requests (zero).
* The check is **request-level and atomic**: a request that spans two windows is denied as a whole, so a denied write never
  executes partially. (A beat-level gate behind the bridge cannot give this; see §4.)
* A denied write's data is drained; memory is unchanged (tested by read-back).
* While waiting, the fields do not change and the request is not withdrawn (checked every cycle).
* A cancel that arrives while the verdict is pending is applied after the verdict (the guard protocol is never abandoned
  half-way).

## 3. Plugging Citadel in (specification — **not built and not simulated**)

Citadel's `sf_citadel_permission` is a purely combinational function of (request, table state). Its inputs and the gate's check
port use the same fields as the HostBridge port:

| HostBridge | Citadel (`sf_citadel_permission` input / `sf_citadel_gate` check port) |
|---|---|
| `grd_dom_o` | `dom_i` / `chk_dom_o` |
| `grd_op_o` | `op_i` / `chk_op_o` |
| `grd_attr_o` | `attr_i` / `chk_attr_o` |
| `grd_addr_o` | `addr_i` / `chk_addr_o` |
| `grd_len_o` | `len_i` (`LEN_W = 32`) / `chk_len_o` |
| (constant) | `cls_i = SF_CIT_CLS_ADDR`, `idx_i = 0` |
| (constant) | `src_i` = the physical port index of the host path in Citadel's binding table |
| `grd_rsp_valid_i` | tie to `grd_req_valid_o` (the permission check has `LAT = 0`) |
| `grd_permit_i`, `grd_status_i` | `permit_o`, `status_o` (the requester-visible ALP status: `OKAY`, `BAD_OPCODE`, `BAD_ATTR` or the coarse `ACCESS_DENIED`) |
| (commit) | `chk_commit_i` of the security block = `grd_req_valid_o && grd_rsp_valid_i`, one pulse per request, so each denial is counted once |

What Citadel adds that the reference guard does not have:

* **Port binding.** Citadel binds each physical master port to the set of domain slots it may present (`bind_i`); a request
  that names a domain its port is not bound to is a **spoof** and is denied. This is the correct mitigation for the
  trust caveat on `hreq_dom` (a compromised shim cannot claim ROOT or another tenant's domain). Bind the host port to tenant
  domains only.
* Domain **state** (INVALID / SUSPENDED / ACTIVE / QUARANTINED), privilege / secure capability checks, exclusive windows,
  device and queue classes, safe-state lockdown, fault containment, audit counters, formal proofs (per the Citadel README).
* Privileged **configuration** through a dedicated management port (ROOT/MGMT with the privileged attribute).

Status words: Citadel's coarse status set maps through `sf_hti_status_from_alp` (`ACCESS_DENIED → SF_HS_DENIED`,
`BAD_OPCODE`/`BAD_ATTR → SF_HS_BAD_REQ`).

**Not verified:** no HostBridge simulation has used Citadel's RTL; the port correspondence above was established by
reading `sf_citadel_permission.sv` / `sf_citadel_gate.sv`, not by building them together.

## 4. Defense in depth: a Citadel gate on the ALP link as well

`sf_citadel_gate` can additionally sit on HostBridge's ALP initiator link (its documentation names "host DMA bridge" as an
intended master) and enforces per ALP word. This is a useful second layer, but **not a replacement** for the request-level
check: a beat-level gate sees 16-byte words, so a multi-word write that spans a window edge would have its permitted words
executed before a denied word is rejected. Keep the request-level check for atomicity and add the gate for independence.
(The gate's integration rule: the downstream link is reachable only through the gate; keep HostBridge as its only master.)

## 5. What the reference guard implements (and does not)

`sf_albion_host_domain_guard` — default deny after reset; windows `{valid, domain, base, inclusive limit, read, write}` programmed through a **separate privileged
port** (not reachable from HTI); policy: reserved domain 0xFF denied, bad opcode / attribute / zero length / overflow denied,
ROOT permitted without a window (`ROOT_BYPASS`), otherwise a valid window of the same domain must contain the **whole range**
and grant the right; coarse statuses only (no layout oracle). Missing relative to Citadel: port binding, domain state,
capabilities, exclusivity, lockdown, formal proofs.
In the demonstration SoC the window table is programmed through CSR registers that accept writes only from ROOT or MGMT
with the privileged attribute; a tenant that reaches the register block through a mis-configured window still cannot
program anything privileged (test S2, "defense in depth").
