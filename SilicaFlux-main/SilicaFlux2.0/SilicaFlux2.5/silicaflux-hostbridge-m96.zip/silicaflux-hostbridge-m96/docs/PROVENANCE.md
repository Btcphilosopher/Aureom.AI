# Provenance of vendored files

`third_party/albioncore/` holds **unmodified copies** of nine files of the AlbionCore library (ALP v1, library 0.1.0), taken
from `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/albioncore-0.1.0.zip` of the Aureom.AI repository
(sha256 of the archive: `d79c338783c7fe752c072beddc947e7b74f251c92d9ea655d4b360812b9393f2`). They are vendored so the package builds without the rest of the repository;
nothing was edited. Verify with `(cd third_party && sha256sum -c ../docs/third_party.sha256)`.

| File | Role in HostBridge |
|---|---|
| `rtl/sf_albion_pkg.sv` | ALP v1 types, status codes, legality functions (the fabric protocol of the bridge) |
| `rtl/sf_albion_fifo.sv`, `rtl/sf_albion_skid.sv` | queues and registered stages |
| `rtl/sf_albion_tag_tracker.sv` | ALP tag allocation, outstanding limit, in-order response check |
| `rtl/sf_albion_err_resp.sv`, `rtl/sf_albion_ref_mem.sv`, `rtl/sf_albion_ref_subsystem.sv` | stage-1 SRAM demonstration fabric, error responder, SRAM of the SoC demo |
| `tests/sf_albion_link_checker.sv`, `tests/sf_albion_chan_checker.sv` | ALP protocol monitors bound to every link in the testbenches (testbench-only) |

`scripts/style_check.py` and `scripts/albion_lib.py` are copies of AlbionCore's `tools/albion/build/style_check.py` and
`albion_lib.py` (used here to check the 17 Albion RTL style rules on `rtl/*.sv`).

Everything else in this package (`rtl/sf_albion_host_*.sv`, `tb/`, `scripts/` other than the two above, `docs/`) is new
work for Module 96.

## Reference studied but not copied

`silicaflux-citadel-p89.zip` (`sf_citadel_gate`, `sf_citadel_permission`, `sf_citadel_domain_table`) and
`silicaflux-albionformal-m94.zip` (the audit that records "no module named DomainGuard") were read to define the guard seam;
none of their code is included.
