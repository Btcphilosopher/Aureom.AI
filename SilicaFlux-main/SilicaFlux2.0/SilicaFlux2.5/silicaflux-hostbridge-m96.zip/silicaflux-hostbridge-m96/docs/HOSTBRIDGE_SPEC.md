# HostBridge specification — HTI v1 and the bridge it belongs to

Status: **HTI 1.0 / HostBridge library 0.1.0** (SilicaFlux Module 96). Primary RTL: `rtl/sf_albion_host_bridge.sv`.
Primary source of every constant: `rtl/sf_albion_host_pkg.sv`. Every statement below that says "tested" names the
testbench that exercises it (see [VERIFICATION.md](VERIFICATION.md)).

> **Scope.** HostBridge is a **transaction-level** adapter. It is not a PCIe PHY, data-link layer or transaction layer,
> and nothing here claims PCIe electrical or protocol compliance. It defines a clean host-facing interface (HTI) that a
> thin shim can connect to licensed PCIe endpoint IP ([PCIE_INTEGRATION.md](PCIE_INTEGRATION.md)).

## 1. Where it sits

```
                      host side (HTI)                                         fabric side (ALP v1)
 ┌───────────────────────────────────────────────┐   ┌──────────────────────────────────────────────────────┐
 │ hreq / hw   host -> device requests  ─────────┼──►│ sf_albion_host_req_path ──► ALP initiator m_req/m_rsp │
 │ hcpl        completions of those     ◄────────┼───│   validate, translate, DomainGuard, split, complete   │
 │                                               │   │                                                      │
 │ dreq / dw   device -> host requests  ◄────────┼───│ sf_albion_host_dma_path ◄── DMA client port           │
 │ dcpl        completions of those     ─────────┼──►│   split, tags, out-of-order match, reorder, in order  │
 └───────────────────────────────────────────────┘   │ grd_*  DomainGuard check port   err_evt_*  events     │
                                                     └──────────────────────────────────────────────────────┘
```

Fabric side: an **ALP v1** initiator (`sf_albion_pkg`: 64-bit address, 128-bit word, 8-bit tag, 8-bit domain, in-order,
single-beat, non-posted). AlbionCore's ALP link checker is bound to the bridge's link in every test.

## 2. HTI v1 channels

All channels are valid/ready. A transfer happens at a clock edge where both are high. `valid` and the payload of a
channel driven by the bridge stay stable until accepted (checked by the host model on `dreq`, `dw`, and by the env
on `err_evt`). No `ready` of the bridge depends combinationally on a `valid`.

Widths: address 64, data 128 (one beat = one 16-byte **word**, 16 byte lanes), tag 8, domain 8, host request length 13,
DMA length 24, status 4.

### 2.1 Request kinds (`hreq_kind`, `dreq_kind`)

| Code | Name | Meaning |
|---|---|---|
| 0 | `SF_HK_NONE` | invalid. A request with this kind is completed with `SF_HS_BAD_REQ` and is treated as having **no** write data |
| 1 | `SF_HK_RD` | memory read; answered by a read completion |
| 2 | `SF_HK_WR` | memory write, non-posted; answered by a one-beat write completion |
| 3 | `SF_HK_WRP` | memory write, posted; no completion; a failure is reported as an error event |

### 2.2 Write data convention (used by `hw`, `dma_w`, `dw`)

A request covers the byte span `[addr, addr+len)`. **Beat *k* carries the aligned word at `(addr & ~15) + 16·k`; lane
*j* of the beat is the byte at that word's address + *j*.** The number of beats is always
`nwords = (addr[3:0] + len + 15) >> 4` (0 for `len == 0`), **whether or not the request is legal**, so the bridge can
always drain the data of a rejected write. Every beat carries a byte strobe (`be`, one bit per lane) and `last` on its
final beat.

* The bridge ANDs the host's strobes with the span mask: a strobe set for a lane **outside** the span, or garbage data in
  such a lane, is ignored (tested with "dirty lanes", `cfg_dirty_lanes`).
* A write word whose effective strobe is all zero is **skipped** (ALP forbids `BE == 0`).
* A `last` that disagrees with the beat count is reported as a protocol event (`SF_HS_PROTO`); the beat count itself is
  never changed by it.

### 2.3 Host → device: `hreq` + `hw` → `hcpl`

| Signal | Dir (bridge) | Width | Meaning |
|---|---|---|---|
| `hreq_valid / hreq_ready` | in / out | 1 | request handshake |
| `hreq_kind` | in | 2 | §2.1 |
| `hreq_addr` | in | 64 | byte address of the first byte (host-side address; aperture-translated) |
| `hreq_len` | in | 13 | request length in **bytes**, legal 1 … `MAX_REQ_BYTES` (≤ 4096) |
| `hreq_tag` | in | 8 | host transaction identifier, opaque, echoed on the completion |
| `hreq_dom` | in | 8 | protection domain **assigned by the shim** (see §6, trust) |
| `hw_valid / hw_ready` | in / out | 1 | write data beat handshake (independent of `hreq`: data may precede its request, `cfg_data_first` test) |
| `hw_data / hw_be / hw_last` | in | 128 / 16 / 1 | §2.2 |
| `hcpl_valid / hcpl_ready` | out / in | 1 | completion beat handshake |
| `hcpl_tag` | out | 8 | tag of the request |
| `hcpl_status` | out | 4 | §3; **meaningful on the last beat**, always `SF_HS_OK` on earlier beats |
| `hcpl_data` | out | 128 | read data (lanes outside the span are zero); zero on a write completion and on an error beat |
| `hcpl_last` | out | 1 | last beat of the completion |

**Completion shape.** A successful read completion is exactly `nwords` beats, ending with `hcpl_last`. A successful
non-posted write completion is one beat. A **failed** request ends with **one** error beat (`last = 1`, status ≠ OK,
data zero); beats that preceded it (reads that failed part-way) carry OK data and must be discarded by the host once the
terminator arrives. Completions return **in request order**, including locally generated error completions.

### 2.4 Device → host: `dreq` + `dw` → `dcpl`

| Signal | Dir (bridge) | Width | Meaning |
|---|---|---|---|
| `dreq_valid / dreq_ready` | out / in | 1 | request handshake |
| `dreq_kind` | out | 2 | RD, WR or WRP (never NONE) |
| `dreq_addr` | out | 64 | exact byte address of the first byte |
| `dreq_len` | out | 13 | exact length in bytes, 1 … max(`MPS_BYTES`, `MRRS_BYTES`) |
| `dreq_tag` | out | 8 | request tag, `0 … NUM_TAGS-1` for RD and WR; 0 for WRP |
| `dw_valid / dw_ready`, `dw_data / dw_be / dw_last` | out / in | 1 / 128 / 16 / 1 | write data, §2.2 |
| `dcpl_valid / dcpl_ready` | in / out | 1 | completion beat handshake; `dcpl_ready` is **constant 1** |
| `dcpl_tag` | in | 8 | tag being completed |
| `dcpl_status` | in | 4 | §3; non-OK ends the request |
| `dcpl_data` | in | 128 | read data of one aligned word (the whole span's words are delivered lane-aligned) |
| `dcpl_last` | in | 1 | last beat of the **request** |

Rules the bridge obeys (host-model checkers in every DMA test):

* a request is presented only after the previous write's data was accepted, and a write's data only after its `dreq` was
  accepted; so a shim always sees whole packets, in order;
* no request crosses a `MPS_BYTES` (writes) / `MRRS_BYTES` (reads) boundary, hence none crosses 4 KiB
  (both are powers of two ≤ 4096); interior chunk edges are 16-byte aligned;
* tags of reads and non-posted writes are unique among outstanding ones and `< NUM_TAGS`;
* write strobes never extend outside the request span.

Rules the **host side** must obey (violations are detected, not trusted; tested in D9 / T2):

* completion beats of one tag arrive in address order; beats of different tags may interleave arbitrarily
  (**out-of-order completion across tags is permitted, tested with 1,500+ stream switches**);
* a read completion is exactly the request's words ending with `dcpl_last`, or ends early with a non-OK status;
  a non-posted write is acknowledged by one beat (its status);
* a beat that matches no outstanding tag, a short completion, or extra beats are dropped/flagged (`SF_HS_PROTO`),
  counted in `unexpected_cpl_o`, and never stall the bridge.

### 2.5 DMA client port (device agents → bridge)

`dma_req_*` (valid/ready, `write`, `posted`, `addr` 64, `len` 24 = 1…16 MiB-1, `id` 8), `dma_w_*` (write data, §2.2) and
`dma_r_*` (result stream: `id`, `status`, `is_write`, `data`, `be`, `last`).

* Results return **in request order** (reads and writes together).
* A read yields `nwords` beats with `dma_r_be` marking the span lanes and zero data elsewhere; a failure ends it with one
  error beat. A write yields one beat (`is_write = 1`): non-posted when the host acknowledged every chunk, posted when the
  host side **accepted** the data of every chunk (tested: D10).
* A DMA request is validated before anything is sent to the host: `len == 0` → `BAD_LEN`, `addr + len` beyond 2^64 →
  `BOUNDARY` (a request that ends *exactly* at 2^64 is legal). The write data of a rejected write is drained, one error
  result and one error event are produced, nothing reaches the host (tested: D11).
* A non-OK status carried by a **host completion** (`dcpl_status`) is passed to the client unchanged and logged; the
  codes defined in §3 are tested (D8: UR, CA, POISON, DENIED, BAD_REQ; PROTO and TIMEOUT are produced locally). The
  undefined codes 11-15 are not specified and not tested.
* The bridge splits a request at `MPS_BYTES` / `MRRS_BYTES`; reads are tracked by tag and reassembled in a reorder
  buffer (`NUM_TAGS × MRRS_BYTES/16` words), so the **client never sees out-of-order data**.

## 3. Status codes (`hcpl_status`, `dcpl_status`, `dma_r_status`, `err_evt_code`)

| Code | Name | Meaning | ALP status mapped to it |
|---|---|---|---|
| 0 | `SF_HS_OK` | success | OKAY |
| 1 | `SF_HS_UR` | unsupported request: no aperture / no target | DECODE_ERR |
| 2 | `SF_HS_DENIED` | aperture rights, reserved domain, DomainGuard, or fabric access check | ACCESS_DENIED |
| 3 | `SF_HS_CA` | completer abort: the target failed the access | TARGET_ERR |
| 4 | `SF_HS_POISON` | uncorrectable data error | ECC_UNCORR |
| 5 | `SF_HS_BAD_LEN` | length zero or above `MAX_REQ_BYTES` | — (local) |
| 6 | `SF_HS_BOUNDARY` | crosses a 2^`BOUNDARY_LOG2` boundary, the aperture end, or wraps the address space | — (local) |
| 7 | `SF_HS_ABORTED` | cancelled by `cancel_i` | CANCELLED |
| 8 | `SF_HS_TIMEOUT` | no completion within `CPL_TIMEOUT` | TIMEOUT |
| 9 | `SF_HS_BAD_REQ` | invalid kind, or the fabric rejected the request as malformed | BAD_OPCODE, BAD_BE, ALIGN_ERR, BAD_ATTR |
| 10 | `SF_HS_PROTO` | protocol violation by the other side (rogue / short / extra completion, bad response) | PROTOCOL_ERR, or any non-well-formed response |

The table is checked by an independent copy in `tb_hb_fabric_faults` (F1: all eleven ALP statuses, read and write).

## 4. Host-originated request pipeline

Order of checks (the **first** failing one decides the status; precedence is tested edge by edge in `tb_hb_host_path` P6):

1. `hreq_kind == NONE` → `BAD_REQ`; 2. `len == 0` or `len > MAX_REQ_BYTES` → `BAD_LEN`; 3. `addr + len` wraps 2^64 →
`BOUNDARY`; 4. crosses a `2^BOUNDARY_LOG2` boundary → `BOUNDARY`; 5. `hreq_dom == 0xFF` → `DENIED`;
6. address in no aperture → `UR`; 7. starts in an aperture but does not end in it → `BOUNDARY`; 8. aperture rights
forbid the access → `DENIED`; 9. **DomainGuard** (when `GUARD_EN`) → permit, or `DENIED`; 10. ALP request(s).

A rejected request never reaches the fabric (tested: the ALP request counter does not move). Its write data is drained.

**Apertures** (`NUM_APERT` ≤ 8, parameters `AP_HBASE/AP_SIZE/AP_DBASE/AP_ATTR/AP_PERM`): host range → device base, the ALP
attribute byte (privilege, memory type) the aperture assigns, and read/write rights. **The host cannot choose its own
privilege or memory type**: the attribute is a property of the aperture, not of the request. Host and device base must
have equal low 4 address bits (elaboration check).

**ALP requests.** One per 16-byte word of the span, `be` = span mask ∧ host strobes, tags from `sf_albion_tag_tracker`
(unique, outstanding ≤ `MAX_OUT`, in-order response check). A response that is not well-formed or whose operation flag is
wrong becomes `PROTO`; a response with the wrong tag or an unsolicited response latches `fatal_o` until reset and the
bridge stops issuing (tested: F5, F6).

**Completions** are built from the in-order ALP responses (§2.3). First error wins for writes; a read ends at its first
failing word and the rest of its responses are drained.

## 5. Reset and cancellation

| | Contract | Tested |
|---|---|---|
| `rst_ni` (hard) | asynchronous assert, integrator-synchronized release. Every queue, tag and outstanding request is discarded; **no completion is ever produced for a pre-reset request**; no `valid` is high while reset is low. | `tb_hb_cancel_reset` R: 40 resets at random sub-cycle offsets; 14 hit the host path busy, 39 the DMA path busy, 13 with ALP words outstanding, 13 mid-packet |
| `cancel_i` (soft, one pulse) | Requests **accepted no later than the cycle of the pulse** that have not finished issuing end `ABORTED` (non-posted) or are dropped with an event (posted). ALP words already issued cannot be recalled (ALP-CAN-01): their responses are consumed; a request that had fully issued completes normally. **DMA tags are all abandoned**: the client gets `ABORTED` at once; a tag stays busy until its late host completion arrives (data dropped) and is then reused, so stale data can never be matched to a new request. A write chunk being streamed ends with all strobes cleared. | C1 … C7 |
| `CPL_TIMEOUT > 0` | A tag without completion after `CPL_TIMEOUT` cycles is abandoned with `TIMEOUT`; after a second period it is released even if no completion ever arrives. | `tb_hb_dma_timeout` |

## 6. Security

* **DomainGuard check port** (`grd_*`): offered once per host request with the **translated device range**, the
  aperture-assigned attribute and the domain, *before* any ALP request exists. The fields stay stable until the verdict
  (tested with verdict latencies 0 … 9, `tb_hb_guard` G4). There is no other path to the fabric; the test monitor checks that
  every ALP word ever issued is permitted by an independent policy model (G3, 900 random requests).
  The check port mirrors Citadel's `chk_*` port; see [DOMAIN_GUARD_SEAM.md](DOMAIN_GUARD_SEAM.md). **No module literally named
  DomainGuard existed in the repository** (the Module 94 audit says so): `sf_albion_host_domain_guard` is a small reference
  implementation of the contract, not Citadel and not a certified security block.
* **Trust.** `hreq_dom` is only as trustworthy as the shim that drives it (it derives it from the requester identity or
  BAR). A compromised shim can claim any domain; Citadel's per-port domain binding is the mitigation and the reference guard
  does **not** implement it. The reference guard additionally lets domain ROOT bypass its windows (bootstrap); the shim must
  never map a host function to ROOT.
* The aperture attribute (§4) prevents a host from claiming privilege; the CSR demo block adds a second rule
  (privileged registers need ROOT/MGMT **and** the privileged attribute), proven by "defense in depth" S2.
* Status codes distinguish UR from DENIED; if layout leakage matters, collapse them in the shim.

## 7. Error events

`err_evt_*` (valid/ready, payload stable while stalled): `{src[1:0], code[3:0], tag[7:0], addr[63:0]}`, `src`: 0 host
path, 1 DMA path. One event per rejected request, per failing posted write, per client-visible DMA failure (not per
failing chunk), per protocol violation and on `fatal_o`. A deliberate cancel of a non-posted request is not an error and
is not logged. **No event is lost**: lower-priority writers wait; a stalled consumer back-pressures the request path
(tested M3/M3b: 50 + 24 events through a stalled consumer, in order, with correct tag and address). Beats that match no tag
are the one lossy source (coalesced; the exact count is in `unexpected_cpl_o`).

## 8. Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `REQ_Q_DEPTH`, `WDATA_Q_DEPTH`, `EVT_Q_DEPTH` | 4, 16, 4 | queues |
| `MAX_OUT` | 8 | outstanding ALP words (1 … 256) |
| `MAX_REQ_BYTES`, `BOUNDARY_LOG2` | 4096, 12 | legal host request length; boundary rule |
| `NUM_APERT`, `AP_*` | 2 | apertures |
| `GUARD_EN` | 1 | route host requests through the guard check port |
| `NUM_TAGS` | 8 | outstanding host-bound requests (1 … 64) |
| `MPS_BYTES`, `MRRS_BYTES` | 256 | host write / read chunk size (powers of two; MRRS ≥ 32); **must not exceed what the PCIe link negotiates** |
| `DMA_REQ_Q_DEPTH`, `DMA_WDATA_Q_DEPTH`, `CK_Q_DEPTH` | 4, 16, 12 | DMA queues (`CK_Q_DEPTH ≥ NUM_TAGS + 2`) |
| `CPL_TIMEOUT` | 0 | completion timeout in cycles (0 = off) |

Elaboration checks (`gen_param_check_*`, `$error`) reject illegal values; the synthesis script proves they fire.

## 9. Demonstration register map (`sf_albion_host_csr`)

32-bit registers, 4-byte stride, 16 bytes per ALP word; offsets inside the CSR window.

| Offset | Name | Access | Content |
|---|---|---|---|
| 0x000 | ID | RO | `0x48420096` |
| 0x004 | VERSION | RO | `{0, major, minor, patch}` |
| 0x008 | CAPS | RO | `{NUM_TAGS, MAX_OUT, guard_en, 0}` |
| 0x00C | SCRATCH | RW | |
| 0x010 | CONTROL | W, privileged | bit0 cancel, bit1 clear error log |
| 0x014 | STATUS | RO | host_busy, dma_busy, fatal, engine busy |
| 0x018 / 0x01C | OUT_HOST / OUT_DMA | RO | outstanding ALP words / DMA tags |
| 0x020 … 0x02C | ERR_COUNT, ERR_INFO, ERR_ALO, ERR_AHI | RO | error log (first event kept) |
| 0x030 | UNEXP_CPL | RO | dropped host completion beats |
| 0x040 … 0x054 | DMA_SRC_LO/HI, DMA_DST_LO/HI, DMA_LEN, DMA_CTRL | RW, privileged | engine programming; CTRL bit0 start, bit1 dir (1 = SRAM→host), bit2 posted |
| 0x058 / 0x05C | DMA_STATUS / DMA_BYTES | RO | bit0 busy, bit1 done, [7:4] HTI status |
| 0x100 + 0x20·i | guard window i | RW, privileged (read and write) | BASE_LO/HI, LIMIT_LO/HI, ATTR `{dom[15:8], wr[2], rd[1], valid[0]}`; writing ATTR commits |

## 10. What is not specified or claimed

See [LIMITATIONS.md](LIMITATIONS.md). In particular: no PCIe compliance of any kind, no timing/area/power figure, no
atomics, no ATS/PASID, static MPS/MRRS, completions of host requests in request order only.
