# Limitations and non-claims

Read this before relying on anything else in the package.

## Not claimed

* **No PCIe compliance of any kind**: electrical, protocol, interoperability, or compatibility with a specific vendor's
  endpoint IP. HostBridge is a transaction-level adapter; no TLP was generated, parsed or simulated. The integration seam is
  specified, not built ([PCIE_INTEGRATION.md](PCIE_INTEGRATION.md)).
* **No timing, area, power, frequency or throughput figure.** The Yosys runs are elaboration and latch checks on generic
  cells; cell counts are not reported as results. Simulation is cycle-based and two-state (Verilator): metastability and X
  propagation are not modelled. There is no clock-domain crossing in the design (single clock).
* **No security certification.** The reference DomainGuard is a small default-deny window checker, not Citadel, and
  carries no proof. See [DOMAIN_GUARD_SEAM.md](DOMAIN_GUARD_SEAM.md).
* **No formal verification** of HostBridge. Evidence is simulation, protocol assertions of AlbionCore's link checker, a
  mutation campaign and a synthesis (latch) check.
* The Module 94 / Citadel / AlbionCore results are not re-claimed; AlbionCore files are used **unmodified** (checksums in
  `docs/PROVENANCE.md`).

## Design limitations (known, deliberate or deferred)

1. **Static `MPS_BYTES` / `MRRS_BYTES`.** They must not exceed what the link negotiates; there is no dynamic update.
2. **Host completions in request order only.** Out-of-order completion is supported where PCIe allows it most naturally,
   on the *host → device completion* path (`dcpl`, across tags); the completions of host-originated requests (`hcpl`) are
   returned in request order, because ALP v1 is in order. Error completions do not bypass older reads.
3. **Store-and-forward reads on the DMA path.** A read chunk is delivered after it fully arrived (reorder buffer of
   `NUM_TAGS × MRRS_BYTES` bytes); there is no cut-through.
4. **One DomainGuard query at a time**, serial with request splitting; throughput under a slow guard is limited.
5. **Reads cannot express byte-enable holes**; the shim must zero disabled bytes (PCIE_INTEGRATION §2.1). Writes can.
6. **No poison bit on write data**, no ECC on the host side, no TLP digest/prefix/attribute propagation (no relaxed or
   ID-based ordering, no traffic classes, no ATS/PASID, no atomics — ALP v1 has none).
7. **Tag reclamation after a missing completion** needs `CPL_TIMEOUT > 0` (second period) or a reset; with it disabled an
   abandoned tag whose completion never comes stays busy.
8. **`unexpected_cpl_o` and the coalesced PROTO event** are the only lossy diagnostics (counts are exact).
9. **The demonstration pieces** (CSR block, DMA engine, arbiter with alternating turn → at most one request per initiator
   every other cycle, fabric) are demonstration quality. The DMA engine needs 16-byte aligned addresses and lengths and
   handles one transfer at a time.
10. **Trust in `hreq_dom`** and the ROOT bypass of the reference guard (see the security section of the spec).
11. **Reset release is the integrator's** (asynchronous assert, synchronous release): HostBridge contains no reset synchronizer.
12. The `sf_albion_ref_mem` used as the demonstration SRAM clears itself for `WORDS` cycles after every reset and is not ready
    meanwhile; this is a property of the reused component.

## Tool findings worth knowing

* **Yosys 0.33 segfaults** (not an error message) on a bit-select of a packed-struct *member* using a *package-scoped* index
  (`req.attr[sf_albion_pkg::SF_ATTR_PRIV_BIT]`). Found when `sf_albion_host_csr` crashed the front end; worked around by
  selecting the bit from a plain vector copy (commented in the RTL). Not previously listed in AlbionCore's tool-compatibility table.
* Verilator `--timing`: a timed process that drives a signal with `@(posedge clk)` races with `always @(posedge clk)`
  monitors; all stimulus is driven on the falling edge (AlbionCore's house rule) and the BFMs follow it.
