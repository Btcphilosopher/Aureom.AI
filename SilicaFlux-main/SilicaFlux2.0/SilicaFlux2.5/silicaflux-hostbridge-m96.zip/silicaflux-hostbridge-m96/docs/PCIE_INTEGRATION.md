# Connecting HostBridge to third-party PCIe endpoint IP — the integration seam

> **What this document is.** The specification of a **shim** (the block you write, or generate, between licensed PCIe
> endpoint IP and HostBridge) and the list of obligations that make HostBridge's tested guarantees carry over to a real
> link.
>
> **What it is not.** HostBridge contains no SERDES, PHY, equalization, link training, data-link layer, flow-control
> credits, replay buffer or LTSSM, and **nothing in this repository claims PCIe electrical, protocol or interoperability
> compliance, or compatibility with any specific vendor's IP.** No shim is provided or has been simulated. Everything
> below is a design specification for work that remains to be done and verified. Statements about PCIe follow the
> general PCIe model; **confirm every field, rule and number against the PCI-SIG Base Specification revision you target
> and against the product guide of the IP you license** — interface names, widths, alignment modes and sideband signals differ between
> vendors and generations.

## 1. The seam in one picture

```
   PCIe link (PHY, data link, flow control)         ── provided by the licensed / FPGA hard IP, not by this repo
   ┌───────────────────────────────────────────┐
   │  PCIe endpoint IP                          │   application side, typically four streams:
   │   completer request     (host reads/writes our BARs)             ──► shim ─► hreq / hw
   │   completer completion  (we answer host reads)                   ◄── shim ◄─ hcpl
   │   requester request     (we read/write host memory)              ◄── shim ◄─ dreq / dw
   │   requester completion  (host answers our reads)                 ──► shim ─► dcpl
   │   configuration / status sideband (MPS, MRRS, BME, FLR, link up, error reporting)
   └───────────────────────────────────────────┘
                         │  your shim: header decode / encode, alignment, tag tables, completion packetizer,
                         │  width + clock-domain conversion, reset mapping
   ┌───────────────────────────────────────────┐
   │  HostBridge  (HTI v1: hreq hw hcpl │ dreq dw dcpl │ cancel_i rst_ni │ err_evt_*)
   └───────────────────────────────────────────┘
```

Vendors name the four application streams differently and some present whole TLPs on an AXI4-Stream/Avalon-ST bus
while others pre-decode headers. HTI is the level **after header decode**: addresses, lengths, byte strobes, tags,
status. A second, quicker route exists for bring-up: use the IP's AXI4 memory-mapped *bridge* mode and write an
AXI4↔HTI adapter (also not provided); you then give up TLP-level control (completion splitting, tags, error status
fidelity) and the `hreq_dom` source below becomes your IP's master-ID.

## 2. Direction 1 — host to device (completer side): `hreq` / `hw` / `hcpl`

### 2.1 Request: TLP → `hreq` + `hw`

| HTI field | Derived from | Notes for the shim |
|---|---|---|
| `hreq_kind` | TLP type | memory read → `RD (1)`; memory write → `WRP (3)` **always** (PCIe memory writes are posted). `WR (2)` (acknowledged write) is for internal users and is **not** produced from a PCIe memory write. I/O and configuration requests are handled by the endpoint IP, not by HostBridge. |
| `hreq_addr` | address field | 32- or 64-bit; the endpoint IP's BAR decode gives the BAR index and offset. HostBridge expects a **flat host-side address**; you choose it (e.g. `BAR_base_i + offset`) and configure `AP_HBASE/AP_SIZE` to match. |
| `hreq_len` | length (DWORDs) | HTI counts **bytes**. Convert, then trim by the byte enables below. Length field value 0 encodes 1024 DW in PCIe; map it to 4096 bytes. Keep `MAX_REQ_BYTES ≤` the largest request your link can deliver (MPS for writes, up to 4096). |
| byte span | first/last DW byte enables | `addr_byte = {addr[..:2], 2'b00} + lowest enabled byte of the first DW`; last byte from the last DW's enables (for a 1-DW request use the first-DW enables only). HTI expresses **any** strobe pattern on write beats. A read span is contiguous: if a (legal, short) read has holes in its byte enables, the bridge reads the whole span and **you must zero the disabled bytes** in the completion payload. |
| `hreq_tag` | **your** table index | HostBridge returns this 8-bit value on the completion. Store `{requester ID, TLP tag, traffic class, attributes, original low address bits, byte count info}` in a table indexed by it and use the entry to build the completion header. Posted writes need no entry (no completion) but their *errors* come back as events (below). Up to 256 entries; completions return in request order, so a simple circular allocator works. |
| `hreq_dom` | requester ID / function (PF, VF) / BAR | **A trust anchor.** Map physical function and virtual function numbers to the protection domain space of `sf_albion_pkg` (0x00 root, 0x01 management, 0x02 DMA, 0x10…0xFE tenants). Never derive it from payload data, and never map a host function to ROOT (the reference DomainGuard lets ROOT bypass its windows). See [DOMAIN_GUARD_SEAM.md](DOMAIN_GUARD_SEAM.md). |
| `hw_data / hw_be / hw_last` | payload | **Realign.** The TLP payload is a DW-aligned byte stream starting at the (DW-aligned) address; HTI beat *k* is the 16-byte word at `(addr & ~15) + 16·k`, lane *j* = byte *j* of that word. Place the first DW at lane `addr[3:2]·4`, and set strobes from the first/last DW byte enables (all-ones in between). A barrel shifter of at most 12 bytes does it. Beat count = `((addr[3:0] + len + 15) >> 4)`. |
| flow control | `hreq_ready`, `hw_ready` | back-pressure maps to the IP's `tready`; the IP handles credits. `hw` may be presented before or after `hreq` (both tested), but **every accepted write request must eventually receive all its beats**. |

PCIe-level checks that belong to the **shim**, not to HostBridge (HostBridge only sees well-formed HTI): malformed TLPs
(length/byte-enable inconsistencies, 4 KiB crossing — HostBridge also rejects it with `BOUNDARY`), unsupported types,
ECRC, poisoned write payload (`EP = 1`: HTI write beats have **no poison bit** — drop the write and report it, do not
forward the data).

### 2.2 Completion: `hcpl` → completion TLP(s)

HostBridge returns one **stream of beats per request**, in request order, status valid on the last beat
([HOSTBRIDGE_SPEC.md §2.3](HOSTBRIDGE_SPEC.md)). The shim must:

1. look up the table entry by `hcpl_tag`;
2. **packetize** a successful read into completions with data (split at the Read Completion Boundary / MPS your link
   uses; compute *byte count* (bytes remaining, including this packet) and *lower address* for each packet from the
   saved low address bits and the length); gather HTI beats into the packet payload, **dropping the leading unused lanes** of
   the first beat (the inverse of the request-side alignment);
3. on a non-OK **last beat**, discard any data already received for that tag and send **one completion without data**
   with the status below;
4. never answer a posted write; log its failure as an error message instead (error events, §5).

| `hcpl_status` | Suggested PCIe completion status | Comment |
|---|---|---|
| `OK` | Successful Completion | |
| `UR`, `DENIED`, `BAD_REQ` | Unsupported Request | `DENIED` vs `UR` distinction is information a host should not necessarily see (no layout oracle): collapse them here if that matters |
| `CA`, `TIMEOUT`, `PROTO` | Completer Abort | |
| `POISON` | Successful Completion with the poisoned (EP) bit set, or Completer Abort | policy choice |
| `BAD_LEN`, `BOUNDARY` | Unsupported Request | these indicate the shim should have rejected the TLP as malformed first |
| `ABORTED` | none | only produced after `cancel_i`; the host usually no longer expects it (FLR) |

Suggested treatment, **not verified here**: these mappings follow the usual meaning of the PCIe status codes; check them
against the Base Specification and the IP's behaviour.

## 3. Direction 2 — device to host (requester side): `dreq` / `dw` / `dcpl`

### 3.1 Request: `dreq` + `dw` → TLP(s)

| HTI field | Becomes | Notes |
|---|---|---|
| `dreq_kind` | memory read request / memory write request | `RD → MRd` (non-posted), `WRP → MWr` (posted). `WR` (non-posted write with acknowledgement) has **no PCIe memory-write equivalent**: configure the DMA path to use only posted writes (`dma_req_posted = 1`) with a PCIe link. |
| `dreq_addr`, `dreq_len` | address, length, first/last DW byte enables | already split by HostBridge: never above `MPS_BYTES` (writes) / `MRRS_BYTES` (reads), **never crossing 4 KiB**. The shim converts byte span → DW address + DW length + byte enables (partial first/last DW). **`MPS_BYTES` and `MRRS_BYTES` are static parameters and must not exceed the values negotiated on the link** (device-control MPS / MRRS, which the host may lower at enumeration): set them to the smallest value the host can negotiate, or gate the DMA path until configuration is known. Reconsider if you need them dynamic: that is a limitation, [LIMITATIONS.md](LIMITATIONS.md). |
| `dreq_tag` | requester tag | `0 … NUM_TAGS-1` for reads; keep `NUM_TAGS ≤` the number of tags your IP/link allows (8-bit extended tags need to be enabled on both sides; confirm). Writes need no tag. |
| address space | bus / IO virtual address | `dma_req_addr` is a **bus address**. IOMMU translation, ATS and address-type attributes are host-side and **not modelled** here; PASID is not carried. |
| `dw_data / dw_be / dw_last` | payload | beats are aligned like `hw` (§2.1): serialize into a DW-aligned payload starting at the first enabled DW; the strobes of the first and last beat become the first/last DW byte enables (**HTI strobes may be sparse in the middle; if your link only allows contiguous enables for larger payloads, the DMA client must not generate holes**). |
| ordering | request order | requests and write data leave in order; a request is presented only after the previous write's data was accepted, so the shim can treat `dreq`+`dw` as whole packets. Relaxed-ordering and ID-based-ordering attributes are **not** produced. |

### 3.2 Completion: completion TLP(s) → `dcpl`

For each received completion TLP, look up the request by tag and emit **one `dcpl` beat per aligned 16-byte word**:

* `dcpl_tag` = the request tag; `dcpl_data` = the word, with the payload **placed at its lane position** relative to
  the original request address (the bridge discards lanes outside the request span itself, so unused lanes may hold anything);
* the words of one tag must arrive **in address order**; beats of different tags may interleave arbitrarily — HostBridge
  reassembles them (this is what the out-of-order tests exercise);
* `dcpl_last = 1` on the final word of the **request** (byte count reaches zero), not of each TLP;
* a completion with status UR / CA / unsupported: one beat with the matching status (`UR`, `CA`) and `dcpl_last = 1`;
  a completion with EP set: status `POISON`; a TLP whose tag matches no outstanding request: still present it (HostBridge
  drops and counts it), or drop it in the shim and report an unexpected completion;
* **completion timeout**: either use the IP's timeout, or set `CPL_TIMEOUT` (cycles). A late completion for a timed-out tag
  is dropped by the bridge (tested).

`dcpl_ready` is constant 1: never wait for it.

## 4. Clocks, reset, width

| Topic | What to do |
|---|---|
| Clock | HostBridge is single-clock (`clk_i`). The PCIe application clock is generated by the IP; use it directly or cross with AlbionCore's `sf_albion_async_fifo` / `sf_albion_cdc_*` (not used or tested in this repository). |
| Width | HTI is 128 bits. Endpoint application interfaces commonly offer 64/128/256/512 bits: convert in the shim (serialize/deserialize beats); alignment is the shim's job (§2.1). |
| Reset | map `rst_ni` to the IP's user reset / link-up (deassert synchronously, ≥ 1 cycle after the PCIe clock is stable). Map function-level reset (FLR) to `cancel_i` (soft: ongoing writes finish, reads are abandoned) **and/or** to `rst_ni` (hard) according to your recovery policy; after a hard reset nothing is produced for pre-reset requests. |
| Bus mastering | the DMA path must be held idle (no `dma_req_valid`) until the host enabled bus mastering; the bridge does not know about it. |
| Interrupts | not present. MSI/MSI-X is a posted write: issue it as a 4-byte DMA write from a client. |

## 5. Errors

Connect `err_evt_*` (`src`, `code`, `tag`, `addr`) to the IP's error-reporting sideband **if it has one**, or to a CSR log
(the demonstration `sf_albion_host_csr` shows one). Suggested use, **unverified**: UR/DENIED/BAD_REQ/BOUNDARY/BAD_LEN on
a posted write → non-fatal error message; PROTO / fatal (`fatal_o`) → fatal error and a reset request.

## 6. The shim's obligations (checklist)

HostBridge's guarantees hold on a real link if and only if the shim satisfies these. Each one is exactly what the host
bus-functional model enforces on the **bridge** side and relies on on the **host** side, so the same model, extended to
emit/consume TLPs, is the natural reference for shim verification.

| # | Obligation |
|---|---|
| S-01 | Every accepted write request (`hreq_valid && hreq_ready`) is followed by exactly `nwords` `hw` beats, with `hw_last` on the last. |
| S-02 | `hreq_dom` comes from the requester identity or BAR, never from untrusted payload; never ROOT for a host function. |
| S-03 | `hreq_tag` values are unique among requests that expect a completion and are echoed to the right requester ID / tag / traffic class. |
| S-04 | `hreq_len ≥ 1`, ≤ 4096, never crossing 4 KiB; the byte span matches the byte enables. |
| S-05 | Posted memory writes → `WRP`; reads → `RD`; nothing else enters `hreq`. |
| S-06 | Completions are packetized per the link's boundary / MPS rules with correct byte count and lower address; failed requests get exactly one completion without data. |
| S-07 | `dreq` TLPs respect the **negotiated** MPS / MRRS, tag limits, and 4 KiB rule; `MPS_BYTES` / `MRRS_BYTES` ≤ the negotiated values. |
| S-08 | Beats of `dcpl` for one tag are in address order, word-aligned, with `dcpl_last` on the final word of the request; status on the last beat. |
| S-09 | `dcpl` is never back-pressured (`dcpl_ready` is constant 1) and never presents a beat before the request was accepted. |
| S-10 | `rst_ni` / `cancel_i` follow the reset policy of §4; DMA is idle before bus mastering is enabled. |
| S-11 | A poisoned or malformed inbound write is not forwarded as data. |

## 7. What is not verified at this seam (all of it)

* no shim exists; no TLP was generated or parsed; no PCIe IP or simulation model of one was used;
* ordering rules of the PCIe model (posted/non-posted/completion ordering, relaxed ordering, ID-based ordering), flow-control
  credit behaviour, completion-timeout interaction, ATS/PRI/PASID, AER, SR-IOV, hot reset, power management;
* dynamic MPS/MRRS, 10-bit tags, non-contiguous byte-enable corner cases, zero-length reads, AtomicOps (HostBridge/ALP v1
  have no atomics), TLP prefixes, multiple traffic classes / virtual channels.
Each of these is future work; none is claimed.

## 8. How to bring it up in practice (suggested sequence)

1. Write the shim against §2–§4 and verify it **alone** against the host bus-functional model (`tb/sf_hti_host_bfm.sv`),
   extended to speak TLPs on the IP side; the obligations in §6 are the assertions.
2. Put the shim between the IP's vendor simulation model and `sf_albion_host_soc_demo`; run the register / SRAM / DMA flows of
   `tb_hb_system` through a host model of the vendor (root-complex model).
3. Re-run HostBridge's own regression (`make all`) with the same parameter values (`NUM_TAGS`, `MPS_BYTES`, `MRRS_BYTES`,
   `MAX_OUT`) you chose for the link.
4. Only then consider interoperability testing on hardware. This repository claims nothing about that step.
