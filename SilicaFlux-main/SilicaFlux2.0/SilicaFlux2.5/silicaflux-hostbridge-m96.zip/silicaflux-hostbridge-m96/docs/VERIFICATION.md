# Verification — what was run, what it shows, what it does not show

Every number in this file was produced by the scripts in `scripts/` on the files in this package (final regression and
final mutation campaign, run after the last edit of any RTL or testbench file). Re-create them with `make all` and
`make mutants`. **Nothing here is a timing, area, power or PCIe-compliance result** — see [LIMITATIONS.md](LIMITATIONS.md).

## 1. Summary

| Check | Result |
|---|---|
| Repository style rules (17 AlbionCore RTL rules, `rtl/*.sv`) | OK, 10 files |
| Verilator `-Wall` lint, warnings fatal | 15 / 15 pass (9 tops + 6 parameter variants) |
| Yosys 0.33 elaboration + generic synthesis, zero-latch check | 16 / 16 pass (9 tops + 7 parameter variants) |
| Self-checking simulations (Verilator 5.020, `--timing`) | **31 / 31 pass, 2,966,277 checks, 0 errors** |
| Mutation campaign | 58 mutants: **56 killed, 0 survivors, 0 build failures, 2 flagged equivalent** (§4) |
| Coverage bins (59 declared, summed over the 31 runs) | every reachable bin hit; the 10 un-hit bins are the undefined status codes 11-15 on `hcpl` / `dma_r` (§5) |

Not done, on purpose: formal verification, gate-level or post-synthesis simulation, FPGA or silicon bring-up, any PCIe
shim (specified in [PCIE_INTEGRATION.md](PCIE_INTEGRATION.md), not built), multi-clock or X-propagation analysis.

## 2. How to run

```bash
make all          # style + lint + synth + every simulation        (about 4-5 min on 4 cores)
make sim-quick    # smoke + host_path + system only
make seeds        # every simulation with 3 simulator seeds (random initial state differs per seed)
make mutants      # the mutation campaign (slow; see §4)
python3 scripts/run_all.py sim --only guard     # a subset
scripts/sim.sh tb_hb_dma -GNUM_TAGS=3 -GMPS_BYTES=16 -GMRRS_BYTES=32   # one testbench, one configuration
```

Results land in `build/reports/` (`results.json`, `summary.md`); each simulation keeps its own `run.log`. Every
simulation must print exactly one `HB_TB_RESULT <tb> PASS checks=<n> errors=<n>` line and exit 0; the runner rejects
anything else (including a missing result line). `+hb_failfast` stops at the first failed check. Simulations are
deterministic: the stimulus PRNG is seeded from the testbench, and Verilator runs with `+verilator+rand+reset+2`
(random initial state) and `+verilator+seed+<n>`.

Tools: Verilator 5.020, Yosys 0.33, Python 3, GNU make, g++.

## 3. Test inventory

All hosts, memories and clients are bus-functional models in `tb/`; the DUT is driven only through its ports.

### 3.1 Environments and models

| File | Role |
|---|---|
| `tb/sf_hti_host_bfm.sv` | **Host BFM** on all four HTI channels. *Requester*: drives `hreq`/`hw`, checks every completion against a reference model of device memory (tag, beat count, status on the last beat, zero data on error). *Completer* (plays host memory): applies DMA writes with byte strobes, answers reads / non-posted writes with configurable latency, beat-level interleaving across tags (out-of-order across tags, in order within a tag), error windows (immediate / after N beats / silent) and rogue beats. *Checker*: payload stability, tag uniqueness, chunk length and 4 KiB limits, write-data ownership, strobes inside the span |
| `tb/sf_hb_dma_client_bfm.sv` | DMA client: queues requests, drives data with dirty lanes, checks every result (order, shape, status, data, byte enables) against a shadow of host memory; understands a cancel race (`exp_status = 255`) and verifies that an ABORTED request is covered by a cancel pulse |
| `tb/hb_env_sram.sv` | Stage 1, SRAM-backed demonstration: bridge + AlbionCore reference subsystem (SRAM + error responder) + optional reference DomainGuard; ALP link checker bound to the bridge's link; event logger with `expect_evt` / `expect_no_evt`; SRAM backdoor |
| `tb/hb_env_soc.sv` | Stage 2, the demonstration SoC (`sf_albion_host_soc_demo`: bridge + guard + CSR block + DMA engine + ALP arbiter + fabric + SRAM); link checkers on four ALP links |
| `tb/sf_hb_alp_corrupt.sv` | Response fault injector on the ALP link (status replace, tag corruption, wrong operation flag, non-well-formed response) |
| `tb/sf_hb_tb_pkg.sv` | PRNG, check counters, coverage bins, shared host-memory byte pattern |
| `third_party/albioncore/tests/` | AlbionCore ALP link / channel checkers (unmodified), bound to every link: ALP-REQ/RSP/TAG/ORD/OUT/RST rules are asserted continuously in every simulation |

### 3.2 Testbenches (31 simulations)

| Simulation(s) | Testbench | What it exercises | Checks |
|---|---|---|---|
| `smoke` | `tb_hb_smoke` | first light: a few directed host reads / writes through stage 1 | 55 |
| `dma_smoke` | `tb_hb_dma_smoke` | first light of the DMA path | 2,606 |
| `host_path`, `host_path_ap6k` | `tb_hb_host_path` | **MMIO / memory reads and writes.** P1 idle; P2 every size × every offset incl. word straddles; P3 exhaustive offset × length sweep; P4 byte-strobe holes; P5 bursts up to 4 KiB; **P6 address-boundary cases** (4 KiB edges, aperture edges, wrap, zero / too long, bad kind, reserved domain, check precedence, exact status *and* event, rejected requests never reach the fabric); P7 posted writes keep order, failing posted write = event; P8 data before request, dirty lanes, all channels throttled; P9 whole-SRAM write + read-back; backdoor compare of the SRAM against the reference model. `_ap6k` puts the aperture end off a 4 KiB boundary | 31,835 / 27,139 |
| `dma_t8_256_256`, `dma_t1_256_256`, `dma_t2_64_64`, `dma_t3_16_32`, `dma_t5_128_512`, `dma_t16_4096_4096`, `dma_t64_256_256` | `tb_hb_dma` (parameters: tags / MPS / MRRS) | **DMA round trips and tag management.** D1 read sweep (16 offsets × 22 lengths); D2 write sweep, with and without strobe holes, then read back; D3 4 KiB crossings; D4 tag-pool exhaustion (pool must saturate, nothing lost); **D5 out-of-order completions** (random interleaving across tags, > 1,000 stream switches); D6 forced reordering (oldest answered last, client still sees request order); **D7 back-pressure on every channel**; **D8 host fault responses** (UR, CA, POISON, DENIED, BAD_REQ; error after N beats; middle chunk of a multi-chunk read fails; non-posted write acknowledged with error); D9 rogue completions (unknown tag, short, extra beats → PROTO); D10 posted write complete only after the host side accepted its data; **D11 invalid DMA requests** (zero length, address-space wrap, requests ending exactly at 2^64) | 161k - 913k each |
| `dma_timeout` | `tb_hb_dma_timeout` | completion timeout: silent read / write, tag abandoned after one period and released after the second, late completion dropped, slow-but-in-time is not a timeout, middle chunk silent | 5,735 |
| `cancel_reset` | `tb_hb_cancel_reset` | **Cancel and reset during traffic.** C1 front end stuck on write data; C1b / C1c cancelled posted writes are logged (they have no completion); **C1d `cancel_i` in the very cycle a request is accepted: that request is ABORTED, the next one must complete normally** (directed, repeated 6 times); C2 cancel mid-request; C3 host-path cancel storm (exactly one completion per request, OK or ABORTED only); C4-C7 DMA cancel (tags abandoned, late completions dropped, tags not reused early, strobes cleared on the streaming chunk, queued requests without data); R1.. **hard reset at random moments** (40 iterations, asynchronous assert, random traffic and throttling on both paths): outputs idle and outstanding counters zero right after reset, no completion of a pre-reset request ever reaches the host or the client, no stale event, and fresh exactly-checked traffic works afterwards; the storm must hit the bridge busy with ALP words and DMA tags outstanding (coverage-checked) | 103,318 |
| `guard_lat0/1/3/9` | `tb_hb_guard` | **DomainGuard.** G0 default deny; G1 guard is shown the translated device range, the aperture-assigned attribute and the host's domain, stable while pending; G2 window table semantics (rights, domain, edges, touching windows); G3 independent policy model predicts every verdict of a random storm (status, memory effect, number of ALP words) while a monitor proves every ALP word issued was permitted; G4 verdict latency 0 / 1 / 3 / 9 cycles changes nothing; G5 revocation; G6 no layout oracle ("someone else's memory" and "nothing mapped" return the same status); G7 the guard's verdict status is mapped to the host-visible status (an OKAY verdict without a permit is never a grant) | 19.7k - 25.4k |
| `fabric_faults` | `tb_hb_fabric_faults` | **Fault responses from the fabric.** F1 all eleven ALP statuses → documented HTI status (independent table), read and write; F2 read failing at word 0 / middle / last; F3 write reports its FIRST error; F4 failing posted write = event; F5 non-conforming responses → PROTO; F6 wrong response tag latches `fatal`, bridge stops issuing, reset recovers; F7 randomized fault storm | 17,240 |
| `perm` | `tb_hb_perm` | aperture read / write rights (read-only and write-only apertures) | 61 |
| `csr_unit` | `tb_hb_csr` | CSR block driven directly over ALP: every domain × privilege × register class, mixed-rights word denied as a whole, legality precedence, byte lanes, guard window commit, DMA registers, error log | 588 |
| `multi_out1/2/8/32` | `tb_hb_multi` | **Multiple outstanding transactions:** M1 outstanding limit reached, never exceeded; M2 `hreq_ready` / `hw_ready` really drop when full, nothing lost, order kept; M3 stalled event consumer loses no event; M4 mixed random traffic under random throttling | 17.9k - 19.6k |
| `soak_s1..s6` | `tb_hb_soak` | **Constrained-random soak**, host path and DMA path together; per round a new personality (throttle on all eight channels, host completion ordering policy and latency, request mix, length, alignment); six configurations of (tags, MPS, MRRS, outstanding) | 63k - 180k |
| `system` | `tb_hb_system` | **Demonstration SoC end to end.** S0 register identification; S1 scratch register and byte lanes; S2 guard windows programmed through CSR registers, tenant isolation, defence in depth; S3 DMA host → SRAM; S4 DMA SRAM → host and the full round trip alongside host traffic; S5 DMA faults and the error-log registers; S6 cancel through the CONTROL register mid-DMA; S7 contention storm (host traffic + DMA, out-of-order host completions, back-pressure); S8 reset in the middle of a DMA (registers back to defaults, guard back to default-deny) | 11,713 |

The seven-item list of the task and where each item is covered:

| Required | Where |
|---|---|
| MMIO reads and writes | `host_path` P2-P9, `system` S1, `csr_unit`, `smoke` |
| DMA round trips | `dma_*` D1-D2 (read back through the bridge), `system` S3/S4, soak |
| Multiple outstanding requests | `multi_*`, `dma_*` D4-D5, soak |
| Backpressure | `host_path` P8, `dma_*` D7, `multi_*` M2/M3, soak (all eight channels) |
| Out-of-order completions where permitted | `dma_*` D5/D6 and soak (across tags on `dcpl`); **not** on `hcpl`, which ALP v1 keeps in order — documented, see LIMITATIONS §2 |
| Fault responses | `fabric_faults`, `dma_*` D8/D9/D11, `host_path` P6, `dma_timeout`, `system` S5 |
| Reset during traffic | `cancel_reset` R1.., `system` S8, soak |
| Address-boundary cases | `host_path` P3/P5/P6 (+ `_ap6k`), `dma_*` D3/D11, soak |

## 4. Mutation campaign

`scripts/mutate.py` plants one hand-written bug at a time in a private copy of the RTL (`build/mut/<id>/`), runs the
simulation(s) that should notice, and requires at least one to **fail**. A mutant is *killed* when a test fails or the
simulation aborts, *survives* when every selected test passes, and is reported as a *build failure* (weak kill) when the
mutant does not compile. Before anything else the script runs the same simulations on the **unmutated** tree and refuses
to continue if any fails, so a kill can never be an artefact of a broken baseline. Mutants that the design makes provably
equivalent are flagged and not counted against the tests.

Result on the final tree (run from the unpacked zip): **58 mutants planted, 56 killed, 0 survived, 0 build failures, 0 broken patches, 2 equivalent (`req_wrap`, `grd_wrap`); the unmutated baseline passed first**

The mutants target byte masks, address and length arithmetic, boundary / aperture / permission checks, the DomainGuard
handshake, completion ordering and error aggregation, tag lifecycle, reorder-buffer addressing, cancel / timeout
bookkeeping, the ALP arbiter and the CSR rights (`python3 scripts/mutate.py --list` prints all of them with the test
meant to catch each one).

The two equivalent mutants and why:

* `req_wrap` — removing the address-wrap check of the host path changes nothing observable: a request that wraps 2^64
  necessarily crosses a 2^`BOUNDARY_LOG2` boundary (2^64 is a multiple of it), and the boundary check right after it
  returns the same status (`BOUNDARY`). It is flagged equivalent, not killed.
* `grd_wrap` — the reference guard's own address-overflow check is redundant behind the bridge, which already rejects
  every wrapping request before the guard is asked. It is kept as defence in depth for a guard used behind another
  front end; flagged equivalent for this integration.

What the mutation campaign changed in the tests: nine mutants survived the first full run. Each was closed by a new or
stronger test (the table lists the planted bug as recorded in `scripts/mutate.py`, and the simulation that now kills it):

| First survivor | Planted bug | Closed by |
|---|---|---|
| `req_word_addr` | ALP word address off by one word — write and read-back go through the same wrong address, so the data still "round-trips" | `host_path`: SRAM backdoor compare of the whole memory against the reference model |
| `req_dom_ff` | reserved domain 0xFF reaches the fabric | `host_path`: ALP legality monitor ("no illegal ALP request is ever issued") |
| `req_guard_inverted_status` | deny verdict status mangled | `guard_lat0`: a guard model that can return every ALP status |
| `csr_priv_attr` | privileged attribute not required (domain alone decides) | `csr_unit`: the CSR block driven directly over ALP (the host path always supplies the privileged attribute) |
| `eng_last` | DMA write never marks its last beat (visible only as a PROTO event in the error log) | `system` |
| `fab_csr_check` | fabric access check of the register window removed | `system` |
| `grd_reset` | guard windows valid after reset (un-reset contents hid it from behaviour) | `guard_lat0`: state check after reset |
| `req_cancel_count` | cancel snapshot counts the popped request twice (over-aborts a request accepted after the cancel) | `cancel_reset`: over-abort scoreboard, then **C1d** (see below) |
| `req_posted_event` | an ABORTED posted write is not logged (it has no completion to carry the news) | `cancel_reset` C1b / C1c |

`req_cancel_count` needed a second round. It was killed by the random cancel storm in an earlier campaign, but in the
final campaign it **survived**: the random storm only hits the bug when a cancel lands in the cycle a request is
accepted, and that did not reproduce on the final tree. Test C1d now forces exactly that cycle (it watches
`hreq_valid && hreq_ready` and raises `cancel_i` for that one cycle) and the mutant is killed by it. The lesson recorded
here is that a kill by random stimulus is not a kill until the unmutated and mutated runs are repeated on the final tree.

A tenth, `dma_lowest_tag`, had been wrongly labelled "equivalent"; it is an ordinary mutant (the spec says lowest free
tag) and is killed.

After the last review of the coverage bins, three more mutants were added for DMA request validation
(`dma_zero_len`, `dma_wrap`, `dma_wrap_exact`) together with test D11 (§5).

## 5. Coverage

Functional-coverage bins are named counters printed by every simulation (`COV <tb> <bin> <n>`). Summed over the 31
runs the bins are, among others: every defined HTI status code on `hcpl` and on `dma_r` (0-10), every error-event
code, `dma_ooo_forced`, `soak_ooo_switches` (145 in the soak runs), reset with ALP words / DMA tags /
host-bound packets outstanding, reset while the DMA engine is busy, back-pressure on `hreq` and `hw`, guard verdict
storm permit / deny, host raw beats, silent / error-injected host reads.

**Unhit bins (10):** `hcpl_status_11..15` and `dma_status_11..15`. Codes 11-15 are not defined by HTI v1: the bridge
never produces them on `hcpl`, and on `dma_r` a host completion carrying one would be passed through as a non-OK status
(unspecified behaviour, not tested). Every *defined* code is hit on both channels.

The review of this table is itself a result: in the first final regression the bins `dma_status_2`, `_5`, `_6` and
`_9` were zero. `_5` and `_6` showed that the DMA path's zero-length and address-wrap rejections were implemented but
never tested; `_2` and `_9` showed that only three of the five host-completion error codes had been injected. D11 and
the D8 extension close those. (D11 also exposed a **testbench** bug: the BFM span check `addr + len` overflowed for a
request ending exactly at 2^64, so the model expected no valid lanes. The RTL result was right; the BFM comparisons
are now overflow-safe.)

Code coverage (line / toggle) was not measured.

## 6. Bug log

**Found in the RTL by the verification (all fixed, each now has a test that fails without the fix):**

1. *Fabric-reported errors produced no error event.* A request that failed in the fabric (ALP status ≠ OKAY) returned
   the right completion but did not appear on `err_evt`. Fixed with a fabric-error event FIFO and a unified end-of-
   request path that logs every non-OK result except the deliberately silent non-posted cancel
   (checked in `fabric_faults`; event payloads are also covered by mutant `req_event_addr`).
2. *A failing multi-chunk DMA write logged one event per chunk*, not one per request. Fixed by logging per parent
   aggregate (`dma_ev_dedupe`, `dma_t3_16_32`).
3. *The CSR guard-window table was unreachable.* The range check `register index < GWN` cast the end index to 7 bits;
   at the default eight windows `GWN` is 128, which truncates to 0, so no guard-window register could be read or
   written. Fixed with an 8-bit compare (commented in the RTL). Guard window programming through the registers is
   exercised by `system` S2 and `csr_unit`.

**Tool findings (not RTL bugs):**

4. Yosys 0.33 **segfaults** on a bit-select of a packed-struct member with a package-scoped index; worked around in
   `sf_albion_host_csr.sv` and listed in LIMITATIONS.
5. Verilator reported false combinational loops (UNOPTFLAT) on two signals (`eng_req`, `cn_mark`); the logic was split
   into separate assigns / always blocks (no behaviour change).
6. Verilator `--timing`: stimulus driven from `@(posedge clk)` races with `always @(posedge clk)` monitors. All BFMs
   drive on the falling edge (the AlbionCore house rule).

**Testbench defects found along the way** (worth listing because a wrong checker is as dangerous as a wrong design):
event snapshot too narrow; BFM insisted on exactly one error beat where partial OK beats are legal; `clear_rules`
before queued requests drained; wrong expectations for STATUS / alignment precedence in the CSR unit test; an inverted
range (MRRS = 32) that made `tb_range` allocate gigabytes in a soak configuration (it now reports an inverted range as
an error); a runner quoting bug for `-GAP1_SIZE=64'h1800`; stdout buffering that hid progress; an over-strict
over-abort scoreboard (now restricted to requests whose expected status is "OK or ABORTED"); a mutant "kill" caused by a
failing baseline (the baseline check was added); the 2^64 span overflow of §5.

## 7. What the evidence does not cover

* **Simulation is two-state and cycle-based.** No X-propagation, no metastability, no timing.
* **The DUT's single clock** means no clock-domain-crossing verification was needed or done.
* **Compliance with PCIe is neither claimed nor testable here:** the host BFM implements HTI, not TLPs.
* **The reference DomainGuard** was verified against its own contract and an independent policy model; this is not a
  security proof, and Citadel was not integrated (the seam is documented in [DOMAIN_GUARD_SEAM.md](DOMAIN_GUARD_SEAM.md)).
* **Randomised soak is bounded**: six configurations × one seed in `make all` (`make seeds` runs three simulator seeds);
  a clean run is evidence, not proof.
* **Mutation score measures the testbench, not the design**: a killed mutant shows a test can see that bug class; the
  hand-written mutant list cannot cover every bug.
