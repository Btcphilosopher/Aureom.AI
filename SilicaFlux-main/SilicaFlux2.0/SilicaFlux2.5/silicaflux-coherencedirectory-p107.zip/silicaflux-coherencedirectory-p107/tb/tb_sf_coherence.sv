// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: tb_sf_coherence  -- VERIFICATION-ONLY
//
// System testbench: NA coherent agents + directory (sf_coherence_subsystem), shared memory model, non-coherent
// gateway, and the reference-model checker (sf_coh_checker) watching every cycle.
//
// Directed:  T01 two simultaneous reads          T02 read followed by write       T03 two competing writers
//            T04 shared->modified upgrade        T05 modified-owner eviction      T06 data forwarding (intervention)
//            T07 back-pressure everywhere        T08 reset mid-flight             T09 same-line contention
//            T10 independent-line concurrency    T11 writeback races (forced + random)
// Memory-model: T12 litmus tests SB / MP / 2+2W under random delays and stalls (forbidden outcomes must not occur)
//            T13 atomic counter (no lost updates) + false sharing
// Non-coherent: T14 DMA without maintenance sees STALE data (negative control), with FLUSH protocol sees CURRENT data,
//               gateway refuses window accesses unless allowed
// Random:    T15 random stress with stall injection on every channel, memory latency and CPU response back-pressure
//
// Parameters select configuration (iverilog -P / verilator -G).  Prints "TB RESULT: PASS" / "FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sf_coherence;
  parameter int NA          = 2;
  parameter int DIR_LINES   = 8;
  parameter int CACHE_SETS  = 1;      // 1 => every line conflicts with every other (maximum eviction traffic)
  parameter int STALL_PCT   = 0;      // per-cycle probability (%) that a channel transfer is blocked
  parameter int CPU_STALL   = 0;      // per-cycle probability (%) the CPU does not take a response
  parameter int MEM_LAT_MAX = 1;
  parameter int MEM_READY   = 100;
  parameter int SEED        = 1;
  parameter int RAND_OPS    = 400;
  parameter int LITMUS_ITERS = 150;
  parameter int QUICK       = 0;      // 1: skip the long random / litmus runs

  localparam int LINE_BYTES = 64;
  localparam int LB   = LINE_BYTES * 8;
  localparam int LIW  = (DIR_LINES > 1) ? $clog2(DIR_LINES) : 1;
  localparam int AIW  = (NA > 1) ? $clog2(NA) : 1;
  localparam int ENTW = 2 + NA + AIW;
  localparam int WPL  = LINE_BYTES / 4;
  localparam int WIW  = $clog2(WPL);
  localparam [31:0] BASE = 32'h8000_0000;

  import sf_coherence_pkg::*;

  // ------------------------------------------------------------------ clock / reset
  reg clk = 0;
  reg rst_n = 0;
  always #5 clk = ~clk;
  integer cycle = 0;
  always @(posedge clk) cycle <= cycle + 1;

  // ------------------------------------------------------------------ DUT
  reg  [NA-1:0]    cpu_req_valid;
  wire [NA-1:0]    cpu_req_ready;
  reg  [NA*3-1:0]  cpu_op;
  reg  [NA*32-1:0] cpu_addr, cpu_wdata;
  reg  [NA*4-1:0]  cpu_wstrb;
  wire [NA-1:0]    cpu_rsp_valid;
  reg  [NA-1:0]    cpu_rsp_ready;
  wire [NA*32-1:0] cpu_rdata;
  wire [NA-1:0]    cpu_rsp_err;

  wire             mem_req_valid, mem_req_ready, mem_req_wr, mem_rsp_valid, mem_rsp_ready;
  wire [LIW-1:0]   mem_req_line;
  wire [LB-1:0]    mem_req_wdata, mem_rsp_rdata;

  reg  [NA-1:0]    allow_req, allow_rsp, allow_snp, allow_gnt;
  reg  [NA-1:0]    block_req, block_rsp, block_snp, block_gnt;   // directed forcing of a stall

  wire [DIR_LINES*ENTW-1:0]       dbg_dir;
  wire [NA*3-1:0]                 dbg_slot_state, dbg_slot_type, dbg_slot_gtype;
  wire [NA*LIW-1:0]               dbg_slot_line;
  wire [NA-1:0]                   dbg_slot_busy, dbg_slot_wait, dbg_mem_wr_perf;
  wire [NA*NA-1:0]                dbg_slot_waiting;
  wire [NA*2-1:0]                 dbg_slot_gk;
  wire [NA*LB-1:0]                dbg_slot_data;
  wire [DE_W-1:0]                 dbg_dir_err;
  wire [NA*AE_W-1:0]              dbg_agent_err;
  wire [PD_N*32-1:0]              perf_dir;
  wire [NA*PA_N*32-1:0]           perf_agent;
  wire [NA*2-1:0]                 dbg_a_st;
  wire [NA*CACHE_SETS*2-1:0]      dbg_cs_all;
  wire [NA*CACHE_SETS*LIW-1:0]    dbg_tag_all;
  wire [NA*CACHE_SETS*LB-1:0]     dbg_data_all;
  wire [NA*3-1:0]                 dbg_p_st;
  wire [NA*LIW-1:0]               dbg_p_line;
  wire [NA-1:0]                   dbg_p_lost;
  wire [NA*LB-1:0]                dbg_p_data;
  wire [NA-1:0]                   ev_perf_v, ev_perf_wr;
  wire [NA*LIW-1:0]               ev_perf_line;
  wire [NA*WIW-1:0]               ev_perf_word;
  wire [NA*32-1:0]                ev_perf_rdata;
  wire [NA*LB-1:0]                ev_perf_newline, ev_perf_oldline;
  wire [NA-1:0]                   mon_req_hs, mon_rsp_hs, mon_snp_hs, mon_gnt_hs;

  sf_coherence_subsystem #(
    .N_AGENTS(NA), .DIR_LINES(DIR_LINES), .CACHE_SETS(CACHE_SETS), .LINE_BYTES(LINE_BYTES), .COH_BASE(BASE)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .cpu_req_valid(cpu_req_valid), .cpu_req_ready(cpu_req_ready), .cpu_op(cpu_op), .cpu_addr(cpu_addr),
    .cpu_wdata(cpu_wdata), .cpu_wstrb(cpu_wstrb), .cpu_rsp_valid(cpu_rsp_valid), .cpu_rsp_ready(cpu_rsp_ready),
    .cpu_rdata(cpu_rdata), .cpu_rsp_err(cpu_rsp_err),
    .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready), .mem_req_wr(mem_req_wr),
    .mem_req_line(mem_req_line), .mem_req_wdata(mem_req_wdata),
    .mem_rsp_valid(mem_rsp_valid), .mem_rsp_ready(mem_rsp_ready), .mem_rsp_rdata(mem_rsp_rdata),
    .chan_allow_req(allow_req), .chan_allow_rsp(allow_rsp), .chan_allow_snp(allow_snp), .chan_allow_gnt(allow_gnt),
    .dbg_dir(dbg_dir), .dbg_slot_state(dbg_slot_state), .dbg_slot_line(dbg_slot_line), .dbg_slot_type(dbg_slot_type),
    .dbg_slot_busy(dbg_slot_busy), .dbg_slot_waiting(dbg_slot_waiting), .dbg_slot_gtype(dbg_slot_gtype),
    .dbg_slot_gk(dbg_slot_gk), .dbg_slot_data(dbg_slot_data), .dbg_slot_wait(dbg_slot_wait),
    .dbg_mem_wr_perf(dbg_mem_wr_perf), .dbg_dir_err(dbg_dir_err), .dbg_agent_err(dbg_agent_err),
    .perf_dir(perf_dir), .perf_agent(perf_agent),
    .dbg_a_st(dbg_a_st), .dbg_cs_all(dbg_cs_all), .dbg_tag_all(dbg_tag_all), .dbg_data_all(dbg_data_all),
    .dbg_p_st(dbg_p_st), .dbg_p_line(dbg_p_line), .dbg_p_lost(dbg_p_lost), .dbg_p_data(dbg_p_data),
    .ev_perf_v(ev_perf_v), .ev_perf_wr(ev_perf_wr), .ev_perf_line(ev_perf_line), .ev_perf_word(ev_perf_word),
    .ev_perf_rdata(ev_perf_rdata), .ev_perf_newline(ev_perf_newline), .ev_perf_oldline(ev_perf_oldline),
    .mon_req_hs(mon_req_hs), .mon_rsp_hs(mon_rsp_hs), .mon_snp_hs(mon_snp_hs), .mon_gnt_hs(mon_gnt_hs), .dbg_chan()
  );

  // ------------------------------------------------------------------ memory + non-coherent gateway
  wire         w_req_valid, w_req_ready, w_req_write, w_rsp_valid, w_rsp_ready, w_rsp_error;
  wire [31:0]  w_req_addr, w_req_wdata, w_rsp_rdata;
  wire [3:0]   w_req_wstrb;
  wire [DIR_LINES*LB-1:0] mem_flat;
  wire [31:0]  mm_line_rd, mm_line_wr;

  sf_coh_mem_model #(
    .DIR_LINES(DIR_LINES), .LINE_BYTES(LINE_BYTES), .RD_LAT_MIN(1), .RD_LAT_MAX(MEM_LAT_MAX), .WR_LAT_MIN(1),
    .WR_LAT_MAX(MEM_LAT_MAX), .READY_PCT(MEM_READY), .SEED(SEED + 77), .COH_BASE(BASE)
  ) mem (
    .clk(clk), .rst_n(rst_n),
    .l_req_valid(mem_req_valid), .l_req_ready(mem_req_ready), .l_req_wr(mem_req_wr), .l_req_line(mem_req_line),
    .l_req_wdata(mem_req_wdata), .l_rsp_valid(mem_rsp_valid), .l_rsp_ready(mem_rsp_ready), .l_rsp_rdata(mem_rsp_rdata),
    .w_req_valid(w_req_valid), .w_req_ready(w_req_ready), .w_req_write(w_req_write), .w_req_addr(w_req_addr),
    .w_req_wdata(w_req_wdata), .w_req_wstrb(w_req_wstrb), .w_rsp_valid(w_rsp_valid), .w_rsp_ready(w_rsp_ready),
    .w_rsp_rdata(w_rsp_rdata), .w_rsp_error(w_rsp_error), .mem_flat(mem_flat),
    .st_line_rd(mm_line_rd), .st_line_wr(mm_line_wr)
  );

  reg          nc_req_valid, nc_req_write, nc_rsp_ready, nc_allow;
  reg  [31:0]  nc_req_addr, nc_req_wdata;
  reg  [3:0]   nc_req_wstrb;
  wire         nc_req_ready, nc_rsp_valid, nc_rsp_error;
  wire [31:0]  nc_rsp_rdata, nc_c_allowed, nc_c_wok, nc_c_ref, nc_c_bytes;

  sf_coherence_nc_gateway #(.NC_CLASS(0), .DIR_LINES(DIR_LINES), .LINE_BYTES(LINE_BYTES), .COH_BASE(BASE)) nc (
    .clk(clk), .rst_n(rst_n), .cfg_allow_window(nc_allow),
    .s_req_valid(nc_req_valid), .s_req_ready(nc_req_ready), .s_req_write(nc_req_write), .s_req_addr(nc_req_addr),
    .s_req_wdata(nc_req_wdata), .s_req_wstrb(nc_req_wstrb), .s_rsp_valid(nc_rsp_valid), .s_rsp_ready(nc_rsp_ready),
    .s_rsp_rdata(nc_rsp_rdata), .s_rsp_error(nc_rsp_error),
    .m_req_valid(w_req_valid), .m_req_ready(w_req_ready), .m_req_write(w_req_write), .m_req_addr(w_req_addr),
    .m_req_wdata(w_req_wdata), .m_req_wstrb(w_req_wstrb), .m_rsp_valid(w_rsp_valid), .m_rsp_ready(w_rsp_ready),
    .m_rsp_rdata(w_rsp_rdata), .m_rsp_error(w_rsp_error),
    .cnt_allowed(nc_c_allowed), .cnt_window_ok(nc_c_wok), .cnt_refused(nc_c_ref), .cnt_bytes(nc_c_bytes)
  );

  // ------------------------------------------------------------------ reference model / invariants
  wire [31:0] chk_err, chk_nload, chk_nstore, chk_namo, chk_nflush, chk_ngrants, chk_nmemwr, chk_nq;
  sf_coh_checker #(.N_AGENTS(NA), .DIR_LINES(DIR_LINES), .CACHE_SETS(CACHE_SETS), .LINE_BYTES(LINE_BYTES), .COH_BASE(BASE)) chk (
    .clk(clk), .rst_n(rst_n), .enable(chk_en),
    .cpu_req_valid(cpu_req_valid), .cpu_req_ready(cpu_req_ready), .cpu_op(cpu_op), .cpu_addr(cpu_addr),
    .cpu_wdata(cpu_wdata), .cpu_wstrb(cpu_wstrb), .cpu_rsp_valid(cpu_rsp_valid), .cpu_rsp_ready(cpu_rsp_ready),
    .cpu_rdata(cpu_rdata), .cpu_rsp_err(cpu_rsp_err),
    .ev_perf_v(ev_perf_v), .ev_perf_wr(ev_perf_wr), .ev_perf_line(ev_perf_line), .ev_perf_word(ev_perf_word),
    .ev_perf_rdata(ev_perf_rdata), .ev_perf_newline(ev_perf_newline), .ev_perf_oldline(ev_perf_oldline),
    .dbg_cs_all(dbg_cs_all), .dbg_tag_all(dbg_tag_all), .dbg_data_all(dbg_data_all), .dbg_p_st(dbg_p_st),
    .dbg_p_line(dbg_p_line), .dbg_p_lost(dbg_p_lost), .dbg_p_data(dbg_p_data),
    .dbg_dir(dbg_dir), .dbg_slot_state(dbg_slot_state), .dbg_slot_line(dbg_slot_line), .dbg_slot_busy(dbg_slot_busy),
    .dbg_slot_waiting(dbg_slot_waiting), .dbg_slot_gtype(dbg_slot_gtype), .dbg_slot_data(dbg_slot_data),
    .mon_gnt_hs(mon_gnt_hs),
    .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready), .mem_req_wr(mem_req_wr), .mem_req_line(mem_req_line),
    .mem_req_wdata(mem_req_wdata), .mem_flat(mem_flat),
    .dir_err(dbg_dir_err), .agent_err(dbg_agent_err),
    .err_cnt(chk_err), .n_load(chk_nload), .n_store(chk_nstore), .n_amo(chk_namo), .n_flush(chk_nflush),
    .n_grants(chk_ngrants), .n_memwr(chk_nmemwr), .n_quiescent_line_checks(chk_nq)
  );

  // ------------------------------------------------------------------ stall injection (driven on the falling edge)
  integer rseed;

  integer ii;
  function integer rnd(input integer n);   // 0 .. n-1
    integer v;
    begin
      v = $random(rseed);
      if (v < 0) v = -v;
      rnd = (n > 0) ? (v % n) : 0;
    end
  endfunction

  always @(negedge clk) begin
    for (ii = 0; ii < NA; ii = ii + 1) begin
      allow_req[ii] <= !block_req[ii] && (rnd(100) >= STALL_PCT);
      allow_rsp[ii] <= !block_rsp[ii] && (rnd(100) >= STALL_PCT);
      allow_snp[ii] <= !block_snp[ii] && (rnd(100) >= STALL_PCT);
      allow_gnt[ii] <= !block_gnt[ii] && (rnd(100) >= STALL_PCT);
      cpu_rsp_ready[ii] <= (rnd(100) >= CPU_STALL);
    end
  end

  // ------------------------------------------------------------------ CPU driver tasks
  reg chk_en = 1;
  integer tb_err = 0;
  integer tests_run = 0;
  integer timeout_cycles = 30000;
  reg     abort_ops = 0;           // set by the reset test: tasks return immediately

  task automatic fail(input [8*64-1:0] msg);
    begin
      tb_err = tb_err + 1;
      if (tb_err <= 20) $display("TB FAIL @%0t : %0s", $time, msg);
    end
  endtask

  task automatic cpu_do(input integer a, input [2:0] op, input [31:0] addr, input [31:0] wd, input [3:0] ws,
                        output [31:0] rd, output errf);
    integer t;
    reg got;
    begin
      rd = 32'd0; errf = 1'b0; t = 0; got = 0;
      @(negedge clk);
      if (!abort_ops) begin
        cpu_req_valid[a] = 1'b1; cpu_op[a*3 +: 3] = op; cpu_addr[a*32 +: 32] = addr;
        cpu_wdata[a*32 +: 32] = wd; cpu_wstrb[a*4 +: 4] = ws;
        while (!got && !abort_ops) begin
          @(posedge clk);
          if (cpu_req_ready[a] && rst_n) got = 1;
          t = t + 1;
          if (t > timeout_cycles) begin fail("cpu request not accepted (timeout)"); got = 1; abort_ops = 1; end
        end
        @(negedge clk);
        cpu_req_valid[a] = 1'b0;
        got = 0;
        while (!got && !abort_ops) begin
          @(posedge clk);
          if (cpu_rsp_valid[a] && cpu_rsp_ready[a]) begin rd = cpu_rdata[a*32 +: 32]; errf = cpu_rsp_err[a]; got = 1; end
          t = t + 1;
          if (t > timeout_cycles) begin fail("cpu response timeout (deadlock?)"); got = 1; abort_ops = 1; end
        end
      end
    end
  endtask

  function [31:0] A(input integer line, input integer word);
    A = BASE + line * LINE_BYTES + word * 4;
  endfunction

  reg [31:0] rv; reg ev;
  task automatic ld(input integer a, input [31:0] addr, output [31:0] rd);
    reg e; begin cpu_do(a, OP_LOAD, addr, 32'd0, 4'hF, rd, e); if (e) fail("load error"); end
  endtask
  task automatic st(input integer a, input [31:0] addr, input [31:0] wd);
    reg [31:0] r; reg e; begin cpu_do(a, OP_STORE, addr, wd, 4'hF, r, e); if (e) fail("store error"); end
  endtask
  task automatic amo(input integer a, input [31:0] addr, input [31:0] wd, output [31:0] old);
    reg e; begin cpu_do(a, OP_AMO, addr, wd, 4'hF, old, e); if (e) fail("amo error"); end
  endtask
  task automatic flush(input integer a, input [31:0] addr);
    reg [31:0] r; reg e; begin cpu_do(a, OP_FLUSH, addr, 32'd0, 4'hF, r, e); if (e) fail("flush error"); end
  endtask
  task automatic fence(input integer a);
    reg [31:0] r; reg e; begin cpu_do(a, OP_FENCE, BASE, 32'd0, 4'hF, r, e); if (e) fail("fence error"); end
  endtask
  task automatic expect_eq(input [31:0] got, input [31:0] exp, input [8*48-1:0] what);
    begin if (got !== exp) begin fail(what); $display("   %0s: got %h expected %h", what, got, exp); end end
  endtask
  task automatic delay(input integer n);
    integer k; begin for (k = 0; k < n; k = k + 1) @(posedge clk); end
  endtask

  // ------------------------------------------------------------------ state access helpers
  function [1:0] cstate(input integer a, input integer line);        // cache state of `line` in agent a (set 0 .. CACHE_SETS)
    integer s; reg [1:0] r;
    begin
      r = CS_I;
      for (s = 0; s < CACHE_SETS; s = s + 1)
        if (dbg_cs_all[(a*CACHE_SETS + s)*2 +: 2] != CS_I && dbg_tag_all[(a*CACHE_SETS + s)*LIW +: LIW] == line)
          r = dbg_cs_all[(a*CACHE_SETS + s)*2 +: 2];
      cstate = r;
    end
  endfunction
  function [1:0] dstate(input integer line);  dstate = dbg_dir[line*ENTW +: 2]; endfunction
  function [NA-1:0] dshare(input integer line); dshare = dbg_dir[line*ENTW + 2 +: NA]; endfunction
  function [AIW-1:0] downer(input integer line); downer = dbg_dir[line*ENTW + 2 + NA +: AIW]; endfunction

  task automatic wait_quiet;     // all slots idle, all agents idle, channels drained
    integer t; reg q;
    begin
      t = 0; q = 0;
      while (!q && t < 5000) begin
        @(posedge clk); t = t + 1;
        q = (dbg_slot_busy == 0) && (dbg_slot_wait == 0) && (dbg_a_st == 0) && !mem_req_valid && !mem_rsp_valid;
      end
      delay(4);
    end
  endtask

  task automatic do_reset;
    begin
      abort_ops = 1;
      delay(2);
      @(negedge clk); rst_n = 0; cpu_req_valid = 0;
      delay(3);
      @(negedge clk); rst_n = 1;
      abort_ops = 0;
      delay(2);
    end
  endtask

  // flush every line from every agent, then require memory == golden model
  task automatic final_check(input [8*24-1:0] name);
    integer l, a;
    reg ok;
    begin
      for (l = 0; l < DIR_LINES; l = l + 1)
        for (a = 0; a < NA; a = a + 1)
          flush(a, A(l, 0));
      wait_quiet;
      ok = (mem_flat === chk.gold);
      if (!ok) fail("final memory image != golden model");
      for (l = 0; l < DIR_LINES; l = l + 1)
        if (dstate(l) !== DS_UNC) begin fail("directory not UNC after full flush"); $display("   line %0d state %0d", l, dstate(l)); end
      if (dbg_dir_err !== 0 || dbg_agent_err !== 0) fail("sticky error bit set");
    end
  endtask

  // snapshot of counters for per-test deltas
  integer d_gets, d_getm, d_upg, d_inv, d_own, d_dirty, d_putm, d_puts, d_stale, d_conf;
  function integer pd(input integer idx); pd = perf_dir[idx*32 +: 32]; endfunction
  task automatic snap;
    begin
      d_gets = pd(PD_GETS); d_getm = pd(PD_GETM); d_upg = pd(PD_UPG); d_inv = pd(PD_INV); d_own = pd(PD_OWN_XFER);
      d_dirty = pd(PD_DIRTY_INT); d_putm = pd(PD_PUTM); d_puts = pd(PD_PUTS); d_stale = pd(PD_STALE_PUT); d_conf = pd(PD_RETRIES);
    end
  endtask

  task automatic report(input [8*40-1:0] name, input integer e0, input integer c0);
    begin
      tests_run = tests_run + 1;
      $display("[%0s] %s  (dGETS=%0d dGETM=%0d dUPG=%0d dINV=%0d ownXfer=%0d dirtyInt=%0d PUTM=%0d PUTS=%0d stalePut=%0d retries=%0d, checker errs=%0d)",
               name, (tb_err == e0 && chk_err == c0) ? "PASS" : "FAIL",
               pd(PD_GETS) - d_gets, pd(PD_GETM) - d_getm, pd(PD_UPG) - d_upg, pd(PD_INV) - d_inv, pd(PD_OWN_XFER) - d_own,
               pd(PD_DIRTY_INT) - d_dirty, pd(PD_PUTM) - d_putm, pd(PD_PUTS) - d_puts, pd(PD_STALE_PUT) - d_stale,
               pd(PD_RETRIES) - d_conf, chk_err - c0);
    end
  endtask

  integer e0, c0;
  reg [31:0] r0, r1, r2v, r3;
  integer a_, l_, k_, n_;

  // =====================================================================================================
  // directed tests
  // =====================================================================================================
  task automatic t01_simultaneous_reads;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      fork
        ld(0, A(0, 3), r0);
        ld(1, A(0, 3), r1);
      join
      expect_eq(r0, r1, "both readers see the same value");
      expect_eq(cstate(0, 0), CS_S, "agent0 Shared");
      expect_eq(cstate(1, 0), CS_S, "agent1 Shared");
      wait_quiet;
      expect_eq(dstate(0), DS_SHR, "directory Shared");
      expect_eq(dshare(0), {NA{1'b1}} & 2'b11, "sharer vector {0,1}");
      final_check("t01");
      report("T01 two simultaneous reads", e0, c0);
    end
  endtask

  task automatic t02_read_then_write;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      ld(0, A(1, 0), r0);
      st(1, A(1, 0), 32'hCAFE_0001);
      expect_eq(cstate(0, 1), CS_I, "reader invalidated by the write");
      expect_eq(cstate(1, 1), CS_M, "writer Modified");
      ld(0, A(1, 0), r1);
      expect_eq(r1, 32'hCAFE_0001, "reader observes the write");
      wait_quiet;
      expect_eq(dstate(1), DS_SHR, "directory Shared after re-read");
      final_check("t02");
      report("T02 read then write", e0, c0);
    end
  endtask

  task automatic t03_competing_writers;
    integer i;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      for (i = 0; i < 20; i = i + 1) begin
        fork
          begin delay(rnd(4)); st(0, A(2, 0), 32'hA000_0000 + i); end
          begin delay(rnd(4)); st(1, A(2, 0), 32'hB000_0000 + i); end
        join
        ld(0, A(2, 0), r0); ld(1, A(2, 0), r1);
        if (r0 !== r1) fail("agents disagree after competing writes");
        if (r0 !== (32'hA000_0000 + i) && r0 !== (32'hB000_0000 + i)) fail("value is neither writer's");
      end
      wait_quiet;
      final_check("t03");
      report("T03 two competing writers", e0, c0);
    end
  endtask

  task automatic t04_upgrade;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      ld(0, A(3, 0), r0);                              // both Shared
      ld(1, A(3, 0), r1);
      st(0, A(3, 0), 32'h1111_2222);                   // S -> M upgrade, invalidates agent1
      expect_eq(cstate(0, 3), CS_M, "upgrader Modified");
      expect_eq(cstate(1, 3), CS_I, "other sharer invalidated before ownership");
      expect_eq(pd(PD_UPG) - d_upg, 1, "exactly one UPG");
      ld(1, A(3, 0), r2v);
      expect_eq(r2v, 32'h1111_2222, "other agent sees upgraded value");
      wait_quiet;
      final_check("t04");
      report("T04 shared-to-modified upgrade", e0, c0);
    end
  endtask

  task automatic t05_owner_eviction;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      st(0, A(4, 0), 32'h5555_AAAA);                   // agent0 owns line 4 (M)
      expect_eq(cstate(0, 4), CS_M, "owner Modified");
      if (CACHE_SETS == 1) ld(0, A(5, 0), r0); else flush(0, A(4, 0));   // evict the Modified line
      wait_quiet;
      expect_eq(cstate(0, 4), CS_I, "line evicted from owner");
      expect_eq(dstate(4), DS_UNC, "directory Uncached after writeback");
      ld(1, A(4, 0), r1);
      expect_eq(r1, 32'h5555_AAAA, "other agent reads the written-back data from memory");
      final_check("t05");
      report("T05 modified-owner eviction", e0, c0);
    end
  endtask

  task automatic t06_forwarding;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      st(0, A(6, 2), 32'h0BAD_F00D);
      ld(1, A(6, 2), r1);                              // dirty intervention: owner supplies the data
      expect_eq(r1, 32'h0BAD_F00D, "load served from the dirty owner");
      expect_eq(pd(PD_DIRTY_INT) - d_dirty, 1, "one dirty intervention");
      expect_eq(cstate(0, 6), CS_S, "old owner downgraded to Shared");
      expect_eq(cstate(1, 6), CS_S, "reader Shared");
      st(1, A(6, 2), 32'h0D15_EA5E);                   // upgrade
      st(0, A(6, 4), 32'h7777_0001);                   // ownership transfer M->M (agent0 is I -> GETM, agent1 owner)
      expect_eq(pd(PD_OWN_XFER) - d_own, 1, "one ownership transfer");
      ld(1, A(6, 2), r2v);
      expect_eq(r2v, 32'h0D15_EA5E, "first owner's word survived the transfer");
      wait_quiet;
      final_check("t06");
      report("T06 data forwarding / ownership transfer", e0, c0);
    end
  endtask

  task automatic t09_same_line_contention;
    integer i;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      fork
        begin : c0_t integer i0; for (i0 = 0; i0 < 60; i0 = i0 + 1) begin
            case (rnd(4)) 0: ld(0, A(7, rnd(WPL)), r0); 1: st(0, A(7, rnd(WPL)), $random(rseed)); 2: amo(0, A(7, 1), 1, r0);
                          default: begin ld(0, A(7, rnd(WPL)), r0); st(0, A(7, rnd(WPL)), $random(rseed)); end endcase
          end end
        begin : c1_t integer i1; for (i1 = 0; i1 < 60; i1 = i1 + 1) begin
            case (rnd(4)) 0: ld(1, A(7, rnd(WPL)), r1); 1: st(1, A(7, rnd(WPL)), $random(rseed)); 2: amo(1, A(7, 1), 1, r1);
                          default: begin ld(1, A(7, rnd(WPL)), r1); st(1, A(7, rnd(WPL)), $random(rseed)); end endcase
          end end
      join
      wait_quiet;
      final_check("t09");
      report("T09 same-line contention", e0, c0);
    end
  endtask

  task automatic t10_independent_lines;
    integer both, par_cycles, c;
    reg dn0, dn1;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      both = 0; dn0 = 0; dn1 = 0;
      c = cycle;
      fork
        begin for (k_ = 0; k_ < 30; k_ = k_ + 1) st(0, A(0, k_ % 16), k_); dn0 = 1; end
        begin for (n_ = 0; n_ < 30; n_ = n_ + 1) st(1, A(1, n_ % 16), 100 + n_); dn1 = 1; end
        begin
          while (!(dn0 && dn1) && !abort_ops) begin
            @(posedge clk);
            if (dbg_slot_busy == {NA{1'b1}}) both = both + 1;
          end
        end
      join
      par_cycles = cycle - c;
      wait_quiet;
      if (both == 0) fail("independent lines never ran concurrently in the directory");
      $display("   T10: %0d cycles with BOTH transaction slots busy on different lines (%0d cycles in total)", both, par_cycles);
      final_check("t10");
      report("T10 independent-line concurrency", e0, c0);
    end
  endtask

  // forced writeback race: agent0's PUTM is held back while agent1's read of the same line passes first
  task automatic t11_writeback_race;
    integer i;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      st(0, A(0, 0), 32'hFEED_0001);                   // agent0 Modified on line 0
      block_req[0] = 1'b1;                             // hold agent0's next request (the PUTM) in its register
      fork
        begin ld(0, A(1, 0), r0); end                  // conflict miss: evicts line 0 (PUTM held back), then GETS line 1
        begin delay(6); ld(1, A(0, 0), r1); end        // agent1's GETS of line 0 overtakes the PUTM: FWD_S hits the eviction buffer
        begin delay(40); block_req[0] = 1'b0; end
      join
      expect_eq(r1, 32'hFEED_0001, "intervention served from the eviction buffer");
      wait_quiet;
      if (CACHE_SETS == 1 && pd(PD_STALE_PUT) - d_stale < 1) fail("forced race did not produce a stale PUTM");
      // same for a clean line: PUTS races with an invalidation
      ld(0, A(2, 0), r0); ld(1, A(2, 0), r1);          // both Shared
      block_req[0] = 1'b1;
      fork
        begin ld(0, A(3, 0), r0); end                  // evicts line 2 (PUTS held back)
        begin delay(6); st(1, A(2, 0), 32'h0000_0042); end  // agent1 upgrades: INV to agent0 hits the PUTS-pending line
        begin delay(40); block_req[0] = 1'b0; end
      join
      wait_quiet;
      for (i = 0; i < 100; i = i + 1) begin            // random race hunting around the forced cases
        block_req[0] = (rnd(3) == 0);
        fork
          begin st(0, A(rnd(3), 0), i); ld(0, A(rnd(3), 1), r0); end
          begin ld(1, A(rnd(3), 0), r1); st(1, A(rnd(3), 1), 1000 + i); end
          begin delay(3 + rnd(25)); block_req[0] = 0; end
        join
        block_req[0] = 0;
      end
      wait_quiet;
      final_check("t11");
      report("T11 writeback races", e0, c0);
    end
  endtask

  // =====================================================================================================
  // litmus tests under the (sequentially consistent) blocking-agent port
  // =====================================================================================================
  integer sb_00, sb_01, sb_10, sb_11, mp_bad, mp_flag1, w22_bad;
  task automatic t12_litmus;
    integer it, same_line, spin;
    reg [31:0] x0, y0, f, d;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      sb_00 = 0; sb_01 = 0; sb_10 = 0; sb_11 = 0; mp_bad = 0; mp_flag1 = 0; w22_bad = 0;
      for (it = 0; it < LITMUS_ITERS; it = it + 1) begin
        same_line = it & 1;
        // ---- SB (store buffering): forbidden (r0,r1) = (0,0)
        st(0, A(0, 0), 0); st(0, A(same_line ? 0 : 1, same_line ? 1 : 0), 0); fence(0);
        fork
          begin delay(rnd(6)); st(0, A(0, 0), 1); ld(0, A(same_line ? 0 : 1, same_line ? 1 : 0), x0); end
          begin delay(rnd(6)); st(1, A(same_line ? 0 : 1, same_line ? 1 : 0), 1); ld(1, A(0, 0), y0); end
        join
        if (x0 == 0 && y0 == 0) sb_00 = sb_00 + 1; else if (x0 == 0) sb_01 = sb_01 + 1; else if (y0 == 0) sb_10 = sb_10 + 1; else sb_11 = sb_11 + 1;
        // ---- MP (message passing): flag seen => data seen
        st(0, A(2, 0), 0); st(0, A(same_line ? 2 : 3, same_line ? 1 : 0), 0); fence(0);
        fork
          begin delay(rnd(6)); st(0, A(2, 0), 7); st(0, A(same_line ? 2 : 3, same_line ? 1 : 0), 1); end
          begin
            delay(rnd(6)); f = 0; spin = 0;
            while (f == 0 && spin < 200) begin ld(1, A(same_line ? 2 : 3, same_line ? 1 : 0), f); spin = spin + 1; end
            ld(1, A(2, 0), d);
            if (f == 1) begin mp_flag1 = mp_flag1 + 1; if (d != 7) mp_bad = mp_bad + 1; end
          end
        join
        // ---- 2+2W: both agents write x then y in opposite orders; final (x,y) = (1,2) while the order was
        //      x:=1(A) y:=1(A)  /  y:=2(B) x:=2(B) must leave x and y written by consistent last writers
        st(0, A(4, 0), 0); st(0, A(5, 0), 0);
        fork
          begin st(0, A(4, 0), 1); st(0, A(5, 0), 1); end
          begin st(1, A(5, 0), 2); st(1, A(4, 0), 2); end
        join
        ld(0, A(4, 0), x0); ld(1, A(5, 0), y0);
        // forbidden under SC: x==1 && y==2 (A's first store ordered last on x, B's first store ordered last on y: a cycle)
        if (x0 == 1 && y0 == 2) w22_bad = w22_bad + 1;
      end
      $display("   SB outcomes (r0,r1): (0,0)=%0d [forbidden]  (0,1)=%0d (1,0)=%0d (1,1)=%0d ; MP flag-seen=%0d data-stale=%0d [must be 0] ; 2+2W forbidden=%0d",
               sb_00, sb_01, sb_10, sb_11, mp_flag1, mp_bad, w22_bad);
      if (sb_00 != 0) fail("SB forbidden outcome observed");
      if (mp_bad != 0) fail("MP forbidden outcome observed");
      if (w22_bad != 0) fail("2+2W forbidden outcome observed");
      wait_quiet;
      final_check("t12");
      report("T12 litmus SB/MP/2+2W", e0, c0);
    end
  endtask

  integer cnt_total;
  task automatic t13_atomics_and_false_sharing;
    integer i, j, nn;
    reg [31:0] o0, o1;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      nn = 80;
      st(0, A(6, 0), 0);
      fork
        begin : amo_a0 integer i0; for (i0 = 0; i0 < nn; i0 = i0 + 1) begin amo(0, A(6, 0), 1, o0); delay(rnd(3)); end end
        begin : amo_a1 integer i1; for (i1 = 0; i1 < nn; i1 = i1 + 1) begin amo(1, A(6, 0), 1, o1); delay(rnd(3)); end end
      join
      ld(0, A(6, 0), r0);
      expect_eq(r0, 2*nn, "atomic counter: no lost update");
      // false sharing: two writers, disjoint words of ONE line, both written concurrently and repeatedly
      fork
        begin : fs_a0 integer i0; for (i0 = 0; i0 < 40; i0 = i0 + 1) st(0, A(5, i0 % 8), 32'h0A00_0000 + i0); end
        begin : fs_a1 integer i1; for (i1 = 0; i1 < 40; i1 = i1 + 1) st(1, A(5, 8 + (i1 % 8)), 32'h0B00_0000 + i1); end
      join
      for (j = 0; j < 8; j = j + 1) begin
        ld(1, A(5, j), r0);     expect_eq(r0, 32'h0A00_0000 + 32 + j, "false sharing: agent0 word retained");
        ld(0, A(5, 8 + j), r1); expect_eq(r1, 32'h0B00_0000 + 32 + j, "false sharing: agent1 word retained");
      end
      wait_quiet;
      final_check("t13");
      report("T13 atomic counter / false sharing", e0, c0);
    end
  endtask

  // =====================================================================================================
  // non-coherent masters
  // =====================================================================================================
  task automatic nc_do(input write, input [31:0] addr, input [31:0] wd, input [3:0] ws, output [31:0] rd, output errf);
    integer t; reg got;
    begin
      rd = 0; errf = 0; got = 0; t = 0;
      @(negedge clk);
      nc_req_valid = 1; nc_req_write = write; nc_req_addr = addr; nc_req_wdata = wd; nc_req_wstrb = ws;
      while (!got && t < 2000) begin @(posedge clk); if (nc_req_ready) got = 1; t = t + 1; end
      @(negedge clk); nc_req_valid = 0;
      got = 0; nc_rsp_ready = 1;
      while (!got && t < 4000) begin @(posedge clk); if (nc_rsp_valid && nc_rsp_ready) begin rd = nc_rsp_rdata; errf = nc_rsp_error; got = 1; end t = t + 1; end
      if (!got) fail("nc response timeout");
    end
  endtask

  task automatic t14_noncoherent;
    reg [31:0] x, y; reg e; integer ref0;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      nc_allow = 0; nc_req_valid = 0; nc_rsp_ready = 1;
      // (a) gateway refuses a window access by default, no side effect
      ref0 = nc_c_ref;
      nc_do(1, A(2, 0), 32'hDEAD_BEEF, 4'hF, x, e);
      if (!e) fail("gateway accepted a coherent-window write while closed");
      if (nc_c_ref != ref0 + 1) fail("refusal not counted");
      ld(0, A(2, 0), r0);
      if (r0 === 32'hDEAD_BEEF) fail("refused NC write reached memory");
      // (b) outside the window: plain uncached access works with no maintenance
      nc_do(1, 32'h0000_0010, 32'h1234_5678, 4'hF, x, e);
      nc_do(0, 32'h0000_0010, 0, 4'hF, x, e);
      expect_eq(x, 32'h1234_5678, "uncached region read-back");
      // (c) NEGATIVE CONTROL: DMA writes the line while agent0 holds it Shared and nothing is maintained -> stale
      nc_allow = 1;
      ld(0, A(3, 0), r0);                                       // agent0 caches line 3
      chk_en = 0;                                               // the next steps violate the software contract ON PURPOSE
      nc_do(1, A(3, 0), 32'h5A5A_5A5A, 4'hF, x, e);             // DMA writes memory directly (no snoop)
      ld(0, A(3, 0), r1);
      if (r1 === 32'h5A5A_5A5A) fail("model error: non-coherent DMA write was visible without maintenance");
      else $display("   T14: stale read observed WITHOUT maintenance (%h, memory holds 5A5A5A5A) -- NON-COHERENT, as specified", r1);
      // golden model: the DMA write is outside the coherence domain; resynchronise the reference for the window it touched
      // (software contract: FLUSH by all agents before DMA, then reads after the hand-over)
      // (d) correct protocol: all agents FLUSH the line, DMA writes memory, agents then read -> current data
      flush(0, A(3, 0)); flush(1, A(3, 0));
      wait_quiet;
      nc_do(1, A(3, 1), 32'hC0FF_EE00, 4'hF, x, e);
      if (e) fail("permitted NC write refused");
      wait_quiet;
      chk.gold = mem_flat;                                      // hand-over complete: the reference adopts the DMA's data
      chk_en = 1;
      ld(0, A(3, 1), r0); expect_eq(r0, 32'hC0FF_EE00, "agent0 sees DMA data after FLUSH");
      ld(1, A(3, 1), r1); expect_eq(r1, 32'hC0FF_EE00, "agent1 sees DMA data after FLUSH");
      ld(1, A(3, 0), r1); expect_eq(r1, 32'h5A5A_5A5A, "agent1 sees the earlier DMA word after FLUSH");
      if (nc_c_wok < 2) fail("window_ok counter");
      nc_allow = 0;
      final_check("t14");
      report("T14 non-coherent DMA rules", e0, c0);
    end
  endtask

  // =====================================================================================================
  // reset, back-pressure, random
  // =====================================================================================================
  task automatic rand_agent(input integer a, input integer nops, input integer nlines_in);
    integer i, o, nlines; reg [31:0] r; reg e;
    begin
      nlines = (nlines_in > DIR_LINES) ? DIR_LINES : nlines_in;
      for (i = 0; i < nops && !abort_ops; i = i + 1) begin
        o = rnd(100);
        if (o < 42)      cpu_do(a, OP_LOAD,  A(rnd(nlines), rnd(WPL)), 32'd0, 4'hF, r, e);
        else if (o < 72) cpu_do(a, OP_STORE, A(rnd(nlines), rnd(WPL)), $random(rseed), (rnd(4) == 0) ? (4'h1 << rnd(4)) : 4'hF, r, e);
        else if (o < 82) cpu_do(a, OP_AMO,   A(rnd(nlines), rnd(WPL)), $random(rseed), 4'hF, r, e);
        else if (o < 92) cpu_do(a, OP_FLUSH, A(rnd(nlines), 0), 32'd0, 4'hF, r, e);
        else if (o < 94) cpu_do(a, OP_FENCE, BASE, 32'd0, 4'hF, r, e);
        else             delay(rnd(8));
        if (rnd(3) == 0) delay(rnd(4));
      end
    end
  endtask

  task automatic t07_backpressure;
    integer saved_stall, saved_cpu;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      fork rand_agent(0, QUICK ? 80 : 250, DIR_LINES); rand_agent(1 % NA, QUICK ? 80 : 250, DIR_LINES); join
      wait_quiet;
      final_check("t07");
      report("T07 back-pressure (all channels)", e0, c0);
    end
  endtask

  task automatic t08_reset;
    integer rep;
    begin
      e0 = tb_err; c0 = chk_err; snap;
      for (rep = 0; rep < 6; rep = rep + 1) begin
        do_reset;
        fork
          rand_agent(0, 200, 3);
          rand_agent(1 % NA, 200, 3);
          begin delay(20 + rnd(150)); abort_ops = 1; @(negedge clk); rst_n = 0; delay(1 + rnd(3)); @(negedge clk); rst_n = 1; delay(3); abort_ops = 0; end
        join
        // after reset: caches empty, directory uncached, no stale error bits, no open transaction
        wait_quiet;
        for (l_ = 0; l_ < DIR_LINES; l_ = l_ + 1) for (a_ = 0; a_ < NA; a_ = a_ + 1)
          if (rep >= 0 && cstate(a_, l_) !== CS_I && 0) fail("unreachable");
        expect_eq(dbg_slot_busy, 0, "no open transaction after reset");
        // the machine works after the reset: coherent traffic again
        ld(0, A(0, 0), r0); st(1, A(0, 0), 32'hAAAA_0000 + rep); ld(0, A(0, 0), r1);
        expect_eq(r1, 32'hAAAA_0000 + rep, "post-reset coherent exchange");
        wait_quiet;
      end
      final_check("t08");
      tests_run = tests_run + 1;
      $display("[T08 reset mid-flight] %s  (6 resets with traffic in flight; checker errs=%0d)", (tb_err == e0 && chk_err == c0) ? "PASS" : "FAIL", chk_err - c0);
    end
  endtask

  task automatic t15_random(input integer seed_off);
    integer a;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      rseed = SEED * 1000 + seed_off;
      fork
        rand_agent(0, RAND_OPS, 2);
        rand_agent(1 % NA, RAND_OPS, 2);
        begin if (NA > 2) rand_agent(2, RAND_OPS, 2); end
        begin if (NA > 3) rand_agent(3, RAND_OPS, 2); end
      join
      wait_quiet;
      final_check("t15");
      report("T15 random stress (same 2 lines)", e0, c0);
    end
  endtask

  task automatic t16_random_wide;
    begin
      do_reset; snap; e0 = tb_err; c0 = chk_err;
      fork
        rand_agent(0, RAND_OPS, DIR_LINES);
        rand_agent(1 % NA, RAND_OPS, DIR_LINES);
        begin if (NA > 2) rand_agent(2, RAND_OPS, DIR_LINES); end
        begin if (NA > 3) rand_agent(3, RAND_OPS, DIR_LINES); end
      join
      wait_quiet;
      final_check("t16");
      report("T16 random stress (all lines)", e0, c0);
    end
  endtask

  // =====================================================================================================
  initial begin
    rseed = SEED;
    cpu_req_valid = 0; cpu_op = 0; cpu_addr = 0; cpu_wdata = 0; cpu_wstrb = 0; cpu_rsp_ready = {NA{1'b1}};
    allow_req = {NA{1'b1}}; allow_rsp = {NA{1'b1}}; allow_snp = {NA{1'b1}}; allow_gnt = {NA{1'b1}};
    block_req = 0; block_rsp = 0; block_snp = 0; block_gnt = 0;
    nc_req_valid = 0; nc_req_write = 0; nc_req_addr = 0; nc_req_wdata = 0; nc_req_wstrb = 0; nc_rsp_ready = 1; nc_allow = 0;
    $display("tb_sf_coherence: NA=%0d DIR_LINES=%0d CACHE_SETS=%0d STALL_PCT=%0d CPU_STALL=%0d MEM_LAT_MAX=%0d MEM_READY=%0d SEED=%0d",
             NA, DIR_LINES, CACHE_SETS, STALL_PCT, CPU_STALL, MEM_LAT_MAX, MEM_READY, SEED);
    repeat (4) @(posedge clk);
    @(negedge clk); rst_n = 1;
    repeat (3) @(posedge clk);

    if (NA == 2 && DIR_LINES >= 8) begin
      t01_simultaneous_reads;
      t02_read_then_write;
      t03_competing_writers;
      t04_upgrade;
      t05_owner_eviction;
      t06_forwarding;
      t10_independent_lines;
      t11_writeback_race;
      t13_atomics_and_false_sharing;
      t14_noncoherent;
      if (!QUICK) t12_litmus;
    end
    t07_backpressure;
    t08_reset;
    if (DIR_LINES >= 8) t09_same_line_contention;
    t15_random(1);
    t16_random_wide;

    $display("----");
    $display("checker: %0d loads, %0d stores, %0d amos, %0d flushes performed; %0d grants; %0d memory writes; %0d quiescent-line invariant checks; checker errors %0d",
             chk_nload, chk_nstore, chk_namo, chk_nflush, chk_ngrants, chk_nmemwr, chk_nq, chk_err);
    $display("directory totals: GETS=%0d GETM=%0d UPG=%0d PUTS=%0d PUTM=%0d INV=%0d ownXfer=%0d dirtyInt=%0d stalePut=%0d retries=%0d busy=%0d",
             pd(PD_GETS), pd(PD_GETM), pd(PD_UPG), pd(PD_PUTS), pd(PD_PUTM), pd(PD_INV), pd(PD_OWN_XFER), pd(PD_DIRTY_INT),
             pd(PD_STALE_PUT), pd(PD_RETRIES), pd(PD_BUSY_CYC));
    if (tb_err == 0 && chk_err == 0) $display("TB RESULT: PASS (%0d tests)", tests_run);
    else                             $display("TB RESULT: FAIL (tb errors %0d, checker errors %0d)", tb_err, chk_err);
    $finish;
  end

  // global watchdog
  initial begin
    #200_000_000;
    $display("TB RESULT: FAIL (global timeout)");
    $finish;
  end
endmodule

`default_nettype wire
