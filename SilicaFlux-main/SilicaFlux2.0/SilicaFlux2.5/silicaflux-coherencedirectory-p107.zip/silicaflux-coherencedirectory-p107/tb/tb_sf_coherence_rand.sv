// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: tb_sf_coherence_rand  -- VERIFICATION-ONLY
//
// Fork-free, clocked random-traffic testbench (runs unchanged in Icarus Verilog AND Verilator): per-agent random FSMs issue
// LOAD / STORE (random byte strobes) / AMO / FLUSH / FENCE to a small set of shared lines, while random stalls hit every coherence
// channel, the CPU response and the memory; random RESETS hit mid-flight.  The reference checker watches every cycle.  After NOPS
// operations each agent flushes every line; the memory image must then equal the golden model and the directory must be UNC.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sf_coherence_rand;
  parameter int NA = 2;
  parameter int DIR_LINES = 8;
  parameter int CACHE_SETS = 1;
  parameter int STALL_PCT = 30;
  parameter int CPU_STALL = 20;
  parameter int MEM_LAT_MAX = 3;
  parameter int MEM_READY = 80;
  parameter int NOPS = 3000;
  parameter int NLINES = 3;
  parameter int RESETS = 4;           // number of mid-flight resets
  parameter int SEED = 1;
  localparam int LINE_BYTES = 64;
  localparam int LB = 512;
  localparam int LIW = $clog2(DIR_LINES);
  localparam int AIW = (NA > 1) ? $clog2(NA) : 1;
  localparam int ENTW = 2 + NA + AIW;
  localparam int WIW = 4;
  localparam [31:0] BASE = 32'h8000_0000;
  import sf_coherence_pkg::*;

  reg clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  reg  [NA-1:0] cpu_req_valid; wire [NA-1:0] cpu_req_ready; reg [NA*3-1:0] cpu_op; reg [NA*32-1:0] cpu_addr, cpu_wdata;
  reg  [NA*4-1:0] cpu_wstrb; wire [NA-1:0] cpu_rsp_valid; reg [NA-1:0] cpu_rsp_ready; wire [NA*32-1:0] cpu_rdata; wire [NA-1:0] cpu_rsp_err;
  wire mem_req_valid, mem_req_ready, mem_req_wr, mem_rsp_valid, mem_rsp_ready; wire [LIW-1:0] mem_req_line; wire [LB-1:0] mem_req_wdata, mem_rsp_rdata;
  reg  [NA-1:0] al_req, al_rsp, al_snp, al_gnt;
  wire [DIR_LINES*ENTW-1:0] dbg_dir; wire [NA*3-1:0] dbg_slot_state, dbg_slot_type, dbg_slot_gtype; wire [NA*LIW-1:0] dbg_slot_line;
  wire [NA-1:0] dbg_slot_busy, dbg_slot_wait, dbg_mem_wr_perf; wire [NA*NA-1:0] dbg_slot_waiting; wire [NA*2-1:0] dbg_slot_gk;
  wire [NA*LB-1:0] dbg_slot_data; wire [DE_W-1:0] dbg_dir_err; wire [NA*AE_W-1:0] dbg_agent_err;
  wire [PD_N*32-1:0] perf_dir; wire [NA*PA_N*32-1:0] perf_agent; wire [NA*2-1:0] dbg_a_st;
  wire [NA*CACHE_SETS*2-1:0] dbg_cs_all; wire [NA*CACHE_SETS*LIW-1:0] dbg_tag_all; wire [NA*CACHE_SETS*LB-1:0] dbg_data_all;
  wire [NA*3-1:0] dbg_p_st; wire [NA*LIW-1:0] dbg_p_line; wire [NA-1:0] dbg_p_lost; wire [NA*LB-1:0] dbg_p_data;
  wire [NA-1:0] ev_perf_v, ev_perf_wr; wire [NA*LIW-1:0] ev_perf_line; wire [NA*WIW-1:0] ev_perf_word; wire [NA*32-1:0] ev_perf_rdata;
  wire [NA*LB-1:0] ev_perf_newline, ev_perf_oldline; wire [NA-1:0] mon_req_hs, mon_rsp_hs, mon_snp_hs, mon_gnt_hs;

  sf_coherence_subsystem #(.N_AGENTS(NA), .DIR_LINES(DIR_LINES), .CACHE_SETS(CACHE_SETS), .LINE_BYTES(LINE_BYTES), .COH_BASE(BASE)) dut (
    .clk(clk), .rst_n(rst_n), .cpu_req_valid(cpu_req_valid), .cpu_req_ready(cpu_req_ready), .cpu_op(cpu_op), .cpu_addr(cpu_addr),
    .cpu_wdata(cpu_wdata), .cpu_wstrb(cpu_wstrb), .cpu_rsp_valid(cpu_rsp_valid), .cpu_rsp_ready(cpu_rsp_ready), .cpu_rdata(cpu_rdata),
    .cpu_rsp_err(cpu_rsp_err), .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready), .mem_req_wr(mem_req_wr),
    .mem_req_line(mem_req_line), .mem_req_wdata(mem_req_wdata), .mem_rsp_valid(mem_rsp_valid), .mem_rsp_ready(mem_rsp_ready),
    .mem_rsp_rdata(mem_rsp_rdata), .chan_allow_req(al_req), .chan_allow_rsp(al_rsp), .chan_allow_snp(al_snp), .chan_allow_gnt(al_gnt),
    .dbg_dir(dbg_dir), .dbg_slot_state(dbg_slot_state), .dbg_slot_line(dbg_slot_line), .dbg_slot_type(dbg_slot_type),
    .dbg_slot_busy(dbg_slot_busy), .dbg_slot_waiting(dbg_slot_waiting), .dbg_slot_gtype(dbg_slot_gtype), .dbg_slot_gk(dbg_slot_gk),
    .dbg_slot_data(dbg_slot_data), .dbg_slot_wait(dbg_slot_wait), .dbg_mem_wr_perf(dbg_mem_wr_perf), .dbg_dir_err(dbg_dir_err),
    .dbg_agent_err(dbg_agent_err), .perf_dir(perf_dir), .perf_agent(perf_agent), .dbg_a_st(dbg_a_st), .dbg_cs_all(dbg_cs_all),
    .dbg_tag_all(dbg_tag_all), .dbg_data_all(dbg_data_all), .dbg_p_st(dbg_p_st), .dbg_p_line(dbg_p_line), .dbg_p_lost(dbg_p_lost),
    .dbg_p_data(dbg_p_data), .ev_perf_v(ev_perf_v), .ev_perf_wr(ev_perf_wr), .ev_perf_line(ev_perf_line), .ev_perf_word(ev_perf_word),
    .ev_perf_rdata(ev_perf_rdata), .ev_perf_newline(ev_perf_newline), .ev_perf_oldline(ev_perf_oldline),
    .mon_req_hs(mon_req_hs), .mon_rsp_hs(mon_rsp_hs), .mon_snp_hs(mon_snp_hs), .mon_gnt_hs(mon_gnt_hs), .dbg_chan());

  wire [DIR_LINES*LB-1:0] mem_flat; wire [31:0] s0, s1;
  sf_coh_mem_model #(.DIR_LINES(DIR_LINES), .LINE_BYTES(LINE_BYTES), .RD_LAT_MIN(1), .RD_LAT_MAX(MEM_LAT_MAX), .WR_LAT_MIN(1),
    .WR_LAT_MAX(MEM_LAT_MAX), .READY_PCT(MEM_READY), .SEED(SEED + 5), .COH_BASE(BASE)) mem (
    .clk(clk), .rst_n(rst_n), .l_req_valid(mem_req_valid), .l_req_ready(mem_req_ready), .l_req_wr(mem_req_wr), .l_req_line(mem_req_line),
    .l_req_wdata(mem_req_wdata), .l_rsp_valid(mem_rsp_valid), .l_rsp_ready(mem_rsp_ready), .l_rsp_rdata(mem_rsp_rdata),
    .w_req_valid(1'b0), .w_req_ready(), .w_req_write(1'b0), .w_req_addr(32'd0), .w_req_wdata(32'd0), .w_req_wstrb(4'd0),
    .w_rsp_valid(), .w_rsp_ready(1'b1), .w_rsp_rdata(), .w_rsp_error(), .mem_flat(mem_flat), .st_line_rd(s0), .st_line_wr(s1));

  wire [31:0] chk_err, c1, c2, c3, c4, c5, c6, c7;
  sf_coh_checker #(.N_AGENTS(NA), .DIR_LINES(DIR_LINES), .CACHE_SETS(CACHE_SETS), .LINE_BYTES(LINE_BYTES), .COH_BASE(BASE)) chk (
    .clk(clk), .rst_n(rst_n), .enable(1'b1), .cpu_req_valid(cpu_req_valid), .cpu_req_ready(cpu_req_ready), .cpu_op(cpu_op),
    .cpu_addr(cpu_addr), .cpu_wdata(cpu_wdata), .cpu_wstrb(cpu_wstrb), .cpu_rsp_valid(cpu_rsp_valid), .cpu_rsp_ready(cpu_rsp_ready),
    .cpu_rdata(cpu_rdata), .cpu_rsp_err(cpu_rsp_err), .ev_perf_v(ev_perf_v), .ev_perf_wr(ev_perf_wr), .ev_perf_line(ev_perf_line),
    .ev_perf_word(ev_perf_word), .ev_perf_rdata(ev_perf_rdata), .ev_perf_newline(ev_perf_newline), .ev_perf_oldline(ev_perf_oldline),
    .dbg_cs_all(dbg_cs_all), .dbg_tag_all(dbg_tag_all), .dbg_data_all(dbg_data_all), .dbg_p_st(dbg_p_st), .dbg_p_line(dbg_p_line),
    .dbg_p_lost(dbg_p_lost), .dbg_p_data(dbg_p_data), .dbg_dir(dbg_dir), .dbg_slot_state(dbg_slot_state), .dbg_slot_line(dbg_slot_line),
    .dbg_slot_busy(dbg_slot_busy), .dbg_slot_waiting(dbg_slot_waiting), .dbg_slot_gtype(dbg_slot_gtype), .dbg_slot_data(dbg_slot_data),
    .mon_gnt_hs(mon_gnt_hs), .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready), .mem_req_wr(mem_req_wr),
    .mem_req_line(mem_req_line), .mem_req_wdata(mem_req_wdata), .mem_flat(mem_flat), .dir_err(dbg_dir_err), .agent_err(dbg_agent_err),
    .err_cnt(chk_err), .n_load(c1), .n_store(c2), .n_amo(c3), .n_flush(c4), .n_grants(c5), .n_memwr(c6), .n_quiescent_line_checks(c7));

  // ---------------------------------------------------------------- xorshift PRNG (identical in every simulator)
  function [31:0] xs(input [31:0] x);
    reg [31:0] y;
    begin y = x ^ (x << 13); y = y ^ (y >> 17); y = y ^ (y << 5); xs = y; end
  endfunction
  integer stall_v, cpustall_v, nops_v, seed_v, nlines_v;   // runtime knobs (plusargs +SEED= +STALL= +CPUSTALL= +NOPS= +NLINES=)
  reg [31:0] prng;           // global stall / reset generator
  reg [31:0] ar [0:NA-1];    // per-agent generator
  integer    done_cnt [0:NA-1];
  integer    gap [0:NA-1];
  integer    phase [0:NA-1];   // 0 random ops, 1 final flush sweep, 2 finished
  integer    sweep [0:NA-1];
  integer    st [0:NA-1];      // 0 idle, 1 request presented, 2 waiting response
  integer    cyc;
  integer    resets_left;
  integer    next_reset;
  integer    a, k;
  reg [31:0] r, r2, r3, r4;
  integer    errors;
  reg        fin;
  integer    tcount;
  integer    lat_c [0:NA-1];
  integer    max_lat;
  integer    n_lat;
  integer    sum_lat;

  initial begin
    stall_v = STALL_PCT; cpustall_v = CPU_STALL; nops_v = NOPS; seed_v = SEED; nlines_v = NLINES;
    if ($value$plusargs("SEED=%d", seed_v)) ;
    if ($value$plusargs("STALL=%d", stall_v)) ;
    if ($value$plusargs("CPUSTALL=%d", cpustall_v)) ;
    if ($value$plusargs("NOPS=%d", nops_v)) ;
    if ($value$plusargs("NLINES=%d", nlines_v)) ;
    prng = 32'h1234_5678 ^ (seed_v * 32'h9E37_79B9);
    for (a = 0; a < NA; a = a + 1) begin
      ar[a] = 32'hA5A5_0001 + a * 32'h0101_0101 + seed_v * 32'h0000_1357;
      done_cnt[a] = 0; gap[a] = 0; phase[a] = 0; sweep[a] = 0; st[a] = 0;
    end
    cpu_req_valid = 0; cpu_op = 0; cpu_addr = 0; cpu_wdata = 0; cpu_wstrb = 0; cpu_rsp_ready = {NA{1'b1}};
    al_req = {NA{1'b1}}; al_rsp = {NA{1'b1}}; al_snp = {NA{1'b1}}; al_gnt = {NA{1'b1}};
    cyc = 0; resets_left = RESETS; next_reset = 300; errors = 0; fin = 0; tcount = 0; max_lat = 0; n_lat = 0; sum_lat = 0;
    for (a = 0; a < NA; a = a + 1) lat_c[a] = 0;
  end

  // reset sequencing: power-on reset, then random mid-flight resets while traffic runs
  integer rst_cnt = 6;
  always @(posedge clk) begin
    cyc <= cyc + 1;
    if (rst_cnt > 0) begin rst_cnt <= rst_cnt - 1; rst_n <= 1'b0; end
    else begin
      rst_n <= 1'b1;
      if (resets_left > 0 && cyc >= next_reset && phase[0] == 0) begin
        resets_left <= resets_left - 1;
        rst_cnt <= 2 + (prng % 3);
        next_reset <= cyc + 400 + (prng % 900);
      end
    end
  end

  always @(posedge clk) begin
    prng <= xs(prng);
    // stall injection (registered: applies to the NEXT cycle's handshakes)
    for (k = 0; k < NA; k = k + 1) begin
      al_req[k] <= ((xs(prng + k + 1)  % 100) >= stall_v);
      al_rsp[k] <= ((xs(prng + k + 11) % 100) >= stall_v);
      al_snp[k] <= ((xs(prng + k + 21) % 100) >= stall_v);
      al_gnt[k] <= ((xs(prng + k + 31) % 100) >= stall_v);
      cpu_rsp_ready[k] <= ((xs(prng + k + 41) % 100) >= cpustall_v);
    end
  end

  // per-agent random FSMs
  always @(posedge clk) begin
    for (a = 0; a < NA; a = a + 1) begin
      if (!rst_n) begin
        cpu_req_valid[a] <= 1'b0; st[a] <= 0; gap[a] <= 0;
        if (phase[a] == 1) sweep[a] <= 0;     // restart the sweep after a reset
      end else begin
        ar[a] <= xs(ar[a]);
        case (st[a])
          0: begin
            lat_c[a] <= 0;
            if (gap[a] > 0) gap[a] <= gap[a] - 1;
            else if (phase[a] == 0) begin
              r = xs(ar[a]); r2 = xs(r); r3 = xs(r2); r4 = xs(r3);
              ar[a] <= r4;
              cpu_req_valid[a] <= 1'b1; st[a] <= 1;
              cpu_addr[a*32 +: 32] <= BASE + ((r2 % nlines_v) * LINE_BYTES) + (((r3 >> 8) % 16) * 4);
              cpu_wdata[a*32 +: 32] <= r4;
              cpu_wstrb[a*4 +: 4] <= (r3[3:0] < 4'd4) ? (4'h1 << r3[5:4]) : 4'hF;
              if      ((r % 100) < 40) cpu_op[a*3 +: 3] <= OP_LOAD;
              else if ((r % 100) < 72) cpu_op[a*3 +: 3] <= OP_STORE;
              else if ((r % 100) < 84) cpu_op[a*3 +: 3] <= OP_AMO;
              else if ((r % 100) < 95) cpu_op[a*3 +: 3] <= OP_FLUSH;
              else                     cpu_op[a*3 +: 3] <= OP_FENCE;
              gap[a] <= ((r >> 20) % 4 == 0) ? ((r >> 24) % 6) : 0;
            end else if (phase[a] == 1) begin
              cpu_req_valid[a] <= 1'b1; st[a] <= 1;
              cpu_op[a*3 +: 3] <= OP_FLUSH;
              cpu_addr[a*32 +: 32] <= BASE + sweep[a] * LINE_BYTES;
              cpu_wdata[a*32 +: 32] <= 32'd0; cpu_wstrb[a*4 +: 4] <= 4'hF;
            end
          end
          1: begin lat_c[a] <= lat_c[a] + 1; if (cpu_req_ready[a]) begin cpu_req_valid[a] <= 1'b0; st[a] <= 2; end end
          2: begin lat_c[a] <= lat_c[a] + 1; if (cpu_rsp_valid[a] && cpu_rsp_ready[a]) begin
               if (phase[a] == 0) begin if (lat_c[a] + 1 > max_lat) max_lat <= lat_c[a] + 1; n_lat <= n_lat + 1; sum_lat <= sum_lat + lat_c[a] + 1; end
               st[a] <= 0;
               if (phase[a] == 0) begin
                 done_cnt[a] <= done_cnt[a] + 1;
                 if (done_cnt[a] + 1 >= nops_v) phase[a] <= 1;
               end else if (phase[a] == 1) begin
                 sweep[a] <= sweep[a] + 1;
                 if (sweep[a] + 1 >= DIR_LINES) phase[a] <= 2;
               end
             end end
        endcase
      end
    end
  end

  // completion: every agent finished its sweep, directory idle -> compare memory with the golden model
  reg all_done;
  integer settle = 0;
  integer l;
  always @(posedge clk) begin
    all_done = 1;
    for (a = 0; a < NA; a = a + 1) if (phase[a] != 2) all_done = 0;
    tcount <= tcount + 1;
    if (all_done && rst_n && dbg_slot_busy == 0 && dbg_a_st == 0 && !mem_req_valid && !mem_rsp_valid) settle <= settle + 1; else settle <= 0;
    if (settle == 20 && !fin) begin
      fin = 1;
      errors = 0;
      if (mem_flat !== chk.gold) begin errors = errors + 1; $display("RAND FAIL: memory image != golden model after the final flush"); end
      for (l = 0; l < DIR_LINES; l = l + 1) if (dbg_dir[l*ENTW +: 2] !== DS_UNC) begin errors = errors + 1; $display("RAND FAIL: line %0d not UNC", l); end
      if (chk_err != 0) errors = errors + 1;
      $display("RAND: NA=%0d sets=%0d stall=%0d%% cpustall=%0d%% memlat<=%0d seed=%0d : %0d loads %0d stores %0d amos %0d flushes, %0d grants, %0d memory writes, resets=%0d, %0d cycles, %0d quiescent-line checks, checker errors %0d",
               NA, CACHE_SETS, stall_v, cpustall_v, MEM_LAT_MAX, seed_v, c1, c2, c3, c4, c5, c6, RESETS - resets_left, tcount, c7, chk_err);
      $display("RAND LATENCY: %0d operations, max %0d cycles, mean %0d cycles (request presented -> response taken, random stalls)", n_lat, max_lat, (n_lat > 0) ? sum_lat / n_lat : 0);
      $display("RAND RESULT: %s", (errors == 0) ? "PASS" : "FAIL");
      $finish;
    end
    if (tcount > 3_000_000) begin $display("RAND RESULT: FAIL (timeout: agents %0d/%0d ops phase %0d,%0d)", done_cnt[0], nops_v, phase[0], phase[NA-1]); $finish; end
  end
endmodule
`default_nettype wire
