// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: tb_sf_coherence_bench  -- VERIFICATION-ONLY
//
// Coherence-traffic benchmark.  Runs eight sharing patterns on NA agents (the reference checker stays on, so every number
// comes from a run whose data was verified) and prints one CSV row per workload with the directory and agent counters:
//   shared reads (GETS), exclusive requests (GETM), upgrades, invalidations, ownership transfers, dirty interventions,
//   coherence stalls, directory lookups, traffic bytes per channel and at the memory port, protocol retries.
// Cycle counts are RTL simulation cycles of the testbench configuration (memory latency MEM_LAT); they are not silicon timing.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sf_coherence_lat;
  parameter int NA = 2;
  parameter int DIR_LINES = 16;
  parameter int CACHE_SETS = 4;
  parameter int MEM_LAT = 1;
  parameter int ITER = 64;
  parameter int SEED = 1;
  localparam int LINE_BYTES = 64;
  localparam int LB = 512;
  localparam int LIW = $clog2(DIR_LINES);
  localparam int AIW = (NA > 1) ? $clog2(NA) : 1;
  localparam int ENTW = 2 + NA + AIW;
  localparam int WPL = 16;
  localparam int WIW = 4;
  localparam [31:0] BASE = 32'h8000_0000;
  import sf_coherence_pkg::*;

  reg clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  integer cycle = 0;
  always @(posedge clk) cycle <= cycle + 1;

  reg  [NA-1:0] cpu_req_valid; wire [NA-1:0] cpu_req_ready; reg [NA*3-1:0] cpu_op; reg [NA*32-1:0] cpu_addr, cpu_wdata;
  reg  [NA*4-1:0] cpu_wstrb; wire [NA-1:0] cpu_rsp_valid; reg [NA-1:0] cpu_rsp_ready; wire [NA*32-1:0] cpu_rdata; wire [NA-1:0] cpu_rsp_err;
  wire mem_req_valid, mem_req_ready, mem_req_wr, mem_rsp_valid, mem_rsp_ready; wire [LIW-1:0] mem_req_line; wire [LB-1:0] mem_req_wdata, mem_rsp_rdata;
  wire [DIR_LINES*ENTW-1:0] dbg_dir; wire [NA*3-1:0] dbg_slot_state, dbg_slot_type, dbg_slot_gtype; wire [NA*LIW-1:0] dbg_slot_line;
  wire [NA-1:0] dbg_slot_busy, dbg_slot_wait, dbg_mem_wr_perf; wire [NA*NA-1:0] dbg_slot_waiting; wire [NA*2-1:0] dbg_slot_gk;
  wire [NA*LB-1:0] dbg_slot_data; wire [DE_W-1:0] dbg_dir_err; wire [NA*AE_W-1:0] dbg_agent_err;
  wire [PD_N*32-1:0] perf_dir; wire [NA*PA_N*32-1:0] perf_agent; wire [NA*2-1:0] dbg_a_st;
  wire [NA*CACHE_SETS*2-1:0] dbg_cs_all; wire [NA*CACHE_SETS*LIW-1:0] dbg_tag_all; wire [NA*CACHE_SETS*LB-1:0] dbg_data_all;
  wire [NA*3-1:0] dbg_p_st; wire [NA*LIW-1:0] dbg_p_line; wire [NA-1:0] dbg_p_lost; wire [NA*LB-1:0] dbg_p_data;
  wire [NA-1:0] ev_perf_v, ev_perf_wr; wire [NA*LIW-1:0] ev_perf_line; wire [NA*WIW-1:0] ev_perf_word; wire [NA*32-1:0] ev_perf_rdata;
  wire [NA*LB-1:0] ev_perf_newline, ev_perf_oldline; wire [NA-1:0] mon_req_hs, mon_rsp_hs, mon_snp_hs, mon_gnt_hs;

  sf_coherence_subsystem #(.N_AGENTS(NA), .DIR_LINES(DIR_LINES), .CACHE_SETS(CACHE_SETS), .LINE_BYTES(LINE_BYTES), .COH_BASE(BASE)) dut (
    .clk(clk), .rst_n(rst_n), .cpu_req_valid(cpu_req_valid), .cpu_req_ready(cpu_req_ready), .cpu_op(cpu_op), .cpu_addr(cpu_addr),
    .cpu_wdata(cpu_wdata), .cpu_wstrb(cpu_wstrb), .cpu_rsp_valid(cpu_rsp_valid), .cpu_rsp_ready(cpu_rsp_ready), .cpu_rdata(cpu_rdata),
    .cpu_rsp_err(cpu_rsp_err), .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready), .mem_req_wr(mem_req_wr),
    .mem_req_line(mem_req_line), .mem_req_wdata(mem_req_wdata), .mem_rsp_valid(mem_rsp_valid), .mem_rsp_ready(mem_rsp_ready),
    .mem_rsp_rdata(mem_rsp_rdata), .chan_allow_req({NA{1'b1}}), .chan_allow_rsp({NA{1'b1}}), .chan_allow_snp({NA{1'b1}}),
    .chan_allow_gnt({NA{1'b1}}), .dbg_dir(dbg_dir), .dbg_slot_state(dbg_slot_state), .dbg_slot_line(dbg_slot_line),
    .dbg_slot_type(dbg_slot_type), .dbg_slot_busy(dbg_slot_busy), .dbg_slot_waiting(dbg_slot_waiting), .dbg_slot_gtype(dbg_slot_gtype),
    .dbg_slot_gk(dbg_slot_gk), .dbg_slot_data(dbg_slot_data), .dbg_slot_wait(dbg_slot_wait), .dbg_mem_wr_perf(dbg_mem_wr_perf),
    .dbg_dir_err(dbg_dir_err), .dbg_agent_err(dbg_agent_err), .perf_dir(perf_dir), .perf_agent(perf_agent), .dbg_a_st(dbg_a_st),
    .dbg_cs_all(dbg_cs_all), .dbg_tag_all(dbg_tag_all), .dbg_data_all(dbg_data_all), .dbg_p_st(dbg_p_st), .dbg_p_line(dbg_p_line),
    .dbg_p_lost(dbg_p_lost), .dbg_p_data(dbg_p_data), .ev_perf_v(ev_perf_v), .ev_perf_wr(ev_perf_wr), .ev_perf_line(ev_perf_line),
    .ev_perf_word(ev_perf_word), .ev_perf_rdata(ev_perf_rdata), .ev_perf_newline(ev_perf_newline), .ev_perf_oldline(ev_perf_oldline),
    .mon_req_hs(mon_req_hs), .mon_rsp_hs(mon_rsp_hs), .mon_snp_hs(mon_snp_hs), .mon_gnt_hs(mon_gnt_hs));

  wire [DIR_LINES*LB-1:0] mem_flat; wire [31:0] s0, s1;
  sf_coh_mem_model #(.DIR_LINES(DIR_LINES), .LINE_BYTES(LINE_BYTES), .RD_LAT_MIN(MEM_LAT), .RD_LAT_MAX(MEM_LAT), .WR_LAT_MIN(MEM_LAT),
    .WR_LAT_MAX(MEM_LAT), .READY_PCT(100), .SEED(SEED), .COH_BASE(BASE)) mem (
    .clk(clk), .rst_n(rst_n), .l_req_valid(mem_req_valid), .l_req_ready(mem_req_ready), .l_req_wr(mem_req_wr), .l_req_line(mem_req_line),
    .l_req_wdata(mem_req_wdata), .l_rsp_valid(mem_rsp_valid), .l_rsp_ready(mem_rsp_ready), .l_rsp_rdata(mem_rsp_rdata),
    .w_req_valid(1'b0), .w_req_ready(), .w_req_write(1'b0), .w_req_addr(32'd0), .w_req_wdata(32'd0), .w_req_wstrb(4'd0),
    .w_rsp_valid(), .w_rsp_ready(1'b1), .w_rsp_rdata(), .w_rsp_error(), .mem_flat(mem_flat), .st_line_rd(s0), .st_line_wr(s1));

  wire [31:0] chk_err, c1, c2, c3, c4, c5, c6, c7, c8;
  sf_coh_checker #(.N_AGENTS(NA), .DIR_LINES(DIR_LINES), .CACHE_SETS(CACHE_SETS), .LINE_BYTES(LINE_BYTES), .COH_BASE(BASE)) chk (
    .clk(clk), .rst_n(rst_n), .enable(1'b1), .cpu_req_valid(cpu_req_valid), .cpu_req_ready(cpu_req_ready), .cpu_op(cpu_op),
    .cpu_addr(cpu_addr), .cpu_wdata(cpu_wdata), .cpu_wstrb(cpu_wstrb), .cpu_rsp_valid(cpu_rsp_valid), .cpu_rsp_ready(cpu_rsp_ready),
    .cpu_rdata(cpu_rdata), .cpu_rsp_err(cpu_rsp_err), .ev_perf_v(ev_perf_v), .ev_perf_wr(ev_perf_wr), .ev_perf_line(ev_perf_line),
    .ev_perf_word(ev_perf_word), .ev_perf_rdata(ev_perf_rdata), .ev_perf_newline(ev_perf_newline), .ev_perf_oldline(ev_perf_oldline),
    .dbg_cs_all(dbg_cs_all), .dbg_tag_all(dbg_tag_all), .dbg_data_all(dbg_data_all), .dbg_p_st(dbg_p_st), .dbg_p_line(dbg_p_line),
    .dbg_p_lost(dbg_p_lost), .dbg_p_data(dbg_p_data), .dbg_dir(dbg_dir), .dbg_slot_state(dbg_slot_state), .dbg_slot_line(dbg_slot_line),
    .dbg_slot_busy(dbg_slot_busy), .dbg_slot_waiting(dbg_slot_waiting), .dbg_slot_gtype(dbg_slot_gtype), .dbg_slot_data(dbg_slot_data),
    .mon_gnt_hs(mon_gnt_hs), .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready), .mem_req_wr(mem_req_wr),
    .mem_req_line(mem_req_line), .mem_req_wdata(mem_req_wdata), .mem_flat(mem_flat), .dir_err(dbg_dir_err), .agent_err(dbg_agent_err),
    .err_cnt(chk_err), .n_load(c1), .n_store(c2), .n_amo(c3), .n_flush(c4), .n_grants(c5), .n_memwr(c6), .n_quiescent_line_checks(c7));

  integer rseed = 1;
  function integer rnd(input integer n); integer v; begin v = $random(rseed); if (v < 0) v = -v; rnd = (n > 0) ? v % n : 0; end endfunction
  function [31:0] A(input integer line, input integer word); A = BASE + line * LINE_BYTES + word * 4; endfunction

  integer nops;                         // operations completed in the workload
  integer lat_sum;
  task automatic cpu_do(input integer a, input [2:0] op, input [31:0] addr, input [31:0] wd);
    integer t0;
    begin
      t0 = cycle;
      @(negedge clk); cpu_req_valid[a] = 1; cpu_op[a*3 +: 3] = op; cpu_addr[a*32 +: 32] = addr; cpu_wdata[a*32 +: 32] = wd; cpu_wstrb[a*4 +: 4] = 4'hF;
      @(posedge clk); while (!cpu_req_ready[a]) @(posedge clk);
      @(negedge clk); cpu_req_valid[a] = 0;
      @(posedge clk); while (!cpu_rsp_valid[a]) @(posedge clk);
      nops = nops + 1; lat_sum = lat_sum + (cycle - t0);
    end
  endtask
  task automatic ld(input integer a, input integer l, input integer w); cpu_do(a, OP_LOAD, A(l, w), 0); endtask
  task automatic st(input integer a, input integer l, input integer w, input [31:0] d); cpu_do(a, OP_STORE, A(l, w), d); endtask
  task automatic am(input integer a, input integer l, input integer w); cpu_do(a, OP_AMO, A(l, w), 1); endtask
  task automatic fl(input integer a, input integer l); cpu_do(a, OP_FLUSH, A(l, 0), 0); endtask
  function integer pd(input integer i); pd = perf_dir[i*32 +: 32]; endfunction
  function integer pa(input integer a, input integer i); pa = perf_agent[(a*PA_N + i)*32 +: 32]; endfunction

  task automatic quiet; integer t; begin t = 0; while (((dbg_slot_busy != 0) || (dbg_slot_wait != 0) || (dbg_a_st != 0)) && t < 3000) begin @(posedge clk); t = t + 1; end repeat (4) @(posedge clk); end endtask
  task automatic reset; begin @(negedge clk); rst_n = 0; repeat (3) @(negedge clk); rst_n = 1; repeat (2) @(posedge clk); end endtask

  integer c_start, ha, wa, a2, wl;
  task automatic emit(input [8*24-1:0] name);
    integer hits, waitc;
    begin
      quiet;
      hits = 0; waitc = 0;
      for (a2 = 0; a2 < NA; a2 = a2 + 1) begin hits = hits + pa(a2, PA_HITS); waitc = waitc + pa(a2, PA_WAIT_CYC); end
      $display("CSV,%0s,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
        name, NA, CACHE_SETS, MEM_LAT, nops, cycle - c_start, lat_sum,
        pd(PD_GETS), pd(PD_GETM), pd(PD_UPG), pd(PD_PUTS), pd(PD_PUTM), pd(PD_INV), pd(PD_OWN_XFER), pd(PD_DIRTY_INT), pd(PD_LOOKUPS),
        pd(PD_STALL_CONF), pd(PD_STALL_GATH), pd(PD_RETRIES), pd(PD_BYTES_REQ), pd(PD_BYTES_RSP), pd(PD_BYTES_SNP), pd(PD_BYTES_GNT),
        pd(PD_MEM_RD_B), pd(PD_MEM_WR_B), hits, pd(PD_BUSY_CYC));
      if (chk_err != 0) $display("BENCH CHECKER ERRORS: %0d", chk_err);
    end
  endtask
  task automatic begin_wl; begin reset; nops = 0; lat_sum = 0; c_start = cycle; end endtask

  // latency of ONE operation: cycles from the request being presented to the response being valid (no stalls)
  integer lat;
  task automatic timed(input integer a, input [2:0] op, input [31:0] addr, input [31:0] wd);
    integer t0;
    begin
      t0 = cycle;
      @(negedge clk); cpu_req_valid[a] = 1; cpu_op[a*3 +: 3] = op; cpu_addr[a*32 +: 32] = addr; cpu_wdata[a*32 +: 32] = wd; cpu_wstrb[a*4 +: 4] = 4'hF;
      @(posedge clk); while (!cpu_req_ready[a]) @(posedge clk);
      @(negedge clk); cpu_req_valid[a] = 0;
      @(posedge clk); while (!cpu_rsp_valid[a]) @(posedge clk);
      lat = cycle - t0;
      @(posedge clk);
    end
  endtask
  task automatic show(input [8*64-1:0] what); begin $display("LAT,%0s,%0d", what, lat); end endtask
  initial begin
    cpu_req_valid = 0; cpu_op = 0; cpu_addr = 0; cpu_wdata = 0; cpu_wstrb = 0; cpu_rsp_ready = {NA{1'b1}};
    repeat (3) @(posedge clk); @(negedge clk); rst_n = 1; repeat (3) @(posedge clk);
    reset; timed(0, OP_LOAD, A(0,0), 0);  show("GETS, line uncached (cold miss)");
    timed(0, OP_LOAD, A(0,1), 0);         show("load hit");
    timed(0, OP_STORE, A(0,2), 32'h1);    show("store, line Shared, no other sharer (UPG)");
    timed(0, OP_STORE, A(0,3), 32'h2);    show("store hit (Modified)");
    reset; timed(0, OP_STORE, A(1,0), 1); show("GETM, line uncached");
    timed(1, OP_LOAD, A(1,0), 0);         show("load of a line Modified elsewhere (FWD_S)");
    reset; timed(0, OP_LOAD, A(2,0), 0); timed(1, OP_LOAD, A(2,0), 0); timed(0, OP_STORE, A(2,0), 9); show("upgrade with 1 other sharer (INV)");
    reset; timed(0, OP_STORE, A(3,0), 1); timed(1, OP_STORE, A(3,0), 2); show("store to a line Modified elsewhere (FWD_M)");
    reset; timed(0, OP_STORE, A(4,0), 1); timed(0, OP_FLUSH, A(4,0), 0); show("FLUSH of a Modified line (PUTM + memory write)");
    reset; timed(0, OP_LOAD, A(5,0), 0); timed(0, OP_FLUSH, A(5,0), 0); show("FLUSH of a Shared line (PUTS)");
    reset; timed(0, OP_STORE, A(6,0), 1); timed(0, OP_LOAD, A(7,0), 0); show("miss that evicts a Modified victim (set conflict, 1 set)");
    $finish;
  end
endmodule
`default_nettype wire
