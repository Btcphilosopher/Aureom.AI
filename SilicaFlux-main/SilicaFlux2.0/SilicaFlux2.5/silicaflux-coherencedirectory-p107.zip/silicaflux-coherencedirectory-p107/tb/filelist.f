# verification-only sources (after rtl/coherence/filelist.f)
sf_coh_mem_model.sv
sf_coh_checker.sv
tb_sf_coherence.sv        # directed + random system test (Icarus Verilog: uses fork/join)
# tb_sf_coherence_rand.sv # fork-free random test (Icarus and Verilator)
# tb_sf_coherence_bench.sv, tb_sf_coherence_lat.sv : benchmark / latency
