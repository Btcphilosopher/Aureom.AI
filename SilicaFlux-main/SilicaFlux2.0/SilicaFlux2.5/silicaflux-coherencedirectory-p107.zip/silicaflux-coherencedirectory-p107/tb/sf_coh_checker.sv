// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: sf_coh_checker  -- VERIFICATION-ONLY
//
// (1) MEMORY-COHERENCE REFERENCE MODEL (golden memory).  It watches the CPU ports, recomputes the architectural
//     effect of every accepted operation on its own copy of the coherent window ("gold": the latest value of every
//     line in the per-location write order) and compares:
//        - the whole line each agent found when it performed the operation  == gold          (NO STALE DATA)
//        - the line it produced and the value returned to the CPU            == recomputed result
//        - every operation is performed exactly once before its response    (NO DUPLICATE / MISSING COMPLETION)
//        - every line written to memory (writeback / intervention)           == gold          (NO STALE WRITEBACK)
//        - every fill / grant data presented by the directory                == gold
// (2) PROTOCOL INVARIANTS checked on the cycle-by-cycle state of caches and directory:
//        SWMR (at most one Modified owner; no Shared copy alongside an owner), exact directory at quiescence,
//        ownership granted only after all invalidations, one open transaction per line, one completion per grant,
//        no sticky error bit.
//
// The same module is the property set of the formal environment (`FORMAL defined: failures are `assert`s).
// In simulation a failure increments err_cnt and prints the first few.
// =============================================================================
`default_nettype none
`ifdef FORMAL
  `define SF_CHK(c, id) assert(c);
`else
  `define SF_CHK(c, id) if (!(c)) begin err_cnt = err_cnt + 32'd1; if (err_cnt <= 32'd8) $display("CHECKER FAIL id=%0d t=%0t : %s", id, $time, `"c`"); end
`endif
`ifdef FV_NODATA
  `define SF_DCHK(c, id) ;
`else
  `define SF_DCHK(c, id) `SF_CHK(c, id)
`endif

module sf_coh_checker #(
  parameter int N_AGENTS   = 2,
  parameter int DIR_LINES  = 16,
  parameter int CACHE_SETS = 4,
  parameter int LINE_BYTES = 64,
  parameter logic [31:0] COH_BASE = 32'h8000_0000,
  localparam int LIW  = (DIR_LINES > 1) ? $clog2(DIR_LINES) : 1,
  localparam int AIW  = (N_AGENTS > 1) ? $clog2(N_AGENTS) : 1,
  localparam int LB   = LINE_BYTES * 8,
  localparam int WPL  = LINE_BYTES / 4,
  localparam int WIW  = (WPL > 1) ? $clog2(WPL) : 1,
  localparam int OFW  = $clog2(LINE_BYTES),
  localparam int ENTW = 2 + N_AGENTS + AIW
) (
  input  wire                          clk,
  input  wire                          rst_n,
  input  wire                          enable,        // 0: checking suspended (deliberate non-coherent-master negative controls)
  // ---- CPU ports
  input  wire [N_AGENTS-1:0]           cpu_req_valid,
  input  wire [N_AGENTS-1:0]           cpu_req_ready,
  input  wire [N_AGENTS*3-1:0]         cpu_op,
  input  wire [N_AGENTS*32-1:0]        cpu_addr,
  input  wire [N_AGENTS*32-1:0]        cpu_wdata,
  input  wire [N_AGENTS*4-1:0]         cpu_wstrb,
  input  wire [N_AGENTS-1:0]           cpu_rsp_valid,
  input  wire [N_AGENTS-1:0]           cpu_rsp_ready,
  input  wire [N_AGENTS*32-1:0]        cpu_rdata,
  input  wire [N_AGENTS-1:0]           cpu_rsp_err,
  // ---- performed-operation events
  input  wire [N_AGENTS-1:0]           ev_perf_v,
  input  wire [N_AGENTS-1:0]           ev_perf_wr,
  input  wire [N_AGENTS*LIW-1:0]       ev_perf_line,
  input  wire [N_AGENTS*WIW-1:0]       ev_perf_word,
  input  wire [N_AGENTS*32-1:0]        ev_perf_rdata,
  input  wire [N_AGENTS*LB-1:0]        ev_perf_newline,
  input  wire [N_AGENTS*LB-1:0]        ev_perf_oldline,
  // ---- caches
  input  wire [N_AGENTS*CACHE_SETS*2-1:0]   dbg_cs_all,
  input  wire [N_AGENTS*CACHE_SETS*LIW-1:0] dbg_tag_all,
  input  wire [N_AGENTS*CACHE_SETS*LB-1:0]  dbg_data_all,
  input  wire [N_AGENTS*3-1:0]         dbg_p_st,
  input  wire [N_AGENTS*LIW-1:0]       dbg_p_line,
  input  wire [N_AGENTS-1:0]           dbg_p_lost,
  input  wire [N_AGENTS*LB-1:0]        dbg_p_data,
  // ---- directory
  input  wire [DIR_LINES*ENTW-1:0]     dbg_dir,
  input  wire [N_AGENTS*3-1:0]         dbg_slot_state,
  input  wire [N_AGENTS*LIW-1:0]       dbg_slot_line,
  input  wire [N_AGENTS-1:0]           dbg_slot_busy,
  input  wire [N_AGENTS*N_AGENTS-1:0]  dbg_slot_waiting,
  input  wire [N_AGENTS*3-1:0]         dbg_slot_gtype,
  input  wire [N_AGENTS*LB-1:0]        dbg_slot_data,
  input  wire [N_AGENTS-1:0]           mon_gnt_hs,
  // ---- memory side
  input  wire                          mem_req_valid,
  input  wire                          mem_req_ready,
  input  wire                          mem_req_wr,
  input  wire [LIW-1:0]                mem_req_line,
  input  wire [LB-1:0]                 mem_req_wdata,
  input  wire [DIR_LINES*LB-1:0]       mem_flat,
  // ---- sticky errors of the design
  input  wire [sf_coherence_pkg::DE_W-1:0]            dir_err,
  input  wire [N_AGENTS*sf_coherence_pkg::AE_W-1:0]   agent_err,
  // ---- results
  output reg  [31:0]                   err_cnt,
  output reg  [31:0]                   n_load,
  output reg  [31:0]                   n_store,
  output reg  [31:0]                   n_amo,
  output reg  [31:0]                   n_flush,
  output reg  [31:0]                   n_grants,
  output reg  [31:0]                   n_memwr,
  output reg  [31:0]                   n_quiescent_line_checks
);
  localparam logic [1:0] CS_I_L = sf_coherence_pkg::CS_I;
  localparam logic [1:0] CS_S_L = sf_coherence_pkg::CS_S;
  localparam logic [1:0] CS_M_L = sf_coherence_pkg::CS_M;
  localparam logic [1:0] DS_UNC_L = sf_coherence_pkg::DS_UNC;
  localparam logic [1:0] DS_SHR_L = sf_coherence_pkg::DS_SHR;
  localparam logic [1:0] DS_MOD_L = sf_coherence_pkg::DS_MOD;

  // ------------------------------------------------------------------ golden memory
  reg [DIR_LINES*LB-1:0] gold;
  reg [DIR_LINES*LB-1:0] gold_n;

  // captured CPU operation per agent (in-order, blocking => at most one)
  reg [2:0]  c_op   [0:N_AGENTS-1];
  reg [31:0] c_addr [0:N_AGENTS-1];
  reg [31:0] c_wd   [0:N_AGENTS-1];
  reg [3:0]  c_ws   [0:N_AGENTS-1];
  reg [N_AGENTS-1:0] c_open;       // operation accepted, response not yet taken
  reg [N_AGENTS-1:0] c_expect_perf;
  reg [N_AGENTS-1:0] c_seen_perf;
  reg [N_AGENTS-1:0] c_expect_err;
  reg [31:0] c_exp_rd [0:N_AGENTS-1];

  reg [N_AGENTS*3-1:0] st_q;       // previous slot state
  reg [N_AGENTS-1:0]   open_gnt;   // a data / upgrade grant was delivered, its completion has not been seen

  integer a, b, s, L, w, k;
  reg [31:0] off, ow;
  reg [LIW-1:0] cl;
  reg [WIW-1:0] cw;
  reg [LB-1:0]  ol, nl;
  reg [31:0]    oldw, neww, expect_rd;
  reg           m_a, s_a;
  reg [N_AGENTS-1:0] hm, hs;
  reg           busy_l;
  reg [1:0]     e_st;
  reg [N_AGENTS-1:0] e_sh;
  reg [AIW-1:0] e_ow;
  reg [N_AGENTS-1:0] holders;
  integer       nm, nbusy;
  reg           inwin, misal;

  initial begin
    err_cnt = 0; n_load = 0; n_store = 0; n_amo = 0; n_flush = 0; n_grants = 0; n_memwr = 0; n_quiescent_line_checks = 0;
    c_open = 0; c_expect_perf = 0; c_seen_perf = 0; c_expect_err = 0; open_gnt = 0; st_q = 0;
  end

  always @(posedge clk) begin
    if (!rst_n) begin
      gold          <= mem_flat;          // after reset the memory image is the truth (dirty cache data is lost)
      c_open        <= {N_AGENTS{1'b0}};
      c_expect_perf <= {N_AGENTS{1'b0}};
      c_seen_perf   <= {N_AGENTS{1'b0}};
      c_expect_err  <= {N_AGENTS{1'b0}};
      open_gnt      <= {N_AGENTS{1'b0}};
      st_q          <= {N_AGENTS*3{1'b0}};
    end else if (enable) begin
      gold_n = gold;

      // ================= CPU command capture and response check =================================================
      for (a = 0; a < N_AGENTS; a = a + 1) begin
        if (cpu_rsp_valid[a] && cpu_rsp_ready[a]) begin
          `SF_CHK(c_open[a], 1)
          if (c_expect_perf[a]) begin
            `SF_CHK(c_seen_perf[a], 2)                       // performed exactly once before the response
            `SF_CHK(cpu_rsp_err[a] == 1'b0, 3)
            `SF_DCHK(cpu_rdata[a*32 +: 32] == c_exp_rd[a], 4) // returned value == reference value
          end else if (c_expect_err[a]) begin
            `SF_CHK(cpu_rsp_err[a] == 1'b1, 5)
          end else begin
            `SF_CHK(cpu_rsp_err[a] == 1'b0, 6)
          end
          c_open[a]        <= 1'b0;
          c_expect_perf[a] <= 1'b0;
          c_seen_perf[a]   <= 1'b0;
        end
        if (cpu_req_valid[a] && cpu_req_ready[a]) begin
          c_op[a]   <= cpu_op[a*3 +: 3];
          c_addr[a] <= cpu_addr[a*32 +: 32];
          c_wd[a]   <= cpu_wdata[a*32 +: 32];
          c_ws[a]   <= cpu_wstrb[a*4 +: 4];
          c_open[a] <= 1'b1;
          off   = cpu_addr[a*32 +: 32] - COH_BASE;
          inwin = (cpu_addr[a*32 +: 32] >= COH_BASE) && (off < DIR_LINES * LINE_BYTES);
          misal = |cpu_addr[a*32 +: 2];
          c_expect_perf[a] <= (cpu_op[a*3 +: 3] <= sf_coherence_pkg::OP_AMO) && inwin && !misal;
          c_expect_err[a]  <= (cpu_op[a*3 +: 3] > sf_coherence_pkg::OP_FENCE) || !inwin || misal;
          c_seen_perf[a]   <= 1'b0;
        end
      end

      // ================= performed operations: compare with the reference ======================================
      for (a = 0; a < N_AGENTS; a = a + 1) begin
        if (ev_perf_v[a]) begin
          `SF_CHK(c_open[a] && c_expect_perf[a] && !c_seen_perf[a], 7)   // exactly once per accepted operation
          off = c_addr[a] - COH_BASE;
          cl  = off[OFW +: LIW];
          cw  = (WPL > 1) ? off[2 +: WIW] : {WIW{1'b0}};
          `SF_CHK(ev_perf_line[a*LIW +: LIW] == cl, 8)
          ol  = gold_n[cl*LB +: LB];
          `SF_DCHK(ev_perf_oldline[a*LB +: LB] == ol, 9)                  // the agent saw the CURRENT line: no stale data
          oldw = ol[cw*32 +: 32];
          nl   = ol;  neww = oldw;  expect_rd = oldw;
          if (c_op[a] == sf_coherence_pkg::OP_STORE) begin
            for (b = 0; b < 4; b = b + 1) if (c_ws[a][b]) nl[cw*32 + b*8 +: 8] = c_wd[a][b*8 +: 8];
            expect_rd = 32'd0;
          end else if (c_op[a] == sf_coherence_pkg::OP_AMO) begin
            nl[cw*32 +: 32] = oldw + c_wd[a];
          end
          `SF_DCHK(ev_perf_newline[a*LB +: LB] == nl, 10)
          `SF_DCHK(ev_perf_rdata[a*32 +: 32] == expect_rd, 11)
          `SF_CHK(ev_perf_wr[a] == (c_op[a] != sf_coherence_pkg::OP_LOAD), 12)
          gold_n[cl*LB +: LB] = nl;
          c_seen_perf[a] <= 1'b1;
          c_exp_rd[a]    <= expect_rd;
          if (c_op[a] == sf_coherence_pkg::OP_LOAD)  n_load  = n_load  + 1;
          if (c_op[a] == sf_coherence_pkg::OP_STORE) n_store = n_store + 1;
          if (c_op[a] == sf_coherence_pkg::OP_AMO)   n_amo   = n_amo   + 1;
        end
        if (cpu_rsp_valid[a] && cpu_rsp_ready[a] && c_op[a] == sf_coherence_pkg::OP_FLUSH && !cpu_rsp_err[a]) n_flush = n_flush + 1;
      end
      gold <= gold_n;

      // ================= memory writes and grants carry current data ===========================================
      if (mem_req_valid && mem_req_ready && mem_req_wr) begin
        `SF_DCHK(mem_req_wdata == gold[mem_req_line*LB +: LB], 13)        // no stale writeback / intervention data
        n_memwr = n_memwr + 1;
      end
      for (a = 0; a < N_AGENTS; a = a + 1) begin
        if (dbg_slot_state[a*3 +: 3] == sf_coherence_pkg::TS_GRANT &&
            (dbg_slot_gtype[a*3 +: 3] == sf_coherence_pkg::GN_DATA_S || dbg_slot_gtype[a*3 +: 3] == sf_coherence_pkg::GN_DATA_M))
          `SF_DCHK(dbg_slot_data[a*LB +: LB] == gold[dbg_slot_line[a*LIW +: LIW]*LB +: LB], 14)   // fill data is current
      end

      // ================= per-line cache / directory invariants ===================================================
      for (L = 0; L < DIR_LINES; L = L + 1) begin
        hm = {N_AGENTS{1'b0}};
        hs = {N_AGENTS{1'b0}};
        for (a = 0; a < N_AGENTS; a = a + 1) begin
          m_a = 1'b0; s_a = 1'b0;
          for (s = 0; s < CACHE_SETS; s = s + 1)
            if (dbg_cs_all[(a*CACHE_SETS + s)*2 +: 2] != CS_I_L && dbg_tag_all[(a*CACHE_SETS + s)*LIW +: LIW] == L) begin
              if (dbg_cs_all[(a*CACHE_SETS + s)*2 +: 2] == CS_M_L) m_a = 1'b1; else s_a = 1'b1;
              `SF_DCHK(dbg_data_all[(a*CACHE_SETS + s)*LB +: LB] == gold[L*LB +: LB], 15)  // every cached copy is current
            end
          if (dbg_p_st[a*3 +: 3] == sf_coherence_pkg::PS_MI && !dbg_p_lost[a] && dbg_p_line[a*LIW +: LIW] == L) begin
            m_a = 1'b1;
            `SF_DCHK(dbg_p_data[a*LB +: LB] == gold[L*LB +: LB], 16)                         // eviction buffer is current
          end
          if (dbg_p_st[a*3 +: 3] == sf_coherence_pkg::PS_SI && !dbg_p_lost[a] && dbg_p_line[a*LIW +: LIW] == L) s_a = 1'b1;
          hm[a] = m_a;  hs[a] = s_a;
        end
        nm = 0;
        for (a = 0; a < N_AGENTS; a = a + 1) if (hm[a]) nm = nm + 1;
        `SF_CHK(nm <= 1, 17)                                            // at most one Modified owner
        `SF_CHK(!(nm == 1 && ((hs != {N_AGENTS{1'b0}}))), 18)           // no Shared copy alongside the owner

        // transient / quiescent
        busy_l = 1'b0; nbusy = 0;
        for (a = 0; a < N_AGENTS; a = a + 1)
          if (dbg_slot_busy[a] && dbg_slot_line[a*LIW +: LIW] == L) begin busy_l = 1'b1; nbusy = nbusy + 1; end
        `SF_CHK(nbusy <= 1, 19)                                         // one open transaction per line

        e_st = dbg_dir[L*ENTW +: 2];
        e_sh = dbg_dir[L*ENTW + 2 +: N_AGENTS];
        e_ow = dbg_dir[L*ENTW + 2 + N_AGENTS +: AIW];
        holders = hm | hs;
        if (!busy_l) begin
          n_quiescent_line_checks = n_quiescent_line_checks + 1;
          if (e_st == DS_UNC_L) begin
            `SF_CHK(holders == {N_AGENTS{1'b0}} && e_sh == {N_AGENTS{1'b0}}, 20)
            `SF_DCHK(mem_flat[L*LB +: LB] == gold[L*LB +: LB], 21)       // memory current when nobody holds the line
          end else if (e_st == DS_SHR_L) begin
            `SF_CHK(e_sh == holders && hm == {N_AGENTS{1'b0}} && e_sh != {N_AGENTS{1'b0}}, 22)   // exact sharer vector
            `SF_DCHK(mem_flat[L*LB +: LB] == gold[L*LB +: LB], 23)
          end else begin
            `SF_CHK(e_st == DS_MOD_L, 24)
            `SF_CHK(holders == hm && hm == ({{(N_AGENTS-1){1'b0}}, 1'b1} << e_ow) && e_sh == hm, 25)  // exactly the owner
          end
        end
      end

      // ================= ownership only after invalidation; one completion per grant ============================
      for (a = 0; a < N_AGENTS; a = a + 1) begin
        if ((dbg_slot_state[a*3 +: 3] == sf_coherence_pkg::TS_GRANT || dbg_slot_state[a*3 +: 3] == sf_coherence_pkg::TS_COMPL) &&
            dbg_slot_gtype[a*3 +: 3] != sf_coherence_pkg::GN_PUTACK) begin
          `SF_CHK(dbg_slot_waiting[a*N_AGENTS +: N_AGENTS] == {N_AGENTS{1'b0}}, 26)    // all acknowledgements received
          for (b = 0; b < N_AGENTS; b = b + 1) if (b != a) begin
            for (L = 0; L < DIR_LINES; L = L + 1) if (dbg_slot_line[a*LIW +: LIW] == L) begin
              m_a = 1'b0; s_a = 1'b0;
              for (s = 0; s < CACHE_SETS; s = s + 1)
                if (dbg_cs_all[(b*CACHE_SETS + s)*2 +: 2] != CS_I_L && dbg_tag_all[(b*CACHE_SETS + s)*LIW +: LIW] == L) begin
                  if (dbg_cs_all[(b*CACHE_SETS + s)*2 +: 2] == CS_M_L) m_a = 1'b1; else s_a = 1'b1;
                end
              if (dbg_p_st[b*3 +: 3] == sf_coherence_pkg::PS_MI && !dbg_p_lost[b] && dbg_p_line[b*LIW +: LIW] == L) m_a = 1'b1;
              if (dbg_p_st[b*3 +: 3] == sf_coherence_pkg::PS_SI && !dbg_p_lost[b] && dbg_p_line[b*LIW +: LIW] == L) s_a = 1'b1;
              `SF_CHK(!m_a, 27)                                               // no other owner while data / ownership is granted
              if (dbg_slot_gtype[a*3 +: 3] != sf_coherence_pkg::GN_DATA_S) `SF_CHK(!s_a, 28)   // exclusive grant: all other copies gone
            end
          end
        end
        // completion accounting
        if (dbg_slot_state[a*3 +: 3] == sf_coherence_pkg::TS_GRANT && mon_gnt_hs[a] && dbg_slot_gtype[a*3 +: 3] != sf_coherence_pkg::GN_PUTACK) begin
          `SF_CHK(!open_gnt[a], 29)                                           // no second grant before the completion
          open_gnt[a] <= 1'b1;
          n_grants = n_grants + 1;
        end
        if (st_q[a*3 +: 3] == sf_coherence_pkg::TS_COMPL && dbg_slot_state[a*3 +: 3] == sf_coherence_pkg::TS_IDLE) begin
          `SF_CHK(open_gnt[a], 30)                                            // a completion only for an open grant
          open_gnt[a] <= 1'b0;
        end
      end
      st_q <= dbg_slot_state;

      // ================= the design's own sticky error bits must stay zero ======================================
      `SF_CHK(dir_err == {sf_coherence_pkg::DE_W{1'b0}}, 31)
      `SF_CHK(agent_err == {N_AGENTS*sf_coherence_pkg::AE_W{1'b0}}, 32)
    end
  end
endmodule

`default_nettype wire
