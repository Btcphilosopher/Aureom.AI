// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: sf_coh_mem_model  -- VERIFICATION-ONLY
//
// Shared memory / LLC behavioural model with two ports onto ONE array:
//   * line port  (directory)           : 64-byte read / write, response after the operation is performed (SFB2 R7)
//   * word port  (non-coherent gateway): 32-bit read / write with byte strobes; addresses outside the coherent
//                                        window go to a separate "uncached" array
// One operation is served at a time (the serialisation a real memory controller imposes).  Random latency and
// random request back-pressure (READY_PCT) inject memory-side stalls.  Contents are initialised to a known
// pattern so the golden model can start from `init pattern`.
// =============================================================================
`default_nettype none

module sf_coh_mem_model #(
  parameter int DIR_LINES  = 16,
  parameter int LINE_BYTES = 64,
  parameter int RD_LAT_MIN = 1,
  parameter int RD_LAT_MAX = 1,
  parameter int WR_LAT_MIN = 1,
  parameter int WR_LAT_MAX = 1,
  parameter int READY_PCT  = 100,
  parameter int SEED       = 1,
  parameter logic [31:0] COH_BASE = 32'h8000_0000,
  localparam int LIW = (DIR_LINES > 1) ? $clog2(DIR_LINES) : 1,
  localparam int LB  = LINE_BYTES * 8,
  localparam int WPL = LINE_BYTES / 4
) (
  input  wire                 clk,
  input  wire                 rst_n,
  // line port
  input  wire                 l_req_valid,
  output wire                 l_req_ready,
  input  wire                 l_req_wr,
  input  wire [LIW-1:0]       l_req_line,
  input  wire [LB-1:0]        l_req_wdata,
  output wire                 l_rsp_valid,
  input  wire                 l_rsp_ready,
  output wire [LB-1:0]        l_rsp_rdata,
  // word port
  input  wire                 w_req_valid,
  output wire                 w_req_ready,
  input  wire                 w_req_write,
  input  wire [31:0]          w_req_addr,
  input  wire [31:0]          w_req_wdata,
  input  wire [3:0]           w_req_wstrb,
  output wire                 w_rsp_valid,
  input  wire                 w_rsp_ready,
  output wire [31:0]          w_rsp_rdata,
  output wire                 w_rsp_error,
  // contents of the coherent window (for the checker)
  output wire [DIR_LINES*LB-1:0] mem_flat,
  // statistics
  output reg  [31:0]          st_line_rd,
  output reg  [31:0]          st_line_wr
);
  reg [31:0] m [0:DIR_LINES*WPL-1];
  reg [31:0] u [0:255];
  integer seed_r;
  integer ready_v = READY_PCT;
  integer ii;

  function [31:0] init_word(input integer idx);
    init_word = 32'hC0DE_0000 ^ (idx * 32'h0101_0101) ^ 32'h0000_00A5;
  endfunction

  initial begin
    for (ii = 0; ii < DIR_LINES*WPL; ii = ii + 1) m[ii] = init_word(ii);
    for (ii = 0; ii < 256; ii = ii + 1) u[ii] = 32'hD00D_0000 + ii;
    seed_r = SEED;
    if ($value$plusargs("MSEED=%d", seed_r)) ;
    if ($value$plusargs("MEMREADY=%d", ready_v)) ;
    st_line_rd = 0; st_line_wr = 0;
  end

  genvar g;
  generate
    for (g = 0; g < DIR_LINES*WPL; g = g + 1) begin : g_flat
      assign mem_flat[g*32 +: 32] = m[g];
    end
  endgenerate

  // service state
  reg        busy;          // an operation is in flight (latency countdown or response pending)
  reg        who;           // 0 line port, 1 word port
  reg        done;          // latency elapsed, response presented
  integer    cnt;
  reg [LB-1:0] l_rdata_r;
  reg [31:0]   w_rdata_r;
  reg          w_err_r;
  reg          rdy_roll;

  function integer rnd(input integer lo, input integer hi);
    integer r;
    begin
      r = $random(seed_r);
      if (r < 0) r = -r;
      rnd = (hi > lo) ? (lo + (r % (hi - lo + 1))) : lo;
    end
  endfunction

  // random readiness, re-rolled every cycle
  always @(posedge clk) rdy_roll <= (rnd(1, 100) <= ready_v);

  reg who_pref;     // 1: prefer the word port when both request (toggles after each service)
  initial who_pref = 1'b0;
  assign l_req_ready = rst_n && !busy && rdy_roll && !(w_req_valid && who_pref);
  assign w_req_ready = rst_n && !busy && rdy_roll && !(l_req_valid && !who_pref);

  assign l_rsp_valid = busy && done && !who;
  assign l_rsp_rdata = l_rdata_r;
  assign w_rsp_valid = busy && done && who;
  assign w_rsp_rdata = w_rdata_r;
  assign w_rsp_error = w_err_r;

  integer widx, bb;
  wire [31:0] woff = w_req_addr - COH_BASE;
  wire w_in_win = (w_req_addr >= COH_BASE) && (woff < DIR_LINES * LINE_BYTES);

  always @(posedge clk) begin
    if (!rst_n) begin
      busy <= 1'b0; done <= 1'b0; who_pref <= 1'b0;
    end else begin
      if (!busy) begin
        if (l_req_valid && l_req_ready) begin
          busy <= 1'b1; done <= 1'b0; who <= 1'b0; who_pref <= 1'b1;
          if (l_req_wr) begin
            for (ii = 0; ii < WPL; ii = ii + 1) m[l_req_line*WPL + ii] <= l_req_wdata[ii*32 +: 32];
            cnt <= rnd(WR_LAT_MIN, WR_LAT_MAX);
            st_line_wr <= st_line_wr + 1;
          end else begin
            for (ii = 0; ii < WPL; ii = ii + 1) l_rdata_r[ii*32 +: 32] <= m[l_req_line*WPL + ii];
            cnt <= rnd(RD_LAT_MIN, RD_LAT_MAX);
            st_line_rd <= st_line_rd + 1;
          end
        end else if (w_req_valid && w_req_ready) begin
          busy <= 1'b1; done <= 1'b0; who <= 1'b1; who_pref <= 1'b0;
          w_err_r <= 1'b0;
          widx = (w_req_addr[9:2]);
          if (w_in_win) begin
            widx = woff[31:2];
            if (w_req_write) begin
              for (bb = 0; bb < 4; bb = bb + 1)
                if (w_req_wstrb[bb]) m[widx][bb*8 +: 8] <= w_req_wdata[bb*8 +: 8];
              w_rdata_r <= 32'd0;
            end else w_rdata_r <= m[widx];
          end else begin
            if (w_req_write) begin
              for (bb = 0; bb < 4; bb = bb + 1)
                if (w_req_wstrb[bb]) u[widx][bb*8 +: 8] <= w_req_wdata[bb*8 +: 8];
              w_rdata_r <= 32'd0;
            end else w_rdata_r <= u[widx];
          end
          cnt <= w_req_write ? rnd(WR_LAT_MIN, WR_LAT_MAX) : rnd(RD_LAT_MIN, RD_LAT_MAX);
        end
      end else if (!done) begin
        if (cnt <= 1) done <= 1'b1; else cnt <= cnt - 1;
      end else begin
        if ((!who && l_rsp_ready) || (who && w_rsp_ready)) begin busy <= 1'b0; done <= 1'b0; end
      end
    end
  end
endmodule

`default_nettype wire
