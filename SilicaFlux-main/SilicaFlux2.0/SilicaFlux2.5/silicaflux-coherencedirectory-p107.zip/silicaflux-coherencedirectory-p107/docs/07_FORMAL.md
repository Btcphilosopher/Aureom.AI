# 07 — Formal verification

> **Evidence level.** Formal results are for the **minimum geometry that contains every race**: 2 agents, 2 lines, 1 cache set per agent (every access to the other line evicts), 4-byte lines (32-bit data). The 64-byte line is a width parameter and is verified by simulation, not formal. N > 2 is not formally checked. No result below is a statement about silicon.

## 1. Tools and flow

| tool | use |
|---|---|
| **Yosys 0.33** (`read_verilog -sv -formal`, `prep`, `flatten`, `techmap`, `write_aiger`) | elaboration of RTL + properties into a bit-level model; the same flow that accepts the package-localparam RTL style |
| **ABC `pdr`** (IC3 / property-directed reachability, via `yosys-abc`) | **unbounded** safety proofs: it finds its own inductive strengthening (`formal/run_pdr.sh`) |
| **Yosys built-in SAT** (`sat -seq`, `sat -tempinduct`) | bounded model checking from reset and plain k-induction (`formal/run_formal.sh`) |
| z3 via `yosys-smtbmc` | tried first; **too slow** on this model (depth 8 did not finish in 10 minutes) and abandoned |
| **SymbiYosys** | **not installed** in the build environment; `formal/sf_coherence.sby` is the equivalent job and **was not executed** |

PDR is the engine SymbiYosys calls `abc pdr`; the AIGER model is produced by the same Yosys passes (`write_aiger -zinit`: uninitialised flops become free initial values, `$assume` becomes a constraint, `$assert` a bad-state output).

## 2. The harness (`formal/sf_coh_fv_top.sv`)

`sf_coh_fv_core` = `sf_coherence_subsystem` (2 agents + directory) + a one-outstanding-operation memory with a free ready and a free response-hold + `sf_coh_checker` compiled with `FORMAL` (every check becomes an `assert`). Wrappers drive the CPU side:

* **`sf_coh_fv_top` (the proof harness).** Everything the environment can do is a **free input in every cycle**: each agent's CPU port (`valid` may drop, any of LOAD / STORE / AMO / FLUSH / FENCE, either line, any word data and byte strobes), CPU response ready, an *allow* bit gating **each of the four coherence channels of each agent**, memory request-ready and memory response-hold. Reset is low only in step 0.
* **Assumptions (the complete list, 8 constraints):** for each agent, `op ≤ FENCE`, `address ≥ BASE`, `address < BASE + 8` (the two lines), `address[1:0] = 0`. Nothing else is assumed; in particular **stalls are unconstrained** (any channel may be blocked any number of cycles, forever) for the safety proof.
* **Not in the proof:** mid-run reset (simulation, T08 + campaign), out-of-window / misaligned / illegal-opcode operations (error response, no side effect — directed + random simulation), N > 2, non-coherent masters.
* `sf_coh_fv_prog` (each agent runs a K-operation program chosen by the solver, so one run covers all pairs of programs) was written to reach deep race scenarios by BMC; its BMC runs (depth 24–28, SAT instances of 4–16 M variables) were **started and stopped before completing** and are superseded by the unbounded PDR proof of the free harness. It is kept for users with more solver resources. `sf_coh_fv_live` (bounded latency) is described in §5.

## 3. Properties

The 32 checks of `sf_coh_checker` (ids as in docs/01 §3) are the property set: 69 `$assert` cells in the full model, **46** in the structural-only model (`-DFV_NODATA` removes the ten comparisons that involve data: values returned, lines performed, writeback / fill data, cached-copy data, memory image).

| id | property | class |
|---|---|---|
| 17 | at most one Modified owner (counting a live eviction record) | structural |
| 18 | no Shared copy alongside the owner | structural |
| 19 | one open transaction per line | structural |
| 20, 22, 24, 25 | directory exact when a line is quiescent (UNC / SHR / MOD) | structural |
| 26, 27, 28 | ownership / data granted only after every acknowledgement, with no other owner (and no other copy for an exclusive grant) | structural |
| 29, 30 | one completion per grant; no second grant before it | structural |
| 31, 32 | no sticky protocol-error bit, directory or agent | structural |
| 1–3, 5–8, 12 | each CPU operation is performed exactly once before its response; error responses are exactly the illegal operations | structural |
| 4, 9, 10, 11 | the value returned, the line found, the line produced equal the independently recomputed result: **no stale data returned** | data |
| 13, 14 | every line written to memory and every fill granted is the latest value: **no stale writeback / fill** | data |
| 15, 16 | every cached copy and every live eviction buffer is the latest value | data |
| 21, 23 | memory is current when nobody owns the line | data |

## 4. Results

All proofs/BMC on the frozen sources (`reports/frozen_sources.md5`).

| run | engine | result | time |
|---|---|---|---|
| **structural properties (46 asserts), free environment** | **PDR (unbounded)** | **PROVED** | final run: see §4.1 |
| **all properties incl. data (69 asserts), free environment** | **PDR (unbounded)** | **PROVED** (earlier run: inductive invariant of 23 080 clauses over 1 081 of 1 082 flops, frame 27, 1 469 s) | final run: see §4.1 |
| all properties, BMC from reset (with the 8 constraints, `-set-assumes`) | Yosys SAT, depth 14 | no counterexample | 113 s |
| same, without constraints (first run, before the `-set-assumes` issue was found) | Yosys SAT, depth 14 | no counterexample (a superset of the environments) | 119 s |
| all properties, k-induction without strengthening (with constraints) | Yosys `sat -tempinduct`, k = 1…5 | **induction step fails at every k ≤ 5** (the plain property is not inductive); **superseded by PDR**, which supplies the strengthening | 25 s |

### 4.1 Final runs on the frozen sources
| property set | engine | result | solver time |
|---|---|---|---|
| structural (46 asserts, `-DFV_NODATA`) | ABC PDR | **PROVED** | 53.28 s |
| all (69 asserts incl. data) | ABC PDR | **PROVED** | 2286.11 s |

Invariant found for the full property set: frame 37, 26799 clauses over 1081 of 1082 flops; ABC reports "Verification of invariant … was successful".


### 4.2 What "PROVED" means here
For **every** execution of the 2-agent, 2-line, 1-set-per-agent design, of **any length**, starting from reset, under **any** sequence of CPU operations (from the assumed set) and **any** stalls on the four channels, memory and CPU response: the properties of §3 hold at every cycle. That includes "no stale data is ever returned or written back or filled", "at most one owner", "no ownership before all invalidations", "one completion per grant", and "no protocol error". It does **not** include progress (§5), other geometries, N > 2, mid-run reset, or the 64-byte data path.

### 4.3 The proof is not vacuous (formal sensitivity)
A proof under over-constrained assumptions would hold for any design. Two safeguards:
1. The assumptions are the eight shown in §2 (op ≤ FENCE, address inside the two lines, word-aligned, per agent); they are satisfiable — every counterexample below satisfies them.
2. **Each of the 17 injected bugs of `scripts/mutants.py` is detected by the same harness**, with a counterexample, by the same engine:

| mutant | what it breaks | properties | PDR result | wall time |
|---|---|---|---|---|
| `grant_before_acks` | ownership / data granted before the invalidation acknowledgements arrived | nodata | **COUNTEREXAMPLE** (property violated at depth 19) | 66 s |
| `no_inv_on_getm` | exclusive request from a shared line sends no invalidations | nodata | **COUNTEREXAMPLE** (property violated at depth 17) | 77 s |
| `no_inv_on_upgrade` | upgrade granted without invalidating the other sharers | nodata | **COUNTEREXAMPLE** (property violated at depth 26) | 86 s |
| `ignore_keep_bit` | directory keeps a former owner (that evicted) as a sharer: inexact sharer vector | nodata | **COUNTEREXAMPLE** (property violated at depth 22) | 91 s |
| `stale_put_commits` | a stale PUTM erases the (new) owner from the directory | nodata | **COUNTEREXAMPLE** (property violated at depth 28) | 108 s |
| `no_completion_wait` | transaction closed at grant: no unblock, entry never committed | nodata | **COUNTEREXAMPLE** (property violated at depth 11) | 60 s |
| `conflict_check_off` | two transactions on the same line at once (no per-line serialisation) | nodata | **COUNTEREXAMPLE** (property violated at depth 7) | 64 s |
| `fwd_s_keeps_modified` | owner does not downgrade on a shared intervention: two copies, one Modified | nodata | **COUNTEREXAMPLE** (property violated at depth 33) | 93 s |
| `inv_ignored_by_sharer` | sharer acknowledges the invalidation but keeps its copy: stale data later | nodata | **COUNTEREXAMPLE** (property violated at depth 19) | 80 s |
| `putack_not_consumed` | eviction record never cleared: agent hangs | nodata | **COUNTEREXAMPLE** (property violated at depth 17) | 84 s |
| `eviction_buffer_ignores_fwd` | writeback race: owner mid-eviction cannot answer the intervention | nodata | **COUNTEREXAMPLE** (property violated at depth 15) | 79 s |
| `amo_is_store` | AMO fetch-add replaced by a plain store (lost updates) | full | **COUNTEREXAMPLE** (property violated at depth 10) | 67 s |
| `strobes_ignored` | byte strobes ignored on stores | full | **COUNTEREXAMPLE** (property violated at depth 10) | 66 s |
| `upg_hit_skips_request` | store to a Shared line performed locally without an upgrade (no invalidation of other sharers) | full | **COUNTEREXAMPLE** (property violated at depth 18) | 97 s |
| `owner_data_dropped` | owner data response not captured: requester gets a stale buffer | full | **COUNTEREXAMPLE** (property violated at depth 17) | 213 s |
| `stale_putm_writes_memory` | a stale PUTM (lost the race) overwrites memory with old data | full | **COUNTEREXAMPLE** (property violated at depth 24) | 541 s |
| `intervention_not_written_to_memory` | dirty data forwarded to the reader but memory left stale | full | **COUNTEREXAMPLE** (property violated at depth 19) | 142 s |

(The 17 bugs are the ones the simulation environment kills in docs/06 §6. "Depth" is the PDR frame at which the violation was found; PDR extends frames one at a time, so no shorter counterexample exists. Several bugs need 22–33 cycles of adversarial, free-environment behaviour; a plain BMC of this harness at depth 20 had not finished after more than 45 minutes and was stopped.)

## 5. Progress (bounded latency)
**Not proved — inconclusive; no formal progress statement is made.**

Goal of the harness `sf_coh_fv_live`: assume a finite fairness bound on the environment (no handshake enable — 4 channels × 2 agents, memory ready, memory response — is low for more than S = 1 consecutive cycle) and assert that every operation accepted on a CPU port presents its response within LIMIT cycles, whatever the other agent does. A proof would be a proof of bounded response for all executions.

What happened:
1. **First attempts were invalid, and the reason is worth recording.** They used Yosys `sat`, which **silently ignores `$assume` unless `-set-assumes` is given**, and a fairness counter whose loop variable was shared between two `always` blocks. Both made the fairness bound ineffective. The "counterexamples" (an operation open for 60–90+ cycles) were inspected cycle by cycle: in them one agent's grant channel was held off for **more than 20 consecutive cycles** — the environment violated the stated bound — so they are **harness defects, not design bugs**. The runner now passes `-set-assumes` (every SAT run after that point), the harness uses a generate-based counter, and ABC PDR reads `$assume` natively (it prints "the last N outputs are interpreted as constraints").
2. **With the corrected harness** PDR (LIMIT = 100) did not converge in the time available (it reached frame 55 and stopped making progress), and a bounded run to depth 75 with assumptions exceeded 10 GB of memory on the build machine and was stopped without result.
3. **Evidence available instead:** the paper argument of docs/04 §4; the protocol model's deadlock-freedom check (docs/06 §5); the simulation watchdogs (30 000 cycles per operation, never fired across 38 configurations and 240 random runs); and the **maximum observed operation latency** per channel-stall level (docs/06 §4: 114 cycles at 0 % to 300 cycles at 85 % channel stalls, including 4-agent runs and CPU response stalls). These are observations, **not a bound**.


## 6. Reproduce

```bash
formal/run_pdr.sh 3000                                   # all properties, unbounded (≈ 25 min)
FV_DEFS=-DFV_NODATA FV_TAG=nodata formal/run_pdr.sh 3000 # structural properties, unbounded (≈ 1–2 min)
formal/run_formal.sh bmc 14                              # bounded model check
formal/run_formal.sh ind 5                               # plain k-induction (fails; see §4)
python3 scripts/run_pdr_mutants.py nodata 900 grant_before_acks ...   # formal sensitivity
```

## 7. Known limits of the formal result
* Geometry (§intro). The agent and directory are parameterised, but only this instance is proved.
* The memory model in the harness serves one operation at a time with arbitrary latency; a memory that reorders responses is outside the model (SFB2 R5 forbids it).
* The properties are the checker's; a bug that violates no checked property is not found (the mutation results show which classes are covered).
* PDR results depend on the ABC version; the invariant itself is certified by ABC's own check ("Verification of invariant … was successful"), not by an independent proof checker.
