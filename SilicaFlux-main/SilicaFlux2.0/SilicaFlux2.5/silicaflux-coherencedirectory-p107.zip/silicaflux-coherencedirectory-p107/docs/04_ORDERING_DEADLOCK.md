# 04 — Ordering, deadlock freedom and progress

## 1. Ordering rules (what the hardware guarantees, and what each rule is checked by)

| # | Rule | Mechanism | Checked by |
|---|---|---|---|
| O1 | **Request ordering per line.** All transactions on one line are totally ordered by their *start* at the directory (the directory lookup). A later request on a busy line waits in its slot (`TS_WAIT`) — there is no NACK and no reordering. Requests on *different* lines are independent and may overlap (two slots busy at once, T10). | `blocked` logic + one-start-per-cycle round-robin arbiter | invariant I3 [19]; T03, T09, T10 |
| O2 | **Invalidation completion.** A transaction that needs invalidations is complete only when the directory has received an `INVACK` from every invalidated sharer; the grant is not presented before. After the `INVACK` the sharer's copy is gone (the agent clears the line in the same cycle it answers). | `sf_coherence_sharers` (`to_send`, `waiting`); `gather_done` requires `sh_idle` | I7 [26, 27, 28]; formal; mutants `grant_before_acks`, `no_inv_on_getm`, `no_inv_on_upgrade` |
| O3 | **Ownership handoff.** Ownership of a line moves from agent O to R only through the directory: `FWD_M`→O, O answers `DATA` and clears the line in the same cycle, the directory (optionally) writes memory, presents `DATA_M`; R installs `M` only on that grant. There is no instant at which two agents hold `M`. | SNP/RSP/GNT sequence under one open transaction | I1, I2 [17, 18]; T06 (`ownership transfer`), T13 (238 transfers), random campaign |
| O4 | **Writeback ordering.** Dirty data written to memory (`PUTM`, or the owner's data on an intervention) is *performed* (memory response, SFB2 R7) before `PUTACK`/the grant is presented, and the line stays blocked until the transaction closes; so any later transaction on the line that reads memory reads the written data. A stale `PUTM` never writes. | `TS_MEMWR` precedes `TS_GRANT`; `putm_valid` test at start | I8 [13, 21, 23]; mutants `stale_putm_writes`, `intervention_not_written_to_memory`; T05, T11 |
| O5 | **Response sequencing.** For one transaction: [snoops → responses] → [memory] → **one** grant → **one** `COMPLETE` → entry commit → line unblocked. A grant is accepted only by an agent with a matching pending request; `COMPLETE` is accepted only by a slot in `COMPL`. Each agent has at most one open transaction, so its responses cannot reorder. | slot FSM; agent pending record | I9, I10 [29–32] |
| O6 | **Performed point.** A load/store/AMO is *performed* in one cycle: for a hit when the array is read/written, for a miss in the cycle the grant is installed (perform-on-grant). The CPU response is presented after that. Stores are never acknowledged before the agent holds `M`, i.e. before every other copy has been invalidated and acknowledged. | `ev_perf_*` events; agent FSM | reference model [2, 7–12] |

**Per-location order.** For one line the sequence of performed writes is the sequence of its `M`-ownership periods (O3); reads in `S` periods see the last write before the period. This is the coherence order the golden model (`gold`) tracks; the checker compares every performed operation against it.

## 2. Interaction with CPU-level memory-ordering guarantees

* The existing SilicaFlux consistency contract (MemoryCore `docs/03_CONSISTENCY.md`) says there is **no hardware coherence** and **one hart**; its caches are non-coherent and made visible by software `CLEAN`/`INVAL`. This block adds hardware coherence **only inside the coherent window**, for agents built on `sf_coherence_agent_adapter`. Nothing in the existing contract is weakened: rules C1 (single-copy atomicity of an aligned 32-bit access), C5 (message passing) and the "completion implies visibility" rule C4 hold inside the window, and now hold *between agents* without software maintenance.
* **The agent port is blocking and in-order**: one operation at a time, response after the operation is performed, next operation accepted only after the response is taken. Together with write serialisation and "a store completes only when the agent holds `M` and all other copies are gone", every operation takes effect atomically at its performed point, and an agent's performed points are in program order. The resulting memory behaviour for coherent-window accesses is **sequentially consistent**. The litmus tests confirm it on the RTL: store-buffering `(r0,r1) = (0,0)` never occurs; message passing never shows `flag = 1` with stale data; 2+2W never produces the forbidden cycle (T12: 150 iterations alternating same-line / different-line placement, random start skew; docs/06 has the histogram).
* **`FENCE`** completes immediately (an agent never has an operation outstanding after its response); it exists so software written for weaker agents is portable. A CPU that wraps this adapter with a **store buffer, load speculation or out-of-order issue gets only what its own fences give it**: coherence guarantees the *location* order, not the *inter-location* order of its own pipeline. The adapter offers the in-order point of coherence for such a CPU: a store drained to the adapter is globally performed when its response returns.
* **Atomics.** `OP_AMO` (32-bit fetch-and-add) is one indivisible read-modify-write on a line held in `M`: no snoop is taken between the read and the write (the perform is a single cycle and snoops are not processed in that cycle). Two agents hammering one counter lose no update (T13: 160/160; mutant `amo_is_store` killed). Multi-word atomicity, LR/SC and compare-and-swap are **not** provided (consistent with MemoryCore docs/06).
* **Non-coherent masters** are outside this ordering: see docs/05. A DMA write is ordered against coherent agents only by the software hand-over, not by the protocol.

## 3. Deadlock prevention

### 3.1 Channels and buffering
* **Four separate channels** (REQ, RSP, SNP, GNT); no buffer or arbiter is shared between classes. REQ needs only an idle slot; **RSP is the terminal sink** (always consumed within N cycles by a round-robin arbiter, never gated by any other resource); SNP and GNT need only the receiving agent's one RSP register.
* **Pre-allocated resources.** Everything a message needs downstream is allocated before it is sent: the REQ message lands in the agent's own slot (data buffer included), the grant data sits in the slot's buffer, the `COMPLETE`/`INVACK`/`DATA` replies have the agent's RSP register (checked before the snoop/grant is *taken*), and the RSP sink is unconditional.
* **No NACK / retry loop**: a request is never refused and re-sent; it waits in its slot. (`PD_RETRIES` counts requests that had to wait once for a busy line; it is a statistic, not a protocol action.)

### 3.2 The wait-for relation is acyclic
Order the resources: `REQ slot` → `line busy` → `SNP at agent` → `agent RSP register` → `directory RSP sink` (terminal) and `memory port` (terminal under the memory assumption).

* A **busy slot** waits only for: snoop acceptance by other agents, those agents' replies, the memory port, the requester's acceptance of the grant, the requester's `COMPLETE`. Each of those is served by an agent's *snoop/grant handler*, which depends only on the agent's RSP register, never on the agent's CPU FSM or its own outstanding request (priority snoop > grant > CPU).
* A **`WAIT` slot** waits only for a busy slot on its line; a busy slot never waits for a `WAIT` slot. So the line-conflict edges cannot close a cycle.
* The agent's **CPU FSM** waits for its own transaction; its transaction never waits for the CPU FSM.
* The **memory port** (one outstanding op, round-robin) is held by a slot only until its response; the memory model's response is an environment assumption (F1).
* **Writeback race** (owner mid-eviction): the owner's snoop handler answers from its eviction buffer, so the transfer needs nothing from the owner's *blocked* `PUTM` request (whose slot is still `WAIT`).

Therefore the wait-for graph is a DAG ending in the two sinks, and no set of requests can wait on each other forever.

### 3.3 Livelock
* **Perform-on-grant**: a granted request is performed in the cycle its line is installed, so a snoop cannot take the line back before the requester used it.
* **Fair arbiters**: start, memory, snoop and RSP arbiters are round-robin (work-conserving), so a waiting slot is overtaken by at most N−1 others. For N = 2 a slot that has waited on a line starts before the previous owner's next request can even enter `WAIT` (the slot only re-enters `WAIT` ≥ 2 cycles after its previous transaction ends).

## 4. Progress statement and assumptions

**Fairness / environment assumptions** (used by the argument; stated, not proven):

* **F1 — handshakes are eventually offered.** A channel transfer that is continuously possible on the design side (valid and ready both asserted by the design) is not suppressed forever by the environment: the test hook `chan_allow_*` is 1 infinitely often; the memory model accepts a request and responds within finite time; the CPU takes a response within finite time.
* **F2 — the CPU does not withdraw** a presented request before it is accepted (the agent latches the operation on acceptance, so this only matters for the BFM).
* **F3 — reset is not asserted** (reset cancels transactions by design).

**Claim.** Under F1–F3 every operation accepted on a CPU port completes (receives its response).

*Proof sketch.* (1) An operation needs at most two transactions (evict the victim, then the miss). (2) Take a transaction in slot *i*. It starts after every busy slot on its line has finished and it has won the round-robin start arbiter. A busy slot finishes: it waits only on the resources in §3.2, each of which is served by a handler that does not wait on it, so by induction on the (finite) number of busy slots all of them finish; with round-robin arbitration slot *i* is overtaken by at most N−1 starts, and for N = 2 by none after the blocker finishes. (3) Once started, `GATHER` completes (each snoop is accepted — agents take a snoop when their RSP register is free, which drains within N cycles — answered within 2 cycles, and its reply consumed by the RSP sink; memory responds by F1), `MEMWR` completes by F1, `GRANT` is accepted when the requester's RSP register is free and no snoop is pending (snoops are finitely many — one per open foreign transaction), and the requester sends `COMPLETE` the cycle after installing. (4) The grant is performed on arrival (§3.3), so the CPU operation completes. ∎

**What is and is not machine-checked.** The *safety* side (no stale data, no two owners, exact directory, one completion per grant, ownership only after invalidation, no protocol error) is **proved for all executions** of the 2-agent / 2-line / 1-set instance by ABC PDR (docs/07), is exhaustively explored in the protocol model (1.78 M states, all message interleavings) and is checked by simulation in every cycle of every run on N = 2…4. The *progress* argument above is a **paper proof**; its evidence is (a) the model checker's **deadlock-freedom check** (every reachable state of the protocol model is either terminal-and-quiescent or has an enabled transition — 1.78 M states, 4.6 M transitions, 2 agents × 2 lines, 3 operations per agent, unordered channels), (b) simulation: 38 configurations plus 240 random runs with random stalls on every channel and per-operation watchdogs (30 000 cycles) that never fired, and (c) the bounded-latency formal property of docs/07 §5, whose status is stated there. **No unbounded liveness proof is claimed.**
