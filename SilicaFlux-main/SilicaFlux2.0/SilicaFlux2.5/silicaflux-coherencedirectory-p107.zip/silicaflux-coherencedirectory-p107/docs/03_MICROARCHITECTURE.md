# 03 — Microarchitecture

## 1. Modules (all in `rtl/coherence/`, Yosys-0.33-safe subset: flat ports, package localparams, no struct/enum/interface)

| module | role | notes |
|---|---|---|
| `sf_coherence_pkg` | every encoding: line states, directory states, message types of the four channels, transaction FSM states, CPU ops, error bits, counter indices | localparams only |
| `sf_coherence_directory` | **primary RTL.** Directory array (stable states), N transaction slots, start / memory / snoop / response arbiters, response routing, performance counters, error flags | one instance per coherent window |
| `sf_coherence_transient_fsm` | one transaction slot = the **transient states** (`WAIT → GATHER → [MEMWR] → GRANT → COMPL`), plan computation from the entry, commit of the new entry | one per agent |
| `sf_coherence_sharers` | snoop-target set + outstanding-acknowledgement tracker (`to_send`, `waiting`, `ack_bad`, `idle`) | one per slot |
| `sf_coherence_agent_adapter` | coherent caching agent: MSI array, CPU port (LOAD/STORE/AMO/FLUSH/FENCE), pending record, snoop responder, perform-on-grant | one per agent; the CacheForge-style integration point |
| `sf_coherence_nc_gateway` | port for non-coherent masters (docs/05) | one per NC master |
| `sf_coherence_subsystem` | N adapters + directory; `chan_allow_*` stall-injection hooks (tie to 1); observability buses | integration example |

## 2. Latency of single operations (measured, RTL simulation, zero stalls, memory latency 1)

Cycles from the CPU request being presented to the response being valid, one operation at a time (`tb/tb_sf_coherence_lat.sv`, `reports/latency.csv`); includes the one-cycle accept and one-cycle evaluate of the agent.

| operation | cycles |
|---|---|
| load / store **hit** (S or M) | 3 |
| store to a Shared line, no other sharer (`UPG`, grant without data) | 7 |
| upgrade with one other sharer (`UPG` + `INV`/`INVACK`) | 9 |
| `GETS` / `GETM`, line uncached (cold miss) | 11 |
| load of a line Modified elsewhere (`FWD_S`, owner data, memory write, `DATA_S`) | 13 |
| store to a line Modified elsewhere (`FWD_M`, ownership transfer) | 13 |
| `FLUSH` of a Shared line (`PUTS`/`PUTACK`) | 7 |
| `FLUSH` of a Modified line (`PUTM` + memory write + `PUTACK`) | 11 |
| miss that must evict a Modified victim first (`PUTM` then `GETS`, 1 set) | 20 |

The design has no pipelining beyond the registered memory arbiter, the snoop / grant registers and the agent's RSP register; every message hop costs at least one cycle. Memory latency adds directly on the cold-miss and writeback paths (docs/08 shows 1 → 8).

## 3. Arbiters and resource ownership

| resource | arbitration | held until |
|---|---|---|
| directory **start** (lookup) | round-robin among `WAIT` slots whose line is not busy; one per cycle | – |
| directory **line** | exactly one busy slot per line (`blocked` logic) | `COMPLETE` / `PUTACK` (entry committed in the same cycle the slot returns to `IDLE`) |
| **memory port** | round-robin among slots wanting memory; registered grant (`mst`: idle → request → response); **one outstanding operation** | memory response |
| **SNP** channel to agent *j* | round-robin among slots whose snoop targets *j* | handshake |
| **RSP** channel | one accepted per cycle, round-robin among agents; always consumed | handshake |
| **GNT** channel to agent *i* | driven by slot *i* only | handshake |
| agent **array port** | snoop > grant > CPU, one per cycle; snoop/grant need the RSP register free | – |

## 4. Reset and error flags

Synchronous reset clears the directory (all lines `UNC`), every slot, every arbiter, the agents' arrays' state bits, pending records, request/response registers and counters; data registers are not reset (qualified by their state bits). Sticky error bits (`DE_*`, `AE_*` in the package) record protocol violations; the verification environment asserts they stay 0 (docs/01 I10).

## 5. Generic synthesis statistics (Yosys 0.33 `synth -flatten`, generic cells; **no timing, no area claim**)

Source: `scripts/yosys_stats.sh`, parsed to `reports/yosys_stats.csv`. 64-byte lines.

| block | geometry | generic cells | of which flip-flops |
|---|---|---|---|
| `sf_coherence_directory` | N = 2, 16 lines | 10 179 | 1 795 |
| | N = 2, 64 lines | 15 994 | 2 039 |
| | N = 4, 16 lines | 19 430 | 2 960 |
| | N = 8, 16 lines | 53 921 | 5 351 |
| `sf_coherence_agent_adapter` | 4 sets, 16-line window | 41 590 | 3 545 |
| | 16 sets, 64-line window | 141 653 | 9 797 |
| `sf_coherence_subsystem` | N = 2, 4 sets, 16 lines | 93 173 | 8 885 |

Reading: the flip-flops are dominated by the 512-bit data registers (the agent's array + eviction buffer + request/response registers; the directory slots' buffers); the cell count growth with N in the directory is the per-slot data muxes and the O(N²) routing of snoops and responses. The array of the directory is a flop vector here (docs/02 §3 on SRAM). These counts say nothing about frequency or area.
