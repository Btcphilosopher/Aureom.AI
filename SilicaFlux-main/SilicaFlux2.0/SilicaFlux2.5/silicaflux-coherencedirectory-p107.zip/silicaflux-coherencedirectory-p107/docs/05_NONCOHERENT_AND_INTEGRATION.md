# 05 — Non-coherent masters, cache-maintenance rules, and integration

**Principle (mission §9): no master is silently treated as coherent.** Only agents built on `sf_coherence_agent_adapter` take part in the protocol. Everything else — DMA engines, scratchpad engines, management / debug access — is **non-coherent** and meets the coherent window only through `sf_coherence_nc_gateway`, under the software rules below. Scratchpads (VSPM, TensorCore operand/accumulator/output buffers) are *not caches*: they are engine-private memories outside the window, addressable only by their engine (MemoryCore docs/05); they never answer a snoop and are never snooped.

## 1. Interfaces

| Master | Class (`NC_CLASS`) | Port | Reaches |
|---|---|---|---|
| DMA engine (CloudDMA / StreamDMA / HPC DMA adapter) | 0 | SFB2-shaped word interface of the gateway: `s_req_{valid,ready,write,addr,wdata,wstrb}`, `s_rsp_{valid,ready,rdata,error}`, one 32-bit word per transaction, blocking | shared memory **directly** (word port of the memory); a wider master uses one gateway per lane / the fabric serialises |
| Scratchpad engine writing/reading the window | 1 | same | same |
| Management / debug host | 2 | same | same |
| Coherent agent | – | `sf_coherence_agent_adapter` (CPU port + 4 coherence channels) | the directory |

**Gateway behaviour** (`sf_coherence_nc_gateway`):

| address | `cfg_allow_window` = 0 (reset default) | `cfg_allow_window` = 1 |
|---|---|---|
| outside the coherent window (uncached memory, MMIO) | forwarded unchanged | forwarded unchanged |
| inside the window | **refused: error response, no memory side effect**, `cnt_refused`++ | forwarded to memory, `cnt_window_ok`++ |
| misaligned | refused | refused |

`cfg_allow_window` is meant to be a management register written only for the duration of a hand-over. A refused access can never corrupt a coherent line or read a stale one by accident.

## 2. Rules (the software contract for non-coherent masters)

Same ownership discipline as MemoryCore docs/03 §5, with the hardware doing the agents' side:

* **N1 — one owner at a time.** A buffer in the window belongs either to the coherent agents or to one non-coherent master. While a non-coherent master owns it no agent reads or writes it.
* **N2 — hand over to a device (device will READ what the CPU wrote, or WRITE it).** Every agent that may hold a line of the buffer issues `OP_FLUSH` for each line and waits for the response. `OP_FLUSH` writes a Modified line back and drops it (`PUTM`/`PUTS`), and its response means the `PUTACK` was received after the memory write was *performed* — so after the last response memory holds the data and **no cache holds any line of the buffer**. Only then is `cfg_allow_window` set and the device started (the start is an MMIO write, ordered after the flushes by the agent's in-order port).
* **N3 — hand back (the CPU will read what the device wrote).** The device's completion record is read through an *uncached* path (outside the window) after the device's last write was acknowledged (SFB2 R7). Agents then simply read: their copies were dropped in N2, so the first access misses and fetches the device's data from memory through the directory. `cfg_allow_window` is cleared.
* **N4 — whole lines.** Buffers shared with a device are line-aligned and a whole number of 64-byte lines (the same rule as `SFMEM_DMA_ALIGN`): otherwise a neighbouring CPU variable shares the line, and an agent's later `PUTM` writes the *whole line* over the device's data.
* **N5 — never mix.** A Modified line in any cache while a device writes memory is destroyed by the eventual `PUTM`; a Shared copy kept across a device write is stale forever. Both are prevented only by N2.
* **N6 — fine-grained sharing with a device (descriptors, mailboxes, flags)** does not belong in the coherent window: put it in the uncached region (outside the window) — no maintenance, no coherence involved.
* **N7 — management / debug.** Read/write access is permitted only with `cfg_allow_window = 1`. A debugger that wants the architecturally current value of a line asks the agents to `FLUSH` it first; a window read returns *memory*, which is stale for a line held in `M`.
* **N8 — I/O-coherent masters are a different thing.** A non-caching master that issues coherent `ReadOnce`/`WriteUnique` requests to the directory would need new request types and directory flows; they are **not implemented** (docs/09).

## 3. Demonstrated by the testbench (T14, same run as the other tests)

1. Window access with the gateway closed → error response, `cnt_refused` increments, the refused write did not reach memory.
2. Access outside the window with no maintenance → works (uncached region).
3. **Negative control:** agent 0 holds line 3 (Shared); the DMA writes the line in memory with no maintenance; agent 0 reads again and gets the **stale** value (`0x11112222`, memory holds `0x5A5A5A5A`) — printed in the log as "stale read observed WITHOUT maintenance … NON-COHERENT, as specified". During these two steps the reference checker is deliberately suspended (the software contract is being violated on purpose) and re-armed afterwards.
4. **Correct protocol:** both agents `FLUSH` the line, the DMA writes, both agents read → both see the DMA's data; the final memory image equals the reference model; the directory ends Uncached.

## 4. Integrating a cache (CacheForge-style, or the existing `sfmem_cache`)

`CacheForge` does not exist in the repository (docs/00). The existing caches are non-coherent, 16-byte lines, with `CLEAN/INVAL/CLEAN_INVAL` maintenance. What a cache must add to become an agent of this protocol:

| need | what the adapter does | what an existing cache must change |
|---|---|---|
| **64-byte line** (or sub-lines under one directory line) | `LINE_BYTES` parameter | `sfmem_cache` LINE_BYTES 16 → 64, or four 16-B sub-lines moved/owned together |
| **ownership state** | `CS_S` vs `CS_M`; a store to `S` issues `UPG` | the existing valid/dirty bits give `S`/`M`, but a **write hit on a clean line must request ownership** instead of setting dirty |
| **snoop port with priority over the CPU** | `sn_*` handler: `INV`, `FWD_S`, `FWD_M` on a single array port, snoop > grant > CPU | add a second tag-lookup/data-read path or steal a cycle; the snoop must see a consistent line (no snoop between the read and write of one atomic op) |
| **eviction record** | `p_data` + `PS_MI/PS_SI` | the writeback buffer must stay snoopable until `PUTACK` |
| **one request per agent** | `PS_*` pending record | MSHRs are a later step (docs/09) |
| **perform-on-grant** | grant installs and performs in one cycle | the fill path must be able to forward the critical word and complete the waiting access in the install cycle |
| **maintenance for non-coherent masters** | `OP_FLUSH(line)` | `CLEAN_INVAL` over a range → loop of line `FLUSH`es; `INVAL` (discard) has **no** coherent equivalent and must not be used on coherent lines |
| **reset** | cache emptied, dirty data lost | same as MemoryCore R1 |

The I-cache (read-only) is the easy case: it needs only `S`/`I`, `GETS`, `PUTS` and `INV`; it is not wrapped here.
