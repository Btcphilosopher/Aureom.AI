# 09 — Expansion study (mission §12)

> **Status: investigation, not implementation.** The mission said to introduce nothing beyond MSI until the basic directory passes formal checks. MSI with two agents is the only protocol implemented. What follows is what was **measured** on the MSI design (N = 3 and 4 simulation, benchmark counters), and a **design analysis** of each item with the protocol deltas and the verification they would need. Statements marked *(analysis)* are reasoning, not results.

## 1. MESI (Exclusive state)

**What it would save — measured upper bound.** An `E` grant (`GETS` answered exclusive-clean when the directory finds no other holder) lets the agent write later without an `UPG`. In the benchmark (docs/08, 2 agents, memory latency 1) the removable transactions are the `UPG`s that follow a read of a line **nobody else holds**:

| workload | `UPG` count | of directory lookups | removable by `E`? |
|---|---|---|---|
| private | 6 | 14 (43 %) | yes — all of them (each is read-then-write of private data) |
| read_mostly | 8 | 20 | no — the other agents hold the line (`UPG` needs invalidations) |
| producer_consumer | 62 | 128 | no — the reader holds a Shared copy, so `E` would not have been granted |
| mixed_random | 45 | 156 | mostly no — sharing traffic |

So MESI pays for **private read-then-write data** and for nothing in the sharing patterns that dominate the expensive workloads. Per removed `UPG` the traffic saved is the `UPG` request, grant and `COMPLETE` (3 × 8 B) and one directory lookup.

**Protocol deltas** *(analysis)*: `CS_E` and `GN_DATA_E`; the directory treats an `E` owner like the `MOD` owner (an owner is "exclusive: clean or dirty, unknown to the directory because `E→M` is silent"); the owner's answer to `FWD_*` must either always carry data (simple, costs a data transfer for clean owners) or distinguish clean (`RS_CLEAN`, directory supplies memory data); a clean exclusive eviction `PUTE` (no data) next to `PUTM`; stale-`PUTE` handled exactly like stale `PUTM`; the checker's "M" becomes "E or M" in I1/I2 and I6 holds unchanged. About 40–60 lines of RTL and one more row set in the transaction table.
**Verification needed**: extend `model/sf_coherence_ref_model.py` (add `E`, rerun the exhaustive search), then the formal harness. Not done here by design.

## 2. Four or eight agents

* **Measured (simulation, MSI, unchanged RTL):** N = 3 and N = 4 pass the full random campaign (`reports/rand_campaign.csv`: 4-agent geometries `(4,1,8)` and `(4,2,16)`, 3-agent `(3,1,8)`; mid-flight resets included) and the configuration sweep (`reports/sweep.csv`: `NA=3`, `NA=4` rows) with the reference checker on every cycle. The protocol model explores N = 3 exhaustively for two bounded cases (`reports/model_n3.log`: 107 484 states with FLUSH, 1 176 242 states on one line with 2 operations per agent — no violation, no deadlock).
* **Not done:** N = 8 simulation, formal for N > 2.
* **What grows** *(analysis)*: sharer vector N bits per line (docs/02); the number of slots (N × 64-B buffers); invalidation fan-out is **issued one snoop per cycle per slot** — for a line shared by 7 others the `GATHER` takes ≥ 7 cycles to issue plus the acknowledgements (the 4-agent `migratory_amo` row shows the matching per-operation latency growth: 19.9 → 39.8 cycles at the same cycles/op); a parallel snoop send (one SNP port per destination, already per-destination in the directory) is the obvious next step. Arbiters are round-robin so the starvation bound grows by one per agent.

## 3. Snoop filters

`sf_coherence_directory` already *is* a snoop filter in the sense that no agent is ever snooped unless the directory records it as a holder (exact sharer vector). Using it as a filter in front of a **snooping** domain (a local broadcast bus with several caches behind one directory port) means: the "agent" in the sharer vector becomes the cluster, an `INV` to a cluster is broadcast inside it and acknowledged once, and inclusion (every line cached anywhere in the cluster is recorded) must be maintained. The sparse, tagged form of docs/02 §3 with back-invalidation is the scalable version. *(analysis; not implemented.)*

## 4. Directory banking

Lines are independent (one transaction per line), so the directory banks by line-address bits with **no protocol change**: instantiate B copies of `sf_coherence_directory`, each owning the lines `line mod B`, with *(analysis)*: a REQ demultiplexer by line address, an RSP demultiplexer by line address (already the routing key for `INVACK`/`DATA`), a per-agent SNP/GNT merge (round-robin among banks), and one memory-port arbiter or one port per bank. The deadlock argument of docs/04 carries over: the sinks are unchanged, and a slot's waits are still on resources "later" in the order. Per-agent "one outstanding request" stays global, so banks only add parallelism across agents. The measured motivation: directory busy 64–89 % under sharing patterns with 2 agents (docs/08); at that load banking helps only when several lines are hot at the same time, not for a single hot line (`migratory_amo`).

## 5. Multiple outstanding lines (non-blocking agents)

*(analysis)* The directory side is already ready: slot conflicts compare lines, so M outstanding requests per agent means N × M slots with no change to the start/commit logic. The agent side is the work: an MSHR per outstanding line (op buffer for perform-on-grant), eviction while other misses are outstanding, and the in-order response rule — a non-blocking agent **loses the sequential consistency of docs/04 §2** unless it commits operations in order; the litmus tests must be rerun with the new agent. The `PS_*` pending record becomes a per-MSHR record; the snoop rows of docs/01 §4 apply per MSHR (a snoop can still only hit a line whose own transaction is *not* open, so `IS`/`IM` rows stay "error").

## 6. Integration with CacheForge

**CacheForge does not exist in the repository** (docs/00), so there is nothing to integrate or measure. docs/05 §4 lists what the closest existing cache (`sfmem_cache`) would have to add; the adapter's CPU-side port (blocking, 32-bit, `LOAD/STORE/AMO/FLUSH/FENCE`) is the interface a CacheForge-style cache would present *to its CPU*, and its four coherence channels are what it would present *to the directory*.

## 7. Recommended order

1. Extend the unbounded proof of docs/07 (today: 2 agents, 2 lines, 1 set, 4-byte lines) to N = 3/4, more lines/sets, and add a progress proof — prerequisite for everything else.
2. Skip the memory write on `M→M` transfers (measured 64 B per transfer, docs/08) and issue invalidations in parallel — both small, both re-verifiable by the existing harness.
3. MESI, because the private read-then-write case is common in software and the cost is small; extend the model first.
4. N = 4 formal / banking; MSHRs only with a litmus re-run.
