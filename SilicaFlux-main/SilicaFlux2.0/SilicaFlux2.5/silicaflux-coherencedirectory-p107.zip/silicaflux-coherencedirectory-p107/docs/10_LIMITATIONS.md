# 10 — Limitations and what is NOT claimed

Read this with the README. Everything not listed as verified is not verified.

## Not delivered / not possible in this repository
1. **CacheForge and AtomicEngine do not exist** in the repository (docs/00). Nothing was integrated with them. `OP_AMO` (32-bit fetch-and-add on an owned line) is provided at the agent as the minimum that makes "no lost update" testable.
2. **MESI, MOESI, more than two agents (formal), snoop filters, banking, multiple outstanding lines** are *investigated only* (docs/09). By instruction nothing beyond MSI was built before MSI passed its formal checks; MSI did pass them for the minimal instance (docs/07), and the expansions remain investigation-only.
3. **SymbiYosys is not installed** in the build environment. The formal runs use Yosys 0.33 with ABC's PDR (the engine behind SymbiYosys' `abc pdr`) and Yosys' built-in SAT; `formal/sf_coherence.sby` is a SymbiYosys job for the bounded runs and **was not executed**.

## Formal status (docs/07 has the details)
* **Unbounded for one geometry, nothing more.** The safety properties (no stale data, single owner, ownership only after invalidation, exact directory, one completion per grant, no protocol error — 69 assertions) are **proved for all executions of any length** by ABC PDR, but **only for the 2-agent, 2-line, 1-cache-set, 4-byte-line instance**, under a free environment (any CPU operations from the assumed set, any stall pattern on every channel, memory and CPU response). Other geometries (N > 2, more lines, more sets, 64-byte lines) are covered by simulation and by the protocol model, **not** by formal.
* **Plain k-induction (k ≤ 5) does not close** (the properties are not inductive without strengthening); PDR supplies the strengthening automatically. The invariant is certified by ABC's own check, not by an independent proof checker.
* **No liveness proof.** Progress is a paper argument (docs/04 §4) plus the protocol model's deadlock-freedom check and simulation watchdogs. A bounded-latency formal property was set up (`sf_coh_fv_live`); its result is reported in docs/07 §5 and is **not** a proof of progress unless stated there.
* **Mid-run reset, illegal operations and non-coherent masters are outside the formal environment** (simulation only).
* **Yosys `sat` ignores assumptions unless asked** (`-set-assumes`); the first bounded runs were made without them (a superset of behaviours, so conservative for safety) and were rerun where the assumptions matter. The PDR runs always used the constraints (ABC reports them).

## Design limits (by construction)
* **One outstanding request per agent, blocking in-order CPU port.** Sequential consistency of docs/04 §2 depends on it. A CPU with a store buffer or out-of-order issue sees only the guarantees of its own fences.
* **Directory array is a flop vector over an explicit window, no tags** (docs/02); not a production-scale representation. Sparse directory / SRAM array / back-invalidation are not implemented.
* **Dirty data goes through the directory; every intervention writes memory** (also `M→M` transfers). Deliberate for provable "no stale data"; costs 64 B per transfer (docs/08). No direct cache-to-cache path.
* **One memory operation at a time**, one directory start per cycle, invalidations issued one per cycle per transaction.
* **Synchronous reset; reset discards dirty data.** No response is produced for operations cancelled by a reset; the CPU model must abandon them (the testbenches do).
* **No error handling for memory errors** (the memory port has no error response; MemoryCore's precise/imprecise refill/writeback error rules are not reproduced).
* **No ECC/parity, no protection (domains, MemoryGuard), no address translation.** The coherent window is a physical address range; out-of-window CPU accesses return an error response from the agent.
* **I-cache and read-only agents are not wrapped.**
* **Non-coherent masters stay non-coherent** (N1–N8, docs/05); I/O-coherent requests (`ReadOnce`/`WriteUnique`) are not implemented. A hand-over that violates N2 *does* produce stale data — the testbench demonstrates it on purpose.

## Evidence limits
* **No silicon, no FPGA, no timing, no area, no power.** `scripts/yosys_stats.sh` gives generic-cell counts only (docs/03); they are structure counts, not area.
* **Cycle counts are testbench cycles** with a fixed-latency memory model (docs/08).
* **Verilator** cross-checks the fork-free random testbench (240 runs); the directed testbench runs in Icarus Verilog only (Verilator 5.020 crashes on `fork` in `initial` blocks — a tool bug, not a design issue).
* **Mutation score is over the 17 + 6 mutants listed** (docs/06); it shows the environment is sensitive to those bug classes, not that no other bug exists.
* The non-coherent negative control in T14 **suspends the reference checker on purpose** for two steps (the software contract is being violated) and re-arms it.
* Sticky protocol-error bits are *asserted never to be set* (I10) — an agent receiving an impossible message is a verification failure, not a handled case, except for the one defensive acknowledgement of an `INV` to an absent line.
