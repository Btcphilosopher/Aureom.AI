# 08 — Coherence performance (RTL simulation counters)

> **Evidence level.** Every number below is a cycle or byte count read from the RTL counters in a simulation run whose data was verified by the reference checker (`BENCH DONE checker_errors=0`). Cycles are *testbench* cycles with the stated memory latency; **no frequency, silicon timing, area or power is claimed.** Regenerate with `scripts/run_bench.sh && scripts/make_perf_report.py`. Raw counters: `benchmarks/results.csv`.

## 1. Counters (mission §10) and what they count

| counter | RTL name | definition |
|---|---|---|
| shared reads | `PD_GETS` | `GETS` transactions started |
| exclusive requests | `PD_GETM` | `GETM` started |
| upgrades | `PD_UPG` | `UPG` started |
| clean / dirty evictions | `PD_PUTS`, `PD_PUTM` | evictions started (includes stale ones) |
| invalidations | `PD_INV` | `INV` snoops issued |
| ownership transfers | `PD_OWN_XFER` | owner→new-owner transfers (`FWD_M` data received) |
| dirty interventions | `PD_DIRTY_INT` | owner data responses (`FWD_S` + `FWD_M`) |
| directory lookups | `PD_LOOKUPS` | one per started transaction |
| coherence stalls | `PD_STALL_CONF`, `PD_STALL_GATH` | slot-cycles a request waited for a busy line / slot-cycles in `GATHER` |
| traffic bytes | `PD_BYTES_{REQ,RSP,SNP,GNT}`, `PD_MEM_{RD,WR}_B` | 8-byte header per message + 64 data bytes on `PUTM`/`DATA`/fills; memory port bytes |
| protocol retries | `PD_RETRIES` | requests deferred at least once by a same-line conflict. **The protocol has no NACK**, so this is conflict-deferral, not a re-sent message. |

## 2. Results

### 2 agents, memory latency 1 (the verified configuration)

| workload | ops | cycles/op | avg op latency | hit rate | dir lookups/op | coherence B/op | memory B/op | GETS | GETM | UPG | PUTM | PUTS | INV | own. xfer | dirty int. | conflict-stall cycles | retries | dir busy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| private | 256 | 1.71 | 3.4 | 0.95 | 0.05 | 3.3 | 2.0 | 6 | 2 | 6 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 14 % |
| read_shared | 128 | 1.88 | 3.6 | 0.94 | 0.06 | 5.5 | 4.0 | 8 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 10 | 4 | 20 % |
| producer_consumer | 128 | 11.07 | 11.0 | 0.00 | 1.00 | 104.8 | 33.0 | 64 | 2 | 62 | 0 | 0 | 62 | 0 | 64 | 0 | 0 | 64 % |
| migratory_amo | 128 | 10.05 | 19.9 | 0.00 | 1.00 | 167.4 | 64.0 | 0 | 128 | 0 | 0 | 0 | 0 | 127 | 127 | 763 | 127 | 89 % |
| false_sharing | 128 | 10.05 | 19.9 | 0.00 | 1.00 | 167.4 | 64.0 | 0 | 128 | 0 | 0 | 0 | 0 | 127 | 127 | 763 | 127 | 89 % |
| read_mostly | 128 | 2.48 | 4.6 | 0.84 | 0.16 | 15.8 | 6.0 | 12 | 0 | 8 | 0 | 0 | 8 | 0 | 8 | 24 | 10 | 43 % |
| streaming_evict | 128 | 9.80 | 19.4 | 0.00 | 1.93 | 133.1 | 94.0 | 64 | 64 | 0 | 60 | 59 | 2 | 0 | 0 | 0 | 0 | 80 % |
| mixed_random | 256 | 4.66 | 9.2 | 0.39 | 0.61 | 78.1 | 27.8 | 48 | 63 | 45 | 0 | 0 | 47 | 59 | 105 | 110 | 31 | 84 % |

### 2 agents, memory latency 8

| workload | ops | cycles/op | avg op latency | hit rate | dir lookups/op | coherence B/op | memory B/op | GETS | GETM | UPG | PUTM | PUTS | INV | own. xfer | dirty int. | conflict-stall cycles | retries | dir busy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| private | 256 | 1.86 | 3.6 | 0.95 | 0.05 | 3.3 | 2.0 | 6 | 2 | 6 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 21 % |
| read_shared | 128 | 2.31 | 4.4 | 0.94 | 0.06 | 5.5 | 4.0 | 8 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 38 | 4 | 35 % |
| producer_consumer | 128 | 14.68 | 14.6 | 0.00 | 1.00 | 104.8 | 33.0 | 64 | 2 | 62 | 0 | 0 | 62 | 0 | 64 | 0 | 0 | 72 % |
| migratory_amo | 128 | 17.05 | 33.9 | 0.00 | 1.00 | 167.4 | 64.0 | 0 | 128 | 0 | 0 | 0 | 0 | 127 | 127 | 1652 | 127 | 94 % |
| false_sharing | 128 | 17.05 | 33.9 | 0.00 | 1.00 | 167.4 | 64.0 | 0 | 128 | 0 | 0 | 0 | 0 | 127 | 127 | 1652 | 127 | 94 % |
| read_mostly | 128 | 3.03 | 5.3 | 0.84 | 0.16 | 15.8 | 6.0 | 12 | 0 | 8 | 0 | 0 | 8 | 0 | 8 | 38 | 10 | 57 % |
| streaming_evict | 128 | 16.28 | 29.9 | 0.00 | 1.93 | 138.4 | 73.0 | 64 | 64 | 0 | 18 | 101 | 2 | 0 | 42 | 297 | 43 | 88 % |
| mixed_random | 256 | 6.42 | 12.3 | 0.47 | 0.53 | 68.3 | 24.5 | 39 | 59 | 37 | 0 | 0 | 39 | 55 | 92 | 265 | 33 | 88 % |

### 4 agents, memory latency 1

| workload | ops | cycles/op | avg op latency | hit rate | dir lookups/op | coherence B/op | memory B/op | GETS | GETM | UPG | PUTM | PUTS | INV | own. xfer | dirty int. | conflict-stall cycles | retries | dir busy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| private ¹ | 256 | 1.71 | 3.4 | 0.95 | 0.05 | 3.3 | 2.0 | 6 | 2 | 6 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 14 % |
| read_shared | 256 | 1.03 | 3.9 | 0.94 | 0.06 | 5.5 | 4.0 | 16 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 67 | 12 | 28 % |
| producer_consumer ¹ | 128 | 11.07 | 11.0 | 0.00 | 1.00 | 104.8 | 33.0 | 64 | 2 | 62 | 0 | 0 | 62 | 0 | 64 | 0 | 0 | 64 % |
| migratory_amo | 256 | 10.02 | 39.8 | 0.00 | 1.00 | 167.7 | 64.0 | 0 | 256 | 0 | 0 | 0 | 0 | 255 | 255 | 6096 | 255 | 90 % |
| false_sharing ¹ | 128 | 10.05 | 19.9 | 0.00 | 1.00 | 167.4 | 64.0 | 0 | 128 | 0 | 0 | 0 | 0 | 127 | 127 | 763 | 127 | 89 % |
| read_mostly | 256 | 1.70 | 5.4 | 0.85 | 0.15 | 15.0 | 7.5 | 30 | 0 | 8 | 0 | 0 | 23 | 0 | 8 | 254 | 29 | 61 % |
| streaming_evict ¹ | 128 | 9.80 | 19.4 | 0.00 | 1.93 | 133.1 | 94.0 | 64 | 64 | 0 | 60 | 59 | 2 | 0 | 0 | 0 | 0 | 80 % |
| mixed_random ¹ | 256 | 4.66 | 9.2 | 0.39 | 0.61 | 78.1 | 27.8 | 48 | 63 | 45 | 0 | 0 | 47 | 59 | 105 | 110 | 31 | 84 % |

¹ this workload drives only agents 0 and 1 even in the 4-agent build, so its row equals the 2-agent row; rows without the mark use all four agents.

### 4 agents, memory latency 8

| workload | ops | cycles/op | avg op latency | hit rate | dir lookups/op | coherence B/op | memory B/op | GETS | GETM | UPG | PUTM | PUTS | INV | own. xfer | dirty int. | conflict-stall cycles | retries | dir busy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| private ¹ | 256 | 1.86 | 3.6 | 0.95 | 0.05 | 3.3 | 2.0 | 6 | 2 | 6 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 21 % |
| read_shared | 256 | 1.48 | 5.1 | 0.94 | 0.06 | 5.5 | 4.0 | 16 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 148 | 6 | 49 % |
| producer_consumer ¹ | 128 | 14.68 | 14.6 | 0.00 | 1.00 | 104.8 | 33.0 | 64 | 2 | 62 | 0 | 0 | 62 | 0 | 64 | 0 | 0 | 72 % |
| migratory_amo | 256 | 17.02 | 67.6 | 0.00 | 1.00 | 167.7 | 64.0 | 0 | 256 | 0 | 0 | 0 | 0 | 255 | 255 | 11430 | 255 | 94 % |
| false_sharing ¹ | 128 | 17.05 | 33.9 | 0.00 | 1.00 | 167.4 | 64.0 | 0 | 128 | 0 | 0 | 0 | 0 | 127 | 127 | 1652 | 127 | 94 % |
| read_mostly | 256 | 2.17 | 6.7 | 0.87 | 0.13 | 13.4 | 6.5 | 26 | 0 | 8 | 0 | 0 | 20 | 0 | 8 | 428 | 30 | 75 % |
| streaming_evict ¹ | 128 | 16.28 | 29.9 | 0.00 | 1.93 | 138.4 | 73.0 | 64 | 64 | 0 | 18 | 101 | 2 | 0 | 42 | 297 | 43 | 88 % |
| mixed_random ¹ | 256 | 6.42 | 12.3 | 0.47 | 0.53 | 68.3 | 24.5 | 39 | 59 | 37 | 0 | 0 | 39 | 55 | 92 | 265 | 33 | 88 % |

¹ as above.

## 3. What the numbers say (each statement is read off the tables above)

* **Private data costs almost nothing**: 95 % of operations hit with no coherence request; 3.3 coherence bytes per operation; the directory is busy 14 % of the time (compulsory misses only).
* **Read sharing is cheap and scales**: `read_shared` keeps 94 % hits and 5.5 B/op with 2 agents, and 5.5 B/op with 4 (compulsory fills only).
* **Ping-pong writes are the expensive case.** `migratory_amo` (every agent fetch-adds one word): every operation is an ownership transfer — 167 coherence bytes and 64 memory bytes per operation, 10.0 cycles/op, the directory 89 % busy, 763 slot-cycles of conflict stall. With 4 agents the per-op latency grows from 19.9 to 39.8 cycles (queueing on one line) while throughput stays 10.0 cycles/op: the line, not the directory, is the bottleneck. `false_sharing` produces the identical counters because the two agents' disjoint words share a line — false sharing is as expensive as true sharing.
* **Dirty data goes through the directory.** `producer_consumer`: 64 dirty interventions for 128 operations; each read of a modified line costs a `FWD_S`, a data response and a memory write (33 memory bytes per op). Direct cache-to-cache forwarding would remove the extra data hop but not the memory write; that trade-off is listed in docs/09.
* **The memory write on every intervention is a measurable choice**: `migratory_amo` writes 64 B/op to memory although memory is never read in the steady state (an `M→M` transfer does not need the write: skipping it would remove those bytes; not implemented).
* **Memory latency matters only where memory is on the critical path**: raising memory latency 1→8 changes cycles/op from 1.71 to 1.86 for `private`, but from 10.0 to 17.0 for `migratory_amo` and from 9.8 to 16.3 for `streaming_evict` (writeback + fill per miss).
* **Directory utilisation is the contention signal**: 89 % (ping-pong), 80 % (streaming), 84 % (mixed random) versus 14 % (private). One transaction per line and one start per cycle are not the limit at these loads: the lookups-per-op column stays ≤ 1.93.
* **Protocol retries**: the `retries` column counts requests that had to wait once for a busy line (conflict deferral). It tracks the sharing intensity (`migratory_amo`, `mixed_random`) and is 0 for private and streaming traffic.

## 4. Limits of these measurements

* Blocking single-operation agents and one outstanding request per agent: the numbers show the protocol's cost, not the throughput of an out-of-order core.
* One workload instance per configuration (deterministic, fixed seed); no confidence intervals. The mixed workload is random with a fixed seed.
* The memory model has a fixed latency and unlimited bandwidth; real LLC / DRAM contention is not modelled.
* "Coherence bytes" use a modelled 8-byte header; a real link adds its own framing.

