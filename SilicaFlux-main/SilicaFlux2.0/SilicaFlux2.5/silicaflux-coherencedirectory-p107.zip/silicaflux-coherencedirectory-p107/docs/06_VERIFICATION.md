# 06 — Verification environment and results

> Every number in this document is read from a log in `reports/` by `scripts/make_verif_report.py`. Results are **RTL simulation, protocol-model exploration** and (docs/07) formal verification of the minimal 2-agent instance; no silicon, FPGA or timing evidence exists.

## 1. Environment

| piece | file | role |
|---|---|---|
| design under test | `rtl/coherence/*` via `sf_coherence_subsystem` | 2–4 agents + directory; `chan_allow_*` hooks inject a stall on any channel in any cycle |
| shared memory model | `tb/sf_coh_mem_model.sv` | line port + word port on one array, random latency and request back-pressure, response after the operation is performed |
| **reference model + invariants** | `tb/sf_coh_checker.sv` | golden memory recomputed from the CPU commands; SWMR, exact directory, ownership-after-invalidation, one completion per grant, no stale data / writeback / fill, no sticky error (32 checks; ids in docs/01) |
| directed + random system test | `tb/tb_sf_coherence.sv` (Icarus) | T01–T16 below, stall injection on every channel, CPU response and memory |
| fork-free random test | `tb/tb_sf_coherence_rand.sv` (Icarus **and** Verilator) | clocked per-agent random FSMs, random mid-flight resets, final flush + memory == golden check |
| benchmark / latency | `tb/tb_sf_coherence_bench.sv`, `tb/tb_sf_coherence_lat.sv` | docs/08, docs/03 |
| protocol model | `model/sf_coherence_ref_model.py` | executable spec, explicit-state exploration of all interleavings |
| formal | `formal/*`, `tb/sf_coh_checker.sv` compiled with `-DFORMAL` | docs/07 |

## 2. Directed and random system tests (default configuration: 2 agents, 8 lines, 1 cache set per agent, no stalls)

| test | scenario (mission §11) | result |
|---|---|---|
| T01 two simultaneous reads | two simultaneous reads | **PASS** |
| T02 read then write | read followed by write | **PASS** |
| T03 two competing writers | two competing writers (20 rounds, random skew) | **PASS** |
| T04 shared-to-modified upgrade | shared-to-modified upgrade | **PASS** |
| T05 modified-owner eviction | modified-owner eviction | **PASS** |
| T06 data forwarding / ownership transfer | data forwarding / dirty intervention / ownership transfer | **PASS** |
| T10 independent-line concurrency | independent-line concurrency (both slots busy at once) | **PASS** |
| T11 writeback races | writeback races: forced PUTM-vs-intervention and PUTS-vs-INV + 100 random race rounds | **PASS** |
| T13 atomic counter / false sharing | atomic counter (2×80 AMOs → 160) + false sharing | **PASS** |
| T14 non-coherent DMA rules | non-coherent DMA: gateway refusal, uncached region, stale-data negative control, FLUSH hand-over | **PASS** |
| T12 litmus SB/MP/2+2W | litmus SB / MP / 2+2W under random delays | **PASS** |
| T07 back-pressure (all channels) | back-pressure (random ops, all channels) | **PASS** |
| T08 reset mid-flight | reset mid-flight (6 resets with traffic in flight) | **PASS** |
| T09 same-line contention | same-line contention (loads, stores, AMOs on one line) | **PASS** |
| T15 random stress (same 2 lines) | random stress, 2 shared lines | **PASS** |
| T16 random stress (all lines) | random stress, all lines | **PASS** |

Reference checker over the whole run: 2628 loads, 3234 stores, 424 AMOs, 471 flushes performed and compared; 4711 grants; 3082 memory writes checked for freshness; 466307 per-line quiescent invariant checks; **checker errors 0**.

Litmus (T12): `SB outcomes (r0,r1): (0,0)=0 [forbidden]  (0,1)=72 (1,0)=0 (1,1)=78 ; MP flag-seen=150 data-stale=0 [must be 0] ; 2+2W forbidden=0`

Negative control (T14): `T14: stale read observed WITHOUT maintenance (11112222, memory holds 5A5A5A5A) -- NON-COHERENT, as specified`

## 3. Configuration and seed sweep (Icarus, `scripts/run_sweep.py`)

38 / 38 configurations PASS. Axes: channel stall 0–80 %, CPU response stall 0–70 %, memory latency 1–6 with 40–100 % request readiness, cache sets 1/2/4/8, agents 2/3/4, window 2/8/16 lines, 2–3 seeds. Directed tests T01–T14 run only for the 2-agent ≥ 8-line configurations; the random tests run in all.

## 4. Verilator random campaign (`scripts/run_rand_campaign.py`)

`240/240 random runs pass across 6 geometries; totals: loads=326341, stores=260735, amos=98135, flushes=97431, grants=533208, memwr=304398, resets=960, cycles=6855660, qchecks=61476714`
`max observed operation latency (cycles) by channel-stall %: 0%: 114, 10%: 108, 30%: 118, 60%: 159, 85%: 300`

("max observed operation latency" = cycles from a CPU request being presented to its response being taken, over all operations of all runs with that channel-stall percentage, **including N = 4 runs and CPU response stalls**; it is an observation, not a bound.)

Six geometries (agents × sets × lines: 2×1×8, 2×2×8, 3×1×8, 4×1×8, 4×2×16, 2×4×16), 40 runs each with random seed, stall mix (0–85 %), CPU stall, memory readiness, number of hot lines, and 4 mid-flight resets per run (the reset happens while traffic is in flight). Each run ends with every agent flushing every line and requires memory == golden model and the directory `UNC` everywhere.

## 5. Protocol model (`model/sf_coherence_ref_model.py`)

| configuration | result |
|---|---|
| agents=2 lines=2 cache capacity=1 lines/agent ops/agent=3 | **no violation, no deadlock**: 1780432 states, 4628344 transitions |
| agents=2 lines=2 cache capacity=2 lines/agent ops/agent=2 | **no violation, no deadlock**: 107656 states, 260260 transitions |
| agents=3 lines=2 cache capacity=1 lines/agent ops/agent=1 | **no violation, no deadlock**: 107484 states, 323220 transitions |
| agents=3 lines=1 cache capacity=1 lines/agent ops/agent=2 | **no violation, no deadlock**: 1176242 states, 3680271 transitions |

Checked in every state: SWMR, no shared copy beside an owner, every cached value current, exact directory when a line is quiescent, memory current when nobody owns it, one transaction per line, ownership granted only with no other holder, no unexpected/mistyped message at an agent or the directory; and in every reachable non-terminal state some transition is enabled (**deadlock freedom of the protocol**). Channels are unordered multisets (any delay, any order). Six protocol mutants (grant before acks, stale PUTM writes memory, no invalidation, intervention data not written, keep bit ignored, no wait for owner data) are each reported with a counterexample trace.

## 6. Mutation sensitivity of the RTL environment (`scripts/run_mutants.py`)

**17 / 17 injected RTL bugs are killed** by the quick regression (QUICK=1, 20 % stalls). First failing check per mutant:

| mutant | what it breaks | result | first failure reported |
|---|---|---|---|
| `grant_before_acks` | ownership / data granted before the invalidation acknowledgements arrived | **KILLED** | `CHECKER FAIL 31=31 t=0 : dir_err == {sf_coherence_pkg::DE_W{1'b0}}` |
| `stale_putm_writes_memory` | a stale PUTM (lost the race) overwrites memory with old data | **KILLED** | `TB FAIL @17115000 : forced race did not produce a stale PUTM` |
| `no_inv_on_getm` | exclusive request from a shared line sends no invalidations | **KILLED** | `CHECKER FAIL 28=28 t=0 : !s_a` |
| `no_inv_on_upgrade` | upgrade granted without invalidating the other sharers | **KILLED** | `CHECKER FAIL 28=28 t=0 : !s_a` |
| `intervention_not_written_to_memory` | dirty data forwarded to the reader but memory left stale | **KILLED** | `CHECKER FAIL 23=23 t=0 : mem_flat[L*LB +: LB] == gold[L*LB +: LB]` |
| `ignore_keep_bit` | directory keeps a former owner (that evicted) as a sharer: inexact sharer vector | **KILLED** | `CHECKER FAIL 22=22 t=0 : e_sh == holders && hm == {N_AGENTS{1'b0}} && e_sh != {N_AGENTS{1'b0}}` |
| `owner_data_dropped` | owner data response not captured: requester gets a stale buffer | **KILLED** | `TB FAIL @1455000 : reader observes the write` |
| `stale_put_commits` | a stale PUTM erases the (new) owner from the directory | **KILLED** | `CHECKER FAIL 20=20 t=0 : holders == {N_AGENTS{1'b0}} && e_sh == {N_AGENTS{1'b0}}` |
| `no_completion_wait` | transaction closed at grant: no unblock, entry never committed | **KILLED** | `CHECKER FAIL 20=20 t=0 : holders == {N_AGENTS{1'b0}} && e_sh == {N_AGENTS{1'b0}}` |
| `conflict_check_off` | two transactions on the same line at once (no per-line serialisation) | **KILLED** | `CHECKER FAIL 19=19 t=0 : nbusy <= 1` |
| `fwd_s_keeps_modified` | owner does not downgrade on a shared intervention: two copies, one Modified | **KILLED** | `CHECKER FAIL 27=27 t=0 : !m_a` |
| `inv_ignored_by_sharer` | sharer acknowledges the invalidation but keeps its copy: stale data later | **KILLED** | `CHECKER FAIL 28=28 t=0 : !s_a` |
| `putack_not_consumed` | eviction record never cleared: agent hangs | **KILLED** | `CHECKER FAIL 22=22 t=0 : e_sh == holders && hm == {N_AGENTS{1'b0}} && e_sh != {N_AGENTS{1'b0}}` |
| `eviction_buffer_ignores_fwd` | writeback race: owner mid-eviction cannot answer the intervention | **KILLED** | `CHECKER FAIL 32=32 t=0 : agent_err == {N_AGENTS*sf_coherence_pkg::AE_W{1'b0}}` |
| `amo_is_store` | AMO fetch-add replaced by a plain store (lost updates) | **KILLED** | `CHECKER FAIL 10=10 t=0 : ev_perf_newline[a*LB +: LB] == nl` |
| `strobes_ignored` | byte strobes ignored on stores | **KILLED** | `CHECKER FAIL 10=10 t=0 : ev_perf_newline[a*LB +: LB] == nl` |
| `upg_hit_skips_request` | store to a Shared line performed locally without an upgrade (no invalidation of other sharers) | **KILLED** | `CHECKER FAIL 9=9 t=0 : ev_perf_oldline[a*LB +: LB] == ol` |
**17 / 17 mutants killed.**

## 7. What is not covered

See docs/10. In particular: the directed testbench runs only in Icarus (Verilator 5.020 crashes on `fork` in `initial`), 64-byte-line data paths are verified by simulation only (formal uses 4-byte lines), and the mutation score is over the listed bug classes.

