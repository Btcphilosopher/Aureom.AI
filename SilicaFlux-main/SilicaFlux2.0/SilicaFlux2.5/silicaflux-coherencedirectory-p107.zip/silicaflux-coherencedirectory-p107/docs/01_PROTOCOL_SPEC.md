# 01 — MSI directory protocol specification

Scope: the protocol implemented by `sf_coherence_directory` / `sf_coherence_transient_fsm` / `sf_coherence_sharers` (directory side) and
`sf_coherence_agent_adapter` (agent side). Executable form: `model/sf_coherence_ref_model.py` (the model and this document describe the same
transition system; every rule below names the RTL signal and the check that covers it). Encodings: `rtl/coherence/sf_coherence_pkg.sv`.

**Initial configuration.** Two coherent caching agents, one directory controller, 64-byte lines, one outstanding coherence request per agent,
one open transaction per line. N (agents) and the window size (`DIR_LINES`) are parameters; N = 2 is the formally checked configuration,
N = 3 / 4 are simulated (docs/08).

## 1. Architecture

```
 CPU0 ─► agent0 ─┐  REQ  (GETS GETM UPG PUTS PUTM+data)       ┌──────────────────────────────┐
                 ├────────────────────────────────────────────►  directory controller        │
 CPU1 ─► agent1 ─┘  RSP  (INVACK  DATA+keep  COMPLETE)         │  per-agent transaction slot  │──► memory / LLC
        ▲  ▲     ◄───────────────────────────────────────────  │  (transient FSM + sharers)   │    (64-byte line port)
        │  └─────  SNP  (INV  FWD_S  FWD_M)                    │  + directory array (stable)  │
        └────────  GNT  (DATA_S DATA_M UPG PUTACK+data)        └──────────────────────────────┘
```

Four channels, all ready/valid, all separate (no shared buffering between classes — docs/04):

| channel | direction | messages | accepted when |
|---|---|---|---|
| REQ | agent → directory | `GETS GETM UPG PUTS PUTM`(+line data) | the agent's transaction slot is idle |
| RSP | agent → directory | `INVACK`, `DATA`(+line data, `keep`), `COMPLETE` | always (1 per cycle, round-robin) |
| SNP | directory → agent | `INV`, `FWD_S`, `FWD_M` | agent's RSP register is free |
| GNT | directory → agent | `DATA_S`, `DATA_M`, `UPG`, `PUTACK`(+line data for fills) | RSP register free and no snoop pending |

Message size model used by the traffic counters: 8-byte header + 64 data bytes for `PUTM`, `DATA`, `DATA_S`, `DATA_M`.

## 2. Stable states

**Cache line (agent):** `I` invalid · `S` shared, clean, read-only, any number of copies · `M` modified, the only valid copy, read-write.

**Directory entry (per line)** `{owner, sharers, state}`:

| state | meaning | sharers | owner | memory |
|---|---|---|---|---|
| `UNC` | no agent holds the line | 0 | – | current |
| `SHR` | one or more clean copies | ≠ 0, exact | – | current |
| `MOD` | exactly one agent holds `M` | = onehot(owner) | owner | possibly stale |

**Transient states** live in the transaction slot (one per agent), not in the array; a line is transient exactly while a slot is busy on it:

| slot state | meaning | waits for |
|---|---|---|
| `IDLE` | free | request |
| `WAIT` | request captured | the line to be free (no other busy slot on it) and the start arbiter |
| `GATHER` | `GK_INV`: SHR→MOD invalidating; `GK_FWD`: MOD→SHR or MOD→MOD, owner's dirty data; `GK_MEM`: memory read | INVACKs / owner DATA / memory |
| `MEMWR` | dirty data (owner's, or an eviction's) is written to memory | memory write acknowledgement |
| `GRANT` | grant / PUTACK offered to the requester | the requester's acceptance |
| `COMPL` | grant delivered; **line still blocked** | `RS_COMPLETE` from the requester |

Agent-side transient states are the *pending record* `{PS_*, line, lost, eviction data}`:
`IS` (GETS sent) · `IM` (GETM sent, or a UPG that lost its copy) · `SM` (UPG sent, S copy kept) · `MI` (PUTM sent, data kept in the eviction buffer) · `SI` (PUTS sent).

## 3. Invariants (each is asserted by `tb/sf_coh_checker.sv`, simulation and formal; id in brackets)

* **I1 single writer** — at most one agent holds `M` for a line (counting an agent whose eviction record is `MI` and has not lost the line) [17].
* **I2 no shared copy beside an owner** — if an agent holds `M`, no other agent holds `S` [18].
* **I3 one open transaction per line** [19].
* **I4 exact directory at quiescence** — if no slot is busy on a line: `UNC` ⇒ nobody holds it; `SHR` ⇒ sharers = exactly the agents holding `S`; `MOD` ⇒ sharers = owner = the agent holding `M` [20, 22, 25]. (Explicit `PUTS`/`PUTM` and the `keep` bit exist to keep this *exact*; there are no silent evictions.)
* **I5 memory is current when nobody owns** — `UNC`/`SHR` and not busy ⇒ memory = latest value [21, 23].
* **I6 every cached copy is current** — any `S`/`M` copy, and any live eviction buffer, equals the latest value of the line [15, 16].
* **I7 ownership only after invalidation** — a data/ownership grant is presented only when no acknowledgement is outstanding, and while it is in flight / being installed no other agent holds `M` (and, for `DATA_M`/`UPG`, no other copy at all) [26, 27, 28].
* **I8 data carried by the protocol is current** — a fill granted by the directory [14] and every line written to memory (writeback or intervention) [13] equals the latest value; a stale `PUTM` never writes memory.
* **I9 exactly one completion per grant** — a data/upgrade grant is followed by exactly one `COMPLETE`; no second grant before it [29, 30].
* **I10 no protocol error** — none of the sticky error bits of directory/agents is ever set [31, 32] (unexpected response, response from an agent that was not awaited, `GETS`/`GETM` from the recorded owner, `COMPLETE` out of turn, snoop the protocol cannot send, grant with no pending request).
* **Data value** — every operation observes the latest value in the per-location order and returns the independently recomputed result [7–12]; this is the reference model of docs/06.

## 4. Agent behaviour

**CPU operation × cache state** (agent main FSM `AS_*`; one operation at a time):

| op | `M` | `S` | `I`, set empty | `I`, set holds another line |
|---|---|---|---|---|
| LOAD | perform | perform | `GETS` → `IS` | evict victim first (`PUTM`+data if M, `PUTS` if S), then `GETS` |
| STORE / AMO | perform | `UPG` → `SM` | `GETM` → `IM` | evict victim first, then `GETM` |
| FLUSH(line) | `PUTM`+data → `MI` | `PUTS` → `SI` | no-op | no-op |
| FENCE | completes (nothing is ever outstanding after a response) | | | |

Out-of-window address, misaligned address or unknown opcode: error response, no side effect.

**Perform-on-grant.** When a `DATA_S` / `DATA_M` / `UPG` grant arrives the waiting CPU operation is performed **in the same cycle** the line is installed and
`COMPLETE` is queued. A competing snoop can never remove the line between install and use, so every granted request makes progress (no livelock).

**Snoop × state** (`sn_*`; snoop has priority over grant over CPU; taken only if the RSP register is free):

| snoop | line `S` | line `M` | pending `SM` (UPG sent) | pending `MI` | pending `SI` | absent |
|---|---|---|---|---|---|---|
| `INV` | drop → `INVACK` | *protocol error* (answers DATA, flags) | drop S copy → `INVACK`, pending becomes `IM` | error | `INVACK`, `lost := 1` | error flag, `INVACK` (cannot hang) |
| `FWD_S` | error | `DATA`(`keep`=1), `M`→`S` | – | `DATA` from the eviction buffer (`keep`=0), `lost := 1` | – | error |
| `FWD_M` | error | `DATA`(`keep`=0), `M`→`I` | – | `DATA` from the eviction buffer (`keep`=0), `lost := 1` | – | error |

**Grant × pending:** `DATA_S`/`IS`, `DATA_M`/`IM` or `SM`, `UPG`/`SM` → install, perform, `COMPLETE`; `PUTACK`/`MI` or `SI` → pending cleared (no `COMPLETE`); anything else sets `AE_GNT_UNEXPECT`.

## 5. Directory behaviour (the transaction table)

`start` = the slot wins the start arbiter (round-robin, one per cycle) while no other busy slot holds the same line. It reads the entry once (the *directory lookup*) and plans:

| request | entry | snoops (in GATHER) | memory | grant | new entry (committed on `COMPLETE`) |
|---|---|---|---|---|---|
| `GETS` | `UNC` | – | read | `DATA_S` | `SHR {R}` |
| `GETS` | `SHR` | – | read | `DATA_S` | `SHR sharers∪{R}` |
| `GETS` | `MOD`, owner O | `FWD_S`→O, wait `DATA` | **write** (owner data) | `DATA_S` (owner data) | `SHR {R}` ∪ `{O}` if `keep` |
| `GETM` | `UNC` | – | read | `DATA_M` | `MOD R` |
| `GETM` | `SHR` | `INV` to sharers∖{R}, wait all `INVACK` | read | `DATA_M` | `MOD R` |
| `GETM` | `MOD`, owner O | `FWD_M`→O, wait `DATA` | **write** (owner data) | `DATA_M` (owner data) | `MOD R` (ownership transfer) |
| `UPG`, R ∈ sharers, `SHR` | | `INV` to sharers∖{R}, wait all `INVACK` | – | `UPG` (no data) | `MOD R` |
| `UPG`, R ∉ sharers (lost its copy) | any | treated as `GETM` | | `DATA_M` | `MOD R` |
| `PUTS` | `SHR`, R ∈ sharers | – | – | `PUTACK` | sharers∖{R}; `UNC` if empty |
| `PUTS` | otherwise (**stale**) | – | – | `PUTACK` | unchanged |
| `PUTM` | `MOD`, owner = R | – | **write** (eviction data) | `PUTACK` | `UNC` |
| `PUTM` | otherwise (**stale**: lost the race to a transaction that took the line) | – | **none** | `PUTACK` | unchanged |

Design choices (all measured in docs/08): the owner's dirty data goes **through the directory** (no direct cache-to-cache path), which is written to memory on every
intervention (also on `MOD→MOD`; skipping that write is a one-line optimisation that saves 64 B per ownership transfer); the directory collects the acknowledgements itself,
so the requester never has to count them.

## 6. Races, and where each is resolved

| race | what happens | resolved by |
|---|---|---|
| **writeback vs intervention** — owner evicts (`PUTM` in flight / held back) while another agent's `GETS`/`GETM` of the line is served first | `FWD_*` reaches the owner in `MI`; it answers from the eviction buffer with `keep=0`, `lost := 1`; the directory later finds the `PUTM` **stale** (state ≠ `MOD`/owner ≠ R) and answers a bare `PUTACK`: no memory write, no entry change | agent `PS_MI` row; directory `PUTM` stale row; test T11 (forced + random), model mutant `stale_putm_writes` |
| **PUTS vs invalidation** | `INV` reaches the agent in `SI`; `INVACK`; the `PUTS` is stale | agent `PS_SI` row; directory `PUTS` stale row |
| **upgrade vs invalidation** — both sharers upgrade at once | the directory serialises them; the loser's `S` copy is invalidated while `UPG` is pending → `SM`→`IM`; its `UPG` finds it no longer a sharer and is served as `GETM` | agent `PS_SM` row; directory `UPG` rows; T03, T09 |
| **competing exclusive requests** | one open transaction per line; the later request waits in `WAIT` (no NACK) and starts after the earlier `COMPLETE` | `blocked` logic in `sf_coherence_directory`; I3; T03, T09 |
| **grant overtaking snoop** (different channels) | impossible: the line stays blocked until the requester's `COMPLETE` (it is sent after install), so no snoop for the line is issued while a grant is in flight | `TS_COMPL` |
| **capacity eviction during a miss** | one request outstanding per agent: the victim is evicted (and acknowledged) **before** the miss request is issued | agent EVAL logic |
| **reset** | synchronous reset empties caches and directory; dirty data is lost (memory keeps its image); no response is produced for cancelled operations; the golden model re-adopts the memory image | T08, random campaign |

## 7. Message-level cost of each operation (reads from the benchmark, docs/08)

| operation | messages | data transfers |
|---|---|---|
| read, line uncached/shared | GETS, DATA_S, COMPLETE | memory→requester (via directory) |
| read, line modified elsewhere | GETS, FWD_S, DATA, (mem write), DATA_S, COMPLETE | owner→directory→requester + one memory write |
| write, line uncached | GETM, DATA_M, COMPLETE | memory→requester |
| write, shared by k others | GETM, k×INV, k×INVACK, DATA_M, COMPLETE | memory→requester |
| upgrade, shared by k others | UPG, k×INV, k×INVACK, UPG-grant, COMPLETE | none |
| write, modified elsewhere | GETM, FWD_M, DATA, (mem write), DATA_M, COMPLETE | owner→directory→requester + one memory write |
| dirty eviction | PUTM(+data), PUTACK | agent→memory |
| clean eviction | PUTS, PUTACK | none |
