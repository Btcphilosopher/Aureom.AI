# 02 — Directory storage

## 1. What is tracked

| Item (mission §4) | Where | Width |
|---|---|---|
| cache-line address | **array index** (full-map directory over the coherent window) and `line` in the open transaction slot | `LIW = ⌈log2 DIR_LINES⌉` |
| state | directory array: `UNC / SHR / MOD` stable state; slot FSM: transient state | 2 bits / 3 bits |
| sharer vector | directory array entry | `N` bits (full bit-vector) |
| modified owner | directory array entry (explicit, redundant with the one-hot sharer vector in `MOD` — kept for checking and for a future pointer encoding) | `AIW = ⌈log2 N⌉` |
| pending requester | the **slot index** (slot *i* is attached to agent *i*'s REQ channel) | – |
| outstanding acknowledgements | per slot, `sf_coherence_sharers.waiting` (+ `to_send`) | `2N` bits per slot |
| transaction status | per slot: `state`, `type`, grant type, memory-op state, entry snapshot, `keep` | ≈ 8 + N + 2 + AIW + 3 bits and one 64-byte data buffer per slot |

Entry layout `{owner[AIW], sharers[N], state[2]}` → `ENTW = 2 + N + AIW` bits per line. Exactly one transaction per line is open, so the transient state needs **no per-line storage**: it is per slot (N slots), not per line. A line is "transient" exactly while a slot is busy on it.

## 2. Storage cost of the implemented representation

| agents N | bits / line (`ENTW`) | 16-line window | 1 024-line window | 64 Ki-line window (4 MiB of 64-B lines) |
|---|---|---|---|---|
| 2 | 5 | 80 b | 5 Kb | 320 Kb |
| 4 | 8 | 128 b | 8 Kb | 512 Kb |
| 8 | 13 | 208 b | 13 Kb | 832 Kb |
| 16 | 22 | 352 b | 22 Kb | 1.4 Mb |

The data buffers of the slots dominate the slot cost: `N × 64 B` in the directory (+ `N × 64 B` eviction buffer and `N × 64 B` × sets in the agents).

## 3. Is it scalable? — what the implementation does and does not claim

* **Scales in agents:** the sharer vector is a parameter (`N_AGENTS`); the slot count equals N; every arbiter is generic. N = 3 and 4 are simulated clean (docs/08). Full bit-vector storage grows linearly with N, which is the right trade for N ≤ 16.
* **Scales in window size only as far as a flop array does.** The array is a flat register vector indexed by line number, **with no tags**: it covers an explicit coherent window of `DIR_LINES` lines (default 16 in simulation). This is a *reference* implementation. A window of millions of lines needs the two standard changes below. **They are not implemented** and are listed as expansion work (docs/09):
  1. **SRAM-backed array** with a 1-cycle read in the `WAIT→start` step (the FSM already reads the entry once per transaction and commits once per transaction, so the array needs one read port and N write ports, or one write port with a commit queue).
  2. **Sparse (tagged) directory / snoop filter**: track only lines that are present in some cache (entries ≈ total cache lines × 1.5–2), each entry gets a tag; allocation evicts an old entry by *back-invalidating* its sharers — a new transient state `BACKINV` in the slot FSM. The `INV`/`INVACK` machinery of `sf_coherence_sharers` is exactly what back-invalidation needs.
* **Alternatives for large N**, not implemented: *limited pointers* (P pointers + overflow bit: `2 + P·log2N + 1` bits — N = 64, P = 4: 27 b vs 72 b) with broadcast-on-overflow; *coarse vector* (one bit per group of g agents: `N/g` bits, invalidations sent to whole groups, the extra `INVACK`s from non-holders are legal because an `INV` to a non-holder is acknowledged — the agent's `AE_SNP_ABSENT` path would become a legal path, to be re-verified).

## 4. Exactness of the sharer vector (why PUTS exists)

The checker asserts the vector is *exact* whenever a line is not busy (I4). This is why clean evictions are **explicit** (`PUTS`) and why an intervention response carries `keep`: with silent evictions the vector would be a superset, spurious `INV`s would be sent and the "no shared copy beside an unaccounted owner" check would have to allow unknown holders. The price is one 8-byte message per clean eviction (measured: `PUTS` bytes in docs/08). A silent-eviction variant is the first optimisation to evaluate if clean-eviction traffic matters (it needs the `AE_SNP_ABSENT` path to become legal).

## 5. Directory lookups

One per transaction, at `start` (`PD_LOOKUPS`): the slot reads its line's entry combinationally and snapshots it; the entry is committed once, when the transaction closes. One start per cycle (round-robin), so the lookup bandwidth is one per cycle and the array needs no more than one *read* per cycle.
