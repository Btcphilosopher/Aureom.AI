# SilicaFlux Project 107: CoherenceDirectory, hardware cache-coherence engine

Aureom.AI / SilicaFlux Cloud Semiconductor Systems. Primary RTL: `rtl/coherence/sf_coherence_directory.sv`.

> **Read first.** This package contains **no silicon data**. Every number is an RTL-simulation result (Icarus Verilog 12, Verilator 5.020), an exhaustive explicit-state model-checking result, a formal result (Yosys 0.33 + ABC PDR / SAT), a Yosys structure count, or an explicitly labelled assumption. **No frequency, area, power or timing is claimed.** It is **not ASIC-ready**. Two items named in the brief **do not exist in this repository** — **CacheForge** and an **AtomicEngine** (docs/00) — so nothing was integrated with them. By instruction, **nothing was committed to git**; this is delivered as a ZIP.

## What it is

A directory-based **MSI** cache-coherence subsystem: two (parameterised to N) coherent caching agents, one directory controller, 64-byte lines, **one open transaction per line**, four separate channels (REQ / RSP / SNP / GNT), explicit transient states, dirty-data intervention through the directory, explicit completion, explicit evictions and writebacks, per-line request ordering, no NACK, no retry loop.

```
 CPU0 ─► agent0 ─┐  REQ  GETS GETM UPG PUTS PUTM(+data)                 ┌─────────────────────────┐
                 ├──────────────────────────────────────────────────────►  directory controller   │
 CPU1 ─► agent1 ─┘  RSP  INVACK DATA(+keep) COMPLETE                     │  N transaction slots    │──► shared memory / LLC
        ▲  ▲     ◄──────────────────────────────────────────────────────  (transient FSM)         │    (64-byte line port)
        │  └─────  SNP  INV FWD_S FWD_M                                  │  + directory array      │
        └────────  GNT  DATA_S DATA_M UPG PUTACK                         └─────────────────────────┘
 non-coherent masters (DMA, scratchpad engines, management) ─► sf_coherence_nc_gateway ─► memory (never the directory)
```

## Definition of done — met

> *Two coherent caches can share data, acquire exclusive ownership, modify memory and observe each other's updates correctly under contention and injected stalls.*

* **Simulation:** 16 directed / random system tests (every scenario of mission §11), 38 swept configurations, a 240-run Verilator random campaign with mid-flight resets (N = 2, 3, 4) and 17 bug-injection mutants — checked cycle by cycle against an independent golden model (docs/06).
* **Formal:** all 69 safety assertions (no stale data, single owner, ownership only after invalidation, exact directory, one completion per grant, no protocol error) are **proved for all executions of any length** by ABC PDR for the **minimal 2-agent / 2-line instance** under a free environment, and each of the 17 injected bugs is found by the same harness (docs/07). Progress is **not** formally proved (docs/04, docs/07 §5).

## Results at a glance (all read from `reports/`)

| area | result | source |
|---|---|---|
| system regression (Icarus) | **16 / 16** tests PASS — 2 628 loads, 3 234 stores, 424 AMOs, 471 flushes compared against the golden model, 4 711 grants, 3 082 memory writes checked, 466 307 per-line invariant checks, **0 checker errors** | `reports/regression_directed.log`, docs/06 |
| litmus (blocking in-order agent) | SB `(0,0)` never; MP flag⇒data never violated; 2+2W cycle never — memory behaviour for the coherent window is sequentially consistent | T12 |
| atomics / false sharing | 2 × 80 concurrent fetch-adds = **160**; both writers' words retained in one line | T13 |
| non-coherent masters | gateway refuses window accesses by default; **stale read is observed without maintenance (negative control)**; correct FLUSH hand-over gives the DMA's data | T14, docs/05 |
| configuration sweep | **38 / 38** (stall 0–80 %, CPU stall 0–70 %, memory latency 1–6, sets 1–8, agents 2/3/4, window 2–16 lines) | `reports/sweep.csv` |
| Verilator random campaign | **240 / 240** runs, 6 geometries, 326 341 loads, 260 735 stores, 98 135 AMOs, 97 431 flushes, 533 208 grants, **960 mid-flight resets**, 61.5 M invariant checks, 0 errors; max observed op latency 114 cycles (0 % channel stall) … 300 cycles (85 % channel stalls) | `reports/rand_campaign.*` |
| RTL mutants (simulation) | **17 / 17 killed** | `reports/mutants_sim.md` |
| protocol model (exhaustive) | 2 agents × 2 lines × 3 ops: **1 780 432 states, 4 628 344 transitions, no violation, no deadlock** (+ three more configurations incl. 3 agents); 6 protocol mutants each reported | `reports/model.log` |
| **formal — unbounded** | **PDR proves all 69 assertions** (46 structural + 23 data) for the minimal instance on the frozen sources (structural set 53.28 s, full set 2286.11 s of solver time) ; **17 / 17** injected bugs found with counterexamples (depth 7–33) | `reports/fv_pdr_final_*.log`, `reports/mutants_pdr.md`, docs/07 |
| formal — bounded | BMC depth 14 clean (113 s, with the assumptions) ; plain k-induction fails at k ≤ 5 (PDR supersedes it) | docs/07 |
| latency (zero stalls, memory latency 1) | hit 3 · UPG 7 · cold miss 11 · load of a Modified line 13 · ownership transfer 13 · flush of M line 11 · miss that evicts M 20 cycles | `reports/latency.csv`, docs/03 |
| coherence traffic (benchmarks) | private data ≈ 3 B/op; ping-pong writes 167 B/op coherence + 64 B/op memory, directory 89 % busy; false sharing costs exactly as much as true sharing | `benchmarks/results.csv`, docs/08 |
| generic synthesis counts (Yosys) | directory N=2/16 lines 10 179 cells (1 795 flops); agent 4 sets 41 590 cells (3 545 flops) — structure counts only | `reports/yosys_stats.csv`, docs/03 |

## Deliverables (mission → file)

| mission deliverable | where |
|---|---|
| `sf_coherence_directory.sv` | `rtl/coherence/sf_coherence_directory.sv` |
| `sf_coherence_pkg.sv` | `rtl/coherence/sf_coherence_pkg.sv` |
| `sf_coherence_agent_adapter.sv` | `rtl/coherence/sf_coherence_agent_adapter.sv` (coherent MSI cache agent; the CacheForge-style integration point) |
| `sf_coherence_sharers.sv` | `rtl/coherence/sf_coherence_sharers.sv` |
| `sf_coherence_transient_fsm.sv` | `rtl/coherence/sf_coherence_transient_fsm.sv` |
| (mission §9) non-coherent interfaces | `rtl/coherence/sf_coherence_nc_gateway.sv`, docs/05; integration top `sf_coherence_subsystem.sv` |
| verification environment | `tb/` (checker = reference model + invariants, memory model, system / random / benchmark / latency testbenches), `model/sf_coherence_ref_model.py` (executable protocol spec + exhaustive checker), `scripts/` |
| formal properties | `tb/sf_coh_checker.sv` (compiled with `-DFORMAL`), `formal/` (harnesses, PDR / BMC runners, `.sby`), docs/07 |
| coherence traffic benchmarks | `tb/tb_sf_coherence_bench.sv`, `benchmarks/results.csv`, `docs/08_PERFORMANCE.md` |
| protocol specification | `docs/01_PROTOCOL_SPEC.md` (+ docs/02 storage, 03 microarchitecture, 04 ordering & deadlock, 05 non-coherent masters) |
| repository audit (§1) | `docs/00_AUDIT.md` |
| expansion study (§12) | `docs/09_EXPANSION.md` (investigation; MESI etc. **not implemented**, by instruction) |
| limitations | `docs/10_LIMITATIONS.md` |

## Key findings of the audit (docs/00)

* **No CacheForge, no AtomicEngine** anywhere in the repository.
* The existing caches (`sfmem_cache`, `direct_mapped_cache`, `set_assoc_cache`) are **explicitly non-coherent**, 16-byte default lines; MemoryCore docs/03 §8 states "no hardware coherence, one hart". The existing DataFabric (SFB2), Meridian and MemoryMatrix all state **no coherence**. This block is the coherence those documents leave out, for agents that opt in; DMA and scratchpad engines stay non-coherent and meet the window only through the gateway and the software rules of docs/05.
* The baseline Yosys 0.33 flow rejects `import`, structs and interfaces (stated in the DMA / DataFabric sources); the RTL therefore uses package localparams on flat vectors.

## Run it

```bash
scripts/run_all.sh quick        # lint, elaboration, model, directed + random regression  (~3 min)
scripts/run_all.sh full         # + sweep, Verilator campaign, mutants, benchmarks, latency, synthesis counts
formal/run_pdr.sh 3000          # unbounded proof, all properties (~25 min); FV_DEFS=-DFV_NODATA for the structural set (~1 min)
formal/run_formal.sh bmc 14     # bounded model check
python3 model/sf_coherence_ref_model.py --agents 2 --lines 2 --ops 3   # exhaustive protocol model
```
Tools: Icarus Verilog 12, Verilator 5.020, Yosys 0.33 (+ `yosys-abc`), Python 3. Everything is local.

## Layout

```
rtl/coherence/   sf_coherence_{pkg,sharers,transient_fsm,directory,agent_adapter,nc_gateway,subsystem}.sv  filelist.f
tb/              sf_coh_checker.sv (reference model + invariants)  sf_coh_mem_model.sv  tb_sf_coherence{,_rand,_bench,_lat}.sv
model/           sf_coherence_ref_model.py            executable protocol specification + exhaustive checker + protocol mutants
formal/          sf_coh_fv_top.sv (free-input, programmed, bounded-latency harnesses)  run_pdr.sh  run_formal.sh  sf_coherence.sby
benchmarks/      results.csv                         raw counters of the traffic benchmark
scripts/         run_all.sh run_sweep.py run_rand_campaign.py run_mutants.py run_pdr_mutants.py run_bench.sh make_*_report.py ...
docs/            00_AUDIT … 10_LIMITATIONS
reports/         every raw log / table the documents quote (see reports/README.md)
```

## What is NOT claimed (full list: docs/10)

* Formal results are **for the 2-agent, 2-line, 1-set, 4-byte-line instance**; N > 2, larger windows and 64-byte data paths are covered by simulation and the protocol model only.
* **No liveness proof.** Progress is a paper argument + model-level deadlock check + simulation watchdogs (docs/04, docs/07 §5).
* One outstanding request per agent, blocking in-order CPU port — the sequential-consistency statement depends on it.
* The directory array is a flop vector over an explicit window without tags; not a production-scale representation (docs/02).
* No silicon / FPGA / timing / area / power; SymbiYosys was not available (the `.sby` job was **not** executed); the directed testbench runs in Icarus only (Verilator 5.020 crashes on `fork` in `initial`).
