# SilicaFlux P107 CoherenceDirectory -- RTL file list (order matters: the package first)
sf_coherence_pkg.sv
sf_coherence_sharers.sv
sf_coherence_transient_fsm.sv
sf_coherence_directory.sv
sf_coherence_agent_adapter.sv
sf_coherence_nc_gateway.sv
sf_coherence_subsystem.sv
