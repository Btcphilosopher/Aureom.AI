// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: sf_coherence_sharers
//
// Snoop-target set and outstanding-acknowledgement tracker of ONE directory transaction.
//
//   load       : capture the set of agents that must be snooped (invalidation targets, or the single owner)
//   to_send    : targets whose snoop has not been issued yet          (one bit per agent, bit vector)
//   pick_*     : lowest-numbered target still to be issued (one snoop issued per cycle)
//   send_fire  : the snoop for pick_id was accepted by the SNP channel -> move it to `waiting`
//   waiting    : snoops issued, response (RS_INVACK / RS_DATA) not yet received  == outstanding acknowledgements
//   ack_v/id   : a response from agent ack_id arrived -> clear its waiting bit; ack_bad if it was not awaited
//   idle       : nothing left to send and nothing left to wait for   (invalidation complete)
//
// Scalability: the vector is N bits per transaction (full bit-vector); only transient state lives here, the
// per-line sharer set lives in the directory array (docs/02_DIRECTORY_STORAGE.md discusses limited-pointer /
// coarse / sparse alternatives for N > 16).  N is a parameter; N = 2 is the verified configuration.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_coherence_sharers #(
  parameter int N_AGENTS = 2,
  localparam int AIW = (N_AGENTS > 1) ? $clog2(N_AGENTS) : 1
) (
  input  wire                 clk,
  input  wire                 rst_n,
  input  wire                 load,
  input  wire [N_AGENTS-1:0]  load_mask,
  output wire [N_AGENTS-1:0]  to_send,
  output wire                 pick_v,
  output wire [AIW-1:0]       pick_id,
  input  wire                 send_fire,
  input  wire                 ack_v,
  input  wire [AIW-1:0]       ack_id,
  output wire [N_AGENTS-1:0]  waiting,
  output wire                 ack_bad,
  output wire                 idle
);
  reg [N_AGENTS-1:0] ts_r;
  reg [N_AGENTS-1:0] wt_r;

  assign to_send = ts_r;
  assign waiting = wt_r;
  assign idle    = (ts_r == {N_AGENTS{1'b0}}) && (wt_r == {N_AGENTS{1'b0}});

  // lowest set bit of to_send
  reg             pv;
  reg [AIW-1:0]   pid;
  integer         k;
  always @* begin
    pv  = 1'b0;
    pid = {AIW{1'b0}};
    for (k = N_AGENTS - 1; k >= 0; k = k - 1) begin
      if (ts_r[k]) begin
        pv  = 1'b1;
        pid = k[AIW-1:0];
      end
    end
  end
  assign pick_v  = pv;
  assign pick_id = pid;

  // an acknowledgement is valid only from an agent whose snoop was issued and not yet answered
  wire [N_AGENTS-1:0] ack_oh = ({{(N_AGENTS-1){1'b0}}, 1'b1} << ack_id);
  assign ack_bad = ack_v && ((wt_r & ack_oh) == {N_AGENTS{1'b0}});

  wire [N_AGENTS-1:0] fire_oh = ({{(N_AGENTS-1){1'b0}}, 1'b1} << pid);

  always @(posedge clk) begin
    if (!rst_n) begin
      ts_r <= {N_AGENTS{1'b0}};
      wt_r <= {N_AGENTS{1'b0}};
    end else if (load) begin
      ts_r <= load_mask;
      wt_r <= {N_AGENTS{1'b0}};
    end else begin
      if (send_fire && pv) begin
        ts_r <= ts_r & ~fire_oh;
        wt_r <= (wt_r & ~(ack_v ? ack_oh : {N_AGENTS{1'b0}})) | fire_oh;
      end else if (ack_v) begin
        wt_r <= wt_r & ~ack_oh;
      end
    end
  end

endmodule

`default_nettype wire
