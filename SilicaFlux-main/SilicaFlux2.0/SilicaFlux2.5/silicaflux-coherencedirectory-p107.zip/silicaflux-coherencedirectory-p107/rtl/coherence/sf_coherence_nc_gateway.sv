// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: sf_coherence_nc_gateway
//
// Port for a NON-COHERENT master (DMA engine, scratchpad engine, management / debug access) onto the shared
// memory.  It exists so that no master is silently treated as coherent (mission rule 9):
//
//   * Accesses OUTSIDE the coherent window are plain uncached memory accesses (forwarded unchanged).
//   * Accesses INSIDE the coherent window bypass the directory and the caches: the master sees / changes MEMORY,
//     not the caches.  That is only meaningful under the software protocol of docs/05 (agents FLUSH the lines
//     first, the NC master owns the buffer, agents never touch it until the hand-over).  The gateway therefore
//     REFUSES such accesses (error response, no memory side effect, counted) unless `cfg_allow_window` is set by
//     management software for the duration of a hand-over.  With cfg_allow_window = 0 an NC master can never
//     corrupt, or read stale data from, a coherent line by accident.
//   * One word (32-bit, byte strobes) per transaction, blocking, same request / response shape as SFB2
//     (R1 handshakes, R5 one response per request in order, R7 write response after the write is performed -- the
//     response is taken from the memory side).
//
// NC_CLASS only labels the instance in reports: 0 DMA, 1 scratchpad engine, 2 management / debug.
// Counters: allowed (outside window), window_ok (inside, permitted), refused (inside, not permitted), bytes.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_coherence_nc_gateway #(
  parameter int NC_CLASS   = 0,
  parameter int DIR_LINES  = 16,
  parameter int LINE_BYTES = 64,
  parameter int ADDR_W     = 32,
  parameter logic [31:0] COH_BASE = 32'h8000_0000
) (
  input  wire                  clk,
  input  wire                  rst_n,
  input  wire                  cfg_allow_window,
  // ---- NC master side (slave port of the gateway)
  input  wire                  s_req_valid,
  output wire                  s_req_ready,
  input  wire                  s_req_write,
  input  wire [ADDR_W-1:0]     s_req_addr,
  input  wire [31:0]           s_req_wdata,
  input  wire [3:0]            s_req_wstrb,
  output wire                  s_rsp_valid,
  input  wire                  s_rsp_ready,
  output wire [31:0]           s_rsp_rdata,
  output wire                  s_rsp_error,
  // ---- shared-memory side (word port)
  output wire                  m_req_valid,
  input  wire                  m_req_ready,
  output wire                  m_req_write,
  output wire [ADDR_W-1:0]     m_req_addr,
  output wire [31:0]           m_req_wdata,
  output wire [3:0]            m_req_wstrb,
  input  wire                  m_rsp_valid,
  output wire                  m_rsp_ready,
  input  wire [31:0]           m_rsp_rdata,
  input  wire                  m_rsp_error,
  // ---- counters
  output wire [31:0]           cnt_allowed,
  output wire [31:0]           cnt_window_ok,
  output wire [31:0]           cnt_refused,
  output wire [31:0]           cnt_bytes
);
  // state: 0 idle, 1 forwarding (waiting for memory response), 2 error response pending
  reg [1:0]          st;
  reg                w_r;
  reg [ADDR_W-1:0]   a_r;
  reg [31:0]         d_r;
  reg [3:0]          b_r;
  reg [31:0]         rd_r;
  reg                er_r;
  reg                fwd_sent;
  reg [31:0]         c_allowed, c_wok, c_ref, c_bytes;

  wire [ADDR_W-1:0] off      = s_req_addr - COH_BASE;
  wire              in_win   = (s_req_addr >= COH_BASE) && (off < DIR_LINES * LINE_BYTES);
  wire              misal    = |s_req_addr[1:0];
  wire              permit   = !in_win || cfg_allow_window;

  assign s_req_ready = (st == 2'd0);
  assign s_rsp_valid = (st == 2'd2);
  assign s_rsp_rdata = rd_r;
  assign s_rsp_error = er_r;

  assign m_req_valid = (st == 2'd1) && !fwd_sent;
  assign m_req_write = w_r;
  assign m_req_addr  = a_r;
  assign m_req_wdata = d_r;
  assign m_req_wstrb = b_r;
  assign m_rsp_ready = (st == 2'd1) && fwd_sent;

  assign cnt_allowed   = c_allowed;
  assign cnt_window_ok = c_wok;
  assign cnt_refused   = c_ref;
  assign cnt_bytes     = c_bytes;

  always @(posedge clk) begin
    if (!rst_n) begin
      st <= 2'd0; fwd_sent <= 1'b0; er_r <= 1'b0; rd_r <= 32'd0;
      c_allowed <= 32'd0; c_wok <= 32'd0; c_ref <= 32'd0; c_bytes <= 32'd0;
    end else begin
      case (st)
        2'd0: if (s_req_valid) begin
          w_r <= s_req_write; a_r <= s_req_addr; d_r <= s_req_wdata; b_r <= s_req_wstrb;
          fwd_sent <= 1'b0;
          if (permit && !misal) begin
            st <= 2'd1;
            if (in_win) c_wok <= c_wok + 32'd1; else c_allowed <= c_allowed + 32'd1;
          end else begin
            st <= 2'd2; er_r <= 1'b1; rd_r <= 32'd0;
            c_ref <= c_ref + 32'd1;
          end
        end
        2'd1: begin
          if (!fwd_sent && m_req_ready) fwd_sent <= 1'b1;
          if (fwd_sent && m_rsp_valid) begin
            rd_r <= m_rsp_rdata; er_r <= m_rsp_error; st <= 2'd2;
            c_bytes <= c_bytes + (w_r ? ((b_r[0] ? 32'd1 : 32'd0) + (b_r[1] ? 32'd1 : 32'd0) + (b_r[2] ? 32'd1 : 32'd0) + (b_r[3] ? 32'd1 : 32'd0)) : 32'd4);
          end
        end
        2'd2: if (s_rsp_ready) begin st <= 2'd0; er_r <= 1'b0; end
        default: st <= 2'd0;
      endcase
    end
  end
endmodule

`default_nettype wire
