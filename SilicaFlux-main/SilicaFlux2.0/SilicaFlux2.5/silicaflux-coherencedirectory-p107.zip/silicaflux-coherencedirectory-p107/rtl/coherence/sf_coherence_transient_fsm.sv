// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: sf_coherence_transient_fsm
//
// ONE directory transaction slot == the TRANSIENT states of the protocol.  The directory instantiates one per
// agent: slot i is attached to agent i's REQ channel, so "pending requester" is the slot index and an agent has
// at most one open transaction.  The directory's per-line array holds only STABLE states (UNC / SHR / MOD); a line
// is in a transient state exactly while some slot is active (>= GATHER) on it.
//
//   IDLE   --req-->  WAIT   --start-->  GATHER --done--> [MEMWR] --> GRANT --accepted--> COMPL --RS_COMPLETE--> IDLE
//                                          \----------------------------> GRANT (PUTS, stale PUTM, bare UPG)
//                              (PUTM, owner) --> MEMWR --> GRANT --accepted--> IDLE (PUTACK needs no completion)
//
//   GATHER does, concurrently and in any order, whatever the request needs before data / ownership may be granted:
//     * SHR -> MOD   : INV to every sharer except the requester, wait for ALL RS_INVACK     (sf_coherence_sharers)
//     * MOD -> SHR   : SN_FWD_S to the owner, wait for its RS_DATA (dirty intervention), write it to memory
//     * MOD -> MOD   : SN_FWD_M to the owner, wait for its RS_DATA (ownership transfer),   write it to memory
//     * UNC / SHR    : read memory
//   The grant is presented only when GATHER is complete (ownership never precedes invalidation; a requester never
//   receives backing-memory data while an owner holds newer data).  The directory entry is committed when the
//   transaction closes (RS_COMPLETE / PUTACK); the line stays blocked (other requests on it wait in WAIT) until then.
//
// Stale evictions (a PUTS / PUTM that lost a race against an earlier transaction on the same line, so the agent
// is no longer a sharer / owner) are recognised from the entry and answered with a bare PUTACK: no memory write,
// no entry change.  This is the explicit transient-state treatment of the writeback race (docs/01 section 6).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_coherence_transient_fsm #(
  parameter int N_AGENTS  = 2,
  parameter int SLOT_ID   = 0,
  parameter int DIR_LINES = 16,
  parameter int LINE_BYTES = 64,
  localparam int AIW = (N_AGENTS > 1) ? $clog2(N_AGENTS) : 1,
  localparam int LIW = (DIR_LINES > 1) ? $clog2(DIR_LINES) : 1,
  localparam int LB  = LINE_BYTES * 8
) (
  input  wire                  clk,
  input  wire                  rst_n,
  // ---- request capture (REQ channel of agent SLOT_ID)
  input  wire                  req_valid,
  output wire                  req_ready,
  input  wire [2:0]            req_type,
  input  wire [LIW-1:0]        req_line,
  input  wire [LB-1:0]         req_data,
  // ---- start / conflict arbitration (directory top)
  output wire                  wait_v,        // request captured, not started
  output wire                  busy,          // transaction open (GATHER .. COMPL): the line is blocked
  output wire [LIW-1:0]        line,
  input  wire                  start,         // granted by the start arbiter this cycle
  // ---- directory entry of `line` (combinational read, valid in WAIT)
  input  wire [1:0]            ent_st,
  input  wire [N_AGENTS-1:0]   ent_sh,
  input  wire [AIW-1:0]        ent_ow,
  // ---- commit of the new stable entry (closing the transaction)
  output reg                   commit_v,
  output wire [LIW-1:0]        commit_line,
  output reg  [1:0]            commit_st,
  output reg  [N_AGENTS-1:0]   commit_sh,
  output reg  [AIW-1:0]        commit_ow,
  // ---- snoop issue (to the directory's SNP arbiter)
  output wire                  snp_v,
  output wire [AIW-1:0]        snp_dst,
  output wire [1:0]            snp_type,
  input  wire                  snp_acc,
  // ---- responses routed to this slot (one per cycle)
  input  wire                  rsp_v,
  input  wire [1:0]            rsp_type,
  input  wire [AIW-1:0]        rsp_src,
  input  wire [LB-1:0]         rsp_data,
  input  wire                  rsp_keep,
  // ---- memory port client (directory memory arbiter)
  output wire                  mem_v,
  output wire                  mem_wr,
  output wire [LB-1:0]         mem_wdata,
  input  wire                  mem_acc,
  input  wire                  mem_done,
  input  wire [LB-1:0]         mem_rdata,
  // ---- grant channel to agent SLOT_ID
  output wire                  gnt_v,
  output wire [2:0]            gnt_type,
  output wire [LB-1:0]         gnt_data,
  input  wire                  gnt_acc,
  // ---- observability
  output wire [2:0]            state,
  output wire [1:0]            gather_kind,
  output wire [2:0]            txn_type,
  output wire [N_AGENTS-1:0]   acks_waiting,
  output wire [2:0]            gnt_type_o,
  // ---- event pulses (performance counters) and error pulses
  output wire                  ev_start,
  output wire                  ev_inv,          // an INV snoop was issued
  output wire                  ev_dirty,        // owner data response received
  output wire                  ev_own_xfer,     // ... and it served an exclusive request (ownership transfer)
  output wire                  ev_stale_put,    // stale eviction recognised at start
  output wire                  err_rsp,         // unexpected / mistyped response
  output wire                  err_compl,       // RS_COMPLETE while not waiting for it
  output wire                  err_own          // GETS / GETM from the recorded owner
);
  localparam logic [2:0] TS_IDLE_L   = sf_coherence_pkg::TS_IDLE;
  localparam logic [2:0] TS_WAIT_L   = sf_coherence_pkg::TS_WAIT;
  localparam logic [2:0] TS_GATHER_L = sf_coherence_pkg::TS_GATHER;
  localparam logic [2:0] TS_MEMWR_L  = sf_coherence_pkg::TS_MEMWR;
  localparam logic [2:0] TS_GRANT_L  = sf_coherence_pkg::TS_GRANT;
  localparam logic [2:0] TS_COMPL_L  = sf_coherence_pkg::TS_COMPL;

  localparam logic [2:0] RQ_GETS_L = sf_coherence_pkg::RQ_GETS;
  localparam logic [2:0] RQ_GETM_L = sf_coherence_pkg::RQ_GETM;
  localparam logic [2:0] RQ_UPG_L  = sf_coherence_pkg::RQ_UPG;
  localparam logic [2:0] RQ_PUTS_L = sf_coherence_pkg::RQ_PUTS;
  localparam logic [2:0] RQ_PUTM_L = sf_coherence_pkg::RQ_PUTM;
  localparam logic [1:0] DS_UNC_L  = sf_coherence_pkg::DS_UNC;
  localparam logic [1:0] DS_SHR_L  = sf_coherence_pkg::DS_SHR;
  localparam logic [1:0] DS_MOD_L  = sf_coherence_pkg::DS_MOD;

  /* verilator lint_off WIDTHTRUNC */
  localparam logic [AIW-1:0]      MY_ID = SLOT_ID;
  /* verilator lint_on WIDTHTRUNC */
  localparam logic [N_AGENTS-1:0] ME = ({{(N_AGENTS-1){1'b0}}, 1'b1} << SLOT_ID);

  reg [2:0]            st_r;
  reg [2:0]            ty_r;
  reg [LIW-1:0]        ln_r;
  reg [LB-1:0]         db_r;      // data buffer: evicted data, owner data, memory data -- what GRANT / MEMWR present
  reg                  kp_r;      // keep bit of the owner's response
  reg [1:0]            kd_r;      // snoop kind issued in GATHER (SN_INV / SN_FWD_S / SN_FWD_M)
  reg                  wa_r;      // memory write needed after GATHER (owner data)
  reg [2:0]            gt_r;      // grant type to present
  reg [1:0]            nm_r;      // memory op state: 0 none, 1 to issue, 2 issued / waiting
  reg [1:0]            e_st;      // directory entry snapshot taken at start
  reg [N_AGENTS-1:0]   e_sh;
  reg [AIW-1:0]        e_ow;

  assign state       = st_r;
  assign txn_type    = ty_r;
  assign line        = ln_r;
  assign commit_line = ln_r;
  assign wait_v      = (st_r == TS_WAIT_L);
  assign busy        = (st_r != TS_IDLE_L) && (st_r != TS_WAIT_L);
  assign req_ready   = (st_r == TS_IDLE_L);
  assign gnt_type_o  = gt_r;

  // ------------------------------------------------------------------ start decision (combinational on the entry)
  wire in_wait      = (st_r == TS_WAIT_L);
  wire start_fire   = in_wait && start;
  wire me_in_sh     = (ent_sh & ME) != {N_AGENTS{1'b0}};
  wire is_getm      = (ty_r == RQ_GETM_L) || ((ty_r == RQ_UPG_L) && !((ent_st == DS_SHR_L) && me_in_sh));
  wire ent_mod      = (ent_st == DS_MOD_L);
  wire ent_shr      = (ent_st == DS_SHR_L);
  wire [N_AGENTS-1:0] own_oh = ({{(N_AGENTS-1){1'b0}}, 1'b1} << ent_ow);
  wire putm_valid   = ent_mod && (ent_ow == MY_ID);
  wire puts_valid   = ent_shr && me_in_sh;

  // plan computed at start
  reg [N_AGENTS-1:0] p_mask;
  reg [1:0]          p_kind;
  reg [1:0]          p_nm;
  reg                p_wa;
  reg [2:0]          p_gt;
  reg [2:0]          p_next;
  reg                p_stale;
  always @* begin
    p_mask  = {N_AGENTS{1'b0}};
    p_kind  = sf_coherence_pkg::SN_NONE;
    p_nm    = 2'd0;
    p_wa    = 1'b0;
    p_gt    = sf_coherence_pkg::GN_NONE;
    p_next  = TS_GATHER_L;
    p_stale = 1'b0;
    if (ty_r == RQ_GETS_L) begin
      p_gt = sf_coherence_pkg::GN_DATA_S;
      if (ent_mod) begin
        p_mask = own_oh;  p_kind = sf_coherence_pkg::SN_FWD_S;  p_wa = 1'b1;
      end else begin
        p_nm = 2'd1;
      end
    end else if (is_getm) begin
      p_gt = sf_coherence_pkg::GN_DATA_M;
      if (ent_mod) begin
        p_mask = own_oh;  p_kind = sf_coherence_pkg::SN_FWD_M;  p_wa = 1'b1;
      end else if (ent_shr) begin
        p_mask = ent_sh & ~ME;  p_kind = sf_coherence_pkg::SN_INV;  p_nm = 2'd1;
      end else begin
        p_nm = 2'd1;
      end
    end else if (ty_r == RQ_UPG_L) begin      // requester is a sharer: data-less upgrade
      p_gt   = sf_coherence_pkg::GN_UPG;
      p_mask = ent_sh & ~ME;  p_kind = sf_coherence_pkg::SN_INV;
    end else if (ty_r == RQ_PUTS_L) begin
      p_gt    = sf_coherence_pkg::GN_PUTACK;
      p_next  = TS_GRANT_L;
      p_stale = !puts_valid;
    end else begin                            // RQ_PUTM
      p_gt    = sf_coherence_pkg::GN_PUTACK;
      p_stale = !putm_valid;
      if (putm_valid) begin p_next = TS_MEMWR_L; p_nm = 2'd1; end
      else            begin p_next = TS_GRANT_L; end
    end
  end

  // ------------------------------------------------------------------ sharer / ack tracker
  wire [N_AGENTS-1:0] sh_to_send;
  wire                sh_pick_v;
  wire [AIW-1:0]      sh_pick_id;
  wire [N_AGENTS-1:0] sh_waiting;
  wire                sh_ack_bad;
  wire                sh_idle;
  wire in_gather   = (st_r == TS_GATHER_L);
  wire rsp_ack     = in_gather && rsp_v && (rsp_type == sf_coherence_pkg::RS_INVACK || rsp_type == sf_coherence_pkg::RS_DATA);
  wire snd_fire    = in_gather && snp_acc;

  sf_coherence_sharers #(.N_AGENTS(N_AGENTS)) u_sh (
    .clk(clk), .rst_n(rst_n),
    .load(start_fire), .load_mask(p_mask),
    .to_send(sh_to_send), .pick_v(sh_pick_v), .pick_id(sh_pick_id),
    .send_fire(snd_fire),
    .ack_v(rsp_ack), .ack_id(rsp_src),
    .waiting(sh_waiting), .ack_bad(sh_ack_bad), .idle(sh_idle)
  );

  assign acks_waiting = sh_waiting;
  assign snp_v    = in_gather && sh_pick_v;
  assign snp_dst  = sh_pick_id;
  assign snp_type = kd_r;

  // response type must match the snoop kind that was issued
  wire rsp_type_bad = rsp_ack && ((rsp_type == sf_coherence_pkg::RS_INVACK && kd_r != sf_coherence_pkg::SN_INV) ||
                                  (rsp_type == sf_coherence_pkg::RS_DATA   && kd_r == sf_coherence_pkg::SN_INV) ||
                                  (rsp_type == sf_coherence_pkg::RS_DATA   && kd_r == sf_coherence_pkg::SN_NONE));
  assign err_rsp   = rsp_ack && (sh_ack_bad || rsp_type_bad);
  assign err_compl = rsp_v && (((rsp_type == sf_coherence_pkg::RS_COMPLETE) && (st_r != TS_COMPL_L)) ||
                               ((rsp_type != sf_coherence_pkg::RS_COMPLETE) && !in_gather));
  assign err_own   = start_fire && ent_mod && (ent_ow == MY_ID) && (ty_r == RQ_GETS_L || is_getm);

  // ------------------------------------------------------------------ memory port client
  assign mem_v     = ((st_r == TS_GATHER_L) || (st_r == TS_MEMWR_L)) && (nm_r == 2'd1);
  assign mem_wr    = (st_r == TS_MEMWR_L);
  assign mem_wdata = db_r;

  // ------------------------------------------------------------------ grant
  assign gnt_v    = (st_r == TS_GRANT_L);
  assign gnt_type = gt_r;
  assign gnt_data = db_r;

  // ------------------------------------------------------------------ closing the transaction: commit the entry
  wire close_put   = (st_r == TS_GRANT_L) && gnt_acc && (gt_r == sf_coherence_pkg::GN_PUTACK);
  wire close_compl = (st_r == TS_COMPL_L) && rsp_v && (rsp_type == sf_coherence_pkg::RS_COMPLETE);
  wire [N_AGENTS-1:0] keep_oh = ({{(N_AGENTS-1){1'b0}}, 1'b1} << e_ow);
  wire [N_AGENTS-1:0] sh_minus_me = e_sh & ~ME;
  always @* begin
    commit_v  = close_put || close_compl;
    commit_st = e_st;
    commit_sh = e_sh;
    commit_ow = e_ow;
    case (ty_r)
      RQ_GETS_L: begin
        commit_st = DS_SHR_L;
        commit_ow = {AIW{1'b0}};
        if (e_st == DS_MOD_L) commit_sh = ME | (kp_r ? keep_oh : {N_AGENTS{1'b0}});
        else                  commit_sh = e_sh | ME;
      end
      RQ_GETM_L, RQ_UPG_L: begin
        commit_st = DS_MOD_L;  commit_sh = ME;  commit_ow = MY_ID;
      end
      RQ_PUTS_L: begin
        if (e_st == DS_SHR_L && ((e_sh & ME) != {N_AGENTS{1'b0}})) begin
          commit_sh = sh_minus_me;
          commit_st = (sh_minus_me == {N_AGENTS{1'b0}}) ? DS_UNC_L : DS_SHR_L;
          commit_ow = {AIW{1'b0}};
        end
      end
      default: begin                           // RQ_PUTM
        if (e_st == DS_MOD_L && e_ow == MY_ID) begin
          commit_st = DS_UNC_L;  commit_sh = {N_AGENTS{1'b0}};  commit_ow = {AIW{1'b0}};
        end
      end
    endcase
  end

  // ------------------------------------------------------------------ sequencing
  wire gather_done = in_gather && sh_idle && (nm_r == 2'd0);

  always @(posedge clk) begin
    if (!rst_n) begin
      st_r <= TS_IDLE_L;
      nm_r <= 2'd0;
      kd_r <= sf_coherence_pkg::SN_NONE;
      ty_r <= RQ_GETS_L;
      ln_r <= {LIW{1'b0}};
      wa_r <= 1'b0;
      gt_r <= sf_coherence_pkg::GN_NONE;
      kp_r <= 1'b0;
      e_st <= DS_UNC_L;
      e_sh <= {N_AGENTS{1'b0}};
      e_ow <= {AIW{1'b0}};
    end else begin
      case (st_r)
        TS_IDLE_L: begin
          if (req_valid) begin
            st_r <= TS_WAIT_L;
            ty_r <= req_type;
            ln_r <= req_line;
            db_r <= req_data;
          end
        end
        TS_WAIT_L: begin
          if (start) begin
            st_r <= p_next;
            kd_r <= p_kind;
            nm_r <= p_nm;
            wa_r <= p_wa;
            gt_r <= p_gt;
            kp_r <= 1'b0;
            e_st <= ent_st;
            e_sh <= ent_sh;
            e_ow <= ent_ow;
          end
        end
        TS_GATHER_L: begin
          if (nm_r == 2'd1 && mem_acc) nm_r <= 2'd2;
          if (nm_r == 2'd2 && mem_done) begin
            nm_r <= 2'd0;
            db_r <= mem_rdata;
          end
          if (rsp_ack && rsp_type == sf_coherence_pkg::RS_DATA) begin
            db_r <= rsp_data;
            kp_r <= rsp_keep;
          end
          if (gather_done) begin
            if (wa_r) begin st_r <= TS_MEMWR_L; nm_r <= 2'd1; end
            else      begin st_r <= TS_GRANT_L; end
          end
        end
        TS_MEMWR_L: begin
          if (nm_r == 2'd1 && mem_acc) nm_r <= 2'd2;
          if (nm_r == 2'd2 && mem_done) begin
            nm_r <= 2'd0;
            st_r <= TS_GRANT_L;
          end
        end
        TS_GRANT_L: begin
          if (gnt_acc) begin
            if (gt_r == sf_coherence_pkg::GN_PUTACK) st_r <= TS_IDLE_L;
            else                                     st_r <= TS_COMPL_L;
          end
        end
        TS_COMPL_L: begin
          if (close_compl) st_r <= TS_IDLE_L;
        end
        default: st_r <= TS_IDLE_L;
      endcase
    end
  end

  // ------------------------------------------------------------------ observability / event pulses
  assign gather_kind = !in_gather ? sf_coherence_pkg::GK_NONE :
                       (kd_r == sf_coherence_pkg::SN_FWD_S || kd_r == sf_coherence_pkg::SN_FWD_M) && !sh_idle ? sf_coherence_pkg::GK_FWD :
                       (kd_r == sf_coherence_pkg::SN_INV) && !sh_idle ? sf_coherence_pkg::GK_INV :
                       (nm_r != 2'd0) ? sf_coherence_pkg::GK_MEM : sf_coherence_pkg::GK_NONE;
  assign ev_start     = start_fire;
  assign ev_inv       = snd_fire && (kd_r == sf_coherence_pkg::SN_INV) && sh_pick_v;
  assign ev_dirty     = rsp_ack && (rsp_type == sf_coherence_pkg::RS_DATA);
  assign ev_own_xfer  = ev_dirty && (kd_r == sf_coherence_pkg::SN_FWD_M);
  assign ev_stale_put = start_fire && p_stale && (ty_r == RQ_PUTS_L || ty_r == RQ_PUTM_L);

endmodule

`default_nettype wire
