// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: sf_coherence_pkg -- protocol constants
//
// SINGLE SOURCE OF TRUTH for every encoding that crosses a module, testbench or formal boundary:
// cache-line states, directory states, message types of the four coherence channels, the directory
// transaction (transient) FSM states, CPU-port operation codes, error bits and performance-counter indices.
//
// Coding rule inherited from the SilicaFlux Yosys-0.33 flow (same as sfdma / sfmem packages):
//   * synthesizable RTL uses ONLY localparams of this package, fully qualified (sf_coherence_pkg::NAME), inside
//     module bodies, on flat bit vectors.  No struct, no enum, no `import`, no package function, no interface.
//   * a package constant is NOT used in a module parameter list or a port width: geometry (agents, lines, line
//     bytes) is module parameters with local derived widths.
//
// PROTOCOL: directory-based MSI, blocking per line (one open transaction per line), explicit completion
//           (unblock) message, directory-mediated dirty intervention.  Specification: docs/01_PROTOCOL_SPEC.md,
//           executable form: model/sf_coherence_ref_model.py.  Classification: SYNTHESIZABLE (constants).
// =============================================================================
`default_nettype none

package sf_coherence_pkg;

  // ---------------------------------------------------------------- cache-line states (agent array)
  localparam logic [1:0] CS_I = 2'd0;   // Invalid
  localparam logic [1:0] CS_S = 2'd1;   // Shared   : clean, read-only, possibly several copies
  localparam logic [1:0] CS_M = 2'd2;   // Modified : the only valid copy, read-write, memory may be stale

  // ---------------------------------------------------------------- directory STABLE states (per line)
  localparam logic [1:0] DS_UNC = 2'd0; // Uncached / no owner : no agent holds the line, memory is current
  localparam logic [1:0] DS_SHR = 2'd1; // Shared              : sharers != 0, memory is current, nobody holds M
  localparam logic [1:0] DS_MOD = 2'd2; // Modified            : exactly one owner holds M, memory may be stale

  // ---------------------------------------------------------------- REQ channel  (agent -> directory)
  localparam logic [2:0] RQ_NONE = 3'd0;
  localparam logic [2:0] RQ_GETS = 3'd1; // read shared      (miss, load)
  localparam logic [2:0] RQ_GETM = 3'd2; // read exclusive   (miss, store/amo)
  localparam logic [2:0] RQ_UPG  = 3'd3; // upgrade S -> M   (store hit on a Shared line), no data returned
  localparam logic [2:0] RQ_PUTS = 3'd4; // evict a Shared line (explicit, keeps the sharer vector exact)
  localparam logic [2:0] RQ_PUTM = 3'd5; // evict a Modified line + writeback data

  // ---------------------------------------------------------------- RSP channel  (agent -> directory)
  localparam logic [1:0] RS_NONE     = 2'd0;
  localparam logic [1:0] RS_INVACK   = 2'd1; // invalidation done (no data)
  localparam logic [1:0] RS_DATA     = 2'd2; // dirty-data intervention response (+ keep bit)
  localparam logic [1:0] RS_COMPLETE = 2'd3; // requester installed the grant: closes the transaction (unblock)

  // ---------------------------------------------------------------- SNP channel  (directory -> agent)
  localparam logic [1:0] SN_NONE  = 2'd0;
  localparam logic [1:0] SN_INV   = 2'd1; // drop your Shared copy, answer RS_INVACK
  localparam logic [1:0] SN_FWD_S = 2'd2; // you own the line: send the data, keep a Shared copy
  localparam logic [1:0] SN_FWD_M = 2'd3; // you own the line: send the data, drop the line (ownership transfer)

  // ---------------------------------------------------------------- GNT channel  (directory -> agent)
  localparam logic [2:0] GN_NONE   = 3'd0;
  localparam logic [2:0] GN_DATA_S = 3'd1; // fill, install Shared
  localparam logic [2:0] GN_DATA_M = 3'd2; // fill, install Modified (all other copies already gone)
  localparam logic [2:0] GN_UPG    = 3'd3; // upgrade granted, no data (the requester's Shared copy is current)
  localparam logic [2:0] GN_PUTACK = 3'd4; // eviction acknowledged (also answers a stale eviction)

  // ---------------------------------------------------------------- directory transaction (TRANSIENT) states
  localparam logic [2:0] TS_IDLE   = 3'd0; // slot free
  localparam logic [2:0] TS_WAIT   = 3'd1; // request captured, waiting to win the line / start arbiter
  localparam logic [2:0] TS_GATHER = 3'd2; // invalidating sharers / intervening at the owner / reading memory
  localparam logic [2:0] TS_MEMWR  = 3'd3; // writing owner or evicted data to memory
  localparam logic [2:0] TS_GRANT  = 3'd4; // presenting the grant (or PUTACK) to the requester
  localparam logic [2:0] TS_COMPL  = 3'd5; // grant delivered, waiting for RS_COMPLETE (line stays blocked)

  // GATHER sub-state: what the transaction is waiting for (reported on the debug bus)
  localparam logic [1:0] GK_NONE = 2'd0;
  localparam logic [1:0] GK_INV  = 2'd1; // SHR -> MOD: invalidation acknowledgements outstanding
  localparam logic [1:0] GK_FWD  = 2'd2; // MOD -> SHR / MOD -> MOD: waiting for the owner's dirty data
  localparam logic [1:0] GK_MEM  = 2'd3; // waiting for the memory read

  // ---------------------------------------------------------------- CPU-side operations of the agent adapter
  localparam logic [2:0] OP_LOAD  = 3'd0; // 32-bit load
  localparam logic [2:0] OP_STORE = 3'd1; // 32-bit store with byte strobes
  localparam logic [2:0] OP_AMO   = 3'd2; // atomic fetch-and-add on a 32-bit word (returns the old value)
  localparam logic [2:0] OP_FLUSH = 3'd3; // cache maintenance: write back (if Modified) and invalidate one line
  localparam logic [2:0] OP_FENCE = 3'd4; // completes when this agent has nothing outstanding (always, blocking)

  // ---------------------------------------------------------------- agent main FSM and pending-record states
  localparam logic [1:0] AS_IDLE = 2'd0;
  localparam logic [1:0] AS_EVAL = 2'd1;
  localparam logic [1:0] AS_WAIT = 2'd2;
  localparam logic [1:0] AS_RESP = 2'd3;

  localparam logic [2:0] PS_NONE = 3'd0;
  localparam logic [2:0] PS_IS   = 3'd1; // GETS issued, waiting for GN_DATA_S
  localparam logic [2:0] PS_IM   = 3'd2; // GETM issued (or UPG that lost its copy), waiting for GN_DATA_M
  localparam logic [2:0] PS_SM   = 3'd3; // UPG issued, S copy kept, waiting for GN_UPG (or becomes PS_IM on SN_INV)
  localparam logic [2:0] PS_MI   = 3'd4; // PUTM issued, dirty data kept in the eviction buffer, waiting for GN_PUTACK
  localparam logic [2:0] PS_SI   = 3'd5; // PUTS issued, waiting for GN_PUTACK

  // ---------------------------------------------------------------- sticky error / protocol-violation bits
  // directory (dbg_err)
  localparam int DE_RSP_NOMATCH   = 0;   // a response matched no open transaction
  localparam int DE_RSP_UNEXPECT  = 1;   // response from an agent that was not awaited, or of the wrong type
  localparam int DE_REQ_FROM_OWN  = 2;   // GetS/GetM from the agent the directory records as owner
  localparam int DE_COMPL_UNEXP   = 3;   // RS_COMPLETE in a slot that is not waiting for it
  localparam int DE_MEM_PROTO     = 4;   // memory response without an outstanding memory request
  localparam int DE_W             = 5;
  // agent (dbg_err)
  localparam int AE_SNP_UNEXPECT  = 0;   // snoop that the protocol cannot send (e.g. FWD to a non-owner)
  localparam int AE_SNP_ABSENT    = 1;   // INV for a line that is not present (acked anyway)
  localparam int AE_GNT_UNEXPECT  = 2;   // grant without a matching pending request
  localparam int AE_W             = 3;

  // ---------------------------------------------------------------- performance counters (32-bit, saturating)
  // directory
  localparam int PD_GETS        = 0;   // shared reads started
  localparam int PD_GETM        = 1;   // exclusive requests started (GETM)
  localparam int PD_UPG         = 2;   // upgrades started
  localparam int PD_PUTS        = 3;   // clean evictions
  localparam int PD_PUTM        = 4;   // dirty evictions (writebacks)
  localparam int PD_INV         = 5;   // invalidation snoops sent
  localparam int PD_OWN_XFER    = 6;   // ownership transfers (owner -> new owner)
  localparam int PD_DIRTY_INT   = 7;   // dirty-data interventions (owner data responses)
  localparam int PD_LOOKUPS     = 8;   // directory lookups (one per started transaction)
  localparam int PD_STALL_CONF  = 9;   // slot-cycles a request waited because its line was busy
  localparam int PD_STALL_GATH  = 10;  // slot-cycles in GATHER (coherence wait: acks / owner data / memory)
  localparam int PD_BUSY_CYC    = 11;  // cycles with at least one transaction open
  localparam int PD_RETRIES     = 12;  // requests deferred at least once by a same-line conflict
  localparam int PD_BYTES_REQ   = 13;  // coherence traffic bytes, REQ channel
  localparam int PD_BYTES_RSP   = 14;  // ... RSP channel
  localparam int PD_BYTES_SNP   = 15;  // ... SNP channel
  localparam int PD_BYTES_GNT   = 16;  // ... GNT channel
  localparam int PD_MEM_RD_B    = 17;  // memory-port bytes read
  localparam int PD_MEM_WR_B    = 18;  // memory-port bytes written
  localparam int PD_STALE_PUT   = 19;  // stale evictions answered with a bare PUTACK (race outcomes)
  localparam int PD_N           = 20;
  // agent
  localparam int PA_OPS         = 0;   // CPU operations completed
  localparam int PA_HITS        = 1;   // operations performed from the array without a coherence request
  localparam int PA_MISS_RD     = 2;   // GETS issued
  localparam int PA_MISS_WR     = 3;   // GETM issued
  localparam int PA_UPG         = 4;   // UPG issued
  localparam int PA_EVICT_M     = 5;   // PUTM issued
  localparam int PA_EVICT_S     = 6;   // PUTS issued
  localparam int PA_SNP_INV     = 7;   // invalidations received
  localparam int PA_SNP_FWD     = 8;   // dirty interventions served
  localparam int PA_WAIT_CYC    = 9;   // cycles the CPU port was blocked waiting for coherence
  localparam int PA_N           = 10;

  // ---------------------------------------------------------------- message size model for the traffic counters
  localparam int HDR_BYTES = 8;          // header of every coherence message (type, line, ids); data adds LINE_BYTES

endpackage

`default_nettype wire
