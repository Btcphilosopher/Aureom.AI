// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: sf_coherence_agent_adapter
//
// Coherent caching agent: a small direct-mapped MSI cache (64-byte lines) with a blocking 32-bit CPU-side port
// and the four coherence channels toward sf_coherence_directory.  It is the integration point for a CPU / cache:
//   * CPU side     : one operation at a time (LOAD, STORE with byte strobes, AMO fetch-add, FLUSH line, FENCE),
//                    completed in order; the response is presented only after the operation is PERFORMED.
//   * coherence    : REQ / RSP out, SNP / GNT in, ready/valid, flat vectors (sf_coherence_pkg encodings).
//   * the existing SilicaFlux caches (sfmem_cache, direct_mapped_cache, set_assoc_cache) are NONCOHERENT with 16/64-B
//     lines and no snoop port; they are not wrapped here.  This adapter shows the minimum a cache must add to join
//     the protocol (docs/05_NONCOHERENT_AND_INTEGRATION.md): an ownership state, an eviction record that can still
//     answer a snoop, and a snoop responder with priority over the CPU.
//
// MSI array (per set): state I/S/M, tag = line index in the coherent window, 512-bit data.
//   LOAD  : hit S/M -> perform.                       miss -> [evict victim: PUTM(+data) / PUTS] -> GETS
//   STORE : hit M   -> perform.   hit S -> UPG.       miss -> [evict victim]                      -> GETM
//   AMO   : as STORE; the fetch-and-add is one indivisible read-modify-write on an M line.
//   FLUSH : hit M -> PUTM (write back), hit S -> PUTS, line absent -> no-op.  Used by software for NON-COHERENT
//           agents (DMA / scratchpad / management): after FLUSH the line is in memory and in no cache.
//
// ONE outstanding coherence request per agent.  The pending record {PS_*, line, lost, eviction data} is what makes
// races explicit (sf_coherence_pkg PS_*):
//   PS_MI (PUTM sent): still answers SN_FWD_S / SN_FWD_M from the eviction buffer, then remembers it lost the line;
//                      the directory then treats the PUTM as STALE and answers a bare PUTACK.
//   PS_SI (PUTS sent): answers SN_INV; the PUTS then becomes stale.
//   PS_SM (UPG sent) : an SN_INV that wins the race drops the S copy and the request becomes a GETM (PS_IM): the
//                      directory answers a UPG from a non-sharer with GN_DATA_M.
// PERFORM-ON-GRANT: when a GETS/GETM/UPG grant arrives, the waiting CPU operation is performed in the SAME cycle as
// the line is installed (and RS_COMPLETE is queued).  A competing snoop can therefore never steal the line between
// install and use: every granted request makes progress (livelock freedom).
//
// Priorities (one event per cycle): snoop > grant > CPU.  A snoop / grant is taken only if the RSP output
// register is free (rs_v == 0); that register drains into a directory that always consumes RSP, so a snoop can
// always be answered eventually.
//
// Reset: synchronous; the cache is emptied (dirty data is LOST -- same as the existing MemoryCore rule R1).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_coherence_agent_adapter #(
  parameter int AGENT_ID   = 0,
  parameter int N_AGENTS   = 2,
  parameter int DIR_LINES  = 16,
  parameter int CACHE_SETS = 4,          // power of two, <= DIR_LINES
  parameter int LINE_BYTES = 64,
  parameter int ADDR_W     = 32,
  parameter logic [31:0] COH_BASE = 32'h8000_0000,
  localparam int LIW  = (DIR_LINES > 1) ? $clog2(DIR_LINES) : 1,
  localparam int LB   = LINE_BYTES * 8,
  localparam int WPL  = LINE_BYTES / 4,
  localparam int WIW  = (WPL > 1) ? $clog2(WPL) : 1,
  localparam int OFW  = $clog2(LINE_BYTES),
  localparam int SETW = (CACHE_SETS > 1) ? $clog2(CACHE_SETS) : 1
) (
  input  wire                  clk,
  input  wire                  rst_n,
  // ---- CPU side (blocking, in order)
  input  wire                  cpu_req_valid,
  output wire                  cpu_req_ready,
  input  wire [2:0]            cpu_op,
  input  wire [ADDR_W-1:0]     cpu_addr,
  input  wire [31:0]           cpu_wdata,
  input  wire [3:0]            cpu_wstrb,
  output wire                  cpu_rsp_valid,
  input  wire                  cpu_rsp_ready,
  output wire [31:0]           cpu_rdata,
  output wire                  cpu_rsp_err,
  // ---- REQ out
  output wire                  rq_valid,
  input  wire                  rq_ready,
  output wire [2:0]            rq_type,
  output wire [LIW-1:0]        rq_line,
  output wire [LB-1:0]         rq_data,
  // ---- RSP out
  output wire                  rs_valid,
  input  wire                  rs_ready,
  output wire [1:0]            rs_type,
  output wire [LIW-1:0]        rs_line,
  output wire [LB-1:0]         rs_data,
  output wire                  rs_keep,
  // ---- SNP in
  input  wire                  sn_valid,
  output wire                  sn_ready,
  input  wire [1:0]            sn_type,
  input  wire [LIW-1:0]        sn_line,
  // ---- GNT in
  input  wire                  gn_valid,
  output wire                  gn_ready,
  input  wire [2:0]            gn_type,
  input  wire [LIW-1:0]        gn_line,
  input  wire [LB-1:0]         gn_data,
  // ---- observability
  output wire [CACHE_SETS*2-1:0]   dbg_cs,
  output wire [CACHE_SETS*LIW-1:0] dbg_tag,
  output wire [CACHE_SETS*LB-1:0]  dbg_data,
  output wire [2:0]            dbg_p_st,
  output wire [LIW-1:0]        dbg_p_line,
  output wire                  dbg_p_lost,
  output wire [LB-1:0]         dbg_p_data,
  output wire [1:0]            dbg_a_st,
  // performed-operation event (combinational, for the golden model): the operation takes effect at this clock edge
  output reg                   ev_perf_v,
  output reg                   ev_perf_wr,
  output reg  [LIW-1:0]        ev_perf_line,
  output reg  [WIW-1:0]        ev_perf_word,
  output reg  [31:0]           ev_perf_rdata,       // value returned to the CPU (load / amo old value)
  output reg  [LB-1:0]         ev_perf_newline,     // whole line after the operation (== old line for a load)
  output reg  [LB-1:0]         ev_perf_oldline,     // whole line the operation found (checked against the golden model)
  output wire [sf_coherence_pkg::AE_W-1:0]   dbg_err,
  output wire [sf_coherence_pkg::PA_N*32-1:0] perf
);
  localparam int AE_W_L = sf_coherence_pkg::AE_W;
  localparam int PA_N_L = sf_coherence_pkg::PA_N;
  localparam logic [1:0] CS_I_L = sf_coherence_pkg::CS_I;
  localparam logic [1:0] CS_S_L = sf_coherence_pkg::CS_S;
  localparam logic [1:0] CS_M_L = sf_coherence_pkg::CS_M;
  localparam logic [2:0] PS_NONE_L = sf_coherence_pkg::PS_NONE;
  localparam logic [2:0] PS_IS_L = sf_coherence_pkg::PS_IS;
  localparam logic [2:0] PS_IM_L = sf_coherence_pkg::PS_IM;
  localparam logic [2:0] PS_SM_L = sf_coherence_pkg::PS_SM;
  localparam logic [2:0] PS_MI_L = sf_coherence_pkg::PS_MI;
  localparam logic [2:0] PS_SI_L = sf_coherence_pkg::PS_SI;
  localparam logic [1:0] AS_IDLE_L = sf_coherence_pkg::AS_IDLE;
  localparam logic [1:0] AS_EVAL_L = sf_coherence_pkg::AS_EVAL;
  localparam logic [1:0] AS_WAIT_L = sf_coherence_pkg::AS_WAIT;
  localparam logic [1:0] AS_RESP_L = sf_coherence_pkg::AS_RESP;
  localparam logic [2:0] OP_LOAD_L  = sf_coherence_pkg::OP_LOAD;
  localparam logic [2:0] OP_STORE_L = sf_coherence_pkg::OP_STORE;
  localparam logic [2:0] OP_AMO_L   = sf_coherence_pkg::OP_AMO;
  localparam logic [2:0] OP_FLUSH_L = sf_coherence_pkg::OP_FLUSH;
  localparam logic [2:0] OP_FENCE_L = sf_coherence_pkg::OP_FENCE;
  localparam logic [1:0] SN_INV_L   = sf_coherence_pkg::SN_INV;
  localparam logic [1:0] SN_FWD_S_L = sf_coherence_pkg::SN_FWD_S;
  localparam logic [1:0] SN_FWD_M_L = sf_coherence_pkg::SN_FWD_M;
  localparam logic [2:0] GN_DATA_S_L = sf_coherence_pkg::GN_DATA_S;
  localparam logic [2:0] GN_DATA_M_L = sf_coherence_pkg::GN_DATA_M;
  localparam logic [2:0] GN_UPG_L    = sf_coherence_pkg::GN_UPG;
  localparam logic [2:0] GN_PUTACK_L = sf_coherence_pkg::GN_PUTACK;
  localparam logic [1:0] RS_INVACK_L   = sf_coherence_pkg::RS_INVACK;
  localparam logic [1:0] RS_DATA_L     = sf_coherence_pkg::RS_DATA;
  localparam logic [1:0] RS_COMPLETE_L = sf_coherence_pkg::RS_COMPLETE;

  // ------------------------------------------------------------------ state
  reg [CACHE_SETS*2-1:0]   arr_st;
  reg [CACHE_SETS*LIW-1:0] arr_tag;
  reg [CACHE_SETS*LB-1:0]  arr_data;
  reg [1:0]   a_st;
  reg [2:0]   op_code;
  reg [ADDR_W-1:0] op_addr;
  reg [31:0]  op_wdata;
  reg [3:0]   op_wstrb;
  reg [2:0]   p_st;
  reg [LIW-1:0] p_line;
  reg         p_lost;
  reg [LB-1:0] p_data;
  reg         rq_v;
  reg [2:0]   rq_t;
  reg [LIW-1:0] rq_l;
  reg [LB-1:0] rq_d;
  reg         rs_v;
  reg [1:0]   rs_t;
  reg [LIW-1:0] rs_l;
  reg [LB-1:0] rs_d;
  reg         rs_k;
  reg [31:0]  resp_rdata;
  reg         resp_err;
  reg [AE_W_L-1:0] err_r;
  reg [PA_N_L*32-1:0] perf_r;

  assign dbg_cs = arr_st;  assign dbg_tag = arr_tag;  assign dbg_data = arr_data;
  assign dbg_p_st = p_st;  assign dbg_p_line = p_line; assign dbg_p_lost = p_lost; assign dbg_p_data = p_data;
  assign dbg_a_st = a_st;
  assign rq_valid = rq_v;  assign rq_type = rq_t;  assign rq_line = rq_l;  assign rq_data = rq_d;
  assign rs_valid = rs_v;  assign rs_type = rs_t;  assign rs_line = rs_l;  assign rs_data = rs_d; assign rs_keep = rs_k;
  assign cpu_req_ready = (a_st == AS_IDLE_L);
  assign cpu_rsp_valid = (a_st == AS_RESP_L);
  assign cpu_rdata     = resp_rdata;
  assign cpu_rsp_err   = resp_err;
  assign dbg_err = err_r;
  assign perf    = perf_r;

  // ------------------------------------------------------------------ operation decode
  wire [ADDR_W-1:0] op_off   = op_addr - COH_BASE;
  wire              op_inwin = (op_addr >= COH_BASE) && (op_off < DIR_LINES * LINE_BYTES);
  wire              op_misal = |op_addr[1:0];
  wire [LIW-1:0]    op_line  = op_off[OFW +: LIW];
  wire [WIW-1:0]    op_word  = (WPL > 1) ? op_off[2 +: WIW] : {WIW{1'b0}};
  wire [SETW-1:0]   op_set   = (CACHE_SETS > 1) ? op_line : {SETW{1'b0}};
  wire              op_is_wr = (op_code == OP_STORE_L) || (op_code == OP_AMO_L);

  // set lookup for the CPU operation
  reg [1:0]    h_st;
  reg [LIW-1:0] h_tag;
  reg [LB-1:0] h_data;
  integer s0;
  always @* begin
    h_st = CS_I_L; h_tag = {LIW{1'b0}}; h_data = {LB{1'b0}};
    for (s0 = 0; s0 < CACHE_SETS; s0 = s0 + 1)
      if (op_set == s0) begin
        h_st   = arr_st[s0*2 +: 2];
        h_tag  = arr_tag[s0*LIW +: LIW];
        h_data = arr_data[s0*LB +: LB];
      end
  end
  wire op_hit = (h_st != CS_I_L) && (h_tag == op_line);

  // set lookup for a snoop
  wire [SETW-1:0] sn_set = (CACHE_SETS > 1) ? sn_line : {SETW{1'b0}};
  reg [1:0]    sn_st;
  reg [LIW-1:0] sn_tag;
  reg [LB-1:0] sn_dat;
  integer s1;
  always @* begin
    sn_st = CS_I_L; sn_tag = {LIW{1'b0}}; sn_dat = {LB{1'b0}};
    for (s1 = 0; s1 < CACHE_SETS; s1 = s1 + 1)
      if (sn_set == s1) begin
        sn_st  = arr_st[s1*2 +: 2];
        sn_tag = arr_tag[s1*LIW +: LIW];
        sn_dat = arr_data[s1*LB +: LB];
      end
  end
  wire sn_hit = (sn_st != CS_I_L) && (sn_tag == sn_line);

  wire [SETW-1:0] gn_set = (CACHE_SETS > 1) ? gn_line : {SETW{1'b0}};

  // ------------------------------------------------------------------ channel arbitration of the single array port
  assign sn_ready = !rs_v;
  assign gn_ready = !rs_v && !sn_valid;
  wire snp_take = sn_valid && !rs_v;
  wire gnt_take = gn_valid && !rs_v && !sn_valid;

  // ------------------------------------------------------------------ operation apply (load / store / amo on a line)
  wire [LB-1:0] ap_src = (gnt_take && gn_type != GN_UPG_L) ? gn_data : h_data;
  reg  [LB-1:0] ap_new;
  reg  [31:0]   ap_old;
  integer w, b;
  always @* begin
    ap_new = ap_src;
    ap_old = 32'd0;
    for (w = 0; w < WPL; w = w + 1)
      if (op_word == w) ap_old = ap_src[w*32 +: 32];
    for (w = 0; w < WPL; w = w + 1)
      if (op_word == w) begin
        if (op_code == OP_STORE_L) begin
          for (b = 0; b < 4; b = b + 1)
            if (op_wstrb[b]) ap_new[w*32 + b*8 +: 8] = op_wdata[b*8 +: 8];
        end else if (op_code == OP_AMO_L) begin
          ap_new[w*32 +: 32] = ap_old + op_wdata;
        end
      end
  end
  wire [31:0] ap_rdata = (op_code == OP_STORE_L) ? 32'd0 : ap_old;

  // ------------------------------------------------------------------ next-state logic
  reg [CACHE_SETS*2-1:0]   arr_st_n;
  reg [CACHE_SETS*LIW-1:0] arr_tag_n;
  reg [CACHE_SETS*LB-1:0]  arr_data_n;
  reg [1:0]   a_st_n;
  reg [2:0]   p_st_n;
  reg [LIW-1:0] p_line_n;
  reg         p_lost_n;
  reg [LB-1:0] p_data_n;
  reg         rq_v_n;
  reg [2:0]   rq_t_n;
  reg [LIW-1:0] rq_l_n;
  reg [LB-1:0] rq_d_n;
  reg         rs_v_n;
  reg [1:0]   rs_t_n;
  reg [LIW-1:0] rs_l_n;
  reg [LB-1:0] rs_d_n;
  reg         rs_k_n;
  reg [31:0]  resp_rdata_n;
  reg         resp_err_n;
  reg [AE_W_L-1:0] err_n;
  reg ev_hit, ev_miss_rd, ev_miss_wr, ev_upg, ev_evict_m, ev_evict_s, ev_snp_inv, ev_snp_fwd, ev_done;
  integer sI;

  always @* begin
    arr_st_n   = arr_st;   arr_tag_n  = arr_tag;  arr_data_n = arr_data;
    a_st_n     = a_st;
    p_st_n     = p_st;     p_line_n   = p_line;   p_lost_n   = p_lost;  p_data_n = p_data;
    rq_v_n     = rq_v && !rq_ready;
    rq_t_n     = rq_t;     rq_l_n     = rq_l;     rq_d_n      = rq_d;
    rs_v_n     = rs_v && !rs_ready;
    rs_t_n     = rs_t;     rs_l_n     = rs_l;     rs_d_n      = rs_d;   rs_k_n = rs_k;
    resp_rdata_n = resp_rdata;
    resp_err_n   = resp_err;
    err_n        = err_r;
    ev_hit = 1'b0; ev_miss_rd = 1'b0; ev_miss_wr = 1'b0; ev_upg = 1'b0; ev_evict_m = 1'b0; ev_evict_s = 1'b0;
    ev_snp_inv = 1'b0; ev_snp_fwd = 1'b0; ev_done = 1'b0;
    ev_perf_v = 1'b0; ev_perf_wr = 1'b0; ev_perf_line = op_line; ev_perf_word = op_word;
    ev_perf_rdata = 32'd0; ev_perf_newline = ap_new; ev_perf_oldline = ap_src;

    // ============================ 1. snoop (highest priority) =====================================================
    if (snp_take) begin
      if ((p_st != PS_NONE_L) && (p_line == sn_line)) begin
        // the snooped line is the one being evicted / upgraded: answer from the pending record
        if (p_st == PS_MI_L && !p_lost && (sn_type == SN_FWD_S_L || sn_type == SN_FWD_M_L)) begin
          rs_v_n = 1'b1; rs_t_n = RS_DATA_L; rs_l_n = sn_line; rs_d_n = p_data; rs_k_n = 1'b0;
          p_lost_n = 1'b1; ev_snp_fwd = 1'b1;
        end else if (p_st == PS_SI_L && !p_lost && sn_type == SN_INV_L) begin
          rs_v_n = 1'b1; rs_t_n = RS_INVACK_L; rs_l_n = sn_line; rs_k_n = 1'b0;
          p_lost_n = 1'b1; ev_snp_inv = 1'b1;
        end else if (p_st == PS_SM_L && sn_type == SN_INV_L) begin
          for (sI = 0; sI < CACHE_SETS; sI = sI + 1)
            if (sn_set == sI) arr_st_n[sI*2 +: 2] = CS_I_L;
          rs_v_n = 1'b1; rs_t_n = RS_INVACK_L; rs_l_n = sn_line; rs_k_n = 1'b0;
          p_st_n = PS_IM_L; ev_snp_inv = 1'b1;
        end else begin
          err_n[sf_coherence_pkg::AE_SNP_UNEXPECT] = 1'b1;
          if (sn_type == SN_INV_L) begin
            rs_v_n = 1'b1; rs_t_n = RS_INVACK_L; rs_l_n = sn_line; rs_k_n = 1'b0;
          end
        end
      end else if (sn_hit) begin
        if (sn_type == SN_INV_L) begin
          for (sI = 0; sI < CACHE_SETS; sI = sI + 1)
            if (sn_set == sI) arr_st_n[sI*2 +: 2] = CS_I_L;
          rs_v_n = 1'b1; rs_l_n = sn_line; rs_k_n = 1'b0; ev_snp_inv = 1'b1;
          if (sn_st == CS_S_L) rs_t_n = RS_INVACK_L;
          else begin rs_t_n = RS_DATA_L; rs_d_n = sn_dat; err_n[sf_coherence_pkg::AE_SNP_UNEXPECT] = 1'b1; end
        end else if (sn_st == CS_M_L && sn_type == SN_FWD_S_L) begin
          for (sI = 0; sI < CACHE_SETS; sI = sI + 1)
            if (sn_set == sI) arr_st_n[sI*2 +: 2] = CS_S_L;
          rs_v_n = 1'b1; rs_t_n = RS_DATA_L; rs_l_n = sn_line; rs_d_n = sn_dat; rs_k_n = 1'b1; ev_snp_fwd = 1'b1;
        end else if (sn_st == CS_M_L && sn_type == SN_FWD_M_L) begin
          for (sI = 0; sI < CACHE_SETS; sI = sI + 1)
            if (sn_set == sI) arr_st_n[sI*2 +: 2] = CS_I_L;
          rs_v_n = 1'b1; rs_t_n = RS_DATA_L; rs_l_n = sn_line; rs_d_n = sn_dat; rs_k_n = 1'b0; ev_snp_fwd = 1'b1;
        end else begin
          err_n[sf_coherence_pkg::AE_SNP_UNEXPECT] = 1'b1;
        end
      end else begin
        // line not present: cannot happen with exact sharer tracking; acknowledge an INV so the system cannot hang
        if (sn_type == SN_INV_L) begin
          rs_v_n = 1'b1; rs_t_n = RS_INVACK_L; rs_l_n = sn_line; rs_k_n = 1'b0;
          err_n[sf_coherence_pkg::AE_SNP_ABSENT] = 1'b1;
        end else begin
          err_n[sf_coherence_pkg::AE_SNP_UNEXPECT] = 1'b1;
        end
      end
    end

    // ============================ 2. grant =========================================================================
    if (gnt_take) begin
      if (p_st == PS_NONE_L || gn_line != p_line) begin
        err_n[sf_coherence_pkg::AE_GNT_UNEXPECT] = 1'b1;
      end else if (gn_type == GN_PUTACK_L) begin
        if (p_st == PS_MI_L || p_st == PS_SI_L) p_st_n = PS_NONE_L;
        else err_n[sf_coherence_pkg::AE_GNT_UNEXPECT] = 1'b1;
      end else if ((a_st == AS_WAIT_L) && (op_line == gn_line) &&
                   (((gn_type == GN_DATA_S_L) && (p_st == PS_IS_L)) ||
                   ((gn_type == GN_DATA_M_L) && (p_st == PS_IM_L || p_st == PS_SM_L)) ||
                   ((gn_type == GN_UPG_L)    && (p_st == PS_SM_L)))) begin
        // install + perform the waiting CPU operation atomically
        for (sI = 0; sI < CACHE_SETS; sI = sI + 1)
          if (gn_set == sI) begin
            arr_st_n[sI*2 +: 2]        = (gn_type == GN_DATA_S_L) ? CS_S_L : CS_M_L;
            arr_tag_n[sI*LIW +: LIW]   = gn_line;
            arr_data_n[sI*LB +: LB]    = ap_new;
          end
        rs_v_n = 1'b1; rs_t_n = RS_COMPLETE_L; rs_l_n = gn_line; rs_k_n = 1'b0;
        p_st_n = PS_NONE_L;
        a_st_n = AS_RESP_L;
        resp_rdata_n = ap_rdata;
        resp_err_n   = 1'b0;
        ev_perf_v = 1'b1; ev_perf_wr = op_is_wr; ev_perf_line = gn_line; ev_perf_rdata = ap_rdata;
        ev_done = 1'b1;
      end else begin
        err_n[sf_coherence_pkg::AE_GNT_UNEXPECT] = 1'b1;
      end
    end

    // ============================ 3. CPU side =====================================================================
    case (a_st)
      AS_IDLE_L: begin
        if (cpu_req_valid) a_st_n = AS_EVAL_L;
      end
      AS_EVAL_L: begin
        if (!snp_take && !gnt_take && !rq_v) begin
          if (!op_inwin || op_misal || op_code > OP_FENCE_L) begin
            resp_err_n = 1'b1; resp_rdata_n = 32'd0; a_st_n = AS_RESP_L; ev_done = 1'b1;
          end else if (op_code == OP_FENCE_L) begin
            resp_err_n = 1'b0; resp_rdata_n = 32'd0; a_st_n = AS_RESP_L; ev_done = 1'b1;
          end else if (op_code == OP_FLUSH_L) begin
            if (op_hit) begin
              // evict this line (victim == target)
              for (sI = 0; sI < CACHE_SETS; sI = sI + 1)
                if (op_set == sI) arr_st_n[sI*2 +: 2] = CS_I_L;
              rq_v_n = 1'b1; rq_l_n = h_tag; p_line_n = h_tag; p_lost_n = 1'b0; a_st_n = AS_WAIT_L;
              if (h_st == CS_M_L) begin rq_t_n = sf_coherence_pkg::RQ_PUTM; rq_d_n = h_data; p_data_n = h_data; p_st_n = PS_MI_L; ev_evict_m = 1'b1; end
              else                begin rq_t_n = sf_coherence_pkg::RQ_PUTS; p_st_n = PS_SI_L; ev_evict_s = 1'b1; end
            end else begin
              resp_err_n = 1'b0; resp_rdata_n = 32'd0; a_st_n = AS_RESP_L; ev_done = 1'b1;
            end
          end else if (op_hit && (op_code == OP_LOAD_L || h_st == CS_M_L)) begin
            // hit: perform now
            if (op_is_wr)
              for (sI = 0; sI < CACHE_SETS; sI = sI + 1)
                if (op_set == sI) arr_data_n[sI*LB +: LB] = ap_new;
            resp_rdata_n = ap_rdata; resp_err_n = 1'b0; a_st_n = AS_RESP_L;
            ev_perf_v = 1'b1; ev_perf_wr = op_is_wr; ev_perf_rdata = ap_rdata;
            ev_hit = 1'b1; ev_done = 1'b1;
          end else if (op_hit) begin
            // store / amo on a Shared line: upgrade
            rq_v_n = 1'b1; rq_t_n = sf_coherence_pkg::RQ_UPG; rq_l_n = op_line;
            p_st_n = PS_SM_L; p_line_n = op_line; p_lost_n = 1'b0; a_st_n = AS_WAIT_L; ev_upg = 1'b1;
          end else if (h_st != CS_I_L) begin
            // miss with a valid victim in the set: evict it first
            for (sI = 0; sI < CACHE_SETS; sI = sI + 1)
              if (op_set == sI) arr_st_n[sI*2 +: 2] = CS_I_L;
            rq_v_n = 1'b1; rq_l_n = h_tag; p_line_n = h_tag; p_lost_n = 1'b0; a_st_n = AS_WAIT_L;
            if (h_st == CS_M_L) begin rq_t_n = sf_coherence_pkg::RQ_PUTM; rq_d_n = h_data; p_data_n = h_data; p_st_n = PS_MI_L; ev_evict_m = 1'b1; end
            else                begin rq_t_n = sf_coherence_pkg::RQ_PUTS; p_st_n = PS_SI_L; ev_evict_s = 1'b1; end
          end else begin
            // miss, set empty: request the line
            rq_v_n = 1'b1; rq_l_n = op_line; p_line_n = op_line; p_lost_n = 1'b0; a_st_n = AS_WAIT_L;
            if (op_code == OP_LOAD_L) begin rq_t_n = sf_coherence_pkg::RQ_GETS; p_st_n = PS_IS_L; ev_miss_rd = 1'b1; end
            else                      begin rq_t_n = sf_coherence_pkg::RQ_GETM; p_st_n = PS_IM_L; ev_miss_wr = 1'b1; end
          end
        end
      end
      AS_WAIT_L: begin
        // eviction finished (PUTACK consumed): re-evaluate, or finish a FLUSH.  (Gets finish via the grant path.)
        if (p_st == PS_NONE_L) begin
          if (op_code == OP_FLUSH_L) begin resp_err_n = 1'b0; resp_rdata_n = 32'd0; a_st_n = AS_RESP_L; ev_done = 1'b1; end
          else a_st_n = AS_EVAL_L;
        end
      end
      AS_RESP_L: begin
        if (cpu_rsp_ready) a_st_n = AS_IDLE_L;
      end
      default: a_st_n = AS_IDLE_L;
    endcase
  end

  // ------------------------------------------------------------------ registers
  function [31:0] sat_inc(input [31:0] a, input inc);
    sat_inc = (a == 32'hFFFF_FFFF) ? a : (a + {31'd0, inc});
  endfunction

  always @(posedge clk) begin
    if (!rst_n) begin
      arr_st   <= {CACHE_SETS*2{1'b0}};
      a_st     <= AS_IDLE_L;
      p_st     <= PS_NONE_L;
      p_lost   <= 1'b0;
      rq_v     <= 1'b0;
      rs_v     <= 1'b0;
      resp_err <= 1'b0;
      err_r    <= {AE_W_L{1'b0}};
      perf_r   <= {PA_N_L*32{1'b0}};
    end else begin
      arr_st   <= arr_st_n;
      a_st     <= a_st_n;
      p_st     <= p_st_n;
      p_lost   <= p_lost_n;
      rq_v     <= rq_v_n;
      rs_v     <= rs_v_n;
      resp_err <= resp_err_n;
      err_r    <= err_n;
      perf_r[sf_coherence_pkg::PA_OPS*32 +: 32]      <= sat_inc(perf_r[sf_coherence_pkg::PA_OPS*32 +: 32], (a_st == AS_RESP_L) && cpu_rsp_ready);
      perf_r[sf_coherence_pkg::PA_HITS*32 +: 32]     <= sat_inc(perf_r[sf_coherence_pkg::PA_HITS*32 +: 32], ev_hit);
      perf_r[sf_coherence_pkg::PA_MISS_RD*32 +: 32]  <= sat_inc(perf_r[sf_coherence_pkg::PA_MISS_RD*32 +: 32], ev_miss_rd);
      perf_r[sf_coherence_pkg::PA_MISS_WR*32 +: 32]  <= sat_inc(perf_r[sf_coherence_pkg::PA_MISS_WR*32 +: 32], ev_miss_wr);
      perf_r[sf_coherence_pkg::PA_UPG*32 +: 32]      <= sat_inc(perf_r[sf_coherence_pkg::PA_UPG*32 +: 32], ev_upg);
      perf_r[sf_coherence_pkg::PA_EVICT_M*32 +: 32]  <= sat_inc(perf_r[sf_coherence_pkg::PA_EVICT_M*32 +: 32], ev_evict_m);
      perf_r[sf_coherence_pkg::PA_EVICT_S*32 +: 32]  <= sat_inc(perf_r[sf_coherence_pkg::PA_EVICT_S*32 +: 32], ev_evict_s);
      perf_r[sf_coherence_pkg::PA_SNP_INV*32 +: 32]  <= sat_inc(perf_r[sf_coherence_pkg::PA_SNP_INV*32 +: 32], ev_snp_inv);
      perf_r[sf_coherence_pkg::PA_SNP_FWD*32 +: 32]  <= sat_inc(perf_r[sf_coherence_pkg::PA_SNP_FWD*32 +: 32], ev_snp_fwd);
      perf_r[sf_coherence_pkg::PA_WAIT_CYC*32 +: 32] <= sat_inc(perf_r[sf_coherence_pkg::PA_WAIT_CYC*32 +: 32], (a_st == AS_WAIT_L));
    end
    // data-path registers: not reset (the state bits above qualify them)
    arr_tag    <= arr_tag_n;
    arr_data   <= arr_data_n;
    p_line     <= p_line_n;
    p_data     <= p_data_n;
    rq_t       <= rq_t_n;
    rq_l       <= rq_l_n;
    rq_d       <= rq_d_n;
    rs_t       <= rs_t_n;
    rs_l       <= rs_l_n;
    rs_d       <= rs_d_n;
    rs_k       <= rs_k_n;
    resp_rdata <= resp_rdata_n;
    if (a_st == AS_IDLE_L && cpu_req_valid) begin
      op_code  <= cpu_op;
      op_addr  <= cpu_addr;
      op_wdata <= cpu_wdata;
      op_wstrb <= cpu_wstrb;
    end
  end

endmodule

`default_nettype wire
