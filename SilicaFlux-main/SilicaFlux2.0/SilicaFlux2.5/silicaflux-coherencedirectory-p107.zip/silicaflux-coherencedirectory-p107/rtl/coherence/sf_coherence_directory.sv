// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: sf_coherence_directory  -- PRIMARY RTL
//
// Directory controller of the SilicaFlux MSI coherence subsystem.
//
//   Caching agents --REQ--> [ per-agent transaction slot ]--GNT--> agents
//                  --RSP--> [ sf_coherence_transient_fsm x N ]--SNP--> agents
//                            |  directory array (stable state per line)  |
//                            +--> memory-port arbiter --> shared memory / LLC (line granularity)
//
// Four SEPARATE channels, each ready/valid, flat vectors (agent i = slice i):
//   REQ  agent -> dir : GETS / GETM / UPG / PUTS / PUTM(+data)       accepted only by an idle slot  (<= 1 per agent)
//   RSP  agent -> dir : INVACK / DATA(+keep) / COMPLETE              ALWAYS consumed (1 per cycle, round-robin): the
//                                                                    sink of the dependency chain REQ -> SNP -> RSP
//   SNP  dir -> agent : INV / FWD_S / FWD_M                          arbitrated per destination agent
//   GNT  dir -> agent : DATA_S / DATA_M / UPG / PUTACK(+data)        driven by exactly one slot (the requester's)
//
// Directory entry per line (stable): {owner[AIW], sharers[N], state[2]}   state UNC / SHR / MOD (sf_coherence_pkg).
//   UNC : sharers = 0                              no agent holds the line, memory current
//   SHR : sharers != 0, no owner                   memory current, every sharer holds a clean copy
//   MOD : sharers = onehot(owner)                  the owner holds the only copy; memory may be stale
//   Exactness invariant: whenever no transaction is open on a line, `sharers` equals the set of agents that hold or
//   are evicting a copy (explicit PUTS/PUTM keep it exact; the keep bit of an intervention response keeps it exact).
// Transient states live in the transaction slots (sf_coherence_transient_fsm): a line is transient exactly while a
// slot is busy on it.  ONE transaction per line: a request whose line is busy waits in its slot (no NACK, no drop).
//
// Arbiters (all round-robin => bounded wait; see docs/04_ORDERING_DEADLOCK.md):
//   start   : one transaction starts per cycle among slots whose line is not busy      (== one directory lookup/cycle)
//   memory  : one outstanding memory operation at a time; slot -> port -> response routed back to that slot
//   snoop   : per destination agent
//   response: one RSP accepted per cycle
//
// Geometry: DIR_LINES lines of LINE_BYTES (default 64 B) form the coherent window; messages carry the line INDEX
// within the window (LIW bits); the integrator adds the window base when talking to the memory system.
// The array is a flop vector (reference implementation); an SRAM-backed array is the scaling path
// (docs/02_DIRECTORY_STORAGE.md).
//
// Reset: synchronous, all transactions are discarded, every line returns to UNC (caches are reset with it).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_coherence_directory #(
  parameter int N_AGENTS   = 2,
  parameter int DIR_LINES  = 16,
  parameter int LINE_BYTES = 64,
  localparam int AIW  = (N_AGENTS > 1) ? $clog2(N_AGENTS) : 1,
  localparam int LIW  = (DIR_LINES > 1) ? $clog2(DIR_LINES) : 1,
  localparam int LB   = LINE_BYTES * 8,
  localparam int ENTW = 2 + N_AGENTS + AIW
) (
  input  wire                         clk,
  input  wire                         rst_n,
  // ---- REQ  (agents -> directory)
  input  wire [N_AGENTS-1:0]          req_valid,
  output wire [N_AGENTS-1:0]          req_ready,
  input  wire [N_AGENTS*3-1:0]        req_type,
  input  wire [N_AGENTS*LIW-1:0]      req_line,
  input  wire [N_AGENTS*LB-1:0]       req_data,
  // ---- RSP  (agents -> directory)
  input  wire [N_AGENTS-1:0]          rsp_valid,
  output wire [N_AGENTS-1:0]          rsp_ready,
  input  wire [N_AGENTS*2-1:0]        rsp_type,
  input  wire [N_AGENTS*LIW-1:0]      rsp_line,
  input  wire [N_AGENTS*LB-1:0]       rsp_data,
  input  wire [N_AGENTS-1:0]          rsp_keep,
  // ---- SNP  (directory -> agents)
  output wire [N_AGENTS-1:0]          snp_valid,
  input  wire [N_AGENTS-1:0]          snp_ready,
  output wire [N_AGENTS*2-1:0]        snp_type,
  output wire [N_AGENTS*LIW-1:0]      snp_line,
  // ---- GNT  (directory -> agents)
  output wire [N_AGENTS-1:0]          gnt_valid,
  input  wire [N_AGENTS-1:0]          gnt_ready,
  output wire [N_AGENTS*3-1:0]        gnt_type,
  output wire [N_AGENTS*LIW-1:0]      gnt_line,
  output wire [N_AGENTS*LB-1:0]       gnt_data,
  // ---- shared memory / LLC port (line granularity, one outstanding operation)
  output wire                         mem_req_valid,
  input  wire                         mem_req_ready,
  output wire                         mem_req_wr,
  output wire [LIW-1:0]               mem_req_line,
  output wire [LB-1:0]                mem_req_wdata,
  input  wire                         mem_rsp_valid,      // read data, or write performed (SFB2 R7)
  output wire                         mem_rsp_ready,
  input  wire [LB-1:0]                mem_rsp_rdata,
  // ---- observability (debug / formal / testbench)
  output wire [DIR_LINES*ENTW-1:0]    dbg_dir,
  output wire [N_AGENTS*3-1:0]        dbg_slot_state,
  output wire [N_AGENTS*LIW-1:0]      dbg_slot_line,
  output wire [N_AGENTS*3-1:0]        dbg_slot_type,
  output wire [N_AGENTS-1:0]          dbg_slot_busy,
  output wire [N_AGENTS*N_AGENTS-1:0] dbg_slot_waiting,
  output wire [N_AGENTS*3-1:0]        dbg_slot_gtype,
  output wire [N_AGENTS*2-1:0]        dbg_slot_gk,
  output wire [N_AGENTS*LB-1:0]       dbg_slot_data,
  output wire [N_AGENTS-1:0]          dbg_slot_wait,
  output wire [N_AGENTS-1:0]          dbg_mem_wr_perf,    // pulse: slot's memory WRITE accepted (for the reference model)
  output wire [sf_coherence_pkg::DE_W-1:0]   dbg_err,
  output wire [sf_coherence_pkg::PD_N*32-1:0] perf
);
  localparam int DE_W_L = sf_coherence_pkg::DE_W;
  localparam int PD_N_L = sf_coherence_pkg::PD_N;

  // ------------------------------------------------------------------ directory array
  reg [DIR_LINES*ENTW-1:0] dir_r;
  assign dbg_dir = dir_r;

  // ------------------------------------------------------------------ per-slot buses
  wire [N_AGENTS-1:0]          s_wait, s_busy, s_start;
  wire [N_AGENTS*LIW-1:0]      s_line;
  wire [N_AGENTS*2-1:0]        s_ent_st;
  wire [N_AGENTS*N_AGENTS-1:0] s_ent_sh;
  wire [N_AGENTS*AIW-1:0]      s_ent_ow;
  wire [N_AGENTS-1:0]          s_commit_v;
  wire [N_AGENTS*LIW-1:0]      s_commit_line;
  wire [N_AGENTS*2-1:0]        s_commit_st;
  wire [N_AGENTS*N_AGENTS-1:0] s_commit_sh;
  wire [N_AGENTS*AIW-1:0]      s_commit_ow;
  wire [N_AGENTS-1:0]          s_snp_v, s_snp_acc;
  wire [N_AGENTS*AIW-1:0]      s_snp_dst;
  wire [N_AGENTS*2-1:0]        s_snp_type;
  wire [N_AGENTS-1:0]          s_rsp_v;
  wire [N_AGENTS-1:0]          s_mem_v, s_mem_wr, s_mem_acc, s_mem_done;
  wire [N_AGENTS*LB-1:0]       s_mem_wdata;
  wire [N_AGENTS-1:0]          s_gnt_acc;
  wire [N_AGENTS*3-1:0]        s_gnt_type;
  wire [N_AGENTS-1:0]          s_ev_start, s_ev_inv, s_ev_dirty, s_ev_own, s_ev_stale;
  wire [N_AGENTS-1:0]          s_err_rsp, s_err_compl, s_err_own;
  wire [N_AGENTS*3-1:0]        s_ty;

  // routed response (one per cycle), see response arbiter below
  reg  [1:0]            rr_type;
  reg  [AIW-1:0]        rr_src;
  reg  [LB-1:0]         rr_data;
  reg                   rr_keep;
  reg  [N_AGENTS-1:0]   rr_slot_oh;
  reg                   rr_nomatch;

  wire [LB-1:0]  mem_rdata_w = mem_rsp_rdata;

  genvar gi;
  generate
    for (gi = 0; gi < N_AGENTS; gi = gi + 1) begin : g_slot
      wire [LIW-1:0] ln;
      wire [2:0]     stt;
      assign s_line[gi*LIW +: LIW] = ln;
      // directory entry read for this slot's line
      wire [ENTW-1:0] ent = dir_r[ln*ENTW +: ENTW];
      assign s_ent_st[gi*2 +: 2]               = ent[1:0];
      assign s_ent_sh[gi*N_AGENTS +: N_AGENTS] = ent[2 +: N_AGENTS];
      assign s_ent_ow[gi*AIW +: AIW]           = ent[2+N_AGENTS +: AIW];

      sf_coherence_transient_fsm #(
        .N_AGENTS(N_AGENTS), .SLOT_ID(gi), .DIR_LINES(DIR_LINES), .LINE_BYTES(LINE_BYTES)
      ) u_fsm (
        .clk(clk), .rst_n(rst_n),
        .req_valid(req_valid[gi]), .req_ready(req_ready[gi]),
        .req_type(req_type[gi*3 +: 3]), .req_line(req_line[gi*LIW +: LIW]), .req_data(req_data[gi*LB +: LB]),
        .wait_v(s_wait[gi]), .busy(s_busy[gi]), .line(ln), .start(s_start[gi]),
        .ent_st(s_ent_st[gi*2 +: 2]), .ent_sh(s_ent_sh[gi*N_AGENTS +: N_AGENTS]), .ent_ow(s_ent_ow[gi*AIW +: AIW]),
        .commit_v(s_commit_v[gi]), .commit_line(s_commit_line[gi*LIW +: LIW]),
        .commit_st(s_commit_st[gi*2 +: 2]), .commit_sh(s_commit_sh[gi*N_AGENTS +: N_AGENTS]),
        .commit_ow(s_commit_ow[gi*AIW +: AIW]),
        .snp_v(s_snp_v[gi]), .snp_dst(s_snp_dst[gi*AIW +: AIW]), .snp_type(s_snp_type[gi*2 +: 2]),
        .snp_acc(s_snp_acc[gi]),
        .rsp_v(s_rsp_v[gi]), .rsp_type(rr_type), .rsp_src(rr_src), .rsp_data(rr_data), .rsp_keep(rr_keep),
        .mem_v(s_mem_v[gi]), .mem_wr(s_mem_wr[gi]), .mem_wdata(s_mem_wdata[gi*LB +: LB]),
        .mem_acc(s_mem_acc[gi]), .mem_done(s_mem_done[gi]), .mem_rdata(mem_rdata_w),
        .gnt_v(gnt_valid[gi]), .gnt_type(gnt_type[gi*3 +: 3]), .gnt_data(gnt_data[gi*LB +: LB]),
        .gnt_acc(s_gnt_acc[gi]),
        .state(stt), .gather_kind(dbg_slot_gk[gi*2 +: 2]), .txn_type(s_ty[gi*3 +: 3]),
        .acks_waiting(dbg_slot_waiting[gi*N_AGENTS +: N_AGENTS]), .gnt_type_o(dbg_slot_gtype[gi*3 +: 3]),
        .ev_start(s_ev_start[gi]), .ev_inv(s_ev_inv[gi]), .ev_dirty(s_ev_dirty[gi]), .ev_own_xfer(s_ev_own[gi]),
        .ev_stale_put(s_ev_stale[gi]),
        .err_rsp(s_err_rsp[gi]), .err_compl(s_err_compl[gi]), .err_own(s_err_own[gi])
      );
      assign dbg_slot_state[gi*3 +: 3] = stt;
      assign dbg_slot_line[gi*LIW +: LIW] = ln;
      assign dbg_slot_type[gi*3 +: 3] = s_ty[gi*3 +: 3];
      assign dbg_slot_busy[gi] = s_busy[gi];
      assign dbg_slot_wait[gi] = s_wait[gi];
      assign dbg_slot_data[gi*LB +: LB] = gnt_data[gi*LB +: LB];
      assign gnt_line[gi*LIW +: LIW] = ln;
      assign s_gnt_acc[gi] = gnt_valid[gi] && gnt_ready[gi];
    end
  endgenerate

  // ------------------------------------------------------------------ line-conflict detection and start arbiter
  reg [N_AGENTS-1:0] blocked;
  integer bi, bj;
  always @* begin
    blocked = {N_AGENTS{1'b0}};
    for (bi = 0; bi < N_AGENTS; bi = bi + 1)
      for (bj = 0; bj < N_AGENTS; bj = bj + 1)
        if (bi != bj && s_busy[bj] && (s_line[bj*LIW +: LIW] == s_line[bi*LIW +: LIW]))
          blocked[bi] = 1'b1;
  end
  wire [N_AGENTS-1:0] elig = s_wait & ~blocked;

  reg [AIW-1:0]       rr_start;
  reg [N_AGENTS-1:0]  start_oh;
  reg [AIW-1:0]       start_idx;
  integer si, sidx;
  reg     sfound;
  always @* begin
    start_oh  = {N_AGENTS{1'b0}};
    start_idx = {AIW{1'b0}};
    sfound    = 1'b0;
    for (si = 1; si <= N_AGENTS; si = si + 1) begin
      sidx = (rr_start + si) % N_AGENTS;
      if (!sfound && elig[sidx]) begin
        start_oh[sidx] = 1'b1;
        start_idx      = sidx[AIW-1:0];
        sfound         = 1'b1;
      end
    end
  end
  assign s_start = start_oh;

  // ------------------------------------------------------------------ directory array commit (closing transactions)
  integer ci, cl;
  always @(posedge clk) begin
    if (!rst_n) begin
      dir_r    <= {DIR_LINES*ENTW{1'b0}};
      rr_start <= {AIW{1'b0}};
    end else begin
      if (|start_oh) rr_start <= start_idx;
      for (ci = 0; ci < N_AGENTS; ci = ci + 1)
        if (s_commit_v[ci])
          dir_r[s_commit_line[ci*LIW +: LIW]*ENTW +: ENTW] <=
            {s_commit_ow[ci*AIW +: AIW], s_commit_sh[ci*N_AGENTS +: N_AGENTS], s_commit_st[ci*2 +: 2]};
    end
  end

  // ------------------------------------------------------------------ memory-port arbiter (one outstanding op)
  reg [1:0]          mst;          // 0 idle, 1 request presented, 2 waiting for the response
  reg [AIW-1:0]      mown;
  reg [AIW-1:0]      rr_mem;
  reg [N_AGENTS-1:0] mem_pick_oh;
  reg [AIW-1:0]      mem_pick_idx;
  integer mi, midx;
  reg     mfound;
  always @* begin
    mem_pick_oh  = {N_AGENTS{1'b0}};
    mem_pick_idx = {AIW{1'b0}};
    mfound       = 1'b0;
    for (mi = 1; mi <= N_AGENTS; mi = mi + 1) begin
      midx = (rr_mem + mi) % N_AGENTS;
      if (!mfound && s_mem_v[midx]) begin
        mem_pick_oh[midx] = 1'b1;
        mem_pick_idx      = midx[AIW-1:0];
        mfound            = 1'b1;
      end
    end
  end
  assign mem_req_valid  = (mst == 2'd1);
  assign mem_req_wr     = s_mem_wr[mown];
  assign mem_req_line   = s_line[mown*LIW +: LIW];
  assign mem_req_wdata  = s_mem_wdata[mown*LB +: LB];
  assign mem_rsp_ready  = 1'b1;
  wire mem_acc_w  = (mst == 2'd1) && mem_req_ready;
  wire mem_done_w = (mst == 2'd2) && mem_rsp_valid;
  genvar mg;
  generate
    for (mg = 0; mg < N_AGENTS; mg = mg + 1) begin : g_memrt
      assign s_mem_acc[mg]  = mem_acc_w  && (mown == mg);
      assign s_mem_done[mg] = mem_done_w && (mown == mg);
      assign dbg_mem_wr_perf[mg] = mem_acc_w && (mown == mg) && s_mem_wr[mg];
    end
  endgenerate
  always @(posedge clk) begin
    if (!rst_n) begin
      mst    <= 2'd0;
      mown   <= {AIW{1'b0}};
      rr_mem <= {AIW{1'b0}};
    end else begin
      case (mst)
        2'd0: if (|mem_pick_oh) begin mst <= 2'd1; mown <= mem_pick_idx; rr_mem <= mem_pick_idx; end
        2'd1: if (mem_req_ready) mst <= 2'd2;
        2'd2: if (mem_rsp_valid) mst <= 2'd0;
        default: mst <= 2'd0;
      endcase
    end
  end

  // ------------------------------------------------------------------ snoop arbiters (per destination agent)
  reg [N_AGENTS-1:0]  snp_sel_v;
  reg [N_AGENTS*AIW-1:0] snp_sel_i;
  reg [N_AGENTS*AIW-1:0] rr_snp;
  integer dj, dk, didx;
  reg     dfound;
  always @* begin
    snp_sel_v = {N_AGENTS{1'b0}};
    snp_sel_i = {N_AGENTS*AIW{1'b0}};
    for (dj = 0; dj < N_AGENTS; dj = dj + 1) begin
      dfound = 1'b0;
      for (dk = 1; dk <= N_AGENTS; dk = dk + 1) begin
        didx = (rr_snp[dj*AIW +: AIW] + dk) % N_AGENTS;
        if (!dfound && s_snp_v[didx] && (s_snp_dst[didx*AIW +: AIW] == dj)) begin
          snp_sel_v[dj]                = 1'b1;
          snp_sel_i[dj*AIW +: AIW]     = didx[AIW-1:0];
          dfound                       = 1'b1;
        end
      end
    end
  end
  genvar sg;
  generate
    for (sg = 0; sg < N_AGENTS; sg = sg + 1) begin : g_snp
      assign snp_valid[sg]            = snp_sel_v[sg];
      assign snp_type[sg*2 +: 2]      = s_snp_type[snp_sel_i[sg*AIW +: AIW]*2 +: 2];
      assign snp_line[sg*LIW +: LIW]  = s_line[snp_sel_i[sg*AIW +: AIW]*LIW +: LIW];
      assign s_snp_acc[sg]            = s_snp_v[sg] && snp_ready[s_snp_dst[sg*AIW +: AIW]] &&
                                        snp_sel_v[s_snp_dst[sg*AIW +: AIW]] &&
                                        (snp_sel_i[s_snp_dst[sg*AIW +: AIW]*AIW +: AIW] == sg);
    end
  endgenerate
  integer rj;
  always @(posedge clk) begin
    if (!rst_n) rr_snp <= {N_AGENTS*AIW{1'b0}};
    else for (rj = 0; rj < N_AGENTS; rj = rj + 1)
      if (snp_sel_v[rj] && snp_ready[rj]) rr_snp[rj*AIW +: AIW] <= snp_sel_i[rj*AIW +: AIW];
  end

  // ------------------------------------------------------------------ response arbiter and routing
  reg [AIW-1:0]      rr_rsp;
  reg                rsel_v;
  reg [AIW-1:0]      rsel_i;
  integer ri, ridx;
  reg     rfound;
  always @* begin
    rsel_v = 1'b0;
    rsel_i = {AIW{1'b0}};
    rfound = 1'b0;
    for (ri = 1; ri <= N_AGENTS; ri = ri + 1) begin
      ridx = (rr_rsp + ri) % N_AGENTS;
      if (!rfound && rsp_valid[ridx]) begin
        rsel_v = 1'b1;
        rsel_i = ridx[AIW-1:0];
        rfound = 1'b1;
      end
    end
  end
  genvar rg;
  generate
    for (rg = 0; rg < N_AGENTS; rg = rg + 1) begin : g_rspr
      assign rsp_ready[rg] = rsel_v && (rsel_i == rg);
    end
  endgenerate
  integer rk;
  reg [LIW-1:0] rline;
  reg           rfound_slot;
  always @* begin
    rr_type    = rsp_type[rsel_i*2 +: 2];
    rr_src     = rsel_i;
    rr_data    = rsp_data[rsel_i*LB +: LB];
    rr_keep    = rsp_keep[rsel_i];
    rline      = rsp_line[rsel_i*LIW +: LIW];
    rr_slot_oh = {N_AGENTS{1'b0}};
    rfound_slot = 1'b0;
    if (rsel_v) begin
      if (rr_type == sf_coherence_pkg::RS_COMPLETE) begin
        rr_slot_oh[rsel_i] = 1'b1;
        rfound_slot = 1'b1;
      end else begin
        for (rk = 0; rk < N_AGENTS; rk = rk + 1)
          if (!rfound_slot && s_busy[rk] && (dbg_slot_state[rk*3 +: 3] == sf_coherence_pkg::TS_GATHER) &&
              (s_line[rk*LIW +: LIW] == rline)) begin
            rr_slot_oh[rk] = 1'b1;
            rfound_slot    = 1'b1;
          end
      end
    end
    rr_nomatch = rsel_v && !rfound_slot;
  end
  assign s_rsp_v = rr_slot_oh;
  always @(posedge clk) begin
    if (!rst_n) rr_rsp <= {AIW{1'b0}};
    else if (rsel_v) rr_rsp <= rsel_i;
  end

  // ------------------------------------------------------------------ sticky error bits
  reg [DE_W_L-1:0] err_r;
  assign dbg_err = err_r;
  always @(posedge clk) begin
    if (!rst_n) err_r <= {DE_W_L{1'b0}};
    else begin
      if (rr_nomatch)                  err_r[sf_coherence_pkg::DE_RSP_NOMATCH]  <= 1'b1;
      if (|s_err_rsp)                  err_r[sf_coherence_pkg::DE_RSP_UNEXPECT] <= 1'b1;
      if (|s_err_own)                  err_r[sf_coherence_pkg::DE_REQ_FROM_OWN] <= 1'b1;
      if (|s_err_compl)                err_r[sf_coherence_pkg::DE_COMPL_UNEXP]  <= 1'b1;
      if (mem_rsp_valid && mst != 2'd2) err_r[sf_coherence_pkg::DE_MEM_PROTO]   <= 1'b1;
    end
  end

  // ------------------------------------------------------------------ performance counters
  reg [31:0] c_gets, c_getm, c_upg, c_puts, c_putm, c_inv, c_own, c_dirty, c_look, c_scf, c_sga, c_stale;
  reg [31:0] c_req_b, c_rsp_b, c_snp_b, c_gnt_b, c_mrd_b, c_mwr_b;
  integer pq, pq2;
  reg [N_AGENTS-1:0] seen_blk;
  reg [31:0] n_retry;
  always @* begin
    c_gets = 0; c_getm = 0; c_upg = 0; c_puts = 0; c_putm = 0; c_inv = 0; c_own = 0; c_dirty = 0;
    c_look = 0; c_scf = 0; c_sga = 0; c_stale = 0; c_req_b = 0; c_rsp_b = 0; c_snp_b = 0; c_gnt_b = 0;
    c_mrd_b = 0; c_mwr_b = 0; n_retry = 0;
    for (pq = 0; pq < N_AGENTS; pq = pq + 1) begin
      if (s_ev_start[pq]) begin
        c_look = c_look + 1;
        if (s_ty[pq*3 +: 3] == sf_coherence_pkg::RQ_GETS) c_gets = c_gets + 1;
        if (s_ty[pq*3 +: 3] == sf_coherence_pkg::RQ_GETM) c_getm = c_getm + 1;
        if (s_ty[pq*3 +: 3] == sf_coherence_pkg::RQ_UPG)  c_upg  = c_upg  + 1;
        if (s_ty[pq*3 +: 3] == sf_coherence_pkg::RQ_PUTS) c_puts = c_puts + 1;
        if (s_ty[pq*3 +: 3] == sf_coherence_pkg::RQ_PUTM) c_putm = c_putm + 1;
      end
      if (s_ev_inv[pq])   c_inv   = c_inv   + 1;
      if (s_ev_own[pq])   c_own   = c_own   + 1;
      if (s_ev_dirty[pq]) c_dirty = c_dirty + 1;
      if (s_ev_stale[pq]) c_stale = c_stale + 1;
      if (s_wait[pq] && blocked[pq]) c_scf = c_scf + 1;
      if (s_wait[pq] && blocked[pq] && !seen_blk[pq]) n_retry = n_retry + 1;
      if (dbg_slot_state[pq*3 +: 3] == sf_coherence_pkg::TS_GATHER) c_sga = c_sga + 1;
      if (req_valid[pq] && req_ready[pq])
        c_req_b = c_req_b + sf_coherence_pkg::HDR_BYTES +
                  ((req_type[pq*3 +: 3] == sf_coherence_pkg::RQ_PUTM) ? LINE_BYTES : 0);
      if (snp_valid[pq] && snp_ready[pq]) c_snp_b = c_snp_b + sf_coherence_pkg::HDR_BYTES;
      if (gnt_valid[pq] && gnt_ready[pq])
        c_gnt_b = c_gnt_b + sf_coherence_pkg::HDR_BYTES +
                  ((gnt_type[pq*3 +: 3] == sf_coherence_pkg::GN_DATA_S || gnt_type[pq*3 +: 3] == sf_coherence_pkg::GN_DATA_M) ? LINE_BYTES : 0);
      if (rsp_valid[pq] && rsp_ready[pq])
        c_rsp_b = c_rsp_b + sf_coherence_pkg::HDR_BYTES +
                  ((rsp_type[pq*2 +: 2] == sf_coherence_pkg::RS_DATA) ? LINE_BYTES : 0);
    end
    if (mem_acc_w && !s_mem_wr[mown]) c_mrd_b = LINE_BYTES;
    if (mem_acc_w &&  s_mem_wr[mown]) c_mwr_b = LINE_BYTES;
  end
  always @(posedge clk) begin
    if (!rst_n) seen_blk <= {N_AGENTS{1'b0}};
    else for (pq2 = 0; pq2 < N_AGENTS; pq2 = pq2 + 1) begin
      if (s_wait[pq2] && blocked[pq2]) seen_blk[pq2] <= 1'b1;
      else if (s_start[pq2])           seen_blk[pq2] <= 1'b0;
    end
  end

  reg [PD_N_L*32-1:0] perf_r;
  assign perf = perf_r;
  wire [31:0] c_busy = (|s_busy) ? 32'd1 : 32'd0;
  function [31:0] sat_add(input [31:0] a, input [31:0] b);
    sat_add = (((({1'b0, a} + {1'b0, b}) >> 32) & 33'd1) != 33'd0) ? 32'hFFFF_FFFF : (a + b);
  endfunction
  always @(posedge clk) begin
    if (!rst_n) perf_r <= {PD_N_L*32{1'b0}};
    else begin
      perf_r[sf_coherence_pkg::PD_GETS*32 +: 32]       <= sat_add(perf_r[sf_coherence_pkg::PD_GETS*32 +: 32], c_gets);
      perf_r[sf_coherence_pkg::PD_GETM*32 +: 32]       <= sat_add(perf_r[sf_coherence_pkg::PD_GETM*32 +: 32], c_getm);
      perf_r[sf_coherence_pkg::PD_UPG*32 +: 32]        <= sat_add(perf_r[sf_coherence_pkg::PD_UPG*32 +: 32], c_upg);
      perf_r[sf_coherence_pkg::PD_PUTS*32 +: 32]       <= sat_add(perf_r[sf_coherence_pkg::PD_PUTS*32 +: 32], c_puts);
      perf_r[sf_coherence_pkg::PD_PUTM*32 +: 32]       <= sat_add(perf_r[sf_coherence_pkg::PD_PUTM*32 +: 32], c_putm);
      perf_r[sf_coherence_pkg::PD_INV*32 +: 32]        <= sat_add(perf_r[sf_coherence_pkg::PD_INV*32 +: 32], c_inv);
      perf_r[sf_coherence_pkg::PD_OWN_XFER*32 +: 32]   <= sat_add(perf_r[sf_coherence_pkg::PD_OWN_XFER*32 +: 32], c_own);
      perf_r[sf_coherence_pkg::PD_DIRTY_INT*32 +: 32]  <= sat_add(perf_r[sf_coherence_pkg::PD_DIRTY_INT*32 +: 32], c_dirty);
      perf_r[sf_coherence_pkg::PD_LOOKUPS*32 +: 32]    <= sat_add(perf_r[sf_coherence_pkg::PD_LOOKUPS*32 +: 32], c_look);
      perf_r[sf_coherence_pkg::PD_STALL_CONF*32 +: 32] <= sat_add(perf_r[sf_coherence_pkg::PD_STALL_CONF*32 +: 32], c_scf);
      perf_r[sf_coherence_pkg::PD_STALL_GATH*32 +: 32] <= sat_add(perf_r[sf_coherence_pkg::PD_STALL_GATH*32 +: 32], c_sga);
      perf_r[sf_coherence_pkg::PD_BUSY_CYC*32 +: 32]   <= sat_add(perf_r[sf_coherence_pkg::PD_BUSY_CYC*32 +: 32], c_busy);
      perf_r[sf_coherence_pkg::PD_RETRIES*32 +: 32]    <= sat_add(perf_r[sf_coherence_pkg::PD_RETRIES*32 +: 32], n_retry);
      perf_r[sf_coherence_pkg::PD_BYTES_REQ*32 +: 32]  <= sat_add(perf_r[sf_coherence_pkg::PD_BYTES_REQ*32 +: 32], c_req_b);
      perf_r[sf_coherence_pkg::PD_BYTES_RSP*32 +: 32]  <= sat_add(perf_r[sf_coherence_pkg::PD_BYTES_RSP*32 +: 32], c_rsp_b);
      perf_r[sf_coherence_pkg::PD_BYTES_SNP*32 +: 32]  <= sat_add(perf_r[sf_coherence_pkg::PD_BYTES_SNP*32 +: 32], c_snp_b);
      perf_r[sf_coherence_pkg::PD_BYTES_GNT*32 +: 32]  <= sat_add(perf_r[sf_coherence_pkg::PD_BYTES_GNT*32 +: 32], c_gnt_b);
      perf_r[sf_coherence_pkg::PD_MEM_RD_B*32 +: 32]   <= sat_add(perf_r[sf_coherence_pkg::PD_MEM_RD_B*32 +: 32], c_mrd_b);
      perf_r[sf_coherence_pkg::PD_MEM_WR_B*32 +: 32]   <= sat_add(perf_r[sf_coherence_pkg::PD_MEM_WR_B*32 +: 32], c_mwr_b);
      perf_r[sf_coherence_pkg::PD_STALE_PUT*32 +: 32]  <= sat_add(perf_r[sf_coherence_pkg::PD_STALE_PUT*32 +: 32], c_stale);
    end
  end

endmodule

`default_nettype wire
