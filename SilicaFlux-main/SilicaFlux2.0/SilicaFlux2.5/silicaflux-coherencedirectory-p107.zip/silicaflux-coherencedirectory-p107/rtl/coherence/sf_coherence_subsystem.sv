// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: sf_coherence_subsystem
//
// Integration of N coherent caching agents (sf_coherence_agent_adapter) with ONE directory controller
// (sf_coherence_directory) and the shared-memory line port.  Initial configuration: N_AGENTS = 2, 64-byte lines.
//
//   CPU0 --> agent0 --\                          /--> memory / LLC line port (64 B)
//                      +-- 4 channels -- directory
//   CPU1 --> agent1 --/                          \--> (management counters)
//
// Test hooks: `chan_allow_*` gate the valid AND ready of one coherence channel per agent for one cycle (a
// stall).  Tie to all-ones in a product.  Verification and formal drive them with random / free values to inject
// back-pressure on every channel without touching the protocol logic.
//
// The non-coherent gateway (sf_coherence_nc_gateway) is instantiated by the SoC next to this block, NOT inside it:
// non-coherent masters do not participate in the protocol.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_coherence_subsystem #(
  parameter int N_AGENTS   = 2,
  parameter int DIR_LINES  = 16,
  parameter int CACHE_SETS = 4,
  parameter int LINE_BYTES = 64,
  parameter int ADDR_W     = 32,
  parameter logic [31:0] COH_BASE = 32'h8000_0000,
  localparam int LIW  = (DIR_LINES > 1) ? $clog2(DIR_LINES) : 1,
  localparam int LB   = LINE_BYTES * 8,
  localparam int AIW  = (N_AGENTS > 1) ? $clog2(N_AGENTS) : 1,
  localparam int ENTW = 2 + N_AGENTS + AIW,
  localparam int WPL  = LINE_BYTES / 4,
  localparam int WIW  = (WPL > 1) ? $clog2(WPL) : 1
) (
  input  wire                          clk,
  input  wire                          rst_n,
  // ---- CPU ports (one per agent)
  input  wire [N_AGENTS-1:0]           cpu_req_valid,
  output wire [N_AGENTS-1:0]           cpu_req_ready,
  input  wire [N_AGENTS*3-1:0]         cpu_op,
  input  wire [N_AGENTS*ADDR_W-1:0]    cpu_addr,
  input  wire [N_AGENTS*32-1:0]        cpu_wdata,
  input  wire [N_AGENTS*4-1:0]         cpu_wstrb,
  output wire [N_AGENTS-1:0]           cpu_rsp_valid,
  input  wire [N_AGENTS-1:0]           cpu_rsp_ready,
  output wire [N_AGENTS*32-1:0]        cpu_rdata,
  output wire [N_AGENTS-1:0]           cpu_rsp_err,
  // ---- shared memory / LLC line port
  output wire                          mem_req_valid,
  input  wire                          mem_req_ready,
  output wire                          mem_req_wr,
  output wire [LIW-1:0]                mem_req_line,
  output wire [LB-1:0]                 mem_req_wdata,
  input  wire                          mem_rsp_valid,
  output wire                          mem_rsp_ready,
  input  wire [LB-1:0]                 mem_rsp_rdata,
  // ---- test hooks (tie to ones)
  input  wire [N_AGENTS-1:0]           chan_allow_req,
  input  wire [N_AGENTS-1:0]           chan_allow_rsp,
  input  wire [N_AGENTS-1:0]           chan_allow_snp,
  input  wire [N_AGENTS-1:0]           chan_allow_gnt,
  // ---- observability
  output wire [DIR_LINES*ENTW-1:0]     dbg_dir,
  output wire [N_AGENTS*3-1:0]         dbg_slot_state,
  output wire [N_AGENTS*LIW-1:0]       dbg_slot_line,
  output wire [N_AGENTS*3-1:0]         dbg_slot_type,
  output wire [N_AGENTS-1:0]           dbg_slot_busy,
  output wire [N_AGENTS*N_AGENTS-1:0]  dbg_slot_waiting,
  output wire [N_AGENTS*3-1:0]         dbg_slot_gtype,
  output wire [N_AGENTS*2-1:0]         dbg_slot_gk,
  output wire [N_AGENTS*LB-1:0]        dbg_slot_data,
  output wire [N_AGENTS-1:0]           dbg_slot_wait,
  output wire [N_AGENTS-1:0]           dbg_mem_wr_perf,
  output wire [sf_coherence_pkg::DE_W-1:0]    dbg_dir_err,
  output wire [N_AGENTS*sf_coherence_pkg::AE_W-1:0] dbg_agent_err,
  output wire [sf_coherence_pkg::PD_N*32-1:0] perf_dir,
  output wire [N_AGENTS*sf_coherence_pkg::PA_N*32-1:0] perf_agent,
  // per-agent cache arrays and pending records
  output wire [N_AGENTS*2-1:0]         dbg_a_st,
  output wire [N_AGENTS*CACHE_SETS*2-1:0]   dbg_cs_all,
  output wire [N_AGENTS*CACHE_SETS*LIW-1:0] dbg_tag_all,
  output wire [N_AGENTS*CACHE_SETS*LB-1:0]  dbg_data_all,
  output wire [N_AGENTS*3-1:0]         dbg_p_st,
  output wire [N_AGENTS*LIW-1:0]       dbg_p_line,
  output wire [N_AGENTS-1:0]           dbg_p_lost,
  output wire [N_AGENTS*LB-1:0]        dbg_p_data,
  // performed-operation events (golden model)
  output wire [N_AGENTS-1:0]           ev_perf_v,
  output wire [N_AGENTS-1:0]           ev_perf_wr,
  output wire [N_AGENTS*LIW-1:0]       ev_perf_line,
  output wire [N_AGENTS*WIW-1:0]       ev_perf_word,
  output wire [N_AGENTS*32-1:0]        ev_perf_rdata,
  output wire [N_AGENTS*LB-1:0]        ev_perf_newline,
  output wire [N_AGENTS*LB-1:0]        ev_perf_oldline,
  // channel traffic (for monitors): post-gating handshakes
  output wire [N_AGENTS-1:0]           mon_req_hs,
  output wire [N_AGENTS-1:0]           mon_rsp_hs,
  output wire [N_AGENTS-1:0]           mon_snp_hs,
  output wire [N_AGENTS-1:0]           mon_gnt_hs,
  // raw per-agent channel state (valid / ready after gating), for counterexample analysis
  output wire [6*N_AGENTS-1:0]         dbg_chan
);
  // ------------------------------------------------------------------ raw channel buses
  wire [N_AGENTS-1:0]      a_rq_valid, a_rq_ready, a_rs_valid, a_rs_ready, a_sn_valid, a_sn_ready, a_gn_valid, a_gn_ready;
  wire [N_AGENTS*3-1:0]    a_rq_type;
  wire [N_AGENTS*LIW-1:0]  a_rq_line;
  wire [N_AGENTS*LB-1:0]   a_rq_data;
  wire [N_AGENTS*2-1:0]    a_rs_type;
  wire [N_AGENTS*LIW-1:0]  a_rs_line;
  wire [N_AGENTS*LB-1:0]   a_rs_data;
  wire [N_AGENTS-1:0]      a_rs_keep;
  wire [N_AGENTS*2-1:0]    a_sn_type;
  wire [N_AGENTS*LIW-1:0]  a_sn_line;
  wire [N_AGENTS*3-1:0]    a_gn_type;
  wire [N_AGENTS*LIW-1:0]  a_gn_line;
  wire [N_AGENTS*LB-1:0]   a_gn_data;

  wire [N_AGENTS-1:0]      d_req_ready, d_rsp_ready, d_snp_valid, d_gnt_valid;
  wire [N_AGENTS*2-1:0]    d_snp_type;
  wire [N_AGENTS*LIW-1:0]  d_snp_line;
  wire [N_AGENTS*3-1:0]    d_gnt_type;
  wire [N_AGENTS*LIW-1:0]  d_gnt_line;
  wire [N_AGENTS*LB-1:0]   d_gnt_data;

  // gating (stall injection): a transfer happens only in cycles where `allow` is 1
  wire [N_AGENTS-1:0] req_v_g = a_rq_valid & chan_allow_req;
  wire [N_AGENTS-1:0] rsp_v_g = a_rs_valid & chan_allow_rsp;
  wire [N_AGENTS-1:0] snp_v_g = d_snp_valid & chan_allow_snp;
  wire [N_AGENTS-1:0] gnt_v_g = d_gnt_valid & chan_allow_gnt;
  assign a_rq_ready = d_req_ready & chan_allow_req;
  assign a_rs_ready = d_rsp_ready & chan_allow_rsp;
  wire [N_AGENTS-1:0] snp_r_g = a_sn_ready & chan_allow_snp;
  wire [N_AGENTS-1:0] gnt_r_g = a_gn_ready & chan_allow_gnt;
  assign a_sn_valid = snp_v_g;
  assign a_gn_valid = gnt_v_g;

  assign dbg_chan = {a_rq_valid, a_rs_valid, a_sn_valid, a_sn_ready, a_gn_valid, a_gn_ready};
  assign mon_req_hs = req_v_g & d_req_ready;
  assign mon_rsp_hs = rsp_v_g & d_rsp_ready;
  assign mon_snp_hs = snp_v_g & a_sn_ready;
  assign mon_gnt_hs = gnt_v_g & a_gn_ready;

  assign a_sn_type = d_snp_type;  assign a_sn_line = d_snp_line;
  assign a_gn_type = d_gnt_type;  assign a_gn_line = d_gnt_line;  assign a_gn_data = d_gnt_data;

  sf_coherence_directory #(.N_AGENTS(N_AGENTS), .DIR_LINES(DIR_LINES), .LINE_BYTES(LINE_BYTES)) u_dir (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_v_g), .req_ready(d_req_ready), .req_type(a_rq_type), .req_line(a_rq_line), .req_data(a_rq_data),
    .rsp_valid(rsp_v_g), .rsp_ready(d_rsp_ready), .rsp_type(a_rs_type), .rsp_line(a_rs_line), .rsp_data(a_rs_data),
    .rsp_keep(a_rs_keep),
    .snp_valid(d_snp_valid), .snp_ready(snp_r_g), .snp_type(d_snp_type), .snp_line(d_snp_line),
    .gnt_valid(d_gnt_valid), .gnt_ready(gnt_r_g), .gnt_type(d_gnt_type), .gnt_line(d_gnt_line), .gnt_data(d_gnt_data),
    .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready), .mem_req_wr(mem_req_wr),
    .mem_req_line(mem_req_line), .mem_req_wdata(mem_req_wdata),
    .mem_rsp_valid(mem_rsp_valid), .mem_rsp_ready(mem_rsp_ready), .mem_rsp_rdata(mem_rsp_rdata),
    .dbg_dir(dbg_dir), .dbg_slot_state(dbg_slot_state), .dbg_slot_line(dbg_slot_line), .dbg_slot_type(dbg_slot_type),
    .dbg_slot_busy(dbg_slot_busy), .dbg_slot_waiting(dbg_slot_waiting), .dbg_slot_gtype(dbg_slot_gtype),
    .dbg_slot_gk(dbg_slot_gk), .dbg_slot_data(dbg_slot_data), .dbg_slot_wait(dbg_slot_wait),
    .dbg_mem_wr_perf(dbg_mem_wr_perf), .dbg_err(dbg_dir_err), .perf(perf_dir)
  );

  genvar gi;
  generate
    for (gi = 0; gi < N_AGENTS; gi = gi + 1) begin : g_agent
      sf_coherence_agent_adapter #(
        .AGENT_ID(gi), .N_AGENTS(N_AGENTS), .DIR_LINES(DIR_LINES), .CACHE_SETS(CACHE_SETS),
        .LINE_BYTES(LINE_BYTES), .ADDR_W(ADDR_W), .COH_BASE(COH_BASE)
      ) u_agent (
        .clk(clk), .rst_n(rst_n),
        .cpu_req_valid(cpu_req_valid[gi]), .cpu_req_ready(cpu_req_ready[gi]), .cpu_op(cpu_op[gi*3 +: 3]),
        .cpu_addr(cpu_addr[gi*ADDR_W +: ADDR_W]), .cpu_wdata(cpu_wdata[gi*32 +: 32]), .cpu_wstrb(cpu_wstrb[gi*4 +: 4]),
        .cpu_rsp_valid(cpu_rsp_valid[gi]), .cpu_rsp_ready(cpu_rsp_ready[gi]), .cpu_rdata(cpu_rdata[gi*32 +: 32]),
        .cpu_rsp_err(cpu_rsp_err[gi]),
        .rq_valid(a_rq_valid[gi]), .rq_ready(a_rq_ready[gi]), .rq_type(a_rq_type[gi*3 +: 3]),
        .rq_line(a_rq_line[gi*LIW +: LIW]), .rq_data(a_rq_data[gi*LB +: LB]),
        .rs_valid(a_rs_valid[gi]), .rs_ready(a_rs_ready[gi]), .rs_type(a_rs_type[gi*2 +: 2]),
        .rs_line(a_rs_line[gi*LIW +: LIW]), .rs_data(a_rs_data[gi*LB +: LB]), .rs_keep(a_rs_keep[gi]),
        .sn_valid(a_sn_valid[gi]), .sn_ready(a_sn_ready[gi]), .sn_type(a_sn_type[gi*2 +: 2]), .sn_line(a_sn_line[gi*LIW +: LIW]),
        .gn_valid(a_gn_valid[gi]), .gn_ready(a_gn_ready[gi]), .gn_type(a_gn_type[gi*3 +: 3]),
        .gn_line(a_gn_line[gi*LIW +: LIW]), .gn_data(a_gn_data[gi*LB +: LB]),
        .dbg_cs(dbg_cs_all[gi*CACHE_SETS*2 +: CACHE_SETS*2]), .dbg_tag(dbg_tag_all[gi*CACHE_SETS*LIW +: CACHE_SETS*LIW]),
        .dbg_data(dbg_data_all[gi*CACHE_SETS*LB +: CACHE_SETS*LB]),
        .dbg_p_st(dbg_p_st[gi*3 +: 3]), .dbg_p_line(dbg_p_line[gi*LIW +: LIW]), .dbg_p_lost(dbg_p_lost[gi]),
        .dbg_p_data(dbg_p_data[gi*LB +: LB]), .dbg_a_st(dbg_a_st[gi*2 +: 2]),
        .ev_perf_v(ev_perf_v[gi]), .ev_perf_wr(ev_perf_wr[gi]), .ev_perf_line(ev_perf_line[gi*LIW +: LIW]),
        .ev_perf_word(ev_perf_word[gi*WIW +: WIW]), .ev_perf_rdata(ev_perf_rdata[gi*32 +: 32]),
        .ev_perf_newline(ev_perf_newline[gi*LB +: LB]), .ev_perf_oldline(ev_perf_oldline[gi*LB +: LB]),
        .dbg_err(dbg_agent_err[gi*sf_coherence_pkg::AE_W +: sf_coherence_pkg::AE_W]),
        .perf(perf_agent[gi*sf_coherence_pkg::PA_N*32 +: sf_coherence_pkg::PA_N*32])
      );
    end
  endgenerate
endmodule

`default_nettype wire
