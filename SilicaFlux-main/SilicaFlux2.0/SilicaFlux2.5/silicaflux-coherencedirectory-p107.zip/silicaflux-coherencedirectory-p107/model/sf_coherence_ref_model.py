#!/usr/bin/env python3
"""
SilicaFlux Project 107 :: CoherenceDirectory -- protocol-level reference model (MSI, directory, blocking per line)

This file is the EXECUTABLE SPECIFICATION of the protocol that sf_coherence_directory.sv /
sf_coherence_agent_adapter.sv implement (docs/01_PROTOCOL_SPEC.md is its prose form).  It does two jobs:

  1. It is the memory-coherence reference model: a golden per-line "latest value" (version number) that every
     load must return (no stale data), and the architectural rules (SWMR, exact directory, ...).
  2. It is an explicit-state model checker: `python3 sf_coherence_ref_model.py` enumerates EVERY reachable state
     of the protocol under EVERY interleaving of CPU operations, message deliveries (messages are an unordered
     multiset, i.e. any channel order and any delay) and directory steps, and checks the invariants in each state.
     Interleaving is at message/handler granularity -- the same granularity as the RTL's FSM steps.

What the model abstracts (stated, not hidden):
  * data is a version number (0 = initial memory content); the golden model is per line;
  * channels are unordered, unbounded multisets (a SUPERSET of the RTL's one-entry in-order registers);
  * memory read / write are atomic steps (same-line transactions are serialised by the directory, so this
    does not hide a same-line race; different-line memory operations do not interact);
  * time and ready/valid back-pressure are not modelled (that is the RTL formal / simulation job).

Exit status 0 = no violation in the explored space.
"""
import sys, itertools, time, argparse
from collections import deque

# ---- encodings (mirror sf_coherence_pkg.sv) --------------------------------------------------------------------
I, S, M = 0, 1, 2
UNC, SHR, MOD = 0, 1, 2
GETS, GETM, UPG, PUTS, PUTM = 'GETS', 'GETM', 'UPG', 'PUTS', 'PUTM'
INVACK, DATA, COMPLETE = 'INVACK', 'DATA', 'COMPLETE'
INV, FWD_S, FWD_M = 'INV', 'FWD_S', 'FWD_M'
GN_DATA_S, GN_DATA_M, GN_UPG, GN_PUTACK = 'DATA_S', 'DATA_M', 'UPG', 'PUTACK'
LOAD, STORE, FLUSH = 'LOAD', 'STORE', 'FLUSH'
# agent main FSM
A_IDLE, A_EVAL, A_WAIT, A_RESP = 0, 1, 2, 3
# pending record kinds
P_IS, P_IM, P_SM, P_MI, P_SI = 'IS', 'IM', 'SM', 'MI', 'SI'
# directory slot states
T_WAIT, T_GATHER, T_MEMWR, T_GRANT, T_COMPL = 'WAIT', 'GATHER', 'MEMWR', 'GRANT', 'COMPL'


class Violation(Exception):
    pass


# Bug-injection switches (sensitivity check: every mutant must be caught by the checker).  Selected with --mutant.
MUT = set()
MUTANTS = {
    'grant_before_acks': 'directory grants ownership without waiting for invalidation acknowledgements',
    'stale_putm_writes': 'a stale PutM (non-owner) still overwrites memory',
    'no_inv': 'GetM/Upg from a shared line sends no invalidations',
    'no_mem_update': 'dirty data from the owner is not written to memory on a shared intervention',
    'ignore_keep': 'directory always keeps the old owner as a sharer (ignores the keep bit)',
    'no_fwd_wait': 'directory does not wait for the owner data response before granting',
}


class Cfg:
    def __init__(self, n=2, lines=2, cap=1, ops=3, ops_kinds=(LOAD, STORE, FLUSH), max_states=10_000_000):
        self.n, self.lines, self.cap, self.ops = n, lines, cap, ops
        self.kinds = ops_kinds
        self.max_states = max_states


# ---- state layout -----------------------------------------------------------------------------------------------
# state = (agents, dirents, mem, slots, msgs, gold, ver)
#  agents[a] = (a_st, op, cache, pend, ops_left)
#       op    = None | (kind, line)
#       cache = tuple sorted of (line, st, data)
#       pend  = None | (kind, line, lost, data)
#  dirents[l] = (st, sh_mask, owner)
#  mem[l]     = version
#  slots[i]   = None | (tstate, type, line, dbuf, keep, to_send, kind, waiting, need_mem, wr_after, gtype, ent)
#  msgs       = sorted tuple of messages
#  gold[l]    = version, ver = global version counter


def set_t(t, i, v):
    return t[:i] + (v,) + t[i + 1:]


def msgs_add(msgs, m):
    return tuple(sorted(msgs + (m,)))


def msgs_del(msgs, m):
    l = list(msgs)
    l.remove(m)
    return tuple(l)


def has_copy(agent, line, msgs=(), aid=None):
    """(has_M, has_S) of an agent for a line, counting an eviction record as the copy it still logically holds
    until the directory's PUTACK for it has been issued (the directory commits the eviction when it sends PUTACK)."""
    a_st, op, cache, pend, left = agent
    hm = hs = False
    for (l, st, d) in cache:
        if l == line:
            hm |= st == M
            hs |= st == S
    if pend is not None:
        k, pl, lost, pd = pend
        acked = aid is not None and any(m[0] == 'GNT' and m[1] == aid and m[2] == GN_PUTACK and m[3] == line for m in msgs)
        if pl == line and not lost and not acked:
            if k == P_MI:
                hm = True
            if k == P_SI:
                hs = True
    return hm, hs


def initial(cfg):
    ag = tuple((A_IDLE, None, (), None, cfg.ops) for _ in range(cfg.n))
    de = tuple((UNC, 0, 0) for _ in range(cfg.lines))
    return (ag, de, (0,) * cfg.lines, (None,) * cfg.n, (), (0,) * cfg.lines, 0)


def active(slot):
    return slot is not None and slot[0] != T_WAIT


# ---- successor generation ---------------------------------------------------------------------------------------
def successors(cfg, s):
    ag, de, mem, slots, msgs, gold, ver = s
    n = cfg.n
    out = []

    def emit(label, **kw):
        out.append((label, (kw.get('ag', ag), kw.get('de', de), kw.get('mem', mem), kw.get('slots', slots),
                            kw.get('msgs', msgs), kw.get('gold', gold), kw.get('ver', ver))))

    # ===================== agents ==========================================================================
    for a in range(n):
        a_st, op, cache, pend, left = ag[a]

        # --- CPU issues a new operation
        if a_st == A_IDLE and left > 0:
            for k in cfg.kinds:
                for l in range(cfg.lines):
                    emit(f'cpu{a}:{k}{l}', ag=set_t(ag, a, (A_EVAL, (k, l), cache, pend, left - 1)))

        # --- response taken
        if a_st == A_RESP:
            emit(f'cpu{a}:resp', ag=set_t(ag, a, (A_IDLE, None, cache, pend, left)))

        # --- main FSM evaluate
        if a_st == A_EVAL:
            k, l = op
            ent = next((e for e in cache if e[0] == l), None)
            others = tuple(e for e in cache if e[0] != l)

            def evict(entry, new_cache):
                el, est, ed = entry
                if est == M:
                    p = (P_MI, el, False, ed)
                    m = ('REQ', a, PUTM, el, ed)
                else:
                    p = (P_SI, el, False, None)
                    m = ('REQ', a, PUTS, el, None)
                return (A_WAIT, op, new_cache, p, left), m

            if k == LOAD:
                if ent is not None:
                    if ent[2] != gold[l]:
                        raise Violation(f'STALE LOAD agent{a} line{l}: got {ent[2]} golden {gold[l]}')
                    emit(f'a{a}:load-hit', ag=set_t(ag, a, (A_RESP, op, cache, pend, left)))
                elif len(cache) >= cfg.cap:
                    v = cache[0]
                    na, m = evict(v, tuple(e for e in cache if e is not v))
                    emit(f'a{a}:load-evict', ag=set_t(ag, a, na), msgs=msgs_add(msgs, m))
                else:
                    emit(f'a{a}:GETS', ag=set_t(ag, a, (A_WAIT, op, cache, (P_IS, l, False, None), left)),
                         msgs=msgs_add(msgs, ('REQ', a, GETS, l, None)))
            elif k == STORE:
                if ent is not None and ent[1] == M:
                    nv = ver + 1
                    ncache = tuple(sorted(others + ((l, M, nv),)))
                    emit(f'a{a}:store-hit', ag=set_t(ag, a, (A_RESP, op, ncache, pend, left)),
                         gold=set_t(gold, l, nv), ver=nv)
                elif ent is not None:  # S -> upgrade
                    emit(f'a{a}:UPG', ag=set_t(ag, a, (A_WAIT, op, cache, (P_SM, l, False, None), left)),
                         msgs=msgs_add(msgs, ('REQ', a, UPG, l, None)))
                elif len(cache) >= cfg.cap:
                    v = cache[0]
                    na, m = evict(v, tuple(e for e in cache if e is not v))
                    emit(f'a{a}:store-evict', ag=set_t(ag, a, na), msgs=msgs_add(msgs, m))
                else:
                    emit(f'a{a}:GETM', ag=set_t(ag, a, (A_WAIT, op, cache, (P_IM, l, False, None), left)),
                         msgs=msgs_add(msgs, ('REQ', a, GETM, l, None)))
            elif k == FLUSH:
                if ent is not None:
                    na, m = evict(ent, others)
                    emit(f'a{a}:flush-evict', ag=set_t(ag, a, na), msgs=msgs_add(msgs, m))
                else:
                    emit(f'a{a}:flush-nop', ag=set_t(ag, a, (A_RESP, op, cache, pend, left)))

        # --- waiting for eviction to finish
        if a_st == A_WAIT and pend is None:
            k, l = op
            emit(f'a{a}:wait-done', ag=set_t(ag, a, (A_RESP if k == FLUSH else A_EVAL, op, cache, pend, left)))

        # --- snoop delivery
        for m in sorted(set(x for x in msgs if x[0] == 'SNP' and x[1] == a)):
            _, dst, st, l = m
            nmsgs = msgs_del(msgs, m)
            ent = next((e for e in cache if e[0] == l), None)
            pr = None  # (new_agent_tuple, response_message or None)
            if pend is not None and pend[1] == l:
                pk, pl, lost, pd = pend
                if pk == P_MI and st in (FWD_S, FWD_M) and not lost:
                    pr = ((a_st, op, cache, (pk, pl, True, pd), left), ('RSP', a, DATA, l, pd, False))
                elif pk == P_SI and st == INV and not lost:
                    pr = ((a_st, op, cache, (pk, pl, True, pd), left), ('RSP', a, INVACK, l, None, False))
                elif pk == P_SM and st == INV and ent is not None and ent[1] == S:
                    pr = ((a_st, op, tuple(e for e in cache if e is not ent), (P_IM, pl, False, None), left),
                          ('RSP', a, INVACK, l, None, False))
                else:
                    raise Violation(f'agent{a} snoop {st} line{l} in pending {pend} cache {cache}')
            elif ent is not None:
                if st == INV and ent[1] == S:
                    pr = ((a_st, op, tuple(e for e in cache if e is not ent), pend, left),
                          ('RSP', a, INVACK, l, None, False))
                elif st == FWD_S and ent[1] == M:
                    pr = ((a_st, op, tuple(sorted(tuple(e for e in cache if e is not ent) + ((l, S, ent[2]),))), pend, left),
                          ('RSP', a, DATA, l, ent[2], True))
                elif st == FWD_M and ent[1] == M:
                    pr = ((a_st, op, tuple(e for e in cache if e is not ent), pend, left),
                          ('RSP', a, DATA, l, ent[2], False))
                else:
                    raise Violation(f'agent{a} bad snoop {st} on {ent} line{l}')
            else:
                raise Violation(f'agent{a} snoop {st} for absent line{l} (pend={pend})')
            na, rm = pr
            emit(f'a{a}:snp-{st}', ag=set_t(ag, a, na), msgs=msgs_add(nmsgs, rm))

        # --- grant delivery
        for m in sorted(set(x for x in msgs if x[0] == 'GNT' and x[1] == a)):
            _, dst, gt, l, gd = m
            nmsgs = msgs_del(msgs, m)
            if pend is None or pend[1] != l:
                raise Violation(f'agent{a} unexpected grant {m} pend={pend}')
            pk, pl, lost, pd = pend
            k, ol = op
            if gt == GN_PUTACK:
                if pk not in (P_MI, P_SI):
                    raise Violation(f'agent{a} PUTACK in pending {pk}')
                emit(f'a{a}:putack', ag=set_t(ag, a, (a_st, op, cache, None, left)), msgs=nmsgs)
                continue
            if ol != l:
                raise Violation(f'agent{a} grant line {l} != op line {ol}')
            if len(cache) >= cfg.cap and gt != GN_UPG:
                raise Violation(f'agent{a} install without free way')
            nm = msgs_add(nmsgs, ('RSP', a, COMPLETE, l, None, False))
            ngold, nver = gold, ver
            if gt == GN_DATA_S and pk == P_IS:
                if gd != gold[l]:
                    raise Violation(f'STALE FILL agent{a} line{l}: {gd} vs golden {gold[l]}')
                ncache = tuple(sorted(cache + ((l, S, gd),)))
            elif gt == GN_DATA_M and pk in (P_IM, P_SM):
                if gd != gold[l]:
                    raise Violation(f'STALE FILL(M) agent{a} line{l}: {gd} vs golden {gold[l]}')
                nver = ver + 1
                ngold = set_t(gold, l, nver)
                base = tuple(e for e in cache if e[0] != l)
                ncache = tuple(sorted(base + ((l, M, nver),)))
            elif gt == GN_UPG and pk == P_SM:
                ent = next((e for e in cache if e[0] == l), None)
                if ent is None or ent[1] != S:
                    raise Violation(f'agent{a} UPG grant but no S copy')
                if ent[2] != gold[l]:
                    raise Violation(f'STALE UPG agent{a} line{l}: {ent[2]} vs golden {gold[l]}')
                nver = ver + 1
                ngold = set_t(gold, l, nver)
                base = tuple(e for e in cache if e[0] != l)
                ncache = tuple(sorted(base + ((l, M, nver),)))
            else:
                raise Violation(f'agent{a} grant {gt} in pending {pk}')
            emit(f'a{a}:grant-{gt}', ag=set_t(ag, a, (A_RESP, op, ncache, None, left)), msgs=nm, gold=ngold, ver=nver)

    # ===================== directory =======================================================================
    for i in range(n):
        sl = slots[i]
        # accept request into an idle slot
        if sl is None:
            for m in sorted(set(x for x in msgs if x[0] == 'REQ' and x[1] == i)):
                _, src, ty, l, d = m
                emit(f'd{i}:accept-{ty}', slots=set_t(slots, i, (T_WAIT, ty, l, d, False, 0, None, 0, 0, False, None, None)),
                     msgs=msgs_del(msgs, m))
            continue
        ts, ty, l, dbuf, keep, to_send, kind, waiting, need_mem, wr_after, gtype, ent = sl

        if ts == T_WAIT:
            if any(active(slots[j]) and slots[j][2] == l for j in range(n) if j != i):
                continue  # line busy
            est, esh, eow = de[l]
            me = 1 << i
            treat_getm = ty == GETM or (ty == UPG and not (est == SHR and (esh & me)))
            ns = None
            if ty == GETS:
                if est == MOD:
                    if eow == i:
                        raise Violation(f'GETS from owner {i}')
                    ns = (T_GATHER, ty, l, dbuf, False, 1 << eow, FWD_S, 0, 0, 'no_mem_update' not in MUT, GN_DATA_S, (est, esh, eow))
                else:
                    ns = (T_GATHER, ty, l, dbuf, False, 0, None, 0, 1, False, GN_DATA_S, (est, esh, eow))
            elif treat_getm:
                if est == MOD:
                    if eow == i:
                        raise Violation(f'GETM from owner {i}')
                    ns = (T_GATHER, ty, l, dbuf, False, 1 << eow, FWD_M, 0, 0, True, GN_DATA_M, (est, esh, eow))
                elif est == SHR:
                    ns = (T_GATHER, ty, l, dbuf, False, 0 if 'no_inv' in MUT else esh & ~me, INV, 0, 1, False, GN_DATA_M, (est, esh, eow))
                else:
                    ns = (T_GATHER, ty, l, dbuf, False, 0, None, 0, 1, False, GN_DATA_M, (est, esh, eow))
            elif ty == UPG:  # R is a sharer
                ns = (T_GATHER, ty, l, dbuf, False, 0 if 'no_inv' in MUT else esh & ~me, INV, 0, 0, False, GN_UPG, (est, esh, eow))
            elif ty == PUTS:
                ns = (T_GRANT, ty, l, dbuf, False, 0, None, 0, 0, False, GN_PUTACK, (est, esh, eow))
            elif ty == PUTM:
                if est == MOD and eow == i:
                    ns = (T_MEMWR, ty, l, dbuf, False, 0, None, 0, 0, False, GN_PUTACK, (est, esh, eow))
                elif 'stale_putm_writes' in MUT:
                    ns = (T_MEMWR, ty, l, dbuf, False, 0, None, 0, 0, False, GN_PUTACK, (est, esh, eow))
                else:
                    ns = (T_GRANT, ty, l, dbuf, False, 0, None, 0, 0, False, GN_PUTACK, (est, esh, eow))
            emit(f'd{i}:start-{ty}', slots=set_t(slots, i, ns))

        elif ts == T_GATHER:
            for j in range(n):
                if to_send & (1 << j):
                    ns = (ts, ty, l, dbuf, keep, to_send & ~(1 << j), kind, waiting | (1 << j), need_mem, wr_after, gtype, ent)
                    emit(f'd{i}:snp-{kind}->{j}', slots=set_t(slots, i, ns), msgs=msgs_add(msgs, ('SNP', j, kind, l)))
            if need_mem:
                ns = (ts, ty, l, mem[l], keep, to_send, kind, waiting, 0, wr_after, gtype, ent)
                emit(f'd{i}:memrd', slots=set_t(slots, i, ns))
            if (to_send == 0 or 'grant_before_acks' in MUT) and (waiting == 0 or 'grant_before_acks' in MUT or ('no_fwd_wait' in MUT and kind in (FWD_S, FWD_M))) and need_mem == 0:
                emit(f'd{i}:gather-done',
                     slots=set_t(slots, i, (T_MEMWR if wr_after else T_GRANT, ty, l, dbuf, keep, 0, kind, 0, 0, wr_after, gtype, ent)))

        elif ts == T_MEMWR:
            emit(f'd{i}:memwr', mem=set_t(mem, l, dbuf), slots=set_t(slots, i, (T_GRANT, ty, l, dbuf, keep, 0, kind, 0, 0, False, gtype, ent)))

        elif ts == T_GRANT:
            nm = msgs_add(msgs, ('GNT', i, gtype, l, dbuf if gtype in (GN_DATA_S, GN_DATA_M) else None))
            if gtype == GN_PUTACK:
                nde = commit(cfg, de, sl, i)
                emit(f'd{i}:putack', slots=set_t(slots, i, None), msgs=nm, de=nde)
            else:
                emit(f'd{i}:grant', slots=set_t(slots, i, (T_COMPL,) + sl[1:]), msgs=nm)

    # directory consumes agent->dir responses (routed by line / source)
    for m in sorted(set(x for x in msgs if x[0] == 'RSP')):
        _, src, ty, l, d, kp = m
        nmsgs = msgs_del(msgs, m)
        if ty == COMPLETE:
            sl = slots[src]
            if sl is None or sl[0] != T_COMPL or sl[2] != l:
                raise Violation(f'unexpected COMPLETE from {src} line{l} slot={sl}')
            nde = commit(cfg, de, sl, src)
            emit(f'd:complete-{src}', slots=set_t(slots, src, None), msgs=nmsgs, de=nde)
        else:
            k = next((j for j in range(n) if slots[j] is not None and slots[j][0] == T_GATHER and slots[j][2] == l), None)
            if k is None:
                raise Violation(f'unexpected RSP {m}')
            sl = slots[k]
            ts, ty2, l2, dbuf, keep, to_send, kind, waiting, need_mem, wr_after, gtype, ent = sl
            if not (waiting & (1 << src)):
                raise Violation(f'RSP {m} from agent not awaited, slot {sl}')
            if ty == INVACK and kind != INV or ty == DATA and kind not in (FWD_S, FWD_M):
                raise Violation(f'RSP type {ty} mismatches snoop kind {kind}')
            nsl = (ts, ty2, l2, d if ty == DATA else dbuf, kp if ty == DATA else keep, to_send, kind,
                   waiting & ~(1 << src), need_mem, wr_after, gtype, ent)
            emit(f'd:rsp-{ty}-{src}', slots=set_t(slots, k, nsl), msgs=nmsgs)
    return out


def commit(cfg, de, sl, i):
    ts, ty, l, dbuf, keep, to_send, kind, waiting, need_mem, wr_after, gtype, ent = sl
    est, esh, eow = ent
    me = 1 << i
    if ty == GETS:
        if est == MOD:
            new = (SHR, me | ((1 << eow) if (keep or 'ignore_keep' in MUT) else 0), 0)
        else:
            new = (SHR, esh | me, 0)
    elif ty in (GETM, UPG):
        new = (MOD, me, i)
    elif ty == PUTS:
        if est == SHR and (esh & me):
            nsh = esh & ~me
            new = (SHR, nsh, 0) if nsh else (UNC, 0, 0)
        else:
            new = ent
    else:  # PUTM
        new = (UNC, 0, 0) if (est == MOD and eow == i) else ent
    return set_t(de, l, new)


# ---- invariants -------------------------------------------------------------------------------------------------
def check(cfg, s):
    ag, de, mem, slots, msgs, gold, ver = s
    n = cfg.n
    for l in range(cfg.lines):
        hm = [has_copy(ag[a], l, msgs, a)[0] for a in range(n)]
        hs = [has_copy(ag[a], l, msgs, a)[1] for a in range(n)]
        if sum(hm) > 1:
            raise Violation(f'MULTIPLE OWNERS line{l}')
        if any(hm) and any(hs):
            raise Violation(f'SHARED COPY ALONGSIDE OWNER line{l}')
        # cached values are current (a copy is never stale)
        for a in range(n):
            for (cl, st, d) in ag[a][2]:
                if cl == l and d != gold[l]:
                    raise Violation(f'STALE COPY agent{a} line{l} st={st} data={d} golden={gold[l]}')
        # line-quiescent -> directory entry is EXACT and memory is right
        busy = any(active(slots[j]) and slots[j][2] == l for j in range(n))
        if not busy:
            est, esh, eow = de[l]
            holders = sum((1 << a) for a in range(n) if hm[a] or hs[a])
            if est == UNC:
                if holders or esh:
                    raise Violation(f'DIR UNC but holders {holders:b} line{l}')
                if mem[l] != gold[l]:
                    raise Violation(f'STALE MEMORY line{l} (UNC): {mem[l]} vs {gold[l]}')
            elif est == SHR:
                if esh != holders or any(hm) or esh == 0:
                    raise Violation(f'DIR SHR sh={esh:b} holders={holders:b} line{l}')
                if mem[l] != gold[l]:
                    raise Violation(f'STALE MEMORY line{l} (SHR): {mem[l]} vs {gold[l]}')
            else:
                if esh != (1 << eow) or holders != (1 << eow) or not hm[eow]:
                    raise Violation(f'DIR MOD owner={eow} sh={esh:b} holders={holders:b} line{l}')
    # at most one transaction per line
    for i in range(n):
        for j in range(i + 1, n):
            if active(slots[i]) and active(slots[j]) and slots[i][2] == slots[j][2]:
                raise Violation('TWO ACTIVE TRANSACTIONS ON ONE LINE')
    # ownership granted only after required invalidations: when a M/UPG grant is in flight no other agent holds a copy
    for (kind, *rest) in msgs:
        pass
    for i in range(n):
        sl = slots[i]
        if sl is not None and sl[0] in (T_GRANT, T_COMPL) and sl[10] in (GN_DATA_M, GN_UPG):
            l = sl[2]
            for a in range(n):
                if a != i:
                    hm, hs = has_copy(ag[a], l, msgs, a)
                    if hm or hs:
                        raise Violation(f'OWNERSHIP GRANTED WHILE agent{a} STILL HOLDS line{l}')


def done(cfg, s):
    ag, de, mem, slots, msgs, gold, ver = s
    return (all(a[0] == A_IDLE and a[4] == 0 for a in ag) and not msgs and all(x is None for x in slots))


def explore(cfg, verbose=True):
    s0 = initial(cfg)
    parent = {s0: None}
    seen = {s0}
    q = deque([s0])
    ntrans = 0
    ndone = 0
    t0 = time.time()
    max_gold = 0
    try:
        while q:
            s = q.popleft()
            check(cfg, s)
            succ = successors(cfg, s)
            if not succ:
                if not done(cfg, s):
                    raise Violation(f'DEADLOCK: {s}')
                ndone += 1
            for lab, t in succ:
                ntrans += 1
                if t not in seen:
                    seen.add(t)
                    parent[t] = (s, lab)
                    q.append(t)
                    if len(seen) > cfg.max_states:
                        raise RuntimeError('state limit')
            if verbose and len(seen) % 200000 == 0:
                print(f'  ... {len(seen)} states, queue {len(q)}', flush=True)
    except Violation as e:
        tr = []
        cur = s
        while parent.get(cur):
            p, lab = parent[cur]
            tr.append(lab)
            cur = p
        return dict(ok=False, error=str(e), states=len(seen), trans=ntrans, trace=list(reversed(tr)))
    # final-state sanity: every terminal state is quiescent and memory/caches consistent (checked above)
    return dict(ok=True, states=len(seen), trans=ntrans, terminal=ndone, secs=time.time() - t0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--agents', type=int, default=2)
    ap.add_argument('--lines', type=int, default=2)
    ap.add_argument('--cap', type=int, default=1)
    ap.add_argument('--ops', type=int, default=3, help='CPU operations per agent')
    ap.add_argument('--no-flush', action='store_true')
    ap.add_argument('--mutant', choices=sorted(MUTANTS), help='inject a protocol bug (checker must report it)')
    a = ap.parse_args()
    kinds = (LOAD, STORE) if a.no_flush else (LOAD, STORE, FLUSH)
    if a.mutant:
        MUT.add(a.mutant)
        print('MUTANT:', a.mutant, '-', MUTANTS[a.mutant])
    cfg = Cfg(a.agents, a.lines, a.cap, a.ops, kinds)
    print(f'MSI directory protocol model: agents={cfg.n} lines={cfg.lines} cache capacity={cfg.cap} lines/agent '
          f'ops/agent={cfg.ops} kinds={kinds}')
    r = explore(cfg)
    print({k: v for k, v in r.items() if k != 'trace'})
    if not r['ok']:
        print('counterexample (%d steps): ' % len(r['trace']) + ' ; '.join(r['trace']))
    sys.exit(0 if r['ok'] else 1)


if __name__ == '__main__':
    main()
