#!/usr/bin/env python3
"""Formal sensitivity with the UNBOUNDED engine: inject each bug, run PDR on the same harness; a counterexample must be found.
usage: run_pdr_mutants.py <nodata|full> <timeout_s> <mutant> [<mutant> ...]     Output appended to reports/mutants_pdr.md"""
import os, re, shutil, subprocess, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mutants import MUTANTS
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES = ['sf_coherence_pkg.sv', 'sf_coherence_sharers.sv', 'sf_coherence_transient_fsm.sv', 'sf_coherence_directory.sv',
         'sf_coherence_agent_adapter.sv', 'sf_coherence_nc_gateway.sv', 'sf_coherence_subsystem.sv']
mode, tmo = sys.argv[1], sys.argv[2]
for name in sys.argv[3:]:
    _, fn, old, new, why = [x for x in MUTANTS if x[0] == name][0]
    d = f'{ROOT}/build/pmut_{name}'
    shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
    for f in FILES:
        shutil.copy(f'{ROOT}/rtl/coherence/{f}', d)
    t = open(f'{d}/{fn}').read()
    assert t.count(old) == 1
    open(f'{d}/{fn}', 'w').write(t.replace(old, new))
    env = dict(os.environ, FV_RTL=d, FV_TAG=f'm_{mode}_{name}')
    if mode == 'nodata':
        env['FV_DEFS'] = '-DFV_NODATA'
    t0 = time.time()
    r = subprocess.run([f'{ROOT}/formal/run_pdr.sh', tmo], capture_output=True, text=True, env=env)
    line = (r.stdout.strip().splitlines() or [''])[-1]
    log = open(f'{ROOT}/build/formal/pdr_m_{mode}_{name}.log').read() if os.path.exists(f'{ROOT}/build/formal/pdr_m_{mode}_{name}.log') else ''
    fr = re.search(r'Output \d+ of miter .*? was asserted in frame (\d+)', log, re.S)
    if fr:
        res = f'**COUNTEREXAMPLE** (property violated at depth {fr.group(1)})'
    elif 'Property proved' in log:
        res = '**PROVED (bug not detected)**'
    else:
        res = 'inconclusive (timeout)'
    print(f'{name}: {res} [{int(time.time() - t0)} s]', flush=True)
    with open(f'{ROOT}/reports/mutants_pdr.md', 'a') as f:
        f.write(f'| `{name}` | {why} | {mode} | {res} | {int(time.time() - t0)} s |\n')
    shutil.rmtree(d, ignore_errors=True)
