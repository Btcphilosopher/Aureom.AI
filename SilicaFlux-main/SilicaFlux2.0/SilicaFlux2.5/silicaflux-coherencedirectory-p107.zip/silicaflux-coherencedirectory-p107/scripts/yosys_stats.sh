#!/bin/bash
# Generic Yosys 0.33 synthesis statistics (no liberty, no timing, no area claim): cell counts per block and geometry.
ROOT=$(cd "$(dirname "$0")/.." && pwd)
R=$ROOT/rtl/coherence
F="$R/sf_coherence_pkg.sv $R/sf_coherence_sharers.sv $R/sf_coherence_transient_fsm.sv $R/sf_coherence_directory.sv $R/sf_coherence_agent_adapter.sv $R/sf_coherence_nc_gateway.sv $R/sf_coherence_subsystem.sv"
run() {  # name top params
  yosys -q -p "read_verilog -sv $F; hierarchy -top $2 $3; synth -flatten -top $2; tee -o /tmp/ys_$1.txt stat" >/dev/null 2>&1
  CELLS=$(grep -E "Number of cells" /tmp/ys_$1.txt | tail -1 | awk "{print \$4}")
  FFS=$(grep -E "\\\$_(S?DFF|DFFE|SDFFE|DFFSR)" /tmp/ys_$1.txt | awk '{s+=$1} END {print s+0}')
  echo "$1,$CELLS,$FFS"
}
echo "block,generic_cells,flip_flops"
run dir_n2_l16   sf_coherence_directory "-chparam N_AGENTS 2 -chparam DIR_LINES 16"
run dir_n2_l64   sf_coherence_directory "-chparam N_AGENTS 2 -chparam DIR_LINES 64"
run dir_n4_l16   sf_coherence_directory "-chparam N_AGENTS 4 -chparam DIR_LINES 16"
run dir_n8_l16   sf_coherence_directory "-chparam N_AGENTS 8 -chparam DIR_LINES 16"
run agent_s4     sf_coherence_agent_adapter "-chparam CACHE_SETS 4 -chparam DIR_LINES 16"
run agent_s16    sf_coherence_agent_adapter "-chparam CACHE_SETS 16 -chparam DIR_LINES 64"
run subsys_n2    sf_coherence_subsystem "-chparam N_AGENTS 2 -chparam DIR_LINES 16 -chparam CACHE_SETS 4"
