#!/usr/bin/env python3
"""Turns benchmarks/results.csv into docs/08_PERFORMANCE.md (tables are generated; the commentary refers only to numbers in them)."""
import csv, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rows = list(csv.DictReader(open(f'{ROOT}/benchmarks/results.csv')))
ALL4 = {'read_shared', 'migratory_amo', 'read_mostly'}          # workloads that drive agents 0..3 in the 4-agent build
def f(r, k): return int(r[k])
def derived(r):
    ops = f(r, 'ops'); cyc = f(r, 'cycles')
    coh = sum(f(r, k) for k in ('bytes_req', 'bytes_rsp', 'bytes_snp', 'bytes_gnt'))
    mem = f(r, 'bytes_mem_rd') + f(r, 'bytes_mem_wr')
    return dict(ops=ops, cyc_op=cyc / ops, lat_op=f(r, 'sum_op_latency') / ops, coh_op=coh / ops, mem_op=mem / ops,
                hit=f(r, 'agent_hits') / ops, lk_op=f(r, 'lookups') / ops, busy=100 * f(r, 'dir_busy_cyc') / cyc)
def pick(na, lat):
    return [r for r in rows if f(r, 'agents') == na and f(r, 'mem_lat') == lat]
out = []
w = out.append
w('# 08 — Coherence performance (RTL simulation counters)\n')
w('> **Evidence level.** Every number below is a cycle or byte count read from the RTL counters in a simulation run whose data was verified by the reference checker '
  '(`BENCH DONE checker_errors=0`). Cycles are *testbench* cycles with the stated memory latency; **no frequency, silicon timing, area or power is claimed.** '
  'Regenerate with `scripts/run_bench.sh && scripts/make_perf_report.py`. Raw counters: `benchmarks/results.csv`.\n')
w('## 1. Counters (mission §10) and what they count\n')
w('| counter | RTL name | definition |\n|---|---|---|\n'
  '| shared reads | `PD_GETS` | `GETS` transactions started |\n| exclusive requests | `PD_GETM` | `GETM` started |\n| upgrades | `PD_UPG` | `UPG` started |\n'
  '| clean / dirty evictions | `PD_PUTS`, `PD_PUTM` | evictions started (includes stale ones) |\n| invalidations | `PD_INV` | `INV` snoops issued |\n'
  '| ownership transfers | `PD_OWN_XFER` | owner→new-owner transfers (`FWD_M` data received) |\n| dirty interventions | `PD_DIRTY_INT` | owner data responses (`FWD_S` + `FWD_M`) |\n'
  '| directory lookups | `PD_LOOKUPS` | one per started transaction |\n| coherence stalls | `PD_STALL_CONF`, `PD_STALL_GATH` | slot-cycles a request waited for a busy line / slot-cycles in `GATHER` |\n'
  '| traffic bytes | `PD_BYTES_{REQ,RSP,SNP,GNT}`, `PD_MEM_{RD,WR}_B` | 8-byte header per message + 64 data bytes on `PUTM`/`DATA`/fills; memory port bytes |\n'
  '| protocol retries | `PD_RETRIES` | requests deferred at least once by a same-line conflict. **The protocol has no NACK**, so this is conflict-deferral, not a re-sent message. |\n')

def table(na, lat, title):
    rs = pick(na, lat)
    w(f'### {title}\n')
    w('| workload | ops | cycles/op | avg op latency | hit rate | dir lookups/op | coherence B/op | memory B/op | GETS | GETM | UPG | PUTM | PUTS | INV | own. xfer | dirty int. | conflict-stall cycles | retries | dir busy |')
    w('|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|')
    for r in rs:
        d = derived(r)
        mark = '' if (na == 2 or r['workload'] in ALL4) else ' ¹'
        w(f"| {r['workload']}{mark} | {d['ops']} | {d['cyc_op']:.2f} | {d['lat_op']:.1f} | {d['hit']:.2f} | {d['lk_op']:.2f} | {d['coh_op']:.1f} | {d['mem_op']:.1f} | {r['gets']} | {r['getm']} | {r['upg']} | {r['putm']} | {r['puts']} | {r['inv']} | {r['own_xfer']} | {r['dirty_int']} | {r['stall_conflict_cyc']} | {r['retries']} | {d['busy']:.0f} % |")
    w('')
w('## 2. Results\n')
table(2, 1, '2 agents, memory latency 1 (the verified configuration)')
table(2, 8, '2 agents, memory latency 8')
table(4, 1, '4 agents, memory latency 1')
w('¹ this workload drives only agents 0 and 1 even in the 4-agent build, so its row equals the 2-agent row; rows without the mark use all four agents.\n')
table(4, 8, '4 agents, memory latency 8')
w('¹ as above.\n')
a = {r['workload']: derived(r) for r in pick(2, 1)}
b = {r['workload']: derived(r) for r in pick(2, 8)}
c = {r['workload']: derived(r) for r in pick(4, 1)}
d = {r['workload']: derived(r) for r in pick(4, 8)}
mig = [r for r in pick(2, 1) if r['workload'] == 'migratory_amo'][0]
pc = [r for r in pick(2, 1) if r['workload'] == 'producer_consumer'][0]
w('## 3. What the numbers say (each statement is read off the tables above)\n')
w(f"* **Private data costs almost nothing**: {a['private']['hit']*100:.0f} % of operations hit with no coherence request; {a['private']['coh_op']:.1f} coherence bytes per operation; the directory is busy {a['private']['busy']:.0f} % of the time (compulsory misses only).")
w(f"* **Read sharing is cheap and scales**: `read_shared` keeps {a['read_shared']['hit']*100:.0f} % hits and {a['read_shared']['coh_op']:.1f} B/op with 2 agents, and {c['read_shared']['coh_op']:.1f} B/op with 4 (compulsory fills only).")
w(f"* **Ping-pong writes are the expensive case.** `migratory_amo` (every agent fetch-adds one word): every operation is an ownership transfer — {a['migratory_amo']['coh_op']:.0f} coherence bytes and {a['migratory_amo']['mem_op']:.0f} memory bytes per operation, {a['migratory_amo']['cyc_op']:.1f} cycles/op, the directory {a['migratory_amo']['busy']:.0f} % busy, "
  f"{mig['stall_conflict_cyc']} slot-cycles of conflict stall. With 4 agents the per-op latency grows from {a['migratory_amo']['lat_op']:.1f} to {c['migratory_amo']['lat_op']:.1f} cycles (queueing on one line) while throughput stays {c['migratory_amo']['cyc_op']:.1f} cycles/op: the line, not the directory, is the bottleneck. `false_sharing` produces the identical counters because the two agents' disjoint words share a line — false sharing is as expensive as true sharing.")
w(f"* **Dirty data goes through the directory.** `producer_consumer`: {pc['dirty_int']} dirty interventions for {pc['ops']} operations; each read of a modified line costs a `FWD_S`, a data response and a memory write ({a['producer_consumer']['mem_op']:.0f} memory bytes per op). Direct cache-to-cache forwarding would remove the extra data hop but not the memory write; that trade-off is listed in docs/09.")
w(f"* **The memory write on every intervention is a measurable choice**: `migratory_amo` writes {a['migratory_amo']['mem_op']:.0f} B/op to memory although memory is never read in the steady state (an `M→M` transfer does not need the write: skipping it would remove those bytes; not implemented).")
w(f"* **Memory latency matters only where memory is on the critical path**: raising memory latency 1→8 changes cycles/op from {a['private']['cyc_op']:.2f} to {b['private']['cyc_op']:.2f} for `private`, but from {a['migratory_amo']['cyc_op']:.1f} to {b['migratory_amo']['cyc_op']:.1f} for `migratory_amo` and from {a['streaming_evict']['cyc_op']:.1f} to {b['streaming_evict']['cyc_op']:.1f} for `streaming_evict` (writeback + fill per miss).")
w(f"* **Directory utilisation is the contention signal**: {a['migratory_amo']['busy']:.0f} % (ping-pong), {a['streaming_evict']['busy']:.0f} % (streaming), {a['mixed_random']['busy']:.0f} % (mixed random) versus {a['private']['busy']:.0f} % (private). One transaction per line and one start per cycle are not the limit at these loads: the lookups-per-op column stays ≤ {max(v['lk_op'] for v in a.values()):.2f}.")
w('* **Protocol retries**: the `retries` column counts requests that had to wait once for a busy line (conflict deferral). It tracks the sharing intensity (`migratory_amo`, `mixed_random`) and is 0 for private and streaming traffic.\n')
w('## 4. Limits of these measurements\n')
w('* Blocking single-operation agents and one outstanding request per agent: the numbers show the protocol\'s cost, not the throughput of an out-of-order core.\n'
  '* One workload instance per configuration (deterministic, fixed seed); no confidence intervals. The mixed workload is random with a fixed seed.\n'
  '* The memory model has a fixed latency and unlimited bandwidth; real LLC / DRAM contention is not modelled.\n'
  '* "Coherence bytes" use a modelled 8-byte header; a real link adds its own framing.\n')
open(f'{ROOT}/docs/08_PERFORMANCE.md', 'w').write('\n'.join(out) + '\n')
print('wrote docs/08_PERFORMANCE.md')
