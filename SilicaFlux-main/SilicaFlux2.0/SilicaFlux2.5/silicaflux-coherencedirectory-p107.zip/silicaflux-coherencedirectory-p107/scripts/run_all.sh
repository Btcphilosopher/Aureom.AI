#!/bin/bash
# SilicaFlux P107 -- regenerate every report in reports/ and benchmarks/.   usage: scripts/run_all.sh [quick|full]
# Tools: iverilog 12, verilator 5.020, yosys 0.33 (+ its built-in SAT), python3.  Everything is local; nothing is committed anywhere.
set -u
ROOT=$(cd "$(dirname "$0")/.." && pwd); cd $ROOT
MODE=${1:-quick}
R=rtl/coherence
RTL="$R/sf_coherence_pkg.sv $R/sf_coherence_sharers.sv $R/sf_coherence_transient_fsm.sv $R/sf_coherence_directory.sv $R/sf_coherence_agent_adapter.sv $R/sf_coherence_nc_gateway.sv $R/sf_coherence_subsystem.sv"
mkdir -p build reports benchmarks
step() { echo; echo "=== $*"; }

step "1. lint (Verilator -Wall) and Yosys elaboration"
verilator --lint-only -Wall -Wno-DECLFILENAME -Wno-UNUSEDPARAM -Wno-UNUSEDSIGNAL -Wno-PINCONNECTEMPTY -Wno-WIDTHEXPAND -Wno-WIDTHTRUNC -Wno-UNUSEDGENVAR \
   --top-module sf_coherence_subsystem $RTL > reports/lint.log 2>&1 && echo "verilator lint: clean" || { echo "verilator lint: WARNINGS (see reports/lint.log)"; }
yosys -q -p "read_verilog -sv $RTL; hierarchy -top sf_coherence_subsystem; proc; flatten; opt -fast" > reports/yosys_elab.log 2>&1 && echo "yosys 0.33 elaboration: ok"

step "2. protocol reference model (exhaustive) + protocol mutants"
scripts/run_model.sh | tail -14

step "3. directed + random system testbench (Icarus), default configuration"
iverilog -g2012 -o build/tb.vvp -s tb_sf_coherence $RTL tb/sf_coh_mem_model.sv tb/sf_coh_checker.sv tb/tb_sf_coherence.sv 2>/dev/null
vvp -n build/tb.vvp | tee reports/regression_directed.log | grep -E "PASS|FAIL|TB RESULT|stale read|SB outcomes"

step "4. fork-free random testbench (Verilator)"
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module tb_sf_coherence_rand -GNOPS=800 -Mdir build/vl2 $RTL tb/sf_coh_mem_model.sv tb/sf_coh_checker.sv tb/tb_sf_coherence_rand.sv -o tb >/dev/null 2>&1
build/vl2/tb | grep -E "RAND"

if [ "$MODE" = full ]; then
  step "5. configuration / seed sweep (Icarus)";           python3 scripts/run_sweep.py | tail -3
  step "6. Verilator random campaign";                      python3 scripts/run_rand_campaign.py 40 | tail -2
  step "7. simulation mutants (17 bugs)";                   python3 scripts/run_mutants.py | tail -2
  step "8. benchmarks";                                     scripts/run_bench.sh && python3 scripts/make_perf_report.py
  step "9. latency";                                        iverilog -g2012 -o build/lat.vvp -s tb_sf_coherence_lat -Ptb_sf_coherence_lat.CACHE_SETS=1 $RTL tb/sf_coh_mem_model.sv tb/sf_coh_checker.sv tb/tb_sf_coherence_lat.sv 2>/dev/null && vvp -n build/lat.vvp | grep LAT
  step "10. generic synthesis statistics";                  scripts/yosys_stats.sh
fi
step "formal (separate: minutes to hours)"
echo "free-input BMC   : formal/run_formal.sh bmc 14"
echo "programmed BMC   : FV_TOP=sf_coh_fv_prog FV_CHPARAM='K 2' formal/run_formal.sh bmc 24"
echo "k-induction      : formal/run_formal.sh ind 5      (expected to FAIL: not strengthened, docs/07)"
echo "formal mutants   : python3 scripts/run_formal_mutants.py 16 amo_is_store no_inv_on_upgrade"
