#!/usr/bin/env python3
"""Configuration / seed sweep of tb_sf_coherence (Icarus Verilog).  Usage: run_sweep.py [--quick]
Each row = one simulation run; every run must print 'TB RESULT: PASS'.  Output: reports/sweep.csv"""
import subprocess, sys, os, itertools, csv, re, concurrent.futures as cf
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = [f'{ROOT}/rtl/coherence/{f}' for f in ('sf_coherence_pkg.sv', 'sf_coherence_sharers.sv', 'sf_coherence_transient_fsm.sv',
       'sf_coherence_directory.sv', 'sf_coherence_agent_adapter.sv', 'sf_coherence_nc_gateway.sv', 'sf_coherence_subsystem.sv')]
TB = [f'{ROOT}/tb/{f}' for f in ('sf_coh_mem_model.sv', 'sf_coh_checker.sv', 'tb_sf_coherence.sv')]
os.makedirs(f'{ROOT}/build', exist_ok=True)

def run(cfg):
    name = '_'.join(f'{k}{v}' for k, v in cfg.items())
    vvp = f'{ROOT}/build/sw_{name}.vvp'
    args = ['iverilog', '-g2012', '-o', vvp, '-s', 'tb_sf_coherence'] + [f'-Ptb_sf_coherence.{k}={v}' for k, v in cfg.items()] + RTL + TB
    c = subprocess.run(args, capture_output=True, text=True)
    if c.returncode:
        return cfg, 'COMPILE-ERROR', c.stderr[-300:], {}
    r = subprocess.run(['vvp', '-n', vvp], capture_output=True, text=True, timeout=3000)
    out = r.stdout
    os.remove(vvp)
    m = re.search(r'TB RESULT: (\w+)', out)
    res = m.group(1) if m else 'NO-RESULT'
    stats = {}
    mm = re.search(r'checker: (\d+) loads, (\d+) stores, (\d+) amos, (\d+) flushes performed; (\d+) grants; (\d+) memory writes; (\d+) quiescent', out)
    if mm:
        stats = dict(zip(['loads', 'stores', 'amos', 'flushes', 'grants', 'memwr', 'qchecks'], map(int, mm.groups())))
    ds = re.search(r'directory totals: GETS=(\d+) GETM=(\d+) UPG=(\d+) PUTS=(\d+) PUTM=(\d+) INV=(\d+) ownXfer=(\d+) dirtyInt=(\d+) stalePut=(\d+)', out)
    if ds:
        stats.update(dict(zip(['GETS', 'GETM', 'UPG', 'PUTS', 'PUTM', 'INV', 'ownXfer', 'dirtyInt', 'stalePut'], map(int, ds.groups()))))
    return cfg, res, '' if res == 'PASS' else out[-600:], stats

def main():
    quick = '--quick' in sys.argv
    cfgs = []
    base = dict(RAND_OPS=250, LITMUS_ITERS=60)
    for stall, cpu, lat, rdy in [(0, 0, 1, 100), (20, 0, 1, 100), (50, 30, 3, 60), (80, 50, 6, 40), (30, 70, 2, 100)]:
        for sets in ([1, 2, 4] if not quick else [1]):
            for seed in ([1, 2] if not quick else [1]):
                cfgs.append(dict(base, STALL_PCT=stall, CPU_STALL=cpu, MEM_LAT_MAX=lat, MEM_READY=rdy, CACHE_SETS=sets, SEED=seed, NA=2, DIR_LINES=8))
    if not quick:
        for seed in (1, 2, 3):
            cfgs.append(dict(base, NA=4, STALL_PCT=30, CPU_STALL=20, MEM_LAT_MAX=3, MEM_READY=70, CACHE_SETS=1, SEED=seed, DIR_LINES=8))
            cfgs.append(dict(base, NA=3, STALL_PCT=30, CPU_STALL=20, MEM_LAT_MAX=3, MEM_READY=70, CACHE_SETS=2, SEED=seed, DIR_LINES=8))
        cfgs.append(dict(base, NA=2, DIR_LINES=2, CACHE_SETS=1, STALL_PCT=40, SEED=9))
        cfgs.append(dict(base, NA=2, DIR_LINES=16, CACHE_SETS=8, STALL_PCT=10, SEED=5))
    rows = []
    bad = 0
    with cf.ThreadPoolExecutor(max_workers=os.cpu_count() or 2) as ex:
        for cfg, res, tail, stats in ex.map(run, cfgs):
            rows.append(dict(cfg, result=res, **stats))
            print(('PASS ' if res == 'PASS' else 'FAIL ') + ' '.join(f'{k}={v}' for k, v in cfg.items() if k not in ('RAND_OPS', 'LITMUS_ITERS')), flush=True)
            if res != 'PASS':
                bad += 1
                print(tail)
    keys = sorted({k for r in rows for k in r})
    with open(f'{ROOT}/reports/sweep.csv', 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    print(f'{len(rows) - bad}/{len(rows)} configurations pass')
    sys.exit(1 if bad else 0)

if __name__ == '__main__':
    main()
