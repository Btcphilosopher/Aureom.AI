#!/bin/bash
# Coherence-traffic benchmark sweep: agents {2,4} x memory latency {1,8}; one CSV for everything.
ROOT=$(cd "$(dirname "$0")/.." && pwd)
RTL="$ROOT/rtl/coherence/sf_coherence_pkg.sv $ROOT/rtl/coherence/sf_coherence_sharers.sv $ROOT/rtl/coherence/sf_coherence_transient_fsm.sv $ROOT/rtl/coherence/sf_coherence_directory.sv $ROOT/rtl/coherence/sf_coherence_agent_adapter.sv $ROOT/rtl/coherence/sf_coherence_nc_gateway.sv $ROOT/rtl/coherence/sf_coherence_subsystem.sv"
mkdir -p $ROOT/build $ROOT/benchmarks
OUT=$ROOT/benchmarks/results.csv
: > $OUT
for NA in 2 4; do for LAT in 1 8; do for SETS in 4; do
  iverilog -g2012 -o $ROOT/build/bench_$NA_$LAT.vvp -s tb_sf_coherence_bench -Ptb_sf_coherence_bench.NA=$NA -Ptb_sf_coherence_bench.MEM_LAT=$LAT -Ptb_sf_coherence_bench.CACHE_SETS=$SETS \
    $RTL $ROOT/tb/sf_coh_mem_model.sv $ROOT/tb/sf_coh_checker.sv $ROOT/tb/tb_sf_coherence_bench.sv 2>/dev/null
  vvp -n $ROOT/build/bench_$NA_$LAT.vvp | grep -E "^CSV|BENCH" > $ROOT/build/bench_tmp.txt
  grep -q "checker_errors=0" $ROOT/build/bench_tmp.txt || { echo "BENCH FAILED NA=$NA LAT=$LAT"; cat $ROOT/build/bench_tmp.txt; exit 1; }
  if [ ! -s $OUT ]; then grep CSV_HEADER $ROOT/build/bench_tmp.txt | sed 's/CSV_HEADER,//' > $OUT; fi
  grep "^CSV," $ROOT/build/bench_tmp.txt | sed 's/^CSV,//' >> $OUT
done; done; done
echo "wrote $OUT ($(($(wc -l < $OUT)-1)) rows)"
