#!/bin/bash
# Protocol model: exhaustive exploration + bug-injection sensitivity.  Output: reports/model.log
ROOT=$(cd "$(dirname "$0")/.." && pwd)
M=$ROOT/model/sf_coherence_ref_model.py
L=$ROOT/reports/model.log
: > $L
echo "## exhaustive exploration (all interleavings, unordered channels)" >> $L
python3 $M --agents 2 --lines 2 --cap 1 --ops 3 >> $L 2>&1
python3 $M --agents 2 --lines 2 --cap 2 --ops 2 >> $L 2>&1
python3 $M --agents 3 --lines 2 --cap 1 --ops 1 >> $L 2>&1
python3 $M --agents 3 --lines 1 --cap 1 --ops 2 >> $L 2>&1
echo "## protocol mutants (each must be reported)" >> $L
for m in grant_before_acks stale_putm_writes no_inv no_mem_update ignore_keep no_fwd_wait; do
  python3 $M --agents 2 --lines 2 --cap 1 --ops 2 --mutant $m 2>&1 | grep -E "MUTANT|'ok'" | cut -c1-200 >> $L
done
cat $L | grep -E "'ok'|MUTANT" | head -40
