#!/usr/bin/env python3
"""Formal sensitivity: inject selected bugs of mutants.py and run BMC; the formal environment must find a counterexample.
usage: run_formal_mutants.py <depth> <mutant> [<mutant> ...]     Output appended to reports/mutants_formal.md"""
import os, shutil, subprocess, sys, time, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mutants import MUTANTS
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES = ['sf_coherence_pkg.sv', 'sf_coherence_sharers.sv', 'sf_coherence_transient_fsm.sv', 'sf_coherence_directory.sv',
         'sf_coherence_agent_adapter.sv', 'sf_coherence_nc_gateway.sv', 'sf_coherence_subsystem.sv']
depth = int(sys.argv[1])
env_extra = {}
if os.environ.get('FV_TOP'):
    env_extra = {k: os.environ[k] for k in ('FV_TOP', 'FV_CHPARAM') if k in os.environ}
for name in sys.argv[2:]:
    m = [x for x in MUTANTS if x[0] == name][0]
    _, fn, old, new, why = m
    d = f'{ROOT}/build/fmut_{name}'
    shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
    for f in FILES:
        shutil.copy(f'{ROOT}/rtl/coherence/{f}', d)
    t = open(f'{d}/{fn}').read()
    assert t.count(old) == 1
    open(f'{d}/{fn}', 'w').write(t.replace(old, new))
    t0 = time.time()
    env = dict(os.environ, FV_RTL=d, FV_TIMEOUT='2400', **env_extra)
    r = subprocess.run([f'{ROOT}/formal/run_formal.sh', 'bmc', str(depth)], capture_output=True, text=True, env=env)
    line = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-200:]
    found = 'did fail' in line or 'FAIL' in line
    res = 'COUNTEREXAMPLE FOUND' if found else ('NOT FOUND within depth' if 'SUCCESS' in line else 'INCONCLUSIVE')
    top = env_extra.get('FV_TOP', 'sf_coh_fv_top')
    print(f'{name}: {res} (depth {depth}, {top}, {int(time.time() - t0)} s)', flush=True)
    with open(f'{ROOT}/reports/mutants_formal.md', 'a') as f:
        f.write(f'| `{name}` | {why} | {top} | {depth} | **{res}** | {int(time.time() - t0)} s |\n')
    shutil.rmtree(d, ignore_errors=True)
