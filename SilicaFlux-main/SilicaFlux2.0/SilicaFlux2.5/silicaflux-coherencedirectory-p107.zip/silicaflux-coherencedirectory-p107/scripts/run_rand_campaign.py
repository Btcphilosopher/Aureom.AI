#!/usr/bin/env python3
"""Large random campaign on the fork-free random testbench with Verilator (independent of the Icarus regression).
One Verilator build per (agents, sets, lines) geometry; many runtime seeds / stall mixes / mid-flight resets per build.
Output: reports/rand_campaign.csv, reports/rand_campaign.log"""
import os, re, subprocess, sys, itertools, csv, random, concurrent.futures as cf
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = [f'{ROOT}/rtl/coherence/{f}' for f in ('sf_coherence_pkg.sv', 'sf_coherence_sharers.sv', 'sf_coherence_transient_fsm.sv',
       'sf_coherence_directory.sv', 'sf_coherence_agent_adapter.sv', 'sf_coherence_nc_gateway.sv', 'sf_coherence_subsystem.sv')]
TB = [f'{ROOT}/tb/{f}' for f in ('sf_coh_mem_model.sv', 'sf_coh_checker.sv', 'tb_sf_coherence_rand.sv')]
GEOS = [(2, 1, 8), (2, 2, 8), (3, 1, 8), (4, 1, 8), (4, 2, 16), (2, 4, 16)]
RUNS = int(sys.argv[1]) if len(sys.argv) > 1 else 40

def build(g):
    na, sets, lines = g
    d = f'{ROOT}/build/rc_{na}_{sets}_{lines}'
    r = subprocess.run(['verilator', '--binary', '--timing', '-Wno-fatal', '-Wno-lint', '-Wno-style', '--top-module', 'tb_sf_coherence_rand',
                        f'-GNA={na}', f'-GCACHE_SETS={sets}', f'-GDIR_LINES={lines}', f'-GNOPS=1200', '-Mdir', d] + RTL + TB + ['-o', 'tb'],
                       capture_output=True, text=True)
    return g, d, r.returncode

def run(args):
    g, d, seed, stall, cpus, nl = args
    r = subprocess.run([f'{d}/tb', f'+SEED={seed}', f'+MSEED={seed * 7 + 1}', f'+STALL={stall}', f'+CPUSTALL={cpus}', f'+NLINES={nl}', f'+MEMREADY={random.Random(seed).choice([40, 70, 100])}'],
                       capture_output=True, text=True, timeout=900)
    out = r.stdout
    m = re.search(r'RAND RESULT: (\w+)', out)
    res = m.group(1) if m else 'NO-RESULT'
    mm = re.search(r'(\d+) loads (\d+) stores (\d+) amos (\d+) flushes, (\d+) grants, (\d+) memory writes, resets=(\d+), (\d+) cycles, (\d+) quiescent-line checks', out)
    st = list(map(int, mm.groups())) if mm else [0] * 9
    ml = re.search(r'RAND LATENCY: (\d+) operations, max (\d+) cycles, mean (\d+)', out)
    st += [int(ml.group(2)), int(ml.group(1)) * int(ml.group(3))] if ml else [0, 0]
    return g, seed, stall, cpus, nl, res, st, '' if res == 'PASS' else out[-400:]

def main():
    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        builds = list(ex.map(build, GEOS))
    jobs = []
    rng = random.Random(2026)
    for g, d, rc in builds:
        if rc:
            print('BUILD FAILED', g); sys.exit(1)
        for i in range(RUNS):
            jobs.append((g, d, rng.randrange(1, 10**6), rng.choice([0, 10, 30, 60, 85]), rng.choice([0, 20, 60]), rng.choice([2, 3, 5, min(8, g[2])])))
    maxlat = {}
    rows, bad, tot = [], 0, dict(loads=0, stores=0, amos=0, flushes=0, grants=0, memwr=0, resets=0, cycles=0, qchecks=0)
    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        for g, seed, stall, cpus, nl, res, st, tail in ex.map(run, jobs):
            rows.append(dict(agents=g[0], sets=g[1], lines=g[2], seed=seed, stall=stall, cpustall=cpus, nlines=nl, result=res))
            for k, v in zip(tot, st[:9]):
                tot[k] += v
            maxlat[stall] = max(maxlat.get(stall, 0), st[9])
            rows[-1]['max_op_latency'] = st[9]
            if res != 'PASS':
                bad += 1
                print('FAIL', g, seed, stall, cpus, nl, tail)
    with open(f'{ROOT}/reports/rand_campaign.csv', 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(f'{len(rows) - bad}/{len(rows)} random runs pass across {len(GEOS)} geometries; totals: ' + ', '.join(f'{k}={v}' for k, v in tot.items()))
    print('max observed operation latency (cycles) by channel-stall %: ' + ', '.join(f'{k}%: {v}' for k, v in sorted(maxlat.items())))
    sys.exit(1 if bad else 0)

if __name__ == '__main__':
    main()
