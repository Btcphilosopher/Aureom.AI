#!/usr/bin/env python3
"""Simulation sensitivity: inject each bug of mutants.py into a copy of the RTL, run the quick regression, require FAIL.
Output: reports/mutants_sim.md"""
import os, re, shutil, subprocess, sys, concurrent.futures as cf
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mutants import MUTANTS
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES = ['sf_coherence_pkg.sv', 'sf_coherence_sharers.sv', 'sf_coherence_transient_fsm.sv', 'sf_coherence_directory.sv',
         'sf_coherence_agent_adapter.sv', 'sf_coherence_nc_gateway.sv', 'sf_coherence_subsystem.sv']
TB = [f'{ROOT}/tb/{f}' for f in ('sf_coh_mem_model.sv', 'sf_coh_checker.sv', 'tb_sf_coherence.sv')]

def run(m):
    name, fn, old, new, why = m
    d = f'{ROOT}/build/mut_{name}'
    shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
    for f in FILES:
        shutil.copy(f'{ROOT}/rtl/coherence/{f}', d)
    p = f'{d}/{fn}'
    t = open(p).read()
    if t.count(old) != 1:
        return name, why, 'INVALID', f'pattern occurs {t.count(old)} times'
    open(p, 'w').write(t.replace(old, new))
    vvp = f'{d}/m.vvp'
    c = subprocess.run(['iverilog', '-g2012', '-o', vvp, '-s', 'tb_sf_coherence', '-Ptb_sf_coherence.QUICK=1', '-Ptb_sf_coherence.RAND_OPS=120',
                        '-Ptb_sf_coherence.STALL_PCT=20', '-Ptb_sf_coherence.LITMUS_ITERS=40'] + [f'{d}/{f}' for f in FILES] + TB, capture_output=True, text=True)
    if c.returncode:
        return name, why, 'COMPILE-ERROR', c.stderr[-200:]
    try:
        r = subprocess.run(['vvp', '-n', vvp], capture_output=True, text=True, timeout=900)
        out = r.stdout
    except subprocess.TimeoutExpired:
        return name, why, 'KILLED', 'simulation timeout'
    shutil.rmtree(d, ignore_errors=True)
    if 'TB RESULT: PASS' in out:
        return name, why, 'SURVIVED', ''
    first = ''
    for ln in out.splitlines():
        if ln.startswith('CHECKER FAIL') or ln.startswith('TB FAIL'):
            first = ln.strip()[:110]; break
    if not first:
        first = 'TB RESULT: FAIL' if 'TB RESULT: FAIL' in out else 'no result'
    return name, why, 'KILLED', first

def main():
    rows = []
    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        for r in ex.map(run, MUTANTS):
            rows.append(r)
            print(f'{r[2]:9s} {r[0]:36s} {r[3]}', flush=True)
    killed = sum(1 for r in rows if r[2] == 'KILLED')
    with open(f'{ROOT}/reports/mutants_sim.md', 'w') as f:
        f.write('# Simulation mutation sensitivity\n\nEach row injects one bug into a copy of the RTL and runs the quick regression (QUICK=1, 20 % stalls).\n'
                'KILLED = the environment reports a failure.\n\n| mutant | what it breaks | result | first failure reported |\n|---|---|---|---|\n')
        for n, why, res, first in rows:
            f.write(f'| `{n}` | {why} | **{res}** | `{first}` |\n')
        f.write(f'\n**{killed} / {len(rows)} mutants killed.**\n')
    print(f'{killed}/{len(rows)} mutants killed')
    sys.exit(0 if killed == len(rows) else 1)

if __name__ == '__main__':
    main()
