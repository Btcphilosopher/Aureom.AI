#!/usr/bin/env python3
"""Builds docs/06_VERIFICATION.md from the logs in reports/ so every number in the document is read from a log."""
import csv, os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = f'{ROOT}/reports'
def rd(n):
    p = f'{R}/{n}'
    return open(p).read() if os.path.exists(p) else ''
reg = rd('regression_directed.log')
tests = re.findall(r'^\[(T\d+[^\]]*)\] (PASS|FAIL)', reg, re.M)
chk = re.search(r'checker: (\d+) loads, (\d+) stores, (\d+) amos, (\d+) flushes performed; (\d+) grants; (\d+) memory writes; (\d+) quiescent-line invariant checks; checker errors (\d+)', reg)
sb = re.search(r'SB outcomes.*', reg)
stale = re.search(r'T14: stale read observed.*', reg)
sweep = list(csv.DictReader(open(f'{R}/sweep.csv'))) if os.path.exists(f'{R}/sweep.csv') else []
sw_pass = sum(1 for r in sweep if r['result'] == 'PASS')
rc = rd('rand_campaign.log').strip().splitlines()
rc_line = '`\n`'.join(rc[-2:]) if rc else 'not run'
mut = rd('mutants_sim.md')
mk = re.search(r'\*\*(\d+) / (\d+) mutants killed', mut)
model = rd('model.log')
mrows = []
_cfg = None
for _l in model.split('## protocol mutants')[0].splitlines():
    _m = re.match(r"MSI directory protocol model: (agents=\d+ lines=\d+ cache capacity=\d+ lines/agent ops/agent=\d+)", _l)
    if _m: _cfg = _m.group(1)
    elif _l.startswith("{'ok'") and _cfg: mrows.append((_cfg, _l)); _cfg = None
o = []
w = o.append
w('# 06 — Verification environment and results\n')
w('> Every number in this document is read from a log in `reports/` by `scripts/make_verif_report.py`. Results are **RTL simulation, protocol-model exploration** and (docs/07) formal verification of the minimal 2-agent instance; no silicon, FPGA or timing evidence exists.\n')
w('## 1. Environment\n')
w('| piece | file | role |\n|---|---|---|\n'
  '| design under test | `rtl/coherence/*` via `sf_coherence_subsystem` | 2–4 agents + directory; `chan_allow_*` hooks inject a stall on any channel in any cycle |\n'
  '| shared memory model | `tb/sf_coh_mem_model.sv` | line port + word port on one array, random latency and request back-pressure, response after the operation is performed |\n'
  '| **reference model + invariants** | `tb/sf_coh_checker.sv` | golden memory recomputed from the CPU commands; SWMR, exact directory, ownership-after-invalidation, one completion per grant, no stale data / writeback / fill, no sticky error (32 checks; ids in docs/01) |\n'
  '| directed + random system test | `tb/tb_sf_coherence.sv` (Icarus) | T01–T16 below, stall injection on every channel, CPU response and memory |\n'
  '| fork-free random test | `tb/tb_sf_coherence_rand.sv` (Icarus **and** Verilator) | clocked per-agent random FSMs, random mid-flight resets, final flush + memory == golden check |\n'
  '| benchmark / latency | `tb/tb_sf_coherence_bench.sv`, `tb/tb_sf_coherence_lat.sv` | docs/08, docs/03 |\n'
  '| protocol model | `model/sf_coherence_ref_model.py` | executable spec, explicit-state exploration of all interleavings |\n'
  '| formal | `formal/*`, `tb/sf_coh_checker.sv` compiled with `-DFORMAL` | docs/07 |\n')
w('## 2. Directed and random system tests (default configuration: 2 agents, 8 lines, 1 cache set per agent, no stalls)\n')
w('| test | scenario (mission §11) | result |\n|---|---|---|')
desc = {'T01': 'two simultaneous reads', 'T02': 'read followed by write', 'T03': 'two competing writers (20 rounds, random skew)', 'T04': 'shared-to-modified upgrade',
        'T05': 'modified-owner eviction', 'T06': 'data forwarding / dirty intervention / ownership transfer', 'T07': 'back-pressure (random ops, all channels)',
        'T08': 'reset mid-flight (6 resets with traffic in flight)', 'T09': 'same-line contention (loads, stores, AMOs on one line)', 'T10': 'independent-line concurrency (both slots busy at once)',
        'T11': 'writeback races: forced PUTM-vs-intervention and PUTS-vs-INV + 100 random race rounds', 'T12': 'litmus SB / MP / 2+2W under random delays',
        'T13': 'atomic counter (2×80 AMOs → 160) + false sharing', 'T14': 'non-coherent DMA: gateway refusal, uncached region, stale-data negative control, FLUSH hand-over',
        'T15': 'random stress, 2 shared lines', 'T16': 'random stress, all lines'}
for name, res in tests:
    k = name.split()[0]
    w(f'| {name} | {desc.get(k, "")} | **{res}** |')
if chk:
    w(f'\nReference checker over the whole run: {chk.group(1)} loads, {chk.group(2)} stores, {chk.group(3)} AMOs, {chk.group(4)} flushes performed and compared; {chk.group(5)} grants; {chk.group(6)} memory writes checked for freshness; {chk.group(7)} per-line quiescent invariant checks; **checker errors {chk.group(8)}**.')
if sb: w(f'\nLitmus (T12): `{sb.group(0).strip()}`')
if stale: w(f'\nNegative control (T14): `{stale.group(0).strip()}`')
w('\n## 3. Configuration and seed sweep (Icarus, `scripts/run_sweep.py`)\n')
w(f'{sw_pass} / {len(sweep)} configurations PASS. Axes: channel stall 0–80 %, CPU response stall 0–70 %, memory latency 1–6 with 40–100 % request readiness, cache sets 1/2/4/8, agents 2/3/4, window 2/8/16 lines, 2–3 seeds. '
  'Directed tests T01–T14 run only for the 2-agent ≥ 8-line configurations; the random tests run in all.\n')
w('## 4. Verilator random campaign (`scripts/run_rand_campaign.py`)\n')
w(f'`{rc_line}`\n')
w('("max observed operation latency" = cycles from a CPU request being presented to its response being taken, over all operations of all runs with that channel-stall percentage, **including N = 4 runs and CPU response stalls**; it is an observation, not a bound.)\n')
w('Six geometries (agents × sets × lines: 2×1×8, 2×2×8, 3×1×8, 4×1×8, 4×2×16, 2×4×16), 40 runs each with random seed, stall mix (0–85 %), CPU stall, memory readiness, number of hot lines, and 4 mid-flight resets per run (the reset happens while traffic is in flight). '
  'Each run ends with every agent flushing every line and requires memory == golden model and the directory `UNC` everywhere.\n')
w('## 5. Protocol model (`model/sf_coherence_ref_model.py`)\n')
w('| configuration | result |\n|---|---|')
for cfg, res in mrows:
    ok = "'ok': True" in res
    n = re.search(r"'states': (\d+), 'trans': (\d+)", res)
    w(f'| {cfg} | {"**no violation, no deadlock**" if ok else "**VIOLATION**"}: {n.group(1)} states, {n.group(2)} transitions |')
w('\nChecked in every state: SWMR, no shared copy beside an owner, every cached value current, exact directory when a line is quiescent, memory current when nobody owns it, one transaction per line, ownership granted only with no other holder, no unexpected/mistyped message at an agent or the directory; and in every reachable non-terminal state some transition is enabled (**deadlock freedom of the protocol**). Channels are unordered multisets (any delay, any order). '
  'Six protocol mutants (grant before acks, stale PUTM writes memory, no invalidation, intervention data not written, keep bit ignored, no wait for owner data) are each reported with a counterexample trace.\n')
w('## 6. Mutation sensitivity of the RTL environment (`scripts/run_mutants.py`)\n')
if mk:
    w(f'**{mk.group(1)} / {mk.group(2)} injected RTL bugs are killed** by the quick regression (QUICK=1, 20 % stalls). First failing check per mutant:\n')
    w(mut.split('KILLED = the environment reports a failure.')[-1].replace('\n\n**', '\n**', 1).strip())
w('\n## 7. What is not covered\n')
w('See docs/10. In particular: the directed testbench runs only in Icarus (Verilator 5.020 crashes on `fork` in `initial`), 64-byte-line data paths are verified by simulation only (formal uses 4-byte lines), and the mutation score is over the listed bug classes.\n')
open(f'{ROOT}/docs/06_VERIFICATION.md', 'w').write('\n'.join(o) + '\n')
print('wrote docs/06_VERIFICATION.md')
