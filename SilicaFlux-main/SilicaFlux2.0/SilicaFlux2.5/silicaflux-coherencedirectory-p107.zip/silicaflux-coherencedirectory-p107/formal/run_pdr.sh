#!/bin/bash
# SilicaFlux P107 -- UNBOUNDED proof attempt with ABC's IC3/PDR (the engine behind SymbiYosys' `abc pdr`).
#   formal/run_pdr.sh [timeout_seconds]
# Environment: FV_TOP (default sf_coh_fv_top), FV_CHPARAM, FV_RTL (RTL dir, for mutants), FV_TAG (log tag)
ROOT=$(cd "$(dirname "$0")/.." && pwd)
OUT=$ROOT/build/formal; mkdir -p $OUT
RTL="${FV_RTL:-$ROOT/rtl/coherence}"
TOP=${FV_TOP:-sf_coh_fv_top}
TAG=${FV_TAG:-$TOP}
TMO=${1:-3000}
cat > $OUT/pdr_$TAG.ys <<YS
read_verilog -sv -formal -DFORMAL ${FV_DEFS:-} $RTL/sf_coherence_pkg.sv $RTL/sf_coherence_sharers.sv $RTL/sf_coherence_transient_fsm.sv $RTL/sf_coherence_directory.sv $RTL/sf_coherence_agent_adapter.sv $RTL/sf_coherence_subsystem.sv $ROOT/tb/sf_coh_checker.sv ${FV_EXTRA:-$ROOT/formal/sf_coh_fv_top.sv}
${FV_CHPARAM:+hierarchy -top $TOP; chparam -set $FV_CHPARAM $TOP}
prep -top $TOP
flatten
memory_map
async2sync
techmap
dffunmap
abc -fast -g AND
opt_clean -purge
tee -o $OUT/pdr_${TAG}_stat.txt stat
write_aiger -zinit -symbols -map $OUT/pdr_$TAG.aim $OUT/pdr_$TAG.aig
YS
S=$(date +%s)
yosys -q $OUT/pdr_$TAG.ys > $OUT/pdr_${TAG}_yosys.log 2>&1 || { echo "yosys failed"; tail -5 $OUT/pdr_${TAG}_yosys.log; exit 2; }
timeout $((TMO+60)) yosys-abc -c "read_aiger $OUT/pdr_$TAG.aig; fold; strash; pdr -T $TMO -v" > $OUT/pdr_$TAG.log 2>&1
E=$(date +%s)
V=$(grep -E "Property proved|Output .* was asserted|Counter-example|Timeout|timeout" $OUT/pdr_$TAG.log | tail -2 | tr '\n' '|')
echo "pdr top=$TOP tag=$TAG time=$((E-S))s verdict: $V"
