// =============================================================================
// SilicaFlux CoherenceDirectory (Project 107) :: sf_coh_fv_top  -- FORMAL HARNESS
//
// Closed system for yosys-smtbmc (BMC and k-induction):
//   two coherent agents + directory (sf_coherence_subsystem)  +  a tiny memory  +  sf_coh_checker (properties)
// Everything the environment may do is a FREE INPUT (unconstrained every cycle), constrained only by the assumptions below:
//   * each agent's CPU port: any LOAD / STORE / AMO / FLUSH / FENCE to any word of the 2-line coherent window
//     (valid may drop at any time: the agent latches the operation on acceptance)
//   * CPU response back-pressure, per-channel stalls on all four coherence channels, memory ready / response delay
// Geometry is the minimum that still contains every race: 2 agents, 2 lines, ONE cache set per agent (every access to
// the other line evicts), 4-byte lines (32-bit data) -- the protocol logic is line-size independent (docs/03 sec 5).
// Reset: low in step 0 only.  The golden model of the checker adopts the memory image during reset.
// =============================================================================
`default_nettype none

module sf_coh_fv_core (
  input  wire        clk,
  input  wire        rst_n,
  input  wire [1:0]  cpu_req_valid,
  input  wire [5:0]  cpu_op,
  input  wire [63:0] cpu_addr,
  input  wire [63:0] cpu_wdata,
  input  wire [7:0]  cpu_wstrb,
  input  wire [1:0]  cpu_rsp_ready,
  input  wire [1:0]  allow_req, allow_rsp, allow_snp, allow_gnt,
  input  wire        mem_rdy,
  input  wire        mem_go,
  output wire [1:0]  cpu_req_ready,
  output wire [1:0]  cpu_rsp_valid,
  output wire [5:0]  x_slot_state,
  output wire [1:0]  x_slot_line,
  output wire [3:0]  x_a_st,
  output wire [5:0]  x_p_st,
  output wire [1:0]  x_p_line,
  output wire [9:0]  x_dir,
  output wire [1:0]  x_slot_wait,
  output wire [1:0]  x_slot_busy,
  output wire [1:0]  x_mon_req, x_mon_rsp, x_mon_snp, x_mon_gnt,
  output wire [11:0] x_chan
);
  assign x_chan = dbg_chan;
  assign x_slot_state = dbg_slot_state;
  assign x_slot_line  = dbg_slot_line;
  assign x_a_st       = dbg_a_st;
  assign x_p_st       = dbg_p_st;
  assign x_p_line     = dbg_p_line;
  assign x_dir        = dbg_dir;
  assign x_slot_wait  = dbg_slot_wait;
  assign x_slot_busy  = dbg_slot_busy;
  assign x_mon_req = mon_req_hs; assign x_mon_rsp = mon_rsp_hs; assign x_mon_snp = mon_snp_hs; assign x_mon_gnt = mon_gnt_hs;
  localparam [31:0] BASE = 32'h8000_0000;
  localparam int NA = 2, DL = 2, CS = 1, LBY = 4, LB = 32;

  // ---------------- DUT
  wire [NA-1:0]    cpu_rsp_err;
  wire [NA*32-1:0] cpu_rdata;
  wire             mem_req_valid, mem_req_wr, mem_rsp_ready;
  wire [0:0]       mem_req_line;
  wire [LB-1:0]    mem_req_wdata;
  reg              mrsp_v;
  reg  [LB-1:0]    mrsp_d;
  reg  [LB-1:0]    mw0, mw1;
  wire             mem_req_ready = mem_rdy && !mrsp_v;
  wire             mem_rsp_valid = mrsp_v && mem_go;
  localparam int ENTW = 2 + NA + 1;

  wire [DL*ENTW-1:0] dbg_dir;
  wire [NA*3-1:0] dbg_slot_state, dbg_slot_type, dbg_slot_gtype;
  wire [NA*1-1:0] dbg_slot_line;
  wire [NA-1:0]   dbg_slot_busy, dbg_slot_wait, dbg_mem_wr_perf;
  wire [NA*NA-1:0] dbg_slot_waiting;
  wire [NA*2-1:0] dbg_slot_gk;
  wire [NA*LB-1:0] dbg_slot_data;
  wire [sf_coherence_pkg::DE_W-1:0] dbg_dir_err;
  wire [NA*sf_coherence_pkg::AE_W-1:0] dbg_agent_err;
  wire [sf_coherence_pkg::PD_N*32-1:0] perf_dir;
  wire [NA*sf_coherence_pkg::PA_N*32-1:0] perf_agent;
  wire [NA*2-1:0] dbg_a_st;
  wire [NA*CS*2-1:0] dbg_cs_all;
  wire [NA*CS*1-1:0] dbg_tag_all;
  wire [NA*CS*LB-1:0] dbg_data_all;
  wire [NA*3-1:0] dbg_p_st;
  wire [NA*1-1:0] dbg_p_line;
  wire [NA-1:0]   dbg_p_lost;
  wire [NA*LB-1:0] dbg_p_data;
  wire [NA-1:0]   ev_perf_v, ev_perf_wr;
  wire [NA*1-1:0] ev_perf_line;
  wire [NA*1-1:0] ev_perf_word;
  wire [NA*32-1:0] ev_perf_rdata;
  wire [NA*LB-1:0] ev_perf_newline, ev_perf_oldline;
  wire [NA-1:0]   mon_req_hs, mon_rsp_hs, mon_snp_hs, mon_gnt_hs;
  wire [6*NA-1:0] dbg_chan;

  sf_coherence_subsystem #(.N_AGENTS(NA), .DIR_LINES(DL), .CACHE_SETS(CS), .LINE_BYTES(LBY), .COH_BASE(BASE)) dut (
    .clk(clk), .rst_n(rst_n),
    .cpu_req_valid(cpu_req_valid), .cpu_req_ready(cpu_req_ready), .cpu_op(cpu_op), .cpu_addr(cpu_addr),
    .cpu_wdata(cpu_wdata), .cpu_wstrb(cpu_wstrb), .cpu_rsp_valid(cpu_rsp_valid), .cpu_rsp_ready(cpu_rsp_ready),
    .cpu_rdata(cpu_rdata), .cpu_rsp_err(cpu_rsp_err),
    .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready), .mem_req_wr(mem_req_wr),
    .mem_req_line(mem_req_line), .mem_req_wdata(mem_req_wdata),
    .mem_rsp_valid(mem_rsp_valid), .mem_rsp_ready(mem_rsp_ready), .mem_rsp_rdata(mrsp_d),
    .chan_allow_req(allow_req), .chan_allow_rsp(allow_rsp), .chan_allow_snp(allow_snp), .chan_allow_gnt(allow_gnt),
    .dbg_dir(dbg_dir), .dbg_slot_state(dbg_slot_state), .dbg_slot_line(dbg_slot_line), .dbg_slot_type(dbg_slot_type),
    .dbg_slot_busy(dbg_slot_busy), .dbg_slot_waiting(dbg_slot_waiting), .dbg_slot_gtype(dbg_slot_gtype),
    .dbg_slot_gk(dbg_slot_gk), .dbg_slot_data(dbg_slot_data), .dbg_slot_wait(dbg_slot_wait),
    .dbg_mem_wr_perf(dbg_mem_wr_perf), .dbg_dir_err(dbg_dir_err), .dbg_agent_err(dbg_agent_err),
    .perf_dir(perf_dir), .perf_agent(perf_agent),
    .dbg_a_st(dbg_a_st), .dbg_cs_all(dbg_cs_all), .dbg_tag_all(dbg_tag_all), .dbg_data_all(dbg_data_all),
    .dbg_p_st(dbg_p_st), .dbg_p_line(dbg_p_line), .dbg_p_lost(dbg_p_lost), .dbg_p_data(dbg_p_data),
    .ev_perf_v(ev_perf_v), .ev_perf_wr(ev_perf_wr), .ev_perf_line(ev_perf_line), .ev_perf_word(ev_perf_word),
    .ev_perf_rdata(ev_perf_rdata), .ev_perf_newline(ev_perf_newline), .ev_perf_oldline(ev_perf_oldline),
    .mon_req_hs(mon_req_hs), .mon_rsp_hs(mon_rsp_hs), .mon_snp_hs(mon_snp_hs), .mon_gnt_hs(mon_gnt_hs), .dbg_chan(dbg_chan)
  );

  // ---------------- memory: one outstanding operation, response held until `mem_go`
  always @(posedge clk) begin
    if (!rst_n) mrsp_v <= 1'b0;
    else if (mem_req_valid && mem_req_ready) begin
      mrsp_v <= 1'b1;
      if (mem_req_wr) begin
        if (mem_req_line == 1'b0) mw0 <= mem_req_wdata; else mw1 <= mem_req_wdata;
      end else mrsp_d <= (mem_req_line == 1'b0) ? mw0 : mw1;
    end else if (mrsp_v && mem_go) mrsp_v <= 1'b0;
  end

`ifndef FV_NOCHK
  // ---------------- properties
  wire [31:0] e0, e1, e2, e3, e4, e5, e6, e7;
  sf_coh_checker #(.N_AGENTS(NA), .DIR_LINES(DL), .CACHE_SETS(CS), .LINE_BYTES(LBY), .COH_BASE(BASE)) chk (
    .clk(clk), .rst_n(rst_n), .enable(1'b1),
    .cpu_req_valid(cpu_req_valid), .cpu_req_ready(cpu_req_ready), .cpu_op(cpu_op), .cpu_addr(cpu_addr),
    .cpu_wdata(cpu_wdata), .cpu_wstrb(cpu_wstrb), .cpu_rsp_valid(cpu_rsp_valid), .cpu_rsp_ready(cpu_rsp_ready),
    .cpu_rdata(cpu_rdata), .cpu_rsp_err(cpu_rsp_err),
    .ev_perf_v(ev_perf_v), .ev_perf_wr(ev_perf_wr), .ev_perf_line(ev_perf_line), .ev_perf_word(ev_perf_word),
    .ev_perf_rdata(ev_perf_rdata), .ev_perf_newline(ev_perf_newline), .ev_perf_oldline(ev_perf_oldline),
    .dbg_cs_all(dbg_cs_all), .dbg_tag_all(dbg_tag_all), .dbg_data_all(dbg_data_all), .dbg_p_st(dbg_p_st),
    .dbg_p_line(dbg_p_line), .dbg_p_lost(dbg_p_lost), .dbg_p_data(dbg_p_data),
    .dbg_dir(dbg_dir), .dbg_slot_state(dbg_slot_state), .dbg_slot_line(dbg_slot_line), .dbg_slot_busy(dbg_slot_busy),
    .dbg_slot_waiting(dbg_slot_waiting), .dbg_slot_gtype(dbg_slot_gtype), .dbg_slot_data(dbg_slot_data),
    .mon_gnt_hs(mon_gnt_hs),
    .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready), .mem_req_wr(mem_req_wr), .mem_req_line(mem_req_line),
    .mem_req_wdata(mem_req_wdata), .mem_flat({mw1, mw0}),
    .dir_err(dbg_dir_err), .agent_err(dbg_agent_err),
    .err_cnt(e0), .n_load(e1), .n_store(e2), .n_amo(e3), .n_flush(e4), .n_grants(e5), .n_memwr(e6), .n_quiescent_line_checks(e7)
  );
`endif
endmodule

`default_nettype wire


// ----------------------------------------------------------------------------------------------------------------
// FREE-INPUT harness: any operation, any time (valid may drop), any stall pattern.  Reset low in step 0 only.
// ----------------------------------------------------------------------------------------------------------------
module sf_coh_fv_top (
  input  wire        clk,
  input  wire [1:0]  cpu_req_valid,
  input  wire [5:0]  cpu_op,
  input  wire [63:0] cpu_addr,
  input  wire [63:0] cpu_wdata,
  input  wire [7:0]  cpu_wstrb,
  input  wire [1:0]  cpu_rsp_ready,
  input  wire [1:0]  allow_req, allow_rsp, allow_snp, allow_gnt,
  input  wire        mem_rdy,
  input  wire        mem_go
);
  localparam [31:0] BASE = 32'h8000_0000;
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;
  integer a;
  always @* begin
    for (a = 0; a < 2; a = a + 1) begin
      assume(cpu_op[a*3 +: 3] <= sf_coherence_pkg::OP_FENCE);
      assume(cpu_addr[a*32 +: 32] >= BASE);
      assume(cpu_addr[a*32 +: 32] <  BASE + 8);
      assume(cpu_addr[a*32 +: 2] == 2'b00);
    end
  end
  wire [1:0] rdy, rv;
  sf_coh_fv_core core (.clk(clk), .rst_n(rst_n), .cpu_req_valid(cpu_req_valid), .cpu_op(cpu_op), .cpu_addr(cpu_addr),
    .cpu_wdata(cpu_wdata), .cpu_wstrb(cpu_wstrb), .cpu_rsp_ready(cpu_rsp_ready), .allow_req(allow_req), .allow_rsp(allow_rsp),
    .allow_snp(allow_snp), .allow_gnt(allow_gnt), .mem_rdy(mem_rdy), .mem_go(mem_go), .cpu_req_ready(rdy), .cpu_rsp_valid(rv));
endmodule

// ----------------------------------------------------------------------------------------------------------------
// PROGRAMMED harness: each agent runs a K-operation program whose operations are chosen by the SOLVER (held constant for
// the whole run), so one proof run covers every pair of programs of length K over {LOAD, STORE, AMO, FLUSH} x {line 0, 1},
// under every stall pattern (channels, memory, CPU response) up to the BMC depth.  This reaches the deep race scenarios
// (eviction crossing an intervention, upgrade crossing an invalidation, ownership transfer) that a free-input run of the same
// depth cannot.
// ----------------------------------------------------------------------------------------------------------------
module sf_coh_fv_prog #(parameter int K = 3) (
  input  wire        clk,
  input  wire [1:0]  cpu_rsp_ready,
  input  wire [1:0]  allow_req, allow_rsp, allow_snp, allow_gnt,
  input  wire        mem_rdy,
  input  wire        mem_go,
  input  wire [K*3-1:0] prog0,       // per op: {type[1:0], line}   (free input, assumed constant)
  input  wire [K*3-1:0] prog1
);
  localparam [31:0] BASE = 32'h8000_0000;
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;
  reg [K*3-1:0] p0_q, p1_q;
  always @(posedge clk) begin p0_q <= prog0; p1_q <= prog1; end
  always @* if (!init) begin assume(prog0 == p0_q); assume(prog1 == p1_q); end

  reg [3:0] pc0, pc1;                 // next operation index of each agent
  wire [1:0] rdy, rv;
  wire v0 = (pc0 < K) && !init;
  wire v1 = (pc1 < K) && !init;
  wire [2:0] e0 = prog0[pc0*3 +: 3];
  wire [2:0] e1 = prog1[pc1*3 +: 3];
  // type 0 LOAD, 1 STORE, 2 AMO, 3 FLUSH ; distinct data per (agent, op index)
  wire [2:0] op0 = (e0[2:1] == 2'd0) ? sf_coherence_pkg::OP_LOAD : (e0[2:1] == 2'd1) ? sf_coherence_pkg::OP_STORE :
                   (e0[2:1] == 2'd2) ? sf_coherence_pkg::OP_AMO  : sf_coherence_pkg::OP_FLUSH;
  wire [2:0] op1 = (e1[2:1] == 2'd0) ? sf_coherence_pkg::OP_LOAD : (e1[2:1] == 2'd1) ? sf_coherence_pkg::OP_STORE :
                   (e1[2:1] == 2'd2) ? sf_coherence_pkg::OP_AMO  : sf_coherence_pkg::OP_FLUSH;
  wire [31:0] ad0 = BASE + {29'd0, e0[0], 2'b00};
  wire [31:0] ad1 = BASE + {29'd0, e1[0], 2'b00};
  wire [31:0] wd0 = 32'h0000_0010 + {28'd0, pc0};
  wire [31:0] wd1 = 32'h0000_0020 + {28'd0, pc1};
  always @(posedge clk) begin
    if (!rst_n) begin pc0 <= 4'd0; pc1 <= 4'd0; end
    else begin
      if (v0 && rdy[0]) pc0 <= pc0 + 4'd1;
      if (v1 && rdy[1]) pc1 <= pc1 + 4'd1;
    end
  end
  sf_coh_fv_core core (.clk(clk), .rst_n(rst_n), .cpu_req_valid({v1, v0}), .cpu_op({op1, op0}), .cpu_addr({ad1, ad0}),
    .cpu_wdata({wd1, wd0}), .cpu_wstrb(8'hFF), .cpu_rsp_ready(cpu_rsp_ready), .allow_req(allow_req), .allow_rsp(allow_rsp),
    .allow_snp(allow_snp), .allow_gnt(allow_gnt), .mem_rdy(mem_rdy), .mem_go(mem_go), .cpu_req_ready(rdy), .cpu_rsp_valid(rv));
endmodule

// ----------------------------------------------------------------------------------------------------------------
// BOUNDED-LATENCY (progress) harness.  Environment fairness F1 is made precise and finite: no handshake enable of the
// environment (4 coherence channels x 2 agents, memory ready, memory response, CPU response ready) stays low for more than
// S consecutive cycles.  Property: an operation accepted on a CPU port presents its response within LIMIT cycles, whatever
// the other agent does.  A proof (PDR) is unbounded in time: it says progress holds in EVERY execution of the 2-agent, 2-line
// configuration under that fairness bound.  A counterexample would be a livelock / deadlock / starvation scenario.
// ----------------------------------------------------------------------------------------------------------------
module sf_coh_fv_live #(parameter int S = 1, parameter int LIMIT = 100) (
  input  wire        clk,
  input  wire [1:0]  cpu_req_valid,
  input  wire [5:0]  cpu_op,
  input  wire [63:0] cpu_addr,
  input  wire [63:0] cpu_wdata,
  input  wire [7:0]  cpu_wstrb,
  input  wire [1:0]  cpu_rsp_ready,
  input  wire [1:0]  allow_req, allow_rsp, allow_snp, allow_gnt,
  input  wire        mem_rdy,
  input  wire        mem_go
);
  localparam [31:0] BASE = 32'h8000_0000;
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;
  integer a;
  always @* begin
    for (a = 0; a < 2; a = a + 1) begin
      assume(cpu_op[a*3 +: 3] <= sf_coherence_pkg::OP_FENCE);
      assume(cpu_addr[a*32 +: 32] >= BASE);
      assume(cpu_addr[a*32 +: 32] <  BASE + 8);
      assume(cpu_addr[a*32 +: 2] == 2'b00);
    end
  end
  wire [1:0] rdy, rv;
  (* keep *) wire [5:0] t_slot_state; (* keep *) wire [1:0] t_slot_line; (* keep *) wire [3:0] t_a_st; (* keep *) wire [5:0] t_p_st;
  (* keep *) wire [11:0] t_chan; (* keep *) wire [1:0] t_p_line; (* keep *) wire [9:0] t_dir; (* keep *) wire [1:0] t_wait, t_busy, t_mreq, t_mrsp, t_msnp, t_mgnt;
  sf_coh_fv_core core (.clk(clk), .rst_n(rst_n), .cpu_req_valid(cpu_req_valid), .cpu_op(cpu_op), .cpu_addr(cpu_addr),
    .cpu_wdata(cpu_wdata), .cpu_wstrb(cpu_wstrb), .cpu_rsp_ready(cpu_rsp_ready), .allow_req(allow_req), .allow_rsp(allow_rsp),
    .allow_snp(allow_snp), .allow_gnt(allow_gnt), .mem_rdy(mem_rdy), .mem_go(mem_go), .cpu_req_ready(rdy), .cpu_rsp_valid(rv),
    .x_slot_state(t_slot_state), .x_slot_line(t_slot_line), .x_a_st(t_a_st), .x_p_st(t_p_st), .x_p_line(t_p_line), .x_dir(t_dir),
    .x_slot_wait(t_wait), .x_slot_busy(t_busy), .x_mon_req(t_mreq), .x_mon_rsp(t_mrsp), .x_mon_snp(t_msnp), .x_mon_gnt(t_mgnt), .x_chan(t_chan));

  // fairness: at most S consecutive low cycles on every environment enable
  wire [9:0] en = {allow_req, allow_rsp, allow_snp, allow_gnt, mem_rdy, mem_go};
  // one counter per enable (generate, no shared loop variable): consecutive cycles the enable has been low
  genvar gk;
  generate
    for (gk = 0; gk < 10; gk = gk + 1) begin : g_fair
      reg [1:0] run;
      always @(posedge clk) begin
        if (init || en[gk]) run <= 2'd0;
        else if (run != 2'd3) run <= run + 2'd1;
      end
      always @* assume(init || !(run >= S && !en[gk]));
    end
  endgenerate

  // watchdog: cycles from acceptance of an operation to its response being presented
  reg [7:0] wd0, wd1;
  reg       op0, op1;
  always @(posedge clk) begin
    if (!rst_n) begin wd0 <= 8'd0; wd1 <= 8'd0; op0 <= 1'b0; op1 <= 1'b0; end
    else begin
      if (cpu_req_valid[0] && rdy[0]) begin op0 <= 1'b1; wd0 <= 8'd0; end
      else if (rv[0]) op0 <= 1'b0;
      else if (op0 && wd0 != 8'hFF) wd0 <= wd0 + 8'd1;
      if (cpu_req_valid[1] && rdy[1]) begin op1 <= 1'b1; wd1 <= 8'd0; end
      else if (rv[1]) op1 <= 1'b0;
      else if (op1 && wd1 != 8'hFF) wd1 <= wd1 + 8'd1;
    end
  end
  always @* begin
    assert(init || !(op0 && wd0 > LIMIT));
    assert(init || !(op1 && wd1 > LIMIT));
  end
endmodule
