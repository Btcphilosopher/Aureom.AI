#!/bin/bash
# SilicaFlux P107 formal runner.  Engine: Yosys 0.33 built-in SAT (bit-blasted netlist, MiniSat).  SymbiYosys is not installed
# in the build environment; formal/sf_coherence.sby holds the equivalent SymbiYosys job for users who have it.
#   formal/run_formal.sh bmc <depth>        bounded model check from reset, every assertion at every step 1..depth
#   formal/run_formal.sh ind <maxk>         k-induction (base case + step), k = 1..maxk
# NOTE: `sat` ignores $assume cells unless -set-assumes is given; it is set here (ABC/PDR reads $assume as constraints natively).
# Environment: FV_TOP (default sf_coh_fv_top; sf_coh_fv_prog = solver-chosen K-op programs), FV_CHPARAM 'K 3' (program length), FV_SRC (extra sources), FV_DEFS (extra -D defines, e.g. -DMUT_x), FV_TIMEOUT (s)
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
MODE=${1:-bmc}; N=${2:-12}
OUT=$ROOT/build/formal; mkdir -p $OUT
RTL="${FV_RTL:-$ROOT/rtl/coherence}"
SRC=${FV_SRC:-"$ROOT/tb/sf_coh_checker.sv $ROOT/formal/sf_coh_fv_top.sv"}
TOP=${FV_TOP:-sf_coh_fv_top}
TMO=${FV_TIMEOUT:-3000}
cat > $OUT/run_$$.ys <<YS
read_verilog -sv -formal -DFORMAL ${FV_DEFS:-} $RTL/sf_coherence_pkg.sv $RTL/sf_coherence_sharers.sv $RTL/sf_coherence_transient_fsm.sv $RTL/sf_coherence_directory.sv $RTL/sf_coherence_agent_adapter.sv $RTL/sf_coherence_subsystem.sv $SRC
${FV_CHPARAM:+hierarchy -top $TOP; chparam -set $FV_CHPARAM $TOP}
prep -top $TOP
flatten
memory_map
async2sync
dffunmap
opt_clean -purge
YS
if [ "$MODE" = bmc ]; then
  echo "sat -verify -prove-asserts -set-assumes -seq $N -set-at 1 init 1 -timeout $TMO ${FV_VCD:+-dump_vcd $FV_VCD} ${FV_SHOW:-}" >> $OUT/run_$$.ys
else
  echo "sat -verify -prove-asserts -set-assumes -tempinduct -maxsteps $N -set-at 1 init 1 -timeout $TMO" >> $OUT/run_$$.ys
fi
START=$(date +%s)
set +e
LOG=$OUT/log_$$.txt
yosys -l $LOG $OUT/run_$$.ys > /dev/null 2>&1
RC=$?
set -e
END=$(date +%s)
VERDICT=$(grep -E "SAT proof finished|Temporal induction|QED|FAIL|failed|ERROR|Timeout|timeout" $LOG | grep -v "Import proof" | tail -3 | tr '\n' '|')
echo "mode=$MODE n=$N top=$TOP rc=$RC time=$((END-START))s verdict: $VERDICT"
cp $LOG $OUT/last_${TOP}_${MODE}_${N}.log; rm -f $OUT/run_$$.ys $LOG
exit $RC
