# Simulation mutation sensitivity

Each row injects one bug into a copy of the RTL and runs the quick regression (QUICK=1, 20 % stalls).
KILLED = the environment reports a failure.

| mutant | what it breaks | result | first failure reported |
|---|---|---|---|
| `grant_before_acks` | ownership / data granted before the invalidation acknowledgements arrived | **KILLED** | `CHECKER FAIL 31=31 t=0 : dir_err == {sf_coherence_pkg::DE_W{1'b0}}` |
| `stale_putm_writes_memory` | a stale PUTM (lost the race) overwrites memory with old data | **KILLED** | `TB FAIL @17115000 : forced race did not produce a stale PUTM` |
| `no_inv_on_getm` | exclusive request from a shared line sends no invalidations | **KILLED** | `CHECKER FAIL 28=28 t=0 : !s_a` |
| `no_inv_on_upgrade` | upgrade granted without invalidating the other sharers | **KILLED** | `CHECKER FAIL 28=28 t=0 : !s_a` |
| `intervention_not_written_to_memory` | dirty data forwarded to the reader but memory left stale | **KILLED** | `CHECKER FAIL 23=23 t=0 : mem_flat[L*LB +: LB] == gold[L*LB +: LB]` |
| `ignore_keep_bit` | directory keeps a former owner (that evicted) as a sharer: inexact sharer vector | **KILLED** | `CHECKER FAIL 22=22 t=0 : e_sh == holders && hm == {N_AGENTS{1'b0}} && e_sh != {N_AGENTS{1'b0}}` |
| `owner_data_dropped` | owner data response not captured: requester gets a stale buffer | **KILLED** | `TB FAIL @1455000 : reader observes the write` |
| `stale_put_commits` | a stale PUTM erases the (new) owner from the directory | **KILLED** | `CHECKER FAIL 20=20 t=0 : holders == {N_AGENTS{1'b0}} && e_sh == {N_AGENTS{1'b0}}` |
| `no_completion_wait` | transaction closed at grant: no unblock, entry never committed | **KILLED** | `CHECKER FAIL 20=20 t=0 : holders == {N_AGENTS{1'b0}} && e_sh == {N_AGENTS{1'b0}}` |
| `conflict_check_off` | two transactions on the same line at once (no per-line serialisation) | **KILLED** | `CHECKER FAIL 19=19 t=0 : nbusy <= 1` |
| `fwd_s_keeps_modified` | owner does not downgrade on a shared intervention: two copies, one Modified | **KILLED** | `CHECKER FAIL 27=27 t=0 : !m_a` |
| `inv_ignored_by_sharer` | sharer acknowledges the invalidation but keeps its copy: stale data later | **KILLED** | `CHECKER FAIL 28=28 t=0 : !s_a` |
| `putack_not_consumed` | eviction record never cleared: agent hangs | **KILLED** | `CHECKER FAIL 22=22 t=0 : e_sh == holders && hm == {N_AGENTS{1'b0}} && e_sh != {N_AGENTS{1'b0}}` |
| `eviction_buffer_ignores_fwd` | writeback race: owner mid-eviction cannot answer the intervention | **KILLED** | `CHECKER FAIL 32=32 t=0 : agent_err == {N_AGENTS*sf_coherence_pkg::AE_W{1'b0}}` |
| `amo_is_store` | AMO fetch-add replaced by a plain store (lost updates) | **KILLED** | `CHECKER FAIL 10=10 t=0 : ev_perf_newline[a*LB +: LB] == nl` |
| `strobes_ignored` | byte strobes ignored on stores | **KILLED** | `CHECKER FAIL 10=10 t=0 : ev_perf_newline[a*LB +: LB] == nl` |
| `upg_hit_skips_request` | store to a Shared line performed locally without an upgrade (no invalidation of other sharers) | **KILLED** | `CHECKER FAIL 9=9 t=0 : ev_perf_oldline[a*LB +: LB] == ol` |

**17 / 17 mutants killed.**
