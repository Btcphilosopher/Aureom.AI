| mutant | what it breaks | property set | PDR result | wall time |
|---|---|---|---|---|
| `grant_before_acks` | ownership / data granted before the invalidation acknowledgements arrived | nodata | **COUNTEREXAMPLE** (property violated at depth 19) | 66 s |
| `no_inv_on_getm` | exclusive request from a shared line sends no invalidations | nodata | **COUNTEREXAMPLE** (property violated at depth 17) | 77 s |
| `no_inv_on_upgrade` | upgrade granted without invalidating the other sharers | nodata | **COUNTEREXAMPLE** (property violated at depth 26) | 86 s |
| `ignore_keep_bit` | directory keeps a former owner (that evicted) as a sharer: inexact sharer vector | nodata | **COUNTEREXAMPLE** (property violated at depth 22) | 91 s |
| `stale_put_commits` | a stale PUTM erases the (new) owner from the directory | nodata | **COUNTEREXAMPLE** (property violated at depth 28) | 108 s |
| `no_completion_wait` | transaction closed at grant: no unblock, entry never committed | nodata | **COUNTEREXAMPLE** (property violated at depth 11) | 60 s |
| `conflict_check_off` | two transactions on the same line at once (no per-line serialisation) | nodata | **COUNTEREXAMPLE** (property violated at depth 7) | 64 s |
| `fwd_s_keeps_modified` | owner does not downgrade on a shared intervention: two copies, one Modified | nodata | **COUNTEREXAMPLE** (property violated at depth 33) | 93 s |
| `inv_ignored_by_sharer` | sharer acknowledges the invalidation but keeps its copy: stale data later | nodata | **COUNTEREXAMPLE** (property violated at depth 19) | 80 s |
| `putack_not_consumed` | eviction record never cleared: agent hangs | nodata | **COUNTEREXAMPLE** (property violated at depth 17) | 84 s |
| `eviction_buffer_ignores_fwd` | writeback race: owner mid-eviction cannot answer the intervention | nodata | **COUNTEREXAMPLE** (property violated at depth 15) | 79 s |
| `amo_is_store` | AMO fetch-add replaced by a plain store (lost updates) | full | **COUNTEREXAMPLE** (property violated at depth 10) | 67 s |
| `strobes_ignored` | byte strobes ignored on stores | full | **COUNTEREXAMPLE** (property violated at depth 10) | 66 s |
| `upg_hit_skips_request` | store to a Shared line performed locally without an upgrade (no invalidation of other sharers) | full | **COUNTEREXAMPLE** (property violated at depth 18) | 97 s |
| `owner_data_dropped` | owner data response not captured: requester gets a stale buffer | full | **COUNTEREXAMPLE** (property violated at depth 17) | 213 s |
| `stale_putm_writes_memory` | a stale PUTM (lost the race) overwrites memory with old data | full | **COUNTEREXAMPLE** (property violated at depth 24) | 541 s |
| `intervention_not_written_to_memory` | dirty data forwarded to the reader but memory left stale | full | **COUNTEREXAMPLE** (property violated at depth 19) | 142 s |
