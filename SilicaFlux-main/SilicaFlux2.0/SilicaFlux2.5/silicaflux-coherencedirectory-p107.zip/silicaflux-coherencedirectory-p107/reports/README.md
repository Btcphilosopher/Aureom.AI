# reports/ — raw evidence (each file is produced by a script in `scripts/` or `formal/`)

| file | produced by | what it is |
|---|---|---|
| `lint.log` | `scripts/run_all.sh` / chain | Verilator `-Wall` lint of the RTL (rc 0 = clean) |
| `regression_directed.log` | `tb/tb_sf_coherence.sv` (Icarus) | T01–T16 directed / random system tests, litmus histogram, non-coherent negative control |
| `sweep.csv`, `sweep.log` | `scripts/run_sweep.py` | 38 configurations × seeds, stall / latency / geometry sweep |
| `rand_campaign.csv`, `rand_campaign.log` | `scripts/run_rand_campaign.py` | 240 Verilator random runs with mid-flight resets, 6 geometries |
| `mutants_sim.md`, `mutants_sim.log` | `scripts/run_mutants.py` | 17 injected RTL bugs, all must be killed by the simulation environment |
| `model.log` | `scripts/run_model.sh` | protocol model exhaustive exploration + 6 protocol mutants |
| `latency.csv` | `tb/tb_sf_coherence_lat.sv` | single-operation latencies |
| `yosys_stats.csv` | `scripts/yosys_stats.sh` | generic-cell synthesis statistics (no area / timing claim) |
| `frozen_sources.md5` | – | checksums of the RTL / checker / formal harness the final formal runs used |
| `fv_pdr_final_full.log`, `fv_pdr_final_nodata.log` | `formal/run_pdr.sh` | **unbounded** PDR proofs on the frozen sources (all properties / structural properties) |
| `fv_pdr_full.log`, `fv_pdr_nodata.log` | same | earlier identical runs (before two non-functional edits: a counter loop variable and a debug port) |
| `mutants_pdr.md`, `mutants_pdr_final.log` | `scripts/run_pdr_mutants.py` | formal sensitivity: PDR finds a counterexample for each of the 17 bugs |
| `fv_bmc14_assume.log`, `fv_ind5_assume.log` | `formal/run_formal.sh` | bounded model check depth 14 and plain k-induction (fails at k ≤ 5), with the assumptions enabled; `fv_bmc.log`, `fv_ind5.log` are the first runs, made without `-set-assumes` (a superset of the environments) |
| `fv_bmc_live*`, `fv_pdr_live*` | `formal/run_formal.sh`, `formal/run_pdr.sh` | bounded-latency (progress) experiments; see docs/07 §5 for how to read them |
| `*_n3.log`, `model_n3.log` | model | 3-agent exhaustive runs |
