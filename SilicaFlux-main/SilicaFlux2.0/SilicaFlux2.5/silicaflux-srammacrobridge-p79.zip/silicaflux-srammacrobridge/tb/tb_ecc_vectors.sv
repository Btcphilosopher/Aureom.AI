// =============================================================================
// SilicaFlux SRAMMacroBridge :: tb_ecc_vectors
// Module-level check of sf_ecc_secded_enc / _dec against the independent Python golden model (tools/ecc_ref.py).
// Vector record (hex, bit-exact packed, MSB first): {kind[3:0], data_in, check_in, data_out, corrected, uncorrectable}
//   kind 0 clean, 1 single-bit flip, 2 double-bit flip.  The encoder is checked on every record's CLEAN data (kind 0).
// Run per K:  iverilog -P tb_ecc_vectors.K=32 ...   (scripts/run_sim.py suite 'ecc')
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_macro_defs.svh"
module tb_ecc_vectors;
  parameter int K = 32;
  parameter     VEC = "tb/vectors/ecc_vec_k32.mem";
  localparam int R = `SF_ECC_R(K);
  reg [3:0]   kind;
  reg [K-1:0] di, dexp;
  reg [R-1:0] ci;
  reg         cexp, uexp;
  wire [R-1:0] c_enc;
  wire [K-1:0] d_out;
  wire         cor, unc;
  sf_ecc_secded_enc #(.K(K)) u_enc (.data(di), .check(c_enc));
  sf_ecc_secded_dec #(.K(K)) u_dec (.data_in(di), .check_in(ci), .data_out(d_out), .corrected(cor), .uncorrectable(unc));

  // one record = 4+K+R+K+2 bits: {kind[3:0], di, ci, dexp, cexp, uexp}
  reg [4+K+R+K+2-1:0] mem [0:4095];
  integer n, i, errs, enc_checks, dec_checks, nsingle, ndouble;
  reg [R-1:0] chk_clean;
  initial begin
    errs = 0; enc_checks = 0; dec_checks = 0; nsingle = 0; ndouble = 0;
    n = 0;
    $readmemh(VEC, mem);
    for (i = 0; i < 4096; i = i + 1) if (^mem[i] !== 1'bx) n = i + 1;
    for (i = 0; i < n; i = i + 1) begin
      {kind, di, ci, dexp, cexp, uexp} = mem[i];
      #1;
      if (kind == 0) begin
        // clean record: encoder output must equal the golden check bits stored in ci
        if (c_enc !== ci) begin errs = errs + 1; $display("ENC MISMATCH K=%0d rec %0d data=%h got=%h exp=%h", K, i, di, c_enc, ci); end
        enc_checks = enc_checks + 1;
      end
      if (d_out !== dexp || cor !== cexp || unc !== uexp) begin
        errs = errs + 1;
        $display("DEC MISMATCH K=%0d rec %0d kind=%0d in=%h/%h got=%h c=%b u=%b exp=%h c=%b u=%b", K, i, kind, di, ci, d_out, cor, unc, dexp, cexp, uexp);
      end
      dec_checks = dec_checks + 1;
      if (kind == 1) nsingle = nsingle + 1;
      if (kind == 2) ndouble = ndouble + 1;
    end
    $display("SF_TB_RESULT: %s ecc_vectors K=%0d R=%0d records=%0d enc_checks=%0d dec_checks=%0d singles=%0d doubles=%0d errors=%0d",
             (errs == 0 && n > 0) ? "PASS" : "FAIL", K, R, n, enc_checks, dec_checks, nsingle, ndouble, errs);
    $finish;
  end
endmodule
