// =============================================================================
// SilicaFlux SRAMMacroBridge :: tb_macro   -- self-checking testbench for sf_sram_macro_wrapper (any backend)
//
// One testbench, every backend: the SAME stimulus (seeded xorshift, identical in Icarus and Verilator) is applied to
// GENERIC / FPGA / ASIC-macro configurations and the response trace hash (SF_TB_TRACE) must be identical across them.
//
// Phases
//   P1  directed: read-after-write next cycle, write-after-read returns old data, back-to-back accesses
//   P2  byte enables (BYTE_ENABLE=1): every single lane, walking masks, zero mask, untouched-lane preservation
//   P3  full-array initialisation (unwritten SRAM is never assumed to be zero)
//   P4  random traffic (idle/read/write mix, RAW/WAR hazards, random masks) against the reference model, exact latency
//   P5  test port (TEST_MODE=1): hand-over rule, RAW array read-back, March C- over the raw physical words
//   P6  ECC (ECC_MODE!=0, TEST_MODE=1): every single-bit flip of the stored word is corrected and flagged, double flips
//       (same lane) detected and flagged, flips in different lanes corrected; array restored afterwards
//   P7  power (POWER_CTRL=1): sleep blocks nothing in flight, retention across sleep, wake latency
//   Timing semantics are checked every cycle: rd_vld exactly READ_LATENCY after the read edge, rdata only then, ECC flags
//   only then; with SF_MACRO_POISON (4-state) rdata must be X whenever rd_vld=0 (output is NOT held).
//
// Stimulus is driven 2 ns after each rising edge and sampled at the next rising edge (before NBAs), like a flop.
// Result line:  SF_TB_RESULT: PASS|FAIL <config> checks=N errors=E trace=<hash>
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_macro_defs.svh"
`include "sf_sram_macro_ids.svh"
`include "sf_sram_macro_funcs.svh"

module tb_macro;
  parameter int DATA_WIDTH     = 32;
  parameter int DEPTH_WORDS    = 1024;
  parameter int READ_LATENCY   = 1;
  parameter int BYTE_ENABLE    = 1;
  parameter int BYTE_WIDTH     = 8;
  parameter int MEMORY_TECH    = 0;
  parameter int MACRO_ID       = 0;
  parameter int ECC_MODE       = 0;
  parameter int TEST_MODE      = 0;
  parameter int POWER_CTRL     = 0;
  parameter int WAKE_CYCLES    = 2;
  parameter int FPGA_RAM_STYLE = 0;
  parameter int NCYC           = 4000;    // random-traffic cycles
  parameter int SEED           = 1;
  parameter int PERIOD         = 20;      // ns; >= 2 x (SKY130 model DELAY 3 ns + margin)
  parameter int POISON         = 0;       // 1: expect X on rdata/tst_rdata outside the valid slot (4-state, SF_MACRO_POISON)
  parameter int MARCH_ADDRS    = 0;       // 0: whole array; else only the first MARCH_ADDRS words (large arrays)
  parameter int NEG_TEST       = 0;       // 1 (needs TEST_MODE=1, 4-state simulator): P8 presents accesses inside the 2-cycle hand-over window
                                          //   on purpose; the wrapper must DROP them and raise SF_MACRO_ASSERT_HANDOVER exactly 4 times

  localparam int LANES = (BYTE_ENABLE != 0) ? DATA_WIDTH / BYTE_WIDTH : 1;
  localparam int LANE_W = (BYTE_ENABLE != 0) ? BYTE_WIDTH : DATA_WIDTH;
  localparam int ECC_R = (ECC_MODE == 0) ? 0 : `SF_ECC_R(LANE_W);
  localparam int PLW = LANE_W + ECC_R;
  localparam int PW = LANES * PLW;
  localparam int IDXW = $clog2(DEPTH_WORDS);
  localparam int DW = LANES * LANE_W;
  localparam int L = READ_LATENCY;

  // ------------------------------------------------------------------ DUT
  reg clk = 1'b0;
  reg ce = 1'b0, we = 1'b0;
  reg [LANES-1:0] wmask = {LANES{1'b1}};
  reg [IDXW-1:0] idx = {IDXW{1'b0}};
  reg [DW-1:0] wdata = {DW{1'b0}};
  wire [DW-1:0] rdata;
  wire rd_vld, ecc_corrected, ecc_uncorrectable;
  reg tst_active = 1'b0, tst_ce = 1'b0, tst_we = 1'b0;
  reg [IDXW-1:0] tst_idx = {IDXW{1'b0}};
  reg [PW-1:0] tst_wdata = {PW{1'b0}};
  wire [PW-1:0] tst_rdata;
  wire tst_rd_vld;
  reg pwr_sleep = 1'b0;
  wire pwr_active;

  sf_sram_macro_wrapper #(
    .DATA_WIDTH(DATA_WIDTH), .DEPTH_WORDS(DEPTH_WORDS), .READ_LATENCY(READ_LATENCY), .BYTE_ENABLE(BYTE_ENABLE),
    .BYTE_WIDTH(BYTE_WIDTH), .MEMORY_TECH(MEMORY_TECH), .MACRO_ID(MACRO_ID), .ECC_MODE(ECC_MODE), .TEST_MODE(TEST_MODE),
    .POWER_CTRL(POWER_CTRL), .WAKE_CYCLES(WAKE_CYCLES), .FPGA_RAM_STYLE(FPGA_RAM_STYLE)
  ) dut (
    .clk(clk), .ce(ce), .we(we), .wmask(wmask), .idx(idx), .wdata(wdata), .rdata(rdata), .rd_vld(rd_vld),
    .ecc_corrected(ecc_corrected), .ecc_uncorrectable(ecc_uncorrectable),
    .tst_active(tst_active), .tst_ce(tst_ce), .tst_we(tst_we), .tst_idx(tst_idx), .tst_wdata(tst_wdata),
    .tst_rdata(tst_rdata), .tst_rd_vld(tst_rd_vld), .pwr_sleep(pwr_sleep), .pwr_active(pwr_active));

  // GF180MCU vendor-model artefact (simulation only): the model keeps a 100 ps-delayed copy of CEN that stays X unless CEN
  // has CHANGED at least once, so it silently drops the first access to that macro ("CEN is not reset, memory is not
  // operational").  The hardware requirement ("CEN high before the first running cycle") is already met by ce=0 at
  // power-up.  For the simulation, every macro row gets one CEN pulse BEFORE the clock starts (no clock edge, hence no
  // access).  The clock is held until this sequence is done, for every technology (harmless elsewhere).
  localparam int M_WORDS = `SF_MACRO_WORDS(MACRO_ID);
  reg clk_en = 1'b0;
  initial begin : startup
    integer r, nrows;
    nrows = (M_WORDS > 0) ? (DEPTH_WORDS + M_WORDS - 1) / M_WORDS : 1;
    if (MEMORY_TECH == `SF_MEM_TECH_ASIC_GF180MCU) begin
      for (r = 0; r < nrows; r = r + 1) begin
        #0.3 idx = r * M_WORDS;
        #0.3 ce = 1'b1;
        #0.3 ce = 1'b0;
      end
      #0.3 idx = {IDXW{1'b0}};
    end
    #1 clk_en = 1'b1;
  end
  initial begin
    wait (clk_en);
    forever #(PERIOD / 2.0) clk = ~clk;
  end

  // ------------------------------------------------------------------ bookkeeping
  integer errors = 0, checks = 0;
  reg [63:0] trace = 64'hcbf29ce484222325;   // FNV-1a style hash of every VALID response (identical across backends)
  reg [31:0] rs = 32'h1;                      // xorshift32 state
  task automatic rng(output [31:0] r);
    begin
      rs = rs ^ (rs << 13);
      rs = rs ^ (rs >> 17);
      rs = rs ^ (rs << 5);
      r = rs;
    end
  endtask
  task automatic mix(input [63:0] v);
    begin
      trace = (trace ^ v) * 64'h100000001b3;
    end
  endtask
  task automatic mixw(input [1023:0] v, input integer w);       // hash all w bits, 32 at a time
    integer c;
    begin
      for (c = 0; c < (w + 31) / 32; c = c + 1) mix({32'h0, v[c*32 +: 32]});
    end
  endtask
  task automatic err(input [1023:0] what);
    begin
      errors = errors + 1;
      if (errors <= 20) $display("TB ERROR @%0t: %0s", $time, what);
    end
  endtask

  // ------------------------------------------------------------------ reference model
  reg [DW-1:0] ref_mem [0:DEPTH_WORDS-1];
  // expected-response pipelines (stage k = request sampled k edges ago)
  reg            ev [0:L];
  reg [DW-1:0]   ed [0:L];
  reg            ecor [0:L];
  reg            eunc [0:L];
  reg            tev [0:L];
  reg [PW-1:0]   ted [0:L];
  // per-request overrides set by the driver (ECC phases): expected data / flags for the NEXT read request
  reg            ov_en = 1'b0;
  reg [DW-1:0]   ov_data;
  reg            ov_cor = 1'b0, ov_unc = 1'b0;
  reg            t_ov_en = 1'b0;            // test read: expected raw word supplied by the driver
  reg [PW-1:0]   t_ov_data;
  reg            mon_en = 1'b0;
  reg            expect_quiet_drop = 1'b0;  // negative tests (Icarus): the request of this cycle is dropped by the DUT
  integer        k;

  initial begin
    for (k = 0; k <= L; k = k + 1) begin ev[k] = 0; ed[k] = 0; ecor[k] = 0; eunc[k] = 0; tev[k] = 0; ted[k] = 0; end
  end

  // monitor: sample at every rising edge, BEFORE this edge's NBAs (a consumer flop's view)
  always @(posedge clk) if (mon_en) begin
    // shift the expectation pipelines
    for (k = L; k >= 1; k = k - 1) begin
      ev[k] = ev[k-1]; ed[k] = ed[k-1]; ecor[k] = ecor[k-1]; eunc[k] = eunc[k-1];
      tev[k] = tev[k-1]; ted[k] = ted[k-1];
    end
    // --- functional response
    if (rd_vld !== ev[L]) begin
      err("rd_vld does not match the expected read slot (latency/valid)");
      $display("   rd_vld=%b expected=%b", rd_vld, ev[L]);
    end else if (ev[L]) begin
      checks = checks + 1;
      if (rdata !== ed[L]) begin err("rdata mismatch"); $display("   got %h expected %h", rdata, ed[L]); end
      if (ecc_corrected !== ecor[L] || ecc_uncorrectable !== eunc[L]) begin
        err("ECC flags mismatch"); $display("   got cor=%b unc=%b expected cor=%b unc=%b", ecc_corrected, ecc_uncorrectable, ecor[L], eunc[L]);
      end
      mixw({{(1024-DW){1'b0}}, rdata}, DW); mix({63'h0, ecc_corrected}); mix({63'h0, ecc_uncorrectable});
    end else begin
      // not a read slot: no ECC flag may be raised, and with poison enabled rdata must not be held
      if (ecc_corrected !== 1'b0 || ecc_uncorrectable !== 1'b0) err("ECC flag raised outside a read slot");
      if (POISON != 0 && (^rdata) !== 1'bx) err("rdata is held outside the read slot (expected X with SF_MACRO_POISON)");
    end
    // --- test response (raw)
    if (TEST_MODE != 0) begin
      if (tst_rd_vld !== tev[L]) begin
        err("tst_rd_vld does not match the expected test-read slot");
        $display("   tst_rd_vld=%b expected=%b", tst_rd_vld, tev[L]);
      end else if (tev[L]) begin
        checks = checks + 1;
        if (tst_rdata !== ted[L]) begin err("tst_rdata (raw) mismatch"); $display("   got %h expected %h", tst_rdata, ted[L]); end
        mixw({{(1024-PW){1'b0}}, tst_rdata}, PW);
      end else if (POISON != 0 && (^tst_rdata) !== 1'bx) err("tst_rdata is held outside the read slot (expected X with SF_MACRO_POISON)");
    end
    // --- push this cycle's request (the DUT samples the same values at this edge)
    ev[0] = 1'b0; tev[0] = 1'b0; ecor[0] = 1'b0; eunc[0] = 1'b0;
    if (ce && !expect_quiet_drop && pwr_active !== 1'b0 && !tst_active) begin
      if (we) begin
        for (k = 0; k < LANES; k = k + 1)
          if (BYTE_ENABLE == 0 || wmask[k]) ref_mem[idx][k*LANE_W +: LANE_W] = wdata[k*LANE_W +: LANE_W];
      end else begin
        ev[0] = 1'b1;
        ed[0] = ov_en ? ov_data : ref_mem[idx];
        ecor[0] = ov_en ? ov_cor : 1'b0;
        eunc[0] = ov_en ? ov_unc : 1'b0;
        ov_en = 1'b0;
      end
    end
    if (tst_ce && tst_active && !tst_we && !expect_quiet_drop) begin
      tev[0] = 1'b1;
      ted[0] = t_ov_data;
    end
  end

  // ------------------------------------------------------------------ driver tasks (drive 2 ns after the edge)
  task automatic cyc(input c, input w, input [IDXW-1:0] i, input [LANES-1:0] m, input [DW-1:0] d);
    begin
      @(posedge clk); #2;
      ce = c; we = w; idx = i; wmask = m; wdata = d;
    end
  endtask
  task automatic idle(input integer n);
    integer j;
    begin
      for (j = 0; j < n; j = j + 1) begin
        @(posedge clk); #2;
        ce = 1'b0; we = 1'b0; tst_ce = 1'b0; tst_we = 1'b0;
      end
    end
  endtask
  task automatic wr(input [IDXW-1:0] i, input [LANES-1:0] m, input [DW-1:0] d);
    begin cyc(1'b1, 1'b1, i, m, d); end
  endtask
  task automatic rd(input [IDXW-1:0] i);
    begin cyc(1'b1, 1'b0, i, {LANES{1'b1}}, {DW{1'b0}}); end
  endtask
  task automatic rdx(input [IDXW-1:0] i, input [DW-1:0] exp_d, input exp_c, input exp_u);   // read with explicit expectation
    begin
      @(posedge clk); #2;                     // the expectation must change together with the stimulus (after the edge that
      ce = 1'b1; we = 1'b0; idx = i; wmask = {LANES{1'b1}}; wdata = {DW{1'b0}};   // samples the PREVIOUS request)
      ov_en = 1'b1; ov_data = exp_d; ov_cor = exp_c; ov_unc = exp_u;
    end
  endtask
  // Functional-side signals are DON'T-CARE while ce=0: drive random noise on them during every test access so that a wrapper
  // that lets them influence a test access (e.g. uses the functional lane mask for test writes) is caught.
  task automatic noise_functional;
    reg [31:0] n1, n2;
    begin
      rng(n1); rng(n2);
      we = n1[0]; wmask = n1[LANES+1:2] ^ n2[LANES-1:0]; idx = n2[IDXW-1:0]; wdata = {n2, n1, n2, n1, n2, n1, n2, n1, n2, n1, n2, n1, n2, n1, n2, n1, n2, n1, n2, n1, n2, n1, n2, n1, n2, n1, n2, n1, n2, n1, n2, n1};
    end
  endtask
  task automatic tcyc(input c, input w, input [IDXW-1:0] i, input [PW-1:0] d);
    begin
      @(posedge clk); #2;
      ce = 1'b0;
      noise_functional;
      tst_ce = c; tst_we = w; tst_idx = i; tst_wdata = d;
    end
  endtask
  task automatic twr(input [IDXW-1:0] i, input [PW-1:0] d);
    begin tcyc(1'b1, 1'b1, i, d); end
  endtask
  task automatic trd(input [IDXW-1:0] i, input [PW-1:0] exp_raw);
    begin
      @(posedge clk); #2;
      ce = 1'b0;
      noise_functional;
      tst_ce = 1'b1; tst_we = 1'b0; tst_idx = i; tst_wdata = {PW{1'b0}};
      t_ov_data = exp_raw;
    end
  endtask
  // hand-over: tst_active changes in one cycle, the next cycle is the settle cycle; the first access follows
  task automatic tst_set(input v);
    begin
      @(posedge clk); #2;
      ce = 1'b0; we = 1'b0; tst_ce = 1'b0; tst_we = 1'b0;
      tst_active = v;
      idle(1);
    end
  endtask
  task automatic flush;
    begin idle(L + 3); end
  endtask

  // ------------------------------------------------------------------ independent reference encoder (TB-side)
  // Different code path from the RTL: j-th odd-weight (>=3) r-bit vector found by explicit counting.
  function automatic [15:0] col_of(input integer j, input integer r);
    integer v, b, pc, cnt;
    reg [15:0] res;
    begin
      cnt = 0; res = 0;
      for (v = 1; v < (1 << r); v = v + 1) begin
        pc = 0;
        for (b = 0; b < r; b = b + 1) if ((v >> b) & 1) pc = pc + 1;
        if (pc >= 3 && (pc % 2) == 1) begin
          if (cnt == j) res = v[15:0];
          cnt = cnt + 1;
        end
      end
      col_of = res;
    end
  endfunction
  function automatic [PLW-1:0] enc_lane_word(input [LANE_W-1:0] d);
    integer j, b;
    reg [15:0] c;
    reg [15:0] chk;
    reg [PLW-1:0] w;
    begin
      chk = 0;
      for (j = 0; j < LANE_W; j = j + 1) begin
        c = col_of(j, ECC_R);
        if (d[j]) chk = chk ^ c;
      end
      w = 0;
      w[LANE_W-1:0] = d;
      for (b = 0; b < ECC_R; b = b + 1) w[LANE_W + b] = chk[b];
      enc_lane_word = w;
    end
  endfunction
  // physical (raw) word of a data word: lanes of {check, data}
  function automatic [PW-1:0] raw_of(input [DW-1:0] d);
    integer l;
    reg [PW-1:0] w;
    begin
      w = 0;
      for (l = 0; l < LANES; l = l + 1) begin
        if (ECC_MODE == 0) w[l*PLW +: PLW] = d[l*LANE_W +: LANE_W];
        else w[l*PLW +: PLW] = enc_lane_word(d[l*LANE_W +: LANE_W]);
      end
      raw_of = w;
    end
  endfunction

  // ------------------------------------------------------------------ phases
  integer i, j, a, l, n, cnt, pass;
  reg [31:0] r1, r2, r3;
  reg [DW-1:0] dv, dv2;
  reg [LANES-1:0] mv;
  reg [PW-1:0] rawv, rawc;
  reg [IDXW-1:0] av;
  integer addrs, e;

  task automatic fill_all;
    integer q;
    begin
      for (q = 0; q < DEPTH_WORDS; q = q + 1) begin
        rng(r1); rng(r2); rng(r3);
        dv = {r3, r2, r1, r3 ^ r1, r2 ^ r3, r1 ^ r2, r1 + r2, r2 + r3, r3 + r1, r3, r2, r1, r1 ^ r3, r2 ^ r1, r3 ^ r2, r1 ^ r2 ^ r3,
              r1, r2, r3, r1 ^ r2, r2 ^ r3, r3 ^ r1, r1 + r3, r2 + r1, r3 + r2, r2, r3, r1, r2 ^ r1, r3 ^ r2, r1 ^ r3, r1 + r2 + r3};
        wr(q[IDXW-1:0], {LANES{1'b1}}, dv[DW-1:0]);
      end
    end
  endtask

  // March C-  (10N) on the RAW physical words through the test port, backgrounds all-0 / all-1 over PW bits.
  task automatic march_c(input integer naddr, output integer mism);
    integer q;
    reg [PW-1:0] z, o;
    begin
      z = {PW{1'b0}}; o = {PW{1'b1}};
      // element 1: up (w0)
      for (q = 0; q < naddr; q = q + 1) twr(q[IDXW-1:0], z);
      // element 2: up (r0, w1)
      for (q = 0; q < naddr; q = q + 1) begin trd(q[IDXW-1:0], z); twr(q[IDXW-1:0], o); end
      // element 3: up (r1, w0)
      for (q = 0; q < naddr; q = q + 1) begin trd(q[IDXW-1:0], o); twr(q[IDXW-1:0], z); end
      // element 4: down (r0, w1)
      for (q = naddr - 1; q >= 0; q = q - 1) begin trd(q[IDXW-1:0], z); twr(q[IDXW-1:0], o); end
      // element 5: down (r1, w0)
      for (q = naddr - 1; q >= 0; q = q - 1) begin trd(q[IDXW-1:0], o); twr(q[IDXW-1:0], z); end
      // element 6: up (r0)
      for (q = 0; q < naddr; q = q + 1) trd(q[IDXW-1:0], z);
      mism = 0;
    end
  endtask

  initial begin : main
    integer p, q, lane, bit_i, emask;
    reg [DW-1:0] d0, d1, dnew;
    reg [PW-1:0] rw, rwc;
    integer errs_before;
    rs = (SEED == 0) ? 32'h1 : 32'h9E3779B1 ^ SEED;
    for (p = 0; p < DEPTH_WORDS; p = p + 1) ref_mem[p] = {DW{1'b0}};
    // ---------------- reset-less power-up: hold everything idle (GF180MCU needs CEN high first)
    repeat (4) @(posedge clk);
    #2; mon_en = 1'b1;
    idle(2 + WAKE_CYCLES + 2);

    // ---------------- P3 first (everything below reads written words only): full initialisation
    fill_all;
    flush;

    // ---------------- P1 directed
    rng(r1); rng(r2);
    d0 = {r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1};
    wr(5, {LANES{1'b1}}, d0[DW-1:0]);
    rd(5);                                    // read-after-write in the next cycle returns the NEW data
    wr(5, {LANES{1'b1}}, ~d0[DW-1:0]);        // write-after-read in the next cycle: the read above returned the OLD data
    rd(5);
    rd(6); rd(7); rd(8);                      // back-to-back reads, one response per cycle, in order
    wr(9, {LANES{1'b1}}, d0[DW-1:0]); wr(10, {LANES{1'b1}}, ~d0[DW-1:0]); rd(9); rd(10);
    wr(DEPTH_WORDS - 1, {LANES{1'b1}}, d0[DW-1:0]); rd(DEPTH_WORDS - 1); rd(0);   // boundary words
    wr(0, {LANES{1'b1}}, ~d0[DW-1:0]); rd(0);
    flush;

    // ---------------- P2 byte enables
    if (BYTE_ENABLE != 0) begin
      wr(11, {LANES{1'b1}}, {DW{1'b0}});
      for (lane = 0; lane < LANES; lane = lane + 1) begin
        rng(r1);
        mv = {LANES{1'b0}}; mv[lane] = 1'b1;
        dnew = {DW{1'b1}};
        wr(11, mv, dnew);                     // only this lane takes the new data
        rd(11);
        wr(11, mv, {DW{1'b0}});               // clear it again
      end
      wr(12, {LANES{1'b1}}, {DW{1'b1}});
      wr(12, {LANES{1'b0}}, {DW{1'b0}});      // zero mask: legal write that changes nothing
      rd(12);
      for (lane = 0; lane < LANES; lane = lane + 1) begin   // walking-0 mask over a pattern word
        rng(r1); rng(r2);
        dnew = {r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1};
        mv = {LANES{1'b1}}; mv[lane] = 1'b0;
        wr(13, {LANES{1'b1}}, ~dnew[DW-1:0]);
        wr(13, mv, dnew[DW-1:0]);
        rd(13);
      end
      for (q = 0; q < (1 << ((LANES > 6) ? 6 : LANES)); q = q + 1) begin   // exhaustive masks (first 6 lanes)
        mv = q[LANES-1:0];
        rng(r1); rng(r2);
        dnew = {r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1};
        wr(14, {LANES{1'b1}}, ~dnew[DW-1:0]);
        wr(14, mv, dnew[DW-1:0]);
        rd(14);
      end
    end
    flush;

    // ---------------- P4 random traffic
    for (n = 0; n < NCYC; n = n + 1) begin
      rng(r1); rng(r2); rng(r3);
      // 25% idle, of the rest 50/50 read/write; addresses biased to a small hot set to force hazards
      a = (r1[7:6] == 2'b00) ? (r2 % 8) : (r2 % DEPTH_WORDS);
      if (r1[1:0] == 2'b00) begin
        cyc(1'b0, r1[2], a[IDXW-1:0], r3[LANES-1:0], {r3, r2, r1, r3, r2, r1, r3, r2, r1, r3, r2, r1, r3, r2, r1, r3, r2, r1, r3, r2, r1, r3, r2, r1, r3, r2, r1, r3, r2, r1, r3, r2});
      end else if (r1[2]) begin
        mv = (BYTE_ENABLE != 0) ? ((r1[5:3] == 3'b000) ? {LANES{1'b1}} : r3[LANES-1:0]) : {LANES{1'b1}};
        wr(a[IDXW-1:0], mv, {r3, r2, r1, r3 ^ r1, r2 ^ r3, r1 ^ r2, r3, r2, r1, r1 + r2, r2 + r3, r3 + r1, r3, r2, r1, r1 ^ r3, r2, r3, r1, r1, r2 ^ r1, r3 ^ r2, r1 ^ r2 ^ r3, r2, r3, r1, r2 + r1, r3, r2, r1, r3 ^ r1, r2 ^ r3});
      end else begin
        rd(a[IDXW-1:0]);
      end
    end
    flush;
    // full read-back of the whole array against the reference model
    for (q = 0; q < DEPTH_WORDS; q = q + 1) rd(q[IDXW-1:0]);
    flush;

    // ---------------- P5 test port
    if (TEST_MODE != 0) begin : p5
      integer maddr, mism;
      maddr = (MARCH_ADDRS == 0) ? DEPTH_WORDS : MARCH_ADDRS;
      // functional contents must survive entering/leaving test mode untouched: remember raw words of a few addresses
      tst_set(1'b1);
      for (q = 0; q < 8; q = q + 1) begin
        trd((q * 37) % DEPTH_WORDS, raw_of(ref_mem[(q * 37) % DEPTH_WORDS]));      // RAW read-back == encode(functional data)
      end
      idle(L + 2);
      march_c(maddr, mism);
      idle(L + 2);
      tst_set(1'b0);
      // the March left all-zero raw words in [0, maddr): the functional view of those words is now decode(zero word).
      // For ECC configs the all-zero codeword is valid (zero data, zero check); for non-ECC it is just zero data.
      for (q = 0; q < maddr; q = q + 1) ref_mem[q] = {DW{1'b0}};
      for (q = 0; q < ((maddr < 64) ? maddr : 64); q = q + 1) rd(q[IDXW-1:0]);
      flush;
    end

    // ---------------- P6 ECC error injection through the raw test port (TEST_MODE=1 required)
    if (ECC_MODE != 0 && TEST_MODE != 0) begin : p6
      integer sa, fb, fb2, lane_a, lane_b, nsing, ndbl, ndiff;
      reg [DW-1:0] want, dmg;
      reg [PW-1:0] good, bad;
      reg [DW-1:0] stored_data;
      nsing = 0; ndbl = 0; ndiff = 0;
      for (sa = 0; sa < 4; sa = sa + 1) begin
        av = (sa * 53 + 3) % DEPTH_WORDS;
        rng(r1); rng(r2); rng(r3);
        want = {r3, r2, r1, r3 ^ r2, r1 ^ r3, r2 ^ r1, r3, r2, r1, r3, r2, r1, r3, r2, r1, r1 ^ r2, r3, r2, r1, r1 ^ r3, r2, r3, r1, r2, r3, r1 ^ r2, r2, r3, r1, r2, r3, r1};
        wr(av, {LANES{1'b1}}, want);
        flush;
        // golden raw word (TB reference encoder) and the raw word the DUT really stored
        good = raw_of(ref_mem[av]);
        tst_set(1'b1);
        trd(av, good);                                       // stored raw word == golden codeword
        idle(L + 2);
        // every single-bit flip of the stored physical word
        for (fb = 0; fb < PW; fb = fb + 1) begin
          bad = good; bad[fb] = ~bad[fb];
          twr(av, bad);
          tst_set(1'b0);
          rdx(av, ref_mem[av], 1'b1, 1'b0);                   // corrected, flagged, data intact
          idle(L + 2);
          tst_set(1'b1);
          nsing = nsing + 1;
        end
        // double flips: same lane -> uncorrectable (data returned = stored data bits, uncorrected); different lanes -> both corrected
        for (fb = 0; fb < PW; fb = fb + 1) begin
          for (fb2 = fb + 1; fb2 < PW; fb2 = fb2 + 1) begin
            if (((fb * 7 + fb2 * 13 + sa) % ((PW > 40) ? 11 : 3)) != 0) begin : skip_pair end
            else begin
              lane_a = fb / PLW; lane_b = fb2 / PLW;
              bad = good; bad[fb] = ~bad[fb]; bad[fb2] = ~bad[fb2];
              twr(av, bad);
              // expected raw -> functional view: per lane decode; build expected data by lane
              dmg = ref_mem[av];
              if (lane_a == lane_b) begin
                // uncorrectable lane: data bits as stored (with flipped data bits applied)
                for (l = 0; l < LANES; l = l + 1) if (l == lane_a) begin
                  stored_data = 0;
                  stored_data[l*LANE_W +: LANE_W] = bad[l*PLW +: LANE_W];
                  dmg[l*LANE_W +: LANE_W] = stored_data[l*LANE_W +: LANE_W];
                end
                tst_set(1'b0);
                rdx(av, dmg, 1'b0, 1'b1);
                ndbl = ndbl + 1;
              end else begin
                tst_set(1'b0);
                rdx(av, ref_mem[av], 1'b1, 1'b0);
                ndiff = ndiff + 1;
              end
              idle(L + 2);
              tst_set(1'b1);
            end
          end
        end
        twr(av, good);                                       // restore the codeword
        tst_set(1'b0);
        rd(av);
        idle(L + 2);
      end
      $display("TB INFO: ECC injection: %0d single flips corrected, %0d same-lane double flips detected, %0d cross-lane double flips corrected", nsing, ndbl, ndiff);
      flush;
    end

    // ---------------- P7 power (logical-interface model)
    if (POWER_CTRL != 0) begin : p7
      reg [DW-1:0] pd;
      integer w;
      rng(r1); rng(r2);
      pd = {r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1, r2, r1};
      wr(21, {LANES{1'b1}}, pd[DW-1:0]);
      rd(21);                                                // in flight when sleep asserts: must still complete
      @(posedge clk); #2; ce = 1'b0; we = 1'b0; pwr_sleep = 1'b1;
      idle(1);
      if (pwr_active !== 1'b0) err("pwr_active did not fall while pwr_sleep=1");
      idle(L + 6);
      @(posedge clk); #2; pwr_sleep = 1'b0;                  // wake
      #1;                                                    // let pwr_active settle (a same-timestep read would race)
      w = 0;
      while (pwr_active !== 1'b1 && w < 32) begin @(posedge clk); #2; w = w + 1; end
      if (w != WAKE_CYCLES) begin err("wake latency differs from WAKE_CYCLES"); $display("   measured %0d expected %0d", w, WAKE_CYCLES); end
      rd(21);                                                // contents retained across sleep
      flush;
    end

    // ---------------- P8 negative: accesses inside the test hand-over window are dropped (never reach the array)
    if (NEG_TEST != 0 && TEST_MODE != 0) begin : p8
      reg [DW-1:0] junk;
      integer q8;
      junk = {DW{1'b1}};
      expect_quiet_drop = 1'b1;
      // enter: functional writes in the cycle tst_active rises and in the settle cycle -> both dropped (2 assertions)
      @(posedge clk); #2; tst_active = 1'b1; ce = 1'b1; we = 1'b1; idx = 40; wmask = {LANES{1'b1}}; wdata = junk;
      @(posedge clk); #2; ce = 1'b1; we = 1'b1; idx = 41; wmask = {LANES{1'b1}}; wdata = junk;
      @(posedge clk); #2; ce = 1'b0; we = 1'b0;
      // exit: functional writes in the cycle tst_active falls and in the settle cycle -> both dropped (2 assertions)
      @(posedge clk); #2; tst_active = 1'b0; ce = 1'b1; we = 1'b1; idx = 42; wmask = {LANES{1'b1}}; wdata = junk;
      @(posedge clk); #2; ce = 1'b1; we = 1'b1; idx = 43; wmask = {LANES{1'b1}}; wdata = junk;
      @(posedge clk); #2; ce = 1'b0; we = 1'b0;
      expect_quiet_drop = 1'b0;
      idle(2);
      for (q8 = 40; q8 < 44; q8 = q8 + 1) rd(q8);               // the four addresses must still hold their OLD (reference) data
      flush;
    end

    flush;
    mon_en = 1'b0;
    $display("SF_TB_RESULT: %s tech=%0d macro=%0d W=%0d D=%0d L=%0d be=%0d bw=%0d ecc=%0d test=%0d pwr=%0d checks=%0d errors=%0d trace=%016h",
             (errors == 0 && checks > 0) ? "PASS" : "FAIL", MEMORY_TECH, MACRO_ID, DATA_WIDTH, DEPTH_WORDS, READ_LATENCY, BYTE_ENABLE,
             BYTE_WIDTH, ECC_MODE, TEST_MODE, POWER_CTRL, checks, errors, trace);
    $finish;
  end

  // watchdog
  initial begin
    #(PERIOD * 4000000.0);
    $display("SF_TB_RESULT: FAIL timeout");
    $finish;
  end
endmodule
