# =============================================================================
# SilicaFlux SRAMMacroBridge :: mock_odb.tcl
# Executes the generated floorplan Tcl under plain tclsh against a MOCK of the OpenROAD / OpenDB commands it uses
#   ord::get_db_block, dbBlock getDefUnits/getInsts/findInst, dbInst getName/getMaster/setOrient/getOrient/setLocation/
#   getBBox/setPlacementStatus/getPlacementStatus, dbMaster getName/getType/getWidth/getHeight, odb::dbBlockage_create,
#   initialize_floorplan, add_global_connection, global_connect.
# The mock knows exactly the macro instances of the synthesized netlist (macros.tsv), so an unknown instance name or a wrong
# master fails here as it would in OpenROAD.  It proves the Tcl runs and what it does; it does NOT prove that OpenROAD
# accepts the placement (that needs a real OpenROAD run, which this package could not perform).
#
#   tclsh8.6 physical/mock_odb.tcl <macros.tsv> <out.json> <script.tcl> [<script.tcl> ...]
#   macros.tsv: "<instance name>\t<master>\t<width_dbu>\t<height_dbu>" per line
# =============================================================================
lassign $argv tsv_file out_json
set scripts [lrange $argv 2 end]
set ::DBU 1000
set ::insts [dict create]        ;# handle -> dict(name master w h x y orient status)
set ::order {}
set ::blockages {}
set ::cmdlog {}
set ::die {}
set ::core {}
set ::site {}
set ::gconn {}

set fh [open $tsv_file r]
set n 0
while {[gets $fh line] >= 0} {
  if {$line eq ""} continue
  lassign [split $line "\t"] name master w h
  incr n
  set hnd "::mock_inst_$n"
  dict set ::insts $hnd [dict create name $name master $master w $w h $h x 0 y 0 orient R0 status UNPLACED]
  lappend ::order $hnd
  proc $hnd {cmd args} {
    set self [lindex [info level 0] 0]
    set d [dict get $::insts $self]
    switch -- $cmd {
      getName            { return [dict get $d name] }
      getMaster          { return "::mock_master_[dict get $d master]" }
      setOrient          { dict set ::insts $self orient [lindex $args 0]; return }
      getOrient          { return [dict get $d orient] }
      setLocation        { dict set ::insts $self x [lindex $args 0]; dict set ::insts $self y [lindex $args 1]; return }
      getLocation        { return [list [dict get $d x] [dict get $d y]] }
      setPlacementStatus { dict set ::insts $self status [lindex $args 0]; return }
      getPlacementStatus { return [dict get $d status] }
      getBBox            { return "::mock_bbox_[string range $self 12 end]" }
      default            { error "mock dbInst: unsupported method $cmd" }
    }
  }
  set mname "::mock_master_$master"
  if {[info commands $mname] eq ""} {
    proc $mname {cmd args} {
      set self [lindex [info level 0] 0]
      set m [string range $self 14 end]
      switch -- $cmd {
        getName   { return $m }
        getType   { return BLOCK }
        default   { error "mock dbMaster: unsupported method $cmd" }
      }
    }
  }
  proc "::mock_bbox_$n" {cmd args} {
    set self [lindex [info level 0] 0]
    set hnd "::mock_inst_[string range $self 12 end]"
    set d [dict get $::insts $hnd]
    switch -- $cmd {
      xMin { return [dict get $d x] }
      yMin { return [dict get $d y] }
      xMax { return [expr {[dict get $d x] + [dict get $d w]}] }
      yMax { return [expr {[dict get $d y] + [dict get $d h]}] }
      default { error "mock dbBox: unsupported method $cmd" }
    }
  }
}
close $fh

proc ::mock_block {cmd args} {
  switch -- $cmd {
    getDefUnits { return $::DBU }
    getInsts    { return $::order }
    findInst    { set want [lindex $args 0]
                  foreach h $::order { if {[dict get [dict get $::insts $h] name] eq $want} { return $h } }
                  return NULL }
    default     { error "mock dbBlock: unsupported method $cmd" }
  }
}
namespace eval ::ord { proc get_db_block {} { return ::mock_block } }
namespace eval ::odb {
  proc dbBlockage_create {block x1 y1 x2 y2} {
    if {$block ne "::mock_block"} { error "mock dbBlockage_create: bad block" }
    lappend ::blockages [list $x1 $y1 $x2 $y2]
    return "::mock_blockage"
  }
}
proc initialize_floorplan {args} {
  array set a {-site {}}
  foreach {k v} $args { set a($k) $v }
  set ::die $a(-die_area); set ::core $a(-core_area); set ::site $a(-site)
  lappend ::cmdlog "initialize_floorplan"
}
proc add_global_connection {args} {
  array set a {}
  set flags {}
  set i 0
  while {$i < [llength $args]} {
    set k [lindex $args $i]
    if {$k in {-power -ground}} { lappend flags $k; incr i } else { set a($k) [lindex $args [expr {$i+1}]]; incr i 2 }
  }
  lappend ::gconn [list $a(-net) $a(-pin_pattern) $flags]
}
proc global_connect {} { lappend ::cmdlog "global_connect" }

foreach s $scripts {
  puts "MOCK: sourcing $s"
  source $s
}

# ---- machine-readable result
proc jstr {s} { return "\"[string map {\\ \\\\ \" \\\"} $s]\"" }
set fh [open $out_json w]
puts $fh "\{"
puts $fh "\"die\": \[[join $::die ,]\], \"core\": \[[join $::core ,]\], \"site\": [jstr $::site], \"dbu\": $::DBU,"
puts $fh "\"insts\": \["
set first 1
foreach h $::order {
  set d [dict get $::insts $h]
  if {!$first} { puts $fh "," }
  set first 0
  puts -nonewline $fh "  \{\"name\": [jstr [dict get $d name]], \"master\": [jstr [dict get $d master]], \"x\": [dict get $d x], \"y\": [dict get $d y], \"orient\": [jstr [dict get $d orient]], \"status\": [jstr [dict get $d status]]\}"
}
puts $fh "\n\],"
puts $fh "\"blockages\": \[[join [lmap b $::blockages {format "\[%s\]" [join $b ,]}] ,]\],"
puts $fh "\"global_connections\": \[[join [lmap g $::gconn {format "\[%s, %s, %s\]" [jstr [lindex $g 0]] [jstr [lindex $g 1]] [jstr [lindex $g 2]]}] ,]\],"
puts $fh "\"commands\": \[[join [lmap c $::cmdlog {jstr $c}] ,]\]"
puts $fh "\}"
close $fh
puts "MOCK: done ([llength $::order] macros, [llength $::blockages] blockages)"
