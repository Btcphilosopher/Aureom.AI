"""Configuration generator: rule coverage (incl. synthetic-catalogue rules), plan arithmetic, rejections, ranking."""
import copy, json, math, os, subprocess, sys, unittest
import common
from common import ROOT
import sram_cfg_gen as G

MAN = os.path.join(ROOT, "manifests")


class T(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cat = G.load_catalog(MAN)
        cls.byname = {m["macro_name"]: mid for mid, m in cls.cat.items()}

    def cfg(self, **k):
        c = {"DATA_WIDTH": 32, "DEPTH_WORDS": 1024, "READ_LATENCY": 1, "BYTE_ENABLE": 1, "BYTE_WIDTH": 8, "MEMORY_TECH": 0, "MACRO_ID": 0, "ECC_MODE": 0}
        c.update(k)
        return c

    def test_each_reachable_rule_fires(self):
        e = lambda **k: G.err_code(self.cfg(**k), self.cat)
        ihp4 = self.byname["RM_IHPSG13_1P_256x32_c2_bm_bist"]
        self.assertEqual(e(), 0)
        self.assertEqual(e(DATA_WIDTH=0), 1)
        self.assertEqual(e(DEPTH_WORDS=1), 2)
        self.assertEqual(e(READ_LATENCY=0), 3)
        self.assertEqual(e(BYTE_ENABLE=3), 4)
        self.assertEqual(e(DATA_WIDTH=30), 5)
        self.assertEqual(e(MEMORY_TECH=19), 6)
        self.assertEqual(e(MEMORY_TECH=3), 7)
        self.assertEqual(e(ECC_MODE=1), 9)                       # word ECC + byte enables needs RMW
        self.assertEqual(e(ECC_MODE=2, BYTE_ENABLE=0), 10)
        self.assertEqual(e(MEMORY_TECH=10, MACRO_ID=ihp4, INIT_MODE=1), 20)
        self.assertEqual(e(MEMORY_TECH=11, MACRO_ID=ihp4), 22)
        self.assertEqual(e(MEMORY_TECH=10, MACRO_ID=ihp4, POWER_CTRL=1), 26)
        self.assertEqual(e(MEMORY_TECH=10, MACRO_ID=ihp4, DEPTH_WORDS=300000, DATA_WIDTH=512), 28)

    def test_rules_that_need_data_the_real_catalogue_lacks(self):
        """Synthetic catalogue entries (NOT real macros): the rules exist and fire."""
        cat = copy.deepcopy(self.cat)
        base = dict(cat[self.byname["RM_IHPSG13_1P_256x32_c2_bm_bist"]])
        nomask = dict(base, id=101, has_wmask=False)
        ecc = dict(base, id=102, builtin_ecc=True)
        slow = dict(base, id=103, read_latency_cycles=2)
        sleep_ok = dict(base, id=104, sleep_retention=True)
        for m in (nomask, ecc, slow, sleep_ok):
            cat[m["id"]] = m
        e = lambda mid, **k: G.err_code(self.cfg(MEMORY_TECH=10, MACRO_ID=mid, DEPTH_WORDS=256, **k), cat)
        self.assertEqual(e(101), 23)                              # no write mask + byte enables: rejected (RMW cannot be stalled for)
        self.assertEqual(e(101, BYTE_ENABLE=0, ECC_MODE=0), 0)    # whole-word writes are fine without a mask
        self.assertEqual(e(102), 25)
        self.assertEqual(e(103), 27)
        self.assertEqual(e(103, READ_LATENCY=2), 0)
        self.assertEqual(e(104, POWER_CTRL=1), 0)                 # a macro WITH sleep pins would pass rule 26

    def test_mask_granularity_rule(self):
        sky = self.byname["sky130_sram_1kbyte_1rw1r_32x256_8"]
        ok = G.err_code(self.cfg(MEMORY_TECH=12, MACRO_ID=sky, DATA_WIDTH=32, BYTE_WIDTH=8, DEPTH_WORDS=256), self.cat)
        bad9 = G.err_code(self.cfg(MEMORY_TECH=12, MACRO_ID=sky, DATA_WIDTH=36, BYTE_WIDTH=9, DEPTH_WORDS=256), self.cat)
        badecc = G.err_code(self.cfg(MEMORY_TECH=12, MACRO_ID=sky, DATA_WIDTH=32, BYTE_WIDTH=8, ECC_MODE=2, DEPTH_WORDS=256), self.cat)   # 13-bit lanes
        okecc = G.err_code(self.cfg(MEMORY_TECH=12, MACRO_ID=sky, DATA_WIDTH=32, BYTE_ENABLE=0, ECC_MODE=1, DEPTH_WORDS=256), self.cat)  # one 39-bit lane: all bytes written
        self.assertEqual((ok, bad9, badecc, okecc), (0, 24, 24, 0))

    def test_plan_arithmetic_is_recomputable(self):
        req = {"DATA_WIDTH": 128, "DEPTH_WORDS": 3000, "READ_LATENCY": 2, "BYTE_ENABLE": 1, "BYTE_WIDTH": 32, "ECC_MODE": 2, "TEST_MODE": 1}
        plan = G.build_plan(req, self.cat, MAN, tech="ihp")
        self.assertEqual(plan["status"], "OK")
        lg = plan["logical"]
        self.assertEqual((lg["lanes"], lg["ecc_check_bits_per_lane"], lg["stored_lane_bits"], lg["physical_word_bits"]), (4, 7, 39, 156))
        for alt in [plan["selected"]] + plan["alternatives"]:
            nr = math.ceil(3000 / alt["tiling"]["macro_words"])
            nc = math.ceil(156 / alt["tiling"]["macro_bits"])
            self.assertEqual((alt["tiling"]["rows"], alt["tiling"]["columns"], alt["tiling"]["instances"]), (nr, nc, nr * nc))
            c = alt["capacity"]
            self.assertEqual(c["logical_bits"], 128 * 3000)
            self.assertEqual(c["physical_stored_bits"], 156 * 3000)
            self.assertEqual(c["ecc_overhead_bits"], 28 * 3000)
            self.assertEqual(c["macro_bits_total"], nr * nc * alt["tiling"]["macro_words"] * alt["tiling"]["macro_bits"])
            self.assertEqual(c["unused_bits"], c["macro_bits_total"] - c["physical_stored_bits"])
            w, h = alt["footprint"]["macro_size_um"]
            self.assertAlmostEqual(alt["footprint"]["total_macro_area_um2"], nr * nc * w * h, delta=0.01 * nr * nc)
        areas = [a["footprint"]["total_macro_area_um2"] for a in [plan["selected"]] + plan["alternatives"]]
        self.assertEqual(areas, sorted(areas))                    # objective=area ranks by area

    def test_objectives_change_the_ranking_deterministically(self):
        req = {"DATA_WIDTH": 32, "DEPTH_WORDS": 3000, "READ_LATENCY": 1, "BYTE_ENABLE": 1, "BYTE_WIDTH": 8}
        a = G.build_plan(req, self.cat, MAN, tech="ihp", objective="area")["selected"]["macro_name"]
        c = G.build_plan(req, self.cat, MAN, tech="ihp", objective="count")["selected"]
        self.assertEqual(c["tiling"]["instances"], min(x["tiling"]["instances"] for x in [c] + G.build_plan(req, self.cat, MAN, tech="ihp", objective="count")["alternatives"]))
        self.assertEqual(a, G.build_plan(req, self.cat, MAN, tech="ihp", objective="area")["selected"]["macro_name"])

    def test_impossible_requests_are_reported_not_substituted(self):
        p = G.build_plan({"DATA_WIDTH": 36, "DEPTH_WORDS": 512, "BYTE_ENABLE": 1, "BYTE_WIDTH": 9}, self.cat, MAN, tech="sky130")
        self.assertEqual(p["status"], "CANNOT_IMPLEMENT_WITH_CATALOGUED_MACROS")
        self.assertIsNone(p["selected"])
        self.assertEqual({r["code"] for r in p["rejected"]}, {24})
        p = G.build_plan({"DATA_WIDTH": 32, "DEPTH_WORDS": 256, "POWER_CTRL": 1}, self.cat, MAN, tech="all")
        self.assertEqual(p["status"], "CANNOT_IMPLEMENT_WITH_CATALOGUED_MACROS")
        self.assertEqual({r["code"] for r in p["rejected"]}, {26})
        self.assertEqual(sum(len(r["macros"]) for r in p["rejected"]), 25)       # all 25 macros listed with the reason

    def test_timing_bound_uses_liberty_only(self):
        p = G.build_plan({"DATA_WIDTH": 32, "DEPTH_WORDS": 256}, self.cat, MAN, tech="sky130", logic_delay_ns=0.0)
        s = p["selected"]
        c = s["timing_macro_only"]["corners"][0]
        self.assertEqual(c["launch_edge"], "falling_edge")                        # SKY130: half-cycle access
        self.assertAlmostEqual(c["read_path_period_lower_bound_ns"], 2 * c["clk_to_out_max_ns"], places=3)
        self.assertGreaterEqual(c["period_lower_bound_ns"], c["min_period_liberty_ns"])
        p2 = G.build_plan({"DATA_WIDTH": 32, "DEPTH_WORDS": 256}, self.cat, MAN, tech="sky130", logic_delay_ns=0.5)
        c2 = p2["selected"]["timing_macro_only"]["corners"][0]
        self.assertGreater(c2["read_path_period_lower_bound_ns"], c["read_path_period_lower_bound_ns"])

    def test_cli_check_exit_codes(self):
        run = lambda *a: subprocess.run([sys.executable, "-I", os.path.join(ROOT, "tools", "sram_cfg_gen.py"), "check", "--manifests", MAN] + list(a), capture_output=True, text=True)
        self.assertEqual(run("--width", "32", "--words", "1024").returncode, 0)
        r = run("--width", "32", "--words", "1024", "--ecc", "word")
        self.assertEqual(r.returncode, 2)
        self.assertIn("read-modify-write", r.stdout)

if __name__ == "__main__":
    unittest.main()
