"""Floorplan generator + checker, including NEGATIVE tests: a corrupted floorplan must be rejected."""
import json, os, shutil, subprocess, sys, tempfile, unittest
import common
from common import ROOT

CHECK = [sys.executable, "-I", os.path.join(ROOT, "tools", "check_floorplan.py")]
PLANS = [d for d in ("sfv_a", "sfv_gf", "sfv_sky") if os.path.isdir(os.path.join(ROOT, "physical", d))]
HAVE_TCL = shutil.which("tclsh8.6") is not None


@unittest.skipUnless(HAVE_TCL, "tclsh8.6 not installed")
class T(unittest.TestCase):
    def run_check(self, d):
        return subprocess.run(CHECK + [d], capture_output=True, text=True)

    def test_generated_floorplans_pass(self):
        self.assertTrue(PLANS)
        for p in PLANS:
            r = self.run_check(os.path.join(ROOT, "physical", p))
            self.assertEqual(r.returncode, 0, p + "\n" + r.stdout[-800:])
            self.assertIn("OpenROAD was NOT run", r.stdout)

    def corrupt(self, plan, fn):
        td = tempfile.mkdtemp()
        d = os.path.join(td, "fp")
        shutil.copytree(os.path.join(ROOT, "physical", plan), d)
        fn(d)
        r = self.run_check(d)
        shutil.rmtree(td)
        return r

    def edit_json(self, f, mut):
        def go(d):
            p = os.path.join(d, f)
            with open(p) as fh:
                x = json.load(fh)
            mut(x)
            with open(p, "w") as fh:
                json.dump(x, fh, indent=1)
        return go

    def edit_text(self, f, old, new):
        def go(d):
            p = os.path.join(d, f)
            with open(p) as fh:
                t = fh.read()
            assert old in t
            with open(p, "w") as fh:
                fh.write(t.replace(old, new, 1))
        return go

    def test_overlap_is_detected(self):
        plan = "sfv_a"
        def mut(x):
            x["placements"][1]["x"] = x["placements"][0]["x"] + 5.0
            x["placements"][1]["bbox"][0] = x["placements"][1]["x"]; x["placements"][1]["bbox"][2] = x["placements"][1]["x"] + x["macro_size_um"][0]
        r = self.corrupt(plan, self.edit_json("floorplan.json", mut))
        self.assertNotEqual(r.returncode, 0)

    def test_tcl_that_disagrees_with_json_is_detected(self):
        r = self.corrupt("sfv_a", self.edit_text("macro_place.tcl", " 41.58 R0}", " 99.99 R0}"))
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("FAIL", r.stdout)

    def test_unknown_instance_name_fails_in_the_tcl(self):
        r = self.corrupt("sfv_a", self.edit_text("macro_place.tcl", "g_row[0].g_col[0]", "g_row[0].g_col[9]"))
        self.assertNotEqual(r.returncode, 0)

    def test_wrong_master_fails_in_the_tcl(self):
        r = self.corrupt("sfv_a", self.edit_text("macro_place.tcl", "RM_IHPSG13_1P_2048x32_c2_bm_bist 41.76", "RM_IHPSG13_1P_1024x32_c2_bm_bist 41.76"))
        self.assertNotEqual(r.returncode, 0)

    def test_macro_outside_core_is_detected(self):
        def mut(x):
            p = x["placements"][0]; p["x"] = -5.0; p["bbox"] = [-5.0, p["bbox"][1], -5.0 + x["macro_size_um"][0], p["bbox"][3]]
        self.assertNotEqual(self.corrupt("sfv_a", self.edit_json("floorplan.json", mut)).returncode, 0)

    def test_illegal_orientation_is_detected(self):
        def mut(x): x["placements"][0]["orient"] = "R90"
        self.assertNotEqual(self.corrupt("sfv_a", self.edit_json("floorplan.json", mut)).returncode, 0)

    def test_wrong_pg_pin_name_is_detected(self):
        r = self.corrupt("sfv_a", self.edit_text("pdn_connect.tcl", "^VDDARRAY!$", "^VDDARRAY$"))
        self.assertNotEqual(r.returncode, 0)

    def test_multirow_uses_facing_orientations(self):
        with open(os.path.join(ROOT, "physical", "sfv_gf", "floorplan.json")) as fh:
            fp = json.load(fh)
        by_row = {p["row"]: p["orient"] for p in fp["placements"]}
        self.assertEqual(by_row, {0: "MX", 1: "R0"})              # pins on the south edge: row 0 flipped so both pin edges face the channel
        rows = sorted({p["row"] for p in fp["placements"]})
        y0 = min(p["bbox"][3] for p in fp["placements"] if p["row"] == 0)
        y1 = min(p["bbox"][1] for p in fp["placements"] if p["row"] == 1)
        self.assertGreaterEqual(y1 - y0, fp["assumptions"][2]["value"] - 1e-6)     # pin channel kept between the facing rows

if __name__ == "__main__":
    unittest.main()
