"""Parsers on small synthetic fixtures (no vendor files needed)."""
import unittest
import common  # noqa: F401
import lef_parse, lib_parse, vlog_ports, ecc_ref

LEF = """VERSION 5.7 ;
UNITS DATABASE MICRONS 1000 ; END UNITS
MACRO M1
  CLASS BLOCK ;
  SIZE 100 BY 50 ;
  SYMMETRY X Y R90 ;
  PIN A[0] DIRECTION INPUT ; USE SIGNAL ; PORT LAYER Metal2 ; RECT 10 0 11 1 ; END END A[0]
  PIN A[1] DIRECTION INPUT ; USE SIGNAL ; PORT LAYER Metal2 ; RECT 20 0 21 1 ; END END A[1]
  PIN Q DIRECTION OUTPUT ; USE SIGNAL ; PORT LAYER Metal3 ; RECT 99 20 100 21 ; END END Q
  PIN VDD! DIRECTION INOUT ; USE POWER ; PORT LAYER Metal4 ; RECT 5 0 7 50 ; END END VDD!
  PIN VSS! DIRECTION INOUT ; USE GROUND ; PORT LAYER Metal4 ; RECT 8 0 10 50 ; END END VSS!
  OBS LAYER Metal1 ; RECT 0 0 100 50 ; LAYER Metal2 ; POLYGON 0 0 100 0 100 50 0 50 ; END
END M1
"""
TECH = """UNITS DATABASE MICRONS 1000 ; END UNITS
SITE CoreSite SYMMETRY Y ; CLASS CORE ; SIZE 0.48 BY 3.78 ; END CoreSite
LAYER Metal1 TYPE ROUTING ; DIRECTION HORIZONTAL ; PITCH 0.42 ; WIDTH 0.16 ; END Metal1
LAYER Via1 TYPE CUT ; END Via1
LAYER Metal2 TYPE ROUTING ; DIRECTION VERTICAL ; PITCH 0.48 ; WIDTH 0.2 ; END Metal2
VIA v1 LAYER Metal1 ; RECT 0 0 1 1 ; END v1
"""
LIB = """library(t) { time_unit : "1ns"; leakage_power_unit : "1nW"; nom_voltage : 1.2; nom_temperature : 25; nom_process : 1;
  revision : 1.0.0 ;
  voltage_map ( VDD, 1.20); voltage_map ( VDDA, 1.20);
  cell(M1) { area : 5000 ; cell_leakage_power : 12.5 ;
    memory() { type : ram; address_width : 2; word_width : 4; }
    pg_pin(VDD) { pg_type : primary_power; }
    pin(CLK) { direction : input; clock : "true";
      timing() { timing_type : "min_pulse_width"; related_pin : "CLK"; rise_constraint(t) { values("0.2,0.3"); } } }
    bus(A) { direction : input;
      pin(A[1:0]) {
        timing() { timing_type : setup_rising; related_pin : "CLK"; when : "(EN)"
                   sdf_cond : "EN"
          rise_constraint(t) { values("0.1,0.2","0.3,0.4"); } fall_constraint(t) { values("-0.1,0.0","0.2,0.5"); } }
        timing() { timing_type : hold_rising; related_pin : "CLK"; rise_constraint(t) { values("0.5"); } fall_constraint(t) { values("0.6"); } } } }
    bus(Q) { direction : output;
      timing() { timing_type : rising_edge; related_pin : "CLK"; cell_rise(t) { values("3.0,3.1"); } cell_fall(t) { values("2.9,3.2"); } } }
  } }
"""
VLOG = """module m (a, b, q);
parameter W = 4;
input [W-1:0] a; input b; output [W*2-1:0] q;
endmodule
"""

class T(unittest.TestCase):
    def test_lef_macro(self):
        d = lef_parse.parse_macro_lef(LEF)
        m = d["macros"]["M1"]
        s = lef_parse.summarize_macro(m)
        self.assertEqual(s["size_um"], [100.0, 50.0])
        self.assertEqual(s["signal_pins"]["A"]["width"], 2)
        self.assertEqual(s["signal_pins"]["A"]["edges"], ["S"])
        self.assertEqual(s["signal_pins"]["Q"]["edges"], ["E"])
        self.assertEqual(sorted(s["pg_pins"]), ["VDD!", "VSS!"])
        self.assertEqual(s["pg_pins"]["VDD!"]["orientation_by_layer"], {"Metal4": "V"})
        self.assertEqual(sorted(s["obs_layers"]), ["Metal1", "Metal2"])
        self.assertTrue(s["obs_layers"]["Metal2"]["bbox_covers_outline"])
        self.assertAlmostEqual(s["obs_layers"]["Metal2"]["area_sum_um2"], 5000.0)   # polygon area (shoelace)

    def test_lef_orientations(self):
        self.assertEqual(lef_parse.legal_orientations(["X", "Y", "R90"]), ["R0", "MX", "MY", "R180"])
        self.assertEqual(lef_parse.legal_orientations(["X"]), ["R0", "MX"])
        self.assertEqual(lef_parse.legal_orientations([]), ["R0"])
        self.assertIn("R90", lef_parse.legal_orientations(["X", "Y", "R90"], allow_rotated=True))

    def test_lef_rejects_unsupported_geometry(self):
        bad = LEF.replace("OBS LAYER Metal1 ; RECT 0 0 100 50 ;", "OBS LAYER Metal1 ; VIA 1 1 v1 ;")
        with self.assertRaises(lef_parse.LefError):
            lef_parse.parse_macro_lef(bad)

    def test_tech_lef(self):
        t = lef_parse.parse_tech_lef(TECH)
        self.assertEqual(t["sites"], {"CoreSite": [0.48, 3.78]})
        self.assertEqual([l["name"] for l in lef_parse.tech_summary(t)], ["Metal1", "Metal2"])   # CUT layer and VIA's LAYER ignored

    def test_liberty(self):
        s = lib_parse.summarize_corner(lib_parse.parse_liberty(LIB))
        self.assertEqual(s["cell"]["memory"], {"type": "ram", "address_width": 2, "word_width": 4})
        self.assertEqual(s["cell"]["leakage_nw"], 12.5)
        self.assertEqual(s["setup_ns"]["A"], {"min": -0.1, "max": 0.5})
        self.assertEqual(s["hold_ns"]["A"], {"min": 0.5, "max": 0.6})
        self.assertEqual(s["clk_to_out_ns"]["Q"]["max"], 3.2)
        self.assertEqual(s["clk_to_out_ns"]["Q"]["min"], 2.9)
        self.assertEqual(s["min_pulse_width_ns"]["high"], 0.3)
        self.assertEqual(s["voltage_map"], {"VDD": 1.2, "VDDA": 1.2})
        self.assertIsNone(s["min_period_ns"])             # nothing is invented when the library lacks a quantity
        self.assertEqual(s["when_conditions"], ["(EN)"])  # attribute without ';' parsed

    def test_liberty_units_scale(self):
        t = LIB.replace('leakage_power_unit : "1nW"', 'leakage_power_unit : "1mW"')
        s = lib_parse.summarize_corner(lib_parse.parse_liberty(t))
        self.assertEqual(s["cell"]["leakage_nw"], 12.5e6)

    def test_when_eval(self):
        e = lib_parse.eval_when
        env = {"CEN": 0, "GWEN": 1, "WEN[0]": 0, "WEN[1]": 1}
        self.assertEqual(e("((!CEN) & (GWEN))", env), 1)
        self.assertEqual(e("!CEN & !GWEN", env), 0)
        self.assertEqual(e("(!WEN[0] | !WEN[1]) & GWEN", env), 1)
        self.assertEqual(e("CEN | WEN[1]", env), 1)
        with self.assertRaises(KeyError):
            e("UNKNOWN", env)

    def test_vlog_ports(self):
        p = vlog_ports.parse_ports(VLOG)
        self.assertEqual(p["ports"]["a"], {"dir": "input", "width": 4})
        self.assertEqual(p["ports"]["q"], {"dir": "output", "width": 8})

    def test_ecc_ref(self):
        self.assertEqual([ecc_ref.nchk(k) for k in (1, 4, 5, 8, 11, 12, 16, 26, 27, 32, 57, 58, 64, 120, 121, 128, 247, 248, 502)],
                         [4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9, 9, 10, 10])
        for k in (8, 16, 32):
            d = 0xA5A5A5A5 & ((1 << k) - 1)
            c = ecc_ref.encode(d, k)
            self.assertEqual(ecc_ref.decode(d, c, k), (d, 0, 0))
            self.assertEqual(ecc_ref.decode(d ^ 1, c, k), (d, 1, 0))                 # data-bit error corrected
            self.assertEqual(ecc_ref.decode(d, c ^ 1, k), (d, 1, 0))                 # check-bit error corrected
            self.assertEqual(ecc_ref.decode(d ^ 3, c, k)[1:], (0, 1))                # double error detected

if __name__ == "__main__":
    unittest.main()
