"""Invariants of the generated manifests and of the RTL generated from them (no vendor files needed)."""
import glob, json, os, re, subprocess, sys, unittest
import common
from common import ROOT
import families


def _j(path):
    with open(path) as fh:
        return json.load(fh)


def rd(path):
    with open(path) as fh:
        return fh.read()

MAN = os.path.join(ROOT, "manifests")


def load_all():
    return {os.path.basename(f)[:-5]: _j(f) for f in glob.glob(os.path.join(MAN, "*.json")) if not f.endswith("catalog.json")}


class T(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = load_all()
        cls.cat = _j(os.path.join(MAN, "catalog.json"))

    def test_counts_and_ids(self):
        self.assertEqual(len(self.m), 25)
        self.assertEqual(self.cat["count"], 25)
        ids = [x["id"] for x in self.m.values()]
        self.assertEqual(sorted(ids), list(range(1, 26)))
        self.assertEqual(len(set(ids)), 25)

    def test_every_check_passed(self):
        for n, m in self.m.items():
            self.assertEqual(m["checks"]["status"], "PASS", n)
            self.assertEqual(m["checks"]["issues"], [], n)
            for k, v in (m["checks"]["sramlib_record_match"] or {}).items():
                self.assertTrue(v, "%s differs from the earlier SRAM library record in %s" % (n, k))
            for c in m["timing"]["corners"]:
                self.assertIn(c["polarity_check"], ("PASS", "NON_INFORMATIVE"), "%s %s" % (n, c["id"]))     # never FAIL / INDETERMINATE

    def test_names_come_from_files(self):
        for n, m in self.m.items():
            self.assertEqual(m["macro_name"], n)
            self.assertTrue(m["views"]["verilog"]["path"].endswith(n + ".v"), n)
            self.assertTrue(m["views"]["lef"]["path"].endswith(n + ".lef"), n)
            self.assertEqual(len(m["views"]["lef"]["sha256"]), 64)
            self.assertTrue(m["views"]["verilog"]["upstream"].startswith("https://raw.githubusercontent.com/"))
            for corner in m["views"]["liberty"].values():
                self.assertIn(m["views"]["verilog"]["upstream"].split("/")[5], corner["upstream"])   # same pinned commit

    def test_no_sleep_ecc_redundancy_anywhere(self):
        # absence is established from the pin lists (build_manifest fails on any pin not in the family table)
        for n, m in self.m.items():
            self.assertFalse(m["power"]["sleep_retention"]["supported"], n)
            self.assertFalse(m["ecc"]["builtin"], n)
            self.assertFalse(m["redundancy"]["present"], n)
            self.assertFalse(m["redundancy"]["repair_interface"], n)
            for c in m["timing"]["corners"]:
                self.assertEqual(c["power_states"], [], n)

    def test_physical_data_present(self):
        for n, m in self.m.items():
            g = m["geometry"]
            self.assertGreater(g["size_um"][0], 0)
            self.assertEqual(g["class"], "BLOCK")
            self.assertTrue(g["pg_pins"], n)
            self.assertTrue(g["tech_routing_layers"], n)
            self.assertTrue(g["routing_layers_free_above_macro"], n)
            self.assertIn(g["default_core_site"], g["tech_sites_um"], n)
            self.assertEqual(g["legal_orientations"], ["R0", "MX", "MY", "R180"], n)
            self.assertEqual(m["readiness"]["status"], "PHYSICAL_VIEWS_COMPLETE_SIGNOFF_PENDING")
            self.assertEqual(m["readiness"]["signoff"], {"drc": "NOT_RUN", "lvs": "NOT_RUN", "sta": "NOT_RUN", "ir_drop": "NOT_RUN"})
            nom = [c for c in m["timing"]["corners"] if c["id"] == m["timing"]["nominal_corner"]]
            self.assertEqual(len(nom), 1, n)
            self.assertGreater(nom[0]["clk_to_out_ns"]["max"], nom[0]["clk_to_out_ns"]["min"] - 1e-9)

    def test_family_facts(self):
        for n, m in self.m.items():
            f = m["family"]
            if f == "IHP_1P":
                self.assertEqual(m["semantics"]["write_mask"]["granularity_bits"], 1)
                self.assertEqual(m["semantics"]["write_mask"]["polarity"], "active_high")
                self.assertTrue(m["test"]["builtin_test_pins"])
                self.assertEqual(sorted(m["geometry"]["pg_pins"]), ["VDD!", "VDDARRAY!", "VSS!"])
                self.assertEqual(m["interface"]["pins"]["tie_high"][0]["name"], "A_DLY")
            if f == "GF180_1RW":
                self.assertEqual(m["semantics"]["write_mask"]["polarity"], "active_low")
                self.assertEqual(m["semantics"]["chip_enable"]["polarity"], "active_low")
                self.assertFalse(m["test"]["builtin_test_pins"])
                self.assertTrue(m["organization"]["dont_use_in_liberty"])
            if f == "SKY130_1RW1R":
                self.assertEqual(m["semantics"]["write_mask"]["granularity_bits"], 8)
                self.assertEqual(m["semantics"]["access_edge"], "falling")
                self.assertEqual(m["organization"]["ports"], "1RW1R")
            self.assertEqual(m["family_code"], families.FAMILY_CODE[f])

    def test_vendor_discrepancy_is_recorded_not_hidden(self):
        w = self.m["gf180mcu_fd_ip_sram__sram512x8m8wm1"]["checks"]["warnings"]
        self.assertTrue(any("spec Tah" in x for x in w))

    def test_gf180_spec_address_width_discrepancy_is_systematic(self):
        # the vendor spec CSV states A[6:0] for every GF180 macro; it is right only for the 128x8 macro
        bad = sorted(n for n, m in self.m.items() if any("1_pins_desc.csv lists A[6:0]" in w for w in m["checks"]["warnings"]))
        self.assertEqual(bad, ["gf180mcu_fd_ip_sram__sram256x8m8wm1", "gf180mcu_fd_ip_sram__sram512x8m8wm1", "gf180mcu_fd_ip_sram__sram64x8m8wm1"])
        self.assertEqual(self.m["gf180mcu_fd_ip_sram__sram128x8m8wm1"]["organization"]["address_width"], 7)

    def test_ihp_array_supply_equals_logic_supply(self):
        for n, m in self.m.items():
            if m["family"] == "IHP_1P":
                for c in m["timing"]["corners"]:
                    self.assertEqual(c["voltage_map"]["VDD"], c["voltage_map"]["VDDARRAY"], "%s %s" % (n, c["id"]))

    def test_rtl_generated_from_manifests_has_no_drift(self):
        r = subprocess.run([sys.executable, "-I", os.path.join(ROOT, "tools", "gen_rtl.py"), "--manifests", MAN, "--out", os.path.join(ROOT, "rtl"), "--check"],
                           capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)

    def test_only_catalogued_cell_names_are_instantiated(self):
        names = set(self.m)
        used = set()
        for f in glob.glob(os.path.join(ROOT, "rtl", "backends", "asic", "sf_sram_leaf_*.sv")):
            used |= set(re.findall(r"^\s+(\w+) u_macro \(", rd(f), flags=re.M))
        self.assertEqual(used, names)
        stubs = set(re.findall(r"^module (\w+) \(", rd(os.path.join(ROOT, "rtl/backends/asic/stubs/sf_sram_macro_blackboxes.sv")), flags=re.M))
        self.assertEqual(stubs, names)

    def test_stub_ports_match_vendor_model_ports_minus_pg(self):
        txt = rd(os.path.join(ROOT, "rtl/backends/asic/stubs/sf_sram_macro_blackboxes.sv"))
        for n, m in self.m.items():
            blk = re.search(r"module %s \((.*?)\);" % re.escape(n), txt, flags=re.S).group(1)
            ports = re.findall(r"(?:input|output|inout)\s*(?:\[(\d+):0\])?\s+(\w+)", blk)
            got = {p: (int(w) + 1 if w else 1) for w, p in ports}
            want = {p: v[1] for p, v in m["interface"]["verilog_ports"].items() if p not in m["power"]["supplies_lib"]}
            self.assertEqual(got, want, n)

if __name__ == "__main__":
    unittest.main()
