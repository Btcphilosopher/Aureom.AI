#!/bin/sh
# Build the delivery zip (no git operations).  Excludes build/ (scratch + vendor files) and Yosys intermediates.
#   sh scripts/package.sh [output.zip]      default: ../silicaflux-srammacrobridge-p79.zip
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd)
NAME=$(basename "$ROOT")
case "${1:-}" in
  "") OUT="$(cd .. && pwd)/$NAME-p79.zip" ;;
  /*) OUT="$1" ;;
  *)  OUT="$(pwd)/$1" ;;
esac
rm -f SHA256SUMS
find . -type f ! -path './build/*' ! -path '*/__pycache__/*' ! -name '*.pyc' ! -name SHA256SUMS ! -path './physical/*/netlist.json' | sort | xargs sha256sum > SHA256SUMS
cd ..
rm -f "$OUT"
zip -q -r "$OUT" "$NAME" -x "$NAME/build/*" "*/__pycache__/*" "*.pyc" "$NAME/physical/*/netlist.json"
echo "wrote $OUT"
