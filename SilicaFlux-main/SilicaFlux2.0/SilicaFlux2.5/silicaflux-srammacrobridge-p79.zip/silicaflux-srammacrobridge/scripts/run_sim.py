#!/usr/bin/env python3
"""SilicaFlux SRAMMacroBridge simulation / verification runner.

  python3 -I scripts/run_sim.py [--suite all|ecc|generic|fpga|asic|equiv|neg|agree] [--vendor build/vendor] [--jobs N] [--quick]

Suites
  ecc      sf_ecc_secded_enc/_dec against the independent Python golden vectors (tb/tb_ecc_vectors.sv), several K
  generic  tb_macro on the GENERIC backend: Icarus (4-state, poison) and Verilator (2-state); identical trace required
  fpga     tb_macro on the FPGA-inference backend (same two simulators)
  asic     tb_macro on the REAL vendor Verilog models of the open-PDK macros (Icarus).  Skipped (never PASS) when the vendor
           files are missing: fetch them with tools/fetch_vendor.py
  equiv    every ASIC config is re-run on the GENERIC backend with the same stimulus: response/trace hashes must be identical
  neg      illegal parameter sets must fail elaboration with the expected rule code, in Verilator AND Icarus
  agree    tools/sram_cfg_gen.py err_code() must equal the RTL ERR_CODE on a configuration matrix (legal and illegal)

Results: reports/sim.json and reports/sim.md.  Exit code 0 only if nothing failed (skips are reported, not hidden).
"""
import argparse
import concurrent.futures as cf
import hashlib
import itertools
import json
import os
import random
import re
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import sram_cfg_gen as G  # noqa: E402

RTL = ["rtl/ecc/sf_ecc_secded_enc.sv", "rtl/ecc/sf_ecc_secded_dec.sv", "rtl/backends/sf_sram_be_generic.sv", "rtl/backends/sf_sram_be_fpga.sv",
       "rtl/backends/asic/sf_sram_leaf_ihp1p.sv", "rtl/backends/asic/sf_sram_leaf_gf180.sv", "rtl/backends/asic/sf_sram_leaf_sky130.sv",
       "rtl/backends/sf_sram_be_asic.sv", "rtl/sf_sram_macro_wrapper.sv"]
STUBS = "rtl/backends/asic/stubs/sf_sram_macro_blackboxes.sv"
INC = ["-I" + os.path.join(ROOT, "rtl"), "-I" + os.path.join(ROOT, "rtl/ecc"), "-I" + os.path.join(ROOT, "rtl/backends")]
BUILD = os.path.join(ROOT, "build", "sim")


def rtl(*extra):
    return [os.path.join(ROOT, f) for f in RTL] + list(extra)


def sh(cmd, cwd=None, timeout=1800, env=None):
    t0 = time.time()
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
    return p.returncode, p.stdout + p.stderr, time.time() - t0


def parse_result(out):
    m = re.findall(r"SF_TB_RESULT: (PASS|FAIL)(.*)", out)
    if not m:
        return None
    st, rest = m[-1]
    kv = dict(re.findall(r"(\w+)=(\S+)", rest))
    return {"status": st, "checks": int(kv.get("checks", 0)), "errors": int(kv.get("errors", 0)), "trace": kv.get("trace"), "raw": rest.strip()}


# ----------------------------------------------------------------------------------------- vendor model file lists
def vendor_files(vendor, macro_id, catalog, manifests):
    m = catalog[macro_id]
    man = json.load(open(os.path.join(manifests, m["macro_name"] + ".json")))
    src = {"IHP_1P": "ihp_sg13g2", "GF180_1RW": "gf180mcu", "SKY130_1RW1R": "sky130_openram"}[m["family"]]
    files = [os.path.join(vendor, src, man["views"]["verilog"]["path"])]
    defs = []
    if m["family"] == "IHP_1P":
        files.insert(0, os.path.join(vendor, src, os.path.dirname(man["views"]["verilog"]["path"]), "RM_IHPSG13_1P_core_behavioral_bm_bist.v"))
        defs.append("-DFUNCTIONAL")
    if m["family"] == "GF180_1RW":
        defs.append("-DSF_MACRO_VENDOR_INPUT_DELAY")      # GF180 model samples 100 ps after the edge (see the leaf header)
    for f in files:
        if not os.path.isfile(f):
            return None, None, f
    return files, defs, None


# ----------------------------------------------------------------------------------------- simulators
def build_icarus(tag, params, defs, vendor_srcs, include_stubs):
    os.makedirs(BUILD, exist_ok=True)
    out = os.path.join(BUILD, "ic_%s" % tag)
    cmd = ["iverilog", "-g2012", "-Wno-timescale"] + INC + defs
    for k, v in params.items():
        cmd.append("-Ptb_macro.%s=%s" % (k, v))
    cmd += ["-o", out, os.path.join(ROOT, "tb/tb_macro.sv")] + rtl()
    if include_stubs:
        cmd.append(os.path.join(ROOT, STUBS))
    cmd += vendor_srcs
    rc, log, _ = sh(cmd)
    return rc, log, out


def run_icarus(tag, params, defs=(), vendor_srcs=(), include_stubs=True, timeout=1800, expect_asserts=None):
    rc, log, exe = build_icarus(tag, params, list(defs), list(vendor_srcs), include_stubs)
    if rc != 0:
        return {"status": "FAIL", "why": "iverilog compile failed", "log": log[-600:]}
    t0 = time.time()
    rc, out, dt = sh(["vvp", "-n", exe], timeout=timeout)
    res = parse_result(out)
    asserts = len(re.findall(r"SF_MACRO_ASSERT_", out))
    if res is None:
        return {"status": "FAIL", "why": "no SF_TB_RESULT line", "log": out[-600:]}
    if expect_asserts is not None:
        only = len(re.findall(r"SF_MACRO_ASSERT_HANDOVER", out))
        if asserts != expect_asserts or only != expect_asserts:
            res["status"] = "FAIL"
            res["why"] = "expected exactly %d SF_MACRO_ASSERT_HANDOVER, saw %d assertions (%d handover)" % (expect_asserts, asserts, only)
        res["detail"] = "%d hand-over assertions as expected; dropped accesses never reached the array" % only if res["status"] == "PASS" else res.get("why")
    elif asserts:
        res["status"] = "FAIL"
        res["why"] = "%d protocol assertion(s) fired" % asserts
        res["log"] = "\n".join(l for l in out.splitlines() if "SF_MACRO_ASSERT_" in l)[:600]
    if res["status"] != "PASS" and "log" not in res:
        res["log"] = "\n".join(l for l in out.splitlines() if "TB ERROR" in l or "got" in l or "expected" in l)[:800]
    res["seconds"] = round(dt, 1)
    return res


def run_verilator(tag, params, defs=(), timeout=1800):
    d = os.path.join(BUILD, "vl_%s" % tag)
    shutil.rmtree(d, ignore_errors=True)
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "--top-module", "tb_macro",
           "-Mdir", d, "-j", "1"] + INC + list(defs)
    for k, v in params.items():
        cmd.append("-G%s=%s" % (k, v))
    cmd += [os.path.join(ROOT, "tb/tb_macro.sv")] + rtl() + [os.path.join(ROOT, STUBS)]
    rc, log, _ = sh(cmd, timeout=timeout)
    if rc != 0:
        return {"status": "FAIL", "why": "verilator build failed", "log": log[-800:]}
    rc, out, dt = sh([os.path.join(d, "Vtb_macro")], timeout=timeout)
    res = parse_result(out)
    if res is None:
        return {"status": "FAIL", "why": "no SF_TB_RESULT line", "log": out[-600:]}
    res["seconds"] = round(dt, 1)
    return res


# ----------------------------------------------------------------------------------------- configuration matrix
def P(**k):
    return k


GENERIC = [
    ("g01_default_32x1024", P(), {}),
    ("g02_l2_lane_ecc_test_power", P(READ_LATENCY=2, ECC_MODE=2, TEST_MODE=1, POWER_CTRL=1, DEPTH_WORDS=256, NCYC=3000), {"poison": 1}),
    ("g03_l3_depth300_nonpow2", P(READ_LATENCY=3, DEPTH_WORDS=300, TEST_MODE=1), {"poison": 1}),
    ("g04_word_ecc_64b_be0", P(DATA_WIDTH=64, BYTE_ENABLE=0, ECC_MODE=1, TEST_MODE=1, DEPTH_WORDS=256), {}),
    ("g05_9bit_lanes_36b_lane_ecc", P(DATA_WIDTH=36, BYTE_WIDTH=9, ECC_MODE=2, TEST_MODE=1, DEPTH_WORDS=200), {}),
    ("g06_odd_width_13b_be0", P(DATA_WIDTH=13, BYTE_ENABLE=0, DEPTH_WORDS=100, TEST_MODE=1), {}),
    ("g07_128b_32b_lanes_lane_ecc_l2", P(DATA_WIDTH=128, BYTE_WIDTH=32, ECC_MODE=2, READ_LATENCY=2, TEST_MODE=1, DEPTH_WORDS=128, NCYC=2500), {}),
    ("g08_power_wake1", P(POWER_CTRL=1, WAKE_CYCLES=1, DEPTH_WORDS=64), {}),
    ("g09_power_wake4_ecc", P(POWER_CTRL=1, WAKE_CYCLES=4, ECC_MODE=2, TEST_MODE=1, DEPTH_WORDS=64), {}),
    ("g10_handover_negative", P(TEST_MODE=1, DEPTH_WORDS=64, NEG_TEST=1, NCYC=500), {"icarus_only": 1}),
]
FPGA = [
    ("f01_auto_32x1024", P(MEMORY_TECH=1), {}),
    ("f02_block_l2_test", P(MEMORY_TECH=1, FPGA_RAM_STYLE=1, READ_LATENCY=2, TEST_MODE=1, DEPTH_WORDS=300), {"poison": 1}),
    ("f03_ultra_72b_be0_word_ecc", P(MEMORY_TECH=1, FPGA_RAM_STYLE=2, DATA_WIDTH=64, BYTE_ENABLE=0, ECC_MODE=1, TEST_MODE=1, DEPTH_WORDS=512), {}),
    ("f04_dist_lane_ecc_power", P(MEMORY_TECH=1, FPGA_RAM_STYLE=3, ECC_MODE=2, POWER_CTRL=1, TEST_MODE=1, DEPTH_WORDS=64), {}),
]
# ASIC: (name, tb params, generic-equivalent params (functional part only))
ASIC = [
    ("a_ihp04_256x32_1macro_test", P(MEMORY_TECH=10, MACRO_ID=4, DEPTH_WORDS=256, TEST_MODE=1), {}),
    ("a_ihp06_256x64_tiled_ecc_lane_test", P(MEMORY_TECH=10, MACRO_ID=6, DATA_WIDTH=64, BYTE_WIDTH=32, ECC_MODE=2, DEPTH_WORDS=1000, TEST_MODE=1, NCYC=2500), {}),
    ("a_ihp01_64x64_rows16_l2", P(MEMORY_TECH=10, MACRO_ID=1, DATA_WIDTH=32, DEPTH_WORDS=1000, READ_LATENCY=2, TEST_MODE=1), {}),
    ("a_ihp02_256x8_cols_word_ecc_l3", P(MEMORY_TECH=10, MACRO_ID=2, DATA_WIDTH=64, BYTE_ENABLE=0, ECC_MODE=1, DEPTH_WORDS=700, READ_LATENCY=3, TEST_MODE=1, NCYC=2500), {}),
    ("a_ihp15_2048x32_4096words", P(MEMORY_TECH=10, MACRO_ID=15, DATA_WIDTH=32, DEPTH_WORDS=4096, TEST_MODE=1, MARCH_ADDRS=512, NCYC=3000), {}),
    ("a_ihp09_512x32_9bit_lanes", P(MEMORY_TECH=10, MACRO_ID=9, DATA_WIDTH=36, BYTE_WIDTH=9, DEPTH_WORDS=600, TEST_MODE=1), {}),
    ("a_gf20_128x8_tiled_test", P(MEMORY_TECH=11, MACRO_ID=20, DEPTH_WORDS=300, TEST_MODE=1), {}),
    ("a_gf19_64x8_lane_ecc_test", P(MEMORY_TECH=11, MACRO_ID=19, DATA_WIDTH=32, ECC_MODE=2, DEPTH_WORDS=130, TEST_MODE=1), {}),
    ("a_gf22_512x8_be0_word_ecc_l2", P(MEMORY_TECH=11, MACRO_ID=22, DATA_WIDTH=24, BYTE_ENABLE=0, ECC_MODE=1, DEPTH_WORDS=600, READ_LATENCY=2, TEST_MODE=1), {}),
    ("a_gf21_256x8_4bit_lanes", P(MEMORY_TECH=11, MACRO_ID=21, DATA_WIDTH=24, BYTE_WIDTH=4, DEPTH_WORDS=300, TEST_MODE=1), {}),
    ("a_sky23_256x32_tiled_test", P(MEMORY_TECH=12, MACRO_ID=23, DEPTH_WORDS=700, TEST_MODE=1), {}),
    ("a_sky24_512x32_word_ecc_be0_l2", P(MEMORY_TECH=12, MACRO_ID=24, DATA_WIDTH=32, BYTE_ENABLE=0, ECC_MODE=1, DEPTH_WORDS=1100, READ_LATENCY=2, TEST_MODE=1), {}),
    ("a_sky25_1024x8_16b_2lanes", P(MEMORY_TECH=12, MACRO_ID=25, DATA_WIDTH=16, DEPTH_WORDS=1500, TEST_MODE=1), {}),
    # the four reference configurations of configs/reference_configs.json (their floorplans live in physical/): simulated with the same macros
    ("a_ref_sfv_a_ihp15_128b_lane_ecc", P(MEMORY_TECH=10, MACRO_ID=15, DATA_WIDTH=128, BYTE_WIDTH=32, ECC_MODE=2, DEPTH_WORDS=2048, READ_LATENCY=2, TEST_MODE=1, MARCH_ADDRS=512, NCYC=2500), {}),
    ("a_ref_sfv_b_ihp18_128b_lane_ecc", P(MEMORY_TECH=10, MACRO_ID=18, DATA_WIDTH=128, BYTE_WIDTH=32, ECC_MODE=2, DEPTH_WORDS=4096, READ_LATENCY=2, TEST_MODE=1, MARCH_ADDRS=256, NCYC=2500), {}),
    ("a_ref_sfv_gf_gf22_32b", P(MEMORY_TECH=11, MACRO_ID=22, DATA_WIDTH=32, DEPTH_WORDS=1024, READ_LATENCY=1, TEST_MODE=0, NCYC=2500), {}),
    ("a_ref_sfv_sky_sky24_64b", P(MEMORY_TECH=12, MACRO_ID=24, DATA_WIDTH=64, DEPTH_WORDS=1536, READ_LATENCY=1, TEST_MODE=1, MARCH_ADDRS=512, NCYC=2500), {}),
    ("a_ihp04_handover_negative", P(MEMORY_TECH=10, MACRO_ID=4, DEPTH_WORDS=256, TEST_MODE=1, NEG_TEST=1, NCYC=500), {}),
    ("a_gf20_handover_negative", P(MEMORY_TECH=11, MACRO_ID=20, DEPTH_WORDS=300, TEST_MODE=1, NEG_TEST=1, NCYC=500), {}),
    ("a_sky23_handover_negative", P(MEMORY_TECH=12, MACRO_ID=23, DEPTH_WORDS=300, TEST_MODE=1, NEG_TEST=1, NCYC=500), {}),
]

# negative elaboration tests: params -> expected rule code
NEG = [
    (1, P(DATA_WIDTH=0)), (1, P(DATA_WIDTH=2000)), (2, P(DEPTH_WORDS=1)), (3, P(READ_LATENCY=0)), (3, P(READ_LATENCY=17)),
    (4, P(BYTE_ENABLE=2)), (5, P(DATA_WIDTH=30, BYTE_WIDTH=8)), (5, P(BYTE_WIDTH=0)),
    (6, P(MEMORY_TECH=19)), (7, P(MEMORY_TECH=5)), (8, P(ECC_MODE=3)),
    (9, P(ECC_MODE=1)), (10, P(ECC_MODE=2, BYTE_ENABLE=0)), (11, P(ECC_MODE=1, DATA_WIDTH=600, BYTE_ENABLE=0)),
    (12, P(TEST_MODE=2)), (13, P(POWER_CTRL=2)), (14, P(POWER_CTRL=1, WAKE_CYCLES=0)), (14, P(POWER_CTRL=1, WAKE_CYCLES=9)),
    (15, P(INIT_MODE=7)), (16, P(INIT_MODE=2)), (18, P(FPGA_RAM_STYLE=9, MEMORY_TECH=1)), (19, P(MACRO_ID=3)),
    (20, P(MEMORY_TECH=10, MACRO_ID=4, INIT_MODE=1)), (21, P(MEMORY_TECH=10, MACRO_ID=0)), (21, P(MEMORY_TECH=10, MACRO_ID=99)),
    (22, P(MEMORY_TECH=11, MACRO_ID=4)), (22, P(MEMORY_TECH=12, MACRO_ID=19)),
    (24, P(MEMORY_TECH=12, MACRO_ID=23, DATA_WIDTH=36, BYTE_WIDTH=9)),
    (24, P(MEMORY_TECH=12, MACRO_ID=23, DATA_WIDTH=32, BYTE_WIDTH=8, ECC_MODE=2)),
    (26, P(MEMORY_TECH=10, MACRO_ID=4, POWER_CTRL=1)), (26, P(MEMORY_TECH=11, MACRO_ID=19, POWER_CTRL=1)),
    (28, P(MEMORY_TECH=11, MACRO_ID=19, DATA_WIDTH=128, DEPTH_WORDS=65536)),
]
# Rules E23 (macro without write mask), E25 (built-in ECC macro) and E27 (READ_LATENCY below macro latency) are data-driven
# and cannot fire with the current catalogue (every macro has a write mask, no built-in ECC, native latency 1 = the minimum):
# they are covered at generator level with synthetic manifests in tests/test_generator.py, not by an RTL run.


def v_params(p):
    return ["-G%s=%s" % (k, v if not isinstance(v, str) else '"%s"' % v) for k, v in p.items()]


def verilator_elab(p, extra_defs=()):
    cmd = ["verilator", "--lint-only", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module", "sf_sram_macro_wrapper"] + INC + list(extra_defs) + v_params(p) + \
          rtl(os.path.join(ROOT, STUBS))
    rc, out, _ = sh(cmd)
    m = re.search(r"sf_sram_macro_wrapper\[E(\d\d)\]", out)
    return (int(m.group(1)) if m else 0), rc, out


def icarus_elab(tag, p):
    os.makedirs(BUILD, exist_ok=True)
    top = os.path.join(BUILD, "neg_top.sv")
    if not os.path.isfile(top):
        open(top, "w").write("`timescale 1ns/1ps\nmodule neg_top;\n  reg clk = 0;\n"
                             "  sf_sram_macro_wrapper u (.clk(clk), .ce(1'b0), .we(1'b0), .wmask('0), .idx('0), .wdata('0), .tst_active(1'b0), .tst_ce(1'b0),\n"
                             "                          .tst_we(1'b0), .tst_idx('0), .tst_wdata('0), .pwr_sleep(1'b0));\n  initial #1 $finish;\nendmodule\n")
    # parameters are overridden through a defparam-free wrapper: generate a top per test
    t = os.path.join(BUILD, "neg_%s.sv" % tag)
    ov = ", ".join(".%s(%s)" % (k, v if not isinstance(v, str) else '"%s"' % v) for k, v in p.items())
    open(t, "w").write("`timescale 1ns/1ps\nmodule neg_top_%s;\n  reg clk = 0;\n  sf_sram_macro_wrapper #(%s) u (.clk(clk), .ce(1'b0), .we(1'b0), .wmask('0), .idx('0), .wdata('0),\n"
                       "    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_idx('0), .tst_wdata('0), .pwr_sleep(1'b0));\n  initial #1 $finish;\nendmodule\n" % (tag, ov))
    exe = os.path.join(BUILD, "neg_%s" % tag)
    rc, log, _ = sh(["iverilog", "-g2012", "-Wno-timescale"] + INC + ["-s", "neg_top_%s" % tag, "-o", exe, t] + rtl(os.path.join(ROOT, STUBS)))
    if rc != 0:
        return -1, log
    rc, out, _ = sh(["vvp", "-n", exe])
    m = re.search(r"sf_sram_macro_wrapper\[E(\d\d)\]", out)
    return (int(m.group(1)) if m else 0), out


# ----------------------------------------------------------------------------------------- suites
def suite_ecc(a, R):
    ks = [8, 13, 16, 32, 39, 64, 128]
    os.makedirs(BUILD, exist_ok=True)
    for k in ks:
        vec = os.path.join(ROOT, "tb", "vectors", "ecc_vec_k%d.mem" % k)
        exe = os.path.join(BUILD, "ecc_%d" % k)
        rc, log, _ = sh(["iverilog", "-g2012"] + INC + ["-P", "tb_ecc_vectors.K=%d" % k, "-P", 'tb_ecc_vectors.VEC="%s"' % vec, "-o", exe,
                                                        os.path.join(ROOT, "tb/tb_ecc_vectors.sv"), os.path.join(ROOT, "rtl/ecc/sf_ecc_secded_enc.sv"),
                                                        os.path.join(ROOT, "rtl/ecc/sf_ecc_secded_dec.sv")])
        if rc != 0:
            R.append({"suite": "ecc", "name": "ecc_vectors_K%d" % k, "status": "FAIL", "why": "compile", "log": log[-400:]})
            continue
        rc, out, _ = sh(["vvp", "-n", exe])
        m = re.findall(r"SF_TB_RESULT: (PASS|FAIL) (.*)", out)
        R.append({"suite": "ecc", "name": "ecc_vectors_K%d" % k, "status": m[-1][0] if m else "FAIL", "detail": m[-1][1] if m else out[-300:]})


def run_cfg(job):
    suite, name, kind, params, defs, srcs, stubs = job
    p = dict(params)
    base = re.sub(r"\W", "_", name)
    if kind == "icarus":
        r = run_icarus(base + "_ic", p, defs, srcs, stubs, expect_asserts=4 if p.get("NEG_TEST") else None)
    else:
        r = run_verilator(base + "_vl", p, defs)
    r.update({"suite": suite, "name": name, "sim": kind, "params": p})
    return r


def suite_sim(a, R, name, table, vendor=None, catalog=None, manifests=None):
    jobs = []
    for nm, params, opt in table:
        params = dict(params)
        if a.quick:
            params["NCYC"] = min(params.get("NCYC", 4000), 1000)
        defs = []
        srcs, stubs = [], True
        if name == "asic":
            files, d2, missing = vendor_files(vendor, params["MACRO_ID"], catalog, manifests)
            if files is None:
                R.append({"suite": name, "name": nm, "sim": "icarus", "status": "SKIPPED", "why": "vendor file missing: %s (run tools/fetch_vendor.py)" % missing})
                continue
            srcs, defs, stubs = files, d2, False
            jobs.append((name, nm, "icarus", params, defs, srcs, stubs))
            continue
        if opt.get("poison"):
            jobs.append((name, nm, "icarus", dict(params, POISON=1), ["-DSF_MACRO_POISON"], srcs, stubs))
        else:
            jobs.append((name, nm, "icarus", params, defs, srcs, stubs))
        if not opt.get("icarus_only"):
            jobs.append((name, nm, "verilator", params, defs, srcs, stubs))
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run_cfg, jobs))
    R.extend(res)
    # cross-simulator trace equality (Icarus vs Verilator) for GENERIC/FPGA (poison does not change the hash: X outputs are not hashed)
    by = {}
    for r in res:
        by.setdefault(r["name"], {})[r["sim"]] = r
    for nm, d in by.items():
        if "icarus" in d and "verilator" in d and d["icarus"].get("trace") and d["verilator"].get("trace"):
            same = d["icarus"]["trace"] == d["verilator"]["trace"] and d["icarus"]["checks"] == d["verilator"]["checks"]
            R.append({"suite": name, "name": nm + "::icarus_vs_verilator_trace", "status": "PASS" if same else "FAIL",
                      "detail": "%s/%s checks %s/%s" % (d["icarus"]["trace"], d["verilator"]["trace"], d["icarus"]["checks"], d["verilator"]["checks"])})


def suite_equiv(a, R, vendor, catalog, manifests):
    """Each ASIC config re-run on the GENERIC backend: same stimulus => identical trace."""
    jobs = []
    for nm, params, opt in ASIC:
        files, d2, missing = vendor_files(vendor, params["MACRO_ID"], catalog, manifests)
        if files is None:
            R.append({"suite": "equiv", "name": nm, "status": "SKIPPED", "why": "vendor file missing"})
            continue
        gp = dict(params, MEMORY_TECH=0, MACRO_ID=0)
        if a.quick:
            gp["NCYC"] = min(gp.get("NCYC", 4000), 1000)
        jobs.append(("equiv", nm + "::generic", "icarus", gp, [], [], True))
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        gen = list(ex.map(run_cfg, jobs))
    asic_by = {r["name"]: r for r in R if r.get("suite") == "asic" and r.get("sim") == "icarus"}
    for g in gen:
        nm = g["name"].replace("::generic", "")
        ar = asic_by.get(nm)
        if not ar or ar.get("status") != "PASS" or g.get("status") != "PASS":
            R.append({"suite": "equiv", "name": nm, "status": "FAIL", "why": "asic or generic run did not pass", "detail": "asic=%s generic=%s" % (ar and ar.get("status"), g.get("status"))})
            continue
        same = ar["trace"] == g["trace"] and ar["checks"] == g["checks"]
        R.append({"suite": "equiv", "name": nm, "status": "PASS" if same else "FAIL", "detail": "asic trace %s generic trace %s (%d checks)" % (ar["trace"], g["trace"], ar["checks"])})


def suite_neg(a, R):
    def one(item):
        k, (code, p) = item
        vc, rc, out = verilator_elab(p)
        ic, iout = icarus_elab("n%d" % k, p)
        ok = vc == code and ic == code
        return {"suite": "neg", "name": "E%02d %s" % (code, json.dumps(p, sort_keys=True)), "status": "PASS" if ok else "FAIL",
                "detail": "expected E%02d, verilator E%02d, icarus E%02d" % (code, vc, ic)}
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        R.extend(ex.map(one, list(enumerate(NEG))))
    # a legal configuration must NOT raise
    legal = [P(), P(MEMORY_TECH=1), P(MEMORY_TECH=10, MACRO_ID=4), P(MEMORY_TECH=11, MACRO_ID=19), P(MEMORY_TECH=12, MACRO_ID=23)]
    for p in legal:
        vc, rc, out = verilator_elab(p)
        R.append({"suite": "neg", "name": "legal %s elaborates" % json.dumps(p, sort_keys=True), "status": "PASS" if vc == 0 and "Error" not in out.split("Warning")[0] else "FAIL", "detail": "rule code %d" % vc})
    # PATTERN init is rejected when SYNTHESIS is defined (E17), accepted otherwise
    vc, rc, out = verilator_elab(P(INIT_MODE=3), ["-DSYNTHESIS"])
    R.append({"suite": "neg", "name": "E17 INIT_MODE=PATTERN with SYNTHESIS", "status": "PASS" if vc == 17 else "FAIL", "detail": "got E%02d" % vc})
    vc, rc, out = verilator_elab(P(INIT_MODE=3))
    R.append({"suite": "neg", "name": "INIT_MODE=PATTERN allowed in simulation", "status": "PASS" if vc == 0 else "FAIL", "detail": "got E%02d" % vc})


def suite_agree(a, R, catalog):
    """Random configurations biased toward structurally sensible ones (so deeper rules are reached), plus every
    rule's boundary.  For each: tools/sram_cfg_gen.err_code() must equal the rule code the RTL reports."""
    rnd = random.Random(7)
    techs = [(0, 0), (1, 0)] + [(m["family_code"], mid) for mid, m in catalog.items()] * 2
    cfgs = []
    for i in range(320):
        tech, mid = rnd.choice(techs)
        dw = rnd.choice([8, 9, 12, 16, 24, 32, 36, 40, 48, 64, 72, 128, 200, 1024])
        divs = [b for b in (4, 8, 9, 12, 16, 18, 32, 36, 64) if dw % b == 0] or [8]
        bw = rnd.choice(divs) if rnd.random() < 0.8 else rnd.choice([0, 3, 5, 8, 64])
        be = 1 if rnd.random() < 0.7 else 0
        ecc = rnd.choice([0, 2, 2, 0] if be else [0, 1, 1])
        if rnd.random() < 0.06:
            ecc = rnd.choice([0, 1, 2, 3])
        if tech and rnd.random() < 0.08:                      # wrong family / unknown id / MACRO_ID on a non-ASIC tech
            mid = rnd.choice([0, 99, rnd.choice(list(catalog))])
        c = {"DATA_WIDTH": dw, "DEPTH_WORDS": rnd.choice([2, 64, 100, 256, 300, 1000, 4096, 20000, 70000]), "READ_LATENCY": rnd.choice([1, 1, 2, 3]),
             "BYTE_ENABLE": be, "BYTE_WIDTH": bw, "MEMORY_TECH": tech, "MACRO_ID": mid, "ECC_MODE": ecc,
             "TEST_MODE": rnd.choice([0, 1]), "POWER_CTRL": rnd.choice([0, 0, 0, 1]),
             "INIT_MODE": rnd.choice([0, 0, 0, 0, 1, 3])}
        cfgs.append(c)
    cfgs += [{"DATA_WIDTH": 1024, "DEPTH_WORDS": 2, "BYTE_ENABLE": 0}, {"DATA_WIDTH": 1025}, {"DATA_WIDTH": 502, "ECC_MODE": 1, "BYTE_ENABLE": 0},
             {"DATA_WIDTH": 503, "ECC_MODE": 1, "BYTE_ENABLE": 0}, {"DEPTH_WORDS": 1 << 30}, {"DEPTH_WORDS": (1 << 30) + 1}]
    cfgs = [dict({"DATA_WIDTH": 32, "BYTE_WIDTH": 8, "MEMORY_TECH": 0, "MACRO_ID": 0, "READ_LATENCY": 1, "BYTE_ENABLE": 1, "DEPTH_WORDS": 64}, **c) for c in cfgs]

    def one(c):
        py = G.err_code(c, catalog)
        vc, rc, out = verilator_elab({k: v for k, v in c.items()})
        # rule 28 / large arrays still elaborate in lint-only mode; non-fatal errors other than USERFATAL would show as rc != 0 with code 0
        return {"cfg": c, "python": py, "rtl": vc}
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(one, cfgs))
    bad = [r for r in res if r["python"] != r["rtl"]]
    hist = {}
    for r in res:
        hist[r["python"]] = hist.get(r["python"], 0) + 1
    R.append({"suite": "agree", "name": "sram_cfg_gen.err_code == RTL ERR_CODE on %d configurations" % len(res), "status": "PASS" if not bad else "FAIL",
              "detail": "rule histogram %s%s" % (json.dumps(hist, sort_keys=True), ("; MISMATCH: %s" % bad[:3]) if bad else "")})


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--suite", default="all")
    ap.add_argument("--vendor", default=os.environ.get("SF_VENDOR_DIR", os.path.join(ROOT, "build", "vendor")))
    ap.add_argument("--manifests", default=os.path.join(ROOT, "manifests"))
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2) - 0))
    ap.add_argument("--quick", action="store_true", help="shorter random phases (smoke test)")
    ap.add_argument("--out", default=os.path.join(ROOT, "reports"))
    a = ap.parse_args(argv)
    catalog = G.load_catalog(a.manifests)
    want = set(["ecc", "generic", "fpga", "asic", "equiv", "neg", "agree"] if a.suite == "all" else a.suite.split(","))
    R = []
    t0 = time.time()
    if "ecc" in want:
        suite_ecc(a, R)
    if "generic" in want:
        suite_sim(a, R, "generic", GENERIC)
    if "fpga" in want:
        suite_sim(a, R, "fpga", FPGA)
    if "asic" in want or "equiv" in want:
        if "asic" in want:
            suite_sim(a, R, "asic", ASIC, a.vendor, catalog, a.manifests)
    if "equiv" in want:
        if "asic" not in want:
            suite_sim(a, R, "asic", ASIC, a.vendor, catalog, a.manifests)
        suite_equiv(a, R, a.vendor, catalog, a.manifests)
    if "neg" in want:
        suite_neg(a, R)
    if "agree" in want:
        suite_agree(a, R, catalog)
    summ = {}
    for r in R:
        summ.setdefault(r["suite"], {}).setdefault(r["status"], 0)
        summ[r["suite"]][r["status"]] += 1
    os.makedirs(a.out, exist_ok=True)
    tools = {}
    for t, c in (("iverilog", ["iverilog", "-V"]), ("verilator", ["verilator", "--version"]), ("yosys", ["yosys", "-V"])):
        try:
            tools[t] = subprocess.run(c, capture_output=True, text=True).stdout.splitlines()[0]
        except Exception:
            tools[t] = "not available"
    json.dump({"tools": tools, "seconds": round(time.time() - t0, 1), "summary": summ, "results": R}, open(os.path.join(a.out, "sim.json"), "w"), indent=1)
    with open(os.path.join(a.out, "sim.md"), "w") as f:
        f.write("# Simulation / verification results\n\nTools: %s\n\n| suite | PASS | FAIL | SKIPPED |\n|---|---|---|---|\n" % ", ".join("%s: %s" % kv for kv in tools.items()))
        for s, d in sorted(summ.items()):
            f.write("| %s | %d | %d | %d |\n" % (s, d.get("PASS", 0), d.get("FAIL", 0), d.get("SKIPPED", 0)))
        f.write("\n| suite | test | sim | status | checks | trace | detail |\n|---|---|---|---|---|---|---|\n")
        for r in R:
            f.write("| %s | %s | %s | %s | %s | %s | %s |\n" % (r["suite"], r["name"], r.get("sim", ""), r["status"], r.get("checks", ""), r.get("trace", ""),
                                                                 (r.get("detail") or r.get("why") or "").replace("|", "/")[:160]))
    for s, d in sorted(summ.items()):
        print("%-8s %s" % (s, d))
    fails = [r for r in R if r["status"] == "FAIL"]
    for r in fails[:12]:
        print("FAIL:", r["suite"], r["name"], r.get("sim", ""), r.get("why", ""), (r.get("log") or r.get("detail") or "")[:300].replace("\n", " | "))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
