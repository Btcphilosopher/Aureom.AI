#!/usr/bin/env python3
"""Regenerate every reference plan, synthesis top, instance list, floorplan and floorplan check from configs/reference_configs.json.

  python3 -I scripts/make_plans.py
"""
import json
import os
import subprocess
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PY = [sys.executable, "-I"]


def run(*a):
    r = subprocess.run(PY + [os.path.join(ROOT, a[0])] + list(a[1:]), capture_output=True, text=True, cwd=ROOT)
    if r.returncode != 0:
        print(r.stdout + r.stderr)
        sys.exit("failed: %s" % " ".join(a))
    return r.stdout


def main():
    with open(os.path.join(ROOT, "configs", "reference_configs.json")) as fh:
        cfgs = json.load(fh)["configs"]
    for c in cfgs:
        n = c["name"]
        args = ["tools/sram_cfg_gen.py", "emit", "--name", n, "--tech", c["tech"], "--width", str(c["width"]), "--words", str(c["words"]),
                "--lane-bits", str(c["lane_bits"]), "--ecc", c["ecc"], "--read-latency", str(c["read_latency"]), "--out", "configs/generated"]
        if c.get("test"):
            args.append("--test")
        run(*args)
        run("tools/synth_instances.py", "--plan", "configs/generated/%s.plan.json" % n, "--top", "configs/generated/%s.top.sv" % n, "--out", "physical/%s" % n)
        print(run("tools/gen_floorplan.py", "--plan", "configs/generated/%s.plan.json" % n, "--instances", "physical/%s/instances.json" % n,
                  "--out", "physical/%s" % n).strip())
        print(run("tools/check_floorplan.py", "physical/%s" % n, "--report", "physical/%s/check.json" % n).strip().splitlines()[-1])


if __name__ == "__main__":
    main()
