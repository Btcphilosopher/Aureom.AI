#!/usr/bin/env python3
"""Yosys synthesis evidence for the three backends.

  python3 -I scripts/run_synth.py [--out reports]

GENERIC : generic `synth` of the wrapper: the behavioural array maps to flip-flops (informational: this is NOT an ASIC
          SRAM); zero latches.
FPGA    : `synth_xilinx -family xc7|xcup`, `synth_ice40`, `synth_ecp5`: the inferred array must map to the family's block RAM
          (RAMB36E1/RAMB18E1, URAM288 where Yosys supports it, SB_RAM40_4K, DP16KD) with no unmapped `$mem`, zero latches.
          Vivado/Quartus were NOT run (no vendor tools); only Yosys's inference is evidenced.
ASIC    : generic `synth -flatten` with the macros as black boxes: the number of macro instances equals the planned
          rows x columns, no `$mem` and no latch remains, and the glue logic (ECC, row mux, test mux) is counted.
Every job also records the Yosys version and the SHA-256 of the RTL.
"""
import argparse
import concurrent.futures as cf
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import sram_cfg_gen as G  # noqa: E402
import synth_instances as SI  # noqa: E402

RTLS = [os.path.join(ROOT, "rtl", f) for f in SI.RTL_FILES]
TOP = "sf_sram_macro_wrapper"


def yosys_stat(params, flow):
    """Run one Yosys job; returns (ok, cell-type counts of the flattened top, log tail)."""
    with tempfile.TemporaryDirectory() as td:
        js = os.path.join(td, "stat.json")
        ys = os.path.join(td, "run.ys")
        ch = " ".join("-set %s %s" % (k, v) for k, v in params.items())
        with open(ys, "w") as f:
            f.write("read_verilog -sv -defer -I%s/rtl -I%s/rtl/ecc -I%s/rtl/backends %s\n" % (ROOT, ROOT, ROOT, " ".join(RTLS)))
            if ch:
                f.write("chparam %s %s\n" % (ch, TOP))
            f.write("hierarchy -check -top %s\n" % TOP)
            f.write(flow + "\n")
            f.write("tee -q -o %s stat -json\n" % js)
        r = subprocess.run(["yosys", "-q", "-s", ys], capture_output=True, text=True)
        if r.returncode != 0 or not os.path.isfile(js):
            return False, {}, (r.stdout + r.stderr)[-600:]
        d = json.load(open(js))
        mods = d.get("modules") or {}
        top = mods.get("\\" + TOP) or mods.get(TOP) or d.get("design") or {}
        cells = top.get("num_cells_by_type") or top.get("cells") or {}
        return True, {k.lstrip("\\"): v for k, v in cells.items()}, ""


def count(cells, pat):
    return sum(v for k, v in cells.items() if re.search(pat, k))


def latches(cells):
    return count(cells, r"DLATCH|\$dlatch|\$_DLATCH|LATCH")


FPGA_FLOWS = {
    "xc7": ("synth_xilinx -family xc7 -flatten", r"RAMB36E1|RAMB18E1", "RAMB36E1/RAMB18E1"),
    "xcup": ("synth_xilinx -family xcup -flatten", r"RAMB36E2|RAMB18E2|URAM288", "RAMB36E2/RAMB18E2/URAM288"),
    "ice40": ("synth_ice40 -flatten", r"SB_RAM40_4K", "SB_RAM40_4K"),
    "ecp5": ("synth_ecp5 -flatten", r"DP16KD|PDPW16KD", "DP16KD/PDPW16KD"),
}


def job_generic(spec):
    name, params = spec
    ok, cells, log = yosys_stat(params, "synth -flatten")
    r = {"backend": "GENERIC", "name": name, "params": params, "ok": ok}
    if ok:
        r.update({"flip_flops": count(cells, r"DFF"), "latches": latches(cells), "mem_cells_left": count(cells, r"\$mem"),
                  "total_cells": sum(cells.values()), "status": "PASS" if latches(cells) == 0 else "FAIL",
                  "note": "behavioural array becomes flip-flops under generic mapping: not SRAM area"})
    else:
        r.update({"status": "FAIL", "log": log})
    return r


def job_fpga(spec):
    name, family, params = spec
    flow, pat, label = FPGA_FLOWS[family]
    ok, cells, log = yosys_stat(dict(params, MEMORY_TECH=1), flow)
    r = {"backend": "FPGA", "family": family, "name": name, "params": params, "ok": ok, "ram_primitive": label}
    if ok:
        n = count(cells, pat)
        r.update({"ram_cells": n, "ram_breakdown": {k: v for k, v in cells.items() if re.search(pat, k)}, "latches": latches(cells),
                  "mem_cells_left": count(cells, r"\$mem"), "flip_flops": count(cells, r"FD|DFF|\$_DFF"), "total_cells": sum(cells.values())})
        good = n > 0 and latches(cells) == 0 and r["mem_cells_left"] == 0
        r["status"] = "PASS" if good else ("NO_RAM_INFERRED" if n == 0 else "FAIL")
    else:
        r.update({"status": "FAIL", "log": log})
    return r


def job_asic(spec):
    name, plan_path = spec
    plan = json.load(open(plan_path))
    sel = plan["selected"]
    req = plan["request"]
    params = {"DATA_WIDTH": req["DATA_WIDTH"], "DEPTH_WORDS": req["DEPTH_WORDS"], "READ_LATENCY": req.get("READ_LATENCY", 1),
              "BYTE_ENABLE": req.get("BYTE_ENABLE", 1), "BYTE_WIDTH": req.get("BYTE_WIDTH", 8), "ECC_MODE": req.get("ECC_MODE", 0),
              "TEST_MODE": req.get("TEST_MODE", 0), "MEMORY_TECH": sel["wrapper_params"]["MEMORY_TECH"], "MACRO_ID": sel["macro_id"]}
    ok, cells, log = yosys_stat(params, "synth -flatten")
    r = {"backend": "ASIC", "name": name, "macro": sel["macro_name"], "params": params, "ok": ok, "planned_instances": sel["tiling"]["instances"]}
    if ok:
        n = cells.get(sel["macro_name"], 0)
        other = {k: v for k, v in cells.items() if re.match(r"^(RM_IHPSG13|gf180mcu_fd_ip_sram|sky130_sram)", k) and k != sel["macro_name"]}
        r.update({"macro_instances": n, "other_macro_types": other, "latches": latches(cells), "mem_cells_left": count(cells, r"\$mem"),
                  "glue_flip_flops": count(cells, r"DFF"), "glue_cells_total": sum(v for k, v in cells.items() if k != sel["macro_name"]),
                  "status": "PASS" if (n == sel["tiling"]["instances"] and not other and latches(cells) == 0 and count(cells, r"\$mem") == 0) else "FAIL"})
    else:
        r.update({"status": "FAIL", "log": log})
    return r


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports"))
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args(argv)
    gen = [("default 32x1024 byte-enable", {}), ("lane ECC 128b L2 test", {"DATA_WIDTH": 128, "BYTE_WIDTH": 32, "ECC_MODE": 2, "READ_LATENCY": 2, "TEST_MODE": 1, "DEPTH_WORDS": 256}),
           ("word ECC 64b BE0 power", {"DATA_WIDTH": 64, "BYTE_ENABLE": 0, "ECC_MODE": 1, "POWER_CTRL": 1, "DEPTH_WORDS": 128})]
    fpga = []
    for fam in FPGA_FLOWS:
        fpga.append(("32x4096 byte-enable block", fam, {"DEPTH_WORDS": 4096, "FPGA_RAM_STYLE": 1}))
    fpga += [("64b BE0 word-ECC 2048 words block", "xc7", {"DATA_WIDTH": 64, "BYTE_ENABLE": 0, "ECC_MODE": 1, "DEPTH_WORDS": 2048, "FPGA_RAM_STYLE": 1, "TEST_MODE": 1}),
             ("32x1024 AUTO style", "xc7", {"DEPTH_WORDS": 1024}),
             ("32x8192 ULTRA hint", "xcup", {"DEPTH_WORDS": 8192, "FPGA_RAM_STYLE": 2, "READ_LATENCY": 2}),
             ("lane ECC 32b L2", "xc7", {"ECC_MODE": 2, "READ_LATENCY": 2, "DEPTH_WORDS": 1024})]
    asic = [(os.path.basename(p).split(".")[0], p) for p in sorted(os.path.join(ROOT, "configs", "generated", f) for f in os.listdir(os.path.join(ROOT, "configs", "generated"))
                                                                  if f.endswith(".plan.json"))]
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        rg = list(ex.map(job_generic, gen))
        rf = list(ex.map(job_fpga, fpga))
        ra = list(ex.map(job_asic, asic))
    ver = subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip()
    rtlhash = {os.path.relpath(f, ROOT): hashlib.sha256(open(f, "rb").read()).hexdigest() for f in RTLS}
    os.makedirs(a.out, exist_ok=True)
    allr = rg + rf + ra
    json.dump({"yosys": ver, "rtl_sha256": rtlhash, "results": allr}, open(os.path.join(a.out, "synth.json"), "w"), indent=1)
    with open(os.path.join(a.out, "synth.md"), "w") as f:
        f.write("# Yosys synthesis evidence\n\n%s.  Vivado/Quartus/OpenROAD were not run.\n\n" % ver)
        f.write("## GENERIC (generic `synth`; flip-flops are NOT SRAM area)\n\n| config | flip-flops | latches | cells | status |\n|---|---|---|---|---|\n")
        for r in rg:
            f.write("| %s | %s | %s | %s | %s |\n" % (r["name"], r.get("flip_flops"), r.get("latches"), r.get("total_cells"), r["status"]))
        f.write("\n## FPGA inference\n\n| config | family | RAM primitives | breakdown | latches | $mem left | status |\n|---|---|---|---|---|---|---|\n")
        for r in rf:
            f.write("| %s | %s | %s | %s | %s | %s | %s |\n" % (r["name"], r["family"], r.get("ram_cells"), json.dumps(r.get("ram_breakdown", {})), r.get("latches"), r.get("mem_cells_left"), r["status"]))
        f.write("\n## ASIC (macros as black boxes)\n\n| plan | macro | planned | found | other macro types | latches | $mem left | glue FFs | glue cells | status |\n|---|---|---|---|---|---|---|---|---|---|\n")
        for r in ra:
            f.write("| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |\n" % (r["name"], r.get("macro"), r.get("planned_instances"), r.get("macro_instances"),
                                                                                  r.get("other_macro_types"), r.get("latches"), r.get("mem_cells_left"), r.get("glue_flip_flops"),
                                                                                  r.get("glue_cells_total"), r["status"]))
    for r in allr:
        print("%-6s %-42s %s" % (r["backend"], r["name"][:42], r["status"]))
    return 0 if all(r["status"] in ("PASS", "NO_RAM_INFERRED") for r in allr) else 1


if __name__ == "__main__":
    sys.exit(main())
