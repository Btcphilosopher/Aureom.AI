#!/usr/bin/env python3
"""Mutation testing of the SRAMMacroBridge RTL against the self-checking testbenches.

  python3 -I scripts/run_mutants.py [--vendor build/vendor] [--jobs N] [--out reports]

Each mutant is ONE textual change (applied to a private copy of rtl/, asserted to apply exactly once).  A mutant is KILLED
if the selected simulation fails (mismatch, assertion, compile error, or no result line).  Mutants expected to survive are
FUNCTIONALLY EQUIVALENT AT THE INTERFACE and are listed with the reason; an unexpected survivor, or an unexpected kill,
fails the run.
"""
import argparse
import concurrent.futures as cf
import json
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "tools"))
import run_sim as S  # noqa: E402
import sram_cfg_gen as G  # noqa: E402

CFG = {}
for nm, p, o in S.GENERIC + S.FPGA + S.ASIC:
    CFG[nm] = (p, o)

# (id, file, old, new, [config names or 'ecc:K'], expectation, why)
M = [
    ("M01 wmask ignored", "rtl/sf_sram_macro_wrapper.sv", "wire logic [LANES-1:0] w_lane = (BYTE_ENABLE != 0) ? wmask : {LANES{1'b1}};",
     "wire logic [LANES-1:0] w_lane = {LANES{1'b1}};", ["g01_default_32x1024"], "KILLED", ""),
    ("M02 ECC lane layout {data,check}", "rtl/sf_sram_macro_wrapper.sv", "assign w_phys[l*PLW +: PLW] = {chk, wdata[l*LANE_W +: LANE_W]};",
     "assign w_phys[l*PLW +: PLW] = {wdata[l*LANE_W +: LANE_W], chk};", ["g02_l2_lane_ecc_test_power"], "KILLED", ""),
    ("M03 read latency off by one", "rtl/sf_sram_macro_wrapper.sv", "assign rdata_i = d_q[READ_LATENCY-2];", "assign rdata_i = d_q[0];",
     ["g03_l3_depth300_nonpow2"], "KILLED", ""),
    ("M04 settle cycle not quiet", "rtl/sf_sram_macro_wrapper.sv", "assign quiet   = chg | settle_q;", "assign quiet   = chg;",
     ["g10_handover_negative"], "KILLED", ""),
    ("M05 functional access allowed while the test bus owns the array", "rtl/sf_sram_macro_wrapper.sv", "wire logic f_ce = ce & ~tst_sel & pwr_ok & ~quiet;",
     "wire logic f_ce = ce & pwr_ok & ~quiet;", ["g04_word_ecc_64b_be0"], "SURVIVES",
     "the testbench never presents a functional access while tst_active owns the array (outside the hand-over window); the "
     "wrapper's SF_MACRO_ASSERT_TSTOWN assertion covers it in simulation"),
    ("M06 ECC corrected flag never raised", "rtl/sf_sram_macro_wrapper.sv", "assign cor_i   = dec_cor & fr_v1;", "assign cor_i   = 1'b0;",
     ["g04_word_ecc_64b_be0"], "KILLED", "(latency-1 branch)"),
    ("M07 decoder: check-bit errors not flagged", "rtl/ecc/sf_ecc_secded_dec.sv", "assign corrected     = any_hit | syn_unit;", "assign corrected     = any_hit;",
     ["ecc:32", "g04_word_ecc_64b_be0"], "KILLED", ""),
    ("M08 encoder: unit-vector columns allowed", "rtl/ecc/sf_ecc_h.svh", "if (j < K && pc >= 3 && (pc % 2) == 1) begin", "if (j < K && pc >= 1 && (pc % 2) == 1) begin",
     ["ecc:32", "g04_word_ecc_64b_be0"], "KILLED", ""),
    ("M09 decoder: wrong data bit corrected", "rtl/ecc/sf_ecc_secded_dec.sv", "assign data_out      = data_in ^ hit;", "assign data_out      = data_in ^ (hit << 1);",
     ["ecc:32", "g04_word_ecc_64b_be0"], "KILLED", ""),
    ("M10 no wake delay", "rtl/sf_sram_macro_wrapper.sv", "assign pwr_ok = ~pwr_sleep & (&awake_q);", "assign pwr_ok = ~pwr_sleep;",
     ["g08_power_wake1"], "KILLED", ""),
    ("M11 test read valid also for writes", "rtl/sf_sram_macro_wrapper.sv", "tr_v1 <= t_ce & ~tst_we;", "tr_v1 <= t_ce;",
     ["g04_word_ecc_64b_be0"], "KILLED", ""),
    ("M12 row select not registered (ASIC)", "rtl/backends/sf_sram_be_asic.sv", "always_ff @(posedge clk) row_q <= tst_active ? t_row : f_row;",
     "always_comb row_q = tst_active ? t_row : f_row;", ["a_ihp01_64x64_rows16_l2"], "KILLED", ""),
    ("M13 lane mask of lane 0 used for every bit (ASIC)", "rtl/backends/sf_sram_be_asic.sv", "assign f_bm[p] = wlane[p / PLW];", "assign f_bm[p] = wlane[0];",
     ["a_ihp09_512x32_9bit_lanes"], "KILLED", ""),
    ("M14 GF180 CEN polarity", "rtl/backends/asic/sf_sram_leaf_gf180.sv", "wire logic n_ce0 = ~m_ce;", "wire logic n_ce0 = m_ce;",
     ["a_gf20_128x8_tiled_test"], "KILLED", ""),
    ("M15 GF180 bit-mask polarity", "rtl/backends/asic/sf_sram_leaf_gf180.sv", "wire logic [MB-1:0] n_bm0 = ~m_bm;", "wire logic [MB-1:0] n_bm0 = m_bm;",
     ["a_gf20_128x8_tiled_test"], "KILLED", ""),
    ("M16 SKY130 web0 polarity", "rtl/backends/asic/sf_sram_leaf_sky130.sv", "wire logic n_we = ~m_we;", "wire logic n_we = m_we;",
     ["a_sky23_256x32_tiled_test"], "KILLED", ""),
    ("M17 SKY130 byte-mask order reversed", "rtl/backends/asic/sf_sram_leaf_sky130.sv", "assign wmask_b[b] = m_bm[8*b];", "assign wmask_b[b] = m_bm[MB-8-8*b];",
     ["a_sky23_256x32_tiled_test"], "KILLED", ""),
    ("M18 IHP BIST mask zero", "rtl/backends/asic/sf_sram_leaf_ihp1p.sv", ".A_BIST_BM(ones)", ".A_BIST_BM({MB{1'b0}})", ["a_ihp04_256x32_1macro_test"], "KILLED", "(first macro only)"),
    ("M19 IHP A_DLY not tied high", "rtl/backends/asic/sf_sram_leaf_ihp1p.sv", ".A_DLY(1'b1)", ".A_DLY(1'b0)", ["a_ihp04_256x32_1macro_test"], "KILLED", "(first macro only)"),
    ("M20 IHP built-in test mux never selected", "rtl/backends/asic/sf_sram_leaf_ihp1p.sv", ".A_BIST_EN(t_en)", ".A_BIST_EN(1'b0)", ["a_ihp04_256x32_1macro_test"], "KILLED", "(first macro only)"),
    ("M21 IHP write-through always requested (A_REN=1)", "rtl/backends/asic/sf_sram_leaf_ihp1p.sv", ".A_REN(n_we)", ".A_REN(1'b1)", ["a_ihp04_256x32_1macro_test"], "SURVIVES",
     "write-through only changes the macro's DOUT register during write cycles; the contract samples rdata only in read slots, so the "
     "difference is invisible at the interface (it would matter for power and for output-hold assumptions, which the wrapper does not make)"),
    ("M22 test writes use the functional lane mask", "rtl/backends/sf_sram_array_body.svh", "wire logic [NL-1:0]         a_lane  = tst_active ? {NL{1'b1}} : wlane;",
     "wire logic [NL-1:0]         a_lane  = wlane;", ["g02_l2_lane_ecc_test_power"], "KILLED", ""),
    ("M23 generic array reads on write cycles too", "rtl/backends/sf_sram_array_body.svh", "    end else begin\n      rdata <= mem[a_idx];\n    end\n",
     "    end\n    rdata <= mem[a_idx];\n", ["g01_default_32x1024"], "SURVIVES",
     "read-first versus no-change behaviour of the same-cycle read register is unobservable: rdata is meaningful only in a read slot"),
]


def mut_root(i):
    return os.path.join(ROOT, "build", "mut", "m%02d" % i)


def run_one(args):
    i, (mid, rel, old, new, cfgs, expect, why), vendor, catalog, manifests = args
    root = mut_root(i)
    shutil.rmtree(root, ignore_errors=True)
    os.makedirs(root)
    shutil.copytree(os.path.join(ROOT, "rtl"), os.path.join(root, "rtl"))
    path = os.path.join(root, rel)
    t = open(path).read()
    if t.count(old) < 1:
        return {"id": mid, "status": "ERROR", "why": "pattern not found (%s)" % rel}
    open(path, "w").write(t.replace(old, new))     # every occurrence (leaf blocks repeat per macro)
    killed_by = None
    for c in cfgs:
        if c.startswith("ecc:"):
            k = int(c.split(":")[1])
            vec = os.path.join(ROOT, "tb", "vectors", "ecc_vec_k%d.mem" % k)
            exe = os.path.join(root, "ecc_exe")
            inc = ["-I" + os.path.join(root, "rtl"), "-I" + os.path.join(root, "rtl", "ecc")]
            rc = subprocess.run(["iverilog", "-g2012"] + inc + ["-P", "tb_ecc_vectors.K=%d" % k, "-P", 'tb_ecc_vectors.VEC="%s"' % vec, "-o", exe,
                                                             os.path.join(ROOT, "tb/tb_ecc_vectors.sv"), os.path.join(root, "rtl/ecc/sf_ecc_secded_enc.sv"),
                                                             os.path.join(root, "rtl/ecc/sf_ecc_secded_dec.sv")], capture_output=True, text=True)
            if rc.returncode != 0:
                killed_by = c + " (compile)"
                break
            out = subprocess.run(["vvp", "-n", exe], capture_output=True, text=True).stdout
            if "SF_TB_RESULT: PASS" not in out:
                killed_by = c
                break
            continue
        params, opt = CFG[c]
        params = dict(params)
        params["NCYC"] = min(params.get("NCYC", 4000), 800)
        defs = []
        srcs = []
        stubs = True
        if params.get("MEMORY_TECH", 0) >= 10:
            files, d2, missing = S.vendor_files(vendor, params["MACRO_ID"], catalog, manifests)
            if files is None:
                return {"id": mid, "status": "SKIPPED", "why": "vendor file missing: %s" % missing}
            srcs, defs, stubs = files, d2, False
        if opt.get("poison"):
            defs = defs + ["-DSF_MACRO_POISON"]
            params["POISON"] = 1
        inc = ["-I" + os.path.join(root, "rtl"), "-I" + os.path.join(root, "rtl", "ecc"), "-I" + os.path.join(root, "rtl", "backends")]
        exe = os.path.join(root, "t_exe")
        files = [os.path.join(root, f) for f in S.RTL]
        cmd = ["iverilog", "-g2012", "-Wno-timescale"] + inc + defs + ["-P" + "tb_macro.%s=%s" % kv for kv in params.items()] + \
              ["-o", exe, os.path.join(ROOT, "tb/tb_macro.sv")] + files + ([os.path.join(root, S.STUBS)] if stubs else []) + srcs
        rc = subprocess.run(cmd, capture_output=True, text=True)
        if rc.returncode != 0:
            killed_by = c + " (compile)"
            break
        try:
            out = subprocess.run(["vvp", "-n", exe], capture_output=True, text=True, timeout=900).stdout
        except subprocess.TimeoutExpired:
            killed_by = c + " (timeout)"
            break
        res = S.parse_result(out)
        n_as = len(re.findall(r"SF_MACRO_ASSERT_", out))
        neg = params.get("NEG_TEST")
        if res is None or res["status"] != "PASS" or (n_as != 4 if neg else n_as != 0):
            killed_by = c
            break
    status = "KILLED" if killed_by else "SURVIVES"
    ok = (status == expect)
    return {"id": mid, "file": rel, "status": status, "expected": expect, "ok": ok, "by": killed_by, "why": why}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--vendor", default=os.environ.get("SF_VENDOR_DIR", os.path.join(ROOT, "build", "vendor")))
    ap.add_argument("--manifests", default=os.path.join(ROOT, "manifests"))
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports"))
    a = ap.parse_args(argv)
    catalog = G.load_catalog(a.manifests)
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run_one, [(i, m, a.vendor, catalog, a.manifests) for i, m in enumerate(M)]))
    os.makedirs(a.out, exist_ok=True)
    json.dump(res, open(os.path.join(a.out, "mutants.json"), "w"), indent=1)
    killed = sum(1 for r in res if r["status"] == "KILLED")
    surv = [r for r in res if r["status"] == "SURVIVES"]
    with open(os.path.join(a.out, "mutants.md"), "w") as f:
        f.write("# Mutation testing\n\n%d mutants: %d killed, %d survived (expected: %d equivalent at the interface).\n\n| mutant | result | expected | killed by | note |\n|---|---|---|---|---|\n" % (
            len(res), killed, len(surv), sum(1 for r in res if r.get("expected") == "SURVIVES")))
        for r in res:
            f.write("| %s | %s | %s | %s | %s |\n" % (r["id"], r["status"], r.get("expected", ""), r.get("by") or "", (r.get("why") or "").replace("|", "/")))
    for r in res:
        print("%-62s %-9s %s %s" % (r["id"][:62], r["status"], "" if r.get("ok", True) else "<-- UNEXPECTED", r.get("by") or ""))
    bad = [r for r in res if not r.get("ok", False)]
    print("%d mutants: %d killed, %d survived; %d unexpected" % (len(res), killed, len(surv), len(bad)))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
