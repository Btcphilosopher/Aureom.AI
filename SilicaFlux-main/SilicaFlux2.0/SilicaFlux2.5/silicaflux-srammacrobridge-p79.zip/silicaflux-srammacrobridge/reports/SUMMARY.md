# SilicaFlux SRAMMacroBridge (Project 79) -- status summary

Generated from the result files by `scripts/make_report.py`.

| Item | Result |
|---|---|
| Catalogue | 25 real macros (4 GF180_1RW, 18 IHP_1P, 3 SKY130_1RW1R) from 3 open-PDK sources; 209 vendor files pinned by SHA-256 |
| Manifest cross-checks | 25/25 macros: all Verilog/LEF/Liberty/datasheet/earlier-library checks pass; 4 vendor-document discrepancies reported (see physical_readiness.md section 4) |
| Simulation | agree 1/1; asic 20/20; ecc 7/7; equiv 20/20; fpga 12/12; generic 28/28; neg 39/39 |
| Synthesis (Yosys) | 15/15 jobs pass |
| Mutation testing | 20/23 killed, 3 expected survivors |
| Floorplans | 4 generated, 4/4 pass the mock-OpenDB + geometry checks; **OpenROAD not run** |
| Physical readiness | `PHYSICAL_VIEWS_COMPLETE_SIGNOFF_PENDING` for all macros; DRC/LVS/STA/IR **not run**; silicon qualification **not established** |

Details: `physical_readiness.md`, `sim.md`, `synth.md`, `mutants.md`.

