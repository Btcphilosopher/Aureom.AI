# Simulation / verification results

Tools: iverilog: Icarus Verilog version 12.0 (stable) (), verilator: Verilator 5.020 2024-01-01 rev (Debian 5.020-1), yosys: Yosys 0.33 (git sha1 2584903a060)

| suite | PASS | FAIL | SKIPPED |
|---|---|---|---|
| agree | 1 | 0 | 0 |
| asic | 20 | 0 | 0 |
| ecc | 7 | 0 | 0 |
| equiv | 20 | 0 | 0 |
| fpga | 12 | 0 | 0 |
| generic | 28 | 0 | 0 |
| neg | 39 | 0 | 0 |

| suite | test | sim | status | checks | trace | detail |
|---|---|---|---|---|---|---|
| ecc | ecc_vectors_K8 |  | PASS |  |  | ecc_vectors K=8 R=5 records=726 enc_checks=66 dec_checks=726 singles=396 doubles=264 errors=0 |
| ecc | ecc_vectors_K13 |  | PASS |  |  | ecc_vectors K=13 R=6 records=726 enc_checks=66 dec_checks=726 singles=396 doubles=264 errors=0 |
| ecc | ecc_vectors_K16 |  | PASS |  |  | ecc_vectors K=16 R=6 records=726 enc_checks=66 dec_checks=726 singles=396 doubles=264 errors=0 |
| ecc | ecc_vectors_K32 |  | PASS |  |  | ecc_vectors K=32 R=7 records=726 enc_checks=66 dec_checks=726 singles=396 doubles=264 errors=0 |
| ecc | ecc_vectors_K39 |  | PASS |  |  | ecc_vectors K=39 R=7 records=726 enc_checks=66 dec_checks=726 singles=396 doubles=264 errors=0 |
| ecc | ecc_vectors_K64 |  | PASS |  |  | ecc_vectors K=64 R=8 records=726 enc_checks=66 dec_checks=726 singles=396 doubles=264 errors=0 |
| ecc | ecc_vectors_K128 |  | PASS |  |  | ecc_vectors K=128 R=9 records=726 enc_checks=66 dec_checks=726 singles=396 doubles=264 errors=0 |
| generic | g01_default_32x1024 | icarus | PASS | 2557 | 7a30e6a707c971a3 |  |
| generic | g01_default_32x1024 | verilator | PASS | 2557 | 7a30e6a707c971a3 |  |
| generic | g02_l2_lane_ecc_test_power | icarus | PASS | 3469 | d16e58f5ddc5a89d |  |
| generic | g02_l2_lane_ecc_test_power | verilator | PASS | 3469 | d16e58f5ddc5a89d |  |
| generic | g03_l3_depth300_nonpow2 | icarus | PASS | 3389 | af2b678fbb8bda38 |  |
| generic | g03_l3_depth300_nonpow2 | verilator | PASS | 3389 | af2b678fbb8bda38 |  |
| generic | g04_word_ecc_64b_be0 | icarus | PASS | 4288 | 11a7b89b83e5c451 |  |
| generic | g04_word_ecc_64b_be0 | verilator | PASS | 4288 | 11a7b89b83e5c451 |  |
| generic | g05_9bit_lanes_36b_lane_ecc | icarus | PASS | 3576 | 5faeb323678493d8 |  |
| generic | g05_9bit_lanes_36b_lane_ecc | verilator | PASS | 3576 | 5faeb323678493d8 |  |
| generic | g06_odd_width_13b_be0 | icarus | PASS | 2123 | b89f0489b5b74b3d |  |
| generic | g06_odd_width_13b_be0 | verilator | PASS | 2123 | b89f0489b5b74b3d |  |
| generic | g07_128b_32b_lanes_lane_ecc_l2 | icarus | PASS | 6828 | 4ba5bd16d34119d4 |  |
| generic | g07_128b_32b_lanes_lane_ecc_l2 | verilator | PASS | 6828 | 4ba5bd16d34119d4 |  |
| generic | g08_power_wake1 | icarus | PASS | 1577 | ba83ae25e3989983 |  |
| generic | g08_power_wake1 | verilator | PASS | 1577 | ba83ae25e3989983 |  |
| generic | g09_power_wake4_ecc | icarus | PASS | 2667 | ea41faad88b807ba |  |
| generic | g09_power_wake4_ecc | verilator | PASS | 2667 | ea41faad88b807ba |  |
| generic | g10_handover_negative | icarus | PASS | 680 | 846c917156283cdd | 4 hand-over assertions as expected; dropped accesses never reached the array |
| generic | g01_default_32x1024::icarus_vs_verilator_trace |  | PASS |  |  | 7a30e6a707c971a3/7a30e6a707c971a3 checks 2557/2557 |
| generic | g02_l2_lane_ecc_test_power::icarus_vs_verilator_trace |  | PASS |  |  | d16e58f5ddc5a89d/d16e58f5ddc5a89d checks 3469/3469 |
| generic | g03_l3_depth300_nonpow2::icarus_vs_verilator_trace |  | PASS |  |  | af2b678fbb8bda38/af2b678fbb8bda38 checks 3389/3389 |
| generic | g04_word_ecc_64b_be0::icarus_vs_verilator_trace |  | PASS |  |  | 11a7b89b83e5c451/11a7b89b83e5c451 checks 4288/4288 |
| generic | g05_9bit_lanes_36b_lane_ecc::icarus_vs_verilator_trace |  | PASS |  |  | 5faeb323678493d8/5faeb323678493d8 checks 3576/3576 |
| generic | g06_odd_width_13b_be0::icarus_vs_verilator_trace |  | PASS |  |  | b89f0489b5b74b3d/b89f0489b5b74b3d checks 2123/2123 |
| generic | g07_128b_32b_lanes_lane_ecc_l2::icarus_vs_verilator_trace |  | PASS |  |  | 4ba5bd16d34119d4/4ba5bd16d34119d4 checks 6828/6828 |
| generic | g08_power_wake1::icarus_vs_verilator_trace |  | PASS |  |  | ba83ae25e3989983/ba83ae25e3989983 checks 1577/1577 |
| generic | g09_power_wake4_ecc::icarus_vs_verilator_trace |  | PASS |  |  | ea41faad88b807ba/ea41faad88b807ba checks 2667/2667 |
| fpga | f01_auto_32x1024 | icarus | PASS | 2557 | 7a30e6a707c971a3 |  |
| fpga | f01_auto_32x1024 | verilator | PASS | 2557 | 7a30e6a707c971a3 |  |
| fpga | f02_block_l2_test | icarus | PASS | 3389 | af2b678fbb8bda38 |  |
| fpga | f02_block_l2_test | verilator | PASS | 3389 | af2b678fbb8bda38 |  |
| fpga | f03_ultra_72b_be0_word_ecc | icarus | PASS | 5842 | fbe94ff01ad98949 |  |
| fpga | f03_ultra_72b_be0_word_ecc | verilator | PASS | 5842 | fbe94ff01ad98949 |  |
| fpga | f04_dist_lane_ecc_power | icarus | PASS | 2667 | ea41faad88b807ba |  |
| fpga | f04_dist_lane_ecc_power | verilator | PASS | 2667 | ea41faad88b807ba |  |
| fpga | f01_auto_32x1024::icarus_vs_verilator_trace |  | PASS |  |  | 7a30e6a707c971a3/7a30e6a707c971a3 checks 2557/2557 |
| fpga | f02_block_l2_test::icarus_vs_verilator_trace |  | PASS |  |  | af2b678fbb8bda38/af2b678fbb8bda38 checks 3389/3389 |
| fpga | f03_ultra_72b_be0_word_ecc::icarus_vs_verilator_trace |  | PASS |  |  | fbe94ff01ad98949/fbe94ff01ad98949 checks 5842/5842 |
| fpga | f04_dist_lane_ecc_power::icarus_vs_verilator_trace |  | PASS |  |  | ea41faad88b807ba/ea41faad88b807ba checks 2667/2667 |
| asic | a_ihp04_256x32_1macro_test | icarus | PASS | 3124 | fb36f256466f917a |  |
| asic | a_ihp06_256x64_tiled_ecc_lane_test | icarus | PASS | 8438 | c521f725323cd4cb |  |
| asic | a_ihp01_64x64_rows16_l2 | icarus | PASS | 7602 | 79fee7d2eae18632 |  |
| asic | a_ihp02_256x8_cols_word_ecc_l3 | icarus | PASS | 6412 | 13a2799954eb4a85 |  |
| asic | a_ihp15_2048x32_4096words | icarus | PASS | 7903 | 83cd8c38837a4458 |  |
| asic | a_ihp09_512x32_9bit_lanes | icarus | PASS | 5185 | cec337ea2dfd4033 |  |
| asic | a_gf20_128x8_tiled_test | icarus | PASS | 3389 | af2b678fbb8bda38 |  |
| asic | a_gf19_64x8_lane_ecc_test | icarus | PASS | 3060 | 9e2808c7963d041e |  |
| asic | a_gf22_512x8_be0_word_ecc_l2 | icarus | PASS | 5852 | e80e0e3da0a2f22a |  |
| asic | a_gf21_256x8_4bit_lanes | icarus | PASS | 3436 | 3295e436d63a6a00 |  |
| asic | a_sky23_256x32_tiled_test | icarus | PASS | 5796 | 276560d9c722d102 |  |
| asic | a_sky24_512x32_word_ecc_be0_l2 | icarus | PASS | 9282 | caa499c3b43d2f33 |  |
| asic | a_sky25_1024x8_16b_2lanes | icarus | PASS | 10589 | df97ce0d1f49669c |  |
| asic | a_ref_sfv_a_ihp15_128b_lane_ecc | icarus | PASS | 10678 | b85caad6b126a221 |  |
| asic | a_ref_sfv_b_ihp18_128b_lane_ecc | icarus | PASS | 11470 | 04f8186750ed9ca8 |  |
| asic | a_ref_sfv_gf_gf22_32b | icarus | PASS | 1999 | 3c868e750577c091 |  |
| asic | a_ref_sfv_sky_sky24_64b | icarus | PASS | 5188 | 857bb2117aa7e705 |  |
| asic | a_ihp04_handover_negative | icarus | PASS | 1819 | 2a89130fc5f76e76 | 4 hand-over assertions as expected; dropped accesses never reached the array |
| asic | a_gf20_handover_negative | icarus | PASS | 2086 | 48081dab48ee76e0 | 4 hand-over assertions as expected; dropped accesses never reached the array |
| asic | a_sky23_handover_negative | icarus | PASS | 2086 | 48081dab48ee76e0 | 4 hand-over assertions as expected; dropped accesses never reached the array |
| equiv | a_ihp04_256x32_1macro_test |  | PASS |  |  | asic trace fb36f256466f917a generic trace fb36f256466f917a (3124 checks) |
| equiv | a_ihp06_256x64_tiled_ecc_lane_test |  | PASS |  |  | asic trace c521f725323cd4cb generic trace c521f725323cd4cb (8438 checks) |
| equiv | a_ihp01_64x64_rows16_l2 |  | PASS |  |  | asic trace 79fee7d2eae18632 generic trace 79fee7d2eae18632 (7602 checks) |
| equiv | a_ihp02_256x8_cols_word_ecc_l3 |  | PASS |  |  | asic trace 13a2799954eb4a85 generic trace 13a2799954eb4a85 (6412 checks) |
| equiv | a_ihp15_2048x32_4096words |  | PASS |  |  | asic trace 83cd8c38837a4458 generic trace 83cd8c38837a4458 (7903 checks) |
| equiv | a_ihp09_512x32_9bit_lanes |  | PASS |  |  | asic trace cec337ea2dfd4033 generic trace cec337ea2dfd4033 (5185 checks) |
| equiv | a_gf20_128x8_tiled_test |  | PASS |  |  | asic trace af2b678fbb8bda38 generic trace af2b678fbb8bda38 (3389 checks) |
| equiv | a_gf19_64x8_lane_ecc_test |  | PASS |  |  | asic trace 9e2808c7963d041e generic trace 9e2808c7963d041e (3060 checks) |
| equiv | a_gf22_512x8_be0_word_ecc_l2 |  | PASS |  |  | asic trace e80e0e3da0a2f22a generic trace e80e0e3da0a2f22a (5852 checks) |
| equiv | a_gf21_256x8_4bit_lanes |  | PASS |  |  | asic trace 3295e436d63a6a00 generic trace 3295e436d63a6a00 (3436 checks) |
| equiv | a_sky23_256x32_tiled_test |  | PASS |  |  | asic trace 276560d9c722d102 generic trace 276560d9c722d102 (5796 checks) |
| equiv | a_sky24_512x32_word_ecc_be0_l2 |  | PASS |  |  | asic trace caa499c3b43d2f33 generic trace caa499c3b43d2f33 (9282 checks) |
| equiv | a_sky25_1024x8_16b_2lanes |  | PASS |  |  | asic trace df97ce0d1f49669c generic trace df97ce0d1f49669c (10589 checks) |
| equiv | a_ref_sfv_a_ihp15_128b_lane_ecc |  | PASS |  |  | asic trace b85caad6b126a221 generic trace b85caad6b126a221 (10678 checks) |
| equiv | a_ref_sfv_b_ihp18_128b_lane_ecc |  | PASS |  |  | asic trace 04f8186750ed9ca8 generic trace 04f8186750ed9ca8 (11470 checks) |
| equiv | a_ref_sfv_gf_gf22_32b |  | PASS |  |  | asic trace 3c868e750577c091 generic trace 3c868e750577c091 (1999 checks) |
| equiv | a_ref_sfv_sky_sky24_64b |  | PASS |  |  | asic trace 857bb2117aa7e705 generic trace 857bb2117aa7e705 (5188 checks) |
| equiv | a_ihp04_handover_negative |  | PASS |  |  | asic trace 2a89130fc5f76e76 generic trace 2a89130fc5f76e76 (1819 checks) |
| equiv | a_gf20_handover_negative |  | PASS |  |  | asic trace 48081dab48ee76e0 generic trace 48081dab48ee76e0 (2086 checks) |
| equiv | a_sky23_handover_negative |  | PASS |  |  | asic trace 48081dab48ee76e0 generic trace 48081dab48ee76e0 (2086 checks) |
| neg | E01 {"DATA_WIDTH": 0} |  | PASS |  |  | expected E01, verilator E01, icarus E01 |
| neg | E01 {"DATA_WIDTH": 2000} |  | PASS |  |  | expected E01, verilator E01, icarus E01 |
| neg | E02 {"DEPTH_WORDS": 1} |  | PASS |  |  | expected E02, verilator E02, icarus E02 |
| neg | E03 {"READ_LATENCY": 0} |  | PASS |  |  | expected E03, verilator E03, icarus E03 |
| neg | E03 {"READ_LATENCY": 17} |  | PASS |  |  | expected E03, verilator E03, icarus E03 |
| neg | E04 {"BYTE_ENABLE": 2} |  | PASS |  |  | expected E04, verilator E04, icarus E04 |
| neg | E05 {"BYTE_WIDTH": 8, "DATA_WIDTH": 30} |  | PASS |  |  | expected E05, verilator E05, icarus E05 |
| neg | E05 {"BYTE_WIDTH": 0} |  | PASS |  |  | expected E05, verilator E05, icarus E05 |
| neg | E06 {"MEMORY_TECH": 19} |  | PASS |  |  | expected E06, verilator E06, icarus E06 |
| neg | E07 {"MEMORY_TECH": 5} |  | PASS |  |  | expected E07, verilator E07, icarus E07 |
| neg | E08 {"ECC_MODE": 3} |  | PASS |  |  | expected E08, verilator E08, icarus E08 |
| neg | E09 {"ECC_MODE": 1} |  | PASS |  |  | expected E09, verilator E09, icarus E09 |
| neg | E10 {"BYTE_ENABLE": 0, "ECC_MODE": 2} |  | PASS |  |  | expected E10, verilator E10, icarus E10 |
| neg | E11 {"BYTE_ENABLE": 0, "DATA_WIDTH": 600, "ECC_MODE": 1} |  | PASS |  |  | expected E11, verilator E11, icarus E11 |
| neg | E12 {"TEST_MODE": 2} |  | PASS |  |  | expected E12, verilator E12, icarus E12 |
| neg | E13 {"POWER_CTRL": 2} |  | PASS |  |  | expected E13, verilator E13, icarus E13 |
| neg | E14 {"POWER_CTRL": 1, "WAKE_CYCLES": 0} |  | PASS |  |  | expected E14, verilator E14, icarus E14 |
| neg | E14 {"POWER_CTRL": 1, "WAKE_CYCLES": 9} |  | PASS |  |  | expected E14, verilator E14, icarus E14 |
| neg | E15 {"INIT_MODE": 7} |  | PASS |  |  | expected E15, verilator E15, icarus E15 |
| neg | E16 {"INIT_MODE": 2} |  | PASS |  |  | expected E16, verilator E16, icarus E16 |
| neg | E18 {"FPGA_RAM_STYLE": 9, "MEMORY_TECH": 1} |  | PASS |  |  | expected E18, verilator E18, icarus E18 |
| neg | E19 {"MACRO_ID": 3} |  | PASS |  |  | expected E19, verilator E19, icarus E19 |
| neg | E20 {"INIT_MODE": 1, "MACRO_ID": 4, "MEMORY_TECH": 10} |  | PASS |  |  | expected E20, verilator E20, icarus E20 |
| neg | E21 {"MACRO_ID": 0, "MEMORY_TECH": 10} |  | PASS |  |  | expected E21, verilator E21, icarus E21 |
| neg | E21 {"MACRO_ID": 99, "MEMORY_TECH": 10} |  | PASS |  |  | expected E21, verilator E21, icarus E21 |
| neg | E22 {"MACRO_ID": 4, "MEMORY_TECH": 11} |  | PASS |  |  | expected E22, verilator E22, icarus E22 |
| neg | E22 {"MACRO_ID": 19, "MEMORY_TECH": 12} |  | PASS |  |  | expected E22, verilator E22, icarus E22 |
| neg | E24 {"BYTE_WIDTH": 9, "DATA_WIDTH": 36, "MACRO_ID": 23, "MEMORY_TECH": 12} |  | PASS |  |  | expected E24, verilator E24, icarus E24 |
| neg | E24 {"BYTE_WIDTH": 8, "DATA_WIDTH": 32, "ECC_MODE": 2, "MACRO_ID": 23, "MEMORY_TECH": 12} |  | PASS |  |  | expected E24, verilator E24, icarus E24 |
| neg | E26 {"MACRO_ID": 4, "MEMORY_TECH": 10, "POWER_CTRL": 1} |  | PASS |  |  | expected E26, verilator E26, icarus E26 |
| neg | E26 {"MACRO_ID": 19, "MEMORY_TECH": 11, "POWER_CTRL": 1} |  | PASS |  |  | expected E26, verilator E26, icarus E26 |
| neg | E28 {"DATA_WIDTH": 128, "DEPTH_WORDS": 65536, "MACRO_ID": 19, "MEMORY_TECH": 11} |  | PASS |  |  | expected E28, verilator E28, icarus E28 |
| neg | legal {} elaborates |  | PASS |  |  | rule code 0 |
| neg | legal {"MEMORY_TECH": 1} elaborates |  | PASS |  |  | rule code 0 |
| neg | legal {"MACRO_ID": 4, "MEMORY_TECH": 10} elaborates |  | PASS |  |  | rule code 0 |
| neg | legal {"MACRO_ID": 19, "MEMORY_TECH": 11} elaborates |  | PASS |  |  | rule code 0 |
| neg | legal {"MACRO_ID": 23, "MEMORY_TECH": 12} elaborates |  | PASS |  |  | rule code 0 |
| neg | E17 INIT_MODE=PATTERN with SYNTHESIS |  | PASS |  |  | got E17 |
| neg | INIT_MODE=PATTERN allowed in simulation |  | PASS |  |  | got E00 |
| agree | sram_cfg_gen.err_code == RTL ERR_CODE on 326 configurations |  | PASS |  |  | rule histogram {"0": 125, "1": 1, "2": 1, "5": 35, "8": 4, "9": 1, "10": 3, "11": 4, "20": 89, "21": 9, "22": 4, "24": 6, "26": 35, "28": 9} |
