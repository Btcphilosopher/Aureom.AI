# Mutation testing

23 mutants: 20 killed, 3 survived (expected: 3 equivalent at the interface).

| mutant | result | expected | killed by | note |
|---|---|---|---|---|
| M01 wmask ignored | KILLED | KILLED | g01_default_32x1024 |  |
| M02 ECC lane layout {data,check} | KILLED | KILLED | g02_l2_lane_ecc_test_power |  |
| M03 read latency off by one | KILLED | KILLED | g03_l3_depth300_nonpow2 |  |
| M04 settle cycle not quiet | KILLED | KILLED | g10_handover_negative |  |
| M05 functional access allowed while the test bus owns the array | SURVIVES | SURVIVES |  | the testbench never presents a functional access while tst_active owns the array (outside the hand-over window); the wrapper's SF_MACRO_ASSERT_TSTOWN assertion covers it in simulation |
| M06 ECC corrected flag never raised | KILLED | KILLED | g04_word_ecc_64b_be0 | (latency-1 branch) |
| M07 decoder: check-bit errors not flagged | KILLED | KILLED | ecc:32 |  |
| M08 encoder: unit-vector columns allowed | KILLED | KILLED | ecc:32 |  |
| M09 decoder: wrong data bit corrected | KILLED | KILLED | ecc:32 |  |
| M10 no wake delay | KILLED | KILLED | g08_power_wake1 |  |
| M11 test read valid also for writes | KILLED | KILLED | g04_word_ecc_64b_be0 |  |
| M12 row select not registered (ASIC) | KILLED | KILLED | a_ihp01_64x64_rows16_l2 |  |
| M13 lane mask of lane 0 used for every bit (ASIC) | KILLED | KILLED | a_ihp09_512x32_9bit_lanes |  |
| M14 GF180 CEN polarity | KILLED | KILLED | a_gf20_128x8_tiled_test |  |
| M15 GF180 bit-mask polarity | KILLED | KILLED | a_gf20_128x8_tiled_test |  |
| M16 SKY130 web0 polarity | KILLED | KILLED | a_sky23_256x32_tiled_test |  |
| M17 SKY130 byte-mask order reversed | KILLED | KILLED | a_sky23_256x32_tiled_test |  |
| M18 IHP BIST mask zero | KILLED | KILLED | a_ihp04_256x32_1macro_test | (first macro only) |
| M19 IHP A_DLY not tied high | KILLED | KILLED | a_ihp04_256x32_1macro_test | (first macro only) |
| M20 IHP built-in test mux never selected | KILLED | KILLED | a_ihp04_256x32_1macro_test | (first macro only) |
| M21 IHP write-through always requested (A_REN=1) | SURVIVES | SURVIVES |  | write-through only changes the macro's DOUT register during write cycles; the contract samples rdata only in read slots, so the difference is invisible at the interface (it would matter for power and for output-hold assumptions, which the wrapper does not make) |
| M22 test writes use the functional lane mask | KILLED | KILLED | g02_l2_lane_ecc_test_power |  |
| M23 generic array reads on write cycles too | SURVIVES | SURVIVES |  | read-first versus no-change behaviour of the same-cycle read register is unobservable: rdata is meaningful only in a read slot |
