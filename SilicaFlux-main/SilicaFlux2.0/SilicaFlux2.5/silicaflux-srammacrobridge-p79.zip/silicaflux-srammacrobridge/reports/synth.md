# Yosys synthesis evidence

Yosys 0.33 (git sha1 2584903a060).  Vivado/Quartus/OpenROAD were not run.

## GENERIC (generic `synth`; flip-flops are NOT SRAM area)

| config | flip-flops | latches | cells | status |
|---|---|---|---|---|
| default 32x1024 byte-enable | 32801 | 0 | 70764 | PASS |
| lane ECC 128b L2 test | 40384 | 0 | 82978 | PASS |
| word ECC 64b BE0 power | 9291 | 0 | 19364 | PASS |

## FPGA inference

| config | family | RAM primitives | breakdown | latches | $mem left | status |
|---|---|---|---|---|---|---|
| 32x4096 byte-enable block | xc7 | 4 | {"RAMB36E1": 4} | 0 | 0 | PASS |
| 32x4096 byte-enable block | xcup | 4 | {"RAMB36E2": 4} | 0 | 0 | PASS |
| 32x4096 byte-enable block | ice40 | 32 | {"SB_RAM40_4K": 32} | 0 | 0 | PASS |
| 32x4096 byte-enable block | ecp5 | 8 | {"DP16KD": 8} | 0 | 0 | PASS |
| 64b BE0 word-ECC 2048 words block | xc7 | 4 | {"RAMB36E1": 4} | 0 | 0 | PASS |
| 32x1024 AUTO style | xc7 | 1 | {"RAMB36E1": 1} | 0 | 0 | PASS |
| 32x8192 ULTRA hint | xcup | 1 | {"URAM288": 1} | 0 | 0 | PASS |
| lane ECC 32b L2 | xc7 | 2 | {"RAMB36E1": 2} | 0 | 0 | PASS |

## ASIC (macros as black boxes)

| plan | macro | planned | found | other macro types | latches | $mem left | glue FFs | glue cells | status |
|---|---|---|---|---|---|---|---|---|---|
| sfv_a | RM_IHPSG13_1P_2048x32_c2_bm_bist | 5 | 5 | {} | 0 | 0 | 292 | 1601 | PASS |
| sfv_b | RM_IHPSG13_1P_4096x16_c3_bm_bist | 10 | 10 | {} | 0 | 0 | 292 | 1601 | PASS |
| sfv_gf | gf180mcu_fd_ip_sram__sram512x8m8wm1 | 8 | 8 | {} | 0 | 0 | 2 | 42 | PASS |
| sfv_sky | sky130_sram_2kbyte_1rw1r_32x512_8 | 6 | 6 | {} | 0 | 0 | 6 | 438 | PASS |
