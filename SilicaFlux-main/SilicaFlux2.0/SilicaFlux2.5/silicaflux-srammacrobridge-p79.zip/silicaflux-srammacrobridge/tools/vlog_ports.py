#!/usr/bin/env python3
"""Extract the module name, parameters and port list (direction, width) from a vendor SRAM Verilog model.

SilicaFlux SRAMMacroBridge (Project 79).  The model is read as TEXT only (never executed).

Supports the non-ANSI header style used by all three families (names in the header, directions in the body) and
simple ANSI headers.  `ifdef/`ifndef/`else/`endif are resolved against a caller-supplied define set so that e.g. the
SKY130 `USE_POWER_PINS` ports can be included or excluded.  Width expressions may reference module parameters.
"""
import json
import re
import sys


class VlogError(Exception):
    pass


def _strip_comments(t):
    t = re.sub(r"/\*.*?\*/", " ", t, flags=re.S)
    t = re.sub(r"//[^\n]*", "", t)
    return re.sub(r'"(?:[^"\\]|\\.)*"', '""', t)      # string literals can contain the words input/output


def _preprocess(t, defines):
    out, stack = [], []  # stack of (active, taken)
    for line in t.splitlines():
        s = line.strip()
        m = re.match(r"`(ifdef|ifndef)\s+(\w+)", s)
        if m:
            cond = (m.group(2) in defines) == (m.group(1) == "ifdef")
            parent = all(a for a, _ in stack)
            stack.append((cond and parent, cond))
            continue
        if re.match(r"`else\b", s):
            a, taken = stack.pop()
            parent = all(x for x, _ in stack)
            stack.append((parent and not taken, True))
            continue
        if re.match(r"`endif\b", s):
            stack.pop()
            continue
        if re.match(r"`(timescale|celldefine|endcelldefine|default_nettype)\b", s):
            continue
        if all(a for a, _ in stack):
            out.append(line)
    if stack:
        raise VlogError("unbalanced `ifdef")
    return "\n".join(out)


def _eval(expr, params):
    expr = expr.strip()
    if not re.fullmatch(r"[\w\s+\-*()<>]+", expr):
        raise VlogError("unsupported width expression: %r" % expr)
    py = re.sub(r"[A-Za-z_]\w*", lambda m: str(params[m.group(0)]) if m.group(0) in params else _bad(m.group(0)), expr)
    return int(eval(py, {"__builtins__": {}}, {}))  # only digits and + - * << >> ( ) remain


def _bad(n):
    raise VlogError("unknown identifier in width expression: %s" % n)


def parse_ports(text, defines=()):
    t = _preprocess(_strip_comments(text), set(defines))
    m = re.search(r"\bmodule\s+(\w+)\s*(?:#\s*\((.*?)\))?\s*\((.*?)\)\s*;", t, flags=re.S)
    if not m:
        raise VlogError("no module header")
    name, _, hdr = m.group(1), m.group(2), m.group(3)
    body = t[m.end():t.index("endmodule", m.end())]
    params = {}
    for pm in re.finditer(r"\bparameter\s+(?:\w+\s+)?(\w+)\s*=\s*([^;]+);", body):
        try:
            params[pm.group(1)] = _eval(pm.group(2), params)
        except VlogError:
            pass
    ports = {}
    order = []
    ansi = re.findall(r"\b(input|output|inout)\b\s*(?:wire|reg|logic)?\s*(\[[^\]]+\])?\s*(\w+)", hdr)
    names = [n.strip() for n in hdr.replace("\n", " ").split(",") if n.strip()]
    if ansi and len(ansi) == len(names):
        decls = ansi
    else:
        decls = re.findall(r"\b(input|output|inout)\b\s*(?:wire|reg|logic)?\s*(\[[^\]]+\])?\s*([\w\s,]+?)\s*;", body)
        flat = []
        for d, w, ns in decls:
            for n in [x.strip() for x in ns.split(",") if x.strip()]:
                flat.append((d, w, n))
        decls = flat
    for d, w, n in decls:
        width = 1
        if w:
            msb, lsb = w.strip()[1:-1].split(":")
            width = abs(_eval(msb, params) - _eval(lsb, params)) + 1
        ports[n] = {"dir": d, "width": width}
        order.append(n)
    header_names = [re.sub(r"\b(input|output|inout|wire|reg|logic)\b|\[[^\]]*\]", "", n).strip() for n in names]
    missing = [n for n in header_names if n and n not in ports]
    if missing:
        raise VlogError("header ports without declaration: %s" % missing)
    return {"module": name, "params": params, "ports": ports, "order": order}


if __name__ == "__main__":
    print(json.dumps(parse_ports(open(sys.argv[1]).read(), defines=sys.argv[2:]), indent=1))
