#!/usr/bin/env python3
"""Fetch the PUBLIC open-PDK SRAM macro collateral (Verilog model, LEF, Liberty, datasheet / spec CSV)
at the exact upstream commits listed in tools/pins/vendor_sources.json.

SilicaFlux SRAMMacroBridge (Project 79).

  python3 -I tools/fetch_vendor.py --dest build/vendor [--macros NAME ...] [--update-pins] [--verify-only]

Integrity model (three independent layers):
  1. every URL contains a full 40-hex upstream commit id, so the content is immutable upstream;
  2. every fetched file is hashed (SHA-256) and compared with tools/pins/vendor_sha256.json when that
     file exists; a mismatch is a hard error (use --update-pins only when deliberately re-pinning);
  3. for files that the earlier SilicaFlux SRAM Wrapper Library (sramlib) recorded in its own manifests,
     the hash is compared with that independent record ("xcheck"); a mismatch is reported loudly.

The files are treated strictly as DATA.  Nothing downloaded is executed, imported or sourced here;
the parsers (tools/lef_parse.py, tools/lib_parse.py, tools/vlog_ports.py) read them as text.
The vendor files are Apache-2.0 and are NOT redistributed in this package (fetch on demand).
"""
import argparse
import concurrent.futures as cf
import hashlib
import json
import os
import ssl
import sys
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_JSON = os.path.join(HERE, "pins", "vendor_sources.json")
PIN_JSON = os.path.join(HERE, "pins", "vendor_sha256.json")
RAW = "https://raw.githubusercontent.com/{repo}/{commit}/{path}"


def _ssl_ctx():
    for var in ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE"):
        p = os.environ.get(var)
        if p and os.path.isfile(p):
            return ssl.create_default_context(cafile=p)
    return ssl.create_default_context()


def download(url, tries=4):
    last = None
    ctx = _ssl_ctx()
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "silicaflux-srammacrobridge-fetch/1"})
            with urllib.request.urlopen(req, timeout=60, context=ctx) as r:
                return r.read()
        except (urllib.error.URLError, TimeoutError, ConnectionError) as e:  # retry transient failures
            last = e
            time.sleep(1.5 * (k + 1))
    raise RuntimeError("download failed: %s (%s)" % (url, last))


def sha256(b):
    return hashlib.sha256(b).hexdigest()


def file_list(src, names):
    """Return {(source, path): [macro names]} for every file needed."""
    need = {}
    for name in names:
        m = src["macros"][name]
        paths = []
        f = m["files"]
        for k in ("verilog", "lef", "datasheet"):
            if f.get(k):
                paths.append(f[k])
        paths += f.get("liberty", [])
        paths += f.get("spec", [])
        for p in paths:
            need.setdefault((m["source"], p), []).append(name)
    used = {m["source"] for n, m in src["macros"].items() if n in names}
    used |= {s for s, v in src["sources"].items() if v.get("always")}
    for s in sorted(used):
        if src["sources"][s].get("license"):
            need.setdefault((s, src["sources"][s]["license"]), []).append("*")
        for p in src["sources"][s].get("extra_files", []):
            need.setdefault((s, p), []).append("*")
    return need


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dest", default="build/vendor")
    ap.add_argument("--macros", nargs="*", help="macro names (default: all)")
    ap.add_argument("--update-pins", action="store_true", help="(re)write tools/pins/vendor_sha256.json")
    ap.add_argument("--verify-only", action="store_true", help="hash existing files under --dest, download nothing")
    ap.add_argument("--jobs", type=int, default=8)
    a = ap.parse_args(argv)

    src = json.load(open(SRC_JSON))
    names = a.macros or sorted(src["macros"])
    for n in names:
        if n not in src["macros"]:
            sys.exit("unknown macro: %s" % n)
    pins = json.load(open(PIN_JSON)) if os.path.isfile(PIN_JSON) else {}
    recorded = {}
    for n, m in src["macros"].items():
        for p, h in m.get("sramlib_recorded_sha256", {}).items():
            recorded[(m["source"], p)] = h
    for s, v in src["sources"].items():
        # LICENSE hashes recorded by sramlib are keyed without source; resolved per macro above
        pass

    need = file_list(src, names)
    os.makedirs(a.dest, exist_ok=True)
    results, errors = {}, []

    def one(key):
        s, path = key
        out = os.path.join(a.dest, s, path)
        if a.verify_only:
            if not os.path.isfile(out):
                return key, None, "missing"
            data = open(out, "rb").read()
        else:
            if os.path.isfile(out):
                data = open(out, "rb").read()
            else:
                data = download(RAW.format(repo=src["sources"][s]["repo"], commit=src["sources"][s]["commit"], path=path))
                os.makedirs(os.path.dirname(out), exist_ok=True)
                tmp = out + ".part"
                open(tmp, "wb").write(data)
                os.replace(tmp, out)
        return key, sha256(data), len(data)

    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for key, h, size in ex.map(one, sorted(need)):
            s, path = key
            rel = "%s/%s" % (s, path)
            rec = {"sha256": h, "bytes": size}
            if h is None:
                errors.append("%s: %s" % (rel, size))
                continue
            pin = pins.get("files", {}).get(rel)
            if pin and pin != h:
                errors.append("%s: SHA-256 differs from pin (pin %s, got %s)" % (rel, pin, h))
            rec["pin"] = "match" if pin == h else ("NEW" if pin is None else "MISMATCH")
            rh = recorded.get(key)
            if rh is None and path == src["sources"][s].get("license"):
                rh = next((m["sramlib_recorded_sha256"].get("LICENSE") for n2, m in src["macros"].items()
                           if m["source"] == s and "LICENSE" in m.get("sramlib_recorded_sha256", {})), None)
            if rh is not None:
                rec["xcheck_sramlib"] = "match" if rh == h else "MISMATCH"
                if rh != h:
                    errors.append("%s: differs from the hash recorded by sramlib" % rel)
            results[rel] = rec

    summary = {
        "files": len(results),
        "bytes": sum(r["bytes"] for r in results.values()),
        "pin_match": sum(1 for r in results.values() if r["pin"] == "match"),
        "pin_new": sum(1 for r in results.values() if r["pin"] == "NEW"),
        "xcheck_match": sum(1 for r in results.values() if r.get("xcheck_sramlib") == "match"),
        "xcheck_mismatch": sum(1 for r in results.values() if r.get("xcheck_sramlib") == "MISMATCH"),
        "errors": errors,
    }
    json.dump({"summary": summary, "files": results}, open(os.path.join(a.dest, "fetch_report.json"), "w"), indent=1, sort_keys=True)
    if a.update_pins and not errors:
        json.dump({"schema": "silicaflux-srammacrobridge/vendor-sha256/1",
                   "files": {k: v["sha256"] for k, v in sorted(results.items())}},
                  open(PIN_JSON, "w"), indent=1, sort_keys=True)
        print("pins written:", PIN_JSON)
    print(json.dumps({k: v for k, v in summary.items() if k != "errors"}))
    for e in errors:
        print("ERROR:", e, file=sys.stderr)
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
