#!/usr/bin/env python3
"""Minimal, strict LEF reader for SRAM hard macros and technology LEF layers.

SilicaFlux SRAMMacroBridge (Project 79).  Reads the file as DATA (text); nothing is executed.

Macro LEF  -> dict(name, cls, size_um, origin, symmetry, pins{}, obs[])
Tech LEF   -> dict(dbu, layers{name: {type, direction, pitch, width, spacing}})

Only the constructs that occur in the three open-PDK SRAM families are understood.  Anything structural that is
NOT understood raises LefError (no silent skipping of geometry): unknown statements *inside* PIN/PORT/OBS bodies that
carry no geometry (antenna data, SHAPE, PROPERTY, ...) are skipped up to their ';'.

Usage: python3 -I tools/lef_parse.py <file.lef>   (prints a JSON summary)
"""
import json
import re
import sys


class LefError(Exception):
    pass


def tokenize(text):
    out = []
    for line in text.splitlines():
        line = line.split("#", 1)[0]
        line = line.replace(";", " ; ")
        out.extend(line.split())
    return out


def _skip_stmt(t, i):
    while i < len(t) and t[i] != ";":
        i += 1
    return i + 1


def _shape(t, i, layer, sink):
    kind = t[i]
    j = i + 1
    nums = []
    while t[j] != ";":
        # RECT may carry "MASK n" or "ITERATE" modifiers in newer LEF; not used by these macros
        nums.append(float(t[j]))
        j += 1
    if kind == "RECT":
        if len(nums) != 4:
            raise LefError("RECT with %d numbers" % len(nums))
        x1, y1, x2, y2 = nums
        sink.append((layer, min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2), "RECT", None))
    else:  # POLYGON
        xs, ys = nums[0::2], nums[1::2]
        if len(nums) % 2 or len(xs) < 3:
            raise LefError("bad POLYGON")
        sink.append((layer, min(xs), min(ys), max(xs), max(ys), "POLYGON", list(zip(xs, ys))))
    return j + 1


def _body(t, i, sink):
    """Parse LAYER/RECT/POLYGON until the terminating bare END of PORT or OBS."""
    layer = None
    while True:
        k = t[i]
        if k == "END":
            return i + 1
        if k == "LAYER":
            layer = t[i + 1]
            i = _skip_stmt(t, i)
        elif k in ("RECT", "POLYGON"):
            if layer is None:
                raise LefError("shape before LAYER")
            i = _shape(t, i, layer, sink)
        elif k == "VIA":
            raise LefError("VIA inside macro port/obs is not supported")
        else:
            i = _skip_stmt(t, i)


def parse_macro_lef(text):
    t = tokenize(text)
    dbu = 1000
    macros = {}
    i = 0
    while i < len(t):
        if t[i] == "UNITS":
            j = i
            while not (t[j] == "END" and t[j + 1] == "UNITS"):
                if t[j] == "DATABASE" and t[j + 1] == "MICRONS":
                    dbu = int(float(t[j + 2]))
                j += 1
            i = j + 2
            continue
        if t[i] == "MACRO":
            name = t[i + 1]
            m = {"name": name, "cls": None, "size_um": None, "origin": [0.0, 0.0], "symmetry": [], "site": None,
                 "pins": {}, "obs": []}
            i += 2
            while not (t[i] == "END" and t[i + 1] == name):
                k = t[i]
                if k == "CLASS":
                    m["cls"] = " ".join(t[i + 1:t.index(";", i)])
                    i = _skip_stmt(t, i)
                elif k == "SIZE":
                    m["size_um"] = [float(t[i + 1]), float(t[i + 3])]
                    i = _skip_stmt(t, i)
                elif k == "ORIGIN":
                    m["origin"] = [float(t[i + 1]), float(t[i + 2])]
                    i = _skip_stmt(t, i)
                elif k == "SYMMETRY":
                    j = t.index(";", i)
                    m["symmetry"] = t[i + 1:j]
                    i = j + 1
                elif k == "SITE":
                    m["site"] = t[i + 1]
                    i = _skip_stmt(t, i)
                elif k == "PIN":
                    pname = t[i + 1]
                    p = {"dir": None, "use": None, "shapes": []}
                    i += 2
                    while not (t[i] == "END" and t[i + 1] == pname):
                        if t[i] == "DIRECTION":
                            p["dir"] = t[i + 1]
                            i = _skip_stmt(t, i)
                        elif t[i] == "USE":
                            p["use"] = t[i + 1]
                            i = _skip_stmt(t, i)
                        elif t[i] == "PORT":
                            i = _body(t, i + 1, p["shapes"])
                        else:
                            i = _skip_stmt(t, i)
                    i += 2
                    if pname in m["pins"]:
                        raise LefError("duplicate PIN %s" % pname)
                    m["pins"][pname] = p
                elif k == "OBS":
                    i = _body(t, i + 1, m["obs"])
                else:
                    i = _skip_stmt(t, i)
            i += 2
            macros[name] = m
            continue
        i += 1
    if not macros:
        raise LefError("no MACRO found")
    return {"dbu": dbu, "macros": macros}


def parse_tech_lef(text):
    t = tokenize(text)
    dbu = 1000
    layers = {}
    sites = {}
    i = 0
    while i < len(t):
        if t[i] == "SITE" and i + 2 < len(t) and t[i + 2] != ";" and t[i - 1] != "END":   # a definition, not `SITE name ;` inside a MACRO
            name = t[i + 1]
            j = i + 2
            size = None
            while not (t[j] == "END" and t[j + 1] == name):
                if t[j] == "SIZE":
                    size = [float(t[j + 1]), float(t[j + 3])]
                j += 1
            if size:
                sites[name] = size
            i = j + 2
            continue
        if t[i] == "DATABASE" and t[i + 1] == "MICRONS":
            dbu = int(float(t[i + 2]))
        if t[i] == "LAYER" and i + 2 < len(t) and t[i - 1] != "END" and t[i + 2] == "TYPE":
            name = t[i + 1]
            j = i + 2
            L = {"type": None, "direction": None, "pitch": None, "width": None, "spacing": None}
            while not (t[j] == "END" and j + 1 < len(t) and t[j + 1] == name):
                if t[j] == "TYPE":
                    L["type"] = t[j + 1]
                elif t[j] == "DIRECTION":
                    L["direction"] = t[j + 1]
                elif t[j] == "PITCH":
                    L["pitch"] = [float(t[j + 1])] + ([float(t[j + 2])] if t[j + 2] != ";" else [])
                elif t[j] == "WIDTH" and L["width"] is None:
                    L["width"] = float(t[j + 1])
                elif t[j] == "SPACING" and L["spacing"] is None:
                    L["spacing"] = float(t[j + 1])
                j += 1
            layers[name] = L
            i = j + 2
            continue
        i += 1
    return {"dbu": dbu, "layers": layers, "sites": sites}


# ----------------------------------------------------------------------------- summaries
def bus_base(name):
    m = re.match(r"^(.*)\[(\d+)\]$", name)
    return (m.group(1), int(m.group(2))) if m else (name, None)


def pin_bbox(shapes):
    xs1 = min(s[1] for s in shapes)
    ys1 = min(s[2] for s in shapes)
    xs2 = max(s[3] for s in shapes)
    ys2 = max(s[4] for s in shapes)
    return [xs1, ys1, xs2, ys2]


def edge_of(bb, w, h, tol=1e-6):
    """Which macro edge a pin touches/is nearest to: W, E, S, N."""
    cx, cy = (bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2
    d = {"W": cx, "E": w - cx, "S": cy, "N": h - cy}
    return min(sorted(d), key=lambda k: d[k])


def shape_area(s):
    if s[5] == "RECT":
        return (s[3] - s[1]) * (s[4] - s[2])
    pts = s[6]
    a = 0.0
    for (x1, y1), (x2, y2) in zip(pts, pts[1:] + pts[:1]):
        a += x1 * y2 - x2 * y1
    return abs(a) / 2.0


def summarize_macro(m):
    """Geometry facts used by the manifest, floorplan and readiness report."""
    w, h = m["size_um"]
    sig = {}
    pg = {}
    for name, p in m["pins"].items():
        if not p["shapes"]:
            raise LefError("pin %s has no geometry" % name)
        if p["use"] in ("POWER", "GROUND"):
            layers = {}
            for s in p["shapes"]:
                layers.setdefault(s[0], []).append(s)
            pg[name] = {
                "use": p["use"],
                "layers": sorted(layers),
                "shape_count": len(p["shapes"]),
                "bbox_um": pin_bbox(p["shapes"]),
                "area_um2_by_layer": {l: round(sum(shape_area(s) for s in v), 4) for l, v in sorted(layers.items())},
                # stripe orientation per layer: V if shapes are taller than wide on average
                "orientation_by_layer": {l: ("V" if sum((s[4] - s[2]) for s in v) >= sum((s[3] - s[1]) for s in v) else "H")
                                         for l, v in sorted(layers.items())},
            }
        else:
            base, idx = bus_base(name)
            e = sig.setdefault(base, {"dir": p["dir"], "use": p["use"], "bits": {}, "layers": set()})
            bb = pin_bbox(p["shapes"])
            e["bits"][-1 if idx is None else idx] = {"bbox_um": bb, "edge": edge_of(bb, w, h),
                                                    "layers": sorted({s[0] for s in p["shapes"]})}
            e["layers"].update(s[0] for s in p["shapes"])
    sigs = {}
    for base, e in sorted(sig.items()):
        bits = e["bits"]
        edges = sorted({b["edge"] for b in bits.values()})
        sigs[base] = {"dir": e["dir"], "use": e["use"], "width": (max(bits) + 1) if -1 not in bits else 1,
                      "bits": len(bits), "edges": edges, "layers": sorted(e["layers"]),
                      "bbox_um": [min(b["bbox_um"][0] for b in bits.values()), min(b["bbox_um"][1] for b in bits.values()),
                                  max(b["bbox_um"][2] for b in bits.values()), max(b["bbox_um"][3] for b in bits.values())]}
        if -1 not in bits and sorted(bits) != list(range(len(bits))):
            raise LefError("bus %s has non-contiguous bits" % base)
    obs = {}
    for s in m["obs"]:
        o = obs.setdefault(s[0], {"shapes": 0, "bbox_um": [s[1], s[2], s[3], s[4]], "area_sum_um2": 0.0})
        o["shapes"] += 1
        bb = o["bbox_um"]
        o["bbox_um"] = [min(bb[0], s[1]), min(bb[1], s[2]), max(bb[2], s[3]), max(bb[3], s[4])]
        o["area_sum_um2"] += shape_area(s)
    for l, o in obs.items():
        bb = o["bbox_um"]
        o["bbox_covers_outline"] = bool(bb[0] <= 1.0 and bb[1] <= 1.0 and bb[2] >= w - 1.0 and bb[3] >= h - 1.0)
        o["area_sum_um2"] = round(o["area_sum_um2"], 3)
    return {"size_um": [w, h], "area_um2": round(w * h, 4), "class": m["cls"], "origin_um": m["origin"],
            "symmetry": m["symmetry"], "site": m["site"], "pg_pins": pg, "signal_pins": sigs, "obs_layers": obs}


# DEF/OpenDB orientations legal for a LEF SYMMETRY list (LEF 5.8 "SYMMETRY"): N is always legal.
def legal_orientations(symmetry, allow_rotated=False):
    sym = set(symmetry)
    o = ["R0"]
    if "X" in sym:
        o.append("MX")
    if "Y" in sym:
        o.append("MY")
    if "X" in sym and "Y" in sym:
        o.append("R180")
    if allow_rotated and "R90" in sym:
        o += ["R90", "R270", "MXR90", "MYR90"]
    return o


def tech_summary(tech):
    """Routing layers in stack order with direction/pitch."""
    r = [(n, L) for n, L in tech["layers"].items() if L["type"] == "ROUTING"]
    return [{"name": n, "direction": L["direction"], "pitch": L["pitch"], "width": L["width"], "index": k}
            for k, (n, L) in enumerate(r)]


if __name__ == "__main__":
    txt = open(sys.argv[1]).read()
    if "MACRO" in txt:
        d = parse_macro_lef(txt)
        for n, m in d["macros"].items():
            print(json.dumps({"name": n, **summarize_macro(m)}, indent=1))
    else:
        print(json.dumps(tech_summary(parse_tech_lef(txt)), indent=1))
