#!/usr/bin/env python3
"""Tolerant Liberty (.lib) reader for SRAM macros + corner summary.

SilicaFlux SRAMMacroBridge (Project 79).  Reads the file as DATA; nothing is executed.

The three open-PDK SRAM families write Liberty differently (attributes without ';', buses with per-pin and
per-bus timing groups, quoted and unquoted timing types, `min_period` as attribute or as a `minimum_period` timing
group, leakage as attribute or as `leakage_power(){value}`).  This reader normalises all of that into one summary:

    summarize_corner(lib) -> {
        library, corner{process,temperature_c,voltage_v,name}, units{...},
        cell{name, area_um2, dont_use, memory{address_width, word_width}, leakage_nw, pg_pins{}},
        clock_pin,
        clk_to_out_ns{edge, min, max, pins[]},               # access / clock-to-output
        setup_ns{pin: {min,max}},  hold_ns{pin: {min,max}},   # over all slew combinations, rise+fall
        min_pulse_width_ns{high,low}, min_period_ns,         # None when the library does not characterise it
        power{units, internal_power[{pin, when, rise, fall}]},
        power_states: [],                                    # no sleep / retention / shutdown state in any library read
    }

Nothing is estimated: a quantity the library does not contain is reported as None.
"""
import json
import re
import sys

_TOK = re.compile(
    r'''\s*(?:
      (?P<str>"(?:[^"\\]|\\.)*")
    | (?P<num>[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?(?![A-Za-z_\[]))
    | (?P<id>[A-Za-z_][A-Za-z0-9_.$]*(?:\[[0-9:]+\])?)
    | (?P<p>[{}():;,])
    )''', re.X)


class LibError(Exception):
    pass


def _strip(text):
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    text = re.sub(r"//[^\n]*", " ", text)
    text = text.replace("\\\n", " ").replace("\\\r\n", " ")
    return text


def tokenize(text):
    """Return a list of (kind, value, line).  Line numbers survive comment stripping (comments keep their newlines)."""
    text = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), text, flags=re.S)
    text = re.sub(r"//[^\n]*", " ", text)
    text = text.replace("\\\n", "\n").replace("\\\r\n", "\n")  # continuation: keep the line count
    pos, out, n = 0, [], len(text)
    line = 1
    while pos < n:
        m0 = re.compile(r"\s*").match(text, pos)
        line += text.count("\n", pos, m0.end())
        pos = m0.end()
        if pos >= n:
            break
        m = _TOK.match(text, pos)
        if not m:
            raise LibError("cannot tokenise near: %r" % text[pos:pos + 40])
        k = m.lastgroup
        v = m.group(k)
        out.append((k, v[1:-1] if k == "str" else v, line))
        line += text.count("\n", pos, m.end())
        pos = m.end()
    return out


def _is(tok, kind, val):
    return tok[0] == kind and tok[1] == val


def _group(t, i):
    """t[i] is an 'id' for a group/attribute.  Returns (node, next_i)."""
    _, name, line0 = t[i]
    i += 1
    if _is(t[i], "p", ":"):
        # simple attribute: name : value [;]  -- the value ends at ';' or at the end of the line (some libraries omit ';')
        ln = t[i][2]
        i += 1
        vals = []
        while not _is(t[i], "p", ";") and not _is(t[i], "p", "}") and t[i][2] == ln:
            vals.append(t[i][1])
            i += 1
        if _is(t[i], "p", ";"):
            i += 1
        return {"k": "attr", "name": name, "value": " ".join(vals)}, i
    if _is(t[i], "p", "("):
        i += 1
        args = []
        while not _is(t[i], "p", ")"):
            if not _is(t[i], "p", ","):
                args.append(t[i][1])
            i += 1
        i += 1
        if _is(t[i], "p", "{"):
            i += 1
            node = {"k": "group", "name": name, "args": args, "attrs": {}, "cattrs": {}, "cattrs_all": {}, "groups": []}
            while not _is(t[i], "p", "}"):
                sub, i = _group(t, i)
                if sub["k"] == "attr":
                    node["attrs"][sub["name"]] = sub["value"]
                elif sub["k"] == "cattr":
                    node["cattrs"].setdefault(sub["name"], sub["args"])
                    node["cattrs_all"].setdefault(sub["name"], []).append(sub["args"])
                else:
                    node["groups"].append(sub)
            return node, i + 1
        if _is(t[i], "p", ";"):
            i += 1
        return {"k": "cattr", "name": name, "args": args}, i
    raise LibError("unexpected token after %s (line %d): %r" % (name, line0, t[i]))


def parse_liberty(text):
    t = tokenize(text)
    node, i = _group(t, 0)
    if node["k"] != "group" or node["name"] != "library":
        raise LibError("not a Liberty library")
    return node


# ------------------------------------------------------------------ boolean `when` expressions
_WTOK = re.compile(r"\s*(?:(!)|(&|\*)|(\||\+)|(\^)|(\()|(\))|([A-Za-z_][A-Za-z0-9_]*(?:\[\d+\])?)|(\d+'?[bB]?[01]?))")


def eval_when(expr, env):
    """Evaluate a Liberty boolean expression.  env: name -> 0/1.  Raises KeyError for unknown names."""
    toks = []
    pos = 0
    while pos < len(expr):
        if expr[pos:].strip() == "":
            break
        m = _WTOK.match(expr, pos)
        if not m:
            raise LibError("bad when expression: %r" % expr)
        pos = m.end()
        toks.append((m.lastindex, m.group(m.lastindex)))
    p = [0]

    def peek():
        return toks[p[0]][0] if p[0] < len(toks) else None

    def atom():
        k = peek()
        if k == 1:
            p[0] += 1
            return 0 if atom() else 1
        if k == 5:
            p[0] += 1
            v = orx()
            if peek() != 6:
                raise LibError("missing ) in %r" % expr)
            p[0] += 1
            return v
        if k == 7:
            v = env[toks[p[0]][1]]
            p[0] += 1
            return v
        if k == 8:
            v = int(toks[p[0]][1].rstrip("'bB") or 0)
            p[0] += 1
            return v
        raise LibError("bad when expression: %r" % expr)

    def andx():
        v = atom()
        while peek() == 2:
            p[0] += 1
            v = v & atom()
        return v

    def xorx():
        v = andx()
        while peek() == 4:
            p[0] += 1
            v = v ^ andx()
        return v

    def orx():
        v = xorx()
        while peek() == 3:
            p[0] += 1
            v = v | xorx()
        return v

    v = orx()
    if p[0] != len(toks):
        raise LibError("trailing tokens in %r" % expr)
    return v


# ------------------------------------------------------------------ numeric helpers
def _floats(args):
    out = []
    for a in args:
        for x in re.split(r"[,\s]+", a.strip()):
            if x:
                out.append(float(x))
    return out


def _table(g):
    """Return (min, max, mid) of the 'values' of a table group, or None."""
    v = g["cattrs"].get("values")
    if not v:
        return None
    vals = _floats(v)
    if not vals:
        return None
    return {"min": min(vals), "max": max(vals), "mid": vals[len(vals) // 2]}


_LEAK_UNIT_NW = {"1nw": 1.0, "1uw": 1e3, "1mw": 1e6, "1pw": 1e-3, "1w": 1e9}


def _leak_scale(unit):
    u = (unit or "1nW").replace(" ", "").lower()
    if u not in _LEAK_UNIT_NW:
        raise LibError("unknown leakage_power_unit %r" % unit)
    return _LEAK_UNIT_NW[u]


def _base(name):
    return re.sub(r"\[[\d:]+\]$", "", name)


def _walk_pins(cell):
    """Yield (pin_group_name_normalised, direction, pin_node, parent_bus_node_or_None)."""
    for g in cell["groups"]:
        if g["name"] == "pin":
            yield _base(g["args"][0]), g, None
        elif g["name"] == "bus":
            bus = g["args"][0]
            yield bus, g, g
            for s in g["groups"]:
                if s["name"] == "pin":
                    yield bus, s, g


def summarize_corner(lib):
    attrs = lib["attrs"]
    cells = [g for g in lib["groups"] if g["name"] == "cell"]
    if len(cells) != 1:
        raise LibError("expected exactly one cell, found %d" % len(cells))
    cell = cells[0]
    oc = [g for g in lib["groups"] if g["name"] == "operating_conditions"]
    nom = {"process": float(attrs.get("nom_process", "nan")), "temperature_c": float(attrs.get("nom_temperature", "nan")),
           "voltage_v": float(attrs.get("nom_voltage", "nan"))}
    cname = oc[0]["args"][0] if oc else None
    if oc:
        o = oc[0]["attrs"]
        nom = {"process": float(o.get("process", nom["process"])), "temperature_c": float(o.get("temperature", nom["temperature_c"])),
               "voltage_v": float(o.get("voltage", nom["voltage_v"]))}
    cu = lib["cattrs"].get("capacitive_load_unit", [])
    units = {"time": attrs.get("time_unit"), "voltage": attrs.get("voltage_unit"), "current": attrs.get("current_unit"),
             "leakage_power": attrs.get("leakage_power_unit"), "capacitance": "".join(cu)}

    setup, hold, c2o = {}, {}, []
    mpw = {"high": None, "low": None}
    minper = None
    power = []
    whens = set()
    clock_pins = []
    pins = {}
    pgp = {}
    for g in cell["groups"]:
        if g["name"] == "pg_pin":
            pgp[g["args"][0]] = g["attrs"].get("pg_type")

    def merge(d, key, tb):
        if tb is None:
            return
        e = d.setdefault(key, {"min": tb["min"], "max": tb["max"]})
        e["min"] = min(e["min"], tb["min"])
        e["max"] = max(e["max"], tb["max"])

    for name, node, bus in _walk_pins(cell):
        direction = node["attrs"].get("direction") or (bus["attrs"].get("direction") if bus else None)
        pins.setdefault(name, {"direction": direction})
        if node["attrs"].get("direction"):
            pins[name]["direction"] = node["attrs"]["direction"]
        if node["attrs"].get("clock", "").strip('"').lower() == "true":
            if name not in clock_pins:
                clock_pins.append(name)
        for a in ("min_pulse_width_high", "min_pulse_width_low", "min_period"):
            if a in node["attrs"]:
                v = float(node["attrs"][a])
                if a == "min_period":
                    minper = v
                else:
                    mpw["high" if a.endswith("high") else "low"] = v
        for sub in node["groups"]:
            if sub["name"] == "timing" and sub["attrs"].get("when"):
                whens.add(sub["attrs"]["when"].strip('"'))
            if sub["name"] == "timing":
                tt = sub["attrs"].get("timing_type", "combinational").strip('"')
                related = sub["attrs"].get("related_pin", "").strip('"')
                tabs = {s["name"]: _table(s) for s in sub["groups"] if _table(s)}
                if tt == "setup_rising":
                    for k in ("rise_constraint", "fall_constraint"):
                        merge(setup, name, tabs.get(k))
                elif tt == "hold_rising":
                    for k in ("rise_constraint", "fall_constraint"):
                        merge(hold, name, tabs.get(k))
                elif tt in ("rising_edge", "falling_edge"):
                    vals = [tabs[k] for k in ("cell_rise", "cell_fall") if k in tabs]
                    if vals:
                        c2o.append({"pin": name, "edge": tt, "related": related,
                                    "min": min(v["min"] for v in vals), "max": max(v["max"] for v in vals)})
                elif tt == "min_pulse_width":
                    for k, side in (("rise_constraint", "high"), ("fall_constraint", "low")):
                        if k in tabs:
                            mpw[side] = tabs[k]["max"] if mpw[side] is None else max(mpw[side], tabs[k]["max"])
                    if "rise_constraint" in tabs and "fall_constraint" not in tabs:
                        mpw["low"] = mpw["high"] if mpw["low"] is None else mpw["low"]
                elif tt == "minimum_period":
                    vals = [tabs[k]["max"] for k in ("rise_constraint", "fall_constraint") if k in tabs]
                    if vals:
                        minper = max(vals)
            elif sub["name"] == "internal_power":
                rp = [s for s in sub["groups"] if s["name"] == "rise_power"]
                fp = [s for s in sub["groups"] if s["name"] == "fall_power"]
                power.append({"pin": name, "when": sub["attrs"].get("when", "").strip('"'),
                              "rise": _table(rp[0]) if rp else None, "fall": _table(fp[0]) if fp else None})
    leak = None
    if "cell_leakage_power" in cell["attrs"]:
        leak = float(cell["attrs"]["cell_leakage_power"])
    else:
        lg = [g for g in cell["groups"] if g["name"] == "leakage_power"]
        if lg and "value" in lg[0]["attrs"]:
            leak = float(lg[0]["attrs"]["value"])
    mem = [g for g in cell["groups"] if g["name"] == "memory"]
    memory = None
    if mem:
        memory = {"type": mem[0]["attrs"].get("type"), "address_width": int(mem[0]["attrs"].get("address_width", 0)),
                  "word_width": int(mem[0]["attrs"].get("word_width", 0))}
    # statements whose 'when' differ per power state would show up here; no library read has a sleep/retention state
    pstates = [g["args"][0] for g in cell["groups"] if g["name"] in ("pg_pin",) and g["attrs"].get("pg_type") not in
               ("primary_power", "primary_ground")]
    return {
        "library": lib["args"][0],
        "corner": {"name": cname, **nom},
        "units": units,
        "cell": {"name": cell["args"][0], "area_um2": float(cell["attrs"].get("area", "nan")),
                 "dont_use": cell["attrs"].get("dont_use", "").lower() in ("true", "\"true\""),
                 "memory": memory, "leakage_nw": None if leak is None else round(leak * _leak_scale(units["leakage_power"]), 6),
                 "pg_pins": pgp},
        "clock_pins": clock_pins,
        "pins": pins,
        "clk_to_out_ns": {x["pin"]: {"edge": x["edge"], "related": x["related"], "min": x["min"], "max": x["max"]} for x in c2o},
        "setup_ns": setup, "hold_ns": hold,
        "min_pulse_width_ns": mpw, "min_period_ns": minper,
        "power": {"internal_power_unit": "as library (" + units["capacitance"] + " x " + str(units["voltage"]) + "^2 per toggle)",
                  "internal_power": power},
        "power_states": pstates,
        "voltage_map": {a[0]: float(a[1]) for a in lib["cattrs_all"].get("voltage_map", []) if len(a) == 2},
        "when_conditions": sorted(whens),
    }


if __name__ == "__main__":
    lib = parse_liberty(open(sys.argv[1]).read())
    s = summarize_corner(lib)
    s["power"]["internal_power"] = s["power"]["internal_power"][:3]
    print(json.dumps(s, indent=1))
