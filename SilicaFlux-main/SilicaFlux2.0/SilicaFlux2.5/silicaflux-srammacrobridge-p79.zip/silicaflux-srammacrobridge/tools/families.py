"""Curated per-family macro semantics (SilicaFlux SRAMMacroBridge, Project 79).

This table is the ONLY hand-written knowledge about the macros.  It states, per family, which physical pin plays which
logical role and with which polarity.  build_manifest.py then VERIFIES every statement against the real files:

  * every pin named here must exist, with the stated direction and width relation, in the vendor Verilog model,
    in the LEF and in every Liberty corner;
  * the declared polarity must not contradict the Liberty `when` conditions (an access-only condition must be false in
    the declared idle state);
  * unlisted pins must not exist (so a new macro revision with an extra test/sleep/ECC/repair pin fails the build
    instead of being silently ignored).

`evidence` names the vendor document each semantic comes from; the file-level provenance (repo, commit, SHA-256) is in
tools/pins/vendor_sources.json and tools/pins/vendor_sha256.json.

Pin-spec conventions
  "bus"  : pin name; width == macro data width (BITS), address width (AW) or mask width as stated by 'w'.
  w      : "1" | "BITS" | "AW" | "MASKBITS" (BITS for bit-mask, BITS//8 for byte-mask)
  pol    : "H" active high, "L" active low
"""

FAMILIES = {
    # ------------------------------------------------------------------------------------------------ IHP SG13G2
    "IHP_1P": {
        "memory_tech": "ASIC_IHP_SG13G2",
        "foundry": "IHP Microelectronics (open PDK)",
        "process": "SG13G2 130 nm SiGe:C BiCMOS",
        "pdk": "IHP-Open-PDK (Apache-2.0)",
        "topology": "1RW",
        # nominal corner = the vendor's own 'typical' condition (IHP datasheet: tc_1d20V_25C)
        "nominal_corner": "typ_1p20V_25C",
        # placement site of the std-cell platform used by FloorplanLab/ORFS for this PDK (existence + size verified in the LEF)
        "core_site": "CoreSite",
        "pins": {
            "clk": {"name": "A_CLK", "w": "1"},
            "ce": {"name": "A_MEN", "w": "1", "pol": "H"},
            "we": {"name": "A_WEN", "w": "1", "pol": "H"},
            "re": {"name": "A_REN", "w": "1", "pol": "H"},
            "addr": {"name": "A_ADDR", "w": "AW"},
            "din": {"name": "A_DIN", "w": "BITS"},
            "dout": {"name": "A_DOUT", "w": "BITS"},
            "mask": {"name": "A_BM", "w": "MASKBITS", "pol": "H"},
            "tie_high": [{"name": "A_DLY", "w": "1"}],
        },
        "test_pins": {
            "en": {"name": "A_BIST_EN", "w": "1", "pol": "H"},
            "clk": {"name": "A_BIST_CLK", "w": "1"},
            "ce": {"name": "A_BIST_MEN", "w": "1", "pol": "H"},
            "we": {"name": "A_BIST_WEN", "w": "1", "pol": "H"},
            "re": {"name": "A_BIST_REN", "w": "1", "pol": "H"},
            "addr": {"name": "A_BIST_ADDR", "w": "AW"},
            "din": {"name": "A_BIST_DIN", "w": "BITS"},
            "mask": {"name": "A_BIST_BM", "w": "MASKBITS", "pol": "H"},
        },
        # control encodings used by the adapter (logical level -> pin levels)
        "read_cycle": {"ce": 1, "we": 0, "re": 1},
        "write_cycle": {"ce": 1, "we": 1, "re": 0},
        "idle_cycle": {"ce": 0, "we": 0, "re": 0},
        "mask_granularity_bits": 1,
        "read_latency_cycles": 1,
        "access_edge": "rising",
        "output_hold": "HELD: A_DOUT is a register updated only by a read or write-through (core model RM_IHPSG13_1P_core_behavioral_bm_bist.v)",
        "write_through": "defined: A_WEN=1 and A_REN=1 with A_MEN=1 returns the written word (not used by the adapter: A_REN = ~we)",
        "same_cycle_rw": "not applicable (single port; A_WEN/A_REN select the operation)",
        "test_mux": "BUILT-IN: A_BIST_EN selects the *_BIST_* inputs AND A_BIST_CLK in place of A_CLK (core model CLK_MUX)",
        "test_handover_rule": "datasheet: one cycle before and after A_BIST_EN changes no read, write or write-through is allowed (set A_MEN and A_BIST_MEN to 0)",
        "constraints": ["A_DLY must be tied to 1 (datasheet 'MANDATORY'; model $stop otherwise)"],
        "evidence": ["verilog/<macro>.v", "verilog/RM_IHPSG13_1P_core_behavioral_bm_bist.v", "doc/<macro>.txt (operation tables)",
                     "lib/<macro>_*.lib"],
        "supply": {"lib": ["VDD", "VDDARRAY", "VSS"], "lef_suffix": "!"},
        "sleep_retention": {"supported": False, "evidence": "no sleep/retention/shutdown pin in Verilog, LEF or Liberty; "
                                                           "datasheet: 'A_MEN low deactivates the memory'"},
        "ecc_builtin": False,
        "redundancy": False,
        "repair_interface": False,
        "uninitialised_array": "undefined at power-up (core model reg array without initial value)",
    },
    # ------------------------------------------------------------------------------------------------ GF180MCU
    "GF180_1RW": {
        "memory_tech": "ASIC_GF180MCU",
        "foundry": "GlobalFoundries (open PDK, via Google/GF)",
        "process": "GF180MCU 180 nm (018 5V green SRAM)",
        "pdk": "globalfoundries-pdk-ip-gf180mcu_fd_ip_sram (Apache-2.0)",
        "topology": "1RW",
        # nominal corner = vendor spec column 'Typical Process 3.3v, 25C' (specs/5_AC_Characteristics2.csv)
        "nominal_corner": "tt_025C_3v30",
        "core_site": "GF018hv5v_green_sc9",
        "pins": {
            "clk": {"name": "CLK", "w": "1"},
            "ce": {"name": "CEN", "w": "1", "pol": "L"},
            "we": {"name": "GWEN", "w": "1", "pol": "L"},
            "addr": {"name": "A", "w": "AW"},
            "din": {"name": "D", "w": "BITS"},
            "dout": {"name": "Q", "w": "BITS"},
            "mask": {"name": "WEN", "w": "MASKBITS", "pol": "L"},
        },
        "test_pins": {},
        "read_cycle": {"ce": 1, "we": 0},
        "write_cycle": {"ce": 1, "we": 1},
        "idle_cycle": {"ce": 0, "we": 0},
        "mask_granularity_bits": 1,
        "read_latency_cycles": 1,
        "access_edge": "rising",
        "output_hold": "HELD: Q keeps its previous value in write, mask and standby cycles (specs/2_truth_table.csv)",
        "write_through": "none: a write cycle holds Q",
        "same_cycle_rw": "not applicable (single port; GWEN selects the operation)",
        "test_mux": "NONE: the macro has no test pins; a fabric mux is required for MBIST access",
        "test_handover_rule": None,
        "constraints": ["CEN must be high before the first running cycle (specs/1_pins_desc.csv); the model ignores accesses "
                        "until it has seen a CEN 1->0 transition",
                        "library cell is dont_use/dont_touch: it must be instantiated, never inferred"],
        "evidence": ["<macro>.v", "specs/1_pins_desc.csv", "specs/2_truth_table.csv", "specs/5_AC_Characteristics2.csv",
                     "specs/6_Physical_Dimensions.csv", "<macro>__<corner>.lib"],
        "supply": {"lib": ["VDD", "VSS"], "lef_suffix": ""},
        "sleep_retention": {"supported": False, "evidence": "no sleep/retention pin; 'CEN high: deactivated but internal states retained' is "
                                                           "ordinary standby, not a power state with its own timing"},
        "ecc_builtin": False,
        "redundancy": False,
        "repair_interface": False,
        "uninitialised_array": "model initialises to 0; silicon content is undefined at power-up",
    },
    # ------------------------------------------------------------------------------------------------ SKY130 OpenRAM
    "SKY130_1RW1R": {
        "memory_tech": "ASIC_SKY130_OPENRAM",
        "foundry": "SkyWater (open PDK), OpenRAM-generated",
        "process": "SKY130 130 nm",
        "pdk": "efabless/sky130_sram_macros (Apache-2.0)",
        "topology": "1RW1R",
        # only one Liberty corner is published for these macros
        "nominal_corner": "TT_1p8V_25C",
        "core_site": "unithd",
        "pins": {
            "clk": {"name": "clk0", "w": "1"},
            "ce": {"name": "csb0", "w": "1", "pol": "L"},
            "we": {"name": "web0", "w": "1", "pol": "L"},
            "addr": {"name": "addr0", "w": "AW"},
            "din": {"name": "din0", "w": "BITS"},
            "dout": {"name": "dout0", "w": "BITS"},
            "mask": {"name": "wmask0", "w": "MASKBITS", "pol": "H"},
            # unused read-only port 1: held inactive by the adapter
            "p1_clk": {"name": "clk1", "w": "1"},
            "p1_ce": {"name": "csb1", "w": "1", "pol": "L"},
            "p1_addr": {"name": "addr1", "w": "AW"},
            "p1_dout": {"name": "dout1", "w": "BITS"},
        },
        "test_pins": {},
        "read_cycle": {"ce": 1, "we": 0},
        "write_cycle": {"ce": 1, "we": 1},
        "idle_cycle": {"ce": 0, "we": 0},
        "mask_granularity_bits": 8,
        "read_latency_cycles": 1,
        "access_edge": "falling",
        "output_hold": "NOT HELD: the model drives dout X T_HOLD after every rising clk edge; capture it exactly one cycle after the read",
        "write_through": "none",
        "same_cycle_rw": "cross-port same-address write(port0)+read(port1) UNDEFINED (model warns); port1 unused by the adapter",
        "test_mux": "NONE: the macro has no test pins; a fabric mux is required for MBIST access",
        "test_handover_rule": None,
        "constraints": ["port1 (read-only) is held inactive: csb1=1",
                        "Liberty launches dout on the FALLING clock edge (half-cycle access); the Verilog model uses an arbitrary "
                        "DELAY=3 (its own header says so): never use the model delay for timing",
                        "write mask granularity is 8 bits"],
        "evidence": ["<macro>.v (header comments, MEM_WRITE0/MEM_READ0 blocks)", "<macro>_TT_1p8V_25C.lib"],
        "supply": {"lib": ["vccd1", "vssd1"], "lef_suffix": ""},
        "sleep_retention": {"supported": False, "evidence": "no sleep/retention pin in Verilog, LEF or Liberty"},
        "ecc_builtin": False,
        "redundancy": False,
        "repair_interface": False,
        "uninitialised_array": "undefined (model reg array without initial value)",
    },
}

FAMILY_ORDER = ["IHP_1P", "GF180_1RW", "SKY130_1RW1R"]
# numeric family codes shared with the RTL (rtl/sf_sram_macro_defs.svh: SF_MEM_TECH_ASIC_*)
FAMILY_CODE = {"IHP_1P": 10, "GF180_1RW": 11, "SKY130_1RW1R": 12}
