#!/usr/bin/env python3
"""Verify a generated floorplan: (1) run the generated Tcl under a mock OpenDB (tclsh), (2) compare what the Tcl did with
floorplan.json, (3) re-check the geometry independently in Python (bounds, overlap, halos, grid, orientation, dimensions,
instance names, PG pin names against the manifest).

  python3 -I tools/check_floorplan.py physical/NAME [--manifests manifests] [--tclsh tclsh8.6]

Exit 0 only if everything agrees.  This validates the Tcl and the geometry; it is NOT an OpenROAD run.
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("dir")
    ap.add_argument("--manifests", default=os.path.join(HERE, "..", "manifests"))
    ap.add_argument("--tclsh", default="tclsh8.6")
    ap.add_argument("--report")
    a = ap.parse_args(argv)
    d = a.dir
    fp = json.load(open(os.path.join(d, "floorplan.json")))
    inst = json.load(open(os.path.join(d, "instances.json")))
    man = json.load(open(os.path.join(a.manifests, fp["macro"] + ".json")))
    problems = []
    checks = []

    def chk(name, ok, detail=""):
        checks.append({"check": name, "result": "PASS" if ok else "FAIL", "detail": detail})
        if not ok:
            problems.append("%s %s" % (name, detail))

    # ---- (1) run the Tcl under the mock
    out = tempfile.NamedTemporaryFile(suffix=".json", delete=False).name
    cmd = [a.tclsh, os.path.join(HERE, "..", "physical", "mock_odb.tcl"), os.path.join(d, "macros.tsv"), out,
           os.path.join(d, "floorplan.tcl"), os.path.join(d, "macro_place.tcl"), os.path.join(d, "check_macros.tcl"),
           os.path.join(d, "pdn_connect.tcl")]
    r = subprocess.run(cmd, capture_output=True, text=True)
    chk("generated Tcl runs under the mock OpenDB (floorplan, macro_place, check_macros, pdn_connect)", r.returncode == 0,
        (r.stdout + r.stderr)[-400:] if r.returncode else "")
    if r.returncode != 0:
        tail = [l for l in (r.stdout + r.stderr).splitlines() if "SF-" in l or "error" in l.lower()][-6:]
        for k in checks:
            print("%-4s %s %s" % (k["result"], k["check"], ("-- " + " | ".join(tail)) if k["result"] == "FAIL" else ""))
        print("floorplan check: FAIL (mock OpenDB run of the generated Tcl failed; OpenROAD was NOT run)")
        return 1
    mock = json.load(open(out))
    os.unlink(out)
    # ---- (2) the Tcl did what floorplan.json says
    chk("mock die/core equal floorplan.json", mock["die"] == fp["die"] and mock["core"] == fp["core"], "%s %s" % (mock["die"], mock["core"]))
    chk("mock site equals floorplan.json", mock["site"] == fp["site"])
    dbu = fp["dbu"]
    pm = {p["name"]: p for p in fp["placements"]}
    ok = True
    for i in mock["insts"]:
        p = pm.get(i["name"])
        if not p or i["x"] != round(p["x"] * dbu) or i["y"] != round(p["y"] * dbu) or i["orient"] != p["orient"] or i["status"] != "FIRM":
            ok = False
            problems.append("mock placement of %s differs: %s vs %s" % (i["name"], i, p))
    chk("every macro placed FIRM at the floorplan.json location/orientation by the Tcl", ok and len(mock["insts"]) == len(fp["placements"]))
    chk("halo blockages created (one per macro)", len(mock["blockages"]) == len(fp["halos"]))
    pats = {g[1] for g in mock["global_connections"]}
    want = {"^%s$" % n for n in man["geometry"]["pg_pins"]}
    chk("global connections cover exactly the LEF PG pin names", pats == want, "%s vs %s" % (sorted(pats), sorted(want)))
    # ---- (3) independent geometry
    W, H = man["geometry"]["size_um"]
    chk("macro size in floorplan.json equals the LEF size", fp["macro_size_um"] == [W, H])
    names = {i["name"] for i in inst["instances"]}
    chk("placed instance names == synthesized netlist macro instances", set(pm) == names)
    chk("masters equal the planned macro", all(p["master"] == man["macro_name"] for p in fp["placements"]))
    legal = set(man["geometry"]["legal_orientations"])
    chk("orientations are legal per LEF SYMMETRY", all(p["orient"] in legal for p in fp["placements"]), str(sorted({p["orient"] for p in fp["placements"]})))
    c = fp["core"]
    inside = all(p["bbox"][0] >= c[0] - 1e-6 and p["bbox"][1] >= c[1] - 1e-6 and p["bbox"][2] <= c[2] + 1e-6 and p["bbox"][3] <= c[3] + 1e-6 for p in fp["placements"])
    chk("all macros inside the core", inside)
    chk("core inside die", fp["die"][0] <= c[0] and fp["die"][1] <= c[1] and c[2] <= fp["die"][2] and c[3] <= fp["die"][3])
    ov = []
    ps = fp["placements"]
    for i in range(len(ps)):
        for j in range(i + 1, len(ps)):
            a1, b1 = ps[i]["bbox"], ps[j]["bbox"]
            if a1[0] < b1[2] and b1[0] < a1[2] and a1[1] < b1[3] and b1[1] < a1[3]:
                ov.append((ps[i]["name"], ps[j]["name"]))
    chk("no two macros overlap", not ov, str(ov[:3]))
    h = fp["halo_um"]
    gap_ok = True
    for i in range(len(ps)):
        for j in range(i + 1, len(ps)):
            a1, b1 = ps[i]["bbox"], ps[j]["bbox"]
            dx = max(b1[0] - a1[2], a1[0] - b1[2], 0)
            dy = max(b1[1] - a1[3], a1[1] - b1[3], 0)
            if dx < h - 1e-6 and dy < h - 1e-6:        # B lies inside A's halo rectangle
                gap_ok = False
    chk("macro-to-macro spacing >= halo (halos never intrude into a neighbour)", gap_ok)
    sw, sh = fp["site_size_um"]
    snapped = all(abs((p["bbox"][0] - c[0]) / sw - round((p["bbox"][0] - c[0]) / sw)) < 1e-6 and abs((p["bbox"][1] - c[1]) / sh - round((p["bbox"][1] - c[1]) / sh)) < 1e-6 for p in ps)
    chk("macro lower-left corners lie on the placement-site grid (core-relative)", snapped)
    chk("core origin on the site grid", abs(c[0] / sw - round(c[0] / sw)) < 1e-6 and abs(c[1] / sh - round(c[1] / sh)) < 1e-6)
    mg = 0.005
    chk("coordinates on the 0.005 um manufacturing grid", all(abs(v / mg - round(v / mg)) < 1e-6 for p in ps for v in p["bbox"]))
    pg_ok = all(n in man["geometry"]["pg_pins"] for n in fp["pg"]["nets"]) and len(fp["pg"]["nets"]) == len(man["geometry"]["pg_pins"])
    chk("PG nets use exactly the LEF PG pins", pg_ok)
    chk("PG pin layers are blocked/used layers and routing is free above them",
        all(l in fp["routing"]["tech_routing_layers"] for l in fp["routing"]["macro_pg_layers"]) and fp["routing"]["free_above_macro"] is not None)
    res = {"dir": d, "plan": fp["plan"], "macro": fp["macro"], "openroad_executed": False, "checks": checks, "status": "PASS" if not problems else "FAIL"}
    if a.report:
        json.dump(res, open(a.report, "w"), indent=1)
    for k in checks:
        print("%-4s %s %s" % (k["result"], k["check"], ("-- " + k["detail"]) if k["detail"] and k["result"] == "FAIL" else ""))
    print("floorplan check:", res["status"], "(mock OpenDB; OpenROAD was NOT run)")
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(main())
