#!/usr/bin/env python3
"""Generate the OpenROAD floorplan inputs for a planned SRAM macro array.

  python3 -I tools/gen_floorplan.py --plan configs/generated/NAME.plan.json --instances physical/NAME/instances.json \
          --manifests manifests --out physical/NAME [--halo 10] [--channel 20] [--pin-channel 40] [--die-margin 40]
                                                    [--pin-facing pairs|uniform] [--logic-area-um2 0] [--core-voltage V]

Inputs that make the output REAL rather than invented:
  * instance names  : from physical/NAME/instances.json (Yosys-flattened netlist, tools/synth_instances.py);
  * dimensions, orientation symmetry, PG pin names/layers, signal-pin edges, blocked/free routing layers, placement
    site and its size : from the manifest, i.e. from the vendor LEF and the technology/std-cell LEF;
  * supply voltages : from the vendor Liberty `voltage_map`.
Everything that is a CHOICE (halo, channel widths, die margin, pin-facing policy, supply tie of the array supply) is a
named option, carried into floorplan.json under "assumptions" with its provenance.  Missing physical data => the
generator stops with PHYSICAL_INCOMPLETE instead of guessing.

Outputs (physical/NAME/):  floorplan.json  floorplan.tcl  macro_place.tcl  pdn_connect.tcl  load_design.tcl
                           check_macros.tcl  macros.tsv (for the mock OpenDB run)  README.md
The Tcl uses OpenROAD commands and the OpenDB Tcl API.  It was NOT executed by OpenROAD in the generating environment (no
OpenROAD available); tools/run_mock_odb.py runs the placement/check Tcl against a mock OpenDB under tclsh to prove the
Tcl is well-formed and does what floorplan.json says.  See docs/04_physical.md.
"""
import argparse
import json
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

EDGE_FLIP = {"R0": {}, "MX": {"N": "S", "S": "N"}, "MY": {"E": "W", "W": "E"}, "R180": {"N": "S", "S": "N", "E": "W", "W": "E"}}


class Incomplete(Exception):
    pass


def snap_up(v, step):
    return math.ceil(round(v / step, 9)) * step


def r3(v):
    return round(v, 3)


def edges_after(orient, edges):
    return {EDGE_FLIP[orient].get(e, e) for e in edges}


def pick_orient(legal, pin_edges, want):
    for o in ("R0", "MX", "MY", "R180"):
        if o in legal and want in edges_after(o, pin_edges):
            return o
    return None


def tcl_list_item(*vals):
    return "  {" + " ".join(str(v) for v in vals) + "}\n"


def build(plan, inst, man, o):
    sel = plan["selected"]
    g = man["geometry"]
    if not g.get("tech_lef") or not g.get("tech_routing_layers"):
        raise Incomplete("technology LEF not ingested: legal routing layers unknown")
    site = g["default_core_site"]
    if site not in g["tech_sites_um"]:
        raise Incomplete("placement site %s not found in the technology LEF" % site)
    sw, sh = g["tech_sites_um"][site]
    W, H = g["size_um"]
    nr, nc = sel["tiling"]["rows"], sel["tiling"]["columns"]
    legal = g["legal_orientations"]
    pin_edges = set(g["pins_edges"])
    if not inst.get("consistent_with_plan"):
        raise Incomplete("instances.json is not consistent with the plan")
    by_rc = {(i["row"], i["col"]): i for i in inst["instances"]}
    warnings = []

    # ---- orientation per row
    orients = {}
    for r in range(nr):
        if o["pin_facing"] == "uniform":
            orients[r] = "R0"
            continue
        want = "N" if (r % 2 == 0 and r + 1 < nr) else "S"      # lower row of a pair faces up, upper row (or a lone row) faces down
        po = pick_orient(legal, pin_edges, want)
        if po is None:
            po = "R0"
            warnings.append("row %d: no legal orientation puts a pin edge on %s; using R0" % (r, want))
        orients[r] = po
    # ---- coordinates (core-relative, then shifted by the die margin); site-grid snapped
    xs = []
    x = 0.0
    for c in range(nc):
        xs.append(x)
        x = snap_up(x + W + max(o["channel"], 2 * o["halo"]), sw)
    ys = []
    y = 0.0
    for r in range(nr):
        ys.append(y)
        gap = o["pin_channel"] if (o["pin_facing"] == "pairs" and r % 2 == 0 and r + 1 < nr) else max(o["channel"], 2 * o["halo"])
        y = snap_up(y + H + gap, sh)
    blk_w = snap_up(xs[-1] + W, sw)
    core_h = snap_up(ys[-1] + H, sh)
    core_w = blk_w
    logic_rel = None            # core-relative rectangle reserved for the wrapper logic (only if --logic-area-um2 > 0)
    if o["logic_area"] > 0:
        core_w = blk_w + snap_up(o["logic_area"] / core_h, sw)
        logic_rel = [blk_w, 0.0, core_w, core_h]
    m = snap_up(o["die_margin"], max(sw, sh))
    m = snap_up(m, sh)
    off_x = snap_up(m, sw)
    off_y = m
    core = [r3(off_x), r3(off_y), r3(off_x + core_w), r3(off_y + core_h)]
    die = [0.0, 0.0, r3(core[2] + off_x), r3(core[3] + off_y)]
    placements = []
    halos = []
    for r in range(nr):
        for c in range(nc):
            i = by_rc[(r, c)]
            px, py = r3(off_x + xs[c]), r3(off_y + ys[r])
            placements.append({"name": i["name"], "master": i["master"], "row": r, "col": c, "x": px, "y": py, "orient": orients[r],
                               "bbox": [px, py, r3(px + W), r3(py + H)]})
            hb = [max(core[0], r3(px - o["halo"])), max(core[1], r3(py - o["halo"])), min(core[2], r3(px + W + o["halo"])),
                  min(core[3], r3(py + H + o["halo"]))]
            halos.append({"for": i["name"], "bbox": hb})
    # ---- power/ground connections from the REAL LEF pin names
    vm_ok = True
    nets = {}
    for pn, pg in sorted(g["pg_pins"].items()):
        base = pn.rstrip("!")
        net = o["power_net"] if pg["use"] == "POWER" else o["ground_net"]
        nets[pn] = {"net": net, "use": pg["use"], "layers": pg["layers"], "orientation_by_layer": pg["orientation_by_layer"],
                    "shape_count": pg["shape_count"], "bbox_um": pg["bbox_um"]}
    # verify that tying separate array/logic supplies to ONE net is consistent with the vendor Liberty
    supply_notes = []
    pow_pins = [p.rstrip("!") for p, v in g["pg_pins"].items() if v["use"] == "POWER"]
    if len(pow_pins) > 1:
        for cn in man["timing"]["corners"]:
            vmap = cn.get("voltage_map", {})
            vs = {p: vmap.get(p) for p in pow_pins}
            if None in vs.values():
                vm_ok = False
                supply_notes.append("corner %s: Liberty voltage_map lacks %s" % (cn["id"], [p for p, v in vs.items() if v is None]))
            elif len(set(vs.values())) > 1:
                vm_ok = False
                supply_notes.append("corner %s: power pins have DIFFERENT voltages %s: they cannot share one net" % (cn["id"], vs))
        if not vm_ok:
            raise Incomplete("power pins %s are not all at the same voltage in every Liberty corner: a separate supply is required (%s)" % (
                pow_pins, "; ".join(supply_notes)))
        supply_notes.append("power pins %s have identical voltage in all %d Liberty corners (voltage_map) -> one net %s is consistent" % (
            pow_pins, len(man["timing"]["corners"]), o["power_net"]))
    corners = [{"id": c["id"], "process": c["process"], "temperature_c": c["temperature_c"], "voltage_v": c["voltage_v"]} for c in man["timing"]["corners"]]
    nominal = next(c for c in corners if c["id"] == man["timing"]["nominal_corner"])
    core_v = o["core_voltage"] if o["core_voltage"] is not None else nominal["voltage_v"]
    vmatch = [c["id"] for c in corners if abs(c["voltage_v"] - core_v) < 1e-6 and c["process"] == 1.0 and abs(c["temperature_c"] - 25) < 1e-6]
    if not vmatch:
        warnings.append("no typical-process 25 C Liberty corner at the core voltage %.2f V: pick STA corners explicitly" % core_v)
    layers = {"tech_routing_layers": [x["name"] for x in g["tech_routing_layers"]],
              "blocked_over_macro": g["routing_layers_blocked_over_macro"], "free_above_macro": g["routing_layers_free_above_macro"],
              "macro_pg_layers": sorted({l for p in g["pg_pins"].values() for l in p["layers"]}),
              "macro_signal_pin_layers": sorted({l for p in g["signal_pins"].values() for l in p["layers"]})}
    top_pg = max((layers["tech_routing_layers"].index(l) for l in layers["macro_pg_layers"] if l in layers["tech_routing_layers"]), default=None)
    pdn_up = layers["tech_routing_layers"][top_pg + 1] if top_pg is not None and top_pg + 1 < len(layers["tech_routing_layers"]) else None
    assumptions = [
        {"name": "halo_um", "value": o["halo"], "provenance": "ASSUMPTION (option --halo): no vendor halo rule was found in the Verilog/LEF/Liberty/datasheet files"},
        {"name": "channel_um", "value": o["channel"], "provenance": "ASSUMPTION (option --channel); the generator uses max(channel, 2*halo)"},
        {"name": "pin_channel_um", "value": o["pin_channel"], "provenance": "ASSUMPTION (option --pin-channel): routing/logic channel between facing pin edges"},
        {"name": "die_margin_um", "value": o["die_margin"], "provenance": "ASSUMPTION (option --die-margin)"},
        {"name": "pin_facing", "value": o["pin_facing"], "provenance": "POLICY (option --pin-facing)"},
        {"name": "orientations", "value": legal, "provenance": "LEF SYMMETRY %s (rotated orientations excluded by policy: macro PG stripes are unidirectional)" % g["symmetry"]},
        {"name": "placement_site", "value": {site: [sw, sh]}, "provenance": "technology/std-cell LEF SITE (name from the platform choice in tools/families.py)"},
        {"name": "logic_area_um2", "value": o["logic_area"], "provenance": "OPTION --logic-area-um2 (default 0: wrapper logic area is NOT included; take it from synthesis)"},
        {"name": "core_voltage_v", "value": core_v, "provenance": "OPTION --core-voltage (default: nominal Liberty corner %s)" % man["timing"]["nominal_corner"]},
        {"name": "array_supply_tie", "value": "single net %s" % o["power_net"], "provenance": "; ".join(supply_notes) or "single power pin"},
    ]
    out = {
        "schema": "silicaflux-srammacrobridge/floorplan/1",
        "plan": plan.get("name"), "macro": sel["macro_name"], "family": sel["family"], "tiling": sel["tiling"],
        "units": "um", "dbu": 1000, "die": die, "core": core, "site": site, "site_size_um": [sw, sh], "macro_size_um": [W, H],
        "logic_reserve_um": logic_rel and [r3(core[0] + logic_rel[0]), r3(core[1] + logic_rel[1]), r3(core[0] + logic_rel[2]), r3(core[1] + logic_rel[3])],
        "placements": placements, "halos": halos, "halo_um": o["halo"],
        "pg": {"nets": nets, "power_net": o["power_net"], "ground_net": o["ground_net"], "pdn_connect_up_to_layer": pdn_up,
               "supply_notes": supply_notes},
        "routing": layers, "signal_pin_edges_local": sorted(pin_edges),
        "corners": corners, "nominal_corner": man["timing"]["nominal_corner"], "core_voltage_v": core_v,
        "assumptions": assumptions, "warnings": warnings,
        "readiness": {"physical_views": man["readiness"]["status"], "signoff": man["readiness"]["signoff"],
                      "openroad_executed": False,
                      "note": "floorplan Tcl was NOT executed by OpenROAD (not available in the generating environment); "
                              "validated only by tools/run_mock_odb.py (mock OpenDB under tclsh) and tools/check_floorplan.py"},
        "instances_source": {"yosys": inst.get("yosys"), "flow": inst.get("flow")},
    }
    return out, sel, man


# -------------------------------------------------------------------------------------------------------------- Tcl
HDR = """# =============================================================================
# GENERATED by tools/gen_floorplan.py (SilicaFlux SRAMMacroBridge, Project 79) -- DO NOT EDIT BY HAND.
# Plan: {plan}   Macro: {macro}  ({nr} x {nc} instances)
# NOT EXECUTED BY OPENROAD in the generating environment (OpenROAD unavailable there).  Validated only against a mock
# OpenDB (tools/run_mock_odb.py).  Run it in your OpenROAD build and read the log; see docs/04_physical.md.
# =============================================================================
"""


def tcl_floorplan(fp):
    d, c = fp["die"], fp["core"]
    return HDR.format(plan=fp["plan"], macro=fp["macro"], nr=fp["tiling"]["rows"], nc=fp["tiling"]["columns"]) + """
# Die/core in microns.  Site: %(site)s (%(sw)s x %(sh)s um, from the technology/std-cell LEF).
# `initialize_floorplan` creates the die, core and placement rows; it is the standard OpenROAD command.
initialize_floorplan -die_area {%(d)s} -core_area {%(c)s} -site %(site)s
""" % {"site": fp["site"], "sw": fp["site_size_um"][0], "sh": fp["site_size_um"][1], "d": " ".join(str(v) for v in d),
       "c": " ".join(str(v) for v in c)}


def tcl_macro_place(fp):
    s = HDR.format(plan=fp["plan"], macro=fp["macro"], nr=fp["tiling"]["rows"], nc=fp["tiling"]["columns"])
    s += """
# Manual macro placement through the OpenDB Tcl API (same method as FloorplanLab's macro_placement_lib.tcl; `place_macro`
# is not used).  setLocation() puts the lower-left corner of the orientation-adjusted bounding box at (x, y) microns.
# Unknown instances, masters that do not match, and macros left unplaced are HARD errors (nothing is silently skipped).
proc sf_place_macros {placements} {
  set block [ord::get_db_block]
  if {$block eq "NULL" || $block eq ""} { error "no design loaded: read_lef/read_liberty/read_verilog/link_design first" }
  set dbu [$block getDefUnits]
  array set byname {}
  foreach inst [$block getInsts] {
    if {[[$inst getMaster] getType] == "BLOCK"} { set byname([string map {\\\\ {}} [$inst getName]]) $inst }
  }
  set done {}
  foreach p $placements {
    lassign $p name master x y orient
    set key [string map {\\\\ {}} $name]
    if {![info exists byname($key)]} { error "SF-MACRO: macro instance '$name' not found in the netlist" }
    set inst $byname($key)
    set m [[$inst getMaster] getName]
    if {$m ne $master} { error "SF-MACRO: $name is $m, the floorplan expects $master" }
    $inst setOrient $orient
    $inst setLocation [expr {round($x * $dbu)}] [expr {round($y * $dbu)}]
    $inst setPlacementStatus FIRM
    lappend done [$inst getName]
    puts "SF-MACRO: $name ($master) at ($x, $y) $orient FIRM"
  }
  set missing 0
  foreach inst [$block getInsts] {
    if {[[$inst getMaster] getType] == "BLOCK" && [lsearch -exact $done [$inst getName]] < 0} {
      puts "SF-MACRO: ERROR macro [$inst getName] has no placement"
      incr missing
    }
  }
  if {$missing > 0} { error "SF-MACRO: $missing macros not placed" }
}

# Halo = placement blockage around each macro (no standard cell may be placed there).  The halo size is an ASSUMPTION
# (see floorplan.json 'assumptions'): no vendor rule was found in the macro files.
proc sf_create_halos {halos} {
  set block [ord::get_db_block]
  set dbu [$block getDefUnits]
  foreach h $halos {
    lassign $h x1 y1 x2 y2
    odb::dbBlockage_create $block [expr {round($x1 * $dbu)}] [expr {round($y1 * $dbu)}] [expr {round($x2 * $dbu)}] [expr {round($y2 * $dbu)}]
  }
}

# {instance-name master x_um y_um orientation}
set SF_PLACEMENTS {
"""
    for p in fp["placements"]:
        s += tcl_list_item(p["name"], p["master"], p["x"], p["y"], p["orient"])
    s += "}\n\n# {x1 y1 x2 y2} in microns, one per macro, clipped to the core\nset SF_HALOS {\n"
    for h in fp["halos"]:
        s += tcl_list_item(*h["bbox"])
    s += "}\n\nsf_place_macros $SF_PLACEMENTS\nsf_create_halos $SF_HALOS\n"
    return s


def tcl_pdn(fp, man):
    pg = fp["pg"]
    s = HDR.format(plan=fp["plan"], macro=fp["macro"], nr=fp["tiling"]["rows"], nc=fp["tiling"]["columns"])
    s += "\n# Macro power/ground pins connect to the core nets BY THE REAL LEF PIN NAMES (verbatim from the vendor LEF).\n"
    for pn, v in sorted(pg["nets"].items()):
        flag = "-power" if v["use"] == "POWER" else "-ground"
        s += "add_global_connection -net {%s} -pin_pattern {^%s$} %s   ;# LEF pin %s: layers %s, %d shapes\n" % (
            v["net"], re.escape(pn).replace("\\!", "!"), flag, pn, ",".join(v["layers"]), v["shape_count"])
    s += "global_connect\n"
    up = pg["pdn_connect_up_to_layer"]
    s += "\n# Macro power grid.  UNVERIFIED (option names not checked against a real OpenROAD build): the macro PG pins are on %s;\n" % (
        ",".join(fp["routing"]["macro_pg_layers"]))
    s += "# the next routing layer above is %s.  Define the core PDN with your platform's pdn script first, then:\n" % up
    if up:
        s += "#   define_pdn_grid -macro -default -name sf_macro_grid -starts_with POWER\n"
        s += "#   add_pdn_connect -grid sf_macro_grid -layers {%s %s}\n" % (fp["routing"]["macro_pg_layers"][-1], up)
    s += "#   pdngen\n"
    return s


def tcl_load(fp, man):
    views = man["views"]
    s = HDR.format(plan=fp["plan"], macro=fp["macro"], nr=fp["tiling"]["rows"], nc=fp["tiling"]["columns"])
    s += """
# Environment (set by you; the vendor files are fetched by tools/fetch_vendor.py into $SF_VENDOR_DIR/<source>/<path>):
#   SF_VENDOR_DIR   the fetch destination (build/vendor)
#   SF_SC_LEF       standard-cell LEF of the platform (e.g. ORFS platform sg13g2_stdcell.lef)
#   SF_SC_LIB       standard-cell Liberty at the STA corner
#   SF_NETLIST      synthesized netlist of the design with the macro instances (ORFS Yosys flow)
#   SF_TOP          top module name
"""
    s += "read_lef $::env(SF_VENDOR_DIR)/%s            ;# technology LEF (layers)\n" % views["tech_lef"][0]["path"]
    s += "read_lef $::env(SF_SC_LEF)\n"
    # vendor sources are stored as <source>/<repo path>; the source key is the family's source name
    srckey = {"IHP_1P": "ihp_sg13g2", "GF180_1RW": "gf180mcu", "SKY130_1RW1R": "sky130_openram"}[man["family"]]
    s += "read_lef $::env(SF_VENDOR_DIR)/%s/%s            ;# macro LEF (real geometry)\n" % (srckey, views["lef"]["path"])
    s += "read_liberty $::env(SF_SC_LIB)\n"
    nom = man["timing"]["nominal_corner"]
    s += "read_liberty $::env(SF_VENDOR_DIR)/%s/%s     ;# macro Liberty, nominal corner %s (use the corner that matches your STA corner)\n" % (
        srckey, views["liberty"][nom]["path"], nom)
    s += "read_verilog $::env(SF_NETLIST)\nlink_design $::env(SF_TOP)\n"
    return s


def tcl_check(fp):
    W, H = fp["macro_size_um"]
    s = HDR.format(plan=fp["plan"], macro=fp["macro"], nr=fp["tiling"]["rows"], nc=fp["tiling"]["columns"])
    s += """
# Post-placement checks on the OpenDB database: every macro FIRM, master dimensions equal to the LEF size, inside the core,
# no two macros overlap, orientation legal.  Raises an error on the first failure class (prints all violations).
proc sf_check_macros {core expected_w expected_h legal} {
  set block [ord::get_db_block]
  set dbu [$block getDefUnits]
  lassign $core cx1 cy1 cx2 cy2
  set cx1 [expr {round($cx1 * $dbu)}]; set cy1 [expr {round($cy1 * $dbu)}]
  set cx2 [expr {round($cx2 * $dbu)}]; set cy2 [expr {round($cy2 * $dbu)}]
  set ew [expr {round($expected_w * $dbu)}]; set eh [expr {round($expected_h * $dbu)}]
  set boxes {}
  set bad 0
  foreach inst [$block getInsts] {
    if {[[$inst getMaster] getType] != "BLOCK"} continue
    set n [$inst getName]
    set bb [$inst getBBox]
    set x1 [$bb xMin]; set y1 [$bb yMin]; set x2 [$bb xMax]; set y2 [$bb yMax]
    if {[$inst getPlacementStatus] ne "FIRM"} { puts "SF-CHECK: $n not FIRM"; incr bad }
    if {abs(($x2 - $x1) - $ew) > 1 || abs(($y2 - $y1) - $eh) > 1} { puts "SF-CHECK: $n size [expr {$x2-$x1}]x[expr {$y2-$y1}] differs from LEF ${ew}x${eh} (dbu)"; incr bad }
    if {$x1 < $cx1 || $y1 < $cy1 || $x2 > $cx2 || $y2 > $cy2} { puts "SF-CHECK: $n outside the core"; incr bad }
    if {[lsearch -exact $legal [$inst getOrient]] < 0} { puts "SF-CHECK: $n orientation [$inst getOrient] not legal"; incr bad }
    lappend boxes [list $n $x1 $y1 $x2 $y2]
  }
  set nb [llength $boxes]
  for {set i 0} {$i < $nb} {incr i} {
    for {set j [expr {$i + 1}]} {$j < $nb} {incr j} {
      lassign [lindex $boxes $i] na ax1 ay1 ax2 ay2
      lassign [lindex $boxes $j] nb_ bx1 by1 bx2 by2
      if {$ax1 < $bx2 && $bx1 < $ax2 && $ay1 < $by2 && $by1 < $ay2} { puts "SF-CHECK: $na overlaps $nb_"; incr bad }
    }
  }
  puts "SF-CHECK: $nb macros checked, $bad violation(s)"
  if {$bad > 0} { error "SF-CHECK: $bad violation(s)" }
}
"""
    s += "sf_check_macros {%s} %s %s {%s}\n" % (" ".join(str(v) for v in fp["core"]), W, H, " ".join(sorted({p["orient"] for p in fp["placements"]} | {"R0", "MX", "MY", "R180"})))
    return s


def readme(fp):
    a = "\n".join("- **%s** = `%s` -- %s" % (x["name"], x["value"], x["provenance"]) for x in fp["assumptions"])
    return """# Floorplan inputs: %(plan)s

Macro `%(macro)s`, %(nr)d x %(nc)d instances.  Die %(die)s um, core %(core)s um, site %(site)s.

Generated by `tools/gen_floorplan.py` from the synthesized instance names, the vendor LEF/Liberty (via the manifest) and
the technology LEF.  **OpenROAD was not run** on these files in the generating environment.

Order in OpenROAD: `load_design.tcl` -> `floorplan.tcl` -> `macro_place.tcl` -> `check_macros.tcl` -> `pdn_connect.tcl`.

## Assumptions and options
%(a)s

## Warnings
%(w)s
""" % {"plan": fp["plan"], "macro": fp["macro"], "nr": fp["tiling"]["rows"], "nc": fp["tiling"]["columns"], "die": fp["die"], "core": fp["core"],
       "site": fp["site"], "a": a, "w": "\n".join("- " + w for w in fp["warnings"]) or "none"}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--plan", required=True)
    ap.add_argument("--instances", required=True)
    ap.add_argument("--manifests", default=os.path.join(HERE, "..", "manifests"))
    ap.add_argument("--out", required=True)
    ap.add_argument("--halo", type=float, default=10.0)
    ap.add_argument("--channel", type=float, default=20.0)
    ap.add_argument("--pin-channel", type=float, default=40.0)
    ap.add_argument("--die-margin", type=float, default=40.0)
    ap.add_argument("--pin-facing", choices=["pairs", "uniform"], default="pairs")
    ap.add_argument("--logic-area-um2", type=float, default=0.0)
    ap.add_argument("--power-net", default="VDD")
    ap.add_argument("--ground-net", default="VSS")
    ap.add_argument("--core-voltage", type=float)
    a = ap.parse_args(argv)
    plan = json.load(open(a.plan))
    inst = json.load(open(a.instances))
    man = json.load(open(os.path.join(a.manifests, plan["selected"]["macro_name"] + ".json")))
    o = {"halo": a.halo, "channel": a.channel, "pin_channel": a.pin_channel, "die_margin": a.die_margin, "pin_facing": a.pin_facing,
         "logic_area": a.logic_area_um2, "power_net": a.power_net, "ground_net": a.ground_net, "core_voltage": a.core_voltage}
    try:
        fp, sel, man = build(plan, inst, man, o)
    except Incomplete as e:
        print("PHYSICAL_INCOMPLETE: %s" % e, file=sys.stderr)
        return 2
    os.makedirs(a.out, exist_ok=True)
    w = lambda n, t: open(os.path.join(a.out, n), "w").write(t)
    w("floorplan.json", json.dumps(fp, indent=1))
    w("floorplan.tcl", tcl_floorplan(fp))
    w("macro_place.tcl", tcl_macro_place(fp))
    w("pdn_connect.tcl", tcl_pdn(fp, man))
    w("load_design.tcl", tcl_load(fp, man))
    w("check_macros.tcl", tcl_check(fp))
    w("macros.tsv", "".join("%s\t%s\t%d\t%d\n" % (p["name"], p["master"], round(fp["macro_size_um"][0] * fp["dbu"]), round(fp["macro_size_um"][1] * fp["dbu"]))
                            for p in fp["placements"]))
    w("README.md", readme(fp))
    print("%s: die %s core %s, %d macros, orientations %s, halo %s um" % (fp["plan"], fp["die"], fp["core"], len(fp["placements"]),
                                                                           sorted({p["orient"] for p in fp["placements"]}), fp["halo_um"]))
    for x in fp["warnings"]:
        print("WARNING:", x)
    return 0


if __name__ == "__main__":
    sys.exit(main())
