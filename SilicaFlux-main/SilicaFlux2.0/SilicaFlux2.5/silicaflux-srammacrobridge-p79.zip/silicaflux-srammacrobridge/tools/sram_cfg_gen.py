#!/usr/bin/env python3
"""SilicaFlux SRAMMacroBridge memory configuration generator.

Selects compatible macro instances for a required LOGICAL memory and reports everything the physical flow needs.  All
macro facts come from manifests/*.json, which were built from the vendor Verilog/LEF/Liberty files (tools/build_manifest.py).

  plan   python3 -I tools/sram_cfg_gen.py plan  --width 128 --words 4096 --lane-bits 32 --ecc lane [--tech all|ihp|gf180|sky130]
                                                [--read-latency 2] [--test] [--objective area|count|waste|bits]
                                                [--logic-delay-ns 0.0] [--json out.json]
  check  python3 -I tools/sram_cfg_gen.py check --tech ihp --macro-id 4 --width 64 --words 1000 --byte-enable 0 ...
         -> prints the rule code the RTL (rtl/sf_sram_macro_wrapper.sv ERR_CODE) would report; 0 = legal.
  emit   python3 -I tools/sram_cfg_gen.py emit  --name sfv_l1 <plan options> --out configs/generated
         -> <name>.plan.json (full plan, input of gen_floorplan.py) + <name>.params.svh (wrapper parameters)

What is computed per candidate macro (uniform tiling: NR rows x NC columns of ONE macro type, exactly what
sf_sram_be_asic builds):
  macro count, logical capacity, physical stored bits (data + ECC), ECC overhead, unused capacity (macro bits that store
  nothing), macro area and halo-expanded footprint, interface adaptation (polarity, mask conversion, tie-offs, test path,
  extra pipeline), and a MACRO-ONLY timing lower bound from the Liberty corners (not STA: no wires, no clock skew, no
  decode/mux logic delay unless --logic-delay-ns is given).

If no catalogued macro can implement the request, the report says so, lists the rule that rejects each candidate and
what would be needed (commercial compiler output, narrower lanes, etc.).  Nothing is silently substituted.
"""
import argparse
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import ecc_ref  # noqa: E402

# --- constants mirrored from rtl/sf_sram_macro_defs.svh -------------------------------------------------------------
TECH = {"generic": 0, "fpga": 1, "ihp": 10, "gf180": 11, "sky130": 12, "commercial": 19}
TECH_NAME = {v: k for k, v in TECH.items()}
ECC = {"none": 0, "word": 1, "lane": 2}
INIT_NONE, INIT_ZERO, INIT_FILE, INIT_PATTERN = 0, 1, 2, 3

MESSAGES = {
    1: "DATA_WIDTH must be in 1..1024",
    2: "DEPTH_WORDS must be in 2..2**30",
    3: "READ_LATENCY must be in 1..16 (asynchronous read is not supported)",
    4: "BYTE_ENABLE must be 0 or 1",
    5: "BYTE_ENABLE=1 needs BYTE_WIDTH >= 1 and DATA_WIDTH a multiple of BYTE_WIDTH",
    6: "MEMORY_TECH=ASIC_COMMERCIAL: no qualified commercial macro files (Verilog/Liberty/LEF) exist in this package",
    7: "MEMORY_TECH is not GENERIC, FPGA or a catalogued ASIC family",
    8: "ECC_MODE must be NONE, SECDED_WORD or SECDED_LANE",
    9: "SECDED_WORD with BYTE_ENABLE=1 needs a read-modify-write that the always-accept interface cannot stall for",
    10: "SECDED_LANE needs BYTE_ENABLE=1 (the lane is the ECC granule)",
    11: "the ECC granule (lane or word) must be at most 502 data bits",
    12: "TEST_MODE must be 0 or 1",
    13: "POWER_CTRL must be 0 or 1",
    14: "WAKE_CYCLES must be in 1..8",
    15: "INIT_MODE must be NONE, ZERO, FILE or PATTERN",
    16: "INIT_MODE=FILE requires INIT_FILE",
    17: "INIT_MODE=PATTERN is simulation-only",
    18: "FPGA_RAM_STYLE must be AUTO, BLOCK, ULTRA or DISTRIBUTED",
    19: "MACRO_ID applies only to ASIC technologies (must be 0 for GENERIC/FPGA)",
    20: "ASIC macros power up with undefined content: only INIT_MODE=NONE is legal",
    21: "MACRO_ID is not a catalogue entry",
    22: "MACRO_ID belongs to a different technology family than MEMORY_TECH",
    23: "the macro has no write mask and an external read-modify-write cannot be stalled for: BYTE_ENABLE=1 rejected",
    24: "the stored lane width (data + ECC bits) is not a multiple of the macro's write-mask granularity",
    25: "macros with built-in ECC are not supported by this adapter",
    26: "the macro has no sleep/retention pins: POWER_CTRL=1 rejected",
    27: "READ_LATENCY is below the macro's native read latency",
    28: "more than 1024 macro instances",
}


def _load(path):
    with open(path) as fh:
        return json.load(fh)


def load_catalog(manifests):
    cat = _load(os.path.join(manifests, "catalog.json"))
    return {m["id"]: m for m in cat["macros"]}


def load_manifest(manifests, name):
    return _load(os.path.join(manifests, name + ".json"))


def geometry(c):
    """Derived logical/physical word geometry (mirror of the wrapper's localparams)."""
    dw, be, bw, ecc = c["DATA_WIDTH"], c.get("BYTE_ENABLE", 1), c.get("BYTE_WIDTH", 8), c.get("ECC_MODE", 0)
    ok = be != 0 and bw > 0 and dw >= bw
    lanes = dw // bw if ok else 1
    lane_w = bw if ok else (dw if dw > 0 else 1)
    r = ecc_ref.nchk(lane_w) if ecc in (1, 2) and lane_w <= 502 else 0
    plw = lane_w + r
    return {"LANES": lanes, "LANE_W": lane_w, "ECC_R": r, "PLW": plw, "PW": lanes * plw}


def err_code(c, catalog):
    """First violated rule (1..28) or 0.  MUST stay identical to ERR_CODE in rtl/sf_sram_macro_wrapper.sv."""
    g = geometry(c)
    dw, depth, lat = c["DATA_WIDTH"], c["DEPTH_WORDS"], c.get("READ_LATENCY", 1)
    be, bw = c.get("BYTE_ENABLE", 1), c.get("BYTE_WIDTH", 8)
    tech, mid, ecc = c.get("MEMORY_TECH", 0), c.get("MACRO_ID", 0), c.get("ECC_MODE", 0)
    test, pwr, wake = c.get("TEST_MODE", 0), c.get("POWER_CTRL", 0), c.get("WAKE_CYCLES", 2)
    init, init_file, style = c.get("INIT_MODE", 0), c.get("INIT_FILE", ""), c.get("FPGA_RAM_STYLE", 0)
    synth = c.get("IN_SYNTH", False)
    is_asic = tech in (10, 11, 12)
    is_fpga, is_gen = tech == 1, tech == 0
    m = catalog.get(mid) if is_asic else None
    m_words = m["words"] if m else 0
    m_bits = m["bits"] if m else 0
    m_gran = m["mask_granularity_bits"] if m else 1
    t_nr = -(-depth // m_words) if m_words > 0 else 1
    t_nc = -(-g["PW"] // m_bits) if m_bits > 0 else 1
    bw_safe = bw if bw > 0 else 1
    rules = [
        (1, dw < 1 or dw > 1024),
        (2, depth < 2 or depth > (1 << 30)),
        (3, lat < 1 or lat > 16),
        (4, be not in (0, 1)),
        (5, be == 1 and (bw < 1 or dw < bw or dw % bw_safe != 0)),
        (6, tech == 19),
        (7, not (is_gen or is_fpga or is_asic)),
        (8, ecc < 0 or ecc > 2),
        (9, ecc == 1 and be == 1),
        (10, ecc == 2 and be == 0),
        (11, ecc != 0 and g["LANE_W"] > 502),
        (12, test not in (0, 1)),
        (13, pwr not in (0, 1)),
        (14, pwr == 1 and (wake < 1 or wake > 8)),
        (15, init < 0 or init > 3),
        (16, init == INIT_FILE and init_file == ""),
        (17, init == INIT_PATTERN and synth),
        (18, style < 0 or style > 3),
        (19, (not is_asic) and mid != 0),
        (20, is_asic and init != INIT_NONE),
        (21, is_asic and m_words == 0),
        (22, is_asic and m is not None and m["family_code"] != tech),
        (23, is_asic and m is not None and be == 1 and not m.get("has_wmask", True)),
        (24, is_asic and m is not None and m_gran > 1 and g["LANES"] > 1 and g["PLW"] % m_gran != 0),
        (25, is_asic and m is not None and m.get("builtin_ecc", False)),
        (26, is_asic and m is not None and pwr == 1 and not m.get("sleep_retention", False)),
        (27, is_asic and m is not None and lat < m["read_latency_cycles"]),
        (28, is_asic and t_nr * t_nc > 1024),
    ]
    for code, cond in rules:
        if cond:
            return code
    return 0


# ---------------------------------------------------------------------------------------------------------- planning
def candidate(c, mid, catalog, manifests, halo_um, channel_um, logic_delay_ns):
    m = catalog[mid]
    cc = dict(c, MEMORY_TECH=m["family_code"], MACRO_ID=mid)
    code = err_code(cc, catalog)
    if code:
        return {"macro_id": mid, "macro_name": m["macro_name"], "feasible": False, "reject_code": code, "reject_reason": MESSAGES[code]}
    g = geometry(cc)
    nr = -(-cc["DEPTH_WORDS"] // m["words"])
    nc = -(-g["PW"] // m["bits"])
    count = nr * nc
    man = load_manifest(manifests, m["macro_name"])
    w, h = m["width_um"], m["height_um"]
    area = w * h
    logical_bits = cc["DATA_WIDTH"] * cc["DEPTH_WORDS"]
    stored_bits = g["PW"] * cc["DEPTH_WORDS"]
    ecc_bits = (g["PW"] - cc["DATA_WIDTH"]) * cc["DEPTH_WORDS"]
    macro_bits = count * m["words"] * m["bits"]
    pad_cols_bits = nc * m["bits"] - g["PW"]
    pad_rows_words = nr * m["words"] - cc["DEPTH_WORDS"]
    # interface adaptation (what the leaf/backend do for this macro)
    ia = []
    ip = man["interface"]["pins"]
    for role in ("ce", "we", "mask"):
        pol = ip[role].get("pol", "H")
        if pol == "L":
            ia.append("%s: logical active-high -> %s active-low (inverted in the leaf)" % (role, ip[role]["name"]))
    gran = m["mask_granularity_bits"]
    if cc.get("BYTE_ENABLE", 1):
        ia.append("lane enable (%d lane%s of %d stored bits) -> %s mask: %s" % (
            g["LANES"], "s" if g["LANES"] > 1 else "", g["PLW"], ip["mask"]["name"],
            "per-bit mask" if gran == 1 else "per-byte mask (lane width is a multiple of %d)" % gran))
    else:
        ia.append("whole-word writes: every mask bit enabled")
    if man["organization"]["ports"] != "1RW":
        ia.append("second port (%s) unused: chip-enable held inactive, clock tied to clk, address tied to 0" % man["organization"]["ports"])
    if "tie_high" in ip:
        ia.append("%s tied to 1 (vendor-mandated)" % ", ".join(t["name"] for t in ip["tie_high"]))
    if man["test"]["builtin_test_pins"]:
        ia.append("MBIST: the macro's built-in test mux (%s) is used; hand-over rule: %s" % (man["test"]["pins"]["en"], man["test"]["handover_rule"]))
    else:
        ia.append("MBIST: the macro has no test pins -> fabric functional/test mux in the leaf (TEST_MODE=%d)" % cc.get("TEST_MODE", 0))
    if pad_cols_bits:
        ia.append("%d padding column bit(s) in the last macro column (written 0, mask 0)" % pad_cols_bits)
    if nr > 1:
        ia.append("%d rows: %d high address bit(s) select the row; registered row select + %d:1 read mux" % (nr, math.ceil(math.log2(nr)), nr))
    if pad_rows_words:
        ia.append("%d unreachable word(s) in the last row (idx must stay < DEPTH_WORDS)" % pad_rows_words)
    extra = cc.get("READ_LATENCY", 1) - m["read_latency_cycles"]
    if extra:
        ia.append("%d extra register stage(s) after the (ECC) decode to reach READ_LATENCY=%d" % (extra, cc["READ_LATENCY"]))
    if cc.get("ECC_MODE", 0):
        ia.append("external SECDED %s: %d check bit(s)/%s over %d data bits (%d total check bits per word), stored in %d extra bit column(s)" % (
            "per lane" if cc["ECC_MODE"] == 2 else "per word", g["ECC_R"], "lane" if cc["ECC_MODE"] == 2 else "word", g["LANE_W"],
            g["PW"] - cc["DATA_WIDTH"], g["PW"] - cc["DATA_WIDTH"]))
    # timing lower bound (macro only), per Liberty corner
    corners = []
    for cn in man["timing"]["corners"]:
        c2o = cn["clk_to_out_ns"]
        edge = c2o["edge"]
        ssu = cn["worst_setup_ns"] or 0.0
        c2o_max = c2o["max"]
        # read path: macro output -> (mux/decode) -> capturing flop.  A rising-edge macro launches at the clock edge;
        # a falling-edge macro (SKY130 OpenRAM) launches half a cycle later, so the half-period must cover the access.
        path = c2o_max + logic_delay_ns
        t_read = path if edge == "rising_edge" else 2.0 * path
        t_min = max([t for t in (t_read, cn["min_period_ns"]) if t is not None])
        corners.append({"corner": cn["id"], "voltage_v": cn["voltage_v"], "temperature_c": cn["temperature_c"], "process": cn["process"],
                        "clk_to_out_max_ns": c2o_max, "launch_edge": edge, "worst_input_setup_ns": ssu, "worst_input_hold_ns": cn["worst_hold_ns"],
                        "min_period_liberty_ns": cn["min_period_ns"], "min_pulse_width_ns": cn["min_pulse_width_ns"],
                        "read_path_period_lower_bound_ns": round(t_read, 4), "period_lower_bound_ns": round(t_min, 4)})
    return {
        "macro_id": mid, "macro_name": m["macro_name"], "family": m["family"], "feasible": True,
        "tiling": {"rows": nr, "columns": nc, "instances": count, "macro_words": m["words"], "macro_bits": m["bits"]},
        "capacity": {"logical_bits": logical_bits, "logical_bytes": logical_bits / 8.0, "physical_stored_bits": stored_bits,
                     "ecc_overhead_bits": ecc_bits, "ecc_overhead_pct_of_data": round(100.0 * ecc_bits / logical_bits, 3),
                     "macro_bits_total": macro_bits, "unused_bits": macro_bits - stored_bits,
                     "unused_pct": round(100.0 * (macro_bits - stored_bits) / macro_bits, 3),
                     "utilisation_pct": round(100.0 * stored_bits / macro_bits, 3)},
        "footprint": {"macro_size_um": [w, h], "macro_area_um2": round(area, 3), "total_macro_area_um2": round(count * area, 3),
                      "total_macro_area_mm2": round(count * area / 1e6, 6),
                      "halo_um": halo_um, "area_with_halo_um2": round(count * (w + 2 * halo_um) * (h + 2 * halo_um), 3),
                      "grid_bbox_um": [round(nc * w + (nc - 1) * channel_um, 3), round(nr * h + (nr - 1) * channel_um, 3)],
                      "grid_bbox_um2": round((nc * w + (nc - 1) * channel_um) * (nr * h + (nr - 1) * channel_um), 3),
                      "channel_um": channel_um},
        "interface_adaptation": ia,
        "timing_macro_only": {"note": "Lower bound from the Liberty corners only: no wires, skew, setup of the capturing flop, or "
                                      "decode/mux delay (unless --logic-delay-ns). NOT static timing analysis.",
                              "logic_delay_ns_assumed": logic_delay_ns, "corners": corners},
        "readiness": m["readiness"], "physical_views": {"lef_sha256": m["lef_sha256"], "verilog_sha256": m["verilog_sha256"]},
        "wrapper_params": {"MEMORY_TECH": m["family_code"], "MACRO_ID": mid},
    }


def build_plan(c, catalog, manifests, tech="all", objective="area", halo_um=10.0, channel_um=20.0, logic_delay_ns=0.0):
    fam = {"all": (10, 11, 12), "ihp": (10,), "gf180": (11,), "sky130": (12,)}[tech]
    cand = [candidate(c, mid, catalog, manifests, halo_um, channel_um, logic_delay_ns)
            for mid in sorted(catalog) if catalog[mid]["family_code"] in fam]
    feas = [x for x in cand if x["feasible"]]
    key = {
        "area": lambda x: (x["footprint"]["total_macro_area_um2"], x["tiling"]["instances"], x["macro_id"]),
        "count": lambda x: (x["tiling"]["instances"], x["footprint"]["total_macro_area_um2"], x["macro_id"]),
        "waste": lambda x: (x["capacity"]["unused_bits"], x["footprint"]["total_macro_area_um2"], x["macro_id"]),
        "bits": lambda x: (x["capacity"]["macro_bits_total"], x["footprint"]["total_macro_area_um2"], x["macro_id"]),
    }[objective]
    feas.sort(key=key)
    g = geometry(dict(c, MEMORY_TECH=10))
    rejected = {}
    for x in cand:
        if not x["feasible"]:
            rejected.setdefault((x["reject_code"], x["reject_reason"]), []).append(x["macro_name"])
    plan = {
        "schema": "silicaflux-srammacrobridge/plan/1",
        "request": c, "objective": objective, "technologies": tech,
        "logical": {"data_width": c["DATA_WIDTH"], "depth_words": c["DEPTH_WORDS"], "lanes": g["LANES"], "lane_data_bits": g["LANE_W"],
                    "ecc_check_bits_per_lane": g["ECC_R"], "stored_lane_bits": g["PLW"], "physical_word_bits": g["PW"],
                    "capacity_bits": c["DATA_WIDTH"] * c["DEPTH_WORDS"]},
        "status": "OK" if feas else "CANNOT_IMPLEMENT_WITH_CATALOGUED_MACROS",
        "selected": feas[0] if feas else None,
        "alternatives": feas[1:6],
        "rejected": [{"code": k[0], "reason": k[1], "macros": v} for k, v in sorted(rejected.items())],
        "other_backends": {
            "generic": "behavioural array (%d bits stored): fine for simulation/formal; on an ASIC flow it becomes flip-flops" % (g["PW"] * c["DEPTH_WORDS"]),
            "fpga": "inferred RAM, %d stored bits: Yosys-checked block-RAM inference; Vivado/Quartus not checked" % (g["PW"] * c["DEPTH_WORDS"]),
        },
        "notes": [],
    }
    if not feas:
        plan["notes"].append("No catalogued open-PDK macro can implement this request. Options: relax the request (see rejection reasons), "
                             "use the GENERIC/FPGA backends, or obtain a licensed memory-compiler output (Verilog model + Liberty + LEF) and "
                             "add it to the catalogue (docs/05_commercial_macros.md).")
    else:
        plan["notes"].append("Uniform tiling of ONE macro type (what sf_sram_be_asic builds). Mixed-macro tilings (e.g. a 1024-word and a "
                             "256-word macro to cover 1280 words) would waste less but are not implemented in the RTL.")
        plan["notes"].append("Physical readiness is PHYSICAL_VIEWS_COMPLETE_SIGNOFF_PENDING at best: DRC/LVS/STA/IR were not run; "
                             "silicon qualification is not established (see reports/physical_readiness.md).")
        if tech == "all":
            plan["notes"].append("Technologies differ in process node, supply voltage and speed (see timing); 'all' ranks them together "
                                 "only by the chosen objective: pick the technology for the product, then plan within it.")
    return plan


def params_svh(name, plan):
    s = plan["selected"]
    req = plan["request"]
    lines = ["// Generated by tools/sram_cfg_gen.py -- %s\n" % name,
             "// Instantiate:  sf_sram_macro_wrapper #(.DATA_WIDTH(%d), .DEPTH_WORDS(%d), ... ) u_%s (...);\n" % (req["DATA_WIDTH"], req["DEPTH_WORDS"], name)]
    p = {"DATA_WIDTH": req["DATA_WIDTH"], "DEPTH_WORDS": req["DEPTH_WORDS"], "READ_LATENCY": req.get("READ_LATENCY", 1),
         "BYTE_ENABLE": req.get("BYTE_ENABLE", 1), "BYTE_WIDTH": req.get("BYTE_WIDTH", 8), "ECC_MODE": req.get("ECC_MODE", 0),
         "TEST_MODE": req.get("TEST_MODE", 0), "POWER_CTRL": req.get("POWER_CTRL", 0)}
    if s:
        p.update(s["wrapper_params"])
    for k, v in p.items():
        lines.append("localparam int %s_%s = %d;\n" % (name.upper(), k, v))
    return "".join(lines)


def top_sv(name, plan):
    """Synthesis/floorplan top: the wrapper with the plan's parameters, ports passed straight through."""
    req = plan["request"]
    s = plan["selected"]
    g = geometry(dict(req, MEMORY_TECH=s["wrapper_params"]["MEMORY_TECH"]))
    idxw = max(1, (req["DEPTH_WORDS"] - 1).bit_length())
    dw = g["LANES"] * g["LANE_W"]
    be = req.get("BYTE_ENABLE", 1)
    lanes = g["LANES"]
    pw = g["PW"]
    return """// Generated by tools/sram_cfg_gen.py: synthesis / floorplan top for '%(n)s' (%(mn)s, %(nr)dx%(nc)d instances).
`include "sf_sram_macro_defs.svh"
module %(n)s_top (
  input  wire              clk, ce, we,
  input  wire [%(lm)d:0]       wmask,
  input  wire [%(im)d:0]       idx,
  input  wire [%(dm)d:0]       wdata,
  output wire [%(dm)d:0]       rdata,
  output wire              rd_vld, ecc_corrected, ecc_uncorrectable,
  input  wire              tst_active, tst_ce, tst_we,
  input  wire [%(im)d:0]       tst_idx,
  input  wire [%(pm)d:0]       tst_wdata,
  output wire [%(pm)d:0]       tst_rdata,
  output wire              tst_rd_vld,
  input  wire              pwr_sleep,
  output wire              pwr_active
);
  sf_sram_macro_wrapper #(
    .DATA_WIDTH(%(dw)d), .DEPTH_WORDS(%(dp)d), .READ_LATENCY(%(rl)d), .BYTE_ENABLE(%(be)d), .BYTE_WIDTH(%(bw)d),
    .MEMORY_TECH(%(mt)d), .MACRO_ID(%(mid)d), .ECC_MODE(%(ecc)d), .TEST_MODE(%(tm)d), .POWER_CTRL(0)
  ) u_sram (
    .clk(clk), .ce(ce), .we(we), .wmask(wmask), .idx(idx), .wdata(wdata), .rdata(rdata), .rd_vld(rd_vld),
    .ecc_corrected(ecc_corrected), .ecc_uncorrectable(ecc_uncorrectable),
    .tst_active(tst_active), .tst_ce(tst_ce), .tst_we(tst_we), .tst_idx(tst_idx), .tst_wdata(tst_wdata),
    .tst_rdata(tst_rdata), .tst_rd_vld(tst_rd_vld), .pwr_sleep(pwr_sleep), .pwr_active(pwr_active));
endmodule
""" % {"n": name, "mn": s["macro_name"], "nr": s["tiling"]["rows"], "nc": s["tiling"]["columns"], "lm": lanes - 1, "im": idxw - 1,
       "dm": dw - 1, "pm": pw - 1, "dw": req["DATA_WIDTH"], "dp": req["DEPTH_WORDS"], "rl": req.get("READ_LATENCY", 1), "be": be,
       "bw": req.get("BYTE_WIDTH", 8), "mt": s["wrapper_params"]["MEMORY_TECH"], "mid": s["wrapper_params"]["MACRO_ID"],
       "ecc": req.get("ECC_MODE", 0), "tm": req.get("TEST_MODE", 0)}


def add_common(ap):
    ap.add_argument("--width", type=int, required=True, help="logical data width in bits")
    ap.add_argument("--words", type=int, required=True, help="logical depth in words")
    ap.add_argument("--lane-bits", type=int, default=8, help="write-lane (byte) width; ignored with --no-byte-enable")
    ap.add_argument("--no-byte-enable", action="store_true")
    ap.add_argument("--ecc", choices=sorted(ECC), default="none")
    ap.add_argument("--read-latency", type=int, default=1)
    ap.add_argument("--test", action="store_true", help="TEST_MODE=1 (MBIST port)")
    ap.add_argument("--power", action="store_true", help="POWER_CTRL=1 (sleep model; rejected for every catalogued macro)")
    ap.add_argument("--manifests", default=os.path.join(HERE, "..", "manifests"))


def cfg_from(a):
    return {"DATA_WIDTH": a.width, "DEPTH_WORDS": a.words, "READ_LATENCY": a.read_latency, "BYTE_ENABLE": 0 if a.no_byte_enable else 1,
            "BYTE_WIDTH": a.lane_bits, "ECC_MODE": ECC[a.ecc], "TEST_MODE": 1 if a.test else 0, "POWER_CTRL": 1 if a.power else 0}


def print_plan(plan):
    L = plan["logical"]
    print("Logical memory: %d x %d bit = %d bits (%.1f KiB), %d lane(s) x %d data bits; ECC check bits/lane %d -> physical word %d bits" % (
        L["depth_words"], L["data_width"], L["capacity_bits"], L["capacity_bits"] / 8192.0, L["lanes"], L["lane_data_bits"],
        L["ecc_check_bits_per_lane"], L["physical_word_bits"]))
    print("Status:", plan["status"])
    s = plan["selected"]
    if s:
        def row(x):
            t, cap, f = x["tiling"], x["capacity"], x["footprint"]
            return "%-40s %3dx%-3d=%-4d  area %9.4f mm2  util %6.2f%%  unused %9d b  period>= %s ns" % (
                x["macro_name"], t["rows"], t["columns"], t["instances"], f["total_macro_area_mm2"], cap["utilisation_pct"], cap["unused_bits"],
                "/".join("%.2f" % c["period_lower_bound_ns"] for c in x["timing_macro_only"]["corners"] if c["corner"] == "typ_1p20V_25C" or "tt_025C_3v30" in c["corner"] or c["corner"] == "TT_1p8V_25C"))
        print("\nSELECTED  " + row(s))
        for x in plan["alternatives"]:
            print("ALT       " + row(x))
        print("\nInterface adaptation (selected):")
        for t in s["interface_adaptation"]:
            print("  -", t)
    for r in plan["rejected"]:
        print("\nREJECTED [E%02d] %s\n   %s" % (r["code"], r["reason"], ", ".join(r["macros"])))
    for n in plan["notes"]:
        print("\nNOTE:", n)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("plan")
    add_common(p1)
    p1.add_argument("--tech", choices=["all", "ihp", "gf180", "sky130"], default="all")
    p1.add_argument("--objective", choices=["area", "count", "waste", "bits"], default="area")
    p1.add_argument("--halo-um", type=float, default=10.0)
    p1.add_argument("--channel-um", type=float, default=20.0)
    p1.add_argument("--logic-delay-ns", type=float, default=0.0)
    p1.add_argument("--json")
    p2 = sub.add_parser("check")
    add_common(p2)
    p2.add_argument("--tech", choices=sorted(TECH), default="generic")
    p2.add_argument("--macro-id", type=int, default=0)
    p2.add_argument("--byte-enable", type=int)
    p2.add_argument("--byte-width", type=int)
    p3 = sub.add_parser("emit")
    add_common(p3)
    p3.add_argument("--name", required=True)
    p3.add_argument("--tech", choices=["ihp", "gf180", "sky130"], required=True)
    p3.add_argument("--objective", choices=["area", "count", "waste", "bits"], default="area")
    p3.add_argument("--macro-id", type=int, help="force this catalogue macro instead of the ranked best")
    p3.add_argument("--halo-um", type=float, default=10.0)
    p3.add_argument("--channel-um", type=float, default=20.0)
    p3.add_argument("--logic-delay-ns", type=float, default=0.0)
    p3.add_argument("--out", default="configs/generated")
    a = ap.parse_args(argv)
    catalog = load_catalog(a.manifests)
    c = cfg_from(a)
    if a.cmd == "check":
        c.update(MEMORY_TECH=TECH[a.tech], MACRO_ID=a.macro_id)
        if a.byte_enable is not None:
            c["BYTE_ENABLE"] = a.byte_enable
        if a.byte_width is not None:
            c["BYTE_WIDTH"] = a.byte_width
        code = err_code(c, catalog)
        print(code if code == 0 else "%d  %s" % (code, MESSAGES[code]))
        return 0 if code == 0 else 2
    if a.cmd == "plan":
        plan = build_plan(c, catalog, a.manifests, a.tech, a.objective, a.halo_um, a.channel_um, a.logic_delay_ns)
        print_plan(plan)
        if a.json:
            json.dump(plan, open(a.json, "w"), indent=1)
        return 0 if plan["status"] == "OK" else 3
    if a.cmd == "emit":
        plan = build_plan(c, catalog, a.manifests, a.tech, a.objective, a.halo_um, a.channel_um, a.logic_delay_ns)
        if a.macro_id:
            forced = [x for x in [plan["selected"]] + plan["alternatives"] if x and x["macro_id"] == a.macro_id]
            if not forced:
                print("macro %d is not feasible for this request" % a.macro_id, file=sys.stderr)
                return 3
            plan["selected"] = forced[0]
        print_plan(plan)
        if plan["status"] != "OK":
            return 3
        os.makedirs(a.out, exist_ok=True)
        plan["name"] = a.name
        json.dump(plan, open(os.path.join(a.out, a.name + ".plan.json"), "w"), indent=1)
        open(os.path.join(a.out, a.name + ".params.svh"), "w").write(params_svh(a.name, plan))
        open(os.path.join(a.out, a.name + ".top.sv"), "w").write(top_sv(a.name, plan))
        print("\nwrote %s/%s.plan.json, .params.svh and .top.sv" % (a.out, a.name))
        return 0


if __name__ == "__main__":
    sys.exit(main())
