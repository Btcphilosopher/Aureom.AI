#!/usr/bin/env python3
"""Build the SRAMMacroBridge macro manifests from the REAL vendor files (Verilog model, LEF, Liberty corners,
datasheet / spec CSV, technology LEF).

  python3 -I tools/fetch_vendor.py --dest build/vendor
  python3 -I tools/build_manifest.py --vendor build/vendor --out manifests

Every number in a manifest is read from a vendor file (path + SHA-256 are recorded in `views`).  The hand-written
family semantics (tools/families.py) are verified against those files; any disagreement is an ISSUE and makes the build
fail (exit 1) instead of producing a manifest that looks complete.  Nothing is estimated: a quantity that a vendor file
does not contain is null.
"""
import argparse
import csv
import hashlib
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import families  # noqa: E402
import lef_parse  # noqa: E402
import lib_parse  # noqa: E402
import vlog_ports  # noqa: E402

SCHEMA = "silicaflux-srammacrobridge/macro-manifest/1"


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def width_of(w, bits, aw, gran):
    return {"1": 1, "AW": aw, "BITS": bits, "MASKBITS": bits if gran == 1 else bits // gran}[w]


# --------------------------------------------------------------------------------------------- checks
def check_pins(fam, name, bits, aw, vlog, lef_sum, libs, issues):
    gran = fam["mask_granularity_bits"]
    expected = {}  # pin -> (dir, width)
    all_roles = dict(fam["pins"])
    tie = all_roles.pop("tie_high", [])
    for role, spec in list(all_roles.items()) + [("test_" + r, s) for r, s in fam["test_pins"].items()]:
        w = width_of(spec["w"], bits, aw, gran)
        is_out = role in ("dout", "p1_dout")
        expected[spec["name"]] = ("output" if is_out else "input", w)
    for spec in tie:
        expected[spec["name"]] = ("input", width_of(spec["w"], bits, aw, gran))
    vports = {n: p for n, p in vlog["ports"].items()}
    pg_names = set(fam["supply"]["lib"])
    for n, (d, w) in expected.items():
        if n not in vports:
            issues.append("%s: role pin %s missing in Verilog model" % (name, n))
            continue
        if vports[n]["width"] != w or vports[n]["dir"] != d:
            issues.append("%s: Verilog pin %s is %s[%d], expected %s[%d]" % (name, n, vports[n]["dir"], vports[n]["width"], d, w))
    extra = [n for n in vports if n not in expected and n not in pg_names]
    if extra:
        issues.append("%s: Verilog ports not covered by the family table (possible new test/sleep/ECC/repair pin): %s" % (name, extra))
    # LEF vs expected
    sp = lef_sum["signal_pins"]
    for n, (d, w) in expected.items():
        if n not in sp:
            issues.append("%s: pin %s missing in LEF" % (name, n))
        elif sp[n]["width"] != w or sp[n]["dir"] != d.upper():
            issues.append("%s: LEF pin %s is %s[%d], expected %s[%d]" % (name, n, sp[n]["dir"], sp[n]["width"], d.upper(), w))
    lextra = [n for n in sp if n not in expected]
    if lextra:
        issues.append("%s: LEF signal pins not covered by the family table: %s" % (name, lextra))
    lef_pg = {k.rstrip("!") for k in lef_sum["pg_pins"]}
    if lef_pg != pg_names:
        issues.append("%s: LEF PG pins %s differ from family supply %s" % (name, sorted(lef_pg), sorted(pg_names)))
    # Liberty vs expected
    for cid, ls in libs.items():
        lp = ls["pins"]
        for n, (d, w) in expected.items():
            if n not in lp:
                issues.append("%s[%s]: pin %s missing in Liberty" % (name, cid, n))
            elif lp[n]["direction"] != d:
                issues.append("%s[%s]: Liberty pin %s direction %s, expected %s" % (name, cid, n, lp[n]["direction"], d))
        lx = [n for n in lp if n not in expected]
        if lx:
            issues.append("%s[%s]: Liberty pins not covered by the family table: %s" % (name, cid, lx))
        if {k for k in ls["cell"]["pg_pins"]} != pg_names:
            issues.append("%s[%s]: Liberty pg_pins %s differ from family supply" % (name, cid, sorted(ls["cell"]["pg_pins"])))


def polarity_check(fam, bits, aw, libs):
    """Cross-check the declared control polarity against the Liberty clock-pin internal_power `when` conditions."""
    gran = fam["mask_granularity_bits"]
    p = fam["pins"]

    def lvl(role, logical):
        return logical if p[role].get("pol", "H") == "H" else 1 - logical

    def env_for(state, writing):
        e = {}
        for role in ("ce", "we", "re"):
            if role in p and role in state:
                e[p[role]["name"]] = lvl(role, state[role])
        mb = width_of("MASKBITS", bits, aw, gran)
        act = lvl("mask", 1)
        for b in range(mb):
            e["%s[%d]" % (p["mask"]["name"], b)] = act if writing else 1 - act
        return e

    envs = {"idle": env_for(fam["idle_cycle"], False), "read": env_for(fam["read_cycle"], False),
            "write": env_for(fam["write_cycle"], True)}
    out = {}
    for cid, ls in libs.items():
        clk = p["clk"]["name"]
        pw = {k: [] for k in envs}
        for ip in ls["power"]["internal_power"]:
            if ip["pin"] != clk or not ip["when"]:
                continue
            val = (ip["rise"]["max"] if ip["rise"] else 0.0) + (ip["fall"]["max"] if ip["fall"] else 0.0)
            for st, env in envs.items():
                try:
                    if lib_parse.eval_when(ip["when"], env):
                        pw[st].append(val)
                except KeyError:
                    pass
        m = {k: (max(v) if v else None) for k, v in pw.items()}
        if None in m.values():
            status = "INDETERMINATE"
        elif m["idle"] > min(m["read"], m["write"]) + 1e-12:
            status = "FAIL"
        elif m["idle"] == m["read"] == m["write"]:
            status = "NON_INFORMATIVE"
        else:
            status = "PASS"
        out[cid] = {"status": status, "power_by_state": m}
    return out


def datasheet_checks(fam_key, name, d_files, lef_sum, libs, vendor, src, issues, warnings):
    notes = []
    base = os.path.join(vendor, src["source"])
    w, h = lef_sum["size_um"]
    if fam_key == "IHP_1P" and d_files.get("datasheet"):
        t = open(os.path.join(base, d_files["datasheet"]), encoding="latin-1").read()
        m = re.search(r"Area \(h x w\)\s*:\s*([\d.]+) x ([\d.]+)", t)
        if m:
            dh, dw = float(m.group(1)), float(m.group(2))
            ok = abs(dh - h) < 0.006 and abs(dw - w) < 0.006
            notes.append({"check": "datasheet size == LEF size", "result": "PASS" if ok else "FAIL", "datasheet": [dw, dh], "lef": [w, h]})
            if not ok:
                issues.append("%s: datasheet size %s differs from LEF %s" % (name, [dw, dh], [w, h]))
        rows = re.findall(r"\|\s*Clock to Data Out\s*\|\s*Delay\s*\|\s*(Rising|Falling)\s*\|\s*([\d.e+-]+)\s*\|\s*([\d.e+-]+)\s*\|\s*([\d.e+-]+)\s*\|", t)
        cmap = {"wc": "slow", "bc": "fast", "tc": "typ"}
        for edge, wc, bc, tc in rows:
            for key, val in (("wc", wc), ("bc", bc), ("tc", tc)):
                cids = [c for c in libs if cmap[key] in c]
                if not cids:
                    continue
                c2o = libs[cids[0]]["clk_to_out_ns"].get(fam_key and "A_DOUT")
                v = float(val)
                ok = c2o and c2o["min"] * 0.995 <= v <= c2o["max"] * 1.005
                notes.append({"check": "datasheet clock-to-out %s %s within Liberty table range" % (edge, key),
                              "result": "PASS" if ok else "FAIL", "datasheet_ns": v,
                              "liberty_ns": [c2o["min"], c2o["max"]] if c2o else None})
                if not ok:
                    warnings.append("%s: datasheet clock-to-out %s/%s=%s ns outside Liberty range %s (Liberty is used for timing)" % (name, edge, key, v, c2o))
    if fam_key == "GF180_1RW":
        spec = d_files["spec"]
        dim = [p for p in spec if p.endswith("6_Physical_Dimensions.csv")][0]
        rows = list(csv.reader(io.StringIO(open(os.path.join(base, dim)).read())))
        dw, dh = float(rows[1][0]), float(rows[1][1])
        ok = abs(dw - w) < 0.006 and abs(dh - h) < 0.006
        notes.append({"check": "spec 6_Physical_Dimensions == LEF size", "result": "PASS" if ok else "FAIL", "spec": [dw, dh], "lef": [w, h]})
        if not ok:
            issues.append("%s: spec dimensions %s differ from LEF %s" % (name, [dw, dh], [w, h]))
        pd = [p for p in spec if p.endswith("1_pins_desc.csv")][0]
        rows_pd = list(csv.reader(io.StringIO(open(os.path.join(base, pd)).read())))
        for r in rows_pd[1:]:
            m_ = re.match(r"^A\[(\d+):0\]$", r[0].strip()) if r else None
            if m_:
                spec_w = int(m_.group(1)) + 1
                vw = next(iter(libs.values()))["cell"]["memory"]["address_width"]
                ok = spec_w == vw
                notes.append({"check": "spec 1_pins_desc address width == Liberty/Verilog/LEF address width", "result": "PASS" if ok else "DISCREPANCY",
                              "spec_bits": spec_w, "model_bits": vw})
                if not ok:
                    warnings.append("%s: vendor spec 1_pins_desc.csv lists A[%d:0] (%d bits) but the Verilog model, LEF and Liberty have %d address bits "
                                    "(the model/LEF/Liberty are used)" % (name, spec_w - 1, spec_w, vw))
        ac = [p for p in spec if p.endswith("5_AC_Characteristics2.csv")][0]
        rows = list(csv.reader(io.StringIO(open(os.path.join(base, ac)).read())))
        sym = {r[0].strip(): r for r in rows[1:] if r}
        tt = [c for c in libs if "tt_025C_3v30" in c]
        if tt:
            lib = libs[tt[0]]
            tcyc = float(sym["Tcyc"][4])
            lm = lib["min_period_ns"]
            ok = lm is not None and abs(tcyc - lm) <= 1e-3 * tcyc
            notes.append({"check": "spec Tcyc (typical 3.3 V 25 C) == Liberty min_period (tt_025C_3v30)", "result": "PASS" if ok else "FAIL",
                          "spec_ns": tcyc, "liberty_ns": lm})
            if not ok:
                warnings.append("%s: spec Tcyc %s ns != Liberty min_period %s ns (Liberty is used for timing)" % (name, tcyc, lm))
            tah = float(sym["Tah"][4])
            c2o = lib["clk_to_out_ns"]["Q"]
            ok = abs(tah - c2o["min"]) <= 2e-3 * tah
            notes.append({"check": "spec Tah (clock high to Q high, typical) == Liberty clk->Q minimum", "result": "PASS" if ok else "FAIL",
                          "spec_ns": tah, "liberty_min_ns": c2o["min"]})
            if not ok:
                warnings.append("%s: vendor spec Tah (typical) %s ns != Liberty clk->Q minimum %s ns (maximum %s ns): the vendor's own "
                                "spec CSV and Liberty disagree; Liberty is used for timing" % (name, tah, c2o["min"], c2o["max"]))
    if fam_key == "SKY130_1RW1R":
        a = next(iter(libs.values()))["cell"]["area_um2"]
        ok = abs(a - w * h) <= 0.01 * a / 100 * 100 * 1e-2 or abs(a - w * h) / a < 1e-4
        notes.append({"check": "Liberty cell area == LEF size product", "result": "PASS" if ok else "FAIL", "liberty_um2": a, "lef_um2": round(w * h, 3)})
        if not ok:
            issues.append("%s: Liberty area %s != LEF %s" % (name, a, w * h))
    return notes


def corner_id(macro, path):
    stem = os.path.basename(path)[:-4]
    return re.sub(r"^%s_*" % re.escape(macro), "", stem) or stem


def timing_summary(fam, ls, bits, aw):
    p = fam["pins"]
    func = [p[r]["name"] for r in ("ce", "we", "re", "addr", "din", "mask") if r in p]
    tst = [s["name"] for r, s in fam["test_pins"].items() if r != "clk"]
    dout = p["dout"]["name"]
    c2o = ls["clk_to_out_ns"].get(dout)
    out = {
        "clock_pin": p["clk"]["name"],
        "clk_to_out_ns": c2o,
        "setup_ns": {k: ls["setup_ns"][k] for k in func + tst if k in ls["setup_ns"]},
        "hold_ns": {k: ls["hold_ns"][k] for k in func + tst if k in ls["hold_ns"]},
        "min_pulse_width_ns": ls["min_pulse_width_ns"],
        "min_period_ns": ls["min_period_ns"],
    }
    fs = [ls["setup_ns"][k]["max"] for k in func if k in ls["setup_ns"]]
    fh = [ls["hold_ns"][k]["max"] for k in func if k in ls["hold_ns"]]
    out["worst_setup_ns"] = max(fs) if fs else None
    out["worst_hold_ns"] = max(fh) if fh else None
    return out


def sites_hint(src, fam_key, vendor):
    out = {}
    for r in src["tech_lef"][fam_key]:
        p = os.path.join(vendor, r)
        if os.path.isfile(p):
            out.update(lef_parse.parse_tech_lef(open(p).read())["sites"])
    return out


def build_macro(name, ms, src, vendor, tech_cache, ids):
    issues = []
    fam_key = ms["family"]
    fam = families.FAMILIES[fam_key]
    sdef = src["sources"][ms["source"]]
    base = os.path.join(vendor, ms["source"])
    files = ms["files"]

    def path(rel):
        return os.path.join(base, rel)

    # --- Verilog
    vtxt = open(path(files["verilog"])).read()
    vlog = vlog_ports.parse_ports(vtxt, defines=())
    if vlog["module"] != name:
        issues.append("%s: Verilog module is named %s" % (name, vlog["module"]))
    # --- LEF
    lef = lef_parse.parse_macro_lef(open(path(files["lef"])).read())
    if list(lef["macros"]) != [name]:
        issues.append("%s: LEF defines %s" % (name, list(lef["macros"])))
    lm = lef["macros"][name]
    lef_sum = lef_parse.summarize_macro(lm)
    if lef["dbu"] <= 0 or lef_sum["class"] != "BLOCK":
        issues.append("%s: LEF class %s" % (name, lef_sum["class"]))
    # --- Liberty corners
    libs = {}
    lib_files = {}
    for lf in sorted(files["liberty"]):
        cid = corner_id(name, lf)
        ls = lib_parse.summarize_corner(lib_parse.parse_liberty(open(path(lf)).read()))
        if ls["cell"]["name"] != name:
            issues.append("%s[%s]: Liberty cell is %s" % (name, cid, ls["cell"]["name"]))
        libs[cid] = ls
        lib_files[cid] = lf
    if fam["core_site"] not in sites_hint(src, fam_key, vendor):
        issues.append("%s: default core site %s not found in the tech/std-cell LEF" % (name, fam["core_site"]))
    if fam["nominal_corner"] not in libs:
        issues.append("%s: nominal corner %s not among %s" % (name, fam["nominal_corner"], sorted(libs)))
    mem = next(iter(libs.values()))["cell"]["memory"]
    if not mem:
        issues.append("%s: Liberty has no memory() group" % name)
        mem = {"address_width": 0, "word_width": 0}
    aw, bits = mem["address_width"], mem["word_width"]
    for cid, ls in libs.items():
        if ls["cell"]["memory"] != mem:
            issues.append("%s[%s]: memory() differs between corners" % (name, cid))
        a = ls["cell"]["area_um2"]
        if abs(a - lef_sum["area_um2"]) / a > 1e-4:
            issues.append("%s[%s]: Liberty area %s != LEF area %s" % (name, cid, a, lef_sum["area_um2"]))
    words = 1 << aw
    gran = fam["mask_granularity_bits"]
    if bits % gran:
        issues.append("%s: data width %d not a multiple of mask granularity %d" % (name, bits, gran))
    check_pins(fam, name, bits, aw, vlog, lef_sum, libs, issues)
    pol = polarity_check(fam, bits, aw, libs)
    for cid, r in pol.items():
        if r["status"] == "FAIL":
            issues.append("%s[%s]: declared polarity contradicts Liberty clock-pin power conditions %s" % (name, cid, r["power_by_state"]))
    warnings = []
    dsn = datasheet_checks(fam_key, name, files, lef_sum, libs, vendor, ms, issues, warnings)
    # --- recorded values from the earlier SRAM Wrapper Library (independent cross-check)
    rec = ms.get("sramlib_recorded")
    xr = None
    if rec:
        xr = {"words": rec["words"] == words, "data_width": rec["data_width"] == bits,
              "width_um": rec["width_um"] is not None and abs(rec["width_um"] - lef_sum["size_um"][0]) < 0.006,
              "height_um": rec["height_um"] is not None and abs(rec["height_um"] - lef_sum["size_um"][1]) < 0.006,
              "read_latency": rec["read_latency_cycles"] == fam["read_latency_cycles"],
              "mask_granularity": rec["mask_granularity_bits"] == gran}
        for k, v in xr.items():
            if not v:
                issues.append("%s: differs from the sramlib record in %s" % (name, k))
    # --- tech LEF: legal routing layers over the macro
    tech_rels = src["tech_lef"][fam_key]
    tech_rel = tech_rels[0]
    tech_path = os.path.join(vendor, tech_rel)
    tech = None
    sites = {}
    if all(os.path.isfile(os.path.join(vendor, r)) for r in tech_rels):
        if fam_key not in tech_cache:
            parsed = [lef_parse.parse_tech_lef(open(os.path.join(vendor, r)).read()) for r in tech_rels]
            allsites = {}
            for pz in parsed:
                allsites.update(pz["sites"])
            tech_cache[fam_key] = (lef_parse.tech_summary(parsed[0]), allsites)
        tech, sites = tech_cache[fam_key]
    used = set(lef_sum["obs_layers"]) | {l for p in lef_sum["signal_pins"].values() for l in p["layers"]} | \
        {l for p in lef_sum["pg_pins"].values() for l in p["layers"]}
    routing = [l["name"] for l in tech] if tech else []
    idx = {n: i for i, n in enumerate(routing)}
    top_used = max((idx[l] for l in used if l in idx), default=-1)
    free_above = routing[top_used + 1:] if tech else None
    blocked = [l for l in routing if l in lef_sum["obs_layers"]]
    geometry = {
        "size_um": lef_sum["size_um"], "area_um2": lef_sum["area_um2"], "class": lef_sum["class"], "origin_um": lef_sum["origin_um"],
        "symmetry": lef_sum["symmetry"],
        "legal_orientations": lef_parse.legal_orientations(lef_sum["symmetry"]),
        "legal_orientations_incl_rotated": lef_parse.legal_orientations(lef_sum["symmetry"], allow_rotated=True),
        "pg_pins": lef_sum["pg_pins"], "signal_pins": lef_sum["signal_pins"], "obs_layers": lef_sum["obs_layers"],
        "tech_lef": tech_rels if tech else None,
        "tech_sites_um": sites,
        "default_core_site": fam["core_site"],
        "tech_routing_layers": tech,
        "routing_layers_blocked_over_macro": blocked,
        "routing_layers_free_above_macro": free_above,
        "pins_edges": sorted({e for p in lef_sum["signal_pins"].values() for e in p["edges"]}),
    }
    # --- views / provenance
    views = {"verilog": {}, "lef": {}, "liberty": {}, "datasheet": {}, "spec": {}}
    def view(rel):
        upstream = "https://raw.githubusercontent.com/%s/%s/%s" % (sdef["repo"], sdef["commit"], rel)
        return {"path": rel, "sha256": sha256_file(path(rel)), "bytes": os.path.getsize(path(rel)), "upstream": upstream}
    views["verilog"] = view(files["verilog"])
    views["lef"] = view(files["lef"])
    views["liberty"] = {cid: view(f) for cid, f in lib_files.items()}
    if files.get("datasheet"):
        views["datasheet"] = view(files["datasheet"])
    if files.get("spec"):
        views["spec"] = {os.path.basename(p): view(p) for p in files["spec"]}
    views["tech_lef"] = [{"path": r, "sha256": sha256_file(os.path.join(vendor, r)), "source": "OpenROAD-flow-scripts platform file (data only)"}
                         for r in tech_rels] if tech else None
    views["gds"] = "listed upstream, NOT fetched or verified by this package (no DRC/LVS performed)"
    corners = []
    for cid, ls in libs.items():
        c = {"id": cid, "library": ls["library"], "process": ls["corner"]["process"], "temperature_c": ls["corner"]["temperature_c"],
             "voltage_v": ls["corner"]["voltage_v"], "leakage_nw": ls["cell"]["leakage_nw"], "units": ls["units"],
             "power_states": ls["power_states"], "polarity_check": pol[cid]["status"], "voltage_map": ls["voltage_map"]}
        c.update(timing_summary(fam, ls, bits, aw))
        corners.append(c)
    has_bist = bool(fam["test_pins"])
    mgr = {
        "schema": SCHEMA,
        "id": ids[name],
        "macro_name": name,
        "family": fam_key,
        "family_code": families.FAMILY_CODE[fam_key],
        "memory_tech": fam["memory_tech"],
        "status": "OPEN_SOURCE_AVAILABLE",
        "foundry": fam["foundry"], "process": fam["process"], "pdk": fam["pdk"],
        "license": "Apache-2.0 (vendor files are not redistributed in this package)",
        "organization": {"words": words, "bits": bits, "address_width": aw, "ports": fam["topology"],
                         "dont_use_in_liberty": next(iter(libs.values()))["cell"]["dont_use"]},
        "interface": {"pins": fam["pins"], "test_pins": fam["test_pins"], "read_cycle": fam["read_cycle"],
                      "write_cycle": fam["write_cycle"], "idle_cycle": fam["idle_cycle"],
                      "verilog_ports": {n: [p["dir"], p["width"]] for n, p in vlog["ports"].items()}},
        "semantics": {
            "read_latency_cycles": fam["read_latency_cycles"], "access_edge": fam["access_edge"],
            "output_hold": fam["output_hold"], "write_through": fam["write_through"], "same_cycle_rw": fam["same_cycle_rw"],
            "write_mask": {"supported": True, "granularity_bits": gran, "mask_bits": width_of("MASKBITS", bits, aw, gran),
                           "polarity": "active_high" if fam["pins"]["mask"].get("pol", "H") == "H" else "active_low",
                           "pin": fam["pins"]["mask"]["name"]},
            "chip_enable": {"pin": fam["pins"]["ce"]["name"], "polarity": "active_high" if fam["pins"]["ce"].get("pol", "H") == "H" else "active_low"},
            "write_enable": {"pin": fam["pins"]["we"]["name"], "polarity": "active_high" if fam["pins"]["we"].get("pol", "H") == "H" else "active_low"},
            "uninitialised_array": fam["uninitialised_array"], "constraints": fam["constraints"],
        },
        "test": {"builtin_test_pins": has_bist, "mux": fam["test_mux"], "handover_rule": fam["test_handover_rule"],
                 "pins": {r: s["name"] for r, s in fam["test_pins"].items()}},
        "ecc": {"builtin": fam["ecc_builtin"], "external_check_bits": "supported by the wrapper: extra stored bits are tiled as ordinary columns"},
        "redundancy": {"present": fam["redundancy"], "repair_interface": fam["repair_interface"],
                       "evidence": "no redundancy/repair pin in Verilog, LEF or Liberty"},
        "power": {"sleep_retention": fam["sleep_retention"], "liberty_power_states": [], "supplies_lib": fam["supply"]["lib"],
                  "supplies_lef": sorted(lef_sum["pg_pins"])},
        "geometry": geometry,
        "timing": {"nominal_corner": fam["nominal_corner"], "corners": corners,
                   "model_delay_note": "Verilog-model delays/specify values are simulation conveniences and are NOT timing data; "
                                       "all timing above is from the Liberty files"},
        "views": views,
        "checks": {"issues": issues, "warnings": warnings, "polarity_vs_liberty": pol, "datasheet": dsn, "sramlib_record_match": xr,
                   "status": "PASS" if not issues else "FAIL"},
    }
    missing = []
    if not tech:
        missing.append("technology LEF")
    if not corners:
        missing.append("Liberty")
    mgr["readiness"] = {
        "logical_integration": "READY" if not issues else "BLOCKED",
        "physical_views": {"verilog": True, "lef": True, "liberty_corners": len(corners), "tech_lef": bool(tech),
                           "gds": "not verified"},
        "missing_for_physical_implementation": missing,
        "signoff": {"drc": "NOT_RUN", "lvs": "NOT_RUN", "sta": "NOT_RUN", "ir_drop": "NOT_RUN"},
        "silicon_qualification": "NOT ESTABLISHED by this package (no foundry qualification data was read)",
        "status": "PHYSICAL_INCOMPLETE" if missing else "PHYSICAL_VIEWS_COMPLETE_SIGNOFF_PENDING",
    }
    return mgr, issues, warnings


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--vendor", default="build/vendor")
    ap.add_argument("--out", default="manifests")
    ap.add_argument("--macros", nargs="*")
    ap.add_argument("--ids", default=os.path.join(HERE, "pins", "catalog_ids.json"))
    a = ap.parse_args(argv)
    src = json.load(open(os.path.join(HERE, "pins", "vendor_sources.json")))
    names = a.macros or sorted(src["macros"])
    ids = json.load(open(a.ids)) if os.path.isfile(a.ids) else {}
    # stable catalogue ids: existing ids never change; new macros are appended in (family, words, bits) order
    def keyof(n):
        m = src["macros"][n]
        r = m.get("sramlib_recorded", {})
        return (families.FAMILY_ORDER.index(m["family"]), r.get("words", 0), r.get("data_width", 0), n)
    nxt = max(ids.values(), default=0) + 1
    for n in sorted(src["macros"], key=keyof):
        if n not in ids:
            ids[n] = nxt
            nxt += 1
    os.makedirs(a.out, exist_ok=True)
    json.dump(ids, open(a.ids, "w"), indent=1, sort_keys=True)
    tech_cache = {}
    all_issues = []
    all_warnings = []
    catalog = []
    for n in names:
        m, issues, warns = build_macro(n, src["macros"][n], src, a.vendor, tech_cache, ids)
        all_warnings += warns
        json.dump(m, open(os.path.join(a.out, n + ".json"), "w"), indent=1)
        all_issues += issues
        g = m["geometry"]
        t0 = next(c for c in m["timing"]["corners"] if c["id"] == m["timing"]["nominal_corner"])
        catalog.append({"id": m["id"], "macro_name": n, "family": m["family"], "family_code": m["family_code"],
                        "words": m["organization"]["words"], "bits": m["organization"]["bits"],
                        "address_width": m["organization"]["address_width"], "ports": m["organization"]["ports"],
                        "mask_granularity_bits": m["semantics"]["write_mask"]["granularity_bits"],
                        "read_latency_cycles": m["semantics"]["read_latency_cycles"], "access_edge": m["semantics"]["access_edge"],
                        "builtin_test_pins": m["test"]["builtin_test_pins"], "builtin_ecc": m["ecc"]["builtin"],
                        "sleep_retention": m["power"]["sleep_retention"]["supported"],
                        "width_um": g["size_um"][0], "height_um": g["size_um"][1], "area_um2": g["area_um2"],
                        "pins_edges": g["pins_edges"], "corners": [c["id"] for c in m["timing"]["corners"]],
                        "clk_to_out_ns_typ_max": (t0["clk_to_out_ns"] or {}).get("max"), "readiness": m["readiness"]["status"],
                        "checks": m["checks"]["status"], "lef_sha256": m["views"]["lef"]["sha256"],
                        "verilog_sha256": m["views"]["verilog"]["sha256"]})
    catalog.sort(key=lambda c: c["id"])
    json.dump({"schema": "silicaflux-srammacrobridge/catalog/1", "count": len(catalog), "macros": catalog},
              open(os.path.join(a.out, "catalog.json"), "w"), indent=1)
    print("macros: %d   issues: %d   vendor-data warnings: %d" % (len(catalog), len(all_issues), len(all_warnings)))
    for w in all_warnings:
        print("WARNING:", w, file=sys.stderr)
    for i in all_issues[:60]:
        print("ISSUE:", i, file=sys.stderr)
    return 1 if all_issues else 0


if __name__ == "__main__":
    sys.exit(main())
