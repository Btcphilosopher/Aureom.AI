#!/usr/bin/env python3
"""Independent golden model of the SilicaFlux SRAMMacroBridge SECDED code (Hsiao, odd-weight columns).

Code definition (also in rtl/ecc/sf_ecc_h.svh): K data bits, R check bits, R = smallest r with 2^(r-1) - r >= K.
Data bit j has H-column = the j-th r-bit vector (ascending numeric order) with odd popcount >= 3; check bit i has the
unit vector 1<<i.  check_i = XOR of the data bits whose column has bit i set.

This file is written independently of the RTL (different formulation: Python big ints, explicit syndrome table) and is
used to (a) prove the code properties exhaustively (--selftest), (b) generate the test vectors read by
tb/tb_ecc_vectors.sv (--vectors DIR), and (c) provide the physical-word layout helpers used by the config generator.

Physical lane layout (matches the wrapper): lane = { check[R-1:0], data[K-1:0] } -> data in the low bits.
"""
import argparse
import itertools
import os
import random
import sys


def nchk(k):
    """Number of SECDED check bits for k data bits (mirror of `SF_ECC_R in rtl/sf_sram_macro_defs.svh)."""
    for r in range(4, 12):
        if (1 << (r - 1)) - r >= k:
            return r
    raise ValueError("k too large")


def columns(k, r=None):
    r = r or nchk(k)
    cols = []
    for v in range(1, 1 << r):
        if len(cols) == k:
            break
        pc = bin(v).count("1")
        if pc >= 3 and pc % 2 == 1:
            cols.append(v)
    if len(cols) != k:
        raise ValueError("not enough odd-weight columns")
    return cols


def encode(data, k):
    r = nchk(k)
    cols = columns(k, r)
    chk = 0
    for j, c in enumerate(cols):
        if (data >> j) & 1:
            chk ^= c
    return chk


def decode(data, chk, k):
    """returns (data_out, corrected, uncorrectable)"""
    r = nchk(k)
    cols = columns(k, r)
    syn = chk ^ encode(data, k)
    if syn == 0:
        return data, 0, 0
    table = {c: j for j, c in enumerate(cols)}
    if syn in table:
        return data ^ (1 << table[syn]), 1, 0
    if bin(syn).count("1") == 1:
        return data, 1, 0
    return data, 0, 1


def lane_word(data, k):
    return (encode(data, k) << k) | data


def selftest():
    for k in (1, 2, 4, 5, 8, 11, 12, 16, 26, 27, 32, 39, 57, 58, 64, 72, 120, 121, 128, 247, 248, 256, 502):
        r = nchk(k)
        cols = columns(k, r)
        assert len(set(cols)) == k, "columns not distinct"
        assert all(bin(c).count("1") % 2 == 1 and bin(c).count("1") >= 3 for c in cols)
        assert (1 << (r - 1)) - r >= k and ((1 << (r - 2)) - (r - 1) < k if r > 4 else True), "R not minimal for k=%d" % k
        n = k + r
        rng = random.Random(k)
        for _ in range(3):
            d = rng.getrandbits(k)
            c = encode(d, k)
            assert decode(d, c, k) == (d, 0, 0)
            word = (c << k) | d
            for i in range(n):  # every single flip corrected
                w = word ^ (1 << i)
                do, cor, unc = decode(w & ((1 << k) - 1), w >> k, k)
                assert (do, cor, unc) == (d, 1, 0), (k, i)
            pairs = itertools.combinations(range(n), 2) if n <= 140 else [tuple(rng.sample(range(n), 2)) for _ in range(4000)]
            for i, j in pairs:  # every double flip detected, never miscorrected
                w = word ^ (1 << i) ^ (1 << j)
                do, cor, unc = decode(w & ((1 << k) - 1), w >> k, k)
                assert (cor, unc) == (0, 1) and do == (w & ((1 << k) - 1)), (k, i, j)
    print("ecc_ref selftest: PASS (every single-bit error corrected and every double-bit error detected: exhaustive over all bit positions when K+R <= 140, 4000 random pairs per word above that)")


def vectors(out, k, nvec=64, seed=1):
    """Vector file: one record per line, hex, bit-exact packed MSB first:
         {kind[3:0], data_in[K], check_in[R], data_out[K], corrected, uncorrectable}
      kind 0 = clean (check_in = golden encoder output), 1 = single flip, 2 = double flip.  data_in/check_in are what
      the decoder receives; data_out/corrected/uncorrectable are the golden decoder results."""
    r = nchk(k)
    rng = random.Random(seed * 1000 + k)
    rows = []
    words = [0, (1 << k) - 1] + [rng.getrandbits(k) for _ in range(nvec)]
    n = k + r
    for d in words:
        c = encode(d, k)
        rows.append((0, d, c, d, 0, 0))
        flips = rng.sample(range(n), min(n, 6))
        for i in flips:
            w = ((c << k) | d) ^ (1 << i)
            di, ci = w & ((1 << k) - 1), w >> k
            do, cor, unc = decode(di, ci, k)
            rows.append((1, di, ci, do, cor, unc))
        for _ in range(4):
            i, j = rng.sample(range(n), 2)
            w = ((c << k) | d) ^ (1 << i) ^ (1 << j)
            di, ci = w & ((1 << k) - 1), w >> k
            do, cor, unc = decode(di, ci, k)
            rows.append((2, di, ci, do, cor, unc))
    path = os.path.join(out, "ecc_vec_k%d.mem" % k)
    total = 4 + k + r + k + 2
    digits = (total + 3) // 4
    with open(path, "w") as f:
        for kind, di, ci, do, cor, unc in rows:
            # bit-exact packing, MSB first: {kind[3:0], data_in[k], check_in[r], data_out[k], corrected, uncorrectable}
            rec = (kind << (k + r + k + 2)) | (di << (r + k + 2)) | (ci << (k + 2)) | (do << 2) | (cor << 1) | unc
            f.write("%0*x\n" % (digits, rec))
    return path, len(rows), r


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--vectors", metavar="DIR")
    ap.add_argument("--k", type=int, nargs="*", default=[8, 13, 16, 32, 39, 64, 128])
    a = ap.parse_args()
    if a.selftest:
        selftest()
    if a.vectors:
        os.makedirs(a.vectors, exist_ok=True)
        for k in a.k:
            p, n, r = vectors(a.vectors, k)
            print("wrote %s (%d records, K=%d R=%d)" % (p, n, k, r))


if __name__ == "__main__":
    main()
