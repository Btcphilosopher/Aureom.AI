#!/usr/bin/env python3
"""Synthesize a generated plan top with Yosys (macros as black boxes) and extract the REAL flattened macro instance names.

  python3 -I tools/synth_instances.py --plan configs/generated/NAME.plan.json --top configs/generated/NAME.top.sv \
          --rtl rtl --out physical/NAME

Writes <out>/instances.json: [{name, master, row, col}] (name = hierarchical name in the flattened netlist, exactly what
OpenROAD/OpenDB sees when the netlist comes from a Yosys `flatten` flow such as OpenROAD-flow-scripts), the Yosys version,
and per-cell-type counts.  The floorplan generator refuses to run without this file: no instance name is ever invented.
Also checks that the number of macro instances equals the plan (rows x columns).
"""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
RTL_FILES = ["ecc/sf_ecc_secded_enc.sv", "ecc/sf_ecc_secded_dec.sv", "backends/sf_sram_be_generic.sv", "backends/sf_sram_be_fpga.sv",
             "backends/asic/sf_sram_leaf_ihp1p.sv", "backends/asic/sf_sram_leaf_gf180.sv", "backends/asic/sf_sram_leaf_sky130.sv",
             "backends/sf_sram_be_asic.sv", "sf_sram_macro_wrapper.sv", "backends/asic/stubs/sf_sram_macro_blackboxes.sv"]


def run_yosys(script, yosys="yosys"):
    r = subprocess.run([yosys, "-q", "-s", script], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--plan", required=True)
    ap.add_argument("--top", required=True)
    ap.add_argument("--rtl", default=os.path.join(HERE, "..", "rtl"))
    ap.add_argument("--out", required=True)
    ap.add_argument("--yosys", default="yosys")
    a = ap.parse_args(argv)
    plan = json.load(open(a.plan))
    sel = plan["selected"]
    name = plan.get("name") or os.path.basename(a.plan).split(".")[0]
    rtl = os.path.abspath(a.rtl)
    os.makedirs(a.out, exist_ok=True)
    jpath = os.path.join(os.path.abspath(a.out), "netlist.json")
    with tempfile.NamedTemporaryFile("w", suffix=".ys", delete=False) as f:
        f.write("read_verilog -sv -defer -I%s -I%s/ecc -I%s/backends %s %s\n" % (
            rtl, rtl, rtl, " ".join(os.path.join(rtl, x) for x in RTL_FILES), os.path.abspath(a.top)))
        f.write("hierarchy -check -top %s_top\nproc\nflatten\nopt_clean\nwrite_json %s\n" % (name, jpath))
        script = f.name
    rc, log = run_yosys(script, a.yosys)
    os.unlink(script)
    if rc != 0:
        print(log, file=sys.stderr)
        return 1
    d = json.load(open(jpath))
    top = d["modules"]["%s_top" % name]
    insts = []
    types = {}
    for n, c in top["cells"].items():
        types[c["type"]] = types.get(c["type"], 0) + 1
        if c["type"] == sel["macro_name"]:
            m = re.search(r"g_row\[(\d+)\]\.g_col\[(\d+)\]", n)
            if not m:
                print("macro instance name without g_row/g_col: %s" % n, file=sys.stderr)
                return 1
            insts.append({"name": n, "master": c["type"], "row": int(m.group(1)), "col": int(m.group(2))})
    insts.sort(key=lambda x: (x["row"], x["col"]))
    exp = sel["tiling"]["instances"]
    foreign = [t for t in types if t not in (sel["macro_name"],) and re.match(r"^(RM_IHPSG13|gf180mcu_fd_ip_sram|sky130_sram)", t)]
    ok = len(insts) == exp and not foreign and {(i["row"], i["col"]) for i in insts} == {
        (r, c) for r in range(sel["tiling"]["rows"]) for c in range(sel["tiling"]["columns"])}
    ver = subprocess.run([a.yosys, "-V"], capture_output=True, text=True).stdout.strip()
    out = {"schema": "silicaflux-srammacrobridge/instances/1", "plan": name, "top": "%s_top" % name, "yosys": ver,
           "flow": "read_verilog -defer; hierarchy; proc; flatten; opt_clean", "expected_instances": exp,
           "found_instances": len(insts), "consistent_with_plan": ok, "foreign_macro_types": foreign,
           "instances": insts, "cell_type_counts_top": dict(sorted(types.items())),
           "rtl_sha256": {x: hashlib.sha256(open(os.path.join(rtl, x), "rb").read()).hexdigest() for x in RTL_FILES}}
    json.dump(out, open(os.path.join(a.out, "instances.json"), "w"), indent=1)
    print("%s: %d macro instances (plan %d) %s" % (name, len(insts), exp, "OK" if ok else "MISMATCH"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
