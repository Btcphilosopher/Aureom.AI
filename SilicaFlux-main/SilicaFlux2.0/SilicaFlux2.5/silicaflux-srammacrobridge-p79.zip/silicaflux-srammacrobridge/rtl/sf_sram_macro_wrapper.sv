// =============================================================================
// SilicaFlux SRAMMacroBridge (Project 79) :: sf_sram_macro_wrapper            -- primary RTL
// Technology-aware SRAM wrapper.  One LOGICAL memory interface (the SRAMCore / SRAM-library raw contract) in front of
// three interchangeable physical backends selected by MEMORY_TECH:
//   GENERIC          behavioural array            (simulation, formal, generic synthesis)
//   FPGA             inferred block/ultra/distributed RAM
//   ASIC_<family>    real open-PDK SRAM hard macros (IHP SG13G2, GF180MCU, SKY130 OpenRAM), tiled, with their real
//                    Verilog models in simulation and LEF/Liberty in the physical flow
// Aureom.AI | SilicaFlux Semiconductor Systems
//
// ---------------------------------------------------------------------------
// Logical interface (drop-in for sf_sram_array: same clk/ce/we/wmask/idx/wdata/rdata names and timing)
//   clk                rising edge; the only clock (all backends, test and power logic)
//   ce, we             ce=0 idle.  ce=1: one access, we=1 write / we=0 read.  Always accepted: there is no ready.
//   wmask[LANES]       byte (lane) enables when BYTE_ENABLE=1; lane l = wdata[l*BYTE_WIDTH +: BYTE_WIDTH].
//                      BYTE_ENABLE=0: whole-word writes, LANES=1, wmask is ignored (tie to 1).
//   idx                WORD index, must be < DEPTH_WORDS (simulation assertion; the macro array has no bounds check).
//   wdata              write data (DATA_WIDTH bits, ECC check bits are added inside)
//   rdata              read data, valid EXACTLY READ_LATENCY cycles after the read edge, for that one cycle; never held.
//   rd_vld             1 in that cycle for an accepted read (qualifies rdata and the ECC flags)
//   ecc_corrected      with rd_vld: a single-bit error (data or check bit) was corrected in rdata
//   ecc_uncorrectable  with rd_vld: a multi-bit error was detected; rdata is the UNCORRECTED stored data
// Test (MBIST) port, enabled by TEST_MODE=1; accesses the RAW stored word (PHYS_WIDTH bits = data + check bits), so a
// March test sees every cell including the ECC check-bit columns and single-bit faults are NOT masked by ECC:
//   tst_active         hand the array to the test bus.  HAND-OVER RULE (all technologies, enforced by the wrapper): after
//                      tst_active changes, NO functional or test access for 2 cycles (the cycle of the change and the
//                      next one); accesses presented then are dropped and flagged by SF_MACRO_ASSERT_HANDOVER.  This is
//                      the IHP datasheet rule for A_BIST_EN, applied uniformly so a test controller is portable.
//   tst_ce, tst_we, tst_idx, tst_wdata   one raw access per cycle (all lanes written); tst_rdata/tst_rd_vld like rdata.
// Power (POWER_CTRL=1; GENERIC/FPGA only -- no catalogue macro has a sleep/retention pin):
//   pwr_sleep -> accesses are blocked, contents retained; pwr_active=0 while asleep and for WAKE_CYCLES cycles after
//   pwr_sleep falls.  A LOGICAL-INTERFACE model, not a physical power state.
//
// ---------------------------------------------------------------------------
// Physical word.  LANES write lanes; PLW = LANE_W + ECC_R stored bits per lane; PHYS_WIDTH = LANES * PLW.
//   ECC_MODE NONE         PLW = lane data bits
//   ECC_MODE SECDED_WORD  one codeword over DATA_WIDTH (BYTE_ENABLE must be 0: a partial write would need a
//                         read-modify-write, which an always-accept interface cannot stall for)
//   ECC_MODE SECDED_LANE  one codeword per lane (BYTE_ENABLE must be 1): byte enables work, the lane's check bits are
//                         written with the lane's enable.
// None of the catalogued macros has built-in ECC, redundancy or a repair interface (manifests/), so ECC is external
// check-bit storage tiled like any other column and no macro feature is duplicated.
//
// Configuration errors: every illegal parameter set fails elaboration with ONE message (first violated rule, ERR_CODE
// below; mirrored by tools/sram_cfg_gen.py --check).  Nothing is silently corrected.
//
// Classification: SYNTHESIZABLE (GENERIC/FPGA); HARD MACRO WRAPPER (ASIC).  Simulation-only code is excluded when
// SYNTHESIS is defined.  SF_MACRO_POISON (4-state simulation): rdata/tst_rdata = X whenever not valid.
// =============================================================================
`include "sf_sram_macro_defs.svh"
`include "sf_sram_macro_ids.svh"
`include "sf_sram_macro_funcs.svh"
`default_nettype none

/* verilator lint_off UNUSEDSIGNAL */   // wmask (BYTE_ENABLE=0), test/power pins when their feature is off
module sf_sram_macro_wrapper #(
  parameter int DATA_WIDTH     = 32,
  parameter int DEPTH_WORDS    = 1024,
  parameter int READ_LATENCY   = 1,
  parameter int BYTE_ENABLE    = 1,
  parameter int BYTE_WIDTH     = 8,
  parameter int MEMORY_TECH    = `SF_MEM_TECH_GENERIC,
  parameter int MACRO_ID       = 0,
  parameter int ECC_MODE       = `SF_ECC_NONE,
  parameter int TEST_MODE      = 0,
  parameter int POWER_CTRL     = 0,
  parameter int WAKE_CYCLES    = 2,
  parameter int INIT_MODE      = `SF_MACRO_INIT_NONE,
  parameter     INIT_FILE      = "",
  parameter int FPGA_RAM_STYLE = `SF_MACRO_FPGA_AUTO,
  // ---- derived geometry (public: ports depend on it)
  localparam int IDX_WIDTH  = (DEPTH_WORDS > 1) ? $clog2(DEPTH_WORDS) : 1,
  localparam int BW_SAFE    = (BYTE_WIDTH > 0) ? BYTE_WIDTH : 1,
  localparam int LANES      = (BYTE_ENABLE != 0 && BYTE_WIDTH > 0 && DATA_WIDTH >= BYTE_WIDTH) ? DATA_WIDTH / BW_SAFE : 1,
  localparam int LANE_W     = (BYTE_ENABLE != 0 && BYTE_WIDTH > 0 && DATA_WIDTH >= BYTE_WIDTH) ? BYTE_WIDTH : ((DATA_WIDTH > 0) ? DATA_WIDTH : 1),
  localparam int ECC_R      = (ECC_MODE == `SF_ECC_SECDED_WORD || ECC_MODE == `SF_ECC_SECDED_LANE) ? `SF_ECC_R(LANE_W) : 0,
  localparam int PLW        = LANE_W + ECC_R,
  localparam int PHYS_WIDTH = LANES * PLW
) (
  input  wire logic                   clk,
  input  wire logic                   ce,
  input  wire logic                   we,
  input  wire logic [LANES-1:0]       wmask,
  input  wire logic [IDX_WIDTH-1:0]   idx,
  input  wire logic [LANES*LANE_W-1:0] wdata,
  output logic      [LANES*LANE_W-1:0] rdata,
  output logic                        rd_vld,
  output logic                        ecc_corrected,
  output logic                        ecc_uncorrectable,
  // test (MBIST) port: raw physical word
  input  wire logic                   tst_active,
  input  wire logic                   tst_ce,
  input  wire logic                   tst_we,
  input  wire logic [IDX_WIDTH-1:0]   tst_idx,
  input  wire logic [PHYS_WIDTH-1:0]  tst_wdata,
  output logic      [PHYS_WIDTH-1:0]  tst_rdata,
  output logic                        tst_rd_vld,
  // power
  input  wire logic                   pwr_sleep,
  output logic                        pwr_active
);

  localparam int DW = LANES * LANE_W;   // == DATA_WIDTH for every legal configuration

  // ------------------------------------------------ configuration legality (first violated rule wins)
  localparam bit IS_ASIC  = (MEMORY_TECH == `SF_MEM_TECH_ASIC_IHP_SG13G2) || (MEMORY_TECH == `SF_MEM_TECH_ASIC_GF180MCU) ||
                            (MEMORY_TECH == `SF_MEM_TECH_ASIC_SKY130_OPENRAM);
  localparam bit IS_FPGA  = (MEMORY_TECH == `SF_MEM_TECH_FPGA);
  localparam bit IS_GEN   = (MEMORY_TECH == `SF_MEM_TECH_GENERIC);
`ifdef SYNTHESIS
  localparam bit IN_SYNTH = 1'b1;
`else
  localparam bit IN_SYNTH = 1'b0;
`endif
  localparam int M_WORDS  = IS_ASIC ? `SF_MACRO_WORDS(MACRO_ID) : 0;
  localparam int M_BITS   = IS_ASIC ? `SF_MACRO_BITS(MACRO_ID)  : 0;
  localparam int M_GRAN   = IS_ASIC ? `SF_MACRO_GRAN(MACRO_ID)  : 1;
  localparam int T_NR     = (M_WORDS > 0) ? (DEPTH_WORDS + M_WORDS - 1) / M_WORDS : 1;
  localparam int T_NC     = (M_BITS  > 0) ? (PHYS_WIDTH + M_BITS - 1) / M_BITS    : 1;

  localparam int ERR_CODE =
      (DATA_WIDTH < 1 || DATA_WIDTH > 1024)                                                         ? 1  :
      (DEPTH_WORDS < 2 || DEPTH_WORDS > (1 << 30))                                                  ? 2  :
      (READ_LATENCY < 1 || READ_LATENCY > 16)                                                       ? 3  :
      (BYTE_ENABLE != 0 && BYTE_ENABLE != 1)                                                        ? 4  :
      (BYTE_ENABLE == 1 && (BYTE_WIDTH < 1 || DATA_WIDTH < BYTE_WIDTH || (DATA_WIDTH % BW_SAFE) != 0)) ? 5  :
      (MEMORY_TECH == `SF_MEM_TECH_ASIC_COMMERCIAL)                                                 ? 6  :
      (!IS_GEN && !IS_FPGA && !IS_ASIC)                                                             ? 7  :
      (ECC_MODE < `SF_ECC_NONE || ECC_MODE > `SF_ECC_SECDED_LANE)                                   ? 8  :
      (ECC_MODE == `SF_ECC_SECDED_WORD && BYTE_ENABLE == 1)                                         ? 9  :
      (ECC_MODE == `SF_ECC_SECDED_LANE && BYTE_ENABLE == 0)                                         ? 10 :
      (ECC_MODE != `SF_ECC_NONE && LANE_W > 502)                                                    ? 11 :
      (TEST_MODE != 0 && TEST_MODE != 1)                                                            ? 12 :
      (POWER_CTRL != 0 && POWER_CTRL != 1)                                                          ? 13 :
      (POWER_CTRL == 1 && (WAKE_CYCLES < 1 || WAKE_CYCLES > 8))                                     ? 14 :
      (INIT_MODE < `SF_MACRO_INIT_NONE || INIT_MODE > `SF_MACRO_INIT_PATTERN)                       ? 15 :
      (INIT_MODE == `SF_MACRO_INIT_FILE && INIT_FILE == "")                                         ? 16 :
      (INIT_MODE == `SF_MACRO_INIT_PATTERN && IN_SYNTH)                                             ? 17 :
      (FPGA_RAM_STYLE < `SF_MACRO_FPGA_AUTO || FPGA_RAM_STYLE > `SF_MACRO_FPGA_DISTRIBUTED)        ? 18 :
      (!IS_ASIC && MACRO_ID != 0)                                                                   ? 19 :
      (IS_ASIC && INIT_MODE != `SF_MACRO_INIT_NONE)                                                 ? 20 :
      (IS_ASIC && M_WORDS == 0)                                                                     ? 21 :
      (IS_ASIC && `SF_MACRO_FAMILY(MACRO_ID) != MEMORY_TECH)                                        ? 22 :
      (IS_ASIC && BYTE_ENABLE == 1 && `SF_MACRO_HAS_WMASK(MACRO_ID) == 0)                           ? 23 :
      (IS_ASIC && M_GRAN > 1 && LANES > 1 && (PLW % M_GRAN) != 0)                                   ? 24 :
      (IS_ASIC && `SF_MACRO_HAS_ECC(MACRO_ID) != 0)                                                 ? 25 :
      (IS_ASIC && POWER_CTRL == 1 && `SF_MACRO_HAS_SLEEP(MACRO_ID) == 0)                            ? 26 :
      (IS_ASIC && READ_LATENCY < `SF_MACRO_LATENCY(MACRO_ID))                                       ? 27 :
      (IS_ASIC && T_NR * T_NC > 1024)                                                               ? 28 : 0;

  if (ERR_CODE == 1)  begin : g_err_01_data_width_must_be_1_to_1024
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E01]: DATA_WIDTH must be in 1..1024")
  end
  if (ERR_CODE == 2)  begin : g_err_02_depth_words_must_be_2_to_2_pow_30
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E02]: DEPTH_WORDS must be in 2..2**30")
  end
  if (ERR_CODE == 3)  begin : g_err_03_read_latency_must_be_1_to_16
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E03]: READ_LATENCY must be in 1..16 (asynchronous read is not supported)")
  end
  if (ERR_CODE == 4)  begin : g_err_04_byte_enable_must_be_0_or_1
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E04]: BYTE_ENABLE must be 0 or 1")
  end
  if (ERR_CODE == 5)  begin : g_err_05_data_width_not_a_multiple_of_byte_width
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E05]: BYTE_ENABLE=1 needs BYTE_WIDTH >= 1 and DATA_WIDTH a multiple of BYTE_WIDTH")
  end
  if (ERR_CODE == 6)  begin : g_err_06_commercial_macro_not_available
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E06]: MEMORY_TECH=ASIC_COMMERCIAL: no qualified commercial macro files (Verilog/Liberty/LEF) exist in this package; nothing can be integrated")
  end
  if (ERR_CODE == 7)  begin : g_err_07_unknown_memory_tech
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E07]: MEMORY_TECH is not GENERIC, FPGA or a catalogued ASIC family")
  end
  if (ERR_CODE == 8)  begin : g_err_08_unknown_ecc_mode
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E08]: ECC_MODE must be NONE, SECDED_WORD or SECDED_LANE")
  end
  if (ERR_CODE == 9)  begin : g_err_09_word_ecc_with_byte_enable_needs_rmw
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E09]: SECDED_WORD with BYTE_ENABLE=1 needs a read-modify-write that the always-accept interface cannot stall for: use SECDED_LANE, or BYTE_ENABLE=0")
  end
  if (ERR_CODE == 10) begin : g_err_10_lane_ecc_needs_byte_enable
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E10]: SECDED_LANE needs BYTE_ENABLE=1 (the lane is the ECC granule); use SECDED_WORD for whole-word writes")
  end
  if (ERR_CODE == 11) begin : g_err_11_ecc_granule_wider_than_502
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E11]: the ECC granule (lane or word) must be at most 502 data bits")
  end
  if (ERR_CODE == 12) begin : g_err_12_test_mode_must_be_0_or_1
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E12]: TEST_MODE must be 0 or 1")
  end
  if (ERR_CODE == 13) begin : g_err_13_power_ctrl_must_be_0_or_1
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E13]: POWER_CTRL must be 0 or 1")
  end
  if (ERR_CODE == 14) begin : g_err_14_wake_cycles_must_be_1_to_8
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E14]: WAKE_CYCLES must be in 1..8")
  end
  if (ERR_CODE == 15) begin : g_err_15_init_mode_invalid
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E15]: INIT_MODE must be NONE, ZERO, FILE or PATTERN")
  end
  if (ERR_CODE == 16) begin : g_err_16_init_file_missing
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E16]: INIT_MODE=FILE requires INIT_FILE")
  end
  if (ERR_CODE == 17) begin : g_err_17_init_pattern_is_simulation_only
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E17]: INIT_MODE=PATTERN is simulation-only")
  end
  if (ERR_CODE == 18) begin : g_err_18_fpga_ram_style_invalid
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E18]: FPGA_RAM_STYLE must be AUTO, BLOCK, ULTRA or DISTRIBUTED")
  end
  if (ERR_CODE == 19) begin : g_err_19_macro_id_only_for_asic
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E19]: MACRO_ID applies only to ASIC technologies (must be 0 for GENERIC/FPGA)")
  end
  if (ERR_CODE == 20) begin : g_err_20_asic_macro_array_has_no_initial_content
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E20]: ASIC macros power up with undefined content: only INIT_MODE=NONE is legal (a boot image needs a ROM macro or a loader)")
  end
  if (ERR_CODE == 21) begin : g_err_21_unknown_macro_id
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E21]: MACRO_ID is not a catalogue entry (see sf_sram_macro_ids.svh; run tools/sram_cfg_gen.py to select one)")
  end
  if (ERR_CODE == 22) begin : g_err_22_macro_family_differs_from_memory_tech
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E22]: MACRO_ID belongs to a different technology family than MEMORY_TECH")
  end
  if (ERR_CODE == 23) begin : g_err_23_macro_has_no_write_mask
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E23]: the macro has no write mask and an external read-modify-write cannot be stalled for: BYTE_ENABLE=1 rejected")
  end
  if (ERR_CODE == 24) begin : g_err_24_lane_not_a_multiple_of_macro_mask_granularity
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E24]: the stored lane width (data + ECC bits) is not a multiple of the macro's write-mask granularity (e.g. 8-bit byte masks): choose another BYTE_WIDTH / ECC layout / macro")
  end
  if (ERR_CODE == 25) begin : g_err_25_macro_with_builtin_ecc_not_supported
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E25]: macros with built-in ECC are not supported by this adapter (none exists in the catalogue)")
  end
  if (ERR_CODE == 26) begin : g_err_26_macro_has_no_sleep_retention
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E26]: the macro has no sleep/retention pins: POWER_CTRL=1 rejected")
  end
  if (ERR_CODE == 27) begin : g_err_27_read_latency_below_macro_latency
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E27]: READ_LATENCY is below the macro's native read latency")
  end
  if (ERR_CODE == 28) begin : g_err_28_more_than_1024_macro_instances
    `SF_MACRO_CFG_FATAL("sf_sram_macro_wrapper[E28]: more than 1024 macro instances: review the plan with tools/sram_cfg_gen.py")
  end

  // ------------------------------------------------ test hand-over (TEST_MODE) and power gating
  // tst_sel is the REGISTERED test select seen by every backend (IHP: it drives A_BIST_EN).  Accesses are dropped in the
  // cycle tst_active changes and in the cycle after it (the IHP "one cycle before and after A_BIST_EN" rule).
  logic tst_sel;
  logic quiet;
  if (TEST_MODE != 0) begin : g_hand
    logic tst_sel_q, settle_q;
    wire logic chg = tst_active ^ tst_sel_q;
    always_ff @(posedge clk) begin
      tst_sel_q <= tst_active;
      settle_q  <= chg;
    end
    assign tst_sel = tst_sel_q;
    assign quiet   = chg | settle_q;
  end else begin : g_nohand
    assign tst_sel = 1'b0;
    assign quiet   = 1'b0;
  end

  logic pwr_ok;
  if (ERR_CODE == 0 && POWER_CTRL != 0) begin : g_pwr
    logic [WAKE_CYCLES-1:0] awake_q;
    wire logic nsleep = ~pwr_sleep;
    always_ff @(posedge clk) awake_q <= (awake_q << 1) | WAKE_CYCLES'(nsleep);
    assign pwr_ok = ~pwr_sleep & (&awake_q);
  end else begin : g_nopwr
    assign pwr_ok = 1'b1;
  end
  assign pwr_active = pwr_ok;

  wire logic f_ce = ce & ~tst_sel & pwr_ok & ~quiet;
  wire logic t_ce = (TEST_MODE != 0) & tst_ce & tst_sel & pwr_ok & ~quiet;

  // ------------------------------------------------ write path: lane enables + ECC encode
  wire logic [LANES-1:0] w_lane = (BYTE_ENABLE != 0) ? wmask : {LANES{1'b1}};
  logic [PHYS_WIDTH-1:0] w_phys;
  for (genvar l = 0; l < LANES; l++) begin : g_wl
    if (ERR_CODE == 0 && ECC_MODE != `SF_ECC_NONE) begin : g_enc
      logic [ECC_R-1:0] chk;
      sf_ecc_secded_enc #(.K(LANE_W)) u_enc (.data(wdata[l*LANE_W +: LANE_W]), .check(chk));
      assign w_phys[l*PLW +: PLW] = {chk, wdata[l*LANE_W +: LANE_W]};
    end else begin : g_raw
      assign w_phys[l*PLW +: PLW] = wdata[l*LANE_W +: LANE_W];
    end
  end

  // ------------------------------------------------ backend (native latency 1, raw stored bits)
  logic [PHYS_WIDTH-1:0] raw;
  // Independent (not else-if chained) generate blocks: instance names in synthesized netlists stay short and stable
  // (u_sram.g_asic.u_be.g_row[r].g_col[c].g_<family>.u_leaf.g_<macro>.u_macro), which the floorplan scripts rely on.
  if (ERR_CODE == 0 && IS_GEN) begin : g_gen
    sf_sram_be_generic #(.PW(PHYS_WIDTH), .NL(LANES), .PLW(PLW), .DEPTH(DEPTH_WORDS),
                         .INIT_MODE(INIT_MODE), .INIT_FILE(INIT_FILE)) u_be (
      .clk(clk), .ce(f_ce), .we(we), .wlane(w_lane), .idx(idx), .wdata(w_phys),
      .tst_active(tst_sel), .tst_ce(t_ce), .tst_we(tst_we), .tst_idx(tst_idx), .tst_wdata(tst_wdata), .rdata(raw));
  end
  if (ERR_CODE == 0 && IS_FPGA) begin : g_fpga
    sf_sram_be_fpga #(.PW(PHYS_WIDTH), .NL(LANES), .PLW(PLW), .DEPTH(DEPTH_WORDS), .RAM_STYLE(FPGA_RAM_STYLE),
                      .INIT_MODE(INIT_MODE), .INIT_FILE(INIT_FILE)) u_be (
      .clk(clk), .ce(f_ce), .we(we), .wlane(w_lane), .idx(idx), .wdata(w_phys),
      .tst_active(tst_sel), .tst_ce(t_ce), .tst_we(tst_we), .tst_idx(tst_idx), .tst_wdata(tst_wdata), .rdata(raw));
  end
  if (ERR_CODE == 0 && IS_ASIC) begin : g_asic
    sf_sram_be_asic #(.MACRO_ID(MACRO_ID), .PW(PHYS_WIDTH), .NL(LANES), .PLW(PLW), .DEPTH(DEPTH_WORDS),
                      .TEST_MODE(TEST_MODE)) u_be (
      .clk(clk), .ce(f_ce), .we(we), .wlane(w_lane), .idx(idx), .wdata(w_phys),
      .tst_active(tst_sel), .tst_ce(t_ce), .tst_we(tst_we), .tst_idx(tst_idx), .tst_wdata(tst_wdata), .rdata(raw));
  end
  if (ERR_CODE != 0) begin : g_nobackend
    assign raw = '0;   // illegal configuration: elaboration already failed; keeps the netlist well-formed for tools that continue
  end

  // ------------------------------------------------ read path: decode, latency pipeline, status
  logic fr_v1, tr_v1;     // native-slot valid (functional / test read accepted in the previous cycle)
  always_ff @(posedge clk) begin
    fr_v1 <= f_ce & ~we;
    tr_v1 <= t_ce & ~tst_we;
  end

  logic [DW-1:0] dec_data;
  logic          dec_cor, dec_unc;
  if (ERR_CODE == 0 && ECC_MODE != `SF_ECC_NONE) begin : g_dec
    logic [LANES-1:0] lc, lu;
    for (genvar l = 0; l < LANES; l++) begin : g_l
      sf_ecc_secded_dec #(.K(LANE_W)) u_dec (
        .data_in(raw[l*PLW +: LANE_W]), .check_in(raw[l*PLW + LANE_W +: ECC_R]),
        .data_out(dec_data[l*LANE_W +: LANE_W]), .corrected(lc[l]), .uncorrectable(lu[l]));
    end
    assign dec_cor = |lc;
    assign dec_unc = |lu;
  end else begin : g_nodec
    assign dec_data = raw;
    assign dec_cor  = 1'b0;
    assign dec_unc  = 1'b0;
  end

  logic [DW-1:0]         rdata_i;
  logic                  vld_i, cor_i, unc_i;
  logic [PHYS_WIDTH-1:0] traw_i;
  logic                  tvld_i;
  if (ERR_CODE != 0 || READ_LATENCY == 1) begin : g_lat1   // (illegal configs: keep the netlist well-formed; elaboration already failed)
    assign rdata_i = dec_data;
    assign vld_i   = fr_v1;
    assign cor_i   = dec_cor & fr_v1;
    assign unc_i   = dec_unc & fr_v1;
    assign traw_i  = raw;
    assign tvld_i  = tr_v1;
  end else begin : g_latn
    // decode, then READ_LATENCY-1 register stages (no reset, no enable: same template as the SRAMCore array pipeline)
    logic [DW-1:0]         d_q [READ_LATENCY-1];
    logic [PHYS_WIDTH-1:0] r_q [READ_LATENCY-1];
    logic [READ_LATENCY-2:0] v_q, c_q, u_q, tv_q;
    always_ff @(posedge clk) begin
      d_q[0]  <= dec_data;
      r_q[0]  <= raw;
      v_q[0]  <= fr_v1;
      c_q[0]  <= dec_cor & fr_v1;
      u_q[0]  <= dec_unc & fr_v1;
      tv_q[0] <= tr_v1;
      for (int k = 1; k < READ_LATENCY - 1; k++) begin
        d_q[k]  <= d_q[k-1];
        r_q[k]  <= r_q[k-1];
        v_q[k]  <= v_q[k-1];
        c_q[k]  <= c_q[k-1];
        u_q[k]  <= u_q[k-1];
        tv_q[k] <= tv_q[k-1];
      end
    end
    assign rdata_i = d_q[READ_LATENCY-2];
    assign vld_i   = v_q[READ_LATENCY-2];
    assign cor_i   = c_q[READ_LATENCY-2];
    assign unc_i   = u_q[READ_LATENCY-2];
    assign traw_i  = r_q[READ_LATENCY-2];
    assign tvld_i  = tv_q[READ_LATENCY-2];
  end

`ifdef SF_MACRO_POISON
  `ifndef SYNTHESIS
  assign rdata     = vld_i  ? rdata_i : {DW{1'bx}};
  assign tst_rdata = tvld_i ? traw_i  : {PHYS_WIDTH{1'bx}};
  `else
  assign rdata     = rdata_i;
  assign tst_rdata = traw_i;
  `endif
`else
  assign rdata     = rdata_i;
  assign tst_rdata = traw_i;
`endif
  assign rd_vld            = vld_i;
  assign ecc_corrected     = cor_i;
  assign ecc_uncorrectable = unc_i;
  assign tst_rd_vld        = tvld_i;

  // ------------------------------------------------ simulation-only protocol checks (excluded when SYNTHESIS)
`ifndef SYNTHESIS
  logic seen_clk = 1'b0;
  always @(posedge clk) begin
    seen_clk <= 1'b1;
    if (seen_clk) begin
      if ((^{ce}) === 1'bx)
        $error("SF_MACRO_ASSERT_X: ce is X/Z (GF180MCU requires CEN high before the first cycle; drive ce=0 out of reset)");
      else if (ce) begin
        if ((^{we, idx}) === 1'bx) $error("SF_MACRO_ASSERT_X: we/idx is X/Z during an access");
        if (we && BYTE_ENABLE != 0 && (^{wmask}) === 1'bx) $error("SF_MACRO_ASSERT_X: wmask is X/Z during a write");
        if (32'(idx) >= 32'(DEPTH_WORDS)) $error("SF_MACRO_ASSERT_OOB: idx %0d >= DEPTH_WORDS %0d (the macro array has no bounds check)", idx, DEPTH_WORDS);
        if (we && BYTE_ENABLE == 0 && !wmask[0]) $error("SF_MACRO_ASSERT_WMASK: wmask is ignored when BYTE_ENABLE=0 (write is full-word); tie it to 1");
        if (TEST_MODE != 0 && tst_sel && !quiet) $error("SF_MACRO_ASSERT_TSTOWN: functional access while the test bus owns the array");
        if (!pwr_ok) $error("SF_MACRO_ASSERT_SLEEP: functional access while asleep / waking (dropped)");
        if (quiet) $error("SF_MACRO_ASSERT_HANDOVER: functional access within 2 cycles of a tst_active change (dropped)");
      end
      if (TEST_MODE == 0 && (tst_active || tst_ce)) $error("SF_MACRO_ASSERT_TSTOFF: test port used but TEST_MODE=0");
      if (TEST_MODE != 0 && tst_ce) begin
        if (!tst_sel && !quiet) $error("SF_MACRO_ASSERT_TSTOWN: test access without tst_active");
        if (!pwr_ok) $error("SF_MACRO_ASSERT_SLEEP: test access while asleep / waking (dropped)");
        if (quiet) $error("SF_MACRO_ASSERT_HANDOVER: test access within 2 cycles of a tst_active change (dropped)");
      end
    end
  end
`endif

endmodule

/* verilator lint_on UNUSEDSIGNAL */
`default_nettype wire
