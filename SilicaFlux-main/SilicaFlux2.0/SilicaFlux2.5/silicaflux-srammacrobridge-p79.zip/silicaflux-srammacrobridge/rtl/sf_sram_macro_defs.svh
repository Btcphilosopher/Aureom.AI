// =============================================================================
// SilicaFlux SRAMMacroBridge (Project 79) :: sf_sram_macro_defs.svh
//
// Constants shared by the macro wrapper, its backends and the ECC blocks.  A `define header rather than a package:
// Yosys 0.33 cannot resolve package references in module parameter lists (same constraint as SRAMCore P71), and every
// synthesizable module here must elaborate unaided in Verilator, Icarus and Yosys.
//
// Values are part of the public contract: never renumber, only append.
// =============================================================================
`ifndef SF_SRAM_MACRO_DEFS_SVH
`define SF_SRAM_MACRO_DEFS_SVH

// --------------------------------------------------------------- MEMORY_TECH
//   GENERIC  : behavioural array (simulation, generic synthesis, formal)
//   FPGA     : inferred block / ultra / distributed RAM (no vendor primitive is instantiated)
//   ASIC_*   : real open-PDK SRAM hard macros; MACRO_ID selects the catalogue entry (sf_sram_macro_ids.svh).  The family
//              must match the macro's family: the wrapper rejects a mismatch.
//   ASIC_COMMERCIAL : placeholder, ALWAYS rejected: no qualified commercial macro files (Verilog/Liberty/LEF) exist in
//              this package, so nothing can be integrated or verified (see docs/05_commercial_macros.md).
`define SF_MEM_TECH_GENERIC             0
`define SF_MEM_TECH_FPGA                1
`define SF_MEM_TECH_ASIC_IHP_SG13G2     10
`define SF_MEM_TECH_ASIC_GF180MCU       11
`define SF_MEM_TECH_ASIC_SKY130_OPENRAM 12
`define SF_MEM_TECH_ASIC_COMMERCIAL     19

// --------------------------------------------------------------- ECC_MODE
//   NONE       : no check bits
//   SECDED_WORD: one Hsiao (odd-weight-column) SECDED codeword over DATA_WIDTH bits.  Partial (byte) writes would need a
//                read-modify-write, which the always-accept interface cannot stall for: BYTE_ENABLE must be 0.
//   SECDED_LANE: one codeword per write lane (BYTE_WIDTH data bits).  Byte enables work without read-modify-write; the
//                check bits of a lane are written with that lane's enable.  BYTE_ENABLE must be 1.
`define SF_ECC_NONE        0
`define SF_ECC_SECDED_WORD 1
`define SF_ECC_SECDED_LANE 2

// Number of SECDED check bits for k data bits: smallest r with (2^(r-1) - r) >= k (odd-weight columns of weight >= 3).
// Valid for 1 <= k <= 502 (the wrapper rejects larger widths).  Mirrored in tools/ecc_ref.py.
`define SF_ECC_R(k) (((k) <= 4) ? 4 : ((k) <= 11) ? 5 : ((k) <= 26) ? 6 : ((k) <= 57) ? 7 : ((k) <= 120) ? 8 : \
                     ((k) <= 247) ? 9 : 10)

// --------------------------------------------------------------- INIT_MODE (same values as SRAMCore)
`define SF_MACRO_INIT_NONE    0
`define SF_MACRO_INIT_ZERO    1
`define SF_MACRO_INIT_FILE    2
`define SF_MACRO_INIT_PATTERN 3

// --------------------------------------------------------------- FPGA_RAM_STYLE (attribute hint only)
`define SF_MACRO_FPGA_AUTO        0
`define SF_MACRO_FPGA_BLOCK       1
`define SF_MACRO_FPGA_ULTRA       2
`define SF_MACRO_FPGA_DISTRIBUTED 3

// --------------------------------------------------------------- configuration errors
// Elaboration-time failure for illegal parameterisations.  Icarus 12 does not evaluate elaboration-time $fatal, so it
// gets a time-0 $fatal instead.  Yosys 0.33 aborts on the $fatal but does not print the message; the message is
// therefore also encoded in the generate-block name (g_err_*).
`ifdef __ICARUS__
  `define SF_MACRO_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SF_MACRO_CFG_FATAL(msg) $fatal(1, msg);
`endif

`endif // SF_SRAM_MACRO_DEFS_SVH
