// =============================================================================
// SilicaFlux SRAMMacroBridge :: sf_ecc_h.svh  -- included INSIDE a module body that defines K and R.
//
// Hsiao SECDED parity-check matrix.  Column j (0-based, one per data bit) is the j-th r-bit vector, in ascending
// numeric order, whose population count is ODD and >= 3.  The R check bits use the unit vectors (weight 1).  Properties
// (proved exhaustively for the widths in use by tools/ecc_ref.py --selftest):
//   * every column distinct, odd weight  -> a single error gives an odd-weight syndrome equal to exactly one column
//     (data bit) or one unit vector (check bit): corrected;
//   * any double error gives a non-zero EVEN-weight syndrome (sum of two odd-weight vectors): detected, never "corrected";
//   * >= 3 errors may alias to a single error (inherent to SECDED, documented in docs/03_ecc.md).
// Mirrored bit-for-bit by tools/ecc_ref.py (independent golden model used by the testbench vectors).
// =============================================================================
function automatic logic [K*R-1:0] sf_ecc_build_h(input int unused);
  logic [K*R-1:0] h;
  int j;
  int pc;
  begin
    h = '0;
    j = 0;
    for (int v = 1; v < (1 << R); v++) begin
      pc = 0;
      for (int b = 0; b < R; b++) pc = pc + ((v >> b) & 1);
      if (j < K && pc >= 3 && (pc % 2) == 1) begin
        h[j*R +: R] = R'(v);
        j = j + 1;
      end
    end
    sf_ecc_build_h = h;
  end
endfunction
localparam logic [K*R-1:0] SF_ECC_H = sf_ecc_build_h(0);
