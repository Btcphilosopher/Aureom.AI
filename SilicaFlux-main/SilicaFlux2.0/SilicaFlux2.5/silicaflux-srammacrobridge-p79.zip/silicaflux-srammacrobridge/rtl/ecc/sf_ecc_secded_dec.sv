// =============================================================================
// SilicaFlux SRAMMacroBridge :: sf_ecc_secded_dec
// Combinational SECDED decoder.  Inputs the stored data bits and check bits; outputs the (corrected) data and two flags:
//   corrected     : a single-bit error (data bit or check bit) was found and fixed
//   uncorrectable : the syndrome is non-zero and is neither a data column nor a check-bit unit vector
//                   (all double errors, and many multi-bit errors); data_out is then the UNCORRECTED stored data
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sram_macro_defs.svh"
`default_nettype none

module sf_ecc_secded_dec #(
  parameter int K = 32,
  localparam int R = `SF_ECC_R(K)
) (
  input  wire logic [K-1:0] data_in,
  input  wire logic [R-1:0] check_in,
  output logic      [K-1:0] data_out,
  output logic              corrected,
  output logic              uncorrectable
);
  if (K < 1 || K > 502) begin : g_err_k_out_of_range_1_502
    `SF_MACRO_CFG_FATAL("sf_ecc_secded_dec: K must be in 1..502")
  end
  `include "sf_ecc_h.svh"

  logic [R-1:0] recomputed;
  sf_ecc_secded_enc #(.K(K)) u_enc (.data(data_in), .check(recomputed));

  wire logic [R-1:0] syn = check_in ^ recomputed;
  logic [K-1:0] hit;
  for (genvar j = 0; j < K; j++) begin : g_hit
    assign hit[j] = (syn == SF_ECC_H[j*R +: R]);
  end
  wire logic syn_nz     = |syn;
  wire logic syn_unit   = syn_nz && ((syn & (syn - R'(1))) == '0);   // exactly one bit set: a check-bit error
  wire logic any_hit    = |hit;
  assign data_out      = data_in ^ hit;
  assign corrected     = any_hit | syn_unit;
  assign uncorrectable = syn_nz & ~any_hit & ~syn_unit;
endmodule

`default_nettype wire
