// =============================================================================
// SilicaFlux SRAMMacroBridge :: sf_ecc_secded_enc
// Combinational SECDED encoder: R = SF_ECC_R(K) check bits for K data bits (Hsiao code, see sf_ecc_h.svh).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sram_macro_defs.svh"
`default_nettype none

module sf_ecc_secded_enc #(
  parameter int K = 32,
  localparam int R = `SF_ECC_R(K)
) (
  input  wire logic [K-1:0] data,
  output logic      [R-1:0] check
);
  if (K < 1 || K > 502) begin : g_err_k_out_of_range_1_502
    `SF_MACRO_CFG_FATAL("sf_ecc_secded_enc: K must be in 1..502")
  end
  `include "sf_ecc_h.svh"

  for (genvar i = 0; i < R; i++) begin : g_chk
    logic [K-1:0] rowmask;
    for (genvar j = 0; j < K; j++) begin : g_m
      assign rowmask[j] = SF_ECC_H[j*R + i];
    end
    assign check[i] = ^(data & rowmask);
  end
endmodule

`default_nettype wire
