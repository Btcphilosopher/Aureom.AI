// SilicaFlux SRAMMacroBridge RTL file list (relative to the package root).  Include dirs: -Irtl -Irtl/ecc -Irtl/backends
// For ASIC simulation also compile the vendor Verilog models of the macros in use (scripts/run_sim.py does this); for
// synthesis/lint compile rtl/backends/asic/stubs/sf_sram_macro_blackboxes.sv INSTEAD of the vendor models.
rtl/ecc/sf_ecc_secded_enc.sv
rtl/ecc/sf_ecc_secded_dec.sv
rtl/backends/sf_sram_be_generic.sv
rtl/backends/sf_sram_be_fpga.sv
rtl/backends/asic/sf_sram_leaf_ihp1p.sv
rtl/backends/asic/sf_sram_leaf_gf180.sv
rtl/backends/asic/sf_sram_leaf_sky130.sv
rtl/backends/sf_sram_be_asic.sv
rtl/sf_sram_macro_wrapper.sv
