// =============================================================================
// SilicaFlux SRAMMacroBridge :: sf_sram_array_init.svh  -- included inside a module that defines mem[], PW, DEPTH,
// INIT_MODE, INIT_FILE.  Power-up content of an inferred array (identical semantics to SRAMCore's INIT_MODE).
//   NONE: no initial content (undefined: X in a 4-state simulator).  ZERO/FILE: FPGA bitstream init and simulation.
//   PATTERN: deterministic non-zero word per address, SIMULATION ONLY (rejected under SYNTHESIS by the wrapper).
// =============================================================================
localparam int NCHUNK = (PW + 31) / 32;
function automatic logic [PW-1:0] init_pattern(input int unsigned i);
  logic [PW-1:0] w;
  logic [31:0]   h;
  begin
    w = '0;
    for (int k = 0; k < NCHUNK; k++) begin
      h = (32'(i) * 32'h9E3779B1) ^ (32'(k + 1) * 32'h85EBCA6B) ^ 32'hC2B2AE35;
      h = h ^ (h >> 15);
      h = h * 32'h2C1B3C6D;
      h = h ^ (h >> 12);
      for (int b = 0; b < 32; b++)
        if (k * 32 + b < PW) w[k * 32 + b] = h[b];
    end
    init_pattern = w;
  end
endfunction

initial begin
  if (INIT_MODE == `SF_MACRO_INIT_ZERO) begin
    for (int i = 0; i < DEPTH; i++) mem[i] = '0;
  end else if (INIT_MODE == `SF_MACRO_INIT_FILE) begin
    $readmemh(INIT_FILE, mem);
  end else if (INIT_MODE == `SF_MACRO_INIT_PATTERN) begin
    for (int i = 0; i < DEPTH; i++) mem[i] = init_pattern(i);
  end
end
