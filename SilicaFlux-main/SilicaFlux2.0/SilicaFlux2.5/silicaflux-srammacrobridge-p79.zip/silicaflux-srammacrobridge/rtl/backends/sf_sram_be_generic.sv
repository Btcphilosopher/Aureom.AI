// =============================================================================
// SilicaFlux SRAMMacroBridge :: sf_sram_be_generic          -- MODE A: GENERIC RTL
// Behavioural, synthesizable physical-word array for simulation, formal and generic synthesis.  It is NOT a
// manufacturable ASIC SRAM: on an ASIC flow it becomes flip-flops/latches and is only acceptable for tiny memories
// (the wrapper's ASIC modes use real macros instead).
//
// Backend contract (identical for all three backends; ECC and latency live in the wrapper):
//   physical word = NL lanes x PLW bits (PW = NL*PLW); one access per cycle; native latency 1 (rdata registered);
//   `rdata` holds raw stored bits and is only meaningful the cycle after a read;
//   tst_active=1: the test port owns the array (raw word, all lanes written).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sram_macro_defs.svh"
`default_nettype none

module sf_sram_be_generic #(
  parameter int PW        = 32,
  parameter int NL        = 4,
  parameter int PLW       = 8,
  parameter int DEPTH     = 1024,
  parameter int INIT_MODE = `SF_MACRO_INIT_NONE,
  parameter     INIT_FILE = "",
  localparam int IDXW     = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic            clk,
  input  wire logic            ce,
  input  wire logic            we,
  input  wire logic [NL-1:0]   wlane,
  input  wire logic [IDXW-1:0] idx,
  input  wire logic [PW-1:0]   wdata,
  input  wire logic            tst_active,
  input  wire logic            tst_ce,
  input  wire logic            tst_we,
  input  wire logic [IDXW-1:0] tst_idx,
  input  wire logic [PW-1:0]   tst_wdata,
  output logic      [PW-1:0]   rdata
);
  logic [PW-1:0] mem [DEPTH];
  `include "sf_sram_array_body.svh"
endmodule

`default_nettype wire
