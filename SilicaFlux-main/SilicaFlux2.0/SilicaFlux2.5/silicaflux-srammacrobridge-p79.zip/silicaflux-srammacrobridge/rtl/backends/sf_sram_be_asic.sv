// =============================================================================
// SilicaFlux SRAMMacroBridge :: sf_sram_be_asic             -- MODE C: real SRAM hard macros
// Tiles NR x NC instances of ONE catalogue macro (MACRO_ID, see sf_sram_macro_ids.svh) into the physical word array the
// wrapper asks for.  The catalogue only contains macros whose Verilog model, LEF and Liberty files were read and
// cross-checked (manifests/); a technology cell name is never assumed.
//
//   NC = ceil(PW / macro bits)    columns: split the physical word (data + any ECC check bits) over macro columns;
//   NR = ceil(DEPTH / macro words) rows   : high address bits select the row; rows beyond DEPTH are unreachable.
//   padding bits of the last column are written as 0 with mask 0.
//
// Write mask: the wrapper's lane enables are expanded to a per-bit mask here; the leaf converts it to the macro's own
// mask (bit mask active-high / active-low, or byte mask).  Read: the row of the previous cycle's access is registered
// (exactly like the macro's own input registers) and selects the row's output; unselected rows are never observed, so
// held / X-ing macro outputs cannot leak.  Native latency = 1 (all catalogue macros; asserted by the wrapper).
// Classification: HARD MACRO WRAPPER (simulation with the vendor Verilog models; macros are black boxes in synthesis)
// =============================================================================
`include "sf_sram_macro_defs.svh"
`include "sf_sram_macro_ids.svh"
`include "sf_sram_macro_funcs.svh"
`default_nettype none

module sf_sram_be_asic #(
  parameter int MACRO_ID  = 1,   // legal default (first IHP catalogue entry) so tools that elaborate defaults do not hit the unknown-macro error
  parameter int PW        = 32,
  parameter int NL        = 4,
  parameter int PLW       = 8,
  parameter int DEPTH     = 1024,
  parameter int TEST_MODE = 0,
  localparam int IDXW     = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int FAM      = `SF_MACRO_FAMILY(MACRO_ID),
  localparam int MB       = `SF_MACRO_BITS(MACRO_ID),
  localparam int MW       = `SF_MACRO_WORDS(MACRO_ID),
  localparam int MAW      = `SF_MACRO_AW(MACRO_ID),
  localparam int NC       = (PW + MB - 1) / MB,
  localparam int NR       = (DEPTH + MW - 1) / MW,
  localparam int PADW     = NC * MB
) (
  input  wire logic            clk,
  input  wire logic            ce,
  input  wire logic            we,
  input  wire logic [NL-1:0]   wlane,
  input  wire logic [IDXW-1:0] idx,
  input  wire logic [PW-1:0]   wdata,
  input  wire logic            tst_active,
  input  wire logic            tst_ce,
  input  wire logic            tst_we,
  input  wire logic [IDXW-1:0] tst_idx,
  input  wire logic [PW-1:0]   tst_wdata,
  output logic      [PW-1:0]   rdata
);
  // ---------------------------------------------------------------- address split
  wire logic [31:0]    f_idx32 = 32'(idx);
  wire logic [31:0]    t_idx32 = 32'(tst_idx);
  wire logic [MAW-1:0] f_addr  = f_idx32[MAW-1:0];
  wire logic [MAW-1:0] t_addr  = t_idx32[MAW-1:0];
  wire logic [31:0]    f_row   = f_idx32 >> MAW;
  wire logic [31:0]    t_row   = t_idx32 >> MAW;

  // ---------------------------------------------------------------- data / mask spreading over columns
  // (test writes always enable every used bit: the leaf supplies the all-ones test mask itself)
  wire logic [PADW-1:0] f_wd = PADW'(wdata);
  wire logic [PADW-1:0] t_wd = PADW'(tst_wdata);
  logic [PADW-1:0] f_bm;
  for (genvar p = 0; p < PADW; p++) begin : g_bm
    if (p < PW) begin : g_used
      assign f_bm[p] = wlane[p / PLW];
    end else begin : g_pad
      assign f_bm[p] = 1'b0;
    end
  end

  // ---------------------------------------------------------------- the macro array
  logic [NR*PADW-1:0] rd_flat;
  for (genvar r = 0; r < NR; r++) begin : g_row
    wire logic hit_f = (f_row == 32'(r));
    wire logic hit_t = (t_row == 32'(r));
    for (genvar c = 0; c < NC; c++) begin : g_col
      if (FAM == `SF_MEM_TECH_ASIC_IHP_SG13G2) begin : g_ihp
        sf_sram_leaf_ihp1p #(.MACRO_ID(MACRO_ID), .TEST_MODE(TEST_MODE)) u_leaf (
          .clk(clk), .ce(ce & hit_f), .we(we), .bm(f_bm[c*MB +: MB]), .addr(f_addr), .wdata(f_wd[c*MB +: MB]),
          .rdata(rd_flat[(r*NC + c)*MB +: MB]),
          .tst_en(tst_active), .tst_ce(tst_ce & hit_t), .tst_we(tst_we), .tst_addr(t_addr), .tst_wdata(t_wd[c*MB +: MB]));
      end
      if (FAM == `SF_MEM_TECH_ASIC_GF180MCU) begin : g_gf
        sf_sram_leaf_gf180 #(.MACRO_ID(MACRO_ID), .TEST_MODE(TEST_MODE)) u_leaf (
          .clk(clk), .ce(ce & hit_f), .we(we), .bm(f_bm[c*MB +: MB]), .addr(f_addr), .wdata(f_wd[c*MB +: MB]),
          .rdata(rd_flat[(r*NC + c)*MB +: MB]),
          .tst_en(tst_active), .tst_ce(tst_ce & hit_t), .tst_we(tst_we), .tst_addr(t_addr), .tst_wdata(t_wd[c*MB +: MB]));
      end
      if (FAM == `SF_MEM_TECH_ASIC_SKY130_OPENRAM) begin : g_sky
        sf_sram_leaf_sky130 #(.MACRO_ID(MACRO_ID), .TEST_MODE(TEST_MODE)) u_leaf (
          .clk(clk), .ce(ce & hit_f), .we(we), .bm(f_bm[c*MB +: MB]), .addr(f_addr), .wdata(f_wd[c*MB +: MB]),
          .rdata(rd_flat[(r*NC + c)*MB +: MB]),
          .tst_en(tst_active), .tst_ce(tst_ce & hit_t), .tst_we(tst_we), .tst_addr(t_addr), .tst_wdata(t_wd[c*MB +: MB]));
      end
    end
  end

  // ---------------------------------------------------------------- read: registered row select + row mux
  logic [31:0] row_q;
  always_ff @(posedge clk) row_q <= tst_active ? t_row : f_row;

  always_comb begin
    rdata = '0;
    for (int r = 0; r < NR; r++) begin
      if (row_q == 32'(r)) rdata = rdata | rd_flat[r*PADW +: PW];
    end
  end
endmodule

`default_nettype wire
