// =============================================================================
// SilicaFlux SRAMMacroBridge :: sf_sram_array_body.svh -- the inferred single-port array template, included by the
// generic and FPGA backends so both implement EXACTLY the same behaviour.  Expects (in the including module):
//   PW, NL, PLW, DEPTH, INIT_MODE, INIT_FILE, ports clk/ce/we/wlane/idx/wdata/tst_*/rdata, and the declaration of
//   `mem` (with any vendor ram-style attribute) immediately before the `include of this file.
//
// Template: single clock; per-lane write enables in a for loop; read in the else-branch of the write enable
// ("no-change"); NO reset on any storage or output register; no asynchronous read.  A test access (tst_active) owns the
// port: it writes ALL lanes and reads RAW stored bits.
// =============================================================================
wire logic                  a_ce    = tst_active ? tst_ce    : ce;
wire logic                  a_we    = tst_active ? tst_we    : we;
wire logic [IDXW-1:0]       a_idx   = tst_active ? tst_idx   : idx;
wire logic [PW-1:0]         a_wdata = tst_active ? tst_wdata : wdata;
wire logic [NL-1:0]         a_lane  = tst_active ? {NL{1'b1}} : wlane;

`include "sf_sram_array_init.svh"

always_ff @(posedge clk) begin
  if (a_ce) begin
    if (a_we) begin
      for (int l = 0; l < NL; l++) begin
        if (a_lane[l]) mem[a_idx][l*PLW +: PLW] <= a_wdata[l*PLW +: PLW];
      end
    end else begin
      rdata <= mem[a_idx];
    end
  end
end
