// =============================================================================
// SilicaFlux SRAMMacroBridge :: sf_sram_be_fpga             -- MODE B: FPGA memory INFERENCE
// The same array template as the generic backend, with a vendor RAM-style attribute chosen by RAM_STYLE:
//   AUTO        no attribute (the tool chooses)
//   BLOCK       ram_style="block" (AMD/Xilinx), ramstyle="M20K" (Intel), syn_ramstyle="block_ram" (Lattice/Synplify)
//   ULTRA       ram_style="ultra"  (AMD UltraRAM; tool constraints apply: see docs/02_backends.md)
//   DISTRIBUTED ram_style="distributed" / ramstyle="MLAB" / syn_ramstyle="select_ram"
// No vendor primitive is instantiated: a primitive could not be simulated or checked here (no vendor libraries), and
// the project rule is not to invent library cells.  Inference was checked with Yosys (xc7 / xcup / ice40 / ecp5);
// Vivado/Quartus behaviour was NOT checked (no vendor tool available).
// Classification: SYNTHESIZABLE (block-RAM inference)
// =============================================================================
`include "sf_sram_macro_defs.svh"
`default_nettype none

module sf_sram_be_fpga #(
  parameter int PW        = 32,
  parameter int NL        = 4,
  parameter int PLW       = 8,
  parameter int DEPTH     = 1024,
  parameter int RAM_STYLE = `SF_MACRO_FPGA_AUTO,
  parameter int INIT_MODE = `SF_MACRO_INIT_NONE,
  parameter     INIT_FILE = "",
  localparam int IDXW     = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic            clk,
  input  wire logic            ce,
  input  wire logic            we,
  input  wire logic [NL-1:0]   wlane,
  input  wire logic [IDXW-1:0] idx,
  input  wire logic [PW-1:0]   wdata,
  input  wire logic            tst_active,
  input  wire logic            tst_ce,
  input  wire logic            tst_we,
  input  wire logic [IDXW-1:0] tst_idx,
  input  wire logic [PW-1:0]   tst_wdata,
  output logic      [PW-1:0]   rdata
);
  if (RAM_STYLE == `SF_MACRO_FPGA_BLOCK) begin : g_block
    (* ram_style = "block", ramstyle = "M20K", syn_ramstyle = "block_ram" *) logic [PW-1:0] mem [DEPTH];
    `include "sf_sram_array_body.svh"
  end else if (RAM_STYLE == `SF_MACRO_FPGA_ULTRA) begin : g_ultra
    (* ram_style = "ultra" *) logic [PW-1:0] mem [DEPTH];
    `include "sf_sram_array_body.svh"
  end else if (RAM_STYLE == `SF_MACRO_FPGA_DISTRIBUTED) begin : g_dist
    (* ram_style = "distributed", ramstyle = "MLAB", syn_ramstyle = "select_ram" *) logic [PW-1:0] mem [DEPTH];
    `include "sf_sram_array_body.svh"
  end else begin : g_auto
    logic [PW-1:0] mem [DEPTH];
    `include "sf_sram_array_body.svh"
  end
endmodule

`default_nettype wire
