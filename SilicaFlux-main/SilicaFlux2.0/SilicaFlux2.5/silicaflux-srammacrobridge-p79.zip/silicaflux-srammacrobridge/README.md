# SilicaFlux SRAMMacroBridge (Project 79)

**Technology-aware SRAM macro integration** for SilicaFlux.  One logical SRAM interface (the SRAMCore/SRAM-library contract) in front of
three physical backends -- generic RTL, FPGA RAM inference, and **real open-PDK SRAM hard macros** (IHP SG13G2, GF180MCU, SKY130 OpenRAM) -- plus
the tooling that turns the macros' real Verilog / LEF / Liberty files into manifests, an RTL leaf-adapter library, a memory configuration
generator and OpenROAD floorplan inputs.  Aureom.AI | SilicaFlux Semiconductor Systems.  Primary RTL: `rtl/sf_sram_macro_wrapper.sv`.

> **Read first.**  A behavioural SystemVerilog array is not a manufacturable SRAM.  This package keeps the logical interface fixed and makes the
> physical implementation technology-aware.  The ASIC path is built **only** on macros whose vendor files were fetched, hash-pinned and
> cross-checked (25 macros).  **OpenROAD, OpenSTA, DRC and LVS were not run**; silicon qualification of any macro is **not established**; no commercial
> macro exists in this package (`ASIC_COMMERCIAL` is rejected).  See `reports/physical_readiness.md`.

## Quick start

```bash
make fetch        # download + SHA-256-verify the vendor macro files (Apache-2.0 public repos; not redistributed in this package)
make test         # unit tests, simulation matrix (incl. real vendor models), synthesis, mutation, floorplans, reports
make plan ARGS="--width 128 --words 4096 --lane-bits 32 --ecc lane --read-latency 2 --test --tech ihp"
```

Requires: Python 3, Icarus Verilog >= 12, Verilator >= 5.020, Yosys >= 0.33, Tcl 8.6 (`apt-get install iverilog verilator yosys tcl8.6`).
`python3 -I` is used throughout so downloaded files can never shadow imports.

## Using the wrapper

```systemverilog
sf_sram_macro_wrapper #(
  .DATA_WIDTH(128), .DEPTH_WORDS(4096), .READ_LATENCY(2), .BYTE_ENABLE(1), .BYTE_WIDTH(32), .ECC_MODE(`SF_ECC_SECDED_LANE),
  .TEST_MODE(1), .MEMORY_TECH(`SF_MEM_TECH_ASIC_IHP_SG13G2), .MACRO_ID(`SF_MACRO_ID_IHP_4096X16)   // ids: rtl/sf_sram_macro_ids.svh
) u_mem (.clk, .ce, .we, .wmask, .idx, .wdata, .rdata, .rd_vld, .ecc_corrected, .ecc_uncorrectable,
         .tst_active, .tst_ce, .tst_we, .tst_idx, .tst_wdata, .tst_rdata, .tst_rd_vld, .pwr_sleep('0), .pwr_active());
```
Switching `MEMORY_TECH` (GENERIC / FPGA / ASIC_*) changes the physical implementation, not the interface or its timing.  Let
`tools/sram_cfg_gen.py plan` choose `MACRO_ID`.  Compile flows: `rtl/files.f`; use `read_verilog -defer` in Yosys-based flows (defaults are legal anyway).

## Layout

| Path | Content |
|---|---|
| `rtl/` | wrapper, backends (`backends/`), ECC (`ecc/`), **generated** macro ids/lookups/leaf adapters/black-box stubs |
| `tools/` | fetch, LEF/Liberty/Verilog parsers, manifest builder, RTL generator, **configuration generator**, floorplan generator/checker, ECC golden model |
| `manifests/` | per-macro manifests + `catalog.json` (derived from the vendor files; hashes + pinned upstream URLs) |
| `physical/` | reference floorplans (Tcl + JSON) and the mock OpenDB; `configs/` reference requests and generated plans |
| `tb/`, `scripts/`, `tests/` | testbenches + vectors, simulation/synthesis/mutation/report runners, unit tests |
| `reports/` | `SUMMARY.md`, `physical_readiness.md`, `sim.md`, `synth.md`, `mutants.md` (+ JSON) |
| `docs/` | 00 audit - 01 interface - 02 backends - 03 ECC/MBIST/power - 04 physical - 05 commercial macros - 06 verification - 07 status |
