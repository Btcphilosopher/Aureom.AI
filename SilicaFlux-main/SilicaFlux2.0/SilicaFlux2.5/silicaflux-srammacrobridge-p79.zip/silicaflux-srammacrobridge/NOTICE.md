# Third-party material and licensing

SilicaFlux SRAMMacroBridge (Project 79), Aureom.AI | SilicaFlux Semiconductor Systems.

**This package contains no vendor macro file.**  The Verilog models, LEF, Liberty, datasheets and spec CSVs of the SRAM macros are
fetched on demand by `tools/fetch_vendor.py` from the public repositories listed in `tools/pins/vendor_sources.json` at the exact
pinned commits, verified against `tools/pins/vendor_sha256.json`, and treated strictly as data:

| Source | Repository (pinned commit in the JSON) | Licence of the fetched files |
|---|---|---|
| IHP SG13G2 SRAM macros | `IHP-GmbH/IHP-Open-PDK` (`ihp-sg13g2/libs.ref/sg13g2_sram`) | Apache-2.0 |
| GF180MCU SRAM macros | `google/globalfoundries-pdk-ip-gf180mcu_fd_ip_sram` | Apache-2.0 |
| SKY130 OpenRAM macros | `efabless/sky130_sram_macros` | Apache-2.0 |
| Technology / std-cell LEF (sites, layers) | `The-OpenROAD-Project/OpenROAD-flow-scripts` platform files (SkyWater, IHP, GF PDK data) | per the respective PDK; read as data only, no licence file was found at the pinned commit |

`manifests/*.json` contain facts extracted from those files (dimensions, pin names, timing numbers) with file SHA-256 hashes; they
are derived data, not copies of the files.  The generated RTL instantiates the vendor modules by name; it does not contain their code.

Project code (RTL, tools, tests, documents): see the licence terms of the Aureom.AI repository this package is delivered to; this
package does not state any licence of its own.  No proprietary or NDA material was used or is included.
