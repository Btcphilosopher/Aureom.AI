# 02 -- Backends

```
sf_sram_macro_wrapper            lane enables, ECC encode/decode, read pipeline, rd_vld/flags, test hand-over, sleep model
 |-- sf_sram_be_generic          MODE A  behavioural array
 |-- sf_sram_be_fpga             MODE B  inferred RAM + vendor ram-style attribute
 `-- sf_sram_be_asic             MODE C  NR x NC tiling of ONE real macro
       `-- sf_sram_leaf_{ihp1p,gf180,sky130}   GENERATED per family from the manifests; instantiates the real vendor module
```

All three backends implement the same **physical-word contract**: a word is `NL` lanes of `PLW` stored bits (`PW = NL*PLW`, data +
ECC check bits); one access per cycle; native read latency 1; raw stored bits on `rdata`; test accesses own the port and write all lanes.
Everything that defines user-visible behaviour (latency, ECC, flags, hand-over, sleep) lives in the wrapper, so it is identical for
every technology.

## MODE A -- GENERIC
`sf_sram_array_body.svh`: the SRAMCore template (single clock, per-lane write loop, read in the else-branch, **no reset on storage or
read data**, no async read).  Synthesizable, but on an ASIC flow the array becomes flip-flops (Yosys: 32,801 for 32x1024): acceptable
only for tiny memories.  Used for simulation, formal and as the reference in equivalence runs.

## MODE B -- FPGA
The same template with `(* ram_style *)`/`ramstyle`/`syn_ramstyle` attributes chosen by `FPGA_RAM_STYLE` (`AUTO` = no attribute).
**No vendor primitive is instantiated**: it could not be simulated or checked here (no vendor libraries) and the brief forbids assuming
a cell exists.  Evidence (Yosys 0.33, `reports/synth.md`): `RAMB36E1` (xc7), `RAMB36E2` (xcup), `SB_RAM40_4K` (ice40), `DP16KD` (ecp5)
are inferred for byte-enable and ECC configurations with no `$mem` left and no latch; `FPGA_RAM_STYLE=ULTRA` maps a 32x8192 latency-2
memory to one `URAM288` on xcup.  **Not checked**: Vivado/Quartus behaviour, URAM constraints (single clock, registered output,
byte-write granularity), timing, board operation.  `READ_LATENCY>=2` registers may or may not merge into the RAM output register
(Yosys does not merge them).

## MODE C -- ASIC macros
Catalogue (from the vendor files; `manifests/catalog.json`): **18 IHP SG13G2 1P** (64-4096 words x 8-64 bits), **4 GF180MCU** (64-512 x 8),
**3 SKY130 OpenRAM 1RW1R** (256x32, 512x32, 1024x8).  `tools/sram_cfg_gen.py` picks the macro; `MACRO_ID` is the only ASIC selector.

* `NC = ceil(PW / macro bits)` columns split the physical word; `NR = ceil(DEPTH / macro words)` rows are selected by the high index bits.
  Padding bits of the last column are written 0 with mask 0; words beyond `DEPTH_WORDS` in the last row are unreachable.
* The row of the previous cycle's access is **registered** (like the macro's own input registers) and selects the row output;
  unselected rows are never observed, so held (IHP/GF180) or X-ing (SKY130) outputs cannot leak.
* The wrapper's lane enables become a per-bit mask; the leaf converts it to the macro's mask.

### Pin mapping and polarity (from `tools/families.py`, verified against the files; see `manifests/*.json interface`)

| Role | IHP `RM_IHPSG13_1P_*` | GF180MCU `..sram*x8m8wm1` | SKY130 `sky130_sram_*_1rw1r_*` |
|---|---|---|---|
| clock | `A_CLK` | `CLK` | `clk0` (port 1: `clk1` tied to `clk`) |
| chip enable | `A_MEN` **high** | `CEN` **low** | `csb0` **low** (`csb1` = 1) |
| write / read | `A_WEN` high / `A_REN = ~we` (write-through never issued) | `GWEN` low = write | `web0` low = write |
| write mask | `A_BM` **bit**, high | `WEN[b]` **bit**, low | `wmask0` **byte**, high |
| data in / out | `A_DIN` / `A_DOUT` | `D` / `Q` | `din0` / `dout0` |
| output | held register | held (truth table) | **not held** (X after `T_HOLD`) |
| clock-to-output edge (Liberty) | rising | rising | **falling** (half-cycle access) |
| test pins | `A_BIST_*` built-in mux | none | none |
| mandatory ties | `A_DLY = 1` | -- | port 1 inactive |
| supplies (LEF) | `VDD!`, `VDDARRAY!`, `VSS!` | `VDD`, `VSS` | `vccd1`, `vssd1` |

Polarity was **cross-checked**, not just asserted: `tools/build_manifest.py` evaluates every Liberty clock-pin `internal_power` `when`
condition under the declared idle/read/write encodings (IHP, GF180: idle power < read/write power, as required; SKY130 publishes the same
number for all states so that check is "non-informative" there) and the behaviour is verified against the vendor Verilog models in simulation.

### Per-macro facts that shape the adapter
* IHP: `A_BIST_EN` also muxes the **clock** (`A_BIST_CLK`); the wrapper ties `A_BIST_CLK = clk`.  Datasheet rule: no access one cycle before
  or after `A_BIST_EN` changes (03).  Read-during-write: `A_WEN & A_REN` is a defined write-through; unused.
* GF180: `CEN` must be high before the first running cycle; the macro Liberty cell is `dont_use/dont_touch` (instantiate, never infer).
* SKY130: cross-port same-address write+read is **undefined**; port 1 is never used.  Mask granularity 8 bits: lanes of other widths
  (e.g. 9-bit, or 8+5 ECC bits) are rejected (E24) rather than silently mis-masked.
* No catalogued macro has ECC, redundancy, a repair interface or sleep/retention pins (verified from the pin lists in Verilog, LEF and
  Liberty; a new macro revision with an extra pin fails `build_manifest.py` instead of being ignored).

## Why not "just instantiate a macro name"?
Every module name, pin name and width in the leaves is generated from a manifest built from the vendor Verilog/LEF/Liberty; the
black-box stubs (`rtl/backends/asic/stubs`) are generated from the same data and `tests/test_manifests.py` proves that the set of
instantiated cell names equals the catalogue and that every stub's ports equal the vendor model's ports minus PG pins.
