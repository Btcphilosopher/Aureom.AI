# 03 -- ECC, MBIST and power

## ECC (external SECDED, no duplication of macro features)

None of the catalogued macros has built-in ECC (pin lists), so ECC is **external check-bit storage** tiled like any other bit column.
If a macro with built-in ECC appears, rule E25 rejects the combination until an adapter exists: ECC is never done twice.

**Code.** Hsiao SECDED over `K` data bits with `R` check bits, `R = min r : 2^(r-1) - r >= K` (K=8: 5, 16: 6, 32: 7, 64: 8, 128: 9).
Data bit *j* has the *j*-th r-bit vector (ascending) with odd weight >= 3 as H-column; check bits are unit vectors
(`rtl/ecc/sf_ecc_h.svh`, mirrored by `tools/ecc_ref.py`).  Single error -> odd-weight syndrome equal to one column (data bit) or a unit vector
(check bit) -> corrected, `ecc_corrected=1`.  Any double error -> non-zero even-weight syndrome -> `ecc_uncorrectable=1`, data returned
**uncorrected**.  >= 3 errors may alias to a single error (inherent to SECDED).

| Evidence | Result |
|---|---|
| `tools/ecc_ref.py --selftest` | every single-bit error corrected and every double-bit error detected, exhaustively when K+R <= 140 |
| `tb/tb_ecc_vectors.sv` vs Python golden vectors | RTL encoder/decoder == independent model (K = 8, 13, 16, 32, 39, 64, 128) |
| `tb_macro` phase P6 | through the **raw test port**: every single flip of the stored word corrected + flagged; same-lane doubles detected; cross-lane doubles (lane ECC) both corrected |

**Granule = write lane.**  `SECDED_LANE`: one codeword per lane of `BYTE_WIDTH` bits; a byte write rewrites the lane's data *and* its check
bits with the lane enable -> byte enables need no read-modify-write.  Overhead: `R/BYTE_WIDTH` (8-bit lanes 62.5 %, 16: 37.5 %, 32: 21.9 %,
64: 12.5 %); choose `BYTE_WIDTH` as the write granule you really need.  `SECDED_WORD` has the lowest overhead but only whole-word writes.
Stored lane layout: `{check[R-1:0], data[K-1:0]}`; physical word = lanes concatenated, lane 0 lowest.

Not implemented: scrubbing, error counters, error-address capture, injection ports (use the raw test port).

## MBIST integration

The test port accesses the **raw stored word** (data + check bits) with the same latency as the functional port, so
* a March test sees every cell **including the check-bit columns**, and
* a single-bit cell fault is **not masked** by ECC during test (ECC would otherwise hide it).

| Macro | Test path | Why |
|---|---|---|
| IHP SG13G2 | the macro's **built-in mux**: `A_BIST_EN` selects `A_BIST_*` inputs *and* `A_BIST_CLK`; `A_BIST_BM` all ones | the macro already pays for the mux: building another in fabric would duplicate it |
| GF180MCU, SKY130 | **fabric** functional/test mux in the leaf | the macros have no test pins |

**Hand-over rule (all technologies, enforced by the wrapper).**  `tst_active` changes in cycle *a*; no functional or test access in cycles *a*
and *a*+1; first access in cycle *a*+2.  Accesses presented earlier are **dropped** (they never reach the array) and raise
`SF_MACRO_ASSERT_HANDOVER`.  This is the IHP datasheet rule ("one cycle before and after `A_BIST_EN` changes no read, write or write-through")
applied uniformly so a test controller is portable; the select seen by all backends is the *registered* `tst_active`.  Verified by phase P8 on
GENERIC and on all three real macro families (4 dropped accesses, array untouched), and by mutant M04.

Model artefact found by that test: the GF180 Verilog model samples inputs 100 ps *after* the clock edge, so gating that releases exactly at the
edge races in zero-delay simulation; the GF180 leaf therefore has a **simulation-only** input delay (`SF_MACRO_VENDOR_INPUT_DELAY`), as the earlier
SRAM library did.  In silicon this is a *hold-time* matter: the GF180 `CEN` hold is ~2 ns at the nominal corner (Liberty), far above a flop's
clk-to-q -> STA hold fixing will buffer macro control inputs that are driven from flops (see physical readiness report).

**Redundancy / repair:** none of the macros has a redundancy or repair interface (absent from every pin list); nothing is wrapped.
`tests/test_manifests.py::test_no_sleep_ecc_redundancy_anywhere` fails if a future manifest shows otherwise.

## Power (sleep/retention)

No catalogued macro has a sleep, retention or shutdown pin, and no Liberty file contains a power state.  Therefore:
* ASIC + `POWER_CTRL=1` is **rejected** (E26); there is no honest way to implement it on these macros.
* `POWER_CTRL=1` on GENERIC/FPGA is a **logical-interface model** only: `pwr_sleep=1` blocks accesses (reads accepted before sleep still
  complete), contents are retained, `pwr_active=0` while asleep and for `WAKE_CYCLES` cycles after `pwr_sleep` falls.  It exists so system-level
  power-management RTL can be developed and verified before a macro with real retention pins exists.  It models no leakage or wake energy.
Tested: sleep with a read in flight, retention across sleep, exact wake latency (WAKE = 1..4), mutant M10 (no wake delay) killed.
