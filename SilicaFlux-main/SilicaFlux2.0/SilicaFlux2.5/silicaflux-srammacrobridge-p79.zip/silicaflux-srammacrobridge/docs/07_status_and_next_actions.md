# 07 -- Status against the brief, open items, next actions

Numbers live in `reports/SUMMARY.md` and `reports/physical_readiness.md` (generated from the result files).

## Acceptance (brief sections 1-12 and "definition of done")

| # | Requirement | Status | Evidence / caveat |
|---|---|---|---|
| 1 | Repository audit | **done** | `docs/00_repository_audit.md`.  No LEF/Liberty/Verilog macro file existed; FPGAFlow does not exist as a project. |
| 2 | `sf_sram_macro_wrapper.sv` with `DATA_WIDTH, DEPTH_WORDS, READ_LATENCY, BYTE_ENABLE, MEMORY_TECH, ECC, test`; reject incompatible settings | **done** | 28 numbered rules, one message each, identical in Verilator/Icarus; generator mirrors them. |
| 3 | Backends A (generic), B (FPGA), C (ASIC, real macros only) | **done** | B is inference-only (no vendor primitive could be verified); C covers the 25 open-PDK macros; no commercial macro exists. |
| 4 | Physical macro interface, polarity | **done** | per-family tables; polarity cross-checked against Liberty and vendor-model simulation; mutants M14-M17 kill polarity/mask bugs. |
| 5 | Macro geometry (LEF dims, PG, pins, blockages, orientation, layers) | **done (data)** | extracted and cross-checked for 25/25; tech LEF is the ORFS platform's. **Not** run through OpenROAD. |
| 6 | Timing from Liberty | **done (data)** | setup/hold/clock-to-output/min period/leakage/corners per macro; no power-state timing exists; IHP publishes no min period (null).  **No STA run.** |
| 7 | Port/collision behaviour | **done** | verified against vendor models: latency, mask behaviour, output hold, chip-enable timing; single-port use; cross-port collision avoided (SKY130 port 1 unused); no RMW needed or implemented (rejected if required). |
| 8 | ECC and MBIST integration | **done** | external SECDED (word or lane granule), raw test port, IHP built-in BIST mux used, fabric mux elsewhere, no redundancy/repair exists. |
| 9 | Memory configuration generator | **done** | all requested metrics; reports impossible requests with the rejecting rule. |
| 10 | Physical floorplan integration | **generated; not run in OpenROAD** | real instance names/dimensions; mock-OpenDB + geometry checked. |
| 11 | Verification (behavioural, FPGA, ASIC model, data, timing semantics, byte enables, invalid settings, ECC, MBIST, power) | **done** | `reports/sim.md`, `synth.md`, `mutants.md`; power only as a GENERIC/FPGA interface model (no macro supports it). |
| 12 | Deliverables | **done** | RTL, backend adapters, generator, manifests, LEF/Liberty ingest scripts, compatibility tests, floorplan Tcl, documentation, readiness report. |
| DoD | Same logical interface across supported backends; ASIC path integrates real available models and physical data | **met in simulation and data; physical implementation unproven** | identical traces GENERIC vs ASIC models; physical sign-off not attempted. |

## Not claimed
OpenROAD/OpenSTA execution, DRC/LVS/IR drop, silicon qualification of any macro, standard-cell area or timing of the wrapper logic, Vivado/Quartus
results, board validation, dual-clock operation, scrubbing/error counters, mixed-macro tilings, commercial-node macros.

## Findings worth acting on
1. **Vendor spec CSVs are unreliable**: GF180 `1_pins_desc.csv` states `A[6:0]` for three macros whose address is 6, 8 and 9 bits; the 512x8 spec's
   clock-to-Q disagrees with its own Liberty by 13 %.  Liberty/Verilog/LEF were used and agree with each other.
2. **SKY130 timing**: Liberty launches the output on the falling clock edge (half-cycle access) while the Verilog model's delay is arbitrary: never
   use the model for timing.  Its min period (1.8-2.0 ns) is not the same as the access constraint (2 x access time).
3. **Macro control hold times** (GF180 ~2 ns nominal, up to ~12 ns at slow corners) greatly exceed flop clk-to-q: hold-fix buffering will be needed on
   macro control inputs driven from flops (e.g. the test hand-over gating).
4. **No catalogued macro has sleep/retention, built-in ECC, redundancy or repair**: those features cannot be implemented honestly on them; the wrapper
   rejects sleep (E26) and builds ECC externally.
5. **Lane-granule ECC trades area for byte enables**: 8-bit lanes cost 62.5 % overhead; use 32-bit lanes (21.9 %) where the write granule allows.

## Next actions (prioritised)
| P | Action | Exit criterion |
|---|---|---|
| P0 | Run `physical/<plan>/*.tcl` in a real OpenROAD build (ORFS with IHP SG13G2 first: densest open macros, FloorplanLab already has the platform) | `SF-MACRO`/`SF-CHECK` clean, PDN connected, `check_placement` legal; fix unverified option names |
| P0 | OpenSTA with the per-corner Liberty of the chosen macro + std-cell corner at the same voltage/temperature | macro control hold fixed, read-path slack incl. ECC decode known |
| P1 | Decide the first-silicon technology; confirm foundry/MPW qualification status of its macro; fetch and inspect the GDS, run macro DRC/LVS in the platform flow | qualification and sign-off status recorded in the manifest |
| P1 | Vivado/Quartus inference run of the FPGA backend (RAM style, URAM constraints, latency-2 output register merge) | utilisation + timing report archived |
| P1 | Count wrapper logic in standard cells (Yosys + platform liberty) and feed `--logic-area-um2` / `--logic-delay-ns` | die size and timing bound without placeholders |
| P2 | Mixed-macro tiling in `sf_sram_be_asic` (less waste for depths like 1280) | generator and RTL agree; equivalence suite green |
| P2 | Optional ECC extras: scrub, error counters/address capture; sleep support when a macro with retention pins is catalogued | per-feature tests |
| P2 | Commercial compiler engagement (docs/05) | manifest + leaf + equivalence suite green on the licensed model |
