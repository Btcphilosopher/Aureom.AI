# 06 -- Verification

Everything is reproducible with `make test` (see the Makefile); results land in `reports/`.  Tools: Icarus Verilog 12.0, Verilator 5.020,
Yosys 0.33, Tcl 8.6, Python 3.  Vendor models are fetched on demand (`make fetch`); ASIC runs are **skipped, never passed**, when they are absent.

## Suites

| Suite | What it proves | Where |
|---|---|---|
| `ecc` | RTL SECDED encoder/decoder == independent Python golden model (726 vectors per K, K = 8, 13, 16, 32, 39, 64, 128) | `tb/tb_ecc_vectors.sv`, `tools/ecc_ref.py` |
| `generic`, `fpga` | wrapper behaviour on the GENERIC and FPGA-inference backends in **Icarus (4-state, poison)** and **Verilator (2-state)**; the two simulators must produce the same trace hash | `tb/tb_macro.sv`, `scripts/run_sim.py` |
| `asic` | the same testbench against the **real vendor Verilog models**: IHP (FUNCTIONAL core model), GF180MCU, SKY130 OpenRAM; tiled, with ECC, test mode, odd lane widths, 4096-word arrays | same |
| `equiv` | each ASIC configuration re-run on GENERIC with the same stimulus: **identical trace** (data, latency-independent valid responses, ECC flags, raw test reads) | `run_sim.py` |
| `neg` | every illegal parameter set fails with its rule code in **Verilator and Icarus**; legal configs elaborate | `run_sim.py` |
| `agree` | `tools/sram_cfg_gen.py err_code()` == RTL `ERR_CODE` on random + boundary configurations | `run_sim.py` |
| synthesis | Yosys per backend: generic (latch-free), FPGA block-RAM inference (xc7, xcup incl. URAM288 hint, ice40, ecp5), ASIC macro-instance counts == plan | `scripts/run_synth.py` |
| mutation | 23 injected bugs; 20 killed, 3 interface-equivalent survivors, each explained | `scripts/run_mutants.py`, `reports/mutants.md` |
| unit | parsers on synthetic fixtures, manifest invariants, RTL drift guard, generator arithmetic and rules (incl. synthetic E23/E25/E27), floorplan negative tests | `tests/` (`python3 -I -m unittest discover -s tests`) |

## `tb_macro` phases

P3 full-array initialisation (unwritten SRAM is never assumed to be zero) - P1 directed (RAW next cycle, WAR returns old data, back-to-back,
boundary words) - P2 byte enables (every single lane, walking masks, zero mask, exhaustive masks for <= 6 lanes) - P4 random traffic with hazards
and random masks + full read-back - P5 test port (raw read-back == golden encoding, hand-over, March C- over all raw bits) - P6 ECC injection through
the raw test port (every single flip corrected; same-lane and cross-lane doubles) - P7 power (in-flight read, retention, exact wake latency) - P8
hand-over negative (accesses inside the window dropped, 4 assertions, array untouched).  Every cycle: `rd_vld` equal to the expected slot (both
directions), data, ECC flags, no flag outside a slot, `rdata` X outside a slot under `SF_MACRO_POISON`.  Functional-side signals carry random noise
during test accesses (they are don't-care).

## Timing semantics -- what is and is not verified
Verified: cycle-exact latency (1..16 via 1/2/3 in tests), no output hold, write-after-read / read-after-write ordering, test-port latency, hand-over
window, wake latency.  **Not verified**: any nanosecond timing.  The vendor Verilog models are used **only functionally**; their delays
are arbitrary or absent (SKY130 `DELAY=3`, GF180 `Tdly`), IHP runs in its zero-delay `FUNCTIONAL` mode, and the specify blocks are ignored by both
simulators.  The Liberty numbers in the manifests are the only timing data, and they have not been run through STA.

## Vendor-model artefacts handled (and documented)
* IHP: the macro Verilog instantiates `SRAM_1P_behavioral_bm_bist`, which lives in a separate upstream file
  (`RM_IHPSG13_1P_core_behavioral_bm_bist.v`, fetched and pinned); simulate with `-DFUNCTIONAL`.
* GF180: (1) the model drops the first access to a macro unless CEN has changed once before (its 100 ps-delayed CEN copy stays X): the testbench
  pulses CEN once per macro row before the clock starts; (2) the model samples inputs 100 ps after the edge: the leaf has a simulation-only input delay
  (`SF_MACRO_VENDOR_INPUT_DELAY`).  Both found by the testbenches, neither is a silicon property (but see the hold-time note in 03).
* SKY130: the model prints for every access (the runner filters it) and uses arbitrary delays; the testbench clock period (20 ns) is chosen so the
  model's 3 ns read delay completes before the next edge.

## Honest limits
* One clock; no CDC.  Bounded simulation (4,000 random cycles per configuration by default), no formal proof of the wrapper.
* The testbench shares an author with the RTL; independence is provided by the Python golden ECC model, the vendor models, the earlier library's
  recorded data and mutation testing -- not by a second implementation of the wrapper.
* GENERIC/FPGA power model is an interface model only (03).
* No FPGA vendor-tool run, no board run, no gate-level simulation with standard cells.
