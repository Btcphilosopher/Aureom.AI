# 05 -- Commercial macros (130 / 65 / 28 nm) and adding a new macro

**Status: nothing to integrate.**  No foundry or IP-vendor memory-compiler output (Verilog model, Liberty per corner, LEF, GDS/OASIS,
datasheet) exists in this package or the repository, and none may be invented.  `MEMORY_TECH = ASIC_COMMERCIAL` is therefore rejected
(E06) and the earlier SRAM library's three `PENDING_NO_MACRO` placeholders stay pending.  Technology LEF/PDK templates for commercial
nodes in TimingLab/FloorplanLab are "template only".

## How a licensed macro would be added (no code change in the wrapper)

1. Obtain, under licence, the compiler outputs for the chosen configuration(s).  Do **not** commit them to a public repository.
2. Add the files to a private source tree and a private `tools/pins/vendor_sources.json` entry (repo/commit or local path, per-file SHA-256).
3. Add a family to `tools/families.py` stating, for each pin, its role, polarity and width relation (`pins`, `test_pins`, cycle encodings, mask
   granularity, latency, access edge, supplies, test hand-over rule, sleep/retention pins if any, ECC/redundancy/repair pins if any).  **Every
   pin in the Verilog model must be accounted for**: `build_manifest.py` fails on any uncovered pin, which is what forces a new test, sleep, ECC or
   repair pin to be handled instead of ignored.
4. Run `build_manifest.py`: pin widths, LEF/Liberty/Verilog consistency, polarity vs Liberty `when` conditions, datasheet cross-checks must pass.
5. Run `gen_rtl.py`: it generates the leaf adapter and the black-box stub.  A new family needs a template function in `gen_rtl.py` (about 60
   lines: the pin connections and any fabric test mux) and a `SF_MEM_TECH_ASIC_*` code in `rtl/sf_sram_macro_defs.svh`.
6. Run `scripts/run_sim.py --suite asic,equiv` with the vendor model: the equivalence runs against GENERIC must be trace-identical.
7. Macros with **built-in ECC**, **sleep/retention**, **redundancy/repair** or **test pins** change the manifest flags (`ecc.builtin`,
   `power.sleep_retention`, `redundancy`, `test.builtin_test_pins`); the wrapper then must map those pins instead of adding its own logic
   (rule E25 currently rejects built-in-ECC macros until such an adapter exists; E26 is lifted for macros with sleep pins and a leaf mapping).

## Honest limits
The wrapper's rejection of unsupported combinations is a feature: for example, a commercial compiler macro without a byte mask would be
rejected for byte-enable use (E23) instead of getting an unverified read-modify-write.
