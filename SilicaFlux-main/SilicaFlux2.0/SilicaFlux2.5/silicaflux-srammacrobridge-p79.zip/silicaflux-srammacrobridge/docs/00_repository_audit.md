# 00 -- Repository audit (what exists, what is real)

Audit of the SilicaFlux repository (`SilicaFlux-main/` and the project archives under `SilicaFlux2.0/SilicaFlux2.5/`) before any
design work.  Method: every relevant archive was extracted into an isolated scratch directory and read; nothing in the repository
was modified.

## Memory projects found

| Project | What it is | Relevance here |
|---|---|---|
| **SRAMCore (P71)** `silicaflux-sramcore` | `sf_sram_core` + `sf_sram_array`: single-port, always-accept SRAM, byte lanes, `READ_LATENCY`, bounds policy, INIT modes. | **Defines the logical contract** this package preserves. `sf_sram_array`'s ports (`clk, ce, we, wmask, idx, wdata, rdata`) and timing are the raw interface of `sf_sram_macro_wrapper`. Its docs say the ASIC path was "not exercised" and that no Liberty/LEF/macro existed. |
| **SRAMBank (P72)** | 2-64 bank subsystem built from `sf_sram_core`. | Consumer of the contract; not changed. |
| **SRAMController (P73), SRAMFabric (P74)** | Multi-master controller / DataFabric bridge over the banks. | Consumers; not changed. |
| **SRAM Wrapper Library** `silicaflux-sramlib` | Generic / FPGA / ASIC backends, **34 macro manifests** (SKY130 OpenRAM, GF180MCU, IHP SG13G2) with SHA-256 provenance, ASIC leaf adapters verified against the vendor Verilog models, MBIST demo controller, 3 commercial placeholders (`PENDING_NO_MACRO`). | Closest prior art. Its own status page lists the gaps this package closes: **no Liberty parsing, no LEF placement/halos/power pins, no ECC, macro BIST mux unused, OpenROAD unavailable**. Its recorded sizes/hashes are used here as an *independent cross-check* (79 file hashes matched, 0 mismatches). |
| **SRAMGRID (P33), MemoryCore** | Region/bank architecture and placement scripts using manifest dimensions. | MemoryCore's README states the repository has *no Liberty/LEF/GDS views* and OpenROAD was not run; its floorplan Tcl is headed "UNEXECUTED SCRIPT". |
| **ECCCore (P54)** | **NAND** BCH/LDPC engine. | **Not reusable for SRAM**: different code class and latency; no SRAM SECDED existed anywhere in the repository (grep for SECDED/Hsiao: only NAND-ECC documents). SRAM ECC is therefore implemented here. |
| **FloorplanLab (P05)** | OpenROAD-flow-scripts floorplanning on IHP SG13G2 with 12 IHP SRAM macros; real runs recorded. | Source of the method for manual macro placement through OpenDB (`setLocation` = lower-left of the oriented bbox, FIRM, hard errors for unknown instances) and of platform facts (IHP site 0.48 x 3.78 um, PG pin handling).  Reused as a *method*; its run evidence is not re-claimed. |
| **TimingFlow (P06) / TimingLab** | Yosys -> OpenSTA -> OpenROAD flows; PDK configs for sky130hd, ihp-sg13g2, gf180mcu; commercial 65/28 nm **templates only**. | Confirms the three open PDKs are the legal technologies; commercial nodes are "template only, no proprietary content". |
| **FPGAFlow** | *No project of this name exists in the repository.* FPGA evidence in the repo = Yosys inference in sramcore/sramlib and an Arty-A7 self-test top in sramlib (never run on a board). | FPGA backend here is inference-only, checked with Yosys; see 02. |

## Technologies and model availability (facts)

| Item | Present in the repository? |
|---|---|
| Vendor Verilog models of SRAM macros | **No** (only manifests describing them) |
| LEF / Liberty / GDS / SPICE of SRAM macros | **No** (only manifests + recorded SHA-256) |
| Any `.lef`/`.lib` at all | One *illustrative* generic 45 nm `.lib` (research folder), unrelated to any macro |
| Technology LEF / PDK files | No (platform profiles reference them) |
| OpenROAD / OpenSTA binaries | Not installed in the environment of the earlier projects, nor in this one |
| Commercial memory compiler output | **None** (no NDA material) |
| Legal open technologies | SKY130 (OpenRAM), GF180MCU, IHP SG13G2 |

## Consequence for this package

The real files **are** publicly fetchable at the commits the earlier manifests record (verified here: 209 files, 8.5 MB, hashes
pinned).  So the ASIC path is implemented against real, checked data -- but only for those three open families.  Everything else
(commercial 130/65/28 nm) stays `PENDING_NO_MACRO` (rule E06) as the brief demands: "Do not invent a technology cell name".
