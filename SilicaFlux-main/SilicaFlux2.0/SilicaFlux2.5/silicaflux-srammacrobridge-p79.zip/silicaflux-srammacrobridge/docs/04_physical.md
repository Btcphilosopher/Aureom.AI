# 04 -- Physical data, configuration generator and floorplan flow

## Data pipeline (real files only)

```
tools/fetch_vendor.py     vendor Verilog / LEF / Liberty / datasheet / spec CSV + technology LEFs (pinned commits, SHA-256 verified,
                          cross-checked against the hashes the earlier SRAM library recorded independently)
tools/lef_parse.py        macro LEF: SIZE, SYMMETRY, pins (edge, layer, bbox), PG pins (layer, stripe orientation), OBS per layer;
                          tech LEF: routing layers, SITE sizes
tools/lib_parse.py        Liberty: corner (process/temperature/voltage, voltage_map), setup/hold tables, clock-to-output arcs
                          (rising or falling edge), min period / pulse width, leakage, internal power, pg_pin; tolerant of
                          attributes without ';', buses, quoted/unquoted timing types
tools/vlog_ports.py       vendor Verilog model: module name, parameters, ports (widths evaluated)
tools/families.py         the ONLY hand-written macro knowledge (pin roles, polarity, mask granularity, latency, edge)
tools/build_manifest.py   verifies families.py against ALL of the above and writes manifests/*.json + catalog.json
```

`build_manifest.py` **fails** (exit 1) on any disagreement: a pin missing in Verilog/LEF/Liberty, a pin not covered by the family table (a
new test/sleep/ECC/repair pin), PG-pin names differing between LEF and Liberty, LEF area != Liberty area, datasheet/spec size != LEF, or
polarity contradicting the Liberty `when` power conditions.  Numeric vendor-document disagreements are recorded as **warnings** in the
manifest (`checks.warnings`) and in the readiness report, never hidden.

What a manifest holds (all derived from files; `views` give path, SHA-256 and the pinned upstream URL):
`organization` (words, bits, ports), `semantics` (latency, access edge, hold behaviour, mask, enables, constraints), `test`, `ecc`, `redundancy`,
`power`, `geometry` (size, symmetry, **legal orientations**, PG pins, signal pins, OBS, blocked / free routing layers, sites), `timing` (every
Liberty corner: voltage, temperature, process, setup/hold per pin, clock-to-output, min period/pulse width, leakage), `checks`, `readiness`.

Geometry facts worth knowing (from the LEFs): all IHP and GF180 signal pins are on the **south edge** (Metal2); SKY130 pins are on **all four
edges** (met3/met4); macro PG is vertical Metal4 stripes (IHP, SKY130 met4+met3 rings) or horizontal Metal3 edge pins (GF180); `OBS` blocks Metal1-4
(IHP), met1-4 (SKY130), Metal1-3 + vias (GF180); legal over-macro routing is the stack **above** the highest used layer (IHP: Metal5, TopMetal1/2;
SKY130: met5; GF180: Metal4, Metal5).  Technology LEF = the ORFS platform file at a pinned commit (`sg13g2_tech.lef`, `sky130_fd_sc_hd.tlef`,
`gf180mcu_5LM_1TM_9K_9t_tech.lef`): it is the *platform's* layer stack, not macro-specific; for GF180 the 5LM/9-track variant is an assumption.

## Configuration generator -- `tools/sram_cfg_gen.py`

```
python3 -I tools/sram_cfg_gen.py plan  --width 128 --words 4096 --lane-bits 32 --ecc lane --read-latency 2 --test --tech ihp
python3 -I tools/sram_cfg_gen.py check --tech sky130 --macro-id 23 --width 36 --words 512 --lane-bits 9        # -> 24 ...
python3 -I tools/sram_cfg_gen.py emit  --name my_mem --tech ihp --width ... --out configs/generated            # plan + params + synth top
```

For every catalogued macro it applies the same rejection rules as the RTL and, if feasible, reports: tiling (rows x columns, instances), logical
capacity, physical stored bits, **ECC overhead**, macro bits and **unused capacity**, macro area, halo-expanded footprint and grid bounding box,
**interface adaptation** (polarity inversions, mask conversion, tie-offs, test path, padding, row decode, extra pipeline, ECC), and a **macro-only
timing lower bound** per Liberty corner (a falling-edge macro needs twice the access time per period; `--logic-delay-ns` adds your decode/mux
estimate).  It is **not STA**: no wires, skew, flop setup, or logic.  Requests no macro can implement return `CANNOT_IMPLEMENT_WITH_CATALOGUED_MACROS`
with the rejection code and the list of macros it applies to (e.g. 9-bit lanes on SKY130 -> E24; sleep -> E26 for all 25).  Mixed-macro tilings
(which would waste less) are not implemented in the RTL, so the generator does not offer them.

## Floorplan flow

```
python3 -I tools/synth_instances.py --plan P.plan.json --top P.top.sv --out physical/P       # Yosys: REAL flattened instance names
python3 -I tools/gen_floorplan.py   --plan P.plan.json --instances physical/P/instances.json --out physical/P [--halo 10 ...]
python3 -I tools/check_floorplan.py physical/P                                               # mock OpenDB + independent geometry checks
python3 -I scripts/make_plans.py                                                             # all of the above for configs/reference_configs.json
```

Outputs per plan: `floorplan.json` (die/core/site, placements, halos, PG nets with LEF names and layers, routing layers, corners, assumptions,
warnings), `floorplan.tcl` (`initialize_floorplan`), `macro_place.tcl` (OpenDB manual placement, **FIRM**, halo blockages, hard errors for unknown
instances / wrong masters / unplaced macros), `check_macros.tcl`, `pdn_connect.tcl` (`add_global_connection` by the **real LEF pin names**; macro
PDN commands only as an explicitly UNVERIFIED comment), `load_design.tcl` (read_lef/liberty/verilog/link with `$SF_*` variables), `README.md`.

* Instance names look like `u_sram.g_asic.u_be.g_row[0].g_col[1].g_ihp.u_leaf.g_ihp_1p_2048x32.u_macro` and come from Yosys `flatten`;
  the Tcl matches names with backslashes removed (OpenDB escapes `[ ]`), as FloorplanLab does.
* Placement: tiles in rows/columns; macro positions snap to the placement **site** grid from the tech/std-cell LEF (IHP `CoreSite` 0.48 x 3.78 um;
  GF180 `GF018hv5v_green_sc9` 0.56 x 5.04; SKY130 `unithd` 0.46 x 2.72); coordinates are on the 0.005 um manufacturing grid; orientations are
  limited to those legal under the LEF `SYMMETRY` (R0/MX/MY/R180; rotated ones are excluded because PG stripes are unidirectional); with
  `--pin-facing pairs` the lower row of each pair is oriented so its pin edge faces the shared channel (GF180: MX / R0).
* **IHP supply tie**: `VDDARRAY!` is tied to the core `VDD` net only because the Liberty `voltage_map` gives it the same voltage as `VDD` in all
  three corners (checked, recorded in `floorplan.json`).  If they ever differed, the generator stops with `PHYSICAL_INCOMPLETE`.
* **Assumptions (options, recorded under `assumptions`)**: halo (default 10 um; **no vendor halo rule was found**), channel, pin channel, die
  margin, pin-facing policy, wrapper-logic area (default 0: not included), core voltage.

### What was and was not executed
`check_floorplan.py` runs the generated Tcl under `tclsh` against a **mock OpenDB** (`physical/mock_odb.tcl`: instances/masters of the netlist, the
OpenDB methods the Tcl uses) and compares the result with `floorplan.json`, then re-checks bounds, overlaps, halo spacing, site/manufacturing-grid
alignment, orientation legality, instance names, masters, LEF dimensions and PG pin names; the unit tests show that a corrupted floorplan
(overlap, outside core, wrong master/instance/PG name, illegal orientation, Tcl disagreeing with the JSON) is rejected.
**OpenROAD itself was not run** (no binary available; attempting to install one was not permitted in the generating session), so
option names and OpenDB behaviour are *standard but unverified*.  Run in your OpenROAD build, in this order:
`load_design.tcl -> floorplan.tcl -> macro_place.tcl -> check_macros.tcl -> pdn_connect.tcl`, and read the log for `SF-MACRO` / `SF-CHECK` lines.

### Timing and STA hand-off
Use each manifest's per-corner Liberty (`views.liberty.<corner>`) in OpenSTA together with your std-cell corner at the same voltage/temperature
(`floorplan.json corners`).  Expect (nominal corner, from the manifests; clock-to-output = min..max over the Liberty tables): IHP 2.9-5.6 ns depending on macro size, no
published min period; GF180 6.2-8.1 ns at 3.3 V (published min period 8.26-9.24 ns); SKY130 0.34-0.53 ns launched on the **falling** edge
(published min period 1.79-1.96 ns).  Macro control hold times far exceed a flop's clk-to-q (GF180 ~2 ns
nominal): plan for hold-fix buffers.  The wrapper's ECC decode sits between the macro output and the output register (latency >= 2) or
before the consumer (latency 1): that path is the first thing to look at in STA.
