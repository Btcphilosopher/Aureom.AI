# 01 -- Interface and semantics (normative)

`sf_sram_macro_wrapper` presents the SRAMCore raw contract in front of three interchangeable physical backends.  Cycle *t* is the
cycle in which inputs are presented; they are sampled at the rising edge that ends it.

## Ports

| Port | Dir | Width | Meaning |
|---|---|---|---|
| `clk` | in | 1 | the only clock (data path, hand-over and power logic) |
| `ce`, `we` | in | 1 | `ce=0` idle; `ce=1` one access, `we=1` write / `we=0` read.  Always accepted, no `ready`. |
| `wmask` | in | `LANES` | lane enables when `BYTE_ENABLE=1`; with `BYTE_ENABLE=0` it is 1 bit and ignored (tie to 1) |
| `idx` | in | `clog2(DEPTH_WORDS)` | word index, must be `< DEPTH_WORDS` (simulation assertion `SF_MACRO_ASSERT_OOB`) |
| `wdata` / `rdata` | in/out | `DATA_WIDTH` | write / read data (ECC bits are internal) |
| `rd_vld` | out | 1 | 1 in the read slot of an accepted read |
| `ecc_corrected`, `ecc_uncorrectable` | out | 1 | with `rd_vld`; see 03 |
| `tst_active`, `tst_ce`, `tst_we`, `tst_idx`, `tst_wdata` | in | 1,1,1,idx,`PHYS_WIDTH` | MBIST port (`TEST_MODE=1`), **raw physical word** |
| `tst_rdata`, `tst_rd_vld` | out | `PHYS_WIDTH`, 1 | raw read data / slot |
| `pwr_sleep` / `pwr_active` | in / out | 1 | logical sleep model (`POWER_CTRL=1`, GENERIC/FPGA only) |

There is no reset: valid pipelines are plain delay lines (meaningful after `READ_LATENCY` clocks with `ce` driven to a defined value),
exactly like the SRAMCore array.  Power-up array content is undefined; with ECC an unwritten word may report errors: initialise by writing.

## Timing

| Event | Rule |
|---|---|
| Read presented in cycle *t* | `rd_vld=1` and `rdata` valid in cycle *t*+`READ_LATENCY`, for that one cycle; **never held** |
| Write presented in cycle *t* | array updated at the edge ending *t*; every read presented in a cycle >= *t*+1 observes it; a read in cycle *t*-1 returns the old word |
| Throughput | one access per cycle, any mix |
| `READ_LATENCY >= 2` | decode, then `READ_LATENCY-1` unreset register stages (a vendor tool may merge them into a RAM output register) |
| Native latency | 1 for every catalogued macro; `READ_LATENCY` below it is rejected (E27) |

### Tests that enforce it
Exact-latency scoreboard every cycle (`rd_vld` must equal the expected slot in both directions), poison check (`SF_MACRO_POISON`: `rdata`
must be X outside the slot -- output is not held), byte-enable exhaustive masks, write-after-read / read-after-write hazards, response-trace
equality between backends.  See 06.

## Parameters and rejection rules

Every illegal combination fails elaboration with **one** message (the first violated rule, `ERR_CODE`), in Verilator, Icarus and Yosys.
`tools/sram_cfg_gen.py err_code()` implements the same rules; `scripts/run_sim.py --suite agree` proves they agree on 326 configurations.

| Parameter | Default | Meaning |
|---|---|---|
| `DATA_WIDTH` | 32 | data bits (1..1024) |
| `DEPTH_WORDS` | 1024 | words (2..2^30), any value |
| `READ_LATENCY` | 1 | 1..16 |
| `BYTE_ENABLE`, `BYTE_WIDTH` | 1, 8 | per-lane write enables; lane width (`DATA_WIDTH` must be a multiple) |
| `MEMORY_TECH` | GENERIC | `GENERIC`, `FPGA`, `ASIC_IHP_SG13G2`, `ASIC_GF180MCU`, `ASIC_SKY130_OPENRAM`, (`ASIC_COMMERCIAL` always rejected) |
| `MACRO_ID` | 0 | catalogue entry (`rtl/sf_sram_macro_ids.svh`); ASIC only; chosen by `tools/sram_cfg_gen.py` |
| `ECC_MODE` | NONE | `NONE`, `SECDED_WORD` (needs `BYTE_ENABLE=0`), `SECDED_LANE` (needs `BYTE_ENABLE=1`) |
| `TEST_MODE`, `POWER_CTRL`, `WAKE_CYCLES` | 0, 0, 2 | MBIST port / sleep model / wake latency |
| `INIT_MODE`, `INIT_FILE` | NONE | GENERIC/FPGA only (`ZERO`/`FILE`/`PATTERN`); ASIC macros have no initial content |
| `FPGA_RAM_STYLE` | AUTO | attribute hint: `BLOCK`, `ULTRA`, `DISTRIBUTED` |

| Code | Rejected because |
|---|---|
| E01-E05 | width/depth/latency out of range; `BYTE_ENABLE` invalid; `DATA_WIDTH` not a multiple of `BYTE_WIDTH` |
| E06 | `ASIC_COMMERCIAL`: no qualified macro files exist |
| E07 | unknown `MEMORY_TECH` |
| E08-E11 | ECC mode invalid; **word ECC + byte enables** (needs read-modify-write the always-accept interface cannot stall for); **lane ECC without byte enables**; granule > 502 bits |
| E12-E14 | `TEST_MODE`/`POWER_CTRL` invalid; `WAKE_CYCLES` outside 1..8 |
| E15-E17 | `INIT_MODE` invalid; `FILE` without file; `PATTERN` under `SYNTHESIS` |
| E18-E19 | bad `FPGA_RAM_STYLE`; `MACRO_ID` on a non-ASIC technology |
| E20 | ASIC with `INIT_MODE != NONE` (macros power up undefined) |
| E21-E22 | unknown `MACRO_ID`; macro family differs from `MEMORY_TECH` |
| E23 | macro without a write mask + byte enables (an external read-modify-write cannot be stalled for) -- *data-driven; no catalogued macro triggers it* |
| E24 | stored lane width (data+ECC) not a multiple of the macro's mask granularity (SKY130: 8 bits) |
| E25 | built-in-ECC macro (not supported; none exists) -- *data-driven* |
| E26 | `POWER_CTRL=1` on a macro without sleep/retention pins (**all** catalogued macros) |
| E27 | `READ_LATENCY` below the macro's native latency -- *data-driven; all macros have latency 1* |
| E28 | more than 1024 macro instances |

E23, E25 and E27 depend on catalogue data the open macros do not have; they are exercised with synthetic catalogue entries in
`tests/test_generator.py`, not by an RTL run.

### Read-modify-write: implemented or rejected?
**Rejected, deliberately.**  The contract accepts one access per cycle with no stall.  A correct RMW needs a read, a modify and a
write, i.e. a stall or a hazard-forwarding buffer.  The two places RMW would be needed are (a) word-granule ECC with partial writes and
(b) a macro without a write mask.  (a) is replaced by *lane-granule ECC*, which never needs RMW; (b) does not occur in the catalogue
(every open macro has a bit or byte mask) and is rejected by rule E23 should a future macro lack one.
