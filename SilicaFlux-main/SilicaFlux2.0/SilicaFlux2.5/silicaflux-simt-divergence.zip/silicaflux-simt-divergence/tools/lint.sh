#!/usr/bin/env bash
# Verilator -Wall lint of the synthesisable RTL in several configurations.
set -euo pipefail
cd "$(dirname "$0")/.."
SRC="rtl/sfd_decode.sv rtl/sfd_alu.sv rtl/sfd_simt_stack.sv rtl/sfd_regfile.sv rtl/sfd_ram.sv rtl/sfd_lsu.sv rtl/sfd_core.sv"
status=0
for P in "-GLANES=8 -GWARPS=4 -GDEPTH=8" "-GLANES=4 -GWARPS=2 -GDEPTH=7 -GPRED_EN=0" \
         "-GLANES=16 -GWARPS=3 -GDEPTH=31" "-GLANES=8 -GWARPS=1 -GDEPTH=1"; do
  if out=$(verilator --lint-only -Wall -Irtl --top-module sfd_core $P $SRC 2>&1); then
    echo "lint clean: $P"
  else
    echo "lint FAILED: $P"; echo "$out"; status=1
  fi
done
exit $status
