#!/usr/bin/env python3
"""RTL mutation testing: does the verification catch realistic divergence bugs?

Each mutant is one textual change to a copy of rtl/.  The kill suite is the
directed tests, a handful of random structured kernels and three workloads, all
run with assertions enabled and compared exactly against the reference model.
A mutant is *killed* by the first failing check; the report says which test and
whether an RTL assertion or the model comparison caught it.
"""
import os
import shutil
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "model"))
sys.path.insert(0, os.path.join(HERE, "..", "tests"))
from directed import TESTS  # noqa: E402
from sfdiv import asm, gen, isa, kc, machine, rtl, workloads  # noqa: E402

MUTANTS = [
    ("M01", "sfd_simt_stack.sv", "wA = 1'b1; dA = {pc1, cmd_reconv, n_m};\n                wB = 1'b1; dB = {cmd_target, cmd_reconv, t_m};",
     "wA = 1'b1; dA = {cmd_target, cmd_reconv, t_m};\n                wB = 1'b1; dB = {pc1, cmd_reconv, n_m};",
     "path order swapped (fall-through runs first; deviates from the reference order)"),
    ("M02", "sfd_simt_stack.sv", "reuse    = (top_rpc == cmd_reconv);", "reuse    = 1'b0;",
     "reuse disabled: every divergence pushes a new reconvergence entry"),
    ("M03", "sfd_simt_stack.sv", "assign needs_pop = !empty && ((top_pc == top_rpc) || (active == '0));",
     "assign needs_pop = !empty && (top_pc == top_rpc);", "entries without live lanes are not dropped"),
    ("M04", "sfd_simt_stack.sv", "br_ovf   = br_div && (sp_after > (SPW+2)'(DEPTH));",
     "br_ovf   = br_div && (sp_after >= (SPW+2)'(DEPTH));", "overflow check off by one (false overflow at capacity)"),
    ("M05", "sfd_simt_stack.sv", "br_ovf   = br_div && (sp_after > (SPW+2)'(DEPTH));",
     "br_ovf   = br_div && (sp_after > (SPW+2)'(DEPTH + 1));", "overflow check off by one (writes past the last entry)"),
    ("M06", "sfd_core.sv", "assign x_ex     = x_in_win ? (x_act & pmask[x_warp]) : x_act;",
     "assign x_ex     = x_act;", "predication window ignores the predicate (side effects in predicated-off lanes)"),
    ("M07", "sfd_simt_stack.sv", "assign active    = top_mask & live_q;", "assign active    = top_mask;",
     "active mask ignores the live mask (exited lanes keep executing)"),
    ("M08", "sfd_lsu.sv", "        rem     <= req_mask;", "        rem     <= '1;",
     "LSU performs every lane, including inactive ones"),
    ("M09", "sfd_lsu.sv", "assign lane      = LW'(lowbit32({{(32-LANES){1'b0}}, rem}));",
     "logic [LW-1:0] lane_hi;\n  always_comb begin lane_hi = '0; for (int i = 0; i < LANES; i++) if (rem[i]) lane_hi = LW'(i); end\n  assign lane = lane_hi;",
     "LSU performs lanes in descending order"),
    ("M10", "sfd_core.sv", "((bar_wait | w_empty) == {WARPS{1'b1}})", "(bar_wait == {WARPS{1'b1}})",
     "barrier waits for warps that are already done (deadlock after exits)"),
    ("M11", "sfd_core.sv", "((bar_wait | w_empty) == {WARPS{1'b1}})", "(bar_wait != '0)",
     "barrier releases as soon as one warp arrives"),
    ("M12", "sfd_core.sv", "C_BAR:    if (x_act != x_live)", "C_BAR:    if (1'b0)",
     "no divergent-barrier check"),
    ("M13", "sfd_core.sv", "end else if (x_rpc != RPC_NONE && x_pc > x_rpc) begin", "end else if (1'b0) begin",
     "no F_RECONV check (a path may run past its reconvergence point)"),
    ("M14", "sfd_core.sv", "cond[l]     = d_pol_z ? rs1_zero[l] : !rs1_zero[l];",
     "cond[l]     = d_pol_z ? !rs1_zero[l] : rs1_zero[l];", "branch / predicate polarity inverted"),
    ("M15", "sfd_core.sv", "pcount[x_warp] <= pcount[x_warp] - 5'd1;", "pcount[x_warp] <= pcount[x_warp];",
     "predication window never closes"),
    ("M16", "sfd_core.sv", "cmd_mask   = (d_cls == C_EXIT) ? x_act : cond;", "cmd_mask   = (d_cls == C_EXIT) ? x_live : cond;",
     "exit retires every live lane, not just the active ones"),
    ("M17", "sfd_core.sv", "assign wa_en   = (x_commit && d_rd_we && !is_mem && d_rd != 4'd0) ? x_ex : '0;",
     "assign wa_en   = (x_commit && d_rd_we && !is_mem && d_rd != 4'd0) ? {LANES{1'b1}} : '0;",
     "register write ignores the execution mask"),
    ("M18", "sfd_simt_stack.sv", "wT = 1'b1; dT = {cmd_reconv, top_rpc, top_mask};\n              if (need_f && need_t) begin",
     "wT = 1'b0; dT = {cmd_reconv, top_rpc, top_mask};\n              if (need_f && need_t) begin",
     "top entry not turned into the reconvergence entry"),
    ("M19", "sfd_core.sv", "C_PRED:   if (x_rpc != RPC_NONE && win_end >= {{(32-PW){1'b0}}, x_rpc}) begin",
     "C_PRED:   if (1'b0) begin", "no check that a window ends before the reconvergence point"),
    ("M20", "sfd_lsu.sv", "m_wdata = q + cur_wdata;", "m_wdata = cur_wdata;", "atomic add stores the addend only"),
    ("M21", "sfd_core.sv", "assign elig[gw] = run && !inflight[gw] && !w_empty[gw] && !w_needs_pop[gw] && !bar_wait[gw];",
     "assign elig[gw] = run && !w_empty[gw] && !w_needs_pop[gw] && !bar_wait[gw];",
     "scheduler may issue a warp that already has an instruction in flight"),
    ("M22", "sfd_core.sv", "init_mask[gw][l] = (32'(gw * LANES + l) < l_wg_dim);", "init_mask[gw][l] = 1'b1;",
     "launch ignores wg_dim (threads that do not exist run)"),
    ("M23", "sfd_simt_stack.sv", "assign pop_fire  = needs_pop && !cmd_valid && !init_valid;",
     "assign pop_fire  = needs_pop && !cmd_valid && !init_valid && (top_pc == top_rpc);",
     "pop trace / counter misses dead-entry pops"),
    ("M24", "sfd_core.sv", "else if (x_commit && d_cls == C_BAR) bar_wait[x_warp] <= 1'b1;",
     "else if (1'b0) bar_wait[x_warp] <= 1'b1;", "barrier is a no-op"),
]


def kill_suite():
    """(name, cfg, launch, wdog, expect_fault) in increasing cost order."""
    out = []
    for t in TESTS:
        p = asm.assemble(t.src, t.name)
        out.append((t.name, t.config(), machine.Launch(p.words, wg_dim=t.wg_dim, args=t.args, gmem=t.gmem),
                    t.wdog or 20000, t.fault))
    for name in ("reduce_smem", "loop_break_in_if_k3", "exit_barrier_k4"):
        w = workloads.by_name(name)
        k = kc.compile_kernel(name, w.body)
        out.append((name, isa.Config(), machine.Launch(k.words, wg_dim=w.wg_dim, gmem=w.gmem), 50000, None))
    for seed in range(3):
        for cfg in (isa.Config(lanes=8, warps=4, depth=8), isa.Config(lanes=4, warps=2, depth=3)):
            g = gen.random_kernel(1000 + seed, cfg.lanes, cfg.warps)
            k = kc.compile_kernel(f"rnd{seed}", g.body, lanes=cfg.lanes)
            out.append((f"random{seed}_L{cfg.lanes}D{cfg.depth}", cfg,
                        machine.Launch(k.words, wg_dim=g.wg_dim, gmem=g.gmem, args=[seed * 7 + 1]), 200000, "any"))
    return out


def run_mutant(mid, fname, old, new, suite, base):
    d = os.path.join(base, mid)
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(os.path.join(rtl.ROOT, "rtl"), os.path.join(d, "rtl"))
    p = os.path.join(d, "rtl", fname)
    s = open(p).read()
    if s.count(old) < 1:
        return ("ERROR", f"pattern not found in {fname}")
    open(p, "w").write(s.replace(old, new, 1))
    vvps = {}
    for name, cfg, launch, wdog, expect in suite:
        key = (cfg.lanes, cfg.warps, cfg.depth, cfg.pred_en)
        try:
            if key not in vvps:
                vvps[key] = rtl.build(cfg, build_dir=os.path.join(d, "build"), rtl_dir=os.path.join(d, "rtl"))
            r = rtl.run(cfg, launch, os.path.join(d, "run", name), vvp=vvps[key], wdog=wdog, maxcyc=300000)
        except AssertionError as e:
            msg = str(e)
            tag = next((ln.strip() for ln in msg.splitlines() if "SFD-ASSERT" in ln), "simulator failure")
            return ("killed", f"{name}: assertion {tag}")
        except RuntimeError as e:
            return ("killed", f"{name}: build error {str(e)[:120]}")
        errs = rtl.compare(cfg, launch, r)
        if expect is None and r.fault is not None:
            errs.append(f"unexpected fault {r.fault.name}")
        if isinstance(expect, int) and (r.fault is None or r.fault.code != expect):
            errs.append(f"expected {isa.FAULT_NAMES[expect]}, got {r.fault.name if r.fault else 'no fault'}")
        if errs:
            return ("killed", f"{name}: comparison: {errs[0][:150]}")
    return ("SURVIVED", "")


def main():
    base = os.path.join(rtl.ROOT, "build", "mutants")
    suite = kill_suite()
    t0 = time.time()
    rows = []
    for mid, fname, old, new, desc in MUTANTS:
        st, why = run_mutant(mid, fname, old, new, suite, base)
        rows.append((mid, desc, st, why))
        print(f"{mid} {st:9s} {desc}\n     {why}", flush=True)
    killed = sum(1 for r in rows if r[2] == "killed")
    print(f"\n{killed}/{len(rows)} mutants killed ({time.time() - t0:.0f}s)")
    with open(os.path.join(rtl.ROOT, "results", "mutation.md"), "w") as f:
        f.write("# RTL mutation testing\n\nGenerated by `tools/mutate.py`. Each mutant is one change to a copy of "
                "`rtl/`; the kill suite is the directed tests, three workloads and six random kernels, with "
                "assertions on and exact comparison against the reference model.\n\n")
        f.write("| id | injected bug | result | first detection |\n|---|---|---|---|\n")
        for mid, desc, st, why in rows:
            f.write(f"| {mid} | {desc} | {st} | {why.replace('|', '/')} |\n")
        f.write(f"\n**{killed}/{len(rows)} mutants killed.**\n")
    sys.exit(0 if killed == len(rows) else 1)


if __name__ == "__main__":
    main()
