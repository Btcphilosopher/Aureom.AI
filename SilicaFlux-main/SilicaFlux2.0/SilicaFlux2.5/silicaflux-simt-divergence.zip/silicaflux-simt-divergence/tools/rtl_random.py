#!/usr/bin/env python3
"""Differential regression: random structured kernels on the RTL vs the reference model vs the oracle.

For each (configuration, seed): compile the kernel (branch lowering and, when the
configuration has SFX-PRED, the predicated lowering), run it on the RTL, replay
the RTL's warp order on the model and require an exact match; then require the
per-thread oracle to agree with both (registers of every thread, all memory).
"""
import argparse
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "model"))
from sfdiv import gen, isa, kc, machine, oracle, rtl  # noqa: E402

CONFIGS = {
    "L8W4D8":   isa.Config(lanes=8, warps=4, depth=8),
    "L4W2D7":   isa.Config(lanes=4, warps=2, depth=7),
    "L16W2D31": isa.Config(lanes=16, warps=2, depth=31),
    "L8W1D15":  isa.Config(lanes=8, warps=1, depth=15),
    "L8W3D15n": isa.Config(lanes=8, warps=3, depth=15, pred_en=False),
    "L8W4D3":   isa.Config(lanes=8, warps=4, depth=3),      # small stack: precise overflow faults expected
}


def one(cfg, seed, workdir, variants):
    g = gen.random_kernel(seed, cfg.lanes, cfg.warps)
    out = []
    ref_mem = None
    for pred in variants:
        if pred and not cfg.pred_en:
            continue
        k = kc.compile_kernel(f"rnd{seed}{'p' if pred else ''}", g.body, predicate=pred, lanes=cfg.lanes)
        launch = machine.Launch(k.words, wg_dim=g.wg_dim, gmem=g.gmem, args=[seed * 7 + 1])
        r = rtl.run(cfg, launch, os.path.join(workdir, f"s{seed}{'p' if pred else 'b'}"))
        errs = rtl.compare(cfg, launch, r)
        o = oracle.run_oracle(cfg, launch)
        if r.fault is not None:
            # only legitimate fault for random kernels: overflow on a small stack
            if r.fault.code != isa.F_STACK_OVERFLOW or cfg.depth >= cfg.safe_depth:
                errs.append(f"unexpected fault {r.fault}")
        else:
            if r.gmem != o.gmem or r.smem != o.smem:
                errs.append("oracle memory mismatch")
            for t in range(g.wg_dim):
                rr = r.regs[t // cfg.lanes][t % cfg.lanes]
                lim = 11 if pred else 16
                if rr[:lim] != o.regs[t][:lim]:
                    errs.append(f"oracle register mismatch thread {t}")
                    break
            if ref_mem is None:
                ref_mem = (r.gmem, r.smem)
            elif ref_mem != (r.gmem, r.smem):
                errs.append("branch and predicated variants disagree")
        out.append((pred, r, errs, k))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=40)
    ap.add_argument("--start", type=int, default=0)
    ap.add_argument("--configs", default=",".join(CONFIGS))
    ap.add_argument("--workdir", default=os.path.join(rtl.ROOT, "build", "random"))
    a = ap.parse_args()
    t0 = time.time()
    total = fails = faults = 0
    for name in a.configs.split(","):
        cfg = CONFIGS[name]
        rtl.build(cfg)
        n_ok = 0
        for seed in range(a.start, a.start + a.seeds):
            for pred, r, errs, k in one(cfg, seed, os.path.join(a.workdir, name), (False, True)):
                total += 1
                faults += r.fault is not None
                if errs:
                    fails += 1
                    print(f"FAIL {name} seed {seed} {'pred' if pred else 'branch'}:")
                    for e in errs[:6]:
                        print("   ", e)
                else:
                    n_ok += 1
        print(f"{name}: {n_ok} runs match", flush=True)
    print(f"total {total} runs, {fails} failures, {faults} precise overflow faults (small stacks, compared exactly), "
          f"{time.time() - t0:.0f}s")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
