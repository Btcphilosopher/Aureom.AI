#!/usr/bin/env python3
"""Cross-check against the existing SilicaFlux SF-G1 reference model (silicaflux-sf-g1).

Runs the same binaries (branch lowering: plain SF-G1 instructions, no SFX-PRED) on the
SF-G1 device model through its host API, and compares global memory with this
package's reference model.  This checks that the divergence core implements the
SF-G1 ISA and reconvergence semantics, not merely something self-consistent.

usage: tools/xcheck_sfg1.py --sfg1 /path/to/silicaflux-sf-g1   (the tree inside silicaflux-sf-g1.zip)
"""
import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "model"))
sys.path.insert(0, os.path.join(HERE, "..", "tests"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sfg1", required=True, help="root of the silicaflux-sf-g1 tree")
    ap.add_argument("--random", type=int, default=150)
    a = ap.parse_args()
    sys.path.insert(0, os.path.join(os.path.abspath(a.sfg1), "sim"))
    from sfg1 import host as sfhost          # noqa: E402  (SF-G1's own model)
    from sfg1.spec import Config as SfConfig  # noqa: E402
    from directed import TESTS               # noqa: E402
    from sfdiv import asm, gen, isa, kc, machine, workloads  # noqa: E402

    cfg = isa.Config(lanes=8, warps=4, depth=16)        # SF-G1 default: 8 lanes, 4 warps/EG, depth 16
    sfcfg = SfConfig.default()
    REGION = cfg.gmem_words                             # compare the first 16 KiB of global memory

    def run_both(name, words, wg_dim, gmem, args):
        m = machine.run(cfg, machine.Launch(words, wg_dim=wg_dim, gmem=gmem, args=args))
        h = sfhost.open_local(sfcfg)
        h._next = 0x40000                               # code and descriptor far from the data region
        init = [0] * REGION
        for k, v in (gmem or {}).items():
            init[k] = v
        h.write_words(0, init)                          # SF-G1 poisons memory at power-up
        k = h.load_kernel(words)
        r = h.launch(k, grid=1, wg=wg_dim, shared=cfg.smem_words * 4, args=list(args) + [0] * (8 - len(args)),
                     flags=1)                           # SMEM_ZERO (this core's shared memory starts at 0)
        if m.fault is not None or r.status != "done":
            same = (m.fault is not None and r.status == "fault" and
                    isa.FAULT_NAMES[m.fault.code] == r.error and m.fault.pc == r.fault["PC"] and
                    m.fault.data == r.fault["DATA"])
            return same, f"model={m.fault} sfg1={r.status}/{r.error}/{r.fault}"
        got = h.read_words(0, REGION)
        if got != m.gmem:
            d = next(i for i in range(REGION) if got[i] != m.gmem[i])
            return False, f"gmem word {d:#x}: model={m.gmem[d]:#x} sfg1={got[d]:#x}"
        # SIMT efficiency must agree as well: same warp instructions, same lane-ops
        if r.issued != m.issued or r.lane_ops != sum(isa.popcount(c.exec_mask) for c in m.trace):
            return False, f"issue counts differ: model {m.issued} vs sfg1 {r.issued}"
        return True, f"issued={m.issued}"

    total = bad = 0
    for t in TESTS:
        if t.cfg or t.fault == isa.F_WATCHDOG or "pred" in t.name:
            continue                                     # non-default stack sizes, watchdog, SFX-PRED
        p = asm.assemble(t.src, t.name)
        ok, msg = run_both(t.name, p.words, t.wg_dim, t.gmem, t.args)
        total += 1
        bad += not ok
        print(f"{'ok  ' if ok else 'FAIL'} directed {t.name:26s} {msg}")
    for w in workloads.suite():
        k = kc.compile_kernel(w.name, w.body)
        ok, msg = run_both(w.name, k.words, w.wg_dim, w.gmem, w.args)
        total += 1
        bad += not ok
        print(f"{'ok  ' if ok else 'FAIL'} workload {w.name:26s} {msg}")
    for seed in range(a.random):
        g = gen.random_kernel(seed)
        k = kc.compile_kernel(f"r{seed}", g.body)
        ok, msg = run_both(f"random{seed}", k.words, g.wg_dim, g.gmem, [seed * 7 + 1])
        total += 1
        bad += not ok
        if not ok:
            print(f"FAIL random {seed}: {msg}")
    print(f"\nSF-G1 cross-check: {total - bad}/{total} kernels agree (global memory, fault records, issue counts)")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
