#!/usr/bin/env python3
"""Evaluation: run every workload on the RTL (branch lowering and, where legal, predicated
lowering), verify each run, and tabulate utilisation, control overhead, stack occupancy and
completion cycles.

Every number in results/EVALUATION.md comes from an RTL run that was first checked:
  * exact lock-step match with the reference model (commits, memory order, final state,
    hardware counters),
  * per-thread oracle agreement (registers of every thread, all memory),
  * for predicated variants: identical memory and program-visible registers (r1..r10)
    to the branch variant (the equivalence that makes the comparison legitimate).
"""
import argparse
import csv
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "model"))
from sfdiv import isa, kc, machine, oracle, rtl, workloads  # noqa: E402

CONFIGS = {
    "L8W4D8": isa.Config(lanes=8, warps=4, depth=8),
    "L8W1D8": isa.Config(lanes=8, warps=1, depth=8),
    "L16W2D8": isa.Config(lanes=16, warps=2, depth=8),
}


def metrics(cfg, r: rtl.RtlResult, k: kc.CompiledKernel):
    p = r.perf
    L = cfg.lanes
    issued = p["issued"]
    setup = 0
    for c in r.commits:
        d = isa.decode(c.word)
        if d.cls == isa.ALU and d.rd >= kc.PRED_TMP and k.predicated:
            setup += 1
    ctrl = p["ctrl"]
    return dict(
        cycles=p["cycles"], issued=issued,
        util=p["lane_slots"] / (issued * L) if issued else 0.0,
        live_util=p["lane_slots"] / p["live_slots"] if p["live_slots"] else 0.0,
        lane_slots=p["lane_slots"], ctrl=ctrl, pred_setup=setup,
        overhead=(ctrl + setup) / issued if issued else 0.0,
        branches=p["branch"], diverge=p["diverge"], push=p["push"],
        pops=p["pop_r"] + p["pop_x"], pop_r=p["pop_r"], pop_x=p["pop_x"], pop_stall=p["pop_stall"],
        sp_max=p["sp_max"], sp_mean=p["sp_sum"] / issued if issued else 0.0,
        pred_insn=p["pred_insn"], pred_off=p["pred_off"], idle=p["idle"], stall=p["stall"],
        lsu_busy=p["lsu_busy"], mem_lanes=p["mem_lanes"], bar_wait=p["bar_wait"],
        static_bound=k.static_bound(L), code_words=len(k.words),
    )


def run_one(cfg, cname, w, variant, workdir):
    k = kc.compile_kernel(w.name, w.body, predicate=(variant == "pred"), lanes=cfg.lanes)
    conv = [c for c in k.conversions]
    if variant == "pred" and not any(c.converted for c in conv):
        return None, k
    wg = min(w.wg_dim, cfg.lanes * cfg.warps)
    L = machine.Launch(k.words, wg_dim=wg, gmem=w.gmem, args=w.args)
    r = rtl.run(cfg, L, os.path.join(workdir, cname, f"{w.name}_{variant}"))
    errs = rtl.compare(cfg, L, r)
    if r.fault is not None:
        errs.append(f"fault {r.fault}")
    o = oracle.run_oracle(cfg, L)
    if r.gmem != o.gmem or r.smem != o.smem:
        errs.append("oracle memory mismatch")
    lim = 11 if variant == "pred" else 16
    for t in range(wg):
        if r.regs[t // cfg.lanes][t % cfg.lanes][:lim] != o.regs[t][:lim]:
            errs.append(f"oracle register mismatch thread {t}")
            break
    if errs:
        raise AssertionError(f"{cname} {w.name} {variant}: " + "; ".join(errs[:4]))
    return (r, metrics(cfg, r, k)), k


def depth_sweep(workdir):
    """Run selected workloads with shrinking stacks: smallest safe depth and the overflow fault."""
    rows = []
    sel = ["nested_d3_k4", "piecewise_k6", "loop_nested_div_k3", "loop_break_in_if_k3", "exit_in_loop_k3"]
    for name in sel:
        w = workloads.by_name(name)
        for depth in range(1, 9):
            cfg = isa.Config(lanes=8, warps=4, depth=depth)
            k = kc.compile_kernel(w.name, w.body, lanes=8)
            L = machine.Launch(k.words, wg_dim=w.wg_dim, gmem=w.gmem, args=w.args)
            r = rtl.run(cfg, L, os.path.join(workdir, "depth", f"{name}_D{depth}"))
            errs = rtl.compare(cfg, L, r)
            if errs:
                raise AssertionError(f"depth sweep {name} D{depth}: {errs[:3]}")
            rows.append(dict(workload=name, depth=depth, status="ok" if r.fault is None else r.fault.name,
                             fault_pc=r.fault.pc if r.fault else "", fault_data=r.fault.data if r.fault else "",
                             cycles=r.cycles, sp_max=r.perf.get("sp_max"), static_bound=k.static_bound(8)))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workdir", default=os.path.join(rtl.ROOT, "build", "eval"))
    ap.add_argument("--out", default=os.path.join(rtl.ROOT, "results"))
    ap.add_argument("--configs", default=",".join(CONFIGS))
    ap.add_argument("--no-depth", action="store_true")
    a = ap.parse_args()
    t0 = time.time()
    rows = []
    na = []
    for cname in a.configs.split(","):
        cfg = CONFIGS[cname]
        rtl.build(cfg)
        for w in workloads.suite():
            for variant in ("branch", "pred"):
                res, k = run_one(cfg, cname, w, variant, a.workdir)
                if res is None:
                    if cname == "L8W4D8":
                        reasons = sorted({c.reason for c in k.conversions if not c.converted}) or \
                            ["no if statement (loops / exits are not if-convertible)"]
                        na.append(dict(workload=w.name, family=w.family, reason="; ".join(reasons)))
                    continue
                r, m = res
                conv = k.conversions
                status = ("full" if conv and all(c.converted for c in conv) else
                          "partial" if any(c.converted for c in conv) else "-")
                rows.append(dict(config=cname, workload=w.name, family=w.family, variant=variant,
                                 conversion=status if variant == "pred" else "-", **m))
                print(f"{cname:8s} {w.name:24s} {variant:6s} cycles={m['cycles']:5d} issued={m['issued']:4d} "
                      f"util={m['util']:.2f} ovh={m['overhead']:.2f} spmax={m['sp_max']}", flush=True)
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "eval.csv"), "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)
    drows = [] if a.no_depth else depth_sweep(a.workdir)
    with open(os.path.join(a.out, "eval.json"), "w") as f:
        json.dump(dict(rows=rows, not_applicable=na, depth=drows), f, indent=1)
    print(f"{len(rows)} verified runs + {len(drows)} depth-sweep runs in {time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
