#!/usr/bin/env bash
# Yosys generic synthesis: reconvergence stack across capacities, and the whole core.
# usage: tools/synth.sh [stack|core|all|core8x4]
#   core     whole core, L4 W2 D7 (~3 min)
#   core8x4  whole core, default L8 W4 D8: ~36 min (ABC on the 16 Kbit flop register file)
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/synth
what=${1:-all}
if [[ $what == stack || $what == all ]]; then
  for L in 8 16; do for D in 2 4 8 15 16 31; do
    yosys -q -p "read_verilog -sv -Irtl rtl/sfd_simt_stack.sv; hierarchy -top sfd_simt_stack -chparam LANES $L -chparam DEPTH $D; synth -top sfd_simt_stack -flatten; abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX; opt_clean; tee -o build/synth/stack_L${L}_D${D}.stat stat" >/dev/null
    printf "stack L=%-2s D=%-2s cells=%-6s\n" $L $D "$(grep -m1 'Number of cells' build/synth/stack_L${L}_D${D}.stat | awk '{print $4}')"
  done; done
fi
if [[ $what == core || $what == all || $what == core8x4 ]]; then
  cfgs="4 2 7"; [[ $what == core8x4 ]] && cfgs="8 4 8"
  # Yosys 0.33 cannot re-derive this top with -chparam (generate + parameterised submodule),
  # so the configuration is selected with the SFD_* macros.
  for cfg in "$cfgs"; do
    set -- $cfg
    out=build/synth/core_L$1W$2D$3.stat
    sed "s|@PARAMS@||; s|@OUT@|$out|; s|^read_verilog -defer -sv -Irtl |read_verilog -sv -DSFD_LANES=$1 -DSFD_WARPS=$2 -DSFD_DEPTH=$3 -Irtl |" \
        tools/synth.ys.tmpl > build/synth/core.ys
    yosys -q -s build/synth/core.ys 2>&1 | grep -v "Replacing memory" || true
    echo "core L=$1 W=$2 D=$3: $(grep -m1 'Number of cells' $out | awk '{print $4}') cells"
  done
fi
