// Testbench for sfd_core: load a kernel, launch it, write a trace and the final state.
//
// Plusargs
//   +code=<hex>          code image ($readmemh, one word per line)       (required)
//   +code_words=<n>      number of code words                            (required)
//   +gmem=<hex>          initial global memory ($readmemh with @addr)    (optional)
//   +smem=<hex>          initial shared memory                           (optional)
//   +wg_dim=<n> +wg_id=<n> +grid_dim=<n> +shared_bytes=<n> +entry=<n>
//   +arg0=<hex> .. +arg7=<hex>   kernel arguments
//   +wdog=<n>            watchdog limit in cycles (0 = off)
//   +maxcyc=<n>          testbench timeout
//   +trace=<file>        commit / pop / memory / barrier trace
//   +out=<file>          final state: status, perf counters, registers, memories
//
// Trace lines (decimal unless noted):
//   C cyc warp pc insn(hex) exec(hex) active(hex) live(hex) sp pcount pmask(hex) | pc:rpc:mask(hex) ...  (bottom..top)
//   P cyc warp R|X pc:rpc:mask        pop of the top entry (R: reached rpc, X: no live lane)
//   M cyc warp lane G|S R|W|A addr(word,hex) rdata(hex|-) wdata(hex|-)
//   B cyc released-warps(hex)
//   F code warp pc lane mask(hex) data(hex) cyc
//   D cyc
module tb_sfd_core;
  parameter int LANES      = 8;
  parameter int WARPS      = 4;
  parameter int DEPTH      = 8;
  parameter int IMEM_WORDS = 1024;
  parameter int GMEM_WORDS = 4096;
  parameter int SMEM_WORDS = 256;
  parameter bit PRED_EN    = 1'b1;
  localparam int WW  = (WARPS > 1) ? $clog2(WARPS) : 1;
  localparam int LW  = (LANES > 1) ? $clog2(LANES) : 1;
  localparam int IAW = $clog2(IMEM_WORDS);
  localparam int GAW = $clog2(GMEM_WORDS);
  localparam int SAW = $clog2(SMEM_WORDS);
  localparam int PW  = 11;
  localparam int NP  = 20;
  localparam int EW  = 2 * PW + LANES;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic               host_imem_we = 0;
  logic [IAW-1:0]     host_imem_addr = '0;
  logic [31:0]        host_imem_wdata = '0;
  logic               host_gmem_en = 0, host_gmem_we = 0;
  logic [GAW-1:0]     host_gmem_addr = '0;
  logic [31:0]        host_gmem_wdata = '0, host_gmem_rdata;
  logic               host_smem_en = 0, host_smem_we = 0;
  logic [SAW-1:0]     host_smem_addr = '0;
  logic [31:0]        host_smem_wdata = '0, host_smem_rdata;
  logic               start = 0;
  logic [PW-1:0]      l_code_words = '0, l_entry_pc = '0;
  logic [31:0]        l_wg_dim = 0, l_wg_id = 0, l_grid_dim = 1, l_shared_bytes = 0, l_wdog = 0;
  logic [8*32-1:0]    l_args = '0;
  logic               busy, done, faulted;
  logic [7:0]         fault_code;
  logic [WW-1:0]      fault_warp;
  logic [PW-1:0]      fault_pc;
  logic [LW-1:0]      fault_lane;
  logic [LANES-1:0]   fault_mask;
  logic [31:0]        fault_data;
  logic [NP*32-1:0]   perf;
  logic [WW-1:0]      dbg_warp = '0;
  logic [LW-1:0]      dbg_lane = '0;
  logic [3:0]         dbg_reg = '0;
  logic [31:0]        dbg_rdata;

  sfd_core #(.LANES(LANES), .WARPS(WARPS), .DEPTH(DEPTH), .IMEM_WORDS(IMEM_WORDS),
             .GMEM_WORDS(GMEM_WORDS), .SMEM_WORDS(SMEM_WORDS), .PRED_EN(PRED_EN)) dut (.*);

  logic [31:0] code  [0:IMEM_WORDS-1];
  logic [31:0] gimg  [0:GMEM_WORDS-1];
  logic [31:0] simg  [0:SMEM_WORDS-1];
  integer tf, of, cyc;
  string  s_code, s_gmem, s_smem, s_trace, s_out;
  integer code_words, maxcyc, v;

  // ------------------------------------------------------------------ trace
  function automatic string ent_str(input logic [EW-1:0] e);
    ent_str = $sformatf("%0d:%0d:%0h", e[EW-1 -: PW], e[EW-PW-1 -: PW], e[LANES-1:0]);
  endfunction

  always @(posedge clk) if (busy && tf != 0) begin
    if (dut.x_commit) begin
      string st;
      st = "";
      for (int i = 0; i < DEPTH; i++)
        if (i < int'(dut.x_sp)) st = {st, " ", ent_str(dut.trc_stack[i*EW +: EW])};
      $fdisplay(tf, "C %0d %0d %0d %08h %0h %0h %0h %0d %0d %0h |%s", cyc, dut.x_warp, dut.x_pc, dut.imem_q,
                dut.x_ex, dut.x_act, dut.x_live, dut.x_sp, dut.pcount[dut.x_warp], dut.pmask[dut.x_warp], st);
    end
    for (int w = 0; w < WARPS; w++)
      if (dut.w_pop_fire[w])
        $fdisplay(tf, "P %0d %0d %s %0d:%0d:%0h", cyc, w, dut.w_pop_dead[w] ? "X" : "R",
                  dut.w_pc[w], dut.w_rpc[w], dut.w_mask[w]);
    if (dut.acc_v) begin
      case (dut.acc_kind)
        2'd0: $fdisplay(tf, "M %0d %0d %0d %s R %0h %0h -", cyc, dut.acc_warp, dut.acc_lane,
                        dut.acc_shared ? "S" : "G", dut.acc_addr >> 2, dut.acc_rdata);
        2'd1: $fdisplay(tf, "M %0d %0d %0d %s W %0h - %0h", cyc, dut.acc_warp, dut.acc_lane,
                        dut.acc_shared ? "S" : "G", dut.acc_addr >> 2, dut.acc_wdata);
        default: $fdisplay(tf, "M %0d %0d %0d %s A %0h %0h %0h", cyc, dut.acc_warp, dut.acc_lane,
                        dut.acc_shared ? "S" : "G", dut.acc_addr >> 2, dut.acc_rdata, dut.acc_wdata);
      endcase
    end
    if (dut.bar_release) $fdisplay(tf, "B %0d %0h", cyc, dut.bar_wait);
  end

  always @(posedge clk) if (busy) cyc <= cyc + 1;

  // ------------------------------------------------------------------ driver
  initial begin
    tf = 0;
    if (!$value$plusargs("code=%s", s_code)) begin $display("need +code"); $finish; end
    if (!$value$plusargs("code_words=%d", code_words)) begin $display("need +code_words"); $finish; end
    if (!$value$plusargs("maxcyc=%d", maxcyc)) maxcyc = 2000000;
    for (int i = 0; i < IMEM_WORDS; i++) code[i] = 32'd0;
    for (int i = 0; i < GMEM_WORDS; i++) gimg[i] = 32'd0;
    for (int i = 0; i < SMEM_WORDS; i++) simg[i] = 32'd0;
    $readmemh(s_code, code);
    if ($value$plusargs("gmem=%s", s_gmem)) $readmemh(s_gmem, gimg);
    if ($value$plusargs("smem=%s", s_smem)) $readmemh(s_smem, simg);
    if ($value$plusargs("wg_dim=%d", v))       l_wg_dim = v;
    if ($value$plusargs("wg_id=%d", v))        l_wg_id = v;
    if ($value$plusargs("grid_dim=%d", v))     l_grid_dim = v;
    if ($value$plusargs("entry=%d", v))        l_entry_pc = PW'(v);
    if ($value$plusargs("wdog=%d", v))         l_wdog = v;
    l_shared_bytes = SMEM_WORDS * 4;
    if ($value$plusargs("shared_bytes=%d", v)) l_shared_bytes = v;
    for (int a = 0; a < 8; a++) begin
      logic [31:0] av;
      if ($value$plusargs($sformatf("arg%0d=%%h", a), av)) l_args[a*32 +: 32] = av;
    end
    l_code_words = PW'(code_words);
    if ($value$plusargs("trace=%s", s_trace)) tf = $fopen(s_trace, "w");

    repeat (3) @(posedge clk);
    rst_n = 1'b1;
    // load memories through the host ports
    for (int i = 0; i < IMEM_WORDS; i++) begin
      @(negedge clk); host_imem_we = 1; host_imem_addr = IAW'(i); host_imem_wdata = code[i];
    end
    for (int i = 0; i < GMEM_WORDS; i++) begin
      @(negedge clk); host_imem_we = 0; host_gmem_en = 1; host_gmem_we = 1; host_gmem_addr = GAW'(i); host_gmem_wdata = gimg[i];
    end
    for (int i = 0; i < SMEM_WORDS; i++) begin
      @(negedge clk); host_gmem_en = 0; host_gmem_we = 0; host_smem_en = 1; host_smem_we = 1;
      host_smem_addr = SAW'(i); host_smem_wdata = simg[i];
    end
    @(negedge clk); host_smem_en = 0; host_smem_we = 0;
    // launch
    cyc = 0;
    @(negedge clk); start = 1;
    @(negedge clk); start = 0;
    while (busy && cyc < maxcyc) @(posedge clk);
    @(negedge clk);
    if (tf != 0) begin
      if (faulted) $fdisplay(tf, "F %0d %0d %0d %0d %0h %0h %0d", fault_code, fault_warp, fault_pc, fault_lane,
                             fault_mask, fault_data, cyc);
      if (done) $fdisplay(tf, "D %0d", cyc);
      $fclose(tf);
    end
    // ---------------------------------------------------------------- final state
    if ($value$plusargs("out=%s", s_out)) begin
      of = $fopen(s_out, "w");
      $fdisplay(of, "STATUS %s %0d", done ? "done" : faulted ? "fault" : "timeout", cyc);
      if (faulted) $fdisplay(of, "FAULT %0d %0d %0d %0d %0h %0h", fault_code, fault_warp, fault_pc, fault_lane,
                             fault_mask, fault_data);
      for (int i = 0; i < NP; i++) $fdisplay(of, "K %0d %0d", i, perf[i*32 +: 32]);
      for (int w = 0; w < WARPS; w++)
        for (int l = 0; l < LANES; l++)
          for (int r = 1; r < 16; r++) begin
            dbg_warp = WW'(w); dbg_lane = LW'(l); dbg_reg = 4'(r);
            #1;
            if (dbg_rdata != 32'd0) $fdisplay(of, "R %0d %0d %0d %0h", w, l, r, dbg_rdata);
          end
      for (int i = 0; i < GMEM_WORDS; i++) begin
        @(negedge clk); host_gmem_en = 1; host_gmem_addr = GAW'(i);
        @(negedge clk); host_gmem_en = 0;
        if (host_gmem_rdata != 32'd0) $fdisplay(of, "G %0h %0h", i, host_gmem_rdata);
      end
      for (int i = 0; i < SMEM_WORDS; i++) begin
        @(negedge clk); host_smem_en = 1; host_smem_addr = SAW'(i);
        @(negedge clk); host_smem_en = 0;
        if (host_smem_rdata != 32'd0) $fdisplay(of, "S %0h %0h", i, host_smem_rdata);
      end
      $fclose(of);
    end
    $finish;
  end
endmodule
