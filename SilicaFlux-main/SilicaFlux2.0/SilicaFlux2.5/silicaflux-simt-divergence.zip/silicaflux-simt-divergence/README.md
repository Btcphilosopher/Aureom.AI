# SilicaFlux SIMT divergence core

SIMT branch-divergence handling for the **SilicaFlux SF-G1 GPU**: one precisely specified
reconvergence mechanism, its contract with compiler-generated control flow, synthesisable
SystemVerilog, an instruction-level Python reference model, verification, and an evaluation
against predicated execution.

**Mechanism.** Each warp has a reconvergence stack of `(pc, rpc, mask)` entries. A
`bz/bnz rs, target, reconv` instruction carries its reconvergence point, chosen by the compiler
as the minimal valid post-dominator. A divergent branch turns the top entry into the
reconvergence entry and pushes the fall-through path, then the taken path, which runs first.
Paths that start at the join need no entry, and a branch whose join equals the current entry's
join *reuses* that entry, which keeps loops at constant depth. An entry is popped when its path
reaches the join or has no live lane left. `exit` clears lanes from the live mask. Capacity is
a parameter; overflow is a precise fault, and `DEPTH ≥ 2·LANES − 1` makes it impossible.
This is the SF-G1 execution model, so binaries are SF-G1 binaries: the core is
cross-checked against the existing SF-G1 reference model and agrees on 199/199 kernels.

## The brief, and where each item is answered

| requirement | where |
|---|---|
| per-warp execution masks | spec §1.2 (live / active / execution masks, rules E1–E4); `rtl/sfd_core.sv` `x_ex`; assertions C1, C2, L1 |
| branch evaluation | spec §1.5; `simt.py: plan_branch`; `sfd_simt_stack.sv` branch preview |
| path selection | spec §1.5 (taken path first, empty paths, reuse) |
| reconvergence points | spec §1.6 (pop rule, one pop per clock, `F_RECONV` layout check); contract chapter 2 |
| nested divergence | spec §1.7; `d03_nested3`, `d31_shared_joins`, `nested_d*` workloads |
| loop handling | spec §1.8 (do-while, while, break, break inside `if`, continue); `d04`–`d07`, `loop_*` |
| early thread termination | spec §1.9; `d08`–`d11`, `exit_*` |
| stack / token capacity | spec §1.12 (`2L−1` bound, tight); cost per entry, chapter 3 §3.3; static bound §2.5 |
| overflow behaviour | spec §1.12: precise `F_STACK_OVERFLOW(sp)`, launch stops; `d15_overflow`, capacity sweep in chapter 6 |
| one precisely specified mechanism, coordinated with assembler/compiler | chapter 1 (normative) + chapter 2 (contract C1–C3, lowering table, checker, minimality vs classic IPDOM) |
| per-thread architectural results preserved | per-thread oracle (`oracle.py`) = SIMT model = RTL on every register of every thread (chapter 5) |
| supported memory ordering preserved | spec §1.11; LSU ascending lanes (L2), program order per thread, barrier/fence; exact memory-access streams compared |
| workloads: uniform, balanced, sparse, nested loops, exits | chapter 4, `model/sfdiv/workloads.py` |
| metrics: utilisation, control overhead, stack occupancy, completion cycles | chapter 6 + `results/EVALUATION.md` (hardware counters, cross-checked against traces) |
| compare with predication only where equivalent | chapter 2 §2.6 (legality P1–P4), chapter 6 §6.6; 9 workloads reported as *not comparable* with the reason |
| synthesisable RTL | `rtl/`; Verilator `-Wall` clean; Yosys synthesis (chapter 3) |
| reference semantics | `model/sfdiv/simt.py`, `machine.py` (normative), `oracle.py` |
| tests, assertions | `tests/` (pytest + directed + random), 21 RTL assertions, 24/24 mutants killed (chapter 5) |
| traces that explain reconvergence step by step | `traces/` (21 narrated RTL runs), `model/sfdiv/explain.py` |
| no side effects in inactive lanes; barrier behaviour unchanged | rules E1/E4, assertions L1/C2/C6/C10, test `d23_inactive_bad_addr`; predication refuses regions containing barriers (P2) |

## Headline results (L8W4D8 unless stated; all from verified RTL runs)

* **Utilisation**: 100 % for uniform branches; 60–81 % balanced; 30 % for one lane on a long path;
  30 % at nesting depth 3; 52–58 % for divergent loops. Exits cost almost nothing: live
  utilisation stays at 92–99 %.
* **Control overhead**: 2–24 % of issue slots. With 4 warps, pop latency is almost entirely hidden
  (2–7 exposed cycles per kernel); with one warp every pop is exposed.
* **Stack occupancy**: peak 5 entries over 26 workloads, mean 1.0–3.65; `DEPTH = 8` (240 bits per
  warp) suffices. Smaller stacks fail with a precise overflow and never run slower.
* **Branch vs predication** (17 of 26 workloads comparable): predication wins by at most 5 %
  (flat, balanced `if`, single warp). It needs **1.06–1.72×** the cycles when conditions are
  warp-uniform, whole warps skip an arm, or conditions nest. Loops, breaks and exits cannot be
  predicated.

## Quick start

```bash
make test      # model-level tests (seconds)
make rtl       # RTL vs reference model: directed, random, workloads (needs Icarus Verilog 12)
make eval      # verified evaluation sweep -> results/EVALUATION.md
make traces    # step-by-step reconvergence narratives -> traces/
make help      # lint, synth, mutate, xcheck ...
```

Requirements: Python ≥ 3.9 (tested 3.13) with `pytest`; Icarus Verilog 12; optionally
Verilator 5 (lint) and Yosys ≥ 0.33 (synthesis). The SF-G1 cross-check needs the
`silicaflux-sf-g1` tree (from `silicaflux-sf-g1.zip` in the SilicaFlux repository).

Compile and run your own kernel:

```python
import sys; sys.path.insert(0, "model")
from sfdiv import isa, kc, machine, rtl, explain
from sfdiv.kc import If, While, ops
body = ops("rdsr r1, SR_TID; andi r2, r1, 1; addi r5, r0, 0") + \
       [If("r2", ops("addi r5, r5, 1"), ops("addi r5, r5, 2"))] + \
       ops("shli r3, r1, 2; stg r5, [r3 + 1024]")
k = kc.compile_kernel("demo", body)          # reconvergence points chosen + contract checked
print(k.program.listing())
cfg = isa.Config()                           # 8 lanes, 4 warps, depth 8
L = machine.Launch(k.words, wg_dim=32)
r = rtl.run(cfg, L, "build/demo")            # RTL simulation
assert not rtl.compare(cfg, L, r)            # exact agreement with the reference model
print(explain.narrate(cfg, r, rtl.replay_model(cfg, L, r), k.program, [0]))
```

## Layout

```
docs/01-reconvergence-spec.md   normative specification of the mechanism
docs/02-compiler-contract.md    contract with compiler / assembler, checker, if-conversion legality
docs/03-microarchitecture.md    RTL structure, timing, capacity cost, synthesis
docs/04-workloads.md            workload families and the random kernel generator
docs/05-verification.md         strategy, assertions, results
docs/06-evaluation.md           analysis of the measured results
rtl/      sfd_core (top), sfd_simt_stack, sfd_lsu, sfd_regfile, sfd_decode, sfd_alu, sfd_ram, sfd_defs.svh
tb/       tb_sfd_core.sv (loads a kernel, writes commit/pop/memory/barrier trace + final state)
model/sfdiv/
    isa.py asm.py           SF-G1 ISA (+ SFX-PRED pz/pnz), assembler
    simt.py machine.py      reconvergence stack + instruction-level SIMT machine (normative)
    oracle.py               per-thread MIMD oracle
    cfg.py kc.py            contract checker, structured compiler, if-converter, static stack bound
    workloads.py gen.py     evaluation workloads, random structured kernels
    rtl.py explain.py       RTL runner + lock-step comparison, trace narration
tests/    pytest suites, directed kernels (tests/directed.py), run_directed.py
tools/    evaluate.py report.py rtl_random.py mutate.py make_traces.py xcheck_sfg1.py lint.sh synth.sh
results/  EVALUATION.md, eval.csv/json, mutation.md, regression logs, synthesis reports
traces/   narrated RTL runs (README.md indexes them)
```

## Relation to SF-G1

Same encoding, opcodes, special registers, fault codes and divergence semantics as SF-G1
(`silicaflux-sf-g1`, docs 02–05). This package implements the execution pipeline that SF-G1
lists as *planned*: warp table, scheduler, SIMT stack integration, lane execution, LSU and
barrier unit, for one execution group running one workgroup. It adds one clearly separated
extension, **SFX-PRED** (`pz`/`pnz` predication windows, opcodes 0x3B/0x3C, fault 27). It is
used only for the comparison and can be disabled (`PRED_EN = 0`), which makes the opcodes
illegal as in SF-G1.

## Status and limits

Done and verified as described in chapter 5. Not done: multi-execution-group dispatch, a
coalescing memory system, formal proofs, gate-level simulation and timing closure. Simulation
uses Icarus Verilog; Verilator is used for lint only. No license file is included; add one
before publishing.
