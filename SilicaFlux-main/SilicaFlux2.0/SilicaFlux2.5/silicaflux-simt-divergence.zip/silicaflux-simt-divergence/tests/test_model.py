"""Reference model: directed behaviours, per-thread equivalence, schedule independence."""
import random

import pytest

from directed import TESTS
from run_directed import check_model
from sfdiv import gen, isa, kc, machine, oracle
from sfdiv.machine import Machine


@pytest.mark.parametrize("t", TESTS, ids=[t.name for t in TESTS])
def test_directed(t):
    check_model(t)


CONFIGS = [isa.Config(lanes=8, warps=4, depth=15), isa.Config(lanes=4, warps=2, depth=7),
           isa.Config(lanes=16, warps=2, depth=31)]


@pytest.mark.parametrize("c", CONFIGS, ids=lambda c: f"L{c.lanes}W{c.warps}")
def test_simt_preserves_per_thread_results(c):
    """SIMT execution == independent per-thread execution, for every register of every thread."""
    for seed in range(60):
        g = gen.random_kernel(seed, c.lanes, c.warps)
        k = kc.compile_kernel("r", g.body, lanes=c.lanes)
        L = machine.Launch(k.words, wg_dim=g.wg_dim, gmem=g.gmem, args=[seed])
        m = Machine(c, L)
        step = m.step

        def checked(w, m=m, step=step):
            step(w)
            for x in m.warps:
                x.stack.check_invariants(c.lanes)
        m.step = checked
        r = m.run()
        o = oracle.run_oracle(c, L)
        assert r.fault is None and o.fault is None
        assert r.gmem == o.gmem and r.smem == o.smem
        for t in range(g.wg_dim):
            assert r.regs[t // c.lanes][t % c.lanes] == o.regs[t], (seed, t)


def test_results_independent_of_warp_schedule():
    """Any legal schedule gives the same per-thread results for race-free kernels."""
    c = isa.Config(lanes=8, warps=4, depth=15)
    for seed in range(40):
        g = gen.random_kernel(seed)
        k = kc.compile_kernel("r", g.body)
        L = machine.Launch(k.words, wg_dim=g.wg_dim, gmem=g.gmem)
        ref = machine.run(c, L)
        m = Machine(c, L)
        rng = random.Random(seed)
        while not m.all_done:
            el = [w for w in m.warps if m.eligible(w)]
            m.step(rng.choice(el))
        assert m.fault is None
        assert m.gmem == ref.gmem and [[r for r in w.regs] for w in m.warps] == ref.regs


def test_inactive_lanes_have_no_side_effects():
    """Lanes outside the execution mask never write registers or memory (checked on every commit)."""
    c = isa.Config()
    for seed in range(40):
        g = gen.random_kernel(seed)
        for pred in (False, True):
            k = kc.compile_kernel("r", g.body, predicate=pred)
            r = machine.run(c, machine.Launch(k.words, wg_dim=g.wg_dim, gmem=g.gmem))
            for cm in r.trace:
                assert cm.exec_mask & ~cm.active == 0
                assert cm.active & ~cm.live == 0
                for a in cm.mem:
                    assert (cm.exec_mask >> a.lane) & 1, (seed, cm, a)


def test_barrier_never_sees_divergence_in_compiled_code():
    c = isa.Config()
    for seed in range(60):
        g = gen.random_kernel(seed)
        k = kc.compile_kernel("r", g.body)
        r = machine.run(c, machine.Launch(k.words, wg_dim=g.wg_dim, gmem=g.gmem))
        for cm in r.trace:
            if isa.decode(cm.word).cls == isa.BAR:
                assert cm.active == cm.live
