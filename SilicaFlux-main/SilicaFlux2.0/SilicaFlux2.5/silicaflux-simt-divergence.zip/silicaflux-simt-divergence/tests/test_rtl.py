"""RTL vs reference model (needs Icarus Verilog; skipped otherwise).  Slow: run with `make rtl`."""
import os

import pytest

from directed import TESTS
from run_directed import check_rtl
from sfdiv import gen, isa, kc, machine, oracle, rtl, workloads

pytestmark = pytest.mark.skipif(not rtl.have_tools(), reason="iverilog/vvp not installed")
WORK = os.path.join(rtl.ROOT, "build", "pytest")


@pytest.mark.parametrize("t", TESTS, ids=[t.name for t in TESTS])
def test_directed_rtl(t):
    r, errs = check_rtl(t, WORK)
    assert not errs, errs


@pytest.mark.parametrize("seed", range(4))
@pytest.mark.parametrize("c", [isa.Config(lanes=8, warps=4, depth=8), isa.Config(lanes=4, warps=2, depth=3)],
                         ids=["L8W4D8", "L4W2D3"])
def test_random_rtl(seed, c):
    g = gen.random_kernel(500 + seed, c.lanes, c.warps)
    k = kc.compile_kernel("r", g.body, lanes=c.lanes)
    L = machine.Launch(k.words, wg_dim=g.wg_dim, gmem=g.gmem, args=[seed])
    r = rtl.run(c, L, os.path.join(WORK, f"rnd_{c.lanes}_{c.depth}_{seed}"))
    assert not rtl.compare(c, L, r)
    if r.fault is None:
        o = oracle.run_oracle(c, L)
        assert r.gmem == o.gmem


@pytest.mark.parametrize("name", ["balanced_k8", "loop_break_in_if_k3", "reduce_smem", "exit_in_loop_k3"])
def test_workload_rtl(name):
    w = workloads.by_name(name)
    for pred in (False, True):
        k = kc.compile_kernel(name, w.body, predicate=pred)
        L = machine.Launch(k.words, wg_dim=w.wg_dim, gmem=w.gmem)
        r = rtl.run(isa.Config(), L, os.path.join(WORK, f"{name}_{pred}"))
        assert not rtl.compare(isa.Config(), L, r)
