#!/usr/bin/env python3
"""Run the directed kernels on the reference model and (optionally) on the RTL."""
import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "model"))
from directed import TESTS  # noqa: E402
from sfdiv import asm, isa, machine, rtl  # noqa: E402


def launch_of(t):
    p = asm.assemble(t.src, t.name)
    return p, machine.Launch(p.words, wg_dim=t.wg_dim, args=t.args, gmem=t.gmem)


def check_model(t):
    cfg = t.config()
    p, L = launch_of(t)
    r = machine.Machine(cfg, L).run(max_issues=t.max_issues)
    if t.fault is None:
        assert r.fault is None, f"{t.name}: unexpected fault {r.fault}"
    else:
        assert r.fault is not None and r.fault.code == t.fault, f"{t.name}: expected {isa.FAULT_NAMES[t.fault]} got {r.fault}"
        if t.fault_data is not None:
            assert r.fault.data == t.fault_data, f"{t.name}: fault data {r.fault.data:#x} != {t.fault_data:#x}"
    if t.check:
        t.check(r)
    return r


def check_rtl(t, workdir):
    cfg = t.config()
    p, L = launch_of(t)
    r = rtl.run(cfg, L, os.path.join(workdir, t.name), wdog=t.wdog)
    errs = rtl.compare(cfg, L, r)
    if t.fault is not None:
        if r.fault is None or r.fault.code != t.fault:
            errs.append(f"expected {isa.FAULT_NAMES[t.fault]} got {r.fault}")
    elif t.check:
        m = rtl.replay_model(cfg, L, r)
        t.check(m)
    return r, errs


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--rtl", action="store_true")
    ap.add_argument("--workdir", default=os.path.join(rtl.ROOT, "build", "directed"))
    a = ap.parse_args()
    bad = 0
    for t in TESTS:
        try:
            r = check_model(t)
            line = f"{t.name:28s} model ok  issued={r.issued:5d} maxsp={max(r.max_sp)} fault={r.fault.name if r.fault else '-'}"
            if a.rtl:
                rr, errs = check_rtl(t, a.workdir)
                if errs:
                    bad += 1
                    line += "  RTL FAIL: " + "; ".join(errs[:3])
                else:
                    line += f"  RTL match cycles={rr.cycles}"
            print(line, flush=True)
        except AssertionError as e:
            bad += 1
            print(f"{t.name:28s} FAIL {e}", flush=True)
    print(f"{len(TESTS) - bad}/{len(TESTS)} directed tests pass")
    sys.exit(1 if bad else 0)
