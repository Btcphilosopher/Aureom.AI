"""Directed kernels: one per specified behaviour, each with explicit expectations.

Used by tests/test_model.py (reference model), tests/test_rtl.py and tests/run_directed.py --rtl
(RTL vs model), tools/mutate.py (kill suite) and tools/make_traces.py.
Every test states *what* it demonstrates in ``doc``; ``check`` receives the model
Result (and is also applied to the RTL result's final state through the exact
model-vs-RTL comparison).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "model"))
from sfdiv import isa  # noqa: E402


@dataclass
class Directed:
    name: str
    doc: str
    src: str
    wg_dim: int = 32
    cfg: Dict = field(default_factory=dict)
    args: List[int] = field(default_factory=lambda: [0] * 8)
    gmem: Dict[int, int] = field(default_factory=dict)
    fault: Optional[int] = None           # expected fault code
    fault_data: Optional[int] = None
    check: Optional[Callable] = None      # check(result) -> None (asserts)
    wdog: int = 0
    max_issues: int = 200_000

    def config(self) -> isa.Config:
        return isa.Config(**self.cfg)


def _g(res, addr):
    return res.gmem[addr]


def _max_sp(res):
    return max(res.max_sp)


def _div(res):
    return sum(1 for c in res.trace if c.branch is not None and c.branch.kind == "diverge")


def c_uniform(res):
    assert _div(res) == 0, "uniform branch must never diverge"
    for t in range(32):
        assert _g(res, 0x100 + t) == (11 if (t // 8) % 2 else 22)


def c_ifelse(res):
    for t in range(32):
        assert _g(res, 0x100 + t) == (205 if t % 2 == 0 else 101)
    # the worked example: after the divergent bz warp 0's stack is (9,-,FF)(3,9,AA)(6,9,55)
    c = next(c for c in res.trace if c.warp == 0 and c.pc == 6)
    assert c.stack == ((9, isa.RPC_NONE, 0xFF), (3, 9, 0xAA), (6, 9, 0x55)), c.stack
    assert _max_sp(res) == 3


def c_nested3(res):
    for t in range(32):
        l = t % 8
        leaf = 4 * (l & 1) + (l & 2) + ((l >> 2) & 1)     # path id: bit0 outermost
        assert _g(res, 0x100 + t) == 1000 + leaf, (t, _g(res, 0x100 + t))
    assert _max_sp(res) == 7, _max_sp(res)          # 1 + 2 * nesting depth


def c_shared_joins(res):
    for t in range(32):
        l = t % 8
        assert _g(res, 0x100 + t) == 1000 + 4 * (l & 1) + (l & 2) + ((l >> 2) & 1)
    assert _max_sp(res) == 5, _max_sp(res)
    reused = [c for c in res.trace if c.branch is not None and c.branch.kind == "diverge" and c.branch.reuse]
    assert reused, "coinciding reconvergence points must reuse the top entry"


def c_loop_reuse(res):
    for t in range(32):
        assert _g(res, 0x100 + t) == (t % 8) + 1
    assert _max_sp(res) == 2, "do-while back-edge must reuse its entry (constant depth)"


def c_while(res):
    for t in range(32):
        n = t % 8
        assert _g(res, 0x100 + t) == n * (n - 1) // 2
    assert _max_sp(res) == 2


def c_nested_loops(res):
    for t in range(32):
        o, i = (t % 4) + 1, (t >> 2) % 3 + 1
        assert _g(res, 0x100 + t) == o * i, (t, _g(res, 0x100 + t))


def c_break(res):
    data = [3, 9, 1, 12, 7, 15, 2, 20]
    for t in range(32):
        thr = t % 16
        idx = next((k for k, d in enumerate(data) if d > thr), 8)
        assert _g(res, 0x100 + t) == idx, (t, _g(res, 0x100 + t), idx)


def c_exit_early(res):
    for t in range(32):
        assert _g(res, 0x100 + t) == (t + 1 if t < 13 else 0)
    # lanes that exit never execute again: count lanes executing the store
    st = [c for c in res.trace if isa.decode(c.word).cls == isa.STG]
    assert sum(isa.popcount(c.exec_mask) for c in st) == 13


def c_exit_in_arm(res):
    for t in range(32):
        assert _g(res, 0x100 + t) == (0 if t % 4 == 0 else 7 + (t % 2)), (t, _g(res, 0x100 + t))


def c_exit_cascade(res):
    # lanes 0-3 exit inside the else path, lanes 4-7 take the then path, all 8 exit before the join
    for t in range(32):
        assert _g(res, 0x100 + t) == (0xAA if t % 8 >= 4 else 0xBB)
    assert all(c.pc != 10 for c in res.trace), "nobody reaches the join"
    assert sum(1 for c in res.trace for p in c.pops if p[0] == "X") >= 8, "dead entries are dropped"


def c_exit_warp_barrier(res):
    # warps 1 and 3 exit completely before the barrier; warps 0 and 2 pass it
    for t in range(32):
        w = t // 8
        assert _g(res, 0x100 + t) == (0 if w in (1, 3) else 5)
    assert sum(1 for c in res.trace if c.bar_release) == 1


def c_barrier_loop(res):
    for t in range(32):
        assert _g(res, 0x100 + t) == 4 * (t + (t % 2)), (t, _g(res, 0x100 + t))


def c_partial(res):
    for t in range(32):
        assert _g(res, 0x100 + t) == (t * 3 if t < 21 else 0)
    assert all(c.live & ~((1 << 5) - 1) == 0 for c in res.trace if c.warp == 2)
    assert not any(c.warp == 3 for c in res.trace), "warp with no thread never issues"


def c_sparse(res):
    for t in range(32):
        assert _g(res, 0x100 + t) == (t * 100 if t % 8 == 5 else 1)
    long = [c for c in res.trace if c.pc in range(5, 13)]
    assert all(isa.popcount(c.exec_mask) == 1 for c in long)


def c_order(res):
    assert _g(res, 0x40) == 7, "highest active lane's store wins"
    assert _g(res, 0x41) == sum(range(1, 9)) * 4
    # atomic return values: lane i of warp w sees sum of all earlier increments
    for t in range(8):
        assert res.regs[0][t][6] == sum(range(1, t + 1)), (t, res.regs[0][t][6])


def c_pred(res):
    for t in range(32):
        assert _g(res, 0x100 + t) == (50 if t % 3 == 0 else 60), (t, _g(res, 0x100 + t))
    # predicated lanes never touch memory: exactly one store per thread
    assert len([a for a in res.mem_log if a.kind == "W"]) == 32
    # windows never touch the reconvergence stack
    assert all(c.sp == 1 for c in res.trace if isa.decode(c.word).cls == isa.PRED)


def c_pred_empty(res):
    assert _g(res, 0x100) == 0 and all(_g(res, 0x100 + t) == 0 for t in range(32))
    w = [c for c in res.trace if c.pcount > 0]
    assert w and all(c.exec_mask == 0 for c in w)


def c_inactive_bad_addr(res):
    for t in range(32):
        assert _g(res, 0x100 + t) == (t if t % 2 else 0)


def c_reduce(res):
    vals = [(t * 37 + 11) & 0xFF for t in range(32)]
    assert _g(res, 0x300) == sum(vals), (_g(res, 0x300), sum(vals))


def c_degenerate(res):
    for t in range(32):
        assert _g(res, 0x100 + t) == 1


# -------------------------------------------------------------------------------------------
TESTS: List[Directed] = [
    Directed("d01_uniform_branch", "Branch on SR_WARP_ID: uniform per warp, never diverges, no stack entry.", """
    rdsr r1, SR_TID
    rdsr r2, SR_WARP_ID
    andi r2, r2, 1
    bz   r2, even, done
    addi r3, r0, 11
    bra  done
even:
    addi r3, r0, 22
done:
    shli r4, r1, 2
    stg  r3, [r4 + 0x400]
    exit
""", check=c_uniform),

    Directed("d02_ifelse", "SF-G1 worked example: if/else, taken path first, two pops to reconverge.", """
    rdsr r1, SR_TID
    andi r2, r1, 1
    bz   r2, else, endif
    addi r3, r0, 100
    addi r3, r3, 1
    bra  endif
else:
    addi r3, r0, 200
    addi r3, r3, 2
    addi r3, r3, 3
endif:
    shli r4, r1, 2
    stg  r3, [r4 + 0x400]
    exit
""", check=c_ifelse),

    Directed("d03_nested3", "Three nested if/else on lane bits 0..2: 8 leaf paths, depth 1 + 2*3 = 7.", """
    rdsr r1, SR_TID
    rdsr r2, SR_LANE_ID
    andi r3, r2, 1
    andi r4, r2, 2
    andi r5, r2, 4
    addi r6, r0, 1000
    bz   r3, a0, aj
      bz r4, b0, bj
        bz r5, c0, cj
          addi r6, r6, 7
          bra cj
c0:       addi r6, r6, 6
cj:     bra bj
b0:     bz r5, d0, dj
          addi r6, r6, 5
          bra dj
d0:       addi r6, r6, 4
dj:     nop
bj:   bra aj
a0:   bz r4, e0, ej
        bz r5, f0, fj
          addi r6, r6, 3
          bra fj
f0:       addi r6, r6, 2
fj:     bra ej
e0:     bz r5, g0, gj
          addi r6, r6, 1
          bra gj
g0:       addi r6, r6, 0
gj:     nop
ej:   nop
aj: shli r7, r1, 2
    stg  r6, [r7 + 0x400]
    exit
""", cfg=dict(depth=8), check=c_nested3),

    Directed("d04_dowhile_reuse", "Do-while with per-lane trip count (lane+1): back-edge reuses its entry, depth stays 2.", """
    rdsr r1, SR_TID
    rdsr r2, SR_LANE_ID
    addi r3, r0, 0
loop:
    addi r3, r3, 1
    slt  r4, r2, r3       ; r4 = (lane < count) -> leave
    xori r4, r4, 1
    bnz  r4, loop, after
after:
    shli r5, r1, 2
    stg  r3, [r5 + 0x400]
    exit
""", check=c_loop_reuse),

    Directed("d05_while_top_test", "While loop with the test at the top (bz c, exit, exit): sum 0..n-1 per lane.", """
    rdsr r1, SR_TID
    rdsr r2, SR_LANE_ID
    addi r3, r0, 0        ; i
    addi r6, r0, 0        ; sum
top:
    slt  r4, r3, r2
    bz   r4, out, out
    add  r6, r6, r3
    addi r3, r3, 1
    bra  top
out:
    shli r5, r1, 2
    stg  r6, [r5 + 0x400]
    exit
""", check=c_while),

    Directed("d06_nested_loops", "Outer trip 1..4 (tid%4+1) x inner trip 1..3 ((tid>>2)%3+1), both divergent.", """
    rdsr r1, SR_TID
    andi r2, r1, 3
    addi r2, r2, 1        ; outer count
    shri r3, r1, 2
    addi r9, r0, 3
    ; r3 = (tid>>2) % 3 via repeated subtraction (no divide in the ISA)
m3: slt  r10, r3, r9
    bnz  r10, m3done, m3done
    sub  r3, r3, r9
    bra  m3
m3done:
    addi r3, r3, 1        ; inner count
    addi r4, r0, 0        ; outer i
    addi r6, r0, 0        ; acc
otop:
    addi r5, r0, 0        ; inner j
itop:
    addi r6, r6, 1
    addi r5, r5, 1
    slt  r7, r5, r3
    bnz  r7, itop, iend
iend:
    addi r4, r4, 1
    slt  r8, r4, r2
    bnz  r8, otop, oend
oend:
    shli r7, r1, 2
    stg  r6, [r7 + 0x400]
    exit
""", check=c_nested_loops),

    Directed("d07_break", "Search loop with a conditional break (bnz c, exit, exit): index of first data > tid%16.", """
    rdsr r1, SR_TID
    andi r2, r1, 15       ; threshold
    addi r3, r0, 0        ; k
    addi r9, r0, 0x200    ; data base (bytes)
top:
    slti r4, r3, 8
    bz   r4, out, out
    shli r5, r3, 2
    add  r5, r5, r9
    ldg  r6, [r5 + 0]
    slt  r7, r2, r6       ; data > thr
    bnz  r7, out, out     ; break
    addi r3, r3, 1
    bra  top
out:
    shli r8, r1, 2
    stg  r3, [r8 + 0x400]
    exit
""", gmem={0x80 + i: v for i, v in enumerate([3, 9, 1, 12, 7, 15, 2, 20])}, check=c_break),

    Directed("d08_exit_early", "Guard exit (if tid >= 13 exit): reconv at the join, not the kernel end.", """
    rdsr r1, SR_TID
    slti r2, r1, 13
    bnz  r2, go, go
    exit
go:
    addi r3, r1, 1
    shli r4, r1, 2
    stg  r3, [r4 + 0x400]
    exit
""", check=c_exit_early),

    Directed("d09_exit_in_arm", "Exit inside the then-arm: survivors reconverge without the exited lanes.", """
    rdsr r1, SR_TID
    andi r2, r1, 3
    bz   r2, else, join     ; tid%4 == 0 -> else
    andi r3, r1, 1
    addi r3, r3, 7
    bra  join
else:
    exit
join:
    shli r4, r1, 2
    stg  r3, [r4 + 0x400]
    exit
""", check=c_exit_in_arm),

    Directed("d10_exit_cascade", "Every lane exits inside its own path: entries die (pop X) and nobody reaches the join.", """
    rdsr r1, SR_TID
    andi r2, r1, 4
    shli r4, r1, 2
    bz   r2, else, join
    addi r3, r0, 0xAA
    stg  r3, [r4 + 0x400]
    exit
else:
    addi r3, r0, 0xBB
    stg  r3, [r4 + 0x400]
    exit
join:
    trap 1
""", check=c_exit_cascade),

    Directed("d11_exit_warp_barrier", "Whole warps exit before a barrier; the barrier waits only for warps that are not done.", """
    rdsr r1, SR_TID
    rdsr r2, SR_WARP_ID
    andi r2, r2, 1
    bz   r2, go, go
    exit
go:
    bar
    addi r3, r0, 5
    shli r4, r1, 2
    stg  r3, [r4 + 0x400]
    exit
""", check=c_exit_warp_barrier),

    Directed("d12_barrier_loop", "Barrier inside a uniform loop with divergence between barriers (reconverged before each bar).", """
    rdsr r1, SR_TID
    addi r2, r0, 0        ; i
    addi r6, r0, 0        ; acc
loop:
    andi r3, r1, 1
    bz   r3, even, join
    addi r6, r6, 1
    bra  join
even:
join:
    add  r6, r6, r1
    bar
    addi r2, r2, 1
    slti r5, r2, 4
    bnz  r5, loop, after
after:
    shli r4, r1, 2
    stg  r6, [r4 + 0x400]
    exit
""", check=c_barrier_loop),

    Directed("d13_partial_warp", "wg_dim = 21: warp 2 has 5 live lanes, warp 3 none (done at launch).", """
    rdsr r1, SR_TID
    addi r2, r0, 3
    mul  r3, r1, r2
    shli r4, r1, 2
    stg  r3, [r4 + 0x400]
    exit
""", wg_dim=21, check=c_partial),

    Directed("d14_sparse_lane", "One lane per warp takes a long path: 8 instructions at 1/8 utilisation.", """
    rdsr r1, SR_TID
    rdsr r2, SR_LANE_ID
    addi r3, r0, 1
    xori r5, r2, 5
    bnz  r5, skip, skip
    addi r3, r0, 0
    addi r6, r0, 25
    add  r3, r3, r6
    add  r3, r3, r6
    add  r3, r3, r6
    add  r3, r3, r6
    mul  r3, r3, r1
    nop
skip:
    shli r4, r1, 2
    stg  r3, [r4 + 0x400]
    exit
""", check=c_sparse),

    Directed("d15_overflow", "Nested divergence deeper than DEPTH=4: precise F_STACK_OVERFLOW, data = depth at the branch.", """
    rdsr r2, SR_LANE_ID
    andi r3, r2, 1
    andi r4, r2, 2
    bz   r3, a0, aj
    addi r6, r0, 1
    bra  aj
a0: bz   r4, b0, bj        ; needs 2 more entries at depth 3 -> 5 > 4
    addi r6, r0, 2
    bra  bj
b0: addi r6, r0, 3
bj: addi r7, r0, 1          ; keeps bj != aj (otherwise the inner branch would reuse)
aj: exit
""", cfg=dict(depth=4), fault=isa.F_STACK_OVERFLOW, fault_data=3),

    Directed("d16_reconv_violation", "If-arm breaks out of a loop but names endif as reconv: F_RECONV at runtime.", """
    rdsr r1, SR_TID
    andi r2, r1, 1
    addi r4, r0, 0
top:
    slti r5, r4, 4
    bz   r5, out, out
    bz   r2, endif, endif   ; WRONG: the arm below breaks; must be 'out'
    bra  out
endif:
    addi r4, r4, 1
    bra  top
out:
    exit
""", fault=isa.F_RECONV, fault_data=7),

    Directed("d17_bar_divergent", "Barrier inside a divergent arm: F_BAR_DIVERGENT with the live mask.", """
    rdsr r1, SR_TID
    andi r2, r1, 1
    bz   r2, join, join
    bar
join:
    exit
""", fault=isa.F_BAR_DIVERGENT, fault_data=0xFF),

    Directed("d18_pred_window_control", "A branch inside a predication window: F_PRED_WINDOW (precise).", """
    rdsr r1, SR_TID
    andi r2, r1, 1
    pnz  r2, 2
    addi r3, r0, 1
    bra  next
next:
    exit
""", fault=isa.F_PRED_WINDOW),

    Directed("d19_pred_window_cross", "A window that would run past the path's reconvergence point: F_PRED_WINDOW.", """
    rdsr r1, SR_TID
    andi r2, r1, 1
    bz   r2, join, join
    pnz  r2, 3
    addi r3, r0, 1
join:
    addi r3, r3, 1
    exit
""", fault=isa.F_PRED_WINDOW),

    Directed("d20_pred_basic", "pz/pnz windows: one store per thread, the other arm's lanes never touch memory.", """
    rdsr r1, SR_TID
    addi r2, r0, 3
    ; r3 = tid % 3 == 0 via subtraction loop-free trick: tid - 3*floor(tid/3) using a table-free test
    addi r3, r0, 0
    addi r5, r1, 0
m:  slti r6, r5, 3
    bnz  r6, md, md
    sub  r5, r5, r2
    bra  m
md: shli r4, r1, 2
    addi r7, r0, 50
    addi r8, r0, 60
    pz   r5, 1
    stg  r7, [r4 + 0x400]
    pnz  r5, 1
    stg  r8, [r4 + 0x400]
    exit
""", check=c_pred),

    Directed("d21_pred_empty", "A window whose predicate selects no lane: instructions issue with an empty mask and do nothing.", """
    rdsr r1, SR_TID
    shli r4, r1, 2
    addi r7, r0, 99
    pnz  r0, 2
    stg  r7, [r4 + 0x400]
    addi r9, r0, 1
    exit
""", check=c_pred_empty),

    Directed("d22_mem_fault_priority", "Lanes 3 (misaligned) and 5 (out of range) fail: lowest lane wins, no lane is performed.", """
    rdsr r2, SR_LANE_ID
    shli r3, r2, 2
    xori r6, r2, 3
    bnz  r6, a, a
    addi r3, r3, 1          ; lane 3 misaligned
a:  xori r6, r2, 5
    bnz  r6, b, b
    lui  r3, 1000           ; lane 5 far out of range
b:  stg  r2, [r3 + 0x400]
    exit
""", wg_dim=8, fault=isa.F_GMEM_ALIGN, fault_data=0x40D),

    Directed("d23_inactive_bad_addr", "Inactive lanes hold invalid addresses but must neither fault nor store.", """
    rdsr r1, SR_TID
    shli r4, r1, 2
    andi r2, r1, 1
    bnz  r2, ok, ok
    lui  r4, 0x3FFFFF       ; even lanes: garbage address (never used)
    addi r4, r4, 3
ok: bz   r2, skip, skip
    stg  r1, [r4 + 0x400]   ; only odd lanes are active here
skip:
    exit
""", check=c_inactive_bad_addr),

    Directed("d24_illegal", "Reserved bit set in a nop: F_ILLEGAL_INSN carries the word.", """
    rdsr r1, SR_TID
    .word 0x00000001
    exit
""", fault=isa.F_ILLEGAL_INSN, fault_data=0x00000001),

    Directed("d25_pc_range", "Falling off the end of the code: F_PC_RANGE with the pc.", """
    rdsr r1, SR_TID
    addi r2, r1, 1
""", fault=isa.F_PC_RANGE, fault_data=2),

    Directed("d26_trap", "trap: F_TRAP with the code.", """
    rdsr r1, SR_TID
    trap 0x1234
""", fault=isa.F_TRAP, fault_data=0x1234),

    Directed("d27_lane_order", "Same-address stores: highest active lane wins; atomics act in ascending lane order.", """
    rdsr r1, SR_TID
    rdsr r2, SR_LANE_ID
    rdsr r3, SR_WARP_ID
    bnz  r3, done, done
    addi r4, r0, 0x100
    stg  r2, [r4 + 0]       ; all lanes -> word 0x40
    addi r5, r2, 1
    addi r4, r0, 0x104
    atomadd r6, [r4], r5    ; r6 = old value seen by this lane
    atomadd r0, [r4], r5
    atomadd r0, [r4], r5
    atomadd r0, [r4], r5
done:
    exit
""", check=c_order),

    Directed("d28_degenerate_branch", "Divergent bz whose target and fall-through both equal reconv: no entry is pushed.", """
    rdsr r1, SR_TID
    andi r2, r1, 1
    bz   r2, j, j
j:  addi r3, r0, 1
    shli r4, r1, 2
    stg  r3, [r4 + 0x400]
    exit
""", check=c_degenerate),

    Directed("d29_watchdog", "Infinite loop: stopped only by the watchdog (F_WATCHDOG).", """
    rdsr r1, SR_TID
top:
    addi r1, r1, 1
    bra  top
""", fault=isa.F_WATCHDOG, wdog=3000, max_issues=1500),

    Directed("d30_reduce_smem", "Shared-memory tree reduction with barriers; the active set halves each step (if tid < s).", """
    rdsr r1, SR_TID
    addi r2, r0, 37
    mul  r2, r1, r2
    addi r2, r2, 11
    andi r2, r2, 0xFF
    shli r3, r1, 2
    sts  r2, [r3 + 0]
    bar
    addi r5, r0, 16        ; s
step:
    slt  r6, r1, r5
    bz   r6, skip, skip
    shli r7, r5, 2
    add  r7, r7, r3
    lds  r8, [r7 + 0]
    lds  r9, [r3 + 0]
    add  r9, r9, r8
    sts  r9, [r3 + 0]
skip:
    bar
    shri r5, r5, 1
    bnz  r5, step, fin
fin:
    bnz  r1, out, out
    lds  r9, [r0 + 0]
    addi r4, r0, 0xC00
    stg  r9, [r4 + 0]
out:
    exit
""", check=c_reduce),
    Directed("d31_shared_joins", "Same nest, but inner joins coincide with outer ones: those branches REUSE the enclosing entry (depth 5, not 7).", """
    rdsr r1, SR_TID
    rdsr r2, SR_LANE_ID
    andi r3, r2, 1
    andi r4, r2, 2
    andi r5, r2, 4
    addi r6, r0, 1000
    bz   r3, a0, aj
      bz r4, b0, bj
        bz r5, c0, cj
          addi r6, r6, 7
          bra cj
c0:       addi r6, r6, 6
cj:     bra bj
b0:     bz r5, d0, dj
          addi r6, r6, 5
          bra dj
d0:       addi r6, r6, 4
dj:
bj:   bra aj
a0:   bz r4, e0, ej
        bz r5, f0, fj
          addi r6, r6, 3
          bra fj
f0:       addi r6, r6, 2
fj:     bra ej
e0:     bz r5, g0, gj
          addi r6, r6, 1
          bra gj
g0:       addi r6, r6, 0
gj:
ej:
aj: shli r7, r1, 2
    stg  r6, [r7 + 0x400]
    exit
""", cfg=dict(depth=8), check=c_shared_joins),
]


# d32: the d03 nest on a stack of exactly 7 entries: fills it to capacity without overflowing
_d03 = next(t for t in TESTS if t.name == "d03_nested3")
TESTS.append(Directed("d32_exact_capacity", "Three-deep nest on DEPTH=7: the stack is filled exactly to capacity, no fault.",
                      _d03.src, cfg=dict(depth=7), check=c_nested3))


def get(name: str) -> Directed:
    return next(t for t in TESTS if t.name == name)
