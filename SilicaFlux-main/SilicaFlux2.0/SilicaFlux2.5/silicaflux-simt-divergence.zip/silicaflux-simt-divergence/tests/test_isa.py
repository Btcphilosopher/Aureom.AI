"""ISA encoding, decoding, assembler, and RTL/model constant consistency."""
import os
import random
import re

import pytest

from sfdiv import asm, isa

ROOT = os.path.join(os.path.dirname(__file__), "..")


def test_roundtrip_all_formats():
    rng = random.Random(1)
    for o in isa.OPS.values():
        for _ in range(50):
            kw = dict(rd=rng.randrange(16), rs1=rng.randrange(16), rs2=rng.randrange(16))
            f = o.fmt
            if f in ("I", "S"):
                kw["imm"] = rng.randint(-(1 << 17), (1 << 17) - 1)
            elif f == "IS":
                kw["imm"] = rng.randrange(32)
            elif f == "U":
                kw["imm"] = rng.randrange(1 << 22)
            elif f == "B":
                kw["imm"], kw["imm2"] = rng.randint(-1024, 1023), rng.randint(1, 2047)
            elif f == "J":
                kw["imm"] = rng.randint(-(1 << 25), (1 << 25) - 1)
            elif f == "T":
                kw["imm"] = rng.randrange(1 << 16)
            elif f == "SR":
                kw["imm"] = rng.choice(sorted(isa.SR_VALID))
            elif f == "P":
                kw["imm"] = rng.randint(1, 31)
            w = isa.encode(o.name, **kw)
            d = isa.decode(w)
            assert not d.illegal and d.op.name == o.name
            # re-encode from the disassembly at pc 100
            text = isa.disasm(w, 100)
            if f in ("B", "J"):
                continue
            p = asm.assemble(text)
            assert p.words == [w], (text, hex(w), [hex(x) for x in p.words])


@pytest.mark.parametrize("word,why", [
    (0x0000_0001, "reserved bit in Z format"),
    (0xE480_2000, "bz with roff = 0"),
    (0xA840_0009, "rdsr undefined index 9"),
    (0xF000_0000, "pnz length 0"),
    (0x1400_0000, "undefined opcode 0x05"),
    (0x4000_0001, "reserved bit in R format"),
])
def test_illegal_words(word, why):
    assert isa.decode(word).illegal, why


def test_pred_disabled_is_illegal():
    w = isa.encode("pnz", rs1=3, imm=4)
    assert not isa.decode(w, pred_en=True).illegal
    assert isa.decode(w, pred_en=False).illegal


def test_assembler_diagnostics():
    with pytest.raises(asm.AsmError, match="not after the branch"):
        asm.assemble("x: bz r1, x, x\n exit")
    with pytest.raises(asm.AsmError, match="unknown register"):
        asm.assemble("add r16, r1, r2")
    p = asm.assemble("bz r1, b, a\na: nop\nb: exit")
    assert any("beyond its reconvergence" in w for w in p.warnings)


def test_li_forward_reference_is_two_words():
    p = asm.assemble("li r1, later\n exit\nlater: exit")
    assert len(p.words) == 4 and isa.decode(p.words[1]).op.name == "nop"


def test_rtl_constants_match_model():
    """sfd_defs.svh mirrors isa.py: opcodes, fault codes, RPC_NONE width."""
    text = open(os.path.join(ROOT, "rtl", "sfd_defs.svh")).read()
    ops = dict((m.group(1).lower(), int(m.group(2), 16)) for m in re.finditer(r"OP_(\w+)\s*=\s*6'h([0-9a-fA-F]+)", text))
    alias = {"atom": "atomadd"}
    for k, v in ops.items():
        assert isa.OPS[alias.get(k, k)].opcode == v, k
    assert len(ops) == len(isa.OPS)
    faults = dict((m.group(1), int(m.group(2))) for m in re.finditer(r"(F_\w+)\s*=\s*8'd(\d+)", text))
    for k, v in faults.items():
        assert getattr(isa, k) == v, k
    assert re.search(r"localparam int PCW = (\d+)", text).group(1) == str(isa.PCW)
