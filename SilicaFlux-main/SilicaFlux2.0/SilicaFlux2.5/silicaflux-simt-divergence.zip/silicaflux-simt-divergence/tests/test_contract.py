"""Compiler / assembler reconvergence contract (docs/02-compiler-contract.md)."""
import pytest

from sfdiv import asm, cfg, gen, isa, kc, machine, workloads


def test_all_workloads_satisfy_contract_minimally():
    for w in workloads.suite():
        for pred in (False, True):
            k = kc.compile_kernel(w.name, w.body, predicate=pred)
            assert k.contract.ok, k.contract.summary()
            assert not k.contract.warnings, (w.name, k.contract.warnings)
            for b in k.contract.branches:
                assert b.valid and b.minimal == b.reconv


def test_random_kernels_satisfy_contract_and_never_fault_reconv():
    c = isa.Config(lanes=8, warps=4, depth=15)
    for seed in range(120):
        g = gen.random_kernel(seed)
        k = kc.compile_kernel(f"r{seed}", g.body)
        assert k.contract.ok and not k.contract.warnings
        assert all(b.minimal == b.reconv for b in k.contract.branches)
        r = machine.run(c, machine.Launch(k.words, wg_dim=g.wg_dim, gmem=g.gmem))
        assert r.fault is None, (seed, r.fault)


BREAK_LOOP = """
    rdsr r1, SR_TID
    andi r2, r1, 1
    addi r4, r0, 0
top:
    slti r5, r4, 4
    bz   r5, out, out
    bz   r2, endif, {R}
    bra  out
endif:
    addi r4, r4, 1
    bra  top
out:
    exit
"""


def test_break_in_if_must_reconverge_at_loop_exit():
    bad = cfg.check(asm.assemble(BREAK_LOOP.format(R="endif")).words)
    assert not bad.ok and "beyond reconv" in bad.errors[0]
    good = cfg.check(asm.assemble(BREAK_LOOP.format(R="out")).words)
    assert good.ok and not good.warnings


def test_violation_faults_at_runtime_exactly_where_predicted():
    p = asm.assemble(BREAK_LOOP.format(R="endif"))
    r = machine.run(isa.Config(), machine.Launch(p.words, wg_dim=8))
    assert r.fault.code == isa.F_RECONV and r.fault.data == p.symbols["endif"]


def test_late_reconvergence_is_legal_but_reported():
    src = """
    rdsr r1, SR_TID
    andi r2, r1, 1
    bz   r2, join, late
    addi r3, r0, 1
join:
    addi r3, r3, 1
late:
    exit
"""
    rep = cfg.check(asm.assemble(src).words)
    assert rep.ok and rep.warnings and rep.branches[0].minimal == 4


def test_early_exit_join_is_earlier_than_classic_ipdom():
    src = """
    rdsr r1, SR_TID
    slti r2, r1, 5
    bnz  r2, go, go
    exit
go: addi r3, r0, 1
    exit
"""
    rep = cfg.check(asm.assemble(src).words)
    b = rep.branches[0]
    assert b.valid and b.minimal == 4 and b.ipdom == cfg.EXIT_NODE


def test_window_crossing_reconvergence_is_a_static_error():
    src = """
    rdsr r1, SR_TID
    andi r2, r1, 1
    bz   r2, join, join
    pnz  r2, 3
    addi r3, r0, 1
join:
    addi r3, r3, 1
    exit
"""
    rep = cfg.check(asm.assemble(src).words)
    assert any("crosses reconvergence point" in e for e in rep.errors)


def test_window_with_control_is_a_static_error():
    rep = cfg.check(asm.assemble("pnz r1, 2\n addi r2, r0, 1\n exit").words)
    assert any("control instruction" in e for e in rep.errors)


def test_compiler_rejects_break_outside_loop():
    with pytest.raises(ValueError):
        kc.compile_kernel("x", [kc.Break("r1")])


def test_static_bound_holds_for_random_kernels():
    for lanes in (4, 8):
        c = isa.Config(lanes=lanes, warps=2, depth=2 * lanes - 1)
        for seed in range(80):
            g = gen.random_kernel(seed, lanes, 2)
            k = kc.compile_kernel("r", g.body, lanes=lanes)
            r = machine.run(c, machine.Launch(k.words, wg_dim=g.wg_dim, gmem=g.gmem))
            assert max(r.max_sp) <= k.static_bound(lanes)


def test_dead_end_arm_reconverges_at_the_surviving_path():
    """An arm that always exits: the join is lowered to the start of the other arm (no entry for it)."""
    body = kc.ops("rdsr r1, SR_TID; andi r2, r1, 1") + [
        kc.If("r2", [kc.Exit()] + kc.ops("addi r3, r0, 9"), kc.ops("addi r3, r0, 1"))] + \
        kc.ops("shli r4, r1, 2; stg r3, [r4 + 1024]")
    k = kc.compile_kernel("dead", body)
    b = k.contract.branches[0]
    assert b.reconv == b.target == k.program.symbols["else_2"]
    unrefined = kc.compile_kernel("dead", body, refine=False)
    assert unrefined.contract.warnings and unrefined.contract.branches[0].reconv > b.reconv
    for kk in (k, unrefined):
        r = machine.run(isa.Config(), machine.Launch(kk.words, wg_dim=32))
        assert r.fault is None and all(r.gmem[0x100 + t] == (0 if t % 2 else 1) for t in range(32))
    assert max(machine.run(isa.Config(), machine.Launch(k.words, wg_dim=32)).max_sp) == 2
    assert max(machine.run(isa.Config(), machine.Launch(unrefined.words, wg_dim=32)).max_sp) == 3
