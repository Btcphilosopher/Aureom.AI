"""Reconvergence stack: specified scenarios and properties."""
import random

import pytest

from sfdiv.isa import RPC_NONE
from sfdiv.simt import ReconvStack, depth_bound


def test_ifelse_worked_example():
    s = ReconvStack(16)
    s.init(2, 0xFF)
    o = s.branch(cond=0x0F, target=6, reconv=9)            # lanes 0-3 take the branch to else
    assert o.kind == "diverge" and not o.reuse and o.needed == 2
    assert s.snapshot() == [(9, RPC_NONE, 0xFF), (3, 9, 0xF0), (6, 9, 0x0F)]
    assert s.active == 0x0F
    for _ in range(3):
        s.seq()
    assert s.resolve() == [("R", (9, 9, 0x0F))]
    assert s.active == 0xF0
    s.seq(); s.seq(); s.jump(9)
    assert s.resolve() == [("R", (9, 9, 0xF0))]
    assert s.snapshot() == [(9, RPC_NONE, 0xFF)] and s.active == 0xFF


def test_loop_constant_depth():
    """Back-edge `bnz r, 0, 30` at pc 29; one more lane leaves per trip; depth stays 2."""
    s = ReconvStack(16)
    s.init(0, 0xFF)
    mask = 0xFF
    for trip in range(8):
        s.entries[-1][0] = 29
        leaving = 1 << trip
        o = s.branch(cond=mask & ~leaving, target=0, reconv=30)
        mask &= ~leaving
        s.resolve()
        assert s.sp == (2 if mask else 1), (trip, s.snapshot())
        if mask:
            assert o.reuse == (trip > 0)
    assert s.snapshot() == [(30, RPC_NONE, 0xFF)]


def test_overflow_is_precise():
    s = ReconvStack(2)
    s.init(0, 0xFF)
    before = s.snapshot()
    plan = s.plan_branch(cond=0x0F, target=5, reconv=9)
    assert plan.overflow and plan.needed == 2
    o = s.branch(cond=0x0F, target=5, reconv=9)
    assert o.overflow and s.snapshot() == before


def test_exit_drops_dead_entries():
    s = ReconvStack(8)
    s.init(0, 0xFF)
    s.branch(cond=0x0F, target=5, reconv=9)               # (9)(1,9,F0)(5,9,0F)
    s.exit(0x0F)                                           # taken path's lanes exit
    assert s.resolve() == [("X", (5, 9, 0x0F))]
    assert s.active == 0xF0 and s.live == 0xF0
    s.exit(0xF0)
    ev = s.resolve()
    assert [r for r, _ in ev] == ["X", "X"] and s.empty


def test_uniform_branches_never_push():
    s = ReconvStack(1)
    s.init(4, 0x0F)
    assert s.branch(cond=0x0F, target=10, reconv=12).kind == "all-taken" and s.pc == 10
    assert s.branch(cond=0x00, target=2, reconv=12).kind == "none-taken" and s.pc == 11
    assert s.sp == 1


@pytest.mark.parametrize("lanes", [2, 4, 8, 16])
def test_depth_never_exceeds_two_l_minus_one(lanes):
    """Any command stream, however ill-formed, stays within 2L-1 entries."""
    rng = random.Random(lanes)
    full = (1 << lanes) - 1
    worst = 0
    for trial in range(400):
        s = ReconvStack(10_000)
        s.init(rng.randrange(50), full)
        for _ in range(200):
            if s.empty:
                break
            k = rng.random()
            if k < 0.6:
                s.branch(rng.getrandbits(lanes), rng.randrange(60), s.pc + rng.randint(1, 8))
            elif k < 0.75:
                s.seq()
            elif k < 0.85:
                s.jump(rng.randrange(60))
            elif k < 0.9:
                s.exit(s.active & rng.getrandbits(lanes))
            else:
                s.entries[-1][0] = s.rpc if s.rpc != RPC_NONE else s.pc   # force a reconvergence
            s.resolve()
            worst = max(worst, s.max_sp)
            assert s.max_sp <= depth_bound(lanes)


@pytest.mark.parametrize("lanes", [2, 4, 8, 16, 32])
def test_bound_is_tight(lanes):
    """Peeling one lane per nested divergence reaches exactly 2L-1 entries."""
    full = (1 << lanes) - 1
    s = ReconvStack(10_000)
    s.init(0, full)
    for i in range(lanes - 1):
        act = s.active
        low = act & -act
        o = s.branch(cond=act & ~low, target=s.pc + 2, reconv=s.pc + 3)   # taken = all but one lane
        assert o.kind == "diverge" and o.needed == 2 and not o.reuse
        assert not s.resolve()
    assert s.sp == depth_bound(lanes) == 2 * lanes - 1
