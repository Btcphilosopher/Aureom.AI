"""If-conversion legality and equivalence (docs/02 section 6)."""
import pytest

from sfdiv import gen, isa, kc, machine, oracle, workloads
from sfdiv.kc import Bar, Break, DoWhile, Exit, ExitIf, If, Op, While, ops


@pytest.mark.parametrize("arm,reason", [
    ([DoWhile(ops("addi r3, r3, 1; slti r4, r3, 3"), "r4")], "P1"),
    ([Exit()], "P2"),
    ([ExitIf("r3")], "P2"),
    ([Bar()], "P2"),
    ([Break("r3")], "P2"),
    ([Op("addi r12, r0, 1")], "P4"),
    ([If("r3", [If("r4", [If("r5", ops("nop"))])])], "P3"),
])
def test_illegal_conversions_are_refused(arm, reason):
    why = kc.convertible(If("r2", arm))
    assert why is not None and why.startswith(reason), why


def test_legal_nest_is_converted():
    s = If("r2", [If("r3", ops("addi r4, r4, 1"), ops("addi r4, r4, 2"))], ops("addi r4, r4, 3"))
    assert kc.convertible(s) is None
    k = kc.compile_kernel("n", ops("rdsr r2, SR_LANE_ID; andi r3, r2, 2; andi r2, r2, 1") + [s] +
                          ops("rdsr r1, SR_TID; shli r1, r1, 2; stg r4, [r1 + 1024]"), predicate=True)
    assert all(c.converted for c in k.conversions)
    assert not any(isa.decode(w).cls == isa.BRANCH for w in k.words)


def test_converted_kernels_are_equivalent():
    c = isa.Config()
    for w in workloads.suite():
        kb = kc.compile_kernel(w.name, w.body)
        kp = kc.compile_kernel(w.name, w.body, predicate=True)
        L = lambda k: machine.Launch(k.words, wg_dim=w.wg_dim, gmem=w.gmem, args=w.args)
        rb, rp = machine.run(c, L(kb)), machine.run(c, L(kp))
        assert rb.fault is None and rp.fault is None
        assert rb.gmem == rp.gmem and rb.smem == rp.smem, w.name
        for t in range(w.wg_dim):
            assert rb.regs[t // 8][t % 8][:11] == rp.regs[t // 8][t % 8][:11], (w.name, t)


def test_fast_form_only_when_condition_is_preserved():
    # else-arm writes the condition register: the converter must fall back to a saved predicate
    s = If("r2", ops("addi r3, r0, 1"), ops("addi r2, r0, 0; addi r3, r0, 2"))
    k = kc.compile_kernel("f", ops("rdsr r2, SR_LANE_ID; andi r2, r2, 1") + [s] +
                          ops("rdsr r1, SR_TID; shli r1, r1, 2; stg r3, [r1 + 1024]"), predicate=True)
    assert "sltu r12" in k.asm
    r = machine.run(isa.Config(), machine.Launch(k.words, wg_dim=32))
    o = oracle.run_oracle(isa.Config(), machine.Launch(k.words, wg_dim=32))
    assert r.gmem == o.gmem and all(r.gmem[0x100 + t] == (1 if t % 2 else 2) for t in range(32))


def test_random_predicated_equivalence():
    c = isa.Config(lanes=8, warps=4, depth=15)
    for seed in range(80):
        g = gen.random_kernel(seed)
        kb = kc.compile_kernel("r", g.body)
        kp = kc.compile_kernel("r", g.body, predicate=True)
        L = lambda k: machine.Launch(k.words, wg_dim=g.wg_dim, gmem=g.gmem)
        rb, rp = machine.run(c, L(kb)), machine.run(c, L(kp))
        assert rb.gmem == rp.gmem and rb.smem == rp.smem
