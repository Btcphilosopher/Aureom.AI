# 6. Evaluation

All numbers below come from RTL runs (Icarus Verilog, cycle-accurate), each of which was
first verified against the reference model, the per-thread oracle and — for predicated
variants — against the branch variant. The complete tables are generated into
`results/EVALUATION.md` (data: `results/eval.json`, `results/eval.csv`). Unless stated,
configuration **L8W4D8**: 8 lanes, 4 warps (32 threads), stack depth 8.

## 6.1 Metrics

| metric | definition | source |
|---|---|---|
| completion cycles | launch to completion | `perf.cycles` |
| active-lane utilisation | Σ execution-mask lanes / (issued × L) | `lane_slots`, `issued` |
| live utilisation | Σ execution-mask lanes / Σ live lanes (excludes non-existent and exited lanes) | `live_slots` |
| control overhead (issue) | (control instructions `bz bnz bra pz pnz` + predicate set-up) / issued | `ctrl`, trace |
| control overhead (stack) | pops (each costs the popping warp one cycle); **pop-stall** = cycles in which no warp could issue while a pop was pending | `pop_r`, `pop_x`, `pop_stall` |
| stack occupancy | maximum and mean (over issued instructions) depth | `sp_max`, `sp_sum` |

## 6.2 Active-lane utilisation

| family | mean util | mean live util | worst case |
|---|---:|---:|---|
| uniform | 100 % | 100 % | — |
| balanced | 69 % | 69 % | `balanced_k16` 60 % |
| sparse | 60 % | 62 % | `sparse_lane_k32` 30 % |
| nested | 49 % | 49 % | `nested_d3_k4` 30 % |
| loops | 72 % | 72 % | `loop_nested_div_k3` 52 % |
| exits | 73 % | **97 %** | `exit_barrier_k4` 56 % (98 % live) |
| barrier | 92 % | 92 % | — |

* **Balanced divergence** tends to 50 % as the arms grow (81 % → 66 % → 60 % for 2/8/16
  instructions): the two halves run serially and only the common code runs at full width.
* **Nesting** halves leaf utilisation per level (71 % → 47 % → 30 % for d = 1/2/3).
* **Sparse lanes**: one lane per warp on a 32-instruction arm gives 30 %. When the sparse
  condition leaves *whole warps* without a taker (`sparse_tid0`), those warps skip the arm
  through a uniform branch at no cost (56 % instead of 30 %).
* **Exits** cost almost nothing: once a lane exits it is removed from every mask, so live
  utilisation stays at 92–99 %. The lower raw utilisation is lanes that no longer exist.
* **Partial warps** (20 threads): 55 % raw, 66 % live — the empty lanes of warp 2 and the
  empty warp 3 never issue.

## 6.3 Control overhead

*Issue slots.* Control instructions take 2–24 % of issued instructions. The high end is
loop-heavy code with little work per trip (`loop_while_lane_k4` 23 %, `reduce_smem` 24 %);
an if/else costs exactly two control instructions per warp (`bz` + `bra`) however much it
diverges.

*Stack management.* Each pop makes the popping warp wait one cycle. With four warps the
scheduler hides almost all of it: `pop_stall` is 2–7 cycles per kernel (e.g. `nested_d3_k4`:
48 pops, 3 exposed cycles of 313). With one warp nothing hides it (`L8W1D8`): every pop is
exposed (`nested_d3_k4`: 12 pop-stall cycles of 160, 7.5 %).

*Pushes are free*: they are written in the commit cycle of the divergent branch.

## 6.4 Stack occupancy and capacity

* Maximum occupancy over all 26 workloads is **5** (`nested_d3_k4`, `piecewise_k6`); mean
  occupancy is 1.0–3.65. `DEPTH = 8` (240 bits per warp at L = 8) never overflows on
  structured code; the overflow-free `DEPTH = 15` costs 210 more flops per warp (chapter 3).
* Joins that coincide **reuse** the enclosing entry: `nested_d3_k4` needs 5 entries, not the
  `1 + 2·3 = 7` of a nest with distinct joins (`d03_nested3`).
* The compiler's static bound is conservative and never exceeded (worst slack:
  `loop_break_in_if_k3`, bound 10, measured 3, because the bound assumes a pending entry for
  every lane).
* **Capacity sweep** (`results/EVALUATION.md`, last table): running five workloads with
  `DEPTH = 1..8`, every run with `DEPTH < measured maximum` stops with a precise
  `F_STACK_OVERFLOW` at the offending branch; every run with `DEPTH ≥ maximum` completes in
  the same number of cycles. Capacity affects *whether* a kernel runs, never *how fast*.

## 6.5 Completion cycles and configuration

Same 32 threads on 16-lane warps (`L16W2D8`) instead of 8-lane warps: half the warp
instructions, so fewer cycles (`balanced_k8` 137 → 89), with identical utilisation when the
divergence pattern is lane-parity; worse utilisation when divergence is sparse
(`sparse_tid0_k32` 56 % → 38 %), because a wider warp carries more idle lanes on the arm.

## 6.6 Branch handling vs predication (where equivalent)

If-conversion is **legal for 17 of the 26 workloads**: in 15 every `if` is converted (in
`reduce_smem` the surrounding loop naturally stays a branch), in 2 (`nested_d3_k4`,
`piecewise_k6`) only the inner two levels are converted because the outermost level exceeds
the predicate-register budget (rule P3). It is **not** compared for the 9 workloads
whose divergence is in loops, breaks or exits, because a predication window cannot express
a lane-dependent trip count, an exit or a break (`results/EVALUATION.md`, "Not compared").
For every compared pair the predicated RTL run produced exactly the branch run's memory and
program-visible registers.

`speedup` = branch cycles / predicated cycles:

| situation | workloads | L8W4D8 | L8W1D8 (one warp) | why |
|---|---|---:|---:|---|
| uniform condition | `uniform_k4/k16` | 0.82 / 0.67 | 0.79 / 0.64 | predication issues both arms; a uniform branch issues one |
| flat, balanced | `balanced_*`, `nested_d1`, `partial20` | 1.00 | 1.02–1.05 | same issue count (`bz`+`bra` vs two windows); predication saves the two pops, which only matter when they are exposed |
| lane-sparse (every warp has a taker) | `sparse_lane_*` | 0.98–1.00 | 0.99–1.02 | same as balanced |
| warp-sparse (some warps have no taker) | `sparse_tid0_*`, `sparse_data_k16` | 0.62–0.76 | 0.58–1.02 | branches skip the arm in those warps; windows still issue it with an empty mask (with one warp, `sparse_tid0` has its taker in the only warp and behaves like the lane-sparse case) |
| nested | `nested_d2`, `nested_d3`, `piecewise` | 0.80–0.91 | 0.84–0.92 | predicate materialisation (`sltu`/`xori`/`and`) costs more than the pops it saves (overhead 35–38 % vs 17–20 %) |
| reduction | `reduce_smem` | 0.94 | 1.00 | the converted `if (tid < s)` is issued even by warps where no lane takes it |

**Conclusion.** On this core, branch-based divergence handling with the reconvergence stack
never needs more than 1.05× the cycles of predicated execution (flat, balanced `if` on a
single warp), while predicated execution needs **1.06–1.72×** the cycles of branch execution
whenever a condition is uniform within some warps, whole warps skip an arm, or conditions
nest. Predication's genuine advantages
are that converted regions need no stack entries (`sp max` 1 instead of 3–5) and no pop
latency, which pays off only for short, flat, genuinely divergent `if`s on a core with too
few warps to hide pops. It cannot replace branches for loops, breaks or exits.

## 6.7 The cost of IPDOM reconvergence with breaks

`traces/loop_break_in_if_k3.txt` shows the textbook case: an `if` containing `break` must
reconverge at the loop exit, so in warp 0 the single non-breaking lane runs the remaining
loop trips alone (1/8 utilisation) while the seven breaking lanes wait in a pending entry.
A conditional `break` placed directly in the loop body (`loop_break_k3`) avoids the extra
entry. The compiler accounts for the possible accumulation in its static bound (up to `L`
pending entries); the measured peak was 3.

## 6.8 Threats to validity

* Small synthetic kernels (≤ 70 instructions, 32 threads); real kernels have longer straight
  runs, which lowers relative control overhead.
* The LSU is lane-serial, so memory instructions cost one cycle per active lane; this
  rewards sparse execution more than a coalescing memory system would.
* Pop latency (one cycle per entry) is a property of this implementation; a design that
  folds the first pop into the commit cycle would narrow the gap to predication further on
  single-warp workloads.
* Predicate materialisation follows one straightforward scheme (two predicate registers per
  nesting level); a predicate-register file or nested window hardware would reduce the
  nested-case overhead.
