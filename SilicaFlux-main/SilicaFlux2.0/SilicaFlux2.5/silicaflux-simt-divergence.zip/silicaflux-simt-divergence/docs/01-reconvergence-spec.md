# 1. SIMT divergence and reconvergence: normative specification

This chapter specifies **one** reconvergence mechanism for the SilicaFlux SF-G1 GPU:
a per-warp **reconvergence stack driven by compiler-supplied reconvergence points**
(immediate post-dominator reconvergence, "IPDOM"), with the reconvergence address
encoded in every conditional branch. It is the same mechanism SF-G1 describes in its
`docs/03-execution-model.md`; this chapter makes every corner precise enough to build
and verify hardware against, and adds the predication-window extension used for the
evaluation.

**Normative sources, in order of authority:** this text, `model/sfdiv/simt.py`
(command semantics), `model/sfdiv/machine.py` (instruction semantics). Where prose and
code disagree, the code is right and the prose is a bug. The RTL
(`rtl/sfd_simt_stack.sv`, `rtl/sfd_core.sv`) is verified against the code
instruction-by-instruction (chapter 5).

---

## 1.1 Terms

| Term | Meaning |
|---|---|
| lane | one of the `L` SIMD positions of a warp (`L` = `LANES`, default 8) |
| thread | the program instance bound to one lane of one warp; `tid = warp * L + lane` |
| warp | `L` lanes that share one instruction stream and one reconvergence stack |
| path | a set of lanes executing the same instruction sequence after a divergence |
| entry | a reconvergence-stack record `(pc, rpc, mask)` |
| reconvergence point `R` | the instruction at which diverged paths of one branch meet again |
| `RPC_NONE` | `0x7FF`: "no reconvergence point" (bottom entry only) |

## 1.2 Per-warp masks

Each warp has three lane masks. They govern different things and are never confused:

| Mask | Definition | Governs |
|---|---|---|
| **live** | lanes whose thread has not executed `exit` | barrier participation; which entries are dead |
| **active** | `top.mask & live` | the current path; branch evaluation; `bar` legality |
| **execution** | `active & pmask` inside a predication window, else `active` | which lanes an instruction *acts* in |

Rules that hold for every instruction:

* **E1** An instruction reads and writes registers, and performs memory accesses, **only in
  execution-mask lanes**. A lane outside the execution mask has *no* architectural effect:
  no register write, no memory access, no fault (its address is not even checked).
* **E2** `live` never gains a lane during a launch.
* **E3** `exec ⊆ active ⊆ live ⊆ bottom.mask` (= the launch mask).
* **E4** An instruction with an empty execution mask (possible only in a predication
  window) issues, advances the pc, and has no other effect.

At launch each warp gets `live = {lanes l : warp*L + l < wg_dim}` and a single entry
`(ENTRY_PC, RPC_NONE, live)`. A warp whose launch mask is empty starts *done*.

## 1.3 Stack state and capacity

A warp's stack holds at most `DEPTH` entries (RTL parameter `DEPTH`, model `Config.depth`).
`sp` is the number of entries; the top entry is `entries[sp-1]`.

* the **top** entry is the executing path: its `pc` is the warp's PC;
* entries below the top are either **pending paths** (waiting to run) or **reconvergence
  entries** (whose `pc` is a reconvergence point, waiting for the paths above them).

A warp is **done** when its stack is empty. That implies `live = 0` (the bottom entry can
only be removed when it has no live lane, because its `rpc` is never reached).

## 1.4 Commands

Every committed instruction applies exactly **one** command to its warp's stack:

| Command | Issued by | Effect |
|---|---|---|
| `SEQ` | all instructions except the four below (`bar`, `pz`/`pnz` and memory instructions included) | `top.pc ← top.pc + 1` |
| `JUMP t` | `bra` | `top.pc ← t` |
| `BRANCH c, t, R` | `bz`, `bnz` | §1.5 |
| `EXIT` | `exit` | `live ← live & ~active` |

`trap` and every faulting instruction apply no command (faults are precise, §1.12).

## 1.5 Branch evaluation and path selection

`bz rs, target, reconv` / `bnz rs, target, reconv` (encoding: SF-G1 format B; `target =
pc + sext(toff11)`, `R = pc + roff11`, `roff ≥ 1`).

**Evaluation.** For every *active* lane `i`, the lane is **taken** iff `rs[i] == 0` (`bz`)
or `rs[i] != 0` (`bnz`). Inactive lanes are not evaluated. Let `pc` be the branch, and

```
act = top.mask & live      T = act & cond      N = act & ~cond
```

**Static checks** (every execution, taken or not, divergent or not): `0 ≤ target <
CODE_WORDS` else `F_PC_RANGE(target)`; then `R < CODE_WORDS` else `F_PC_RANGE(R)`.

**Path selection:**

```
if T == 0:  top.pc ← pc + 1                    # uniform: nobody takes it
elif N == 0: top.pc ← target                   # uniform: everybody takes it
else:                                          # DIVERGENCE
    paths = []
    if pc + 1 != R:  paths.append((pc+1,  R, N))    # fall-through path: pushed first, runs second
    if target != R:  paths.append((target, R, T))   # taken path: pushed last, ON TOP, runs first
    reuse  = (top.rpc == R)
    needed = max(len(paths) - 1, 0) if reuse else len(paths)
    if sp + needed > DEPTH:  fault F_STACK_OVERFLOW(sp)          # precise, nothing changes
    if reuse:
        if paths: replace top with paths[0]; push paths[1:]
        else:     top.pc ← R
    else:
        top.pc ← R                             # top becomes the reconvergence entry
        push all paths
```

* **Order.** The taken path runs first, the fall-through path second. Software cannot
  observe the order in a race-free program (§1.11), but it is fixed so that the RTL and the
  model produce identical traces.
* **Paths that start at `R`** need no entry: those lanes simply wait in the entry below.
  This covers `if (c) {A}` (`target == R`), loop exits (`pc + 1 == R`) and the early-exit
  idiom.
* **Reuse.** If the top already reconverges at `R`, the lanes not on either new path are
  already waiting in an entry below, so no new reconvergence entry is created. This keeps
  loops at constant depth (§1.8) and lets nested branches that share a join point share
  one reconvergence entry (§1.7).

## 1.6 Reconvergence

After every command the stack is **resolved**:

```
while sp > 0 and (top.pc == top.rpc  or  top.mask & live == 0):  pop
```

* `top.pc == top.rpc` (**reconvergence pop**, trace reason `R`): the path reached its
  reconvergence point; the entry below is either the next pending path or the reconvergence
  entry, whose `pc` is `R` and whose mask is the union of the lanes that diverged.
* `top.mask & live == 0` (**dead pop**, reason `X`): every lane of the entry has exited.

Resolution is architectural only in its settled result. The RTL pops **one entry per
clock** and a warp cannot issue while its top needs a pop; each pop is one cycle of latency
for that warp (other warps may issue meanwhile). This is the "control overhead" measured
in chapter 6.

**Fetch-time layout check.** Before an instruction executes, if `top.rpc != RPC_NONE` and
`top.pc > top.rpc`, the warp faults with `F_RECONV(top.rpc)`. A path can only get past its
reconvergence point if the reconvergence operand was wrong (chapter 2); the fault turns
that compiler bug into a precise, diagnosable event instead of silently wrong execution.

Fetch checks, in order: `pc ≥ CODE_WORDS` → `F_PC_RANGE(pc)`; the layout check →
`F_RECONV`; illegal encoding → `F_ILLEGAL_INSN(word)`; a control instruction inside a
predication window → `F_PRED_WINDOW(word)`.

## 1.7 Nested divergence

A divergent branch on a path pushes on top of that path. Without reuse each nesting level
adds at most two entries, so `d` levels of if/else need `1 + 2d` entries
(`tests/directed.py: d03_nested3` reaches 7 with `d = 3`, and `d32_exact_capacity`
runs that program on `DEPTH = 7` without overflow). When an inner join coincides with an
outer join (same address), the inner branch **reuses** the enclosing entry and adds at
most one (`d31_shared_joins`: same nest, depth 5).

## 1.8 Loops

| Construct | Lowering (chapter 2) | Stack behaviour |
|---|---|---|
| `do {B} while (c)` | `L: B; bnz c, L, X; X:` | first divergence: top becomes `(X,…)`, continuing lanes pushed as `(L, X, T)`; every later divergence of the back-edge **reuses** that entry. Depth +1, constant across trips. |
| `while (c) {B}` | `L: c; bz c, X, X; B; bra L; X:` | first divergence: leaving lanes wait at `X`, continuing lanes pushed `(pc+1, X, N)`; later trips reuse. Depth +1. |
| `break` (conditional) | `bnz b, X, X` | breaking lanes go to `X` = the loop's reconvergence point: no entry; the continuing path is reused. Depth +0. |
| `if` containing `break` | `bz c, L_end, X` (R = loop exit, **not** `L_end`) | required by the contract (lanes that break never pass `L_end`); see below |
| `continue` | forward `bra` to the loop latch | must be a *forward* jump: with a backward jump to the header, the join of the enclosing `if` would be the header, which precedes the branch and cannot be encoded (`roff ≥ 1`) |

**Break inside an `if`.** Because such an `if` reconverges at the loop exit, the lanes that
do not break run the *rest of the loop* as their own path; the breaking lanes wait in a
pending entry. Each trip on which some lanes break can leave one more pending entry; they
all share the loop's reconvergence entry and have disjoint, non-empty masks, so at most
`L` of them exist. This is the known cost of IPDOM reconvergence with unstructured exits;
`loop_break_in_if_k3` measures it (chapter 6). A conditional `break` placed directly in
the loop body costs nothing.

## 1.9 Early thread termination

`exit` removes the active lanes from `live` (command `EXIT`). Consequences:

* exited lanes are ignored by every entry from then on (`active = top.mask & live`);
* an entry left with no live lane is popped by resolution (dead pop), so a path whose lanes
  all exit simply ends and the next pending path (or reconvergence entry) runs;
* lanes that exit inside one arm never arrive at the join; the others reconverge without
  them; no entry is reserved for them;
* the early-exit idiom `bnz ok, go, go; exit; go:` reconverges at `go`, not at the end of
  the kernel (chapter 2 explains why this is the minimal valid point although the classic
  IPDOM is the kernel exit);
* a warp whose lanes have all exited is **done**; done warps do not take part in barriers
  (§1.10), so an exit can never deadlock a barrier.

## 1.10 Barriers (unchanged from SF-G1)

* **Arrival.** `bar` is legal only when `active == live` (the warp is fully reconverged);
  otherwise `F_BAR_DIVERGENT(live)`. On arrival the warp advances past `bar` (`SEQ`) and
  waits.
* **Release.** When every warp that is not done is waiting, all waiting warps become
  issuable together. The condition is re-evaluated whenever a warp becomes done.
* **Memory.** A barrier is a release/acquire for the workgroup: all memory accesses of all
  threads before it are visible to all threads after it. In this core every warp has at
  most one instruction in flight and an instruction leaves the LSU before its warp can issue
  again, so every pre-barrier access is complete when the last warp arrives.
* Divergence handling never changes barrier behaviour: predication windows may not contain
  `bar` (§1.13), and the compiler never if-converts a region containing one (chapter 2).

## 1.11 Memory ordering

The mechanism preserves exactly the SF-G1 ordering rules (SF-G1 `docs/04-memory.md`, C1–C8):

* **Program order per thread (C2).** A lane belongs to exactly one path at a time and paths of
  one warp execute serially, so every thread executes its own instructions in program order;
  divergence never reorders a thread's memory accesses.
* **Within one warp instruction (C3).** All execution-mask lanes' addresses are checked
  first (precise fault: lowest failing lane; misalignment before range). Then the lanes are
  performed one at a time in **ascending lane order**: for same-address stores the highest
  lane's value remains; `atomadd` lane `i` observes the additions of lower lanes. Inactive
  lanes perform nothing (E1).
* **Between diverged paths of one warp.** The taken path's accesses precede the
  fall-through path's. Accesses by different threads on different paths are unordered by
  the architecture (two such accesses to one word with a store are a data race); the fixed
  order only makes runs reproducible.
* **Between warps.** The LSU performs warp instructions one at a time in issue order (stronger
  than required). `fence` therefore needs no extra action; `bar` orders as above (C4).
* **After a fault** memory is unspecified; the faulting instruction itself has no effect.

## 1.12 Stack capacity and overflow

**Bound.** For *any* command stream the depth never exceeds `2L − 1`: every divergence
splits the active lanes into two non-empty disjoint groups and every entry above a
reconvergence entry covers a distinct non-empty lane group, so the entries form a binary
tree over at most `L` lanes, which has at most `2L − 1` nodes. The bound is tight
(`tests/test_simt.py::test_bound_is_tight`: peeling one lane per nested divergence reaches
exactly `2L − 1`) and is property-tested on random command streams.
**`DEPTH ≥ 2L − 1` makes overflow impossible** (15 entries for 8 lanes).

Smaller stacks are legal and cheaper (one entry = `2·11 + L` bits per warp; chapter 3).
Compiled structured code needs far less than the bound; the compiler reports a conservative
static bound per kernel (chapter 2, §2.5), and the evaluation measures actual occupancy.

**Overflow behaviour.** A divergent branch that needs more entries than remain raises
**`F_STACK_OVERFLOW`, `FAULT_DATA = sp`** (the depth before the branch). The fault is
precise: the branch has no effect, no entry is written, no mask changes. As for every
execution fault, the launch stops (no further instruction issues; an LSU operation of
another warp may be abandoned; memory is then unspecified) and the fault record — code,
warp, pc, lowest active lane, active mask, data — is latched. There is no silent
degradation: no spilling, no forced serialisation, no dropped reconvergence point. A
deployment that cannot tolerate the fault either configures `DEPTH ≥ 2L − 1` or rejects
kernels whose static bound exceeds `DEPTH` at compile time.

## 1.13 Predication windows (SFX-PRED extension)

Used to compare branch-based divergence with predicated execution. Opcodes `0x3B` (`pz`)
and `0x3C` (`pnz`), format P: `[31:26]` opcode, `[25:22]` `rs1`, `[21:5]` reserved (zero),
`[4:0]` `n` (1..31; `n = 0` is illegal). With the extension disabled (`PRED_EN = 0`) both
opcodes are illegal, exactly as in SF-G1.

`pz rs, n` / `pnz rs, n` at `pc`:

* **W1** `pmask ← exec & {lanes with rs == 0 (pz) / != 0 (pnz)}`, `pcount ← n`; command `SEQ`.
* **W2** Each of the next `n` instructions the warp executes runs with execution mask
  `active & pmask` (E1, E4 apply); `pcount` decrements after each.
* **W3** Window instructions must not be control instructions (`bra bz bnz exit bar trap pz
  pnz`): such an instruction faults with `F_PRED_WINDOW(word)` (precise).
* **W4** The window must end before the current path's reconvergence point:
  if `top.rpc != RPC_NONE` and `pc + n ≥ top.rpc`, the `pz/pnz` itself faults with
  `F_PRED_WINDOW(word)`. (Otherwise a pop inside the window would hand the window to a
  different path.)
* **W5** A window never touches the reconvergence stack.

## 1.14 Faults added or refined

| Fault | Code | Divergence-related cause | `FAULT_DATA` |
|---|---:|---|---|
| `F_RECONV` | 18 | a path's pc passed its reconvergence point (wrong `reconv` operand) | the reconvergence point |
| `F_STACK_OVERFLOW` | 23 | divergent branch needs more entries than remain | `sp` before the branch |
| `F_BAR_DIVERGENT` | 24 | `bar` while `active != live` | `live` |
| `F_PRED_WINDOW` | 27 | control instruction in a window, or a window crossing `top.rpc` | instruction word |

All other SF-G1 faults are unchanged. `FAULT_LOC.lane` is the lowest failing lane for
memory faults and the lowest active lane otherwise; `FAULT_MASK` is the active mask.

## 1.15 Forward progress

Diverged paths of one warp execute serially and the order is fixed. A lane must never wait
for another lane of the *same warp* on a different path (for example a spin lock): the
waiting path may run first and never yield. There is no forward-progress guarantee between
diverged lanes of a warp (as in SF-G1); warps of a workgroup make progress independently.

## 1.16 Worked example (from `traces/d02_ifelse.txt`, RTL cycles)

```
 2: bz  r2, 6, 9        ; even lanes (r2 == 0) take the branch to `else` at 6
 3..5: then-arm, ends with bra 9
 6..8: else-arm
 9: endif
```

| cycle | event | stack (top first) | active |
|---:|---|---|---|
| 9 | `bz` diverges: taken {0,2,4,6} → 6, fall {1,3,5,7} → 3, R = 9; not reuse | `(6,9,#.#.#.#.) (3,9,.#.#.#.#) (9,-,########)` | `#.#.#.#.` |
| 13–21 | else-arm runs | | `#.#.#.#.` |
| 22 | pop: else path reached 9 | `(3,9,.#.#.#.#) (9,-,########)` | `.#.#.#.#` |
| 25–33 | then-arm runs, `bra 9` | | `.#.#.#.#` |
| 34 | pop: then path reached 9 | `(9,-,########)` | `########` (reconverged) |
