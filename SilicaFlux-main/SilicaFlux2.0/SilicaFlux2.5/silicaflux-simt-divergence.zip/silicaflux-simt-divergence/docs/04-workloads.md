# 4. Workloads

Two generators feed the verification and the evaluation. Both emit *structured* kernels in
the language of `kc.py`, so every kernel is compiled with reconvergence points chosen by the
compiler and checked by the contract checker, and can be lowered both with branches and
(where legal) with predication from the same source.

## 4.1 Evaluation workloads (`model/sfdiv/workloads.py`)

32 threads (4 warps × 8 lanes) unless stated; each thread stores one result word, so every
run can be checked against the per-thread oracle. `k` is the number of instructions in an
arm / loop body.

| family | workload | divergence pattern | what it exercises |
|---|---|---|---|
| **uniform** | `uniform_k4`, `uniform_k16` | `if/else` on warp parity | branch never diverges; predication must still run both arms |
| **balanced** | `balanced_k2/8/16` | `if/else` on lane parity: every warp splits 4/4 | two-path serialisation, both arms per warp, two pops |
| | `balanced_data_k8` | `if/else` on a random data bit (~50 %) | data-dependent, uneven per-warp splits |
| **sparse** | `sparse_lane_k8/k32` | only lane 0 of each warp runs the arm | 1/8 utilisation on the long path |
| | `sparse_tid0_k8/k32` | only thread 0 of the workgroup runs the arm | three warps skip the arm *uniformly* |
| | `sparse_data_k16` | ~1/8 of threads by data | irregular sparse activity |
| | `partial20_k8` | lane-parity `if/else`, 20 threads | partially populated warps (warp 2 half, warp 3 empty) |
| **nested** | `nested_d1/d2/d3_k4` | `if/else` nested 1–3 deep on lane bits 0..2 | stack growth, leaf utilisation 1/2^d, coinciding joins |
| | `piecewise_k6` | 4-way `else-if` chain on data | chained conditionals (nesting in the else arm) |
| **loops** | `loop_uniform_n4_k4` | do-while, 4 trips for all | uniform back-edge: no divergence |
| | `loop_while_lane_k4` | while, trip count = lane id (0..7) | per-lane trip counts, constant depth via reuse |
| | `loop_nested_div_k3` | outer trips 1..4 (tid) × inner trips 1..4 (data) | **nested divergent loops** |
| | `loop_break_k3` | search loop, conditional `break` | breaking lanes wait at the loop exit, no entry |
| | `loop_break_in_if_k3` | the same search with the break inside an `if` | IPDOM `if` reconverging at the loop exit; pending entries |
| **exits** | `exit_guard_n20_k8`, `exit_guard_n4_k8` | `if (tid ≥ n) exit` | early termination; whole warps exiting (n = 4) |
| | `exit_in_loop_k3` | threads exit inside a loop when they find a match | **thread exits** mid-loop, dead-entry pops |
| | `exit_barrier_k4` | ¾ of threads exit, the rest exchange via shared memory across a barrier | barrier participation after exits |
| **barrier** | `reduce_smem` | shared-memory tree reduction | barrier in a uniform loop, divergent `if (tid < s)` between barriers |

The requested categories map as follows: uniform branches → *uniform*; balanced divergence →
*balanced*; sparse active lanes → *sparse* (plus `exit_*`, whose survivors are sparse);
nested loops → `loop_nested_div_k3` (and the nested `if` family); thread exits → *exits*.

## 4.2 Random structured kernels (`model/sfdiv/gen.py`) — verification only

Random nests of `If` (with and without `else`), `While`, `DoWhile` (counter-bounded, up to
two loop levels), conditional `Break`, `ExitIf`, `Exit` inside arms, ALU instructions of every
kind, `rdsr`, global loads (read-only input), per-thread global stores, `atomadd` with
discarded result, per-thread shared-memory slots, and top-level barrier phases with a
neighbour exchange through shared memory. Conditions mix lane-dependent, data-dependent and
warp-uniform tests. Workgroup sizes include full, partial and single-thread workgroups.

Each kernel is **terminating**, **race-free** and **barrier-correct** by construction, which is
what makes the per-thread oracle, the SIMT model (under any schedule), the predicated variant,
the RTL and the SF-G1 reference model comparable result-for-result.
