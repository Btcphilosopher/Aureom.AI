# 5. Verification

## 5.1 Strategy: four independent references

```
   structured source ──kc.py──► binary ──cfg.py──► contract verdict (static)
                                   │
          ┌────────────────────────┼─────────────────────────┬──────────────────────────┐
          ▼                        ▼                         ▼                          ▼
  per-thread oracle         SIMT reference model         RTL (Icarus, assertions on)   SF-G1 reference model
  (oracle.py: no warps,     (machine.py + simt.py)       (rtl/ + tb/)                  (the existing silicaflux-sf-g1,
   no masks, no stack)                                                                   via its host API)
          │   per-thread regs     │   lock-step: every commit,  │                          │
          └───── + memory ────────┤   every memory access,      │                          │
                                  │   final state, counters ────┘                          │
                                  └──────────── global memory, fault records, issue counts ┘
```

* **Oracle vs model** proves the *mechanism* preserves per-thread architectural results:
  the oracle defines each thread's result with no notion of masks or reconvergence.
* **Model vs RTL** proves the *hardware* implements the mechanism exactly, at instruction
  granularity: the RTL's warp order is replayed on the model, then the commit streams
  (warp, pc, word, execution/active/live masks, the full settled stack, predication-window
  state), the global memory-access streams (warp, lane, space, kind, address, data), the
  pop sequences per warp, the final registers and memories, the fault records and the
  hardware performance counters must all be identical.
* **Model vs SF-G1** proves the semantics are those of the SilicaFlux GPU specification,
  not merely self-consistent (`tools/xcheck_sfg1.py`).
* **Contract checker** proves compiler output can never reach `F_RECONV`.

## 5.2 What was run (final numbers)

| Check | Scope | Result |
|---|---|---|
| model unit + property tests (`make test`) | ISA round-trips and illegal words, stack scenarios, the `2L−1` bound (random streams, and tightness for L = 2..32), precise overflow, contract checker, compiler lowering, static bound, if-conversion legality, directed kernels, oracle equivalence on 180 random kernels (3 configurations) with stack invariants checked after every instruction, schedule independence, no side effects in inactive lanes | 85 passed |
| directed kernels, model **and** RTL (`tests/directed.py`) | 32 kernels, one per behaviour (table below) | 32/32 RTL = model |
| RTL pytest suite (`tests/test_rtl.py`) | directed kernels, random kernels on L8W4D8 and L4W2D3, four workloads in both lowerings | 44 passed |
| random structured kernels, RTL vs model vs oracle (`tools/rtl_random.py`) | branch and predicated lowering; 6 configurations: L8W4D8, L4W2D7, L16W2D31, L8W1D15, L8W3 without SFX-PRED, and L8W4D3 where stacks overflow and the precise fault record must match | **275/275** in the final run (6 precise overflow faults matched exactly), plus 360/360 in an earlier run |
| evaluation runs (`tools/evaluate.py`) | 26 workloads × 2 lowerings × 3 configurations + 40 capacity-sweep runs, each verified before its numbers are used | 129 + 40 verified |
| RTL mutation testing (`tools/mutate.py`) | 24 injected divergence / masking / barrier / LSU bugs | **24/24 killed** (`results/mutation.md`) |
| SF-G1 cross-check (`tools/xcheck_sfg1.py`) | 23 directed (default stack size, no SFX-PRED, no watchdog) + 26 workloads + 150 random kernels on the original SF-G1 reference model | **199/199 agree** (`results/xcheck_sfg1.log`) |
| lint (`tools/lint.sh`) | Verilator 5.020 `-Wall`, 4 configurations incl. `WARPS=1, DEPTH=1` and `PRED_EN=0` | clean |
| synthesis (`tools/synth.sh`) | Yosys 0.33 generic: stack sweep, core L4W2D7 and L8W4D8 | synthesises (chapter 3) |

## 5.3 Directed kernels

| test | behaviour |
|---|---|
| d01_uniform_branch | warp-uniform branch: never diverges, no entry |
| d02_ifelse | SF-G1 worked example: exact stack contents after the divergent branch |
| d03_nested3 | 3-deep nest: depth 1 + 2·3 = 7 |
| d04_dowhile_reuse | per-lane trip counts: back-edge reuse, constant depth 2 |
| d05_while_top_test | while loop, test at the top |
| d06_nested_loops | nested divergent loops |
| d07_break | conditional break from a search loop |
| d08_exit_early | guard exit; reconvergence at the join; exited lanes never execute again |
| d09_exit_in_arm | exit inside one arm; survivors reconverge |
| d10_exit_cascade | all lanes exit inside their paths; dead entries popped; join never reached |
| d11_exit_warp_barrier | whole warps exit; the barrier still releases |
| d12_barrier_loop | barrier in a uniform loop with divergence between barriers |
| d13_partial_warp | partially populated / empty warps |
| d14_sparse_lane | one active lane on a long path |
| d15_overflow | `F_STACK_OVERFLOW` on `DEPTH = 4`, data = depth, precise |
| d16_reconv_violation | wrong reconvergence operand → `F_RECONV` with the right data |
| d17_bar_divergent | `F_BAR_DIVERGENT` with the live mask |
| d18 / d19 | `F_PRED_WINDOW`: control in a window; window crossing the reconvergence point |
| d20_pred_basic, d21_pred_empty | predication windows; empty predicate does nothing |
| d22_mem_fault_priority | lowest failing lane, misalignment before range, nothing performed |
| d23_inactive_bad_addr | inactive lanes with invalid addresses neither fault nor store |
| d24 / d25 / d26 | illegal word, fall off the code, trap |
| d27_lane_order | highest lane wins same-address stores; atomics ascending |
| d28_degenerate_branch | divergent branch whose both successors are the join |
| d29_watchdog | infinite loop stopped by the watchdog |
| d30_reduce_smem | shared-memory tree reduction with barriers |
| d31_shared_joins | coinciding joins: branches reuse the enclosing entry (depth 5 instead of 7) |
| d32_exact_capacity | stack filled exactly to `DEPTH = 7`, no fault (kills off-by-one capacity bugs) |

## 5.4 RTL assertions (`+define+SFD_ASSERT`, on in every simulation here)

| id | module | property |
|---|---|---|
| S1 | stack | `sp ≤ DEPTH` |
| S2 | stack | commands only reach a non-empty, settled stack |
| S3 | stack | an overflowing branch is never committed (the core faults instead) |
| S4 | stack | bottom entry has `rpc = RPC_NONE`; `live ⊆ bottom.mask` |
| S5 | stack | every entry's mask ⊆ bottom mask |
| S6 | stack | `EXIT` retires only active lanes |
| S7 | stack | a lane that has exited never becomes live again |
| L0 | LSU | never started with an empty mask |
| L1 | LSU | every access belongs to an execution-mask lane (**no side effects for inactive lanes**) |
| L2 | LSU | strictly ascending lane order, each lane once |
| L3 | LSU | an instruction completes only after every execution-mask lane was performed |
| C1 | core | execution mask ⊆ active; inside a window ⊆ predicate |
| C2 | core | register writes only for execution-mask lanes |
| C3 | core | the executing warp's stack is settled and the warp is in flight |
| C4 | core | only eligible, not-in-flight warps are selected |
| C5 | core | register-file write ports never target the same warp |
| C6 | core | a waiting warp never issues; arrival only with `active == live`; release never races an arrival (**barrier behaviour**) |
| C7 | core | no control instruction commits inside a window |
| C8 | core | a done warp has no live lane, nothing in flight, no barrier wait |
| C9 | core | no instruction commits at or beyond its path's reconvergence point |
| C10 | core | while running, memory is written only by an LSU access |

Assertions are immediate checks in `always` blocks guarded by `` `ifndef SYNTHESIS `` /
`` `ifdef SFD_ASSERT `` (portable to Icarus and Verilator); they stop the simulation with
`$fatal`, which the Python runner reports as a failure. In the mutation campaign 11 of the
24 bugs were first caught by an assertion, the other 13 by the model comparison.

## 5.5 Reproducing

```
make test        # model level, seconds
make rtl         # directed + random + workload RTL runs
make lint
make eval        # verified evaluation runs + results/EVALUATION.md
make mutate      # results/mutation.md
make xcheck SFG1=/path/to/silicaflux-sf-g1     # needs the SF-G1 tree (silicaflux-sf-g1.zip)
```

## 5.6 Not verified

* no formal proof (the stack bound and the contract argument are proofs on paper plus
  property tests, not machine-checked);
* no gate-level simulation, no timing analysis (no target library);
* Verilator was used for lint only; all simulation is Icarus Verilog 12;
* one workgroup per launch on one execution group (multi-EG dispatch is out of scope).
