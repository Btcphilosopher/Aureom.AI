# 2. The reconvergence contract between compiler/assembler and hardware

The hardware of chapter 1 does not discover reconvergence points: it **trusts the
`reconv` operand of every `bz`/`bnz`**. The contract below says what a producer of code
(compiler, assembler programmer) must guarantee, what the tools check, and what the
hardware does when the guarantee is broken.

| Layer | What it guarantees / checks | Implementation |
|---|---|---|
| structured compiler | chooses every `R` by construction, then lowers it to the minimal valid point (§2.2) | `model/sfdiv/kc.py` |
| assembler | encodability: `R > pc`, offsets in range; warns when `target > R` | `model/sfdiv/asm.py` |
| contract checker | validity and minimality of every `R` on the binary, window rules (§2.3) | `model/sfdiv/cfg.py` |
| hardware | `F_RECONV` the moment a path overruns its `R`; `F_PRED_WINDOW` for bad windows | `rtl/sfd_core.sv` |

`kc.compile_kernel` runs the checker on everything it emits and refuses to return a
kernel that violates the contract, so compiled code never reaches the hardware's
safety net. Hand-written assembly gets the same checker via `cfg.check`.

## 2.1 The contract

For every conditional branch at `b` with taken target `t`, fall-through `b+1` and
reconvergence operand `R`:

* **C1 (encoding)** `b < R < CODE_WORDS`, `0 ≤ t < CODE_WORDS`.
* **C2 (region closure)** Let `REGION(b, R)` be the instructions reachable from `t` or
  `b+1` *without passing through `R`*, where `exit` and `trap` end a path. Every instruction
  in the region has `pc < R` and no path falls off the end of the code.
* **C3 (windows)** The `n` instructions after a `pz/pnz` exist, are not control
  instructions, and if the window lies in some `REGION(b, R)` it ends before `R`.

**Why C2 is the right condition.** A path pushed by `b` carries `rpc = R`. The path's
lanes execute exactly the instructions of `REGION(b, R)` until they reach `R` (pop) or
exit. If every region instruction lies below `R`, the fetch check `pc > rpc` can never fire
and every lane that does not exit arrives at `R`, where the reconvergence entry (pc `R`,
all diverged lanes) resumes them together. Nested branches inside the region have their own
regions inside it, so their `R'` is in `REGION(b,R) ∪ {R}`, i.e. `R' ≤ R`, and the
argument applies recursively. Conversely, if some region instruction lies beyond `R`, a
path can reach it without meeting `R`: that is precisely an `F_RECONV`.

**Minimality.** `R` is *minimal* when no smaller address satisfies C2. A valid but
non-minimal `R` is legal; it only keeps lanes serialised longer (reported as a warning).
The checker reports the minimal value for every branch.

**Relation to the classic immediate post-dominator.** On the CFG with a virtual exit node,
the minimal valid `R` equals the classic IPDOM except where a path ends in `exit`: for
`bnz ok, go, go; exit; go:` the classic IPDOM is the *kernel exit*, while the contract
allows `go`, because the exiting lanes never need to arrive anywhere. Reconverging at the
kernel end would make the surviving lanes run the whole rest of the kernel with one extra
stack entry. The checker prints both (`tests/test_contract.py::test_early_exit_join_is_earlier_than_classic_ipdom`).

**Layout consequence.** C2 implies `t ≤ R` for forward branches and that every structured
region is laid out between its branch and its join.

## 2.2 Lowering of structured control flow (`kc.py`)

| Statement | Lowering | `R` |
|---|---|---|
| `If(c, A, B)` | `bz c, Lelse, R` · A · `bra Lend` · `Lelse:` B · `Lend:` | `Lend` |
| `If(c, A)` | `bz c, Lend, R` · A · `Lend:` | `Lend` |
| `If(c, [], B)` | `bnz c, Lend, R` · B · `Lend:` | `Lend` |
| `While(pre, c, B)` | `Ltop:` pre · `bz c, Lexit, Lexit` · B · `bra Ltop` · `Lexit:` | `Lexit` |
| `DoWhile(B, c)` | `Ltop:` B · `bnz c, Ltop, Lexit` · `Lexit:` | `Lexit` |
| `Break(c)` | `bnz c, Lexit, Lexit` (unconditional: `bra Lexit`) | innermost `Lexit` |
| `ExitIf(c)` | `bz c, Lgo, Lgo` · `exit` · `Lgo:` | `Lgo` |
| `Exit()` / `Bar()` | `exit` / `bar` | — |

**The break rule.** An `If` whose arms contain a `Break` of the enclosing loop (looking
through nested `If`s but not into nested loops) uses `R = Lexit` of that loop, because lanes
that break never pass `Lend`. Using `Lend` violates C2 (the break path reaches `Lexit > Lend`)
and faults with `F_RECONV` at run time (`tests/directed.py: d16_reconv_violation`, and
`tests/test_contract.py::test_violation_faults_at_runtime_exactly_where_predicted`, which
checks that the fault data is exactly the `R` the checker flagged).

**Exits** need no special rule: exiting lanes never arrive, so `R` stays `Lend`.

**Refinement to the minimal point.** The structural rule above is minimal for every evaluation
workload. It is not minimal when an arm *always* terminates — for example an arm that starts
with `exit`: then nothing but the other arm reaches `Lend`, and the minimal join is the first
instruction of that other arm (its lanes then need no path entry at all). `compile_kernel`
therefore runs the checker on the lowered code and rewrites any `reconv` operand to the
checker's minimal valid address (`refine=True`, the default; the code layout does not change).
On 1,800 random kernels (4/8/16 lanes, both lowerings) 196 had such an operand before
refinement and none after; `tests/test_contract.py::test_dead_end_arm_reconverges_at_the_surviving_path`
shows the effect (peak stack 2 instead of 3).

**Barriers** are emitted only where the source places them. The compiler does not prove
that a `Bar` is reached with a reconverged warp; the hardware checks it
(`F_BAR_DIVERGENT`). Structured code reconverges at every statement boundary of the
top-level and of every uniformly executed loop body, which is where barriers belong.

## 2.3 The checker (`cfg.py`)

`cfg.check(words)` builds the CFG (`exit`/`trap`/illegal words end a path; `bra` has one
successor; `bz/bnz` two), then for every conditional branch computes `REGION(b, R)`, checks
C1/C2, searches the smallest `R'` that satisfies C2, computes the classic IPDOM, and checks
C3 for every window. It returns errors (contract violations) and warnings (valid but
non-minimal `R`). Every compiled workload and 120 random kernels are checked minimal and
error-free in `tests/test_contract.py` (with refinement, §2.2).

## 2.4 What the hardware does if the contract is broken anyway

| Violation | Run-time behaviour |
|---|---|
| a path can run past `R` | `F_RECONV(R)` at the first fetch beyond `R`, precise; only if the branch actually diverged (a uniform branch never pushes an entry) |
| `R` outside the code | `F_PC_RANGE(R)` on every execution of the branch |
| `R` later than minimal | correct results, longer serialisation |
| window contains control / crosses `R` | `F_PRED_WINDOW(word)` |

## 2.5 Static stack bound

`kc.static_stack_need` computes, from the structured program, a conservative number of
entries above the bottom entry; `CompiledKernel.static_bound(L) = min(1 + need, 2L − 1)`:

| Statement | Entries it may add above its own entry |
|---|---|
| straight line, `Exit`, `Bar`, conditional `Break` | 0 |
| `If` with both arms | `max(2 + need(else), 1 + need(then))` — the else (taken) path runs on top of the pending then path |
| `If` with one arm | `1 + need(arm)` |
| `If` containing a `Break` | `1 + max(need(arms))` (its level is charged to the loop) |
| `While` / `DoWhile` | `1 + need(body)`, or `L + need(body)` if the body contains a break-`if` (up to `L` pending entries can accumulate, §1.8) |
| `ExitIf` | 1 |

Reuse can only make actual occupancy smaller. `tests/test_contract.py` checks
`measured max ≤ static bound` on random kernels for 4 and 8 lanes; the evaluation reports
both for every workload. The compiler user decides whether a kernel whose bound exceeds
`DEPTH` is rejected or run (it may still fit, because the bound is conservative).

## 2.6 If-conversion (predication) and when it is equivalent

`compile_kernel(..., predicate=True)` rewrites every `If` for which `kc.convertible`
returns no reason into SFX-PRED windows; every other construct is lowered with branches as
above. An `If` is converted only when predicated execution is **equivalent** to branch
execution — same per-thread registers (except the converter's own `r11..r15`), same memory
effects in the same order, same barrier behaviour:

* **P1** the arms are straight-line code or convertible nested `If`s — *no loops* (a loop
  with a lane-dependent trip count needs a back-edge branch and therefore divergence);
* **P2** no `exit`, `ExitIf`, `break`, `bar`, `trap` or other control transfer inside an arm
  (a predicated barrier would change barrier participation; a predicated exit or break cannot
  be expressed by a window);
* **P3** nesting depth ≤ 2 (predicate register budget `r11..r15`);
* **P4** arms and condition do not use `r11..r15`.

Why the result is equivalent: each thread executes exactly the instructions of its own arm,
in program order, because a window instruction acts only in `active & predicate` lanes (E1)
and an empty mask does nothing (E4) — no speculative loads, no stores or faults in lanes that
would not have executed the arm. The converter emits the **else arm first**, matching the
branch lowering's taken-path-first order, so even the order of memory accesses between the
two arms is the same.

Two lowerings are used:

* **fast form** (flat `if`, condition register not written by an arm that precedes a window
  that re-reads it): `pz c, n_else` · else · `pnz c, n_then` · then — no set-up instructions;
* **general form** (nested `if`s, or the condition is overwritten): predicates are
  materialised as 0/1 values in `r12/r13` (level 1) and `r14/r15` (level 2) by
  *unpredicated* instructions (`sltu`, `xori`, `and` with the parent predicate), so lanes
  outside the parent predicate get predicate 0 instead of a stale value.

Arms longer than 31 instructions are split into several windows with the same predicate.
Equivalence is tested on every workload and on random kernels (`tests/test_predication.py`)
and on the RTL for every evaluated workload (`tools/evaluate.py`).
