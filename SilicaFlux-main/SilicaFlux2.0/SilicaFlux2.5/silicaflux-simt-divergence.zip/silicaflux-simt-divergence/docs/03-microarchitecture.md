# 3. Microarchitecture (`rtl/`)

Synthesisable SystemVerilog, one execution group running one workgroup of up to
`WARPS × LANES` threads. Written in the subset that Icarus Verilog 12, Verilator 5.020
(`-Wall` clean) and Yosys 0.33 all accept: no packages (shared constants are
`` `include ``d into each module), no `return`, no `int'()` casts.

```
             +---------------------------------------------------------------+
             |  per warp w (generate):                                        |
  start ---->|  sfd_simt_stack: entries[DEPTH] = {pc, rpc, mask}, sp, live    |
             |  inflight, bar_wait, pcount, pmask                             |
             +------+------------------------------------------^-------------+
                    | top.pc, settled?, eligible                 | one command per commit
             +------v------+      +---------+      +-------------+----------------------+
   S stage   | loose round |----->|  IMEM   |----->| X stage: decode, regfile read,     |
             | robin select|      | (sync)  |      | LANES x ALU, branch cond, fetch &  |
             +-------------+      +---------+      | exec fault checks, commit          |
                                                   +--+-----------+--------------+-----+
                                     register write A |   LSU start |   bar arrive  | window
                                                   +--v--+     +---v------------+  |
                                                   | RF  |<----| sfd_lsu: one   |  |
                                                   |     |  B  | lane / access, |  |
                                                   +-----+     | ascending lane |  |
                                                               +--+---------+---+  |
                                                                  | GMEM    | SMEM (sync SRAM)
```

## 3.1 Modules

| Module | Function |
|---|---|
| `sfd_defs.svh` | opcodes, classes, ALU codes, stack commands, fault codes, perf-counter indices, `popc32`, `lowbit32` |
| `sfd_decode.sv` | SF-G1 decoder + SFX-PRED; illegal-word detection |
| `sfd_alu.sv` | one lane of the integer ALU |
| `sfd_simt_stack.sv` | per-warp reconvergence stack: commands, overflow preview, one pop per cycle, assertions S1–S7 |
| `sfd_regfile.sv` | `WARPS×LANES×15×32` flops (r0 = 0), two read ports per lane, write ports A (execute) and B (LSU) |
| `sfd_lsu.sv` | lane-serial load/store/atomic unit, assertions L0–L3 |
| `sfd_ram.sv` | single-port synchronous SRAM (GMEM, SMEM) |
| `sfd_core.sv` | warp state, scheduler, S/X stages, faults, barrier, predication windows, perf counters, assertions C1–C10 |

Parameters: `LANES` (2..32), `WARPS` (1..16), `DEPTH` (1..64), `IMEM_WORDS` (≤ 2046),
`GMEM_WORDS`, `SMEM_WORDS`, `PRED_EN`. Defaults 8 / 4 / 8 / 1024 / 4096 / 256 / 1.

## 3.2 Pipeline and timing

* **S (select).** Warp `w` is *eligible* when the core is running, `w` has no instruction
  in flight, its stack is non-empty and settled (no pop pending), and it is not waiting at a
  barrier. The scheduler picks the first eligible warp after the last one issued (loose
  round-robin, the SF-G1 reference policy) and reads `IMEM[top.pc]` (synchronous).
* **X (execute/commit).** Decode; read both operands for all lanes; run the fetch checks and
  the execution fault checks; if no fault: write results (port A, execution-mask lanes only),
  apply the warp's stack command, hand memory instructions to the LSU, record a barrier
  arrival, update the predication window.
* **Stack resolution.** If the command leaves the top entry complete, the stack pops in the
  following cycle, one entry per cycle; the warp is ineligible until its top is settled.
* **LSU.** Lanes of the execution mask are performed one per cycle in ascending order. With
  `n` lanes, a load occupies the LSU for `n + 2` cycles, a store `n + 1`, an atomic `2n + 1`.
  The LSU handles one warp instruction at a time; a memory instruction that reaches X while
  the LSU is busy stalls X and S (structural hazard).

Measured on one warp (no latency hiding), `traces/` and `results/`:

| event | cost for the issuing warp |
|---|---|
| ALU / control instruction | issue every 2 cycles (S, X) |
| divergent branch (pushes) | none beyond its own issue: pushes are written at commit |
| each pop (reconvergence or dead entry) | +1 cycle before the warp can issue again |
| store, `n` lanes | next issue `n + 3` cycles after the store's X cycle |

With two or more ready warps the core issues one instruction per cycle and pops of one warp
overlap with other warps' issue; the `pop_stall` counter records cycles in which nothing
could issue *and* a pop was pending (the exposed part of the reconvergence cost).

## 3.3 Reconvergence stack (`sfd_simt_stack.sv`)

* storage: `DEPTH` entries of `2·PCW + LANES` bits (`PCW = 11`), plus `sp` and `live`;
* the top entry is selected by a `DEPTH:1` mux on `sp − 1`;
* a command writes at most three entries in one cycle: the top (`T`), slot `sp` (`A`) and
  slot `sp+1` (`B`) — enough for "top becomes the reconvergence entry and two paths are
  pushed";
* `br_ovf` (overflow), `br_div` (divergent) and `br_push` (entries added) are computed
  combinationally from the command inputs, so the X stage raises `F_STACK_OVERFLOW`
  *before* committing (no state change);
* `needs_pop = sp ≠ 0 && (top.pc == top.rpc || top.mask & live == 0)`; one pop per cycle
  when no command arrives.

### Cost of capacity (Yosys 0.33 generic gates, `build/synth/stack_*.stat`)

| LANES | DEPTH | flops | cells |
|---:|---:|---:|---:|
| 8 | 2 | 70 | 833 |
| 8 | 4 | 131 | 1182 |
| 8 | 8 | 252 | 1841 |
| 8 | 15 (= 2L−1, overflow impossible) | 462 | 2922 |
| 8 | 16 | 493 | 3139 |
| 8 | 31 | 943 | 5390 |
| 16 | 8 | 324 | 2298 |
| 16 | 15 | 590 | 3728 |
| 16 | 31 (= 2L−1) | 1199 | 6769 |

Flops = `DEPTH·(22 + L) + ⌈log2(DEPTH+1)⌉ + L` per warp; logic grows linearly with
`DEPTH` (entry muxes and write decoders). At `L = 8` going from `DEPTH = 8` to the
overflow-free `15` costs ≈ 1.1 k gates and 210 flops per warp.

## 3.4 Register file, ALUs, special registers

`LANES` ALUs evaluate every lane every cycle; only execution-mask lanes are written. Special
registers are generated per lane (`SR_LANE_ID`, `SR_TID`, `SR_GTID` …); kernel arguments
come from the launch interface.

## 3.5 Barrier unit

`bar_wait[w]` is set when `bar` commits (after the `active == live` check). Release:
`bar_wait ≠ 0 && (bar_wait | done) == all-ones`, evaluated every cycle from registered
state, so a warp that finishes (stack becomes empty) releases waiting warps in the next
cycle. A release and a new arrival can never coincide (assertion C6).

## 3.6 Predication windows

Per warp: `pcount` (5 bits) and `pmask`. `x_ex = pcount ? active & pmask : active`.
`pz/pnz` load both; every committed window instruction decrements `pcount`. Control
instructions inside a window and windows that would cross `top.rpc` fault in X.

## 3.7 Faults, completion, watchdog

Fault priority within an instruction follows chapter 1 §1.6 and §1.14; across events in one
cycle: execution fault > completion > watchdog (SF-G1). On a fault the core latches the
record (`fault_code/warp/pc/lane/mask/data`), stops issuing and aborts the LSU.
Completion: every stack empty, nothing in X, LSU idle. The watchdog (`l_wdog` cycles,
0 = off) raises `F_WATCHDOG`.

## 3.8 Performance counters (`perf` bus, `rtl.PERF_NAMES`)

`cycles, issued, lane_slots, live_slots, pred_off, ctrl, branch, diverge, push, pop_r,
pop_x, sp_sum, sp_max, idle, stall, lsu_busy, bar_wait, pred_insn, mem_lanes, pop_stall`.
The verification compares every counter that can be derived from the instruction trace
with the trace (chapter 5), so the evaluation's numbers are cross-checked.

## 3.9 Interfaces

* host ports for IMEM/GMEM/SMEM (usable while idle), launch inputs (`code_words`,
  `entry_pc`, `wg_dim`, `wg_id`, `grid_dim`, `shared_bytes`, 8 arguments, watchdog),
  status/fault outputs, a debug register read port;
* trace taps read hierarchically by `tb/tb_sfd_core.sv` (`x_commit`, `trc_stack`,
  `w_pop_fire`, `acc_*`, `bar_release`); they have no function and are removed by synthesis.

## 3.10 Synthesis of the whole core

`tools/synth.sh` (Yosys generic flow, SRAMs kept as `$mem_v2` macros):

| configuration | cells | flops (register file) | SRAM macros | Yosys run time |
|---|---:|---:|---:|---:|
| L4 W2 D7 | 53,853 | 5,698 (3,840) | 3 | 2.5 min |
| L8 W4 D8 (default) | ≈145,300 | 18,209 (15,360) | 3 | ≈36 min |

The register file dominates (`W·L·15·32` flops); the reconvergence stacks are
`W·DEPTH·(22+L)` flops (2 × 7 × 26 = 364 here). Timing was not analysed (no target library).
The L8 W4 D8 figure comes from a run made just before the final lint-only RTL edits (an
equivalent rewrite of the port-A write enable, the multiplier expression and an unused
parameter), so its cell count is approximate; the flop count is exact. Almost all of the run
time is ABC on the 16 Kbit flop register file and its 2 × 8 wide read multiplexers; a
production flow would use a register-file macro, as it does for the SRAMs. Stack storage at
this size is 4 × 8 × 30 = 960 flops, 5 % of the core's flops.

## 3.11 Limits of this implementation

* one workgroup per launch on one execution group (multi-EG dispatch is SF-G1's launch
  unit, not part of divergence handling);
* lane-serial LSU (no coalescing): memory instructions cost one cycle per active lane;
* one instruction in flight per warp, no operand forwarding: a single warp issues every
  other cycle;
* simulation-verified only: no formal proof, no gate-level or timing sign-off.
