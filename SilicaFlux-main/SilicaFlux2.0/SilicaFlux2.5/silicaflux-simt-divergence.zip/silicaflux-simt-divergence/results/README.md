# Results

Produced by the tools in this package on the delivered RTL and model (Icarus Verilog 12.0,
Verilator 5.020, Yosys 0.33, Python 3.13), except where a row says otherwise.

| file | content | produced by |
|---|---|---|
| `EVALUATION.md` | all evaluation tables (utilisation, control overhead, stack occupancy, cycles; branch vs predication; configuration sensitivity; capacity sweep) | `tools/evaluate.py`, `tools/report.py` |
| `eval.csv`, `eval.json` | raw per-run metrics and hardware counters | `tools/evaluate.py` |
| `eval_run.log` | the evaluation run (every line is a verified RTL run) | `make eval` |
| `mutation.md`, `mutation_run.log` | 24 injected RTL bugs and how each was caught | `tools/mutate.py` |
| `directed.log` | 32 directed kernels: model checks + RTL lock-step | `tests/run_directed.py --rtl` |
| `rtl_random_initial.log` | first large random run, RTL vs model vs oracle: 360 runs over 5 configurations (made before the final lint clean-ups and reconvergence refinement; those changed no RTL function) | `tools/rtl_random.py --seeds 40` |
| `rtl_random_final.log` | final random regression, 6 configurations incl. a 3-entry stack (precise overflow faults compared) | `tools/rtl_random.py --seeds 25` |
| `pytest_model.log` | model-level test suite (85 tests) | `make test` |
| `pytest_rtl.log` | RTL test suite: 32 directed, 8 random, 4 workloads in both lowerings (44 tests) | `pytest tests/test_rtl.py` |
| `xcheck_sfg1.log` | the same binaries on the original SF-G1 reference model (199 kernels) | `tools/xcheck_sfg1.py` |
| `lint.log` | Verilator `-Wall` in four configurations | `tools/lint.sh` |
| `synth/` | Yosys reports: reconvergence stack for L ∈ {8,16} × DEPTH ∈ {2,4,8,15,16,31}; whole core L4 W2 D7 and L8 W4 D8 | `tools/synth.sh` |
