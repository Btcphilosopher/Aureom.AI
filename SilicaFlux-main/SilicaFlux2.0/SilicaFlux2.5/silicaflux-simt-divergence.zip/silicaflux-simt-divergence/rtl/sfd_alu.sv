// One lane of the SF-G1 integer ALU (32-bit, wrap-around, no flags).
module sfd_alu (
  input  logic [3:0]  fn,
  input  logic [31:0] a,
  input  logic [31:0] b,
  output logic [31:0] y
);
  `include "sfd_defs.svh"
  always_comb begin
    case (fn)
      A_ADD:   y = a + b;
      A_SUB:   y = a - b;
      A_MUL:   y = a * b;                 // low 32 bits
      A_AND:   y = a & b;
      A_OR:    y = a | b;
      A_XOR:   y = a ^ b;
      A_SHL:   y = a << b[4:0];
      A_SHR:   y = a >> b[4:0];
      A_SAR:   y = $unsigned($signed(a) >>> b[4:0]);
      A_SLT:   y = {31'd0, $signed(a) < $signed(b)};
      A_SLTU:  y = {31'd0, a < b};
      A_PASSB: y = b;
      default: y = 32'd0;
    endcase
  end
endmodule
