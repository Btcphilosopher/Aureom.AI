// Load/store unit: performs one warp memory instruction at a time, one lane per
// access, in ascending lane order, and ONLY for lanes in the instruction's
// execution mask (inactive / exited / predicated-off lanes never touch memory).
//
// Addresses arrive already checked by the execute stage (precise faults are
// raised there, before any lane is performed).  Timing for n active lanes:
//   load   : n read cycles + 1 capture cycle + 1 write-back cycle
//   store  : n write cycles + 1 completion cycle
//   atomic : 2n cycles (read, then write old+b) + 1 write-back cycle
// Memory accesses of different warp instructions are therefore performed in
// issue order, and a warp has at most one instruction in flight.
module sfd_lsu #(
  parameter int LANES = 8,
  parameter int WW    = 2,
  parameter int GAW   = 12,
  parameter int SAW   = 8,
  parameter int LW    = (LANES > 1) ? $clog2(LANES) : 1
) (
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic                 abort,
  // request (from execute stage)
  input  logic                 start,
  input  logic [WW-1:0]        req_warp,
  input  logic [1:0]           req_kind,      // 0 load, 1 store, 2 atomic add
  input  logic                 req_shared,
  input  logic [LANES-1:0]     req_mask,
  input  logic [LANES*32-1:0]  req_addr,      // byte addresses (aligned, in range)
  input  logic [LANES*32-1:0]  req_wdata,     // store data / atomic addend
  input  logic [3:0]           req_rd,
  output logic                 busy,
  // completion: register write-back + warp release
  output logic                 fin,
  output logic [WW-1:0]        fin_warp,
  output logic [LANES-1:0]     wb_en,
  output logic [3:0]           wb_reg,
  output logic [LANES*32-1:0]  wb_data,
  // memories
  output logic                 g_en,
  output logic                 g_we,
  output logic [GAW-1:0]       g_addr,
  output logic [31:0]          g_wdata,
  input  logic [31:0]          g_q,
  output logic                 s_en,
  output logic                 s_we,
  output logic [SAW-1:0]       s_addr,
  output logic [31:0]          s_wdata,
  input  logic [31:0]          s_q,
  // access trace (one record per lane access, in order)
  output logic                 acc_v,
  output logic [LW-1:0]        acc_lane,
  output logic [1:0]           acc_kind,
  output logic                 acc_shared,
  output logic [31:0]          acc_addr,
  output logic [31:0]          acc_rdata,
  output logic [31:0]          acc_wdata,
  output logic [WW-1:0]        acc_warp
);
  `include "sfd_defs.svh"
  localparam logic [1:0] K_LD = 2'd0, K_ST = 2'd1;            // 2'd2 = atomic add
  localparam logic [1:0] S_IDLE = 2'd0, S_RUN = 2'd1, S_CAP = 2'd2, S_FIN = 2'd3;

  logic [1:0]          st, st_n;
  logic [WW-1:0]       warp_q;
  logic [1:0]          kind_q;
  logic                sh_q;
  logic [LANES-1:0]    mask_q, rem, rem_n;
  logic [LANES*32-1:0] addr_q, wdata_q, buf_q;
  logic [3:0]          rd_q;
  logic                cap_v, cap_v_n, phase, phase_n;
  logic [LW-1:0]       cap_lane, cap_lane_n, lane;
  logic [31:0]         q, a_byte, cur_wdata;
  logic                m_en, m_we;
  logic [31:0]         m_wdata;
  logic                cap_now;          // capture q into buf[cap_lane] this cycle
  logic                at_wr;            // atomic write phase this cycle

  assign q         = sh_q ? s_q : g_q;
  assign lane      = LW'(lowbit32({{(32-LANES){1'b0}}, rem}));
  assign a_byte    = addr_q[lane*32 +: 32];
  assign cur_wdata = wdata_q[lane*32 +: 32];
  assign busy      = (st != S_IDLE);

  always_comb begin
    st_n       = st;
    rem_n      = rem;
    cap_v_n    = 1'b0;
    cap_lane_n = cap_lane;
    phase_n    = phase;
    m_en       = 1'b0;
    m_we       = 1'b0;
    m_wdata    = cur_wdata;
    cap_now    = 1'b0;
    at_wr      = 1'b0;
    case (st)
      S_IDLE: if (start) st_n = S_RUN;
      S_RUN: begin
        case (kind_q)
          K_LD: begin
            m_en       = 1'b1;
            cap_now    = cap_v;
            cap_v_n    = 1'b1;
            cap_lane_n = lane;
            rem_n      = rem & ~(LANES'(1) << lane);
            if (rem_n == '0) st_n = S_CAP;
          end
          K_ST: begin
            m_en  = 1'b1;
            m_we  = 1'b1;
            rem_n = rem & ~(LANES'(1) << lane);
            if (rem_n == '0) st_n = S_FIN;
          end
          default: begin // K_AT
            m_en = 1'b1;
            if (!phase) begin
              phase_n = 1'b1;
            end else begin
              m_we    = 1'b1;
              m_wdata = q + cur_wdata;
              at_wr   = 1'b1;
              phase_n = 1'b0;
              rem_n   = rem & ~(LANES'(1) << lane);
              if (rem_n == '0) st_n = S_FIN;
            end
          end
        endcase
      end
      S_CAP: begin
        cap_now = 1'b1;
        st_n    = S_FIN;
      end
      default: st_n = S_IDLE;   // S_FIN
    endcase
  end

  // memory port drive
  assign g_en    = m_en && !sh_q;
  assign g_we    = m_we && !sh_q;
  assign g_addr  = a_byte[GAW+1:2];
  assign g_wdata = m_wdata;
  assign s_en    = m_en && sh_q;
  assign s_we    = m_we && sh_q;
  assign s_addr  = a_byte[SAW+1:2];
  assign s_wdata = m_wdata;

  // completion
  assign fin      = (st == S_FIN);
  assign fin_warp = warp_q;
  assign wb_en    = (fin && kind_q != K_ST && rd_q != 4'd0) ? mask_q : '0;
  assign wb_reg   = rd_q;
  assign wb_data  = buf_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st       <= S_IDLE;
      rem      <= '0;
      cap_v    <= 1'b0;
      cap_lane <= '0;
      phase    <= 1'b0;
      warp_q   <= '0;
      kind_q   <= K_LD;
      sh_q     <= 1'b0;
      mask_q   <= '0;
      addr_q   <= '0;
      wdata_q  <= '0;
      buf_q    <= '0;
      rd_q     <= '0;
    end else if (abort) begin
      st    <= S_IDLE;
      cap_v <= 1'b0;
      phase <= 1'b0;
    end else begin
      st       <= st_n;
      rem      <= rem_n;
      cap_v    <= cap_v_n;
      cap_lane <= cap_lane_n;
      phase    <= phase_n;
      if (st == S_IDLE && start) begin
        warp_q  <= req_warp;
        kind_q  <= req_kind;
        sh_q    <= req_shared;
        mask_q  <= req_mask;
        rem     <= req_mask;
        addr_q  <= req_addr;
        wdata_q <= req_wdata;
        rd_q    <= req_rd;
        buf_q   <= '0;
        cap_v   <= 1'b0;
        phase   <= 1'b0;
      end
      if (cap_now) buf_q[cap_lane*32 +: 32] <= q;
      if (at_wr)   buf_q[lane*32 +: 32]     <= q;
    end
  end

  // access trace
  always_comb begin
    acc_v      = 1'b0;
    acc_lane   = lane;
    acc_kind   = kind_q;
    acc_shared = sh_q;
    acc_addr   = a_byte;
    acc_rdata  = q;
    acc_wdata  = m_wdata;
    acc_warp   = warp_q;
    if (cap_now) begin
      acc_v    = 1'b1;
      acc_lane = cap_lane;
      acc_addr = addr_q[cap_lane*32 +: 32];
    end else if (st == S_RUN && kind_q == K_ST) begin
      acc_v = 1'b1;
    end else if (at_wr) begin
      acc_v = 1'b1;
    end
  end

`ifndef SYNTHESIS
`ifdef SFD_ASSERT
  // L1 every performed access belongs to a lane of the instruction's execution mask
  // L2 lanes are performed in strictly ascending order, each at most once
  logic [LANES-1:0] done_lanes;
  logic [LW:0]      last_lane;
  always @(posedge clk) if (rst_n && !abort) begin
    if (st == S_IDLE && start) begin
      done_lanes <= '0;
      last_lane  <= '1;
      if (req_mask == '0) begin $display("SFD-ASSERT L0 LSU started with empty mask"); $fatal(1); end
    end else if (acc_v) begin
      if (!mask_q[acc_lane]) begin $display("SFD-ASSERT L1 access for lane %0d outside exec mask %b", acc_lane, mask_q); $fatal(1); end
      if (done_lanes[acc_lane]) begin $display("SFD-ASSERT L2 lane %0d accessed twice", acc_lane); $fatal(1); end
      if (last_lane != '1 && {1'b0, acc_lane} <= last_lane) begin $display("SFD-ASSERT L2 lane order %0d after %0d", acc_lane, last_lane); $fatal(1); end
      done_lanes[acc_lane] <= 1'b1;
      last_lane <= {1'b0, acc_lane};
    end
    if (fin && (done_lanes | (acc_v ? (LANES'(1) << acc_lane) : '0)) != mask_q) begin
      $display("SFD-ASSERT L3 instruction finished without performing every lane"); $fatal(1);
    end
  end
`endif
`endif
endmodule
