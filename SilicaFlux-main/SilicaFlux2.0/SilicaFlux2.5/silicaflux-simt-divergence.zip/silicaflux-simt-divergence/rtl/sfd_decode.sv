// SF-G1 instruction decoder (+ SFX-PRED pz/pnz when PRED_EN).
// Purely combinational.  Illegal words (undefined opcode, non-zero reserved
// bits, roff == 0, undefined special register, zero-length window) assert
// `illegal`; the core turns that into F_ILLEGAL_INSN.
module sfd_decode #(
  parameter bit PRED_EN = 1'b1
) (
  input  logic [31:0] insn,
  output logic        illegal,
  output logic [3:0]  cls,
  output logic [3:0]  alu_fn,
  output logic        b_imm,      // ALU operand b comes from imm (I/IS/U formats)
  output logic        rd_we,      // class writes rd (when rd != 0)
  output logic        pol_z,      // bz / pz: condition is "register == 0"
  output logic [3:0]  rd,
  output logic [3:0]  rs1,
  output logic [3:0]  rs2,
  output logic [31:0] imm,
  output logic [10:0] imm2
);
  `include "sfd_defs.svh"

  localparam logic [3:0] FZ = 4'd0, FT = 4'd1, FR = 4'd2, FI = 4'd3, FIS = 4'd4, FU = 4'd5;
  localparam logic [3:0] FS = 4'd6, FB = 4'd7, FJ = 4'd8, FSR = 4'd9, FP = 4'd10, FBAD = 4'd15;

  logic [5:0]  op;
  logic [3:0]  fmt;
  logic [31:0] resv;
  logic        sr_ok;

  always_comb begin
    op     = insn[31:26];
    fmt    = FBAD;
    cls    = C_NOP;
    alu_fn = A_ADD;
    rd_we  = 1'b0;
    b_imm  = 1'b0;
    pol_z  = 1'b0;
    case (op)
      OP_NOP:   begin fmt = FZ; cls = C_NOP;   end
      OP_EXIT:  begin fmt = FZ; cls = C_EXIT;  end
      OP_BAR:   begin fmt = FZ; cls = C_BAR;   end
      OP_FENCE: begin fmt = FZ; cls = C_FENCE; end
      OP_TRAP:  begin fmt = FT; cls = C_TRAP;  end
      OP_ADD:   begin fmt = FR; cls = C_ALU; alu_fn = A_ADD;  rd_we = 1'b1; end
      OP_SUB:   begin fmt = FR; cls = C_ALU; alu_fn = A_SUB;  rd_we = 1'b1; end
      OP_MUL:   begin fmt = FR; cls = C_ALU; alu_fn = A_MUL;  rd_we = 1'b1; end
      OP_AND:   begin fmt = FR; cls = C_ALU; alu_fn = A_AND;  rd_we = 1'b1; end
      OP_OR:    begin fmt = FR; cls = C_ALU; alu_fn = A_OR;   rd_we = 1'b1; end
      OP_XOR:   begin fmt = FR; cls = C_ALU; alu_fn = A_XOR;  rd_we = 1'b1; end
      OP_SHL:   begin fmt = FR; cls = C_ALU; alu_fn = A_SHL;  rd_we = 1'b1; end
      OP_SHR:   begin fmt = FR; cls = C_ALU; alu_fn = A_SHR;  rd_we = 1'b1; end
      OP_SAR:   begin fmt = FR; cls = C_ALU; alu_fn = A_SAR;  rd_we = 1'b1; end
      OP_SLT:   begin fmt = FR; cls = C_ALU; alu_fn = A_SLT;  rd_we = 1'b1; end
      OP_SLTU:  begin fmt = FR; cls = C_ALU; alu_fn = A_SLTU; rd_we = 1'b1; end
      OP_ADDI:  begin fmt = FI;  cls = C_ALU; alu_fn = A_ADD;   rd_we = 1'b1; b_imm = 1'b1; end
      OP_ANDI:  begin fmt = FI;  cls = C_ALU; alu_fn = A_AND;   rd_we = 1'b1; b_imm = 1'b1; end
      OP_ORI:   begin fmt = FI;  cls = C_ALU; alu_fn = A_OR;    rd_we = 1'b1; b_imm = 1'b1; end
      OP_XORI:  begin fmt = FI;  cls = C_ALU; alu_fn = A_XOR;   rd_we = 1'b1; b_imm = 1'b1; end
      OP_SHLI:  begin fmt = FIS; cls = C_ALU; alu_fn = A_SHL;   rd_we = 1'b1; b_imm = 1'b1; end
      OP_SHRI:  begin fmt = FIS; cls = C_ALU; alu_fn = A_SHR;   rd_we = 1'b1; b_imm = 1'b1; end
      OP_SARI:  begin fmt = FIS; cls = C_ALU; alu_fn = A_SAR;   rd_we = 1'b1; b_imm = 1'b1; end
      OP_SLTI:  begin fmt = FI;  cls = C_ALU; alu_fn = A_SLT;   rd_we = 1'b1; b_imm = 1'b1; end
      OP_SLTIU: begin fmt = FI;  cls = C_ALU; alu_fn = A_SLTU;  rd_we = 1'b1; b_imm = 1'b1; end
      OP_LUI:   begin fmt = FU;  cls = C_ALU; alu_fn = A_PASSB; rd_we = 1'b1; b_imm = 1'b1; end
      OP_RDSR:  begin fmt = FSR; cls = C_SREAD; rd_we = 1'b1; end
      OP_LDG:   begin fmt = FI;  cls = C_LDG;  rd_we = 1'b1; end
      OP_STG:   begin fmt = FS;  cls = C_STG;  end
      OP_LDS:   begin fmt = FI;  cls = C_LDS;  rd_we = 1'b1; end
      OP_STS:   begin fmt = FS;  cls = C_STS;  end
      OP_ATOM:  begin fmt = FR;  cls = C_ATOM; rd_we = 1'b1; end
      OP_BRA:   begin fmt = FJ;  cls = C_JUMP; end
      OP_BZ:    begin fmt = FB;  cls = C_BRANCH; pol_z = 1'b1; end
      OP_BNZ:   begin fmt = FB;  cls = C_BRANCH; end
      OP_PZ:    if (PRED_EN) begin fmt = FP; cls = C_PRED; pol_z = 1'b1; end
      OP_PNZ:   if (PRED_EN) begin fmt = FP; cls = C_PRED; end
      default:  fmt = FBAD;
    endcase

    case (fmt)
      FR:      resv = 32'h0000_3fff;
      FIS:     resv = 32'h0003_ffe0;
      FT:      resv = 32'h03ff_0000;
      FZ:      resv = 32'h03ff_ffff;
      FSR:     resv = 32'h003f_ffe0;
      FP:      resv = 32'h003f_ffe0;
      default: resv = 32'h0000_0000;
    endcase

    rd   = 4'd0;
    rs1  = 4'd0;
    rs2  = 4'd0;
    imm  = 32'd0;
    imm2 = 11'd0;
    case (fmt)
      FR:  begin rd = insn[25:22]; rs1 = insn[21:18]; rs2 = insn[17:14]; end
      FI:  begin rd = insn[25:22]; rs1 = insn[21:18]; imm = {{14{insn[17]}}, insn[17:0]}; end
      FIS: begin rd = insn[25:22]; rs1 = insn[21:18]; imm = {27'd0, insn[4:0]}; end
      FU:  begin rd = insn[25:22]; imm = {insn[21:0], 10'd0}; end
      FS:  begin rs2 = insn[25:22]; rs1 = insn[21:18]; imm = {{14{insn[17]}}, insn[17:0]}; end
      FB:  begin rs1 = insn[25:22]; imm = {{21{insn[21]}}, insn[21:11]}; imm2 = insn[10:0]; end
      FJ:  imm = {{6{insn[25]}}, insn[25:0]};
      FT:  imm = {16'd0, insn[15:0]};
      FSR: begin rd = insn[25:22]; imm = {27'd0, insn[4:0]}; end
      FP:  begin rs1 = insn[25:22]; imm = {27'd0, insn[4:0]}; end
      default: ;
    endcase

    sr_ok   = (insn[4:0] <= 5'd8) || (insn[4:0] >= 5'd16 && insn[4:0] <= 5'd23);
    illegal = (fmt == FBAD)
           || ((insn & resv) != 32'd0)
           || (fmt == FB  && insn[10:0] == 11'd0)
           || (fmt == FSR && !sr_ok)
           || (fmt == FP  && insn[4:0] == 5'd0);
  end
endmodule
