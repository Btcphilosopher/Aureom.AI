// Per-warp reconvergence stack (docs/01-reconvergence-spec.md, model/sfdiv/simt.py).
//
// Entry = {pc, rpc, mask}.  Top entry = executing path; active = top.mask & live.
// One command per issued instruction:
//   SEQ            top.pc <- top.pc + 1
//   JUMP t         top.pc <- t
//   BRANCH c,t,R   (cmd_mask = c: lanes whose condition holds = taken)
//                    T = act & c, N = act & ~c
//                    T == 0            : top.pc <- pc + 1
//                    N == 0            : top.pc <- t
//                    otherwise diverge : fall path (pc+1,R,N) if pc+1 != R,
//                                        taken path (t,R,T)   if t    != R (pushed last = runs first)
//                                        reuse = (top.rpc == R):
//                                          reuse: top replaced by first path, rest pushed
//                                          else : top.pc <- R (reconvergence entry), all paths pushed
//   EXIT m         live <- live & ~m
// Resolution: while the top has reached its rpc or has no live lane, pop it —
// ONE pop per clock.  The warp is not issuable while `needs_pop` is high.
//
// Overflow: `br_ovf` is computed combinationally from the cmd_* inputs so the
// core can raise F_STACK_OVERFLOW *before* committing (precise: no state change).
module sfd_simt_stack #(
  parameter int LANES = 8,
  parameter int DEPTH = 8,
  parameter int SPW   = $clog2(DEPTH + 1),
  parameter int PW    = 11                    // must equal PCW in sfd_defs.svh
) (
  input  logic             clk,
  input  logic             rst_n,
  // launch
  input  logic             init_valid,
  input  logic [PW-1:0]    init_pc,
  input  logic [LANES-1:0] init_mask,
  // command from the execute stage
  input  logic             cmd_valid,
  input  logic [1:0]       cmd_op,
  input  logic [LANES-1:0] cmd_mask,
  input  logic [PW-1:0]    cmd_target,
  input  logic [PW-1:0]    cmd_reconv,
  // state
  output logic [PW-1:0]    top_pc,
  output logic [PW-1:0]    top_rpc,
  output logic [LANES-1:0] top_mask,
  output logic [LANES-1:0] live,
  output logic [LANES-1:0] active,
  output logic [SPW-1:0]   sp,
  output logic             empty,
  output logic             needs_pop,
  output logic             pop_fire,
  output logic             pop_dead,    // the pop (if any) is of an entry without live lanes
  // branch preview (combinational from cmd_* inputs)
  output logic             br_div,
  output logic             br_ovf,
  output logic [1:0]       br_push,     // entries a non-overflowing divergent branch adds
  // debug: all entries, entry i at [i*EW +: EW], EW = 2*PW+LANES
  output logic [DEPTH*(2*PW+LANES)-1:0] dbg_entries
);
  `include "sfd_defs.svh"
  localparam int EW = 2 * PW + LANES;

  logic [EW-1:0]    ent [0:DEPTH-1];
  logic [SPW-1:0]   sp_q;
  logic [LANES-1:0] live_q;
  logic [SPW-1:0]   tix;

  assign tix   = sp_q - 1'b1;
  assign sp    = sp_q;
  assign live  = live_q;
  assign empty = (sp_q == '0);

  logic [EW-1:0] top_e;
  always_comb begin
    top_e = '0;
    for (int i = 0; i < DEPTH; i++)
      if (!empty && tix == i[SPW-1:0]) top_e = ent[i];
  end
  assign top_pc   = top_e[EW-1 -: PW];
  assign top_rpc  = top_e[EW-PW-1 -: PW];
  assign top_mask = top_e[LANES-1:0];
  assign active    = top_mask & live_q;
  assign needs_pop = !empty && ((top_pc == top_rpc) || (active == '0));
  assign pop_fire  = needs_pop && !cmd_valid && !init_valid;
  assign pop_dead  = (active == '0);

  // ---------------------------------------------------------------- branch preview
  logic [LANES-1:0] t_m, n_m;
  logic [PW-1:0]    pc1;
  logic             need_f, need_t, reuse;
  logic [1:0]       np, needed;
  logic [SPW+1:0]   sp_after;

  always_comb begin
    t_m      = active & cmd_mask;
    n_m      = active & ~cmd_mask;
    pc1      = top_pc + 1'b1;
    br_div   = (t_m != '0) && (n_m != '0);
    need_f   = (pc1 != cmd_reconv);
    need_t   = (cmd_target != cmd_reconv);
    np       = {1'b0, need_f} + {1'b0, need_t};
    reuse    = (top_rpc == cmd_reconv);
    needed   = reuse ? ((np == 2'd0) ? 2'd0 : np - 2'd1) : np;
    sp_after = {2'b00, sp_q} + {{SPW{1'b0}}, needed};
    br_ovf   = br_div && (sp_after > (SPW+2)'(DEPTH));
    br_push  = br_div ? needed : 2'd0;
  end

  // ---------------------------------------------------------------- write ports
  // T: rewrite the top entry; A: write slot sp; B: write slot sp+1
  logic             wT, wA, wB;
  logic [EW-1:0]    dT, dA, dB;
  logic [SPW-1:0]   sp_n;
  logic [LANES-1:0] live_n;

  always_comb begin
    wT = 1'b0; wA = 1'b0; wB = 1'b0;
    dT = {top_pc, top_rpc, top_mask};
    dA = '0;
    dB = '0;
    sp_n   = sp_q;
    live_n = live_q;
    if (cmd_valid) begin
      case (cmd_op)
        CMD_SEQ:  begin wT = 1'b1; dT = {pc1, top_rpc, top_mask}; end
        CMD_JUMP: begin wT = 1'b1; dT = {cmd_target, top_rpc, top_mask}; end
        CMD_EXIT: live_n = live_q & ~cmd_mask;
        default: begin // CMD_BRANCH
          if (t_m == '0) begin
            wT = 1'b1; dT = {pc1, top_rpc, top_mask};
          end else if (n_m == '0) begin
            wT = 1'b1; dT = {cmd_target, top_rpc, top_mask};
          end else if (!br_ovf) begin
            if (reuse) begin
              wT = 1'b1;
              if (need_f && need_t) begin
                dT = {pc1, cmd_reconv, n_m};
                wA = 1'b1; dA = {cmd_target, cmd_reconv, t_m};
                sp_n = sp_q + 1'b1;
              end else if (need_f) begin
                dT = {pc1, cmd_reconv, n_m};
              end else if (need_t) begin
                dT = {cmd_target, cmd_reconv, t_m};
              end else begin
                dT = {cmd_reconv, top_rpc, top_mask};
              end
            end else begin
              wT = 1'b1; dT = {cmd_reconv, top_rpc, top_mask};
              if (need_f && need_t) begin
                wA = 1'b1; dA = {pc1, cmd_reconv, n_m};
                wB = 1'b1; dB = {cmd_target, cmd_reconv, t_m};
                sp_n = sp_q + SPW'(2);
              end else if (need_f) begin
                wA = 1'b1; dA = {pc1, cmd_reconv, n_m};
                sp_n = sp_q + 1'b1;
              end else if (need_t) begin
                wA = 1'b1; dA = {cmd_target, cmd_reconv, t_m};
                sp_n = sp_q + 1'b1;
              end
            end
          end
        end
      endcase
    end else if (needs_pop) begin
      sp_n = sp_q - 1'b1;
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sp_q   <= '0;
      live_q <= '0;
      for (int i = 0; i < DEPTH; i++) ent[i] <= '0;
    end else if (init_valid) begin
      sp_q   <= (init_mask != '0) ? SPW'(1) : '0;
      live_q <= init_mask;
      ent[0] <= {init_pc, RPC_NONE, init_mask};
    end else begin
      sp_q   <= sp_n;
      live_q <= live_n;
      for (int i = 0; i < DEPTH; i++) begin
        if (wT && tix == i[SPW-1:0])         ent[i] <= dT;
        if (wA && sp_q == i[SPW-1:0])        ent[i] <= dA;
        if (wB && (sp_q + 1'b1) == i[SPW-1:0]) ent[i] <= dB;
      end
    end
  end

  genvar gi;
  generate for (gi = 0; gi < DEPTH; gi++) begin : g_dbg
    assign dbg_entries[gi*EW +: EW] = ent[gi];
  end endgenerate

`ifndef SYNTHESIS
`ifdef SFD_ASSERT
  // ---------------------------------------------------------------- assertions
  always @(posedge clk) if (rst_n && !init_valid) begin
    // S1 capacity is never exceeded
    if (sp_q > SPW'(DEPTH)) begin $display("SFD-ASSERT S1 sp %0d > DEPTH %m", sp_q); $fatal(1); end
    // S2 commands only reach a settled, non-empty stack (the core never issues otherwise)
    if (cmd_valid && (empty || needs_pop)) begin $display("SFD-ASSERT S2 command to unsettled stack %m"); $fatal(1); end
    // S3 an overflowing branch is never committed (the core faults instead)
    if (cmd_valid && cmd_op == CMD_BRANCH && br_ovf) begin $display("SFD-ASSERT S3 overflowing branch committed %m"); $fatal(1); end
    // S4 the bottom entry always reconverges nowhere, and live lanes are a subset of it
    if (!empty && ent[0][EW-PW-1 -: PW] != RPC_NONE) begin $display("SFD-ASSERT S4 bottom rpc %m"); $fatal(1); end
    if (!empty && (live_q & ~ent[0][LANES-1:0]) != '0) begin $display("SFD-ASSERT S4 live outside bottom mask %m"); $fatal(1); end
    // S5 every entry above the bottom is a sub-mask of the bottom entry
    for (int i = 1; i < DEPTH; i++)
      if (SPW'(i) < sp_q && (ent[i][LANES-1:0] & ~ent[0][LANES-1:0]) != '0) begin
        $display("SFD-ASSERT S5 entry %0d mask escapes bottom mask %m", i); $fatal(1);
      end
    // S6 an EXIT only retires active lanes
    if (cmd_valid && cmd_op == CMD_EXIT && (cmd_mask & ~active) != '0) begin $display("SFD-ASSERT S6 exit of inactive lanes %m"); $fatal(1); end
  end
  // S7 live lanes never come back
  logic [LANES-1:0] live_prev;
  always @(posedge clk) begin
    if (rst_n && !init_valid && (live_q & ~live_prev) != '0) begin $display("SFD-ASSERT S7 lane revived %m"); $fatal(1); end
    live_prev <= init_valid ? init_mask : live_q;
  end
`endif
`endif
endmodule
