// Per-thread register file: WARPS x LANES x 16 x 32 bit, r0 hard-wired to zero.
// Read: two operands for every lane of one warp (combinational).
// Write port A: execute stage (ALU / rdsr results), per-lane enables.
// Write port B: LSU (load / atomic results), per-lane enables.
// The core guarantees A and B never address the same warp in one cycle
// (asserted in sfd_core).  `clear` zeroes every register at launch
// (SF-G1: registers are zero when a thread starts).
module sfd_regfile #(
  parameter int LANES = 8,
  parameter int WARPS = 4,
  parameter int WW    = (WARPS > 1) ? $clog2(WARPS) : 1,
  parameter int LW    = (LANES > 1) ? $clog2(LANES) : 1
) (
  input  logic                  clk,
  input  logic                  clear,
  input  logic [WW-1:0]         rd_warp,
  input  logic [3:0]            rs1,
  input  logic [3:0]            rs2,
  output logic [LANES*32-1:0]   rdata1,
  output logic [LANES*32-1:0]   rdata2,
  input  logic [LANES-1:0]      wa_en,
  input  logic [WW-1:0]         wa_warp,
  input  logic [3:0]            wa_reg,
  input  logic [LANES*32-1:0]   wa_data,
  input  logic [LANES-1:0]      wb_en,
  input  logic [WW-1:0]         wb_warp,
  input  logic [3:0]            wb_reg,
  input  logic [LANES*32-1:0]   wb_data,
  input  logic [WW-1:0]         dbg_warp,
  input  logic [LW-1:0]         dbg_lane,
  input  logic [3:0]            dbg_reg,
  output logic [31:0]           dbg_data
);
  localparam int NWORDS = WARPS * LANES * 16;
  logic [NWORDS*32-1:0] flat;

  genvar gw, gl, gr;
  generate
    for (gw = 0; gw < WARPS; gw++) begin : g_w
      for (gl = 0; gl < LANES; gl++) begin : g_l
        assign flat[((gw * LANES + gl) * 16) * 32 +: 32] = 32'd0;      // r0
        for (gr = 1; gr < 16; gr++) begin : g_r
          logic [31:0] r;
          always_ff @(posedge clk) begin
            if (clear)
              r <= 32'd0;
            else if (wa_en[gl] && wa_warp == WW'(gw) && wa_reg == 4'(gr))
              r <= wa_data[gl*32 +: 32];
            else if (wb_en[gl] && wb_warp == WW'(gw) && wb_reg == 4'(gr))
              r <= wb_data[gl*32 +: 32];
          end
          assign flat[((gw * LANES + gl) * 16 + gr) * 32 +: 32] = r;
        end
      end
    end
  endgenerate

  // word index = (warp * LANES + lane) * 16 + reg
  localparam int IW = $clog2(NWORDS);
  /* verilator lint_off UNUSEDSIGNAL */   // upper bits of the 32-bit scratch index are always zero
  function automatic logic [IW-1:0] widx(input logic [WW-1:0] w, input logic [LW-1:0] l, input logic [3:0] r);
    logic [31:0] t;
    t = (({{(32-WW){1'b0}}, w} * LANES) + {{(32-LW){1'b0}}, l}) * 16 + {28'd0, r};
    widx = t[IW-1:0];
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */

  always_comb begin
    for (int l = 0; l < LANES; l++) begin
      rdata1[l*32 +: 32] = flat[widx(rd_warp, LW'(l), rs1) * 32 +: 32];
      rdata2[l*32 +: 32] = flat[widx(rd_warp, LW'(l), rs2) * 32 +: 32];
    end
  end
  assign dbg_data = flat[widx(dbg_warp, dbg_lane, dbg_reg) * 32 +: 32];
endmodule
