// SilicaFlux SIMT divergence core: shared constants and helper functions.
//
// Included *inside* every module body (Yosys 0.33 does not accept package
// imports in modules, so a package would make the RTL unsynthesisable there).
// Values mirror model/sfdiv/isa.py; tests/test_isa.py::test_rtl_constants_match_model compares them.

/* verilator lint_off UNUSEDPARAM */
localparam int PCW = 11;                                   // pc / rpc width
localparam logic [PCW-1:0] RPC_NONE = {PCW{1'b1}};         // bottom-entry "no reconvergence"

// ---- opcodes (SF-G1; 0x3B/0x3C = SFX-PRED extension) -------------------
localparam logic [5:0] OP_NOP   = 6'h00, OP_EXIT = 6'h01, OP_BAR  = 6'h02, OP_FENCE = 6'h03, OP_TRAP = 6'h04;
localparam logic [5:0] OP_ADD   = 6'h10, OP_SUB  = 6'h11, OP_MUL  = 6'h12, OP_AND   = 6'h13, OP_OR   = 6'h14;
localparam logic [5:0] OP_XOR   = 6'h15, OP_SHL  = 6'h16, OP_SHR  = 6'h17, OP_SAR   = 6'h18, OP_SLT  = 6'h19;
localparam logic [5:0] OP_SLTU  = 6'h1a;
localparam logic [5:0] OP_ADDI  = 6'h20, OP_ANDI = 6'h21, OP_ORI  = 6'h22, OP_XORI  = 6'h23, OP_SHLI = 6'h24;
localparam logic [5:0] OP_SHRI  = 6'h25, OP_SARI = 6'h26, OP_SLTI = 6'h27, OP_SLTIU = 6'h28, OP_LUI  = 6'h29;
localparam logic [5:0] OP_RDSR  = 6'h2a;
localparam logic [5:0] OP_LDG   = 6'h30, OP_STG  = 6'h31, OP_LDS  = 6'h32, OP_STS   = 6'h33, OP_ATOM = 6'h34;
localparam logic [5:0] OP_BRA   = 6'h38, OP_BZ   = 6'h39, OP_BNZ  = 6'h3a, OP_PZ    = 6'h3b, OP_PNZ  = 6'h3c;

// ---- instruction classes ----------------------------------------------
localparam logic [3:0] C_NOP = 4'd0, C_EXIT = 4'd1, C_BAR = 4'd2, C_FENCE = 4'd3, C_TRAP = 4'd4;
localparam logic [3:0] C_ALU = 4'd5, C_SREAD = 4'd6, C_LDG = 4'd7, C_STG = 4'd8, C_LDS = 4'd9;
localparam logic [3:0] C_STS = 4'd10, C_ATOM = 4'd11, C_JUMP = 4'd12, C_BRANCH = 4'd13, C_PRED = 4'd14;

// ---- ALU functions -----------------------------------------------------
localparam logic [3:0] A_ADD = 4'd0, A_SUB = 4'd1, A_MUL = 4'd2, A_AND = 4'd3, A_OR = 4'd4, A_XOR = 4'd5;
localparam logic [3:0] A_SHL = 4'd6, A_SHR = 4'd7, A_SAR = 4'd8, A_SLT = 4'd9, A_SLTU = 4'd10, A_PASSB = 4'd11;

// ---- reconvergence-stack commands -------------------------------------
localparam logic [1:0] CMD_SEQ = 2'd0, CMD_JUMP = 2'd1, CMD_BRANCH = 2'd2, CMD_EXIT = 2'd3;

// ---- faults (SF-G1 codes; 27 = SFX-PRED) ------------------------------
localparam logic [7:0] F_NONE = 8'd0, F_ILLEGAL_INSN = 8'd16, F_PC_RANGE = 8'd17, F_RECONV = 8'd18;
localparam logic [7:0] F_GMEM_ALIGN = 8'd19, F_GMEM_RANGE = 8'd20, F_SMEM_ALIGN = 8'd21, F_SMEM_RANGE = 8'd22;
localparam logic [7:0] F_STACK_OVERFLOW = 8'd23, F_BAR_DIVERGENT = 8'd24, F_TRAP = 8'd25, F_WATCHDOG = 8'd26;
localparam logic [7:0] F_PRED_WINDOW = 8'd27;

// ---- performance counters (index into the perf bus) -------------------
localparam int P_CYCLES = 0, P_ISSUED = 1, P_LANE_SLOTS = 2, P_LIVE_SLOTS = 3, P_PRED_OFF = 4;
localparam int P_CTRL = 5, P_BRANCH = 6, P_DIVERGE = 7, P_PUSH = 8, P_POP_R = 9, P_POP_X = 10;
localparam int P_SP_SUM = 11, P_SP_MAX = 12, P_IDLE = 13, P_STALL = 14, P_LSU_BUSY = 15;
localparam int P_BAR_WAIT = 16, P_PRED_INSN = 17, P_MEM_LANES = 18, P_POP_STALL = 19;
localparam int NPERF = 20;

// ---- helpers ------------------------------------------------------------
function automatic logic [5:0] popc32(input logic [31:0] v);
  logic [5:0] c;
  c = 6'd0;
  for (int i = 0; i < 32; i++) c = c + {5'd0, v[i]};
  popc32 = c;
endfunction

// index of the lowest set bit (0 when v == 0)
function automatic logic [4:0] lowbit32(input logic [31:0] v);
  logic [4:0] r;
  logic       f;
  r = 5'd0;
  f = 1'b0;
  for (int i = 0; i < 32; i++)
    if (!f && v[i]) begin
      r = i[4:0];
      f = 1'b1;
    end
  lowbit32 = r;
endfunction
/* verilator lint_on UNUSEDPARAM */
