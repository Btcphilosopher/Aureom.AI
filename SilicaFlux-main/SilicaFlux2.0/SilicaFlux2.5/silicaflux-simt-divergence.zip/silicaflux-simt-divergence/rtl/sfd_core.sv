// SilicaFlux SIMT divergence core (one execution group, one workgroup per launch).
//
// Pipeline (docs/03-microarchitecture.md):
//   S  select a warp (loose round-robin over eligible warps), read IMEM[top.pc]
//   X  decode, read operands, check faults, execute all lanes, commit:
//      register write (port A), one reconvergence-stack command, LSU hand-off,
//      barrier arrival, predication-window update
//   LSU (memory instructions only): lane-serial, ascending lanes, exec lanes only
// A warp has at most one instruction in flight; it becomes eligible again when
// that instruction has committed (or the LSU has finished it) AND its stack is
// settled (one pop per cycle).  Eligible = running, not in flight, stack not
// empty, no pop pending, not waiting at a barrier.
`ifndef SFD_LANES
`define SFD_LANES 8
`endif
`ifndef SFD_WARPS
`define SFD_WARPS 4
`endif
`ifndef SFD_DEPTH
`define SFD_DEPTH 8
`endif
`ifndef SFD_PRED_EN
`define SFD_PRED_EN 1
`endif
// Defaults can be overridden by parameters or, for tools that cannot re-derive
// the top module (Yosys 0.33 + generate), by -DSFD_LANES=... etc.
module sfd_core #(
  parameter int LANES      = `SFD_LANES,
  parameter int WARPS      = `SFD_WARPS,
  parameter int DEPTH      = `SFD_DEPTH,
  parameter int IMEM_WORDS = 1024,
  parameter int GMEM_WORDS = 4096,
  parameter int SMEM_WORDS = 256,
  parameter bit PRED_EN    = 1'(`SFD_PRED_EN),
  // derived
  parameter int WW  = (WARPS > 1) ? $clog2(WARPS) : 1,
  parameter int LW  = (LANES > 1) ? $clog2(LANES) : 1,
  parameter int IAW = $clog2(IMEM_WORDS),
  parameter int GAW = $clog2(GMEM_WORDS),
  parameter int SAW = $clog2(SMEM_WORDS),
  parameter int SPW = $clog2(DEPTH + 1),
  parameter int PW  = 11,
  parameter int NP  = 20
) (
  input  logic                 clk,
  input  logic                 rst_n,
  // host access (only while not busy)
  input  logic                 host_imem_we,
  input  logic [IAW-1:0]       host_imem_addr,
  input  logic [31:0]          host_imem_wdata,
  input  logic                 host_gmem_en,
  input  logic                 host_gmem_we,
  input  logic [GAW-1:0]       host_gmem_addr,
  input  logic [31:0]          host_gmem_wdata,
  output logic [31:0]          host_gmem_rdata,
  input  logic                 host_smem_en,
  input  logic                 host_smem_we,
  input  logic [SAW-1:0]       host_smem_addr,
  input  logic [31:0]          host_smem_wdata,
  output logic [31:0]          host_smem_rdata,
  // launch
  input  logic                 start,
  input  logic [PW-1:0]        l_code_words,
  input  logic [PW-1:0]        l_entry_pc,
  input  logic [31:0]          l_wg_dim,
  input  logic [31:0]          l_wg_id,
  input  logic [31:0]          l_grid_dim,
  input  logic [31:0]          l_shared_bytes,
  input  logic [31:0]          l_wdog,
  input  logic [8*32-1:0]      l_args,
  // status
  output logic                 busy,
  output logic                 done,
  output logic                 faulted,
  output logic [7:0]           fault_code,
  output logic [WW-1:0]        fault_warp,
  output logic [PW-1:0]        fault_pc,
  output logic [LW-1:0]        fault_lane,
  output logic [LANES-1:0]     fault_mask,
  output logic [31:0]          fault_data,
  output logic [NP*32-1:0]     perf,
  // debug register read
  input  logic [WW-1:0]        dbg_warp,
  input  logic [LW-1:0]        dbg_lane,
  input  logic [3:0]           dbg_reg,
  output logic [31:0]          dbg_rdata
);
  `include "sfd_defs.svh"
  localparam int EW = 2 * PW + LANES;
  localparam logic [1:0] ST_IDLE = 2'd0, ST_RUN = 2'd1, ST_FAULT = 2'd2;

  // ======================================================================
  // Launch registers
  // ======================================================================
  logic [1:0]      state;
  logic            run;
  logic [PW-1:0]   code_words;
  logic [31:0]     wg_dim, wg_id, grid_dim, shared_bytes, wdog, gtid_base;
  logic [8*32-1:0] args;

  assign run  = (state == ST_RUN);
  assign busy = run;

  // ======================================================================
  // Per-warp state
  // ======================================================================
  logic [PW-1:0]    w_pc   [0:WARPS-1];
  logic [PW-1:0]    w_rpc  [0:WARPS-1];
  /* verilator lint_off UNUSEDSIGNAL */          // w_mask / acc_* / trc_stack: testbench trace taps
  logic [LANES-1:0] w_mask [0:WARPS-1];
  /* verilator lint_on UNUSEDSIGNAL */
  logic [LANES-1:0] w_live [0:WARPS-1];
  logic [LANES-1:0] w_act  [0:WARPS-1];
  logic [SPW-1:0]   w_sp   [0:WARPS-1];
  logic [EW*DEPTH-1:0] w_dbg [0:WARPS-1];
  logic [WARPS-1:0] w_empty, w_needs_pop, w_pop_fire, w_pop_dead, w_br_div, w_br_ovf, w_cmd_v;
  logic [1:0]       w_br_push [0:WARPS-1];
  logic [WARPS-1:0] inflight, bar_wait, elig;
  logic [4:0]       pcount [0:WARPS-1];
  logic [LANES-1:0] pmask  [0:WARPS-1];
  logic [LANES-1:0] init_mask [0:WARPS-1];

  // stack command bus (shared; only the x-warp's stack sees cmd_valid)
  logic [1:0]       cmd_op;
  logic [LANES-1:0] cmd_mask;
  logic [PW-1:0]    cmd_target, cmd_reconv;

  genvar gw;
  generate
    for (gw = 0; gw < WARPS; gw++) begin : g_warp
      always_comb
        for (int l = 0; l < LANES; l++)
          init_mask[gw][l] = (32'(gw * LANES + l) < l_wg_dim);
      sfd_simt_stack #(.LANES(LANES), .DEPTH(DEPTH), .SPW(SPW), .PW(PW)) u_stack (
        .clk(clk), .rst_n(rst_n),
        .init_valid(start && state != ST_RUN), .init_pc(l_entry_pc), .init_mask(init_mask[gw]),
        .cmd_valid(w_cmd_v[gw]), .cmd_op(cmd_op), .cmd_mask(cmd_mask),
        .cmd_target(cmd_target), .cmd_reconv(cmd_reconv),
        .top_pc(w_pc[gw]), .top_rpc(w_rpc[gw]), .top_mask(w_mask[gw]), .live(w_live[gw]),
        .active(w_act[gw]), .sp(w_sp[gw]), .empty(w_empty[gw]), .needs_pop(w_needs_pop[gw]),
        .pop_fire(w_pop_fire[gw]), .pop_dead(w_pop_dead[gw]),
        .br_div(w_br_div[gw]), .br_ovf(w_br_ovf[gw]), .br_push(w_br_push[gw]),
        .dbg_entries(w_dbg[gw]));
      assign elig[gw] = run && !inflight[gw] && !w_empty[gw] && !w_needs_pop[gw] && !bar_wait[gw];
    end
  endgenerate

  // ======================================================================
  // S stage: loose round-robin select + instruction fetch
  // ======================================================================
  logic [WW-1:0] last, s_warp;
  logic          s_any, s_fire;
  logic          x_valid, x_stall, x_fault, x_commit;
  logic [WW-1:0] x_warp;
  logic          wdog_fire, done_now;

  always_comb begin
    s_any  = 1'b0;
    s_warp = '0;
    for (int k = 1; k <= WARPS; k++) begin
      int idx;
      idx = {{(32-WW){1'b0}}, last} + k;
      if (idx >= WARPS) idx = idx - WARPS;
      if (!s_any && elig[idx]) begin
        s_any  = 1'b1;
        s_warp = WW'(idx);
      end
    end
  end
  assign s_fire = run && s_any && !x_stall && !x_fault && !wdog_fire;

  logic [31:0] imem [0:IMEM_WORDS-1];
  logic [31:0] imem_q;
  always_ff @(posedge clk) begin
    if (!run && host_imem_we) imem[host_imem_addr] <= host_imem_wdata;
    if (s_fire) imem_q <= imem[w_pc[s_warp][IAW-1:0]];
  end

  // ======================================================================
  // X stage
  // ======================================================================
  logic [PW-1:0]    x_pc, x_rpc;
  logic [LANES-1:0] x_act, x_live, x_ex;
  logic [SPW-1:0]   x_sp;
  logic             x_in_win;

  assign x_pc     = w_pc[x_warp];
  assign x_rpc    = w_rpc[x_warp];
  assign x_act    = w_act[x_warp];
  assign x_live   = w_live[x_warp];
  assign x_sp     = w_sp[x_warp];
  assign x_in_win = (pcount[x_warp] != 5'd0);
  assign x_ex     = x_in_win ? (x_act & pmask[x_warp]) : x_act;

  logic        d_illegal, d_b_imm, d_rd_we, d_pol_z;
  logic [3:0]  d_cls, d_fn, d_rd, d_rs1, d_rs2;
  logic [31:0] d_imm;
  logic [10:0] d_imm2;
  sfd_decode #(.PRED_EN(PRED_EN)) u_dec (
    .insn(imem_q), .illegal(d_illegal), .cls(d_cls), .alu_fn(d_fn), .b_imm(d_b_imm),
    .rd_we(d_rd_we), .pol_z(d_pol_z), .rd(d_rd), .rs1(d_rs1), .rs2(d_rs2), .imm(d_imm), .imm2(d_imm2));

  logic [LANES*32-1:0] rs1v, rs2v, alu_y, sr_y, wa_data, lsu_addr;
  logic [LANES-1:0]    wa_en;
  logic [LANES-1:0]    lsu_wb_en;
  logic [WW-1:0]       lsu_fin_warp;
  logic [3:0]          lsu_wb_reg;
  logic [LANES*32-1:0] lsu_wb_data;

  sfd_regfile #(.LANES(LANES), .WARPS(WARPS), .WW(WW), .LW(LW)) u_rf (
    .clk(clk), .clear(start && !run), .rd_warp(x_warp), .rs1(d_rs1), .rs2(d_rs2),
    .rdata1(rs1v), .rdata2(rs2v),
    .wa_en(wa_en), .wa_warp(x_warp), .wa_reg(d_rd), .wa_data(wa_data),
    .wb_en(lsu_wb_en), .wb_warp(lsu_fin_warp), .wb_reg(lsu_wb_reg), .wb_data(lsu_wb_data),
    .dbg_warp(dbg_warp), .dbg_lane(dbg_lane), .dbg_reg(dbg_reg), .dbg_data(dbg_rdata));

  genvar gl;
  generate
    for (gl = 0; gl < LANES; gl++) begin : g_lane
      sfd_alu u_alu (.fn(d_fn), .a(rs1v[gl*32 +: 32]), .b(d_b_imm ? d_imm : rs2v[gl*32 +: 32]),
                     .y(alu_y[gl*32 +: 32]));
      logic [31:0] tid;
      assign tid = 32'(x_warp) * 32'(LANES) + 32'(gl);
      always_comb begin
        case (d_imm[4:0])
          5'd0:    sr_y[gl*32 +: 32] = 32'(gl);
          5'd1:    sr_y[gl*32 +: 32] = 32'(x_warp);
          5'd2:    sr_y[gl*32 +: 32] = tid;
          5'd3:    sr_y[gl*32 +: 32] = wg_id;
          5'd4:    sr_y[gl*32 +: 32] = wg_dim;
          5'd5:    sr_y[gl*32 +: 32] = grid_dim;
          5'd6:    sr_y[gl*32 +: 32] = gtid_base + tid;
          5'd7:    sr_y[gl*32 +: 32] = 32'(LANES);
          5'd8:    sr_y[gl*32 +: 32] = shared_bytes;
          default: sr_y[gl*32 +: 32] = args[d_imm[2:0] * 32 +: 32];
        endcase
      end
      assign lsu_addr[gl*32 +: 32] = rs1v[gl*32 +: 32] + ((d_cls == C_ATOM) ? 32'd0 : d_imm);
    end
  endgenerate

  // ---------------------------------------------------------------- per-lane predicates
  logic [LANES-1:0] rs1_zero, cond, mis, rng, mfail;
  logic             is_mem, is_glob;
  always_comb begin
    is_mem  = (d_cls == C_LDG) || (d_cls == C_STG) || (d_cls == C_LDS) || (d_cls == C_STS) || (d_cls == C_ATOM);
    is_glob = (d_cls == C_LDG) || (d_cls == C_STG) || (d_cls == C_ATOM);
    for (int l = 0; l < LANES; l++) begin
      rs1_zero[l] = (rs1v[l*32 +: 32] == 32'd0);
      cond[l]     = d_pol_z ? rs1_zero[l] : !rs1_zero[l];
      mis[l]      = (lsu_addr[l*32 +: 2] != 2'b00);
      rng[l]      = is_glob ? (lsu_addr[l*32 +: 32] >= 32'(GMEM_WORDS * 4))
                            : (lsu_addr[l*32 +: 32] >= shared_bytes);
      mfail[l]    = x_ex[l] && is_mem && (mis[l] || rng[l]);
    end
  end

  // ---------------------------------------------------------------- targets
  logic [31:0] pc32, tgt32, rcv32, win_end;
  logic        tgt_bad, rcv_bad;
  assign pc32    = {{(32-PW){1'b0}}, x_pc};
  assign tgt32   = pc32 + d_imm;                         // bra (off26) or bz/bnz (toff11)
  assign rcv32   = pc32 + {21'd0, d_imm2};
  assign tgt_bad = (tgt32 >= {{(32-PW){1'b0}}, code_words});
  assign rcv_bad = (rcv32 >= {{(32-PW){1'b0}}, code_words});
  assign win_end = pc32 + d_imm;                          // pz/pnz: last instruction of the window

  // ---------------------------------------------------------------- fault selection
  logic [7:0]    xf_code;
  logic [31:0]   xf_data;
  logic [LW-1:0] xf_lane, act_low, mfail_low;
  assign act_low   = LW'(lowbit32({{(32-LANES){1'b0}}, x_act}));
  assign mfail_low = LW'(lowbit32({{(32-LANES){1'b0}}, mfail}));

  always_comb begin
    xf_code = F_NONE;
    xf_data = 32'd0;
    xf_lane = act_low;
    if (x_pc >= code_words) begin
      xf_code = F_PC_RANGE;  xf_data = pc32;
    end else if (x_rpc != RPC_NONE && x_pc > x_rpc) begin
      xf_code = F_RECONV;    xf_data = {{(32-PW){1'b0}}, x_rpc};
    end else if (d_illegal) begin
      xf_code = F_ILLEGAL_INSN; xf_data = imem_q;
    end else if (x_in_win && (d_cls == C_EXIT || d_cls == C_BAR || d_cls == C_TRAP ||
                              d_cls == C_JUMP || d_cls == C_BRANCH || d_cls == C_PRED)) begin
      xf_code = F_PRED_WINDOW; xf_data = imem_q;
    end else begin
      case (d_cls)
        C_JUMP:   if (tgt_bad) begin xf_code = F_PC_RANGE; xf_data = tgt32; end
        C_BRANCH: if (tgt_bad)                    begin xf_code = F_PC_RANGE; xf_data = tgt32; end
                  else if (rcv_bad)               begin xf_code = F_PC_RANGE; xf_data = rcv32; end
                  else if (w_br_ovf[x_warp])      begin xf_code = F_STACK_OVERFLOW; xf_data = 32'(x_sp); end
        C_BAR:    if (x_act != x_live) begin xf_code = F_BAR_DIVERGENT; xf_data = 32'(x_live); end
        C_TRAP:   begin xf_code = F_TRAP; xf_data = d_imm; end
        C_PRED:   if (x_rpc != RPC_NONE && win_end >= {{(32-PW){1'b0}}, x_rpc}) begin
                    xf_code = F_PRED_WINDOW; xf_data = imem_q;
                  end
        default:  if (mfail != '0) begin
                    xf_lane = mfail_low;
                    xf_data = lsu_addr[mfail_low*32 +: 32];
                    if (is_glob) xf_code = mis[mfail_low] ? F_GMEM_ALIGN : F_GMEM_RANGE;
                    else         xf_code = mis[mfail_low] ? F_SMEM_ALIGN : F_SMEM_RANGE;
                  end
      endcase
    end
  end

  // ---------------------------------------------------------------- commit
  logic lsu_busy, lsu_fin, lsu_start;
  assign x_fault   = x_valid && run && (xf_code != F_NONE);
  assign x_stall   = x_valid && run && !x_fault && is_mem && (x_ex != '0) && lsu_busy;
  assign x_commit  = x_valid && run && !x_fault && !x_stall;
  assign lsu_start = x_commit && is_mem && (x_ex != '0);

  // register write port A: ALU and rdsr results, execution-mask lanes only
  assign wa_en   = (x_commit && d_rd_we && !is_mem && d_rd != 4'd0) ? x_ex : '0;
  assign wa_data = (d_cls == C_SREAD) ? sr_y : alu_y;

  // stack command
  always_comb begin
    case (d_cls)
      C_JUMP:   cmd_op = CMD_JUMP;
      C_BRANCH: cmd_op = CMD_BRANCH;
      C_EXIT:   cmd_op = CMD_EXIT;
      default:  cmd_op = CMD_SEQ;
    endcase
    cmd_mask   = (d_cls == C_EXIT) ? x_act : cond;
    cmd_target = tgt32[PW-1:0];
    cmd_reconv = rcv32[PW-1:0];
    for (int w = 0; w < WARPS; w++) w_cmd_v[w] = x_commit && (x_warp == WW'(w));
  end

  // ======================================================================
  // LSU and memories
  // ======================================================================
  logic          g_en, g_we, s_en, s_we, l_g_en, l_g_we, l_s_en, l_s_we;
  logic [GAW-1:0] g_addr, l_g_addr;
  logic [SAW-1:0] s_addr, l_s_addr;
  logic [31:0]   g_wdata, s_wdata, l_g_wdata, l_s_wdata, g_q, s_q;
  /* verilator lint_off UNUSEDSIGNAL */
  logic          acc_v, acc_shared;
  logic [LW-1:0] acc_lane;
  logic [1:0]    acc_kind;
  logic [31:0]   acc_addr, acc_rdata, acc_wdata;
  logic [WW-1:0] acc_warp;
  /* verilator lint_on UNUSEDSIGNAL */

  sfd_lsu #(.LANES(LANES), .WW(WW), .GAW(GAW), .SAW(SAW), .LW(LW)) u_lsu (
    .clk(clk), .rst_n(rst_n), .abort(!run),
    .start(lsu_start), .req_warp(x_warp),
    .req_kind((d_cls == C_STG || d_cls == C_STS) ? 2'd1 : (d_cls == C_ATOM) ? 2'd2 : 2'd0),
    .req_shared(d_cls == C_LDS || d_cls == C_STS), .req_mask(x_ex), .req_addr(lsu_addr),
    .req_wdata(rs2v), .req_rd(d_rd), .busy(lsu_busy),
    .fin(lsu_fin), .fin_warp(lsu_fin_warp), .wb_en(lsu_wb_en), .wb_reg(lsu_wb_reg), .wb_data(lsu_wb_data),
    .g_en(l_g_en), .g_we(l_g_we), .g_addr(l_g_addr), .g_wdata(l_g_wdata), .g_q(g_q),
    .s_en(l_s_en), .s_we(l_s_we), .s_addr(l_s_addr), .s_wdata(l_s_wdata), .s_q(s_q),
    .acc_v(acc_v), .acc_lane(acc_lane), .acc_kind(acc_kind), .acc_shared(acc_shared),
    .acc_addr(acc_addr), .acc_rdata(acc_rdata), .acc_wdata(acc_wdata), .acc_warp(acc_warp));

  assign g_en    = run ? l_g_en    : host_gmem_en;
  assign g_we    = run ? l_g_we    : host_gmem_we;
  assign g_addr  = run ? l_g_addr  : host_gmem_addr;
  assign g_wdata = run ? l_g_wdata : host_gmem_wdata;
  assign s_en    = run ? l_s_en    : host_smem_en;
  assign s_we    = run ? l_s_we    : host_smem_we;
  assign s_addr  = run ? l_s_addr  : host_smem_addr;
  assign s_wdata = run ? l_s_wdata : host_smem_wdata;
  assign host_gmem_rdata = g_q;
  assign host_smem_rdata = s_q;

  sfd_ram #(.WORDS(GMEM_WORDS), .AW(GAW)) u_gmem (.clk(clk), .en(g_en), .we(g_we), .addr(g_addr), .wdata(g_wdata), .q(g_q));
  sfd_ram #(.WORDS(SMEM_WORDS), .AW(SAW)) u_smem (.clk(clk), .en(s_en), .we(s_we), .addr(s_addr), .wdata(s_wdata), .q(s_q));

  // ======================================================================
  // Barrier, completion, watchdog
  // ======================================================================
  logic bar_release;
  assign bar_release = run && (bar_wait != '0) && ((bar_wait | w_empty) == {WARPS{1'b1}});
  assign done_now    = run && (w_empty == {WARPS{1'b1}}) && !x_valid && !lsu_busy;

  logic [31:0] pc_cnt [0:NP-1];
  assign wdog_fire = run && !x_fault && !done_now && (wdog != 32'd0) && (pc_cnt[P_CYCLES] >= wdog);

  // ======================================================================
  // Sequential state
  // ======================================================================
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state      <= ST_IDLE;
      done       <= 1'b0;
      faulted    <= 1'b0;
      fault_code <= F_NONE;
      fault_warp <= '0;
      fault_pc   <= '0;
      fault_lane <= '0;
      fault_mask <= '0;
      fault_data <= '0;
      x_valid    <= 1'b0;
      x_warp     <= '0;
      last       <= WW'(WARPS - 1);
      inflight   <= '0;
      bar_wait   <= '0;
      code_words <= '0;
      wg_dim     <= '0; wg_id <= '0; grid_dim <= '0; shared_bytes <= '0; wdog <= '0; gtid_base <= '0;
      args       <= '0;
      for (int w = 0; w < WARPS; w++) begin pcount[w] <= '0; pmask[w] <= '0; end
    end else if (start && !run) begin
      state      <= ST_RUN;
      done       <= 1'b0;
      faulted    <= 1'b0;
      fault_code <= F_NONE;
      x_valid    <= 1'b0;
      last       <= WW'(WARPS - 1);
      inflight   <= '0;
      bar_wait   <= '0;
      code_words <= l_code_words;
      wg_dim     <= l_wg_dim;
      wg_id      <= l_wg_id;
      grid_dim   <= l_grid_dim;
      shared_bytes <= l_shared_bytes;
      wdog       <= l_wdog;
      gtid_base  <= l_wg_id * l_wg_dim;
      args       <= l_args;
      for (int w = 0; w < WARPS; w++) begin pcount[w] <= '0; pmask[w] <= '0; end
    end else if (run) begin
      // ---- faults and completion (execution fault > completion > watchdog)
      if (x_fault) begin
        state      <= ST_FAULT;
        faulted    <= 1'b1;
        fault_code <= xf_code;
        fault_warp <= x_warp;
        fault_pc   <= x_pc;
        fault_lane <= xf_lane;
        fault_mask <= x_act;
        fault_data <= xf_data;
        x_valid    <= 1'b0;
      end else if (done_now) begin
        state <= ST_IDLE;
        done  <= 1'b1;
      end else if (wdog_fire) begin
        state      <= ST_FAULT;
        faulted    <= 1'b1;
        fault_code <= F_WATCHDOG;
        fault_warp <= '1;
        fault_pc   <= '0;
        fault_lane <= '1;
        fault_mask <= '0;
        fault_data <= pc_cnt[P_CYCLES];
        x_valid    <= 1'b0;
      end else begin
        // ---- pipeline advance
        if (!x_stall) begin
          x_valid <= s_fire;
          if (s_fire) begin
            x_warp <= s_warp;
            last   <= s_warp;
          end
        end
        // ---- in-flight bookkeeping
        for (int w = 0; w < WARPS; w++) begin
          if (s_fire && s_warp == WW'(w))                  inflight[w] <= 1'b1;
          if (x_commit && !lsu_start && x_warp == WW'(w))  inflight[w] <= 1'b0;
          if (lsu_fin && lsu_fin_warp == WW'(w))           inflight[w] <= 1'b0;
        end
        // ---- barrier: arrive / release
        if (bar_release) bar_wait <= '0;
        else if (x_commit && d_cls == C_BAR) bar_wait[x_warp] <= 1'b1;
        // ---- predication window
        if (x_commit) begin
          if (d_cls == C_PRED) begin
            pmask[x_warp]  <= x_ex & cond;
            pcount[x_warp] <= d_imm[4:0];
          end else if (x_in_win) begin
            pcount[x_warp] <= pcount[x_warp] - 5'd1;
          end
        end
      end
    end
  end

  // ======================================================================
  // Performance counters
  // ======================================================================
  logic [SPW-1:0] sp_max_now;
  logic [5:0]     n_pop_r, n_pop_x;
  logic           any_needs_pop;
  always_comb begin
    sp_max_now    = '0;
    n_pop_r       = '0;
    n_pop_x       = '0;
    any_needs_pop = 1'b0;
    for (int w = 0; w < WARPS; w++) begin
      if (w_sp[w] > sp_max_now) sp_max_now = w_sp[w];
      if (w_pop_fire[w] && !w_pop_dead[w]) n_pop_r = n_pop_r + 6'd1;
      if (w_pop_fire[w] &&  w_pop_dead[w]) n_pop_x = n_pop_x + 6'd1;
      if (w_needs_pop[w]) any_needs_pop = 1'b1;
    end
  end

  logic [31:0] inc [0:NP-1];
  always_comb begin
    for (int i = 0; i < NP; i++) inc[i] = 32'd0;
    inc[P_CYCLES]    = 32'd1;
    if (x_commit) begin
      inc[P_ISSUED]     = 32'd1;
      inc[P_LANE_SLOTS] = 32'(popc32({{(32-LANES){1'b0}}, x_ex}));
      inc[P_LIVE_SLOTS] = 32'(popc32({{(32-LANES){1'b0}}, x_live}));
      inc[P_PRED_OFF]   = 32'(popc32({{(32-LANES){1'b0}}, x_act & ~x_ex}));
      inc[P_CTRL]       = (d_cls == C_JUMP || d_cls == C_BRANCH || d_cls == C_PRED) ? 32'd1 : 32'd0;
      inc[P_BRANCH]     = (d_cls == C_BRANCH) ? 32'd1 : 32'd0;
      inc[P_DIVERGE]    = (d_cls == C_BRANCH && w_br_div[x_warp]) ? 32'd1 : 32'd0;
      inc[P_PUSH]       = (d_cls == C_BRANCH) ? 32'(w_br_push[x_warp]) : 32'd0;
      inc[P_SP_SUM]     = 32'(x_sp);
      inc[P_PRED_INSN]  = x_in_win ? 32'd1 : 32'd0;
    end
    inc[P_POP_R]     = 32'(n_pop_r);
    inc[P_POP_X]     = 32'(n_pop_x);
    inc[P_IDLE]      = (!x_valid) ? 32'd1 : 32'd0;
    inc[P_STALL]     = x_stall ? 32'd1 : 32'd0;
    inc[P_LSU_BUSY]  = lsu_busy ? 32'd1 : 32'd0;
    inc[P_BAR_WAIT]  = 32'(popc32({{(32-WARPS){1'b0}}, bar_wait}));
    inc[P_MEM_LANES] = acc_v ? 32'd1 : 32'd0;
    inc[P_POP_STALL] = (!s_any && any_needs_pop) ? 32'd1 : 32'd0;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NP; i++) pc_cnt[i] <= '0;
    end else if (start && !run) begin
      for (int i = 0; i < NP; i++) pc_cnt[i] <= '0;
    end else if (run && !x_fault) begin
      for (int i = 0; i < NP; i++)
        if (i == P_SP_MAX) pc_cnt[i] <= (32'(sp_max_now) > pc_cnt[i]) ? 32'(sp_max_now) : pc_cnt[i];
        else               pc_cnt[i] <= pc_cnt[i] + inc[i];
    end
  end
  always_comb for (int i = 0; i < NP; i++) perf[i*32 +: 32] = pc_cnt[i];

  // ======================================================================
  // Trace taps (read hierarchically by the testbench; removed by synthesis)
  // ======================================================================
  /* verilator lint_off UNUSEDSIGNAL */
  logic [EW*DEPTH-1:0] trc_stack;
  /* verilator lint_on UNUSEDSIGNAL */
  assign trc_stack = w_dbg[x_warp];

`ifndef SYNTHESIS
`ifdef SFD_ASSERT
  // ======================================================================
  // Assertions (docs/05-verification.md lists them with their intent)
  // ======================================================================
  always @(posedge clk) if (rst_n && run) begin
    // C1 no lane outside the active mask executes; window lanes are a subset of the predicate
    if (x_commit && (x_ex & ~x_act) != '0) begin $display("SFD-ASSERT C1 exec mask outside active"); $fatal(1); end
    if (x_commit && x_in_win && (x_ex & ~pmask[x_warp]) != '0) begin $display("SFD-ASSERT C1 window lane outside predicate"); $fatal(1); end
    // C2 register writes only for execution-mask lanes
    if ((wa_en & ~x_ex) != '0) begin $display("SFD-ASSERT C2 register write for an inactive lane"); $fatal(1); end
    // C3 the issuing warp's stack is settled and it has one instruction in flight
    if (x_valid && (w_empty[x_warp] || w_needs_pop[x_warp] || !inflight[x_warp])) begin
      $display("SFD-ASSERT C3 x-warp %0d not settled / not in flight", x_warp); $fatal(1);
    end
    // C4 only eligible warps are selected; a selected warp is never already in flight
    if (s_fire && (!elig[s_warp] || inflight[s_warp])) begin $display("SFD-ASSERT C4 bad select"); $fatal(1); end
    // C5 write ports A and B never target the same warp
    if (wa_en != '0 && lsu_wb_en != '0 && x_warp == lsu_fin_warp) begin $display("SFD-ASSERT C5 regfile port conflict"); $fatal(1); end
    // C6 barrier: a waiting warp never issues; arrival only with active == live;
    //    release only when every warp is waiting or done
    if (s_fire && bar_wait[s_warp]) begin $display("SFD-ASSERT C6 waiting warp issued"); $fatal(1); end
    if (x_commit && d_cls == C_BAR && x_act != x_live) begin $display("SFD-ASSERT C6 divergent barrier arrival"); $fatal(1); end
    if (bar_release && x_commit && d_cls == C_BAR) begin $display("SFD-ASSERT C6 release races arrival"); $fatal(1); end
    // C7 control instructions never commit inside a predication window
    if (x_commit && x_in_win && (d_cls == C_JUMP || d_cls == C_BRANCH || d_cls == C_EXIT ||
                                 d_cls == C_BAR || d_cls == C_PRED || d_cls == C_TRAP)) begin
      $display("SFD-ASSERT C7 control instruction in window"); $fatal(1);
    end
    // C8 a done warp (empty stack) has no live lane and nothing in flight
    for (int w = 0; w < WARPS; w++)
      if (w_empty[w] && (w_live[w] != '0 || inflight[w] || bar_wait[w])) begin
        $display("SFD-ASSERT C8 empty warp %0d still live/in flight/waiting", w); $fatal(1);
      end
    // C9 a committed instruction never runs past its reconvergence point
    if (x_commit && x_rpc != RPC_NONE && x_pc >= x_rpc) begin $display("SFD-ASSERT C9 pc beyond rpc committed"); $fatal(1); end
    // C10 while running, memory is written only by the LSU performing an access of a busy instruction
    if ((g_we || s_we) && !(lsu_busy && acc_v)) begin $display("SFD-ASSERT C10 memory write outside an LSU access"); $fatal(1); end
  end
`endif
`endif
endmodule
