// Single-port synchronous SRAM (read-first), one access per cycle.
module sfd_ram #(
  parameter int WORDS = 1024,
  parameter int AW    = $clog2(WORDS)
) (
  input  logic          clk,
  input  logic          en,
  input  logic          we,
  input  logic [AW-1:0] addr,
  input  logic [31:0]   wdata,
  output logic [31:0]   q
);
  logic [31:0] mem [0:WORDS-1];
  always_ff @(posedge clk) begin
    if (en) begin
      if (we) mem[addr] <= wdata;
      q <= mem[addr];
    end
  end
endmodule
