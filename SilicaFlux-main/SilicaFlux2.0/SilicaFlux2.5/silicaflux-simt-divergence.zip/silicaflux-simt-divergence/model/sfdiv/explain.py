"""Step-by-step reconvergence narratives from an RTL run.

The RTL trace provides cycles, settled stacks and pops; the reference model,
replayed on the RTL's warp order (and verified identical by rtl.compare), provides
the *reason* for each stack change (branch outcome, reuse decision, paths
pushed).  The narrative states, for every instruction of a warp:

    cycle, pc, instruction, active lanes, stack (top first), and what happened

Masks print lane 0 on the left: '#' = lane in the mask, '.' = not.
Stack entries print as (pc, rpc, mask) with '-' for "no reconvergence point".
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

from . import isa
from .asm import Program
from .isa import RPC_NONE
from .machine import Result
from .rtl import RtlResult
from .simt import lanes_str, mask_str


def _ent(e, L) -> str:
    pc, rpc, m = e
    return f"({pc},{'-' if rpc == RPC_NONE else rpc},{mask_str(m, L)})"


def _stack(st, L) -> str:
    return " ".join(_ent(e, L) for e in reversed(st)) if st else "(empty)"


def _label(prog: Optional[Program], pc: int) -> str:
    if prog is None:
        return ""
    labs = prog.labels_at(pc)
    return f" <{labs[0]}>" if labs else ""


def _what(c, L, prog) -> List[str]:
    """Explain the effect of committed instruction c (a model Commit)."""
    d = isa.decode(c.word)
    out: List[str] = []
    if c.branch is not None:
        b = c.branch
        t_pc = c.pc + d.imm
        r_pc = c.pc + d.imm2
        cond = "== 0" if d.op.name == "bz" else "!= 0"
        if b.kind == "none-taken":
            out.append(f"uniform: no active lane has r{d.rs1} {cond}; all fall through to {c.pc + 1}")
        elif b.kind == "all-taken":
            out.append(f"uniform: every active lane has r{d.rs1} {cond}; all go to {t_pc}{_label(prog, t_pc)}")
        else:
            out.append(f"DIVERGE on r{d.rs1} {cond}: taken {lanes_str(b.taken)} -> {t_pc}{_label(prog, t_pc)}, "
                       f"fall-through {lanes_str(b.fall)} -> {c.pc + 1}; reconverge at {r_pc}{_label(prog, r_pc)}")
            waits = []
            if t_pc == r_pc:
                waits.append(f"taken lanes {lanes_str(b.taken)} need no path: they wait at {r_pc}")
            if c.pc + 1 == r_pc:
                waits.append(f"fall-through lanes {lanes_str(b.fall)} need no path: they wait at {r_pc}")
            if b.reuse:
                out.append(f"top already reconverges at {r_pc} -> REUSE: the top entry is replaced"
                           + (f", {b.needed} entry pushed" if b.needed else ", nothing pushed"))
            else:
                out.append(f"top entry becomes the reconvergence entry (pc := {r_pc}); "
                           f"{b.needed} path entr{'y' if b.needed == 1 else 'ies'} pushed")
            out += waits
            if len(b.paths) == 2:
                out.append("taken path is on top and runs first; the fall-through path waits below it")
    elif d.cls == isa.JUMP:
        out.append(f"uniform jump to {c.pc + d.imm}{_label(prog, c.pc + d.imm)}")
    elif d.cls == isa.EXIT:
        out.append(f"EXIT: lanes {lanes_str(c.exec_mask)} terminate; live {mask_str(c.live, L)} -> "
                   f"{mask_str(c.live_after, L)}")
    elif d.cls == isa.BAR:
        out.append("barrier arrival (active == live): warp waits until every warp that is not done has arrived")
    elif d.cls == isa.PRED:
        pm, n = c.pred_set
        out.append(f"predication window: next {n} instruction(s) run only in lanes {lanes_str(pm)} "
                   f"(no branch, no stack change)")
    elif c.pcount:
        out.append(f"inside window ({c.pcount} left): lanes {lanes_str(c.active & ~c.exec_mask)} are predicated off "
                   f"and have no effect")
    if c.mem:
        kinds = {"R": "load", "W": "store", "A": "atomic"}
        lanes_ = [a.lane for a in c.mem]
        out.append(f"memory: {kinds[c.mem[0].kind]} performed for lanes {lanes_} in ascending order "
                   f"(inactive lanes do nothing)")
    if c.bar_release:
        out.append(f"BARRIER RELEASE: warps {lanes_str(c.bar_release)} resume together")
    return out


def _explain_fault(cfg, f, model: Result, prog) -> List[str]:
    """Why the fault happened, reconstructed from the (precise) state at the fault."""
    L = cfg.lanes
    if not model.stacks or f.code not in (isa.F_STACK_OVERFLOW, isa.F_RECONV, isa.F_BAR_DIVERGENT):
        return []
    entries, live = model.stacks[f.warp]
    out = [f"  state at the fault: stack {_stack(entries, L)}, live {mask_str(live, L)}"]
    if f.code == isa.F_STACK_OVERFLOW and prog is not None:
        from .simt import ReconvStack
        d = isa.decode(prog.words[f.pc])
        s = ReconvStack(cfg.depth)
        s.entries = [list(e) for e in entries]
        s.live = live
        bz = d.op.name == "bz"
        cond = 0
        for l in range(L):
            if (s.active >> l) & 1 and ((model.regs[f.warp][l][d.rs1] == 0) == bz):
                cond |= 1 << l
        p = s.plan_branch(cond, f.pc + d.imm, f.pc + d.imm2)
        out.append(f"  {isa.disasm(prog.words[f.pc], f.pc)} would diverge: taken {lanes_str(p.taken)}, "
                   f"fall-through {lanes_str(p.fall)}; reuse={p.reuse}; it needs {p.needed} new "
                   f"entr{'y' if p.needed == 1 else 'ies'}: {s.sp} + {p.needed} > DEPTH {cfg.depth}")
    elif f.code == isa.F_RECONV:
        out.append(f"  the path's pc {f.pc} is beyond its reconvergence point {f.data}: some path of the branch "
                   f"that pushed this entry can leave the region without meeting {f.data} (contract C2 violated)")
    elif f.code == isa.F_BAR_DIVERGENT:
        out.append(f"  bar requires active == live; active {mask_str(f.mask, L)} != live {mask_str(f.data, L)}")
    return out


def narrate(cfg: isa.Config, rtl_res: RtlResult, model: Result, prog: Optional[Program] = None,
            warps: Optional[Sequence[int]] = None, title: str = "") -> str:
    L = cfg.lanes
    warps = list(range(cfg.warps)) if warps is None else list(warps)
    # align model commits with RTL commits (same global order, verified by rtl.compare)
    assert len(model.trace) == len(rtl_res.commits), "model/RTL commit streams differ; run rtl.compare first"
    pops_by_warp: Dict[int, List[tuple]] = {}
    for cyc, w, reason, e in rtl_res.pops:
        pops_by_warp.setdefault(w, []).append((cyc, reason, e))
    lines: List[str] = []
    if title:
        lines += [title, "=" * len(title), ""]
    lines.append(f"configuration: {L} lanes x {cfg.warps} warps, stack depth {cfg.depth}; "
                 f"completion {rtl_res.cycles} cycles; status {rtl_res.status}")
    lines.append("masks: lane 0 on the left, '#' = in mask.  entries: (pc, rpc, mask), top first.")
    lines.append("")
    for w in warps:
        rows = [(r, m) for r, m in zip(rtl_res.commits, model.trace) if r.warp == w]
        if not rows:
            lines.append(f"--- warp {w}: no live thread at launch (done immediately) ---")
            lines.append("")
            continue
        lines.append(f"--- warp {w} ---")
        pops = list(pops_by_warp.get(w, []))
        for i, (r, m) in enumerate(rows):
            # pops that happened before this instruction issued
            while pops and pops[0][0] < r.cyc:
                cyc, reason, e = pops.pop(0)
                why = (f"reached its reconvergence pc {e[0]}" if reason == "R"
                       else "has no live lane left (all its lanes exited)")
                lines.append(f"{cyc:6d}      POP  {_ent(e, L)} {why}")
            dis = isa.disasm(r.word, r.pc)
            lines.append(f"{r.cyc:6d} {r.pc:4d}{_label(prog, r.pc):<10s} {dis:<26s} {mask_str(r.exec_mask, L)}  "
                         f"sp={r.sp}  {_stack(r.stack, L)}")
            for s in _what(m, L, prog):
                lines.append(" " * 13 + "-> " + s)
        while pops:
            cyc, reason, e = pops.pop(0)
            why = (f"reached its reconvergence pc {e[0]}" if reason == "R"
                   else "has no live lane left (all its lanes exited)")
            lines.append(f"{cyc:6d}      POP  {_ent(e, L)} {why}")
        lines.append("              warp done (stack empty)" if not (rtl_res.fault and rtl_res.fault.warp == w)
                     else f"              FAULT {rtl_res.fault}")
        lines.append("")
    if rtl_res.fault:
        f = rtl_res.fault
        lines.append(f"FAULT {f.name}: warp {f.warp} pc {f.pc} lane {f.lane} active {mask_str(f.mask, L)} "
                     f"data 0x{f.data:x} — precise: the faulting instruction changed no state")
        lines += _explain_fault(cfg, f, model, prog)
    return "\n".join(lines) + "\n"
