"""Static checker for the reconvergence contract between compiler/assembler and hardware.

Contract (docs/02-compiler-contract.md), for every conditional branch ``b`` with
taken target ``t``, fall-through ``b+1`` and reconvergence operand ``R``:

  C1  b < R < CODE_WORDS and 0 <= t < CODE_WORDS            (else the encoding / F_PC_RANGE)
  C2  *Region closure.*  Let REGION(b, R) be every instruction reachable from
      ``t`` or ``b+1`` without passing through ``R`` (``exit``/``trap`` end a path).
      Every instruction in the region has pc < R, and no path falls off the
      end of the code.  This is exactly the condition under which no lane of a
      path pushed by ``b`` can run past ``R`` (F_RECONV is impossible) and every
      lane that does not exit arrives at ``R``.
  C3  *Predication windows* (SFX-PRED): the ``n`` instructions after a ``pz/pnz``
      are inside the code, contain no control instruction, and when the window
      lies in REGION(b, R) its last instruction is before ``R``.

``R`` is *minimal* when no smaller address satisfies C2.  A valid but non-minimal
``R`` is legal and only delays reconvergence (reported as a warning).  The
minimal valid ``R`` equals the classic immediate post-dominator except where a
path ends in ``exit``: there the classic IPDOM is the virtual kernel exit, while
the contract allows the earlier join (the early-exit idiom ``bnz ok, go, go;
exit; go:``).  Both are reported.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Set

from . import isa

EXIT_NODE = -1


@dataclass
class BranchInfo:
    pc: int
    target: int
    reconv: int
    valid: bool
    minimal: Optional[int]          # smallest valid reconvergence address (None: none exists <= limit)
    ipdom: Optional[int]            # classic immediate post-dominator (EXIT_NODE = kernel exit)
    region: Set[int] = field(default_factory=set)
    problems: List[str] = field(default_factory=list)


@dataclass
class ContractReport:
    code_words: int
    branches: List[BranchInfo]
    errors: List[str]
    warnings: List[str]

    @property
    def ok(self) -> bool:
        return not self.errors

    def summary(self) -> str:
        lines = [f"{len(self.branches)} conditional branches, {len(self.errors)} errors, {len(self.warnings)} warnings"]
        for b in self.branches:
            ip = "exit" if b.ipdom == EXIT_NODE else b.ipdom
            tag = "ok" if b.valid and b.minimal == b.reconv else ("LATE" if b.valid else "INVALID")
            lines.append(f"  pc {b.pc:4d}: target {b.target:4d} reconv {b.reconv:4d}  minimal {b.minimal}  "
                         f"ipdom {ip}  [{tag}]")
        lines += ["  error: " + e for e in self.errors]
        lines += ["  warning: " + w for w in self.warnings]
        return "\n".join(lines)


def successors(words: Sequence[int], code_words: int, pred_en: bool = True) -> Dict[int, List[int]]:
    """CFG over instruction indices.  ``code_words`` as a successor means 'falls off the end'."""
    succ: Dict[int, List[int]] = {}
    for pc in range(code_words):
        d = isa.decode(words[pc], pred_en)
        if d.illegal or d.cls in (isa.EXIT, isa.TRAP):
            succ[pc] = []
        elif d.cls == isa.JUMP:
            succ[pc] = [pc + d.imm]
        elif d.cls == isa.BRANCH:
            succ[pc] = sorted({pc + d.imm, pc + 1})
        else:
            succ[pc] = [pc + 1]
    return succ


def region(succ: Dict[int, List[int]], starts: Sequence[int], stop: int) -> Set[int]:
    seen: Set[int] = set()
    work = [s for s in starts if s != stop]
    while work:
        n = work.pop()
        if n in seen:
            continue
        seen.add(n)
        for s in succ.get(n, []):
            if s != stop and s not in seen:
                work.append(s)
    return seen


def _region_ok(succ, code_words, starts, R) -> bool:
    reg = region(succ, starts, R)
    return all(0 <= n < R and n < code_words for n in reg)


def postdominators(succ: Dict[int, List[int]], code_words: int) -> Dict[int, Optional[int]]:
    """Classic immediate post-dominators with a virtual exit node (EXIT_NODE)."""
    nodes = list(range(code_words))
    allset = set(nodes) | {EXIT_NODE}
    pdom: Dict[int, Set[int]] = {n: set(allset) for n in nodes}
    pdom[EXIT_NODE] = {EXIT_NODE}

    def outs(n):
        ss = succ[n]
        if not ss:
            return [EXIT_NODE]
        return [s if 0 <= s < code_words else EXIT_NODE for s in ss]
    changed = True
    while changed:
        changed = False
        for n in reversed(nodes):
            new = set.intersection(*(pdom[s] for s in outs(n))) | {n}
            if new != pdom[n]:
                pdom[n] = new
                changed = True
    ipdom: Dict[int, Optional[int]] = {}
    for n in nodes:
        strict = pdom[n] - {n}
        # the immediate one is the strict post-dominator that is post-dominated by all others
        cand = [c for c in strict if all(o in pdom[c] for o in strict)]
        ipdom[n] = cand[0] if cand else None
    return ipdom


def check(words: Sequence[int], code_words: Optional[int] = None, pred_en: bool = True) -> ContractReport:
    cw = len(words) if code_words is None else code_words
    succ = successors(words, cw, pred_en)
    ip = postdominators(succ, cw)
    errors: List[str] = []
    warnings: List[str] = []
    branches: List[BranchInfo] = []
    for pc in range(cw):
        d = isa.decode(words[pc], pred_en)
        if d.illegal:
            errors.append(f"pc {pc}: illegal instruction word 0x{words[pc]:08x}")
            continue
        if d.cls not in (isa.EXIT, isa.TRAP, isa.JUMP, isa.BRANCH) and pc + 1 >= cw:
            errors.append(f"pc {pc}: last instruction falls off the end of the code (end every path with exit)")
        if d.cls == isa.JUMP and not 0 <= pc + d.imm < cw:
            errors.append(f"pc {pc}: jump target {pc + d.imm} outside the code")
        if d.cls == isa.PRED:
            n = d.imm
            for q in range(pc + 1, pc + n + 1):
                if q >= cw:
                    errors.append(f"pc {pc}: predication window runs past the end of the code")
                    break
                dq = isa.decode(words[q], pred_en)
                if dq.illegal or dq.cls in isa.WINDOW_FORBIDDEN:
                    errors.append(f"pc {pc}: predication window contains control instruction at {q} "
                                  f"({isa.disasm(words[q], q)})")
        if d.cls != isa.BRANCH:
            continue
        t, R = pc + d.imm, pc + d.imm2
        bi = BranchInfo(pc, t, R, False, None, ip.get(pc))
        if not (0 <= t < cw):
            bi.problems.append(f"target {t} outside the code")
        if not (pc < R < cw):
            bi.problems.append(f"reconvergence address {R} outside ({pc}, {cw})")
        if not bi.problems:
            starts = [t, pc + 1]
            reg = region(succ, starts, R)
            bi.region = reg
            esc = sorted(n for n in reg if n >= R)
            if esc:
                bi.problems.append(f"a path from the branch reaches pc {esc[0]} beyond reconv {R} without meeting it "
                                   f"(F_RECONV when this branch diverges)")
            if any(n >= cw for n in reg):
                bi.problems.append("a path falls off the end of the code")
            bi.valid = not bi.problems
        # minimal valid reconvergence address
        limit = R if bi.valid else cw - 1
        for r2 in range(pc + 1, limit + 1):
            if 0 <= t < cw and _region_ok(succ, cw, [t, pc + 1], r2):
                bi.minimal = r2
                break
        if not bi.valid:
            sug = f" (smallest valid: {bi.minimal})" if bi.minimal is not None else ""
            errors.append(f"pc {pc}: {isa.disasm(words[pc], pc)}: " + "; ".join(bi.problems) + sug)
        elif bi.minimal is not None and bi.minimal < R:
            warnings.append(f"pc {pc}: reconv {R} is valid but later than necessary ({bi.minimal}); "
                            f"lanes stay serialised longer")
        branches.append(bi)
    # C3: windows inside a branch region must end before that region's reconvergence point
    for bi in branches:
        if not bi.valid:
            continue
        for q in bi.region:
            dq = isa.decode(words[q], pred_en)
            if not dq.illegal and dq.cls == isa.PRED and q + dq.imm >= bi.reconv:
                errors.append(f"pc {q}: predication window of {dq.imm} crosses reconvergence point {bi.reconv} "
                              f"of the branch at {bi.pc} (F_PRED_WINDOW)")
    return ContractReport(cw, branches, errors, warnings)
