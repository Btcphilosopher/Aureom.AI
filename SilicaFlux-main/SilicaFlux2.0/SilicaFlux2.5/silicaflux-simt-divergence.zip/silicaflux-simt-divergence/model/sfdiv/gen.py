"""Random structured kernels for property and differential testing.

Every generated kernel terminates (loops are counter-bounded), is race-free
(each thread stores only to its own output slots; shared-memory exchange is
write-before-barrier / read-after-barrier; atomics discard the old value), and
respects the barrier rule (barriers only where the warp cannot be diverged).
Under those conditions the per-thread oracle, the SIMT model, the predicated
variant and the RTL must all produce identical per-thread registers and memory.

Register plan
    r1  tid            (read-only)       r4/r5  loop level 1 counter / bound
    r2  &out[tid*S]    (read-only)       r6/r7  loop level 2 counter / bound
    r3  &in[0]         (read-only)       r8..r10 general
    r11..r15 reserved for the if-converter
Memory plan (word addresses)
    IN_BASE..   read-only input,   OUT_BASE + tid*SLOTS..  per-thread output,
    CNT_BASE..  atomic counters,   shared: tid*SH_SLOTS..  per-thread slots
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, List

from .kc import (Bar, Break, DoWhile, Exit, ExitIf, If, Op, Stmt, While, ops)

IN_BASE, IN_WORDS = 0x100, 64
OUT_BASE, SLOTS = 0x200, 8
CNT_BASE, CNT_WORDS = 0x80, 8
SH_SLOTS = 2
GEN = ["r8", "r9", "r10"]
ALU_R = ["add", "sub", "mul", "and", "or", "xor", "shl", "shr", "sar", "slt", "sltu"]
ALU_I = ["addi", "andi", "ori", "xori", "slti", "sltiu"]


@dataclass
class GenKernel:
    body: List[Stmt]
    gmem: Dict[int, int]
    wg_dim: int
    seed: int


class _G:
    def __init__(self, rng: random.Random, lanes: int, allow_bar: bool):
        self.r = rng
        self.lanes = lanes
        self.allow_bar = allow_bar
        self.nstmt = 0

    def src(self):
        return self.r.choice(["r1", "r4", "r5", "r6", "r7"] + GEN + GEN)

    def alu(self) -> List[Stmt]:
        r = self.r
        rd = r.choice(GEN)
        k = r.random()
        if k < 0.45:
            return [Op(f"{r.choice(ALU_R)} {rd}, {self.src()}, {self.src()}")]
        if k < 0.75:
            return [Op(f"{r.choice(ALU_I)} {rd}, {self.src()}, {r.randint(-40, 40)}")]
        if k < 0.85:
            return [Op(f"{r.choice(['shli', 'shri', 'sari'])} {rd}, {self.src()}, {r.randint(0, 31)}")]
        if k < 0.92:
            return [Op(f"rdsr {rd}, {r.choice(['SR_LANE_ID', 'SR_WARP_ID', 'SR_TID', 'SR_ARG0', 'SR_LANES'])}")]
        return [Op(f"lui {rd}, {r.randint(0, 0x3FFFFF)}")]

    def mem(self) -> List[Stmt]:
        r = self.r
        k = r.random()
        if k < 0.45:
            return [Op(f"stg {self.src()}, [r2 + {4 * r.randrange(SLOTS)}]")]
        if k < 0.75:
            t = r.choice(GEN)
            return ops(f"andi {t}, {self.src()}, {IN_WORDS - 1}; shli {t}, {t}, 2; add {t}, {t}, r3; "
                       f"ldg {r.choice(GEN)}, [{t} + 0]")
        if k < 0.9:
            t = r.choice(GEN)
            return ops(f"addi {t}, r0, {4 * (CNT_BASE + r.randrange(CNT_WORDS))}; atomadd r0, [{t}], {self.src()}")
        # own shared slot (written and read by the same thread only)
        t = r.choice(GEN)
        return ops(f"shli {t}, r1, {3}; sts {self.src()}, [{t} + 4]; lds {r.choice(GEN)}, [{t} + 4]")

    def cond(self) -> List[Stmt]:
        """Compute a condition into a general register; mixes lane-dependent and data-dependent tests."""
        r = self.r
        c = r.choice(GEN)
        k = r.random()
        if k < 0.35:
            return [Op(f"andi {c}, r1, {1 << r.randrange(max(1, self.lanes.bit_length()))}")], c
        if k < 0.55:
            return [Op(f"slti {c}, r1, {r.randint(0, 40)}")], c
        if k < 0.75:
            return [Op(f"andi {c}, {self.src()}, {r.randint(1, 7)}")], c
        if k < 0.85:
            return [Op(f"rdsr {c}, SR_WARP_ID")], c          # uniform within a warp
        return [Op(f"slt {c}, {self.src()}, {self.src()}")], c

    def block(self, depth: int, loop: int, in_loop: bool, uniform_ok: bool) -> List[Stmt]:
        out: List[Stmt] = []
        n = self.r.randint(1, 4)
        for _ in range(n):
            out += self.stmt(depth, loop, in_loop, uniform_ok)
        return out

    def stmt(self, depth: int, loop: int, in_loop: bool, uniform_ok: bool) -> List[Stmt]:
        r = self.r
        self.nstmt += 1
        k = r.random()
        if depth >= 4 or self.nstmt > 60:
            k = r.random() * 0.5
        if k < 0.30:
            return self.alu()
        if k < 0.48:
            return self.mem()
        if k < 0.68:
            pre, c = self.cond()
            th = self.block(depth + 1, loop, in_loop, False)
            el = self.block(depth + 1, loop, in_loop, False) if r.random() < 0.6 else []
            if not th and not el:
                th = self.alu()
            return pre + [If(c, th, el)]
        if k < 0.80 and loop < 2:
            kr, nr = ("r4", "r5") if loop == 0 else ("r6", "r7")
            bound = r.choice([f"andi {nr}, r1, 3", f"andi {nr}, r1, {r.randint(1, 5)}",
                              f"addi {nr}, r0, {r.randint(0, 3)}", f"andi {nr}, {r.choice(GEN)}, 3"])
            init = ops(f"{bound}; addi {kr}, r0, 0")
            body = self.block(depth + 1, loop + 1, True, False)
            if r.random() < 0.5:
                c = r.choice(GEN)
                return init + [While(ops(f"slt {c}, {kr}, {nr}"), c, body + ops(f"addi {kr}, {kr}, 1"))]
            c = r.choice(GEN)
            return init + [DoWhile(body + ops(f"addi {kr}, {kr}, 1; slt {c}, {kr}, {nr}"), c)]
        if k < 0.86 and in_loop:
            pre, c = self.cond()
            return pre + [Break(c)]
        if k < 0.90:
            pre, c = self.cond()
            return pre + [ExitIf(c)]
        if k < 0.92 and depth > 0:
            return [Exit()]
        if k < 0.97 and uniform_ok and self.allow_bar:
            return [Bar()]
        return self.alu()


def random_kernel(seed: int, lanes: int = 8, warps: int = 4, allow_bar: bool = True) -> GenKernel:
    rng = random.Random(seed)
    g = _G(rng, lanes, allow_bar)
    body: List[Stmt] = ops(f"rdsr r1, SR_TID; shli r2, r1, 5; addi r2, r2, {4 * OUT_BASE}; "
                           f"addi r3, r0, {4 * IN_BASE}; addi r8, r1, 1; addi r9, r1, 3; addi r10, r0, 7")
    # top level: blocks separated by optional barriers (barriers only at top level, never diverged)
    for _ in range(rng.randint(2, 4)):
        body += g.block(0, 0, False, False)
        if allow_bar and rng.random() < 0.5:
            body += [Bar()]
            # shared exchange: write own slot, barrier, read neighbour's slot
            body += ops("shli r8, r1, 3; sts r9, [r8 + 0]")
            body += [Bar()]
            body += ops(f"xori r10, r1, 1; shli r10, r10, 3; lds r10, [r10 + 0]; stg r10, [r2 + {4 * (SLOTS - 1)}]")
            body += [Bar()]            # nobody rewrites a slot before every neighbour has read it
    gm = {IN_BASE + i: rng.randint(0, 0xFFFF_FFFF) for i in range(IN_WORDS)}
    wg = rng.choice([lanes * warps, lanes * warps, max(1, lanes * warps - rng.randint(1, lanes)),
                     rng.randint(1, lanes * warps)])
    return GenKernel(body, gm, wg, seed)
