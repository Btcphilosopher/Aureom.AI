"""Build and run the RTL testbench, parse its trace, and compare it with the reference model.

The comparison is *lock-step at instruction granularity*:

1. the RTL run yields the global commit order (warp id per issued instruction);
2. the reference model replays exactly that warp order;
3. then every committed instruction must match (warp, pc, word, execution mask,
   active and live masks, full settled stack, predication window state), every
   memory access must match in global order (warp, lane, space, kind, address,
   data), the final registers / global / shared memory must match, and so must
   the fault record (code, warp, pc, lane, mask, data);
4. the hardware performance counters must equal the values derived from the trace.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from . import isa
from .isa import Config
from .machine import Fault, Launch, Machine, Result

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
RTL_FILES = ["sfd_decode.sv", "sfd_alu.sv", "sfd_simt_stack.sv", "sfd_regfile.sv", "sfd_ram.sv",
             "sfd_lsu.sv", "sfd_core.sv"]
PERF_NAMES = ["cycles", "issued", "lane_slots", "live_slots", "pred_off", "ctrl", "branch", "diverge",
              "push", "pop_r", "pop_x", "sp_sum", "sp_max", "idle", "stall", "lsu_busy", "bar_wait",
              "pred_insn", "mem_lanes", "pop_stall"]


@dataclass
class RCommit:
    cyc: int
    warp: int
    pc: int
    word: int
    exec_mask: int
    active: int
    live: int
    sp: int
    pcount: int
    pmask: int
    stack: Tuple[Tuple[int, int, int], ...]

    def key(self):
        return (self.warp, self.pc, self.word, self.exec_mask, self.live, self.stack, self.pcount,
                self.pmask if self.pcount else 0)


@dataclass
class RtlResult:
    status: str
    cycles: int
    fault: Optional[Fault]
    perf: Dict[str, int]
    regs: List[List[List[int]]]
    gmem: List[int]
    smem: List[int]
    commits: List[RCommit] = field(default_factory=list)
    pops: List[tuple] = field(default_factory=list)       # (cyc, warp, reason, (pc, rpc, mask))
    mem: List[tuple] = field(default_factory=list)        # (cyc, key)
    bars: List[tuple] = field(default_factory=list)       # (cyc, mask)
    log: str = ""

    @property
    def schedule(self) -> List[int]:
        return [c.warp for c in self.commits]


def _build_dir(base: Optional[str]) -> str:
    d = base or os.path.join(ROOT, "build")
    os.makedirs(d, exist_ok=True)
    return d


def build(cfg: Config, defines: Sequence[str] = ("SFD_ASSERT",), build_dir: Optional[str] = None,
          rtl_dir: Optional[str] = None, tag: str = "") -> str:
    """Compile the testbench for ``cfg`` with Icarus Verilog; returns the .vvp path (cached)."""
    rtl_dir = rtl_dir or os.path.join(ROOT, "rtl")
    bd = _build_dir(build_dir)
    name = f"tb_L{cfg.lanes}_W{cfg.warps}_D{cfg.depth}_P{int(cfg.pred_en)}{tag}"
    out = os.path.join(bd, name + ".vvp")
    srcs = [os.path.join(rtl_dir, f) for f in RTL_FILES] + [os.path.join(ROOT, "tb", "tb_sfd_core.sv")]
    if os.path.exists(out) and all(os.path.getmtime(out) >= os.path.getmtime(s) for s in srcs):
        return out
    tmp = f"{out}.{os.getpid()}.tmp"        # concurrent builders never see a half-written file
    cmd = ["iverilog", "-g2012", "-I", rtl_dir, "-o", tmp,
           f"-Ptb_sfd_core.LANES={cfg.lanes}", f"-Ptb_sfd_core.WARPS={cfg.warps}",
           f"-Ptb_sfd_core.DEPTH={cfg.depth}", f"-Ptb_sfd_core.IMEM_WORDS={cfg.imem_words}",
           f"-Ptb_sfd_core.GMEM_WORDS={cfg.gmem_words}", f"-Ptb_sfd_core.SMEM_WORDS={cfg.smem_words}",
           f"-Ptb_sfd_core.PRED_EN={int(cfg.pred_en)}"]
    cmd += [f"-D{d}" for d in defines] + srcs
    p = subprocess.run(cmd, capture_output=True, text=True)
    errs = [l for l in p.stderr.splitlines() if "sorry: constant selects" not in l
            and "cannot be synthesized" not in l and l.strip()]
    if p.returncode != 0:
        raise RuntimeError("iverilog failed:\n" + "\n".join(errs))
    os.replace(tmp, out)
    return out


def _write_mem_hex(path: str, init: Optional[Dict[int, int]]):
    with open(path, "w") as f:
        for a in sorted(init or {}):
            f.write(f"@{a:x} {init[a] & isa.MASK32:08x}\n")


def run(cfg: Config, launch: Launch, workdir: str, vvp: Optional[str] = None, maxcyc: int = 2_000_000,
        wdog: int = 0, trace: bool = True) -> RtlResult:
    os.makedirs(workdir, exist_ok=True)
    vvp = vvp or build(cfg)
    code = list(launch.code)
    cw = launch.code_words if launch.code_words is not None else len(code)
    with open(os.path.join(workdir, "code.hex"), "w") as f:
        for w in code:
            f.write(f"{w & isa.MASK32:08x}\n")
    _write_mem_hex(os.path.join(workdir, "gmem.hex"), launch.gmem)
    _write_mem_hex(os.path.join(workdir, "smem.hex"), launch.smem)
    args = launch.norm_args()
    plus = [f"+code={workdir}/code.hex", f"+code_words={cw}", f"+gmem={workdir}/gmem.hex",
            f"+smem={workdir}/smem.hex", f"+wg_dim={launch.wg_dim}", f"+wg_id={launch.wg_id}",
            f"+grid_dim={launch.grid_dim}", f"+entry={launch.entry_pc}", f"+wdog={wdog}",
            f"+maxcyc={maxcyc}", f"+out={workdir}/final.txt"]
    if launch.shared_bytes is not None:
        plus.append(f"+shared_bytes={launch.shared_bytes}")
    plus += [f"+arg{i}={a:x}" for i, a in enumerate(args)]
    if trace:
        plus.append(f"+trace={workdir}/trace.txt")
    p = subprocess.run(["vvp", "-n", vvp] + plus, capture_output=True, text=True)
    log = p.stdout + p.stderr
    if "SFD-ASSERT" in log or p.returncode != 0 or "FATAL" in log:
        raise AssertionError(f"RTL assertion / simulator failure in {workdir}:\n{log[-3000:]}")
    return parse(cfg, workdir, log, trace)


def parse(cfg: Config, workdir: str, log: str = "", trace: bool = True) -> RtlResult:
    L, W = cfg.lanes, cfg.warps
    regs = [[[0] * 16 for _ in range(L)] for _ in range(W)]
    gmem = [0] * cfg.gmem_words
    smem = [0] * cfg.smem_words
    perf: Dict[str, int] = {}
    status, cycles, fault = "?", 0, None
    with open(os.path.join(workdir, "final.txt")) as f:
        for line in f:
            t = line.split()
            if not t:
                continue
            if t[0] == "STATUS":
                status, cycles = t[1], int(t[2])
            elif t[0] == "FAULT":
                fault = Fault(int(t[1]), int(t[2]), int(t[3]), int(t[4]), int(t[5], 16), int(t[6], 16))
            elif t[0] == "K":
                perf[PERF_NAMES[int(t[1])]] = int(t[2])
            elif t[0] == "R":
                regs[int(t[1])][int(t[2])][int(t[3])] = int(t[4], 16)
            elif t[0] == "G":
                gmem[int(t[1], 16)] = int(t[2], 16)
            elif t[0] == "S":
                smem[int(t[1], 16)] = int(t[2], 16)
    res = RtlResult(status, cycles, fault, perf, regs, gmem, smem, log=log)
    if not trace:
        return res
    with open(os.path.join(workdir, "trace.txt")) as f:
        for line in f:
            t = line.split()
            if not t:
                continue
            k = t[0]
            if k == "C":
                bar = t.index("|")
                st = tuple(tuple((int(a), int(b), int(c, 16))) for a, b, c in (e.split(":") for e in t[bar + 1:]))
                res.commits.append(RCommit(int(t[1]), int(t[2]), int(t[3]), int(t[4], 16), int(t[5], 16),
                                           int(t[6], 16), int(t[7], 16), int(t[8]), int(t[9]), int(t[10], 16), st))
            elif k == "P":
                a, b, c = t[4].split(":")
                res.pops.append((int(t[1]), int(t[2]), t[3], (int(a), int(b), int(c, 16))))
            elif k == "M":
                rd = None if t[7] == "-" else int(t[7], 16)
                wd = None if t[8] == "-" else int(t[8], 16)
                res.mem.append((int(t[1]), (int(t[2]), int(t[3]), t[4], t[5], int(t[6], 16), rd, wd)))
            elif k == "B":
                res.bars.append((int(t[1]), int(t[2], 16)))
    return res


# ----------------------------------------------------------------------------- comparison
def trace_counters(commits: Sequence, lanes: int) -> Dict[str, int]:
    """Counters derivable from the commit stream (for both RTL commits and model commits)."""
    c = dict(issued=0, lane_slots=0, live_slots=0, pred_off=0, ctrl=0, branch=0, pred_insn=0, sp_sum=0)
    for r in commits:
        d = isa.decode(r.word)
        c["issued"] += 1
        c["lane_slots"] += isa.popcount(r.exec_mask)
        c["live_slots"] += isa.popcount(r.live)
        c["pred_off"] += isa.popcount(r.active & ~r.exec_mask)
        c["ctrl"] += d.cls in (isa.JUMP, isa.BRANCH, isa.PRED)
        c["branch"] += d.cls == isa.BRANCH
        c["pred_insn"] += r.pcount > 0
        c["sp_sum"] += len(r.stack)
    return c


def replay_model(cfg: Config, launch: Launch, rtl: RtlResult) -> Result:
    sched = rtl.schedule + ([rtl.fault.warp] if rtl.fault and rtl.fault.code != isa.F_WATCHDOG else [])
    m = Machine(cfg, launch)
    if rtl.fault and rtl.fault.code == isa.F_WATCHDOG:
        return m.run(max_issues=len(rtl.schedule), schedule=sched)
    return m.run(schedule=sched)


def compare(cfg: Config, launch: Launch, rtl: RtlResult, model: Optional[Result] = None,
            check_state_on_fault: bool = False) -> List[str]:
    """Return a list of mismatches (empty = RTL and model agree exactly)."""
    errs: List[str] = []
    try:
        m = model or replay_model(cfg, launch, rtl)
    except RuntimeError as e:          # the RTL issued a warp the reference says cannot issue
        return [f"schedule divergence: {e}"]
    # fault
    if (m.fault is None) != (rtl.fault is None):
        errs.append(f"fault mismatch: model={m.fault} rtl={rtl.fault}")
    elif m.fault is not None:
        if m.fault.code == isa.F_WATCHDOG:
            if rtl.fault.code != isa.F_WATCHDOG:
                errs.append(f"fault mismatch: model={m.fault} rtl={rtl.fault}")
        elif m.fault.key() != rtl.fault.key():
            errs.append(f"fault mismatch: model={m.fault} rtl={rtl.fault}")
    if rtl.status == "timeout":
        errs.append("RTL timed out")
    # commits
    mk = [c.key() for c in m.trace]
    rk = [c.key() for c in rtl.commits]
    if mk != rk:
        n = next((i for i, (a, b) in enumerate(zip(mk, rk)) if a != b), min(len(mk), len(rk)))
        errs.append(f"commit stream differs at #{n} (model {len(mk)}, rtl {len(rk)}): "
                    f"model={mk[n] if n < len(mk) else None} rtl={rk[n] if n < len(rk) else None}")
    # memory accesses (global order)
    mm = [a.key() for a in m.mem_log]
    rm = [k for _, k in rtl.mem]
    if m.fault is not None and len(rm) <= len(mm):
        # After a fault the LSU is aborted: accesses still queued for other warps may be
        # cut short (memory after a fault is unspecified, docs/01 section 11).  What the
        # RTL did perform must still be exactly the reference's prefix.
        mm = mm[:len(rm)]
    if mm != rm:
        n = next((i for i, (a, b) in enumerate(zip(mm, rm)) if a != b), min(len(mm), len(rm)))
        errs.append(f"memory access stream differs at #{n} (model {len(mm)}, rtl {len(rm)}): "
                    f"model={mm[n] if n < len(mm) else None} rtl={rm[n] if n < len(rm) else None}")
    # pops: per warp sequence of popped entries and reasons
    mp = {}
    for c in m.trace:
        for reason, e in c.pops:
            mp.setdefault(c.warp, []).append((reason, tuple(e)))
    rp = {}
    for _, w, reason, e in rtl.pops:
        rp.setdefault(w, []).append((reason, e))
    if mp != rp and (m.fault is None):
        errs.append(f"pop sequence differs: model={mp} rtl={rp}")
    # final state
    if m.fault is None or check_state_on_fault:
        if m.regs != rtl.regs:
            for w in range(cfg.warps):
                for l in range(cfg.lanes):
                    if m.regs[w][l] != rtl.regs[w][l]:
                        errs.append(f"regs differ warp {w} lane {l}: model={m.regs[w][l]} rtl={rtl.regs[w][l]}")
                        break
        if m.gmem != rtl.gmem:
            d = [i for i in range(cfg.gmem_words) if m.gmem[i] != rtl.gmem[i]]
            errs.append(f"gmem differs at {len(d)} words, first {d[0]:#x}: model={m.gmem[d[0]]:#x} rtl={rtl.gmem[d[0]]:#x}")
        if m.smem != rtl.smem:
            d = [i for i in range(cfg.smem_words) if m.smem[i] != rtl.smem[i]]
            errs.append(f"smem differs at {len(d)} words, first {d[0]:#x}")
    # hardware counters vs trace
    if rtl.fault is None:
        tc = trace_counters(rtl.commits, cfg.lanes)
        for k, v in tc.items():
            if rtl.perf.get(k) != v:
                errs.append(f"perf counter {k}: hw={rtl.perf.get(k)} trace={v}")
        div = sum(1 for c in m.trace if c.branch is not None and c.branch.kind == "diverge")
        push = sum(c.branch.needed for c in m.trace if c.branch is not None and c.branch.kind == "diverge")
        if rtl.perf.get("push") != push:
            errs.append(f"perf counter push: hw={rtl.perf.get('push')} model={push}")
        if rtl.perf.get("diverge") != div:
            errs.append(f"perf counter diverge: hw={rtl.perf.get('diverge')} model={div}")
        npr = sum(1 for c in m.trace for p in c.pops if p[0] == "R")
        npx = sum(1 for c in m.trace for p in c.pops if p[0] == "X")
        if rtl.perf.get("pop_r") != npr or rtl.perf.get("pop_x") != npx:
            errs.append(f"perf pops: hw=({rtl.perf.get('pop_r')},{rtl.perf.get('pop_x')}) model=({npr},{npx})")
        if rtl.perf.get("mem_lanes") != len(m.mem_log):
            errs.append(f"perf mem_lanes: hw={rtl.perf.get('mem_lanes')} model={len(m.mem_log)}")
        msp = max([max(m.max_sp)] + [0])
        if rtl.perf.get("sp_max") != msp:
            errs.append(f"perf sp_max: hw={rtl.perf.get('sp_max')} model={msp}")
    return errs


def have_tools() -> bool:
    return shutil.which("iverilog") is not None and shutil.which("vvp") is not None
