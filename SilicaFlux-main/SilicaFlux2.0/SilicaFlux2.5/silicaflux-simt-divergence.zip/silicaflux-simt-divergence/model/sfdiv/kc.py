"""Structured kernel compiler: the producer side of the reconvergence contract.

A kernel is a list of statements:

    Op("addi r3, r3, 1")          straight-line instruction (no control flow)
    If(c, then, els)              then-arm for lanes with c != 0, else-arm for c == 0
    While(pre, c, body)           loop while c != 0 (``pre`` recomputes c each trip)
    DoWhile(body, c)              body; repeat while c != 0
    Break(c=None)                 leave the innermost loop (lanes with c != 0, or all)
    ExitIf(c)                     threads with c != 0 terminate here
    Exit()                        active threads terminate
    Bar()                         workgroup barrier

Lowering (reconvergence operand R chosen structurally, docs/02 section 3):

    If          bz  c, L_else, R    then  bra L_end  L_else: else  L_end:      R = L_end
    If (no else) bz c, L_end, R     then  L_end:
    If (no then) bnz c, L_end, R    else  L_end:
    While       L_top: pre  bz c, L_exit, L_exit  body  bra L_top  L_exit:
    DoWhile     L_top: body  bnz c, L_top, L_exit  L_exit:
    Break c     bnz c, L_exit, L_exit            (unconditional: bra L_exit)
    ExitIf c    bz  c, L_go, L_go  exit  L_go:

    An ``If`` whose arms contain a ``Break`` of the enclosing loop (not inside a
    nested loop) uses R = L_exit of that loop: lanes that break never pass L_end.

After lowering, :func:`sfdiv.cfg.check` verifies the binary independently
(validity and minimality of every R).  Compilation fails if the contract does
not hold, so hardware never sees a kernel that could raise F_RECONV.

If-conversion (``predicate=True``) rewrites every *legal* ``If`` into SFX-PRED
windows; see :func:`convertible` for the legality rules (when predicated
execution is equivalent to branch execution).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Union

from . import asm as asmmod
from . import cfg as cfgmod
from . import isa


# ---------------------------------------------------------------- AST
@dataclass
class Op:
    text: str


@dataclass
class If:
    cond: str
    then: List["Stmt"] = field(default_factory=list)
    els: List["Stmt"] = field(default_factory=list)


@dataclass
class While:
    pre: List["Stmt"]
    cond: str
    body: List["Stmt"]


@dataclass
class DoWhile:
    body: List["Stmt"]
    cond: str


@dataclass
class Break:
    cond: Optional[str] = None


@dataclass
class ExitIf:
    cond: str


@dataclass
class Exit:
    pass


@dataclass
class Bar:
    pass


Stmt = Union[Op, If, While, DoWhile, Break, ExitIf, Exit, Bar]


def ops(text: str) -> List[Op]:
    """Split 'a; b\\n c' into Op statements."""
    out = []
    for part in re.split(r"[;\n]", text):
        part = part.strip()
        if part:
            out.append(Op(part))
    return out


# Registers reserved for the if-converter (predicates + one temporary)
PRED_TMP = 11
PRED_REGS = [(12, 13), (14, 15)]        # (pT, pF) per nesting level
MAX_PRED_DEPTH = len(PRED_REGS)
_CONTROL_MN = {"bra", "j", "bz", "bnz", "exit", "bar", "trap", "pz", "pnz"}
_RESERVED_RE = re.compile(r"\br(1[1-5])\b", re.I)


# ---------------------------------------------------------------- analysis helpers
def contains_break(stmts: Sequence[Stmt]) -> bool:
    """A Break that leaves the *enclosing* loop (does not look inside nested loops)."""
    for s in stmts:
        if isinstance(s, Break):
            return True
        if isinstance(s, If) and (contains_break(s.then) or contains_break(s.els)):
            return True
    return False


def contains_break_if(stmts: Sequence[Stmt]) -> bool:
    for s in stmts:
        if isinstance(s, If) and (contains_break(s.then) or contains_break(s.els)):
            return True
    return False


def static_stack_need(stmts: Sequence[Stmt], lanes: int) -> int:
    """Conservative number of stack entries a statement list may add above its own entry.

    Derivation in docs/02-compiler-contract.md section 5.  Entries that share one
    reconvergence entry have pairwise disjoint, non-empty lane masks, so a loop
    whose body contains break-ifs (which may leave one pending entry per trip)
    contributes at most ``lanes`` entries at its level.
    """
    need = 0
    for s in stmts:
        if isinstance(s, If):
            brk = contains_break(s.then) or contains_break(s.els)
            t, e = static_stack_need(s.then, lanes), static_stack_need(s.els, lanes)
            if brk:
                n = 1 + max(t, e)                       # its level is accounted by the loop
            elif s.then and s.els:
                n = max(2 + e, 1 + t)                   # else (taken) path runs on top of then (fall)
            else:
                n = 1 + (t if s.then else e)
        elif isinstance(s, (While, DoWhile)):
            body = (s.pre + s.body) if isinstance(s, While) else s.body
            lvl = lanes if contains_break_if(body) else 1
            n = lvl + static_stack_need(body, lanes)
        elif isinstance(s, ExitIf):
            n = 1
        else:
            n = 0
        need = max(need, n)
    return need


def convertible(s: If, depth: int = 1) -> Optional[str]:
    """None if the If may be if-converted with equivalent results, else the reason it may not.

    Predicated execution of an If is equivalent to branch execution (same
    per-thread results, same memory effects, same barrier behaviour) when:
      P1 both arms are straight-line code or legally convertible nested Ifs
         (no loop: a loop with a lane-dependent trip count needs a back-edge);
      P2 no arm contains exit, a barrier, a trap or any other control transfer
         (a predicated barrier would change barrier participation; an exit
         inside a window cannot be expressed);
      P3 nesting depth <= MAX_PRED_DEPTH (predicate register budget);
      P4 the arms do not use the converter's registers r11..r15.
    Inactive lanes never execute side effects in either scheme: window
    instructions run under ``active & predicate`` and an empty mask does nothing.
    """
    if depth > MAX_PRED_DEPTH:
        return f"P3: nesting depth {depth} exceeds predicate register budget ({MAX_PRED_DEPTH})"
    for arm in (s.then, s.els):
        for x in arm:
            if isinstance(x, Op):
                mn = x.text.split()[0].lower()
                if mn in _CONTROL_MN:
                    return f"P2: control instruction '{x.text}' inside an arm"
                if _RESERVED_RE.search(x.text):
                    return f"P4: arm uses reserved register in '{x.text}'"
            elif isinstance(x, If):
                r = convertible(x, depth + 1)
                if r:
                    return r
            elif isinstance(x, (While, DoWhile)):
                return "P1: loop inside an arm (lane-dependent trip count needs a back-edge branch)"
            elif isinstance(x, (Break,)):
                return "P2: break inside an arm"
            elif isinstance(x, (Exit, ExitIf)):
                return "P2: thread exit inside an arm"
            elif isinstance(x, Bar):
                return "P2: barrier inside an arm (would change barrier behaviour)"
    if _RESERVED_RE.search(s.cond):
        return "P4: condition uses a reserved register"
    return None


# ---------------------------------------------------------------- compiler
@dataclass
class Conversion:
    label: str
    converted: bool
    reason: Optional[str]


@dataclass
class CompiledKernel:
    name: str
    asm: str
    program: asmmod.Program
    contract: cfgmod.ContractReport
    static_need: int                     # entries above the bottom entry (branch mode)
    conversions: List[Conversion]
    predicated: bool

    @property
    def words(self) -> List[int]:
        return self.program.words

    def static_bound(self, lanes: int) -> int:
        return min(1 + self.static_need, 2 * lanes - 1)


class Compiler:
    def __init__(self, predicate: bool = False):
        self.predicate = predicate
        self.lines: List[str] = []
        self.n = 0
        self.conversions: List[Conversion] = []

    def lab(self, base: str) -> str:
        self.n += 1
        return f"{base}_{self.n}"

    def emit(self, s: str):
        self.lines.append("    " + s)

    def label(self, l: str):
        self.lines.append(f"{l}:")

    # ------------------------------------------------------------------
    def stmts(self, ss: Sequence[Stmt], loop_exit: Optional[str]):
        for s in ss:
            self.stmt(s, loop_exit)

    def stmt(self, s: Stmt, loop_exit: Optional[str]):
        if isinstance(s, Op):
            mn = s.text.split()[0].lower()
            if mn in _CONTROL_MN:
                raise ValueError(f"control instruction in Op: '{s.text}' (use the structured statements)")
            self.emit(s.text)
        elif isinstance(s, If):
            self.if_(s, loop_exit)
        elif isinstance(s, While):
            top, ex = self.lab("while"), self.lab("wend")
            self.label(top)
            self.stmts(s.pre, ex)
            self.emit(f"bz {s.cond}, {ex}, {ex}")
            self.stmts(s.body, ex)
            self.emit(f"bra {top}")
            self.label(ex)
        elif isinstance(s, DoWhile):
            top, ex = self.lab("do"), self.lab("dend")
            self.label(top)
            self.stmts(s.body, ex)
            self.emit(f"bnz {s.cond}, {top}, {ex}")
            self.label(ex)
        elif isinstance(s, Break):
            if loop_exit is None:
                raise ValueError("break outside a loop")
            if s.cond is None:
                self.emit(f"bra {loop_exit}")
            else:
                self.emit(f"bnz {s.cond}, {loop_exit}, {loop_exit}")
        elif isinstance(s, ExitIf):
            go = self.lab("go")
            self.emit(f"bz {s.cond}, {go}, {go}")
            self.emit("exit")
            self.label(go)
        elif isinstance(s, Exit):
            self.emit("exit")
        elif isinstance(s, Bar):
            self.emit("bar")
        else:
            raise TypeError(s)

    def if_(self, s: If, loop_exit: Optional[str]):
        tag = f"if_{self.n + 1}"
        if self.predicate:
            why = convertible(s)
            if why is None:
                self.conversions.append(Conversion(tag, True, None))
                self.n += 1
                self.predicated_if(s)
                return
            self.conversions.append(Conversion(tag, False, why))
        brk = contains_break(s.then) or contains_break(s.els)
        end = self.lab("endif")
        R = loop_exit if brk else end
        if s.then and s.els:
            el = self.lab("else")
            self.emit(f"bz {s.cond}, {el}, {R}")
            self.stmts(s.then, loop_exit)
            self.emit(f"bra {end}")
            self.label(el)
            self.stmts(s.els, loop_exit)
        elif s.then:
            self.emit(f"bz {s.cond}, {end}, {R}")
            self.stmts(s.then, loop_exit)
        elif s.els:
            self.emit(f"bnz {s.cond}, {end}, {R}")
            self.stmts(s.els, loop_exit)
        self.label(end)

    # ------------------------------------------------------------------ if-conversion
    def predicated_if(self, s: If):
        """Emit the If as predication windows.  Arms run in the same order as the
        branch lowering executes them (else = taken path first), so even the order
        of memory accesses between the two arms is identical."""
        segs: List[tuple] = []          # ("raw", text) | ("win", preg, [texts], polarity)
        flat = not any(isinstance(x, If) for x in s.then + s.els)
        creg = _reg_num(s.cond)
        keeps = lambda arm: all(_writes(x.text) != creg for x in arm)
        if flat and creg is not None and keeps(s.els) and (len(s.then) <= 31 or keeps(s.then)):
            # Fast form: test the condition register directly (no predicate set-up).
            # Valid because no window that re-reads the condition runs after an
            # instruction that changes it (else runs first; a split then-arm must
            # not write it either).
            if s.els:
                segs.append(("win", creg, [x.text for x in s.els], "pz"))
            if s.then:
                segs.append(("win", creg, [x.text for x in s.then], "pnz"))
        else:
            pT, pF = PRED_REGS[0]
            segs.append(("raw", f"sltu r{pT}, r0, {s.cond}"))
            segs.append(("raw", f"xori r{pF}, r{pT}, 1"))
            self._arm_segs(s.els, pF, 1, segs)
            self._arm_segs(s.then, pT, 1, segs)
        for seg in segs:
            if seg[0] == "raw":
                self.emit(seg[1])
            else:
                _, preg, texts, pol = seg
                for i in range(0, len(texts), 31):
                    chunk = texts[i:i + 31]
                    self.emit(f"{pol} r{preg}, {len(chunk)}")
                    for t in chunk:
                        self.emit(t)

    def _arm_segs(self, arm: Sequence[Stmt], preg: int, level: int, segs: list):
        cur: List[str] = []
        for x in arm:
            if isinstance(x, Op):
                cur.append(x.text)
            else:  # nested If (legality already checked)
                if cur:
                    segs.append(("win", preg, cur, "pnz"))
                    cur = []
                qT, qF = PRED_REGS[level]
                segs.append(("raw", f"sltu r{PRED_TMP}, r0, {x.cond}"))
                segs.append(("raw", f"and r{qT}, r{preg}, r{PRED_TMP}"))
                segs.append(("raw", f"xori r{PRED_TMP}, r{PRED_TMP}, 1"))
                segs.append(("raw", f"and r{qF}, r{preg}, r{PRED_TMP}"))
                self._arm_segs(x.els, qF, level + 1, segs)
                self._arm_segs(x.then, qT, level + 1, segs)
        if cur:
            segs.append(("win", preg, cur, "pnz"))


def _reg_num(name: str) -> Optional[int]:
    m = re.fullmatch(r"r(\d+)", name.strip(), re.I)
    return int(m.group(1)) if m else None


def _writes(text: str) -> Optional[int]:
    """Destination register written by a straight-line instruction (None if it writes none)."""
    w = asmmod.assemble(text, "op").words[0]
    d = isa.decode(w)
    if d.illegal or d.cls not in (isa.ALU, isa.SREAD, isa.LDG, isa.LDS, isa.ATOM):
        return None
    return d.rd


def compile_kernel(name: str, body: Sequence[Stmt], predicate: bool = False, lanes: int = 8,
                   check: bool = True, refine: bool = True) -> CompiledKernel:
    c = Compiler(predicate)
    c.stmts(body, None)
    if not (body and isinstance(body[-1], Exit)):
        c.emit("exit")
    text = f"; kernel {name} ({'predicated' if predicate else 'branch'} lowering)\n" + "\n".join(c.lines) + "\n"
    prog = asmmod.assemble(text, name)
    rep = cfgmod.check(prog.words)
    if refine and rep.ok and rep.warnings:
        # The structural rule is minimal except where an arm always terminates (e.g. starts
        # with `exit`): then the join can be the first instruction of the surviving path.
        # Lower such operands to the checker's minimal valid point (same code layout).
        lines = text.splitlines()
        for b in rep.branches:
            if b.valid and b.minimal is not None and b.minimal < b.reconv:
                i = prog.src_line[b.pc] - 1
                lines[i] = re.sub(r",\s*[^,]+$", f", {b.minimal}", lines[i]) + "    ; reconv lowered to the minimal valid point"
        text = "\n".join(lines) + "\n"
        prog = asmmod.assemble(text, name)
        rep = cfgmod.check(prog.words)
    if check and not rep.ok:
        raise ValueError(f"kernel {name}: reconvergence contract violated\n{rep.summary()}\n{prog.listing()}")
    need = static_stack_need(body, lanes) if not predicate else static_stack_need(_strip_converted(body, c), lanes)
    return CompiledKernel(name, text, prog, rep, need, c.conversions, predicate)


def _strip_converted(body, c: Compiler):
    """Static need of a predicated kernel: converted Ifs add no stack entries."""
    out = []
    for s in body:
        if isinstance(s, If):
            if convertible(s) is None:
                continue
            out.append(If(s.cond, _strip_converted(s.then, c), _strip_converted(s.els, c)))
        elif isinstance(s, While):
            out.append(While(_strip_converted(s.pre, c), s.cond, _strip_converted(s.body, c)))
        elif isinstance(s, DoWhile):
            out.append(DoWhile(_strip_converted(s.body, c), s.cond))
        else:
            out.append(s)
    return out
