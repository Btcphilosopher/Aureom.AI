"""Instruction-level SIMT reference model of the SilicaFlux divergence core.

One workgroup of up to ``warps * lanes`` threads runs on one core.  Each step
issues one complete warp instruction (zero-latency memory) and then fully
resolves that warp's reconvergence stack.  Scheduling is the SF-G1 reference
loose round-robin, or a replayed schedule (the warp order of an RTL run), which
makes even racy programs comparable cycle-for-instruction with the hardware.

Normative behaviour: docs/01-reconvergence-spec.md.  Every architectural rule
lives in ``_issue``; there is no other place where state changes.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence

from . import isa
from .isa import Config, MASK32, RPC_NONE, popcount
from .simt import ReconvStack


@dataclass
class Launch:
    code: Sequence[int]
    wg_dim: int
    args: Sequence[int] = (0,) * 8
    wg_id: int = 0
    grid_dim: int = 1
    shared_bytes: Optional[int] = None
    entry_pc: int = 0
    gmem: Optional[Dict[int, int]] = None     # word index -> value; others zero
    smem: Optional[Dict[int, int]] = None
    code_words: Optional[int] = None

    def norm_args(self) -> List[int]:
        a = [x & MASK32 for x in self.args]
        return (a + [0] * 8)[:8]


@dataclass
class Fault:
    code: int
    warp: int
    pc: int
    lane: int
    mask: int
    data: int

    @property
    def name(self) -> str:
        return isa.FAULT_NAMES.get(self.code, str(self.code))

    def key(self):
        return (self.code, self.warp, self.pc, self.lane, self.mask, self.data)

    def __str__(self):
        return (f"{self.name} warp={self.warp} pc={self.pc} lane={self.lane} "
                f"mask=0x{self.mask:x} data=0x{self.data:x}")


@dataclass
class MemAccess:
    warp: int
    lane: int
    space: str        # 'G' global, 'S' shared
    kind: str         # 'R' load, 'W' store, 'A' atomic add
    addr: int         # word address
    rdata: Optional[int]
    wdata: Optional[int]

    def key(self):
        return (self.warp, self.lane, self.space, self.kind, self.addr, self.rdata, self.wdata)


@dataclass
class Commit:
    """One issued warp instruction.  Pre-issue state is the settled state the RTL also reports."""
    seq: int
    warp: int
    pc: int
    word: int
    exec_mask: int
    active: int
    live: int
    stack: tuple                  # settled stack before the instruction, bottom..top
    pcount: int                   # predication window instructions remaining (before)
    pmask: int
    cls: int
    branch: Optional[object] = None   # BranchOutcome for bz/bnz
    pred_set: Optional[tuple] = None  # (pmask, n) for pz/pnz
    live_after: int = 0
    pops: List[tuple] = field(default_factory=list)  # (reason, entry) popped after this instruction
    mem: List[MemAccess] = field(default_factory=list)
    bar_release: int = 0          # mask of warps released after this instruction

    def key(self):
        return (self.warp, self.pc, self.word, self.exec_mask, self.live, self.stack, self.pcount,
                self.pmask if self.pcount else 0)

    @property
    def sp(self) -> int:
        return len(self.stack)


@dataclass
class Result:
    cfg: Config
    fault: Optional[Fault]
    done: bool
    issued: int
    regs: List[List[List[int]]]
    gmem: List[int]
    smem: List[int]
    trace: List[Commit]
    mem_log: List[MemAccess]
    schedule: List[int]
    max_sp: List[int]
    stacks: List[tuple] = field(default_factory=list)   # per warp: (entries, live) at the end / at the fault


class _Fault(Exception):
    def __init__(self, code, data, lane=None):
        self.code, self.data, self.lane = code, data & MASK32, lane


class Warp:
    def __init__(self, wid: int, cfg: Config):
        self.id = wid
        self.regs = [[0] * isa.NREGS for _ in range(cfg.lanes)]
        self.stack = ReconvStack(cfg.depth)
        self.bar_wait = False
        self.pcount = 0
        self.pmask = 0

    @property
    def done(self) -> bool:
        return self.stack.empty


class Machine:
    def __init__(self, cfg: Config, launch: Launch, trace: bool = True):
        self.cfg = cfg
        self.L = launch
        self.trace_on = trace
        L, W = cfg.lanes, cfg.warps
        code = list(launch.code)
        self.code_words = launch.code_words if launch.code_words is not None else len(code)
        if self.code_words > cfg.imem_words:
            raise ValueError("kernel larger than instruction memory")
        self.imem = (code + [0] * cfg.imem_words)[:cfg.imem_words]
        if not 1 <= launch.wg_dim <= L * W:
            raise ValueError(f"wg_dim {launch.wg_dim} outside 1..{L * W}")
        self.shared_bytes = launch.shared_bytes if launch.shared_bytes is not None else cfg.smem_words * 4
        assert self.shared_bytes % 4 == 0 and self.shared_bytes <= cfg.smem_words * 4
        self.args = launch.norm_args()
        self.gmem = [0] * cfg.gmem_words
        for a, v in (launch.gmem or {}).items():
            self.gmem[a] = v & MASK32
        self.smem = [0] * cfg.smem_words
        for a, v in (launch.smem or {}).items():
            self.smem[a] = v & MASK32
        self.warps = [Warp(w, cfg) for w in range(W)]
        for w in self.warps:
            live = 0
            for l in range(L):
                if w.id * L + l < launch.wg_dim:
                    live |= 1 << l
            w.stack.init(launch.entry_pc, live)
        self.last = W - 1
        self.seq = 0
        self.trace: List[Commit] = []
        self.mem_log: List[MemAccess] = []
        self.schedule: List[int] = []
        self.fault: Optional[Fault] = None

    # ------------------------------------------------------------ scheduling
    def eligible(self, w: Warp) -> bool:
        return not w.done and not w.bar_wait and w.stack.settled

    def pick(self) -> Optional[Warp]:
        W = self.cfg.warps
        for k in range(1, W + 1):
            w = self.warps[(self.last + k) % W]
            if self.eligible(w):
                return w
        return None

    @property
    def all_done(self) -> bool:
        return all(w.done for w in self.warps)

    def run(self, max_issues: int = 2_000_000, schedule: Optional[Iterable[int]] = None) -> Result:
        it = iter(schedule) if schedule is not None else None
        while not self.all_done and self.fault is None:
            if self.seq >= max_issues:
                self.fault = Fault(isa.F_WATCHDOG, 0xFF, 0, 0, 0, self.seq)
                break
            if it is not None:
                try:
                    wid = next(it)
                except StopIteration:
                    raise RuntimeError("replay schedule ended before the kernel finished")
                w = self.warps[wid]
                if not self.eligible(w):
                    raise RuntimeError(f"replay schedule issues warp {wid} at step {self.seq} but it is not eligible")
            else:
                w = self.pick()
                assert w is not None, "no eligible warp (impossible: barrier always releases)"
            self.last = w.id
            self.step(w)
        return Result(self.cfg, self.fault, self.all_done and self.fault is None, self.seq,
                      [[list(r) for r in w.regs] for w in self.warps], list(self.gmem), list(self.smem),
                      self.trace, self.mem_log, self.schedule, [w.stack.max_sp for w in self.warps],
                      [(tuple(w.stack.snapshot()), w.stack.live) for w in self.warps])

    # -------------------------------------------------------------- helpers
    def _sr(self, idx: int, w: Warp, lane: int) -> int:
        L = self.cfg.lanes
        tid = w.id * L + lane
        v = {
            0: lane, 1: w.id, 2: tid, 3: self.L.wg_id, 4: self.L.wg_dim, 5: self.L.grid_dim,
            6: self.L.wg_id * self.L.wg_dim + tid, 7: L, 8: self.shared_bytes,
        }.get(idx)
        if v is None:
            v = self.args[idx - 16]
        return v & MASK32

    def step(self, w: Warp) -> None:
        st = w.stack
        rec = Commit(self.seq, w.id, st.pc, 0, 0, st.active, st.live, tuple(st.snapshot()),
                     w.pcount, w.pmask, -1)
        try:
            self._issue(w, rec)
        except _Fault as f:
            act = st.active
            lane = f.lane if f.lane is not None else ((act & -act).bit_length() - 1 if act else 0)
            self.fault = Fault(f.code, w.id, rec.pc, lane, act, f.data)
            return
        rec.live_after = st.live
        rec.pops = st.resolve()
        self.seq += 1
        self.schedule.append(w.id)
        # barrier release: all warps that are not done are waiting
        waiting = [x for x in self.warps if x.bar_wait]
        if waiting and all(x.bar_wait or x.done for x in self.warps):
            for x in waiting:
                x.bar_wait = False
                rec.bar_release |= 1 << x.id
        if self.trace_on:
            self.trace.append(rec)

    def _issue(self, w: Warp, rec: Commit) -> None:
        cfg = self.cfg
        st = w.stack
        pc, rpc = st.pc, st.rpc
        active = st.active
        # ---- fetch-time checks (precise, in this order)
        if pc >= self.code_words:
            raise _Fault(isa.F_PC_RANGE, pc)
        if rpc != RPC_NONE and pc > rpc:
            raise _Fault(isa.F_RECONV, rpc)
        word = self.imem[pc]
        rec.word = word
        d = isa.decode(word, cfg.pred_en)
        if d.illegal:
            raise _Fault(isa.F_ILLEGAL_INSN, word)
        cls = d.cls
        rec.cls = cls
        in_window = w.pcount > 0
        if in_window and cls in isa.WINDOW_FORBIDDEN:
            raise _Fault(isa.F_PRED_WINDOW, word)
        ex = active & w.pmask if in_window else active
        rec.exec_mask = ex
        regs = w.regs
        lanes = list(isa.lanes_of(ex))

        def rv(l, r):
            return regs[l][r]

        def wb(l, r, v):
            if r != 0:
                regs[l][r] = v & MASK32

        if cls in (isa.NOP, isa.FENCE):
            st.seq()
        elif cls == isa.ALU:
            o = d.op
            for l in lanes:
                a = rv(l, d.rs1)
                b = rv(l, d.rs2) if o.fmt == "R" else d.imm
                wb(l, d.rd, isa.alu(o.alu, a, b))
            st.seq()
        elif cls == isa.SREAD:
            for l in lanes:
                wb(l, d.rd, self._sr(d.imm, w, l))
            st.seq()
        elif cls in isa.MEM_CLASSES:
            self._mem(w, d, cls, lanes, rec)
            st.seq()
        elif cls == isa.JUMP:
            t = pc + d.imm
            if not 0 <= t < self.code_words:
                raise _Fault(isa.F_PC_RANGE, t)
            st.jump(t)
        elif cls == isa.BRANCH:
            t, r = pc + d.imm, pc + d.imm2
            if not 0 <= t < self.code_words:
                raise _Fault(isa.F_PC_RANGE, t)
            if not 0 <= r < self.code_words:
                raise _Fault(isa.F_PC_RANGE, r)
            bz = d.op.name == "bz"
            cond = 0
            for l in isa.lanes_of(active):
                v = rv(l, d.rs1)
                if (v == 0) == bz:
                    cond |= 1 << l
            plan = st.plan_branch(cond, t, r)
            if plan.overflow:
                raise _Fault(isa.F_STACK_OVERFLOW, st.sp)
            rec.branch = st.branch(cond, t, r)
        elif cls == isa.EXIT:
            st.exit(active)
        elif cls == isa.BAR:
            if active != st.live:
                raise _Fault(isa.F_BAR_DIVERGENT, st.live)
            st.seq()
            w.bar_wait = True
        elif cls == isa.TRAP:
            raise _Fault(isa.F_TRAP, d.imm)
        elif cls == isa.PRED:
            n = d.imm
            if rpc != RPC_NONE and pc + n >= rpc:
                raise _Fault(isa.F_PRED_WINDOW, word)
            want_zero = d.op.name == "pz"
            pm = 0
            for l in lanes:
                if (rv(l, d.rs1) == 0) == want_zero:
                    pm |= 1 << l
            st.seq()
            rec.pred_set = (pm, n)
            w.pmask, w.pcount = pm, n
            return                      # the pz/pnz itself is never inside a window
        else:  # pragma: no cover
            raise AssertionError(cls)
        if in_window:
            w.pcount -= 1

    def _mem(self, w: Warp, d: isa.Decoded, cls: int, lanes: List[int], rec: Commit) -> None:
        regs = w.regs
        glob = cls in (isa.LDG, isa.STG, isa.ATOM)
        limit = self.cfg.gmem_bytes if glob else self.shared_bytes
        f_align = isa.F_GMEM_ALIGN if glob else isa.F_SMEM_ALIGN
        f_range = isa.F_GMEM_RANGE if glob else isa.F_SMEM_RANGE
        imm = 0 if cls == isa.ATOM else d.imm
        addrs = {}
        for l in lanes:                                  # check every lane first: precise faults
            a = (regs[l][d.rs1] + imm) & MASK32
            if a & 3:
                raise _Fault(f_align, a, l)
            if a >= limit:
                raise _Fault(f_range, a, l)
            addrs[l] = a >> 2
        mem = self.gmem if glob else self.smem
        sp = "G" if glob else "S"
        for l in lanes:                                  # then perform, ascending lane order
            a = addrs[l]
            if cls in (isa.LDG, isa.LDS):
                v = mem[a]
                if d.rd:
                    regs[l][d.rd] = v
                acc = MemAccess(w.id, l, sp, "R", a, v, None)
            elif cls in (isa.STG, isa.STS):
                v = regs[l][d.rs2]
                mem[a] = v
                acc = MemAccess(w.id, l, sp, "W", a, None, v)
            else:
                old = mem[a]
                new = (old + regs[l][d.rs2]) & MASK32
                mem[a] = new
                if d.rd:
                    regs[l][d.rd] = old
                acc = MemAccess(w.id, l, sp, "A", a, old, new)
            rec.mem.append(acc)
            self.mem_log.append(acc)


def run(cfg: Config, launch: Launch, **kw) -> Result:
    return Machine(cfg, launch).run(**kw)
