"""SilicaFlux SIMT divergence: reference semantics, compiler contract, workloads and evaluation."""
__version__ = "1.0.0"
