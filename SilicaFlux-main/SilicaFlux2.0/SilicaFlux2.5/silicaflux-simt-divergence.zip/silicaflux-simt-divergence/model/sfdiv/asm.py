"""Two-pass assembler for the SF-G1 assembly language (+ SFX-PRED ``pz``/``pnz``).

Syntax follows SF-G1 docs/10-assembler.md:

    ; comment          // comment
    label:  add r1, r2, r3
    .equ N, 4*8
    .reg acc, r9
    .word 0x12345678, label
    bz  r3, target, reconv      ; branch operands are absolute instruction indices / labels
    pnz r3, 4                   ; predication window: next 4 instructions run in lanes with r3 != 0

Pseudo-instructions: li, la, mov, neg, not, sgt, sgtu, j.

The assembler enforces the *static* part of the reconvergence contract
(docs/02-compiler-contract.md): ``reconv`` must lie after the branch and fit the
11-bit unsigned offset (so ``roff >= 1``); a ``target`` beyond ``reconv`` is a
warning (the branch would fault with F_RECONV if it diverged).  The CFG-level
part of the contract (reconv is a valid, minimal reconvergence point) is checked
by :mod:`sfdiv.cfg`.
"""
from __future__ import annotations

import ast
import operator
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from . import isa


class AsmError(Exception):
    pass


@dataclass
class Program:
    words: List[int]
    symbols: Dict[str, int]
    src_line: List[int]               # source line number per word
    src_text: List[str]               # source text per word
    warnings: List[str] = field(default_factory=list)
    name: str = "kernel"
    source: str = ""

    def labels_at(self, pc: int) -> List[str]:
        return [k for k, v in self.symbols.items() if v == pc and not k.startswith("_")]

    def listing(self) -> str:
        out = []
        for i, w in enumerate(self.words):
            labs = self.labels_at(i)
            lab = (",".join(labs) + ":") if labs else ""
            out.append(f"{i:4d}  {w:08x}  {lab:<16s} {isa.disasm(w, i)}")
        return "\n".join(out)

    def hex(self) -> str:
        return "".join(f"{w:08x}\n" for w in self.words)


_BINOPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.FloorDiv: operator.floordiv, ast.Div: operator.floordiv, ast.Mod: operator.mod,
    ast.LShift: operator.lshift, ast.RShift: operator.rshift, ast.BitAnd: operator.and_,
    ast.BitOr: operator.or_, ast.BitXor: operator.xor,
}


class _Unknown(Exception):
    pass


_IDENT_RE = re.compile(r"(?<![\w.])([A-Za-z_.][\w.]*)")


def _eval(expr: str, syms: Dict[str, int], strict: bool) -> int:
    e = re.sub(r"%hi\(", "__hi(", expr.strip())
    e = re.sub(r"%lo\(", "__lo(", e)
    # Labels may be Python keywords ("else") or contain dots: map every identifier
    # to a placeholder before handing the expression to the Python parser.
    names: Dict[str, str] = {}

    def sub(m):
        s = m.group(1)
        if s in ("__hi", "__lo"):
            return s
        k = names.setdefault(s, f"_v{len(names)}")
        return k
    e = _IDENT_RE.sub(sub, e)
    back = {v: k for k, v in names.items()}
    try:
        tree = ast.parse(e, mode="eval")
    except SyntaxError:
        raise AsmError(f"bad expression '{expr}'")

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, int) and not isinstance(n.value, bool):
            return n.value
        if isinstance(n, ast.Name):
            name = back.get(n.id, n.id)
            if name in syms:
                return syms[name]
            if strict:
                raise AsmError(f"undefined symbol '{name}'")
            raise _Unknown(name)
        if isinstance(n, ast.BinOp) and type(n.op) in _BINOPS:
            return _BINOPS[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.UnaryOp):
            v = ev(n.operand)
            if isinstance(n.op, ast.USub):
                return -v
            if isinstance(n.op, ast.UAdd):
                return v
            if isinstance(n.op, ast.Invert):
                return ~v
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and len(n.args) == 1:
            v = ev(n.args[0])
            if n.func.id == "__hi":
                return (v & isa.MASK32) >> 10
            if n.func.id == "__lo":
                return v & 0x3FF
        raise AsmError(f"unsupported expression '{expr}'")

    return ev(tree)


_REG_RE = re.compile(r"^(?:r(\d+)|zero)$", re.I)
_MEM_RE = re.compile(r"^\[\s*([A-Za-z_]\w*)\s*(?:([+-])\s*(.+))?\]$")
_LABEL_RE = re.compile(r"^([A-Za-z_.][\w.]*)\s*:(.*)$")


def _split_ops(s: str) -> List[str]:
    out, depth, cur = [], 0, ""
    for ch in s:
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        if ch == "," and depth == 0:
            out.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def _li_one(v: int) -> bool:
    v32 = v & isa.MASK32
    return -(1 << 17) <= isa.s32(v32) < (1 << 17) or (v32 & 0x3FF) == 0


@dataclass
class _Item:
    line: int
    pc: int
    text: str
    mn: str
    ops: List[str]
    size: int


class Assembler:
    def __init__(self, pred_en: bool = True):
        self.pred_en = pred_en

    def assemble(self, text: str, name: str = "kernel", predefined: Optional[Dict[str, int]] = None) -> Program:
        errors: List[str] = []
        warnings: List[str] = []
        syms: Dict[str, int] = dict(isa.SR)
        if predefined:
            syms.update(predefined)
        regs: Dict[str, int] = {}
        items: List[_Item] = []
        pc = 0
        # ---------------- pass 1: layout ----------------
        for ln, raw in enumerate(text.splitlines(), 1):
            s = re.split(r";|//", raw, maxsplit=1)[0].strip()
            while True:
                m = _LABEL_RE.match(s)
                if not m:
                    break
                lab = m.group(1)
                if lab in syms:
                    errors.append(f"{name}:{ln}: error: duplicate symbol '{lab}'")
                syms[lab] = pc
                s = m.group(2).strip()
            if not s:
                continue
            parts = s.split(None, 1)
            mn = parts[0].lower()
            ops = _split_ops(parts[1]) if len(parts) > 1 else []
            try:
                if mn == ".equ":
                    if len(ops) != 2:
                        raise AsmError(".equ needs name, value")
                    if ops[0] in syms:
                        raise AsmError(f"duplicate symbol '{ops[0]}'")
                    syms[ops[0]] = _eval(ops[1], syms, True)
                    continue
                if mn == ".reg":
                    if len(ops) != 2:
                        raise AsmError(".reg needs alias, register")
                    regs[ops[0]] = self._reg(ops[1], regs)
                    continue
                if mn == ".word":
                    for o in ops:
                        items.append(_Item(ln, pc, s, ".word1", [o], 1))
                        pc += 1
                    continue
                size = self._size(mn, ops, syms)
                items.append(_Item(ln, pc, s, mn, ops, size))
                pc += size
            except AsmError as e:
                errors.append(f"{name}:{ln}: error: {e}")
        # ---------------- pass 2: encode ----------------
        words: List[int] = []
        src_line: List[int] = []
        src_text: List[str] = []
        for it in items:
            try:
                enc = self._encode(it, syms, regs, warnings, f"{name}:{it.line}")
                assert len(enc) == it.size, (it, enc)
            except (AsmError, ValueError) as e:
                errors.append(f"{name}:{it.line}: error: {e}")
                enc = [0] * it.size
            for w in enc:
                words.append(w & isa.MASK32)
                src_line.append(it.line)
                src_text.append(it.text)
        if errors:
            raise AsmError("\n".join(errors))
        user_syms = {k: v for k, v in syms.items() if k not in isa.SR}
        return Program(words, user_syms, src_line, src_text, warnings, name, text)

    # ------------------------------------------------------------------
    def _reg(self, s: str, regs: Dict[str, int]) -> int:
        s = s.strip()
        if s in regs:
            return regs[s]
        m = _REG_RE.match(s)
        if not m:
            raise AsmError(f"unknown register '{s}'")
        r = int(m.group(1)) if m.group(1) is not None else 0
        if r >= isa.NREGS:
            raise AsmError(f"unknown register '{s}'")
        return r

    def _mem(self, s: str, syms, regs) -> Tuple[int, int]:
        m = _MEM_RE.match(s.strip())
        if not m:
            raise AsmError(f"bad memory operand '{s}'")
        base = self._reg(m.group(1), regs)
        off = 0
        if m.group(3):
            off = _eval(m.group(3), syms, True)
            if m.group(2) == "-":
                off = -off
        return base, off

    def _size(self, mn: str, ops: List[str], syms) -> int:
        if mn in ("li", "la"):
            if len(ops) != 2:
                raise AsmError(f"{mn} needs 2 operands")
            try:
                v = _eval(ops[1], syms, False)
            except _Unknown:
                return 2              # forward reference: always two words
            return 1 if _li_one(v) else 2
        if mn in ("mov", "neg", "not", "sgt", "sgtu", "j") or mn in isa.OPS:
            if mn in isa.OPS and isa.OPS[mn].cls == isa.PRED and not self.pred_en:
                raise AsmError(f"'{mn}' needs the SFX-PRED extension")
            return 1
        raise AsmError(f"unknown mnemonic '{mn}'")

    @staticmethod
    def _nops(mn, ops, n):
        if len(ops) != n:
            raise AsmError(f"'{mn}' expects {n} operand(s), got {len(ops)}")

    def _encode(self, it: _Item, syms, regs, warnings, where) -> List[int]:
        mn, ops, pc = it.mn, it.ops, it.pc
        R = lambda s: self._reg(s, regs)
        E = lambda s: _eval(s, syms, True)
        if mn == ".word1":
            return [E(ops[0]) & isa.MASK32]
        if mn in ("li", "la"):
            self._nops(mn, ops, 2)
            rd, v = R(ops[0]), E(ops[1]) & isa.MASK32
            sv = isa.s32(v)
            if -(1 << 17) <= sv < (1 << 17):
                out = [isa.encode("addi", rd=rd, rs1=0, imm=sv)]
            elif (v & 0x3FF) == 0:
                out = [isa.encode("lui", rd=rd, imm=v >> 10)]
            else:
                out = [isa.encode("lui", rd=rd, imm=v >> 10), isa.encode("ori", rd=rd, rs1=rd, imm=v & 0x3FF)]
            while len(out) < it.size:
                out.append(isa.encode("nop"))
            return out
        if mn == "mov":
            self._nops(mn, ops, 2)
            return [isa.encode("addi", rd=R(ops[0]), rs1=R(ops[1]), imm=0)]
        if mn == "neg":
            self._nops(mn, ops, 2)
            return [isa.encode("sub", rd=R(ops[0]), rs1=0, rs2=R(ops[1]))]
        if mn == "not":
            self._nops(mn, ops, 2)
            return [isa.encode("xori", rd=R(ops[0]), rs1=R(ops[1]), imm=-1)]
        if mn in ("sgt", "sgtu"):
            self._nops(mn, ops, 3)
            return [isa.encode("slt" if mn == "sgt" else "sltu", rd=R(ops[0]), rs1=R(ops[2]), rs2=R(ops[1]))]
        if mn == "j":
            mn = "bra"
        o = isa.OPS[mn]
        f = o.fmt
        if f == "Z":
            self._nops(mn, ops, 0)
            return [isa.encode(mn)]
        if f == "T":
            self._nops(mn, ops, 1)
            return [isa.encode(mn, imm=E(ops[0]))]
        if f == "R":
            self._nops(mn, ops, 3)
            if o.cls == isa.ATOM:
                base, off = self._mem(ops[1], syms, regs)
                if off != 0:
                    raise AsmError("atomadd takes [rN] without offset")
                return [isa.encode(mn, rd=R(ops[0]), rs1=base, rs2=R(ops[2]))]
            return [isa.encode(mn, rd=R(ops[0]), rs1=R(ops[1]), rs2=R(ops[2]))]
        if f in ("I", "IS"):
            if o.cls in (isa.LDG, isa.LDS):
                self._nops(mn, ops, 2)
                base, off = self._mem(ops[1], syms, regs)
                return [isa.encode(mn, rd=R(ops[0]), rs1=base, imm=off)]
            self._nops(mn, ops, 3)
            return [isa.encode(mn, rd=R(ops[0]), rs1=R(ops[1]), imm=E(ops[2]))]
        if f == "U":
            self._nops(mn, ops, 2)
            return [isa.encode(mn, rd=R(ops[0]), imm=E(ops[1]))]
        if f == "S":
            self._nops(mn, ops, 2)
            base, off = self._mem(ops[1], syms, regs)
            return [isa.encode(mn, rs2=R(ops[0]), rs1=base, imm=off)]
        if f == "SR":
            self._nops(mn, ops, 2)
            return [isa.encode(mn, rd=R(ops[0]), imm=E(ops[1]))]
        if f == "P":
            self._nops(mn, ops, 2)
            return [isa.encode(mn, rs1=R(ops[0]), imm=E(ops[1]))]
        if f == "J":
            self._nops(mn, ops, 1)
            return [isa.encode(mn, imm=E(ops[0]) - pc)]
        if f == "B":
            self._nops(mn, ops, 3)
            t, r = E(ops[1]), E(ops[2])
            if r <= pc:
                raise AsmError(f"reconvergence address {r} is not after the branch at {pc}")
            if r - pc > 0x7FF:
                raise AsmError(f"reconvergence offset {r - pc} does not fit 11 bits")
            if not -1024 <= t - pc <= 1023:
                raise AsmError(f"branch offset {t - pc} does not fit 11 bits")
            if t > r:
                warnings.append(f"{where}: warning: branch target {t} is beyond its reconvergence address {r} "
                                f"(F_RECONV if the branch diverges)")
            return [isa.encode(mn, rs1=R(ops[0]), imm=t - pc, imm2=r - pc)]
        raise AsmError(f"unknown mnemonic '{mn}'")


def assemble(text: str, name: str = "kernel", pred_en: bool = True, predefined=None) -> Program:
    """Assemble ``text``; raises AsmError carrying every diagnostic on failure."""
    return Assembler(pred_en).assemble(text, name, predefined)
