"""Evaluation workloads, written once in the structured kernel language.

Families (docs/06-evaluation.md):
    uniform      branch condition uniform within each warp (no divergence)
    balanced     50/50 lane split (lane parity, or random data)
    sparse       few active lanes: one lane per warp, one thread per workgroup,
                 ~1/8 of threads by data, partially populated warps
    nested       if/else nested D deep on lane bits; chained if/else-if (piecewise)
    loops        uniform and divergent nested loops, search loop with break,
                 break inside an if (reconverges at the loop exit)
    exits        guard exit, exit inside a loop, exits before a barrier
    barrier      shared-memory tree reduction (barrier inside a uniform loop)

Every workload stores one result word per thread (and, for the reduction, one
word in total) so that results can be checked against the per-thread oracle.
Registers r1..r10 only: r11..r15 belong to the if-converter.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Callable, Dict, List

from .kc import (Bar, Break, DoWhile, Exit, ExitIf, If, Op, Stmt, While, ops)

OUT = 0x100          # word address of per-thread results (byte 0x400)
IN = 0x200           # word address of input data (byte 0x800), 64 words
IN_WORDS = 64


@dataclass
class Workload:
    name: str
    family: str
    body: List[Stmt]
    wg_dim: int = 32
    gmem: Dict[int, int] = field(default_factory=dict)
    args: List[int] = field(default_factory=lambda: [0] * 8)
    doc: str = ""


def _data(seed: int, n: int = IN_WORDS) -> Dict[int, int]:
    r = random.Random(seed)
    return {IN + i: r.randint(0, 0xFFFF) for i in range(n)}


PROLOGUE = "rdsr r1, SR_TID; shli r2, r1, 2; rdsr r3, SR_LANE_ID"


def work(k: int, acc: str = "r5", salt: int = 1) -> List[Stmt]:
    """k dependent ALU instructions on ``acc`` (a stand-in for real arm work)."""
    seq = []
    for i in range(k):
        m = (i + salt) % 4
        if m == 0:
            seq.append(f"addi {acc}, {acc}, {salt * 3 + i}")
        elif m == 1:
            seq.append(f"xori {acc}, {acc}, {(salt * 37 + i * 11) & 0xFF}")
        elif m == 2:
            seq.append(f"shli {acc}, {acc}, 1")
        else:
            seq.append(f"add {acc}, {acc}, r1")
    return [Op(s) for s in seq]


def store(acc: str = "r5") -> List[Stmt]:
    return ops(f"stg {acc}, [r2 + {OUT * 4}]")


def load_in(dst: str, idx: str = "r1") -> List[Stmt]:
    return ops(f"andi {dst}, {idx}, {IN_WORDS - 1}; shli {dst}, {dst}, 2; ldg {dst}, [{dst} + {IN * 4}]")


# ------------------------------------------------------------------------------- families
def uniform(k: int) -> Workload:
    body = ops(PROLOGUE + "; rdsr r4, SR_WARP_ID; andi r4, r4, 1; addi r5, r0, 0") + [
        If("r4", work(k, salt=1), work(k, salt=2))] + store()
    return Workload(f"uniform_k{k}", "uniform", body, doc=f"if/else on warp parity, {k}-instruction arms")


def balanced(k: int) -> Workload:
    body = ops(PROLOGUE + "; andi r4, r3, 1; addi r5, r0, 0") + [
        If("r4", work(k, salt=1), work(k, salt=2))] + store()
    return Workload(f"balanced_k{k}", "balanced", body, doc=f"if/else on lane parity, {k}-instruction arms")


def balanced_data(k: int) -> Workload:
    body = ops(PROLOGUE + "; addi r5, r0, 0") + load_in("r4") + ops("andi r4, r4, 1") + [
        If("r4", work(k, salt=1), work(k, salt=2))] + store()
    return Workload(f"balanced_data_k{k}", "balanced", body, gmem=_data(11),
                    doc=f"if/else on random data bit (~50%), {k}-instruction arms")


def sparse_lane(k: int) -> Workload:
    body = ops(PROLOGUE + "; addi r5, r0, 1; sltiu r4, r3, 1") + [If("r4", work(k, salt=3))] + store()
    return Workload(f"sparse_lane_k{k}", "sparse", body, doc=f"only lane 0 of each warp runs a {k}-instruction arm")


def sparse_tid0(k: int) -> Workload:
    body = ops(PROLOGUE + "; addi r5, r0, 1; sltiu r4, r1, 1") + [If("r4", work(k, salt=3))] + store()
    return Workload(f"sparse_tid0_k{k}", "sparse", body,
                    doc=f"only thread 0 of the workgroup runs a {k}-instruction arm (3 warps skip it uniformly)")


def sparse_data(k: int) -> Workload:
    body = ops(PROLOGUE + "; addi r5, r0, 1") + load_in("r4") + ops("andi r4, r4, 7; sltiu r4, r4, 1") + [
        If("r4", work(k, salt=3))] + store()
    return Workload(f"sparse_data_k{k}", "sparse", body, gmem=_data(12),
                    doc=f"~1/8 of threads (by data) run a {k}-instruction arm")


def partial(k: int) -> Workload:
    w = balanced(k)
    return Workload(f"partial20_k{k}", "sparse", w.body, wg_dim=20,
                    doc=f"lane-parity if/else with 20 threads (warp 2 half full, warp 3 empty)")


def nested(depth: int, k: int) -> Workload:
    """If/else nested ``depth`` deep; level d tests lane bit d (register r4+d); accumulator r9."""
    def lvl(d: int) -> List[Stmt]:
        if d == depth:
            return work(k, acc="r9", salt=d + 1)
        c = f"r{4 + d}"
        return [If(c, work(1, acc="r9", salt=2 * d + 1) + lvl(d + 1),
                   work(1, acc="r9", salt=2 * d + 2) + lvl(d + 1))]
    conds = "; ".join(f"andi r{4 + d}, r3, {1 << d}" for d in range(depth))
    body = ops(PROLOGUE + "; addi r9, r0, 0; " + conds) + lvl(0) + store("r9")
    return Workload(f"nested_d{depth}_k{k}", "nested", body,
                    doc=f"if/else nested {depth} deep on lane bits, {k}-instruction leaves")


def piecewise(k: int) -> Workload:
    """x<64: A  elif x<128: B  elif x<192: C  else D   (else-if chain = nested in the else arm)."""
    body = ops(PROLOGUE + "; addi r5, r0, 0") + load_in("r4") + ops("andi r4, r4, 255; slti r6, r4, 64") + [
        If("r6", work(k, salt=1),
           ops("slti r6, r4, 128") + [
               If("r6", work(k, salt=2),
                  ops("slti r6, r4, 192") + [If("r6", work(k, salt=3), work(k, salt=4))])])] + store()
    return Workload(f"piecewise_k{k}", "nested", body, gmem=_data(13),
                    doc=f"4-way else-if chain on data, {k}-instruction arms")


def loops_uniform(n: int, k: int) -> Workload:
    body = ops(PROLOGUE + f"; addi r5, r0, 0; addi r6, r0, 0; addi r7, r0, {n}") + [
        DoWhile(work(k) + ops("addi r6, r6, 1; slt r8, r6, r7"), "r8")] + store()
    return Workload(f"loop_uniform_n{n}_k{k}", "loops", body, doc=f"do-while, {n} trips for every thread")


def loops_divergent(k: int) -> Workload:
    """Outer trip tid%4+1, inner trip (data[outer+tid] & 3)+1: both lane-divergent."""
    body = ops(PROLOGUE + "; addi r5, r0, 0; andi r7, r1, 3; addi r7, r7, 1; addi r6, r0, 0") + [
        DoWhile(ops("add r9, r6, r1") + load_in("r9", "r9") +
                ops("andi r9, r9, 3; addi r9, r9, 1; addi r8, r0, 0") + [
                    DoWhile(work(k) + ops("addi r8, r8, 1; slt r10, r8, r9"), "r10")] +
                ops("addi r6, r6, 1; slt r10, r6, r7"), "r10")] + store()
    return Workload(f"loop_nested_div_k{k}", "loops", body, gmem=_data(14),
                    doc="outer trip 1..4 (tid%4+1) x inner trip 1..4 (data), both divergent")


def loop_while_div(k: int) -> Workload:
    body = ops(PROLOGUE + "; addi r5, r0, 0; addi r6, r0, 0; andi r7, r3, 7") + [
        While(ops("slt r8, r6, r7"), "r8", work(k) + ops("addi r6, r6, 1"))] + store()
    return Workload(f"loop_while_lane_k{k}", "loops", body, doc="while loop, trip count = lane id (0..7)")


def loop_break(k: int) -> Workload:
    body = ops(PROLOGUE + "; addi r5, r0, 0; addi r6, r0, 0; andi r7, r1, 15; shli r7, r7, 10") + [
        While(ops("slti r8, r6, 16"), "r8",
              ops("add r9, r6, r1") + load_in("r9", "r9") + ops("slt r10, r7, r9") + [Break("r10")] +
              work(k) + ops("addi r6, r6, 1"))] + ops("add r5, r5, r6") + store()
    return Workload(f"loop_break_k{k}", "loops", body, gmem=_data(15),
                    doc="search loop: conditional break when data > threshold(tid)")


def loop_break_in_if(k: int) -> Workload:
    body = ops(PROLOGUE + "; addi r5, r0, 0; addi r6, r0, 0; andi r7, r1, 15; shli r7, r7, 10") + [
        While(ops("slti r8, r6, 16"), "r8",
              ops("add r9, r6, r1") + load_in("r9", "r9") + ops("slt r10, r7, r9") + [
                  If("r10", work(2, salt=5) + [Break()])] +
              work(k) + ops("addi r6, r6, 1"))] + ops("add r5, r5, r6") + store()
    return Workload(f"loop_break_in_if_k{k}", "loops", body, gmem=_data(15),
                    doc="same search, but the break sits inside an if with extra work: the if reconverges "
                        "at the loop exit (IPDOM), serialising the remaining trips")


def exit_guard(n: int, k: int) -> Workload:
    body = ops(PROLOGUE + f"; addi r5, r0, 0; slti r4, r1, {n}; xori r4, r4, 1") + [ExitIf("r4")] + \
        work(k) + store()
    return Workload(f"exit_guard_n{n}_k{k}", "exits", body,
                    doc=f"threads with tid >= {n} exit at once (tail warps exit whole)")


def exit_in_loop(k: int) -> Workload:
    body = ops(PROLOGUE + "; addi r5, r0, 0; addi r6, r0, 0; addi r7, r0, 1") + store() + [
        While(ops("slti r8, r6, 12"), "r8",
              ops("add r9, r6, r1") + load_in("r9", "r9") + ops("andi r9, r9, 15; sltiu r10, r9, 2") +
              [If("r10", ops("addi r5, r6, 100") + store() + [Exit()])] +
              work(k) + ops("addi r6, r6, 1"))] + store()
    return Workload(f"exit_in_loop_k{k}", "exits", body, gmem=_data(16),
                    doc="threads terminate inside a loop when they find a match (~1/8 per trip)")


def exit_barrier(k: int) -> Workload:
    body = ops(PROLOGUE + "; addi r5, r0, 0; andi r4, r1, 5; sltiu r4, r4, 1; xori r4, r4, 1") + [
        ExitIf("r4")] + ops("shli r6, r1, 2; sts r1, [r6 + 0]") + [Bar()] + \
        ops("xori r7, r1, 2; shli r7, r7, 2; lds r5, [r7 + 0]") + work(k) + store()
    return Workload(f"exit_barrier_k{k}", "exits", body,
                    doc="3/4 of threads exit; survivors exchange through shared memory across a barrier")


def reduce_smem() -> Workload:
    body = ops(PROLOGUE) + load_in("r4") + ops("shli r6, r1, 2; sts r4, [r6 + 0]; addi r7, r0, 16") + [
        Bar(),
        DoWhile(ops("slt r8, r1, r7") + [
            If("r8", ops("shli r9, r7, 2; add r9, r9, r6; lds r9, [r9 + 0]; lds r10, [r6 + 0]; "
                         "add r10, r10, r9; sts r10, [r6 + 0]"))] +
                [Bar()] + ops("shri r7, r7, 1"), "r7"),
        If("r1", [], ops(f"lds r5, [r0 + 0]; stg r5, [r0 + {OUT * 4 + 128}]"))]
    return Workload("reduce_smem", "barrier", body, gmem=_data(17),
                    doc="shared-memory tree reduction; barrier in a uniform loop, divergent if between barriers")


def suite() -> List[Workload]:
    w: List[Workload] = []
    for k in (4, 16):
        w.append(uniform(k))
    for k in (2, 8, 16):
        w.append(balanced(k))
    w.append(balanced_data(8))
    for k in (8, 32):
        w.append(sparse_lane(k))
        w.append(sparse_tid0(k))
    w.append(sparse_data(16))
    w.append(partial(8))
    for d in (1, 2, 3):
        w.append(nested(d, 4))
    w.append(piecewise(6))
    w.append(loops_uniform(4, 4))
    w.append(loop_while_div(4))
    w.append(loops_divergent(3))
    w.append(loop_break(3))
    w.append(loop_break_in_if(3))
    w.append(exit_guard(20, 8))
    w.append(exit_guard(4, 8))
    w.append(exit_in_loop(3))
    w.append(exit_barrier(4))
    w.append(reduce_smem())
    return w


def by_name(name: str) -> Workload:
    return next(x for x in suite() if x.name == name)
