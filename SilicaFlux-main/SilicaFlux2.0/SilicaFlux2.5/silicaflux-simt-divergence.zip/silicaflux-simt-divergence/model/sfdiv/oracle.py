"""Per-thread (MIMD) oracle: every thread runs as an independent scalar program.

This is the *definition* of the per-thread architectural result that SIMT
execution must preserve.  It knows nothing about warps, masks or reconvergence:

* ``bz``/``bnz`` send the thread to ``target`` or ``pc + 1`` (the reconvergence
  operand is ignored);
* ``pz``/``pnz`` open a per-thread window: the next ``n`` instructions execute
  only if this thread's predicate holds (otherwise they are skipped);
* ``bar`` blocks the thread until every thread that has not exited is blocked
  at a barrier; ``exit`` ends the thread.

Threads run one after another until they block (thread-id order).  For
race-free programs (SF-G1 docs/04 4.5) the final registers of every thread and
the final memory are independent of that order, so they must equal the SIMT
model's and the RTL's results.  ``atomadd`` return values are order dependent;
kernels compared this way discard them (``rd = r0``) or only compare memory.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from . import isa
from .isa import Config, MASK32
from .machine import Launch


@dataclass
class OracleResult:
    regs: List[List[int]]          # [tid][reg]
    exited: List[bool]
    gmem: List[int]
    smem: List[int]
    fault: Optional[str]
    steps: int


class _T:
    __slots__ = ("tid", "pc", "regs", "state", "pcount", "pflag")

    def __init__(self, tid, pc):
        self.tid, self.pc = tid, pc
        self.regs = [0] * isa.NREGS
        self.state = "run"          # run | bar | exit
        self.pcount = 0
        self.pflag = True


def run_oracle(cfg: Config, launch: Launch, max_steps: int = 5_000_000) -> OracleResult:
    code = list(launch.code)
    cw = launch.code_words if launch.code_words is not None else len(code)
    shared_bytes = launch.shared_bytes if launch.shared_bytes is not None else cfg.smem_words * 4
    args = launch.norm_args()
    gmem = [0] * cfg.gmem_words
    for a, v in (launch.gmem or {}).items():
        gmem[a] = v & MASK32
    smem = [0] * cfg.smem_words
    for a, v in (launch.smem or {}).items():
        smem[a] = v & MASK32
    L = cfg.lanes
    ts = [_T(t, launch.entry_pc) for t in range(launch.wg_dim)]
    steps = 0

    def sr(idx, t):
        tid = t.tid
        vals = {0: tid % L, 1: tid // L, 2: tid, 3: launch.wg_id, 4: launch.wg_dim, 5: launch.grid_dim,
                6: launch.wg_id * launch.wg_dim + tid, 7: L, 8: shared_bytes}
        return (vals[idx] if idx in vals else args[idx - 16]) & MASK32

    def fault(msg):
        return OracleResult([t.regs for t in ts], [t.state == "exit" for t in ts], gmem, smem, msg, steps)

    while True:
        progressed = False
        for t in ts:
            while t.state == "run":
                if steps >= max_steps:
                    return fault("watchdog")
                steps += 1
                progressed = True
                if not 0 <= t.pc < cw:
                    return fault(f"thread {t.tid}: pc {t.pc} out of range")
                d = isa.decode(code[t.pc], cfg.pred_en)
                if d.illegal:
                    return fault(f"thread {t.tid}: illegal instruction at {t.pc}")
                cls = d.cls
                in_win = t.pcount > 0
                if in_win:
                    t.pcount -= 1
                    if not t.pflag:
                        t.pc += 1               # predicated off: no effect at all
                        continue
                r = t.regs
                o = d.op

                def wb(rd, v):
                    if rd:
                        r[rd] = v & MASK32
                if cls in (isa.NOP, isa.FENCE):
                    t.pc += 1
                elif cls == isa.ALU:
                    b = r[d.rs2] if o.fmt == "R" else d.imm
                    wb(d.rd, isa.alu(o.alu, r[d.rs1], b))
                    t.pc += 1
                elif cls == isa.SREAD:
                    wb(d.rd, sr(d.imm, t))
                    t.pc += 1
                elif cls in isa.MEM_CLASSES:
                    glob = cls in (isa.LDG, isa.STG, isa.ATOM)
                    a = (r[d.rs1] + (0 if cls == isa.ATOM else d.imm)) & MASK32
                    lim = cfg.gmem_bytes if glob else shared_bytes
                    if a & 3 or a >= lim:
                        return fault(f"thread {t.tid}: bad address 0x{a:x} at {t.pc}")
                    m = gmem if glob else smem
                    if cls in (isa.LDG, isa.LDS):
                        wb(d.rd, m[a >> 2])
                    elif cls in (isa.STG, isa.STS):
                        m[a >> 2] = r[d.rs2]
                    else:
                        old = m[a >> 2]
                        m[a >> 2] = (old + r[d.rs2]) & MASK32
                        wb(d.rd, old)
                    t.pc += 1
                elif cls == isa.JUMP:
                    t.pc += d.imm
                elif cls == isa.BRANCH:
                    z = r[d.rs1] == 0
                    taken = z if o.name == "bz" else not z
                    t.pc = t.pc + d.imm if taken else t.pc + 1
                elif cls == isa.EXIT:
                    t.state = "exit"
                elif cls == isa.BAR:
                    t.state = "bar"
                    t.pc += 1
                elif cls == isa.TRAP:
                    return fault(f"thread {t.tid}: trap {d.imm}")
                elif cls == isa.PRED:
                    z = r[d.rs1] == 0
                    t.pflag = z if o.name == "pz" else not z
                    t.pcount = d.imm
                    t.pc += 1
        alive = [t for t in ts if t.state != "exit"]
        if not alive:
            break
        if all(t.state == "bar" for t in alive):
            for t in alive:
                t.state = "run"
            continue
        if not progressed:
            return fault("deadlock")
    return OracleResult([t.regs for t in ts], [t.state == "exit" for t in ts], gmem, smem, None, steps)
