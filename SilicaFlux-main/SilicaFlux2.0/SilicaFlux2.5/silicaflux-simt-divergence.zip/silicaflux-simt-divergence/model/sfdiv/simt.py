"""Per-warp reconvergence stack: the normative reference for docs/01-reconvergence-spec.md.

State
    entries : list of [pc, rpc, mask]   (index 0 = bottom, -1 = top)
    live    : lanes whose threads have not executed ``exit``

    top          = entries[-1]
    active mask  = top.mask & live
    warp PC      = top.pc

Commands (exactly one per issued instruction; rtl/sfd_simt_stack.sv implements the same set):
    SEQ               top.pc += 1
    JUMP  t           top.pc  = t
    BRANCH c, t, R    see branch()
    EXIT  m           live &= ~m

Resolution (after every command; the RTL performs one pop per clock):
    while stack non-empty and (top.pc == top.rpc or top.mask & live == 0): pop

The class records structured events so traces can explain each step.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from .isa import RPC_NONE, popcount


@dataclass
class BranchOutcome:
    kind: str                 # "none-taken" | "all-taken" | "diverge"
    taken: int
    fall: int
    reuse: bool = False
    paths: List[tuple] = field(default_factory=list)   # (pc, rpc, mask) pushed/placed, bottom->top
    needed: int = 0           # new entries required
    overflow: bool = False


class ReconvStack:
    __slots__ = ("depth", "entries", "live", "max_sp", "pushes", "pops_reconv", "pops_dead")

    def __init__(self, depth: int):
        self.depth = depth
        self.entries: List[List[int]] = []
        self.live = 0
        self.max_sp = 0
        self.pushes = 0
        self.pops_reconv = 0
        self.pops_dead = 0

    # ------------------------------------------------------------------ views
    @property
    def sp(self) -> int:
        return len(self.entries)

    @property
    def empty(self) -> bool:
        return not self.entries

    @property
    def top(self) -> List[int]:
        return self.entries[-1]

    @property
    def pc(self) -> int:
        return self.entries[-1][0]

    @property
    def rpc(self) -> int:
        return self.entries[-1][1]

    @property
    def active(self) -> int:
        return self.entries[-1][2] & self.live if self.entries else 0

    def snapshot(self) -> List[tuple]:
        return [tuple(e) for e in self.entries]

    def needs_pop(self) -> Optional[str]:
        """'R' if top reached its reconvergence pc, 'X' if it has no live lane, else None."""
        if not self.entries:
            return None
        pc, rpc, mask = self.entries[-1]
        if (mask & self.live) == 0:
            return "X"
        if pc == rpc:
            return "R"
        return None

    @property
    def settled(self) -> bool:
        return self.needs_pop() is None

    # --------------------------------------------------------------- commands
    def init(self, pc: int, mask: int) -> None:
        self.live = mask
        self.entries = [[pc, RPC_NONE, mask]] if mask else []
        self.max_sp = self.sp

    def seq(self) -> None:
        self.entries[-1][0] += 1

    def jump(self, target: int) -> None:
        self.entries[-1][0] = target

    def exit(self, mask: int) -> None:
        self.live &= ~mask

    def plan_branch(self, cond: int, target: int, reconv: int) -> BranchOutcome:
        """Compute the effect of BRANCH without changing state (used for the precise overflow check)."""
        pc, rpc, mask = self.entries[-1]
        act = mask & self.live
        t_m = act & cond
        n_m = act & ~cond
        if t_m == 0:
            return BranchOutcome("none-taken", t_m, n_m)
        if n_m == 0:
            return BranchOutcome("all-taken", t_m, n_m)
        paths = []
        if pc + 1 != reconv:
            paths.append((pc + 1, reconv, n_m))      # fall-through path: runs second
        if target != reconv:
            paths.append((target, reconv, t_m))      # taken path: on top, runs first
        reuse = (rpc == reconv)
        needed = max(len(paths) - 1, 0) if reuse else len(paths)
        o = BranchOutcome("diverge", t_m, n_m, reuse, paths, needed)
        o.overflow = self.sp + needed > self.depth
        return o

    def branch(self, cond: int, target: int, reconv: int) -> BranchOutcome:
        o = self.plan_branch(cond, target, reconv)
        if o.overflow:
            return o                                   # precise: no state change
        top = self.entries[-1]
        if o.kind == "none-taken":
            top[0] += 1
        elif o.kind == "all-taken":
            top[0] = target
        elif o.reuse:
            if not o.paths:
                top[0] = reconv
            else:
                self.entries[-1] = list(o.paths[0])
                for p in o.paths[1:]:
                    self.entries.append(list(p))
                    self.pushes += 1
        else:
            top[0] = reconv                            # top becomes the reconvergence entry
            for p in o.paths:
                self.entries.append(list(p))
                self.pushes += 1
        self.max_sp = max(self.max_sp, self.sp)
        return o

    # ------------------------------------------------------------- resolution
    def pop_one(self) -> Optional[tuple]:
        r = self.needs_pop()
        if r is None:
            return None
        e = tuple(self.entries.pop())
        if r == "R":
            self.pops_reconv += 1
        else:
            self.pops_dead += 1
        return (r, e)

    def resolve(self) -> List[tuple]:
        ev = []
        while True:
            p = self.pop_one()
            if p is None:
                return ev
            ev.append(p)

    # ------------------------------------------------------------- invariants
    def check_invariants(self, lanes: int) -> None:
        """Structural invariants of a settled or unsettled stack (asserted by tests and mirrored in RTL).

        I1  sp <= depth
        I2  bottom entry has rpc == RPC_NONE
        I3  every non-bottom entry e[i] has a *reconvergence entry* below it:
            the nearest j < i with e[j].pc == e[i].rpc, and e[i].mask is a subset of e[j].mask
        I4  entries that share a reconvergence entry have pairwise disjoint masks
        I5  live is a subset of the bottom entry's mask
        """
        full = (1 << lanes) - 1
        E = self.entries
        assert len(E) <= self.depth, "I1"
        if not E:
            return
        assert E[0][1] == RPC_NONE, "I2"
        assert (self.live & ~E[0][2] & full) == 0, "I5"
        groups = {}
        for i in range(1, len(E)):
            pc, rpc, m = E[i]
            j = next((j for j in range(i - 1, -1, -1) if E[j][0] == rpc), None)
            assert j is not None, f"I3 no reconvergence entry for {E[i]} in {E}"
            assert (m & ~E[j][2]) == 0, f"I3 mask {m:x} not within {E[j][2]:x}"
            groups.setdefault(j, []).append(m)
        for j, ms in groups.items():
            acc = 0
            for m in ms:
                assert (acc & m) == 0, f"I4 overlapping masks over entry {j}: {[hex(x) for x in ms]}"
                acc |= m


def depth_bound(lanes: int) -> int:
    """No command stream can make the stack deeper than this (property-tested)."""
    return 2 * lanes - 1


def mask_str(mask: int, lanes: int) -> str:
    """Lane 0 on the left: '#' active, '.' inactive."""
    return "".join("#" if (mask >> i) & 1 else "." for i in range(lanes))


def lanes_str(mask: int) -> str:
    ls = [str(i) for i in range(32) if (mask >> i) & 1]
    return "{" + ",".join(ls) + "}" if ls else "{}"


__all__ = ["ReconvStack", "BranchOutcome", "depth_bound", "mask_str", "lanes_str", "popcount"]
