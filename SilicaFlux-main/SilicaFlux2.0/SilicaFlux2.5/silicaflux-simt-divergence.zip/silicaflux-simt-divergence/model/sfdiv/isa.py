"""SF-G1 instruction set as used by the divergence core, plus the SFX-PRED extension.

Encodings, opcodes, special registers and fault codes are those of the SilicaFlux
SF-G1 specification (docs/02-isa.md and docs/generated/isa_reference.md in the
silicaflux-sf-g1 tree).  The only addition is the *predication window*
extension (``pz`` / ``pnz``, format ``P``), which exists so that branch-based
divergence can be compared with predicated execution.  It is enabled by
``Config.pred_en`` (RTL parameter ``PRED_EN``); with it disabled the two opcodes
are illegal, exactly as in SF-G1.

Everything in this file is mirrored by rtl/sfd_defs.svh and rtl/sfd_decode.sv;
tests/test_isa.py checks encode/decode round trips, the illegal-word rules and that the
RTL constants match.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

MASK32 = 0xFFFF_FFFF
NREGS = 16
PCW = 11                      # width of pc / rpc fields in the RTL
RPC_NONE = (1 << PCW) - 1     # "no reconvergence address" (bottom stack entry)


def s32(x: int) -> int:
    x &= MASK32
    return x - (1 << 32) if x & 0x8000_0000 else x


def sext(x: int, bits: int) -> int:
    x &= (1 << bits) - 1
    return x - (1 << bits) if x >> (bits - 1) else x


def popcount(x: int) -> int:
    return bin(x).count("1")


def lanes_of(mask: int):
    i = 0
    while mask:
        if mask & 1:
            yield i
        mask >>= 1
        i += 1


# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class Config:
    lanes: int = 8            # L: lanes per warp
    warps: int = 4            # W: warp slots (= one workgroup of up to W*L threads)
    depth: int = 8            # reconvergence-stack entries per warp
    imem_words: int = 1024
    gmem_words: int = 4096    # global memory = 16 KiB
    smem_words: int = 256     # shared memory = 1 KiB
    pred_en: bool = True

    def __post_init__(self):
        assert self.lanes in (2, 4, 8, 16, 32)
        assert 1 <= self.warps <= 16
        assert 1 <= self.depth <= 64
        assert self.imem_words <= RPC_NONE - 1

    @property
    def full_mask(self) -> int:
        return (1 << self.lanes) - 1

    @property
    def gmem_bytes(self) -> int:
        return self.gmem_words * 4

    @property
    def safe_depth(self) -> int:
        """Depth at which F_STACK_OVERFLOW is impossible for any program (2L-1)."""
        return 2 * self.lanes - 1


# --------------------------------------------------------------------------
# Opcodes, formats, classes
# --------------------------------------------------------------------------
# class names
NOP, EXIT, BAR, FENCE, TRAP, ALU, SREAD, LDG, STG, LDS, STS, ATOM, JUMP, BRANCH, PRED = range(15)
CLASS_NAMES = ["NOP", "EXIT", "BAR", "FENCE", "TRAP", "ALU", "SREAD", "LDG", "STG", "LDS", "STS",
               "ATOM", "JUMP", "BRANCH", "PRED"]
MEM_CLASSES = (LDG, STG, LDS, STS, ATOM)
# Instructions that may not appear inside a predication window
WINDOW_FORBIDDEN = (EXIT, BAR, TRAP, JUMP, BRANCH, PRED)

# ALU function codes (SF-G1 numbering)
A_ADD, A_SUB, A_MUL, A_AND, A_OR, A_XOR, A_SHL, A_SHR, A_SAR, A_SLT, A_SLTU, A_PASSB = range(12)


@dataclass(frozen=True)
class OpInfo:
    name: str
    opcode: int
    fmt: str
    cls: int
    alu: int = A_ADD


_OPS = [
    OpInfo("nop", 0x00, "Z", NOP),
    OpInfo("exit", 0x01, "Z", EXIT),
    OpInfo("bar", 0x02, "Z", BAR),
    OpInfo("fence", 0x03, "Z", FENCE),
    OpInfo("trap", 0x04, "T", TRAP),
    OpInfo("add", 0x10, "R", ALU, A_ADD),
    OpInfo("sub", 0x11, "R", ALU, A_SUB),
    OpInfo("mul", 0x12, "R", ALU, A_MUL),
    OpInfo("and", 0x13, "R", ALU, A_AND),
    OpInfo("or", 0x14, "R", ALU, A_OR),
    OpInfo("xor", 0x15, "R", ALU, A_XOR),
    OpInfo("shl", 0x16, "R", ALU, A_SHL),
    OpInfo("shr", 0x17, "R", ALU, A_SHR),
    OpInfo("sar", 0x18, "R", ALU, A_SAR),
    OpInfo("slt", 0x19, "R", ALU, A_SLT),
    OpInfo("sltu", 0x1A, "R", ALU, A_SLTU),
    OpInfo("addi", 0x20, "I", ALU, A_ADD),
    OpInfo("andi", 0x21, "I", ALU, A_AND),
    OpInfo("ori", 0x22, "I", ALU, A_OR),
    OpInfo("xori", 0x23, "I", ALU, A_XOR),
    OpInfo("shli", 0x24, "IS", ALU, A_SHL),
    OpInfo("shri", 0x25, "IS", ALU, A_SHR),
    OpInfo("sari", 0x26, "IS", ALU, A_SAR),
    OpInfo("slti", 0x27, "I", ALU, A_SLT),
    OpInfo("sltiu", 0x28, "I", ALU, A_SLTU),
    OpInfo("lui", 0x29, "U", ALU, A_PASSB),
    OpInfo("rdsr", 0x2A, "SR", SREAD),
    OpInfo("ldg", 0x30, "I", LDG),
    OpInfo("stg", 0x31, "S", STG),
    OpInfo("lds", 0x32, "I", LDS),
    OpInfo("sts", 0x33, "S", STS),
    OpInfo("atomadd", 0x34, "R", ATOM),
    OpInfo("bra", 0x38, "J", JUMP),
    OpInfo("bz", 0x39, "B", BRANCH),
    OpInfo("bnz", 0x3A, "B", BRANCH),
    # SFX-PRED extension (not part of SF-G1)
    OpInfo("pz", 0x3B, "P", PRED),
    OpInfo("pnz", 0x3C, "P", PRED),
]
OPS: Dict[str, OpInfo] = {o.name: o for o in _OPS}
BY_OPCODE: Dict[int, OpInfo] = {o.opcode: o for o in _OPS}
PRED_OPCODES = (0x3B, 0x3C)

# Reserved-bit masks per format (bits that must be zero)
RESERVED = {
    "R": 0x0000_3FFF, "I": 0, "IS": 0x0003_FFE0, "U": 0, "S": 0, "B": 0, "J": 0,
    "T": 0x03FF_0000, "Z": 0x03FF_FFFF, "SR": 0x003F_FFE0, "P": 0x003F_FFE0,
}

# --------------------------------------------------------------------------
# Special registers
# --------------------------------------------------------------------------
SR = {
    "SR_LANE_ID": 0, "SR_WARP_ID": 1, "SR_TID": 2, "SR_WG_ID": 3, "SR_WG_DIM": 4,
    "SR_GRID_DIM": 5, "SR_GTID": 6, "SR_LANES": 7, "SR_SHARED_BYTES": 8,
    **{f"SR_ARG{i}": 16 + i for i in range(8)},
}
SR_VALID = set(SR.values())
SR_NAMES = {v: k for k, v in SR.items()}

# --------------------------------------------------------------------------
# Faults (SF-G1 codes 16..26; 27 is the SFX-PRED extension)
# --------------------------------------------------------------------------
F_NONE = 0
F_ILLEGAL_INSN = 16
F_PC_RANGE = 17
F_RECONV = 18
F_GMEM_ALIGN = 19
F_GMEM_RANGE = 20
F_SMEM_ALIGN = 21
F_SMEM_RANGE = 22
F_STACK_OVERFLOW = 23
F_BAR_DIVERGENT = 24
F_TRAP = 25
F_WATCHDOG = 26
F_PRED_WINDOW = 27
FAULT_NAMES = {
    F_NONE: "NONE", F_ILLEGAL_INSN: "F_ILLEGAL_INSN", F_PC_RANGE: "F_PC_RANGE", F_RECONV: "F_RECONV",
    F_GMEM_ALIGN: "F_GMEM_ALIGN", F_GMEM_RANGE: "F_GMEM_RANGE", F_SMEM_ALIGN: "F_SMEM_ALIGN",
    F_SMEM_RANGE: "F_SMEM_RANGE", F_STACK_OVERFLOW: "F_STACK_OVERFLOW", F_BAR_DIVERGENT: "F_BAR_DIVERGENT",
    F_TRAP: "F_TRAP", F_WATCHDOG: "F_WATCHDOG", F_PRED_WINDOW: "F_PRED_WINDOW",
}


# --------------------------------------------------------------------------
# Encode / decode
# --------------------------------------------------------------------------
@dataclass
class Decoded:
    word: int
    illegal: bool
    op: Optional[OpInfo]
    rd: int = 0
    rs1: int = 0
    rs2: int = 0
    imm: int = 0      # sign/zero-extended main immediate
    imm2: int = 0     # roff (B format)

    @property
    def cls(self) -> int:
        return self.op.cls if self.op else -1

    @property
    def name(self) -> str:
        return self.op.name if self.op else "<illegal>"


def _chk(v: int, bits: int, signed: bool, what: str) -> int:
    if signed:
        lo, hi = -(1 << (bits - 1)), (1 << (bits - 1)) - 1
    else:
        lo, hi = 0, (1 << bits) - 1
    if not lo <= v <= hi:
        raise ValueError(f"{what} {v} does not fit {'signed' if signed else 'unsigned'} {bits} bits")
    return v & ((1 << bits) - 1)


def encode(name: str, rd: int = 0, rs1: int = 0, rs2: int = 0, imm: int = 0, imm2: int = 0) -> int:
    o = OPS[name]
    w = o.opcode << 26
    f = o.fmt
    for r in (rd, rs1, rs2):
        if not 0 <= r < NREGS:
            raise ValueError(f"register r{r} does not exist")
    if f == "R":
        w |= rd << 22 | rs1 << 18 | rs2 << 14
    elif f == "I":
        w |= rd << 22 | rs1 << 18 | _chk(imm, 18, True, "immediate")
    elif f == "IS":
        w |= rd << 22 | rs1 << 18 | _chk(imm, 5, False, "shift amount")
    elif f == "U":
        w |= rd << 22 | _chk(imm, 22, False, "upper immediate")
    elif f == "S":
        w |= rs2 << 22 | rs1 << 18 | _chk(imm, 18, True, "immediate")
    elif f == "B":
        w |= rs1 << 22 | _chk(imm, 11, True, "branch offset") << 11 | _chk(imm2, 11, False, "reconvergence offset")
        if imm2 == 0:
            raise ValueError("reconvergence offset must be >= 1")
    elif f == "J":
        w |= _chk(imm, 26, True, "jump offset")
    elif f == "T":
        w |= _chk(imm, 16, False, "trap code")
    elif f == "SR":
        if imm not in SR_VALID:
            raise ValueError(f"undefined special register {imm}")
        w |= rd << 22 | imm
    elif f == "P":
        if not 1 <= imm <= 31:
            raise ValueError("predication window length must be 1..31")
        w |= rs1 << 22 | imm
    return w


def decode(word: int, pred_en: bool = True) -> Decoded:
    word &= MASK32
    opc = word >> 26
    o = BY_OPCODE.get(opc)
    if o is None or (opc in PRED_OPCODES and not pred_en):
        return Decoded(word, True, None)
    f = o.fmt
    if word & RESERVED[f]:
        return Decoded(word, True, o)
    d = Decoded(word, False, o)
    a = (word >> 22) & 0xF
    b = (word >> 18) & 0xF
    c = (word >> 14) & 0xF
    if f == "R":
        d.rd, d.rs1, d.rs2 = a, b, c
    elif f == "I":
        d.rd, d.rs1, d.imm = a, b, sext(word, 18)
    elif f == "IS":
        d.rd, d.rs1, d.imm = a, b, word & 0x1F
    elif f == "U":
        d.rd, d.imm = a, (word & 0x3F_FFFF) << 10
    elif f == "S":
        d.rs2, d.rs1, d.imm = a, b, sext(word, 18)
    elif f == "B":
        d.rs1, d.imm, d.imm2 = a, sext(word >> 11, 11), word & 0x7FF
        if d.imm2 == 0:
            d.illegal = True
    elif f == "J":
        d.imm = sext(word, 26)
    elif f == "T":
        d.imm = word & 0xFFFF
    elif f == "SR":
        d.rd, d.imm = a, word & 0x1F
        if d.imm not in SR_VALID:
            d.illegal = True
    elif f == "P":
        d.rs1, d.imm = a, word & 0x1F
        if d.imm == 0:
            d.illegal = True
    return d


def alu(fn: int, a: int, b: int) -> int:
    a &= MASK32
    b &= MASK32
    if fn == A_ADD:
        r = a + b
    elif fn == A_SUB:
        r = a - b
    elif fn == A_MUL:
        r = a * b
    elif fn == A_AND:
        r = a & b
    elif fn == A_OR:
        r = a | b
    elif fn == A_XOR:
        r = a ^ b
    elif fn == A_SHL:
        r = a << (b & 31)
    elif fn == A_SHR:
        r = a >> (b & 31)
    elif fn == A_SAR:
        r = s32(a) >> (b & 31)
    elif fn == A_SLT:
        r = 1 if s32(a) < s32(b) else 0
    elif fn == A_SLTU:
        r = 1 if a < b else 0
    elif fn == A_PASSB:
        r = b
    else:
        raise ValueError(fn)
    return r & MASK32


def disasm(word: int, pc: Optional[int] = None, pred_en: bool = True) -> str:
    d = decode(word, pred_en)
    if d.illegal:
        return f".word 0x{word:08x}"
    o = d.op
    f = o.fmt
    n = o.name
    if f == "Z":
        return n
    if f == "T":
        return f"{n} {d.imm}"
    if f == "R":
        if o.cls == ATOM:
            return f"{n} r{d.rd}, [r{d.rs1}], r{d.rs2}"
        return f"{n} r{d.rd}, r{d.rs1}, r{d.rs2}"
    if f in ("I", "IS"):
        if o.cls in (LDG, LDS):
            return f"{n} r{d.rd}, [r{d.rs1} {'+' if d.imm >= 0 else '-'} {abs(d.imm)}]"
        return f"{n} r{d.rd}, r{d.rs1}, {d.imm}"
    if f == "U":
        return f"{n} r{d.rd}, {d.imm >> 10}"
    if f == "S":
        return f"{n} r{d.rs2}, [r{d.rs1} {'+' if d.imm >= 0 else '-'} {abs(d.imm)}]"
    if f == "SR":
        return f"{n} r{d.rd}, {SR_NAMES[d.imm]}"
    if f == "P":
        return f"{n} r{d.rs1}, {d.imm}"
    if f == "J":
        return f"{n} {pc + d.imm}" if pc is not None else f"{n} .{d.imm:+d}"
    if f == "B":
        if pc is not None:
            return f"{n} r{d.rs1}, {pc + d.imm}, {pc + d.imm2}"
        return f"{n} r{d.rs1}, .{d.imm:+d}, .+{d.imm2}"
    return n
