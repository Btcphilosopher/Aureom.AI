// =============================================================================
// ds_model.sv -- behavioural downstream for the coalescer testbench
//
// Models a byte-addressed memory behind TWO ports (ordinary + atomic) with:
//   * random request back-pressure                       (+P_MRDY / +P_ARDY, percent)
//   * random service latency                             (+LAT_MIN / +LAT_MAX, cycles)
//   * OPERATIONS PERFORM AT SERVICE TIME, not at accept, so two requests that
//     overlap and are in flight together really do take effect in a
//     latency-dependent order -> a missing ordering interlock in the DUT
//     produces wrong data instead of passing silently.
//   * random response reordering                         (+REORDER=1; 0 = strict in-order)
//   * random response gaps                               (+P_DRSP, percent)
//   * fault / hole / slow address regions                (+FAULT_LO/HI, +HOLE_LO/HI, +SLOW_LO/HI)
//   * duplicate-response injection                       (+DUP_PCT, per mille)
//   * independent hazard check: refuses (flags) any pair of simultaneously
//     outstanding overlapping accesses that the DUT's interlock must prevent.
//
// The atomic port performs atomics in ISSUE ORDER (its documented contract);
// only the responses may come back reordered.
// =============================================================================
`default_nettype none

module ds_model #(
  parameter int ADDR_W       = 32,
  parameter int TXN_BYTES    = 128,
  parameter int ATOM_BYTES   = 8,
  parameter int NUM_MEM_TAGS = 16,
  parameter int NUM_ATM_TAGS = 8,
  parameter int MEM_BYTES    = 65536,
  parameter int MTAG_W       = 4,
  parameter int ATAG_W       = 3,
  parameter int SIZE_W       = 2,
  parameter bit DS_OOO       = 1'b1,     // mirrors the DUT parameter (selects hazard-check policy)
  parameter int MAX_INSTR    = 4096
) (
  input  logic                     clk,
  input  logic                     rst_n,

  input  logic                     mem_req_valid,
  output logic                     mem_req_ready,
  input  logic [MTAG_W-1:0]        mem_req_id,
  input  logic                     mem_req_write,
  input  logic [ADDR_W-1:0]        mem_req_addr,
  input  logic [TXN_BYTES-1:0]     mem_req_mask,
  input  logic [TXN_BYTES*8-1:0]   mem_req_wdata,
  input  logic [31:0]              mem_req_inst,   // expected-stream instruction index (from TB)

  output logic                     mem_rsp_valid,
  input  logic                     mem_rsp_ready,
  output logic [MTAG_W-1:0]        mem_rsp_id,
  output logic [TXN_BYTES*8-1:0]   mem_rsp_rdata,
  output logic                     mem_rsp_err,

  input  logic                     atm_req_valid,
  output logic                     atm_req_ready,
  input  logic [ATAG_W-1:0]        atm_req_id,
  input  logic [3:0]               atm_req_op,
  input  logic [SIZE_W-1:0]        atm_req_size,
  input  logic [ADDR_W-1:0]        atm_req_addr,
  input  logic [ATOM_BYTES*8-1:0]  atm_req_a,
  input  logic [ATOM_BYTES*8-1:0]  atm_req_b,
  input  logic [31:0]              atm_req_inst,

  output logic                     atm_rsp_valid,
  input  logic                     atm_rsp_ready,
  output logic [ATAG_W-1:0]        atm_rsp_id,
  output logic [ATOM_BYTES*8-1:0]  atm_rsp_rdata,
  output logic                     atm_rsp_err,

  // statistics / error counters
  output int unsigned              n_hole,
  output int unsigned              n_slow,
  output int unsigned              n_fault,
  output int unsigned              n_dup,
  output int unsigned              n_errors      // DS-detected DUT misbehaviour
);

  localparam int NM = NUM_MEM_TAGS;
  localparam int NA = NUM_ATM_TAGS;
  localparam int ATOM_W = ATOM_BYTES * 8;

  // ---------------- memory ----------------
  logic [7:0] mem [0:MEM_BYTES-1];

  task automatic load_mem(input string path);
    $readmemh(path, mem);
  endtask

  // ---------------- local PRNG (xorshift32; simulator independent) ----------------
  int unsigned rng;
  function automatic int unsigned rnd();
    rng = rng ^ (rng << 13);
    rng = rng ^ (rng >> 17);
    rng = rng ^ (rng << 5);
    return rng;
  endfunction
  function automatic int urange(input int n);   // 0..n-1
    return (n <= 1) ? 0 : int'(rnd() % unsigned'(n));
  endfunction
  function automatic bit chance(input int pct);
    return (urange(100) < pct);
  endfunction

  // ---------------- configuration (plusargs) ----------------
  int p_mrdy = 100, p_ardy = 100, p_drsp = 100, lat_min = 20, lat_max = 20, reorder = 0;
  int dup_pm = 0, slow_extra = 400, nohzchk = 0;
  longint unsigned fault_lo = 1, fault_hi = 0, hole_lo = 1, hole_hi = 0, slow_lo = 1, slow_hi = 0;
  int unsigned seed_v = 1;
  string profile;

  initial begin
    if ($value$plusargs("PROFILE=%s", profile)) begin
      if (profile == "stress") begin p_mrdy = 50; p_ardy = 50; p_drsp = 50; lat_min = 2; lat_max = 60; reorder = 1; end
      if (profile == "heavy")  begin p_mrdy = 20; p_ardy = 20; p_drsp = 25; lat_min = 1; lat_max = 120; reorder = 1; end
    end
    void'($value$plusargs("P_MRDY=%d", p_mrdy));
    void'($value$plusargs("P_ARDY=%d", p_ardy));
    void'($value$plusargs("P_DRSP=%d", p_drsp));
    void'($value$plusargs("LAT_MIN=%d", lat_min));
    void'($value$plusargs("LAT_MAX=%d", lat_max));
    void'($value$plusargs("REORDER=%d", reorder));
    void'($value$plusargs("DUP_PM=%d", dup_pm));
    void'($value$plusargs("SLOW_EXTRA=%d", slow_extra));
    void'($value$plusargs("NOHZCHK=%d", nohzchk));
    void'($value$plusargs("FAULT_LO=%d", fault_lo)); void'($value$plusargs("FAULT_HI=%d", fault_hi));
    void'($value$plusargs("HOLE_LO=%d",  hole_lo));  void'($value$plusargs("HOLE_HI=%d",  hole_hi));
    void'($value$plusargs("SLOW_LO=%d",  slow_lo));  void'($value$plusargs("SLOW_HI=%d",  slow_hi));
    void'($value$plusargs("SEED=%d", seed_v));
    rng = seed_v * 32'h9E3779B1 + 32'h1234567;
    if (rng == 0) rng = 1;
  end

  // ---------------- address-region classification ----------------
  // 0 ok, 1 fault, 2 hole, 3 slow
  function automatic int region(input longint unsigned line);
    if (line >= fault_lo && line < fault_hi) return 1;
    if (line >= hole_lo  && line < hole_hi)  return 2;
    if (line >= slow_lo  && line < slow_hi)  return 3;
    return 0;
  endfunction

  // ---------------- AMO ALU (independent re-implementation of the Python model) ----------------
  function automatic logic [63:0] amo_alu(input logic [3:0] op, input logic [63:0] old_v,
                                          input logic [63:0] a_v, input logic [63:0] b_v, input int nbytes);
    logic [63:0] m, o, x, y;
    logic signed [63:0] so, sx;
    int bits, sh;
    bits = 8 * nbytes;
    sh   = 64 - bits;
    m    = (bits == 64) ? 64'hFFFF_FFFF_FFFF_FFFF : ((64'd1 << bits) - 64'd1);
    o = old_v & m; x = a_v & m; y = b_v & m;
    so = $signed(o << sh) >>> sh;
    sx = $signed(x << sh) >>> sh;
    case (op)
      4'd0:    amo_alu = (o + x) & m;
      4'd1:    amo_alu = o & x;
      4'd2:    amo_alu = o | x;
      4'd3:    amo_alu = o ^ x;
      4'd4:    amo_alu = (so <= sx) ? o : x;
      4'd5:    amo_alu = (so >= sx) ? o : x;
      4'd6:    amo_alu = (o <= x) ? o : x;
      4'd7:    amo_alu = (o >= x) ? o : x;
      4'd8:    amo_alu = x;
      4'd9:    amo_alu = (o == x) ? y : o;
      default: amo_alu = o;
    endcase
  endfunction

  // ---------------- record state ----------------
  typedef enum logic [1:0] {R_FREE, R_WAIT, R_DONE, R_HOLE} rst_e;

  rst_e                    m_st    [NM];
  logic                    m_wr    [NM];
  logic [ADDR_W-1:0]       m_addr  [NM];
  logic [TXN_BYTES-1:0]    m_mask  [NM];
  logic [TXN_BYTES*8-1:0]  m_wd    [NM];
  logic [TXN_BYTES*8-1:0]  m_rd    [NM];
  logic                    m_err   [NM];
  logic [31:0]             m_inst  [NM];
  int                      m_ready [NM];
  int                      m_seq   [NM];

  rst_e                    a_st    [NA];
  logic [3:0]              a_op    [NA];
  int                      a_nb    [NA];
  logic [ADDR_W-1:0]       a_addr  [NA];
  logic [ATOM_W-1:0]       a_a     [NA];
  logic [ATOM_W-1:0]       a_b     [NA];
  logic [ATOM_W-1:0]       a_rd    [NA];
  logic                    a_err   [NA];
  logic [31:0]             a_inst  [NA];
  int                      a_ready [NA];
  int                      a_seq   [NA];

  int cyc = 0;
  int m_seq_ctr = 0, a_seq_ctr = 0;

  // per-instruction count of downstream operations performed (read by the scoreboard)
  int unsigned perf_m [0:MAX_INSTR-1];
  int unsigned perf_a [0:MAX_INSTR-1];

  // response drivers
  logic                    mrsp_busy, arsp_busy;
  logic [MTAG_W-1:0]       mrsp_id_q;
  logic [ATAG_W-1:0]       arsp_id_q;
  logic                    mrsp_is_dup, arsp_is_dup;
  logic                    mdup_pend, adup_pend;
  logic [MTAG_W-1:0]       mdup_id;
  logic [ATAG_W-1:0]       adup_id;

  function automatic void flag(input string msg);
    n_errors++;
    if (n_errors <= 10) $display("[%0t] DS_MODEL ERROR: %s", $time, msg);
  endfunction

  // ---------------- main per-cycle process ----------------
  int mstart, astart;
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int t = 0; t < NM; t++) m_st[t] = R_FREE;
      for (int t = 0; t < NA; t++) a_st[t] = R_FREE;
      mem_req_ready <= 1'b0; atm_req_ready <= 1'b0;
      mem_rsp_valid <= 1'b0; atm_rsp_valid <= 1'b0;
      mem_rsp_id <= '0; atm_rsp_id <= '0; mem_rsp_rdata <= '0; atm_rsp_rdata <= '0;
      mem_rsp_err <= 1'b0; atm_rsp_err <= 1'b0;
      for (int i = 0; i < MAX_INSTR; i++) begin perf_m[i] = 0; perf_a[i] = 0; end
      mrsp_busy = 0; arsp_busy = 0; mdup_pend = 0; adup_pend = 0;
      mrsp_is_dup = 0; arsp_is_dup = 0;
      cyc = 0; m_seq_ctr = 0; a_seq_ctr = 0;
      n_hole = 0; n_slow = 0; n_fault = 0; n_dup = 0; n_errors = 0;
    end else begin
      cyc++;
      // ============ 1. retire responses that were handshaken this edge ============
      if (mrsp_busy && mem_rsp_ready) begin
        mrsp_busy = 0;
        mem_rsp_valid <= 1'b0;
        if (!mrsp_is_dup) begin
          m_st[mrsp_id_q] = R_FREE;
          if (urange(1000) < dup_pm) begin mdup_pend = 1; mdup_id = mrsp_id_q; end
        end
        mrsp_is_dup = 0;
      end
      if (arsp_busy && atm_rsp_ready) begin
        arsp_busy = 0;
        atm_rsp_valid <= 1'b0;
        if (!arsp_is_dup) begin
          a_st[arsp_id_q] = R_FREE;
          if (urange(1000) < dup_pm) begin adup_pend = 1; adup_id = arsp_id_q; end
        end
        arsp_is_dup = 0;
      end

      // ============ 2. accept requests ============
      if (mem_req_valid && mem_req_ready) begin
        logic [MTAG_W-1:0] id; int rg; int hz_mem_conflict;
        id = mem_req_id;
        if (int'(id) >= NM) flag("mem request id out of range");
        else begin
          if (m_st[id] != R_FREE) flag($sformatf("DUT re-used mem tag %0d while still outstanding", id));
          rg = region(longint'(mem_req_addr));
          // independent ordering check: no overlapping outstanding access with a writer
          if (nohzchk == 0) begin
            for (int t = 0; t < NM; t++)
              if (t != int'(id) && (m_st[t] == R_WAIT || m_st[t] == R_DONE) &&
                  m_addr[t] == mem_req_addr && |(m_mask[t] & mem_req_mask) &&
                  DS_OOO && (m_wr[t] || mem_req_write))
                flag($sformatf("ORDERING: overlapping mem txns outstanding together (tags %0d,%0d line 0x%h)", t, id, mem_req_addr));
            for (int t = 0; t < NA; t++)
              if ((a_st[t] == R_WAIT || a_st[t] == R_DONE) &&
                  (a_addr[t] & ~ADDR_W'(TXN_BYTES - 1)) == mem_req_addr)
                for (int k = 0; k < a_nb[t]; k++)
                  if (mem_req_mask[int'(a_addr[t] % TXN_BYTES) + k])
                    flag($sformatf("ORDERING: mem txn overlaps outstanding atomic (line 0x%h)", mem_req_addr));
          end
          m_wr[id] = mem_req_write; m_addr[id] = mem_req_addr; m_mask[id] = mem_req_mask;
          m_wd[id] = mem_req_wdata; m_inst[id] = mem_req_inst; m_err[id] = 0;
          m_seq[id] = m_seq_ctr++;
          m_ready[id] = cyc + lat_min + urange(lat_max - lat_min + 1) + ((rg == 3) ? slow_extra : 0);
          if (rg == 2) begin m_st[id] = R_HOLE; n_hole++; end
          else         m_st[id] = R_WAIT;
        end
      end
      if (atm_req_valid && atm_req_ready) begin
        logic [ATAG_W-1:0] id; int rg; int nb;
        id = atm_req_id;
        nb = 1 << int'(atm_req_size);
        if (int'(id) >= NA) flag("atm request id out of range");
        else begin
          if (a_st[id] != R_FREE) flag($sformatf("DUT re-used atm tag %0d while still outstanding", id));
          rg = region(longint'(atm_req_addr) & ~longint'(TXN_BYTES - 1));
          if (atm_req_addr % nb != 0) flag("atomic request not naturally aligned");
          if (nohzchk == 0) begin
            for (int t = 0; t < NM; t++)
              if ((m_st[t] == R_WAIT || m_st[t] == R_DONE) &&
                  m_addr[t] == (atm_req_addr & ~ADDR_W'(TXN_BYTES - 1)))
                for (int k = 0; k < nb; k++)
                  if (m_mask[t][int'(atm_req_addr % TXN_BYTES) + k])
                    flag($sformatf("ORDERING: atomic overlaps outstanding mem txn (addr 0x%h)", atm_req_addr));
          end
          a_op[id] = atm_req_op; a_nb[id] = nb; a_addr[id] = atm_req_addr;
          a_a[id] = atm_req_a; a_b[id] = atm_req_b; a_inst[id] = atm_req_inst; a_err[id] = 0;
          a_seq[id] = a_seq_ctr++;
          a_ready[id] = cyc + lat_min + urange(lat_max - lat_min + 1) + ((rg == 3) ? slow_extra : 0);
          if (rg == 2) begin a_st[id] = R_HOLE; n_hole++; end
          else         a_st[id] = R_WAIT;
        end
      end

      // ============ 3. perform operations whose service time has elapsed ============
      mstart = urange(NM);
      for (int kk = 0; kk < NM; kk++) begin
        int t, oldest, rg;
        t = (kk + mstart) % NM;
        oldest = 1;
        if (!reorder)                         // strict mode: only the oldest waiting record may perform
          for (int u = 0; u < NM; u++) if (m_st[u] == R_WAIT && m_seq[u] < m_seq[t]) oldest = 0;
        if (m_st[t] == R_WAIT && cyc >= m_ready[t] && oldest) begin
          rg = region(longint'(m_addr[t]));
          m_err[t] = 0;
          m_rd[t]  = '0;
          if (int'(m_addr[t]) + TXN_BYTES > MEM_BYTES) begin
            flag($sformatf("mem txn beyond end of memory: 0x%h", m_addr[t]));
            m_err[t] = 1;
          end else if (rg == 1) begin
            m_err[t] = 1; n_fault++;
            for (int j = 0; j < TXN_BYTES; j++) m_rd[t][j*8 +: 8] = 8'hEE;
          end else begin
            if (rg == 3) n_slow++;
            if (m_wr[t]) begin
              for (int j = 0; j < TXN_BYTES; j++)
                if (m_mask[t][j]) mem[int'(m_addr[t]) + j] = m_wd[t][j*8 +: 8];
            end else begin
              for (int j = 0; j < TXN_BYTES; j++)
                m_rd[t][j*8 +: 8] = m_mask[t][j] ? mem[int'(m_addr[t]) + j] : (8'hA5 ^ j[7:0]);
            end
          end
          m_st[t] = R_DONE;
          if (m_inst[t] < MAX_INSTR) perf_m[m_inst[t]]++;
        end
      end
      for (int kk = 0; kk < NA; kk++) begin
        int t, rg, nb; logic [63:0] old_v, new_v; int oldest;
        t = kk;
        oldest = 1;                           // atomics always perform in issue order
        for (int u = 0; u < NA; u++) if (a_st[u] == R_WAIT && a_seq[u] < a_seq[t]) oldest = 0;
        if (a_st[t] == R_WAIT && cyc >= a_ready[t] && oldest) begin
          nb = a_nb[t];
          rg = region(longint'(a_addr[t]) & ~longint'(TXN_BYTES - 1));
          a_err[t] = 0; a_rd[t] = '0;
          if (int'(a_addr[t]) + nb > MEM_BYTES) begin
            flag($sformatf("atomic beyond end of memory: 0x%h", a_addr[t]));
            a_err[t] = 1;
          end else if (rg == 1) begin a_err[t] = 1; n_fault++; end
          else begin
            if (rg == 3) n_slow++;
            old_v = '0;
            for (int j = 0; j < 8; j++) if (j < nb) old_v[j*8 +: 8] = mem[int'(a_addr[t]) + j];
            new_v = amo_alu(a_op[t], old_v, {{(64-ATOM_W){1'b0}}, a_a[t]}, {{(64-ATOM_W){1'b0}}, a_b[t]}, nb);
            for (int j = 0; j < 8; j++) if (j < nb) mem[int'(a_addr[t]) + j] = new_v[j*8 +: 8];
            a_rd[t] = old_v[ATOM_W-1:0];
          end
          a_st[t] = R_DONE;
          if (a_inst[t] < MAX_INSTR) perf_a[a_inst[t]]++;
        end
      end

      // ============ 4. drive responses ============
      if (!mrsp_busy) begin
        if (mdup_pend) begin                        // protocol-abuse: duplicate of the response just delivered
          mdup_pend = 0; mrsp_busy = 1; mrsp_is_dup = 1; n_dup++;
          mrsp_id_q = mdup_id;
          mem_rsp_valid <= 1'b1; mem_rsp_id <= mdup_id; mem_rsp_err <= urange(2); mem_rsp_rdata <= {TXN_BYTES{8'h5A}};
        end else if (chance(p_drsp)) begin
          int pick, cnt, best;
          pick = -1; cnt = 0; best = 0;
          if (reorder) begin                        // random among completed records
            for (int t = 0; t < NM; t++) if (m_st[t] == R_DONE) begin
              cnt++;
              if (urange(cnt) == 0) pick = t;
            end
          end else begin                            // in-order: the oldest outstanding record, once done
            best = 32'h7FFF_FFFF;
            for (int t = 0; t < NM; t++)
              if ((m_st[t] == R_WAIT || m_st[t] == R_DONE) && m_seq[t] < best) begin best = m_seq[t]; pick = t; end
            if (pick >= 0 && m_st[pick] != R_DONE) pick = -1;
          end
          if (pick >= 0) begin
            mrsp_busy = 1; mrsp_is_dup = 0; mrsp_id_q = pick[MTAG_W-1:0];
            mem_rsp_valid <= 1'b1; mem_rsp_id <= pick[MTAG_W-1:0];
            mem_rsp_rdata <= m_rd[pick]; mem_rsp_err <= m_err[pick];
          end
        end
      end
      if (!arsp_busy) begin
        if (adup_pend) begin
          adup_pend = 0; arsp_busy = 1; arsp_is_dup = 1; n_dup++;
          arsp_id_q = adup_id;
          atm_rsp_valid <= 1'b1; atm_rsp_id <= adup_id; atm_rsp_err <= urange(2); atm_rsp_rdata <= {ATOM_BYTES{8'h5A}};
        end else if (chance(p_drsp)) begin
          int pick, cnt;
          pick = -1; cnt = 0;
          for (int t = 0; t < NA; t++) if (a_st[t] == R_DONE) begin
            cnt++;
            if (reorder ? (urange(cnt) == 0) : (pick < 0 || a_seq[t] < a_seq[pick])) pick = t;
          end
          if (pick >= 0) begin
            arsp_busy = 1; arsp_is_dup = 0; arsp_id_q = pick[ATAG_W-1:0];
            atm_rsp_valid <= 1'b1; atm_rsp_id <= pick[ATAG_W-1:0];
            atm_rsp_rdata <= a_rd[pick]; atm_rsp_err <= a_err[pick];
          end
        end
      end

      // ============ 5. next-cycle request readiness (random back-pressure) ============
      mem_req_ready <= chance(p_mrdy);
      atm_req_ready <= chance(p_ardy);
    end
  end

  // outstanding (non-hole) record counts for drain detection
  function automatic int live_records();
    int c; c = 0;
    for (int t = 0; t < NM; t++) if (m_st[t] == R_WAIT || m_st[t] == R_DONE) c++;
    for (int t = 0; t < NA; t++) if (a_st[t] == R_WAIT || a_st[t] == R_DONE) c++;
    return c + int'(mrsp_busy) + int'(arsp_busy) + int'(mdup_pend) + int'(adup_pend);
  endfunction

  // compare the final memory image with the Python golden image; returns mismatching bytes
  function automatic int compare_mem(input string path);
    logic [7:0] gold [0:MEM_BYTES-1];
    int bad;
    $readmemh(path, gold);
    bad = 0;
    for (int a = 0; a < MEM_BYTES; a++)
      if (mem[a] !== gold[a]) begin
        if (bad < 8) $display("  memory mismatch @0x%0h: dut=%02h gold=%02h", a, mem[a], gold[a]);
        bad++;
      end
    return bad;
  endfunction

endmodule

`default_nettype wire
