// =============================================================================
// coalescer_checker.sv -- passive protocol + "exactly once" checker
//
// Instantiated next to the DUT; observes the ports only.  Properties:
//
//   SVA (concurrent)
//     P1  req payload held stable while req_valid && !req_ready      (requester obligation)
//     P2  rsp payload held stable while rsp_valid && !rsp_ready      (DUT obligation)
//     P3  mem_req / atm_req payload held stable until accepted       (DUT obligation)
//     P4  mem_req address aligned, mask non-empty, data confined to mask, loads carry no data
//     P5  atomic requests naturally aligned and carry a legal opcode
//     P6  response channels from downstream are never back-pressured (ready held high)
//
//   Bookkeeping (procedural; this is the exactly-once argument at the interface)
//     B1  every accepted request is given a fresh slot id (no id live twice)
//     B2  uid increments by exactly one per accepted request (never repeats)
//     B3  every response names a slot that is in flight, with the uid it was given
//     B4  no uid is ever completed twice
//     B5  accepted - completed <= NUM_INSTR_SLOTS and never negative
//     B6  (UP_INORDER) responses leave in request order
//     B7  downstream tags are never re-issued while outstanding
// =============================================================================
`default_nettype none

module coalescer_checker #(
  parameter int NUM_LANES       = 32,
  parameter int ADDR_W          = 32,
  parameter int MAX_ACC_BYTES   = 8,
  parameter int TXN_BYTES       = 128,
  parameter int NUM_INSTR_SLOTS = 8,
  parameter int NUM_MEM_TAGS    = 16,
  parameter int NUM_ATM_TAGS    = 8,
  parameter int USER_TAG_W      = 8,
  parameter int UID_W           = 32,
  parameter int SIZE_W          = 2,
  parameter int SLOT_W          = 3,
  parameter int MTAG_W          = 4,
  parameter int ATAG_W          = 3,
  parameter int ATOM_W          = 64,
  parameter bit UP_INORDER      = 1'b0
) (
  input logic                                       clk,
  input logic                                       rst_n,
  input logic                                       req_valid,
  input logic                                       req_ready,
  input logic [1:0]                                 req_op,
  input logic [SIZE_W-1:0]                          req_size,
  input logic [3:0]                                 req_amo,
  input logic [NUM_LANES-1:0]                       req_mask,
  input logic [NUM_LANES-1:0][ADDR_W-1:0]           req_addr,
  input logic [NUM_LANES-1:0][MAX_ACC_BYTES-1:0]    req_be,
  input logic [NUM_LANES-1:0][MAX_ACC_BYTES*8-1:0]  req_wdata,
  input logic [NUM_LANES-1:0][ATOM_W-1:0]           req_wdata2,
  input logic [USER_TAG_W-1:0]                      req_tag,
  input logic [UID_W-1:0]                           req_uid,
  input logic [SLOT_W-1:0]                          req_id,
  input logic                                       rsp_valid,
  input logic                                       rsp_ready,
  input logic [UID_W-1:0]                           rsp_uid,
  input logic [SLOT_W-1:0]                          rsp_id,
  input logic [USER_TAG_W-1:0]                      rsp_tag,
  input logic [1:0]                                 rsp_op,
  input logic [NUM_LANES-1:0][MAX_ACC_BYTES*8-1:0]  rsp_rdata,
  input logic [4:0]                                 rsp_err,
  input logic [NUM_LANES-1:0]                       rsp_err_mask,
  input logic                                       mem_req_valid,
  input logic                                       mem_req_ready,
  input logic [MTAG_W-1:0]                          mem_req_id,
  input logic                                       mem_req_write,
  input logic [ADDR_W-1:0]                          mem_req_addr,
  input logic [TXN_BYTES-1:0]                       mem_req_mask,
  input logic [TXN_BYTES*8-1:0]                     mem_req_wdata,
  input logic                                       mem_rsp_valid,
  input logic                                       mem_rsp_ready,
  input logic [MTAG_W-1:0]                          mem_rsp_id,
  input logic                                       atm_req_valid,
  input logic                                       atm_req_ready,
  input logic [ATAG_W-1:0]                          atm_req_id,
  input logic [3:0]                                 atm_req_op,
  input logic [SIZE_W-1:0]                          atm_req_size,
  input logic [ADDR_W-1:0]                          atm_req_addr,
  input logic [ATOM_W-1:0]                          atm_req_a,
  input logic [ATOM_W-1:0]                          atm_req_b,
  input logic                                       atm_rsp_valid,
  input logic                                       atm_rsp_ready,
  input logic [ATAG_W-1:0]                          atm_rsp_id,
  input logic                                       check_rsp_ids   // 0 while the TB injects bogus downstream responses
);

  localparam int LOG2_TXN = $clog2(TXN_BYTES);

  // ----------------------------------------------------------------------- //
  // SVA
  // ----------------------------------------------------------------------- //
  P1_req_stable: assert property (@(posedge clk) disable iff (!rst_n)
    (req_valid && !req_ready) |=> (req_valid && $stable(req_op) && $stable(req_size) && $stable(req_amo) &&
                                   $stable(req_mask) && $stable(req_addr) && $stable(req_be) &&
                                   $stable(req_wdata) && $stable(req_wdata2) && $stable(req_tag)))
    else $error("[P1] request payload changed while stalled");

  P2_rsp_stable: assert property (@(posedge clk) disable iff (!rst_n)
    (rsp_valid && !rsp_ready) |=> (rsp_valid && $stable(rsp_uid) && $stable(rsp_id) && $stable(rsp_tag) &&
                                   $stable(rsp_op) && $stable(rsp_rdata) && $stable(rsp_err) && $stable(rsp_err_mask)))
    else $error("[P2] response payload changed / dropped while stalled");

  P3a_mem_stable: assert property (@(posedge clk) disable iff (!rst_n)
    (mem_req_valid && !mem_req_ready) |=> (mem_req_valid && $stable(mem_req_id) && $stable(mem_req_write) &&
                                           $stable(mem_req_addr) && $stable(mem_req_mask) && $stable(mem_req_wdata)))
    else $error("[P3] mem_req changed / dropped before being accepted");

  P3b_atm_stable: assert property (@(posedge clk) disable iff (!rst_n)
    (atm_req_valid && !atm_req_ready) |=> (atm_req_valid && $stable(atm_req_id) && $stable(atm_req_op) &&
                                           $stable(atm_req_size) && $stable(atm_req_addr) &&
                                           $stable(atm_req_a) && $stable(atm_req_b)))
    else $error("[P3] atm_req changed / dropped before being accepted");

  P4a_mem_aligned: assert property (@(posedge clk) disable iff (!rst_n)
    mem_req_valid |-> (mem_req_addr[LOG2_TXN-1:0] == '0))
    else $error("[P4] mem_req_addr not aligned to TXN_BYTES");

  P4b_mem_mask: assert property (@(posedge clk) disable iff (!rst_n)
    mem_req_valid |-> (mem_req_mask != '0))
    else $error("[P4] empty byte mask");

  logic [TXN_BYTES*8-1:0] expand_mask;
  always_comb for (int j = 0; j < TXN_BYTES; j++) expand_mask[j*8 +: 8] = {8{mem_req_mask[j]}};

  P4c_mem_data_in_mask: assert property (@(posedge clk) disable iff (!rst_n)
    mem_req_valid |-> ((mem_req_wdata & ~expand_mask) == '0))
    else $error("[P4] write data outside byte mask");

  P4d_load_no_data: assert property (@(posedge clk) disable iff (!rst_n)
    (mem_req_valid && !mem_req_write) |-> (mem_req_wdata == '0))
    else $error("[P4] load carries data");

  P5a_atm_aligned: assert property (@(posedge clk) disable iff (!rst_n)
    atm_req_valid |-> ((int'(atm_req_addr) & ((1 << int'(atm_req_size)) - 1)) == 0))
    else $error("[P5] atomic request not naturally aligned");

  P5b_atm_op: assert property (@(posedge clk) disable iff (!rst_n)
    atm_req_valid |-> (atm_req_op <= 4'd9))
    else $error("[P5] illegal atomic opcode downstream");

  P6_rsp_ready: assert property (@(posedge clk) disable iff (!rst_n) (mem_rsp_ready && atm_rsp_ready))
    else $error("[P6] downstream response channel back-pressured");

  // ----------------------------------------------------------------------- //
  // Bookkeeping
  // ----------------------------------------------------------------------- //
  logic [NUM_INSTR_SLOTS-1:0] slot_busy;
  logic [UID_W-1:0]           slot_uid [NUM_INSTR_SLOTS];
  logic [NUM_MEM_TAGS-1:0]    mem_out;
  logic [NUM_ATM_TAGS-1:0]    atm_out;
  longint unsigned            acc_cnt, rsp_cnt;
  bit                         seen [longint unsigned];

  always @(posedge clk) begin
    if (!rst_n) begin
      slot_busy = '0; mem_out = '0; atm_out = '0; acc_cnt = 0; rsp_cnt = 0;
      seen.delete();
    end else begin
      // ---- completions first (a slot may be re-allocated no earlier than next cycle) ----
      if (rsp_valid && rsp_ready) begin
        if (int'(rsp_id) >= NUM_INSTR_SLOTS) $error("[B3] response slot id %0d out of range", rsp_id);
        else begin
          if (!slot_busy[rsp_id])                $error("[B3] response for slot %0d that is not in flight", rsp_id);
          else if (slot_uid[rsp_id] != rsp_uid)  $error("[B3] slot %0d carries uid %0d but response says %0d",
                                                       rsp_id, slot_uid[rsp_id], rsp_uid);
          slot_busy[rsp_id] = 1'b0;
        end
        if (seen.exists(longint'(rsp_uid)))      $error("[B4] uid %0d completed twice", rsp_uid);
        seen[longint'(rsp_uid)] = 1'b1;
        if (UP_INORDER && longint'(rsp_uid) != longint'(rsp_cnt))
                                                 $error("[B6] out-of-order upstream response: uid %0d, expected %0d", rsp_uid, rsp_cnt);
        rsp_cnt++;
      end
      // ---- acceptances ----
      if (req_valid && req_ready) begin
        if (slot_busy[req_id])                   $error("[B1] slot %0d allocated while still in flight", req_id);
        if (longint'(req_uid) != longint'(acc_cnt)) $error("[B2] uid %0d, expected %0d", req_uid, acc_cnt);
        slot_busy[req_id] = 1'b1;
        slot_uid[req_id]  = req_uid;
        acc_cnt++;
      end
      if (acc_cnt < rsp_cnt || acc_cnt - rsp_cnt > longint'(NUM_INSTR_SLOTS))
        $error("[B5] in-flight count out of range: accepted=%0d completed=%0d", acc_cnt, rsp_cnt);

      // ---- downstream tag discipline ----
      if (mem_rsp_valid && int'(mem_rsp_id) < NUM_MEM_TAGS) begin
        if (check_rsp_ids && !mem_out[mem_rsp_id]) $error("[B7] mem response for tag %0d that is not outstanding", mem_rsp_id);
        mem_out[mem_rsp_id] = 1'b0;
      end
      if (atm_rsp_valid && int'(atm_rsp_id) < NUM_ATM_TAGS) begin
        if (check_rsp_ids && !atm_out[atm_rsp_id]) $error("[B7] atm response for tag %0d that is not outstanding", atm_rsp_id);
        atm_out[atm_rsp_id] = 1'b0;
      end
      if (mem_req_valid && mem_req_ready) begin
        if (mem_out[mem_req_id]) $error("[B7] mem tag %0d re-issued while outstanding", mem_req_id);
        mem_out[mem_req_id] = 1'b1;
      end
      if (atm_req_valid && atm_req_ready) begin
        if (atm_out[atm_req_id]) $error("[B7] atm tag %0d re-issued while outstanding", atm_req_id);
        atm_out[atm_req_id] = 1'b1;
      end
    end
  end

endmodule

`default_nettype wire
