// =============================================================================
// tb_gpu_coalescer.sv -- self-checking testbench
//
//   vectors (Python)  --> driver --> DUT <--> ds_model (random latency / reorder / back-pressure)
//                                     |
//                                     +--> scoreboard + stream monitors + protocol checker
//
// What is checked on every run
//   * EVERY accepted request gets exactly one response (no loss, no duplicate,
//     no response for an unaccepted uid), with matching tag / opcode.
//   * Read data, error flags and error-lane mask equal the Python golden model.
//   * The downstream TRANSACTION STREAM (ordinary and atomic) equals the one the
//     Python model predicts: same count, order, line address, byte mask, write data.
//   * A response is never released before every downstream operation of that
//     request has completed (store-completion tracking); fences likewise.
//   * Final memory image equals the Python golden memory.
//   * DUT performance counters agree with the observed traffic.
//   * ds_model independently flags overlapping concurrent accesses and tag reuse.
//
// Run-time plusargs:  +VEC=<dir> +SEED=n +PROFILE=ideal|stress|heavy +P_REQ=% +P_RSP=%
//   +SERIAL=1 (one request in flight)  +MAX_CYC=n  +DUP_PM=per-mille  (see ds_model.sv)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_gpu_coalescer;
  import gpu_coalescer_pkg::*;

  // ---------------- compile-time configuration (mirrors the DUT) ----------------
  parameter int NUM_LANES        = 32;
  parameter int ADDR_W           = 32;
  parameter int MAX_ACC_BYTES    = 8;
  parameter int TXN_BYTES        = 128;
  parameter int NUM_INSTR_SLOTS  = 8;
  parameter int NUM_MEM_TAGS     = 16;
  parameter int NUM_ATM_TAGS     = 8;
  parameter int USER_TAG_W       = 8;
  parameter int UID_W            = 32;
  parameter bit COALESCE_EN      = 1'b1;
  parameter bit ALLOW_MISALIGNED = 1'b1;
  parameter bit DS_OOO           = 1'b1;
  parameter bit UP_INORDER       = 1'b0;
  parameter int TIMEOUT_CYCLES   = 0;
  parameter int MEM_BYTES        = 65536;     // also the DUT ADDR_LIMIT
  parameter int MAX_INSTR        = 4096;
  parameter int MAX_MTXN         = 65536;
  parameter int MAX_ATXN         = 65536;

  localparam int LOG2_ACC   = $clog2(MAX_ACC_BYTES);
  localparam int SIZE_W     = ($clog2(MAX_ACC_BYTES) < 1) ? 1 : $clog2($clog2(MAX_ACC_BYTES) + 1);
  localparam int SLOT_W     = (NUM_INSTR_SLOTS <= 1) ? 1 : $clog2(NUM_INSTR_SLOTS);
  localparam int MTAG_W     = (NUM_MEM_TAGS    <= 1) ? 1 : $clog2(NUM_MEM_TAGS);
  localparam int ATAG_W     = (NUM_ATM_TAGS    <= 1) ? 1 : $clog2(NUM_ATM_TAGS);
  localparam int ATOM_BYTES = (MAX_ACC_BYTES < 8) ? MAX_ACC_BYTES : 8;
  localparam int ATOM_W     = ATOM_BYTES * 8;
  localparam int ACC_W      = MAX_ACC_BYTES * 8;

  // ---------------- clock / reset ----------------
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------- DUT wiring ----------------
  logic                                       req_valid, req_ready;
  logic [1:0]                                 req_op;
  logic [SIZE_W-1:0]                          req_size;
  logic [3:0]                                 req_amo;
  logic [NUM_LANES-1:0]                       req_mask;
  logic [NUM_LANES-1:0][ADDR_W-1:0]           req_addr;
  logic [NUM_LANES-1:0][MAX_ACC_BYTES-1:0]    req_be;
  logic [NUM_LANES-1:0][ACC_W-1:0]            req_wdata;
  logic [NUM_LANES-1:0][ATOM_W-1:0]           req_wdata2;
  logic [USER_TAG_W-1:0]                      req_tag;
  logic [UID_W-1:0]                           req_uid;
  logic [SLOT_W-1:0]                          req_id;
  logic                                       rsp_valid, rsp_ready;
  logic [UID_W-1:0]                           rsp_uid;
  logic [SLOT_W-1:0]                          rsp_id;
  logic [USER_TAG_W-1:0]                      rsp_tag;
  logic [1:0]                                 rsp_op;
  logic [NUM_LANES-1:0][ACC_W-1:0]            rsp_rdata;
  logic [ERR_W-1:0]                           rsp_err;
  logic [NUM_LANES-1:0]                       rsp_err_mask;

  logic                                       mem_req_valid, mem_req_ready;
  logic [MTAG_W-1:0]                          mem_req_id;
  logic                                       mem_req_write;
  logic [ADDR_W-1:0]                          mem_req_addr;
  logic [TXN_BYTES-1:0]                       mem_req_mask;
  logic [TXN_BYTES*8-1:0]                     mem_req_wdata;
  logic                                       mem_rsp_valid, mem_rsp_ready;
  logic [MTAG_W-1:0]                          mem_rsp_id;
  logic [TXN_BYTES*8-1:0]                     mem_rsp_rdata;
  logic                                       mem_rsp_err;

  logic                                       atm_req_valid, atm_req_ready;
  logic [ATAG_W-1:0]                          atm_req_id;
  logic [3:0]                                 atm_req_op;
  logic [SIZE_W-1:0]                          atm_req_size;
  logic [ADDR_W-1:0]                          atm_req_addr;
  logic [ATOM_W-1:0]                          atm_req_a, atm_req_b;
  logic                                       atm_rsp_valid, atm_rsp_ready;
  logic [ATAG_W-1:0]                          atm_rsp_id;
  logic [ATOM_W-1:0]                          atm_rsp_rdata;
  logic                                       atm_rsp_err;

  logic        idle;
  logic [31:0] stat_instr_accepted, stat_instr_completed, stat_mem_txns, stat_mem_useful_bytes,
               stat_atm_ops, stat_err_instr, stat_rsp_spurious, stat_rsp_late, stat_timeouts;
  logic        stat_proto_err;

  gpu_coalescer #(
    .NUM_LANES(NUM_LANES), .ADDR_W(ADDR_W), .MAX_ACC_BYTES(MAX_ACC_BYTES), .TXN_BYTES(TXN_BYTES),
    .NUM_INSTR_SLOTS(NUM_INSTR_SLOTS), .NUM_MEM_TAGS(NUM_MEM_TAGS), .NUM_ATM_TAGS(NUM_ATM_TAGS),
    .USER_TAG_W(USER_TAG_W), .UID_W(UID_W), .ADDR_LIMIT(MEM_BYTES), .COALESCE_EN(COALESCE_EN),
    .ALLOW_MISALIGNED(ALLOW_MISALIGNED), .DS_OOO(DS_OOO), .UP_INORDER(UP_INORDER),
    .TIMEOUT_CYCLES(TIMEOUT_CYCLES)
  ) dut (.*);

  logic [31:0] mem_req_inst, atm_req_inst;
  int unsigned ds_n_hole, ds_n_slow, ds_n_fault, ds_n_dup, ds_n_errors;

  ds_model #(
    .ADDR_W(ADDR_W), .TXN_BYTES(TXN_BYTES), .ATOM_BYTES(ATOM_BYTES), .NUM_MEM_TAGS(NUM_MEM_TAGS),
    .NUM_ATM_TAGS(NUM_ATM_TAGS), .MEM_BYTES(MEM_BYTES), .MTAG_W(MTAG_W), .ATAG_W(ATAG_W),
    .SIZE_W(SIZE_W), .DS_OOO(DS_OOO), .MAX_INSTR(MAX_INSTR)
  ) ds (
    .clk, .rst_n,
    .mem_req_valid, .mem_req_ready, .mem_req_id, .mem_req_write, .mem_req_addr, .mem_req_mask,
    .mem_req_wdata, .mem_req_inst,
    .mem_rsp_valid, .mem_rsp_ready, .mem_rsp_id, .mem_rsp_rdata, .mem_rsp_err,
    .atm_req_valid, .atm_req_ready, .atm_req_id, .atm_req_op, .atm_req_size, .atm_req_addr,
    .atm_req_a, .atm_req_b, .atm_req_inst,
    .atm_rsp_valid, .atm_rsp_ready, .atm_rsp_id, .atm_rsp_rdata, .atm_rsp_err,
    .n_hole(ds_n_hole), .n_slow(ds_n_slow), .n_fault(ds_n_fault), .n_dup(ds_n_dup), .n_errors(ds_n_errors)
  );

  logic check_rsp_ids = 1'b1;
  coalescer_checker #(
    .NUM_LANES(NUM_LANES), .ADDR_W(ADDR_W), .MAX_ACC_BYTES(MAX_ACC_BYTES), .TXN_BYTES(TXN_BYTES),
    .NUM_INSTR_SLOTS(NUM_INSTR_SLOTS), .NUM_MEM_TAGS(NUM_MEM_TAGS), .NUM_ATM_TAGS(NUM_ATM_TAGS),
    .USER_TAG_W(USER_TAG_W), .UID_W(UID_W), .SIZE_W(SIZE_W), .SLOT_W(SLOT_W), .MTAG_W(MTAG_W),
    .ATAG_W(ATAG_W), .ATOM_W(ATOM_W), .UP_INORDER(UP_INORDER)
  ) chk (.*);

  // ---------------- vectors ----------------
  logic [31:0]                v_cfg   [0:15];
  logic [31:0]                v_meta  [0:MAX_INSTR-1];
  logic [63:0]                v_mask  [0:MAX_INSTR-1];
  logic [ADDR_W-1:0]          v_addr  [0:MAX_INSTR*NUM_LANES-1];
  logic [MAX_ACC_BYTES-1:0]   v_be    [0:MAX_INSTR*NUM_LANES-1];
  logic [ACC_W-1:0]           v_wd    [0:MAX_INSTR*NUM_LANES-1];
  logic [ATOM_W-1:0]          v_wd2   [0:MAX_INSTR*NUM_LANES-1];
  logic [7:0]                 v_eerr  [0:MAX_INSTR-1];
  logic [63:0]                v_emask [0:MAX_INSTR-1];
  logic [ACC_W-1:0]           v_erd   [0:MAX_INSTR*NUM_LANES-1];
  logic [31:0]                v_ecnt  [0:MAX_INSTR-1];
  logic [3:0]                 v_twr   [0:MAX_MTXN-1];
  logic [ADDR_W-1:0]          v_taddr [0:MAX_MTXN-1];
  logic [TXN_BYTES-1:0]       v_tmask [0:MAX_MTXN-1];
  logic [TXN_BYTES*8-1:0]     v_tdata [0:MAX_MTXN-1];
  logic [31:0]                v_tinst [0:MAX_MTXN-1];
  logic [ADDR_W-1:0]          v_xaddr [0:MAX_ATXN-1];
  logic [31:0]                v_xop   [0:MAX_ATXN-1];
  logic [ATOM_W-1:0]          v_xa    [0:MAX_ATXN-1];
  logic [ATOM_W-1:0]          v_xb    [0:MAX_ATXN-1];
  logic [31:0]                v_xinst [0:MAX_ATXN-1];

  int n_instr, n_mtxn, n_atxn;
  string vec_dir;

  // ---------------- run-time knobs ----------------
  int p_req = 100, p_rsp = 100, serial = 0, max_cyc = 3_000_000, verbose = 0;
  int unsigned seed_v = 1;
  string profile;

  int unsigned rng;
  function automatic int unsigned rnd();
    rng = rng ^ (rng << 13);
    rng = rng ^ (rng >> 17);
    rng = rng ^ (rng << 5);
    return rng;
  endfunction
  function automatic bit chance(input int pct);
    return (int'(rnd() % 100) < pct);
  endfunction

  // ---------------- error accounting ----------------
  int errors = 0;
  task automatic fail(input string msg);
    errors++;
    if (errors <= 20) $display("[%0t] TB ERROR: %s", $time, msg);
    if (errors == 20) begin
      $display("TB_RESULT: FAIL (too many errors, aborting)");
      $fatal(1, "aborting after 20 errors");
    end
  endtask

  function automatic int popcnt(input logic [TXN_BYTES-1:0] v);
    int c; c = 0;
    for (int i = 0; i < TXN_BYTES; i++) c += int'(v[i]);
    return c;
  endfunction

  // ---------------- state ----------------
  int cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  int          acc_n = 0, cmp_n = 0;
  bit          drv_done = 1'b0;
  int          acc_cyc [MAX_INSTR];
  int          off_cyc [MAX_INSTR];
  int          rsp_cyc [MAX_INSTR];
  bit          done_i  [MAX_INSTR];
  int unsigned mt_n = 0, at_n = 0;
  longint      useful_bytes = 0, lane_bytes_done = 0;
  int          lat_acc_hist [0:4095];
  int          lat_off_hist [0:4095];
  longint      lat_acc_sum = 0, lat_off_sum = 0;
  int          lat_acc_max = 0, lat_off_max = 0;
  int          first_acc = -1, last_rsp = 0;
  int          n_err_instr_exp = 0;

  assign mem_req_inst = (mt_n < n_mtxn) ? v_tinst[mt_n] : 32'hFFFF_FFFF;
  assign atm_req_inst = (at_n < n_atxn) ? v_xinst[at_n] : 32'hFFFF_FFFF;

  // ---------------- vector loading ----------------
  task automatic load_vectors();
    if (!$value$plusargs("VEC=%s", vec_dir)) begin
      $display("TB_RESULT: FAIL (+VEC=<dir> required)");
      $fatal(1, "missing +VEC");
    end
    $readmemh({vec_dir, "/cfg.hex"},    v_cfg);
    $readmemh({vec_dir, "/meta.hex"},   v_meta);
    $readmemh({vec_dir, "/mask.hex"},   v_mask);
    $readmemh({vec_dir, "/addr.hex"},   v_addr);
    $readmemh({vec_dir, "/be.hex"},     v_be);
    $readmemh({vec_dir, "/wd.hex"},     v_wd);
    $readmemh({vec_dir, "/wd2.hex"},    v_wd2);
    $readmemh({vec_dir, "/e_err.hex"},  v_eerr);
    $readmemh({vec_dir, "/e_emask.hex"}, v_emask);
    $readmemh({vec_dir, "/e_rd.hex"},   v_erd);
    $readmemh({vec_dir, "/e_cnt.hex"},  v_ecnt);
    $readmemh({vec_dir, "/t_wr.hex"},   v_twr);
    $readmemh({vec_dir, "/t_addr.hex"}, v_taddr);
    $readmemh({vec_dir, "/t_mask.hex"}, v_tmask);
    $readmemh({vec_dir, "/t_data.hex"}, v_tdata);
    $readmemh({vec_dir, "/t_inst.hex"}, v_tinst);
    $readmemh({vec_dir, "/x_addr.hex"}, v_xaddr);
    $readmemh({vec_dir, "/x_op.hex"},   v_xop);
    $readmemh({vec_dir, "/x_a.hex"},    v_xa);
    $readmemh({vec_dir, "/x_b.hex"},    v_xb);
    $readmemh({vec_dir, "/x_inst.hex"}, v_xinst);
    ds.load_mem({vec_dir, "/mem_init.hex"});
    n_instr = int'(v_cfg[7]);
    n_mtxn  = int'(v_cfg[8]);
    n_atxn  = int'(v_cfg[9]);
    if (v_cfg[0] != 32'h0C0A1E5C) fail("vector file magic mismatch");
    if (int'(v_cfg[1]) != NUM_LANES || int'(v_cfg[2]) != ADDR_W || int'(v_cfg[3]) != MAX_ACC_BYTES ||
        int'(v_cfg[4]) != TXN_BYTES || int'(v_cfg[5]) != int'(COALESCE_EN) ||
        int'(v_cfg[6]) != int'(ALLOW_MISALIGNED) || int'(v_cfg[10]) != MEM_BYTES)
      fail($sformatf("vectors generated for a different configuration (lanes=%0d addr_w=%0d acc=%0d txn=%0d coal=%0d mis=%0d limit=%0d)",
                     v_cfg[1], v_cfg[2], v_cfg[3], v_cfg[4], v_cfg[5], v_cfg[6], v_cfg[10]));
    if (n_instr > MAX_INSTR || n_mtxn > MAX_MTXN || n_atxn > MAX_ATXN)
      fail($sformatf("vector set too large for TB arrays (%0d/%0d/%0d)", n_instr, n_mtxn, n_atxn));
    for (int i = 0; i < n_instr; i++) if (v_eerr[i] != 0) n_err_instr_exp++;
  endtask

  // ---------------- driver ----------------
  task automatic drive_idle_garbage();
    req_op   <= 2'(rnd());
    req_size <= SIZE_W'(rnd());
    req_amo  <= 4'(rnd());
    req_mask <= NUM_LANES'(rnd());
    req_tag  <= USER_TAG_W'(rnd());
    for (int l = 0; l < NUM_LANES; l++) begin
      req_addr[l]   <= ADDR_W'(rnd());
      req_be[l]     <= MAX_ACC_BYTES'(rnd());
      req_wdata[l]  <= {ACC_W/32 + 1{rnd()}};
      req_wdata2[l] <= {ATOM_W/32 + 1{rnd()}};
    end
  endtask

  initial begin : driver
    req_valid = 1'b0; rsp_ready = 1'b0;
    req_op = '0; req_size = '0; req_amo = '0; req_mask = '0; req_tag = '0;
    req_addr = '0; req_be = '0; req_wdata = '0; req_wdata2 = '0;
    void'($value$plusargs("SEED=%d", seed_v));
    rng = seed_v * 32'h85EBCA6B + 32'h2545F491;
    if (rng == 0) rng = 1;
    if ($value$plusargs("PROFILE=%s", profile)) begin
      if (profile == "stress") begin p_req = 60; p_rsp = 50; end
      if (profile == "heavy")  begin p_req = 100; p_rsp = 15; end
    end
    void'($value$plusargs("P_REQ=%d", p_req));
    void'($value$plusargs("P_RSP=%d", p_rsp));
    void'($value$plusargs("SERIAL=%d", serial));
    void'($value$plusargs("MAX_CYC=%d", max_cyc));
    void'($value$plusargs("VERBOSE=%d", verbose));
    load_vectors();
    repeat (6) @(posedge clk);
    rst_n <= 1'b1;
    repeat (3) @(posedge clk);

    for (int i = 0; i < n_instr; i++) begin
      // idle gap
      while (!chance(p_req)) begin drive_idle_garbage(); @(posedge clk); end
      if (serial != 0) while (cmp_n < i) begin drive_idle_garbage(); @(posedge clk); end
      off_cyc[i] = cyc;
      req_valid <= 1'b1;
      req_op    <= v_meta[i][1:0];
      req_size  <= v_meta[i][2 +: SIZE_W];
      req_amo   <= v_meta[i][6 +: 4];
      req_tag   <= v_meta[i][10 +: USER_TAG_W];
      req_mask  <= v_mask[i][NUM_LANES-1:0];
      for (int l = 0; l < NUM_LANES; l++) begin
        req_addr[l]   <= v_addr[i*NUM_LANES + l];
        req_be[l]     <= v_be[i*NUM_LANES + l];
        req_wdata[l]  <= v_wd[i*NUM_LANES + l];
        req_wdata2[l] <= v_wd2[i*NUM_LANES + l];
      end
      @(posedge clk);
      while (!req_ready) @(posedge clk);          // handshake happened on this edge
      req_valid <= 1'b0;
    end
    drv_done = 1'b1;
    drive_idle_garbage();
  end

  // upstream response back-pressure
  always @(posedge clk) rsp_ready <= rst_n ? chance(p_rsp) : 1'b0;

  // ---------------- scoreboard: request / response monitor ----------------
  always @(posedge clk) begin
    if (rst_n) begin
      // ---- acceptance ----
      if (req_valid && req_ready) begin
        if (int'(req_uid) != acc_n) fail($sformatf("accepted uid %0d, expected %0d", req_uid, acc_n));
        if (acc_n < n_instr) begin
          acc_cyc[acc_n] = cyc;
          if (first_acc < 0) first_acc = cyc;
        end
        acc_n++;
      end
      // ---- completion ----
      if (rsp_valid && rsp_ready) begin
        int idx;
        idx = int'(rsp_uid);
        if (idx >= acc_n || idx >= n_instr) fail($sformatf("response for uid %0d that was never accepted", idx));
        else if (done_i[idx])               fail($sformatf("DUPLICATE completion of uid %0d", idx));
        else begin
          done_i[idx] = 1'b1;
          rsp_cyc[idx] = cyc;
          cmp_n++;
          last_rsp = cyc;
          // identity
          if (rsp_tag !== v_meta[idx][10 +: USER_TAG_W]) fail($sformatf("uid %0d: tag mismatch", idx));
          if (rsp_op  !== v_meta[idx][1:0])              fail($sformatf("uid %0d: opcode mismatch", idx));
          // errors
          if (rsp_err !== v_eerr[idx][ERR_W-1:0])
            fail($sformatf("uid %0d: err flags dut=%b exp=%b", idx, rsp_err, v_eerr[idx][ERR_W-1:0]));
          if (rsp_err_mask !== v_emask[idx][NUM_LANES-1:0])
            fail($sformatf("uid %0d: err mask dut=%h exp=%h", idx, rsp_err_mask, v_emask[idx][NUM_LANES-1:0]));
          // data
          for (int l = 0; l < NUM_LANES; l++)
            if (!v_emask[idx][l] && rsp_rdata[l] !== v_erd[idx*NUM_LANES + l])
              fail($sformatf("uid %0d lane %0d: rdata dut=%h exp=%h", idx, l, rsp_rdata[l], v_erd[idx*NUM_LANES + l]));
          // completion tracking: all downstream work for this request is finished before it completes
          if (!v_eerr[idx][ERR_BIT_TIMEOUT]) begin
            if (ds.perf_m[idx] != int'(v_ecnt[idx][15:0]))
              fail($sformatf("uid %0d completed with %0d/%0d memory transactions answered", idx, ds.perf_m[idx], v_ecnt[idx][15:0]));
            if (ds.perf_a[idx] != int'(v_ecnt[idx][31:16]))
              fail($sformatf("uid %0d completed with %0d/%0d atomic ops answered", idx, ds.perf_a[idx], v_ecnt[idx][31:16]));
          end
          if (v_meta[idx][1:0] == OP_FENCE && v_eerr[idx] == 0) begin
            for (int j = 0; j < idx; j++)
              if (ds.perf_m[j] != int'(v_ecnt[j][15:0]) || ds.perf_a[j] != int'(v_ecnt[j][31:16]))
                if (!v_eerr[j][ERR_BIT_TIMEOUT])
                  fail($sformatf("FENCE uid %0d completed while older uid %0d still had work in flight", idx, j));
          end
          // latency
          begin
            int la, lo;
            la = cyc - acc_cyc[idx];
            lo = cyc - off_cyc[idx];
            lat_acc_sum += la; lat_off_sum += lo;
            if (la > lat_acc_max) lat_acc_max = la;
            if (lo > lat_off_max) lat_off_max = lo;
            lat_acc_hist[(la > 4095) ? 4095 : la]++;
            lat_off_hist[(lo > 4095) ? 4095 : lo]++;
          end
        end
      end
    end
  end

  // ---------------- downstream stream monitors ----------------
  always @(posedge clk) begin
    if (rst_n) begin
      if (mem_req_valid && mem_req_ready) begin
        if (mt_n >= n_mtxn) fail($sformatf("unexpected extra memory transaction (#%0d) line 0x%h", mt_n, mem_req_addr));
        else begin
          if (mem_req_write !== v_twr[mt_n][0])
            fail($sformatf("txn #%0d: write=%b expected %b", mt_n, mem_req_write, v_twr[mt_n][0]));
          if (mem_req_addr !== v_taddr[mt_n])
            fail($sformatf("txn #%0d: addr=0x%h expected 0x%h", mt_n, mem_req_addr, v_taddr[mt_n]));
          if (mem_req_mask !== v_tmask[mt_n])
            fail($sformatf("txn #%0d: mask mismatch\n  dut=%h\n  exp=%h", mt_n, mem_req_mask, v_tmask[mt_n]));
          if (mem_req_write)
            for (int j = 0; j < TXN_BYTES; j++)
              if (v_tmask[mt_n][j] && mem_req_wdata[j*8 +: 8] !== v_tdata[mt_n][j*8 +: 8])
                fail($sformatf("txn #%0d: write data byte %0d dut=%02h exp=%02h", mt_n, j,
                               mem_req_wdata[j*8 +: 8], v_tdata[mt_n][j*8 +: 8]));
        end
        useful_bytes += popcnt(mem_req_mask);
        mt_n <= mt_n + 1;
      end
      if (atm_req_valid && atm_req_ready) begin
        if (at_n >= n_atxn) fail($sformatf("unexpected extra atomic op (#%0d)", at_n));
        else begin
          logic [31:0] xo;
          xo = v_xop[at_n];
          if (atm_req_op !== xo[3:0])             fail($sformatf("atomic #%0d: op=%0d expected %0d", at_n, atm_req_op, xo[3:0]));
          if (atm_req_size !== xo[4 +: SIZE_W])   fail($sformatf("atomic #%0d: size=%0d expected %0d", at_n, atm_req_size, xo[4 +: SIZE_W]));
          if (atm_req_addr !== v_xaddr[at_n])     fail($sformatf("atomic #%0d: addr=0x%h expected 0x%h", at_n, atm_req_addr, v_xaddr[at_n]));
          if (atm_req_a !== v_xa[at_n])           fail($sformatf("atomic #%0d: operand A mismatch", at_n));
          if (atm_req_b !== v_xb[at_n])           fail($sformatf("atomic #%0d: operand B mismatch", at_n));
        end
        at_n <= at_n + 1;
      end
    end
  end

  // ---------------- end-of-test control ----------------
  function automatic int pctl(input int hist[0:4095], input int total, input int pct);
    int acc, tgt;
    acc = 0;
    tgt = (total * pct + 99) / 100;
    for (int i = 0; i < 4096; i++) begin
      acc += hist[i];
      if (acc >= tgt) return i;
    end
    return 4095;
  endfunction

  initial begin : control
    string fpath, tmp;
    int bad_mem, spin;
    int exp_to, exp_late;
    longint lane_bytes_exp;
    wait (rst_n === 1'b1);
    wait (drv_done === 1'b1 || cyc > max_cyc);
    while (cmp_n < n_instr && cyc <= max_cyc) @(posedge clk);
    if (cmp_n < n_instr) begin
      fail($sformatf("LOST REQUESTS: only %0d of %0d completed after %0d cycles", cmp_n, n_instr, cyc));
      begin
        int shown;
        shown = 0;
        for (int i = 0; i < n_instr && shown < 8; i++)
          if (!done_i[i]) begin $display("  uid %0d never completed (accepted=%0b)", i, i < acc_n); shown++; end
      end
    end
    // let slow/late downstream responses and bogus injections drain
    spin = 0;
    while ((ds.live_records() != 0) && spin < 20000) begin @(posedge clk); spin++; end
    repeat (20) @(posedge clk);

    // ---- stream completeness ----
    if (mt_n != n_mtxn) fail($sformatf("memory transactions issued=%0d expected=%0d", mt_n, n_mtxn));
    if (at_n != n_atxn) fail($sformatf("atomic ops issued=%0d expected=%0d", at_n, n_atxn));

    // ---- final memory image ----
    bad_mem = ds.compare_mem({vec_dir, "/mem_final.hex"});
    if (bad_mem != 0) fail($sformatf("final memory differs from golden image in %0d bytes", bad_mem));

    // ---- DUT counters vs observation ----
    if (stat_instr_accepted  != acc_n)        fail($sformatf("stat_instr_accepted=%0d observed=%0d", stat_instr_accepted, acc_n));
    if (stat_instr_completed != cmp_n)        fail($sformatf("stat_instr_completed=%0d observed=%0d", stat_instr_completed, cmp_n));
    if (stat_mem_txns        != mt_n)         fail($sformatf("stat_mem_txns=%0d observed=%0d", stat_mem_txns, mt_n));
    if (stat_mem_useful_bytes != useful_bytes[31:0]) fail($sformatf("stat_mem_useful_bytes=%0d observed=%0d", stat_mem_useful_bytes, useful_bytes));
    if (stat_atm_ops         != at_n)         fail($sformatf("stat_atm_ops=%0d observed=%0d", stat_atm_ops, at_n));
    if (stat_err_instr       != n_err_instr_exp) fail($sformatf("stat_err_instr=%0d expected=%0d", stat_err_instr, n_err_instr_exp));
    if (!idle)                                fail("DUT not idle after all requests completed");
    if (ds_n_errors != 0)                     fail($sformatf("downstream model flagged %0d DUT misbehaviours", ds_n_errors));
    exp_to   = ds_n_hole + ds_n_slow;
    exp_late = ds_n_slow;
    if (TIMEOUT_CYCLES > 0) begin
      if (stat_timeouts != exp_to)            fail($sformatf("stat_timeouts=%0d expected=%0d", stat_timeouts, exp_to));
      if (stat_rsp_late != exp_late)          fail($sformatf("stat_rsp_late=%0d expected=%0d", stat_rsp_late, exp_late));
    end
    if (stat_rsp_spurious != ds_n_dup)        fail($sformatf("stat_rsp_spurious=%0d injected=%0d", stat_rsp_spurious, ds_n_dup));
    if (stat_proto_err != (ds_n_dup != 0))    fail($sformatf("stat_proto_err=%0b (injected duplicates=%0d)", stat_proto_err, ds_n_dup));

    // ---- exactly-once, final accounting ----
    for (int i = 0; i < n_instr; i++) if (!done_i[i]) begin fail($sformatf("uid %0d never completed", i)); break; end
    if (acc_n != n_instr) fail($sformatf("accepted %0d of %0d", acc_n, n_instr));

    // ---- metrics ----
    begin
      int cycles;
      real la, lo;
      cycles = (last_rsp - first_acc) + 1;
      la = n_instr ? real'(lat_acc_sum) / real'(n_instr) : 0.0;
      lo = n_instr ? real'(lat_off_sum) / real'(n_instr) : 0.0;
      lane_bytes_exp = 0;
      $display("METRIC instrs=%0d cycles=%0d mem_txns=%0d atm_ops=%0d useful_bytes=%0d errors_instr=%0d",
               n_instr, cycles, mt_n, at_n, useful_bytes, n_err_instr_exp);
      $display("METRIC lat_acc_avg=%0.3f lat_acc_p50=%0d lat_acc_p95=%0d lat_acc_max=%0d",
               la, pctl(lat_acc_hist, n_instr, 50), pctl(lat_acc_hist, n_instr, 95), lat_acc_max);
      $display("METRIC lat_off_avg=%0.3f lat_off_p50=%0d lat_off_p95=%0d lat_off_max=%0d",
               lo, pctl(lat_off_hist, n_instr, 50), pctl(lat_off_hist, n_instr, 95), lat_off_max);
      $display("METRIC dut_stats accepted=%0d completed=%0d mem_txns=%0d atm_ops=%0d spurious=%0d late=%0d timeouts=%0d proto_err=%0b",
               stat_instr_accepted, stat_instr_completed, stat_mem_txns, stat_atm_ops,
               stat_rsp_spurious, stat_rsp_late, stat_timeouts, stat_proto_err);
    end
    if (errors == 0) begin
      $display("TB_RESULT: PASS (%0d instrs, %0d mem txns, %0d atomic ops, %0d cycles)", n_instr, mt_n, at_n, cyc);
      $finish;
    end else begin
      $display("TB_RESULT: FAIL (%0d errors)", errors);
      $fatal(1, "testbench failed");
    end
  end

  // hard watchdog (independent of the control thread)
  initial begin : watchdog
    wait (cyc > max_cyc + 100000);
    $display("TB_RESULT: FAIL (global watchdog)");
    $fatal(1, "watchdog");
  end

  // toggle the checker's response-id strictness when bogus responses are being injected
  initial begin
    int dpm;
    dpm = 0;
    void'($value$plusargs("DUP_PM=%d", dpm));
    check_rsp_ids = (dpm == 0);
  end

endmodule

`default_nettype wire
