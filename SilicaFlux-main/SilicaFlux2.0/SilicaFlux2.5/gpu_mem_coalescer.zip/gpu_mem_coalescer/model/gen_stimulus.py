#!/usr/bin/env python3
"""
gen_stimulus.py -- generate access streams, run the golden model, and write the
vector files consumed by tb/tb_gpu_coalescer.sv.

Access classes (``--pattern``):
  contiguous  unit-stride warp accesses (aligned, line-aligned, and misaligned starts)
  strided     lane stride of 2..64 elements
  scatter     random per-lane addresses
  overlap     broadcast / pairwise / half-element overlap / dense-in-one-line
  crossing    accesses that straddle transaction (line) boundaries
  atomic      counters, histograms, scatter, CAS ... (separate path)
  hazard      loads/stores/atomics/fences hammering a tiny hot region (ordering stress)
  errors      misaligned atomics, out-of-range, illegal encodings mixed with legal traffic
  mixed       weighted mixture of everything above
  fault       mixed + a downstream error region
  timeout     accesses into hole/slow regions (watchdog test; needs TIMEOUT_CYCLES > 0)

All numbers are written as one hex word per line for $readmemh.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
from typing import Callable, Dict, List, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from coalescer_model import (  # noqa: E402
    AMO_CAS, AMO_LAST, Cfg, Instr, ByteMemory, OP_ATOMIC, OP_FENCE, OP_LOAD, OP_STORE,
    build_txns, execute, f_bytes, txn_stats,
)

MAGIC = 0x0C0A1E5C


class Gen:
    def __init__(self, cfg: Cfg, seed: int):
        self.cfg = cfg
        self.rng = random.Random(seed)
        self.n = cfg.num_lanes
        self.full_be = (1 << cfg.max_acc) - 1

    # ---------------- helpers ---------------- #
    def rdata(self) -> int:
        return self.rng.getrandbits(8 * self.cfg.max_acc)

    def sizes(self, max_size: int = None) -> int:
        cfg = self.cfg
        hi = cfg.log2_acc if max_size is None else min(max_size, cfg.log2_acc)
        return self.rng.choice([0, 1, 2, 2, 2, 3, 3] if hi >= 3 else list(range(hi + 1)) * 2)

    def pick_mask(self) -> int:
        r = self.rng.random()
        full = (1 << self.n) - 1
        if r < 0.6:
            return full
        if r < 0.85:
            return self.rng.getrandbits(self.n) or 1
        if r < 0.93:
            return 1 << self.rng.randrange(self.n)
        if r < 0.97:
            return (full >> self.rng.randrange(self.n)) or 1       # prefix of lanes
        return 0                                                   # zero active lanes

    def pick_be(self) -> List[int]:
        r = self.rng.random()
        if r < 0.8:
            return [self.full_be] * self.n
        if r < 0.9:
            return [self.rng.getrandbits(self.cfg.max_acc) for _ in range(self.n)]
        b = self.rng.getrandbits(self.cfg.max_acc)
        return [b] * self.n

    def finish(self, op: int, size: int, addr: List[int], label: str, amo: int = 0,
               mask: int = None, be: List[int] = None) -> Instr:
        cfg = self.cfg
        ins = Instr.blank(cfg, op, size, amo=amo, label=label)
        ins.addr = [a % (1 << cfg.addr_w) for a in addr]
        ins.mask = self.pick_mask() if mask is None else mask
        ins.be = self.pick_be() if be is None else be
        ins.wdata = [self.rdata() for _ in range(self.n)]
        ins.wdata2 = [self.rdata() for _ in range(self.n)]
        ins.tag = self.rng.getrandbits(8)
        return ins

    def base(self, span: int, align: int = 1) -> int:
        top = max(1, self.cfg.limit - span - 1)
        return (self.rng.randrange(0, top) // align) * align

    def ldst(self) -> int:
        return self.rng.choice([OP_LOAD, OP_LOAD, OP_STORE])

    # ---------------- patterns ---------------- #
    def contiguous(self) -> Instr:
        cfg, n = self.cfg, self.n
        size = self.sizes()
        bsz = 1 << size
        r = self.rng.random()
        span = n * bsz
        if r < 0.35:                                   # line aligned
            base = self.base(span + cfg.txn, cfg.txn)
        elif r < 0.7:                                  # naturally aligned
            base = self.base(span + cfg.txn, bsz)
        else:                                          # arbitrary (may straddle)
            base = self.base(span + cfg.txn)
            if not cfg.allow_misaligned:
                base -= base % bsz
        return self.finish(self.ldst(), size, [base + l * bsz for l in range(n)], "contiguous")

    def strided(self) -> Instr:
        n = self.n
        size = self.sizes()
        bsz = 1 << size
        stride = self.rng.choice([2, 3, 4, 5, 7, 8, 16, 32, 64])
        step = stride * bsz
        base = self.base(n * step + self.cfg.txn, bsz)
        return self.finish(self.ldst(), size, [base + l * step for l in range(n)], f"strided{stride}")

    def scatter(self) -> Instr:
        cfg, n = self.cfg, self.n
        size = self.sizes()
        bsz = 1 << size
        addr = []
        for _ in range(n):
            a = self.rng.randrange(0, cfg.limit - bsz - 1)
            if self.rng.random() < 0.85 or not cfg.allow_misaligned:
                a -= a % bsz
            addr.append(a)
        return self.finish(self.ldst(), size, addr, "scatter")

    def overlap(self) -> Instr:
        cfg, n = self.cfg, self.n
        size = self.sizes()
        bsz = 1 << size
        k = self.rng.randrange(5)
        base = self.base(2 * cfg.txn + 64, bsz)
        if k == 0:
            addr = [base] * n
            label = "overlap-broadcast"
        elif k == 1:
            addr = [base + (l // 2) * bsz for l in range(n)]
            label = "overlap-pairs"
        elif k == 2 and cfg.allow_misaligned and bsz > 1:
            addr = [base + l * (bsz // 2) for l in range(n)]
            label = "overlap-halfstep"
        elif k == 3:
            line = base - base % cfg.txn
            addr = [line + self.rng.randrange(0, cfg.txn // bsz) * bsz for _ in range(n)]
            label = "overlap-dense-line"
        else:
            addr = [base + self.rng.randrange(0, 4) * bsz for _ in range(n)]
            label = "overlap-few"
        op = self.rng.choice([OP_STORE, OP_STORE, OP_LOAD])
        return self.finish(op, size, addr, label)

    def crossing(self) -> Instr:
        cfg, n = self.cfg, self.n
        size = self.rng.choice([1, 2, 3]) if cfg.log2_acc >= 3 else max(1, cfg.log2_acc)
        size = min(size, cfg.log2_acc)
        bsz = 1 << size
        if bsz == 1:
            size, bsz = 1, 2
        nb = max(1, self.rng.choice([1, 1, 2, 4]))
        first_line = self.base(nb * cfg.txn + 2 * cfg.txn, cfg.txn)
        addr = []
        for l in range(n):
            b = first_line + cfg.txn * (1 + (l % nb))
            if cfg.allow_misaligned:
                r = self.rng.randrange(1, bsz)
                a = b - r if self.rng.random() < 0.7 else b - bsz - self.rng.randrange(0, 3)
            else:
                a = b - bsz
            addr.append(a)
        return self.finish(self.ldst(), size, addr, "crossing")

    def atomic(self) -> Instr:
        cfg, n = self.cfg, self.n
        size = self.rng.choice([2, 2, 3, 1, 0]) if cfg.log2_atom >= 3 else self.rng.randrange(cfg.log2_atom + 1)
        size = min(size, cfg.log2_atom)
        bsz = 1 << size
        k = self.rng.randrange(4)
        base = self.base(cfg.txn * 2, 64)
        if k == 0:
            addr = [base] * n
            label = "atomic-counter"
        elif k == 1:
            addr = [base + self.rng.randrange(0, 8) * bsz for _ in range(n)]
            label = "atomic-histogram"
        elif k == 2:
            addr = [base + l * bsz for l in range(n)]
            label = "atomic-contig"
        else:
            addr = []
            for _ in range(n):
                a = self.rng.randrange(0, cfg.limit - bsz - 1)
                addr.append(a - a % bsz)
            label = "atomic-scatter"
        amo = self.rng.randrange(AMO_LAST + 1)
        ins = self.finish(OP_ATOMIC, size, addr, label, amo=amo)
        if amo == AMO_CAS and self.rng.random() < 0.5:       # make some CAS compares hit
            ins.wdata = [self.rng.choice([0, 0x1234, ins.wdata[l]]) for l in range(n)]
        return ins

    def fence(self) -> Instr:
        return self.finish(OP_FENCE, 0, [0] * self.n, "fence", mask=0)

    def hazard(self) -> Instr:
        cfg, n = self.cfg, self.n
        hot = cfg.txn * 2
        size = self.rng.choice([0, 1, 2, 3]) if cfg.log2_acc >= 3 else 1
        size = min(size, cfg.log2_acc)
        bsz = 1 << size
        r = self.rng.random()
        if r < 0.06:
            return self.fence()
        if r < 0.24:
            amo = self.rng.randrange(AMO_LAST + 1)
            a_size = min(self.rng.choice([2, 3]), cfg.log2_atom)
            ab = 1 << a_size
            addr = [(self.rng.randrange(0, hot // ab)) * ab for _ in range(n)]
            return self.finish(OP_ATOMIC, a_size, addr, "hazard-atomic", amo=amo)
        k = self.rng.randrange(3)
        if k == 0:
            addr = [self.rng.randrange(0, hot - bsz) for _ in range(n)]
            if not cfg.allow_misaligned:
                addr = [a - a % bsz for a in addr]
        elif k == 1:
            b = self.rng.randrange(0, hot - n * bsz) if hot > n * bsz else 0
            addr = [b + l * bsz for l in range(n)]
            if not cfg.allow_misaligned:
                addr = [a - a % bsz for a in addr]
        else:
            addr = [self.rng.randrange(0, 4) * bsz for _ in range(n)]
        return self.finish(self.rng.choice([OP_LOAD, OP_STORE]), size, addr, "hazard")

    def errors(self) -> Instr:
        cfg, n = self.cfg, self.n
        r = self.rng.randrange(6)
        if r == 0:                                       # misaligned atomic lane(s)
            ins = self.atomic()
            ins.mask |= 1
            lane = self.rng.randrange(n)
            ins.mask |= 1 << lane
            bsz = f_bytes(cfg, ins.size)
            if bsz > 1:
                ins.addr[lane] = (ins.addr[lane] | 1) if ins.addr[lane] % bsz == 0 else ins.addr[lane]
            ins.label = "err-misaligned-atomic"
            return ins
        if r == 1:                                       # out-of-range lane(s)
            ins = self.contiguous() if self.rng.random() < 0.5 else self.scatter()
            lane = self.rng.randrange(n)
            ins.mask |= 1 << lane
            bsz = f_bytes(cfg, ins.size)
            ins.be[lane] = self.full_be
            ins.addr[lane] = self.rng.choice([cfg.limit, cfg.limit + 4096, cfg.limit - 1,
                                              cfg.limit - bsz + 1, (1 << cfg.addr_w) - 1])
            ins.label = "err-range"
            return ins
        if r == 2:                                       # illegal atomic opcode
            ins = self.atomic()
            ins.amo = self.rng.randrange(AMO_LAST + 1, 16)
            ins.label = "err-illegal-amo"
            return ins
        if r == 3 and (1 << cfg_size_w(cfg)) - 1 > cfg.log2_acc:      # illegal load/store size
            ins = self.contiguous()
            ins.size = self.rng.randrange(cfg.log2_acc + 1, 1 << cfg_size_w(cfg))
            ins.label = "err-illegal-size"
            return ins
        if r == 4 and (1 << cfg_size_w(cfg)) - 1 > cfg.log2_atom:     # illegal atomic size
            ins = self.atomic()
            ins.size = self.rng.randrange(cfg.log2_atom + 1, 1 << cfg_size_w(cfg))
            ins.label = "err-illegal-atomic-size"
            return ins
        if not cfg.allow_misaligned:                     # misaligned load/store
            ins = self.contiguous()
            ins.addr[self.rng.randrange(n)] += 1
            ins.label = "err-misaligned"
            return ins
        return self.scatter()

    def mixed(self) -> Instr:
        fn = self.rng.choices(
            [self.contiguous, self.strided, self.scatter, self.overlap, self.crossing,
             self.atomic, self.hazard, self.errors, self.fence],
            weights=[18, 12, 10, 12, 12, 10, 14, 5, 3])[0]
        return fn()

    def fault(self) -> Instr:
        cfg = self.cfg
        ins = self.mixed()
        if cfg.fault and self.rng.random() < 0.5 and ins.op != OP_FENCE:
            lo, hi = self.rng.choice(cfg.fault)
            lane = self.rng.randrange(self.n)
            ins.mask |= 1 << lane
            ins.addr[lane] = self.rng.randrange(lo, hi - 8)
            ins.be[lane] = self.full_be
        return ins

    def timeout(self) -> Instr:
        """Each hole/slow line is touched at most once per stream (state after a timeout is undefined)."""
        cfg, n = self.cfg, self.n
        ins = self.contiguous() if self.rng.random() < 0.7 else self.scatter()
        if ins.op == OP_FENCE:
            return ins
        lane = self.rng.randrange(n)
        regs = [("hole", r) for r in cfg.hole] + [("slow", r) for r in cfg.slow]
        if regs and self.rng.random() < 0.6:
            avail = [(k, r) for k, r in regs if r not in self._used]
            if avail:
                k, r = self.rng.choice(avail)
                self._used.add(r)
                ins.mask |= 1 << lane
                ins.op = self.rng.choice([OP_LOAD, OP_STORE])
                ins.size = min(ins.size, 2)
                ins.addr[lane] = r[0] + self.rng.randrange(0, (r[1] - r[0]) - 8)
                ins.be[lane] = self.full_be
        return ins

    _used: set = set()


def cfg_size_w(cfg: Cfg) -> int:
    return max(1, cfg.log2_acc.bit_length())


PATTERNS = ["contiguous", "strided", "scatter", "overlap", "crossing", "atomic",
            "hazard", "errors", "mixed", "fault", "timeout"]


def generate(cfg: Cfg, pattern: str, n: int, seed: int) -> List[Instr]:
    g = Gen(cfg, seed)
    g._used = set()
    fn: Callable[[], Instr] = getattr(g, pattern)
    out: List[Instr] = []
    amask = (1 << cfg.addr_w) - 1
    while len(out) < n:
        ins = fn()
        # error injectors may compute addresses wider than ADDR_W; the hardware only ever sees ADDR_W
        # bits, so normalise here so that the model and the vector files describe the same request.
        ins.addr = [a & amask for a in ins.addr]
        out.append(ins)
    return out


# --------------------------------------------------------------------------- #
# Vector writer
# --------------------------------------------------------------------------- #
def hx(v: int, bits: int) -> str:
    return f"{v & ((1 << bits) - 1):0{(bits + 3) // 4}x}"


def write_vectors(outdir: str, cfg: Cfg, instrs: List[Instr], seed: int, mem_bytes: int,
                  pattern: str) -> Dict[str, object]:
    os.makedirs(outdir, exist_ok=True)
    cfg.validate()
    n = cfg.num_lanes
    acc_bits = 8 * cfg.max_acc
    mem0 = ByteMemory(mem_bytes, seed=seed ^ 0x5EED)
    gold = mem0.copy()
    mtx_all, atx_all = [], []
    exp = []
    for i, ins in enumerate(instrs):
        res = execute(ins, cfg, gold)
        exp.append(res)
        t, a = build_txns(ins, cfg, i)
        mtx_all.extend(t)
        atx_all.extend(a)

    def w(name: str, lines: List[str]) -> None:
        with open(os.path.join(outdir, name), "w") as f:
            f.write("\n".join(lines) + ("\n" if lines else ""))

    w("cfg.hex", [hx(v, 32) for v in (MAGIC, n, cfg.addr_w, cfg.max_acc, cfg.txn, int(cfg.coalesce),
                                      int(cfg.allow_misaligned), len(instrs), len(mtx_all),
                                      len(atx_all), cfg.limit & 0xFFFFFFFF, mem_bytes)])
    w("meta.hex", [hx(i.op | (i.size << 2) | (i.amo << 6) | (i.tag << 10), 32) for i in instrs])
    w("mask.hex", [hx(i.mask, 64) for i in instrs])
    w("addr.hex", [hx(a, cfg.addr_w) for i in instrs for a in i.addr])
    w("be.hex", [hx(b, cfg.max_acc) for i in instrs for b in i.be])
    w("wd.hex", [hx(d, acc_bits) for i in instrs for d in i.wdata])
    w("wd2.hex", [hx(d, 8 * cfg.atom_bytes) for i in instrs for d in i.wdata2])
    w("e_err.hex", [hx(r.err, 8) for r in exp])
    w("e_emask.hex", [hx(r.err_mask, 64) for r in exp])
    w("e_rd.hex", [hx(d, acc_bits) for r in exp for d in r.rdata])
    cnt_m = [0] * len(instrs)
    cnt_a = [0] * len(instrs)
    for t in mtx_all:
        cnt_m[t.instr] += 1
    for a in atx_all:
        cnt_a[a.instr] += 1
    w("e_cnt.hex", [hx(cnt_m[i] | (cnt_a[i] << 16), 32) for i in range(len(instrs))])
    w("t_wr.hex", [hx(int(t.write), 4) for t in mtx_all])
    w("t_addr.hex", [hx(t.line, cfg.addr_w) for t in mtx_all])
    w("t_mask.hex", [hx(t.mask, cfg.txn) for t in mtx_all])
    w("t_data.hex", [hx(int.from_bytes(t.data, "little"), 8 * cfg.txn) for t in mtx_all])
    w("t_inst.hex", [hx(t.instr, 32) for t in mtx_all])
    w("x_addr.hex", [hx(a.addr, cfg.addr_w) for a in atx_all])
    w("x_op.hex", [hx(a.amo | (a.size << 4) | (a.lane << 8), 32) for a in atx_all])
    w("x_a.hex", [hx(a.a, 8 * cfg.atom_bytes) for a in atx_all])
    w("x_b.hex", [hx(a.b, 8 * cfg.atom_bytes) for a in atx_all])
    w("x_inst.hex", [hx(a.instr, 32) for a in atx_all])
    w("mem_init.hex", [hx(b, 8) for b in mem0.data])
    w("mem_final.hex", [hx(b, 8) for b in gold.data])

    st = txn_stats(instrs, cfg)
    summary = {
        "pattern": pattern, "seed": seed, "instrs": len(instrs), "mem_instrs": st.mem_instrs,
        "atm_instrs": st.atm_instrs, "mem_txns": st.mem_txns,
        "atm_ops": st.atm_ops, "useful_bytes": st.useful_bytes, "lane_bytes": st.lane_bytes,
        "txns_per_mem_instr": round(st.txns_per_instr, 4),
        "useful_bytes_per_txn": round(st.useful_per_txn, 3),
        "bus_efficiency": round(st.bus_efficiency, 4),
        "coalesce": cfg.coalesce,
    }
    with open(os.path.join(outdir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=1)
    return summary


def parse_range(s: str) -> Tuple[int, int]:
    lo, hi = s.split(":")
    return int(lo, 0), int(hi, 0)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", required=True)
    ap.add_argument("--pattern", default="mixed", choices=PATTERNS)
    ap.add_argument("--n", type=int, default=400)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--lanes", type=int, default=32)
    ap.add_argument("--addr-w", type=int, default=32)
    ap.add_argument("--acc", type=int, default=8, help="MAX_ACC_BYTES")
    ap.add_argument("--txn", type=int, default=128, help="TXN_BYTES")
    ap.add_argument("--coalesce", type=int, default=1)
    ap.add_argument("--misaligned", type=int, default=1)
    ap.add_argument("--limit", type=int, default=65536, help="aperture / memory size in bytes")
    ap.add_argument("--fault", action="append", default=[], help="lo:hi byte range returning errors")
    ap.add_argument("--hole", action="append", default=[], help="lo:hi byte range never responding")
    ap.add_argument("--slow", action="append", default=[], help="lo:hi byte range responding late")
    a = ap.parse_args()
    cfg = Cfg(num_lanes=a.lanes, addr_w=a.addr_w, max_acc=a.acc, txn=a.txn,
              coalesce=bool(a.coalesce), allow_misaligned=bool(a.misaligned), addr_limit=a.limit,
              fault=tuple(parse_range(x) for x in a.fault),
              hole=tuple(parse_range(x) for x in a.hole),
              slow=tuple(parse_range(x) for x in a.slow))
    instrs = generate(cfg, a.pattern, a.n, a.seed)
    summ = write_vectors(a.out, cfg, instrs, a.seed, a.limit, a.pattern)
    print(json.dumps(summ))


if __name__ == "__main__":
    main()
