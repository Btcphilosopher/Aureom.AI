"""
coalescer_model.py -- Python reference model for the GPU memory coalescer.

Three layers, each usable on its own:

  1. ``ByteMemory``        byte-addressed reference memory (sparse-free bytearray).
  2. ``execute``           GOLDEN semantics: each warp instruction executes
                           atomically, in program order, against ByteMemory.
                           This is the architectural contract the RTL must honour.
  3. ``build_txns``        TRANSACTION model: exactly the downstream transactions
                           (and their order) that the RTL emits for an
                           instruction, with or without coalescing.
                           ``execute_via_txns`` runs those transactions against a
                           ByteMemory and must agree with ``execute`` -- that is
                           the proof (exercised by test_model.py) that
                           coalescing preserves the memory semantics.

Architectural semantics (see docs/ARCHITECTURE.md section 3):

  * Lane parts.  A lane access of ``2**size`` bytes at address ``a`` with byte
    enables ``be`` touches the bytes ``a+k`` for every enabled ``k``.  Bytes
    that fall in the aligned line containing ``a`` form the LOW part, bytes that
    spill into the next line form the HIGH part.
  * Store overlap.  When several lanes store to the same byte, the HIGHEST lane
    wins (per byte).
  * Loads return zero in disabled bytes.
  * Atomics execute one lane at a time in ascending lane order; each returns the
    old value; they are never merged and never reordered against overlapping
    ordinary accesses.
  * Errors never write memory for the failing lane; other lanes proceed.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

# --------------------------------------------------------------------------- #
# Constants -- must match rtl/gpu_coalescer_pkg.sv
# --------------------------------------------------------------------------- #
OP_LOAD, OP_STORE, OP_ATOMIC, OP_FENCE = 0, 1, 2, 3
OP_NAMES = {OP_LOAD: "LOAD", OP_STORE: "STORE", OP_ATOMIC: "ATOMIC", OP_FENCE: "FENCE"}

AMO_ADD, AMO_AND, AMO_OR, AMO_XOR, AMO_MIN, AMO_MAX, AMO_MINU, AMO_MAXU, AMO_EXCH, AMO_CAS = range(10)
AMO_LAST = 9

ERR_ILLEGAL = 1 << 0
ERR_ALIGN = 1 << 1
ERR_RANGE = 1 << 2
ERR_DOWNSTREAM = 1 << 3
ERR_TIMEOUT = 1 << 4
ERR_NAMES = [(ERR_ILLEGAL, "ILLEGAL"), (ERR_ALIGN, "ALIGN"), (ERR_RANGE, "RANGE"),
             (ERR_DOWNSTREAM, "DOWNSTREAM"), (ERR_TIMEOUT, "TIMEOUT")]


def err_str(e: int) -> str:
    return "|".join(n for b, n in ERR_NAMES if e & b) or "OK"


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
@dataclass
class Cfg:
    num_lanes: int = 32
    addr_w: int = 32
    max_acc: int = 8            # widest per-lane access in bytes
    txn: int = 128              # aligned transaction size in bytes
    coalesce: bool = True       # False => uncoalesced baseline
    allow_misaligned: bool = True
    addr_limit: int = 65536     # exclusive aperture bound; 0 => 2**addr_w
    # Downstream fault injection (byte ranges, must be multiples of ``txn``)
    fault: Tuple[Tuple[int, int], ...] = ()   # downstream returns an error status
    hole: Tuple[Tuple[int, int], ...] = ()    # downstream never performs / never responds
    slow: Tuple[Tuple[int, int], ...] = ()    # downstream performs but responds after the watchdog

    @property
    def log2_txn(self) -> int:
        return self.txn.bit_length() - 1

    @property
    def log2_acc(self) -> int:
        return self.max_acc.bit_length() - 1

    @property
    def atom_bytes(self) -> int:
        return min(8, self.max_acc)

    @property
    def log2_atom(self) -> int:
        return self.atom_bytes.bit_length() - 1

    @property
    def limit(self) -> int:
        return self.addr_limit or (1 << self.addr_w)

    @property
    def size_w(self) -> int:
        """Width of the req_size field: clog2(log2_acc + 1), at least 1 (matches SIZE_W in the RTL)."""
        return max(1, self.log2_acc.bit_length())

    def validate(self) -> None:
        assert self.max_acc >= 2 and self.max_acc & (self.max_acc - 1) == 0
        assert self.txn >= self.max_acc and self.txn & (self.txn - 1) == 0
        for r in self.fault + self.hole + self.slow:
            assert r[0] % self.txn == 0 and r[1] % self.txn == 0, "fault regions are line granular"

    def ds_status(self, line_addr: int) -> str:
        """Downstream behaviour for the aligned line starting at ``line_addr``."""
        for lo, hi in self.fault:
            if lo <= line_addr < hi:
                return "fault"
        for lo, hi in self.hole:
            if lo <= line_addr < hi:
                return "hole"
        for lo, hi in self.slow:
            if lo <= line_addr < hi:
                return "slow"
        return "ok"


# --------------------------------------------------------------------------- #
# Byte-addressed reference memory
# --------------------------------------------------------------------------- #
class ByteMemory:
    """Flat byte-addressed memory over ``[0, size)``."""

    def __init__(self, size: int, seed: Optional[int] = 1):
        self.size = size
        if seed is None:
            self.data = bytearray(size)
        else:
            rng = random.Random(seed)
            self.data = bytearray(rng.getrandbits(8) for _ in range(size))

    def copy(self) -> "ByteMemory":
        m = ByteMemory.__new__(ByteMemory)
        m.size = self.size
        m.data = bytearray(self.data)
        return m

    def read_byte(self, a: int) -> int:
        return self.data[a]

    def write_byte(self, a: int, v: int) -> None:
        self.data[a] = v & 0xFF

    def read(self, a: int, n: int) -> int:
        """Little-endian read of ``n`` bytes."""
        return int.from_bytes(self.data[a:a + n], "little")

    def write(self, a: int, n: int, v: int) -> None:
        self.data[a:a + n] = (v & ((1 << (8 * n)) - 1)).to_bytes(n, "little")

    def __eq__(self, other: object) -> bool:
        return isinstance(other, ByteMemory) and self.data == other.data


# --------------------------------------------------------------------------- #
# Instruction / result containers
# --------------------------------------------------------------------------- #
@dataclass
class Instr:
    op: int
    size: int = 2                      # log2(bytes per lane access)
    amo: int = 0
    mask: int = 0                      # active-lane bit mask
    tag: int = 0
    addr: List[int] = field(default_factory=list)
    be: List[int] = field(default_factory=list)      # per-lane byte enables (bit k = byte k)
    wdata: List[int] = field(default_factory=list)   # store data / atomic operand A
    wdata2: List[int] = field(default_factory=list)  # atomic operand B
    label: str = ""

    @staticmethod
    def blank(cfg: Cfg, op: int, size: int = 2, **kw) -> "Instr":
        n = cfg.num_lanes
        return Instr(op=op, size=size, addr=[0] * n, be=[(1 << cfg.max_acc) - 1] * n,
                     wdata=[0] * n, wdata2=[0] * n, **kw)


@dataclass
class Result:
    rdata: List[int]
    err: int
    err_mask: int


# --------------------------------------------------------------------------- #
# Per-instruction analysis (mirrors the accept-path logic in the RTL)
# --------------------------------------------------------------------------- #
def f_bytes(cfg: Cfg, size: int) -> int:
    return cfg.max_acc if size > cfg.log2_acc else (1 << size)


def is_illegal(instr: Instr, cfg: Cfg) -> bool:
    if instr.op in (OP_LOAD, OP_STORE):
        return instr.size > cfg.log2_acc
    if instr.op == OP_ATOMIC:
        return instr.size > cfg.log2_atom or instr.amo > AMO_LAST
    return False


@dataclass
class Analysis:
    illegal: bool
    be_eff: List[int]
    has: List[bool]
    al_bad: List[bool]
    rg_bad: List[bool]
    lane_ok: List[bool]
    pend_lo: List[bool]
    pend_hi: List[bool]
    err: int
    err_mask: int


def analyze(instr: Instr, cfg: Cfg) -> Analysis:
    n = cfg.num_lanes
    bsz = f_bytes(cfg, instr.size)
    full = (1 << bsz) - 1
    illegal = is_illegal(instr, cfg)
    is_mem = instr.op in (OP_LOAD, OP_STORE, OP_ATOMIC)
    be_eff, has, al, rg, ok, plo, phi = [], [], [], [], [], [], []
    for l in range(n):
        a = instr.addr[l]
        be = full if instr.op == OP_ATOMIC else (instr.be[l] & full)
        h = be != 0
        off = a % cfg.txn
        lo_n = bsz if off + bsz <= cfg.txn else cfg.txn - off
        lo_ex = (be & ((1 << lo_n) - 1)) != 0
        hi_ex = (be >> lo_n) != 0
        a_bad = (instr.op == OP_ATOMIC or not cfg.allow_misaligned) and (a & (bsz - 1)) != 0
        last = be.bit_length() - 1 if be else 0
        r_bad = (a + last) >= cfg.limit
        lane_ok = is_mem and not illegal and bool((instr.mask >> l) & 1) and h and not a_bad and not r_bad
        be_eff.append(be)
        has.append(h)
        al.append(a_bad)
        rg.append(r_bad)
        ok.append(lane_ok)
        plo.append(lane_ok and lo_ex)
        phi.append(lane_ok and hi_ex and instr.op != OP_ATOMIC)
    err, errm = 0, 0
    if illegal:
        err = ERR_ILLEGAL
        errm = instr.mask
    elif is_mem:
        for l in range(n):
            m = (instr.mask >> l) & 1 and has[l]
            if m and al[l]:
                err |= ERR_ALIGN
            if m and rg[l]:
                err |= ERR_RANGE
            if m and (al[l] or rg[l]):
                errm |= 1 << l
    return Analysis(illegal, be_eff, has, al, rg, ok, plo, phi, err, errm)


def amo_apply(op: int, old: int, a: int, b: int, nbytes: int) -> int:
    """Atomic ALU: returns the new memory value.  Operands are truncated to ``nbytes``."""
    bits = 8 * nbytes
    m = (1 << bits) - 1
    old &= m
    a &= m
    b &= m

    def s(x: int) -> int:
        return x - (1 << bits) if (x >> (bits - 1)) & 1 else x

    if op == AMO_ADD:
        return (old + a) & m
    if op == AMO_AND:
        return old & a
    if op == AMO_OR:
        return old | a
    if op == AMO_XOR:
        return old ^ a
    if op == AMO_MIN:
        return old if s(old) <= s(a) else a
    if op == AMO_MAX:
        return old if s(old) >= s(a) else a
    if op == AMO_MINU:
        return min(old, a)
    if op == AMO_MAXU:
        return max(old, a)
    if op == AMO_EXCH:
        return a
    if op == AMO_CAS:
        return b if old == a else old
    raise ValueError(f"bad amo {op}")


def _line_of(cfg: Cfg, a: int) -> int:
    return a - (a % cfg.txn)


# --------------------------------------------------------------------------- #
# GOLDEN semantics
# --------------------------------------------------------------------------- #
def execute(instr: Instr, cfg: Cfg, mem: ByteMemory) -> Result:
    """Execute one instruction atomically against ``mem`` (the architectural contract)."""
    an = analyze(instr, cfg)
    n = cfg.num_lanes
    rdata = [0] * n
    err, errm = an.err, an.err_mask
    if instr.op == OP_FENCE or an.illegal:
        return Result(rdata, err, errm)
    bsz = f_bytes(cfg, instr.size)

    def note(l: int, status: str) -> None:
        nonlocal err, errm
        if status == "fault":
            err |= ERR_DOWNSTREAM
            errm |= 1 << l
        elif status in ("hole", "slow"):
            err |= ERR_TIMEOUT
            errm |= 1 << l

    if instr.op == OP_LOAD:
        for l in range(n):
            if not an.lane_ok[l]:
                continue
            for k in range(bsz):
                if (an.be_eff[l] >> k) & 1:
                    a = instr.addr[l] + k
                    st = cfg.ds_status(_line_of(cfg, a))
                    if st == "ok":
                        rdata[l] |= mem.read_byte(a) << (8 * k)
                    else:
                        note(l, st)
    elif instr.op == OP_STORE:
        for l in range(n):                       # ascending lanes: highest lane wins
            if not an.lane_ok[l]:
                continue
            for k in range(bsz):
                if (an.be_eff[l] >> k) & 1:
                    a = instr.addr[l] + k
                    st = cfg.ds_status(_line_of(cfg, a))
                    if st in ("ok", "slow"):
                        mem.write_byte(a, (instr.wdata[l] >> (8 * k)) & 0xFF)
                    if st != "ok":
                        note(l, st)
    elif instr.op == OP_ATOMIC:
        for l in range(n):                       # ascending lanes
            if not an.lane_ok[l]:
                continue
            a = instr.addr[l]
            st = cfg.ds_status(_line_of(cfg, a))
            if st in ("ok", "slow"):
                old = mem.read(a, bsz)
                mem.write(a, bsz, amo_apply(instr.amo, old, instr.wdata[l], instr.wdata2[l], bsz))
                rdata[l] = old
            if st != "ok":
                note(l, st)
    return Result(rdata, err, errm)


# --------------------------------------------------------------------------- #
# TRANSACTION model (what the RTL emits)
# --------------------------------------------------------------------------- #
@dataclass
class Txn:
    write: bool
    line: int                  # byte address, aligned to cfg.txn
    mask: int                  # TXN_BYTES-bit byte mask
    data: bytes                # TXN_BYTES bytes (zeros where mask is clear; zeros for loads)
    lanes_lo: int              # lane bitmask served via the LOW part
    lanes_hi: int              # lane bitmask served via the HIGH part
    instr: int = 0

    @property
    def useful_bytes(self) -> int:
        return bin(self.mask).count("1")


@dataclass
class AtomOp:
    lane: int
    amo: int
    size: int
    addr: int
    a: int
    b: int
    instr: int = 0


def build_txns(instr: Instr, cfg: Cfg, idx: int = 0) -> Tuple[List[Txn], List[AtomOp]]:
    """Downstream operations for ``instr`` in the exact order the RTL issues them."""
    an = analyze(instr, cfg)
    n = cfg.num_lanes
    bsz = f_bytes(cfg, instr.size)
    if instr.op == OP_FENCE or an.illegal:
        return [], []
    plo = list(an.pend_lo)
    phi = list(an.pend_hi)

    if instr.op == OP_ATOMIC:
        ops = []
        for l in range(n):
            if plo[l]:
                m = (1 << (8 * bsz)) - 1
                ops.append(AtomOp(l, instr.amo, instr.size, instr.addr[l],
                                  instr.wdata[l] & m, instr.wdata2[l] & m, idx))
        return [], ops

    txns: List[Txn] = []
    while any(plo) or any(phi):
        # leader: lowest lane with a pending part, low part first
        ldr = next(l for l in range(n) if plo[l] or phi[l])
        ldr_hi = not plo[ldr]
        base_line = _line_of(cfg, instr.addr[ldr])
        line = base_line + cfg.txn if ldr_hi else base_line
        m_lo = [False] * n
        m_hi = [False] * n
        if cfg.coalesce:
            for l in range(n):
                ll = _line_of(cfg, instr.addr[l])
                m_lo[l] = plo[l] and ll == line
                m_hi[l] = phi[l] and ll + cfg.txn == line
        else:
            (m_hi if ldr_hi else m_lo)[ldr] = True
        mask = 0
        data = bytearray(cfg.txn)
        for l in range(n):                       # ascending lanes: highest lane wins
            if not (m_lo[l] or m_hi[l]):
                continue
            off = instr.addr[l] % cfg.txn
            for k in range(bsz):
                if not (an.be_eff[l] >> k) & 1:
                    continue
                j = off + k
                if m_lo[l] and j < cfg.txn:
                    pos = j
                elif m_hi[l] and j >= cfg.txn:
                    pos = j - cfg.txn
                else:
                    continue
                mask |= 1 << pos
                if instr.op == OP_STORE:
                    data[pos] = (instr.wdata[l] >> (8 * k)) & 0xFF
        lo_m = sum(1 << l for l in range(n) if m_lo[l])
        hi_m = sum(1 << l for l in range(n) if m_hi[l])
        txns.append(Txn(instr.op == OP_STORE, line, mask, bytes(data), lo_m, hi_m, idx))
        for l in range(n):
            if m_lo[l]:
                plo[l] = False
            if m_hi[l]:
                phi[l] = False
    return txns, []


def execute_via_txns(instr: Instr, cfg: Cfg, mem: ByteMemory) -> Result:
    """Run the transaction list against ``mem`` as an ideal in-order downstream and
    assemble read data exactly as the RTL's response path does."""
    an = analyze(instr, cfg)
    n = cfg.num_lanes
    rdata = [0] * n
    err, errm = an.err, an.err_mask
    txns, aops = build_txns(instr, cfg)
    bsz = f_bytes(cfg, instr.size)
    for t in txns:
        st = cfg.ds_status(t.line)
        lanes = t.lanes_lo | t.lanes_hi
        if st != "ok" and st != "slow":
            err |= ERR_DOWNSTREAM if st == "fault" else ERR_TIMEOUT
            errm |= lanes
            continue
        if st == "slow":
            err |= ERR_TIMEOUT
            errm |= lanes
        if t.write:
            for j in range(cfg.txn):
                if (t.mask >> j) & 1:
                    mem.write_byte(t.line + j, t.data[j])
        elif st == "ok":
            line_bytes = bytes(mem.data[t.line:t.line + cfg.txn])
            for l in range(n):
                off = instr.addr[l] % cfg.txn
                for k in range(bsz):
                    if not (an.be_eff[l] >> k) & 1:
                        continue
                    j = off + k
                    if (t.lanes_lo >> l) & 1 and j < cfg.txn:
                        rdata[l] |= line_bytes[j] << (8 * k)
                    if (t.lanes_hi >> l) & 1 and j >= cfg.txn:
                        rdata[l] |= line_bytes[j - cfg.txn] << (8 * k)
    for op in aops:
        st = cfg.ds_status(_line_of(cfg, op.addr))
        if st in ("ok", "slow"):
            old = mem.read(op.addr, bsz)
            mem.write(op.addr, bsz, amo_apply(op.amo, old, op.a, op.b, bsz))
            rdata[op.lane] = old
        if st == "fault":
            err |= ERR_DOWNSTREAM
            errm |= 1 << op.lane
        elif st != "ok":
            err |= ERR_TIMEOUT
            errm |= 1 << op.lane
    return Result(rdata, err, errm)


# --------------------------------------------------------------------------- #
# Static (functional) metrics
# --------------------------------------------------------------------------- #
@dataclass
class TxnStats:
    instrs: int = 0            # all instructions
    mem_instrs: int = 0        # loads + stores that generated >= 1 transaction
    atm_instrs: int = 0
    mem_txns: int = 0
    atm_ops: int = 0
    useful_bytes: int = 0      # bytes actually requested (sum of mask popcounts)
    txn_capacity: int = 0      # mem_txns * cfg.txn
    lane_bytes: int = 0        # bytes requested by lanes (before merging)

    @property
    def txns_per_instr(self) -> float:
        return self.mem_txns / self.mem_instrs if self.mem_instrs else 0.0

    @property
    def useful_per_txn(self) -> float:
        return self.useful_bytes / self.mem_txns if self.mem_txns else 0.0

    @property
    def bus_efficiency(self) -> float:
        return self.useful_bytes / self.txn_capacity if self.txn_capacity else 0.0

    @property
    def atm_per_instr(self) -> float:
        return self.atm_ops / self.atm_instrs if self.atm_instrs else 0.0


def txn_stats(instrs: Sequence[Instr], cfg: Cfg) -> TxnStats:
    s = TxnStats()
    for i, ins in enumerate(instrs):
        s.instrs += 1
        txns, aops = build_txns(ins, cfg, i)
        if txns:
            s.mem_instrs += 1
        if aops:
            s.atm_instrs += 1
        s.mem_txns += len(txns)
        s.atm_ops += len(aops)
        s.useful_bytes += sum(t.useful_bytes for t in txns)
        s.txn_capacity += len(txns) * cfg.txn
        an = analyze(ins, cfg)
        if ins.op in (OP_LOAD, OP_STORE):
            s.lane_bytes += sum(bin(an.be_eff[l]).count("1") for l in range(cfg.num_lanes) if an.lane_ok[l])
    return s
