"""
test_model.py -- self-tests for the Python reference model.

Run:  python3 -m pytest -q model/test_model.py        (or: python3 model/test_model.py)

The central property is TRANSACTION-LEVEL EQUIVALENCE: for every generated
instruction stream, running the transaction list that the RTL would emit
(`execute_via_txns`) against a byte memory yields exactly the same read data,
error flags, error lanes and final memory as the golden per-instruction
semantics (`execute`) -- for the coalesced design AND the uncoalesced baseline.
"""
import itertools
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from coalescer_model import (  # noqa: E402
    AMO_ADD, AMO_CAS, AMO_MAX, AMO_MIN, AMO_MAXU, ByteMemory, Cfg, Instr, OP_ATOMIC, OP_LOAD,
    OP_STORE, ERR_ALIGN, ERR_RANGE, ERR_ILLEGAL, amo_apply, build_txns, execute,
    execute_via_txns, txn_stats,
)
from gen_stimulus import PATTERNS, generate  # noqa: E402

CONFIGS = [
    dict(num_lanes=32, max_acc=8, txn=128),
    dict(num_lanes=32, max_acc=8, txn=32),
    dict(num_lanes=8, max_acc=16, txn=64),
    dict(num_lanes=4, max_acc=4, txn=16),
    dict(num_lanes=16, max_acc=8, txn=64, allow_misaligned=False),
]


def run_equivalence(cfg: Cfg, pattern: str, n: int, seed: int) -> None:
    instrs = generate(cfg, pattern, n, seed)
    m_gold = ByteMemory(cfg.limit, seed=seed)
    m_txn = m_gold.copy()
    for i, ins in enumerate(instrs):
        g = execute(ins, cfg, m_gold)
        t = execute_via_txns(ins, cfg, m_txn)
        ctx = f"cfg={cfg} pattern={pattern} seed={seed} instr#{i} {ins.label}"
        assert g.err == t.err, ctx
        assert g.err_mask == t.err_mask, ctx
        for l in range(cfg.num_lanes):
            if not (g.err_mask >> l) & 1:
                assert g.rdata[l] == t.rdata[l], f"{ctx} lane {l}"
    assert m_gold == m_txn, f"final memory mismatch: cfg={cfg} pattern={pattern} seed={seed}"


def test_transaction_level_equivalence():
    for kw, coal in itertools.product(CONFIGS, (True, False)):
        cfg = Cfg(coalesce=coal, addr_limit=8192, **kw)
        for pat in PATTERNS:
            if pat in ("timeout",):
                continue
            c = cfg
            if pat == "fault":
                c = Cfg(coalesce=coal, addr_limit=8192, fault=((1024, 1024 + 2 * cfg.txn),), **kw)
            for seed in (1, 2):
                run_equivalence(c, pat, 60, seed)


def test_equivalence_with_timeout_regions():
    cfg = Cfg(addr_limit=8192, hole=((2048, 2048 + 256),), slow=((4096, 4096 + 256),))
    run_equivalence(cfg, "timeout", 80, 3)


# ------------------------------------------------------------------ directed
def mk(cfg, op, size, addrs, mask=None, be=None, wd=None):
    ins = Instr.blank(cfg, op, size)
    ins.addr = list(addrs) + [0] * (cfg.num_lanes - len(addrs))
    ins.mask = (1 << len(addrs)) - 1 if mask is None else mask
    if be is not None:
        ins.be = be
    if wd is not None:
        ins.wdata = wd + [0] * (cfg.num_lanes - len(wd))
    return ins


def test_contiguous_is_one_transaction():
    cfg = Cfg(addr_limit=1 << 16)
    ins = mk(cfg, OP_LOAD, 2, [256 + 4 * l for l in range(32)])
    t, a = build_txns(ins, cfg)
    assert len(t) == 1 and not a and t[0].line == 256 and t[0].mask == (1 << 128) - 1
    base = Cfg(addr_limit=1 << 16, coalesce=False)
    assert len(build_txns(ins, base)[0]) == 32


def test_stride_one_line_per_lane():
    cfg = Cfg(addr_limit=1 << 16)
    ins = mk(cfg, OP_LOAD, 2, [128 * l for l in range(32)])
    assert len(build_txns(ins, cfg)[0]) == 32


def test_boundary_crossing_splits_into_two_parts():
    cfg = Cfg(addr_limit=1 << 16)
    ins = mk(cfg, OP_STORE, 3, [128 - 3], wd=[0x8877665544332211])
    t, _ = build_txns(ins, cfg)
    assert [(x.line, x.mask) for x in t] == [(0, 0b111 << 125), (128, 0b11111)]
    assert t[0].data[125:128] == bytes([0x11, 0x22, 0x33]) and t[1].data[0:5] == bytes([0x44, 0x55, 0x66, 0x77, 0x88])
    assert t[0].lanes_lo == 1 and t[1].lanes_hi == 1


def test_adjacent_lanes_share_a_boundary_transaction():
    cfg = Cfg(addr_limit=1 << 16)
    # lane 0 crosses 128; lane 1 sits wholly in the next line -> 2 txns, hi part of lane 0 merged with lane 1
    ins = mk(cfg, OP_LOAD, 3, [124, 132])
    t, _ = build_txns(ins, cfg)
    assert len(t) == 2
    assert t[1].lanes_hi == 1 and t[1].lanes_lo == 2


def test_overlapping_store_highest_lane_wins():
    cfg = Cfg(addr_limit=1 << 16)
    ins = mk(cfg, OP_STORE, 2, [64, 64, 66], wd=[0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC])
    m = ByteMemory(1 << 16, seed=None)
    execute(ins, cfg, m)
    assert bytes(m.data[64:70]) == bytes([0xBB, 0xBB, 0xCC, 0xCC, 0xCC, 0xCC])
    t, _ = build_txns(ins, cfg)
    assert len(t) == 1 and t[0].data[64 % 128:70 % 128] == bytes([0xBB, 0xBB, 0xCC, 0xCC, 0xCC, 0xCC])
    m2 = ByteMemory(1 << 16, seed=None)
    execute_via_txns(ins, cfg, m2)
    assert m == m2


def test_byte_enables_and_zero_fill():
    cfg = Cfg(addr_limit=1 << 16)
    be = [0b0101] + [0xFF] * 31
    ld = mk(cfg, OP_LOAD, 2, [8], be=be)
    m = ByteMemory(1 << 16, seed=7)
    r = execute(ld, cfg, m)
    exp = (m.data[8] | (m.data[10] << 16))
    assert r.rdata[0] == exp
    st = mk(cfg, OP_STORE, 2, [8], be=be, wd=[0xDDCCBBAA])
    before = bytes(m.data[8:12])
    execute(st, cfg, m)
    assert bytes(m.data[8:12]) == bytes([0xAA, before[1], 0xCC, before[3]])


def test_atomics_are_never_merged():
    cfg = Cfg(addr_limit=1 << 16)
    ins = Instr.blank(cfg, OP_ATOMIC, 2, amo=AMO_ADD)
    ins.addr = [512] * 32
    ins.mask = (1 << 32) - 1
    ins.wdata = [1] * 32
    t, a = build_txns(ins, cfg)
    assert t == [] and [x.lane for x in a] == list(range(32))
    m = ByteMemory(1 << 16, seed=None)
    r = execute(ins, cfg, m)
    assert m.read(512, 4) == 32 and r.rdata == list(range(32))        # each lane sees the running total


def test_amo_alu():
    assert amo_apply(AMO_MIN, 0xFFFFFFFF, 1, 0, 4) == 0xFFFFFFFF      # -1 < 1 (signed)
    assert amo_apply(AMO_MAXU, 0xFFFFFFFF, 1, 0, 4) == 0xFFFFFFFF
    assert amo_apply(AMO_MAX, 0xFFFFFFFF, 1, 0, 4) == 1
    assert amo_apply(AMO_CAS, 5, 5, 9, 4) == 9 and amo_apply(AMO_CAS, 5, 6, 9, 4) == 5
    assert amo_apply(AMO_ADD, 0xFF, 1, 0, 1) == 0                      # wraps at the access width


def test_error_classes():
    cfg = Cfg(addr_limit=4096)
    a = Instr.blank(cfg, OP_ATOMIC, 2, amo=AMO_ADD)
    a.addr = [1] + [0] * 31
    a.mask = 1
    r = execute(a, cfg, ByteMemory(4096, seed=None))
    assert r.err == ERR_ALIGN and r.err_mask == 1
    o = mk(cfg, OP_LOAD, 2, [4094, 100])
    r = execute(o, cfg, ByteMemory(4096, seed=None))
    assert r.err == ERR_RANGE and r.err_mask == 1
    il = Instr.blank(cfg, OP_ATOMIC, 2, amo=12)
    il.mask = 0b110
    r = execute(il, cfg, ByteMemory(4096, seed=None))
    assert r.err == ERR_ILLEGAL and r.err_mask == 0b110
    # erroring lanes never write; healthy lanes do
    st = mk(cfg, OP_STORE, 2, [4094, 16], wd=[0x11111111, 0x22222222])
    m = ByteMemory(4096, seed=None)
    r = execute(st, cfg, m)
    assert m.read(16, 4) == 0x22222222 and m.data[4094] == 0 and m.data[4095] == 0


def test_coalescing_never_increases_transactions():
    for kw in CONFIGS:
        base = Cfg(coalesce=False, addr_limit=8192, **kw)
        coal = Cfg(coalesce=True, addr_limit=8192, **kw)
        for pat in ("contiguous", "strided", "scatter", "overlap", "crossing", "mixed"):
            ins = generate(coal, pat, 80, 5)
            sc, sb = txn_stats(ins, coal), txn_stats(ins, base)
            assert sc.mem_txns <= sb.mem_txns, (kw, pat)
            assert sc.useful_bytes <= sb.useful_bytes, (kw, pat)   # merging overlap can only shrink useful bytes
            assert sc.atm_ops == sb.atm_ops                        # atomics identical on both paths


if __name__ == "__main__":
    import pytest
    sys.exit(pytest.main([__file__, "-q"]))
