#!/usr/bin/env bash
# =============================================================================
# run_formal.sh -- unbounded safety proof of the "exactly once" accounting for a
#                  tiny geometry, using Yosys' built-in SAT engine (no external solver).
#
#   needs:  yowasp-yosys   (pip install yowasp-yosys)  -- or any Yosys with the slang
#           front end; override with  YOSYS="yosys -m slang"  (see formal/README.md)
#
#   usage:  formal/run_formal.sh [BMC_DEPTH]          (default depth 12, ~1.5 min)
#
# Steps
#   1 base case      BMC from reset to depth D: f_prop holds
#   2 induction      1-induction step from an ARBITRARY state: f_prop holds   => unbounded proof
#   3 non-vacuity    a load/store and an atomic can each be accepted, issued and completed
#                    end-to-end under the assumptions; spurious responses are admissible
#   4 mutants        two injected accounting bugs must yield counterexamples
#   5 variants       watchdog on, in-order upstream/downstream, baseline, strict alignment, odd resources
# =============================================================================
set -u
cd "$(dirname "$0")/.."
YOSYS=${YOSYS:-yowasp-yosys}
D=${1:-12}
W=build/formal
mkdir -p "$W"
GEOM="-G NUM_LANES=2 -G ADDR_W=6 -G MAX_ACC_BYTES=4 -G TXN_BYTES=8 -G NUM_INSTR_SLOTS=2 -G NUM_MEM_TAGS=2 -G NUM_ATM_TAGS=2 -G UID_W=8 -G ADDR_LIMIT=64"
FAILS=0

# sat_run <name> <extra -D flags> <sat arguments> <expect: proved|cex|model> [extra -G overrides]
sat_run() {
  local name=$1 defs=$2 satargs=$3 expect=$4 gextra=${5:-}
  cat > "$W/$name.ys" <<EOS
read_slang -j 1 --top gpu_coalescer -DFORMAL $defs $GEOM $gextra rtl/gpu_coalescer_pkg.sv rtl/gpu_coalescer.sv
hierarchy -top gpu_coalescer
proc
flatten
opt -fast
memory_map
opt -fast
async2sync
dffunmap
opt_clean
sat $satargs
EOS
  local t0=$(date +%s)
  $YOSYS -l "$W/$name.log" "$W/$name.ys" > /dev/null 2>&1
  local dt=$(( $(date +%s) - t0 )) got="error"
  if   grep -q "SAT proof finished - no model found" "$W/$name.log"; then got="proved"
  elif grep -q "SAT proof finished - model found"    "$W/$name.log"; then got="cex"
  elif grep -q "SAT solving finished - model found"  "$W/$name.log"; then got="model"
  elif grep -q "SAT solving finished - no model"     "$W/$name.log"; then got="nomodel"; fi
  local verdict="OK  "; [ "$got" = "$expect" ] || { verdict="FAIL"; FAILS=$((FAILS+1)); }
  printf "  [%s] %-34s expected=%-6s got=%-6s (%ss)\n" "$verdict" "$name" "$expect" "$got" "$dt"
}

echo "geometry: 2 lanes, 4-byte accesses, 8-byte transactions, 2 slots, 2+2 tags, 8-bit uid"
echo "1. base case: bounded model check from reset, depth $D"
sat_run base_bmc "" "-verify -prove f_prop 1 -set-at 1 rst_n 0 -prove-skip 1 -seq $D" proved
echo "2. induction step (arbitrary start state, property assumed in the previous step)"
sat_run induction_k1 "" "-verify -prove f_prop 1 -set-at 1 f_prop 1 -prove-skip 1 -seq 2" proved
sat_run induction_k2 "" "-verify -prove f_prop 1 -set-at 1 f_prop 1 -set-at 2 f_prop 1 -prove-skip 2 -seq 3" proved
echo "3. non-vacuity (a satisfying trace must exist)"
sat_run cover_loadstore "" "-set-at 1 rst_n 0 -set-at 12 rsp_fire 1 -set-at 12 c_acc_q 1 -set-at 12 c_cmp_q 0 -set-at 12 c_mtx_q 1 -set-at 12 c_aop_q 0 -set-at 12 f_env_ok_q 1 -seq 12" model
sat_run cover_atomic    "" "-set-at 1 rst_n 0 -set-at 12 rsp_fire 1 -set-at 12 c_acc_q 1 -set-at 12 c_cmp_q 0 -set-at 12 c_aop_q 1 -set-at 12 c_mtx_q 0 -set-at 12 f_env_ok_q 1 -seq 12" model
sat_run cover_spurious  "" "-set-at 1 rst_n 0 -set-at 12 c_spur_q 1 -set-at 12 f_env_ok_q 1 -seq 12" model
echo "4. mutants must be refuted"
sat_run mutant_early_complete "-DMUT_EARLY_COMPLETE"       "-verify -prove f_prop 1 -set-at 1 rst_n 0 -prove-skip 1 -seq $D" cex
sat_run mutant_no_spur_filter "-DMUT_NO_SPURIOUS_FILTER"   "-verify -prove f_prop 1 -set-at 1 rst_n 0 -prove-skip 1 -seq $D" cex

echo "5. design variants: reset base case (depth 4) + unbounded induction step"
variant() { # name, -G overrides
  sat_run "$1_base"      "" "-verify -prove f_prop 1 -set-at 1 rst_n 0 -prove-skip 1 -seq 4" proved "$2"
  sat_run "$1_induction" "" "-verify -prove f_prop 1 -set-at 1 f_prop 1 -prove-skip 1 -seq 2" proved "$2"
}
variant watchdog3   "-G TIMEOUT_CYCLES=3"
sat_run watchdog3_cover_timeout "" "-set-at 1 rst_n 0 -set-at 14 c_to_q 1 -set-at 14 f_env_ok_q 1 -seq 14" model "-G TIMEOUT_CYCLES=3"
sat_run watchdog3_cover_late    "" "-set-at 1 rst_n 0 -set-at 16 c_late_q 1 -set-at 16 f_env_ok_q 1 -seq 16" model "-G TIMEOUT_CYCLES=3"
variant up_inorder  "-G UP_INORDER=1"
variant ds_inorder  "-G DS_OOO=0"
variant baseline    "-G COALESCE_EN=0"
variant strict_align "-G ALLOW_MISALIGNED=0"
variant three_slots "-G NUM_INSTR_SLOTS=3 -G NUM_MEM_TAGS=3 -G NUM_ATM_TAGS=1"

echo
if [ "$FAILS" -eq 0 ]; then echo "FORMAL PASS"; else echo "FORMAL FAIL ($FAILS unexpected result(s); logs in $W/)"; fi
exit $FAILS
