# Formal proof of the "exactly once" accounting

`run_formal.sh` proves, with Yosys' built-in SAT engine, that for a tiny geometry (2 lanes, 4-byte accesses,
8-byte transactions, 2 instruction slots, 2+2 tags, 8-bit uid) and **for every possible input sequence** satisfying
the environment contract below, the safety properties **X1–X11** hold in every reachable state. The
properties live in the RTL itself (`gpu_coalescer.sv`, section 13, compiled only with `-DFORMAL`) and are
reduced to one signal, `f_prop`.

```
pip install yowasp-yosys          # Yosys + slang SystemVerilog front end, bundled SAT solver, no other tool needed
formal/run_formal.sh              # ~5-6 minutes: base case, induction, covers, mutants, 6 design variants
```
(With a native Yosys that has the slang plugin, run `YOSYS="yosys -m slang" formal/run_formal.sh`.)

## What is proved

| id | property |
|---|---|
| X1 | `accepted − completed == number of occupied slots` — no request is lost, none is completed more often than accepted |
| X2 | for every occupied slot, its outstanding counter equals the number of live downstream tags (ordinary + atomic) that name it — a response can never complete the wrong request, or one twice (no underflow/overflow) |
| X3 | a response is only ever offered for an occupied, locked, fully-issued slot with nothing outstanding; exactly one slot is locked iff the response register is valid |
| X4 | every live or zombie tag names an occupied slot; zombies are valid tags |
| X5 | for an arbitrary but fixed uid **X**: X is never completed before it is accepted, never completed twice, never accepted twice |
| X6 | an occupied slot carrying X implies X was accepted and not yet completed |
| X7–X11 | ghost-state consistency (uid counter distance, saturation, reset values) — strengthening lemmas that make the above inductive |
| X8 | occupied slots carry pairwise-distinct uids, none equal to the next uid to be issued (unique request identifiers) |

X5 + X1 + X3 are the safety half of "each accepted request completes exactly once": a request is completed at
most once and never before it exists, and the number of completions plus in-flight requests always equals the number
of acceptances.

## Environment contract assumed

1. **Downstream:** it never answers a tag that is *live* in the coalescer but not yet *accepted* by the
   downstream (indistinguishable from a real response). Everything else is allowed — **spurious, duplicate,
   late and out-of-range responses are explicitly part of the input space** and must not disturb the accounting.
2. **uid width:** `UID_W` is large enough that the uid counter never overtakes an in-flight uid (at most
   `2^UID_W − 2` accepts while any request is in flight).
3. The tracked uid X is constant (it is a free input).

Requester behaviour (valid/ready, payloads, `rsp_ready`) is completely unconstrained.

## How the proof is structured

| step | command (Yosys `sat`) | result |
|---|---|---|
| base case | BMC from reset, depth 12 (and depth 4 per variant) | no counterexample |
| induction | start in an **arbitrary** state satisfying `f_prop`, take one step (also two) | `f_prop` still holds ⇒ unbounded |
| non-vacuity | trace to "one load/store accepted, issued and completed", same for an atomic, a spurious response, a timeout, a late response | traces exist |
| mutants | `MUT_EARLY_COMPLETE`, `MUT_NO_SPURIOUS_FILTER` | counterexamples found |
| variants | watchdog on, in-order upstream, in-order downstream, baseline (no coalescing), strict alignment, 3 slots/3 tags | base + induction proved |

The environment contract is implemented as a **sticky monitor** (`f_env_ok_q`): once the environment breaks
an assumption, `f_prop` is vacuously true forever after. That is equivalent to an `assume` on every cycle and
needs no solver feature beyond plain `sat`.

## Honest limits

* The theorem is proved for the geometries in the script. The invariants are written with loops over
  `NUM_INSTR_SLOTS`, `NUM_MEM_TAGS` and `NUM_ATM_TAGS` and do not mention the lane count, so they are expected to
  hold for every geometry — but that extension is argued and simulated (the full regression runs seven larger
  geometries with the same embedded assertions), not proved.
* **Safety only.** It does not prove that a request *eventually* completes; that depends on the downstream
  answering and the requester accepting responses. Liveness is covered by: a structural argument
  (`docs/VERIFICATION.md` §3), the optional watchdog, and the testbench's lost-request check.
* Data-path correctness (merge, byte enables, boundary crossing, atomic results) is **not** part of the formal
  proof; it is checked bit-exactly against the Python model in simulation, and mutants of those functions
  are killed by the regression (`scripts/mutation.py`).
* Larger geometries were not attempted with the formal flow: the 32-lane / 128-byte default does not fit the
  memory of the WebAssembly Yosys build used for development, and no larger formal geometry was tried.

## Tool notes

* `sby` could not be used in the development sandbox (its solver processes cannot be spawned from the WebAssembly
  build), so the script drives `sat` directly. With a native SymbiYosys the same `f_prop` signal can be wrapped as an
  `assert` and proved by `mode prove`.
* `read_slang -j 1` is required for the WebAssembly build (no threads); it is harmless elsewhere.
