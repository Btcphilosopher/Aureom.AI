# GPU memory coalescer

A configurable SystemVerilog **warp-level memory coalescer**: it merges the per-lane accesses of one
SIMT memory instruction into aligned transactions, tracks them to completion, assembles read data, and
returns exactly one response per accepted instruction — or an explicit, lane-precise error. Atomics take a
separate path and are never merged. The package contains the RTL, a self-checking Verilator testbench, a
Python byte-addressed reference model and stimulus generator, a coalesced-vs-uncoalesced benchmark, mutation
testing, a formal proof of the accounting invariants, and integration documentation.

```
rtl/        gpu_coalescer_pkg.sv, gpu_coalescer.sv            the design (one module)
tb/         tb_gpu_coalescer.sv, ds_model.sv, coalescer_checker.sv     testbench, downstream model, SVA checker
model/      coalescer_model.py, gen_stimulus.py, test_model.py         Python reference model, generator, tests
scripts/    run_regression.py, mutation.py, bench.py, summary.py, simlib.py, vbuild.sh, lint.sh
formal/     run_formal.sh, README.md                                   Yosys SAT proof of exactly-once accounting
docs/       ARCHITECTURE.md, INTEGRATION.md, VERIFICATION.md, RESULTS.md (generated)
results/    SUMMARY.md + raw json/log from the run that produced this package
```

## Feature checklist

| requested | where |
|---|---|
| configurable lanes / access widths / transaction size / outstanding capacity | parameters `NUM_LANES`, `MAX_ACC_BYTES` (+ per-instruction `req_size`), `TXN_BYTES`, `NUM_INSTR_SLOTS`, `NUM_MEM_TAGS`, `NUM_ATM_TAGS` |
| active-lane masks, byte enables | `req_mask`, `req_be[lane]` |
| accesses spanning transaction boundaries | low/high part split, merged independently (`docs/ARCHITECTURE.md` §3) |
| read-response assembly | per-lane read buffers filled from tag-matched response lines |
| store completion tracking | per-instruction outstanding counters; response only after every downstream op is answered; `FENCE` |
| unique request identifiers | global `uid`, in-flight slot id, downstream tags |
| out-of-order responses | tag-matched downstream (`DS_OOO`), optional in-order upstream (`UP_INORDER`) |
| memory semantics preserved | in-order issue + byte-mask hazard interlock; rules S1–S9 in `ARCHITECTURE.md` §2 |
| atomics on a separate path | `atm_*` port, own tags, one op per lane, ascending order, never merged |
| Python byte-addressed reference memory, contiguous / strided / scattered / overlapping / boundary-crossing accesses | `model/` |
| compare vs uncoalesced baseline | `COALESCE_EN=0` build of the same RTL; `docs/RESULTS.md` |
| random back-pressure and response reordering | `ds_model.sv`, `+PROFILE=stress|heavy` |
| "exactly once or explicit error", by tests and assertions | `docs/VERIFICATION.md`; `results/SUMMARY.md` |

## Quick start

Needs **Verilator ≥ 5.020**, Python ≥ 3.8 (pytest optional); `make formal` additionally wants `pip install yowasp-yosys`.

```bash
make test                       # lint + Python model tests + quick regression      (~2 min)
make regress                    # full regression: 12 geometries x 9 access classes x 3 timing profiles
make mutation                   # inject 10 RTL bugs, all must be caught
make bench                      # coalesced vs baseline -> docs/RESULTS.md
make formal                     # unbounded accounting proof (tiny geometries)
make all && cat results/SUMMARY.md
make run PATTERN=hazard N=300 PROFILE=heavy SEED=3   # one custom run
```

Manual flow for one run:

```bash
python3 model/gen_stimulus.py --out build/vec --pattern crossing --n 300 --seed 1     # Python model -> vectors
scripts/vbuild.sh build/sim -GNUM_LANES=32 -GTXN_BYTES=128                            # build TB + DUT
build/sim/sim +VEC=build/vec +PROFILE=stress +SEED=7                                  # run; prints TB_RESULT: PASS|FAIL
```
The generator flags (`--lanes --acc --txn --addr-w --coalesce --misaligned`) must match the `-G` overrides; the
testbench refuses to run on vectors generated for a different configuration.

## Headline results

Measured on the RTL (32 lanes, 128-byte transactions, 20-cycle downstream; full tables in `docs/RESULTS.md`):

| access class | txns / instr (coalesced vs baseline) | useful B / txn | throughput speed-up (in-order downstream) |
|---|---|---|---|
| contiguous | 1.69 vs 23.91 | 55.7 vs 3.9 | 10.0x |
| overlap | 1.22 vs 24.42 | 32.0 vs 4.0 | 10.6x |
| crossing | 2.89 vs 39.77 | 5.9 vs 2.6 | 13.3x |
| strided | 10.02 vs 24.02 | 10.0 vs 4.2 | 2.4x |
| scatter | 23.17 vs 23.76 | 4.1 vs 4.0 | 1.0x (nothing to merge) |
| mixed | 5.91 vs 27.01 | 12.0 vs 3.6 | 2.4x |
| atomic | identical (never merged) | – | 1.0x |

With an out-of-order downstream the baseline additionally stalls behind the ordering interlock for same-line
stores, so the same-address classes show larger speed-ups (up to ~65x on `overlap`); `docs/RESULTS.md` reports both
regimes and explains the difference. Throughput scales with the configured capacities as Little's law predicts
(92–99 % of the bound in the sweeps; 79 % at 16 instruction slots, where the one-transaction-per-cycle limit starts to bind).

## Verification at a glance

`results/SUMMARY.md` has the exact counts from the run that produced this package. In short:
the full multi-geometry regression passes; 10/10 injected RTL defects are caught (and the ordering/completion
ones are caught even with every white-box check removed); an unbounded Yosys-SAT proof shows that accounting
invariants — conservation, per-slot outstanding counts, unique ids, "no uid completed before accept or twice" — hold
for all input sequences on tiny geometries under a minimal downstream contract that explicitly admits
spurious, duplicate and late responses.
Limits (formal covers tiny geometries and safety only; no timing/CDC) are listed in `docs/VERIFICATION.md` §8.

## Things you should know

* `rtl/gpu_coalescer.sv` contains inert `MUT_*` and `FORMAL` hooks used only by verification; they are
  compiled out unless defined.
* The leader/match/merge stage is a single combinational cycle (reference-quality, not tuned for multi-GHz).
  `docs/INTEGRATION.md` §8 says how to pipeline it.
* No git repository metadata is included and nothing in this package was committed anywhere.
