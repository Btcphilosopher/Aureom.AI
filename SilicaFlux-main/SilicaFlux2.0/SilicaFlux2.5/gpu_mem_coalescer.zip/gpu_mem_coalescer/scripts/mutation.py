#!/usr/bin/env python3
"""
mutation.py -- prove the verification environment can actually fail.

Each mutant re-builds the DUT with one deliberately injected defect (compile-time hooks
`MUT_*` in rtl/gpu_coalescer.sv) and runs a fixed battery of tests.  A mutant is KILLED if
at least one test fails (TB check, SVA, embedded assertion or watchdog).  An unmutated
control build runs the same battery and must pass -- otherwise "killed" would be meaningless.

  python3 scripts/mutation.py
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import simlib as S  # noqa: E402

MUTANTS = [
    ("MUT_NO_HAZARD",          "ordering interlock removed (overlapping accesses may be in flight together)"),
    ("MUT_ATM_NO_XHAZARD",     "atomic path ignores overlapping ordinary loads/stores"),
    ("MUT_LOWEST_LANE_WINS",   "overlapping store bytes resolved lowest-lane-wins"),
    ("MUT_IGNORE_BE",          "per-lane byte enables ignored"),
    ("MUT_DROP_HI_PART",       "bytes that spill past a transaction boundary are dropped"),
    ("MUT_NO_SPURIOUS_FILTER", "downstream responses for non-outstanding tags are accepted"),
    ("MUT_EARLY_COMPLETE",     "request completes before its downstream operations finish"),
    ("MUT_ATOMIC_REVERSE",     "atomics/leader issued highest lane first"),
    ("MUT_NO_RANGE_CHECK",     "address-range error detection removed"),
    ("MUT_RSP_UNSTABLE",       "upstream response register re-selected while stalled"),
]

# (pattern, n, generator seed, plusargs)
BATTERY = [
    ("hazard",     200, 31, ["+PROFILE=heavy", "+SEED=1"]),
    ("hazard",     200, 32, ["+PROFILE=stress", "+SEED=2"]),
    ("overlap",    200, 33, ["+PROFILE=stress", "+SEED=3"]),
    ("crossing",   200, 34, ["+PROFILE=ideal", "+SEED=4"]),
    ("contiguous", 200, 35, ["+PROFILE=stress", "+SEED=5"]),
    ("atomic",     120, 36, ["+PROFILE=stress", "+SEED=6"]),
    ("errors",     200, 37, ["+PROFILE=ideal", "+SEED=7"]),
    ("mixed",      250, 38, ["+PROFILE=heavy", "+SEED=8"]),
    ("mixed",      250, 39, ["+PROFILE=heavy", "+SEED=9", "+DUP_PM=120"]),
    ("mixed",      200, 40, ["+PROFILE=heavy", "+SEED=10", "+P_RSP=10"]),
]


def run_battery(exe: Path):
    def one(t):
        pat, n, gs, plus = t
        vec = S.gen_vectors(S.DEFAULT, pat, n, gs)
        r = S.run_sim(exe, vec, plus, timeout=300)
        return (f"{pat}#{gs} {' '.join(plus)}", r)
    return S.pmap(one, BATTERY)


def main() -> int:
    t0 = time.time()
    report = {"control": None, "mutants": []}

    print("control (unmutated) ...", flush=True)
    exe = S.build(S.DEFAULT)
    res = run_battery(exe)
    ctrl_ok = all(r.passed for _, r in res)
    report["control"] = {"pass": ctrl_ok, "tests": len(res)}
    print(f"  control: {sum(r.passed for _, r in res)}/{len(res)} tests pass", flush=True)
    if not ctrl_ok:
        for n, r in res:
            if not r.passed:
                print(f"  CONTROL FAIL {n}: {r.first_error}")
        return 2

    killed = 0
    for name, desc in MUTANTS:
        cfg = S.Config(f"mut_{name}", defines=[name])
        exe = S.build(cfg)
        res = run_battery(exe)
        fails = [(n, r) for n, r in res if not r.passed]
        ok = bool(fails)
        killed += ok
        first = fails[0][1].first_error if fails else ""
        print(f"  {'KILLED  ' if ok else 'SURVIVED'} {name:24s} ({len(fails)}/{len(res)} tests fail)  {first[:90]}", flush=True)
        report["mutants"].append({"name": name, "description": desc, "killed": ok,
                                  "failing_tests": len(fails), "tests": len(res),
                                  "first_failure": first, "first_failing_test": fails[0][0] if fails else None})
    # ---- black-box confirmation -------------------------------------------------------------
    # Some mutants above are first caught by white-box checks (embedded RTL assertions, the memory
    # model's ordering check).  Prove the black-box checks alone (golden data, final memory image,
    # completion tracking) also catch the ordering / completion bugs: compile the RTL assertions out
    # (-DSYNTHESIS) and switch the downstream ordering check off (+NOHZCHK=1).
    print("\nblack-box confirmation (RTL assertions compiled out, memory-model ordering check off):", flush=True)
    bb = []
    for name in ("MUT_NO_HAZARD", "MUT_ATM_NO_XHAZARD", "MUT_EARLY_COMPLETE"):
        cfg = S.Config(f"bb_{name}", defines=[name, "SYNTHESIS"])
        exe = S.build(cfg)
        vec = S.gen_vectors(S.DEFAULT, "hazard", 200, 31)
        r = S.run_sim(exe, vec, ["+PROFILE=heavy", "+SEED=1", "+NOHZCHK=1"], timeout=300)
        ok = not r.passed
        killed_bb = ok
        print(f"  {'KILLED  ' if ok else 'SURVIVED'} {name:24s} {r.first_error[:100]}", flush=True)
        bb.append({"name": name, "killed": killed_bb, "first_failure": r.first_error})
    report["black_box"] = bb
    bb_ok = all(x["killed"] for x in bb)

    print(f"\nMUTATION SCORE: {killed}/{len(MUTANTS)} mutants killed in {time.time() - t0:.0f}s"
          f" (black-box-only confirmation: {sum(x['killed'] for x in bb)}/{len(bb)})")
    out = S.ROOT / "results" / "mutation.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(report, indent=1))
    return 0 if (killed == len(MUTANTS) and bb_ok) else 1


if __name__ == "__main__":
    sys.exit(main())
