#!/usr/bin/env bash
# vbuild.sh <build-dir> [verilator -G/-D flags...]   -- build the testbench
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$1"; shift
mkdir -p "$OUT"
verilator --binary --timing --assert --timescale 1ns/1ps \
  -Wno-fatal -Wno-WIDTH -Wno-UNUSED -Wno-DECLFILENAME -Wno-CASEINCOMPLETE -Wno-PINCONNECTEMPTY \
  -Wno-BLKSEQ -Wno-INITIALDLY -Wno-LATCH -Wno-UNOPTFLAT -Wno-MULTIDRIVEN -Wno-SYMRSVDWORD \
  -O2 --top-module tb_gpu_coalescer -Mdir "$OUT" -o sim -j "$(nproc)" "$@" \
  "$ROOT/rtl/gpu_coalescer_pkg.sv" "$ROOT/rtl/gpu_coalescer.sv" \
  "$ROOT/tb/ds_model.sv" "$ROOT/tb/coalescer_checker.sv" "$ROOT/tb/tb_gpu_coalescer.sv" \
  > "$OUT/build.log" 2>&1 || { grep -E "^%Error" "$OUT/build.log" | head -30; echo "BUILD FAILED (see $OUT/build.log)"; exit 1; }
