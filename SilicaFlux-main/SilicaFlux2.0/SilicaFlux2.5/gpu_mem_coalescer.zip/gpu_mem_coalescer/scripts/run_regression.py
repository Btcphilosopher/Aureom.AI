#!/usr/bin/env python3
"""
run_regression.py -- full self-checking regression.

For every DUT geometry (see simlib.CONFIGS) it builds the Verilator testbench, generates
Python-model vector sets for each access class, and runs them under three timing
profiles (ideal / stress / heavy) with random back-pressure, random latency and
response reordering.  A run PASSES only if the testbench reports TB_RESULT: PASS
(exactly-once, data, error, transaction-stream, memory-image and counter checks) with
no assertion firing.

  python3 scripts/run_regression.py            # full
  python3 scripts/run_regression.py --quick    # smoke (fewer instrs / seeds)
  python3 scripts/run_regression.py --configs default,baseline
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent))
import simlib as S  # noqa: E402

PATTERNS = ["contiguous", "strided", "scatter", "overlap", "crossing", "atomic", "hazard", "errors", "mixed"]
PROFILES = ["ideal", "stress", "heavy"]


@dataclass
class Test:
    cfg: str
    name: str
    pattern: str
    n: int
    gseed: int
    gen_extra: List[str] = field(default_factory=list)
    plus: List[str] = field(default_factory=list)


def tests_for(cfgname: str, quick: bool) -> List[Test]:
    n = 100 if quick else 250
    tseeds = [1] if quick else [1, 2]
    T: List[Test] = []
    for gs, pat in enumerate(PATTERNS, start=11):
        for prof in PROFILES:
            for ts in tseeds:
                extra = []
                if cfgname == "inorder_ds":
                    extra = ["+REORDER=0"]            # downstream contract: performs in issue order
                T.append(Test(cfgname, f"{pat}/{prof}/s{ts}", pat, n, gs + ts * 100,
                              plus=[f"+PROFILE={prof}", f"+SEED={ts}"] + extra))
    # directed extras -------------------------------------------------------
    if cfgname in ("default", "small_odd", "wide", "aligned_min", "baseline", "timeout"):
        T.append(Test(cfgname, "fault-region", "fault", n, 91, ["--fault", "1024:2048"],
                      ["+PROFILE=stress", "+SEED=5", "+FAULT_LO=1024", "+FAULT_HI=2048"]))
    if cfgname != "inorder_ds":
        T.append(Test(cfgname, "dup-injection", "mixed", n, 92, [], ["+PROFILE=heavy", "+SEED=6", "+DUP_PM=120"]))
    else:
        T.append(Test(cfgname, "dup-injection", "mixed", n, 92, [], ["+PROFILE=stress", "+SEED=6", "+DUP_PM=120", "+REORDER=0"]))
    T.append(Test(cfgname, "serial", "mixed", n, 93, [], ["+PROFILE=stress", "+SEED=7", "+SERIAL=1"]
                  + (["+REORDER=0"] if cfgname == "inorder_ds" else [])))
    if cfgname == "timeout":
        T.append(Test(cfgname, "watchdog-hole-slow", "timeout", n, 94,
                      ["--hole", "2048:2304", "--slow", "4096:4352"],
                      ["+PROFILE=stress", "+SEED=3", "+HOLE_LO=2048", "+HOLE_HI=2304", "+SLOW_LO=4096",
                       "+SLOW_HI=4352", "+SLOW_EXTRA=900", "+NOHZCHK=1"]))
    return T


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--configs", default=",".join(S.CONFIGS))
    ap.add_argument("--jobs", type=int, default=S.NPROC)
    ap.add_argument("--out", default=str(S.ROOT / "results" / "regression.json"))
    a = ap.parse_args()

    t0 = time.time()
    import shutil
    shutil.rmtree(S.BUILD / "vec", ignore_errors=True)
    (S.BUILD / "vec").mkdir(parents=True, exist_ok=True)
    allres: Dict[str, List[dict]] = {}
    total = failed = 0
    for cname in a.configs.split(","):
        cfg = S.CONFIGS[cname]
        print(f"\n=== config {cname}: {' '.join(cfg.vflags()) or '(defaults)'}", flush=True)
        exe = S.build(cfg)
        tests = tests_for(cname, a.quick)

        def one(t: Test):
            vec = S.gen_vectors(cfg, t.pattern, t.n, t.gseed, t.gen_extra)
            r = S.run_sim(exe, vec, t.plus)
            return t, r

        results = S.pmap(one, tests, a.jobs)
        rows = []
        for t, r in results:
            total += 1
            ok = r.passed
            failed += 0 if ok else 1
            rows.append({"test": t.name, "pass": ok, "instrs": r.metrics.get("instrs"),
                         "mem_txns": r.metrics.get("mem_txns"), "atm_ops": r.metrics.get("atm_ops"),
                         "cycles": r.metrics.get("cycles"), "error": None if ok else r.first_error,
                         "cmd": r.cmd})
            if not ok:
                print(f"  FAIL {t.name}: {r.first_error}\n       {r.cmd}", flush=True)
        npass = sum(1 for r in rows if r["pass"])
        print(f"  {npass}/{len(rows)} passed", flush=True)
        allres[cname] = rows

    Path(a.out).parent.mkdir(exist_ok=True, parents=True)
    Path(a.out).write_text(json.dumps({"total": total, "failed": failed, "results": allres}, indent=1))
    print(f"\nREGRESSION {'PASS' if failed == 0 else 'FAIL'}: {total - failed}/{total} runs passed "
          f"in {time.time() - t0:.0f}s")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
