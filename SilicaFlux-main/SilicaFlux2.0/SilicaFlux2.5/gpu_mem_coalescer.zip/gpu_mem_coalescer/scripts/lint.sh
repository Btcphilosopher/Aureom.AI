#!/usr/bin/env bash
# lint.sh -- Verilator -Wall lint of the RTL across several geometries, with and without FORMAL.
set -u
cd "$(dirname "$0")/.."
FAIL=0
lint() {
  local out
  out=$(verilator --lint-only -Wall -Wno-DECLFILENAME -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM \
        -Wno-WIDTHTRUNC -Wno-WIDTHEXPAND --top-module gpu_coalescer "$@" \
        rtl/gpu_coalescer_pkg.sv rtl/gpu_coalescer.sv 2>&1)
  if [ -n "$out" ]; then echo "LINT FAIL: $*"; echo "$out" | head -20; FAIL=1; else echo "lint clean: ${*:-(defaults)}"; fi
}
lint
lint -GNUM_LANES=8 -GMAX_ACC_BYTES=16 -GTXN_BYTES=64 -GNUM_INSTR_SLOTS=3 -GNUM_MEM_TAGS=5 -GNUM_ATM_TAGS=3 -GADDR_W=24
lint -GNUM_LANES=16 -GMAX_ACC_BYTES=4 -GTXN_BYTES=32 -GNUM_INSTR_SLOTS=1 -GNUM_MEM_TAGS=2 -GNUM_ATM_TAGS=1
lint -GNUM_LANES=64 -GTXN_BYTES=256 -GTIMEOUT_CYCLES=500
lint -DFORMAL -GNUM_LANES=2 -GADDR_W=6 -GMAX_ACC_BYTES=4 -GTXN_BYTES=8 -GNUM_INSTR_SLOTS=2 -GNUM_MEM_TAGS=2 -GNUM_ATM_TAGS=2 -GUID_W=8
exit $FAIL
