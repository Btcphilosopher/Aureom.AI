#!/usr/bin/env python3
"""
bench.py -- coalesced vs uncoalesced baseline, measured on the RTL.

The baseline is the SAME RTL built with COALESCE_EN=0 (one downstream transaction per
lane access-part; identical handshakes, tags, hazard interlock and error handling), so
every difference below is attributable to coalescing alone.  Both designs are driven with
the identical instruction stream (generated once by the Python model) and identical
downstream timing seeds, and every benchmark run must pass the full self-checking
testbench before its numbers are used.

Two downstream regimes are reported because the ordering interlock matters:
  A  out-of-order downstream (DS_OOO=1): overlapping accesses must wait for each other
  B  in-order downstream     (DS_OOO=0): the downstream preserves issue order, interlock off
Regime B isolates the pure effect of the transaction-count reduction.

Metrics
  txns / instr        downstream load/store transactions per load/store instruction
  useful B / txn      bytes the lanes actually asked for per transaction (popcount of the byte mask)
  bus efficiency      useful bytes / (transactions x TXN_BYTES)
  unloaded latency    serial run (one request in flight), fixed 20-cycle downstream latency:
                      cycles from request accept to response handshake
  throughput          instructions per 1000 cycles and lane-payload bytes per cycle
  RTL == model        RTL transaction counts equal the Python model's prediction

  python3 scripts/bench.py [--n 600]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent))
import simlib as S  # noqa: E402

PATTERNS = ["contiguous", "strided", "scatter", "overlap", "crossing", "mixed"]
ALL = PATTERNS + ["atomic"]
TXN_BYTES = 128
FIXED_LAT = 20

MODES = {
    # name: (config, extra plusargs)
    "coalesced":    (S.Config("default"), []),
    "baseline":     (S.CONFIGS["baseline"], []),
    "coalesced_io": (S.Config("bench_coal_io", G=dict(DS_OOO=0)), ["+REORDER=0"]),
    "baseline_io":  (S.Config("bench_base_io", G=dict(DS_OOO=0, COALESCE_EN=0), gen=["--coalesce", "0"]), ["+REORDER=0"]),
}
SCENARIOS = {
    "serial": ["+PROFILE=ideal", "+SERIAL=1"],         # unloaded completion latency
    "ideal":  ["+PROFILE=ideal"],                      # saturated, no back-pressure
    "stress": ["+PROFILE=stress", "+SEED=11"],         # random back-pressure + latency + reordering
}


def fmt(x, nd=2):
    return "-" if x is None else (f"{x:.{nd}f}" if isinstance(x, float) else str(x))


def ratio(num, den, nd=2, suffix="x"):
    return "-" if not den or num is None else f"{num / den:.{nd}f}{suffix}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--out", default=str(S.ROOT / "results" / "benchmark.json"))
    ap.add_argument("--md", default=str(S.ROOT / "docs" / "RESULTS.md"))
    a = ap.parse_args()

    exes = {m: S.build(cfg) for m, (cfg, _) in MODES.items()}

    jobs = [(pat, mode, sc) for pat in ALL for mode in MODES for sc in SCENARIOS]

    def one(j):
        pat, mode, sc = j
        cfg, extra = MODES[mode]
        gcfg = S.CONFIGS["baseline"] if "baseline" in mode else S.DEFAULT     # generator flags only
        vec = S.gen_vectors(gcfg, pat, a.n, 1000 + ALL.index(pat), tag=f"bench_{'base' if 'baseline' in mode else 'coal'}_{pat}")
        summ = json.loads((vec / "summary.json").read_text())
        r = S.run_sim(exes[mode], vec, SCENARIOS[sc] + extra)
        return j, summ, r

    data: Dict[str, Dict[str, Dict[str, dict]]] = {}
    bad = 0
    for j, summ, r in S.pmap(one, jobs):
        pat, mode, sc = j
        if not r.passed:
            bad += 1
            print(f"FAIL {pat}/{mode}/{sc}: {r.first_error}")
        data.setdefault(pat, {}).setdefault(mode, {})[sc] = {"m": r.metrics, "s": summ}
    if bad:
        print(f"{bad} benchmark runs failed functional checks -- not reporting numbers")
        return 1

    rows: List[dict] = []
    for pat in ALL:
        row = {"pattern": pat}
        for mode in MODES:
            d = data[pat][mode]
            mi, si, ms, mx = d["ideal"]["m"], d["ideal"]["s"], d["serial"]["m"], d["stress"]["m"]
            mem_instrs = data[pat]["coalesced"]["ideal"]["s"]["mem_instrs"] or None
            row[mode] = {
                "txns_per_instr": (mi["mem_txns"] / mem_instrs) if mem_instrs else None,
                "useful_per_txn": (mi["useful_bytes"] / mi["mem_txns"]) if mi["mem_txns"] else None,
                "bus_eff": (mi["useful_bytes"] / (mi["mem_txns"] * TXN_BYTES)) if mi["mem_txns"] else None,
                "lat_unloaded": ms["lat_acc_avg"], "lat_loaded": mi["lat_acc_avg"], "lat_stress": mx["lat_acc_avg"],
                "ipk": 1000.0 * mi["instrs"] / mi["cycles"], "ipk_stress": 1000.0 * mx["instrs"] / mx["cycles"],
                "bpc": si["lane_bytes"] / mi["cycles"], "cycles": mi["cycles"], "cycles_stress": mx["cycles"],
                "model_txns": si["mem_txns"], "rtl_txns": mi["mem_txns"],
                "model_atm": si["atm_ops"], "rtl_atm": mi["atm_ops"],
            }
        row["model_match"] = all(row[m]["model_txns"] == row[m]["rtl_txns"] and row[m]["model_atm"] == row[m]["rtl_atm"]
                                 for m in MODES)
        rows.append(row)

    # ---------------------------- capacity sweeps (Little's law) ----------------------------
    sweep = {"slots": [], "tags": [], "atm_tags": []}
    sweep_n = 400

    def sweep_one(item):
        kind, val, pat, gs = item
        g = dict(NUM_INSTR_SLOTS=16, NUM_MEM_TAGS=32, NUM_ATM_TAGS=16)
        key = {"slots": "NUM_INSTR_SLOTS", "tags": "NUM_MEM_TAGS", "atm_tags": "NUM_ATM_TAGS"}[kind]
        g[key] = val
        cfg = S.Config(f"sweep_{kind}_{val}", G=g)
        exe = S.build(cfg)
        vec = S.gen_vectors(S.DEFAULT, pat, sweep_n, gs, tag=f"sweep_{pat}")
        ideal = S.run_sim(exe, vec, ["+PROFILE=ideal"])
        serial = S.run_sim(exe, vec, ["+PROFILE=ideal", "+SERIAL=1"])
        return item, ideal, serial

    items = [("slots", v, "contiguous", 2001) for v in (1, 2, 4, 8, 16)] + \
            [("tags", v, "scatter", 2002) for v in (2, 4, 8, 16, 32)] + \
            [("atm_tags", v, "atomic", 2003) for v in (1, 2, 4, 8, 16)]
    for item, ideal, serial in [sweep_one(i) for i in items]:      # builds already parallel inside verilator
        kind, val, pat, _ = item
        if not (ideal.passed and serial.passed):
            print(f"FAIL sweep {item}: {(ideal if not ideal.passed else serial).first_error}")
            return 1
        mi = ideal.metrics
        lat = serial.metrics["lat_acc_avg"]
        ipk = 1000.0 * mi["instrs"] / mi["cycles"]
        ops_pc = (mi["mem_txns"] + mi["atm_ops"]) / mi["cycles"]
        sweep[kind].append({"value": val, "ipk": ipk, "ops_per_cycle": ops_pc, "lat_unloaded": lat,
                            "cycles": mi["cycles"], "mem_txns": mi["mem_txns"], "atm_ops": mi["atm_ops"],
                            "instrs": mi["instrs"]})

    out = {"rows": rows, "sweep": sweep}
    Path(a.out).parent.mkdir(exist_ok=True, parents=True)
    Path(a.out).write_text(json.dumps(out, indent=1))

    # ----------------------------- markdown -----------------------------
    L: List[str] = []
    L.append("# Benchmark results: coalesced vs uncoalesced baseline\n")
    L.append("_Generated by `scripts/bench.py` from RTL simulation (`make bench`). Do not edit by hand._\n")
    L.append(f"**Setup.** 32 lanes, 128-byte transactions, 8-byte maximum lane access, 8 instruction slots, 16 memory tags, "
             f"8 atomic tags. {a.n} instructions per access class. *Baseline* = the same RTL built with `COALESCE_EN=0`. "
             "Every run below passed the complete self-checking testbench (exactly-once, data, error, transaction-stream, "
             "memory-image and counter checks) before its numbers were accepted.\n")
    L.append("**Downstream timing.** *serial* / *ideal*: fixed 20-cycle latency, no back-pressure, one response per cycle. "
             "*stress*: random request/response back-pressure, 2–60-cycle random latency, random response reordering.\n")
    L.append("**Regimes.** *A (out-of-order downstream)*: the downstream may perform and answer in any order, so the coalescer's "
             "ordering interlock makes overlapping accesses wait for each other. *B (in-order downstream)*: the downstream "
             "performs in issue order, the interlock is off, and the comparison isolates the transaction-count reduction.\n")

    def table(title, cols, getter, note=None):
        L.append(f"\n## {title}\n")
        if note:
            L.append(note + "\n")
        L.append("| access class | " + " | ".join(cols) + " |")
        L.append("|---|" + "|".join(["---:"] * len(cols)) + "|")
        for r in rows:
            L.append(f"| {r['pattern']} | " + " | ".join(getter(r)) + " |")

    table("1. Transactions per load/store instruction", ["coalesced", "baseline", "reduction"],
          lambda r: [fmt(r["coalesced"]["txns_per_instr"]), fmt(r["baseline"]["txns_per_instr"]),
                     ratio(r["baseline"]["txns_per_instr"], r["coalesced"]["txns_per_instr"], 1)
                     if r["coalesced"]["txns_per_instr"] else "n/a (atomics only)"])
    table("2. Useful bytes per transaction", ["coalesced", "baseline", "bus efficiency coalesced", "bus efficiency baseline"],
          lambda r: [fmt(r["coalesced"]["useful_per_txn"], 1), fmt(r["baseline"]["useful_per_txn"], 1),
                     (fmt(100 * r["coalesced"]["bus_eff"], 1) + " %") if r["coalesced"]["bus_eff"] is not None else "-",
                     (fmt(100 * r["baseline"]["bus_eff"], 1) + " %") if r["baseline"]["bus_eff"] is not None else "-"],
          note="Useful bytes = popcount of the transaction byte mask (bytes some lane asked for); bus efficiency = useful / 128.")
    for tag, (cm, bm, title) in {"A": ("coalesced", "baseline", "A: out-of-order downstream (interlock active)"),
                                  "B": ("coalesced_io", "baseline_io", "B: in-order downstream (interlock off)")}.items():
        table(f"3{tag}. Completion latency, cycles (accept → response) — regime {title}",
              ["unloaded coalesced", "unloaded baseline", "ratio", "loaded coalesced", "loaded baseline"],
              lambda r, cm=cm, bm=bm: [fmt(r[cm]["lat_unloaded"], 1), fmt(r[bm]["lat_unloaded"], 1),
                                       ratio(r[bm]["lat_unloaded"], r[cm]["lat_unloaded"]),
                                       fmt(r[cm]["lat_loaded"], 1), fmt(r[bm]["lat_loaded"], 1)],
              note="*Unloaded* = one request in flight. *Loaded* = saturating instruction stream (queueing included).")
        table(f"4{tag}. Throughput — regime {title}",
              ["instr/kcycle coalesced", "instr/kcycle baseline", "speed-up", "payload B/cycle coalesced",
               "payload B/cycle baseline", "speed-up (random back-pressure)"],
              lambda r, cm=cm, bm=bm: [fmt(r[cm]["ipk"], 1), fmt(r[bm]["ipk"], 1), ratio(r[cm]["ipk"], r[bm]["ipk"]),
                                       fmt(r[cm]["bpc"], 1), fmt(r[bm]["bpc"], 1),
                                       ratio(r[cm]["ipk_stress"], r[bm]["ipk_stress"])],
              note="Payload = bytes requested by active, non-faulting lanes (from the Python model).")
    table("5. Cross-check: RTL counters vs Python model prediction (all four builds)",
          ["model txns", "RTL txns", "model atomic ops", "RTL atomic ops", "match"],
          lambda r: [str(r["coalesced"]["model_txns"]), str(int(r["coalesced"]["rtl_txns"])),
                     str(r["coalesced"]["model_atm"]), str(int(r["coalesced"]["rtl_atm"])),
                     "yes" if r["model_match"] else "**NO**"])

    L.append("\n## 6. Outstanding-request capacity (Little's law)\n")
    L.append("Saturated throughput of the coalesced design versus the configurable capacities. "
             "Bound = capacity ÷ unloaded latency (Little's law). Measured with the 20-cycle downstream.\n")
    for kind, title, unit, num in (("slots", "NUM_INSTR_SLOTS (outstanding instructions), `contiguous` stream", "instr/kcycle", "ipk"),
                                   ("tags", "NUM_MEM_TAGS (outstanding transactions), `scatter` stream (~23 txns/instr)", "txn/cycle", "ops"),
                                   ("atm_tags", "NUM_ATM_TAGS (outstanding atomics), `atomic` stream (≤32 ops/instr)", "atomic op/cycle", "ops")):
        L.append(f"\n**{title}**\n")
        L.append(f"| {kind} | measured {unit} | Little bound | measured / bound |")
        L.append("|---:|---:|---:|---:|")
        for e in sweep[kind]:
            if num == "ipk":
                meas = e["ipk"]
                bound = 1000.0 * e["value"] / e["lat_unloaded"]
            else:
                meas = e["ops_per_cycle"]
                lat_txn = FIXED_LAT + 2          # request->response round trip seen by one tag
                bound = min(1.0, e["value"] / lat_txn)
            L.append(f"| {e['value']} | {meas:.3f} | {bound:.3f} | {100 * meas / bound:.0f} % |")
    L.append("\n### Notes\n")
    L.append("* **Atomics are never merged.** The `atomic` row shows identical operation counts for both designs: atomics are "
             "issued one lane at a time on the separate atomic port, so coalescing neither helps nor hurts them. Their "
             "throughput is set by `NUM_ATM_TAGS` (section 6).")
    L.append("* `useful B/txn` counts bytes the lanes asked for. When several lanes read the same bytes (broadcast / overlap) "
             "the coalescer fetches them once, so the figure can be lower than the sum of lane bytes — a feature, not a loss.")
    L.append("* Unloaded latency ≈ fixed downstream latency + a handful of coalescer pipeline cycles + one cycle per "
             "additional transaction. The baseline pays that last term once per lane-part.")
    L.append("* Large regime-A speed-ups on `overlap` and `crossing` are inflated by the baseline's ordering stalls (same-line "
             "stores from different lanes must serialise behind the interlock). Regime B shows the effect of transaction count alone.")
    L.append("* `scatter` (random addresses over a 64 KiB aperture) leaves almost nothing to merge; coalescing is expected to "
             "be neutral there, and is.")
    Path(a.md).parent.mkdir(exist_ok=True, parents=True)
    Path(a.md).write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 0


if __name__ == "__main__":
    sys.exit(main())
