"""
simlib.py -- shared helpers for the regression / mutation / benchmark runners.

Builds the Verilator testbench for a named configuration, generates vector sets
with model/gen_stimulus.py (same geometry flags), runs the simulator and parses
the ``METRIC`` / ``TB_RESULT`` lines the testbench prints.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import threading
import zlib
import sys
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
GEN = ROOT / "model" / "gen_stimulus.py"
VBUILD = ROOT / "scripts" / "vbuild.sh"
NPROC = os.cpu_count() or 4


@dataclass
class Config:
    """One DUT/TB geometry.  ``G`` are Verilator -G overrides (shared by DUT and TB),
    ``gen`` the matching generator flags."""
    name: str
    G: Dict[str, object] = field(default_factory=dict)
    defines: List[str] = field(default_factory=list)       # e.g. ["MUT_NO_HAZARD"]
    gen: List[str] = field(default_factory=list)

    def vflags(self) -> List[str]:
        out = [f"-G{k}={v}" for k, v in self.G.items()]
        out += [f"-D{d}" for d in self.defines]
        return out


# Geometry presets used by the regression ------------------------------------------------
DEFAULT = Config("default")
CONFIGS: Dict[str, Config] = {
    "default": DEFAULT,
    # small, deliberately non-power-of-two resources, 16-byte lane accesses, in-order upstream
    "small_odd": Config("small_odd",
                        G=dict(NUM_LANES=8, ADDR_W=24, MAX_ACC_BYTES=16, TXN_BYTES=64, NUM_INSTR_SLOTS=3,
                               NUM_MEM_TAGS=5, NUM_ATM_TAGS=3, UP_INORDER=1, UID_W=16),
                        gen=["--lanes", "8", "--addr-w", "24", "--acc", "16", "--txn", "64"]),
    # downstream guarantees in-order performance -> interlock disabled
    "inorder_ds": Config("inorder_ds", G=dict(DS_OOO=0)),
    # natural alignment enforced, minimal resources
    "aligned_min": Config("aligned_min",
                          G=dict(NUM_LANES=16, MAX_ACC_BYTES=4, TXN_BYTES=32, NUM_INSTR_SLOTS=1, NUM_MEM_TAGS=2,
                                 NUM_ATM_TAGS=1, ALLOW_MISALIGNED=0),
                          gen=["--lanes", "16", "--acc", "4", "--txn", "32", "--misaligned", "0"]),
    # the uncoalesced baseline
    "baseline": Config("baseline", G=dict(COALESCE_EN=0), gen=["--coalesce", "0"]),
    # watchdog enabled
    "timeout": Config("timeout", G=dict(TIMEOUT_CYCLES=300)),
    # large lane count / big transactions
    "wide": Config("wide", G=dict(NUM_LANES=64, TXN_BYTES=256, NUM_INSTR_SLOTS=16, NUM_MEM_TAGS=32, NUM_ATM_TAGS=16),
                   gen=["--lanes", "64", "--txn", "256"]),
    # ---- corner geometries -------------------------------------------------------------------
    # one lane, transaction == access width (every misaligned access straddles), every resource = 1
    "edge_1lane": Config("edge_1lane",
                         G=dict(NUM_LANES=1, ADDR_W=16, MAX_ACC_BYTES=2, TXN_BYTES=2, NUM_INSTR_SLOTS=1,
                                NUM_MEM_TAGS=1, NUM_ATM_TAGS=1),
                         gen=["--lanes", "1", "--addr-w", "16", "--acc", "2", "--txn", "2"]),
    # 64-bit addresses
    "edge_addr64": Config("edge_addr64", G=dict(NUM_LANES=4, ADDR_W=64, TXN_BYTES=64),
                          gen=["--lanes", "4", "--addr-w", "64", "--txn", "64"]),
    # address space == aperture == 4 KiB (limit equals 2**ADDR_W)
    "edge_tinymem": Config("edge_tinymem", G=dict(NUM_LANES=8, ADDR_W=12, MEM_BYTES=4096, TXN_BYTES=32),
                           gen=["--lanes", "8", "--addr-w", "12", "--txn", "32", "--limit", "4096"]),
    # 2-byte lane accesses on 128-byte transactions
    "edge_narrow": Config("edge_narrow", G=dict(NUM_LANES=32, MAX_ACC_BYTES=2, TXN_BYTES=128), gen=["--acc", "2"]),
    # 16-byte accesses on 16-byte transactions
    "edge_acc16": Config("edge_acc16", G=dict(NUM_LANES=4, MAX_ACC_BYTES=16, TXN_BYTES=16, NUM_ATM_TAGS=2),
                         gen=["--lanes", "4", "--acc", "16", "--txn", "16"]),
}


def run_cmd(cmd: Sequence[str], timeout: int = 900) -> subprocess.CompletedProcess:
    return subprocess.run(list(map(str, cmd)), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          text=True, timeout=timeout)


def build(cfg: Config, tag: Optional[str] = None, force: bool = False) -> Path:
    """Build the simulator for ``cfg``; returns the path of the ``sim`` binary."""
    tag = tag or cfg.name
    d = BUILD / tag
    exe = d / "sim"
    stamp = d / ".flags"
    flags = " ".join(cfg.vflags())
    srcs = [ROOT / "rtl" / "gpu_coalescer.sv", ROOT / "rtl" / "gpu_coalescer_pkg.sv"] + \
           list((ROOT / "tb").glob("*.sv"))
    newest = max(p.stat().st_mtime for p in srcs)
    if (not force and exe.exists() and stamp.exists() and stamp.read_text() == flags
            and exe.stat().st_mtime >= newest):
        return exe
    r = run_cmd([VBUILD, d] + cfg.vflags(), timeout=1800)
    if r.returncode != 0 or not exe.exists():
        raise RuntimeError(f"build of {tag} failed:\n{r.stdout[-3000:]}")
    stamp.write_text(flags)
    return exe


_gen_locks: Dict[str, threading.Lock] = {}
_gen_guard = threading.Lock()


def gen_vectors(cfg: Config, pattern: str, n: int, seed: int, extra: Sequence[str] = (),
                tag: Optional[str] = None) -> Path:
    """Generate (once) the vector set for this key.  Thread-safe and atomic: concurrent callers
    asking for the same set wait for one generation, and nobody ever reads a half-written set."""
    key = tag or f"{cfg.name}_{pattern}_{n}_{seed}_{zlib.crc32(' '.join(map(str, extra)).encode()) % 10_000}"
    d = BUILD / "vec" / key
    with _gen_guard:
        lock = _gen_locks.setdefault(key, threading.Lock())
    with lock:
        if (d / "summary.json").exists():
            return d
        tmp = BUILD / "vec" / f".tmp_{key}_{os.getpid()}"
        shutil.rmtree(tmp, ignore_errors=True)
        r = run_cmd([sys.executable, GEN, "--out", tmp, "--pattern", pattern, "--n", n, "--seed", seed]
                    + cfg.gen + list(extra))
        if r.returncode != 0:
            raise RuntimeError(f"vector generation failed: {r.stdout[-2000:]}")
        shutil.rmtree(d, ignore_errors=True)
        os.rename(tmp, d)
    return d


@dataclass
class RunResult:
    rc: int
    passed: bool
    metrics: Dict[str, float]
    tail: str
    cmd: str

    @property
    def first_error(self) -> str:
        for ln in self.tail.splitlines():
            if "ERROR" in ln or "FAIL" in ln or "Assertion" in ln or "%Error" in ln:
                return ln.strip()[:200]
        return self.tail.strip().splitlines()[-1][:200] if self.tail.strip() else "(no output)"


def parse_metrics(out: str) -> Dict[str, float]:
    m: Dict[str, float] = {}
    for ln in out.splitlines():
        if ln.startswith("METRIC"):
            for k, v in re.findall(r"(\w+)=(-?[0-9.]+)", ln):
                m[k] = float(v)
    return m


def run_sim(exe: Path, vec: Path, plusargs: Iterable[str] = (), timeout: int = 900) -> RunResult:
    cmd = [exe, f"+VEC={vec}"] + list(plusargs)
    try:
        r = run_cmd(cmd, timeout=timeout)
        out, rc = r.stdout, r.returncode
    except subprocess.TimeoutExpired as e:
        out, rc = (e.stdout or "") + "\nTB_RESULT: FAIL (host timeout)", 124
    passed = rc == 0 and "TB_RESULT: PASS" in out
    return RunResult(rc, passed, parse_metrics(out), out[-4000:], " ".join(map(str, cmd)))


def pmap(fn, items, workers: int = NPROC):
    with ThreadPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(fn, items))
