# Integration guide

Everything an SoC / GPU-core integrator needs: parameters, ports, handshake rules, the contracts both
neighbours must honour, sizing, timing/area notes and a bring-up checklist.
Microarchitecture and semantics are in `ARCHITECTURE.md`; how it was verified is in `VERIFICATION.md`.

## 1. Files

| file | role |
|---|---|
| `rtl/gpu_coalescer_pkg.sv` | opcodes, atomic opcodes, error-flag bit positions (compile first) |
| `rtl/gpu_coalescer.sv` | the coalescer (single module, no sub-modules) |

Plain SystemVerilog-2012 (no interfaces, structs or classes). Simulated with Verilator 5.020, linted with
`-Wall`, parsed and elaborated by Yosys + slang. Single clock `clk`, synchronous active-low reset `rst_n`.

## 2. Parameters

| parameter | default | legal values | meaning / effect |
|---|---|---|---|
| `NUM_LANES` | 32 | ≥ 1 | lanes per warp instruction |
| `ADDR_W` | 32 | > log2(`TXN_BYTES`) | byte-address width |
| `MAX_ACC_BYTES` | 8 | power of 2, ≥ 2 | widest per-lane access. Per-instruction access width is `2^req_size` ≤ this. Data buses are `MAX_ACC_BYTES*8` bits per lane |
| `TXN_BYTES` | 128 | power of 2, ≥ `MAX_ACC_BYTES` | aligned downstream transaction size (cache line / sector / burst) |
| `NUM_INSTR_SLOTS` | 8 | ≥ 1 | outstanding upstream instructions (response-reorder window, storage for one full instruction each) |
| `NUM_MEM_TAGS` | 16 | ≥ 1 | outstanding ordinary downstream transactions |
| `NUM_ATM_TAGS` | 8 | ≥ 1 | outstanding atomic operations |
| `USER_TAG_W` | 8 | ≥ 1 | width of the opaque requester tag echoed in the response |
| `UID_W` | 32 | ≥ log2(`NUM_INSTR_SLOTS`) | width of the global request id. Must not wrap while an older request is still in flight; 32 is effectively unbounded |
| `ADDR_LIMIT` | 0 | 0 or any | exclusive upper bound of legal addresses; 0 = the whole `2^ADDR_W` space. Make it a multiple of `TXN_BYTES` unless the downstream honours `mem_req_mask` at the end of memory |
| `COALESCE_EN` | 1 | 0/1 | 0 = uncoalesced baseline (one transaction per lane-part) |
| `ALLOW_MISALIGNED` | 1 | 0/1 | 0 = misaligned load/store → `ERR_ALIGN` (atomics must always be aligned) |
| `DS_OOO` | 1 | 0/1 | 1 = downstream may perform/answer out of order (interlock on). 0 = downstream performs in issue order (interlock off, in-order checker on) |
| `UP_INORDER` | 0 | 0/1 | 1 = upstream responses leave in request order; 0 = any order (use `rsp_id`/`rsp_uid`) |
| `TIMEOUT_CYCLES` | 0 | ≥ 0 | downstream watchdog; 0 disables it |

Derived widths are `localparam`s in the module's parameter port list; compute the same values when you declare
the connecting signals:

| width | value |
|---|---|
| `SIZE_W` | `max(1, $clog2(log2(MAX_ACC_BYTES) + 1))` — e.g. 2 for 8-byte, 3 for 16-byte accesses |
| `SLOT_W` | `max(1, $clog2(NUM_INSTR_SLOTS))` |
| `MTAG_W` / `ATAG_W` | `max(1, $clog2(NUM_MEM_TAGS))` / `max(1, $clog2(NUM_ATM_TAGS))` |
| `ATOM_W` | `8 * min(8, MAX_ACC_BYTES)` |

## 3. Ports

All multi-lane buses are packed arrays indexed by lane. **Byte `k` of a lane value is bits `[8k+7:8k]`
(little-endian); byte enable `k` is `req_be[lane][k]`; byte `k` lives at address `req_addr[lane] + k`.**

### 3.1 Upstream request (valid/ready)

| signal | dir | description |
|---|---|---|
| `req_valid` / `req_ready` | in/out | standard handshake; payload must be stable while `valid && !ready` |
| `req_op` | in | `0` load, `1` store, `2` atomic, `3` fence |
| `req_size` | in | log2 of bytes per lane access (`0..log2(MAX_ACC_BYTES)`); atomics `0..3` |
| `req_amo` | in | atomic opcode (`ADD 0, AND 1, OR 2, XOR 3, MIN 4, MAX 5, MINU 6, MAXU 7, EXCH 8, CAS 9`) |
| `req_mask` | in | active-lane mask |
| `req_addr[l]` | in | byte address of lane *l* |
| `req_be[l]` | in | byte enables of lane *l* (bits above the access size are ignored; **ignored for atomics**) |
| `req_wdata[l]` | in | store data / atomic operand A (CAS compare value) |
| `req_wdata2[l]` | in | atomic operand B (CAS swap value) |
| `req_tag` | in | opaque; returned unchanged in `rsp_tag` (warp id, destination register, …) |
| `req_uid` | out | the unique id this request **will** receive if the handshake completes this cycle (valid while `req_ready`) |
| `req_id` | out | the slot index it will occupy (valid while `req_ready`) |

`req_ready` is high while at least one instruction slot is free; it does not depend on `req_valid`.
A fence ignores `req_size/mask/addr/…`. A load/store/atomic with `req_mask == 0` (or no enabled byte) is accepted and
completes with no traffic.

### 3.2 Upstream response (valid/ready)

| signal | description |
|---|---|
| `rsp_valid` / `rsp_ready` | payload stable while `valid && !ready` |
| `rsp_uid` | unique id of the request being completed (matches `req_uid` seen at accept) |
| `rsp_id` | slot index (matches `req_id`); unique among in-flight requests |
| `rsp_tag`, `rsp_op` | echo of `req_tag`, `req_op` |
| `rsp_rdata[l]` | load data / atomic old value, zero-extended; zero in disabled bytes and inactive lanes; **undefined for lanes in `rsp_err_mask`** |
| `rsp_err` | error-flag vector (bit0 ILLEGAL, 1 ALIGN, 2 RANGE, 3 DOWNSTREAM, 4 TIMEOUT); 0 = success |
| `rsp_err_mask` | lanes that failed |

Order: with `UP_INORDER = 0` responses may overtake each other; identify them by `rsp_uid` (or `rsp_id`). Stores
and fences return `rsp_rdata = 0`.

### 3.3 Downstream ordinary port

| signal | dir | description |
|---|---|---|
| `mem_req_valid` / `mem_req_ready` | out/in | request handshake (registered output; payload stable until accepted) |
| `mem_req_id` | out | transaction tag, unique among outstanding requests (`< NUM_MEM_TAGS`) |
| `mem_req_write` | out | 1 store, 0 load |
| `mem_req_addr` | out | line address, aligned to `TXN_BYTES` |
| `mem_req_mask` | out | per-byte: bytes to write / bytes the requester needs (never empty) |
| `mem_req_wdata` | out | write data (zero outside the mask; zero for loads) |
| `mem_rsp_valid` | in | response; **`mem_rsp_ready` is tied to 1** |
| `mem_rsp_id` | in | tag of the request being answered |
| `mem_rsp_rdata` | in | line data; only bytes inside the request mask are used |
| `mem_rsp_err` | in | 1 = failed (the lanes served get `ERR_DOWNSTREAM`) |

### 3.4 Downstream atomic port (separate)

`atm_req_valid/ready`, `atm_req_id`, `atm_req_op` (same encoding as `req_amo`), `atm_req_size` (log2 bytes),
`atm_req_addr` (naturally aligned), `atm_req_a`, `atm_req_b` (already truncated to the access width);
`atm_rsp_valid`, `atm_rsp_id`, `atm_rsp_rdata` (old value), `atm_rsp_err`, with `atm_rsp_ready` tied to 1.

### 3.5 Status / counters (free-running 32-bit, wrap)

`idle`, `stat_instr_accepted`, `stat_instr_completed`, `stat_mem_txns`, `stat_mem_useful_bytes` (sum of mask
popcounts), `stat_atm_ops`, `stat_err_instr`, `stat_rsp_spurious` (dropped responses to non-outstanding tags),
`stat_rsp_late` (dropped responses to timed-out tags), `stat_timeouts`, `stat_proto_err` (sticky: spurious
response or in-order contract violation).
Coalescing efficiency in the field = `stat_mem_useful_bytes / (stat_mem_txns * TXN_BYTES)`.

## 4. Handshake timing

```
clk              ┐ ┌─┐ ┌─┐ ┌─┐ ┌─┐ ┌─┐ ┌─┐ ┌─┐ ┌─┐ ┌─┐ ┌─┐
req_valid        ▔▔▔▔▔▔▔▔▁▁▁▁                                     request accepted at the edge
req_ready        ▔▔▔▔▔▔▔▔                                         where both are high
req_uid/req_id   [  N, s  ]                                       sampled by the requester at that edge
mem_req_valid    ▁▁▁▁▁▁▁▁▁▁▁▁▔▔▔▔▔▁▁▁                             2 cycles after accept (single txn)
mem_rsp_valid    ▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▔▁                     L cycles later (downstream latency)
rsp_valid        ▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▔▔▔               2 cycles after the last downstream response
```

Rules:
* A requester must keep `req_valid` and the payload steady until `req_ready`; the coalescer keeps `rsp_*`,
  `mem_req_*` and `atm_req_*` steady until accepted (checked by SVA in the testbench).
* `mem_req_ready` / `atm_req_ready` may be tied high or toggle randomly; `rsp_ready` may toggle randomly.
* Reset must be applied while the unit is idle; all outstanding work is discarded.

## 5. Contracts

### 5.1 What the downstream must guarantee

1. **Tag discipline.** Answer every accepted request exactly once, with the request's id. Ids of different
   outstanding requests are different (the coalescer guarantees this on the way out).
2. **Response ⇒ performed.** When `mem_rsp_valid` is seen for a store the data is visible to any request the
   coalescer issues afterwards (on either port); when it is seen for a load the data was read from the
   state that includes every earlier store whose response was already delivered.
3. **Ordering.** With `DS_OOO = 1` the downstream may perform and answer requests in any order. With
   `DS_OOO = 0` it must perform **all** ordinary requests in issue order and answer them in issue order
   (a violation is flagged in `stat_proto_err`, not corrected). Atomics must be **performed in issue order**
   on the atomic port; their responses may be reordered.
4. **Masks.** Honour `mem_req_mask` for writes (bytes outside it must not change). For reads only bytes inside the
   mask are consumed.
5. **Errors.** Signal failure with `*_rsp_err`; a failed write must not partially update the line.
6. **No spontaneous responses.** Spurious, duplicate and late responses are *tolerated* (dropped and counted), but a
   response for a tag whose request is still sitting in the coalescer's output register — not yet accepted —
   is indistinguishable from a real one and would be misattributed.

### 5.2 What the requester (LSU) must do

1. Obey the valid/ready rules; use `req_uid` (captured at the handshake) or `rsp_id` to match responses; echo state
   in `req_tag`.
2. Accept responses in any order unless `UP_INORDER = 1`, and always eventually assert `rsp_ready`
   (slots are held until then).
3. Treat `rsp_err != 0` as a precise per-lane fault (`rsp_err_mask`); data of those lanes is undefined; other lanes
   completed normally.
4. Use `FENCE` (or wait for the response of every older request) wherever a later instruction must not overtake
   an earlier one *across different byte ranges*.
5. Sizes: `req_size ≤ log2(MAX_ACC_BYTES)`; atomics ≤ 8 bytes and naturally aligned.

### 5.3 Mapping to common downstream protocols

* **AXI4 / AXI5.** One tag = one ARID/AWID value (≤ `NUM_MEM_TAGS` distinct ids). Load → AR, `mem_rsp_rdata` is the
  R data (assemble beats), `RRESP != OKAY` → `mem_rsp_err`. Store → AW+W with `WSTRB = mem_req_mask`, B response →
  `mem_rsp_valid`. Different ids may complete out of order, so use **`DS_OOO = 1`**. Do *not* use `DS_OOO = 0` merely
  because you use one id: AXI does not order the read and write channels against each other.
  Atomics can use AXI5 atomic transactions or a separate L2 atomic unit that performs in arrival order.
* **TileLink / CHI / custom NoC.** Same: tag = source id, response = grant/ack, set `DS_OOO` according to whether
  the fabric can reorder requests to the same line.

## 6. Sizing

Little's law governs throughput (measured in `RESULTS.md` §6 at 92–99 % of the bound; 79 % at 16 slots, where the one-transaction-per-cycle limit also binds):

| to sustain | provision |
|---|---|
| *r* ordinary transactions per cycle at downstream latency *L* | `NUM_MEM_TAGS ≥ r · L` |
| *r* atomic operations per cycle | `NUM_ATM_TAGS ≥ r · L` |
| *i* instructions per cycle at instruction latency *L_i* (≈ `L + transactions + 5`) | `NUM_INSTR_SLOTS ≥ i · L_i` |

The simulation defaults (16 / 8 / 8) suit a 20-cycle downstream; for a 200-cycle L2 you want tens of tags and
slots. Cost: each slot stores a whole instruction plus its read buffer (`NUM_LANES × (ADDR_W + 17·MAX_ACC_BYTES + ATOM_W)` bits);
each tag stores a line address, a `TXN_BYTES` mask and two lane masks.

Typical geometries: 32 lanes × 4 B with 128-byte lines (`MAX_ACC_BYTES = 8`, `TXN_BYTES = 128`); 16 lanes with
64-byte lines; 64 lanes with 256-byte sectors — all three are in the regression.

## 7. Example instantiation

```systemverilog
import gpu_coalescer_pkg::*;
localparam int LANES = 32, AW = 40, ACC = 8, LINE = 128, NS = 16, NM = 64, NA = 16;

gpu_coalescer #(
  .NUM_LANES(LANES), .ADDR_W(AW), .MAX_ACC_BYTES(ACC), .TXN_BYTES(LINE),
  .NUM_INSTR_SLOTS(NS), .NUM_MEM_TAGS(NM), .NUM_ATM_TAGS(NA),
  .USER_TAG_W(12), .UID_W(32), .ADDR_LIMIT(0),
  .COALESCE_EN(1), .ALLOW_MISALIGNED(1), .DS_OOO(1), .UP_INORDER(0), .TIMEOUT_CYCLES(4096)
) u_coal (
  .clk, .rst_n,
  .req_valid(lsu_valid), .req_ready(lsu_ready), .req_op(lsu_op), .req_size(lsu_size), .req_amo(lsu_amo),
  .req_mask(lsu_mask), .req_addr(lsu_addr), .req_be(lsu_be), .req_wdata(lsu_wdata),
  .req_wdata2(lsu_wdata2), .req_tag({warp_id, dst_reg}), .req_uid(lsu_uid), .req_id(lsu_slot),
  .rsp_valid(wb_valid), .rsp_ready(wb_ready), .rsp_uid(wb_uid), .rsp_id(wb_slot), .rsp_tag(wb_tag),
  .rsp_op(wb_op), .rsp_rdata(wb_data), .rsp_err(wb_err), .rsp_err_mask(wb_err_lanes),
  .mem_req_valid, .mem_req_ready, .mem_req_id, .mem_req_write, .mem_req_addr, .mem_req_mask, .mem_req_wdata,
  .mem_rsp_valid, .mem_rsp_ready, .mem_rsp_id, .mem_rsp_rdata, .mem_rsp_err,
  .atm_req_valid, .atm_req_ready, .atm_req_id, .atm_req_op, .atm_req_size, .atm_req_addr, .atm_req_a, .atm_req_b,
  .atm_rsp_valid, .atm_rsp_ready, .atm_rsp_id, .atm_rsp_rdata, .atm_rsp_err,
  .idle, .stat_instr_accepted, .stat_instr_completed, .stat_mem_txns, .stat_mem_useful_bytes,
  .stat_atm_ops, .stat_err_instr, .stat_rsp_spurious, .stat_rsp_late, .stat_timeouts, .stat_proto_err
);
```

Set `TIMEOUT_CYCLES` comfortably above the worst-case downstream latency *including* queueing; a watchdog that
fires on a healthy response turns it into an error and a zombie tag.

## 8. Timing, area and pipelining

* **Critical path.** The leader search → match → byte-merge → hazard-compare → tag-allocate chain is one
  combinational cycle (leader search is a priority encoder over `NUM_LANES`, the match is `NUM_LANES` line
  comparators, the merge is a `NUM_LANES × MAX_ACC_BYTES` byte crossbar into `TXN_BYTES`, the hazard check is
  `(NUM_MEM_TAGS + NUM_ATM_TAGS)` mask comparators). It simulates and synthesises, but it is **not** claimed
  to close timing at multi-GHz clocks. The natural split for a fast clock is: stage 1 = leader + match →
  register `m_lo/m_hi/ldr_line`; stage 2 = merge + hazard + commit. The response scatter (`rd_mem_new`) can be
  registered the same way. Both splits keep the interface and the tag/slot logic unchanged.
* **Synthesisability.** Yosys (with the slang front end) elaborates and synthesises the design; the generic
  `synth` + `check -assert` run on an 8-lane / 8-byte-access / 32-byte-transaction / 4-slot geometry reported
  **0 problems** (no latches, combinational loops or multiple drivers) and about 124 k generic gate cells and
  8.8 k flip-flops (technology-independent estimate, not a place-and-route figure; most flops are the slot
  storage). The 32-lane × 128-byte default geometry exceeded the memory of the WebAssembly Yosys build used here,
  so it was verified by simulation and lint only.
* **Clock/reset.** Single clock, synchronous reset, no CDC inside. Put a CDC FIFO outside if the requester and
  memory run on different clocks.
* **Power/area levers.** Fewer lanes per instruction cycle (split a warp into half-warps), smaller `MAX_ACC_BYTES`,
  smaller `NUM_INSTR_SLOTS` (slot storage dominates), narrower `UID_W`.

## 9. Bring-up checklist

1. `make test` (lint + model tests + quick regression) in this repository.
2. Re-run the regression with *your* geometry: add a `Config` to `scripts/simlib.py` (`-G` overrides + matching
   generator flags) and run `scripts/run_regression.py --configs yours`.
3. In your own bench, check: `stat_proto_err == 0`, `stat_rsp_spurious == 0`, `stat_timeouts == 0` in normal
   operation; `stat_instr_accepted - stat_instr_completed` equals the in-flight count; `idle` after drain.
4. If `stat_proto_err` is set: with `DS_OOO = 0` the downstream is reordering (use `DS_OOO = 1`); otherwise it
   answered a tag that was not outstanding.
5. Watch `stat_mem_useful_bytes / (stat_mem_txns · TXN_BYTES)` to see how well real kernels coalesce.

## 10. Limitations

* One requester interface; no cross-requester ordering or coherence.
* No store-to-load forwarding; a load overlapping an in-flight store waits for its response.
* The watchdog leaks a tag if a response never arrives; recover by reset.
* Formal proofs (see `VERIFICATION.md`) cover tiny geometries and safety properties; large geometries and
  liveness rely on simulation, a liveness argument and the lost-request watchdog in the testbench.
* Counters are 32 bits and wrap.
