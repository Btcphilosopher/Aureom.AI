# Verification

The claim to establish: **every accepted request completes exactly once or produces an explicit error,
and the downstream traffic and data it produces are what the architectural memory model prescribes.**
The evidence is layered so that no single mechanism has to be trusted on its own. Current numbers are in
[`results/SUMMARY.md`](../results/SUMMARY.md) (generated from the raw result files by `make summary`).

## 1. Layers

| layer | what | where | proves |
|---|---|---|---|
| L1 | Python model self-tests (12 tests incl. transaction-level equivalence over random streams, 5 geometries × coalesced/baseline × 10 access classes) | `model/test_model.py` | the transaction list the RTL is *expected* to emit preserves the golden memory semantics (S1–S8) |
| L2 | RTL regression against the Python model: exact downstream stream, read data, errors, final memory, counters, under random back-pressure, latency and response reordering; 12 geometries × 9 access classes × 3 timing profiles + directed runs | `scripts/run_regression.py`, `tb/` | the RTL implements the model, bit-exactly, under adversarial timing |
| L3 | Assertions: embedded RTL invariants (I1–I6), SVA protocol checker (P1–P6), interface bookkeeping (B1–B7), downstream-model ordering check | `rtl/gpu_coalescer.sv` §12, `tb/coalescer_checker.sv`, `tb/ds_model.sv` | no protocol or accounting violation occurs in any simulated state |
| L4 | Mutation testing: 10 injected RTL defects, plus a black-box-only confirmation | `scripts/mutation.py` | L2 + L3 are able to fail; they are not vacuous |
| L5 | Formal proof (Yosys SAT, base case + induction) of the accounting invariants X1–X11 for tiny geometries and all environment behaviours | `formal/` | the safety half of "exactly once" holds for **every** input sequence, including spurious / duplicate / late responses |

## 2. Requirement traceability

| requirement | implementation | verification |
|---|---|---|
| combine compatible lane accesses into aligned transactions | leader/match/merge (`ARCHITECTURE.md` §3) | L2: exact transaction stream (line, byte mask, write data) equals Python `build_txns`; L1 equivalence; P4 (aligned, non-empty mask) |
| configurable lane count, access widths, transaction size, outstanding capacity | parameters `NUM_LANES`, `MAX_ACC_BYTES` (+ per-instruction `req_size`), `TXN_BYTES`, `NUM_INSTR_SLOTS`, `NUM_MEM_TAGS`, `NUM_ATM_TAGS` | L2 runs 12 geometries (1/4/8/16/32/64 lanes, 2/4/8/16-byte accesses, 2/16/32/64/128/256-byte transactions, 12/16/24/32/64-bit addresses, 1–16 slots, 1–32 tags, non-powers-of-two, transaction size equal to access size, address space equal to the aperture); capacity sweep in `RESULTS.md` §6 |
| active-lane masks | `req_mask`, partial / sparse / empty masks | generator draws full, random, single-lane, prefix and **empty** masks; golden checks inactive lanes read 0 |
| byte enables | `req_be`, applied in merge and read scatter | `overlap`/`contiguous` patterns draw random and shared byte enables; mutant `MUT_IGNORE_BE` killed |
| accesses spanning transaction boundaries | low/high part split | `crossing` pattern (incl. adjacent lanes sharing a boundary transaction); mutant `MUT_DROP_HI_PART` killed |
| read-response assembly | `rd_mem_new` scatter from response lines, per-lane buffers | bit-exact read data vs golden for every lane of every load; the memory model returns garbage outside the request mask so unmasked bytes cannot be silently used |
| store completion tracking | `s_nout` per slot, completion only when `idone && nout==0` | TB checks that **every** downstream operation of a request was performed before its response (loads, stores, atomics, fences); I2/X2 invariants; mutant `MUT_EARLY_COMPLETE` killed (black-box too) |
| unique request identifiers | `uid` (global, monotonic), slot id (unique in flight), downstream tags (unique outstanding) | B1/B2/B7; X8; TB checks `req_uid == accept count` and `rsp_uid` matches |
| out-of-order responses where the protocol allows | tag-matched downstream responses; `DS_OOO`; optional in-order upstream | memory model completes in random order (`+REORDER=1`); `inorder_ds` geometry runs the in-order contract; `UP_INORDER` geometry checks B6 |
| preserve memory semantics | in-order issue + byte-mask hazard interlock; S1–S9 | the memory model **performs at service time**, so ordering bugs corrupt data; mutants `MUT_NO_HAZARD`, `MUT_ATM_NO_XHAZARD`, `MUT_LOWEST_LANE_WINS` killed |
| atomics on a separate path, not merged as stores | `atm_*` port, own tags, one op per lane | atomic stream checked op-by-op (opcode, size, address, operands); `atomic`/`hazard` patterns; `MUT_ATOMIC_REVERSE` killed; counts equal in coalesced and baseline builds |
| Python byte-addressed reference memory + contiguous / strided / scattered / overlapping / boundary-crossing generators | `model/coalescer_model.py` (`ByteMemory`), `model/gen_stimulus.py` | those exact classes are the `contiguous`, `strided`, `scatter`, `overlap`, `crossing` patterns |
| compare transactions/instruction, useful bytes/txn, latency, throughput vs uncoalesced baseline | `COALESCE_EN=0` build; `scripts/bench.py` | `docs/RESULTS.md`; RTL transaction counts equal the Python model's prediction in every benchmark run |
| random back-pressure and response reordering | memory model + TB knobs | profiles `stress`/`heavy` randomise request ready, response gaps, latency, ordering, `rsp_ready`, request gaps |
| each accepted request completes exactly once or yields an explicit error | §3 below | L2 scoreboard, L3 B1–B7, L5 X1–X8 |

## 3. Why every accepted request completes exactly once or errors

**Mechanism.** A request owns a slot from the accept handshake to the response handshake. A slot is freed
only by `rsp_fire`, and `rsp_fire` can only occur for the slot held in the response register. The response
register is loaded only with a slot that is occupied, fully issued, has nothing outstanding and is not already
locked; the lock stays set until the slot is freed. So a slot yields at most one response, and a freed
slot is a different request when it is re-allocated (it gets a fresh `uid`).

**Invariants** (each one is checked at three levels):

| invariant | statement | RTL assertion | SVA/TB | formal |
|---|---|---|---|---|
| conservation | accepted − completed = occupied slots | I1 | B5, final accounting | X1 |
| no stray completion | a slot's outstanding counter equals the live downstream tags naming it; never under/overflows | I2 | per-request completion tracking | X2 |
| single, valid response | only occupied, finished, locked slots are presented; ≤ 1 locked | I4 | P2 (stable), B3, B4 | X3 |
| tags | allocated only when free, retired only when valid; zombies are valid | I3 | B7 | X4 |
| unique ids | uids increase by one per accept; occupied slots hold distinct uids | — | B1, B2 | X5, X6, X8 |
| exactly once | a tracked uid is never completed before accept, twice, or accepted twice | — | B3, B4 (all uids) | X5 (arbitrary uid) |
| ordering | no two live accesses with overlapping bytes and a writer are outstanding together | I5 | downstream-model ordering check | — (simulation) |

**Explicit errors.** Anything the unit cannot or should not do ends in a response with `rsp_err != 0` and a
lane mask, never in a silent drop: illegal encodings, misaligned atomics (and misaligned accesses when
disallowed), out-of-aperture addresses, downstream error status, and downstream silence (watchdog). Each class
is generated by the `errors`, `fault` and `timeout` patterns and compared against the Python model's exact
flags and lane masks. Downstream protocol violations (spurious/duplicate/late responses) are *not* allowed to
complete or fail anything: they are dropped, counted and flagged (`stat_rsp_spurious`, `stat_rsp_late`,
`stat_proto_err`); the `dup-injection` runs show that requests are unaffected.

**Liveness (informal).** A request completes if (i) the downstream answers every transaction or the watchdog is
on, and (ii) the requester eventually asserts `rsp_ready`. Given these, every stage is monotone and cannot block
indefinitely: responses are never back-pressured (resources are pre-reserved), tags are freed by responses,
a hazard is released by the response of the older conflicting access (which does not depend on the younger one),
the output register drains when the downstream is ready, pending parts are cleared at each commit, and the
in-order sequencer advances whenever the head instruction has issued. The testbench enforces this empirically
with a global watchdog and a final "every uid completed" check; the formal proof covers safety only.

**Not claimed.** Cross-requester ordering, coherence, and liveness under a downstream that never answers while
the watchdog is off.

## 4. Testbench architecture

```
 Python model ──► vectors/*.hex ──► driver ──► DUT ──► ds_model (memory, 2 ports) ──► DUT responses
   (golden semantics,                │            │         ▲ random latency, back-pressure, reordering,
    expected txn stream,             │            │         │ fault/hole/slow regions, duplicate injection
    expected results, memory)        │            ▼
                                     └─────► scoreboard + stream monitors + coalescer_checker (SVA) + metrics
```

Per run the testbench checks: exactly-once and identity (uid/slot/tag/op) per response; error flags and lane
mask; read data of every non-failing lane; the ordinary and atomic downstream streams (count, order, address,
mask, write data / opcode, size, operands); per-request completion tracking and fence ordering; final memory
image; every DUT performance counter; `idle` at the end; downstream-model flags (ordering, tag reuse, alignment);
and the lost-request watchdog.

**Randomisation / reproducibility.** The Python generator is seeded; the testbench uses its own xorshift PRNG
seeded by `+SEED`, so runs are bit-reproducible across simulators and machines.

## 5. Mutation testing

`rtl/gpu_coalescer.sv` carries ten compile-time defect hooks (`MUT_*`). `scripts/mutation.py` builds each, runs a
10-test battery and requires at least one failure; an unmutated control must pass the same battery. In addition, the
three ordering/completion mutants are re-run with every white-box check removed (RTL assertions compiled out,
memory-model ordering check off) to show that the golden-data, final-memory and completion-tracking checks
alone catch them.

## 6. Formal

See `formal/README.md`. Unbounded proof of X1–X11 for tiny geometries (and six design variants) against all
environment behaviours satisfying a minimal contract that explicitly allows spurious, duplicate, late and
out-of-range downstream responses; non-vacuity covers; two mutants refuted.

## 7. Reproduce

```
make test        # ~2 min
make regress     # ~2 min
make mutation    # ~2-3 min
make bench       # ~4 min      -> docs/RESULTS.md
make formal      # ~6 min      (pip install yowasp-yosys)
make all && cat results/SUMMARY.md
```

Add your own geometry: append a `Config` in `scripts/simlib.py` (the `-G` overrides plus the matching generator flags)
and run `python3 scripts/run_regression.py --configs yours`. Add an access class: a method on `Gen` in
`model/gen_stimulus.py` and a name in `PATTERNS`.

## 8. Known gaps

* Formal proofs: tiny geometries, safety only (details in `formal/README.md`).
* Simulation uses one clock and zero-delay logic: no timing, CDC or X-propagation checks (Verilator is two-state).
* The downstream model is behavioural; real memory systems may reorder in ways it does not (it reorders
  arbitrarily within the documented contract).
* Random streams of a few hundred instructions per run (several thousand per geometry); the regression is broad
  rather than long — extend `--n` and the seed lists for soak runs.
