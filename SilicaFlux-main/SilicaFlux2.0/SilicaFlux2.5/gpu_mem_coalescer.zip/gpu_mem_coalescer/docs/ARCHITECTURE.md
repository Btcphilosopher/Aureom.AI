# Architecture and memory semantics

`rtl/gpu_coalescer.sv` turns one warp-wide memory instruction (up to `NUM_LANES` per-lane accesses) into
the smallest practical number of aligned `TXN_BYTES` transactions, tracks them to completion, assembles
read data, and returns exactly one response per accepted instruction.

```
              upstream (LSU / warp scheduler)                        downstream (L1 / L2 / NoC)
   req ──►┌───────────────────────────────────────────────────────────────┐──► mem_req  (ordinary, merged)
          │  accept: per-lane legality, part split, error pre-screen      │◄── mem_rsp  (tag, data, err)
          │        │                                                      │
          │   ┌────▼─────┐   in-order    ┌──────────────┐  tag + hazard   │──► atm_req  (separate path,
          │   │ instr    ├──────────────►│ issue engine │  interlock      │               one op per lane)
          │   │ slots    │  seq counter  │ leader/merge │◄───────────────►│◄── atm_rsp  (tag, old value, err)
          │   │ (N)      │◄──────────────┤ + atomic     │ mem tags (NM)   │
          │   └────▲─────┘  nout, err,   │   sequencer  │ atm tags (NA)   │
          │        │        read data    └──────────────┘ watchdog        │
   rsp ◄──┤  response select (round-robin / in-order) ◄ completion track ◄┘
          └───────────────────────────────────────────────────────────────┘
```

## 1. Life of an instruction

| step | what happens | where |
|---|---|---|
| accept | a free slot is allocated; the request is captured whole (addresses, byte enables, data); every lane is pre-screened for illegal size / alignment / range; each surviving lane is split into a *low part* (bytes in the line containing `addr`) and a *high part* (bytes that spill into the next line) — a part exists only if some enabled byte lands there. A unique `uid` is assigned. | `acc_*` logic, slot arrays |
| issue | slots are issued strictly in accept order (the low bits of `uid` are the ordering key). Each cycle one transaction is built from the head slot (§3). | `head_*`, `ldr_*`, `m_lo/m_hi`, `c_mask/c_data` |
| track | every committed transaction takes a downstream tag, increments the slot's outstanding counter `s_nout`, and is remembered in the tag table with its line, byte mask and the lanes it serves. | `mt_*`, `at_*` tables |
| respond (downstream) | a response is matched by tag, its data is scattered into the per-lane read buffers of the owning slot (`rd_mem_new`), `s_nout` is decremented, errors are accumulated. | §5 of the RTL |
| complete | when all transactions are *issued* (`s_idone`) and none is outstanding (`s_nout == 0`) the slot is *done*. A done slot is locked into the response register (round-robin, or oldest-first if `UP_INORDER`), presented on `rsp_*`, and freed on the `rsp_valid && rsp_ready` handshake. | `done_v`, `sel_*`, `rsp_*` |

Resources (slot, per-lane read buffer) are reserved at accept time, so **downstream responses never
need to wait for anything**. `mem_rsp_ready` and `atm_rsp_ready` are therefore constant 1, which removes
the classic response-channel deadlock.

## 2. Memory semantics (the contract the verification checks)

These are the architectural rules; `model/coalescer_model.py::execute` is their executable form.

| # | rule |
|---|---|
| S1 | **Program order per byte.** For two instructions from the one requester, a later access observes the effect of every earlier access to an overlapping byte. Accesses that do not overlap in bytes are unordered. Enforced by in-order issue + the hazard interlock (§4). |
| S2 | **Intra-instruction loads.** All lanes of one load observe the same memory state. Lanes with disabled bytes receive **zero** in those bytes. |
| S3 | **Intra-instruction stores.** When several lanes write the same byte the **highest lane index wins**, per byte. Byte enables are honoured exactly: a disabled byte is never written. |
| S4 | **Boundary crossing.** An access straddling a `TXN_BYTES` boundary is performed as two parts in two transactions; the lane's data is reassembled from both. A byte-enable pattern that leaves one side empty produces no transaction on that side. |
| S5 | **Atomics.** Each active lane performs one indivisible read-modify-write at the downstream atomic unit, returning the old value. Lanes execute in **ascending lane order**; same-address lanes therefore see each other's results. Atomics are **never merged** with each other or with stores. They are ordered against overlapping ordinary accesses exactly like stores. Operand width is `2^size` bytes (≤ 8); operands and results wrap at that width. |
| S6 | **Completion implies performed.** A response is generated only after every downstream operation of the instruction has been answered. A store's response therefore means its data is visible to any request issued afterwards. |
| S7 | **Fence.** A `FENCE` completes only after every older load, store and atomic has been answered; younger instructions are not issued until then. |
| S8 | **Errors are lane-precise and explicit.** A lane that fails an accept-time check (illegal encoding, alignment, range) performs **no** memory access at all. A lane hit by a downstream error or timeout is reported as failed, but its *other* part (if it straddles two transactions) may already have been performed — downstream failures are per transaction, not per lane. The other lanes of the instruction always proceed normally. The response carries an error-flag vector and the mask of failing lanes; read data of failing lanes is undefined. |
| S9 | **Exactly one response.** Every accepted instruction produces exactly one response — success or explicit error — and each `uid` is delivered once. |

Not provided (by design, document these in the system that contains the coalescer): ordering **between
different requesters**, store-to-load forwarding (a load that hits an in-flight store waits for the
store's response), memory consistency models beyond S1–S7, and cache coherence.

## 3. The coalescing algorithm

Per cycle, for the head slot:

1. **Leader**: the lowest-numbered lane with a pending part (its low part before its high part).
   `sel_line = leader's line`.
2. **Match**: every pending part whose line equals `sel_line` joins the transaction —
   low parts with `addr>>log2(TXN) == sel_line`, high parts with `(addr>>log2(TXN)) + 1 == sel_line`.
   With `COALESCE_EN = 0` only the leader joins: this *is* the uncoalesced baseline.
   For atomics only the leader joins, always.
3. **Merge**: matched parts are written into a `TXN_BYTES` image in ascending lane order
   (so the highest lane wins on overlap, rule S3), producing `c_mask` (bytes touched) and `c_data`.
4. **Commit** (if an output-register slot, a free tag and no hazard are available): allocate the tag,
   register the downstream request, clear the matched parts from the slot.

The number of cycles an instruction spends in the issue engine equals its number of transactions (≥ 1
cycle even if it has none, to pass the in-order sequencer). The sequence is fully deterministic and is
mirrored bit-for-bit by `build_txns` in the Python model, which is how the testbench checks the *exact*
downstream transaction stream.

Worked example, `TXN_BYTES = 128`: an 8-byte store by lane 3 at `0x7D` (offset 125).
`lo_cnt = min(8, 128-125) = 3`: bytes 0–2 → line `0x00` offsets 125–127 (mask `0b111<<125`);
bytes 3–7 → line `0x80` offsets 0–4 (mask `0b11111`). Lane 4 at `0x84` joins the second transaction.

## 4. Ordering interlock

A candidate transaction (line `L`, byte mask `M`, write-or-read) may not be committed while an
**outstanding, non-timed-out** access conflicts with it:

| candidate \ outstanding | ordinary read | ordinary write | atomic |
|---|---|---|---|
| ordinary read  | allowed | wait if bytes overlap | wait if bytes overlap |
| ordinary write | wait if overlap | wait if overlap | wait if overlap |
| atomic         | wait if overlap | wait if overlap | allowed (atomic port is in-order per address) |

The ordinary-vs-ordinary cells (first two rows × first two columns) apply only when `DS_OOO = 1`, i.e. when
the downstream may perform out of order. With `DS_OOO = 0` the downstream is required to perform ordinary
accesses in issue order, that interlock is removed, and an in-order **checker** instead flags any violation of
the contract (`stat_proto_err`). Every cell involving an atomic is always enforced: the two downstream ports
are not ordered with respect to each other.

The overlap test is on **byte masks**, not whole lines, so accesses to different bytes of one line do not
serialise. The interlock is evaluated against the tag table every cycle; an outstanding entry disappears
the cycle after its response is processed.

## 5. Atomic path

* `atm_req_*` / `atm_rsp_*` is a distinct port with its own tag pool (`NUM_ATM_TAGS`).
* One request per active lane, ascending lane order, one lane per cycle at most.
* Request fields: opcode (`ADD AND OR XOR MIN MAX MINU MAXU EXCH CAS`), size, address, operand A, operand B (CAS swap value).
  Operands are truncated to the access width.
* Downstream contract: perform atomics **in issue order**; responses (old value) may be reordered by tag.
* Misaligned atomics are errors (`ERR_ALIGN`); an unknown opcode or size is `ERR_ILLEGAL`.

## 6. Tag tables, response handling and read-data assembly

* A response is **live** if its tag is valid and not a zombie; **late** if it names a timed-out (zombie) tag
  — dropped, tag freed; **spurious** otherwise (free tag, out-of-range id) — dropped, counted,
  `stat_proto_err` set. Dropped responses never touch slot state.
* For loads, each lane that the transaction serves (`mt_slo` / `mt_shi`) has its enabled bytes copied from
  the response line at offset `(addr mod TXN_BYTES) + k` (low part) or `… − TXN_BYTES` (high part)
  into the slot's read buffer. Bytes outside the request mask are never used (the testbench's downstream
  model returns garbage there to prove it).
* Per-slot bookkeeping is deliberately event-based: issue (+1), ordinary response (−1), atomic response (−1)
  and watchdog expiry (−1) may hit one slot in the same cycle; `ev_inc/ev_dec` aggregate them.

## 7. Errors

| flag (`rsp_err` bit) | meaning | raised when | lanes in `rsp_err_mask` |
|---|---|---|---|
| 0 `ILLEGAL`    | encoding | `size` above the configured maximum, atomic size > 8, atomic opcode > 9 | all active lanes |
| 1 `ALIGN`      | alignment | atomic not naturally aligned; any misaligned access when `ALLOW_MISALIGNED = 0` | offending lanes |
| 2 `RANGE`      | aperture | highest enabled byte ≥ `ADDR_LIMIT` (or wraps past 2^`ADDR_W`) | offending lanes |
| 3 `DOWNSTREAM` | downstream status | `*_rsp_err` on a transaction serving the lane | lanes served by that transaction |
| 4 `TIMEOUT`    | watchdog | no response within `TIMEOUT_CYCLES` | lanes served by that transaction |

Flags OR together. Instructions with no active lane, or with no enabled byte, complete successfully with
no traffic.

### Watchdog (optional, `TIMEOUT_CYCLES > 0`)
Each outstanding tag has an age counter. On expiry the transaction is completed **with `TIMEOUT`** and its
tag becomes a *zombie*: still reserved (so a late response cannot be mistaken for a newer request's),
ignored by the hazard interlock, freed when a late response arrives. A response that never arrives
permanently leaks one tag (visible in `stat_timeouts`); the recovery is a reset of the whole unit. After a
timeout the state of the affected bytes is architecturally undefined.

## 8. Timing behaviour

* Accept → first downstream request: 2 cycles. One transaction can be committed per cycle.
* Downstream response → `rsp_valid`: 2 cycles (counter update, then selection and response register).
* Unloaded latency of a single-transaction instruction ≈ downstream latency + 5 cycles
  (measured 24.4 – 24.9 cycles with a 20-cycle downstream).
* Sustained limits (Little's law, confirmed in `docs/RESULTS.md` §6): instructions/cycle ≤
  `NUM_INSTR_SLOTS` / instruction latency; transactions/cycle ≤ `NUM_MEM_TAGS` / transaction latency and ≤ 1.
* The leader/match/merge stage is a single combinational cycle — fine for a reference design and moderate
  clocks; see `docs/INTEGRATION.md` §8 for pipelining advice.

## 9. Design decisions worth knowing

* **One instruction in the issue engine at a time, one transaction per cycle.** Downstream bandwidth is the
  real limit; this keeps program order trivially correct.
* **Slots are reused, `uid` is not.** `rsp_id`/`req_id` are slot indices (unique among in-flight requests);
  `uid` increments forever (32-bit by default) and is unique over the run.
* **Uniform baseline.** `COALESCE_EN = 0` re-uses every other mechanism (tags, hazards, errors), so
  benchmark differences are due to merging alone.
* **Verification hooks.** `MUT_*` macros and the `FORMAL` block in the RTL are inert unless defined.
