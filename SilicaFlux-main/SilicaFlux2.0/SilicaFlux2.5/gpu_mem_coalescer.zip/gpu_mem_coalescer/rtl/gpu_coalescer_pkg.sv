// =============================================================================
// gpu_coalescer_pkg.sv
//
// Shared constants for the GPU memory coalescer: opcodes, atomic operation
// codes and error-flag bit positions.  Plain localparams (no enums/structs) so
// the package is accepted by Verilator, Yosys and commercial front ends alike.
// =============================================================================
package gpu_coalescer_pkg;

  // ---- Instruction opcodes (req_op / rsp_op) --------------------------------
  localparam logic [1:0] OP_LOAD   = 2'd0;  // per-lane loads, coalesced
  localparam logic [1:0] OP_STORE  = 2'd1;  // per-lane stores, coalesced
  localparam logic [1:0] OP_ATOMIC = 2'd2;  // per-lane atomics, NEVER merged
  localparam logic [1:0] OP_FENCE  = 2'd3;  // completes when all older traffic is performed

  // ---- Atomic operation codes (req_amo / atm_req_op) ------------------------
  localparam logic [3:0] AMO_ADD  = 4'd0;
  localparam logic [3:0] AMO_AND  = 4'd1;
  localparam logic [3:0] AMO_OR   = 4'd2;
  localparam logic [3:0] AMO_XOR  = 4'd3;
  localparam logic [3:0] AMO_MIN  = 4'd4;   // signed
  localparam logic [3:0] AMO_MAX  = 4'd5;   // signed
  localparam logic [3:0] AMO_MINU = 4'd6;   // unsigned
  localparam logic [3:0] AMO_MAXU = 4'd7;   // unsigned
  localparam logic [3:0] AMO_EXCH = 4'd8;
  localparam logic [3:0] AMO_CAS  = 4'd9;   // compare (operand A) / swap (operand B)
  localparam int         AMO_LAST = 9;      // highest legal encoding

  // ---- Error flags (rsp_err is a bit-vector: several may be set) ------------
  localparam int ERR_W            = 5;
  localparam int ERR_BIT_ILLEGAL    = 0;    // illegal size / atomic opcode
  localparam int ERR_BIT_ALIGN      = 1;    // misaligned atomic (or any misaligned access
                                            // when ALLOW_MISALIGNED = 0)
  localparam int ERR_BIT_RANGE      = 2;    // enabled byte outside [0, ADDR_LIMIT)
  localparam int ERR_BIT_DOWNSTREAM = 3;    // downstream returned an error status
  localparam int ERR_BIT_TIMEOUT    = 4;    // watchdog expired before a response arrived

endpackage
