// =============================================================================
// gpu_coalescer.sv  --  GPU warp-level memory access coalescer
//
// Accepts one warp-wide memory instruction per handshake (NUM_LANES lanes, each
// with its own address / byte-enables / data) and turns it into aligned
// TXN_BYTES-sized downstream transactions with byte masks.
//
//   * Loads / stores : lane accesses that land in the same aligned line are
//                      merged into ONE transaction.  An access that straddles
//                      a line boundary is split into a low part and a high
//                      part that coalesce independently.
//   * Atomics        : never merged.  One operation per active lane, issued in
//                      ascending lane order on a SEPARATE downstream port with
//                      its own tag pool.
//   * Fence          : completes once every older operation has been performed.
//   * Ordering       : a byte-overlap hazard interlock over the outstanding
//                      tag tables preserves program order for conflicting
//                      accesses even though the downstream may perform and
//                      respond out of order (DS_OOO = 1).
//   * Completion     : every accepted instruction gets EXACTLY ONE upstream
//                      response, carrying read data (assembled from the
//                      downstream responses) and an explicit error code / lane
//                      mask when anything went wrong.
//
// COALESCE_EN = 0 turns the same RTL into the *uncoalesced baseline*: one
// downstream transaction per lane-part, same handshakes, same hazards.
//
// Reset: synchronous, active low.  Reset must only be applied while idle.
//
// Verification-only hooks (inert unless the macro is defined; never needed in a product build):
//   MUT_*     deliberately injected defects used by scripts/mutation.py
//   FORMAL    extra input `f_x_in` and the invariant monitors of section 13 (formal/run_formal.sh)
//   SYNTHESIS removes the simulation-only assertions of section 12
//
// See docs/ARCHITECTURE.md and docs/INTEGRATION.md.
// =============================================================================
`default_nettype none

/* verilator lint_off UNSIGNED */
module gpu_coalescer
  import gpu_coalescer_pkg::*;
#(
  parameter int              NUM_LANES        = 32,   // lanes per warp instruction
  parameter int              ADDR_W           = 32,   // byte-address width
  parameter int              MAX_ACC_BYTES    = 8,    // widest per-lane access (power of 2, >= 2)
  parameter int              TXN_BYTES        = 128,  // aligned transaction size (power of 2, >= MAX_ACC_BYTES)
  parameter int              NUM_INSTR_SLOTS  = 8,    // outstanding upstream instructions
  parameter int              NUM_MEM_TAGS     = 16,   // outstanding downstream load/store transactions
  parameter int              NUM_ATM_TAGS     = 8,    // outstanding downstream atomic operations
  parameter int              USER_TAG_W       = 8,    // opaque requester tag, echoed in the response
  parameter int              UID_W            = 32,   // width of the global unique request id
  parameter longint unsigned ADDR_LIMIT       = 0,    // exclusive upper bound of legal addresses (0 = 2^ADDR_W)
  parameter bit              COALESCE_EN      = 1'b1, // 0 = uncoalesced baseline
  parameter bit              ALLOW_MISALIGNED = 1'b1, // 0 = misaligned load/store -> ERR_ALIGN
  parameter bit              DS_OOO           = 1'b1, // 1 = downstream may perform/respond out of order
                                                      // 0 = downstream performs in issue order (interlock off)
  parameter bit              UP_INORDER       = 1'b0, // 1 = upstream responses in request order
  parameter int              TIMEOUT_CYCLES   = 0,    // downstream watchdog (0 = disabled)

  // ---- Derived widths (do not override) ----
  localparam int SIZE_W    = ($clog2(MAX_ACC_BYTES) < 1) ? 1 : $clog2($clog2(MAX_ACC_BYTES) + 1),
  localparam int SLOT_W    = (NUM_INSTR_SLOTS <= 1) ? 1 : $clog2(NUM_INSTR_SLOTS),
  localparam int MTAG_W    = (NUM_MEM_TAGS    <= 1) ? 1 : $clog2(NUM_MEM_TAGS),
  localparam int ATAG_W    = (NUM_ATM_TAGS    <= 1) ? 1 : $clog2(NUM_ATM_TAGS),
  localparam int ATOM_W    = ((MAX_ACC_BYTES < 8) ? MAX_ACC_BYTES : 8) * 8
) (
  input  logic                                       clk,
  input  logic                                       rst_n,

  // ---------------- Upstream request channel (valid/ready) ------------------
  input  logic                                       req_valid,
  output logic                                       req_ready,
  input  logic [1:0]                                 req_op,        // OP_LOAD/STORE/ATOMIC/FENCE
  input  logic [SIZE_W-1:0]                          req_size,      // log2(bytes per lane access)
  input  logic [3:0]                                 req_amo,       // atomic opcode (OP_ATOMIC only)
  input  logic [NUM_LANES-1:0]                       req_mask,      // active-lane mask
  input  logic [NUM_LANES-1:0][ADDR_W-1:0]           req_addr,      // per-lane byte address
  input  logic [NUM_LANES-1:0][MAX_ACC_BYTES-1:0]    req_be,        // per-lane byte enables (bit k = byte k)
  input  logic [NUM_LANES-1:0][MAX_ACC_BYTES*8-1:0]  req_wdata,     // store data / atomic operand A
  input  logic [NUM_LANES-1:0][ATOM_W-1:0]           req_wdata2,    // atomic operand B (CAS swap value)
  input  logic [USER_TAG_W-1:0]                      req_tag,       // opaque, echoed in the response
  output logic [UID_W-1:0]                           req_uid,       // uid that WILL be given to this request
  output logic [SLOT_W-1:0]                          req_id,        // slot id that WILL be given to it

  // ---------------- Upstream response channel (valid/ready) ------------------
  output logic                                       rsp_valid,
  input  logic                                       rsp_ready,
  output logic [UID_W-1:0]                           rsp_uid,
  output logic [SLOT_W-1:0]                          rsp_id,
  output logic [USER_TAG_W-1:0]                      rsp_tag,
  output logic [1:0]                                 rsp_op,
  output logic [NUM_LANES-1:0][MAX_ACC_BYTES*8-1:0]  rsp_rdata,
  output logic [ERR_W-1:0]                           rsp_err,
  output logic [NUM_LANES-1:0]                       rsp_err_mask,

  // ---------------- Downstream: ordinary load/store port ---------------------
  output logic                                       mem_req_valid,
  input  logic                                       mem_req_ready,
  output logic [MTAG_W-1:0]                          mem_req_id,
  output logic                                       mem_req_write,
  output logic [ADDR_W-1:0]                          mem_req_addr,    // aligned to TXN_BYTES
  output logic [TXN_BYTES-1:0]                       mem_req_mask,    // bytes written / bytes needed
  output logic [TXN_BYTES*8-1:0]                     mem_req_wdata,

  input  logic                                       mem_rsp_valid,
  output logic                                       mem_rsp_ready,   // always 1: responses are never back-pressured
  input  logic [MTAG_W-1:0]                          mem_rsp_id,
  input  logic [TXN_BYTES*8-1:0]                     mem_rsp_rdata,
  input  logic                                       mem_rsp_err,

  // ---------------- Downstream: atomic port (separate path) ------------------
  output logic                                       atm_req_valid,
  input  logic                                       atm_req_ready,
  output logic [ATAG_W-1:0]                          atm_req_id,
  output logic [3:0]                                 atm_req_op,
  output logic [SIZE_W-1:0]                          atm_req_size,    // log2(bytes)
  output logic [ADDR_W-1:0]                          atm_req_addr,
  output logic [ATOM_W-1:0]                          atm_req_a,
  output logic [ATOM_W-1:0]                          atm_req_b,

  input  logic                                       atm_rsp_valid,
  output logic                                       atm_rsp_ready,   // always 1
  input  logic [ATAG_W-1:0]                          atm_rsp_id,
  input  logic [ATOM_W-1:0]                          atm_rsp_rdata,   // old value, zero-extended
  input  logic                                       atm_rsp_err,

  // ---------------- Status / performance counters ----------------------------
  output logic                                       idle,                // no instruction in flight
  output logic [31:0]                                stat_instr_accepted,
  output logic [31:0]                                stat_instr_completed,
  output logic [31:0]                                stat_mem_txns,
  output logic [31:0]                                stat_mem_useful_bytes, // sum of popcount(mem_req_mask)
  output logic [31:0]                                stat_atm_ops,
  output logic [31:0]                                stat_err_instr,        // completed with rsp_err != 0
  output logic [31:0]                                stat_rsp_spurious,     // downstream responses to non-outstanding tags (dropped)
  output logic [31:0]                                stat_rsp_late,         // late responses to timed-out tags (dropped)
  output logic [31:0]                                stat_timeouts,
  output logic                                       stat_proto_err         // sticky: spurious rsp or DS ordering violation
`ifdef FORMAL
  ,
  input  logic [UID_W-1:0]                           f_x_in                 // formal only: the symbolic uid being tracked
`endif
);

  // ===========================================================================
  // Derived constants
  // ===========================================================================
  localparam int LOG2_TXN   = $clog2(TXN_BYTES);
  localparam int LOG2_ACC   = $clog2(MAX_ACC_BYTES);
  localparam int ACC_W      = MAX_ACC_BYTES * 8;
  localparam int LINE_W     = ADDR_W - LOG2_TXN;
  localparam int ATOM_BYTES = (MAX_ACC_BYTES < 8) ? MAX_ACC_BYTES : 8;
  localparam int LOG2_ATOM  = $clog2(ATOM_BYTES);
  localparam int N          = NUM_INSTR_SLOTS;
  localparam int NM         = NUM_MEM_TAGS;
  localparam int NA         = NUM_ATM_TAGS;
  localparam int LANE_W     = (NUM_LANES <= 1) ? 1 : $clog2(NUM_LANES);
  localparam int NOUT_W     = $clog2(2 * NUM_LANES + 1);
  localparam int SEQ_W      = SLOT_W;                     // low uid bits order the in-flight instructions
  localparam int TO_W       = $clog2(TIMEOUT_CYCLES + 2);
  localparam logic [TO_W-1:0] TO_LIM = TIMEOUT_CYCLES[TO_W-1:0];
  localparam logic [ADDR_W:0] LIMIT  = (ADDR_LIMIT == 0) ? {1'b1, {ADDR_W{1'b0}}}
                                                         : ADDR_LIMIT[ADDR_W:0];

`ifndef SYNTHESIS
  initial begin
    if (MAX_ACC_BYTES < 2 || (MAX_ACC_BYTES & (MAX_ACC_BYTES - 1)) != 0)
      $fatal(1, "MAX_ACC_BYTES must be a power of two >= 2");
    if (TXN_BYTES < MAX_ACC_BYTES || (TXN_BYTES & (TXN_BYTES - 1)) != 0)
      $fatal(1, "TXN_BYTES must be a power of two >= MAX_ACC_BYTES");
    if (NUM_LANES < 1 || N < 1 || NM < 1 || NA < 1)
      $fatal(1, "NUM_LANES, NUM_INSTR_SLOTS, NUM_MEM_TAGS, NUM_ATM_TAGS must be >= 1");
    if (UID_W < SLOT_W)
      $fatal(1, "UID_W must be >= clog2(NUM_INSTR_SLOTS)");
    if (ADDR_W <= LOG2_TXN)
      $fatal(1, "ADDR_W must exceed log2(TXN_BYTES)");
  end
`endif

  // ===========================================================================
  // Helper functions
  // ===========================================================================
  // Low-n-ones mask over MAX_ACC_BYTES bits, 0 <= n <= MAX_ACC_BYTES.
  function automatic logic [MAX_ACC_BYTES-1:0] f_low_mask(input int n);
    logic [MAX_ACC_BYTES:0] t;
    t = ({{MAX_ACC_BYTES{1'b0}}, 1'b1} << n) - 1'b1;
    return t[MAX_ACC_BYTES-1:0];
  endfunction

  // Bytes per lane access for a size code (clamped; illegal codes are rejected elsewhere).
  function automatic int f_bytes(input logic [SIZE_W-1:0] sz);
    return (int'(sz) > LOG2_ACC) ? MAX_ACC_BYTES : (1 << int'(sz));
  endfunction

  // Effective byte enables of one lane: size-limited; atomics ignore req_be.
  function automatic logic [MAX_ACC_BYTES-1:0] f_be_eff(input logic [1:0] op,
                                                        input logic [SIZE_W-1:0] sz,
                                                        input logic [MAX_ACC_BYTES-1:0] be);
`ifdef MUT_IGNORE_BE
    return f_low_mask(f_bytes(sz));
`else
    return (op == OP_ATOMIC) ? f_low_mask(f_bytes(sz)) : (be & f_low_mask(f_bytes(sz)));
`endif
  endfunction

  // Number of access bytes that fall in the LOW line (the rest, if any, fall in the next line).
  function automatic int f_lo_cnt(input logic [LOG2_TXN-1:0] off, input int bsz);
    return (int'(off) + bsz > TXN_BYTES) ? (TXN_BYTES - int'(off)) : bsz;
  endfunction

  function automatic logic f_misaligned(input logic [ADDR_W-1:0] a, input int bsz);
    logic [31:0] t;
    t = bsz - 1;
    return |(a[LOG2_ACC-1:0] & t[LOG2_ACC-1:0]);
  endfunction

  // True when the highest enabled byte of the access lies outside the legal aperture.
  function automatic logic f_range_bad(input logic [ADDR_W-1:0] a,
                                       input logic [MAX_ACC_BYTES-1:0] be_e);
    int          last;
    logic [ADDR_W:0] lastv, s;
    last = 0;
    for (int k = 0; k < MAX_ACC_BYTES; k++) if (be_e[k]) last = k;
    lastv = '0;
    lastv[LOG2_ACC-1:0] = last[LOG2_ACC-1:0];
    s = {1'b0, a} + lastv;
    return (s >= LIMIT);
  endfunction

  function automatic int f_popcount(input logic [TXN_BYTES-1:0] v);
    int c;
    c = 0;
    for (int i = 0; i < TXN_BYTES; i++) c += int'(v[i]);
    return c;
  endfunction

  // Truncate an atomic operand/result to `bsz` bytes.
  function automatic logic [ATOM_W-1:0] f_trunc_atom(input logic [ATOM_W-1:0] v, input int bsz);
    logic [ATOM_W-1:0] r;
    r = '0;
    for (int k = 0; k < ATOM_BYTES; k++) if (k < bsz) r[k*8 +: 8] = v[k*8 +: 8];
    return r;
  endfunction

  // ===========================================================================
  // State
  // ===========================================================================
  // ---- Instruction slots ----
  logic [N-1:0]                              s_valid_q, s_idone_q, s_lock_q;
  logic [1:0]                                s_op_q     [N];
  logic [SIZE_W-1:0]                         s_size_q   [N];
  logic [3:0]                                s_amo_q    [N];
  logic [USER_TAG_W-1:0]                     s_utag_q   [N];
  logic [UID_W-1:0]                          s_uid_q    [N];
  logic [NUM_LANES-1:0]                      s_pend_lo_q[N];
  logic [NUM_LANES-1:0]                      s_pend_hi_q[N];
  logic [NOUT_W-1:0]                         s_nout_q   [N];
  logic [ERR_W-1:0]                          s_err_q    [N];
  logic [NUM_LANES-1:0]                      s_errm_q   [N];
  logic [NUM_LANES-1:0][ADDR_W-1:0]          s_addr_q   [N];
  logic [NUM_LANES-1:0][MAX_ACC_BYTES-1:0]   s_be_q     [N];
  logic [NUM_LANES-1:0][ACC_W-1:0]           s_wd_q     [N];
  logic [NUM_LANES-1:0][ATOM_W-1:0]          s_wd2_q    [N];
  logic [NUM_LANES-1:0][ACC_W-1:0]           s_rd_q     [N];

  logic [UID_W-1:0]        uid_cnt_q;
  logic [SEQ_W-1:0]        issue_seq_q, retire_seq_q;
  logic [SLOT_W-1:0]       rr_q;
  logic                    rsp_valid_q;
  logic [SLOT_W-1:0]       rsp_slot_q;

  // ---- Downstream ordinary-transaction tag table ----
  logic [NM-1:0]           mt_v_q, mt_z_q;                       // valid, zombie (timed out)
  logic [SLOT_W-1:0]       mt_slot_q [NM];
  logic                    mt_wr_q   [NM];
  logic [LINE_W-1:0]       mt_line_q [NM];
  logic [TXN_BYTES-1:0]    mt_mask_q [NM];
  logic [NUM_LANES-1:0]    mt_slo_q  [NM];                       // lanes served via their low part
  logic [NUM_LANES-1:0]    mt_shi_q  [NM];                       // lanes served via their high part
  logic [TO_W-1:0]         mt_age_q  [NM];

  // ---- Downstream atomic tag table ----
  logic [NA-1:0]           at_v_q, at_z_q;
  logic [SLOT_W-1:0]       at_slot_q [NA];
  logic [LANE_W-1:0]       at_lane_q [NA];
  logic [LINE_W-1:0]       at_line_q [NA];
  logic [TXN_BYTES-1:0]    at_mask_q [NA];
  logic [TO_W-1:0]         at_age_q  [NA];

  // ---- Downstream output registers ----
  logic                    mem_req_valid_q;
  logic [MTAG_W-1:0]       mem_req_id_q;
  logic                    mem_req_write_q;
  logic [ADDR_W-1:0]       mem_req_addr_q;
  logic [TXN_BYTES-1:0]    mem_req_mask_q;
  logic [TXN_BYTES*8-1:0]  mem_req_wdata_q;

  logic                    atm_req_valid_q;
  logic [ATAG_W-1:0]       atm_req_id_q;
  logic [3:0]              atm_req_op_q;
  logic [SIZE_W-1:0]       atm_req_size_q;
  logic [ADDR_W-1:0]       atm_req_addr_q;
  logic [ATOM_W-1:0]       atm_req_a_q, atm_req_b_q;

  // ---- Counters ----
  logic [31:0] c_acc_q, c_cmp_q, c_mtx_q, c_mby_q, c_aop_q, c_err_q, c_spur_q, c_late_q, c_to_q;
  logic        proto_err_q;

  // ===========================================================================
  // 1. Accept path: slot allocation and per-lane analysis of the incoming request
  // ===========================================================================
  logic              alloc_v;
  logic [SLOT_W-1:0] alloc_i;
  always_comb begin
    alloc_v = 1'b0;
    alloc_i = '0;
    for (int i = N - 1; i >= 0; i--)
      if (!s_valid_q[i]) begin alloc_v = 1'b1; alloc_i = i[SLOT_W-1:0]; end
  end

  assign req_ready = alloc_v;
  assign req_uid   = uid_cnt_q;
  assign req_id    = alloc_i;
  wire   req_fire  = req_valid && req_ready;

  wire is_mem_op = (req_op == OP_LOAD) || (req_op == OP_STORE) || (req_op == OP_ATOMIC);

  logic acc_illegal;
  always_comb begin
    acc_illegal = 1'b0;
    case (req_op)
      OP_LOAD, OP_STORE: acc_illegal = (int'(req_size) > LOG2_ACC);
      OP_ATOMIC:         acc_illegal = (int'(req_size) > LOG2_ATOM) || (int'(req_amo) > AMO_LAST);
      default:           acc_illegal = 1'b0;
    endcase
  end

  logic [NUM_LANES-1:0]  acc_has, acc_lo_ex, acc_hi_ex, acc_al_bad, acc_rg_bad, acc_lane_ok;
  logic [NUM_LANES-1:0]  acc_pend_lo, acc_pend_hi;
  logic [ERR_W-1:0]      acc_err;
  logic [NUM_LANES-1:0]  acc_errm;

  always_comb begin
    logic [MAX_ACC_BYTES-1:0] be_e;
    int                       bsz, lo_n;
    bsz = f_bytes(req_size);
    for (int l = 0; l < NUM_LANES; l++) begin
      be_e            = f_be_eff(req_op, req_size, req_be[l]);
      lo_n            = f_lo_cnt(req_addr[l][LOG2_TXN-1:0], bsz);
      acc_has[l]      = |be_e;
      acc_lo_ex[l]    = |(be_e &  f_low_mask(lo_n));
      acc_hi_ex[l]    = |(be_e & ~f_low_mask(lo_n));
      acc_al_bad[l]   = ((req_op == OP_ATOMIC) || !ALLOW_MISALIGNED) && f_misaligned(req_addr[l], bsz);
`ifdef MUT_NO_RANGE_CHECK
      acc_rg_bad[l]   = 1'b0;
`else
      acc_rg_bad[l]   = f_range_bad(req_addr[l], be_e);
`endif
      acc_lane_ok[l]  = is_mem_op && !acc_illegal && req_mask[l] && acc_has[l]
                        && !acc_al_bad[l] && !acc_rg_bad[l];
      acc_pend_lo[l]  = acc_lane_ok[l] && acc_lo_ex[l];
`ifdef MUT_DROP_HI_PART
      acc_pend_hi[l]  = 1'b0;
`else
      acc_pend_hi[l]  = acc_lane_ok[l] && acc_hi_ex[l] && (req_op != OP_ATOMIC);
`endif
    end
    acc_err  = '0;
    acc_errm = '0;
    if (acc_illegal) begin
      acc_err[ERR_BIT_ILLEGAL] = 1'b1;
      acc_errm                 = req_mask;
    end else if (is_mem_op) begin
      acc_err[ERR_BIT_ALIGN] = |(req_mask & acc_has & acc_al_bad);
      acc_err[ERR_BIT_RANGE] = |(req_mask & acc_has & acc_rg_bad);
      acc_errm               = req_mask & acc_has & (acc_al_bad | acc_rg_bad);
    end
  end

  // ===========================================================================
  // 2. Issue engine: head instruction, leader selection, merge
  // ===========================================================================
  logic              head_v;
  logic [SLOT_W-1:0] head_i;
  always_comb begin
    head_v = 1'b0;
    head_i = '0;
    for (int i = 0; i < N; i++)
      if (s_valid_q[i] && !s_idone_q[i] && (s_uid_q[i][SEQ_W-1:0] == issue_seq_q)) begin
        head_v = 1'b1;
        head_i = i[SLOT_W-1:0];
      end
  end

  wire [1:0]                                h_op      = s_op_q[head_i];
  wire [SIZE_W-1:0]                         h_size    = s_size_q[head_i];
  wire [3:0]                                h_amo     = s_amo_q[head_i];
  wire [NUM_LANES-1:0]                      h_pend_lo = head_v ? s_pend_lo_q[head_i] : '0;
  wire [NUM_LANES-1:0]                      h_pend_hi = head_v ? s_pend_hi_q[head_i] : '0;
  wire [NUM_LANES-1:0][ADDR_W-1:0]          h_addr    = s_addr_q[head_i];
  wire [NUM_LANES-1:0][MAX_ACC_BYTES-1:0]   h_be      = s_be_q[head_i];
  wire [NUM_LANES-1:0][ACC_W-1:0]           h_wd      = s_wd_q[head_i];
  wire [NUM_LANES-1:0][ATOM_W-1:0]          h_wd2     = s_wd2_q[head_i];

  // ---- Leader = lowest pending lane (low part before high part) ----
  logic                ldr_v, ldr_hi;
  logic [LANE_W-1:0]   ldr_lane;
  always_comb begin
    ldr_v    = 1'b0;
    ldr_hi   = 1'b0;
    ldr_lane = '0;
`ifdef MUT_ATOMIC_REVERSE
    for (int l = 0; l < NUM_LANES; l++)
`else
    for (int l = NUM_LANES - 1; l >= 0; l--)
`endif
      if (h_pend_lo[l] || h_pend_hi[l]) begin
        ldr_v    = 1'b1;
        ldr_lane = l[LANE_W-1:0];
        ldr_hi   = !h_pend_lo[l];
      end
  end

  wire [ADDR_W-1:0]  ldr_addr  = h_addr[ldr_lane];
  logic [LINE_W-1:0] ldr_line;
  always_comb begin
    ldr_line = ldr_addr[ADDR_W-1:LOG2_TXN];
    if (ldr_hi) ldr_line = ldr_line + 1'b1;
  end

  // ---- Which lane-parts join the leader's transaction ----
  logic [NUM_LANES-1:0] m_lo, m_hi;
  always_comb begin
    logic [LINE_W-1:0] ll;
    for (int l = 0; l < NUM_LANES; l++) begin
      ll      = h_addr[l][ADDR_W-1:LOG2_TXN];
      m_lo[l] = h_pend_lo[l] && (ll == ldr_line);
      m_hi[l] = h_pend_hi[l] && ((ll + 1'b1) == ldr_line);
    end
    if (!COALESCE_EN) begin                      // baseline: leader only
      m_lo = '0;
      m_hi = '0;
      if (ldr_hi) m_hi[ldr_lane] = 1'b1;
      else        m_lo[ldr_lane] = 1'b1;
    end
    if (h_op == OP_ATOMIC) begin                 // atomics: always exactly one lane, never merged
      m_lo = '0;
      m_hi = '0;
      m_lo[ldr_lane] = 1'b1;
    end
  end

  // ---- Merge matched lane-parts into a transaction (ascending lane order:
  //      the highest lane wins on overlapping store bytes) ----
  logic [TXN_BYTES-1:0]   c_mask;
  logic [TXN_BYTES*8-1:0] c_data;
  always_comb begin
    int j;
    logic [MAX_ACC_BYTES-1:0] be_e;
    c_mask = '0;
    c_data = '0;
`ifdef MUT_LOWEST_LANE_WINS
    for (int l = NUM_LANES - 1; l >= 0; l--) begin
`else
    for (int l = 0; l < NUM_LANES; l++) begin
`endif
      be_e = f_be_eff(h_op, h_size, h_be[l]);
      for (int k = 0; k < MAX_ACC_BYTES; k++) begin
        j = int'(h_addr[l][LOG2_TXN-1:0]) + k;
        if (be_e[k]) begin
          if (m_lo[l] && j < TXN_BYTES) begin
            c_mask[j] = 1'b1;
            if (h_op == OP_STORE) c_data[j*8 +: 8] = h_wd[l][k*8 +: 8];
          end
          if (m_hi[l] && j >= TXN_BYTES) begin
            c_mask[j-TXN_BYTES] = 1'b1;
            if (h_op == OP_STORE) c_data[(j-TXN_BYTES)*8 +: 8] = h_wd[l][k*8 +: 8];
          end
        end
      end
    end
  end

  // ---- Atomic candidate (one lane) ----
  logic [LINE_W-1:0]      a_line;
  logic [TXN_BYTES-1:0]   a_mask;
  logic [ATOM_W-1:0]      a_opa, a_opb;
  always_comb begin
    int off, bsz;
    a_line = ldr_addr[ADDR_W-1:LOG2_TXN];
    off    = int'(ldr_addr[LOG2_TXN-1:0]);
    bsz    = f_bytes(h_size);
    a_mask = '0;
    for (int k = 0; k < ATOM_BYTES; k++) if (k < bsz && (off + k) < TXN_BYTES) a_mask[off + k] = 1'b1;
    a_opa = f_trunc_atom(h_wd[ldr_lane][ATOM_W-1:0], bsz);
    a_opb = f_trunc_atom(h_wd2[ldr_lane],            bsz);
  end

  // ===========================================================================
  // 3. Tags, hazard interlock and commit
  // ===========================================================================
  logic              mt_free_v, at_free_v;
  logic [MTAG_W-1:0] mt_free_i;
  logic [ATAG_W-1:0] at_free_i;
  always_comb begin
    mt_free_v = 1'b0; mt_free_i = '0;
    for (int t = NM - 1; t >= 0; t--) if (!mt_v_q[t]) begin mt_free_v = 1'b1; mt_free_i = t[MTAG_W-1:0]; end
    at_free_v = 1'b0; at_free_i = '0;
    for (int t = NA - 1; t >= 0; t--) if (!at_v_q[t]) begin at_free_v = 1'b1; at_free_i = t[ATAG_W-1:0]; end
  end

  // Hazard: the candidate may not issue while an overlapping older access is outstanding
  //   (write-vs-anything, within the ordinary port, when the downstream may reorder), and
  //   (anything-vs-atomic, across the two ports, always -- the ports are not mutually ordered).
  logic hz_mem, hz_atm;
  always_comb begin
    hz_mem = 1'b0;
    hz_atm = 1'b0;
    for (int t = 0; t < NM; t++) begin
      if (mt_v_q[t] && !mt_z_q[t]) begin
        if (mt_line_q[t] == ldr_line && |(mt_mask_q[t] & c_mask) &&
            DS_OOO && ((h_op == OP_STORE) || mt_wr_q[t]))
          hz_mem = 1'b1;                                   // ordinary vs ordinary
        if (mt_line_q[t] == a_line && |(mt_mask_q[t] & a_mask))
          hz_atm = 1'b1;                                   // atomic vs ordinary
      end
    end
    for (int t = 0; t < NA; t++) begin
      if (at_v_q[t] && !at_z_q[t]) begin
        if (at_line_q[t] == ldr_line && |(at_mask_q[t] & c_mask))
          hz_mem = 1'b1;                                   // ordinary vs atomic
      end
    end
`ifdef MUT_NO_HAZARD
    hz_mem = 1'b0;
    hz_atm = 1'b0;
`endif
`ifdef MUT_ATM_NO_XHAZARD
    hz_atm = 1'b0;
`endif
  end

  wire mem_out_ok = !mem_req_valid_q || mem_req_ready;
  wire atm_out_ok = !atm_req_valid_q || atm_req_ready;

  wire mem_cand = head_v && ldr_v && (h_op == OP_LOAD || h_op == OP_STORE);
  wire atm_cand = head_v && ldr_v && (h_op == OP_ATOMIC);
  wire mem_commit = mem_cand && mt_free_v && mem_out_ok && !hz_mem;
  wire atm_commit = atm_cand && at_free_v && atm_out_ok && !hz_atm;

  wire fence_ok   = ((mt_v_q & ~mt_z_q) == '0) && ((at_v_q & ~at_z_q) == '0);
  wire head_empty = head_v && ((h_op == OP_FENCE) ? fence_ok : !ldr_v);

  logic [NUM_LANES-1:0] ldr_onehot;
  always_comb begin
    ldr_onehot = '0;
    ldr_onehot[ldr_lane] = 1'b1;
  end

  wire [NUM_LANES-1:0] pend_lo_after = h_pend_lo & ~(mem_commit ? m_lo : ldr_onehot);
  wire [NUM_LANES-1:0] pend_hi_after = h_pend_hi & ~(mem_commit ? m_hi : '0);
  wire any_commit       = mem_commit || atm_commit;
  wire issue_done_set   = (any_commit && ((pend_lo_after | pend_hi_after) == '0)) || head_empty;

  // ===========================================================================
  // 4. Downstream responses, watchdog timeouts
  // ===========================================================================
  // ---- Ordinary port ----
  wire                 mrsp_in_rng = (int'(mem_rsp_id) < NM);
  wire                 mrsp_known  = mem_rsp_valid && mrsp_in_rng && mt_v_q[mem_rsp_id];
`ifdef MUT_NO_SPURIOUS_FILTER
  wire                 mrsp_live   = mem_rsp_valid && mrsp_in_rng && !mt_z_q[mem_rsp_id];
`else
  wire                 mrsp_live   = mrsp_known && !mt_z_q[mem_rsp_id];
`endif
  wire                 mrsp_late   = mrsp_known && mt_z_q[mem_rsp_id];
  wire                 mrsp_spur   = mem_rsp_valid && !mrsp_known;
  wire [SLOT_W-1:0]    mrsp_slot   = mt_slot_q[mem_rsp_id];
  wire [NUM_LANES-1:0] mrsp_lanes  = mt_slo_q[mem_rsp_id] | mt_shi_q[mem_rsp_id];

  logic              mto_v;
  logic [MTAG_W-1:0] mto_idx;
  always_comb begin
    mto_v = 1'b0; mto_idx = '0;
    if (TIMEOUT_CYCLES > 0)
      for (int t = NM - 1; t >= 0; t--)
        if (mt_v_q[t] && !mt_z_q[t] && (mt_age_q[t] >= TO_LIM) && !(mrsp_live && int'(mem_rsp_id) == t)) begin
          mto_v = 1'b1; mto_idx = t[MTAG_W-1:0];
        end
  end
  wire [SLOT_W-1:0]    mto_slot  = mt_slot_q[mto_idx];
  wire [NUM_LANES-1:0] mto_lanes = mt_slo_q[mto_idx] | mt_shi_q[mto_idx];

  // ---- Atomic port ----
  wire                 arsp_in_rng = (int'(atm_rsp_id) < NA);
  wire                 arsp_known  = atm_rsp_valid && arsp_in_rng && at_v_q[atm_rsp_id];
`ifdef MUT_NO_SPURIOUS_FILTER
  wire                 arsp_live   = atm_rsp_valid && arsp_in_rng && !at_z_q[atm_rsp_id];
`else
  wire                 arsp_live   = arsp_known && !at_z_q[atm_rsp_id];
`endif
  wire                 arsp_late   = arsp_known && at_z_q[atm_rsp_id];
  wire                 arsp_spur   = atm_rsp_valid && !arsp_known;
  wire [SLOT_W-1:0]    arsp_slot   = at_slot_q[atm_rsp_id];
  wire [LANE_W-1:0]    arsp_lane   = at_lane_q[atm_rsp_id];

  logic              ato_v;
  logic [ATAG_W-1:0] ato_idx;
  always_comb begin
    ato_v = 1'b0; ato_idx = '0;
    if (TIMEOUT_CYCLES > 0)
      for (int t = NA - 1; t >= 0; t--)
        if (at_v_q[t] && !at_z_q[t] && (at_age_q[t] >= TO_LIM) && !(arsp_live && int'(atm_rsp_id) == t)) begin
          ato_v = 1'b1; ato_idx = t[ATAG_W-1:0];
        end
  end
  wire [SLOT_W-1:0]    ato_slot = at_slot_q[ato_idx];
  wire [LANE_W-1:0]    ato_lane = at_lane_q[ato_idx];

  assign mem_rsp_ready = 1'b1;
  assign atm_rsp_ready = 1'b1;

  // ---- Optional downstream in-order checker (only when DS_OOO = 0) ----
  logic mem_ord_viol;
  generate
    if (!DS_OOO) begin : g_ordchk
      localparam int ORD_W = MTAG_W + 2;
      logic [ORD_W-1:0] mord_q;
      logic [ORD_W-1:0] mt_ord_q [NM];
      always_comb begin
        logic [ORD_W-1:0] my_age;
        mem_ord_viol = 1'b0;
        my_age = mord_q - mt_ord_q[mem_rsp_id];
        for (int t = 0; t < NM; t++)
          if (mrsp_live && mt_v_q[t] && !mt_z_q[t] && int'(mem_rsp_id) != t &&
              ((mord_q - mt_ord_q[t]) > my_age))
            mem_ord_viol = 1'b1;
      end
      always_ff @(posedge clk) begin
        if (!rst_n) mord_q <= '0;
        else if (mem_commit) begin
          mt_ord_q[mt_free_i] <= mord_q;
          mord_q              <= mord_q + 1'b1;
        end
      end
    end else begin : g_noordchk
      assign mem_ord_viol = 1'b0;
    end
  endgenerate

  // ===========================================================================
  // 5. Per-slot event aggregation (issue / response / timeout may hit one slot together)
  // ===========================================================================
  logic [NOUT_W-1:0]     ev_inc  [N];
  logic [NOUT_W-1:0]     ev_dec  [N];
  logic [ERR_W-1:0]      ev_err  [N];
  logic [NUM_LANES-1:0]  ev_errm [N];
  always_comb begin
    for (int i = 0; i < N; i++) begin
      ev_inc[i]  = '0;
      ev_dec[i]  = '0;
      ev_err[i]  = '0;
      ev_errm[i] = '0;
      if (any_commit && head_v && (head_i == i[SLOT_W-1:0])) ev_inc[i] = 1;
      if (mrsp_live && (mrsp_slot == i[SLOT_W-1:0])) begin
        ev_dec[i] = ev_dec[i] + 1'b1;
        if (mem_rsp_err) begin
          ev_err[i][ERR_BIT_DOWNSTREAM] = 1'b1;
          ev_errm[i] = ev_errm[i] | mrsp_lanes;
        end
      end
      if (mto_v && (mto_slot == i[SLOT_W-1:0])) begin
        ev_dec[i] = ev_dec[i] + 1'b1;
        ev_err[i][ERR_BIT_TIMEOUT] = 1'b1;
        ev_errm[i] = ev_errm[i] | mto_lanes;
      end
      if (arsp_live && (arsp_slot == i[SLOT_W-1:0])) begin
        ev_dec[i] = ev_dec[i] + 1'b1;
        if (atm_rsp_err) begin
          ev_err[i][ERR_BIT_DOWNSTREAM] = 1'b1;
          ev_errm[i][arsp_lane] = 1'b1;
        end
      end
      if (ato_v && (ato_slot == i[SLOT_W-1:0])) begin
        ev_dec[i] = ev_dec[i] + 1'b1;
        ev_err[i][ERR_BIT_TIMEOUT] = 1'b1;
        ev_errm[i][ato_lane] = 1'b1;
      end
    end
  end

  // ---- Read-data assembly: scatter a response line into per-lane read buffers ----
  logic [NUM_LANES-1:0][ACC_W-1:0] rd_mem_new, rd_atm_new;
  always_comb begin
    logic [MAX_ACC_BYTES-1:0] be_e;
    int j;
    rd_mem_new = s_rd_q[mrsp_slot];
    for (int l = 0; l < NUM_LANES; l++) begin
      be_e = f_be_eff(OP_LOAD, s_size_q[mrsp_slot], s_be_q[mrsp_slot][l]);
      for (int k = 0; k < MAX_ACC_BYTES; k++) begin
        j = int'(s_addr_q[mrsp_slot][l][LOG2_TXN-1:0]) + k;
        if (be_e[k] && mt_slo_q[mem_rsp_id][l] && j < TXN_BYTES)
          rd_mem_new[l][k*8 +: 8] = mem_rsp_rdata[j*8 +: 8];
        if (be_e[k] && mt_shi_q[mem_rsp_id][l] && j >= TXN_BYTES)
          rd_mem_new[l][k*8 +: 8] = mem_rsp_rdata[(j-TXN_BYTES)*8 +: 8];
      end
    end
  end
  always_comb begin
    logic [ACC_W-1:0] tmp;
    tmp = '0;
    tmp[ATOM_W-1:0] = f_trunc_atom(atm_rsp_rdata, f_bytes(s_size_q[arsp_slot]));
    rd_atm_new = s_rd_q[arsp_slot];
    rd_atm_new[arsp_lane] = tmp;
  end

  // ===========================================================================
  // 6. Upstream response selection
  // ===========================================================================
  logic [N-1:0] done_v, elig_v;
  logic         sel_v;
  logic [SLOT_W-1:0] sel_i;
  always_comb begin
    for (int i = 0; i < N; i++) begin
      done_v[i] = s_valid_q[i] && s_idone_q[i] && (s_nout_q[i] == '0) && !s_lock_q[i];
`ifdef MUT_EARLY_COMPLETE
      done_v[i] = s_valid_q[i] && s_idone_q[i] && !s_lock_q[i];      // ignores outstanding txns
`endif
      elig_v[i] = done_v[i] && (!UP_INORDER || (s_uid_q[i][SEQ_W-1:0] == retire_seq_q));
    end
    sel_v = 1'b0;
    sel_i = '0;
    for (int k = N - 1; k >= 0; k--) begin
      int idx;
      idx = int'(rr_q) + k;
      if (idx >= N) idx = idx - N;
      if (elig_v[idx]) begin sel_v = 1'b1; sel_i = idx[SLOT_W-1:0]; end
    end
  end

  wire rsp_fire = rsp_valid_q && rsp_ready;
`ifdef MUT_RSP_UNSTABLE
  wire sel_en   = 1'b1;                       // BUG: re-select even while the response is stalled
`else
  wire sel_en   = !rsp_valid_q || rsp_fire;
`endif

  // ===========================================================================
  // 7. Sequential: instruction slots, issue pointers, response register
  // ===========================================================================
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      s_valid_q    <= '0;
      s_idone_q    <= '0;
      s_lock_q     <= '0;
      issue_seq_q  <= '0;
      retire_seq_q <= '0;
      uid_cnt_q    <= '0;
      rr_q         <= '0;
      rsp_valid_q  <= 1'b0;
      rsp_slot_q   <= '0;
    end else begin
      // ---- per-slot event updates (outstanding counter, error accumulation) ----
      for (int i = 0; i < N; i++) begin
        if (s_valid_q[i]) begin
          s_nout_q[i] <= s_nout_q[i] + ev_inc[i] - ev_dec[i];
          s_err_q[i]  <= s_err_q[i]  | ev_err[i];
          s_errm_q[i] <= s_errm_q[i] | ev_errm[i];
        end
      end

      // ---- issue progress on the head slot ----
      if (any_commit) begin
        s_pend_lo_q[head_i] <= pend_lo_after;
        s_pend_hi_q[head_i] <= pend_hi_after;
      end
      if (issue_done_set) begin
        s_idone_q[head_i] <= 1'b1;
        issue_seq_q       <= issue_seq_q + 1'b1;
      end

      // ---- read-data assembly (see rd_mem_new / rd_atm_new) ----
      if (mrsp_live && !mem_rsp_err && (s_op_q[mrsp_slot] == OP_LOAD)) s_rd_q[mrsp_slot] <= rd_mem_new;
      if (arsp_live && !atm_rsp_err)                                   s_rd_q[arsp_slot] <= rd_atm_new;

      // ---- upstream response register: select / lock / free ----
      if (rsp_fire) begin
        s_valid_q[rsp_slot_q] <= 1'b0;
        s_lock_q[rsp_slot_q]  <= 1'b0;
      end
      if (sel_en) begin
        rsp_valid_q <= sel_v;
        rsp_slot_q  <= sel_i;
        if (sel_v) begin
          s_lock_q[sel_i] <= 1'b1;
          rr_q            <= (int'(sel_i) == N - 1) ? '0 : (sel_i + 1'b1);
          if (UP_INORDER) retire_seq_q <= retire_seq_q + 1'b1;
        end
      end

      // ---- accept a new instruction (always targets a currently-free slot) ----
      if (req_fire) begin
        s_valid_q[alloc_i]  <= 1'b1;
        s_idone_q[alloc_i]  <= 1'b0;
        s_lock_q[alloc_i]   <= 1'b0;
        s_op_q[alloc_i]     <= req_op;
        s_size_q[alloc_i]   <= req_size;
        s_amo_q[alloc_i]    <= req_amo;
        s_utag_q[alloc_i]   <= req_tag;
        s_uid_q[alloc_i]    <= uid_cnt_q;
        s_pend_lo_q[alloc_i]<= acc_pend_lo;
        s_pend_hi_q[alloc_i]<= acc_pend_hi;
        s_nout_q[alloc_i]   <= '0;
        s_err_q[alloc_i]    <= acc_err;
        s_errm_q[alloc_i]   <= acc_errm;
        s_addr_q[alloc_i]   <= req_addr;
        s_be_q[alloc_i]     <= req_be;
        s_wd_q[alloc_i]     <= req_wdata;
        s_wd2_q[alloc_i]    <= req_wdata2;
        s_rd_q[alloc_i]     <= '0;
        uid_cnt_q           <= uid_cnt_q + 1'b1;
      end
    end
  end

  // ===========================================================================
  // 8. Sequential: ordinary tag table
  // ===========================================================================
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      mt_v_q <= '0;
      mt_z_q <= '0;
    end else begin
      for (int t = 0; t < NM; t++)
        if (mt_v_q[t] && !mt_z_q[t] && (mt_age_q[t] < TO_LIM)) mt_age_q[t] <= mt_age_q[t] + 1'b1;

      if (mem_commit) begin
        mt_v_q[mt_free_i]    <= 1'b1;
        mt_z_q[mt_free_i]    <= 1'b0;
        mt_slot_q[mt_free_i] <= head_i;
        mt_wr_q[mt_free_i]   <= (h_op == OP_STORE);
        mt_line_q[mt_free_i] <= ldr_line;
        mt_mask_q[mt_free_i] <= c_mask;
        mt_slo_q[mt_free_i]  <= m_lo;
        mt_shi_q[mt_free_i]  <= m_hi;
        mt_age_q[mt_free_i]  <= '0;
      end
      if (mrsp_known) begin                 // response (live or late) retires the tag
        mt_v_q[mem_rsp_id] <= 1'b0;
        mt_z_q[mem_rsp_id] <= 1'b0;
      end
      if (mto_v) mt_z_q[mto_idx] <= 1'b1;   // timeout: zombie until the late response arrives
    end
  end

  // ===========================================================================
  // 9. Sequential: atomic tag table
  // ===========================================================================
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      at_v_q <= '0;
      at_z_q <= '0;
    end else begin
      for (int t = 0; t < NA; t++)
        if (at_v_q[t] && !at_z_q[t] && (at_age_q[t] < TO_LIM)) at_age_q[t] <= at_age_q[t] + 1'b1;

      if (atm_commit) begin
        at_v_q[at_free_i]    <= 1'b1;
        at_z_q[at_free_i]    <= 1'b0;
        at_slot_q[at_free_i] <= head_i;
        at_lane_q[at_free_i] <= ldr_lane;
        at_line_q[at_free_i] <= a_line;
        at_mask_q[at_free_i] <= a_mask;
        at_age_q[at_free_i]  <= '0;
      end
      if (arsp_known) begin
        at_v_q[atm_rsp_id] <= 1'b0;
        at_z_q[atm_rsp_id] <= 1'b0;
      end
      if (ato_v) at_z_q[ato_idx] <= 1'b1;
    end
  end

  // ===========================================================================
  // 10. Sequential: downstream request registers
  // ===========================================================================
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      mem_req_valid_q <= 1'b0;
      atm_req_valid_q <= 1'b0;
    end else begin
      if (mem_req_ready) mem_req_valid_q <= 1'b0;
      if (mem_commit) begin
        mem_req_valid_q <= 1'b1;
        mem_req_id_q    <= mt_free_i;
        mem_req_write_q <= (h_op == OP_STORE);
        mem_req_addr_q  <= {ldr_line, {LOG2_TXN{1'b0}}};
        mem_req_mask_q  <= c_mask;
        mem_req_wdata_q <= c_data;
      end
      if (atm_req_ready) atm_req_valid_q <= 1'b0;
      if (atm_commit) begin
        atm_req_valid_q <= 1'b1;
        atm_req_id_q    <= at_free_i;
        atm_req_op_q    <= h_amo;
        atm_req_size_q  <= h_size;
        atm_req_addr_q  <= ldr_addr;
        atm_req_a_q     <= a_opa;
        atm_req_b_q     <= a_opb;
      end
    end
  end

  assign mem_req_valid = mem_req_valid_q;
  assign mem_req_id    = mem_req_id_q;
  assign mem_req_write = mem_req_write_q;
  assign mem_req_addr  = mem_req_addr_q;
  assign mem_req_mask  = mem_req_mask_q;
  assign mem_req_wdata = mem_req_wdata_q;
  assign atm_req_valid = atm_req_valid_q;
  assign atm_req_id    = atm_req_id_q;
  assign atm_req_op    = atm_req_op_q;
  assign atm_req_size  = atm_req_size_q;
  assign atm_req_addr  = atm_req_addr_q;
  assign atm_req_a     = atm_req_a_q;
  assign atm_req_b     = atm_req_b_q;

  // ---- upstream response payload (stable while rsp_valid && !rsp_ready) ----
  assign rsp_valid    = rsp_valid_q;
  assign rsp_uid      = s_uid_q[rsp_slot_q];
  assign rsp_id       = rsp_slot_q;
  assign rsp_tag      = s_utag_q[rsp_slot_q];
  assign rsp_op       = s_op_q[rsp_slot_q];
  assign rsp_rdata    = s_rd_q[rsp_slot_q];
  assign rsp_err      = s_err_q[rsp_slot_q];
  assign rsp_err_mask = s_errm_q[rsp_slot_q];

  // ===========================================================================
  // 11. Counters
  // ===========================================================================
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      c_acc_q <= '0; c_cmp_q <= '0; c_mtx_q <= '0; c_mby_q <= '0; c_aop_q <= '0;
      c_err_q <= '0; c_spur_q <= '0; c_late_q <= '0; c_to_q <= '0; proto_err_q <= 1'b0;
    end else begin
      if (req_fire)    c_acc_q <= c_acc_q + 1'b1;
      if (rsp_fire) begin
        c_cmp_q <= c_cmp_q + 1'b1;
        if (s_err_q[rsp_slot_q] != '0) c_err_q <= c_err_q + 1'b1;
      end
      if (mem_commit) begin
        c_mtx_q <= c_mtx_q + 1'b1;
        c_mby_q <= c_mby_q + 32'(f_popcount(c_mask));
      end
      if (atm_commit)  c_aop_q <= c_aop_q + 1'b1;
      if (mrsp_spur)   c_spur_q <= c_spur_q + 1'b1;
      if (arsp_spur)   c_spur_q <= c_spur_q + 1'b1 + 32'(mrsp_spur);
      if (mrsp_late || arsp_late) c_late_q <= c_late_q + 32'(mrsp_late) + 32'(arsp_late);
      if (mto_v || ato_v) c_to_q <= c_to_q + 32'(mto_v) + 32'(ato_v);
      if (mrsp_spur || arsp_spur || mem_ord_viol) proto_err_q <= 1'b1;
    end
  end

  assign stat_instr_accepted   = c_acc_q;
  assign stat_instr_completed  = c_cmp_q;
  assign stat_mem_txns         = c_mtx_q;
  assign stat_mem_useful_bytes = c_mby_q;
  assign stat_atm_ops          = c_aop_q;
  assign stat_err_instr        = c_err_q;
  assign stat_rsp_spurious     = c_spur_q;
  assign stat_rsp_late         = c_late_q;
  assign stat_timeouts         = c_to_q;
  assign stat_proto_err        = proto_err_q;
  assign idle                  = (s_valid_q == '0);

  // ===========================================================================
  // 12. Embedded assertions (simulation only).  These encode the invariants
  //     that together imply "each accepted request completes exactly once":
  //       I1  accepted - completed == number of occupied slots   (no leak, no duplicate)
  //       I2  per-slot outstanding counter never under/overflows (no stray completion)
  //       I3  tags are allocated only when free, retired only when valid
  //       I4  a response is only ever selected for a fully-complete, unlocked slot
  //       I5  no two live outstanding accesses conflict (ordering interlock holds)
  //       I6  transactions are aligned and carry a non-empty byte mask
  // ===========================================================================
`ifndef SYNTHESIS
  function automatic int f_cnt_ones(input logic [N-1:0] v);
    int c; c = 0;
    for (int i = 0; i < N; i++) c += int'(v[i]);
    return c;
  endfunction

  always_ff @(posedge clk) if (rst_n) begin
    // I1
    assert ((c_acc_q - c_cmp_q) == 32'(f_cnt_ones(s_valid_q)))
      else $error("[coalescer I1] accepted-completed (%0d) != occupied slots (%0d)",
                  c_acc_q - c_cmp_q, f_cnt_ones(s_valid_q));
    // I2
    for (int i = 0; i < N; i++)
      if (s_valid_q[i])
        assert ((int'(s_nout_q[i]) + int'(ev_inc[i]) - int'(ev_dec[i])) >= 0 &&
                (int'(s_nout_q[i]) + int'(ev_inc[i]) - int'(ev_dec[i])) <= 2 * NUM_LANES)
          else $error("[coalescer I2] slot %0d outstanding counter out of range", i);
    // I3
    if (mem_commit) assert (!mt_v_q[mt_free_i]) else $error("[coalescer I3] mem tag allocated while valid");
    if (atm_commit) assert (!at_v_q[at_free_i]) else $error("[coalescer I3] atm tag allocated while valid");
    // I4
    if (sel_en && sel_v)
      assert (s_valid_q[sel_i] && s_idone_q[sel_i] && !s_lock_q[sel_i] && s_nout_q[sel_i] == '0)
        else $error("[coalescer I4] response selected for incomplete slot %0d", sel_i);
    // I5 (ordinary vs ordinary, when the interlock is active; ordinary vs atomic always)
    for (int a = 0; a < NM; a++) begin
      for (int b = a + 1; b < NM; b++)
        if (DS_OOO && mt_v_q[a] && !mt_z_q[a] && mt_v_q[b] && !mt_z_q[b] && mt_line_q[a] == mt_line_q[b] &&
            |(mt_mask_q[a] & mt_mask_q[b]))
          assert (!mt_wr_q[a] && !mt_wr_q[b])
            else $error("[coalescer I5] conflicting outstanding mem txns %0d,%0d", a, b);
      for (int b = 0; b < NA; b++)
        if (mt_v_q[a] && !mt_z_q[a] && at_v_q[b] && !at_z_q[b] && mt_line_q[a] == at_line_q[b] &&
            |(mt_mask_q[a] & at_mask_q[b]))
          assert (1'b0) else $error("[coalescer I5] ordinary txn %0d overlaps outstanding atomic %0d", a, b);
    end
    // I6
    if (mem_req_valid_q) begin
      assert (mem_req_addr_q[LOG2_TXN-1:0] == '0) else $error("[coalescer I6] unaligned transaction address");
      assert (mem_req_mask_q != '0)               else $error("[coalescer I6] empty byte mask");
    end
  end
`endif


  // ===========================================================================
  // 13. FORMAL-ONLY properties (compiled only with -DFORMAL; see formal/README.md)
  //
  //   f_prop == 1 in every reachable state, for every legal environment.
  //
  //   Environment contract (assumed): the downstream only answers requests it has
  //   accepted and not yet answered.  This is tracked by f_mem_out / f_atm_out and
  //   by the sticky f_env_ok_q: once the environment misbehaves the property is
  //   vacuously true from then on (equivalent to an `assume` on every cycle).
  //
  //   Proven obligations:
  //     X1  accepted - completed == occupied slots                  (no leak / duplicate)
  //     X2  per slot: s_nout == number of live downstream tags naming that slot
  //                                                                 (no stray / double decrement)
  //     X3  a response is only offered for a valid, locked, finished slot, and exactly
  //         one slot is locked iff the response register is valid
  //     X4  every live or zombie tag names an occupied slot; zombies are valid
  //     X5  for an arbitrary but fixed uid X:  X is never completed before it is
  //         accepted, never completed twice, never accepted twice
  //     X6  a valid slot carrying uid X implies X was accepted and not yet completed
  //     X7  ghost: uid counter == X + 1 + (accepts since X)   (makes X5 inductive)
  //     X9  ghost counter below saturation (follows from assumption (b))
  //     X8  occupied slots carry pairwise-distinct uids, none equal to the next uid  (unique ids)
  // ===========================================================================
`ifdef FORMAL
  // The tracked uid X is the free input f_x_in, constrained to be constant by the
  // environment assumption below (compared against its value one cycle earlier).
  wire  [UID_W-1:0] f_x_q = f_x_in;
  logic [UID_W-1:0] f_x_prev_q;

  logic [NM-1:0] f_mem_out;
  logic [NA-1:0] f_atm_out;
  logic          f_env_ok_q, f_acc_x_q, f_done_x_q;
  logic [UID_W-1:0] f_after_q;                     // accepts since X was accepted

  // Environment contract:
  //   (a) the downstream never answers a tag that is LIVE in the coalescer but not yet accepted by
  //       the downstream (indistinguishable from a real response).  Anything else is allowed:
  //       responses to free tags, zombie (timed-out) tags, duplicates, out-of-range ids -- the
  //       coalescer must drop those without disturbing its accounting;
  //   (b) UID_W is wide enough that uids do not wrap while the tracked uid is live
  //       (at most 2^UID_W - 2 further accepts after X);
  //   (d) likewise no in-flight uid is overtaken by the counter (same sizing rule, all slots);
  //   (c) the tracked uid X (formal input) does not change.
  logic f_wrap_hit;      // an accept now would let the uid counter overtake an in-flight uid
  always_comb begin
    f_wrap_hit = 1'b0;
    for (int i = 0; i < N; i++)
      if (s_valid_q[i] && (uid_cnt_q - s_uid_q[i]) == {UID_W{1'b1}}) f_wrap_hit = 1'b1;
  end

  wire f_assume_now =
        (!mem_rsp_valid || !mrsp_in_rng || f_mem_out[mem_rsp_id] || !(mt_v_q[mem_rsp_id] && !mt_z_q[mem_rsp_id])) &&
        (!atm_rsp_valid || !arsp_in_rng || f_atm_out[atm_rsp_id] || !(at_v_q[atm_rsp_id] && !at_z_q[atm_rsp_id])) &&
        !(req_fire && f_acc_x_q && f_after_q == {UID_W{1'b1}} - 1'b1) &&
        !(req_fire && f_wrap_hit) &&
        (f_x_in == f_x_prev_q);                    // (c) X is constant

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      f_mem_out <= '0; f_atm_out <= '0; f_env_ok_q <= 1'b1; f_acc_x_q <= 1'b0; f_done_x_q <= 1'b0;
      f_after_q <= '0;
      f_x_prev_q <= f_x_in;
    end else begin
      f_x_prev_q <= f_x_in;
      if (req_fire && f_acc_x_q) f_after_q <= f_after_q + 1'b1;
      f_env_ok_q <= f_env_ok_q && f_assume_now;
      if (mem_rsp_valid && mrsp_in_rng) f_mem_out[mem_rsp_id] <= 1'b0;
      if (atm_rsp_valid && arsp_in_rng) f_atm_out[atm_rsp_id] <= 1'b0;
      if (mem_req_valid && mem_req_ready) f_mem_out[mem_req_id] <= 1'b1;     // (a request cannot be answered in the cycle it is accepted: f_mem_out is registered)
      if (atm_req_valid && atm_req_ready) f_atm_out[atm_req_id] <= 1'b1;
      if (req_fire && req_uid == f_x_q) f_acc_x_q <= 1'b1;
      if (rsp_fire && s_uid_q[rsp_slot_q] == f_x_q) f_done_x_q <= 1'b1;
    end
  end

  function automatic int f_ones(input logic [N-1:0] v);
    int c; c = 0;
    for (int i = 0; i < N; i++) c += int'(v[i]);
    return c;
  endfunction

  (* keep *) logic [UID_W-1:0] f_x7_exp;
  assign f_x7_exp = f_x_q + f_after_q + {{(UID_W-1){1'b0}}, 1'b1};
  (* keep *) logic [11:0] f_vbits;
  always_comb begin
    int live;
    f_vbits = '0;
    // X1
    if ((c_acc_q - c_cmp_q) != 32'(f_ones(s_valid_q))) f_vbits[0] = 1'b1;
    // X2
    for (int i = 0; i < N; i++) begin
      live = 0;
      for (int t = 0; t < NM; t++) if (mt_v_q[t] && !mt_z_q[t] && mt_slot_q[t] == i[SLOT_W-1:0]) live++;
      for (int t = 0; t < NA; t++) if (at_v_q[t] && !at_z_q[t] && at_slot_q[t] == i[SLOT_W-1:0]) live++;
      if (s_valid_q[i] && int'(s_nout_q[i]) != live) f_vbits[1] = 1'b1;
    end
    // X3
    if (rsp_valid_q && !(s_valid_q[rsp_slot_q] && s_lock_q[rsp_slot_q] && s_idone_q[rsp_slot_q] &&
                         s_nout_q[rsp_slot_q] == '0)) f_vbits[2] = 1'b1;
    if (f_ones(s_lock_q) != int'(rsp_valid_q)) f_vbits[3] = 1'b1;
    if ((s_lock_q & ~s_valid_q) != '0) f_vbits[3] = 1'b1;
    // X4
    for (int t = 0; t < NM; t++) begin
      if (mt_v_q[t] && !mt_z_q[t] && !s_valid_q[mt_slot_q[t]]) f_vbits[4] = 1'b1;
      if (mt_z_q[t] && !mt_v_q[t]) f_vbits[4] = 1'b1;
    end
    for (int t = 0; t < NA; t++) begin
      if (at_v_q[t] && !at_z_q[t] && !s_valid_q[at_slot_q[t]]) f_vbits[4] = 1'b1;
      if (at_z_q[t] && !at_v_q[t]) f_vbits[4] = 1'b1;
    end
    // X5
    if (rsp_fire && s_uid_q[rsp_slot_q] == f_x_q && (!f_acc_x_q || f_done_x_q)) f_vbits[5] = 1'b1;
    if (req_fire && req_uid == f_x_q && f_acc_x_q) f_vbits[5] = 1'b1;
    // X6
    for (int i = 0; i < N; i++)
      if (s_valid_q[i] && s_uid_q[i] == f_x_q && (!f_acc_x_q || f_done_x_q)) f_vbits[6] = 1'b1;
    // X8: uids of occupied slots are distinct and differ from the next uid to be issued
    for (int i = 0; i < N; i++) begin
      if (s_valid_q[i] && s_uid_q[i] == uid_cnt_q) f_vbits[7] = 1'b1;
      for (int j = i + 1; j < N; j++)
        if (s_valid_q[i] && s_valid_q[j] && s_uid_q[i] == s_uid_q[j]) f_vbits[7] = 1'b1;
    end
    // X7: ghost distance between the uid counter and X
    if (f_acc_x_q && (uid_cnt_q != f_x7_exp)) f_vbits[8] = 1'b1;
    if (f_after_q == {UID_W{1'b1}}) f_vbits[9] = 1'b1;     // X9: ghost never saturates
    if (!f_acc_x_q && f_after_q != '0) f_vbits[10] = 1'b1;  // X10: ghost idle until X is accepted
    if (f_done_x_q && !f_acc_x_q)      f_vbits[11] = 1'b1;  // X11: completed implies accepted
  end
  wire f_viol = |f_vbits;

  (* keep *) wire f_prop = !(f_env_ok_q && f_assume_now && f_viol);
`endif
endmodule
/* verilator lint_on UNSIGNED */

`default_nettype wire
