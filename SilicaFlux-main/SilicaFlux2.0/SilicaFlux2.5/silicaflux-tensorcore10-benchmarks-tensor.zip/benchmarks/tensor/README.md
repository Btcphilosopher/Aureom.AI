# SilicaFlux TensorCore 10 — Tensor Performance Laboratory and GEMM Software Runtime

Aureom.AI | SilicaFlux-HPC · target directory `benchmarks/tensor/`

A reproducible benchmarking framework for the SilicaFlux TensorCore. It executes real matrix workloads on the
**unmodified TENSORCORE 08 RTL** (`silicaflux_tensor_unit`: 4×4 INT8 systolic array, TC03 operand buffers, TC04
INT32 accumulator, TC05 requantiser, TC07 DMA), validates every output byte against independent references, and
takes every performance number from RTL event counters that are cross-checked against an independent tile-schedule
model. The evidence is then used to decide what the hardware should optimise next.

> **Time base: RTL-simulation clock cycles (Verilator 5.020).** FPGA hardware: **NOT RUN** (no board). Energy:
> **NOT AVAILABLE**. No silicon. Per-second figures appear only at labelled nextpnr post-route Fmax *estimates*.
> Delivered as an archive; nothing was committed.

## Results at a glance (`reports/SUMMARY.md`, `dashboard/index.html`)

| | |
|---|---|
| Runs | **267 / 267 VALID**, 0 failed; 316 GEMM commands; 83.1 M MACs; 20.3 M simulated cycles |
| Correctness | 2.48 MB of output region checked byte for byte — **0 mismatches**; 7 198 counter cross-checks — **0 failed** |
| 4×4×4 GEMM | 143 cycles (2.8 % of the array); fixed overhead ≈ 132 cycles + 2.97 cycles per k |
| Best sustained 4×4 | 27.6 % sequential, 42.1 % double-buffered (long K); 128³: 24.2 % / 40.0 % |
| Long-K accumulator | K = 131 071 with A = B = −128 → 2 147 467 264 in every element, exact |
| GEMV (N = 1) | 10.4 % on the double-buffered 4×4; 1.1 % on 16×16 |
| Quantised INT8 output | bit-exact for 5 rounding modes, ReLU, zero-points; SAT counter = reference |
| Array scaling | 4×4 → 16×16 (16× PEs) = 3.4–4.2× throughput; follows the port ceiling 4RC/(R+C) |
| CPU reference | the fastest CPU code per shape on one x86 core (naive C, vectorised C or oneDNN) is 55–751× faster than the 4×4 at its estimated 28.85 MHz (different timing boundaries, stated) |

**Three largest measured bottlenecks** (double-buffered, cycle-weighted):
1. operand memory waiting on the single 32-bit SFB2 port — 41.6 % of busy cycles (port busy 69–88 %);
2. repeated operand loads (no reuse) — 3.3–16.2× the compulsory traffic on tiled GEMMs;
3. per-launch set-up / drain / readout — 29 cycles per job, 19.9 % of busy cycles.

**Next:** widen the operand path (64-bit / dual SFB2 master) → operand reuse in the scheduler → pipelined job
launch; MAX_OUT 8 behind real memories (measured 1.70× at 8-cycle latency). Not recommended on the evidence: more
SRAM banks, a bigger operand buffer without reuse, a bigger array without bandwidth (16×16 also does not fit the
LFE5U-85F: 114 % of its LUTs, 181 % of its DSPs — synthesized estimate). Projections (analytical,
validated to 8.1 % mean error): 1.22–1.53× for the wider port alone, 1.63–1.87× for all three
(`reports/OPTIMISATION.md`).

## Layout

| Path | Content |
|---|---|
| `kernels/` | executable benchmark kernels: `workloads.py` (gemm, gemv, vecmat, qgemm, conv-im2col), `program.py` (memory image, descriptors, output check) |
| `reference/` | `ref_int8.py` (pure-Python loop, numpy int64, requantisation, im2col, direct convolution, bias lowering), `cpu_gemm.c` (naive / vectorised C / oneDNN), `selftest.py` |
| `datasets/` | content-addressed INT8 operands (`store.py`, `manifest.json`, `data/`), `make_datasets.py --verify` |
| `drivers/` | `tb/derive_bench_tb.py` → `tb_tensor_bench.sv` (TC08 testbench + observation); `sim.py` (configs, Verilator builds, parsing); `runtime/` (C host runtime + examples on the RTL) |
| `configs/` | `hardware.json` (23 configurations), `memory.json`, `clocks.json`, `power.json`, `experiments/*.json` (19 experiments) |
| `analysis/` | `counters.py` (extraction, cross-checks), `analyse.py` (roofline, scaling, bottlenecks, projections), `cpu_compare.py`, `synth_sweep.py`, `make_reports.py`, `make_dashboard.py` |
| `reports/` | `runs/` (267 run records), `counters/` (raw snapshots, events, records), `logs/`, `runtime/`, `synth/` (raw Yosys / nextpnr logs of this lab), markdown reports, `analysis.json`, `cpu_reference.json`, `synth_sweep.json` |
| `dashboard/` | `index.html` — self-contained (no external assets), 14 views + reference comparison + next steps |
| `docs/` | 00 audit · 01 methodology · 02 workloads · 03 counters · 04 equations · 05 reproducibility / FPGA procedure |
| `schema/` | `run_record.schema.json` |
| `third_party/silicaflux-tensorcore08/` | TENSORCORE 08, unmodified (`make check-tc08`) |

## Quick start

```bash
make check-tc08 tb ref-selftest
```

```bash
make core
```

```bash
make expand cpu runtime report
```

```bash
make reproduce RUN=C2_long_k_extremes__dbuf__lat1__gemm4x4x131071_daneg_dbneg__s1
```

## Host runtime (`drivers/runtime/`)

`sftc_runtime.{h,c}` over TC08's unmodified bare-metal driver: allocate / identify device buffers, pack host matrices
(any leading dimension), submit asynchronously or run `sftc_gemm()` synchronously, wait, read results, validate
(exact INT32 and the TC05 requantisation contract), read PERF / DMA_PERF counters. Six examples (4×4 GEMM, tiled
non-multiple GEMM, long K at the extreme, GEMV, quantised GEMM with per-channel N-split, asynchronous submission)
pass on the baseline and full builds through TC08's Verilator simulation backend, and reproduce the bench
testbench's cycle counts exactly. There is no PCIe / OS driver and **no integration with PyTorch, TensorFlow, ONNX
Runtime or Triton**.

## What is not claimed

* no FPGA, ASIC or silicon measurement; no measured clock; no power or energy figure;
* no native convolution (im2col is host software), no hardware per-channel requantisation or bias (software lowering);
* 16×16 is outside TC08's verified shapes (run with `ALLOW_UNVERIFIED = 1`, every run checked bit-exactly);
* projected speed-ups of RTL changes are analytical, not measurements;
* BandwidthLab / MemoryLab model outputs are not used anywhere.
