#!/usr/bin/env python3
"""Verify (default) or rebuild every dataset listed in datasets/manifest.json.

  --verify   regenerate every dataset from its specification and compare the SHA-256 with the manifest;
             stored files (datasets/data/*.i8) are compared byte for byte as well
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from datasets import store  # noqa: E402


def main() -> int:
    m = json.loads(store.MANIFEST.read_text())
    bad = 0
    for sid, e in m.items():
        a = store.generate(e["dist"], e["rows"], e["cols"], e["seed"])
        sha = hashlib.sha256(a.tobytes()).hexdigest()
        ok = sha == e["sha256"]
        if e.get("stored"):
            f = HERE / e["file"]
            ok &= f.exists() and f.read_bytes() == a.tobytes()
        bad += int(not ok)
        if not ok:
            print("MISMATCH", sid)
    print(f"datasets: {len(m) - bad}/{len(m)} verified "
          f"({sum(1 for e in m.values() if e.get('stored'))} stored, the rest regenerated deterministically)")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
