`default_nettype none
module fpga_top (input wire logic clk, input wire logic btn, output logic [7:0] led);
  tsu_fpga_harness #(.ENABLE_QUANTIZATION(1), .ENABLE_DOUBLE_BUFFERING(1)) u_h (.*);
endmodule
`default_nettype wire
