# 04 — Command execution and completion

The brief's pipeline, and the hardware event that ends each stage (no stage is timed; every transition waits for a
real handshake or completion signal):

| Stage | Hardware | Ends when |
|---|---|---|
| Host command | `tsu_regs` DOORBELL → `hpc_command_queue` | push handshake (`in_valid && in_ready`) |
| Validation | `tsu_validate`, 15 rules, 20 cycles | `done` pulse; an error ends the command here with no side effect |
| DMA load | TC07 `LOAD_A`, `LOAD_B` (SEAL) per step, 2-D strided SFB2 reads → TC03 fill writes | every fill write acknowledged by TC03, then `fill_end` (set READY) |
| Operand buffering | TC03 set FILLING → READY → IN_USE (`cmp_begin` by the compute sequencer) | the compute side owns the set |
| Systolic execution | TC03 k-slices → TC02 array (one launch per K chunk) | last slice handshake, `cmp_end` (set FREE), readout `m_last` |
| Partial-sum accumulation | TC04 slot opened at chunk 0, every chunk merged, tile committed after the last | TC04 commit of the tile |
| Output conversion | INT32: rows as lanes; INT8: TC05 (per-tile OPEN) + `tsu_q8_pack` | last row written into the output buffer, set READY |
| DMA store | TC07 `STORE` (SEAL): output set → SFB2 writes to C | every write **acknowledged** by memory (SFB2 R7), set released |
| Completion | `tsu_sched` | all descriptor records received, compute and TC05 idle → record pushed |

**Success is never asserted before the output writes complete.** The OK record requires that every STORE
descriptor of the command has delivered its completion record, and TC07 produces that record only after every
write of the descriptor was acknowledged by its target (TC07 doc 03 §5; SFB2 R7: a write response means the write
was performed). The testbench memory model performs a write exactly when it answers it, and the checker compares
the whole memory image after the record, so a premature record would be caught as missing bytes. Mutation S01
(complete without waiting for the STORE records) is killed by exactly this check (docs/08 §6).

## Measured latency (RTL cycles, 4×4 array; 1-cycle memory unless stated; `reports/perf.md`)

| Workload | CYCLES (dequeue → record) | MAC utilisation |
|---|---|---|
| 4×4×4 (1 tile, 1 chunk) | 143 | 2.8 % |
| 32×32×256 sequential (64 tiles × 4 chunks) | 63 578 | 25.8 % |
| 32×32×256 PREFETCH (double buffering) | 40 090 | 40.9 % |
| 32×32×256 PREFETCH, INT8 output | 39 569 | 41.4 % |
| 32×32×256 sequential / PREFETCH behind the DataFabric crossbar | 96 794 / 72 739 | 16.9 % / 22.5 % |

The fixed per-command cost is 20 cycles of validation plus about 2 cycles of record handling; the rest is TC07 / TC02
/ TC04 work identical to TC07's own measurement of the same schedule (63 557 / 40 069 cycles). Utilisation is bounded
by the single 32-bit SFB2 port (a 4×4×64 step moves ~128 words for 1 024 MACs) — doc 09.
