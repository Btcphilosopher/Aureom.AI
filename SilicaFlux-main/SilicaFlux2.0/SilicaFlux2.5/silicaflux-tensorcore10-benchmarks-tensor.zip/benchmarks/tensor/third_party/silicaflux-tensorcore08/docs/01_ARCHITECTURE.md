# 01 — Architecture

## 1. Block diagram

```
 host (SilicaFlux-V register bus, one 4 KiB page)
   │ rb_sel/we/addr/wdata → rb_rdata/err
   ▼
 ┌─ silicaflux_tensor_unit ───────────────────────────────────────────────────────────────────────────────────┐
 │ tsu_regs ── DESC0..11 + DOORBELL ──► hpc_command_queue (M08, 384 b × CMD_QUEUE_DEPTH)                      │
 │    ▲ CPL0..5 / CPL_POP ◄── hpc_command_queue (M08, 192 b × CPL_QUEUE_DEPTH) ◄── record ──┐                 │
 │    │ CTRL / STATUS / INT / PERF                                                          │                 │
 │    │                                     ┌───────────────── tsu_sched ───────────────────┴──────────────┐  │
 │    │                                     │ tsu_validate (15 rules, shift-add products, no multiplier)   │  │
 │    │                                     │ descriptor iterator ── TC06 ttc_tile_iter ── LOAD_A/LOAD_B/STORE ──┐
 │    │                                     │ job iterator        ── TC06 ttc_tile_iter ── jobs (+ TC05 OPEN) ─┐ │
 │    │                                     │ completion collector, first-error capture, watchdog          │ │ │
 │    │                                     │ abort / quiesce / soft reset / stop-on-error / flush         │ │ │
 │    │                                     └──────────────────────────────────────────────────────────────┘ │ │
 │ hpc_perf_counters (M08) ◄─ events ─► perf_ev                                                             │ │
 │ ┌─ tsu_datapath ─────────────────────────────────────────────────────────────────────────────────────┐   │ │
 │ │  TC07 tensor_dma_adapter ◄──────────────────────────── descriptors ◄──────────────────────────────┼───┘ │
 │ │    │ fill port + fill_begin/end              ▲ read port + rd_begin/end                           │     │
 │ │    ▼                                         │                                                    │     │
 │ │  TC03 tensor_operand_buffer ─slices─► TC02 tensor_systolic_array ─rows─► TC04 tensor_acc_subsystem │     │
 │ │       ▲ cmp_begin/end, tile          ▲ cfg                          │ osram (INT32)  │ oquant (INT8)  │     │
 │ │       └── TC07 tdma_compute_seq ◄────┴────────── jobs ◄─────────────┼────────────────┼────────────────┼─────┘
 │ │                                                                     │      TC05 tensor_quantize ◄── OPEN
 │ │                                                                     │                │ tsu_q8_pack     │
 │ │                                                                     ▼                ▼                 │
 │ │                                                  TC07 tensor_output_buffer (M04 scratchpad, 1–2 sets) │
 │ └──────────────────────────────── SFB2 ─────────────────────────────────────────────────────────────────┘
 │                                     │
 │                                tsu_bus_gate (quiesce: hold a presented request, collect every response)
 └─────────────────────────────────────┼────────────────────────────────────────────────────────────────────┘
                                       ▼  m_req_* / m_rsp_*  (SFB2 master: DataFabric crossbar or memory)
```

## 2. The nine required subsystems

| # | Brief subsystem | Implementation | New / reused |
|---|---|---|---|
| 1 | Command / control interface | `tsu_regs` (register page), two `hpc_command_queue` FIFOs, CTRL / STATUS / INT | page new; FIFOs M08 |
| 2 | Tensor tile controller | `tsu_sched` (two `ttc_tile_iter` iterators, descriptor generation, job generation, collector); `tdma_compute_seq` executes one job on the array | scheduler new; iterator TC06; sequencer TC07 |
| 3 | Systolic array | `tensor_systolic_array` (+ `tensor_pe`, `tensor_skew`, `tensor_output_collect`) | TC02 |
| 4 | Operand buffers | `tensor_operand_buffer` (banked A / B regions, 1 or 2 sets) | TC03 |
| 5 | Partial-sum accumulator | `tensor_acc_subsystem` (2 accumulator slots, STRICT_RANGE) | TC04 |
| 6 | Output conversion | INT32: TC04 → output buffer; INT8: `tensor_quantize` + `tsu_q8_pack` | TC05 + new packer |
| 7 | DMA adapter | `tensor_dma_adapter` (2-D strided LOAD_A / LOAD_B / STORE), `tensor_output_buffer` | TC07 |
| 8 | Completion / status logic | `tsu_sched` collector + record, completion FIFO, STATUS, interrupts, `tsu_bus_gate` | new |
| 9 | Performance event interface | `perf_ev` port (20 × 32-bit increments per cycle) + `hpc_perf_counters` PERF page + TC07's 18 DMA counters | port new; bank M08 |

## 3. Parameters

| Parameter | Default | Legal (checked at elaboration in Verilator, Icarus and Yosys) | Notes |
|---|---|---|---|
| `ARRAY_ROWS` × `ARRAY_COLS` | 4 × 4 | 1..16 each; only the **verified** shapes 2×2, 4×4, 8×8 unless `ALLOW_UNVERIFIED = 1` | `TILE_M`, `TILE_N` |
| `DATA_WIDTH` | 8 | **8 only** (INT8 operands) | other widths are rejected |
| `ACC_WIDTH` | 32 | **32 only** (INT32 accumulation) | |
| `TILE_K` | 64 | 1..32767 (KC field width); must fit the operand sets | K chunk per operand set |
| `OPERAND_BUFFER_BYTES` | 2048 | power of two ≥ 64; each set (`OBB / (2·sets)` per A and per B region) must hold a `TILE_M × TILE_K` A block and a `TILE_K × TILE_N` B block and ≥ 2 rows per bank | |
| `NUM_MEMORY_BANKS` | 4 | power of two 1..16 | TC03 A banks; B and output-buffer banks = half |
| `ENABLE_QUANTIZATION` | 0 | 0 / 1 | 1 instantiates TC05 and permits `OUT_FMT = INT8` |
| `ENABLE_DOUBLE_BUFFERING` | 0 | 0 / 1 | 1: two operand and two output sets, permits `FLAGS.PREFETCH` |
| `CMD_QUEUE_DEPTH`, `CPL_QUEUE_DEPTH` | 4, 4 | powers of two 2..256 | |
| `MEM_LO`, `MEM_HI` | 0, 2³² | non-empty, 4-aligned | legal external window; enforced by validation and again by TC07 |
| `MAX_OUT` | 4 | 1, 2, 4, 8, 16 | SFB2 transactions in flight; ≥ 2 behind the crossbar (R6) |
| `K_MAX` | 131 071 | 1..131 071 | the exact INT32 bound for INT8×INT8 (131 071 · 16 384 < 2³¹) |
| `WDOG_LOG2` | 16 | 4..30 | no-progress watchdog |
| `PERF_EN` | 1 | 0 / 1 | counter bank (the event port is always present) |
| `MEM_BACKEND` | GENERIC | GENERIC / FPGA | SRAM library backend of the operand and output buffers (ASIC macros are not wired) |
| `FAULT_INJ` | 0 | 0 / 1 | verification-only fault hooks (`fi_mode`), compiled out by default |

The baseline of the brief is the default: 4×4 INT8, INT32 accumulation, dense GEMM, **sequential DMA** (one operand
set, one output set, the adapter in SEQUENTIAL mode), INT32 output. Quantisation, double buffering and the 2×2 /
8×8 arrays were enabled only after the baseline passed (docs/08 §2).

## 4. One command, end to end

1. **Submit** — the host writes DESC0..11, then DOORBELL: exactly one push into the command queue (refused while
   full, without effect).
2. **Decode / validate** (`tsu_validate`, 20 cycles) — the 15 rules of doc 02 §4, before any side effect. A failing
   command produces its ERROR record and nothing else (no bus access, no buffer write).
3. **Prepare** — per-command constants (TILE_M·LDA, TILE_M·LDC, KC·LDB from the validator's shift-add loop), datapath
   mode (`cfg_prefetch`, `cfg_int8`), both iterators initialised.
4. **Run** — two independent streams over the same tile sequence (output tiles TILE_M × TILE_N in M-major or N-major
   order, K innermost in chunks of KC):
   * *descriptor stream*: per step `LOAD_A` (eff_m rows × eff_k bytes, source `A + m0·LDA + k0`, local stride
     `lda_loc`) and `LOAD_B` with SEAL (eff_k rows × eff_n bytes, source `B + k0·LDB + n0`); after the last chunk of a
     tile `STORE` with SEAL (eff_m rows × eff_n·esz bytes to `C + m0·LDC + esz·n0`). Addresses come from incremental
     pointers (adds only); a simulation check compares every one with the multiplied-out contract.
   * *job stream*: per step one compute job (eff_m, eff_n, eff_k, K, chunk index, local layout); for INT8 output a
     TC05 OPEN descriptor (context = the TC04 slot of the tile, per-tensor M / S / zp, rounding mode, ReLU) before the
     tile's first chunk.
   The adapter fills a TC03 set and seals it; the compute sequencer waits for the sealed set (`cmp_begin`), runs the
   array, releases the set; TC04 accumulates chunks and commits the tile (INT32 rows, or through TC05 as INT8) into
   the output buffer; the adapter's STORE waits for the committed set and writes C over SFB2.
5. **Complete** — when every descriptor has a completion record (each STORE record means all of its writes were
   **acknowledged** by memory, SFB2 R7), compute is idle and TC05 is idle, the scheduler pushes the OK record:
   COUNT = acknowledged C bytes, TILES = STOREs OK, CYCLES = dequeue → record.

`lda_loc(eff_k)` = eff_k rounded up to 4 bytes, plus 4 if that is a multiple of 8 (an odd word stride, so the TILE_M A
rows of a slice sit in different TC03 banks — TC07's layout). The B local stride is `TILE_N` rounded up to 4.

## 5. Why the two streams cannot deadlock

The streams meet only through buffer ownership. A job waits for a set whose LOADs were issued earlier in the
descriptor stream; a STORE waits for a tile whose jobs were issued earlier in the job stream; LOADs wait for a set
that compute releases after a job; the output set a tile needs is released by the STORE of an earlier tile, which was
issued before that tile's LOADs (TC07 doc 04 §5 ordering rule). Every wait therefore points to an older item in the
other stream, and there is no cycle. The per-channel queues of the adapter (depth 4) only bound how far the
descriptor stream runs ahead.

## 6. Clock, reset, soft reset

One clock. `rst_n`: asynchronous assert, synchronous release (SilicaFlux convention); it resets everything, and
commands destroyed by it produce no record. After any execution error or an abort the scheduler stops issuing, asks
`tsu_bus_gate` to quiesce the SFB2 port (a request already presented is kept until accepted — SFB2 R2 — and no new one
leaves; every response is collected), then holds the datapath in reset for 4 clock edges through a **registered**
request (`dp_rst_n = rst_n & ~srst_q`, glitch-free), which both the asynchronous-reset blocks (TC02/03/07, M04) and the
synchronous-reset blocks (TC04/05) see. The record is pushed after that, so the next command always starts on a clean
datapath.

## 7. Scheduler states (`STATUS[11:8]`)

| State | Leaves when |
|---|---|
| IDLE | a command is queued (→ DECODE) or an abort is pending (→ FLUSH) |
| DECODE | stop-on-error with sticky error (→ RECORD, SKIPPED); validation done (→ RECORD for errors and NOP, → PREP) |
| PREP | always (→ RUN) |
| RUN | first error / abort / watchdog (→ QUIESCE); all descriptors completed and compute idle (→ RECORD, OK) |
| QUIESCE | port drained (→ SRST); no progress for 2^WDOG_LOG2 cycles (→ RECORD, then HALT) |
| SRST | 4 reset edges + 2 settle cycles (→ RECORD) |
| RECORD | the completion queue accepted the record (→ IDLE, FLUSH after an abort, HALT after a failed quiesce) |
| FLUSH | the command queue is empty (every queued command got a SKIPPED / ABORTED record) |
| HALT | only a hard reset |
