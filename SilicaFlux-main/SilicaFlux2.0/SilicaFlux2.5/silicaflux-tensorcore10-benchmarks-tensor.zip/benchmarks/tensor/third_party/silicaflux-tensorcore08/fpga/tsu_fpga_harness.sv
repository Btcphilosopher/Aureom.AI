// =============================================================================
// SilicaFlux TENSORCORE 08 :: tsu_fpga_harness  -- place-and-route harness
//
// silicaflux_tensor_unit has ~85 inputs and ~750 outputs (including the 640-bit
// performance event interface), more than an FPGA board offers.  To place and
// route the COMPLETE unit and obtain nextpnr's post-route timing estimate, this
// harness uses the method of HPC Module 08 hpc_tile_fpga_harness (and Module 03):
//   * every unit input is driven from registers loaded from a 64-bit LFSR, so
//     every input path starts at a flip-flop and no logic is constant;
//   * every unit output is XOR-folded into a registered 64-bit signature reduced
//     to 8 LEDs, so no logic can be removed;
//   * the reset button is synchronised (asynchronous assert, synchronous release).
// It is NOT a functional test (bus handshake rules are not respected); the unit
// is verified in simulation.  The harness flip-flops are included in the
// reported utilisation.  Board pins (ULX3S: 25 MHz clock G2, button R1, LEDs)
// appear only in the constraint file written by syn/run_synth.py.
// =============================================================================
`include "tsu_defs.svh"
`include "sram_defs.svh"
`default_nettype none

module tsu_fpga_harness #(
  parameter int ARRAY_ROWS              = 4,
  parameter int ARRAY_COLS              = 4,
  parameter int OPERAND_BUFFER_BYTES    = 2048,
  parameter int NUM_MEMORY_BANKS        = 4,
  parameter int ENABLE_QUANTIZATION     = 0,
  parameter int ENABLE_DOUBLE_BUFFERING = 0,
  parameter int MEM_BACKEND             = `SRAM_BACKEND_FPGA
) (
  input  wire logic       clk,
  input  wire logic       btn,                  // reset, active high
  output logic      [7:0] led
);
  localparam int NPC  = `TSU_NUM_PC;
  localparam int NIN  = 1 + 1 + 12 + 32 + 1 + 1 + 32 + 1;
  localparam int NOUT = 32 + 1 + 1 + 1 + 32 + 32 + 4 + 1 + 3 + NPC * 32;

  logic [1:0] rs_q;
  always_ff @(posedge clk or posedge btn)
    if (btn) rs_q <= 2'b00; else rs_q <= {rs_q[0], 1'b1};
  wire rst_n = rs_q[1];

  logic [63:0]    lfsr_q;
  logic [NIN-1:0] in_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin lfsr_q <= 64'h1; in_q <= '0; end
    else begin
      lfsr_q <= {lfsr_q[62:0], lfsr_q[63] ^ lfsr_q[62] ^ lfsr_q[60] ^ lfsr_q[59]};
      in_q   <= {in_q[NIN-65:0], lfsr_q};
    end
  end

  logic [31:0]        rb_rdata, m_req_addr, m_req_wdata;
  logic               rb_err, m_req_valid, m_req_write, m_rsp_ready, irq, busy, halted;
  logic [3:0]         m_req_wstrb;
  logic [NPC*32-1:0]  perf_ev;

  silicaflux_tensor_unit #(
    .ARRAY_ROWS(ARRAY_ROWS), .ARRAY_COLS(ARRAY_COLS), .OPERAND_BUFFER_BYTES(OPERAND_BUFFER_BYTES),
    .NUM_MEMORY_BANKS(NUM_MEMORY_BANKS), .ENABLE_QUANTIZATION(ENABLE_QUANTIZATION),
    .ENABLE_DOUBLE_BUFFERING(ENABLE_DOUBLE_BUFFERING), .MEM_BACKEND(MEM_BACKEND)
  ) u_tsu (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(in_q[0]), .rb_we(in_q[1]), .rb_addr(in_q[2 +: 12]), .rb_wdata(in_q[14 +: 32]),
    .rb_rdata(rb_rdata), .rb_err(rb_err),
    .m_req_valid(m_req_valid), .m_req_ready(in_q[46]), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_rsp_valid(in_q[47]), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(in_q[48 +: 32]), .m_rsp_error(in_q[80]),
    .irq(irq), .busy(busy), .halted(halted), .perf_ev(perf_ev), .fi_mode(2'd0));

  wire [NOUT-1:0] outs = {rb_rdata, rb_err, m_req_valid, m_req_write, m_req_addr, m_req_wdata, m_req_wstrb,
                          m_rsp_ready, irq, busy, halted, perf_ev};
  logic [63:0] sig_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) sig_q <= '0;
    else begin
      logic [63:0] f;
      f = {sig_q[62:0], sig_q[63]};
      for (int i = 0; i < NOUT; i++) f[i % 64] = f[i % 64] ^ outs[i];
      sig_q <= f;
    end
  end
  always_ff @(posedge clk) led <= sig_q[7:0] ^ sig_q[15:8] ^ sig_q[23:16] ^ sig_q[31:24] ^
                                 sig_q[39:32] ^ sig_q[47:40] ^ sig_q[55:48] ^ sig_q[63:56];
endmodule

`default_nettype wire
