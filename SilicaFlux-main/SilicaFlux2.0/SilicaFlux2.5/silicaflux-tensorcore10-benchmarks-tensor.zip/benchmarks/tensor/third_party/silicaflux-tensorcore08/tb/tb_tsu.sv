// =============================================================================
// SilicaFlux TENSORCORE 08 :: tb_tsu
// End-to-end integration testbench of silicaflux_tensor_unit.
//
//   host BFM (register bus) ── rb page ──► DUT ── SFB2 ──┬───────────────────────► memory model
//                                                         └─ XBAR=1: DataFabric sfb_crossbar (round robin)
//                                                            with a second, competing traffic master
//
// The host runs build/<test>/prog.txt (model/gen_tests.py): it stages each
// 12-word descriptor in DESC0..11 and rings DOORBELL exactly like software,
// pops every completion record through CPL0..5 / CPL_POP, and logs them.  The
// memory model performs a write only when it answers it (SFB2 R7), answers
// with an error inside programmable poison windows, adds latency and request
// back-pressure, and in XBAR mode sits behind the real crossbar (R6: one
// transaction per port).  Program operations:
//   C w0..w11   submit a command (retries while DOORBELL is refused: queue full)
//   S n         wait until n records have been collected since the last reset
//   D n         wait n cycles (records keep being collected)
//   A           CTRL.ABORT, then wait until STATUS.ABORTING = 0
//   X n         hard reset (DUT, fabric and memory model together, R11) for n cycles
//   E v         CTRL.ERR_CONT = v          K   CTRL.ERR_CLEAR
//   F v         fault-injection mode       P i lo hi mode dly  memory window i: mode bit0 read error,
//               bit1 write error, bit2 never answered (until reset), bit3 answered dly cycles late
//   N v         INT_ENABLE = v             Q   wait for all records, then finish
// Outputs: records.txt (R lines, X markers), mem_final.hex, perf.txt, and a
// RESULT line; model/check.py compares them with the reference.
// =============================================================================
`timescale 1ns/1ps
`include "tsu_defs.svh"
module tb_tsu;
  parameter int ROWS = 4, COLS = 4, TK = 64, OPB = 2048, NB = 4, QUANT = 0, DBUF = 0, MAXOUT = 4, KMAX = 131071;
  parameter int CMDQ = 4, CPLQ = 4, WDOG = 16, FI = 0, XBAR = 0;
  parameter int MEM_BASE = 32'h1000_0000, MEM_BYTES = 1 << 20;
  localparam int NPC = `TSU_NUM_PC;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int errors = 0;
  `define ERR(args) begin errors = errors + 1; if (errors <= 40) begin $write("ERROR cyc=%0d: ", cyc); $display args ; end end

  int unsigned rs [0:7];
  function automatic int unsigned rnd(input int s);
    int unsigned x;
    x = rs[s]; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rs[s] = x; return x;
  endfunction
  // the random streams advance in a fixed order, independent of short-circuit evaluation
  function automatic bit pct(input int s, input int p);
    int unsigned r;
    if (p <= 0) return 1'b0;
    r = rnd(s);
    return (r % 100) < p;
  endfunction

  // ------------------------------------------------------------ DUT
  logic        rb_sel = 1'b0, rb_we = 1'b0, rb_err;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0, rb_rdata;
  logic        t_req_valid, t_req_ready, t_req_write, t_rsp_valid, t_rsp_ready, t_rsp_error;
  logic [31:0] t_req_addr, t_req_wdata, t_rsp_rdata;
  logic [3:0]  t_req_wstrb;
  logic        irq, busy, halted;
  logic [NPC*32-1:0] perf_ev;
  logic [1:0]  fi_mode = 2'd0;

  silicaflux_tensor_unit #(
    .ARRAY_ROWS(ROWS), .ARRAY_COLS(COLS), .DATA_WIDTH(8), .ACC_WIDTH(32), .TILE_K(TK), .OPERAND_BUFFER_BYTES(OPB),
    .NUM_MEMORY_BANKS(NB), .ENABLE_QUANTIZATION(QUANT), .ENABLE_DOUBLE_BUFFERING(DBUF), .CMD_QUEUE_DEPTH(CMDQ),
    .CPL_QUEUE_DEPTH(CPLQ), .MEM_LO(33'(MEM_BASE)), .MEM_HI(33'(MEM_BASE) + 33'(MEM_BYTES)), .MAX_OUT(MAXOUT),
    .K_MAX(KMAX), .WDOG_LOG2(WDOG), .PERF_EN(1), .FAULT_INJ(FI)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(rb_rdata), .rb_err(rb_err),
    .m_req_valid(t_req_valid), .m_req_ready(t_req_ready), .m_req_write(t_req_write), .m_req_addr(t_req_addr),
    .m_req_wdata(t_req_wdata), .m_req_wstrb(t_req_wstrb), .m_rsp_valid(t_rsp_valid), .m_rsp_ready(t_rsp_ready),
    .m_rsp_rdata(t_rsp_rdata), .m_rsp_error(t_rsp_error),
    .irq(irq), .busy(busy), .halted(halted), .perf_ev(perf_ev), .fi_mode(fi_mode));

  logic [31:0] pc_viol, pc_nreq, pc_nrsp, pc_out;
  sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT((XBAR != 0) ? 1 : MAXOUT), .NAME("tsu_sfb")) u_chk (
    .clk(clk), .rst_n(rst_n), .req_valid(t_req_valid), .req_ready(t_req_ready), .req_write(t_req_write),
    .req_addr(t_req_addr), .req_wdata(t_req_wdata), .req_wstrb(t_req_wstrb), .rsp_valid(t_rsp_valid),
    .rsp_ready(t_rsp_ready), .rsp_rdata(t_rsp_rdata), .rsp_error(t_rsp_error),
    .violations(pc_viol), .n_req(pc_nreq), .n_rsp(pc_nrsp), .outstanding(pc_out));

  // ------------------------------------------------------------ memory-side port (direct or behind the crossbar)
  logic        s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [31:0] s_req_addr, s_req_wdata, s_rsp_rdata;
  logic [3:0]  s_req_wstrb;
  // competing master (XBAR only)
  logic        n_req_valid = 1'b0, n_req_ready, n_req_write = 1'b0, n_rsp_valid, n_rsp_error;
  logic [31:0] n_req_addr = '0, n_req_wdata = '0, n_rsp_rdata;
  logic [3:0]  n_req_wstrb = '0;
  int          noise = 0;
  longint      n_noise = 0;

  if (XBAR != 0) begin : g_xbar
    /* verilator lint_off UNUSEDSIGNAL */
    logic xe; logic [31:0] xa; logic xm, xw; logic [1:0] xacc, xst, xloss, xrst;
    /* verilator lint_on UNUSEDSIGNAL */
    sfb_crossbar #(.NM(2), .NS(1), .AW(32), .DW(32), .ARB_MODE(1), .CHECK_ALIGN(1),
                   .SLV_BASE(32'(MEM_BASE)), .SLV_MASK(32'(~(MEM_BYTES - 1))), .MST_SLV_EN(2'b11)) u_xbar (
      .clk(clk), .rst_n(rst_n),
      .m_req_valid({n_req_valid, t_req_valid}), .m_req_ready({n_req_ready, t_req_ready}),
      .m_req_write({n_req_write, t_req_write}), .m_req_addr({n_req_addr, t_req_addr}),
      .m_req_wdata({n_req_wdata, t_req_wdata}), .m_req_wstrb({n_req_wstrb, t_req_wstrb}),
      .m_rsp_valid({n_rsp_valid, t_rsp_valid}), .m_rsp_ready({1'b1, t_rsp_ready}),
      .m_rsp_rdata({n_rsp_rdata, t_rsp_rdata}), .m_rsp_error({n_rsp_error, t_rsp_error}),
      .s_req_valid(s_req_valid), .s_req_ready(s_req_ready), .s_req_write(s_req_write), .s_req_addr(s_req_addr),
      .s_req_wdata(s_req_wdata), .s_req_wstrb(s_req_wstrb), .s_rsp_valid(s_rsp_valid), .s_rsp_ready(s_rsp_ready),
      .s_rsp_rdata(s_rsp_rdata), .s_rsp_error(s_rsp_error),
      .err_evt(xe), .err_addr(xa), .err_master(xm), .err_write(xw),
      .ev_req_accept(xacc), .ev_req_stall(xst), .ev_arb_loss(xloss), .ev_rsp_stall(xrst));
  end else begin : g_direct
    assign s_req_valid = t_req_valid; assign t_req_ready = s_req_ready; assign s_req_write = t_req_write;
    assign s_req_addr = t_req_addr; assign s_req_wdata = t_req_wdata; assign s_req_wstrb = t_req_wstrb;
    assign t_rsp_valid = s_rsp_valid; assign s_rsp_ready = t_rsp_ready; assign t_rsp_rdata = s_rsp_rdata;
    assign t_rsp_error = s_rsp_error;
    assign n_req_ready = 1'b0; assign n_rsp_valid = 1'b0; assign n_rsp_rdata = '0; assign n_rsp_error = 1'b0;
  end

  // ------------------------------------------------------------ SFB2 memory model (write performed at response, R7)
  logic [7:0] mem [0:MEM_BYTES-1];
  int lat_min = 1, lat_max = 1, bp = 0, rsp_bp = 0;
  logic [31:0] pz_lo [0:3], pz_hi [0:3];
  int          pz_mode [0:3], pz_dly [0:3];
  localparam int QN = 64;
  logic q_w [0:QN-1]; logic [31:0] q_a [0:QN-1], q_d [0:QN-1]; logic [3:0] q_s [0:QN-1]; longint q_t [0:QN-1];
  int q_head = 0, q_tail = 0, outst_q = 0;
  logic rsp_v_q = 1'b0, rsp_e_q = 1'b0, rdy_q = 1'b0; logic [31:0] rsp_d_q = '0;
  assign s_rsp_valid = rsp_v_q; assign s_rsp_error = rsp_e_q; assign s_rsp_rdata = rsp_d_q;
  assign s_req_ready = rdy_q && rst_n && (outst_q < QN - 2);
  always @(posedge clk)
    if (!rst_n) outst_q <= 0;
    else        outst_q <= outst_q + ((s_req_valid && s_req_ready) ? 1 : 0) - ((rsp_v_q && s_rsp_ready) ? 1 : 0);
  function automatic bit inwin(input logic [31:0] a);
    return (a >= MEM_BASE) && (64'(a) < 64'(MEM_BASE) + 64'(MEM_BYTES));
  endfunction
  function automatic bit poisoned(input logic [31:0] a, input bit w);
    for (int i = 0; i < 4; i++) if (a >= pz_lo[i] && a < pz_hi[i] && ((pz_mode[i] >> (w ? 1 : 0)) & 1) != 0) return 1'b1;
    return 1'b0;
  endfunction
  function automatic longint extra_delay(input logic [31:0] a);
    for (int i = 0; i < 4; i++) if (a >= pz_lo[i] && a < pz_hi[i]) begin
      if ((pz_mode[i] & 4) != 0) return 64'd1 << 40;          // black hole: never answered (until reset)
      if ((pz_mode[i] & 8) != 0) return longint'(pz_dly[i]);
    end
    return 0;
  endfunction
  longint n_rd = 0, n_wr = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      q_head = 0; q_tail = 0; rsp_v_q <= 1'b0; rsp_e_q <= 1'b0; rdy_q <= 1'b0;
    end else begin
      bit can_rsp, hold_rsp;
      can_rsp  = (!rsp_v_q || s_rsp_ready) && q_head != q_tail && cyc >= q_t[q_head % QN];
      // explicit if: Verilator 5.020 evaluates an impure call in the unselected arm of ?:
      hold_rsp = 1'b0;
      if (can_rsp) hold_rsp = pct(3, rsp_bp);
      if (can_rsp && !hold_rsp) begin
        int h; logic [31:0] o; logic e;
        h = q_head % QN; q_head = q_head + 1; o = q_a[h] - MEM_BASE;
        e = !inwin(q_a[h]) || poisoned(q_a[h], q_w[h]);
        rsp_v_q <= 1'b1; rsp_e_q <= e;
        if (q_w[h]) begin
          rsp_d_q <= '0;
          if (!e) for (int b = 0; b < 4; b++) if (q_s[h][b]) mem[o + b] = q_d[h][8*b +: 8];
        end else rsp_d_q <= e ? 32'd0 : {mem[o+3], mem[o+2], mem[o+1], mem[o]};
      end else if (rsp_v_q && s_rsp_ready) rsp_v_q <= 1'b0;
      if (s_req_valid && s_req_ready) begin
        int t; longint jit;
        t = q_tail % QN;
        jit = 0;
        if (lat_max > lat_min) jit = longint'(rnd(1) % (lat_max - lat_min + 1));
        q_w[t] = s_req_write; q_a[t] = s_req_addr; q_d[t] = s_req_wdata; q_s[t] = s_req_wstrb;
        q_t[t] = cyc + lat_min + jit + extra_delay(s_req_addr);
        q_tail = q_tail + 1;
        if (s_req_addr[1:0] != 2'b00) `ERR(("misaligned SFB2 address %h", s_req_addr))
        if (s_req_write) n_wr = n_wr + 1; else n_rd = n_rd + 1;
      end
      rdy_q <= !pct(2, bp);
    end
  end

  // ------------------------------------------------------------ competing traffic master (XBAR only)
  // random reads / writes inside the noise window; its own read data is checked against a shadow copy
  logic [31:0] nz_lo = '0, nz_hi = '0;
  localparam int NZW = 1024;                  // noise window: up to 4 KiB
  logic [31:0] n_shadow [0:NZW-1];
  bit          n_sv     [0:NZW-1];
  initial for (int i = 0; i < NZW; i++) n_sv[i] = 1'b0;
  logic        n_pend = 1'b0, n_pw = 1'b0;
  logic [31:0] n_pa = '0;
  bit          n_go;
  always @(posedge clk) begin
    if (!rst_n) begin
      n_req_valid <= 1'b0; n_pend <= 1'b0;
    end else if (XBAR != 0) begin
      if (n_req_valid && n_req_ready) begin
        n_req_valid <= 1'b0; n_pend <= 1'b1; n_pw <= n_req_write; n_pa <= n_req_addr;
        if (n_req_write) begin n_shadow[(n_req_addr - nz_lo) >> 2] = n_req_wdata; n_sv[(n_req_addr - nz_lo) >> 2] = 1'b1; end
      end
      if (n_rsp_valid) begin
        n_pend <= 1'b0; n_noise = n_noise + 1;
        if (n_rsp_error) `ERR(("noise master: error response at %h", n_pa))
        if (!n_pw && n_sv[(n_pa - nz_lo) >> 2] && n_rsp_rdata != n_shadow[(n_pa - nz_lo) >> 2])
          `ERR(("noise master: read %h at %h, expected %h", n_rsp_rdata, n_pa, n_shadow[(n_pa - nz_lo) >> 2]))
      end
      if (!n_req_valid && !n_pend && !(n_rsp_valid) && nz_hi > nz_lo) n_go = pct(4, noise);
      else n_go = 1'b0;
      if (n_go) begin
        logic [31:0] a;
        a = nz_lo + ((rnd(5) % (((nz_hi - nz_lo) >> 2) < NZW ? ((nz_hi - nz_lo) >> 2) : NZW)) << 2);
        n_req_valid <= 1'b1; n_req_addr <= a; n_req_write <= ((rnd(6) & 32'd1) != 32'd0); n_req_wdata <= rnd(7); n_req_wstrb <= 4'hF;
      end
    end
  end

  // ------------------------------------------------------------ host BFM (register bus)
  bit rb_full;                                // command queue full in the strobe cycle
  task automatic rb(input bit we, input logic [11:0] a, input logic [31:0] d, output logic [31:0] q, output bit e);
    @(negedge clk);
    rb_sel = 1'b1; rb_we = we; rb_addr = a; rb_wdata = d;
    #1; q = rb_rdata; e = rb_err; rb_full = dut.cq_full;
    @(posedge clk); #1;
    rb_sel = 1'b0; rb_we = 1'b0;
  endtask
  task automatic wr32(input logic [11:0] a, input logic [31:0] d);
    logic [31:0] q; bit e;
    rb(1'b1, a, d, q, e);
    if (e) `ERR(("register write %h refused", a))
  endtask
  task automatic rd32(input logic [11:0] a, output logic [31:0] q);
    bit e;
    rb(1'b0, a, 32'd0, q, e);
    if (e) `ERR(("register read %h refused", a))
  endtask

  int fd_rec, n_rec = 0, n_irq = 0, n_sub = 0;
  bit irq_q = 1'b0;
  always @(posedge clk) begin irq_q <= irq; if (irq && !irq_q) n_irq <= n_irq + 1; end

  // pop every available record
  task automatic collect();
    logic [31:0] st, r0, r1, r2, r3, r4, r5; bit e;
    rd32(`TSU_R_STATUS, st);
    while (st[`TSU_SB_CPL_VALID]) begin
      rd32(`TSU_R_CPL0, r0); rd32(`TSU_R_CPL0 + 12'd4, r1); rd32(`TSU_R_CPL0 + 12'd8, r2);
      rd32(`TSU_R_CPL0 + 12'd12, r3); rd32(`TSU_R_CPL0 + 12'd16, r4); rd32(`TSU_R_CPL0 + 12'd20, r5);
      rb(1'b1, `TSU_R_CPL_POP, 32'd1, st, e);
      if (e) `ERR(("CPL_POP refused with a record present"))
      $fdisplay(fd_rec, "R %h %h %h %h %h %h", r0, r1, r2, r3, r4, r5);
      n_rec = n_rec + 1;
      rd32(`TSU_R_STATUS, st);
    end
  endtask

  task automatic hard_reset(input int n);
    rst_n = 1'b0;
    repeat (n) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
    repeat (2) @(posedge clk);
    n_rec = 0; n_sub = 0;
    $fdisplay(fd_rec, "X");
  endtask

  // ------------------------------------------------------------ program
  string dir;
  logic [63:0] op;                            // program token, right-justified characters
  int fd, rc, rt, maxcyc = 20_000_000;
  logic [31:0] f [0:11];
  logic [31:0] tok;
  initial begin
    int s, v;
    if (!$value$plusargs("dir=%s", dir)) dir = ".";
    if (!$value$plusargs("seed=%d", s)) s = 1;
    for (int i = 0; i < 8; i++) rs[i] = 32'h9E37_79B9 * (s + i * 7919) + 32'h1234_5 + i;
    void'($value$plusargs("lat_min=%d", lat_min)); void'($value$plusargs("lat_max=%d", lat_max));
    void'($value$plusargs("bp=%d", bp)); void'($value$plusargs("rsp_bp=%d", rsp_bp));
    void'($value$plusargs("noise=%d", noise)); void'($value$plusargs("maxcyc=%d", maxcyc));
    if ($value$plusargs("nz_lo=%h", v)) nz_lo = v;
    if ($value$plusargs("nz_hi=%h", v)) nz_hi = v;
    if (lat_max < lat_min) lat_max = lat_min;
    for (int i = 0; i < 4; i++) begin pz_lo[i] = '0; pz_hi[i] = '0; pz_mode[i] = 0; pz_dly[i] = 0; end
    $readmemh({dir, "/mem_init.hex"}, mem);
    fd_rec = $fopen({dir, "/records.txt"}, "w");
    fd = $fopen({dir, "/prog.txt"}, "r");
    if (fd == 0) begin $display("RESULT FAIL (no prog.txt)"); $finish; end
    repeat (4) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
    repeat (2) @(posedge clk);
    begin : main
      logic [31:0] q, stv; bit e;
      // identification
      rd32(`TSU_R_ID, q);
      if (q != `TSU_ID_VALUE) `ERR(("ID %h", q))
      rt = 1;
      while (!$feof(fd) && rt == 1) begin
        rt = $fscanf(fd, "%s", op);
        if (rt == 1) case (op)
          64'("C"): begin
            for (int i = 0; i < 12; i++) begin rc = $fscanf(fd, "%h", tok); f[i] = tok; end
            for (int i = 0; i < 12; i++) wr32(12'(`TSU_R_DESC0 + 4 * i), f[i]);
            rb(1'b1, `TSU_R_DOORBELL, 32'd1, q, e);
            while (e) begin
              if (!rb_full) `ERR(("DOORBELL refused while the queue is not full"))
              collect();
              rb(1'b1, `TSU_R_DOORBELL, 32'd1, q, e);
            end
            n_sub = n_sub + 1;
          end
          64'("S"): begin rc = $fscanf(fd, "%d", v); while (n_rec < v) collect(); end
          64'("D"): begin
            rc = $fscanf(fd, "%d", v);
            begin longint t0; t0 = cyc; while (cyc < t0 + v) collect(); end
          end
          64'("A"): begin
            wr32(`TSU_R_CTRL, 32'(1 << `TSU_CTRL_ABORT));
            do begin collect(); rd32(`TSU_R_STATUS, stv); end while (stv[`TSU_SB_ABORTING]);
          end
          64'("X"): begin rc = $fscanf(fd, "%d", v); hard_reset(v); end
          64'("E"): begin rc = $fscanf(fd, "%d", v); wr32(`TSU_R_CTRL, 32'(v & 1)); end
          64'("K"): begin rd32(`TSU_R_CTRL, q); wr32(`TSU_R_CTRL, q | 32'(1 << `TSU_CTRL_ERR_CLEAR)); end
          64'("F"): begin rc = $fscanf(fd, "%d", v); fi_mode = 2'(v); end
          64'("N"): begin rc = $fscanf(fd, "%h", v); wr32(`TSU_R_INT_ENABLE, v); end
          64'("P"): begin
            int i, lo, hi, md, dl;
            rc = $fscanf(fd, "%d %h %h %d %d", i, lo, hi, md, dl);
            pz_lo[i] = lo; pz_hi[i] = hi; pz_mode[i] = md; pz_dly[i] = dl;
            $display("TB: memory window %0d [%h, %h) mode %0d delay %0d (rc %0d)", i, pz_lo[i], pz_hi[i], pz_mode[i], pz_dly[i], rc);
          end
          64'("Q"): begin
            while (n_rec < n_sub) collect();
            do begin collect(); rd32(`TSU_R_STATUS, stv); end while (stv[`TSU_SB_BUSY]);
          end
          default: `ERR(("unknown program op %h", op))
        endcase
      end
      // final state checks
      collect();
      rd32(`TSU_R_STATUS, stv);
      if (stv[`TSU_SB_BUSY] || stv[`TSU_SB_CPL_VALID]) `ERR(("unit not idle at the end: STATUS %h", stv))
      rd32(`TSU_R_SUBMITTED, q);
      if (q != 32'(n_sub)) `ERR(("SUBMITTED %0d, %0d doorbells accepted since reset", q, n_sub))
      rb(1'b1, `TSU_R_CPL_POP, 32'd1, q, e);
      if (!e) `ERR(("CPL_POP accepted with no record"))
      rb(1'b1, `TSU_R_ID, 32'd0, q, e);
      if (!e) `ERR(("write to ID accepted"))
      rb(1'b0, 12'h3FC, 32'd0, q, e);
      if (!e) `ERR(("read of an unmapped offset accepted"))
      rb(1'b0, 12'h042, 32'd0, q, e);
      if (!e) `ERR(("misaligned read accepted"))
      begin
        int fp; fp = $fopen({dir, "/perf.txt"}, "w");
        for (int i = 0; i < NPC; i++) begin rd32(12'(`TSU_R_PERF0 + 4 * i), q); $fdisplay(fp, "%0d %0d", i, q); end
        for (int i = 0; i < 18; i++) begin rd32(12'(`TSU_R_DMA_PERF0 + 4 * i), q); $fdisplay(fp, "D%0d %0d", i, q); end
        $fdisplay(fp, "irq_edges %0d", n_irq);
        $fdisplay(fp, "noise_txn %0d", n_noise);
        $fdisplay(fp, "cycles %0d", cyc);
        $fclose(fp);
      end
    end
    $fclose(fd);
    $fclose(fd_rec);
    $writememh({dir, "/mem_final.hex"}, mem);
    if (pc_viol != 0) `ERR(("%0d SFB2 protocol violations", pc_viol))
    $display("TB cycles=%0d records=%0d irq_edges=%0d noise=%0d", cyc, n_rec, n_irq, n_noise);
    $display("RESULT %s", (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end

  int trace = 0;
  initial void'($value$plusargs("trace=%d", trace));
  always @(posedge clk) if (trace != 0 && rst_n) begin
    if (s_req_valid && s_req_ready) $display("T %0d REQ %0d %h", cyc, s_req_write, s_req_addr);
    if (s_rsp_valid && s_rsp_ready) $display("T %0d RSP %h", cyc, s_rsp_rdata);
    if (trace > 1) $display("T %0d RDY %0d V %0d RV %0d RR %0d", cyc, s_req_ready, s_req_valid, s_rsp_valid, s_rsp_ready);
  end

  always @(posedge clk) if (cyc == longint'(maxcyc)) begin
    `ERR(("TB WATCHDOG: busy=%0d halted=%0d records=%0d submitted=%0d", busy, halted, n_rec, n_sub))
    $display("RESULT FAIL"); $finish;
  end
endmodule
