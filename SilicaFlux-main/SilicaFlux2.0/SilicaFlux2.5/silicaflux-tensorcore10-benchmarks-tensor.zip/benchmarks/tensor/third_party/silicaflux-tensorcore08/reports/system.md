# Coexistence: HPC Module 08 tile + tensor unit + host on the DataFabric crossbar

**9 / 9 runs pass** (scripts/run_system.py, tb/tb_system.sv).

| Seed | SRAM latency | Host CPU traffic | Result | Tensor records | Tile records | Both units busy (cycles) | Host transactions | Arbitration losses host / tile / tensor |
|---|---|---|---|---|---|---|---|---|
| 1 | 1 | 0 % | PASS | 10 | 9 | 59447 | 0 | 0 / 85 / 8698 |
| 1 | 1 | 40 % | PASS | 10 | 9 | 62273 | 49040 | 4287 / 2038 / 61086 |
| 1 | 4 | 25 % | PASS | 10 | 9 | 142104 | 61382 | 18767 / 25372 / 102044 |
| 2 | 1 | 0 % | PASS | 10 | 9 | 58702 | 0 | 0 / 69 / 8785 |
| 2 | 1 | 40 % | PASS | 10 | 9 | 61573 | 48316 | 4147 / 2126 / 60548 |
| 2 | 4 | 25 % | PASS | 10 | 9 | 139927 | 60448 | 18495 / 25075 / 100726 |
| 3 | 1 | 0 % | PASS | 10 | 9 | 58494 | 0 | 0 / 82 / 8518 |
| 3 | 1 | 40 % | PASS | 10 | 9 | 61316 | 53982 | 4308 / 1982 / 65538 |
| 3 | 4 | 25 % | PASS | 10 | 9 | 139653 | 68059 | 18475 / 24878 / 107662 |
