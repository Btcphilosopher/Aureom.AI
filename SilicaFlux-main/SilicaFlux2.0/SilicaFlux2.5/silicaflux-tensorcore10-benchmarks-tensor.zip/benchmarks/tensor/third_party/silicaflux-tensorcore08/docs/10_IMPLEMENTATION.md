# 10 — FPGA and ASIC flows

**FPGAFlow does not exist in the repository** (doc 00); the flow is the repository's own practice — Yosys 0.33 and
nextpnr-ecp5 on the ULX3S device (LFE5U-85F CABGA381), as used by TENSORCORE 03 and HPC Module 08. Everything below
was run by `syn/run_synth.py` (results `reports/synth.md`, `reports/synth.json`, raw logs `reports/synth/`) and
`scripts/run_lint.py` (`reports/lint.md`).

| Flow step | Tool | What was run | Status |
|---|---|---|---|
| Lint | Verilator 5.020 `--lint-only -Wall` | 11 legal configurations + the system wrapper; 0 warnings allowed in new RTL | run |
| Elaboration | Icarus 12, Yosys 0.33 `hierarchy -check`, Verilator | the same 11 configurations; 18 illegal configurations must be rejected by all three | run |
| RTL simulation | Verilator 5.020, Icarus 12 | docs/08 | run |
| Generic synthesis | Yosys `synth -flatten`, `check -assert`, latch check | baseline, full, 8×8 full | run |
| FPGA synthesis | Yosys `synth_ecp5`, `synth_xilinx -family xc7` | baseline, full (buffers in block RAM: `MEM_BACKEND = FPGA`) | run |
| FPGA implementation | nextpnr-ecp5 0.6 | harness (`fpga/tsu_fpga_harness.sv`) placed and routed on LFE5U-85F, 25 MHz constraint, seed 1 | run |
| Timing analysis | nextpnr-ecp5 post-route static timing | Fmax estimate of the routed harness | run (estimate) |
| Bitstream / board | ecppack / ULX3S | — | **not run**: no board; nothing was programmed |
| Xilinx implementation | Vivado | — | **not available** |
| ASIC synthesis smoke test | Yosys + ABC, `sky130_fd_sc_hd__tt_025C_1v80.lib` (OpenROAD-flow-scripts) | baseline, buffers as flip-flops | run |
| ASIC place & route, STA, power | OpenROAD / OpenSTA | — | **not available here; not claimed** |

## How to read the numbers

* **Generic cell counts** include every buffer as flip-flops (the SRAM library's GENERIC backend); they show the design
  maps without latches or combinational loops, not its size in a product.
* **ECP5 / Xilinx mapping** puts the operand and output buffers in block RAM (SRAM library FPGA backend); the queues
  and small FIFOs are distributed RAM.
* **The place-and-route harness** is non-functional by construction (LFSR inputs, XOR-folded outputs) so that no logic
  is optimised away; its flip-flops are included in the utilisation. The Fmax figure is nextpnr's estimate for the
  speed grade it models, at one seed — a property of this placement, not a measured clock. The longest paths are
  listed in `reports/synth/pnr_*/nextpnr.log`.
* **The SKY130 smoke test** reports the standard-cell area from the liberty: no wires, no placement, no clock tree,
  flip-flop memories instead of SRAM macros, one corner, and no timing (ABC printed no delay estimate in this flow).
  It shows that the RTL maps completely to a real cell library; it is not an area, timing or power result.

## Results of the final run (`reports/synth.md`)

| Run | Result |
|---|---|
| Generic, baseline / full / 8×8 full | OK — `check -assert` clean, no latch; 133 788 / 186 725 / 345 275 generic cells (34 467 / 38 589 / 67 252 flip-flops, buffers included) |
| ECP5 mapping, baseline | 23 711 LUT4, 10 620 FF, 3 823 CCU2C, 8 DP16KD, 30 MULT18X18D, 344 TRELLIS_DPR16X4 |
| ECP5 mapping, full (INT8 + double buffering) | 31 940 LUT4, 12 425 FF, 5 215 CCU2C, 8 DP16KD, 47 MULT18X18D, 361 TRELLIS_DPR16X4 |
| Xilinx-7 mapping, baseline / full | 16 081 / 20 133 LUT, 9 821 / 11 508 FF, 8 / 8 RAMB18E1, 25 / 41 DSP48E1 |
| nextpnr-ecp5, baseline harness | **routed; post-route Fmax estimate 28.85 MHz — meets the 25 MHz constraint** (36 254 / 83 640 TRELLIS_COMB, 10 759 FF, 8 DP16KD, 31 MULT18X18D) |
| nextpnr-ecp5, full harness | **routed; post-route Fmax estimate 23.93 MHz — FAILS the 25 MHz constraint** at seed 1 (47 273 / 83 640 TRELLIS_COMB, 12 564 FF, 8 DP16KD, 48 MULT18X18D). nextpnr exits with an error for the missed constraint; the routed result is reported, not hidden |

| SKY130 HD smoke test, baseline | OK — mapped completely (no generic cell left): 154 882 cells, 1 597 079 µm² cell area; 34 447 flip-flops and 22 099 `mux2_1` are the buffers and queues built from flip-flops |

Critical paths (nextpnr, routed):
* **baseline**: 34.7 ns = 11.7 ns logic + 23.0 ns routing, from TC02's readout-row register (`u_arr.rd_row_q`) through
  TC04's partial-sum index logic to its storage read pointer (`u_acc.u_store.rp_q`) — the direct array → accumulator
  interface of two reused blocks, routing-dominated.
* **full**: 41.8 ns = 17.1 ns logic + 24.7 ns routing, from TC05's registered shift amount (`u_lane.s2`) through
  the variable arithmetic shift of the registered product, the rounding increment, the zero-point add and the
  saturation (`inc`, `y`, `qs`, `q`) into TC05's output FIFO — one stage of the reused quantiser lane.
Both are inside reused, unmodified blocks; TENSORCORE 08's own logic is not on either critical path. Next actions
(not done): a register slice between TC02's readout and TC04, and one more pipeline stage in TC05's lane — both
change the timing of verified blocks and need their regressions re-run.
