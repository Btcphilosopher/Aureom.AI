# Lint, elaboration and illegal configurations

* Legal configurations — Verilator `-Wall` with **0 warnings in TENSORCORE 08 RTL**, Icarus elaboration, Yosys `hierarchy -check`: **11 / 11**
* Illegal configurations rejected by Verilator, Icarus and Yosys: **18 / 18** (all but `banks_vs_buffer` with the unit's own message in all three tools; see the note below)
* System wrapper (tile + tensor unit + crossbar) Verilator `-Wall`: **0 warnings in new RTL**
* Generated C / Python ABI files up to date with rtl/tsu_defs.svh: **True**

| Legal configuration | Verilator new-RTL warnings | third-party warnings (reused RTL, not modified) | Icarus | Yosys |
|---|---|---|---|---|
| `baseline` | 0 | 70 | ok | ok |
| `quant` | 0 | 70 | ok | ok |
| `dbuf` | 0 | 70 | ok | ok |
| `full` | 0 | 70 | ok | ok |
| `a8` | 0 | 70 | ok | ok |
| `a2` | 0 | 70 | ok | ok |
| `tk16` | 0 | 70 | ok | ok |
| `mo1_noperf` | 0 | 70 | ok | ok |
| `fpga_mem` | 0 | 70 | ok | ok |
| `fault` | 0 | 70 | ok | ok |
| `unverified_3x5` | 0 | 70 | ok | ok |

| Illegal configuration | Verilator | Icarus | Yosys | message seen (V / I / Y) |
|---|---|---|---|---|
| `data_width_16` | rejected | rejected | rejected | y/y/y |
| `acc_width_40` | rejected | rejected | rejected | y/y/y |
| `rows_32` | rejected | rejected | rejected | y/y/y |
| `shape_3x3_unverified` | rejected | rejected | rejected | y/y/y |
| `tile_k_0` | rejected | rejected | rejected | y/y/y |
| `tile_k_40000` | rejected | rejected | rejected | y/y/y |
| `opbuf_not_pow2` | rejected | rejected | rejected | y/y/y |
| `opbuf_too_small` | rejected | rejected | rejected | y/y/y |
| `banks_3` | rejected | rejected | rejected | y/y/y |
| `banks_vs_buffer` | rejected | rejected | rejected | y/y/y |
| `quant_2` | rejected | rejected | rejected | y/y/y |
| `dbuf_2` | rejected | rejected | rejected | y/y/y |
| `max_out_3` | rejected | rejected | rejected | y/y/y |
| `cmdq_3` | rejected | rejected | rejected | y/y/y |
| `k_max_big` | rejected | rejected | rejected | y/y/y |
| `mem_window` | rejected | rejected | rejected | y/y/y |
| `backend_asic` | rejected | rejected | rejected | y/y/y |
| `wdog_2` | rejected | rejected | rejected | y/y/y |

`banks_vs_buffer` (one row per bank): Yosys reports the unit's own check (its line); Verilator reaches the SRAM library's `DEPTH must be >= 2` check first and Icarus fails compiling TC03's zero-width selects. All three reject it, but only Yosys with the unit's message.
