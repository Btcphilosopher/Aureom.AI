# Integration regression (tb/tb_tsu.sv on silicaflux_tensor_unit)

Final run: **111 / 111 runs pass** (202.7 s).  Tools: verilator: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); iverilog: Icarus Verilog version 12.0 (stable) (); yosys: Yosys 0.33 (git sha1 2584903a060); nextpnr-ecp5: "nextpnr-ecp5" -- Next Generation Place and Route (Version 0.6-3build5); python: Python 3.13.18.

Every run: every completion record field the reference predicts, the WHOLE 1 MiB memory image, exact counters where defined (model/check.py), the DataFabric SFB2 protocol checker on the unit's master port, and no simulator error.

| Stage | Test | Configuration × memory: passed / runs |
|---|---|---|
| 1 | `g1x1x1` | base/lat1 1/1 |
| 1 | `g4x4x4` | base/lat1 1/1 |
| 2 | `abort` | base/lat1 6/6, base/rand 6/6 |
| 2 | `b2b` | base/lat1 2/2, base/rand 2/2, mo1/lat1 2/2, mo1/rand 2/2 |
| 2 | `contention` | base/lat1 2/2 |
| 2 | `dma_errors` | base/lat1 1/1, base/rand 1/1, mo1/lat1 1/1, mo1/rand 1/1 |
| 2 | `extreme` | base/lat1 1/1 |
| 2 | `invalid` | base/lat1 1/1 |
| 2 | `irq` | base/lat1 1/1 |
| 2 | `kchunk_long` | base/lat1 1/1 |
| 2 | `reset` | base/lat1 6/6, base/rand 6/6 |
| 2 | `shapes` | base/lat1 2/2, base/lat8 2/2, base/rand 2/2, mo1/lat1 2/2, mo1/lat8 2/2, mo1/rand 2/2 |
| 2 | `shapes_nmajor` | base/lat1 1/1, base/rand 1/1 |
| 2 | `stop_continue` | base/lat1 1/1 |
| 2 | `tiles_large` | base/lat1 1/1, base/rand 1/1 |
| 2 | `watchdog` | wd/lat1 1/1 |
| 3 | `a2_quant` | a2/lat1 1/1 |
| 3 | `a2_shapes` | a2/lat1 1/1, a2/rand 1/1 |
| 3 | `a8_b2b` | a8/lat1 1/1 |
| 3 | `a8_quant` | a8/lat1 2/2 |
| 3 | `a8_shapes` | a8/lat1 1/1, a8/rand 1/1 |
| 3 | `dbuf_abort` | dbuf/rand 3/3 |
| 3 | `dbuf_b2b` | dbuf/rand 1/1 |
| 3 | `dbuf_contention` | dbuf/lat1 1/1 |
| 3 | `dbuf_errors` | dbuf/lat1 1/1 |
| 3 | `dbuf_mixed` | dbuf/lat1 3/3, dbuf/rand 3/3 |
| 3 | `dbuf_reset` | dbuf/rand 3/3 |
| 3 | `dbuf_shapes` | dbuf/lat1 1/1, dbuf/rand 1/1, full/lat1 1/1, full/rand 1/1 |
| 3 | `fault` | fi/lat1 1/1, fi/rand 1/1 |
| 3 | `quant` | full/lat1 2/2, full/rand 2/2, quant/lat1 2/2, quant/rand 2/2 |
| 3 | `quant_invalid` | full/lat1 1/1, quant/lat1 1/1 |
| 3 | `quant_mixed` | full/lat1 3/3, quant/lat1 3/3 |
| 3 | `tk16_b2b` | tk16/lat1 1/1 |
| 3 | `tk16_invalid` | tk16/lat1 1/1 |
| 3 | `tk16_shapes` | tk16/lat1 1/1, tk16/rand 1/1 |

GEMM commands completed OK and checked: **642**; completion records checked: **963**.


## Cross-simulation (Verilator 5.020 vs Icarus 12)

112 / 112 runs pass; **56 / 56 run pairs identical** (the complete record stream including CYCLES, and every counter).

