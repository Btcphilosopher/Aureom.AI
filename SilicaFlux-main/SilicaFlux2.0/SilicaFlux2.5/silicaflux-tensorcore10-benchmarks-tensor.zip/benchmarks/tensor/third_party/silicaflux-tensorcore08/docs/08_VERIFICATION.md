# 08 — Verification

## 1. Method

* **DUT:** the complete `silicaflux_tensor_unit`, driven only through its register page and its SFB2 master port —
  the host BFM stages descriptors and rings DOORBELL exactly as software does, and pops records through CPL0..5.
* **Memory:** an SFB2 slave model that performs a write only when it answers it (R7), with programmable latency,
  request and response back-pressure, error windows (read / write), "never answered" and "answered late" windows; or
  the real DataFabric crossbar in front of it with a competing master (`XBAR = 1`). The DataFabric
  `sfb_protocol_checker` watches the unit's port in every run.
* **Reference:** `model/tsu_ref.py` — descriptor encoding, an independent validator written from the ABI document,
  the GEMM contract in plain Python integers, INT8 output through TENSORCORE 05's own `element()` reference, and the
  exact SFB2 word traffic of the schedule. `model/prog.py` models the stop-on-error state machine, so every
  expected record follows from the ABI rather than from the RTL.
* **Checks per run** (`model/check.py`): every predicted record field (TID, OPCODE, ERR_CODE, STATUS, IRQ, SAT,
  DETAIL, COUNT, ERR_ADDR, SEQ, TILES; CYCLES > 0); the **whole 1 MiB memory image** after the run, reconstructed from
  the records the hardware actually produced (only the C footprint of a command that started and did not finish OK
  is excluded); exact counters (GEMM_OK, TILES, CHUNKS, MACS, DESC, RD_WORDS, WR_WORDS, CMD_DONE, CMD_ACCEPT) in every
  run without reset / abort / execution error; no `$error` (the RTL's own assertions: incremental pointers equal the
  multiplied-out addresses, TC05 context = TC04 slot, TC03 / SRAM-library assertions); RESULT PASS.
* **Race tests** (reset, abort) accept exactly the legal outcomes: a prefix of the expected records before a hard
  reset; for an abort, the expected OK records up to the first ABORTED one, then only SKIPPED / ABORTED.

## 2. Staged bring-up (the brief: baseline first)

`scripts/run_regress.py` runs the stages in order and stops at the first failing stage:

1. **Stage 1** — one command on the 4×4 INT8 / INT32 sequential baseline (4×4×4, 1×1×1).
2. **Stage 2** — the baseline: all brief GEMMs and boundary shapes, K chunks, many tiles, N-major, accumulation
   extremes up to K = 131 071, back-to-back commands, every validation rule, DMA read / write errors with exact
   ERR_ADDR / COUNT / TILES, stop / continue, interrupts, hard reset during operation, abort, crossbar contention,
   watchdog. Also `MAX_OUT = 1`.
3. **Stage 3** — the advanced features, each in its own configuration, only after stage 2 passed: double buffering
   (PREFETCH, mixed with SEQUENTIAL, under reset / abort / errors / contention), INT8 quantisation (all rounding
   modes, ReLU, saturation, unaligned C, mixed with INT32), 8×8 and 2×2 arrays, TILE_K = 16, fault injection.

## 3. Brief §9 → tests

| Brief test | Test(s) | What is checked beyond the memory image |
|---|---|---|
| 4×4 GEMM | `g4x4x4`, `shapes` | |
| 8×8 GEMM | `shapes` (4 output tiles), `a8_shapes` (8×8 array) | |
| 17×13×29 GEMM | `shapes` (two stride sets, odd bases), `system`, `cosim` | |
| Multi-chunk K | `shapes` (8×8×200: 4 chunks; KC = 17: 8 chunks), `kchunk_long` (K = 1 000, 777), `extreme` (K = 131 071: 2 048 chunks), `tk16_*` | exact MACS / CHUNKS counters |
| Back-to-back commands | `b2b` (queue-full doorbell refusals, NOPs, RAW chain: A of one command = C of the previous) | SEQ order, doorbell refused only when full |
| Multiple output tiles | `shapes`, `tiles_large` (64 tiles), `shapes_nmajor` | TILES |
| DMA contention | `contention` (DataFabric crossbar, competing master at 60 %), `system` (tile DMA + host CPU) | competing master's own data (shadow) |
| Reset during operation | `reset` (hard reset at a random point, 6 seeds × 2 memories), `abort` (soft) | prefix rule; next commands exact |
| Invalid commands | `invalid`, `quant_invalid`, `tk16_invalid` (every rule, boundaries) | no bus access (exact word counters) |
| Quantised output when enabled | `quant`, `quant_mixed`, `a8_quant`, `a2_quant`, `cosim` | SAT, element-exact vs TC05 reference |

## 4. Results

`reports/regression.md` (final run on the frozen RTL), `reports/system.md`, `reports/lint.md`,
`reports/cosim_*.log`, `reports/perf.md`, `reports/mutation.md`; summary in the README.

## 5. Cross-simulation

The stage 1–2 baseline subset (including reset and abort) runs under Verilator and Icarus with the same seeds; the
complete record streams (including CYCLES) and all counters must be identical. Two testbench portability issues were
found and fixed on the way: Icarus 12 does not support `break` / string `case` / unpacked-array elements as
system-task arguments in this form, and Verilator 5.020 evaluates an impure function in the unselected arm of `?:`
(which advanced a random stream and made the back-pressure pattern differ). Neither affected the RTL.

## 6. Mutation testing

`scripts/run_mutants.py`: 26 deliberate bugs in the new RTL (scheduler 14, validator 5, bus gate 2, register page 2,
INT8 packer 1, datapath wiring 2), each rebuilt and run against a fixed regression subset. Final result **25 / 26
killed** (`reports/mutation.md`).

* The first campaign left four survivors. Three were **test gaps**, now closed: no test put a footprint's last byte
  exactly on `MEM_HI` (V03), no test made C — rather than A or B — wrap 2³² (V05), and the testbench never compared
  `SUBMITTED` with the accepted doorbells (R01: a doorbell pushed while full is dropped by the FIFO itself, but the
  counter over-counted). All three are killed now; the regression and cross-simulation were re-run afterwards.
* The remaining survivor, **S01** (complete without counting the STORE records), is **equivalent**: the completion
  condition also requires the adapter idle with an empty completion FIFO, and TC07's `busy` covers every descriptor
  until the clock edge that pushes its record, so no cycle exists in which the last record is neither pending nor
  collected. The counter stays as an interlock independent of TC07's internal definition of `busy`.
