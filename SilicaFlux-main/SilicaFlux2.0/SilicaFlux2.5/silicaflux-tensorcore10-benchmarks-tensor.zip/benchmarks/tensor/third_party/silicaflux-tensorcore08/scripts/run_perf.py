#!/usr/bin/env python3
"""Measured GEMM performance of silicaflux_tensor_unit (RTL simulation cycles, tb/tb_tsu.sv).

Each workload runs ALONE in a fresh simulation; every run is also functionally checked (model/check.py).  Reported:
the completion record's CYCLES (dequeue -> record, i.e. including validation and the final write
acknowledgements), MACs, array utilisation = MACs / (CYCLES * ROWS * COLS), and SFB2 words moved.  Memory models: a
1-cycle and an 8-cycle slave (both with up to MAX_OUT = 4 transactions in flight), and the DataFabric crossbar
(one transaction per port, R6) with a 1-cycle slave.  These are simulation cycles against modelled memories, not
a measured clock.
"""
from __future__ import annotations

import sys
import zlib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, CPUS, REPORTS, build, simulate, write_json  # noqa: E402

import check  # noqa: E402
import tsu_abi as A  # noqa: E402
from gen_tests import CFG  # noqa: E402
from prog import Prog  # noqa: E402
from tsu_ref import rec_fields  # noqa: E402

WORKLOADS = {
    "4x4x4":       dict(M=4, N=4, K=4),
    "8x8x8":       dict(M=8, N=8, K=8),
    "17x13x29":    dict(M=17, N=13, K=29, lda=29, ldb=13, ldc=13 * 4 + 8),
    "8x8x200":     dict(M=8, N=8, K=200),
    "32x32x64":    dict(M=32, N=32, K=64),
    "32x32x256":   dict(M=32, N=32, K=256),
    "64x16x64_n":  dict(M=64, N=16, K=64, flags=1 << A.FL_NMAJOR),
    "32x32x256_q8": dict(M=32, N=32, K=256, ofmt=A.OFMT_INT8, qmult=1 << 30, qshift=40),
}
MEMS = {"lat1": {}, "lat8": dict(lat_min=8, lat_max=8), "xbar": dict(lat_min=1, lat_max=1)}
HW = {"base": ("base", 0), "full": ("full", 1 << A.FL_PREFETCH)}


def one(job):
    wl, mem, hw = job
    cfgname, pf = HW[hw]
    w = dict(WORKLOADS[wl])
    if w.get("ofmt") == A.OFMT_INT8 and not CFG[cfgname].quant:
        return None
    w["flags"] = w.get("flags", 0) | pf
    M, N, K = w.pop("M"), w.pop("N"), w.pop("K")
    p = Prog(CFG[cfgname], 11 + zlib.crc32(wl.encode()) % 100)
    p.gemm(M, N, K, a_align=4, b_align=4, **w)
    d = BUILD / "perf" / f"{wl}__{mem}__{hw}"
    p.write(d)
    exe = build(CFG[cfgname], "verilator", 1 if mem == "xbar" else 0)
    simulate(exe, d, MEMS[mem])
    res = check.check(d)
    rec = [rec_fields([int(x, 16) for x in l.split()[1:7]]) for l in (d / "records.txt").read_text().splitlines()
           if l.startswith("R")][0]
    cfg = CFG[cfgname]
    macs = M * N * K
    pf_ = res["perf"]
    return dict(workload=wl, mem=mem, hw=hw, prefetch=bool(pf), ok=res["ok"], cycles=rec["cycles"], macs=macs,
                util=round(100.0 * macs / (rec["cycles"] * cfg.rows * cfg.cols), 1), rd_words=pf_.get("12"),
                wr_words=pf_.get("13"), tiles=rec["tiles"], overlap=pf_.get("11"), dma_buf_wait=pf_.get("D10"))


def main():
    jobs = [(wl, mem, hw) for wl in WORKLOADS for mem in MEMS for hw in HW]
    with ThreadPoolExecutor(CPUS) as ex:
        res = [r for r in ex.map(one, jobs) if r]
    bad = [r for r in res if not r["ok"]]
    write_json(REPORTS / "perf.json", dict(runs=res, failed=len(bad)))
    for r in res:
        print(f"{r['workload']:<13} {r['mem']:<5} {r['hw']:<5} cycles {r['cycles']:>7}  util {r['util']:>5} %  "
              f"rd {r['rd_words']} wr {r['wr_words']}  {'ok' if r['ok'] else 'FAIL'}")
    print(f"perf: {len(res) - len(bad)}/{len(res)} runs functionally correct")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
