`default_nettype none
module fpga_top (input wire logic clk, input wire logic btn, output logic [7:0] led);
  tsu_fpga_harness #() u_h (.*);
endmodule
`default_nettype wire
