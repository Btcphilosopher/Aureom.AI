#!/usr/bin/env python3
"""TENSORCORE 08 implementation flows -- every number in reports/synth.md comes from a log written here.

  generic_<cfg>   Yosys 0.33 generic synthesis of silicaflux_tensor_unit, flattened: check -assert (no combinational
                  loop, no undriven / multi-driven net), no latch, cell statistics
  ecp5_<cfg>      synth_ecp5 mapping (LUT4 / FF / DP16KD / MULT18 estimate), buffers in FPGA block RAM
  xc7_<cfg>       synth_xilinx -family xc7 mapping estimate (no Vivado: no Xilinx place and route)
  pnr_<cfg>       fpga/tsu_fpga_harness.sv -> synth_ecp5 -> nextpnr-ecp5 place and route on LFE5U-85F CABGA381
                  (ULX3S pins), 25 MHz constraint; nextpnr's post-route static timing estimate (Fmax)
  asic_sky130     ASIC synthesis smoke test: generic synthesis, dfflibmap + abc onto sky130_fd_sc_hd (TT 25C 1.80V,
                  from OpenROAD-flow-scripts), stat -liberty area.  Buffers are flip-flops (no SRAM macros), no
                  floorplan, no placement, no wires: NOT a timing, power or tapeout result.
Configurations use literal-parameter wrapper tops (Yosys 0.33 can assert when re-deriving a top via chparam).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from common import BUILD, REPORTS, run, tool_versions, write_json  # noqa: E402

CONFIGS = {
    "baseline": dict(),                                                                  # brief baseline 4x4
    "full":     dict(ENABLE_QUANTIZATION=1, ENABLE_DOUBLE_BUFFERING=1),
    "a8full":   dict(ARRAY_ROWS=8, ARRAY_COLS=8, NUM_MEMORY_BANKS=8, OPERAND_BUFFER_BYTES=4096,
                     ENABLE_QUANTIZATION=1, ENABLE_DOUBLE_BUFFERING=1),
}
SKY130_URL = ("https://raw.githubusercontent.com/The-OpenROAD-Project/OpenROAD-flow-scripts/master/flow/platforms/"
              "sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib")
SKY130_SHA = "ec0e1067a35c8bf20b11e58d1e8ac53326067e4dac84a125cc1b917a3518d0d9"

LPF = """BLOCK RESETPATHS;
LOCATE COMP "clk" SITE "G2";
IOBUF  PORT "clk" PULLMODE=NONE IO_TYPE=LVCMOS33;
FREQUENCY PORT "clk" 25 MHZ;
LOCATE COMP "btn" SITE "R1";
IOBUF  PORT "btn" PULLMODE=DOWN IO_TYPE=LVCMOS33;
""" + "".join(f'LOCATE COMP "led[{i}]" SITE "{s}";\nIOBUF  PORT "led[{i}]" PULLMODE=NONE IO_TYPE=LVCMOS33 DRIVE=4;\n'
              for i, s in enumerate(["B2", "C2", "C1", "D2", "D1", "E2", "E1", "H3"]))

PORTS = """  input  wire logic clk, rst_n, rb_sel, rb_we, input wire logic [11:0] rb_addr, input wire logic [31:0] rb_wdata,
  output logic [31:0] rb_rdata, output logic rb_err,
  output logic m_req_valid, input wire logic m_req_ready, output logic m_req_write, output logic [31:0] m_req_addr,
  output logic [31:0] m_req_wdata, output logic [3:0] m_req_wstrb, input wire logic m_rsp_valid, output logic m_rsp_ready,
  input wire logic [31:0] m_rsp_rdata, input wire logic m_rsp_error, output logic irq, busy, halted,
  output logic [639:0] perf_ev, input wire logic [1:0] fi_mode"""


def flist(extra=()):
    inc, files = [], []
    for line in (ROOT / "rtl/files.f").read_text().splitlines():
        line = line.strip()
        if line.startswith("+incdir+"):
            inc.append(line[len("+incdir+"):])
        elif line and "stubs" not in line:
            files.append(line)
    return inc, files + list(extra)


def wrapper(d: Path, params: dict) -> Path:
    p = ", ".join(f".{k}({v})" for k, v in params.items())
    w = d / "cfg_top.sv"
    w.write_text(f"`default_nettype none\nmodule cfg_top (\n{PORTS}\n);\n"
                 f"  silicaflux_tensor_unit #({p}) u (.*);\nendmodule\n`default_nettype wire\n")
    return w


def harness_top(d: Path, params: dict) -> Path:
    p = ", ".join(f".{k}({v})" for k, v in params.items())
    w = d / "fpga_top.sv"
    w.write_text("`default_nettype none\nmodule fpga_top (input wire logic clk, input wire logic btn, output logic [7:0] led);\n"
                 f"  tsu_fpga_harness #({p}) u_h (.*);\nendmodule\n`default_nettype wire\n")
    return w


def reads(extra=()):
    inc, files = flist(extra)
    return "read_verilog -defer -sv -DSYNTHESIS " + " ".join(f"-I{i}" for i in inc) + " " + " ".join(str(f) for f in files)


def yosys(d: Path, name: str, script: str, timeout=10800):
    (d / f"{name}.ys").write_text(script.replace("; ", ";\n") + "\n")
    rc, out = run(["yosys", "-l", str(d / f"{name}.log"), "-s", str(d / f"{name}.ys")], timeout=timeout)
    (d / f"{name}.stdout").write_text(out[-20000:])
    return rc


def parse_stat(log: str) -> dict:
    i = log.rfind("Printing statistics")
    s = log[i:]
    cells = {m[1]: int(m[2]) for m in re.finditer(r"^\s+(\$?[\w$]+)\s+(\d+)$", s, re.M)}
    tot = re.search(r"Number of cells:\s+(\d+)", s)
    area = re.search(r"Chip area for (?:top )?module '\\?\w+':\s+([\d.]+)", s)
    return dict(total=int(tot[1]) if tot else None, cells=cells, area=float(area[1]) if area else None)


def job_generic(cfg):
    d = BUILD / "synth" / f"generic_{cfg}"
    d.mkdir(parents=True, exist_ok=True)
    w = wrapper(d, CONFIGS[cfg])
    rc = yosys(d, "synth", f"{reads([w])}; hierarchy -check -top cfg_top; proc; flatten; opt_clean; check -assert; "
                           f"synth -top cfg_top -flatten; select -assert-none t:$dlatch t:$_DLATCH_* t:$_DLATCH*_; "
                           f"check -assert; stat")
    st = parse_stat((d / "synth.log").read_text())
    return dict(ok=rc == 0, kind="generic", cfg=cfg, **st)


def job_map(cfg, family):
    d = BUILD / "synth" / f"{family}_{cfg}"
    d.mkdir(parents=True, exist_ok=True)
    w = wrapper(d, dict(CONFIGS[cfg], MEM_BACKEND=1))
    if family == "ecp5":
        flow = "synth_ecp5 -top cfg_top; select -assert-none t:$dlatch t:$_DLATCH*"
    else:
        flow = "synth_xilinx -family xc7 -flatten -top cfg_top; select -assert-none t:LDCE t:LDPE"
    rc = yosys(d, "synth", f"{reads([w])}; hierarchy -check -top cfg_top; {flow}; check -assert; stat")
    st = parse_stat((d / "synth.log").read_text())
    return dict(ok=rc == 0, kind=family, cfg=cfg, **st)


def job_pnr(cfg, seed=1):
    d = BUILD / "synth" / f"pnr_{cfg}"
    d.mkdir(parents=True, exist_ok=True)
    params = {k: v for k, v in CONFIGS[cfg].items()}
    w = harness_top(d, params)
    rc = yosys(d, "synth", f"{reads([ROOT / 'fpga/tsu_fpga_harness.sv', w])}; hierarchy -check -top fpga_top; "
                           f"synth_ecp5 -top fpga_top -json {d / 'ecp5.json'}; stat")
    st = parse_stat((d / "synth.log").read_text())
    res = dict(kind="pnr", cfg=cfg, synth_ok=rc == 0, **st)
    if rc != 0:
        return dict(res, ok=False)
    (d / "ulx3s.lpf").write_text(LPF)
    r = subprocess.run(["nextpnr-ecp5", "--85k", "--package", "CABGA381", "--json", "ecp5.json", "--lpf", "ulx3s.lpf",
                        "--freq", "25", "--seed", str(seed), "--report", "report.json", "--textcfg", "out.config",
                        "--log", "nextpnr.log"], cwd=d, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                       timeout=14400)
    timing_pass = r.returncode == 0
    log = (d / "nextpnr.log").read_text() if (d / "nextpnr.log").exists() else r.stdout
    fmax = [float(m) for m in re.findall(r"Max frequency for clock\s+'[^']+':\s+([\d.]+) MHz", log)]
    util = {m[1]: (int(m[2]), int(m[3])) for m in re.finditer(r"^Info:\s+(\w+):\s+(\d+)/\s*(\d+)", log, re.M)}
    rep = json.loads((d / "report.json").read_text()) if (d / "report.json").exists() else {}
    return dict(res, ok=bool(fmax) and "Routing complete" in log, timing_pass_25mhz=timing_pass, pnr_rc=r.returncode, fmax_mhz=fmax[-1] if fmax else None,
                fmax_all=fmax, utilisation=util, report=rep.get("fmax", {}), routed="Routing complete" in log or
                "Finished routing" in log)


def job_asic(cfg="baseline"):
    d = BUILD / "synth" / f"asic_sky130_{cfg}"
    d.mkdir(parents=True, exist_ok=True)
    lib = BUILD / "pdk" / "sky130_fd_sc_hd__tt_025C_1v80.lib"
    if not lib.exists():
        lib.parent.mkdir(parents=True, exist_ok=True)
        urllib.request.urlretrieve(SKY130_URL, lib)
    sha = hashlib.sha256(lib.read_bytes()).hexdigest()
    w = wrapper(d, CONFIGS[cfg])
    rc = yosys(d, "synth", f"read_liberty -lib {lib}; {reads([w])}; hierarchy -check -top cfg_top; "
                           f"synth -top cfg_top -flatten; dfflibmap -liberty {lib}; abc -liberty {lib} -D 20000; opt_clean; "
                           f"hilomap -hicell sky130_fd_sc_hd__conb_1 HI -locell sky130_fd_sc_hd__conb_1 LO; "
                           f"check -assert; stat -liberty {lib}", timeout=21600)
    log = (d / "synth.log").read_text()
    st = parse_stat(log)
    delays = [float(x) for x in re.findall(r"Delay =\s*([\d.]+) ps", log)]
    generic = [c for c in st["cells"] if c.startswith("$")]
    return dict(ok=rc == 0 and not generic, kind="asic", cfg=cfg, lib_sha256=sha, lib_url=SKY130_URL,
                lib_sha_matches=(sha == SKY130_SHA), abc_delay_ps=delays, unmapped=generic, **st)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    jobs = [("generic_baseline", job_generic, ("baseline",)), ("generic_full", job_generic, ("full",)),
            ("generic_a8full", job_generic, ("a8full",)),
            ("ecp5_baseline", job_map, ("baseline", "ecp5")), ("ecp5_full", job_map, ("full", "ecp5")),
            ("xc7_baseline", job_map, ("baseline", "xc7")), ("xc7_full", job_map, ("full", "xc7")),
            ("pnr_baseline", job_pnr, ("baseline",)), ("pnr_full", job_pnr, ("full",)),
            ("asic_sky130_baseline", job_asic, ("baseline",))]
    if a.only:
        jobs = [j for j in jobs if j[0] in a.only.split(",")]
    out_path = REPORTS / "synth.json"
    out = json.loads(out_path.read_text()) if out_path.exists() and a.only else {}
    out["tools"] = tool_versions()

    def one(j):
        name, fn, args = j
        try:
            r = fn(*args)
        except Exception as e:  # noqa: BLE001
            r = dict(ok=False, error=str(e)[-1500:])
        print(f"{name}: {'OK' if r.get('ok') else 'FAIL'}", flush=True)
        return name, r

    with ThreadPoolExecutor(a.jobs) as ex:
        for name, r in ex.map(one, jobs):
            out[name] = r
    write_json(out_path, out)


if __name__ == "__main__":
    main()
