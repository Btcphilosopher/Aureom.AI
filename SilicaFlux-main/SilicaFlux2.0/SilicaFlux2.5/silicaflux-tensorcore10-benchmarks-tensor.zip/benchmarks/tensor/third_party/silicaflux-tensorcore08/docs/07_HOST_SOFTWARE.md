# 07 — Host software

`sw/tsu_driver.c` + `sw/include/tsu_driver.h`: a bare-metal C driver in the style of the DataFabric DMA and HPC
Module 06 / 08 drivers (no libc beyond `<stdint.h>`, return 0 / hardware code > 0 / driver error < 0).

**There is no PCIe driver, no OS driver and no hardware run.** Register access goes through `TSU_WR32` /
`TSU_RD32`:

| Backend | Build | What it is |
|---|---|---|
| MMIO (default) | any bare-metal toolchain, `TSU_BASE` = the register page | volatile 32-bit loads / stores. **Not exercised on hardware** — no board or SoC containing the unit exists |
| **Simulation backend** | `-DTSU_COSIM`, `scripts/run_cosim.py` | `cosim/cosim_main.cpp` turns every access into one register-bus strobe cycle on the Verilated RTL of `silicaflux_tensor_unit`; device memory is a C++ SFB2 slave model (writes performed when answered) |

## 1. API

```c
int  tsu_init(tsu_dev_t *dev);                                     /* ID / ABI check, capabilities, stop mode */
int  tensor_gemm(tsu_dev_t *dev, uint32_t A, uint32_t B, uint32_t C,
                 uint32_t M, uint32_t N, uint32_t K, const tsu_opts_t *opts, tsu_record_t *rec);
```

`tensor_gemm` is the brief's one-call API and performs exactly its steps:

| Step | Implementation |
|---|---|
| validate parameters | `tsu_check()`: the hardware's 15 rules in the same order, using CAPS / MEM_LO / MEM_LAST / KMAX read by `tsu_init`; a predicted rejection returns `TSU_EINVAL` without submitting (unless `opts->skip_host_check`) |
| prepare the command | `tsu_build_gemm()`: the 12-word descriptor (strides default to dense K, N, size·N) |
| submit | `tsu_submit()`: never rings a full queue (`STATUS.Q_FREE`), retries a refused doorbell |
| wait for completion | `tsu_wait()`: polls `STATUS.CPL_VALID`; returns `TSU_EHALTED` / `TSU_ETIMEDOUT` |
| read status | `tsu_poll()`: CPL0..5, CPL_POP, decoded `tsu_record_t` |
| check errors | TID and SEQ must match the submission (`TSU_EPROTO` otherwise); STATUS ≠ OK returns ERR_CODE |

Options (`tsu_opts_t`): strides, KC, INT8 output (rounding mode, ReLU, multiplier, shift, zero-point), PREFETCH,
NMAJOR, IRQ. Lower-level calls (`tsu_build_nop`, `tsu_submit` without waiting, `tsu_abort`, `tsu_clear_error`,
`tsu_set_continue_on_error`, `tsu_counter`) support back-to-back submission and error handling.
Device memory: A, B, C are **device byte addresses**; the host writes A / B with ordinary stores and reads C after
the record (`sw/include/tsu_host.h`; on the simulation backend these touch the memory model).

## 2. Example on the RTL (`sw/examples/gemm_demo.c`, `reports/cosim_full.log`)

Built twice — the baseline (4×4, INT32, sequential) and the full configuration (quantisation, double buffering) — and
run against the RTL by `scripts/run_cosim.py`. Every C element is compared with a plain C reference (exact INT32, and
the integer requantisation contract for INT8). Output of the full configuration:

```
SilicaFlux tensor unit: INFO 07040422 (array 4x4, TILE_K 64, quantisation 1, double buffering 1), window 10000000..100fffff, K_MAX 131071, init rc 0
tensor_gemm, checked element by element against the C reference:
  4x4 baseline                       M=4   N=4   K=4    INT32  rc=0 (NONE) tiles=1 bytes=64 cycles=147 sat=0  PASS
  8x8 (4 output tiles)               M=8   N=8   K=8    INT32  rc=0 (NONE) tiles=4 bytes=256 cycles=590 sat=0  PASS
  17x13x29, padded strides           M=17  N=13  K=29   INT32  rc=0 (NONE) tiles=20 bytes=884 cycles=3943 sat=0  PASS
  32x32x256 (4 K chunks)             M=32  N=32  K=256  INT32  rc=0 (NONE) tiles=64 bytes=4096 cycles=64602 sat=0  PASS
  32x32x256, PREFETCH                M=32  N=32  K=256  INT32  rc=0 (NONE) tiles=64 bytes=4096 cycles=57498 sat=0  PASS
  INT8 requantised, RNE              M=9   N=11  K=40   INT8   rc=0 (NONE) tiles=9 bytes=99 cycles=1989 sat=0  PASS
  INT8 RTZ + ReLU, negative M        M=6   N=5   K=70   INT8   rc=0 (NONE) tiles=4 bytes=30 cycles=1406 sat=1  PASS
  INT8 saturating                    M=4   N=4   K=64   INT8   rc=0 (NONE) tiles=1 bytes=16 cycles=370 sat=1  PASS
error handling:
  M = 0, host check                 -> -1 (EINVAL (host check)), nothing submitted
  M = 0, submitted anyway            -> 8 (DIM_ZERO) status 1
  next GEMM, stop-on-error           -> 64 (PRIOR) status 2 (SKIPPED, nothing executed)
  after ERR_CLEAR                    M=4   N=4   K=4    INT32  rc=0 (NONE) tiles=1 bytes=64 cycles=147 sat=0  PASS
  B outside the memory window        -> -1 (EINVAL (host check)), host check
back-to-back submission (no waiting), records in order:
  queued command 1                   M=5   N=7   K=33   INT32  rc=0 (NONE) tiles=4 bytes=140 cycles=812 sat=0  PASS
  ...
DEMO PASS (0 failures)
```

(The co-simulation memory answers after 2 cycles, so PREFETCH gains less here than with the 1-cycle memory of
`reports/perf.md`.)
