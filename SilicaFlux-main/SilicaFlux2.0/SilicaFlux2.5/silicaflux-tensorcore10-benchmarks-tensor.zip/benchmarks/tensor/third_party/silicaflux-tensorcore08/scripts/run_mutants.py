#!/usr/bin/env python3
"""Mutation testing of the TENSORCORE 08 RTL: can the regression detect real design bugs?

Each mutant is one deliberate, plausible bug in the NEW RTL (rtl/tsu_*.sv), applied as an exact textual
substitution that must match once.  The mutated unit is rebuilt and a fixed subset of the regression is run; the
mutant is KILLED if any run fails (wrong record, wrong memory byte, counter mismatch, protocol violation, testbench
watchdog).  Survivors are listed and must be analysed in docs/08.
"""
from __future__ import annotations

import json
import shutil
import sys
import zlib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, CPUS, REPORTS, ROOT, TB_FILES, run, tb_params, write_json  # noqa: E402

import check  # noqa: E402
from gen_tests import CFG, MEMS, TESTS  # noqa: E402

S, V, G, R, P, D = ("rtl/tsu_sched.sv", "rtl/tsu_validate.sv", "rtl/tsu_bus_gate.sv", "rtl/tsu_regs.sv",
                    "rtl/tsu_q8_pack.sv", "rtl/tsu_datapath.sv")
BASIC = [("shapes", "base", "lat1"), ("b2b", "base", "rand"), ("dma_errors", "base", "lat1"),
         ("invalid", "base", "lat1"), ("abort", "base", "rand"), ("stop_continue", "base", "lat1")]
QUANT = [("quant", "quant", "lat1"), ("quant_mixed", "quant", "lat1")]

MUTANTS = [
    # ------------------------------------------------------------ scheduler
    ("S01 complete before every STORE is acknowledged", S,
     "wire run_complete = d_done && j_done && (n_cpl == n_desc) && !c_valid", "wire run_complete = d_done && j_done && !c_valid", BASIC),
    ("S02 INT32 STORE row length eff_n bytes", S,
     "dd[`TDMA_D_ROWLEN]  = r_int8 ? 16'(d_en) : 16'({d_en, 2'b00});", "dd[`TDMA_D_ROWLEN]  = 16'(d_en);", BASIC),
    ("S03 LOAD_B without SEAL", S, "        dd[`TDMA_D_FLAGS]   = 6'(1 << `TDMA_F_SEAL);\n      end\n      default:",
     "        dd[`TDMA_D_FLAGS]   = 6'd0;\n      end\n      default:", BASIC),
    ("S04 B pointer not advanced per K chunk", S, "if (!d_lastk) kofs_b <= kofs_b + r_kcldb;", "if (!d_lastk) kofs_b <= kofs_b;", BASIC),
    ("S05 C column step 4 bytes", S,
     "if (17'(d_n0) + 17'(TILE_N) < 17'(f_n)) begin b_col <= b_col + 32'(TILE_N); c_col <= c_col + r_tn_esz; end",
     "if (17'(d_n0) + 17'(TILE_N) < 17'(f_n)) begin b_col <= b_col + 32'(TILE_N); c_col <= c_col + 32'd4; end", BASIC),
    ("S06 read error reported as write error", S, "`TDMA_C_RD_BUS:                  ex_code = `TSU_E_DMA_READ;",
     "`TDMA_C_RD_BUS:                  ex_code = `TSU_E_DMA_WRITE;", BASIC),
    ("S07 abort does not flush the queue", S, "          else if (abort_pend) st <= S_FLUSH;\n",
     "          else if (abort_pend) begin st <= S_IDLE; abort_pend <= 1'b0; end\n", BASIC),
    ("S08 ERROR does not set the sticky error", S, "if (r_status == `TSU_ST_ERROR) err_sticky <= 1'b1;",
     "if (1'b0) err_sticky <= 1'b1;", BASIC),
    ("S09 SEQ not incremented", S, "if (rec_hs) seq <= seq + 32'd1;", "if (rec_hs) seq <= seq;", BASIC),
    ("S10 TC05 context not advanced per tile", S, "slot_pred <= (NUM_SLOTS > 1) ? slot_pred + SLOT_W'(1) : slot_pred;",
     "slot_pred <= slot_pred;", QUANT),
    ("S11 COUNT not accumulated", S, "            if (c_kind == `TDMA_K_STORE) begin\n              bytes_ok <= bytes_ok + c_bytes;",
     "            if (c_kind == `TDMA_K_STORE) begin\n              bytes_ok <= bytes_ok;", BASIC),
    ("S12 watchdog never fires", S, "else if (wd != WD_LIM) wd <= wd + 32'd1;", "else if (wd != WD_LIM) wd <= wd;",
     [("watchdog", "wd", "lat1")]),
    ("S13 no bus quiesce before the soft reset", S,
     "if (g_quiesced) begin st <= S_SRST; srst_cnt <= 5'(SRST_CYCLES + 2); end",
     "if (1'b1) begin st <= S_SRST; srst_cnt <= 5'(SRST_CYCLES + 2); end",
     [("abort", "base", "rand"), ("dma_errors", "base", "rand"), ("abort", "base", "lat1")]),
    ("S14 N-major C row step missing", S,
     "if (17'(d_m0) + 17'(TILE_M) < 17'(f_m)) begin a_row <= a_row + r_tm_lda; c_row <= c_row + r_tm_ldc; end",
     "if (17'(d_m0) + 17'(TILE_M) < 17'(f_m)) begin a_row <= a_row + r_tm_lda; end", [("shapes_nmajor", "base", "lat1")]),
    # ------------------------------------------------------------ validation
    ("V01 ALIAS rule removed", V, "(64'(c_base) <= bl && 64'(b_base) <= cl))                           c_code = `TSU_E_ALIAS;",
     "(64'(c_base) <= bl && 64'(b_base) <= cl) && 1'b0)                    c_code = `TSU_E_ALIAS;", [("invalid", "base", "lat1")]),
    ("V02 LDC compared with N, not 4N", V, "34'(ldc) < esz_n)", "34'(ldc) < 34'(n))", [("invalid", "base", "lat1")]),
    ("V03 window end off by one", V, "(hi >= 64'(MEM_HI))", "(hi > 64'(MEM_HI))", [("invalid", "base", "lat1")]),
    ("V04 chunk-count limit removed", V, "quo > 18'd65535)", "1'b0)", [("invalid", "base", "lat1")]),
    ("V05 C overflow not checked", V, "|| cl[63:32] != 32'd0)", ")", [("invalid", "base", "lat1")]),
    # ------------------------------------------------------------ bus gate
    ("G01 gate never blocks", G, "assign pass = !q_q || held_q;", "assign pass = 1'b1;",
     [("abort", "base", "rand"), ("dma_errors", "base", "rand"), ("abort", "base", "lat1")]),
    ("G02 quiesced ignores outstanding responses", G,
     "quiesced <= q_req && q_q && !(d_req_valid && !d_req_ready) &&",
     "quiesced <= q_req && q_q; if (1'b0) quiesced <= !(d_req_valid && !d_req_ready) &&",
     [("abort", "base", "rand"), ("dma_errors", "base", "rand"), ("abort", "base", "lat1")]),
    # ------------------------------------------------------------ register page
    ("R01 DOORBELL ignores a full queue", R, "assign cq_in_valid = wr && a_doorbell && cq_in_ready;",
     "assign cq_in_valid = wr && a_doorbell;", [("b2b", "base", "rand")]),
    ("R02 INT_STATUS never set", R, "| int_set;   // set wins", ";", [("irq", "base", "lat1")]),
    # ------------------------------------------------------------ INT8 packing / datapath
    ("P01 INT8 bytes swapped inside a lane", P, "data[32*l + 8*b +: 8] = q8[8*(4*l + b) +: 8];",
     "data[32*l + 8*(3-b) +: 8] = q8[8*(4*l + b) +: 8];", QUANT),
    ("D01 INT8 commands use the INT32 path", D, ".cfg_dest(cfg_int8 ? 3'b010 : 3'b001)", ".cfg_dest(3'b001)", QUANT),
    ("D02 saturation never reported", D,
     "sat_inc = sat_inc + {{(SATW-1){1'b0}}, q_out_sat[j] & q_out_cm[j]};", "sat_inc = sat_inc;", QUANT),
]


def build_mutant(mid: str, path: str, old: str, new: str, cfg: str) -> Path | None:
    out = BUILD / "mutants" / mid / cfg
    exe = out / "Vtb_tsu"
    if exe.exists():
        return exe
    out.mkdir(parents=True, exist_ok=True)
    src = (ROOT / path).read_text()
    assert src.count(old) == 1, (mid, old, src.count(old))
    mfile = out / Path(path).name
    mfile.write_text(src.replace(old, new))
    fl = out / "files.f"
    fl.write_text((ROOT / "rtl/files.f").read_text().replace(path + "\n", str(mfile) + "\n"))
    par = tb_params(CFG[cfg], 0)
    cmd = ["verilator", "--binary", "--timing", "-O1", "-j", "2", "--top-module", "tb_tsu", "-Mdir", str(out),
           "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-INITIALDLY", "-Wno-MULTIDRIVEN",
           "-Wno-SYNCASYNCNET", "-Wno-BLKANDNBLK", "-Wno-UNOPTFLAT", "-Wno-CASEINCOMPLETE", "-Wno-WIDTH",
           "+define+TOB_ASSERT", "+define+SRAMLIB_ASSERT"] + [f"-G{k}={v}" for k, v in par.items()] + \
          ["-f", str(fl)] + TB_FILES
    rc, txt = run(cmd, log=out / "build.log", timeout=1800)
    return exe if rc == 0 and exe.exists() else None


def run_mutant(m):
    name, path, old, new, tests = m
    mid = name.split()[0]
    detail = []
    killed = False
    for tname, cfg, mem in tests:
        exe = build_mutant(mid, path, old, new, cfg)
        if exe is None:
            return dict(id=mid, name=name, status="BUILD_FAIL", detail=["mutant does not compile"])
        fn = TESTS[tname][0]
        prog, plus = fn(cfg, 1000 + zlib.crc32(tname.encode()) % 997)
        plus = dict(MEMS[mem], **plus, maxcyc=3_000_000, seed=1)
        d = BUILD / "mutants" / mid / f"{tname}__{cfg}__{mem}"
        if d.exists():
            shutil.rmtree(d)
        prog.write(d)
        try:
            run([str(exe), f"+dir={d}"] + [f"+{k}={v}" for k, v in plus.items()], cwd=d, timeout=900, log=d / "sim.log")
            res = check.check(d)
        except Exception as e:  # noqa: BLE001  (a hung or crashed simulation is a detection)
            res = dict(ok=False, fails=[f"simulation did not complete: {type(e).__name__}"])
        if prog.plus.get("irq_min_edges") and res.get("perf", {}).get("irq_edges", 0) < prog.plus["irq_min_edges"]:
            res["ok"] = False
            res["fails"].append("no interrupt edge observed")
        if not res["ok"]:
            killed = True
            detail.append(f"{tname}/{cfg}/{mem}: " + (res["fails"][0] if res["fails"] else "fail")[:200])
            break
        detail.append(f"{tname}/{cfg}/{mem}: passed")
    return dict(id=mid, name=name, status="KILLED" if killed else "SURVIVED", detail=detail)


def main():
    with ThreadPoolExecutor(max(1, CPUS - 1)) as ex:
        res = list(ex.map(run_mutant, MUTANTS))
    k = sum(r["status"] == "KILLED" for r in res)
    for r in res:
        print(f"{r['status']:<9} {r['name']}  [{r['detail'][-1] if r['detail'] else ''}]")
    print(f"mutation: {k}/{len(res)} killed")
    write_json(REPORTS / "mutation.json", dict(killed=k, total=len(res), mutants=res))


if __name__ == "__main__":
    main()
