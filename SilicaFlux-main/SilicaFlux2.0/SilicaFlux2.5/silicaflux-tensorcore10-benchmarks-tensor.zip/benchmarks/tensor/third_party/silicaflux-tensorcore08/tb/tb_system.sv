// =============================================================================
// SilicaFlux TENSORCORE 08 :: tb_system
// Coexistence test: integration/sfx_hpc_tensor_system = HPC Module 08 compute tile (FP32 vector array) +
// silicaflux_tensor_unit (INT8 GEMM) + host CPU port on the real DataFabric crossbar, sharing one SRAM.
//
// Program (model/gen_system.py), one token per line:
//   C w0..w11   submit a tensor GEMM (page 9)       H w0..w7   submit an HPC tile command (page 8)
//   S nt nh     wait for nt tensor and nh tile records          Q   wait until both units are idle
// The host CPU port (master 0) issues random reads / writes into a private window at +cpu_rate% (shadow-
// checked).  Every master port carries an SFB2 protocol checker.  Outputs: records.txt (tensor, R lines),
// tile_records.txt, mem_final.hex, stats.txt.
// =============================================================================
`timescale 1ns/1ps
`include "tsu_defs.svh"
module tb_system;
  parameter int MEM_BASE = 32'h1000_0000, MEM_BYTES = 1 << 20;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int errors = 0;
  `define ERR(args) begin errors = errors + 1; if (errors <= 40) begin $write("ERROR cyc=%0d: ", cyc); $display args ; end end
  int unsigned rs [0:7];
  function automatic int unsigned rnd(input int s);
    int unsigned x;
    x = rs[s]; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rs[s] = x; return x;
  endfunction
  function automatic bit pct(input int s, input int p);
    int unsigned r;
    if (p <= 0) return 1'b0;
    r = rnd(s);
    return (r % 100) < p;
  endfunction

  // ------------------------------------------------------------ DUT
  logic        rb_sel = 1'b0, rb_we = 1'b0, rb_err;
  logic [15:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0, rb_rdata;
  logic        h_req_valid = 1'b0, h_req_ready, h_req_write = 1'b0, h_rsp_valid, h_rsp_error;
  logic [31:0] h_req_addr = '0, h_req_wdata = '0, h_rsp_rdata;
  logic [3:0]  h_req_wstrb = 4'hF;
  logic        s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [31:0] s_req_addr, s_req_wdata, s_rsp_rdata;
  logic [3:0]  s_req_wstrb;
  logic        tile_irq, tsu_irq, tile_busy, tsu_busy, tsu_halted;
  logic [2:0]  mon_stall, mon_acc, mon_loss;

  sfx_hpc_tensor_system #(.SRAM_BASE(MEM_BASE), .SRAM_BYTES(MEM_BYTES)) dut (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(rb_rdata), .rb_err(rb_err),
    .h_req_valid(h_req_valid), .h_req_ready(h_req_ready), .h_req_write(h_req_write), .h_req_addr(h_req_addr),
    .h_req_wdata(h_req_wdata), .h_req_wstrb(h_req_wstrb), .h_rsp_valid(h_rsp_valid), .h_rsp_ready(1'b1),
    .h_rsp_rdata(h_rsp_rdata), .h_rsp_error(h_rsp_error),
    .s_req_valid(s_req_valid), .s_req_ready(s_req_ready), .s_req_write(s_req_write), .s_req_addr(s_req_addr),
    .s_req_wdata(s_req_wdata), .s_req_wstrb(s_req_wstrb), .s_rsp_valid(s_rsp_valid), .s_rsp_ready(s_rsp_ready),
    .s_rsp_rdata(s_rsp_rdata), .s_rsp_error(s_rsp_error),
    .tile_irq(tile_irq), .tsu_irq(tsu_irq), .tile_busy(tile_busy), .tsu_busy(tsu_busy), .tsu_halted(tsu_halted),
    .mon_req_stall(mon_stall), .mon_req_accept(mon_acc), .mon_arb_loss(mon_loss));

  // protocol checkers on every master port of the fabric
  logic [31:0] v0, v1, v2, nq [0:8];
  sfb_protocol_checker #(.MAX_OUT(1), .NAME("host")) u_c0 (.clk(clk), .rst_n(rst_n),
    .req_valid(h_req_valid), .req_ready(h_req_ready), .req_write(h_req_write), .req_addr(h_req_addr),
    .req_wdata(h_req_wdata), .req_wstrb(h_req_wstrb), .rsp_valid(h_rsp_valid), .rsp_ready(1'b1),
    .rsp_rdata(h_rsp_rdata), .rsp_error(h_rsp_error), .violations(v0), .n_req(nq[0]), .n_rsp(nq[1]), .outstanding(nq[2]));
  sfb_protocol_checker #(.MAX_OUT(1), .NAME("tile_dma")) u_c1 (.clk(clk), .rst_n(rst_n),
    .req_valid(dut.m_req_valid[1]), .req_ready(dut.m_req_ready[1]), .req_write(dut.m_req_write[1]),
    .req_addr(dut.m_req_addr[63:32]), .req_wdata(dut.m_req_wdata[63:32]), .req_wstrb(dut.m_req_wstrb[7:4]),
    .rsp_valid(dut.m_rsp_valid[1]), .rsp_ready(dut.m_rsp_ready[1]), .rsp_rdata(dut.m_rsp_rdata[63:32]),
    .rsp_error(dut.m_rsp_error[1]), .violations(v1), .n_req(nq[3]), .n_rsp(nq[4]), .outstanding(nq[5]));
  sfb_protocol_checker #(.MAX_OUT(1), .NAME("tensor_dma")) u_c2 (.clk(clk), .rst_n(rst_n),
    .req_valid(dut.m_req_valid[2]), .req_ready(dut.m_req_ready[2]), .req_write(dut.m_req_write[2]),
    .req_addr(dut.m_req_addr[95:64]), .req_wdata(dut.m_req_wdata[95:64]), .req_wstrb(dut.m_req_wstrb[11:8]),
    .rsp_valid(dut.m_rsp_valid[2]), .rsp_ready(dut.m_rsp_ready[2]), .rsp_rdata(dut.m_rsp_rdata[95:64]),
    .rsp_error(dut.m_rsp_error[2]), .violations(v2), .n_req(nq[6]), .n_rsp(nq[7]), .outstanding(nq[8]));

  // ------------------------------------------------------------ shared SRAM model (write performed at response, R7)
  logic [7:0] mem [0:MEM_BYTES-1];
  int lat = 1;
  localparam int QN = 16;
  logic q_w [0:QN-1]; logic [31:0] q_a [0:QN-1], q_d [0:QN-1]; logic [3:0] q_s [0:QN-1]; longint q_t [0:QN-1];
  int q_head = 0, q_tail = 0;
  logic rsp_v_q = 1'b0, rsp_e_q = 1'b0; logic [31:0] rsp_d_q = '0;
  assign s_rsp_valid = rsp_v_q; assign s_rsp_error = rsp_e_q; assign s_rsp_rdata = rsp_d_q;
  assign s_req_ready = rst_n && (q_tail - q_head < QN - 2);
  always @(posedge clk) begin
    if (!rst_n) begin
      q_head = 0; q_tail = 0; rsp_v_q <= 1'b0;
    end else begin
      bit can;
      can = (!rsp_v_q || s_rsp_ready) && q_head != q_tail && cyc >= q_t[q_head % QN];
      if (can) begin
        int h; logic [31:0] o;
        h = q_head % QN; q_head = q_head + 1; o = q_a[h] - MEM_BASE;
        rsp_v_q <= 1'b1; rsp_e_q <= 1'b0;
        if (q_w[h]) begin
          rsp_d_q <= '0;
          for (int b = 0; b < 4; b++) if (q_s[h][b]) mem[o + b] = q_d[h][8*b +: 8];
        end else rsp_d_q <= {mem[o+3], mem[o+2], mem[o+1], mem[o]};
      end else if (rsp_v_q && s_rsp_ready) rsp_v_q <= 1'b0;
      if (s_req_valid && s_req_ready) begin
        int t; t = q_tail % QN;
        q_w[t] = s_req_write; q_a[t] = s_req_addr; q_d[t] = s_req_wdata; q_s[t] = s_req_wstrb; q_t[t] = cyc + lat;
        q_tail = q_tail + 1;
      end
    end
  end

  // ------------------------------------------------------------ host CPU traffic (master 0), shadow-checked
  int          cpu_rate = 0;
  logic [31:0] cpu_lo = '0;
  localparam int CW = 512;
  logic [31:0] c_sh [0:CW-1];
  bit          c_sv [0:CW-1];
  initial for (int i = 0; i < CW; i++) c_sv[i] = 1'b0;
  logic        c_pend = 1'b0, c_pw = 1'b0, c_go;
  logic [31:0] c_pa = '0;
  longint      n_cpu = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      h_req_valid <= 1'b0; c_pend <= 1'b0;
    end else begin
      if (h_req_valid && h_req_ready) begin
        h_req_valid <= 1'b0; c_pend <= 1'b1; c_pw <= h_req_write; c_pa <= h_req_addr;
        if (h_req_write) begin c_sh[(h_req_addr - cpu_lo) >> 2] = h_req_wdata; c_sv[(h_req_addr - cpu_lo) >> 2] = 1'b1; end
      end
      if (h_rsp_valid) begin
        c_pend <= 1'b0; n_cpu = n_cpu + 1;
        if (h_rsp_error) `ERR(("host CPU: error response at %h", c_pa))
        if (!c_pw && c_sv[(c_pa - cpu_lo) >> 2] && h_rsp_rdata != c_sh[(c_pa - cpu_lo) >> 2])
          `ERR(("host CPU: read %h at %h, expected %h", h_rsp_rdata, c_pa, c_sh[(c_pa - cpu_lo) >> 2]))
      end
      c_go = 1'b0;
      if (!h_req_valid && !c_pend && !h_rsp_valid && cpu_lo != 0) c_go = pct(4, cpu_rate);
      if (c_go) begin
        h_req_valid <= 1'b1; h_req_addr <= cpu_lo + ((rnd(5) % CW) << 2);
        h_req_write <= ((rnd(6) & 32'd1) != 32'd0); h_req_wdata <= rnd(7); h_req_wstrb <= 4'hF;
      end
    end
  end

  // arbitration statistics
  longint stall [0:2], loss [0:2], accn [0:2];
  initial for (int i = 0; i < 3; i++) begin stall[i] = 0; loss[i] = 0; accn[i] = 0; end
  always @(posedge clk) if (rst_n) for (int i = 0; i < 3; i++) begin
    stall[i] = stall[i] + mon_stall[i]; loss[i] = loss[i] + mon_loss[i]; accn[i] = accn[i] + mon_acc[i];
  end
  longint both_active = 0;
  always @(posedge clk) if (rst_n && dut.u_tile.busy && dut.u_tsu.u_sched.busy) both_active = both_active + 1;

  // ------------------------------------------------------------ host register BFM
  task automatic rb(input bit we, input logic [15:0] a, input logic [31:0] d, output logic [31:0] q, output bit e);
    @(negedge clk);
    rb_sel = 1'b1; rb_we = we; rb_addr = a; rb_wdata = d;
    #1; q = rb_rdata; e = rb_err;
    @(posedge clk); #1;
    rb_sel = 1'b0; rb_we = 1'b0;
  endtask
  task automatic wr32(input logic [15:0] a, input logic [31:0] d);
    logic [31:0] q; bit e;
    rb(1'b1, a, d, q, e);
    if (e) `ERR(("register write %h refused", a))
  endtask
  task automatic rd32(input logic [15:0] a, output logic [31:0] q);
    bit e;
    rb(1'b0, a, 32'd0, q, e);
    if (e) `ERR(("register read %h refused", a))
  endtask
  localparam logic [15:0] PT = 16'h9000, PH = 16'h8000;

  int fd_t, fd_h, n_t = 0, n_h = 0, s_t = 0, s_h = 0;
  task automatic collect();
    logic [31:0] st, r0, r1, r2, r3, r4, r5; bit e;
    rd32(PT + `TSU_R_STATUS, st);
    while (st[`TSU_SB_CPL_VALID]) begin
      rd32(PT + `TSU_R_CPL0, r0); rd32(PT + `TSU_R_CPL0 + 16'd4, r1); rd32(PT + `TSU_R_CPL0 + 16'd8, r2);
      rd32(PT + `TSU_R_CPL0 + 16'd12, r3); rd32(PT + `TSU_R_CPL0 + 16'd16, r4); rd32(PT + `TSU_R_CPL0 + 16'd20, r5);
      rb(1'b1, PT + `TSU_R_CPL_POP, 32'd1, st, e);
      $fdisplay(fd_t, "R %h %h %h %h %h %h", r0, r1, r2, r3, r4, r5);
      n_t = n_t + 1;
      rd32(PT + `TSU_R_STATUS, st);
    end
    rd32(PH + 16'h028, st);                                    // tile STATUS[5] CPL_VALID
    while (st[5]) begin
      rd32(PH + 16'h040, r0); rd32(PH + 16'h044, r1); rd32(PH + 16'h048, r2); rd32(PH + 16'h04C, r3);
      rd32(PH + 16'h050, r4); rd32(PH + 16'h054, r5);
      wr32(PH + 16'h058, 32'd1);
      $fdisplay(fd_h, "H %h %h %h %h %h %h", r0, r1, r2, r3, r4, r5);
      n_h = n_h + 1;
      rd32(PH + 16'h028, st);
    end
  endtask

  string dir;
  logic [63:0] op;
  logic [31:0] tok;
  int fd, rc, rt, maxcyc = 30_000_000;
  initial begin
    int s, v, v2;
    logic [31:0] q; bit e;
    if (!$value$plusargs("dir=%s", dir)) dir = ".";
    if (!$value$plusargs("seed=%d", s)) s = 1;
    for (int i = 0; i < 8; i++) rs[i] = 32'h9E37_79B9 * (s + i * 7919) + 32'h1234_5 + i;
    void'($value$plusargs("lat=%d", lat)); void'($value$plusargs("cpu_rate=%d", cpu_rate));
    if ($value$plusargs("cpu_lo=%h", v)) cpu_lo = v;
    $readmemh({dir, "/mem_init.hex"}, mem);
    fd_t = $fopen({dir, "/records.txt"}, "w");
    fd_h = $fopen({dir, "/tile_records.txt"}, "w");
    fd = $fopen({dir, "/prog.txt"}, "r");
    repeat (4) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
    repeat (4) @(posedge clk);
    rd32(PT + `TSU_R_ID, q); if (q != `TSU_ID_VALUE) `ERR(("tensor ID %h", q))
    rd32(PH + 16'h000, q);   if (q != 32'h5346_4854) `ERR(("tile ID %h", q))
    rb(1'b0, 16'h3000, 32'd0, q, e); if (!e) `ERR(("unmapped register page accepted"))
    rt = 1;
    while (!$feof(fd) && rt == 1) begin
      rt = $fscanf(fd, "%s", op);
      if (rt == 1) case (op)
        64'("C"): begin
          logic [31:0] f [0:11];
          for (int i = 0; i < 12; i++) begin rc = $fscanf(fd, "%h", tok); f[i] = tok; end
          for (int i = 0; i < 12; i++) wr32(PT + `TSU_R_DESC0 + 16'(4 * i), f[i]);
          rb(1'b1, PT + `TSU_R_DOORBELL, 32'd1, q, e);
          while (e) begin collect(); rb(1'b1, PT + `TSU_R_DOORBELL, 32'd1, q, e); end
          s_t = s_t + 1;
        end
        64'("H"): begin
          logic [31:0] f [0:7];
          for (int i = 0; i < 8; i++) begin rc = $fscanf(fd, "%h", tok); f[i] = tok; end
          for (int i = 0; i < 8; i++) wr32(PH + 16'h080 + 16'(4 * i), f[i]);
          rb(1'b1, PH + 16'h0A0, 32'd1, q, e);
          while (e) begin collect(); rb(1'b1, PH + 16'h0A0, 32'd1, q, e); end
          s_h = s_h + 1;
        end
        64'("S"): begin rc = $fscanf(fd, "%d %d", v, v2); while (n_t < v || n_h < v2) collect(); end
        64'("Q"): begin
          while (n_t < s_t || n_h < s_h) collect();
          do begin collect(); end while (tsu_busy || tile_busy);
        end
        default: `ERR(("unknown op %h", op))
      endcase
    end
    cpu_rate = 0;
    repeat (20) @(posedge clk);
    $fclose(fd); $fclose(fd_t); $fclose(fd_h);
    $writememh({dir, "/mem_final.hex"}, mem);
    if (v0 != 0 || v1 != 0 || v2 != 0) `ERR(("SFB2 protocol violations host %0d tile %0d tensor %0d", v0, v1, v2))
    begin
      int fp; fp = $fopen({dir, "/stats.txt"}, "w");
      for (int i = 0; i < 3; i++) $fdisplay(fp, "master%0d accepted %0d stall_cycles %0d arb_losses %0d", i, accn[i], stall[i], loss[i]);
      $fdisplay(fp, "both_units_busy_cycles %0d", both_active);
      $fdisplay(fp, "cpu_transactions %0d", n_cpu);
      $fdisplay(fp, "cycles %0d", cyc);
      $fclose(fp);
    end
    $display("TB cycles=%0d tensor_records=%0d tile_records=%0d cpu=%0d both_busy=%0d", cyc, n_t, n_h, n_cpu, both_active);
    $display("RESULT %s", (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
  always @(posedge clk) if (cyc == longint'(maxcyc)) begin
    `ERR(("TB WATCHDOG")) $display("RESULT FAIL"); $finish;
  end
endmodule
