#!/usr/bin/env python3
"""Lint, elaboration and illegal-configuration checks of silicaflux_tensor_unit (and the system wrapper).

  1. Verilator 5.020 --lint-only -Wall on every legal configuration: 0 warnings in TENSORCORE 08 RTL
     (rtl/, integration/, fpga/); warnings inside third_party/ are counted and reported, not hidden.
  2. Icarus 12 elaboration of every legal configuration (iverilog -g2012 + a 0-time vvp run).
  3. Yosys 0.33 elaboration (read + hierarchy -check) of every legal configuration.
  4. Every illegal configuration must be REJECTED BY THE UNIT ITSELF in all three tools, with its own message.
Writes reports/lint.json and prints a summary.
"""
from __future__ import annotations

import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, run, write_json  # noqa: E402

LEGAL = {
    "baseline": {},
    "quant": dict(ENABLE_QUANTIZATION=1),
    "dbuf": dict(ENABLE_DOUBLE_BUFFERING=1),
    "full": dict(ENABLE_QUANTIZATION=1, ENABLE_DOUBLE_BUFFERING=1),
    "a8": dict(ARRAY_ROWS=8, ARRAY_COLS=8, NUM_MEMORY_BANKS=8, OPERAND_BUFFER_BYTES=4096, ENABLE_QUANTIZATION=1,
               ENABLE_DOUBLE_BUFFERING=1),
    "a2": dict(ARRAY_ROWS=2, ARRAY_COLS=2, NUM_MEMORY_BANKS=2, OPERAND_BUFFER_BYTES=512),
    "tk16": dict(TILE_K=16, OPERAND_BUFFER_BYTES=512, K_MAX=4096, CMD_QUEUE_DEPTH=2, CPL_QUEUE_DEPTH=2),
    "mo1_noperf": dict(MAX_OUT=1, PERF_EN=0),
    "fpga_mem": dict(MEM_BACKEND=1, ENABLE_DOUBLE_BUFFERING=1),
    "fault": dict(FAULT_INJ=1, ENABLE_DOUBLE_BUFFERING=1, ENABLE_QUANTIZATION=1),
    "unverified_3x5": dict(ARRAY_ROWS=3, ARRAY_COLS=5, ALLOW_UNVERIFIED=1, NUM_MEMORY_BANKS=4),
}
ILLEGAL = {
    "data_width_16": (dict(DATA_WIDTH=16), "DATA_WIDTH must be 8"),
    "acc_width_40": (dict(ACC_WIDTH=40), "ACC_WIDTH must be 32"),
    "rows_32": (dict(ARRAY_ROWS=32, ALLOW_UNVERIFIED=1), "must be 1..16"),
    "shape_3x3_unverified": (dict(ARRAY_ROWS=3, ARRAY_COLS=3), "not in the verified list"),
    "tile_k_0": (dict(TILE_K=0), "TILE_K must be 1..32767"),
    "tile_k_40000": (dict(TILE_K=40000), "TILE_K must be 1..32767"),
    "opbuf_not_pow2": (dict(OPERAND_BUFFER_BYTES=1000), "power of two"),
    "opbuf_too_small": (dict(OPERAND_BUFFER_BYTES=256), "does not fit in one operand set"),
    "banks_3": (dict(NUM_MEMORY_BANKS=3), "NUM_MEMORY_BANKS must be a power of two"),
    # one row per bank: Yosys reports the top's check; Verilator first reaches the SRAM library's own DEPTH check and
    # Icarus fails compiling TC03's zero-width selects -- rejected by all three, by the messages listed
    "banks_vs_buffer": (dict(NUM_MEMORY_BANKS=16, OPERAND_BUFFER_BYTES=128, TILE_K=8),
                        ">= 2 rows per bank|DEPTH must be >= 2|widths must be constant and greater than zero"),
    "quant_2": (dict(ENABLE_QUANTIZATION=2), "ENABLE_QUANTIZATION must be 0 or 1"),
    "dbuf_2": (dict(ENABLE_DOUBLE_BUFFERING=2), "ENABLE_DOUBLE_BUFFERING must be 0 or 1"),
    "max_out_3": (dict(MAX_OUT=3), "MAX_OUT must be"),
    "cmdq_3": (dict(CMD_QUEUE_DEPTH=3), "must be powers of two"),
    "k_max_big": (dict(K_MAX=200000), "K_MAX must be"),
    "mem_window": (dict(MEM_LO="33'h010000000", MEM_HI="33'h010000000"), "memory window"),
    "backend_asic": (dict(MEM_BACKEND=2), "MEM_BACKEND must be"),
    "wdog_2": (dict(WDOG_LOG2=2), "WDOG_LOG2 must be"),
}
NEW_DIRS = ("rtl/", "integration/", "fpga/")


def flist():
    inc, files = [], []
    for line in (ROOT / "rtl/files.f").read_text().splitlines():
        line = line.strip()
        if line.startswith("+incdir+"):
            inc.append(line[len("+incdir+"):])
        elif line:
            files.append(line)
    return inc, files


def vparams(p):
    return [f"-G{k}={v}" for k, v in p.items()]


def verilator(p, wall=True):
    cmd = ["verilator", "--lint-only", "--top-module", "silicaflux_tensor_unit", "-f", "rtl/files.f"] + vparams(p)
    # legal: warnings reported, never fatal; illegal: only the unit's own $fatal (USERFATAL) may reject
    cmd[1:1] = ["-Wall", "-Wno-fatal"] if wall else ["-Wno-fatal", "-Werror-USERFATAL"]
    return run(cmd, timeout=900)


def icarus(name, p):
    d = BUILD / "lint"
    d.mkdir(parents=True, exist_ok=True)
    vvp = d / f"{name}.vvp"
    cmd = ["iverilog", "-g2012", "-o", str(vvp), "-s", "silicaflux_tensor_unit", "-f", "rtl/files.f"]
    cmd += [f"-Psilicaflux_tensor_unit.{k}={v}" for k, v in p.items()]
    rc, out = run(cmd, timeout=900)
    if rc == 0:
        rc2, out2 = run(["vvp", "-n", str(vvp)], timeout=300)
        return rc2 if "$fatal" in out2 or "FATAL" in out2.upper() else rc, out + out2
    return rc, out


def yosys(name, p):
    d = BUILD / "lint"
    d.mkdir(parents=True, exist_ok=True)
    inc, files = flist()
    files = [f for f in files if "stubs" not in f]
    w = d / f"{name}_top.sv"
    plist = ", ".join(f".{k}({v})" for k, v in p.items())
    w.write_text("module lint_top (input wire logic clk);\n  /* verilator lint_off PINMISSING */\n"
                 f"  silicaflux_tensor_unit #({plist}) u (.clk(clk));\nendmodule\n")
    script = (f"read_verilog -defer -sv -DSYNTHESIS {' '.join('-I' + i for i in inc)} {' '.join(files)} {w}; "
              "hierarchy -check -top lint_top")
    return run(["yosys", "-p", script], timeout=1800)


def new_warnings(out: str):
    return [l for l in out.splitlines() if l.startswith("%Warning") and any(f" {d}" in l or f"{d}" in l.split(":")[0]
                                                                         for d in NEW_DIRS)
            and "third_party" not in l.split(":")[0]]


def main():
    res = dict(legal={}, illegal={}, system={})

    def legal(item):
        name, p = item
        rc, out = verilator(p)
        nw = new_warnings(out)
        tp = [l for l in out.splitlines() if l.startswith("%Warning") and "third_party" in l]
        irc, iout = icarus(name, p)
        yrc, yout = yosys(name, p)
        ok = rc == 0 and not nw and irc == 0 and yrc == 0
        return name, dict(ok=ok, verilator_rc=rc, new_rtl_warnings=nw[:20], third_party_warnings=len(tp),
                          icarus_rc=irc, yosys_rc=yrc, errors=[l for l in (out + iout + yout).splitlines()
                                                               if "rror" in l][:5])

    def illegal(item):
        name, (p, msg) = item
        rc, out = verilator(p, wall=False)
        irc, iout = icarus("bad_" + name, p)
        yrc, yout = yosys("bad_" + name, p)
        # Yosys 0.33 prints "<file>:<line>: ERROR: FATAL: ." without the text: require the line of the check
        msgs = msg.split("|")                         # first: the unit's message; others: a reused module's own check
        src = (ROOT / "rtl/silicaflux_tensor_unit.sv").read_text().splitlines()
        lines = [i + 1 for i, l in enumerate(src) if "SRAM_CFG_FATAL" in l and msgs[0] in l]
        hit = [any(m in out for m in msgs), any(m in iout for m in msgs),
               any(f"silicaflux_tensor_unit.sv:{n}: ERROR: FATAL" in yout for n in lines)]
        return name, dict(ok=rc != 0 and irc != 0 and yrc != 0 and all(hit), verilator=rc != 0, icarus=irc != 0,
                          yosys=yrc != 0, message_seen=hit)

    with ThreadPoolExecutor(4) as ex:
        res["legal"] = dict(ex.map(legal, LEGAL.items()))
        res["illegal"] = dict(ex.map(illegal, ILLEGAL.items()))
    rc, out = run(["verilator", "--lint-only", "-Wall", "-Wno-fatal", "--top-module", "sfx_hpc_tensor_system",
                   "-f", "integration/files_system.f"], timeout=1200)
    res["system"] = dict(ok=rc == 0 and not new_warnings(out), new_rtl_warnings=new_warnings(out)[:20],
                         third_party_warnings=len([l for l in out.splitlines() if l.startswith("%Warning")
                                                   and "third_party" in l]))
    rc, out = run(["python3", "scripts/gen_abi.py", "--check"])
    res["abi_generated_up_to_date"] = rc == 0
    nl = sum(v["ok"] for v in res["legal"].values())
    ni = sum(v["ok"] for v in res["illegal"].values())
    print(f"legal configurations clean in Verilator -Wall / Icarus / Yosys: {nl}/{len(LEGAL)}")
    for k, v in res["legal"].items():
        if not v["ok"]:
            print("  FAIL", k, v)
    print(f"illegal configurations rejected by Verilator, Icarus and Yosys: {ni}/{len(ILLEGAL)} "
          "(all with the unit's own message except banks_vs_buffer, see reports/lint.md)")
    for k, v in res["illegal"].items():
        if not v["ok"]:
            print("  FAIL", k, v)
    print(f"system wrapper Verilator -Wall: {'clean' if res['system']['ok'] else 'WARNINGS'}; "
          f"generated ABI files up to date: {res['abi_generated_up_to_date']}")
    write_json(REPORTS / "lint.json", res)
    sys.exit(0 if nl == len(LEGAL) and ni == len(ILLEGAL) and res["system"]["ok"] else 1)


if __name__ == "__main__":
    main()
