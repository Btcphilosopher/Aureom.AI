#!/usr/bin/env python3
"""TENSORCORE 08 integration regression: tb/tb_tsu.sv on rtl/silicaflux_tensor_unit.sv.

Stages run strictly in order and a failing stage stops the run (the brief: prove the 4x4 INT8 / INT32
baseline before enabling the advanced features):
  1  one command on the baseline (4x4x4, 1x1x1)
  2  the baseline: shapes, K chunks, many tiles, extremes, back-to-back, invalid commands, DMA errors,
     stop / continue, interrupts, hard reset during operation, abort, crossbar contention, watchdog
  3  advanced features, each in its own configuration: double buffering, INT8 quantisation, 8x8 / 2x2 arrays,
     TILE_K = 16, fault injection (ownership violations, accumulator range)
Every run is checked by model/check.py (records, the whole final memory, exact counters).
Usage: run_regress.py [--stages 1,2,3] [--sims verilator,icarus] [--tests a,b] [--jobs N] [--out name] [--keep]
"""
from __future__ import annotations

import argparse
import shutil
import sys
import time
import traceback
import zlib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, CPUS, REPORTS, build, simulate, tool_versions, write_json  # noqa: E402

import check  # noqa: E402
from gen_tests import CFG, MEMS, TESTS  # noqa: E402


def jobs_for(stages, names, sims, seed_scale=1):
    jobs = []
    for name, (fn, stage, cfgs, mems, seeds, xbar) in TESTS.items():
        if stage not in stages or (names and name not in names):
            continue
        for cfg in cfgs:
            for mem in mems:
                for s in range(1, max(1, seeds * seed_scale) + 1):
                    for sim in sims:
                        jobs.append(dict(name=name, stage=stage, cfg=cfg, mem=mem, seed=s, xbar=xbar, sim=sim))
    return jobs


def run_job(j, out_root: Path, keep: bool):
    tid = f"{j['name']}__{j['cfg']}__{j['mem']}__s{j['seed']}__{j['sim']}"
    d = out_root / tid
    t0 = time.time()
    try:
        fn = TESTS[j["name"]][0]
        prog, plus = fn(j["cfg"], j["seed"] * 1000 + zlib.crc32(j["name"].encode()) % 997)
        plus = dict(MEMS[j["mem"]], **plus)
        if d.exists():
            shutil.rmtree(d)
        prog.write(d, meta=dict(j))
        exe = build(CFG[j["cfg"]], j["sim"], j["xbar"])
        plus.setdefault("seed", j["seed"])
        rc = simulate(exe, d, plus, j["sim"])
        res = check.check(d)
        if prog.plus.get("irq_min_edges") and res.get("perf", {}).get("irq_edges", 0) < prog.plus["irq_min_edges"]:
            res["ok"] = False
            res["fails"].append("no interrupt edge observed")
        res.update(rc=rc)
    except Exception as e:  # noqa: BLE001
        res = dict(ok=False, fails=[f"exception: {e}", traceback.format_exc()[-800:]])
    res.update(j, id=tid, secs=round(time.time() - t0, 1))
    if res["ok"] and not keep:
        for f in ("mem_init.hex", "mem_final.hex", "mem_gold.bin", "expect.json"):
            (d / f).unlink(missing_ok=True)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", default="1,2,3")
    ap.add_argument("--sims", default="verilator")
    ap.add_argument("--tests", default="")
    ap.add_argument("--jobs", type=int, default=CPUS)
    ap.add_argument("--out", default="regression")
    ap.add_argument("--keep", action="store_true")
    ap.add_argument("--seed-scale", type=int, default=1)
    a = ap.parse_args()
    stages = [int(x) for x in a.stages.split(",")]
    names = [x for x in a.tests.split(",") if x]
    sims = a.sims.split(",")
    out_root = BUILD / a.out
    out_root.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    all_res, ok_all = [], True
    for st in stages:
        js = jobs_for([st], names, sims, a.seed_scale)
        if not js:
            continue
        # build every configuration of the stage first (in parallel)
        keys = {(j["cfg"], j["sim"], j["xbar"]) for j in js}
        with ThreadPoolExecutor(max(1, min(len(keys), a.jobs // 2 or 1))) as ex:
            list(ex.map(lambda k: build(CFG[k[0]], k[1], k[2]), keys))
        with ThreadPoolExecutor(a.jobs) as ex:
            res = list(ex.map(lambda j: run_job(j, out_root, a.keep), js))
        npass = sum(r["ok"] for r in res)
        print(f"stage {st}: {npass}/{len(res)} runs pass", flush=True)
        for r in res:
            if not r["ok"]:
                print(f"  FAIL {r['id']}: " + " | ".join(r.get("fails", []))[:600], flush=True)
        all_res += res
        if npass != len(res):
            ok_all = False
            print(f"stage {st} failed: later stages not run", flush=True)
            break
    # cross-simulation: the same test under Verilator and Icarus must give identical records (incl. CYCLES)
    # and identical counters
    xsim = []
    if len(sims) > 1:
        by = {}
        for r in all_res:
            by.setdefault(r["id"].rsplit("__", 1)[0], {})[r["sim"]] = r
        for key, d in sorted(by.items()):
            if len(d) < 2 or not all(x["ok"] for x in d.values()):
                continue
            files = [{f: (out_root / x["id"] / f).read_text() for f in ("records.txt", "perf.txt")} for x in d.values()]
            same = all(fl == files[0] for fl in files[1:])
            xsim.append(dict(test=key, identical=same))
            if not same:
                ok_all = False
                print(f"  CROSS-SIM MISMATCH {key}", flush=True)
        print(f"cross-simulation: {sum(x['identical'] for x in xsim)}/{len(xsim)} run pairs identical", flush=True)
    summary = dict(total=len(all_res), passed=sum(r["ok"] for r in all_res), secs=round(time.time() - t0, 1),
                   stages=stages, sims=sims, tools=tool_versions(), runs=all_res, xsim=xsim)
    write_json(REPORTS / f"{a.out}.json", summary)
    print(f"total: {summary['passed']}/{summary['total']} runs pass ({summary['secs']} s)")
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
