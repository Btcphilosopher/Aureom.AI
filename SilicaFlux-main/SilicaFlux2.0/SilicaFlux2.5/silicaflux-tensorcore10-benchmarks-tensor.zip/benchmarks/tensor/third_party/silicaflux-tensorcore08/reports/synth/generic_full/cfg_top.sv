`default_nettype none
module cfg_top (
  input  wire logic clk, rst_n, rb_sel, rb_we, input wire logic [11:0] rb_addr, input wire logic [31:0] rb_wdata,
  output logic [31:0] rb_rdata, output logic rb_err,
  output logic m_req_valid, input wire logic m_req_ready, output logic m_req_write, output logic [31:0] m_req_addr,
  output logic [31:0] m_req_wdata, output logic [3:0] m_req_wstrb, input wire logic m_rsp_valid, output logic m_rsp_ready,
  input wire logic [31:0] m_rsp_rdata, input wire logic m_rsp_error, output logic irq, busy, halted,
  output logic [639:0] perf_ev, input wire logic [1:0] fi_mode
);
  silicaflux_tensor_unit #(.ENABLE_QUANTIZATION(1), .ENABLE_DOUBLE_BUFFERING(1)) u (.*);
endmodule
`default_nettype wire
