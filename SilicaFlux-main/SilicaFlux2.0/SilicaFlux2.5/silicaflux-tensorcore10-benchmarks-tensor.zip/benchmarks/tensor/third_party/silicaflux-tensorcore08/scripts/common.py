"""Shared build / run helpers for the TENSORCORE 08 scripts (standard library only)."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build"
REPORTS = ROOT / "reports"
sys.path.insert(0, str(ROOT / "model"))

TB_FILES = ["third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_addr_decoder.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_arbiter.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_error_slave.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_req_mux.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_rsp_router.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_crossbar.sv",
            "tb/tb_tsu.sv"]

_lock = threading.Lock()


def run(cmd, cwd=ROOT, timeout=None, log=None):
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
    if log:
        Path(log).write_text(p.stdout)
    return p.returncode, p.stdout


def tb_params(cfg, xbar=0) -> dict:
    return dict(ROWS=cfg.rows, COLS=cfg.cols, TK=cfg.tile_k, OPB=cfg.opbuf, NB=cfg.banks, QUANT=cfg.quant,
                DBUF=cfg.dbuf, MAXOUT=cfg.max_out, KMAX=cfg.k_max, CMDQ=cfg.cmdq, CPLQ=cfg.cplq, WDOG=cfg.wdog,
                FI=cfg.fault, XBAR=xbar)


def build(cfg, sim="verilator", xbar=0) -> Path:
    """Build (once) the testbench for a hardware configuration; returns the executable / vvp file."""
    par = tb_params(cfg, xbar)
    key = hashlib.sha1(json.dumps([sim, par], sort_keys=True).encode()).hexdigest()[:12]
    out = BUILD / sim / key
    exe = out / ("Vtb_tsu" if sim == "verilator" else "tb.vvp")
    with _lock:
        if exe.exists():
            return exe
        out.mkdir(parents=True, exist_ok=True)
        (out / "params.json").write_text(json.dumps(par))
        if sim == "verilator":
            cmd = ["verilator", "--binary", "--timing", "-O2", "-j", "2", "--top-module", "tb_tsu", "-Mdir", str(out),
                   "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-INITIALDLY", "-Wno-MULTIDRIVEN",
                   "-Wno-SYNCASYNCNET", "-Wno-BLKANDNBLK", "-Wno-UNOPTFLAT", "-Wno-CASEINCOMPLETE", "-Wno-WIDTH",
                   "--x-assign", "unique", "--x-initial", "unique", "+define+TOB_ASSERT", "+define+SRAMLIB_ASSERT"]
            cmd += [f"-G{k}={v}" for k, v in par.items()]
            cmd += ["-f", "rtl/files.f"] + TB_FILES
        else:
            cmd = ["iverilog", "-g2012", "-o", str(exe), "-s", "tb_tsu", "-DTOB_ASSERT", "-DSRAMLIB_ASSERT"]
            cmd += [f"-Ptb_tsu.{k}={v}" for k, v in par.items()]
            cmd += ["-f", str(_icarus_filelist(out))] + TB_FILES
        rc, txt = run(cmd, log=out / "build.log")
        if rc != 0 or not exe.exists():
            raise RuntimeError(f"build failed ({sim}, {par}):\n" + txt[-3000:])
        return exe


def _icarus_filelist(out: Path) -> Path:
    """Icarus understands +incdir+ and plain files in -f lists, as Verilator does."""
    p = out / "files_icarus.f"
    p.write_text((ROOT / "rtl" / "files.f").read_text())
    return p


def simulate(exe: Path, test_dir: Path, plusargs: dict, sim="verilator", timeout=3600) -> int:
    args = [f"+dir={test_dir}"] + [f"+{k}={v}" for k, v in plusargs.items()]
    cmd = [str(exe)] + args if sim == "verilator" else ["vvp", "-n", str(exe)] + args
    rc, _ = run(cmd, cwd=test_dir, timeout=timeout, log=test_dir / "sim.log")
    return rc


def tool_versions() -> dict:
    v = {}
    for name, cmd in (("verilator", ["verilator", "--version"]), ("iverilog", ["iverilog", "-V"]),
                      ("yosys", ["yosys", "-V"]), ("nextpnr-ecp5", ["nextpnr-ecp5", "--version"]),
                      ("python", [sys.executable, "--version"])):
        try:
            v[name] = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True).stdout.splitlines()[0]
        except Exception as e:  # noqa: BLE001
            v[name] = f"unavailable ({e})"
    return v


def write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1))


def clean_dir(p: Path):
    if p.exists():
        shutil.rmtree(p)
    p.mkdir(parents=True)


CPUS = os.cpu_count() or 2
