#!/usr/bin/env python3
"""Coexistence regression: tb/tb_system.sv on integration/sfx_hpc_tensor_system.sv (HPC Module 08 tile +
tensor unit + host CPU traffic on the DataFabric crossbar, one shared SRAM).  Checks the tensor records, the HPC
tile records, the whole final memory (GEMM results, FP32 kernel results, nothing else changed) and the SFB2
protocol checkers on all three master ports."""
from __future__ import annotations

import json
import shutil
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, CPUS, REPORTS, ROOT, run, write_json  # noqa: E402

import check  # noqa: E402
from gen_system import system_prog  # noqa: E402

DEFS = ["+define+HPC_TILE_ASSERT", "+define+HPC_DMA_ASSERT", "+define+HPC_SPM_ASSERT", "+define+SRAMLIB_ASSERT",
        "+define+TOB_ASSERT"]
RUNS = [dict(seed=s, lat=lat, cpu_rate=cpu) for s in (1, 2, 3) for lat, cpu in ((1, 0), (1, 40), (4, 25))]


def build() -> Path:
    out = BUILD / "system"
    exe = out / "Vtb_system"
    if exe.exists():
        return exe
    out.mkdir(parents=True, exist_ok=True)
    cmd = ["verilator", "--binary", "--timing", "-O2", "-j", "4", "--top-module", "tb_system", "-Mdir", str(out),
           "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-INITIALDLY", "-Wno-MULTIDRIVEN",
           "-Wno-SYNCASYNCNET", "-Wno-BLKANDNBLK", "-Wno-UNOPTFLAT", "-Wno-CASEINCOMPLETE", "-Wno-WIDTH",
           *DEFS, "-f", "integration/files_system.f", "third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv",
           "tb/tb_system.sv"]
    rc, txt = run(cmd, log=out / "build.log")
    if rc != 0:
        raise RuntimeError(txt[-3000:])
    return exe


def one(exe, r):
    d = BUILD / "system_runs" / f"s{r['seed']}_lat{r['lat']}_cpu{r['cpu_rate']}"
    if d.exists():
        shutil.rmtree(d)
    p = system_prog(r["seed"] * 77 + 5)
    p.write(d, meta=r)
    e = json.loads((d / "expect.json").read_text())
    e["extra"] = p.extra
    (d / "expect.json").write_text(json.dumps(e))
    plus = [f"+dir={d}", f"+seed={r['seed']}", f"+lat={r['lat']}", f"+cpu_rate={r['cpu_rate']}", f"+cpu_lo={p.plus['cpu_lo']}"]
    t0 = time.time()
    run([str(exe)] + plus, cwd=d, log=d / "sim.log")
    res = check.check(d)
    tile = [l.split() for l in (d / "tile_records.txt").read_text().splitlines() if l.strip()]
    if len(tile) != len(p.tile_expect):
        res["ok"] = False
        res["fails"].append(f"{len(tile)} tile records, {len(p.tile_expect)} expected")
    for i, (t, x) in enumerate(zip(tile, p.tile_expect)):
        info, count = int(t[1], 16), int(t[3], 16)
        got = dict(tag=info & 0xFF, status=(info >> 8) & 0xF, type=(info >> 12) & 0xF, count=count)
        if got != x or not (info >> 31) & 1:
            res["ok"] = False
            res["fails"].append(f"tile record {i}: {got} expected {x}")
    stats = (d / "stats.txt").read_text() if (d / "stats.txt").exists() else ""
    res.update(r, secs=round(time.time() - t0, 1), stats=stats, n_tile=len(tile))
    return res


def main():
    exe = build()
    with ThreadPoolExecutor(CPUS) as ex:
        res = list(ex.map(lambda r: one(exe, r), RUNS))
    n = sum(x["ok"] for x in res)
    for x in res:
        tag = "PASS" if x["ok"] else "FAIL " + " | ".join(x["fails"])[:400]
        print(f"seed {x['seed']} lat {x['lat']} cpu {x['cpu_rate']}%: {tag}; tensor records {x['n_records']}, "
              f"tile records {x['n_tile']}; " + " ".join(x["stats"].split("\n")[3:5]))
    print(f"system: {n}/{len(res)} runs pass")
    write_json(REPORTS / "system.json", dict(passed=n, total=len(res), runs=res))
    sys.exit(0 if n == len(res) else 1)


if __name__ == "__main__":
    main()
