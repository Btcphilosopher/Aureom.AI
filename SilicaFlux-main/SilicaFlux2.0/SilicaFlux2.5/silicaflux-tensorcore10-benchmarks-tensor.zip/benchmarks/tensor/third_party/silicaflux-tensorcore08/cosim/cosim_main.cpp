// =============================================================================
// SilicaFlux TENSORCORE 08 :: cosim_main.cpp  -- SIMULATION BACKEND of the host driver
//
// Runs the unmodified C driver (sw/tsu_driver.c) and a host program against the Verilated RTL of
// silicaflux_tensor_unit.  Nothing here is a hardware driver: every TSU_WR32 / TSU_RD32 becomes one register-bus
// strobe cycle on the RTL, and "device memory" is a byte array served to the unit's SFB2 master port by a C++
// SFB2 slave model (writes performed when answered, SFB2 R7; programmable latency).
//
//   host program -> tsu_driver.c -> tsu_cosim_wr32/rd32 -> rb_* pins -> RTL -> m_req_* -> memory model
//
// Host access to device memory (tsu_host_write / tsu_host_read) stands for the CPU's ordinary loads and stores
// to shared SRAM; it bypasses the unit, exactly as a CPU store to SRAM would.
// =============================================================================
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <deque>
#include <vector>

#include "Vsilicaflux_tensor_unit.h"
#include "verilated.h"

#include "tsu_driver.h"
#include "tsu_host.h"

static const uint32_t MEM_BASE = 0x10000000u;
static const uint32_t MEM_BYTES = 1u << 20;

static Vsilicaflux_tensor_unit *top;
static std::vector<uint8_t> mem(MEM_BYTES);
static uint64_t cycles = 0;
static int last_err = 0;
static unsigned latency = 2;

struct Txn { bool w; uint32_t a, d; uint8_t s; uint64_t due; };
static std::deque<Txn> q;
static bool rsp_v = false, rsp_e = false;
static uint32_t rsp_d = 0;

static bool in_mem(uint32_t a) { return a >= MEM_BASE && (uint64_t)a + 4 <= (uint64_t)MEM_BASE + MEM_BYTES; }

// one clock cycle; the register-bus inputs for this cycle are already applied
static void tick() {
    top->m_req_ready = 1;
    top->m_rsp_valid = rsp_v;
    top->m_rsp_rdata = rsp_d;
    top->m_rsp_error = rsp_e;
    top->clk = 0;
    top->eval();
    // sample this cycle's handshakes (before the edge)
    bool req = top->m_req_valid && top->m_req_ready;
    bool rsp = rsp_v && top->m_rsp_ready;
    Txn t{(bool)top->m_req_write, (uint32_t)top->m_req_addr, (uint32_t)top->m_req_wdata,
          (uint8_t)top->m_req_wstrb, cycles + latency};
    top->clk = 1;
    top->eval();
    cycles++;
    // memory model: registered response, in order, one per cycle
    if (rsp) rsp_v = false;
    if (req) q.push_back(t);
    if (!rsp_v && !q.empty() && q.front().due <= cycles) {
        Txn h = q.front();
        q.pop_front();
        bool e = !in_mem(h.a) || (h.a & 3u);
        rsp_v = true;
        rsp_e = e;
        rsp_d = 0;
        uint32_t o = h.a - MEM_BASE;
        if (!e && h.w) {
            for (int b = 0; b < 4; b++) if (h.s & (1u << b)) mem[o + b] = (uint8_t)(h.d >> (8 * b));
        } else if (!e) {
            rsp_d = mem[o] | (mem[o + 1] << 8) | (mem[o + 2] << 16) | ((uint32_t)mem[o + 3] << 24);
        }
    }
}

extern "C" void tsu_cosim_wr32(uint32_t off, uint32_t v) {
    top->rb_sel = 1; top->rb_we = 1; top->rb_addr = off; top->rb_wdata = v;
    top->clk = 0; top->eval();
    last_err = top->rb_err;
    tick();
    top->rb_sel = 0; top->rb_we = 0;
}

extern "C" uint32_t tsu_cosim_rd32(uint32_t off) {
    top->rb_sel = 1; top->rb_we = 0; top->rb_addr = off; top->rb_wdata = 0;
    top->clk = 0; top->eval();
    uint32_t v = top->rb_rdata;
    last_err = top->rb_err;
    tick();
    top->rb_sel = 0;
    return v;
}

extern "C" int tsu_cosim_last_err(void) { return last_err; }

extern "C" void tsu_host_write(uint32_t addr, const void *src, uint32_t len) {
    const uint8_t *s = (const uint8_t *)src;
    for (uint32_t i = 0; i < len; i++) mem.at(addr - MEM_BASE + i) = s[i];
}

extern "C" void tsu_host_read(uint32_t addr, void *dst, uint32_t len) {
    uint8_t *d = (uint8_t *)dst;
    for (uint32_t i = 0; i < len; i++) d[i] = mem.at(addr - MEM_BASE + i);
}

extern "C" uint64_t tsu_host_cycles(void) { return cycles; }

int main(int argc, char **argv) {
    Verilated::commandArgs(argc, argv);
    if (const char *l = getenv("TSU_COSIM_LATENCY")) latency = (unsigned)atoi(l);
    top = new Vsilicaflux_tensor_unit;
    top->fi_mode = 0;
    top->rb_sel = 0;
    top->rst_n = 0;
    for (int i = 0; i < 5; i++) tick();
    top->rst_n = 1;
    for (int i = 0; i < 3; i++) tick();
    uint32_t seed = 12345;
    for (auto &b : mem) { seed = seed * 1103515245u + 12345u; b = (uint8_t)(seed >> 16); }
    int rc = host_main();
    top->final();
    delete top;
    printf("cosim: %llu cycles, host program returned %d\n", (unsigned long long)cycles, rc);
    return rc == 0 ? 0 : 1;
}
