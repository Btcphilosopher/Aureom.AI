# 00 — Repository audit and dependency readiness

Scope: every component the brief names, located in `btcphilosopher/Aureom.AI`
(`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/*.zip`), inspected as delivered. Nothing is assumed from a
README alone: interfaces were read in the RTL, copies were compared byte for byte, and the cheapest decisive
regressions of the components this module builds on were re-run in this environment.

Tools here: Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33, nextpnr-ecp5 0.6 (Ubuntu 24.04 packages; the
same baseline every earlier stage used, nextpnr excepted — HPC Module 08 used the YoWASP build 0.11).

## 1. Re-run evidence (this session, before any TENSORCORE 08 code existed)

| Component | Command | Result |
|---|---|---|
| TENSORCORE 07 (DMA adapter) | `make quick` (lint + stage 1) | lint **19/19**, stage 1 **20/20** |
| TENSORCORE 07 | `scripts/run_gemm.py` (end-to-end GEMMs on TC02/03/04 through the adapter) | **328/328** |
| TENSORCORE 06 (tile controller) | `make quick` | lint **16/16**, stage 1 **18/18** |

Logs: `reports/audit/`.

## 2. Provenance checks

* The TC02 array, TC03 operand buffer and TC04 accumulator copies vendored by TC03/04/05/06/07 are
  **byte-identical** to the originals (18 files compared). TC07's copies of HPC Module 04, the DataFabric
  crossbar and SRAM slave, and the SRAM library are identical to their source archives.
* Every file that both HPC Module 08 and this module vendor (SRAM library, DataFabric DMA / crossbar /
  checker, Module 04 scratchpad, `hpc_command_queue`, `hpc_perf_counters`) is **byte-identical**, so the tile
  and the tensor unit compile together from one copy of each (`integration/files_system.f`).
* **Two different `tensor_pe.sv` exist.** TENSORCORE 01's PE (`clk_i/rst_ni`, `tensor_pe_pkg`, formal proof)
  was not present when TENSORCORE 02 was written; TC02 wrote its own PE (`clk/rst_n`, `MUL_PIPE`,
  `CHECK_ALIGN`). The verified array instantiates TC02's PE. The two modules have the same name and different
  ports, so they cannot be compiled together; TC01's PE is therefore **not** used.
* **Two different `hpc_command_queue.sv` and `hpc_perf_counters.sv` exist.** HPC Module 06 / 07 deliver a full
  queue+scheduler and a full telemetry unit; HPC Module 08 (the integrated tile) delivers minimal generic
  versions under the same names. This module uses the **Module 08 versions** — the ones deployed in the tile it
  must coexist with.

## 3. Readiness

| Brief item | Where | What exists (verified by its own stage) | Used here | How / why not |
|---|---|---|---|---|
| `tensor_pe.sv` | TC01; TC02 `rtl/tensor_pe.sv` | TC01: standalone PE + mesh, formal SAT proof. TC02: PE inside the array | TC02's, unmodified | TC01's: name clash, incompatible interface (above) |
| `tensor_systolic_array.sv` | TC02 | output-stationary R×C array; 29/29 array runs, 44/47 mutants | **yes, unmodified** | |
| `tensor_operand_buffer.sv` | TC03 | banked A/B buffers, FREE/FILL/READY/COMPUTE sets, tile AGU; 33/33 lint, stages 1–3 | **yes, unmodified** | |
| `tensor_accumulator.sv` | TC04 (`tensor_acc_subsystem`) | multi-tile partial-sum accumulation, STRICT_RANGE overflow guard; 1160/1160 checks | **yes, unmodified** | |
| `tensor_quantize.sv` | TC05 | requantisation (5 rounding modes, ReLU, zero-points), per-tile OPEN descriptors; 1239/1239 checks | **yes, unmodified** (INT8 output) | per-channel table and bias not exposed (doc 09) |
| `tensor_tile_controller.sv` | TC06 | complete GEMM scheduler with its **own** word-level memory mover; 290/290 runs | **partly**: `ttc_tile_iter` unmodified | the controller moves operands itself (`ttc_loader`/`ttc_store`), bypassing the DMA adapter the brief requires; TC07 doc 09 §3 lists the retrofit as open. TC08's scheduler drives the adapter instead (docs/01). Its 11 validation rules are re-implemented, generalised to INT8 output (`ttc_validate` hard-codes INT32 C) |
| `tensor_dma_adapter.sv` | TC07 | 2-D strided DMA, ownership coordination, prefetch, output buffer; 582 + 328 + 36 runs | **yes, unmodified** (+ `tensor_output_buffer`, `tdma_compute_seq`) | `tdma_compute_seq` is labelled "test infrastructure" by TC07; it is synthesizable and was verified in TC07's 328 GEMMs; its limits (one job at a time, no operand reuse) are carried into doc 09 |
| HPC command queue | M06; M08 `rtl/hpc_command_queue.sv` | M06: 8-word v1 ABI, DMA + vector executors, 193-bit FIFO entries. M08: generic WIDTH × DEPTH FIFO used by the tile | M08 FIFO **unmodified** (commands, records) | M06's queue cannot carry the 12-word GEMM descriptor and has no tensor executor; changing it would invalidate its verification. The ABI keeps M06's header word and record words 0–3 (doc 02) so a future M06 v2 can route opcode `0x40` |
| HPC performance counters | M07; M08 `rtl/hpc_perf_counters.sv` | M07: 64-bit telemetry unit. M08: generic saturating bank | M08 bank **unmodified** | the increments are also exported (`perf_ev`) for an M07-style unit |
| DataFabric | `silicaflux-datafabric` | SFB2 protocol, `sfb_crossbar` (round robin), SRAM slaves, protocol checker | **yes, unmodified** | system integration and contention tests |
| FPGAFlow | — | **does not exist** in the repository (every archive searched; HPC Module 08 reports the same) | — | the repository's own practice is used: Yosys + nextpnr-ecp5 (doc 08) |
| CPU / host register interface | SilicaFlux-V register bus (`rb_*`, `sfv_periph_bridge`) | used by DataFabric `dma_control_regs`, M06 `hpc_cq_mmio`, M08 `hpc_tile_regs` | **yes** (same contract) | |
| HPC compute tile | M08 `silicaflux_hpc_tile` | FP32 vector tile, 145/145 integration runs, SoC firmware | **yes, unmodified** in the coexistence system | |
| Scratchpad, SRAM library | M04, `silicaflux-sramlib` | | **yes, unmodified** (inside TC07's output buffer and TC03) | |

## 4. What is new in TENSORCORE 08

Everything under `rtl/` (scheduler, validator, register page, bus quiesce gate, INT8 packer, datapath wiring,
top), `integration/`, `fpga/`, `tb/`, `model/`, `sw/`, `cosim/`, `scripts/`, `syn/`. Everything under
`third_party/` is reused byte-for-byte (`third_party/SHA256SUMS`, `third_party/PROVENANCE.md`).
