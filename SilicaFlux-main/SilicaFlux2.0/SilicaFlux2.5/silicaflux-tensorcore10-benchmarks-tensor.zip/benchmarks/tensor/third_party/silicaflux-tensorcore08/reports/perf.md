# Measured performance (RTL simulation cycles)

CYCLES = the completion record (dequeue → record, including validation and the last write acknowledgement). Utilisation = MACs / (CYCLES · ROWS · COLS). Memories: `lat1` 1-cycle slave, `lat8` 8-cycle slave (both up to MAX_OUT = 4 in flight), `xbar` DataFabric crossbar + 1-cycle slave (R6). `base` = sequential baseline; `full` = double buffering with PREFETCH. Every run was also checked exactly.

| Workload | Memory | HW | CYCLES | MACs | Utilisation | SFB2 reads | SFB2 writes | Checked |
|---|---|---|---|---|---|---|---|---|
| 4x4x4 | lat1 | base | 143 | 64 | 2.8 % | 8 | 16 | ok |
| 4x4x4 | lat1 | full | 143 | 64 | 2.8 % | 8 | 16 | ok |
| 4x4x4 | lat8 | base | 185 | 64 | 2.2 % | 8 | 16 | ok |
| 4x4x4 | lat8 | full | 185 | 64 | 2.2 % | 8 | 16 | ok |
| 4x4x4 | xbar | base | 164 | 64 | 2.4 % | 8 | 16 | ok |
| 4x4x4 | xbar | full | 164 | 64 | 2.4 % | 8 | 16 | ok |
| 8x8x8 | lat1 | base | 542 | 512 | 5.9 % | 64 | 64 | ok |
| 8x8x8 | lat1 | full | 284 | 512 | 11.3 % | 64 | 64 | ok |
| 8x8x8 | lat8 | base | 766 | 512 | 4.2 % | 64 | 64 | ok |
| 8x8x8 | lat8 | full | 486 | 512 | 6.6 % | 64 | 64 | ok |
| 8x8x8 | xbar | base | 658 | 512 | 4.9 % | 64 | 64 | ok |
| 8x8x8 | xbar | full | 388 | 512 | 8.2 % | 64 | 64 | ok |
| 17x13x29 | lat1 | base | 3924 | 6409 | 10.2 % | 1439 | 221 | ok |
| 17x13x29 | lat1 | full | 2176 | 6409 | 18.4 % | 1439 | 221 | ok |
| 17x13x29 | lat8 | base | 6913 | 6409 | 5.8 % | 1439 | 221 | ok |
| 17x13x29 | lat8 | full | 5097 | 6409 | 7.9 % | 1439 | 221 | ok |
| 17x13x29 | xbar | base | 5524 | 6409 | 7.3 % | 1439 | 221 | ok |
| 17x13x29 | xbar | full | 3856 | 6409 | 10.4 % | 1439 | 221 | ok |
| 8x8x200 | lat1 | base | 3326 | 12800 | 24.1 % | 1600 | 64 | ok |
| 8x8x200 | lat1 | full | 2320 | 12800 | 34.5 % | 1600 | 64 | ok |
| 8x8x200 | lat8 | base | 6238 | 12800 | 12.8 % | 1600 | 64 | ok |
| 8x8x200 | lat8 | full | 5120 | 12800 | 15.6 % | 1600 | 64 | ok |
| 8x8x200 | xbar | base | 4954 | 12800 | 16.1 % | 1600 | 64 | ok |
| 8x8x200 | xbar | full | 3895 | 12800 | 20.5 % | 1600 | 64 | ok |
| 32x32x64 | lat1 | base | 19034 | 65536 | 21.5 % | 8192 | 1024 | ok |
| 32x32x64 | lat1 | full | 10907 | 65536 | 37.6 % | 8192 | 1024 | ok |
| 32x32x64 | lat8 | base | 35162 | 65536 | 11.6 % | 8192 | 1024 | ok |
| 32x32x64 | lat8 | full | 27035 | 65536 | 15.2 % | 8192 | 1024 | ok |
| 32x32x64 | xbar | base | 28058 | 65536 | 14.6 % | 8192 | 1024 | ok |
| 32x32x64 | xbar | full | 19364 | 65536 | 21.2 % | 8192 | 1024 | ok |
| 32x32x256 | lat1 | base | 63578 | 262144 | 25.8 % | 32768 | 1024 | ok |
| 32x32x256 | lat1 | full | 40090 | 262144 | 40.9 % | 32768 | 1024 | ok |
| 32x32x256 | lat8 | base | 122714 | 262144 | 13.4 % | 32768 | 1024 | ok |
| 32x32x256 | lat8 | full | 99226 | 262144 | 16.5 % | 32768 | 1024 | ok |
| 32x32x256 | xbar | base | 96794 | 262144 | 16.9 % | 32768 | 1024 | ok |
| 32x32x256 | xbar | full | 72739 | 262144 | 22.5 % | 32768 | 1024 | ok |
| 64x16x64_n | lat1 | base | 19034 | 65536 | 21.5 % | 8192 | 1024 | ok |
| 64x16x64_n | lat1 | full | 10907 | 65536 | 37.6 % | 8192 | 1024 | ok |
| 64x16x64_n | lat8 | base | 35162 | 65536 | 11.6 % | 8192 | 1024 | ok |
| 64x16x64_n | lat8 | full | 27035 | 65536 | 15.2 % | 8192 | 1024 | ok |
| 64x16x64_n | xbar | base | 28058 | 65536 | 14.6 % | 8192 | 1024 | ok |
| 64x16x64_n | xbar | full | 19364 | 65536 | 21.2 % | 8192 | 1024 | ok |
| 32x32x256_q8 | lat1 | full | 39569 | 262144 | 41.4 % | 32768 | 512 | ok |
| 32x32x256_q8 | lat8 | full | 97809 | 262144 | 16.8 % | 32768 | 512 | ok |
| 32x32x256_q8 | xbar | full | 72336 | 262144 | 22.6 % | 32768 | 512 | ok |
