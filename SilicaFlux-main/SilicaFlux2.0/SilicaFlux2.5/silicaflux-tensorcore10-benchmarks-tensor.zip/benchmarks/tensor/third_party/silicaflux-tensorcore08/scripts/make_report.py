#!/usr/bin/env python3
"""reports/*.md from the JSON results of the final runs (nothing here is typed by hand)."""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
R = ROOT / "reports"


def load(name):
    p = R / f"{name}.json"
    return json.loads(p.read_text()) if p.exists() else None


def tools_line(t):
    return "; ".join(f"{k}: {v}" for k, v in (t or {}).items())


def regression_md(reg, xs):
    L = ["# Integration regression (tb/tb_tsu.sv on silicaflux_tensor_unit)", ""]
    if not reg:
        return L + ["not run"]
    L += [f"Final run: **{reg['passed']} / {reg['total']} runs pass** ({reg['secs']} s).  Tools: {tools_line(reg['tools'])}.",
          "", "Every run: every completion record field the reference predicts, the WHOLE 1 MiB memory image, exact "
          "counters where defined (model/check.py), the DataFabric SFB2 protocol checker on the unit's master port, "
          "and no simulator error.", ""]
    by = defaultdict(lambda: defaultdict(lambda: [0, 0]))
    for r in reg["runs"]:
        k = (r["stage"], r["name"])
        by[k][(r["cfg"], r["mem"])][0] += r["ok"]
        by[k][(r["cfg"], r["mem"])][1] += 1
    L += ["| Stage | Test | Configuration × memory: passed / runs |", "|---|---|---|"]
    for (st, name), d in sorted(by.items()):
        cells = ", ".join(f"{c}/{m} {p}/{n}" for (c, m), (p, n) in sorted(d.items()))
        L.append(f"| {st} | `{name}` | {cells} |")
    gem = sum(r.get("ok_gemms", 0) for r in reg["runs"])
    recs = sum(r.get("n_records", 0) for r in reg["runs"])
    L += ["", f"GEMM commands completed OK and checked: **{gem}**; completion records checked: **{recs}**.", ""]
    fails = [r for r in reg["runs"] if not r["ok"]]
    if fails:
        L += ["## Failures", ""] + [f"* `{r['id']}`: {'; '.join(r.get('fails', []))[:300]}" for r in fails]
    if xs:
        n = sum(x["identical"] for x in xs.get("xsim", []))
        L += ["", "## Cross-simulation (Verilator 5.020 vs Icarus 12)", "",
              f"{xs['passed']} / {xs['total']} runs pass; **{n} / {len(xs.get('xsim', []))} run pairs identical** "
              "(the complete record stream including CYCLES, and every counter).", ""]
    return L


def system_md(s):
    L = ["# Coexistence: HPC Module 08 tile + tensor unit + host on the DataFabric crossbar", ""]
    if not s:
        return L + ["not run"]
    L += [f"**{s['passed']} / {s['total']} runs pass** (scripts/run_system.py, tb/tb_system.sv).", "",
          "| Seed | SRAM latency | Host CPU traffic | Result | Tensor records | Tile records | Both units busy (cycles) | "
          "Host transactions | Arbitration losses host / tile / tensor |", "|---|---|---|---|---|---|---|---|---|"]
    for r in s["runs"]:
        st = {}
        for line in r.get("stats", "").splitlines():
            t = line.split()
            if t and t[0].startswith("master"):
                st[t[0]] = int(t[6])
            elif len(t) == 2:
                st[t[0]] = int(t[1])
        L.append(f"| {r['seed']} | {r['lat']} | {r['cpu_rate']} % | {'PASS' if r['ok'] else 'FAIL'} | {r['n_records']} | "
                 f"{r['n_tile']} | {st.get('both_units_busy_cycles')} | {st.get('cpu_transactions')} | "
                 f"{st.get('master0')} / {st.get('master1')} / {st.get('master2')} |")
    return L


def lint_md(l):
    L = ["# Lint, elaboration and illegal configurations", ""]
    if not l:
        return L + ["not run"]
    nl, ni = sum(v["ok"] for v in l["legal"].values()), sum(v["ok"] for v in l["illegal"].values())
    L += [f"* Legal configurations — Verilator `-Wall` with **0 warnings in TENSORCORE 08 RTL**, Icarus elaboration, "
          f"Yosys `hierarchy -check`: **{nl} / {len(l['legal'])}**",
          f"* Illegal configurations rejected by Verilator, Icarus and Yosys: **{ni} / {len(l['illegal'])}** (all but "
          f"`banks_vs_buffer` with the unit's own message in all three tools; see the note below)",
          f"* System wrapper (tile + tensor unit + crossbar) Verilator `-Wall`: "
          f"**{'0 warnings in new RTL' if l['system']['ok'] else 'warnings'}**",
          f"* Generated C / Python ABI files up to date with rtl/tsu_defs.svh: **{l['abi_generated_up_to_date']}**", "",
          "| Legal configuration | Verilator new-RTL warnings | third-party warnings (reused RTL, not modified) | Icarus | Yosys |",
          "|---|---|---|---|---|"]
    for k, v in l["legal"].items():
        L.append(f"| `{k}` | {len(v['new_rtl_warnings'])} | {v['third_party_warnings']} | "
                 f"{'ok' if v['icarus_rc'] == 0 else 'FAIL'} | {'ok' if v['yosys_rc'] == 0 else 'FAIL'} |")
    L += ["", "| Illegal configuration | Verilator | Icarus | Yosys | message seen (V / I / Y) |", "|---|---|---|---|---|"]
    for k, v in l["illegal"].items():
        L.append(f"| `{k}` | {'rejected' if v['verilator'] else 'ACCEPTED'} | {'rejected' if v['icarus'] else 'ACCEPTED'} | "
                 f"{'rejected' if v['yosys'] else 'ACCEPTED'} | {'/'.join('y' if x else 'n' for x in v['message_seen'])} |")
    L += ["", "`banks_vs_buffer` (one row per bank): Yosys reports the unit's own check (its line); Verilator reaches "
          "the SRAM library's `DEPTH must be >= 2` check first and Icarus fails compiling TC03's zero-width selects. "
          "All three reject it, but only Yosys with the unit's message."]
    return L


def synth_md(s):
    L = ["# Synthesis, place and route, timing — actual tool results", ""]
    if not s:
        return L + ["not run"]
    L += [f"Tools: {tools_line(s.get('tools'))}. Raw logs: `reports/synth/<run>/`.", "",
          "**No timing closure, silicon area, power or tapeout readiness is claimed.** FPGA numbers are Yosys mapping "
          "and nextpnr post-route estimates for a harness on an LFE5U-85F (no board was programmed). The ASIC numbers "
          "are a logic-synthesis smoke test onto SKY130 HD cells (no floorplan, placement, wires or SRAM macros).", ""]
    g = [(k, v) for k, v in s.items() if k.startswith("generic_")]
    if g:
        L += ["## Generic synthesis (flattened, `check -assert`, no latch)", "", "| Run | Result | Cells | flip-flops |",
              "|---|---|---|---|"]
        for k, v in g:
            ff = sum(n for c, n in v.get("cells", {}).items() if "DFF" in c)
            L.append(f"| `{k}` | {'OK' if v.get('ok') else 'FAIL'} | {v.get('total')} | {ff} |")
    for fam, keys in (("ECP5 mapping (synth_ecp5, buffers in block RAM)", ("LUT4", "TRELLIS_FF", "CCU2C", "DP16KD",
                                                                            "MULT18X18D", "TRELLIS_DPR16X4")),
                      ("Xilinx 7-series mapping estimate (synth_xilinx; no Vivado)", ("LUT1", "LUT2", "LUT3", "LUT4",
                                                                                     "LUT5", "LUT6", "FDRE", "FDCE",
                                                                                     "CARRY4", "RAMB18E1", "RAMB36E1",
                                                                                     "DSP48E1", "RAM32M", "RAM64M"))):
        rows = [(k, v) for k, v in s.items() if k.startswith(fam[:4].lower()) or (fam.startswith("Xilinx") and k.startswith("xc7_"))]
        if not rows:
            continue
        L += ["", f"## {fam}", "", "| Run | Result | " + " | ".join(keys) + " |", "|---|---|" + "---|" * len(keys)]
        for k, v in rows:
            L.append(f"| `{k}` | {'OK' if v.get('ok') else 'FAIL'} | " + " | ".join(str(v.get('cells', {}).get(c, 0)) for c in keys) + " |")
    p = [(k, v) for k, v in s.items() if k.startswith("pnr_")]
    if p:
        L += ["", "## ECP5 place and route (nextpnr-ecp5, LFE5U-85F CABGA381, ULX3S pins, 25 MHz constraint, seed 1)", "",
              "fpga/tsu_fpga_harness.sv: every input from an LFSR register, every output folded into a registered "
              "signature (HPC Module 08 method) — utilisation includes the harness.", "",
              "| Run | Routed | Post-route Fmax estimate | 25 MHz constraint | TRELLIS_COMB | TRELLIS_FF | DP16KD | MULT18X18D |",
              "|---|---|---|---|---|---|---|---|"]
        for k, v in p:
            u = v.get("utilisation", {})
            f = v.get("fmax_mhz")

            def us(n):
                return f"{u[n][0]} / {u[n][1]}" if n in u else "—"
            tp = v.get("timing_pass_25mhz", v.get("pnr_rc") == 0)
            L.append(f"| `{k}` | {'yes' if v.get('routed') else 'NO'} | {f'{f:.2f} MHz' if f else '—'} | "
                     f"{'met' if tp else '**FAILED**'} | {us('TRELLIS_COMB')} | "
                     f"{us('TRELLIS_FF')} | {us('DP16KD')} | {us('MULT18X18D')} |")
    a = [(k, v) for k, v in s.items() if k.startswith("asic_")]
    if a:
        L += ["", "## ASIC synthesis smoke test (Yosys + ABC onto sky130_fd_sc_hd, TT 25 °C 1.80 V)", ""]
        for k, v in a:
            dl = v.get("abc_delay_ps") or []
            ff = sum(n for c, n in v.get("cells", {}).items() if "__df" in c or "__sdf" in c or "__edf" in c)
            top = sorted(v.get("cells", {}).items(), key=lambda x: -x[1])[:5]
            L += [f"* `{k}`: {'OK' if v.get('ok') else 'FAIL'} — every cell mapped to sky130_fd_sc_hd (unmapped generic "
                  f"cells: {len(v.get('unmapped', []))}); **{v.get('total')} cells**, `stat -liberty` cell area "
                  f"**{v.get('area'):.0f} µm²**, of which {ff} flip-flops (the operand / output buffers and queues are "
                  f"flip-flops: no SRAM macros). Largest cell types: " + ", ".join(f"{c} {n}" for c, n in top) + ". "
                  + (f"ABC delay estimate {dl} ps." if dl else "ABC printed no delay estimate in this flow; no timing "
                     "is reported for the ASIC run.") + " No floorplan, placement, clock tree or wires: not an area, "
                  "timing or power result.",
                  f"* liberty: `{v.get('lib_url')}`, SHA-256 `{v.get('lib_sha256')}`"]
    return L


def perf_md(p):
    L = ["# Measured performance (RTL simulation cycles)", ""]
    if not p:
        return L + ["not run"]
    L += ["CYCLES = the completion record (dequeue → record, including validation and the last write "
          "acknowledgement). Utilisation = MACs / (CYCLES · ROWS · COLS). Memories: `lat1` 1-cycle slave, `lat8` "
          "8-cycle slave (both up to MAX_OUT = 4 in flight), `xbar` DataFabric crossbar + 1-cycle slave (R6). "
          "`base` = sequential baseline; `full` = double buffering with PREFETCH. Every run was also checked exactly.", "",
          "| Workload | Memory | HW | CYCLES | MACs | Utilisation | SFB2 reads | SFB2 writes | Checked |",
          "|---|---|---|---|---|---|---|---|---|"]
    for r in p["runs"]:
        L.append(f"| {r['workload']} | {r['mem']} | {r['hw']} | {r['cycles']} | {r['macs']} | {r['util']} % | "
                 f"{r['rd_words']} | {r['wr_words']} | {'ok' if r['ok'] else 'FAIL'} |")
    return L


def mutation_md(m):
    L = ["# Mutation testing of the TENSORCORE 08 RTL", ""]
    if not m:
        return L + ["not run"]
    L += [f"**{m['killed']} / {m['total']} mutants killed** by the regression subset (scripts/run_mutants.py).", "",
          "| Mutant | Result | Evidence |", "|---|---|---|"]
    for x in m["mutants"]:
        L.append(f"| {x['name']} | {x['status']} | {x['detail'][-1] if x['detail'] else ''} |")
    surv = [x for x in m["mutants"] if x["status"] != "KILLED"]
    if surv:
        L += ["", "## Survivors", ""]
        for x in surv:
            L.append(f"* **{x['name']}** — " + EQUIV.get(x["id"], "NOT analysed as equivalent: a test gap."))
    return L


EQUIV = {
    "S01": ("analysed as **equivalent** (redundant interlock). The completion condition also requires the adapter to "
            "be idle (`!dma_busy`) with an empty completion FIFO (`!c_valid`). TC07's `busy` covers every descriptor "
            "from intake until its channel leaves the CPL state, and the channel leaves CPL on the same clock edge "
            "that pushes the record into the completion FIFO (tensor_dma_adapter.sv, `cpl_g` / `cq_push`), so there "
            "is no cycle in which the last STORE record is neither pending nor collected. The explicit "
            "`n_cpl == n_desc` check is kept as an interlock that does not depend on TC07's internal definition of "
            "`busy`."),
}


def main():
    reg, xs, s, l, sy, p, m = (load(n) for n in ("regression", "xsim", "system", "lint", "synth", "perf", "mutation"))
    for name, lines in (("regression", regression_md(reg, xs)), ("system", system_md(s)), ("lint", lint_md(l)),
                        ("synth", synth_md(sy)), ("perf", perf_md(p)), ("mutation", mutation_md(m))):
        (R / f"{name}.md").write_text("\n".join(lines) + "\n")
    print("reports written")


if __name__ == "__main__":
    sys.exit(main())
