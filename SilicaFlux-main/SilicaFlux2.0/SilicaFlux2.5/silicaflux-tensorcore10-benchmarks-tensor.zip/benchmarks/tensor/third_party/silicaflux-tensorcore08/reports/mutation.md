# Mutation testing of the TENSORCORE 08 RTL

**25 / 26 mutants killed** by the regression subset (scripts/run_mutants.py).

| Mutant | Result | Evidence |
|---|---|---|
| S01 complete before every STORE is acknowledged | SURVIVED | stop_continue/base/lat1: passed |
| S02 INT32 STORE row length eff_n bytes | KILLED | shapes/base/lat1: group 0 cmd 0: count: got 0x10 expected 0x40 |
| S03 LOAD_B without SEAL | KILLED | shapes/base/lat1: group 0 cmd 0: err: got 0x30 expected 0x0; status: got 0x1 expected 0x0; count: got 0x0 expected 0x40; tiles: got 0x0 expected 0x1 |
| S04 B pointer not advanced per K chunk | KILLED | shapes/base/lat1: testbench did not report RESULT PASS |
| S05 C column step 4 bytes | KILLED | shapes/base/lat1: testbench did not report RESULT PASS |
| S06 read error reported as write error | KILLED | dma_errors/base/lat1: group 0 cmd 0: err: got 0x19 expected 0x18 |
| S07 abort does not flush the queue | KILLED | abort/base/rand: group 0 cmd 1: record after an aborted one is not SKIPPED/ABORTED |
| S08 ERROR does not set the sticky error | KILLED | dma_errors/base/lat1: group 0 cmd 1: err: got 0x0 expected 0x40; status: got 0x0 expected 0x2; count: got 0x24 expected 0x0; tiles: got 0x1 expected 0x0 |
| S09 SEQ not incremented | KILLED | shapes/base/lat1: group 0 cmd 1: seq 0 expected 1 |
| S10 TC05 context not advanced per tile | KILLED | quant/quant/lat1: group 0 cmd 0: err: got 0x30 expected 0x0; status: got 0x1 expected 0x0; count: got 0x8 expected 0x18; tiles: got 0x1 expected 0x3 |
| S11 COUNT not accumulated | KILLED | shapes/base/lat1: group 0 cmd 0: count: got 0x0 expected 0x40 |
| S12 watchdog never fires | KILLED | watchdog/wd/lat1: testbench did not report RESULT PASS |
| S13 no bus quiesce before the soft reset | KILLED | abort/base/rand: testbench did not report RESULT PASS |
| S14 N-major C row step missing | KILLED | shapes_nmajor/base/lat1: testbench did not report RESULT PASS |
| V01 ALIAS rule removed | KILLED | invalid/base/lat1: group 0 cmd 49: err: got 0x0 expected 0xf; status: got 0x0 expected 0x1; count: got 0x78 expected 0x0; tiles: got 0x4 expected 0x0 |
| V02 LDC compared with N, not 4N | KILLED | invalid/base/lat1: group 0 cmd 38: err: got 0xc expected 0xb |
| V03 window end off by one | KILLED | invalid/base/lat1: group 0 cmd 47: err: got 0x1a expected 0xe; detail: got 0x5 expected 0x0; count: got 0x60 expected 0x0; tiles: got 0x2 expected 0x0 |
| V04 chunk-count limit removed | KILLED | invalid/base/lat1: group 0 cmd 35: err: got 0xf expected 0xa |
| V05 C overflow not checked | KILLED | invalid/base/lat1: group 0 cmd 43: err: got 0xe expected 0xd |
| G01 gate never blocks | KILLED | dma_errors/base/rand: testbench did not report RESULT PASS |
| G02 quiesced ignores outstanding responses | KILLED | abort/base/rand: testbench did not report RESULT PASS |
| R01 DOORBELL ignores a full queue | KILLED | b2b/base/rand: testbench did not report RESULT PASS |
| R02 INT_STATUS never set | KILLED | irq/base/lat1: no interrupt edge observed |
| P01 INT8 bytes swapped inside a lane | KILLED | quant/quant/lat1: memory: 405 bytes differ, first at 0x10000511: got fc expected 07 (initial 81) |
| D01 INT8 commands use the INT32 path | KILLED | quant/quant/lat1: group 0 cmd 0: err: got 0x30 expected 0x0; status: got 0x1 expected 0x0; count: got 0x0 expected 0x18; tiles: got 0x0 expected 0x3 |
| D02 saturation never reported | KILLED | quant/quant/lat1: group 0 cmd 5: sat: got 0x0 expected 0x1 |

## Survivors

* **S01 complete before every STORE is acknowledged** — analysed as **equivalent** (redundant interlock). The completion condition also requires the adapter to be idle (`!dma_busy`) with an empty completion FIFO (`!c_valid`). TC07's `busy` covers every descriptor from intake until its channel leaves the CPL state, and the channel leaves CPL on the same clock edge that pushes the record into the completion FIFO (tensor_dma_adapter.sv, `cpl_g` / `cq_push`), so there is no cycle in which the last STORE record is neither pending nor collected. The explicit `n_cpl == n_desc` check is kept as an interlock that does not depend on TC07's internal definition of `busy`.
