# Synthesis, place and route, timing — actual tool results

Tools: verilator: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); iverilog: Icarus Verilog version 12.0 (stable) (); yosys: Yosys 0.33 (git sha1 2584903a060); nextpnr-ecp5: "nextpnr-ecp5" -- Next Generation Place and Route (Version 0.6-3build5); python: Python 3.13.18. Raw logs: `reports/synth/<run>/`.

**No timing closure, silicon area, power or tapeout readiness is claimed.** FPGA numbers are Yosys mapping and nextpnr post-route estimates for a harness on an LFE5U-85F (no board was programmed). The ASIC numbers are a logic-synthesis smoke test onto SKY130 HD cells (no floorplan, placement, wires or SRAM macros).

## Generic synthesis (flattened, `check -assert`, no latch)

| Run | Result | Cells | flip-flops |
|---|---|---|---|
| `generic_baseline` | OK | 133788 | 34467 |
| `generic_full` | OK | 186725 | 38589 |
| `generic_a8full` | OK | 345275 | 67252 |

## ECP5 mapping (synth_ecp5, buffers in block RAM)

| Run | Result | LUT4 | TRELLIS_FF | CCU2C | DP16KD | MULT18X18D | TRELLIS_DPR16X4 |
|---|---|---|---|---|---|---|---|
| `ecp5_baseline` | OK | 23711 | 10620 | 3823 | 8 | 30 | 344 |
| `ecp5_full` | OK | 31940 | 12425 | 5215 | 8 | 47 | 361 |

## Xilinx 7-series mapping estimate (synth_xilinx; no Vivado)

| Run | Result | LUT1 | LUT2 | LUT3 | LUT4 | LUT5 | LUT6 | FDRE | FDCE | CARRY4 | RAMB18E1 | RAMB36E1 | DSP48E1 | RAM32M | RAM64M |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `xc7_baseline` | OK | 559 | 4127 | 3505 | 1033 | 2323 | 4534 | 4940 | 4875 | 1611 | 8 | 0 | 25 | 235 | 0 |
| `xc7_full` | OK | 487 | 5216 | 5224 | 1292 | 2395 | 5519 | 6454 | 5049 | 2048 | 8 | 0 | 41 | 251 | 0 |

## ECP5 place and route (nextpnr-ecp5, LFE5U-85F CABGA381, ULX3S pins, 25 MHz constraint, seed 1)

fpga/tsu_fpga_harness.sv: every input from an LFSR register, every output folded into a registered signature (HPC Module 08 method) — utilisation includes the harness.

| Run | Routed | Post-route Fmax estimate | 25 MHz constraint | TRELLIS_COMB | TRELLIS_FF | DP16KD | MULT18X18D |
|---|---|---|---|---|---|---|---|
| `pnr_baseline` | yes | 28.85 MHz | met | 36254 / 83640 | 10759 / 83640 | 8 / 208 | 31 / 156 |
| `pnr_full` | yes | 23.93 MHz | **FAILED** | 47273 / 83640 | 12564 / 83640 | 8 / 208 | 48 / 156 |

## ASIC synthesis smoke test (Yosys + ABC onto sky130_fd_sc_hd, TT 25 °C 1.80 V)

* `asic_sky130_baseline`: OK — every cell mapped to sky130_fd_sc_hd (unmapped generic cells: 0); **154882 cells**, `stat -liberty` cell area **1597079 µm²**, of which 34447 flip-flops (the operand / output buffers and queues are flip-flops: no SRAM macros). Largest cell types: sky130_fd_sc_hd__dfxtp_1 29612, sky130_fd_sc_hd__mux2_1 22099, sky130_fd_sc_hd__nand2_1 15420, sky130_fd_sc_hd__nor2_1 14450, sky130_fd_sc_hd__conb_1 12179. ABC printed no delay estimate in this flow; no timing is reported for the ASIC run. No floorplan, placement, clock tree or wires: not an area, timing or power result.
* liberty: `https://raw.githubusercontent.com/The-OpenROAD-Project/OpenROAD-flow-scripts/master/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib`, SHA-256 `ec0e1067a35c8bf20b11e58d1e8ac53326067e4dac84a125cc1b917a3518d0d9`
