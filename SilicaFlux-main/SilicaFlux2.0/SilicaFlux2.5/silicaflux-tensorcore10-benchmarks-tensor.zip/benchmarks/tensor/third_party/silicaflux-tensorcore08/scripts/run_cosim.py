#!/usr/bin/env python3
"""Build and run the C host driver against the Verilated RTL (SIMULATION BACKEND, cosim/cosim_main.cpp).

Two builds: the brief's baseline (4x4, sequential, INT32 only) and the full configuration (quantisation and
double buffering enabled).  The unmodified sw/tsu_driver.c and sw/examples/gemm_demo.c are compiled with
-DTSU_COSIM; the program's output is saved to reports/cosim_<config>.log and must end with DEMO PASS.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, run  # noqa: E402

CONFIGS = {
    "baseline": [],
    "full": ["-GENABLE_QUANTIZATION=1", "-GENABLE_DOUBLE_BUFFERING=1"],
}


def main():
    ok = True
    for name, gp in CONFIGS.items():
        out = BUILD / "cosim" / name
        out.mkdir(parents=True, exist_ok=True)
        cmd = ["verilator", "--cc", "--exe", "--build", "-O2", "-j", "4", "--top-module", "silicaflux_tensor_unit",
               "-Mdir", str(out), "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-MULTIDRIVEN", "-Wno-UNOPTFLAT",
               "-Wno-SYNCASYNCNET", "-GMEM_LO=33'h010000000", "-GMEM_HI=33'h010100000", *gp,
               "-CFLAGS", f"-DTSU_COSIM -I{ROOT / 'sw' / 'include'} -O2",
               "-f", "rtl/files.f", str(ROOT / "cosim" / "cosim_main.cpp"), str(ROOT / "sw" / "tsu_driver.c"),
               str(ROOT / "sw" / "examples" / "gemm_demo.c"), "-o", "cosim"]
        rc, txt = run(cmd, log=out / "build.log")
        if rc != 0:
            print(f"{name}: build FAILED\n{txt[-3000:]}")
            ok = False
            continue
        rc, txt = run([str(out / "cosim")], cwd=out)
        log = REPORTS / f"cosim_{name}.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(txt)
        passed = rc == 0 and "DEMO PASS" in txt
        ok &= passed
        print(f"{name}: {'PASS' if passed else 'FAIL'} ({log.relative_to(ROOT)})")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
