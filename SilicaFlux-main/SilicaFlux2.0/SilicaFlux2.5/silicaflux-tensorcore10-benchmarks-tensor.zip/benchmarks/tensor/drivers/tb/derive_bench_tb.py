#!/usr/bin/env python3
"""Derive drivers/tb/tb_tensor_bench.sv from TENSORCORE 08's verified testbench (tb/tb_tsu.sv).

The host BFM (register bus), the SFB2 memory model (write performed at response, R7), the DataFabric
crossbar option and the end-of-run checks are kept byte-for-byte.  Only OBSERVATION is added:

  * program op `W tag`  -> snapshot of every counter: the 20 host-visible PERF registers and 18 DMA_PERF
                           registers (read through the register page, exactly as software would), plus the
                           RTL-internal counters of TC02 (array), TC03 (operand buffer), TC04 (accumulator),
                           TC05 (quantiser) read through the simulation hierarchy (NOT host-visible in TC08),
                           plus testbench tallies of RTL event signals and the cycle-accounting stack;
  * events.txt          -> SUB (submit start / doorbell), DEQ (scheduler dequeue), CMD (per-command phase
                           timestamps), POP (host popped the record) with clock-cycle stamps;
  * cycle accounting    -> every cycle the scheduler is busy is put in exactly one category, classified from
                           RTL state (scheduler, TC07 compute sequencer, TC02 array controller, handshakes);
  * ALLOW_UNVERIFIED    -> passed through (16x16 scaling experiment), MEM_BYTES / dump range as parameters.

Every insertion anchor must occur exactly once in the source; otherwise derivation fails (no silent drift).
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
LAB = HERE.parents[1]
SRC = LAB / "third_party" / "silicaflux-tensorcore08" / "tb" / "tb_tsu.sv"
DST = HERE / "tb_tensor_bench.sv"

OBS = r"""
  // ===========================================================================================================
  // BENCH OBSERVATION (benchmarks/tensor) -- added by drivers/tb/derive_bench_tb.py; observes, never drives
  // ===========================================================================================================
  // Cycle-accounting categories (exactly one per cycle while the scheduler is not IDLE):
  //   1 VALIDATE     scheduler DECODE / PREP (descriptor validation, per-command constants)
  //   2 RECORD       scheduler RECORD (completion record push)
  //   3 ERRPATH      QUIESCE / SRST / FLUSH / HALT
  //   4 WAIT_OPND    compute sequencer waits for a sealed operand set (cmp_begin): memory waiting on loads
  //   5 SETUP        sequencer / array launch set-up (TC04 cfg, TC03 tile descriptor, TC02 cfg, CLEAR, accept)
  //   6 MAC_ISSUE    array RUN and a k-slice accepted (PE slots issued; padding included, see TC02 PAD)
  //   7 STARVED      array RUN with no slice offered (operand starvation inside TC03 delivery)
  //   8 DRAIN        array pipeline drain after the last slice (DRAIN state)
  //   9 READOUT      array READOUT with the accumulator accepting rows
  //  10 OUT_STALL    array READOUT back-pressured by TC04 (output stall)
  //  11 STORE_TAIL   compute sequencer idle, no job offered, DMA adapter busy (stores / loads with no compute)
  //  12 SCHED_GAP    compute sequencer idle, no job offered, DMA idle (scheduler bookkeeping)
  //  13 CE_WAIT      sequencer waits for the operand-set release (cmp_end) outside DRAIN / READOUT
  localparam int BNC = 14;
  longint bca [0:BNC-1];
  longint b_rd_hs = 0, b_wr_hs = 0, b_rsp_hs = 0, b_req_stall = 0, b_ob_cfl_w = 0, b_ob_cfl_d = 0, b_ob_wwait = 0;
  longint b_busy = 0;
  int     fd_ev, fd_snap;
  longint bt_sub0 = 0;
  // per-command phase stamps
  longint ph_deq = -1, ph_rd0 = -1, ph_sl0 = -1, ph_sl1 = -1, ph_ro1 = -1, ph_wr0 = -1, ph_wr1 = -1;
  logic [3:0] b_st_q = 4'd0;
  initial for (int i = 0; i < BNC; i++) bca[i] = 0;
  // TC02's perf outputs are PER LAUNCH (cleared by cfg_go, TC02 identity busy = 1 + K + M + N + stalls):
  // accumulate the finished launch's values at the clearing edge; a snapshot adds the live (current) launch.
  longint a2_busy = 0, a2_issue = 0, a2_su = 0, a2_se = 0, a2_mac = 0, a2_pad = 0, a2_launch = 0;
  always @(posedge clk) if (rst_n && dut.u_dp.u_arr.cfg_go) begin
    a2_busy = a2_busy + dut.u_dp.p_busy; a2_issue = a2_issue + dut.u_dp.p_issue; a2_su = a2_su + dut.u_dp.p_su;
    a2_se = a2_se + dut.u_dp.p_se; a2_mac = a2_mac + dut.u_dp.p_mac; a2_pad = a2_pad + dut.u_dp.p_pad;
    a2_launch = a2_launch + 1;
  end

  logic [3:0] b_sp, b_cs;
  logic [2:0] b_as;
  logic       b_sv, b_sr, b_mv, b_mr, b_jv, b_db;
  assign b_sp = dut.u_sched.st;
  assign b_cs = dut.u_dp.u_seq.s;
  assign b_as = dut.u_dp.u_arr.state_q;
  assign b_sv = dut.u_dp.s_valid;
  assign b_sr = dut.u_dp.s_ready;
  assign b_mv = dut.u_dp.m_valid;
  assign b_mr = dut.u_dp.m_ready;
  assign b_jv = dut.u_dp.job_valid;
  assign b_db = dut.dma_busy;

  function automatic int classify();
    // scheduler states (tsu_defs.svh TSU_S_*): 0 IDLE 1 DECODE 2 PREP 3 RUN 4 QUIESCE 5 SRST 6 RECORD 7 FLUSH 8 HALT
    // compute sequencer (tdma_compute_seq): 0 IDLE 1 CB 2 CFG 3 TILE 4 TRSP 5 ACFG 6 RUN 7 CE 8 RD
    // array (tensor_systolic_array): 0 IDLE 1 CLEAR 2 RUN 3 DRAIN 4 READOUT
    if (b_sp == 4'd0) return 0;
    if (b_sp == 4'd1 || b_sp == 4'd2) return 1;
    if (b_sp == 4'd6) return 2;
    if (b_sp != 4'd3) return 3;
    case (b_cs)
      4'd0: return b_jv ? 5 : (b_db ? 11 : 12);
      4'd1: return 4;
      4'd2, 4'd3, 4'd4, 4'd5: return 5;
      default: begin
        case (b_as)
          3'd2: return (b_sv) ? 6 : 7;
          3'd3: return 8;
          3'd4: return b_mr ? 9 : 10;
          3'd1: return 5;
          default: return (b_cs == 4'd7) ? 13 : 5;
        endcase
      end
    endcase
  endfunction

  always @(posedge clk) if (rst_n) begin
    int c;
    c = classify();
    bca[c] = bca[c] + 1;
    if (c != 0) b_busy = b_busy + 1;
    if (t_req_valid && t_req_ready) begin
      if (t_req_write) b_wr_hs = b_wr_hs + 1; else b_rd_hs = b_rd_hs + 1;
      if (!t_req_write && ph_rd0 < 0) ph_rd0 = cyc;
      if (t_req_write && ph_wr0 < 0) ph_wr0 = cyc;
    end
    if (t_req_valid && !t_req_ready) b_req_stall = b_req_stall + 1;
    if (t_rsp_valid && t_rsp_ready) begin b_rsp_hs = b_rsp_hs + 1; ph_wr1 = cyc; end
    if (dut.u_dp.ob_conflict[0]) b_ob_cfl_w = b_ob_cfl_w + 1;
    if (dut.u_dp.ob_conflict[1]) b_ob_cfl_d = b_ob_cfl_d + 1;
    if (dut.u_dp.ob_ev_wait) b_ob_wwait = b_ob_wwait + 1;
    if (b_sv && b_sr) begin if (ph_sl0 < 0) ph_sl0 = cyc; ph_sl1 = cyc; end
    if (b_mv && b_mr) ph_ro1 = cyc;
    if (b_st_q == 4'd0 && b_sp != 4'd0) begin
      ph_deq = cyc; ph_rd0 = -1; ph_sl0 = -1; ph_sl1 = -1; ph_ro1 = -1; ph_wr0 = -1; ph_wr1 = -1;
      $fdisplay(fd_ev, "DEQ %0d", cyc);
    end
    if (dut.ev_commit && b_sp == 4'd6)
      $fdisplay(fd_ev, "CMD %0d %0d %0d %0d %0d %0d %0d %0d", ph_deq, cyc, ph_rd0, ph_sl0, ph_sl1, ph_ro1, ph_wr0, ph_wr1);
    b_st_q <= b_sp;
  end

  // RTL-internal counters (simulation hierarchy; not on the TC08 register page)
  logic [13*32-1:0] b_q_perf;
  if (QUANT != 0) begin : g_bq
    assign b_q_perf = dut.u_dp.g_quant.q_perf;
  end else begin : g_bnq
    assign b_q_perf = '0;
  end

  task automatic bench_snap(input int tag);
    logic [31:0] q;
    for (int i = 0; i < NPC; i++) begin rd32(12'(`TSU_R_PERF0 + 4 * i), q); $fdisplay(fd_snap, "%0d PERF%0d %0d", tag, i, q); end
    for (int i = 0; i < 18; i++) begin rd32(12'(`TSU_R_DMA_PERF0 + 4 * i), q); $fdisplay(fd_snap, "%0d DMA%0d %0d", tag, i, q); end
    $fdisplay(fd_snap, "%0d TC02_BUSY %0d", tag, a2_busy + longint'(dut.u_dp.p_busy));
    $fdisplay(fd_snap, "%0d TC02_ISSUE %0d", tag, a2_issue + longint'(dut.u_dp.p_issue));
    $fdisplay(fd_snap, "%0d TC02_STALL_UP %0d", tag, a2_su + longint'(dut.u_dp.p_su));
    $fdisplay(fd_snap, "%0d TC02_STALL_EXT %0d", tag, a2_se + longint'(dut.u_dp.p_se));
    $fdisplay(fd_snap, "%0d TC02_MAC %0d", tag, a2_mac + longint'(dut.u_dp.p_mac));
    $fdisplay(fd_snap, "%0d TC02_PAD %0d", tag, a2_pad + longint'(dut.u_dp.p_pad));
    $fdisplay(fd_snap, "%0d TC02_LAUNCH %0d", tag, a2_launch);
    for (int i = 0; i < 20; i++) $fdisplay(fd_snap, "%0d TC03_%0d %0d", tag, i, dut.u_dp.t_pc[32*i +: 32]);
    for (int i = 0; i < 16; i++) $fdisplay(fd_snap, "%0d TC04_%0d %0d", tag, i, dut.u_dp.c_perf[40*i +: 40]);
    for (int i = 0; i < 13; i++) $fdisplay(fd_snap, "%0d TC05_%0d %0d", tag, i, b_q_perf[32*i +: 32]);
    for (int i = 0; i < BNC; i++) $fdisplay(fd_snap, "%0d CA%0d %0d", tag, i, bca[i]);
    $fdisplay(fd_snap, "%0d TB_BUSY %0d", tag, b_busy);
    $fdisplay(fd_snap, "%0d TB_RD_HS %0d", tag, b_rd_hs);
    $fdisplay(fd_snap, "%0d TB_WR_HS %0d", tag, b_wr_hs);
    $fdisplay(fd_snap, "%0d TB_RSP_HS %0d", tag, b_rsp_hs);
    $fdisplay(fd_snap, "%0d TB_REQ_STALL %0d", tag, b_req_stall);
    $fdisplay(fd_snap, "%0d TB_OB_CFL_W %0d", tag, b_ob_cfl_w);
    $fdisplay(fd_snap, "%0d TB_OB_CFL_D %0d", tag, b_ob_cfl_d);
    $fdisplay(fd_snap, "%0d TB_OB_WWAIT %0d", tag, b_ob_wwait);
    $fdisplay(fd_snap, "%0d TB_CYC %0d", tag, cyc);
  endtask
"""

EDITS = [
    ("module tb_tsu;", "module tb_tensor_bench;"),
    ("parameter int CMDQ = 4, CPLQ = 4, WDOG = 16, FI = 0, XBAR = 0;",
     "parameter int CMDQ = 4, CPLQ = 4, WDOG = 16, FI = 0, XBAR = 0, AUV = 0;"),
    (".K_MAX(KMAX), .WDOG_LOG2(WDOG), .PERF_EN(1), .FAULT_INJ(FI)",
     ".K_MAX(KMAX), .WDOG_LOG2(WDOG), .PERF_EN(1), .FAULT_INJ(FI), .ALLOW_UNVERIFIED(AUV)"),
    ("            for (int i = 0; i < 12; i++) wr32(12'(`TSU_R_DESC0 + 4 * i), f[i]);",
     "            bt_sub0 = cyc;\n            for (int i = 0; i < 12; i++) wr32(12'(`TSU_R_DESC0 + 4 * i), f[i]);"),
    ("            n_sub = n_sub + 1;\n",
     "            n_sub = n_sub + 1;\n            $fdisplay(fd_ev, \"SUB %0d %0d %0d\", n_sub - 1, bt_sub0, cyc);\n"),
    ("      $fdisplay(fd_rec, \"R %h %h %h %h %h %h\", r0, r1, r2, r3, r4, r5);\n",
     "      $fdisplay(fd_rec, \"R %h %h %h %h %h %h\", r0, r1, r2, r3, r4, r5);\n"
     "      $fdisplay(fd_ev, \"POP %0d %0d\", n_rec, cyc);\n"),
    ("          default: `ERR((\"unknown program op %h\", op))",
     "          64'(\"W\"): begin rc = $fscanf(fd, \"%d\", v); bench_snap(v); end\n"
     "          default: `ERR((\"unknown program op %h\", op))"),
    ("    fd_rec = $fopen({dir, \"/records.txt\"}, \"w\");",
     "    fd_rec = $fopen({dir, \"/records.txt\"}, \"w\");\n"
     "    fd_ev = $fopen({dir, \"/events.txt\"}, \"w\");\n"
     "    fd_snap = $fopen({dir, \"/snaps.txt\"}, \"w\");"),
    ("    $fclose(fd_rec);\n", "    $fclose(fd_rec);\n    $fclose(fd_ev);\n    $fclose(fd_snap);\n"),
    ("    $writememh({dir, \"/mem_final.hex\"}, mem);",
     "    begin\n"
     "      int dlo, dhi;\n"
     "      dlo = 0; dhi = MEM_BYTES - 1;\n"
     "      void'($value$plusargs(\"dump_lo=%d\", dlo)); void'($value$plusargs(\"dump_hi=%d\", dhi));\n"
     "      $writememh({dir, \"/mem_final.hex\"}, mem, dlo, dhi);\n"
     "    end"),
    ("endmodule", OBS + "endmodule"),
]


def derive() -> str:
    txt = SRC.read_text()
    for old, new in EDITS:
        n = txt.count(old)
        if n != 1:
            raise SystemExit(f"derive_bench_tb: anchor occurs {n} times (expected 1): {old[:70]!r}")
        txt = txt.replace(old, new)
    src_sha = hashlib.sha256(SRC.read_bytes()).hexdigest()
    hdr = ("// GENERATED by benchmarks/tensor/drivers/tb/derive_bench_tb.py -- do not edit.\n"
           f"// Source: third_party/silicaflux-tensorcore08/tb/tb_tsu.sv sha256 {src_sha}\n"
           "// Additions are observation only (see the BENCH OBSERVATION block); the host BFM and memory model are\n"
           "// TENSORCORE 08's verified ones.\n")
    return hdr + txt


def main():
    out = derive()
    check = "--check" in sys.argv
    if check:
        if not DST.exists() or DST.read_text() != out:
            raise SystemExit("tb_tensor_bench.sv is stale: run drivers/tb/derive_bench_tb.py")
        print("tb_tensor_bench.sv up to date")
        return
    DST.write_text(out)
    print(f"wrote {DST.relative_to(LAB)} ({len(out.splitlines())} lines)")


if __name__ == "__main__":
    main()
