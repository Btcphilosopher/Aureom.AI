"""Simulation driver: hardware configurations, Verilator builds of the bench testbench, runs and output parsing.

Time base: RTL-simulation clock cycles of the tensor unit (Verilator 5.020, --binary --timing).  The design under
test is TENSORCORE 08's silicaflux_tensor_unit, compiled from third_party/silicaflux-tensorcore08 unmodified.
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import threading
from dataclasses import dataclass
from pathlib import Path

LAB = Path(__file__).resolve().parents[1]
TC08 = LAB / "third_party" / "silicaflux-tensorcore08"
BUILD = LAB / "build"
sys.path.insert(0, str(TC08 / "model"))
import tsu_ref  # noqa: E402  (TC08 ABI encoding, validation rules, tile schedule / traffic model)

TB = LAB / "drivers" / "tb" / "tb_tensor_bench.sv"
TB_EXTRA = ["third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_addr_decoder.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_arbiter.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_error_slave.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_req_mux.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_rsp_router.sv",
            "third_party/silicaflux-datafabric/rtl/interconnect/sfb_crossbar.sv"]
MEM_BASE = 0x1000_0000
_lock = threading.Lock()
_build_locks: dict[str, threading.Lock] = {}


def load_json(p: Path):
    return json.loads(Path(p).read_text())


HW = load_json(LAB / "configs" / "hardware.json")
MEMS = load_json(LAB / "configs" / "memory.json")["models"]


@dataclass
class Hw:
    name: str
    p: dict

    @property
    def rows(self): return self.p["ARRAY_ROWS"]

    @property
    def cols(self): return self.p["ARRAY_COLS"]

    @property
    def quant(self): return self.p["ENABLE_QUANTIZATION"]

    @property
    def dbuf(self): return self.p["ENABLE_DOUBLE_BUFFERING"]

    @property
    def mem_bytes(self): return self.p["MEM_BYTES"]

    @property
    def verified(self): return bool(self.p.get("verified", True))

    def tsu_cfg(self) -> "tsu_ref.HwCfg":
        p = self.p
        return tsu_ref.HwCfg(rows=p["ARRAY_ROWS"], cols=p["ARRAY_COLS"], tile_k=p["TILE_K"],
                             opbuf=p["OPERAND_BUFFER_BYTES"], banks=p["NUM_MEMORY_BANKS"], quant=p["ENABLE_QUANTIZATION"],
                             dbuf=p["ENABLE_DOUBLE_BUFFERING"], max_out=p["MAX_OUT"], k_max=p["K_MAX"],
                             mem_lo=MEM_BASE, mem_hi=MEM_BASE + p["MEM_BYTES"], cmdq=p["CMD_QUEUE_DEPTH"],
                             cplq=p["CPL_QUEUE_DEPTH"], wdog=p["WDOG_LOG2"])

    def tb_params(self, xbar: int) -> dict:
        p = self.p
        return dict(ROWS=p["ARRAY_ROWS"], COLS=p["ARRAY_COLS"], TK=p["TILE_K"], OPB=p["OPERAND_BUFFER_BYTES"],
                    NB=p["NUM_MEMORY_BANKS"], QUANT=p["ENABLE_QUANTIZATION"], DBUF=p["ENABLE_DOUBLE_BUFFERING"],
                    MAXOUT=p["MAX_OUT"], KMAX=p["K_MAX"], CMDQ=p["CMD_QUEUE_DEPTH"], CPLQ=p["CPL_QUEUE_DEPTH"],
                    WDOG=p["WDOG_LOG2"], FI=0, XBAR=xbar, AUV=p["ALLOW_UNVERIFIED"], MEM_BYTES=p["MEM_BYTES"])

    def public(self) -> dict:
        return {k: v for k, v in self.p.items() if not k.startswith("_")}


def hw(name: str) -> Hw:
    p = dict(HW["baseline"])
    p.update(HW["configs"][name])
    return Hw(name, p)


def run(cmd, cwd=TC08, timeout=None, log=None, env=None):
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout,
                       env=env)
    if log:
        Path(log).write_text(p.stdout)
    return p.returncode, p.stdout


def build(h: Hw, xbar: int = 0) -> Path:
    """Build (once, cached by parameter hash + testbench hash) the Verilator executable for a configuration."""
    par = h.tb_params(xbar)
    tb_sha = hashlib.sha256(TB.read_bytes()).hexdigest()[:12]
    key = hashlib.sha1(json.dumps([par, tb_sha], sort_keys=True).encode()).hexdigest()[:12]
    out = BUILD / "verilator" / key
    exe = out / "Vtb_tensor_bench"
    with _lock:
        lk = _build_locks.setdefault(key, threading.Lock())
    with lk:
        if exe.exists():
            return exe
        out.mkdir(parents=True, exist_ok=True)
        (out / "params.json").write_text(json.dumps(dict(hw=h.name, params=par, tb_sha=tb_sha), indent=1))
        cmd = ["verilator", "--binary", "--timing", "-O2", "-j", "2", "--top-module", "tb_tensor_bench", "-Mdir", str(out),
               "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-INITIALDLY", "-Wno-MULTIDRIVEN",
               "-Wno-SYNCASYNCNET", "-Wno-BLKANDNBLK", "-Wno-UNOPTFLAT", "-Wno-CASEINCOMPLETE", "-Wno-WIDTH",
               "--x-assign", "unique", "--x-initial", "unique", "+define+TOB_ASSERT", "+define+SRAMLIB_ASSERT"]
        cmd += [f"-G{k}={v}" for k, v in par.items()]
        cmd += ["-f", "rtl/files.f"] + TB_EXTRA + [str(TB)]
        rc, txt = run(cmd, log=out / "build.log")
        if rc != 0 or not exe.exists():
            raise RuntimeError(f"Verilator build failed for {h.name} xbar={xbar}:\n" + txt[-4000:])
        return exe


def simulate(exe: Path, run_dir: Path, plusargs: dict, timeout: int = 7200) -> tuple[int, str]:
    args = [f"+dir={run_dir}"] + [f"+{k}={v}" for k, v in plusargs.items()]
    rc, txt = run([str(exe)] + args, cwd=run_dir, timeout=timeout, log=run_dir / "sim.log")
    return rc, txt


# ------------------------------------------------------------------------------------------------ output parsing
def parse_records(d: Path) -> list[dict]:
    out = []
    for line in (d / "records.txt").read_text().splitlines():
        if line.startswith("R "):
            words = [int(x, 16) for x in line.split()[1:7]]
            out.append(tsu_ref.rec_fields(words))
    return out


def parse_events(d: Path) -> dict:
    ev = dict(sub=[], deq=[], cmd=[], pop=[])
    for line in (d / "events.txt").read_text().splitlines():
        t = line.split()
        if not t:
            continue
        if t[0] == "SUB":
            ev["sub"].append(dict(i=int(t[1]), start=int(t[2]), doorbell=int(t[3])))
        elif t[0] == "DEQ":
            ev["deq"].append(int(t[1]))
        elif t[0] == "CMD":
            k = ["deq", "rec", "first_rd", "first_slice", "last_slice", "last_readout", "first_wr", "last_rsp"]
            ev["cmd"].append(dict(zip(k, map(int, t[1:9]))))
        elif t[0] == "POP":
            ev["pop"].append(dict(n=int(t[1]), t=int(t[2])))
    return ev


def parse_snaps(d: Path) -> dict[int, dict[str, int]]:
    snaps: dict[int, dict[str, int]] = {}
    for line in (d / "snaps.txt").read_text().splitlines():
        t = line.split()
        if len(t) == 3:
            snaps.setdefault(int(t[0]), {})[t[1]] = int(t[2])
    return snaps


def parse_mem(d: Path, lo: int, hi: int) -> bytearray:
    vals = bytearray()
    for line in (d / "mem_final.hex").read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("//") or line.startswith("@"):
            continue
        for tok in line.split():
            vals.append(int(tok, 16) if "x" not in tok.lower() else 0)
    if len(vals) != hi - lo + 1:
        raise RuntimeError(f"mem_final.hex has {len(vals)} bytes, expected {hi - lo + 1}")
    return vals


def sim_result(txt: str) -> str:
    for line in reversed(txt.splitlines()):
        if line.startswith("RESULT"):
            return line.split()[1]
    return "NO_RESULT"


def tool_versions() -> dict:
    v = {}
    for name, cmd in (("verilator", ["verilator", "--version"]), ("iverilog", ["iverilog", "-V"]),
                      ("yosys", ["yosys", "-V"]), ("nextpnr-ecp5", ["nextpnr-ecp5", "--version"]),
                      ("gcc", ["gcc", "--version"]), ("python", [sys.executable, "--version"])):
        try:
            v[name] = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True).stdout.splitlines()[0]
        except Exception as e:  # noqa: BLE001
            v[name] = f"unavailable ({e})"
    try:
        import numpy
        v["numpy"] = numpy.__version__
    except Exception:  # noqa: BLE001
        pass
    return v


def rtl_digest() -> str:
    """SHA-256 of TC08's SHA256SUMS manifest (identifies the exact RTL + model tree used)."""
    return hashlib.sha256((TC08 / "SHA256SUMS").read_bytes()).hexdigest()


CPUS = os.cpu_count() or 2
