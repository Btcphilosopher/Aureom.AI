/* Example 3: long reduction.  K = 32 768 with every operand -128: each C element is 32 768 * 16 384 = 536 870 912,
 * accumulated exactly in INT32 across 512 K chunks; then a random K = 16 384 GEMM. */
#include "ex_common.h"

static int8_t a[4 * 32768], b[32768 * 4];
static int32_t c[16];

static int run(sftc_ctx_t *ctx, uint32_t K, int extreme, uint32_t seed)
{
    sftc_buf_t A, B, C;
    sftc_counters_t c0, c1, d;
    sftc_opts_t o = {0};
    tsu_record_t rec;
    char lbl[64];
    ctx->top = ctx->arena_lo;                                    /* reuse the arena */
    if (extreme) { for (uint32_t i = 0; i < 4 * K; i++) { a[i] = -128; b[i] = -128; } }
    else { ex_fill(a, 4 * K, seed); ex_fill(b, 4 * K, seed + 1); }
    EX_CHECK(sftc_alloc(ctx, &A, 4, K, 1, 0, 4) == 0, "alloc A");
    EX_CHECK(sftc_alloc(ctx, &B, K, 4, 1, 0, 4) == 0, "alloc B");
    EX_CHECK(sftc_alloc(ctx, &C, 4, 4, 4, 0, 4) == 0, "alloc C");
    sftc_pack_i8(&A, a, K);
    sftc_pack_i8(&B, b, 4);
    o.prefetch = ex_dbuf_build(ctx);
    sftc_counters(&c0);
    int rc = sftc_gemm(ctx, &A, &B, &C, &o, &rec);
    sftc_counters(&c1);
    EX_CHECK(rc == 0, "sftc_gemm -> %d (%s)", rc, tsu_err_name(rc));
    sftc_read_i32(&C, c);
    long bad = sftc_check_i32(c, a, b, 4, 4, K);
    sftc_counters_delta(&c0, &c1, &d);
    snprintf(lbl, sizeof lbl, "  4x4x%u%s", K, extreme ? " (all -128)" : "");
    sftc_print_summary(lbl, &rec, &d, ex_rows(ctx), ex_cols(ctx));
    if (extreme) EX_CHECK(c[0] == (int32_t)(K * 16384u), "C[0] = %d, expected %u", c[0], K * 16384u);
    EX_CHECK(bad == 0, "%ld mismatching elements", bad);
    EX_CHECK(d.perf[7] == (K + 63) / 64, "CHUNKS %u", d.perf[7]);
    return 0;
}

int ex03_long_k(void)
{
    sftc_ctx_t ctx;
    EX_CHECK(sftc_open(&ctx, EX_ARENA_LO, EX_ARENA_BYTES) == 0, "open");
    if (run(&ctx, 32768, 1, 0)) return 1;
    return run(&ctx, 16384, 0, 99);
}
