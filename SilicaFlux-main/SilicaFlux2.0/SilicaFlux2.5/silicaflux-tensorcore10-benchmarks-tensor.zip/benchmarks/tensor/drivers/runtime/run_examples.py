#!/usr/bin/env python3
"""Build the host runtime examples against the Verilated RTL (SIMULATION BACKEND) and run them.

Per hardware configuration, ONE Verilator build links: TC08 cosim/cosim_main.cpp (unmodified simulation backend),
TC08 sw/tsu_driver.c (unmodified driver), drivers/runtime/sftc_runtime.c and the six examples.  Each example
runs in its own process (SFTC_EXAMPLE=<name>) and must print EXAMPLE PASS.  Logs: reports/runtime/<cfg>__<ex>.log,
summary: reports/runtime/summary.json.  Memory latency of the C++ slave: TSU_COSIM_LATENCY (default 2 here, as TC08).
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path

LAB = Path(__file__).resolve().parents[2]
TC08 = LAB / "third_party" / "silicaflux-tensorcore08"
RT = LAB / "drivers" / "runtime"
OUT = LAB / "reports" / "runtime"
CONFIGS = {"base": [], "full": ["-GENABLE_QUANTIZATION=1", "-GENABLE_DOUBLE_BUFFERING=1"]}
EXAMPLES = ["ex01_gemm4x4", "ex02_tiled", "ex03_long_k", "ex04_gemv", "ex05_qgemm", "ex06_async"]


def build(cfg: str, gp: list[str]) -> Path:
    out = LAB / "build" / "runtime" / cfg
    out.mkdir(parents=True, exist_ok=True)
    srcs = [TC08 / "cosim" / "cosim_main.cpp", TC08 / "sw" / "tsu_driver.c", RT / "sftc_runtime.c"] + \
        [RT / "examples" / f"{e}.c" for e in EXAMPLES] + [RT / "examples" / "examples_main.c"]
    cmd = ["verilator", "--cc", "--exe", "--build", "-O2", "-j", "4", "--top-module", "silicaflux_tensor_unit",
           "-Mdir", str(out), "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-MULTIDRIVEN", "-Wno-UNOPTFLAT",
           "-Wno-SYNCASYNCNET", "-GMEM_LO=33'h010000000", "-GMEM_HI=33'h010100000", *gp,
           "-CFLAGS", f"-DTSU_COSIM -I{TC08 / 'sw' / 'include'} -I{RT} -I{RT / 'examples'} -O2",
           "-f", "rtl/files.f", *map(str, srcs), "-o", "sftc_examples"]
    p = subprocess.run(cmd, cwd=TC08, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (out / "build.log").write_text(p.stdout)
    if p.returncode != 0:
        raise SystemExit(f"{cfg}: build failed\n{p.stdout[-3000:]}")
    return out / "sftc_examples"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    summary = dict(backend="simulation (TC08 cosim/cosim_main.cpp + Verilated RTL); no hardware driver exercised",
                   memory_latency_cycles=int(os.environ.get("TSU_COSIM_LATENCY", "2")), runs=[])
    ok = True
    for cfg, gp in CONFIGS.items():
        exe = build(cfg, gp)
        for ex in EXAMPLES:
            env = dict(os.environ, SFTC_EXAMPLE=ex)
            env.setdefault("TSU_COSIM_LATENCY", "2")
            p = subprocess.run([str(exe)], cwd=exe.parent, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                               env=env, timeout=3600)
            (OUT / f"{cfg}__{ex}.log").write_text(p.stdout)
            passed = p.returncode == 0 and f"EXAMPLE PASS {ex}" in p.stdout
            skipped = "SKIPPED" in p.stdout
            cyc = [int(x) for x in re.findall(r"CYCLES (\d+)", p.stdout)]
            summary["runs"].append(dict(config=cfg, example=ex, status="PASS" if passed else "FAIL", skipped=skipped,
                                        record_cycles=cyc, log=f"reports/runtime/{cfg}__{ex}.log"))
            ok &= passed
            print(f"{cfg:<5} {ex:<14} {'PASS' if passed else 'FAIL'}{' (skipped: needs quantisation)' if skipped else ''}")
    (OUT / "summary.json").write_text(json.dumps(summary, indent=1))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
