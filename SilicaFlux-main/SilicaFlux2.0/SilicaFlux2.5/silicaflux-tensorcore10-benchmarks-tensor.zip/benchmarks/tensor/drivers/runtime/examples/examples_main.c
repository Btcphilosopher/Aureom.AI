/* Dispatcher: host_main() (called by TC08 cosim/cosim_main.cpp after reset) runs the example named by
 * $SFTC_EXAMPLE (or all of them) and prints EXAMPLE PASS / EXAMPLE FAIL per example. */
#include <string.h>
#include "ex_common.h"

typedef struct { const char *name; int (*fn)(void); } ex_t;
static const ex_t EX[] = {{"ex01_gemm4x4", ex01_gemm4x4}, {"ex02_tiled", ex02_tiled}, {"ex03_long_k", ex03_long_k},
                          {"ex04_gemv", ex04_gemv}, {"ex05_qgemm", ex05_qgemm}, {"ex06_async", ex06_async}};

int host_main(void)
{
    const char *sel = getenv("SFTC_EXAMPLE");
    int fails = 0;
    for (unsigned i = 0; i < sizeof EX / sizeof EX[0]; i++) {
        if (sel && *sel && strcmp(sel, EX[i].name)) continue;
        uint64_t t0 = tsu_host_cycles();
        printf("== %s\n", EX[i].name);
        int rc = EX[i].fn();
        printf("EXAMPLE %s %s (%llu host cycles)\n", rc ? "FAIL" : "PASS", EX[i].name,
               (unsigned long long)(tsu_host_cycles() - t0));
        fails += rc != 0;
    }
    return fails;
}
