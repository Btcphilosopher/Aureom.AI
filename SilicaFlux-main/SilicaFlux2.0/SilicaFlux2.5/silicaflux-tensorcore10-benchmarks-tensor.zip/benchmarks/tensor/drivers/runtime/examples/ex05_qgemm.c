/* Example 5: quantised GEMM -- INT8 operands, INT32 accumulation, per-tensor requantisation to INT8 in hardware
 * (TC05), then per-channel scales by SOFTWARE LOWERING: one command per output-channel group, addressing column
 * blocks of B and C through base offsets (the TC08 ABI has no per-channel table).  Needs ENABLE_QUANTIZATION. */
#include "ex_common.h"

#define M 32
#define N 32
#define K 256
static int8_t a[M * K], b[K * N], q[M * N], qg[M * 4];

int ex05_qgemm(void)
{
    sftc_ctx_t ctx;
    sftc_buf_t A, B, C;
    sftc_counters_t c0, c1, d;
    sftc_opts_t o = {0};
    tsu_record_t rec;
    long sat = 0;
    EX_CHECK(sftc_open(&ctx, EX_ARENA_LO, EX_ARENA_BYTES) == 0, "open");
    if (!ex_quant_build(&ctx)) { printf("  SKIPPED: this build has ENABLE_QUANTIZATION = 0\n"); return 0; }
    ex_fill(a, sizeof a, 31);
    ex_fill(b, sizeof b, 32);
    EX_CHECK(sftc_alloc(&ctx, &A, M, K, 1, 0, 4) == 0, "alloc A");
    EX_CHECK(sftc_alloc(&ctx, &B, K, N, 1, 0, 4) == 0, "alloc B");
    EX_CHECK(sftc_alloc(&ctx, &C, M, N, 1, 0, 4) == 0, "alloc C");
    sftc_pack_i8(&A, a, K);
    sftc_pack_i8(&B, b, N);
    o.out_int8 = 1; o.rm = TSU_RM_RNE; o.qmult = 1518500250; o.qshift = 44; o.qzp = -3; o.relu = 0;
    o.prefetch = ex_dbuf_build(&ctx);
    sftc_counters(&c0);
    int rc = sftc_gemm(&ctx, &A, &B, &C, &o, &rec);
    sftc_counters(&c1);
    EX_CHECK(rc == 0, "qgemm -> %d (%s)", rc, tsu_err_name(rc));
    sftc_read_i8(&C, q);
    long bad = sftc_check_q8(q, a, b, M, N, K, &o, &sat);
    sftc_counters_delta(&c0, &c1, &d);
    sftc_print_summary("  QGEMM per-tensor 32x32x256", &rec, &d, ex_rows(&ctx), ex_cols(&ctx));
    printf("  saturated elements: hardware SAT counter %u, reference %ld, record SAT flag %u\n", d.perf[18], sat, rec.sat);
    EX_CHECK(bad == 0, "%ld mismatching INT8 elements", bad);
    EX_CHECK((long)d.perf[18] == sat, "SAT counter");
    /* per-channel: 8 groups of 4 columns, each with its own multiplier */
    uint64_t t0 = tsu_host_cycles(), dev = 0;
    for (uint32_t g = 0; g < N / 4; g++) {
        sftc_buf_t Bg, Cg;
        sftc_opts_t og = o;
        og.qmult = 1518500250 - (int32_t)(g * 60000000);
        sftc_identify(&Bg, B.addr + 4 * g, K, 4, B.ld, 1);                 /* column block of B */
        sftc_identify(&Cg, C.addr + 4 * g, M, 4, C.ld, 1);                 /* column block of C */
        rc = sftc_gemm(&ctx, &A, &Bg, &Cg, &og, &rec);
        EX_CHECK(rc == 0, "group %u -> %d", g, rc);
        dev += rec.cycles;
        sftc_read_i8(&Cg, qg);
        int8_t bg[K * 4];
        for (uint32_t k = 0; k < K; k++) for (int j = 0; j < 4; j++) bg[k * 4 + j] = b[k * N + 4 * g + j];
        EX_CHECK(sftc_check_q8(qg, a, bg, M, 4, K, &og, NULL) == 0, "group %u mismatch", g);
    }
    printf("  QGEMM per-channel (8 groups, software N-split): device CYCLES sum %llu, host-observed %llu cycles\n",
           (unsigned long long)dev, (unsigned long long)(tsu_host_cycles() - t0));
    return 0;
}
