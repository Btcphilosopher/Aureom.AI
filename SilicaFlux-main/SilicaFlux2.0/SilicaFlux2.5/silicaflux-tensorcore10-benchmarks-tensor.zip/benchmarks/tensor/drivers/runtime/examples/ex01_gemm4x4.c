/* Example 1: the smallest useful command -- one 4x4x4 INT8 GEMM, end to end, with counters. */
#include "ex_common.h"

int ex01_gemm4x4(void)
{
    sftc_ctx_t ctx;
    sftc_buf_t A, B, C;
    sftc_counters_t c0, c1, d;
    tsu_record_t rec;
    int8_t a[16], b[16];
    int32_t c[16];
    int rc = sftc_open(&ctx, EX_ARENA_LO, EX_ARENA_BYTES);
    EX_CHECK(rc == 0, "sftc_open %d", rc);
    ex_fill(a, 16, 11);
    ex_fill(b, 16, 22);
    EX_CHECK(sftc_alloc(&ctx, &A, 4, 4, 1, 0, 4) == 0, "alloc A");             /* allocate */
    EX_CHECK(sftc_alloc(&ctx, &B, 4, 4, 1, 0, 4) == 0, "alloc B");
    EX_CHECK(sftc_alloc(&ctx, &C, 4, 4, 4, 0, 4) == 0, "alloc C");
    sftc_pack_i8(&A, a, 4);                                                     /* pack */
    sftc_pack_i8(&B, b, 4);
    sftc_counters(&c0);
    rc = sftc_gemm(&ctx, &A, &B, &C, NULL, &rec);                               /* submit + wait */
    sftc_counters(&c1);
    EX_CHECK(rc == 0, "sftc_gemm -> %d (%s)", rc, tsu_err_name(rc));
    sftc_read_i32(&C, c);                                                       /* read results */
    long bad = sftc_check_i32(c, a, b, 4, 4, 4);                                /* validate */
    sftc_counters_delta(&c0, &c1, &d);                                          /* counters */
    printf("  C = [%d %d %d %d; %d %d %d %d; ...]\n", c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7]);
    sftc_print_summary("  4x4x4", &rec, &d, ex_rows(&ctx), ex_cols(&ctx));
    EX_CHECK(bad == 0, "%ld mismatching elements", bad);
    EX_CHECK(d.perf[8] == 64, "MACS counter %u != 64", d.perf[8]);
    return 0;
}
