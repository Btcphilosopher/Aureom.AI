/*
 * SilicaFlux TensorCore benchmark lab -- minimal host runtime (see sftc_runtime.h).
 * Device-memory access goes through tsu_host_write / tsu_host_read (TC08 sw/include/tsu_host.h): on the simulation
 * backend they touch the memory model; on a bare-metal SoC they would be ordinary CPU stores / loads to shared SRAM.
 */
#include <stdio.h>
#include <string.h>

#include "sftc_runtime.h"
#include "tsu_host.h"

static const char *PERF_NAMES[SFTC_NPERF] = {
    "CYCLES", "BUSY", "CMD_ACCEPT", "CMD_DONE", "CMD_ERR", "GEMM_OK", "TILES", "CHUNKS", "MACS", "COMPUTE_CYC",
    "DMA_ACTIVE", "OVERLAP", "RD_WORDS", "WR_WORDS", "BUS_STALL", "DESC", "Q_FULL", "CPL_STALL", "SAT", "ABORTS"};
static const char *DMA_NAMES[SFTC_NDMA] = {
    "ACTIVE", "RD_BYTES", "WR_BYTES", "RD_REQ", "WR_REQ", "STALL", "SFB_STALL", "LOC_STALL", "OUT_SUM", "OUT_MAX",
    "BUF_WAIT", "DEP_WAIT", "XFER_ERR", "DESC_OK", "OVERLAP", "CPL_STALL", "LD_BUSY", "ST_BUSY"};

const char *sftc_perf_name(int i) { return (i >= 0 && i < SFTC_NPERF) ? PERF_NAMES[i] : "?"; }
const char *sftc_dma_name(int i) { return (i >= 0 && i < SFTC_NDMA) ? DMA_NAMES[i] : "?"; }

int sftc_open(sftc_ctx_t *ctx, uint32_t arena_lo, uint32_t arena_bytes)
{
    memset(ctx, 0, sizeof *ctx);
    ctx->arena_lo = arena_lo;
    ctx->arena_hi = arena_lo + arena_bytes;
    ctx->top = arena_lo;
    return tsu_init(&ctx->dev);
}

int sftc_alloc(sftc_ctx_t *ctx, sftc_buf_t *b, uint32_t rows, uint32_t cols, uint32_t esz, uint32_t ld_pad,
               uint32_t align)
{
    uint32_t a, bytes;
    if (rows == 0 || cols == 0 || (esz != 1 && esz != 4)) return SFTC_EARG;
    if (align == 0) align = (esz == 4) ? 4 : 1;
    if (esz == 4 && (align & 3u)) return SFTC_EARG;              /* INT32 C needs 4-aligned base and stride */
    if (esz == 4 && (ld_pad & 3u)) return SFTC_EARG;
    a = (ctx->top + align - 1u) & ~(align - 1u);
    b->addr = a;
    b->rows = rows;
    b->cols = cols;
    b->esz = esz;
    b->ld = cols * esz + ld_pad;
    bytes = (rows - 1u) * b->ld + cols * esz;
    if ((uint64_t)a + bytes + 16u > ctx->arena_hi) return SFTC_ENOMEM;
    ctx->top = a + bytes + 16u;                                  /* 16-byte gap: no two buffers share a word */
    return 0;
}

void sftc_identify(sftc_buf_t *b, uint32_t addr, uint32_t rows, uint32_t cols, uint32_t ld, uint32_t esz)
{
    b->addr = addr; b->rows = rows; b->cols = cols; b->ld = ld; b->esz = esz;
}

int sftc_pack_i8(const sftc_buf_t *b, const int8_t *src, uint32_t src_ld)
{
    uint32_t r;
    if (b->esz != 1 || src_ld < b->cols) return SFTC_EARG;
    for (r = 0; r < b->rows; r++) tsu_host_write(b->addr + r * b->ld, src + (size_t)r * src_ld, b->cols);
    return 0;
}

static void to_tsu_opts(const sftc_buf_t *A, const sftc_buf_t *B, const sftc_buf_t *C, const sftc_opts_t *o,
                        tsu_opts_t *t)
{
    memset(t, 0, sizeof *t);
    t->lda = A->ld; t->ldb = B->ld; t->ldc = C->ld;
    if (o) {
        t->kc = o->kc; t->out_int8 = o->out_int8; t->rm = o->rm; t->relu = o->relu; t->qmult = o->qmult;
        t->qshift = o->qshift; t->qzp = o->qzp; t->prefetch = o->prefetch; t->nmajor = o->nmajor;
    }
}

static int shapes_ok(const sftc_buf_t *A, const sftc_buf_t *B, const sftc_buf_t *C, const sftc_opts_t *o)
{
    uint32_t esz = (o && o->out_int8) ? 1u : 4u;
    return A->esz == 1 && B->esz == 1 && C->esz == esz && A->cols == B->rows && A->rows == C->rows &&
           B->cols == C->cols;
}

int sftc_submit(sftc_ctx_t *ctx, const sftc_buf_t *A, const sftc_buf_t *B, const sftc_buf_t *C,
                const sftc_opts_t *o, uint8_t *tid_out)
{
    uint32_t d[TSU_DESC_WORDS];
    tsu_opts_t t;
    uint8_t tid;
    int rc;
    if (!shapes_ok(A, B, C, o)) return SFTC_EARG;
    to_tsu_opts(A, B, C, o, &t);
    tid = ctx->dev.next_tid++;
    tsu_build_gemm(d, tid, A->addr, B->addr, C->addr, A->rows, B->cols, A->cols, &t);
    rc = tsu_check(&ctx->dev, d);                                /* host-side validation: same 15 rules as RTL */
    if (rc != 0) return TSU_EINVAL;
    do { rc = tsu_submit(&ctx->dev, d); } while (rc == TSU_EBUSY);
    if (tid_out) *tid_out = tid;
    return rc;
}

int sftc_wait(sftc_ctx_t *ctx, tsu_record_t *rec)
{
    int rc = tsu_wait(&ctx->dev, rec, 0u);
    if (rc != 0) return rc;
    if (rec->status != TSU_ST_OK) return rec->err ? (int)rec->err : TSU_EPROTO;
    return 0;
}

int sftc_gemm(sftc_ctx_t *ctx, const sftc_buf_t *A, const sftc_buf_t *B, const sftc_buf_t *C,
              const sftc_opts_t *o, tsu_record_t *rec)
{
    tsu_opts_t t;
    if (!shapes_ok(A, B, C, o)) return SFTC_EARG;
    to_tsu_opts(A, B, C, o, &t);
    return tensor_gemm(&ctx->dev, A->addr, B->addr, C->addr, A->rows, B->cols, A->cols, &t, rec);
}

int sftc_read_i32(const sftc_buf_t *C, int32_t *dst)
{
    uint32_t r, j;
    uint8_t row[4 * 65536];
    if (C->esz != 4 || C->cols > 65536u) return SFTC_EARG;
    for (r = 0; r < C->rows; r++) {
        tsu_host_read(C->addr + r * C->ld, row, 4u * C->cols);
        for (j = 0; j < C->cols; j++)
            dst[(size_t)r * C->cols + j] = (int32_t)((uint32_t)row[4 * j] | ((uint32_t)row[4 * j + 1] << 8) |
                                                     ((uint32_t)row[4 * j + 2] << 16) | ((uint32_t)row[4 * j + 3] << 24));
    }
    return 0;
}

int sftc_read_i8(const sftc_buf_t *C, int8_t *dst)
{
    uint32_t r;
    if (C->esz != 1) return SFTC_EARG;
    for (r = 0; r < C->rows; r++) tsu_host_read(C->addr + r * C->ld, dst + (size_t)r * C->cols, C->cols);
    return 0;
}

long sftc_check_i32(const int32_t *got, const int8_t *A, const int8_t *B, uint32_t M, uint32_t N, uint32_t K)
{
    long bad = 0;
    uint32_t i, j, k;
    for (i = 0; i < M; i++)
        for (j = 0; j < N; j++) {
            int64_t s = 0;
            for (k = 0; k < K; k++) s += (int64_t)A[(size_t)i * K + k] * (int64_t)B[(size_t)k * N + j];
            if (s != (int64_t)got[(size_t)i * N + j]) bad++;
        }
    return bad;
}

/* q = clamp(R_rm(acc * M / 2^S) + zp, -128, 127); max(q, zp) with ReLU.  Exact: |acc * M| < 2^62. */
int8_t sftc_requant_ref(int64_t acc, const sftc_opts_t *o, int *sat)
{
    /* exact 128-bit arithmetic (gcc / clang __int128): floor division, remainder 0 <= r < 2^S */
    __int128 p = (__int128)acc * (__int128)o->qmult, fl, r, y, half, D;
    unsigned s = o->qshift;
    int inc = 0;
    if (s == 0) {
        y = p;
    } else {
        D = (__int128)1 << s;
        fl = (p >= 0) ? p / D : -((-p + D - 1) / D);
        r = p - fl * D;
        half = D >> 1;
        switch (o->rm) {
        case TSU_RM_RDN: inc = 0; break;
        case TSU_RM_RUP: inc = r != 0; break;
        case TSU_RM_RTZ: inc = (r != 0) && (p < 0); break;
        case TSU_RM_RNE: inc = (r > half) || (r == half && (fl & 1)); break;
        default:         inc = (r > half) || (r == half && fl >= 0); break;   /* RMM */
        }
        y = fl + inc;
    }
    y += (__int128)o->qzp;
    *sat = (y < -128) || (y > 127);
    if (y < -128) y = -128;
    if (y > 127) y = 127;
    if (o->relu && y < o->qzp) y = o->qzp;
    return (int8_t)y;
}

long sftc_check_q8(const int8_t *got, const int8_t *A, const int8_t *B, uint32_t M, uint32_t N, uint32_t K,
                   const sftc_opts_t *o, long *saturated)
{
    long bad = 0, sats = 0;
    uint32_t i, j, k;
    for (i = 0; i < M; i++)
        for (j = 0; j < N; j++) {
            int64_t s = 0;
            int sat;
            for (k = 0; k < K; k++) s += (int64_t)A[(size_t)i * K + k] * (int64_t)B[(size_t)k * N + j];
            if (sftc_requant_ref(s, o, &sat) != got[(size_t)i * N + j]) bad++;
            sats += sat;
        }
    if (saturated) *saturated = sats;
    return bad;
}

void sftc_counters(sftc_counters_t *c)
{
    int i;
    for (i = 0; i < SFTC_NPERF; i++) c->perf[i] = tsu_counter(i);
    for (i = 0; i < SFTC_NDMA; i++) c->dma[i] = TSU_RD32(TSU_R_DMA_PERF0 + 4u * (uint32_t)i);
}

void sftc_counters_delta(const sftc_counters_t *a, const sftc_counters_t *b, sftc_counters_t *d)
{
    int i;
    for (i = 0; i < SFTC_NPERF; i++) d->perf[i] = b->perf[i] - a->perf[i];
    for (i = 0; i < SFTC_NDMA; i++) d->dma[i] = (i == 9) ? b->dma[i] : b->dma[i] - a->dma[i];   /* 9 = OUT_MAX */
}

void sftc_print_summary(const char *label, const tsu_record_t *r, const sftc_counters_t *d, uint32_t rows,
                        uint32_t cols)
{
    double util = r->cycles ? (double)d->perf[8] / ((double)r->cycles * rows * cols) : 0.0;
    printf("%s: CYCLES %u  MACS %u  utilisation %.1f %% of %ux%u  SFB2 rd %u wr %u words  tiles %u  chunks %u  "
           "bus-stall %u  overlap %u\n", label, r->cycles, d->perf[8], 100.0 * util, rows, cols, d->perf[12],
           d->perf[13], d->perf[6], d->perf[7], d->perf[14], d->perf[11]);
}
