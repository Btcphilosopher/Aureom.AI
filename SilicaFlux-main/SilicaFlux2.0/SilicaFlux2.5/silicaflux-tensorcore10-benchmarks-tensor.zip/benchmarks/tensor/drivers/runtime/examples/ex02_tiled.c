/* Example 2: a tiled GEMM larger than the array with non-multiple dimensions; the host matrices have their own
 * leading dimensions (packing), the device buffers use padded strides. */
#include "ex_common.h"

#define M 65
#define N 67
#define K 63
#define HLD_A 70        /* host leading dimensions (elements) */
#define HLD_B 72

static int8_t ha[M * HLD_A], hb[K * HLD_B], a[M * K], b[K * N];
static int32_t c[M * N];

int ex02_tiled(void)
{
    sftc_ctx_t ctx;
    sftc_buf_t A, B, C;
    sftc_counters_t c0, c1, d;
    sftc_opts_t o = {0};
    tsu_record_t rec;
    int rc = sftc_open(&ctx, EX_ARENA_LO, EX_ARENA_BYTES);
    EX_CHECK(rc == 0, "open");
    ex_fill(ha, sizeof ha, 5);
    ex_fill(hb, sizeof hb, 6);
    for (int i = 0; i < M; i++) for (int k = 0; k < K; k++) a[i * K + k] = ha[i * HLD_A + k];
    for (int k = 0; k < K; k++) for (int j = 0; j < N; j++) b[k * N + j] = hb[k * HLD_B + j];
    EX_CHECK(sftc_alloc(&ctx, &A, M, K, 1, 1, 1) == 0, "alloc A");   /* LDA = K + 1, unaligned rows */
    EX_CHECK(sftc_alloc(&ctx, &B, K, N, 1, 0, 4) == 0, "alloc B");
    EX_CHECK(sftc_alloc(&ctx, &C, M, N, 4, 8, 4) == 0, "alloc C");   /* LDC = 4N + 8 */
    sftc_pack_i8(&A, ha, HLD_A);
    sftc_pack_i8(&B, hb, HLD_B);
    o.prefetch = ex_dbuf_build(&ctx);
    sftc_counters(&c0);
    rc = sftc_gemm(&ctx, &A, &B, &C, &o, &rec);
    sftc_counters(&c1);
    EX_CHECK(rc == 0, "sftc_gemm -> %d (%s)", rc, tsu_err_name(rc));
    sftc_read_i32(&C, c);
    long bad = sftc_check_i32(c, a, b, M, N, K);
    sftc_counters_delta(&c0, &c1, &d);
    sftc_print_summary("  65x67x63", &rec, &d, ex_rows(&ctx), ex_cols(&ctx));
    EX_CHECK(bad == 0, "%ld mismatching elements", bad);
    EX_CHECK(d.perf[8] == (uint32_t)(M * N * K), "MACS %u", d.perf[8]);
    return 0;
}
