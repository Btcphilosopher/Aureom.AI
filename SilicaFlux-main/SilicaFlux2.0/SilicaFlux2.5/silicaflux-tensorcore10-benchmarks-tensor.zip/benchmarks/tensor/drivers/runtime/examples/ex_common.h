/* Shared helpers of the runtime examples (simulation backend: TC08 cosim/cosim_main.cpp, 1 MiB at 0x1000_0000). */
#ifndef EX_COMMON_H
#define EX_COMMON_H
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "sftc_runtime.h"
#include "tsu_host.h"

#define EX_ARENA_LO    0x10000100u
#define EX_ARENA_BYTES ((1u << 20) - 0x200u)

static inline uint32_t ex_rnd(uint32_t *s) { *s ^= *s << 13; *s ^= *s >> 17; *s ^= *s << 5; return *s; }
static inline void ex_fill(int8_t *p, size_t n, uint32_t seed)
{
    uint32_t s = seed ? seed : 1u;
    for (size_t i = 0; i < n; i++) p[i] = (int8_t)ex_rnd(&s);
}
static inline int ex_quant_build(const sftc_ctx_t *c) { return (int)((c->dev.info >> 24) & 1u); }
static inline int ex_dbuf_build(const sftc_ctx_t *c) { return (int)((c->dev.info >> 25) & 1u); }
static inline uint32_t ex_rows(const sftc_ctx_t *c) { return (c->dev.info >> 8) & 0xFFu; }
static inline uint32_t ex_cols(const sftc_ctx_t *c) { return (c->dev.info >> 16) & 0xFFu; }
#define EX_CHECK(cond, ...) do { if (!(cond)) { printf("  CHECK FAILED: " __VA_ARGS__); printf("\n"); return 1; } } while (0)

int ex01_gemm4x4(void);
int ex02_tiled(void);
int ex03_long_k(void);
int ex04_gemv(void);
int ex05_qgemm(void);
int ex06_async(void);
#endif
