/*
 * SilicaFlux TensorCore benchmark lab -- minimal host runtime ("sftc").  Aureom.AI | SilicaFlux-HPC
 *
 * A thin layer over TENSORCORE 08's verified bare-metal driver (third_party/silicaflux-tensorcore08/sw/tsu_driver.c,
 * used unmodified) that adds what a benchmark or application needs around a single GEMM command:
 *
 *   buffers    sftc_alloc()      allocate a row-major matrix in device-visible memory (bump arena, aligned)
 *              sftc_identify()   describe a matrix that already lives at a known device address
 *   packing    sftc_pack_i8()    copy a host INT8 matrix (any host leading dimension) into a device buffer
 *   submit     sftc_submit()     validate on the host (tsu_check), build and ring the doorbell -- asynchronous
 *   wait       sftc_wait()       collect the next completion record (in submission order)
 *   one call   sftc_gemm()       tensor_gemm(): validate, submit, wait, check the record
 *   results    sftc_read_i32() / sftc_read_i8()   copy C back to the host (row by row, honouring LDC)
 *   validate   sftc_check_i32() / sftc_check_q8() compare with a plain C reference (exact INT32; TC05 requant contract)
 *   counters   sftc_counters()   PERF[0..19] and DMA_PERF[0..17] through the register page (host-visible only)
 *
 * Backends: the register hooks of tsu_driver.h.  In this lab the runtime runs on the SIMULATION BACKEND
 * (TC08 cosim/cosim_main.cpp: every register access is one register-bus cycle on the Verilated RTL; device memory is
 * a C++ SFB2 slave model).  No PCIe / OS driver exists; no FPGA board was available; there is no integration with
 * PyTorch, TensorFlow, ONNX Runtime or Triton.
 */
#ifndef SFTC_RUNTIME_H
#define SFTC_RUNTIME_H

#include <stdint.h>
#include "tsu_driver.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SFTC_ENOMEM (-20)   /* device arena exhausted */
#define SFTC_EARG   (-21)   /* bad buffer shape / element size */

typedef struct {
    tsu_dev_t dev;
    uint32_t  arena_lo, arena_hi, top;   /* device byte addresses of the bump arena */
    uint32_t  rows_flags;                /* reserved */
} sftc_ctx_t;

typedef struct {
    uint32_t addr;                       /* device byte address of element [0][0] */
    uint32_t rows, cols;                 /* logical shape */
    uint32_t ld;                         /* leading dimension in BYTES (row stride) */
    uint32_t esz;                        /* element size in bytes: 1 (INT8) or 4 (INT32) */
} sftc_buf_t;

typedef struct {                         /* GEMM options; zero-initialise for the INT32 default */
    int      out_int8;                   /* 1: requantised INT8 output (needs ENABLE_QUANTIZATION) */
    int      rm, relu;                   /* INT8: rounding mode (TSU_RM_*), ReLU at the zero-point */
    int32_t  qmult;                      /* INT8: multiplier M */
    uint8_t  qshift;                     /* INT8: shift S */
    int8_t   qzp;                        /* INT8: output zero-point */
    int      prefetch;                   /* double-buffered overlap (needs ENABLE_DOUBLE_BUFFERING) */
    int      nmajor;                     /* N-major tile order */
    uint32_t kc;                         /* K chunk (0 = TILE_K) */
} sftc_opts_t;

#define SFTC_NPERF 20
#define SFTC_NDMA  18
typedef struct {
    uint32_t perf[SFTC_NPERF];           /* TSU_PC_* (docs/03_REGISTER_MAP.md sec. 1) */
    uint32_t dma[SFTC_NDMA];             /* TDMA_PC_* (TENSORCORE 07 adapter) */
} sftc_counters_t;

int  sftc_open(sftc_ctx_t *ctx, uint32_t arena_lo, uint32_t arena_bytes);
int  sftc_alloc(sftc_ctx_t *ctx, sftc_buf_t *b, uint32_t rows, uint32_t cols, uint32_t esz, uint32_t ld_pad,
                uint32_t align);
void sftc_identify(sftc_buf_t *b, uint32_t addr, uint32_t rows, uint32_t cols, uint32_t ld, uint32_t esz);
int  sftc_pack_i8(const sftc_buf_t *b, const int8_t *src, uint32_t src_ld);
int  sftc_submit(sftc_ctx_t *ctx, const sftc_buf_t *A, const sftc_buf_t *B, const sftc_buf_t *C,
                 const sftc_opts_t *o, uint8_t *tid_out);
int  sftc_wait(sftc_ctx_t *ctx, tsu_record_t *rec);
int  sftc_gemm(sftc_ctx_t *ctx, const sftc_buf_t *A, const sftc_buf_t *B, const sftc_buf_t *C,
               const sftc_opts_t *o, tsu_record_t *rec);
int  sftc_read_i32(const sftc_buf_t *C, int32_t *dst);          /* dst: rows x cols, dense */
int  sftc_read_i8(const sftc_buf_t *C, int8_t *dst);
long sftc_check_i32(const int32_t *got, const int8_t *A, const int8_t *B, uint32_t M, uint32_t N, uint32_t K);
long sftc_check_q8(const int8_t *got, const int8_t *A, const int8_t *B, uint32_t M, uint32_t N, uint32_t K,
                   const sftc_opts_t *o, long *saturated);
int8_t sftc_requant_ref(int64_t acc, const sftc_opts_t *o, int *sat);
void sftc_counters(sftc_counters_t *c);
void sftc_counters_delta(const sftc_counters_t *a, const sftc_counters_t *b, sftc_counters_t *d);
const char *sftc_perf_name(int i);
const char *sftc_dma_name(int i);
void sftc_print_summary(const char *label, const tsu_record_t *r, const sftc_counters_t *d, uint32_t rows,
                        uint32_t cols);

#ifdef __cplusplus
}
#endif
#endif
