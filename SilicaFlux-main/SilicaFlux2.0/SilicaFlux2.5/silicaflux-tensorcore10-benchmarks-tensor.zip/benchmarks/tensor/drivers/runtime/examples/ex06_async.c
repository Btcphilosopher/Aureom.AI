/* Example 6: asynchronous submission.  Four commands are rung back to back (the command queue holds 4), then the
 * four records are collected in order -- versus submit + wait one at a time.  Host-observed cycles include every
 * register access of the driver on the simulation backend (one register-bus cycle each). */
#include "ex_common.h"

static int8_t a[16 * 64], b[64 * 16];
static int32_t c[16 * 16];

int ex06_async(void)
{
    sftc_ctx_t ctx;
    sftc_buf_t A, B, C[4];
    sftc_opts_t o = {0};
    tsu_record_t rec;
    uint64_t t0, t_async, t_sync;
    EX_CHECK(sftc_open(&ctx, EX_ARENA_LO, EX_ARENA_BYTES) == 0, "open");
    ex_fill(a, sizeof a, 41);
    ex_fill(b, sizeof b, 42);
    EX_CHECK(sftc_alloc(&ctx, &A, 16, 64, 1, 0, 4) == 0, "A");
    EX_CHECK(sftc_alloc(&ctx, &B, 64, 16, 1, 0, 4) == 0, "B");
    for (int i = 0; i < 4; i++) EX_CHECK(sftc_alloc(&ctx, &C[i], 16, 16, 4, 0, 4) == 0, "C");
    sftc_pack_i8(&A, a, 64);
    sftc_pack_i8(&B, b, 16);
    o.prefetch = ex_dbuf_build(&ctx);
    t0 = tsu_host_cycles();
    for (int i = 0; i < 4; i++) EX_CHECK(sftc_submit(&ctx, &A, &B, &C[i], &o, NULL) == 0, "submit %d", i);
    for (int i = 0; i < 4; i++) {
        EX_CHECK(sftc_wait(&ctx, &rec) == 0, "wait %d", i);
        EX_CHECK(rec.tid == (uint8_t)(ctx.dev.next_tid - 4 + i), "record order");
    }
    t_async = tsu_host_cycles() - t0;
    t0 = tsu_host_cycles();
    for (int i = 0; i < 4; i++) EX_CHECK(sftc_gemm(&ctx, &A, &B, &C[i], &o, &rec) == 0, "sync %d", i);
    t_sync = tsu_host_cycles() - t0;
    for (int i = 0; i < 4; i++) {
        sftc_read_i32(&C[i], c);
        EX_CHECK(sftc_check_i32(c, a, b, 16, 16, 64) == 0, "C[%d] mismatch", i);
    }
    printf("  4 x GEMM 16x16x64: back-to-back submission %llu host cycles, submit+wait each %llu host cycles\n",
           (unsigned long long)t_async, (unsigned long long)t_sync);
    return 0;
}
