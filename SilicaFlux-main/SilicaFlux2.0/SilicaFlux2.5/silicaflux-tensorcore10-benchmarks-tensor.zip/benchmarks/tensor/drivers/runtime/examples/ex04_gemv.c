/* Example 4: matrix-vector y = A x as a GEMM with N = 1, and x^T A with M = 1. */
#include "ex_common.h"

static int8_t a[256 * 256], x[256];
static int32_t y[256];

int ex04_gemv(void)
{
    sftc_ctx_t ctx;
    sftc_buf_t A, X, Y;
    sftc_counters_t c0, c1, d;
    sftc_opts_t o = {0};
    tsu_record_t rec;
    EX_CHECK(sftc_open(&ctx, EX_ARENA_LO, EX_ARENA_BYTES) == 0, "open");
    ex_fill(a, sizeof a, 7);
    ex_fill(x, sizeof x, 8);
    o.prefetch = ex_dbuf_build(&ctx);
    /* y = A x : M = 256, N = 1, K = 256 */
    EX_CHECK(sftc_alloc(&ctx, &A, 256, 256, 1, 0, 4) == 0, "alloc A");
    EX_CHECK(sftc_alloc(&ctx, &X, 256, 1, 1, 0, 4) == 0, "alloc x");
    EX_CHECK(sftc_alloc(&ctx, &Y, 256, 1, 4, 0, 4) == 0, "alloc y");
    sftc_pack_i8(&A, a, 256);
    sftc_pack_i8(&X, x, 1);
    sftc_counters(&c0);
    int rc = sftc_gemm(&ctx, &A, &X, &Y, &o, &rec);
    sftc_counters(&c1);
    EX_CHECK(rc == 0, "gemv -> %d (%s)", rc, tsu_err_name(rc));
    sftc_read_i32(&Y, y);
    sftc_counters_delta(&c0, &c1, &d);
    sftc_print_summary("  GEMV 256x1x256", &rec, &d, ex_rows(&ctx), ex_cols(&ctx));
    EX_CHECK(sftc_check_i32(y, a, x, 256, 1, 256) == 0, "gemv mismatch");
    /* x^T A : M = 1, N = 256, K = 256 (x as a 1 x 256 row) */
    sftc_buf_t XR, YR;
    EX_CHECK(sftc_alloc(&ctx, &XR, 1, 256, 1, 0, 4) == 0, "alloc xr");
    EX_CHECK(sftc_alloc(&ctx, &YR, 1, 256, 4, 0, 4) == 0, "alloc yr");
    sftc_pack_i8(&XR, x, 256);
    sftc_counters(&c0);
    rc = sftc_gemm(&ctx, &XR, &A, &YR, &o, &rec);
    sftc_counters(&c1);
    EX_CHECK(rc == 0, "vecmat -> %d", rc);
    sftc_read_i32(&YR, y);
    sftc_counters_delta(&c0, &c1, &d);
    sftc_print_summary("  VECMAT 1x256x256", &rec, &d, ex_rows(&ctx), ex_cols(&ctx));
    EX_CHECK(sftc_check_i32(y, x, a, 1, 256, 256) == 0, "vecmat mismatch");
    return 0;
}
