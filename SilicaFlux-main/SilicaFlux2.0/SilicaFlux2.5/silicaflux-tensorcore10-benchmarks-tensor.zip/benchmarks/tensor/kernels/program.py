"""Benchmark program builder: places INT8 operands in the modelled memory, encodes GEMM descriptors (TC08 ABI v2),
computes the expected results with the lab's independent reference, and emits the bench testbench inputs.

Layout: operands are placed first (from MEM_BASE + 0x100), then every C buffer, so all outputs form one contiguous
region that is dumped and checked completely -- including the bytes BETWEEN and AROUND the C rows, which must keep
their 0xA5 sentinel (a stray write anywhere in the output region is detected).

Host program (drivers/tb/tb_tensor_bench.sv): `W 0`, then per command `C <12 words>`, `S <n>` (wait for its
record), `W <n>` (counter snapshot), finally `Q`.  Commands therefore run one at a time with an idle gap in
between -- every per-command counter delta and CYCLES value is isolated from its neighbours.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from drivers.sim import MEM_BASE, Hw, tsu_ref
from reference import ref_int8 as R

A = tsu_ref.A                     # TC08 generated ABI constants (model/tsu_abi.py)
SENTINEL = 0xA5


@dataclass
class Cmd:
    gemm: "tsu_ref.Gemm"
    expect: np.ndarray            # (M, N) int64 (INT32 out) or int8 (INT8 out)
    sat_expect: int               # expected number of saturated INT8 elements (0 for INT32 output)
    label: str
    c_bytes: int = 0
    meta: dict = field(default_factory=dict)


class BenchProgram:
    def __init__(self, h: Hw):
        self.h = h
        self.cfg = h.tsu_cfg()
        self.size = h.mem_bytes
        self.img = bytearray(h.mem_bytes)
        self.top = MEM_BASE + 0x100
        self.cmds: list[Cmd] = []
        self.pending: list[dict] = []
        self.c_lo = self.c_hi = None
        self.datasets: dict[str, str] = {}

    # ------------------------------------------------------------------------------------------- memory
    def alloc(self, size: int, align: int = 4) -> int:
        a = (self.top + align - 1) // align * align
        self.top = a + size
        if self.top > MEM_BASE + self.size - 64:
            raise MemoryError(f"workload does not fit in the {self.size >> 20} MiB memory model")
        return a

    def put_matrix(self, a: np.ndarray, ld: int | None = None, align: int = 4, pad_byte: int = 0x3C) -> tuple[int, int]:
        """Place a row-major int8 matrix; returns (address, leading dimension in bytes)."""
        rows, cols = a.shape
        ld = cols if ld is None else ld
        assert ld >= cols
        addr = self.alloc((rows - 1) * ld + cols, align)
        o = addr - MEM_BASE
        raw = a.astype(np.int8).view(np.uint8)
        if ld == cols:
            self.img[o:o + rows * cols] = raw.tobytes()
        else:
            buf = np.full((rows, ld), pad_byte, np.uint8)
            buf[:, :cols] = raw
            self.img[o:o + (rows - 1) * ld + cols] = buf.tobytes()[:(rows - 1) * ld + cols]
        return addr, ld

    # ------------------------------------------------------------------------------------------- commands
    def gemm(self, a_addr: int, lda: int, b_addr: int, ldb: int, M: int, N: int, K: int, expect: np.ndarray,
             label: str, ofmt: int = A.OFMT_INT32, ldc_pad: int = 0, flags: int = 0, kc: int = 0, rm: int = 0,
             relu: int = 0, qmult: int = 0, qshift: int = 0, qzp: int = 0, sat: int = 0, meta=None):
        esz = 1 if ofmt == A.OFMT_INT8 else 4
        ldc = esz * N + ldc_pad
        self.pending.append(dict(a=a_addr, lda=lda, b=b_addr, ldb=ldb, M=M, N=N, K=K, ldc=ldc, esz=esz, expect=expect,
                                 label=label, ofmt=ofmt, flags=flags, kc=kc, rm=rm, relu=relu, qmult=qmult,
                                 qshift=qshift, qzp=qzp, sat=sat, meta=meta or {}))

    def finalize(self):
        """Allocate every C buffer after the operands; fill the whole output region with the sentinel."""
        self.top = (self.top + 63) // 64 * 64 + 64
        self.c_lo = self.top - 64
        for p in self.pending:
            c = self.alloc((p["M"] - 1) * p["ldc"] + p["esz"] * p["N"], 4 if p["esz"] == 4 else 1)
            self.top += 16                                   # sentinel gap between consecutive C buffers
            g = tsu_ref.Gemm(p["a"], p["b"], c, p["M"], p["N"], p["K"], p["lda"], p["ldb"], p["ldc"], kc=p["kc"],
                             tid=len(self.cmds) & 0xFF, flags=p["flags"], ofmt=p["ofmt"], rm=p["rm"], relu=p["relu"],
                             qmult=p["qmult"] & 0xFFFF_FFFF, qshift=p["qshift"], qzp=p["qzp"] & 0xFF)
            code = tsu_ref.validate(g.words(), self.cfg)
            if code != A.E_NONE:
                raise ValueError(f"{p['label']}: descriptor would be rejected by validation (code {code:#x})")
            self.cmds.append(Cmd(g, p["expect"], p["sat"], p["label"], p["M"] * p["N"] * p["esz"], p["meta"]))
        self.c_hi = self.top + 64
        lo, hi = self.c_lo - MEM_BASE, self.c_hi - MEM_BASE
        self.img[lo:hi] = bytes([SENTINEL]) * (hi - lo)

    # ------------------------------------------------------------------------------------------- emit
    def write(self, d: Path) -> dict:
        d.mkdir(parents=True, exist_ok=True)
        used = self.c_hi - MEM_BASE
        (d / "mem_init.hex").write_text(bytes(self.img[:used]).hex("\n") + "\n")
        ops = ["W 0"]
        for i, c in enumerate(self.cmds):
            ops.append("C " + " ".join(f"{w:08x}" for w in c.gemm.words()))
            ops.append(f"S {i + 1}")
            ops.append(f"W {i + 1}")
        (d / "prog.txt").write_text("\n".join(ops + ["Q"]) + "\n")
        plus = dict(dump_lo=self.c_lo - MEM_BASE, dump_hi=self.c_hi - MEM_BASE - 1)
        return plus

    # ------------------------------------------------------------------------------------------- check
    def check(self, final: bytearray) -> dict:
        """Compare every C element with the reference and every non-C byte of the output region with the sentinel."""
        exp = bytearray([SENTINEL]) * (self.c_hi - self.c_lo)
        res = []
        for c in self.cmds:
            g = c.gemm
            if g.ofmt == A.OFMT_INT8:
                rows = np.asarray(c.expect, dtype=np.int8).view(np.uint8)
            else:
                rows = np.asarray(c.expect, dtype=np.int64).astype("<i4").view(np.uint8).reshape(g.m, g.n * 4)
            for r in range(g.m):
                o = g.c + r * g.ldc - self.c_lo
                exp[o:o + rows.shape[1]] = rows[r].tobytes()
        diff = np.flatnonzero(np.frombuffer(bytes(final), np.uint8) != np.frombuffer(bytes(exp), np.uint8))
        # attribute mismatches to commands
        per_cmd = []
        for c in self.cmds:
            g = c.gemm
            lo = g.c - self.c_lo
            hi = lo + (g.m - 1) * g.ldc + g.n * g.esz
            nbad = int(((diff >= lo) & (diff < hi)).sum())
            got = np.frombuffer(bytes(final[lo:hi]), np.uint8)
            if g.ofmt == A.OFMT_INT8:
                full = np.zeros(g.m * g.ldc, np.uint8)
                full[:hi - lo] = got
                gm = full.reshape(g.m, g.ldc)[:, :g.n].view(np.int8).astype(np.int64)
                em = np.asarray(c.expect, dtype=np.int64)
                maxerr = int(np.abs(gm - em).max()) if gm.size else 0
            else:
                maxerr = None
            per_cmd.append(dict(label=c.label, elements=g.m * g.n, bytes=c.c_bytes, mismatched_bytes=nbad,
                                max_abs_err=maxerr))
        return dict(checked_bytes=len(exp), c_bytes=sum(c.c_bytes for c in self.cmds), mismatched_bytes=int(diff.size),
                    first_mismatch=(hex(self.c_lo + int(diff[0])) if diff.size else None), per_cmd=per_cmd,
                    ok=diff.size == 0)
