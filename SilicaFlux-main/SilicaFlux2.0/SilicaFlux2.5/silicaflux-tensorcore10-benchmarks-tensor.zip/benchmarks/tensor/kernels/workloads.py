"""Executable benchmark kernels.  Each builder turns a workload specification into a BenchProgram (operands in
memory, descriptors, expected results) plus metadata used by the analysis (useful MACs, ideal traffic, host-side
software-lowering cost).

  gemm     dense C = A x B, INT8 x INT8 -> INT32 (A, B, C mandatory workloads; also the scaling sweeps)
  gemv     matrix-vector y = A x, issued as GEMM with N = 1 (D)
  vecmat   row vector x matrix, GEMM with M = 1 (D, contrast)
  qgemm    INT8 output through TC05 requantisation: per-tensor in hardware; per-channel scales and INT32 bias by
           SOFTWARE LOWERING (N-split into one command per channel group; bias folded into K) -- the TC08 ABI
           exposes neither, so these are labelled as lowering, not hardware features (E)
  conv     2-D convolution lowered to GEMM by HOST im2col (F): no native convolution hardware exists
"""
from __future__ import annotations

import numpy as np

from datasets import store
from drivers.sim import Hw
from kernels.program import A, BenchProgram
from reference import ref_int8 as R

FL_PF = 1 << A.FL_PREFETCH
FL_NM = 1 << A.FL_NMAJOR
NAIVE_LIMIT = 1 << 18             # cross-check the numpy reference with the pure-Python loop up to this many MACs


def _flags(h: Hw, prm: dict) -> int:
    f = 0
    pf = prm.get("prefetch")
    if (pf is None and h.dbuf) or pf:
        f |= FL_PF
    if prm.get("nmajor"):
        f |= FL_NM
    return f


def _ref(a, b):
    c = R.gemm_numpy(a, b)
    if a.shape[0] * a.shape[1] * b.shape[1] <= NAIVE_LIMIT:
        if not np.array_equal(c, R.gemm_naive(a, b)):
            raise AssertionError("reference disagreement: numpy vs naive loop")
    return c


def _operand(p: BenchProgram, dist, rows, cols, seed, tag):
    a, sha = store.get(dist, rows, cols, seed)
    p.datasets[tag] = f"{store.spec_id(dist, rows, cols, seed)}:{sha[:16]}"
    return a


def _ideal(M, N, K, esz):
    """Compulsory traffic: each input element read once, each output element written once."""
    return M * K + K * N + esz * M * N


def build(kind: str, prm: dict, h: Hw, seed: int):
    p = BenchProgram(h)
    meta = dict(kind=kind)
    if kind in ("gemm", "gemv", "vecmat"):
        M, N, K = prm.get("M", 1), prm.get("N", 1), prm["K"]
        if kind == "gemv":
            N = 1
        if kind == "vecmat":
            M = 1
        a = _operand(p, prm.get("da", "uniform"), M, K, seed, "A")
        b = _operand(p, prm.get("db", "uniform"), K, N, seed + 1000, "B")
        aa, lda = p.put_matrix(a, K + prm.get("lda_pad", 0), prm.get("a_align", 4))
        ba, ldb = p.put_matrix(b, N + prm.get("ldb_pad", 0), prm.get("b_align", 4))
        c = _ref(a, b)
        for _ in range(prm.get("repeat", 1)):
            p.gemm(aa, lda, ba, ldb, M, N, K, c, f"{kind} {M}x{N}x{K}", flags=_flags(h, prm), kc=prm.get("kc", 0),
                   ldc_pad=prm.get("ldc_pad", 0))
        reps = prm.get("repeat", 1)
        meta.update(M=M, N=N, K=K, macs=M * N * K * reps, out="INT32", commands=reps,
                    ideal_bytes=_ideal(M, N, K, 4) * reps, host_bytes=0, lowering=None)
    elif kind == "qgemm":
        M, N, K = prm["M"], prm["N"], prm["K"]
        a = _operand(p, prm.get("da", "act"), M, K, seed, "A")
        b = _operand(p, prm.get("db", "normal16"), K, N, seed + 1000, "B")
        rm, relu, zp = prm.get("rm", 0), int(prm.get("relu", 0)), prm.get("zp", 0)
        bias_mode, mode = prm.get("bias"), prm.get("mode", "per_tensor")
        host_bytes = 0
        acc = R.gemm_numpy(a, b)
        a_hw, b_hw, k_hw = a, b, K
        bias = None
        if bias_mode == "kaug":
            rng = np.random.default_rng(seed + 77)
            bias = rng.integers(-12000, 12001, N)
            ac, br = R.bias_rows(bias, 2)
            a_hw = np.concatenate([a, np.broadcast_to(ac, (M, 2))], axis=1).astype(np.int8)
            b_hw = np.concatenate([b, br], axis=0).astype(np.int8)
            k_hw = K + 2
            acc = acc + bias[None, :]
            host_bytes = M * (K + 2) + 2 * N                  # host re-packs A with two extra columns + 2 B rows
            if not np.array_equal(_ref(a_hw, b_hw), acc):
                raise AssertionError("bias lowering reference mismatch")
        std = max(1.0, float(acc.std()))
        base_scale = prm.get("scale", 127.0 / (3.0 * std))
        aa, lda = p.put_matrix(a_hw, k_hw)
        ba, ldb = p.put_matrix(b_hw, N)
        fl = _flags(h, prm)
        if mode == "per_tensor":
            mlt, sh = R.quantize_multiplier(base_scale)
            if "mult" in prm:
                mlt, sh = prm["mult"], prm["shift"]
            q, sat = R.requant(acc, mlt, sh, zp, rm, bool(relu))
            p.gemm(aa, lda, ba, ldb, M, N, k_hw, q, f"qgemm {M}x{N}x{k_hw}", ofmt=A.OFMT_INT8, flags=fl, rm=rm,
                   relu=relu, qmult=mlt, qshift=sh, qzp=zp, sat=int(sat.sum()))
            sats = int(sat.sum())
            ncmd = 1
        else:                                                 # per-channel scales by N-split (software lowering)
            g = prm.get("group", 1)
            scales = base_scale * (0.5 + np.arange(N) / max(1, N - 1))
            sats = 0
            ncmd = 0
            for n0 in range(0, N, g):
                gw = min(g, N - n0)
                mlt, sh = R.quantize_multiplier(float(scales[n0]))  # one scale per group (group = channel block)
                q, sat = R.requant(acc[:, n0:n0 + gw], mlt, sh, zp, rm, bool(relu))
                sats += int(sat.sum())
                p.gemm(aa, lda, ba + n0, ldb, M, gw, k_hw, q, f"qgemm-ch{n0} {M}x{gw}x{k_hw}", ofmt=A.OFMT_INT8,
                       flags=fl, rm=rm, relu=relu, qmult=mlt, qshift=sh, qzp=zp, sat=int(sat.sum()),
                       meta=dict(n0=n0))
                ncmd += 1
        meta.update(M=M, N=N, K=k_hw, K_math=K, macs=M * N * k_hw, useful_macs=M * N * K, out="INT8", commands=ncmd,
                    ideal_bytes=_ideal(M, N, K, 1), host_bytes=host_bytes, saturated_expected=sats,
                    lowering=("bias folded into K (+2)" if bias is not None else None) if mode == "per_tensor" else
                    f"per-channel scales by N-split, group {prm.get('group', 1)}" +
                    (" + bias folded into K (+2)" if bias is not None else ""), rm=rm, relu=relu, zp=zp)
    elif kind == "conv":
        H, W, C, CO = prm["H"], prm["W"], prm["C"], prm["CO"]
        KH, KW, st, pd = prm["KH"], prm["KW"], prm.get("stride", 1), prm.get("pad", 0)
        x = _operand(p, prm.get("dx", "act"), H * W, C, seed, "X").reshape(H, W, C)
        w = _operand(p, prm.get("dw", "normal16"), KH * KW * C, CO, seed + 1000, "W")
        cols, oh, ow = R.im2col_nhwc(x, KH, KW, st, pd)
        direct = R.conv2d_direct(x, w.reshape(KH, KW, C, CO), st, pd).reshape(oh * ow, CO)
        c = _ref(cols, w)
        if not np.array_equal(c, direct):
            raise AssertionError("im2col GEMM reference != direct convolution")
        aa, lda = p.put_matrix(cols, cols.shape[1])
        ba, ldb = p.put_matrix(w, CO)
        M, K, N = oh * ow, KH * KW * C, CO
        p.gemm(aa, lda, ba, ldb, M, N, K, c, f"conv {H}x{W}x{C}->{CO} k{KH}x{KW} s{st} p{pd}", flags=_flags(h, prm))
        in_bytes = H * W * C
        meta.update(M=M, N=N, K=K, macs=M * N * K, out="INT32", commands=1,
                    ideal_bytes=in_bytes + K * N + 4 * M * N,      # convolution's own compulsory traffic
                    gemm_ideal_bytes=_ideal(M, N, K, 4),
                    host_bytes=in_bytes + M * K,                  # host im2col: read input, write the patch matrix
                    im2col_bytes=M * K, input_bytes=in_bytes, expansion=M * K / in_bytes, OH=oh, OW=ow,
                    lowering="host im2col -> GEMM (software lowering; no native convolution hardware)")
    else:
        raise ValueError(f"unknown workload kind {kind}")
    p.finalize()
    meta["datasets"] = dict(p.datasets)
    return p, meta
