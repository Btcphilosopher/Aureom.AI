#!/usr/bin/env python3
"""SilicaFlux TensorCore benchmark lab -- runner.

  bench.py run <EXP>... [--jobs N]     run experiments (configs/experiments/<EXP>.json); writes run records
  bench.py reproduce <RUN_ID>           re-execute one recorded run and compare cycles / counters / outputs
  bench.py validate                     validate every run record against schema/run_record.schema.json
  bench.py list                         list experiments and their points

Every run: build the workload (kernels/workloads.py) -> Verilator simulation of TC08's unmodified RTL through the
bench testbench -> output check against the lab reference -> counter deltas per command -> cross-checks ->
run record (reports/runs/<id>.json) + raw counter / event dumps (reports/counters/).
"""
from __future__ import annotations

import argparse
import itertools
import json
import shutil
import sys
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

LAB = Path(__file__).resolve().parent
sys.path.insert(0, str(LAB))

from analysis import counters as C  # noqa: E402
from datasets import store  # noqa: E402
from drivers import sim  # noqa: E402
from kernels import workloads as W  # noqa: E402

EXP_DIR = LAB / "configs" / "experiments"
RUNS = LAB / "reports" / "runs"
CNT = LAB / "reports" / "counters"
LOGS = LAB / "reports" / "logs"
_TOOLS = None


def tools():
    global _TOOLS
    if _TOOLS is None:
        _TOOLS = sim.tool_versions()
    return _TOOLS


def load_exp(name: str) -> dict:
    return json.loads((EXP_DIR / f"{name}.json").read_text())


def points(exp: dict) -> list[dict]:
    pts = []
    fixed = exp.get("fixed", {})
    grid = exp.get("grid", {})
    if grid:
        keys = list(grid)
        for combo in itertools.product(*[grid[k] for k in keys]):
            p = dict(fixed)
            p.update(dict(zip(keys, combo)))
            pts.append(p)
    for p in exp.get("points", []):
        q = dict(fixed)
        q.update(p)
        pts.append(q)
    return pts


DIMKEYS = ["M", "N", "K", "H", "W", "C", "CO", "KH", "KW", "stride", "pad"]
SKIP = {"hw", "mem", "kind", "seed", "not_run", "label"}


def run_id(exp: str, p: dict, seed: int) -> str:
    dims = "x".join(str(p[k]) for k in DIMKEYS if k in p)
    extra = "_".join(f"{k}{p[k]}" for k in sorted(p) if k not in SKIP and k not in DIMKEYS)
    s = f"{exp}__{p['hw']}__{p['mem']}__{p['kind']}{dims}" + (f"_{extra}" if extra else "") + f"__s{seed}"
    return s.replace(" ", "").replace("/", "-").replace("'", "")


def metrics(h: sim.Hw, meta: dict, tot: dict, recs: list, ev: dict, mem: dict) -> dict:
    R, Cc = h.rows, h.cols
    cyc = sum(r["cycles"] for r in recs)
    hst = tot["host"]
    macs = hst["MACS"]
    rd_bus, wr_bus = 4 * hst["RD_WORDS"], 4 * hst["WR_WORDS"]
    ca = tot["ca"]
    busy = sum(ca[n] for n in C.CA_BUSY) or 1
    host_cycles = (ev["pop"][-1]["t"] - ev["sub"][0]["start"]) if ev["pop"] and ev["sub"] else None
    m = dict(
        device_cycles=cyc,
        host_cycles=host_cycles,
        macs=macs,
        useful_macs=meta.get("useful_macs", meta["macs"]),
        peak_macs_per_cycle=R * Cc,
        mac_slots=cyc * R * Cc,
        utilisation=macs / (cyc * R * Cc) if cyc else 0.0,
        macs_per_cycle=macs / cyc if cyc else 0.0,
        int_ops_per_cycle=2 * macs / cyc if cyc else 0.0,
        issue_efficiency=(tot["tc02"]["MAC"] / (tot["tc02"]["ISSUE"] * R * Cc)) if tot["tc02"]["ISSUE"] else 0.0,
        bus_bytes_rd=rd_bus, bus_bytes_wr=wr_bus, payload_rd=meta["_payload_rd"], payload_wr=meta["_payload_wr"],
        ideal_bytes=meta["ideal_bytes"],
        traffic_amplification=(rd_bus + wr_bus) / meta["ideal_bytes"],
        ai_ideal=2 * meta.get("useful_macs", meta["macs"]) / meta["ideal_bytes"],
        ai_measured=2 * macs / (rd_bus + wr_bus) if rd_bus + wr_bus else None,
        bus_bytes_per_cycle=(rd_bus + wr_bus) / cyc if cyc else 0.0,
        port_busy_fraction=(hst["RD_WORDS"] + hst["WR_WORDS"]) / cyc if cyc else 0.0,
        port_bytes_per_cycle=mem["port_bytes_per_cycle"],
        cycle_stack={n: ca[n] for n in C.CA_BUSY},
        cycle_stack_frac={n: ca[n] / busy for n in C.CA_BUSY},
        stack_groups={g: sum(ca[n] for n in ns) / busy for g, ns in C.STACK_GROUPS.items()},
        operand_starvation_cycles=tot["tc03"]["STARVE"],
        starve_a=tot["tc03"]["STARVE_A"], starve_b=tot["tc03"]["STARVE_B"],
        array_stall_up=tot["tc02"]["STALL_UP"],
        wait_operand_cycles=ca["WAIT_OPND"],
        sram_bank_conflicts=tot["tc03"]["BANK_CONFLICT"],
        sram_rd_wr_block=tot["tc03"]["RD_WR_BLOCK"],
        sram_wr_stall=tot["tc03"]["WR_STALL"],
        outbuf_conflicts=tot["tb"]["OB_CFL_W"] + tot["tb"]["OB_CFL_D"],
        output_stall_cycles=ca["OUT_STALL"],
        acc_out_stall=tot["tc04"]["OUT_STALL"],
        outbuf_set_wait=tot["tb"]["OB_WWAIT"],
        scheduler_overhead_cycles=ca["VALIDATE"] + ca["RECORD"] + ca["SCHED_GAP"] + ca["SETUP"],
        buffer_overlap_cycles=hst["OVERLAP"],
        tc03_fill_overlap_cycles=tot["tc03"]["OVERLAP"],
        dma_overlap_cycles=tot["dma"]["OVERLAP"],
        dma_buf_wait=tot["dma"]["BUF_WAIT"],
        bus_stall_cycles=hst["BUS_STALL"],
        pad_slots=tot["tc02"]["PAD"],
        commands=len(recs),
    )
    if ev["cmd"]:
        c0 = ev["cmd"][0]
        m["phases_first_cmd"] = dict(
            lead_in=(c0["first_slice"] - c0["deq"]) if c0["first_slice"] >= 0 else None,
            compute_span=(c0["last_readout"] - c0["first_slice"]) if c0["first_slice"] >= 0 else None,
            tail=(c0["rec"] - c0["last_readout"]) if c0["last_readout"] >= 0 else None)
        sub = ev["sub"][0]
        m["host_submit_cycles"] = sub["doorbell"] - sub["start"]
        m["queue_to_dequeue_cycles"] = c0["deq"] - sub["doorbell"]
        m["record_to_pop_cycles"] = ev["pop"][0]["t"] - c0["rec"] if ev["pop"] else None
    return m


def execute(exp: dict, p: dict, seed: int, keep: bool = False) -> dict:
    rid = run_id(exp["id"], p, seed)
    h = sim.hw(p["hw"])
    memm = sim.MEMS[p["mem"]]
    rec = dict(id=rid, experiment=exp["id"], benchmark=exp.get("benchmark"), title=exp.get("title"),
               data_class="simulated", time_base="RTL simulation clock cycles (Verilator), not a measured clock",
               hw=dict(name=h.name, params=h.public(), verified_shape=h.verified),
               memory=dict(model=p["mem"], **memm), workload={k: v for k, v in p.items() if k not in ("hw", "mem")},
               seed=seed, created=datetime.now(timezone.utc).isoformat(timespec="seconds"),
               reproduce=f"python3 bench.py reproduce {rid}")
    if p.get("not_run"):
        rec.update(status="NOT_RUN", reason=p["not_run"])
        return rec
    d = sim.BUILD / "runs" / rid
    if d.exists():
        shutil.rmtree(d)
    try:
        prog, meta = W.build(p["kind"], {k: v for k, v in p.items() if k not in ("hw", "mem", "kind")}, h, seed)
        plus = prog.write(d)
        plus.update(memm["plusargs"])
        plus["maxcyc"] = p.get("maxcyc", 50_000_000)
        exe = sim.build(h, memm["xbar"])
        t0 = time.time()
        rc, txt = sim.simulate(exe, d, plus)
        wall = time.time() - t0
        tb_res = sim.sim_result(txt)
        recs = sim.parse_records(d)
        ev = sim.parse_events(d)
        snaps = sim.parse_snaps(d)
        final = sim.parse_mem(d, plus["dump_lo"], plus["dump_hi"])
        corr = prog.check(final)
        per_cmd, tot, xc = [], {}, []
        for i, c in enumerate(prog.cmds):
            dl = C.delta(snaps[i], snaps[i + 1])
            tot = C.add(tot, dl)
            r = recs[i] if i < len(recs) else None
            mdl = C.model(c.gemm, h.tsu_cfg())
            sat_n = c.sat_expect if c.gemm.ofmt == W.A.OFMT_INT8 else None
            if r is None:
                xc.append(dict(name=f"cmd{i} record present", ok=False, got=None, expected=1))
                continue
            for x in C.crosschecks(dl, r, mdl, c.gemm, sat_n):
                x["name"] = f"cmd{i}: {x['name']}"
                xc.append(x)
            if c.gemm.ofmt == W.A.OFMT_INT8:
                xc.append(dict(name=f"cmd{i}: record SAT flag", ok=bool(r["sat"]) == (c.sat_expect > 0),
                               got=r["sat"], expected=int(c.sat_expect > 0)))
            per_cmd.append(dict(label=c.label, M=c.gemm.m, N=c.gemm.n, K=c.gemm.k, kc=c.gemm.kc, flags=c.gemm.flags,
                                record=r, model=mdl, counters=dl,
                                words=[f"{w:08x}" for w in c.gemm.words()]))
        meta["_payload_rd"] = sum(c["model"]["payload_rd"] for c in per_cmd)
        meta["_payload_wr"] = sum(c["model"]["payload_wr"] for c in per_cmd)
        n_bad_x = sum(1 for x in xc if not x["ok"])
        ok = rc == 0 and tb_res == "PASS" and corr["ok"] and len(recs) == len(prog.cmds) and n_bad_x == 0
        rec.update(status="VALID" if ok else "FAILED", meta=meta, sim=dict(rc=rc, tb_result=tb_res, wall_s=round(wall, 3),
                   exe=str(exe.parent.name)),
                   correctness=dict(corr, reference="reference/ref_int8.py (numpy int64; pure-Python loop cross-check "
                                    f"up to {W.NAIVE_LIMIT} MACs; requant cross-checked with TC05 tq_ref)"),
                   crosschecks=dict(total=len(xc), failed=n_bad_x, failures=[x for x in xc if not x["ok"]][:20]),
                   commands=per_cmd, counters_total=tot, metrics=metrics(h, meta, tot, recs, ev, memm),
                   events=dict(sub=ev["sub"][:8], cmd=ev["cmd"][:8], pop=ev["pop"][:8]),
                   provenance=dict(rtl="third_party/silicaflux-tensorcore08 (unmodified)", rtl_manifest_sha256=sim.rtl_digest(),
                                   testbench="drivers/tb/tb_tensor_bench.sv (derived from TC08 tb/tb_tsu.sv)",
                                   tools=tools(), plusargs=plus))
        CNT.mkdir(parents=True, exist_ok=True)
        shutil.copy(d / "snaps.txt", CNT / f"{rid}.snaps.txt")
        shutil.copy(d / "events.txt", CNT / f"{rid}.events.txt")
        shutil.copy(d / "records.txt", CNT / f"{rid}.records.txt")
        LOGS.mkdir(parents=True, exist_ok=True)
        lg = (d / "sim.log").read_text().splitlines()
        (LOGS / f"{rid}.log").write_text("\n".join(lg[:40] + (["..."] if len(lg) > 80 else []) + lg[-40:]) + "\n")
        if not keep and ok:
            shutil.rmtree(d, ignore_errors=True)
    except Exception as e:  # noqa: BLE001
        rec.update(status="FAILED", error=f"{type(e).__name__}: {e}", traceback=traceback.format_exc()[-3000:])
    return rec


def write_record(rec: dict):
    RUNS.mkdir(parents=True, exist_ok=True)
    (RUNS / f"{rec['id']}.json").write_text(json.dumps(rec, indent=1, default=int))


def cmd_run(names: list[str], jobs: int, keep: bool):
    todo = []
    for n in names:
        exp = load_exp(n)
        for p in points(exp):
            for s in p.get("seeds", exp.get("seeds", [1])):
                todo.append((exp, p, s))
    # build every needed configuration first (in parallel), then run
    cfgs = {(p["hw"], sim.MEMS[p["mem"]]["xbar"]) for _, p, _ in todo if not p.get("not_run")}
    with ThreadPoolExecutor(max(1, min(jobs, 4))) as ex:
        list(ex.map(lambda c: sim.build(sim.hw(c[0]), c[1]), sorted(cfgs)))
    t0 = time.time()
    results = []

    def one(item):
        exp, p, s = item
        r = execute(exp, p, s, keep)
        write_record(r)
        m = r.get("metrics", {})
        print(f"{r['status']:<8} {r['id']:<80} cyc {m.get('device_cycles', '-'):>8} util "
              f"{100 * m.get('utilisation', 0):5.1f}%  x-checks {r.get('crosschecks', {}).get('total', 0)}"
              f"/{r.get('crosschecks', {}).get('failed', 0)} bad"
              + (f"  ERR {r.get('error')}" if r.get('error') else ""), flush=True)
        return r

    with ThreadPoolExecutor(jobs) as ex:
        results = list(ex.map(one, todo))
    store.save_manifest()
    bad = [r for r in results if r["status"] == "FAILED"]
    print(f"{len(results)} runs: {sum(r['status'] == 'VALID' for r in results)} VALID, {len(bad)} FAILED, "
          f"{sum(r['status'] == 'NOT_RUN' for r in results)} NOT RUN  ({time.time() - t0:.0f} s)")
    return 1 if bad else 0


def cmd_reproduce(rid: str):
    old = json.loads((RUNS / f"{rid}.json").read_text())
    exp = load_exp(old["experiment"])
    p = dict(old["workload"])
    p["hw"], p["mem"] = old["hw"]["name"], old["memory"]["model"]
    new = execute(exp, p, old["seed"])
    same = []
    for key in ("device_cycles", "macs", "bus_bytes_rd", "bus_bytes_wr", "cycle_stack"):
        same.append((key, old.get("metrics", {}).get(key) == new.get("metrics", {}).get(key)))
    same.append(("counters_total", old.get("counters_total") == new.get("counters_total")))
    same.append(("status", old["status"] == new["status"]))
    for k, ok in same:
        print(f"{'SAME' if ok else 'DIFF'}  {k}")
    print("REPRODUCED" if all(ok for _, ok in same) else "NOT REPRODUCED")
    return 0 if all(ok for _, ok in same) else 1


def cmd_validate():
    import jsonschema
    schema = json.loads((LAB / "schema" / "run_record.schema.json").read_text())
    n = bad = 0
    for f in sorted(RUNS.glob("*.json")):
        n += 1
        try:
            jsonschema.validate(json.loads(f.read_text()), schema)
        except jsonschema.ValidationError as e:
            bad += 1
            print(f"INVALID {f.name}: {e.message}")
    print(f"schema: {n - bad}/{n} run records valid")
    return 1 if bad else 0


def cmd_list():
    for f in sorted(EXP_DIR.glob("*.json")):
        e = json.loads(f.read_text())
        print(f"{e['id']:<28} {len(points(e)):>4} points  {e.get('title', '')}")
    return 0


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    r = sp.add_parser("run")
    r.add_argument("exp", nargs="+")
    r.add_argument("--jobs", type=int, default=sim.CPUS)
    r.add_argument("--keep", action="store_true")
    rp = sp.add_parser("reproduce")
    rp.add_argument("run")
    sp.add_parser("validate")
    sp.add_parser("list")
    a = ap.parse_args()
    if a.cmd == "run":
        sys.exit(cmd_run(a.exp, a.jobs, a.keep))
    if a.cmd == "reproduce":
        sys.exit(cmd_reproduce(a.run))
    if a.cmd == "validate":
        sys.exit(cmd_validate())
    sys.exit(cmd_list())


if __name__ == "__main__":
    main()
