/* =============================================================================================================
 * SilicaFlux TensorCore benchmark lab :: CPU reference GEMMs (INT8 x INT8 -> INT32, row-major, exact)
 *
 *   naive      straightforward i-j-k dot-product loop (the "straightforward CPU reference")
 *   vec        i-k-j loop over int32 accumulator rows, written for the compiler's auto-vectoriser
 *              (gcc -O3 -march=native); a plain-C optimisation, not a library
 *   onednn     oneDNN dnnl_gemm_s8s8s32 (a well-optimised CPU library; row-major API, offsets 0, alpha 1, beta 0)
 *
 * Usage: cpu_gemm A.bin B.bin C_expected.bin M N K impl [min_seconds]
 *   A.bin  M*K int8   B.bin  K*N int8   C_expected.bin  M*N int32 little-endian (from reference/ref_int8.py)
 * Prints one JSON object: timing of the kernel call only (operands already in host memory, output buffer
 * allocated, warm-up call excluded), median over 7 batches, and the exact comparison with C_expected.
 * Timing boundary: kernel call only -- no file I/O, allocation or packing outside the call (oneDNN's internal
 * packing happens inside its call and IS included).
 * ============================================================================================================= */
#define _POSIX_C_SOURCE 199309L
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef HAVE_ONEDNN
#include <oneapi/dnnl/dnnl.h>
#endif

static void gemm_naive(const int8_t *A, const int8_t *B, int32_t *C, long M, long N, long K) {
  for (long i = 0; i < M; i++)
    for (long j = 0; j < N; j++) {
      int32_t s = 0;
      for (long k = 0; k < K; k++) s += (int32_t)A[i * K + k] * (int32_t)B[k * N + j];
      C[i * N + j] = s;
    }
}

static void gemm_vec(const int8_t *restrict A, const int8_t *restrict B, int32_t *restrict C, long M, long N, long K) {
  for (long i = 0; i < M; i++) {
    int32_t *restrict c = C + i * N;
    for (long j = 0; j < N; j++) c[j] = 0;
    for (long k = 0; k < K; k++) {
      const int32_t a = A[i * K + k];
      const int8_t *restrict b = B + k * N;
      for (long j = 0; j < N; j++) c[j] += a * (int32_t)b[j];
    }
  }
}

#ifdef HAVE_ONEDNN
static void gemm_onednn(const int8_t *A, const int8_t *B, int32_t *C, long M, long N, long K) {
  const int32_t co = 0;
  dnnl_status_t st = dnnl_gemm_s8s8s32('N', 'N', 'F', M, N, K, 1.0f, A, K, 0, B, N, 0, 0.0f, C, N, &co);
  if (st != dnnl_success) { fprintf(stderr, "dnnl_gemm_s8s8s32 failed: %d\n", (int)st); exit(2); }
}
#endif

static void *load(const char *p, size_t n) {
  FILE *f = fopen(p, "rb");
  if (!f) { perror(p); exit(2); }
  void *b = malloc(n ? n : 1);
  if (fread(b, 1, n, f) != n) { fprintf(stderr, "%s: short read\n", p); exit(2); }
  fclose(f);
  return b;
}

static double now(void) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return t.tv_sec + 1e-9 * t.tv_nsec;
}

static int cmpd(const void *a, const void *b) {
  double x = *(const double *)a, y = *(const double *)b;
  return (x > y) - (x < y);
}

int main(int argc, char **argv) {
  if (argc < 8) { fprintf(stderr, "usage: %s A B Cexp M N K naive|vec|onednn [min_s]\n", argv[0]); return 2; }
  long M = atol(argv[4]), N = atol(argv[5]), K = atol(argv[6]);
  const char *impl = argv[7];
  double min_s = argc > 8 ? atof(argv[8]) : 0.05;
  int8_t *A = load(argv[1], (size_t)(M * K));
  int8_t *B = load(argv[2], (size_t)(K * N));
  int32_t *E = load(argv[3], (size_t)(M * N) * 4);
  int32_t *C = calloc((size_t)(M * N), 4);
  void (*fn)(const int8_t *, const int8_t *, int32_t *, long, long, long) = NULL;
  if (!strcmp(impl, "naive")) fn = gemm_naive;
  else if (!strcmp(impl, "vec")) fn = gemm_vec;
#ifdef HAVE_ONEDNN
  else if (!strcmp(impl, "onednn")) fn = gemm_onednn;
#endif
  if (!fn) { printf("{\"impl\": \"%s\", \"status\": \"NOT AVAILABLE\"}\n", impl); return 0; }
  fn(A, B, C, M, N, K);                                   /* warm-up + correctness */
  long bad = 0;
  for (long i = 0; i < M * N; i++) bad += C[i] != E[i];
  /* calibrate the repetition count, then 7 timed batches */
  long reps = 1;
  for (;;) {
    double t0 = now();
    for (long r = 0; r < reps; r++) fn(A, B, C, M, N, K);
    if (now() - t0 > min_s / 7 || reps > (1L << 30)) break;
    reps *= 2;
  }
  double per[7];
  for (int b = 0; b < 7; b++) {
    double t0 = now();
    for (long r = 0; r < reps; r++) fn(A, B, C, M, N, K);
    per[b] = (now() - t0) / reps;
  }
  qsort(per, 7, sizeof(double), cmpd);
  for (long i = 0; i < M * N; i++) bad += C[i] != E[i];
  double macs = (double)M * N * K;
  printf("{\"impl\": \"%s\", \"M\": %ld, \"N\": %ld, \"K\": %ld, \"reps\": %ld, \"median_s\": %.9e, \"min_s\": %.9e, "
         "\"max_s\": %.9e, \"gmacs_per_s\": %.6f, \"gops_per_s\": %.6f, \"mismatches\": %ld, \"status\": \"%s\"}\n",
         impl, M, N, K, reps, per[3], per[0], per[6], macs / per[3] / 1e9, 2 * macs / per[3] / 1e9, bad,
         bad ? "FAILED" : "VALID");
  return bad ? 1 : 0;
}
