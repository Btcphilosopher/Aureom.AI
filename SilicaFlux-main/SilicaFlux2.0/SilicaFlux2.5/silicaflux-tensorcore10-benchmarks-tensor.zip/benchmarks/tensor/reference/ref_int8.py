"""Independent INT8 reference implementations for the SilicaFlux TensorCore benchmark lab.

Written from the TENSORCORE 08 ABI document (docs/02_COMMAND_ABI.md section 2), NOT from the RTL:

  C[m][n] = sum_k A[m][k] * B[k][n]                                  exact INT32 (INT8 x INT8 operands)
  INT8 output: q = clamp(R_rm(acc * Q_MULT / 2^Q_SHIFT) + Q_ZP, -128, 127); with RELU q = max(q, Q_ZP)
               SAT = the pre-clamp value left [-128, 127]
  rounding modes: 0 RNE (half to even), 1 RTZ (toward zero), 2 RDN (toward -inf), 3 RUP (toward +inf),
                  4 RMM (half away from zero)

Three independent GEMM paths are provided and cross-checked against each other by reference/selftest.py:
  * gemm_naive   -- pure-Python triple loop on Python integers (unbounded; small sizes only)
  * gemm_numpy   -- numpy int64 matmul (exact: |sum| < 2^31 << 2^63)
  * the C kernels in reference/cpu_gemm.c (naive, compiler-vectorised, oneDNN gemm_s8s8s32)
and the requantisation is checked against TENSORCORE 05's own Fraction-based tq_ref.element().
"""
from __future__ import annotations

import numpy as np

RM_RNE, RM_RTZ, RM_RDN, RM_RUP, RM_RMM = 0, 1, 2, 3, 4
RM_NAMES = {0: "RNE", 1: "RTZ", 2: "RDN", 3: "RUP", 4: "RMM"}
INT32_MIN, INT32_MAX = -(1 << 31), (1 << 31) - 1


# ----------------------------------------------------------------------------------------------- GEMM
def gemm_naive(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Literal triple loop on Python integers (straightforward CPU reference, no numpy arithmetic)."""
    m, k = a.shape
    k2, n = b.shape
    assert k == k2
    al = a.astype(int).tolist()
    bl = b.astype(int).T.tolist()
    out = [[sum(x * y for x, y in zip(al[i], bl[j])) for j in range(n)] for i in range(m)]
    return np.array(out, dtype=np.int64)


def gemm_numpy(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Exact INT8 x INT8 -> INT64 matmul; asserts the INT32 contract (no overflow)."""
    c = a.astype(np.int64) @ b.astype(np.int64)
    if c.size and (c.min() < INT32_MIN or c.max() > INT32_MAX):
        raise OverflowError("INT32 accumulation bound exceeded (K too large for the operands)")
    return c


# ----------------------------------------------------------------------------------------------- requantisation
def _shift_round(x: np.ndarray, s: int, rm: int) -> np.ndarray:
    """R_rm(x / 2^s) for int64 x with |x| < 2^62 and 0 <= s <= 63 (exact integer arithmetic)."""
    x = x.astype(np.int64)
    if s == 0:
        return x.copy()
    fl = x >> np.int64(s)                                    # floor (arithmetic shift)
    # remainder 0 <= r < 2^s; for s = 63 the true value fits int64 and two's-complement wrap gives it exactly
    with np.errstate(over="ignore"):
        r = x - (fl << np.int64(s))
    half = np.int64(1) << np.int64(s - 1)
    if rm == RM_RDN:
        inc = np.zeros_like(x)
    elif rm == RM_RUP:
        inc = (r != 0).astype(np.int64)
    elif rm == RM_RTZ:
        inc = ((r != 0) & (x < 0)).astype(np.int64)
    elif rm == RM_RNE:
        inc = ((r > half) | ((r == half) & ((fl & 1) == 1))).astype(np.int64)
    elif rm == RM_RMM:
        inc = ((r > half) | ((r == half) & (fl >= 0))).astype(np.int64)
    else:
        raise ValueError(f"illegal rounding mode {rm}")
    return fl + inc


def requant(acc: np.ndarray, mult, shift, zp, rm: int = RM_RNE, relu: bool = False):
    """INT32 accumulators -> INT8 with per-tensor (scalars) or per-column (1-D arrays of length N) parameters.
    Returns (q int8 array, sat bool array)."""
    acc = np.asarray(acc, dtype=np.int64)
    n = acc.shape[-1]
    mult = np.broadcast_to(np.asarray(mult, dtype=np.int64), (n,))
    shift = np.broadcast_to(np.asarray(shift, dtype=np.int64), (n,))
    zp = np.broadcast_to(np.asarray(zp, dtype=np.int64), (n,))
    y = np.empty_like(acc)
    for j in range(n):                                       # per column: shift is a per-column scalar
        p = acc[..., j] * mult[j]                            # |acc| < 2^31, |M| <= 2^31 -> |p| <= 2^62
        y[..., j] = _shift_round(p, int(shift[j]), rm) + zp[j]
    sat = (y < -128) | (y > 127)
    q = np.clip(y, -128, 127)
    if relu:
        q = np.maximum(q, zp)
    return q.astype(np.int8), sat


def quantize_multiplier(scale: float, shift_max: int = 63) -> tuple[int, int]:
    """Real scale -> (M, S) with scale ~= M / 2^S, M a signed 32-bit integer, largest usable S."""
    if scale == 0:
        return 0, 0
    best = (0, 0)
    for s in range(shift_max + 1):
        m = int(round(scale * (1 << s)))
        if -(1 << 31) <= m < (1 << 31):
            best = (m, s)
        else:
            break
    return best


# ----------------------------------------------------------------------------------------------- convolution
def im2col_nhwc(x: np.ndarray, kh: int, kw: int, stride: int = 1, pad: int = 0, pad_value: int = 0):
    """x: (H, W, C) int8 -> patches (OH*OW, KH*KW*C) with k index order (kh, kw, c)."""
    h, w, c = x.shape
    xp = np.full((h + 2 * pad, w + 2 * pad, c), pad_value, dtype=x.dtype)
    xp[pad:pad + h, pad:pad + w, :] = x
    oh = (h + 2 * pad - kh) // stride + 1
    ow = (w + 2 * pad - kw) // stride + 1
    cols = np.empty((oh * ow, kh * kw * c), dtype=x.dtype)
    for i in range(oh):
        for j in range(ow):
            patch = xp[i * stride:i * stride + kh, j * stride:j * stride + kw, :]
            cols[i * ow + j] = patch.reshape(-1)
    return cols, oh, ow


def conv2d_direct(x: np.ndarray, wgt: np.ndarray, stride: int = 1, pad: int = 0) -> np.ndarray:
    """Direct (non-GEMM) NHWC convolution reference: x (H, W, C), wgt (KH, KW, C, CO) -> (OH, OW, CO) int64."""
    h, w, c = x.shape
    kh, kw, c2, co = wgt.shape
    assert c == c2
    xp = np.zeros((h + 2 * pad, w + 2 * pad, c), dtype=np.int64)
    xp[pad:pad + h, pad:pad + w, :] = x
    oh = (h + 2 * pad - kh) // stride + 1
    ow = (w + 2 * pad - kw) // stride + 1
    out = np.zeros((oh, ow, co), dtype=np.int64)
    w64 = wgt.astype(np.int64)
    for dy in range(kh):
        for dx in range(kw):
            win = xp[dy:dy + stride * oh:stride, dx:dx + stride * ow:stride, :]       # (OH, OW, C)
            out += np.tensordot(win, w64[dy, dx], axes=([2], [0]))
    return out


# ----------------------------------------------------------------------------------------------- bias lowering
def bias_rows(bias: np.ndarray, extra: int = 2):
    """Software lowering of an INT32 bias into `extra` INT8 GEMM rows (K augmentation, NOT a hardware bias):
    A gets columns [127, 1] (or [127]*(extra-1) + [1]); B gets rows whose weighted sum is the bias.
    Representable |bias| <= (extra-1)*127*127 + 127.  Returns (a_cols int8 (extra,), b_rows int8 (extra, N))."""
    bias = np.asarray(bias, dtype=np.int64)
    n = bias.shape[0]
    a_cols = np.array([127] * (extra - 1) + [1], dtype=np.int8)
    b_rows = np.zeros((extra, n), dtype=np.int64)
    rem = bias.copy()
    for i in range(extra - 1):
        q = np.clip(np.trunc(rem / 127.0).astype(np.int64), -127, 127)
        b_rows[i] = q
        rem = rem - 127 * q
    if np.any(np.abs(rem) > 127):
        raise ValueError("bias magnitude too large for the requested number of augmentation rows")
    b_rows[extra - 1] = rem
    assert np.array_equal((a_cols.astype(np.int64)[:, None] * b_rows).sum(0), bias)
    return a_cols, b_rows.astype(np.int8)
