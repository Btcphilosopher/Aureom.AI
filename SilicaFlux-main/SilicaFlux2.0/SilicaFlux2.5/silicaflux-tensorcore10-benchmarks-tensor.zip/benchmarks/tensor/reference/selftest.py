#!/usr/bin/env python3
"""Self-test of the lab's references before any hardware result is trusted.

  1. gemm_naive (pure Python) == gemm_numpy (int64) on random shapes, all distributions, and the INT32 extreme
  2. requant() == TENSORCORE 05 tq_ref.element() (Fraction arithmetic, written independently by TC05) on
     random and edge accumulators x multipliers x shifts 0..63 x zero-points x all five rounding modes x ReLU
  3. im2col + GEMM == direct convolution
  4. bias lowering by K augmentation reproduces the INT32 bias exactly
Writes reports/reference_selftest.json; exit code 1 on any mismatch.
"""
from __future__ import annotations

import json
import random
import sys
from pathlib import Path

import numpy as np

LAB = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(LAB))
sys.path.insert(0, str(LAB / "third_party/silicaflux-tensorcore08/third_party/silicaflux-tensorcore05/model"))
import tq_ref  # noqa: E402

from reference import ref_int8 as R  # noqa: E402


def main(n_requant: int = 20000) -> int:
    rng = np.random.default_rng(2026)
    res = {}
    # 1 -------------------------------------------------------------------------------------- GEMM paths
    bad = 0
    cases = 0
    for m, n, k in [(1, 1, 1), (4, 4, 4), (5, 7, 3), (17, 13, 29), (8, 1, 64), (1, 9, 33), (16, 16, 16)]:
        for dist in ("uniform", "neg", "mix"):
            if dist == "uniform":
                a = rng.integers(-128, 128, (m, k), dtype=np.int8)
                b = rng.integers(-128, 128, (k, n), dtype=np.int8)
            elif dist == "neg":
                a = np.full((m, k), -128, np.int8)
                b = np.full((k, n), -128, np.int8)
            else:
                a = np.where(rng.random((m, k)) < .5, -128, 127).astype(np.int8)
                b = np.where(rng.random((k, n)) < .5, -128, 127).astype(np.int8)
            cases += 1
            bad += int(not np.array_equal(R.gemm_naive(a, b), R.gemm_numpy(a, b)))
    # INT32 extreme: K = 131071, all -128 -> 2 147 467 264 (largest exact value), and K = 131072 must be refused
    a = np.full((1, 131071), -128, np.int8)
    b = np.full((131071, 1), -128, np.int8)
    ext = int(R.gemm_numpy(a, b)[0, 0])
    ok_ext = ext == 131071 * 16384 and ext <= R.INT32_MAX
    try:
        R.gemm_numpy(np.full((1, 131072), -128, np.int8), np.full((131072, 1), -128, np.int8))
        ok_ovf = False
    except OverflowError:
        ok_ovf = True
    res["gemm"] = dict(cases=cases, mismatches=bad, int32_extreme=ext, extreme_ok=ok_ext, overflow_detected=ok_ovf)

    # 2 -------------------------------------------------------------------------------------- requantisation
    prng = random.Random(7)
    edges_acc = [0, 1, -1, 2, -2, 3, -3, R.INT32_MAX, R.INT32_MIN, 131071 * 16384, -131071 * 16384, 1 << 20, -(1 << 20)]
    edges_m = [0, 1, -1, (1 << 31) - 1, -(1 << 31), 1 << 30, 0x5A82799A, -0x5A82799A]
    mism = 0
    checked = 0
    for i in range(n_requant):
        acc = prng.choice(edges_acc) if i % 4 == 0 else prng.randint(R.INT32_MIN, R.INT32_MAX)
        if i % 3 == 0:
            acc = prng.randint(-5000, 5000)
        mult = prng.choice(edges_m) if i % 5 == 0 else prng.randint(-(1 << 31), (1 << 31) - 1)
        shift = prng.randint(0, 63)
        zp = prng.randint(-128, 127)
        rm = prng.randint(0, 4)
        relu = prng.random() < 0.3
        q, sat = R.requant(np.array([[acc]]), mult, shift, zp, rm, relu)
        q2, sat2, _ = tq_ref.element(acc, mult=mult, shift=shift, zp=zp, rq=True, ofmt=tq_ref.OFMT_INT8,
                                     relu=relu, rm=rm)
        checked += 1
        if int(q[0, 0]) != q2 or bool(sat[0, 0]) != bool(sat2):
            mism += 1
            if mism < 5:
                print("requant mismatch", acc, mult, shift, zp, rm, relu, int(q[0, 0]), q2, bool(sat[0, 0]), sat2)
    # exhaustive ties: x = (2t+1) * 2^(s-1) for every mode
    for s in range(1, 12):
        for t in range(-40, 40):
            acc = (2 * t + 1) << (s - 1)
            for rm in range(5):
                q, sat = R.requant(np.array([[acc]]), 1, s, 0, rm, False)
                q2, sat2, _ = tq_ref.element(acc, mult=1, shift=s, zp=0, rq=True, ofmt=tq_ref.OFMT_INT8, rm=rm)
                checked += 1
                mism += int(int(q[0, 0]) != q2 or bool(sat[0, 0]) != bool(sat2))
    res["requant"] = dict(checked=checked, mismatches=mism, reference="TENSORCORE 05 model/tq_ref.py element()")

    # 3 -------------------------------------------------------------------------------------- im2col
    x = rng.integers(-128, 128, (9, 7, 5), dtype=np.int8)
    w = rng.integers(-128, 128, (3, 3, 5, 6), dtype=np.int8)
    ok_conv = True
    for stride, pad in ((1, 0), (1, 1), (2, 1)):
        cols, oh, ow = R.im2col_nhwc(x, 3, 3, stride, pad)
        g = R.gemm_numpy(cols, w.reshape(-1, 6)).reshape(oh, ow, 6)
        ok_conv &= bool(np.array_equal(g, R.conv2d_direct(x, w, stride, pad)))
    res["im2col"] = dict(ok=ok_conv)

    # 4 -------------------------------------------------------------------------------------- bias lowering
    bias = rng.integers(-16000, 16000, 64)
    ac, br = R.bias_rows(bias, 2)
    res["bias_lowering"] = dict(ok=bool(np.array_equal((ac.astype(np.int64)[:, None] * br.astype(np.int64)).sum(0), bias)))

    ok = (bad == 0 and ok_ext and ok_ovf and mism == 0 and ok_conv and res["bias_lowering"]["ok"])
    res["status"] = "PASS" if ok else "FAIL"
    out = LAB / "reports" / "reference_selftest.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(res, indent=1))
    print(json.dumps(res, indent=1))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(int(sys.argv[1]) if len(sys.argv) > 1 else 20000))
