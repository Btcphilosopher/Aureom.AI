# SilicaFlux BandwidthLab — repository audit

Repository: `btcphilosopher/Aureom.AI`, revision `ba77e7c` (branch `claude/admiring-pasteur-lmpz98`, working tree
clean). All SilicaFlux material is in `SilicaFlux-main/`; almost all RTL is inside zip/tar archives, which were
extracted read-only into a scratch directory. **No repository file was modified.**

Method. Three static source audits (one per area) cite every fact as `file:line`; they are reproduced unabridged in
[`audit/`](audit/) (paths there are relative to each archive's root; `<extract>/X` = the archive `X.zip` extracted).
Key facts the simulator depends on were then **checked by execution** in this project, not only by reading:

| Fact used by the model | How it was checked |
|---|---|
| `sfb_crossbar` timing: 0 added cycles, 1 outstanding per master/slave port, same-cycle re-issue, RR pointer moves on accepted grant, grant lock, per-master error slave 1 cycle | Unmodified RTL driven by `rtl_harness/tb_bandwidthlab_xbar.sv` under Verilator 5.020 and Icarus 12.0; 11,600 transactions compared cycle by cycle with the model — all identical (`calibration/calibration.json`) |
| `dma_transfer_engine` 4 cycles/beat; `dma_burst_engine` phase/credit rules | Read the RTL headers and next-state logic (`rtl/dma/dma_burst_engine.sv:1-30,101-141,214-253`); model reproduces all 12 recorded Verilator benchmark rows (11 configurations) after one fitted overhead |
| `sfv_tile` TSPM arbitration (per bank, per cycle: MBIST > engine > fabric) and engine timing `3+2K(+4)`, `3+B·P` | Read `sfv_tile.sv:1-40,90-140`, `sfv_tensor_engine.sv:2-30`, `sfv_vec_engine.sv:1-30`; unmodified `sfv_tile` run under Verilator through MemoryLab's harness (54 commands) |
| sramlib bank controller semantics | Cycle equivalence (35 stimulus configurations) with MemoryLab's `BankController`, which MemoryLab validated against the unmodified `sram_bank_controller.sv` |

## 1. What `.sf` (and `.sfx`) files are

`.sf` = **SystemVerilog source with a renamed extension** ("Language: Silica Flux-2017", defined in the
testbenches as IEEE 1800-2017 semantics; `S25/run_sim.sh` compiles them with `iverilog -g2012`). They are **not**
renamed copies of the v1 `.sv` files: the loose `.sf` files are a much larger "Gen-2.5" rewrite which **does not
form a buildable design** (two incompatible `package silicaflux_pkg`, instantiations with ports the modules do not
have, ~30 referenced modules not found). `.sfx` = assembly for `sfx_asm.py`. Details:
[`audit/audit_mcu_full_labs.md` §A](audit/audit_mcu_full_labs.md).

## 2. Which projects exist

| Project | Archive | Status relevant to BandwidthLab |
|---|---|---|
| SilicaFlux-V reduced ASIC (release 1) | `silicaflux-v-release1.zip` | Coherent RTL; CPU RV32I 2-stage, `sfv_xbar` 3×7 fixed priority, 4×32 KiB SRAM, 16 KiB TSPM (4 banks), 4-lane VE, 4×4 INT8 TE; **no DMA, no cache**; IHP/SKY130 synthesis estimates |
| DataFabric (SFB2 bus + DMA) | `silicaflux-datafabric.zip` (identical copy in SilicaFlux2.5) | `sfb_crossbar` 4×7 RR in `sfv_soc_df`; simple DMA default, buffered/dual-port options; recorded Verilator benchmarks, traces, synthesis |
| SRAM Wrapper Library (Project 01) | `SilicaFlux2.5/silicaflux-sramlib.zip` | `sram_sp/1r1w/tdp`, `sram_bank_controller`; not instantiated by SilicaFlux-V (it has `sfv_sram_sp`) but selectable in `sfv_soc_df` (`SRAM_IMPL=1`) |
| MCU-I | `SilicaFlux2.5/silicaflux-mcu-i.zip` | RV32IM 2-stage, SFB2 crossbar RR, 4 contiguous SRAM banks (64/128 KiB), simple DMA, no cache |
| Full SilicaFlux v1 cluster | `silicaflux.zip` | 4 tiles × 1 KiB SPM, 2×2 mesh NoC, sequential tensor unit (~67 cycles); coherent but no bus/DMA; TimingFlow could not synthesise it |
| Full SilicaFlux Gen-2.5 (`.sf`) | loose files | not buildable (see §1) |
| MemoryLab (previous Roofline/DES project) | `silicaflux-memorylab.zip` (2 identical copies) | **Exists and is reused** (event engine, ClockDomain, Transaction, units, provenance, RTL-validated BankController, tile-latency harness) |
| MemoryFlow v1/v2 | `silicaflux-memoryflow*.zip` | memory-subsystem characterisation of the 2.5 controller |
| TwinLab | `silicaflux-twinlab.zip` | Angular app; **no import path** (export only) |
| TimingFlow / TimingLab | `silicaflux-timingflow.zip`, `silicaflux-timinglab*.zip` | per-design `timing_scenes.csv` with *derived* Fmax |
| PowerLink | `silicaflux-powerlink.zip` | SRAM reads/writes-per-cycle workload profiles, pJ values marked `source: assumption` |
| FloorplanLab | `silicaflux-floorplanlab.zip` | `twinlab_floorplan.json` (schema 1.0.0) for SilicaFlux-V |
| "PowerGrid", "ThermalLab" | — | **NOT FOUND** as tools; only sub-features of TwinLab/PowerLink/FloorplanLab |
| Cache controllers | `memory_cache_repo.zip` | `set_assoc_cache.sv` (32 KiB, 64 B, 4-way PLRU, WB, blocking) — **not used by any SilicaFlux top** |

## 3. Source-backed module audit (the ten requested properties)

`DF` = `silicaflux-datafabric/`, `SV` = `silicaflux-v/`, `SL` = `silicaflux-sramlib/`, `MCU` = `silicaflux-mcu-i/`.

| # | Module and file | Clock domain | Bus width | Request / response protocol | Max outstanding | SRAM read latency | Memory port topology | Arbitration | Ordering rules | Verification status |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | `sfb_crossbar` — `DF/rtl/interconnect/sfb_crossbar.sv` | `clk`, async `rst_n`; no CDC | AW/DW 32 in SoC (`sfv_soc_df.sv:116`) | SFB2: `req_valid/ready, write, addr, wdata, wstrb`; `rsp_valid/ready, rdata, error`; no IDs/bursts; every write answered | 1 per master port, 1 per slave port (`:19-23`) | none (adds 0 cycles, `:24-25`) | 4 masters (DBG, CPUD, CPUI, DMA) × 7 slaves (ROM, SRAM0-3, TSPM, PERIPH) | per-slave `sfb_arbiter`, RR (`ARB_MODE=1`), pointer → winner+1 on accepted grant; grant lock | in order per master (owner register, `sfb_rsp_router.sv:4-10`) | Authors: sim 115/115, unbounded proofs; **this project: 11,600 txns cycle-exact vs model (Verilator+Icarus)** |
| 2 | `sfb_arbiter` — `DF/rtl/interconnect/sfb_arbiter.sv` | `clk` | N=4 | req/stall/accept → one-hot grant | — | — | one per slave | fixed (0 highest, `:63-69`) or RR (`:95-96`) | — | proved (authors); exercised by the RTL comparison |
| 3 | `sfb_error_slave` — `DF/.../sfb_error_slave.sv` | `clk` | 32 | SFB2 slave, `error=1, rdata=0` | 1 | answers 1 cycle after accept (`:27-35`) | one per master | — | in order | **verified here** (decode-error cases in the RTL comparison) |
| 4 | `sfb_reg_slice` / `sfb_skid_buffer` | `clk` | 32 | pass-through | 2-entry skid | +1 cycle per sliced direction (`sfb_reg_slice.sv:6-10`) | point to point | — | in order | authors only; **not used in the SoC** |
| 5 | `sfb_shared_bus` | `clk` | 32 | SFB2 | 1 in the whole fabric | 0 added | NM×1×NS | RR | in order | authors (TB TOPO=1); **not used in the SoC** |
| 6 | `dma_transfer_engine` — `DF/rtl/dma/dma_transfer_engine.sv` | `clk` | DW 32 (SoC default) | SFB2 master, registered valid | 1 | — | 1 master port | — | strict read→write per beat; `done` after last write response OK (`:91,168-180`) | Authors: tb_dma, bounded formal 23; **model matches recorded Verilator cycles exactly** |
| 7 | `dma_burst_engine` — `DF/rtl/dma/dma_burst_engine.sv` | `clk` | DW 32/64 | SFB2 master ×1 or ×2 | MAX_OUT per port (crossbar caps at 1) | — | 1 port (phases) or 2 (DUAL_PORT) | — | FIFO credit; phase switch only when idle; `done` after all writes acked | Authors: bounded formal 22; **model matches 8 recorded configurations (9 rows) exactly** |
| 8 | `sfv_sram_slave` / `sfv_sram_sp` — `SV/rtl/mem/sfv_mem_slaves.sv:14`, `sfv_sram_sp.sv` | `clk` | 32, 4 byte enables | SFB slave | 1 (crossbar) | **1 cycle** (`:61`) | 1RW, 8192×32 per bank, 4 contiguous banks = 128 KiB | MBIST preempts | in order | SoC firmware 6/6 (authors) |
| 9 | `sfv_tile` (TSPM) — `SV/rtl/accel/sfv_tile.sv` | `clk` + gated `gclk_ve/te` | fabric 32; engine port 4×32 | SFB slave + engine lock port | 1 | 1 | 4 × 1RW, word-interleaved (bank = addr[3:2]), 16 KiB | per bank per cycle: MBIST > lock owner > fabric (`:8-15`); lock TE > VE | engines deterministic; fabric in order | authors cocotb; **this project: Verilator run of the unmodified tile (54 commands)** |
| 10 | `sfv_tensor_engine` — `SV/rtl/accel/sfv_tensor_engine.sv` | `gclk_te` | 4×4 INT8/UINT8, 32-bit acc | register bus + TSPM engine port | 1 command | TSPM 1 | A/B words fetched sequentially from 1RW banks | via tile lock | `CYCLES = 3+2K (+4 WB)` (`:25-30`), peak 8 of 16 MAC/cycle | as #9 |
| 11 | `sfv_vec_engine` — `SV/rtl/accel/sfv_vec_engine.sv` | `gclk_ve` | 4 lanes × 32 | register bus + TSPM engine port | 1 command | TSPM 1 | all 4 TSPM banks per beat | via tile lock | `CYCLES = 3 + B·P (+1 DOT WRES)`, P = 3/2/2/1 | as #9 |
| 12 | `sfv_cpu` — `SV/rtl/cpu/sfv_cpu.sv` | `clk` | 2 × SFB 32 (I, D) | SFB master (req/gnt) | 1 per port, blocking | load CPI 2 at 1-cycle memory | — | — | in order, precise | riscv-tests 55/55 (authors); **CPI only checked against documentation here** |
| 13 | `sfv_xbar` — `SV/rtl/bus/sfv_xbar.sv` | `clk` | 32 | SFB v1 (req/gnt, rvalid; no rsp back-pressure) | 1/1 | — | 3×7 | fixed priority, master 0 highest (`:113-116`) | in order | formal PDR (authors); superseded by `sfb_crossbar` in `sfv_soc_df` |
| 14 | `sram_sp` / `sram_1r1w` / `sram_tdp` — `SL/rtl/mem/` | `clk` | DW 32 default, byte masks | v/r req + v/r rsp (id, err) | RSP_FIFO_DEPTH (= RL+1) | RL (default 1); writes effective at accept, ack after RL | 1RW / 1R1W / 2RW | 1R1W collision STALL alternating (default); TDP same-address with a write: sequential | in acceptance order | authors' regressions; |
| 15 | `sram_bank_controller` — `SL/rtl/mem/sram_bank_controller.sv` | `clk` | 32 | per-master v/r with IDs | RSP_FIFO_DEPTH credits; **no request queue** | RL | N banks × 1RW, low/high interleave (XOR not implemented) | per-bank RR (pointer → granted+1) or fixed | per master in order | **MemoryLab: Verilator/Icarus equivalence; this project: 35-config equivalence of the new model** |
| 16 | `mcu_cpu` + `sfb_crossbar` + `mcu_sram_bank` — `MCU/rtl/...` | `clk` | 32 | SFB2 | 1 per port | 1 cycle | 4 contiguous 1RW banks | RR | in order | riscv-tests, cocotb, SoC regression (authors) |
| 17 | `set_assoc_cache` — `memory_cache_repo/rtl/set_assoc_cache.sv` | `clk` | 32 | cpu_req/ack, mem_req/ack | 1 (blocking, no MSHR) | — | 1/1 | — | blocking | TB present, no logs; **unused** |
| 18 | v1 `memory_controller` / NoC — `silicaflux/rtl/` | `clk` | 32/128; 43-bit flits | v/r, blocking FSM | 1 | 3 cycles/word end-to-end (MemoryFlow record) | 1 port + write-back port; 2×2 mesh | none / fixed L>N>S>E>W | serial | v1 TB, no logs |

**Address map (DataFabric SoC, `generated/sfb_memmap_pkg.sv:11-61`):** ROM 0x0000_0000 4 KiB; SRAM0-3
0x1000_0000/0x1000_8000/0x1001_0000/0x1001_8000 32 KiB each; TSPM 0x2000_0000 16 KiB; PERIPH 0x4000_0000 128 KiB
(DMA registers 0x4000_6000, performance counters 0x4000_7000). CPUI and DMA are denied PERIPH (`MST_SLV_EN`).

**Clock domains.** One functional clock everywhere (SDC target 20 ns = 50 MHz for SilicaFlux-V — a constraint, not a
measurement; IHP post-placement estimate 74.5 MHz typical; TimingFlow derived Fmax for `sfv_soc_df` 62.0 MHz slow /
152 MHz fast at post-synthesis). JTAG TCK is the only other domain. No CDC exists in the memory system.

**Existing hardware counters.** `sfb_perf_counters` (per master reads, writes, request stall, arbitration loss,
response stall, error cycles; DMA bytes/busy/idle/max FIFO; 64-bit cycle counter); engine `CYCLES` registers; CPU
`mcycle/minstret`. **Existing transaction traces.** Five DataFabric RTL traces
(`reports/datafabric/traces/*.csv`, `sfb_trace_monitor` format) — imported by `bandwidthlab.trace_import`.

## 4. Discrepancies between the brief and the repository

1. The brief's SilicaFlux-V has 256 KiB SRAM and one DMA channel; the RTL release has 128 KiB and **no DMA** (the
   DataFabric SoC adds the simple DMA). The provisional configuration keeps the brief's values, labelled HYPOTHETICAL.
2. "Vector/tensor traffic" never crosses the fabric in SilicaFlux-V: both engines use dedicated TSPM engine ports
   with priority over the fabric. The model reproduces this; fabric masters are DBG, CPUD, CPUI and DMA.
3. 2×2…16×16 MAC arrays, INT16/INT4, BF16/FP16, more lanes, wider fabrics, bursts, multi-outstanding ports, input
   queues, weighted/age arbitration, scatter-gather and multi-channel DMA, caches and DRAM are **exploration
   features**, not present in SilicaFlux-V RTL; every result row records whether its fabric configuration stays
   within the audited SFB2 behaviour (`fabric_rtl_equivalent`).
4. No DRAM/HBM exists in any SilicaFlux RTL; external memory appears only in the hypothetical `silicaflux_full`.
5. The DataFabric `tb/` source hash does not match its recorded value (rtl/ does) — see `audit/audit_datafabric.md` §14.4.

## 5. Git branch

The brief asks for `feature/silicaflux-bandwidthlab`. The user instructed *"produce as a zip, do not commit to
github"*, so no branch, commit or push was made. To integrate, unzip into `SilicaFlux-main/silicaflux-bandwidthlab/`
and create the branch there (see `integration.md`).
