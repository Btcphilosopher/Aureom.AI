# Commands executed and actual results

Environment: Linux x86_64, Python 3.12.3 (venv), packages pinned in `requirements.txt`, Verilator 5.020, Icarus Verilog 12.0 (Ubuntu packages), headless Chromium for PNG export. Repository archives read from `SILICAFLUX_REPO=<Aureom.AI checkout>`.

## Commands

```bash
export SILICAFLUX_REPO=<path to the Aureom.AI checkout>; export PYTHONPATH=python
python -m pytest tests/bandwidthlab -rs --junitxml=logs/pytest_junit.xml      # logs/pytest.log
python -m bandwidthlab test-summary --junit logs/pytest_junit.xml --run-dir reports/bandwidthlab/example_run
python -m bandwidthlab all --out reports/bandwidthlab/example_run --workers 4   # logs/all.log
#   = analytical (4 configs), simulate run_001, experiments A-J + H, qos, sweep (75 variants), calibrate,
#     couple, export-twinlab, report (+ figures, dashboard, trace viewer)
python -m bandwidthlab experiments --config configs/silicaflux_v.yaml --workers 4   # final experiments (logs/experiments_final.log)
python -m bandwidthlab report --run-dir reports/bandwidthlab/example_run           # logs/report_final.log
python profile (logs/profile.log): cProfile of the reference tile pipeline
```

## Results

* Tests: **191 passed, 0 failed, 0 skipped**.
* Crossbar vs unmodified `sfb_crossbar` RTL: Verilator 7600 transactions in 8 configurations, all cycle-exact: True; Icarus 4000 transactions in 4 configurations, all cycle-exact: True.
* DMA vs recorded Verilator benchmark: fitted {'dma.setup_cycles + dma.completion_cycles': 4} on ['buf_f8_b8', 'simple_d32']; holdout {'n': 10, 'mape': 0.0, 'max_rel_error': 0.0, 'mean_abs_error_cycles': 0.0, 'max_abs_error_cycles': 0.0, 'exact': 10}.
* tensor engine vs `sfv_tile` RTL (Verilator, this session): fitted {'tensor.overhead_cycles': 1} on ['K=1 WB=0', 'K=16 WB=0']; holdout {'n': 12, 'mape': 0.025346346309746418, 'max_rel_error': 0.1111111111111111, 'mean_abs_error_cycles': 0.5833333333333334, 'max_abs_error_cycles': 1.0, 'exact': 5}.
* vector engine vs `sfv_tile` RTL (Verilator, this session): fitted {'vector.overhead_cycles': 1} on ['dot_vs LEN=100 WRES=0', 'vv LEN=100 WRES=0']; holdout {'n': 38, 'mape': 0.10467724196349257, 'max_rel_error': 0.5, 'mean_abs_error_cycles': 0.6052631578947368, 'max_abs_error_cycles': 1.0, 'exact': 15}.
* Saturation, experiments, sweep, QoS: see REPORT.md and the JSON/CSV files under the run directory.
* Profile: reference pipeline 30,940 transactions / 40,064 cycles in 5.8 s (no event log) or 7.6 s (with) — `logs/profile.log`.

## Run-directory contents

| path | content |
|---|---|
| `REPORT.md`, `answers.json`, `quality_gates.json` | report, answers, gates |
| `dashboard.html`, `trace_viewer.html`, `plotly.min.js` | interactive dashboard and transaction timeline |
| `figures/*.html`, `figures/*.png` | the 14 required visualisations |
| `run_001/` | reference simulation: results.json, transactions.csv, latency_decomposition.csv, events.csv |
| `analytical/` | Level-1 ceilings per configuration |
| `experiments/experiments.json` | experiments A-J and H |
| `qos/qos.json` | arbitration QoS study |
| `sweeps/` | 75-variant sweep, marginal gains, Pareto front, summary |
| `calibration/` | RTL equivalence, DMA and engine calibration/holdout, recorded-trace metrics |
| `coupling/` | TimingFlow Fmax import, combined metrics, PowerLink activity profile, synthesis table |
| `twinlab/` | TwinLab export + JSON Schema |
| `test_summary.json` | parsed JUnit summary |
