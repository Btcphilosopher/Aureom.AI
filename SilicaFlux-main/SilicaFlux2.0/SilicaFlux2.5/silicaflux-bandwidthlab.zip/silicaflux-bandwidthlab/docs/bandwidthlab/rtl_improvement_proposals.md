# Proposed SilicaFlux-V RTL improvements (ranked)

Basis: EVENT_SIMULATED results of the PROVISIONAL SilicaFlux-V configuration (`reports/bandwidthlab/example_run`,
experiments A–J and the 75-variant sweep) on the reference tile pipeline (GEMM 32×32×64 INT8 in 4×4 tiles, CPU
programming the DMA through its registers, TE then VE per tile, a CPU background stream), plus the repository's
recorded synthesis results (technology-independent NAND2-eq, `silicaflux-datafabric/reports/datafabric/synth.md`).
The fabric and DMA timing behind these numbers is RTL-validated (see `model_reference.md` §1); the whole pipeline is
not. Cycle counts are clock-independent; all GB/s figures assume 50 MHz.

| Rank | Change | Evidence (cycles of the reference pipeline unless stated) | Cost evidence | Status |
|---|---|---|---|---|
| 1 | **Make the dual-port buffered DMA (`ENGINE=1, DUAL_PORT=1`) the SoC default** | no DMA (CPU copy loops, release-1 style) 56,995 → simple DMA 40,064 → buffered single-port 26,139 → **dual-port 15,560** (3.66× vs no DMA, 2.57× vs simple). TE MAC utilisation 7.2 % → 10.2 % → 15.7 % → 26.3 % | dual-port engine 7,926 NAND2-eq vs simple 3,638 (+4,288; *less* than the single-port buffered engine, 8,243). Needs a 5th crossbar master port (not synthesised in the repository: cost unknown) | RTL exists (`dma_burst_engine.sv`); only the SoC parameters change |
| 2 | **Widen the DMA/fabric path into the TSPM to 64 bit** | buffered DMA 32→64 bit: 26,139 → 14,450 (1.81×); simple DMA 40,064 → 20,652 (1.94×); sweep 64→128 bit +40.9 %, 128→256 bit +2.4 % (the 4 × 32-bit TSPM row limits). A wider fabric with a 32-bit DMA gives 0 % | crossbar 4×7: 7,340 → 11,526 NAND2-eq (+4,186); 64-bit buffered DMA 8,960 | RTL parameterised (`DW`); TSPM fabric port is 32-bit in `sfv_tile` and would need widening |
| 3 | **Bound the fabric's wait on the TSPM** (today strict engine priority, `sfv_tile.sv:8-15`) | CPU loads to a TSPM bank the TE streams from: P99 2.02 cycles but **max 257 cycles** (one whole TE command, experiment F). Engine timing is deterministic by design, so any fix trades a little engine throughput for a CPU bound | small (a wait counter + a forced fabric slot) | **not simulated as a variant** — the expected effect is a bounded CPU wait of W cycles at ≤ 1/W loss of engine bank cycles; needs a model variant and RTL change |
| 4 | **Interleave or hash the main-SRAM banks across the crossbar** when several masters stream concurrently | 4 streams on 4 contiguous 64 KiB banks: 4,001 cycles; 8 contiguous banks 2,001; **4 interleaved banks 2,004** (no new banks). Strided streams (stride = 4 words) on 4 banks: low/high 6,001, **XOR or skew 2,003** (3×) | decoder change only; XOR = bit operations; skew needs an adder; non-power-of-two modulo needs a divider | not in RTL (`sfb_addr_decoder` is range-based; sramlib lists XOR as a next action) |
| 5 | Keep `FIFO_DEPTH = 8, MAX_OUT = 2` for the buffered DMA | sweep: FIFO 1→2 +48 %, 2→4 +24 %, 4→8 +19 %, 8→16 **0 %**; outstanding 1→2 +27 %, 2→4 **0 %** (the crossbar allows one transaction per port) | FIFO bits and outstanding entries | RTL default already 8 / 2 |

## Changes that do NOT pay off before ranks 1–2

* **More SRAM banks for the pipeline**: 1→2 banks +1.8 %, 2→16 0 %; banks only cut CPU tail latency (experiment A:
  CPU P99 4 → 2 cycles, DMA copy time unchanged).
* **More SRAM capacity**: 0 % from 32 KiB to 1 MiB for this workload (its footprint is < 32 KiB). Capacity must be
  sized from real application data, which this benchmark does not represent.
* **Arbitration policy changes for throughput**: fixed / RR / WRR / age give identical pipeline throughput. Policy is a
  QoS knob only: fixed CPU-first gives CPU P99 2 cycles but slows a same-bank DMA copy by 37 % (8,196 → 11,193
  cycles); RR gives P99 3 cycles at full DMA speed (experiment J).
* **A larger tensor array before the staging path is fixed**: 8×8 is 3.7× faster with operands resident
  (8,833 → 2,401 cycles) but only 1.9× in the DMA-staged pipeline, and the gain there comes from bigger tiles moving
  less operand data per MAC, while MAC utilisation falls from 15.7 % to 7.3 %. With the 64-bit path, 8×8 reaches
  3,306 cycles (sweep interaction).
* **More vector lanes**: ≤ 7.5 % per doubling in this pipeline (the VE only post-processes 16-element tiles).

## Not evaluated (would need new model work or RTL)

* Operand double-buffering in the TE (recorded in the SilicaFlux-V issue register as a next-revision item) — the
  model has the knob (`tensor.operand_ports`, `input_buffers`) but the TSPM would need a second engine port per
  operand; not simulated in the delivered runs.
* Posted engine-port writes (would also remove the 1-cycle TE write-back residual).
* Any change needing physical data (frequency, area of the shortlisted variants, energy): run the IHP flow already in
  the repository on variants 1–2 before deciding.
