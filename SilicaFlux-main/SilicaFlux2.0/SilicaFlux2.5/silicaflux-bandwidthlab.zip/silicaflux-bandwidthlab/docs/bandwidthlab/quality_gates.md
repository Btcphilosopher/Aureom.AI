# Engineering quality gates

Test suite: 191 passed, 0 failed, 0 skipped (19.8 s; `logs/pytest.log`, `logs/pytest_junit.xml`).

Gate status is evaluated by `bandwidthlab.report.evaluate_gates` from the run's evidence files (with live re-runs for determinism and sweep reproducibility). PASS on synthetic tests does **not** mean RTL cycle accuracy: only the components listed in model_reference.md §1 have RTL evidence.

| gate | status | evidence |
|---|---|---|
| GATE 1 — Configuration validation | PASS | 4 shipped configs validate; strict schema (unknown keys rejected); pytest: 191 passed, 0 failed |
| GATE 2 — Deterministic event engine | PASS | identical seeds -> identical transaction timelines (live re-run); (time, priority, sequence) ordering property-tested |
| GATE 3 — Transaction conservation | PASS | run_001: accepted 30940 = completed 30940 + outstanding 0 + cancelled 0; invariant errors 0 |
| GATE 4 — Correct queue behaviour | PASS | finite queues: bounded latency, no growth trend; unbounded admission: growth detected at [0.35, 0.4, 0.5, 0.7, 1.0] req/cycle/master |
| GATE 5 — SRAM port constraints | PASS | run_001 per-bank accesses <= busy cycles x ports; 35 stimulus configurations cycle-equivalent to the RTL-validated MemoryLab BankController; property test over 1RW/1R1W/2RW |
| GATE 6 — Arbitration correctness | PASS | 11600 transactions cycle-exact vs unmodified sfb_crossbar RTL (fixed + round robin, Verilator and Icarus) |
| GATE 7 — Backpressure correctness | PASS | 3 RTL cases with 10-30 % response back-pressure, all cycle-exact; request back-pressure via 1-outstanding ports |
| GATE 8 — DMA data movement correctness | PASS | byte-exact destination checks in tests (4 engines x 4 lengths, errors, SG); DMA cycle counts: holdout {'n': 10, 'mape': 0.0, 'max_rel_error': 0.0, 'mean_abs_error_cycles': 0.0, 'max_abs_error_cycles': 0.0, 'exact': 10} |
| GATE 9 — Bandwidth accounting | PASS | port utilisation <= 1; copy bytes counted once (DMA useful 36864 B vs physical 136048 B incl. operand/CPU traffic); GB and GiB both |
| GATE 10 — Latency accounting | PASS | 9 consecutive non-overlapping components sum exactly to the total for every completed transaction of run_001; Little's law gap 0.0 |
| GATE 11 — Compute dependency correctness | PASS | TE MACs 65536 = workload MACs; pointer-chase loads never overlap (test); compute ops start only after their operands |
| GATE 12 — Saturation behaviour | PASS | plateau, onset of queueing and instability classified for 4 curves (experiment H) |
| GATE 13 — Workload validation | PASS | CPU CPI vs documented RTL CPI; TE 2 cycles/k-step and VE 3 cycles/beat vs RTL formulas; engine cycles vs sfv_tile RTL (holdout) |
| GATE 14 — Parameter sweep reproducibility | PASS | re-executed sweep variants reproduce the stored result_hash bit-for-bit; workers=1 vs 2 identical (test) |
| GATE 15 — RTL trace integration where available | PASS | own SV harness on sfb_crossbar; sfv_tile via MemoryLab harness; 5 recorded DataFabric traces imported |
| GATE 16 — Calibration and validation separation | PASS | parameters fitted only on named calibration subsets; errors reported separately for holdout; crossbar has no fitted parameters |
| GATE 17 — Reports and visualisations correctly sourced | PASS | 14 figures rebuilt from run files only; every result labelled with its category |
| GATE 18 — All model limitations documented | PASS | docs/bandwidthlab/model_reference.md (fidelity, limitations) and open_issues.md |
