# BandwidthLab model reference

## 1. Fidelity levels and result categories

| Level | What | Category label | Module |
|---|---|---|---|
| 1 Analytical | link, port, SRAM, DMA, tensor and vector ceilings; Roofline; Little bound | `ANALYTICAL_CEILING` | `analytical.py` |
| 2 Cycle-aware DES | the principal engine (everything below) | `EVENT_SIMULATED` | `scheduler`, `sram`, `bus`, `dma`, `masters`, ... |
| 3 RTL-calibrated | unmodified RTL run under Verilator/Icarus in this session | `RTL_OBSERVED` | `calibration.py`, `rtl_harness/` |
| — | RTL results recorded in the repository by earlier projects (not re-run) | `RTL_SIMULATED (recorded)` | `calibration.dma_calibration` |
| — | silicon | `SILICON_MEASURED` — **none exists** | — |

Categories are never merged. An analytical ceiling is never reported as a benchmark result.

**Where the model is RTL-validated, and where it is not.**

| Component | Status |
|---|---|
| Interconnect (`bus.Interconnect`) in its SFB2 configuration (crossbar, fixed/RR, 1 outstanding, 0-cycle, error slave, response back-pressure) | **cycle-exact** vs unmodified `sfb_crossbar` RTL for every compared transaction (8 configurations Verilator + 4 Icarus) |
| Banked SRAM (`sram.BankedSram`), 1RW, no request queue, power-of-two banks, low/high interleave | cycle-equivalent to MemoryLab's `BankController` (35 configurations), itself validated against `sram_bank_controller.sv` |
| DMA (`dma.DmaEngine`) simple / buffered / dual-port | matches all 12 recorded Verilator benchmark rows (ideal scenario) after one fitted start/finish overhead |
| Tensor / vector engine programs | per-step slopes exact; holdout command cycles within ≤ 1 cycle of `sfv_tile` RTL (diagnosed residuals) |
| CPU core | CPI 1/2/3 reproduce the **documented** values only (no RTL run of the core) |
| Extensions (shared bus, queues, multi-outstanding, bursts, WRR/age, 1R1W/2RW banks, XOR/skew, non-power-of-two, multi-channel/SG/prefetch DMA, cache, DRAM) | **not RTL-validated**; unit/property tested only |
| Whole SoC workloads (tile pipeline) | composition of validated parts; **not compared end-to-end with RTL** |

## 2. Time, clocks, events

* Integer femtoseconds; `ClockDomain` (from MemoryLab) converts cycles exactly when the period is an integer number
  of fs (else the quantisation error is reported).
* Pending events are ordered by `(time, priority, sequence)`. Within a clock edge a `DomainDriver` evaluates five
  phases in order — RESPONSE, ISSUE, ARBITRATE, ACCEPT, POST — and within a phase components run by rank (targets,
  fabric, masters) then attachment order. Idle periods are skipped; cycle indices stay exact.
* Typed `SimEvent` records: time, domain, cycle, type (15 required types + diagnostics), global sequence number,
  transaction id, source, destination, payload, dependency state.
* Safety: negative delays and past events raise `SchedulingError`; zero-time loops raise `ZeroTimeLoopError`; event,
  simulated-time and wall-clock limits raise `LimitExceeded`; a drained queue with outstanding work raises
  `DeadlockError`; no completion for a watchdog interval while work is outstanding raises `NoForwardProgressError`.
* Cycle rules: a presented request may be accepted on the edge it is presented; data arriving at edge *c* can start a
  compute op at *c*; a request that depends on something completed at *c* is presented for *c+1* (registered valid).

## 3. Transactions

`MemTransaction` subclasses MemoryLab's `Transaction` (no parallel definition). Kinds READ, WRITE, DMA_READ,
DMA_WRITE, PREFETCH (cache prefetch / non-binding read), ATOMIC (schema only; no audited bus implements it).
Ordered lifecycle stamps: created, issued, enqueued, queue_head, granted, at_target, service_start, service_end,
response, completed (+ cancelled). **Acceptance** (`t_accepted`, the ownership handshake) is a separate stamp because
in a combinational SFB2 crossbar it coincides with target acceptance, after arbitration. `TransactionLedger` enforces
conservation (accepted = completed + outstanding + cancelled), detects duplicates, loss, completion before
acceptance or before dependencies, and integrates the in-system count for Little's law.

Write semantics: SFB2 writes are acknowledged (completion = response accepted). Posted writes (sramlib `WRITE_ACK=0`)
complete at acceptance.

## 4. Latency decomposition (exact, non-overlapping)

generation (created→issued), admission (issued→enqueued), queue_wait (enqueued→queue_head), arbitration
(queue_head→granted), interconnect (granted→at_target), target_wait (at_target→service_start), memory_service
(service_start→service_end), response_queue (service_end→response), response_xfer (response→completed). Missing
stages take the previous stamp (zero length), so waiting is attributed to the next existing stage. The components sum
exactly to the total for every transaction (checked). Acceptance delay (issued→accepted) is reported separately as an
overlapping view. Percentiles: numpy linear interpolation; tail percentiles are flagged unstable when fewer than 10
samples lie beyond them; bootstrap confidence intervals are available.

## 5. Bandwidth definitions

Theoretical link `(W/8)·f·transfers·links` (ANALYTICAL); offered, accepted and completed traffic; read/write
bandwidth; useful payload (a DMA copy counts its bytes once: reads carry `useful_bytes = 0`); physical link traffic
(beats × width); utilisation (busy cycles / window); transfer efficiency (useful bytes / peak bytes); idle and stall
cycles. GB/s = 1e9 B/s and GiB/s = 2^30 B/s are both reported, always with the clock domain.

## 6. Component semantics (summary)

* **SRAM** (`sram.py`): ports × banks; per-bank RR (pointer → last granted + 1) or fixed; 1RW / 1R1W (same-row
  collision STALL, alternating) / 2RW (same row with a write → sequential); writes at grant; responses after
  read/write latency in order per port; response credits (default RL+1); optional per-port request FIFO; error
  response for out-of-range / misaligned (natural alignment); multi-word and explicit word-list accesses.
* **Bank mapping** (`banking.py`): low, high, modulo, XOR (power of two), skew (any count); all bijective (property
  test).
* **Interconnect** (`bus.py`): see the module docstring; `FabricConfig.rtl_equivalent()` reports any departure from
  the audited SFB2 behaviour. Fabric-split memories model DataFabric's SRAM0..3 (each bank its own slave).
* **DMA** (`dma.py`): feature levels L0-L5; registered request valid; FIFO credit; phases; completion after the last
  write acknowledgement; real data movement; errors (read error → write the good prefix; write error → stop).
* **Masters** (`masters.py`): program-driven; in-order or decoupled access/execute; TokenBoard for cross-unit
  dependencies; exact stall accounting from state transitions.
* **CPU** (`cpu.py`): fetch and execute masters synchronised by tokens; fetch-ahead 3; blocking loads/stores.
* **Vector** (`vector.py`) / **Tensor** (`tensor.py`): see module docstrings (operand layouts, buffering, fill/drain,
  write-back, precision rules: FP16/BF16 refused without an FP compute model).
* **DRAM** (`dram.py`): simplified controller (not JEDEC-accurate) in its own clock domain with a 2-stage CDC.
  Ramulator 2 trace export (`ramulator.py`, format checked against upstream source; not executed).
* **Cache** (`cache.py`): optional, non-coherent; fills/write-backs as single-beat SFB2 transactions.

## 7. Limitations (all known)

1. Only the components listed as validated in §1 have RTL evidence; everything else is a model of documented
   behaviour or an exploration extension.
2. No physical effects: wire delay beyond configured register slices, clock skew, IR drop, temperature, voltage
   droop are not modelled. Frequencies are assumptions or tool-derived estimates.
3. DRAM: no refresh, tRAS/tRC/tFAW/tRRD, power-down, ODT, ECC. Cache: no coherence; DMA writes are not snooped.
4. Area/energy: no silicon area or energy is computed from first principles. Resource columns are proxies; the
   synthesis-backed cost table uses the repository's technology-independent NAND2-eq numbers (not PDK area). PowerLink
   SRAM energies are assumptions in the repository, so energy per byte is not reported.
5. The CPU model has no branch prediction, interrupts, CSR or exception timing; DMA status polling is replaced by a
   completion token (interrupt-like, zero cost).
6. The tensor-engine write-back is 1 cycle long versus RTL and short vector commands are ≤ 2 cycles short; not tuned
   away (holdout independence).
7. The tile-pipeline workload (CPU-programmed DMA staging, double-buffered TSPM slots, TE then VE per tile) is a
   plausible firmware structure, not firmware from the repository.
8. Python performance (measured, `logs/profile.log`): the reference tile pipeline (30,940 transactions, 40,064
   cycles, 53,723 kernel events) takes 5.8 s without and 7.6 s with event recording — ≈190 µs per transaction,
   ≈6,900 simulated cycles/s. cProfile shows the time spread over the per-edge phase methods (largest single function
   ≈7 % of the run), so only a port of the whole cycle engine would help; a C++ backend was not justified for the
   delivered studies (75-variant sweep ≈100 s on 4 cores).
