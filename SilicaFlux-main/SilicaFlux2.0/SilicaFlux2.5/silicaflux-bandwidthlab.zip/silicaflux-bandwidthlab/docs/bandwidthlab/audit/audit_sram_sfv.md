# Source-backed audit: SilicaFlux SRAM Wrapper Library + SilicaFlux-V (release 1)

Audit date: 2026-11-06. Method: read-only inspection of the extracted sources. Nothing was executed from them. Every
claim cites `path:line`. "NOT FOUND" means I searched the stated tree and it is absent.

**Roots** (all paths below are relative to `<extract>/`):

| Alias | Root |
|---|---|
| `SL/` | `SilicaFlux2.0_SilicaFlux2.5_silicaflux-sramlib/silicaflux-sramlib/` |
| `SV/` | `silicaflux-v-release1/silicaflux-v/` |
| `DF/` | `silicaflux-datafabric/silicaflux-datafabric/` (outside the assigned scope; used only for `sfv_soc_df.sv`, see §B.0) |

Note on concatenated files: line numbers are per file (verified with `grep -n` where files were read together).

---

# Part A: SRAM Wrapper Library (`SL/`)

## A.0 Library-wide constants and scope

* Backends: `SRAM_BACKEND_GENERIC 0`, `_FPGA 1`, `_ASIC 2` (`SL/rtl/mem/sram_defs.svh:22-24`). GENERIC "turns into flip-flops: never use it for silicon storage" (`sram_defs.svh:16-18`). ASIC "never falls back to flip-flops" (`sram_defs.svh:20-21`).
* Collision policies: `STALL 0` (default), `READ_OLD 1` (1R1W only, GENERIC/FPGA only), `FORBID 2` (`sram_defs.svh:26-39`).
* Arbitration constants: `SRAM_ARB_RR 0`, `SRAM_ARB_FIXED 1` (`sram_defs.svh:42-43`). Interleave: `SRAM_ILV_LOW 0` (bank = word % NUM_BANKS), `SRAM_ILV_HIGH 1` (bank = word / BANK_DEPTH) (`sram_defs.svh:45-46`). Addressing: `SRAM_ADDR_WORD 0`, `SRAM_ADDR_BYTE 1` (`sram_defs.svh:48-49`).
* MBIST algorithms: March C- (10N) = 0, MATS+ (5N) = 1 (`sram_defs.svh:52-53`).
* Clock domains: **single clock only**. "Single clock domain only; no ECC; no sleep/retention control" (`SL/docs/mem/09_status_and_next_actions.md:43`). A dual-clock 1R1W is listed only as a future action (`09_status_and_next_actions.md:62`). No `.sdc` file exists in `SL/` (NOT FOUND).
* Illustrative SilicaFlux-V presets (explicitly "NOT confirmed SilicaFlux design specifications", `SL/rtl/mem/sram_presets.svh:3-4`): CTRL 32b x 1024 (4 KiB), CPU 32b x 4096 (16 KiB), VEC SPM 64b x 4096 (32 KiB), TENSOR SPM 128b x 2048 (32 KiB) (`sram_presets.svh:11-18`).

## A.1 Primitives: port topology, parameters, defaults

| Module | Topology | Parameters (defaults) | Source |
|---|---|---|---|
| `sram_sp` | **1RW**, valid/ready request + in-order valid/ready response + raw MBIST test port | `DATA_WIDTH=32`, `DEPTH=1024`, `MASK_WIDTH = DW%8==0 ? DW/8 : 1` (byte enables by default), `READ_LATENCY=1`, `BACKEND=GENERIC`, `MACRO=0`, `RSP_FIFO_DEPTH=READ_LATENCY+1`, `WRITE_ACK=1`, `ID_WIDTH=1`, `TEST_EN=1`, `INIT_FILE=""`; `AW = clog2(DEPTH)` localparam | `SL/rtl/mem/sram_sp.sv:39-52` |
| `sram_1r1w` | **1R1W**: posted write channel `wr_*` + read channel `rd_*` with response | as above plus `COLLISION=STALL`; no `WRITE_ACK` (writes posted, `wr_err` on invalid address) | `SL/rtl/mem/sram_1r1w.sv:36-49`, `:5-10` |
| `sram_tdp` | **2RW true dual port** (ports A and B, each with sram_sp request/response) | as sram_sp plus `COLLISION=STALL`; READ_OLD not offered | `SL/rtl/mem/sram_tdp.sv:28-42`, `:14-21` |
| `sram_backend_1rw` / `_1r1w` / `_2rw` | raw macro-shaped ports (`ce/we/wmask/addr/wdata->rdata`; 1R1W: `we/waddr` + `re/raddr`) | `DATA_WIDTH=32`, `DEPTH=1024`, `MASK_WIDTH=4`, `READ_LATENCY=1`, `BACKEND`, `MACRO=0`, `INIT_FILE` | `SL/rtl/mem/sram_backend_1rw.sv:22-39`; `sram_backend_1r1w.sv:23-41`; `sram_backend_2rw.sv:23-46` |
| `sram_generic_{1rw,1r1w,2rw}` | behavioural arrays (flip-flop/inferred), sim-only fault injection | `READ_LATENCY >= 1`; `MASK_WIDTH` must divide `DATA_WIDTH` | `SL/rtl/mem/backends/generic/sram_generic_1rw.sv:35-57` |
| `sram_fpga_{1rw,1r1w,2rw}` | BRAM inference (`ram_style="block"`), optional `$readmemh` | 1 = BRAM latch, 2 = + output register, >=3 fabric regs | `SL/rtl/mem/backends/fpga/sram_fpga_1rw.sv:11-13`, `:50-56` |
| `sram_asic_array` | tiles real macros; `MODE` 0=1RW, 1=1R1W, 2=2RW | `NC = ceil(DW/macro width)`, `NR = ceil(DEPTH/macro words)`, `XL = READ_LATENCY - MLAT` extra flop stages | `SL/rtl/mem/backends/asic/sram_asic_array.sv:31-69` |

Elaboration rules: `DEPTH >= 2`, `DATA_WIDTH >= 1`, ASIC requires explicit `MACRO`, `INIT_FILE` only on FPGA (`SL/rtl/mem/sram_backend_1rw.sv:41-55`). `WRITE_ACK` must be 0/1 (`sram_sp.sv:81-83`). Non-power-of-two DEPTH supported; out-of-range addresses are accepted, never touch the array, and return `rsp_err=1` (`sram_sp.sv:18-19`, `:98`, `:144`).

## A.2 Latency, write semantics, read-during-write, collisions

**Read latency (request accept -> rdata valid): exactly `READ_LATENCY` cycles, default 1**, when not back-pressured.
* Contract: "response READ_LATENCY cycles after acceptance" (`SL/rtl/mem/sram_sp.sv:12-13`); timing table: accepted at t, response visible at t + READ_LATENCY (`SL/docs/mem/01_interface_spec.md:122-130`).
* Mechanism: tag pipeline `LATENCY` deep in `sram_rsp_path` (`SL/rtl/mem/sram_rsp_path.sv:73-99`); FIFO bypass when empty and `rsp_ready=1`, so latency stays `LATENCY` (`sram_rsp_path.sv:13-15`, `:131-135`).
* Raw backends: data valid "EXACTLY READ_LATENCY cycles after the read edge, for one cycle only (never rely on it being held)" (`SL/rtl/mem/sram_backend_1rw.sv:14-15`). Backend pipeline `q0` + `READ_LATENCY-1` stages (`SL/rtl/mem/backends/generic/sram_generic_1rw.sv:128-139`).
* ASIC: every catalogued macro has native latency 1 (`SL/rtl/mem/backends/asic/sram_macro_funcs.svh:200-235`). Extra latency adds plain flops (`sram_asic_array.sv:68`, `:184-200`). `READ_LATENCY` below the macro latency is rejected (`sram_asic_array.sv:86-88`).

**Write latency**: the write takes effect at the acceptance edge; any read accepted in a later cycle sees it (`SL/rtl/mem/sram_sp.sv:14-15`; `01_interface_spec.md:73`, `:129`). With `WRITE_ACK=1` the acknowledgement (rsp_we=1, rdata=0) travels the same tag pipeline, so it also appears `READ_LATENCY` cycles after acceptance (`sram_sp.sv:100`, `:144`; `sram_rsp_path.sv:21-22`). `WRITE_ACK=0` gives posted writes that need no credit (`sram_sp.sv:16-17`, `:101`).

**Read-during-write / collisions**
* `sram_sp` (1RW): one access per cycle; "A write cycle produces no read data" (`SL/rtl/mem/backends/generic/sram_generic_1rw.sv:7-8`). FPGA 1RW is "no-change" mode (`SL/rtl/mem/backends/fpga/sram_fpga_1rw.sv:5-7`, `:18-19`).
* `sram_1r1w`: ordering rule for all policies: a read returns data of writes accepted in earlier cycles, never of a write accepted in the same cycle (`SL/rtl/mem/sram_1r1w.sv:12-14`).
  * STALL (default): a same-address pair is never issued; one side is back-pressured; priority alternates (`sram_1r1w.sv:17-21`, code `:104-113`).
  * READ_OLD: both issue, read returns old word; GENERIC/FPGA only; **rejected at elaboration for ASIC** (`sram_1r1w.sv:22-25`, `:82-84`). GENERIC model reads first (`SL/rtl/mem/backends/generic/sram_generic_1r1w.sv:72`); FPGA uses separate processes, which gives an old-word read (`SL/rtl/mem/backends/fpga/sram_fpga_1r1w.sv:6-11`).
  * FORBID: no logic; assertion; X in simulation (`sram_1r1w.sv:26-27`, `:156-163`).
* `sram_tdp` same address: a conflict is "both ports request the same valid address in one cycle and at least one of them writes"; read/read is never a conflict (`SL/rtl/mem/sram_tdp.sv:14-15`, code `:111`). STALL: the port without priority is back-pressured, priority alternates (starvation-free), and the result equals sequential execution in acceptance order. **write/write: the later write wins** (`sram_tdp.sv:16-19`, code `:113-121`). FORBID: assertion only (`sram_tdp.sv:20`). READ_OLD is not offered (`sram_tdp.sv:21`, `:83-85`). The raw 2RW backend treats same-address write involvement as outside the contract and gives X in sim (`SL/rtl/mem/backends/generic/sram_generic_2rw.sv:5-9`, `:81-105`).
* Starvation bound under STALL: "≤ 2 cycles wait without backpressure — simulated and formally bounded-proven" (`SL/docs/mem/01_interface_spec.md:93`).
* TDP availability: GENERIC, FPGA and **ASIC only on IHP SG13G2 2P macros**; SKY130 1RW1R and GF180 1RW are rejected (`sram_tdp.sv:6-12`; `sram_asic_array.sv:80-82`).

**Backpressure / outstanding**: `req_ready` is 0 in reset and the cycle after, and 0 in test mode (`sram_sp.sv:25-27`, `:101`). Credits: `can_issue = live_q && (oc_q < FIFO_DEPTH)` (`SL/rtl/mem/sram_rsp_path.sv:168`), so **max outstanding responses = `RSP_FIFO_DEPTH` (default `READ_LATENCY+1` = 2)**. That depth sustains 1 access/cycle (`sram_rsp_path.sv:16-17`). `RSP_FIFO_DEPTH=0` means no backpressure is allowed (master must hold `rsp_ready=1`, checked by assertion) (`sram_rsp_path.sv:18-20`, `:105-120`). There is no combinational path `rsp_ready -> req_ready` (`sram_rsp_path.sv:10-11`; `01_interface_spec.md:75`).

**Ordering**: exactly one response per response-producing request, in acceptance order, never dropped, duplicated or unsolicited (`sram_sp.sv:20-21`; `sram_rsp_path.sv:21`; `01_interface_spec.md:74`).

## A.3 Bank controller (`SL/rtl/mem/sram_bank_controller.sv`)

| Item | Fact | Source |
|---|---|---|
| Topology | `NUM_MASTERS` requesters x `NUM_BANKS` **single-port (1RW)** banks (`sram_backend_1rw` per bank) | `:3`, `:235-240` |
| Defaults | `NUM_MASTERS=4` (1..16), `NUM_BANKS=4` (power of two), `DATA_WIDTH=32`, `MASK_WIDTH=DW/8`, `BANK_DEPTH=1024`, `READ_LATENCY=1`, `ARB=RR`, `INTERLEAVE=LOW`, `ADDR_MODE=WORD`, `ID_WIDTH=4`, `RSP_FIFO_DEPTH=READ_LATENCY+1`, `WRITE_ACK=1`, `TEST_EN=1` | `:44-66`, checks `:97-117` |
| Address-to-bank mapping | **Low-order interleave (default)**: `m_bank = BW'(w)`, `m_row = w >> BW`. **High-order** option: `m_bank = w >> RAW`, `m_row = BW'(w)`. **XOR/hashed: NOT FOUND** (listed as a future action, `SL/docs/mem/03_banking.md:36`; `09_status_and_next_actions.md:61`) | code `:144-153`; header `:10-13` |
| Byte mode | low `log2(DW/8)` bits must be 0, else error response "misaligned"; out-of-range -> error | `:6-9`, `:139-143` |
| Arbitration | per bank, one grant per cycle. RR: search starts at `b_ptr[b]`; after a grant `b_ptr <= gidx+1 (wrap)`. FIXED: master 0 highest (can starve) | `:166-195`; header `:15-19` |
| Request queue depth | **none**: "A request is accepted (m_req_ready) in the cycle its bank grants it, so acceptance == issue" | `:20-21`, `:202` |
| Response queue | per-master `sram_rsp_path` FIFO of `RSP_FIFO_DEPTH` (credit-limited) | `:286-298` |
| Backpressure | `m_req_ready = (granted OR (error request AND credit)) AND !test` | `:202` |
| Parallelism | up to `min(NUM_MASTERS, NUM_BANKS)` accesses/cycle | `:22` |
| Response ordering | per master, in that master's acceptance order, carrying `m_rsp_id`; in order **by construction** (every access, including errors, takes exactly READ_LATENCY and a master issues at most one per cycle); per-bank owner pipeline routes data | `:26-32`, `:244-279` |
| Coherence | none | `:33-34` |
| Perf hook | `m_stall_conflict[m]` = valid & ok & credit & lost bank arbitration | `:84`, `:203` |
| MBIST | `tst_active` blocks functional traffic; `tst_sel[b]` selects banks (parallel allowed) | `:36-38`, `:218-220` |

Measured (simulated, self-checking) bank-controller throughput, 4 masters, low-order interleave: e.g. 32-bit x 4 banks: vector 3.998 words/cycle, random cpu 2.147, stride-by-B 1.001; 128-bit uses READ_LATENCY 2 (avg latency 2.00) (`SL/reports/mem/analysis.md:117-171`). 4000 cycles per run (`analysis.md:173`).

## A.4 Process leaves: real macros or behavioural stand-ins?

| Family | Macros catalogued | Topology | Status | Source |
|---|---|---|---|---|
| SKY130 OpenRAM | `sky130_sram_1kbyte_1rw1r_32x256_8` (id 1), `_2kbyte_1rw1r_32x512_8` (2), `_1kbyte_1rw1r_8x1024_8` (3) | 1RW1R; 1R1W and 1RW allowed, 2RW rejected | real macro names; manifest `status: OPEN_SOURCE_AVAILABLE`, `read_latency_cycles: 1`, output NOT held | `SL/rtl/mem/backends/asic/sram_macro_ids.svh:7-9`; `sram_leaf_sky130.sv:49-51`, `:62-81`; `SL/manifests/sky130_sram_1kbyte_1rw1r_32x256_8.json:7,14,76,105` |
| GF180MCU | `gf180mcu_fd_ip_sram__sram{64,128,256,512}x8m8wm1` (ids 10-13) | 1RW only | real; `OPEN_SOURCE_AVAILABLE` | `sram_macro_ids.svh:10-13`; `sram_leaf_gf180.sv:49-51`; `SL/manifests/gf180mcu_fd_ip_sram__sram512x8m8wm1.json:7,13,61` |
| IHP SG13G2 1P | 18 x `RM_IHPSG13_1P_*_bm_bist` (ids 20-37) | 1RW only | real; BIST pins tied off, functional pins used | `sram_macro_ids.svh:14-31`; `sram_leaf_ihp1p.sv:49-61` |
| IHP SG13G2 2P | 9 x `RM_IHPSG13_2P_*_bm_bist` (ids 60-68) | true 2RW (also 1R1W, 1RW) | real; `OPEN_SOURCE_AVAILABLE` | `sram_macro_ids.svh:32-40`; `SL/manifests/RM_IHPSG13_2P_1024x32_c2_bm_bist.json:7,14,187` |
| Commercial 130/65/28 nm | ids 90-92 | none | **placeholders**: `PENDING_NO_MACRO`; selecting them fails elaboration | `sram_macro_ids.svh:41-43`; `sram_asic_array.sv:74-76`; `SL/manifests/commercial_65nm_pending.json:7,13-14` |

What is actually in the tree: **pin-only `(* blackbox *)` stubs** with no behaviour (34 modules) for lint/synthesis (`SL/rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv:3-6`). Vendor Verilog models are **not included**; they are fetched on demand at pinned commits (`SL/scripts/mem/fetch_open_macros.sh:22-32`; `SL/README.md:118-120`). Provenance: SKY130 `efabless/sky130_sram_macros@ebfbf57`, GF180 `@9c41192`, IHP `IHP-Open-PDK@5e6d592` (`SL/docs/mem/02_backends_and_macros.md:22-24`). The GENERIC backend is a behavioural stand-in, not for silicon (`sram_defs.svh:16-18`).

Not shown: "timing closure against the Liberty views, LEF-based placement, power-pin connection, DRC/LVS, or behaviour of any macro in silicon" (`02_backends_and_macros.md:86-87`).

## A.5 MBIST

* `sram_mbist_march`: a demonstration controller (March C- 10N / MATS+ 5N), serial per target; "NOT a production MBIST" (`SL/rtl/mem/sram_mbist_march.sv:3`, `:11-13`, `:27-30`). Defaults: `NUM_TARGETS=1`, `DW=32`, `AW=10`, `READ_LATENCY=1` (`:36-44`).
* `sram_mbist_adapter`: TestCore collar bus to the memory test port, optional `IN_PIPE`/`OUT_PIPE`. Defaults `BUS_AW=16`, `BUS_DW=72`, `MEM_AW=10`, `MEM_DW=32` (`SL/rtl/mem/sram_mbist_adapter.sv:3-23`, `:29-36`).

## A.6 Other RTL

* `sram_if` + `sram_sp_if`: optional SV interface with master/slave/monitor modports and master-side assertions (`SL/rtl/mem/intf/sram_if.sv:13-59`, `:62-92`).
* `sfv_memory_subsystem_example`: a **structural template only**. It instantiates CTRL `sram_sp` 32x1024 and CPU `sram_sp` 32x4096 (both `RSP_FIFO_DEPTH=0`, `READ_LATENCY=1`), and a 4-master (CPU/vector/tensor/DMA) x 4-bank x 128b x 512 byte-addressed `sram_bank_controller` (32 KiB) with 6-target MBIST (`SL/rtl/mem/examples/sfv_memory_subsystem_example.sv:6-10`, `:25-29`, `:106-107`, `:123-124`, `:136-140`). "The example top itself has no dedicated testbench" (`SL/docs/mem/07_integration_silicaflux_v.md:68`).
* `sram_fpga_selftest_top`: one `sram_sp` 32x4096, latency 2, 8 pattern passes, UART report; `CLK_HZ=100_000_000` parameter (`SL/rtl/mem/fpga/sram_fpga_selftest_top.sv:27-33`). "NOT validated on hardware" (`:20-21`).
* SilicaFlux 2.5 integration: `memory_controller_sramlib.sf` replaces the inline bank arrays with `sram_backend_1rw` (128b x BANK_DEPTH data + 16b parity) (`SL/docs/mem/07_integration_silicaflux_v.md:23-26`). The MemoryFlow TB passes with an identical 150,843 checks for the baseline, GENERIC and FPGA variants (`SL/reports/mem/integration.md:7-11`).

## A.7 Assumed clock frequencies (SRAM library)

* No SDC: NOT FOUND.
* Arty A7 XDC: `create_clock -period 10.000` (100 MHz) (`SL/rtl/mem/fpga/constraints/arty_a7_100t_sram_selftest.xdc:18`). This is **assumed**: "This flow has NOT been run in Vivado or on a board" (`:13-14`).
* `sram_fpga_selftest_top` `CLK_HZ = 100_000_000` (`sram_fpga_selftest_top.sv:28`): **assumed**.
* Analysis table "macro-limited clock 108 MHz (GF180 spec, 3.3 V typ)" (`SL/reports/mem/analysis.md:11`), from the vendor `Tcyc` 9.24 ns for 512x8 (`SL/docs/mem/08_capacity_area_performance.md:11`). This is **vendor-datasheet derived, not measured**. SKY130/IHP clock rates were not extracted (`08_capacity_area_performance.md:11`).

## A.8 Verification status (SRAM library)

Testbenches (all self-checking) are in `SL/tb/mem/`:
* `tb_sram_sp`: phases P0-P10 (reset, single/consecutive/alternating r/w, walking 1/0, byte enables, boundaries + invalid, random + backpressure, MBIST hand-over, retention). Exact latency is checked when there is no backpressure (`SL/tb/mem/tb_sram_sp.sv:8-17`).
* `tb_sram_1r1w`: collision policies, starvation bound (`tb_sram_1r1w.sv:3-13`). `tb_sram_tdp`: w/w, w/r, r/r conflicts (`tb_sram_tdp.sv:3-8`). `tb_sram_banking`: per-master ID/order + workloads 0-6 (`tb_sram_banking.sv:3-18`). `tb_sram_mbist`: 7 fault models (`tb_sram_mbist.sv:3-13`). `tb_sram_fpga_selftest`: UART decode (`tb_sram_fpga_selftest.sv:3-9`).
* cocotb: `SL/tb/mem/cocotb/test_sram_random.py:1-12` (Python dict scoreboard, Icarus).
* Formal harnesses: `SL/formal/mem/fv_sram_sp.sv`, `fv_sram_1r1w.sv`, `fv_sram_tdp.sv`, `fv_bank_ctrl.sv`.

Evidence of executed results (in-tree reports; **no independent CI logs**):
* `SL/reports/mem/SUMMARY.md:5-17`: lint 47/0, sim 53/0, xsim 5/0, equiv 11/0, mutants 10/0, 2,731,959 scoreboard checks, cocotb 4/0, formal 9/0, synth 29/0, integration 3/0, workload 48/48. Generated 2026-11-05T20:23:07Z; "not a git checkout" (`SUMMARY.md:3`).
* Formal is **bounded**: BMC depth 20 (16 for the bank controller), PDR UNDECIDED (`SL/reports/mem/formal.md:9-19` [file lines]). The bank controller was proven only at 2x2.
* Vendor-model equivalence: 11 configurations with trace-identical GENERIC vs vendor models (`SL/reports/mem/regression.md:154-168`).
* Synthesis: ASIC macro-integrity with black boxes; FPGA inference with Yosys only (`SL/reports/mem/synth.md:35-63`).
* Tools missing in the producing environment: sby, openroad, vivado, quartus_sh (`SUMMARY.md:29-36`).
* CI: `SL/ci/github-actions-sramlib.yml` is a **template, "Not installed or run"** (`:3-6`); "prepared, not exercised" (`SL/docs/mem/09_status_and_next_actions.md:23`). No `.github/` directory exists (NOT FOUND).
* Provenance flag: report details embed agent-scratchpad paths (`<agent-path>`) (`SL/reports/mem/regression.md:58-59`). The runs therefore happened in the authoring agent's environment, not in a CI system.

## A.9 Python tooling (SRAM library)

`SL/scripts/mem/`: `common.py` (paths, provenance), `run_regress.py` (lint/sim/xsim/equiv/mutants), `run_formal.py` (Yosys+ABC BMC/PDR), `run_synth.py`, `run_cocotb.py`, `run_integration.py`, `sram_analysis.py` (capacity/area/bench), `build_manifests.py` (manifests from vendor sources), `build_catalog.py` (generates macro IDs/funcs/leaves/stubs), `make_summary.py`. Docstrings are at each file's lines 1-12. Also `SL/tb/mem/cocotb/test_sram_random.py`.

---

# Part B: SilicaFlux-V release 1 (`SV/`)

## B.0 Scope notes

* `sfv_soc_df.sv`: **NOT FOUND in `SV/`**. It exists in the separate DataFabric project at `DF/rtl/soc/sfv_soc_df.sv` (two identical copies with sha256 `d5a2a743…` in `x/`). From its header only: it is derived from `sfv_soc.sv` and replaces `sfv_xbar` with `sfb_crossbar` (SFB2, 4 masters, round-robin default). It adds a DMA master (master 3) and DFPERF performance counters (page 7), and `SRAM_IMPL=1` swaps the SRAM banks for sramlib `sram_sp` (`DF/rtl/soc/sfv_soc_df.sv:4-22`, params `:26-42`). `sfb_crossbar` keeps one outstanding transaction per master and per slave, and adds `rsp_ready` backpressure (`DF/rtl/interconnect/sfb_crossbar.sv:4-6`, `:19-23`). The rest of DataFabric was not audited.
* `sfv_sram_macro_bank.sv` is at `SV/asic/tech/{sky130,ihp_sg13g2}/` (not `rtl/`).
* The SRAM library is **not used** anywhere in `SV/`: grep for `sram_bank_controller|sram_defs.svh|sram_rsp_path` found nothing. SV has its own `sfv_sram_sp`, "derived from memoryflow sf_sram_1rw" (`SV/rtl/mem/sfv_sram_sp.sv:18-19`). The SRAM library's docs say SilicaFlux-V RTL was absent at the commit they inspected (`SL/docs/mem/00_repository_evidence.md:47`; `SL/docs/mem/09_status_and_next_actions.md:35`).

## B.1 Top-level SoC (`SV/rtl/top/sfv_soc.sv`)

* Parameters (defaults): `SRAM_BANKS=4`, `SRAM_BANK_WORDS=8192` (32 KiB/bank), `TSPM_WORDS=4096` (16 KiB), `ROM_WORDS=1024` (4 KiB), `LANES=4`, `MUL_W=32`, `GPIO_N=8`, `UART_BAUD_RESET=217` (`:19-28`).
* **Masters (3)**: M0 JTAG SBA (`M_DBG`, highest priority), M1 CPU data, M2 CPU instruction (lowest) (`SV/rtl/pkg/sfv_pkg.sv:44-47`). Instantiation: CPU `:117-126`, JTAG `:136-144`.
* **Slaves (NS = SRAM_BANKS+3 = 7)**: ROM, SRAM0..3, TSPM, PERIPH (`sfv_soc.sv:57-58`). Bases: ROM `0x0`, SRAM bank b at `SRAM_BASE + b*BANK_BYTES`, TSPM `0x2000_0000`, PERIPH `0x4000_0000` (`:65-72`). Masks: ROM `~(4096-1)`, banks `~(32768-1)`, TSPM `~(16384-1)`, PERIPH `PERIPH_MASK` (`:73-79`).
* Execute-never: the CPU-I port to PERIPH is disabled (`:81-84`).
* Interconnect: `sfv_xbar` (`:105-110`). Boot ROM `sfv_bootrom` (`:147-152`). MBIST `sfv_mbist`, group 0 = main SRAM, group 1 = TSPM (`:169-176`). SRAM banks: `sfv_sram_slave` x SRAM_BANKS (`:180-190`). Peripheral bridge (`:204-210`). Tile (`:282-293`).
* Peripherals: SYSCTRL, INTC (N=8), TIMER, UART, SPI, GPIO, plus VE/TE pages (`:200-203`, `:231-279`).
* **Clock domains**: a single functional `clk` + JTAG `tck` (`:10`; `SV/docs/CLOCK_RESET.md:4-8`). Two ICG-gated derived clocks `gclk_ve`, `gclk_te` (`SV/rtl/accel/sfv_tile.sv:67-69`). No PLL (`CLOCK_RESET.md:6`). Resets: por/sys/cpu, async assert / sync deassert (`sfv_soc.sv:86-92`).

### Address map (`SV/rtl/pkg/sfv_pkg.sv:23-41`; `SV/docs/MEMORY_MAP.md:7-19`)

| Base | Size (decoded in `sfv_soc`) | Region |
|---|---|---|
| `0x0000_0000` | 4 KiB | Boot ROM (reset vector) |
| `0x1000_0000` | 128 KiB = 4 x 32 KiB contiguous banks at +0x0/+0x8000/+0x10000/+0x18000 | SRAM |
| `0x2000_0000` | 16 KiB, 4-way word-interleaved | TSPM |
| `0x4000_0000` | 128 KiB window, 4 KiB pages `addr[16:12]`: SYSCTRL 0, INTC 1, TIMER 2, UART 3, SPI 4, GPIO 5, VE 16, TE 17 | Peripherals |

Inconsistency: `sfv_pkg` defines `ROM_MASK = 0xFFFF_C000` (16 KiB) and `TSPM_MASK = 0xFFFF_0000` (64 KiB) (`sfv_pkg.sv:25`, `:28`). These are **unused**: Verilator reports UNUSEDPARAM (`SV/reports/lint/verilator_lint.log:18`, `:22`), and the SoC decodes 4 KiB / 16 KiB (`sfv_soc.sv:75`, `:77`). DMA: not included (`MEMORY_MAP.md:20-22`).

## B.2 Interconnect (`SV/rtl/bus/sfv_xbar.sv`) and SFB protocol

* **Bus width**: 32-bit address, 32-bit data, 4-bit byte enable (`sfv_xbar.sv:40-45`).
* **Protocol signals** (SFB, "OBI-style"): request `req, addr, we, be, wdata -> gnt` (transfer on `req & gnt`); response `rvalid, rdata, err`, **one per transfer, in order, >= 1 cycle after gnt, never stalled** (no response backpressure) (`sfv_xbar.sv:4-8`; `SV/docs/BUS.md:6-30`).
* **Max outstanding**: **1 per master and 1 per slave**. A new transfer can be granted in the cycle the previous response returns (`sfv_xbar.sv:15-18`). Code: `m_free = ~out_q | m_rvalid` (`:106`), `s_free = ~busy_q | s_rvalid` (`:120`).
* **Address decode**: `(addr & SLV_MASK[s]) == SLV_BASE[s]` AND `MST_SLV_EN`; the loop runs `s = NS-1 .. 0`, so the lowest index wins ("first match wins"). No match gives a decode error (`:11-14`, code `:75-87`).
* **Arbitration (exact code)**: fixed priority per slave, master 0 highest (`:19-22`):
  ```systemverilog
  for (int m = NM - 1; m >= 0; m--) begin
    if (m_req[m] && m_free[m] && m_hit[m] && m_sel[m] == SW'(s)) win[s] = '0;
    if (m_req[m] && m_free[m] && m_hit[m] && m_sel[m] == SW'(s)) win[s][m] = 1'b1;
  end
  ```
  (`sfv_xbar.sv:113-116`). The lowest-numbered requesting master overwrites the winner. Grant: `m_gnt[m] = derr_gnt | (win & s_req & s_gnt)` (`:143-150`).
* **Ordering**: no IDs; with a single outstanding transaction, "responses can never be re-ordered" (`:15-17`).
* **Decode-error latency**: 1 cycle after grant (`derr_q`) (`:23-24`, `:163`).
* Peripheral bridge: `gnt = 1`, registered response 1 cycle after grant, sub-word writes return a bus error (`SV/rtl/bus/sfv_periph_bridge.sv:4-12`, `:45`, `:54-64`).

## B.3 CPU (`SV/rtl/cpu/sfv_cpu.sv`)

* **ISA**: RV32I (RV32E option) + Zicsr, M-mode only. FENCE is a NOP; FENCE.I flushes the 2-entry prefetch buffer. **No M extension** (`:4-6`; `SV/docs/ARCHITECTURE.md:58-60`).
* **Pipeline**: 2 stages, in order. IF has 1 outstanding instruction request and a 2-entry fetch buffer. EX does decode/ALU/CSR/blocking load-store/trap/write-back (`:7-14`). CPI: ALU 1, load/store 2 (+wait states), taken branch/jump 3 (`:15`).
* **Memory interface**: two SFB ports (I and D) (`:26-28`, ports `:44-60`).
* **Outstanding**: I-port 1 (`i_req = (!out_q || i_rvalid) && (fb_after <= 1)`, `:104`). D-port 1, blocking (`d_req = ls_go && !lsu_wait_q`, `:434`; wait state `:535-537`).
* Traps: precise; mcause 0-7, 11; MSI/MTI/MEI (`:16-25`).
* **Performance counters**: 64-bit `mcycle`, `minstret`, readable at 0xB00/0xB02/0xB80/0xB82 and the user aliases 0xC00/0xC02/0xC80/0xC82, plus `mcountinhibit` 0x320 (`:337-338`, `:356`, `:362-365`, `:541-542`). `mhpmcounter3+`: NOT FOUND (no case entries).
* **Trace**: retirement trace outputs `rt_valid, rt_pc, rt_insn, rt_trap, rt_cause, rt_rd, rt_rd_wdata, rt_rd_we` ("verification only") (`:67-75`). These are **left unconnected in `sfv_soc`** (`SV/rtl/top/sfv_soc.sv:125`) and used by `tb_cpu` `+trace` (`SV/tb/cpu/tb_cpu.sv:10`, `:38`).
* Dangling reference: the header cites `docs/REUSE_MATRIX.md` (`:32-33`). That file is NOT FOUND in `SV/docs/`.

## B.4 Memories

* `sfv_sram_sp` (`SV/rtl/mem/sfv_sram_sp.sv`): **1RW**, 32-bit word, 4 byte enables, `DEPTH` param (default 1024). **Read data valid the NEXT cycle (latency 1)**, no hold, no write-through (`:4-9`, `:23-34`). The default is an inference template ("NOT for ASIC"). `SFV_SRAM_MACRO` selects `sfv_sram_macro_bank` (`:11-17`, `:35-38`). A sim-only stuck-at fault hook is excluded under `SYNTHESIS` (`:54-70`).
* `sfv_sram_slave` (`SV/rtl/mem/sfv_mem_slaves.sv:14`): "1 cycle latency, back-to-back accesses" (`:9`). `gnt = !bist_en` (`:42`), `rvalid <= req && gnt` (`:61`), `rdata = rd_q ? q : 0` (`:65`), `err = 0` (`:66`). The MBIST collar takes the bank while `bist_en` (`:10-12`).
* `sfv_bootrom` (`sfv_mem_slaves.sv:77`): `gnt = 1` (`:98`), 1-cycle response (`:107`), writes give an error (`:108`). The image is a generated combinational module (`:71-76`) and is **not an SRAM**.
* **SRAM read latency at the bus**: 1 cycle from grant to `rvalid` for SRAM, TSPM, ROM, peripherals and decode errors (`sfv_mem_slaves.sv:61`, `:107`; `SV/rtl/accel/sfv_tile.sv:137`; `sfv_periph_bridge.sv:60`; `sfv_xbar.sv:163`).
* **ASIC macro banks**:
  * SKY130 (`SV/asic/tech/sky130/sfv_sram_macro_bank.sv`): 4 words folded into a 128-bit row of `sky130_sram_1rw1r_128x256_8`, depth tiled; port 1 (read-only) unused/disabled (`:1-7`, `:20-23`, `:43-46`). The **in-repo model is a "BEHAVIOURAL stand-in"** (`SV/asic/tech/sky130/models/sky130_sram_1rw1r_128x256_8.v:1-3`). The flow takes the lib/LEF from ORFS `sky130ram` (`SV/asic/configs/sky130hd.cfg:7`, `:10`). This macro is not among the 3 SKY130 macros in the SRAM library's catalogue (`SL/docs/mem/02_backends_and_macros.md:22`).
  * IHP SG13G2 (`SV/asic/tech/ihp_sg13g2/sfv_sram_macro_bank.sv`): 2 words per 64-bit row; macro = 2048/1024/512/256 x64 by folded depth; BIST port tied off (`:1-8`, `:22-25`, `:46-71` [file lines]). Simulated with the "IHP vendor functional SRAM models" (`SV/docs/VERIFICATION_REPORT.md:22`).
* **Total SRAM instantiated (default parameters)**: main SRAM 4 banks x 8192 x 32b = **128 KiB** (`sfv_soc.sv:20-21`, `:180-190`). TSPM 4 banks x 1024 x 32b = **16 KiB** (`sfv_soc.sv:22`; `sfv_tile.sv:6-7`, `:161`). Total **144 KiB** (`SV/docs/PROCESS_NODE_COMPARISON.md:28`). ROM is 4 KiB of logic.
  * Banking: main SRAM uses **high-order/contiguous** banks; each bank is its own crossbar slave at +32 KiB (`sfv_soc.sv:69`; `MEMORY_MAP.md:10`). TSPM uses **low-order word interleave**, bank = byte addr[3:2] (`sfv_tile.sv:6-7`, `:126-127`).
  * Macro counts from synthesis: IHP 8 x 2048x64 + 4 x 512x64 = 12 macros, 4.533 mm² (`SV/reports/synth/ihp_sg13g2/summary.md:11-13`). SKY130: 36 x 128x256, 25.996 mm² (`SV/reports/synth/sky130hd/summary.md:11-12`).
* Memory port topology: **every SRAM is 1RW single-port**. On SKY130 the second (1R) port of the 1RW1R macro is unused.

## B.5 Compute tile, vector engine, tensor engine

* **Tile** (`SV/rtl/accel/sfv_tile.sv`): TSPM has `NB = LANES = 4` word-interleaved single-port banks (`:6-7`, `:24-30`). Per bank and cycle, the **fixed priority** is MBIST > engine holding the TSPM lock > SFB fabric port (`:8-15`). Lock arbitration is **TE > VE** on a same-cycle tie, held until the engine drops its request (`:96-112`). Fabric `gnt = !bist_en && !en_ce[f_bank]` (`:128`), `rvalid` 1 cycle later (`:137`). Per-engine ICG (`:67-69`).
* **Vector engine** (`SV/rtl/accel/sfv_vec_engine.sv`): `LANES=4` x 32-bit SIMD, `MUL_W=32` (`:34-37`). Memory-to-memory over TSPM: one beat = LANES consecutive words = one row across the 4 banks (`:4-5`). Ops ADD SUB MUL MIN MAX AND OR XOR SLL SRA SRL DOT (`:17`; `sfv_pkg.sv:61-73`). Latency `CYCLES = 3 + B*P (+1 DOT+WRES)`, `B = ceil(LEN/LANES)`, `P = 3/2/1` (`:25-30`). Throughput 4/3 to 4 elements/cycle (`SV/docs/ACCELERATORS.md:43`). Memory access path: engine port `e_ce[LANES], e_we, e_row, e_wdata, e_rdata` to the TSPM banks via the lock (`:52-59`). The engine has no SFB master port; the CPU must stage operands.
* **Tensor engine** (`SV/rtl/accel/sfv_tensor_engine.sv`): **4x4 output-stationary MAC array**, operands **INT8/UINT8** per operand (A_UNSIGNED / B_UNSIGNED), **32-bit accumulators** (`:2-11`, `sfv_mac_array` `:41-73`). Operand loading: A read column-wise (word k at `A_ADDR + k*A_STRIDE`), B row-wise (`:6-10`). K 1..1024 (`:22`). Latency `CYCLES = 3 + 2K (+4 with WB)`. Peak 16 MAC per 2 cycles = 8 MAC/cycle (A and B fetched sequentially) (`:25-30`; `ACCELERATORS.md:62-63`). Results in ACC0..15 or written back (`:12-14`).
* Accelerator perf counters: VE `CYCLES` RO at 0x24 (`sfv_vec_engine.sv:15`). TE `CYCLES` RO at 0x28 (`sfv_tensor_engine.sv:24`).

## B.6 Clock gating (`SV/rtl/common/sfv_clkgate.sv`)

Latch-based ICG model (`gclk = clk & en_l`, latch transparent while clk low), `test_en` forces it on, and `SFV_NO_CLOCK_GATE` gives `gclk = clk` (`:4-8`, `:14-16`, `:28-39`). Tech mappings: `sky130_fd_sc_hd__sdlclkp_1` (`SV/asic/tech/sky130/sfv_clkgate.sv:2-4`), `sg13g2_slgcp_1` (`SV/asic/tech/ihp_sg13g2/sfv_clkgate.sv:2-4`). The enable is `sel || busy || cg_off` (`sfv_tile.sv:68-69`). The header references `scripts/check_latches.py` (`sfv_clkgate.sv:11`), which is NOT FOUND in `SV/scripts/`.

## B.7 Peripherals and debug

UART (8N1, `FIFO_DEPTH=4`, `BAUD_RESET=217` for 25 MHz/115200) (`SV/rtl/periph/sfv_uart.sv:2`, `:19-21`). SPI master modes 0-3 (`sfv_spi.sv:2-10`). GPIO (N=8), CLINT-style timer, level INTC (`sfv_periph_misc.sv:3-5`, `:13-14`, `:72`, `:136-137`). SYSCTRL holds IDs, boot mode, TEST_STATUS, soft reset, BUSERR capture and MBIST control (`SV/docs/MEMORY_MAP.md:24-37`). MBIST is March C- 10N over 4 banks in parallel with read latency 1 (`SV/rtl/mem/sfv_mbist.sv:12-15`, `:21-23`). JTAG has a TAP (IDCODE, BYPASS) plus SBA (66-bit DR, 1 command in flight, refused while busy) and DBGCTRL. There is no boundary scan and no RISC-V DM (`SV/rtl/debug/sfv_jtag.sv:4-22`). Reference mismatch: `sfv_jtag.sv:22` says BSR/DM are "ISS-005/006", but the issue register has them as ISS-004 and ISS-009 (`SV/docs/ISSUE_REGISTER.md:13`, `:18`). `sfv_uart.sv:4` cites `docs/REGISTER_MAP.md`, which is NOT FOUND (the map is in `docs/MEMORY_MAP.md`).

Monitor/trace outputs at SoC level: `test_pass`, `test_fail`, `test_status[31:0]`, `cpu_sleep` (`sfv_soc.sv:51-54`), SYSCTRL BUSERR_ADDR/INFO (`MEMORY_MAP.md:34`), and xbar `err_evt/err_addr/err_master/err_we` (`sfv_xbar.sv:57-61`). **No bus-level performance counters in `sfv_soc`** (NOT FOUND). DataFabric adds `sfb_perf_counters` (`DF/rtl/soc/sfv_soc_df.sv:377`).

## B.8 Assumed / measured clock frequencies (SilicaFlux-V)

| Source | Quote | Measured or assumed |
|---|---|---|
| `SV/asic/constraints/sfv_soc.sdc:2-5` | "CLK_PERIOD is set by the flow (default 20 ns = 50 MHz)"; `tck` period 100.0 (10 MHz) | constraint (assumed target) |
| `SV/asic/configs/sky130hd.cfg:15`, `ihp_sg13g2.cfg:15` [file lines] | `CLK_PERIOD_NS=${CLK_PERIOD_NS:-20.0}` | assumed |
| `SV/asic/configs/commercial_130nm.cfg.template:19` / `commercial_65nm.cfg.template:19` | "15.0 # 66 MHz target" / "6.67 # 150 MHz target" | assumed (templates) |
| `SV/reports/synth/ihp_sg13g2/summary.md:16,20` | slack +6.579 ns @ 20 ns; "estimated Fmax 74.5 MHz, DERIVED 1/(T − slack), ideal clocks, typical corner" | tool-derived **post-placement estimate**, not signoff (`summary.md:3-5`) |
| `SV/reports/synth/sky130hd/summary.md:15,19` | slack −6.76 ns; Fmax 37.4 MHz (misses 50 MHz) | tool estimate |
| `SV/reports/synth/sky130hd_mini32k/summary.md:15,19` | slack −5.179 ns; Fmax 39.7 MHz | tool estimate |
| `SV/docs/PROCESS_NODE_COMPARISON.md:17` | "[E] 45–55 MHz signoff at ss/125 °C after CTS → 50 MHz target"; 65 nm "[E] 150–200 MHz" | **engineering estimate** ([E] = estimate, `:3-6`) |
| `SV/docs/ARCHITECTURE.md:96` | "functional clock (50 MHz target @130 nm)" | assumed target |
| `SV/fpga/ulx3s/ulx3s_v20.lpf:10` | `FREQUENCY PORT "clk_25mhz" 25 MHZ;` | constraint |
| `SV/reports/fpga/nextpnr_key.log:118-119` | "Max frequency ... clk_25mhz: 39.24 MHz (PASS at 25.00 MHz)"; tck 93.39 MHz | nextpnr post-route **tool report** (an earlier pass in the same log reports 25.66 MHz, `:12`). **Not hardware-tested** (`SV/docs/FPGA.md:3-5`; ISS-007 `ISSUE_REGISTER.md:16`) |
| `SV/rtl/periph/sfv_uart.sv:21`; `SV/README.md:70` | 217 = 115200 Bd @ 25 MHz | assumed |

Critical path: TSPM SRAM Q (3.9 ns) to the vector-lane multiplier. On SKY130 the macro launches on the falling edge, giving a half-cycle path (`SV/docs/ASIC_FLOW.md:39`, `:48-51`). SKY130 SRAM power of 325 mW is flagged "not credible" (`ASIC_FLOW.md:43`).

## B.9 Verification status (SilicaFlux-V)

Testbenches/harnesses: `SV/tb/cpu/tb_cpu.sv` (randomized grant/latency SFB slaves, riscv-tests tohost, `:4-10`), `SV/tb/soc/tb_soc.sv` (firmware-level, UART/SPI-flash/JTAG models, `:4-18`), and cocotb `SV/tb/unit/test_tile.py`, `test_xbar.py`, `test_periph.py`, `test_mbist.py` (docstrings `:1-8`). Golden model: `SV/tb/models/sfv_golden.py:1-5`. Formal: `SV/formal/fv_xbar.sv`, `fv_cpu_bus.sv`, `fv_fifo.sv`, `fv_tap.sv` + `.sby`.

Executed-result evidence (in-tree logs; **CI not installed**):
* `SV/reports/REGRESSION_SUMMARY.md:3-21` [file lines]: generated 2026-11-05 16:43:27 UTC; firmware, lint, riscv-tests 55/0, soc-firmware 6/6 (432 app checks), no-clock-gate, sky130-macro-tiling, IHP vendor SRAM models, Icarus smoke, cocotb tile 3/3, xbar 1/1, periph 3/3, mbist 1/1, formal; **OVERALL: PASS**.
* Raw logs: `SV/reports/sim/riscv_tests.txt` (55 PASS, "TOTAL pass=55 fail=0"); `SV/reports/sim/soc_regression.txt:1-8` (6 scenarios PASS, `cycles=3101307` for SPI boot); `SV/reports/sim/cocotb_tile.log` (TESTS=3 PASS=3); `SV/reports/formal/formal_summary.txt:1-5` (sby DONE PASS x5).
* Formal: `sfv_xbar` 3x2 PDR **unbounded proof**. `sfv_cpu` bus protocol **bounded BMC depth 16 only**; PDR did not converge (`SV/docs/VERIFICATION_REPORT.md:47`, `:50`).
* Not verified: gate-level sim, post-route timing/power, FPGA hardware execution, formal of CPU/accelerators, CDC/RDC tooling, coverage metrics (`VERIFICATION_REPORT.md:62-65`).
* CI: `SV/ci/github-actions.yml:1` says "Copy to .github/workflows/silicaflux-v.yml". No `.github/` directory exists (NOT FOUND), so the workflow is **not installed**.
* Provenance flag: `cocotb_tile.log` ends with `make` paths under `<agent-path>` (tail of `SV/reports/sim/cocotb_tile.log`). The runs happened in an agent environment, not in CI.
* FPGA bitstream: the sha256 in `SV/reports/fpga/sfv_ulx3s.bit.sha256` matches the file (`faed2a4e…`, recomputed during this audit).

## B.10 Python tooling (SilicaFlux-V)

`SV/scripts/asic_summary.py` (ASIC run summary), `bin2hex.py`, `check_map.py` (RTL vs firmware map cross-check), `gen_post_vectors.py` (POST vectors from the golden model), `gen_rom.py` (boot-ROM SV image), `mkimage.py` (SPI boot image). Docstrings are at lines 1-6 of each. Also `SV/tb/models/sfv_golden.py` and the cocotb tests in `SV/tb/unit/*.py`.

---

# Part C: Cross-cutting findings / inconsistencies

1. **sfv_soc_df.sv is not in the SilicaFlux-V release**. It lives in DataFabric (`DF/rtl/soc/sfv_soc_df.sv`, §B.0).
2. **The SRAM library and SilicaFlux-V are not integrated.** SV uses its own `sfv_sram_sp` (1-cycle, no handshake/credits). The SRAM library's `sfv_memory_subsystem_example` (4-master banked scratchpad incl. DMA) is an illustrative template with no testbench (`SL/docs/mem/07_integration_silicaflux_v.md:68`). It does not match SV's actual structure: SV has no DMA (`SV/docs/MEMORY_MAP.md:20`), a 128 KiB main SRAM and a 16 KiB TSPM. The only bridge is DataFabric `SRAM_IMPL=1` (`DF/rtl/soc/sfv_soc_df.sv:17-20`).
3. **Interconnect concurrency is minimal in SV**: 1 outstanding per master/slave, fixed priority, no response backpressure (`SV/rtl/bus/sfv_xbar.sv:15-22`). The SRAM library's bank controller supports `RSP_FIFO_DEPTH` credits, IDs and RR arbitration (`SL/rtl/mem/sram_bank_controller.sv:15-32`).
4. **Dangling doc/script references in SV**: `docs/REUSE_MATRIX.md` (`sfv_cpu.sv:33`), `docs/REGISTER_MAP.md` (`sfv_uart.sv:4`), `scripts/check_latches.py` (`sfv_clkgate.sv:11`). All are NOT FOUND. JTAG cites the wrong ISS IDs (§B.7).
5. **Unused package windows**: `ROM_MASK` (16 KiB) and `TSPM_MASK` (64 KiB) disagree with the decoded 4 KiB / 16 KiB (§B.1).
6. **SKY130 macro in SV** (`sky130_sram_1rw1r_128x256_8`) has only a behavioural stand-in in-tree, and its SoC macro simulation used that stand-in (`SV/docs/VERIFICATION_REPORT.md:22`). The SRAM library catalogues different SKY130 macros (`SL/docs/mem/02_backends_and_macros.md:22`).
7. **All timing figures are estimates or constraints**, not signoff: post-placement, ideal clocks, typical corner (`SV/reports/synth/*/summary.md:3-5`; ISS-001 `SV/docs/ISSUE_REGISTER.md:10`). No hardware (FPGA or silicon) measurement exists in either tree.
8. **Both CI configs are uninstalled templates**. Pass/fail evidence is limited to in-tree reports produced in agent scratchpad environments.

---

# Summary table (one row per module)

Abbreviations: RL = READ_LATENCY; v/r = valid/ready; "1/1" = one outstanding per master and per slave.

| Module | Path | Clock domain | Bus width | Req/rsp protocol | Max outstanding | SRAM read latency | Memory port topology | Arbitration | Ordering rules | Verification status |
|---|---|---|---|---|---|---|---|---|---|---|
| sram_sp | `SL/rtl/mem/sram_sp.sv` | single `clk` | `DATA_WIDTH` (def 32), mask DW/8 | v/r req (`req_*`) + v/r rsp (`rsp_*`, id, err, we) | `RSP_FIFO_DEPTH` (def RL+1=2); posted writes need no credit | RL cycles (def 1) | 1RW | n/a (single port; test port preempts) | in acceptance order, 1 rsp per req | sim 29 configs, formal BMC-20 x3, cocotb x2, xsim, equiv (`SL/reports/mem/regression.md`, `formal.md`) |
| sram_1r1w | `SL/rtl/mem/sram_1r1w.sv` | single `clk` | `DATA_WIDTH` | `wr_*` v/r posted + `rd_*` v/r + `rsp_*` | reads: RSP_FIFO_DEPTH (def 2); writes posted | RL (def 1) | 1R1W | collision STALL with alternating priority (def) / READ_OLD / FORBID | read sees only earlier-cycle writes | sim 7 configs, formal x3 policies, equiv on SKY130/IHP 2P |
| sram_tdp | `SL/rtl/mem/sram_tdp.sv` | single `clk` | `DATA_WIDTH` | two independent sram_sp-style ports | per port RSP_FIFO_DEPTH (def 2) | RL (def 1) | 2RW (ASIC: IHP 2P only) | STALL alternating priority (def) / FORBID | per port in order; conflicting pair = sequential, later write wins | sim 4 configs, formal BMC-20, equiv IHP 2P |
| sram_rsp_path | `SL/rtl/mem/sram_rsp_path.sv` | single `clk` | `DATA_WIDTH` | internal issue/stage to v/r rsp | FIFO_DEPTH credits | LATENCY (>=1) | n/a | n/a | strict acceptance order | covered via wrappers + embedded assertions |
| sram_bank_controller | `SL/rtl/mem/sram_bank_controller.sv` | single `clk` | `DATA_WIDTH` (def 32), ADDR_WIDTH derived | per-master v/r req + v/r rsp with `m_rsp_id` | per master RSP_FIFO_DEPTH (def 2); no request queue | RL (def 1) | NUM_BANKS x 1RW (def 4 banks x 1024) | per-bank RR (def) or fixed (m0 highest) | per-master acceptance order (by construction) | sim 10 configs, formal 2x2 BMC-16, cocotb x2, 48 workload runs |
| sram_backend_{1rw,1r1w,2rw} | `SL/rtl/mem/sram_backend_*.sv` | single `clk` | `DATA_WIDTH` | raw `ce/we/wmask/addr/wdata->rdata` (no handshake) | n/a (1 access/port/cycle) | exactly RL, not held | 1RW / 1R1W / 2RW | none | n/a | via wrappers; lint |
| sram_generic_* | `SL/rtl/mem/backends/generic/` | single `clk` | `DATA_WIDTH` | raw | n/a | RL | 1RW/1R1W/2RW (behavioural, flops) | none | 1R1W read-first (old word) | sim sweep, mutants |
| sram_fpga_* | `SL/rtl/mem/backends/fpga/` | single `clk` | `DATA_WIDTH` | raw | n/a | RL (1=BRAM, 2=+out reg) | 1RW/1R1W/2RW BRAM inference | none | 1R1W old word | Yosys inference only; no vendor tool / board |
| sram_asic_array | `SL/rtl/mem/backends/asic/sram_asic_array.sv` | single `clk` | `DATA_WIDTH`, tiled NCxNR | raw | n/a | macro latency 1 + (RL-1) flops | MODE 0/1/2 by macro | none | n/a | equiv 11 configs vs vendor models; synth macro integrity |
| sram_leaf_sky130 | `.../asic/sram_leaf_sky130.sv` | single `clk` | macro 32 or 8 b | macro pins (csb/web active low) | n/a | 1 (not held) | 1RW1R (2RW rejected) | none | cross-port collision undefined | equiv vs OpenRAM model (fetched) |
| sram_leaf_gf180 | `.../asic/sram_leaf_gf180.sv` | single `clk` | 8 b | macro pins (CEN/GWEN/WEN) | n/a | 1 | 1RW only | none | n/a | equiv vs vendor model |
| sram_leaf_ihp1p / ihp2p | `.../asic/sram_leaf_ihp{1p,2p}.sv` | single `clk` | 8-64 b | macro pins (MEN/WEN/REN active high) | n/a | 1 | 1P: 1RW; 2P: 2RW | none | 2P conflicts not handled by macro | equiv vs IHP models |
| macro blackboxes | `.../asic/stubs/sram_macro_blackboxes.sv` | n/a | per macro | pin-only stubs | n/a | n/a (no behaviour) | per macro | n/a | n/a | lint/synth only |
| sram_if / sram_sp_if | `SL/rtl/mem/intf/sram_if.sv` | single `clk` | param | sram_sp channels + modports | as sram_sp | as sram_sp | 1RW | n/a | as sram_sp | assertions only (no dedicated TB) |
| sram_mbist_march | `SL/rtl/mem/sram_mbist_march.sv` | single `clk` | DW (def 32) | TestCore collar test bus | 1 op/cycle | compares at RL | n/a | serial targets | n/a | tb_sram_mbist 2 configs, 7 fault models |
| sram_mbist_adapter | `SL/rtl/mem/sram_mbist_adapter.sv` | single `clk` | BUS 72 / MEM 32 | collar bus to tst_* | n/a | RL + IN_PIPE + OUT_PIPE | n/a | n/a | n/a | via tb_sram_mbist |
| sfv_memory_subsystem_example | `SL/rtl/mem/examples/sfv_memory_subsystem_example.sv` | single `clk` | 32 (ctrl/cpu), 128 (SPM) | sram_sp / bank controller | ctrl/cpu FIFO 0; SPM def 2/master | 1 | 2 x 1RW + 4-bank 1RW | SPM RR | per master | lint + Yosys synth only; **no TB** |
| sram_fpga_selftest_top | `SL/rtl/mem/fpga/sram_fpga_selftest_top.sv` | `clk` (100 MHz assumed) | 32 | internal sram_sp | WRITE_ACK=0 | 2 | 1RW BRAM | n/a | n/a | sim TB; Yosys xc7; **not on board** |
| sfv_soc | `SV/rtl/top/sfv_soc.sv` | `clk` + `tck`; ICG `gclk_ve/te` | 32 addr / 32 data / 4 be | SFB req/gnt + rvalid/rdata/err | 1 per master, 1 per slave | 1 cycle | all 1RW (128 KiB main + 16 KiB TSPM) | xbar fixed priority (JTAG > CPU-D > CPU-I) | in order, no IDs | riscv-tests 55/55, SoC fw 6/6, Icarus smoke (`SV/reports/REGRESSION_SUMMARY.md`) |
| sfv_xbar | `SV/rtl/bus/sfv_xbar.sv` | `clk` | 32/32/4 | SFB (no rsp backpressure) | 1/1 | n/a | n/a | fixed priority, master 0 highest (`:113-116`) | in order by construction | formal PDR proof (3x2), cocotb 3 masters x 1500 txn |
| sfv_cpu | `SV/rtl/cpu/sfv_cpu.sv` | `clk` | 2 x SFB 32-bit (I, D) | SFB master | I: 1, D: 1 (blocking) | load CPI 2 at 1-cycle memory | n/a | n/a | in-order, precise traps | riscv-tests 55/55 x 6 bus profiles; formal bus BMC-16 |
| sfv_sram_sp | `SV/rtl/mem/sfv_sram_sp.sv` | `clk` | 32 b, 4 be | raw ce/we/be/addr/wdata->rdata | n/a | 1 (next cycle, not held) | 1RW | n/a | n/a | via SoC fw + MBIST |
| sfv_sram_slave | `SV/rtl/mem/sfv_mem_slaves.sv:14` | `clk` | 32 | SFB slave, `gnt=!bist_en` | 1 (xbar-enforced) | 1 | 1RW, 8192 x 32 per bank | MBIST preempts | in order | SoC fw; MBIST fault scenarios |
| sfv_bootrom | `SV/rtl/mem/sfv_mem_slaves.sv:77` | `clk` | 32 | SFB slave, `gnt=1` | 1 | 1 (logic ROM) | ROM (combinational image) | n/a | in order | SoC boot scenarios |
| sfv_sram_macro_bank (SKY130) | `SV/asic/tech/sky130/sfv_sram_macro_bank.sv` | `clk` | 32 (128-b macro rows) | raw | n/a | 1 (macro output on falling edge, `ASIC_FLOW.md:48`) | 1RW1R macro used as 1RW | n/a | n/a | SoC fw with **behavioural stand-in**; synth/place est. |
| sfv_sram_macro_bank (IHP) | `SV/asic/tech/ihp_sg13g2/sfv_sram_macro_bank.sv` | `clk` | 32 (64-b rows) | raw | n/a | 1 | 1RW (IHP 1P) | n/a | n/a | SoC fw with IHP vendor functional models; synth/place est. |
| sfv_tile | `SV/rtl/accel/sfv_tile.sv` | `clk` + `gclk_ve/te` | 32 fabric; 4 x 32 engine | SFB slave + engine lock port | 1 (xbar) | 1 | 4 x 1RW, low-order interleave | MBIST > lock owner > fabric; lock TE > VE | engine deterministic; fabric in order | cocotb tile 200 vec + 100 tensor cmds |
| sfv_vec_engine | `SV/rtl/accel/sfv_vec_engine.sv` | `gclk_ve` | 4 lanes x 32 | register bus + TSPM engine port | 1 command | TSPM 1 | uses 4 TSPM banks | via tile lock | sequential beats | cocotb tile, fw T4, POST |
| sfv_tensor_engine | `SV/rtl/accel/sfv_tensor_engine.sv` | `gclk_te` | 4x4 INT8/UINT8, 32-b acc | register bus + TSPM engine port | 1 command | TSPM 1 | uses TSPM banks | via tile lock | 3+2K (+4) cycles | cocotb tile, fw T5, POST |
| sfv_periph_bridge | `SV/rtl/bus/sfv_periph_bridge.sv` | `clk` | 32 (word-only) | SFB slave to reg bus | 1 | n/a (1-cycle rsp) | n/a | n/a | in order | cocotb periph, fw |
| sfv_mbist | `SV/rtl/mem/sfv_mbist.sv` | `clk` | 32 x 4 banks | broadcast bist_* | n/a | compares at 1 | collar on 1RW | groups (SRAM / TSPM) | n/a | cocotb mbist; SoC fault detect x2 |
| sfv_jtag_tap / sfv_jtag_dbg | `SV/rtl/debug/sfv_jtag.sv` | `tck` + `clk` (toggle CDC) | 32 (SBA) | SFB master (SBA) | 1 (busy refuses) | n/a | n/a | highest xbar priority | n/a | formal TAP PDR; SoC JTAG scenario |
| sfv_clkgate | `SV/rtl/common/sfv_clkgate.sv` | `clk` to `gclk` | n/a | n/a | n/a | n/a | n/a | n/a | n/a | no-clock-gate equivalence (identical cycles 3,101,307) |
| UART/SPI/GPIO/TIMER/INTC/SYSCTRL | `SV/rtl/periph/*.sv` | `clk` | 32 reg bus | rb_sel/rb_we/rb_addr/rb_wdata to rb_rdata/rb_err | n/a | n/a | n/a | n/a | n/a | cocotb periph 3/3; fw T2/T6/T7 |
| sfv_soc_df | **NOT FOUND in `SV/`**; `DF/rtl/soc/sfv_soc_df.sv` | `clk` + `tck` | 32 | SFB2 (adds rsp_ready) | 1/1 (`DF/.../sfb_crossbar.sv:19-23`) | SRAM_LATENCY (def 1) | 1RW (`SRAM_IMPL=1`: sramlib sram_sp) | RR default (`ARB_MODE=1`) | in order | not audited (out of scope) |
