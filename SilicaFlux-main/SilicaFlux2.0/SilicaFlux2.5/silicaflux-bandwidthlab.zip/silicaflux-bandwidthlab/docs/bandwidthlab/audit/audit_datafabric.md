# Source audit: SilicaFlux DataFabric (SFB2 bus and DMA)

Scope: the SilicaFlux DataFabric bus and DMA RTL, the testbenches, the Python, cocotb and trace tooling, the docs, the Makefiles and the reports.
Method: I read the source only. Nothing in the extract was executed or simulated. The only computation was an independent re-implementation of the report's source-hash algorithm (§14.4), written in my own scratch script.

## 0. Extract, duplicate check and path convention

* Extract root A = `scratchpad/x/silicaflux-datafabric/`. B = `scratchpad/x/SilicaFlux2.0_SilicaFlux2.5_silicaflux-datafabric/`.
* **Duplicate check:** `diff -rq --exclude=node_modules A B` returned exit code 0 with no output, and an unfiltered `diff -rq A B` also reported them identical. **The two trees are byte-identical.** Neither tree contains a `node_modules` directory, and neither has hidden files.
* Both A and B contain one folder, `silicaflux-datafabric/`. **Every path below is relative to `A/silicaflux-datafabric/`** (the project root). Line references use the form `file:line` or `file:start-end`.
* Project size: 230 files. The RTL in scope is in `rtl/interconnect/` (12 files), `rtl/dma/` (8), `rtl/mem/` (2), `rtl/soc/` (1) and `generated/sfb_memmap_pkg.sv`. There is also vendored, unmodified third-party RTL under `third_party/silicaflux-v/` and `third_party/silicaflux-sramlib/`. Its provenance is claimed in `README.md:30` and listed in `third_party/SHA256SUMS`.

---

## 1. System-level picture (SoC integration, `rtl/soc/sfv_soc_df.sv`)

| Item | Fact | Source |
|---|---|---|
| Topology | `sfb_crossbar`, NM = 4 masters × NS = 7 slaves (partial crossbar via an access matrix) | `rtl/soc/sfv_soc_df.sv:71-72,115-130`; `generated/sfb_memmap_pkg.sv:8-9` |
| Masters | 0 DBG (JTAG system-bus access), 1 CPUD (CPU data), 2 CPUI (CPU instruction fetch), 3 DMA (`silicaflux_dma`) | `generated/sfb_memmap_pkg.sv:40-43`; `rtl/soc/sfv_soc_df.sv:158-159,162-192,363-373` |
| Vector / tensor engines | **They are not bus masters.** They sit inside `sfv_tile`, behind slave port 5 (TSPM). The DMA and CPU reach them through the TSPM window. | `rtl/soc/sfv_soc_df.sv:393-404`; `docs/datafabric/ARCHITECTURE.md:69-88`; `docs/datafabric/ISSUES.md:20` (DF-11) |
| Slaves | 0 ROM, 1-4 SRAM0..3, 5 TSPM, 6 PERIPH | `generated/sfb_memmap_pkg.sv:11-38` |
| Arbitration (SoC default) | `ARB_MODE = 1` (round robin) | `rtl/soc/sfv_soc_df.sv:36,116` |
| Data / address width (SoC) | DW = 32, AW = 32, both hard-coded in the SoC instance | `rtl/soc/sfv_soc_df.sv:116,363` |
| DMA config (SoC default) | `DMA_ENGINE = 0` (simple), `DMA_FIFO_DEPTH = 8`, `DMA_BURST = 8`, `DUAL_PORT(0)`, `MAX_OUT(2)`, `MAX_LEN_LOG2(24)`. FIFO, BURST and MAX_OUT only take effect when ENGINE = 1. | `rtl/soc/sfv_soc_df.sv:37-39,363-364` |
| Legacy masters | CPU I/D and JTAG tie `rsp_ready = 1` | `rtl/soc/sfv_soc_df.sv:177-179` |
| Legacy slaves | ROM, TSPM, PERIPH (and the SRAM banks when `SRAM_IMPL = 0`) sit behind `sfb_v1_slave_adapter` | `rtl/soc/sfv_soc_df.sv:134-154` |
| SRAM implementation | `SRAM_IMPL = 0` (default): third-party `sfv_sram_slave` (1-cycle latency) behind the v1 adapter. `SRAM_IMPL = 1`: `sfb_sram_slave` with `READ_LATENCY = SRAM_LATENCY` (default 1). | `rtl/soc/sfv_soc_df.sv:41-42,228-257` |
| Clock / reset | One functional `clk`. The fabric, DMA and slaves are reset by `sys_rst_n` (from `sfv_rst_sync`). The JTAG TAP adds TCK. | `rtl/soc/sfv_soc_df.sv:21-22,44-45,87-92,120,365`; `docs/datafabric/ARCHITECTURE.md:46-65` |
| Interrupt | DMA = INTC source 8 (`NUM_IRQ = 9`). Bus error = source 6. | `generated/sfb_memmap_pkg.sv:63-72`; `rtl/soc/sfv_soc_df.sv:312-329` |
| Perf block | `PERF = 1` default: `sfb_perf_counters` on page 7. `PERF = 0` removes it and the page answers with a bus error. | `rtl/soc/sfv_soc_df.sv:40,267-268,376-390` |
| Register slices in SoC | **NOT FOUND.** `sfb_reg_slice`, `sfb_shared_bus` and `sfb_sram_1r1w_slave` are instantiated only in testbenches (grep over `rtl/` and `tb/`). | `tb/interconnect/tb_sfb_xbar.sv:95,135,388` |
| Size guard | Elaboration fails unless the memory sizes match the generated map | `rtl/soc/sfv_soc_df.sv:80-84` |

---

## 2. Address map (`generated/sfb_memmap_pkg.sv`, generated from `memmap/silicaflux_v_datafabric.yaml`)

### 2.1 Regions (crossbar slave ports, mask decode)

| Slave idx | Region | Base | Size | Mask | Source |
|---|---|---|---|---|---|
| 0 | BOOT_ROM | `0x0000_0000` | `0x1000` (4 KiB) | `0xFFFF_F000` | `generated/sfb_memmap_pkg.sv:11-14` |
| 1 | SRAM_BANK0 | `0x1000_0000` | `0x8000` (32 KiB) | `0xFFFF_8000` | `:15-18` |
| 2 | SRAM_BANK1 | `0x1000_8000` | `0x8000` | `0xFFFF_8000` | `:19-22` |
| 3 | SRAM_BANK2 | `0x1001_0000` | `0x8000` | `0xFFFF_8000` | `:23-26` |
| 4 | SRAM_BANK3 | `0x1001_8000` | `0x8000` | `0xFFFF_8000` | `:27-30` |
| 5 | TSPM (tile scratchpad, 4-way word-interleaved) | `0x2000_0000` | `0x4000` (16 KiB) | `0xFFFF_C000` | `:31-34`; `memmap/silicaflux_v_datafabric.yaml:38-39` |
| 6 | PERIPH (register bus, 32 × 4 KiB pages) | `0x4000_0000` | `0x2_0000` (128 KiB) | `0xFFFE_0000` | `:35-38`; YAML `:40-41` |

* Packed crossbar vectors: `SLV_BASE` and `SLV_MASK` (`generated/sfb_memmap_pkg.sv:46-47`).
* Access matrix `MST_SLV_EN = 28'h7EFFFFF`, bit `m*NS+s` (`:49`). Decoded: DBG and CPUD reach all 7 slaves. **CPUI and DMA are denied PERIPH (slave 6).** This matches YAML `masters.deny` (`memmap/silicaflux_v_datafabric.yaml:58-63`) and `generated/datafabric_map.py:5`.
* Peripheral pages: SYSCTRL 0 `0x4000_0000`, INTC 1 `0x4000_1000`, TIMER 2 `0x4000_2000`, UART 3 `0x4000_3000`, SPI 4 `0x4000_4000`, GPIO 5 `0x4000_5000`, **DMA 6 `0x4000_6000`**, **DFPERF 7 `0x4000_7000`**, VE 16 `0x4001_0000`, TE 17 `0x4001_1000`. `PAGE_EN = 32'h000300FF` (`generated/sfb_memmap_pkg.sv:51-61`).
* Everything else is unmapped and returns a decode error, never an alias (`docs/datafabric/MEMORY_MAP.md:3`; `memmap/silicaflux_v_datafabric.yaml:29-30`).

### 2.2 Illegal-address behaviour

| Case | Behaviour | Source |
|---|---|---|
| Unmapped address | The per-master `sfb_error_slave` answers `rsp_error = 1` and `rsp_rdata = 0` one cycle after acceptance. No slave sees the request. | `rtl/interconnect/sfb_crossbar.sv:12-14,124-134`; `rtl/interconnect/sfb_error_slave.sv:4-10,27-35` |
| Access-matrix denial (`MST_SLV_EN`) | Same decode error | `rtl/interconnect/sfb_addr_decoder.sv:4-5,37`; `rtl/interconnect/sfb_crossbar.sv:26-28` |
| Misaligned (`CHECK_ALIGN = 1`, `addr[log2(DW/8)-1:0] != 0`) | Same decode error | `rtl/interconnect/sfb_addr_decoder.sv:8-9,35,42` |
| Overlapping regions | Must not exist (the generator rejects them). If present, the lowest slave index wins. | `rtl/interconnect/sfb_addr_decoder.sv:5-7,36-41`; `python/datafabric/memmap_gen.py:16-22` |
| Decode-error capture | `err_evt/err_addr/err_master/err_write`, one per cycle; the lowest master index wins. Wired to SYSCTRL BUSERR. | `rtl/interconnect/sfb_crossbar.sv:77-80,202-215`; `rtl/soc/sfv_soc_df.sv:128,303` |
| Disabled page / sub-word peripheral write | Bus error from `sfv_periph_bridge` | `third_party/silicaflux-v/rtl/bus/sfv_periph_bridge.sv:10-12`; `rtl/soc/sfv_soc_df.sv:277-282` |
| ROM write | Bus error from the ROM | `third_party/silicaflux-v/rtl/mem/sfv_mem_slaves.sv:75,108` |
| SRAM word ≥ DEPTH (non-power-of-two DEPTH only) | `rsp_error` from `sram_sp` | `rtl/mem/sfb_sram_slave.sv:14-15`; `third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv:18-19` |

---

## 3. Protocol: SFB2 (all DataFabric ports)

Spec: `docs/datafabric/PROTOCOL.md:18-54`.

* **Request channel:** `req_valid` / `req_ready`, `req_write` (1 = write), `req_addr[AW-1:0]` (byte address), `req_wdata[DW-1:0]`, `req_wstrb[DW/8-1:0]` (`rtl/interconnect/sfb_crossbar.sv:7,55-60`; `docs/datafabric/PROTOCOL.md:22-27`).
* **Response channel:** `rsp_valid` / `rsp_ready`, `rsp_rdata[DW-1:0]`, `rsp_error` (`rtl/interconnect/sfb_crossbar.sv:8,61-64`; `docs/datafabric/PROTOCOL.md:28-31`).
* **Absent fields: NOT FOUND** for `id`, `size`, `burst`, `len`, `prot`, `lock` and `cache`. Transfer size is expressed only by `req_wstrb`. Reads always return the full word. There are no native bursts (`docs/datafabric/PROTOCOL.md:52`, R10). IDs and multiple outstanding transactions are only a plan (`docs/datafabric/PROTOCOL.md:103-115`).
* **Writes get a response:** yes. Exactly one response per accepted request, including writes (R5, `docs/datafabric/PROTOCOL.md:47`). Write responses are issued only after the write has been performed (R7, `:49`). Write responses and error responses carry `rsp_rdata = 0` (R8, `:50`).
* **Error signalling:** a single bit, `rsp_error` (R8).
* **Handshake rules:** R2 forbids withdrawing a request and requires a stable payload (`:44`). R3/R4 ban combinational valid←ready dependencies and require a stable held response (`:45-46`). Responses come at least one cycle after acceptance (R5). Addresses must be DW-aligned (R9, `:51`). Reset cancels in-flight transactions (R11, `:53`).
* **Legacy SFB v1 mapping:** `req`→`req_valid`, `gnt`→`req_ready`, `we`, `addr`, `be`→`wstrb`, `rvalid`/`rdata`/`err`. v1 has no `rsp_ready` (`docs/datafabric/PROTOCOL.md:20-31`; `rtl/interconnect/sfb_v1_slave_adapter.sv:4-12`).

---

## 4. Per-module audit — interconnect (`rtl/interconnect/`)

### 4.1 `sfb_crossbar` — `rtl/interconnect/sfb_crossbar.sv`

1. **Module / path:** `sfb_crossbar`, `rtl/interconnect/sfb_crossbar.sv:36`.
2. **Clock / reset:** `clk`, `rst_n`, active-low with asynchronous assert (`:52-53,180-181`). No CDC.
3. **Widths:** `NM = 2`, `NS = 2`, `AW = 32`, `DW = 32`, `ARB_MODE = 1`, `CHECK_ALIGN = 1`, `SLV_BASE/SLV_MASK` default 0, `MST_SLV_EN` all ones. `SB = DW/8` (`:37-50`). In the SoC: NM = 4, NS = 7, AW = DW = 32 (`rtl/soc/sfv_soc_df.sv:115-118`).
4. **Protocol:** SFB2. Master side `m_req_valid/ready/write/addr/wdata/wstrb`, `m_rsp_valid/ready/rdata/error`. Slave side: the same signals with an `s_` prefix (`:55-75`). Extra outputs: `err_*` capture and per-master events `ev_req_accept/ev_req_stall/ev_arb_loss/ev_rsp_stall` (`:77-85,175-177`).
5. **Max outstanding:** **1 per master port and 1 per slave port** (`:19-23`). This is enforced by `out_q[m]`, `busy_q[s]`, `m_free = ~out_q | m_rsp_hs` and `s_free = ~busy_q | s_rsp_hs` (`:88-90,117-122,153,186-197`). A new request can be accepted in the same cycle as the previous response, so back-to-back transfers have no bubble (`:20-21`). No ID width. In the SoC at most 4 transactions are in flight in total (one per master; `docs/datafabric/PPA.md:31`).
6. **SRAM latency assumption:** none. Slave latency is arbitrary and at least 1 (`docs/datafabric/PROTOCOL.md:54`). The crossbar adds **0 cycles** in each direction because it is combinational (`:24-25`).
7. **Topology:** a full or partial crossbar (`MST_SLV_EN` removes pairs by constant propagation, `:26-28,143-145`). Each master has an `sfb_addr_decoder` and an `sfb_error_slave` (`:96-106,125-134`). Each slave has an `sfb_arbiter` and an `sfb_req_mux` (`:139-160`). One shared `sfb_rsp_router` (`:110-115`).
8. **Arbitration:** one `sfb_arbiter` per slave with `MODE = ARB_MODE`, `stall = s_req_valid && !s_req_ready` and `accept = s_req_valid && s_req_ready` (`:147-152`). `s_req_valid = gvalid && s_free` (`:153`). Candidates are qualified by `m_free` and the decode result (`:144-145`). See §4.3.
9. **Ordering:** in order per master by construction (1 outstanding, so responses "can never be re-ordered and need no IDs", `:22-23`). Responses are routed by a **one-hot owner register per slave** (`owner_q`), recorded at slave acceptance (`:90,191-193`). There is no ID tag and no FIFO.
10. **Address map:** taken from parameters (§2). Error behaviour is in §2.2.
11. **Slices:** none inside the module. Insert `sfb_reg_slice` externally (`:24-25`).
14. **Verification:** `tb_sfb_xbar` (§14.1), the v1compat cocotb test, formal `fv_sfb_xbar` (P1-P7, unbounded PDR PROVED per `reports/datafabric/formal.md:11`), mutation campaign 12/12 (`reports/datafabric/xbar_mutants.md:3`), and GLS (`reports/datafabric/gls.md:7-9`).

### 4.2 `sfb_addr_decoder` — `rtl/interconnect/sfb_addr_decoder.sv`

* Purely combinational; no clock (`:10,31-44`). Parameters: `NS = 4`, `AW = 32`, `DW = 32`, `CHECK_ALIGN = 1`, `SLV_BASE`, `SLV_MASK`, `EN` (`:15-21`).
* Rule: `(addr & SLV_MASK[s]) == SLV_BASE[s] && EN[s]`, scanned from s = NS-1 down to 0, so the lowest index wins (`:36-41`). Misaligned addresses force `hit = 0` (`:35,42`). Outputs: `hit`, `sel`, `sel_oh`, `misaligned` (`:25-29`).
* Verified indirectly through the crossbar TBs and formal P6 (`formal/datafabric/fv_sfb_xbar.sv:16-17`).

### 4.3 `sfb_arbiter` — `rtl/interconnect/sfb_arbiter.sv`

* Clock `clk`, reset `rst_n` (async, `:32-33,87-88`). Parameters: `N = 4`, `MODE = 1` (`:28-29`). N does not have to be a power of two (`:20`).
* **MODE 0, fixed priority:** requester 0 has the highest priority, and lower requesters can starve (`:4-6`). Code: loop k = N-1 down to 0, so the lowest index wins (`:63-69`). In the SoC, master 0 is DBG and master 3 (the DMA) has the lowest priority.
* **MODE 1, round robin:** the pointer moves to `(winner + 1) mod N` **only when the grant is accepted** (`:7-10,95-96`). Search uses a double-width rotate, `req2 = {req,req} >> prio_q` (`:71-81`). Bounded waiting: at most N-1 other accepted grants (`:8-10`).
* **Grant lock:** `lock_q <= grant_valid && stall && !accept`, `lock_idx_q <= grant_idx` (`:93-94`). While locked and the requester still requests, the same index is re-granted (`:60-62`). If the requester withdraws, the lock is released (`:15-18`).
* Combinational path is req → grant. There is no path from accept or stall (`:23`).
* **Verification:** formal A1-A4 (`formal/datafabric/fv_sfb_arbiter.sv:1-9`). Results in `reports/datafabric/formal.md:7-9`: RR N = 3 and N = 5 and fixed N = 4 are PROVED unbounded by PDR. Mutant "RR pointer stuck" is caught (`:16`).

### 4.4 `sfb_req_mux` — `rtl/interconnect/sfb_req_mux.sv`

* AND-OR mux driven by a one-hot grant. A zero grant gives an all-zero payload. Combinational (`:3-5,25-36`). Parameters: `NM = 4`, `AW = 32`, `DW = 32` (`:10-13`).

### 4.5 `sfb_rsp_router` — `rtl/interconnect/sfb_rsp_router.sv`

* Combinational. Parameters: `NM = 4`, `NS = 4`, `DW = 32` (`:15-17`).
* Each slave holds at most one transaction (`busy[s]`) with a one-hot owner. The response is steered only to the owner, and the owner's `rsp_ready` becomes `s_rsp_ready` (`:4-10,37-47`). Decode-error responses (`e_rsp_valid`) are merged in (`:33-34`).

### 4.6 `sfb_error_slave` — `rtl/interconnect/sfb_error_slave.sv`

* Clock `clk`, reset `rst_n` (`:17-18`). Parameter `DW = 32` (`:15`).
* Behaviour: `req_ready = !pend_q || rsp_ready`. `rsp_valid = rsp_error = pend_q`, held until `rsp_ready`. `rsp_rdata = 0`. The response comes **one cycle after acceptance**. One response is buffered, which gives full throughput (`:9-10,27-35`).

### 4.7 `sfb_shared_bus` — `rtl/interconnect/sfb_shared_bus.sv` (comparison topology, not used in the SoC)

* Same ports and parameters as the crossbar: `NM = 2`, `NS = 2`, `AW = 32`, `DW = 32`, `ARB_MODE = 1`, `CHECK_ALIGN = 1` (`:16-26`). There is **no `MST_SLV_EN`**: the access matrix is not supported (`:9-12`).
* Built from an NM×1 `sfb_crossbar` (arbitration only, `:69-81`) followed by a 1×NS `sfb_crossbar` (decode and routing, `:83-95`).
* **At most one transaction is in flight across the whole fabric** (`:7-9`). `err_master` is reconstructed from stage-1 `ev_req_accept` (`:97-101`).
* Verified with `tb_sfb_xbar -GTOPO=1` (`tb/interconnect/tb_sfb_xbar.sv:46,94-108`; `scripts/datafabric/xbar_regress.py:17`).

### 4.8 `sfb_skid_buffer` — `rtl/interconnect/sfb_skid_buffer.sv`

* Clock `clk`, reset `rst_n`. Parameter `WIDTH = 32` (`:11,13-14`).
* Two entries. Forward valid/data and backward ready are both registered (`s_ready = ~skid_valid`). One transfer per cycle. The payload is stable while held. **The storage flops are not reset** (`:4-8,25,27-48`). It adds 1 cycle of latency because `m_valid` is a flop (`:29,37`).
* Formal S1-S4 PROVED unbounded (`formal/datafabric/fv_sfb_skid.sv:4-8`; `reports/datafabric/formal.md:10`).

### 4.9 `sfb_reg_slice` — `rtl/interconnect/sfb_reg_slice.sv`

* Parameters: `AW = 32`, `DW = 32`, `REQ_SLICE = 1`, `RSP_SLICE = 1` (`:20-23`).
* **Latency:** `REQ_SLICE = 1` adds +1 cycle on the request path. `RSP_SLICE = 1` adds +1 cycle on the response path. 0 makes the channel a pass-through wire (`:6-9,54-82`). Each sliced channel is one `sfb_skid_buffer` (2 entries), and full throughput is kept (`:10`).
* **Caveat:** the slice stores up to one extra transaction per sliced channel. Placed between a master and a crossbar master port, it breaks the 1-outstanding guarantee seen by that master (`:11-15`; `docs/datafabric/PROTOCOL.md:94-101`).
* Verified by `tb_sfb_reg_slice` (§14.1) and `tb_sfb_xbar -GSLICE=1`.

### 4.10 `sfb_v1_slave_adapter` — `rtl/interconnect/sfb_v1_slave_adapter.sv`

* Fixed 32-bit, no parameters. Clock `clk`, reset `rst_n` (`:17-19`).
* Maps `req_valid` → `v1_req` (gated by `!hold_q`), `v1_gnt` → `req_ready`, `req_write` → `v1_we`, `req_wstrb` → `v1_be` (`:45-50`).
* A one-entry holding register parks a response when `rsp_ready = 0`. While a response is parked, no new request is passed on (`:7-10,52-71`).
* **Latency added: none.** Cost: 34 flops (`:13`). Holding data flops are not reset (`:66-71`).

### 4.11 `sfb_perf_counters` (+ `sfb_perf_defs.svh`) — `rtl/interconnect/sfb_perf_counters.sv`

1. Clock `clk`, reset `rst_n` (`:24-25`).
2. Parameters: `NM = 4`, `CW = 32` (`:21-22`). The register bus is 12-bit address and 32-bit data (`:27-34`).
3. **What it counts** (each 32-bit and saturating, `:9,61-63`), per master m (`NE = 6`, `:47`):
   * READS: `ev_accept && !ev_write` (`:77`)
   * WRITES (`:78`)
   * REQ_STALL: cycles with `req_valid && !req_ready` (`:79`)
   * ARB_LOSS: cycles where the master was eligible but lost (`:80`; source `rtl/interconnect/sfb_crossbar.sv:169-171`)
   * RSP_STALL (`:81`)
   * ERRORS: error responses accepted (`:82`; SoC wiring `m_rvalid & m_rsp_ready & m_err` at `rtl/soc/sfv_soc_df.sv:382`)
4. Global counters: DMA_BYTES (summed at `dma_done`, saturating, `:84`), DMA_BUSY and DMA_IDLE cycles (`:85-86`), FIFO_MAX (maximum DMA FIFO level, 8-bit, `:87`), and a 64-bit cycle counter (`:88`).
5. **Control:** CTRL.ENABLE (reset value 1, `:67`), CTRL.CLEAR, and CTRL.SNAPSHOT (an atomic copy into the read registers, `:10-13,93-102`).
6. **Map:** CTRL 0x000, INFO 0x004 (holds {CW, NM}, `:117`), CYCLES_LO/HI 0x008/0x00C, DMA_BYTES 0x010, DMA_BUSY 0x014, DMA_IDLE 0x018, FIFO_MAX 0x01C. The per-master block starts at 0x040 with a 0x020 stride: READS +0x00, WRITES +0x04, REQ_STALL +0x08, ARB_LOSS +0x0C, RSP_STALL +0x10, ERRORS +0x14 (`rtl/interconnect/sfb_perf_defs.svh:8-30`).
7. Writes to read-only registers or unmapped offsets return `rb_err` (`:114-131`).
8. Verified at SoC level only, through firmware D8 output (`reports/datafabric/soc_logs/default__dma_demo_sram_boot.uart.log`, "DFPERF ..." lines). **A dedicated unit testbench: NOT FOUND.**

---

## 5. Memory slaves (`rtl/mem/`)

### 5.1 `sfb_sram_slave` — `rtl/mem/sfb_sram_slave.sv`

* Clock `clk`, reset `rst_n`. Parameters: `DW = 32`, `DEPTH = 1024` (words), **`READ_LATENCY = 1`**, `BACKEND = GENERIC`, `MACRO = 0`. Local `AW = clog2(DEPTH)`, and the word address is `req_addr[OFF +: AW]` (`:22-29,63`). `req_addr` is a fixed 32-bit port (`:38`).
* Wraps `sram_sp` with `RSP_FIFO_DEPTH = READ_LATENCY + 1`, `WRITE_ACK = 1`, `ID_WIDTH = 1` (ID tied to 0) and `TEST_EN = 1` (`:57-68`).
* **Read latency:** the response arrives READ_LATENCY cycles after acceptance (`:11-12`; `third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv:12-13`). That is the bypass path when the response FIFO is empty and `rsp_ready = 1`; otherwise the response is FIFO-buffered (`third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv:13-17,131-133`).
* **Write acknowledgements** travel the same LATENCY-deep tag pipeline, so a write response also comes READ_LATENCY cycles after acceptance. It is never sent before the array write (`:9-11`; `third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv:6-8,73-98`).
* `req_ready` is 0 during reset and in the cycle after it (`third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv:25-26`). `req_ready` is also forced to 0 while MBIST `tst_active` is high (`:28-29,101`).
* Internally the library accepts up to `READ_LATENCY + 1` outstanding requests on credit (`third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv:168`). The crossbar slave port limits this to **1**, so at `READ_LATENCY ≥ 2` a port runs at 1/latency of its bandwidth (`docs/datafabric/ISSUES.md:16`, DF-07).
* SoC: used only with `SRAM_IMPL = 1`, with `READ_LATENCY = SRAM_LATENCY` (default 1; MBIST requires 1) (`rtl/soc/sfv_soc_df.sv:42,240-251`; `docs/datafabric/ISSUES.md:22`).

### 5.2 `sfb_sram_1r1w_slave` — `rtl/mem/sfb_sram_1r1w_slave.sv` (TB-only use)

* Parameters are the same as §5.1 (`:20-27`).
* Reads go through `sram_1r1w` with READ_LATENCY cycles. Writes are posted in the library. **The adapter generates the write response one cycle after `wr_valid && wr_ready`** (`:5-9,84-86,72-74`).
* It holds at most one transaction (`in_q`) and accepts the next in the cycle the previous response is accepted (`:10-12,44,51-54,82-83`).
* Collision policy is `SRAM_COLL_STALL` (`:58`). Reads and writes are serialised through one port (`:13-14`; `docs/datafabric/ISSUES.md:21`, DF-12).

### 5.3 Third-party SoC slaves (default `SRAM_IMPL = 0`), for latency context only

* `sfv_sram_slave`: "1 cycle latency, back-to-back accesses". `rvalid <= req && gnt`, and `gnt = !bist_en` (`third_party/silicaflux-v/rtl/mem/sfv_mem_slaves.sv:9,42,56-64`). Behind the v1 adapter, which adds no latency, the accept-to-`rsp_valid` latency is **1 cycle**.
* `sfv_bootrom`: `gnt = 1`, `rvalid` 1 cycle after the request (`third_party/silicaflux-v/rtl/mem/sfv_mem_slaves.sv:98,107`).
* `sfv_periph_bridge`: `gnt = 1`, `rvalid` 1 cycle after the grant (`third_party/silicaflux-v/rtl/bus/sfv_periph_bridge.sv:9,45,60`).
* TSPM (`sfv_tile`): `rvalid <= f_go` (1 cycle). `gnt` drops on an engine bank conflict, and engine accesses have priority (`third_party/silicaflux-v/rtl/accel/sfv_tile.sv:9-15,128-137`).

---

## 6. DMA (`rtl/dma/`)

### 6.1 `silicaflux_dma` (top) — `rtl/dma/silicaflux_dma.sv`

* Clock `clk`, reset `rst_n` (`:33-34`). In the SoC: `sys_rst_n` (`rtl/soc/sfv_soc_df.sv:365`).
* Parameters: `DW = 32`, `ENGINE = 0` (0 = simple `dma_transfer_engine`, 1 = buffered `dma_burst_engine`), `FIFO_DEPTH = 8`, `BURST = 8`, `DUAL_PORT = 0`, `MAX_OUT = 2`, `MAX_LEN_LOG2 = 24`, `PERF = 1`. `NP = 2` only when ENGINE = 1 and DUAL_PORT = 1 (`:22-31`).
* Ports:
  * register bus `rb_sel/rb_we/rb_addr[11:0]/rb_wdata/rb_rdata/rb_err` and `irq` (`:36-42`)
  * SFB2 master port(s) `m_req_*` / `m_rsp_*` with a fixed 32-bit address (`:44-53`)
  * status `busy/ev_done/bytes_done/fifo_level` (`:55-58`)
* **Channels: 1** ("single-channel", `:2,12`).
* **Scatter-gather / descriptor chaining / 2-D: NOT FOUND.** `docs/datafabric/ISSUES.md:19` (DF-10) lists "no 2-D/strided transfers; no descriptor chaining".
* The DMA has no memory map of its own. Illegal regions come back as bus errors, and the SoC access matrix keeps the DMA out of PERIPH (`:13-16`).

### 6.2 Register map (`rtl/dma/dma_defs.svh`, generated; page base `0x4000_6000`)

| Off | Name | Access | Fields / notes | Source |
|---|---|---|---|---|
| 0x00 | CONTROL | wo (reads 0) | bit0 START, bit1 ABORT | `rtl/dma/dma_defs.svh:8,23-24`; YAML `:83-90` |
| 0x04 | STATUS | ro | bit0 BUSY, bit1 DONE, bit2 ERROR, bit3 ABORTED, [10:8] STATE | `rtl/dma/dma_defs.svh:9,25-30`; `rtl/dma/dma_control_regs.sv:77` |
| 0x08 | SRC_ADDR | rw (write refused while busy) | | `rtl/dma/dma_defs.svh:10`; `rtl/dma/dma_control_regs.sv:79,108-112` |
| 0x0C | DST_ADDR | rw (write refused while busy) | | `rtl/dma/dma_defs.svh:11` |
| 0x10 | LENGTH | rw (write refused while busy) | bytes, 1..2^MAX_LEN_LOG2 | `rtl/dma/dma_defs.svh:12` |
| 0x14 | BYTES_DONE | ro | contiguous prefix acknowledged OK | `rtl/dma/dma_defs.svh:13` |
| 0x18 | INT_ENABLE | rw | bit0 DONE, bit1 ERROR | `rtl/dma/dma_defs.svh:14,31-32` |
| 0x1C | INT_STATUS | w1c | bit0 DONE, bit1 ERROR | `rtl/dma/dma_defs.svh:15,33-34` |
| 0x20 | ERROR_CODE | ro | 0 NONE, 1 ZERO_LENGTH, 2 LENGTH, 3 SRC_ALIGN, 4 DST_ALIGN, 5 SRC_OVERFLOW, 6 DST_OVERFLOW, 7 OVERLAP, 8 READ_BUS, 9 WRITE_BUS, 10 ABORTED | `rtl/dma/dma_defs.svh:16,45-55` |
| 0x24 | ERROR_ADDR | ro | failing bus address | `rtl/dma/dma_defs.svh:17` |
| 0x28 | INFO | ro | [7:0] DW bytes, [8] BUFFERED, [15:12] FIFO_LOG2, [23:16] MAX_LEN_LOG2, [31:24] VERSION = 1 | `rtl/dma/dma_defs.svh:18,35-43`; `rtl/dma/dma_control_regs.sv:65` |
| 0x2C | ID | ro | `0x5346_4446` ("SFDF") | `rtl/dma/dma_defs.svh:19,44` |
| 0x30 | ACTIVE_CYCLES | ro, PERF only (wraps) | | `rtl/dma/dma_defs.svh:20`; `rtl/dma/dma_control_regs.sv:89,146` |
| 0x34 | STALL_CYCLES | ro, PERF only (wraps) | cycles a request waited | `rtl/dma/dma_defs.svh:21`; `rtl/dma/dma_control_regs.sv:90,147` |
| 0x38 | TRANSFERS | ro, PERF only (wraps) | completed transfers | `rtl/dma/dma_defs.svh:22`; `rtl/dma/dma_control_regs.sv:91,149` |

FSM state encodings (STATUS.STATE): IDLE 0, VALIDATE 1, ISSUE_READ 2, WAIT_READ 3, ISSUE_WRITE 4, WAIT_WRITE 5, COMPLETE 6, ERROR 7 (`rtl/dma/dma_defs.svh:56-63`).

### 6.3 `dma_control_regs` — `rtl/dma/dma_control_regs.sv`

* Register-bus slave. Read data and errors are combinational in the strobe cycle (`:4-9,71-95`).
* **Busy protection:** while busy, writes to SRC, DST, LEN and CONTROL.START are refused with `rb_err = 1` and have no effect. ABORT is accepted at any time, except that a START|ABORT write while busy is ignored completely (`:11-15,57-63,76,79-81,108`).
* Writes to read-only registers and unmapped offsets return `rb_err` (`:92`).
* STATUS DONE, ERROR and ABORTED are sticky until the next START (`:114-123`).
* Perf counters are generated only when `PERF != 0` (`:135-159`).

### 6.4 `dma_transfer_engine` (ENGINE = 0, SoC default) — `rtl/dma/dma_transfer_engine.sv`

* Parameters: `DW = 32`, `MAX_LEN_LOG2 = 24` (`:34-35`). One SFB2 master port (`:56-65`).
* **Data buffering:** no FIFO. There is a single data register, the write-data register loaded from the read response, and it is not reset (`:4-5,200-203`). INFO reports FIFO_LOG2 = clog2(1) = 0 (`rtl/dma/silicaflux_dma.sv:65`; `rtl/dma/dma_control_regs.sv:65`).
* **Max outstanding: 1** in total, read or write (`:5,14-15`).
* **Burst length:** none. One beat per transaction.
* **Read→write dependency:** strict. Each beat goes ISSUE_READ → WAIT_READ → ISSUE_WRITE → WAIT_WRITE, and a write is issued only with data from an error-free read of the same beat (`:7-11,18,138-167`). Throughput is 4 cycles per beat with 1-cycle slaves (`:28`). Measured: 4,100 cycles for 4 KiB at DW = 32 (`reports/datafabric/benchmark.md:42`).
* **`rsp_ready`** is asserted only in the WAIT states (`:87`).
* **Completion semantics:** `done` is decoded from the COMPLETE state (`:91`). COMPLETE is entered only from WAIT_WRITE on `rsp_valid && !rsp_error && last_beat` (`:168-180`). So **done is raised only after the final write response returned OK** (`:21-22`). STATUS.DONE is latched on the edge where BUSY falls (`:89-90`; `rtl/dma/dma_control_regs.sv:119`).
* **Tail handling:** the final partial word is written with `tail_strb`, so bytes ≥ len are never written (`:19-20,75-83,157`).
* **Errors:**
  * validation in the VALIDATE state, before any bus access (`:123-137`)
  * read error → ERROR, ERROR_ADDR = src, no further write (`:146-149`)
  * write error → ERROR, ERROR_ADDR = dst (`:170-173`)
  * `bytes_done` counts only acknowledged writes, as a contiguous prefix (`:23-25,175`)
* **Abort** takes effect at the next beat boundary. Requests are never withdrawn (`:26-27,109,127-129,150-152,181-183`).
* **Timeout / watchdog: NOT FOUND** (stated as deliberate in `docs/datafabric/DMA.md:81-84`).

### 6.5 `dma_burst_engine` (ENGINE = 1, optional) — `rtl/dma/dma_burst_engine.sv`

* Parameters: `DW = 32`, `MAX_LEN_LOG2 = 24`, **`FIFO_DEPTH = 8`** (power of two, at least 2), **`BURST = 8`** (1..FIFO_DEPTH, single-port phases), `DUAL_PORT = 0`, **`MAX_OUT = 2`** (`:33-38`).
* Data path: read issuer → `dma_fifo` (FIFO_DEPTH beats) → write issuer (`:6,138-140`).
* **Credit:** a read is issued only if `rd_iss - wr_iss < FIFO_DEPTH`, so `rsp_ready` is constantly 1 (`:7-9,116,147`).
* **Max outstanding:** `rd_iss - rd_rsp < MAX_OUT` and `wr_iss - wr_rsp < MAX_OUT` per port (`:10-12,116,118`). **However, on an `sfb_crossbar` master port only 1 transaction is ever accepted outstanding.** The engine can present the next request while one is pending (`rtl/interconnect/sfb_crossbar.sv:19-21`; `docs/datafabric/PROTOCOL.md:48`, R6).
* **Bursts:** SFB2 has no native bursts. A "burst" is up to BURST sequential single-beat requests. With a single port, READ and WRITE phases alternate, and the phase changes only when the port is idle (`:13-17,228-245`). With `DUAL_PORT = 1`, port 0 reads and port 1 writes concurrently (`:18-19,215-227`). The SoC hard-codes `DUAL_PORT(0)` (`rtl/soc/sfv_soc_df.sv:364`).
* **Read→write dependency:** a write needs FIFO data (`fcnt_n != 0`, `:117`), and writes stop at `rd_ok` after a read error (`:110`).
* **Completion:** `done = (st_q == S_END) && !err_q` (`:145`). S_END is entered only when `finished` holds: nothing presented, nothing outstanding, and every write that can be issued has been issued (`:134-136,249-250`). If it finishes without a bus error but `wr_rsp != total`, the result is ABORTED (`:251-253`). So completion implies every write response returned OK (`:27`).
* **Errors:**
  * issue stops on an error
  * outstanding responses are drained
  * the first error wins (`:20-23,198-206`)
  * after a write error, up to MAX_OUT-1 later beats may also have been written, while `bytes_done` stays at the OK prefix (`:24-27,212-213`)

### 6.6 `dma_fifo` — `rtl/dma/dma_fifo.sv`

* Parameters: `WIDTH = 32`, `DEPTH = 4` (module default; instantiated with FIFO_DEPTH, `rtl/dma/dma_burst_engine.sv:138`). Power of two, at least 2. First-word fall-through (`:2-8,13-14`).
* Pointers are reset; storage is not (`:29-41`). A simulation-only check flags push-while-full and pop-while-empty (`:46-54`).

### 6.7 `dma_validate` — `rtl/dma/dma_validate.sv`

* Combinational. The first failing rule wins:
  * len == 0 → ZERO_LENGTH
  * len > 2^MAX_LEN_LOG2 → LENGTH
  * src or dst not DW-aligned → SRC_ALIGN / DST_ALIGN
  * src+len or dst+len > 2^32 → SRC_OVERFLOW / DST_OVERFLOW
  * any overlap, including src == dst → OVERLAP
* Region existence is not checked (`:5-16,31-46`).

### 6.8 `dma_irq` — `rtl/dma/dma_irq.sv`

* `status` is set by the event (set wins over a same-cycle W1C). Writing 1 clears it. `irq = |(status & enable)`, a level signal (`:4-6,19-23`).

### 6.9 DMA summary of requested items

| Item | Simple (ENGINE 0, SoC default) | Buffered (ENGINE 1) |
|---|---|---|
| Burst length | none (single beats) | `BURST = 8` default, sequential single beats (`rtl/dma/dma_burst_engine.sv:36`) |
| FIFO depth | 1 data register | `FIFO_DEPTH = 8` default (`rtl/dma/dma_burst_engine.sv:35`) |
| Max outstanding reads/writes | 1 total | `MAX_OUT = 2` per port, capped to 1 accepted by the crossbar |
| Read→write dependency | strict per beat | via FIFO credit |
| Done raised | after the final write response OK (COMPLETE state) | after all write responses OK and nothing outstanding (S_END) |
| Error handling | validation codes 1-7, bus errors 8/9 + ERROR_ADDR, abort 10, no watchdog | same, plus draining |
| Channels | 1 | 1 |
| Scatter-gather | NOT FOUND | NOT FOUND |

---

## 7. Clock domains / CDC summary

* Every DataFabric module uses one clock `clk` and the active-low async reset `rst_n`. No DataFabric module has a second clock (see the port lists above).
* **CDC in DataFabric: NONE.** `docs/datafabric/ARCHITECTURE.md:48-50`: "No clock-domain crossing is introduced by DataFabric".
* SoC-level CDC exists only in the vendored JTAG debug module: TCK ↔ `clk`, using a toggle handshake with two-flop synchronisers (`third_party/silicaflux-v/rtl/debug/sfv_jtag.sv:24-28`; `rtl/soc/sfv_soc_df.sv:184-192`).
* The tile engines use ICG-gated versions of `clk`. That is the same domain, not a CDC (`third_party/silicaflux-v/rtl/accel/sfv_tile.sv:16-20`).
* Reset synchronisers: `sfv_rst_sync` builds por, sys and cpu resets (`rtl/soc/sfv_soc_df.sv:87-92`).

---

## 8. Verification IP and testbenches (`tb/`)

### 8.1 Verification IP

* `tb/common/sfb_if.sv`: an SFB2 interface bundle with master, slave and monitor modports, for verification use only (`:1-32`).
* `tb/common/sfb_protocol_checker.sv`:
  * checks R2 (request held stable), R4 (response held stable), R5 (no response without an outstanding request), R6 (outstanding ≤ MAX_OUT), R8 (`rdata == 0` on write and error responses; needs MAX_OUT ≤ 8) and X/Z on handshakes (`:4-19,65-139`)
  * outputs `violations`, `n_req`, `n_rsp`, `outstanding` (`:44-47`)
* `tb/common/sfb_trace_monitor.sv`:
  * **CSV trace format** `cycle,event,master,id,addr,op,size,bank,slave,error,stall_cycles` (`:7,64`)
  * events: ISSUE, ACCEPT, CONFLICT, RESPONSE (`:8-13`)
  * `id` is a per-master sequence number
  * the `bank` column is written with the slave index, the same value as `slave` (`:85-86,89-90,92-93`)
  * enabled by `+trace=<file>` (`:14,62-65`)

### 8.2 Waveforms

* **VCD/FST dump: NOT FOUND.** There is no `$dumpfile` or `$dumpvars` in DataFabric TBs or scripts, and no `.vcd` or `.fst` files.
* **JSON trace:** `python/datafabric/trace_export.py` can write `{"format":"memorylab-canonical+datafabric","transactions":[...]}` (`:93-96`). No JSON trace files are present; only CSV traces are.

---

## 14. Verification status (testbenches, tests, evidence)

### 14.1 Testbenches and tests

| TB / test | DUT / config | What it checks | Source |
|---|---|---|---|
| `tb/interconnect/tb_sfb_xbar.sv` | `sfb_crossbar` or `sfb_shared_bus` (TOPO), optional slices, slaves = TB models or the sramlib `sram_sp`/`sram_1r1w`. Defaults: NM = 3, NS = 3, DW = 32, ARB = 1, latency 1..3. | Random masters (shared words, unmapped/misaligned/denied/slave-error addresses, rsp back-pressure, pipelined requests). Scoreboards: (1) request conservation, (2) responses predicted from a shadow memory, (3) liveness with a 20,000-cycle watchdog, and an RR fairness bound of NM*(LMAX+2) in mode 1. Mid-traffic resets (`+resets`). Modes 0 random / 1 contention / 2 single requester. Protocol checker on every port. | `tb/interconnect/tb_sfb_xbar.sv:2-30,35-48,156-179,485-512,531-537,597-601` |
| `tb/interconnect/tb_sfb_reg_slice.sv` | `sfb_reg_slice` (REQ/RSP_SLICE, DW) | Up to 12 in flight against a pipelined slave with queue depth 8. In-order data, no loss or duplication, final memory, throughput ≥ 0.95/cycle. | `tb/interconnect/tb_sfb_reg_slice.sv:2-21,158-187` |
| `tb/dma/tb_dma.sv` | `silicaflux_dma` on an `sfb_crossbar` with NC = 2 competing random masters (described as CPU/vector/tensor traffic models), 3 slaves (MEM0/MEM1 16 KiB, MEM2 4 KiB), latency 1..3, random bp. **The DMA is master index 0 here** (`:95`); in the SoC it is index 3. `MAX_LEN_LOG2` is overridden to 16 (`:92`). | Tests `+test=` directed, errors, busy, irq, abort, reset, random, perf. A byte-exact expected memory and a write monitor; checks of STATUS, ERROR_CODE, ERROR_ADDR, BYTES_DONE, INT_STATUS and irq; a FIFO saturation check. | `tb/dma/tb_dma.sv:1-27,32-43,365-530,550-562,567-570` |
| `tb/dma/cocotb/test_dma_cocotb.py` (+ `tb/dma/cocotb/Makefile`) | `silicaflux_dma` standalone (Icarus). ENGINE 0 or 1; FIFO = 4, BURST = 4, MAX_LEN_LOG2 = 16. The Python slave allows up to 4 outstanding. | 3 tests: `random_valid_transfers` (`:182-195`), `validation_and_bus_errors` (`:197-215`), `busy_protection_and_irq` (`:217-238`). Results are compared against the Python reference `ref_transfer` (`:32-59`). | `tb/dma/cocotb/Makefile:5-8`; `tb/dma/cocotb/test_dma_cocotb.py:1-10,62-109` |
| `tb/interconnect/v1compat/test_xbar.py` (+ `tb_xbar_wrap.sv`, `sfv_cocotb.py`, Makefile) | `sfb_crossbar` 3×3 behind the v1-style wrapper, fixed priority or `COMPAT_RR=1` | 1 test, `random_traffic`. The silicaflux-v crossbar test, claimed to be unmodified: data integrity, in-order, decode errors, access mask (m2 → S2 denied), slave errors, error capture. | `tb/interconnect/v1compat/test_xbar.py:1-6,64-65`; `tb/interconnect/v1compat/tb_xbar_wrap.sv:1-6`; `tb/interconnect/v1compat/Makefile:1-4` |
| `tb/soc/tb_soc_df.sv` | `sfv_soc_df` (ARB_MODE, DMA_ENGINE, PERF, SRAM_IMPL via -G/+define) | Firmware-level: UART, SPI flash, GPIO and JTAG board models. PASS/FAIL comes from TEST_STATUS. CSV trace via `+trace`. | `tb/soc/tb_soc_df.sv:1-24,28-38,66-73,215-245,324-331` |
| Formal `formal/datafabric/fv_sfb_arbiter.sv`, `fv_sfb_skid.sv`, `fv_sfb_xbar.sv`, `fv_dma_engine.sv` (+ `run_formal.py`, `jobs_extra.py`) | arbiter A1-A4; skid S1-S4; crossbar 3×2 DW = 16 P1-P7; DMA D1-D9 (LEN_BITS 6 or 5) | BMC with yosys-smtbmc/z3 or ABC bmc3, plus ABC PDR, plus 5 non-vacuity mutants | headers at `formal/datafabric/fv_sfb_arbiter.sv:1-9`, `formal/datafabric/fv_sfb_skid.sv:1-8`, `formal/datafabric/fv_sfb_xbar.sv:1-20`, `formal/datafabric/fv_dma_engine.sv:1-21`; `formal/datafabric/run_formal.py:1-6`; `formal/datafabric/jobs_extra.py:1-14` |
| pytest `python/datafabric/tests/test_memmap_gen.py` | memory-map generator | 20 tests (overlap, size, alignment, overflow, duplicates, pages, registers, fields, deny lists, SV output, cross-check, freshness) | `python/datafabric/tests/test_memmap_gen.py:27-136` |
| Mutation campaign `scripts/datafabric/xbar_mutants.py` | 12 RTL mutants against `tb_sfb_xbar` / `tb_sfb_reg_slice` | Testbench strength | `scripts/datafabric/xbar_mutants.py:1-14` |

Regression drivers:
* `scripts/datafabric/unit_regress.py`: tb_dma 8 configs × 3 seeds, slice 5 × 3, xsram 6 × 2, cocotb, pytest (`:43-61`).
* `scripts/datafabric/xbar_regress.py`: 19 configs, seeds 1-3, plus one 200k-cycle long run (`:12-21,64`).
* `scripts/datafabric/soc_regress.py` (`:1-14`) and `scripts/datafabric/gls.py` (`:1-6`).

### 14.2 Evidence that the tests were run (as shipped)

These are the authors' own reports. I did not re-run any of them.

* `reports/datafabric/SUMMARY.md:3,9-19,33-46`. Generated 2026-11-06 02:40 UTC, with tool versions: Verilator 5.020, Icarus 12.0, Yosys 0.33, z3, cocotb 2.1.0; sby and openroad "not installed". Claimed results:
  * lint 25/25
  * unit 56/56
  * xbar 115/115
  * mutants 12/12
  * SoC 18/18
  * formal 12/12 jobs as expected, of which 5 unbounded proofs and 2 bounded only
  * GLS 5/5
  * synth 34/34 with 0 latches
  * benchmark 54/54
* Per-run JSON with result lines, exit codes and run times (for example `reports/datafabric/unit_regression.json` holds `{suite, config, args, ok, result, secs}`; `reports/datafabric/xbar_regression.json` also holds `cmd` and `exit`). Markdown versions: `reports/datafabric/unit_regression.md:3-62`, `reports/datafabric/xbar_regression.md:3`, `reports/datafabric/formal.md:5-18`, `reports/datafabric/gls.md:3-11`, `reports/datafabric/xbar_mutants.md:3-18`, `reports/datafabric/soc_regression.md:3-26`.
* **Raw logs:** only for the SoC. `reports/datafabric/soc_logs/` holds 36 files (18 `*.sim.log` + 18 `*.uart.log`). Example: `reports/datafabric/soc_logs/default__dma_demo_sram_boot.sim.log` ends with "TB_SOC RESULT PASS status=00000001 cycles=3853563".
* **Raw logs for unit, xbar, formal and GLS runs: NOT FOUND.** Only the captured result lines in JSON exist. Also not present: cocotb `results*.xml`, Verilator build directories, formal counterexample traces. `Makefile:73-75` and `scripts/datafabric/package.sh:12-14` exclude or clean these.
* **CI:** `ci/github-actions-datafabric.yml` is a template ("Copy to .github/workflows/ when the project is placed in a repository", `:1-3`). **CI run logs or artifacts: NOT FOUND.**
* **Formal caveat:** the DMA proofs are **bounded only**: 23 cycles for the simple engine and 22 for the buffered engine; PDR reached its 1,200 s budget without a result (`reports/datafabric/formal.md:12-13`; `docs/datafabric/ISSUES.md:14`, DF-05). The interconnect proofs are unbounded PDR PROVED (`reports/datafabric/formal.md:7-11`).
* **Traces:** `reports/datafabric/traces/*.csv`, 5 traces plus 5 `.memorylab.csv` copies. Two are SoC D8 windows and three are tb_dma contention runs. All use the CSV format of §8.1.

### 14.3 Notes on the test data

* In the tb_dma `_fp` (fixed-priority) benchmark rows the DMA is master 0, the highest priority (`tb/dma/tb_dma.sv:95`). That is why its cycles are unchanged under contention (`reports/datafabric/benchmark.md:7-20,45-58`). In the SoC the DMA is master 3, the lowest fixed priority (`generated/sfb_memmap_pkg.sv:43`; `rtl/interconnect/sfb_arbiter.sv:4-6`). The fixed-priority numbers therefore do not carry over to the SoC.
* The tb_dma competing masters drive random `wstrb`, which can be all-zero (`tb/dma/tb_dma.sv:230`). The trace `reports/datafabric/traces/tb_dma__simple_d32__contention.csv` contains 164 accepted writes of size 0 (84 from master 1, 80 from master 2). PROTOCOL R10 says "1..DW/8 bytes" (`docs/datafabric/PROTOCOL.md:52`). This is a minor mismatch between the spec and the stimulus.
* `xbar_regression.md:23` records `starvation_events=19` for the fixed-priority contention run, counted as PASS by design (`tb/interconnect/tb_sfb_xbar.sv:493-497`).

### 14.4 Source-hash cross-check (independent re-computation)

I re-implemented the `tree_hash` algorithm of `scripts/datafabric/report.py:16-24,59-61` in my own script and ran it on the extracted tree.

| tree | SUMMARY.md value (`reports/datafabric/SUMMARY.md:25-29`) | recomputed | match |
|---|---|---|---|
| rtl | `9ff28812…420e` | `9ff28812…420e` | **yes** |
| tb | `a378f114…542d` | `70ae45ce…30e2` | **NO** |
| firmware | `c2572d05…91b9` | `c2572d05…91b9` | yes |
| memmap | `c2ecd6da…982a` | `c2ecd6da…982a` | yes |
| third_party | `30c7f549…bbab` | `30c7f549…bbab` | yes |

The RTL that produced the reports is byte-identical to the shipped RTL. The shipped `tb/` tree differs from the one hashed at report time. The cause cannot be established from the sources. One possibility is generated cocotb or sim-build files that were present at report time and excluded from the package.

---

## 15. Python models and tools

| Path | What it does | Source |
|---|---|---|
| `python/datafabric/memmap_gen.py` | Validates the YAML map and generates `generated/sfb_memmap_pkg.sv`, `rtl/dma/dma_defs.svh`, `rtl/interconnect/sfb_perf_defs.svh`, `generated/sfv_df_map.h`, `generated/datafabric_map.py` and `docs/datafabric/MEMORY_MAP.md`. Has `--check` and a `--sfv-pkg` cross-check. | `python/datafabric/memmap_gen.py:1-27` |
| `generated/datafabric_map.py` | Generated Python constants (REGIONS, PAGES, MASTERS, MASTER_DENY, IRQ, REGS, ENUMS) and `decode()` | `generated/datafabric_map.py:1-16` |
| `python/datafabric/trace_export.py` | Converts trace-monitor CSV to MemoryLab canonical CSV or JSON. Validates monotonic cycles, in-order responses and `max_outstanding` (default 1). | `python/datafabric/trace_export.py:1-19,36-78,93-96` |
| `python/datafabric/trace_window.py` | Streams a cycle window out of a large trace | `python/datafabric/trace_window.py:1-10` |
| `python/datafabric/bandwidth_analysis.py` | Per-master bytes per cycle, arbitration delay, latency, conflict cycles and errors, plus per-slave utilisation, from measured traces | `python/datafabric/bandwidth_analysis.py:1-11` |
| `python/datafabric/memorylab_adapter.py` | Runs the external MemoryLab analyser and its DMA model, located through `MEMORYLAB_PY` (**not included in this extract**). It compares predicted against measured cycles and states that the model assumes a 1-cycle SRAM and a 0-cycle crossbar (`:38`). | `python/datafabric/memorylab_adapter.py:1-23,37-61,64-75` |
| `python/datafabric/tests/test_memmap_gen.py` | pytest suite for the generator (20 tests) | §14.1 |
| `tb/dma/cocotb/test_dma_cocotb.py` | **The only Python behavioural model of DataFabric logic:** `ref_transfer` (the DMA reference semantics) and `MemSlave` (an SFB2 slave model) | `tb/dma/cocotb/test_dma_cocotb.py:32-109` |
| `tb/interconnect/v1compat/sfv_cocotb.py` | cocotb helpers (`start`, `RegBus`, `SfbMaster`) | `tb/interconnect/v1compat/sfv_cocotb.py:9,18,44` |
| `scripts/datafabric/*.py` | Regression, lint, synth, GLS, benchmark and report drivers (`unit_regress`, `xbar_regress`, `xbar_mutants`, `soc_regress`, `lint`, `synth`, `gls`, `benchmark`, `report`); `package.sh` zips the project | file headers, lines 1-14 of each |
| `formal/datafabric/run_formal.py`, `jobs_extra.py` | Formal runner (Yosys, smtbmc, ABC PDR) and the job list | `formal/datafabric/run_formal.py:1-6` |
| `third_party/silicaflux-v/tb/models/sfv_golden.py` | Vector/tensor golden models (not DataFabric) | `:1-5` |
| `third_party/silicaflux-v/scripts/{bin2hex,gen_post_vectors,gen_rom,mkimage}.py` | Firmware image tooling (not DataFabric) | headers |

**A Python cycle model of the crossbar or arbiter: NOT FOUND.**

---

## 16. Concise summary table

| Path | Clock | Width (defaults) | Protocol | Max outstanding | SRAM read latency | Port topology | Arbitration | Ordering | Verification status |
|---|---|---|---|---|---|---|---|---|---|
| `generated/sfb_memmap_pkg.sv` | n/a (package) | 32-bit addresses | n/a | n/a | n/a | defines 4 masters × 7 slaves, matrix `28'h7EFFFFF` | n/a | n/a | pytest freshness and cross-check (20 tests, PASS per report) |
| `rtl/interconnect/sfb_crossbar.sv` | clk / rst_n | NM 2, NS 2, AW 32, DW 32 (SoC 4×7, 32/32) | SFB2 valid/ready + rsp_ready, wstrb, rsp_error | 1 per master port, 1 per slave port, no IDs | none assumed; adds 0 cycles | partial crossbar NM×NS | per-slave `sfb_arbiter` (ARB_MODE 1 = RR) with grant lock | in order; one-hot owner register per slave | Sim 115/115, mutants 12/12, PDR PROVED, GLS 3/3 (reported) |
| `rtl/interconnect/sfb_addr_decoder.sv` | combinational | NS 4, AW 32, DW 32 | address → hit/sel | n/a | n/a | one per master | lowest index wins | n/a | through crossbar TB and formal P6 |
| `rtl/interconnect/sfb_arbiter.sv` | clk / rst_n | N 4, MODE 1 | req/stall/accept → one-hot grant | n/a | n/a | one per slave | fixed (0 highest) or RR (advance on accept), lock under stall | n/a | PDR PROVED A1-A4 (reported) |
| `rtl/interconnect/sfb_req_mux.sv` | combinational | NM 4, AW 32, DW 32 | AND-OR payload mux | n/a | n/a | one per slave | n/a | n/a | indirect |
| `rtl/interconnect/sfb_rsp_router.sv` | combinational | NM 4, NS 4, DW 32 | response steer | 1 per slave (busy) | n/a | NS → NM | n/a | owner one-hot | PDR P4 (reported) |
| `rtl/interconnect/sfb_error_slave.sv` | clk / rst_n | DW 32 | SFB2 slave | 1 buffered | responds 1 cycle after accept | one per master | n/a | in order | indirect |
| `rtl/interconnect/sfb_shared_bus.sv` | clk / rst_n | NM 2, NS 2, AW 32, DW 32 | SFB2 | 1 in the whole fabric | 0 added | NM×1 + 1×NS (shared) | RR default | in order | xbar TB TOPO = 1 (reported PASS); not used in SoC |
| `rtl/interconnect/sfb_skid_buffer.sv` | clk / rst_n | WIDTH 32 | valid/ready | 2 entries | +1 cycle | point to point | n/a | FIFO order | PDR PROVED S1-S4 (reported) |
| `rtl/interconnect/sfb_reg_slice.sv` | clk / rst_n | AW 32, DW 32, REQ/RSP_SLICE 1 | SFB2 pass-through | +1 per sliced channel | +1 cycle per sliced direction | point to point | n/a | in order | tb_sfb_reg_slice 15/15 (reported); not used in SoC |
| `rtl/interconnect/sfb_v1_slave_adapter.sv` | clk / rst_n | fixed 32 | SFB2 ↔ SFB v1 | 1 (hold register) | 0 added (legacy SRAM 1 cycle) | point to point | n/a | in order | v1compat cocotb + SoC 18/18 (reported) |
| `rtl/interconnect/sfb_perf_counters.sv` | clk / rst_n | NM 4, CW 32 | register bus (12-bit address) | n/a | n/a | page 7 | n/a | n/a | SoC firmware only |
| `rtl/mem/sfb_sram_slave.sv` | clk / rst_n | DW 32, DEPTH 1024, READ_LATENCY 1 | SFB2 slave on `sram_sp` | library: READ_LATENCY + 1 credits; crossbar caps at 1 | READ_LATENCY (default 1) for reads and write acks | slave | n/a | in order | xsram TB 6 configs × 2 (reported) + SoC sramlib variant |
| `rtl/mem/sfb_sram_1r1w_slave.sv` | clk / rst_n | DW 32, DEPTH 1024, READ_LATENCY 1 | SFB2 slave on `sram_1r1w` | 1 | read READ_LATENCY; write ack +1 cycle | slave | n/a | in order | xsram TB SLAVES = 2 (reported); not used in SoC |
| `rtl/dma/silicaflux_dma.sv` (+ regs, validate, irq) | clk / rst_n | DW 32, ENGINE 0, FIFO 8, BURST 8, MAX_OUT 2, MAX_LEN_LOG2 24 | SFB2 master + register-bus slave + irq | simple 1; buffered MAX_OUT per port (crossbar caps at 1) | none assumed (4 cycles per beat with 1-cycle slaves) | master 3 in SoC, 1 channel | n/a | in order | tb_dma 24 runs, cocotb 6, GLS 2, formal bounded only (reported) |
| `rtl/dma/dma_transfer_engine.sv` | clk / rst_n | DW 32 | SFB2 master | 1 | n/a | 1 port | n/a | strict read → write per beat | as above; formal bounded 23 cycles |
| `rtl/dma/dma_burst_engine.sv` | clk / rst_n | DW 32, FIFO 8, BURST 8, MAX_OUT 2, DUAL_PORT 0 | SFB2 master ×1 or ×2 | MAX_OUT per port | n/a | 1 or 2 ports | n/a | phase-ordered, FIFO credit | as above; formal bounded 22 cycles |
| `rtl/dma/dma_fifo.sv` | clk / rst_n | WIDTH 32, DEPTH 4 (used with 8) | push/pop FWFT | DEPTH | n/a | internal | n/a | FIFO | indirect + sim assertion |
| `rtl/soc/sfv_soc_df.sv` | clk (+ TCK in JTAG), sys_rst_n | AW 32, DW 32 | SFB2 crossbar + v1 adapters | 1 per port, at most 4 in total | 1 cycle (sfv_sram_slave) or SRAM_LATENCY (default 1) | crossbar 4 × 7 (DBG, CPUD, CPUI, DMA × ROM, SRAM0-3, TSPM, PERIPH) | RR (ARB_MODE 1) | in order per master | SoC firmware 18/18 with raw logs present |
| `tb/common/*` | clk / rst_n | AW 32, DW 32 | checker, trace, interface | checker MAX_OUT parameter | n/a | monitor | n/a | checks R5/R6 | used in all SV TBs |

Every "PASS" above is the authors' own result, taken from `reports/datafabric/*`. In this audit nothing was executed except the hash re-computation in §14.4. Raw logs exist only for the SoC runs. The `tb/` hash does not match the reported value; the `rtl/` hash does.
