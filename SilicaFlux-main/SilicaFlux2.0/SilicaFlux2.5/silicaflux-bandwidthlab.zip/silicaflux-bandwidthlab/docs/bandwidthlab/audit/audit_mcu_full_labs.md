# SilicaFlux source-backed audit: Full SilicaFlux (v1 / Gen-2.5), MCU-I, cache repo, lab tools

Scope: read-only static audit of the sources. Nothing was compiled or simulated by the auditor.
Every claim cites `file:line`. "NOT FOUND" means a targeted search of the listed locations found nothing.
Labels used for numbers:

* **RTL** – read directly from RTL code by the auditor (static reading, not simulated).
* **DOC** – stated in a comment/README/doc in the repository (a claim, not a result).
* **REC-SIM** – a simulation/tool result *recorded in a shipped report file*; the auditor did not re-run it, and the raw logs are usually not shipped.

## Path abbreviations

| Abbrev | Absolute path |
|---|---|
| `SFM/` | `<repo>/SilicaFlux-main/` |
| `S25/` | `<repo>/SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` |
| `X/` | `<extract>/` |
| `V1/` | `X/silicaflux/silicaflux/` (v1 cluster zip, `.sv`) |
| `MCU/` | `X/SilicaFlux2.0_SilicaFlux2.5_silicaflux-mcu-i/silicaflux-mcu-i/` |
| `MCR/` | `X/memory_cache_repo/memory_cache_repo/` |
| `SOC/` | `X/soc_integration/soc_integration/` |
| `TL/` | `X/silicaflux-twinlab/` (TwinLab, Angular app) |
| `TF/` | `X/SilicaFlux2.0_SilicaFlux2.5_silicaflux-timingflow/silicaflux-timingflow/` |
| `PL/` | `X/silicaflux-powerlink/silicaflux-powerlink/` |
| `FL/` | `X/SilicaFlux2.0_SilicaFlux2.5_silicaflux-floorplanlab/silicaflux-floorplanlab/` |
| `MF1/` | `X/silicaflux-memoryflow/silicaflux-memoryflow/` (byte-identical copy at `X/SilicaFlux2.0_SilicaFlux2.5_silicaflux-memoryflow/`) |
| `MF2/` | `X/SilicaFlux2.0_SilicaFlux2.5_silicaflux-memoryflow-v2.0.0/silicaflux-memoryflow/` |
| `DF/` | `X/silicaflux-datafabric/silicaflux-datafabric/` (identical copy under `X/SilicaFlux2.0_SilicaFlux2.5_silicaflux-datafabric/`) |
| `ML/` | `X/silicaflux-memorylab/silicaflux-memorylab/` (identical copy under `X/SilicaFlux2.0_SilicaFlux2.5_silicaflux-memorylab/`) |

---

## Executive summary

1. **`.sf` = SystemVerilog with a renamed extension and a renamed language label.** Headers say
   "Language: Silica Flux-2017" (`S25/memory_controller.sf:4`), which the testbenches define as
   "IEEE 1800-2017 language semantics" (`S25/tb_vector_engine.sf:5`, `SFM/tb_tensor_unit.sf:6`). The runner
   compiles them with Icarus `iverilog -g2012` using `SF_EXT=.sf` (`S25/run_sim.sh:5,67,143,152`).
   **They are NOT renamed copies of the v1 `.sv` files**: none of 31 `.sf` files is byte-identical to its v1
   `.sv` namesake (e.g. `memory_controller.sf` 1492 lines vs `V1/rtl/memory_controller.sv` 232 lines). The
   `.sf` set is a separate, much larger "Gen-2.5" rewrite.
2. **The Gen-2.5 `.sf` set does not form a buildable design.** It contains at least two incompatible
   `package silicaflux_pkg` definitions (`SFM/silicaflux_pkg.sf:22` = 64-bit OoO core package, `XLEN=64` at :44;
   `SFM/silicaflux_pkg (1).sf:13` = 32-bit memory transaction types). `compute_tile.sf` instantiates
   `memory_controller`, `vector_engine` and `tensor_unit` with parameter/port names that the shipped modules do
   not have. **Every** shipped 2.5 testbench binds parameter/port names that its DUT lacks (e.g. 49 of 51 names in
   `S25/tb_memory_controller.sf:1251`). The 2.5 `silicaflux_top.sf` instantiates ~30 module types (`sf_core`,
   `sf_l2_cache`, `sf_llc_bank`, `sf_coh_xbar`, ...) that are **NOT FOUND** anywhere. MemoryFlow v2 reports the same
   (`MF2/README.md:49-54`).
3. **Only the v1 `.sv` cluster (`V1/`) is a coherent RTL set**: 4 tiles, 1 KiB SPM per tile, 2×2 XY mesh with
   43-bit flits and 1-flit buffers, a sequential 4×4 tensor unit of about 66-67 cycles, and one 100 MHz clock
   (an assumption; no measured timing exists).
   TimingFlow could not synthesise it (`TF/configs/designs/silicaflux_full.yaml:3-12`).
4. **MCU-I is real, self-consistent and has recorded evidence**: RV32I[M]_Zicsr 2-stage CPU, SFB2 crossbar
   (1 outstanding per port), 4 SRAM banks with 1-cycle read latency, no cache. Reports cover lint, riscv-tests,
   cocotb, Verilator SoC regression, formal, FPGA P&R (industrial 29.28 MHz achieved vs a 25 MHz constraint) and
   pre-layout synthesis (STA NOT RUN).
5. **`memory_cache_repo`** has a 4-way PLRU write-back blocking cache (64 B lines, no MSHRs) and a direct-mapped
   cache, both **not used by any SilicaFlux top**.
6. **Integration targets**: TwinLab has **no importer**; it only exports HTML/JSON/CSV. FloorplanLab
   already writes a `twinlab_floorplan.json` (schema 1.0.0) for SilicaFlux-V. TimingFlow exports
   `timing_report.json/.csv` with WNS/TNS and a *derived* Fmax\*. PowerLink takes SRAM `reads_per_cycle`/
   `writes_per_cycle` YAML plus VCD/SAIF, and writes `power_by_block.csv`/`summary.json`. A standalone
   "PowerGrid" or "ThermalLab" tool is NOT FOUND; both exist only as sub-features (details in section E).
7. **Existing transaction traces**: DataFabric CSV traces (`cycle,event,master,id,addr,op,size,bank,slave,error,
   stall_cycles`) plus the MemoryLab canonical trace importer. These are the closest ready-made input format for a
   bandwidth simulator. MemoryFlow v2 has recorded RTL characterisation of the 2.5 memory controller and tensor unit.

---

## A. What `.sf` and `.sfx` files are

### A.1 `.sf` files
| Evidence | Citation |
|---|---|
| Language label "Silica Flux-2017" | `S25/memory_controller.sf:4`, `S25/noc_interconnect.sf:4`, `S25/compute_tile.sf:6` |
| Label defined as IEEE 1800-2017 (SystemVerilog) | `S25/tb_vector_engine.sf:5`, `SFM/tb_tensor_unit.sf:6` |
| SV constructs throughout (e.g. `memory_controller.sf`: 25× `always_ff`, 14× `always_comb`, 7× `typedef struct packed`, 27× `assert property`) | auditor `grep -c` on `S25/memory_controller.sf` |
| Simulator: Icarus Verilog, `-g2012 -Wall`, extension `.sf` | `S25/run_sim.sh:5`, `:67` (`SF_EXT [.sf]`), `:143`, `:152` |
| Compile order: `silicaflux_pkg.sf` first, then `*_pkg.sf`, interfaces, core | `S25/run_sim.sh:17-19`, `:147-148` |

**Diff against v1 `.sv` (from the `silicaflux.zip` extraction)**: no `.sf` is identical to its `.sv` namesake.

| `.sf` file | lines | v1 `.sv` | lines |
|---|---|---|---|
| `S25/memory_controller.sf` (= `SFM/memory_controller.sf`, byte-identical) | 1492 | `V1/rtl/memory_controller.sv` | 232 |
| `S25/compute_tile.sf` | 2300 | `V1/rtl/compute_tile.sv` | 351 |
| `S25/noc_interconnect.sf` | 1069 | `V1/rtl/noc_interconnect.sv` | 182 |
| `S25/scheduler.sf` | 1450 | `V1/rtl/scheduler.sv` | 175 |
| `SFM/tensor_unit.sf` | 930 | `V1/rtl/tensor_unit.sv` | 260 |
| `S25/vector_engine.sf` / `SFM/vector_engine (1).sf` | 764 / 684 | `V1/rtl/vector_engine.sv` | 189 |
| `S25/tile_interface.sf` | 1403 | `V1/rtl/tile_interface.sv` | 262 |
| `S25/silicaflux_top.sf` | 2013 | `V1/rtl/silicaflux_top.sv` | 467 |
| `SFM/silicaflux_pkg.sf` / `SFM/silicaflux_pkg (1).sf` | 2081 / 136 | `V1/rtl/silicaflux_pkg.sv` | 247 |

Byte-identical pairs between `SFM/` and `S25/`: `forwarding_unit.sf`, `memory_controller.sf`, `silicaflux_pkg (1).sf`,
`tb_compute_tile.sf`, `tb_noc_interconnect.sf`. The `.sf` files inside the RTL zips are yet more variants:
`X/SilicaFlux2.0_SilicaFlux2.5_silicaflux_rtl{,2}/silicaflux/rtl/silicaflux_top.sf` (1538 lines, md5 c637c75e) differ
from `S25/silicaflux_top.sf` (2013 lines, md5 f19a378e). The `silicaflux_pkg.sf` variants are 1728, 2031 and 2081 lines.

**Package conflict (blocking).** `SFM/silicaflux_pkg.sf:22` declares `package silicaflux_pkg` for a 64-bit OoO core
(`XLEN=64` :44; L1D 12-way, 16 MSHRs, L2 1024×16, 64 B lines, AXI 256-bit at :157-197). `SFM/silicaflux_pkg (1).sf:13`
declares the **same package name** with 32-bit memory types (`SF_XLEN=32`, `SF_VLEN=128`, `SF_PADDR_W=32`,
`SF_MEM_TAG_W=8`, `SF_BURST_LEN_W=8` at :18-25) used by `memory_controller.sf`. They cannot be compiled together.

**Interface mismatches (blocking, auditor static check):**
* `S25/compute_tile.sf:1953-1966` instantiates `memory_controller #(.NUM_PORTS,.PORT_LINES)` with ports
  `req_valid_i/req_i/req_ready_o/rsp_*/idle_o`. `S25/memory_controller.sf:96-164` has none of these. Its parameters are
  `SPM_BASE, NUM_BANKS, ...` and its ports are `scalar_req_*`, `vector_req_*`, `burst_*`.
* `S25/compute_tile.sf:1385-1405` binds `vector_engine` with `req_*`/`mem_req_*` ports. `S25/vector_engine.sf:74-120`
  has `iss_*`/`res_*` ports and **no memory port**.
* `S25/compute_tile.sf:1448-1468` binds `tensor_unit #(.PIPE_DEPTH)` with `cmd_*`/`mem_req_*` ports.
  `SFM/tensor_unit.sf:45-83` has `PIPE_STAGES`, `issue_*`, `mat_a_i`, `mat_b_i` and **no memory port**.
* The `compute_tile.sf` package contract (`:128-137`: `sf_mem_req_t`, `SF_MEM_AW`, `SF_MEM_LINE_W`, ...) is NOT FOUND
  in any shipped package (auditor grep over all `.sf` and the RTL-zip `.sf`).
* `noc_packet_t` (default `pkt_t`, `S25/noc_interconnect.sf:83,814`) is NOT FOUND in any package.
* `tile_interface.sf` package contract (`S25/tile_interface.sf:120-132`: `SF_FLIT_DATA_W`, `sf_noc_flit_t`, ...)
  is NOT FOUND in any package.
* All 2.5 testbenches bind names their DUT does not declare (auditor scripted check of the instantiation block
  against the DUT `module ... );` header):

| Testbench instantiation | DUT | Bound names absent from DUT |
|---|---|---|
| `S25/tb_memory_controller.sf:1251` | `memory_controller.sf` | 49 of 51 (e.g. `ADDR_W`, `MISALIGN_MODE`, `s_req_we_i`, `trc_valid_o`) |
| `S25/tb_noc_interconnect.sf:2853` | `noc_interconnect.sf` | 13 of 17 (e.g. `FLIT_W`, `FIFO_DEPTH`, `inj_valid_i`, `trc_valid_o`) |
| `SFM/tb_tensor_unit.sf:849` | `tensor_unit.sf` | 13 of 13 (e.g. `N`, `DATA_W`, `LATENCY`, `in_valid`) |
| `S25/tb_vector_engine.sf:588` | `vector_engine.sf` | 16 of 18 |
| `S25/tb_compute_tile.sf:3691` | `compute_tile.sf` | 44 of 44 |
| `S25/tb_scheduler.sf:3436` | `scheduler.sf` | 31 of 37 |
| `S25/tb_silicaflux_top.sf:3514` | `silicaflux_top.sf` | 59 of 59 |

No 2.5 simulation log, VCD, `sim_build/` or JUnit file is shipped (NOT FOUND), so there is no evidence the 2.5
testbenches were run against this RTL. MemoryFlow v2 wrote its **own** Verilator testbenches for the 2.5
`memory_controller.sf` and `tensor_unit.sf`, and reports them PASS (see B.9).

### A.2 `.sfx` files
Assembly source for the SilicaFlux assembler `sfx_asm.py`.
* `S25/sfx_asm.py:2-6`: "SilicaFlux multi-format assembler ... memory images ... `$readmemh` (.hex), .bin, .mif, .coe".
  `:8-12`: it claims to be "the normative definition of the SilicaFlux v1 instruction encoding" and can emit a
  `silicaflux_isa_pkg` SV package.
* Its encoding is a 6-bit opcode whose `opcode[5:3]` is the FU dispatch port (`S25/sfx_asm.py:20-30,44-49`), with
  VLEN=128 and tensor tiles of 4×4 int32 (`:15-19`). This **differs from the v1 RTL encoding** (5-bit opcode in
  `[31:27]`, `V1/rtl/silicaflux_pkg.sv:35,70-73`).
* The v1 assembler `V1/sim/sfx_asm.py:1-12` (435 lines) is a different, simpler program. `S25/sfx_asm.py` has 3339 lines.
* Example programs: `S25/fibonacci.sfx:1-50` (uses `DFSYNC 0, LSU, TILE`, `.equ`/`.org`). `S25/fibonacci.sfx`,
  `S25/matmul_4x4.sfx` and both `S25/dot_product_parallel*.sfx` all differ from the `V1/sim/programs/*.sfx` versions (different md5).

---

## B. Full SilicaFlux cluster

Two generations exist and must not be conflated:
* **v1 (`V1/rtl/*.sv`)**: coherent, small, Icarus-oriented RTL.
* **Gen-2.5 (`*.sf`)**: large rewrite; individual modules are self-consistent but the set is not integrable (section A).

### B.1 memory_controller (scratchpad SRAM)

**v1 `V1/rtl/memory_controller.sv`**
| Item | Value | Citation |
|---|---|---|
| Size | `SRAM_DEPTH`=256 words × 32 b = **1 KiB per instance** | `V1/rtl/silicaflux_pkg.sv:27`, `memory_controller.sv:52` |
| Width | 32-bit array; vector/burst assembled into a 128-bit buffer | `memory_controller.sv:52,75` |
| Instances | 1 per tile (×4) + 1 shared for control-core scalar LOAD/STORE | `V1/rtl/compute_tile.sv:88-105`; `V1/rtl/silicaflux_top.sv:233-250` |
| Ports | single req/resp (`req_valid/req_ready/req_opcode/addr/wdata/vwdata/length`, `resp_valid/rdata/vrdata`) + independent `wb_*` write port | `memory_controller.sv:28-46` |
| Protocol | blocking FSM; `req_ready` high only in IDLE; **1 transaction outstanding** | `:61-68,111-114,182-183` |
| Scalar read latency | RTL: accept in IDLE, data registered in SCALAR_RD. REC-SIM: **3 cycles/word** sustained | `:123-125,179-184`; `MF2/reports/data/sf_char_results.json:84` |
| Scalar store | committed in the IDLE cycle, `resp_valid` next edge | `:128-132` |
| Vector (VLOAD/VSTORE) | 4 words serially, one per cycle, + 1 deliver cycle. REC-SIM 2.2857 B/cycle | `:135-149,187-206`; `sf_char_results.json:87` |
| DF burst (DFLOAD/DFSTORE) | `req_length` up to 31 words, but the lane index is `burst_idx[1:0]` → **only 4 distinct words; longer bursts are broken**. REC-SIM: "defect reproduced", 4 of 8 words not written | `:151-168,191-196,212-217`; `sf_char_results.json:89,93` |
| Arbitration | none on the request port (single requester). The `wb_*` port is a 2nd unarbitrated writer (tied off in tiles) | `:85-88`; `compute_tile.sv:102-104`; REC-SIM `sf1_array_writes_in_one_cycle=2` `sf_char_results.json:92` |
| Alignment | `addr[1:0]!=0` → `alignment_err` pulse | `:79-80,116-119` |

**Gen-2.5 `S25/memory_controller.sf`** (defaults)
| Item | Value | Citation |
|---|---|---|
| Organisation | `NUM_BANKS`=8 single-port banks × `BANK_DEPTH`=512 lines × 128 b, per-byte WE, line-interleaved = **64 KiB** | `:14-19,99-100` |
| Domains | lines [0,`SCALAR_LINES`=1024) scalar = 16 KiB, rest vector; `STRICT_DOMAINS`=1 | `:21-27,101,114` |
| Aperture | `SPM_BASE`=0x1000_0000 | `:98` |
| Read latency param | `SRAM_LATENCY`=1 (array pipe) | `:103,979-1017` |
| End-to-end load latency | pipeline I (2-entry skid) → A (arbitrate/issue) → M (L cycles) → R (resp FIFO). REC-SIM: **3 cycles** scalar and vector at L=1 | `:30-45`; `MF2/reports/data/sf_char_results.json:11-12` |
| Ports | 3 requesters: scalar 32 b, vector 128 b + lane mask, burst (descriptor + wdata + rdata + done) | `:126-154,169-172`; types in `SFM/silicaflux_pkg (1).sf:70-134` |
| Burst | 1..`BURST_MAX_BEATS`=256 beats of 128 b; no page (4 KiB) or domain crossing; 1 descriptor in flight | `:110-111,713-733,738` |
| Queues / outstanding | 2-entry ingress skid per port; response credits `SCALAR_RSP_DEPTH`=4, `VECTOR_RSP_DEPTH`=4, `BURST_RDATA_DEPTH`=8, `BURST_WDATA_DEPTH`=4 | `:105-108,188,677-706` |
| Arbitration | per-bank, round-robin (`ARB_ROUND_ROBIN`=1) or fixed scalar>vector>burst; ≤3 accesses/cycle if bank-disjoint | `:35-37,113,378-383,887-935` |
| Ordering | in-order per port, fixed latency; no cross-port ordering; same-cycle bank contention serialised | `:48-56` |
| Throughput (REC-SIM) | ≈1 word/cycle scalar, ≈1 line (16 B)/cycle vector; disjoint banks 1.99 req/cycle; same bank 0.998; 3 ports 2.49 req/cycle = 29.87 B/cycle; burst efficiency 0.2 (L=1 load) → 0.985 (L=256) | `sf_char_results.json:13-17,19,35-40` |
| Other | parity per byte (`PARITY_EN`), init sweep after reset (512 cycles REC-SIM), coherence write-notify hook, `bank_conflict_o` | `:116-117,156-163,539-555`; `sf_char_results.json:10` |
| Clock | single `clk_i` | `:119` |
| Integration | **not instantiable by `compute_tile.sf`** (interface mismatch, section A) | `S25/compute_tile.sf:1953-1966` |

Unused helper: `S25/sram-decoder.sf:2-22` (`sf_sram_bank_decode`, line-interleave decode). It is not instantiated by any `.sf`.

### B.2 compute_tile
**v1 `V1/rtl/compute_tile.sv`**
* SRAM per tile: one `memory_controller` = 1 KiB (`:88-105`). Local staging is `vreg_local[0:7]` × 128 b (`:72`).
* **The vector engine and tensor unit do NOT access SRAM.** Memory ops go to the controller and the result goes to
  `tile_result_*` (`:236-251,288-297`). Vector operands come from scheduler broadcast (`:254-261`). Tensor operands
  are `vreg_local[0..7]` (`:143-161`), and `OP_MATMUL` only reloads `vreg_local[0..1]` from the inputs (`:265-269`).
* One token at a time: FSM T_IDLE/T_MEMWAIT/T_VECEXEC/T_TENSOR (`:184-190`).
* NoC use: on DFEXEC completion, the scalar result is sent as a single flit (`:338-349`). `noc_flit_valid` is also
  assigned in the main FSM (`:209,216`), so the signal is multiply driven (auditor reading).
* Receive path stores `noc_flit_in.data` into `vreg_local[src_col]` (`:225-228`). The v1 NoC reconstructs eject
  flits with a zeroed header (`V1/rtl/noc_interconnect.sv:169-178`), so `src_col` is 0 (auditor reading).

**Gen-2.5 `S25/compute_tile.sf`** (as documented and parameterised; not elaborable)
* Single clock domain (`:7`). Parameters: `NUM_LANES`=4, `NUM_ALU`=2, `NUM_TEN`=1, `LSU_TXN`=8,
  `TEN_PIPE_DEPTH`=20, `SPM_S_BYTES`=16 KiB, `SPM_V_BYTES`=64 KiB, `NOC_EN`=0 (`:145-169`).
  The tile SPM total (80 KiB) differs from `memory_controller.sf`'s 64 KiB default.
* Crossbar: requesters LSU, vector, tensor[k], NoC → targets {scalar SPM, vector SPM, NoC}
  (`:16-19,245-257`). Arbitration order: write-burst lock, then starved requesters (age ≥ `XB_STARVE_LIM`=16), then fixed
  LSU > vector > tensor > NoC (`:63-65,157`). Reads return `blen+1` beats. Weakly ordered between requesters, with
  `DFSYNC.M` as the fence (`:66-71`).
* ACLs: vector and tensor may only touch the vector SPM (`ACL_VEC/ACL_TEN = 3'b010`, `:166-168`).
* Perf outputs: `perf_ingress_o`, `perf_sfx_held_o`, `perf_xb_conflict_o`, `perf_wb_saturated_o` (`:226-230,2134-2136`).

### B.3 noc_interconnect
**v1 `V1/rtl/noc_router.sv` + `noc_interconnect.sv`**
| Item | Value | Citation |
|---|---|---|
| Topology | 2×2 mesh, 5-port routers (L,N,S,E,W) | `noc_interconnect.sv:5-9`; `noc_router.sv:2-4` |
| Flit | 43 b packed = type 2 + dst 2+2 + src 2+2 + data 32 + valid 1; `NOC_WIDTH`=32 | `noc_router.sv:32-35`; `silicaflux_pkg.sv:28,190-198` |
| Routing | XY (column first, then row) | `noc_router.sv:40-49` |
| Buffering | 1-flit input register + 1-flit output register per port | `noc_router.sv:51-57` |
| Per-hop latency | RTL derived: ≥2 cycles/hop (ibuf → obuf). No simulated number found | `noc_router.sv:82-121,125-190` |
| Arbitration | fixed priority per output, LOCAL > N > S > E > W | `noc_router.sv:123-136` |
| Flow control | valid/ready; input ready = input buffer empty | `noc_router.sv:75-80` |
| Auditor concern (not simulated) | the input buffer drains on `out_accept[rt]` (output register accepted), not on "this input was moved into the output register" (`noc_router.sv:94-95,129-135`). A static reading suggests flits can be **duplicated** (output register reloads from a still-valid input) or **dropped** (input cleared after losing arbitration) | — |
| Ejected header | zeroed (`up(ej_data, '0)`) | `noc_interconnect.sv:169-178` |

**Gen-2.5 `S25/noc_interconnect.sf`** (not elaborable: `noc_packet_t` undefined)
| Item | Value | Citation |
|---|---|---|
| Topology / routing | 2×2 mesh, XY dimension-ordered, wormhole | `:5-6,78` |
| Flit width | `$bits(pkt_t)`, with `pkt_t=noc_packet_t` **undefined**. The TB-local flit is 100 b (chk 16 + payload 64 + id 16 + 4×1 coord) | `:83,158`; `S25/tb_noc_interconnect.sf:69-96` |
| Buffer depth | `BUF_DEPTH`=4 per input (≥2 required) | `:88,214-216,472` |
| Per-hop latency | DOC: **2 cycles/hop** (S1 BW+RC, S2 SA+ST, registered links). TB contract says **1 cycle/hop**, zero-load = hops+1 | `:17-23`; `S25/tb_noc_interconnect.sf:40-41,49` |
| Arbitration | per-output round-robin (optional 2-class QoS, off); wormhole lock if `FLITS_PER_PKT>1` | `:21,40-41,62-64,588-637` |
| Flow control | on/off, ready = registered !full | `:25-31,65-68` |
| Ordering | in-order per (src,dst) | `:42-43` |
| Telemetry | `perf_link_stall_o`, `perf_hol_block_o`, `noc_idle_o` | `:137-140,837-842` |

### B.4 scheduler
* **v1 `V1/rtl/scheduler.sv`**: single instruction in. Per-tile busy scoreboard (`:73-89`), so **max 1 token per tile**
  (4 cluster-wide). DFSYNC barrier stalls until all tiles are idle (`:97-108`). Token fields are broadcast and valid
  is one-hot (`:116-148`). Writeback uses sequential `if`s (last match wins, i.e. tile 0) and always writes
  `wb_reg='0` (`:158-173`).
* **Gen-2.5 `S25/scheduler.sf`**: OoO issue window `IQ_DEPTH`=32 (`:65`), `NUM_ISSUE_PORTS`=8 (`:67`),
  `ITT_PER_PORT`=8 in-flight per port (`:70`), `PORT_LAT`={1,1,3,1,0,0,0,0} (`:82`), DFSYNC epochs (`:24-25`),
  single clock (`:6`). Its package contract (`:43-57`) is not satisfied by the shipped packages.

### B.5 tensor_unit
| Gen | Array / datatype | Latency | Operand loading | Citation |
|---|---|---|---|---|
| v1 `V1/rtl/tensor_unit.sv` | 4×4, 32-bit signed, result truncated to 32 b, sequential 1 MAC/cycle | DOC "~66 cycles" (`:7`). REC-SIM **67 cycles** start→done, 0.94 MAC/cycle. **v1 README claims "~20-cycle"** (`V1/README.md:239`), which contradicts the RTL | `:5-7,51,201-249`; `MF2/reports/data/sf_char_results.json:108-110` |
| 2.5 `SFM/tensor_unit.sf` | `DIM`=4, `OP_W`=8 (INT8), `OUT_W`=32, exact accumulator, Booth/CSA tree | `PIPE_STAGES`=20, issue→result **PIPE_STAGES+1 = 21** (DOC). REC-SIM 21 cycles, 0.99 products/cycle = 63.4 MAC/cycle; no accumulation across issues | `:5-14,24-40,46-51`; `sf_char_results.json:60-62` |

2.5 operand loading: full A and B matrices (4×4×8 b = 128 b each) on the issue handshake; **no memory port**
(`SFM/tensor_unit.sf:64-71`). MemoryFlow v2 reports that inside a tile it reaches about 9 % of peak behind a 16 B/cycle
vector port (`MF2/README.md:58-61`; DOC/analysis, not RTL of an integrated tile).

### B.6 vector_engine
| Gen | LANES | Latency | Citation |
|---|---|---|---|
| v1 | `LANES_DEFAULT`=4 (4/8/16) × 32 b | RTL: result registered **1 cycle** after `issue_valid` (`result_valid <= issue_valid`). Header says "2 stages"; README says "2-cycle". LANES=16 reduction is "simplified" (incomplete) | `V1/rtl/silicaflux_pkg.sv:26`; `vector_engine.sv:16-18,30,143-144,160-167`; `V1/README.md:239` |
| 2.5 `S25/vector_engine.sf` | `LANES`=4, `LANE_W`=32 | `EX_STAGES`=1 → latency 1; =2 → latency 2 | `:19-20,46-47,55` |
| `SFM/vector_engine (1).sf` | `LANES`=8 | same EX_STAGES rule | `:19-21,88-90` |

Neither 2.5 vector engine has a memory port (`S25/vector_engine.sf:74-120`).

### B.7 tile_interface (chiplet serialiser)
* **v1**: `LINK_WIDTH`=8 (8/16/32 allowed) (`V1/rtl/tile_interface.sv:14,31`); instantiated with 8 (`V1/rtl/silicaflux_top.sv:433`).
  A 43-bit flit takes `ceil(43/8)` = **6 beats** (`:73-75`); the header claims "4 x 8-bit beats" (`:10`), which is wrong.
  The credit is a level (`phy_tx_credit`). A 2-FF synchroniser sits on RX (`:145-163`) although the whole design uses one `clk`.
* **2.5 `S25/tile_interface.sf`**: dual clock (`tile_clk_i`, `noc_clk_i`), Gray-pointer CDC FIFOs
  `TX/RX_FIFO_DEPTH`=16 flits, HEAD/BODY/TAIL framing with CRC-8 and per-flit parity (`:14-20,25-60,160-176`).
  Link width is `SF_FLIT_DATA_W`, which is **undefined** (`:122`).

### B.8 Clock domains and SDC
* v1: one `clk` (`V1/rtl/silicaflux_top.sv:43`). The SDC async group for `phy_rx_clk` is commented out (`V1/synth/silicaflux.sdc:31-33`).
* **`silicaflux.sdc` frequency is ASSUMED: 100 MHz / 10 ns** (`V1/synth/silicaflux.sdc:6,14-17`; Arty XDC
  `V1/synth/vivado/silicaflux_arty.xdc:20`). The README gives "Fmax (est.) 80–110 MHz" (`V1/README.md:226`).
  **Measured Fmax: NOT FOUND.** `synth.tcl` would write `build/timing.rpt` (`V1/synth/vivado/synth.tcl:15,100`), but no report is
  shipped. TimingFlow lists full v1 as PARTIAL: "Yosys 0.33/0.70 parse FAIL at silicaflux_pkg.sv:218", so
  synthesis/STA is blocked (`TF/configs/designs/silicaflux_full.yaml:3-12,25-26`).
* 2.5: `compute_tile.sf`, `scheduler.sf`, `memory_controller.sf` and `noc_interconnect.sf` are single-clock
  (`compute_tile.sf:7`; `scheduler.sf:6`; `memory_controller.sf:119`; `noc_interconnect.sf:824`).
  `tile_interface.sf` is tile/NoC dual-clock. `S25/silicaflux_top.sf:18-23` lists `clk_core_i`, `clk_mem_i`, `clk_host_i`,
  `clk_rtc_i` and `jtag_tck_i`. The RTL-zip variant lists `clk_i`, `mem_clk_i` and `dbg_clk_i`
  (`X/SilicaFlux2.0_SilicaFlux2.5_silicaflux_rtl/silicaflux/rtl/silicaflux_top.sf:20-24`). **No SDC for 2.5: NOT FOUND.**

### B.9 Verification evidence for the cluster
* v1 testbenches exist (`V1/tb/*.sv`) and dump VCDs (e.g. `V1/tb/tb_memory_controller.sv:97-98`), but **no logs or VCDs
  are shipped**. `tb_memory_controller.sv` advertises 5 tests (`:5-10`) and implements 3 (`:108-147`).
  `tb_silicaflux_top.sv` has no scalar LOAD test (auditor grep).
* v1 control-core scalar LOAD: `mem_req_ready` is declared but unused (`V1/rtl/control_core.sv:53`). MEM/WB samples
  `mem_resp_valid` in the same cycle the request is issued (`:240-257,263-274`), while the controller responds ≥2
  cycles later. The auditor's reading is that a scalar LOAD would not write back memory data (**not simulated**).
* 2.5: shipped testbenches do not match the DUTs (section A). Independent evidence is MemoryFlow v2 REC-SIM:
  `sf25_memctrl` PASS with 150,843 checks, `sf25_tensor` PASS, `sf1_memctrl` DEFECT (expected), `sf1_tensor` PASS
  (`MF2/reports/data/sf_char_results.json`). The `log_path` values point to a `build/` directory that is **not shipped** (`:48,71,96,113,137`).

---

## C. MCU-I (`MCU/`)

| Topic | Finding | Citation |
|---|---|---|
| What it is | RISC-V MCU SoC, two configs (BASIC, INDUSTRIAL). Honest status: sim/formal/synth/FPGA bitstream only; **no P&R STA, no silicon, no board run** | `MCU/README.md:1-18` |
| Top-level | `mcu_top` (config wrapper) → `mcu_soc` | `MCU/rtl/top/mcu_top.sv:1-18,60`; `MCU/rtl/top/mcu_soc.sv:1-22,26-86` |
| CPU ISA | RV32I[M] (or RV32E) + Zicsr, M-mode only; RV32M 0/1 (iterative, 35-cycle fixed)/2 (1-cycle mul) | `MCU/rtl/cpu/mcu_cpu.sv:7-11,19-21,52-57`. `MCU/configs/industrial.yaml:5` says "34-cycle", which is inconsistent |
| Pipeline | 2 stages IF/EX, in order; IF has 1 outstanding instruction request + 2-entry fetch buffer; load/store **blocking**; CPI ALU 1, LD/ST 2 (+wait), taken branch 3 | `mcu_cpu.sv:22-30` |
| Memory interface | separate I and D ports, OBI-style req/gnt + rvalid (SFB v1 master); `rsp_ready` tied 1 | `mcu_cpu.sv:41-43,61-77`; `mcu_soc.sv:171-187` |
| Max outstanding | CPU-I 1, CPU-D 1 (blocking); crossbar enforces **≤1 per master port and ≤1 per slave port** | `mcu_cpu.sv:23-27`; `MCU/third_party/silicaflux-datafabric/rtl/interconnect/sfb_crossbar.sv:19-23,117-122` |
| Bus | `sfb_crossbar` SFB2, NM=3 (BASIC) or 4 (+DMA) masters × NS=6 slaves (ROM, 4 SRAM banks, peripheral bridge), 32-bit addr/data, round-robin (`ARB_MODE=1`), alignment check, 0 added latency (combinational), decode-error slave. The I-port is denied the peripheral window | `mcu_soc.sv:88-95,107-124,152-163`; `sfb_crossbar.sv:24-25,41,139-160` |
| Arbitration | per-slave `sfb_arbiter`, round robin with grant lock under back-pressure. Formal: `arbiter_rr_n4` PROVED (ABC PDR) | `sfb_crossbar.sv:15-16,147-152`; `MCU/reports/SUMMARY.md:73` |
| SRAM | BASIC 4 × 4096 words = **64 KiB**; INDUSTRIAL 4 × 8192 words = **128 KiB** with odd byte parity (36-bit words). Banks are **contiguous, not interleaved** (bank b at `SRAM_BASE + b*BANK_BYTES`) | `MCU/configs/basic.yaml:7-9`; `MCU/configs/industrial.yaml:6-8`; `mcu_soc.sv:110-111` |
| SRAM latency | `mcu_sram_bank #(.READ_LATENCY(1))` over `sram_sp` (1RW); response `READ_LATENCY` cycles after acceptance; `RSP_FIFO_DEPTH`=RL+1 sustains 1 access/cycle; writes ack'd (`WRITE_ACK=1`) | `mcu_soc.sv:253-264`; `MCU/rtl/mem/mcu_sram_bank.sv:26-33,88-100`; `MCU/third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv:12-24` |
| ROM | 8 KiB window (2048 words), 1-cycle | `MCU/configs/memmap.yaml:38-39`; `MCU/docs/ARCHITECTURE.md:98` |
| Peripherals | SYSCTRL, INTC, MTIMER, UART0, SPI0, GPIO, FAULT, WDT, GPTIMER (always); DMA, PWM, I2C0, UART1, SPI1, DSP (INDUSTRIAL) | `MCU/configs/memmap.yaml:45-60`; `mcu_soc.sv:432-607` |
| Peripheral path | `sfb_reg_slice` (+1 cycle per access) → `sfb_v1_slave_adapter` → `sfv_periph_bridge` (32 × 4 KiB pages; 2-cycle access) | `mcu_soc.sv:287-330`; `MCU/docs/ARCHITECTURE.md:68-69` |
| DMA | 1 channel, one transaction in flight, **4 cycles per element** with 1-cycle slaves. REC-SIM 1 KiB SRAM→SRAM = 1,104 cycles | `MCU/rtl/dma/mcu_dma.sv:1-20,29`; `MCU/docs/PERIPHERALS.md:64-72`; `MCU/docs/VERIFICATION.md:70` |
| Address map | ROM 0x0000_0000 (8 KiB); SRAM 0x1000_0000 (window 256 KiB, configured 64/128 KiB, above size → decode error); PERIPH 0x4000_0000 (128 KiB, 32 pages, execute-never) | `MCU/configs/memmap.yaml:37-43` |
| Clocking | one functional `clk` + JTAG `tck`; ICGs for CPU sleep and peripherals | `mcu_soc.sv:12-16`; `MCU/docs/CLOCK_RESET.md:5-16` |
| Frequency targets | ASIC SDC: `CLK_PERIOD_NS` 20 ns (130 nm) / 25 ns (180 nm), explicitly "TARGETS, not achieved"; FPGA LPF 25 MHz | `MCU/asic/constraints/mcu_soc.sdc:3-6`; `MCU/asic/configs/sky130hd.cfg:15`; `gf180mcu.cfg:15`; `MCU/docs/CLOCK_RESET.md:23-24` |
| Measured timing | FPGA (ECP5, nextpnr) post-route: **INDUSTRIAL 29.28 MHz**, **BASIC 31.50 MHz** (constraint 25 MHz); pre-route estimate 20.20 MHz (FAIL). ASIC STA **NOT RUN** | `MCU/reports/fpga/industrial/nextpnr_report.json` key `fmax`; `MCU/reports/fpga/basic/nextpnr_report.json` key `fmax`; `MCU/reports/fpga/industrial/nextpnr_key.log:7,43`; `MCU/reports/asic/sky130hd/industrial_noparity/summary.json:17` |
| Cache | **NONE** ("no caches") | `MCU/docs/ARCHITECTURE.md:50-51,96-97`; `mcu_cpu.sv:20-21`; `MCU/docs/AUDIT.md:21` |
| Testbenches | riscv-tests harness `MCU/tb/cpu/tb_cpu.sv`; Verilator SoC TB `MCU/tb/soc/tb_mcu_soc.sv` + `sim_main_cov.cpp`; cocotb units `MCU/tb/unit/test_*.py`, `run_unit.py`; formal `MCU/formal/*.sv`, `run_formal.py` | file listing |
| Evidence of runs (REC-SIM) | Lint PASS; riscv-tests 55/63/63 pass; cocotb 12 suites PASS; SoC regression BASIC 15/15, INDUSTRIAL 18/18 (Verilator, 10 ns sim clock); coverage line 82.3 % / 89.1 %; formal table; per-test UART logs shipped | `MCU/reports/SUMMARY.md:19-80`; `MCU/reports/sim/soc_industrial.txt:1-3`; `MCU/reports/sim/logs/*/*.uart.log` |
| Perf hooks | CPU `mcycle`/`minstret` CSRs; crossbar `ev_req_accept/ev_req_stall/ev_arb_loss/ev_rsp_stall` exist but are **unconnected** in `mcu_soc` | `mcu_cpu.sv:357,382-385`; `sfb_crossbar.sv:81-85,175-177`; `mcu_soc.sv:150,162` |
| Calibration data | DSP FIR benchmark cycle counts; MTI latency 83 cycles | `MCU/reports/bench/dsp_benchmark.md:5-9`; `MCU/docs/VERIFICATION.md:68` |

Note: TimingFlow and FloorplanLab both say MCU-I "does not exist in the repository" (`TF/configs/designs/mcu_i.yaml:1-8`;
`FL/configs/mcu_i/design.yaml:1-10`). Those tools predate the MCU-I zip, so their MCU-I statements are stale.

---

## D. memory_cache_repo and soc_integration

### D.1 `MCR/` (generic memory/cache library)
| Module | Type | Line / assoc / replacement | Write policy | MSHRs / blocking | Latency | Citation |
|---|---|---|---|---|---|---|
| `set_assoc_cache` | N-way SA, defaults `NUM_SETS`=128, `NUM_WAYS`=4, `LINE_SIZE`=64 B (32 KiB), 32-bit data | 1/2/4-way; 2-way true LRU; 4-way tree PLRU (3 bits/set) | **write-back, write-allocate** (write miss fills, then writes in S_RESPOND) | **no MSHRs; blocking FSM** IDLE/HIT/WRITEBACK/FILL/RESPOND; word-serial refill over `mem_req/mem_ack` | hit: req (IDLE) → S_HIT → `cpu_ack` registered = ack 2 edges after req (RTL); miss: writeback + fill of `LINE_SIZE/4` words | `MCR/rtl/set_assoc_cache.sv:1-38,74-75,91-95,167-218,258-337` |
| `direct_mapped_cache` | DM, `CACHE_LINES`=256, `LINE_SIZE`=64 B (16 KiB) | — | write-back | blocking, same FSM shape | DOC "Hit: 1 cycle"; RTL acks in S_HIT (the cycle after IDLE) | `MCR/rtl/direct_mapped_cache.sv:1-36,105-148,205-212` |
| `memory_controller` | DRAM-style FSM (ACT/CAS/PRE/REF), `BURST_LEN`=8, tRCD=3, tCL=3, tWR=2, tRP=3, tRFC=12, refresh 3200 | — | — | single request in flight (`req_ready`) | parameterised | `MCR/rtl/memory_controller.sv:1-41,196-201,250` |
| others | `sp_ram`, `dp_ram`, `sync_fifo`, `async_fifo` | | | | | `MCR/rtl/*.sv` |

* Perf counters: `perf_hits`, `perf_misses`, `perf_writebacks` (`set_assoc_cache.sv:57-60`; `direct_mapped_cache.sv:55-57`).
* Auditor concern (not simulated): `hit_way`/`victim_way` are computed from the **live** `cpu_addr`
  (`set_assoc_cache.sv:84-86,106-137`). S_HIT uses `hit_way` with `lat_index` (`:277-282`), so this is only correct
  if the CPU holds `cpu_addr` stable. The comment claims "from latched index during miss" (`:122`).
* Sim flow: Verilator by default (`MCR/sim/Makefile:3,21,92`).
* **Used by any SilicaFlux top? NO.** No instantiation of `set_assoc_cache` or `direct_mapped_cache` outside `MCR/` (auditor grep over
  all `.sv/.sf/.v/.f`). MCU-I explicitly does not use it (`MCU/docs/AUDIT.md:21`). MemoryLab and MemoryFlow only
  reference it as a model parameter source (`ML/python/memorylab/cache.py:7`; `MF2/memoryflow/silicaflux/inventory.py:262-264`).
  The 2.5 package declares L1/L2 cache *types* (`SFM/silicaflux_pkg.sf:156-174`), but the cache modules are NOT FOUND (B.8 and section A).

### D.2 `SOC/` (soc_integration)
A standalone, generic SoC framework not derived from SilicaFlux (no "SilicaFlux" string in it, auditor grep).
* 1 master (external CPU **BFM**, `SOC/tb/models/cpu_bfm.sv`) / 6-slave SSB fabric (`SOC/README.md:9-33`;
  `SOC/rtl/bus/soc_fabric.sv:1-40`).
* Map: ROM 64 KB @0x0, SRAM 128 KB @0x2000_0000, Timer/GPIO/UART/IRQ @0x4000_0000.. (`SOC/README.md:37-46`).
* SSB protocol: valid/ready request, valid/ready response, "all slaves respond in exactly 1 cycle"
  (`SOC/README.md:50-64`). SRAM is 32768 × 32 b, `req_ready` always 1, 1-cycle response (`SOC/rtl/memory/soc_sram.sv:4-16`).
* **A real VCD is shipped**: `SOC/sim/dump.vcd` (302 KB, Icarus, `$timescale 1s`, signals `cpu_req_valid/ready/addr/
  write/wdata/wstrb`, `cpu_rsp_*`; header lines 1-40).

---

## E. Integration targets for a bandwidth simulator

### E.1 TwinLab (`TL/`)
* Angular "AI Studio" app (`TL/README.md:5-20`). **No importer: NOT FOUND.** No `FileReader`, file input, `HttpClient`
  or JSON schema import (auditor grep of `TL/src`). The only `JSON.parse` calls are deep copies (`TL/src/app/services/semiconductor-physics.ts:476-477,586`).
  FloorplanLab independently states the same: "keeps its floorplan as a hard-coded `signal<SemiconductorBlock[]>` ... and has NO file
  import" (`FL/python/floorplanlab/twinlab.py:3-9`). See also `TL/src/app/services/twinlab-state.ts:232`.
* Internal data model (what an importer would have to produce): `SemiconductorBlock`, `ArchitectureConfig`
  (memory: `sramBankCount`, `sramMacroSizeKb`, `memoryBusWidthBits`, `l2CacheKb`, `eccMode`; interconnect: topology,
  arbitration, `busWidthBits`, `cdcFifoDepth`), `ThermalResult`, `PowerGridResult`, `TimingPath`, `WorkloadRoofline`
  (`TL/src/app/models/semiconductor.models.ts:31-52,88-126,128-150,167-191`). Defaults are demo values
  (e.g. `freqTargetMhz: 125`, `sramBankCount: 4`, `memoryBusWidthBits: 128` at `twinlab-state.ts:187,208,210`).
* Export only: HTML / JSON / CSV "Engineering Dossier". The JSON keys are `project, targetArchitecture, processNode,
  architectureConfig, thermalAnalysis, powerIntegrity, waferEconomics, generatedAt`. CSV columns are `Metric,Value,Unit,Provenance`
  (`TL/src/app/components/reports-export/reports-export.ts:16-69`).
* Thermal and IR solvers are internal (SOR finite difference) (`semiconductor-physics.ts:30,83,175`).

### E.2 TimingFlow (`TF/`)
* Exports per run: `timing_report.json` (manifest, synth, audit, gates, cdc, impact, stages→summary),
  `timing_scenes.csv`, `critical_paths.csv`, `constraint_audit.csv`, `timing_report.html`/`.txt`, PNG plots
  (`TF/timingflow/report.py:55-61,220-250,328`).
* `timing_scenes.csv` columns include `wns_ns, tns_ns, whs_ns, ths_ns, reg2reg_setup_wns_ns, reg2reg_fmax_derived_mhz,
  sram_read_setup_wns_ns, sram_write_setup_wns_ns, setup_violators, ...`
  (`TF/reports/silicaflux_v/ihp_sg13g2/baseline/timing_scenes.csv:1`). `critical_paths.csv` columns: `stage,scene,kind,rank,
  slack_ns,arrival_ns,required_ns,group,startpoint,endpoint,...,cell_delay_ns,net_delay_ns,logic_depth,...`
  (`.../critical_paths.csv:1`).
* **Fmax is DERIVED, not measured**: `1000/(period - reg2reg_wns)` (`TF/timingflow/summary.py:131-132`;
  `TF/timingflow/dashboard.py:188`).
* Designs covered with results: `silicaflux_v`, `silicaflux_v_df`, `blk_tensor`, `blk_cpu`, `blk_sramlib_ihp` and others
  (`TF/reports/*`). **Full SilicaFlux: BLOCKED** (`TF/configs/designs/silicaflux_full.yaml:3-12`). **MCU-I: NOT_FOUND at that time**
  (`TF/configs/designs/mcu_i.yaml:1-8`).
* Useful memory numbers (SilicaFlux-V, IHP): SRAM macro clock→DOUT for 2048×64 is 5.33–5.60 ns typ / 8.88–9.29 slow; for 512×64 it is 3.77–4.03 / 6.31–6.73.
  The SoC at 20 ns: typ +2.841 ns, slow −7.388 ns at post-global-route (derived Fmax\* 36.5 MHz slow / 58.3 MHz typ)
  (`TF/FINAL_ANSWERS.md:43,46`; `TF/reports/silicaflux_v/ihp_sg13g2/baseline/timing_report.txt:1-40`).

### E.3 PowerLink (`PL/`)
* Chips modelled: **SilicaFlux-V** (65 nm generic, 100 MHz, "pre-synthesis planning model", gate counts are estimates)
  and a **hypothetical SilicaFlux-X** (`PL/configs/chips/silicaflux_v.yaml:1-28`; `PL/README.md:75`). The full SilicaFlux cluster
  and MCU-I are not modelled (auditor listing of `PL/configs/chips/`).
* **Inputs a bandwidth simulator could drive**: per-workload `reads_per_cycle`/`writes_per_cycle` per SRAM block and
  `alpha` per logic block (`PL/configs/workloads/silicaflux_v_workloads.yaml:38-40,52-54,66-68,92-94,106-108`).
  The SRAM energy model is `P_sram = (reads*E_read + writes*E_write) * f * (V/V_char)^2` (`PL/powerlink/power/dynamic.py:7,175-180`),
  with per-macro `read_pj`/`write_pj` marked as assumptions (`PL/configs/tech/generic_65nm.yaml:72-81`). VCD/SAIF activity import
  is provided by `PL/powerlink/power/activity.py:1-8,75,242,304`.
* Output formats: `power_by_block.csv` (`profile,block,rail,kind,p_data_w,p_clock_w,p_sram_w,p_leak_w,p_fixed_w,alpha,
  clock_enable,activity_source,temp_c`), `summary.json` (`chip, max_profile, power_mw{profile}, core_current_ma,
  static_ir_worst_mv, dynamic_ir_worst_mv, budgets, packages, tj_c, risks, crosscheck_all_pass, verdict`),
  `ir_drop_static_mv.csv` (grid matrix), `thermal_map_export.csv` (`x_um,y_um,temp_c,power_w`), `risks.csv`,
  `assumptions.csv`, `manifest.json`, `REPORT.md`, `report.html`, SPICE cross-check decks (`PL/results/silicaflux_v/*`;
  `PL/README.md:100`).
* The PDN grid solver is `PL/powerlink/electrical/grid.py:1-8`.

### E.4 "PowerGrid" and "ThermalLab"
* **PowerGrid as a separate tool/repo: NOT FOUND.** The name appears only as a TwinLab type/state (`PowerGridResult`,
  `TL/src/app/models/semiconductor.models.ts:140-150`; `reports-export.ts:42`), a FloorplanLab model
  (`class PowerGrid`, `FL/python/floorplanlab/twinlab.py:103-106`) and ORFS PDN scripts in FloorplanLab.
* **ThermalLab as a separate tool/repo: NOT FOUND.** It exists only as a TwinLab component
  (`TL/src/app/components/thermal-lab/thermal-lab.ts`) and as PowerLink's thermal module (`PL/powerlink/thermal/model.py`).

### E.5 FloorplanLab (`FL/`)
* OpenROAD/ORFS floorplans of **SilicaFlux-V** (`top: sfv_soc_df`). Full SilicaFlux: `status: not_available`, because
  `silicaflux_top.sf` has no SRAM macro mapping (`FL/configs/full_silicaflux/design.yaml:1-11`).
* **Block-placement export = TwinLab exchange JSON, `schema_version` "1.0.0"** (Pydantic models, JSON Schema
  generated by `write_schema`) (`FL/python/floorplanlab/twinlab.py:21,25-170,179-180`). Top-level keys: `schema_version,
  provenance, technology, die_um, core_um, macros[] {name,master,bbox_um,orient,status,group,words,bits,signal_pin_edge},
  std_cell_groups[], density_grid, io_pins[], clock_source_pin, power_grid {stripes,followpin_rails,connectivity},
  area, timing {wns_ns,tns_ns,whs_ns,clock_period_ns,critical_paths}, routing, twinlab_blocks[] (SemiconductorBlock
  shape + provenanceNote), integration_status` (`twinlab.py:153-170`).
* Shipped instances: `FL/reports/runs/*/twinlab_floorplan.json` (e.g. `A_baseline`: 12 SRAM macros `RM_IHPSG13_1P_2048x64`
  ×8 and `512x64` ×4; pre-route timing WNS 10.049 ns at 20 ns). A standalone viewer is `FL/viewer/twinlab_viewer.html`.

### E.6 MemoryFlow
* **What it is**: a memory-subsystem modelling, simulation and optimisation toolkit (`MF2/README.md:1-20`).
  It has its own synthesizable RTL (banked SPM, DMA, router, tensor array, ECC, MBIST), Verilator testbenches, Python models
  (roofline, banking, DMA, cache, dataflow, energy, area, DSE) and reports.
* **v1** (`MF1/`) was built without the SilicaFlux sources and assumed 40 nm / 500 MHz (`MF2/README.md:8-11`). **v2** (`MF2/`)
  reads the real RTL, characterises it and uses a 65 nm / 200 MHz target (`MF2/README.md:8-18`).
* Directly relevant to a bandwidth simulator:
  * REC-SIM characterisation of the existing RTL (`MF2/reports/data/sf_char_results.json`; numbers in B.1 and B.5).
  * Calibration tables comparing RTL with the model: `MF2/reports/calibration_spm.csv` (`test,metric,rtl,model,error_pct,analytic`),
    `calibration_dma.csv` (`metric,burst,path,rtl,sim,analytic,...`) and `calibration_tensor.csv`.
  * A bridge `rtl/bridge sf_mc25_vport_bridge` into the 2.5 controller's vector port (`MF2/README.md:85`). REC-SIM DMA ext→SPM
    11.43 B/cycle (`sf_char_results.json:125`).
  * `MF2/README.md:54` says "Absent everywhere: a DRAM controller and PHY". The SilicaFlux tops indeed have none, but
    `MCR/rtl/memory_controller.sv` is a generic DRAM-style FSM with no PHY.

---

## F. Traces, performance counters, Verilator/cocotb

### F.1 Existing transaction traces
| Artifact | Format | Design | Citation |
|---|---|---|---|
| DataFabric bus traces | CSV `cycle,event,master,id,addr,op,size,bank,slave,error,stall_cycles`; events ISSUE/ACCEPT/CONFLICT/RESPONSE; up to 82k rows | SilicaFlux-V + DataFabric (SFB2, same bus family as MCU-I) | `DF/reports/datafabric/traces/*.csv` (e.g. `tb_dma__simple_d32__contention.csv:1-3`); writer `DF/tb/common/sfb_trace_monitor.sv`; converter `DF/python/datafabric/trace_export.py:1-29` |
| MemoryLab canonical trace | `cycle|time_ns,event,master,id,addr,op,size,bank` (+ VCD handshake decode with explicit signal map) | importer | `ML/python/memorylab/trace_import.py:1-40`; RTL harness `ML/rtl_harness/tb_memorylab_bank_trace.sv:1-21` |
| soc_integration VCD | VCD, CPU-BFM bus signals | soc_integration | `SOC/sim/dump.vcd` |
| PowerLink VCD/SAIF | power sequencer only (not memory traffic) | PowerLink RTL | `PL/results/rtl/tb_sf_pwr_seq.vcd`, `tb_sf_rst_clk_ctrl.vcd`, `*.saif` |
| TestCore MBIST traces | text `T ...` MBIST op traces (gz) | TestCore | `X/SilicaFlux2.0_SilicaFlux2.5_silicaflux-testcore-p07/silicaflux-testcore/reports/testcore/mbist/*/traced/trace.txt.gz` |
| v1 / 2.5 SilicaFlux cluster traces | **NOT FOUND** (v1 TBs call `$dumpfile`, but no dumps are shipped; the 2.5 `trc_*` ports exist only in mismatched TBs) | — | `V1/tb/*.sv`; `S25/tb_memory_controller.sf:32-33` |
| MCU-I traces | **NOT FOUND** (UART logs only; CPU retirement-trace ports left open) | — | `MCU/reports/sim/logs/`; `mcu_soc.sv:179` |

### F.2 Hardware performance counters / events
* MCU-I: `mcycle`/`minstret` (`MCU/rtl/cpu/mcu_cpu.sv:357,382-385`). Crossbar events exist but are unconnected (`sfb_crossbar.sv:81-85`; `mcu_soc.sv:162`).
* 2.5 (not elaborable): `compute_tile.sf:226-230`; `noc_interconnect.sf:137-140,837-842`; `memory_controller.sf:163` (`bank_conflict_o`).
  `S25/silicaflux_top.sf` declares `PMU_NUM_COUNTERS`=16 and instantiates `sf_pmu` (`S25/silicaflux_top.sf:16,64,1765`).
  The RTL-zip top instantiates `sf_perf_monitor`
  (`X/SilicaFlux2.0_SilicaFlux2.5_silicaflux_rtl/silicaflux/rtl/silicaflux_top.sf:1437`). **Both modules are NOT FOUND.**
* Cache repo: `perf_hits/misses/writebacks` (`MCR/rtl/set_assoc_cache.sv:57-60`).
* v1 cluster: **NOT FOUND** (auditor grep of `V1/rtl` for perf/counter).

### F.3 Verilator / cocotb setups
| Repo | Verilator | cocotb | Icarus | Citation |
|---|---|---|---|---|
| v1 cluster | no | no | yes | `V1/sim/run_sim.sh:5` |
| 2.5 `.sf` | no | no | yes | `S25/run_sim.sh:5,152` |
| MCU-I | yes (SoC TB, lint, coverage) | yes (12 suites) | yes (cocotb sim) | `MCU/scripts/build_sim.sh`; `MCU/tb/soc/sim_main_cov.cpp`; `MCU/tb/unit/run_unit.py`; `MCU/reports/SUMMARY.md:9-12,37` |
| MemoryFlow v2 | yes | no | — | `MF2/README.md:17,26` |
| DataFabric | yes | yes | yes | auditor grep (12 / 5 / 1 files) |
| MemoryLab | yes | no | yes | auditor grep |
| memory_cache_repo | yes (default `TOOL`) | no | — | `MCR/sim/Makefile:21,92` |
| soc_integration | no | no | yes (`sim.vvp`) | `SOC/sim/` |

---

## Summary table: memory-system-relevant modules

Abbreviations: `1×` = one transaction outstanding; RL = SRAM read latency; E2E = request-to-response at the port.

| Module | Path | Clock domain | Bus width | Req/rsp protocol | Max outstanding | SRAM read latency | Memory port topology | Arbitration | Ordering rules | Verification status |
|---|---|---|---|---|---|---|---|---|---|---|
| v1 memory_controller | `V1/rtl/memory_controller.sv` | `clk` (single) | 32 b scalar, 128 b vector (assembled) | valid/ready + `resp_valid` pulse, opcode-typed | 1 (blocking FSM) | array 1 cyc; E2E scalar 3 cyc/word (REC-SIM) | 1 req port + unarbitrated `wb_*` write port; 256×32 b | none (single requester) | strictly serial | v1 TB (3 tests), no logs; MemoryFlow REC-SIM: DF-burst >4 words DEFECT |
| v1 compute_tile | `V1/rtl/compute_tile.sv` | `clk` | token fields + 128 b operands | token valid/ready; `tile_done` pulse | 1 token per tile | via the MC above | MC private to tile; vector/tensor have no SRAM path | n/a | in-order per tile | v1 TB, no logs |
| v1 NoC | `V1/rtl/noc_router.sv`, `noc_interconnect.sv` | `clk` | 43 b flit (32 b data) | valid/ready per link | 1 flit/input + 1/output reg per port | n/a | 2×2 mesh, XY | fixed L>N>S>E>W | single path; auditor flags possible dup/drop | v1 TB, no logs; not simulated by auditor |
| v1 scheduler | `V1/rtl/scheduler.sv` | `clk` | token broadcast | one-hot valid / ready | 1 per tile (4 total) | n/a | broadcast to 4 tiles | target-tile select (no contention) | DFSYNC barrier waits for all tiles | v1 TB, no logs |
| v1 tensor_unit | `V1/rtl/tensor_unit.sv` | `clk` | 4×128 b in, 4×128 b out | start/done | 1 | n/a | operands from tile vregs | n/a | n/a | REC-SIM PASS, 67 cycles |
| v1 vector_engine | `V1/rtl/vector_engine.sv` | `clk` | LANES×32 b (4) | issue_valid → result_valid (+1) | pipelined 1/cycle | n/a | none | n/a | in order | v1 TB, no logs |
| v1 tile_interface | `V1/rtl/tile_interface.sv` | `clk` (2-FF RX sync) | `LINK_WIDTH`=8 b phy; 43 b flit = 6 beats | valid + level credit | 1 flit TX, 1 RX | n/a | point-to-point | n/a | in order | no TB found for it in `V1/tb` |
| 2.5 memory_controller | `S25/memory_controller.sf` (= `SFM/`) | `clk_i` | scalar 32 b, vector 128 b + 4-lane mask, burst 128 b beats | valid/ready req; valid/ready rsp FIFOs; tags; exceptions | credits: S 4, V 4, burst-read 8; 2-entry ingress skid; 1 burst descriptor | `SRAM_LATENCY`=1; E2E 3 cyc (REC-SIM) | 8 single-port banks × 512 × 128 b (64 KiB), line-interleaved, scalar/vector domains | per-bank RR (or fixed S>V>B) | in order per port, none across ports; same-bank serialised | own TB mismatched (49/51 names); MemoryFlow REC-SIM PASS (150,843 checks) |
| 2.5 compute_tile | `S25/compute_tile.sf` | `clk_i` (single) | `sf_mem_req_t` (undefined) | valid/ready, txn-tagged, burst `blen+1` | `LSU_TXN`=8 (LSU) | via MC | crossbar: LSU/vector/tensor/NoC → {scalar SPM, vector SPM, NoC} | burst lock > starvation (16) > LSU>vec>ten>NoC | weakly ordered between requesters; DFSYNC.M fence | **not elaborable**; TB mismatched 44/44 |
| 2.5 NoC | `S25/noc_interconnect.sf` | `clk_i` | `$bits(noc_packet_t)` (undefined; TB flit 100 b) | valid/ready, registered ready (on/off) | `BUF_DEPTH`=4 per input port | n/a | 2×2 mesh, XY, wormhole | per-output RR (QoS off) | in order per src/dst | **not elaborable**; TB mismatched; DOC 2 cyc/hop vs TB 1 cyc/hop |
| 2.5 scheduler | `S25/scheduler.sf` | `clk_i` | uop packets | registered-ready issue; completion network | IQ 32; ITT 8 per port × 8 ports | n/a | 8 issue ports | oldest-first age matrix (+prio) | DFSYNC epochs | pkg contract unsatisfied; TB mismatched |
| 2.5 tensor_unit | `SFM/tensor_unit.sf` | `clk_i` | A,B 4×4×8 b in; C 4×4×32 b out | valid/ready issue + result | ~21 in flight (pipelined) | n/a | **no memory port** | n/a | in order | TB mismatched; MemoryFlow REC-SIM PASS, 21 cycles |
| 2.5 vector_engine | `S25/vector_engine.sf` | `clk_i` | 4×32 b | iss/res valid + stall | 1–2 stages | n/a | **no memory port** | n/a | in order | TB mismatched |
| 2.5 tile_interface | `S25/tile_interface.sf` | `tile_clk_i` / `noc_clk_i` (CDC) | `SF_FLIT_DATA_W` (undefined) | valid/ready + credits; HEAD/BODY/TAIL | TX/RX FIFO 16 flits | n/a | point-to-point | n/a | in order per VC | pkg undefined; no TB |
| 2.5 silicaflux_top (L2/LLC/coherent fabric) | `S25/silicaflux_top.sf` | core/mem/host/rtc/tck | AXI (types undefined) | AXI + coherent | `MAX_OUTSTANDING`=64, `MEM_MAX_TXN`=128 (params) | n/a | L2 2 MiB 16-way, 8 LLC banks × 4 MiB (params) | n/a | n/a | **submodules NOT FOUND**; TB mismatched 59/59 |
| MCU-I mcu_cpu | `MCU/rtl/cpu/mcu_cpu.sv` | `clk` (ICG-gated) | 32 b I + 32 b D | OBI-style req/gnt + rvalid | I 1, D 1 (blocking) | via bank: LD/ST CPI 2 | 2 master ports | n/a | in order, precise | riscv-tests 55/63/63 PASS (REC-SIM); formal equivalence script |
| MCU-I sfb_crossbar | `MCU/third_party/silicaflux-datafabric/rtl/interconnect/sfb_crossbar.sv` | `clk` | 32 b addr/data + strobes | SFB2 valid/ready req + valid/ready rsp, error | 1 per master, 1 per slave | 0 added (combinational) | 3–4 masters × 6 slaves, partial (I-port XN) | per-slave RR, grant lock | in order (no IDs needed) | formal xbar + arbiter PROVED (REC-SIM) |
| MCU-I SRAM bank | `MCU/rtl/mem/mcu_sram_bank.sv` → `sram_sp.sv` | `clk` | 32 b (36 b with parity) | SFB2 slave; WRITE_ACK=1 | `RSP_FIFO_DEPTH`=2 (crossbar limits to 1) | **1 cycle** | 4 contiguous 1RW banks (16 or 32 KiB); MBIST port | crossbar RR; MBIST takes over (`req_ready`=0) | in order | cocotb `sram_bank` PASS; SoC regression PASS (REC-SIM) |
| MCU-I boot ROM | `sfv_bootrom` in `mcu_soc.sv:227` | `clk` | 32 b | SFB v1 via adapter | 1 | 1 cycle (DOC) | single slave | crossbar RR | in order | SoC regression |
| MCU-I periph path | `mcu_soc.sv:287-330` | `clk` (+ peripheral ICGs) | 32 b | SFB2 → reg slice → v1 adapter → register bus | 1 | +1 (slice) +2 (bridge) cycles | 32 pages × 4 KiB | crossbar RR | in order | SoC regression; formal per block |
| MCU-I DMA | `MCU/rtl/dma/mcu_dma.sv` | `clk` (gated) | 32 b | SFB2 master | 1 in flight | 4 cyc/element (DOC; REC-SIM 1,104 cyc per KiB) | 1 master port | crossbar RR | element order | cocotb `dma` PASS; formal bounded |
| set_assoc_cache | `MCR/rtl/set_assoc_cache.sv` | `clk` | 32 b CPU, 32 b mem | `cpu_req`/`cpu_ack`+`cpu_stall`; `mem_req`/`mem_ack` | 1 (blocking, no MSHR) | n/a (register arrays); hit ack ~2 edges | 1 CPU, 1 mem port | n/a | blocking | Verilator TB present; no logs; **not used by any SilicaFlux top** |
| direct_mapped_cache | `MCR/rtl/direct_mapped_cache.sv` | `clk` | 32 b | same as above | 1 | DOC 1-cycle hit | 1/1 | n/a | blocking | TB present; not used |
| DRAM-style controller | `MCR/rtl/memory_controller.sv` | `clk` | 32 b | valid/ready + `resp_valid` | 1 | tRCD 3 + tCL 3 + 8-beat burst (params) | single DRAM channel FSM | reads over writes (`PRIORITY_READS`) | in order | TB present; not used |
| soc_integration fabric + SRAM | `SOC/rtl/bus/soc_fabric.sv`, `SOC/rtl/memory/soc_sram.sv` | `clk` | 32 b | SSB valid/ready req + valid/ready rsp | 1 (`active_q`, `soc_fabric.sv:8`) | 1 cycle | 1 master × 6 slaves; 128 KB SRAM | none (1 master) | in order | Icarus run; `dump.vcd` shipped |

*End of audit.*
