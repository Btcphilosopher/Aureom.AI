# Integration

## Placement in the repository

Unzip into `SilicaFlux-main/silicaflux-bandwidthlab/` next to the other SilicaFlux projects, then:

```bash
cd SilicaFlux-main/silicaflux-bandwidthlab
git checkout -b feature/silicaflux-bandwidthlab
python3.12 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
make bandwidthlab-test
```

No branch, commit or push was made by this project (user instruction: *produce as a zip, do not commit to github*).

## MemoryLab reuse

`python/memorylab/` is an **unmodified copy** of the MemoryLab package from `SilicaFlux-main/silicaflux-memorylab.zip`
(both copies in the repository are byte-identical, sha256
`36575f266fff0415b2be510967cca0eb69c6f184eac7299e8c14e5407f1e0296`). BandwidthLab imports from it:

| From MemoryLab | Used for |
|---|---|
| `event_engine.EventEngine`, `ClockDomain`, priorities, errors | base class of `bandwidthlab.scheduler.Scheduler` |
| `event_engine.Transaction` | base class of `bandwidthlab.transaction.MemTransaction` |
| `units` | operation units, `parse_size`, unit-checked throughput |
| `provenance` | provenance classes, `experiment_record` |
| `sram.BankController`, `bankbench` | RTL-validated reference for the new SRAM model (equivalence tests) |
| `rtl_integration.run_tile_latency` + `rtl_harness/tb_memorylab_tile_latency.sv` | `sfv_tile` RTL runs for engine calibration |

When integrated into the repository, the vendored copy can be replaced by the repository's MemoryLab.

## RTL sources

`bandwidthlab calibrate` needs the repository archives `SilicaFlux-main/silicaflux-datafabric.zip` and
`SilicaFlux-main/silicaflux-v-release1.zip`. They are found by walking up from the working directory or through
`SILICAFLUX_REPO=<path to the Aureom.AI checkout>`; they are extracted (path-checked) into `build/bandwidthlab/`.
Verilator ≥ 5.0 and/or Icarus 12 must be on `PATH`; without them the RTL steps are skipped and reported as such.

## Other SilicaFlux projects

| Project | Interface |
|---|---|
| TwinLab | no importer exists in TwinLab; `bandwidthlab export-twinlab` writes `twinlab/bandwidthlab_twinlab_export.json` + JSON Schema; `twinlab.load_export` / `to_twinlab_architecture` is the example importer (tested) |
| FloorplanLab | optional: `twinlab.export_twinlab(..., floorplan=twinlab_floorplan.json)` attaches macro boxes by exact name only |
| TimingFlow | `coupling.read_timingflow_fmax(timing_scenes.csv)` (DERIVED Fmax, not signoff) |
| PowerLink | `coupling.powerlink_activity(run)` writes simulated SRAM reads/writes per cycle in PowerLink's workload-profile format; PowerLink `summary.json` importer |
| Ramulator 2 | `ramulator.write_loadstore_trace` (format verified against upstream source; Ramulator not built or run here) |
| gem5 | no integration (gem5 not available; no API verified) |
| cocotb | not used: the RTL harness is plain SystemVerilog driven by a stimulus file, run under Verilator and Icarus |
