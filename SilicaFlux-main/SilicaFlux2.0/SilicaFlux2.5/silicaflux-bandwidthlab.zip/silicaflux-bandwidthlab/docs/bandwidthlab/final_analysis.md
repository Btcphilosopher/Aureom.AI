# Final analysis — answers to the engineering questions

Generated from `reports/bandwidthlab/example_run/answers.json` (the same text as REPORT.md). All SilicaFlux-V numbers are EVENT_SIMULATED predictions for the PROVISIONAL configuration unless labelled otherwise; they are not physical SilicaFlux results. Where evidence is insufficient the answer says what is missing.

## What is the simulated maximum sustainable SRAM bandwidth?

One SRAM bank behind one SFB2 slave port sustains 1.000 requests/cycle = 4.00 B/cycle (0.200 GB/s at the assumed 50 MHz). With 8 low-interleaved banks the same three masters reach 3.00 requests/cycle (limited by 3 masters x 1 outstanding, not by the banks). EVENT_SIMULATED; the analytical ceiling is 1 word/cycle/port (4 B/cycle, 0.2 GB/s at 50 MHz).

## What are the actual model assumptions behind that result?

SFB2 crossbar semantics validated cycle-exact against the RTL (1 outstanding per master and per slave port, 0-cycle crossbar, same-cycle re-issue); 1-cycle synchronous single-port SRAM (sramlib/sfv timing); 3 masters, Bernoulli open-loop arrivals, 4-byte accesses, 30 % writes, uniform in 4 KiB, 8-deep source queues; 50 MHz is an ASSUMPTION (SDC target), so GB/s scale with the real clock.

## Which SRAM banks experience the most contention?

In the reference tile pipeline (run_001): tspm.b3 (1000 conflict word-cycles, 13.4% busy), tspm.b1 (329 conflict word-cycles, 13.4% busy), tspm.b0 (257 conflict word-cycles, 13.4% busy). The TSPM banks carry the operand traffic of the tensor/vector engines and DMA staging; the fabric-split main SRAM banks see no internal conflicts (one port each) - their contention appears as crossbar arbitration instead (see the contention heatmap).

## How much latency is caused by arbitration?

run_001: arbitration accounts for 0.0% of all transaction latency (mean 0.00 cycles per transaction) - in this workload no two fabric masters target the same slave port at once; the engine/fabric conflicts on the TSPM appear as target wait instead. Under same-bank DMA contention (experiment J, round robin) the CPU's mean latency rises by 0.67 cycles (2.00 -> 2.67); arbitration accounts for 0.33 cycles of that (50% of the increase), the rest is master-side waiting behind the delayed previous request.

## How much latency is caused by memory service?

78.7% of all latency in run_001 (1 cycle per access: the SRAM read latency); target-side waiting (bank conflicts, engine priority on the TSPM) adds 4.7%; master-side generation delay (1-outstanding limit) 16.7%.

## Does DMA improve overall workload completion time?

Yes. Without a DMA (SilicaFlux-V release 1: the CPU copies tiles with load/store loops, modelled optimistically at CPI 1 for loop overhead) the pipeline takes 56995 cycles; the simple DMA (DataFabric SoC default) 40064 (1.42x), the buffered engine 26139 (2.18x), the dual-port engine 15560 (3.66x). The DMA also frees the CPU for control work (EVENT_SIMULATED; the CPU core model is validated against documented CPI only).

## Does increasing bus width improve throughput?

Yes up to the TSPM row width, provided the DMA beat widens with it: 32->64 bit +80.9%; 64->128 bit +40.9%; 128->256 bit +2.4%. A wider fabric with a 32-bit DMA gives 0 % (verified). Beyond 128 bits the 4 x 32-bit TSPM row limits staging writes (diminishing returns).

## Does increasing SRAM bank count improve throughput?

For the DMA-staged tile pipeline: 1->2 +1.8%; 2->4 +0.0%; 4->8 +0.0%; 8->16 +0.0%. More banks mainly cut the tail latency of concurrent masters (experiment A: CPU P99 4 -> 2 cycles with an unchanged DMA copy time). Multi-stream workloads gain when streams stop sharing a bank (experiment B: 4->8 contiguous banks 4001->2001 cycles; interleaving the 4 existing banks gives 2004 cycles without new banks).

## What causes P99 latency spikes?

Three mechanisms observed: (1) fixed engine priority on the TSPM - a CPU access to a bank the tensor engine streams from waits for the whole engine command (CPU max latency 257 cycles vs P99 2.02, experiment F); (2) same-bank DMA bursts (experiment E: CPU P99 2->4 cycles with the buffered DMA); (3) source queueing at overload (experiment H: P99 grows to the queue depth with backpressure and without bound with unbounded admission).

## When does the system saturate?

For 3 masters on one bank: queueing becomes significant at 0.2 requests/cycle/master (offered 0.60/cycle total), the completed throughput reaches 95 % of its peak at 0.35 and plateaus from 0.35 (definitions in the saturation report).

## Is the tensor engine underutilised because of memory traffic?

Yes. In the reference pipeline (simple DMA) the 4x4 array is computing 10.7% of the time and waiting for operands 78.1%; MAC utilisation over the run is 10.2%. With operands resident (experiment G) the same array reaches 46.4% while active (RTL ceiling 50 %: 8 of 16 MAC/cycle, sequential A/B fetch). The DMA staging over the 32-bit fabric is the bottleneck.

## Do additional compute lanes provide useful performance?

Tensor array: 2->4 +133.4%; 4->8 +87.3%; 8->16 +50.6% - the gain comes from larger tiles moving less operand data per MAC, not from MAC count, and MAC utilisation falls as the array grows. Vector lanes: 2->4 +7.5%; 4->8 +1.5%; 8->16 +2.0%; 16->32 +4.1% (the VE only post-processes 16-element tiles here; lanes beyond 4 are diminishing).

## What is the smallest configuration meeting the stated workload targets?

Targets (stated assumptions in configs/silicaflux_v.yaml): {'total_cycles_max': 40000.0, 'cpu_bg_lat_p99_max': 8.0}. Lowest cost-index variant meeting them: 'sram_capacity=32KiB' (26139 cycles, CPU P99 2 cycles, cost index 292) - i.e. the buffered DMA of the sweep baseline is required (the simple-DMA SoC default misses the cycle target) and SRAM capacity beyond this workload's footprint (< 32 KiB) buys nothing for it. The capacity of a real product is set by its application data, which this benchmark does not represent; the cost index uses HYPOTHETICAL weights.

## Which architecture offers the best marginal gain per hardware resource?

Using the repository's synthesis results (technology-independent NAND2-eq, DataFabric synth.md): the dual-port buffered DMA gives 2.57x the simple DMA's pipeline throughput for +4288 NAND2-eq of logic (0.367 speed-up per added kNAND2-eq) - the best synthesis-backed option. Among proxy-costed sweep steps, dma_outstanding 1->2 gives +27.2% throughput for +33% of its resource proxy (res_dma_outstanding_entries; 0.82 relative gain per relative resource). Proxies are counts/bits, not silicon area.

## Has the model actually been validated against RTL?

Partially, and only where stated: (a) the interconnect model is cycle-exact against the unmodified sfb_crossbar RTL for 7600 transactions in 8 configurations (Verilator) plus 4 configurations under Icarus; (b) the SRAM bank model is cycle-equivalent to MemoryLab's RTL-validated bank controller; (c) DMA cycle counts match recorded Verilator benchmarks on all holdout rows (1 fitted overhead); (d) TE/VE command cycles vs sfv_tile RTL run here: holdout max error tensor 1.0 cycle, vector 1.0 cycle. NOT validated: the CPU core model (documented CPI only), the full-SoC tile pipeline as a whole, the DRAM and cache models, and any silicon.

## Which design changes should be prioritised before SilicaFlux-V fabrication?

See docs/bandwidthlab/rtl_improvement_proposals.md; in order of simulated benefit per resource: (1) adopt the buffered or dual-port DMA engine (already in RTL) as the SoC default; (2) widen the DMA/fabric path into the TSPM to 64 bit; (3) give the fabric a bounded-wait share of the TSPM instead of strict engine priority (CPU tail latency); (4) XOR/skew bank hashing if strided masters share banks; (5) do not add SRAM banks/capacity or tensor MACs before (1)-(2) - they show no gain while staging limits.
