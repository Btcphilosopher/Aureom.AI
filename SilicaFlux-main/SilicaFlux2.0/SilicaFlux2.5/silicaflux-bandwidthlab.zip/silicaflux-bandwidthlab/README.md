# SilicaFlux BandwidthLab

Cycle-aware bandwidth, latency and data-movement simulator for the SilicaFlux processor family
(Project 10, Aureom.AI / SilicaFlux Semiconductor Engineering). It answers: *where does a SilicaFlux memory system
lose throughput, where does latency accumulate, and which architectural change genuinely helps?*

| Level | Engine | Result category |
|---|---|---|
| 1 | Analytical ceilings (link, SFB2 port, SRAM, DMA, tensor/vector, Roofline) | `ANALYTICAL_CEILING` |
| 2 | Deterministic cycle-aware discrete-event simulator (the principal engine) | `EVENT_SIMULATED` |
| 3 | Unmodified RTL under Verilator/Icarus, compared transaction by transaction | `RTL_OBSERVED` |

BandwidthLab **builds on MemoryLab** (Project 02): its scheduler extends MemoryLab's event engine and its transaction
type subclasses MemoryLab's `Transaction`; MemoryLab's RTL-validated SRAM bank controller is the reference for the new
SRAM model. `python/memorylab/` is an unmodified copy of that package.

## What is validated against RTL (and what is not)

* **Interconnect**: cycle-exact against the unmodified DataFabric `sfb_crossbar` RTL for every compared transaction
  (acceptance cycle, response cycle, error flag, read data) — 8 configurations under Verilator and 4 under Icarus,
  fixed priority and round robin, 1-3-cycle slaves, 0-30 % response back-pressure, decode errors.
* **SRAM bank model**: cycle-equivalent to MemoryLab's `BankController` (validated by MemoryLab against
  `sram_bank_controller.sv`) on 35 stimulus configurations.
* **DMA engines**: one start/finish overhead fitted on 2 recorded Verilator benchmark rows; all 10 holdout rows exact.
* **SilicaFlux-V tensor/vector engines**: `sfv_tile` RTL run here; holdout command cycles within 1 cycle.
* **Not validated**: CPU core (documented CPI only), full-SoC workloads end to end, DRAM, cache, every exploration
  extension. No silicon exists. See `docs/bandwidthlab/model_reference.md` §1 and §7.

## Quick start

```bash
python3.12 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
make bandwidthlab-test                     # 200+ unit, property and RTL-equivalence tests
make bandwidthlab-all                      # every stage -> reports/bandwidthlab/example_run/
PYTHONPATH=python python -m bandwidthlab simulate --config configs/silicaflux_v.yaml
PYTHONPATH=python python -m bandwidthlab sweep --config configs/bandwidth_sweep.yaml
PYTHONPATH=python python -m bandwidthlab calibrate                       # needs SILICAFLUX_REPO + verilator/iverilog
PYTHONPATH=python python -m bandwidthlab calibrate --trace traces/rtl_transactions.csv
PYTHONPATH=python python -m bandwidthlab report --run-dir reports/bandwidthlab/example_run
PYTHONPATH=python python -m bandwidthlab dashboard --run-dir reports/bandwidthlab/example_run --serve
```

Open `reports/bandwidthlab/example_run/dashboard.html` (and `trace_viewer.html`) in a browser; both load
`plotly.min.js` from the same folder. `REPORT.md` holds the answers, quality gates and tables.

Make targets: `bandwidthlab-test`, `-basic`, `-sram`, `-dma`, `-saturation`, `-sweep`, `-experiments`, `-calibrate`,
`-report`, `-dashboard`, `-all`, `-deps`. `python -m bandwidthlab --help` lists every command.

## Configurations (`configs/`)

| File | Meaning |
|---|---|
| `silicaflux_v_datafabric_rtl.yaml` | SilicaFlux-V + DataFabric SoC **as built** (every value cites its RTL/doc source) |
| `silicaflux_v.yaml` | the brief's **provisional** SilicaFlux-V (256 KiB SRAM, configurable banking, 1 DMA channel, assumed 50 MHz) |
| `silicaflux_mcu_i.yaml` | MCU-I as audited |
| `silicaflux_full.yaml` | **hypothetical** larger configuration (64-bit fabric, 1 MiB, 8×8 TE, DRAM with illustrative timing) |
| `bandwidth_sweep.yaml` | sweep definition (OFAT + interaction grids + constraints; never the full Cartesian product) |

Every parameter has a provenance class (VERIFIED_REPO, RTL_SIMULATED, EXTERNAL_MEASURED, HYPOTHETICAL);
`bandwidthlab audit-params --config <file>` prints the table.

## Layout

```
python/bandwidthlab/   units events scheduler transaction banking sram bus arbitration masters dma dram cache
                       cpu vector tensor workloads scenarios simulation latency bandwidth analytical metrics
                       saturation sweep optimisation experiments qos calibration trace_import plotting dashboard
                       traceviewer report twinlab coupling ramulator export cli
python/memorylab/      unmodified MemoryLab package (reused kernel, transaction, units, provenance, RTL harness)
rtl_harness/           tb_bandwidthlab_xbar.sv (+ MemoryLab's two harnesses)
configs/               configurations and the sweep definition
tests/bandwidthlab/    pytest + hypothesis suites (incl. live RTL comparison when tools are present)
docs/bandwidthlab/     audit, model reference, analysis, proposals, open issues, commands and results
reports/bandwidthlab/example_run/   every output of the delivered run
```
