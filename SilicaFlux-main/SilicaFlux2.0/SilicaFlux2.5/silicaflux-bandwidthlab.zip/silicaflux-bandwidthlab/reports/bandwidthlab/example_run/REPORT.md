# SilicaFlux BandwidthLab — engineering report

Run directory `example_run`. Categories: **ANALYTICAL_CEILING** (Level 1), **EVENT_SIMULATED** (Level 2), **RTL_OBSERVED** (RTL simulated in this session), **RTL_SIMULATED (recorded)** (RTL results recorded in the repository by earlier projects). **SILICON_MEASURED: none** — no silicon exists. All SilicaFlux-V experiment results are simulation predictions for the PROVISIONAL configuration, not physical results.

## Answers to the engineering questions

**What is the simulated maximum sustainable SRAM bandwidth?**

One SRAM bank behind one SFB2 slave port sustains 1.000 requests/cycle = 4.00 B/cycle (0.200 GB/s at the assumed 50 MHz). With 8 low-interleaved banks the same three masters reach 3.00 requests/cycle (limited by 3 masters x 1 outstanding, not by the banks). EVENT_SIMULATED; the analytical ceiling is 1 word/cycle/port (4 B/cycle, 0.2 GB/s at 50 MHz).

**What are the actual model assumptions behind that result?**

SFB2 crossbar semantics validated cycle-exact against the RTL (1 outstanding per master and per slave port, 0-cycle crossbar, same-cycle re-issue); 1-cycle synchronous single-port SRAM (sramlib/sfv timing); 3 masters, Bernoulli open-loop arrivals, 4-byte accesses, 30 % writes, uniform in 4 KiB, 8-deep source queues; 50 MHz is an ASSUMPTION (SDC target), so GB/s scale with the real clock.

**Which SRAM banks experience the most contention?**

In the reference tile pipeline (run_001): tspm.b3 (1000 conflict word-cycles, 13.4% busy), tspm.b1 (329 conflict word-cycles, 13.4% busy), tspm.b0 (257 conflict word-cycles, 13.4% busy). The TSPM banks carry the operand traffic of the tensor/vector engines and DMA staging; the fabric-split main SRAM banks see no internal conflicts (one port each) - their contention appears as crossbar arbitration instead (see the contention heatmap).

**How much latency is caused by arbitration?**

run_001: arbitration accounts for 0.0% of all transaction latency (mean 0.00 cycles per transaction) - in this workload no two fabric masters target the same slave port at once; the engine/fabric conflicts on the TSPM appear as target wait instead. Under same-bank DMA contention (experiment J, round robin) the CPU's mean latency rises by 0.67 cycles (2.00 -> 2.67); arbitration accounts for 0.33 cycles of that (50% of the increase), the rest is master-side waiting behind the delayed previous request.

**How much latency is caused by memory service?**

78.7% of all latency in run_001 (1 cycle per access: the SRAM read latency); target-side waiting (bank conflicts, engine priority on the TSPM) adds 4.7%; master-side generation delay (1-outstanding limit) 16.7%.

**Does DMA improve overall workload completion time?**

Yes. Without a DMA (SilicaFlux-V release 1: the CPU copies tiles with load/store loops, modelled optimistically at CPI 1 for loop overhead) the pipeline takes 56995 cycles; the simple DMA (DataFabric SoC default) 40064 (1.42x), the buffered engine 26139 (2.18x), the dual-port engine 15560 (3.66x). The DMA also frees the CPU for control work (EVENT_SIMULATED; the CPU core model is validated against documented CPI only).

**Does increasing bus width improve throughput?**

Yes up to the TSPM row width, provided the DMA beat widens with it: 32->64 bit +80.9%; 64->128 bit +40.9%; 128->256 bit +2.4%. A wider fabric with a 32-bit DMA gives 0 % (verified). Beyond 128 bits the 4 x 32-bit TSPM row limits staging writes (diminishing returns).

**Does increasing SRAM bank count improve throughput?**

For the DMA-staged tile pipeline: 1->2 +1.8%; 2->4 +0.0%; 4->8 +0.0%; 8->16 +0.0%. More banks mainly cut the tail latency of concurrent masters (experiment A: CPU P99 4 -> 2 cycles with an unchanged DMA copy time). Multi-stream workloads gain when streams stop sharing a bank (experiment B: 4->8 contiguous banks 4001->2001 cycles; interleaving the 4 existing banks gives 2004 cycles without new banks).

**What causes P99 latency spikes?**

Three mechanisms observed: (1) fixed engine priority on the TSPM - a CPU access to a bank the tensor engine streams from waits for the whole engine command (CPU max latency 257 cycles vs P99 2.02, experiment F); (2) same-bank DMA bursts (experiment E: CPU P99 2->4 cycles with the buffered DMA); (3) source queueing at overload (experiment H: P99 grows to the queue depth with backpressure and without bound with unbounded admission).

**When does the system saturate?**

For 3 masters on one bank: queueing becomes significant at 0.2 requests/cycle/master (offered 0.60/cycle total), the completed throughput reaches 95 % of its peak at 0.35 and plateaus from 0.35 (definitions in the saturation report).

**Is the tensor engine underutilised because of memory traffic?**

Yes. In the reference pipeline (simple DMA) the 4x4 array is computing 10.7% of the time and waiting for operands 78.1%; MAC utilisation over the run is 10.2%. With operands resident (experiment G) the same array reaches 46.4% while active (RTL ceiling 50 %: 8 of 16 MAC/cycle, sequential A/B fetch). The DMA staging over the 32-bit fabric is the bottleneck.

**Do additional compute lanes provide useful performance?**

Tensor array: 2->4 +133.4%; 4->8 +87.3%; 8->16 +50.6% - the gain comes from larger tiles moving less operand data per MAC, not from MAC count, and MAC utilisation falls as the array grows. Vector lanes: 2->4 +7.5%; 4->8 +1.5%; 8->16 +2.0%; 16->32 +4.1% (the VE only post-processes 16-element tiles here; lanes beyond 4 are diminishing).

**What is the smallest configuration meeting the stated workload targets?**

Targets (stated assumptions in configs/silicaflux_v.yaml): {'total_cycles_max': 40000.0, 'cpu_bg_lat_p99_max': 8.0}. Lowest cost-index variant meeting them: 'sram_capacity=32KiB' (26139 cycles, CPU P99 2 cycles, cost index 292) - i.e. the buffered DMA of the sweep baseline is required (the simple-DMA SoC default misses the cycle target) and SRAM capacity beyond this workload's footprint (< 32 KiB) buys nothing for it. The capacity of a real product is set by its application data, which this benchmark does not represent; the cost index uses HYPOTHETICAL weights.

**Which architecture offers the best marginal gain per hardware resource?**

Using the repository's synthesis results (technology-independent NAND2-eq, DataFabric synth.md): the dual-port buffered DMA gives 2.57x the simple DMA's pipeline throughput for +4288 NAND2-eq of logic (0.367 speed-up per added kNAND2-eq) - the best synthesis-backed option. Among proxy-costed sweep steps, dma_outstanding 1->2 gives +27.2% throughput for +33% of its resource proxy (res_dma_outstanding_entries; 0.82 relative gain per relative resource). Proxies are counts/bits, not silicon area.

**Has the model actually been validated against RTL?**

Partially, and only where stated: (a) the interconnect model is cycle-exact against the unmodified sfb_crossbar RTL for 7600 transactions in 8 configurations (Verilator) plus 4 configurations under Icarus; (b) the SRAM bank model is cycle-equivalent to MemoryLab's RTL-validated bank controller; (c) DMA cycle counts match recorded Verilator benchmarks on all holdout rows (1 fitted overhead); (d) TE/VE command cycles vs sfv_tile RTL run here: holdout max error tensor 1.0 cycle, vector 1.0 cycle. NOT validated: the CPU core model (documented CPI only), the full-SoC tile pipeline as a whole, the DRAM and cache models, and any silicon.

**Which design changes should be prioritised before SilicaFlux-V fabrication?**

See docs/bandwidthlab/rtl_improvement_proposals.md; in order of simulated benefit per resource: (1) adopt the buffered or dual-port DMA engine (already in RTL) as the SoC default; (2) widen the DMA/fabric path into the TSPM to 64 bit; (3) give the fabric a bounded-wait share of the TSPM instead of strict engine priority (CPU tail latency); (4) XOR/skew bank hashing if strided masters share banks; (5) do not add SRAM banks/capacity or tensor MACs before (1)-(2) - they show no gain while staging limits.

## Quality gates

| gate | status | evidence |
|---|---|---|
| GATE 1 — Configuration validation | PASS | 4 shipped configs validate; strict schema (unknown keys rejected); pytest: 191 passed, 0 failed |
| GATE 2 — Deterministic event engine | PASS | identical seeds -> identical transaction timelines (live re-run); (time, priority, sequence) ordering property-tested |
| GATE 3 — Transaction conservation | PASS | run_001: accepted 30940 = completed 30940 + outstanding 0 + cancelled 0; invariant errors 0 |
| GATE 4 — Correct queue behaviour | PASS | finite queues: bounded latency, no growth trend; unbounded admission: growth detected at [0.35, 0.4, 0.5, 0.7, 1.0] req/cycle/master |
| GATE 5 — SRAM port constraints | PASS | run_001 per-bank accesses <= busy cycles x ports; 35 stimulus configurations cycle-equivalent to the RTL-validated MemoryLab BankController; property test over 1RW/1R1W/2RW |
| GATE 6 — Arbitration correctness | PASS | 11600 transactions cycle-exact vs unmodified sfb_crossbar RTL (fixed + round robin, Verilator and Icarus) |
| GATE 7 — Backpressure correctness | PASS | 3 RTL cases with 10-30 % response back-pressure, all cycle-exact; request back-pressure via 1-outstanding ports |
| GATE 8 — DMA data movement correctness | PASS | byte-exact destination checks in tests (4 engines x 4 lengths, errors, SG); DMA cycle counts: holdout {'n': 10, 'mape': 0.0, 'max_rel_error': 0.0, 'mean_abs_error_cycles': 0.0, 'max_abs_error_cycles': 0.0, 'exact': 10} |
| GATE 9 — Bandwidth accounting | PASS | port utilisation <= 1; copy bytes counted once (DMA useful 36864 B vs physical 136048 B incl. operand/CPU traffic); GB and GiB both |
| GATE 10 — Latency accounting | PASS | 9 consecutive non-overlapping components sum exactly to the total for every completed transaction of run_001; Little's law gap 0.0 |
| GATE 11 — Compute dependency correctness | PASS | TE MACs 65536 = workload MACs; pointer-chase loads never overlap (test); compute ops start only after their operands |
| GATE 12 — Saturation behaviour | PASS | plateau, onset of queueing and instability classified for 4 curves (experiment H) |
| GATE 13 — Workload validation | PASS | CPU CPI vs documented RTL CPI; TE 2 cycles/k-step and VE 3 cycles/beat vs RTL formulas; engine cycles vs sfv_tile RTL (holdout) |
| GATE 14 — Parameter sweep reproducibility | PASS | re-executed sweep variants reproduce the stored result_hash bit-for-bit; workers=1 vs 2 identical (test) |
| GATE 15 — RTL trace integration where available | PASS | own SV harness on sfb_crossbar; sfv_tile via MemoryLab harness; 5 recorded DataFabric traces imported |
| GATE 16 — Calibration and validation separation | PASS | parameters fitted only on named calibration subsets; errors reported separately for holdout; crossbar has no fitted parameters |
| GATE 17 — Reports and visualisations correctly sourced | PASS | 14 figures rebuilt from run files only; every result labelled with its category |
| GATE 18 — All model limitations documented | PASS | docs/bandwidthlab/model_reference.md (fidelity, limitations) and open_issues.md |

## RTL calibration and validation

### Crossbar equivalence (verilator) — fitted parameters: none

| case | masters | slaves | latency | arbitration | rsp bp % | traffic | transactions | accept exact | response exact | equivalent |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 4 | 2 | 1 | rr | 0 | random | 1200 | 1200 | 1200 | True |
| 1 | 4 | 2 | 1 | fixed | 0 | random | 1200 | 1200 | 1200 | True |
| 2 | 4 | 1 | 1 | rr | 0 | hot | 800 | 800 | 800 | True |
| 3 | 4 | 1 | 1 | fixed | 0 | hot | 800 | 800 | 800 | True |
| 4 | 3 | 3 | 2 | rr | 20 | random | 900 | 900 | 900 | True |
| 5 | 2 | 2 | 3 | rr | 0 | bursty | 600 | 600 | 600 | True |
| 6 | 4 | 3 | 1 | rr | 30 | bursty | 1200 | 1200 | 1200 | True |
| 7 | 3 | 2 | 2 | fixed | 10 | random | 900 | 900 | 900 | True |

### Crossbar equivalence (iverilog) — fitted parameters: none

| case | masters | slaves | latency | arbitration | rsp bp % | traffic | transactions | accept exact | response exact | equivalent |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 4 | 2 | 1 | rr | 0 | random | 1200 | 1200 | 1200 | True |
| 1 | 4 | 2 | 1 | fixed | 0 | random | 1200 | 1200 | 1200 | True |
| 2 | 4 | 1 | 1 | rr | 0 | hot | 800 | 800 | 800 | True |
| 3 | 4 | 1 | 1 | fixed | 0 | hot | 800 | 800 | 800 | True |

### DMA engines vs recorded Verilator benchmark

Source: silicaflux-datafabric reports/datafabric/benchmark.md (MEASURED, Verilator; recorded in the repository by an earlier project, not re-run in this session). Fitted on ['buf_f8_b8', 'simple_d32']: {'dma.setup_cycles + dma.completion_cycles': 4}. Calibration error {'n': 2, 'mape': 0.0, 'max_rel_error': 0.0, 'mean_abs_error_cycles': 0.0, 'max_abs_error_cycles': 0.0, 'exact': 2}; **holdout error {'n': 10, 'mape': 0.0, 'max_rel_error': 0.0, 'mean_abs_error_cycles': 0.0, 'max_abs_error_cycles': 0.0, 'exact': 10}**.

| config | same bank | RTL cycles | model cycles | error | set |
|---|---|---|---|---|---|
| buf_f16_b16 | False | 2307 | 2307 | 0 | holdout |
| buf_f2_b2 | False | 4099 | 4099 | 0 | holdout |
| buf_f4_b4 | False | 3075 | 3075 | 0 | holdout |
| buf_f8_b1 | False | 6147 | 6147 | 0 | holdout |
| buf_f8_b4 | False | 3075 | 3075 | 0 | holdout |
| buf_f8_b8 | False | 2563 | 2563 | 0 | calibration |
| buf_f8_b8_d64 | False | 1283 | 1283 | 0 | holdout |
| buf_f8_dual | False | 1031 | 1031 | 0 | holdout |
| buf_f8_dual | True | 2053 | 2053 | 0 | holdout |
| simple_d128 | False | 1028 | 1028 | 0 | holdout |
| simple_d32 | False | 4100 | 4100 | 0 | calibration |
| simple_d64 | False | 2052 | 2052 | 0 | holdout |

### SilicaFlux-V engines vs sfv_tile RTL (Verilator, this session)

- **tensor**: fitted {'tensor.overhead_cycles': 1} on ['K=1 WB=0', 'K=16 WB=0']; holdout {'n': 12, 'mape': 0.025346346309746418, 'max_rel_error': 0.1111111111111111, 'mean_abs_error_cycles': 0.5833333333333334, 'max_abs_error_cycles': 1.0, 'exact': 5}.
  Discrepancies (7): K=1 WB=1 (+1), K=2 WB=1 (+1), K=4 WB=1 (+1), K=16 WB=1 (+1), K=64 WB=1 (+1), K=255 WB=1 (+1), K=1024 WB=1 (+1)
- **vector**: fitted {'vector.overhead_cycles': 1} on ['dot_vs LEN=100 WRES=0', 'vv LEN=100 WRES=0']; holdout {'n': 38, 'mape': 0.10467724196349257, 'max_rel_error': 0.5, 'mean_abs_error_cycles': 0.6052631578947368, 'max_abs_error_cycles': 1.0, 'exact': 15}.
  Discrepancies (24): vv LEN=0 WRES=0 (-1), vs LEN=0 WRES=0 (-1), dot_vv LEN=0 WRES=0 (-1), dot_vv LEN=0 WRES=1 (-1), dot_vs LEN=0 WRES=0 (-1), vv LEN=1 WRES=0 (+1), vs LEN=1 WRES=0 (+1), dot_vv LEN=1 WRES=1 (+1), vv LEN=4 WRES=0 (+1), vs LEN=4 WRES=0 (+1), dot_vv LEN=4 WRES=1 (+1), dot_vv LEN=5 WRES=1 (+1)

Diagnostics: tensor write-back cases are +1 cycle because the model waits for the acknowledgement of the last accumulator row, whereas the engine's TSPM writes are posted directly into the macros; vector short commands (LEN <= 16) are within 1-2 cycles because the model's prologue does not overlap the lock cycle exactly. These were NOT tuned away, to keep the holdout independent.

### Recorded RTL trace cross-check

- tb_dma__simple_d32__contention.csv: RTL 4.77 cycles/beat under contention; model ideal 4.00 (lower bound holds: True)
- tb_dma__buf_f8_b8__contention.csv: RTL 4.51 cycles/beat under contention; model ideal 2.50 (lower bound holds: True)

## SilicaFlux-V experiments A–J (EVENT_SIMULATED, PROVISIONAL configuration)

### A. One SRAM bank versus four banks

| variant | cycles | useful GB/s | mean | P95 | P99 | max bank queue | bank conflicts | TE util | CPU P99 | assessment |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 bank | 40064 | 0.124 | 1.3 | 2 | 3 | 2 | 1840 | 0.102 | 3 | reference |
| 4 banks | 40064 | 0.124 | 1.27 | 2 | 3 | 2 | 1840 | 0.102 | 2 | no measurable benefit (+0.0%); CPU P99 3->2 cycles |
| 1 bank (CPU vs DMA) | 8198 | 0.123 | 2.27 | 4 | 4 | 1 | 0 | n/a | 4 | reference |
| 4 banks (CPU vs DMA) | 8198 | 0.123 | 1.42 | 2 | 2 | 1 | 0 | n/a | 2 | no measurable benefit (+0.0%); CPU P99 4->2 cycles |

### B. Four banks versus eight banks

| variant | cycles | useful GB/s | mean | P95 | P99 | max bank queue | bank conflicts | TE util | CPU P99 | assessment |
|---|---|---|---|---|---|---|---|---|---|---|
| 4 banks contiguous | 4001 | 0.4 | 4 | 4 | 4 | 1 | 0 | n/a | n/a | reference |
| 8 banks contiguous | 2001 | 0.8 | 2 | 2 | 2 | 1 | 0 | n/a | n/a | worthwhile: +100.0% throughput |
| 4 banks interleaved | 2004 | 0.798 | 2 | 2 | 2 | 1 | 0 | n/a | n/a | worthwhile: +99.7% throughput |
| 8 banks interleaved | 2004 | 0.798 | 2 | 2 | 2 | 1 | 0 | n/a | n/a | worthwhile: +99.7% throughput |
| 4 banks (tile pipeline) | 26139 | 0.19 | 1.27 | 2 | 2 | 2 | 1903 | 0.157 | 2 | reference |
| 8 banks (tile pipeline) | 26139 | 0.19 | 1.27 | 2 | 2 | 2 | 1903 | 0.157 | 2 | no measurable benefit (+0.0%); CPU P99 2->2 cycles |

### C. 32-bit versus 64-bit interconnect

| variant | cycles | useful GB/s | mean | P95 | P99 | max bank queue | bank conflicts | TE util | CPU P99 | assessment |
|---|---|---|---|---|---|---|---|---|---|---|
| 32-bit fabric, simple DMA | 40064 | 0.124 | 1.27 | 2 | 3 | 2 | 1840 | 0.102 | 2 | reference |
| 64-bit fabric, simple DMA | 20652 | 0.24 | 1.34 | 2 | 2 | 2 | 1635 | 0.198 | 2 | worthwhile: +94.0% throughput; CPU P99 2->2 cycles |
| 32-bit fabric, buffered DMA | 26139 | 0.19 | 1.27 | 2 | 2 | 2 | 1903 | 0.157 | 2 | worthwhile: +53.3% throughput; CPU P99 2->2 cycles |
| 64-bit fabric, buffered DMA | 14450 | 0.343 | 1.38 | 2 | 2 | 2 | 2221 | 0.283 | 2 | worthwhile: +177.3% throughput; CPU P99 2->2 cycles |
| 32-bit fabric, DMA copy 16 KiB | 16390 | 0.05 | 1 | 1 | 1 | 1 | 0 | n/a | n/a | reference |
| 64-bit fabric, DMA copy 16 KiB | 8198 | 0.1 | 1 | 1 | 1 | 1 | 0 | n/a | n/a | worthwhile: +99.9% throughput |

### D. Simple DMA versus buffered DMA

| variant | cycles | useful GB/s | mean | P95 | P99 | max bank queue | bank conflicts | TE util | CPU P99 | assessment |
|---|---|---|---|---|---|---|---|---|---|---|
| no DMA: CPU copy loops (release-1 style) | 56995 | 0.245 | 1.11 | 2 | 2 | 2 | 820 | 0.0719 | 2 | reference |
| simple (L0) | 40064 | 0.124 | 1.27 | 2 | 3 | 2 | 1840 | 0.102 | 2 | worthwhile: +42.3% throughput; CPU P99 2->2 cycles |
| buffered FIFO 8 burst 8 (L1) | 26139 | 0.19 | 1.27 | 2 | 2 | 2 | 1903 | 0.157 | 2 | worthwhile: +118.0% throughput; CPU P99 2->2 cycles |
| buffered dual-port (L2) | 15560 | 0.319 | 1.35 | 2 | 2 | 2 | 4364 | 0.263 | 2 | worthwhile: +266.3% throughput; CPU P99 2->2 cycles |
| buffered + scatter-gather (L1+L4 ext) | 25947 | 0.191 | 1.27 | 2 | 2 | 2 | 1903 | 0.158 | 2 | worthwhile: +119.7% throughput; CPU P99 2->2 cycles |

### E. CPU competing with DMA

| variant | cycles | useful GB/s | mean | P95 | P99 | max bank queue | bank conflicts | TE util | CPU P99 | assessment |
|---|---|---|---|---|---|---|---|---|---|---|
| CPU alone | 3001 | 0.2 | 2 | 2 | 2 | 1 | 0 | n/a | 2 | reference: CPU P99 2->2; CPU max 2->2; DMA copy 8->8 |
| CPU + DMA, different banks | 8198 | 0.123 | 1.42 | 2 | 2 | 1 | 0 | n/a | 2 | reference: CPU P99 2->2; CPU max 2->2; DMA copy 8.2e+03->8.2e+03 |
| CPU + DMA, same bank | 8198 | 0.123 | 1.7 | 3 | 3 | 1 | 0 | n/a | 3 | reference: CPU P99 3->3; CPU max 3->3; DMA copy 8.2e+03->8.2e+03 |
| CPU + buffered DMA, same bank | 6231 | 0.162 | 1.93 | 4 | 4 | 1 | 0 | n/a | 4 | CPU P99 3->4; CPU max 3->4; DMA copy 8.2e+03->6.23e+03 |

### F. CPU competing with tensor traffic

| variant | cycles | useful GB/s | mean | P95 | P99 | max bank queue | bank conflicts | TE util | CPU P99 | assessment |
|---|---|---|---|---|---|---|---|---|---|---|
| CPU alone on TSPM | 4004 | 0.101 | 1 | 1 | 1 | 2 | 4 | 0.00025 | 1 | reference: CPU P99 1->1; CPU max 5->5; TE util 0.0833->0.0833 |
| CPU + TE GEMM on TSPM | 5696 | 0.223 | 1.62 | 2 | 2 | 2 | 1696 | 0.36 | 2.02 | CPU P99 1->2.02; CPU max 5->257; TE util 0.0833->0.481 |
| TE GEMM alone | 4257 | 0.205 | 1.51 | 2 | 2 | 1 | 0 | 0.481 | n/a | TE util 0.0833->0.481 |

### G. 4x4 tensor array versus 8x8

| variant | cycles | useful GB/s | mean | P95 | P99 | max bank queue | bank conflicts | TE util | CPU P99 | assessment |
|---|---|---|---|---|---|---|---|---|---|---|
| 4x4, operands resident | 8833 | 0.209 | 1.52 | 2 | 2 | 1 | 0 | 0.464 | n/a | reference |
| 8x8, operands resident | 2401 | 0.427 | 1.56 | 2 | 2 | 1 | 0 | 0.426 | n/a | worthwhile: +267.9% throughput |
| 4x4, DMA-staged pipeline | 26139 | 0.19 | 1.27 | 2 | 2 | 2 | 1903 | 0.157 | 2 | reference |
| 8x8, DMA-staged pipeline | 13957 | 0.219 | 1.29 | 2 | 2 | 2 | 890 | 0.0734 | 2 | worthwhile: +87.3% throughput; CPU P99 2->2 cycles |

### I. Different bank address mappings

| variant | cycles | useful GB/s | mean | P95 | P99 | max bank queue | bank conflicts | TE util | CPU P99 | assessment |
|---|---|---|---|---|---|---|---|---|---|---|
| 4 banks high | 6001 | 0.2 | 6 | 6 | 6 | 1 | 0 | n/a | n/a | reference |
| 4 banks low | 6001 | 0.2 | 6 | 6 | 6 | 1 | 0 | n/a | n/a | no measurable benefit (+0.0%) |
| 4 banks xor | 2003 | 0.599 | 2 | 2 | 2 | 1 | 0 | n/a | n/a | worthwhile: +199.6% throughput |
| 4 banks skew | 2003 | 0.599 | 2 | 2 | 2 | 1 | 0 | n/a | n/a | worthwhile: +199.6% throughput |
| 3 banks modulo | 2001 | 0.6 | 2 | 2 | 2 | 1 | 0 | n/a | n/a | worthwhile: +199.9% throughput |
| 3 banks skew | 2003 | 0.599 | 2 | 2 | 2 | 1 | 0 | n/a | n/a | worthwhile: +199.6% throughput |

### J. Different arbitration policies

| variant | cycles | useful GB/s | mean | P95 | P99 | max bank queue | bank conflicts | TE util | CPU P99 | assessment |
|---|---|---|---|---|---|---|---|---|---|---|
| round robin | 8198 | 0.123 | 1.7 | 3 | 3 | 1 | 0 | n/a | 3 | reference: CPU P99 3->3; CPU max 3->3; DMA copy 8.2e+03->8.2e+03 |
| fixed, CPU highest | 11195 | 0.0902 | 1.84 | 2 | 2 | 1 | 0 | n/a | 2 | CPU P99 3->2; CPU max 3->2; DMA copy 8.2e+03->1.12e+04 |
| fixed, DMA highest | 8198 | 0.123 | 1.7 | 3 | 3 | 1 | 0 | n/a | 3 | CPU P99 3->3; CPU max 3->3; DMA copy 8.2e+03->8.2e+03 |
| weighted RR (DMA 3 : CPU 1) | 8198 | 0.123 | 1.7 | 3 | 3 | 1 | 0 | n/a | 3 | CPU P99 3->3; CPU max 3->3; DMA copy 8.2e+03->8.2e+03 |
| age-based | 8198 | 0.123 | 1.7 | 3 | 3 | 1 | 0 | n/a | 3 | CPU P99 3->3; CPU max 3->3; DMA copy 8.2e+03->8.2e+03 |

### H. Offered load until saturation

- **1 target bank, finite queue (backpressure)** — {'zero_load_latency_cycles': 1.0397236614853196, 'peak_completed_per_cycle': 1.0, 'onset_of_queueing_rate': 0.2, 'plateau_start_rate': 0.35, 'near_saturation_rate': 0.35, 'unbounded_growth_rates': []}
- **1 target bank, unbounded source queue** — {'zero_load_latency_cycles': 1.0397236614853196, 'peak_completed_per_cycle': 1.0, 'onset_of_queueing_rate': 0.2, 'plateau_start_rate': 0.35, 'near_saturation_rate': 0.35, 'unbounded_growth_rates': [0.35, 0.4, 0.5, 0.7, 1.0]}
- **1 target bank, drop when full** — {'zero_load_latency_cycles': 1.0397236614853196, 'peak_completed_per_cycle': 1.0, 'onset_of_queueing_rate': 0.2, 'plateau_start_rate': 0.35, 'near_saturation_rate': 0.35, 'unbounded_growth_rates': []}
- **8 interleaved banks, finite queue** — {'zero_load_latency_cycles': 1.0, 'peak_completed_per_cycle': 3.0, 'onset_of_queueing_rate': None, 'plateau_start_rate': None, 'near_saturation_rate': 1.0, 'unbounded_growth_rates': []}

Assumptions per curve are stored in experiments.json (`assumptions`).

## Synthesis-backed cost of DMA and fabric options

Logic cost from the DataFabric synthesis report recorded in the repository (Yosys 0.33, `abc -g cmos2`, NAND2-eq = transistors/4, generic gates: technology independent, NOT PDK-mapped area; SRAM excluded). Throughput from experiments C/D (EVENT_SIMULATED tile pipeline).

| option | synthesised block | NAND2-eq | pipeline cycles | speed-up vs simple DMA | speed-up per added kNAND2-eq |
|---|---|---|---|---|---|
| simple DMA (L0) | dma_simple_d32 | 3638 | 40064 | 1.00x | n/a |
| buffered DMA F8/B8 (L1) | dma_buf_f8_b8 | 8243 | 26139 | 1.53x | 0.116 |
| dual-port buffered DMA (L2) | dma_buf_f8_dual | 7926 | 15560 | 2.57x | 0.367 |
| 64-bit fabric + 64-bit buffered DMA | dma_buf_f8_b8_d64+xbar_m4_s7_d64_rr - xbar_m4_s7_d32_rr | 13146 | 14450 | 2.77x | 0.186 |

## Hardware-resource assumptions

Resource columns (`res_*`) are explicit proxies: SRAM KiB and bank count, crossbar mux bits (width x masters x targets), DMA FIFO bits and outstanding entries, MAC count, lane count. The cost index uses HYPOTHETICAL weights (optimisation.DEFAULT_COST_WEIGHTS). No silicon area or energy is claimed.

## Figures

- [01_bandwidth_vs_latency](figures/01_bandwidth_vs_latency.html) · ![01_bandwidth_vs_latency](figures/01_bandwidth_vs_latency.png)
- [02_latency_distributions](figures/02_latency_distributions.html) · ![02_latency_distributions](figures/02_latency_distributions.png)
- [03_per_master_bandwidth](figures/03_per_master_bandwidth.html) · ![03_per_master_bandwidth](figures/03_per_master_bandwidth.png)
- [04_sram_bank_utilisation](figures/04_sram_bank_utilisation.html) · ![04_sram_bank_utilisation](figures/04_sram_bank_utilisation.png)
- [05_dma_timeline](figures/05_dma_timeline.html) · ![05_dma_timeline](figures/05_dma_timeline.png)
- [06_queue_occupancy](figures/06_queue_occupancy.html) · ![06_queue_occupancy](figures/06_queue_occupancy.png)
- [07_contention_heatmap](figures/07_contention_heatmap.html) · ![07_contention_heatmap](figures/07_contention_heatmap.png)
- [08_bus_saturation](figures/08_bus_saturation.html) · ![08_bus_saturation](figures/08_bus_saturation.png)
- [09_accelerator_utilisation](figures/09_accelerator_utilisation.html) · ![09_accelerator_utilisation](figures/09_accelerator_utilisation.png)
- [10_stall_breakdown](figures/10_stall_breakdown.html) · ![10_stall_breakdown](figures/10_stall_breakdown.png)
- [11_before_after](figures/11_before_after.html) · ![11_before_after](figures/11_before_after.png)
- [12_pareto_frontier](figures/12_pareto_frontier.html) · ![12_pareto_frontier](figures/12_pareto_frontier.png)
- [13_rtl_vs_simulator](figures/13_rtl_vs_simulator.html) · ![13_rtl_vs_simulator](figures/13_rtl_vs_simulator.png)
- [14_provenance](figures/14_provenance.html) · ![14_provenance](figures/14_provenance.png)
