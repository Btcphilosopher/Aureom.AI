"""Regenerate docs/bandwidthlab/{final_analysis,quality_gates,commands_and_results}.md from a run directory."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
run = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "reports/bandwidthlab/example_run"
docs = ROOT / "docs/bandwidthlab"
ans = json.loads((run / "answers.json").read_text())
gates = json.loads((run / "quality_gates.json").read_text())
tests = json.loads((run / "test_summary.json").read_text())
cal = json.loads((run / "calibration/calibration.json").read_text())

L = ["# Final analysis — answers to the engineering questions", "",
     "Generated from `reports/bandwidthlab/example_run/answers.json` (the same text as REPORT.md). All SilicaFlux-V "
     "numbers are EVENT_SIMULATED predictions for the PROVISIONAL configuration unless labelled otherwise; they are not "
     "physical SilicaFlux results. Where evidence is insufficient the answer says what is missing.", ""]
for a in ans:
    L += [f"## {a['question']}", "", a["answer"], ""]
(docs / "final_analysis.md").write_text("\n".join(L))

L = ["# Engineering quality gates", "", f"Test suite: {tests['passed']} passed, {tests['failed']} failed, "
     f"{tests['skipped']} skipped ({tests.get('time_s', 0):.1f} s; `logs/pytest.log`, `logs/pytest_junit.xml`).", "",
     "Gate status is evaluated by `bandwidthlab.report.evaluate_gates` from the run's evidence files (with live re-runs "
     "for determinism and sweep reproducibility). PASS on synthetic tests does **not** mean RTL cycle accuracy: only the "
     "components listed in model_reference.md §1 have RTL evidence.", "", "| gate | status | evidence |", "|---|---|---|"]
L += [f"| {g['gate']} | {g['status']} | {g['evidence']} |" for g in gates]
(docs / "quality_gates.md").write_text("\n".join(L) + "\n")

xv, xi = cal.get("xbar_verilator", {}), cal.get("xbar_iverilog", {})
eng = cal.get("engines", {}).get("engines", {})
L = ["# Commands executed and actual results", "",
     "Environment: Linux x86_64, Python 3.12.3 (venv), packages pinned in `requirements.txt`, Verilator 5.020, "
     "Icarus Verilog 12.0 (Ubuntu packages), headless Chromium for PNG export. Repository archives read from "
     "`SILICAFLUX_REPO=<Aureom.AI checkout>`.", "",
     "## Commands", "", "```bash",
     "export SILICAFLUX_REPO=<path to the Aureom.AI checkout>; export PYTHONPATH=python",
     "python -m pytest tests/bandwidthlab -rs --junitxml=logs/pytest_junit.xml      # logs/pytest.log",
     "python -m bandwidthlab test-summary --junit logs/pytest_junit.xml --run-dir reports/bandwidthlab/example_run",
     "python -m bandwidthlab all --out reports/bandwidthlab/example_run --workers 4   # logs/all.log",
     "#   = analytical (4 configs), simulate run_001, experiments A-J + H, qos, sweep (75 variants), calibrate,",
     "#     couple, export-twinlab, report (+ figures, dashboard, trace viewer)",
     "python -m bandwidthlab experiments --config configs/silicaflux_v.yaml --workers 4   # final experiments (logs/experiments_final.log)",
     "python -m bandwidthlab report --run-dir reports/bandwidthlab/example_run           # logs/report_final.log",
     "python profile (logs/profile.log): cProfile of the reference tile pipeline", "```", "",
     "## Results", "",
     f"* Tests: **{tests['passed']} passed, {tests['failed']} failed, {tests['skipped']} skipped**.",
     f"* Crossbar vs unmodified `sfb_crossbar` RTL: Verilator {xv.get('transactions_compared')} transactions in "
     f"{len(xv.get('rows', []))} configurations, all cycle-exact: {xv.get('all_equivalent')}; Icarus "
     f"{xi.get('transactions_compared')} transactions in {len(xi.get('rows', []))} configurations, all cycle-exact: "
     f"{xi.get('all_equivalent')}.",
     f"* DMA vs recorded Verilator benchmark: fitted {cal['dma']['fitted_parameters']} on {cal['dma']['fitted_on']}; "
     f"holdout {cal['dma']['holdout_error']}.",
]
for e, v in eng.items():
    L.append(f"* {e} engine vs `sfv_tile` RTL (Verilator, this session): fitted {v['fitted_parameters']} on "
             f"{v['fitted_on']}; holdout {v['holdout_error']}.")
L += ["* Saturation, experiments, sweep, QoS: see REPORT.md and the JSON/CSV files under the run directory.",
      "* Profile: reference pipeline 30,940 transactions / 40,064 cycles in 5.8 s (no event log) or 7.6 s (with) — "
      "`logs/profile.log`.", "",
      "## Run-directory contents", "", "| path | content |", "|---|---|",
      "| `REPORT.md`, `answers.json`, `quality_gates.json` | report, answers, gates |",
      "| `dashboard.html`, `trace_viewer.html`, `plotly.min.js` | interactive dashboard and transaction timeline |",
      "| `figures/*.html`, `figures/*.png` | the 14 required visualisations |",
      "| `run_001/` | reference simulation: results.json, transactions.csv, latency_decomposition.csv, events.csv |",
      "| `analytical/` | Level-1 ceilings per configuration |",
      "| `experiments/experiments.json` | experiments A-J and H |", "| `qos/qos.json` | arbitration QoS study |",
      "| `sweeps/` | 75-variant sweep, marginal gains, Pareto front, summary |",
      "| `calibration/` | RTL equivalence, DMA and engine calibration/holdout, recorded-trace metrics |",
      "| `coupling/` | TimingFlow Fmax import, combined metrics, PowerLink activity profile, synthesis table |",
      "| `twinlab/` | TwinLab export + JSON Schema |", "| `test_summary.json` | parsed JUnit summary |"]
(docs / "commands_and_results.md").write_text("\n".join(L) + "\n")
print("docs written")
