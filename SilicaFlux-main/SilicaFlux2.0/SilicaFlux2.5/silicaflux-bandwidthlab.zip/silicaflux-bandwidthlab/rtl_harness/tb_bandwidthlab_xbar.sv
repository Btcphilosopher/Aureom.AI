// =============================================================================
// SilicaFlux BandwidthLab -- transaction-trace harness for the UNMODIFIED
// DataFabric sfb_crossbar (silicaflux-datafabric rtl/interconnect/*.sv).
//
// Simulation only.  The same stimulus file is executed by the BandwidthLab
// Python model (bandwidthlab.calibration.xbar_model_run); both write the
// acceptance and response cycle of every transaction, which are compared
// transaction by transaction.
//
// Stimulus file (+stim=<path>):
//   <NM> <MAXN>
//   M <m> <n>                         then n lines:
//   <not_before_cycle> <we> <addr_hex> <wdata_hex>
// Master m presents request i in the first cycle >= not_before that is
// strictly after the acceptance of request i-1 (valid held until accepted,
// registered valid, at most one request per cycle).
// Response back-pressure: rsp_ready = bp_ready(seed, pct, m, cycle), a
// deterministic 32-bit hash identical to memorylab.bankbench.backpressure_ready.
// Slaves: behavioural SFB2 slaves, always ready, response READ_LATENCY cycles
// after acceptance (sfb_sram_slave timing, sfb_sram_slave.sv:24,59), held until
// accepted; data stored per word.
// Output (+out=<path>): "ACC <cycle> <m> <i>" and "RSP <cycle> <m> <i> <err> <rdata>"
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_bandwidthlab_xbar #(
  parameter int NM       = 4,
  parameter int NS       = 2,
  parameter int LAT      = 1,
  parameter int ARB_MODE = 1,
  parameter int MAXN     = 2048
);
  localparam int AW = 32, DW = 32, SB = 4;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // slave windows: 4 KiB each at 0x1000_0000 + s*0x1000
  function automatic logic [NS*AW-1:0] bases();
    logic [NS*AW-1:0] b;
    for (int s = 0; s < NS; s++) b[s*AW +: AW] = 32'h1000_0000 + 32'(s) * 32'h1000;
    return b;
  endfunction
  function automatic logic [NS*AW-1:0] masks();
    logic [NS*AW-1:0] k;
    for (int s = 0; s < NS; s++) k[s*AW +: AW] = 32'hFFFF_F000;
    return k;
  endfunction

  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*AW-1:0] m_req_addr;
  logic [NM*DW-1:0] m_req_wdata, m_rsp_rdata;
  logic [NM*SB-1:0] m_req_wstrb;
  logic [NS-1:0]    s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [NS*AW-1:0] s_req_addr;
  logic [NS*DW-1:0] s_req_wdata, s_rsp_rdata;
  logic [NS*SB-1:0] s_req_wstrb;
  logic err_evt, err_write;
  logic [AW-1:0] err_addr;
  logic [((NM > 1) ? $clog2(NM) : 1)-1:0] err_master;
  logic [NM-1:0] ev_a, ev_s, ev_l, ev_r;

  sfb_crossbar #(.NM(NM), .NS(NS), .AW(AW), .DW(DW), .ARB_MODE(ARB_MODE), .CHECK_ALIGN(1),
                 .SLV_BASE(bases()), .SLV_MASK(masks())) dut (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .err_evt, .err_addr, .err_master, .err_write,
    .ev_req_accept(ev_a), .ev_req_stall(ev_s), .ev_arb_loss(ev_l), .ev_rsp_stall(ev_r));

  // ---------------------------------------------------------------- stimulus
  int          n_of   [NM];
  int          nb     [NM][MAXN];
  logic        we     [NM][MAXN];
  logic [31:0] addr   [NM][MAXN];
  logic [31:0] wdata  [NM][MAXN];
  int          idx    [NM];
  int          cur    [NM];          // index of the presented request (valid)
  int          seed, pct;
  int          fo;
  longint      cyc;
  bit          acc_t [NM];
  int          nxt_t [NM];
  int          w_t   [NS];
  bit          all_t;

  function automatic bit bp_ready(int m, longint c);
    logic [31:0] h;
    if (pct <= 0) return 1'b1;
    h = 32'(c * 64'd2654435761 + longint'(m) * 64'd40503 + longint'(seed) * 64'd97 + 64'd12345);
    h = h ^ (h >> 15);
    h = 32'(64'(h) * 64'd2246822519);
    h = h ^ (h >> 13);
    return (h % 100) >= 32'(pct);
  endfunction

  initial begin
    string sp, op;
    int fi, nm_f, maxn_f, m, n, r, t_nb, t_we;
    logic [31:0] t_addr, t_wd;
    if (!$value$plusargs("stim=%s", sp)) $fatal(1, "+stim required");
    if (!$value$plusargs("out=%s", op)) $fatal(1, "+out required");
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("bp=%d", pct)) pct = 0;
    fi = $fopen(sp, "r");
    r = $fscanf(fi, "%d %d\n", nm_f, maxn_f);
    if (nm_f != NM) $fatal(1, "stimulus has %0d masters, harness NM=%0d", nm_f, NM);
    for (int k = 0; k < NM; k++) begin
      r = $fscanf(fi, "M %d %d\n", m, n);
      n_of[m] = n;
      for (int i = 0; i < n; i++) begin
        r = $fscanf(fi, "%d %d %h %h\n", t_nb, t_we, t_addr, t_wd);    // temporaries: Icarus cannot scan into
        nb[m][i] = t_nb; we[m][i] = t_we[0]; addr[m][i] = t_addr; wdata[m][i] = t_wd;  // 2-D array elements
      end
    end
    $fclose(fi);
    fo = $fopen(op, "w");
  end

  // ---------------------------------------------------------------- masters (registered valid)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      m_req_valid <= '0; m_req_write <= '0; m_req_addr <= '0; m_req_wdata <= '0; m_req_wstrb <= '0;
      cyc <= 0;
      for (int m = 0; m < NM; m++) begin idx[m] <= 0; cur[m] <= -1; end
    end else begin
      cyc <= cyc + 1;
      for (int m = 0; m < NM; m++) begin
        acc_t[m] = m_req_valid[m] && m_req_ready[m];
        nxt_t[m] = acc_t[m] ? idx[m] + 1 : idx[m];
        if (acc_t[m]) begin
          $fdisplay(fo, "ACC %0d %0d %0d", cyc, m, cur[m]);
          idx[m] <= nxt_t[m];
        end
        if (m_rsp_valid[m] && m_rsp_ready[m])
          $fdisplay(fo, "RSP %0d %0d %0d %0d %h", cyc, m, -1, m_rsp_error[m], m_rsp_rdata[m*DW +: DW]);
        if (!m_req_valid[m] || acc_t[m]) begin
          if (nxt_t[m] < n_of[m] && nb[m][nxt_t[m]] <= cyc + 1) begin
            m_req_valid[m]           <= 1'b1;
            m_req_write[m]           <= we[m][nxt_t[m]];
            m_req_addr[m*AW +: AW]   <= addr[m][nxt_t[m]];
            m_req_wdata[m*DW +: DW]  <= wdata[m][nxt_t[m]];
            m_req_wstrb[m*SB +: SB]  <= 4'hF;
            cur[m]                   <= nxt_t[m];
          end else begin
            m_req_valid[m] <= 1'b0;
          end
        end
      end
    end
  end
  always_comb for (int m = 0; m < NM; m++) m_rsp_ready[m] = bp_ready(m, cyc);

  // ---------------------------------------------------------------- slaves
  logic [31:0] smem [NS][1024];
  int          s_cnt [NS];
  logic        s_pend [NS];
  logic [31:0] s_data [NS];
  always_comb for (int s = 0; s < NS; s++) s_req_ready[s] = 1'b1;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s_rsp_valid <= '0; s_rsp_rdata <= '0; s_rsp_error <= '0;
      for (int s = 0; s < NS; s++) begin s_cnt[s] <= 0; s_pend[s] <= 1'b0; end
    end else begin
      for (int s = 0; s < NS; s++) begin
        if (s_rsp_valid[s] && s_rsp_ready[s]) s_rsp_valid[s] <= 1'b0;
        if (s_pend[s]) begin
          if (s_cnt[s] <= 1) begin
            s_rsp_valid[s] <= 1'b1;
            s_rsp_rdata[s*DW +: DW] <= s_data[s];
            s_pend[s] <= 1'b0;
          end else s_cnt[s] <= s_cnt[s] - 1;
        end
        if (s_req_valid[s] && s_req_ready[s]) begin
          w_t[s] = int'(s_req_addr[s*AW + 2 +: 10]);
          if (s_req_write[s]) begin
            smem[s][w_t[s]] <= s_req_wdata[s*DW +: DW];
            s_data[s]  <= 32'h0;
          end else s_data[s] <= smem[s][w_t[s]];
          if (LAT == 1) begin
            s_rsp_valid[s] <= 1'b1;
            s_rsp_rdata[s*DW +: DW] <= s_req_write[s] ? 32'h0 : smem[s][w_t[s]];
          end else begin
            s_pend[s] <= 1'b1;
            s_cnt[s]  <= LAT - 1;
          end
        end
      end
    end
  end

  // ---------------------------------------------------------------- run control
  initial begin
    int done_cycles;
    for (int s = 0; s < NS; s++) for (int w = 0; w < 1024; w++) smem[s][w] = 32'h0;
    repeat (3) @(posedge clk);
    rst_n = 1'b1;
    done_cycles = 0;
    while (done_cycles < 400000) begin
      @(posedge clk);
      done_cycles++;
      begin
        all_t = 1'b1;
        for (int m = 0; m < NM; m++) if (idx[m] < n_of[m] || m_req_valid[m]) all_t = 1'b0;
        if (all_t) begin
          repeat (LAT + 4) @(posedge clk);
          $fclose(fo);
          $finish;
        end
      end
    end
    $fatal(1, "timeout");
  end
endmodule
`default_nettype wire
