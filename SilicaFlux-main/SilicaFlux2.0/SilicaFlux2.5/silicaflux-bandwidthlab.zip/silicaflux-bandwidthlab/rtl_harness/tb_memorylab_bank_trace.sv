// =============================================================================
// SilicaFlux MemoryLab :: tb_memorylab_bank_trace
// Stimulus-file-driven transaction-trace harness for the SilicaFlux SRAM Wrapper
// Library's sram_bank_controller (unmodified, GENERIC backend).  The same
// stimulus file is executed by memorylab.bankbench (Python), and the two traces
// are compared transaction by transaction (memorylab.rtl_integration).
//
// Stimulus file (+stim=<path>):
//   <NM> <MAXN>
//   M <m> <n>                         then n lines per master:
//   <not_before_cycle> <we> <addr_hex> <wdata_hex> <wmask_hex> <id_hex>
// Driving rule (identical to Python): master m presents request i in the first
// cycle c >= START + not_before that is strictly after request i-1's acceptance
// cycle; valid is held until accepted.  rsp_ready = bp_ready(seed, pct, m, c).
// Log (+log=<path>), cycles relative to START:
//   A <cyc> <m> <id_hex>                         request accepted
//   C <cyc> <m>                                  m_stall_conflict (lost bank arbitration)
//   R <cyc> <m> <id_hex> <rdata_hex> <err> <we>  response handshake
// Optional +vcd=<file> dumps the top-level handshake signals (for trace_import.decode_handshake).
// Classification: SIMULATION ONLY
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_memorylab_bank_trace;
  parameter int NM     = 4;
  parameter int NB     = 4;
  parameter int DW     = 32;
  parameter int MW     = 4;
  parameter int BD     = 256;
  parameter int LAT    = 1;
  parameter int ARB    = 0;          // 0 RR, 1 FIXED (sram_defs.svh)
  parameter int ILV    = 0;          // 0 LOW, 1 HIGH
  parameter int FIFO   = LAT + 1;
  parameter int WACK   = 1;
  parameter int IDW    = 16;
  parameter int MAXN   = 8192;
  parameter int START  = 8;
  localparam int TOTAL = NB * BD;
  localparam int AWD   = $clog2(TOTAL) + 2;          // spare bits: out-of-range requests
  localparam int RAW   = (BD > 1) ? $clog2(BD) : 1;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic [NM-1:0]     req_valid = '0, req_we = '0, rsp_ready = '1;
  logic [NM*AWD-1:0] req_addr = '0;
  logic [NM*DW-1:0]  req_wdata = '0;
  logic [NM*MW-1:0]  req_wmask = '0;
  logic [NM*IDW-1:0] req_id = '0;
  logic [NM-1:0]     req_ready, rsp_valid, rsp_err, rsp_we, stall_conflict;
  logic [NM*DW-1:0]  rsp_rdata;
  logic [NM*IDW-1:0] rsp_id;
  logic              busy;
  logic [NB*DW-1:0]  tst_rdata;

  sram_bank_controller #(
    .NUM_MASTERS(NM), .NUM_BANKS(NB), .DATA_WIDTH(DW), .MASK_WIDTH(MW), .BANK_DEPTH(BD), .READ_LATENCY(LAT),
    .BACKEND(0), .MACRO(0), .ARB(ARB), .INTERLEAVE(ILV), .ADDR_MODE(0), .ID_WIDTH(IDW),
    .RSP_FIFO_DEPTH(FIFO), .WRITE_ACK(WACK), .TEST_EN(1), .ADDR_WIDTH(AWD)
  ) dut (
    .clk, .rst_n,
    .m_req_valid(req_valid), .m_req_ready(req_ready), .m_req_we(req_we), .m_req_addr(req_addr),
    .m_req_wdata(req_wdata), .m_req_wmask(req_wmask), .m_req_id(req_id),
    .m_rsp_valid(rsp_valid), .m_rsp_ready(rsp_ready), .m_rsp_rdata(rsp_rdata), .m_rsp_err(rsp_err),
    .m_rsp_we(rsp_we), .m_rsp_id(rsp_id), .m_stall_conflict(stall_conflict),
    .tst_active(1'b0), .tst_sel('0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0),
    .tst_rdata(tst_rdata), .busy(busy)
  );

  // ------------------------------------------------------------ stimulus storage
  int            s_n   [NM];
  int            s_nb  [NM][MAXN];
  bit            s_we  [NM][MAXN];
  logic [63:0]   s_addr[NM][MAXN];
  logic [DW-1:0] s_data[NM][MAXN];
  logic [MW-1:0] s_mask[NM][MAXN];
  logic [IDW-1:0] s_id [NM][MAXN];
  int            idx   [NM];
  bit            acc_q [NM];
  int            bp_pct = 0, bp_seed = 1;
  int            log_fd;
  int            cyc = 0;             // posedges since reset release
  int            total_reqs = 0, total_acc = 0, total_rsp = 0;

  // identical to memorylab.bankbench.backpressure_ready
  function automatic bit bp_ready(input int unsigned seed, input int unsigned pct, input int unsigned m,
                                  input int unsigned c);
    logic [31:0] h;
    if (pct == 0) return 1'b1;
    h = c * 32'd2654435761 + m * 32'd40503 + seed * 32'd97 + 32'd12345;
    h = h ^ (h >> 15);
    h = h * 32'd2246822519;
    h = h ^ (h >> 13);
    return (h % 100) >= pct;
  endfunction

  task automatic load_stim(input string path);
    int fd, nm, maxn, m, n, r;
    string tag;
    fd = $fopen(path, "r");
    if (fd == 0) begin $display("MEMLAB_ERROR cannot open stimulus %s", path); $finish; end
    r = $fscanf(fd, "%d %d\n", nm, maxn);
    if (nm != NM || maxn > MAXN) begin
      $display("MEMLAB_ERROR stimulus NM=%0d MAXN=%0d vs harness NM=%0d MAXN=%0d", nm, maxn, NM, MAXN); $finish;
    end
    for (int k = 0; k < NM; k++) begin
      r = $fscanf(fd, "%s %d %d\n", tag, m, n);
      s_n[m] = n;
      total_reqs += n;
      for (int i = 0; i < n; i++) begin
        int nb, we;
        logic [63:0] a, d, mk, id;
        r = $fscanf(fd, "%d %d %h %h %h %h\n", nb, we, a, d, mk, id);
        s_nb[m][i] = nb; s_we[m][i] = (we != 0); s_addr[m][i] = a;
        s_data[m][i] = d[DW-1:0]; s_mask[m][i] = mk[MW-1:0]; s_id[m][i] = id[IDW-1:0];
      end
    end
    $fclose(fd);
  endtask

  // ------------------------------------------------------------ monitor (pre-edge values)
  always @(posedge clk) begin
    if (rst_n) begin
      for (int m = 0; m < NM; m++) begin
        acc_q[m] = req_valid[m] && req_ready[m];
        if (acc_q[m]) begin
          $fdisplay(log_fd, "A %0d %0d %h", cyc - START, m, req_id[m*IDW +: IDW]);
          total_acc++;
        end
        if (stall_conflict[m]) $fdisplay(log_fd, "C %0d %0d", cyc - START, m);
        if (rsp_valid[m] && rsp_ready[m]) begin
          $fdisplay(log_fd, "R %0d %0d %h %h %0d %0d", cyc - START, m, rsp_id[m*IDW +: IDW],
                    rsp_rdata[m*DW +: DW], rsp_err[m], rsp_we[m]);
          total_rsp++;
        end
      end
      cyc = cyc + 1;
    end
  end

  // ------------------------------------------------------------ driver (between edges)
  always @(negedge clk) begin
    if (rst_n) begin
      for (int m = 0; m < NM; m++) begin
        rsp_ready[m] <= bp_ready(bp_seed, bp_pct, m, cyc - START);
        if (req_valid[m] && acc_q[m]) begin req_valid[m] = 1'b0; idx[m]++; acc_q[m] = 0; end
        if (!req_valid[m] && idx[m] < s_n[m] && cyc >= START + s_nb[m][idx[m]]) begin
          req_valid[m] = 1'b1;
          req_we[m] = s_we[m][idx[m]];
          req_addr[m*AWD +: AWD] = AWD'(s_addr[m][idx[m]]);
          req_wdata[m*DW +: DW]  = s_data[m][idx[m]];
          req_wmask[m*MW +: MW]  = s_mask[m][idx[m]];
          req_id[m*IDW +: IDW]   = s_id[m][idx[m]];
        end
      end
    end
  end

  initial begin
    string stim, logf, vcdf;
    int expect_rsp;
    if ($value$plusargs("vcd=%s", vcdf)) begin   // optional: top-level signals only (Icarus)
      $dumpfile(vcdf);
      $dumpvars(1, tb_memorylab_bank_trace);
    end
    if (!$value$plusargs("stim=%s", stim)) begin $display("MEMLAB_ERROR need +stim=<file>"); $finish; end
    if (!$value$plusargs("log=%s", logf)) logf = "bank_trace.log";
    if (!$value$plusargs("bp=%d", bp_pct)) bp_pct = 0;
    if (!$value$plusargs("bpseed=%d", bp_seed)) bp_seed = 1;
    for (int m = 0; m < NM; m++) begin idx[m] = 0; acc_q[m] = 0; s_n[m] = 0; end
    load_stim(stim);
    log_fd = $fopen(logf, "w");
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    // wait until every request is accepted and every response delivered
    fork
      begin
        int done;
        done = 0;
        while (!done) begin
          @(negedge clk);
          done = (total_acc == total_reqs) && !busy && (rsp_valid == '0);
        end
      end
      begin
        #(64'd1_000_000_000);
        $display("MEMLAB_ERROR timeout");
      end
    join_any
    repeat (LAT + 3) @(posedge clk);
    $fclose(log_fd);
    $display("MEMLAB_RESULT accepted=%0d responses=%0d requests=%0d cycles=%0d", total_acc, total_rsp, total_reqs,
             cyc - START);
    $finish;
  end
endmodule

`default_nettype wire
