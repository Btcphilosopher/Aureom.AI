// =============================================================================
// SilicaFlux MemoryLab :: tb_memorylab_tile_latency
// Drives the UNMODIFIED SilicaFlux-V compute tile (silicaflux-v-release1:
// rtl/accel/sfv_tile.sv) through its register bus, runs vector- and tensor-
// engine commands with no fabric traffic, and prints the hardware CYCLES
// counter plus the START-to-DONE wall time.  memorylab.rtl_integration parses
// the "TILE_LAT" lines and compares them with memorylab.compute models.
//   TILE_LAT TE k=<K> wb=<0|1> cycles=<CYCLES> wall=<cycles START write -> BUSY=0>
//   TILE_LAT VE op=<op> bscalar=<b> wres=<w> len=<L> cycles=<CYCLES> wall=<...>
// Classification: SIMULATION ONLY
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_memorylab_tile_latency;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  logic        ve_sel = 0, te_sel = 0, rb_we = 0;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0;
  logic [31:0] ve_rdata, te_rdata, rdata, tsp_rdata;
  logic        ve_err, te_err, irq_ve, irq_te, gnt, rvalid, err;
  logic [4*32-1:0] bist_rdata;

  sfv_tile #(.LANES(4), .MUL_W(32), .TSPM_WORDS(4096)) dut (
    .clk, .rst_n, .test_mode(1'b0), .cg_off(1'b0),
    .req(1'b0), .gnt, .addr(32'd0), .we(1'b0), .be(4'd0), .wdata(32'd0), .rvalid, .rdata(tsp_rdata), .err,
    .ve_sel, .te_sel, .rb_we, .rb_addr, .rb_wdata, .ve_rdata, .ve_err, .te_rdata, .te_err, .irq_ve, .irq_te,
    .bist_en(1'b0), .bist_ce(1'b0), .bist_we(1'b0), .bist_addr('0), .bist_wdata(32'd0), .bist_rdata
  );

  task automatic wr(input bit te, input logic [11:0] a, input logic [31:0] d);
    @(negedge clk);
    te_sel = te; ve_sel = !te; rb_we = 1; rb_addr = a; rb_wdata = d;
    @(negedge clk);
    te_sel = 0; ve_sel = 0; rb_we = 0;
  endtask

  task automatic rd(input bit te, input logic [11:0] a, output logic [31:0] d);
    @(negedge clk);
    te_sel = te; ve_sel = !te; rb_we = 0; rb_addr = a;
    #1 d = te ? te_rdata : ve_rdata;
    @(negedge clk);
    te_sel = 0; ve_sel = 0;
  endtask

  task automatic wait_idle(input bit te, output int wall);
    logic [31:0] st;
    wall = 0;
    do begin rd(te, 12'h004, st); wall += 2; end while (st[0] && wall < 100000);
  endtask

  task automatic run_te(input int k, input bit wb);
    logic [31:0] cyc, st;
    int wall;
    wr(1, 12'h000, 32'h4);                       // CLEAR accumulators
    wr(1, 12'h00C, 32'h0000);                    // A_ADDR
    wr(1, 12'h010, 32'h1000);                    // B_ADDR
    wr(1, 12'h014, 32'h2000);                    // C_ADDR
    wr(1, 12'h018, k);                           // K
    wr(1, 12'h008, {30'd0, wb, 1'b0});           // CFG: WB
    wr(1, 12'h000, 32'h1);                       // START
    wait_idle(1, wall);
    rd(1, 12'h028, cyc);
    rd(1, 12'h004, st);
    $display("TILE_LAT TE k=%0d wb=%0d cycles=%0d wall=%0d err=%0d", k, wb, cyc, wall, st[2]);
    wr(1, 12'h004, 32'h6);                       // W1C DONE/ERR
  endtask

  task automatic run_ve(input int op, input bit bsc, input bit wres, input int len);
    logic [31:0] cyc, st;
    int wall;
    wr(0, 12'h00C, 32'h0000);                    // SRC_A
    wr(0, 12'h010, 32'h1000);                    // SRC_B
    wr(0, 12'h014, 32'h2000);                    // DST
    wr(0, 12'h018, len);
    wr(0, 12'h01C, 32'd3);                       // SCALAR
    wr(0, 12'h008, {21'd0, wres, 1'b0, bsc, 4'd0, 4'(op)});
    wr(0, 12'h000, 32'h1);                       // START
    wait_idle(0, wall);
    rd(0, 12'h024, cyc);
    rd(0, 12'h004, st);
    $display("TILE_LAT VE op=%0d bscalar=%0d wres=%0d len=%0d cycles=%0d wall=%0d err=%0d", op, bsc, wres, len, cyc,
             wall, st[2]);
    wr(0, 12'h004, 32'h6);
  endtask

  int ks[7]   = '{1, 2, 4, 16, 64, 255, 1024};
  int lens[8] = '{0, 1, 4, 5, 16, 100, 1023, 2048};
  initial begin
    repeat (4) @(negedge clk);
    rst_n = 1;
    repeat (4) @(negedge clk);
    foreach (ks[i]) begin run_te(ks[i], 0); run_te(ks[i], 1); end
    foreach (lens[i]) begin
      run_ve(0, 0, 0, lens[i]);                  // ADD vector-vector
      run_ve(0, 1, 0, lens[i]);                  // ADD vector-scalar
      run_ve(11, 0, 0, lens[i]);                 // DOT vector-vector
      run_ve(11, 0, 1, lens[i]);                 // DOT vector-vector + WRES
      run_ve(11, 1, 0, lens[i]);                 // DOT vector-scalar
    end
    $display("TILE_LAT_DONE");
    $finish;
  end
endmodule
`default_nettype wire
