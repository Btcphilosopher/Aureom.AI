"""Typed, validated architecture configuration (GATE 1).

A configuration file (YAML) describes clocks, the fabric, memories, DMA, CPU, vector and
tensor engines, workload targets and -- for every parameter that has one -- its
provenance.  Validation is strict: unknown keys are rejected, sizes are parsed with units
('256KiB'), and cross-field constraints are checked (address-map overlaps, capacity vs
banking, DMA credits, tensor precision support, clock references).

Provenance classes (shared with MemoryLab, ``memorylab.provenance.Provenance``):
VERIFIED_REPO, RTL_SIMULATED, EXTERNAL_MEASURED, HYPOTHETICAL.  A parameter with no
entry in ``provenance`` is HYPOTHETICAL.
"""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from memorylab.provenance import Provenance

from .units import parse_size


class ConfigError(ValueError):
    pass


def _size(v: Any) -> int:
    return parse_size(v)


class _M(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


class FabricCfg(_M):
    name: str = "datafabric"
    clock: str = "fabric"
    topology: Literal["crossbar", "shared_bus"] = "crossbar"
    data_width_bits: int = 32
    arbitration: Literal["fixed", "rr", "wrr", "age"] = "rr"
    weights: dict[str, int] = Field(default_factory=dict)
    master_order: list[str] = Field(default_factory=list)      # arbiter index order (index 0 = highest fixed)
    max_outstanding_per_master: int = 1
    max_outstanding_per_target: int = 1
    input_queue_depth: int = 0
    req_slices: int = 0
    rsp_slices: int = 0
    ordering: Literal["in_order", "same_target_only", "out_of_order"] = "in_order"
    max_burst_beats: int = 1
    burst_setup_cycles: int = 0
    access: dict[str, list[str]] = Field(default_factory=dict)  # master -> allowed targets (empty = all)


class MemoryCfg(_M):
    name: str
    kind: Literal["sram", "dram"] = "sram"
    base: int
    capacity: int
    # SRAM
    banks: int = 1
    data_width_bits: int = 32
    read_latency: int = 1
    write_latency: int | None = None
    port_type: Literal["1RW", "1R1W", "2RW"] = "1RW"
    mapping: Literal["low", "high", "modulo", "xor", "skew"] = "low"
    queue_depth: int = 0
    arbitration: Literal["rr", "fixed"] = "rr"
    rsp_fifo_depth: int | None = None
    local_ports: list[str] = Field(default_factory=list)       # engine ports (before the fabric port)
    fabric_ports: int = 1
    on_fabric: bool = True
    fabric_split: bool = False        # every bank is its own crossbar slave (DataFabric SRAM0..3 style)
    # DRAM (simplified controller)
    dram: dict[str, Any] = Field(default_factory=dict)

    @field_validator("capacity", mode="before")
    @classmethod
    def _cap(cls, v: Any) -> int:
        return _size(v)

    @model_validator(mode="after")
    def _check(self) -> "MemoryCfg":
        if self.kind == "sram":
            wb = self.data_width_bits // 8
            if self.data_width_bits % 8 or self.data_width_bits < 8:
                raise ValueError(f"{self.name}: data_width_bits must be a multiple of 8")
            if self.capacity % (self.banks * wb):
                raise ValueError(f"{self.name}: capacity {self.capacity} B not divisible by banks x word "
                                 f"({self.banks} x {wb} B)")
            if self.mapping == "xor" and (self.banks & (self.banks - 1)):
                raise ValueError(f"{self.name}: xor mapping needs a power-of-two bank count")
        return self


class DmaCfg(_M):
    name: str = "dma"
    engine: Literal["simple", "buffered"] = "simple"
    data_width_bits: int = 32
    fifo_depth: int = 8
    burst: int = 8
    max_outstanding_reads: int = 2
    max_outstanding_writes: int = 2
    dual_port: bool = False
    channels: int = 1
    scatter_gather: bool = False
    descriptor_fetch_bytes: int = 0
    prefetch_next: bool = False
    setup_cycles: int = 2
    completion_cycles: int = 2

    @model_validator(mode="after")
    def _check(self) -> "DmaCfg":
        if self.engine == "buffered" and not 1 <= self.burst <= self.fifo_depth:
            raise ValueError("dma.burst must be within 1..fifo_depth")
        if self.engine == "buffered" and self.max_outstanding_reads > self.fifo_depth:
            raise ValueError("dma.max_outstanding_reads > fifo_depth can never be used")
        return self


class CpuCfg(_M):
    name: str = "cpu"
    code_memory: str = "rom"
    code_base: int = 0
    code_bytes: int = 4096
    fetch_ahead: int = 3
    cpi_alu: int = 1


class VectorCfg(_M):
    name: str = "ve"
    lanes: int = 4
    elem_bits: int = 32
    registers: int = 16
    overhead_cycles: int = 3
    tail_cycles: int = 0
    mul_cycles: int = 1
    port_mode: Literal["wide", "per_lane"] = "wide"
    local_memory: str = "tspm"
    max_outstanding: int = 4


class TensorCfg(_M):
    name: str = "te"
    rows: int = 4
    cols: int = 4
    precision: Literal["int4", "int8", "uint8", "int16", "fp16", "bf16"] = "int8"
    acc_bits: int = 32
    overhead_cycles: int = 3
    systolic_skew: bool = False
    operand_ports: int = 1
    k_block: int = 1
    input_buffers: int = 2
    output_buffers: int = 1
    wb_words_per_access: int = 4
    fp_supported: bool = False
    local_memory: str = "tspm"
    max_outstanding: int = 4

    @model_validator(mode="after")
    def _check(self) -> "TensorCfg":
        if self.precision in ("fp16", "bf16") and not self.fp_supported:
            raise ValueError(f"tensor precision {self.precision} requires fp_supported: true and a floating-point "
                             "compute model; the audited SilicaFlux tensor engines are integer-only")
        return self


class SimCfg(_M):
    seed: int = 1
    record_events: bool = True
    watchdog_cycles: int = 2_000_000
    max_cycles: int | None = 50_000_000
    wall_limit_s: float = 900.0


class SystemConfig(_M):
    name: str
    description: str = ""
    status: str = "PROVISIONAL"
    clocks: dict[str, float]
    fabric: FabricCfg = Field(default_factory=FabricCfg)
    memories: list[MemoryCfg]
    dma: DmaCfg | None = None
    cpu: CpuCfg | None = None
    vector: VectorCfg | None = None
    tensor: TensorCfg | None = None
    sim: SimCfg = Field(default_factory=SimCfg)
    targets: dict[str, float] = Field(default_factory=dict)
    provenance: dict[str, list[str]] = Field(default_factory=dict)   # dotted key -> [class, source]
    notes: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _check(self) -> "SystemConfig":
        for k, hz in self.clocks.items():
            if not hz > 0:
                raise ValueError(f"clock {k} must be > 0 Hz")
        if self.fabric.clock not in self.clocks:
            raise ValueError(f"fabric clock {self.fabric.clock!r} not in clocks")
        names = [m.name for m in self.memories]
        if len(set(names)) != len(names):
            raise ValueError("memory names must be unique")
        rng = sorted((m.base, m.base + m.capacity, m.name) for m in self.memories if m.on_fabric)
        for (a0, a1, n0), (b0, b1, n1) in zip(rng, rng[1:]):
            if b0 < a1:
                raise ValueError(f"address ranges of {n0} and {n1} overlap")
        for m in self.memories:
            if m.kind == "dram" and m.dram.get("clock", "dram") not in self.clocks:
                raise ValueError(f"{m.name}: DRAM controller clock not defined in clocks")
        for eng, mem in (("vector", self.vector), ("tensor", self.tensor)):
            if mem is not None and mem.local_memory not in names:
                raise ValueError(f"{eng}.local_memory {mem.local_memory!r} is not a memory")
        if self.cpu is not None and self.cpu.code_memory not in names:
            raise ValueError(f"cpu.code_memory {self.cpu.code_memory!r} is not a memory")
        for key, v in self.provenance.items():
            if not v or v[0] not in {p.value for p in Provenance}:
                raise ValueError(f"provenance[{key}] must start with one of {[p.value for p in Provenance]}")
        return self

    def memory(self, name: str) -> MemoryCfg:
        for m in self.memories:
            if m.name == name:
                return m
        raise KeyError(name)

    @property
    def fabric_hz(self) -> float:
        return self.clocks[self.fabric.clock]


# ---------------------------------------------------------------------------- loading / overrides
def _int_like(v: Any) -> Any:
    if isinstance(v, str):
        s = v.strip().replace("_", "")
        try:
            if s.lower().startswith("0x"):
                return int(s, 16)
            if s.replace(".", "", 1).replace("e", "", 1).replace("+", "").replace("-", "").isdigit() and \
                    any(c in s for c in ".e"):
                return float(s)
        except ValueError:
            return v
    return v


def _normalise(d: Any) -> Any:
    if isinstance(d, dict):
        return {k: _normalise(v) for k, v in d.items()}
    if isinstance(d, list):
        return [_normalise(v) for v in d]
    return _int_like(d)


def read_yaml(path: str | Path) -> dict:
    p = Path(path)
    data = yaml.safe_load(p.read_text())
    if not isinstance(data, dict):
        raise ConfigError(f"{p}: top level must be a mapping")
    base = data.pop("extends", None)
    if base:
        parent = read_yaml(p.parent / base)
        data = deep_merge(parent, data)
    return _normalise(data)


def deep_merge(base: Any, over: Any) -> Any:
    if isinstance(base, dict) and isinstance(over, dict):
        out = dict(base)
        for k, v in over.items():
            out[k] = deep_merge(base.get(k), v) if k in base else copy.deepcopy(v)
        return out
    if isinstance(base, list) and isinstance(over, list) and over and all(isinstance(x, dict) and "name" in x
                                                                           for x in over + base):
        by = {x["name"]: copy.deepcopy(x) for x in base}
        order = [x["name"] for x in base]
        for x in over:
            if x["name"] in by:
                by[x["name"]] = deep_merge(by[x["name"]], x)
            else:
                by[x["name"]] = copy.deepcopy(x)
                order.append(x["name"])
        return [by[n] for n in order]
    return copy.deepcopy(over)


def apply_overrides(data: dict, overrides: dict[str, Any]) -> dict:
    """Apply dotted-key overrides, e.g. {'fabric.data_width_bits': 64, 'memories.sram.banks': 8}."""
    d = copy.deepcopy(data)
    for key, val in overrides.items():
        parts = key.split(".")
        cur: Any = d
        for i, p in enumerate(parts[:-1]):
            if isinstance(cur, list):
                cur = next((x for x in cur if x.get("name") == p), None)
                if cur is None:
                    raise ConfigError(f"override {key}: no list element named {p!r}")
            else:
                if cur.get(p) is None:
                    cur[p] = {}
                cur = cur[p]
        last = parts[-1]
        if isinstance(cur, list):
            raise ConfigError(f"override {key}: cannot assign to a list")
        cur[last] = val
    return d


def load_config(path: str | Path, overrides: dict[str, Any] | None = None) -> SystemConfig:
    data = read_yaml(path)
    if overrides:
        data = apply_overrides(data, overrides)
    try:
        return SystemConfig.model_validate(data)
    except Exception as e:  # pydantic.ValidationError -> ConfigError with the file name
        raise ConfigError(f"{path}: {e}") from e


def config_from_dict(data: dict, overrides: dict[str, Any] | None = None) -> SystemConfig:
    data = _normalise(data)
    if overrides:
        data = apply_overrides(data, overrides)
    return SystemConfig.model_validate(data)


def provenance_table(cfg: SystemConfig) -> list[dict]:
    """Every scalar parameter with its provenance class and source (HYPOTHETICAL if unlisted)."""
    rows: list[dict] = []

    def walk(prefix: str, obj: Any) -> None:
        if isinstance(obj, BaseModel):
            for k in type(obj).model_fields:
                if k in ("provenance", "notes", "description"):
                    continue
                walk(f"{prefix}.{k}" if prefix else k, getattr(obj, k))
        elif isinstance(obj, list) and obj and isinstance(obj[0], BaseModel):
            for x in obj:
                walk(f"{prefix}.{getattr(x, 'name', '?')}", x)
        elif isinstance(obj, dict) and prefix.endswith("dram"):
            for k, v in obj.items():
                walk(f"{prefix}.{k}", v)
        else:
            p = cfg.provenance.get(prefix)
            rows.append({"parameter": prefix, "value": obj,
                         "provenance": p[0] if p else Provenance.HYPOTHETICAL.value,
                         "source": p[1] if p and len(p) > 1 else ""})
    walk("", cfg)
    return rows
