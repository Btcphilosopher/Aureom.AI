"""Address-to-bank mapping.

All mappings work on *word* addresses (byte address // bank word bytes) and return
``(bank, row)``.  Every mapping is a bijection between word addresses in
``[0, banks*depth)`` and ``(bank, row)`` pairs; ``tests/bandwidthlab/test_banking.py``
checks this property for power-of-two and non-power-of-two bank counts.

Mappings
--------
LOW      low-order interleave, bank = word mod B.  For power-of-two B this is the bit
         select used by sramlib ``sram_bank_controller`` (BANK_SEL_LOW=1).  For other B
         it is the same arithmetic (a modulo, which costs a divider in hardware --
         reported as ``needs_divider``).
HIGH     high-order mapping, bank = word div depth (sramlib BANK_SEL_LOW=0).
MODULO   explicit modulo mapping for any B (identical arithmetic to LOW; kept as a
         separate name so that configurations state the intent).
XOR      bank = (word mod B) XOR ((word div B) mod B); power-of-two B only
         (MemoryLab's ``memorylab.sram.bank_map`` 'xor' form).  Not present in the
         audited SilicaFlux RTL.
SKEW     bank = (word + word div B) mod B; any B.  A bijective additive skew that
         breaks power-of-two strides when B is not a power of two.
"""
from __future__ import annotations

from enum import Enum

from .units import is_pow2


class BankMapError(ValueError):
    pass


class BankMapping(str, Enum):
    LOW = "low"
    HIGH = "high"
    MODULO = "modulo"
    XOR = "xor"
    SKEW = "skew"


class BankMapper:
    def __init__(self, banks: int, depth: int, mapping: BankMapping | str = BankMapping.LOW) -> None:
        mapping = BankMapping(mapping)
        if banks < 1:
            raise BankMapError("bank count must be >= 1")
        if depth < 1:
            raise BankMapError("bank depth must be >= 1 word")
        if mapping == BankMapping.XOR and not is_pow2(banks):
            raise BankMapError("XOR bank hashing needs a power-of-two bank count; use 'skew' or 'modulo'")
        self.banks, self.depth, self.mapping = banks, depth, mapping
        self.total_words = banks * depth

    @property
    def needs_divider(self) -> bool:
        """True when the mapping needs a non-power-of-two divide/modulo in hardware."""
        if self.mapping == BankMapping.HIGH:
            return not is_pow2(self.depth)
        return not is_pow2(self.banks)

    def map(self, word: int) -> tuple[int, int]:
        if word < 0 or word >= self.total_words:
            raise BankMapError(f"word address {word} outside [0, {self.total_words})")
        b, m = self.banks, self.mapping
        if b == 1:
            return 0, word
        if m in (BankMapping.LOW, BankMapping.MODULO):
            return word % b, word // b
        if m == BankMapping.HIGH:
            return word // self.depth, word % self.depth
        if m == BankMapping.XOR:
            hi = word // b
            return (word % b) ^ (hi % b), hi
        if m == BankMapping.SKEW:
            hi = word // b
            return (word + hi) % b, hi
        raise BankMapError(f"unknown mapping {m}")

    def bank(self, word: int) -> int:
        return self.map(word)[0]

    def unmap(self, bank: int, row: int) -> int:
        """Inverse mapping (used by the bijectivity tests)."""
        b, m = self.banks, self.mapping
        if not (0 <= bank < b and 0 <= row < self.depth):
            raise BankMapError("bank/row out of range")
        if b == 1:
            return row
        if m in (BankMapping.LOW, BankMapping.MODULO):
            return row * b + bank
        if m == BankMapping.HIGH:
            return bank * self.depth + row
        if m == BankMapping.XOR:
            return row * b + (bank ^ (row % b))
        if m == BankMapping.SKEW:
            return row * b + ((bank - row) % b)
        raise BankMapError(f"unknown mapping {m}")

    def describe(self) -> str:
        return f"{self.banks} banks x {self.depth} words, {self.mapping.value} mapping" + (
            " (needs divider)" if self.needs_divider else "")
