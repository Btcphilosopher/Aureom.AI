"""Memory-traffic generators (programs for :class:`~bandwidthlab.masters.ProgramMaster`).

Every generator is deterministic for a given seed (numpy PCG64).  Patterns:

  seq_ifetch     sequential instruction fetch (4-byte words from a code region)
  seq_read       sequential data reads           seq_write   sequential data writes
  random         uniform random word accesses (read fraction configurable)
  pointer_chase  a linked list laid out in memory; every load's address is the data
                 returned by the previous load (real address dependency)
  stack          push/pop pattern around a stack pointer (LIFO, writes then reads)
  stream_read / stream_write   back-to-back independent accesses (bandwidth probes)
  mixed          read/write mix over a region with a configurable write fraction
  inject         open-loop injection at a target rate (Bernoulli or periodic arrivals),
                 used by the saturation harness
"""
from __future__ import annotations

from typing import Any, Iterator

import numpy as np

from .masters import ComputeOp, MemOp, Op
from .transaction import TxnKind

PATTERNS = ("seq_ifetch", "seq_read", "seq_write", "random", "pointer_chase", "stack", "stream_read",
            "stream_write", "mixed", "inject", "strided")


def _rng(seed: int) -> np.random.Generator:
    return np.random.Generator(np.random.PCG64(seed))


def build_linked_list(n: int, base: int, region_bytes: int, word: int, seed: int) -> list[int]:
    """Addresses of a random cyclic linked list: node i stores the address of node i+1."""
    slots = region_bytes // word
    if n > slots:
        raise ValueError("pointer chase: more nodes than words in the region")
    order = _rng(seed).permutation(slots)[:n]
    return [base + int(s) * word for s in order]


def program(pattern: str, *, n: int, base: int, region_bytes: int, word: int = 4, seed: int = 1,
            think_cycles: int = 0, write_fraction: float = 0.3, dependent: bool = False, rate: float = 1.0,
            arrivals: str = "bernoulli", link: str = "default", start_cycle: int = 0,
            tag: str | None = None, stride_words: int = 4) -> Iterator[Op]:
    """Yield ``n`` memory ops of ``pattern`` (plus optional compute between them).

    ``think_cycles``: compute cycles between consecutive accesses (CPU work).
    ``dependent``:    each access depends on the previous one's completion (blocking core).
    ``rate``/``arrivals`` (inject): mean requests per cycle; injection times are fixed in
                      advance (open loop), so a stalled fabric shows up as queueing delay.
    """
    if pattern not in PATTERNS:
        raise ValueError(f"unknown pattern {pattern!r}; one of {PATTERNS}")
    if n < 0 or region_bytes < word:
        raise ValueError("n >= 0 and region >= one word")
    rng = _rng(seed)
    words = region_bytes // word
    tag = tag or pattern
    oid = 0
    prev_mem: int | None = None
    if pattern == "pointer_chase":
        nodes = build_linked_list(n + 1, base, region_bytes, word, seed)
        first = nodes[0]
        for i in range(n):
            deps = (prev_mem,) if prev_mem is not None else ()
            addr: Any = first if i == 0 else (lambda d, p=prev_mem: int(d[p].data))
            yield MemOp(TxnKind.READ, addr, word, deps=deps, tag=tag, link=link)
            prev_mem = oid
            oid += 1
            if think_cycles:
                yield ComputeOp(think_cycles, deps=(prev_mem,), tag="think")
                oid += 1
        return
    t_inj = float(start_cycle)
    sp = 0
    for i in range(n):
        kind = TxnKind.READ
        if pattern in ("seq_ifetch", "seq_read", "stream_read"):
            a = base + (i % words) * word
        elif pattern == "strided":
            a = base + ((i * stride_words) % words) * word
        elif pattern in ("seq_write", "stream_write"):
            a, kind = base + (i % words) * word, TxnKind.WRITE
        elif pattern == "random" or pattern == "inject":
            a = base + int(rng.integers(0, words)) * word
            kind = TxnKind.WRITE if rng.random() < write_fraction else TxnKind.READ
        elif pattern == "mixed":
            a = base + (i % words) * word
            kind = TxnKind.WRITE if rng.random() < write_fraction else TxnKind.READ
        elif pattern == "stack":
            depth = 8
            phase = (i // depth) % 2           # push 8, pop 8
            if phase == 0:
                sp += 1
                a, kind = base + region_bytes - sp * word, TxnKind.WRITE
            else:
                a = base + region_bytes - sp * word
                sp -= 1
        else:  # pragma: no cover
            raise AssertionError(pattern)
        nb = 0
        if pattern == "inject":
            if arrivals == "periodic":
                nb = int(t_inj)
                t_inj += 1.0 / rate
            else:
                t_inj += rng.geometric(min(1.0, rate))
                nb = int(t_inj)
        data = int(rng.integers(0, 1 << 32)) if kind == TxnKind.WRITE else None
        deps = (prev_mem,) if (dependent and prev_mem is not None) else ()
        yield MemOp(kind, a, word, deps=deps, data=data, not_before=nb, tag=tag, link=link)
        prev_mem = oid
        oid += 1
        if think_cycles:
            yield ComputeOp(think_cycles, deps=(prev_mem,) if dependent else (), tag="think")
            oid += 1


def init_pointer_chase(mem: Any, n: int, base: int, region_bytes: int, word: int = 4, seed: int = 1) -> list[int]:
    """Write the linked list used by ``program('pointer_chase', ...)`` into a target (back door)."""
    nodes = build_linked_list(n + 1, base, region_bytes, word, seed)
    for a, nxt in zip(nodes, nodes[1:]):
        mem.write_bytes(a, int(nxt).to_bytes(word, "little"))
    return nodes
