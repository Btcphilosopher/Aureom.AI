"""Power and timing coupling (TimingFlow, PowerLink, FloorplanLab report files).

Audit: there is no standalone "PowerGrid" or "ThermalLab" tool in the repository (PowerGrid
and ThermalLab exist only as TwinLab/PowerLink/FloorplanLab sub-features).  The integration
therefore reads the report FILES those projects already produce:

* TimingFlow ``timing_scenes.csv`` -> ``reg2reg_fmax_derived_mhz`` per corner.  TimingFlow
  states this Fmax is DERIVED (1000 / (period - reg2reg WNS)), post-synthesis/post-route,
  not signoff.  BandwidthLab uses it only to convert simulated cycles into time, labelled
  DERIVED, never as a measured frequency.
* PowerLink ``summary.json`` (power_mw per profile) and its SRAM energy model inputs
  (``read_pj``/``write_pj``).  In the repository those pJ values are marked
  ``source: assumption`` ("memory compiler datasheet REQUIRED"), so energy per byte is NOT
  computed unless the caller explicitly opts in (``allow_assumed_energy``) and then it is
  labelled ASSUMPTION-BASED.
* Area: only from a supplied synthesis/floorplan number with its source.

Combined metrics are produced only when their inputs exist and refer to the same design;
otherwise the result states what is missing.  Voltage-droop-induced delay is NOT computed
(no timing methodology for it exists here).

Also provided: ``powerlink_activity`` writes the simulated SRAM reads/writes per cycle in
PowerLink's workload-profile format, so PowerLink can be driven by simulated activity.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd
import yaml


def read_timingflow_fmax(scenes_csv: Path, label: str | None = None) -> dict[str, Any]:
    df = pd.read_csv(scenes_csv).drop_duplicates()
    if "reg2reg_fmax_derived_mhz" not in df.columns:
        raise ValueError(f"{scenes_csv}: no reg2reg_fmax_derived_mhz column")
    rows = df[["corner", "label", "stage", "reg2reg_fmax_derived_mhz"]].dropna().to_dict("records")
    return {"source": label or str(scenes_csv),
            "category": "DERIVED (TimingFlow: 1000/(period - reg2reg WNS); not signoff)",
            "rows": rows, "worst_mhz": float(min(r["reg2reg_fmax_derived_mhz"] for r in rows)) if rows else None}


def read_powerlink_summary(summary_json: Path) -> dict[str, Any]:
    s = json.loads(Path(summary_json).read_text())
    return {"source": str(summary_json), "chip": s.get("chip"), "power_mw": s.get("power_mw"),
            "category": "PowerLink pre-synthesis planning model (per its own README)"}


def combined_metrics(*, useful_bytes: float, cycles: float, macs: float | None = None,
                     fmax: dict | None = None, power_mw: float | None = None, power_source: str = "",
                     area_mm2: float | None = None, area_source: str = "", sram_accesses: dict | None = None,
                     sram_pj: dict | None = None, allow_assumed_energy: bool = False) -> dict[str, Any]:
    out: dict[str, Any] = {"inputs": {}, "metrics": {}, "missing": []}
    if fmax and fmax.get("worst_mhz"):
        f = fmax["worst_mhz"] * 1e6
        t = cycles / f
        out["inputs"]["clock"] = {"mhz": fmax["worst_mhz"], "source": fmax["source"], "category": fmax["category"]}
        out["metrics"]["latency_s_at_derived_fmax"] = t
        out["metrics"]["useful_GBps_at_derived_fmax"] = useful_bytes / t / 1e9
        if macs:
            out["metrics"]["GOPS_int_at_derived_fmax"] = 2 * macs / t / 1e9
    else:
        out["missing"].append("clock frequency for this design (TimingFlow timing_scenes.csv)")
    if power_mw and fmax and fmax.get("worst_mhz"):
        f = fmax["worst_mhz"] * 1e6
        gbps = useful_bytes / (cycles / f) / 1e9
        out["metrics"]["useful_GBps_per_W"] = gbps / (power_mw / 1e3)
        out["inputs"]["power"] = {"mw": power_mw, "source": power_source}
        out["metrics"]["note_power"] = ("power and frequency come from different tools/assumptions; the ratio is only "
                                        "as good as the PowerLink planning model")
    else:
        out["missing"].append("total power of the same design and operating point")
    if area_mm2:
        out["inputs"]["area"] = {"mm2": area_mm2, "source": area_source}
        out["metrics"]["bytes_per_cycle_per_mm2"] = useful_bytes / cycles / area_mm2
        if macs:
            out["metrics"]["macs_per_cycle_per_mm2"] = macs / cycles / area_mm2
    else:
        out["missing"].append("area (synthesis or floorplan report)")
    if sram_accesses and sram_pj and allow_assumed_energy:
        e = sum(sram_accesses[k]["reads"] * sram_pj[k]["read_pj"] + sram_accesses[k]["writes"] * sram_pj[k]["write_pj"]
                for k in sram_accesses if k in sram_pj)
        out["metrics"]["sram_array_pj_per_useful_byte"] = e / useful_bytes if useful_bytes else None
        out["metrics"]["energy_category"] = "ASSUMPTION-BASED (PowerLink pJ values marked source: assumption)"
    else:
        out["missing"].append("verified SRAM access energy (memory-compiler datasheet); energy per byte not computed")
    out["not_computed"] = ["voltage-droop-induced delay (no timing methodology for it in this flow)",
                           "interconnect wire energy (no extracted parasitics imported)"]
    return out


def powerlink_activity(run_dir: Path, profile: str = "bandwidthlab_sim",
                       block_map: dict[str, str] | None = None) -> Path:
    """Write simulated SRAM activity in PowerLink's workload-profile format (reads/writes per cycle)."""
    res = json.loads((Path(run_dir) / "run_001" / "results.json").read_text())
    r = res["results"]
    cycles = res["metrics"]["total_cycles"]
    act = {}
    for name, s in r["srams"].items():
        rd = sum(b["reads"] for b in s["banks"])
        wr = sum(b["writes"] for b in s["banks"])
        key = (block_map or {}).get(name, f"sram_{name}")
        act[key] = {"reads_per_cycle": round(rd / cycles, 6), "writes_per_cycle": round(wr / cycles, 6)}
    doc = {"profiles": {profile: {"description": f"SRAM activity simulated by BandwidthLab ({res['results']['system']})",
                                  "activity": act, "source": "EVENT_SIMULATED (BandwidthLab run_001)"}},
           "note": "map the sram_* keys onto PowerLink block names (sram_imem / sram_scalar / sram_tile) with block_map"}
    out = Path(run_dir) / "coupling" / "powerlink_activity.yaml"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(yaml.safe_dump(doc, sort_keys=False))
    return out


# ---------------------------------------------------------------------------- repository report files
def _repo_zip_member(zip_rel: str, member_suffix: str, dest: Path) -> Path | None:
    import zipfile
    from .calibration import find_repo
    repo = find_repo()
    if repo is None or not (repo / zip_rel).exists():
        return None
    with zipfile.ZipFile(repo / zip_rel) as z:
        names = [n for n in z.namelist() if n.endswith(member_suffix)]
        if not names:
            return None
        if ".." in Path(names[0]).parts:
            raise ValueError("unsafe archive member")
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(z.read(names[0]))
        return dest


def datafabric_synth_table(build: Path) -> dict[str, dict]:
    """Technology-independent synthesis results recorded in silicaflux-datafabric reports/datafabric/synth.md
    (Yosys 0.33, abc -g cmos2, NAND2-eq = transistors/4; generic gates, NOT PDK-mapped area)."""
    p = _repo_zip_member("SilicaFlux-main/silicaflux-datafabric.zip", "reports/datafabric/synth.md",
                         build / "repo_reports" / "datafabric_synth.md")
    if p is None:
        return {}
    out = {}
    for line in p.read_text().splitlines():
        f = [x.strip() for x in line.strip().strip("|").split("|")]
        if len(f) >= 5 and f[3].isdigit() and f[4].isdigit():
            out[f[0]] = {"description": f[1], "nand2_eq": int(f[4]), "flops": int(f[3]) if f[3].isdigit() else None}
    return out


def couple(run_dir: Path, build: Path) -> dict[str, Any]:
    """Coupling for the run_001 workload: TimingFlow derived Fmax (DataFabric SoC), SilicaFlux-V synthesis summary."""
    res = json.loads((Path(run_dir) / "run_001" / "results.json").read_text())
    m = res["metrics"]
    cfg = json.loads((Path(run_dir) / "run_001" / "config_resolved.json").read_text())
    out: dict[str, Any] = {"run_config": cfg["name"]}
    sc = _repo_zip_member("SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-timingflow.zip",
                          "reports/silicaflux_v_df/ihp_sg13g2/baseline/timing_scenes.csv",
                          build / "repo_reports" / "timingflow_silicaflux_v_df_scenes.csv")
    fmax = read_timingflow_fmax(sc, "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-timingflow.zip:"
                                    "silicaflux-timingflow/reports/silicaflux_v_df/ihp_sg13g2/baseline/timing_scenes.csv"
                                ) if sc else None
    if fmax:
        fmax["design"] = "sfv_soc_df (DataFabric SoC as built, 128 KiB SRAM)"
    out["timingflow"] = fmax
    # area / power of the SilicaFlux-V release-1 ASIC baseline (sfv_soc, NOT sfv_soc_df, 128 KiB NOT 256 KiB)
    comparable = cfg["name"] == "silicaflux_v_datafabric_rtl"
    out["comparability"] = ("run configuration differs from every synthesised design (provisional 256 KiB SRAM / "
                            "DataFabric SoC); area and power are therefore NOT combined with the simulated throughput"
                            if not comparable else "DataFabric SoC: TimingFlow covers sfv_soc_df; the IHP area/power "
                            "summary covers sfv_soc (no DataFabric) -- area not combined")
    out["fmax_note"] = ("the derived Fmax belongs to the as-built DataFabric SoC; applying it to the "
                        f"'{cfg['name']}' run is a labelled cycles-to-time conversion only")
    out["combined"] = combined_metrics(useful_bytes=m["useful_bytes"], cycles=m["total_cycles"],
                                       macs=m.get("te_macs"), fmax=fmax)
    out["synthesis_logic_nand2eq"] = datafabric_synth_table(build)
    out["powerlink_activity"] = str(powerlink_activity(run_dir))
    p = Path(run_dir) / "coupling" / "coupling.json"
    p.write_text(json.dumps(out, indent=1, default=str))
    return out
