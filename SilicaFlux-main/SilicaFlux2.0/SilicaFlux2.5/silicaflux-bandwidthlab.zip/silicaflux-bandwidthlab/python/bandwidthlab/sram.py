"""Cycle-aware banked SRAM target.

Semantics follow the SilicaFlux SRAM Wrapper Library (silicaflux-sramlib, audited in
docs/bandwidthlab/repository_audit.md) and generalise it:

* N requester *ports* x B banks.  Each port holds one request ``valid`` until it is
  accepted (valid/ready).  With ``queue_depth == 0`` acceptance happens when every word
  of the request has won its bank (``sram_bank_controller``: accept == issue, no
  request queue).  With ``queue_depth > 0`` each port has a registered request FIFO;
  acceptance is the FIFO handshake and the FIFO head then contends for the banks.
* Per-bank arbitration: round robin with pointer <- last granted port + 1 (sramlib), or
  fixed priority (port 0 highest).
* Bank port types: ``1RW`` (one access per bank per cycle), ``1R1W`` (one read and one
  write per cycle; same-row read/write collision -> STALL with alternating priority,
  sramlib ``sram_1r1w`` COLLISION_MODE=STALL), ``2RW`` (true dual port: two accesses per
  cycle; same-row pair with at least one write -> the second is stalled, i.e. sequential
  semantics, sramlib ``sram_tdp``).  Two conflicting operations are never performed on a
  single-port bank in the same cycle (checked by an internal assertion and by tests).
* Writes take effect at the grant edge (reads granted later see them).  Read data and
  write acknowledgements return ``read_latency`` / ``write_latency`` cycles after
  acceptance, in order per port.  Per-port response credits (``rsp_fifo_depth``,
  default read_latency + 1 as in sramlib) bound the responses in flight; a port whose
  response consumer stalls therefore back-pressures its own requests.
* Out-of-range and (with ``misaligned='error'``) misaligned requests are accepted
  without a bank access and answered with an error response (sramlib behaviour).
* Multi-word requests (an access wider than one bank word, or an explicit word list for
  gather/scatter) are decomposed into word accesses; words may win their banks in
  different cycles; the request is accepted when its last word is granted.

The model is validated cycle-for-cycle against MemoryLab's ``BankController`` (itself
validated against the sramlib RTL under Verilator/Icarus) for 1RW, queue_depth 0,
power-of-two banks, low/high interleave (tests/bandwidthlab/test_sram.py).  Everything
beyond that subset (1R1W, 2RW, queues, non-power-of-two banks, skew/xor mapping,
multi-word accesses) is an extension and is *not* RTL-validated.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable

import numpy as np

from .banking import BankMapper, BankMapping
from .events import EventType
from .scheduler import Scheduler
from .transaction import MemTransaction, TransactionLedger, TxnState, TxnStatus


class SramConfigError(ValueError):
    pass


class PortType(str, Enum):
    RW1 = "1RW"
    R1W1 = "1R1W"
    RW2 = "2RW"


@dataclass
class SramConfig:
    name: str = "sram"
    base_addr: int = 0
    capacity_bytes: int = 64 * 1024
    banks: int = 4
    data_width: int = 32                 # bank word width in bits (DATA_WIDTH)
    read_latency: int = 1                # READ_LATENCY, cycles accept -> read data
    write_latency: int | None = None     # WRITE_LATENCY, cycles accept -> write ack (default = read_latency)
    port_type: PortType = PortType.RW1   # PORT_COUNT/type of every bank macro
    n_ports: int = 1                     # requester ports into the bank array
    queue_depth: int = 0                 # QUEUE_DEPTH per requester port (0 = sramlib direct)
    arbitration: str = "rr"              # ARBITRATION_POLICY: rr | fixed
    mapping: BankMapping = BankMapping.LOW
    rsp_fifo_depth: int | None = None    # response credits per port (None -> read_latency + 1; 0 -> unlimited)
    write_ack: bool = True               # sramlib WRITE_ACK
    misaligned: str = "error"            # error | split
    clock: str = "clk"                   # clock domain name (CLOCK_FREQUENCY comes from the domain)

    def __post_init__(self) -> None:
        self.port_type = PortType(self.port_type)
        self.mapping = BankMapping(self.mapping)
        if self.data_width < 8 or self.data_width % 8:
            raise SramConfigError("data_width must be a positive multiple of 8 bits")
        if self.banks < 1 or self.n_ports < 1:
            raise SramConfigError("banks >= 1 and n_ports >= 1")
        if self.capacity_bytes % (self.banks * self.word_bytes):
            raise SramConfigError(f"{self.name}: capacity {self.capacity_bytes} B is not a multiple of "
                                  f"banks x word ({self.banks} x {self.word_bytes} B)")
        if self.depth < 1:
            raise SramConfigError("each bank needs at least one word")
        if self.read_latency < 1:
            raise SramConfigError("read_latency must be >= 1 cycle (synchronous SRAM)")
        if self.write_latency is None:
            self.write_latency = self.read_latency
        if self.write_latency < 1:
            raise SramConfigError("write_latency must be >= 1 cycle")
        if self.queue_depth < 0:
            raise SramConfigError("queue_depth must be >= 0")
        if self.arbitration not in ("rr", "fixed"):
            raise SramConfigError("arbitration must be rr or fixed")
        if self.rsp_fifo_depth is None:
            self.rsp_fifo_depth = max(self.read_latency, self.write_latency) + 1
        if self.rsp_fifo_depth < 0:
            raise SramConfigError("rsp_fifo_depth must be >= 0")
        if self.misaligned not in ("error", "split"):
            raise SramConfigError("misaligned must be 'error' or 'split'")
        BankMapper(self.banks, self.depth, self.mapping)    # validates mapping vs bank count

    @property
    def word_bytes(self) -> int:
        return self.data_width // 8

    @property
    def depth(self) -> int:
        return self.capacity_bytes // (self.banks * self.word_bytes)

    @property
    def ops_per_bank_cycle(self) -> int:
        return 1 if self.port_type == PortType.RW1 else 2

    def peak_words_per_cycle(self) -> int:
        """Analytical ceiling: banks x ops/bank/cycle, limited by the number of ports."""
        return min(self.banks * self.ops_per_bank_cycle, self.n_ports * self.banks)


@dataclass
class _Word:
    word: int        # word address within the array
    bank: int
    row: int
    granted: bool = False
    grant_cycle: int = -1


@dataclass
class _Req:
    txn: MemTransaction
    port: int
    words: list[_Word]
    ok: bool
    is_write: bool
    need_rsp: bool
    present_cycle: int
    enq_cycle: int = -1
    first_grant: int = -1
    data_words: dict[int, int] = field(default_factory=dict)


@dataclass
class _Rsp:
    req: _Req
    ready_cycle: int
    service_done_marked: bool = False


@dataclass
class BankStats:
    reads: int = 0
    writes: int = 0
    busy_cycles: int = 0
    conflicts: int = 0               # word-cycles that lost arbitration for this bank
    collisions: int = 0              # same-row conflicts on multi-port banks
    queue_occ_sum: int = 0           # sum over active cycles of words waiting for this bank
    queue_occ_max: int = 0
    wait_cycles_sum: int = 0         # sum over granted words of (grant - present/enqueue) cycles
    granted_words: int = 0


class BankedSram:
    """Cycle-aware banked SRAM target (see module docstring)."""

    kind = "sram"
    rank = 0

    def __init__(self, sched: Scheduler, cfg: SramConfig, *, ledger: TransactionLedger | None = None,
                 name: str | None = None) -> None:
        self.sched, self.cfg = sched, cfg
        self.name = name or cfg.name
        self.domain = cfg.clock
        self.drv = sched.driver(cfg.clock)
        self.clock = self.drv.clock
        self.ledger = ledger
        self.mapper = BankMapper(cfg.banks, cfg.depth, cfg.mapping)
        np_, nb = cfg.n_ports, cfg.banks
        self.mem: dict[int, int] = {}
        self.slot: list[_Req | None] = [None] * np_          # presented (valid) request per port
        self.fifo: list[deque[_Req]] = [deque() for _ in range(np_)]
        self.inflight: list[deque[_Rsp]] = [deque() for _ in range(np_)]
        self.ptr = [0] * nb
        self.rw_toggle = [0] * nb                            # 1R1W alternating collision priority
        self.credit_ok = [True] * np_                        # registered at the start of each edge
        self.fifo_len_reg = [0] * np_
        self.popped_this_edge = [False] * np_
        self.accept_cb: list[Callable[[MemTransaction, int], None] | None] = [None] * np_
        self.bank = [BankStats() for _ in range(nb)]
        self.port_bp_cycles = [0] * np_                      # response ready but not taken
        self.port_accepted = [0] * np_
        self.port_conflict_cycles = [0] * np_
        self.port_credit_stall = [0] * np_
        self.lat_cycles: list[int] = []                      # accept -> response handshake
        self.service_cycles: list[int] = []
        self.first_cycle: int | None = None
        self.last_cycle: int | None = None
        self.active_cycles = 0
        self.bytes_read = 0
        self.bytes_written = 0
        self.errors = 0
        self.log: list[tuple[int, str, int, int, int]] = []  # (cycle, ACC|CONF|RSP, port, tid, bank)
        self.log_enabled = False
        self.drv.attach(self)
        sched.register(self)

    # ------------------------------------------------------------------ geometry
    @property
    def base(self) -> int:
        return self.cfg.base_addr

    @property
    def capacity(self) -> int:
        return self.cfg.capacity_bytes

    def contains(self, addr: int, size: int = 1) -> bool:
        return self.base <= addr and addr + size <= self.base + self.capacity

    def peak_bytes_per_cycle(self) -> int:
        return self.cfg.peak_words_per_cycle() * self.cfg.word_bytes

    # ------------------------------------------------------------------ functional memory (for loading data)
    def write_bytes(self, addr: int, data: bytes) -> None:
        """Back-door initialisation (no timing)."""
        wb = self.cfg.word_bytes
        for i, byte in enumerate(data):
            a = addr - self.base + i
            w, off = divmod(a, wb)
            old = self.mem.get(w, 0)
            self.mem[w] = (old & ~(0xFF << (8 * off))) | (byte << (8 * off))

    def read_bytes(self, addr: int, n: int) -> bytes:
        wb = self.cfg.word_bytes
        out = bytearray()
        for i in range(n):
            a = addr - self.base + i
            w, off = divmod(a, wb)
            out.append((self.mem.get(w, 0) >> (8 * off)) & 0xFF)
        return bytes(out)

    def write_word(self, word: int, value: int) -> None:
        self.mem[word] = value & ((1 << self.cfg.data_width) - 1)

    # ------------------------------------------------------------------ target protocol
    def outstanding(self) -> int:
        return (sum(1 for s in self.slot if s is not None) + sum(len(f) for f in self.fifo)
                + sum(len(q) for q in self.inflight))

    def busy(self) -> bool:
        return self.outstanding() > 0

    def can_present(self, port: int) -> bool:
        return self.slot[port] is None

    def set_accept_callback(self, port: int, cb: Callable[[MemTransaction, int], None] | None) -> None:
        self.accept_cb[port] = cb

    def _decode(self, txn: MemTransaction) -> tuple[bool, list[_Word]]:
        cfg = self.cfg
        wb = cfg.word_bytes
        words: list[int]
        explicit = txn.meta.get("words") if txn.meta else None
        if explicit is not None:
            words = [int(w) for w in explicit]
            ok = all(0 <= w < self.mapper.total_words for w in words) and len(words) > 0
        else:
            off = txn.meta.get("_local_addr", txn.addr) - self.base
            if off < 0 or off + txn.size > self.capacity:
                return False, []
            if cfg.misaligned == "error":
                # natural alignment (SFB2 CHECK_ALIGN): an access of <= one word must be aligned to its
                # size and stay inside one word (narrow accesses use byte enables); a multi-word
                # access must start on a word boundary
                if (txn.size <= wb and (off % txn.size or off // wb != (off + txn.size - 1) // wb)) or \
                        (txn.size > wb and off % wb):
                    return False, []
            first = off // wb
            last = (off + txn.size - 1) // wb
            words = list(range(first, last + 1))
            ok = True
        if not ok:
            return False, []
        return True, [_Word(w, *self.mapper.map(w)) for w in words]

    def present(self, port: int, txn: MemTransaction) -> None:
        """Assert valid on ``port`` with ``txn``; held until accepted."""
        if not 0 <= port < self.cfg.n_ports:
            raise IndexError(f"{self.name}: port {port} out of range")
        if self.slot[port] is not None:
            raise RuntimeError(f"{self.name}: port {port} already holds a request (valid must stay until accepted)")
        ok, words = self._decode(txn)
        is_w = txn.op == "W"
        need = (not is_w) or self.cfg.write_ack or (not ok)
        cyc = self.drv.cycle()
        txn.meta["posted"] = not need
        self.slot[port] = _Req(txn, port, words, ok, is_w, need, cyc)
        if txn.t_at_target is None and txn.state < TxnState.AT_TARGET:
            txn.advance(TxnState.AT_TARGET, self.sched.now)
        txn.path.append(self.name)
        self.drv.wake()

    def peek_response(self, port: int, cyc: int) -> MemTransaction | None:
        q = self.inflight[port]
        if q and q[0].ready_cycle <= cyc:
            return q[0].req.txn
        return None

    def pop_response(self, port: int, cyc: int) -> MemTransaction:
        q = self.inflight[port]
        if not q or q[0].ready_cycle > cyc:
            raise RuntimeError(f"{self.name}: no response ready on port {port}")
        if self.popped_this_edge[port]:
            raise RuntimeError(f"{self.name}: two responses on port {port} in one cycle")
        rsp = q.popleft()
        self.popped_this_edge[port] = True
        self._mark_service_done(rsp)
        t = rsp.req.txn
        now = self.sched.now
        t.advance(TxnState.RESPONSE, now)
        acc_c = rsp.req.txn.meta.get("_acc_cycle", cyc)
        self.lat_cycles.append(cyc - acc_c)
        if self.log_enabled:
            self.log.append((cyc, "RSP", port, t.tid, -1))
        return t

    # ------------------------------------------------------------------ phases
    def on_response(self, cyc: int) -> None:
        # registered state for this edge (credits and FIFO fullness are flops)
        d = self.cfg.rsp_fifo_depth
        for p in range(self.cfg.n_ports):
            self.credit_ok[p] = (d == 0) or (len(self.inflight[p]) < d)
            self.fifo_len_reg[p] = len(self.fifo[p])
            self.popped_this_edge[p] = False
            for r in self.inflight[p]:
                if r.ready_cycle > cyc:
                    break
                self._mark_service_done(r)

    def _mark_service_done(self, r: _Rsp) -> None:
        if r.service_done_marked:
            return
        r.service_done_marked = True
        t = r.req.txn
        t_done = self.clock.edge(r.ready_cycle)
        t.advance(TxnState.SERVICE_DONE, max(t_done, t.last_stamp()))
        self.service_cycles.append(r.ready_cycle - r.req.first_grant)
        self.sched.emit(EventType.MEMORY_SERVICE_COMPLETED, domain=self.domain, txn=t, src=self.name,
                        dst=t.master, payload={"port": r.req.port, "words": len(r.req.words)})
        self.sched.emit(EventType.RESPONSE_GENERATED, domain=self.domain, txn=t, src=self.name, dst=t.master,
                        payload={"port": r.req.port, "error": t.status != TxnStatus.OK})

    def on_accept(self, cyc: int) -> None:
        cfg = self.cfg
        nb = cfg.banks
        np_ = cfg.n_ports
        self.active_cycles += 1
        if self.first_cycle is None:
            self.first_cycle = cyc
        self.last_cycle = cyc
        # ---- candidates: the request currently contending for banks on each port
        heads: list[_Req | None] = [None] * np_
        for p in range(np_):
            if cfg.queue_depth == 0:
                heads[p] = self.slot[p]
            else:
                f = self.fifo[p]
                heads[p] = f[0] if (f and f[0].enq_cycle < cyc) else None
        breq: list[list[tuple[int, _Word, bool]]] = [[] for _ in range(nb)]
        eligible = [False] * np_
        for p in range(np_):
            r = heads[p]
            if r is None:
                continue
            credit = self.credit_ok[p] or not r.need_rsp
            if not credit:
                self.port_credit_stall[p] += 1
                continue
            eligible[p] = True
            if r.ok:
                for w in r.words:
                    if not w.granted:
                        breq[w.bank].append((p, w, r.is_write))
        # ---- per-bank arbitration with port-type capacity
        granted_words: list[tuple[int, _Word, bool]] = []
        for b in range(nb):
            cands = breq[b]
            st = self.bank[b]
            if not cands:
                continue
            waiting = len(cands)
            st.queue_occ_sum += waiting
            if waiting > st.queue_occ_max:
                st.queue_occ_max = waiting
            if cfg.arbitration == "rr":
                start = self.ptr[b]
                order = sorted(cands, key=lambda c: ((c[0] - start) % np_, c[1].word))
            else:
                order = sorted(cands, key=lambda c: (c[0], c[1].word))
            g = self._grant_bank(b, order)
            if g:
                st.busy_cycles += 1
                last_port = g[-1][0]
                if cfg.arbitration == "rr":
                    self.ptr[b] = 0 if last_port == np_ - 1 else last_port + 1
            gset = {id(x[1]) for x in g}
            for c in cands:
                if id(c[1]) not in gset:
                    st.conflicts += 1
                    self.port_conflict_cycles[c[0]] += 1
                    if self.log_enabled:
                        self.log.append((cyc, "CONF", c[0], heads[c[0]].txn.tid, b))
                    if self.sched.record_events:
                        self.sched.emit(EventType.BANK_CONFLICT, domain=self.domain, txn=heads[c[0]].txn,
                                        src=self.name, dst=self.name, payload={"bank": b, "port": c[0]})
            granted_words.extend(g)
        # ---- perform the granted word accesses (writes take effect at the grant edge)
        for p, w, is_w in granted_words:
            r = heads[p]
            w.granted = True
            w.grant_cycle = cyc
            if r.first_grant < 0:
                r.first_grant = cyc
            st = self.bank[w.bank]
            st.granted_words += 1
            st.wait_cycles_sum += cyc - (r.present_cycle if cfg.queue_depth == 0 else r.enq_cycle)
            if is_w:
                st.writes += 1
                self._write_word(r, w)
            else:
                st.reads += 1
                r.data_words[w.word] = self.mem.get(w.word, 0)
        # ---- completion of request-level grants
        for p in range(np_):
            r = heads[p]
            if r is None or not eligible[p]:
                continue
            if r.ok and not all(w.granted for w in r.words):
                continue
            # every word granted (or error request): the request is serviced this edge
            if r.first_grant < 0:
                r.first_grant = cyc
            if cfg.queue_depth == 0:
                self.slot[p] = None
                self._handshake(r, cyc)
            else:
                self.fifo[p].popleft()
                self._mark_dequeued(r)
            self._start_service(r, cyc)
        # ---- request FIFO admission (queued mode): registered not-full flag
        if cfg.queue_depth > 0:
            for p in range(np_):
                r = self.slot[p]
                if r is None:
                    continue
                if self.fifo_len_reg[p] < cfg.queue_depth:
                    self.slot[p] = None
                    r.enq_cycle = cyc
                    self.fifo[p].append(r)
                    self._handshake(r, cyc)
                    self.sched.emit(EventType.QUEUE_ENTERED, domain=self.domain, txn=r.txn, src=r.txn.master,
                                    dst=self.name, payload={"queue": f"{self.name}.p{p}", "occupancy":
                                                            len(self.fifo[p])})
                else:
                    self.sched.emit(EventType.BACKPRESSURE, domain=self.domain, txn=r.txn, src=self.name,
                                    dst=r.txn.master, payload={"reason": "request queue full", "port": p})

    def _grant_bank(self, b: int, order: list[tuple[int, _Word, bool]]) -> list[tuple[int, _Word, bool]]:
        pt = self.cfg.port_type
        if pt == PortType.RW1:
            return [order[0]]
        if pt == PortType.R1W1:
            rd = next((c for c in order if not c[2]), None)
            wr = next((c for c in order if c[2]), None)
            if rd is not None and wr is not None and rd[1].row == wr[1].row:
                # same-address read/write collision: STALL, alternating priority (sramlib default)
                self.bank[b].collisions += 1
                pick = rd if self.rw_toggle[b] == 0 else wr
                self.rw_toggle[b] ^= 1
                return [pick]
            return [c for c in (rd, wr) if c is not None] if (rd is None or wr is None or order.index(rd) <
                                                               order.index(wr)) else [wr, rd]
        # 2RW true dual port
        first = order[0]
        for c in order[1:]:
            if c[1].row == first[1].row and (c[2] or first[2]):
                self.bank[b].collisions += 1        # same address with a write: sequential semantics
                continue
            return [first, c]
        return [first]

    def _write_word(self, r: _Req, w: _Word) -> None:
        cfg = self.cfg
        wb = cfg.word_bytes
        t = r.txn
        explicit = t.meta.get("words") if t.meta else None
        if explicit is not None:
            idx = explicit.index(w.word)
            vals = t.meta.get("word_data") or []
            new = vals[idx] if idx < len(vals) else 0
            self.mem[w.word] = new & ((1 << cfg.data_width) - 1)
            self.bytes_written += wb
            return
        off = t.meta.get("_local_addr", t.addr) - self.base
        old = self.mem.get(w.word, 0)
        data = t.data or 0
        mask = t.mask
        val = old
        nbytes = 0
        for k in range(wb):
            a = w.word * wb + k                  # byte offset in the array
            i = a - off                          # byte index within the transaction
            if i < 0 or i >= t.size:
                continue
            if mask is not None and not (mask >> i) & 1:
                continue
            byte = (data >> (8 * i)) & 0xFF
            val = (val & ~(0xFF << (8 * k))) | (byte << (8 * k))
            nbytes += 1
        self.mem[w.word] = val
        self.bytes_written += nbytes

    def _handshake(self, r: _Req, cyc: int) -> None:
        t = r.txn
        now = self.sched.now
        if t.t_accepted is None:
            t.mark_accepted(now)
            if self.ledger is not None:
                self.ledger.on_accepted(t)
            self.sched.emit(EventType.REQUEST_ACCEPTED, domain=self.domain, txn=t, src=t.master, dst=self.name,
                            payload={"port": r.port})
        self.port_accepted[r.port] += 1
        t.meta["_acc_cycle"] = cyc
        if self.log_enabled:
            self.log.append((cyc, "ACC", r.port, t.tid, r.words[0].bank if (r.ok and r.words) else -1))
        cb = self.accept_cb[r.port]
        if cb is not None:
            cb(t, cyc)

    def _mark_dequeued(self, r: _Req) -> None:
        self.sched.emit(EventType.QUEUE_EXITED, domain=self.domain, txn=r.txn, src=self.name, dst=self.name,
                        payload={"queue": f"{self.name}.p{r.port}"})

    def _start_service(self, r: _Req, cyc: int) -> None:
        t = r.txn
        now = self.sched.now
        t.advance(TxnState.SERVICE_STARTED, now)
        self.sched.emit(EventType.MEMORY_SERVICE_STARTED, domain=self.domain, txn=t, src=self.name, dst=t.master,
                        payload={"port": r.port, "banks": sorted({w.bank for w in r.words}),
                                 "first_grant_cycle": r.first_grant})
        if not r.ok:
            t.status = TxnStatus.SLAVE_ERROR
            t.error = True
            if not r.is_write:
                t.data = 0                  # error responses carry rdata = 0 (SFB2 R8 / sramlib)
            self.errors += 1
            self.sched.emit(EventType.ERROR_RESPONSE, domain=self.domain, txn=t, src=self.name, dst=t.master,
                            payload={"reason": "address out of range or misaligned"})
        else:
            t.status = TxnStatus.OK
            if not r.is_write:
                if t.meta.get("words") is not None:
                    t.meta["word_data"] = [r.data_words[w.word] for w in r.words]
                    self.bytes_read += len(r.words) * self.cfg.word_bytes
                else:
                    wb = self.cfg.word_bytes
                    off = t.meta.get("_local_addr", t.addr) - self.base
                    val = 0
                    for i in range(t.size):
                        a = off + i
                        wd, k = divmod(a, wb)
                        val |= ((r.data_words.get(wd, 0) >> (8 * k)) & 0xFF) << (8 * i)
                    t.data = val
                    self.bytes_read += t.size
        lat = self.cfg.write_latency if r.is_write else self.cfg.read_latency
        if r.need_rsp:
            rsp = _Rsp(r, cyc + lat)
            q = self.inflight[r.port]
            if q and q[-1].ready_cycle > rsp.ready_cycle:
                rsp.ready_cycle = q[-1].ready_cycle        # in-order responses per port
            q.append(rsp)
        else:
            # posted write (WRITE_ACK=0): no response; the port owner completes it at acceptance
            t.advance(TxnState.SERVICE_DONE, now)
            self.sched.emit(EventType.MEMORY_SERVICE_COMPLETED, domain=self.domain, txn=t, src=self.name,
                            dst=t.master, payload={"posted": True})

    def on_post(self, cyc: int) -> None:
        for p in range(self.cfg.n_ports):
            q = self.inflight[p]
            if q and q[0].ready_cycle <= cyc and not self.popped_this_edge[p]:
                self.port_bp_cycles[p] += 1
        # single-port invariant: never more grants on a bank than its port type allows (checked in tests)

    # ------------------------------------------------------------------ statistics
    def window_cycles(self) -> int:
        if self.first_cycle is None:
            return 0
        return self.last_cycle - self.first_cycle + 1 + self.cfg.read_latency

    def stats(self, window_cycles: int | None = None) -> dict:
        cfg = self.cfg
        win = window_cycles or self.window_cycles() or 1
        lat = np.asarray(self.lat_cycles if self.lat_cycles else [0], dtype=float)
        banks = []
        for b, st in enumerate(self.bank):
            acc = st.reads + st.writes
            banks.append({
                "bank": b, "reads": st.reads, "writes": st.writes, "busy_cycles": st.busy_cycles,
                "idle_cycles": max(0, win - st.busy_cycles), "conflicts": st.conflicts, "collisions": st.collisions,
                "avg_queue_occupancy": st.queue_occ_sum / win, "max_queue_occupancy": st.queue_occ_max,
                "avg_service_latency_cycles": (st.wait_cycles_sum / st.granted_words + cfg.read_latency)
                if st.granted_words else 0.0,
                "utilisation": st.busy_cycles / win,
                "throughput_bytes_per_cycle": acc * cfg.word_bytes / win,
            })
        tot_words = sum(s.reads + s.writes for s in self.bank)
        return {
            "name": self.name, "window_cycles": win, "banks": banks,
            "words": tot_words, "words_per_cycle": tot_words / win,
            "bytes_per_cycle": tot_words * cfg.word_bytes / win,
            "peak_words_per_cycle": cfg.peak_words_per_cycle(),
            "bytes_read": self.bytes_read, "bytes_written": self.bytes_written,
            "conflicts": sum(s.conflicts for s in self.bank), "collisions": sum(s.collisions for s in self.bank),
            "errors": self.errors,
            "avg_latency_cycles": float(lat.mean()), "max_latency_cycles": float(lat.max()),
            "port_accepted": list(self.port_accepted), "port_conflict_cycles": list(self.port_conflict_cycles),
            "port_credit_stall_cycles": list(self.port_credit_stall),
            "port_rsp_backpressure_cycles": list(self.port_bp_cycles),
            "mapping": self.mapper.describe(), "port_type": cfg.port_type.value,
        }
