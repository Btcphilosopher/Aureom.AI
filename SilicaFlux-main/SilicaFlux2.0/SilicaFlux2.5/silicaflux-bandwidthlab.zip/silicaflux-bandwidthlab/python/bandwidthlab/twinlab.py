"""TwinLab export (standalone schema + example importer).

Audit finding: the TwinLab app (silicaflux-twinlab.zip) has NO import path -- it keeps a
hard-coded architecture in memory and only *exports* HTML/JSON/CSV.  BandwidthLab therefore
provides a standalone, versioned exchange schema (pydantic -> JSON Schema), an exporter, and
an example importer (``load_export`` + ``to_twinlab_architecture``) that maps the export onto
TwinLab's own ``ArchitectureConfig`` field names (semiconductor.models.ts).  The importer is
exercised by tests/bandwidthlab/test_twinlab.py.

Geometry: none.  Blocks are *logical* (masters, fabric, memories, banks); no physical wiring
or placement is claimed.  If a FloorplanLab ``twinlab_floorplan.json`` is supplied, macro
bounding boxes are attached by exact name match only, and ``placement_source`` records it.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from pydantic import BaseModel, ConfigDict, Field

SCHEMA_VERSION = "1.0.0"


class _M(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Block(_M):
    id: str
    kind: str                       # master | fabric | memory | bank | engine
    parent: str | None = None
    clock_domain: str = ""
    params: dict[str, Any] = Field(default_factory=dict)
    bbox_um: list[float] | None = None


class Link(_M):
    src: str
    dst: str
    bytes: int
    transactions: int
    arbitration_loss_cycles: int = 0


class BankStat(_M):
    memory: str
    bank: int
    reads: int
    writes: int
    utilisation: float
    conflicts: int
    avg_queue: float
    max_queue: int


class LatencySummary(_M):
    master: str
    n: int
    mean_cycles: float
    p95_cycles: float
    p99_cycles: float
    max_cycles: float


class Series(_M):
    name: str
    unit: str
    bucket_cycles: int
    start_cycle: int
    values: list[float]


class TwinLabExport(_M):
    schema_version: str = SCHEMA_VERSION
    producer: str = "SilicaFlux BandwidthLab"
    category: str = "EVENT_SIMULATED"
    configuration: str
    clock_hz: float
    clock_domain: str
    window_cycles: int
    architecture: dict[str, Any]
    blocks: list[Block]
    links: list[Link]
    banks: list[BankStat]
    latency: list[LatencySummary]
    compute_stalls: dict[str, dict[str, int]]
    arbitration: dict[str, Any]
    telemetry: list[Series]
    placement_source: str = "none (logical blocks only; no physical geometry claimed)"
    integration_status: str = ("TwinLab has no importer (audit E.1); load with "
                               "bandwidthlab.twinlab.load_export / to_twinlab_architecture")


def write_schema(path: Path) -> Path:
    path.write_text(json.dumps(TwinLabExport.model_json_schema(), indent=1))
    return path


def export_twinlab(run_dir: Path, bucket_cycles: int = 256, floorplan: Path | None = None) -> Path:
    run = Path(run_dir) / "run_001"
    res = json.loads((run / "results.json").read_text())
    cfg = json.loads((run / "config_resolved.json").read_text())
    meta = json.loads((run / "run_meta.json").read_text())
    r = res["results"]
    period = meta["period_fs"]
    blocks: list[Block] = []
    fab = cfg["fabric"]
    blocks.append(Block(id=fab["name"], kind="fabric", clock_domain=fab["clock"],
                        params={k: fab[k] for k in ("topology", "data_width_bits", "arbitration",
                                                    "max_outstanding_per_master")}))
    for m in r["masters"]:
        blocks.append(Block(id=m, kind="engine" if m in ("te", "ve") else "master", clock_domain=fab["clock"]))
    if r["dmas"]:
        for d in r["dmas"]:
            blocks.append(Block(id=d, kind="master", clock_domain=fab["clock"], params={"feature_level":
                                                                                        r["dmas"][d]["feature_level"]}))
    banks: list[BankStat] = []
    for name, s in r["srams"].items():
        blocks.append(Block(id=name, kind="memory", clock_domain=fab["clock"], params={"mapping": s["mapping"],
                                                                                        "port_type": s["port_type"]}))
        for b in s["banks"]:
            banks.append(BankStat(memory=name, bank=b["bank"], reads=b["reads"], writes=b["writes"],
                                  utilisation=b["utilisation"], conflicts=b["conflicts"],
                                  avg_queue=b["avg_queue_occupancy"], max_queue=b["max_queue_occupancy"]))
    ic = r["interconnect"]
    links = []
    for k, g in ic["grant_matrix"].items():
        src, dst = k.split("->")
        links.append(Link(src=src, dst=dst, bytes=0, transactions=g,
                          arbitration_loss_cycles=ic["conflict_matrix"].get(k, 0)))
    tx = pd.read_csv(run / "transactions.csv")
    byte_map = tx.groupby(["master", "dst"])["size"].sum().to_dict()
    for ln in links:
        ln.bytes = int(byte_map.get((ln.src, ln.dst), 0))
    lat = []
    ld = pd.read_csv(run / "latency_decomposition.csv")
    for m, g in ld.groupby("master"):
        v = g["total_cycles"].to_numpy()
        lat.append(LatencySummary(master=str(m), n=int(v.size), mean_cycles=float(v.mean()),
                                  p95_cycles=float(np.percentile(v, 95)), p99_cycles=float(np.percentile(v, 99)),
                                  max_cycles=float(v.max())))
    stalls = {m: {k: int(v) for k, v in s["time_in_state"].items()} for m, s in r["masters"].items()}
    # time series from the transactions (accepted bytes per target per bucket)
    tel = []
    done = tx.dropna(subset=["t_completed"])
    c0 = int((done["t_created"].min()) // period) if len(done) else 0
    c1 = int((done["t_completed"].max()) // period) + 1 if len(done) else 1
    nb = max(1, (c1 - c0) // bucket_cycles + 1)
    for dst, g in done.groupby("dst"):
        idx = ((g["t_completed"] // period).astype(int) - c0) // bucket_cycles
        vals = np.bincount(idx.to_numpy(), weights=g["size"].to_numpy(), minlength=nb)[:nb]
        tel.append(Series(name=f"bytes_completed.{dst}", unit="bytes per bucket", bucket_cycles=bucket_cycles,
                          start_cycle=c0, values=[float(x) for x in vals]))
    arch = {"sramBankCount": sum(1 for b in banks), "memoryBusWidthBits": fab["data_width_bits"],
            "interconnect": {"topology": fab["topology"], "arbitration": fab["arbitration"],
                             "busWidthBits": fab["data_width_bits"]}}
    exp = TwinLabExport(configuration=cfg["name"], clock_hz=meta["clock_hz"], clock_domain=meta["clock_domain"],
                        window_cycles=int(res["metrics"]["total_cycles"]), architecture=arch, blocks=blocks,
                        links=links, banks=banks, latency=lat, compute_stalls=stalls,
                        arbitration={"grant_matrix": ic["grant_matrix"], "conflict_matrix": ic["conflict_matrix"],
                                     "per_master": ic["masters"]}, telemetry=tel)
    if floorplan is not None and Path(floorplan).exists():
        fp = json.loads(Path(floorplan).read_text())
        boxes = {m["name"]: m.get("bbox_um") for m in fp.get("macros", [])}
        hit = 0
        for b in exp.blocks:
            if b.id in boxes:
                b.bbox_um = boxes[b.id]
                hit += 1
        exp.placement_source = f"FloorplanLab {Path(floorplan).name} ({hit} exact name matches)"
    out = Path(run_dir) / "twinlab"
    out.mkdir(parents=True, exist_ok=True)
    write_schema(out / "bandwidthlab_twinlab.schema.json")
    p = out / "bandwidthlab_twinlab_export.json"
    p.write_text(exp.model_dump_json(indent=1))
    return p


def load_export(path: Path) -> TwinLabExport:
    """Example importer: validate an export against the schema and its internal consistency."""
    exp = TwinLabExport.model_validate_json(Path(path).read_text())
    if exp.schema_version.split(".")[0] != SCHEMA_VERSION.split(".")[0]:
        raise ValueError(f"incompatible schema {exp.schema_version}")
    ids = {b.id for b in exp.blocks}
    for ln in exp.links:
        if ln.src not in ids:
            raise ValueError(f"link from unknown block {ln.src}")
    return exp


def to_twinlab_architecture(exp: TwinLabExport) -> dict[str, Any]:
    """Map onto TwinLab ArchitectureConfig field names (semiconductor.models.ts:31-52)."""
    return {"memory": {"sramBankCount": exp.architecture["sramBankCount"],
                       "memoryBusWidthBits": exp.architecture["memoryBusWidthBits"]},
            "interconnect": {"topology": exp.architecture["interconnect"]["topology"],
                             "arbitration": exp.architecture["interconnect"]["arbitration"],
                             "busWidthBits": exp.architecture["interconnect"]["busWidthBits"]},
            "freqTargetMhz": exp.clock_hz / 1e6}
