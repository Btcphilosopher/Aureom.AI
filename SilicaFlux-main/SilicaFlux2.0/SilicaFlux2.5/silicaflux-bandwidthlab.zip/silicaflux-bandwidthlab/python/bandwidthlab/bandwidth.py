"""Bandwidth accounting.

Definitions (all over an explicit observation window of ``window_cycles`` cycles of one
clock domain; bytes/s are converted with that domain's frequency):

* theoretical link bandwidth   (DATA_WIDTH/8) x f x transfers/cycle x links  [ANALYTICAL]
* offered traffic              bytes of every request the workloads generated
* accepted traffic             bytes of requests the fabric accepted
* completed throughput         bytes of requests that completed (response accepted / posted)
* read / write bandwidth       completed read / write bytes
* useful payload bandwidth     application bytes: ``useful_bytes`` of each transaction.  A
                               DMA copy marks its source reads with useful_bytes = 0 and its
                               destination writes with the copied bytes, so a copy of N bytes
                               counts N useful bytes, not 2N.
* physical link traffic        data beats moved on the link x link width (read data + write
                               data channels; partial byte enables still occupy a full beat)
* bus utilisation              busy channel cycles / window
* transfer efficiency          useful bytes / (peak bytes per cycle x window)

GB/s = 1e9 B/s, GiB/s = 2^30 B/s; both are reported.
"""
from __future__ import annotations

from typing import Sequence

from .transaction import MemTransaction, TxnStatus
from .units import GiBps, GBps, ceil_div, peak_link_bandwidth_Bps


def _bw(nbytes: float, window_cycles: float, clock_hz: float) -> dict:
    if window_cycles <= 0:
        return {"bytes": nbytes, "bytes_per_cycle": 0.0, "GBps": 0.0, "GiBps": 0.0}
    bps = nbytes / window_cycles * clock_hz
    return {"bytes": nbytes, "bytes_per_cycle": nbytes / window_cycles, "GBps": bps / GBps, "GiBps": bps / GiBps}


def bandwidth_report(*, generated: Sequence[MemTransaction], clock_hz: float, window_cycles: float,
                     link_width_bits: int, links: int = 1, transfers_per_cycle: float = 1.0,
                     busy_cycles: dict[str, int] | None = None, stall_cycles: dict[str, int] | None = None,
                     domain: str = "clk") -> dict:
    wb = link_width_bits // 8
    acc = [t for t in generated if t.t_accepted is not None]
    done = [t for t in generated if t.t_completed is not None and t.status != TxnStatus.CANCELLED]
    ok = [t for t in done if t.status == TxnStatus.OK]
    peak = peak_link_bandwidth_Bps(link_width_bits, clock_hz, transfers_per_cycle, links)
    peak_bpc = wb * transfers_per_cycle * links
    useful = sum(t.useful_bytes or 0 for t in ok)
    phys_beats = sum(max(1, ceil_div(t.size, wb)) for t in done)
    rep = {
        "domain": domain, "clock_hz": clock_hz, "window_cycles": window_cycles,
        "window_ns": window_cycles * 1e9 / clock_hz,
        "theoretical_link": {"category": "ANALYTICAL_CEILING", "width_bits": link_width_bits, "links": links,
                             "transfers_per_cycle": transfers_per_cycle, "bytes_per_cycle": peak_bpc,
                             "GBps": peak / GBps, "GiBps": peak / GiBps},
        "offered": _bw(sum(t.size for t in generated), window_cycles, clock_hz),
        "accepted": _bw(sum(t.size for t in acc), window_cycles, clock_hz),
        "completed": _bw(sum(t.size for t in done), window_cycles, clock_hz),
        "read": _bw(sum(t.size for t in ok if t.op == "R"), window_cycles, clock_hz),
        "write": _bw(sum(t.size for t in ok if t.op == "W"), window_cycles, clock_hz),
        "useful_payload": _bw(useful, window_cycles, clock_hz),
        "physical_link_traffic": _bw(phys_beats * wb, window_cycles, clock_hz),
        "transactions": {"generated": len(generated), "accepted": len(acc), "completed": len(done),
                         "errors": sum(1 for t in done if t.status != TxnStatus.OK)},
        "transfer_efficiency": useful / (peak_bpc * window_cycles) if window_cycles else 0.0,
    }
    if busy_cycles:
        rep["utilisation"] = {k: v / window_cycles if window_cycles else 0.0 for k, v in busy_cycles.items()}
        rep["idle_cycles"] = {k: max(0.0, window_cycles - v) for k, v in busy_cycles.items()}
    if stall_cycles:
        rep["stall_cycles"] = dict(stall_cycles)
    return rep
