"""BandwidthLab command line: ``python -m bandwidthlab <command> ...``.

Every command runs real code; optional dependencies are reported when missing.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]


def _json(obj: Any, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, default=str))
    return path


def _record(args: argparse.Namespace, cfg_path: str | None, extra: dict | None = None) -> dict:
    from memorylab.provenance import experiment_record
    rec = experiment_record(config_path=cfg_path, config_dict=None, seed=getattr(args, "seed", None),
                            command=" ".join(sys.argv), repo_hint=ROOT)
    rec["simulator"] = "SilicaFlux BandwidthLab"
    from . import __version__
    rec["simulator_version"] = __version__
    if extra:
        rec.update(extra)
    return rec


# ---------------------------------------------------------------------------- commands
def cmd_deps(args: argparse.Namespace) -> int:
    from importlib import metadata
    req = ["numpy", "scipy", "pandas", "pydantic", "PyYAML", "pytest", "hypothesis", "matplotlib", "plotly",
           "networkx"]
    ok = True
    for p in req:
        try:
            print(f"  {p:12s} {metadata.version(p)}")
        except metadata.PackageNotFoundError:
            print(f"  {p:12s} MISSING")
            ok = False
    for tool in ("verilator", "iverilog", "vvp"):
        print(f"  {tool:12s} {shutil.which(tool) or 'not found (RTL calibration runs will be skipped)'}")
    for opt in ("cocotb", "kaleido"):
        try:
            print(f"  {opt:12s} {metadata.version(opt)} (optional)")
        except metadata.PackageNotFoundError:
            print(f"  {opt:12s} not installed (optional)")
    print(f"  {'ramulator2':12s} {shutil.which('ramulator2') or 'not found (optional DRAM adapter unavailable)'}")
    print(f"  {'gem5':12s} {shutil.which('gem5.opt') or 'not found (no gem5 integration available)'}")
    return 0 if ok else 1


def cmd_validate(args: argparse.Namespace) -> int:
    from .config import load_config
    cfg = load_config(args.config)
    print(f"OK: {cfg.name} ({cfg.status}) -- {len(cfg.memories)} memories, fabric {cfg.fabric.data_width_bits}-bit "
          f"{cfg.fabric.topology}/{cfg.fabric.arbitration}")
    return 0


def cmd_audit_params(args: argparse.Namespace) -> int:
    from .config import load_config, provenance_table
    rows = provenance_table(load_config(args.config))
    for r in rows:
        print(f"{r['provenance']:17s} {r['parameter']:45s} = {str(r['value'])[:30]:30s} {r['source']}")
    return 0


def cmd_analytical(args: argparse.Namespace) -> int:
    from .analytical import system_ceilings
    from .config import load_config
    cfg = load_config(args.config)
    res = system_ceilings(cfg)
    out = Path(args.out) / "analytical" / f"{cfg.name}.json"
    _json({"provenance": _record(args, args.config), "result": res}, out)
    print(json.dumps(res, indent=1, default=str)[:4000])
    print(f"-> {out}")
    return 0


def cmd_simulate(args: argparse.Namespace) -> int:
    from .config import load_config
    from .metrics import run_metrics
    from . import scenarios as sc
    from .export import write_run
    cfg = load_config(args.config)
    b = sc.build(cfg, record_events=not args.no_events)
    wl = args.workload
    if wl == "tile_pipeline":
        sc.tile_pipeline(b, M=args.M, N=args.N, K=args.K,
                         cpu_background={"pattern": "seq_read", "n": 1500,
                                         "offset": (cfg.memory("sram").capacity // 2) & ~0xFFF,
                                         "region_bytes": 8192})
    elif wl == "dma_copy":
        sc.dma_copy(b, src_mem="sram", dst_mem="sram", nbytes=args.bytes, dst_off=cfg.memory("sram").capacity // 4)
    elif wl == "gemm_local":
        sc.gemm_local(b, M=args.M, N=args.N, K=args.K)
    elif wl == "cpu":
        sc.cpu_pattern(b, pattern=args.pattern, n_mem=args.n)
    elif wl == "cpu_vs_dma":
        sc.cpu_vs_dma(b)
    else:
        raise SystemExit(f"unknown workload {wl}")
    t0 = time.time()
    b.system.run()
    res = b.system.results()
    m = run_metrics(b, res, focus_master="cpu_bg" if "cpu_bg" in b.system.masters else None)
    run_dir = Path(args.out)
    write_run(b, res, m, run_dir, record=_record(args, args.config, {"workload": wl}))
    print(f"simulated {cfg.name} / {wl}: {m['total_cycles']} cycles, {m['transactions']} transactions, "
          f"invariant errors {m['invariant_errors']}, wall {time.time() - t0:.1f}s")
    for k in ("effective_bw_GBps", "lat_mean", "lat_p95", "lat_p99", "te_mac_util_total", "sram_bank_conflicts"):
        if k in m:
            print(f"  {k:24s} {m[k]}")
    print(f"-> {run_dir}")
    return 0 if m["invariant_errors"] == 0 else 2


def cmd_sweep(args: argparse.Namespace) -> int:
    from .optimisation import marginal_gains, pareto_front, smallest_meeting
    from .sweep import run_variants, sweep_specs, write_rows
    from .config import load_config
    import yaml
    specs = sweep_specs(args.config)
    if args.limit:
        specs = specs[: args.limit]
    t0 = time.time()
    rows = run_variants(specs, workers=args.workers)
    out = Path(args.out) / "sweeps"
    name = Path(args.config).stem
    write_rows(rows, out, name)
    factors = sorted({r["factor"] for r in rows if r["factor"] not in ("baseline",) and "x" not in r["factor"]})
    base = next(r for r in rows if r["factor"] == "baseline")
    mg = []
    for f in factors:
        fr = [r for r in rows if r["factor"] == f]
        mg.extend(marginal_gains(fr, factor=f))
    write_rows(mg, out, f"{name}_marginal_gains")
    front = pareto_front([r for r in rows if r.get("valid")])
    write_rows(front, out, f"{name}_pareto")
    sw = yaml.safe_load(Path(args.config).read_text())
    tgt = load_config(Path(args.config).parent / sw["base_config"]).targets
    tmap = {}
    if "gemm_tile_pipeline_cycles_max" in tgt:
        tmap["total_cycles_max"] = tgt["gemm_tile_pipeline_cycles_max"]
    if "cpu_load_p99_cycles_max" in tgt:
        tmap["cpu_bg_lat_p99_max"] = tgt["cpu_load_p99_cycles_max"]
    small = smallest_meeting(rows, tmap)
    _json({"provenance": _record(args, args.config, {"variants": len(rows), "wall_s": time.time() - t0}),
           "targets": tmap, "smallest_meeting_targets": small, "baseline": base}, out / f"{name}_summary.json")
    print(f"sweep {name}: {len(rows)} variants ({sum(1 for r in rows if r.get('valid'))} valid) in "
          f"{time.time() - t0:.0f}s -> {out}")
    return 0


def cmd_saturation(args: argparse.Namespace) -> int:
    from .experiments import experiment_h
    t0 = time.time()
    res = experiment_h(args.config, cycles=args.cycles)
    out = Path(args.out) / "saturation" / "saturation.json"
    _json({"provenance": _record(args, args.config), "result": res}, out)
    for lab, c in res["curves"].items():
        print(lab, {k: v for k, v in c["regions"].items() if k != "definitions"})
    print(f"-> {out} ({time.time() - t0:.0f}s)")
    return 0


def cmd_experiments(args: argparse.Namespace) -> int:
    from .experiments import run_all
    t0 = time.time()
    res = run_all(args.config, Path(args.out), workers=args.workers, only=args.only)
    out = Path(args.out) / "experiments" / "experiments.json"
    _json({"provenance": _record(args, args.config, {"wall_s": time.time() - t0}), "result": res}, out)
    for k, e in res.items():
        print(f"== {k}: {e['title']}")
        for r in e.get("rows", []):
            print(f"   {r['label'][:40]:40s} cycles={r.get('total_cycles')}  {r.get('recommendation', '')}")
    print(f"-> {out} ({time.time() - t0:.0f}s)")
    return 0


def cmd_qos(args: argparse.Namespace) -> int:
    from .qos import run_qos
    res = run_qos(args.config, workers=args.workers)
    out = Path(args.out) / "qos" / "qos.json"
    _json({"provenance": _record(args, args.config), "result": res}, out)
    print(json.dumps(res["summary"], indent=1)[:3000])
    print(f"-> {out}")
    return 0


def cmd_calibrate(args: argparse.Namespace) -> int:
    from .calibration import run_calibration
    res = run_calibration(trace=args.trace, out=Path(args.out), rtl=not args.no_rtl, workers=args.workers)
    print(json.dumps(res.get("summary", {}), indent=1, default=str)[:4000])
    return 0


def cmd_trace(args: argparse.Namespace) -> int:
    from .trace_import import read_trace, trace_metrics
    df = read_trace(args.trace, clock_hz=args.clock_hz)
    print(json.dumps(trace_metrics(df), indent=1, default=str))
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    from .report import build_report
    p = build_report(Path(args.run_dir))
    print(f"-> {p}")
    return 0


def cmd_dashboard(args: argparse.Namespace) -> int:
    from .dashboard import build_dashboard, serve
    p = build_dashboard(Path(args.run_dir))
    print(f"-> {p}")
    if args.serve:
        serve(Path(args.run_dir), port=args.port)
    return 0


def cmd_twinlab(args: argparse.Namespace) -> int:
    from .twinlab import export_twinlab
    p = export_twinlab(Path(args.run_dir))
    print(f"-> {p}")
    return 0


def cmd_couple(args: argparse.Namespace) -> int:
    from .coupling import couple
    res = couple(Path(args.run_dir), ROOT / "build" / "bandwidthlab")
    print(json.dumps({k: v for k, v in res.items() if k != "synthesis_logic_nand2eq"}, indent=1, default=str)[:3000])
    return 0


def cmd_test_summary(args: argparse.Namespace) -> int:
    from .report import parse_junit
    s = parse_junit(Path(args.junit))
    s["junit"] = str(args.junit)
    _json(s, Path(args.run_dir) / "test_summary.json")
    print(s)
    return 0 if s["failed"] == 0 else 1


def cmd_all(args: argparse.Namespace) -> int:
    out = Path(args.out)
    cfgd = ROOT / "configs"
    rc = 0
    for c in ("silicaflux_v_datafabric_rtl", "silicaflux_v", "silicaflux_mcu_i", "silicaflux_full"):
        rc |= cmd_analytical(argparse.Namespace(config=str(cfgd / f"{c}.yaml"), out=str(out), seed=None))
    rc |= cmd_simulate(argparse.Namespace(config=str(cfgd / "silicaflux_v.yaml"), workload="tile_pipeline", M=32,
                                          N=32, K=64, bytes=8192, pattern="seq_read", n=2000, no_events=False,
                                          out=str(out / "run_001"), seed=1))
    rc |= cmd_experiments(argparse.Namespace(config=str(cfgd / "silicaflux_v.yaml"), out=str(out), workers=args.workers,
                                             only=None, seed=1))
    rc |= cmd_qos(argparse.Namespace(config=str(cfgd / "silicaflux_v.yaml"), out=str(out), workers=args.workers,
                                     seed=1))
    rc |= cmd_sweep(argparse.Namespace(config=str(cfgd / "bandwidth_sweep.yaml"), out=str(out), workers=args.workers,
                                       limit=None, seed=1))
    rc |= cmd_calibrate(argparse.Namespace(trace=None, out=str(out), no_rtl=False, workers=args.workers))
    rc |= cmd_couple(argparse.Namespace(run_dir=str(out)))
    rc |= cmd_twinlab(argparse.Namespace(run_dir=str(out)))
    rc |= cmd_report(argparse.Namespace(run_dir=str(out)))          # also builds figures + dashboard
    return rc


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="bandwidthlab", description="SilicaFlux BandwidthLab")
    sub = ap.add_subparsers(dest="cmd", required=True)
    out_default = str(ROOT / "reports" / "bandwidthlab" / "example_run")

    def add(name: str, fn, help_: str) -> argparse.ArgumentParser:
        p = sub.add_parser(name, help=help_)
        p.set_defaults(fn=fn)
        return p
    add("deps", cmd_deps, "report required / optional dependencies and tools")
    p = add("validate-config", cmd_validate, "validate a configuration (GATE 1)")
    p.add_argument("--config", required=True)
    p = add("audit-params", cmd_audit_params, "provenance of every parameter")
    p.add_argument("--config", required=True)
    p = add("analytical", cmd_analytical, "LEVEL 1 analytical ceilings")
    p.add_argument("--config", required=True)
    p.add_argument("--out", default=out_default)
    p = add("simulate", cmd_simulate, "LEVEL 2 cycle-aware simulation of one workload")
    p.add_argument("--config", required=True)
    p.add_argument("--workload", default="tile_pipeline",
                   choices=["tile_pipeline", "dma_copy", "gemm_local", "cpu", "cpu_vs_dma"])
    p.add_argument("--M", type=int, default=32)
    p.add_argument("--N", type=int, default=32)
    p.add_argument("--K", type=int, default=64)
    p.add_argument("--bytes", type=int, default=8192)
    p.add_argument("--pattern", default="seq_read")
    p.add_argument("--n", type=int, default=2000)
    p.add_argument("--no-events", action="store_true")
    p.add_argument("--seed", type=int, default=1)
    p.add_argument("--out", default=str(Path(out_default) / "run_001"))
    p = add("sweep", cmd_sweep, "architecture sweep + marginal gains + Pareto")
    p.add_argument("--config", required=True)
    p.add_argument("--workers", type=int, default=None)
    p.add_argument("--limit", type=int, default=None)
    p.add_argument("--out", default=out_default)
    p = add("saturation", cmd_saturation, "offered-load sweep until saturation (experiment H)")
    p.add_argument("--config", required=True)
    p.add_argument("--cycles", type=int, default=4000)
    p.add_argument("--out", default=out_default)
    p = add("experiments", cmd_experiments, "SilicaFlux-V experiments A-J")
    p.add_argument("--config", required=True)
    p.add_argument("--workers", type=int, default=None)
    p.add_argument("--only", default=None, help="subset, e.g. ACD")
    p.add_argument("--out", default=out_default)
    p = add("qos", cmd_qos, "latency QoS / arbitration trade-offs")
    p.add_argument("--config", required=True)
    p.add_argument("--workers", type=int, default=None)
    p.add_argument("--out", default=out_default)
    p = add("calibrate", cmd_calibrate, "LEVEL 3 RTL trace calibration and holdout validation")
    p.add_argument("--trace", default=None, help="optional RTL transaction trace (CSV/JSON) to import")
    p.add_argument("--no-rtl", action="store_true", help="do not run Verilator/Icarus even if available")
    p.add_argument("--workers", type=int, default=None)
    p.add_argument("--out", default=out_default)
    p = add("trace", cmd_trace, "import an RTL trace and print its metrics")
    p.add_argument("--trace", required=True)
    p.add_argument("--clock-hz", type=float, default=None)
    p = add("report", cmd_report, "engineering report (REPORT.md + figures) from a run directory")
    p.add_argument("--run-dir", default=out_default)
    p = add("dashboard", cmd_dashboard, "interactive dashboard (HTML) from a run directory")
    p.add_argument("--run-dir", default=out_default)
    p.add_argument("--serve", action="store_true")
    p.add_argument("--port", type=int, default=8050)
    p = add("couple", cmd_couple, "TimingFlow / PowerLink / synthesis coupling for a run directory")
    p.add_argument("--run-dir", default=out_default)
    p = add("export-twinlab", cmd_twinlab, "TwinLab telemetry export")
    p.add_argument("--run-dir", default=out_default)
    p = add("test-summary", cmd_test_summary, "convert a pytest JUnit XML into <run-dir>/test_summary.json")
    p.add_argument("--junit", required=True)
    p.add_argument("--run-dir", default=out_default)
    p = add("all", cmd_all, "every stage into --out")
    p.add_argument("--out", default=out_default)
    p.add_argument("--workers", type=int, default=None)
    args = ap.parse_args(argv)
    return int(args.fn(args) or 0)


if __name__ == "__main__":
    raise SystemExit(main())
