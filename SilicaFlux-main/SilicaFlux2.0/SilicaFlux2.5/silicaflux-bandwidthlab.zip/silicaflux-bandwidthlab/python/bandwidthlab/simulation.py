"""System container: wires targets, interconnect, masters and DMA onto one scheduler and
collects results with their invariants checked."""
from __future__ import annotations

import time
from typing import Any, Iterable

import numpy as np

from .bandwidth import bandwidth_report
from .bus import FabricConfig, FabricLink, Interconnect
from .dma import DmaConfig, DmaEngine
from .dram import DramConfig, DramTarget
from .events import EventType
from .latency import latency_report, littles_law_ledger
from .masters import Link, Op, ProgramMaster, SramPortLink, TokenBoard
from .scheduler import Scheduler
from .sram import BankedSram, SramConfig
from .transaction import TransactionLedger, TxnStatus


class InvariantViolation(AssertionError):
    pass


class System:
    def __init__(self, name: str = "system", *, fabric_clock: str = "clk", fabric_hz: float = 50e6,
                 record_events: bool = True, watchdog_cycles: int | None = 1_000_000,
                 max_events: int = 30_000_000, wall_limit_s: float | None = 900.0,
                 max_cycles: int | None = None) -> None:
        self.name = name
        self.sched = Scheduler(max_events=max_events, wall_limit_s=wall_limit_s, record_events=record_events)
        self.fabric_clock = fabric_clock
        clk = self.sched.add_clock(fabric_clock, fabric_hz)
        if watchdog_cycles:
            self.sched.watchdog_fs = watchdog_cycles * clk.period_fs
        if max_cycles:
            self.sched.max_time_fs = max_cycles * clk.period_fs
        self.ledger = TransactionLedger()
        self.tokens = TokenBoard()
        self.srams: dict[str, BankedSram] = {}
        self.drams: dict[str, DramTarget] = {}
        self.ic: Interconnect | None = None
        self.masters: dict[str, ProgramMaster] = {}
        self.dmas: dict[str, DmaEngine] = {}
        self.run_info: dict[str, Any] = {}
        self.notes: list[str] = []

    # ------------------------------------------------------------------ construction
    @property
    def clock(self):
        return self.sched.clocks[self.fabric_clock]

    def add_clock(self, name: str, hz: float) -> None:
        self.sched.add_clock(name, hz)

    def add_sram(self, cfg: SramConfig) -> BankedSram:
        if cfg.clock not in self.sched.clocks:
            raise KeyError(f"clock {cfg.clock} not defined")
        s = BankedSram(self.sched, cfg, ledger=self.ledger)
        self.srams[cfg.name] = s
        return s

    def add_dram(self, cfg: DramConfig) -> DramTarget:
        d = DramTarget(self.sched, cfg, fabric_clock=self.fabric_clock, ledger=self.ledger)
        self.drams[cfg.name] = d
        return d

    def add_interconnect(self, cfg: FabricConfig) -> Interconnect:
        if self.ic is not None:
            raise RuntimeError("one interconnect per system")
        self.ic = Interconnect(self.sched, cfg, ledger=self.ledger)
        return self.ic

    def map_target(self, target: Any, *, base: int | None = None, size: int | None = None, port: int = 0,
                   name: str | None = None) -> None:
        assert self.ic is not None, "add the interconnect first"
        self.ic.add_target(name or target.name, target, base=target.base if base is None else base,
                           size=target.capacity if size is None else size, port=port)

    def link(self, master: str) -> FabricLink:
        assert self.ic is not None
        return FabricLink(self.ic, master)

    @staticmethod
    def sram_link(sram: BankedSram, port: int, name: str | None = None) -> SramPortLink:
        return SramPortLink(sram, port, name)

    def add_master(self, name: str, program: Iterable[Op], links: dict[str, Link] | None = None, *,
                   domain: str | None = None, **kw: Any) -> ProgramMaster:
        if links is None:
            links = {"default": self.link(name)}
        m = ProgramMaster(self.sched, name=name, domain=domain or self.fabric_clock, program=program, links=links,
                          ledger=self.ledger, tokens=self.tokens, **kw)
        self.masters[name] = m
        return m

    def add_dma(self, cfg: DmaConfig, read_link: Any = None, write_link: Any = None) -> DmaEngine:
        if read_link is None:
            read_link = self.link(cfg.name if not cfg.dual_port else f"{cfg.name}_rd")
        if cfg.dual_port and write_link is None:
            write_link = self.link(f"{cfg.name}_wr")
        d = DmaEngine(self.sched, cfg, read_link=read_link, write_link=write_link, ledger=self.ledger,
                      tokens=self.tokens)
        self.dmas[cfg.name] = d
        return d

    # ------------------------------------------------------------------ run
    def run(self, until_fs: int | None = None) -> dict:
        t0 = time.perf_counter()
        rs = self.sched.run(until_fs)
        end_cycle = self.sched.cycle_of(self.fabric_clock)
        for m in self.masters.values():
            m.close(end_cycle)
        self.run_info = {"events_processed": rs.events, "end_time_fs": rs.end_time_fs, "stopped_by": rs.stopped_by,
                         "wall_s": time.perf_counter() - t0, "end_cycle": end_cycle,
                         "events_recorded": len(self.sched.log), "event_log_truncated": self.sched.log_truncated}
        return self.run_info

    # ------------------------------------------------------------------ invariants
    def check_invariants(self, *, final: bool = True) -> list[str]:
        errs = self.ledger.final_check() if final else self.ledger.check()
        for t in self.ledger.generated.values():
            if t.t_completed is None:
                continue
            st = t.filled_stamps()
            if any(b < a for a, b in zip(st, st[1:])):
                errs.append(f"tid {t.tid}: negative latency component")
            if t.t_accepted is not None and t.t_service_start is not None and t.t_accepted > t.t_service_start:
                errs.append(f"tid {t.tid}: accepted after service start")
        for s in self.srams.values():
            cap = s.cfg.ops_per_bank_cycle
            for b in s.bank:
                if b.reads + b.writes > b.busy_cycles * cap:
                    errs.append(f"{s.name}: bank exceeded its port capacity")
        return errs

    # ------------------------------------------------------------------ results
    def window_cycles(self) -> tuple[int, int]:
        ts = [t for t in self.ledger.generated.values()]
        if not ts:
            return 0, 0
        clk = self.clock
        lo = min(t.t_created for t in ts)
        hi = max((t.t_completed for t in ts if t.t_completed is not None), default=lo)
        return clk.edge_index_at_or_after(lo), clk.edge_index_at_or_after(hi)

    def results(self, *, include_txn_rows: bool = False) -> dict:
        clk = self.clock
        lo, hi = self.window_cycles()
        win = max(1, hi - lo + 1)
        txns = list(self.ledger.generated.values())
        done = [t for t in txns if t.t_completed is not None]
        stall = {}
        for n, m in self.masters.items():
            for k, v in m.time_in.items():
                stall[f"{n}.{k}"] = v
        busy = {}
        if self.ic is not None:
            for tp in self.ic.tports:
                busy[f"{self.ic.name}.{tp.name}"] = tp.busy_cycles
        width = self.ic.cfg.data_width_bits if self.ic is not None else 32
        links = len(self.ic.tports) if (self.ic is not None and self.ic.cfg.topology == "crossbar") else 1
        bw = bandwidth_report(generated=txns, clock_hz=clk.freq_hz, window_cycles=win, link_width_bits=width,
                              links=max(1, links), busy_cycles=busy, stall_cycles=stall, domain=self.fabric_clock)
        lat = latency_report(done, period_fs=clk.period_fs, clock_hz=clk.freq_hz, domain=self.fabric_clock,
                             sim_cycles=win, group_by="master")
        res = {
            "system": self.name, "category": "EVENT_SIMULATED", "run": self.run_info,
            "window_cycles": [lo, hi], "ledger": self.ledger.summary(), "invariant_errors": self.check_invariants(),
            "littles_law": littles_law_ledger(self.ledger, done), "bandwidth": bw, "latency": lat,
            "masters": {n: m.stats() for n, m in self.masters.items()},
            "srams": {n: s.stats() for n, s in self.srams.items()},
            "drams": {n: d.stats() for n, d in self.drams.items()},
            "dmas": {n: d.stats() for n, d in self.dmas.items()},
            "interconnect": self.ic.stats() if self.ic is not None else None,
            "event_counts": {k.value: v for k, v in sorted(self.sched.type_counts.items(), key=lambda kv: kv[0].value)},
            "errors": sum(1 for t in done if t.status != TxnStatus.OK), "notes": list(self.notes),
        }
        topo = self.topology()
        res["topology"] = {k: v for k, v in topo.items() if k != "graph"}
        if include_txn_rows:
            res["transactions"] = [t.to_record() for t in txns]
        return res

    def topology(self) -> dict:
        """Logical topology as a NetworkX digraph + reachability checks (masters -> fabric -> targets -> banks)."""
        import networkx as nx
        g = nx.DiGraph()
        ic = self.ic
        if ic is not None:
            g.add_node(ic.name, kind="fabric")
            for m in ic.masters:
                g.add_node(m.name, kind="master")
                g.add_edge(m.name, ic.name)
            for tp in ic.tports:
                g.add_node(tp.name, kind="target")
                g.add_edge(ic.name, tp.name)
        for name, s in self.srams.items():
            for b in range(s.cfg.banks):
                g.add_edge(name, f"{name}.bank{b}")
                g.nodes[f"{name}.bank{b}"]["kind"] = "bank"
        unreachable = []
        if ic is not None:
            for tp in ic.tports:
                allowed = [m.name for m in ic.masters if m.name not in ic.allowed or tp.name in ic.allowed[m.name]
                           or any(gr[2] == tp.name or tp.idx in gr[3] for gr in ic.groups
                                  if gr[2] in ic.allowed.get(m.name, set()))]
                if not allowed:
                    unreachable.append(tp.name)
        return {"graph": g, "nodes": g.number_of_nodes(), "edges": g.number_of_edges(),
                "weakly_connected": nx.is_weakly_connected(g) if g.number_of_nodes() else True,
                "unreachable_targets": unreachable}

    def require_clean(self) -> None:
        errs = self.check_invariants()
        if errs:
            raise InvariantViolation("; ".join(errs[:10]))


def percentile(values: list[float], q: float) -> float:
    return float(np.percentile(values, q)) if values else float("nan")
