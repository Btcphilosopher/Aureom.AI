"""Architecture experiment engine: variant execution, parameter sweeps, reproducibility.

A *variant* = (base configuration file, dotted-key overrides, scenario, scenario arguments,
seed).  Variants are executed independently (optionally in parallel worker processes) and
their result rows are returned in the order of the specification, so a sweep is
deterministic: the same specification produces byte-identical result rows (the
``result_hash`` column is checked by tests/bandwidthlab/test_sweep.py).

The full Cartesian product of the factor table is never run by default: the engine runs a
one-factor-at-a-time sweep around the baseline plus explicitly listed interaction grids,
after applying explicit constraints (invalid points are reported with the reason, not
silently dropped).
"""
from __future__ import annotations

import hashlib
import json
import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Any

import yaml

from .config import ConfigError, load_config, read_yaml
from .metrics import run_metrics
from .optimisation import cost_index
from . import scenarios as sc

SCENARIOS = ("tile_pipeline", "gemm_local", "vector_local", "dma_copy", "cpu_pattern", "cpu_vs_dma",
             "cpu_vs_tensor", "multi_stream")


def _hash(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:16]


def _resolve_args(cfg: Any, args: dict) -> dict:
    a = json.loads(json.dumps(args))
    bg = a.get("cpu_background")
    if isinstance(bg, dict) and bg.get("offset") == "half":
        mem = cfg.memory(bg.get("memory", "sram"))
        bg["offset"] = (mem.capacity // 2) & ~0xFFF
    return a


def run_variant(spec: dict) -> dict:
    """Execute one variant; never raises for configuration errors (returns an invalid row)."""
    spec = {k: v for k, v in spec.items() if k != "group"}
    row: dict[str, Any] = {"label": spec.get("label", ""), "factor": spec.get("factor", ""),
                           "value": spec.get("value"), "overrides": spec.get("overrides", {}),
                           "scenario": spec["scenario"], "seed": spec.get("seed", 1)}
    try:
        cfg = load_config(spec["config"], spec.get("overrides") or {})
        args = _resolve_args(cfg, spec.get("args", {}))
        b = sc.build(cfg, record_events=False)
        work = _attach(b, spec["scenario"], args)
        b.system.run()
        res = b.system.results()
        m = run_metrics(b, res, work_macs=work.get("macs"), focus_master=spec.get("focus_master"))
        if "dma_copy" in b.info:
            m["dma_data_ok"] = sc.verify_dma_copy(b)
            descs = res["dmas"]["dma"]["descriptors"]
            m["dma_copy_cycles"] = descs[0]["cycles"] if descs else None
        row.update(m)
        failed = [d for d in res["dmas"].get("dma", {}).get("descriptors", []) if d["failed"]]
        reasons = []
        if row["invariant_errors"]:
            reasons.append(f"{row['invariant_errors']} invariant violations")
        if not m.get("dma_data_ok", True):
            reasons.append("DMA destination data mismatch")
        if m["errors"]:
            reasons.append(f"{m['errors']} transactions completed with an error response")
        if failed:
            reasons.append(f"{len(failed)} DMA descriptors failed ({failed[0]['error']})")
        row["valid"] = not reasons
        row["reason"] = "; ".join(reasons)
        row["throughput"] = (work.get("units", 1.0)) / m["total_cycles"]
        row["cost_index"] = cost_index(row)
        row["config_hash"] = _hash(cfg.model_dump(mode="json"))
    except (ConfigError, ValueError) as e:
        row.update({"valid": False, "reason": f"{type(e).__name__}: {str(e)[:300]}"})
    row["result_hash"] = _hash({k: v for k, v in row.items() if k not in ("result_hash",)})
    return row


def _attach(b: sc.Built, scenario: str, args: dict) -> dict:
    if scenario == "tile_pipeline":
        info = sc.tile_pipeline(b, **args)
        return {"macs": info["useful_macs"], "units": info["useful_macs"]}
    if scenario == "gemm_local":
        sc.gemm_local(b, **args)
        return {"macs": b.info["tensor"]["useful_macs"], "units": b.info["tensor"]["useful_macs"]}
    if scenario == "vector_local":
        sc.vector_local(b, **args)
        return {"units": b.info["vector"]["lane_ops"]}
    if scenario == "dma_copy":
        sc.dma_copy(b, **args)
        return {"units": args["nbytes"]}
    if scenario == "cpu_pattern":
        sc.cpu_pattern(b, **args)
        return {"units": args.get("n_mem", 2000)}
    if scenario == "cpu_vs_dma":
        return sc.cpu_vs_dma(b, **args)
    if scenario == "cpu_vs_tensor":
        r = sc.cpu_vs_tensor(b, **args)
        return {"units": r["units"], "macs": r["units"]}
    if scenario == "multi_stream":
        return sc.multi_stream(b, **args)
    raise ValueError(f"unknown scenario {scenario!r}; one of {SCENARIOS}")


def run_variants(specs: list[dict], workers: int | None = None) -> list[dict]:
    workers = workers if workers is not None else max(1, (os.cpu_count() or 1))
    if workers <= 1 or len(specs) <= 1:
        return [run_variant(s) for s in specs]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(run_variant, specs, chunksize=1))


# ---------------------------------------------------------------------------- sweep definitions
def _constrain(over: dict) -> dict:
    o = dict(over)
    fifo = o.get("dma.fifo_depth")
    if fifo is not None:
        o["dma.burst"] = min(int(o.get("dma.burst", 8)), int(fifo))
        o["dma.max_outstanding_reads"] = min(int(o.get("dma.max_outstanding_reads", 2)), int(fifo))
    mo = o.get("dma.max_outstanding_reads")
    if mo is not None and fifo is None:
        o["dma.fifo_depth"] = max(int(o.get("dma.fifo_depth", 8)), int(mo))
        o["dma.max_outstanding_writes"] = int(mo)
    return o


def _ties(f: dict) -> list[str]:
    t = f.get("tie")
    return [] if t is None else ([t] if isinstance(t, str) else list(t))


def sweep_specs(sweep_file: str | Path) -> list[dict]:
    p = Path(sweep_file)
    sw = yaml.safe_load(p.read_text())
    base = str((p.parent / sw["base_config"]).resolve())
    base_over = dict(sw.get("baseline_overrides") or {})
    wl, wargs = sw["workload"], sw.get("workload_args", {})
    seed = int(sw.get("seed", 1))
    factors = sw["factors"]
    specs: list[dict] = []
    seen: set[str] = set()

    def add(label: str, factor: str, value: Any, over: dict) -> None:
        o = _constrain({**base_over, **over})
        key = _hash(o)
        if key in seen and factor != "baseline":
            pass
        seen.add(key)
        specs.append({"config": base, "overrides": o, "scenario": wl, "args": wargs, "seed": seed,
                      "label": label, "factor": factor, "value": value, "focus_master": "cpu_bg"})

    add("baseline", "baseline", None, {})
    for fname, f in factors.items():
        for v in f["values"]:
            over = {f["key"]: v}
            for tk in _ties(f):
                over[tk] = v
            for k, rv in (f.get("requires") or {}).items():
                over.setdefault(k, rv)
            add(f"{fname}={v}", fname, v, over)
    for pair in sw.get("interactions") or []:
        fa, fb = factors[pair[0]], factors[pair[1]]
        for va in fa["values"]:
            for vb in fb["values"]:
                over = {fa["key"]: va, fb["key"]: vb}
                for f, v in ((fa, va), (fb, vb)):
                    for tk in _ties(f):
                        over[tk] = v
                add(f"{pair[0]}={va},{pair[1]}={vb}", f"{pair[0]}x{pair[1]}", f"{va}|{vb}", over)
    return specs


def write_rows(rows: list[dict], out: Path, name: str) -> tuple[Path, Path]:
    import pandas as pd
    out.mkdir(parents=True, exist_ok=True)
    js = out / f"{name}.json"
    js.write_text(json.dumps(rows, indent=1, default=str))
    flat = []
    for r in rows:
        f = {k: (json.dumps(v) if isinstance(v, (dict, list)) else v) for k, v in r.items()}
        flat.append(f)
    csv = out / f"{name}.csv"
    pd.DataFrame(flat).to_csv(csv, index=False)
    return js, csv


def base_config_dict(path: str | Path) -> dict:
    return read_yaml(path)
