"""Deterministic discrete-event scheduler for BandwidthLab.

This *extends* the MemoryLab kernel (``memorylab.event_engine.EventEngine``) instead of
duplicating it.  Inherited behaviour:

* integer femtosecond time base, ``ClockDomain`` cycle <-> time conversion;
* ordering of pending events by ``(time, priority, sequence number)`` -- equal-time
  events run in priority order and then in scheduling order;
* rejection of negative delays and of events scheduled in the past;
* bounded execution (event count, simulated time, wall-clock) and deadlock detection
  (queue drained while a registered component still reports outstanding work).

Added here:

* typed :class:`~bandwidthlab.events.SimEvent` records with a global sequence number,
  clock domain/cycle, transaction id, source/destination, payload and dependency state;
* detection of *zero-time loops* (unbounded event processing at one timestamp);
* a *forward-progress watchdog* (work outstanding but no completion for too long);
* :class:`DomainDriver`, which evaluates synchronous components in fixed phases on the
  clock edges of one domain and skips idle periods entirely.
"""
from __future__ import annotations

import heapq
import time as _time
from typing import Any, Callable, Iterable

from memorylab.event_engine import (PRIO_COMPLETE, PRIO_ISSUE, PRIO_LATE, PRIO_SAMPLE, PRIO_TICK,  # noqa: F401
                                    ClockDomain, DeadlockError, EventEngine, EventHandle, LimitExceeded,
                                    RunStats, SimulationError, _Ev)

from .events import EventType, SimEvent


class SchedulingError(ValueError):
    """Negative delay, event in the past, or a non-integer time."""


class ZeroTimeLoopError(SimulationError):
    """Too many events processed without simulated time advancing."""


class NoForwardProgressError(SimulationError):
    """Work is outstanding but nothing has completed for longer than the watchdog interval."""


# Phases evaluated, in this order, on every active clock edge of a DomainDriver.
PH_RESPONSE = 0   # pipelines advance; responses are delivered towards masters
PH_ISSUE = 1      # masters present requests (valid) / interconnect input handshakes
PH_ARBITRATE = 2  # arbiters grant; granted requests are presented to targets
PH_ACCEPT = 3     # targets (SRAM banks, DRAM queues) accept or refuse (ready)
PH_POST = 4       # reactions to this edge (dependency release) and statistics sampling
PHASES = (PH_RESPONSE, PH_ISSUE, PH_ARBITRATE, PH_ACCEPT, PH_POST)
PHASE_METHODS = ("on_response", "on_issue", "on_arbitrate", "on_accept", "on_post")


class Scheduler(EventEngine):
    """MemoryLab EventEngine + typed event log + zero-time-loop and progress watchdogs."""

    def __init__(self, *, max_events: int = 20_000_000, max_time_fs: int | None = None,
                 wall_limit_s: float | None = 600.0, max_events_per_timestamp: int = 250_000,
                 watchdog_fs: int | None = None, record_events: bool = True,
                 event_log_limit: int = 3_000_000) -> None:
        super().__init__(max_events=max_events, max_time_fs=max_time_fs, wall_limit_s=wall_limit_s)
        self.max_events_per_timestamp = max_events_per_timestamp
        self.watchdog_fs = watchdog_fs
        self.record_events = record_events
        self.event_log_limit = event_log_limit
        self.log: list[SimEvent] = []
        self.log_truncated = False
        self.emitted = 0
        self.clocks: dict[str, ClockDomain] = {}
        self.drivers: dict[str, "DomainDriver"] = {}
        self.last_progress_fs = 0
        self.progress_marks = 0
        self.type_counts: dict[EventType, int] = {}

    # ------------------------------------------------------------------ clocks
    def add_clock(self, name: str, freq_hz: float, phase_fs: int = 0) -> ClockDomain:
        if name in self.clocks:
            raise ValueError(f"clock domain {name!r} already defined")
        clk = ClockDomain(name, float(freq_hz), int(phase_fs))
        self.clocks[name] = clk
        self.drivers[name] = DomainDriver(self, clk)
        return clk

    def driver(self, domain: str) -> "DomainDriver":
        return self.drivers[domain]

    # ------------------------------------------------------------------ scheduling (stricter errors)
    def schedule(self, delay_fs: int, cb: Callable[[], Any], prio: int = PRIO_ISSUE, label: str = "") -> EventHandle:
        if isinstance(delay_fs, bool) or not isinstance(delay_fs, int):
            if isinstance(delay_fs, float) and delay_fs.is_integer():
                delay_fs = int(delay_fs)
            else:
                raise SchedulingError(f"delay must be an integer number of fs, got {delay_fs!r} ({label})")
        if delay_fs < 0:
            raise SchedulingError(f"negative delay {delay_fs} fs ({label})")
        return self.schedule_at(self.now + delay_fs, cb, prio, label)

    def schedule_at(self, t_fs: int, cb: Callable[[], Any], prio: int = PRIO_ISSUE, label: str = "") -> EventHandle:
        if isinstance(t_fs, bool) or not isinstance(t_fs, int):
            raise SchedulingError(f"event time must be an integer number of fs, got {t_fs!r} ({label})")
        if t_fs < self.now:
            raise SchedulingError(f"cannot schedule in the past: t={t_fs} < now={self.now} ({label})")
        ev = _Ev(t_fs, prio, next(self._seq), cb, label)
        heapq.heappush(self._q, ev)
        return EventHandle(ev)

    def schedule_event(self, t_fs: int, etype: EventType, cb: Callable[[], Any] | None = None, *,
                       prio: int = PRIO_ISSUE, domain: str = "", txn: Any = None, src: str = "",
                       dst: str = "", payload: dict | None = None, dep_state: str = "n/a") -> EventHandle:
        """Schedule a typed event: when it fires it is recorded, then ``cb`` runs."""
        def fire() -> None:
            self.emit(etype, domain=domain, txn=txn, src=src, dst=dst, payload=payload, dep_state=dep_state)
            if cb is not None:
                cb()
        return self.schedule_at(t_fs, fire, prio, etype.value)

    # ------------------------------------------------------------------ event records
    def cycle_of(self, domain: str, t_fs: int | None = None) -> int:
        clk = self.clocks.get(domain)
        if clk is None:
            return -1
        t = self.now if t_fs is None else t_fs
        return int((t - clk.phase_fs) // clk.period_fs) if t >= clk.phase_fs else 0

    def emit(self, etype: EventType, *, domain: str = "", txn: Any = None, tid: int | None = None,
             src: str = "", dst: str = "", payload: dict | None = None, dep_state: str = "n/a") -> None:
        self.emitted += 1
        self.type_counts[etype] = self.type_counts.get(etype, 0) + 1
        if etype in (EventType.RESPONSE_ACCEPTED, EventType.COMPUTE_COMPLETED, EventType.DMA_BURST_COMPLETED,
                     EventType.MEMORY_SERVICE_COMPLETED):
            self.note_progress()
        if not self.record_events:
            return
        if len(self.log) >= self.event_log_limit:
            self.log_truncated = True
            return
        if txn is not None:
            tid = txn.tid
        self.log.append(SimEvent(self.now, domain, self.cycle_of(domain), etype, self.emitted, tid, src, dst,
                                 payload, dep_state))

    def note_progress(self) -> None:
        self.last_progress_fs = self.now
        self.progress_marks += 1

    def events_of(self, *types: EventType) -> list[SimEvent]:
        s = set(types)
        return [e for e in self.log if e.etype in s]

    def events_for(self, tid: int) -> list[SimEvent]:
        return [e for e in self.log if e.tid == tid]

    # ------------------------------------------------------------------ run loop
    def outstanding_work(self) -> list[tuple[str, int]]:
        return [(c.name, c.outstanding()) for c in self._components if c.outstanding() > 0]

    def run(self, until_fs: int | None = None) -> RunStats:
        t0 = _time.perf_counter()
        stopped = "drained"
        same_t = -1
        same_n = 0
        q = self._q
        while q:
            ev = q[0]
            if until_fs is not None and ev.time > until_fs:
                stopped = "until"
                break
            heapq.heappop(q)
            if ev.cancelled:
                continue
            if self.max_time_fs is not None and ev.time > self.max_time_fs:
                raise LimitExceeded(f"simulated time limit {self.max_time_fs} fs exceeded at event '{ev.label}'")
            if ev.time == same_t:
                same_n += 1
                if same_n > self.max_events_per_timestamp:
                    raise ZeroTimeLoopError(
                        f"{same_n} events at t={ev.time} fs without time advancing (last: '{ev.label}')")
            else:
                same_t, same_n = ev.time, 1
            self.now = ev.time
            ev.cb()
            self.events_run += 1
            if self.events_run > self.max_events:
                raise LimitExceeded(f"event limit {self.max_events} exceeded (last: '{ev.label}')")
            if (self.events_run & 0x3FF) == 0:
                if self.wall_limit_s is not None and _time.perf_counter() - t0 > self.wall_limit_s:
                    raise LimitExceeded(f"wall-clock limit {self.wall_limit_s} s exceeded")
                if self.watchdog_fs is not None and self.now - self.last_progress_fs > self.watchdog_fs:
                    stuck = self.outstanding_work()
                    if stuck:
                        raise NoForwardProgressError(
                            f"no completion for {self.now - self.last_progress_fs} fs while work is outstanding: "
                            + ", ".join(f"{n} ({k})" for n, k in stuck))
        if stopped == "drained":
            stuck = self.outstanding_work()
            if stuck:
                raise DeadlockError("event queue empty but work is outstanding: " +
                                    ", ".join(f"{n} ({k} outstanding)" for n, k in stuck))
        return RunStats(self.events_run, self.now, _time.perf_counter() - t0, stopped)


class DomainDriver:
    """Evaluates the synchronous components of one clock domain on its rising edges.

    On every *active* edge the five phases run in order; within a phase, components run
    in attachment order.  The driver schedules the next edge only while at least one
    component reports ``busy()``; otherwise the domain sleeps until something calls
    :meth:`wake` (an arrival, a completion, a cross-domain transfer).  Idle cycles are
    therefore never simulated one by one, but the cycle index of every edge is exact.
    """

    def __init__(self, sched: Scheduler, clock: ClockDomain) -> None:
        self.sched, self.clock = sched, clock
        self.name = clock.name
        self.components: list[Any] = []
        self._phase_calls: list[list[Callable[[int], None]]] = [[] for _ in PHASES]
        self._scheduled: set[int] = set()
        self._last_edge_fs: int | None = None
        self.active_edges = 0

    def attach(self, comp: Any) -> None:
        """Attach a component.  Within a phase, components run in ``rank`` order (targets 0,
        interconnects 1, masters 2), then in attachment order -- so a target has registered
        its state before the fabric reads it, and the fabric before the masters."""
        if comp in self.components:
            raise ValueError(f"{getattr(comp, 'name', comp)} attached twice to domain {self.name}")
        self.components.append(comp)
        self.components.sort(key=lambda c: getattr(c, "rank", 2))
        self._phase_calls = [[] for _ in PHASES]
        for c in self.components:
            for i, m in enumerate(PHASE_METHODS):
                fn = getattr(c, m, None)
                if fn is not None:
                    self._phase_calls[i].append(fn)

    def cycle(self, t_fs: int | None = None) -> int:
        return self.sched.cycle_of(self.name, t_fs)

    def edge_fs(self, cycle: int) -> int:
        return self.clock.edge(cycle)

    def wake(self, at_fs: int | None = None) -> None:
        """Make sure an edge at or after ``at_fs`` (default: now) will be evaluated."""
        t = self.sched.now if at_fs is None else max(at_fs, self.sched.now)
        e = self.clock.next_edge(t)
        if self._last_edge_fs is not None and e <= self._last_edge_fs:
            e = self._last_edge_fs + self.clock.period_fs
        if e in self._scheduled:
            return
        self._scheduled.add(e)
        self.sched.schedule_at(e, self._edge, PRIO_TICK, f"{self.name}.edge")

    def _edge(self) -> None:
        now = self.sched.now
        self._scheduled.discard(now)
        if self._last_edge_fs == now:          # duplicate wake for an edge already evaluated
            return
        self._last_edge_fs = now
        self.active_edges += 1
        cyc = self.clock.edge_index_at_or_after(now)
        for calls in self._phase_calls:
            for fn in calls:
                fn(cyc)
        if any(c.busy() for c in self.components):
            self.wake(now + self.clock.period_fs)


def run_bounded(sched: Scheduler, until_fs: int | None = None) -> RunStats:
    """Run with the scheduler's limits; convenience wrapper used by the CLI."""
    return sched.run(until_fs)


__all__: Iterable[str] = (
    "Scheduler", "DomainDriver", "SchedulingError", "ZeroTimeLoopError", "NoForwardProgressError",
    "DeadlockError", "LimitExceeded", "SimulationError", "ClockDomain", "PH_RESPONSE", "PH_ISSUE",
    "PH_ARBITRATE", "PH_ACCEPT", "PH_POST", "PRIO_COMPLETE", "PRIO_ISSUE", "PRIO_TICK", "PRIO_LATE", "PRIO_SAMPLE",
)
