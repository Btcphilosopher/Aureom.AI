"""SilicaFlux BandwidthLab -- cycle-aware bandwidth, latency and data-movement simulator.

Built on the SilicaFlux MemoryLab kernel (``memorylab.event_engine``), whose event engine,
clock domains, transaction base class, units and provenance classes are reused.
"""
__version__ = "0.1.0"
