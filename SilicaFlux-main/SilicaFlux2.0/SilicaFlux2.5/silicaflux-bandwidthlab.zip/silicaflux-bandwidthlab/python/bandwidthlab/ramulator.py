"""Optional adapter to Ramulator 2 (JEDEC-accurate DRAM simulator).

Checked against the upstream source (github.com/CMU-SAFARI/ramulator2, commit 7bead6cb,
2026-11-04; licence: MIT, Copyright (c) 2023 SAFARI Research Group at ETH Zurich and CMU):

* frontend ``LoadStoreTrace`` (src/ramulator/frontend/impl/memory_trace/loadstore_trace.cpp)
  reads one access per line: ``<op> <address>`` with op ``LD`` (read) or ``ST`` (write) and
  the address in decimal or ``0x`` hex; the trace replays cyclically; Python parameters
  ``LoadStoreTrace(clock_ratio=..., path=...)`` (python/ramulator/frontend/load_store_trace.py).

This module only WRITES such a trace from the DRAM-bound transactions of a BandwidthLab run;
building and running Ramulator 2 (CMake/C++) is left to the user and was not executed in this
project, so no Ramulator result is claimed anywhere.  Note that LoadStoreTrace carries no
timing: it measures the DRAM device under its own request pacing, which is a different
experiment from BandwidthLab's closed-loop system simulation.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd


def write_loadstore_trace(transactions_csv: Path, out: Path, *, target: str | None = None,
                          base: int | None = None) -> dict:
    df = pd.read_csv(transactions_csv)
    if target is not None:
        df = df[df["dst"] == target]
    df = df.sort_values("t_issued")
    lines = []
    for r in df.itertuples(index=False):
        addr = int(r.addr) - (base or 0)
        lines.append(f"{'ST' if r.op == 'W' else 'LD'} 0x{addr:x}")
    Path(out).write_text("\n".join(lines) + ("\n" if lines else ""))
    return {"path": str(out), "records": len(lines), "format": "Ramulator 2 LoadStoreTrace (LD|ST <addr>)",
            "executed": False}
