"""Interactive engineering dashboard (static HTML + local plotly.min.js; optional local server).

Everything shown is read from the run directory.  Result categories are never merged:
ANALYTICAL_CEILING, EVENT_SIMULATED, RTL_OBSERVED (this session) / RTL_SIMULATED (recorded in
the repository), SILICON_MEASURED (empty: no silicon exists).
"""
from __future__ import annotations

import html
import http.server
import json
import socketserver
from pathlib import Path

import plotly.offline

from .plotting import (GOLD_CHROME, CYAN_CHROME, GRID, STATUS, SURFACE, SURFACE_2, TEXT, TEXT_2, TEXT_3,
                       RunData, build_figures, export_figures)
from .traceviewer import build_trace_viewer


def _tile(label: str, value: str, note: str) -> str:
    return (f"<div class='tile'><div class='tl'>{html.escape(label)}</div><div class='tv'>{html.escape(value)}</div>"
            f"<div class='tn'>{html.escape(note)}</div></div>")


def _table(rows: list[dict], cols: list[tuple[str, str]], cls: str = "") -> str:
    h = "".join(f"<th>{html.escape(t)}</th>" for _, t in cols)
    body = []
    for r in rows:
        tds = []
        for k, _ in cols:
            v = r.get(k, "")
            if isinstance(v, float):
                v = f"{v:.4g}"
            tds.append(f"<td>{html.escape(str(v))}</td>")
        body.append("<tr>" + "".join(tds) + "</tr>")
    return f"<table class='{cls}'><thead><tr>{h}</tr></thead><tbody>{''.join(body)}</tbody></table>"


def gate_status(run_dir: Path) -> list[dict]:
    p = Path(run_dir) / "quality_gates.json"
    return json.loads(p.read_text()) if p.exists() else []


def build_dashboard(run_dir: Path) -> Path:
    run_dir = Path(run_dir)
    (run_dir / "plotly.min.js").write_text(plotly.offline.get_plotlyjs())
    figs = build_figures(run_dir)
    exported = export_figures(run_dir, figs, png=True)
    d = RunData(run_dir)
    tiles = []
    cal = d.cal() or {}
    xv = cal.get("xbar_verilator", {})
    xi = cal.get("xbar_iverilog", {})
    if isinstance(xv, dict) and "rows" in xv:
        n = xv["transactions_compared"] + (xi.get("transactions_compared", 0) if isinstance(xi, dict) else 0)
        tiles.append(_tile("Crossbar vs RTL", f"{n:,} txns", "cycle-exact: " + str(xv["all_equivalent"] and
                                                                                   xi.get("all_equivalent", True))
                           + " · Verilator + Icarus · RTL_OBSERVED"))
    if "dma" in cal:
        h = cal["dma"]["holdout_error"]
        tiles.append(_tile("DMA holdout error", f"{h.get('mape', 0):.1%} MAPE",
                           f"{h.get('exact', 0)}/{h.get('n', 0)} rows exact · 1 fitted parameter"))
    eng = cal.get("engines", {}).get("engines", {}) if isinstance(cal.get("engines"), dict) else {}
    if eng:
        mx = max(v["holdout_error"].get("max_abs_error_cycles", 0) for v in eng.values())
        tiles.append(_tile("TE / VE holdout", f"≤ {mx:.0f} cycle", "sfv_tile RTL run in this session"))
    e = d.exp() or {}
    if "D" in e:
        base = next((r for r in e["D"]["rows"] if r["label"].startswith("simple")), None)
        best = min((r for r in e["D"]["rows"] if r.get("valid")), key=lambda r: r["total_cycles"], default=None)
        if base and best:
            tiles.append(_tile("Best DMA level vs simple", f"{base['total_cycles'] / best['total_cycles']:.2f}×",
                               f"{best['label']} · tile pipeline · EVENT_SIMULATED"))
    if "H" in e:
        c = next(iter(e["H"]["curves"].values()))
        tiles.append(_tile("Single-bank saturation", f"{c['regions']['peak_completed_per_cycle']:.2f} req/cyc",
                           f"queueing onset at {c['regions']['onset_of_queueing_rate']} req/cyc/master"))
    sections = []
    for name, f in figs.items():
        div = f.to_html(full_html=False, include_plotlyjs=False, config={"displaylogo": False, "responsive": True,
                                                                         "toImageButtonOptions": {"format": "png",
                                                                                                  "scale": 2}})
        sections.append(f"<section class='card' id='{name}'>{div}<div class='dl'><a href='figures/{name}.html'>HTML</a>"
                        + (f" · <a href='figures/{name}.png'>PNG</a>" if f"{name}.png" in exported["png"] else "")
                        + "</div></section>")
    exp_html = ""
    for k, ex in e.items():
        if "rows" not in ex:
            continue
        exp_html += f"<h3>{html.escape(k)} · {html.escape(ex['title'])}</h3>" + _table(
            ex["rows"], [("label", "variant"), ("total_cycles", "cycles"), ("effective_bw_GBps", "useful GB/s"),
                         ("lat_mean", "mean lat"), ("lat_p95", "P95"), ("lat_p99", "P99"),
                         ("max_bank_queue", "max bank queue"), ("sram_bank_conflicts", "bank conflicts"),
                         ("te_mac_util_total", "TE util"), ("recommendation", "assessment")])
    gates = gate_status(run_dir)
    gate_html = _table(gates, [("gate", "gate"), ("status", "status"), ("evidence", "evidence")], "gates") if gates \
        else "<p class='muted'>quality_gates.json not generated yet (run <code>bandwidthlab report</code>).</p>"
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>SilicaFlux BandwidthLab</title>
<script src="plotly.min.js"></script><style>
:root{{--s:{SURFACE};--s2:{SURFACE_2};--g:{GRID};--t:{TEXT};--t2:{TEXT_2};--t3:{TEXT_3};--gold:{GOLD_CHROME};--cyan:{CYAN_CHROME}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--s);color:var(--t2);font:14px/1.5 Inter,system-ui,sans-serif}}
header{{padding:22px 28px 14px;border-bottom:1px solid var(--g)}}h1{{margin:0;color:var(--t);font-size:22px;letter-spacing:.2px}}
h1 b{{color:var(--gold)}}h1 i{{font-style:normal;color:var(--cyan)}}.sub{{color:var(--t3);font-size:12.5px;margin-top:6px}}
nav{{display:flex;gap:16px;flex-wrap:wrap;padding:10px 28px;border-bottom:1px solid var(--g);font-size:13px}}
a{{color:var(--cyan);text-decoration:none}}a:hover{{text-decoration:underline}}
main{{padding:18px 28px;max-width:1500px;margin:0 auto}}.tiles{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}}
.tile{{background:var(--s2);border:1px solid var(--g);border-radius:10px;padding:12px 14px}}.tl{{color:var(--t3);font-size:12px}}
.tv{{color:var(--t);font-size:22px;font-weight:600;margin:2px 0}}.tn{{color:var(--t3);font-size:11.5px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(620px,1fr));gap:14px;margin-top:16px}}
.card{{background:var(--s);border:1px solid var(--g);border-radius:10px;padding:6px;min-width:0}}.dl{{font-size:12px;padding:0 8px 6px;color:var(--t3)}}
h2{{color:var(--t);font-size:16px;margin:26px 0 8px;border-left:3px solid var(--gold);padding-left:8px}}h3{{color:var(--t);font-size:14px;margin:18px 0 6px}}
table{{border-collapse:collapse;width:100%;font-size:12px;font-family:'JetBrains Mono',ui-monospace,monospace}}
th,td{{border-bottom:1px solid var(--g);padding:4px 6px;text-align:left;vertical-align:top}}th{{color:var(--t3);font-weight:500}}
td{{color:var(--t2)}}.muted{{color:var(--t3)}}code{{color:var(--t)}}.cats span{{display:inline-block;margin-right:14px}}
@media(max-width:700px){{.grid{{grid-template-columns:1fr}}main,header,nav{{padding-left:16px;padding-right:16px}}}}
</style></head><body>
<header><h1><b>Silica</b>Flux <i>BandwidthLab</i> — memory-system bandwidth &amp; latency</h1>
<div class="sub">Run directory: {html.escape(run_dir.name)} · every number on this page was produced by the simulator,
the analytical model or an RTL simulation, and is labelled with its category. SILICON_MEASURED: none (no silicon exists).</div></header>
<nav><a href="#figs">Figures</a><a href="#exps">Experiments A–J</a><a href="#gates">Quality gates</a>
<a href="trace_viewer.html">Transaction timeline ↗</a><a href="REPORT.md">REPORT.md</a></nav>
<main><div class="tiles">{''.join(tiles)}</div>
<h2 id="figs">Figures</h2><div class="grid">{''.join(sections)}</div>
<h2 id="exps">SilicaFlux-V experiments (PROVISIONAL configuration · EVENT_SIMULATED)</h2>{exp_html}
<h2 id="gates">Engineering quality gates</h2>{gate_html}
<p class="muted">PNG export: {len(exported['png'])} figures written{'; errors: ' + html.escape('; '.join(exported['png_errors'][:3])) if exported['png_errors'] else ''}.</p>
</main></body></html>"""
    out = run_dir / "dashboard.html"
    out.write_text(page)
    try:
        build_trace_viewer(run_dir)
    except FileNotFoundError:
        pass
    return out


def serve(run_dir: Path, port: int = 8050) -> None:
    """Serve the run directory on localhost (the lightweight Python interface)."""
    handler = lambda *a, **k: http.server.SimpleHTTPRequestHandler(*a, directory=str(run_dir), **k)  # noqa: E731
    with socketserver.TCPServer(("127.0.0.1", port), handler) as httpd:
        print(f"BandwidthLab dashboard on http://127.0.0.1:{port}/dashboard.html  (Ctrl-C to stop)")
        httpd.serve_forever()
