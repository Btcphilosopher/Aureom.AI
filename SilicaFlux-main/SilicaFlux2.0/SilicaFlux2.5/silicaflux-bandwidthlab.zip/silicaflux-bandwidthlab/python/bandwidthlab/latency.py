"""Latency statistics and exact latency decomposition.

Each completed transaction carries ten ordered timestamps (``MemTransaction.stamps``).
The end-to-end latency is split into nine *consecutive, non-overlapping* intervals, so
the components always sum exactly to the total (no interval is counted twice):

    generation      created      -> issued       master-side wait (outstanding limit, link busy)
    admission       issued       -> enqueued     waiting for space in the fabric input queue
    queue_wait      enqueued     -> queue_head   behind older requests in that queue
    arbitration     queue_head   -> granted      waiting for the arbiter grant
    interconnect    granted      -> at_target    register slices / routing pipeline
    target_wait     at_target    -> service_start bank conflicts, target queue, target backpressure
    memory_service  service_start-> service_end  SRAM/DRAM access time
    response_queue  service_end  -> response     response waiting for the response path
    response_xfer   response     -> completed    response routing / beats to the master

Stages a component does not have are zero-length (the missing timestamp takes the value
of the previous present one, so the time is attributed to the next stage that exists).  ``acceptance`` (issued -> accepted) is reported separately as
an *overlapping* view and is never added to the sum.

Percentiles use numpy's default linear interpolation (method 'linear', i.e. type 7).
Tail percentiles are flagged as statistically unstable when fewer than
``MIN_TAIL_SAMPLES`` samples lie beyond them.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

import numpy as np

from .transaction import MemTransaction

COMPONENTS = ("generation", "admission", "queue_wait", "arbitration", "interconnect", "target_wait",
              "memory_service", "response_queue", "response_xfer")
MIN_TAIL_SAMPLES = 10
PERCENTILES = (50, 90, 95, 99)


def decompose(t: MemTransaction) -> dict[str, int]:
    """Exact non-overlapping decomposition (fs) of one completed transaction."""
    s = t.filled_stamps()
    out = {c: s[i + 1] - s[i] for i, c in enumerate(COMPONENTS)}
    out["total"] = s[-1] - s[0]
    if sum(out[c] for c in COMPONENTS) != out["total"]:
        raise AssertionError(f"tid {t.tid}: latency components do not sum to the total")
    return out


@dataclass
class LatencySummary:
    n: int
    mean: float
    median: float
    p50: float
    p90: float
    p95: float
    p99: float
    min: float
    max: float
    std: float
    unit: str
    warnings: list[str]

    def as_dict(self) -> dict:
        return dict(self.__dict__)


def summarise(values: Sequence[float] | np.ndarray, unit: str = "cycles") -> LatencySummary:
    v = np.asarray(values, dtype=float)
    warn: list[str] = []
    if v.size == 0:
        nan = float("nan")
        return LatencySummary(0, nan, nan, nan, nan, nan, nan, nan, nan, nan, unit, ["no samples"])
    if np.any(v < 0):
        raise ValueError("negative latency sample")
    p = np.percentile(v, PERCENTILES)
    for q in (90, 95, 99):
        beyond = v.size * (1 - q / 100)
        if beyond < MIN_TAIL_SAMPLES:
            warn.append(f"P{q} unstable: only {beyond:.1f} expected samples beyond it (n={v.size}); "
                        f"need n >= {int(np.ceil(MIN_TAIL_SAMPLES / (1 - q / 100)))}")
    return LatencySummary(int(v.size), float(v.mean()), float(np.median(v)), float(p[0]), float(p[1]),
                          float(p[2]), float(p[3]), float(v.min()), float(v.max()),
                          float(v.std(ddof=1)) if v.size > 1 else 0.0, unit, warn)


def bootstrap_ci(values: Sequence[float], q: float, *, n_boot: int = 400, seed: int = 1,
                 conf: float = 0.95) -> tuple[float, float]:
    """Percentile-bootstrap confidence interval for the q-th percentile (seeded, deterministic)."""
    v = np.asarray(values, dtype=float)
    if v.size < 2:
        return (float("nan"), float("nan"))
    rng = np.random.Generator(np.random.PCG64(seed))
    idx = rng.integers(0, v.size, size=(n_boot, v.size))
    est = np.percentile(v[idx], q, axis=1)
    lo, hi = np.percentile(est, [(1 - conf) / 2 * 100, (1 + conf) / 2 * 100])
    return float(lo), float(hi)


def transaction_table(txns: Iterable[MemTransaction], period_fs: int) -> "list[dict]":
    """One row per completed transaction with the decomposition in cycles of ``period_fs``."""
    rows = []
    for t in txns:
        if t.t_completed is None:
            continue
        d = decompose(t)
        row = {"tid": t.tid, "master": t.master, "kind": t.kind.value, "dst": t.dst, "addr": t.addr,
               "size": t.size, "status": t.status.value, "tag": t.meta.get("tag", "")}
        for k, v in d.items():
            row[f"{k}_cycles"] = v / period_fs
        row["acceptance_cycles"] = ((t.t_accepted - t.t_issued) / period_fs) if (
            t.t_accepted is not None and t.t_issued is not None) else None
        row["t_created_fs"] = t.t_created
        row["t_completed_fs"] = t.t_completed
        rows.append(row)
    return rows


def latency_report(txns: Sequence[MemTransaction], *, period_fs: int, clock_hz: float, domain: str,
                   sim_cycles: float, group_by: str | None = "master") -> dict:
    """Summary per group (and overall) in cycles and ns, with sample size and duration."""
    rows = transaction_table(txns, period_fs)
    groups: dict[str, list[dict]] = {"ALL": rows}
    if group_by:
        for r in rows:
            groups.setdefault(str(r[group_by]), []).append(r)
    out: dict = {"clock_domain": domain, "clock_hz": clock_hz,
                 "conversion": f"ns = cycles x {1e9 / clock_hz:.6g} (domain '{domain}')",
                 "simulated_cycles": sim_cycles, "simulated_ns": sim_cycles * 1e9 / clock_hz, "groups": {}}
    for g, rs in groups.items():
        tot = [r["total_cycles"] for r in rs]
        s = summarise(tot, "cycles")
        comp_mean = {c: float(np.mean([r[f"{c}_cycles"] for r in rs])) if rs else 0.0 for c in COMPONENTS}
        out["groups"][g] = {
            "n": s.n, "cycles": s.as_dict(),
            "ns": {k: (v * 1e9 / clock_hz if isinstance(v, float) else v) for k, v in s.as_dict().items()
                   if k in ("mean", "median", "p50", "p90", "p95", "p99", "min", "max", "std")},
            "component_mean_cycles": comp_mean,
            "component_share": {c: (comp_mean[c] / s.mean if s.mean else 0.0) for c in COMPONENTS},
            "warnings": s.warnings,
        }
    return out


def littles_law_check(txns: Sequence[MemTransaction], *, start_key: str = "t_issued",
                      end_key: str = "t_completed", window: tuple[int, int] | None = None) -> dict:
    """Independent queueing consistency check, L = lambda * W, over an observation window.

    L is measured by integrating the number of transactions in the system (between
    ``start_key`` and ``end_key``) over the window -- an event-based integral, not the
    product of the other two -- lambda counts transactions that *finish* inside the window
    and W is their mean time in system.  For a window that starts and ends with an empty
    system the identity holds exactly; otherwise boundary effects make it approximate,
    and the report gives the relative gap together with the boundary population.
    """
    iv = [(getattr(t, start_key), getattr(t, end_key)) for t in txns
          if getattr(t, start_key) is not None and getattr(t, end_key) is not None]
    if not iv:
        return {"n": 0}
    a = np.array(iv, dtype=np.int64)
    lo, hi = (int(a[:, 0].min()), int(a[:, 1].max())) if window is None else window
    if hi <= lo:
        return {"n": 0}
    s = np.clip(a[:, 0], lo, hi)
    e = np.clip(a[:, 1], lo, hi)
    area = float((e - s).sum())                      # integral of N(t) over the window
    L = area / (hi - lo)
    fin = (a[:, 1] > lo) & (a[:, 1] <= hi) & (a[:, 0] >= lo)
    lam = fin.sum() / (hi - lo)
    W = float((a[fin, 1] - a[fin, 0]).mean()) if fin.any() else float("nan")
    lw = lam * W
    at_start = int(((a[:, 0] < lo) & (a[:, 1] > lo)).sum())
    at_end = int(((a[:, 0] < hi) & (a[:, 1] > hi)).sum())
    return {"n": int(fin.sum()), "window_fs": [lo, hi], "L_measured": L, "lambda_per_fs": float(lam),
            "W_fs": W, "lambda_W": lw, "relative_gap": abs(L - lw) / L if L else 0.0,
            "in_system_at_start": at_start, "in_system_at_end": at_end,
            "exact_expected": at_start == 0 and at_end == 0}


def littles_law_ledger(ledger, txns: Sequence[MemTransaction]) -> dict:
    """Little's law with L taken from the ledger's live occupancy integral.

    L = (integral of the number of accepted-but-uncompleted transactions) / duration is
    accumulated by :class:`~bandwidthlab.transaction.TransactionLedger` as acceptances and
    completions happen; lambda and W are computed from the transactions' own
    ``t_accepted``/``t_completed`` stamps.  The two code paths are independent, so
    agreement checks the timestamp bookkeeping.  Exact when the run starts and ends empty.
    """
    if ledger.occ_first_fs is None or ledger.occ_last_fs is None or ledger.occ_last_fs <= ledger.occ_first_fs:
        return {"n": 0}
    dur = ledger.occ_last_fs - ledger.occ_first_fs
    L = ledger.occ_area_fs / dur
    done = [t for t in txns if t.t_accepted is not None and t.t_completed is not None]
    lam = len(done) / dur
    W = float(np.mean([t.t_completed - t.t_accepted for t in done])) if done else float("nan")
    return {"n": len(done), "duration_fs": dur, "L_integrated": L, "lambda_per_fs": lam, "W_fs": W,
            "lambda_W": lam * W, "relative_gap": abs(L - lam * W) / L if L else 0.0,
            "ends_empty": ledger.n_in_system == 0}
