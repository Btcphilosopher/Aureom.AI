"""Program-driven masters: the common engine behind CPU, vector, tensor and traffic workloads.

A master executes a *program* -- an iterable of :class:`MemOp` and :class:`ComputeOp` --
in program order:

* A ``MemOp`` becomes a :class:`~bandwidthlab.transaction.MemTransaction` presented on
  one of the master's *links* (a port into the fabric or directly into a banked SRAM).
  It may be presented when (a) every op it depends on has completed in an earlier cycle,
  (b) its ``not_before`` cycle has been reached, (c) the master has fewer than
  ``max_outstanding`` memory ops in flight and (d) its link is free (valid/ready: a
  presented request is held until accepted).  Address dependencies are real: an op's
  ``addr`` may be a function of the *data returned* by the ops it depends on (pointer
  chasing), so a dependent access can never be issued in parallel with its producer.
* A ``ComputeOp`` occupies the master's compute pipeline for ``cycles`` cycles once its
  dependencies are satisfied.
* ``issue_model='in_order'``: one in-order stream (a core).  With ``overlap_compute``
  later ops keep issuing while a compute op *runs*; a compute op still *waiting* for
  operands blocks everything behind it.
  ``issue_model='dae'``: decoupled access/execute (accelerators): memory ops and compute
  ops form two in-order streams coupled only by their dependencies, so loads for later
  blocks run ahead of a compute op that waits for earlier operands.

Cycle rules (identical everywhere in BandwidthLab): data that arrives at edge c can be
consumed by a compute op that starts at edge c (occupying cycle c..c+1); a *request*
that depends on something completed at edge c is presented for edge c + 1 at the
earliest (registered valid); a presented request is accepted at the earliest at the
edge it is presented on.

Per-master time is classified, from state transitions (so it is exact even when idle
cycles are skipped), into: compute, memory-dependency stall, outstanding-limit stall,
backpressure stall, waiting (injection schedule) and done.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Iterator, Protocol

from .events import EventType
from .scheduler import PRIO_COMPLETE, PRIO_SAMPLE, Scheduler
from .transaction import MemTransaction, TransactionLedger, TxnKind, TxnState, TxnStatus


class TokenBoard:
    """Cross-unit synchronisation (fetch -> execute, DMA tile -> compute, compute -> store).

    A token is posted once, at the cycle the producing operation completed; a waiting op
    may start from the next cycle (the same rule as data dependencies).  Waiters are
    woken through their domain drivers.
    """

    def __init__(self) -> None:
        self.done: dict[str, int] = {}
        self.drivers: list[Any] = []

    def post(self, token: str, cycle: int) -> None:
        if token in self.done:
            raise ValueError(f"token {token!r} posted twice")
        self.done[token] = cycle
        for d in self.drivers:
            d.wake()

    def ready(self, token: str, cycle: int, inclusive: bool = False) -> bool:
        c = self.done.get(token)
        return c is not None and (c <= cycle if inclusive else c < cycle)

    def register(self, drv: Any) -> None:
        if drv not in self.drivers:
            self.drivers.append(drv)


@dataclass
class MemOp:
    kind: TxnKind
    addr: int | Callable[[dict[int, MemTransaction]], int]
    size: int
    deps: tuple[int, ...] = ()
    data: int | None = None
    byte_enable: int | None = None
    words: list[int] | None = None          # explicit word list (gather/scatter on a direct SRAM link)
    word_data: list[int] | None = None
    useful_bytes: int | None = None
    not_before: int = 0                     # earliest issue cycle (relative to master start)
    tag: str = ""
    link: str = "default"
    priority: int = 0
    on_complete: Callable[[MemTransaction], None] | None = None   # e.g. a DMA doorbell write
    wait: tuple[str, ...] = ()              # tokens that must have been posted (TokenBoard)
    post: str | None = None                 # token posted when this op completes


@dataclass
class ComputeOp:
    cycles: int
    deps: tuple[int, ...] = ()
    useful_ops: int = 0                     # useful operations performed (MACs, lane-ops)
    capacity_ops: int = 0                   # peak operations the unit could have performed in `cycles`
    tag: str = ""
    not_before: int = 0
    wait: tuple[str, ...] = ()
    post: str | None = None
    on_complete: Callable[[], None] | None = None


Op = MemOp | ComputeOp


class Link(Protocol):
    name: str

    def can_present(self, cyc: int) -> bool: ...
    def present(self, txn: MemTransaction) -> None: ...
    def poll_response(self, cyc: int) -> MemTransaction | None: ...
    def bind(self, master: "ProgramMaster") -> None: ...


class SramPortLink:
    """A dedicated port of a :class:`~bandwidthlab.sram.BankedSram` (accelerator-local memory)."""

    def __init__(self, sram: Any, port: int, name: str | None = None) -> None:
        self.sram, self.port = sram, port
        self.name = name or f"{sram.name}.p{port}"
        self.master: ProgramMaster | None = None

    def bind(self, master: "ProgramMaster") -> None:
        self.master = master
        self.sram.set_accept_callback(self.port, self._accepted)

    def can_present(self, cyc: int) -> bool:
        return self.sram.can_present(self.port)

    def present(self, txn: MemTransaction) -> None:
        for st in (TxnState.ENQUEUED, TxnState.QUEUE_HEAD, TxnState.GRANTED):
            pass                                  # a direct port has no fabric queue or arbiter stage
        self.sram.present(self.port, txn)

    def _accepted(self, txn: MemTransaction, cyc: int) -> None:
        assert self.master is not None
        self.master.on_link_accept(self, txn, cyc)

    def poll_response(self, cyc: int) -> MemTransaction | None:
        t = self.sram.peek_response(self.port, cyc)
        if t is None:
            return None
        return self.sram.pop_response(self.port, cyc)


@dataclass
class _OpState:
    op: Op
    oid: int
    eligible_cycle: int | None = None
    issued: bool = False
    done_cycle: int | None = None
    txn: MemTransaction | None = None


STATES = ("waiting", "active", "compute", "mem_stall", "store_stall", "outstanding_stall", "backpressure", "done")
STALL_STATES = ("mem_stall", "store_stall", "outstanding_stall", "backpressure")


class ProgramMaster:
    kind = "master"
    rank = 2

    def __init__(self, sched: Scheduler, *, name: str, domain: str, program: Iterable[Op],
                 links: dict[str, Link], max_outstanding: int = 1, overlap_compute: bool = True,
                 issue_model: str = "in_order",
                 ledger: TransactionLedger | None = None, start_cycle: int = 0,
                 lookahead: int = 1_000_000, on_done: Callable[["ProgramMaster"], None] | None = None,
                 record_txns: bool = True, tokens: TokenBoard | None = None) -> None:
        if max_outstanding < 1:
            raise ValueError(f"{name}: max_outstanding must be >= 1")
        self.sched, self.name, self.domain = sched, name, domain
        self.drv = sched.driver(domain)
        self.clock = self.drv.clock
        self.links = links
        self.max_out = max_outstanding
        if issue_model not in ("in_order", "dae"):
            raise ValueError(f"{name}: issue_model must be in_order or dae")
        self.issue_model = issue_model
        self.overlap_compute = overlap_compute
        self.ledger = ledger
        self.start_cycle = start_cycle
        self.lookahead = lookahead
        self.on_done = on_done
        self.tokens = tokens
        if tokens is not None:
            tokens.register(self.drv)
        self._prog: Iterator[Op] = iter(program)
        self._prog_done = False
        self.ops: dict[int, _OpState] = {}
        # not yet issued/started, program order; dae: [memory stream, compute stream]
        self.streams: list[deque[_OpState]] = [deque()] if issue_model == "in_order" else [deque(), deque()]
        self._n_window = 0
        self.next_oid = 0
        self.outstanding_n = 0
        self.presented: dict[str, MemTransaction] = {}  # link -> held request
        self.compute_busy_until: int | None = None     # cycle at which the running compute finishes
        self._issued_this_edge = 0
        self._stall_emitted = False
        self.completed_txns: list[MemTransaction] = [] if record_txns else []
        self.record_txns = record_txns
        self.n_mem_done = 0
        self.n_compute_done = 0
        self.useful_ops = 0
        self.capacity_ops = 0
        self.compute_cycles = 0
        self.bytes_read = 0
        self.bytes_written = 0
        self.useful_bytes = 0
        self.errors = 0
        self.state = "waiting"
        self.state_since = start_cycle
        self.time_in: dict[str, int] = {s: 0 for s in STATES}
        self.first_issue_cycle: int | None = None
        self.finish_cycle: int | None = None
        self._last_head_block = ""
        self._wake_at: set[int] = set()
        for ln in links.values():
            ln.bind(self)
        self.drv.attach(self)
        sched.register(self)
        self._refill()
        self.drv.wake(self.clock.edge(start_cycle))

    # ------------------------------------------------------------------ program window
    def _refill(self) -> None:
        while not self._prog_done and self._n_window < self.lookahead:
            try:
                op = next(self._prog)
            except StopIteration:
                self._prog_done = True
                break
            st = _OpState(op, self.next_oid)
            for d in op.deps:
                if d >= self.next_oid or d < 0:
                    raise ValueError(f"{self.name}: op {self.next_oid} depends on non-earlier op {d}")
            self.ops[self.next_oid] = st
            self.next_oid += 1
            si = 0 if (self.issue_model == "in_order" or isinstance(op, MemOp)) else 1
            self.streams[si].append(st)
            self._n_window += 1

    @property
    def finished(self) -> bool:
        return (self._prog_done and self._n_window == 0 and self.outstanding_n == 0 and not self.presented
                and self.compute_busy_until is None)

    def outstanding(self) -> int:
        """Work this master still owes (deadlock detection): in-flight + unissued ops + running compute."""
        return (self.outstanding_n + self._n_window + (1 if self.compute_busy_until is not None else 0)
                + (0 if self._prog_done else 1))

    def busy(self) -> bool:
        if self.presented:
            return True
        cyc = self.drv.cycle()
        for stream in self.streams:
            if not stream:
                continue
            head = stream[0]
            if self._deps_ready(head.op, cyc + 1) and self._not_before_ok(head.op, cyc + 1) and \
                    (isinstance(head.op, ComputeOp) or self.outstanding_n < self.max_out):
                return True
        return False

    # ------------------------------------------------------------------ helpers
    def _deps_ready(self, op: Op, cyc: int) -> bool:
        # compute may start on the edge its operand arrives; a request needs the next edge
        incl = isinstance(op, ComputeOp)
        if op.wait:
            if self.tokens is None:
                raise RuntimeError(f"{self.name}: op waits on tokens but no TokenBoard was given")
            for tk in op.wait:
                if not self.tokens.ready(tk, cyc, incl):
                    return False
        for d in op.deps:
            s = self.ops.get(d)
            if s is None or s.done_cycle is None or (s.done_cycle > cyc if incl else s.done_cycle >= cyc):
                return False
        return True

    def _not_before_ok(self, op: Op, cyc: int) -> bool:
        return cyc >= self.start_cycle + op.not_before

    def _set_state(self, new: str, cyc: int, anticipated: bool = False) -> None:
        if new == self.state:
            return
        self.time_in[self.state] += max(0, cyc - self.state_since)
        if self.state in STALL_STATES and self._stall_emitted and cyc > self.state_since:
            self.sched.emit(EventType.STALL_ENDED, domain=self.domain, src=self.name, dst=self.name,
                            payload={"reason": self.state, "start_cycle": self.state_since, "end_cycle": cyc,
                                     "cycles": cyc - self.state_since})
        self._stall_emitted = False
        self.state, self.state_since = new, cyc
        if new in STALL_STATES:
            if anticipated:
                # emitted at that edge only if the stall really persists into cycle `cyc`
                self.sched.schedule_at(self.clock.edge(cyc), lambda s=new, c=cyc: self._confirm_stall(s, c),
                                       PRIO_SAMPLE, f"{self.name}.stall_check")
            else:
                self._emit_stall_start(new, cyc)

    def _confirm_stall(self, state: str, cyc: int) -> None:
        if self.state == state and self.state_since == cyc and not self._stall_emitted:
            self._emit_stall_start(state, cyc)

    def _emit_stall_start(self, state: str, cyc: int) -> None:
        self._stall_emitted = True
        self.sched.emit(EventType.STALL_STARTED, domain=self.domain, src=self.name, dst=self.name,
                        payload={"reason": state, "start_cycle": cyc}, dep_state=self._last_head_block or "n/a")

    # ------------------------------------------------------------------ link callbacks
    def on_link_accept(self, link: Link, txn: MemTransaction, cyc: int) -> None:
        held = self.presented.get(link.name)
        if held is txn:
            del self.presented[link.name]
        if txn.meta.get("posted"):
            self._complete(txn, cyc, posted=True)

    # ------------------------------------------------------------------ phases
    def on_response(self, cyc: int) -> None:
        for ln in self.links.values():
            t = ln.poll_response(cyc)
            if t is not None:
                self._complete(t, cyc)

    def _complete(self, t: MemTransaction, cyc: int, posted: bool = False) -> None:
        now = self.sched.now
        if posted:
            for st in (TxnState.RESPONSE,):
                if t.state < st:
                    t.advance(st, now)
        t.advance(TxnState.COMPLETED, now)
        if t.status == TxnStatus.PENDING:
            t.status = TxnStatus.OK
        if t.status != TxnStatus.OK:
            self.errors += 1
        if self.ledger is not None:
            self.ledger.on_completed(t, now)
        self.sched.emit(EventType.RESPONSE_ACCEPTED, domain=self.domain, txn=t, src=t.dst or "target", dst=self.name,
                        payload={"error": t.status != TxnStatus.OK, "posted": posted})
        oid = t.meta["oid"]
        st = self.ops[oid]
        st.done_cycle = cyc
        self.outstanding_n -= 1
        self.n_mem_done += 1
        if t.op == "R":
            self.bytes_read += t.size
        else:
            self.bytes_written += t.size
        self.useful_bytes += t.useful_bytes or 0
        if self.record_txns:
            self.completed_txns.append(t)
        if isinstance(st.op, MemOp) and st.op.on_complete is not None:
            st.op.on_complete(t)
        if st.op.post is not None and self.tokens is not None:
            self.tokens.post(st.op.post, cyc)
        self.drv.wake()

    def on_issue(self, cyc: int) -> None:
        self._refill()
        used_links: set[str] = set(self.presented)
        blocks: list[str] = []
        order = range(len(self.streams)) if self.issue_model == "in_order" else (1, 0)   # dae: compute first
        for si in order:
            stream = self.streams[si]
            block = ""
            while stream:
                head = stream[0]
                op = head.op
                if not self._not_before_ok(op, cyc):
                    block = "waiting"
                    self._schedule_wake(self.start_cycle + op.not_before)
                    break
                if not self._deps_ready(op, cyc):
                    block = self._wait_kind(op)
                    break
                if head.eligible_cycle is None:
                    head.eligible_cycle = cyc
                if isinstance(op, ComputeOp):
                    if self.compute_busy_until is not None:
                        block = "compute_busy"
                        break
                    self._start_compute(head, cyc)
                    stream.popleft()
                    self._n_window -= 1
                    if self.issue_model == "in_order" and not self.overlap_compute:
                        block = "compute_blocking"
                        break
                    continue
                if self.issue_model == "in_order" and not self.overlap_compute and self.compute_busy_until is not None:
                    block = "compute_blocking"
                    break
                if self.outstanding_n >= self.max_out:
                    block = "outstanding_stall"
                    break
                ln = self.links.get(op.link)
                if ln is None:
                    raise KeyError(f"{self.name}: op uses unknown link {op.link!r}")
                if op.link in used_links or not ln.can_present(cyc):
                    block = "backpressure"
                    break
                self._issue(head, ln, cyc)
                used_links.add(op.link)
                stream.popleft()
                self._n_window -= 1
                self._refill()
            blocks.append(block)
        # the compute stream's reason dominates for accelerators (is the datapath starved?)
        self._last_head_block = blocks[0] if blocks else ""

    def _wait_kind(self, op: Op) -> str:
        if op.wait and self.tokens is not None and any(self.tokens.done.get(t) is None for t in op.wait):
            return "mem_stall"
        for d in op.deps:
            s = self.ops.get(d)
            if s is not None and isinstance(s.op, MemOp) and s.done_cycle is None:
                return "store_stall" if s.op.kind.op == "W" else "mem_stall"
        return "compute_dep"

    def _waits_on_memory(self, op: Op) -> bool:
        if op.wait and self.tokens is not None and any(self.tokens.done.get(t) is None for t in op.wait):
            return True
        for d in op.deps:
            s = self.ops.get(d)
            if s is not None and isinstance(s.op, MemOp) and (s.done_cycle is None):
                return True
        return False

    def _schedule_wake(self, cycle: int) -> None:
        if cycle in self._wake_at:
            return
        self._wake_at.add(cycle)
        self.drv.wake(self.clock.edge(cycle))

    def _issue(self, st: _OpState, ln: Link, cyc: int) -> None:
        op: MemOp = st.op  # type: ignore[assignment]
        now = self.sched.now
        addr = op.addr
        if callable(addr):
            addr = int(addr({d: self.ops[d].txn for d in op.deps if self.ops[d].txn is not None}))
        t_created = self.clock.edge(st.eligible_cycle if st.eligible_cycle is not None else cyc)
        tid = self.sched.new_id()
        t = MemTransaction.new(tid, self.name, op.kind, addr, op.size, min(t_created, now), data=op.data,
                               byte_enable=op.byte_enable, priority=op.priority,
                               deps=tuple(self.ops[d].txn.tid for d in op.deps
                                          if self.ops[d].txn is not None),
                               domain=self.domain, useful_bytes=op.useful_bytes)
        t.meta["oid"] = st.oid
        t.meta["tag"] = op.tag
        if op.words is not None:
            t.meta["words"] = list(op.words)
            if op.word_data is not None:
                t.meta["word_data"] = list(op.word_data)
        st.txn = t
        st.issued = True
        self._issued_this_edge += 1
        if self.ledger is not None:
            self.ledger.on_generated(t)
            if not self.ledger.deps_satisfied(t, now):
                raise RuntimeError(f"{self.name}: tid {tid} issued before its dependencies completed")
        self.sched.emit(EventType.REQUEST_GENERATED, domain=self.domain, txn=t, src=self.name, dst=ln.name,
                        payload={"addr": addr, "size": op.size, "kind": op.kind.value, "tag": op.tag},
                        dep_state=("deps:" + ",".join(str(x) for x in t.deps)) if t.deps else "none")
        t.advance(TxnState.ISSUED, now)
        self.sched.emit(EventType.REQUEST_ISSUED, domain=self.domain, txn=t, src=self.name, dst=ln.name)
        self.outstanding_n += 1
        if self.first_issue_cycle is None:
            self.first_issue_cycle = cyc
        self.presented[ln.name] = t
        ln.present(t)

    def _start_compute(self, st: _OpState, cyc: int) -> None:
        op: ComputeOp = st.op  # type: ignore[assignment]
        if op.cycles < 0:
            raise ValueError(f"{self.name}: negative compute duration")
        end = cyc + op.cycles
        self.compute_busy_until = end
        self.sched.emit(EventType.COMPUTE_STARTED, domain=self.domain, src=self.name, dst=self.name,
                        payload={"oid": st.oid, "cycles": op.cycles, "tag": op.tag, "useful_ops": op.useful_ops},
                        dep_state="deps:" + ",".join(str(d) for d in op.deps) if op.deps else "none")
        self.useful_ops += op.useful_ops
        self.capacity_ops += op.capacity_ops
        self.compute_cycles += op.cycles

        def finish(st: _OpState = st, end: int = end) -> None:
            st.done_cycle = end
            self.compute_busy_until = None
            self.n_compute_done += 1
            self.sched.emit(EventType.COMPUTE_COMPLETED, domain=self.domain, src=self.name, dst=self.name,
                            payload={"oid": st.oid, "tag": st.op.tag})
            if st.op.post is not None and self.tokens is not None:
                self.tokens.post(st.op.post, end)
            if st.op.on_complete is not None:
                st.op.on_complete()
            self.drv.wake()
        if op.cycles == 0:
            finish(st, cyc)
        else:
            self.sched.schedule_at(self.clock.edge(end), finish, PRIO_COMPLETE, f"{self.name}.compute_done")

    def _classify(self, cyc: int, block: str) -> None:
        """Classify cycle ``cyc`` (called in the POST phase, after acceptance decisions)."""
        if self.finished:
            if self.finish_cycle is None:
                self.finish_cycle = cyc
                self._set_state("done", cyc)
                if self.on_done is not None:
                    self.on_done(self)
            return
        if self.compute_busy_until is not None:
            new = "compute"
        elif self.presented:
            new = "backpressure"                 # valid held, not accepted this edge
        elif self._issued_this_edge:
            new = "active"
        elif block == "outstanding_stall":
            new = "outstanding_stall"
        elif block == "waiting":
            new = "waiting"
        elif block == "store_stall":
            new = "store_stall"
        elif block in ("mem_stall", "compute_dep") or self.outstanding_n > 0:
            new = "mem_stall"
        else:
            new = "waiting"
        self._set_state(new, cyc)
        if new == "active":
            # one productive cycle; what follows (if this domain sleeps) is decided now
            nxt = "mem_stall" if self.outstanding_n > 0 else "waiting"
            if self.outstanding_n >= self.max_out:
                nxt = "outstanding_stall"
            self._set_state(nxt, cyc + 1, anticipated=True)

    def on_post(self, cyc: int) -> None:
        self._classify(cyc, self._last_head_block)
        self._issued_this_edge = 0

    # ------------------------------------------------------------------ results
    def close(self, end_cycle: int) -> None:
        """Account the open state interval up to ``end_cycle`` (call after the run)."""
        if self.state_since < end_cycle and self.state != "done":
            self.time_in[self.state] += end_cycle - self.state_since
            self.state_since = end_cycle

    def stats(self) -> dict:
        span = (self.finish_cycle - self.start_cycle) if self.finish_cycle is not None else None
        return {
            "name": self.name, "finished": self.finished, "finish_cycle": self.finish_cycle,
            "span_cycles": span, "mem_ops": self.n_mem_done, "compute_ops": self.n_compute_done,
            "bytes_read": self.bytes_read, "bytes_written": self.bytes_written, "useful_bytes": self.useful_bytes,
            "useful_ops": self.useful_ops, "capacity_ops": self.capacity_ops, "compute_cycles": self.compute_cycles,
            "time_in_state": dict(self.time_in), "errors": self.errors,
        }
