"""Units for BandwidthLab.

Re-exports MemoryLab's checked operation units (``memorylab.units``) and adds the
time / bandwidth conversions BandwidthLab needs.

Conventions
-----------
* Simulation time is an integer number of femtoseconds (fs), the time base of
  ``memorylab.event_engine``.  Every clock domain converts cycles <-> fs exactly
  when its period is a whole number of fs (the quantisation error is recorded).
* Bytes are 8-bit octets.  KiB = 1024 B.  GB/s = 1e9 B/s (decimal), GiB/s =
  2**30 B/s (binary).  Both are always labelled.
* A bandwidth computed from a clock frequency is only meaningful together with the
  clock domain it refers to; helper functions therefore take the frequency
  explicitly and never guess it.
"""
from __future__ import annotations

import math

from memorylab.units import (GB, KiB, MiB, OpConvention, OpCount, OpKind, Precision, Throughput,  # noqa: F401
                             UnitMismatchError, bytes_human, parse_size, si)

FS_PER_S = 10 ** 15
FS_PER_NS = 10 ** 6
GiB = 1024 ** 3
GBps = 1e9          # bytes per second in one GB/s (decimal)
GiBps = float(GiB)  # bytes per second in one GiB/s (binary)


def peak_link_bandwidth_Bps(data_width_bits: int, clock_hz: float, transfers_per_cycle: float = 1.0,
                            ports: int = 1) -> float:
    """Ideal upper bound B_peak = (DATA_WIDTH / 8) x f x transfers/cycle x ports  [bytes/s].

    This is an upper bound for a bus that moves one full-width beat per transfer
    slot; it is *not* a sustained throughput.
    """
    if data_width_bits <= 0 or data_width_bits % 8:
        raise ValueError("data width must be a positive multiple of 8 bits")
    if not (math.isfinite(clock_hz) and clock_hz > 0):
        raise ValueError("clock frequency must be > 0 Hz")
    if transfers_per_cycle <= 0 or ports < 1:
        raise ValueError("transfers_per_cycle > 0 and ports >= 1")
    return (data_width_bits / 8) * clock_hz * transfers_per_cycle * ports


def to_GBps(bytes_per_s: float) -> float:
    return bytes_per_s / GBps


def to_GiBps(bytes_per_s: float) -> float:
    return bytes_per_s / GiBps


def bytes_per_cycle_to_Bps(bpc: float, clock_hz: float) -> float:
    return bpc * clock_hz


def cycles_to_ns(cycles: float, clock_hz: float) -> float:
    return cycles * 1e9 / clock_hz


def fs_to_ns(t_fs: int | float) -> float:
    return t_fs / FS_PER_NS


def fmt_bw(bytes_per_s: float) -> str:
    """'1.600 GB/s (1.490 GiB/s)' — both units, always labelled."""
    return f"{to_GBps(bytes_per_s):.4g} GB/s ({to_GiBps(bytes_per_s):.4g} GiB/s)"


def ceil_div(a: int, b: int) -> int:
    if b <= 0:
        raise ValueError("division by non-positive number")
    return -(-a // b)


def is_pow2(n: int) -> bool:
    return n >= 1 and (n & (n - 1)) == 0
