"""Scientific figures (Plotly) built ONLY from files a BandwidthLab run wrote.

Visual identity: midnight-navy surface, metallic-gold / electric-cyan accents, violet,
white technical typography.  The categorical data palette below was validated with the
dataviz validator against the navy surface (#0b1426): lightness band, chroma floor,
adjacent-pair CVD separation (worst dE 9.2), normal-vision floor (worst dE 18.3) and 3:1
contrast all PASS.  Data marks use these steps; the brighter brand gold/cyan are used only
for chrome (titles, rules), never for text-as-data.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

SURFACE = "#0b1426"
SURFACE_2 = "#121f38"
GRID = "#1f2d4a"
TEXT = "#f2f4f8"
TEXT_2 = "#b9c2d3"
TEXT_3 = "#7f8aa3"
GOLD_CHROME = "#d4af37"
CYAN_CHROME = "#22d3ee"
SERIES = ["#b08620", "#0891b2", "#8b6cf0", "#df5a3a", "#5b8def", "#2b9348", "#cf4a95"]   # validated order
SEQ = [[0.0, "#0e1a30"], [0.25, "#0b3a56"], [0.5, "#0a6684"], [0.75, "#0891b2"], [1.0, "#5fe0f5"]]
STATUS = {"pass": "#2b9348", "fail": "#df5a3a", "warn": "#b08620"}
FONT = "Inter, 'IBM Plex Sans', system-ui, sans-serif"
MONO = "'JetBrains Mono', 'IBM Plex Mono', ui-monospace, monospace"


def style(fig: go.Figure, title: str, subtitle: str = "", height: int = 420) -> go.Figure:
    fig.update_layout(
        template="plotly_dark", paper_bgcolor=SURFACE, plot_bgcolor=SURFACE, height=height,
        font=dict(family=FONT, color=TEXT_2, size=12),
        title=dict(text=f"<b>{title}</b>" + (f"<br><span style='font-size:12px;color:{TEXT_3}'>{subtitle}</span>"
                                             if subtitle else ""), font=dict(color=TEXT, size=16), x=0.01),
        margin=dict(l=64, r=24, t=72 if subtitle else 52, b=56), barcornerradius=4, bargap=0.35,
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(color=TEXT_2), orientation="h", y=-0.18),
        hoverlabel=dict(bgcolor=SURFACE_2, bordercolor=GRID, font=dict(family=MONO, color=TEXT)),
        colorway=SERIES)
    fig.update_xaxes(gridcolor=GRID, gridwidth=1, zeroline=False, linecolor=GRID, tickfont=dict(family=MONO))
    fig.update_yaxes(gridcolor=GRID, gridwidth=1, zeroline=False, linecolor=GRID, tickfont=dict(family=MONO))
    return fig


def _load(p: Path) -> Any:
    return json.loads(p.read_text()) if p.exists() else None


class RunData:
    """Lazy access to the files of a run directory (reports/bandwidthlab/<run>)."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root)

    def exp(self) -> dict | None:
        d = _load(self.root / "experiments" / "experiments.json")
        return d["result"] if d else None

    def sweep(self) -> list | None:
        return _load(self.root / "sweeps" / "bandwidth_sweep.json")

    def pareto(self) -> list | None:
        return _load(self.root / "sweeps" / "bandwidth_sweep_pareto.json")

    def marginal(self) -> list | None:
        return _load(self.root / "sweeps" / "bandwidth_sweep_marginal_gains.json")

    def cal(self) -> dict | None:
        return _load(self.root / "calibration" / "calibration.json")

    def run(self) -> dict | None:
        return _load(self.root / "run_001" / "results.json")

    def lat(self) -> pd.DataFrame | None:
        p = self.root / "run_001" / "latency_decomposition.csv"
        return pd.read_csv(p) if p.exists() else None

    def events(self) -> pd.DataFrame | None:
        p = self.root / "run_001" / "events.csv"
        return pd.read_csv(p) if p.exists() else None

    def qos(self) -> dict | None:
        d = _load(self.root / "qos" / "qos.json")
        return d["result"] if d else None


# ---------------------------------------------------------------------------- the 14 figures
def fig_bw_latency(d: RunData) -> go.Figure | None:
    e = d.exp()
    if not e or "H" not in e:
        return None
    fig = go.Figure()
    short = {"1 target bank, finite queue (backpressure)": "1 bank · finite queue",
             "1 target bank, unbounded source queue": "1 bank · unbounded queue",
             "1 target bank, drop when full": "1 bank · drop when full",
             "8 interleaved banks, finite queue": "8 interleaved banks · finite queue"}
    symbols = ["circle", "diamond", "square", "triangle-up"]
    for i, (lab, c) in enumerate(e["H"]["curves"].items()):
        pts = c["points"]
        fig.add_trace(go.Scatter(x=[p["completed_per_cycle"] for p in pts], y=[p["lat_p99"] for p in pts],
                                 mode="lines+markers", name=short.get(lab, lab),
                                 line=dict(width=2, color=SERIES[i], dash="dot" if "drop" in lab else "solid"),
                                 marker=dict(size=9 if "drop" not in lab else 7, symbol=symbols[i % 4],
                                             line=dict(width=2, color=SURFACE)),
                                 customdata=[[p["offered_rate"], p["lat_mean"], p["queue_max"]] for p in pts],
                                 hovertemplate="completed %{x:.3f} req/cycle<br>P99 %{y:.1f} cycles<br>offered "
                                               "%{customdata[0]} req/cycle/master<br>mean %{customdata[1]:.2f}"
                                               "<br>max queue %{customdata[2]}<extra>%{fullData.name}</extra>"))
    fig.update_yaxes(type="log", title="P99 latency (cycles, log)")
    fig.update_xaxes(title="completed throughput (req/cycle)")
    fig = style(fig, "Bandwidth versus latency", "Experiment H · 3 masters, Bernoulli arrivals, 4-byte accesses · "
                "drop and backpressure coincide (memoryless source) · EVENT_SIMULATED", height=460)
    fig.update_layout(legend=dict(y=-0.22), margin=dict(b=96))
    return fig


def fig_latency_dist(d: RunData) -> go.Figure | None:
    lat = d.lat()
    if lat is None or lat.empty:
        return None
    fig = go.Figure()
    masters = [m for m in ["cpu_d", "cpu_i", "cpu_bg", "dma", "te", "ve"] if m in set(lat["master"])]
    for i, m in enumerate(masters):
        v = np.sort(lat.loc[lat["master"] == m, "total_cycles"].to_numpy())
        y = np.arange(1, v.size + 1) / v.size
        fig.add_trace(go.Scatter(x=v, y=y, mode="lines", name=f"{m} (n={v.size})", line=dict(width=2, color=SERIES[i],
                                 shape="hv"), hovertemplate="%{x:.0f} cycles · %{y:.3f}<extra>" + m + "</extra>"))
    for q in (0.5, 0.95, 0.99):
        fig.add_hline(y=q, line=dict(color=TEXT_3, width=1), annotation_text=f"P{int(q * 100)}",
                      annotation_font=dict(color=TEXT_3, size=10), annotation_position="right")
    fig.update_xaxes(type="log", title="end-to-end latency (fabric cycles, log)")
    fig.update_yaxes(title="cumulative fraction", range=[0, 1.02])
    return style(fig, "Latency distributions (mean and tail)", "run_001 · SilicaFlux-V tile pipeline · ECDF per "
                 "master")


def fig_master_bw(d: RunData) -> go.Figure | None:
    r = d.run()
    if not r:
        return None
    ms = r["results"]["interconnect"]["masters"]
    ms = [m for m in ms if m["grants"] > 0]
    fig = go.Figure(go.Bar(x=[m["master"] for m in ms], y=[m["bytes_per_cycle"] for m in ms], marker_color=SERIES[1],
                           text=[f"{m['bytes_per_cycle']:.2f}" for m in ms], textposition="outside",
                           textfont=dict(color=TEXT_2, family=MONO),
                           hovertemplate="%{x}: %{y:.3f} B/cycle<extra></extra>", width=0.5))
    fig.update_yaxes(title="bytes per fabric cycle")
    return style(fig, "Per-master fabric bandwidth", "run_001 · bytes accepted by the DataFabric per cycle of the "
                 "observation window")


def fig_bank_util(d: RunData) -> go.Figure | None:
    r = d.run()
    if not r:
        return None
    fig = go.Figure()
    names, util, conf = [], [], []
    for name, s in r["results"]["srams"].items():
        for b in s["banks"]:
            names.append(f"{name}.b{b['bank']}" if len(s["banks"]) > 1 else name)
            util.append(b["utilisation"])
            conf.append(b["conflicts"])
    fig.add_trace(go.Bar(x=names, y=util, marker_color=SERIES[0], width=0.5, customdata=conf,
                         hovertemplate="%{x}: %{y:.1%} busy · %{customdata} conflict word-cycles<extra></extra>"))
    fig.update_yaxes(title="busy cycles / window", tickformat=".0%")
    return style(fig, "Per-bank SRAM utilisation", "run_001 · every bank instance (fabric-split SRAM banks and "
                 "internally banked TSPM)")


def fig_dma_timeline(d: RunData) -> go.Figure | None:
    ev = d.events()
    if ev is None or ev.empty:
        return None
    st = ev[ev["etype"] == "DMA_DESCRIPTOR_STARTED"]
    en = ev[ev["etype"] == "DMA_DESCRIPTOR_COMPLETED"]
    if st.empty:
        return None
    sp = [json.loads(p) for p in st["payload"]]
    ep = {json.loads(p)["did"]: c for p, c in zip(en["payload"], en["cycle"])}
    rows = []
    for (cyc, p) in zip(st["cycle"], sp):
        if p["did"] in ep:
            rows.append((p["did"], p.get("label", ""), cyc, ep[p["did"]], p["bytes"]))
    rows = rows[:120]
    fig = go.Figure()
    kinds = {"in": SERIES[1], "out": SERIES[0]}
    for kind, col in kinds.items():
        rr = [r for r in rows if r[1].startswith(kind)]
        fig.add_trace(go.Bar(x=[r[3] - r[2] for r in rr], y=[r[1] for r in rr], base=[r[2] for r in rr],
                             orientation="h", marker_color=col, name="staging into TSPM" if kind == "in" else
                             "write-back to SRAM", customdata=[[r[4], r[2], r[3]] for r in rr],
                             hovertemplate="%{y}: %{customdata[0]} B · cycles %{customdata[1]}–%{customdata[2]}"
                                           "<extra></extra>"))
    fig.update_xaxes(title="fabric cycle")
    fig.update_yaxes(title="descriptor", autorange="reversed", showticklabels=False)
    fig.update_layout(bargap=0.15)
    return style(fig, "DMA transfer timeline", "run_001 · descriptors from DMA_DESCRIPTOR_STARTED/COMPLETED events "
                 "(first 120)", height=480)


def fig_queue_occupancy(d: RunData) -> go.Figure | None:
    e = d.exp()
    if not e or "H" not in e:
        return None
    fig = go.Figure()
    for i, (lab, c) in enumerate(e["H"]["curves"].items()):
        pts = c["points"]
        fig.add_trace(go.Scatter(x=[p["offered_rate"] for p in pts], y=[p["queue_mean"] for p in pts],
                                 mode="lines+markers", name=lab, line=dict(width=2, color=SERIES[i]),
                                 marker=dict(size=8, line=dict(width=2, color=SURFACE)),
                                 hovertemplate="offered %{x}<br>mean source queue %{y:.2f}<extra>%{fullData.name}"
                                               "</extra>"))
    fig.update_yaxes(type="log", title="mean source-queue occupancy (requests, log)")
    fig.update_xaxes(title="offered load per master (requests/cycle)")
    return style(fig, "Queue occupancy versus offered load", "Experiment H · finite queues saturate at their depth;"
                 " the unbounded queue grows without limit")


def fig_contention_heatmap(d: RunData) -> go.Figure | None:
    r = d.run()
    if not r:
        return None
    cm = r["results"]["interconnect"]["conflict_matrix"]
    gm = r["results"]["interconnect"]["grant_matrix"]
    masters = sorted({k.split("->")[0] for k in gm})
    targets = sorted({k.split("->")[1] for k in gm})
    z = [[cm.get(f"{m}->{t}", 0) for t in targets] for m in masters]
    g = [[gm.get(f"{m}->{t}", 0) for t in targets] for m in masters]
    fig = go.Figure(go.Heatmap(z=z, x=targets, y=masters, colorscale=SEQ, customdata=g, xgap=2, ygap=2,
                               hovertemplate="%{y} → %{x}<br>arbitration-loss cycles %{z}<br>grants %{customdata}"
                                             "<extra></extra>", colorbar=dict(title="lost cycles")))
    return style(fig, "Contention heatmap", "run_001 · cycles a master requested a target port and lost "
                 "arbitration (or found it busy)")


def fig_bus_saturation(d: RunData) -> go.Figure | None:
    sw = d.sweep()
    if not sw:
        return None
    rows = [r for r in sw if r.get("valid") and r["factor"] in ("bus_width", "baseline")]
    rows = [r for r in rows if r["factor"] == "bus_width"]
    fig = go.Figure()
    fig.add_trace(go.Bar(x=[str(r["value"]) for r in rows], y=[r["fabric_bytes_per_cycle"] for r in rows],
                         name="sustained fabric traffic", marker_color=SERIES[1], width=0.4,
                         hovertemplate="%{x}-bit: %{y:.2f} B/cycle<extra></extra>"))
    fig.add_trace(go.Scatter(x=[str(r["value"]) for r in rows], y=[r["value"] / 8 for r in rows],
                             name="one-link ceiling (W/8 B/cycle, ANALYTICAL)", mode="lines+markers",
                             line=dict(width=2, color=TEXT_3, dash="solid"), marker=dict(size=8)))
    fig.update_xaxes(title="fabric and DMA data width (bits)", type="category")
    fig.update_yaxes(title="bytes per fabric cycle")
    return style(fig, "Bus saturation versus width", "Sweep · tile pipeline · sustained traffic vs single-link "
                 "analytical ceiling")


def fig_accel_util(d: RunData) -> go.Figure | None:
    sw = d.sweep()
    if not sw:
        return None
    rows = [r for r in sw if r.get("valid") and r["factor"] == "tensor_arrayxbus_width"]
    if not rows:
        return None
    fig = go.Figure()
    for i, w in enumerate(["32", "64", "128"]):
        rr = [r for r in rows if str(r["value"]).split("|")[1] == w]
        fig.add_trace(go.Scatter(x=[f"{v}x{v}" for v in [int(str(r['value']).split('|')[0]) for r in rr]],
                                 y=[r["te_mac_util_total"] for r in rr], mode="lines+markers", name=f"{w}-bit fabric",
                                 line=dict(width=2, color=SERIES[i]), marker=dict(size=8, line=dict(width=2,
                                                                                                     color=SURFACE)),
                                 hovertemplate="%{x}: %{y:.1%} MAC utilisation<extra>%{fullData.name}</extra>"))
    fig.update_yaxes(title="MAC utilisation over the whole workload", tickformat=".0%")
    fig.update_xaxes(title="tensor array")
    return style(fig, "Accelerator utilisation", "Sweep · DMA-staged GEMM 32×32×64 INT8 · larger arrays finish "
                 "sooner but idle more")


def fig_stall_breakdown(d: RunData) -> go.Figure | None:
    r = d.run()
    if not r:
        return None
    ms = r["results"]["masters"]
    states = ["compute", "active", "mem_stall", "store_stall", "outstanding_stall", "backpressure", "waiting"]
    names = [n for n in ("cpu_i", "cpu_d", "cpu_bg", "te", "ve") if n in ms]
    fig = go.Figure()
    for i, st in enumerate(states):
        fig.add_trace(go.Bar(y=names, x=[ms[n]["time_in_state"].get(st, 0) for n in names], name=st,
                             orientation="h", marker=dict(color=SERIES[i % len(SERIES)], line=dict(width=2,
                                                                                                  color=SURFACE)),
                             hovertemplate="%{y} · " + st + ": %{x} cycles<extra></extra>"))
    fig.update_layout(barmode="stack")
    fig.update_xaxes(title="cycles")
    return style(fig, "Memory stall breakdown", "run_001 · time each master spent per state (exact, from state "
                 "transitions)")


def fig_before_after(d: RunData) -> go.Figure | None:
    e = d.exp()
    if not e:
        return None
    pick = [("D", "simple (L0)"), ("D", "buffered FIFO 8 burst 8 (L1)"), ("D", "buffered dual-port (L2)"),
            ("C", "64-bit fabric, buffered DMA"), ("G", "8x8, DMA-staged pipeline")]
    rows = []
    for k, lab in pick:
        r = next((x for x in e.get(k, {}).get("rows", []) if x["label"] == lab and x.get("valid")), None)
        if r:
            rows.append((f"{k}: {lab}", r["total_cycles"], r.get("te_mac_util_total", 0)))
    if not rows:
        return None
    fig = make_subplots(rows=1, cols=2, subplot_titles=("workload completion (cycles)", "tensor MAC utilisation"))
    fig.add_trace(go.Bar(y=[r[0] for r in rows], x=[r[1] for r in rows], orientation="h", marker_color=SERIES[1],
                         width=0.5, showlegend=False, hovertemplate="%{y}: %{x} cycles<extra></extra>"), 1, 1)
    fig.add_trace(go.Bar(y=[r[0] for r in rows], x=[r[2] for r in rows], orientation="h", marker_color=SERIES[0],
                         width=0.5, showlegend=False, hovertemplate="%{y}: %{x:.1%}<extra></extra>"), 1, 2)
    fig.update_yaxes(autorange="reversed")
    fig.update_yaxes(showticklabels=False, row=1, col=2)
    fig.update_xaxes(tickformat=".0%", row=1, col=2)
    fig.update_annotations(font=dict(color=TEXT_2, size=12))
    return style(fig, "Before / after optimisation", "Experiments C, D, G · SilicaFlux-V tile pipeline 32×32×64 "
                 "INT8 · EVENT_SIMULATED", height=380)


def fig_pareto(d: RunData) -> go.Figure | None:
    sw, front = d.sweep(), d.pareto()
    if not sw:
        return None
    ok = [r for r in sw if r.get("valid")]
    fl = {r["label"] for r in (front or [])}
    fig = go.Figure()
    others = [r for r in ok if r["label"] not in fl]
    pf = sorted([r for r in ok if r["label"] in fl], key=lambda r: r["cost_index"])
    fig.add_trace(go.Scatter(x=[r["cost_index"] for r in others], y=[r["throughput"] * 1e3 for r in others],
                             mode="markers", name="dominated", marker=dict(size=9, color=SERIES[4], opacity=0.55,
                                                                           line=dict(width=2, color=SURFACE)),
                             text=[r["label"] for r in others],
                             hovertemplate="%{text}<br>cost %{x:.0f} · %{y:.2f} kMAC/cycle<extra></extra>"))
    fig.add_trace(go.Scatter(x=[r["cost_index"] for r in pf], y=[r["throughput"] * 1e3 for r in pf],
                             mode="lines+markers", name="Pareto front (throughput, P99, cost)",
                             line=dict(width=2, color=SERIES[0]), marker=dict(size=10, line=dict(width=2,
                                                                                                  color=SURFACE)),
                             text=[r["label"] for r in pf],
                             hovertemplate="%{text}<br>cost %{x:.0f} · %{y:.2f} kMAC/cycle<extra></extra>"))
    fig.update_xaxes(title="resource cost index (HYPOTHETICAL weights; not area)")
    fig.update_yaxes(title="throughput (useful MAC per 1000 cycles)")
    return style(fig, "Architecture Pareto frontier", "Sweep · 75 variants · non-dominated in throughput, P99 "
                 "latency and cost index")


def fig_rtl_vs_sim(d: RunData) -> go.Figure | None:
    c = d.cal()
    if not c:
        return None
    pts = []
    if "dma" in c:
        for r in c["dma"]["rows"]:
            pts.append(("DMA (recorded RTL)", r["observed_cycles"], r["predicted_cycles"], r["set"],
                        f"{r['config']}{' same-bank' if r['same_bank'] else ''}"))
    eng = c.get("engines", {}).get("engines", {}) if isinstance(c.get("engines"), dict) else {}
    for e, v in eng.items():
        for r in v["rows"]:
            pts.append((f"{e} engine (sfv_tile RTL)", r["observed_cycles"], r["predicted_cycles"], r["set"], r["case"]))
    if not pts:
        return None
    fig = go.Figure()
    groups = sorted({p[0] for p in pts})
    for i, g in enumerate(groups):
        for s, sym in (("calibration", "diamond"), ("holdout", "circle")):
            pp = [p for p in pts if p[0] == g and p[3] == s]
            if not pp:
                continue
            fig.add_trace(go.Scatter(x=[p[1] for p in pp], y=[p[2] for p in pp], mode="markers",
                                     name=f"{g} · {s}", marker=dict(size=9, symbol=sym, color=SERIES[i],
                                                                     line=dict(width=2, color=SURFACE)),
                                     text=[p[4] for p in pp],
                                     hovertemplate="%{text}<br>RTL %{x} · model %{y} cycles<extra></extra>"))
    lo = min(min(p[1], p[2]) for p in pts)
    hi = max(max(p[1], p[2]) for p in pts)
    fig.add_trace(go.Scatter(x=[lo, hi], y=[lo, hi], mode="lines", name="model = RTL",
                             line=dict(width=1, color=TEXT_3)))
    fig.update_xaxes(type="log", title="RTL cycles (observed)")
    fig.update_yaxes(type="log", title="model cycles (predicted)")
    xv, xi = c.get("xbar_verilator", {}), c.get("xbar_iverilog", {})
    sub = ""
    if isinstance(xv, dict) and "rows" in xv:
        n = xv["transactions_compared"] + (xi.get("transactions_compared", 0) if isinstance(xi, dict) else 0)
        ok = xv["all_equivalent"] and (xi.get("all_equivalent", True) if isinstance(xi, dict) else True)
        sub = f"crossbar (not plotted): {n:,} transactions, all cycle-exact: {ok} · "
    return style(fig, "RTL versus simulator", sub + "diamonds = calibration set, circles = holdout")


def fig_provenance(d: RunData) -> go.Figure | None:
    from .config import load_config, provenance_table
    root = Path(__file__).resolve().parents[2] / "configs"
    names = ["silicaflux_v_datafabric_rtl", "silicaflux_v", "silicaflux_mcu_i", "silicaflux_full"]
    classes = ["VERIFIED_REPO", "RTL_SIMULATED", "EXTERNAL_MEASURED", "HYPOTHETICAL"]
    counts = {}
    for n in names:
        p = root / f"{n}.yaml"
        if p.exists():
            rows = provenance_table(load_config(p))
            counts[n] = [sum(1 for r in rows if r["provenance"] == c) for c in classes]
    if not counts:
        return None
    fig = go.Figure()
    for i, c in enumerate(classes):
        fig.add_trace(go.Bar(y=list(counts), x=[v[i] for v in counts.values()], name=c, orientation="h",
                             marker=dict(color=SERIES[[5, 1, 2, 0][i]], line=dict(width=2, color=SURFACE)),
                             hovertemplate="%{y} · " + c + ": %{x} parameters<extra></extra>"))
    fig.update_layout(barmode="stack")
    fig.update_xaxes(title="parameters")
    return style(fig, "Experiment provenance", "parameter provenance per configuration (unlisted parameters count "
                 "as HYPOTHETICAL)", height=360)


FIGURES = {
    "01_bandwidth_vs_latency": fig_bw_latency, "02_latency_distributions": fig_latency_dist,
    "03_per_master_bandwidth": fig_master_bw, "04_sram_bank_utilisation": fig_bank_util,
    "05_dma_timeline": fig_dma_timeline, "06_queue_occupancy": fig_queue_occupancy,
    "07_contention_heatmap": fig_contention_heatmap, "08_bus_saturation": fig_bus_saturation,
    "09_accelerator_utilisation": fig_accel_util, "10_stall_breakdown": fig_stall_breakdown,
    "11_before_after": fig_before_after, "12_pareto_frontier": fig_pareto, "13_rtl_vs_simulator": fig_rtl_vs_sim,
    "14_provenance": fig_provenance,
}


def build_figures(run_dir: Path) -> dict[str, go.Figure]:
    d = RunData(run_dir)
    out = {}
    for name, fn in FIGURES.items():
        try:
            f = fn(d)
        except Exception as e:  # a missing/partial input must not break the other figures
            f = style(go.Figure(), name, f"not available: {type(e).__name__}: {e}")
        if f is not None:
            out[name] = f
    return out


def export_figures(run_dir: Path, figs: dict[str, go.Figure], png: bool = True) -> dict[str, list[str]]:
    """HTML always; PNG through kaleido when it can start a browser (reported otherwise)."""
    fdir = Path(run_dir) / "figures"
    fdir.mkdir(parents=True, exist_ok=True)
    done: dict[str, list[str]] = {"html": [], "png": [], "png_errors": []}
    for name, f in figs.items():
        p = fdir / f"{name}.html"
        f.write_html(p, include_plotlyjs="directory", full_html=True)
        done["html"].append(p.name)
        if png:
            try:
                f.write_image(fdir / f"{name}.png", width=1100, height=f.layout.height or 420, scale=2)
                done["png"].append(f"{name}.png")
            except Exception as e:
                done["png_errors"].append(f"{name}: {type(e).__name__}: {str(e)[:200]}")
    return done
