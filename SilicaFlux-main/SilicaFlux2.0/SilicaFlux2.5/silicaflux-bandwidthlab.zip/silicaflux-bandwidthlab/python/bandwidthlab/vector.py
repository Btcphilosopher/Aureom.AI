"""SIMD vector-engine memory-traffic model.

Reference design: SilicaFlux-V ``sfv_vec_engine`` -- 4 lanes x 32 bit, memory-to-memory over
the tile scratchpad (TSPM, LANES word-interleaved single-port banks), one "beat" = LANES
consecutive elements = one row across the banks; CYCLES = 3 + B*P (+1 DOT with WRES),
P = number of single-port bank accesses per beat (3 vector-vector, 2 DOT/vector-scalar,
1 DOT vector-scalar).  Exploration parameters beyond that design (lanes, element width,
per-lane ports, register capacity, strides, gather/scatter, FIR) are hypothetical.

Each beat (element group of ``lanes`` elements) becomes word-level SRAM accesses:
* ``port_mode='wide'``  one access per operand per beat on one engine port whose width is
  the whole bank row (the SilicaFlux-V arrangement: all banks addressed in one cycle);
  the access is decomposed into words that must each win their bank.
* ``port_mode='per_lane'`` one port per lane; lanes contend for banks through the bank
  arbiter.
Lanes never get free simultaneous access to one single-port bank: words that map to the
same bank are serialised by the SRAM model.

Software pipelining: up to ``groups_in_flight`` beats are loaded ahead of the beat being
computed/stored, bounded by the vector register capacity (``registers`` / registers per
beat), so register capacity directly limits latency hiding.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from .masters import ComputeOp, MemOp, Op
from .transaction import TxnKind
from .units import ceil_div

VECTOR_OPS = ("vadd", "vmul", "vscalar", "dot", "reduce", "strided", "gather", "scatter", "fir")


@dataclass
class VectorConfig:
    name: str = "ve"
    lanes: int = 4
    elem_bits: int = 32
    registers: int = 16                # vector registers available for software pipelining
    overhead_cycles: int = 3           # lock + prologue + final stage (sfv_vec_engine)
    tail_cycles: int = 0
    mul_cycles: int = 1                # compute cycles per beat for multiplies
    alu_cycles: int = 1
    port_mode: str = "wide"            # wide | per_lane
    max_outstanding: int = 4

    def __post_init__(self) -> None:
        if self.lanes < 1 or self.elem_bits not in (8, 16, 32, 64):
            raise ValueError("lanes >= 1 and elem_bits in 8/16/32/64")
        if self.port_mode not in ("wide", "per_lane"):
            raise ValueError("port_mode wide|per_lane")

    @property
    def elem_bytes(self) -> int:
        return self.elem_bits // 8

    def groups_in_flight(self, regs_per_group: int) -> int:
        return max(1, self.registers // max(1, regs_per_group))


@dataclass
class VectorKernel:
    op: str = "vadd"
    n: int = 1024
    a_base: int = 0                    # byte offsets inside the local memory
    b_base: int = 0x1000
    c_base: int = 0x2000
    stride: int = 1                    # in elements (strided op)
    align_offset: int = 0              # bytes added to every base (misalignment study)
    taps: int = 8                      # fir
    seed: int = 1
    wres: bool = True                  # dot/reduce: store the scalar result (sfv_vec_engine CMD.WRES)

    def __post_init__(self) -> None:
        if self.op not in VECTOR_OPS:
            raise ValueError(f"unknown vector op {self.op!r}; one of {VECTOR_OPS}")


def vector_program(cfg: VectorConfig, k: VectorKernel, *, local_base: int, word_bytes: int,
                   links: list[str] | None = None, start_wait: tuple[str, ...] = (), done_token: str | None = None
                   ) -> tuple[list[Op], dict[str, Any]]:
    """Ops for one vector command on a local memory at ``local_base`` with ``word_bytes`` words."""
    L, eb = cfg.lanes, cfg.elem_bytes
    rng = np.random.Generator(np.random.PCG64(k.seed))
    G = ceil_div(k.n, L) if k.n else 0
    if cfg.port_mode == "per_lane":
        links = links or [f"lane{i}" for i in range(L)]
    else:
        links = links or ["vmem"]
    stride = k.stride if k.op == "strided" else 1
    gather_idx = rng.permutation(max(k.n * 4, 1))[: k.n] if k.op in ("gather", "scatter") else None

    def elem_addr(base: int, e: int, indexed: bool = False) -> int:
        idx = int(gather_idx[e]) if (indexed and gather_idx is not None) else e * stride
        return base + k.align_offset + idx * eb

    def accesses(base: int, g: int, indexed: bool = False) -> list[list[int]]:
        """Word lists (array-relative word indices) of one beat, per port."""
        elems = [g * L + i for i in range(L) if g * L + i < k.n]
        words_per_lane = [sorted({(elem_addr(base, e, indexed) + b) // word_bytes for b in range(eb)})
                          for e in elems]
        if cfg.port_mode == "wide":
            return [sorted({w for ws in words_per_lane for w in ws})]
        return words_per_lane

    ops: list[Op] = []

    def mem(kind: TxnKind, words: list[int], link: str, deps: tuple[int, ...], tag: str) -> int:
        ops.append(MemOp(kind, local_base + words[0] * word_bytes, len(words) * word_bytes, deps=deps,
                         words=words, word_data=[0] * len(words) if kind == TxnKind.WRITE else None,
                         useful_bytes=len(words) * word_bytes, tag=tag, link=link))
        return len(ops) - 1

    ops.append(ComputeOp(cfg.overhead_cycles, wait=start_wait, tag="ve_overhead"))
    head = len(ops) - 1
    op = k.op
    two_src = op in ("vadd", "vmul", "dot", "strided")
    has_store = op in ("vadd", "vmul", "vscalar", "strided", "gather", "scatter", "fir")
    regs_per_group = (2 if two_src else 1) + (1 if has_store else 0)
    depth = cfg.groups_in_flight(regs_per_group)
    comp_cycles = cfg.mul_cycles if op in ("vmul", "dot", "fir") else cfg.alu_cycles
    if op == "fir":
        comp_cycles = cfg.mul_cycles * k.taps
    loads: dict[int, list[int]] = {}
    last_store: list[int] = []
    computes: list[int] = []
    prev_compute: int | None = None

    def emit_loads(g: int) -> None:
        ids = []
        gate = (computes[g - depth],) if g - depth >= 0 else (head,)
        srcs = [(k.a_base, op in ("gather",))]
        if two_src:
            srcs.append((k.b_base, False))
        for base, indexed in srcs:
            for li, ws in enumerate(accesses(base, g, indexed)):
                ids.append(mem(TxnKind.READ, ws, links[li % len(links)], gate, f"ve_ld_{op}"))
        loads[g] = ids

    for g in range(min(depth, G)):
        emit_loads(g)
    lane_ops = 0
    for g in range(G):
        active = min(L, k.n - g * L)
        deps = tuple(loads[g]) + ((prev_compute,) if prev_compute is not None else ())
        useful = active * (k.taps if op == "fir" else 1)
        ops.append(ComputeOp(comp_cycles, deps=deps, useful_ops=useful, capacity_ops=L * comp_cycles,
                             tag=f"ve_{op}"))
        lane_ops += useful
        prev_compute = len(ops) - 1
        computes.append(prev_compute)
        if has_store:
            for li, ws in enumerate(accesses(k.c_base, g, op == "scatter")):
                last_store.append(mem(TxnKind.WRITE, ws, links[li % len(links)], (prev_compute,), f"ve_st_{op}"))
        if g + depth < G:
            emit_loads(g + depth)
    if op in ("dot", "reduce") and G and k.wres:
        w = (k.c_base + k.align_offset) // word_bytes
        last_store.append(mem(TxnKind.WRITE, [w], links[0], (prev_compute,), f"ve_res_{op}"))
    final_deps = tuple(last_store[-len(links):]) if last_store else ((prev_compute,) if prev_compute is not None
                                                                     else (head,))
    ops.append(ComputeOp(cfg.tail_cycles, deps=final_deps, tag="ve_tail", post=done_token))
    info = {"beats": G, "lane_ops": lane_ops, "groups_in_flight": depth, "lanes": L, "elem_bits": cfg.elem_bits,
            "op": op, "bytes_loaded": sum(o.size for o in ops if isinstance(o, MemOp) and o.kind == TxnKind.READ),
            "bytes_stored": sum(o.size for o in ops if isinstance(o, MemOp) and o.kind == TxnKind.WRITE)}
    return ops, info


def rtl_cycles_formula(op: str, n: int, lanes: int = 4, wres: bool = False, scalar: bool = False) -> int:
    """sfv_vec_engine documented CYCLES (header lines 25-30) -- used as a validation reference."""
    if n == 0:
        return 2
    b = ceil_div(n, lanes)
    if op == "dot":
        p = 1 if scalar else 2
    else:
        p = 2 if scalar else 3
    return 3 + b * p + (1 if (op == "dot" and wres) else 0)
