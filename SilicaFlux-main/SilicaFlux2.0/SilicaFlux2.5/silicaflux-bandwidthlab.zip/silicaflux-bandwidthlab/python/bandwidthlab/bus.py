"""Cycle-aware model of the SilicaFlux DataFabric interconnect (SFB2) and generalisations.

Baseline semantics are those of the audited RTL (silicaflux-datafabric, see
docs/bandwidthlab/repository_audit.md):

* SFB2 valid/ready request channel (write, addr, wdata, wstrb) and response channel
  (rdata, error); no IDs, no native bursts; every write gets a response.
* ``sfb_crossbar``: one arbiter per slave port; 0 added cycles in either direction (the
  master's ``req_ready`` is the slave's ready gated by the grant, so a request is accepted
  when the target accepts it); at most 1 transaction outstanding per master port and per
  slave port; a slave/master port can accept a new request in the same cycle as the
  previous response handshake; responses are routed back by a per-slave owner register,
  i.e. in order per master.
* ``sfb_arbiter``: round robin with the pointer moving to winner+1 only when the grant is
  accepted, or fixed priority (index 0 highest); a stalled grant is held (grant lock).
* Unmapped / access-denied / misaligned requests go to a per-master error slave which
  answers ``error=1, rdata=0`` one cycle after acceptance; no slave sees them.
* ``sfb_reg_slice``: +1 cycle per sliced direction, 2-entry skid buffer.

Generalisations used by the exploration studies (NOT present in the audited RTL and
never reported as SilicaFlux RTL behaviour): shared-bus topology, registered input
queues, more than one outstanding transaction per port (with in-order or same-target-only
response ordering), multi-beat bursts with setup cycles, weighted and age-based
arbitration.  ``FabricConfig.rtl_equivalent()`` states whether a configuration stays
within the audited SFB2 behaviour.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from .arbitration import Arbiter
from .events import EventType
from .scheduler import Scheduler
from .transaction import MemTransaction, TransactionLedger, TxnState, TxnStatus
from .units import ceil_div


class FabricConfigError(ValueError):
    pass


@dataclass
class FabricConfig:
    name: str = "datafabric"
    clock: str = "clk"
    topology: str = "crossbar"               # crossbar | shared_bus
    data_width_bits: int = 32
    arbitration: str = "rr"                  # fixed | rr | wrr | age
    weights: dict[str, int] = field(default_factory=dict)
    max_outstanding_per_master: int = 1
    max_outstanding_per_target: int = 1
    input_queue_depth: int = 0               # 0 = combinational master port (SFB2)
    req_slices: int = 0                      # register slices on the request path
    rsp_slices: int = 0                      # register slices on the response path
    ordering: str = "in_order"               # in_order | same_target_only | out_of_order
    max_burst_beats: int = 1                 # 1 = single-beat SFB2 transfers
    burst_setup_cycles: int = 0              # extra request-channel cycles per multi-beat transfer
    error_latency: int = 1                   # per-master error slave response latency

    def __post_init__(self) -> None:
        if self.topology not in ("crossbar", "shared_bus"):
            raise FabricConfigError("topology must be crossbar or shared_bus")
        if self.data_width_bits < 8 or self.data_width_bits % 8:
            raise FabricConfigError("data_width_bits must be a positive multiple of 8")
        if self.max_outstanding_per_master < 1 or self.max_outstanding_per_target < 1:
            raise FabricConfigError("outstanding limits must be >= 1")
        if self.input_queue_depth < 0 or self.req_slices < 0 or self.rsp_slices < 0:
            raise FabricConfigError("queue depth and slice counts must be >= 0")
        if self.ordering not in ("in_order", "same_target_only", "out_of_order"):
            raise FabricConfigError("ordering must be in_order, same_target_only or out_of_order")
        if self.max_burst_beats < 1 or self.burst_setup_cycles < 0 or self.error_latency < 1:
            raise FabricConfigError("max_burst_beats >= 1, burst_setup_cycles >= 0, error_latency >= 1")
        if self.max_outstanding_per_master > 1 and self.ordering == "out_of_order":
            pass  # allowed for exploration: requires ID-tagged responses, which SFB2 does not have

    @property
    def width_bytes(self) -> int:
        return self.data_width_bits // 8

    def rtl_equivalent(self) -> tuple[bool, list[str]]:
        why = []
        if self.topology != "crossbar":
            why.append("shared_bus topology (sfb_shared_bus exists only in testbenches)")
        if self.max_outstanding_per_master != 1 or self.max_outstanding_per_target != 1:
            why.append("more than 1 outstanding per port (SFB2 crossbar allows 1)")
        if self.input_queue_depth:
            why.append("registered input queues (not in sfb_crossbar)")
        if self.arbitration in ("wrr", "age"):
            why.append(f"{self.arbitration} arbitration (sfb_arbiter has fixed and rr only)")
        if self.max_burst_beats != 1:
            why.append("multi-beat bursts (SFB2 has no native bursts)")
        if self.ordering == "out_of_order":
            why.append("out-of-order responses need IDs (SFB2 has none)")
        return (not why, why)


@dataclass
class _MPort:
    idx: int
    name: str
    slot: MemTransaction | None = None                 # presented (combinational) request
    fifo: deque = field(default_factory=deque)          # (enq_cycle, txn) registered input queue
    fifo_len_reg: int = 0
    outstanding: list = field(default_factory=list)     # accepted, response not yet delivered (in order)
    in_flight: int = 0                                  # granted-not-accepted + accepted-not-responded
    delivered: MemTransaction | None = None
    rsp_pipe: deque = field(default_factory=deque)      # (ready_cycle, txn)
    err_q: deque = field(default_factory=deque)         # (ready_cycle, txn)
    accept_cb: Callable[[MemTransaction, int], None] | None = None
    rsp_ready: Callable[[int], bool] | None = None      # master response back-pressure (SFB2 rsp_ready)
    present_cycle: int = -1
    # statistics
    grants: int = 0
    bytes: int = 0
    req_bp_cycles: int = 0
    arb_loss_cycles: int = 0
    max_wait_cycles: int = 0
    wait_sum_cycles: int = 0
    occ_area: int = 0
    occ_last: int = 0
    occ_max: int = 0


@dataclass
class _TPort:
    idx: int
    name: str
    target: Any
    port: int
    arb: Arbiter
    locked: tuple[int, MemTransaction, list[int]] | None = None
    outstanding: int = 0
    slice_q: deque = field(default_factory=deque)       # (arrive_cycle, master, txn)
    busy_until: int = -1                                # write-beat / setup occupancy (inclusive)
    # statistics
    busy_cycles: int = 0
    contention_cycles: int = 0
    accepted: int = 0
    bytes: int = 0


class Interconnect:
    kind = "interconnect"
    rank = 1

    def __init__(self, sched: Scheduler, cfg: FabricConfig, *, ledger: TransactionLedger | None = None) -> None:
        self.sched, self.cfg, self.ledger = sched, cfg, ledger
        self.name = cfg.name
        self.domain = cfg.clock
        self.drv = sched.driver(cfg.clock)
        self.clock = self.drv.clock
        self.masters: list[_MPort] = []
        self.mindex: dict[str, int] = {}
        self.tports: list[_TPort] = []
        self.amap: list[tuple[int, int, int, str]] = []    # (base, end, tport, target name)
        self.groups: list[tuple[int, int, str, list[int], Any, int]] = []   # interleaved bank groups
        self.allowed: dict[str, set[str]] = {}
        self._bus_arb: Arbiter | None = None
        self.conflict_matrix: dict[tuple[str, str], int] = {}
        self.grant_matrix: dict[tuple[str, str], int] = {}
        self.first_cycle: int | None = None
        self.last_cycle: int | None = None
        self.decode_errors = 0
        self.rsp_hol_cycles = 0
        self._granted_this_edge: set[int] = set()
        self.drv.attach(self)
        sched.register(self)

    # ------------------------------------------------------------------ construction
    def add_master(self, name: str) -> int:
        if name in self.mindex:
            raise FabricConfigError(f"master {name} added twice")
        m = _MPort(len(self.masters), name)
        self.masters.append(m)
        self.mindex[name] = m.idx
        self._rebuild_arbiters()
        return m.idx

    def add_target(self, name: str, target: Any, *, base: int, size: int, port: int = 0) -> None:
        end = base + size
        for b, e, _, n in self.amap:
            if base < e and b < end:
                raise FabricConfigError(f"address range of {name} overlaps {n}")
        tp = _TPort(len(self.tports), name, target, port, Arbiter(1))
        self.tports.append(tp)
        self.amap.append((base, end, tp.idx, name))
        self.amap.sort()
        target.set_accept_callback(port, lambda t, c, tp=tp: self._target_accept(tp, t, c))
        self._rebuild_arbiters()

    def add_target_group(self, name: str, targets: list[Any], *, base: int, size: int, mapper: Any,
                         word_bytes: int) -> None:
        """Bank targets selected by an address-to-bank mapping (each bank its own slave port).

        The decoder computes (bank, row) = mapper.map((addr - base) // word_bytes) and forwards
        the request to bank ``bank`` at local address bank.base + row * word_bytes.  Requests
        must not cross a bank word.
        """
        end = base + size
        for b, e, _, n in self.amap:
            if base < e and b < end:
                raise FabricConfigError(f"address range of {name} overlaps {n}")
        idx = []
        for t in targets:
            tp = _TPort(len(self.tports), t.name, t, 0, Arbiter(1))
            self.tports.append(tp)
            t.set_accept_callback(0, lambda tx, c, tp=tp: self._target_accept(tp, tx, c))
            idx.append(tp.idx)
        self.groups.append((base, end, name, idx, mapper, word_bytes))
        self._rebuild_arbiters()

    def set_access(self, master: str, targets: set[str]) -> None:
        self.allowed[master] = set(targets)

    def _rebuild_arbiters(self) -> None:
        n = max(1, len(self.masters))
        w = [self.cfg.weights.get(m.name, 1) for m in self.masters] if self.masters else [1]
        pol = self.cfg.arbitration
        for tp in self.tports:
            tp.arb = Arbiter(n, pol, w if pol == "wrr" else None, f"{self.name}.{tp.name}.arb")
        self._bus_arb = Arbiter(n, pol, w if pol == "wrr" else None, f"{self.name}.bus.arb")

    def decode(self, master: str, addr: int, size: int, txn: MemTransaction | None = None) -> int | None:
        for b, e, name, idx, mapper, wb in self.groups:
            if b <= addr < e:
                if addr + size > e or (addr - b) // wb != (addr + size - 1 - b) // wb:
                    return None                       # crosses a bank word / the group end
                if master in self.allowed and name not in self.allowed[master]:
                    return None
                bank, row = mapper.map((addr - b) // wb)
                ti = idx[bank]
                if txn is not None:
                    txn.meta["_local_addr"] = self.tports[ti].target.base + row * wb + (addr - b) % wb
                return ti
        for b, e, ti, name in self.amap:
            if b <= addr < e:
                if addr + size > e:
                    return None
                if master in self.allowed and name not in self.allowed[master]:
                    return None
                return ti
        return None

    # ------------------------------------------------------------------ master-side API
    def can_present(self, mi: int) -> bool:
        return self.masters[mi].slot is None

    def present(self, mi: int, txn: MemTransaction) -> None:
        m = self.masters[mi]
        if m.slot is not None:
            raise RuntimeError(f"{self.name}: master {m.name} presented while a request is held")
        beats = max(1, ceil_div(txn.size, self.cfg.width_bytes))
        if beats > self.cfg.max_burst_beats:
            raise FabricConfigError(f"{self.name}: {txn.size}-byte transfer needs {beats} beats; "
                                    f"max_burst_beats={self.cfg.max_burst_beats}")
        txn.beats = beats
        ti = self.decode(m.name, txn.addr, txn.size, txn)
        if ti is None or (txn.addr % min(self.cfg.width_bytes, txn.size if txn.size > 0 else 1)):
            ti = None
        txn.meta["_m"] = mi
        txn.meta["_tp"] = ti
        txn.dst = self.tports[ti].name if ti is not None else "error_slave"
        txn.path.append(self.name)
        m.slot = txn
        m.present_cycle = self.drv.cycle()
        self.drv.wake()

    def take_response(self, mi: int, cyc: int) -> MemTransaction | None:
        m = self.masters[mi]
        t, m.delivered = m.delivered, None
        return t

    def set_accept_callback(self, mi: int, cb: Callable[[MemTransaction, int], None]) -> None:
        self.masters[mi].accept_cb = cb

    def set_rsp_ready(self, mi: int, fn: Callable[[int], bool]) -> None:
        """``fn(cycle) -> bool``: the master's rsp_ready in that cycle (default: always ready)."""
        self.masters[mi].rsp_ready = fn

    def _ready(self, m: _MPort, cyc: int) -> bool:
        return m.rsp_ready is None or bool(m.rsp_ready(cyc))

    # ------------------------------------------------------------------ helpers
    def outstanding(self) -> int:
        n = 0
        for m in self.masters:
            n += (m.slot is not None) + len(m.fifo) + len(m.outstanding) + len(m.rsp_pipe) + len(m.err_q)
        for tp in self.tports:
            n += len(tp.slice_q) + (tp.locked is not None)
        return n

    def busy(self) -> bool:
        return self.outstanding() > 0 or any(m.delivered is not None for m in self.masters)

    def _occ_update(self, m: _MPort, cyc: int) -> None:
        m.occ_area += len(m.fifo) * (cyc - m.occ_last)
        m.occ_last = cyc
        m.occ_max = max(m.occ_max, len(m.fifo))

    def _accept_handshake(self, t: MemTransaction) -> None:
        if t.t_accepted is None:
            t.mark_accepted(self.sched.now)
            if self.ledger is not None:
                self.ledger.on_accepted(t)
            self.sched.emit(EventType.REQUEST_ACCEPTED, domain=self.domain, txn=t, src=t.master, dst=self.name)

    # ------------------------------------------------------------------ phases
    def on_response(self, cyc: int) -> None:
        if self.first_cycle is None:
            self.first_cycle = cyc
        self.last_cycle = cyc
        self._granted_this_edge = set()
        for m in self.masters:
            m.fifo_len_reg = len(m.fifo)
        shared = self.cfg.topology == "shared_bus"
        rsp_bus_used = False
        # per-master error slaves
        for m in self.masters:
            if m.err_q and m.err_q[0][0] <= cyc and m.delivered is None and self._ready(m, cyc):
                if self.cfg.ordering == "in_order" and m.outstanding and m.outstanding[0] is not m.err_q[0][1]:
                    continue
                _, t = m.err_q.popleft()
                t.advance(TxnState.SERVICE_DONE, self.sched.now)
                t.advance(TxnState.RESPONSE, self.sched.now)
                self.sched.emit(EventType.RESPONSE_GENERATED, domain=self.domain, txn=t, src="error_slave",
                                dst=m.name, payload={"error": True})
                self._deliver(m, t, cyc)
        # response pipes (register slices / multi-beat read data)
        for m in self.masters:
            if m.rsp_pipe and m.rsp_pipe[0][0] <= cyc and m.delivered is None and self._ready(m, cyc):
                _, t = m.rsp_pipe.popleft()
                self._deliver(m, t, cyc)
        # target responses
        for tp in self.tports:
            t = tp.target.peek_response(tp.port, cyc)
            if t is None:
                continue
            m = self.masters[t.meta["_m"]]
            if self.cfg.ordering == "in_order" and m.outstanding and m.outstanding[0] is not t:
                self.rsp_hol_cycles += 1
                continue
            extra = self.cfg.rsp_slices + (t.beats - 1 if t.op == "R" else 0)
            if extra == 0 and (m.delivered is not None or not self._ready(m, cyc)):
                continue
            if shared and rsp_bus_used:
                continue
            tp.target.pop_response(tp.port, cyc)
            tp.outstanding -= 1
            rsp_bus_used = True
            if extra == 0:
                self._deliver(m, t, cyc)
            else:
                m.rsp_pipe.append((cyc + extra, t))
        self.drv.wake() if self.busy() else None

    def _deliver(self, m: _MPort, t: MemTransaction, cyc: int) -> None:
        if t in m.outstanding:
            m.outstanding.remove(t)
        m.in_flight -= 1
        m.delivered = t

    def on_arbitrate(self, cyc: int) -> None:
        cfg = self.cfg
        # 1) registered input queues: admission (uses the FIFO length registered at the edge)
        if cfg.input_queue_depth > 0:
            for m in self.masters:
                t = m.slot
                if t is None:
                    continue
                if t.meta["_tp"] is None:
                    continue                         # decode errors go to the error slave below
                if m.fifo_len_reg < cfg.input_queue_depth:
                    self._occ_update(m, cyc)
                    m.slot = None
                    m.fifo.append((cyc, t))
                    t.advance(TxnState.ENQUEUED, self.sched.now)
                    self._accept_handshake(t)
                    self.sched.emit(EventType.QUEUE_ENTERED, domain=self.domain, txn=t, src=m.name,
                                    dst=f"{self.name}.{m.name}.q", payload={"occupancy": len(m.fifo)})
                    if m.accept_cb:
                        m.accept_cb(t, cyc)
        # 2) decode errors -> per-master error slave (accepted without arbitration)
        for m in self.masters:
            t = m.slot
            if t is not None and t.meta["_tp"] is None and m.in_flight < cfg.max_outstanding_per_master:
                m.slot = None
                self.decode_errors += 1
                t.status = TxnStatus.DECODE_ERROR
                t.error = True
                if t.op == "R":
                    t.data = 0
                self._accept_handshake(t)
                t.advance(TxnState.SERVICE_STARTED, self.sched.now)
                self.sched.emit(EventType.ERROR_RESPONSE, domain=self.domain, txn=t, src="error_slave", dst=m.name,
                                payload={"reason": "unmapped, access-denied or misaligned address"})
                m.outstanding.append(t)
                m.in_flight += 1
                m.err_q.append((cyc + cfg.error_latency, t))
                if m.accept_cb:
                    m.accept_cb(t, cyc)
        # 3) slice pipelines deliver to their targets
        for tp in self.tports:
            if tp.slice_q and tp.slice_q[0][0] <= cyc and tp.locked is None and tp.target.can_present(tp.port):
                _, mi, t = tp.slice_q.popleft()
                tp.locked = (mi, t, [])
                tp.target.present(tp.port, t)
        # 4) arbitration
        cands: dict[int, list[int]] = {}
        ages: dict[int, int] = {}
        for m in self.masters:
            if cfg.input_queue_depth > 0:
                if not m.fifo or m.fifo[0][0] >= cyc:
                    continue
                t = m.fifo[0][1]
                if t.state < TxnState.QUEUE_HEAD:
                    t.advance(TxnState.QUEUE_HEAD, self.sched.now)
            else:
                t = m.slot
                if t is None or t.meta.get("_granted"):
                    continue
            ti = t.meta["_tp"]
            if ti is None:
                continue
            if m.in_flight >= cfg.max_outstanding_per_master:
                continue
            if cfg.ordering == "same_target_only" and any(o.meta["_tp"] != ti for o in m.outstanding):
                continue
            cands.setdefault(ti, []).append(m.idx)
            ages[m.idx] = t.t_issued if t.t_enqueued is None else t.t_enqueued
        if cfg.topology == "shared_bus":
            self._arbitrate_shared(cands, ages, cyc)
        else:
            for tp in self.tports:
                reqs = cands.get(tp.idx)
                if not reqs:
                    continue
                self._arbitrate_port(tp, tp.arb, reqs, ages, cyc)

    def _port_free(self, tp: _TPort, cyc: int) -> bool:
        if tp.locked is not None or tp.busy_until >= cyc:
            return False
        if tp.outstanding + len(tp.slice_q) >= self.cfg.max_outstanding_per_target:
            return False
        if self.cfg.req_slices and len(tp.slice_q) >= 2 * self.cfg.req_slices:
            return False
        return True

    def _arbitrate_port(self, tp: _TPort, arb: Arbiter, reqs: list[int], ages: dict[int, int], cyc: int) -> bool:
        if not self._port_free(tp, cyc):
            for mi in reqs:
                self.masters[mi].arb_loss_cycles += 1
                key = (self.masters[mi].name, tp.name)
                self.conflict_matrix[key] = self.conflict_matrix.get(key, 0) + 1
            if len(reqs) > 0:
                tp.contention_cycles += 1
            return False
        win = arb.pick(reqs, ages)
        if win is None:
            return False
        if len(reqs) > 1:
            tp.contention_cycles += 1
        for mi in reqs:
            if mi != win:
                self.masters[mi].arb_loss_cycles += 1
                key = (self.masters[mi].name, tp.name)
                self.conflict_matrix[key] = self.conflict_matrix.get(key, 0) + 1
        self._grant(tp, arb, win, list(reqs), cyc)
        return True

    def _arbitrate_shared(self, cands: dict[int, list[int]], ages: dict[int, int], cyc: int) -> None:
        # one grant per cycle on the whole bus; the bus is held while any granted request waits
        if any(tp.locked is not None or tp.busy_until >= cyc for tp in self.tports):
            for reqs in cands.values():
                for mi in reqs:
                    self.masters[mi].arb_loss_cycles += 1
            return
        flat = [(mi, ti) for ti, reqs in cands.items() for mi in reqs
                if self._port_free(self.tports[ti], cyc)]
        if not flat:
            return
        assert self._bus_arb is not None
        win = self._bus_arb.pick([mi for mi, _ in flat], ages)
        ti = next(t for mi, t in flat if mi == win)
        for mi, t in flat:
            if mi != win:
                self.masters[mi].arb_loss_cycles += 1
                key = (self.masters[mi].name, self.tports[t].name)
                self.conflict_matrix[key] = self.conflict_matrix.get(key, 0) + 1
        if len(flat) > 1:
            self.tports[ti].contention_cycles += 1
        self._grant(self.tports[ti], self._bus_arb, win, [mi for mi, _ in flat], cyc)

    def _grant(self, tp: _TPort, arb: Arbiter, mi: int, reqs: list[int], cyc: int) -> None:
        m = self.masters[mi]
        cfg = self.cfg
        if cfg.input_queue_depth > 0:
            self._occ_update(m, cyc)
            _, t = m.fifo.popleft()
            self.sched.emit(EventType.QUEUE_EXITED, domain=self.domain, txn=t, src=f"{self.name}.{m.name}.q",
                            dst=tp.name)
        else:
            t = m.slot
            t.meta["_granted"] = True
        now = self.sched.now
        t.advance(TxnState.GRANTED, now)
        wait = cyc - self.clock.edge_index_at_or_after(t.t_queue_head or t.t_enqueued or t.t_issued)
        m.wait_sum_cycles += wait
        m.max_wait_cycles = max(m.max_wait_cycles, wait)
        m.in_flight += 1
        self.sched.emit(EventType.ARBITRATION_GRANTED, domain=self.domain, txn=t, src=m.name, dst=tp.name,
                        payload={"requesters": [self.masters[i].name for i in reqs], "wait_cycles": wait})
        self._granted_this_edge.add(tp.idx)
        key = (m.name, tp.name)
        self.grant_matrix[key] = self.grant_matrix.get(key, 0) + 1
        beats = t.beats
        occ = (cfg.burst_setup_cycles if beats > 1 else 0) + (beats - 1 if t.op == "W" else 0)
        if occ:
            tp.busy_until = cyc + occ
        if cfg.req_slices == 0:
            tp.locked = (mi, t, reqs)
            tp.target.present(tp.port, t)
        else:
            # the register slice takes the request: handshake with the master now
            if cfg.input_queue_depth == 0:
                m.slot = None
                self._accept_handshake(t)
                if m.accept_cb:
                    m.accept_cb(t, cyc)
            arb.accept(mi, reqs)
            tp.slice_q.append((cyc + cfg.req_slices + occ, mi, t))

    def _target_accept(self, tp: _TPort, t: MemTransaction, cyc: int) -> None:
        mi = t.meta["_m"]
        m = self.masters[mi]
        reqs: list[int] = []
        if tp.locked is not None and tp.locked[1] is t:
            reqs = tp.locked[2]
            tp.locked = None
        if self.cfg.req_slices == 0:
            arb = self._bus_arb if self.cfg.topology == "shared_bus" else tp.arb
            arb.accept(mi, reqs)                        # RR pointer moves only on an accepted grant
        tp.accepted += 1
        tp.busy_cycles += max(1, t.beats if t.op == "W" else 1)
        tp.bytes += t.size
        m.grants += 1
        m.bytes += t.size
        posted = bool(t.meta.get("posted"))
        if not posted:
            tp.outstanding += 1
            m.outstanding.append(t)
        else:
            m.in_flight -= 1
        if self.cfg.req_slices == 0 and self.cfg.input_queue_depth == 0:
            # combinational SFB2 path: the master's handshake is the target's acceptance
            m.slot = None
            t.meta.pop("_granted", None)
            if self.ledger is not None and t.tid not in self.ledger.accepted:
                if t.t_accepted is None:
                    t.mark_accepted(self.sched.now)
                self.ledger.on_accepted(t)
            if m.accept_cb:
                m.accept_cb(t, cyc)

    def on_post(self, cyc: int) -> None:
        for m in self.masters:
            if m.slot is not None and self.cfg.input_queue_depth == 0:
                m.req_bp_cycles += 1
            elif m.slot is not None and self.cfg.input_queue_depth > 0:
                m.req_bp_cycles += 1
        for tp in self.tports:
            if tp.idx not in self._granted_this_edge and tp.busy_until >= cyc:
                tp.busy_cycles += 0      # write beats already counted at acceptance

    # ------------------------------------------------------------------ statistics
    def window_cycles(self) -> int:
        if self.first_cycle is None:
            return 0
        return self.last_cycle - self.first_cycle + 1

    def stats(self, window_cycles: int | None = None) -> dict:
        win = window_cycles or self.window_cycles() or 1
        ok, why = self.cfg.rtl_equivalent()
        masters = []
        for m in self.masters:
            self._occ_update(m, self.last_cycle or 0)
            masters.append({
                "master": m.name, "grants": m.grants, "bytes": m.bytes, "bytes_per_cycle": m.bytes / win,
                "request_backpressure_cycles": m.req_bp_cycles, "arbitration_loss_cycles": m.arb_loss_cycles,
                "mean_arbitration_wait_cycles": m.wait_sum_cycles / m.grants if m.grants else 0.0,
                "max_arbitration_wait_cycles": m.max_wait_cycles,
                "avg_queue_occupancy": m.occ_area / win, "max_queue_occupancy": m.occ_max,
            })
        ports = [{"target": tp.name, "accepted": tp.accepted, "bytes": tp.bytes, "busy_cycles": tp.busy_cycles,
                  "utilisation": tp.busy_cycles / win, "contention_cycles": tp.contention_cycles,
                  "grant_share": {self.masters[i].name: g for i, g in enumerate(tp.arb.grants)}}
                 for tp in self.tports]
        return {"name": self.name, "topology": self.cfg.topology, "width_bits": self.cfg.data_width_bits,
                "arbitration": self.cfg.arbitration, "window_cycles": win, "masters": masters, "targets": ports,
                "decode_errors": self.decode_errors, "response_hol_cycles": self.rsp_hol_cycles,
                "conflict_matrix": {f"{a}->{b}": v for (a, b), v in sorted(self.conflict_matrix.items())},
                "grant_matrix": {f"{a}->{b}": v for (a, b), v in sorted(self.grant_matrix.items())},
                "rtl_equivalent": ok, "rtl_differences": why}


class FabricLink:
    """A master's port into the interconnect (implements ``masters.Link``)."""

    def __init__(self, ic: Interconnect, master_name: str, name: str | None = None) -> None:
        self.ic = ic
        self.mi = ic.add_master(master_name)
        self.name = name or f"{ic.name}.{master_name}"
        self.master: Any = None

    def bind(self, master: Any) -> None:
        self.master = master
        self.ic.set_accept_callback(self.mi, lambda t, c: master.on_link_accept(self, t, c))

    def can_present(self, cyc: int) -> bool:
        return self.ic.can_present(self.mi)

    def present(self, txn: MemTransaction) -> None:
        self.ic.present(self.mi, txn)

    def poll_response(self, cyc: int) -> MemTransaction | None:
        return self.ic.take_response(self.mi, cyc)
