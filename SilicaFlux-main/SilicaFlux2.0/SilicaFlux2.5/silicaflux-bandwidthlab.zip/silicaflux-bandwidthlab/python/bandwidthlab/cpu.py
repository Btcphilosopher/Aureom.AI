"""In-order control-processor model with separate instruction and data ports.

Modelled on the audited SilicaFlux-V / MCU-I cores (RV32I(M)_Zicsr, 2-stage in-order,
separate CPUI/CPUD fabric masters, one request outstanding per port, blocking loads and
stores; documented CPI 1 ALU, 2 load/store with zero-wait memory, 3 taken branch --
sfv_cpu.sv:4-15).  No cache (none exists in SilicaFlux-V or MCU-I).

Structure: two program masters synchronised through the TokenBoard.

* ``<name>_i`` fetches instruction i (4 bytes, sequential PC) as soon as the fetch buffer
  has room (at most ``fetch_ahead`` instructions ahead of execution) and, after a taken
  branch, only once the branch has executed (redirect).
* ``<name>_d`` executes instruction i once it has been fetched: ALU/branch = a compute op
  of ``cpi_alu`` cycles; load/store = a data-port transaction; the next instruction
  waits for a load/store to complete (blocking memory access, 1 outstanding).

The CPI the model produces with zero-wait memory is checked against the documented
values in tests/bandwidthlab/test_workloads.py; this is a validation against repository
documentation, not against an RTL simulation of the core.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from .masters import ComputeOp, MemOp, Op
from .transaction import TxnKind
from .workloads import build_linked_list


@dataclass
class CpuConfig:
    name: str = "cpu"
    code_base: int = 0x0000_0000
    code_bytes: int = 4096
    fetch_ahead: int = 3
    cpi_alu: int = 1
    blocking_memory: bool = True


@dataclass
class CpuWorkload:
    pattern: str = "seq_read"          # seq_read | seq_write | random | pointer_chase | stack | mixed | stream_*
    n_mem: int = 1000                  # memory instructions
    alu_per_mem: int = 3               # ALU instructions between memory instructions
    branch_every: int = 0              # a taken branch every N instructions (0 = none)
    data_base: int = 0x1000_0000
    data_bytes: int = 16 * 1024
    write_fraction: float = 0.3
    seed: int = 1


def cpu_programs(cfg: CpuConfig, wl: CpuWorkload) -> tuple[list[Op], list[Op], dict[str, Any]]:
    """Return (fetch program, execute program, info)."""
    rng = np.random.Generator(np.random.PCG64(wl.seed))
    instrs: list[tuple[str, Any]] = []                 # (class, payload)
    words = wl.data_bytes // 4
    chase = None
    if wl.pattern == "pointer_chase":
        chase = build_linked_list(wl.n_mem + 1, wl.data_base, wl.data_bytes, 4, wl.seed)
    sp = 0
    for i in range(wl.n_mem):
        for _ in range(wl.alu_per_mem):
            instrs.append(("alu", None))
        p = wl.pattern
        if p in ("seq_read", "stream_read"):
            instrs.append(("load", wl.data_base + (i % words) * 4))
        elif p in ("seq_write", "stream_write"):
            instrs.append(("store", wl.data_base + (i % words) * 4))
        elif p == "random":
            a = wl.data_base + int(rng.integers(0, words)) * 4
            instrs.append(("store" if rng.random() < wl.write_fraction else "load", a))
        elif p == "mixed":
            a = wl.data_base + (i % words) * 4
            instrs.append(("store" if rng.random() < wl.write_fraction else "load", a))
        elif p == "stack":
            if (i // 8) % 2 == 0:
                sp += 1
                instrs.append(("store", wl.data_base + wl.data_bytes - sp * 4))
            else:
                instrs.append(("load", wl.data_base + wl.data_bytes - sp * 4))
                sp -= 1
        elif p == "pointer_chase":
            instrs.append(("chase", i))
        else:
            raise ValueError(f"unknown CPU data pattern {p!r}")
    if wl.branch_every:
        out = []
        for k, ins in enumerate(instrs):
            out.append(ins)
            if (k + 1) % wl.branch_every == 0:
                out.append(("branch", None))
        instrs = out
    n = len(instrs)
    words_code = cfg.code_bytes // 4
    fetch: list[Op] = []
    exe: list[Op] = []
    nm = cfg.name
    last_load_oid: int | None = None
    prev_blocking: int | None = None
    for i, (cls, payload) in enumerate(instrs):
        wait: list[str] = []
        if i >= cfg.fetch_ahead:
            wait.append(f"{nm}.x{i - cfg.fetch_ahead}")
        if i > 0 and instrs[i - 1][0] == "branch":
            wait.append(f"{nm}.x{i - 1}")
        fetch.append(MemOp(TxnKind.READ, cfg.code_base + (i % words_code) * 4, 4, wait=tuple(sorted(set(wait))),
                           post=f"{nm}.f{i}", tag="ifetch", link="default"))
        deps = (prev_blocking,) if (prev_blocking is not None and cfg.blocking_memory) else ()
        w = (f"{nm}.f{i}",)
        post = f"{nm}.x{i}"
        if cls in ("alu", "branch"):
            exe.append(ComputeOp(cfg.cpi_alu, deps=deps, wait=w, post=post, tag=cls, useful_ops=1,
                                 capacity_ops=cfg.cpi_alu))
            prev_blocking = None if not cfg.blocking_memory else prev_blocking
            if cls == "alu" or cls == "branch":
                prev_blocking = None
        elif cls in ("load", "store"):
            kind = TxnKind.READ if cls == "load" else TxnKind.WRITE
            data = int(rng.integers(0, 1 << 32)) if kind == TxnKind.WRITE else None
            exe.append(MemOp(kind, payload, 4, deps=deps, wait=w, post=post, data=data, tag=cls, link="data"))
            prev_blocking = len(exe) - 1
        elif cls == "chase":
            j = payload
            if j == 0:
                addr: Any = chase[0]
                d: tuple[int, ...] = deps
            else:
                addr = (lambda dd, p=last_load_oid: int(dd[p].data))
                d = tuple(sorted(set(deps) | {last_load_oid}))
            exe.append(MemOp(TxnKind.READ, addr, 4, deps=d, wait=w, post=post, tag="chase", link="data"))
            last_load_oid = len(exe) - 1
            prev_blocking = last_load_oid
    info = {"instructions": n, "memory_instructions": wl.n_mem,
            "alu_instructions": sum(1 for c, _ in instrs if c == "alu"),
            "branches": sum(1 for c, _ in instrs if c == "branch"), "chase_nodes": chase}
    return fetch, exe, info
