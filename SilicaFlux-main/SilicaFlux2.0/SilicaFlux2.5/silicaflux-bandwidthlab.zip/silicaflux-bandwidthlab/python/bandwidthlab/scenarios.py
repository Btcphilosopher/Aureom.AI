"""Build a System from a SystemConfig and attach reference workloads.

Scenarios (all deterministic for a given seed):

  cpu_pattern     the control CPU running one of the CPU data patterns (with instruction fetch)
  dma_copy        one DMA copy between two memories (data verified)
  gemm_local      the tensor engine on operands already resident in its local memory
  vector_local    the vector engine on operands already resident in its local memory
  tile_pipeline   the SilicaFlux-V reference pipeline: for every GEMM output tile the CPU
                  programs the DMA through its registers on the fabric, the DMA stages the
                  A/B tiles from main SRAM into the tile scratchpad (double-buffered), the
                  tensor engine computes, the vector engine post-processes the tile
                  (requantisation), the CPU programs the write-back DMA; optionally the CPU
                  also runs a background data loop competing for the fabric
  injection       open-loop synthetic traffic from N masters (saturation studies)
  contention      a CPU data stream competing with a DMA copy or tensor traffic
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .banking import BankMapper
from .bus import FabricConfig, FabricLink
from .config import SystemConfig
from .cpu import CpuConfig, CpuWorkload, cpu_programs
from .dma import Descriptor, DmaConfig, DmaEngine
from .dram import DramConfig
from .masters import ComputeOp, MemOp, ProgramMaster
from .simulation import System
from .sram import SramConfig
from .tensor import GemmKernel, TensorConfig, tensor_program
from .transaction import TxnKind
from .vector import VectorConfig, VectorKernel, vector_program
from .workloads import init_pointer_chase, program

DMA_REG_BASE = 0x4000_6000          # DataFabric DMA register page (sfb_memmap_pkg, audited)


class BankGroupView:
    """Global-address view of a memory split into separate bank targets."""

    def __init__(self, name: str, base: int, capacity: int, banks: list, mapper: BankMapper, word_bytes: int) -> None:
        self.name, self.base, self.capacity = name, base, capacity
        self.banks, self.mapper, self.wb = banks, mapper, word_bytes

    def _loc(self, addr: int) -> tuple[Any, int]:
        b, row = self.mapper.map((addr - self.base) // self.wb)
        bank = self.banks[b]
        return bank, bank.base + row * self.wb + (addr - self.base) % self.wb

    def write_bytes(self, addr: int, data: bytes) -> None:
        for i, x in enumerate(data):
            bank, a = self._loc(addr + i)
            bank.write_bytes(a, bytes([x]))

    def read_bytes(self, addr: int, n: int) -> bytes:
        out = bytearray()
        for i in range(n):
            bank, a = self._loc(addr + i)
            out += bank.read_bytes(a, 1)
        return bytes(out)


@dataclass
class Built:
    cfg: SystemConfig
    system: System
    links: dict[str, FabricLink] = field(default_factory=dict)
    mem_port_of: dict[tuple[str, str], int] = field(default_factory=dict)   # (memory, engine) -> port
    dma: DmaEngine | None = None
    info: dict[str, Any] = field(default_factory=dict)
    groups: dict[str, BankGroupView] = field(default_factory=dict)

    def mem(self, name: str) -> Any:
        s = self.system
        if name in self.groups:
            return self.groups[name]
        return s.srams.get(name) or s.drams[name]

    def link(self, master: str) -> FabricLink:
        if master not in self.links:
            self.links[master] = self.system.link(master)
        return self.links[master]


def build(cfg: SystemConfig, *, record_events: bool | None = None) -> Built:
    sc = cfg.sim
    s = System(cfg.name, fabric_clock=cfg.fabric.clock, fabric_hz=cfg.fabric_hz,
               record_events=sc.record_events if record_events is None else record_events,
               watchdog_cycles=sc.watchdog_cycles, max_cycles=sc.max_cycles, wall_limit_s=sc.wall_limit_s)
    for name, hz in cfg.clocks.items():
        if name != cfg.fabric.clock:
            s.add_clock(name, hz)
    b = Built(cfg, s)
    fc = cfg.fabric
    for m in cfg.memories:
        if m.kind == "sram" and m.fabric_split:
            if m.local_ports:
                raise ValueError(f"{m.name}: a fabric-split memory has no engine-local ports")
            width = max(m.data_width_bits, fc.data_width_bits)
            wb = width // 8
            per = m.capacity // m.banks
            if per % wb:
                raise ValueError(f"{m.name}: bank capacity not a multiple of the {wb}-byte bank word")
            banks = [s.add_sram(SramConfig(name=f"{m.name}{i}", base_addr=m.base + i * per, capacity_bytes=per,
                                           banks=1, data_width=width, read_latency=m.read_latency,
                                           write_latency=m.write_latency, port_type=m.port_type, n_ports=1,
                                           queue_depth=m.queue_depth, rsp_fifo_depth=m.rsp_fifo_depth,
                                           clock=fc.clock)) for i in range(m.banks)]
            mapper = BankMapper(m.banks, per // wb, m.mapping)
            b.groups[m.name] = BankGroupView(m.name, m.base, m.capacity, banks, mapper, wb)
            continue
        if m.kind == "sram":
            n_ports = len(m.local_ports) + (m.fabric_ports if m.on_fabric else 0)
            s.add_sram(SramConfig(name=m.name, base_addr=m.base, capacity_bytes=m.capacity, banks=m.banks,
                                  data_width=m.data_width_bits, read_latency=m.read_latency,
                                  write_latency=m.write_latency, port_type=m.port_type, n_ports=max(1, n_ports),
                                  queue_depth=m.queue_depth, arbitration=m.arbitration, mapping=m.mapping,
                                  rsp_fifo_depth=m.rsp_fifo_depth, clock=fc.clock))
            for i, eng in enumerate(m.local_ports):
                b.mem_port_of[(m.name, eng)] = i
        else:
            kw = dict(m.dram)
            s.add_dram(DramConfig(name=m.name, base_addr=m.base, capacity_bytes=m.capacity, **kw))
    s.add_interconnect(FabricConfig(name=fc.name, clock=fc.clock, topology=fc.topology,
                                    data_width_bits=fc.data_width_bits, arbitration=fc.arbitration,
                                    weights=fc.weights, max_outstanding_per_master=fc.max_outstanding_per_master,
                                    max_outstanding_per_target=fc.max_outstanding_per_target,
                                    input_queue_depth=fc.input_queue_depth, req_slices=fc.req_slices,
                                    rsp_slices=fc.rsp_slices, ordering=fc.ordering,
                                    max_burst_beats=fc.max_burst_beats, burst_setup_cycles=fc.burst_setup_cycles))
    for m in cfg.memories:
        if not m.on_fabric:
            continue
        if m.name in b.groups:
            g = b.groups[m.name]
            s.ic.add_target_group(m.name, g.banks, base=m.base, size=m.capacity, mapper=g.mapper, word_bytes=g.wb)
            continue
        tgt = b.mem(m.name)
        port = len(m.local_ports) if m.kind == "sram" else 0
        s.map_target(tgt, port=port)
    for name in fc.master_order:            # arbiter indices follow master_order (index 0 = highest fixed)
        b.link(name)
    for mst, tg in fc.access.items():
        s.ic.set_access(mst, set(tg))
    return b


def _dma(b: Built) -> DmaEngine:
    if b.dma is None:
        c = b.cfg.dma
        if c is None:
            raise ValueError("this configuration has no DMA (SilicaFlux-V release 1 has none)")
        dc = DmaConfig(name=c.name, clock=b.cfg.fabric.clock, engine=c.engine, data_width_bits=c.data_width_bits,
                       fifo_depth=c.fifo_depth, burst=c.burst, max_outstanding_reads=c.max_outstanding_reads,
                       max_outstanding_writes=c.max_outstanding_writes, dual_port=c.dual_port,
                       channels=c.channels, scatter_gather=c.scatter_gather,
                       descriptor_fetch_bytes=c.descriptor_fetch_bytes, prefetch_next=c.prefetch_next,
                       setup_cycles=c.setup_cycles, completion_cycles=c.completion_cycles)
        rd = b.link(c.name if not c.dual_port else f"{c.name}_rd")
        wr = b.link(f"{c.name}_wr") if c.dual_port else None
        b.dma = b.system.add_dma(dc, read_link=rd, write_link=wr)
    return b.dma


# ---------------------------------------------------------------------------- scenarios
def cpu_pattern(b: Built, *, pattern: str = "seq_read", n_mem: int = 2000, alu_per_mem: int = 3,
                branch_every: int = 0, data_memory: str = "sram", data_offset: int = 0, data_bytes: int = 16384,
                seed: int = 1, write_fraction: float = 0.3) -> tuple[ProgramMaster, ProgramMaster]:
    cc = b.cfg.cpu
    if cc is None:
        raise ValueError("configuration has no CPU")
    code = b.cfg.memory(cc.code_memory)
    dm = b.cfg.memory(data_memory)
    wl = CpuWorkload(pattern=pattern, n_mem=n_mem, alu_per_mem=alu_per_mem, branch_every=branch_every,
                     data_base=dm.base + data_offset, data_bytes=data_bytes, write_fraction=write_fraction, seed=seed)
    fetch, exe, info = cpu_programs(CpuConfig(name=cc.name, code_base=code.base + cc.code_base,
                                              code_bytes=cc.code_bytes, fetch_ahead=cc.fetch_ahead,
                                              cpi_alu=cc.cpi_alu), wl)
    if pattern == "pointer_chase":
        init_pointer_chase(b.mem(data_memory), n_mem, wl.data_base, data_bytes, 4, seed)
    s = b.system
    mi = s.add_master(f"{cc.name}_i", fetch, links={"default": b.link(f"{cc.name}_i")})
    md = s.add_master(f"{cc.name}_d", exe, links={"data": b.link(f"{cc.name}_d")}, overlap_compute=False)
    b.info["cpu"] = info
    return mi, md


def dma_copy(b: Built, *, src_mem: str, dst_mem: str, nbytes: int, src_off: int = 0, dst_off: int = 0,
             fill_seed: int = 3) -> Descriptor:
    d = _dma(b)
    src = b.cfg.memory(src_mem).base + src_off
    dst = b.cfg.memory(dst_mem).base + dst_off
    payload = bytes((i * 131 + fill_seed) & 0xFF for i in range(nbytes))
    b.mem(src_mem).write_bytes(src, payload)
    desc = d.submit(Descriptor.copy(src, dst, nbytes, label="copy"))
    b.info["dma_copy"] = {"src": src, "dst": dst, "bytes": nbytes, "payload": payload, "dst_mem": dst_mem}
    return desc


def verify_dma_copy(b: Built) -> bool:
    c = b.info["dma_copy"]
    return b.mem(c["dst_mem"]).read_bytes(c["dst"], c["bytes"]) == c["payload"]


def _engine_links(b: Built, engine: str, mem: str, names: list[str]) -> dict:
    sram = b.system.srams[mem]
    port = b.mem_port_of.get((mem, engine))
    if port is None:
        raise ValueError(f"{mem} has no local port for {engine}")
    return {n: b.system.sram_link(sram, port, f"{mem}.{engine}") for n in names[:1]} | (
        {n: b.system.sram_link(sram, b.mem_port_of[(mem, engine + "_b")], f"{mem}.{engine}_b") for n in names[1:]}
        if len(names) > 1 else {})


def _tensor_cfg(b: Built) -> TensorConfig:
    t = b.cfg.tensor
    return TensorConfig(name=t.name, rows=t.rows, cols=t.cols, precision=t.precision, acc_bits=t.acc_bits,
                        overhead_cycles=t.overhead_cycles, systolic_skew=t.systolic_skew,
                        operand_ports=t.operand_ports, k_block=t.k_block, input_buffers=t.input_buffers,
                        output_buffers=t.output_buffers, wb_words_per_access=t.wb_words_per_access,
                        fp_supported=t.fp_supported, max_outstanding=t.max_outstanding)


def _vector_cfg(b: Built) -> VectorConfig:
    v = b.cfg.vector
    return VectorConfig(name=v.name, lanes=v.lanes, elem_bits=v.elem_bits, registers=v.registers,
                        overhead_cycles=v.overhead_cycles, tail_cycles=v.tail_cycles, mul_cycles=v.mul_cycles,
                        port_mode=v.port_mode, max_outstanding=v.max_outstanding)


def gemm_local(b: Built, *, M: int, N: int, K: int, a_layout: str = "k_major") -> ProgramMaster:
    t = b.cfg.tensor
    sram = b.system.srams[t.local_memory]
    tc = _tensor_cfg(b)
    a_bytes = tc.operand_bytes(M * K)
    b_bytes = tc.operand_bytes(K * N)
    g = GemmKernel(M=M, N=N, K=K, a_base=0, b_base=_align(a_bytes, 64), c_base=_align(a_bytes, 64) +
                   _align(b_bytes, 64), a_layout=a_layout)
    need = g.c_base + M * N * t.acc_bits // 8
    if need > sram.capacity:
        raise ValueError(f"GEMM {M}x{N}x{K} needs {need} B of {t.local_memory} ({sram.capacity} B)")
    ops, info = tensor_program(tc, g, local_base=sram.base, word_bytes=sram.cfg.word_bytes)
    names = ["a", "b"] if tc.operand_ports == 2 else ["a"]
    links = _engine_links(b, t.name, t.local_memory, names)
    m = b.system.add_master(t.name, ops, links=links, max_outstanding=t.max_outstanding, issue_model="dae")
    b.info["tensor"] = info
    return m


def vector_local(b: Built, *, op: str = "vadd", n: int = 1024, stride: int = 1, align_offset: int = 0,
                 taps: int = 8, seed: int = 1) -> ProgramMaster:
    v = b.cfg.vector
    sram = b.system.srams[v.local_memory]
    vc = _vector_cfg(b)
    span = n * vc.elem_bytes * (stride if op == "strided" else (4 if op in ("gather", "scatter") else 1)) + 64
    k = VectorKernel(op=op, n=n, a_base=0, b_base=_align(span, 64), c_base=2 * _align(span, 64), stride=stride,
                     align_offset=align_offset, taps=taps, seed=seed)
    if k.c_base + span > sram.capacity:
        raise ValueError(f"vector kernel needs {k.c_base + span} B of {v.local_memory} ({sram.capacity} B)")
    if vc.port_mode == "per_lane":
        raise ValueError("per-lane vector ports need a local memory with one port per lane (use vector_lanes study)")
    ops, info = vector_program(vc, k, local_base=sram.base, word_bytes=sram.cfg.word_bytes)
    links = {"vmem": b.system.sram_link(sram, b.mem_port_of[(v.local_memory, v.name)], f"{v.local_memory}.{v.name}")}
    m = b.system.add_master(v.name, ops, links=links, max_outstanding=v.max_outstanding, issue_model="dae")
    b.info["vector"] = info
    return m


def _align(x: int, a: int) -> int:
    return -(-x // a) * a


def tile_pipeline(b: Built, *, M: int = 32, N: int = 32, K: int = 64, src_memory: str = "sram",
                  cpu_background: dict | None = None, ctrl_alu_per_tile: int = 12,
                  vector_post: bool = True, staging: str = "dma", copy_alu_per_word: int = 2) -> dict:
    """The SilicaFlux-V reference workload (see module docstring).

    ``staging='cpu'`` replaces the DMA by CPU copy loops (load word, store word, ``copy_alu_per_word``
    loop instructions at CPI 1 -- an optimistic loop: the taken loop branch is counted as an ALU op),
    which is how SilicaFlux-V release 1 (no DMA) fills the tile scratchpad.  Copied data values are not
    tracked in this mode (timing only)."""
    if staging not in ("dma", "cpu"):
        raise ValueError("staging must be 'dma' or 'cpu'")
    cfg = b.cfg
    if cfg.tensor is None or cfg.cpu is None:
        raise ValueError("tile_pipeline needs a CPU and a tensor engine")
    s = b.system
    tok = s.tokens
    t = cfg.tensor
    tc = _tensor_cfg(b)
    R, C = tc.rows, tc.cols
    acc_b = t.acc_bits // 8
    tspm = s.srams[t.local_memory]
    wb_ = tspm.cfg.word_bytes
    src = cfg.memory(src_memory)
    d = _dma(b) if staging == "dma" else None
    a_tile = tc.operand_bytes(R * K)              # A tile, k-major: K columns of R elements
    b_tile = tc.operand_bytes(K * C)
    c_tile = R * C * acc_b
    slot = _align(a_tile, 64) + _align(b_tile, 64) + _align(c_tile, 64)
    if 2 * slot > tspm.capacity:
        raise ValueError(f"double-buffered tile ({2 * slot} B) does not fit {t.local_memory} ({tspm.capacity} B)")
    tiles = [(i0, j0) for i0 in range(0, M, R) for j0 in range(0, N, C)]
    # operands in main memory: A_i tiles and B_j tiles stored contiguously per tile (pre-packed)
    a_src = {i0: src.base + 0x1000 + (i0 // R) * _align(a_tile, 64) for i0 in range(0, M, R)}
    b_off = 0x1000 + (M // R + 1) * _align(a_tile, 64)
    b_src = {j0: src.base + b_off + (j0 // C) * _align(b_tile, 64) for j0 in range(0, N, C)}
    c_dst0 = src.base + b_off + (N // C + 1) * _align(b_tile, 64)
    for i0, a in a_src.items():
        b.mem(src_memory).write_bytes(a, bytes(((i0 + k) * 7) & 0xFF for k in range(a_tile)))
    for j0, a in b_src.items():
        b.mem(src_memory).write_bytes(a, bytes(((j0 + k) * 11) & 0xFF for k in range(b_tile)))
    # ---- tensor engine: one 'tile' GEMM per output tile, operands in a TSPM slot
    te_ops: list = []
    ve_ops: list = []
    for n_t, (i0, j0) in enumerate(tiles):
        sl = n_t % 2
        base = sl * slot
        g = GemmKernel(M=R, N=C, K=K, a_base=base, b_base=base + _align(a_tile, 64),
                       c_base=base + _align(a_tile, 64) + _align(b_tile, 64), a_layout="k_major")
        wait = (f"dma_in.{n_t}",) + ((f"ve.{n_t - 1}",) if (vector_post and n_t > 0) else
                                     ((f"te.{n_t - 1}",) if n_t > 0 else ()))
        ops, _ = tensor_program(tc, g, local_base=tspm.base, word_bytes=wb_, start_wait=wait,
                                done_token=f"te.{n_t}")
        te_ops.extend(_reindex(ops, len(te_ops)))
        if vector_post and cfg.vector is not None:
            vc = _vector_cfg(b)
            vk = VectorKernel(op="vmul", n=R * C, a_base=g.c_base, b_base=g.c_base, c_base=g.c_base)
            vops, _ = vector_program(vc, vk, local_base=tspm.base, word_bytes=wb_, start_wait=(f"te.{n_t}",),
                                     done_token=f"ve.{n_t}")
            ve_ops.extend(_reindex(vops, len(ve_ops)))
    te_links = _engine_links(b, t.name, t.local_memory, ["a", "b"] if tc.operand_ports == 2 else ["a"])
    s.add_master(t.name, te_ops, links=te_links, max_outstanding=t.max_outstanding, issue_model="dae")
    if vector_post and cfg.vector is not None:
        v = cfg.vector
        s.add_master(v.name, ve_ops, links={"vmem": s.sram_link(tspm, b.mem_port_of[(v.local_memory, v.name)],
                                                                   f"{v.local_memory}.{v.name}")},
                     max_outstanding=v.max_outstanding, issue_model="dae")
    # ---- control CPU: programs the DMA through its registers on the fabric
    cc = cfg.cpu
    code = cfg.memory(cc.code_memory)
    ctrl: list = []
    fetch: list = []
    nfetch = 0
    words_code = cc.code_bytes // 4

    def instr(op_factory) -> None:
        nonlocal nfetch
        i = nfetch
        wait = [f"cpu.x{i - cc.fetch_ahead}"] if i >= cc.fetch_ahead else []
        fetch.append(MemOp(TxnKind.READ, code.base + cc.code_base + (i % words_code) * 4, 4, wait=tuple(wait),
                           post=f"cpu.f{i}", tag="ifetch"))
        ctrl.append(op_factory(i))
        nfetch += 1

    def prog_dma(desc_fn, wait_tokens: tuple[str, ...]) -> None:
        for r in range(4):                         # SRC, DST, LEN, CTRL (DataFabric DMA registers)
            last = r == 3

            def mk(i, r=r, last=last, w=wait_tokens if r == 0 else ()):
                return MemOp(TxnKind.WRITE, DMA_REG_BASE + 4 * r, 4, data=r, wait=(f"cpu.f{i}",) + w,
                             post=f"cpu.x{i}", tag="dma_reg", link="data",
                             deps=(len(ctrl) - 1,) if ctrl else (),
                             on_complete=(lambda tx, fn=desc_fn: d.submit(fn())) if last else None)
            instr(mk)

    def alu(n: int) -> None:
        for _ in range(n):
            instr(lambda i: ComputeOp(cc.cpi_alu, wait=(f"cpu.f{i}",), post=f"cpu.x{i}", tag="alu",
                                      deps=(len(ctrl) - 1,) if ctrl else ()))

    def din(n_t: int):
        i0, j0 = tiles[n_t]
        sl = n_t % 2
        base = tspm.base + sl * slot
        segs_a = Descriptor.copy(a_src[i0], base, a_tile)
        segs_b = Descriptor.copy(b_src[j0], base + _align(a_tile, 64), b_tile)

        def make() -> Descriptor:
            if d.cfg.scatter_gather:
                return Descriptor(segs_a.segments + segs_b.segments, label=f"in{n_t}", post=f"dma_in.{n_t}")
            # without scatter-gather the A and B copies are two descriptors; the token marks the second
            d.submit(Descriptor.copy(a_src[i0], base, a_tile, label=f"inA{n_t}"))
            return Descriptor.copy(b_src[j0], base + _align(a_tile, 64), b_tile, label=f"inB{n_t}",
                                   post=f"dma_in.{n_t}")
        return make

    def dout(n_t: int):
        sl = n_t % 2
        c_src = tspm.base + sl * slot + _align(a_tile, 64) + _align(b_tile, 64)
        return lambda: Descriptor.copy(c_src, c_dst0 + n_t * _align(c_tile, 64), c_tile, label=f"out{n_t}",
                                       post=f"dma_out.{n_t}")

    def cpu_copy(src_a: int, dst_a: int, nbytes: int, post: str, wait_tokens: tuple[str, ...]) -> None:
        for wi in range(-(-nbytes // 4)):
            w0 = wait_tokens if wi == 0 else ()

            def ld(i, a=src_a + 4 * wi, w0=w0):
                return MemOp(TxnKind.READ, a, 4, wait=(f"cpu.f{i}",) + w0, post=f"cpu.x{i}", tag="cpu_copy_ld",
                             link="data", deps=(len(ctrl) - 1,) if ctrl else ())
            instr(ld)

            def st(i, a=dst_a + 4 * wi):
                return MemOp(TxnKind.WRITE, a, 4, data=0, wait=(f"cpu.f{i}",), post=f"cpu.x{i}", tag="cpu_copy_st",
                             link="data", deps=(len(ctrl) - 1,))
            instr(st)
            alu(copy_alu_per_word)
        ctrl.append(ComputeOp(0, deps=(len(ctrl) - 1,), post=post, tag="copy_done"))

    done_tok = "ve" if (vector_post and cfg.vector is not None) else "te"
    for n_t in range(len(tiles)):
        # slot n_t % 2 is free once tile n_t-2 has been written back
        w = (f"dma_out.{n_t - 2}",) if n_t >= 2 else ()
        if staging == "dma":
            prog_dma(din(n_t), w)
        else:
            i0, j0 = tiles[n_t]
            base = tspm.base + (n_t % 2) * slot
            cpu_copy(a_src[i0], base, a_tile, f"cpuA.{n_t}", w)
            cpu_copy(b_src[j0], base + _align(a_tile, 64), b_tile, f"dma_in.{n_t}", ())
        alu(ctrl_alu_per_tile)
        if n_t >= 1:
            if staging == "dma":
                prog_dma(dout(n_t - 1), (f"{done_tok}.{n_t - 1}",))
            else:
                c_src = tspm.base + ((n_t - 1) % 2) * slot + _align(a_tile, 64) + _align(b_tile, 64)
                cpu_copy(c_src, c_dst0 + (n_t - 1) * _align(c_tile, 64), c_tile, f"dma_out.{n_t - 1}",
                         (f"{done_tok}.{n_t - 1}",))
    if staging == "dma":
        prog_dma(dout(len(tiles) - 1), (f"{done_tok}.{len(tiles) - 1}",))
    else:
        n_l = len(tiles) - 1
        c_src = tspm.base + (n_l % 2) * slot + _align(a_tile, 64) + _align(b_tile, 64)
        cpu_copy(c_src, c_dst0 + n_l * _align(c_tile, 64), c_tile, f"dma_out.{n_l}", (f"{done_tok}.{n_l}",))
    s.add_master("cpu_i", fetch, links={"default": b.link("cpu_i")})
    s.add_master("cpu_d", ctrl, links={"data": b.link("cpu_d")}, overlap_compute=False)
    if cpu_background:
        bg = dict(cpu_background)
        dm = cfg.memory(bg.pop("memory", "sram"))
        prog = program(bg.pop("pattern", "seq_read"), n=bg.pop("n", 2000), base=dm.base + bg.pop("offset", 0x8000),
                       region_bytes=bg.pop("region_bytes", 8192), **bg)
        s.add_master("cpu_bg", prog, links={"default": b.link("cpu_bg")}, max_outstanding=1)
    b.info["tile_pipeline"] = {"tiles": len(tiles), "M": M, "N": N, "K": K, "useful_macs": M * N * K,
                               "staging": staging,
                               "tile_bytes": {"A": a_tile, "B": b_tile, "C": c_tile}, "slot_bytes": slot,
                               "array": f"{R}x{C}"}
    return b.info["tile_pipeline"]


def _reindex(ops: list, offset: int) -> list:
    """Shift intra-program dependency indices when concatenating programs."""
    out = []
    for op in ops:
        op.deps = tuple(d + offset for d in op.deps)
        out.append(op)
    return out


def injection(b: Built, *, masters: list[dict], seed: int = 1) -> list[ProgramMaster]:
    """Open-loop injection: each entry {name, target, rate, n, write_fraction, region_bytes, offset,
    arrivals, max_outstanding}."""
    out = []
    for i, m in enumerate(masters):
        tm = b.cfg.memory(m["target"])
        prog = program("inject", n=m.get("n", 2000), base=tm.base + m.get("offset", 0),
                       region_bytes=m.get("region_bytes", min(tm.capacity, 65536)), rate=m["rate"],
                       write_fraction=m.get("write_fraction", 0.3), arrivals=m.get("arrivals", "bernoulli"),
                       seed=seed + 101 * i)
        out.append(b.system.add_master(m["name"], prog, links={"default": b.link(m["name"])},
                                       max_outstanding=m.get("max_outstanding", 1)))
    return out


def cpu_vs_dma(b: Built, *, nbytes: int = 8192, cpu_n: int = 3000, same_bank: bool = True,
               cpu_pattern_name: str = "seq_read", src_off: int = 0x0, dst_off: int | None = None,
               cpu_dependent: bool = False) -> dict:
    """A DMA copy inside main SRAM competing with a CPU data stream (experiments E and J)."""
    mem = b.cfg.memory("sram")
    if dst_off is None:
        dst_off = mem.capacity // 4                     # another bank with the default 4-bank contiguous map
    dma_copy(b, src_mem="sram", dst_mem="sram", nbytes=nbytes, src_off=src_off, dst_off=dst_off)
    cpu_off = (src_off + nbytes) if same_bank else (mem.capacity // 2)
    prog = program(cpu_pattern_name, n=cpu_n, base=mem.base + cpu_off, region_bytes=4096, dependent=cpu_dependent)
    b.system.add_master("cpu_bg", prog, links={"default": b.link("cpu_bg")}, max_outstanding=1)
    return {"units": nbytes}


def cpu_vs_tensor(b: Built, *, M: int = 16, N: int = 16, K: int = 128, cpu_n: int = 2000,
                  cpu_region_off: int = 0x3000) -> dict:
    """CPU loads to the tile scratchpad while the tensor engine streams operands from it (experiment F)."""
    gemm_local(b, M=M, N=N, K=K)
    t = b.cfg.tensor
    tm = b.cfg.memory(t.local_memory)
    prog = program("seq_read", n=cpu_n, base=tm.base + cpu_region_off, region_bytes=2048, dependent=True)
    b.system.add_master("cpu_bg", prog, links={"default": b.link("cpu_bg")}, max_outstanding=1)
    return {"units": b.info["tensor"]["useful_macs"]}


def multi_stream(b: Built, *, streams: int = 3, n: int = 2000, pattern: str = "strided", stride_words: int = 4,
                 spacing: int = 0x4000, memory: str = "sram") -> dict:
    """Independent masters streaming over one memory (bank-mapping study, experiment I)."""
    mem = b.cfg.memory(memory)
    for i in range(streams):
        prog = program(pattern, n=n, base=mem.base + i * spacing, region_bytes=min(spacing, 16384) or 4096,
                       stride_words=stride_words, seed=11 + i)
        b.system.add_master(f"stream{i}", prog, links={"default": b.link(f"stream{i}")}, max_outstanding=1)
    return {"units": streams * n}
