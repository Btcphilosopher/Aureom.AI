"""Typed simulation events.

Every observable state change of a transaction, a DMA burst, a compute task or a
stall is recorded as a :class:`SimEvent`.  Events are produced only by the
simulator while it runs (or by the RTL trace importer); nothing in BandwidthLab
synthesises decorative events.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class EventType(str, Enum):
    # --- the event set required by the BandwidthLab brief (section 4)
    REQUEST_GENERATED = "REQUEST_GENERATED"
    REQUEST_ACCEPTED = "REQUEST_ACCEPTED"
    ARBITRATION_GRANTED = "ARBITRATION_GRANTED"
    QUEUE_ENTERED = "QUEUE_ENTERED"
    QUEUE_EXITED = "QUEUE_EXITED"
    MEMORY_SERVICE_STARTED = "MEMORY_SERVICE_STARTED"
    MEMORY_SERVICE_COMPLETED = "MEMORY_SERVICE_COMPLETED"
    RESPONSE_GENERATED = "RESPONSE_GENERATED"
    RESPONSE_ACCEPTED = "RESPONSE_ACCEPTED"
    DMA_BURST_STARTED = "DMA_BURST_STARTED"
    DMA_BURST_COMPLETED = "DMA_BURST_COMPLETED"
    COMPUTE_STARTED = "COMPUTE_STARTED"
    COMPUTE_COMPLETED = "COMPUTE_COMPLETED"
    STALL_STARTED = "STALL_STARTED"
    STALL_ENDED = "STALL_ENDED"
    # --- diagnostic events (additional; derived from the same simulator state)
    REQUEST_ISSUED = "REQUEST_ISSUED"            # valid asserted towards the fabric
    SLAVE_ARRIVAL = "SLAVE_ARRIVAL"              # request reached the target port (after register slices)
    BANK_CONFLICT = "BANK_CONFLICT"              # a word lost bank arbitration this cycle
    BACKPRESSURE = "BACKPRESSURE"                # handshake refused (ready low / queue full)
    REQUEST_REJECTED = "REQUEST_REJECTED"        # dropped by an admission policy that allows drops
    ERROR_RESPONSE = "ERROR_RESPONSE"            # decode / slave error
    TRANSACTION_CANCELLED = "TRANSACTION_CANCELLED"
    DMA_DESCRIPTOR_STARTED = "DMA_DESCRIPTOR_STARTED"
    DMA_DESCRIPTOR_COMPLETED = "DMA_DESCRIPTOR_COMPLETED"


REQUIRED_EVENT_TYPES = tuple(EventType)[:15]


@dataclass(frozen=True, slots=True)
class SimEvent:
    """One recorded event.

    ``time_fs`` is the shared integer time base; ``domain``/``cycle`` give the clock
    domain of the component that produced the event and the cycle index in that
    domain.  ``seq`` is globally unique and strictly increasing in emission order,
    which makes the order of simultaneous events deterministic and reproducible.
    """

    time_fs: int
    domain: str
    cycle: int
    etype: EventType
    seq: int
    tid: int | None
    src: str
    dst: str
    payload: dict[str, Any] | None
    dep_state: str

    COLUMNS = ("time_fs", "domain", "cycle", "etype", "seq", "tid", "src", "dst", "payload", "dep_state")

    def as_dict(self) -> dict[str, Any]:
        return {"time_fs": self.time_fs, "domain": self.domain, "cycle": self.cycle,
                "etype": self.etype.value, "seq": self.seq, "tid": self.tid, "src": self.src,
                "dst": self.dst, "payload": self.payload, "dep_state": self.dep_state}
