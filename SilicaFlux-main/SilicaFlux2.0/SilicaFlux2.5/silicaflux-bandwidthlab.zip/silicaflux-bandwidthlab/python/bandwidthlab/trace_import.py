"""RTL trace import (LEVEL 3 input).

Supported formats (auto-detected from the header):

* DataFabric ``sfb_trace_monitor`` CSV (silicaflux-datafabric tb/common/sfb_trace_monitor.sv):
  ``cycle,event,master,id,addr,op,size,bank,slave,error,stall_cycles`` with events ISSUE /
  ACCEPT / RESPONSE / CONFLICT -- produced from the observed SFB2 valid/ready signals.
  The MemoryLab copies (``*.memorylab.csv``) use the same columns.
* BandwidthLab transaction CSV/JSON (``transactions.csv`` written by ``export.write_run``)
  or any CSV with columns master, id, issue_cycle, accept_cycle, response_cycle.
* BandwidthLab RTL-harness logs (``ACC <cycle> <m> <i>`` / ``RSP <cycle> <m> <i> <err> <data>``).

The importer returns one row per transaction with cycle-domain timestamps; nothing is
synthesised -- a transaction missing an ACCEPT or RESPONSE stays incomplete and is
reported.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


class TraceFormatError(ValueError):
    pass


DF_COLUMNS = ["cycle", "event", "master", "id", "addr", "op", "size", "bank", "slave", "error", "stall_cycles"]


def read_sfb_trace(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = [c for c in DF_COLUMNS if c not in df.columns]
    if missing:
        raise TraceFormatError(f"{path}: not an sfb_trace_monitor trace (missing {missing})")
    key = ["master", "id"]
    out = None
    for ev, col in (("ISSUE", "issue_cycle"), ("ACCEPT", "accept_cycle"), ("RESPONSE", "response_cycle")):
        part = df[df["event"] == ev].groupby(key, as_index=False).agg(
            **{col: ("cycle", "min")}, addr=("addr", "first"), op=("op", "first"), slave=("slave", "first"),
            error=("error", "max"))
        if out is None:
            out = part
        else:
            out = out.merge(part[key + [col]], on=key, how="outer")
    conf = df[df["event"] == "CONFLICT"].groupby(key).size().rename("conflict_events").reset_index()
    out = out.merge(conf, on=key, how="left").fillna({"conflict_events": 0})
    out["source_format"] = "sfb_trace_monitor"
    return out.sort_values(["accept_cycle", "master"]).reset_index(drop=True)


def read_harness_log(path: str | Path) -> pd.DataFrame:
    acc: dict[tuple[int, int], int] = {}
    rsp: dict[int, list[tuple[int, int, int]]] = {}
    for line in Path(path).read_text().splitlines():
        f = line.split()
        if not f:
            continue
        if f[0] == "ACC":
            acc[(int(f[2]), int(f[3]))] = int(f[1])
        elif f[0] == "RSP":
            rsp.setdefault(int(f[2]), []).append((int(f[1]), int(f[4]), int(f[5], 16)))
    rows = []
    for m in sorted({k[0] for k in acc}):
        idx = sorted(i for (mm, i) in acc if mm == m)
        rs = sorted(rsp.get(m, []))
        for k, i in enumerate(idx):                         # responses are in order per master (SFB2)
            r = rs[k] if k < len(rs) else (None, None, None)
            rows.append({"master": m, "id": i, "accept_cycle": acc[(m, i)], "response_cycle": r[0],
                         "error": r[1], "rdata": r[2], "source_format": "bandwidthlab_harness"})
    return pd.DataFrame(rows)


def read_bandwidthlab(path: str | Path, clock_hz: float | None = None) -> pd.DataFrame:
    p = Path(path)
    df = pd.read_json(p) if p.suffix == ".json" else pd.read_csv(p)
    if {"accept_cycle", "response_cycle"} <= set(df.columns):
        return df
    if "t_issued" in df.columns:
        meta = p.parent / "run_meta.json"
        period = json.loads(meta.read_text())["period_fs"] if meta.exists() else (1e15 / clock_hz if clock_hz else None)
        if period is None:
            raise TraceFormatError("transactions.csv needs run_meta.json or --clock-hz for the cycle conversion")
        out = pd.DataFrame({"master": df["master"], "id": df["tid"], "addr": df["addr"], "op": df["op"],
                            "slave": df["dst"], "error": (df["status"] != "OK").astype(int)})
        for a, b in (("t_issued", "issue_cycle"), ("t_accepted", "accept_cycle"), ("t_completed", "response_cycle")):
            out[b] = df[a] / period
        out["source_format"] = "bandwidthlab_transactions"
        return out
    raise TraceFormatError(f"{p}: unrecognised BandwidthLab trace")


def read_trace(path: str | Path, clock_hz: float | None = None) -> pd.DataFrame:
    p = Path(path)
    head = p.open().readline()
    if head.startswith("cycle,event,master"):
        return read_sfb_trace(p)
    if head.startswith(("ACC ", "RSP ")):
        return read_harness_log(p)
    return read_bandwidthlab(p, clock_hz)


def trace_metrics(df: pd.DataFrame) -> dict[str, Any]:
    """Per-master and overall metrics of an imported trace (cycles of the traced clock)."""
    out: dict[str, Any] = {"transactions": int(len(df))}
    done = df.dropna(subset=["accept_cycle", "response_cycle"])
    out["complete"] = int(len(done))
    out["incomplete"] = int(len(df) - len(done))
    if len(done) == 0:
        return out
    span = float(done["response_cycle"].max() - done["accept_cycle"].min() + 1)
    out["span_cycles"] = span
    out["transactions_per_cycle"] = len(done) / span
    lat = (done["response_cycle"] - done["accept_cycle"]).to_numpy(dtype=float)
    out["accept_to_response"] = _stats(lat)
    if "issue_cycle" in done.columns and done["issue_cycle"].notna().all():
        out["issue_to_response"] = _stats((done["response_cycle"] - done["issue_cycle"]).to_numpy(dtype=float))
        out["issue_to_accept"] = _stats((done["accept_cycle"] - done["issue_cycle"]).to_numpy(dtype=float))
    per = {}
    for m, g in done.groupby("master"):
        sp = float(g["response_cycle"].max() - g["accept_cycle"].min() + 1)
        d = {"n": int(len(g)), "transactions_per_cycle": len(g) / sp if sp else 0.0,
             "accept_to_response": _stats((g["response_cycle"] - g["accept_cycle"]).to_numpy(dtype=float))}
        if "issue_cycle" in g.columns and g["issue_cycle"].notna().all():
            d["issue_to_accept"] = _stats((g["accept_cycle"] - g["issue_cycle"]).to_numpy(dtype=float))
        if "conflict_events" in g.columns:
            d["conflict_events"] = int(g["conflict_events"].sum())
        per[str(m)] = d
    out["per_master"] = per
    if "error" in done.columns:
        out["errors"] = int(done["error"].fillna(0).astype(int).sum())
    return out


def _stats(v: np.ndarray) -> dict[str, float]:
    if v.size == 0:
        return {}
    return {"n": int(v.size), "mean": float(v.mean()), "p50": float(np.percentile(v, 50)),
            "p95": float(np.percentile(v, 95)), "p99": float(np.percentile(v, 99)), "max": float(v.max()),
            "min": float(v.min())}
