"""Simplified external-memory (DDR / LPDDR / HBM-class) controller.

FIDELITY: this is a *simplified memory-controller model*, not a JEDEC-accurate DRAM
simulator.  It models channels, banks with an open-row buffer, a request queue per
channel, FCFS or FR-FCFS scheduling, ACT/PRE/column timing (tRCD, tRP, tCL, tCWL),
burst occupancy of the data bus, read/write turnaround penalties and a clock-domain
crossing to the fabric.  It does NOT model refresh, tRAS/tRC/tFAW/tRRD windows, power-down,
command-bus contention beyond one command per channel per cycle, ODT, ECC or PHY
training.  For JEDEC-accurate results use the Ramulator 2 adapter (``ramulator.py``).

No device timing parameters are built in: every preset in ``configs/`` is labelled
HYPOTHETICAL with its rationale, and real values must come from a datasheet or an
imported configuration file.

Address mapping (burst-interleaved): burst index = addr // burst_bytes;
channel = burst mod C; then column (bursts per row), then bank, then row.

Clock-domain crossing: a request accepted on a fabric edge at time T becomes visible to
the controller at its first edge >= T + sync_stages x controller period; a response
completed at controller edge T2 becomes visible to the fabric at its first edge >=
T2 + sync_stages x fabric period (two-flop synchroniser of an async FIFO pointer).
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable

from .events import EventType
from .scheduler import PRIO_COMPLETE, Scheduler
from .transaction import MemTransaction, TransactionLedger, TxnState, TxnStatus
from .units import ceil_div


class DramConfigError(ValueError):
    pass


@dataclass
class DramConfig:
    name: str = "dram"
    kind: str = "DDR"                    # DDR | LPDDR | HBM (label only; timing comes from the fields)
    clock: str = "dram"                  # controller clock domain (= memory clock in this model)
    base_addr: int = 0x8000_0000
    capacity_bytes: int = 256 * 1024 * 1024
    channels: int = 1
    banks: int = 8
    data_width_bits: int = 16            # per channel
    burst_length: int = 16               # beats per burst (BL)
    transfers_per_clock: int = 2         # DDR = 2
    row_bytes: int = 2048                # row (page) size per bank
    tRCD: int = 0                        # ACT -> column command, controller cycles
    tRP: int = 0                         # PRE -> ACT
    tCL: int = 0                         # READ -> first data
    tCWL: int = 0                        # WRITE -> first data
    tWTR: int = 0                        # write data end -> read command (turnaround)
    tRTW: int = 0                        # read data end -> write data (turnaround)
    queue_depth: int = 16                # per channel
    scheduler: str = "frfcfs"            # fcfs | frfcfs
    page_policy: str = "open"            # open | closed
    sync_stages: int = 2
    fabric_ports: int = 1
    fabric_queue_depth: int = 4          # fabric-side request FIFO per port
    provenance: str = "HYPOTHETICAL"

    def __post_init__(self) -> None:
        if self.channels < 1 or self.banks < 1:
            raise DramConfigError("channels and banks must be >= 1")
        if self.scheduler not in ("fcfs", "frfcfs") or self.page_policy not in ("open", "closed"):
            raise DramConfigError("scheduler fcfs|frfcfs, page_policy open|closed")
        if self.burst_length < 1 or self.transfers_per_clock < 1 or self.data_width_bits % 8:
            raise DramConfigError("invalid burst / width")
        if self.row_bytes % self.burst_bytes:
            raise DramConfigError("row_bytes must be a multiple of burst_bytes")
        for k in ("tRCD", "tRP", "tCL", "tCWL", "tWTR", "tRTW"):
            if getattr(self, k) < 0:
                raise DramConfigError(f"{k} must be >= 0")
        if self.sync_stages < 0 or self.queue_depth < 1 or self.fabric_queue_depth < 1:
            raise DramConfigError("sync_stages >= 0, queue depths >= 1")

    @property
    def burst_bytes(self) -> int:
        return self.data_width_bits // 8 * self.burst_length

    @property
    def tBL(self) -> int:
        return ceil_div(self.burst_length, self.transfers_per_clock)

    def peak_bytes_per_cycle(self) -> float:
        """ANALYTICAL ceiling per controller cycle (all channels, data bus 100 % busy)."""
        return self.channels * self.burst_bytes / self.tBL


@dataclass
class _DReq:
    txn: MemTransaction
    port: int
    ch: int
    bank: int
    row: int
    visible_fs: int
    seq: int
    ready_fabric_cycle: int | None = None
    done: bool = False


@dataclass
class _Bank:
    open_row: int | None = None
    ready: int = 0                       # controller cycle when the bank accepts the next command
    hits: int = 0
    misses: int = 0
    conflicts: int = 0


@dataclass
class _Chan:
    queue: list = field(default_factory=list)
    banks: list = field(default_factory=list)
    bus_free: int = 0                    # first free data-bus cycle
    last_dir: str = ""
    last_data_end: int = 0
    busy_data_cycles: int = 0
    turnarounds: int = 0
    occ_sum: int = 0
    occ_max: int = 0


class DramController:
    """Controller side (controller clock domain)."""
    kind = "dram_ctrl"
    rank = 0

    def __init__(self, target: "DramTarget") -> None:
        self.t = target
        self.name = f"{target.name}.ctrl"
        self.drv = target.sched.driver(target.cfg.clock)
        self.drv.attach(self)

    def busy(self) -> bool:
        return any(ch.queue for ch in self.t.chans)

    def on_accept(self, cyc: int) -> None:
        self.t._schedule(cyc)


class DramTarget:
    """Fabric-facing side (fabric clock domain), same target protocol as BankedSram."""
    kind = "dram"
    rank = 0

    def __init__(self, sched: Scheduler, cfg: DramConfig, *, fabric_clock: str,
                 ledger: TransactionLedger | None = None) -> None:
        self.sched, self.cfg, self.ledger = sched, cfg, ledger
        self.name = cfg.name
        self.domain = fabric_clock
        self.fdrv = sched.driver(fabric_clock)
        self.cclk = sched.clocks[cfg.clock]
        self.fclk = sched.clocks[fabric_clock]
        self.chans = [_Chan(banks=[_Bank() for _ in range(cfg.banks)]) for _ in range(cfg.channels)]
        self.slot: list[MemTransaction | None] = [None] * cfg.fabric_ports
        self.fq_len: list[int] = [0] * cfg.fabric_ports            # accepted, not yet responded (per port)
        self.fq_len_reg: list[int] = [0] * cfg.fabric_ports
        self.rsp: list[deque[_DReq]] = [deque() for _ in range(cfg.fabric_ports)]
        self.accept_cb: list[Callable | None] = [None] * cfg.fabric_ports
        self.popped: list[bool] = [False] * cfg.fabric_ports
        self.mem: dict[int, int] = {}
        self.seq = 0
        self.lat_ctrl_cycles: list[int] = []
        self.reads = self.writes = 0
        self.first_ccyc: int | None = None
        self.last_ccyc = 0
        self.fdrv.attach(self)
        self.ctrl = DramController(self)
        sched.register(self)

    # ------------------------------------------------------------------ geometry
    @property
    def base(self) -> int:
        return self.cfg.base_addr

    @property
    def capacity(self) -> int:
        return self.cfg.capacity_bytes

    def map(self, addr: int) -> tuple[int, int, int]:
        cfg = self.cfg
        b = (addr - cfg.base_addr) // cfg.burst_bytes
        ch = b % cfg.channels
        rest = b // cfg.channels
        rest //= cfg.row_bytes // cfg.burst_bytes          # column
        return ch, rest % cfg.banks, rest // cfg.banks

    # ------------------------------------------------------------------ target protocol (fabric side)
    def outstanding(self) -> int:
        return sum(1 for s in self.slot if s is not None) + sum(self.fq_len)

    def busy(self) -> bool:
        # responses still in the controller wake this domain when they become visible
        return any(s is not None for s in self.slot) or any(q and q[0].done for q in self.rsp)

    def can_present(self, port: int) -> bool:
        return self.slot[port] is None

    def set_accept_callback(self, port: int, cb: Callable) -> None:
        self.accept_cb[port] = cb

    def present(self, port: int, txn: MemTransaction) -> None:
        self.slot[port] = txn
        if txn.state < TxnState.AT_TARGET:
            txn.advance(TxnState.AT_TARGET, self.sched.now)
        txn.path.append(self.name)
        self.fdrv.wake()

    def on_response(self, cyc: int) -> None:
        for p in range(self.cfg.fabric_ports):
            self.fq_len_reg[p] = self.fq_len[p]
            self.popped[p] = False

    def on_accept(self, cyc: int) -> None:
        cfg = self.cfg
        for p in range(cfg.fabric_ports):
            t = self.slot[p]
            if t is None or self.fq_len_reg[p] >= cfg.fabric_queue_depth:
                continue
            ch, bank, row = self.map(t.addr)
            if self.chans[ch].queue and len(self.chans[ch].queue) >= cfg.queue_depth:
                continue
            self.slot[p] = None
            now = self.sched.now
            if t.t_accepted is None:
                t.mark_accepted(now)
                if self.ledger is not None:
                    self.ledger.on_accepted(t)
                self.sched.emit(EventType.REQUEST_ACCEPTED, domain=self.domain, txn=t, src=t.master, dst=self.name)
            if not (self.base <= t.addr and t.addr + t.size <= self.base + self.capacity):
                t.status, t.error = TxnStatus.SLAVE_ERROR, True
            vis = now + cfg.sync_stages * self.cclk.period_fs
            r = _DReq(t, p, ch, bank, row, vis, self.seq)
            self.seq += 1
            self.fq_len[p] += 1
            self.rsp[p].append(r)
            self.chans[ch].queue.append(r)
            t.meta["_acc_fcycle"] = cyc
            self.ctrl.drv.wake(vis)
            cb = self.accept_cb[p]
            if cb is not None:
                cb(t, cyc)

    def peek_response(self, port: int, cyc: int) -> MemTransaction | None:
        q = self.rsp[port]
        if q and q[0].done and q[0].ready_fabric_cycle is not None and q[0].ready_fabric_cycle <= cyc:
            return q[0].txn
        return None

    def pop_response(self, port: int, cyc: int) -> MemTransaction:
        r = self.rsp[port].popleft()
        self.fq_len[port] -= 1
        self.popped[port] = True
        r.txn.advance(TxnState.RESPONSE, self.sched.now)
        return r.txn

    # ------------------------------------------------------------------ controller (controller clock)
    def _schedule(self, ccyc: int) -> None:
        cfg = self.cfg
        now = self.sched.now
        if self.first_ccyc is None:
            self.first_ccyc = ccyc
        self.last_ccyc = ccyc
        for ch in self.chans:
            vis = [r for r in ch.queue if r.visible_fs <= now]
            ch.occ_sum += len(ch.queue)
            ch.occ_max = max(ch.occ_max, len(ch.queue))
            cand = [r for r in vis if ch.banks[r.bank].ready <= ccyc]
            if not cand:
                continue
            if cfg.scheduler == "frfcfs":
                hits = [r for r in cand if ch.banks[r.bank].open_row == r.row]
                r = min(hits or cand, key=lambda x: x.seq)
            else:
                oldest = min(vis, key=lambda x: x.seq)
                if oldest not in cand:
                    continue
                r = oldest
            ch.queue.remove(r)
            self._issue(ch, r, ccyc)

    def _issue(self, ch: _Chan, r: _DReq, c: int) -> None:
        cfg = self.cfg
        b = ch.banks[r.bank]
        t = r.txn
        if b.open_row == r.row:
            col = c
            b.hits += 1
            kind = "hit"
        elif b.open_row is None:
            col = c + cfg.tRCD
            b.misses += 1
            kind = "miss"
        else:
            col = c + cfg.tRP + cfg.tRCD
            b.conflicts += 1
            kind = "conflict"
        is_w = t.op == "W"
        data_start = col + (cfg.tCWL if is_w else cfg.tCL)
        if ch.last_dir and ch.last_dir != ("W" if is_w else "R"):
            pen = cfg.tWTR if ch.last_dir == "W" else cfg.tRTW
            data_start = max(data_start, ch.last_data_end + pen)
            ch.turnarounds += 1
        data_start = max(data_start, ch.bus_free)
        data_end = data_start + cfg.tBL
        ch.bus_free = data_end
        ch.last_dir, ch.last_data_end = ("W" if is_w else "R"), data_end
        ch.busy_data_cycles += cfg.tBL
        b.ready = col + 1 if cfg.page_policy == "open" else data_end + cfg.tRP
        b.open_row = r.row if cfg.page_policy == "open" else None
        now = self.sched.now
        if t.state < TxnState.SERVICE_STARTED:
            t.advance(TxnState.SERVICE_STARTED, now)
        self.sched.emit(EventType.MEMORY_SERVICE_STARTED, domain=cfg.clock, txn=t, src=self.name, dst=t.master,
                        payload={"channel": self.chans.index(ch), "bank": r.bank, "row": r.row, "row_buffer": kind})
        # functional data (word granularity, little endian)
        if t.status == TxnStatus.PENDING or t.status == TxnStatus.OK:
            if is_w:
                self._write(t)
                self.writes += 1
            else:
                t.data = self._read(t)
                self.reads += 1
        done_fs = self.cclk.edge(data_end)

        def done(r: _DReq = r, data_end: int = data_end, c0: int = c) -> None:
            tt = r.txn
            tt.advance(TxnState.SERVICE_DONE, self.sched.now)
            if tt.status == TxnStatus.PENDING:
                tt.status = TxnStatus.OK
            self.sched.emit(EventType.MEMORY_SERVICE_COMPLETED, domain=cfg.clock, txn=tt, src=self.name,
                            dst=tt.master)
            self.sched.emit(EventType.RESPONSE_GENERATED, domain=cfg.clock, txn=tt, src=self.name, dst=tt.master,
                            payload={"error": tt.status != TxnStatus.OK})
            self.lat_ctrl_cycles.append(data_end - c0)
            vis = self.sched.now + cfg.sync_stages * self.fclk.period_fs
            r.ready_fabric_cycle = self.fclk.edge_index_at_or_after(vis)
            r.done = True
            self.fdrv.wake(self.fclk.edge(r.ready_fabric_cycle))
        self.sched.schedule_at(done_fs, done, PRIO_COMPLETE, f"{self.name}.data_done")

    def _write(self, t: MemTransaction) -> None:
        mask = t.mask
        for i in range(t.size):
            if mask is None or (mask >> i) & 1:
                self.mem[t.addr + i] = ((t.data or 0) >> (8 * i)) & 0xFF

    def _read(self, t: MemTransaction) -> int:
        v = 0
        for i in range(t.size):
            v |= self.mem.get(t.addr + i, 0) << (8 * i)
        return v

    def write_bytes(self, addr: int, data: bytes) -> None:
        for i, b in enumerate(data):
            self.mem[addr + i] = b

    def read_bytes(self, addr: int, n: int) -> bytes:
        return bytes(self.mem.get(addr + i, 0) for i in range(n))

    # ------------------------------------------------------------------ statistics
    def stats(self) -> dict:
        span = max(1, self.last_ccyc - (self.first_ccyc or 0) + 1)
        chans = []
        for i, ch in enumerate(self.chans):
            h = sum(b.hits for b in ch.banks)
            m = sum(b.misses for b in ch.banks)
            c = sum(b.conflicts for b in ch.banks)
            n = h + m + c
            chans.append({"channel": i, "row_hits": h, "row_misses": m, "row_conflicts": c,
                          "row_hit_rate": h / n if n else 0.0, "data_bus_utilisation": ch.busy_data_cycles / span,
                          "turnarounds": ch.turnarounds, "avg_queue": ch.occ_sum / span, "max_queue": ch.occ_max})
        lat = self.lat_ctrl_cycles or [0]
        return {"name": self.name, "fidelity": "simplified controller model (not JEDEC-accurate)",
                "provenance": self.cfg.provenance, "reads": self.reads, "writes": self.writes,
                "channels": chans, "controller_cycles": span,
                "peak_bytes_per_ctrl_cycle": self.cfg.peak_bytes_per_cycle(),
                "mean_service_ctrl_cycles": sum(lat) / len(lat), "max_service_ctrl_cycles": max(lat)}
