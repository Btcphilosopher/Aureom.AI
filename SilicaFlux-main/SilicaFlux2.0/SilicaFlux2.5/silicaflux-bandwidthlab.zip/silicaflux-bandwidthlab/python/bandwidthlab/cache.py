"""Optional, non-coherent CPU-side cache (a link wrapper between a core and the fabric).

None of the audited SilicaFlux cores (SilicaFlux-V, MCU-I) has a cache; the closest RTL is
memory_cache_repo/set_assoc_cache.sv (32 KiB, 64 B lines, 4-way tree-PLRU, write-back +
write-allocate, blocking, not used by any SilicaFlux top).  This model is therefore an
EXPLORATION component.  No coherence protocol is implemented: DMA writes to cached lines
are NOT seen by the cache (software must flush/invalidate -- not modelled).

Features: direct-mapped / set-associative, line size, capacity, LRU / FIFO / seeded random /
tree-PLRU replacement, write-back + write-allocate or write-through + no-write-allocate,
hit latency, a finite number of MSHRs (1 = blocking), dirty-victim write-back.  Line fills
and write-backs are sequences of single-beat SFB2 transactions issued through the inner
link (SFB2 has no bursts), so they contend with every other master.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from .events import EventType
from .scheduler import Scheduler
from .transaction import MemTransaction, TransactionLedger, TxnKind, TxnState, TxnStatus


@dataclass
class CacheConfig:
    name: str = "dcache"
    capacity_bytes: int = 4096
    line_bytes: int = 32
    ways: int = 2
    replacement: str = "lru"          # lru | fifo | random | plru
    write_policy: str = "write_back"  # write_back | write_through
    hit_latency: int = 1
    mshrs: int = 1
    word_bytes: int = 4
    seed: int = 1

    def __post_init__(self) -> None:
        if self.capacity_bytes % (self.line_bytes * self.ways):
            raise ValueError("capacity must be a multiple of line_bytes x ways")
        if self.line_bytes % self.word_bytes:
            raise ValueError("line must be a whole number of fabric words")
        if self.replacement not in ("lru", "fifo", "random", "plru"):
            raise ValueError("replacement lru|fifo|random|plru")
        if self.write_policy not in ("write_back", "write_through"):
            raise ValueError("write_policy write_back|write_through")
        if self.replacement == "plru" and self.ways & (self.ways - 1):
            raise ValueError("tree-PLRU needs a power-of-two number of ways")
        if self.hit_latency < 1 or self.mshrs < 1:
            raise ValueError("hit_latency >= 1 and mshrs >= 1")

    @property
    def sets(self) -> int:
        return self.capacity_bytes // (self.line_bytes * self.ways)


@dataclass
class _Line:
    tag: int
    data: bytearray
    dirty: bool = False
    stamp: int = 0
    fill_order: int = 0


@dataclass
class _Miss:
    line_addr: int
    waiters: list = field(default_factory=list)       # CPU transactions waiting for this line
    words_left: int = 0
    data: bytearray = field(default_factory=bytearray)
    issued: int = 0


class CachedLink:
    kind = "cache"
    rank = 2

    def __init__(self, sched: Scheduler, cfg: CacheConfig, inner: Any, *, domain: str,
                 ledger: TransactionLedger | None = None) -> None:
        self.sched, self.cfg, self.inner, self.domain, self.ledger = sched, cfg, inner, domain, ledger
        self.name = cfg.name
        self.drv = sched.driver(domain)
        self.master: Any = None
        self.sets: list[list[_Line]] = [[] for _ in range(cfg.sets)]
        self.plru = [0] * cfg.sets
        self.rng = np.random.Generator(np.random.PCG64(cfg.seed))
        self.ready: deque[tuple[int, MemTransaction]] = deque()
        self.mshr: dict[int, _Miss] = {}
        self.out_q: deque[MemTransaction] = deque()     # fabric transactions to issue (fills, write-backs, WT)
        self.inner_presented: MemTransaction | None = None
        self.inner_inflight: dict[int, MemTransaction] = {}
        self.clock = self.drv.clock
        self.tick = 0
        self.fill_seq = 0
        self.hits = self.misses = self.merged = self.writebacks = self.wt_writes = 0
        self.fill_cycles: list[int] = []
        inner.bind(self)
        self.drv.attach(self)
        sched.register(self)

    # ---------------------------------------------------------------- link interface (towards the core)
    def bind(self, master: Any) -> None:
        self.master = master

    def can_present(self, cyc: int) -> bool:
        # with every MSHR busy the cache accepts nothing (mshrs=1: blocking, like set_assoc_cache.sv)
        return len(self.mshr) < self.cfg.mshrs

    def outstanding(self) -> int:
        return len(self.ready) + len(self.mshr) + len(self.out_q) + len(self.inner_inflight)

    def busy(self) -> bool:
        return bool(self.ready or self.out_q or self.inner_presented)

    def present(self, t: MemTransaction) -> None:
        cfg = self.cfg
        now = self.sched.now
        cyc = self.drv.cycle()
        t.dst = self.name
        t.path.append(self.name)
        la = t.addr // cfg.line_bytes
        if (t.addr + t.size - 1) // cfg.line_bytes != la:
            raise ValueError(f"{self.name}: request crosses a cache line")
        s, tag = la % cfg.sets, la // cfg.sets
        line = next((ln for ln in self.sets[s] if ln.tag == tag), None)
        t.advance(TxnState.AT_TARGET, now)
        t.mark_accepted(now)
        if self.ledger is not None:
            self.ledger.on_accepted(t)
        self.sched.emit(EventType.REQUEST_ACCEPTED, domain=self.domain, txn=t, src=t.master, dst=self.name)
        if self.master is not None:
            self.master.on_link_accept(self, t, cyc)
        if line is not None:
            self.hits += 1
            self._touch(s, line)
            t.advance(TxnState.SERVICE_STARTED, now)
            self._access_line(line, t)
            self.ready.append((cyc + cfg.hit_latency, t))
            self.drv.wake()
            return
        self.misses += 1
        if t.is_write and cfg.write_policy == "write_through":
            t.advance(TxnState.SERVICE_STARTED, now)          # no write-allocate: forward the write
            fwd = self._fabric_txn(TxnKind.WRITE, t.addr, t.size, data=t.data, be=t.mask)
            fwd.meta["_for"] = t
            self.wt_writes += 1
            self.out_q.append(fwd)
            self.drv.wake()
            return
        m = self.mshr.get(la)
        if m is not None:
            self.merged += 1
            m.waiters.append(t)
            return
        m = _Miss(la, [t], cfg.line_bytes // cfg.word_bytes, bytearray(cfg.line_bytes))
        m.issued = cyc
        self.mshr[la] = m
        for w in range(m.words_left):
            f = self._fabric_txn(TxnKind.READ, la * cfg.line_bytes + w * cfg.word_bytes, cfg.word_bytes)
            f.meta["_fill"] = (la, w)
            self.out_q.append(f)
        self.drv.wake()

    def poll_response(self, cyc: int) -> MemTransaction | None:
        if self.ready and self.ready[0][0] <= cyc:
            _, t = self.ready.popleft()
            now = self.sched.now
            for st in (TxnState.SERVICE_DONE, TxnState.RESPONSE):
                if t.state < st:
                    t.advance(st, now)
            return t
        return None

    # ---------------------------------------------------------------- inner link (towards the fabric)
    def on_link_accept(self, link: Any, t: MemTransaction, cyc: int) -> None:
        if self.inner_presented is t:
            self.inner_presented = None
        self.inner_inflight[t.tid] = t

    def _fabric_txn(self, kind: TxnKind, addr: int, size: int, *, data: int | None = None,
                    be: int | None = None) -> MemTransaction:
        t = MemTransaction.new(self.sched.new_id(), self.name, kind, addr, size, self.sched.now, data=data,
                               byte_enable=be, domain=self.domain, useful_bytes=0)
        if self.ledger is not None:
            self.ledger.on_generated(t)
        return t

    def on_response(self, cyc: int) -> None:
        r = self.inner.poll_response(cyc)
        if r is None:
            return
        now = self.sched.now
        r.advance(TxnState.COMPLETED, now)
        if r.status == TxnStatus.PENDING:
            r.status = TxnStatus.OK
        if self.ledger is not None:
            self.ledger.on_completed(r, now)
        self.inner_inflight.pop(r.tid, None)
        if "_fill" in r.meta:
            la, w = r.meta["_fill"]
            m = self.mshr[la]
            m.data[w * self.cfg.word_bytes:(w + 1) * self.cfg.word_bytes] = \
                int(r.data or 0).to_bytes(self.cfg.word_bytes, "little")
            m.words_left -= 1
            if m.words_left == 0:
                self._install(m, cyc)
        elif "_for" in r.meta:
            t = r.meta["_for"]
            self.ready.append((cyc, t))
        self.drv.wake()

    def on_issue(self, cyc: int) -> None:
        if self.inner_presented is None and self.out_q and self.inner.can_present(cyc):
            t = self.out_q.popleft()
            t.advance(TxnState.ISSUED, self.sched.now)
            self.inner_presented = t
            self.inner.present(t)

    # ---------------------------------------------------------------- helpers
    def _touch(self, s: int, line: _Line) -> None:
        self.tick += 1
        if self.cfg.replacement == "lru":
            line.stamp = self.tick
        if self.cfg.replacement == "plru":
            ways = self.sets[s]
            i = ways.index(line)
            node, lo, hi = 1, 0, self.cfg.ways
            bits = self.plru[s]
            while hi - lo > 1:
                mid = (lo + hi) // 2
                right = i >= mid
                bits = (bits | (1 << node)) if not right else (bits & ~(1 << node))   # point away from i
                node = 2 * node + (1 if right else 0)
                lo, hi = (mid, hi) if right else (lo, mid)
            self.plru[s] = bits

    def _victim(self, s: int) -> int:
        ways = self.sets[s]
        r = self.cfg.replacement
        if r == "lru":
            return min(range(len(ways)), key=lambda i: ways[i].stamp)
        if r == "fifo":
            return min(range(len(ways)), key=lambda i: ways[i].fill_order)
        if r == "random":
            return int(self.rng.integers(0, len(ways)))
        node, lo, hi = 1, 0, self.cfg.ways
        bits = self.plru[s]
        while hi - lo > 1:
            mid = (lo + hi) // 2
            right = bool((bits >> node) & 1)
            node = 2 * node + (1 if right else 0)
            lo, hi = (mid, hi) if right else (lo, mid)
        return lo

    def _install(self, m: _Miss, cyc: int) -> None:
        cfg = self.cfg
        s, tag = m.line_addr % cfg.sets, m.line_addr // cfg.sets
        ways = self.sets[s]
        if len(ways) >= cfg.ways:
            v = self._victim(s)
            old = ways[v]
            if old.dirty:
                self.writebacks += 1
                base = (old.tag * cfg.sets + s) * cfg.line_bytes
                for w in range(cfg.line_bytes // cfg.word_bytes):
                    val = int.from_bytes(old.data[w * cfg.word_bytes:(w + 1) * cfg.word_bytes], "little")
                    self.out_q.append(self._fabric_txn(TxnKind.WRITE, base + w * cfg.word_bytes, cfg.word_bytes,
                                                       data=val))
            ways.pop(v)
        self.fill_seq += 1
        line = _Line(tag, m.data, fill_order=self.fill_seq)
        ways.append(line)
        self._touch(s, line)
        del self.mshr[m.line_addr]
        self.fill_cycles.append(cyc - m.issued)
        now = self.sched.now
        for t in m.waiters:
            if t.state < TxnState.SERVICE_STARTED:
                t.advance(TxnState.SERVICE_STARTED, now)
            self._access_line(line, t)
            self.ready.append((cyc, t))

    def _access_line(self, line: _Line, t: MemTransaction) -> None:
        off = t.addr % self.cfg.line_bytes
        if t.is_write:
            for i in range(t.size):
                if t.mask is None or (t.mask >> i) & 1:
                    line.data[off + i] = ((t.data or 0) >> (8 * i)) & 0xFF
            if self.cfg.write_policy == "write_back":
                line.dirty = True
            else:
                fwd = self._fabric_txn(TxnKind.WRITE, t.addr, t.size, data=t.data, be=t.mask)
                self.wt_writes += 1
                self.out_q.append(fwd)
        else:
            t.data = int.from_bytes(line.data[off:off + t.size], "little")

    def stats(self) -> dict:
        n = self.hits + self.misses
        fc = self.fill_cycles or [0]
        return {"name": self.name, "fidelity": "functional + simplified timing; NO coherence",
                "hits": self.hits, "misses": self.misses, "hit_rate": self.hits / n if n else 0.0,
                "miss_rate": self.misses / n if n else 0.0, "merged_misses": self.merged,
                "writebacks": self.writebacks, "write_through_writes": self.wt_writes,
                "mean_miss_service_cycles": float(np.mean(fc)), "max_miss_service_cycles": int(max(fc))}
