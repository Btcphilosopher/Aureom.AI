"""DMA engine model.

Feature levels (each is a separate, explicit configuration -- nothing is assumed to exist
in SilicaFlux-V unless the audit found it):

  L0 ``simple``    DataFabric ``dma_transfer_engine`` (SoC default): one transaction in
                   flight, one data register, strict read -> write per beat
                   (ISSUE_READ, WAIT_READ, ISSUE_WRITE, WAIT_WRITE): 4 cycles/beat with
                   single-cycle slaves.                                       [RTL]
  L1 ``buffered``  DataFabric ``dma_burst_engine``: data FIFO of FIFO_DEPTH beats; a read
                   is issued only when a FIFO slot is reserved (credit); up to MAX_OUT
                   requests outstanding per port; single port: READ and WRITE phases of
                   up to BURST beats alternate and the phase switches only when the port
                   is idle.                                                   [RTL]
  L2 ``dual_port`` ``dma_burst_engine`` DUAL_PORT=1: separate read and write ports.  [RTL]
  L3 channels > 1  several channels served round-robin per descriptor burst. [EXTENSION]
  L4 scatter/gather descriptor chains (optionally fetched from memory).     [EXTENSION]
  L5 prefetch      reads of the next descriptor start while the previous one drains.
                                                                           [EXTENSION]

Request presentation is *registered*, as in the RTL: the decision to present a request
is taken at a clock edge and the request is visible to the fabric on the next edge.

Completion: a descriptor completes only when its last write has been *acknowledged*
(``done`` comes from COMPLETE, entered after the last write response returned OK);
never when its last read returns.  Data are really moved: read responses carry data into
the FIFO and writes carry it out, so tests check destination contents.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable

from .events import EventType
from .scheduler import Scheduler
from .transaction import MemTransaction, TransactionLedger, TxnKind, TxnState, TxnStatus
from .units import ceil_div


class DmaConfigError(ValueError):
    pass


@dataclass
class DmaConfig:
    name: str = "dma"
    clock: str = "clk"
    engine: str = "simple"            # simple | buffered
    data_width_bits: int = 32         # DW (one beat per bus transaction)
    fifo_depth: int = 8               # FIFO_DEPTH (buffered)
    burst: int = 8                    # BURST (buffered, single-port phase length)
    max_outstanding_reads: int = 2    # MAX_OUT on the read port
    max_outstanding_writes: int = 2   # MAX_OUT on the write port
    dual_port: bool = False           # DUAL_PORT
    channels: int = 1                 # > 1 is an extension
    scatter_gather: bool = False      # extension
    descriptor_fetch_bytes: int = 0   # >0: each SG segment costs a descriptor read of this size (extension)
    prefetch_next: bool = False       # extension: overlap next descriptor's reads with this one's writes
    setup_cycles: int = 2             # start -> first request decision (VALIDATE); calibrated
    completion_cycles: int = 1        # last write response -> done (COMPLETE state); calibrated

    def __post_init__(self) -> None:
        if self.engine not in ("simple", "buffered"):
            raise DmaConfigError("engine must be simple or buffered")
        if self.data_width_bits < 8 or self.data_width_bits % 8:
            raise DmaConfigError("data_width_bits must be a multiple of 8")
        if self.engine == "buffered":
            if self.fifo_depth < 1:
                raise DmaConfigError("fifo_depth must be >= 1")
            if not 1 <= self.burst <= self.fifo_depth:
                raise DmaConfigError("burst must be in 1..fifo_depth (dma_burst_engine)")
            if self.max_outstanding_reads < 1 or self.max_outstanding_writes < 1:
                raise DmaConfigError("max outstanding must be >= 1")
            if self.max_outstanding_reads > self.fifo_depth:
                raise DmaConfigError("max_outstanding_reads > fifo_depth can never be used (credit limit)")
        if self.channels < 1 or self.setup_cycles < 0 or self.completion_cycles < 0:
            raise DmaConfigError("channels >= 1, setup/completion cycles >= 0")

    @property
    def beat_bytes(self) -> int:
        return self.data_width_bits // 8

    def feature_level(self) -> str:
        lv = ["L0 simple"] if self.engine == "simple" else ["L1 buffered"]
        if self.dual_port:
            lv.append("L2 dual-port")
        if self.channels > 1:
            lv.append("L3 multi-channel [ext]")
        if self.scatter_gather:
            lv.append("L4 scatter-gather [ext]")
        if self.prefetch_next:
            lv.append("L5 prefetch [ext]")
        return " + ".join(lv)

    def rtl_equivalent(self) -> bool:
        return self.channels == 1 and not self.scatter_gather and not self.prefetch_next \
            and self.descriptor_fetch_bytes == 0


@dataclass
class Segment:
    src: int
    dst: int
    length: int


@dataclass
class Descriptor:
    segments: list[Segment]
    channel: int = 0
    label: str = ""
    on_done: Callable[["Descriptor"], None] | None = None
    on_progress: Callable[["Descriptor", int], None] | None = None    # bytes acknowledged so far
    post: str | None = None            # TokenBoard token posted at completion
    did: int = 0
    t_submit_cycle: int | None = None
    t_start_cycle: int | None = None
    t_done_cycle: int | None = None
    failed: bool = False
    err_code: str = ""
    bytes_done: int = 0

    @classmethod
    def copy(cls, src: int, dst: int, length: int, **kw: Any) -> "Descriptor":
        return cls([Segment(src, dst, length)], **kw)

    @property
    def length(self) -> int:
        return sum(s.length for s in self.segments)


@dataclass
class _Beat:
    seg: int
    idx: int
    src: int
    dst: int
    nbytes: int                    # payload bytes of this beat (tail may be partial)


@dataclass
class _Xfer:
    """One descriptor being executed (flattened to beats)."""
    desc: Descriptor
    beats: list[_Beat]
    rd_iss: int = 0
    rd_rsp: int = 0
    rd_ok: int = 0
    wr_iss: int = 0
    wr_rsp: int = 0
    rd_stop: bool = False
    wr_stop: bool = False
    data: dict[int, int] = field(default_factory=dict)      # beat idx -> data (FIFO contents)
    fetch_pending: int = 0                                   # SG descriptor fetches not yet returned
    fetch_issued: int = 0
    burst_marks: dict[int, int] = field(default_factory=dict)

    @property
    def total(self) -> int:
        return len(self.beats)


class DmaEngine:
    kind = "dma"
    rank = 2

    def __init__(self, sched: Scheduler, cfg: DmaConfig, *, read_link: Any, write_link: Any | None = None,
                 ledger: TransactionLedger | None = None, tokens: Any = None) -> None:
        self.sched, self.cfg, self.ledger = sched, cfg, ledger
        self.tokens = tokens
        self.name = cfg.name
        self.domain = cfg.clock
        self.drv = sched.driver(cfg.clock)
        self.clock = self.drv.clock
        if cfg.dual_port and write_link is None:
            raise DmaConfigError("dual_port DMA needs a write link")
        self.rd_link = read_link
        self.wr_link = write_link if cfg.dual_port else read_link
        self.links = {self.rd_link.name: self.rd_link}
        self.links[self.wr_link.name] = self.wr_link
        for ln in self.links.values():
            ln.bind(self)
        self.queues: list[deque[Descriptor]] = [deque() for _ in range(cfg.channels)]
        self.rr_channel = 0
        self.active: list[_Xfer] = []           # [current] or [current, prefetching next]
        self.state = "IDLE"
        self.ready_at = 0                       # cycle at which the next decision may be taken
        self.phase_write = False                # single-port burst engine phase
        self.bcnt = 0
        self.presented: dict[str, MemTransaction] = {}
        self.next_req: dict[str, tuple[_Xfer, _Beat | None, str]] = {}   # decided at the previous edge
        self.inflight: list[MemTransaction] = []
        self.next_did = 1
        self.completed: list[Descriptor] = []
        self.txns: list[MemTransaction] = []
        # statistics
        self.busy_cycles = 0
        self.stall_cycles = 0
        self.fifo_occ_sum = 0
        self.fifo_occ_max = 0
        self.active_cycles = 0
        self.first_cycle: int | None = None
        self.last_cycle: int | None = None
        self.bytes_read = 0
        self.bytes_written = 0
        self.useful_bytes = 0
        self.drv.attach(self)
        sched.register(self)

    # ------------------------------------------------------------------ API
    def submit(self, desc: Descriptor) -> Descriptor:
        if desc.length <= 0:
            raise DmaConfigError("descriptor length must be > 0")
        if len(desc.segments) > 1 and not self.cfg.scatter_gather:
            raise DmaConfigError("multi-segment descriptor needs scatter_gather=True (extension)")
        if not 0 <= desc.channel < self.cfg.channels:
            raise DmaConfigError(f"channel {desc.channel} does not exist")
        desc.did = self.next_did
        self.next_did += 1
        desc.t_submit_cycle = self.drv.cycle()
        self.queues[desc.channel].append(desc)
        if self.state == "IDLE":
            self.ready_at = max(self.ready_at, desc.t_submit_cycle + self.cfg.setup_cycles)
        self.drv.wake()
        return desc

    def outstanding(self) -> int:
        return sum(len(q) for q in self.queues) + len(self.active) + len(self.inflight) + len(self.presented)

    def busy(self) -> bool:
        return self.outstanding() > 0

    # ------------------------------------------------------------------ helpers
    def _flatten(self, d: Descriptor) -> _Xfer:
        bb = self.cfg.beat_bytes
        beats: list[_Beat] = []
        for si, s in enumerate(d.segments):
            if s.src % bb or s.dst % bb:
                raise DmaConfigError(f"{self.name}: segment addresses must be {bb}-byte aligned")
            n = ceil_div(s.length, bb)
            for i in range(n):
                nbytes = min(bb, s.length - i * bb)
                beats.append(_Beat(si, len(beats), s.src + i * bb, s.dst + i * bb, nbytes))
        x = _Xfer(d, beats)
        if self.cfg.scatter_gather and self.cfg.descriptor_fetch_bytes:
            x.fetch_pending = len(d.segments)
        return x

    def _start_next(self, cyc: int) -> bool:
        for k in range(self.cfg.channels):
            ch = (self.rr_channel + k) % self.cfg.channels
            if self.queues[ch]:
                d = self.queues[ch].popleft()
                self.rr_channel = (ch + 1) % self.cfg.channels
                d.t_start_cycle = cyc
                self.active.append(self._flatten(d))
                self.sched.emit(EventType.DMA_DESCRIPTOR_STARTED, domain=self.domain, src=self.name, dst=self.name,
                                payload={"did": d.did, "bytes": d.length, "segments": len(d.segments),
                                         "channel": ch, "label": d.label})
                return True
        return False

    def _fifo_level(self) -> int:
        return sum(len(x.data) for x in self.active)

    def _new_txn(self, kind: TxnKind, addr: int, size: int, cyc: int, *, data: int | None = None,
                 be: int | None = None, useful: int = 0) -> MemTransaction:
        t = MemTransaction.new(self.sched.new_id(), self.name, kind, addr, size, self.sched.now, data=data,
                               byte_enable=be, domain=self.domain, useful_bytes=useful)
        if self.ledger is not None:
            self.ledger.on_generated(t)
        self.sched.emit(EventType.REQUEST_GENERATED, domain=self.domain, txn=t, src=self.name,
                        payload={"addr": addr, "size": size, "kind": kind.value})
        return t

    # ------------------------------------------------------------------ link callbacks
    def on_link_accept(self, link: Any, txn: MemTransaction, cyc: int) -> None:
        if self.presented.get(link.name) is txn:
            del self.presented[link.name]
        x, beat = txn.meta["_x"], txn.meta["_beat"]
        if txn.kind == TxnKind.DMA_READ:
            if beat is not None:
                x.rd_iss += 1
        else:
            x.wr_iss += 1
            x.data.pop(beat.idx, None)                # FIFO pop at write acceptance
        if self.cfg.engine == "buffered" and not self.cfg.dual_port:
            self.bcnt += 1
        if txn.meta.get("posted"):
            self._response(txn, cyc, posted=True)

    # ------------------------------------------------------------------ phases
    def on_response(self, cyc: int) -> None:
        for ln in self.links.values():
            t = ln.poll_response(cyc)
            if t is not None:
                self._response(t, cyc)

    def _response(self, t: MemTransaction, cyc: int, posted: bool = False) -> None:
        now = self.sched.now
        if posted and t.state < TxnState.RESPONSE:
            t.advance(TxnState.RESPONSE, now)
        t.advance(TxnState.COMPLETED, now)
        if t.status == TxnStatus.PENDING:
            t.status = TxnStatus.OK
        if self.ledger is not None:
            self.ledger.on_completed(t, now)
        self.sched.emit(EventType.RESPONSE_ACCEPTED, domain=self.domain, txn=t, src=t.dst, dst=self.name,
                        payload={"error": t.status != TxnStatus.OK})
        self.inflight.remove(t)
        self.txns.append(t)
        x: _Xfer = t.meta["_x"]
        beat: _Beat | None = t.meta["_beat"]
        err = t.status != TxnStatus.OK
        if t.kind == TxnKind.DMA_READ and beat is None:          # SG descriptor fetch
            x.fetch_pending -= 1
            if err:
                self._fail(x, "DESC_FETCH_ERROR")
            return
        if t.kind == TxnKind.DMA_READ:
            x.rd_rsp += 1
            self.bytes_read += t.size
            if err:
                x.rd_stop = True
                self._fail(x, "READ_ERROR", keep_writing=True)
            elif not x.rd_stop:
                x.data[beat.idx] = t.data or 0
                x.rd_ok += 1
        else:
            x.wr_rsp += 1
            self.bytes_written += beat.nbytes
            if err:
                x.rd_stop = x.wr_stop = True
                self._fail(x, "WRITE_ERROR")
            else:
                self.useful_bytes += beat.nbytes
                x.desc.bytes_done += beat.nbytes
                if x.desc.on_progress:
                    x.desc.on_progress(x.desc, x.desc.bytes_done)
            b = beat.idx // max(1, self.cfg.burst)
            if beat.idx == min(x.total, (b + 1) * self.cfg.burst) - 1 or beat.idx == x.total - 1:
                self.sched.emit(EventType.DMA_BURST_COMPLETED, domain=self.domain, src=self.name, dst=t.dst,
                                payload={"did": x.desc.did, "burst": b})
        self.drv.wake()

    def _fail(self, x: _Xfer, code: str, keep_writing: bool = False) -> None:
        if not x.desc.failed:
            x.desc.failed = True
            x.desc.err_code = code
        if not keep_writing:
            x.wr_stop = True
        x.rd_stop = True

    def on_issue(self, cyc: int) -> None:
        # present the requests decided at the previous edge (registered valid)
        for lname, (x, beat, kind) in list(self.next_req.items()):
            ln = self.links[lname]
            if lname in self.presented or not ln.can_present(cyc):
                continue
            del self.next_req[lname]
            bb = self.cfg.beat_bytes
            if kind == "fetch":
                seg_i = x.fetch_issued
                x.fetch_issued += 1
                t = self._new_txn(TxnKind.DMA_READ, x.beats[0].src if x.beats else 0,
                                  self.cfg.descriptor_fetch_bytes, cyc)
                t.meta["desc_fetch"] = seg_i
            elif kind == "R":
                t = self._new_txn(TxnKind.DMA_READ, beat.src, bb, cyc, useful=0)
            else:
                be = (1 << beat.nbytes) - 1
                t = self._new_txn(TxnKind.DMA_WRITE, beat.dst, bb, cyc, data=x.data.get(beat.idx, 0), be=be,
                                  useful=beat.nbytes)
            t.meta["_x"], t.meta["_beat"] = x, beat
            if kind == "R" and beat is not None and beat.idx % max(1, self.cfg.burst) == 0:
                self.sched.emit(EventType.DMA_BURST_STARTED, domain=self.domain, src=self.name, dst=lname,
                                payload={"did": x.desc.did, "burst": beat.idx // max(1, self.cfg.burst),
                                         "beats": min(self.cfg.burst, x.total - beat.idx)})
            t.advance(TxnState.ISSUED, self.sched.now)
            self.sched.emit(EventType.REQUEST_ISSUED, domain=self.domain, txn=t, src=self.name, dst=lname)
            self.presented[lname] = t
            self.inflight.append(t)
            ln.present(t)

    def on_post(self, cyc: int) -> None:
        if self.first_cycle is None and (self.active or any(self.queues)):
            self.first_cycle = cyc
        if self.active or self.presented or self.inflight:
            self.busy_cycles += 1
            self.last_cycle = cyc
            if self.presented:
                self.stall_cycles += 1                 # valid held, not accepted
        lvl = self._fifo_level()
        self.fifo_occ_sum += lvl
        self.fifo_occ_max = max(self.fifo_occ_max, lvl)
        self.active_cycles += 1
        self._retire(cyc)
        if cyc < self.ready_at:
            self.drv.wake(self.clock.edge(self.ready_at))
            return
        if not self.active:
            if not self._start_next(cyc):
                self.state = "IDLE"
                return
        self.state = "RUN"
        if self.cfg.prefetch_next and len(self.active) == 1 and self.active[0].rd_iss >= self.active[0].total:
            self._start_next(cyc)
        self._decide(cyc)

    def _retire(self, cyc: int) -> None:
        while self.active:
            x = self.active[0]
            outstanding = any(t.meta["_x"] is x for t in self.inflight) or \
                any(r[0] is x for r in self.next_req.values())
            done_writing = x.wr_stop or x.wr_rsp >= self._wr_limit(x)
            done_reading = x.rd_stop or x.rd_iss >= x.total
            if outstanding or not (done_writing and done_reading):
                return
            self.active.pop(0)
            d = x.desc
            d.t_done_cycle = cyc + self.cfg.completion_cycles
            if not d.failed and x.wr_rsp != x.total:
                d.failed, d.err_code = True, "ABORTED"
            self.completed.append(d)
            self.ready_at = max(self.ready_at, cyc + self.cfg.completion_cycles + self.cfg.setup_cycles)
            self.phase_write, self.bcnt = False, 0

            def fire(d: Descriptor = d) -> None:
                self.sched.emit(EventType.DMA_DESCRIPTOR_COMPLETED, domain=self.domain, src=self.name,
                                dst=self.name, payload={"did": d.did, "bytes": d.bytes_done, "failed": d.failed,
                                                        "error": d.err_code, "label": d.label})
                self.sched.note_progress()
                if d.post is not None and self.tokens is not None:
                    self.tokens.post(d.post, d.t_done_cycle)
                if d.on_done:
                    d.on_done(d)
            if self.cfg.completion_cycles:
                self.sched.schedule_at(self.clock.edge(d.t_done_cycle), fire, 0, f"{self.name}.done")
            else:
                fire()

    def _wr_limit(self, x: _Xfer) -> int:
        """Beats that will be written: all, or the good prefix read before a read error."""
        return x.rd_ok if x.rd_stop else x.total

    def _decide(self, cyc: int) -> None:
        """Take the registered request decisions for the next edge."""
        cfg = self.cfg
        rl, wl = self.rd_link.name, self.wr_link.name
        if not self.active:
            return
        x = self.active[0]
        # SG descriptor fetches precede the segment's data movement
        if x.fetch_pending and x.fetch_issued < len(x.desc.segments):
            if rl not in self.presented and rl not in self.next_req and \
                    sum(1 for t in self.inflight if t.meta["_beat"] is None) == 0:
                self.next_req[rl] = (x, None, "fetch")
            return
        if x.fetch_pending:
            return
        rd_out = sum(1 for t in self.inflight if t.kind == TxnKind.DMA_READ)
        wr_out = sum(1 for t in self.inflight if t.kind == TxnKind.DMA_WRITE)
        pending_rd = sum(1 for v in self.next_req.values() if v[2] == "R")
        pending_wr = sum(1 for v in self.next_req.values() if v[2] == "W")
        # the transfer whose reads are being issued (prefetch may have started the next one)
        xr = next((y for y in self.active if not y.rd_stop and y.rd_iss + self._rd_reserved(y) < y.total), None)
        if cfg.engine == "simple":
            # one transaction in flight; read -> write per beat
            if self.presented or self.inflight or self.next_req:
                return
            if x.wr_iss < x.rd_ok and not x.wr_stop and x.wr_iss < self._wr_limit(x):
                self.next_req[wl] = (x, x.beats[x.wr_iss], "W")
            elif x.rd_iss < x.total and not x.rd_stop:
                self.next_req[rl] = (x, x.beats[x.rd_iss], "R")
            return
        # ---- buffered engine
        fifo_reserved = sum(y.rd_iss - y.wr_iss for y in self.active) + pending_rd
        can_rd = (xr is not None and fifo_reserved < cfg.fifo_depth and rd_out + pending_rd < cfg.max_outstanding_reads)
        xw = next((y for y in self.active if not y.wr_stop and y.wr_iss + self._wr_reserved(y) < self._wr_limit(y)
                   and (y.wr_iss + self._wr_reserved(y)) in y.data), None)
        can_wr = xw is not None and wr_out + pending_wr < cfg.max_outstanding_writes
        if cfg.dual_port:
            if can_rd and rl not in self.presented and rl not in self.next_req:
                self.next_req[rl] = (xr, xr.beats[xr.rd_iss + self._rd_reserved(xr)], "R")
            if can_wr and wl not in self.presented and wl not in self.next_req:
                self.next_req[wl] = (xw, xw.beats[xw.wr_iss + self._wr_reserved(xw)], "W")
            return
        if rl in self.presented or rl in self.next_req:
            return                                         # hold: valid stays until accepted
        if not self.phase_write and can_rd and self.bcnt < cfg.burst:
            self.next_req[rl] = (xr, xr.beats[xr.rd_iss + self._rd_reserved(xr)], "R")
        elif self.phase_write and can_wr and self.bcnt < cfg.burst:
            self.next_req[rl] = (xw, xw.beats[xw.wr_iss + self._wr_reserved(xw)], "W")
        elif not self.inflight:
            self.phase_write = not self.phase_write        # switch only when the port is idle
            self.bcnt = 0

    def _rd_reserved(self, x: _Xfer) -> int:
        return sum(1 for t in self.presented.values() if t.meta["_x"] is x and t.kind == TxnKind.DMA_READ
                   and t.meta["_beat"] is not None) + \
            sum(1 for v in self.next_req.values() if v[0] is x and v[2] == "R")

    def _wr_reserved(self, x: _Xfer) -> int:
        return sum(1 for t in self.presented.values() if t.meta["_x"] is x and t.kind == TxnKind.DMA_WRITE) + \
            sum(1 for v in self.next_req.values() if v[0] is x and v[2] == "W")

    # ------------------------------------------------------------------ results
    def stats(self) -> dict:
        win = (self.last_cycle - self.first_cycle + 1) if (self.first_cycle is not None and self.last_cycle
                                                            is not None) else 0
        descs = [{"did": d.did, "label": d.label, "bytes": d.length, "bytes_done": d.bytes_done,
                  "submit_cycle": d.t_submit_cycle, "start_cycle": d.t_start_cycle, "done_cycle": d.t_done_cycle,
                  "cycles": (d.t_done_cycle - d.t_submit_cycle) if d.t_done_cycle is not None else None,
                  "failed": d.failed, "error": d.err_code} for d in self.completed]
        return {"name": self.name, "feature_level": self.cfg.feature_level(),
                "rtl_equivalent": self.cfg.rtl_equivalent(), "descriptors": descs,
                "bytes_read": self.bytes_read, "bytes_written": self.bytes_written,
                "useful_bytes": self.useful_bytes, "busy_cycles": self.busy_cycles,
                "stall_cycles": self.stall_cycles, "window_cycles": win,
                "idle_cycles": max(0, win - self.busy_cycles),
                "avg_fifo_occupancy": self.fifo_occ_sum / max(1, self.active_cycles),
                "max_fifo_occupancy": self.fifo_occ_max,
                "useful_bytes_per_cycle": self.useful_bytes / win if win else 0.0}
