"""Memory transaction schema shared by every BandwidthLab component.

``MemTransaction`` *extends* MemoryLab's ``memorylab.event_engine.Transaction`` (it is a
subclass, not a parallel definition), so it can be passed to MemoryLab components such
as the RTL-validated ``memorylab.sram.BankController`` unchanged.  The base fields keep
their meaning (``op`` 'R'/'W', ``mask`` = byte enables, ``t_issued``, ``t_accepted``,
``t_service_start``, ``t_service_end``, ``t_completed``); BandwidthLab adds the
transaction kind, destination, priority, dependencies, the arbitration / queue /
response timestamps and a checked lifecycle.

Lifecycle (timestamps in fs, each set at most once, never decreasing):

    CREATED -> ISSUED -> ENQUEUED -> QUEUE_HEAD -> GRANTED -> AT_TARGET
            -> SERVICE_STARTED -> SERVICE_DONE -> RESPONSE -> COMPLETED
    any state before COMPLETED -> CANCELLED

A component that has no such stage (e.g. a combinational crossbar has no input queue)
skips it; the skipped interval has zero length.

*Acceptance* (``t_accepted``) is recorded separately from the ordered chain because
where it happens depends on the fabric: in the SilicaFlux SFB2 crossbar the master's
``req_ready`` is the target's ready gated by the grant (sfb_crossbar.sv), so a request
is accepted only when the target accepts it -- after arbitration; in a fabric with a
registered input queue it is accepted on entering the queue.  Acceptance is always
distinct from completion and must satisfy ``t_issued <= t_accepted <= t_service_start``.  A posted write completes at the point the configured protocol
defines (see ``WriteSemantics``); a non-posted write completes when its acknowledgement
is accepted by the master.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Any

from memorylab.event_engine import Transaction


class InvalidOrderingError(RuntimeError):
    """A lifecycle step out of order, a timestamp going backwards or a step repeated."""


class ConservationError(RuntimeError):
    pass


class TxnKind(str, Enum):
    READ = "READ"
    WRITE = "WRITE"
    DMA_READ = "DMA_READ"
    DMA_WRITE = "DMA_WRITE"
    PREFETCH = "PREFETCH"      # non-binding read (cache next-line prefetch, DMA prefetch)
    ATOMIC = "ATOMIC"          # defined for the schema; no audited SilicaFlux bus implements it

    @property
    def op(self) -> str:
        return "W" if self in (TxnKind.WRITE, TxnKind.DMA_WRITE, TxnKind.ATOMIC) else "R"

    @property
    def is_read(self) -> bool:
        return self.op == "R"

    @property
    def is_dma(self) -> bool:
        return self in (TxnKind.DMA_READ, TxnKind.DMA_WRITE)


class TxnStatus(str, Enum):
    PENDING = "PENDING"
    OK = "OK"
    DECODE_ERROR = "DECODE_ERROR"      # no target at this address (error slave)
    SLAVE_ERROR = "SLAVE_ERROR"        # target refused (out of range / misaligned / unsupported)
    CANCELLED = "CANCELLED"


class TxnState(IntEnum):
    CREATED = 0
    ISSUED = 1
    ENQUEUED = 2
    QUEUE_HEAD = 3
    GRANTED = 4
    AT_TARGET = 5
    SERVICE_STARTED = 6
    SERVICE_DONE = 7
    RESPONSE = 8
    COMPLETED = 9
    CANCELLED = 10


_STAMP = {
    TxnState.ISSUED: "t_issued", TxnState.ENQUEUED: "t_enqueued", TxnState.QUEUE_HEAD: "t_queue_head",
    TxnState.GRANTED: "t_granted", TxnState.AT_TARGET: "t_at_target",
    TxnState.SERVICE_STARTED: "t_service_start", TxnState.SERVICE_DONE: "t_service_end",
    TxnState.RESPONSE: "t_response", TxnState.COMPLETED: "t_completed", TxnState.CANCELLED: "t_cancelled",
}


@dataclass(eq=False)
class MemTransaction(Transaction):
    kind: TxnKind = TxnKind.READ
    dst: str = ""                      # destination target (slave) name, set by the address decoder
    priority: int = 0
    deps: tuple[int, ...] = ()         # tids that must complete before this one may be issued
    domain: str = ""                   # clock domain of the issuing master
    useful_bytes: int | None = None    # application payload (defaults to size)
    t_enqueued: int | None = None
    t_queue_head: int | None = None
    t_granted: int | None = None
    t_at_target: int | None = None
    t_response: int | None = None
    t_cancelled: int | None = None
    status: TxnStatus = TxnStatus.PENDING
    state: TxnState = TxnState.CREATED
    beats: int = 1
    meta: dict[str, Any] = field(default_factory=dict)

    __eq__ = object.__eq__
    __hash__ = object.__hash__

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.op != self.kind.op:
            raise ValueError(f"tid {self.tid}: op {self.op!r} inconsistent with kind {self.kind.value}")
        if self.useful_bytes is None:
            self.useful_bytes = self.size
        if self.useful_bytes < 0 or self.useful_bytes > self.size:
            raise ValueError("useful_bytes must be within [0, size]")
        if self.priority < 0:
            raise ValueError("priority must be >= 0")

    # ------------------------------------------------------------------ construction
    @classmethod
    def new(cls, tid: int, master: str, kind: TxnKind, addr: int, size: int, t_created: int, **kw: Any
            ) -> "MemTransaction":
        byte_enable = kw.pop("byte_enable", None)
        t = cls(tid=tid, master=master, op=kind.op, addr=addr, size=size, t_created=t_created, kind=kind, **kw)
        if byte_enable is not None:
            t.mask = byte_enable
        return t

    @property
    def byte_enable(self) -> int | None:
        return self.mask

    @property
    def is_write(self) -> bool:
        return self.op == "W"

    @property
    def done(self) -> bool:
        return self.state in (TxnState.COMPLETED, TxnState.CANCELLED)

    # ------------------------------------------------------------------ checked lifecycle
    def advance(self, state: TxnState, t_fs: int) -> None:
        """Move to ``state`` at ``t_fs``; earlier skipped states keep ``None`` stamps."""
        if self.state in (TxnState.COMPLETED, TxnState.CANCELLED):
            raise InvalidOrderingError(f"tid {self.tid}: {state.name} after terminal state {self.state.name}")
        if state != TxnState.CANCELLED and state <= self.state:
            raise InvalidOrderingError(
                f"tid {self.tid}: {state.name} after {self.state.name} (duplicate or out-of-order step)")
        last = self.last_stamp()
        if t_fs < last:
            raise InvalidOrderingError(f"tid {self.tid}: {state.name} at {t_fs} fs before previous step at {last} fs")
        setattr(self, _STAMP[state], t_fs)
        self.state = state

    def mark_accepted(self, t_fs: int) -> None:
        """Record the acceptance handshake (fabric takes ownership); exactly once."""
        if self.t_accepted is not None:
            raise InvalidOrderingError(f"tid {self.tid}: accepted twice")
        if self.t_issued is None or t_fs < self.t_issued:
            raise InvalidOrderingError(f"tid {self.tid}: accepted at {t_fs} fs before being issued")
        if self.state in (TxnState.COMPLETED, TxnState.CANCELLED):
            raise InvalidOrderingError(f"tid {self.tid}: accepted after {self.state.name}")
        self.t_accepted = t_fs

    def last_stamp(self) -> int:
        last = self.t_created
        for st in TxnState:
            if st in _STAMP:
                v = getattr(self, _STAMP[st])
                if v is not None and v > last:
                    last = v
        return last

    def stamps(self) -> dict[str, int | None]:
        out = {"t_created": self.t_created}
        for st in (TxnState.ISSUED, TxnState.ENQUEUED, TxnState.QUEUE_HEAD, TxnState.GRANTED, TxnState.AT_TARGET,
                   TxnState.SERVICE_STARTED, TxnState.SERVICE_DONE, TxnState.RESPONSE, TxnState.COMPLETED):
            out[_STAMP[st]] = getattr(self, _STAMP[st])
        return out

    def filled_stamps(self) -> list[int]:
        """Timestamps of the 10 lifecycle points with missing ones filled from the next present one.

        A component that does not have a given stage (e.g. a combinational crossbar has no
        input queue) skips it: the missing timestamp takes the value of the previous present
        one, so the skipped stage has zero length and the waiting time is attributed to the
        next stage that exists (e.g. arbitration).  Raises if the transaction has not completed.
        """
        if self.t_completed is None:
            raise ValueError(f"tid {self.tid} has not completed")
        vals = list(self.stamps().values())
        for i in range(1, len(vals)):
            if vals[i] is None:
                vals[i] = vals[i - 1]
        for a, b in zip(vals, vals[1:]):
            if b < a:
                raise InvalidOrderingError(f"tid {self.tid}: non-monotonic timestamps {vals}")
        return vals  # type: ignore[return-value]

    def to_record(self) -> dict[str, Any]:
        d = {"tid": self.tid, "master": self.master, "kind": self.kind.value, "op": self.op, "dst": self.dst,
             "addr": self.addr, "size": self.size, "useful_bytes": self.useful_bytes, "priority": self.priority,
             "status": self.status.value, "deps": list(self.deps), "domain": self.domain, "beats": self.beats}
        d.update(self.stamps())
        d["t_accepted"] = self.t_accepted
        return d


class WriteSemantics(str, Enum):
    """When a write counts as complete (must match the configured protocol)."""
    ACKED = "ACKED"            # completes when the write response is accepted by the master
    POSTED = "POSTED"          # completes when the target accepts the write (no response)


class TransactionLedger:
    """Conservation bookkeeping: generated / accepted / completed / cancelled.

    Invariant (checkable at any simulation boundary):
        accepted == completed + outstanding + cancelled(after acceptance)
    plus: no duplicate generation/acceptance/completion, no completion before
    acceptance, no completion before the transaction's dependencies completed.
    """

    def __init__(self) -> None:
        self.generated: dict[int, MemTransaction] = {}
        self.accepted: set[int] = set()
        self.completed: dict[int, int] = {}       # tid -> completion time
        self.cancelled: set[int] = set()
        self.rejected: set[int] = set()
        self.errors: list[str] = []
        # live occupancy integral (accepted, not yet completed) -- an independent measurement
        # used for the Little's-law consistency check
        self.n_in_system = 0
        self.occ_area_fs = 0
        self.occ_last_fs: int | None = None
        self.occ_first_fs: int | None = None

    def _occ(self, t_fs: int, delta: int) -> None:
        if self.occ_last_fs is not None:
            if t_fs < self.occ_last_fs:
                t_fs = self.occ_last_fs          # same-edge bookkeeping order; time never runs backwards
            self.occ_area_fs += self.n_in_system * (t_fs - self.occ_last_fs)
        else:
            self.occ_first_fs = t_fs
        self.occ_last_fs = t_fs
        self.n_in_system += delta

    def _err(self, msg: str) -> None:
        self.errors.append(msg)
        raise ConservationError(msg)

    def on_generated(self, t: MemTransaction) -> None:
        if t.tid in self.generated:
            self._err(f"duplicate transaction id {t.tid}")
        self.generated[t.tid] = t

    def on_accepted(self, t: MemTransaction) -> None:
        if t.tid not in self.generated:
            self._err(f"tid {t.tid} accepted but never generated")
        if t.tid in self.accepted:
            self._err(f"tid {t.tid} accepted twice (duplicate)")
        self.accepted.add(t.tid)
        self._occ(t.t_accepted if t.t_accepted is not None else (self.occ_last_fs or 0), +1)

    def on_rejected(self, t: MemTransaction) -> None:
        self.rejected.add(t.tid)

    def on_completed(self, t: MemTransaction, now: int) -> None:
        if t.tid not in self.accepted:
            self._err(f"tid {t.tid} completed without acceptance")
        if t.tid in self.completed:
            self._err(f"tid {t.tid} completed twice (duplicate)")
        if t.tid in self.cancelled:
            self._err(f"tid {t.tid} completed after cancellation")
        for d in t.deps:
            if d not in self.completed or self.completed[d] > now:
                self._err(f"tid {t.tid} completed before its dependency {d}")
        self.completed[t.tid] = now
        self._occ(now, -1)

    def on_cancelled(self, t: MemTransaction) -> None:
        if t.tid in self.completed:
            self._err(f"tid {t.tid} cancelled after completion")
        self.cancelled.add(t.tid)

    def deps_satisfied(self, t: MemTransaction, now: int) -> bool:
        return all(d in self.completed and self.completed[d] <= now for d in t.deps)

    @property
    def outstanding(self) -> int:
        return len(self.accepted) - len(self.completed) - len(self.accepted & self.cancelled)

    def check(self) -> list[str]:
        acc = self.accepted
        comp = set(self.completed)
        canc = acc & self.cancelled
        outstanding = acc - comp - canc
        errs = list(self.errors)
        if not comp <= acc:
            errs.append(f"{len(comp - acc)} completions without acceptance")
        if len(acc) != len(comp) + len(outstanding) + len(canc):
            errs.append("conservation violated: accepted != completed + outstanding + cancelled")
        return errs

    def final_check(self) -> list[str]:
        """At end of simulation (event queue drained): nothing may remain outstanding."""
        errs = self.check()
        lost = self.accepted - set(self.completed) - self.cancelled
        if lost:
            errs.append(f"{len(lost)} accepted transactions never completed (lost), e.g. {sorted(lost)[:5]}")
        return errs

    def summary(self) -> dict[str, int]:
        return {"generated": len(self.generated), "accepted": len(self.accepted),
                "completed": len(self.completed), "cancelled": len(self.cancelled),
                "rejected": len(self.rejected), "outstanding": self.outstanding}
