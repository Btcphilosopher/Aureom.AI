"""Latency quality-of-service studies.

Simulated trade-offs (EVENT_SIMULATED, stated traffic): a CPU data stream sharing an SRAM
bank with a DMA copy under fixed priority (CPU first / DMA first), round robin, weighted
round robin and age-based arbitration.  Reported: CPU latency (mean, P99, max), maximum
arbitration wait, DMA copy time, grant shares and Jain's fairness index.

Statistical simulation never proves a worst-case bound.  ``rr_wait_bound`` is a separate,
*analytical* bound derived from the arbiter definition under explicit assumptions; it is
labelled ANALYTICAL_BOUND and is compared with, not derived from, the simulation.
"""
from __future__ import annotations

from typing import Any

from .experiments import specs
from .sweep import run_variants


def rr_wait_bound(n_requesters: int, max_hold_cycles: int) -> dict:
    """Round robin with pointer -> winner+1 on accepted grants (sfb_arbiter MODE=1).

    Assumptions: the port grants one request per accepted handshake; every granted request
    holds the port for at most ``max_hold_cycles`` cycles before it is accepted (target
    ready latency, e.g. a bank conflict or a 1-outstanding response wait); requesters
    other than the one considered keep requesting continuously.  Then a requester waits
    for at most (N - 1) grants: wait <= (N - 1) x max_hold_cycles cycles.
    Fixed priority gives no bound for any requester but the highest.
    """
    return {"category": "ANALYTICAL_BOUND", "policy": "rr", "max_wait_cycles": (n_requesters - 1) * max_hold_cycles,
            "assumptions": ["accepted-grant pointer update (sfb_arbiter.sv:95-96)",
                            f"each grant holds the port <= {max_hold_cycles} cycles",
                            "no other source of delay before arbitration"]}


def jain(xs: list[float]) -> float:
    xs = [x for x in xs if x is not None]
    if not xs or sum(xs) == 0:
        return float("nan")
    return sum(xs) ** 2 / (len(xs) * sum(x * x for x in xs))


def run_qos(cfg_path: str, workers: int | None = None) -> dict[str, Any]:
    sp = specs(cfg_path)["J"]
    rows = run_variants(sp, workers=workers)
    summ = []
    for r in rows:
        summ.append({"policy": r["label"], "cpu_lat_mean": r.get("cpu_bg_lat_mean"),
                     "cpu_lat_p99": r.get("cpu_bg_lat_p99"), "cpu_lat_max": r.get("cpu_bg_lat_max"),
                     "cpu_arbitration_mean": r.get("cpu_bg_arbitration_mean"),
                     "max_arbitration_wait": r.get("max_arbitration_wait"), "dma_copy_cycles": r.get("dma_copy_cycles"),
                     "valid": r.get("valid")})
    return {"rows": rows, "summary": summ,
            "rr_bound_two_requesters": rr_wait_bound(2, 1),
            "note": "simulated latencies are observations under the stated traffic, not worst-case guarantees"}
