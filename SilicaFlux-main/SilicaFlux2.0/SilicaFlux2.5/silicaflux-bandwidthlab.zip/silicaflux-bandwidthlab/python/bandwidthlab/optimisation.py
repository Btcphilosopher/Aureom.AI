"""Marginal-gain analysis and Pareto selection.

Throughput of a configuration on a fixed workload = work / completion cycles (the work is
identical across variants, so relative throughput = cycles_base / cycles_variant).

For consecutive values of one factor (all other parameters fixed):
  absolute gain      = thr(next) - thr(prev)                (work units per cycle)
  relative gain      = thr(next) / thr(prev) - 1
  latency reduction  = lat_mean(prev) - lat_mean(next), same for P95 / P99
  stall change       = stalls(next) - stalls(prev)
  resource cost      = proxy(next) - proxy(prev)  (the factor's own resource proxy; NOT area)
  marginal gain / resource = relative gain / relative resource increase
Diminishing returns: relative gain below ``dr_threshold`` (default 5 %) or marginal gain
per resource below 25 % of the first step's.

Pareto: non-dominated configurations for (maximise throughput, minimise P99 latency,
minimise the resource cost index).  The cost index is a weighted sum of resource proxies
with explicitly HYPOTHETICAL weights (``DEFAULT_COST_WEIGHTS``); it is a ranking aid, not
silicon area.  Configurations that violate a constraint or an invariant are rejected.
"""
from __future__ import annotations

from typing import Any, Sequence

import numpy as np

DEFAULT_COST_WEIGHTS = {            # HYPOTHETICAL ranking weights (relative "cost units"), not mm^2
    "res_sram_kib": 1.0,
    "res_sram_banks_total": 4.0,
    "res_fabric_mux_bits": 0.02,
    "res_dma_fifo_bits": 0.01,
    "res_dma_outstanding_entries": 1.0,
    "res_tensor_macs": 2.0,
    "res_vector_lanes": 4.0,
}

FACTOR_RESOURCE = {
    "bus_width": "res_fabric_width_bits", "sram_banks": "res_sram_banks_total", "dma_fifo": "res_dma_fifo_bits",
    "dma_outstanding": "res_dma_outstanding_entries", "tensor_array": "res_tensor_macs",
    "vector_lanes": "res_vector_lanes", "sram_capacity": "res_sram_kib",
}


def cost_index(row: dict, weights: dict[str, float] | None = None) -> float:
    w = weights or DEFAULT_COST_WEIGHTS
    return float(sum(row.get(k, 0.0) * v for k, v in w.items()))


def marginal_gains(rows: Sequence[dict], *, factor: str, value_key: str = "value", cycles_key: str = "total_cycles",
                   resource_key: str | None = None, dr_threshold: float = 0.05,
                   stall_key: str = "te_load_stall_cycles") -> list[dict]:
    rows = [r for r in rows if r.get("valid", True)]
    rows = sorted(rows, key=lambda r: _num(r[value_key]))
    res_key = resource_key or FACTOR_RESOURCE.get(factor, "")
    out: list[dict] = []
    first_mgpr = None
    for a, b in zip(rows, rows[1:]):
        ta, tb = 1.0 / a[cycles_key], 1.0 / b[cycles_key]
        rel = tb / ta - 1.0
        ra, rb = a.get(res_key, 0.0), b.get(res_key, 0.0)
        rel_res = (rb / ra - 1.0) if ra else float("nan")
        mgpr = rel / rel_res if (rel_res and np.isfinite(rel_res) and rel_res != 0) else float("nan")
        if first_mgpr is None and np.isfinite(mgpr):
            first_mgpr = mgpr
        dim = bool(rel < dr_threshold or (first_mgpr and np.isfinite(mgpr) and mgpr < 0.25 * first_mgpr))
        out.append({
            "factor": factor, "from": a[value_key], "to": b[value_key],
            "abs_gain_per_Mcycle": (tb - ta) * 1e6, "rel_gain": rel,
            "cycles_from": a[cycles_key], "cycles_to": b[cycles_key],
            "lat_mean_reduction": a.get("lat_mean", np.nan) - b.get("lat_mean", np.nan),
            "p95_change": b.get("lat_p95", np.nan) - a.get("lat_p95", np.nan),
            "p99_change": b.get("lat_p99", np.nan) - a.get("lat_p99", np.nan),
            "stall_change": b.get(stall_key, 0) - a.get(stall_key, 0),
            "resource_key": res_key, "resource_from": ra, "resource_to": rb, "rel_resource": rel_res,
            "marginal_gain_per_resource": mgpr, "diminishing_returns": dim,
        })
    return out


def _num(v: Any) -> float:
    if isinstance(v, (int, float)):
        return float(v)
    order = {"fixed": 0, "rr": 1, "wrr": 2, "age": 3, "simple": 0, "buffered": 1}
    if isinstance(v, str) and v in order:
        return float(order[v])
    try:
        from .units import parse_size
        return float(parse_size(v))
    except Exception:
        return 0.0


def pareto_front(rows: Sequence[dict], *, objectives: Sequence[tuple[str, str]] = (
        ("throughput", "max"), ("lat_p99", "min"), ("cost_index", "min"))) -> list[dict]:
    cand = [r for r in rows if r.get("valid", True)]
    front = []
    for r in cand:
        dominated = False
        for q in cand:
            if q is r:
                continue
            better_eq = all((q[k] >= r[k]) if d == "max" else (q[k] <= r[k]) for k, d in objectives)
            strictly = any((q[k] > r[k]) if d == "max" else (q[k] < r[k]) for k, d in objectives)
            if better_eq and strictly:
                dominated = True
                break
        if not dominated:
            front.append(r)
    return front


def smallest_meeting(rows: Sequence[dict], targets: dict[str, float]) -> dict | None:
    """Lowest cost-index configuration meeting every ``targets`` entry (``<metric>_max`` / ``<metric>_min``)."""
    ok = []
    for r in rows:
        if not r.get("valid", True):
            continue
        good = True
        for k, v in targets.items():
            if k.endswith("_max"):
                m = k[:-4]
                good &= (m in r) and r[m] <= v
            elif k.endswith("_min"):
                m = k[:-4]
                good &= (m in r) and r[m] >= v
        if good:
            ok.append(r)
    return min(ok, key=lambda r: r["cost_index"]) if ok else None
