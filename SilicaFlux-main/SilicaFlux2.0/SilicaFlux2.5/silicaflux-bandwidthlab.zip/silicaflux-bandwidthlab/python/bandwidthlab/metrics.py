"""Flat per-run metrics used by experiments, sweeps and the optimiser."""
from __future__ import annotations

from typing import Any

import numpy as np

from memorylab.provenance import Provenance

from .config import SystemConfig, provenance_table
from .latency import transaction_table
from .transaction import TxnStatus


def resource_proxies(cfg: SystemConfig) -> dict[str, float]:
    """Explicit hardware-resource proxies (NOT silicon area).  Units are counts / bits."""
    fc = cfg.fabric
    n_m = max(1, len(fc.master_order))
    n_t = 0
    sram_kib = 0.0
    banks = 0
    for m in cfg.memories:
        if m.kind == "sram":
            sram_kib += m.capacity / 1024
            banks += m.banks
            n_t += (m.banks if m.fabric_split else 1) if m.on_fabric else 0
        else:
            n_t += 1
    out = {
        "sram_kib": sram_kib,
        "sram_banks_total": banks,
        "fabric_mux_bits": fc.data_width_bits * n_m * n_t if fc.topology == "crossbar" else fc.data_width_bits * (n_m + n_t),
        "fabric_width_bits": fc.data_width_bits,
        "fabric_queue_bits": fc.input_queue_depth * (fc.data_width_bits + 36) * n_m,
        "dma_fifo_bits": (cfg.dma.fifo_depth * cfg.dma.data_width_bits if (cfg.dma and cfg.dma.engine == "buffered")
                          else (cfg.dma.data_width_bits if cfg.dma else 0)),
        "dma_outstanding_entries": (cfg.dma.max_outstanding_reads + cfg.dma.max_outstanding_writes) if cfg.dma else 0,
        "tensor_macs": cfg.tensor.rows * cfg.tensor.cols if cfg.tensor else 0,
        "vector_lanes": cfg.vector.lanes if cfg.vector else 0,
    }
    return out


def hypothetical_fraction(cfg: SystemConfig) -> float:
    rows = provenance_table(cfg)
    if not rows:
        return 1.0
    return sum(1 for r in rows if r["provenance"] == Provenance.HYPOTHETICAL.value) / len(rows)


def run_metrics(built: Any, res: dict, *, work_macs: int | None = None, focus_master: str | None = None) -> dict:
    """Headline metrics of one simulated run (all EVENT_SIMULATED)."""
    s = built.system
    cfg: SystemConfig = built.cfg
    clk = s.clock
    end = res["run"]["end_cycle"]
    lo, hi = res["window_cycles"]
    win = max(1, hi - lo + 1)
    txns = [t for t in s.ledger.generated.values() if t.t_completed is not None]
    rows = transaction_table(txns, clk.period_fs)
    lat = np.array([r["total_cycles"] for r in rows]) if rows else np.zeros(1)
    m: dict[str, Any] = {
        "config": cfg.name, "category": "EVENT_SIMULATED", "total_cycles": end,
        "total_ns": end * 1e9 / clk.freq_hz, "transactions": len(txns),
        "useful_bytes": res["bandwidth"]["useful_payload"]["bytes"],
        "effective_bw_GBps": res["bandwidth"]["useful_payload"]["GBps"],
        "fabric_bytes_per_cycle": res["bandwidth"]["completed"]["bytes_per_cycle"],
        "lat_mean": float(lat.mean()), "lat_p50": float(np.percentile(lat, 50)), "lat_p95": float(np.percentile(lat, 95)),
        "lat_p99": float(np.percentile(lat, 99)), "lat_max": float(lat.max()),
        "invariant_errors": len(res["invariant_errors"]),
        "errors": sum(1 for t in txns if t.status != TxnStatus.OK),
    }
    if focus_master:
        fl = np.array([r["total_cycles"] for r in rows if r["master"] == focus_master] or [np.nan])
        m.update({f"{focus_master}_lat_mean": float(np.nanmean(fl)), f"{focus_master}_lat_p95":
                  float(np.nanpercentile(fl, 95)), f"{focus_master}_lat_p99": float(np.nanpercentile(fl, 99)),
                  f"{focus_master}_lat_max": float(np.nanmax(fl)), f"{focus_master}_n": int(np.sum(~np.isnan(fl)))})
        comps = [r for r in rows if r["master"] == focus_master]
        if comps:
            m[f"{focus_master}_arbitration_mean"] = float(np.mean([r["arbitration_cycles"] for r in comps]))
            m[f"{focus_master}_service_mean"] = float(np.mean([r["memory_service_cycles"] for r in comps]))
            m[f"{focus_master}_target_wait_mean"] = float(np.mean([r["target_wait_cycles"] for r in comps]))
    # SRAM conflicts and queueing
    conf = 0
    qmax = 0
    for sr in res["srams"].values():
        conf += sr["conflicts"] + sr["collisions"]
        qmax = max(qmax, max((b["max_queue_occupancy"] for b in sr["banks"]), default=0))
    ic = res["interconnect"] or {}
    m["sram_bank_conflicts"] = conf
    m["fabric_contention_cycles"] = sum(t["contention_cycles"] for t in ic.get("targets", []))
    m["fabric_backpressure_cycles"] = sum(x["request_backpressure_cycles"] for x in ic.get("masters", []))
    m["max_bank_queue"] = qmax
    m["max_arbitration_wait"] = max((x["max_arbitration_wait_cycles"] for x in ic.get("masters", [])), default=0)
    # DMA
    if res["dmas"]:
        d = next(iter(res["dmas"].values()))
        m["dma_useful_bytes"] = d["useful_bytes"]
        m["dma_busy_cycles"] = d["busy_cycles"]
        m["dma_efficiency_B_per_busy_cycle"] = d["useful_bytes"] / d["busy_cycles"] if d["busy_cycles"] else 0.0
        m["dma_avg_fifo"] = d["avg_fifo_occupancy"]
    # accelerators
    ms = res["masters"]
    if "te" in ms and cfg.tensor is not None:
        te = ms["te"]
        peak = cfg.tensor.rows * cfg.tensor.cols
        macs = te["useful_ops"]
        m["te_macs"] = macs
        m["te_mac_util_total"] = macs / (peak * end) if end else 0.0
        span = te["span_cycles"] or end
        m["te_mac_util_active"] = macs / (peak * span) if span else 0.0
        tis = te["time_in_state"]
        m["te_load_stall_cycles"] = tis.get("mem_stall", 0)
        m["te_store_stall_cycles"] = tis.get("store_stall", 0)
        m["te_compute_cycles"] = te["compute_cycles"]
        m["te_sustained_GOPS"] = 2 * macs / (end / clk.freq_hz) / 1e9 if end else 0.0
    if "ve" in ms and cfg.vector is not None:
        ve = ms["ve"]
        m["ve_lane_util_total"] = ve["useful_ops"] / (cfg.vector.lanes * end) if end else 0.0
        m["ve_mem_stall_cycles"] = ve["time_in_state"].get("mem_stall", 0)
    for name in ("cpu_d", "cpu_bg"):
        if name in ms:
            tis = ms[name]["time_in_state"]
            m[f"{name}_stall_cycles"] = tis.get("mem_stall", 0) + tis.get("backpressure", 0) + \
                tis.get("outstanding_stall", 0) + tis.get("store_stall", 0)
    if work_macs:
        m["work_macs"] = work_macs
    m.update({f"res_{k}": v for k, v in resource_proxies(cfg).items()})
    m["hypothetical_param_fraction"] = round(hypothetical_fraction(cfg), 3)
    m["fabric_rtl_equivalent"] = bool(ic.get("rtl_equivalent", False))
    return m
