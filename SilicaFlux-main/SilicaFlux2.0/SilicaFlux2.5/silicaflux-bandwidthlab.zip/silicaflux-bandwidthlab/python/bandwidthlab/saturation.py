"""Offered-load (saturation) studies.

An :class:`Injector` generates open-loop arrivals (Bernoulli per cycle, or periodic) for a
fixed injection window and keeps them in a *source queue* in front of its fabric port.
Admission policies:

  backpressure  finite source queue (default): when it is full the source is held -- the
                arrival process is throttled, so latency stays bounded and the accepted rate
                plateaus at the fabric's service capacity
  drop          finite source queue; arrivals that find it full are rejected (counted)
  unbounded     infinite source queue: under overload the queue and the latency grow
                without bound for as long as injection lasts (detected by a positive trend)

Latency is measured from the *arrival* time (so source queueing is included) to response
acceptance.  The offered rate is what the arrival process produced; accepted = handshakes
with the fabric; completed = responses.  A constant-throughput, zero-latency answer under
overload is impossible by construction: every request occupies the single-outstanding
SFB2 port for at least one cycle and queueing is explicit.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Any

import numpy as np

from .events import EventType
from .scheduler import Scheduler
from .transaction import MemTransaction, TransactionLedger, TxnKind, TxnState, TxnStatus


class Injector:
    kind = "injector"
    rank = 2

    def __init__(self, sched: Scheduler, *, name: str, domain: str, link: Any, rate: float, cycles: int,
                 base: int, region_bytes: int, word: int = 4, write_fraction: float = 0.3,
                 queue_depth: int | None = 16, admission: str = "backpressure", arrivals: str = "bernoulli",
                 seed: int = 1, ledger: TransactionLedger | None = None, start_cycle: int = 0,
                 max_outstanding: int = 1) -> None:
        if admission not in ("backpressure", "drop", "unbounded"):
            raise ValueError("admission backpressure|drop|unbounded")
        if not 0 < rate <= 1:
            raise ValueError("injection rate must be in (0, 1] requests/cycle per master")
        self.sched, self.name, self.domain, self.link = sched, name, domain, link
        self.drv = sched.driver(domain)
        self.clock = self.drv.clock
        self.rate, self.cycles, self.base, self.region, self.word = rate, cycles, base, region_bytes, word
        self.wf, self.admission, self.arrivals = write_fraction, admission, arrivals
        self.qd = None if admission == "unbounded" else (queue_depth or 1)
        self.rng = np.random.Generator(np.random.PCG64(seed))
        self.ledger = ledger
        self.start, self.end = start_cycle, start_cycle + cycles
        self.max_out = max_outstanding
        self.q: deque[tuple[int, MemTransaction]] = deque()
        self.presented: MemTransaction | None = None
        self.outstanding_n = 0
        self.offered = self.dropped = self.throttled = 0
        self.accept_count = 0
        self.done: list[MemTransaction] = []
        self.q_samples: list[tuple[int, int]] = []
        self._acc = 0.0
        link.bind(self)
        self.drv.attach(self)
        sched.register(self)
        self.drv.wake(self.clock.edge(start_cycle))

    def outstanding(self) -> int:
        return len(self.q) + self.outstanding_n + (1 if self.drv.cycle() + 1 < self.end else 0)

    def busy(self) -> bool:
        return self.drv.cycle() + 1 < self.end or bool(self.q) or self.presented is not None

    def on_link_accept(self, link: Any, t: MemTransaction, cyc: int) -> None:
        if self.presented is t:
            self.presented = None
        self.accept_count += 1

    def on_response(self, cyc: int) -> None:
        t = self.link.poll_response(cyc)
        if t is None:
            return
        now = self.sched.now
        t.advance(TxnState.COMPLETED, now)
        if t.status == TxnStatus.PENDING:
            t.status = TxnStatus.OK
        if self.ledger is not None:
            self.ledger.on_completed(t, now)
        self.sched.emit(EventType.RESPONSE_ACCEPTED, domain=self.domain, txn=t, src=t.dst, dst=self.name)
        self.outstanding_n -= 1
        self.done.append(t)

    def _arrivals(self, cyc: int) -> int:
        if not (self.start <= cyc < self.end):
            return 0
        if self.arrivals == "periodic":
            self._acc += self.rate
            n = int(self._acc)
            self._acc -= n
            return n
        return 1 if self.rng.random() < self.rate else 0

    def on_issue(self, cyc: int) -> None:
        for _ in range(self._arrivals(cyc)):
            if self.qd is not None and len(self.q) >= self.qd:
                if self.admission == "drop":
                    self.dropped += 1
                    continue
                self.throttled += 1            # backpressure: the source is held, arrival not generated
                continue
            self.offered += 1
            kind = TxnKind.WRITE if self.rng.random() < self.wf else TxnKind.READ
            addr = self.base + int(self.rng.integers(0, self.region // self.word)) * self.word
            t = MemTransaction.new(self.sched.new_id(), self.name, kind, addr, self.word, self.sched.now,
                                   data=0 if kind == TxnKind.WRITE else None, domain=self.domain)
            if self.ledger is not None:
                self.ledger.on_generated(t)
            self.sched.emit(EventType.REQUEST_GENERATED, domain=self.domain, txn=t, src=self.name, dst=self.link.name)
            self.q.append((cyc, t))
        if self.presented is None and self.q and self.outstanding_n < self.max_out and self.link.can_present(cyc):
            _, t = self.q.popleft()
            t.advance(TxnState.ISSUED, self.sched.now)
            self.presented = t
            self.outstanding_n += 1
            self.link.present(t)

    def on_post(self, cyc: int) -> None:
        self.q_samples.append((cyc, len(self.q)))


@dataclass
class LoadPoint:
    offered_rate: float
    offered_per_cycle: float
    accepted_per_cycle: float
    completed_per_cycle: float
    lat_mean: float
    lat_p95: float
    lat_p99: float
    lat_max: float
    queue_mean: float
    queue_max: int
    dropped: int
    throttled: int
    n: int
    latency_trend_cycles_per_kcycle: float
    stall_cycles: int


def run_load_point(build_fn, *, rate: float, n_masters: int, cycles: int, target: str, admission: str,
                   queue_depth: int | None, seed: int, region_bytes: int = 8192, write_fraction: float = 0.3,
                   same_bank: bool = True) -> LoadPoint:
    """One offered-load point: ``n_masters`` injectors, each at ``rate`` requests/cycle."""
    b = build_fn()
    s = b.system
    mem = b.cfg.memory(target)
    inj = []
    for i in range(n_masters):
        name = f"inj{i}"
        off = 0 if same_bank else (i * mem.capacity // max(1, n_masters))
        inj.append(Injector(s.sched, name=name, domain=s.fabric_clock, link=b.link(name), rate=rate, cycles=cycles,
                            base=mem.base + off, region_bytes=min(region_bytes, mem.capacity - off),
                            write_fraction=write_fraction, queue_depth=queue_depth, admission=admission,
                            seed=seed + 7 * i, ledger=s.ledger))
    s.run()
    period = s.clock.period_fs
    done = [t for j in inj for t in j.done]
    # latency from arrival (t_created) to completion, in cycles
    lat = np.array([(t.t_completed - t.t_created) / period for t in done]) if done else np.zeros(1)
    # throughput is measured inside the injection window only (the drain afterwards is excluded)
    t_end = s.clock.edge(cycles)
    acc = sum(1 for t in s.ledger.generated.values() if t.t_accepted is not None and t.t_accepted <= t_end)
    comp_in = sum(1 for t in done if t.t_completed <= t_end)
    offered = sum(j.offered + j.dropped + j.throttled for j in inj)
    qs = np.array([q for j in inj for _, q in j.q_samples]) if inj else np.zeros(1)
    # trend of latency vs arrival time (cycles of latency per 1000 cycles of run time)
    if len(done) > 10:
        x = np.array([t.t_created / period for t in done])
        trend = float(np.polyfit(x, lat, 1)[0] * 1000)
    else:
        trend = 0.0
    stalls = sum(j.throttled for j in inj)
    return LoadPoint(rate, offered / cycles, acc / cycles, comp_in / cycles, float(lat.mean()),
                     float(np.percentile(lat, 95)), float(np.percentile(lat, 99)), float(lat.max()),
                     float(qs.mean()), int(qs.max()), sum(j.dropped for j in inj), stalls, len(done), trend, stalls)


def offered_load_sweep(build_fn, rates: list[float], **kw: Any) -> list[LoadPoint]:
    return [run_load_point(build_fn, rate=r, **kw) for r in rates]


def classify_regions(points: list[LoadPoint], *, queueing_factor: float = 1.25, plateau_gain: float = 0.02,
                     trend_threshold: float = 5.0) -> dict:
    """Operating regions from a monotone sweep (definitions stated in the result)."""
    if not points:
        return {}
    l0 = points[0].lat_mean
    peak = max(p.completed_per_cycle for p in points)
    onset = next((p.offered_rate for p in points if p.lat_mean > queueing_factor * l0), None)
    plateau = None
    for a, b_ in zip(points, points[1:]):
        if b_.offered_per_cycle > a.offered_per_cycle and \
                (b_.completed_per_cycle - a.completed_per_cycle) < plateau_gain * max(a.completed_per_cycle, 1e-9):
            plateau = a.offered_rate
            break
    near = next((p.offered_rate for p in points if p.completed_per_cycle >= 0.95 * peak), None)
    unstable = [p.offered_rate for p in points if p.latency_trend_cycles_per_kcycle > trend_threshold]
    return {"zero_load_latency_cycles": l0, "peak_completed_per_cycle": peak,
            "onset_of_queueing_rate": onset, "plateau_start_rate": plateau, "near_saturation_rate": near,
            "unbounded_growth_rates": unstable,
            "definitions": {"onset": f"first load with mean latency > {queueing_factor} x zero-load latency",
                            "plateau": f"first load step whose completed-throughput gain < {plateau_gain:.0%}",
                            "near_saturation": "first load reaching 95 % of the peak completed throughput",
                            "unbounded": f"latency trend > {trend_threshold} cycles per 1000 cycles of run time"}}
