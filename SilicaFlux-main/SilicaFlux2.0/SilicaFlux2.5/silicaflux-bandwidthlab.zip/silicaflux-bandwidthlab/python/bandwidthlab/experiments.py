"""SilicaFlux-V experiments A-J (brief section 32).

All results are EVENT_SIMULATED predictions on the PROVISIONAL configuration
(configs/silicaflux_v.yaml) -- simulation experiments, not physical SilicaFlux results.
Every experiment states its workload, the variants, the hardware-resource assumptions and
a recommendation that is computed from the simulated numbers by fixed rules
(``recommend``).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

from .saturation import classify_regions, offered_load_sweep
from .sweep import run_variants
from . import scenarios as sc
from .config import load_config

TILE_ARGS = {"M": 32, "N": 32, "K": 64,
             "cpu_background": {"pattern": "seq_read", "n": 1500, "offset": "half", "region_bytes": 8192}}

EXPERIMENTS = {
    "A": "One SRAM bank versus four banks",
    "B": "Four banks versus eight banks",
    "C": "32-bit versus 64-bit interconnect",
    "D": "Simple DMA versus buffered DMA",
    "E": "CPU competing with DMA",
    "F": "CPU competing with tensor traffic",
    "G": "4x4 tensor array versus 8x8",
    "H": "Increasing memory offered load until saturation",
    "I": "Different bank address mappings",
    "J": "Different arbitration policies",
}


def _v(cfg: str, label: str, over: dict, scenario: str, args: dict, focus: str | None = "cpu_bg",
       group: str | None = None) -> dict:
    d = {"config": cfg, "overrides": over, "scenario": scenario, "args": args, "label": label,
         "factor": label, "value": label, "seed": 1, "focus_master": focus}
    if group:
        d["group"] = group          # explicit comparison group (rows compared with the group's first row)
    return d


def specs(cfg_path: str) -> dict[str, list[dict]]:
    c = cfg_path
    buf = {"dma.engine": "buffered", "dma.fifo_depth": 8, "dma.burst": 8}
    mix = {"nbytes": 8192, "cpu_n": 3000}
    return {
        "A": [_v(c, "1 bank", {"memories.sram.banks": 1}, "tile_pipeline", TILE_ARGS),
              _v(c, "4 banks", {"memories.sram.banks": 4}, "tile_pipeline", TILE_ARGS),
              _v(c, "1 bank (CPU vs DMA)", {"memories.sram.banks": 1}, "cpu_vs_dma",
                 {**mix, "dst_off": 0x8000, "same_bank": False}, group="A2"),
              _v(c, "4 banks (CPU vs DMA)", {"memories.sram.banks": 4}, "cpu_vs_dma",
                 {**mix, "dst_off": 0x10000, "same_bank": False}, group="A2")],
        "B": [_v(c, "4 banks contiguous", {"memories.sram.banks": 4}, "multi_stream",
                 {"streams": 4, "n": 2000, "pattern": "seq_read", "spacing": 0x8000}, None),
              _v(c, "8 banks contiguous", {"memories.sram.banks": 8}, "multi_stream",
                 {"streams": 4, "n": 2000, "pattern": "seq_read", "spacing": 0x8000}, None),
              _v(c, "4 banks interleaved", {"memories.sram.banks": 4, "memories.sram.mapping": "low"},
                 "multi_stream", {"streams": 4, "n": 2000, "pattern": "seq_read", "spacing": 0x8000}, None),
              _v(c, "8 banks interleaved", {"memories.sram.banks": 8, "memories.sram.mapping": "low"},
                 "multi_stream", {"streams": 4, "n": 2000, "pattern": "seq_read", "spacing": 0x8000}, None),
              _v(c, "4 banks (tile pipeline)", {"memories.sram.banks": 4, **buf}, "tile_pipeline", TILE_ARGS),
              _v(c, "8 banks (tile pipeline)", {"memories.sram.banks": 8, **buf}, "tile_pipeline", TILE_ARGS)],
        "C": [_v(c, "32-bit fabric, simple DMA", {}, "tile_pipeline", TILE_ARGS),
              _v(c, "64-bit fabric, simple DMA", {"fabric.data_width_bits": 64, "dma.data_width_bits": 64},
                 "tile_pipeline", TILE_ARGS),
              _v(c, "32-bit fabric, buffered DMA", buf, "tile_pipeline", TILE_ARGS),
              _v(c, "64-bit fabric, buffered DMA", {**buf, "fabric.data_width_bits": 64, "dma.data_width_bits": 64},
                 "tile_pipeline", TILE_ARGS),
              _v(c, "32-bit fabric, DMA copy 16 KiB", {}, "dma_copy",
                 {"src_mem": "sram", "dst_mem": "sram", "nbytes": 16384, "dst_off": 0x10000}, None),
              _v(c, "64-bit fabric, DMA copy 16 KiB", {"fabric.data_width_bits": 64, "dma.data_width_bits": 64},
                 "dma_copy", {"src_mem": "sram", "dst_mem": "sram", "nbytes": 16384, "dst_off": 0x10000}, None)],
        "D": [_v(c, "no DMA: CPU copy loops (release-1 style)", {}, "tile_pipeline", {**TILE_ARGS, "staging": "cpu"}),
              _v(c, "simple (L0)", {}, "tile_pipeline", TILE_ARGS),
              _v(c, "buffered FIFO 8 burst 8 (L1)", buf, "tile_pipeline", TILE_ARGS),
              _v(c, "buffered dual-port (L2)", {**buf, "dma.dual_port": True, "fabric.master_order":
                                                ["dbg", "cpu_d", "cpu_i", "dma_rd", "dma_wr"],
                                                "fabric.access": {"cpu_i": ["rom", "sram", "tspm"],
                                                                  "dma_rd": ["rom", "sram", "tspm"],
                                                                  "dma_wr": ["rom", "sram", "tspm"]}},
                 "tile_pipeline", TILE_ARGS),
              _v(c, "buffered + scatter-gather (L1+L4 ext)", {**buf, "dma.scatter_gather": True},
                 "tile_pipeline", TILE_ARGS)],
        "E": [_v(c, "CPU alone", {}, "cpu_vs_dma", {**mix, "nbytes": 4, "same_bank": False}),
              _v(c, "CPU + DMA, different banks", {}, "cpu_vs_dma", {**mix, "same_bank": False}),
              _v(c, "CPU + DMA, same bank", {}, "cpu_vs_dma", {**mix, "same_bank": True}),
              _v(c, "CPU + buffered DMA, same bank", buf, "cpu_vs_dma", {**mix, "same_bank": True})],
        "F": [_v(c, "CPU alone on TSPM", {}, "cpu_vs_tensor", {"M": 4, "N": 4, "K": 1, "cpu_n": 2000}, group="F"),
              _v(c, "CPU + TE GEMM on TSPM", {}, "cpu_vs_tensor", {"M": 16, "N": 16, "K": 128, "cpu_n": 2000},
                 group="F"),
              _v(c, "TE GEMM alone", {}, "gemm_local", {"M": 16, "N": 16, "K": 128}, None, group="F")],
        "G": [_v(c, "4x4, operands resident", {}, "gemm_local", {"M": 32, "N": 32, "K": 64}, None),
              _v(c, "8x8, operands resident", {"tensor.rows": 8, "tensor.cols": 8}, "gemm_local",
                 {"M": 32, "N": 32, "K": 64}, None),
              _v(c, "4x4, DMA-staged pipeline", buf, "tile_pipeline", TILE_ARGS),
              _v(c, "8x8, DMA-staged pipeline", {**buf, "tensor.rows": 8, "tensor.cols": 8}, "tile_pipeline",
                 TILE_ARGS)],
        "I": [_v(c, f"4 banks {m}", {"memories.sram.banks": 4, "memories.sram.mapping": m}, "multi_stream",
                 {"streams": 3, "n": 2000, "pattern": "strided", "stride_words": 4, "spacing": 0x40}, None)
              for m in ("high", "low", "xor", "skew")] +
             [_v(c, f"3 banks {m}", {"memories.sram.banks": 3, "memories.sram.capacity": "192KiB",
                                     "memories.sram.mapping": m}, "multi_stream",
                 {"streams": 3, "n": 2000, "pattern": "strided", "stride_words": 4, "spacing": 0x40}, None)
              for m in ("modulo", "skew")],
        "J": [_v(c, "round robin", {"fabric.arbitration": "rr"}, "cpu_vs_dma", {**mix, "same_bank": True}),
              _v(c, "fixed, CPU highest", {"fabric.arbitration": "fixed", "fabric.master_order":
                                           ["cpu_bg", "dbg", "cpu_d", "cpu_i", "dma"]}, "cpu_vs_dma",
                 {**mix, "same_bank": True}),
              _v(c, "fixed, DMA highest", {"fabric.arbitration": "fixed", "fabric.master_order":
                                           ["dma", "dbg", "cpu_d", "cpu_i", "cpu_bg"]}, "cpu_vs_dma",
                 {**mix, "same_bank": True}),
              _v(c, "weighted RR (DMA 3 : CPU 1)", {"fabric.arbitration": "wrr", "fabric.weights": {"dma": 3},
                                                    "fabric.master_order": ["dbg", "cpu_d", "cpu_i", "dma",
                                                                            "cpu_bg"]},
                 "cpu_vs_dma", {**mix, "same_bank": True}),
              _v(c, "age-based", {"fabric.arbitration": "age"}, "cpu_vs_dma", {**mix, "same_bank": True})],
    }


def recommend(rows: list[dict], ref: int = 0) -> list[str]:
    """Fixed, data-driven rules: >= 10 % throughput gain -> worthwhile; < 2 % -> no benefit."""
    base = rows[ref]
    out = []
    for i, r in enumerate(rows):
        if not r.get("valid", False):
            out.append(f"invalid: {r.get('reason', '')}")
            continue
        if i == ref:
            out.append("reference")
            continue
        gain = base["total_cycles"] / r["total_cycles"] - 1
        p99 = r.get("cpu_bg_lat_p99")
        p99b = base.get("cpu_bg_lat_p99")
        lat_note = ""
        if p99 is not None and p99b is not None and np.isfinite(p99) and np.isfinite(p99b):
            lat_note = f"; CPU P99 {p99b:.0f}->{p99:.0f} cycles"
        if gain >= 0.10:
            out.append(f"worthwhile: {gain:+.1%} throughput{lat_note}")
        elif gain >= 0.02:
            out.append(f"modest: {gain:+.1%} throughput{lat_note}")
        elif gain > -0.02:
            out.append(f"no measurable benefit ({gain:+.1%}){lat_note}")
        else:
            out.append(f"worse: {gain:+.1%} throughput{lat_note}")
    return out


def recommend_qos(rows: list[dict], ref: int = 0) -> list[str]:
    """Contention experiments: judge CPU tail latency and DMA completion, not total cycles."""
    base = rows[ref]
    out = []
    for i, r in enumerate(rows):
        if not r.get("valid", False):
            out.append(f"invalid: {r.get('reason', '')}")
            continue
        parts = []
        for k, lab in (("cpu_bg_lat_p99", "CPU P99"), ("cpu_bg_lat_max", "CPU max"), ("dma_copy_cycles", "DMA copy"),
                       ("te_mac_util_active", "TE util")):
            if r.get(k) is not None and base.get(k) is not None:
                parts.append(f"{lab} {base[k]:.3g}->{r[k]:.3g}")
        out.append("reference: " + "; ".join(parts) if i == ref else "; ".join(parts))
    return out


QOS_EXPERIMENTS = ("E", "F", "J")


def run_all(cfg_path: str, out_dir: Path, *, workers: int | None = None, only: str | None = None) -> dict[str, Any]:
    sp = specs(cfg_path)
    results: dict[str, Any] = {}
    keys = [k for k in "ABCDEFGIJ" if (only is None or k in only)]
    flat = [(k, s) for k in keys for s in sp[k]]
    rows = run_variants([s for _, s in flat], workers=workers)
    for k in keys:
        rk = [r for (kk, _), r in zip(flat, rows) if kk == k]
        sk = [s_ for kk, s_ in flat if kk == k]
        # compare only variants that ran the same workload (scenario + arguments)
        groups: dict[str, list[int]] = {}
        for i, s_ in enumerate(sk):
            key_args = {a: v for a, v in s_["args"].items() if a != "staging"}   # staging variants compare directly
            key = s_.get("group") or json.dumps([s_["scenario"], key_args], sort_keys=True)
            groups.setdefault(key, []).append(i)
        for gi, idx in enumerate(groups.values()):
            sub = [rk[i] for i in idx]
            recs = recommend_qos(sub) if k in QOS_EXPERIMENTS else recommend(sub)
            for i, rec in zip(idx, recs):
                rk[i]["recommendation"] = rec
                rk[i]["workload_group"] = gi
        results[k] = {"title": EXPERIMENTS[k], "rows": rk}
    if only is None or "H" in only:
        results["H"] = experiment_h(cfg_path)
    return results


def experiment_h(cfg_path: str, rates: list[float] | None = None, cycles: int = 4000) -> dict:
    rates = rates or [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.5, 0.7, 1.0]
    cfg = load_config(cfg_path)
    cfg8 = load_config(cfg_path, {"memories.sram.banks": 8, "memories.sram.mapping": "low"})
    out: dict[str, Any] = {"title": EXPERIMENTS["H"], "curves": {}}
    for label, c, same, adm in (("1 target bank, finite queue (backpressure)", cfg, True, "backpressure"),
                                ("1 target bank, unbounded source queue", cfg, True, "unbounded"),
                                ("1 target bank, drop when full", cfg, True, "drop"),
                                ("8 interleaved banks, finite queue", cfg8, False, "backpressure")):
        pts = offered_load_sweep(lambda c=c: sc.build(c, record_events=False), rates, n_masters=3, cycles=cycles,
                                 target="sram", admission=adm, queue_depth=8, seed=1, same_bank=same,
                                 region_bytes=4096)
        out["curves"][label] = {"points": [p.__dict__ for p in pts], "regions": classify_regions(pts),
                                "assumptions": {"masters": 3, "rate_per_master": "x-axis (requests/cycle)",
                                                "arrivals": "Bernoulli per cycle", "access": "4-byte, 30 % writes,"
                                                " uniform in a 4 KiB region", "source_queue_depth": 8 if adm !=
                                                "unbounded" else "unbounded", "admission": adm,
                                                "injection_cycles": cycles}}
    return out
