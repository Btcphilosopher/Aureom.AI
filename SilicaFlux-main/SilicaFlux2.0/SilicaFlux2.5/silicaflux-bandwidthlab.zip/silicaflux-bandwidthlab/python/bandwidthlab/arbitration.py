"""Arbiters.

``fixed``  fixed priority, index 0 highest (sfb_arbiter MODE=0, sfv_xbar).
``rr``     round robin; the pointer moves to winner + 1 *only when the grant is accepted*
           (sfb_arbiter MODE=1, sfb_arbiter.sv:95-96).
``wrr``    weighted round robin (extension, not in the audited RTL): each requester holds
           ``weight`` credits per round; requesters with credit are served in round-robin
           order; credits are refilled when no current requester has credit left.
``age``    oldest request first (extension); ties broken by index.

Grant locking (a stalled grant is held while the requester still requests,
sfb_arbiter.sv:60-62) is implemented by the interconnect, which does not re-arbitrate a
port while its granted request waits for the target.
"""
from __future__ import annotations

from typing import Sequence


class ArbiterConfigError(ValueError):
    pass


POLICIES = ("fixed", "rr", "wrr", "age")


class Arbiter:
    def __init__(self, n: int, policy: str = "rr", weights: Sequence[int] | None = None, name: str = "arb") -> None:
        if n < 1:
            raise ArbiterConfigError("arbiter needs at least one requester")
        if policy not in POLICIES:
            raise ArbiterConfigError(f"unknown arbitration policy {policy!r}; one of {POLICIES}")
        if policy == "wrr":
            if weights is None or len(weights) != n or any(w < 1 for w in weights):
                raise ArbiterConfigError("wrr needs one integer weight >= 1 per requester")
        self.n, self.policy, self.name = n, policy, name
        self.weights = list(weights) if weights is not None else [1] * n
        self.credits = list(self.weights)
        self.ptr = 0
        self.grants = [0] * n

    def pick(self, requesters: Sequence[int], ages: dict[int, int] | None = None) -> int | None:
        """Winner among ``requesters`` (no state change)."""
        if not requesters:
            return None
        req = set(requesters)
        n = self.n
        if self.policy == "fixed":
            return min(req)
        if self.policy == "age":
            if ages is None:
                raise ArbiterConfigError("age arbitration needs request ages")
            return min(req, key=lambda i: (ages[i], i))
        if self.policy == "wrr":
            with_credit = [i for i in req if self.credits[i] > 0]
            if not with_credit:
                return min(req, key=lambda i: (i - self.ptr) % n)
            return min(with_credit, key=lambda i: (i - self.ptr) % n)
        return min(req, key=lambda i: (i - self.ptr) % n)

    def accept(self, winner: int, requesters: Sequence[int] = ()) -> None:
        """Update state when the granted request is accepted."""
        self.grants[winner] += 1
        if self.policy in ("rr", "wrr"):
            self.ptr = 0 if winner == self.n - 1 else winner + 1
        if self.policy == "wrr":
            if self.credits[winner] > 0:
                self.credits[winner] -= 1
            reqs = set(requesters) | {winner}
            if all(self.credits[i] == 0 for i in reqs):
                self.credits = list(self.weights)
