"""LEVEL 3 -- RTL calibration and holdout validation.

Three evidence streams, each with an explicit separation between the data used to fit a
parameter (CALIBRATION set) and the data used to judge the model (HOLDOUT set):

1. DataFabric crossbar, transaction by transaction (no fitted parameters).  The UNMODIFIED
   ``sfb_crossbar`` RTL (arbiter, decoder, muxes, response router, error slave) is driven by
   ``rtl_harness/tb_bandwidthlab_xbar.sv`` under Verilator (Icarus fallback) from a stimulus
   file; the BandwidthLab interconnect model executes the same file.  Compared per
   transaction: acceptance cycle, response cycle, error flag, read data.  All configurations
   are holdout cases (nothing is tuned).
2. DMA engines.  RTL cycle counts recorded in the repository
   (silicaflux-datafabric reports/datafabric/benchmark.md, "MEASURED, Verilator", 4 KiB
   copies) -- RTL_SIMULATED evidence produced by an earlier project, not re-run here.  One
   parameter (start/finish overhead = setup_cycles + completion_cycles) is fitted on the
   calibration rows {simple_d32, buf_f8_b8}; all other rows are holdout.
3. SilicaFlux-V engines.  The unmodified ``sfv_tile`` is run under Verilator through
   MemoryLab's harness (memorylab.rtl_integration.run_tile_latency); its CYCLES registers are
   RTL_OBSERVED in this session.  The vector and tensor ``overhead_cycles`` are fitted on a
   small calibration subset; every other command is holdout.

Error metrics: absolute error (cycles), relative error |pred - obs| / obs, mean absolute
percentage error (MAPE) and max relative error, reported separately for calibration and
holdout.  Fitted parameters are recorded with the data they were fitted on.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from memorylab.bankbench import backpressure_ready

from .bus import FabricConfig
from .dma import Descriptor, DmaConfig
from .events import EventType
from .simulation import System
from .sram import SramConfig
from .transaction import MemTransaction, TxnKind, TxnState, TxnStatus

ROOT = Path(__file__).resolve().parents[2]
HARNESS = ROOT / "rtl_harness" / "tb_bandwidthlab_xbar.sv"
DF_ZIP_REL = Path("SilicaFlux-main/silicaflux-datafabric.zip")
XBAR_RTL = ["sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv", "sfb_error_slave.sv",
            "sfb_crossbar.sv"]


class RtlUnavailable(RuntimeError):
    pass


# ---------------------------------------------------------------------------- locating the repository
def find_repo(start: Path | None = None) -> Path | None:
    env = os.environ.get("SILICAFLUX_REPO")
    if env and (Path(env) / DF_ZIP_REL).exists():
        return Path(env)
    for base in [start or Path.cwd(), ROOT]:
        p = Path(base).resolve()
        for q in [p, *p.parents]:
            if (q / DF_ZIP_REL).exists():
                return q
    return None


def locate_datafabric(build: Path) -> Path:
    repo = find_repo()
    if repo is None:
        raise RtlUnavailable("silicaflux-datafabric.zip not found: set SILICAFLUX_REPO to the Aureom.AI checkout")
    dest = build / "datafabric"
    root = dest / "silicaflux-datafabric"
    if not (root / "rtl/interconnect/sfb_crossbar.sv").exists():
        dest.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(repo / DF_ZIP_REL) as z:
            for n in z.namelist():
                if ".." in Path(n).parts or n.startswith("/"):
                    raise RtlUnavailable(f"unsafe path in archive: {n}")
            z.extractall(dest)
    return root


def simulators() -> dict[str, str | None]:
    return {s: shutil.which(s) for s in ("verilator", "iverilog", "vvp")}


def _err(pred: float, obs: float) -> tuple[float, float]:
    return pred - obs, (abs(pred - obs) / obs if obs else float("nan"))


def _summ(rows: list[dict], key: str = "rel_error") -> dict:
    v = np.array([r[key] for r in rows if r.get(key) is not None and np.isfinite(r[key])], dtype=float)
    if v.size == 0:
        return {"n": 0}
    ae = np.array([abs(r["abs_error"]) for r in rows], dtype=float)
    return {"n": int(v.size), "mape": float(v.mean()), "max_rel_error": float(v.max()),
            "mean_abs_error_cycles": float(ae.mean()), "max_abs_error_cycles": float(ae.max()),
            "exact": int((ae == 0).sum())}


# ---------------------------------------------------------------------------- 1. crossbar equivalence
@dataclass(frozen=True)
class XReq:
    nb: int
    we: int
    addr: int
    data: int


def xbar_stimulus(nm: int, ns: int, n: int, seed: int, kind: str) -> list[list[XReq]]:
    rng = np.random.Generator(np.random.PCG64(seed))
    out = []
    for m in range(nm):
        c = 1
        reqs = []
        for i in range(n):
            if kind == "hot":
                s, gap = 0, 0
            elif kind == "bursty":
                s, gap = int(rng.integers(0, ns)), (0 if rng.random() < 0.8 else int(rng.integers(3, 12)))
            else:
                s, gap = int(rng.integers(0, ns)), int(rng.integers(0, 3))
            addr = 0x1000_0000 + s * 0x1000 + int(rng.integers(0, 1024)) * 4
            if kind == "random" and rng.random() < 0.03:
                addr = 0x7000_0000 + int(rng.integers(0, 1024)) * 4          # unmapped -> error slave
            we = int(rng.random() < 0.3)
            c += gap
            reqs.append(XReq(c, we, addr, int(rng.integers(0, 1 << 32))))
        out.append(reqs)
    return out


def write_stim(path: Path, stim: list[list[XReq]]) -> Path:
    lines = [f"{len(stim)} {max(len(s) for s in stim)}"]
    for m, reqs in enumerate(stim):
        lines.append(f"M {m} {len(reqs)}")
        lines += [f"{r.nb} {r.we} {r.addr:x} {r.data:x}" for r in reqs]
    path.write_text("\n".join(lines) + "\n")
    return path


def run_rtl_xbar(stim: list[list[XReq]], *, ns: int, lat: int, arb: int, bp: int, seed: int, work: Path,
                 sim: str = "verilator", tag: str = "x") -> dict:
    nm = len(stim)
    df = locate_datafabric(work)
    files = [str(df / "rtl/interconnect" / f) for f in XBAR_RTL]
    maxn = max(len(s) for s in stim)
    import hashlib
    h = hashlib.sha256(b"".join(Path(f).read_bytes() for f in [*files, str(HARNESS)])).hexdigest()[:10]
    key = f"nm{nm}_ns{ns}_lat{lat}_arb{arb}_maxn{maxn}_{sim}_{h}"
    bdir = work / "xbar_build" / key
    stimf = write_stim(work / f"stim_{tag}.txt", stim)
    outf = work / f"rtl_{tag}.log"
    params = [f"-GNM={nm}", f"-GNS={ns}", f"-GLAT={lat}", f"-GARB_MODE={arb}", f"-GMAXN={maxn}"]
    if sim == "verilator":
        exe = bdir / "Vxbar"
        cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-O2", "-Wno-fatal", "-Wno-lint",
               "-Wno-style", "--top-module", "tb_bandwidthlab_xbar", *params, *files, str(HARNESS),
               "--Mdir", str(bdir), "-o", "Vxbar"]
        if not exe.exists():
            bdir.mkdir(parents=True, exist_ok=True)
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
            if r.returncode != 0:
                raise RuntimeError(f"verilator build failed:\n{r.stdout[-3000:]}\n{r.stderr[-3000:]}")
        run = [str(exe), f"+stim={stimf}", f"+out={outf}", f"+seed={seed}", f"+bp={bp}"]
    else:
        exe = bdir / "xbar.vvp"
        cmd = ["iverilog", "-g2012", "-o", str(exe), "-s", "tb_bandwidthlab_xbar",
               *[f"-Ptb_bandwidthlab_xbar.{p[2:]}" for p in params], *files, str(HARNESS)]
        if not exe.exists():
            bdir.mkdir(parents=True, exist_ok=True)
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
            if r.returncode != 0:
                raise RuntimeError(f"iverilog build failed:\n{r.stdout[-3000:]}\n{r.stderr[-3000:]}")
        run = ["vvp", "-n", str(exe), f"+stim={stimf}", f"+out={outf}", f"+seed={seed}", f"+bp={bp}"]
    r = subprocess.run(run, capture_output=True, text=True, timeout=1800)
    if r.returncode != 0 or not outf.exists():
        raise RuntimeError(f"RTL run failed ({sim}):\n{r.stdout[-2000:]}\n{r.stderr[-2000:]}")
    return {**_parse_log(outf.read_text()), "command": " ".join(cmd), "simulator": sim}


def _parse_log(text: str) -> dict:
    acc, rsp = [], {}
    for line in text.splitlines():
        f = line.split()
        if f and f[0] == "ACC":
            acc.append((int(f[1]), int(f[2]), int(f[3])))
        elif f and f[0] == "RSP":
            rsp.setdefault(int(f[2]), []).append((int(f[1]), int(f[4]), int(f[5], 16)))
    return {"accepts": sorted(acc), "responses": {m: sorted(v) for m, v in rsp.items()}}


class _StimMaster:
    """Executes the harness stimulus rule on a FabricLink (model side)."""
    kind = "stim"
    rank = 2

    def __init__(self, s: System, m: int, reqs: list[XReq], link: Any, bp: int, seed: int) -> None:
        self.s, self.m, self.reqs, self.link = s, m, reqs, link
        self.name = f"m{m}"
        self.drv = s.sched.driver(s.fabric_clock)
        self.i = 0
        self.last_acc = 0
        self.presented = False
        self.acc: list[tuple[int, int, int]] = []
        self.rsp: list[tuple[int, int, int]] = []
        self.pending = 0
        link.bind(self)
        link.ic.set_rsp_ready(link.mi, lambda c, m=m: backpressure_ready(seed, bp, m, c))
        self.drv.attach(self)
        s.sched.register(self)
        self.drv.wake(self.drv.clock.edge(1))

    def outstanding(self) -> int:
        return (len(self.reqs) - self.i) + self.pending

    def busy(self) -> bool:
        return self.i < len(self.reqs) or self.presented

    def on_link_accept(self, link: Any, t: MemTransaction, cyc: int) -> None:
        self.acc.append((cyc, self.m, t.meta["idx"]))
        self.last_acc = cyc
        self.presented = False
        self.i += 1

    def on_response(self, cyc: int) -> None:
        t = self.link.poll_response(cyc)
        if t is not None:
            t.advance(TxnState.COMPLETED, self.s.sched.now)
            self.s.ledger.on_completed(t, self.s.sched.now)
            self.pending -= 1
            self.rsp.append((cyc, int(t.status != TxnStatus.OK), (t.data or 0) if t.op == "R" else 0))

    def on_issue(self, cyc: int) -> None:
        if self.presented or self.i >= len(self.reqs):
            return
        r = self.reqs[self.i]
        if cyc < max(1, r.nb) or cyc <= self.last_acc:
            if cyc < r.nb:
                self.drv.wake(self.drv.clock.edge(r.nb))
            return
        t = MemTransaction.new(self.s.sched.new_id(), self.name, TxnKind.WRITE if r.we else TxnKind.READ, r.addr, 4,
                               self.s.sched.now, data=r.data, byte_enable=0xF)
        t.meta["idx"] = self.i
        t.advance(TxnState.ISSUED, self.s.sched.now)
        self.s.ledger.on_generated(t)
        self.presented = True
        self.pending += 1
        self.link.present(t)


def run_model_xbar(stim: list[list[XReq]], *, ns: int, lat: int, arb: int, bp: int, seed: int) -> dict:
    s = System("xbar_model", fabric_hz=100e6, record_events=False)
    tg = [s.add_sram(SramConfig(name=f"s{i}", base_addr=0x1000_0000 + i * 0x1000, capacity_bytes=0x1000, banks=1,
                                read_latency=lat)) for i in range(ns)]
    s.add_interconnect(FabricConfig(arbitration="fixed" if arb == 0 else "rr"))
    for t in tg:
        s.map_target(t)
    ms = [_StimMaster(s, m, reqs, s.link(f"m{m}"), bp, seed) for m, reqs in enumerate(stim)]
    s.run()
    errs = s.check_invariants()
    return {"accepts": sorted(a for m in ms for a in m.acc), "responses": {m.m: sorted(m.rsp) for m in ms},
            "invariant_errors": errs}


def compare_xbar(rtl: dict, mdl: dict) -> dict:
    ra = {(m, i): c for c, m, i in rtl["accepts"]}
    ma = {(m, i): c for c, m, i in mdl["accepts"]}
    keys = sorted(set(ra) | set(ma))
    acc_err = [ma.get(k, -10**9) - ra.get(k, -10**9) for k in keys]
    rsp_err, flag_mismatch, data_mismatch, n_rsp = [], 0, 0, 0
    for m in sorted(set(rtl["responses"]) | set(mdl["responses"])):
        a, b = rtl["responses"].get(m, []), mdl["responses"].get(m, [])
        n_rsp += max(len(a), len(b))
        for x, y in zip(a, b):
            rsp_err.append(y[0] - x[0])
            flag_mismatch += int(x[1] != y[1])
            data_mismatch += int(x[2] != y[2])
        rsp_err += [10**9] * abs(len(a) - len(b))
    last_r = max([c for c, _, _ in rtl["accepts"]] + [0])
    last_m = max([c for c, _, _ in mdl["accepts"]] + [0])
    return {"transactions": len(keys), "accept_exact": sum(1 for e in acc_err if e == 0),
            "response_exact": sum(1 for e in rsp_err if e == 0), "responses": n_rsp,
            "max_abs_accept_error": max((abs(e) for e in acc_err), default=0),
            "max_abs_response_error": max((abs(e) for e in rsp_err), default=0),
            "error_flag_mismatches": flag_mismatch, "read_data_mismatches": data_mismatch,
            "last_accept_cycle_rtl": last_r, "last_accept_cycle_model": last_m,
            "total_cycles_rel_error": abs(last_m - last_r) / last_r if last_r else 0.0,
            "equivalent": all(e == 0 for e in acc_err) and all(e == 0 for e in rsp_err) and flag_mismatch == 0
            and data_mismatch == 0}


XBAR_CASES = [  # (nm, ns, lat, arb, bp, kind, n)
    (4, 2, 1, 1, 0, "random", 300), (4, 2, 1, 0, 0, "random", 300), (4, 1, 1, 1, 0, "hot", 200),
    (4, 1, 1, 0, 0, "hot", 200), (3, 3, 2, 1, 20, "random", 300), (2, 2, 3, 1, 0, "bursty", 300),
    (4, 3, 1, 1, 30, "bursty", 300), (3, 2, 2, 0, 10, "random", 300),
]


def xbar_suite(work: Path, sim: str = "verilator", cases: list | None = None) -> dict:
    rows = []
    for k, (nm, ns, lat, arb, bp, kind, n) in enumerate(cases or XBAR_CASES):
        stim = xbar_stimulus(nm, ns, n, seed=100 + k, kind=kind)
        rtl = run_rtl_xbar(stim, ns=ns, lat=lat, arb=arb, bp=bp, seed=7 + k, work=work, sim=sim, tag=f"{sim}{k}")
        mdl = run_model_xbar(stim, ns=ns, lat=lat, arb=arb, bp=bp, seed=7 + k)
        cmp_ = compare_xbar(rtl, mdl)
        rows.append({"case": k, "masters": nm, "slaves": ns, "slave_latency": lat,
                     "arbitration": "fixed" if arb == 0 else "rr", "rsp_backpressure_pct": bp, "traffic": kind,
                     "requests_per_master": n, "simulator": sim, "model_invariant_errors": len(mdl["invariant_errors"]),
                     **cmp_})
    return {"category": "RTL_OBSERVED vs EVENT_SIMULATED", "rtl_files": XBAR_RTL, "harness": HARNESS.name,
            "rows": rows, "all_equivalent": all(r["equivalent"] for r in rows),
            "transactions_compared": sum(r["transactions"] for r in rows), "fitted_parameters": "none"}


# ---------------------------------------------------------------------------- 2. DMA vs recorded RTL benchmark
BENCH_MAP = {
    "simple_d32": (dict(engine="simple"), 32, False), "simple_d64": (dict(engine="simple"), 64, False),
    "simple_d128": (dict(engine="simple"), 128, False),
    "buf_f8_b8": (dict(engine="buffered", fifo_depth=8, burst=8), 32, False),
    "buf_f2_b2": (dict(engine="buffered", fifo_depth=2, burst=2), 32, False),
    "buf_f4_b4": (dict(engine="buffered", fifo_depth=4, burst=4), 32, False),
    "buf_f8_b1": (dict(engine="buffered", fifo_depth=8, burst=1), 32, False),
    "buf_f8_b4": (dict(engine="buffered", fifo_depth=8, burst=4), 32, False),
    "buf_f16_b16": (dict(engine="buffered", fifo_depth=16, burst=16), 32, False),
    "buf_f8_b8_d64": (dict(engine="buffered", fifo_depth=8, burst=8), 64, False),
    "buf_f8_dual": (dict(engine="buffered", fifo_depth=8, burst=8, dual_port=True), 32, True),
}
DMA_CALIBRATION_SET = ("simple_d32", "buf_f8_b8")


def parse_benchmark_md(path: Path) -> list[dict]:
    rows = []
    for line in path.read_text().splitlines():
        m = re.match(r"\|\s*(\S+)\s*\|\s*(ideal|contention)\s*\|\s*(\d+)\s*\|\s*([\d.]+)\s*\|\s*(\d+)\s*\|", line)
        if m:
            rows.append({"config": m.group(1), "scenario": m.group(2), "xbank_cycles": int(m.group(3)),
                         "same_bank_cycles": int(m.group(5))})
    return rows


def dma_model_cycles(name: str, same_bank: bool, overhead: int, nbytes: int = 4096) -> int:
    kw, dw, dual = BENCH_MAP[name]
    s = System("dmacal", fabric_hz=100e6, record_events=False)
    a = s.add_sram(SramConfig(name="a", base_addr=0x1000_0000, capacity_bytes=32 * 1024, banks=1, data_width=dw))
    b = s.add_sram(SramConfig(name="b", base_addr=0x1000_8000, capacity_bytes=32 * 1024, banks=1, data_width=dw))
    s.add_interconnect(FabricConfig(data_width_bits=dw))
    s.map_target(a)
    s.map_target(b)
    d = s.add_dma(DmaConfig(data_width_bits=dw, setup_cycles=overhead, completion_cycles=0, **kw))
    dst = 0x1000_4000 if same_bank else 0x1000_8000
    desc = d.submit(Descriptor.copy(0x1000_0000, dst, nbytes))
    s.run()
    if desc.failed:
        raise RuntimeError(f"DMA calibration run {name} failed: {desc.err_code}")
    return desc.t_done_cycle - desc.t_submit_cycle


def dma_calibration(bench_md: Path) -> dict:
    bench = [r for r in parse_benchmark_md(bench_md) if r["scenario"] == "ideal" and r["config"] in BENCH_MAP]
    cases = []
    for r in bench:
        cases.append((r["config"], False, r["xbank_cycles"]))
        if BENCH_MAP[r["config"]][2]:
            cases.append((r["config"], True, r["same_bank_cycles"]))
    base = {(n, sb): dma_model_cycles(n, sb, 0) for n, sb, _ in cases}
    calib = [(n, sb, obs) for n, sb, obs in cases if n in DMA_CALIBRATION_SET and not sb]
    best = min(range(0, 13), key=lambda ov: sum(abs(base[(n, sb)] + ov - obs) for n, sb, obs in calib))
    rows = []
    for n, sb, obs in cases:
        pred = base[(n, sb)] + best
        ae, re_ = _err(pred, obs)
        rows.append({"config": n, "same_bank": sb, "observed_cycles": obs, "predicted_cycles": pred,
                     "abs_error": ae, "rel_error": re_,
                     "set": "calibration" if (n in DMA_CALIBRATION_SET and not sb) else "holdout"})
    cal = [r for r in rows if r["set"] == "calibration"]
    hold = [r for r in rows if r["set"] == "holdout"]
    return {"source": "silicaflux-datafabric reports/datafabric/benchmark.md (MEASURED, Verilator; recorded in the "
                      "repository by an earlier project, not re-run in this session)",
            "category": "RTL_SIMULATED (recorded) vs EVENT_SIMULATED",
            "fitted_parameters": {"dma.setup_cycles + dma.completion_cycles": best},
            "fitted_on": sorted(DMA_CALIBRATION_SET), "rows": rows,
            "calibration_error": _summ(cal), "holdout_error": _summ(hold),
            "not_reproduced": "contention rows: the competing-master traffic generator of tb_dma.sv is not "
                              "replicated, so those rows are not used"}


# ---------------------------------------------------------------------------- 3. SilicaFlux-V engines (sfv_tile RTL)
# calibration subsets chosen by a fixed rule before fitting: TE -> the two smallest K without
# write-back; VE -> the LEN=100 command of two operation classes.  Everything else is holdout.
TE_CAL = {"K=1 WB=0", "K=16 WB=0"}
VE_CAL = {"vv LEN=100 WRES=0", "dot_vs LEN=100 WRES=0"}


def _ve_model(case: str, overhead: int) -> int:
    from .vector import VectorConfig, VectorKernel, vector_program
    cls, rest = case.split(" ", 1)
    n = int(re.search(r"LEN=(\d+)", rest).group(1))
    wres = bool(int(re.search(r"WRES=(\d)", rest).group(1)))
    op = {"vv": "vadd", "vs": "vscalar", "dot_vv": "dot", "dot_vs": "reduce"}[cls]
    if n == 0:
        return overhead
    s = System("ve", fabric_hz=100e6, record_events=False)
    t = s.add_sram(SramConfig(name="tspm", base_addr=0x2000_0000, capacity_bytes=16384, banks=4, n_ports=3,
                              arbitration="fixed"))
    ops, _ = vector_program(VectorConfig(overhead_cycles=overhead), VectorKernel(op=op, n=n, wres=wres),
                            local_base=t.base, word_bytes=4)
    m = s.add_master("ve", ops, links={"vmem": s.sram_link(t, 1)}, max_outstanding=4, issue_model="dae")
    s.run()
    return m.finish_cycle


def _te_model(case: str, overhead: int) -> int:
    from .tensor import GemmKernel, TensorConfig, tensor_program
    k = int(re.search(r"K=(\d+)", case).group(1))
    wb = bool(int(re.search(r"WB=(\d)", case).group(1)))
    s = System("te", fabric_hz=100e6, record_events=False)
    t = s.add_sram(SramConfig(name="tspm", base_addr=0x2000_0000, capacity_bytes=16384, banks=4, n_ports=3,
                              arbitration="fixed"))
    ops, _ = tensor_program(TensorConfig(overhead_cycles=overhead), GemmKernel(M=4, N=4, K=k, writeback=wb),
                            local_base=t.base, word_bytes=4)
    m = s.add_master("te", ops, links={"a": s.sram_link(t, 0)}, max_outstanding=4, issue_model="dae")
    s.run()
    return m.finish_cycle


def engine_calibration(work: Path) -> dict:
    from memorylab import rtl_integration as ri
    repo = find_repo()
    if repo is not None:
        os.environ.setdefault("SILICAFLUX_REPO", str(repo))
    if shutil.which("verilator") is None:
        raise RtlUnavailable("verilator not available")
    rtl = ri.run_tile_latency(work / "sfv_tile", ri.locate_sfv(build_dir=work / "sfv_tile"))
    obs = [r for r in rtl["rows"] if not r["err_flag"]]
    out: dict[str, Any] = {"category": "RTL_OBSERVED (this session, Verilator) vs EVENT_SIMULATED",
                           "rtl_command": rtl["command"], "rtl_root": rtl["rtl_root"],
                           "sfv_tile_sha256": rtl["tile_sha256"], "engines": {}}
    for eng, model, cal in (("tensor", _te_model, TE_CAL), ("vector", _ve_model, VE_CAL)):
        cases = [r for r in obs if r["engine"] == eng]
        cal_rows = [r for r in cases if r["case"] in cal]
        if len(cal_rows) != len(cal):
            raise RuntimeError(f"{eng}: calibration cases {sorted(cal)} not all present in the RTL results "
                               f"({sorted(r['case'] for r in cases)})")
        best = min(range(0, 6), key=lambda ov: sum(abs(model(r["case"], ov) - r["observed_cycles"]) for r in cal_rows))
        rows = []
        for r in cases:
            pred = model(r["case"], best)
            ae, re_ = _err(pred, r["observed_cycles"])
            rows.append({"case": r["case"], "observed_cycles": r["observed_cycles"], "predicted_cycles": pred,
                         "abs_error": ae, "rel_error": re_, "set": "calibration" if r["case"] in cal else "holdout"})
        out["engines"][eng] = {"fitted_parameters": {f"{eng}.overhead_cycles": best}, "fitted_on": sorted(cal),
                               "rows": rows,
                               "calibration_error": _summ([x for x in rows if x["set"] == "calibration"]),
                               "holdout_error": _summ([x for x in rows if x["set"] == "holdout"])}
    return out


# ---------------------------------------------------------------------------- 4. recorded RTL traces
def recorded_trace_metrics(df_root: Path) -> dict:
    from .trace_import import read_trace, trace_metrics
    out = {}
    for f in sorted((df_root / "reports/datafabric/traces").glob("*.csv")):
        if f.name.endswith(".memorylab.csv"):
            continue
        out[f.name] = trace_metrics(read_trace(f))
    return out


def dma_trace_crosscheck(df_root: Path) -> dict:
    """Compare the DMA beat period seen in recorded tb_dma RTL traces with the model's ideal period.

    The traces are *contention* scenarios, so only the uncontended part of the comparison is
    meaningful: the model's ideal period is a lower bound on the RTL's observed period."""
    from .trace_import import read_trace
    rows = []
    for f, name in (("tb_dma__simple_d32__contention.csv", "simple_d32"),
                    ("tb_dma__buf_f8_b8__contention.csv", "buf_f8_b8")):
        p = df_root / "reports/datafabric/traces" / f
        if not p.exists():
            continue
        df = read_trace(p)
        dma_master = 0                                  # tb/dma/tb_dma.sv:95 -- the DMA is master 0
        g = df[df["master"] == dma_master].dropna(subset=["accept_cycle"])
        span = g["accept_cycle"].max() - g["accept_cycle"].min() + 1
        period_rtl = 2 * span / len(g)                  # cycles per beat (a beat = one read + one write)
        ideal = dma_model_cycles(name, False, 0) / 1024
        rows.append({"trace": f, "dma_master": int(dma_master), "beats": int(len(g) // 2),
                     "rtl_cycles_per_beat_under_contention": float(period_rtl), "model_ideal_cycles_per_beat": ideal,
                     "model_ideal_is_lower_bound": bool(ideal <= period_rtl + 1e-9)})
    return {"rows": rows, "note": "contention traffic not replicated; used as a consistency (bound) check only"}


# ---------------------------------------------------------------------------- driver
def run_calibration(*, trace: str | None, out: Path, rtl: bool = True, workers: int | None = None) -> dict:
    out = Path(out)
    cal_dir = out / "calibration"
    work = ROOT / "build" / "bandwidthlab"
    cal_dir.mkdir(parents=True, exist_ok=True)
    res: dict[str, Any] = {"simulators": simulators()}
    if trace:
        from .trace_import import read_trace, trace_metrics
        res["imported_trace"] = {"path": trace, "metrics": trace_metrics(read_trace(trace))}
    try:
        df_root = locate_datafabric(work)
    except RtlUnavailable as e:
        df_root = None
        res["datafabric"] = f"unavailable: {e}"
    if df_root is not None:
        res["dma"] = dma_calibration(df_root / "reports/datafabric/benchmark.md")
        res["recorded_traces"] = recorded_trace_metrics(df_root)
        res["dma_trace_crosscheck"] = dma_trace_crosscheck(df_root)
    if rtl and df_root is not None:
        for sim in ("verilator", "iverilog"):
            if shutil.which(sim):
                try:
                    res[f"xbar_{sim}"] = xbar_suite(work, sim=sim, cases=XBAR_CASES if sim == "verilator"
                                                    else XBAR_CASES[:4])
                except Exception as e:                           # report, never hide
                    res[f"xbar_{sim}"] = {"error": f"{type(e).__name__}: {str(e)[:2000]}"}
            else:
                res[f"xbar_{sim}"] = {"error": f"{sim} not installed"}
        try:
            res["engines"] = engine_calibration(work)
        except Exception as e:
            res["engines"] = {"error": f"{type(e).__name__}: {str(e)[:2000]}"}
    elif not rtl:
        res["xbar"] = {"skipped": "--no-rtl"}
    summ: dict[str, Any] = {}
    for k in ("xbar_verilator", "xbar_iverilog"):
        if isinstance(res.get(k), dict) and "rows" in res[k]:
            summ[k] = {"all_equivalent": res[k]["all_equivalent"], "transactions": res[k]["transactions_compared"],
                       "cases": len(res[k]["rows"])}
        elif k in res:
            summ[k] = res[k]
    if "dma" in res:
        summ["dma"] = {"fitted": res["dma"]["fitted_parameters"], "holdout": res["dma"]["holdout_error"]}
    if isinstance(res.get("engines"), dict) and "engines" in res["engines"]:
        summ["engines"] = {e: {"fitted": v["fitted_parameters"], "holdout": v["holdout_error"]}
                           for e, v in res["engines"]["engines"].items()}
    res["summary"] = summ
    (cal_dir / "calibration.json").write_text(json.dumps(res, indent=1, default=str))
    if "dma" in res:
        fitted = {"dma": {"setup_cycles": res["dma"]["fitted_parameters"]["dma.setup_cycles + dma.completion_cycles"],
                          "completion_cycles": 0},
                  "provenance": {"dma.setup_cycles": ["RTL_SIMULATED", "fitted on " + ", ".join(DMA_CALIBRATION_SET) +
                                                      " of DataFabric benchmark.md"]}}
        (cal_dir / "calibrated_overrides.json").write_text(json.dumps(fitted, indent=1))
    return res
