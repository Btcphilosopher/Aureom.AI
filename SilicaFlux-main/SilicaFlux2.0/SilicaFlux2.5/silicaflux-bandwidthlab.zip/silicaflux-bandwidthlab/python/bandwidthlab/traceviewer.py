"""Interactive transaction timeline (Gantt) built from a run's recorded events / transactions.

Every bar comes from a simulated transaction's own timestamps (or an imported RTL trace);
nothing is synthesised.  The page lets the user pick one transaction id and follow it
through the memory system: its stage-by-stage timestamps, the components on its path, and
its dependency chain (transactions it waited for).  Long waits, bank conflicts, stalls of
the compute engines and queue saturation are highlighted.
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from .plotting import GRID, SERIES, SURFACE, SURFACE_2, TEXT, TEXT_2, TEXT_3, GOLD_CHROME

STAGES = [("generation", "t_created", "t_issued"), ("arbitration", "t_issued", "t_granted"),
          ("target wait", "t_granted", "t_service_start"), ("memory service", "t_service_start", "t_service_end"),
          ("response", "t_service_end", "t_completed")]


def _stage_rows(tx: pd.DataFrame, period: float) -> list[dict]:
    out = []
    for r in tx.itertuples(index=False):
        d = r._asdict()
        if pd.isna(d.get("t_completed")):
            continue
        st = {}
        prev = d["t_created"]
        for name, a, b in STAGES:
            va = d.get(a) if not pd.isna(d.get(a)) else prev
            vb = d.get(b) if not pd.isna(d.get(b)) else va
            st[name] = [va / period, vb / period]
            prev = vb
        deps = d.get("deps")
        if isinstance(deps, str):
            try:
                deps = json.loads(deps)
            except json.JSONDecodeError:
                deps = []
        out.append({"tid": int(d["tid"]), "master": str(d["master"]), "kind": str(d["kind"]), "dst": str(d["dst"]),
                    "addr": int(d["addr"]), "size": int(d["size"]), "status": str(d["status"]),
                    "deps": [int(x) for x in (deps or [])], "stages": st})
    return out


def build_trace_viewer(run_dir: Path, max_txns: int = 4000) -> Path:
    run = Path(run_dir) / "run_001"
    meta = json.loads((run / "run_meta.json").read_text())
    period = float(meta["period_fs"])
    tx = pd.read_csv(run / "transactions.csv")
    tx = tx.sort_values("t_created").head(max_txns)
    rows = _stage_rows(tx, period)
    ev = pd.read_csv(run / "events.csv")
    hi = max((r["stages"]["response"][1] for r in rows), default=0)
    stalls, computes, conflicts = [], [], []
    for e in ev.itertuples(index=False):
        if e.cycle > hi + 1:
            continue
        p = json.loads(e.payload) if isinstance(e.payload, str) and e.payload else {}
        if e.etype == "STALL_ENDED":
            stalls.append({"m": e.src, "a": p.get("start_cycle"), "b": p.get("end_cycle"), "why": p.get("reason")})
        elif e.etype == "COMPUTE_STARTED":
            computes.append({"m": e.src, "a": int(e.cycle), "b": int(e.cycle) + int(p.get("cycles", 0)),
                             "tag": p.get("tag", "")})
        elif e.etype == "BANK_CONFLICT":
            conflicts.append({"c": int(e.cycle), "tid": None if pd.isna(e.tid) else int(e.tid)})
    data = {"txns": rows, "stalls": stalls[:4000], "computes": computes[:6000], "conflicts": conflicts[:4000],
            "clock_domain": meta["clock_domain"], "clock_hz": meta["clock_hz"],
            "truncated": len(tx) >= max_txns or meta.get("event_log_truncated", False)}
    html = TEMPLATE.replace("__DATA__", json.dumps(data, separators=(",", ":"))) \
        .replace("__SERIES__", json.dumps(SERIES)).replace("__SURFACE__", SURFACE).replace("__SURFACE2__", SURFACE_2) \
        .replace("__GRID__", GRID).replace("__TEXT__", TEXT).replace("__TEXT2__", TEXT_2).replace("__TEXT3__", TEXT_3) \
        .replace("__GOLD__", GOLD_CHROME)
    out = Path(run_dir) / "trace_viewer.html"
    out.write_text(html)
    return out


TEMPLATE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>BandwidthLab Trace Viewer</title>
<script src="plotly.min.js"></script>
<style>
:root{--s:__SURFACE__;--s2:__SURFACE2__;--g:__GRID__;--t:__TEXT__;--t2:__TEXT2__;--t3:__TEXT3__;--gold:__GOLD__}
body{margin:0;background:var(--s);color:var(--t2);font:13px/1.45 Inter,system-ui,sans-serif}
header{padding:16px 20px;border-bottom:1px solid var(--g)}h1{margin:0;color:var(--t);font-size:18px}
h1 span{color:var(--gold)}.sub{color:var(--t3);font-size:12px;margin-top:4px}
.bar{display:flex;gap:12px;flex-wrap:wrap;align-items:center;padding:10px 20px;border-bottom:1px solid var(--g)}
input,select,button{background:var(--s2);color:var(--t);border:1px solid var(--g);border-radius:6px;padding:5px 8px;font:inherit}
button{cursor:pointer}#plot{height:62vh;min-height:420px}.wrap{display:grid;grid-template-columns:2fr 1fr;gap:0}
#detail{border-left:1px solid var(--g);padding:12px 16px;overflow:auto;max-height:62vh}
table{border-collapse:collapse;width:100%;font-family:'JetBrains Mono',ui-monospace,monospace;font-size:12px}
td,th{border-bottom:1px solid var(--g);padding:3px 6px;text-align:left}th{color:var(--t3);font-weight:500}
.k{color:var(--t3)}.v{color:var(--t)}@media(max-width:900px){.wrap{grid-template-columns:1fr}#detail{border-left:0}}
</style></head><body>
<header><h1>Silica<span>Flux</span> BandwidthLab — transaction timeline</h1>
<div class="sub" id="sub"></div></header>
<div class="bar"><label>transaction id <input id="tid" type="number" min="0" style="width:110px"></label>
<button id="go">follow</button><label>master <select id="fm"><option value="">all</option></select></label>
<label>highlight waits ≥ <input id="thr" type="number" value="4" min="1" style="width:60px"> cycles</label>
<label><input type="checkbox" id="onlylong"> only long waits</label></div>
<div class="wrap"><div id="plot"></div><div id="detail"><div class="k">Select a transaction (click a bar or type an id).</div></div></div>
<script>
const D=__DATA__, C=__SERIES__;
const STG=["generation","arbitration","target wait","memory service","response"];
const SC={"generation":C[4],"arbitration":C[3],"target wait":C[2],"memory service":C[1],"response":C[0]};
const sub=document.getElementById("sub");
sub.textContent=`${D.txns.length} transactions (clock domain '${D.clock_domain}', ${D.clock_hz/1e6} MHz)`+
 (D.truncated?" — window truncated to the first transactions":"")+" · all bars derived from simulator timestamps";
const masters=[...new Set(D.txns.map(t=>t.master))].sort();
const fm=document.getElementById("fm");masters.forEach(m=>{const o=document.createElement("option");o.value=m;o.textContent=m;fm.appendChild(o)});
const byId=new Map(D.txns.map(t=>[t.tid,t]));
function traces(){
 const thr=+document.getElementById("thr").value, only=document.getElementById("onlylong").checked, f=fm.value;
 const sel=D.txns.filter(t=>(!f||t.master===f)&&(!only||(t.stages["arbitration"][1]-t.stages["arbitration"][0]+t.stages["target wait"][1]-t.stages["target wait"][0])>=thr));
 const tr=[];
 for(const s of STG){const xs=[],bs=[],ys=[],cd=[];
  for(const t of sel){const [a,b]=t.stages[s];if(b<=a)continue;xs.push(b-a);bs.push(a);ys.push(t.master);cd.push([t.tid,t.kind,t.dst,b-a])}
  tr.push({type:"bar",orientation:"h",x:xs,base:bs,y:ys,name:s,marker:{color:SC[s],line:{width:0}},customdata:cd,
   hovertemplate:"tid %{customdata[0]} · %{customdata[1]} → %{customdata[2]}<br>"+s+": %{customdata[3]:.0f} cycles<extra></extra>"});}
 const lw=sel.filter(t=>(t.stages["arbitration"][1]-t.stages["arbitration"][0]+t.stages["target wait"][1]-t.stages["target wait"][0])>=thr);
 tr.push({type:"scatter",mode:"markers",x:lw.map(t=>t.stages["arbitration"][0]),y:lw.map(t=>t.master),name:`wait ≥ ${thr} cycles`,
  marker:{symbol:"triangle-right",size:9,color:"#f2f4f8",line:{width:2,color:"__SURFACE__"}},customdata:lw.map(t=>[t.tid]),hovertemplate:"long wait · tid %{customdata[0]}<extra></extra>"});
 const st=D.stalls.filter(s=>!f||s.m===f);
 tr.push({type:"bar",orientation:"h",x:st.map(s=>s.b-s.a),base:st.map(s=>s.a),y:st.map(s=>s.m+" · stall"),name:"stall",
  marker:{color:C[3],opacity:0.55},customdata:st.map(s=>[s.why]),hovertemplate:"%{customdata[0]} %{x} cycles<extra></extra>"});
 const cp=D.computes.filter(s=>!f||s.m===f);
 tr.push({type:"bar",orientation:"h",x:cp.map(s=>s.b-s.a),base:cp.map(s=>s.a),y:cp.map(s=>s.m+" · compute"),name:"compute",
  marker:{color:C[5]},customdata:cp.map(s=>[s.tag]),hovertemplate:"%{customdata[0]} %{x} cycles<extra></extra>"});
 return tr;}
const layout={paper_bgcolor:"__SURFACE__",plot_bgcolor:"__SURFACE__",font:{color:"__TEXT2__",family:"Inter,system-ui"},barmode:"overlay",
 margin:{l:120,r:10,t:10,b:40},xaxis:{title:"fabric cycle",gridcolor:"__GRID__",zeroline:false},yaxis:{gridcolor:"__GRID__",automargin:true},
 legend:{orientation:"h",y:-0.12},hoverlabel:{bgcolor:"__SURFACE2__"},bargap:0.25};
function draw(){Plotly.react("plot",traces(),layout,{responsive:true,displaylogo:false,toImageButtonOptions:{format:"png",scale:2}})}
draw();["thr","onlylong","fm"].forEach(i=>document.getElementById(i).addEventListener("change",draw));
function row(tb,k,v){const tr=document.createElement("tr");const a=document.createElement("td");a.className="k";a.textContent=k;
 const b=document.createElement("td");b.className="v";b.textContent=v;tr.append(a,b);tb.appendChild(tr)}
function follow(id){const t=byId.get(id);const d=document.getElementById("detail");d.textContent="";
 if(!t){d.textContent="transaction "+id+" not in this window";return}
 const h=document.createElement("div");h.className="v";h.textContent=`tid ${t.tid} · ${t.master} · ${t.kind} → ${t.dst} @0x${t.addr.toString(16)} (${t.size} B) · ${t.status}`;d.appendChild(h);
 const tb=document.createElement("table");d.appendChild(tb);
 for(const s of STG){const [a,b]=t.stages[s];row(tb,s,`${a.toFixed(0)} → ${b.toFixed(0)}  (${(b-a).toFixed(0)} cycles)`)}
 const chain=[];let cur=t,guard=0;while(cur&&cur.deps.length&&guard<20){const p=byId.get(cur.deps[0]);if(!p)break;chain.push(p.tid);cur=p;guard++}
 row(tb,"depends on",t.deps.length?t.deps.join(", "):"none");row(tb,"dependency chain",chain.length?chain.join(" ← "):"—");
 const cf=D.conflicts.filter(c=>c.tid===t.tid).length;row(tb,"bank-conflict cycles",String(cf));
 const tr=traces();const a0=t.stages["generation"][0],b0=t.stages["response"][1];
 Plotly.react("plot",tr,Object.assign({},layout,{shapes:[{type:"rect",xref:"x",yref:"paper",x0:a0,x1:Math.max(b0,a0+0.5),y0:0,y1:1,
  fillcolor:"rgba(212,175,55,0.12)",line:{color:"__GOLD__",width:1}}],xaxis:Object.assign({},layout.xaxis,{range:[a0-40,b0+40],autorange:false})}),{responsive:true,displaylogo:false})}
document.getElementById("go").onclick=()=>follow(+document.getElementById("tid").value);
document.getElementById("plot").on("plotly_click",ev=>{const p=ev.points[0];if(p&&p.customdata&&typeof p.customdata[0]==="number"){document.getElementById("tid").value=p.customdata[0];follow(p.customdata[0])}});
</script></body></html>
"""
