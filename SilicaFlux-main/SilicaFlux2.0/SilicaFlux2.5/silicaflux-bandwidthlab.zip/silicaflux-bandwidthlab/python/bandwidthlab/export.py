"""Write one simulated run to a directory (JSON + CSV), everything derived from the run."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd

from .latency import transaction_table


def write_run(built: Any, res: dict, metrics: dict, run_dir: Path, *, record: dict | None = None) -> Path:
    run_dir.mkdir(parents=True, exist_ok=True)
    s = built.system
    clk = s.clock
    (run_dir / "results.json").write_text(json.dumps({"provenance": record or {}, "metrics": metrics,
                                                      "results": res}, indent=1, default=str))
    txns = list(s.ledger.generated.values())
    pd.DataFrame([t.to_record() for t in txns]).to_csv(run_dir / "transactions.csv", index=False)
    pd.DataFrame(transaction_table([t for t in txns if t.t_completed is not None], clk.period_fs)).to_csv(
        run_dir / "latency_decomposition.csv", index=False)
    ev = [e.as_dict() for e in s.sched.log]
    for e in ev:
        e["payload"] = json.dumps(e["payload"], default=str) if e["payload"] is not None else ""
    pd.DataFrame(ev).to_csv(run_dir / "events.csv", index=False)
    cfg = built.cfg
    (run_dir / "config_resolved.json").write_text(cfg.model_dump_json(indent=1))
    # per-bank time series for heatmaps (from the event log: service starts per bank per bucket)
    meta = {"clock_domain": s.fabric_clock, "clock_hz": clk.freq_hz, "period_fs": clk.period_fs,
            "event_log_truncated": s.sched.log_truncated, "events_recorded": len(ev)}
    (run_dir / "run_meta.json").write_text(json.dumps(meta, indent=1))
    return run_dir
