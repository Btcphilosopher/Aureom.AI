"""MAC-array tensor-engine memory-traffic model (GEMM, output stationary).

Reference design: SilicaFlux-V ``sfv_tensor_engine`` -- 4x4 INT8/UINT8 output-stationary
array, 32-bit accumulators, K in 1..1024; A read column-wise (word k holds A[0..3][k]),
B read row-wise; A and B words fetched *sequentially* from single-port TSPM banks, so the
engine peaks at 16 MAC per 2 cycles; CYCLES = 3 + 2K (+4 with write-back).
The 2x2 / 8x8 / 16x16 arrays, INT16 / INT4 operands, extra operand ports and buffering
options are *exploration configurations*, not claims about existing RTL.

Per output tile (rows x cols), per k-block of ``k_block`` k-steps:
  * operand loads: for every k, the A column slice (rows elements) and the B row slice
    (cols elements) -- contiguous when A is stored k-major (transposed, the RTL layout),
    strided (one element per word) when A is row-major;
  * one compute op of k_block cycles (one k-step per cycle when operands are present),
    useful MACs = active rows x active cols x k;
  * ``input_buffers``: loads of block b may start only when block b - input_buffers has
    been consumed (1 = no overlap of loading and computing, 2 = double buffering);
  * fill/drain of a systolic array (rows + cols - 2 cycles per tile) when
    ``systolic_skew`` is set (the RTL broadcast array has none);
  * accumulator write-back: rows x cols x acc_bytes, ``wb_words_per_access`` words per
    store; with ``output_buffers`` = 1 the next tile waits for the write-back.
Operand sizes come from the precision only; no accuracy or throughput is inferred from a
datatype name.  FP16/BF16 are refused unless ``fp_supported`` is set explicitly.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .masters import ComputeOp, MemOp, Op
from .transaction import TxnKind
from .units import UnitMismatchError, ceil_div

PRECISION_BITS = {"int4": 4, "int8": 8, "uint8": 8, "int16": 16, "fp16": 16, "bf16": 16}


@dataclass
class TensorConfig:
    name: str = "te"
    rows: int = 4
    cols: int = 4
    precision: str = "int8"
    acc_bits: int = 32
    overhead_cycles: int = 3           # lock + prologue + drain (sfv_tensor_engine)
    systolic_skew: bool = False
    operand_ports: int = 1             # 1 = A and B fetched sequentially on one port (RTL)
    k_block: int = 1
    input_buffers: int = 2
    output_buffers: int = 1
    wb_words_per_access: int = 4
    fp_supported: bool = False
    max_outstanding: int = 4

    def __post_init__(self) -> None:
        if self.precision not in PRECISION_BITS:
            raise ValueError(f"unknown precision {self.precision!r}")
        if self.precision in ("fp16", "bf16") and not self.fp_supported:
            raise UnitMismatchError(f"{self.precision} needs a floating-point MAC model (fp_supported=True); "
                                    "the audited SilicaFlux tensor engines are integer-only")
        if self.rows < 1 or self.cols < 1 or self.k_block < 1 or self.input_buffers < 1 or self.output_buffers < 1:
            raise ValueError("rows, cols, k_block, buffers >= 1")
        if self.operand_ports not in (1, 2):
            raise ValueError("operand_ports must be 1 or 2")

    @property
    def macs(self) -> int:
        return self.rows * self.cols

    def operand_bytes(self, n: int) -> int:
        return ceil_div(n * PRECISION_BITS[self.precision], 8)


@dataclass
class GemmKernel:
    M: int = 16
    N: int = 16
    K: int = 64
    a_base: int = 0
    b_base: int = 0x1000
    c_base: int = 0x2000
    a_layout: str = "k_major"          # k_major (RTL: A transposed) | row_major
    writeback: bool = True

    def __post_init__(self) -> None:
        if min(self.M, self.N, self.K) < 1:
            raise ValueError("GEMM dimensions must be >= 1")
        if self.a_layout not in ("k_major", "row_major"):
            raise ValueError("a_layout k_major|row_major")


def tensor_program(cfg: TensorConfig, g: GemmKernel, *, local_base: int, word_bytes: int,
                   start_wait: tuple[str, ...] = (), done_token: str | None = None,
                   tile_tokens: dict[tuple[int, int], tuple[str, ...]] | None = None,
                   tile_done_tokens: dict[tuple[int, int], str] | None = None,
                   tiles_only: list[tuple[int, int]] | None = None) -> tuple[list[Op], dict]:
    R, C = cfg.rows, cfg.cols
    bits = PRECISION_BITS[cfg.precision]
    acc_b = cfg.acc_bits // 8
    la = "a"
    lb = "b" if cfg.operand_ports == 2 else "a"
    ops: list[Op] = []

    def mem(kind: TxnKind, words: list[int], link: str, deps: tuple[int, ...], tag: str,
            wait: tuple[str, ...] = ()) -> int:
        ops.append(MemOp(kind, local_base + words[0] * word_bytes, len(words) * word_bytes, deps=deps, words=words,
                         word_data=[0] * len(words) if kind == TxnKind.WRITE else None, tag=tag, link=link,
                         wait=wait))
        return len(ops) - 1

    def words_contig(byte_off: int, nbytes: int) -> list[int]:
        return list(range(byte_off // word_bytes, (byte_off + nbytes - 1) // word_bytes + 1))

    total_macs = 0
    tiles = 0
    prev_wb: list[int] = []
    wb_hist: list[list[int]] = []
    tile_ends: list[int] = []
    tile_list = tiles_only if tiles_only is not None else [(i0, j0) for i0 in range(0, g.M, R)
                                                             for j0 in range(0, g.N, C)]
    for i0, j0 in tile_list:
        if True:
            ra, ca = min(R, g.M - i0), min(C, g.N - j0)
            tiles += 1
            gate: tuple[int, ...] = ()
            if cfg.output_buffers == 1 and prev_wb:
                gate = tuple(prev_wb)
            elif cfg.output_buffers > 1 and len(wb_hist) >= cfg.output_buffers:
                gate = tuple(wb_hist[-cfg.output_buffers])
            tw = tuple(start_wait) + (tile_tokens.get((i0, j0), ()) if tile_tokens else ())
            ops.append(ComputeOp(cfg.overhead_cycles, deps=gate, wait=tw, tag="te_overhead"))
            head = len(ops) - 1
            computes: list[int] = []
            for kb0 in range(0, g.K, cfg.k_block):
                kb = min(cfg.k_block, g.K - kb0)
                b = len(computes)
                ld_gate = (computes[b - cfg.input_buffers],) if b - cfg.input_buffers >= 0 else (head,)
                lds = []
                for k in range(kb0, kb0 + kb):
                    if g.a_layout == "k_major":
                        aw = words_contig(g.a_base + cfg.operand_bytes(k * g.M + i0), cfg.operand_bytes(ra))
                    else:
                        aw = sorted({(g.a_base + cfg.operand_bytes((i0 + r) * g.K + k)) // word_bytes
                                     for r in range(ra)})
                    bw = words_contig(g.b_base + cfg.operand_bytes(k * g.N + j0), cfg.operand_bytes(ca))
                    lds.append(mem(TxnKind.READ, aw, la, ld_gate, "te_ld_a"))
                    lds.append(mem(TxnKind.READ, bw, lb, ld_gate, "te_ld_b"))
                deps = tuple(lds) + ((computes[-1],) if computes else ())
                macs = ra * ca * kb
                total_macs += macs
                ops.append(ComputeOp(kb, deps=deps, useful_ops=macs, capacity_ops=R * C * kb, tag="te_mac"))
                computes.append(len(ops) - 1)
            last = computes[-1]
            if cfg.systolic_skew:
                ops.append(ComputeOp(R + C - 2, deps=(last,), capacity_ops=R * C * (R + C - 2), tag="te_fill_drain"))
                last = len(ops) - 1
            wb: list[int] = []
            if g.writeback:
                row_bytes = ca * acc_b
                for r in range(ra):
                    off = g.c_base + ((i0 + r) * g.N + j0) * acc_b
                    ws = words_contig(off, row_bytes)
                    for s in range(0, len(ws), cfg.wb_words_per_access):
                        wb.append(mem(TxnKind.WRITE, ws[s:s + cfg.wb_words_per_access], la, (last,), "te_wb"))
            prev_wb = wb or [last]
            if tile_done_tokens and (i0, j0) in tile_done_tokens:
                ops.append(ComputeOp(0, deps=tuple(prev_wb), tag="te_tile_done", post=tile_done_tokens[(i0, j0)]))
                prev_wb = [len(ops) - 1]
            wb_hist.append(prev_wb)
            tile_ends.append(prev_wb[-1])
    ops.append(ComputeOp(0, deps=tuple(prev_wb), tag="te_done", post=done_token))
    a_bytes = cfg.operand_bytes(g.M * g.K)
    b_bytes = cfg.operand_bytes(g.K * g.N)
    info = {"tiles": tiles, "useful_macs": total_macs, "array": f"{R}x{C}", "precision": cfg.precision,
            "operand_bits": bits, "min_operand_bytes": a_bytes + b_bytes,
            "loaded_bytes": sum(o.size for o in ops if isinstance(o, MemOp) and o.kind == TxnKind.READ),
            "stored_bytes": sum(o.size for o in ops if isinstance(o, MemOp) and o.kind == TxnKind.WRITE),
            "operand_bytes_per_kstep": cfg.operand_bytes(R) + cfg.operand_bytes(C)}
    return ops, info


def rtl_cycles_formula(K: int, writeback: bool) -> int:
    """sfv_tensor_engine documented CYCLES = 3 + 2K (+4 WB) -- validation reference."""
    return 3 + 2 * K + (4 if writeback else 0)
