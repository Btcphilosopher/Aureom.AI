"""LEVEL 1 -- analytical ceilings.  Every value returned here is an ANALYTICAL_CEILING:
an upper bound under the stated assumptions, never a simulated or measured result.

Formulas (bytes/cycle unless stated; f = clock of the stated domain):

  link            B = (W/8) x transfers/cycle x links                   B_peak[B/s] = B x f
  SFB2 port       a port with 1 outstanding transaction and a target of read latency L
                  (response handshake L cycles after acceptance, a new request accepted in
                  the cycle of the previous response): independent requests 1/L txn/cycle,
                  address-dependent requests 1/(L+1) txn/cycle
  Little          sustained <= outstanding x bytes / latency_cycles
  SRAM            banks x ops/bank/cycle x word bytes, limited by requester ports
  DMA simple      W / (2 (L+1))                       (read -> wait -> write -> wait)
  DMA buffered    W x B / (2B + 2(L+1)) single port   (phases of B beats, idle phase switch)
                  min(W, ...) dual port, different slaves; W/2 same slave
  tensor          k-steps/cycle = min(1, port bytes/cycle / ((rows + cols) x operand bytes)) /
                  accesses per k-step; MAC/cycle = rows x cols x k-steps/cycle
  roofline        P = min(P_peak, I x B)          I = operations / byte moved
"""
from __future__ import annotations

from typing import Any

from .config import SystemConfig
from .tensor import PRECISION_BITS
from .units import GBps, GiBps, ceil_div


def _bw(bpc: float, f: float) -> dict:
    return {"bytes_per_cycle": bpc, "GBps": bpc * f / GBps, "GiBps": bpc * f / GiBps}


def link_ceiling(width_bits: int, f: float, transfers_per_cycle: float = 1.0, links: int = 1) -> dict:
    return {"category": "ANALYTICAL_CEILING", **_bw(width_bits / 8 * transfers_per_cycle * links, f)}


def sfb_port_txn_rate(latency: int, dependent: bool) -> float:
    if latency < 1:
        raise ValueError("latency >= 1 cycle")
    return 1.0 / (latency + 1) if dependent else 1.0 / latency


def little_bound(outstanding: int, nbytes: int, latency_cycles: float) -> float:
    return outstanding * nbytes / latency_cycles


def dma_ceiling(engine: str, width_bytes: int, *, burst: int = 8, dual_port: bool = False, same_target: bool = False,
                latency: int = 1) -> float:
    if engine == "simple":
        return width_bytes / (2 * (latency + 1))
    if dual_port:
        return width_bytes / (2 if same_target else 1) / max(1, latency) if latency > 1 else (
            width_bytes / 2 if same_target else width_bytes)
    return width_bytes * burst / (2 * burst + 2 * (latency + 1))


def tensor_ceiling(rows: int, cols: int, precision: str, port_bytes_per_cycle: int, accesses_per_kstep: int = 2
                   ) -> dict:
    eb_bits = PRECISION_BITS[precision]
    need = ceil_div((rows + cols) * eb_bits, 8)
    ks = min(1.0, port_bytes_per_cycle * accesses_per_kstep / need) / accesses_per_kstep \
        if accesses_per_kstep > 1 else min(1.0, port_bytes_per_cycle / need)
    return {"k_steps_per_cycle": ks, "macs_per_cycle": rows * cols * ks, "peak_macs_per_cycle": rows * cols,
            "operand_bytes_per_kstep": need, "category": "ANALYTICAL_CEILING"}


def roofline(peak_ops_per_s: float, intensity_ops_per_byte: float, bandwidth_Bps: float) -> dict:
    p = min(peak_ops_per_s, intensity_ops_per_byte * bandwidth_Bps)
    return {"attainable_ops_per_s": p, "bound": "compute" if p >= peak_ops_per_s else "bandwidth",
            "ridge_point_ops_per_byte": peak_ops_per_s / bandwidth_Bps if bandwidth_Bps else float("inf"),
            "category": "ANALYTICAL_CEILING"}


def system_ceilings(cfg: SystemConfig) -> dict[str, Any]:
    """Analytical ceilings of a configuration (fabric domain)."""
    f = cfg.fabric_hz
    fc = cfg.fabric
    W = fc.data_width_bits // 8
    out: dict[str, Any] = {"category": "ANALYTICAL_CEILING", "clock_domain": fc.clock, "clock_hz": f,
                           "assumptions": ["single-beat SFB2 transfers unless max_burst_beats > 1",
                                           "targets accept one request per cycle per port",
                                           "no protocol overhead cycles beyond those configured"]}
    fab_targets = 0
    mems = {}
    for m in cfg.memories:
        if m.kind != "sram":
            d = m.dram
            bb = d.get("data_width_bits", 16) // 8 * d.get("burst_length", 16)
            tbl = ceil_div(d.get("burst_length", 16), d.get("transfers_per_clock", 2))
            fd = cfg.clocks[d.get("clock", "dram")]
            mems[m.name] = {"kind": "dram", **_bw(d.get("channels", 1) * bb / tbl * fd / f, f),
                            "note": "data-bus ceiling at the controller clock, converted to fabric cycles"}
            fab_targets += 1
            continue
        ports = (m.banks if m.fabric_split else 1) if m.on_fabric else 0
        fab_targets += ports
        ops = 1 if m.port_type == "1RW" else 2
        word = max(m.data_width_bits, fc.data_width_bits if m.fabric_split else 0) // 8
        internal = m.banks * ops * word
        fabric_side = ports * min(W, word if m.fabric_split else W) / max(1, m.read_latency)
        mems[m.name] = {"kind": "sram", "internal": _bw(internal, f), "via_fabric": _bw(fabric_side, f),
                        "banks": m.banks, "fabric_ports": ports}
    n_masters = max(1, len(fc.master_order))
    out["link"] = link_ceiling(fc.data_width_bits, f)
    out["fabric_aggregate"] = {**link_ceiling(fc.data_width_bits, f, links=min(n_masters, max(1, fab_targets))),
                               "note": "crossbar: min(masters, target ports) concurrent single-beat transfers"
                               if fc.topology == "crossbar" else "shared bus: one transfer per cycle"}
    if fc.topology == "shared_bus":
        out["fabric_aggregate"] = link_ceiling(fc.data_width_bits, f)
    out["per_master_port"] = {"independent": _bw(W * sfb_port_txn_rate(1, False), f),
                              "dependent": _bw(W * sfb_port_txn_rate(1, True), f),
                              "note": "1 outstanding, 1-cycle target"}
    out["memories"] = mems
    if cfg.dma is not None:
        dm = cfg.dma
        dw = dm.data_width_bits // 8
        out["dma"] = {"engine": dm.engine,
                      "copy_useful": _bw(dma_ceiling(dm.engine, dw, burst=dm.burst, dual_port=dm.dual_port), f),
                      "formula": "W/(2(L+1))" if dm.engine == "simple" else
                      ("W" if dm.dual_port else "W*B/(2B+2(L+1))")}
    if cfg.tensor is not None:
        t = cfg.tensor
        tspm = cfg.memory(t.local_memory)
        port = tspm.banks * tspm.data_width_bits // 8
        acc = 2 if t.operand_ports == 1 else 1
        te = tensor_ceiling(t.rows, t.cols, t.precision, port, acc)
        te["ops_per_s_int"] = te["macs_per_cycle"] * 2 * f
        te["peak_ops_per_s_int"] = t.rows * t.cols * 2 * f
        te["convention"] = "1 MAC = 2 integer operations (memorylab.units.OpConvention)"
        out["tensor"] = te
    if cfg.vector is not None:
        v = cfg.vector
        tspm = cfg.memory(v.local_memory)
        row = tspm.banks * tspm.data_width_bits // 8
        beat = v.lanes * v.elem_bits // 8
        acc_per_beat = ceil_div(beat, row)
        out["vector"] = {"beats_per_cycle_vv": 1 / (3 * acc_per_beat), "lane_ops_per_cycle_vv": v.lanes /
                         (3 * acc_per_beat), "peak_lane_ops_per_cycle": v.lanes,
                         "note": "vector-vector op: 3 single-port bank accesses per beat (sfv_vec_engine P=3)"}
    return out
