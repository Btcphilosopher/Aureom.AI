"""End-to-end event-driven execution of workloads on a SilicaFlux profile (EVENT_SIMULATED).

System = memories (SramArray / Dram / Cache) + interconnect + optional DMA + compute
engines.  A workload is mapped to a task graph; the executor enforces:
  * a task's loads start only when a buffer slot is free and its load dependencies are done
  * its compute starts only when its loads AND compute dependencies are done and the engine is free
  * its stores start after its compute; the slot is released when the stores complete
  * nbuf = 1 -> sequential load/compute/store; nbuf = 2 -> double buffering (overlap)
Engine compute time comes from the engine latency models (compute.py), which reproduce
the SilicaFlux-V RTL formulas.  While an engine computes it owns a fraction of the
scratchpad bank cycles (fixed engine priority, sfv_tile.sv), slowing fabric traffic.
Data movement uses the DMA engine when present, otherwise a CPU load/store copy loop.

Fidelity: transaction-level, approximately timed.  The SRAM bank *controller* (sram.py)
is cycle-level and RTL-validated; the system models below are not cycle-accurate
against any SilicaFlux RTL.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
import math
from typing import Any, Callable

import numpy as np

from . import machine, workloads as wl
from .cache import Cache
from .compute import UnsupportedConfiguration
from .config import Profile
from .dma import Descriptor, Dma
from .dram import Dram
from .event_engine import (FS_PER_S, PRIO_COMPLETE, PRIO_ISSUE, ClockDomain, EventEngine, SimulationError, Trace,
                           Transaction)
from .interconnect import Interconnect
from .sram import SramArray
from .units import OpKind

BASES = {"sram": 0x0000_0000, "tspm": 0x2000_0000, "dram": 0x8000_0000}

# bottleneck classification thresholds (fractions); recorded in every result
THRESHOLDS = {"compute_busy": 0.85,  # also used for busy+transfer in SERIALISATION_BOUND
               "bandwidth_util": 0.75, "conflict_bank_time_fraction": 0.25,
              "latency_limit_fraction": 0.5}


# =========================================================================== system
class System:
    def __init__(self, p: Profile, *, trace: bool = False, max_events: int = 20_000_000,
                 wall_limit_s: float | None = 300.0, seed: int = 1) -> None:
        self.p = p
        self.seed = seed
        self.eng = EventEngine(max_events=max_events, wall_limit_s=wall_limit_s)
        self.clk = ClockDomain("sys", p.f)
        self.trace = Trace(enabled=trace)
        icfg = p.interconnect
        ic_clk = ClockDomain("ic", float(icfg.clock_hz.v)) if icfg.clock_hz is not None else self.clk
        self.ic = Interconnect(self.eng, ic_clk, width_bytes=icfg.width_bytes,
                               overhead_cycles=int(icfg.overhead_cycles.v), arbitration=icfg.arbitration,
                               max_outstanding_per_master=int(icfg.max_outstanding_per_master.v),
                               queue_depth=int(icfg.queue_depth.v), topology=icfg.topology, trace=self.trace)
        self.mem: dict[str, Any] = {}
        self.base: dict[str, int] = {}
        nxt_base = 0x4000_0000
        for m in p.memories:
            if not m.enabled:
                continue
            base = int(m.base_addr.v) if m.base_addr is not None else BASES.get(m.name, nxt_base)
            if m.name not in BASES and m.base_addr is None:
                nxt_base += 0x1000_0000
            self.base[m.name] = base
            mclk = ClockDomain(m.name, float(m.clock_hz.v)) if m.clock_hz is not None else self.clk
            if m.kind in ("sram", "scratchpad"):
                comp = SramArray(self.eng, mclk, name=m.name, capacity=m.capacity_bytes, banks=int(m.banks.v),
                                 width_bytes=m.width_bytes, read_latency=int(m.read_latency_cycles.v),
                                 write_latency=int(m.write_latency_cycles.v), ports=m.ports,
                                 interleave=m.interleave if m.interleave != "high" or (m.capacity_bytes // m.width_bytes) % int(m.banks.v) == 0 else "low",
                                 queue_depth=int(m.queue_depth.v), base_addr=base, trace=self.trace)
            elif m.kind == "dram":
                comp = Dram(self.eng, name=m.name, channels=int(m.channels.v), bus_width_bytes=int(m.bus_width_bits.v) // 8,
                            data_rate_mtps=float(m.data_rate_mtps.v), read_latency_ns=float(m.read_latency_ns.v),
                            write_latency_ns=float(m.write_latency_ns.v), burst_bytes=int(m.burst_bytes.v),
                            queue_depth=max(1, int(m.queue_depth.v) or 16), base_addr=base,
                            model_rows=m.model_rows, banks=int(m.dram_banks.v), row_bytes=int(m.row_bytes.v),
                            row_hit_ns=float(m.row_hit_ns.v), row_miss_ns=float(m.row_miss_ns.v), trace=self.trace)
            else:
                continue
            self.mem[m.name] = comp
            self.ic.connect(m.name, comp, **({"port_bytes_per_cycle": icfg.width_bytes} if m.kind != "dram" else {}))
        for m in p.memories:                       # caches in front of their downstream memory
            if m.kind == "cache" and m.enabled:
                if m.downstream not in self.mem:
                    raise UnsupportedConfiguration(f"cache {m.name}: downstream {m.downstream!r} unknown")
                c = Cache(self.eng, self.clk, name=m.name, capacity=m.capacity_bytes, line_bytes=int(m.line_bytes.v),
                          ways=int(m.ways.v), downstream=self.mem[m.downstream], downstream_name=m.downstream,
                          replacement=m.replacement, write_policy=m.write_policy, mshrs=int(m.mshrs.v),
                          hit_latency=int(m.hit_latency_cycles.v), seed=seed,
                          issue=lambda t, tgt, cb: self.ic.request("cache_fill", t, tgt, cb), trace=self.trace)
                self.mem[m.name] = c
                self.base[m.name] = self.base[m.downstream]
        self.dma: Dma | None = None
        if p.dma is not None and p.dma.enabled:
            d = p.dma
            self.dma = Dma(self.eng, self.clk, self.ic, channels=int(d.channels.v), burst_bytes=int(d.burst_bytes.v),
                           max_outstanding=int(d.max_outstanding.v), queue_depth=int(d.queue_depth.v),
                           setup_cycles=int(d.setup_cycles.v), issue_interval_cycles=int(d.issue_interval_cycles.v),
                           max_write_outstanding=int(d.max_write_outstanding.v) if d.max_write_outstanding else None,
                           trace=self.trace)
        self.engines = machine.engines(p)
        self.cpu_copy_overhead = self._cpu_loop_overhead()
        self.engine_blocks_fabric = True     # sfv_tile.sv: the engine holding the TSPM lock has bank priority

    def _cpu_loop_overhead(self, unroll: int = 4) -> int:
        """Cycles of non-memory instructions per copied word, rounded up to whole cycles per 4 words."""
        cpi = {k: float(v.v) for k, v in self.p.cpu.cpi.items()}
        return int(math.ceil(2 * cpi["alu"] + cpi.get("branch_taken", 3)))   # per unrolled iteration of 4 words

    def tspm_name(self) -> str:
        for m in self.p.memories:
            if m.kind == "scratchpad" and m.enabled:
                return m.name
        raise UnsupportedConfiguration("profile has no scratchpad memory for accelerator operands")

    def home_name(self) -> str:
        for m in self.p.memories:
            if m.kind == "sram" and m.enabled:
                return m.name
        raise UnsupportedConfiguration("profile has no SRAM")

    def far_name(self) -> str:
        for m in self.p.memories:
            if m.kind == "dram" and m.enabled:
                return m.name
        return self.home_name()


class Layout:
    """Bump allocator per memory; raises when a workload's data does not fit (no silent wrap)."""

    def __init__(self, sysm: "System") -> None:
        self.s = sysm
        self.top: dict[str, int] = {}

    def alloc(self, mem: str, nbytes: int, align: int = 64) -> int:
        cap = self.s.p.memory(mem).capacity_bytes
        off = -(-self.top.get(mem, 0) // align) * align
        if cap is not None and off + nbytes > cap:
            raise UnsupportedConfiguration(
                f"workload data ({off + nbytes} B) exceeds {mem} capacity ({cap} B)"
                + ("" if any(m.kind == "dram" and m.enabled for m in self.s.p.memories)
                   else "; the profile has no external memory"))
        self.top[mem] = off + nbytes
        return off


# =========================================================================== data movers
class CpuCopier:
    """Blocking load/store copy loop on the control core (one transaction outstanding)."""

    def __init__(self, sysm: System) -> None:
        self.s = sysm
        self.busy = False
        self.q: deque = deque()
        self.busy_fs = 0
        self.bytes = 0
        self._t0 = 0

    def move(self, src: str, src_addr: int, dst: str, dst_addr: int, nbytes: int, cb: Callable[[], None]) -> None:
        self.q.append((src, src_addr, dst, dst_addr, nbytes, cb))
        if not self.busy:
            self._next()

    def _next(self) -> None:
        if not self.q:
            self.busy = False
            return
        self.busy = True
        self._t0 = self.s.eng.now
        src, sa, dst, da, n, cb = self.q.popleft()
        wb = int(self.s.p.cpu.load_bytes.v)
        words = math.ceil(n / wb)
        state = {"i": 0}
        eng, ic, clk = self.s.eng, self.s.ic, self.s.clk

        def step() -> None:
            i = state["i"]
            if i == words:
                self.busy_fs += eng.now - self._t0
                self.bytes += n
                cb()
                self._next()
                return
            ld = Transaction(eng.new_id(), "cpu", "R", sa + i * wb, wb, eng.now)

            def stored(_t: Transaction) -> None:
                state["i"] += 1
                extra = self.s.cpu_copy_overhead if state["i"] % 4 == 0 else 0
                eng.schedule(clk.cycles(extra), step, PRIO_ISSUE, "cpu.copy")

            def loaded(_t: Transaction) -> None:
                st = Transaction(eng.new_id(), "cpu", "W", da + i * wb, wb, eng.now)
                self._req(st, dst, stored)
            self._req(ld, src, loaded)
        step()

    def _req(self, t: Transaction, tgt: str, cb: Callable) -> None:
        if not self.s.ic.request("cpu.d", t, tgt, cb):
            self.s.eng.schedule(self.s.clk.period_fs, lambda: self._req(t, tgt, cb), PRIO_ISSUE, "cpu.retry")


class Mover:
    def __init__(self, sysm: System) -> None:
        self.s = sysm
        self.cpu = None if sysm.dma else CpuCopier(sysm)
        self.kind = "dma" if sysm.dma else "cpu_copy"
        self._ch = 0
        self.backlog: deque = deque()

    def move(self, src: str, src_addr: int, dst: str, dst_addr: int, nbytes: int, cb: Callable[[], None],
             label: str = "") -> None:
        if nbytes <= 0:
            self.s.eng.schedule(0, cb, PRIO_COMPLETE, "move0")
            return
        if self.cpu:
            self.cpu.move(src, src_addr, dst, dst_addr, nbytes, cb)
            return
        dma = self.s.dma
        ch = self._ch
        self._ch = (self._ch + 1) % dma.channels
        d = Descriptor(src, src_addr, dst, dst_addr, nbytes, on_done=lambda d: cb(), label=label)
        if not dma.submit(d, ch):
            self.backlog.append((d, ch))
            self._retry()

    def _retry(self) -> None:
        def again() -> None:
            while self.backlog:
                d, ch = self.backlog[0]
                if not self.s.dma.submit(d, ch):
                    self.s.eng.schedule(self.s.clk.period_fs, again, PRIO_ISSUE, "dma.backlog")
                    return
                self.backlog.popleft()
        self.s.eng.schedule(self.s.clk.period_fs, again, PRIO_ISSUE, "dma.backlog")


# =========================================================================== tasks
@dataclass
class Move:
    src: str
    src_off: int
    dst: str
    dst_off: int
    nbytes: int


@dataclass
class Task:
    name: str
    engine: str
    compute_cycles: int
    loads: list[Move] = field(default_factory=list)
    stores: list[Move] = field(default_factory=list)
    deps: list[str] = field(default_factory=list)          # compute after these tasks' compute
    useful_work: float = 0.0
    engine_port_fraction: float = 0.0
    state: str = "pending"
    t_load_start: int | None = None
    t_loaded: int | None = None
    t_compute_start: int | None = None
    t_compute_end: int | None = None
    t_done: int | None = None
    loads_left: int = 0
    stores_left: int = 0


class Executor:
    def __init__(self, sysm: System, mover: Mover, tasks: list[Task], nbuf: int, name: str = "exec") -> None:
        if nbuf < 1:
            raise ValueError("nbuf >= 1")
        names = [t.name for t in tasks]
        if len(set(names)) != len(names):
            raise ValueError("task names must be unique")
        self.s, self.mv, self.tasks, self.nbuf, self.name = sysm, mover, tasks, nbuf, name
        self.by = {t.name: t for t in tasks}
        for t in tasks:
            for d in t.deps:
                if d not in self.by:
                    raise ValueError(f"task {t.name}: unknown dependency {d}")
        self.free = nbuf
        self.next_load = 0
        self.engine_free: dict[str, int] = {}
        self.engine_busy: dict[str, list[tuple[int, int, str]]] = {}
        self.done = 0
        sysm.eng.register(self)

    def outstanding(self) -> int:
        return len(self.tasks) - self.done

    def start(self) -> None:
        self._try_load()

    def _addr(self, mem: str, off: int) -> int:
        return self.s.base[mem] + off

    def _try_load(self) -> None:
        while self.next_load < len(self.tasks) and self.free > 0:
            t = self.tasks[self.next_load]
            self.next_load += 1
            self.free -= 1
            t.state = "loading"
            t.t_load_start = self.s.eng.now
            t.loads_left = len(t.loads)
            if not t.loads:
                self._loaded(t)
            for mv in t.loads:
                self.mv.move(mv.src, self._addr(mv.src, mv.src_off), mv.dst, self._addr(mv.dst, mv.dst_off),
                             mv.nbytes, lambda t=t: self._load_done(t), label=f"{t.name}.ld")

    def _load_done(self, t: Task) -> None:
        t.loads_left -= 1
        if t.loads_left == 0:
            self._loaded(t)

    def _loaded(self, t: Task) -> None:
        t.state = "loaded"
        t.t_loaded = self.s.eng.now
        self._try_compute()

    def _try_compute(self) -> None:
        for t in self.tasks:
            if t.state != "loaded":
                continue
            if any(self.by[d].t_compute_end is None for d in t.deps):
                continue
            # in-order per engine: no earlier task of this engine may still wait
            earlier = [x for x in self.tasks[: self.tasks.index(t)] if x.engine == t.engine and x.t_compute_start is None]
            if earlier:
                continue
            now = self.s.eng.now
            if self.engine_free.get(t.engine, 0) > now:
                continue
            start = self.s.clk.next_edge(now)
            end = start + self.s.clk.cycles(t.compute_cycles)
            self.engine_free[t.engine] = end
            self.engine_busy.setdefault(t.engine, []).append((start, end, t.name))
            t.state = "computing"
            t.t_compute_start = start
            if t.engine_port_fraction > 0 and t.engine in ("tensor", "vector"):
                try:
                    sp = self.s.mem[self.s.tspm_name()]
                    sp.add_engine_window(self.s.clk.edge_index_at_or_after(start),
                                         self.s.clk.edge_index_at_or_after(end), t.engine_port_fraction)
                except UnsupportedConfiguration:
                    pass
            self.s.eng.schedule_at(end, lambda t=t: self._computed(t), PRIO_COMPLETE, f"{t.name}.compute")

    def _computed(self, t: Task) -> None:
        t.t_compute_end = self.s.eng.now
        t.state = "storing"
        t.stores_left = len(t.stores)
        if not t.stores:
            self._stored(t)
        for mv in t.stores:
            self.mv.move(mv.src, self._addr(mv.src, mv.src_off), mv.dst, self._addr(mv.dst, mv.dst_off),
                         mv.nbytes, lambda t=t: self._store_done(t), label=f"{t.name}.st")
        self._try_compute()

    def _store_done(self, t: Task) -> None:
        t.stores_left -= 1
        if t.stores_left == 0:
            self._stored(t)

    def _stored(self, t: Task) -> None:
        t.state = "done"
        t.t_done = self.s.eng.now
        self.done += 1
        self.free += 1
        self._try_load()
        self._try_compute()


# =========================================================================== workload mappings
def _fraction(sysm: System, engine: str) -> float:
    if not sysm.engine_blocks_fabric:       # hypothetical ping-pong scratchpad: engine and fabric on disjoint halves
        return 0.0
    try:
        sp = sysm.p.memory(sysm.tspm_name())
    except UnsupportedConfiguration:
        return 0.0
    cap = int(sp.banks.v) * sp.width_bytes
    if engine == "tensor":
        return min(1.0, float(sysm.p.tensor.operand_bytes_per_cycle.v) / cap)
    if engine == "vector":
        return min(1.0, sysm.engines["vector"].ldst_bytes_per_cycle / cap)
    return 0.0


def map_gemm(sysm: System, w: wl.Workload) -> tuple[list[Task], int, dict]:
    te = sysm.engines.get("tensor")
    if te is None:
        raise UnsupportedConfiguration("no tensor engine")
    m, n, k = machine.tensor_shape(w)
    conv_note = None
    if w.family == "conv2d":
        # conservative DES mapping: implicit GEMM over an im2col-materialised input (moves R*S/stride^2
        # more input bytes than the analytical line-buffer model, so it stays below that ceiling)
        w = wl.gemm(m, n, k, "double_buffered", precision=w.precision, out_bytes=w.out_bytes)
        conv_note = "im2col-materialised implicit GEMM (conservative)"
    tsp = sysm.tspm_name()
    home = sysm.far_name()
    cap = sysm.p.memory(tsp).capacity_bytes
    b = w.precision.bytes
    frac = _fraction(sysm, "tensor")
    tasks: list[Task] = []
    lay = Layout(sysm)
    a0 = lay.alloc(home, m * k * b)
    b0 = lay.alloc(home, k * n * b)
    c0 = lay.alloc(home, m * n * 4)
    if w.strategy == "scratchpad_resident":
        w.traffic(cap)                                     # raises InfeasibleStrategy if it does not fit
        g = te.gemm(m, n, k, w.precision)
        tasks.append(Task("resident", "tensor", int(math.ceil(g["cycles"])), useful_work=m * n * k,
                          loads=[Move(home, a0, tsp, 0, m * k * b), Move(home, b0, tsp, m * k * b, k * n * b)],
                          stores=[Move(tsp, 0, home, c0, m * n * w.out_bytes)], engine_port_fraction=frac))
        return tasks, 1, {"tm": m, "tn": n, "tk": k, "split_k": False}
    if w.strategy == "naive":
        tm, tn, tk, split, nbuf = te.rows, te.cols, k, False, 1
    else:
        _, info = w.traffic_detail(cap)
        tm, tn, tk, split, nbuf = info["tm"], info["tn"], info["tk"], info["split_k"], info["buffers"]
    vec = sysm.engines.get("vector")
    tiles_i, tiles_j, chunks = math.ceil(m / tm), math.ceil(n / tn), math.ceil(k / tk)
    half = cap // max(1, nbuf)
    for i in range(tiles_i):
        for j in range(tiles_j):
            prev = None
            for c in range(chunks):
                kk = min(tk, k - c * tk)
                last = c == chunks - 1
                rows_i = min(tm, m - i * tm)
                cols_j = min(tn, n - j * tn)
                # remainder tiles only contain the array sub-tiles they actually cover
                sub_ij = math.ceil(rows_i / te.rows) * math.ceil(cols_j / te.cols)
                cyc = sub_ij * sum(te.tile(min(kk - q, te.max_k), w.precision, writeback=(split or last))["cycles"]
                                   for q in range(0, kk, te.max_k))
                if split and c > 0 and vec is not None:          # merge partial sums in the TSPM on the VE
                    cyc += vec.command_cycles("vv", rows_i * cols_j)
                slot = len(tasks) % nbuf
                off = slot * half
                name = f"t{i}_{j}_{c}"
                loads = [Move(home, a0 + (i * tm * k + c * tk) * b, tsp, off, rows_i * kk * b),
                         Move(home, b0 + (c * tk * n + j * tn) * b, tsp, off + tm * kk * b, kk * cols_j * b)]
                if split and c > 0:
                    loads.append(Move(home, c0 + (i * tm * n + j * tn) * 4, tsp, off + (tm + tn) * kk * b,
                                      rows_i * cols_j * 4))
                stores = [Move(tsp, off + (tm + tn) * kk * b, home, c0 + (i * tm * n + j * tn) * 4,
                               rows_i * cols_j * w.out_bytes)] if (last or split) else []
                tasks.append(Task(name, "tensor", int(math.ceil(cyc)), loads=loads, stores=stores,
                                  deps=[prev] if prev else [], useful_work=min(tm, m - i * tm) * min(tn, n - j * tn) * kk,
                                  engine_port_fraction=frac))
                prev = name
    return tasks, nbuf, {"tm": tm, "tn": tn, "tk": tk, "split_k": split, "nbuf": nbuf, "note": conv_note}


def map_vector(sysm: System, w: wl.Workload, nbuf: int) -> tuple[list[Task], int, dict]:
    ve = sysm.engines.get("vector")
    if ve is None:
        raise UnsupportedConfiguration("no vector engine")
    if w.precision not in ve.precisions:
        raise UnsupportedConfiguration(f"vector engine does not support {w.precision.value}")
    cmds = machine.vector_commands(w)
    tsp, home = sysm.tspm_name(), sysm.far_name()
    cap = sysm.p.memory(tsp).capacity_bytes
    eb = ve.elem_bytes
    fam = w.family
    lay = Layout(sysm)
    if fam in ("gemv",):
        rows, n = w.dims["m"], w.dims["n"]
        per_row = n * eb
        a0, x0, y0 = lay.alloc(home, rows * per_row), lay.alloc(home, per_row), lay.alloc(home, rows * 4)
        rows_per_chunk = max(1, (cap // nbuf - per_row) // per_row)
        tasks = []
        x_loaded = False
        for r0 in range(0, rows, rows_per_chunk):
            nr = min(rows_per_chunk, rows - r0)
            cyc = sum(ve.command_cycles("dot_vv", n, wres=True) for _ in range(nr))
            loads = [Move(home, a0 + r0 * per_row, tsp, 0, nr * per_row)]
            if not x_loaded:
                loads.append(Move(home, x0, tsp, cap - per_row, per_row))
                x_loaded = True
            tasks.append(Task(f"rows{r0}", "vector", int(cyc), loads=loads,
                              stores=[Move(tsp, 0, home, y0 + r0 * 4, nr * 4)], useful_work=2 * nr * n,
                              engine_port_fraction=_fraction(sysm, "vector")))
        return tasks, 1, {"rows_per_chunk": rows_per_chunk}
    n_total = cmds[0][1]
    streams_in = {"vector_add": 2, "axpy": 2, "dot": 2, "fir": 1, "stencil2d": 1}.get(fam, 2)
    streams_out = {"dot": 0}.get(fam, 1)
    per_elem = (streams_in + streams_out + (1 if fam in ("axpy", "fir", "stencil2d") else 0)) * eb
    chunk = max(ve.lanes, (cap // nbuf // per_elem) // ve.lanes * ve.lanes)
    ins = [lay.alloc(home, n_total * eb) for _ in range(streams_in)]
    out0 = lay.alloc(home, n_total * eb if streams_out else 4)
    tasks = []
    ops_per_elem = w.arithmetic_ops / n_total
    for c0 in range(0, n_total, chunk):
        L = min(chunk, n_total - c0)
        cyc = sum(ve.command_cycles(op, L, wres=wres and (c0 + L == n_total)) for op, _, wres in cmds)
        slot = len(tasks) % nbuf
        off = slot * (cap // nbuf)
        loads = [Move(home, ins[s_] + c0 * eb, tsp, off + s_ * L * eb, L * eb) for s_ in range(streams_in)]
        stores = [Move(tsp, off, home, out0 + c0 * eb, L * eb)] if streams_out else []
        tasks.append(Task(f"chunk{c0}", "vector", int(math.ceil(cyc)), loads=loads, stores=stores,
                          useful_work=ops_per_elem * L, engine_port_fraction=_fraction(sysm, "vector")))
    if streams_out == 0:
        tasks[-1].stores = [Move(tsp, 0, home, out0, 4)]
    return tasks, nbuf, {"chunk_elements": chunk}


class CpuStream:
    """In-order control core issuing blocking loads (MLP = max_outstanding_loads)."""

    def __init__(self, sysm: System, addrs: list[int], target: str, ops_per_access: int, alu_cycles: int) -> None:
        self.s, self.addrs, self.target = sysm, addrs, target
        self.alu = alu_cycles
        self.mlp = int(sysm.p.cpu.max_outstanding_loads.v)
        self.i = 0
        self.inflight = 0
        self.done_n = 0
        self.t_end: int | None = None
        self.busy_compute_fs = 0
        self.limit_events = 0
        self.core_free = 0
        sysm.eng.register(self)
        self.name = "cpu_stream"

    def outstanding(self) -> int:
        return len(self.addrs) - self.done_n

    def start(self) -> None:
        self._issue()

    def _issue(self) -> None:
        while self.i < len(self.addrs) and self.inflight < self.mlp:
            a = self.addrs[self.i]
            self.i += 1
            self.inflight += 1
            t = Transaction(self.s.eng.new_id(), "cpu", "R", a, int(self.s.p.cpu.load_bytes.v), self.s.eng.now)
            self._req(t)
        if self.i < len(self.addrs) and self.inflight >= self.mlp:
            self.limit_events += 1

    def _req(self, t: Transaction) -> None:
        if not self.s.ic.request("cpu.d", t, self.target, self._done):
            self.s.eng.schedule(self.s.clk.period_fs, lambda: self._req(t), PRIO_ISSUE, "cpu.retry")

    def _done(self, t: Transaction) -> None:
        # in-order single-issue core: the ALU work of each loaded word is serialised on the core;
        # only the loads themselves overlap (up to max_outstanding_loads)
        self.inflight -= 1
        self.done_n += 1
        dt = self.s.clk.cycles(self.alu)
        start = max(self.s.eng.now, self.core_free)
        self.core_free = start + dt
        self.busy_compute_fs += dt
        if self.done_n == len(self.addrs):
            self.s.eng.schedule_at(self.core_free, lambda: setattr(self, "t_end", self.s.eng.now), PRIO_COMPLETE,
                                   "cpu.end")
            return
        self.s.eng.schedule_at(self.core_free, self._issue, PRIO_ISSUE, "cpu.alu")


# =========================================================================== run
def _span(sysm: System) -> int:
    return max(1, sysm.eng.now)


def simulate(p: Profile, w: wl.Workload, engine: str | None = None, *, nbuf: int | None = None,
             trace: bool = False, seed: int = 1, max_events: int = 20_000_000,
             wall_limit_s: float | None = 300.0, engine_blocks_fabric: bool = True) -> dict:
    """``engine_blocks_fabric=False`` models a (hypothetical) ping-pong scratchpad in which the
    engine and the fabric/DMA use disjoint halves, so DMA traffic is not stalled by engine priority."""
    eng_name = engine or w.engine
    sysm = System(p, trace=trace, max_events=max_events, wall_limit_s=wall_limit_s, seed=seed)
    sysm.engine_blocks_fabric = engine_blocks_fabric
    mover = Mover(sysm)
    rng = np.random.Generator(np.random.PCG64(seed))
    info: dict[str, Any] = {}
    executors: list[Executor] = []
    cpu_streams: list[CpuStream] = []
    db = p.dma is not None and p.dma.enabled and p.dma.double_buffering
    work = 0.0
    kind = OpKind.MAC if (w.macs and not w.other_ops and eng_name in ("tensor", "cpu")) else w.precision.arithmetic_kind
    if eng_name == "tensor":
        tasks, nb, info = map_gemm(sysm, w)
        executors.append(Executor(sysm, mover, tasks, nbuf or nb))
        work = w.macs
    elif eng_name == "vector":
        tasks, nb, info = map_vector(sysm, w, nbuf or (2 if db else 1))
        executors.append(Executor(sysm, mover, tasks, nb))
        work = w.arithmetic_ops
    elif eng_name == "cpu":
        home = sysm.home_name() if w.family == "cpu_sequential" else sysm.far_name()
        wb = int(p.cpu.load_bytes.v)
        n = w.dims["n"]
        if w.family == "cpu_sequential":
            addrs = [sysm.base[home] + wb * i for i in range(n)]
            alu = 1 + 1                      # add + (amortised) loop overhead
        elif w.family == "cpu_random":
            region = min(w.dims["region"], sysm.mem[home].capacity if hasattr(sysm.mem[home], "capacity") else w.dims["region"])
            addrs = [sysm.base[home] + int(x) * wb for x in rng.integers(0, region // wb, n)]
            alu = 3
        else:
            raise UnsupportedConfiguration(f"no event-simulated CPU mapping for {w.family}")
        cpu_streams.append(CpuStream(sysm, addrs, home, 1, alu))
        work = w.arithmetic_ops
    elif eng_name == "dma":
        if sysm.dma is None and mover.cpu is None:
            raise UnsupportedConfiguration("no data mover")
        nbytes = w.dims["bytes"]
        src, dst = sysm.far_name(), sysm.home_name()
        if src == dst:
            if nbytes * 2 > p.memory(src).capacity_bytes:
                raise UnsupportedConfiguration(f"dma_copy of {nbytes} B does not fit twice in {src}")
        tasks = [Task("copy", "dma", 0, loads=[Move(src, 0, dst, p.memory(dst).capacity_bytes // 2 if src == dst else 0, nbytes)])]
        executors.append(Executor(sysm, mover, tasks, 1))
        work = 0.0
    else:
        raise UnsupportedConfiguration(f"unknown engine {eng_name}")
    for e in executors:
        e.start()
    for c in cpu_streams:
        c.start()
    rs = sysm.eng.run()
    return collect(sysm, w, eng_name, kind, work, executors, cpu_streams, mover, info, rs)


def simulate_mixed(p: Profile, parts: list[tuple[wl.Workload, str]], *, seed: int = 1, trace: bool = False) -> dict:
    """Independent concurrent workloads on different engines sharing memory and interconnect."""
    sysm = System(p, trace=trace, seed=seed)
    mover = Mover(sysm)
    executors, streams, per = [], [], []
    db = p.dma is not None and p.dma.enabled and p.dma.double_buffering
    for w, eng in parts:
        if eng == "tensor":
            tasks, nb, _ = map_gemm(sysm, w)
            for t in tasks:
                t.name = f"{w.name}.{t.name}"
                t.deps = [f"{w.name}.{d}" for d in t.deps]
            executors.append(Executor(sysm, mover, tasks, nb, w.name))
        elif eng == "vector":
            tasks, nb, _ = map_vector(sysm, w, 2 if db else 1)
            for t in tasks:
                t.name = f"{w.name}.{t.name}"
            executors.append(Executor(sysm, mover, tasks, nb, w.name))
        elif eng == "cpu":
            home = sysm.home_name()
            cap = p.memory(home).capacity_bytes
            need = 4 * w.dims["n"]
            if need > cap // 2:
                raise UnsupportedConfiguration(f"mixed: CPU stream of {need} B does not fit in the top half of {home}")
            top = cap - need                       # top of the home memory, away from the accelerator data
            addrs = [sysm.base[home] + top + 4 * i for i in range(w.dims["n"])]
            streams.append(CpuStream(sysm, addrs, home, 1, 2))
        per.append((w, eng))
    for e in executors:
        e.start()
    for c in streams:
        c.start()
    rs = sysm.eng.run()
    out = {"category": "EVENT_SIMULATED", "profile": p.name, "makespan_s": sysm.eng.now / FS_PER_S,
           "events": rs.events, "parts": []}
    ex_by = {e.name: e for e in executors}
    for w, eng in per:
        if eng == "cpu":
            s = streams.pop(0)
            t_end = s.t_end or sysm.eng.now
            out["parts"].append({"workload": w.name, "engine": eng, "time_s": t_end / FS_PER_S,
                                 "ops_per_s": w.arithmetic_ops / (t_end / FS_PER_S)})
        else:
            e = ex_by[w.name]
            t_end = max(t.t_done for t in e.tasks)
            work = w.macs if eng == "tensor" else w.arithmetic_ops
            out["parts"].append({"workload": w.name, "engine": eng, "time_s": t_end / FS_PER_S,
                                 "ops_per_s": work / (t_end / FS_PER_S),
                                 "kind": "MAC" if eng == "tensor" else w.precision.arithmetic_kind.value})
    out["interconnect"] = sysm.ic.stats(_span(sysm))
    out["memories"] = {k: v.stats() if isinstance(v, (SramArray, Cache)) else v.stats(_span(sysm))
                       for k, v in sysm.mem.items()}
    if sysm.dma:
        out["dma"] = sysm.dma.stats(_span(sysm))
    return out


# =========================================================================== metrics & classification
def _engine_breakdown(sysm: System, executors: list[Executor], span: int) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for e in executors:
        for engname, iv in e.engine_busy.items():
            busy = sum(b - a for a, b, _ in iv)
            # idle time attribution: waiting for operands (a task of this engine loading) vs dependency/other
            mem_wait = dep_wait = 0
            tl = sorted(iv)
            cursor = 0
            for (a, b, name) in tl:
                gap = a - cursor
                if gap > 0:
                    t = e.by[name]
                    waited_load = max(0, min(a, (t.t_loaded or a)) - max(cursor, t.t_load_start or cursor))
                    mem_wait += min(gap, waited_load)
                    dep_wait += gap - min(gap, waited_load)
                cursor = b
            tail = span - cursor
            d = out.setdefault(engname, {"busy_fs": 0, "memory_stall_fs": 0, "dependency_stall_fs": 0, "tail_fs": 0})
            d["busy_fs"] += busy
            d["memory_stall_fs"] += mem_wait
            d["dependency_stall_fs"] += dep_wait
            d["tail_fs"] += max(0, tail)
    for d in out.values():
        d["busy_fraction"] = d["busy_fs"] / span
        d["memory_stall_fraction"] = d["memory_stall_fs"] / span
        d["dependency_stall_fraction"] = d["dependency_stall_fs"] / span
        d["drain_fraction"] = d["tail_fs"] / span
    return out


def _timeline(sysm: System, buckets: int = 60) -> dict:
    span = _span(sysm)
    edges = np.linspace(0, span, buckets + 1)
    series = {}
    for port, ch in list(sysm.ic.req_ch.items()) + [(f"{k}.rsp", v) for k, v in sysm.ic.rsp_ch.items()]:
        name = port if port.endswith(".rsp") else f"{port}.req"
        acc = np.zeros(buckets)
        for s, e, nbytes in ch.intervals:
            if e <= s:
                continue
            i0 = int(np.searchsorted(edges, s, side="right") - 1)
            i1 = int(np.searchsorted(edges, e, side="left"))
            for i in range(max(0, i0), min(buckets, i1)):
                ov = min(e, edges[i + 1]) - max(s, edges[i])
                acc[i] += nbytes * ov / (e - s)
        if acc.sum():
            series[name] = (acc / ((edges[1] - edges[0]) / FS_PER_S)).tolist()
    return {"bucket_s": float((edges[1] - edges[0]) / FS_PER_S), "Bps": series,
            "peak_Bps_per_channel": sysm.ic.width * sysm.ic.clock.freq_hz}


def classify(res: dict) -> dict:
    th = THRESHOLDS
    eng = res.get("engine_breakdown", {}).get(res["engine"], {})
    busy = eng.get("busy_fraction", res.get("cpu_compute_fraction", 0.0))
    resources: dict[str, float] = {}
    for port, v in res["interconnect"]["ports"].items():
        resources[f"interconnect:{port}"] = max(v["req_busy_fraction"], v["rsp_busy_fraction"])
    for name, m in res["memories"].items():
        if "utilisation" in m:
            resources[f"sram_banks:{name}"] = m["utilisation"]
        if "bus_utilisation" in m:
            resources[f"dram:{name}"] = m["bus_utilisation"]
    if res.get("dma"):
        resources["dma"] = res["dma"]["busy_fraction"] if res["dma"]["outstanding_limit_events"] == 0 else \
            max(res["dma"]["busy_fraction"], 0)
    if res.get("cpu_copy"):
        resources["cpu_copy"] = res["cpu_copy"]["busy_fraction"]
    top = max(resources.items(), key=lambda kv: kv[1], default=("none", 0.0))
    span_c = max(1.0, res["makespan_cycles"])
    conf = max([sum(m.get("bank_conflict_cycles", [0])) / (span_c * max(1, len(m.get("bank_conflict_cycles", [1]))))
                for m in res["memories"].values()] or [0.0])
    lat_lim = res.get("latency_limit_fraction", 0.0)
    mover_busy = res.get("cpu_copy", {}).get("busy_fraction", 0.0) or (res.get("dma") or {}).get("busy_fraction", 0.0)
    if busy >= th["compute_busy"]:
        bound, why = "COMPUTE_BOUND", f"engine busy {busy:.0%}"
        if res.get("engine_internal_limit"):
            why += f"; inside the engine: {res['engine_internal_limit']}"
    elif top[1] >= th["bandwidth_util"]:
        bound, why = "BANDWIDTH_BOUND", f"{top[0]} {top[1]:.0%} utilised"
        if top[0] == "cpu_copy":
            why += " (data movement by CPU load/store: no DMA)"
    elif conf >= th["conflict_bank_time_fraction"]:
        bound, why = "CONTENTION_BOUND", f"bank-conflict stalls = {conf:.0%} of bank time"
    elif lat_lim >= th["latency_limit_fraction"]:
        bound, why = "LATENCY_BOUND", f"outstanding-request limit reached {lat_lim:.0%} of issue attempts"
    elif busy + mover_busy >= th["compute_busy"] and res.get("mapping", {}).get("nbuf", 1) == 1:
        bound, why = "SERIALISATION_BOUND", (f"compute ({busy:.0%}) and data movement ({mover_busy:.0%}) do not "
                                             f"overlap (single buffer): double buffering targets this")
    else:
        bound, why = "OVERHEAD_BOUND", "fixed command/setup overheads and dependencies dominate"
    return {"bound": bound, "reason": why, "busiest_resource": top[0], "busiest_utilisation": top[1],
            "thresholds": th, "resources": resources}


def collect(sysm: System, w: wl.Workload, engine: str, kind: OpKind, work: float, executors: list[Executor],
            streams: list[CpuStream], mover: Mover, info: dict, rs) -> dict:
    span = _span(sysm)
    t = span / FS_PER_S
    res: dict[str, Any] = {"category": "EVENT_SIMULATED", "fidelity": "transaction-level, approximately timed",
                           "profile": sysm.p.name, "workload": w.name, "family": w.family, "strategy": w.strategy,
                           "engine": engine, "kind": kind.value, "precision": w.precision.value,
                           "makespan_s": t, "makespan_cycles": span / sysm.clk.period_fs, "events": rs.events,
                           "wall_s": rs.wall_s, "mapping": info, "mover": mover.kind}
    res["achieved_ops_per_s"] = work / t if work else 0.0
    peak = None
    if engine in ("cpu", "vector", "tensor"):
        try:
            peak = machine.peak_for(sysm.p, engine, w, kind).value
        except UnsupportedConfiguration:
            peak = None
    res["peak_ops_per_s"] = peak
    res["compute_utilisation"] = (res["achieved_ops_per_s"] / peak) if peak else None
    if peak and res["achieved_ops_per_s"] > peak * (1 + 1e-9):
        raise SimulationError(f"physically impossible: {res['achieved_ops_per_s']:.3g} > peak {peak:.3g}")
    res["engine_breakdown"] = _engine_breakdown(sysm, executors, span)
    if engine == "tensor" and engine in sysm.engines:
        te = sysm.engines["tensor"]
        sc = te.step_cycles(w.precision)
        if sc > te.depth / te._rate(w.precision):
            res["engine_internal_limit"] = (f"operand delivery {te.step_operand_bytes(w.precision)} B per k-step at "
                                            f"{te.operand_bytes_per_cycle:g} B/cycle -> "
                                            f"{te.pes / sc:.3g} of {te.pes} MAC/cycle")
    res["interconnect"] = sysm.ic.stats(span)
    res["memories"] = {k: (v.stats() if isinstance(v, (SramArray, Cache)) else v.stats(span)) for k, v in sysm.mem.items()}
    for k, v in sysm.mem.items():
        if isinstance(v, SramArray):
            res["memories"][k] = v.stats(span_cycles=int(span / sysm.clk.period_fs))
    if sysm.dma:
        res["dma"] = sysm.dma.stats(span)
        res["dma_bursts"] = [list(b) for b in sysm.dma.bursts[:5000]]
        attempts = max(1, sysm.dma.outstanding_limit_events + len(sysm.dma.bursts))
        res["latency_limit_fraction"] = sysm.dma.outstanding_limit_events / attempts
    if mover.cpu:
        res["cpu_copy"] = {"bytes": mover.cpu.bytes, "busy_fraction": mover.cpu.busy_fs / span}
    if streams:
        s = streams[0]
        res["cpu_compute_fraction"] = s.busy_compute_fs / span
        res["latency_limit_fraction"] = s.limit_events / max(1, len(s.addrs))
        res["engine_breakdown"] = {"cpu": {"busy_fraction": s.busy_compute_fs / span,
                                           "memory_stall_fraction": 1 - s.busy_compute_fs / span,
                                           "dependency_stall_fraction": 0.0, "drain_fraction": 0.0}}
    lat = sysm.ic.all_latencies_cycles()
    res["latency_cycles"] = {"count": int(lat.size), "mean": float(lat.mean()) if lat.size else 0.0,
                             "p50": float(np.percentile(lat, 50)) if lat.size else 0.0,
                             "p95": float(np.percentile(lat, 95)) if lat.size else 0.0,
                             "p99": float(np.percentile(lat, 99)) if lat.size else 0.0,
                             "max": float(lat.max()) if lat.size else 0.0}
    res["latency_histogram"] = np.histogram(lat, bins=min(40, max(1, int(lat.size ** 0.5))))[0].tolist() if lat.size else []
    res["latency_histogram_edges"] = np.histogram(lat, bins=min(40, max(1, int(lat.size ** 0.5))))[1].tolist() if lat.size else []
    res["bandwidth_timeline"] = _timeline(sysm)
    tsp = None
    try:
        tsp = sysm.tspm_name()
    except UnsupportedConfiguration:
        pass
    hm = {}
    for k, v in sysm.mem.items():
        if isinstance(v, SramArray):
            mat, bucket = v.heatmap()
            hm[k] = {"bucket_cycles": bucket, "accesses": mat.tolist()}
    res["bank_heatmaps"] = hm
    total_bytes = sum(v["bytes"] for v in res["interconnect"]["masters"].values())
    res["interconnect_bytes"] = total_bytes
    res["sustained_Bps"] = total_bytes / t
    res["tasks"] = [{"name": tk.name, "engine": tk.engine, "load_start": tk.t_load_start, "loaded": tk.t_loaded,
                     "compute_start": tk.t_compute_start, "compute_end": tk.t_compute_end, "done": tk.t_done}
                    for e in executors for tk in e.tasks[:2000]]
    res["classification"] = classify(res)
    if sysm.trace.enabled:
        errs = sysm.trace.check_invariants(sysm.ic.name, "ACCEPT", "RESPONSE")
        for k, v in sysm.mem.items():
            if isinstance(v, (SramArray, Dram)):
                errs += [f"{k}: {e}" for e in sysm.trace.check_invariants(k, "ACCEPT", "SERVICE_END")]
        res["trace_invariant_errors"] = errs
        res["_trace_rows"] = sysm.trace.rows
    return res
