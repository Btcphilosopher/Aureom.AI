"""Interactive dashboard (Plotly HTML) + static figures (PNG) + REPORT.md from a run directory.

Every panel states its result category; colours follow memorylab.plotting (validated palette);
marker shape encodes category: hollow circle = ANALYTICAL_CEILING, filled circle =
EVENT_SIMULATED, diamond = RTL_OBSERVED.  No panel shows silicon data (none exists).
"""
from __future__ import annotations

import html
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.offline import get_plotlyjs

from . import plotting
from .plotting import SERIES, THEME
from .units import si

FONT = "Inter, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif"


def _layout(fig: go.Figure, title: str, xlab: str, ylab: str, *, logx=False, logy=False, height=460) -> go.Figure:
    fig.update_layout(
        title=dict(text=title, font=dict(size=15, color=THEME["text"]), x=0.01, xanchor="left", y=0.98, yanchor="top"),
        paper_bgcolor=THEME["surface"], plot_bgcolor=THEME["surface"], height=height,
        font=dict(family=FONT, color=THEME["text_2"], size=12), margin=dict(l=70, r=30, t=96, b=60),
        legend=dict(bgcolor=THEME["surface_2"], bordercolor=THEME["axis"], borderwidth=1, font=dict(color=THEME["text"]),
                    orientation="h", x=0, xanchor="left", y=-0.16, yanchor="top"),
        hoverlabel=dict(bgcolor=THEME["surface_2"], bordercolor=THEME["axis"], font=dict(color=THEME["text"])))
    for ax, lab, log in ((fig.update_xaxes, xlab, logx), (fig.update_yaxes, ylab, logy)):
        ax(title=dict(text=lab, font=dict(color=THEME["text_2"])), type="log" if log else "linear",
           gridcolor=THEME["grid"], linecolor=THEME["axis"], zerolinecolor=THEME["grid"],
           tickfont=dict(color=THEME["text_2"]))
    return fig


def _load(run: Path, rel: str) -> Any:
    p = run / rel
    if not p.exists():
        return None
    if p.suffix == ".json":
        return json.loads(p.read_text())
    return pd.read_csv(p)


# =========================================================================== Roofline explorer
def roofline_explorer(run: Path, profiles: list[str]) -> tuple[go.Figure, list[str]]:
    fig = go.Figure()
    combos: list[tuple[str, str, list[int]]] = []
    tile = _load(run, "rtl/sfv_tile_latency.json")
    for pn in profiles:
        a = _load(run, f"analytical/{pn}.json")
        s = _load(run, f"simulated/{pn}.json")
        if not a:
            continue
        simres = {(r["workload"], r["engine"]): r for r in (s or {}).get("runs", [])}
        groups = sorted({(r["engine"], r["precision"]) for r in a["results"] if r.get("status") == "ok"},
                        key=lambda g: (("tensor", "vector", "cpu").index(g[0]), g[1]))
        for eng, prec in groups:
            rs = [r for r in a["results"] if r.get("status") == "ok" and r["engine"] == eng and r["precision"] == prec]
            if not rs:
                continue
            idx0 = len(fig.data)
            peak = rs[0]["peak"]
            levels: dict[str, float] = {}
            for r in rs:
                for lv in r["levels"]:
                    levels[lv["level"]] = lv["effective_bandwidth_Bps"]
            xs_i = [lv["intensity"] for r in rs for lv in r["levels"] if lv["intensity"]] + [peak / b for b in levels.values()]
            lo, hi = min(xs_i) / 8, max(xs_i) * 8
            xs = np.logspace(math.log10(lo), math.log10(hi), 200)
            unit = rs[0]["rate_unit"]
            fig.add_trace(go.Scatter(x=[lo, hi], y=[peak, peak], mode="lines", line=dict(color=THEME["compute_roof"], width=2),
                                     name=f"compute roof {si(peak)}{unit}", visible=False,
                                     hovertemplate=f"peak {si(peak)}{unit}<extra></extra>"))
            for i, (lname, b) in enumerate(levels.items()):
                fig.add_trace(go.Scatter(x=xs, y=np.minimum(peak, xs * b), mode="lines",
                                         line=dict(color=SERIES[i % 4], width=2), visible=False,
                                         name=f"{lname} roof {b / 1e9:.3g} GB/s",
                                         hovertemplate=f"{lname}: I=%{{x:.3g}}, P=%{{y:.3g}} {unit}<extra></extra>"))
            ax, ay, at, sx, sy, st = [], [], [], [], [], []
            for r in rs:
                bl = next((lv for lv in r["levels"] if lv["level"] == r["binding"]),
                          max(r["levels"], key=lambda q: q["time_lower_bound_s"]))
                x = bl["intensity"] if bl["intensity"] else hi
                ax.append(x)
                ay.append(r["ceiling"])
                at.append(f"{r['workload']}<br>ANALYTICAL_CEILING {si(r['ceiling'])}{unit}<br>binding: {r['binding']} "
                          f"({r['bound']})<br>I = {x:.3g} {r['intensity_unit']} at {bl['level']}")
                srun = simres.get((r["workload"], eng))
                if srun:
                    sx.append(x)
                    sy.append(srun["achieved_ops_per_s"])
                    st.append(f"{r['workload']}<br>EVENT_SIMULATED {si(srun['achieved_ops_per_s'])}{unit}<br>"
                              f"{srun['classification']['bound']}: {html.escape(srun['classification']['reason'])}")
            fig.add_trace(go.Scatter(x=ax, y=ay, mode="markers", visible=False, name="analytical ceiling",
                                     marker=dict(symbol="circle-open", size=11, color=THEME["text"], line=dict(width=2)),
                                     text=at, hovertemplate="%{text}<extra></extra>"))
            if sx:
                fig.add_trace(go.Scatter(x=sx, y=sy, mode="markers", visible=False, name="event-simulated",
                                         marker=dict(symbol="circle", size=9, color=THEME["text"],
                                                     line=dict(width=1.5, color=THEME["surface"])),
                                         text=st, hovertemplate="%{text}<extra></extra>"))
            if tile and eng == "tensor" and pn == "silicaflux_v_release1_rtl":
                p_f = 50e6
                tx, ty, tt = [], [], []
                for row in tile["rows"]:
                    if row["engine"] == "tensor" and "WB=1" in row["case"]:
                        k = int(row["case"].split("K=")[1].split()[0])
                        macs = 16 * k
                        tx.append(macs / (8 * k))                    # MAC per operand byte at the TE port
                        ty.append(macs / (row["observed_cycles"] / p_f))
                        tt.append(f"sfv_tile RTL (Verilator) {row['case']}: CYCLES={row['observed_cycles']}<br>"
                                  f"RTL_OBSERVED {si(ty[-1])}MAC/s at 50 MHz, operands resident")
                fig.add_trace(go.Scatter(x=tx, y=ty, mode="markers", visible=False, name="RTL-observed (tile)",
                                         marker=dict(symbol="diamond", size=10, color=THEME["gold"],
                                                     line=dict(width=1, color=THEME["surface"])),
                                         text=tt, hovertemplate="%{text}<extra></extra>"))
            combos.append((pn, f"{eng} ({prec})", list(range(idx0, len(fig.data))),
                           (rs[0]["rate_unit"], rs[0]["intensity_unit"], prec)))
    n = len(fig.data)
    buttons = []
    for pn, eng, idx, (ru, iu, prec) in combos:
        vis = [i in idx for i in range(n)]
        buttons.append(dict(label=f"{pn} / {eng}", method="update", args=[{"visible": vis},
                            {"title.text": f"Hierarchical Roofline - {pn} / {eng} engine",
                             "yaxis.title.text": f"performance [{ru}, {prec}]",
                             "xaxis.title.text": f"arithmetic intensity at the interface [{iu}]"}]))
    if combos:
        for i in combos[0][2]:
            fig.data[i].visible = True
    ru, iu, prec = combos[0][3] if combos else ("ops/s", "ops/B", "")
    _layout(fig, f"Hierarchical Roofline - {combos[0][0]} / {combos[0][1]} engine" if combos else "Roofline",
            f"arithmetic intensity at the interface [{iu}]", f"performance [{ru}, {prec}]",
            logx=True, logy=True, height=600)
    fig.update_layout(updatemenus=[dict(buttons=buttons, direction="down", x=0.0, xanchor="left", y=1.02, yanchor="bottom",
                                        bgcolor=THEME["surface_2"], bordercolor=THEME["axis"],
                                        font=dict(color=THEME["text"]))])
    return fig, [f"{p}/{e}" for p, e, _, _ in combos]


# =========================================================================== other panels
def stall_breakdown(run: Path, profiles: list[str]) -> go.Figure:
    fig = go.Figure()
    comps = [("engine_busy", "compute (engine busy)", SERIES[0]), ("memory_stall", "memory stall", SERIES[3]),
             ("dependency_stall", "dependency / other idle", SERIES[2])]
    df = _load(run, "simulated/simulated_summary.csv")
    if df is None:
        return _layout(fig, "Compute vs memory stall breakdown", "", "")
    df = df[df.status == "ok"]
    buttons = []
    per = len(comps)
    for j, pn in enumerate(profiles):
        sub = df[(df.profile == pn) & (df.engine.isin(["tensor", "vector"]))]
        for key, name, col in comps:
            fig.add_trace(go.Bar(y=sub["workload"], x=sub[key].fillna(0), orientation="h", name=name,
                                 marker=dict(color=col, line=dict(color=THEME["surface"], width=2)),
                                 visible=(j == 0), hovertemplate=f"{name}: %{{x:.0%}}<extra>%{{y}}</extra>"))
    for j, pn in enumerate(profiles):
        vis = [False] * (per * len(profiles))
        for k in range(per):
            vis[j * per + k] = True
        buttons.append(dict(label=pn, method="update", args=[{"visible": vis},
                            {"title.text": f"Compute vs memory stall breakdown - {pn} (EVENT_SIMULATED)"}]))
    fig.update_layout(barmode="stack", updatemenus=[dict(buttons=buttons, x=0.0, xanchor="left", y=1.02, yanchor="bottom",
                                                         bgcolor=THEME["surface_2"], font=dict(color=THEME["text"]))])
    return _layout(fig, f"Compute vs memory stall breakdown - {profiles[0]} (EVENT_SIMULATED)",
                   "fraction of makespan", "", height=460)


def _pick_run(run: Path, pn: str, wname_prefix: str) -> dict | None:
    s = _load(run, f"simulated/{pn}.json")
    if not s:
        return None
    return next((r for r in s["runs"] if r["workload"].startswith(wname_prefix)), None)


def bank_heatmap(r: dict) -> go.Figure:
    fig = go.Figure()
    mems = list(r["bank_heatmaps"].items())
    for j, (mem, hm) in enumerate(mems):
        mat = np.array(hm["accesses"], dtype=float)
        util = mat / hm["bucket_cycles"]
        fig.add_trace(go.Heatmap(z=util, colorscale=[[0, THEME["surface_2"]], [1, THEME["cyan"]]], zmin=0, zmax=1,
                                 visible=(j == 0), colorbar=dict(title=dict(text="bank<br>utilisation"),
                                                                 tickfont=dict(color=THEME["text_2"])),
                                 hovertemplate=f"{mem} bank %{{y}}, bucket %{{x}}: %{{z:.0%}}<extra></extra>"))
    fig.update_layout(updatemenus=[dict(buttons=[dict(label=m, method="update",
                                                      args=[{"visible": [i == j for i in range(len(mems))]}])
                                                 for j, (m, _) in enumerate(mems)],
                                        x=0.0, xanchor="left", y=1.02, yanchor="bottom", bgcolor=THEME["surface_2"],
                                        font=dict(color=THEME["text"]))])
    b = mems[0][1]["bucket_cycles"] if mems else 64
    fig.update_yaxes(dtick=1, tickformat="d")
    return _layout(fig, f"SRAM bank utilisation - {r['profile']} / {r['workload']} (EVENT_SIMULATED)",
                   f"time bucket ({b} cycles each)", "bank")


def latency_hist(runs: list[dict]) -> go.Figure:
    fig = go.Figure()
    runs = [r for r in runs if r.get("latency_histogram")][:6]
    for i, r in enumerate(runs):
        h, e = r["latency_histogram"], r["latency_histogram_edges"]
        mids = [(a + b) / 2 for a, b in zip(e, e[1:])]
        fig.add_trace(go.Bar(x=mids, y=h, name=f"{r['profile']} / {r['workload']}", marker=dict(color=SERIES[0]),
                             width=[(b - a) * 0.9 for a, b in zip(e, e[1:])], visible=(i == 0),
                             hovertemplate="%{x:.1f} cycles: %{y} transactions<extra></extra>"))
    lc = runs[0]["latency_cycles"] if runs else {}
    fig.update_layout(showlegend=False, updatemenus=[dict(
        buttons=[dict(label=f"{r['profile']} / {r['workload']}", method="update",
                      args=[{"visible": [j == i for j in range(len(runs))]},
                            {"title.text": f"Transaction latency - {r['profile']} / {r['workload']} "
                                           f"(mean {r['latency_cycles']['mean']:.1f}, p95 {r['latency_cycles']['p95']:.0f}, "
                                           f"p99 {r['latency_cycles']['p99']:.0f} cycles)"}])
                 for i, r in enumerate(runs)],
        x=0.0, xanchor="left", y=1.02, yanchor="bottom", bgcolor=THEME["surface_2"], font=dict(color=THEME["text"]))])
    t = (f"Transaction latency - {runs[0]['profile']} / {runs[0]['workload']} (mean {lc.get('mean', 0):.1f}, "
         f"p95 {lc.get('p95', 0):.0f}, p99 {lc.get('p99', 0):.0f} cycles)") if runs else "Transaction latency"
    return _layout(fig, t, "latency [cycles, enqueue to response]", "transactions (EVENT_SIMULATED)")


def bw_timeline(r: dict) -> go.Figure:
    fig = go.Figure()
    tl = r["bandwidth_timeline"]
    t = np.arange(len(next(iter(tl["Bps"].values()), []))) * tl["bucket_s"] * 1e6
    for i, (name, ys) in enumerate(list(tl["Bps"].items())[:4]):
        fig.add_trace(go.Scatter(x=t, y=np.array(ys) / 1e9, mode="lines", name=name, line=dict(color=SERIES[i], width=2),
                                 hovertemplate="%{y:.3g} GB/s at %{x:.2f} us<extra>" + name + "</extra>"))
    fig.add_trace(go.Scatter(x=[t[0], t[-1]] if len(t) else [0, 1], y=[tl["peak_Bps_per_channel"] / 1e9] * 2,
                             mode="lines", line=dict(color=THEME["text_3"], dash="dash", width=1),
                             name="channel peak (width x f)"))
    return _layout(fig, f"Bandwidth utilisation timeline - {r['profile']} / {r['workload']} (EVENT_SIMULATED)",
                   "time [us]", "bandwidth [GB/s]")


def pipeline_gantt(runs: list[dict]) -> go.Figure:
    fig = go.Figure()
    for j, r in enumerate(runs):
        P = 1e15 / (r["makespan_s"] and (r["makespan_cycles"] / r["makespan_s"]))
        tasks = r["tasks"][:40]
        for k, (lab, a, b, col) in enumerate((("load", "load_start", "loaded", SERIES[1]),
                                              ("compute", "compute_start", "compute_end", SERIES[0]),
                                              ("store", "compute_end", "done", SERIES[2]))):
            fig.add_trace(go.Bar(y=[f"{r['profile'][:22]} {t['name']}" for t in tasks],
                                 x=[(t[b] - t[a]) / P for t in tasks], base=[t[a] / P for t in tasks],
                                 orientation="h", name=lab, marker=dict(color=col), showlegend=(j == 0),
                                 hovertemplate=f"{lab}: %{{base:.0f}} -> +%{{x:.0f}} cycles<extra>%{{y}}</extra>"))
    fig.update_layout(barmode="overlay", yaxis=dict(autorange="reversed"))
    return _layout(fig, "Accelerator pipeline: load / compute / store per tile (EVENT_SIMULATED)", "cycle", "",
                   height=620)


def dma_timeline(r: dict) -> go.Figure:
    fig = go.Figure()
    P = 1e15 / (r["makespan_cycles"] / r["makespan_s"])
    b = r.get("dma_bursts") or []
    b = b[:400]
    xs_r, ys_r, xs_w, ys_w = [], [], [], []
    for i, (did, ch, t0, tr, tw, n, lab) in enumerate(b):
        xs_r += [t0 / P, tr / P, None]
        ys_r += [i, i, None]
        xs_w += [tr / P, tw / P, None]
        ys_w += [i, i, None]
    fig.add_trace(go.Scatter(x=xs_r, y=ys_r, mode="lines", line=dict(color=SERIES[0], width=3), name="read burst"))
    fig.add_trace(go.Scatter(x=xs_w, y=ys_w, mode="lines", line=dict(color=SERIES[1], width=3), name="write burst"))
    return _layout(fig, f"DMA request timeline - {r['profile']} / {r['workload']} (EVENT_SIMULATED)", "cycle",
                   "burst #", height=480)


def marginal_curves(run: Path, sweep: str = "architecture_sweep") -> go.Figure:
    fig = go.Figure()
    df = _load(run, f"sweeps/{sweep}.csv")
    if df is None:
        return _layout(fig, "Marginal gain curves", "", "")
    knobs = [k for k in ("vector_lanes", "tensor_dim", "tensor_operand_ports", "sram_kib", "tspm_kib", "sram_banks",
                         "bus_bits", "dma_outstanding", "cpu_cores", "clock_hz") if k in df.columns]
    groups = []
    base = df[df._vary == "baseline"]
    pick = {"vector_lanes": ("dot", "vector_add", "gemm_64x64x64_double"),
            "tensor_dim": ("gemm_64x64x64_double", "gemm_64x64x64_blocked", "conv2d", "dot"),
            "tensor_operand_ports": ("gemm_64x64x64_double", "gemm_64x64x64_blocked", "conv2d", "dot")}
    default_pick = ("dot", "vector_add", "gemm_64x64x64_double", "conv2d")
    for knob in knobs:
        sub = pd.concat([df[df._vary == knob], base]).dropna(subset=["sim_throughput_vs_baseline"])
        idx = []
        for i, pre in enumerate(pick.get(knob, default_pick)):
            g = sub[sub.workload.str.startswith(pre)].sort_values(knob)
            if g.empty:
                continue
            wname = g.workload.iloc[0]
            idx.append(len(fig.data))
            fig.add_trace(go.Scatter(x=g[knob], y=g["sim_throughput_vs_baseline"], mode="lines+markers", name=wname,
                                     line=dict(color=SERIES[i], width=2), marker=dict(size=8), visible=False,
                                     text=g["sim_bound"] + ": " + g["busiest_resource"].astype(str),
                                     hovertemplate=f"{knob}=%{{x}}: %{{y:.2f}}x baseline<br>%{{text}}<extra>{wname}</extra>"))
        groups.append((knob, idx))
    n = len(fig.data)
    for i in groups[0][1] if groups else []:
        fig.data[i].visible = True
    logk = {"vector_lanes", "tensor_dim", "sram_kib", "tspm_kib", "sram_banks", "bus_bits", "dma_outstanding", "cpu_cores"}
    fig.update_layout(updatemenus=[dict(buttons=[dict(label=k, method="update",
                                                      args=[{"visible": [i in idx for i in range(n)]},
                                                            {"xaxis.title.text": k,
                                                             "xaxis.type": "log" if k in logk else "linear"}])
                                                 for k, idx in groups],
                                        x=0.0, xanchor="left", y=1.02, yanchor="bottom", bgcolor=THEME["surface_2"],
                                        font=dict(color=THEME["text"]))])
    return _layout(fig, "Marginal gain: simulated throughput vs one architectural knob (EVENT_SIMULATED, OFAT)",
                   groups[0][0] if groups else "", "throughput relative to baseline [x]",
                   logx=bool(groups) and groups[0][0] in logk)


def capacity_curves(run: Path) -> go.Figure:
    fig = go.Figure()
    df = _load(run, "sweeps/memory_sweep.csv")
    if df is None:
        return _layout(fig, "Performance vs SRAM capacity", "", "")
    base = df[df._vary == "baseline"]
    i = 0
    for knob in ("tspm_kib", "sram_kib"):
        sub = pd.concat([df[df._vary == knob], base])
        for wname, g in sub.groupby("workload"):
            if not wname.startswith("gemm") or i >= 4:
                continue
            g = g.dropna(subset=["sim_throughput"]).sort_values(knob)
            fig.add_trace(go.Scatter(x=g[knob], y=g["sim_throughput"] / 1e6, mode="lines+markers",
                                     name=f"{wname} vs {knob}", line=dict(color=SERIES[i], width=2),
                                     hovertemplate=f"{knob}=%{{x}} KiB: %{{y:.4g}} MMAC/s<extra></extra>"))
            i += 1
    cs = _load(run, "analytical/sram_capacity_study.csv")
    if cs is not None:
        for wname, g in cs[cs.status == "ok"].groupby("workload"):
            if i >= 4:
                break
            fig.add_trace(go.Scatter(x=g["sram_kib"], y=g["dram_ceiling_mac_per_s"] / 1e6, mode="lines+markers",
                                     name=f"{wname}: DRAM roof (ANALYTICAL, silicaflux_full)",
                                     line=dict(color=SERIES[i], width=2, dash="dot"), marker=dict(symbol="circle-open"),
                                     hovertemplate="SRAM %{x} KiB: DRAM-interface ceiling %{y:.4g} MMAC/s<extra></extra>"))
            i += 1
    return _layout(fig, "Performance vs SRAM / scratchpad capacity", "capacity [KiB]",
                   "throughput or ceiling [MMAC/s, int8]", logx=True, logy=True)


def size_curves(run: Path) -> go.Figure:
    fig = go.Figure()
    df = _load(run, "sweeps/architecture_sweep.csv")
    if df is None:
        return _layout(fig, "Performance vs vector/tensor size", "", "")
    base = df[df._vary == "baseline"]
    i = 0
    for knob, wprefix in (("vector_lanes", "dot"), ("vector_lanes", "vector_add"), ("tensor_dim", "gemm_64x64x64_double"),
                          ("tensor_dim", "conv2d")):
        g = pd.concat([df[df._vary == knob], base])
        g = g[g.workload.str.startswith(wprefix)].dropna(subset=["sim_throughput_vs_baseline"]).sort_values(knob)
        if g.empty:
            continue
        fig.add_trace(go.Scatter(x=g[knob], y=g["sim_throughput_vs_baseline"], mode="lines+markers",
                                 name=f"{g.workload.iloc[0]} vs {knob}", line=dict(color=SERIES[i], width=2),
                                 hovertemplate=f"{knob}=%{{x}}: %{{y:.2f}}x<extra></extra>"))
        i += 1
    return _layout(fig, "Performance vs vector lanes / tensor array dimension (EVENT_SIMULATED)",
                   "lanes or array dimension d", "throughput relative to baseline [x]", logx=True)


def pareto_explorer(run: Path) -> go.Figure:
    fig = go.Figure()
    df = _load(run, "sweeps/pareto_sweep_pareto.csv")
    if df is None or df.empty:
        return _layout(fig, "Pareto explorer", "", "")
    knobs = [c for c in ("vector_lanes", "tensor_dim", "tensor_operand_ports", "sram_kib", "tspm_kib", "bus_bits",
                         "dma_outstanding") if c in df.columns]
    txt = df[knobs].astype(str).apply(lambda r: "<br>".join(f"{k}={v}" for k, v in r.items()), axis=1)
    for flag, name, sym, col in ((False, "dominated", "circle-open", THEME["text_3"]),
                                 (True, "Pareto-optimal (model)", "circle", THEME["gold"])):
        m = df["pareto"] == flag
        fig.add_trace(go.Scatter(x=df.loc[m, "area_mm2"], y=df.loc[m, "geomean_speedup"], mode="markers", name=name,
                                 marker=dict(symbol=sym, size=11, color=col, line=dict(width=1.5)),
                                 text=txt[m], hovertemplate="%{text}<br>area %{x:.3f} mm2<br>%{y:.2f}x<extra></extra>"))
    front = df[df["pareto"]].sort_values("area_mm2")
    fig.add_trace(go.Scatter(x=front["area_mm2"], y=front["geomean_speedup"], mode="lines", showlegend=False,
                             line=dict(color=THEME["gold"], width=1, dash="dot")))
    return _layout(fig, "Pareto explorer: geomean speedup vs modelled area (HYPOTHETICAL area coefficients)",
                   "modelled area [mm2] (SRAM macro area + hypothetical logic coefficients)",
                   "geomean simulated speedup vs baseline [x]")


def provenance_bars(run: Path, profiles: list[str]) -> go.Figure:
    fig = go.Figure()
    cats = ["VERIFIED_REPO", "RTL_SIMULATED", "EXTERNAL_MEASURED", "HYPOTHETICAL"]
    cols = [SERIES[0], SERIES[2], SERIES[1], SERIES[3]]
    data = {pn: (_load(run, f"analytical/{pn}.json") or {}).get("parameter_provenance", {}) for pn in profiles}
    for c, col in zip(cats, cols):
        fig.add_trace(go.Bar(y=profiles, x=[data[p].get(c, 0) for p in profiles], orientation="h", name=c,
                             marker=dict(color=col, line=dict(color=THEME["surface"], width=2))))
    fig.update_layout(barmode="stack")
    return _layout(fig, "Parameter provenance per profile (count of parameters)", "parameters", "", height=360)


def tile_latency_fig(run: Path) -> go.Figure:
    fig = go.Figure()
    t = _load(run, "rtl/sfv_tile_latency.json")
    if not t:
        return _layout(fig, "SilicaFlux-V engine latency: RTL vs model (PENDING)", "", "")
    for i, eng in enumerate(("tensor", "vector")):
        rows = [r for r in t["rows"] if r["engine"] == eng]
        fig.add_trace(go.Scatter(x=[r["observed_cycles"] for r in rows], y=[r["predicted_cycles"] for r in rows],
                                 mode="markers", name=f"{eng} engine", text=[r["case"] for r in rows],
                                 marker=dict(symbol="diamond", size=9, color=SERIES[i]),
                                 hovertemplate="%{text}<br>RTL %{x} / model %{y} cycles<extra></extra>"))
    mx = max(r["observed_cycles"] for r in t["rows"])
    fig.add_trace(go.Scatter(x=[1, mx], y=[1, mx], mode="lines", line=dict(color=THEME["text_3"], dash="dash"),
                             name="predicted = observed"))
    return _layout(fig, "SilicaFlux-V engine CYCLES: sfv_tile RTL (Verilator) vs MemoryLab model", "RTL-observed cycles",
                   "model cycles", logx=True, logy=True)


def dma_cal_fig(run: Path) -> go.Figure:
    fig = go.Figure()
    c = _load(run, "rtl/dma_calibration_memoryflow.json")
    if not c:
        return _layout(fig, "DMA calibration (PENDING)", "", "")
    lab = [f"{r['path']} b{r['burst_beats']}" for r in c["calibrated_rows"]]
    fig.add_trace(go.Bar(x=lab, y=[r["rtl_cycles"] for r in c["calibrated_rows"]], name="RTL-observed (memoryflow sf_dma)",
                         marker=dict(color=SERIES[1])))
    fig.add_trace(go.Bar(x=lab, y=[r["predicted_cycles"] for r in c["uncalibrated_rows"]], name="model, uncalibrated",
                         marker=dict(color=SERIES[2])))
    fig.add_trace(go.Bar(x=lab, y=[r["predicted_cycles"] for r in c["calibrated_rows"]], name="model, calibrated",
                         marker=dict(color=SERIES[0])))
    fig.update_layout(barmode="group")
    return _layout(fig, f"DMA 4 KiB copy cycles: RTL vs model (mean rel. error {c['uncalibrated_mean_rel_error']:.1%} "
                        f"-> {c['calibrated_mean_rel_error']:.1%})", "path / burst beats", "cycles")


# =========================================================================== page
def _table(df: pd.DataFrame, cols: list[str], fmt: dict[str, str] | None = None, max_rows: int = 60) -> str:
    fmt = fmt or {}
    out = ["<table><thead><tr>" + "".join(f"<th>{html.escape(c)}</th>" for c in cols) + "</tr></thead><tbody>"]
    for _, r in df.head(max_rows).iterrows():
        cells = []
        for c in cols:
            v = r.get(c)
            if isinstance(v, float) and c in fmt:
                s = "" if v != v else format(v, fmt[c])
            elif isinstance(v, float):
                s = "" if v != v else si(v).strip()
            else:
                s = "" if v is None else str(v)
            cells.append(f"<td>{html.escape(s)}</td>")
        out.append("<tr>" + "".join(cells) + "</tr>")
    out.append("</tbody></table>")
    return "".join(out)


CSS = f"""
:root {{ --surface:{THEME['surface']}; --surface-2:{THEME['surface_2']}; --text:{THEME['text']};
  --text-2:{THEME['text_2']}; --text-3:{THEME['text_3']}; --gold:{THEME['gold']}; --cyan:{THEME['cyan']};
  --violet:{THEME['violet']}; --grid:{THEME['grid']}; }}
* {{ box-sizing: border-box; }}
body {{ margin:0; background:var(--surface); color:var(--text); font-family:{FONT}; }}
header {{ padding:28px 32px 18px; border-bottom:1px solid var(--grid); }}
header h1 {{ margin:0; font-size:24px; letter-spacing:.3px; }} header h1 span {{ color:var(--gold); }}
header p {{ margin:6px 0 0; color:var(--text-2); max-width:1100px; }}
main {{ padding:8px 32px 48px; max-width:1500px; }}
section {{ margin:26px 0; }} h2 {{ font-size:17px; color:var(--text); border-left:3px solid var(--cyan);
  padding-left:10px; margin:0 0 6px; }}
.note {{ color:var(--text-2); font-size:13px; margin:2px 0 10px; max-width:1150px; }}
.chips {{ display:flex; flex-wrap:wrap; gap:8px; margin-top:12px; }}
.chip {{ background:var(--surface-2); border:1px solid var(--grid); border-radius:14px; padding:4px 12px;
  font-size:12px; color:var(--text-2); }} .chip b {{ color:var(--text); }}
.grid2 {{ display:grid; grid-template-columns:1fr 1fr; gap:18px; }}
@media (max-width: 1100px) {{ .grid2 {{ grid-template-columns:1fr; }} main, header {{ padding-left:16px; padding-right:16px; }} }}
table {{ border-collapse:collapse; font-size:12px; width:100%; display:block; overflow-x:auto; }}
th, td {{ border-bottom:1px solid var(--grid); padding:5px 8px; text-align:left; white-space:nowrap; }}
th {{ color:var(--text-2); font-weight:600; background:var(--surface-2); position:sticky; top:0; }}
.cat {{ font-size:11px; letter-spacing:.6px; color:var(--gold); text-transform:uppercase; }}
"""


def build_dashboard(run: Path, profiles: list[str]) -> Path:
    prov = _load(run, "provenance.json") or {}
    rtl_status = _load(run, "rtl/status.json") or {}
    parts: list[tuple[str, str, str, str]] = []   # (category, title, note, html)

    def add(cat: str, title: str, note: str, fig: go.Figure | None = None, raw: str | None = None) -> None:
        body = raw if raw is not None else fig.to_html(full_html=False, include_plotlyjs=False,
                                                       config={"displaylogo": False, "responsive": True})
        parts.append((cat, title, note, body))

    rf, _ = roofline_explorer(run, profiles)
    add("ANALYTICAL_CEILING + EVENT_SIMULATED + RTL_OBSERVED", "Roofline explorer",
        "Select a profile/engine. Lines: compute roof and one roof per memory interface (bandwidth x intensity). "
        "Hollow circles: analytical ceilings (upper bounds) at the binding interface's intensity. Filled circles: "
        "event-simulated throughput of the same workload. Gold diamonds: RTL-observed tensor-engine throughput "
        "(sfv_tile, Verilator, operands resident) for the RTL-release profile.", rf)
    a = _load(run, "analytical/analytical_summary.csv")
    s = _load(run, "simulated/simulated_summary.csv")
    if a is not None and s is not None:
        m = a[a.status == "ok"].merge(s[s.status == "ok"][["profile", "workload", "engine", "achieved_ops_per_s", "bound",
                                                            "reason", "compute_utilisation"]],
                                      on=["profile", "workload", "engine"], how="left", suffixes=("", "_sim"))
        add("ANALYTICAL_CEILING vs EVENT_SIMULATED", "Architecture comparison table",
            "Per profile and workload: peak, analytical ceiling and its binding interface, simulated throughput and "
            "its bottleneck classification. Units: the engine's rate unit (MAC/s for the tensor engine, OPS/s otherwise).",
            raw=_table(m, ["profile", "workload", "engine", "rate_unit", "peak", "ceiling", "binding", "bound",
                           "achieved_ops_per_s", "compute_utilisation", "bound_sim", "reason"],
                       {"compute_utilisation": ".2f"}, 200))
    add("EVENT_SIMULATED", "Compute vs memory stall breakdown", "Fraction of makespan the engine computes, waits for "
        "operands, or waits for dependencies / drains.", stall_breakdown(run, profiles))
    r_db = _pick_run(run, "silicaflux_v", "gemm_64x64x64_double") or _pick_run(run, profiles[0], "gemm")
    r_rel = _pick_run(run, "silicaflux_v_release1_rtl", "gemm_64x64x64_double")
    r_dot = _pick_run(run, "silicaflux_v", "dot")
    if r_db:
        add("EVENT_SIMULATED", "SRAM bank utilisation heatmap", "Accesses per bank per time bucket divided by the "
            "bucket length (1.0 = the bank serves every cycle).", bank_heatmap(r_db))
        add("EVENT_SIMULATED", "Bandwidth utilisation timeline", "Bytes moved per interconnect channel per time "
            "bucket; dashed line: width x f of one channel.", bw_timeline(r_db))
        add("EVENT_SIMULATED", "Accelerator pipeline utilisation",
            "Load / compute / store intervals per tile (first 40 tiles). Release-1 RTL (CPU copies, no DMA) vs "
            "provisional profile (DMA, double buffering).", pipeline_gantt([x for x in (r_rel, r_db) if x]))
        if r_db.get("dma_bursts"):
            add("EVENT_SIMULATED", "DMA request timeline", "Each row is one burst: read (issue to data) then write "
                "(issue to acknowledgement).", dma_timeline(r_db))
    hist_runs = [x for x in (r_db, r_dot, _pick_run(run, "silicaflux_full", "cpu_random"),
                             _pick_run(run, "silicaflux_v_release1_rtl", "gemm_64x64x64_double"),
                             _pick_run(run, "silicaflux_full", "gemm_64x64x64_double"),
                             _pick_run(run, "silicaflux_v_release1_rtl", "cpu_seq")) if x]
    if hist_runs:
        add("EVENT_SIMULATED", "Latency distribution", "Interconnect transaction latency (queueing + service).",
            latency_hist(hist_runs))
    add("EVENT_SIMULATED (model configurations)", "Marginal-gain curves",
        "One factor at a time around the provisional SilicaFlux-V baseline; hover shows the bottleneck at each point.",
        marginal_curves(run))
    add("EVENT_SIMULATED + ANALYTICAL_CEILING", "Performance vs SRAM capacity",
        "Solid: simulated GEMM on the provisional SilicaFlux-V vs scratchpad or SRAM capacity (no external memory, so "
        "SRAM size is a feasibility limit). Dotted: analytical DRAM-interface ceiling vs SRAM size on the DRAM-backed "
        "full profile (16 KiB TSPM), the case where capacity changes reuse.", capacity_curves(run))
    add("EVENT_SIMULATED (model configurations)", "Performance vs vector/tensor size", "", size_curves(run))
    add("EVENT_SIMULATED (model configurations)", "Pareto frontier explorer",
        "Model-based Pareto front of simulated geomean speedup vs modelled area. Area per MAC/lane/bank/bus bit is "
        "HYPOTHETICAL; this is not a proof of physical-design optimality.", pareto_explorer(run))
    eq = _load(run, "rtl/bank_controller_equivalence.csv")
    if eq is not None:
        add("RTL_OBSERVED", "SRAM bank controller: Python model vs RTL",
            "Identical stimulus files executed by memorylab.bankbench and by the unmodified silicaflux-sramlib "
            "sram_bank_controller (Verilator; Icarus subset). Compared per transaction.",
            raw=_table(eq, ["case", "simulator", "workload", "params", "backpressure_pct", "requests", "accepts_rtl",
                            "conflicts_rtl", "responses_rtl", "data_compared", "equivalent"]))
    add("RTL_OBSERVED", "SilicaFlux-V engine latency: RTL vs model", "", tile_latency_fig(run))
    add("RTL_OBSERVED vs model", "DMA calibration against memoryflow sf_dma RTL",
        "Calibration target is memoryflow's DMA (SilicaFlux-V has no DMA). Calibrated parameters are stored separately "
        "in calibrated/.", dma_cal_fig(run))
    add("PROVENANCE", "Parameter provenance", "Plain YAML values without a source are HYPOTHETICAL.",
        provenance_bars(run, profiles))
    add("SILICON_MEASURED", "Silicon measurements", "",
        raw="<p class='note'>None. No SilicaFlux silicon exists; nothing in this report is a silicon measurement.</p>")
    git = prov.get("git", {})
    chips = [f"<span class='chip'><b>git</b> {html.escape(str(git.get('revision', 'n/a'))[:12])}"
             f"{' (dirty)' if git.get('dirty') else ''}</span>",
             f"<span class='chip'><b>simulator</b> {html.escape(str(prov.get('simulator_version', '')))}</span>",
             f"<span class='chip'><b>python</b> {html.escape(str(prov.get('environment', {}).get('python', '')))}</span>",
             f"<span class='chip'><b>seed</b> {prov.get('seed')}</span>",
             f"<span class='chip'><b>generated</b> {html.escape(str(prov.get('generated_utc', '')))}</span>"]
    chips += [f"<span class='chip'><b>{html.escape(k)}</b> {html.escape(str(v))}</span>" for k, v in rtl_status.items()]
    body = "".join(
        f"<section><div class='cat'>{html.escape(c)}</div><h2>{html.escape(t)}</h2>"
        f"{'<p class=note>' + html.escape(n) + '</p>' if n else ''}{h}</section>" for c, t, n, h in parts)
    page = (f"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' "
            f"content='width=device-width, initial-scale=1'><title>SilicaFlux MemoryLab</title>"
            f"<style>{CSS}</style><script src='plotly.min.js'></script></head><body><header>"
            f"<h1>SilicaFlux <span>MemoryLab</span></h1><p>Roofline, bandwidth, latency and memory-architecture "
            f"exploration. Result categories are never merged: ANALYTICAL_CEILING (upper bounds), EVENT_SIMULATED "
            f"(transaction-level model), RTL_OBSERVED (Verilator/Icarus runs of repository RTL), SILICON_MEASURED "
            f"(none).</p><div class='chips'>{''.join(chips)}</div></header><main>{body}</main></body></html>")
    out = run / "dashboard.html"
    out.write_text(page)
    (run / "plotly.min.js").write_text(get_plotlyjs())
    return out


# =========================================================================== PNGs + REPORT.md
def build_pngs(run: Path, profiles: list[str]) -> list[Path]:
    figs = run / "figures"
    out = []
    for pn in profiles:
        a = _load(run, f"analytical/{pn}.json")
        s = _load(run, f"simulated/{pn}.json") or {"runs": []}
        if not a:
            continue
        simres = {(r["workload"], r["engine"]): r for r in s["runs"]}
        for eng, prec in sorted({(r["engine"], r["precision"]) for r in a["results"] if r.get("status") == "ok"}):
            rs = [r for r in a["results"] if r.get("status") == "ok" and r["engine"] == eng and r["precision"] == prec]
            if not rs:
                continue
            obs = []
            for r in rs:
                sr = simres.get((r["workload"], eng))
                if sr:
                    bl = next((lv for lv in r["levels"] if lv["level"] == r["binding"]), r["levels"][-1])
                    obs.append({"workload": r["workload"], "intensity": bl["intensity"] or 1.0,
                                "achieved": max(sr["achieved_ops_per_s"], 1e-9), "category": "EVENT_SIMULATED"})
            out.append(plotting.roofline_png(rs, figs / f"roofline_{pn}_{eng}_{prec}.png",
                                             title=f"{pn} - {eng} engine, hierarchical Roofline ({prec})",
                                             observed=obs,
                                             footer="Rings: ANALYTICAL_CEILING per interface (thick = binding). Filled: "
                                                    "EVENT_SIMULATED. No silicon data exists."))
    mg = _load(run, "sweeps/architecture_sweep_marginal_gains.csv")
    df = _load(run, "sweeps/architecture_sweep.csv")
    if df is not None:
        base = df[df._vary == "baseline"]
        for knob, wl_prefix in (("vector_lanes", ("dot", "vector_add")), ("tensor_dim", ("gemm_64x64x64_double", "conv2d")),
                                ("bus_bits", ("dot", "gemm_64x64x64_double")), ("sram_banks", ("dot", "gemm_64x64x64_double")),
                                ("dma_outstanding", ("dot", "gemm_64x64x64_blocked"))):
            g = pd.concat([df[df._vary == knob], base])
            series, x = {}, None
            for pre in wl_prefix:
                gg = g[g.workload.str.startswith(pre)].dropna(subset=["sim_throughput_vs_baseline"]).sort_values(knob)
                if gg.empty:
                    continue
                x = list(gg[knob])
                series[gg.workload.iloc[0]] = list(gg["sim_throughput_vs_baseline"])
            if series and x:
                out.append(plotting.lines_png(x, series, figs / f"marginal_{knob}.png",
                                              title=f"Simulated throughput vs {knob} (OFAT, provisional SilicaFlux-V)",
                                              xlabel=knob, ylabel="throughput / baseline", logx=knob != "tensor_operand_ports",
                                              footer="EVENT_SIMULATED model configurations"))
    eqs = _load(run, "simulated/simulated_summary.csv")
    if eqs is not None:
        sub = eqs[(eqs.status == "ok") & (eqs.profile == "silicaflux_v") & eqs.engine.isin(["tensor", "vector"])]
        if not sub.empty:
            out.append(plotting.bar_png(list(sub.workload), list(sub.compute_utilisation.fillna(0)),
                                        figs / "compute_utilisation_silicaflux_v.png",
                                        title="Achieved / peak compute (provisional SilicaFlux-V)",
                                        xlabel="compute utilisation (EVENT_SIMULATED)", value_fmt="{:.0%}"))
    return out


def build_report_md(run: Path, profiles: list[str]) -> Path:
    prov = _load(run, "provenance.json") or {}
    a = _load(run, "analytical/analytical_summary.csv")
    s = _load(run, "simulated/simulated_summary.csv")
    st = _load(run, "rtl/status.json") or {}
    L = ["# SilicaFlux MemoryLab - run report", "",
         f"Generated {prov.get('generated_utc')} by {prov.get('simulator')} {prov.get('simulator_version')}; "
         f"git {prov.get('git', {}).get('revision')} (dirty={prov.get('git', {}).get('dirty')}); seed {prov.get('seed')}.",
         "", "Result categories are reported separately and never merged.", ""]

    def md(df: pd.DataFrame, cols: list[str]) -> list[str]:
        out = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
        for _, r in df.iterrows():
            vals = []
            for c in cols:
                v = r.get(c)
                vals.append("" if v is None or (isinstance(v, float) and v != v) else
                            (f"{v:.3g}" if isinstance(v, float) else str(v)))
            out.append("| " + " | ".join(vals) + " |")
        return out
    L += ["## ANALYTICAL CEILING", ""]
    if a is not None:
        L += md(a[a.status == "ok"], ["profile", "workload", "engine", "rate_unit", "peak", "ceiling", "binding", "bound",
                                      "unused_compute_fraction"])
    L += ["", "## EVENT-SIMULATED PERFORMANCE", ""]
    if s is not None:
        L += md(s[s.status == "ok"], ["profile", "workload", "engine", "achieved_ops_per_s", "compute_utilisation",
                                      "bound", "busiest_resource", "makespan_cycles"])
        bad = s[s.status != "ok"]
        if len(bad):
            L += ["", "Not simulated (with reason):", ""] + md(bad, ["profile", "workload", "engine", "status", "error"])
    L += ["", "## RTL-OBSERVED PERFORMANCE", ""] + [f"* **{k}**: {v}" for k, v in st.items()]
    L += ["", "## SILICON-MEASURED PERFORMANCE", "", "None. No silicon exists.", "", "## Known limitations", ""]
    L += [f"* {x}" for x in prov.get("limitations", [])]
    L += ["", "## Missing inputs", ""] + [f"* {x}" for x in prov.get("missing_inputs", [])]
    p = run / "REPORT.md"
    p.write_text("\n".join(L) + "\n")
    return p


def build_report(run: Path, profiles: list[str] | None = None) -> dict:
    run = Path(run)
    if not run.exists():
        raise FileNotFoundError(f"run directory not found: {run} (create it with 'memorylab all --out {run}')")
    profiles = profiles or sorted(p.stem for p in (run / "analytical").glob("*.json"))
    if not profiles:
        raise FileNotFoundError(f"{run}: no analytical/*.json results; run 'memorylab roofline' or 'memorylab all'")
    order = ["silicaflux_v_release1_rtl", "silicaflux_v", "silicaflux_130nm_demo", "silicaflux_65nm_demo", "silicaflux_full"]
    profiles = sorted(profiles, key=lambda x: order.index(x) if x in order else 99)
    pngs = build_pngs(run, profiles)
    dash = build_dashboard(run, profiles)
    md = build_report_md(run, profiles)
    return {"dashboard": str(dash), "report": str(md), "figures": [str(x) for x in pngs]}
