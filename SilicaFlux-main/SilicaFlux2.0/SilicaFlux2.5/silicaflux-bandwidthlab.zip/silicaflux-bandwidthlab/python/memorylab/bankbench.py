"""Deterministic stimulus for the cycle-level bank controller, shared with the RTL harness.

A stimulus is, per master, an ordered list of requests
    (not_before_cycle, we, word_addr, wdata, wmask, id)
Master m presents request i in the first cycle c >= not_before_cycle that is
strictly after the acceptance cycle of request i-1 (the valid/ready rule of
the sramlib handshake: valid held until accepted, at most one per cycle).
Response backpressure is a pure function rsp_ready(m, c) of (seed, pct, m, c),
implemented identically in Python and in rtl_harness/tb_memorylab_bank_trace.sv.

Traffic classes mirror tb_sram_banking.sv (+wl=): cpu (sequential, gaps, 30 % writes),
vector (unit stride, back-to-back), tensor (8x8 tile loads from a 64-word-wide matrix),
dma (64-word bursts alternating read/write), mixed (one of each), stride (stride = banks),
random (uniform).  Streams are generated with numpy's PCG64 from the seed, so they are
NOT the same random draws as the SV testbench's xorshift; equivalence is established by
feeding the identical stimulus file to both implementations.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np

from .event_engine import PRIO_ISSUE, ClockDomain, EventEngine, Trace, Transaction
from .sram import BankController, BankCtrlConfig

WORKLOADS = ("random", "cpu", "vector", "tensor", "dma", "mixed", "stride")


@dataclass(frozen=True)
class Req:
    nb: int          # not-before cycle
    we: int
    addr: int        # word address (or out-of-range for error requests)
    data: int
    mask: int
    rid: int


def backpressure_ready(seed: int, pct: int, m: int, c: int) -> bool:
    """Deterministic 32-bit hash; identical to bp_ready() in the SV harness."""
    if pct <= 0:
        return True
    h = (c * 2654435761 + m * 40503 + seed * 97 + 12345) & 0xFFFFFFFF
    h ^= h >> 15
    h = (h * 2246822519) & 0xFFFFFFFF
    h ^= h >> 13
    return (h % 100) >= pct


def generate(workload: str, cfg: BankCtrlConfig, n_per_master: int, seed: int, err_pct: int = 0) -> list[list[Req]]:
    if workload not in WORKLOADS:
        raise ValueError(f"unknown bank workload {workload!r}; one of {WORKLOADS}")
    rng = np.random.Generator(np.random.PCG64(seed))
    nm, total = cfg.num_masters, cfg.total_words
    dmask = (1 << cfg.data_width) - 1
    fullm = (1 << cfg.mask_width) - 1
    out: list[list[Req]] = []
    for m in range(nm):
        kind = {0: "cpu", 1: "vector", 2: "tensor"}.get(m, "dma") if workload == "mixed" else workload
        base = (m * total) // nm
        reqs: list[Req] = []
        c = 0
        ptr = 0
        burst_left, burst_wr = 0, 1
        tr = tc = 0
        for i in range(n_per_master):
            gap = 0
            if kind == "random":
                gap = int(rng.integers(0, 2))
                we = int(rng.random() < 0.4)
                w = int(rng.integers(0, total))
            elif kind == "cpu":
                gap = int(rng.geometric(0.6)) - 1
                we = int(rng.random() < 0.3)
                w = (base + ptr) % total
                ptr += 1
            elif kind == "vector":
                we = (ptr // 256) % 2
                w = (base + ptr) % total
                ptr += 1
            elif kind == "tensor":
                we = 0
                w = (base + tr * 64 + tc) % total
                tc += 1
                if tc == 8:
                    tc = 0
                    tr = (tr + 1) % 8
            elif kind == "dma":
                if burst_left == 0:
                    burst_left, burst_wr, ptr = 64, 1 - burst_wr, int(rng.integers(0, total))
                we = burst_wr
                w = ptr % total
                ptr += 1
                burst_left -= 1
            else:  # stride by number of banks: every request maps to one bank
                we = int(rng.random() < 0.2)
                w = (ptr * cfg.num_banks) % total
                ptr += 1
            if err_pct and rng.random() * 100 < err_pct:
                w = total + int(rng.integers(0, total))
            c += gap
            data = int(rng.integers(0, 1 << 62)) & dmask
            mask = fullm if rng.random() < 0.6 else int(rng.integers(0, fullm + 1))
            reqs.append(Req(c, we, w, data, mask, (m << 8 | (i & 0xFF)) & 0xFFFF))
            c += 1
        out.append(reqs)
    return out


def run(cfg: BankCtrlConfig, stim: Sequence[Sequence[Req]], *, bp_pct: int = 0, seed: int = 1,
        trace: bool = False, freq_hz: float = 100e6, start_cycle: int = 1) -> dict:
    """Run a stimulus on the cycle-level controller; returns stats and the transaction log."""
    eng = EventEngine()
    clk = ClockDomain("clk", freq_hz)
    tr = Trace(enabled=trace)
    nm = cfg.num_masters
    if len(stim) != nm:
        raise ValueError(f"stimulus has {len(stim)} masters, controller has {nm}")
    nxt = [0] * nm
    rsp_log: list[tuple[int, int, int, int, int, int]] = []   # cycle, master, id, data, err, we
    acc_log: list[tuple[int, int, int]] = []                  # cycle, master, id
    known_log: dict[tuple[int, int, int], int] = {}

    ctrl: BankController

    def present(m: int) -> None:
        i = nxt[m]
        if i >= len(stim[m]):
            return
        r = stim[m][i]
        t = Transaction(eng.new_id(), f"m{m}", "W" if r.we else "R", r.addr << ctrl.boff, cfg.data_width // 8,
                        eng.now, data=r.data, mask=r.mask, tag=r.rid)
        ctrl.present(m, t)

    def schedule_next(m: int, after_cycle: int | None) -> None:
        i = nxt[m]
        if i >= len(stim[m]):
            return
        nb = stim[m][i].nb + start_cycle
        earliest = nb if after_cycle is None else max(nb, after_cycle + 1)
        if after_cycle is not None and earliest == after_cycle + 1:
            present(m)                      # reaction at the acceptance edge -> eligible next edge
        else:
            eng.schedule_at(clk.edge(earliest), lambda m=m: present(m), PRIO_ISSUE, f"m{m}.present")

    def on_accept(m: int, t: Transaction, cyc: int) -> None:
        acc_log.append((cyc - start_cycle, m, t.tag if not isinstance(t.tag, tuple) else t.tag[0]))
        nxt[m] += 1
        schedule_next(m, cyc)

    def on_response(m: int, t: Transaction, cyc: int) -> None:
        rid, known = t.tag if isinstance(t.tag, tuple) else (t.tag, -1)
        rsp_log.append((cyc - start_cycle, m, rid, t.data or 0, int(t.error), int(t.op == "W")))
        known_log[(m, rid, cyc - start_cycle)] = known

    ctrl = BankController(eng, clk, cfg, trace=tr,
                          rsp_ready=lambda m, c: backpressure_ready(seed, bp_pct, m, c - start_cycle),
                          on_accept=on_accept, on_response=on_response)
    for m in range(nm):
        schedule_next(m, None)
    rs = eng.run()
    st = ctrl.stats()
    acc_log.sort()
    rsp_log.sort()
    conf_log = sorted((c - start_cycle, m) for c, ev, m, _, _ in ctrl.log if ev == "CONF")
    return {"stats": st, "accepts": acc_log, "responses": rsp_log, "conflicts": conf_log, "known": known_log,
            "events": rs.events, "trace": tr, "controller": ctrl}


def write_stimulus(path: str | Path, cfg: BankCtrlConfig, stim: Sequence[Sequence[Req]]) -> Path:
    """Text stimulus for $fscanf in the SV harness: header then one request per line."""
    p = Path(path)
    lines = [f"{cfg.num_masters} {max(len(s) for s in stim)}"]
    for m, reqs in enumerate(stim):
        lines.append(f"M {m} {len(reqs)}")
        for r in reqs:
            lines.append(f"{r.nb} {r.we} {r.addr:x} {r.data:x} {r.mask:x} {r.rid:x}")
    p.write_text("\n".join(lines) + "\n")
    return p


def metrics(res: dict, cfg: BankCtrlConfig) -> dict:
    st = res["stats"]
    return {"words_per_cycle": st["words_per_cycle"], "conflict_rate": st["conflict_rate"],
            "avg_latency_cycles": st["avg_latency_cycles"], "max_latency_cycles": st["max_latency_cycles"],
            "bytes_per_cycle": st["words_per_cycle"] * cfg.data_width / 8, "cycles": st["cycles"],
            "accepted": st["accepted"]}
