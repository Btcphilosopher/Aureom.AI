"""DMA engine: descriptor queue per channel, burst split, bounded outstanding bursts.

A descriptor {src, src_addr, dst, dst_addr, length} is split into bursts of
``burst_bytes``.  Per channel, after ``setup_cycles`` the engine issues read bursts
at most one every ``issue_interval_cycles`` while fewer than ``max_outstanding`` reads
are in flight; when a read completes its data is written to the destination as soon
as fewer than ``max_write_outstanding`` writes are awaiting acknowledgement (reads and
writes are decoupled by the engine's data FIFO, as in memoryflow's sf_dma).  Both go
through the interconnect, so they contend with every other master.
Channels share the engine's interconnect master ports in round-robin burst order.
The descriptor completes when its last write has been acknowledged.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Callable

import numpy as np

from .event_engine import PRIO_ISSUE, ClockDomain, EventEngine, Trace, Transaction


@dataclass
class Descriptor:
    src: str
    src_addr: int
    dst: str
    dst_addr: int
    length: int
    on_done: Callable[["Descriptor"], None] | None = None
    did: int = 0
    t_submit: int = 0
    t_start: int | None = None
    t_done: int | None = None
    issued: int = 0
    written: int = 0
    inflight: int = 0
    rd_inflight: int = 0
    label: str = ""

    def __post_init__(self) -> None:
        if self.length <= 0:
            raise ValueError("DMA descriptor length must be > 0 bytes")


class Dma:
    def __init__(self, eng: EventEngine, clock: ClockDomain, ic, *, name: str = "dma", channels: int = 1,
                 burst_bytes: int = 64, max_outstanding: int = 4, queue_depth: int = 4, setup_cycles: int = 4,
                 issue_interval_cycles: int = 1, max_write_outstanding: int | None = None,
                 trace: Trace | None = None) -> None:
        if channels < 1 or burst_bytes < 1 or max_outstanding < 1 or queue_depth < 1 or setup_cycles < 0 \
                or issue_interval_cycles < 1:
            raise ValueError(f"{name}: invalid DMA parameters")
        self.issue_interval = issue_interval_cycles
        self.max_wr = max_write_outstanding or max_outstanding
        self.wr_inflight = 0
        self.wr_wait: deque = deque()
        self.next_issue = [0] * channels
        self.eng, self.clock, self.ic, self.name = eng, clock, ic, name
        self.channels, self.burst, self.max_out, self.qdepth, self.setup = \
            channels, burst_bytes, max_outstanding, queue_depth, setup_cycles
        self.queues: list[deque[Descriptor]] = [deque() for _ in range(channels)]
        self.active: list[Descriptor | None] = [None] * channels
        self.ready_at = [0] * channels
        self.trace = trace or Trace(enabled=False)
        self.port_r = f"{name}.rd"
        self.port_w = f"{name}.wr"
        ic.add_master(self.port_r)
        ic.add_master(self.port_w)
        self.bursts: list[tuple] = []          # (desc, ch, issue, read_done, write_done, bytes) timeline
        self.done: list[Descriptor] = []
        self.bytes = 0
        self.outstanding_limit_events = 0
        self._ids = 0
        self._pump_at: set[int] = set()
        eng.register(self)

    def outstanding(self) -> int:
        return sum(len(q) for q in self.queues) + sum(1 for a in self.active if a is not None) + len(self.wr_wait)

    def can_submit(self, ch: int = 0) -> bool:
        return len(self.queues[ch]) < self.qdepth

    def submit(self, d: Descriptor, ch: int = 0) -> bool:
        if not 0 <= ch < self.channels:
            raise IndexError(f"{self.name}: channel {ch}")
        if len(self.queues[ch]) >= self.qdepth:
            return False
        self._ids += 1
        d.did = self._ids
        d.t_submit = self.eng.now
        self.queues[ch].append(d)
        self._pump(ch)
        return True

    def _pump(self, ch: int, at: int | None = None) -> None:
        t = self.clock.next_edge(self.eng.now if at is None else at)
        key = t * 64 + ch
        if key in self._pump_at:
            return
        self._pump_at.add(key)
        self.eng.schedule_at(t, lambda: (self._pump_at.discard(key), self._step(ch)), PRIO_ISSUE, f"{self.name}.pump")

    def _step(self, ch: int) -> None:
        d = self.active[ch]
        if d is None:
            if not self.queues[ch]:
                return
            d = self.queues[ch].popleft()
            self.active[ch] = d
            d.t_start = self.eng.now
            self.ready_at[ch] = self.eng.now + self.clock.cycles(self.setup)
            self.trace.log(self.eng.now, "SERVICE_START", self.name, None, desc=d.did, ch=ch)
        if self.eng.now < self.ready_at[ch]:
            self._pump(ch, self.ready_at[ch])
            return
        while d.issued < d.length and d.rd_inflight < self.max_out:
            if self.eng.now < self.next_issue[ch]:
                self._pump(ch, self.next_issue[ch])
                return
            n = min(self.burst, d.length - d.issued)
            off = d.issued
            rd = Transaction(self.eng.new_id(), self.name, "R", d.src_addr + off, n, self.eng.now, tag=("dma", d.did))
            if not self.ic.request(self.port_r, rd, d.src, lambda t, d=d, off=off, n=n, ch=ch, t0=self.eng.now:
                                   self._read_done(d, off, n, ch, t0)):
                self._pump(ch, self.eng.now + self.clock.period_fs)
                return
            d.issued += n
            d.inflight += 1
            d.rd_inflight += 1
            self.next_issue[ch] = self.eng.now + self.clock.cycles(self.issue_interval)
        if d.issued < d.length and d.rd_inflight >= self.max_out:
            self.outstanding_limit_events += 1

    def _read_done(self, d: Descriptor, off: int, n: int, ch: int, t0: int) -> None:
        d.rd_inflight -= 1
        t_r = self.eng.now
        wr = Transaction(self.eng.new_id(), self.name, "W", d.dst_addr + off, n, self.eng.now, tag=("dma", d.did))
        self.wr_wait.append((wr, d, n, ch, t0, t_r))
        self._drain_writes()
        self._pump(ch)

    def _drain_writes(self) -> None:
        while self.wr_wait and self.wr_inflight < self.max_wr:
            wr, d, n, ch, t0, t_r = self.wr_wait[0]
            if not self.ic.request(self.port_w, wr, d.dst, lambda t, d=d, n=n, ch=ch, t0=t0, t_r=t_r:
                                   self._write_done(d, n, ch, t0, t_r)):
                self.eng.schedule(self.clock.period_fs, self._drain_writes, PRIO_ISSUE, f"{self.name}.wretry")
                return
            self.wr_wait.popleft()
            self.wr_inflight += 1

    def _write_done(self, d: Descriptor, n: int, ch: int, t0: int, t_r: int) -> None:
        self.wr_inflight -= 1
        self._drain_writes()
        d.inflight -= 1
        d.written += n
        self.bytes += n
        self.bursts.append((d.did, ch, t0, t_r, self.eng.now, n, d.label))
        if d.written == d.length:
            d.t_done = self.eng.now
            self.active[ch] = None
            self.done.append(d)
            self.trace.log(self.eng.now, "COMPLETE", self.name, None, desc=d.did, ch=ch)
            if d.on_done:
                d.on_done(d)
        self._pump(ch)

    def stats(self, span_fs: int) -> dict:
        span = max(1, span_fs)
        busy = 0
        iv = sorted((b[2], b[4]) for b in self.bursts)
        cur_s = cur_e = None
        for s, e in iv:                          # union of burst lifetimes = engine-busy time
            if cur_e is None or s > cur_e:
                if cur_e is not None:
                    busy += cur_e - cur_s
                cur_s, cur_e = s, e
            else:
                cur_e = max(cur_e, e)
        if cur_e is not None:
            busy += cur_e - cur_s
        lat = np.array([(d.t_done - d.t_submit) for d in self.done]) / self.clock.period_fs if self.done else np.array([0.0])
        return {"name": self.name, "descriptors": len(self.done), "bytes": self.bytes,
                "Bps": self.bytes / (span / 1e15), "busy_fraction": busy / span,
                "avg_descriptor_latency_cycles": float(lat.mean()), "bursts": len(self.bursts),
                "outstanding_limit_events": self.outstanding_limit_events}
