"""Transaction-level interconnect: crossbar (one port per target) or shared bus.

Each target port has two independent channels, as in the SFB / valid-ready buses
of the repository: a request channel (address phase + write data) and a response
channel (read data).  A transaction holds:
  request channel   overhead_cycles + (write ? beats : 0)
  target            its own access time (SRAM / DRAM / cache model)
  response channel  read ? beats : 1 cycle (write acknowledgement)
with beats = ceil(size / width).  The data rate of each channel can therefore
never exceed width x f, which the tests check from the recorded occupancy.

Arbitration happens whenever a channel is free: round robin (pointer -> granted+1)
or fixed priority (declaration order) among masters whose head request targets the
port and who are below their outstanding limit.  A full per-master queue or a target
that refuses (queue full) back-pressures the master / holds the channel.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
import math
from typing import Any, Callable, Protocol

import numpy as np

from .event_engine import PRIO_COMPLETE, PRIO_TICK, ClockDomain, EventEngine, Trace, Transaction


class Target(Protocol):
    name: str

    def access(self, txn: Transaction, on_done: Callable[[Transaction], None], **kw: Any) -> bool: ...


@dataclass
class _Pending:
    txn: Transaction
    target: str
    on_done: Callable[[Transaction], None]
    t_enq: int
    master: str
    t_fwd: int = 0


@dataclass
class MasterStats:
    txns: int = 0
    bytes: int = 0
    wait_fs: int = 0                 # enqueue -> request-channel grant
    latency_fs: list[int] = field(default_factory=list)
    rejects: int = 0
    outstanding_limit_cycles: int = 0


class Channel:
    def __init__(self, name: str) -> None:
        self.name = name
        self.busy_until = 0          # fs
        self.busy_fs = 0
        self.bytes = 0
        self.intervals: list[tuple[int, int, int]] = []    # (start, end, bytes) for timelines


class Interconnect:
    def __init__(self, eng: EventEngine, clock: ClockDomain, *, name: str = "xbar", width_bytes: int,
                 overhead_cycles: int = 1, arbitration: str = "rr", max_outstanding_per_master: int = 1,
                 queue_depth: int = 4, topology: str = "crossbar", trace: Trace | None = None,
                 record_intervals: bool = True) -> None:
        if width_bytes < 1 or overhead_cycles < 0 or max_outstanding_per_master < 1 or queue_depth < 1:
            raise ValueError(f"{name}: width >= 1 B, overhead >= 0, outstanding >= 1, queue >= 1")
        if arbitration not in ("rr", "fixed") or topology not in ("crossbar", "bus"):
            raise ValueError(f"{name}: arbitration rr|fixed, topology crossbar|bus")
        self.eng, self.clock, self.name = eng, clock, name
        self.width, self.overhead = width_bytes, overhead_cycles
        self.arb, self.max_out, self.qdepth, self.topology = arbitration, max_outstanding_per_master, queue_depth, topology
        self.trace = trace or Trace(enabled=False)
        self.record = record_intervals
        self.targets: dict[str, Target] = {}
        self.target_kw: dict[str, dict] = {}
        self.masters: list[str] = []
        self.queues: dict[str, deque[_Pending]] = {}
        self.inflight: dict[str, int] = {}
        self.mstats: dict[str, MasterStats] = {}
        self.req_ch: dict[str, Channel] = {}
        self.rsp_ch: dict[str, Channel] = {}
        self.rr_ptr: dict[str, int] = {}
        self._kick_at: set[tuple[str, int]] = set()
        self._retry: dict[str, _Pending | None] = {}
        eng.register(self)

    # ------------------------------------------------------------------ topology
    def port_of(self, target: str) -> str:
        return "bus" if self.topology == "bus" else target

    def connect(self, name: str, target: Target, **access_kw: Any) -> None:
        self.targets[name] = target
        self.target_kw[name] = access_kw
        port = self.port_of(name)
        if port not in self.req_ch:
            self.req_ch[port] = Channel(f"{self.name}.{port}.req")
            self.rsp_ch[port] = Channel(f"{self.name}.{port}.rsp")
            self.rr_ptr[port] = 0
            self._retry[port] = None

    def add_master(self, name: str) -> None:
        if name in self.queues:
            return
        self.masters.append(name)
        self.queues[name] = deque()
        self.inflight[name] = 0
        self.mstats[name] = MasterStats()

    def outstanding_total(self) -> int:
        return sum(self.inflight.values()) + sum(len(q) for q in self.queues.values())

    def outstanding(self) -> int:
        """Deadlock-detection protocol: queued + in-flight transactions."""
        return self.outstanding_total()

    # ------------------------------------------------------------------ request API
    def can_accept(self, master: str) -> bool:
        return len(self.queues[master]) < self.qdepth

    def request(self, master: str, txn: Transaction, target: str, on_done: Callable[[Transaction], None]) -> bool:
        """Enqueue; False = master queue full (backpressure, caller retries)."""
        if master not in self.queues:
            self.add_master(master)
        if target not in self.targets:
            raise KeyError(f"{self.name}: no target {target!r}")
        if len(self.queues[master]) >= self.qdepth:
            self.mstats[master].rejects += 1
            self.trace.log(self.eng.now, "BACKPRESSURE", self.name, txn)
            return False
        txn.t_issued = self.eng.now if txn.t_issued is None else txn.t_issued
        txn.path.append(self.name)
        self.queues[master].append(_Pending(txn, target, on_done, self.eng.now, master))
        self.trace.log(self.eng.now, "ISSUE", self.name, txn, target=target)
        self._kick(self.port_of(target))
        return True

    # ------------------------------------------------------------------ arbitration
    def _kick(self, port: str, at: int | None = None) -> None:
        t = self.clock.next_edge(self.eng.now if at is None else at)
        if (port, t) in self._kick_at:
            return
        self._kick_at.add((port, t))
        self.eng.schedule_at(t, lambda p=port, tt=t: self._arbitrate(p, tt), PRIO_TICK, f"{self.name}.{port}.arb")

    def _candidates(self, port: str) -> list[str]:
        out = []
        for m in self.masters:
            q = self.queues[m]
            if q and self.port_of(q[0].target) == port:
                if self.inflight[m] < self.max_out:
                    out.append(m)
                else:
                    self.mstats[m].outstanding_limit_cycles += 1
        return out

    def _arbitrate(self, port: str, t: int) -> None:
        self._kick_at.discard((port, t))
        ch = self.req_ch[port]
        if ch.busy_until > self.eng.now:
            self._kick(port, ch.busy_until)
            return
        if self._retry[port] is not None:            # target refused last time: channel held
            self._forward(port, self._retry[port])
            return
        cands = self._candidates(port)
        if not cands:
            return
        if self.arb == "fixed":
            m = cands[0]
        else:
            n = len(self.masters)
            start = self.rr_ptr[port]
            order = [self.masters[(start + k) % n] for k in range(n)]
            m = next(x for x in order if x in cands)
            self.rr_ptr[port] = (self.masters.index(m) + 1) % n
        p = self.queues[m].popleft()
        self.inflight[m] += 1
        txn = p.txn
        beats = math.ceil(txn.size / self.width)
        # address phase; on writes the first data beat travels with the address (SFB / valid-ready)
        occ_cycles = self.overhead + (beats - (1 if self.overhead else 0) if txn.op == "W" else 0)
        occ_cycles = max(1, occ_cycles)
        start, end = self.eng.now, self.eng.now + self.clock.cycles(occ_cycles)
        ch.busy_until = end
        ch.busy_fs += end - start
        if txn.op == "W":
            ch.bytes += txn.size
            if self.record:
                ch.intervals.append((start, end, txn.size))
        st = self.mstats[m]
        st.wait_fs += start - p.t_enq
        txn.t_accepted = start if txn.t_accepted is None else txn.t_accepted
        self.trace.log(start, "ACCEPT", self.name, txn, port=port, master_q=m)
        self.eng.schedule_at(end, lambda: self._forward(port, p), PRIO_COMPLETE, f"{self.name}.fwd")
        self._kick(port, end)

    def _forward(self, port: str, p: _Pending) -> None:
        p.t_fwd = self.eng.now
        tgt = self.targets[p.target]
        ok = tgt.access(p.txn, lambda txn, p=p: self._target_done(port, p), **self.target_kw[p.target])
        if ok:
            self._retry[port] = None
            self._kick(port)
        else:                                          # target backpressure: hold request channel
            self._retry[port] = p
            self.req_ch[port].busy_fs += self.clock.period_fs
            self.req_ch[port].busy_until = self.eng.now + self.clock.period_fs
            self._kick(port, self.eng.now + self.clock.period_fs)

    def _target_done(self, port: str, p: _Pending) -> None:
        ch = self.rsp_ch[port]
        txn = p.txn
        beats = math.ceil(txn.size / self.width) if txn.op == "R" else 1
        # cut-through: the last beat cannot leave before the target's data is complete, the first
        # beat overlaps the cycle in which the target's first data is valid; the channel stays
        # strictly serialised, so its rate never exceeds width x f
        now_e = self.clock.next_edge(self.eng.now)
        P = self.clock.period_fs
        start = max(now_e - beats * P, ch.busy_until, p.t_fwd)
        end = start + beats * P
        ch.busy_until = end
        ch.busy_fs += end - start
        if txn.op == "R":
            ch.bytes += txn.size
            if self.record:
                ch.intervals.append((start, end, txn.size))

        def complete() -> None:
            self.inflight[p.master] -= 1
            st = self.mstats[p.master]
            st.txns += 1
            st.bytes += txn.size
            st.latency_fs.append(self.eng.now - p.t_enq)
            self.trace.log(self.eng.now, "RESPONSE", self.name, txn)
            p.on_done(txn)
            self._kick(port)
            # the master dropped below its outstanding limit: its next request may target another port
            q = self.queues[p.master]
            if q:
                self._kick(self.port_of(q[0].target))
        self.eng.schedule_at(end, complete, PRIO_COMPLETE, f"{self.name}.rsp")

    # ------------------------------------------------------------------ statistics
    def stats(self, span_fs: int) -> dict:
        span = max(1, span_fs)
        ports = {}
        for port in self.req_ch:
            ports[port] = {
                "req_busy_fraction": self.req_ch[port].busy_fs / span,
                "rsp_busy_fraction": self.rsp_ch[port].busy_fs / span,
                "write_bytes": self.req_ch[port].bytes, "read_bytes": self.rsp_ch[port].bytes,
                "write_Bps": self.req_ch[port].bytes / (span / 1e15), "read_Bps": self.rsp_ch[port].bytes / (span / 1e15),
                "peak_Bps_per_direction": self.width * self.clock.freq_hz,
            }
        masters = {}
        for m, st in self.mstats.items():
            lat = np.array(st.latency_fs) / self.clock.period_fs if st.latency_fs else np.array([0.0])
            masters[m] = {"txns": st.txns, "bytes": st.bytes, "Bps": st.bytes / (span / 1e15),
                          "avg_wait_cycles": (st.wait_fs / max(1, st.txns)) / self.clock.period_fs,
                          "avg_latency_cycles": float(lat.mean()), "p95_latency_cycles": float(np.percentile(lat, 95)),
                          "p99_latency_cycles": float(np.percentile(lat, 99)), "rejects": st.rejects,
                          "outstanding_limit_events": st.outstanding_limit_cycles}
        util = max([max(v["req_busy_fraction"], v["rsp_busy_fraction"]) for v in ports.values()] or [0.0])
        return {"name": self.name, "topology": self.topology, "width_bytes": self.width, "ports": ports,
                "masters": masters, "max_channel_utilisation": util}

    def all_latencies_cycles(self) -> np.ndarray:
        xs = [x for st in self.mstats.values() for x in st.latency_fs]
        return np.array(xs) / self.clock.period_fs if xs else np.array([])
