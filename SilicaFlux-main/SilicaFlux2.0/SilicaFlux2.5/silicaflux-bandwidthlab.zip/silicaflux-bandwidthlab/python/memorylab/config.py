"""Configuration schema (Pydantic v2) and model construction from YAML profiles.

Every numeric leaf may be written either as a plain value or as
``{value: ..., provenance: VERIFIED_REPO|RTL_SIMULATED|EXTERNAL_MEASURED|HYPOTHETICAL,
source: "path:line or reference"}``.  A plain value is HYPOTHETICAL: nothing is
treated as verified unless a source says so.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from .provenance import Provenance, combine
from .units import Precision, parse_size


class ConfigError(ValueError):
    """Invalid or inconsistent configuration (message names the offending field)."""


_NUM = re.compile(r"^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$")


def coerce_number(v: Any) -> Any:
    """YAML 1.1 (PyYAML) reads '200.0e6' as a string; accept it as a number."""
    if isinstance(v, str) and _NUM.match(v.strip()):
        f = float(v)
        return int(f) if f.is_integer() and "." not in v and "e" not in v.lower() else f
    return v


class Sourced(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    value: Any
    provenance: Provenance = Provenance.HYPOTHETICAL
    source: str = ""

    @model_validator(mode="before")
    @classmethod
    def _wrap(cls, data: Any) -> Any:
        if isinstance(data, dict) and "value" in data:
            return {**data, "value": coerce_number(data["value"])}
        return {"value": coerce_number(data)}

    @property
    def v(self) -> Any:
        return self.value


def S(x: Any) -> Sourced:
    return x if isinstance(x, Sourced) else Sourced(value=x)


class _M(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ClockCfg(_M):
    frequency_hz: Sourced


class CpuCfg(_M):
    enabled: bool = True
    cores: Sourced = S(1)
    xlen: Sourced = S(32)
    issue_width: Sourced = S(1)
    cpi: dict[str, Sourced] = Field(default_factory=lambda: {"alu": S(1)})
    has_hw_mul: Sourced = S(False)
    has_fpu: Sourced = S(False)
    utilisation: Sourced = S(1.0)
    max_outstanding_loads: Sourced = S(1)
    load_bytes: Sourced = S(4)


class VectorCfg(_M):
    enabled: bool = True
    lanes: Sourced
    element_bits: Sourced = S(32)
    elems_per_lane_per_cycle: Sourced = S(1.0)
    issue_per_cycle: Sourced = S(1.0)
    macs_per_lane_per_cycle: Sourced = S(1.0)
    ldst_bytes_per_cycle: Sourced | None = None        # default: lanes * element bytes (one row/cycle)
    fixed_overhead_cycles: Sourced = S(3)
    zero_length_cycles: Sourced = S(2)
    wres_cycles: Sourced = S(1)
    dependency_stall_cycles_per_beat: Sourced = S(0.0)
    conflict_stall_cycles_per_beat: Sourced = S(0.0)
    precisions: list[str] = Field(default_factory=lambda: ["int32"])


class TensorCfg(_M):
    enabled: bool = True
    rows: Sourced
    cols: Sourced
    depth: Sourced = S(1)
    macs_per_pe_per_cycle: dict[str, Sourced] = Field(default_factory=lambda: {"int8": S(1.0), "uint8": S(1.0)})
    acc_bits: Sourced = S(32)
    operand_bytes_per_cycle: Sourced
    writeback_bytes_per_cycle: Sourced = S(16)
    fixed_overhead_cycles: Sourced = S(3)
    fill_cycles: Sourced = S(0)
    drain_cycles: Sourced = S(0)
    max_k: Sourced = S(1024)


MemKind = Literal["scratchpad", "sram", "cache", "dram"]


class MemoryCfg(_M):
    name: str
    kind: MemKind
    capacity: Sourced | None = None            # bytes or '256KiB'
    banks: Sourced = S(1)
    width_bits: Sourced = S(32)
    read_latency_cycles: Sourced = S(1)
    write_latency_cycles: Sourced = S(1)       # acceptance-to-architectural-completion
    ports: Literal["1RW", "1R1W", "2RW"] = "1RW"
    interleave: Literal["low", "high", "xor"] = "low"
    arbitration: Literal["rr", "fixed"] = "rr"
    rsp_fifo_depth: Sourced | None = None      # default read_latency + 1 (sramlib)
    write_ack: bool = True
    queue_depth: Sourced = S(0)                # per-bank request queue; 0 = RTL-style direct handshake
    clock_hz: Sourced | None = None            # default: system clock
    # cache
    line_bytes: Sourced = S(64)
    ways: Sourced = S(4)
    replacement: Literal["lru", "plru", "fifo", "random"] = "lru"
    write_policy: Literal["write_back", "write_through"] = "write_back"
    mshrs: Sourced = S(1)
    hit_latency_cycles: Sourced = S(1)
    # dram
    channels: Sourced = S(1)
    bus_width_bits: Sourced = S(16)
    data_rate_mtps: Sourced = S(1600)
    read_latency_ns: Sourced = S(50.0)
    write_latency_ns: Sourced = S(30.0)
    burst_bytes: Sourced = S(32)
    dram_banks: Sourced = S(8)
    row_bytes: Sourced = S(2048)
    row_hit_ns: Sourced = S(15.0)
    row_miss_ns: Sourced = S(45.0)
    model_rows: bool = False
    enabled: bool = True
    base_addr: Sourced | None = None           # default: assigned by the system builder
    downstream: str | None = None              # cache: the memory it caches

    @property
    def capacity_bytes(self) -> int | None:
        return None if self.capacity is None else parse_size(self.capacity.v)

    @property
    def width_bytes(self) -> int:
        return int(self.width_bits.v) // 8


class InterconnectCfg(_M):
    width_bits: Sourced
    topology: Literal["crossbar", "bus"] = "crossbar"
    clock_hz: Sourced | None = None
    overhead_cycles: Sourced = S(1)            # per transaction (address/arbitration phase)
    arbitration: Literal["rr", "fixed"] = "rr"
    max_outstanding_per_master: Sourced = S(1)
    queue_depth: Sourced = S(4)

    @property
    def width_bytes(self) -> int:
        return int(self.width_bits.v) // 8


class DmaCfg(_M):
    enabled: bool = True
    channels: Sourced = S(1)
    burst_bytes: Sourced = S(64)
    max_outstanding: Sourced = S(4)
    queue_depth: Sourced = S(4)
    setup_cycles: Sourced = S(4)
    issue_interval_cycles: Sourced = S(1)          # min cycles between successive read-burst issues
    max_write_outstanding: Sourced | None = None   # default = max_outstanding
    double_buffering: bool = True


LimitName = Literal["engine_port", "interconnect", "dma", "cpu_copy", "memory"]


class LevelLimit(_M):
    via: LimitName
    memory: str | None = None


class RooflineLevelCfg(_M):
    name: str
    capacity_of: list[str] = Field(default_factory=list)   # memories whose capacity is inside this interface
    limits: list[LevelLimit] = Field(default_factory=list)
    bandwidth_Bps: Sourced | None = None                   # explicit override
    latency_cycles: Sourced | None = None                  # for Little's law
    max_inflight_bytes: Sourced | None = None
    port: bool = False                                     # engine operand port (traffic from engine model)


class AreaCfg(_M):
    sram_mm2_per_kib: Sourced = S(0.0307)
    logic_fixed_mm2: Sourced = S(0.5)
    mm2_per_mac: Sourced = S(0.004)
    mm2_per_vector_lane: Sourced = S(0.02)
    mm2_per_bank: Sourced = S(0.01)
    mm2_per_bus_bit: Sourced = S(0.0005)
    mm2_per_dma_outstanding: Sourced = S(0.002)
    mm2_per_core: Sourced = S(0.08)


class Profile(_M):
    schema_version: Literal[1] = 1
    name: str
    description: str = ""
    status: str = "provisional"
    clock: ClockCfg
    cpu: CpuCfg = Field(default_factory=CpuCfg)
    vector: VectorCfg | None = None
    tensor: TensorCfg | None = None
    memories: list[MemoryCfg]
    interconnect: InterconnectCfg
    dma: DmaCfg | None = None
    roofline: dict[str, list[RooflineLevelCfg]] = Field(default_factory=dict)
    area: AreaCfg = Field(default_factory=AreaCfg)
    notes: list[str] = Field(default_factory=list)
    calibrated_from: str | None = None

    @field_validator("memories")
    @classmethod
    def _unique(cls, v: list[MemoryCfg]) -> list[MemoryCfg]:
        names = [m.name for m in v]
        if len(set(names)) != len(names):
            raise ValueError(f"duplicate memory names {names}")
        return v

    @model_validator(mode="after")
    def _check(self) -> "Profile":
        f = float(self.clock.frequency_hz.v)
        if not f > 0:
            raise ValueError("clock.frequency_hz must be > 0")
        names = {m.name for m in self.memories}
        for eng, levels in self.roofline.items():
            if eng not in ("cpu", "vector", "tensor"):
                raise ValueError(f"roofline: unknown engine {eng!r}")
            for lv in levels:
                for c in lv.capacity_of:
                    if c not in names:
                        raise ValueError(f"roofline.{eng}.{lv.name}: unknown memory {c!r}")
                for lim in lv.limits:
                    if lim.via == "memory" and lim.memory not in names:
                        raise ValueError(f"roofline.{eng}.{lv.name}: limit memory {lim.memory!r} unknown")
                    if lim.via == "dma" and (self.dma is None or not self.dma.enabled):
                        raise ValueError(f"roofline.{eng}.{lv.name}: 'dma' limit but no DMA enabled")
                if not lv.port and not lv.limits and lv.bandwidth_Bps is None:
                    raise ValueError(f"roofline.{eng}.{lv.name}: needs limits or bandwidth_Bps")
        for m in self.memories:
            if m.kind != "dram" and m.capacity is None:
                raise ValueError(f"memory {m.name}: capacity required")
            if int(m.banks.v) < 1:
                raise ValueError(f"memory {m.name}: banks must be >= 1")
            if int(m.read_latency_cycles.v) < 1:
                raise ValueError(f"memory {m.name}: read latency must be >= 1 cycle (no zero-cycle reads)")
            if m.width_bits.v % 8:
                raise ValueError(f"memory {m.name}: width_bits must be a multiple of 8")
        if self.interconnect.width_bits.v % 8 or self.interconnect.width_bits.v <= 0:
            raise ValueError("interconnect.width_bits must be a positive multiple of 8")
        return self

    # ------------------------------------------------------------------ helpers
    @property
    def f(self) -> float:
        return float(self.clock.frequency_hz.v)

    def memory(self, name: str) -> MemoryCfg:
        for m in self.memories:
            if m.name == name:
                return m
        raise ConfigError(f"no memory named {name!r}")

    def sourced_leaves(self) -> list[tuple[str, Sourced]]:
        """All parameters with provenance, as (dotted path, Sourced)."""
        out: list[tuple[str, Sourced]] = []

        def walk(obj: Any, path: str) -> None:
            if isinstance(obj, Sourced):
                out.append((path, obj))
            elif isinstance(obj, BaseModel):
                for k in type(obj).model_fields:
                    walk(getattr(obj, k), f"{path}.{k}" if path else k)
            elif isinstance(obj, dict):
                for k, v in obj.items():
                    walk(v, f"{path}.{k}")
            elif isinstance(obj, list):
                for i, v in enumerate(obj):
                    key = getattr(v, "name", i)
                    walk(v, f"{path}[{key}]")
        walk(self, "")
        return out

    def provenance_summary(self) -> dict[str, int]:
        c: dict[str, int] = {p.value: 0 for p in Provenance}
        for _, s in self.sourced_leaves():
            c[s.provenance.value] += 1
        return c


def deep_merge(base: Any, over: Any) -> Any:
    """Merge ``over`` onto ``base``: dicts recursively, ``memories`` lists by name, else replace.

    A leaf mapping with a ``value`` key (a Sourced parameter) replaces the base leaf as a whole,
    so an override never inherits a stale provenance/source from the base.
    """
    if isinstance(base, dict) and isinstance(over, dict):
        if "value" in over:
            return over
        out = dict(base)
        for k, v in over.items():
            if k == "memories" and isinstance(v, list) and isinstance(base.get(k), list):
                by = {m["name"]: m for m in base[k]}
                order = [m["name"] for m in base[k]]
                for m in v:
                    if m.get("remove"):
                        by.pop(m["name"], None)
                        order = [n for n in order if n != m["name"]]
                        continue
                    if m["name"] in by:
                        by[m["name"]] = deep_merge(by[m["name"]], m)
                    else:
                        by[m["name"]] = m
                        order.append(m["name"])
                out[k] = [by[n] for n in order]
            elif v is None:
                out.pop(k, None)
            else:
                out[k] = deep_merge(base.get(k), v) if k in base else v
        return out
    return over


def read_profile_dict(path: str | Path, _depth: int = 0) -> dict:
    p = Path(path)
    if not p.exists():
        raise ConfigError(f"configuration file not found: {p}")
    if _depth > 8:
        raise ConfigError(f"{p}: 'extends' chain too deep (cycle?)")
    try:
        data = yaml.safe_load(p.read_text())
    except yaml.YAMLError as e:
        raise ConfigError(f"{p}: invalid YAML: {e}") from e
    if not isinstance(data, dict):
        raise ConfigError(f"{p}: top level must be a mapping")
    if "extends" in data:
        base = read_profile_dict(p.parent / data.pop("extends"), _depth + 1)
        base.pop("notes", None)
        data = deep_merge(base, data)
    return data


def load_profile(path: str | Path) -> Profile:
    p = Path(path)
    data = read_profile_dict(p)
    if "sweep" in data:
        raise ConfigError(f"{p}: this is a sweep file; use 'memorylab sweep --config {p}'")
    try:
        return Profile.model_validate(data)
    except ValidationError as e:
        lines = [f"{p}: invalid profile:"]
        for err in e.errors():
            loc = ".".join(str(x) for x in err["loc"])
            lines.append(f"  - {loc}: {err['msg']}")
        raise ConfigError("\n".join(lines)) from None


def profile_from_dict(data: dict) -> Profile:
    try:
        return Profile.model_validate(data)
    except ValidationError as e:
        raise ConfigError(str(e)) from None


def precision_of(name: str) -> Precision:
    try:
        return Precision(name)
    except ValueError:
        raise ConfigError(f"unknown precision {name!r}; one of {[p.value for p in Precision]}") from None


def prov_of(*items: Sourced | None) -> str:
    return combine(i.provenance for i in items if i is not None)
