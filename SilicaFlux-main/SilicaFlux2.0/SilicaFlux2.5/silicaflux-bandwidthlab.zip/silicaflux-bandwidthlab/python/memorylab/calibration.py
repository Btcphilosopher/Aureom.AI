"""Calibration of model parameters against RTL-simulation evidence, and error reporting.

relative error = |predicted - observed| / observed, reported only for the same metric and a
nonzero observation.  Calibrated parameters are written to separate files (never merged into
the uncalibrated profiles) with provenance RTL_SIMULATED and the hash of the evidence used.

Evidence used here (all from the repository, all RTL simulations run by earlier projects):
  * silicaflux-memoryflow v2.0.0 reports/calibration_dma.csv: Verilator cycle counts of 4 KiB
    copies by memoryflow's sf_dma (EXT->SPM with a 20-cycle external-memory model, SPM->SPM),
    burst 1..16 beats of 64 bit.  This is memoryflow's DMA, NOT SilicaFlux-V (which has none).
  * silicaflux-sramlib reports/mem/analysis.json: Verilator runs of tb_sram_banking on
    sram_bank_controller (48 rows).  Compared at pattern level (different PRNG draws).
"""
from __future__ import annotations

import itertools
import math
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

from . import bankbench as bb
from .dma import Descriptor, Dma
from .event_engine import ClockDomain, EventEngine
from .interconnect import Interconnect
from .provenance import sha256_file
from .sram import BankCtrlConfig, SramArray
from .trace_import import read_memoryflow_dma_calibration, read_sramlib_analysis


def relative_error(predicted: float | None, observed: float | None, floor: float = 0.0) -> float | None:
    """|p - o| / |o| for a nonzero (and >= floor) reference, else None (use the absolute error)."""
    if predicted is None or observed is None:
        return None
    if not (math.isfinite(predicted) and math.isfinite(observed)) or observed == 0 or abs(observed) < floor:
        return None
    return abs(predicted - observed) / abs(observed)


def steady_state(res: dict) -> dict:
    """Metrics over the window in which every master still has requests (like a fixed-length TB run)."""
    last = {}
    for c, m, _ in res["accepts"]:
        last[m] = max(last.get(m, 0), c)
    end = min(last.values())
    acc = sum(1 for c, _, _ in res["accepts"] if c <= end)
    conf = sum(1 for c, _ in res["conflicts"] if c <= end)
    return {"window_cycles": end + 1, "words_per_cycle": acc / (end + 1),
            "conflict_rate": conf / (acc + conf) if acc + conf else 0.0}


# =========================================================================== DMA vs memoryflow sf_dma RTL
DMA_DEFAULTS = {"overhead": 1, "setup": 4, "ext_latency": 20, "spm_latency": 3, "issue_interval": 1,
                "rd_outstanding": 4, "wr_outstanding": 4}


def dma_copy_cycles(path: str, burst_beats: int, *, overhead: int, setup: int, ext_latency: int,
                    spm_latency: int, issue_interval: int = 1, rd_outstanding: int = 4, wr_outstanding: int = 4,
                    nbytes: int = 4096, beat: int = 8) -> int:
    eng = EventEngine()
    clk = ClockDomain("c", 100e6)
    ic = Interconnect(eng, clk, width_bytes=beat, overhead_cycles=overhead, max_outstanding_per_master=64,
                      queue_depth=64, topology="crossbar", record_intervals=False)
    ext = SramArray(eng, clk, name="ext", capacity=1 << 20, banks=1, width_bytes=beat, read_latency=ext_latency,
                    write_latency=ext_latency, base_addr=0x8000_0000)
    spm = SramArray(eng, clk, name="spm", capacity=32 * 1024, banks=4, width_bytes=beat, read_latency=spm_latency,
                    write_latency=spm_latency, base_addr=0x1000_0000)
    # the external-memory model is pipelined (INTERVAL=1): model it as one beat per cycle
    ic.connect("ext", ext, port_bytes_per_cycle=beat)
    ic.connect("spm", spm, port_bytes_per_cycle=beat)
    burst = burst_beats * beat
    dma = Dma(eng, clk, ic, burst_bytes=burst, max_outstanding=rd_outstanding, queue_depth=4, setup_cycles=setup,
              issue_interval_cycles=issue_interval, max_write_outstanding=wr_outstanding)
    if path == "ext2spm":
        d = Descriptor("ext", 0x8000_0000, "spm", 0x1000_0000, nbytes)
    elif path == "spm2spm":
        d = Descriptor("spm", 0x1000_0000, "spm", 0x1000_4000, nbytes)
    else:
        raise ValueError(f"unknown DMA path {path}")
    dma.submit(d)
    eng.run()
    return int(round(d.t_done / clk.period_fs))


def calibrate_dma(csv_path: str | Path, grid: dict[str, list[int]] | None = None) -> dict[str, Any]:
    obs = read_memoryflow_dma_calibration(csv_path)
    # fixed from the memoryflow RTL/testbench sources: SPM write acknowledge 3 cycles (SPM_WRITE_ACK),
    # external model LATENCY=20 plus router stages (fitted offset); the rest is fitted
    grid = grid or {"overhead": [1], "setup": [4, 16], "ext_latency": [20, 24, 28], "spm_latency": [3],
                    "issue_interval": [1, 2, 3, 4, 5, 6], "rd_outstanding": [4, 8, 16], "wr_outstanding": [4, 8, 16]}

    def score(params: dict) -> tuple[float, list[dict]]:
        rows, errs = [], []
        for _, r in obs.iterrows():
            pred = dma_copy_cycles(r["path"], int(r["burst"]), **params)
            e = relative_error(pred, float(r["rtl"]))
            rows.append({"metric": r.get("metric", f"{r['path']}_b{r['burst']}"), "path": r["path"],
                         "burst_beats": int(r["burst"]), "rtl_cycles": float(r["rtl"]), "predicted_cycles": pred,
                         "relative_error": e})
            if e is not None:
                errs.append(e)
        return (sum(errs) / len(errs) if errs else math.inf), rows
    base_err, base_rows = score(dict(DMA_DEFAULTS))
    best = (math.inf, None, None)
    keys = list(grid)
    for combo in itertools.product(*(grid[k] for k in keys)):
        params = dict(zip(keys, combo))
        e, rows = score(params)
        if e < best[0] - 1e-12:
            best = (e, params, rows)
    return {"evidence": str(csv_path), "evidence_sha256": sha256_file(csv_path),
            "evidence_category": "RTL_OBSERVED (memoryflow sf_dma, Verilator)", "metric": "cycles per 4 KiB copy",
            "uncalibrated_params": DMA_DEFAULTS, "uncalibrated_mean_rel_error": base_err, "uncalibrated_rows": base_rows,
            "calibrated_params": best[1], "calibrated_mean_rel_error": best[0], "calibrated_rows": best[2],
            "grid": grid, "note": "fit applies to memoryflow's sf_dma microarchitecture only; SilicaFlux-V has no DMA"}


def write_calibrated_dma(cal: dict, out: str | Path) -> Path:
    p = Path(out)
    p.parent.mkdir(parents=True, exist_ok=True)
    src = f"{cal['evidence']} (sha256 {cal['evidence_sha256'][:16]}...), grid fit, mean rel err " \
          f"{cal['calibrated_mean_rel_error']:.3%}"
    doc = {"calibration": {
        "target": "silicaflux-memoryflow sf_dma (64-bit, DFIFO 16 beats) + 20-cycle external memory model",
        "category": "CALIBRATED (kept separate from uncalibrated profiles)",
        "parameters": {k: {"value": v, "provenance": "RTL_SIMULATED", "source": src}
                       for k, v in cal["calibrated_params"].items()},
        "uncalibrated_mean_rel_error": cal["uncalibrated_mean_rel_error"],
        "calibrated_mean_rel_error": cal["calibrated_mean_rel_error"]}}
    p.write_text(yaml.safe_dump(doc, sort_keys=False))
    return p


# =========================================================================== bank controller vs sramlib bench
def compare_sramlib_bench(analysis_json: str | Path, n_per_master: int = 1000) -> pd.DataFrame:
    obs = read_sramlib_analysis(analysis_json)
    rows = []
    for _, r in obs.iterrows():
        cfg = BankCtrlConfig(int(r.num_masters), int(r.num_banks), int(r.data_width), int(r.bank_depth),
                             int(r.read_latency))
        wl = {"stride_nb": "stride"}.get(r.workload, r.workload)
        res = bb.run(cfg, bb.generate(wl, cfg, n_per_master, int(r.seed)))
        st = res["stats"]
        ss = steady_state(res)
        for metric, pred, o, floor in (("words_per_cycle", ss["words_per_cycle"], r.words_per_cycle, 0.0),
                                       ("conflict_rate", ss["conflict_rate"], r.conflict_rate, 0.01),
                                       ("avg_latency", st["avg_latency_cycles"], r.avg_latency, 0.0)):
            rows.append({"num_banks": cfg.num_banks, "data_width": cfg.data_width, "read_latency": cfg.read_latency,
                         "workload": r.workload, "metric": metric, "rtl_observed": o, "model": pred,
                         "abs_error": pred - o, "relative_error": relative_error(pred, o, floor),
                         "comparison": "pattern-level, steady-state window (same traffic class, different PRNG draws)"})
    return pd.DataFrame(rows)
