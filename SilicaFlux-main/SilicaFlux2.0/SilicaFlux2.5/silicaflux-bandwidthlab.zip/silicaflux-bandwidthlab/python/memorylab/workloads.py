"""Workload library: operation counts, footprints and per-interface traffic.

Traffic model
-------------
A workload's traffic is always evaluated at one *interface* of the memory
hierarchy, given ``capacity`` = the bytes of storage available on the
compute side of that interface for data reuse (e.g. the TSPM capacity when
evaluating the TSPM<->SRAM interface).  The result counts every byte that
crosses that interface once (reads into the compute side + writes out of
it).  Different interfaces are evaluated separately and never summed.

Reuse can only *reduce* the traffic at an interface down to the compulsory
traffic (every input read once, every output written once); it never
changes the interface bandwidth.  This is how blocking raises arithmetic
intensity "without magically increasing physical bandwidth".

Operation convention
--------------------
``macs`` counts multiply-accumulates; ``other_ops`` counts additional
non-MAC arithmetic operations.  Arithmetic operations = macs * ops_per_mac
+ other_ops.  For a pure-MAC workload the MAC view and the OPS view differ
exactly by ``ops_per_mac``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Callable

from .roofline import LevelTraffic
from .units import DEFAULT_CONVENTION, OpConvention, OpCount, OpKind, Precision


class InfeasibleStrategy(ValueError):
    """The execution strategy cannot be realised with the given capacity."""


GEMM_STRATEGIES = ("naive", "blocked", "scratchpad_resident", "double_buffered", "dma_streaming")


@dataclass
class Workload:
    name: str
    family: str
    engine: str                     # cpu | vector | tensor | dma | mixed
    precision: Precision
    dims: dict
    macs: float
    other_ops: float
    footprint_bytes: float          # unique data touched (inputs + outputs)
    algorithmic_reads: float        # element reads before any reuse
    algorithmic_writes: float
    reuse: str                      # human-readable reuse assumptions
    strategy: str = "default"
    dependencies: list[str] = field(default_factory=list)
    out_bytes: int = 4
    convention: OpConvention = DEFAULT_CONVENTION
    _traffic: Callable[[float], tuple[LevelTraffic, dict]] | None = None

    # ------------------------------------------------------------------ ops
    @property
    def arithmetic_ops(self) -> float:
        return self.macs * self.convention.ops_per_mac + self.other_ops

    def work(self, kind: OpKind) -> OpCount:
        if kind == OpKind.MAC:
            if self.macs == 0:
                raise ValueError(f"{self.name}: no MACs; use {self.precision.arithmetic_kind.value}")
            if self.other_ops:
                raise ValueError(f"{self.name}: has non-MAC ops; MAC view would drop {self.other_ops} ops")
            return OpCount(self.macs, OpKind.MAC, self.precision)
        if kind != self.precision.arithmetic_kind:
            raise ValueError(f"{self.name}: {kind.value} incompatible with {self.precision.value}")
        return OpCount(self.arithmetic_ops, kind, self.precision)

    # ------------------------------------------------------------------ traffic
    def traffic(self, capacity_bytes: float) -> LevelTraffic:
        return self.traffic_detail(capacity_bytes)[0]

    def traffic_detail(self, capacity_bytes: float) -> tuple[LevelTraffic, dict]:
        if capacity_bytes < 0:
            raise ValueError("capacity must be >= 0")
        if self._traffic is None:
            raise ValueError(f"{self.name}: no traffic model")
        return self._traffic(capacity_bytes)

    def compulsory(self) -> LevelTraffic:
        return LevelTraffic(self.footprint_bytes - self.output_bytes, self.output_bytes)

    @property
    def output_bytes(self) -> float:
        return self.dims.get("_output_bytes", 0.0)

    def intensity(self, capacity_bytes: float, kind: OpKind | None = None) -> float:
        k = kind or self.precision.arithmetic_kind
        q = self.traffic(capacity_bytes).total
        return math.inf if q == 0 else self.work(k).value / q

    def describe(self, capacity_bytes: float) -> dict:
        tr, info = self.traffic_detail(capacity_bytes)
        k = OpKind.MAC if (self.macs and not self.other_ops) else self.precision.arithmetic_kind
        return {
            "workload": self.name, "family": self.family, "engine": self.engine,
            "strategy": self.strategy, "precision": self.precision.value, "dims": {
                kk: v for kk, v in self.dims.items() if not kk.startswith("_")},
            "macs": self.macs, "other_ops": self.other_ops, "arithmetic_ops": self.arithmetic_ops,
            "op_convention": self.convention.describe(),
            "footprint_bytes": self.footprint_bytes, "algorithmic_reads": self.algorithmic_reads,
            "algorithmic_writes": self.algorithmic_writes, "capacity_bytes": capacity_bytes,
            "read_bytes": tr.read_bytes, "write_bytes": tr.write_bytes, "traffic_bytes": tr.total,
            "intensity": (math.inf if tr.total == 0 else self.work(k).value / tr.total),
            "intensity_unit": k.intensity_unit, "reuse": self.reuse,
            "dependencies": self.dependencies, **{f"x_{a}": b for a, b in info.items()},
        }


def _lt(r: float, w: float) -> LevelTraffic:
    return LevelTraffic(float(r), float(w))


# =========================================================================== streaming kernels
def vector_add(n: int, precision: Precision = Precision.INT32, engine: str = "vector") -> Workload:
    b = precision.bytes
    return Workload(
        name=f"vector_add_n{n}", family="vector_add", engine=engine, precision=precision,
        dims={"n": n, "_output_bytes": n * b}, macs=0, other_ops=n, footprint_bytes=3 * n * b,
        algorithmic_reads=2 * n, algorithmic_writes=n, out_bytes=b,
        reuse="none: every element used once (streaming)",
        _traffic=lambda c: (_lt(2 * n * b, n * b), {"working_set_bytes": 3 * b}))


def axpy(n: int, precision: Precision = Precision.INT32, engine: str = "vector") -> Workload:
    b = precision.bytes
    return Workload(
        name=f"axpy_n{n}", family="axpy", engine=engine, precision=precision,
        dims={"n": n, "_output_bytes": n * b}, macs=n, other_ops=0, footprint_bytes=3 * n * b,
        algorithmic_reads=2 * n, algorithmic_writes=n, out_bytes=b,
        reuse="scalar a in a register; x, y streamed once; y overwritten in place (counted as write)",
        _traffic=lambda c: (_lt(2 * n * b, n * b), {"working_set_bytes": 2 * b}))


def dot(n: int, precision: Precision = Precision.INT32, engine: str = "vector", acc_bytes: int = 4) -> Workload:
    b = precision.bytes
    return Workload(
        name=f"dot_n{n}", family="dot", engine=engine, precision=precision,
        dims={"n": n, "_output_bytes": acc_bytes}, macs=n, other_ops=0,
        footprint_bytes=2 * n * b + acc_bytes, algorithmic_reads=2 * n, algorithmic_writes=1,
        out_bytes=acc_bytes, reuse="accumulator in a register; inputs streamed once",
        _traffic=lambda c: (_lt(2 * n * b, acc_bytes), {"working_set_bytes": 2 * b + acc_bytes}))


def gemv(m: int, n: int, precision: Precision = Precision.INT32, engine: str = "vector",
         out_bytes: int = 4) -> Workload:
    b = precision.bytes

    def tr(c: float):
        x_bytes = n * b
        if x_bytes <= c / 2:                     # x resident, A streamed once
            return _lt(m * n * b + x_bytes, m * out_bytes), {"x_resident": True, "working_set_bytes": x_bytes}
        return _lt(2 * m * n * b, m * out_bytes), {"x_resident": False, "working_set_bytes": c}
    return Workload(
        name=f"gemv_{m}x{n}", family="gemv", engine=engine, precision=precision,
        dims={"m": m, "n": n, "_output_bytes": m * out_bytes}, macs=m * n, other_ops=0,
        footprint_bytes=m * n * b + n * b + m * out_bytes, algorithmic_reads=2 * m * n,
        algorithmic_writes=m, out_bytes=out_bytes,
        reuse="x reused across rows when it fits in half the capacity; A has no reuse",
        _traffic=tr)


# =========================================================================== GEMM
def gemm_tile_search(m: int, n: int, k: int, b_in: int, b_acc: int, capacity: float,
                     align: int = 4, nbuf: int = 1, tk: int | None = None) -> dict | None:
    """Output-stationary tiling Tm x Tn (multiples of ``align``) minimising traffic.

    Buffers: nbuf * (Tm*Tk + Tk*Tn) * b_in  +  nbuf * Tm*Tn * b_acc  <= capacity.
    Traffic: A read ceil(N/Tn) times, B read ceil(M/Tm) times, C written once.
    """
    tk = min(k, tk or max(align, 16))
    best = None
    mm = list(range(align, max(align, m) + align, align)) if m > align else [align]
    nn = list(range(align, max(align, n) + align, align)) if n > align else [align]
    for tm in mm:
        tm_e = min(tm, max(m, 1))
        for tn in nn:
            tn_e = min(tn, max(n, 1))
            buf = nbuf * ((tm_e * tk + tk * tn_e) * b_in + tm_e * tn_e * b_acc)
            if buf > capacity:
                break
            reads = m * k * b_in * math.ceil(n / tn_e) + k * n * b_in * math.ceil(m / tm_e)
            key = (reads, -tm_e * tn_e)
            if best is None or key < best["key"]:
                best = {"key": key, "tm": tm_e, "tn": tn_e, "tk": tk, "buffer_bytes": buf, "reads": reads}
    return best


def gemm(m: int, n: int, k: int, strategy: str = "blocked", precision: Precision = Precision.INT8,
         engine: str = "tensor", out_bytes: int = 4, acc_bytes: int = 4, align: int = 4,
         tk: int | None = None, split_k: bool = False) -> Workload:
    """C[MxN] = A[MxK] B[KxN].  MACs = M*N*K; arithmetic ops = 2*M*N*K (default convention).

    Strategies:
      naive                 no reuse beyond the datapath registers (array of align x align; align=1 on a CPU)
      blocked               output-stationary tiles sized to the capacity (single buffered)
      scratchpad_resident   A, B, C all resident: compulsory traffic only (else infeasible)
      double_buffered       blocked with two copies of every tile buffer (overlap compute/transfer)
      dma_streaming         as double_buffered, data moved by DMA bursts (same bytes, different executor)
    """
    if strategy not in GEMM_STRATEGIES:
        raise ValueError(f"unknown GEMM strategy {strategy!r}; one of {GEMM_STRATEGIES}")
    if min(m, n, k) < 1:
        raise ValueError("GEMM dims must be >= 1")
    if engine == "cpu":
        align = 1
    b = precision.bytes
    compulsory_r = (m * k + k * n) * b
    out_total = m * n * out_bytes

    def tr(c: float):
        if strategy == "naive":
            # no reuse beyond the datapath's own operand registers: an align x align array reuses each
            # fetched A element across its align columns and each B element across its align rows
            # (align = 1 for a scalar CPU loop -> 2*M*N*K operand bytes)
            reads = m * k * b * math.ceil(n / align) + k * n * b * math.ceil(m / align)
            return _lt(reads, out_total), {"working_set_bytes": 2 * align * b + align * align * acc_bytes,
                                           "tm": align, "tn": align, "tk": k}
        if strategy == "scratchpad_resident":
            need = compulsory_r + m * n * acc_bytes
            if need > c:
                raise InfeasibleStrategy(
                    f"gemm {m}x{n}x{k} {precision.value}: resident footprint {need} B > capacity {c:.0f} B")
            return _lt(compulsory_r, out_total), {"working_set_bytes": need, "tm": m, "tn": n}
        nbuf = 1 if strategy == "blocked" else 2
        # Without split_k the reduction dimension stays whole inside a tile: an output-stationary
        # array that accumulates only in its own registers (SilicaFlux-V TE) cannot merge partial
        # sums without a spill.  K is chunked only when even an align x align tile cannot hold K.
        t = gemm_tile_search(m, n, k, b, acc_bytes, c, align=align, nbuf=nbuf, tk=tk or (None if split_k else k))
        split = bool(split_k)
        if t is None and not split_k:
            t = gemm_tile_search(m, n, k, b, acc_bytes, c, align=align, nbuf=nbuf, tk=tk)
            split = t is not None
        if t is not None:
            t["split_k"] = split or t["tk"] < k
        if t is None:
            raise InfeasibleStrategy(
                f"gemm {strategy}: capacity {c:.0f} B cannot hold even one {align}x{align} tile set")
        extra = 0.0
        if t["split_k"]:          # partial sums of every k-chunk but the last leave and re-enter the tile
            chunks = math.ceil(k / t["tk"])
            extra = 2 * (chunks - 1) * m * n * acc_bytes
        return _lt(t["reads"] + extra / 2, out_total + extra / 2), {
            "working_set_bytes": t["buffer_bytes"], "tm": t["tm"], "tn": t["tn"], "tk": t["tk"],
            "buffers": nbuf, "split_k": t["split_k"]}
    return Workload(
        name=f"gemm_{m}x{n}x{k}_{strategy}", family="gemm", engine=engine, precision=precision,
        dims={"m": m, "n": n, "k": k, "_output_bytes": out_total}, macs=m * n * k, other_ops=0,
        footprint_bytes=compulsory_r + out_total, algorithmic_reads=2 * m * n * k,
        algorithmic_writes=m * n, strategy=strategy, out_bytes=out_bytes,
        reuse={"naive": "only the compute array's own operand reuse (align x align); operands re-fetched per tile",
               "blocked": "A reused across a Tn-wide tile, B across Tm rows, C stationary",
               "scratchpad_resident": "everything resident: compulsory traffic only",
               "double_buffered": "as blocked, half the capacity per buffer copy",
               "dma_streaming": "as double_buffered, DMA executes the transfers"}[strategy],
        dependencies=["C tile written after its last K step"], _traffic=tr)


def gemm_tensor_port_traffic(m: int, n: int, k: int, rows: int, cols: int, depth: int,
                             precision: Precision, acc_bytes: int = 4) -> LevelTraffic:
    """Bytes crossing the tensor-engine operand port (scratchpad -> array) for an OS array.

    Each rows x cols output tile reads (rows + cols) operands per reduction step and
    writes rows*cols accumulators once.
    """
    tiles = math.ceil(m / rows) * math.ceil(n / cols)
    steps = math.ceil(k / depth)
    return _lt(tiles * steps * (rows + cols) * depth * precision.bytes, tiles * rows * cols * acc_bytes)


# =========================================================================== convolution & DSP
def conv2d(h: int, w: int, cin: int, cout: int, r: int = 3, s: int = 3, stride: int = 1, pad: int = 1,
           precision: Precision = Precision.INT8, engine: str = "tensor", out_bytes: int = 4) -> Workload:
    p = (h + 2 * pad - r) // stride + 1
    q = (w + 2 * pad - s) // stride + 1
    if p < 1 or q < 1:
        raise ValueError("conv2d: empty output")
    b = precision.bytes
    i_bytes = h * w * cin * b
    w_bytes = r * s * cin * cout * b
    o_bytes = p * q * cout * out_bytes

    def tr(c: float):
        if i_bytes + w_bytes + o_bytes <= c:
            return _lt(i_bytes + w_bytes, o_bytes), {"mode": "resident", "working_set_bytes": i_bytes + w_bytes + o_bytes}
        line = r * (w + 2 * pad) * cin * b
        if w_bytes + line <= c:
            return _lt(i_bytes + w_bytes, o_bytes), {"mode": "weights_resident_line_buffer",
                                                     "working_set_bytes": w_bytes + line}
        avail = max(c - line, 0)
        if avail <= 0:
            return _lt(i_bytes * r * s + w_bytes * p * q, o_bytes), {"mode": "no_reuse", "working_set_bytes": c}
        chunks = math.ceil(w_bytes / avail)
        return _lt(i_bytes * chunks + w_bytes, o_bytes), {"mode": f"cout_chunks={chunks}", "working_set_bytes": c}
    return Workload(
        name=f"conv2d_{h}x{w}x{cin}_k{r}x{s}_c{cout}", family="conv2d", engine=engine, precision=precision,
        dims={"h": h, "w": w, "cin": cin, "cout": cout, "r": r, "s": s, "stride": stride, "pad": pad,
              "p": p, "q": q, "_output_bytes": o_bytes},
        macs=p * q * cout * r * s * cin, other_ops=0, footprint_bytes=i_bytes + w_bytes + o_bytes,
        algorithmic_reads=2 * p * q * cout * r * s * cin, algorithmic_writes=p * q * cout, out_bytes=out_bytes,
        reuse="weights resident + R-row line buffer when they fit; otherwise output-channel chunks re-read input",
        _traffic=tr)


def fir(n: int, taps: int, precision: Precision = Precision.INT16, engine: str = "vector",
        out_bytes: int = 4) -> Workload:
    """Integer FIR filter y[i] = sum_t h[t] x[i-t] (integer signal processing)."""
    b = precision.bytes

    def tr(c: float):
        if (2 * taps) * b <= c:      # taps + delay line resident
            return _lt(n * b + taps * b, n * out_bytes), {"working_set_bytes": 2 * taps * b}
        return _lt(n * taps * b * 2, n * out_bytes), {"working_set_bytes": c}
    return Workload(
        name=f"fir_n{n}_t{taps}", family="fir", engine=engine, precision=precision,
        dims={"n": n, "taps": taps, "_output_bytes": n * out_bytes}, macs=n * taps, other_ops=0,
        footprint_bytes=n * b + taps * b + n * out_bytes, algorithmic_reads=2 * n * taps,
        algorithmic_writes=n, out_bytes=out_bytes,
        reuse="coefficients and delay line resident; each input sample read once", _traffic=tr)


def stencil2d(h: int, w: int, k: int = 3, precision: Precision = Precision.UINT8, engine: str = "vector",
              out_bytes: int = 1) -> Workload:
    """Streaming image filter (k x k weighted window, e.g. box/Sobel) with a line buffer."""
    b = precision.bytes

    def tr(c: float):
        line = k * w * b
        if line <= c:
            return _lt(h * w * b, h * w * out_bytes), {"line_buffer_bytes": line, "working_set_bytes": line}
        return _lt(h * w * k * k * b, h * w * out_bytes), {"line_buffer_bytes": 0, "working_set_bytes": c}
    return Workload(
        name=f"stencil{k}x{k}_{h}x{w}", family="stencil2d", engine=engine, precision=precision,
        dims={"h": h, "w": w, "k": k, "_output_bytes": h * w * out_bytes}, macs=h * w * k * k, other_ops=0,
        footprint_bytes=h * w * (b + out_bytes), algorithmic_reads=h * w * k * k, algorithmic_writes=h * w,
        out_bytes=out_bytes, reuse="k-row line buffer: every pixel fetched once when it fits", _traffic=tr)


# =========================================================================== memory kernels
def dma_copy(nbytes: int) -> Workload:
    return Workload(
        name=f"dma_copy_{nbytes}B", family="dma_copy", engine="dma", precision=Precision.UINT8,
        dims={"bytes": nbytes, "_output_bytes": nbytes}, macs=0, other_ops=0, footprint_bytes=2 * nbytes,
        algorithmic_reads=nbytes, algorithmic_writes=nbytes, out_bytes=1,
        reuse="none; pure data movement (Roofline intensity = 0, report bandwidth)",
        _traffic=lambda c: (_lt(nbytes, nbytes), {"working_set_bytes": 0}))


def cpu_sequential(n_words: int, word_bytes: int = 4) -> Workload:
    return Workload(
        name=f"cpu_seq_sum_{n_words}w", family="cpu_sequential", engine="cpu", precision=Precision.INT32,
        dims={"n": n_words, "_output_bytes": 4}, macs=0, other_ops=n_words,
        footprint_bytes=n_words * word_bytes + 4, algorithmic_reads=n_words, algorithmic_writes=1, out_bytes=4,
        reuse="sequential: each word loaded once",
        _traffic=lambda c: (_lt(n_words * word_bytes, 4), {"working_set_bytes": word_bytes}))


def cpu_random(n_accesses: int, region_bytes: int, line_bytes: int = 4, word_bytes: int = 4) -> Workload:
    """Uniform random word loads over a region; reuse only via capacity (expected hit fraction)."""
    def tr(c: float):
        hit = min(1.0, c / region_bytes) if line_bytes > word_bytes else 0.0
        return _lt(n_accesses * (1 - hit) * line_bytes + (0 if line_bytes > word_bytes else 0), 4), \
            {"expected_hit_fraction": hit, "working_set_bytes": region_bytes}
    return Workload(
        name=f"cpu_random_{n_accesses}x_{region_bytes}B", family="cpu_random", engine="cpu",
        precision=Precision.INT32, dims={"n": n_accesses, "region": region_bytes, "line": line_bytes,
                                         "_output_bytes": 4},
        macs=0, other_ops=n_accesses, footprint_bytes=region_bytes + 4, algorithmic_reads=n_accesses,
        algorithmic_writes=1, out_bytes=4,
        reuse="random: line reuse only through capacity; blocking loads make it latency-bound",
        dependencies=["each load blocks the in-order CPU (MLP = 1)"], _traffic=tr)


# =========================================================================== registry
def library(size: str = "medium") -> list[Workload]:
    """Default workload set at small / medium / large problem sizes."""
    s = {"small": 0, "medium": 1, "large": 2}[size]
    n = [1024, 16384, 262144][s]
    g = [16, 64, 256][s]
    img = [32, 128, 512][s]
    return [
        vector_add(n), axpy(n), dot(n), gemv(g * 2, g * 2),
        gemm(g, g, g, "naive"), gemm(g, g, g, "blocked"), gemm(g, g, g, "double_buffered"),
        gemm(g, g, g, "dma_streaming"), gemm(4, 4, 4, "scratchpad_resident"),
        conv2d(img // 4, img // 4, 8, 16), fir(n, 32), stencil2d(img, img),
        dma_copy(n * 4), cpu_sequential(n), cpu_random(n // 4, 64 * 1024),
    ]
