"""Simplified functional set-associative cache with timing (no coherence protocol).

Capacity / line / associativity, LRU, FIFO or seeded-random replacement,
write-back+write-allocate or write-through+no-write-allocate, hit latency, finite
MSHRs (secondary misses to the same line merge), dirty-victim writeback.  A request
must not cross a line boundary.  Not cycle-accurate against any SilicaFlux RTL; the
repository's memory_cache_repo/set_assoc_cache.sv (32 KiB, 64 B, 4-way PLRU, WB,
blocking) is the closest RTL reference (mshrs=1 approximates its blocking FSM).
"""
from __future__ import annotations

from collections import OrderedDict
from typing import Callable

import numpy as np

from .event_engine import PRIO_COMPLETE, ClockDomain, EventEngine, Trace, Transaction


class Cache:
    fidelity = "functional hit/miss + simplified timing; no coherence"

    def __init__(self, eng: EventEngine, clock: ClockDomain, *, name: str, capacity: int, line_bytes: int,
                 ways: int, downstream, downstream_name: str, replacement: str = "lru",
                 write_policy: str = "write_back", mshrs: int = 1, hit_latency: int = 1, seed: int = 1,
                 issue: Callable | None = None, trace: Trace | None = None) -> None:
        if line_bytes < 1 or capacity % (line_bytes * ways):
            raise ValueError(f"{name}: capacity must be a multiple of line x ways")
        if replacement not in ("lru", "fifo", "random", "plru") or write_policy not in ("write_back", "write_through"):
            raise ValueError(f"{name}: bad replacement/write policy")
        if mshrs < 1 or hit_latency < 1:
            raise ValueError(f"{name}: mshrs >= 1 and hit latency >= 1 cycle")
        self.eng, self.clock, self.name = eng, clock, name
        self.line, self.ways = line_bytes, ways
        self.sets = capacity // (line_bytes * ways)
        self.repl = "lru" if replacement == "plru" else replacement
        self.wb = write_policy == "write_back"
        self.mshrs, self.hit_lat = mshrs, hit_latency
        self.down, self.down_name = downstream, downstream_name
        self.issue = issue          # issue(txn, target_name, cb) -> bool  (e.g. via an interconnect)
        self.rng = np.random.Generator(np.random.PCG64(seed))
        self.tags: list[OrderedDict[int, bool]] = [OrderedDict() for _ in range(self.sets)]   # tag -> dirty
        self.mshr: dict[int, list[tuple[Transaction, Callable]]] = {}
        self.trace = trace or Trace(enabled=False)
        self.hits = self.misses = self.merged = self.writebacks = self.rejects = 0
        self.pending = 0
        eng.register(self)

    def outstanding(self) -> int:
        return self.pending

    def _split(self, addr: int) -> tuple[int, int, int]:
        la = addr // self.line
        return la, la % self.sets, la // self.sets

    def access(self, txn: Transaction, on_done: Callable[[Transaction], None], **_: object) -> bool:
        la, s, tag = self._split(txn.addr)
        if (txn.addr + txn.size - 1) // self.line != la:
            raise ValueError(f"{self.name}: request crosses a line boundary")
        st = self.tags[s]
        is_w = txn.op == "W"
        if tag in st:
            self.hits += 1
            if self.repl == "lru":
                st.move_to_end(tag)
            if is_w:
                if self.wb:
                    st[tag] = True
                else:
                    return self._write_through(txn, on_done)
            self.pending += 1
            self._after(self.hit_lat, lambda: self._done(txn, on_done))
            return True
        if is_w and not self.wb:                         # write-through, no write-allocate
            self.misses += 1
            return self._write_through(txn, on_done)
        if la in self.mshr:                              # secondary miss
            self.merged += 1
            self.pending += 1
            self.mshr[la].append((txn, on_done))
            return True
        if len(self.mshr) >= self.mshrs:
            self.rejects += 1
            return False
        self.misses += 1
        self.pending += 1
        self.mshr[la] = [(txn, on_done)]
        fill = Transaction(self.eng.new_id(), self.name, "R", la * self.line, self.line, self.eng.now, parent=txn.tid)
        self._send(fill, lambda f, la=la: self._filled(la))
        return True

    def _send(self, txn: Transaction, cb: Callable) -> None:
        ok = self.issue(txn, self.down_name, cb) if self.issue else self.down.access(txn, cb)
        if not ok:
            self._after(1, lambda: self._send(txn, cb))

    def _write_through(self, txn: Transaction, on_done: Callable) -> bool:
        self.pending += 1
        w = Transaction(self.eng.new_id(), self.name, "W", txn.addr, txn.size, self.eng.now, parent=txn.tid)
        self._send(w, lambda x: self._done(txn, on_done))
        return True

    def _filled(self, la: int) -> None:
        _, s, tag = self._split(la * self.line)
        st = self.tags[s]
        if len(st) >= self.ways:
            if self.repl == "random":
                victim = list(st)[int(self.rng.integers(0, len(st)))]
            else:
                victim = next(iter(st))                  # LRU (moved on hit) or FIFO (insertion order)
            dirty = st.pop(victim)
            if dirty:
                self.writebacks += 1
                va = (victim * self.sets + s) * self.line
                self._send(Transaction(self.eng.new_id(), self.name, "W", va, self.line, self.eng.now), lambda x: None)
        waiters = self.mshr.pop(la)
        st[tag] = any(t.op == "W" for t, _ in waiters) and self.wb
        for t, cb in waiters:
            self._done(t, cb)

    def _after(self, cycles: int, fn: Callable) -> None:
        self.eng.schedule_at(self.clock.next_edge(self.eng.now) + self.clock.cycles(cycles), fn, PRIO_COMPLETE,
                             f"{self.name}.t")

    def _done(self, txn: Transaction, cb: Callable) -> None:
        self.pending -= 1
        txn.t_service_end = self.eng.now
        cb(txn)

    def stats(self) -> dict:
        n = self.hits + self.misses + self.merged
        return {"name": self.name, "fidelity": self.fidelity, "hits": self.hits, "misses": self.misses,
                "merged_secondary_misses": self.merged, "hit_rate": self.hits / n if n else 0.0,
                "writebacks": self.writebacks, "mshr_rejects": self.rejects}
