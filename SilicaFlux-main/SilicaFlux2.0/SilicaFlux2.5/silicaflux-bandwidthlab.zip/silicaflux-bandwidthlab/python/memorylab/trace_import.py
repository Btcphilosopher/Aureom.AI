"""Import of real simulation evidence: transaction traces, counters, structured RTL results, VCD.

Canonical transaction-trace columns:
  cycle | time_ns     timestamp (cycles preferred; time_ns converted with an explicit clock)
  event              ISSUE | ACCEPT | CONFLICT | RESPONSE | COMPLETE
  master, id         who and which request (id unique per master)
  addr, op, size     optional payload description; op in R/W
  bank               optional
A raw VCD does not reveal architectural transactions by itself: ``decode_handshake``
needs an explicit signal map (clock, valid, ready, payload fields) and samples the
values *before* each active clock edge, the way a synchronous receiver does.
"""
from __future__ import annotations

import csv
import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

CANON = ("cycle", "event", "master", "id", "addr", "op", "size", "bank")
EVENTS = {"ISSUE", "ACCEPT", "CONFLICT", "RESPONSE", "COMPLETE"}


class TraceFormatError(ValueError):
    pass


def _canonicalise(df: pd.DataFrame, column_map: dict[str, str] | None, clock_hz: float | None) -> pd.DataFrame:
    if column_map:
        df = df.rename(columns={v: k for k, v in column_map.items()})
    if "cycle" not in df.columns:
        if "time_ns" in df.columns:
            if not clock_hz:
                raise TraceFormatError("trace has time_ns but no clock frequency was given (--clock-hz)")
            df["cycle"] = np.round(df["time_ns"].astype(float) * 1e-9 * clock_hz).astype(int)
        else:
            raise TraceFormatError(f"trace needs a 'cycle' or 'time_ns' column; got {list(df.columns)}")
    for c in ("event", "master", "id"):
        if c not in df.columns:
            raise TraceFormatError(f"trace is missing required column {c!r}")
    df["event"] = df["event"].astype(str).str.upper()
    bad = set(df["event"]) - EVENTS
    if bad:
        raise TraceFormatError(f"unknown trace events {sorted(bad)}; allowed {sorted(EVENTS)}")
    if (df["cycle"] < 0).any():
        raise TraceFormatError("negative timestamps in trace")
    return df


def read_trace_csv(path: str | Path, column_map: dict[str, str] | None = None,
                   clock_hz: float | None = None) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        raise TraceFormatError(f"trace file not found: {p}")
    df = pd.read_csv(p)
    return _canonicalise(df, column_map, clock_hz)


def read_trace_json(path: str | Path, column_map: dict[str, str] | None = None,
                    clock_hz: float | None = None) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        raise TraceFormatError(f"trace file not found: {p}")
    d = json.loads(p.read_text())
    recs = d.get("transactions", d.get("events")) if isinstance(d, dict) else d
    if not isinstance(recs, list):
        raise TraceFormatError(f"{p}: expected a list of records or {{'transactions': [...]}}")
    return _canonicalise(pd.DataFrame(recs), column_map, clock_hz)


def read_trace(path: str | Path, **kw: Any) -> pd.DataFrame:
    s = str(path).lower()
    if s.endswith(".csv"):
        return read_trace_csv(path, **kw)
    if s.endswith(".json"):
        return read_trace_json(path, **kw)
    raise TraceFormatError(f"unsupported trace format: {path} (use .csv or .json; VCD via decode_handshake)")


def read_counters(path: str | Path) -> dict[str, float]:
    d = json.loads(Path(path).read_text())
    if not isinstance(d, dict):
        raise TraceFormatError("counters file must be a JSON object {name: value}")
    out = {}
    for k, v in d.items():
        if isinstance(v, (int, float)) and math.isfinite(v):
            out[k] = float(v)
    return out


def transactions(df: pd.DataFrame) -> pd.DataFrame:
    """One row per (master, id): accept / completion cycles and latency where both exist."""
    acc = df[df.event == "ACCEPT"].groupby(["master", "id"])["cycle"].min()
    cmp_ = df[df.event.isin(["RESPONSE", "COMPLETE"])].groupby(["master", "id"])["cycle"].max()
    t = pd.concat([acc.rename("accept_cycle"), cmp_.rename("complete_cycle")], axis=1).reset_index()
    t["latency_cycles"] = t["complete_cycle"] - t["accept_cycle"]
    return t


def trace_metrics(df: pd.DataFrame) -> dict[str, Any]:
    t = transactions(df)
    acc = df[df.event == "ACCEPT"]
    span = (df["cycle"].max() - df["cycle"].min() + 1) if len(df) else 0
    lat = t["latency_cycles"].dropna()
    problems = []
    if (t["complete_cycle"].notna() & t["accept_cycle"].isna()).any():
        problems.append("completion without acceptance")
    if (lat < 0).any():
        problems.append("negative latency")
    dup = acc.duplicated(["master", "id"]).sum()
    if dup:
        problems.append(f"{dup} duplicated acceptances")
    # per-master response order == acceptance order
    for m, g in t.dropna().groupby("master"):
        if list(g.sort_values("accept_cycle")["id"]) != list(g.sort_values("complete_cycle")["id"]):
            problems.append(f"master {m}: responses out of acceptance order")
    return {"span_cycles": int(span), "accepted": int(len(acc)), "words_per_cycle": len(acc) / span if span else 0.0,
            "conflict_events": int((df.event == "CONFLICT").sum()),
            "avg_latency_cycles": float(lat.mean()) if len(lat) else None,
            "p95_latency_cycles": float(np.percentile(lat, 95)) if len(lat) else None,
            "max_latency_cycles": float(lat.max()) if len(lat) else None, "problems": problems}


def from_bankbench(res: dict, cycle_offset: int = 0) -> pd.DataFrame:
    """Python cycle-model result -> canonical trace."""
    rows = [{"cycle": c + cycle_offset, "event": "ACCEPT", "master": m, "id": i} for c, m, i in res["accepts"]]
    rows += [{"cycle": c + cycle_offset, "event": "RESPONSE", "master": m, "id": i} for c, m, i, *_ in res["responses"]]
    rows += [{"cycle": c + cycle_offset, "event": "CONFLICT", "master": m, "id": -1} for c, m in res["conflicts"]]
    return pd.DataFrame(rows)


def read_harness_log(path: str | Path) -> pd.DataFrame:
    """tb_memorylab_bank_trace log (A/C/R lines) -> canonical trace."""
    rows = []
    for line in Path(path).read_text().splitlines():
        f = line.split()
        if not f:
            continue
        if f[0] == "A":
            rows.append({"cycle": int(f[1]), "event": "ACCEPT", "master": int(f[2]), "id": int(f[3], 16)})
        elif f[0] == "C":
            rows.append({"cycle": int(f[1]), "event": "CONFLICT", "master": int(f[2]), "id": -1})
        elif f[0] == "R":
            rows.append({"cycle": int(f[1]), "event": "RESPONSE", "master": int(f[2]), "id": int(f[3], 16)})
    return pd.DataFrame(rows)


# =========================================================================== structured RTL results
def read_sramlib_analysis(path: str | Path) -> pd.DataFrame:
    """silicaflux-sramlib reports/mem/analysis.json 'bench' rows (Verilator, self-checking TB)."""
    d = json.loads(Path(path).read_text())
    rows = []
    for b in d.get("bench", []):
        c = b["config"]
        rows.append({"num_masters": c["NM"], "num_banks": c["NB"], "data_width": c["DW"], "bank_depth": c["BD"],
                     "read_latency": c["LAT"], "workload": b["workload"], "seed": b["seed"], "cycles": b["cycles"],
                     "tb_result": b["tb_result"], "words_per_cycle": b["words_per_cycle"],
                     "conflict_rate": b["conflict_rate"], "avg_latency": b["avg_latency"],
                     "max_latency": b["max_latency"], "command": b.get("cmd")})
    return pd.DataFrame(rows)


def read_memoryflow_dma_calibration(path: str | Path) -> pd.DataFrame:
    """silicaflux-memoryflow reports/calibration_dma.csv (RTL cycles of 4 KiB sf_dma copies)."""
    df = pd.read_csv(path)
    need = {"burst", "path", "rtl"}
    if not need <= set(df.columns):
        raise TraceFormatError(f"{path}: expected columns {sorted(need)}")
    return df


# =========================================================================== VCD
@dataclass
class VcdSignal:
    code: str
    name: str
    width: int
    times: list[int] = field(default_factory=list)
    values: list[str] = field(default_factory=list)


class Vcd:
    """Minimal VCD reader (scalar and vector value changes; $timescale honoured)."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.signals: dict[str, VcdSignal] = {}
        self.by_name: dict[str, list[VcdSignal]] = {}
        self.timescale_s = 1e-9
        self._parse()

    def _parse(self) -> None:
        scope: list[str] = []
        t = 0
        toks = self.path.read_text().split()
        i = 0
        units = {"s": 1, "ms": 1e-3, "us": 1e-6, "ns": 1e-9, "ps": 1e-12, "fs": 1e-15}
        while i < len(toks):
            tok = toks[i]
            if tok == "$timescale":
                j = i + 1
                spec = ""
                while toks[j] != "$end":
                    spec += toks[j]
                    j += 1
                num = "".join(ch for ch in spec if ch.isdigit()) or "1"
                unit = "".join(ch for ch in spec if ch.isalpha())
                self.timescale_s = int(num) * units.get(unit, 1e-9)
                i = j + 1
            elif tok == "$scope":
                scope.append(toks[i + 2])
                i += 4
            elif tok == "$upscope":
                scope.pop()
                i += 2
            elif tok == "$var":
                width, code, name = int(toks[i + 2]), toks[i + 3], toks[i + 4]
                j = i + 5
                if toks[j] != "$end":           # optional [msb:lsb]
                    j += 1
                full = ".".join(scope + [name])
                sig = self.signals.get(code) or VcdSignal(code, full, width)
                self.signals[code] = sig
                self.by_name.setdefault(full, []).append(sig)
                self.by_name.setdefault(name, []).append(sig)
                i = j + 1
            elif tok.startswith("#"):
                t = int(tok[1:])
                i += 1
            elif tok in ("$dumpvars", "$dumpon", "$dumpoff", "$dumpall", "$end"):
                i += 1
            elif tok.startswith("$"):
                while toks[i] != "$end":
                    i += 1
                i += 1
            elif tok[0] in "01xXzZ" and len(tok) > 1 and tok[1:] in self.signals:
                self._chg(tok[1:], t, tok[0])
                i += 1
            elif tok[0] in "bB":
                self._chg(toks[i + 1], t, tok[1:])
                i += 2
            elif tok[0] in "rR":
                i += 2
            else:
                i += 1

    def _chg(self, code: str, t: int, v: str) -> None:
        s = self.signals.get(code)
        if s is None:
            return
        if s.times and s.times[-1] == t:
            s.values[-1] = v
        else:
            s.times.append(t)
            s.values.append(v)

    def signal(self, name: str) -> VcdSignal:
        c = self.by_name.get(name)
        if not c:
            raise TraceFormatError(f"VCD signal {name!r} not found; available e.g. {sorted(self.by_name)[:12]}")
        return c[0]

    @staticmethod
    def value_before(sig: VcdSignal, t: int) -> str | None:
        """Value strictly before time t (what a flop sampling at an edge at t sees)."""
        import bisect
        k = bisect.bisect_left(sig.times, t) - 1
        return sig.values[k] if k >= 0 else None

    def rising_edges(self, clk: str) -> list[int]:
        s = self.signal(clk)
        return [t for t, v, pv in zip(s.times, s.values, [None] + s.values[:-1]) if v == "1" and pv in ("0", None)
                and t > 0]


def _bit(v: str | None, bit: int | None) -> int | None:
    if v is None:
        return None
    if bit is None:
        return int(v, 2) if set(v) <= {"0", "1"} else None
    v = v.zfill(bit + 1)
    ch = v[-1 - bit]
    return int(ch) if ch in "01" else None


def decode_handshake(vcd_path: str | Path, *, clock: str, valid: str, ready: str, fields: dict[str, str] | None = None,
                     valid_bit: int | None = None, ready_bit: int | None = None, cycle_offset: int = 0) -> pd.DataFrame:
    """Transfers (valid && ready sampled before each rising clock edge) decoded from a VCD."""
    vcd = Vcd(vcd_path)
    edges = vcd.rising_edges(clock)
    sv, sr = vcd.signal(valid), vcd.signal(ready)
    fs = {k: vcd.signal(v) for k, v in (fields or {}).items()}
    out = []
    for k, t in enumerate(edges):
        v, r = _bit(Vcd.value_before(sv, t), valid_bit), _bit(Vcd.value_before(sr, t), ready_bit)
        if v == 1 and r == 1:
            rec = {"edge": k + cycle_offset, "time": t}
            for name, s in fs.items():
                val = Vcd.value_before(s, t)
                rec[name] = int(val, 2) if val and set(val) <= {"0", "1"} else None
            out.append(rec)
    return pd.DataFrame(out)
