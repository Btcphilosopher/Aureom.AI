"""Run orchestration and result files.  Every artefact records its provenance category.

Run directory layout:
  provenance.json               experiment record (git revision, versions, configs, seeds, limits)
  analytical/<profile>.json|csv ANALYTICAL_CEILING results (+ engine-model estimates)
  simulated/<profile>.json|csv  EVENT_SIMULATED results (summary) + per-run detail JSON
  sweeps/<name>.csv|json        sweep rows, marginal_gains, saturation, pareto
  rtl/*.json|csv                RTL_OBSERVED evidence and model-vs-RTL comparisons
  calibrated/*.yaml             calibrated parameters (kept separate from uncalibrated profiles)
  figures/*.png, dashboard.html, REPORT.md
"""
from __future__ import annotations

import json
import math
import time
import traceback
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd

from . import calibration as cal
from . import machine, optimisation as opt, rtl_integration as ri, simulator as sim, sweep as sw, workloads as wl
from .compute import UnsupportedConfiguration
from .config import Profile, load_profile
from .event_engine import LimitExceeded, SimulationError
from .provenance import ResultCategory, experiment_record
from .units import Precision

CONFIG_DIR = Path(__file__).resolve().parent / "configs"
DEFAULT_PROFILES = ["silicaflux_v_release1_rtl", "silicaflux_v", "silicaflux_130nm_demo", "silicaflux_65nm_demo",
                    "silicaflux_full"]
LIMITATIONS = [
    "Analytical results are upper bounds (Roofline ceilings), not predictions of achieved performance.",
    "The system simulator is transaction-level and approximately timed; only the SRAM bank controller model is "
    "cycle-level and validated against RTL (Verilator + Icarus) for the configurations listed in rtl/.",
    "The DRAM model is a timing abstraction, not JEDEC-accurate; the cache model has no coherence protocol.",
    "Area coefficients per MAC/lane/bank/bus bit are hypothetical (repository synthesis is flattened); SRAM area is "
    "macro-only (IHP SG13G2 datasheet), a lower bound.",
    "No power model is calibrated: energy is not reported.",
    "No silicon exists: SILICON_MEASURED is empty by construction.",
    "The provisional SilicaFlux-V profile (256 KiB, 200 MHz, 64-bit bus, DMA) is not the RTL release "
    "(128 KiB, 50 MHz, 32-bit SFB crossbar, no DMA).",
]


def jsonable(o: Any) -> Any:
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating, float)):
        f = float(o)
        return f if math.isfinite(f) else None
    if isinstance(o, np.ndarray):
        return jsonable(o.tolist())
    if isinstance(o, Path):
        return str(o)
    if hasattr(o, "value") and hasattr(o, "name") and not isinstance(o, (str, bytes)):   # enums
        return o.value
    if isinstance(o, (str, int, bool)) or o is None:
        return o
    return str(o)


def write_json(path: Path, obj: Any) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(jsonable(obj), indent=1))
    return path


# =========================================================================== workload sets
def analysis_set(size: str = "medium") -> list[tuple[wl.Workload, str]]:
    s = {"small": 0, "medium": 1, "large": 2}[size]
    g = [32, 64, 128][s]
    n = [1024, 4096, 16384][s]
    img = [16, 32, 64][s]
    return [
        (wl.gemm(g, g, g, "naive"), "tensor"), (wl.gemm(g, g, g, "blocked"), "tensor"),
        (wl.gemm(g, g, g, "double_buffered"), "tensor"), (wl.gemm(g, g, g, "dma_streaming"), "tensor"),
        (wl.gemm(4, 4, 4, "scratchpad_resident"), "tensor"), (wl.conv2d(img // 2, img // 2, 8, 16), "tensor"),
        (wl.vector_add(n), "vector"), (wl.axpy(n), "vector"), (wl.dot(n), "vector"), (wl.gemv(g // 2, g), "vector"),
        (wl.fir(n // 4, 16, precision=Precision.INT32), "vector"),
        (wl.stencil2d(img, img, precision=Precision.INT32, out_bytes=4), "vector"),
        (wl.cpu_sequential(n // 2), "cpu"), (wl.cpu_random(n // 8, 64 * 1024), "cpu"),
        (wl.fir(n // 8, 8, precision=Precision.INT16, engine="cpu"), "cpu"),
    ]


def sim_set(size: str = "medium") -> list[tuple[wl.Workload, str]]:
    s = {"small": 0, "medium": 1, "large": 2}[size]
    g = [32, 64, 128][s]
    n = [1024, 4096, 16384][s]
    return [
        (wl.gemm(g, g, g, "naive"), "tensor"), (wl.gemm(g, g, g, "blocked"), "tensor"),
        (wl.gemm(g, g, g, "double_buffered"), "tensor"), (wl.gemm(4, 4, 4, "scratchpad_resident"), "tensor"),
        (wl.conv2d(16, 16, 8, 16), "tensor"),
        (wl.vector_add(n), "vector"), (wl.axpy(n), "vector"), (wl.dot(n), "vector"), (wl.gemv(g // 2, g), "vector"),
        (wl.fir(n // 4, 16, precision=Precision.INT32), "vector"),
        (wl.cpu_sequential(n // 2), "cpu"), (wl.cpu_random(n // 8, 64 * 1024), "cpu"),
        (wl.dma_copy(n * 2), "dma"),
    ]


# =========================================================================== stages
def stage_analytical(profiles: list[str], out: Path, size: str = "medium") -> list[dict]:
    rows = []
    for pn in profiles:
        p = load_profile(CONFIG_DIR / f"{pn}.yaml")
        res = []
        for w, eng in analysis_set(size):
            try:
                r = machine.analyse(p, w, eng)
            except (UnsupportedConfiguration, wl.InfeasibleStrategy) as e:
                res.append({"workload": w.name, "engine": eng, "status": "unsupported", "error": str(e),
                            "category": ResultCategory.ANALYTICAL_CEILING.value, "profile": pn})
                continue
            r["status"] = "ok"
            r["workload_description"] = w.describe(machine.level_capacity(p, p.roofline[eng][-1]) if not
                                                   p.roofline[eng][-1].port else 0)
            res.append(r)
        write_json(out / "analytical" / f"{pn}.json", {"profile": pn, "category": "ANALYTICAL_CEILING",
                                                       "parameter_provenance": p.provenance_summary(), "results": res})
        for r in res:
            if r.get("status") != "ok":
                rows.append({"profile": pn, "workload": r["workload"], "engine": r["engine"], "status": r["status"],
                             "error": r.get("error")})
                continue
            bind = next((lv for lv in r["levels"] if lv["level"] == r["binding"]), None)
            rows.append({"profile": pn, "workload": r["workload"], "family": r["family"], "strategy": r["strategy"],
                         "engine": r["engine"], "status": "ok", "kind": r["kind"], "precision": r["precision"],
                         "rate_unit": r["rate_unit"], "peak": r["peak"], "ceiling": r["ceiling"],
                         "binding": r["binding"], "bound": r["bound"],
                         "unused_compute_fraction": r["unused_compute_fraction"],
                         "intensity_binding": bind["intensity"] if bind else None,
                         "engine_model_utilisation": r["engine_model"]["engine_utilisation"],
                         "category": "ANALYTICAL_CEILING", "convention": r["convention"]})
    df = pd.DataFrame(rows)
    df.to_csv(out / "analytical" / "analytical_summary.csv", index=False)
    return rows


def _sim_summary(r: dict) -> dict:
    eb = r["engine_breakdown"].get(r["engine"], {})
    return {"profile": r["profile"], "workload": r["workload"], "family": r["family"], "strategy": r["strategy"],
            "engine": r["engine"], "kind": r["kind"], "status": "ok", "makespan_s": r["makespan_s"],
            "makespan_cycles": r["makespan_cycles"], "achieved_ops_per_s": r["achieved_ops_per_s"],
            "peak_ops_per_s": r["peak_ops_per_s"], "compute_utilisation": r["compute_utilisation"],
            "bound": r["classification"]["bound"], "reason": r["classification"]["reason"],
            "busiest_resource": r["classification"]["busiest_resource"],
            "busiest_utilisation": r["classification"]["busiest_utilisation"],
            "engine_busy": eb.get("busy_fraction"), "memory_stall": eb.get("memory_stall_fraction"),
            "dependency_stall": eb.get("dependency_stall_fraction"), "sustained_Bps": r["sustained_Bps"],
            "lat_mean_cycles": r["latency_cycles"]["mean"], "lat_p95_cycles": r["latency_cycles"]["p95"],
            "lat_p99_cycles": r["latency_cycles"]["p99"], "mover": r["mover"],
            "dma_utilisation": (r.get("dma") or {}).get("busy_fraction"), "events": r["events"],
            "category": "EVENT_SIMULATED"}


def stage_simulated(profiles: list[str], out: Path, size: str = "medium", seed: int = 1,
                    max_events: int = 8_000_000) -> list[dict]:
    rows = []
    for pn in profiles:
        p = load_profile(CONFIG_DIR / f"{pn}.yaml")
        detail = []
        for w, eng in sim_set(size):
            try:
                r = sim.simulate(p, w, eng, seed=seed, trace=True, max_events=max_events)
            except (UnsupportedConfiguration, wl.InfeasibleStrategy, LimitExceeded, SimulationError) as e:
                rows.append({"profile": pn, "workload": w.name, "engine": eng, "status": type(e).__name__,
                             "error": str(e), "category": "EVENT_SIMULATED"})
                continue
            r.pop("_trace_rows", None)
            s = _sim_summary(r)
            s["trace_invariant_errors"] = len(r.get("trace_invariant_errors", []))
            rows.append(s)
            detail.append(r)
        try:
            mixed = sim.simulate_mixed(p, [(wl.cpu_sequential(1024), "cpu"), (wl.dot(4096), "vector"),
                                           (wl.gemm(32, 32, 32, "double_buffered"), "tensor")], seed=seed)
        except (UnsupportedConfiguration, wl.InfeasibleStrategy, LimitExceeded, SimulationError, ValueError) as e:
            mixed = {"error": f"{type(e).__name__}: {e}"}
        write_json(out / "simulated" / f"{pn}.json", {"profile": pn, "category": "EVENT_SIMULATED", "seed": seed,
                                                      "runs": detail, "mixed": mixed,
                                                      "thresholds": sim.THRESHOLDS})
    pd.DataFrame(rows).to_csv(out / "simulated" / "simulated_summary.csv", index=False)
    return rows


def stage_sweeps(sweeps: list[str], out: Path, progress: Callable[[str], None] | None = None) -> dict:
    res = {}
    units = {k: v[1] for k, v in sw.KNOBS.items()}
    for name in sweeps:
        spec = sw.load_sweep(CONFIG_DIR / f"{name}.yaml")
        r = sw.run_sweep(spec, progress)
        df = r["df"]
        d = out / "sweeps"
        d.mkdir(parents=True, exist_ok=True)
        df.to_csv(d / f"{name}.csv", index=False)
        meta = {"spec": {k: v for k, v in vars(spec).items()}, "points": r["points"], "stopped": r["stopped"],
                "wall_s": r["wall_s"], "category": "EVENT_SIMULATED + ANALYTICAL_CEILING (model configurations)"}
        write_json(d / f"{name}.json", meta)
        if spec.mode == "ofat":
            mg = opt.marginal_gains(df, units)
            mg.to_csv(d / f"{name}_marginal_gains.csv", index=False)
            opt.saturation_points(mg).to_csv(d / f"{name}_saturation.csv", index=False)
        gm = opt.geomean_by_point(df)
        pts = pd.DataFrame([{**{k: v for k, v in p.items()}, "point": i} for i, p in enumerate(r["points"])])
        gm = gm.merge(pts, on="point", how="left")
        pf = opt.pareto(gm, objectives={"geomean_speedup": "max", "area_mm2": "min"})
        pf.to_csv(d / f"{name}_pareto.csv", index=False)
        res[name] = {"rows": len(df), "stopped": r["stopped"], "wall_s": r["wall_s"]}
    return res


def stage_rtl(out: Path, *, sim_name: str = "verilator", n_per_master: int = 400,
              evidence_root: Path | None = None) -> dict:
    """RTL_OBSERVED evidence: bank-controller equivalence, SilicaFlux-V tile latency, calibrations."""
    d = out / "rtl"
    d.mkdir(parents=True, exist_ok=True)
    work = Path(__file__).resolve().parents[2] / "build" / "memorylab" / "rtl"     # never inside the run dir
    status: dict[str, Any] = {}
    try:
        rows = ri.equivalence_suite(work, sim=sim_name, n_per_master=n_per_master)
        try:
            rows += [dict(x, case=f"icarus-{x['case']}") for x in
                     ri.equivalence_suite(work, sim="icarus", n_per_master=150)[:4]]
        except (ri.RtlUnavailable, RuntimeError) as e:
            status["icarus"] = f"skipped: {e}"
        pd.DataFrame(rows).to_csv(d / "bank_controller_equivalence.csv", index=False)
        write_json(d / "bank_controller_equivalence.json", {"category": "RTL_OBSERVED vs EVENT_SIMULATED",
                                                            "library": ri.sramlib_profile(ri.locate_sramlib(build_dir=work)),
                                                            "cases": rows})
        status["bank_equivalence"] = f"{sum(r['equivalent'] for r in rows)}/{len(rows)} equivalent"
    except (ri.RtlUnavailable, RuntimeError) as e:
        status["bank_equivalence"] = f"PENDING: {e}"
    try:
        t = ri.run_tile_latency(work)
        pd.DataFrame(t["rows"]).to_csv(d / "sfv_tile_latency.csv", index=False)
        write_json(d / "sfv_tile_latency.json", t)
        status["tile_latency"] = f"{sum(r['abs_error_cycles'] == 0 for r in t['rows'])}/{len(t['rows'])} exact"
    except (ri.RtlUnavailable, RuntimeError) as e:
        status["tile_latency"] = f"PENDING: {e}"
    root = evidence_root or (ri.find_repo_root(Path(__file__).resolve()))
    if root:
        import zipfile
        mf_zip = root / "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-memoryflow-v2.0.0.zip"
        sl_zip = root / ri.SRAMLIB_ZIP_REL
        ev = work / "evidence"
        ev.mkdir(parents=True, exist_ok=True)
        try:
            with zipfile.ZipFile(mf_zip) as z:
                z.extract("silicaflux-memoryflow/reports/calibration_dma.csv", ev)
            c = cal.calibrate_dma(ev / "silicaflux-memoryflow/reports/calibration_dma.csv")
            c["evidence"] = f"{mf_zip.relative_to(root)}:silicaflux-memoryflow/reports/calibration_dma.csv"
            write_json(d / "dma_calibration_memoryflow.json", c)
            pd.DataFrame(c["calibrated_rows"]).to_csv(d / "dma_calibration_memoryflow.csv", index=False)
            cal.write_calibrated_dma(c, out / "calibrated" / "memoryflow_sf_dma_calibrated.yaml")
            status["dma_calibration"] = (f"mean rel err {c['uncalibrated_mean_rel_error']:.1%} -> "
                                         f"{c['calibrated_mean_rel_error']:.1%}")
        except (KeyError, FileNotFoundError, zipfile.BadZipFile) as e:
            status["dma_calibration"] = f"PENDING: {e}"
        try:
            with zipfile.ZipFile(sl_zip) as z:
                z.extract("silicaflux-sramlib/reports/mem/analysis.json", ev)
            b = cal.compare_sramlib_bench(ev / "silicaflux-sramlib/reports/mem/analysis.json")
            b.to_csv(d / "sramlib_bench_comparison.csv", index=False)
            status["sramlib_bench"] = "; ".join(f"{m} mean rel err {v:.1%}" for m, v in
                                                b.groupby("metric")["relative_error"].mean().items())
        except (KeyError, FileNotFoundError, zipfile.BadZipFile) as e:
            status["sramlib_bench"] = f"PENDING: {e}"
    else:
        status["dma_calibration"] = status["sramlib_bench"] = "PENDING: repository archives not found"
    write_json(d / "status.json", status)
    return status


def run_all(out: Path, *, profiles: list[str] | None = None, sweeps: list[str] | None = None, size: str = "medium",
            seed: int = 1, rtl: bool = True, progress: Callable[[str], None] = print) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    profiles = profiles or DEFAULT_PROFILES
    sweeps = sweeps if sweeps is not None else ["architecture_sweep", "memory_sweep", "pareto_sweep"]
    t0 = time.time()
    rec = experiment_record(config_path=None, config_dict={"profiles": profiles, "sweeps": sweeps, "size": size},
                            seed=seed, command=f"memorylab all --out {out}",
                            extra={"profiles": {p: str(CONFIG_DIR / f"{p}.yaml") for p in profiles},
                                   "profile_sha256": {p: __import__("memorylab.provenance", fromlist=["x"]).sha256_file(
                                       CONFIG_DIR / f"{p}.yaml") for p in profiles},
                                   "sweeps": sweeps, "workload_size": size,
                                   "op_convention": "1 MAC = 2 arithmetic operations; INT and FP never interconverted",
                                   "traffic_assumptions": "per-interface traffic from workloads.py (capacity-based reuse)",
                                   "fidelity": {"analytical": "upper bound", "simulator": "transaction-level",
                                                "bank_controller": "cycle-level, RTL-validated"},
                                   "limitations": LIMITATIONS, "missing_inputs": [
                                       "silicon measurements (none exist)", "calibrated power model",
                                       "per-block synthesis area", "65 nm / commercial SRAM macro data",
                                       "SilicaFlux-V DMA RTL (not implemented)"]},
                            repo_hint=Path(__file__).resolve())
    stages: dict[str, Any] = {}
    progress("analytical ...")
    stages["analytical"] = len(stage_analytical(profiles, out, size))
    stages["capacity_study"] = len(stage_capacity_study(out))
    stages["what_if_studies"] = len(stage_studies(out, seed))
    progress("simulated ...")
    stages["simulated"] = len(stage_simulated(profiles, out, size, seed))
    progress("sweeps ...")
    stages["sweeps"] = stage_sweeps(sweeps, out, None)
    if rtl:
        progress("rtl ...")
        try:
            stages["rtl"] = stage_rtl(out)
        except Exception as e:                       # never lose the other results
            stages["rtl"] = {"error": f"{type(e).__name__}: {e}", "trace": traceback.format_exc()[-2000:]}
    rec["execution_status"] = stages
    rec["wall_s"] = time.time() - t0
    write_json(out / "provenance.json", rec)
    return rec


def stage_capacity_study(out: Path, profile: str = "silicaflux_full",
                         caps_kib: tuple[int, ...] = (8, 16, 32, 64, 128, 256, 512, 1024, 2048),
                         tspm_kib: int = 16) -> pd.DataFrame:
    """ANALYTICAL: DRAM-interface traffic and ceiling vs on-chip SRAM capacity (DRAM-backed profile).

    Only meaningful where external memory exists: on SilicaFlux-V (no DRAM) SRAM capacity is a
    feasibility limit, not a throughput knob.
    """
    import copy
    from .config import profile_from_dict, read_profile_dict
    base = read_profile_dict(CONFIG_DIR / f"{profile}.yaml")
    rows = []
    for kib in caps_kib:
        d = copy.deepcopy(base)
        for m in d["memories"]:
            if m["name"] == "sram":
                m["capacity"] = {"value": f"{kib}KiB", "provenance": "HYPOTHETICAL", "source": "capacity study"}
            if m["name"] == "tspm":     # small fixed scratchpad so the SRAM capacity is what varies
                m["capacity"] = {"value": f"{tspm_kib}KiB", "provenance": "HYPOTHETICAL", "source": "capacity study"}
        p = profile_from_dict(d)
        for w in (wl.gemm(512, 512, 512, "double_buffered"), wl.gemm(1024, 1024, 1024, "double_buffered"),
                  wl.conv2d(64, 64, 64, 128)):
            try:
                r = machine.analyse(p, w, "tensor")
            except (UnsupportedConfiguration, wl.InfeasibleStrategy) as e:
                rows.append({"sram_kib": kib, "workload": w.name, "status": str(e)})
                continue
            dram = next(lv for lv in r["levels"] if lv["level"] == "dram")
            rows.append({"sram_kib": kib, "tspm_kib": tspm_kib, "on_chip_kib": kib + tspm_kib, "workload": w.name,
                         "status": "ok", "ceiling_mac_per_s": r["ceiling"],
                         "peak_mac_per_s": r["peak"], "binding": r["binding"], "bound": r["bound"],
                         "dram_bytes": dram["bytes"], "dram_intensity_mac_per_B": dram["intensity"],
                         "dram_ceiling_mac_per_s": dram["ceiling"], "category": "ANALYTICAL_CEILING"})
    df = pd.DataFrame(rows)
    (out / "analytical").mkdir(parents=True, exist_ok=True)
    df.to_csv(out / "analytical" / "sram_capacity_study.csv", index=False)
    return df


def stage_studies(out: Path, seed: int = 1) -> pd.DataFrame:
    """Targeted EVENT_SIMULATED what-if studies behind the RTL improvement proposals."""
    rows = []
    p = load_profile(CONFIG_DIR / "silicaflux_v.yaml")
    for w, eng in [(wl.vector_add(4096), "vector"), (wl.dot(4096), "vector"),
                   (wl.fir(1024, 16, precision=Precision.INT32), "vector"), (wl.gemm(64, 64, 64, "double_buffered"), "tensor")]:
        a = sim.simulate(p, w, eng, seed=seed)
        b = sim.simulate(p, w, eng, seed=seed, engine_blocks_fabric=False)
        rows.append({"study": "tspm_ping_pong", "profile": p.name, "workload": w.name, "engine": eng,
                     "baseline_ops_per_s": a["achieved_ops_per_s"], "variant_ops_per_s": b["achieved_ops_per_s"],
                     "speedup": b["achieved_ops_per_s"] / a["achieved_ops_per_s"],
                     "baseline_memory_stall": a["engine_breakdown"][eng]["memory_stall_fraction"],
                     "variant_memory_stall": b["engine_breakdown"][eng]["memory_stall_fraction"],
                     "variant": "engine and DMA on disjoint TSPM halves (hypothetical)", "category": "EVENT_SIMULATED"})
    rel, demo = load_profile(CONFIG_DIR / "silicaflux_v_release1_rtl.yaml"), load_profile(CONFIG_DIR / "silicaflux_130nm_demo.yaml")
    for w, eng in [(wl.gemm(64, 64, 64, "double_buffered"), "tensor"), (wl.gemm(64, 64, 64, "blocked"), "tensor"),
                   (wl.vector_add(4096), "vector"), (wl.dot(4096), "vector"), (wl.conv2d(16, 16, 8, 16), "tensor")]:
        a = sim.simulate(rel, w, eng, seed=seed)
        b = sim.simulate(demo, w, eng, seed=seed)
        rows.append({"study": "dma_vs_cpu_copy_50MHz", "profile": f"{rel.name} -> {demo.name}", "workload": w.name,
                     "engine": eng, "baseline_ops_per_s": a["achieved_ops_per_s"], "variant_ops_per_s": b["achieved_ops_per_s"],
                     "speedup": b["achieved_ops_per_s"] / a["achieved_ops_per_s"],
                     "baseline_memory_stall": a["engine_breakdown"][eng]["memory_stall_fraction"],
                     "variant_memory_stall": b["engine_breakdown"][eng]["memory_stall_fraction"],
                     "variant": "add 1-channel DMA (16 B bursts, 2 outstanding) to the RTL release, same 50 MHz / 32-bit bus",
                     "category": "EVENT_SIMULATED"})
    df = pd.DataFrame(rows)
    (out / "studies").mkdir(parents=True, exist_ok=True)
    df.to_csv(out / "studies" / "what_if_studies.csv", index=False)
    return df
