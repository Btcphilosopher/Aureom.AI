"""Architecture sweep engine: constrained, deterministic experiment selection with resource limits.

Knobs mutate a base profile (dict level) and the result is re-validated by the schema.
Couplings follow the RTL where it defines them:
  vector_lanes     TSPM banks = lanes and the vector operand port = one TSPM row per cycle
                   (sfv_tile.sv: NB = LANES word-interleaved banks)
  tensor_dim       rows = cols = d; operand fetch keeps SilicaFlux-V's sequential A/B word reads
                   scaled to the array width (d bytes per cycle), writeback = one row of d accumulators
  tensor_operand_ports  1 = sequential A/B fetch (SilicaFlux-V RTL), 2 = simultaneous A and B fetch
                   (the double-buffered operand path recorded as a next-revision item)
Selection modes: ofat (baseline + one factor at a time), sample (seeded random subset of the
product, constraint-filtered), grid (full product, refused when larger than max_runs).
"""
from __future__ import annotations

import copy
import itertools
import math
import resource
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import numpy as np
import yaml

from . import machine, simulator as sim, workloads as wl
from .compute import UnsupportedConfiguration
from .config import ConfigError, Profile, profile_from_dict, read_profile_dict
from .event_engine import LimitExceeded, SimulationError
from .units import KiB


def _set(d: dict, path: list, value: Any, provenance: str = "HYPOTHETICAL", source: str = "sweep") -> None:
    cur = d
    for k in path[:-1]:
        if isinstance(k, str) and k.startswith("mem:"):
            name = k[4:]
            cur = next(m for m in cur["memories"] if m["name"] == name)
        else:
            cur = cur.setdefault(k, {})
    cur[path[-1]] = {"value": value, "provenance": provenance, "source": source}


def _get(d: dict, path: list) -> Any:
    cur = d
    for k in path:
        if isinstance(k, str) and k.startswith("mem:"):
            cur = next(m for m in cur["memories"] if m["name"] == k[4:])
        else:
            cur = cur.get(k) if isinstance(cur, dict) else None
        if cur is None:
            return None
    return cur["value"] if isinstance(cur, dict) and "value" in cur else cur


def _home(d: dict) -> str:
    return next(m["name"] for m in d["memories"] if m["kind"] == "sram")


def _spm(d: dict) -> str:
    return next(m["name"] for m in d["memories"] if m["kind"] == "scratchpad")


def k_cpu_cores(d, v):
    _set(d, ["cpu", "cores"], int(v))


def k_vector_lanes(d, v):
    v = int(v)
    _set(d, ["vector", "lanes"], v)
    _set(d, ["vector", "ldst_bytes_per_cycle"], 4 * v, source="sweep: one TSPM row (lanes x 32 b) per cycle")
    _set(d, ["mem:" + _spm(d), "banks"], v, source="sweep: TSPM banks track lanes (sfv_tile.sv)")


def k_tensor_dim(d, v):
    v = int(v)
    ports = int(_get(d, ["_tensor_ports"]) or 1)
    _set(d, ["tensor", "rows"], v)
    _set(d, ["tensor", "cols"], v)
    _set(d, ["tensor", "operand_bytes_per_cycle"], v * ports, source="sweep: d bytes/cycle per operand port")
    _set(d, ["tensor", "writeback_bytes_per_cycle"], 4 * v)


def k_tensor_operand_ports(d, v):
    v = int(v)
    d["_tensor_ports"] = v
    dim = int(_get(d, ["tensor", "rows"]))
    _set(d, ["tensor", "operand_bytes_per_cycle"], dim * v, source="sweep: A and B fetched together" if v == 2 else "sweep")


def k_sram_kib(d, v):
    _set(d, ["mem:" + _home(d), "capacity"], f"{int(v)}KiB")


def k_tspm_kib(d, v):
    _set(d, ["mem:" + _spm(d), "capacity"], f"{int(v)}KiB")


def k_sram_banks(d, v):
    _set(d, ["mem:" + _home(d), "banks"], int(v))


def k_bus_bits(d, v):
    _set(d, ["interconnect", "width_bits"], int(v))


def k_dma_outstanding(d, v):
    if d.get("dma") is None:
        raise UnsupportedConfiguration("profile has no DMA")
    _set(d, ["dma", "max_outstanding"], int(v))
    mo = int(_get(d, ["interconnect", "max_outstanding_per_master"]) or 1)
    _set(d, ["interconnect", "max_outstanding_per_master"], max(mo, int(v)))


def k_dma_burst(d, v):
    _set(d, ["dma", "burst_bytes"], int(v))


def k_clock_hz(d, v):
    _set(d, ["clock", "frequency_hz"], float(v))


KNOBS: dict[str, tuple[Callable, str, str]] = {
    # name: (mutator, resource unit, description)
    "cpu_cores": (k_cpu_cores, "cores", "control cores"),
    "vector_lanes": (k_vector_lanes, "lanes", "SIMD lanes (TSPM banks and port track lanes)"),
    "tensor_dim": (k_tensor_dim, "MACs", "tensor array dimension d (d x d PEs)"),
    "tensor_operand_ports": (k_tensor_operand_ports, "ports", "1 = sequential A/B fetch, 2 = parallel"),
    "sram_kib": (k_sram_kib, "KiB", "main SRAM capacity"),
    "tspm_kib": (k_tspm_kib, "KiB", "tile scratchpad capacity"),
    "sram_banks": (k_sram_banks, "banks", "main SRAM banks"),
    "bus_bits": (k_bus_bits, "bits", "interconnect width"),
    "dma_outstanding": (k_dma_outstanding, "outstanding", "DMA outstanding bursts"),
    "dma_burst": (k_dma_burst, "bytes", "DMA burst size"),
    "clock_hz": (k_clock_hz, "Hz", "system clock"),
}


def baseline_value(d: dict, knob: str) -> Any:
    from .config import coerce_number
    return coerce_number({
        "cpu_cores": lambda: _get(d, ["cpu", "cores"]),
        "vector_lanes": lambda: _get(d, ["vector", "lanes"]),
        "tensor_dim": lambda: _get(d, ["tensor", "rows"]),
        "tensor_operand_ports": lambda: d.get("_tensor_ports", 1),
        "sram_kib": lambda: _parse_kib(_get(d, ["mem:" + _home(d), "capacity"])),
        "tspm_kib": lambda: _parse_kib(_get(d, ["mem:" + _spm(d), "capacity"])),
        "sram_banks": lambda: _get(d, ["mem:" + _home(d), "banks"]),
        "bus_bits": lambda: _get(d, ["interconnect", "width_bits"]),
        "dma_outstanding": lambda: _get(d, ["dma", "max_outstanding"]) if d.get("dma") else None,
        "dma_burst": lambda: _get(d, ["dma", "burst_bytes"]) if d.get("dma") else None,
        "clock_hz": lambda: _get(d, ["clock", "frequency_hz"]),
    }[knob]())


def _parse_kib(v: Any) -> int:
    from .units import parse_size
    return parse_size(v) // KiB


# --------------------------------------------------------------------------- workloads
def make_workload(spec: dict, size: str) -> tuple[wl.Workload, str]:
    kind = spec["kind"]
    s = {"small": 0, "medium": 1, "large": 2}[size]
    if kind == "gemm":
        n = spec.get("n", [32, 64, 128][s])
        return wl.gemm(n, n, n, spec.get("strategy", "double_buffered")), "tensor"
    if kind == "conv2d":
        h = spec.get("h", [8, 16, 32][s])
        return wl.conv2d(h, h, spec.get("cin", 8), spec.get("cout", 16)), "tensor"
    if kind in ("vector_add", "axpy", "dot"):
        n = spec.get("n", [1024, 4096, 16384][s])
        return getattr(wl, kind)(n), "vector"
    if kind == "gemv":
        n = spec.get("n", [16, 32, 64][s])
        return wl.gemv(n, 2 * n), "vector"
    if kind == "fir":
        n = spec.get("n", [1024, 4096, 16384][s])
        return wl.fir(n, spec.get("taps", 16), precision=wl.Precision.INT32), "vector"
    if kind == "cpu_sequential":
        return wl.cpu_sequential(spec.get("n", [512, 2048, 8192][s])), "cpu"
    raise ConfigError(f"sweep: unknown workload kind {kind!r}")


# --------------------------------------------------------------------------- selection
@dataclass
class SweepSpec:
    base_profile: Path
    mode: str
    parameters: dict[str, list]
    workloads: list[dict]
    sizes: list[str]
    fidelity: str = "both"                    # analytical | simulated | both
    sample_n: int = 40
    seed: int = 1
    max_runs: int = 400
    max_wall_s: float = 900.0
    max_events_per_run: int = 5_000_000
    max_memory_mb: int = 4096
    constraints: list[str] = field(default_factory=list)
    name: str = "sweep"


def load_sweep(path: str | Path) -> SweepSpec:
    p = Path(path)
    if not p.exists():
        raise ConfigError(f"sweep file not found: {p}")
    d = yaml.safe_load(p.read_text())
    if not isinstance(d, dict) or "sweep" not in d:
        raise ConfigError(f"{p}: expected a top-level 'sweep:' mapping (is this a profile? use 'roofline'/'simulate')")
    s = d["sweep"]
    unknown = set(s.get("parameters", {})) - set(KNOBS)
    if unknown:
        raise ConfigError(f"{p}: unknown sweep parameters {sorted(unknown)}; known: {sorted(KNOBS)}")
    if s.get("mode", "ofat") not in ("ofat", "sample", "grid"):
        raise ConfigError(f"{p}: mode must be ofat | sample | grid")
    lim = s.get("limits", {})
    from .config import coerce_number
    s["parameters"] = {k: [coerce_number(x) for x in v] for k, v in s.get("parameters", {}).items()}
    return SweepSpec(base_profile=(p.parent / s["base_profile"]).resolve(), mode=s.get("mode", "ofat"),
                     parameters=s.get("parameters", {}), workloads=s.get("workloads", [{"kind": "gemm"}]),
                     sizes=s.get("sizes", ["medium"]), fidelity=s.get("fidelity", "both"),
                     sample_n=int(s.get("sample", {}).get("n", 40)), seed=int(s.get("sample", {}).get("seed", 1)),
                     max_runs=int(lim.get("max_runs", 400)), max_wall_s=float(lim.get("max_wall_s", 900)),
                     max_events_per_run=int(lim.get("max_events_per_run", 5_000_000)),
                     max_memory_mb=int(lim.get("max_memory_mb", 4096)), constraints=s.get("constraints", []),
                     name=s.get("name", p.stem))


def _ok(point: dict, constraints: list[str]) -> bool:
    env = {k: v for k, v in point.items()}
    for c in constraints:
        try:
            if not eval(c, {"__builtins__": {}, "math": math}, env):   # noqa: S307 - expressions over sweep knobs only
                return False
        except NameError:
            continue
    return True


def select_points(spec: SweepSpec, base: dict) -> list[dict]:
    knobs = list(spec.parameters)
    base_pt = {k: baseline_value(base, k) for k in knobs}
    if spec.mode == "ofat":
        pts = [dict(base_pt, _vary="baseline")]
        for k in knobs:
            for v in spec.parameters[k]:
                if v == base_pt[k]:
                    continue
                pts.append(dict(base_pt, **{k: v}, _vary=k))
    elif spec.mode == "grid":
        size = math.prod(len(v) for v in spec.parameters.values())
        if size > spec.max_runs:
            raise ConfigError(f"grid of {size} points exceeds max_runs={spec.max_runs}; use mode: sample or ofat")
        pts = [dict(zip(knobs, combo), _vary="grid") for combo in itertools.product(*spec.parameters.values())]
        pts.insert(0, dict(base_pt, _vary="baseline"))
    else:
        rng = np.random.Generator(np.random.PCG64(spec.seed))
        seen, pts = set(), [dict(base_pt, _vary="baseline")]
        tries = 0
        while len(pts) < spec.sample_n + 1 and tries < 50 * spec.sample_n:
            tries += 1
            pt = {k: spec.parameters[k][int(rng.integers(0, len(spec.parameters[k])))] for k in knobs}
            key = tuple(pt[k] for k in knobs)
            if key in seen:
                continue
            seen.add(key)
            pts.append(dict(pt, _vary="sample"))
    pts = [p for p in pts if p["_vary"] == "baseline" or _ok(p, spec.constraints)]
    return pts[: spec.max_runs]


def build_point(base: dict, pt: dict) -> Profile:
    """Apply only the knobs whose value differs from the base profile (couplings never alter the baseline)."""
    d = copy.deepcopy(base)
    changed = {k: v for k, v in pt.items() if not k.startswith("_") and v is not None and v != baseline_value(base, k)}
    if "tensor_operand_ports" in changed:      # ports before dim so the dim knob sees the port count
        KNOBS["tensor_operand_ports"][0](d, changed.pop("tensor_operand_ports"))
    for k in sorted(changed, key=lambda k: (k == "tensor_dim", k)):
        KNOBS[k][0](d, changed[k])
    d.pop("_tensor_ports", None)
    tag = ",".join(f"{k}={pt[k]}" for k in sorted(pt) if not k.startswith("_") and pt[k] != baseline_value(base, k))
    d["name"] = d.get("name", "profile") + ("@" + tag if tag else "@baseline")
    return profile_from_dict(d)


# --------------------------------------------------------------------------- run
def _maxrss_mb() -> float:
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024


def evaluate(p: Profile, w: wl.Workload, eng: str, fidelity: str, max_events: int) -> dict:
    row: dict[str, Any] = {}
    try:
        a = machine.analyse(p, w, eng)
        row.update(analytical_ceiling=a["ceiling"], analytical_binding=a["binding"], analytical_bound=a["bound"],
                   peak=a["peak"], rate_unit=a["rate_unit"],
                   intensity_binding=next((lv["intensity"] for lv in a["levels"] if lv["level"] == a["binding"]),
                                          min(lv["intensity"] for lv in a["levels"])),
                   unused_compute_fraction_ceiling=a["unused_compute_fraction"],
                   engine_model_utilisation=a["engine_model"]["engine_utilisation"])
    except (UnsupportedConfiguration, wl.InfeasibleStrategy) as e:
        row.update(status="unsupported", error=str(e))
        return row
    if fidelity in ("simulated", "both"):
        try:
            r = sim.simulate(p, w, eng, max_events=max_events, wall_limit_s=120)
            eb = r["engine_breakdown"].get(eng, {})
            mem = r["memories"]
            home = next((k for k in mem if k == "sram"), next(iter(mem)))
            row.update(
                status="ok", sim_throughput=r["achieved_ops_per_s"], sim_time_s=r["makespan_s"],
                sim_compute_utilisation=r["compute_utilisation"], sim_bound=r["classification"]["bound"],
                sim_reason=r["classification"]["reason"], busiest_resource=r["classification"]["busiest_resource"],
                busiest_utilisation=r["classification"]["busiest_utilisation"],
                engine_busy=eb.get("busy_fraction"), memory_stall=eb.get("memory_stall_fraction"),
                dependency_stall=eb.get("dependency_stall_fraction"),
                sustained_Bps=r["sustained_Bps"], lat_mean=r["latency_cycles"]["mean"],
                lat_p95=r["latency_cycles"]["p95"], lat_p99=r["latency_cycles"]["p99"],
                sram_bank_conflict_cycles=sum(mem[home].get("bank_conflict_cycles", [0])),
                sram_utilisation=mem[home].get("utilisation"),
                ic_max_utilisation=r["interconnect"]["max_channel_utilisation"],
                dma_utilisation=(r.get("dma") or {}).get("busy_fraction"),
                avg_ic_wait=np.mean([m["avg_wait_cycles"] for m in r["interconnect"]["masters"].values()] or [0]),
                events=r["events"], wall_s=r["wall_s"])
        except LimitExceeded as e:
            row.update(status="limit", error=str(e))
        except (UnsupportedConfiguration, wl.InfeasibleStrategy, SimulationError) as e:
            row.update(status="unsupported", error=str(e))
    else:
        row["status"] = "ok"
    return row


def run_sweep(spec: SweepSpec, progress: Callable[[str], None] | None = None) -> dict:
    from .optimisation import area_model
    base = read_profile_dict(spec.base_profile)
    pts = select_points(spec, base)
    t0 = time.perf_counter()
    rows: list[dict] = []
    stopped = None
    for i, pt in enumerate(pts):
        if time.perf_counter() - t0 > spec.max_wall_s:
            stopped = f"max_wall_s={spec.max_wall_s} reached after {i} points"
            break
        if _maxrss_mb() > spec.max_memory_mb:
            stopped = f"max_memory_mb={spec.max_memory_mb} exceeded after {i} points"
            break
        try:
            prof = build_point(base, pt)
        except (ConfigError, UnsupportedConfiguration) as e:
            rows.append({**{k: v for k, v in pt.items()}, "point": i, "status": "invalid", "error": str(e)})
            continue
        area = area_model(prof)
        for wspec in spec.workloads:
            for size in spec.sizes:
                w, eng = make_workload(wspec, size)
                r = evaluate(prof, w, eng, spec.fidelity, spec.max_events_per_run)
                rows.append({**{k: v for k, v in pt.items()}, "point": i, "workload": w.name,
                             "workload_kind": wspec["kind"], "size": size, "engine": eng,
                             "area_mm2": area["total_mm2"], "area_provenance": area["provenance"],
                             "macs": area["units"]["macs"], "lanes": area["units"]["lanes"],
                             "sram_kib_total": area["units"]["sram_kib"], **r})
        if progress:
            progress(f"[{i + 1}/{len(pts)}] {pt}")
    import pandas as pd
    df = pd.DataFrame(rows)
    # relative to the fixed baseline (point 0) per workload
    if not df.empty and "sim_throughput" in df:
        for col in ("sim_throughput", "analytical_ceiling", "sim_time_s"):
            if col in df:
                b = df[df["point"] == 0].set_index("workload")[col]
                df[f"{col}_vs_baseline"] = df.apply(
                    lambda r, b=b, col=col: (r[col] / b.get(r["workload"]) if (r.get(col) == r.get(col) and
                                             b.get(r["workload"]) not in (None, 0) and b.get(r["workload"]) == b.get(r["workload"]))
                                             else None), axis=1)
    return {"spec": spec, "points": pts, "df": df, "stopped": stopped, "wall_s": time.perf_counter() - t0}
