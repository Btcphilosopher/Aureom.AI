"""Marginal-gain, diminishing-returns and Pareto analysis over sweep results.

Costs: an explicit area model (mm^2) whose every coefficient carries provenance.  For
SilicaFlux-V the SRAM coefficient (IHP SG13G2 macro datasheet area per KiB, macro only)
and the fixed logic area (whole-SoC synthesised std-cell area) are VERIFIED_REPO; all
per-unit logic coefficients (per MAC, lane, bank, bus bit, DMA slot, core) are HYPOTHETICAL
because the repository's synthesis is flattened.  Resource units (MACs, lanes, KiB, banks,
bus bits) are reported alongside so marginal gains can be read without the area model.
A model-based Pareto front is NOT a proof of physical-design optimality.
"""
from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd

from .config import Profile
from .provenance import combine


def area_model(p: Profile) -> dict[str, Any]:
    a = p.area
    sram_kib = sum((m.capacity_bytes or 0) for m in p.memories if m.kind in ("sram", "scratchpad", "cache")) / 1024
    macs = (int(p.tensor.rows.v) * int(p.tensor.cols.v)) if (p.tensor and p.tensor.enabled) else 0
    lanes = int(p.vector.lanes.v) if (p.vector and p.vector.enabled) else 0
    banks = sum(int(m.banks.v) for m in p.memories if m.kind in ("sram", "scratchpad"))
    bus = int(p.interconnect.width_bits.v)
    dma_o = int(p.dma.max_outstanding.v) * int(p.dma.channels.v) if (p.dma and p.dma.enabled) else 0
    cores = int(p.cpu.cores.v)
    parts = {
        "sram_mm2": sram_kib * float(a.sram_mm2_per_kib.v),
        "logic_fixed_mm2": float(a.logic_fixed_mm2.v),
        "macs_mm2": macs * float(a.mm2_per_mac.v),
        "lanes_mm2": lanes * float(a.mm2_per_vector_lane.v),
        "banks_mm2": banks * float(a.mm2_per_bank.v),
        "bus_mm2": bus * float(a.mm2_per_bus_bit.v),
        "dma_mm2": dma_o * float(a.mm2_per_dma_outstanding.v),
        "cores_mm2": max(0, cores - 1) * float(a.mm2_per_core.v),
    }
    return {"total_mm2": sum(parts.values()), "parts": parts,
            "units": {"sram_kib": sram_kib, "macs": macs, "lanes": lanes, "banks": banks, "bus_bits": bus,
                      "dma_outstanding": dma_o, "cores": cores},
            "provenance": combine(getattr(a, f).provenance for f in type(a).model_fields),
            "note": "macro-only SRAM area (lower bound); logic coefficients hypothetical unless sourced"}


def _metric(df: pd.DataFrame) -> str:
    return "sim_throughput" if "sim_throughput" in df and df["sim_throughput"].notna().any() else "analytical_ceiling"


def marginal_gains(df: pd.DataFrame, knob_units: dict[str, str], *, saturation: float = 0.10) -> pd.DataFrame:
    """Per knob (OFAT rows), per workload: gains between consecutive values of the knob.

    Columns: from/to value, absolute and relative performance change, change in execution time,
    sustained bandwidth and area, gain per added resource unit and per added mm^2, and a
    diminishing-returns flag when the relative gain per step falls below ``saturation``.
    """
    metric = _metric(df)
    out = []
    base = df[df["_vary"] == "baseline"]
    for knob in [k for k in knob_units if k in df.columns]:
        sub = pd.concat([df[df["_vary"] == knob], base])
        for wname, g in sub.groupby("workload"):
            g = g.dropna(subset=[metric]).sort_values(knob)
            vals = g.to_dict("records")
            for a, b in zip(vals, vals[1:]):
                dp = b[metric] - a[metric]
                rel = dp / a[metric] if a[metric] else math.nan
                du = (b[knob] - a[knob])
                darea = (b.get("area_mm2") or 0) - (a.get("area_mm2") or 0)
                out.append({
                    "knob": knob, "workload": wname, "from": a[knob], "to": b[knob], "metric": metric,
                    "perf_from": a[metric], "perf_to": b[metric], "abs_gain": dp, "rel_gain": rel,
                    "time_change_s": (b.get("sim_time_s") or math.nan) - (a.get("sim_time_s") or math.nan),
                    "bandwidth_change_Bps": (b.get("sustained_Bps") or math.nan) - (a.get("sustained_Bps") or math.nan),
                    "area_change_mm2": darea, "unit": knob_units[knob],
                    "gain_per_unit": dp / du if du else math.nan,
                    "gain_per_mm2": dp / darea if darea else math.nan,
                    "bound_to": b.get("sim_bound") or b.get("analytical_bound"),
                    "binding_to": b.get("busiest_resource") or b.get("analytical_binding"),
                    "diminishing": bool(rel == rel and rel < saturation),
                })
    return pd.DataFrame(out)


def saturation_points(mg: pd.DataFrame) -> pd.DataFrame:
    """First knob value beyond which the next step gains less than the saturation threshold."""
    rows = []
    for (knob, wname), g in mg.groupby(["knob", "workload"]):
        g = g.sort_values("from")
        sat = g[g["diminishing"]]
        if len(sat):
            r = sat.iloc[0]
            rows.append({"knob": knob, "workload": wname, "saturates_at": r["from"],
                         "next_step_rel_gain": r["rel_gain"], "limited_by": r["binding_to"], "bound": r["bound_to"]})
        else:
            rows.append({"knob": knob, "workload": wname, "saturates_at": None,
                         "next_step_rel_gain": g["rel_gain"].iloc[-1] if len(g) else None,
                         "limited_by": None, "bound": None})
    return pd.DataFrame(rows)


def pareto(df: pd.DataFrame, *, objectives: dict[str, str], constraints: dict[str, float] | None = None) -> pd.DataFrame:
    """Non-dominated points. objectives: {column: 'max'|'min'}; constraints: {column: upper bound}."""
    d = df.copy()
    for c, ub in (constraints or {}).items():
        d = d[d[c] <= ub]
    d = d.dropna(subset=list(objectives))
    if d.empty:
        return d.assign(pareto=[])
    vals = np.column_stack([d[c].to_numpy() * (-1 if s == "max" else 1) for c, s in objectives.items()])
    n = len(vals)
    dominated = np.zeros(n, dtype=bool)
    for i in range(n):
        if dominated[i]:
            continue
        le = (vals <= vals[i]).all(axis=1)
        lt = (vals < vals[i]).any(axis=1)
        if (le & lt).any():
            dominated[i] = True
    d = d.assign(pareto=~dominated)
    return d


def geomean_by_point(df: pd.DataFrame, metric: str | None = None) -> pd.DataFrame:
    """Geometric mean of the per-workload throughput normalised to the baseline, per sweep point."""
    m = metric or _metric(df)
    col = f"{m}_vs_baseline"
    g = df.dropna(subset=[col]).groupby("point")
    out = g.agg(geomean_speedup=(col, lambda x: float(np.exp(np.log(x.clip(lower=1e-12)).mean()))),
                area_mm2=("area_mm2", "first"), sram_kib_total=("sram_kib_total", "first"), macs=("macs", "first"),
                lanes=("lanes", "first"), workloads=("workload", "nunique")).reset_index()
    return out
