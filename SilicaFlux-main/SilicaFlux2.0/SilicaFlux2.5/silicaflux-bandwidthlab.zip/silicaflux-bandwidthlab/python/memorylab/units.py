"""Explicit, checked units for operations, throughput and bandwidth.

Conventions (documented in docs/memorylab/model_reference.md):

* ``OpKind.MAC``    one multiply-accumulate (a*b + c).
* ``OpKind.INT_OP`` one integer arithmetic operation (add, mul, shift, ...).
* ``OpKind.FLOP``   one floating-point arithmetic operation.
* One MAC counts as ``OpConvention.ops_per_mac`` arithmetic operations
  (default 2: one multiply plus one add).  This is the only conversion the
  library performs between kinds, and it is always explicit.
* Integer and floating-point operations are never interconvertible.  INT8
  TOPS cannot be compared with FP32 TFLOP/s; such comparisons raise
  :class:`UnitMismatchError`.
* Bytes are 8-bit octets.  KiB = 1024 B, MiB = 1024 KiB.  GB/s = 1e9 B/s.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math

KiB = 1024
MiB = 1024 * KiB
GB = 1e9  # decimal, for bandwidth (bytes/s)


class UnitMismatchError(ValueError):
    """Raised when two quantities with incompatible units are combined."""


class OpKind(str, Enum):
    MAC = "MAC"
    INT_OP = "INT_OP"
    FLOP = "FLOP"

    @property
    def rate_unit(self) -> str:
        return {"MAC": "MAC/s", "INT_OP": "OPS/s", "FLOP": "FLOP/s"}[self.value]

    @property
    def intensity_unit(self) -> str:
        return {"MAC": "MAC/B", "INT_OP": "OPS/B", "FLOP": "FLOP/B"}[self.value]


class Precision(str, Enum):
    INT8 = "int8"
    UINT8 = "uint8"
    INT16 = "int16"
    INT32 = "int32"
    FP16 = "fp16"
    BF16 = "bf16"
    FP32 = "fp32"
    FP64 = "fp64"

    @property
    def bytes(self) -> int:
        return {
            "int8": 1, "uint8": 1, "int16": 2, "int32": 4,
            "fp16": 2, "bf16": 2, "fp32": 4, "fp64": 8,
        }[self.value]

    @property
    def is_float(self) -> bool:
        return self.value in ("fp16", "bf16", "fp32", "fp64")

    @property
    def arithmetic_kind(self) -> OpKind:
        """The non-MAC operation kind that matches this precision's domain."""
        return OpKind.FLOP if self.is_float else OpKind.INT_OP


@dataclass(frozen=True)
class OpConvention:
    """How MACs relate to arithmetic operations.  Always recorded in reports."""

    ops_per_mac: int = 2

    def __post_init__(self) -> None:
        if self.ops_per_mac not in (1, 2):
            raise ValueError("ops_per_mac must be 1 (MAC counted as one op) or 2 (multiply + add)")

    def describe(self) -> str:
        return (f"1 MAC = {self.ops_per_mac} arithmetic operation(s); integer and floating-point "
                f"operations are never interconverted")


DEFAULT_CONVENTION = OpConvention(2)


def _check_kind_convertible(src: OpKind, dst: OpKind, precision: Precision) -> None:
    if src == dst:
        return
    if src == OpKind.MAC and dst == precision.arithmetic_kind:
        return
    if dst == OpKind.MAC and src == precision.arithmetic_kind:
        return
    raise UnitMismatchError(
        f"cannot convert {src.value} to {dst.value} for precision {precision.value}: "
        "integer operations and floating-point operations are not interchangeable")


def convert_count(value: float, src: OpKind, dst: OpKind, precision: Precision,
                  convention: OpConvention = DEFAULT_CONVENTION) -> float:
    """Convert an operation count/rate between MAC and arithmetic ops (explicitly)."""
    _check_kind_convertible(src, dst, precision)
    if src == dst:
        return value
    if src == OpKind.MAC:
        return value * convention.ops_per_mac
    return value / convention.ops_per_mac


@dataclass(frozen=True)
class OpCount:
    """A number of operations of one kind at one precision."""

    value: float
    kind: OpKind
    precision: Precision

    def __post_init__(self) -> None:
        if not math.isfinite(self.value) or self.value < 0:
            raise ValueError(f"operation count must be finite and >= 0, got {self.value}")
        if self.kind == OpKind.FLOP and not self.precision.is_float:
            raise UnitMismatchError(f"FLOP count with integer precision {self.precision.value}")
        if self.kind == OpKind.INT_OP and self.precision.is_float:
            raise UnitMismatchError(f"integer OP count with float precision {self.precision.value}")

    def to(self, kind: OpKind, convention: OpConvention = DEFAULT_CONVENTION) -> "OpCount":
        return OpCount(convert_count(self.value, self.kind, kind, self.precision, convention),
                       kind, self.precision)


@dataclass(frozen=True)
class Throughput:
    """Operations per second of one kind at one precision."""

    value: float
    kind: OpKind
    precision: Precision

    def __post_init__(self) -> None:
        if not math.isfinite(self.value) or self.value < 0:
            raise ValueError(f"throughput must be finite and >= 0, got {self.value}")
        if self.kind == OpKind.FLOP and not self.precision.is_float:
            raise UnitMismatchError(f"FLOP/s with integer precision {self.precision.value}")
        if self.kind == OpKind.INT_OP and self.precision.is_float:
            raise UnitMismatchError(f"OPS/s with float precision {self.precision.value}")

    def to(self, kind: OpKind, convention: OpConvention = DEFAULT_CONVENTION) -> "Throughput":
        return Throughput(convert_count(self.value, self.kind, kind, self.precision, convention),
                          kind, self.precision)

    @property
    def unit(self) -> str:
        return f"{self.kind.rate_unit} ({self.precision.value})"

    def human(self) -> str:
        return f"{si(self.value)}{self.kind.rate_unit} [{self.precision.value}]"


def require_compatible(a_kind: OpKind, a_prec: Precision, b_kind: OpKind, b_prec: Precision) -> None:
    """Workload and engine must share precision and a convertible operation kind."""
    if a_prec != b_prec:
        raise UnitMismatchError(
            f"precision mismatch: workload {a_prec.value} vs engine peak {b_prec.value}; "
            "use the engine's peak for the workload's precision")
    _check_kind_convertible(a_kind, b_kind, a_prec)


def si(x: float, digits: int = 3) -> str:
    """Format a number with an SI prefix (no unit)."""
    if x == 0:
        return "0 "
    if not math.isfinite(x):
        return f"{x} "
    prefixes = [(1e15, "P"), (1e12, "T"), (1e9, "G"), (1e6, "M"), (1e3, "k"), (1, ""),
                (1e-3, "m"), (1e-6, "u"), (1e-9, "n"), (1e-12, "p")]
    ax = abs(x)
    for scale, p in prefixes:
        if ax >= scale:
            return f"{x / scale:.{digits}g} {p}"
    return f"{x:.{digits}g} "


def bytes_human(n: float) -> str:
    if n >= MiB:
        return f"{n / MiB:.4g} MiB"
    if n >= KiB:
        return f"{n / KiB:.4g} KiB"
    return f"{n:.0f} B"


def parse_size(value: int | float | str) -> int:
    """Parse '256KiB', '1 MiB', '64B' or a plain integer number of bytes."""
    if isinstance(value, (int, float)):
        if value < 0 or (isinstance(value, float) and not value.is_integer()):
            raise ValueError(f"size must be a non-negative integer number of bytes: {value}")
        return int(value)
    s = value.strip().replace(" ", "")
    for suffix, mult in (("MiB", MiB), ("KiB", KiB), ("B", 1)):
        if s.endswith(suffix):
            num = s[: -len(suffix)]
            v = float(num) * mult
            if not v.is_integer() or v < 0:
                raise ValueError(f"size {value!r} is not a whole number of bytes")
            return int(v)
    if s.isdigit():
        return int(s)
    raise ValueError(f"cannot parse size {value!r}: use e.g. '256KiB', '1MiB' or bytes")
