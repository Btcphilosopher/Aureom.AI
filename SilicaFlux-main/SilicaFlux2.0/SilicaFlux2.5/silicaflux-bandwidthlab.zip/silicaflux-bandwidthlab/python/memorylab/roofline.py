"""Analytical Roofline engine (single-level and hierarchical).

Single level:      P = min(P_peak, I * B)
Hierarchical:      P <= min(P_peak, B_1*I_1, ..., B_n*I_n),   I_l = W / Q_l
Equivalent time:   T >= max(W / P_peak, Q_1 / B_1, ..., Q_n / B_n)

W   = work (operations, one kind, one precision)
Q_l = bytes that cross the interface of memory level l (reads + writes,
      each byte counted once per level; the caller supplies per-level traffic
      from a workload model, levels are never summed together)
B_l = sustained bandwidth of that interface in bytes/s

Latency (Little's law): if a level declares a request latency L and a
maximum number of bytes in flight O (outstanding requests x request size),
the bandwidth that can actually be sustained is min(B_l, O / L).  When that
concurrency limit is the binding constraint the point is classified
LATENCY_BOUND.  This is the only latency effect the analytical model
represents; queueing and contention are the domain of the event simulator.

All results are upper bounds (ANALYTICAL_CEILING), never predictions of
achieved performance.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
import math
from typing import Iterable, Mapping, Sequence

from .units import (DEFAULT_CONVENTION, OpConvention, OpCount, OpKind, Throughput,
                    UnitMismatchError, require_compatible)


class Bound(str, Enum):
    COMPUTE_BOUND = "COMPUTE_BOUND"
    BANDWIDTH_BOUND = "BANDWIDTH_BOUND"
    LATENCY_BOUND = "LATENCY_BOUND"


def roofline_ceiling(peak: float, intensity: float, bandwidth: float) -> float:
    """P = min(P_peak, I * B).  Units: peak [ops/s], intensity [ops/B], bandwidth [B/s]."""
    for name, v in (("peak", peak), ("bandwidth", bandwidth)):
        if not (math.isfinite(v) and v > 0):
            raise ValueError(f"{name} must be finite and > 0, got {v}")
    if math.isnan(intensity) or intensity < 0:
        raise ValueError(f"arithmetic intensity must be >= 0, got {intensity}")
    if math.isinf(intensity):
        return peak
    return min(peak, intensity * bandwidth)


def ridge_point(peak: float, bandwidth: float) -> float:
    """Arithmetic intensity at which the bandwidth roof meets the compute roof [ops/B]."""
    if peak <= 0 or bandwidth <= 0:
        raise ValueError("peak and bandwidth must be > 0")
    return peak / bandwidth


def classify_single(peak: float, intensity: float, bandwidth: float) -> Bound:
    return Bound.COMPUTE_BOUND if intensity * bandwidth >= peak else Bound.BANDWIDTH_BOUND


@dataclass(frozen=True)
class MemoryLevel:
    """One memory interface seen by a compute domain."""

    name: str
    bandwidth_Bps: float                     # sustained bytes/s at this interface
    latency_s: float | None = None           # request latency (for Little's law)
    max_inflight_bytes: float | None = None  # outstanding requests x request bytes
    provenance: str = "HYPOTHETICAL"

    def __post_init__(self) -> None:
        if not (math.isfinite(self.bandwidth_Bps) and self.bandwidth_Bps > 0):
            raise ValueError(f"level {self.name}: bandwidth must be > 0 B/s")
        if (self.latency_s is None) != (self.max_inflight_bytes is None):
            raise ValueError(f"level {self.name}: latency_s and max_inflight_bytes must be given together")
        if self.latency_s is not None and (self.latency_s <= 0 or self.max_inflight_bytes <= 0):
            raise ValueError(f"level {self.name}: latency and in-flight bytes must be > 0")

    @property
    def concurrency_bandwidth_Bps(self) -> float:
        """Little's-law limit O / L, or +inf when not specified."""
        if self.latency_s is None:
            return math.inf
        return self.max_inflight_bytes / self.latency_s

    @property
    def effective_bandwidth_Bps(self) -> float:
        return min(self.bandwidth_Bps, self.concurrency_bandwidth_Bps)

    @property
    def latency_limited(self) -> bool:
        return self.concurrency_bandwidth_Bps < self.bandwidth_Bps


@dataclass(frozen=True)
class LevelTraffic:
    read_bytes: float
    write_bytes: float

    def __post_init__(self) -> None:
        if self.read_bytes < 0 or self.write_bytes < 0:
            raise ValueError("traffic must be >= 0 bytes")

    @property
    def total(self) -> float:
        return self.read_bytes + self.write_bytes


@dataclass
class LevelResult:
    level: str
    bandwidth_Bps: float
    effective_bandwidth_Bps: float
    latency_limited: bool
    bytes: float
    read_bytes: float
    write_bytes: float
    intensity: float          # ops per byte (in the result's op kind)
    ceiling: float            # ops/s
    time_lower_bound_s: float
    ridge_point: float
    provenance: str


@dataclass
class RooflineResult:
    workload: str
    engine: str
    kind: OpKind
    precision: str
    work_ops: float
    peak: float
    compute_time_s: float
    levels: list[LevelResult]
    ceiling: float
    time_lower_bound_s: float
    binding: str                      # "compute" or the binding level name
    bound: Bound
    convention: str
    category: str = "ANALYTICAL_CEILING"
    notes: list[str] = field(default_factory=list)

    @property
    def unused_compute_fraction(self) -> float:
        """Fraction of peak compute that this ceiling cannot use (1 - P/P_peak)."""
        return 1.0 - self.ceiling / self.peak

    @property
    def compute_utilisation_ceiling(self) -> float:
        return self.ceiling / self.peak

    def to_dict(self) -> dict:
        d = asdict(self)
        d["kind"] = self.kind.value
        d["bound"] = self.bound.value
        d["unused_compute_fraction"] = self.unused_compute_fraction
        d["rate_unit"] = self.kind.rate_unit
        d["intensity_unit"] = self.kind.intensity_unit
        return d


def hierarchical_roofline(*, workload: str, engine: str, work: OpCount, peak: Throughput,
                          levels: Sequence[MemoryLevel], traffic: Mapping[str, LevelTraffic],
                          kind: OpKind | None = None,
                          convention: OpConvention = DEFAULT_CONVENTION,
                          allow_missing_levels: bool = False) -> RooflineResult:
    """Hierarchical Roofline ceiling for one workload on one compute domain.

    ``work`` and ``peak`` must share precision; their kinds are converted to
    ``kind`` (default: the peak's kind) using only the explicit MAC convention.
    Every level in ``levels`` must have an entry in ``traffic`` unless
    ``allow_missing_levels`` (missing levels are then reported as unconstrained,
    which is recorded in ``notes``).
    """
    require_compatible(work.kind, work.precision, peak.kind, peak.precision)
    k = kind or peak.kind
    w = work.to(k, convention).value
    p = peak.to(k, convention).value
    if p <= 0:
        raise ValueError(f"{engine}: peak throughput is zero for {work.precision.value}")
    if w <= 0:
        raise ValueError(f"{workload}: work must be > 0 operations for a Roofline point")
    names = [lv.name for lv in levels]
    if len(set(names)) != len(names):
        raise ValueError(f"duplicate memory level names: {names}")
    unknown = set(traffic) - set(names)
    if unknown:
        raise ValueError(f"traffic given for unknown levels {sorted(unknown)}")

    notes: list[str] = []
    t_compute = w / p
    results: list[LevelResult] = []
    for lv in levels:
        tr = traffic.get(lv.name)
        if tr is None:
            if not allow_missing_levels:
                raise ValueError(f"no traffic supplied for level '{lv.name}'")
            notes.append(f"level {lv.name}: traffic not modelled -> not a constraint")
            continue
        q = tr.total
        intensity = math.inf if q == 0 else w / q
        beff = lv.effective_bandwidth_Bps
        ceiling = roofline_ceiling(p, intensity, beff)
        results.append(LevelResult(
            level=lv.name, bandwidth_Bps=lv.bandwidth_Bps, effective_bandwidth_Bps=beff,
            latency_limited=lv.latency_limited, bytes=q, read_bytes=tr.read_bytes,
            write_bytes=tr.write_bytes, intensity=intensity, ceiling=ceiling,
            time_lower_bound_s=q / beff, ridge_point=ridge_point(p, beff), provenance=lv.provenance))

    t_bound = max([t_compute] + [r.time_lower_bound_s for r in results])
    ceiling = w / t_bound
    # binding constraint: compute wins ties (a point exactly on the ridge is compute-bound)
    binding, bound = "compute", Bound.COMPUTE_BOUND
    worst = max(results, key=lambda r: r.time_lower_bound_s, default=None)
    if worst is not None and worst.time_lower_bound_s > t_compute * (1 + 1e-12):
        binding = worst.level
        lv = next(x for x in levels if x.name == worst.level)
        bound = Bound.LATENCY_BOUND if lv.latency_limited else Bound.BANDWIDTH_BOUND
    # numerical consistency with the min() form
    alt = min([p] + [r.ceiling for r in results])
    if not math.isclose(alt, ceiling, rel_tol=1e-9):
        raise AssertionError(f"internal: min-form {alt} != time-form {ceiling}")
    return RooflineResult(workload=workload, engine=engine, kind=k, precision=work.precision.value,
                          work_ops=w, peak=p, compute_time_s=t_compute, levels=results,
                          ceiling=ceiling, time_lower_bound_s=t_bound, binding=binding,
                          bound=bound, convention=convention.describe(), notes=notes)


@dataclass
class ConcurrentPart:
    name: str
    engine: str
    work: OpCount
    peak: Throughput
    traffic: Mapping[str, LevelTraffic]


def concurrent_roofline(parts: Iterable[ConcurrentPart], levels: Sequence[MemoryLevel],
                        convention: OpConvention = DEFAULT_CONVENTION) -> dict:
    """Lower bound on the makespan of independent workloads running concurrently.

    Each part runs on its own engine (T >= W_e / P_e) and all parts share
    every memory level (T >= sum_e Q_{e,l} / B_l).  Work of different kinds or
    precisions is reported per part, never summed.
    """
    parts = list(parts)
    if not parts:
        raise ValueError("no parts")
    engines = [p.engine for p in parts]
    if len(set(engines)) != len(engines):
        raise ValueError("each concurrent part needs its own engine (the same engine would serialise)")
    t_parts = {}
    for p in parts:
        require_compatible(p.work.kind, p.work.precision, p.peak.kind, p.peak.precision)
        t_parts[p.name] = p.work.to(p.peak.kind, convention).value / p.peak.value
    t_levels = {}
    for lv in levels:
        q = sum(p.traffic[lv.name].total for p in parts if lv.name in p.traffic)
        t_levels[lv.name] = q / lv.effective_bandwidth_Bps
    t = max(list(t_parts.values()) + list(t_levels.values()))
    binding = max({**{f"compute:{k}": v for k, v in t_parts.items()},
                   **{f"level:{k}": v for k, v in t_levels.items()}}.items(), key=lambda kv: kv[1])[0]
    return {"makespan_lower_bound_s": t, "per_part_compute_s": t_parts,
            "per_level_transfer_s": t_levels, "binding": binding, "category": "ANALYTICAL_CEILING"}


def check_same_domain(results: Sequence[RooflineResult]) -> None:
    """Results plotted on one Roofline must share op kind and precision."""
    keys = {(r.kind, r.precision) for r in results}
    if len(keys) > 1:
        raise UnitMismatchError(f"cannot place mixed op kinds/precisions on one Roofline: {sorted(keys)}")
