"""SilicaFlux MemoryLab: analytical Roofline + discrete-event memory-performance simulator.

Two independently testable engines:
  * memorylab.roofline / machine   -- ANALYTICAL_CEILING (upper bounds, unit-checked)
  * memorylab.event_engine / sram / interconnect / dma / dram / cache / simulator -- EVENT_SIMULATED
RTL evidence (RTL_OBSERVED) comes from memorylab.rtl_integration; silicon data does not exist.
"""
from .provenance import SIMULATOR_VERSION as __version__  # noqa: F401
