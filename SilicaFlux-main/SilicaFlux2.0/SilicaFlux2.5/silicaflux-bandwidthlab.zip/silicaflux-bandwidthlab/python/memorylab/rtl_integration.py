"""Integration with the SilicaFlux SRAM Wrapper Library (Project 01) and RTL simulators.

* ``locate_sramlib``  finds the library: an extracted directory, or the archive
  SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip in the repository
  (extracted into a build directory; the repository is never modified).
* ``sramlib_profile`` reads the library's real module parameters and documented
  contract (interface spec, bank controller defaults) into a MemoryLab adapter dict.
* ``run_rtl_bank_trace`` builds tb_memorylab_bank_trace.sv + the unmodified library RTL
  with Verilator (or Icarus) and executes a stimulus file.
* ``compare_traces`` compares the RTL trace with the Python cycle model transaction by
  transaction: acceptance cycle, conflict stalls, response cycle, response order/ID,
  error flag, write-ack flag and read data on known bits.

Equivalence is only ever claimed for the configurations actually compared.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from . import bankbench as bb
from .provenance import sha256_file
from .sram import BankCtrlConfig

HARNESS = Path(__file__).resolve().parents[2] / "rtl_harness" / "tb_memorylab_bank_trace.sv"
SRAMLIB_ZIP_REL = Path("SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip")
VL_FLAGS = ["--binary", "--timing", "--timescale", "1ns/1ps", "--assert", "-DSRAMLIB_ASSERT", "-DSRAMLIB_POISON",
            "--x-assign", "unique", "--x-initial", "unique", "-Wno-fatal", "-Wno-DECLFILENAME", "-Wno-MULTITOP",
            "-Wno-UNUSEDSIGNAL", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC", "-j", "2"]


class RtlUnavailable(RuntimeError):
    """Simulator or library not available; RTL comparison remains pending."""


def find_repo_root(start: Path | None = None) -> Path | None:
    import os
    env = os.environ.get("SILICAFLUX_REPO")
    if env and (Path(env) / SRAMLIB_ZIP_REL).exists():
        return Path(env)
    p = (start or Path.cwd()).resolve()
    for q in [p, *p.parents]:
        if (q / SRAMLIB_ZIP_REL).exists():
            return q
    return None


def locate_sramlib(path: str | Path | None = None, build_dir: str | Path = "build/memorylab") -> Path:
    """Return the root of silicaflux-sramlib (directory containing rtl/mem/sram_bank_controller.sv)."""
    cands: list[Path] = []
    if path:
        cands.append(Path(path))
    repo = find_repo_root(Path(__file__).resolve())
    if repo:
        cands += [repo / "SilicaFlux-main/silicaflux-sramlib", repo / SRAMLIB_ZIP_REL]
    for c in cands:
        if c.is_dir():
            root = c if (c / "rtl/mem/sram_bank_controller.sv").exists() else c / "silicaflux-sramlib"
            if (root / "rtl/mem/sram_bank_controller.sv").exists():
                return root
        if c.is_file() and c.suffix == ".zip":
            dest = Path(build_dir) / "sramlib"
            root = dest / "silicaflux-sramlib"
            if not (root / "rtl/mem/sram_bank_controller.sv").exists():
                dest.mkdir(parents=True, exist_ok=True)
                with zipfile.ZipFile(c) as z:
                    for n in z.namelist():
                        if ".." in Path(n).parts or n.startswith("/"):
                            raise RtlUnavailable(f"unsafe path in {c}: {n}")
                    z.extractall(dest)
            return root
    raise RtlUnavailable("silicaflux-sramlib not found (pass --sramlib <dir|zip>); the standalone "
                         "reference profile remains usable and the integration contract is in docs/memorylab")


def sramlib_profile(root: Path) -> dict[str, Any]:
    """Extract the library's actual parameters/semantics (adapter for MemoryLab models)."""
    bc = (root / "rtl/mem/sram_bank_controller.sv").read_text()
    spec = (root / "docs/mem/01_interface_spec.md").read_text() if (root / "docs/mem/01_interface_spec.md").exists() else ""

    def param(name: str, text: str = bc) -> str | None:
        m = re.search(rf"parameter\s+int\s+{name}\s*=\s*([^,\n]+)", text)
        return m.group(1).strip() if m else None
    modules = sorted({m for f in (root / "rtl/mem").rglob("*.sv")
                      for m in re.findall(r"^\s*module\s+(\w+)", f.read_text(), re.M)})
    return {
        "library_root": str(root),
        "modules": modules,
        "bank_controller_defaults": {k: param(k) for k in ("NUM_MASTERS", "NUM_BANKS", "DATA_WIDTH", "BANK_DEPTH",
                                                         "READ_LATENCY", "ARB", "INTERLEAVE", "ADDR_MODE",
                                                         "ID_WIDTH", "RSP_FIFO_DEPTH", "WRITE_ACK")},
        "semantics": {
            "arbitration": "per-bank round robin, pointer <- granted+1 (or fixed priority, master 0 highest)",
            "acceptance": "acceptance == issue to the array; one grant per bank per cycle",
            "read_latency": "response READ_LATENCY cycles after acceptance when not back-pressured",
            "write_completion": "architecturally complete at the acceptance edge; WRITE_ACK=1 answers in order",
            "credits": "RSP_FIFO_DEPTH outstanding responses per master; can_issue from registered state",
            "ordering": "per master strictly in acceptance order, carrying req_id",
            "errors": "out-of-range / misaligned: accepted, answered with rsp_err=1 and zero data",
            "banks": "NUM_BANKS power of two; interleave LOW (word % B) or HIGH (word / BANK_DEPTH)",
            "collision_policies_1r1w": "STALL (default) / READ_OLD (not ASIC) / FORBID",
            "write_mask": "MASK_WIDTH lanes, lane width DATA_WIDTH/MASK_WIDTH",
        },
        "spec_sha256": sha256_file(root / "docs/mem/01_interface_spec.md") if spec else None,
        "controller_sha256": sha256_file(root / "rtl/mem/sram_bank_controller.sv"),
        "provenance": "VERIFIED_REPO",
    }


def rtl_sources(root: Path) -> tuple[list[Path], list[Path]]:
    rtl = root / "rtl/mem"
    files = (sorted((rtl / "backends/generic").glob("*.sv")) + sorted((rtl / "backends/fpga").glob("*.sv"))
             + [rtl / "backends/asic/sram_asic_array.sv"] + sorted((rtl / "backends/asic").glob("sram_leaf_*.sv"))
             + sorted(rtl.glob("sram_*.sv")) + [rtl / "backends/asic/stubs/sram_macro_blackboxes.sv"])
    incs = [rtl, rtl / "backends/asic", root / "tb/mem"]
    return files, incs


SIM_BINARIES = {"verilator": "verilator", "icarus": "iverilog"}


def simulator_available(sim: str = "verilator") -> bool:
    if sim not in SIM_BINARIES:
        raise ValueError(f"unknown simulator {sim!r}; one of {sorted(SIM_BINARIES)}")
    return shutil.which(SIM_BINARIES[sim]) is not None and (sim != "icarus" or shutil.which("vvp") is not None)


def _params(cfg: BankCtrlConfig, maxn: int) -> dict[str, int]:
    return {"NM": cfg.num_masters, "NB": cfg.num_banks, "DW": cfg.data_width, "MW": cfg.mask_width,
            "BD": cfg.bank_depth, "LAT": cfg.read_latency, "ARB": 0 if cfg.arbitration == "rr" else 1,
            "ILV": 0 if cfg.interleave == "low" else 1, "FIFO": cfg.rsp_fifo_depth,
            "WACK": int(cfg.write_ack), "MAXN": maxn}


@dataclass
class RtlRun:
    simulator: str
    params: dict
    command: list[str]
    log_path: Path
    stdout: str
    accepts: list = field(default_factory=list)
    conflicts: list = field(default_factory=list)
    responses: list = field(default_factory=list)
    unknown_data: set = field(default_factory=set)


def build(cfg: BankCtrlConfig, root: Path, work: Path, maxn: int, sim: str = "verilator") -> tuple[Path, list[str]]:
    if not simulator_available(sim):
        raise RtlUnavailable(f"{sim} not found on PATH")
    files, incs = rtl_sources(root)
    p = _params(cfg, maxn)
    tag = "_".join(f"{k}{v}" for k, v in p.items())
    work.mkdir(parents=True, exist_ok=True)
    if sim == "verilator":
        mdir = work / f"vl_{tag}"
        exe = mdir / "Vtb_memorylab_bank_trace"
        cmd = ["verilator", *VL_FLAGS, *[f"+incdir+{d}" for d in incs], *map(str, files), str(HARNESS),
               "--top-module", "tb_memorylab_bank_trace", "--Mdir", str(mdir), "-o", exe.name,
               *[f"-G{k}={v}" for k, v in p.items()]]
        if not exe.exists():
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
            if r.returncode != 0 or not exe.exists():
                raise RuntimeError(f"verilator build failed:\n{r.stdout[-3000:]}\n{r.stderr[-3000:]}")
        return exe, cmd
    out = work / f"iv_{tag}.vvp"
    cmd = ["iverilog", "-g2012", "-DSRAMLIB_POISON", *[f"-I{d}" for d in incs], "-o", str(out),
           "-s", "tb_memorylab_bank_trace", *[f"-Ptb_memorylab_bank_trace.{k}={v}" for k, v in p.items()],
           *map(str, files), str(HARNESS)]
    if not out.exists():
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
        if r.returncode != 0:
            raise RuntimeError(f"iverilog build failed:\n{r.stderr[-3000:]}")
    return out, cmd


def run_rtl_bank_trace(cfg: BankCtrlConfig, stim, *, work: Path, root: Path | None = None, bp_pct: int = 0,
                       bp_seed: int = 1, sim: str = "verilator", vcd: Path | None = None) -> RtlRun:
    root = root or locate_sramlib(build_dir=work)
    maxn = max(256, 1 << (max(len(s) for s in stim) - 1).bit_length())
    exe, build_cmd = build(cfg, root, work, maxn, sim)
    tag = hashlib.sha256(repr((_params(cfg, maxn), bp_pct, bp_seed, stim)).encode()).hexdigest()[:12]
    stim_path = bb.write_stimulus(work / f"stim_{tag}.txt", cfg, stim)
    log_path = work / f"rtl_{tag}.log"
    args = [f"+stim={stim_path}", f"+log={log_path}", f"+bp={bp_pct}", f"+bpseed={bp_seed}"]
    if vcd is not None:
        if sim != "icarus":
            raise ValueError("VCD dumping is wired for Icarus (Verilator would need --trace)")
        args.append(f"+vcd={vcd}")
    cmd = [str(exe), *args] if sim == "verilator" else ["vvp", "-n", str(exe), *args]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    if r.returncode != 0 or "MEMLAB_RESULT" not in r.stdout:
        raise RuntimeError(f"RTL run failed (rc={r.returncode}):\n{r.stdout[-3000:]}\n{r.stderr[-2000:]}")
    if "SRAM_ERROR" in r.stdout or "SRAM_ASSERT" in r.stdout or "%Error" in r.stdout:
        raise RuntimeError(f"RTL assertion fired:\n{r.stdout[-3000:]}")
    run = RtlRun(sim, _params(cfg, maxn), build_cmd + ["&&"] + cmd, log_path, r.stdout)
    for line in log_path.read_text().splitlines():
        f = line.split()
        if f[0] == "A":
            run.accepts.append((int(f[1]), int(f[2]), int(f[3], 16)))
        elif f[0] == "C":
            run.conflicts.append((int(f[1]), int(f[2])))
        elif f[0] == "R":
            dhex = f[4]
            key = (int(f[1]), int(f[2]), int(f[3], 16))
            if re.search(r"[xXzZ]", dhex):
                run.unknown_data.add(key)
                data = None
            else:
                data = int(dhex, 16)
            run.responses.append((int(f[1]), int(f[2]), int(f[3], 16), data, int(f[5]), int(f[6])))
    run.accepts.sort()
    run.conflicts.sort()
    run.responses.sort(key=lambda x: (x[0], x[1]))
    return run


def compare_traces(py: dict, rtl: RtlRun) -> dict:
    """Transaction-by-transaction comparison; returns counts and the first mismatches."""
    out: dict[str, Any] = {"accepts_py": len(py["accepts"]), "accepts_rtl": len(rtl.accepts),
                           "responses_py": len(py["responses"]), "responses_rtl": len(rtl.responses),
                           "conflicts_py": len(py["conflicts"]), "conflicts_rtl": len(rtl.conflicts)}
    mism: list[str] = []
    if py["accepts"] != rtl.accepts:
        for a, b in zip(py["accepts"], rtl.accepts):
            if a != b:
                mism.append(f"accept py={a} rtl={b}")
                break
        if len(py["accepts"]) != len(rtl.accepts):
            mism.append("accept count differs")
    if py["conflicts"] != rtl.conflicts:
        mism.append(f"conflict stalls differ: py={len(py['conflicts'])} rtl={len(rtl.conflicts)}")
    pr = sorted(py["responses"], key=lambda x: (x[0], x[1]))
    data_checked = data_skipped = 0
    for a, b in zip(pr, rtl.responses):
        if a[:3] != b[:3] or a[4:] != b[4:]:
            mism.append(f"response py={a[:3]}+{a[4:]} rtl={b[:3]}+{b[4:]}")
            break
        known = py["known"].get((a[1], a[2], a[0]), -1)
        if b[3] is None or known == 0:
            data_skipped += 1
            continue
        mask = known if known != -1 else -1
        if mask == -1:
            if a[3] != b[3]:
                mism.append(f"data py={a[3]:x} rtl={b[3]:x} at {a[:3]}")
                break
        elif (a[3] ^ b[3]) & mask:
            mism.append(f"data (known bits) py={a[3]:x} rtl={b[3]:x} mask={mask:x} at {a[:3]}")
            break
        data_checked += 1
    if len(pr) != len(rtl.responses):
        mism.append("response count differs")
    # per-master order and latency agreement
    out.update(data_compared=data_checked, data_unknown_skipped=data_skipped, mismatches=mism,
               equivalent=not mism)
    return out


def equivalence_suite(work: Path, *, sim: str = "verilator", n_per_master: int = 400,
                      root: Path | None = None) -> list[dict]:
    """The configurations used to validate the Python bank model against the RTL."""
    cases = [
        (BankCtrlConfig(4, 4, 32, 256, 1), "vector", 0), (BankCtrlConfig(4, 4, 32, 256, 1), "cpu", 0),
        (BankCtrlConfig(4, 4, 32, 256, 1), "random", 30), (BankCtrlConfig(4, 2, 32, 256, 2), "mixed", 20),
        (BankCtrlConfig(4, 8, 32, 256, 1), "stride", 0), (BankCtrlConfig(4, 1, 32, 1024, 1), "dma", 0),
        (BankCtrlConfig(4, 4, 128, 256, 2), "tensor", 10), (BankCtrlConfig(3, 4, 32, 256, 1, arbitration="fixed"), "random", 0),
        (BankCtrlConfig(4, 4, 32, 256, 2, rsp_fifo_depth=1), "random", 25),
        (BankCtrlConfig(2, 4, 32, 256, 1, interleave="high"), "random", 0),
        (BankCtrlConfig(4, 4, 32, 256, 1, write_ack=False), "dma", 15),
    ]
    rows = []
    for i, (cfg, wlname, bp) in enumerate(cases):
        seed = 1000 + i
        stim = bb.generate(wlname, cfg, n_per_master, seed, err_pct=3 if wlname == "random" else 0)
        py = bb.run(cfg, stim, bp_pct=bp, seed=seed)
        rtl = run_rtl_bank_trace(cfg, stim, work=work, root=root, bp_pct=bp, bp_seed=seed, sim=sim)
        cmp_ = compare_traces(py, rtl)
        st = py["stats"]
        rows.append({"case": i, "workload": wlname, "simulator": sim, "backpressure_pct": bp, "seed": seed,
                     "params": rtl.params, "requests": sum(len(s) for s in stim),
                     "py_words_per_cycle": st["words_per_cycle"], "py_conflict_rate": st["conflict_rate"],
                     "py_avg_latency": st["avg_latency_cycles"], **cmp_,
                     "rtl_command": " ".join(rtl.command), "category": "RTL_OBSERVED vs EVENT_SIMULATED"})
    return rows


# =========================================================================== SilicaFlux-V tile latency
SFV_ZIP_REL = Path("SilicaFlux-main/silicaflux-v-release1.zip")
TILE_HARNESS = HARNESS.parent / "tb_memorylab_tile_latency.sv"
TILE_FILES = ["pkg/sfv_pkg.sv", "common/sfv_common.sv", "common/sfv_clkgate.sv", "mem/sfv_sram_sp.sv",
              "accel/sfv_vec_engine.sv", "accel/sfv_tensor_engine.sv", "accel/sfv_tile.sv"]


def locate_sfv(path: str | Path | None = None, build_dir: str | Path = "build/memorylab") -> Path:
    """Root of the SilicaFlux-V RTL release (directory containing rtl/accel/sfv_tile.sv)."""
    cands = [Path(path)] if path else []
    repo = find_repo_root(Path(__file__).resolve())
    if repo:
        cands += [repo / "SilicaFlux-main/silicaflux-v", repo / SFV_ZIP_REL]
    for c in cands:
        if c.is_dir():
            root = c if (c / "rtl/accel/sfv_tile.sv").exists() else c / "silicaflux-v"
            if (root / "rtl/accel/sfv_tile.sv").exists():
                return root
        if c.is_file() and c.suffix == ".zip":
            dest = Path(build_dir) / "sfv"
            root = dest / "silicaflux-v"
            if not (root / "rtl/accel/sfv_tile.sv").exists():
                dest.mkdir(parents=True, exist_ok=True)
                with zipfile.ZipFile(c) as z:
                    if any(".." in Path(n).parts or n.startswith("/") for n in z.namelist()):
                        raise RtlUnavailable(f"unsafe path in {c}")
                    z.extractall(dest)
            return root
    raise RtlUnavailable("SilicaFlux-V release RTL not found (pass --sfv <dir|zip>)")


def run_tile_latency(work: Path, root: Path | None = None) -> dict:
    """Run the unmodified sfv_tile with Verilator; compare CYCLES with memorylab.compute models."""
    if not simulator_available("verilator"):
        raise RtlUnavailable("verilator not found on PATH")
    root = root or locate_sfv(build_dir=work)
    rtl = root / "rtl"
    mdir = work / "vl_tile"
    exe = mdir / "Vtile"
    cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-DECLFILENAME",
           "-Wno-MULTITOP", "-Wno-UNUSEDSIGNAL", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC", "-DSFV_NO_CLOCK_GATE",
           *[str(rtl / f) for f in TILE_FILES], str(TILE_HARNESS), "--top-module", "tb_memorylab_tile_latency",
           "--Mdir", str(mdir), "-o", "Vtile"]
    if not exe.exists():
        work.mkdir(parents=True, exist_ok=True)
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
        if r.returncode != 0:
            raise RuntimeError(f"tile build failed:\n{r.stdout[-2000:]}\n{r.stderr[-2000:]}")
    r = subprocess.run([str(exe)], capture_output=True, text=True, timeout=600)
    if "TILE_LAT_DONE" not in r.stdout:
        raise RuntimeError(f"tile run failed:\n{r.stdout[-2000:]}")
    from .compute import TensorModel, VectorModel
    from .units import Precision
    te = TensorModel("te", 4, 4, 50e6, operand_bytes_per_cycle=4, writeback_bytes_per_cycle=16, fixed_overhead_cycles=3)
    ve = VectorModel("ve", 4, 50e6, ldst_bytes_per_cycle=16, fixed_overhead_cycles=3)
    rows = []
    for line in r.stdout.splitlines():
        if not line.startswith("TILE_LAT ") or "DONE" in line:
            continue
        f = dict(kv.split("=") for kv in line.split()[2:])
        if line.split()[1] == "TE":
            k, wb = int(f["k"]), int(f["wb"])
            pred = te.tile(k, Precision.INT8, writeback=bool(wb))["cycles"]
            rows.append({"engine": "tensor", "case": f"K={k} WB={wb}", "observed_cycles": int(f["cycles"]),
                         "predicted_cycles": pred, "wall_cycles": int(f["wall"]), "err_flag": int(f["err"])})
        else:
            op, bsc, wres, n = int(f["op"]), int(f["bscalar"]), int(f["wres"]), int(f["len"])
            cls = ("dot_vs" if bsc else "dot_vv") if op == 11 else ("vs" if bsc else "vv")
            pred = ve.command_cycles(cls, n, wres=bool(wres))
            rows.append({"engine": "vector", "case": f"{cls} LEN={n} WRES={wres}", "observed_cycles": int(f["cycles"]),
                         "predicted_cycles": pred, "wall_cycles": int(f["wall"]), "err_flag": int(f["err"])})
    for x in rows:
        x["abs_error_cycles"] = x["predicted_cycles"] - x["observed_cycles"]
        x["relative_error"] = abs(x["abs_error_cycles"]) / x["observed_cycles"] if x["observed_cycles"] else None
    return {"rows": rows, "command": " ".join(cmd), "rtl_root": str(root),
            "tile_sha256": sha256_file(rtl / "accel/sfv_tile.sv"), "category": "RTL_OBSERVED",
            "all_exact": all(x["abs_error_cycles"] == 0 for x in rows)}
