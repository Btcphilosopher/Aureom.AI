"""Deterministic discrete-event kernel.

Time is an integer number of femtoseconds (exact for every clock whose period
is a whole number of fs; otherwise the period is rounded and the relative
quantisation error is recorded on the ClockDomain).  Events are ordered by
(time, priority, sequence number): equal-time events run in priority order and
then in scheduling order, so a run is reproducible for a fixed seed.

Safety properties enforced here:
  * no negative delays and no scheduling in the past (ValueError)
  * bounded execution: max_events, max_time and a wall-clock limit
  * deadlock detection: when the queue drains while a registered component
    still reports outstanding work, DeadlockError lists who is stuck
"""
from __future__ import annotations

from dataclasses import dataclass, field
import heapq
import itertools
import math
import time as _time
from typing import Any, Callable, Iterable

FS_PER_S = 10 ** 15

# priorities for same-time ordering (lower runs first)
PRIO_COMPLETE = 0     # deliver responses / completions produced by the previous edge
PRIO_ISSUE = 10       # masters present new requests
PRIO_TICK = 20        # clocked components evaluate (arbitration, acceptance)
PRIO_LATE = 30        # reactions to this edge's results (e.g. next request after acceptance)
PRIO_SAMPLE = 40      # statistics sampling


class SimulationError(RuntimeError):
    pass


class DeadlockError(SimulationError):
    pass


class LimitExceeded(SimulationError):
    pass


@dataclass(frozen=True)
class ClockDomain:
    name: str
    freq_hz: float
    phase_fs: int = 0

    def __post_init__(self) -> None:
        if not (math.isfinite(self.freq_hz) and self.freq_hz > 0):
            raise ValueError(f"clock {self.name}: frequency must be > 0")
        if self.period_fs < 1:
            raise ValueError(f"clock {self.name}: period below 1 fs")

    @property
    def period_fs(self) -> int:
        return int(round(FS_PER_S / self.freq_hz))

    @property
    def quantisation_error(self) -> float:
        """Relative error of the integer-fs period vs the requested frequency."""
        exact = FS_PER_S / self.freq_hz
        return abs(self.period_fs - exact) / exact

    def cycles(self, n: float) -> int:
        """Duration of n cycles in fs (n >= 0; fractional cycles are not allowed)."""
        if n < 0:
            raise ValueError("negative cycle count")
        if n != int(n):
            raise ValueError(f"fractional cycle count {n}")
        return int(n) * self.period_fs

    def edge(self, k: int) -> int:
        return self.phase_fs + k * self.period_fs

    def edge_index_at_or_after(self, t_fs: int) -> int:
        if t_fs <= self.phase_fs:
            return 0
        return -(-(t_fs - self.phase_fs) // self.period_fs)

    def next_edge(self, t_fs: int, strictly_after: bool = False) -> int:
        k = self.edge_index_at_or_after(t_fs)
        e = self.edge(k)
        if strictly_after and e <= t_fs:
            e += self.period_fs
        return e

    def to_cycles(self, t_fs: int) -> float:
        return (t_fs - self.phase_fs) / self.period_fs

    def to_seconds(self, cycles: float) -> float:
        return cycles / self.freq_hz


@dataclass(order=True)
class _Ev:
    time: int
    prio: int
    seq: int
    cb: Callable[[], Any] = field(compare=False)
    label: str = field(compare=False, default="")
    cancelled: bool = field(compare=False, default=False)


class EventHandle:
    __slots__ = ("_ev",)

    def __init__(self, ev: _Ev) -> None:
        self._ev = ev

    def cancel(self) -> None:
        self._ev.cancelled = True

    @property
    def time(self) -> int:
        return self._ev.time


@dataclass
class RunStats:
    events: int
    end_time_fs: int
    wall_s: float
    stopped_by: str


class EventEngine:
    def __init__(self, *, max_events: int = 50_000_000, max_time_fs: int | None = None,
                 wall_limit_s: float | None = None) -> None:
        self.now: int = 0
        self._q: list[_Ev] = []
        self._seq = itertools.count()
        self.max_events = max_events
        self.max_time_fs = max_time_fs
        self.wall_limit_s = wall_limit_s
        self.events_run = 0
        self._components: list[Any] = []
        self._ids = itertools.count(1)

    # ------------------------------------------------------------------ ids
    def new_id(self) -> int:
        """Monotonic, globally unique transaction/event id (traceable, reproducible)."""
        return next(self._ids)

    # ------------------------------------------------------------------ scheduling
    def schedule(self, delay_fs: int, cb: Callable[[], Any], prio: int = PRIO_ISSUE, label: str = "") -> EventHandle:
        if not isinstance(delay_fs, int):
            if isinstance(delay_fs, float) and delay_fs.is_integer():
                delay_fs = int(delay_fs)
            else:
                raise TypeError(f"delay must be an integer number of fs, got {delay_fs!r}")
        if delay_fs < 0:
            raise ValueError(f"negative delay {delay_fs} fs ({label})")
        return self.schedule_at(self.now + delay_fs, cb, prio, label)

    def schedule_at(self, t_fs: int, cb: Callable[[], Any], prio: int = PRIO_ISSUE, label: str = "") -> EventHandle:
        if t_fs < self.now:
            raise ValueError(f"cannot schedule in the past: t={t_fs} < now={self.now} ({label})")
        ev = _Ev(int(t_fs), prio, next(self._seq), cb, label)
        heapq.heappush(self._q, ev)
        return EventHandle(ev)

    @property
    def pending(self) -> int:
        return sum(1 for e in self._q if not e.cancelled)

    def register(self, component: Any) -> None:
        """Components exposing ``outstanding() -> int`` and ``name`` take part in deadlock detection."""
        self._components.append(component)

    # ------------------------------------------------------------------ run
    def run(self, until_fs: int | None = None) -> RunStats:
        t0 = _time.perf_counter()
        stopped = "drained"
        while self._q:
            ev = self._q[0]
            if until_fs is not None and ev.time > until_fs:
                stopped = "until"
                break
            heapq.heappop(self._q)
            if ev.cancelled:
                continue
            if self.max_time_fs is not None and ev.time > self.max_time_fs:
                raise LimitExceeded(f"simulated time limit {self.max_time_fs} fs exceeded at event '{ev.label}'")
            self.now = ev.time
            ev.cb()
            self.events_run += 1
            if self.events_run > self.max_events:
                raise LimitExceeded(f"event limit {self.max_events} exceeded (last: '{ev.label}')")
            if self.wall_limit_s is not None and (self.events_run & 0x3FF) == 0 \
                    and _time.perf_counter() - t0 > self.wall_limit_s:
                raise LimitExceeded(f"wall-clock limit {self.wall_limit_s} s exceeded")
        if stopped == "drained":
            stuck = [(c.name, c.outstanding()) for c in self._components if c.outstanding() > 0]
            if stuck:
                raise DeadlockError("event queue empty but work is outstanding: " +
                                    ", ".join(f"{n} ({k} outstanding)" for n, k in stuck))
        return RunStats(self.events_run, self.now, _time.perf_counter() - t0, stopped)


# =========================================================================== transactions & trace
@dataclass
class Transaction:
    tid: int
    master: str
    op: str                         # 'R' or 'W'
    addr: int
    size: int                       # bytes
    t_created: int
    parent: int | None = None
    data: int | None = None         # write data (functional models) / read data on response
    mask: int | None = None
    tag: Any = None
    t_issued: int | None = None     # presented to the first component
    t_accepted: int | None = None
    t_service_start: int | None = None
    t_service_end: int | None = None
    t_completed: int | None = None
    error: bool = False
    path: list[str] = field(default_factory=list)
    on_complete: Callable[["Transaction"], Any] | None = None

    def __post_init__(self) -> None:
        if self.op not in ("R", "W"):
            raise ValueError(f"op must be 'R' or 'W', got {self.op!r}")
        if self.size <= 0:
            raise ValueError("transaction size must be > 0 bytes (no zero-byte transfers)")
        if self.addr < 0:
            raise ValueError("negative address")

    @property
    def latency_fs(self) -> int | None:
        if self.t_completed is None or self.t_issued is None:
            return None
        return self.t_completed - self.t_issued


class Trace:
    """Append-only transaction event log with invariant checks."""

    EVENTS = ("CREATE", "ISSUE", "ACCEPT", "CONFLICT", "SERVICE_START", "SERVICE_END", "RESPONSE",
              "COMPLETE", "BACKPRESSURE", "ERROR")

    def __init__(self, enabled: bool = True, limit: int = 2_000_000) -> None:
        self.enabled = enabled
        self.limit = limit
        self.rows: list[tuple] = []
        self.truncated = False

    def log(self, t_fs: int, event: str, component: str, txn: Transaction | None = None, **extra: Any) -> None:
        if not self.enabled:
            return
        if len(self.rows) >= self.limit:
            self.truncated = True
            return
        if txn is None:
            self.rows.append((t_fs, event, component, None, None, None, None, None, extra or None))
        else:
            self.rows.append((t_fs, event, component, txn.tid, txn.master, txn.op, txn.addr, txn.size,
                              extra or None))

    COLUMNS = ("time_fs", "event", "component", "tid", "master", "op", "addr", "size", "extra")

    def to_records(self) -> list[dict]:
        return [dict(zip(self.COLUMNS, r)) for r in self.rows]

    def check_invariants(self, component: str | None = None, accept: str = "ACCEPT",
                         complete: str = "COMPLETE") -> list[str]:
        """No completion without acceptance, no duplicates, no loss, monotonic per-transaction time."""
        if self.truncated:
            return ["trace truncated: invariants not checkable"]
        errs: list[str] = []
        acc: dict[int, int] = {}
        done: dict[int, int] = {}
        last: dict[int, int] = {}
        for t, ev, comp, tid, *_ in self.rows:
            if tid is None or (component and comp != component):
                continue
            if tid in last and t < last[tid] and ev not in ("SERVICE_START",):
                errs.append(f"tid {tid}: time went backwards at {ev}")
            last[tid] = t
            if ev == accept:
                if tid in acc:
                    errs.append(f"tid {tid}: accepted twice")
                acc[tid] = t
            elif ev == complete:
                if tid not in acc:
                    errs.append(f"tid {tid}: completed without acceptance")
                elif t < acc[tid]:
                    errs.append(f"tid {tid}: negative latency")
                if tid in done:
                    errs.append(f"tid {tid}: completed twice (duplicate)")
                done[tid] = t
        lost = set(acc) - set(done)
        if lost:
            errs.append(f"{len(lost)} accepted transactions never completed (lost), e.g. {sorted(lost)[:5]}")
        return errs


def sorted_unique(xs: Iterable[int]) -> list[int]:
    return sorted(set(xs))
