"""Build compute engines and per-engine hierarchical Roofline levels from a Profile,
and evaluate workloads analytically (ANALYTICAL_CEILING results).

Bandwidth of a Roofline level = min over its declared physical limits:
  engine_port   operand port of the engine (bytes/cycle x f)
  memory        banks x width x f_mem x ports (peak array bandwidth, no conflicts)
  interconnect  width x f_ic x beats/(beats + overhead) for the transfer size in use
  dma           Little's law: channels x outstanding x burst / round-trip time, capped by bus
  cpu_copy      CPU load/store copy loop (bytes per word / cycles per word x f)
Each derived bandwidth carries the combined provenance of its inputs.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any

from .compute import CpuModel, InstructionMix, TensorModel, UnsupportedConfiguration, VectorModel
from .config import Profile, RooflineLevelCfg, prov_of
from .roofline import LevelTraffic, MemoryLevel, RooflineResult, hierarchical_roofline
from .units import OpKind, Precision
from . import workloads as wl


# --------------------------------------------------------------------------- engines
def build_cpu(p: Profile) -> CpuModel:
    c = p.cpu
    return CpuModel(name="cpu", cores=int(c.cores.v), freq_hz=p.f, xlen=int(c.xlen.v),
                    issue_width=int(c.issue_width.v), cpi={k: float(v.v) for k, v in c.cpi.items()},
                    has_hw_mul=bool(c.has_hw_mul.v), has_fpu=bool(c.has_fpu.v),
                    utilisation=float(c.utilisation.v))


def build_vector(p: Profile) -> VectorModel | None:
    v = p.vector
    if v is None or not v.enabled:
        return None
    lanes = int(v.lanes.v)
    eb = int(v.element_bits.v) // 8
    ldst = float(v.ldst_bytes_per_cycle.v) if v.ldst_bytes_per_cycle is not None else lanes * eb
    return VectorModel(name="vector", lanes=lanes, freq_hz=p.f, element_bits=int(v.element_bits.v),
                       elems_per_lane_per_cycle=float(v.elems_per_lane_per_cycle.v),
                       issue_per_cycle=float(v.issue_per_cycle.v),
                       macs_per_lane_per_cycle=float(v.macs_per_lane_per_cycle.v),
                       ldst_bytes_per_cycle=ldst, fixed_overhead_cycles=int(v.fixed_overhead_cycles.v),
                       zero_length_cycles=int(v.zero_length_cycles.v), wres_cycles=int(v.wres_cycles.v),
                       dependency_stall_cycles_per_beat=float(v.dependency_stall_cycles_per_beat.v),
                       conflict_stall_cycles_per_beat=float(v.conflict_stall_cycles_per_beat.v),
                       precisions=tuple(Precision(x) for x in v.precisions))


def build_tensor(p: Profile) -> TensorModel | None:
    t = p.tensor
    if t is None or not t.enabled:
        return None
    return TensorModel(name="tensor", rows=int(t.rows.v), cols=int(t.cols.v), freq_hz=p.f,
                       macs_per_pe_per_cycle={Precision(k): float(v.v) for k, v in t.macs_per_pe_per_cycle.items()},
                       depth=int(t.depth.v), acc_bits=int(t.acc_bits.v),
                       operand_bytes_per_cycle=float(t.operand_bytes_per_cycle.v),
                       writeback_bytes_per_cycle=float(t.writeback_bytes_per_cycle.v),
                       fixed_overhead_cycles=int(t.fixed_overhead_cycles.v), fill_cycles=int(t.fill_cycles.v),
                       drain_cycles=int(t.drain_cycles.v), max_k=int(t.max_k.v))


def engines(p: Profile) -> dict[str, Any]:
    out: dict[str, Any] = {"cpu": build_cpu(p)}
    v, t = build_vector(p), build_tensor(p)
    if v:
        out["vector"] = v
    if t:
        out["tensor"] = t
    return out


# --------------------------------------------------------------------------- bandwidths
@dataclass
class Bandwidth:
    Bps: float
    provenance: str
    detail: str


def _mem_clock(p: Profile, name: str) -> float:
    m = p.memory(name)
    return float(m.clock_hz.v) if m.clock_hz is not None else p.f


def interconnect_txn_bytes(p: Profile) -> int:
    if p.dma is not None and p.dma.enabled:
        return int(p.dma.burst_bytes.v)
    return int(p.cpu.load_bytes.v)


def bw_interconnect(p: Profile, txn_bytes: int | None = None) -> Bandwidth:
    ic = p.interconnect
    f = float(ic.clock_hz.v) if ic.clock_hz is not None else p.f
    txn = txn_bytes or interconnect_txn_bytes(p)
    beats = math.ceil(txn / ic.width_bytes)
    ov = float(ic.overhead_cycles.v)
    bps = txn / (beats + ov) * f
    return Bandwidth(bps, prov_of(ic.width_bits, ic.overhead_cycles, ic.clock_hz, p.clock.frequency_hz),
                     f"interconnect {ic.width_bits.v}b, {txn} B txn = {beats} beats + {ov:g} overhead")


def bw_memory(p: Profile, name: str) -> Bandwidth:
    m = p.memory(name)
    if m.kind == "dram":
        bps = int(m.channels.v) * int(m.bus_width_bits.v) / 8 * float(m.data_rate_mtps.v) * 1e6
        return Bandwidth(bps, prov_of(m.channels, m.bus_width_bits, m.data_rate_mtps),
                         f"{m.name}: {m.channels.v} ch x {m.bus_width_bits.v}b x {m.data_rate_mtps.v} MT/s (peak)")
    ports = {"1RW": 1, "1R1W": 2, "2RW": 2}[m.ports]
    f = _mem_clock(p, name)
    bps = int(m.banks.v) * m.width_bytes * ports * f
    return Bandwidth(bps, prov_of(m.banks, m.width_bits, m.clock_hz, p.clock.frequency_hz),
                     f"{m.name}: {m.banks.v} banks x {m.width_bytes} B x {ports} port(s) (peak, conflict-free)")


def bw_dma(p: Profile, target_memory: str | None) -> Bandwidth:
    d = p.dma
    assert d is not None
    burst = int(d.burst_bytes.v)
    ic = bw_interconnect(p, burst)
    beats = math.ceil(burst / p.interconnect.width_bytes)
    lat = 1.0
    if target_memory:
        m = p.memory(target_memory)
        lat = (float(m.read_latency_ns.v) * 1e-9 * p.f) if m.kind == "dram" else float(m.read_latency_cycles.v)
    # per-burst round trip: bus overhead + source latency + data beats (descriptor setup is
    # per transfer and is accounted for by the event simulator, not by this steady-state bound)
    rtt_cycles = float(p.interconnect.overhead_cycles.v) + lat + beats
    little = int(d.channels.v) * int(d.max_outstanding.v) * burst / rtt_cycles * p.f
    bps = min(ic.Bps, little)
    return Bandwidth(bps, prov_of(d.channels, d.max_outstanding, d.burst_bytes, p.interconnect.width_bits, p.clock.frequency_hz),
                     f"dma {d.channels.v} ch x {d.max_outstanding.v} outstanding x {burst} B / "
                     f"{rtt_cycles:.1f} cycle round trip, capped by bus")


def bw_cpu_copy(p: Profile, unroll: int = 4) -> Bandwidth:
    c = p.cpu
    cpi = {k: float(v.v) for k, v in c.cpi.items()}
    per_word = cpi.get("load", 2) + cpi.get("store", 2) + (2 * cpi["alu"] + cpi.get("branch_taken", 3)) / unroll
    bps = float(c.load_bytes.v) / per_word * p.f * int(c.cores.v)
    return Bandwidth(bps, prov_of(*(c.cpi.get(k) for k in ("load", "store", "alu", "branch_taken")), c.cores,
                                  c.load_bytes, p.clock.frequency_hz),
                     f"cpu copy loop: {per_word:.2f} cycles per {c.load_bytes.v} B word (unroll {unroll})")


def bw_engine_port(p: Profile, engine: str) -> Bandwidth:
    if engine == "tensor" and p.tensor:
        t = p.tensor
        return Bandwidth(float(t.operand_bytes_per_cycle.v) * p.f, prov_of(t.operand_bytes_per_cycle, p.clock.frequency_hz),
                         f"tensor operand port {t.operand_bytes_per_cycle.v} B/cycle")
    if engine == "vector" and p.vector:
        v = build_vector(p)
        src = p.vector.ldst_bytes_per_cycle or p.vector.lanes
        return Bandwidth(v.ldst_bytes_per_cycle * p.f, prov_of(src, p.clock.frequency_hz),
                         f"vector operand port {v.ldst_bytes_per_cycle:g} B/cycle")
    c = p.cpu
    bps = float(c.load_bytes.v) / float(c.cpi.get("load", c.cpi["alu"]).v) * p.f * int(c.cores.v)
    return Bandwidth(bps, prov_of(c.load_bytes, c.cpi.get("load"), c.cores, p.clock.frequency_hz),
                     "cpu load/store port")


def level_bandwidth(p: Profile, engine: str, lv: RooflineLevelCfg) -> Bandwidth:
    if lv.bandwidth_Bps is not None:
        return Bandwidth(float(lv.bandwidth_Bps.v), lv.bandwidth_Bps.provenance.value, "explicit")
    cands: list[Bandwidth] = []
    if lv.port:
        cands.append(bw_engine_port(p, engine))
    target = lv.capacity_of[-1] if lv.capacity_of else None
    outer = None
    for lim in lv.limits:
        if lim.via == "engine_port":
            cands.append(bw_engine_port(p, engine))
        elif lim.via == "memory":
            cands.append(bw_memory(p, lim.memory))
            outer = lim.memory
        elif lim.via == "interconnect":
            cands.append(bw_interconnect(p))
        elif lim.via == "dma":
            cands.append(bw_dma(p, next((x.memory for x in lv.limits if x.via == "memory"), target)))
        elif lim.via == "cpu_copy":
            cands.append(bw_cpu_copy(p))
    best = min(cands, key=lambda b: b.Bps)
    from .provenance import combine, Provenance
    provs = []
    for b in cands:
        for tok in b.provenance.replace("DERIVED(", "").replace(")", "").split("+"):
            provs.append(Provenance(tok))
    return Bandwidth(best.Bps, combine(provs), " | ".join(b.detail for b in cands) + f"  -> min = {best.detail}")


def memory_levels(p: Profile, engine: str) -> list[tuple[RooflineLevelCfg, MemoryLevel, Bandwidth]]:
    out = []
    for lv in p.roofline.get(engine, []):
        bw = level_bandwidth(p, engine, lv)
        lat = inflight = None
        if lv.latency_cycles is not None:
            lat = float(lv.latency_cycles.v) / p.f
            inflight = float(lv.max_inflight_bytes.v) if lv.max_inflight_bytes is not None else None
            if inflight is None:
                raise UnsupportedConfiguration(f"{engine}.{lv.name}: latency_cycles needs max_inflight_bytes")
        out.append((lv, MemoryLevel(lv.name, bw.Bps, lat, inflight, provenance=bw.provenance), bw))
        if lv.port and engine == "tensor" and p.tensor is not None:
            # accumulator writeback uses its own (row-wide) path in the RTL; charging it to the
            # operand-read port would make the "ceiling" lower than the engine's actual rate
            t = p.tensor
            wb = Bandwidth(float(t.writeback_bytes_per_cycle.v) * p.f,
                           prov_of(t.writeback_bytes_per_cycle, p.clock.frequency_hz),
                           f"tensor accumulator writeback {t.writeback_bytes_per_cycle.v} B/cycle")
            wlv = RooflineLevelCfg(name=lv.name + "_writeback", port=True)
            out.append((wlv, MemoryLevel(wlv.name, wb.Bps, provenance=wb.provenance), wb))
    return out


def level_capacity(p: Profile, lv: RooflineLevelCfg) -> float:
    return float(sum(p.memory(m).capacity_bytes or 0 for m in lv.capacity_of))


# --------------------------------------------------------------------------- mapping
def vector_commands(w: wl.Workload) -> list[tuple[str, int, bool]]:
    """Map a workload onto SilicaFlux-style memory-to-memory vector commands (op, len, wres)."""
    d = w.dims
    f = w.family
    if f == "vector_add":
        return [("vv", d["n"], False)]
    if f == "axpy":                     # no fused multiply-add: MUL (vs) + ADD (vv)
        return [("vs", d["n"], False), ("vv", d["n"], False)]
    if f == "dot":
        return [("dot_vv", d["n"], True)]
    if f == "gemv":
        return [("dot_vv", d["n"], True)] * d["m"]
    if f == "fir":                      # per tap: MUL by scalar coefficient + ADD into accumulator
        return [("vs", d["n"], False), ("vv", d["n"], False)] * d["taps"]
    if f == "stencil2d":
        return [("vs", d["h"] * d["w"], False), ("vv", d["h"] * d["w"], False)] * (d["k"] ** 2)
    raise UnsupportedConfiguration(f"no vector mapping for workload family {f!r}")


def tensor_shape(w: wl.Workload) -> tuple[int, int, int]:
    d = w.dims
    if w.family == "gemm":
        return d["m"], d["n"], d["k"]
    if w.family == "conv2d":            # implicit GEMM: M = P*Q, N = Cout, K = R*S*Cin
        return d["p"] * d["q"], d["cout"], d["r"] * d["s"] * d["cin"]
    raise UnsupportedConfiguration(f"no tensor mapping for workload family {w.family!r}")


def cpu_mix(w: wl.Workload, cpu: CpuModel) -> InstructionMix:
    """Simple scalar loop model for the in-order control core (zero-wait memory)."""
    f = w.family
    d = w.dims
    mul = "mul" if cpu.has_hw_mul else "mul_sw"
    loop = lambda iters, unroll=4: {"alu": 2 * iters / unroll, "branch_taken": iters / unroll}
    if f == "cpu_sequential":
        n = d["n"]
        c = {"load": n, "alu": n}
    elif f == "cpu_random":
        n = d["n"]
        c = {"load": n, "alu": 3 * n}          # address generation + accumulate
    elif f == "vector_add":
        n = d["n"]
        c = {"load": 2 * n, "store": n, "alu": n}
    elif f in ("axpy", "dot"):
        n = d["n"]
        c = {"load": 2 * n, "store": n if f == "axpy" else 1, mul: n, "alu": n}
    elif f in ("gemm", "gemv", "conv2d", "fir", "stencil2d"):
        macs = w.macs
        c = {"load": 2 * macs, mul: macs, "alu": macs, "store": w.algorithmic_writes}
        n = macs
    else:
        raise UnsupportedConfiguration(f"no CPU mapping for {f!r}")
    for k, v in loop(n).items():
        c[k] = c.get(k, 0) + v
    useful_kind = w.precision.arithmetic_kind
    return InstructionMix(counts=c, useful_ops=w.arithmetic_ops, useful_kind=useful_kind,
                          precision=w.precision)


def engine_port_traffic(p: Profile, engine: str, w: wl.Workload) -> LevelTraffic:
    if engine == "tensor":
        te = build_tensor(p)
        m, n, k = tensor_shape(w)
        return wl.gemm_tensor_port_traffic(m, n, k, te.rows, te.cols, te.depth, w.precision, te.acc_bits // 8)
    if engine == "vector":
        ve = build_vector(p)
        r = wr = 0.0
        for op, n, wres in vector_commands(w):
            info = ve.command(op, n, wres=wres)
            streams = {"vv": (2, 1), "vs": (1, 1), "dot_vv": (2, 0), "dot_vs": (1, 0)}[op]
            beat = ve.lanes * ve.elem_bytes
            r += info["beats"] * beat * streams[0]
            wr += info["beats"] * beat * streams[1] + (4 if wres else 0)
        return LevelTraffic(r, wr)
    return w.traffic(0)


def engine_compute(p: Profile, engine: str, w: wl.Workload) -> dict:
    """Engine-model execution time with operands resident (analytical estimate, not a ceiling)."""
    if engine == "tensor":
        te = build_tensor(p)
        m, n, k = tensor_shape(w)
        r = te.gemm(m, n, k, w.precision)
        return {"engine_cycles": r["cycles"], "engine_time_s": r["time_s"], "engine_utilisation": r["utilisation"],
                "breakdown": {k_: r[k_] for k_ in ("ideal_cycles", "padding_loss_cycles", "operand_stall",
                                                    "overhead", "writeback")}}
    if engine == "vector":
        ve = build_vector(p)
        tot: dict[str, float] = {}
        for op, n, wres in vector_commands(w):
            for k_, v in ve.command(op, n, wres=wres).items():
                if isinstance(v, (int, float)):
                    tot[k_] = tot.get(k_, 0) + v
        peak = ve.peak(w.precision.arithmetic_kind, w.precision).value
        t = tot["cycles"] / ve.freq_hz
        return {"engine_cycles": tot["cycles"], "engine_time_s": t,
                "engine_utilisation": (w.arithmetic_ops / t) / peak if t else 0.0,
                "breakdown": {k_: tot.get(k_, 0) for k_ in ("ideal", "tail", "memory_stall", "overhead",
                                                           "dependency", "conflict", "writeback")}}
    cpu = build_cpu(p)
    est = cpu.estimate(cpu_mix(w, cpu))
    return {"engine_cycles": est["cycles"], "engine_time_s": est["time_s"],
            "engine_utilisation": est["utilisation"], "breakdown": {"instructions": est["instructions"]}}


def peak_for(p: Profile, engine: str, w: wl.Workload, kind: OpKind):
    e = engines(p).get(engine)
    if e is None:
        raise UnsupportedConfiguration(f"engine {engine!r} not present in profile {p.name}")
    if engine == "vector" and w.precision not in e.precisions:
        raise UnsupportedConfiguration(
            f"vector engine supports {[x.value for x in e.precisions]}, workload is {w.precision.value}")
    return e.peak(kind, w.precision)


def analyse(p: Profile, w: wl.Workload, engine: str | None = None) -> dict:
    """Hierarchical Roofline ceiling + engine-model estimate for one workload."""
    eng = engine or w.engine
    if eng not in ("cpu", "vector", "tensor"):
        raise UnsupportedConfiguration(f"Roofline needs a compute engine; {w.name} runs on {eng!r}")
    # pure-MAC workloads use the engine's MAC rate where it differs from its ALU-op rate (tensor array;
    # CPU without a hardware multiplier, where a MAC costs mul_sw + alu cycles)
    kind = OpKind.MAC if (w.macs and not w.other_ops and eng in ("tensor", "cpu")) else w.precision.arithmetic_kind
    peak = peak_for(p, eng, w, kind)
    levels = memory_levels(p, eng)
    if not levels:
        raise UnsupportedConfiguration(f"profile {p.name} declares no roofline levels for {eng}")
    traffic: dict[str, LevelTraffic] = {}
    details: dict[str, Any] = {}
    for lv, mlv, bw in levels:
        if lv.port and eng == "tensor":
            pt = engine_port_traffic(p, eng, w)
            is_wb = lv.name.endswith("_writeback")
            traffic[lv.name] = LevelTraffic(0.0, pt.write_bytes) if is_wb else LevelTraffic(pt.read_bytes, 0.0)
            details[lv.name] = {"capacity_bytes": None, "bandwidth_detail": bw.detail}
        elif lv.port:
            traffic[lv.name] = engine_port_traffic(p, eng, w)
            details[lv.name] = {"capacity_bytes": None, "bandwidth_detail": bw.detail}
        else:
            cap = level_capacity(p, lv)
            tr, info = w.traffic_detail(cap)
            traffic[lv.name] = tr
            details[lv.name] = {"capacity_bytes": cap, "bandwidth_detail": bw.detail, **info}
    res: RooflineResult = hierarchical_roofline(workload=w.name, engine=eng, work=w.work(kind), peak=peak,
                                                levels=[m for _, m, _ in levels], traffic=traffic, kind=kind,
                                                convention=w.convention)
    comp = engine_compute(p, eng, w)
    d = res.to_dict()
    d["level_details"] = details
    d["engine_model"] = {**comp, "category": "ANALYTICAL_ESTIMATE (engine latency model, operands resident)"}
    d["profile"] = p.name
    d["strategy"] = w.strategy
    d["family"] = w.family
    return d
