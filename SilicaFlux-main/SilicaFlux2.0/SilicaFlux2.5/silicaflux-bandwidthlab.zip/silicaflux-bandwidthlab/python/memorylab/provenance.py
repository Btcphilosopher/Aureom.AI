"""Data provenance: where every parameter and every result comes from.

Parameter provenance (brief section 1):
  VERIFIED_REPO      read from repository RTL / documentation (path recorded)
  RTL_SIMULATED      extracted from an actual RTL simulation run (trace / log recorded)
  EXTERNAL_MEASURED  supplied from external engineering measurement (source recorded)
  HYPOTHETICAL       design assumption (default for anything without a source)

Result categories (brief section 16) are never merged:
  ANALYTICAL_CEILING, EVENT_SIMULATED, RTL_OBSERVED, SILICON_MEASURED.
"""
from __future__ import annotations

from enum import Enum
import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path
from typing import Any, Iterable

SIMULATOR_NAME = "SilicaFlux MemoryLab"
SIMULATOR_VERSION = "0.1.0"


class Provenance(str, Enum):
    VERIFIED_REPO = "VERIFIED_REPO"
    RTL_SIMULATED = "RTL_SIMULATED"
    EXTERNAL_MEASURED = "EXTERNAL_MEASURED"
    HYPOTHETICAL = "HYPOTHETICAL"


class ResultCategory(str, Enum):
    ANALYTICAL_CEILING = "ANALYTICAL_CEILING"
    EVENT_SIMULATED = "EVENT_SIMULATED"
    RTL_OBSERVED = "RTL_OBSERVED"
    SILICON_MEASURED = "SILICON_MEASURED"


def combine(provs: Iterable[Provenance]) -> str:
    """Provenance label of a value derived from several inputs.

    Any hypothetical input makes the result hypothetical; otherwise a single
    common class is kept, and a mixture is reported as DERIVED(...).
    """
    s = sorted({Provenance(p).value for p in provs})
    if not s:
        return Provenance.HYPOTHETICAL.value
    if Provenance.HYPOTHETICAL.value in s:
        return Provenance.HYPOTHETICAL.value
    if len(s) == 1:
        return s[0]
    return "DERIVED(" + "+".join(s) + ")"


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def git_revision(start: str | Path | None = None) -> dict[str, Any]:
    """Git revision of the enclosing SilicaFlux repository (or $SILICAFLUX_REPO), if any."""
    import os
    cwd = Path(start or Path.cwd())
    if cwd.is_file():
        cwd = cwd.parent
    env = os.environ.get("SILICAFLUX_REPO")
    if env:
        try:
            if subprocess.run(["git", "rev-parse", "--show-toplevel"], cwd=cwd, capture_output=True,
                              timeout=10).returncode != 0:
                cwd = Path(env)
        except (OSError, subprocess.SubprocessError):
            cwd = Path(env)
    out: dict[str, Any] = {"available": False}
    try:
        top = subprocess.run(["git", "rev-parse", "--show-toplevel"], cwd=cwd, capture_output=True,
                             text=True, timeout=10)
        if top.returncode != 0:
            out["reason"] = "not inside a git work tree"
            return out
        rev = subprocess.run(["git", "rev-parse", "HEAD"], cwd=cwd, capture_output=True, text=True, timeout=10)
        st = subprocess.run(["git", "status", "--porcelain"], cwd=cwd, capture_output=True, text=True, timeout=30)
        out.update(available=True, toplevel=top.stdout.strip(), revision=rev.stdout.strip(),
                   dirty=bool(st.stdout.strip()))
    except (OSError, subprocess.SubprocessError) as e:  # git missing or hung
        out["reason"] = f"git unavailable: {e}"
    return out


PACKAGES = ("numpy", "scipy", "pandas", "matplotlib", "plotly", "pydantic", "PyYAML", "pytest", "hypothesis")


def environment() -> dict[str, Any]:
    pk = {}
    for p in PACKAGES:
        try:
            pk[p] = metadata.version(p)
        except metadata.PackageNotFoundError:
            pk[p] = None
    return {
        "python": sys.version.split()[0],
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "packages": pk,
    }


def experiment_record(*, config_path: str | Path | None, config_dict: dict[str, Any] | None,
                      seed: int | None, command: str, extra: dict[str, Any] | None = None,
                      repo_hint: str | Path | None = None) -> dict[str, Any]:
    """Common provenance header written into every JSON result."""
    rec: dict[str, Any] = {
        "simulator": SIMULATOR_NAME,
        "simulator_version": SIMULATOR_VERSION,
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "command": command,
        "seed": seed,
        "git": git_revision(repo_hint or (Path(config_path).parent if config_path else None)),
        "environment": environment(),
    }
    if config_path is not None:
        rec["config_file"] = str(config_path)
        rec["config_sha256"] = sha256_file(config_path)
    if config_dict is not None:
        rec["config_resolved_sha256"] = sha256_text(json.dumps(config_dict, sort_keys=True, default=str))
    if extra:
        rec.update(extra)
    return rec
