"""External DRAM / HBM timing ABSTRACTION -- explicitly NOT a JEDEC-accurate model.

Modelled: channels (address-interleaved at burst granularity), per-channel data bus
of width x data-rate (sustained bandwidth bound), fixed read/write latency, request
queue depth with backpressure, burst size, and optionally per-bank open-row state
(row hit / row miss latency).  Not modelled: tRAS/tRC/tFAW/tRRD, refresh, bank
groups, read/write turnaround, command-bus contention, power-down, ODT.  Use the
results as a first-order bandwidth/latency envelope only.
"""
from __future__ import annotations

from typing import Callable

import numpy as np

from .event_engine import FS_PER_S, PRIO_COMPLETE, EventEngine, Trace, Transaction


class Dram:
    fidelity = "timing abstraction (not JEDEC-accurate)"

    def __init__(self, eng: EventEngine, *, name: str = "dram", channels: int = 1, bus_width_bytes: int = 4,
                 data_rate_mtps: float = 1600, read_latency_ns: float = 50, write_latency_ns: float = 30,
                 burst_bytes: int = 32, queue_depth: int = 16, base_addr: int = 0, capacity: int = 1 << 32,
                 model_rows: bool = False, banks: int = 8, row_bytes: int = 2048, row_hit_ns: float = 15,
                 row_miss_ns: float = 45, trace: Trace | None = None) -> None:
        if channels < 1 or bus_width_bytes < 1 or data_rate_mtps <= 0 or burst_bytes < 1 or queue_depth < 1:
            raise ValueError(f"{name}: invalid DRAM parameters")
        if read_latency_ns < 0 or write_latency_ns < 0:
            raise ValueError(f"{name}: negative latency")
        self.eng, self.name = eng, name
        self.channels, self.burst, self.qdepth = channels, burst_bytes, queue_depth
        self.ch_Bps = bus_width_bytes * data_rate_mtps * 1e6
        self.rlat = int(read_latency_ns * 1e6)          # fs
        self.wlat = int(write_latency_ns * 1e6)
        self.base, self.capacity = base_addr, capacity
        self.model_rows, self.banks, self.row_bytes = model_rows, banks, row_bytes
        self.row_hit, self.row_miss = int(row_hit_ns * 1e6), int(row_miss_ns * 1e6)
        self.open_row: dict[tuple[int, int], int] = {}
        self.bus_free = [0] * channels
        self.inflight = [0] * channels
        self.trace = trace or Trace(enabled=False)
        self.bytes = 0
        self.busy_fs = [0] * channels
        self.lat_fs: list[int] = []
        self.row_hits = self.row_misses = self.rejects = 0
        eng.register(self)

    @property
    def peak_Bps(self) -> float:
        return self.ch_Bps * self.channels

    def outstanding(self) -> int:
        return sum(self.inflight)

    def contains(self, addr: int, size: int) -> bool:
        return self.base <= addr and addr + size <= self.base + self.capacity

    def access(self, txn: Transaction, on_done: Callable[[Transaction], None], **_: object) -> bool:
        if not self.contains(txn.addr, txn.size):
            raise ValueError(f"{self.name}: address 0x{txn.addr:x} out of range")
        ch = ((txn.addr - self.base) // self.burst) % self.channels
        if self.inflight[ch] >= self.qdepth:
            self.rejects += 1
            self.trace.log(self.eng.now, "BACKPRESSURE", self.name, txn, channel=ch)
            return False
        self.inflight[ch] += 1
        now = self.eng.now
        lat = self.wlat if txn.op == "W" else self.rlat
        if self.model_rows:
            bank = ((txn.addr - self.base) // self.row_bytes) % self.banks
            row = (txn.addr - self.base) // (self.row_bytes * self.banks)
            hit = self.open_row.get((ch, bank)) == row
            self.open_row[(ch, bank)] = row
            lat = self.row_hit if hit else self.row_miss
            self.row_hits += hit
            self.row_misses += (not hit)
        xfer = int(round(txn.size / self.ch_Bps * FS_PER_S))
        start = max(now + (lat if txn.op == "R" else 0), self.bus_free[ch])
        end = start + max(1, xfer)
        self.bus_free[ch] = end
        self.busy_fs[ch] += end - start
        done_t = end + (lat if txn.op == "W" else 0)
        txn.t_accepted = now if txn.t_accepted is None else txn.t_accepted
        self.trace.log(now, "ACCEPT", self.name, txn, channel=ch)

        def done() -> None:
            self.inflight[ch] -= 1
            self.bytes += txn.size
            self.lat_fs.append(self.eng.now - now)
            self.trace.log(self.eng.now, "SERVICE_END", self.name, txn)
            on_done(txn)
        self.eng.schedule_at(done_t, done, PRIO_COMPLETE, f"{self.name}.done")
        return True

    def stats(self, span_fs: int) -> dict:
        lat = np.array(self.lat_fs) / 1e6 if self.lat_fs else np.array([0.0])
        span = max(1, span_fs)
        return {"name": self.name, "fidelity": self.fidelity, "bytes": self.bytes,
                "Bps": self.bytes / (span / FS_PER_S), "peak_Bps": self.peak_Bps,
                "bus_utilisation": sum(self.busy_fs) / (span * self.channels),
                "avg_latency_ns": float(lat.mean()), "p95_latency_ns": float(np.percentile(lat, 95)),
                "row_hits": self.row_hits, "row_misses": self.row_misses, "rejects": self.rejects}
