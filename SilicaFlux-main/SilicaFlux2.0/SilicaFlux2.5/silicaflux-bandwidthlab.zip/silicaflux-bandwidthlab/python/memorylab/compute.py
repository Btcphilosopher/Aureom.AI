"""Peak and workload-dependent compute models for CPU, vector and tensor engines.

None of these models assumes that peak throughput is sustained: every
estimate is broken down into ideal compute cycles plus explicit losses
(tail processing, operand-delivery stalls, padding to the array, fixed
command overhead, writeback, dependency stalls).

The vector and tensor models are parametric.  With the SilicaFlux-V
parameters they reproduce the RTL-documented latency formulas exactly
(``rtl/accel/sfv_vec_engine.sv`` / ``sfv_tensor_engine.sv`` headers and
``tb/models/sfv_golden.py``), which is checked by the test suite:

  VE  CYCLES = 3 + ceil(LEN/4) * P (+1 for DOT with WRES), LEN=0 -> 2
  TE  CYCLES = 3 + 2K (+4 with WB)
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Mapping

from .units import (DEFAULT_CONVENTION, OpConvention, OpKind, Precision, Throughput,
                    UnitMismatchError)


class UnsupportedConfiguration(ValueError):
    """The requested operation/precision/size is not supported by the engine."""


# --------------------------------------------------------------------------- CPU
@dataclass
class InstructionMix:
    """Dynamic instruction counts by class plus the useful arithmetic work they perform."""

    counts: dict[str, float]
    useful_ops: float
    useful_kind: OpKind
    precision: Precision
    parallel_fraction: float = 1.0   # fraction that scales across cores (Amdahl)

    def __post_init__(self) -> None:
        if any(v < 0 for v in self.counts.values()):
            raise ValueError("instruction counts must be >= 0")
        if not 0.0 <= self.parallel_fraction <= 1.0:
            raise ValueError("parallel_fraction must be in [0, 1]")


@dataclass
class CpuModel:
    name: str
    cores: int
    freq_hz: float
    xlen: int = 32
    issue_width: int = 1                  # instructions per cycle per core (peak)
    cpi: dict[str, float] = field(default_factory=lambda: {"alu": 1.0})
    has_hw_mul: bool = False
    has_fpu: bool = False
    utilisation: float = 1.0              # pipeline utilisation assumption for "sustained peak"

    def __post_init__(self) -> None:
        if self.cores < 1 or self.freq_hz <= 0 or self.issue_width < 1:
            raise ValueError("cpu: cores >= 1, freq > 0, issue_width >= 1 required")
        if not 0 < self.utilisation <= 1:
            raise ValueError("cpu.utilisation must be in (0, 1]")
        if "alu" not in self.cpi:
            raise ValueError("cpu.cpi must define 'alu'")

    def supports(self, precision: Precision) -> bool:
        if precision.is_float:
            return self.has_fpu
        return precision.bytes * 8 <= self.xlen

    def cycles_per_mac(self) -> float:
        mul = self.cpi.get("mul" if self.has_hw_mul else "mul_sw")
        if mul is None:
            raise UnsupportedConfiguration(
                f"{self.name}: no CPI for {'mul' if self.has_hw_mul else 'mul_sw'} (needed for MAC rate)")
        return mul + self.cpi["alu"]

    def peak(self, kind: OpKind, precision: Precision,
             convention: OpConvention = DEFAULT_CONVENTION) -> Throughput:
        """Theoretical peak (no stalls, every issue slot doing useful arithmetic)."""
        if not self.supports(precision):
            raise UnsupportedConfiguration(f"{self.name}: precision {precision.value} not supported")
        base = self.cores * self.freq_hz * self.issue_width / self.cpi["alu"]
        if kind == OpKind.MAC:
            return Throughput(self.cores * self.freq_hz / self.cycles_per_mac(), kind, precision)
        if kind != precision.arithmetic_kind:
            raise UnitMismatchError(f"{kind.value} with {precision.value}")
        return Throughput(base, kind, precision)

    def estimate(self, mix: InstructionMix) -> dict:
        """Workload-dependent estimate with zero-wait memory (the DES adds memory stalls)."""
        if not self.supports(mix.precision):
            raise UnsupportedConfiguration(f"{self.name}: precision {mix.precision.value} not supported")
        missing = [c for c in mix.counts if c not in self.cpi]
        if missing:
            raise UnsupportedConfiguration(f"{self.name}: CPI not defined for {missing}")
        single_core_cycles = sum(n * self.cpi[c] for c, n in mix.counts.items()) / self.issue_width
        # Amdahl: serial part on one core, parallel part over all cores
        cycles = single_core_cycles * ((1 - mix.parallel_fraction) + mix.parallel_fraction / self.cores)
        t = cycles / self.freq_hz
        peak = self.peak(mix.useful_kind, mix.precision)
        achieved = mix.useful_ops / t if t > 0 else 0.0
        return {"engine": self.name, "cycles": cycles, "time_s": t, "achieved_ops_per_s": achieved,
                "peak_ops_per_s": peak.value, "kind": mix.useful_kind.value,
                "utilisation": achieved / peak.value if peak.value else 0.0,
                "instructions": sum(mix.counts.values())}


# --------------------------------------------------------------------------- vector
VECTOR_STREAMS = {
    # operand streams moved per beat (reads + writes), cf. sfv_vec_engine.sv header
    "vv": 3,       # read A, read B, write D
    "vs": 2,       # read A, write D (B = scalar)
    "dot_vv": 2,   # read A, read B (accumulate in RESULT)
    "dot_vs": 1,   # read A
}


@dataclass
class VectorModel:
    name: str
    lanes: int
    freq_hz: float
    element_bits: int = 32
    elems_per_lane_per_cycle: float = 1.0
    issue_per_cycle: float = 1.0            # uops (beats) per cycle
    macs_per_lane_per_cycle: float = 1.0
    ldst_bytes_per_cycle: float = 16.0      # operand port bandwidth (all streams share it)
    fixed_overhead_cycles: int = 3
    zero_length_cycles: int = 2
    wres_cycles: int = 1
    dependency_stall_cycles_per_beat: float = 0.0
    conflict_stall_cycles_per_beat: float = 0.0
    misaligned_extra_beats: int | None = None   # None: misalignment is an error (SilicaFlux-V)
    precisions: tuple[Precision, ...] = (Precision.INT32,)

    def __post_init__(self) -> None:
        if self.lanes < 1 or self.freq_hz <= 0 or self.ldst_bytes_per_cycle <= 0:
            raise ValueError("vector: lanes >= 1, freq > 0, ldst bandwidth > 0 required")

    @property
    def elem_bytes(self) -> int:
        return self.element_bits // 8

    def _check(self, precision: Precision) -> None:
        if precision not in self.precisions:
            raise UnsupportedConfiguration(
                f"{self.name}: precision {precision.value} not supported (supported: "
                f"{[p.value for p in self.precisions]}); widen data explicitly")

    def peak(self, kind: OpKind, precision: Precision,
             convention: OpConvention = DEFAULT_CONVENTION) -> Throughput:
        self._check(precision)
        if kind == OpKind.MAC:
            return Throughput(self.lanes * self.macs_per_lane_per_cycle * self.freq_hz, kind, precision)
        if kind != precision.arithmetic_kind:
            raise UnitMismatchError(f"{kind.value} with {precision.value}")
        return Throughput(self.lanes * self.elems_per_lane_per_cycle * self.freq_hz, kind, precision)

    def operand_port_Bps(self) -> float:
        return self.ldst_bytes_per_cycle * self.freq_hz

    def command(self, op: str, length: int, *, wres: bool = False, aligned: bool = True,
                precision: Precision = Precision.INT32) -> dict:
        """Cycle breakdown of one memory-to-memory vector command of ``length`` elements."""
        self._check(precision)
        if op not in VECTOR_STREAMS:
            raise UnsupportedConfiguration(f"{self.name}: unknown vector op class {op!r}")
        if length < 0:
            raise ValueError("length must be >= 0")
        if not aligned and self.misaligned_extra_beats is None:
            raise UnsupportedConfiguration(f"{self.name}: misaligned operands are rejected (ERRCODE ALIGN)")
        if length == 0:
            return {"cycles": self.zero_length_cycles, "beats": 0, "ideal": 0.0, "tail": 0.0,
                    "memory_stall": 0.0, "overhead": self.zero_length_cycles, "dependency": 0.0,
                    "conflict": 0.0, "writeback": 0, "elements": 0}
        per_cycle = self.lanes * self.elems_per_lane_per_cycle
        beats = math.ceil(length / per_cycle) + (0 if aligned else self.misaligned_extra_beats)
        streams = VECTOR_STREAMS[op]
        beat_bytes = streams * self.lanes * self.elem_bytes
        issue_cycles = 1.0 / self.issue_per_cycle
        port_cycles = beat_bytes / self.ldst_bytes_per_cycle
        cpb = max(issue_cycles, port_cycles) + self.dependency_stall_cycles_per_beat \
            + self.conflict_stall_cycles_per_beat
        wb = self.wres_cycles if (op.startswith("dot") and wres) else 0
        cycles = self.fixed_overhead_cycles + beats * cpb + wb
        ideal = length / per_cycle
        tail = beats * issue_cycles - ideal
        mem = beats * max(0.0, port_cycles - issue_cycles)
        return {"cycles": cycles, "beats": beats, "ideal": ideal, "tail": tail, "memory_stall": mem,
                "overhead": self.fixed_overhead_cycles, "dependency": beats * self.dependency_stall_cycles_per_beat,
                "conflict": beats * self.conflict_stall_cycles_per_beat, "writeback": wb,
                "elements": length, "bytes_moved": beats * beat_bytes}

    def command_cycles(self, op: str, length: int, *, wres: bool = False) -> float:
        return self.command(op, length, wres=wres)["cycles"]


# --------------------------------------------------------------------------- tensor
@dataclass
class TensorModel:
    """Output-stationary rows x cols MAC array, fed one k-step (rank-``depth`` update) at a time."""

    name: str
    rows: int
    cols: int
    freq_hz: float
    macs_per_pe_per_cycle: Mapping[Precision, float] = field(
        default_factory=lambda: {Precision.INT8: 1.0, Precision.UINT8: 1.0})
    depth: int = 1                           # k-values consumed per step (1 = rank-1 update)
    acc_bits: int = 32
    operand_bytes_per_cycle: float = 4.0     # A-column + B-row delivery bandwidth
    writeback_bytes_per_cycle: float = 16.0
    fixed_overhead_cycles: int = 3           # lock + prologue + drain (SilicaFlux-V)
    fill_cycles: int = 0
    drain_cycles: int = 0
    max_k: int = 1024
    accumulates_internally: bool = True

    def __post_init__(self) -> None:
        if self.rows < 1 or self.cols < 1 or self.depth < 1 or self.freq_hz <= 0:
            raise ValueError("tensor: rows, cols, depth >= 1 and freq > 0 required")
        if self.operand_bytes_per_cycle <= 0 or self.writeback_bytes_per_cycle <= 0:
            raise ValueError("tensor: operand/writeback bandwidth must be > 0")

    @property
    def pes(self) -> int:
        return self.rows * self.cols

    def _rate(self, precision: Precision) -> float:
        if precision not in self.macs_per_pe_per_cycle:
            raise UnsupportedConfiguration(
                f"{self.name}: precision {precision.value} not supported "
                f"(supported: {[p.value for p in self.macs_per_pe_per_cycle]})")
        return float(self.macs_per_pe_per_cycle[precision])

    def peak(self, kind: OpKind, precision: Precision,
             convention: OpConvention = DEFAULT_CONVENTION) -> Throughput:
        mac = self.pes * self._rate(precision) * self.freq_hz
        t = Throughput(mac, OpKind.MAC, precision)
        return t if kind == OpKind.MAC else t.to(kind, convention)

    def step_operand_bytes(self, precision: Precision) -> int:
        return (self.rows + self.cols) * self.depth * precision.bytes

    def step_cycles(self, precision: Precision) -> float:
        compute = self.depth / self._rate(precision)
        delivery = math.ceil(self.step_operand_bytes(precision) / self.operand_bytes_per_cycle)
        return max(compute, delivery)

    def writeback_cycles(self) -> int:
        return math.ceil(self.pes * (self.acc_bits // 8) / self.writeback_bytes_per_cycle)

    def operand_port_Bps(self) -> float:
        return self.operand_bytes_per_cycle * self.freq_hz

    def tile(self, k: int, precision: Precision, *, writeback: bool = True) -> dict:
        """One command: a rows x cols output tile over ``k`` reduction steps."""
        if not 1 <= k <= self.max_k:
            raise UnsupportedConfiguration(f"{self.name}: K must be 1..{self.max_k}, got {k}")
        steps = math.ceil(k / self.depth)
        sc = self.step_cycles(precision)
        ideal = k / self._rate(precision)            # cycles if every PE did one MAC per cycle
        wb = self.writeback_cycles() if writeback else 0
        cycles = self.fixed_overhead_cycles + self.fill_cycles + steps * sc + self.drain_cycles + wb
        return {"cycles": cycles, "ideal": ideal, "operand_stall": steps * sc - ideal,
                "overhead": self.fixed_overhead_cycles + self.fill_cycles + self.drain_cycles,
                "writeback": wb, "macs": self.pes * k, "operand_bytes": steps * self.step_operand_bytes(precision),
                "result_bytes": self.pes * (self.acc_bits // 8) if writeback else 0}

    def gemm(self, m: int, n: int, k: int, precision: Precision) -> dict:
        """Engine-only cycles for C[MxN] = A[MxK] B[KxN], tiled over rows x cols outputs.

        Operands are assumed resident in the engine's scratchpad; external data
        movement is accounted for by the workload/hierarchy models.  K larger than
        ``max_k`` is split into accumulate commands (writeback only on the last).
        """
        if min(m, n, k) < 1:
            raise ValueError("GEMM dimensions must be >= 1")
        tiles = math.ceil(m / self.rows) * math.ceil(n / self.cols)
        chunks = [self.max_k] * (k // self.max_k) + ([k % self.max_k] if k % self.max_k else [])
        per_tile = [self.tile(c, precision, writeback=(i == len(chunks) - 1)) for i, c in enumerate(chunks)]
        cyc = tiles * sum(t["cycles"] for t in per_tile)
        useful = m * n * k
        rate = self._rate(precision)
        ideal = useful / (self.pes * rate)
        padded = tiles * self.pes * k
        bd = {key: tiles * sum(t[key] for t in per_tile) for key in ("overhead", "writeback", "operand_stall")}
        padding_loss = (padded - useful) / (self.pes * rate)
        return {"cycles": cyc, "time_s": cyc / self.freq_hz, "tiles": tiles, "commands": tiles * len(chunks),
                "useful_macs": useful, "padded_macs": padded, "ideal_cycles": ideal,
                "padding_loss_cycles": padding_loss, "utilisation": ideal / cyc,
                "achieved_mac_per_s": useful / (cyc / self.freq_hz),
                "peak_mac_per_s": self.peak(OpKind.MAC, precision).value, **bd}
