"""Static (matplotlib PNG) charts in the SilicaFlux / Aureom.AI identity.

Palette (validated with the dataviz validator on the midnight-navy surface #0b1530:
lightness band, chroma floor, CVD separation >= 12 dE, contrast >= 3:1 -- all PASS):
  series-1 electric cyan #0e9cbb, series-2 gold #b8892a, series-3 violet #9474ee,
  series-4 coral #e05d6b.  Text uses text tokens, never series colours.
Encodings used consistently in every chart:
  colour  = memory level (roofs) or entity (series), assigned in fixed order
  marker  = result category: hollow circle ANALYTICAL_CEILING, filled circle EVENT_SIMULATED,
            diamond RTL_OBSERVED (SILICON_MEASURED is never plotted: no silicon data exists)
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Iterable, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

THEME = {
    "surface": "#0b1530", "surface_2": "#121f42", "grid": "#26345e", "axis": "#4a5a86",
    "text": "#f4f6fb", "text_2": "#b9c2da", "text_3": "#8792b0",
    "gold": "#b8892a", "cyan": "#0e9cbb", "violet": "#9474ee", "coral": "#e05d6b",
    "compute_roof": "#e9edf7",
}
SERIES = [THEME["cyan"], THEME["gold"], THEME["violet"], THEME["coral"]]
MARKERS = {"ANALYTICAL_CEILING": ("o", False), "EVENT_SIMULATED": ("o", True), "RTL_OBSERVED": ("D", True)}


def series_color(i: int) -> str:
    if i >= len(SERIES):
        raise ValueError("more than 4 categorical series: fold into 'other' or use small multiples")
    return SERIES[i]


def _style(ax, fig) -> None:
    fig.patch.set_facecolor(THEME["surface"])
    ax.set_facecolor(THEME["surface"])
    for s in ax.spines.values():
        s.set_color(THEME["axis"])
    ax.tick_params(colors=THEME["text_2"], labelsize=9)
    ax.xaxis.label.set_color(THEME["text_2"])
    ax.yaxis.label.set_color(THEME["text_2"])
    ax.title.set_color(THEME["text"])
    ax.grid(True, which="major", color=THEME["grid"], linewidth=0.6)
    ax.grid(True, which="minor", color=THEME["grid"], linewidth=0.3, alpha=0.5)


def _footer(fig, text: str) -> None:
    fig.text(0.01, 0.01, text, color=THEME["text_3"], fontsize=7.5, ha="left", va="bottom")


def roofline_png(results: Sequence[dict], out: str | Path, *, title: str, observed: Iterable[dict] = (),
                 footer: str = "") -> Path:
    """One Roofline (one engine, one op kind / precision) with all its memory-level roofs.

    ``results``: dicts from machine.analyse (ANALYTICAL_CEILING) for the SAME profile/engine.
    ``observed``: optional dicts {workload, intensity_level, intensity, achieved, category} with
    category EVENT_SIMULATED or RTL_OBSERVED, placed at their intensity for the binding level.
    """
    results = list(results)
    if not results:
        raise ValueError("no results to plot")
    keys = {(r["kind"], r["precision"], r["engine"], r["profile"]) for r in results}
    if len(keys) != 1:
        raise ValueError(f"one Roofline per engine/op kind/precision/profile, got {sorted(keys)}")
    kind_unit = results[0]["rate_unit"]
    iunit = results[0]["intensity_unit"]
    peak = results[0]["peak"]
    levels: dict[str, float] = {}
    for r in results:
        for lv in r["levels"]:
            levels[lv["level"]] = lv["effective_bandwidth_Bps"]
    finite_i = [lv["intensity"] for r in results for lv in r["levels"] if math.isfinite(lv["intensity"])]
    ridges = [peak / b for b in levels.values()]
    xmin = min(finite_i + ridges) / 8
    xmax = max(finite_i + ridges) * 8
    xs = np.logspace(math.log10(xmin), math.log10(xmax), 400)
    fig, ax = plt.subplots(figsize=(9.5, 6.0), dpi=150)
    _style(ax, fig)
    ax.set_xscale("log")
    ax.set_yscale("log")
    # compute-bound / memory-bound regions relative to the lowest (binding) memory roof
    bmin = min(levels.values())
    ridge = peak / bmin
    ax.axvspan(xmin, ridge, color=THEME["surface_2"], zorder=0)
    ax.text(xmin * 1.15, peak * 1.25, "memory-bound region", color=THEME["text_3"], fontsize=8)
    ax.text(ridge * 1.15, peak * 1.25, "compute-bound region", color=THEME["text_3"], fontsize=8)
    ax.axhline(peak, color=THEME["compute_roof"], lw=2, zorder=2)
    from .units import si
    ax.text(xmax / 1.1, peak * 0.86, f"peak {si(peak)}{kind_unit}", color=THEME["text"], fontsize=8.5, ha="right")
    for i, (name, b) in enumerate(levels.items()):
        c = series_color(i)
        ys = np.minimum(peak, xs * b)
        ax.plot(xs, ys, color=c, lw=2, zorder=3, label=f"{name}: {b / 1e9:.3g} GB/s")
    # hierarchical Roofline: one ring per (workload, level) at that level's intensity, all at the
    # workload's ceiling; ring colour = level, the binding level's ring is filled-edge thicker and labelled
    level_color = {name: series_color(i) for i, name in enumerate(levels)}
    groups: dict[tuple, list[str]] = {}
    for r in results:
        y = r["ceiling"]
        pts = [(lv["level"], lv["intensity"]) for lv in r["levels"] if math.isfinite(lv["intensity"])]
        if len(pts) > 1:
            ax.plot([q[1] for q in pts], [y] * len(pts), color=THEME["text_3"], lw=0.8, zorder=4)
        for name, x in pts:
            bind = name == r["binding"]
            ax.scatter([x], [y], s=70 if bind else 40, facecolors="none", edgecolors=level_color[name],
                       linewidths=2.2 if bind else 1.2, zorder=5)
        bx = next((x for n, x in pts if n == r["binding"]), pts[-1][1] if pts else xmax / 2)
        groups.setdefault((round(math.log10(bx), 3), round(math.log10(y), 3)), []).append(r["workload"])
    for (lx, ly), names in groups.items():
        ax.annotate("\n".join(names), (10 ** lx, 10 ** ly), xytext=(8, -4), textcoords="offset points",
                    color=THEME["text_2"], fontsize=7.5, va="top", zorder=6)
    for o in observed:
        mk, filled = MARKERS[o["category"]]
        ax.scatter([o["intensity"]], [o["achieved"]], s=55, marker=mk,
                   facecolors=THEME["text"] if filled else "none", edgecolors=THEME["surface"],
                   linewidths=1.5, zorder=7)
    ax.set_xlim(xmin, xmax)
    ys_all = [r["ceiling"] for r in results] + [o["achieved"] for o in observed]
    ax.set_ylim(min(ys_all + [peak]) / 10, peak * 2.2)
    ax.set_xlabel(f"arithmetic intensity at the interface [{iunit}]")
    ax.set_ylabel(f"performance [{kind_unit}, {results[0]['precision']}]")
    ax.set_title(title, fontsize=11, loc="left", color=THEME["text"])
    # legend: roofs + marker meaning
    from matplotlib.lines import Line2D
    handles, labels = ax.get_legend_handles_labels()
    handles += [Line2D([], [], marker="o", ls="", mfc="none", mec=THEME["text"],
                       label="analytical ceiling (ring per level; thick = binding)")]
    if any(o["category"] == "EVENT_SIMULATED" for o in observed):
        handles += [Line2D([], [], marker="o", ls="", mfc=THEME["text"], mec=THEME["text"], label="event-simulated")]
    if any(o["category"] == "RTL_OBSERVED" for o in observed):
        handles += [Line2D([], [], marker="D", ls="", mfc=THEME["text"], mec=THEME["text"], label="RTL-observed")]
    leg = ax.legend(handles=handles, loc="lower right", fontsize=8, frameon=True)
    leg.get_frame().set_facecolor(THEME["surface_2"])
    leg.get_frame().set_edgecolor(THEME["axis"])
    for t in leg.get_texts():
        t.set_color(THEME["text"])
    _footer(fig, footer or "ANALYTICAL_CEILING = upper bound, not a measurement. No silicon measurements exist.")
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, facecolor=THEME["surface"])
    plt.close(fig)
    return out


def bar_png(labels: Sequence[str], values: Sequence[float], out: str | Path, *, title: str, xlabel: str,
            footer: str = "", color_index: int = 0, value_fmt: str = "{:.3g}") -> Path:
    fig, ax = plt.subplots(figsize=(9, max(3.0, 0.38 * len(labels) + 1.2)), dpi=150)
    _style(ax, fig)
    y = np.arange(len(labels))
    ax.barh(y, values, color=series_color(color_index), height=0.62, zorder=3)
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.grid(True, axis="x", color=THEME["grid"], linewidth=0.6)
    ax.grid(False, axis="y")
    vmax = max(values) if len(values) else 1
    for yi, v in zip(y, values):
        ax.text(v + vmax * 0.01, yi, value_fmt.format(v), va="center", color=THEME["text_2"], fontsize=8)
    ax.set_xlim(0, vmax * 1.15 if vmax > 0 else 1)
    ax.set_xlabel(xlabel)
    ax.set_title(title, fontsize=11, loc="left", color=THEME["text"])
    _footer(fig, footer)
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, facecolor=THEME["surface"])
    plt.close(fig)
    return out


def lines_png(x: Sequence[float], series: dict[str, Sequence[float]], out: str | Path, *, title: str,
              xlabel: str, ylabel: str, logx: bool = False, footer: str = "") -> Path:
    fig, ax = plt.subplots(figsize=(9, 5.2), dpi=150)
    _style(ax, fig)
    for i, (name, ys) in enumerate(series.items()):
        ax.plot(x, ys, color=series_color(i), lw=2, marker="o", ms=5, label=name, zorder=3)
        ax.annotate(name, (x[-1], ys[-1]), xytext=(6, 0), textcoords="offset points", color=THEME["text_2"],
                    fontsize=8, va="center")
    if logx:
        ax.set_xscale("log", base=2)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontsize=11, loc="left", color=THEME["text"])
    if len(series) >= 2:
        leg = ax.legend(fontsize=8, frameon=True)
        leg.get_frame().set_facecolor(THEME["surface_2"])
        leg.get_frame().set_edgecolor(THEME["axis"])
        for t in leg.get_texts():
            t.set_color(THEME["text"])
    _footer(fig, footer)
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, facecolor=THEME["surface"])
    plt.close(fig)
    return out
