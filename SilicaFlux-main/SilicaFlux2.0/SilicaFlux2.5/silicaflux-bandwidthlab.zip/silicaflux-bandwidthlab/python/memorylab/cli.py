"""Command-line interface: python -m memorylab <command> ...  (see --help of each command)."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

from . import machine, report as rep, simulator as sim, workloads as wl
from .compute import UnsupportedConfiguration
from .config import ConfigError, load_profile
from .event_engine import LimitExceeded, SimulationError
from .provenance import experiment_record
from .trace_import import TraceFormatError


def _profile_name(path: str) -> str:
    return Path(path).stem


def _wl_by_name(name: str, size: str) -> list[tuple[wl.Workload, str]]:
    pool = rep.sim_set(size) + rep.analysis_set(size)
    seen, out = set(), []
    for w, e in pool:
        if (name in ("all", w.name, w.family) or w.name.startswith(name)) and w.name + e not in seen:
            seen.add(w.name + e)
            out.append((w, e))
    if not out:
        raise ConfigError(f"no workload matches {name!r}; examples: {sorted({w.name for w, _ in pool})[:10]}")
    return out


def cmd_roofline(a: argparse.Namespace) -> int:
    p = load_profile(a.config)
    out = Path(a.out)
    rows = []
    results = []
    for w, eng in _wl_by_name(a.workload, a.size):
        if eng not in p.roofline:
            continue
        try:
            r = machine.analyse(p, w, eng)
        except (UnsupportedConfiguration, wl.InfeasibleStrategy) as e:
            print(f"  skip {w.name} on {eng}: {e}")
            continue
        results.append(r)
        rows.append({"workload": w.name, "engine": eng, "unit": r["rate_unit"], "peak": r["peak"], "ceiling": r["ceiling"],
                     "binding": r["binding"], "bound": r["bound"], "unused_compute": r["unused_compute_fraction"]})
    if not results:
        raise ConfigError("no workload could be analysed on this profile")
    df = pd.DataFrame(rows)
    out.mkdir(parents=True, exist_ok=True)
    name = _profile_name(a.config)
    df.to_csv(out / f"roofline_{name}.csv", index=False)
    rep.write_json(out / f"roofline_{name}.json", {"category": "ANALYTICAL_CEILING", "results": results,
                                                    "provenance": experiment_record(config_path=a.config, config_dict=None,
                                                                                    seed=None, command=" ".join(sys.argv))})
    from . import plotting
    for eng, kind, prec in sorted({(r["engine"], r["kind"].value if hasattr(r["kind"], "value") else r["kind"],
                                    r["precision"]) for r in results}):
        grp = [r for r in results if r["engine"] == eng and r["precision"] == prec]
        plotting.roofline_png(grp, out / f"roofline_{name}_{eng}_{prec}.png",
                              title=f"{p.name} - {eng} engine, hierarchical Roofline ({prec})")
    with pd.option_context("display.width", 200, "display.max_columns", 20):
        print(df.to_string(index=False, float_format=lambda x: f"{x:.4g}"))
    print(f"ANALYTICAL_CEILING results written to {out}")
    return 0


def cmd_simulate(a: argparse.Namespace) -> int:
    p = load_profile(a.config)
    out = Path(a.out)
    rows = []
    for w, eng in _wl_by_name(a.workload, a.size):
        try:
            r = sim.simulate(p, w, eng, seed=a.seed, trace=a.trace, max_events=a.max_events)
        except (UnsupportedConfiguration, wl.InfeasibleStrategy, LimitExceeded, SimulationError) as e:
            print(f"  {w.name} on {eng}: {type(e).__name__}: {e}")
            continue
        r.pop("_trace_rows", None)
        rows.append(rep._sim_summary(r))
        rep.write_json(out / f"sim_{_profile_name(a.config)}_{w.name}_{eng}.json",
                       {**r, "provenance": experiment_record(config_path=a.config, config_dict=None, seed=a.seed,
                                                             command=" ".join(sys.argv))})
    if not rows:
        raise ConfigError("nothing simulated")
    df = pd.DataFrame(rows)
    df.to_csv(out / f"simulated_{_profile_name(a.config)}.csv", index=False)
    with pd.option_context("display.width", 220, "display.max_columns", 12):
        print(df[["workload", "engine", "achieved_ops_per_s", "compute_utilisation", "bound", "busiest_resource",
                  "makespan_cycles"]].to_string(index=False, float_format=lambda x: f"{x:.4g}"))
    print(f"EVENT_SIMULATED results written to {out}")
    return 0


def cmd_sweep(a: argparse.Namespace) -> int:
    from . import sweep as sw
    spec = sw.load_sweep(a.config)
    if a.max_runs:
        spec.max_runs = a.max_runs
    out = Path(a.out)
    name = Path(a.config).stem
    r = sw.run_sweep(spec, (lambda m: print(m)) if a.verbose else None)
    out.mkdir(parents=True, exist_ok=True)
    r["df"].to_csv(out / f"{name}.csv", index=False)
    from . import optimisation as opt
    if spec.mode == "ofat":
        mg = opt.marginal_gains(r["df"], {k: v[1] for k, v in sw.KNOBS.items()})
        mg.to_csv(out / f"{name}_marginal_gains.csv", index=False)
        sat = opt.saturation_points(mg)
        sat.to_csv(out / f"{name}_saturation.csv", index=False)
        print(sat.to_string(index=False))
    rep.write_json(out / f"{name}.json", {"points": r["points"], "stopped": r["stopped"], "wall_s": r["wall_s"],
                                          "provenance": experiment_record(config_path=a.config, config_dict=None,
                                                                          seed=spec.seed, command=" ".join(sys.argv))})
    print(f"{len(r['df'])} rows, stopped={r['stopped']}, written to {out}")
    return 0


def cmd_rtl(a: argparse.Namespace) -> int:
    st = rep.stage_rtl(Path(a.out), sim_name=a.sim, n_per_master=a.n)
    print(json.dumps(st, indent=1))
    return 0 if not any(str(v).startswith("PENDING") for v in st.values()) else 3


def cmd_import_trace(a: argparse.Namespace) -> int:
    from . import trace_import as ti
    if a.vcd:
        df = ti.decode_handshake(a.trace, clock=a.clock, valid=a.valid, ready=a.ready)
        print(df.head(20).to_string())
        print(f"{len(df)} handshakes decoded")
        return 0
    df = ti.read_trace(a.trace, clock_hz=a.clock_hz)
    m = ti.trace_metrics(df)
    print(json.dumps(m, indent=1))
    return 0 if not m["problems"] else 4


def cmd_audit(a: argparse.Namespace) -> int:
    p = load_profile(a.config)
    rows = [{"parameter": k, "value": s.value, "provenance": s.provenance.value, "source": s.source}
            for k, s in p.sourced_leaves()]
    df = pd.DataFrame(rows)
    if a.csv:
        df.to_csv(a.csv, index=False)
    with pd.option_context("display.width", 250, "display.max_colwidth", 90, "display.max_rows", 500):
        print(df.to_string(index=False))
    print(p.provenance_summary())
    return 0


def cmd_report(a: argparse.Namespace) -> int:
    r = __import__("memorylab.dashboard", fromlist=["x"]).build_report(Path(a.run_dir))
    print(json.dumps(r, indent=1))
    return 0


def cmd_all(a: argparse.Namespace) -> int:
    out = Path(a.out)
    rep.run_all(out, size=a.size, seed=a.seed, rtl=not a.no_rtl,
                sweeps=[] if a.no_sweeps else None)
    r = __import__("memorylab.dashboard", fromlist=["x"]).build_report(out)
    print(json.dumps(r, indent=1))
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="memorylab", description="SilicaFlux MemoryLab: Roofline + memory simulator")
    sub = ap.add_subparsers(dest="cmd", required=True)
    cfg = Path(__file__).resolve().parent / "configs"

    def common(s, need_cfg=True):
        if need_cfg:
            s.add_argument("--config", required=True, help=f"profile YAML (e.g. {cfg / 'silicaflux_v.yaml'})")
        s.add_argument("--out", default="reports/memorylab/cli_run", help="output directory")
    s = sub.add_parser("roofline", help="analytical hierarchical Roofline (ANALYTICAL_CEILING)")
    common(s)
    s.add_argument("--workload", default="all")
    s.add_argument("--size", default="medium", choices=["small", "medium", "large"])
    s.set_defaults(fn=cmd_roofline)
    s = sub.add_parser("simulate", help="event-driven simulation (EVENT_SIMULATED)")
    common(s)
    s.add_argument("--workload", default="gemm_64x64x64_double_buffered")
    s.add_argument("--size", default="medium", choices=["small", "medium", "large"])
    s.add_argument("--seed", type=int, default=1)
    s.add_argument("--trace", action="store_true", help="record and check the transaction trace")
    s.add_argument("--max-events", type=int, default=20_000_000)
    s.set_defaults(fn=cmd_simulate)
    s = sub.add_parser("sweep", help="architecture sweep + marginal gains")
    common(s)
    s.add_argument("--max-runs", type=int, default=0)
    s.add_argument("--verbose", action="store_true")
    s.set_defaults(fn=cmd_sweep)
    s = sub.add_parser("rtl", help="RTL evidence: bank-controller equivalence, sfv_tile latency, calibration")
    common(s, need_cfg=False)
    s.add_argument("--sim", default="verilator", choices=["verilator", "icarus"])
    s.add_argument("--n", type=int, default=400, help="requests per master per equivalence case")
    s.set_defaults(fn=cmd_rtl)
    s = sub.add_parser("import-trace", help="import a CSV/JSON trace (or decode a VCD handshake)")
    s.add_argument("--trace", required=True)
    s.add_argument("--clock-hz", type=float, default=None)
    s.add_argument("--vcd", action="store_true")
    s.add_argument("--clock", default="clk")
    s.add_argument("--valid", default="valid")
    s.add_argument("--ready", default="ready")
    s.set_defaults(fn=cmd_import_trace)
    s = sub.add_parser("audit-params", help="list every parameter with its provenance and source")
    s.add_argument("--config", required=True)
    s.add_argument("--csv", default=None)
    s.set_defaults(fn=cmd_audit)
    s = sub.add_parser("report", help="build dashboard.html, figures and REPORT.md from a run directory")
    s.add_argument("--run-dir", required=True)
    s.set_defaults(fn=cmd_report)
    s = sub.add_parser("all", help="run every stage into one run directory and build the report")
    s.add_argument("--out", default="reports/memorylab/example_run")
    s.add_argument("--size", default="medium", choices=["small", "medium", "large"])
    s.add_argument("--seed", type=int, default=1)
    s.add_argument("--no-rtl", action="store_true")
    s.add_argument("--no-sweeps", action="store_true")
    s.set_defaults(fn=cmd_all)
    return ap


def main(argv: list[str] | None = None) -> int:
    ap = build_parser()
    a = ap.parse_args(argv)
    try:
        return a.fn(a)
    except (ConfigError, TraceFormatError, FileNotFoundError) as e:
        print(f"memorylab: error: {e}", file=sys.stderr)
        return 2
    except (UnsupportedConfiguration, wl.InfeasibleStrategy) as e:
        print(f"memorylab: unsupported: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
