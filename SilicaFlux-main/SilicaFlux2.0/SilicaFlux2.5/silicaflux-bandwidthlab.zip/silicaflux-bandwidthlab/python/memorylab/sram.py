"""SRAM models at two fidelity levels.

BankController  -- cycle-level mirror of the SilicaFlux SRAM Wrapper Library's
                   ``sram_bank_controller`` + ``sram_rsp_path`` (silicaflux-sramlib,
                   rtl/mem/sram_bank_controller.sv, rtl/mem/sram_rsp_path.sv):
                   N masters x B single-port banks, low/high interleave, per-bank
                   round-robin (pointer -> granted+1) or fixed priority, acceptance ==
                   issue, per-master response credits (RSP_FIFO_DEPTH), LATENCY-deep tag
                   pipeline, response FIFO with bypass, write acknowledgements, error
                   responses for out-of-range / misaligned addresses, data storage with
                   write masks.  Validated against Verilator traces (tests/memorylab/
                   test_rtl_equivalence.py) for the tested configurations only.

SramArray       -- transaction-level banked array for system simulation: bank
                   reservation per word, configurable ports (1RW / 1R1W / 2RW),
                   per-array request queue depth with backpressure, read/write
                   latencies, optional engine-priority windows (a fraction of bank
                   cycles reserved by an accelerator), per-bank statistics.
                   Arbitration is first-come-first-served in acceptance order.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
import math
from typing import Callable

import numpy as np

from .event_engine import (PRIO_COMPLETE, PRIO_LATE, PRIO_TICK, ClockDomain, EventEngine, Trace,
                           Transaction)


class SramConfigError(ValueError):
    pass


def is_pow2(n: int) -> bool:
    return n >= 1 and (n & (n - 1)) == 0


def bank_map(word: int, banks: int, bank_depth: int, interleave: str) -> tuple[int, int]:
    """(bank, row) of a word address."""
    if banks == 1:
        return 0, word
    if interleave == "low":
        return word % banks, word // banks
    if interleave == "high":
        return word // bank_depth, word % bank_depth
    if interleave == "xor":
        # XOR-folded low interleave (sramlib 'next action'; memoryflow sf_spm_banked INTERLEAVE=1)
        hi = word // banks
        return (word ^ hi) % banks, hi
    raise SramConfigError(f"unknown interleave {interleave!r}")


# =========================================================================== cycle-level controller
@dataclass
class BankCtrlConfig:
    num_masters: int = 4
    num_banks: int = 4
    data_width: int = 32
    bank_depth: int = 1024
    read_latency: int = 1
    arbitration: str = "rr"            # rr | fixed
    interleave: str = "low"            # low | high | xor (xor: not in sramlib RTL)
    addr_mode: str = "word"            # word | byte
    rsp_fifo_depth: int | None = None  # default read_latency + 1
    write_ack: bool = True
    mask_width: int | None = None
    allow_non_pow2_banks: bool = False

    def __post_init__(self) -> None:
        if not 1 <= self.num_masters <= 16:
            raise SramConfigError("num_masters must be 1..16 (sramlib limit)")
        if self.num_banks < 1:
            raise SramConfigError("num_banks must be >= 1")
        if not is_pow2(self.num_banks) and not self.allow_non_pow2_banks:
            raise SramConfigError("num_banks must be a power of two (sramlib); set allow_non_pow2_banks "
                                  "for a non-RTL-compatible modulo mapping")
        if self.read_latency < 1:
            raise SramConfigError("read_latency must be >= 1 cycle")
        if self.bank_depth < 2:
            raise SramConfigError("bank_depth must be >= 2")
        if self.arbitration not in ("rr", "fixed") or self.interleave not in ("low", "high", "xor"):
            raise SramConfigError("arbitration rr|fixed, interleave low|high|xor")
        if self.interleave == "high" and not is_pow2(self.bank_depth):
            raise SramConfigError("interleave=high requires a power-of-two bank_depth")
        if self.addr_mode not in ("word", "byte"):
            raise SramConfigError("addr_mode word|byte")
        if self.addr_mode == "byte" and (self.data_width % 8 or not is_pow2(self.data_width // 8)):
            raise SramConfigError("byte addressing requires DATA_WIDTH/8 to be a power of two")
        if self.rsp_fifo_depth is None:
            self.rsp_fifo_depth = self.read_latency + 1
        if self.rsp_fifo_depth < 0:
            raise SramConfigError("rsp_fifo_depth must be >= 0")
        if self.mask_width is None:
            self.mask_width = self.data_width // 8 if self.data_width % 8 == 0 else 1
        if self.data_width % self.mask_width:
            raise SramConfigError("mask_width must divide data_width")

    @property
    def rtl_compatible(self) -> bool:
        return is_pow2(self.num_banks) and self.interleave in ("low", "high")

    @property
    def total_words(self) -> int:
        return self.num_banks * self.bank_depth


@dataclass
class _Rsp:
    txn: Transaction
    data: int
    err: bool
    we: bool
    known: int = -1             # bits of ``data`` that were written before the read (-1: all)


class BankController:
    """Cycle-level model. Masters call ``present``; callbacks report acceptance and responses."""

    def __init__(self, eng: EventEngine, clock: ClockDomain, cfg: BankCtrlConfig, *, name: str = "sram_bank_ctrl",
                 trace: Trace | None = None,
                 rsp_ready: Callable[[int, int], bool] | None = None,
                 on_accept: Callable[[int, Transaction, int], None] | None = None,
                 on_response: Callable[[int, Transaction, int], None] | None = None) -> None:
        self.eng, self.clock, self.cfg, self.name = eng, clock, cfg, name
        self.trace = trace or Trace(enabled=False)
        self.rsp_ready = rsp_ready or (lambda m, c: True)
        self.on_accept = on_accept
        self.on_response = on_response
        nm, nb, lat = cfg.num_masters, cfg.num_banks, cfg.read_latency
        self.mem: dict[int, int] = {}
        self.known: dict[int, int] = {}
        self.req: list[Transaction | None] = [None] * nm
        self.ptr = [0] * nb
        self.oc = [0] * nm
        self.fifo: list[deque[_Rsp]] = [deque() for _ in range(nm)]
        self.pipe: list[list[_Rsp | None]] = [[None] * lat for _ in range(nm)]
        self._tick_at: set[int] = set()
        self._last_tick: int | None = None
        self.boff = int(math.log2(cfg.data_width // 8)) if (cfg.addr_mode == "byte" and cfg.data_width >= 16) else 0
        # statistics
        self.cycles_active = 0
        self.first_cycle: int | None = None
        self.last_cycle: int | None = None
        self.accepted = [0] * nm
        self.conflicts = [0] * nm
        self.responses = [0] * nm
        self.bank_accesses = [0] * nb
        self.bank_conflicts = [0] * nb
        self.latencies: list[int] = []
        self.fifo_occ_sum = [0] * nm
        self.fifo_occ_max = [0] * nm
        self.bp_cycles = [0] * nm
        self.bank_timeline: dict[int, list[int]] = {}
        self.acc_cycle: dict[int, int] = {}
        self.log: list[tuple] = []          # (cycle, event, master, tid, bank) for trace comparison
        eng.register(self)

    # ------------------------------------------------------------------ API
    def outstanding(self) -> int:
        return sum(1 for r in self.req if r is not None) + sum(self.oc)

    def can_present(self, m: int) -> bool:
        return self.req[m] is None

    def present(self, m: int, txn: Transaction) -> None:
        if not 0 <= m < self.cfg.num_masters:
            raise IndexError(f"master {m} out of range")
        if self.req[m] is not None:
            raise RuntimeError(f"master {m}: request already presented (valid must be held until accepted)")
        if txn.size != self.cfg.data_width // 8:
            raise ValueError(f"bank controller transfers one {self.cfg.data_width}-bit word per request")
        self.req[m] = txn
        txn.t_issued = self.eng.now
        txn.path.append(self.name)
        self.trace.log(self.eng.now, "ISSUE", self.name, txn, master_port=m)
        self._ensure_tick()

    def cycle_now(self) -> int:
        return self.clock.edge_index_at_or_after(self.eng.now)

    # ------------------------------------------------------------------ clocking
    def _ensure_tick(self) -> None:
        now = self.eng.now
        t = self.clock.next_edge(now, strictly_after=(self._last_tick == now))
        if t not in self._tick_at:
            self._tick_at.add(t)
            self.eng.schedule_at(t, self._tick, PRIO_TICK, f"{self.name}.tick")

    def _busy(self) -> bool:
        return any(r is not None for r in self.req) or any(any(x is not None for x in p) for p in self.pipe) \
            or any(self.fifo)

    def _decode(self, txn: Transaction) -> tuple[bool, int, int, int]:
        a = txn.addr
        mis = self.boff > 0 and (a & ((1 << self.boff) - 1)) != 0
        w = a >> self.boff
        ok = (not mis) and w < self.cfg.total_words
        b, r = bank_map(w, self.cfg.num_banks, self.cfg.bank_depth, self.cfg.interleave) if ok else (0, 0)
        return ok, b, r, w

    def _tick(self) -> None:
        now = self.eng.now
        self._tick_at.discard(now)
        self._last_tick = now
        cyc = self.clock.edge_index_at_or_after(now)
        cfg = self.cfg
        nm, nb, lat = cfg.num_masters, cfg.num_banks, cfg.read_latency
        self.cycles_active += 1
        self.first_cycle = cyc if self.first_cycle is None else self.first_cycle
        self.last_cycle = cyc
        # ---- response side (combinational during this cycle)
        rdy = [bool(self.rsp_ready(m, cyc)) for m in range(nm)]
        hs: list[_Rsp | None] = [None] * nm
        for m in range(nm):
            stg = self.pipe[m][lat - 1]
            head = self.fifo[m][0] if self.fifo[m] else stg
            if head is not None:
                if rdy[m]:
                    hs[m] = head
                else:
                    self.bp_cycles[m] += 1
                    if cfg.rsp_fifo_depth == 0:
                        raise RuntimeError(f"{self.name}: RSP_FIFO_DEPTH=0 requires rsp_ready=1 (response would be lost)")
        # ---- request side
        can = [(self.oc[m] < cfg.rsp_fifo_depth) if cfg.rsp_fifo_depth > 0 else True for m in range(nm)]
        dec: list[tuple | None] = [None] * nm
        breq: list[list[int]] = [[] for _ in range(nb)]
        for m in range(nm):
            t = self.req[m]
            if t is None:
                continue
            ok, b, r, w = self._decode(t)
            we = t.op == "W"
            need = (not we) or cfg.write_ack or (not ok)
            credit = can[m] or (not need)
            dec[m] = (ok, b, r, w, we, need, credit)
            if ok and credit:
                breq[b].append(m)
        gnt = [False] * nm
        gidx = [None] * nb
        for b in range(nb):
            if not breq[b]:
                continue
            reqset = set(breq[b])
            for k in range(nm):
                idx = (self.ptr[b] + k) % nm if cfg.arbitration == "rr" else k
                if idx in reqset:
                    gnt[idx] = True
                    gidx[b] = idx
                    break
        accepted: list[int] = []
        for m in range(nm):
            d = dec[m]
            if d is None:
                continue
            ok, b, r, w, we, need, credit = d
            ready = gnt[m] or ((not ok) and can[m])
            if ok and credit and not gnt[m]:
                self.log.append((cyc, "CONF", m, self.req[m].tid, b))
                self.conflicts[m] += 1
                self.bank_conflicts[b] += 1
                self.trace.log(now, "CONFLICT", self.name, self.req[m], bank=b, cycle=cyc)
            if ready:
                accepted.append(m)
        # ---- edge: array access + tag pipeline + FIFO + credits + pointers
        new_tag: list[_Rsp | None] = [None] * nm
        acc_txns: list[tuple[int, Transaction]] = []
        for m in accepted:
            t = self.req[m]
            acc_txns.append((m, t))
            ok, b, r, w, we, need, credit = dec[m]
            data = 0
            kn = -1
            if ok:
                self.bank_accesses[b] += 1
                self.bank_timeline.setdefault(b, []).append(cyc)
                if we:
                    old = self.mem.get(w, 0)
                    lw = cfg.data_width // cfg.mask_width
                    mask = t.mask if t.mask is not None else (1 << cfg.mask_width) - 1
                    bits = 0
                    for lane in range(cfg.mask_width):
                        if (mask >> lane) & 1:
                            bits |= ((1 << lw) - 1) << (lane * lw)
                    self.mem[w] = (old & ~bits) | ((t.data or 0) & bits)
                    self.known[w] = self.known.get(w, 0) | bits
                else:
                    data = self.mem.get(w, 0)
                    kn = self.known.get(w, 0)
            t.t_accepted = now
            t.t_service_start = now
            self.accepted[m] += 1
            self.acc_cycle[t.tid] = cyc
            self.trace.log(now, "ACCEPT", self.name, t, bank=b if ok else None, cycle=cyc, error=not ok)
            self.log.append((cyc, "ACC", m, t.tid, b if ok else -1))
            if need:
                rd = ok and not we
                new_tag[m] = _Rsp(t, data if rd else 0, not ok, we, kn if rd else -1)
            else:                       # posted write: complete at acceptance
                self._complete(m, t, cyc, posted=True)
            self.req[m] = None
        for b in range(nb):
            if gidx[b] is not None:
                self.ptr[b] = 0 if gidx[b] == nm - 1 else gidx[b] + 1
        for m in range(nm):
            stg = self.pipe[m][lat - 1]
            delivered = hs[m]
            if self.fifo[m] and delivered is self.fifo[m][0]:
                self.fifo[m].popleft()
                if stg is not None:
                    self.fifo[m].append(stg)
            elif delivered is not None:          # bypass of the stage entry
                pass
            elif stg is not None:
                self.fifo[m].append(stg)
            if cfg.rsp_fifo_depth > 0 and len(self.fifo[m]) > cfg.rsp_fifo_depth:
                raise AssertionError(f"{self.name}: response FIFO overflow on master {m} (model bug)")
            self.pipe[m] = [new_tag[m]] + self.pipe[m][:-1]
            self.oc[m] += (1 if new_tag[m] is not None else 0) - (1 if delivered is not None else 0)
            if self.oc[m] < 0 or (cfg.rsp_fifo_depth > 0 and self.oc[m] > cfg.rsp_fifo_depth):
                raise AssertionError(f"{self.name}: credit counter out of range on master {m}")
            occ = len(self.fifo[m])
            self.fifo_occ_sum[m] += occ
            self.fifo_occ_max[m] = max(self.fifo_occ_max[m], occ)
            if delivered is not None:
                self._complete(m, delivered.txn, cyc, rsp=delivered)
        # notify masters after the edge so they can present new requests for the next edge
        if self.on_accept and acc_txns:
            self.eng.schedule(0, lambda a=tuple(acc_txns): [self.on_accept(m, t, cyc) for m, t in a], PRIO_LATE,
                              f"{self.name}.accept_cb")
        if self._busy():
            self._ensure_tick()

    def _complete(self, m: int, t: Transaction, cyc: int, rsp: _Rsp | None = None, posted: bool = False) -> None:
        t.t_service_end = self.eng.now
        t.t_completed = self.eng.now
        if rsp is not None:
            t.data = rsp.data
            t.error = rsp.err
            t.tag = (t.tag, rsp.known) if not isinstance(t.tag, tuple) else t.tag
        self.responses[m] += 1
        lat_c = cyc - self.acc_cycle[t.tid]
        if not posted:
            self.latencies.append(lat_c)
            self.log.append((cyc, "RSP", m, t.tid, -1))
        self.trace.log(self.eng.now, "RESPONSE" if not posted else "SERVICE_END", self.name, t, cycle=cyc)
        self.trace.log(self.eng.now, "COMPLETE", self.name, t, cycle=cyc, latency_cycles=lat_c, posted=posted)
        if self.on_response and not posted:      # posted writes produce no response (WRITE_ACK=0)
            self.on_response(m, t, cyc)
        if t.on_complete:
            t.on_complete(t)

    # ------------------------------------------------------------------ results
    def stats(self) -> dict:
        nm = self.cfg.num_masters
        span = (self.last_cycle - self.first_cycle + 1) if self.first_cycle is not None else 0
        lat = np.array(self.latencies) if self.latencies else np.array([0])
        tot_acc = sum(self.accepted)
        tot_conf = sum(self.conflicts)
        return {
            "cycles": span, "accepted": tot_acc, "words_per_cycle": tot_acc / span if span else 0.0,
            "peak_words_per_cycle": min(nm, self.cfg.num_banks),
            "conflict_stalls": tot_conf,
            "conflict_rate": tot_conf / (tot_acc + tot_conf) if (tot_acc + tot_conf) else 0.0,
            "avg_latency_cycles": float(lat.mean()), "max_latency_cycles": int(lat.max()),
            "p50_latency_cycles": float(np.percentile(lat, 50)), "p95_latency_cycles": float(np.percentile(lat, 95)),
            "p99_latency_cycles": float(np.percentile(lat, 99)),
            "per_master_accepted": list(self.accepted), "per_master_conflicts": list(self.conflicts),
            "bank_accesses": list(self.bank_accesses), "bank_conflicts": list(self.bank_conflicts),
            "bank_utilisation": [a / span if span else 0.0 for a in self.bank_accesses],
            "avg_rsp_fifo_occupancy": [s / span if span else 0.0 for s in self.fifo_occ_sum],
            "max_rsp_fifo_occupancy": list(self.fifo_occ_max),
            "backpressure_cycles": list(self.bp_cycles), "rtl_compatible": self.cfg.rtl_compatible,
        }


# =========================================================================== transaction-level array
@dataclass
class EngineWindow:
    start_cycle: int
    end_cycle: int
    fraction: float                 # share of bank cycles the engine owns (fixed priority over fabric)


class SramArray:
    """Banked SRAM for system-level simulation (transaction granularity, word-level bank reservation)."""

    def __init__(self, eng: EventEngine, clock: ClockDomain, *, name: str, capacity: int, banks: int,
                 width_bytes: int, read_latency: int = 1, write_latency: int = 1, ports: str = "1RW",
                 interleave: str = "low", queue_depth: int = 0, base_addr: int = 0,
                 trace: Trace | None = None, timeline_bucket_cycles: int = 64) -> None:
        if banks < 1 or width_bytes < 1 or capacity < width_bytes * banks:
            raise SramConfigError(f"{name}: invalid geometry")
        if read_latency < 1 or write_latency < 1:
            raise SramConfigError(f"{name}: latencies must be >= 1 cycle")
        if ports not in ("1RW", "1R1W", "2RW"):
            raise SramConfigError(f"{name}: ports must be 1RW, 1R1W or 2RW")
        if interleave == "high" and (capacity // width_bytes) % banks:
            raise SramConfigError(f"{name}: high interleave needs capacity divisible by banks")
        self.eng, self.clock, self.name = eng, clock, name
        self.capacity, self.banks, self.width = capacity, banks, width_bytes
        self.read_latency, self.write_latency = read_latency, write_latency
        self.ports, self.interleave, self.queue_depth = ports, interleave, queue_depth
        self.base = base_addr
        self.bank_depth = capacity // width_bytes // banks
        self.trace = trace or Trace(enabled=False)
        nport = 2 if ports != "1RW" else 1
        self.free = np.zeros((banks, nport), dtype=np.int64)     # next free cycle per bank port
        self.windows: list[EngineWindow] = []
        self.inflight = 0
        self.bucket = timeline_bucket_cycles
        self.bank_acc = np.zeros(banks, dtype=np.int64)
        self.bank_conf_cycles = np.zeros(banks, dtype=np.int64)
        self.timeline: dict[int, np.ndarray] = {}
        self.reads = self.writes = self.bytes = self.rejects = 0
        self.lat_cycles: list[int] = []
        self.first: int | None = None
        self.last = 0
        eng.register(self)

    def outstanding(self) -> int:
        return self.inflight

    def contains(self, addr: int, size: int) -> bool:
        return self.base <= addr and addr + size <= self.base + self.capacity

    def add_engine_window(self, start_cycle: int, end_cycle: int, fraction: float) -> None:
        if not 0 <= fraction <= 1 or end_cycle < start_cycle:
            raise ValueError("engine window: 0 <= fraction <= 1, end >= start")
        if fraction > 0 and end_cycle > start_cycle:
            self.windows.append(EngineWindow(start_cycle, end_cycle, fraction))

    def _fabric_cycle(self, c: int) -> int:
        """First cycle >= c not owned by an engine window (deterministic fractional sharing)."""
        for _ in range(64):
            moved = False
            for w in self.windows:
                if w.start_cycle <= c < w.end_cycle:
                    if w.fraction >= 1.0:
                        c = w.end_cycle
                        moved = True
                    else:
                        g = 1.0 - w.fraction        # fabric share: cycles where floor((c+1)g) > floor(cg)
                        rel = c - w.start_cycle
                        while math.floor((rel + 1) * g) == math.floor(rel * g) and c < w.end_cycle:
                            c += 1
                            rel += 1
                            moved = True
            if not moved:
                return c
        return c

    def access(self, txn: Transaction, on_done: Callable[[Transaction], None],
               port_bytes_per_cycle: int | None = None) -> bool:
        """Accept a read/write of ``txn.size`` bytes; False = queue full (caller must retry)."""
        if not self.contains(txn.addr, txn.size):
            raise ValueError(f"{self.name}: access 0x{txn.addr:x}+{txn.size} outside "
                             f"[0x{self.base:x}, 0x{self.base + self.capacity:x})")
        if self.queue_depth and self.inflight >= self.queue_depth:
            self.rejects += 1
            self.trace.log(self.eng.now, "BACKPRESSURE", self.name, txn)
            return False
        self.inflight += 1
        now_c = self.clock.edge_index_at_or_after(self.eng.now)
        txn.t_accepted = self.eng.now if txn.t_accepted is None else txn.t_accepted
        txn.path.append(self.name)
        self.trace.log(self.eng.now, "ACCEPT", self.name, txn, cycle=now_c)
        off = txn.addr - self.base
        first_word = off // self.width
        last_word = (off + txn.size - 1) // self.width
        nwords = last_word - first_word + 1
        wpc = max(1, (port_bytes_per_cycle or self.width) // self.width)
        is_w = txn.op == "W"
        pcol = 1 if (self.ports == "1R1W" and is_w) else 0
        t_last = now_c
        t_first = None
        for i in range(nwords):
            word = first_word + i
            b, _ = bank_map(word, self.banks, self.bank_depth, self.interleave)
            want = now_c + i // wpc
            if self.ports == "2RW":
                pcol = int(np.argmin(self.free[b]))
            t = max(want, int(self.free[b, pcol]))
            if self.windows:
                t = self._fabric_cycle(t)
            self.bank_conf_cycles[b] += t - want
            self.free[b, pcol] = t + 1
            self.bank_acc[b] += 1
            tb = self.timeline.setdefault(t // self.bucket, np.zeros(self.banks, dtype=np.int64))
            tb[b] += 1
            t_last = max(t_last, t)
            t_first = t if t_first is None else min(t_first, t)
        lat = self.write_latency if is_w else self.read_latency
        done_c = t_last + lat
        self.first = t_first if self.first is None else min(self.first, t_first)
        self.last = max(self.last, done_c)
        txn.t_service_start = self.clock.edge(t_first)
        self.trace.log(txn.t_service_start, "SERVICE_START", self.name, txn, cycle=t_first, words=nwords)
        if is_w:
            self.writes += 1
        else:
            self.reads += 1
        self.bytes += txn.size

        def done() -> None:
            self.inflight -= 1
            txn.t_service_end = self.eng.now
            self.lat_cycles.append(done_c - now_c)
            self.trace.log(self.eng.now, "SERVICE_END", self.name, txn, cycle=done_c)
            on_done(txn)
        self.eng.schedule_at(self.clock.edge(done_c), done, PRIO_COMPLETE, f"{self.name}.done")
        return True

    def stats(self, span_cycles: int | None = None) -> dict:
        span = span_cycles or max(1, self.last - (self.first or 0))
        lat = np.array(self.lat_cycles) if self.lat_cycles else np.array([0])
        acc = int(self.bank_acc.sum())
        return {
            "name": self.name, "reads": self.reads, "writes": self.writes, "bytes": self.bytes,
            "bank_accesses": self.bank_acc.tolist(), "bank_conflict_cycles": self.bank_conf_cycles.tolist(),
            "conflict_cycles_per_access": float(self.bank_conf_cycles.sum() / acc) if acc else 0.0,
            "bank_utilisation": (self.bank_acc / span).tolist(),
            "utilisation": float(acc / (span * self.banks * (2 if self.ports != "1RW" else 1))),
            "avg_service_latency_cycles": float(lat.mean()), "p95_service_latency_cycles": float(np.percentile(lat, 95)),
            "rejects": self.rejects,
        }

    def heatmap(self) -> tuple[np.ndarray, int]:
        """(banks x buckets) access counts and bucket size in cycles."""
        if not self.timeline:
            return np.zeros((self.banks, 1)), self.bucket
        keys = sorted(self.timeline)
        lo, hi = keys[0], keys[-1]
        mat = np.zeros((self.banks, hi - lo + 1), dtype=np.int64)
        for k, v in self.timeline.items():
            mat[:, k - lo] = v
        return mat, self.bucket
