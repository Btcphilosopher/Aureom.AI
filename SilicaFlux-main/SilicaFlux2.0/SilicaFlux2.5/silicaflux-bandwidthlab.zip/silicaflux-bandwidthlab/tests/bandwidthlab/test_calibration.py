"""RTL calibration (GATES 15, 16): crossbar equivalence, DMA fit/holdout, trace import."""
import shutil
from pathlib import Path

import pytest

from bandwidthlab import calibration as cal
from bandwidthlab.trace_import import read_trace, trace_metrics

ROOT = Path(__file__).resolve().parents[2]
REPO = cal.find_repo()
need_repo = pytest.mark.skipif(REPO is None, reason="SilicaFlux repository (SILICAFLUX_REPO) not available")


def test_model_side_xbar_is_deterministic_and_clean():
    stim = cal.xbar_stimulus(3, 2, 80, seed=4, kind="random")
    a = cal.run_model_xbar(stim, ns=2, lat=2, arb=1, bp=20, seed=3)
    b = cal.run_model_xbar(stim, ns=2, lat=2, arb=1, bp=20, seed=3)
    assert a["accepts"] == b["accepts"] and a["invariant_errors"] == []
    assert cal.compare_xbar(a, b)["equivalent"]


def test_compare_detects_a_one_cycle_difference():
    stim = cal.xbar_stimulus(2, 1, 20, seed=1, kind="hot")
    a = cal.run_model_xbar(stim, ns=1, lat=1, arb=1, bp=0, seed=1)
    b = {"accepts": [(c + (1 if i == 5 else 0), m, i) for c, m, i in a["accepts"]], "responses": a["responses"]}
    r = cal.compare_xbar(a, b)
    assert not r["equivalent"] and r["max_abs_accept_error"] == 1


@need_repo
@pytest.mark.skipif(shutil.which("verilator") is None, reason="verilator not installed")
def test_rtl_crossbar_cycle_exact(tmp_path):
    stim = cal.xbar_stimulus(3, 2, 60, seed=11, kind="random")
    rtl = cal.run_rtl_xbar(stim, ns=2, lat=2, arb=1, bp=15, seed=5, work=ROOT / "build" / "bandwidthlab",
                           sim="verilator", tag="pytest")
    mdl = cal.run_model_xbar(stim, ns=2, lat=2, arb=1, bp=15, seed=5)
    assert cal.compare_xbar(rtl, mdl)["equivalent"]


@need_repo
def test_dma_calibration_separates_fit_and_holdout():
    df = cal.locate_datafabric(ROOT / "build" / "bandwidthlab")
    res = cal.dma_calibration(df / "reports/datafabric/benchmark.md")
    sets = {r["set"] for r in res["rows"]}
    assert sets == {"calibration", "holdout"}
    assert len([r for r in res["rows"] if r["set"] == "calibration"]) == 2
    assert res["holdout_error"]["n"] >= 8
    assert "fitted_parameters" in res and res["fitted_on"] == sorted(cal.DMA_CALIBRATION_SET)


@need_repo
def test_import_recorded_datafabric_trace():
    df = cal.locate_datafabric(ROOT / "build" / "bandwidthlab")
    t = read_trace(df / "reports/datafabric/traces/tb_dma__simple_d32__contention.csv")
    m = trace_metrics(t)
    assert m["complete"] > 1000 and m["incomplete"] == 0
    assert m["accept_to_response"]["min"] >= 1


def test_import_harness_log(tmp_path):
    p = tmp_path / "log.txt"
    p.write_text("ACC 1 0 0\nRSP 2 0 -1 0 0000abcd\nACC 3 0 1\nRSP 4 0 -1 1 00000000\n")
    t = read_trace(p)
    assert list(t["response_cycle"]) == [2, 4] and list(t["error"]) == [0, 1]
