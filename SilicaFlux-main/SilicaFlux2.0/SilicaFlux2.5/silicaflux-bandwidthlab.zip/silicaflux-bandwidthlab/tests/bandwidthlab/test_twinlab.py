"""TwinLab standalone schema, exporter and example importer."""
from pathlib import Path

from bandwidthlab.cli import main
from bandwidthlab.twinlab import TwinLabExport, export_twinlab, load_export, to_twinlab_architecture

ROOT = Path(__file__).resolve().parents[2]


def test_export_and_import_round_trip(tmp_path):
    rc = main(["simulate", "--config", str(ROOT / "configs" / "silicaflux_v.yaml"), "--workload", "tile_pipeline",
               "--M", "8", "--N", "8", "--K", "16", "--out", str(tmp_path / "run_001")])
    assert rc == 0
    p = export_twinlab(tmp_path)
    exp = load_export(p)
    assert isinstance(exp, TwinLabExport) and exp.schema_version == "1.0.0"
    assert sum(l.transactions for l in exp.links) > 0 and exp.telemetry
    assert "no physical geometry" in exp.placement_source
    arch = to_twinlab_architecture(exp)
    assert arch["memory"]["memoryBusWidthBits"] == 32
    assert (tmp_path / "twinlab" / "bandwidthlab_twinlab.schema.json").exists()
