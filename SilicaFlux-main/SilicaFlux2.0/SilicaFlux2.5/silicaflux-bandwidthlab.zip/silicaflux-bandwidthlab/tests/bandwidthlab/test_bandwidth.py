"""Bandwidth accounting (GATE 9) and throughput capacity limits."""
import pytest

from bandwidthlab.bandwidth import bandwidth_report
from bandwidthlab.bus import FabricConfig
from bandwidthlab.dma import Descriptor, DmaConfig
from bandwidthlab.masters import MemOp
from bandwidthlab.simulation import System
from bandwidthlab.sram import SramConfig
from bandwidthlab.transaction import TxnKind
from bandwidthlab.units import GBps, GiBps, peak_link_bandwidth_Bps


def test_peak_link_formula_and_units():
    b = peak_link_bandwidth_Bps(32, 50e6)
    assert b == 200e6
    assert b / GBps == pytest.approx(0.2) and b / GiBps == pytest.approx(0.186264514923)
    with pytest.raises(ValueError):
        peak_link_bandwidth_Bps(12, 1e6)


def test_sustained_never_exceeds_capacity():
    s = System("b", fabric_hz=100e6)
    m = s.add_sram(SramConfig(name="m", base_addr=0x1000_0000, capacity_bytes=8192, banks=1))
    s.add_interconnect(FabricConfig())
    s.map_target(m)
    for i in range(4):
        s.add_master(f"m{i}", [MemOp(TxnKind.READ, 0x1000_0000 + 4 * j, 4) for j in range(200)])
    s.run()
    r = s.results()
    assert r["bandwidth"]["completed"]["bytes_per_cycle"] <= 4.0 + 1e-9     # 1 word/cycle on one slave port
    assert r["bandwidth"]["completed"]["bytes_per_cycle"] > 3.9
    for v in r["bandwidth"]["utilisation"].values():
        assert v <= 1.0


def test_copy_counts_useful_bytes_once():
    s = System("c", fabric_hz=100e6)
    a = s.add_sram(SramConfig(name="a", base_addr=0x1000_0000, capacity_bytes=8192, banks=1))
    b = s.add_sram(SramConfig(name="b", base_addr=0x1000_2000, capacity_bytes=8192, banks=1))
    s.add_interconnect(FabricConfig())
    s.map_target(a)
    s.map_target(b)
    d = s.add_dma(DmaConfig(engine="buffered"))
    d.submit(Descriptor.copy(0x1000_0000, 0x1000_2000, 1024))
    s.run()
    r = s.results()["bandwidth"]
    assert r["useful_payload"]["bytes"] == 1024             # not 2048
    assert r["completed"]["bytes"] == 2048                  # physical reads + writes
    assert r["read"]["bytes"] == 1024 and r["write"]["bytes"] == 1024


def test_report_fields():
    rep = bandwidth_report(generated=[], clock_hz=1e8, window_cycles=100, link_width_bits=64)
    assert rep["theoretical_link"]["category"] == "ANALYTICAL_CEILING"
    assert rep["theoretical_link"]["GBps"] == pytest.approx(0.8)
