"""Transaction schema and conservation ledger (GATE 3)."""
import pytest

from memorylab.event_engine import Transaction

from bandwidthlab.transaction import (ConservationError, InvalidOrderingError, MemTransaction, TransactionLedger,
                                      TxnKind, TxnState)


def t(tid=1, kind=TxnKind.READ, **kw):
    return MemTransaction.new(tid, "m", kind, 0x100, 4, 0, **kw)


def test_extends_memorylab_transaction():
    x = t()
    assert isinstance(x, Transaction) and x.op == "R"
    assert t(kind=TxnKind.DMA_WRITE).op == "W" and t(kind=TxnKind.PREFETCH).op == "R"
    assert t(byte_enable=0b0011).byte_enable == 0b0011


def test_lifecycle_order_enforced():
    x = t()
    x.advance(TxnState.ISSUED, 10)
    x.mark_accepted(10)
    x.advance(TxnState.SERVICE_STARTED, 20)
    with pytest.raises(InvalidOrderingError):
        x.advance(TxnState.GRANTED, 30)                 # going back to an earlier stage
    with pytest.raises(InvalidOrderingError):
        x.advance(TxnState.SERVICE_DONE, 15)            # time going backwards
    with pytest.raises(InvalidOrderingError):
        x.mark_accepted(20)                             # accepted twice
    x.advance(TxnState.SERVICE_DONE, 30)
    x.advance(TxnState.COMPLETED, 30)
    with pytest.raises(InvalidOrderingError):
        x.advance(TxnState.COMPLETED, 40)               # duplicate completion


def test_acceptance_before_issue_rejected():
    x = t()
    with pytest.raises(InvalidOrderingError):
        x.mark_accepted(5)


def test_ledger_detects_duplicates_lost_and_dependency_violations():
    led = TransactionLedger()
    a, b = t(1), t(2, deps=(1,))
    led.on_generated(a)
    led.on_generated(b)
    with pytest.raises(ConservationError):
        led.on_generated(t(1))                          # duplicate id
    a.t_accepted = 0
    led.on_accepted(a)
    b.t_accepted = 0
    led.on_accepted(b)
    with pytest.raises(ConservationError):
        led.on_completed(b, 5)                          # before its dependency
    led2 = TransactionLedger()
    c = t(3)
    led2.on_generated(c)
    c.t_accepted = 0
    led2.on_accepted(c)
    assert any("lost" in e for e in led2.final_check())
    led2.on_completed(c, 3)
    assert led2.final_check() == []
    with pytest.raises(ConservationError):
        led2.on_completed(c, 4)                         # duplicate completion


def test_conservation_identity():
    led = TransactionLedger()
    xs = [t(i) for i in range(10)]
    for x in xs:
        led.on_generated(x)
        x.t_accepted = 0
        led.on_accepted(x)
    for x in xs[:6]:
        led.on_completed(x, 1)
    led.on_cancelled(xs[6])
    s = led.summary()
    assert s["accepted"] == s["completed"] + s["outstanding"] + 1
    assert led.check() == []
