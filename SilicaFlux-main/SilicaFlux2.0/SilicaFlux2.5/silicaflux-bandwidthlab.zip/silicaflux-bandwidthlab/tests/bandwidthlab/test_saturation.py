"""Saturation behaviour (GATE 12): plateau, bounded latency with backpressure, instability."""
from pathlib import Path

from bandwidthlab import scenarios as sc
from bandwidthlab.config import load_config
from bandwidthlab.saturation import classify_regions, offered_load_sweep

CFG = Path(__file__).resolve().parents[2] / "configs" / "silicaflux_v.yaml"


def _sweep(adm, rates=(0.05, 0.2, 0.3, 0.5, 0.8)):
    cfg = load_config(CFG)
    return offered_load_sweep(lambda: sc.build(cfg, record_events=False), list(rates), n_masters=3, cycles=1500,
                              target="sram", admission=adm, queue_depth=6, seed=2, region_bytes=4096)


def test_queue_saturation_plateau_and_bounded_latency_with_backpressure():
    pts = _sweep("backpressure")
    assert max(p.completed_per_cycle for p in pts) <= 1.0 + 1e-9          # one single-port slave
    assert pts[-1].completed_per_cycle > 0.95
    assert pts[-1].lat_max < 40                                           # finite queue -> bounded
    assert pts[0].lat_mean < 1.5
    reg = classify_regions(pts)
    assert reg["onset_of_queueing_rate"] is not None and not reg["unbounded_growth_rates"]


def test_unbounded_admission_shows_unstable_growth():
    pts = _sweep("unbounded")
    reg = classify_regions(pts)
    assert 0.5 in reg["unbounded_growth_rates"] and pts[-1].lat_mean > 10 * pts[0].lat_mean


def test_drop_policy_rejects_under_overload():
    pts = _sweep("drop")
    assert pts[-1].dropped > 0 and pts[0].dropped == 0
