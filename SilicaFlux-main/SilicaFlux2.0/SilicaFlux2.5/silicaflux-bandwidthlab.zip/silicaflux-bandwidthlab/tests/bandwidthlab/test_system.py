"""Whole-system properties: mixed traffic, conservation, determinism, termination."""
from pathlib import Path

from hypothesis import given, settings, strategies as st

from bandwidthlab import scenarios as sc
from bandwidthlab.bus import FabricConfig
from bandwidthlab.config import load_config
from bandwidthlab.latency import littles_law_ledger
from bandwidthlab.masters import MemOp
from bandwidthlab.simulation import System
from bandwidthlab.sram import SramConfig
from bandwidthlab.transaction import TxnKind
from bandwidthlab.workloads import program

CFG = Path(__file__).resolve().parents[2] / "configs"


def test_mixed_cpu_tensor_dma_traffic_tile_pipeline():
    cfg = load_config(CFG / "silicaflux_v.yaml", {"dma.engine": "buffered"})
    b = sc.build(cfg)
    info = sc.tile_pipeline(b, M=8, N=8, K=16, cpu_background={"pattern": "random", "n": 300, "offset": 0x20000})
    b.system.run()
    r = b.system.results()
    assert r["invariant_errors"] == [] and r["errors"] == 0
    assert r["masters"]["te"]["useful_ops"] == info["useful_macs"] == 8 * 8 * 16
    assert all(not d["failed"] for d in r["dmas"]["dma"]["descriptors"])
    assert r["littles_law"]["relative_gap"] < 1e-9
    # every required event type that this workload exercises was produced by the simulator
    for et in ("REQUEST_GENERATED", "REQUEST_ACCEPTED", "ARBITRATION_GRANTED", "MEMORY_SERVICE_STARTED",
               "MEMORY_SERVICE_COMPLETED", "RESPONSE_GENERATED", "RESPONSE_ACCEPTED", "DMA_BURST_STARTED",
               "DMA_BURST_COMPLETED", "COMPUTE_STARTED", "COMPUTE_COMPLETED", "STALL_STARTED", "STALL_ENDED"):
        assert r["event_counts"].get(et, 0) > 0, et


def _run(seed):
    s = System("r", fabric_hz=100e6)
    m = s.add_sram(SramConfig(name="m", base_addr=0x1000_0000, capacity_bytes=8192, banks=4, n_ports=1))
    s.add_interconnect(FabricConfig())
    s.map_target(m)
    for i in range(3):
        s.add_master(f"m{i}", program("random", n=150, base=0x1000_0000, region_bytes=8192, seed=seed + i))
    s.run()
    return [(t.tid, t.t_accepted, t.t_completed, t.data) for t in s.ledger.generated.values()], s


def test_deterministic_for_equal_seeds_and_different_for_different_seeds():
    a, _ = _run(5)
    b, _ = _run(5)
    c, _ = _run(6)
    assert a == b and a != c


@settings(max_examples=25)
@given(st.integers(1, 4), st.integers(1, 3), st.sampled_from(["rr", "fixed", "age"]), st.integers(0, 2),
       st.integers(1, 1000))
def test_conservation_and_capacity_property(n_masters, lat, arb, qd, seed):
    s = System("p", fabric_hz=100e6)
    m = s.add_sram(SramConfig(name="m", base_addr=0x1000_0000, capacity_bytes=8192, banks=2, read_latency=lat))
    s.add_interconnect(FabricConfig(arbitration=arb, input_queue_depth=qd))
    s.map_target(m)
    for i in range(n_masters):
        s.add_master(f"m{i}", program("random", n=60, base=0x1000_0000, region_bytes=8192, seed=seed + i))
    s.run()
    led = s.ledger.summary()
    assert led["accepted"] == led["completed"] + led["outstanding"] + led["cancelled"]
    assert led["outstanding"] == 0
    assert s.check_invariants() == []
    r = s.results()
    assert r["bandwidth"]["completed"]["bytes_per_cycle"] <= 4.0 + 1e-9      # one slave port, 32 bit
    assert littles_law_ledger(s.ledger, [t for t in s.ledger.generated.values()])["relative_gap"] < 1e-9


def test_64bit_fabric_accepts_naturally_aligned_32bit_access():
    """Regression: a 32-bit access at word offset 4 of a 64-bit bank is legal (byte strobes)."""
    cfg = load_config(CFG / "silicaflux_v.yaml", {"fabric.data_width_bits": 64})
    b = sc.build(cfg)
    m = b.system.add_master("cpu", [MemOp(TxnKind.WRITE, 0x1000_0004, 4, data=0xA5A5A5A5),
                                    MemOp(TxnKind.READ, 0x1000_0004, 4, deps=(0,))], links={"default": b.link("x")})
    b.system.run()
    assert [t.status.value for t in m.completed_txns] == ["OK", "OK"] and m.completed_txns[1].data == 0xA5A5A5A5


def test_simulation_terminates_with_bounded_limits():
    s = System("x", fabric_hz=100e6, max_cycles=50)
    m = s.add_sram(SramConfig(name="m", base_addr=0x1000_0000, capacity_bytes=8192, banks=1))
    s.add_interconnect(FabricConfig())
    s.map_target(m)
    s.add_master("cpu", program("seq_read", n=500, base=0x1000_0000, region_bytes=4096))
    import pytest
    from bandwidthlab.scheduler import LimitExceeded
    with pytest.raises(LimitExceeded):
        s.run()


def test_cpu_staging_baseline_is_slower_than_dma():
    cfg = load_config(CFG / "silicaflux_v.yaml")
    res = {}
    for staging in ("cpu", "dma"):
        b = sc.build(cfg, record_events=False)
        sc.tile_pipeline(b, M=8, N=8, K=16, staging=staging)
        b.system.run()
        r = b.system.results()
        assert r["invariant_errors"] == [] and r["masters"]["te"]["useful_ops"] == 8 * 8 * 16
        res[staging] = r["run"]["end_cycle"]
    assert res["cpu"] > res["dma"]
