"""Simplified external-memory controller: row buffer, scheduling, CDC, data."""
from bandwidthlab.bus import FabricConfig
from bandwidthlab.dram import DramConfig
from bandwidthlab.masters import MemOp
from bandwidthlab.simulation import System
from bandwidthlab.transaction import TxnKind

T = dict(tRCD=4, tRP=4, tCL=6, tCWL=4, tWTR=3, tRTW=2)


def dram_sys(**kw):
    s = System("d", fabric_hz=100e6)
    s.add_clock("dram", 200e6)
    d = s.add_dram(DramConfig(clock="dram", base_addr=0x8000_0000, capacity_bytes=1 << 24, **{**T, **kw}))
    s.add_interconnect(FabricConfig(max_outstanding_per_master=4, max_outstanding_per_target=4))
    s.map_target(d)
    return s, d


def test_row_hits_faster_than_conflicts_and_data_round_trip():
    s, d = dram_sys()
    ops = [MemOp(TxnKind.WRITE, 0x8000_0000, 4, data=0x12345678),
           MemOp(TxnKind.READ, 0x8000_0000, 4, deps=(0,))]
    ops += [MemOp(TxnKind.READ, 0x8000_0000 + 32 * i, 4) for i in range(20)]       # same row: hits
    m = s.add_master("cpu", ops, max_outstanding=4)
    s.run()
    assert m.completed_txns[1].data == 0x12345678
    st = d.stats()["channels"][0]
    assert st["row_hits"] > st["row_misses"]
    assert s.check_invariants() == []


def test_row_conflicts_cost_more():
    def run(stride):
        s, d = dram_sys()
        m = s.add_master("cpu", [MemOp(TxnKind.READ, 0x8000_0000 + stride * i, 4) for i in range(40)])
        s.run()
        return m.finish_cycle, d.stats()["channels"][0]
    near, st_n = run(32)
    far, st_f = run(2048 * 8)            # same bank, different rows
    assert st_f["row_conflicts"] > 0 and far > near


def test_clock_domain_crossing_adds_sync_latency():
    s, d = dram_sys(sync_stages=2)
    m = s.add_master("cpu", [MemOp(TxnKind.READ, 0x8000_0000, 4)])
    s.run()
    t = m.completed_txns[0]
    lat_ns = (t.t_completed - t.t_issued) / 1e6
    # >= ACT + CL + burst at 5 ns plus two synchronisers (2 x 5 ns + 2 x 10 ns)
    assert lat_ns >= (4 + 6 + 8) * 5 + 2 * 5 + 2 * 10 - 10
