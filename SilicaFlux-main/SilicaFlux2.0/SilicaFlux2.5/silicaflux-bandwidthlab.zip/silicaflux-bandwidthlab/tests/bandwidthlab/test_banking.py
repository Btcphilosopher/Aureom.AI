"""Address-to-bank mappings: bijectivity for power-of-two and other bank counts."""
import pytest
from hypothesis import given, strategies as st

from bandwidthlab.banking import BankMapError, BankMapper


@given(st.integers(1, 17), st.integers(1, 64), st.sampled_from(["low", "high", "modulo", "skew", "xor"]))
def test_mapping_is_bijective(banks, depth, mapping):
    if mapping == "xor" and banks & (banks - 1):
        with pytest.raises(BankMapError):
            BankMapper(banks, depth, mapping)
        return
    m = BankMapper(banks, depth, mapping)
    seen = set()
    for w in range(banks * depth):
        b, r = m.map(w)
        assert 0 <= b < banks and 0 <= r < depth
        assert m.unmap(b, r) == w
        seen.add((b, r))
    assert len(seen) == banks * depth


def test_low_interleave_and_high_order():
    lo = BankMapper(4, 8, "low")
    assert [lo.bank(w) for w in range(6)] == [0, 1, 2, 3, 0, 1]
    hi = BankMapper(4, 8, "high")
    assert [hi.bank(w) for w in (0, 7, 8, 31)] == [0, 0, 1, 3]


def test_xor_and_skew_break_power_of_two_strides():
    for mapping in ("xor", "skew"):
        m = BankMapper(4, 64, mapping)
        banks = {m.bank(4 * i) for i in range(16)}      # stride = bank count
        assert len(banks) == 4
    assert {BankMapper(4, 64, "low").bank(4 * i) for i in range(16)} == {0}


def test_non_power_of_two_needs_divider_flag():
    assert BankMapper(3, 16, "modulo").needs_divider
    assert not BankMapper(4, 16, "low").needs_divider
    with pytest.raises(BankMapError):
        BankMapper(4, 16).map(64)
