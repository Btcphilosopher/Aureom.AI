"""LEVEL 1 analytical ceilings agree with the simulator where both apply."""
from pathlib import Path

import pytest

from bandwidthlab.analytical import dma_ceiling, roofline, sfb_port_txn_rate, system_ceilings, tensor_ceiling
from bandwidthlab.config import load_config

CFG = Path(__file__).resolve().parents[2] / "configs"


def test_dma_ceiling_formulas_match_rtl_benchmark_slopes():
    # DataFabric benchmark (4096 B, 1-cycle slaves): simple 4 cyc/beat; buffered B=8 -> 2.5 cyc/beat
    assert 4 / dma_ceiling("simple", 4) == pytest.approx(4.0)
    assert 4 / dma_ceiling("buffered", 4, burst=8) == pytest.approx(2.5)
    assert 4 / dma_ceiling("buffered", 4, burst=1) == pytest.approx(6.0)
    assert dma_ceiling("buffered", 4, dual_port=True) == 4


def test_port_rates_and_roofline():
    assert sfb_port_txn_rate(1, False) == 1 and sfb_port_txn_rate(1, True) == 0.5
    r = roofline(100.0, 2.0, 10.0)
    assert r["attainable_ops_per_s"] == 20.0 and r["bound"] == "bandwidth"


def test_tensor_ceiling_rtl_4x4_is_8_macs_per_cycle():
    te = tensor_ceiling(4, 4, "int8", port_bytes_per_cycle=16, accesses_per_kstep=2)
    assert te["macs_per_cycle"] == 8 and te["peak_macs_per_cycle"] == 16


def test_system_ceilings_all_labelled():
    c = system_ceilings(load_config(CFG / "silicaflux_v.yaml"))
    assert c["category"] == "ANALYTICAL_CEILING" and c["link"]["GBps"] == pytest.approx(0.2)
