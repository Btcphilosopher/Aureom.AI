"""SRAM bank model (GATE 5): port constraints, conflicts, latency, and equivalence with the
RTL-validated MemoryLab BankController (memorylab.sram, validated against sramlib RTL)."""
import pytest
from hypothesis import given, strategies as st

from memorylab import bankbench
from memorylab.sram import BankCtrlConfig

from bandwidthlab.banking import BankMapping
from bandwidthlab.sram import PortType, SramConfig, SramConfigError
from bandwidthlab.transaction import TransactionLedger
from helpers import run_stim


def _cfg_pair(nm, nb, lat, interleave, depth=256):
    ref = BankCtrlConfig(num_masters=nm, num_banks=nb, data_width=32, bank_depth=depth, read_latency=lat,
                         interleave=interleave)
    mine = SramConfig(capacity_bytes=nm and nb * depth * 4, banks=nb, data_width=32, read_latency=lat,
                      n_ports=nm, mapping=BankMapping.LOW if interleave == "low" else BankMapping.HIGH)
    return ref, mine


@pytest.mark.parametrize("workload", ["random", "cpu", "vector", "tensor", "dma", "mixed", "stride"])
@pytest.mark.parametrize("nm,nb,lat,inter,bp", [(4, 4, 1, "low", 0), (2, 8, 2, "low", 30), (4, 2, 3, "high", 20),
                                                 (3, 4, 1, "high", 0), (4, 1, 2, "low", 10)])
def test_equivalent_to_rtl_validated_bank_controller(workload, nm, nb, lat, inter, bp):
    ref_cfg, cfg = _cfg_pair(nm, nb, lat, inter)
    stim = bankbench.generate(workload, ref_cfg, 120, seed=7, err_pct=3)
    ref = bankbench.run(ref_cfg, stim, bp_pct=bp, seed=11)
    led = TransactionLedger()
    got = run_stim(cfg, stim, bp=lambda m, c: bankbench.backpressure_ready(11, bp, m, c), ledger=led)
    assert got["accepts"] == ref["accepts"]
    assert got["conflicts"] == ref["conflicts"]
    ref_rsp = [(c, m, rid, d, e, w) for c, m, rid, d, e, w in ref["responses"]]
    assert [r[:3] + r[4:] for r in got["responses"]] == [r[:3] + r[4:] for r in ref_rsp]
    # read data equal (both models start from all-zero memory)
    assert [r[3] for r in got["responses"]] == [r[3] for r in ref_rsp]
    assert led.final_check() == []


def _two_port(cfg_kw, reqs0, reqs1):
    cfg = SramConfig(**cfg_kw)
    return run_stim(cfg, [reqs0, reqs1])


R = bankbench.Req


def test_single_request_read_latency():
    cfg = SramConfig(capacity_bytes=1024, banks=1, read_latency=2)
    res = run_stim(cfg, [[R(0, 0, 3, 0, 0xF, 1)]])
    assert res["accepts"] == [(0, 0, 1)]
    assert res["responses"][0][0] == 2          # READ_LATENCY cycles after acceptance


def test_same_bank_conflict_serialises_single_port():
    # both ports hit bank 0 every cycle: one access per cycle in total
    kw = dict(capacity_bytes=4096, banks=4, n_ports=2, mapping="low")
    a = [R(0, 0, 4 * i, 0, 0xF, i) for i in range(20)]
    b = [R(0, 0, 4 * i + 64, 0, 0xF, 100 + i) for i in range(20)]
    res = _two_port(kw, a, b)
    last = max(c for c, _, _ in res["accepts"])
    assert last >= 39                           # 40 accesses through one single-port bank
    assert res["sram"].stats()["conflicts"] >= 19
    for st_ in res["sram"].bank[1:]:
        assert st_.reads == 0


def test_independent_banks_run_in_parallel():
    kw = dict(capacity_bytes=4096, banks=4, n_ports=2, mapping="low")
    a = [R(0, 0, 4 * i, 0, 0xF, i) for i in range(20)]           # bank 0
    b = [R(0, 0, 4 * i + 1, 0, 0xF, 100 + i) for i in range(20)]  # bank 1
    res = _two_port(kw, a, b)
    assert max(c for c, _, _ in res["accepts"]) == 19            # 2 words/cycle, no conflict
    assert res["sram"].stats()["conflicts"] == 0


def test_one_read_one_write_port_allows_concurrent_read_and_write():
    kw = dict(capacity_bytes=4096, banks=1, n_ports=2, port_type="1R1W")
    rd = [R(0, 0, i, 0, 0xF, i) for i in range(16)]
    wr = [R(0, 1, 100 + i, i, 0xF, 50 + i) for i in range(16)]
    res = _two_port(kw, rd, wr)
    assert max(c for c, _, _ in res["accepts"]) == 15
    # same configuration but single-port: twice as long
    kw1 = dict(kw, port_type="1RW")
    res1 = _two_port(kw1, rd, wr)
    assert max(c for c, _, _ in res1["accepts"]) == 31


def test_1r1w_same_address_collision_stalls_with_alternating_priority():
    kw = dict(capacity_bytes=1024, banks=1, n_ports=2, port_type="1R1W")
    rd = [R(0, 0, 5, 0, 0xF, 1), R(0, 0, 5, 0, 0xF, 2)]
    wr = [R(0, 1, 5, 0xAB, 0xF, 3), R(0, 1, 5, 0xCD, 0xF, 4)]
    res = _two_port(kw, rd, wr)
    st_ = res["sram"].stats()
    assert st_["collisions"] >= 2
    assert max(c for c, _, _ in res["accepts"]) == 3   # 4 accesses, at most 1 per cycle on the colliding row


def test_true_dual_port_two_accesses_per_cycle_and_write_collision():
    kw = dict(capacity_bytes=4096, banks=1, n_ports=2, port_type="2RW")
    a = [R(0, 0, i, 0, 0xF, i) for i in range(10)]
    b = [R(0, 0, 200 + i, 0, 0xF, 50 + i) for i in range(10)]
    assert max(c for c, _, _ in _two_port(kw, a, b)["accepts"]) == 9
    w1 = [R(0, 1, 7, 1, 0xF, 1)]
    w2 = [R(0, 1, 7, 2, 0xF, 2)]
    res = _two_port(kw, w1, w2)
    assert res["sram"].stats()["collisions"] == 1
    assert res["sram"].mem[7] == 2            # sequential semantics: the later write wins


@given(st.integers(1, 6), st.integers(1, 9), st.sampled_from(["1RW", "1R1W", "2RW"]), st.integers(0, 2),
       st.integers(0, 10_000))
def test_port_capacity_never_exceeded(nports, banks, ptype, qd, seed):
    cfg = SramConfig(capacity_bytes=banks * 64 * 4, banks=banks, n_ports=nports, port_type=ptype,
                     mapping="modulo", queue_depth=qd)
    ref = BankCtrlConfig(num_masters=1, num_banks=1, data_width=32, bank_depth=banks * 64)
    stim = [bankbench.generate("random", ref, 40, seed=seed + p)[0] for p in range(nports)]
    led = TransactionLedger()
    res = run_stim(cfg, stim, ledger=led)
    sram = res["sram"]
    per_cycle = {}
    for c, ev, p, tid, b in sram.log:
        if ev == "ACC" and b >= 0 and qd == 0:
            per_cycle[(c, b)] = per_cycle.get((c, b), 0) + 1
    cap = 1 if ptype == "1RW" else 2
    assert all(v <= cap for v in per_cycle.values())
    for bs in sram.bank:
        assert bs.reads + bs.writes <= bs.busy_cycles * cap
    assert led.final_check() == []
    assert sum(len(s) for s in stim) == len(res["accepts"])


def test_non_power_of_two_banks_supported():
    cfg = SramConfig(capacity_bytes=3 * 128 * 4, banks=3, n_ports=1, mapping="modulo")
    res = run_stim(cfg, [[R(0, 0, i, 0, 0xF, i) for i in range(30)]])
    sram = res["sram"]
    assert [b.reads for b in sram.bank] == [10, 10, 10]
    with pytest.raises(Exception):
        SramConfig(capacity_bytes=3 * 128 * 4, banks=3, mapping="xor")


def test_illegal_address_gets_error_response():
    cfg = SramConfig(capacity_bytes=1024, banks=2)
    res = run_stim(cfg, [[R(0, 0, 10_000, 0, 0xF, 1), R(0, 0, 3, 0, 0xF, 2)]])
    assert [r[4] for r in res["responses"]] == [1, 0]


def test_variable_memory_latency():
    for lat in (1, 2, 4, 7):
        cfg = SramConfig(capacity_bytes=1024, banks=1, read_latency=lat)
        res = run_stim(cfg, [[R(0, 0, i, 0, 0xF, i) for i in range(10)]])
        assert all(r[0] - a[0] == lat for r, a in zip(res["responses"], res["accepts"]))
        # with default credits (lat + 1) the port sustains one access per cycle
        assert res["accepts"][-1][0] == 9


def test_response_credits_backpressure_requests():
    cfg = SramConfig(capacity_bytes=1024, banks=1, read_latency=1, rsp_fifo_depth=2)
    never = lambda p, c: c >= 20   # consumer refuses responses for 20 cycles
    res = run_stim(cfg, [[R(0, 0, i, 0, 0xF, i) for i in range(6)]], bp=never)
    acc = [a[0] for a in res["accepts"]]
    assert acc[:2] == [0, 1] and acc[2] >= 20     # only 2 credits -> third request waits


def test_queue_mode_accepts_ahead_of_bank_service():
    cfg = SramConfig(capacity_bytes=4096, banks=1, n_ports=2, queue_depth=4)
    a = [R(0, 0, i, 0, 0xF, i) for i in range(8)]
    b = [R(0, 0, 100 + i, 0, 0xF, 50 + i) for i in range(8)]
    res = run_stim(cfg, [a, b])
    assert res["sram"].stats()["words"] == 16


def test_config_validation():
    with pytest.raises(SramConfigError):
        SramConfig(capacity_bytes=1000, banks=3, data_width=32)
    with pytest.raises(SramConfigError):
        SramConfig(read_latency=0)
    with pytest.raises(SramConfigError):
        SramConfig(data_width=12)
