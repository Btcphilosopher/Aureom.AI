"""Configuration validation (GATE 1) and provenance."""
from pathlib import Path

import pytest

from bandwidthlab.config import ConfigError, apply_overrides, load_config, provenance_table, read_yaml

CFG = Path(__file__).resolve().parents[2] / "configs"


@pytest.mark.parametrize("name", ["silicaflux_v", "silicaflux_v_datafabric_rtl", "silicaflux_mcu_i", "silicaflux_full"])
def test_shipped_configs_validate(name):
    c = load_config(CFG / f"{name}.yaml")
    assert c.name == name


def test_extends_and_overrides():
    c = load_config(CFG / "silicaflux_v.yaml", {"memories.sram.banks": 8, "fabric.data_width_bits": 64})
    assert c.memory("sram").banks == 8 and c.memory("sram").capacity == 256 * 1024
    assert c.memory("rom").capacity == 4096                         # inherited from the as-built file
    with pytest.raises(ConfigError):
        apply_overrides(read_yaml(CFG / "silicaflux_v.yaml"), {"memories.nosuch.banks": 2})


@pytest.mark.parametrize("over,msg", [
    ({"memories.sram.capacity": "100KiB", "memories.sram.banks": 3}, "divisible"),
    ({"memories.sram.mapping": "xor", "memories.sram.banks": 3, "memories.sram.capacity": "192KiB"}, "power-of-two"),
    ({"tensor.precision": "fp16"}, "fp_supported"),
    ({"dma.engine": "buffered", "dma.fifo_depth": 2, "dma.burst": 8}, "burst"),
    ({"fabric.clock": "nosuch"}, "clock"),
    ({"memories.tspm.base": 0x1000_0000}, "overlap"),
    ({"fabric.unknown_key": 1}, "Extra inputs"),
])
def test_invalid_configs_rejected(over, msg):
    with pytest.raises(ConfigError, match=msg):
        load_config(CFG / "silicaflux_v.yaml", over)


def test_provenance_table_marks_unlisted_as_hypothetical():
    rows = provenance_table(load_config(CFG / "silicaflux_v_datafabric_rtl.yaml"))
    d = {r["parameter"]: r for r in rows}
    assert d["fabric.data_width_bits"]["provenance"] == "VERIFIED_REPO"
    assert d["memories.periph.read_latency"]["provenance"] == "HYPOTHETICAL"
    assert d["sim.seed"]["provenance"] == "HYPOTHETICAL"
