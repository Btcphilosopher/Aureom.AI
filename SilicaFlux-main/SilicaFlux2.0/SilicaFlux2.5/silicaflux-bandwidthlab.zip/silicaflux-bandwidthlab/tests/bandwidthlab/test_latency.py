"""Latency accounting (GATE 10): exact decomposition, statistics, Little's law."""
import numpy as np
from hypothesis import given, strategies as st

from bandwidthlab.bus import FabricConfig
from bandwidthlab.latency import COMPONENTS, bootstrap_ci, decompose, littles_law_ledger, summarise
from bandwidthlab.masters import MemOp
from bandwidthlab.simulation import System
from bandwidthlab.sram import SramConfig
from bandwidthlab.transaction import MemTransaction, TxnKind, TxnState
from bandwidthlab.workloads import program


def contended(n=300, q=0, slices=0, seed=1):
    s = System("l", fabric_hz=100e6)
    m = s.add_sram(SramConfig(name="m", base_addr=0x1000_0000, capacity_bytes=16384, banks=1, read_latency=2,
                              rsp_fifo_depth=4))
    s.add_interconnect(FabricConfig(input_queue_depth=q, req_slices=slices, rsp_slices=slices))
    s.map_target(m)
    for i in range(3):
        s.add_master(f"m{i}", program("random", n=n, base=0x1000_0000, region_bytes=4096, seed=seed + i))
    s.run()
    return s


def test_components_sum_exactly_to_total():
    for q, sl in ((0, 0), (2, 0), (0, 1), (3, 2)):
        s = contended(q=q, slices=sl)
        for t in s.ledger.generated.values():
            d = decompose(t)
            assert sum(d[c] for c in COMPONENTS) == d["total"]
            assert all(d[c] >= 0 for c in COMPONENTS)


def test_decomposition_of_known_timeline():
    t = MemTransaction.new(1, "m", TxnKind.READ, 0, 4, 0)
    t.advance(TxnState.ISSUED, 10)
    t.advance(TxnState.GRANTED, 30)
    t.advance(TxnState.AT_TARGET, 30)
    t.mark_accepted(50)
    t.advance(TxnState.SERVICE_STARTED, 50)
    t.advance(TxnState.SERVICE_DONE, 70)
    t.advance(TxnState.RESPONSE, 80)
    t.advance(TxnState.COMPLETED, 80)
    d = decompose(t)
    assert d == {"generation": 10, "admission": 0, "queue_wait": 0, "arbitration": 20, "interconnect": 0,
                 "target_wait": 20, "memory_service": 20, "response_queue": 10, "response_xfer": 0, "total": 80}


def test_summary_statistics_and_small_sample_warning():
    s = summarise([1, 2, 3, 4, 100])
    assert s.n == 5 and s.min == 1 and s.max == 100 and s.p50 == 3
    assert any("P99 unstable" in w for w in s.warnings)
    big = summarise(np.arange(2000))
    assert not any("P99" in w for w in big.warnings)
    lo, hi = bootstrap_ci(np.arange(1000.0), 99)
    assert lo <= np.percentile(np.arange(1000.0), 99) <= hi


def test_littles_law_holds_exactly_for_a_run_that_starts_and_ends_empty():
    s = contended(n=400)
    done = [t for t in s.ledger.generated.values() if t.t_completed is not None]
    ll = littles_law_ledger(s.ledger, done)
    assert ll["ends_empty"] and ll["relative_gap"] < 1e-9


@given(st.integers(1, 5))
def test_no_negative_latency_any_seed(seed):
    s = contended(n=60, seed=seed)
    assert s.check_invariants() == []
