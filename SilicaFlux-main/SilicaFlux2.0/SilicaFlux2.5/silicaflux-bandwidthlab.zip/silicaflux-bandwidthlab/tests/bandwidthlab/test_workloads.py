"""Workload generators (GATES 11, 13): dependencies, CPU CPI, engine timing vs RTL formulas."""
import pytest

from bandwidthlab.bus import FabricConfig
from bandwidthlab.cpu import CpuConfig, CpuWorkload, cpu_programs
from bandwidthlab.masters import ComputeOp, MemOp
from bandwidthlab.simulation import System
from bandwidthlab.sram import SramConfig
from bandwidthlab.tensor import GemmKernel, TensorConfig, rtl_cycles_formula as te_rtl, tensor_program
from bandwidthlab.transaction import TxnKind
from bandwidthlab.units import UnitMismatchError
from bandwidthlab.vector import VectorConfig, VectorKernel, rtl_cycles_formula as ve_rtl, vector_program
from bandwidthlab.workloads import PATTERNS, init_pointer_chase, program


def mem_sys(**fkw):
    s = System("w", fabric_hz=100e6)
    rom = s.add_sram(SramConfig(name="rom", base_addr=0, capacity_bytes=4096, banks=1))
    ram = s.add_sram(SramConfig(name="ram", base_addr=0x1000_0000, capacity_bytes=64 * 1024, banks=1))
    s.add_interconnect(FabricConfig(**fkw))
    s.map_target(rom)
    s.map_target(ram)
    return s, ram


def test_pointer_chase_is_serial_and_follows_data():
    s, ram = mem_sys()
    nodes = init_pointer_chase(ram, 50, 0x1000_0000, 16384, 4, seed=3)
    m = s.add_master("cpu", program("pointer_chase", n=50, base=0x1000_0000, region_bytes=16384, seed=3),
                     max_outstanding=4)
    s.run()
    txns = m.completed_txns
    assert [t.addr for t in txns] == nodes[:50]                  # every address came from the previous load
    for a, b in zip(txns, txns[1:]):
        assert b.t_issued > a.t_completed                        # never overlapped despite 4 outstanding allowed
        assert a.tid in b.deps


def test_independent_stream_overlaps_but_dependent_does_not():
    def cycles(dep):
        s, _ = mem_sys()
        m = s.add_master("cpu", program("seq_read", n=200, base=0x1000_0000, region_bytes=4096, dependent=dep))
        s.run()
        return m.finish_cycle
    assert cycles(False) == 200 and cycles(True) == 2 * 200 - 1   # 1 access per 2 cycles when dependent


@pytest.mark.parametrize("pattern", [p for p in PATTERNS if p != "pointer_chase"])
def test_every_pattern_runs_clean(pattern):
    s, _ = mem_sys()
    s.add_master("cpu", program(pattern, n=120, base=0x1000_0000, region_bytes=4096, think_cycles=1, rate=0.3))
    s.run()
    assert s.check_invariants() == [] and s.ledger.summary()["completed"] == 120


def test_cpu_cpi_matches_documented_rtl_values():
    """sfv_cpu.sv:4-15: CPI 1 ALU, 2 load/store (zero wait), 3 taken branch."""
    for alu, br in ((0, 0), (3, 0), (3, 4), (7, 0)):
        s, _ = mem_sys(arbitration="fixed")
        f, x, info = cpu_programs(CpuConfig(), CpuWorkload(pattern="seq_read", n_mem=300, alu_per_mem=alu,
                                                           branch_every=br, data_base=0x1000_0000))
        s.add_master("cpu_i", f)
        md = s.add_master("cpu_d", x, links={"data": s.link("cpu_d_port")}, overlap_compute=False)
        s.run()
        documented = 300 * 2 + info["alu_instructions"] + 3 * info["branches"]
        assert abs(md.finish_cycle - documented) <= 2


def tspm():
    s = System("t", fabric_hz=100e6)
    t = s.add_sram(SramConfig(name="tspm", base_addr=0x2000_0000, capacity_bytes=16384, banks=4, n_ports=3,
                              arbitration="fixed"))
    return s, t


@pytest.mark.parametrize("K", [2, 16, 64, 256])
def test_tensor_engine_two_cycles_per_kstep_like_rtl(K):
    s, t = tspm()
    ops, _ = tensor_program(TensorConfig(overhead_cycles=1), GemmKernel(M=4, N=4, K=K, writeback=False),
                            local_base=t.base, word_bytes=4)
    m = s.add_master("te", ops, links={"a": s.sram_link(t, 0)}, max_outstanding=4, issue_model="dae")
    s.run()
    assert m.finish_cycle == te_rtl(K, False)                   # 3 + 2K with the calibrated overhead


@pytest.mark.parametrize("n", [64, 256, 1000])
def test_vector_engine_three_cycles_per_beat_like_rtl(n):
    s, t = tspm()
    ops, info = vector_program(VectorConfig(overhead_cycles=2), VectorKernel(op="vadd", n=n), local_base=t.base,
                               word_bytes=4)
    m = s.add_master("ve", ops, links={"vmem": s.sram_link(t, 1)}, max_outstanding=4, issue_model="dae")
    s.run()
    assert abs(m.finish_cycle - ve_rtl("vadd", n)) <= 1


def test_vector_lanes_cannot_share_a_single_port_bank():
    # 8 lanes on 4 banks: every beat needs two accesses per bank -> at least 2 cycles per operand
    s, t = tspm()
    ops, _ = vector_program(VectorConfig(lanes=8), VectorKernel(op="reduce", n=512), local_base=t.base, word_bytes=4)
    m = s.add_master("ve", ops, links={"vmem": s.sram_link(t, 1)}, max_outstanding=4, issue_model="dae")
    s.run()
    assert m.finish_cycle >= 2 * (512 // 8)
    assert t.stats()["conflicts"] > 0


def test_tensor_precision_rules():
    assert TensorConfig(precision="int4").operand_bytes(4) == 2
    assert TensorConfig(precision="int16").operand_bytes(4) == 8
    with pytest.raises(UnitMismatchError):
        TensorConfig(precision="bf16")
    TensorConfig(precision="bf16", fp_supported=True)


def test_double_buffering_overlaps_loads_with_compute():
    def run(buffers):
        s, t = tspm()
        ops, _ = tensor_program(TensorConfig(input_buffers=buffers, k_block=8),
                                GemmKernel(M=8, N=8, K=64), local_base=t.base, word_bytes=4)
        m = s.add_master("te", ops, links={"a": s.sram_link(t, 0)}, max_outstanding=4, issue_model="dae")
        s.run()
        return m.finish_cycle
    assert run(2) < run(1)
