"""Optional cache model: hit/miss behaviour, working-set effects, data correctness."""
import pytest

from bandwidthlab.bus import FabricConfig
from bandwidthlab.cache import CacheConfig, CachedLink
from bandwidthlab.masters import MemOp
from bandwidthlab.simulation import System
from bandwidthlab.sram import SramConfig
from bandwidthlab.transaction import TxnKind


def run(ops, **ckw):
    s = System("c", fabric_hz=100e6)
    m = s.add_sram(SramConfig(name="m", base_addr=0x1000_0000, capacity_bytes=64 * 1024, banks=1))
    s.add_interconnect(FabricConfig())
    s.map_target(m)
    m.write_bytes(0x1000_0000, bytes((i * 3) & 0xFF for i in range(4096)))
    c = CachedLink(s.sched, CacheConfig(**ckw), s.link("dcache"), domain="clk", ledger=s.ledger)
    cpu = s.add_master("cpu", ops, links={"default": c})
    s.run()
    assert s.check_invariants() == []
    return s, c, cpu, m


def loop(ws_bytes, passes):
    return [MemOp(TxnKind.READ, 0x1000_0000 + (i % (ws_bytes // 4)) * 4, 4) for i in range(passes * ws_bytes // 4)]


def test_working_set_smaller_than_cache_hits_after_warmup():
    s, c, cpu, m = run(loop(1024, 4), capacity_bytes=4096, line_bytes=32, ways=2)
    st = c.stats()
    assert st["misses"] == 1024 // 32 and st["hit_rate"] > 0.95


def test_working_set_larger_than_cache_thrashes_with_lru():
    s, c, cpu, m = run(loop(8192, 2), capacity_bytes=4096, line_bytes=32, ways=2)
    assert c.stats()["hit_rate"] == pytest.approx(7 / 8, abs=0.01)      # only spatial reuse inside a line


def test_read_data_correct_and_writeback_reaches_memory():
    ops = [MemOp(TxnKind.WRITE, 0x1000_0000, 4, data=0xDEADBEEF), MemOp(TxnKind.READ, 0x1000_0000, 4, deps=(0,))]
    ops += loop(8192, 1)                                              # evicts the dirty line
    s, c, cpu, m = run(ops, capacity_bytes=1024, line_bytes=32, ways=1)
    assert cpu.completed_txns[1].data == 0xDEADBEEF
    assert m.read_bytes(0x1000_0000, 4) == (0xDEADBEEF).to_bytes(4, "little")
    assert c.stats()["writebacks"] >= 1


@pytest.mark.parametrize("repl", ["lru", "fifo", "random", "plru"])
def test_replacement_policies_run(repl):
    s, c, cpu, m = run(loop(2048, 2), capacity_bytes=1024, line_bytes=32, ways=4, replacement=repl)
    assert 0 <= c.stats()["hit_rate"] < 1


def test_write_through_no_allocate():
    ops = [MemOp(TxnKind.WRITE, 0x1000_0040, 4, data=7)]
    s, c, cpu, m = run(ops, write_policy="write_through")
    assert m.read_bytes(0x1000_0040, 4) == (7).to_bytes(4, "little") and c.stats()["write_through_writes"] == 1
