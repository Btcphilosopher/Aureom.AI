import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
os.environ.setdefault("BANDWIDTHLAB_ROOT", str(ROOT))

from hypothesis import settings  # noqa: E402

settings.register_profile("bandwidthlab", deadline=None, max_examples=60, derandomize=True)
settings.load_profile("bandwidthlab")
