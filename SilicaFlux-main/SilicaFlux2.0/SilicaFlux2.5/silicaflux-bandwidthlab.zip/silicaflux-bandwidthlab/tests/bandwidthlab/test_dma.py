"""DMA engine (GATE 8): data movement, read->write dependency, completion semantics."""
import pytest

from bandwidthlab.bus import FabricConfig
from bandwidthlab.dma import Descriptor, DmaConfig, DmaConfigError, Segment
from bandwidthlab.simulation import System
from bandwidthlab.sram import SramConfig
from bandwidthlab.transaction import TxnKind


def sys2(dw=32, **dkw):
    s = System("d", fabric_hz=100e6)
    a = s.add_sram(SramConfig(name="a", base_addr=0x1000_0000, capacity_bytes=32 * 1024, banks=1, data_width=dw))
    b = s.add_sram(SramConfig(name="b", base_addr=0x1000_8000, capacity_bytes=32 * 1024, banks=1, data_width=dw))
    s.add_interconnect(FabricConfig(data_width_bits=dw))
    s.map_target(a)
    s.map_target(b)
    d = s.add_dma(DmaConfig(data_width_bits=dw, setup_cycles=0, completion_cycles=0, **dkw))
    return s, a, b, d


@pytest.mark.parametrize("engine,kw", [("simple", {}), ("buffered", {"fifo_depth": 8, "burst": 8}),
                                       ("buffered", {"fifo_depth": 2, "burst": 1, "max_outstanding_reads": 1}),
                                       ("buffered", {"fifo_depth": 16, "burst": 16})])
@pytest.mark.parametrize("length", [4, 6, 64, 257])
def test_copy_moves_exact_bytes(engine, kw, length):
    s, a, b, d = sys2(engine=engine, **kw)
    payload = bytes((i * 37 + 5) & 0xFF for i in range(length))
    a.write_bytes(0x1000_0000, payload)
    b.write_bytes(0x1000_8000, b"\xEE" * (length + 8))
    desc = d.submit(Descriptor.copy(0x1000_0000, 0x1000_8000, length))
    s.run()
    assert b.read_bytes(0x1000_8000, length) == payload
    assert b.read_bytes(0x1000_8000 + length, 3) == b"\xEE" * 3           # never writes beyond dst+len
    assert not desc.failed and desc.bytes_done == length
    assert s.check_invariants() == []


def test_read_write_dependency_every_write_after_its_read():
    s, a, b, d = sys2(engine="buffered", fifo_depth=4, burst=4)
    a.write_bytes(0x1000_0000, bytes(range(64)))
    d.submit(Descriptor.copy(0x1000_0000, 0x1000_8000, 64))
    s.run()
    reads = {t.addr - 0x1000_0000: t for t in d.txns if t.kind == TxnKind.DMA_READ}
    writes = {t.addr - 0x1000_8000: t for t in d.txns if t.kind == TxnKind.DMA_WRITE}
    for off, w in writes.items():
        assert w.t_issued > reads[off].t_completed               # data must have returned before the write


def test_completion_only_after_last_write_acknowledged():
    s, a, b, d = sys2(engine="buffered")
    desc = d.submit(Descriptor.copy(0x1000_0000, 0x1000_8000, 128))
    s.run()
    last_read = max(t.t_completed for t in d.txns if t.kind == TxnKind.DMA_READ)
    last_write_ack = max(t.t_completed for t in d.txns if t.kind == TxnKind.DMA_WRITE)
    done_fs = s.clock.edge(desc.t_done_cycle)
    assert done_fs >= last_write_ack > last_read


def test_simple_engine_four_cycles_per_beat_and_buffered_faster():
    s, *_ , d = sys2(engine="simple")
    desc = d.submit(Descriptor.copy(0x1000_0000, 0x1000_8000, 1024))
    s.run()
    assert desc.t_done_cycle - desc.t_submit_cycle == 4 * 256       # dma_transfer_engine.sv header: 4 cycles/beat
    s2, *_, d2 = sys2(engine="buffered", fifo_depth=8, burst=8)
    desc2 = d2.submit(Descriptor.copy(0x1000_0000, 0x1000_8000, 1024))
    s2.run()
    assert desc2.t_done_cycle - desc2.t_submit_cycle < 0.7 * 4 * 256


def test_dual_port_one_beat_per_cycle_between_slaves():
    s, a, b, d = sys2(engine="buffered", dual_port=True)
    desc = d.submit(Descriptor.copy(0x1000_0000, 0x1000_8000, 1024))
    s.run()
    assert desc.t_done_cycle - desc.t_submit_cycle <= 256 + 4


def test_read_error_stops_reads_and_reports_failure():
    s, a, b, d = sys2(engine="simple")
    desc = d.submit(Descriptor.copy(0x1000_FFF0, 0x1000_0000, 64))   # source runs into unmapped space
    s.run()
    assert desc.failed and desc.err_code == "READ_ERROR"
    assert desc.bytes_done == 16                                      # good prefix written
    assert s.check_invariants() == []


def test_multichannel_and_scatter_gather_extensions():
    s, a, b, d = sys2(engine="buffered", channels=2, scatter_gather=True)
    a.write_bytes(0x1000_0000, bytes(range(256)))
    d1 = d.submit(Descriptor([Segment(0x1000_0000, 0x1000_8000, 32), Segment(0x1000_0040, 0x1000_8040, 32)],
                             channel=0))
    d2 = d.submit(Descriptor.copy(0x1000_0080, 0x1000_8080, 64, channel=1))
    s.run()
    assert b.read_bytes(0x1000_8000, 32) == bytes(range(32))
    assert b.read_bytes(0x1000_8040, 32) == bytes(range(0x40, 0x60))
    assert b.read_bytes(0x1000_8080, 64) == bytes(range(0x80, 0xC0))
    assert not d1.failed and not d2.failed
    assert not d.cfg.rtl_equivalent()


def test_config_validation():
    with pytest.raises(DmaConfigError):
        DmaConfig(engine="buffered", fifo_depth=4, burst=8)
    with pytest.raises(DmaConfigError):
        DmaConfig(engine="buffered", fifo_depth=2, max_outstanding_reads=4)
    s, a, b, d = sys2()
    with pytest.raises(DmaConfigError):
        d.submit(Descriptor([Segment(0x1000_0000, 0x1000_8000, 8), Segment(0x1000_0010, 0x1000_8010, 8)]))
