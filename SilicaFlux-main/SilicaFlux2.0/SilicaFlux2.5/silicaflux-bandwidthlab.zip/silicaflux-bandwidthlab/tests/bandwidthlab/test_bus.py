"""DataFabric interconnect (GATES 3, 4, 6, 7): arbitration, backpressure, ordering, errors."""
import pytest
from hypothesis import given, strategies as st

from bandwidthlab.arbitration import Arbiter, ArbiterConfigError
from bandwidthlab.bus import FabricConfig, FabricConfigError
from bandwidthlab.masters import MemOp
from bandwidthlab.simulation import System
from bandwidthlab.sram import SramConfig
from bandwidthlab.transaction import TxnKind, TxnStatus


def fabric(nbanks_targets=2, lat=1, **fkw):
    s = System("t", fabric_hz=100e6)
    tg = [s.add_sram(SramConfig(name=f"m{i}", base_addr=0x1000_0000 + i * 0x1_0000, capacity_bytes=0x1_0000,
                                banks=1, read_latency=lat)) for i in range(nbanks_targets)]
    s.add_interconnect(FabricConfig(**fkw))
    for t in tg:
        s.map_target(t)
    return s, tg


def reads(base, n, **kw):
    return [MemOp(TxnKind.READ, base + 4 * i, 4, **kw) for i in range(n)]


def test_single_request_end_to_end():
    s, _ = fabric()
    m = s.add_master("cpu", reads(0x1000_0000, 1))
    s.run()
    (t,) = m.completed_txns
    assert t.status == TxnStatus.OK
    assert (t.t_completed - t.t_issued) // s.clock.period_fs == 1          # 1-cycle SRAM, 0-cycle crossbar
    assert t.t_accepted == t.t_service_start                               # SFB2: accepted when the target accepts
    assert s.check_invariants() == []


def test_two_sequential_requests_back_to_back():
    s, _ = fabric()
    m = s.add_master("cpu", reads(0x1000_0000, 2))
    s.run()
    a, b = m.completed_txns
    p = s.clock.period_fs
    # same-cycle reissue: the 2nd request is accepted in the cycle of the 1st response
    assert (b.t_accepted - a.t_accepted) // p == 1
    assert b.t_accepted == a.t_completed


def test_simultaneous_requests_to_one_target_serialise():
    s, _ = fabric(arbitration="rr")
    a = s.add_master("a", reads(0x1000_0000, 1))
    b = s.add_master("b", reads(0x1000_0100, 1))
    s.run()
    ta, tb = a.completed_txns[0], b.completed_txns[0]
    assert ta.t_accepted != tb.t_accepted                                  # one accept per cycle per slave port
    assert abs(ta.t_accepted - tb.t_accepted) == s.clock.period_fs
    assert s.ic.stats()["targets"][0]["contention_cycles"] >= 1


def test_simultaneous_requests_to_different_targets_parallel():
    s, _ = fabric(arbitration="rr")
    a = s.add_master("a", reads(0x1000_0000, 20))
    b = s.add_master("b", reads(0x1001_0000, 20))
    s.run()
    assert max(t.t_completed for t in a.completed_txns + b.completed_txns) // s.clock.period_fs <= 21


def test_fixed_priority_arbitration():
    s, _ = fabric(arbitration="fixed")
    hi = s.add_master("hi", reads(0x1000_0000, 30))
    lo = s.add_master("lo", reads(0x1000_0100, 30))
    s.run()
    # with a saturating high-priority master the low one is served only after it finishes
    assert min(t.t_accepted for t in lo.completed_txns) >= max(t.t_accepted for t in hi.completed_txns)


def test_round_robin_fairness():
    s, _ = fabric(arbitration="rr")
    ms = [s.add_master(f"m{i}", reads(0x1000_0000 + 0x100 * i, 40)) for i in range(4)]
    s.run()
    tp = s.ic.tports[0]
    assert tp.arb.grants == [40, 40, 40, 40]
    # interleaved service: max wait bounded by (N-1) grants
    st_ = s.ic.stats()
    assert max(m["max_arbitration_wait_cycles"] for m in st_["masters"]) <= 3
    assert all(m.finished for m in ms)


@given(st.lists(st.sets(st.integers(0, 4), min_size=1), min_size=1, max_size=60))
def test_rr_arbiter_bounded_waiting_property(req_seq):
    arb = Arbiter(5, "rr")
    waiting = {i: 0 for i in range(5)}
    for reqs in req_seq:
        w = arb.pick(sorted(reqs))
        assert w in reqs
        arb.accept(w, sorted(reqs))
        for r in range(5):                     # consecutive requesting rounds without a grant
            waiting[r] = 0 if (r == w or r not in reqs) else waiting[r] + 1
            assert waiting[r] <= 4


def test_fixed_arbiter_picks_lowest_index_and_wrr_respects_weights():
    a = Arbiter(3, "fixed")
    assert a.pick([2, 1]) == 1
    w = Arbiter(2, "wrr", weights=[3, 1])
    seq = []
    for _ in range(8):
        x = w.pick([0, 1])
        w.accept(x, [0, 1])
        seq.append(x)
    assert seq.count(0) == 6 and seq.count(1) == 2
    with pytest.raises(ArbiterConfigError):
        Arbiter(2, "wrr")
    with pytest.raises(ArbiterConfigError):
        Arbiter(2, "lottery")


def test_backpressure_from_busy_target_holds_request():
    # 2 masters on one 1-cycle slave with 3-cycle latency: 1 outstanding per slave port -> waits
    s, _ = fabric(lat=3)
    a = s.add_master("a", reads(0x1000_0000, 10))
    b = s.add_master("b", reads(0x1000_0100, 10))
    s.run()
    st_ = s.ic.stats()
    assert sum(m["request_backpressure_cycles"] for m in st_["masters"]) > 0
    assert s.check_invariants() == []
    assert max(t.t_completed for t in a.completed_txns + b.completed_txns) // s.clock.period_fs >= 60


def test_response_ordering_in_order_per_master():
    s, _ = fabric(lat=1, max_outstanding_per_master=4, max_outstanding_per_target=4, ordering="in_order")
    slow = s.srams["m1"]
    slow.cfg.read_latency = 5
    ops = []
    for i in range(10):
        ops.append(MemOp(TxnKind.READ, (0x1001_0000 if i % 2 else 0x1000_0000) + 4 * i, 4))
    m = s.add_master("cpu", ops, max_outstanding=4)
    s.run()
    tids = [t.tid for t in m.completed_txns]
    assert tids == sorted(tids)                       # responses returned in issue order
    assert s.ic.rsp_hol_cycles > 0                    # the fast target's responses waited (HOL)


def test_multiple_outstanding_transactions_increase_throughput():
    def run(mo):
        s, _ = fabric(lat=4, max_outstanding_per_master=mo, max_outstanding_per_target=mo)
        s.srams["m0"].cfg.rsp_fifo_depth = 8
        m = s.add_master("cpu", reads(0x1000_0000, 64), max_outstanding=mo)
        s.run()
        assert s.check_invariants() == []
        return m.finish_cycle
    c1, c4 = run(1), run(4)
    assert c1 >= 64 * 4 and c4 < c1 / 2


def test_illegal_address_decode_error():
    s, _ = fabric()
    m = s.add_master("cpu", [MemOp(TxnKind.READ, 0x7000_0000, 4), MemOp(TxnKind.READ, 0x1000_0000, 4)])
    s.run()
    e, ok = m.completed_txns
    assert e.status == TxnStatus.DECODE_ERROR and e.data == 0 and e.dst == "error_slave"
    assert (e.t_completed - e.t_accepted) // s.clock.period_fs == 1        # error slave answers after 1 cycle
    assert ok.status == TxnStatus.OK
    assert s.ic.decode_errors == 1


def test_access_matrix_denied_master_gets_error():
    s, _ = fabric()
    s.ic.set_access("cpu_i", {"m0"})
    m = s.add_master("cpu_i", [MemOp(TxnKind.READ, 0x1001_0000, 4)])
    s.run()
    assert m.completed_txns[0].status == TxnStatus.DECODE_ERROR


def test_shared_bus_one_transfer_per_cycle():
    s, _ = fabric(topology="shared_bus")
    a = s.add_master("a", reads(0x1000_0000, 20))
    b = s.add_master("b", reads(0x1001_0000, 20))
    s.run()
    end = max(t.t_completed for t in a.completed_txns + b.completed_txns) // s.clock.period_fs
    assert end >= 40                                    # 40 transfers through one bus


def test_register_slices_add_latency():
    s, _ = fabric(req_slices=1, rsp_slices=1)
    m = s.add_master("cpu", reads(0x1000_0000, 1))
    s.run()
    t = m.completed_txns[0]
    assert (t.t_completed - t.t_issued) // s.clock.period_fs == 3


def test_input_queue_registered_acceptance():
    s, _ = fabric(input_queue_depth=2)
    m = s.add_master("cpu", reads(0x1000_0000, 4))
    s.run()
    t = m.completed_txns[0]
    assert t.t_enqueued is not None and t.t_accepted == t.t_enqueued
    assert t.t_granted > t.t_enqueued                   # registered queue: eligible the next cycle


def test_multibeat_requires_burst_support():
    s, _ = fabric()
    m = s.add_master("cpu", [MemOp(TxnKind.READ, 0x1000_0000, 16)])
    with pytest.raises(FabricConfigError):
        s.run()


def test_rtl_equivalence_flag():
    ok, why = FabricConfig().rtl_equivalent()
    assert ok and why == []
    ok, why = FabricConfig(topology="shared_bus", max_outstanding_per_master=2).rtl_equivalent()
    assert not ok and len(why) == 2
