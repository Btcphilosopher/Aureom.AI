"""Small test-only drivers shared by the BandwidthLab tests."""
from __future__ import annotations

from bandwidthlab.scheduler import Scheduler
from bandwidthlab.sram import BankedSram, SramConfig
from bandwidthlab.transaction import MemTransaction, TransactionLedger, TxnKind, TxnState


class StimPort:
    """Drives one SRAM port with the MemoryLab bankbench stimulus rule:
    request i is presented in the first cycle >= not_before that is strictly after the
    acceptance cycle of request i-1; responses are taken when rsp_ready(port, cycle)."""

    kind = "stim"
    rank = 2

    def __init__(self, sched, sram, port, reqs, *, start_cycle=1, rsp_ready=None, ledger=None, word_addr=True):
        self.sched, self.sram, self.port, self.reqs = sched, sram, port, list(reqs)
        self.name = f"stim{port}"
        self.domain = sram.domain
        self.drv = sched.driver(self.domain)
        self.start = start_cycle
        self.rsp_ready = rsp_ready or (lambda p, c: True)
        self.ledger = ledger
        self.word_addr = word_addr
        self.i = 0
        self.not_before_accept = -1
        self.accepts, self.responses = [], []
        self.pending = 0
        sram.set_accept_callback(port, self._acc)
        self.drv.attach(self)
        sched.register(self)
        self.drv.wake(self.drv.clock.edge(start_cycle))

    def outstanding(self):
        return (len(self.reqs) - self.i) + self.pending

    def busy(self):
        return self.i < len(self.reqs)

    def _acc(self, t, cyc):
        self.accepts.append((cyc - self.start, self.port, t.tag))
        self.not_before_accept = cyc
        self.i += 1
        if t.meta.get("posted"):
            self.pending -= 1
            t.advance(TxnState.COMPLETED, self.sched.now)
            if self.ledger:
                self.ledger.on_completed(t, self.sched.now)

    def on_response(self, cyc):
        t = self.sram.peek_response(self.port, cyc)
        if t is not None and self.rsp_ready(self.port, cyc - self.start):
            self.sram.pop_response(self.port, cyc)
            t.advance(TxnState.COMPLETED, self.sched.now)
            if self.ledger:
                self.ledger.on_completed(t, self.sched.now)
            self.pending -= 1
            self.responses.append((cyc - self.start, self.port, t.tag, (t.data or 0) if t.op == "R" else 0,
                                   int(t.error), int(t.op == "W")))

    def on_issue(self, cyc):
        if self.i >= len(self.reqs) or not self.sram.can_present(self.port):
            return
        r = self.reqs[self.i]
        if cyc < r.nb + self.start or cyc <= self.not_before_accept:
            if cyc < r.nb + self.start:
                self.drv.wake(self.drv.clock.edge(r.nb + self.start))
            return
        wb = self.sram.cfg.word_bytes
        kind = TxnKind.WRITE if r.we else TxnKind.READ
        t = MemTransaction.new(self.sched.new_id(), self.name, kind, r.addr * wb if self.word_addr else r.addr, wb,
                               self.sched.now, data=r.data, byte_enable=r.mask)
        t.tag = r.rid
        t.advance(TxnState.ISSUED, self.sched.now)
        if self.ledger:
            self.ledger.on_generated(t)
        self.pending += 1
        self.sram.present(self.port, t)


def run_stim(cfg: SramConfig, stim, *, bp=None, freq=100e6, start_cycle=1, ledger=None):
    sched = Scheduler(record_events=False)
    sched.add_clock("clk", freq)
    sram = BankedSram(sched, cfg, ledger=ledger)
    sram.log_enabled = True
    ports = [StimPort(sched, sram, p, stim[p], start_cycle=start_cycle, rsp_ready=bp, ledger=ledger)
             for p in range(cfg.n_ports)]
    sched.run()
    acc = sorted(a for p in ports for a in p.accepts)
    rsp = sorted(r for p in ports for r in p.responses)
    conf = sorted((c - start_cycle, p) for c, ev, p, _, _ in sram.log if ev == "CONF")
    return {"accepts": acc, "responses": rsp, "conflicts": conf, "sram": sram, "sched": sched}
