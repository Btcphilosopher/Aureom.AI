"""Deterministic event kernel (GATE 2) and termination / safety checks."""
import pytest
from hypothesis import given, strategies as st

from bandwidthlab.events import EventType, REQUIRED_EVENT_TYPES
from bandwidthlab.scheduler import (PRIO_COMPLETE, PRIO_ISSUE, PRIO_TICK, DeadlockError, LimitExceeded,
                                    NoForwardProgressError, Scheduler, SchedulingError, ZeroTimeLoopError)


def test_required_event_types_present():
    names = {e.value for e in REQUIRED_EVENT_TYPES}
    assert names == {"REQUEST_GENERATED", "REQUEST_ACCEPTED", "ARBITRATION_GRANTED", "QUEUE_ENTERED", "QUEUE_EXITED",
                     "MEMORY_SERVICE_STARTED", "MEMORY_SERVICE_COMPLETED", "RESPONSE_GENERATED", "RESPONSE_ACCEPTED",
                     "DMA_BURST_STARTED", "DMA_BURST_COMPLETED", "COMPUTE_STARTED", "COMPUTE_COMPLETED",
                     "STALL_STARTED", "STALL_ENDED"}


def test_simultaneous_events_ordered_by_priority_then_sequence():
    s = Scheduler()
    out = []
    s.schedule_at(100, lambda: out.append("tick-a"), PRIO_TICK)
    s.schedule_at(100, lambda: out.append("issue-a"), PRIO_ISSUE)
    s.schedule_at(100, lambda: out.append("complete"), PRIO_COMPLETE)
    s.schedule_at(100, lambda: out.append("issue-b"), PRIO_ISSUE)
    s.schedule_at(50, lambda: out.append("early"), PRIO_TICK)
    s.run()
    assert out == ["early", "complete", "issue-a", "issue-b", "tick-a"]


@given(st.lists(st.tuples(st.integers(0, 1000), st.sampled_from([0, 10, 20, 30])), min_size=1, max_size=60))
def test_ordering_is_total_and_reproducible(evs):
    def run_once():
        s = Scheduler()
        out = []
        for i, (t, p) in enumerate(evs):
            s.schedule_at(t, lambda i=i: out.append(i), p)
        s.run()
        return out
    a, b = run_once(), run_once()
    assert a == b
    keys = [(evs[i][0], evs[i][1], i) for i in a]
    assert keys == sorted(keys)


def test_negative_delay_and_past_event_rejected():
    s = Scheduler()
    with pytest.raises(SchedulingError):
        s.schedule(-1, lambda: None)
    s.schedule_at(10, lambda: s.schedule_at(5, lambda: None))
    with pytest.raises(SchedulingError):
        s.run()
    s2 = Scheduler()
    with pytest.raises(SchedulingError):
        s2.schedule(1.5, lambda: None)


def test_zero_time_loop_detected():
    s = Scheduler(max_events_per_timestamp=1000)

    def again():
        s.schedule(0, again)
    s.schedule(0, again)
    with pytest.raises(ZeroTimeLoopError):
        s.run()


def test_event_limit_bounds_runaway_simulation():
    s = Scheduler(max_events=500)

    def again():
        s.schedule(1, again)
    s.schedule(1, again)
    with pytest.raises(LimitExceeded):
        s.run()


def test_simulated_time_limit():
    s = Scheduler(max_time_fs=1000)

    def again():
        s.schedule(100, again)
    s.schedule(100, again)
    with pytest.raises(LimitExceeded):
        s.run()


class _Stuck:
    name = "stuck"

    def outstanding(self):
        return 3


def test_deadlock_detected_when_queue_drains_with_outstanding_work():
    s = Scheduler()
    s.register(_Stuck())
    s.schedule(10, lambda: None)
    with pytest.raises(DeadlockError, match="stuck"):
        s.run()


def test_watchdog_detects_lack_of_forward_progress():
    s = Scheduler(watchdog_fs=10_000)
    s.register(_Stuck())

    def spin():
        s.schedule(10, spin)          # time advances, nothing ever completes
    s.schedule(10, spin)
    with pytest.raises(NoForwardProgressError):
        s.run()


def test_typed_event_records_carry_required_fields():
    s = Scheduler()
    s.add_clock("clk", 100e6)
    s.schedule_event(20_000_000, EventType.COMPUTE_STARTED, domain="clk", src="te", dst="te", payload={"x": 1})
    s.schedule_event(20_000_000, EventType.COMPUTE_COMPLETED, domain="clk", src="te", dst="te")
    s.run()
    a, b = s.log
    assert a.time_fs == 20_000_000 and a.cycle == 2 and a.domain == "clk"
    assert a.seq < b.seq and a.etype == EventType.COMPUTE_STARTED and a.payload == {"x": 1}
    assert set(a.as_dict()) == set(a.COLUMNS)


def test_simulation_terminates_and_reports_stop_reason():
    s = Scheduler()
    s.schedule(5, lambda: None)
    rs = s.run()
    assert rs.stopped_by == "drained" and rs.events == 1
    s2 = Scheduler()
    s2.schedule(5, lambda: None)
    s2.schedule(50, lambda: None)
    rs2 = s2.run(until_fs=10)
    assert rs2.stopped_by == "until" and s2.now == 5


def test_clock_conversion_correctness():
    s = Scheduler()
    a = s.add_clock("fabric", 50e6)      # 20 ns
    b = s.add_clock("dram", 400e6)       # 2.5 ns
    assert a.period_fs == 20_000_000 and b.period_fs == 2_500_000
    assert a.quantisation_error == 0 and b.quantisation_error == 0
    assert s.cycle_of("fabric", 60_000_000) == 3 and s.cycle_of("dram", 60_000_000) == 24
    c = s.add_clock("odd", 3e8)          # 3.333.. ns: not an integer number of fs
    assert c.quantisation_error < 1e-6
    with pytest.raises(ValueError):
        s.add_clock("fabric", 1e6)


def test_domain_driver_skips_idle_time_but_keeps_exact_cycles():
    s = Scheduler()
    s.add_clock("clk", 100e6)
    drv = s.driver("clk")
    seen = []

    class C:
        name = "c"

        def __init__(self):
            self.left = 3

        def on_post(self, cyc):
            seen.append(cyc)
            self.left -= 1

        def busy(self):
            return self.left > 0
    c = C()
    drv.attach(c)
    drv.wake(drv.clock.edge(1000))
    s.run()
    assert seen == [1000, 1001, 1002]
    assert drv.active_edges == 3
