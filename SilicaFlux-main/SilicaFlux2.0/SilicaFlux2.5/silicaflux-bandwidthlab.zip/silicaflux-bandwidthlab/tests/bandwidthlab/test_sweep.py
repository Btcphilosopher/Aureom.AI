"""Parameter sweep reproducibility (GATE 14) and the marginal-gain optimiser."""
from pathlib import Path

from bandwidthlab.optimisation import marginal_gains, pareto_front, smallest_meeting
from bandwidthlab.sweep import run_variant, run_variants, sweep_specs

ROOT = Path(__file__).resolve().parents[2]


def _spec(over, label):
    return {"config": str(ROOT / "configs" / "silicaflux_v.yaml"), "overrides": over, "scenario": "dma_copy",
            "args": {"src_mem": "sram", "dst_mem": "sram", "nbytes": 2048, "dst_off": 0x10000}, "label": label,
            "factor": "dma", "value": label}


def test_sweep_is_reproducible_bitwise():
    specs = [_spec({}, "simple"), _spec({"dma.engine": "buffered"}, "buffered")]
    a = run_variants(specs, workers=1)
    b = run_variants(specs, workers=2)
    assert [r["result_hash"] for r in a] == [r["result_hash"] for r in b]
    assert all(r["valid"] and r["dma_data_ok"] for r in a)


def test_invalid_configuration_is_reported_not_dropped():
    r = run_variant(_spec({"memories.sram.banks": 3}, "bad"))
    assert r["valid"] is False and "divisible" in r["reason"]


def test_sweep_definition_is_ofat_plus_interactions():
    specs = sweep_specs(ROOT / "configs" / "bandwidth_sweep.yaml")
    labels = [s["label"] for s in specs]
    assert labels[0] == "baseline" and "bus_width=64" in labels and "bus_width=64,sram_banks=8" in labels
    full = 4 * 5 * 6 * 5 * 3 * 4 * 5 * 6
    assert len(specs) < full / 100                                    # never the full Cartesian product


def test_marginal_gain_and_pareto():
    rows = [{"value": v, "total_cycles": c, "res_dma_fifo_bits": v * 32, "lat_mean": 1, "lat_p95": 1, "lat_p99": 1,
             "throughput": 1 / c, "cost_index": v, "valid": True} for v, c in ((1, 1000), (2, 600), (4, 500), (8, 495))]
    mg = marginal_gains(rows, factor="dma_fifo")
    assert mg[0]["rel_gain"] > 0.6 and mg[-1]["diminishing_returns"]
    front = pareto_front(rows, objectives=(("throughput", "max"), ("cost_index", "min")))
    assert len(front) == 4
    assert smallest_meeting(rows, {"total_cycles_max": 550})["value"] == 4
