# Traces

`rtl_transactions.csv` — RTL_OBSERVED in this project: the acceptance and response cycle of every transaction of
crossbar calibration case 0 (4 masters × 2 slaves, 1-cycle slaves, round robin, random traffic, 1,200 transactions),
recorded from the **unmodified** DataFabric `sfb_crossbar` RTL under Verilator 5.020 with
`rtl_harness/tb_bandwidthlab_xbar.sv`. Columns: master, id (per-master request index), accept_cycle, response_cycle,
error, rdata. The BandwidthLab model reproduces every row exactly (`calibration/calibration.json`).

Import: `PYTHONPATH=python python -m bandwidthlab trace --trace traces/rtl_transactions.csv` or
`python -m bandwidthlab calibrate --trace traces/rtl_transactions.csv`.

The DataFabric repository also contains five recorded `sfb_trace_monitor` traces
(`silicaflux-datafabric/reports/datafabric/traces/*.csv`); `calibrate` imports them from the repository archive.
