# SilicaFlux HostLink — Integration report (Project 25)

## 1. Verdict

* **Definition of done — met on the simulation backend.** The SilicaFlux device is controlled exclusively through
  the documented host interface (BAR0 registers, host-memory queues, interrupts), and a complete
  data-transfer-plus-compute operation — host buffers → DMA → SilicaFlux-V tensor engine GEMM → DMA → host — runs
  bit-exact through the C driver on the Verilated RTL (`reports/gemm_demo_sim.log`, also under 50 % AXI
  back-pressure) and through an independent SystemVerilog host on Icarus and Verilator (`reports/sv_tests.log`).
* **Physical PCIe — blocked.** The repository contains no PCIe-capable board, no endpoint IP, and this environment
  has no vendor tools or FPGA hardware. Following the brief, no custom PCIe protocol logic was written; the design
  ends at a generic AXI endpoint boundary and nothing is claimed about PCIe compliance, enumeration, link
  properties or hardware behaviour.

## 2. Brief compliance

| § | Requirement | Status | Evidence |
|---|---|---|---|
| 1 | Repository and platform audit | done | [docs/00_AUDIT.md](docs/00_AUDIT.md) |
| 1 | No endpoint → simulated host transport, physical PCIe marked blocked | done | [docs/06_SIM_BACKEND.md](docs/06_SIM_BACKEND.md), [docs/08_FPGA_BRINGUP.md](docs/08_FPGA_BRINGUP.md) |
| 2 | Host → endpoint → BAR bridge → command queue → DataFabric → vector/tensor engines; bulk host memory ↔ DMA ↔ device memory; PCIe core separate | done (vector engine wired, no opcode in ABI 1.0) | [docs/01_ARCHITECTURE.md](docs/01_ARCHITECTURE.md) |
| 3 | Versioned register map: ID, revision, capabilities, reset/control, SQ/CQ config, interrupt status, perf counters, error reporting; offsets/permissions/side effects; C definitions | done (74 registers, ABI 1.0) | [docs/03_REGISTER_MAP.md](docs/03_REGISTER_MAP.md), [generated/silicaflux_hostlink_abi.h](generated/silicaflux_hostlink_abi.h) |
| 4 | DMA submission: src, dst, length, direction, transaction ID, completion flags; validated host access; mapping rules | done; **scatter-gather not implemented** (CAPS bit 0, by design) | [docs/04_DMA_AND_ISOLATION.md](docs/04_DMA_AND_ISOLATION.md) |
| 5 | Head/tail, ownership (phase tags), full/empty, validation, completion records, error status, queue reset, memory-ordering rules, no early completion | done | [docs/02_DRIVER_ABI.md](docs/02_DRIVER_ABI.md) §5–7 |
| 6 | MSI/MSI-X via endpoint, polling fallback; masking, clearing, completion and error cases tested | done in simulation; real MSI-X blocked | [docs/05_INTERRUPTS.md](docs/05_INTERRUPTS.md) |
| 7 | Windows, lengths, overflow, register permissions, reset, in-flight transfers; IOMMU reliance documented | done | [docs/04_DMA_AND_ISOLATION.md](docs/04_DMA_AND_ISOLATION.md) |
| 8 | Transaction-level host model: BAR, submission, DMA, completion polling, interrupts, failure injection; same ABI on sim and hardware backends | done (hardware backend compiles, not run) | `tb/cosim/`, `sw/backends/` |
| 9 | FPGA bring-up with logs and link properties | **blocked** — no logs exist; procedure and acceptance criteria written | [docs/08_FPGA_BRINGUP.md](docs/08_FPGA_BRINGUP.md) |
| 10 | CXL directions; no PCIe-DMA-as-CXL claims | research note | [docs/09_CXL_RESEARCH.md](docs/09_CXL_RESEARCH.md) |
| 11 | Register access, submission, wraparound, integrity, invalid descriptors, back-pressure, reset, interrupts, timeouts, error recovery | done | [docs/10_VERIFICATION.md](docs/10_VERIFICATION.md) §2 |
| 12 | Deliverables | done | [README.md](README.md#deliverables-brief-12) |

## 3. Integration with existing SilicaFlux work

* **DataFabric (Project 03)**: HostLink is master M0 of an unmodified `sfb_crossbar` (round robin, 2×2) and obeys
  SFB2 rules R1–R12 (requests held until accepted, responses back-pressured, write acknowledged before completion).
  M1 is exported for ControlCore or other masters; `fabric_contention` verifies both masters at once.
* **SilicaFlux-V tile**: the unmodified `sfv_tile` provides the TSPM (via `sfb_v1_slave_adapter`) and the tensor
  engine register page; `TENSOR_GEMM` reproduces the engine's documented deterministic cycle count exactly
  (3 + 2K + 4) for K = 1…1024.
* **SRAM Wrapper Library**: device SRAM through the unmodified `sfb_sram_slave`.
* **Coding rules**: SilicaFlux-V `RTL_CODING_RULES.md` subset; one source accepted by Verilator 5.020, Icarus 12,
  Yosys 0.33. 46 vendored files, SHA-256 identical to the repository archive.
* **Next integrations** (not done): ControlCore host port + `host_irq` behind HostLink, HPC M06 command queue as
  an execution back end, vector-engine opcode ([docs/07_ENDPOINT_INTEGRATION.md](docs/07_ENDPOINT_INTEGRATION.md) §6).

## 4. Results

| Evidence | Result | File |
|---|---|---|
| Co-simulation suite (28 directed tests × 4 seeds + 32 regression seeds) | 144 / 144 pass | `reports/cosim_results.md` |
| SV system smoke + interrupt unit test, Icarus 12 and Verilator 5 | 4 / 4 pass | `reports/sv_tests.log` |
| Mutation testing, 26 injected RTL bugs | 26 / 26 killed | `reports/mutants.md` |
| Lint (Verilator -Wall, 6 configurations; 10 illegal sets; Icarus; SHA-256) | 0 warnings in new RTL; PASS | `reports/lint.log` |
| Yosys 0.33 synthesis (generic, xc7 mapping) | no latches, check clean; ≈ 6.0 k LUT / 4.6 k FF estimate | `reports/synth.log` |
| Memory ordering model | stale completions without flush under relaxed ordering: 13–17 / 30; with FLUSH: 0 | `reports/cosim.log` |
| DMA throughput (RTL, 24-cycle read latency) | H2D 0.92 B/cycle, D2H 1.05 B/cycle | `reports/gemm_demo_sim.log` |
| VFIO hardware backend | compiles with `-Wall -Wextra -Werror`; exits cleanly without hardware; never executed | `reports/vfio_build.log` |

## 5. Blocked items and how to unblock

| Blocked | Needed | Then |
|---|---|---|
| endpoint IP integration, FPGA build | PCIe development board + vendor tools/IP licence | build per [08_FPGA_BRINGUP.md](docs/08_FPGA_BRINGUP.md) §2, satisfying E1–E10 of [07](docs/07_ENDPOINT_INTEGRATION.md) |
| enumeration, link speed/width, BAR, DMA, MSI-X on hardware | the board in an IOMMU-enabled Linux host | run the acceptance table of [08](docs/08_FPGA_BRINGUP.md) §3, record logs in `reports/hw_bringup.md` |
| ordering assumptions E3/E4 on the real bridge | hardware stress run with `FLUSH_ALL` off/on | if stale data appears, ship with `FLUSH_ALL` |

## 6. Known limitations and next steps

1. **Throughput** ≈ 1 B/cycle: one SFB2 word in flight, no overlap between a chunk's host burst and its device
   beats, one AXI burst outstanding. Path: 64-bit DataFabric port, pipelined SFB2 requests (the crossbar accepts
   the next request in the cycle the previous response is accepted), double-buffered chunks, several outstanding
   read bursts with in-order completion tracking.
2. **One queue pair, one command in flight**, strictly in order. Multiple queues (per process / per VM) and
   out-of-order completion would need per-queue doorbells and IDs.
3. **No scatter-gather** (one DMA entry per contiguous IOVA range).
4. **No vector-engine opcode** in ABI 1.0 (0x03 reserved; register page wired).
5. **No formal proofs** for HostLink (candidates: doorbell arithmetic, window check, reset quiescence).
6. Single clock domain; endpoint-side CDC and width conversion are integration tasks.
7. Area: 64-bit perf counters with snapshots and the flop-based burst buffer dominate; the buffer should map to
   LUT-RAM/BRAM and counters could shrink to 48 bits.

## 7. Risks

| Risk | Mitigation |
|---|---|
| chosen endpoint reorders bridge writes or lets MSI overtake them | `CTRL.FLUSH_ALL` (verified in the model); hardware stress test in bring-up |
| endpoint hangs instead of returning an error on completion timeout | HostLink watchdog → FATAL; endpoint/FLR reset recovers (`t_host_timeout`) |
| driver or device misuse of DMA | IOMMU is the security boundary; windows are defence in depth; rejected commands provably touch nothing (`t_invalid_descriptors`) |
| CQE atomic visibility assumption (as in NVMe) | 16-byte aligned single-burst CQE inside one cache line, phase dword read first, read barrier |
