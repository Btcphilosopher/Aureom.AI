// SilicaFlux HostLink -- co-simulation test suite.
// The C driver library (sw/lib/sfh_driver.c) drives the Verilated RTL
// (sfh_device_top) through the transaction-level host model (tb/cosim).
//
// usage: test_hostlink [--list] [--filter substr] [--seeds N] [--report file.md] [--trace]
#include <algorithm>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <functional>
#include <string>
#include <vector>

#include "Vsfh_device_top.h"
#include "sfh_driver.h"
#include "sfh_regtable.h"
#include "sfh_sim.h"

// ============================================================================ framework
static std::string fmtx(const char *f, ...) {
  char b[1024];
  va_list ap;
  va_start(ap, f);
  vsnprintf(b, sizeof b, f, ap);
  va_end(ap);
  return b;
}
struct TestFail { std::string msg; };
#define REQUIRE(c, ...)                                                                            \
  do {                                                                                             \
    if (!(c)) throw TestFail{fmtx("%s:%d: REQUIRE(%s) ", __FILE__, __LINE__, #c) + fmtx(__VA_ARGS__)}; \
  } while (0)

static bool g_trace = false;
static const uint64_t TMO = 20000;   // us of simulated time (5 M cycles)

struct Dev {
  SfhSim sim;
  sfh_dev d{};
  SfhSim::Buf pool{};               // data pool (window 2, read+write)
  explicit Dev(SimCfg c) : sim((c.trace = c.trace || g_trace, c)) {
    REQUIRE(sfh_open(&d, sfh_sim_backend_ops(), &sim) == SFH_OK, "open");
  }
  uint32_t rd(uint32_t o) { return sim.bar_read(o); }
  void wr(uint32_t o, uint32_t v) { sim.bar_write(o, v); }
  void bringup(unsigned sql = 4, unsigned cql = 4, size_t pool_bytes = 256 * 1024, uint32_t extra = 0,
               int irq = 0) {
    REQUIRE(sfh_queues_alloc(&d, sql, cql) == SFH_OK, "queues");
    pool = sim.dma_alloc(pool_bytes);
    REQUIRE(sfh_set_window(&d, 2, pool.iova, pool.size,
                           SFH_WIN_CTRL_VALID_MASK | SFH_WIN_CTRL_DEV_READ_MASK | SFH_WIN_CTRL_DEV_WRITE_MASK) == SFH_OK,
            "window");
    sfh_irq_setup(&d, irq);
    REQUIRE(sfh_enable(&d, extra) == SFH_OK, "enable: ERR_STATUS=%08x", rd(SFH_REG_ERR_STATUS));
  }
  sfh_cqe run(sfh_sqe e) {
    sfh_cqe c{};
    int rc = sfh_run(&d, &e, &c, TMO);
    REQUIRE(rc == SFH_OK, "sfh_run rc=%d STATUS=%08x ERR=%08x", rc, rd(SFH_REG_STATUS), rd(SFH_REG_ERR_STATUS));
    return c;
  }
  uint16_t run_st(sfh_sqe e) { return SFH_CQE_STATUS(run(e).dw3); }
  void no_violations() {
    REQUIRE(sim.violations.empty(), "%zu protocol violations, first: %s", sim.violations.size(),
            sim.violations.empty() ? "" : sim.violations[0].c_str());
  }
};

static SimCfg cfg_default(uint64_t seed = 1) {
  SimCfg c;
  c.seed = seed;
  return c;
}

static void fill_rand(std::mt19937_64 &r, uint8_t *p, size_t n) {
  for (size_t i = 0; i < n; i++) p[i] = (uint8_t)r();
}

// reference 4x4 GEMM, A column-major (word k = A[0..3][k]), B row-major (word k = B[k][0..3])
static void ref_gemm(const uint8_t *A, const uint8_t *B, unsigned K, bool au, bool bu, int32_t C[16]) {
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++) {
      int64_t s = 0;
      for (unsigned k = 0; k < K; k++) {
        int a = au ? (int)A[4 * k + i] : (int)(int8_t)A[4 * k + i];
        int b = bu ? (int)B[4 * k + j] : (int)(int8_t)B[4 * k + j];
        s += a * b;
      }
      C[4 * i + j] = (int32_t)s;
    }
}

// ============================================================================ tests
// 1. ABI conformance: every register's reset value, unmapped offsets
static void t_reg_reset_values(uint64_t seed) {
  Dev x(cfg_default(seed));
  for (unsigned i = 0; i < SFH_REGTABLE_N; i++) {
    const sfh_regdesc &r = sfh_regtable[i];
    uint32_t v = x.rd(r.off);
    REQUIRE(v == r.reset, "%s @%03x reset %08x != ABI %08x", r.name, r.off, v, r.reset);
  }
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) == 0, "reads must have no side effects");
  unsigned unmapped = 0;
  for (uint32_t off = 0; off < SFH_BAR0_BYTES; off += 4) {
    bool mapped = false;
    for (unsigned i = 0; i < SFH_REGTABLE_N; i++) mapped |= sfh_regtable[i].off == off;
    if (mapped) continue;
    unmapped++;
    REQUIRE(x.rd(off) == 0xFFFFFFFFu, "unmapped %03x must read all-ones", off);
    REQUIRE(x.rd(SFH_REG_ERR_REG_OFFSET) == off, "ERR_REG_OFFSET");
  }
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_REG_ACCESS_MASK, "REG_ACCESS logged");
  REQUIRE(x.sim.bar_slverr_reads == unmapped, "SLVERR count %u != %u", x.sim.bar_slverr_reads, unmapped);
  x.no_violations();
}

// 2. access permissions and rejected accesses
static void t_reg_access_rules(uint64_t seed) {
  Dev x(cfg_default(seed));
  // RW / RWL registers while disabled + idle: writable bits == mask
  for (unsigned i = 0; i < SFH_REGTABLE_N; i++) {
    const sfh_regdesc &r = sfh_regtable[i];
    if ((r.acc != SFH_ACC_RW && r.acc != SFH_ACC_RWL) || r.off == SFH_REG_CTRL || r.off == SFH_REG_INT_VECTOR)
      continue;
    x.wr(r.off, 0xFFFFFFFFu);
    REQUIRE(x.rd(r.off) == r.wmask, "%s: ones -> %08x, mask %08x", r.name, x.rd(r.off), r.wmask);
    x.wr(r.off, 0x5A5A5A5Au);
    REQUIRE(x.rd(r.off) == (0x5A5A5A5Au & r.wmask), "%s pattern", r.name);
    x.wr(r.off, r.reset);
  }
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) == 0, "legal writes must not log errors (%08x)", x.rd(SFH_REG_ERR_STATUS));
  // RO registers: write rejected, logged, value unchanged
  for (unsigned i = 0; i < SFH_REGTABLE_N; i++) {
    const sfh_regdesc &r = sfh_regtable[i];
    if (r.acc != SFH_ACC_RO || r.off == SFH_REG_STATUS) continue;
    uint32_t before = x.rd(r.off);
    x.wr(r.off, ~before);
    // a rejected write to ERR_REG_OFFSET logs its own offset there (by design)
    uint32_t expect = r.off == SFH_REG_ERR_REG_OFFSET ? SFH_REG_ERR_REG_OFFSET : before;
    REQUIRE(x.rd(r.off) == expect, "%s changed by write", r.name);
    REQUIRE(x.rd(SFH_REG_ERR_REG_OFFSET) == r.off, "%s offset not logged", r.name);
  }
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_REG_ACCESS_MASK, "REG_ACCESS");
  x.wr(SFH_REG_ERR_STATUS, 0x7F);
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) == 0, "W1C");
  // sub-word write rejected
  x.wr(SFH_REG_SCRATCH, 0x11223344);
  x.sim.bar_write(SFH_REG_SCRATCH, 0xAABBCCDD, 0x3);
  REQUIRE(x.rd(SFH_REG_SCRATCH) == 0x11223344, "sub-word write must be rejected");
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_REG_ACCESS_MASK, "logged");
  // misaligned offset
  REQUIRE(x.rd(SFH_REG_SCRATCH + 1) == 0xFFFFFFFF, "misaligned read");
  // BAR bursts and narrow sizes are answered by the endpoint shell with SLVERR
  std::vector<uint32_t> d;
  bool lok = false, iok = false;
  auto rr = x.sim.bar_read_raw(SFH_REG_SCRATCH, 3, 2, &d, 9, &lok, &iok);
  REQUIRE(rr.size() == 4 && lok && iok, "burst read: %zu beats rlast %d id %d", rr.size(), lok, iok);
  for (auto r : rr) REQUIRE(r == 2, "burst read beat must be SLVERR");
  REQUIRE(x.sim.bar_write_raw(SFH_REG_SCRATCH, 1, 2, {1, 2}, 0xF, 5, &iok) == 2 && iok, "burst write SLVERR");
  REQUIRE(x.sim.bar_write_raw(SFH_REG_SCRATCH, 0, 1, {7}, 0xF, 3, &iok) == 2 && iok, "narrow write SLVERR");
  REQUIRE(x.rd(SFH_REG_SCRATCH) == 0x11223344, "rejected bursts must not write");
  // ID echo
  for (int i = 0; i < 16; i++) {
    REQUIRE(x.sim.bar_write_raw(SFH_REG_SCRATCH, 0, 2, {(uint32_t)i}, 0xF, (uint8_t)i, &iok) == 0 && iok, "id");
    rr = x.sim.bar_read_raw(SFH_REG_SCRATCH, 0, 2, &d, (uint8_t)(15 - i), &lok, &iok);
    REQUIRE(iok && lok && d[0] == (uint32_t)i, "read id/data");
  }
  // INT_VECTOR range check
  x.wr(SFH_REG_INT_VECTOR, 0x0F0F);
  REQUIRE(x.rd(SFH_REG_INT_VECTOR) == 0x100, "out-of-range vector rejected");
  x.wr(SFH_REG_INT_VECTOR, 0x0001);
  REQUIRE(x.rd(SFH_REG_INT_VECTOR) == 0x0001, "vector accepted");
  // RWL locked while enabled
  x.bringup();
  x.wr(SFH_REG_ERR_STATUS, 0x7F);
  uint32_t sqlo = x.rd(SFH_REG_SQ_BASE_LO);
  x.wr(SFH_REG_SQ_BASE_LO, 0);
  x.wr(SFH_REG_WIN_CTRL(2), 0);
  REQUIRE(x.rd(SFH_REG_SQ_BASE_LO) == sqlo && x.rd(SFH_REG_WIN_CTRL(2)) != 0, "RWL must be locked while enabled");
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_REG_ACCESS_MASK, "logged");
  // reads have no side effects
  uint32_t e1 = x.rd(SFH_REG_ERR_STATUS), e2 = x.rd(SFH_REG_ERR_STATUS);
  REQUIRE(e1 == e2, "read side effect");
  x.no_violations();
}

// 3. queue configuration validated against windows at ENABLE
static void t_ring_config_validation(uint64_t seed) {
  Dev x(cfg_default(seed));
  auto ring = x.sim.dma_alloc(64 * 1024);
  auto try_enable = [&](const char *what, bool expect_ok) {
    x.wr(SFH_REG_ERR_STATUS, 0x7F);
    x.wr(SFH_REG_CTRL, SFH_CTRL_ENABLE_MASK);
    bool en = x.rd(SFH_REG_STATUS) & SFH_STATUS_ENABLED_MASK;
    bool rc = x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_RING_CONFIG_MASK;
    REQUIRE(en == expect_ok && rc == !expect_ok, "%s: enabled=%d ring_err=%d", what, en, rc);
    x.wr(SFH_REG_CTRL, 0);
  };
  auto win = [&](unsigned i, uint64_t b, uint64_t s, uint32_t c) {
    x.wr(SFH_REG_WIN_BASE_LO(i), (uint32_t)b); x.wr(SFH_REG_WIN_BASE_HI(i), (uint32_t)(b >> 32));
    x.wr(SFH_REG_WIN_SIZE_LO(i), (uint32_t)s); x.wr(SFH_REG_WIN_SIZE_HI(i), (uint32_t)(s >> 32));
    x.wr(SFH_REG_WIN_CTRL(i), c);
  };
  const uint32_t RW = SFH_WIN_CTRL_VALID_MASK | SFH_WIN_CTRL_DEV_READ_MASK | SFH_WIN_CTRL_DEV_WRITE_MASK;
  uint64_t sq = ring.iova, cq = ring.iova + 32768;
  x.wr(SFH_REG_SQ_BASE_LO, (uint32_t)sq); x.wr(SFH_REG_SQ_BASE_HI, (uint32_t)(sq >> 32));
  x.wr(SFH_REG_CQ_BASE_LO, (uint32_t)cq); x.wr(SFH_REG_CQ_BASE_HI, (uint32_t)(cq >> 32));
  x.wr(SFH_REG_SQ_SIZE, 4); x.wr(SFH_REG_CQ_SIZE, 4);
  try_enable("no window", false);
  win(0, ring.iova, ring.size, RW);
  x.wr(SFH_REG_SQ_SIZE, 0); try_enable("SQ size 0", false);
  x.wr(SFH_REG_SQ_SIZE, 13); try_enable("SQ size > max", false);
  x.wr(SFH_REG_SQ_SIZE, 4); x.wr(SFH_REG_CQ_SIZE, 0); try_enable("CQ size 0", false);
  x.wr(SFH_REG_CQ_SIZE, 4);
  win(0, ring.iova, ring.size, SFH_WIN_CTRL_DEV_READ_MASK | SFH_WIN_CTRL_DEV_WRITE_MASK);
  try_enable("window not VALID", false);
  win(0, ring.iova, ring.size, SFH_WIN_CTRL_VALID_MASK | SFH_WIN_CTRL_DEV_READ_MASK);
  try_enable("CQ without DEV_WRITE", false);
  win(0, ring.iova, ring.size, SFH_WIN_CTRL_VALID_MASK | SFH_WIN_CTRL_DEV_WRITE_MASK);
  try_enable("SQ without DEV_READ", false);
  win(0, ring.iova, 4096, RW);
  try_enable("CQ outside window", false);
  win(0, ring.iova, ring.size, RW);
  x.wr(SFH_REG_SQ_SIZE, 10);    // 64 KiB SQ: exceeds the 64 KiB allocation together with CQ & overlaps
  try_enable("SQ overlaps CQ", false);
  x.wr(SFH_REG_SQ_SIZE, 4);
  x.wr(SFH_REG_CQ_BASE_LO, (uint32_t)(sq + 512));
  try_enable("CQ inside SQ", false);
  x.wr(SFH_REG_CQ_BASE_LO, (uint32_t)cq);
  try_enable("valid configuration", true);
  x.no_violations();
}

// 4. single NOP: every CQE field
static void t_nop_basic(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(3, 3);
  sfh_sqe e;
  sfh_sqe_nop(&e, 0);
  sfh_cqe c = x.run(e);
  REQUIRE(SFH_CQE_STATUS(c.dw3) == SFH_STATUS_SUCCESS, "status");
  REQUIRE(SFH_CQE_PHASE(c.dw3) == 1, "phase");
  REQUIRE(SFH_CQE_SQ_HEAD(&c) == 1, "sq_head %u", SFH_CQE_SQ_HEAD(&c));
  REQUIRE(SFH_CQE_OPCODE(&c) == SFH_OP_NOP, "opcode");
  REQUIRE(c.result == 0, "result");
  REQUIRE(x.rd(SFH_REG_SQ_HEAD) == 1 && x.rd(SFH_REG_CQ_TAIL) == 1, "pointers");
  REQUIRE(x.rd(SFH_REG_STATUS) & SFH_STATUS_IDLE_MASK, "idle");
  x.no_violations();
}

// 5. wraparound with every small ring combination, batching, phase tags
static void t_queue_wraparound(uint64_t seed) {
  const unsigned cfgs[][2] = {{1, 1}, {2, 1}, {1, 3}, {3, 2}, {4, 4}, {5, 2}};
  for (auto &qc : cfgs) {
    Dev x(cfg_default(seed));
    x.bringup(qc[0], qc[1]);
    unsigned total = 6 * (1u << std::max(qc[0], qc[1])) + 7, sent = 0, got = 0;
    std::mt19937_64 r(seed);
    while (got < total) {
      unsigned batch = 1 + (unsigned)(r() % 6);
      unsigned pushed = 0;
      while (sent < total && pushed < batch) {
        sfh_sqe e;
        sfh_sqe_nop(&e, 0);
        e.txn_id = 1000 + sent;
        if (sfh_push(&x.d, &e) != SFH_OK) break;
        sent++; pushed++;
      }
      if (pushed) sfh_ring(&x.d);
      sfh_cqe c;
      unsigned drain = 1 + (unsigned)(r() % 4);
      for (unsigned i = 0; i < drain && got < sent; i++) {
        REQUIRE(sfh_wait_cqe(&x.d, &c, TMO) == SFH_OK, "wait");
        REQUIRE(c.txn_id == 1000 + got, "order: got txn %u expected %u (sq%u cq%u)", c.txn_id, 1000 + got, qc[0], qc[1]);
        REQUIRE(SFH_CQE_STATUS(c.dw3) == 0, "status");
        got++;
      }
    }
    REQUIRE(x.rd(SFH_REG_SQ_HEAD) == x.d.sq_tail, "SQ_HEAD %u tail %u", x.rd(SFH_REG_SQ_HEAD), x.d.sq_tail);
    REQUIRE(x.rd(SFH_REG_CQ_TAIL) == x.d.cq_head, "CQ_TAIL");
    REQUIRE(x.rd(SFH_REG_CQ_PHASE) == x.d.cq_phase, "phase");
    x.no_violations();
  }
}

// 6. doorbell validation
static void t_doorbell_validation(uint64_t seed) {
  Dev x(cfg_default(seed));
  // doorbell while disabled
  x.wr(SFH_REG_SQ_TAIL, 1);
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_DOORBELL_MASK, "doorbell while disabled");
  x.wr(SFH_REG_ERR_STATUS, 0x7F);
  x.bringup(3, 3, 64 * 1024, SFH_CTRL_STOP_ON_ERROR_MASK);
  // slot 0 invalid, slots 1..5 NOP; the invalid command halts the queue at head = 1
  sfh_sqe e;
  sfh_sqe_nop(&e, 0);
  e.opcode = 0x7E;
  sfh_push(&x.d, &e);
  for (int i = 0; i < 5; i++) { sfh_sqe_nop(&e, 0); e.txn_id = 10 + i; sfh_push(&x.d, &e); }
  sfh_wmb();
  x.wr(SFH_REG_SQ_TAIL, 8);                          // >= entries
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_DOORBELL_MASK, "tail >= N");
  REQUIRE(x.rd(SFH_REG_ERR_REG_OFFSET) == SFH_REG_SQ_TAIL, "offset");
  x.wr(SFH_REG_ERR_STATUS, 0x7F);
  x.wr(SFH_REG_SQ_TAIL, 0x1005);                     // high bits
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_DOORBELL_MASK, "high bits");
  x.wr(SFH_REG_ERR_STATUS, 0x7F);
  x.wr(SFH_REG_SQ_TAIL, 5);
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) == 0, "valid doorbell");
  for (int i = 0; i < 2000 && !(x.rd(SFH_REG_STATUS) & SFH_STATUS_HALTED_MASK); i++) x.sim.tick(10);
  REQUIRE(x.rd(SFH_REG_STATUS) & SFH_STATUS_HALTED_MASK, "halted after error");
  REQUIRE(x.rd(SFH_REG_SQ_HEAD) == 1, "head 1");
  x.wr(SFH_REG_ERR_STATUS, 0x7F);
  x.wr(SFH_REG_SQ_TAIL, 3);                          // pending entries would shrink 4 -> 2
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_DOORBELL_MASK, "tail moving backwards");
  REQUIRE(x.rd(SFH_REG_SQ_TAIL) == 5, "rejected doorbell must not change tail");
  x.wr(SFH_REG_ERR_STATUS, 0x7F);
  // CQ head beyond the device tail (1 CQE posted)
  x.wr(SFH_REG_CQ_HEAD, 2);
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_DOORBELL_MASK, "CQ head past tail");
  x.wr(SFH_REG_ERR_STATUS, 0x7F);
  sfh_cqe c;
  REQUIRE(sfh_poll_cqe(&x.d, &c) == 1 && SFH_CQE_STATUS(c.dw3) == SFH_STATUS_INVALID_OPCODE, "first CQE");
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) == 0, "driver CQ_HEAD doorbell valid");
  // resume: rewrite ENABLE clears HALTED
  x.wr(SFH_REG_CTRL, SFH_CTRL_ENABLE_MASK | SFH_CTRL_STOP_ON_ERROR_MASK);
  for (int i = 0; i < 4; i++) {                      // slots 1..4 (doorbell was 5)
    REQUIRE(sfh_wait_cqe(&x.d, &c, TMO) == SFH_OK, "resume");
    REQUIRE(c.txn_id == 10u + i && SFH_CQE_STATUS(c.dw3) == 0, "resumed order");
  }
  sfh_ring(&x.d);                                    // slot 5
  REQUIRE(sfh_wait_cqe(&x.d, &c, TMO) == SFH_OK && c.txn_id == 14, "last entry");
  x.no_violations();
}

// 7. DMA data integrity, random sizes/offsets, both regions, checked by an independent fabric master
static void t_dma_integrity(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(4, 4, 512 * 1024);
  std::mt19937_64 r(seed * 7 + 1);
  uint8_t *h = x.pool.va;
  for (int it = 0; it < 40; it++) {
    bool tspm = r() & 1;
    uint32_t rbase = x.d.devmem_base[tspm], rsize = x.d.devmem_size[tspm];
    uint32_t len = 8 * (1 + (uint32_t)(r() % (std::min<uint32_t>(rsize, 6000) / 8)));
    uint32_t doff = 8 * (uint32_t)(r() % ((rsize - len) / 8 + 1));
    uint32_t hs = 8 * (uint32_t)(r() % ((x.pool.size / 2 - len) / 8));
    uint32_t hd = (uint32_t)x.pool.size / 2 + 8 * (uint32_t)(r() % ((x.pool.size / 2 - len) / 8));
    fill_rand(r, h + hs, len);
    memset(h + hd, 0xEE, len);
    REQUIRE(sfh_dma_h2d(&x.d, x.pool.iova + hs, rbase + doff, len, TMO) == 0, "h2d");
    for (uint32_t w = 0; w < len; w += 4 * (1 + (uint32_t)(r() % 7))) {   // independent check via fabric M1
      uint32_t v = x.sim.fabric_read32(rbase + doff + w), exp;
      memcpy(&exp, h + hs + w, 4);
      REQUIRE(v == exp, "device word %08x: %08x != %08x", rbase + doff + w, v, exp);
    }
    REQUIRE(sfh_dma_d2h(&x.d, rbase + doff, x.pool.iova + hd, len, TMO) == 0, "d2h");
    REQUIRE(memcmp(h + hs, h + hd, len) == 0, "round trip mismatch len %u", len);
  }
  x.no_violations();
}

// 8. maximum transfers: whole SRAM and whole TSPM, host buffer misaligned to 4 KiB (boundary splits)
static void t_dma_full_regions(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(2, 2, 160 * 1024);
  std::mt19937_64 r(seed);
  for (int reg = 0; reg < 2; reg++) {
    uint32_t len = x.d.devmem_size[reg];
    uint8_t *src = x.pool.va + 4096 - 8, *dst = x.pool.va + 81920 + 4096 - 24;
    fill_rand(r, src, len);
    uint64_t bursts0 = x.sim.host_bursts;
    sfh_sqe e;
    sfh_sqe_dma(&e, SFH_DMA_DIR_H2D, x.pool.iova + 4096 - 8, x.d.devmem_base[reg], len, 0);
    sfh_cqe c = x.run(e);
    REQUIRE(SFH_CQE_STATUS(c.dw3) == 0 && c.result == len, "h2d full: st %u res %u", SFH_CQE_STATUS(c.dw3), c.result);
    sfh_sqe_dma(&e, SFH_DMA_DIR_D2H, x.d.devmem_base[reg], x.pool.iova + 81920 + 4096 - 24, len, 0);
    c = x.run(e);
    REQUIRE(SFH_CQE_STATUS(c.dw3) == 0 && c.result == len, "d2h full");
    REQUIRE(memcmp(src, dst, len) == 0, "full-region mismatch");
    // chunks <= 128 B, plus SQ fetch and CQ writes: lower bound on burst count
    REQUIRE(x.sim.host_bursts - bursts0 >= 2 * len / 128, "chunking");
  }
  x.no_violations();
}

// 9. invalid descriptors: correct status, nothing executed, nothing touched
static void t_invalid_descriptors(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(3, 3, 64 * 1024);
  std::mt19937_64 r(seed);
  fill_rand(r, x.pool.va, x.pool.size);
  std::vector<uint8_t> snap(x.pool.va, x.pool.va + x.pool.size);
  const uint32_t canary = 0xC0FFEE00;
  for (uint32_t a : {0x10000000u, 0x1000FFF8u, 0x20000000u, 0x20003FF8u}) x.sim.fabric_write32(a, canary ^ a);
  uint64_t P = x.pool.iova, PE = x.pool.iova + x.pool.size;
  const uint32_t S = 0x10000000, T = 0x20000000;
  struct Case { const char *name; std::function<void(sfh_sqe &)> mk; uint16_t st; };
  std::vector<Case> cases = {
      {"opcode 0x7F", [](sfh_sqe &e) { sfh_sqe_nop(&e, 0); e.opcode = 0x7F; }, SFH_STATUS_INVALID_OPCODE},
      {"reserved VECTOR opcode", [](sfh_sqe &e) { sfh_sqe_nop(&e, 0); e.opcode = 0x03; }, SFH_STATUS_INVALID_OPCODE},
      {"unknown flag", [](sfh_sqe &e) { sfh_sqe_nop(&e, 0x80); }, SFH_STATUS_INVALID_FIELD},
      {"rsvd0", [](sfh_sqe &e) { sfh_sqe_nop(&e, 0); e.rsvd0 = 1; }, SFH_STATUS_INVALID_FIELD},
      {"NOP payload", [](sfh_sqe &e) { sfh_sqe_nop(&e, 0); e.u.dw[3] = 1; }, SFH_STATUS_INVALID_FIELD},
      {"NOP dir", [](sfh_sqe &e) { sfh_sqe_nop(&e, 0); e.dir = 1; }, SFH_STATUS_INVALID_FIELD},
      {"DMA dir 0", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 0, P, S, 64, 0); }, SFH_STATUS_INVALID_FIELD},
      {"DMA dir 3", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 3, P, S, 64, 0); }, SFH_STATUS_INVALID_FIELD},
      {"DMA reserved dword", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P, S, 64, 0); e.u.dma.rsvd[4] = 1; }, SFH_STATUS_INVALID_FIELD},
      {"H2D dst above 4 GiB", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P, (1ull << 32) | S, 64, 0); }, SFH_STATUS_INVALID_FIELD},
      {"D2H src above 4 GiB", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 2, (1ull << 32) | S, P, 64, 0); }, SFH_STATUS_INVALID_FIELD},
      {"length 0", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P, S, 0, 0); }, SFH_STATUS_INVALID_LENGTH},
      {"length > max", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P, S, (1u << 20) + 8, 0); }, SFH_STATUS_INVALID_LENGTH},
      {"length 0xFFFFFFF8", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P, S, 0xFFFFFFF8u, 0); }, SFH_STATUS_INVALID_LENGTH},
      {"src misaligned", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P + 4, S, 64, 0); }, SFH_STATUS_MISALIGNED},
      {"dst misaligned", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P, S + 4, 64, 0); }, SFH_STATUS_MISALIGNED},
      {"length misaligned", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P, S, 12, 0); }, SFH_STATUS_MISALIGNED},
      {"H2D src outside windows", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, PE + 4096, S, 64, 0); }, SFH_STATUS_HOST_ADDR_DENIED},
      {"H2D straddles window end", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, PE - 8, S, 16, 0); }, SFH_STATUS_HOST_ADDR_DENIED},
      {"D2H into SQ ring (read-only window)", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 2, S, x.d.sq.iova, 64, 0); }, SFH_STATUS_HOST_ADDR_DENIED},
      {"H2D from CQ ring (write-only window)", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, x.d.cq.iova, S, 64, 0); }, SFH_STATUS_HOST_ADDR_DENIED},
      {"H2D 64-bit wrap", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, 0xFFFFFFFFFFFFFFF8ull, S, 16, 0); }, SFH_STATUS_HOST_ADDR_DENIED},
      {"H2D host addr 0", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, 0, S, 64, 0); }, SFH_STATUS_HOST_ADDR_DENIED},
      {"dev addr 0", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P, 0, 64, 0); }, SFH_STATUS_DEV_ADDR_INVALID},
      {"dev straddles SRAM end", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P, S + 0xFFF8, 16, 0); }, SFH_STATUS_DEV_ADDR_INVALID},
      {"dev straddles TSPM end", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 2, T + 0x3FF8, P, 16, 0); }, SFH_STATUS_DEV_ADDR_INVALID},
      {"dev 32-bit wrap", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P, 0xFFFFFFF8u, 16, 0); }, SFH_STATUS_DEV_ADDR_INVALID},
      {"dev gap between regions", [&](sfh_sqe &e) { sfh_sqe_dma(&e, 1, P, 0x18000000u, 64, 0); }, SFH_STATUS_DEV_ADDR_INVALID},
      {"GEMM dir", [](sfh_sqe &e) { sfh_sqe_gemm(&e, 0, 0x100, 0x200, 4, 0, 0); e.dir = 2; }, SFH_STATUS_INVALID_FIELD},
      {"GEMM unknown te flag", [](sfh_sqe &e) { sfh_sqe_gemm(&e, 0, 0x100, 0x200, 4, 0x20, 0); }, SFH_STATUS_INVALID_FIELD},
      {"GEMM reserved dword", [](sfh_sqe &e) { sfh_sqe_gemm(&e, 0, 0x100, 0x200, 4, 0, 0); e.u.gemm.rsvd[2] = 9; }, SFH_STATUS_INVALID_FIELD},
  };
  unsigned idx = 0;
  for (auto &k : cases) {
    sfh_sqe e;
    k.mk(e);
    x.wr(SFH_REG_ERR_STATUS, 0x7F);
    sfh_cqe c = x.run(e);
    REQUIRE(SFH_CQE_STATUS(c.dw3) == k.st, "%s: status %s expected %s", k.name, sfh_status_str(SFH_CQE_STATUS(c.dw3)),
            sfh_status_str(k.st));
    REQUIRE(c.result == 0, "%s: result %u", k.name, c.result);
    REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_CMD_ERROR_MASK, "%s: CMD_ERROR", k.name);
    uint32_t ec = x.rd(SFH_REG_ERR_CMD);
    REQUIRE((ec & 0xFFFF) == k.st && (ec >> 16) == (idx & 7u), "%s: ERR_CMD %08x", k.name, ec);
    idx++;
  }
  REQUIRE(x.sim.faults.empty(), "no IOMMU access may happen for rejected commands (%zu faults)", x.sim.faults.size());
  REQUIRE(memcmp(snap.data(), x.pool.va, x.pool.size) == 0, "host memory modified by a rejected command");
  for (uint32_t a : {0x10000000u, 0x1000FFF8u, 0x20000000u, 0x20003FF8u})
    REQUIRE(x.sim.fabric_read32(a) == (canary ^ a), "device memory modified at %08x", a);
  x.no_violations();
}

// 9b. a window at the very top of the 64-bit space: wrap-around must not alias
static void t_window_overflow(uint64_t seed) {
  Dev x(cfg_default(seed));
  REQUIRE(sfh_queues_alloc(&x.d, 2, 2) == SFH_OK, "q");
  // the window itself extends past 2^64 (base + size = 2^64 + 4 KiB): only the
  // explicit "range end <= 2^64" rule can reject a wrapping range here
  REQUIRE(sfh_set_window(&x.d, 3, 0xFFFFFFFFFFFFF000ull, 0x2000,
                         SFH_WIN_CTRL_VALID_MASK | SFH_WIN_CTRL_DEV_READ_MASK | SFH_WIN_CTRL_DEV_WRITE_MASK) == 0, "w3");
  REQUIRE(sfh_enable(&x.d, 0) == SFH_OK, "en");
  sfh_sqe e;
  sfh_sqe_dma(&e, 1, 0xFFFFFFFFFFFFFFF8ull, 0x10000000, 16, 0);     // end wraps to 8
  REQUIRE(x.run_st(e) == SFH_STATUS_HOST_ADDR_DENIED, "wrap past 2^64");
  sfh_sqe_dma(&e, 1, 0xFFFFFFFFFFFFF000ull, 0x10000000, 0x1000, 0);  // exactly the window: allowed (IOMMU faults it)
  REQUIRE(x.run_st(e) == SFH_STATUS_HOST_BUS_ERROR, "inside top window -> reaches IOMMU, faults");
  REQUIRE(!x.sim.faults.empty(), "IOMMU fault recorded");
  x.no_violations();
}

// 10. random host back-pressure and latency on every AXI channel
static void t_host_backpressure(uint64_t seed) {
  SimCfg c = cfg_default(seed);
  std::mt19937_64 r(seed * 31);
  c.ar_ready_pct = 10 + (int)(r() % 60); c.aw_ready_pct = 10 + (int)(r() % 60);
  c.w_ready_pct = 10 + (int)(r() % 60); c.r_valid_pct = 10 + (int)(r() % 60);
  c.b_valid_pct = 10 + (int)(r() % 60); c.rd_latency = 40 + (int)(r() % 200); c.wr_latency = (int)(r() % 100);
  c.irq_ready_pct = 30;
  Dev x(c);
  x.bringup(3, 2, 128 * 1024, 0, 1);
  uint8_t *h = x.pool.va;
  for (int it = 0; it < 12; it++) {
    uint32_t len = 8 * (1 + (uint32_t)(r() % 700));
    uint32_t hs = 8 * (uint32_t)(r() % 4000), hd = 65536 + 8 * (uint32_t)(r() % 4000);
    uint32_t dev = 0x10000000 + 8 * (uint32_t)(r() % ((65536 - len) / 8));
    fill_rand(r, h + hs, len);
    REQUIRE(sfh_dma_h2d(&x.d, x.pool.iova + hs, dev, len, TMO) == 0, "h2d");
    REQUIRE(sfh_dma_d2h(&x.d, dev, x.pool.iova + hd, len, TMO) == 0, "d2h");
    REQUIRE(memcmp(h + hs, h + hd, len) == 0, "mismatch under back-pressure");
  }
  sfh_perf_snapshot(&x.d);
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_HOST_WAIT_CYCLES) > 1000, "host wait cycles");
  x.no_violations();
}

// 11. completion-queue full: device stalls, then resumes in order
static void t_cq_full_backpressure(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(4, 2);                                   // SQ 16, CQ 4 (3 usable)
  for (int i = 0; i < 10; i++) { sfh_sqe e; sfh_sqe_nop(&e, 0); e.txn_id = 500 + i; REQUIRE(sfh_push(&x.d, &e) == 0, "push"); }
  sfh_ring(&x.d);
  x.sim.tick(3000);
  uint32_t st = x.rd(SFH_REG_STATUS);
  REQUIRE(st & SFH_STATUS_CQ_FULL_MASK, "CQ_FULL %08x", st);
  REQUIRE(x.rd(SFH_REG_CQ_TAIL) == 3 && x.rd(SFH_REG_SQ_HEAD) == 4, "stalled at the 4th command");
  for (int i = 0; i < 10; i++) {
    sfh_cqe c;
    REQUIRE(sfh_wait_cqe(&x.d, &c, TMO) == 0 && c.txn_id == 500u + i, "order after stall");
  }
  sfh_perf_snapshot(&x.d);
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_CQ_FULL_CYCLES) > 2000, "CQ_FULL_CYCLES");
  x.no_violations();
}

// 12. interrupts: flag, masking, unmask-while-pending, W1C, vectors, level, endpoint back-pressure, ordering
static void t_interrupts(uint64_t seed) {
  SimCfg c = cfg_default(seed);
  c.post_delay_min = c.post_delay_max = 60;          // writes visible late: MSI must still follow the CQE
  Dev x(c);
  x.bringup(3, 3, 64 * 1024, 0, 1);                  // INT_ENABLE = CQ|ERROR, CQ->0, ERR->1
  sfh_sqe e;
  sfh_cqe cq;
  auto cqe_visible = [&]() {
    volatile sfh_cqe *p = (volatile sfh_cqe *)((uint8_t *)x.d.cq.va + x.d.cq_head * 16);
    return SFH_CQE_PHASE(p->dw3) == x.d.cq_phase;
  };
  // (a) no IRQ flag, success: no interrupt (driver in polling mode so it does not add the flag)
  uint64_t m0 = x.sim.irq_msgs;
  sfh_sqe_nop(&e, 0);
  x.d.use_irq = 0;
  x.run(e);
  x.d.use_irq = 1;
  x.sim.tick(200);
  REQUIRE(x.sim.irq_msgs == m0 && !(x.rd(SFH_REG_INT_STATUS) & 1), "no interrupt without IRQ flag");
  // (b) IRQ flag: message on vector 0, CQE visible when it arrives
  sfh_sqe_nop(&e, SFH_SQE_FLAG_IRQ);
  e.txn_id = 77;
  sfh_submit(&x.d, &e);
  uint32_t f = 0;
  REQUIRE(x.sim.wait_irq(0x3, TMO, &f) == 0 && f == 1, "vector 0 message (fired %x)", f);
  REQUIRE(cqe_visible(), "MSI overtook its completion entry");
  REQUIRE(x.rd(SFH_REG_INT_STATUS) & SFH_INT_STATUS_CQ_MASK, "status");
  REQUIRE(x.sim.irq_level(), "level");
  x.wr(SFH_REG_INT_STATUS, SFH_INT_STATUS_CQ_MASK);
  REQUIRE(!(x.rd(SFH_REG_INT_STATUS) & 1) && !x.sim.irq_level(), "W1C clears");
  REQUIRE(sfh_poll_cqe(&x.d, &cq) == 1 && cq.txn_id == 77, "cqe");
  // (c) masked: status latches, no message; unmask -> message immediately
  x.wr(SFH_REG_INT_ENABLE, SFH_INT_ENABLE_ERROR_MASK);
  m0 = x.sim.irq_msgs;
  sfh_sqe_nop(&e, SFH_SQE_FLAG_IRQ);
  x.run(e);
  x.sim.tick(200);
  REQUIRE(x.sim.irq_msgs == m0, "masked source sent a message");
  REQUIRE(x.rd(SFH_REG_INT_STATUS) & 1, "masked source must still latch");
  REQUIRE(!x.sim.irq_level(), "masked level");
  x.wr(SFH_REG_INT_ENABLE, 3);
  REQUIRE(x.sim.wait_irq(1, 100, &f) == 0, "unmask with pending status must send a message");
  x.wr(SFH_REG_INT_STATUS, 3);
  // (d) failed command interrupts even without the IRQ flag
  sfh_sqe_nop(&e, 0);
  e.opcode = 0x55;
  sfh_submit(&x.d, &e);
  REQUIRE(x.sim.wait_irq(1, TMO, &f) == 0, "error completion interrupt");
  REQUIRE(sfh_poll_cqe(&x.d, &cq) == 1 && SFH_CQE_STATUS(cq.dw3) == SFH_STATUS_INVALID_OPCODE, "cqe");
  x.wr(SFH_REG_INT_STATUS, 3);
  // (e) device error -> ERROR source on vector 1
  x.wr(SFH_REG_ID, 0);
  REQUIRE(x.sim.wait_irq(2, 100, &f) == 0 && f == 2, "error vector");
  REQUIRE(x.rd(SFH_REG_INT_STATUS) & SFH_INT_STATUS_ERROR_MASK, "error status");
  x.wr(SFH_REG_INT_STATUS, 3);
  x.wr(SFH_REG_ERR_STATUS, 0x7F);
  // (f) single-vector configuration
  x.wr(SFH_REG_INT_VECTOR, 0);
  x.wr(SFH_REG_INT_TEST, SFH_INT_TEST_ERROR_MASK);
  REQUIRE(x.sim.wait_irq(3, 100, &f) == 0 && f == 1, "ERROR on vector 0 in single-vector mode");
  x.wr(SFH_REG_INT_STATUS, 3);
  x.wr(SFH_REG_INT_VECTOR, 0x100);
  // (g) endpoint not accepting messages: request held, events coalesce, delivered later
  x.sim.irq_ready_override = 0;
  m0 = x.sim.irq_msgs;
  for (int i = 0; i < 5; i++) { sfh_sqe_nop(&e, SFH_SQE_FLAG_IRQ); x.run(e); }
  x.sim.tick(500);
  REQUIRE(x.sim.irq_msgs == m0 && x.sim.top->irq_valid, "message must wait for the endpoint");
  x.sim.irq_ready_override = 1;
  x.sim.tick(200);
  REQUIRE(x.sim.irq_msgs - m0 >= 1 && x.sim.irq_msgs - m0 <= 2, "coalesced: %llu messages",
          (unsigned long long)(x.sim.irq_msgs - m0));
  x.sim.irq_ready_override = -1;
  // (h) INT_TEST
  x.sim.irq_pending = 0;
  x.wr(SFH_REG_INT_STATUS, 3);
  x.wr(SFH_REG_INT_TEST, SFH_INT_TEST_CQ_MASK);
  REQUIRE(x.sim.wait_irq(1, 100, &f) == 0, "INT_TEST");
  sfh_perf_snapshot(&x.d);
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_IRQ_MSGS) == x.sim.irq_msgs, "IRQ_MSGS counter %llu vs %llu",
          (unsigned long long)sfh_perf_read(&x.d, SFH_PERF_IRQ_MSGS), (unsigned long long)x.sim.irq_msgs);
  x.no_violations();
}

// 13. interrupt-driven completion path of the driver (no busy polling)
static void t_irq_driven_completion(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(3, 3, 64 * 1024, 0, 1);
  std::mt19937_64 r(seed);
  for (int i = 0; i < 30; i++) {
    sfh_sqe e;
    if (i % 3 == 0) sfh_sqe_nop(&e, SFH_SQE_FLAG_IRQ);
    else if (i & 1) sfh_sqe_dma(&e, SFH_DMA_DIR_D2H, 0x10000000, x.pool.iova + 8192, 256, SFH_SQE_FLAG_IRQ);
    else sfh_sqe_dma(&e, SFH_DMA_DIR_H2D, x.pool.iova, 0x10000000, 256, SFH_SQE_FLAG_IRQ);
    sfh_cqe c = x.run(e);
    REQUIRE(SFH_CQE_STATUS(c.dw3) == 0, "status");
  }
  REQUIRE(x.d.irq_waits >= 30, "driver must have slept on interrupts (%llu)", (unsigned long long)x.d.irq_waits);
  REQUIRE(x.d.polls < 200, "few polls with interrupts (%llu)", (unsigned long long)x.d.polls);
  x.no_violations();
}

// 14. definition of done: host data -> device -> tensor engine -> host, bit exact
static void gemm_once(Dev &x, std::mt19937_64 &r, unsigned K, bool au, bool bu, bool acc, int32_t *accum) {
  uint8_t *A = x.pool.va, *B = x.pool.va + 8192, *C = x.pool.va + 16384;
  uint32_t ab = (4 * K + 7) & ~7u;
  fill_rand(r, A, ab);
  fill_rand(r, B, ab);
  memset(C, 0xA5, 64);
  const uint32_t TS = x.d.devmem_base[1];
  REQUIRE(sfh_dma_h2d(&x.d, x.pool.iova, TS + 0x0000, ab, TMO) == 0, "A h2d");
  REQUIRE(sfh_dma_h2d(&x.d, x.pool.iova + 8192, TS + 0x1000, ab, TMO) == 0, "B h2d");
  sfh_sqe e;
  sfh_sqe_gemm(&e, 0x0000, 0x1000, 0x3000, K,
               (acc ? SFH_GEMM_FLAG_ACC : 0) | (au ? SFH_GEMM_FLAG_A_UNSIGNED : 0) | (bu ? SFH_GEMM_FLAG_B_UNSIGNED : 0), 0);
  sfh_cqe c = x.run(e);
  REQUIRE(SFH_CQE_STATUS(c.dw3) == 0, "gemm status %s", sfh_status_str(SFH_CQE_STATUS(c.dw3)));
  REQUIRE(c.result == 3 + 2 * K + 4, "engine cycles %u != 3+2K+4 (K=%u)", c.result, K);
  REQUIRE(sfh_dma_d2h(&x.d, TS + 0x3000, x.pool.iova + 16384, 64, TMO) == 0, "C d2h");
  int32_t ref[16];
  ref_gemm(A, B, K, au, bu, ref);
  for (int i = 0; i < 16; i++) {
    accum[i] = acc ? accum[i] + ref[i] : ref[i];
    int32_t got;
    memcpy(&got, C + 4 * i, 4);
    REQUIRE(got == accum[i], "C[%d][%d] = %d expected %d (K=%u au=%d bu=%d acc=%d)", i / 4, i % 4, got, accum[i], K, au,
            bu, acc);
  }
}
static void t_gemm_end_to_end(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(3, 3, 64 * 1024);
  std::mt19937_64 r(seed);
  int32_t acc[16];
  for (unsigned K : {1u, 2u, 7u, 16u, 64u, 255u, 1024u}) gemm_once(x, r, K, false, false, false, acc);
  gemm_once(x, r, 16, true, false, false, acc);
  gemm_once(x, r, 16, false, true, false, acc);
  gemm_once(x, r, 16, true, true, false, acc);
  gemm_once(x, r, 32, false, false, false, acc);      // K-split accumulation across commands
  gemm_once(x, r, 32, false, false, true, acc);
  gemm_once(x, r, 9, false, false, true, acc);
  x.no_violations();
}

// 15. engine parameter errors come back as ENGINE_ERROR + engine code
static void t_gemm_engine_error(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(2, 2);
  struct { uint32_t a, b, c, k, code; } cs[] = {
      {0, 0x100, 0x200, 0, 2}, {0, 0x100, 0x200, 2000, 2}, {2, 0x100, 0x200, 4, 1}, {0, 0x100, 0x208, 4, 1},
      {0, 0x100, 0x3FF0, 4, 2}, {0x3FF0, 0x100, 0x200, 64, 2}};
  for (auto &k : cs) {
    sfh_sqe e;
    sfh_sqe_gemm(&e, k.a, k.b, k.c, k.k, 0, 0);
    sfh_cqe c = x.run(e);
    REQUIRE(SFH_CQE_STATUS(c.dw3) == SFH_STATUS_ENGINE_ERROR && c.result == k.code, "a=%x c=%x k=%u: st %s res %u",
            k.a, k.c, k.k, sfh_status_str(SFH_CQE_STATUS(c.dw3)), c.result);
  }
  x.no_violations();
}

// 16. engine watchdog: ENGINE_TIMEOUT, tile reset, recovery without device reset
static void t_engine_timeout(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(2, 2, 64 * 1024, 0, 1);
  x.wr(SFH_REG_TIMEOUT, 300);
  sfh_sqe e;
  sfh_sqe_gemm(&e, 0, 0x1000, 0x3000, 1024, 0, 0);
  sfh_cqe c = x.run(e);
  REQUIRE(SFH_CQE_STATUS(c.dw3) == SFH_STATUS_ENGINE_TIMEOUT, "status %s", sfh_status_str(SFH_CQE_STATUS(c.dw3)));
  REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_ENGINE_TIMEOUT_MASK, "ERR_STATUS.ENGINE_TIMEOUT");
  REQUIRE(x.rd(SFH_REG_INT_STATUS) & SFH_INT_STATUS_ERROR_MASK, "ERROR interrupt source");
  REQUIRE(!(x.rd(SFH_REG_STATUS) & SFH_STATUS_FATAL_MASK), "not fatal");
  x.wr(SFH_REG_TIMEOUT, SFH_REFCFG_TIMEOUT_RESET);
  std::mt19937_64 r(seed);
  int32_t acc[16];
  gemm_once(x, r, 12, false, false, false, acc);      // engine recovered
  x.no_violations();
}

// 17. data-path host-bus errors fail the command only
static void t_data_bus_errors(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(3, 3, 64 * 1024);
  fill_rand(x.sim.rng, x.pool.va, 4096);
  // read error on the 3rd 128-byte chunk of an H2D
  x.sim.inject_error(x.pool.iova + 256, x.pool.iova + 264, false, 1, 2);
  sfh_sqe e;
  sfh_sqe_dma(&e, 1, x.pool.iova, 0x10000000, 1024, 0);
  sfh_cqe c = x.run(e);
  REQUIRE(SFH_CQE_STATUS(c.dw3) == SFH_STATUS_HOST_BUS_ERROR && c.result == 256, "h2d err: %s res %u",
          sfh_status_str(SFH_CQE_STATUS(c.dw3)), c.result);
  REQUIRE(x.rd(SFH_REG_ERR_ADDR_LO) == (uint32_t)(x.pool.iova + 256), "ERR_ADDR");
  // write error on D2H
  x.sim.inject_error(x.pool.iova + 8192, x.pool.iova + 8200, true, 1, 2);
  sfh_sqe_dma(&e, 2, 0x10000000, x.pool.iova + 8192 - 128, 512, 0);
  c = x.run(e);
  REQUIRE(SFH_CQE_STATUS(c.dw3) == SFH_STATUS_HOST_BUS_ERROR && c.result == 128, "d2h err res %u", c.result);
  // IOMMU fault: page inside the device window but unmapped by the OS
  x.sim.iommu_unmap_page(x.pool.iova + 12288);
  sfh_sqe_dma(&e, 1, x.pool.iova + 12288, 0x10000000, 64, 0);
  c = x.run(e);
  REQUIRE(SFH_CQE_STATUS(c.dw3) == SFH_STATUS_HOST_BUS_ERROR, "iommu fault");
  REQUIRE(x.sim.faults.size() == 1 && x.sim.faults[0].iova == x.pool.iova + 12288, "fault logged");
  REQUIRE(!(x.rd(SFH_REG_STATUS) & SFH_STATUS_FATAL_MASK), "data errors are not fatal");
  sfh_sqe_dma(&e, 1, x.pool.iova, 0x10000000, 1024, 0);
  REQUIRE(x.run_st(e) == 0, "device keeps working");
  x.no_violations();
}

// 18. queue-memory errors are fatal; CTRL.RESET recovers
static void t_fatal_queue_errors(uint64_t seed) {
  for (int which = 0; which < 3; which++) {         // 0: SQ fetch, 1: CQ write, 2: flush read
    Dev x(cfg_default(seed));
    x.bringup(3, 3, 64 * 1024, which == 2 ? SFH_CTRL_FLUSH_ALL_MASK : 0, 1);
    sfh_sqe e;
    sfh_sqe_nop(&e, 0);
    x.run(e);
    uint64_t addr = which == 1 ? x.d.cq.iova + 16 : x.d.sq.iova + 64;
    x.sim.inject_error(addr, addr + 8, which == 1, 1, 2);
    sfh_submit(&x.d, &e);
    uint32_t f;
    REQUIRE(x.sim.wait_irq(2, TMO, &f) == 0, "ERROR interrupt (case %d)", which);
    uint32_t st = x.rd(SFH_REG_STATUS);
    REQUIRE((st & SFH_STATUS_FATAL_MASK) && (st & SFH_STATUS_IDLE_MASK), "fatal+idle %08x", st);
    REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_HOST_BUS_MASK, "HOST_BUS");
    REQUIRE(x.rd(SFH_REG_ERR_ADDR_LO) == (uint32_t)addr, "ERR_ADDR %08x", x.rd(SFH_REG_ERR_ADDR_LO));
    sfh_cqe c;
    x.sim.tick(500);
    REQUIRE(sfh_poll_cqe(&x.d, &c) == 0, "no completion after a fatal error");
    REQUIRE(sfh_reset(&x.d, TMO) == SFH_OK, "reset");
    for (unsigned i = 0; i < SFH_REGTABLE_N; i++) {
      const sfh_regdesc &r = sfh_regtable[i];
      if (r.off >= SFH_PERF_BASE) continue;
      REQUIRE(x.rd(r.off) == r.reset, "%s after reset: %08x", r.name, x.rd(r.off));
    }
    sfh_queues_free(&x.d);
    x.sim.clear_errors();
    x.bringup(3, 3);
    REQUIRE(x.run_st(e) == 0, "works after reset");
    x.no_violations();
  }
}

// 19. host-bus timeout (host stops answering): FATAL; reset drains; endpoint reset if it never answers
static void t_host_timeout(uint64_t seed) {
  {
    Dev x(cfg_default(seed));
    x.bringup(3, 3, 64 * 1024, 0, 1);
    x.wr(SFH_REG_TIMEOUT, 2000);
    sfh_sqe e;
    sfh_sqe_dma(&e, 1, x.pool.iova, 0x10000000, 4096, 0);
    x.sim.stall_host = true;
    sfh_submit(&x.d, &e);
    uint32_t f;
    REQUIRE(x.sim.wait_irq(2, TMO, &f) == 0, "ERROR interrupt on timeout");
    uint32_t st = x.rd(SFH_REG_STATUS);
    REQUIRE((st & SFH_STATUS_FATAL_MASK) && !(st & SFH_STATUS_IDLE_MASK), "fatal, transaction outstanding %08x", st);
    REQUIRE(x.rd(SFH_REG_ERR_STATUS) & SFH_ERR_STATUS_HOST_TIMEOUT_MASK, "HOST_TIMEOUT");
    x.wr(SFH_REG_CTRL, SFH_CTRL_RESET_MASK);
    x.sim.tick(3000);
    REQUIRE(x.rd(SFH_REG_STATUS) & SFH_STATUS_RESETTING_MASK, "reset waits for the outstanding transaction");
    x.sim.stall_host = false;                        // late answer arrives
    REQUIRE(sfh_reset(&x.d, TMO) == SFH_OK, "reset completes after drain");
    REQUIRE(x.rd(SFH_REG_STATUS) == 0x2, "clean status");
    sfh_queues_free(&x.d);
    x.bringup(3, 3);
    sfh_sqe_dma(&e, 1, x.pool.iova, 0x10000000, 4096, 0);
    REQUIRE(x.run_st(e) == 0, "works after recovery");
    x.no_violations();
  }
  {
    Dev x(cfg_default(seed));
    x.bringup(3, 3);
    x.wr(SFH_REG_TIMEOUT, 1000);
    sfh_sqe e;
    sfh_sqe_nop(&e, 0);
    x.sim.stall_host = true;
    sfh_submit(&x.d, &e);
    x.sim.tick(3000);
    x.wr(SFH_REG_CTRL, SFH_CTRL_RESET_MASK);
    x.sim.tick(3000);
    REQUIRE(x.rd(SFH_REG_STATUS) & SFH_STATUS_RESETTING_MASK, "stuck in reset while host never answers");
    x.sim.ep_reset();                                // hot reset / FLR through the endpoint
    x.sim.stall_host = false;
    REQUIRE(x.rd(SFH_REG_ID) == SFH_DEVICE_MAGIC && x.rd(SFH_REG_STATUS) == 0x2, "endpoint reset recovers");
    REQUIRE(sfh_open(&x.d, sfh_sim_backend_ops(), &x.sim) == 0, "reopen");
    x.bringup(3, 3);
    REQUIRE(x.run_st(e) == 0, "works after endpoint reset");
    x.no_violations();
  }
}

// 20. soft reset during activity: in-flight bus transaction drains, nothing reaches the host afterwards
static void t_reset_during_activity(uint64_t seed) {
  std::mt19937_64 r(seed);
  for (int trial = 0; trial < 6; trial++) {
    SimCfg c = cfg_default(seed + trial);
    c.ar_ready_pct = 50; c.r_valid_pct = 60; c.b_valid_pct = 60;
    Dev x(c);
    x.bringup(3, 3, 192 * 1024);
    sfh_sqe e;
    sfh_sqe_dma(&e, 1, x.pool.iova, 0x10000000, 65536, 0); sfh_push(&x.d, &e);
    sfh_sqe_dma(&e, 2, 0x10000000, x.pool.iova + 65536, 65536, 0); sfh_push(&x.d, &e);
    sfh_sqe_gemm(&e, 0, 0x1000, 0x3000, 1024, 0, 0); sfh_push(&x.d, &e);
    sfh_sqe_dma(&e, 2, 0x20000000, x.pool.iova + 131072, 16384, 0); sfh_push(&x.d, &e);
    sfh_ring(&x.d);
    x.sim.tick(100 + (unsigned)(r() % 60000));
    x.wr(SFH_REG_CTRL, SFH_CTRL_RESET_MASK);
    REQUIRE(sfh_reset(&x.d, TMO) == SFH_OK, "reset trial %d", trial);
    for (unsigned i = 0; i < SFH_REGTABLE_N; i++) {
      const sfh_regdesc &rr = sfh_regtable[i];
      if (rr.off >= SFH_PERF_BASE) continue;
      REQUIRE(x.rd(rr.off) == rr.reset, "%s after reset: %08x", rr.name, x.rd(rr.off));
    }
    uint64_t wb = x.sim.host_wr_beats, rb = x.sim.host_rd_beats;
    x.sim.tick(5000);
    REQUIRE(x.sim.host_wr_beats == wb && x.sim.host_rd_beats == rb, "host traffic after reset completed");
    sfh_queues_free(&x.d);
    x.sim.dma_free(x.pool);
    x.bringup(2, 2);
    sfh_sqe_nop(&e, 0);
    REQUIRE(x.run_st(e) == 0, "usable after reset");
    x.no_violations();
  }
}

// 20b. reset while the flush read is outstanding: the command must not complete
static void t_reset_in_flush(uint64_t seed) {
  SimCfg c = cfg_default(seed);
  c.rd_latency = 3000;                               // park the engine in FLUSH for a long time
  Dev x(c);
  x.bringup(2, 2, 64 * 1024, SFH_CTRL_FLUSH_ALL_MASK);
  sfh_sqe e;
  sfh_sqe_nop(&e, 0);
  sfh_submit(&x.d, &e);
  int i;
  for (i = 0; i < 100000; i++) {
    if (((x.rd(SFH_REG_STATUS) & SFH_STATUS_STATE_MASK) >> SFH_STATUS_STATE_SHIFT) == 11) break;   // E_FLUSH
    x.sim.tick(5);
  }
  REQUIRE(i < 100000, "engine never reached the flush state");
  uint64_t wb = x.sim.host_wr_beats;
  x.wr(SFH_REG_CTRL, SFH_CTRL_RESET_MASK);
  for (i = 0; i < 100000; i++) {
    uint32_t st = x.rd(SFH_REG_STATUS);
    if (!(st & SFH_STATUS_RESETTING_MASK) && (st & SFH_STATUS_IDLE_MASK)) break;
    x.sim.tick(5);
  }
  REQUIRE(i < 100000, "reset did not complete");
  x.sim.tick(2000);
  x.sim.flush_posted();
  REQUIRE(x.sim.host_wr_beats == wb, "%llu host write beats after the reset request",
          (unsigned long long)(x.sim.host_wr_beats - wb));
  volatile sfh_cqe *p = (volatile sfh_cqe *)x.d.cq.va;
  REQUIRE(SFH_CQE_PHASE(p->dw3) == 0, "a completion entry was written after the reset request");
  x.no_violations();
}

// 21. ENABLE 1->0: in-flight command completes, nothing new is fetched
static void t_disable_drain(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(3, 3, 128 * 1024);
  sfh_sqe e;
  sfh_sqe_dma(&e, 1, x.pool.iova, 0x10000000, 65536, 0); e.txn_id = 1; sfh_push(&x.d, &e);
  sfh_sqe_nop(&e, 0); e.txn_id = 2; sfh_push(&x.d, &e);
  sfh_sqe_nop(&e, 0); e.txn_id = 3; sfh_push(&x.d, &e);
  sfh_ring(&x.d);
  x.sim.tick(500);
  REQUIRE(sfh_disable(&x.d, TMO) == SFH_OK, "disable drains");
  sfh_cqe c;
  REQUIRE(sfh_poll_cqe(&x.d, &c) == 1 && c.txn_id == 1 && c.result == 65536, "in-flight command completed");
  REQUIRE(sfh_poll_cqe(&x.d, &c) == 0, "no new command after disable");
  REQUIRE(x.rd(SFH_REG_SQ_HEAD) == 1, "head");
  x.no_violations();
}

// 22. STOP_ON_ERROR halts after a failure; ENABLE rewrite resumes
static void t_stop_on_error(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(3, 3, 64 * 1024, SFH_CTRL_STOP_ON_ERROR_MASK);
  sfh_sqe e;
  sfh_sqe_nop(&e, 0); e.txn_id = 1; sfh_push(&x.d, &e);
  sfh_sqe_dma(&e, 1, 0, 0x10000000, 64, 0); e.txn_id = 2; sfh_push(&x.d, &e);
  sfh_sqe_nop(&e, 0); e.txn_id = 3; sfh_push(&x.d, &e);
  sfh_sqe_nop(&e, 0); e.txn_id = 4; sfh_push(&x.d, &e);
  sfh_ring(&x.d);
  sfh_cqe c;
  REQUIRE(sfh_wait_cqe(&x.d, &c, TMO) == 0 && c.txn_id == 1, "1");
  REQUIRE(sfh_wait_cqe(&x.d, &c, TMO) == 0 && c.txn_id == 2 && SFH_CQE_STATUS(c.dw3) == SFH_STATUS_HOST_ADDR_DENIED, "2");
  x.sim.tick(2000);
  REQUIRE(sfh_poll_cqe(&x.d, &c) == 0, "halted");
  REQUIRE(x.rd(SFH_REG_STATUS) & SFH_STATUS_HALTED_MASK, "HALTED");
  REQUIRE(x.rd(SFH_REG_SQ_HEAD) == 2, "head stays");
  x.wr(SFH_REG_CTRL, SFH_CTRL_ENABLE_MASK | SFH_CTRL_STOP_ON_ERROR_MASK);
  REQUIRE(sfh_wait_cqe(&x.d, &c, TMO) == 0 && c.txn_id == 3, "3");
  REQUIRE(sfh_wait_cqe(&x.d, &c, TMO) == 0 && c.txn_id == 4, "4");
  x.no_violations();
}

// 23. memory ordering under relaxed ordering: hazard detectable without FLUSH, absent with FLUSH
static unsigned ordering_run(uint64_t seed, bool relaxed, int mode /*0 none,1 per-SQE,2 FLUSH_ALL*/) {
  SimCfg c = cfg_default(seed);
  c.relaxed_ordering = relaxed;
  c.post_delay_min = 0;
  c.post_delay_max = 400;
  Dev x(c);
  x.bringup(3, 3, 64 * 1024, mode == 2 ? SFH_CTRL_FLUSH_ALL_MASK : 0);
  std::mt19937_64 r(seed);
  unsigned stale = 0;
  for (int it = 0; it < 30; it++) {
    uint32_t len = 128 * (1 + (uint32_t)(r() % 8));
    fill_rand(r, x.pool.va, len);
    REQUIRE(sfh_dma_h2d(&x.d, x.pool.iova, 0x10000000, len, TMO) == 0, "h2d");
    memset(x.pool.va + 32768, 0, len);
    sfh_sqe e;
    sfh_sqe_dma(&e, 2, 0x10000000, x.pool.iova + 32768, len, mode == 1 ? SFH_SQE_FLAG_FLUSH : 0);
    e.txn_id = 9000 + it;
    sfh_submit(&x.d, &e);
    sfh_cqe cq;
    for (;;) {                                       // consume the CQE the moment it becomes visible
      if (sfh_poll_cqe(&x.d, &cq)) break;
      x.sim.tick(1);
    }
    REQUIRE(SFH_CQE_STATUS(cq.dw3) == 0, "status");
    if (memcmp(x.pool.va, x.pool.va + 32768, len) != 0) stale++;
    x.sim.flush_posted();
  }
  x.no_violations();
  return stale;
}
static void t_memory_ordering(uint64_t seed) {
  unsigned strict = ordering_run(seed, false, 0);
  unsigned rel_none = ordering_run(seed, true, 0);
  unsigned rel_flag = ordering_run(seed, true, 1);
  unsigned rel_all = ordering_run(seed, true, 2);
  printf("      ordering: strict=%u relaxed/no-flush=%u relaxed/SQE.FLUSH=%u relaxed/FLUSH_ALL=%u stale of 30\n",
         strict, rel_none, rel_flag, rel_all);
  REQUIRE(strict == 0, "strict ordering must never expose stale data");
  REQUIRE(rel_none > 0, "the relaxed-ordering model must expose the hazard (else the test is vacuous)");
  REQUIRE(rel_flag == 0 && rel_all == 0, "FLUSH must close the hazard");
}

// 24. DataFabric contention from a second master
static void t_fabric_contention(uint64_t seed) {
  SimCfg c = cfg_default(seed);
  c.ext_traffic_pct = 70;
  c.ext_base = 0x10008000;
  c.ext_size = 0x8000;                               // upper half of the device SRAM belongs to M1
  Dev x(c);
  x.bringup(3, 3, 128 * 1024);
  std::mt19937_64 r(seed);
  for (int it = 0; it < 20; it++) {
    bool tspm = r() & 1;
    uint32_t len = 8 * (1 + (uint32_t)(r() % 512));
    uint32_t dev = tspm ? 0x20000000 + 8 * (uint32_t)(r() % ((16384 - len) / 8))
                        : 0x10000000 + 8 * (uint32_t)(r() % ((32768 - len) / 8));
    fill_rand(r, x.pool.va, len);
    REQUIRE(sfh_dma_h2d(&x.d, x.pool.iova, dev, len, TMO) == 0, "h2d");
    REQUIRE(sfh_dma_d2h(&x.d, dev, x.pool.iova + 65536, len, TMO) == 0, "d2h");
    REQUIRE(memcmp(x.pool.va, x.pool.va + 65536, len) == 0, "mismatch with contention");
  }
  REQUIRE(x.sim.ext_ops > 1000 && x.sim.ext_errors == 0, "second master: %llu ops", (unsigned long long)x.sim.ext_ops);
  x.no_violations();
}

// 25. performance counters: exact values for a known workload, snapshot, clear
static void t_perf_counters(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(3, 3);
  x.wr(SFH_REG_PERF_CTRL, SFH_PERF_CTRL_CLEAR_MASK);
  sfh_sqe e;
  for (int i = 0; i < 3; i++) { sfh_sqe_nop(&e, 0); x.run(e); }
  REQUIRE(sfh_dma_h2d(&x.d, x.pool.iova, 0x10000000, 4096, TMO) == 0, "h2d");
  REQUIRE(sfh_dma_d2h(&x.d, 0x10000000, x.pool.iova + 8192, 1024, TMO) == 0, "d2h");
  sfh_sqe_nop(&e, 0); e.opcode = 0x66; x.run(e);
  sfh_perf_snapshot(&x.d);
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_CMDS_COMPLETED) == 6, "completed %llu", (unsigned long long)sfh_perf_read(&x.d, 0));
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_CMDS_FAILED) == 1, "failed");
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_BYTES_H2D) == 4096, "h2d bytes");
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_BYTES_D2H) == 1024, "d2h bytes");
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_DOORBELLS) == 12, "doorbells %llu", (unsigned long long)sfh_perf_read(&x.d, 9));
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_BUSY_CYCLES) > 0 && sfh_perf_read(&x.d, SFH_PERF_HOST_WAIT_CYCLES) > 0, "cycles");
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_ENGINE_CYCLES) == 0, "engine");
  uint64_t frozen = sfh_perf_read(&x.d, SFH_PERF_BUSY_CYCLES);
  sfh_sqe_nop(&e, 0); x.run(e);
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_BUSY_CYCLES) == frozen, "snapshot must be stable until the next SNAPSHOT");
  sfh_sqe_gemm(&e, 0, 0x1000, 0x3000, 8, 0, 0); x.run(e);
  sfh_perf_snapshot(&x.d);
  REQUIRE(sfh_perf_read(&x.d, SFH_PERF_ENGINE_CYCLES) >= 3 + 2 * 8 + 4, "engine cycles");
  x.wr(SFH_REG_PERF_CTRL, SFH_PERF_CTRL_CLEAR_MASK);
  for (unsigned i = 0; i < SFH_NUM_PERF; i++) REQUIRE(sfh_perf_read(&x.d, i) == 0, "clear %u", i);
  x.no_violations();
}

// 26. endpoint (hot) reset in the middle of traffic
static void t_endpoint_reset(uint64_t seed) {
  Dev x(cfg_default(seed));
  x.bringup(3, 3, 128 * 1024);
  sfh_sqe e;
  sfh_sqe_dma(&e, 1, x.pool.iova, 0x10000000, 65536, 0);
  sfh_submit(&x.d, &e);
  x.sim.tick(3000);
  x.sim.ep_reset();
  for (unsigned i = 0; i < SFH_REGTABLE_N; i++)
    REQUIRE(x.rd(sfh_regtable[i].off) == sfh_regtable[i].reset, "%s after endpoint reset", sfh_regtable[i].name);
  REQUIRE(sfh_open(&x.d, sfh_sim_backend_ops(), &x.sim) == 0, "reopen");
  x.bringup(3, 3);
  sfh_sqe_nop(&e, 0);
  REQUIRE(x.run_st(e) == 0, "works");
  x.no_violations();
}

// 27. randomized regression with a reference model (scoreboard)
static void t_random_regression(uint64_t seed) {
  std::mt19937_64 r(seed * 1000003ull);
  SimCfg c = cfg_default(seed);
  int prof = (int)(r() % 3);
  if (prof >= 1) {
    c.ar_ready_pct = 20 + (int)(r() % 80); c.aw_ready_pct = 20 + (int)(r() % 80); c.w_ready_pct = 20 + (int)(r() % 80);
    c.r_valid_pct = 20 + (int)(r() % 80); c.b_valid_pct = 20 + (int)(r() % 80);
    c.rd_latency = 10 + (int)(r() % 150); c.wr_latency = (int)(r() % 60);
  }
  if (prof == 2) { c.ext_traffic_pct = 40; c.ext_base = 0x1000C000; c.ext_size = 0x4000; }
  Dev x(c);
  unsigned sql = 1 + (unsigned)(r() % 5), cql = 1 + (unsigned)(r() % 5);
  int use_irq = (int)(r() % 2);
  x.bringup(sql, cql, 256 * 1024, (r() % 2) ? SFH_CTRL_FLUSH_ALL_MASK : 0, use_irq);
  std::vector<uint8_t> sram(65536), tspm(16384);
  for (size_t i = 0; i < sram.size(); i += 4) { uint32_t v = x.sim.fabric_read32(0x10000000 + (uint32_t)i); memcpy(&sram[i], &v, 4); }
  for (size_t i = 0; i < tspm.size(); i += 4) { uint32_t v = x.sim.fabric_read32(0x20000000 + (uint32_t)i); memcpy(&tspm[i], &v, 4); }
  const uint32_t sram_lim = prof == 2 ? 0xC000 : 0x10000;   // M1 owns the top of SRAM in profile 2
  auto mem = [&](uint32_t a) -> uint8_t * { return a >= 0x20000000 ? &tspm[a - 0x20000000] : &sram[a - 0x10000000]; };
  struct Exp { uint32_t txn; uint16_t st; uint32_t res; int kind; uint32_t hdst, len; std::vector<uint8_t> data;
               bool gemm_chk; int32_t C[16]; };
  std::deque<Exp> pend;
  unsigned ncmd = 120, issued = 0, done = 0;
  uint32_t txn = 1;
  uint8_t *H = x.pool.va;
  while (done < ncmd) {
    unsigned burst = 1 + (unsigned)(r() % 5);
    bool pushed = false;
    while (issued < ncmd && burst--) {
      sfh_sqe e;
      Exp ex{};
      ex.txn = txn;
      int kind = (int)(r() % 10);
      if (kind <= 3) {                               // H2D
        bool ts = r() & 1;
        uint32_t lim = ts ? 16384 : sram_lim;
        uint32_t len = 8 * (1 + (uint32_t)(r() % 256));
        uint32_t doff = 8 * (uint32_t)(r() % ((lim - len) / 8 + 1));
        // one 4 KiB source slot per command (<= 31 commands can be pending): a queued
        // H2D source is never overwritten before the device has read it
        uint32_t hs = (txn % 32) * 4096 + 8 * (uint32_t)(r() % ((4096 - len) / 8 + 1));
        uint32_t da = (ts ? 0x20000000 : 0x10000000) + doff;
        fill_rand(r, H + hs, len);
        sfh_sqe_dma(&e, 1, x.pool.iova + hs, da, len, (r() % 4) ? 0 : SFH_SQE_FLAG_IRQ);
        memcpy(mem(da), H + hs, len);               // in-order queue: later commands see this data
        ex.st = 0; ex.res = len; ex.kind = 1;
      } else if (kind <= 6) {                        // D2H
        bool ts = r() & 1;
        uint32_t lim = ts ? 16384 : sram_lim;
        uint32_t len = 8 * (1 + (uint32_t)(r() % 256));
        uint32_t doff = 8 * (uint32_t)(r() % ((lim - len) / 8 + 1));
        uint32_t da = (ts ? 0x20000000 : 0x10000000) + doff;
        uint32_t hd = 131072 + (txn % 32) * 4096;   // destination slots in the upper half
        sfh_sqe_dma(&e, 2, da, x.pool.iova + hd, len, 0);
        ex.st = 0; ex.res = len; ex.kind = 2; ex.hdst = hd; ex.len = len;
        ex.data.assign(mem(da), mem(da) + len);
      } else if (kind == 7) {                        // GEMM on whatever the TSPM holds
        unsigned K = 1 + (unsigned)(r() % 64);
        uint32_t te = (uint32_t)(r() % 8) & (SFH_GEMM_FLAG_A_UNSIGNED | SFH_GEMM_FLAG_B_UNSIGNED);
        sfh_sqe_gemm(&e, 0x0400, 0x0800, 0x0C00, K, te, 0);
        ref_gemm(&tspm[0x400], &tspm[0x800], K, te & SFH_GEMM_FLAG_A_UNSIGNED, te & SFH_GEMM_FLAG_B_UNSIGNED, ex.C);
        memcpy(&tspm[0x0C00], ex.C, 64);
        ex.st = 0; ex.res = 3 + 2 * K + 4; ex.kind = 3;
      } else if (kind == 8) {                        // NOP
        sfh_sqe_nop(&e, SFH_SQE_FLAG_IRQ);
        ex.st = 0; ex.res = 0; ex.kind = 0;
      } else {                                       // invalid
        sfh_sqe_dma(&e, 1, x.pool.iova + x.pool.size, 0x10000000, 64, 0);
        ex.st = SFH_STATUS_HOST_ADDR_DENIED; ex.res = 0; ex.kind = 0;
      }
      e.txn_id = txn;
      if (sfh_push(&x.d, &e) != SFH_OK) {
        // SQ full: retire completions until the same entry fits (model already includes it)
        while (sfh_push(&x.d, &e) != SFH_OK) {
          sfh_ring(&x.d);
          sfh_cqe c2;
          REQUIRE(sfh_wait_cqe(&x.d, &c2, TMO) == 0, "wait (full)");
          Exp &p = pend.front();
          REQUIRE(c2.txn_id == p.txn && SFH_CQE_STATUS(c2.dw3) == p.st && c2.result == p.res,
                  "scoreboard txn %u: got txn %u st %s res %u, exp st %s res %u", p.txn, c2.txn_id,
                  sfh_status_str(SFH_CQE_STATUS(c2.dw3)), c2.result, sfh_status_str(p.st), p.res);
          if (p.kind == 2) REQUIRE(memcmp(H + p.hdst, p.data.data(), p.len) == 0, "D2H data txn %u", p.txn);
          pend.pop_front();
          done++;
        }
      }
      pend.push_back(ex);
      issued++; txn++; pushed = true;
    }
    if (pushed) sfh_ring(&x.d);
    unsigned drain = (unsigned)(r() % 4);
    if (issued == ncmd) drain = 1000;
    while (drain-- && !pend.empty()) {
      sfh_cqe c2;
      REQUIRE(sfh_wait_cqe(&x.d, &c2, TMO) == 0, "wait");
      Exp &p = pend.front();
      REQUIRE(c2.txn_id == p.txn && SFH_CQE_STATUS(c2.dw3) == p.st && c2.result == p.res,
              "scoreboard txn %u: got txn %u st %s res %u, exp st %s res %u", p.txn, c2.txn_id,
              sfh_status_str(SFH_CQE_STATUS(c2.dw3)), c2.result, sfh_status_str(p.st), p.res);
      if (p.kind == 2) REQUIRE(memcmp(H + p.hdst, p.data.data(), p.len) == 0, "D2H data txn %u", p.txn);
      pend.pop_front();
      done++;
    }
  }
  // final device memory equals the model
  for (uint32_t a = 0; a < sram_lim; a += 4 * 13) {
    uint32_t v = x.sim.fabric_read32(0x10000000 + a), m;
    memcpy(&m, &sram[a], 4);
    REQUIRE(v == m, "SRAM %05x: %08x != model %08x", a, v, m);
  }
  for (uint32_t a = 0; a < 16384; a += 4 * 5) {
    uint32_t v = x.sim.fabric_read32(0x20000000 + a), m;
    memcpy(&m, &tspm[a], 4);
    REQUIRE(v == m, "TSPM %04x: %08x != model %08x", a, v, m);
  }
  x.no_violations();
}

// ============================================================================ runner
struct TestDef { const char *name; void (*fn)(uint64_t); const char *covers; };
static const TestDef kTests[] = {
    {"reg_reset_values", t_reg_reset_values, "register access: every reset value = ABI; unmapped -> all-ones + logged"},
    {"reg_access_rules", t_reg_access_rules, "register access: masks, RO/RWL/sub-word/burst/narrow rejection, IDs, no read side effects"},
    {"ring_config_validation", t_ring_config_validation, "host isolation: ring placement/permissions/overlap checked at ENABLE"},
    {"nop_basic", t_nop_basic, "command submission: every CQE field"},
    {"queue_wraparound", t_queue_wraparound, "queue wraparound: 6 SQ/CQ size pairs, batching, phase tags"},
    {"doorbell_validation", t_doorbell_validation, "doorbell value checks; halted queue; resume"},
    {"dma_integrity", t_dma_integrity, "DMA data integrity (both regions), independent fabric check"},
    {"dma_full_regions", t_dma_full_regions, "DMA max size, 4 KiB host boundary splitting"},
    {"invalid_descriptors", t_invalid_descriptors, "invalid descriptors (31 cases): status, no access, no side effect"},
    {"window_overflow", t_window_overflow, "integer overflow: window at the top of the 64-bit space"},
    {"host_backpressure", t_host_backpressure, "host back-pressure / latency on all AXI channels"},
    {"cq_full_backpressure", t_cq_full_backpressure, "host back-pressure through a full CQ"},
    {"interrupts", t_interrupts, "interrupts: flag, mask, unmask, W1C, vectors, level, endpoint stall, MSI-after-CQE"},
    {"irq_driven_completion", t_irq_driven_completion, "interrupt-driven driver path"},
    {"gemm_end_to_end", t_gemm_end_to_end, "DEFINITION OF DONE: transfer + TensorCore compute + transfer, bit exact"},
    {"gemm_engine_error", t_gemm_engine_error, "engine parameter errors"},
    {"engine_timeout", t_engine_timeout, "timeouts: engine watchdog + recovery"},
    {"data_bus_errors", t_data_bus_errors, "error recovery: host SLVERR / IOMMU fault on data"},
    {"fatal_queue_errors", t_fatal_queue_errors, "error recovery: SQ/CQ/flush errors -> FATAL -> reset"},
    {"host_timeout", t_host_timeout, "timeouts: host-bus hang, drain, endpoint reset"},
    {"reset_during_activity", t_reset_during_activity, "device reset with transfers in flight (6 random points)"},
    {"reset_in_flush", t_reset_in_flush, "device reset during the flush read: the command never completes"},
    {"disable_drain", t_disable_drain, "queue disable with a command in flight"},
    {"stop_on_error", t_stop_on_error, "STOP_ON_ERROR policy"},
    {"memory_ordering", t_memory_ordering, "memory ordering: relaxed-ordering hazard and FLUSH"},
    {"fabric_contention", t_fabric_contention, "DataFabric contention from a second master"},
    {"perf_counters", t_perf_counters, "performance counters: exact values, snapshot, clear"},
    {"endpoint_reset", t_endpoint_reset, "endpoint hot reset mid-transfer"},
    {"random_regression", t_random_regression, "randomised regression vs reference model"},
};

int main(int argc, char **argv) {
  std::string filter, report;
  unsigned seeds = 1;
  bool list = false;
  for (int i = 1; i < argc; i++) {
    std::string a = argv[i];
    if (a == "--filter" && i + 1 < argc) filter = argv[++i];
    else if (a == "--seeds" && i + 1 < argc) seeds = (unsigned)atoi(argv[++i]);
    else if (a == "--report" && i + 1 < argc) report = argv[++i];
    else if (a == "--trace") g_trace = true;
    else if (a == "--list") list = true;
  }
  struct Res { std::string name; uint64_t seed; bool ok; std::string msg; double ms; const char *covers; };
  std::vector<Res> res;
  for (auto &t : kTests) {
    if (list) { printf("%-24s %s\n", t.name, t.covers); continue; }
    if (!filter.empty() && std::string(t.name).find(filter) == std::string::npos) continue;
    unsigned ns = std::string(t.name) == "random_regression" ? seeds * 8 : seeds;
    for (unsigned s = 1; s <= ns; s++) {
      auto t0 = std::chrono::steady_clock::now();
      Res r{t.name, s, true, "", 0, t.covers};
      try {
        t.fn(s);
      } catch (TestFail &f) {
        r.ok = false;
        r.msg = f.msg;
      }
      r.ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
      printf("%s %-24s seed %-3llu %8.0f ms  %s\n", r.ok ? "PASS" : "FAIL", t.name, (unsigned long long)s, r.ms,
             r.msg.c_str());
      fflush(stdout);
      res.push_back(r);
    }
  }
  if (list) return 0;
  unsigned pass = 0;
  for (auto &r : res) pass += r.ok;
  printf("\n%u / %zu passed\n", pass, res.size());
  if (!report.empty()) {
    FILE *f = fopen(report.c_str(), "w");
    if (f) {
      fprintf(f, "# HostLink co-simulation results\n\nC driver (`sw/lib/sfh_driver.c`) on the Verilated RTL "
                 "(`sfh_device_top`) through the host model (`tb/cosim/sfh_sim.cpp`). Generated by "
                 "`build/test_hostlink --report`.\n\n**%u / %zu passed**\n\n| Result | Test | Seed | Wall ms | Covers | Message |\n|---|---|---|---|---|---|\n",
              pass, res.size());
      for (auto &r : res)
        fprintf(f, "| %s | %s | %llu | %.0f | %s | %s |\n", r.ok ? "PASS" : "**FAIL**", r.name.c_str(),
                (unsigned long long)r.seed, r.ms, r.covers, r.msg.c_str());
      fclose(f);
    }
  }
  return pass == res.size() ? 0 : 1;
}
