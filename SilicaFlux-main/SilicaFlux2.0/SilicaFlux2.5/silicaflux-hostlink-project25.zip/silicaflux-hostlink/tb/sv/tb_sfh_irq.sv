// =============================================================================
// SilicaFlux HostLink :: tb_sfh_irq -- cycle-exact unit test of sfh_irq
// Covers the single-cycle races the system-level suite cannot align:
// event vs. W1C in the same cycle, unmask with pending status, coalescing while
// the endpoint back-pressures, shared vectors, disarm before load, soft reset
// with a message presented.  Icarus 12 and Verilator 5 (--binary --timing).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sfh_irq;
  logic clk = 1'b0, rst_n = 1'b0;
  always #2 clk = ~clk;

  logic       srst = 0, w1c_we = 0, en_we = 0, vec_we = 0, msg_ready = 0;
  logic [1:0] ev = 0, w1c_mask = 0, en_val = 0;
  logic [3:0] vec_cq_val = 0, vec_err_val = 0;
  logic [1:0] status, enable;
  logic [3:0] vec_cq, vec_err, msg_vector;
  logic       msg_valid, irq_level, ev_msg_sent;

  sfh_irq #(.NV(2)) dut (
    .clk, .rst_n, .srst, .ev, .w1c_we, .w1c_mask, .en_we, .en_val, .vec_we, .vec_cq_val, .vec_err_val,
    .status, .enable, .vec_cq, .vec_err, .msg_valid, .msg_vector, .msg_ready, .irq_level, .ev_msg_sent
  );

  int errors = 0, msgs = 0;
  logic [3:0] last_vec;
  always @(posedge clk) if (msg_valid && msg_ready) begin msgs <= msgs + 1; last_vec <= msg_vector; end

  // one clock: inputs applied at the falling edge, effects visible after the rising edge
  task automatic step();
    @(negedge clk);
    ev = 0; w1c_we = 0; en_we = 0; vec_we = 0; srst = 0;
  endtask
  task automatic check(input logic c, input string what);
    if (!c) begin $display("ERROR: %s (status %b enable %b valid %b vec %0d msgs %0d)", what, status, enable,
                           msg_valid, msg_vector, msgs); errors++; end
  endtask

  logic [3:0] held;
  initial begin
    repeat (3) @(negedge clk);
    rst_n = 1;
    step();
    check(status == 0 && enable == 0 && vec_cq == 0 && vec_err == 1 && !msg_valid, "reset values");
    // event while masked: latches, no message, no level
    ev = 2'b01; step(); step();
    check(status == 2'b01 && !msg_valid && !irq_level, "masked event latches only");
    // unmask with status pending -> message
    en_we = 1; en_val = 2'b11; step();
    check(msg_valid && msg_vector == 0 && irq_level, "unmask sends a message");
    // endpoint back-pressure: payload stable, further events coalesce
    held = msg_vector;
    repeat (3) begin ev = 2'b01; step(); check(msg_valid && msg_vector == held, "message held stable"); end
    msg_ready = 1; step(); msg_ready = 0;               // accept the first message
    step();
    check(msgs == 1 && msg_valid, "one follow-up message for coalesced events");
    msg_ready = 1; step(); step(); msg_ready = 0;
    check(msgs == 2 && !msg_valid, "exactly two messages");
    // event and W1C in the same cycle: the event must win
    ev = 2'b01; w1c_we = 1; w1c_mask = 2'b01; step();
    check(status[0], "event in the W1C cycle must not be lost");
    // plain W1C clears
    w1c_we = 1; w1c_mask = 2'b11; step();
    check(status == 0 && !irq_level, "W1C clears");
    msg_ready = 1; step(); step(); msg_ready = 0;       // drain anything armed by the race
    // shared vector: both sources on vector 0 -> one message
    vec_we = 1; vec_cq_val = 0; vec_err_val = 0; step();
    msgs = 0;
    ev = 2'b11; step();
    msg_ready = 1; step(); step(); step(); msg_ready = 0;
    check(msgs == 1 && last_vec == 0, "two sources, one shared vector, one message");
    w1c_we = 1; w1c_mask = 2'b11; step();
    // disarm before load: source 1 cleared while source 0's message is presented
    vec_we = 1; vec_cq_val = 0; vec_err_val = 1; step();
    msgs = 0;
    ev = 2'b01; step();                                 // vector 0 presented, not accepted
    ev = 2'b10; step();                                 // source 1 armed
    w1c_we = 1; w1c_mask = 2'b10; step();               // ...and cleared before its message loads
    msg_ready = 1; step(); step(); step(); msg_ready = 0;
    check(msgs == 1 && last_vec == 0, "cleared source must not send a stale message");
    w1c_we = 1; w1c_mask = 2'b11; step();
    // soft reset with a message presented: message stays until accepted, state resets
    ev = 2'b01; step();
    check(msg_valid, "message presented");
    srst = 1; step();
    check(msg_valid && status == 0 && enable == 0, "srst keeps the presented message, clears state");
    msg_ready = 1; step(); msg_ready = 0; step();
    check(!msg_valid, "accepted after reset");
    if (errors == 0) $display("TB_SFH_IRQ PASS");
    else $display("TB_SFH_IRQ FAIL: %0d errors", errors);
    $finish;
  end
endmodule

`default_nettype wire
