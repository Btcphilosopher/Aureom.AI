// =============================================================================
// SilicaFlux HostLink :: tb_sfh_smoke -- self-checking SystemVerilog smoke test
//
// Independent of the C++ host model: a minimal SV "host" (AXI4 BAR master
// tasks + a 64 KiB host memory behind an AXI4 slave responder) runs the
// definition-of-done flow on sfh_device_top:
//   probe -> program rings/window -> 5 SQEs (H2D A, H2D B, TENSOR_GEMM, D2H C,
//   invalid opcode) -> one doorbell -> poll CQ phase -> check every CQE and C.
// Runs unchanged on Icarus 12 (iverilog -g2012) and Verilator 5 (--binary --timing).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sfh_smoke;
  localparam logic [63:0] HBASE = 64'h0000_0001_0000_0000;   // host memory IOVA base
  localparam int          HSIZE = 65536;
  localparam int          K     = 16;

  logic clk = 1'b0, ep_rst_n = 1'b0;
  always #2 clk = ~clk;

  // ------------------------------------------------------------ DUT ports
  logic        s_bar_awvalid, s_bar_awready, s_bar_wvalid, s_bar_wready, s_bar_wlast;
  logic        s_bar_bvalid, s_bar_bready, s_bar_arvalid, s_bar_arready, s_bar_rvalid, s_bar_rready, s_bar_rlast;
  logic [3:0]  s_bar_awid, s_bar_bid, s_bar_arid, s_bar_rid, s_bar_wstrb;
  logic [31:0] s_bar_awaddr, s_bar_wdata, s_bar_araddr, s_bar_rdata;
  logic [7:0]  s_bar_awlen, s_bar_arlen;
  logic [2:0]  s_bar_awsize, s_bar_arsize;
  logic [1:0]  s_bar_awburst, s_bar_arburst, s_bar_bresp, s_bar_rresp;
  logic        m_host_awvalid, m_host_awready, m_host_wvalid, m_host_wready, m_host_wlast;
  logic        m_host_bvalid, m_host_bready, m_host_arvalid, m_host_arready, m_host_rvalid, m_host_rready;
  logic        m_host_rlast;
  logic [63:0] m_host_awaddr, m_host_araddr, m_host_wdata, m_host_rdata;
  logic [7:0]  m_host_awlen, m_host_arlen, m_host_wstrb;
  logic [2:0]  m_host_awsize, m_host_arsize;
  logic [1:0]  m_host_awburst, m_host_arburst, m_host_bresp, m_host_rresp;
  logic [3:0]  m_host_awid, m_host_arid, m_host_bid, m_host_rid;
  logic        irq_valid, irq_ready, irq_level;
  logic [3:0]  irq_vector;
  logic        x_req_ready, x_rsp_valid, x_rsp_error;
  logic [31:0] x_rsp_rdata;

  sfh_device_top dut (
    .clk, .ep_rst_n,
    .s_bar_awvalid, .s_bar_awready, .s_bar_awid, .s_bar_awaddr, .s_bar_awlen, .s_bar_awsize, .s_bar_awburst,
    .s_bar_wvalid, .s_bar_wready, .s_bar_wdata, .s_bar_wstrb, .s_bar_wlast,
    .s_bar_bvalid, .s_bar_bready, .s_bar_bid, .s_bar_bresp,
    .s_bar_arvalid, .s_bar_arready, .s_bar_arid, .s_bar_araddr, .s_bar_arlen, .s_bar_arsize, .s_bar_arburst,
    .s_bar_rvalid, .s_bar_rready, .s_bar_rid, .s_bar_rdata, .s_bar_rresp, .s_bar_rlast,
    .m_host_awvalid, .m_host_awready, .m_host_awaddr, .m_host_awlen, .m_host_awsize, .m_host_awburst, .m_host_awid,
    .m_host_wvalid, .m_host_wready, .m_host_wdata, .m_host_wstrb, .m_host_wlast,
    .m_host_bvalid, .m_host_bready, .m_host_bresp, .m_host_bid,
    .m_host_arvalid, .m_host_arready, .m_host_araddr, .m_host_arlen, .m_host_arsize, .m_host_arburst, .m_host_arid,
    .m_host_rvalid, .m_host_rready, .m_host_rdata, .m_host_rresp, .m_host_rlast, .m_host_rid,
    .irq_valid, .irq_vector, .irq_ready, .irq_level,
    .x_req_valid(1'b0), .x_req_ready, .x_req_write(1'b0), .x_req_addr(32'd0), .x_req_wdata(32'd0),
    .x_req_wstrb(4'd0), .x_rsp_valid, .x_rsp_ready(1'b1), .x_rsp_rdata, .x_rsp_error
  );

  // ------------------------------------------------------------ host memory + AXI4 slave responder
  logic [7:0] hmem [0:HSIZE-1];
  int         errors = 0;
  int         irqs = 0;

  function automatic int hidx(input logic [63:0] a);
    hidx = int'(a - HBASE);
  endfunction

  logic        rd_act = 1'b0, wr_act = 1'b0, wr_bpend = 1'b0;
  logic [63:0] rd_addr, wr_addr;
  logic [8:0]  rd_left;
  int          rd_wait;
  assign m_host_arready = !rd_act;
  assign m_host_awready = !wr_act && !wr_bpend;
  assign m_host_wready  = wr_act;
  assign irq_ready      = 1'b1;
  assign m_host_rid     = 4'd0;
  assign m_host_bid     = 4'd0;

  always @(posedge clk) begin
    if (!ep_rst_n) begin
      rd_act <= 1'b0; wr_act <= 1'b0; wr_bpend <= 1'b0;
      m_host_rvalid <= 1'b0; m_host_bvalid <= 1'b0;
    end else begin
      if (irq_valid && irq_ready) irqs <= irqs + 1;
      // read: AR -> 8-cycle latency -> beats
      if (m_host_arvalid && m_host_arready) begin
        if (m_host_araddr < HBASE || m_host_araddr >= HBASE + HSIZE) begin
          $display("ERROR: host read outside host memory %h", m_host_araddr);
          errors <= errors + 1;
        end
        rd_act <= 1'b1; rd_addr <= m_host_araddr; rd_left <= {1'b0, m_host_arlen} + 9'd1; rd_wait <= 8;
      end
      if (rd_act) begin
        if (m_host_rvalid && m_host_rready) begin
          rd_addr <= rd_addr + 64'd8;
          rd_left <= rd_left - 9'd1;
          m_host_rvalid <= 1'b0;
          if (rd_left == 9'd1) rd_act <= 1'b0;
        end else if (!m_host_rvalid) begin
          if (rd_wait > 0) rd_wait <= rd_wait - 1;
          else begin
            for (int b = 0; b < 8; b++) m_host_rdata[8*b +: 8] <= hmem[hidx(rd_addr) + b];
            m_host_rvalid <= 1'b1; m_host_rresp <= 2'b00; m_host_rlast <= (rd_left == 9'd1);
          end
        end
      end
      // write: AW -> W beats -> B
      if (m_host_awvalid && m_host_awready) begin
        if ((m_host_awaddr & 64'hFFF) + 64'(({1'b0, m_host_awlen} + 9'd1)) * 64'd8 > 64'd4096) begin
          $display("ERROR: write burst crosses 4 KiB"); errors <= errors + 1;
        end
        wr_act <= 1'b1; wr_addr <= m_host_awaddr;
      end
      if (m_host_wvalid && m_host_wready) begin
        for (int b = 0; b < 8; b++) hmem[hidx(wr_addr) + b] <= m_host_wdata[8*b +: 8];
        wr_addr <= wr_addr + 64'd8;
        if (m_host_wlast) begin wr_act <= 1'b0; wr_bpend <= 1'b1; end
      end
      if (wr_bpend && !m_host_bvalid) begin m_host_bvalid <= 1'b1; m_host_bresp <= 2'b00; end
      if (m_host_bvalid && m_host_bready) begin m_host_bvalid <= 1'b0; wr_bpend <= 1'b0; end
    end
  end

  // ------------------------------------------------------------ BAR master tasks (single-beat AXI4)
  // Simulator-independent timing: inputs are driven at the falling edge and
  // handshakes are sampled 1 ns before the rising edge (pre-edge values), so the
  // result does not depend on how a simulator orders coroutine resumption
  // against non-blocking updates at the clock edge.
  task automatic bar_wr(input logic [11:0] off, input logic [31:0] v);
    logic aw_d, w_d;
    @(negedge clk);
    s_bar_awaddr = {20'd0, off}; s_bar_awid = 4'd3; s_bar_awlen = 8'd0; s_bar_awsize = 3'd2;
    s_bar_awburst = 2'b01; s_bar_awvalid = 1'b1;
    s_bar_wdata = v; s_bar_wstrb = 4'hF; s_bar_wlast = 1'b1; s_bar_wvalid = 1'b1;
    aw_d = 1'b0; w_d = 1'b0;
    while (!(aw_d && w_d)) begin
      #1;
      if (s_bar_awvalid && s_bar_awready) aw_d = 1'b1;
      if (s_bar_wvalid && s_bar_wready) w_d = 1'b1;
      @(negedge clk);
      if (aw_d) s_bar_awvalid = 1'b0;
      if (w_d) s_bar_wvalid = 1'b0;
    end
    #1; while (!s_bar_bvalid) begin @(negedge clk); #1; end
    if (s_bar_bresp != 2'b00) begin $display("ERROR: BAR write %h rejected", off); errors++; end
    @(negedge clk);
  endtask

  task automatic bar_rd(input logic [11:0] off, output logic [31:0] v);
    @(negedge clk);
    s_bar_araddr = {20'd0, off}; s_bar_arid = 4'd5; s_bar_arlen = 8'd0; s_bar_arsize = 3'd2;
    s_bar_arburst = 2'b01; s_bar_arvalid = 1'b1;
    #1; while (!s_bar_arready) begin @(negedge clk); #1; end
    @(negedge clk);
    s_bar_arvalid = 1'b0;
    #1; while (!s_bar_rvalid) begin @(negedge clk); #1; end
    v = (s_bar_rresp == 2'b00) ? s_bar_rdata : 32'hFFFF_FFFF;
    @(negedge clk);
  endtask

  task automatic hput32(input logic [63:0] a, input logic [31:0] v);
    for (int b = 0; b < 4; b++) hmem[hidx(a) + b] = v[8*b +: 8];
  endtask
  function automatic logic [31:0] hget32(input logic [63:0] a);
    for (int b = 0; b < 4; b++) hget32[8*b +: 8] = hmem[hidx(a) + b];
  endfunction

  // SQE dwords
  task automatic sqe(input int slot, input logic [31:0] d0, d1, d2, d3, d4, d5, d6, d7, d8, d9);
    logic [63:0] a;
    a = HBASE + 64'(slot * 64);
    for (int i = 0; i < 16; i++) hput32(a + 64'(4 * i), 32'd0);
    hput32(a + 0, d0); hput32(a + 4, d1); hput32(a + 8, d2); hput32(a + 12, d3); hput32(a + 16, d4);
    hput32(a + 20, d5); hput32(a + 24, d6); hput32(a + 28, d7); hput32(a + 32, d8); hput32(a + 36, d9);
  endtask

  // ------------------------------------------------------------ test
  logic [31:0] v;
  logic [63:0] SQ, CQ, A, B, C;
  int          ref_c [16];
  initial begin
    s_bar_awvalid = 0; s_bar_wvalid = 0; s_bar_arvalid = 0; s_bar_bready = 1; s_bar_rready = 1;
    s_bar_awaddr = 0; s_bar_araddr = 0; s_bar_wdata = 0; s_bar_wstrb = 0; s_bar_wlast = 0;
    s_bar_awid = 0; s_bar_arid = 0; s_bar_awlen = 0; s_bar_arlen = 0; s_bar_awsize = 2; s_bar_arsize = 2;
    s_bar_awburst = 1; s_bar_arburst = 1;
    m_host_rdata = 0; m_host_rresp = 0; m_host_rlast = 0; m_host_bresp = 0;
    for (int i = 0; i < HSIZE; i++) hmem[i] = 8'h00;
    SQ = HBASE; CQ = HBASE + 64'h1000; A = HBASE + 64'h2000; B = HBASE + 64'h3000; C = HBASE + 64'h4000;
    for (int i = 0; i < 4 * K; i++) begin
      hmem[hidx(A) + i] = 8'((i * 37 + 11) & 255);
      hmem[hidx(B) + i] = 8'((i * 91 + 5) & 255);
    end
    for (int i = 0; i < 4; i++)
      for (int j = 0; j < 4; j++) begin
        ref_c[4*i+j] = 0;
        for (int k = 0; k < K; k++)
          ref_c[4*i+j] += int'($signed(hmem[hidx(A) + 4*k + i])) * int'($signed(hmem[hidx(B) + 4*k + j]));
      end
    repeat (5) @(posedge clk);
    ep_rst_n <= 1'b1;
    repeat (5) @(posedge clk);

    bar_rd(12'h000, v); if (v !== 32'h5346484C) begin $display("ERROR: ID %h", v); errors++; end
    bar_rd(12'h004, v); if (v !== 32'h00010000) begin $display("ERROR: VERSION %h", v); errors++; end
    bar_wr(12'h080, SQ[31:0]); bar_wr(12'h084, SQ[63:32]); bar_wr(12'h088, 32'd3);
    bar_wr(12'h0A0, CQ[31:0]); bar_wr(12'h0A4, CQ[63:32]); bar_wr(12'h0A8, 32'd3);
    bar_wr(12'h200, HBASE[31:0]); bar_wr(12'h204, HBASE[63:32]); bar_wr(12'h208, HSIZE); bar_wr(12'h20C, 0);
    bar_wr(12'h210, 32'h7);                                         // window 0: VALID|DEV_READ|DEV_WRITE
    bar_wr(12'h0C4, 32'h1);                                         // INT_ENABLE.CQ
    bar_wr(12'h040, 32'h1);                                         // CTRL.ENABLE
    bar_rd(12'h044, v); if (!v[0]) begin $display("ERROR: not enabled, STATUS %h", v); errors++; end

    //        dw0 (op|flags|dir)  txn    dw2           dw3         dw4          dw5    dw6          dw7 dw8 dw9
    sqe(0, 32'h0001_0001,        32'd1, A[31:0],      A[63:32],   32'h20000000, 32'd0, 32'(4 * K), 0, 0, 0);
    sqe(1, 32'h0001_0001,        32'd2, B[31:0],      B[63:32],   32'h20000100, 32'd0, 32'(4 * K), 0, 0, 0);
    sqe(2, 32'h0000_0002,        32'd3, 32'h000,      32'h100,    32'h200,      K,     0,           0, 0, 0);
    sqe(3, 32'h0002_0101,        32'd4, 32'h20000200, 32'd0,      C[31:0],      C[63:32], 32'd64,   0, 0, 0);
    sqe(4, 32'h0000_007F,        32'd5, 0,            0,          0,            0,     0,           0, 0, 0);
    bar_wr(12'h090, 32'd5);                                         // SQ_TAIL doorbell

    v = 32'd0;
    for (int t = 0; t < 20000 && !v[16]; t++) begin @(posedge clk); v = hget32(CQ + 64'(4 * 16 + 12)); end
    if (!v[16]) begin $display("ERROR: completion 4 never arrived"); errors++; end
    for (int i = 0; i < 5; i++) begin
      logic [31:0] txn, res, dw3;
      txn = hget32(CQ + 64'(16 * i)); res = hget32(CQ + 64'(16 * i + 4)); dw3 = hget32(CQ + 64'(16 * i + 12));
      $display("CQE %0d: txn %0d status 0x%0h phase %0d result %0d", i, txn, dw3[15:0], dw3[16], res);
      if (txn != 32'(i + 1) || dw3[16] != 1'b1) begin $display("ERROR: CQE %0d header", i); errors++; end
      if (dw3[15:0] != ((i == 4) ? 16'h0001 : 16'h0000)) begin $display("ERROR: CQE %0d status", i); errors++; end
    end
    if (hget32(CQ + 64'(2 * 16 + 4)) != 32'(3 + 2 * K + 4)) begin $display("ERROR: GEMM cycles"); errors++; end
    for (int i = 0; i < 16; i++) begin
      v = hget32(C + 64'(4 * i));
      if ($signed(v) != ref_c[i]) begin
        $display("ERROR: C[%0d] = %0d expected %0d", i, $signed(v), ref_c[i]); errors++;
      end
    end
    if (irqs < 1) begin $display("ERROR: no interrupt message for the failed command"); errors++; end
    bar_rd(12'h08C, v); if (v != 32'd5) begin $display("ERROR: SQ_HEAD %0d", v); errors++; end
    bar_rd(12'h7FC, v); if (v != 32'hFFFF_FFFF) begin $display("ERROR: unmapped read %h", v); errors++; end
    if (errors == 0) $display("TB_SFH_SMOKE PASS (C = A*B bit exact, 5 completions, %0d interrupt message(s))", irqs);
    else $display("TB_SFH_SMOKE FAIL: %0d errors", errors);
    $finish;
  end

  initial begin
    #2000000;
    $display("TB_SFH_SMOKE FAIL: timeout");
    $finish;
  end
endmodule

`default_nettype wire
