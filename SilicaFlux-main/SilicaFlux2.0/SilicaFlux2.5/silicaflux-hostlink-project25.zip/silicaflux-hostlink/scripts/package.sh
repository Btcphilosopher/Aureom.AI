#!/usr/bin/env bash
# Package the project (sources, docs, reports; no build products) with a SHA-256 manifest.
set -euo pipefail
cd "$(dirname "$0")/.."
NAME=silicaflux-hostlink
OUT=$(realpath -m "${1:-../${NAME}-project25.zip}")
find . -type f ! -path './build/*' ! -name 'MANIFEST.sha256' ! -name '*.pyc' ! -path '*/__pycache__/*' \
  | sed 's|^\./||' | LC_ALL=C sort | xargs sha256sum > MANIFEST.sha256
rm -f "$OUT"
cd ..
zip -q -r -X "$OUT" "$NAME" -x "$NAME/build/*" "*/__pycache__/*" "*.pyc"
echo "wrote $OUT ($(du -h "$OUT" | cut -f1)), $(wc -l < "$NAME/MANIFEST.sha256") files in MANIFEST.sha256"
