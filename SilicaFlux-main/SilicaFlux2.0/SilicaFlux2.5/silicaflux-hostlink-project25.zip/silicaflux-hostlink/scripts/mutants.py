#!/usr/bin/env python3
"""Mutation testing: inject one realistic bug at a time into the HostLink RTL,
rebuild the Verilated model, run the co-simulation suite (1 seed + 8 regression
seeds).  A mutant is KILLED if the suite fails (assertion, protocol violation,
RTL $error, or hang -> timeout).  Survivors are reported with an analysis."""
import concurrent.futures as cf
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
B = "build/mut"
VROOT = subprocess.run(["verilator", "--getenv", "VERILATOR_ROOT"], capture_output=True, text=True).stdout.strip()

# (id, file, [(original, mutated)...], description)
M = [
    ("win_start", "rtl/sfh_win_check.sv", [("({1'b0, addr} >= {1'b0, win_base[i*64 +: 64]})", "({1'b0, addr} > {1'b0, win_base[i*64 +: 64]})")], "window start off by one"),
    ("win_wrap", "rtl/sfh_win_check.sv", [("(r_end <= 65'h1_0000_0000_0000_0000)", "1'b1")], "64-bit wrap check removed"),
    ("val_len_align", "rtl/sfh_cmd_validate.sv", [(" || length[2:0] != 3'd0", "")], "length alignment check removed"),
    ("val_rsvd", "rtl/sfh_cmd_validate.sv", [("rsv_dma_nz || ", "")], "DMA reserved-dword check removed"),
    ("val_dev_end", "rtl/sfh_cmd_validate.sv", [("(dev_end <= {1'b0, DM0_BASE} + {1'b0, DM0_SIZE})", "(dev_end < {1'b0, DM0_BASE} + {1'b0, DM0_SIZE})")], "device region end off by one"),
    ("val_perm", "rtl/sfh_cmd_validate.sv", [(".need_rd(h2d), .need_wr(!h2d),", ".need_rd(1'b0), .need_wr(1'b0),")], "window permissions ignored"),
    ("eng_phase", "rtl/sfh_engine.sv", [("phase_q <= !phase_q;", "phase_q <= phase_q;")], "phase tag never toggles"),
    ("eng_cqfull", "rtl/sfh_engine.sv", [("end else if (!cq_is_full) begin", "end else if (1'b1) begin")], "CQ full ignored"),
    ("eng_4k", "rtl/sfh_engine.sv", [("wire [31:0] chunk_n  = (c1 < {19'd0, to4k}) ? c1 : {19'd0, to4k};", "wire [31:0] chunk_n  = c1;")], "4 KiB split removed"),
    ("eng_irq_always", "rtl/sfh_engine.sv", [("ev_cq <= sqe_irq || cpl_fail;", "ev_cq <= 1'b1;")], "interrupt on every completion"),
    ("eng_no_flush", "rtl/sfh_engine.sv", [("if (!reset_req && !cq_is_full && (flush_all || sqe_flush)) begin", "if (1'b0) begin"),
                                         ("st <= (flush_all || sqe_flush) ? E_FLUSH : E_CQ_FILL;", "st <= E_CQ_FILL;")], "flush read skipped"),
    ("eng_halt_race", "rtl/sfh_engine.sv", [("!halted && !halt_set &&", "!halted &&")], "halt race re-introduced"),
    ("eng_no_wack", "rtl/sfh_engine.sv", [("E_DEV_REQ: if (f_req_ready) st <= E_DEV_RSP;", "E_DEV_REQ: if (f_req_ready) begin widx_q <= widx_q + 6'd1; st <= E_DEV_NEXT; end")], "device write ack not awaited"),
    ("eng_head_mask", "rtl/sfh_engine.sv", [("sq_head_q <= (sq_head_q + 12'd1) & sq_mask;", "sq_head_q <= sq_head_q + 12'd1;")], "SQ head does not wrap"),
    ("eng_partial", "rtl/sfh_engine.sv", [("cpl_st_q <= sfh_abi_pkg::ST_HOST_BUS_ERROR; cpl_res_q <= done_q;\n            cpl_addr_q <= host_ptr_q; st <= E_CQ_WAIT;\n          end else st <= E_DEV_NEXT;",
                                         "cpl_st_q <= sfh_abi_pkg::ST_HOST_BUS_ERROR; cpl_res_q <= 32'd0;\n            cpl_addr_q <= host_ptr_q; st <= E_CQ_WAIT;\n          end else st <= E_DEV_NEXT;")], "partial byte count lost"),
    ("eng_fetch_err", "rtl/sfh_engine.sv", [("if (tmo_seen_q || hp_err) begin\n            if (hp_err) begin ev_host_bus <= 1'b1; err_addr <= hp_addr_q; end\n            fatal_q <= 1'b1; st <= E_FATAL;\n          end else begin\n            sqe_q",
                                          "if (tmo_seen_q) begin\n            if (hp_err) begin ev_host_bus <= 1'b1; err_addr <= hp_addr_q; end\n            fatal_q <= 1'b1; st <= E_FATAL;\n          end else begin\n            sqe_q")], "SQ fetch error ignored"),
    ("eng_fill_reset", "rtl/sfh_engine.sv", [("hp_valid = !reset_req; hp_write = 1'b1; hp_addr = cq_slot;", "hp_valid = 1'b1; hp_write = 1'b1; hp_addr = cq_slot;"),
                                           ("if (reset_req) begin st <= E_RESET; rcnt_q <= 4'd0; end   // found by t_reset_in_flush\n            else           st <= E_CQ_POST;", "st <= E_CQ_POST;")], "CQE written after a reset request"),
    ("regs_rwl", "rtl/sfh_bar_regs.sv", [("end else if (wr_win_hit) begin\n      wr_rej = locked;", "end else if (wr_win_hit) begin\n      wr_rej = 1'b0;")], "window registers not locked"),
    ("regs_db_back", "rtl/sfh_bar_regs.sv", [("(((db_v - i_sq_head) & sq_mask) >= ((sq_tail_q - i_sq_head) & sq_mask))", "1'b1")], "backward SQ doorbell accepted"),
    ("regs_strb", "rtl/sfh_bar_regs.sv", [("aw_off[1:0] != 2'b00 || w_strb != 4'hF ||", "aw_off[1:0] != 2'b00 ||")], "sub-word writes accepted"),
    ("regs_overlap", "rtl/sfh_bar_regs.sv", [("sq_win_ok && cq_win_ok && !rings_overlap;", "sq_win_ok && cq_win_ok;")], "ring overlap accepted"),
    ("irq_clear_wins", "rtl/sfh_irq.sv", [("wire [1:0] status_n = (status & ~clr) | ev;", "wire [1:0] status_n = (status | ev) & ~clr;")], "W1C beats a simultaneous event"),
    ("irq_unmask", "rtl/sfh_irq.sv", [(" | (en_we ? (en_val & ~enable & status_n) : 2'b00)", "")], "unmask does not re-arm"),
    ("hp_wlast", "rtl/sfh_host_port.sv", [("assign m_wlast   = (cnt_q == beats_q - 1'b1);", "assign m_wlast   = (cnt_q == beats_q);")], "WLAST off by one"),
    ("te_no_tmo", "rtl/sfh_te_ctl.sv", [("end else if (timeout != 32'd0 && wd_q + 32'd1 >= timeout) begin", "end else if (1'b0) begin")], "engine watchdog removed"),
    ("shell_burst", "rtl/ep/sfh_ep_axi_shell.sv", [("wire r_ok = (s_arlen == 8'd0) && (s_arsize == 3'd2);", "wire r_ok = 1'b1;")], "BAR burst reads forwarded"),
]


def build_common():
    os.makedirs(B, exist_ok=True)
    inc = ["-Igenerated", "-Isw/include", "-Itb/cosim", "-Ibuild/obj_dir", f"-I{VROOT}/include", f"-I{VROOT}/include/vltstd"]
    for src, obj in (("tests/test_hostlink.cpp", f"{B}/test.o"), ("tb/cosim/sfh_sim.cpp", f"{B}/sim.o")):
        subprocess.run(["g++", "-std=c++17", "-O2", "-c", src, "-o", obj] + inc, check=True)


def run_mutant(m):
    mid, path, edits, desc = m
    d = f"{B}/{mid}"
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    src = open(path).read()
    for a, b in edits:
        if src.count(a) != 1:
            return (mid, desc, "BAD-MUTANT", f"pattern found {src.count(a)} times")
        src = src.replace(a, b)
    mpath = f"{d}/{os.path.basename(path)}"
    open(mpath, "w").write(src)
    fl = open("rtl/files.f").read().replace(path, mpath)
    open(f"{d}/files.f", "w").write(fl)
    r = subprocess.run(["verilator", "--cc", "--build", "-j", "2", "-O1", "--trace", "-Wno-fatal", "-Wno-lint",
                        "-Wno-style", "-f", f"{d}/files.f", "--top-module", "sfh_device_top", "--Mdir", f"{d}/obj"],
                       capture_output=True, text=True)
    if r.returncode:
        return (mid, desc, "KILLED", "does not compile")
    r = subprocess.run(["g++", f"{B}/test.o", f"{B}/sim.o", "build/sfh_driver.o", f"{d}/obj/Vsfh_device_top__ALL.a",
                        f"{d}/obj/libverilated.a", "-pthread", "-o", f"{d}/test"], capture_output=True, text=True)
    if r.returncode:
        return (mid, desc, "ERROR", r.stderr[-300:])
    try:
        r = subprocess.run([f"{d}/test", "--seeds", "1"], capture_output=True, text=True, timeout=300)
        out = r.stdout + r.stderr
        if r.returncode == 0:
            # second stage: cycle-exact SV unit tests on the mutated sources (Icarus)
            if path == "rtl/sfh_irq.sv":
                u = subprocess.run(["iverilog", "-g2012", "-o", f"{d}/tb_irq.vvp", mpath, "tb/sv/tb_sfh_irq.sv"],
                                   capture_output=True, text=True)
                if u.returncode == 0:
                    u = subprocess.run(["vvp", "-n", f"{d}/tb_irq.vvp"], capture_output=True, text=True)
                if "TB_SFH_IRQ PASS" not in u.stdout:
                    return (mid, desc, "KILLED", "co-simulation suite passes; killed by unit test tb_sfh_irq")
            return (mid, desc, "SURVIVED", "all tests pass")
        first = next((l for l in out.splitlines() if l.startswith("FAIL")), "")
        if not first:
            first = next((l for l in out.splitlines() if "%Error" in l or "error" in l.lower()), "abort")
        killers = sorted({l.split()[1] for l in out.splitlines() if l.startswith("FAIL")})
        return (mid, desc, "KILLED", f"{len(killers)} failing test(s): {', '.join(killers) or first[:120]}")
    except subprocess.TimeoutExpired:
        return (mid, desc, "KILLED", "hang (suite timeout)")


build_common()
res = []
with cf.ThreadPoolExecutor(max_workers=4) as ex:
    for r in ex.map(run_mutant, M):
        print(f"{r[2]:10s} {r[0]:16s} {r[1]:34s} {r[3]}", flush=True)
        res.append(r)
k = sum(1 for r in res if r[2] == "KILLED")
s = [r for r in res if r[2] == "SURVIVED"]
print(f"\n{k} / {len(res)} mutants killed, {len(s)} survived: {', '.join(r[0] for r in s)}")
with open("reports/mutants.md", "w") as f:
    f.write("# Mutation testing\n\nOne injected RTL bug per mutant; suite = `test_hostlink --seeds 1` "
            "(28 directed tests + 8 random-regression seeds), then the cycle-exact unit test `tb/sv/tb_sfh_irq.sv` "
            "for mutants of `sfh_irq.sv` that the suite does not kill. Generated by `make mutants`.\n\n")
    f.write(f"**{k} / {len(res)} killed**\n\n| Result | Mutant | Injected bug | Detail |\n|---|---|---|---|\n")
    for r in res:
        f.write(f"| {r[2]} | `{r[0]}` | {r[1]} | {r[3]} |\n")
sys.exit(0)
