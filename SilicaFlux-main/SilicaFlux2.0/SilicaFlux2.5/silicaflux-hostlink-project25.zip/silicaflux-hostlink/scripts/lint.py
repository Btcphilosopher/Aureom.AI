#!/usr/bin/env python3
"""Lint policy: Verilator 5 -Wall must report ZERO warnings in new HostLink RTL
(rtl/, generated/) for every parameter set below; warnings inside the vendored,
unmodified third_party/ sources are counted and reported but not fixed (they
are upstream files, byte-identical to the repository archives).
Also elaborates the device top with Icarus 12 and checks the vendored SHA-256 sums."""
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

PARAMS = [
    ("sfh_device_top", []),
    ("silicaflux_host_pcie", []),
    ("silicaflux_host_pcie", ["-GNW=1", "-GNV=1"]),
    ("silicaflux_host_pcie", ["-GMAXB=8", "-GSQ_LOG2_MAX=6", "-GCQ_LOG2_MAX=4"]),
    ("silicaflux_host_pcie", ["-GMAXB=8", "-GMAX_DMA_LOG2=16", "-GNV=16"]),
    ("sfh_ep_axi_shell", []),
]

fail = False
for top, gs in PARAMS:
    cmd = ["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-f", "rtl/files.f", "--top-module", top] + gs
    p = subprocess.run(cmd, capture_output=True, text=True)
    warns = [l for l in p.stderr.splitlines() if l.startswith("%Warning") or l.startswith("%Error")]
    warns = [l for l in warns if "Exiting due to" not in l]
    own = [l for l in warns if "third_party/" not in l]
    tp = len(warns) - len(own)
    print(f"verilator -Wall {top:22s} {' '.join(gs):40s} new-RTL warnings: {len(own)}  (vendored: {tp})")
    for l in own:
        print("   " + l)
    fail |= bool(own)

# illegal parameter sets must be rejected at elaboration by Verilator and Yosys (the synthesis
# flow).  Icarus 12 does not implement elaboration-time system tasks ($error in a generate
# block is silently ignored -- verified with a one-line probe), so it is reported, not required.
BAD = [["-GMAXB=4"], ["-GMAXB=32"], ["-GNW=0"], ["-GNW=9"], ["-GNV=0"], ["-GNV=17"],
       ["-GSQ_LOG2_MAX=13"], ["-GCQ_LOG2_MAX=0"], ["-GMAX_DMA_LOG2=2"], ["-GMAX_DMA_LOG2=31"]]
core = [l.strip() for l in open("rtl/files.f") if l.strip().startswith(("rtl/sfh_", "rtl/silicaflux", "generated/"))]
for gs in BAD:
    v = subprocess.run(["verilator", "--lint-only", "--top-module", "silicaflux_host_pcie"] + gs + core,
                       capture_output=True, text=True)
    iv = subprocess.run(["iverilog", "-g2012", "-s", "silicaflux_host_pcie", "-o", "/dev/null",
                         "-Psilicaflux_host_pcie." + gs[0][2:]] + core, capture_output=True, text=True)
    pname, pval = gs[0][2:].split("=")
    ys = "; ".join(f"read_verilog -sv {f}" for f in core) + \
         f"; chparam -set {pname} {pval} silicaflux_host_pcie; hierarchy -top silicaflux_host_pcie"
    y = subprocess.run(["yosys", "-q", "-p", ys], capture_output=True, text=True)
    rej = [v.returncode != 0 and "silicaflux_host_pcie:" in v.stderr,
           iv.returncode != 0 and "silicaflux_host_pcie:" in (iv.stderr + iv.stdout),
           y.returncode != 0 and "silicaflux_host_pcie:" in (y.stderr + y.stdout)]
    print(f"illegal {gs[0]:22s} rejected: verilator={rej[0]} yosys={rej[2]} (icarus={rej[1]}, unsupported)")
    fail |= not (rej[0] and rej[2])

# Icarus elaboration
args = []
for ln in open("rtl/files.f"):
    ln = ln.strip()
    if not ln or ln.startswith("//"):
        continue
    if ln.startswith("+define+"):
        args.append("-D" + ln[8:])
    elif ln.startswith("+incdir+"):
        args.append("-I" + ln[8:])
    else:
        args.append(ln)
os.makedirs("build", exist_ok=True)
p = subprocess.run(["iverilog", "-g2012", "-s", "sfh_device_top", "-o", "build/lint_icarus.vvp"] + args,
                   capture_output=True, text=True)
msgs = [l for l in p.stderr.splitlines() if l.strip()]
sorry = [l for l in msgs if "sorry: constant selects in always_*" in l]
other = [l for l in msgs if l not in sorry]
own_other = [l for l in other if not l.startswith("third_party/")]
print(f"iverilog -g2012 sfh_device_top: rc={p.returncode}, other messages in new RTL: {len(own_other)} "
      f"(Icarus 'constant select in always_*' sensitivity notices: {len(sorry)}, also emitted for the vendored code)")
for l in own_other:
    print("   " + l)
fail |= p.returncode != 0 or bool(own_other)

# vendored sources unmodified
p = subprocess.run("cd third_party/silicaflux-datafabric && sha256sum -c ../SHA256SUMS.datafabric --quiet",
                   shell=True, capture_output=True, text=True)
n = sum(1 for _ in open("third_party/SHA256SUMS.datafabric"))
print(f"third_party SHA-256: {'all %d files unmodified' % n if p.returncode == 0 else 'MISMATCH'}")
fail |= p.returncode != 0
print("LINT", "FAIL" if fail else "PASS")
sys.exit(1 if fail else 0)
