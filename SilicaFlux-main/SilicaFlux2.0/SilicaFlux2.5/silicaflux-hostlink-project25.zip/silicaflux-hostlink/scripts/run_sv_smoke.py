#!/usr/bin/env python3
"""Run tb/sv/tb_sfh_smoke.sv on Icarus 12 and Verilator 5 (--binary --timing)."""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
os.makedirs("build/sv", exist_ok=True)


def files():
    out = []
    for ln in open("rtl/files.f"):
        ln = ln.strip()
        if ln and not ln.startswith("//"):
            out.append(ln)
    return out


def run(cmd, log):
    with open(log, "w") as f:
        p = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, shell=isinstance(cmd, str))
    return p.returncode, open(log).read()


results = []
fl = files()
icarus = ["iverilog", "-g2012", "-s", "tb_sfh_smoke", "-o", "build/sv/tb_icarus.vvp"]
for x in fl:
    if x.startswith("+define+"):
        icarus.append("-D" + x[len("+define+"):])
    elif x.startswith("+incdir+"):
        icarus.append("-I" + x[len("+incdir+"):])
    else:
        icarus.append(x)
icarus.append("tb/sv/tb_sfh_smoke.sv")
rc, _ = run(icarus, "build/sv/icarus_compile.log")
if rc == 0:
    rc, out = run(["vvp", "-n", "build/sv/tb_icarus.vvp"], "build/sv/icarus_run.log")
    ok = "TB_SFH_SMOKE PASS" in out
    results.append(("tb_sfh_smoke Icarus 12", ok, [l for l in out.splitlines() if "TB_SFH" in l or "CQE" in l]))
else:
    results.append(("Icarus 12", False, ["compile failed: build/sv/icarus_compile.log"]))

ver = ["verilator", "--binary", "--timing", "-j", "8", "-Wno-fatal", "-Wno-lint", "-Wno-style",
       "--top-module", "tb_sfh_smoke", "--Mdir", "build/sv/obj_tb", "-f", "rtl/files.f", "tb/sv/tb_sfh_smoke.sv"]
rc, _ = run(ver, "build/sv/verilator_compile.log")
if rc == 0:
    rc, out = run(["build/sv/obj_tb/Vtb_sfh_smoke"], "build/sv/verilator_run.log")
    ok = "TB_SFH_SMOKE PASS" in out
    results.append(("tb_sfh_smoke Verilator 5", ok, [l for l in out.splitlines() if "TB_SFH" in l or "CQE" in l]))
else:
    results.append(("Verilator 5", False, ["compile failed: build/sv/verilator_compile.log"]))

# cycle-exact unit test of the interrupt block
rc, _ = run(["iverilog", "-g2012", "-o", "build/sv/tb_irq.vvp", "rtl/sfh_irq.sv", "tb/sv/tb_sfh_irq.sv"],
            "build/sv/irq_icarus_compile.log")
out = run(["vvp", "-n", "build/sv/tb_irq.vvp"], "build/sv/irq_icarus_run.log")[1] if rc == 0 else ""
results.append(("tb_sfh_irq Icarus 12", "TB_SFH_IRQ PASS" in out, [l for l in out.splitlines() if "TB_SFH" in l or "ERROR" in l]))
rc, _ = run(["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module", "tb_sfh_irq",
             "--Mdir", "build/sv/obj_irq", "rtl/sfh_irq.sv", "tb/sv/tb_sfh_irq.sv"], "build/sv/irq_verilator_compile.log")
out = run(["build/sv/obj_irq/Vtb_sfh_irq"], "build/sv/irq_verilator_run.log")[1] if rc == 0 else ""
results.append(("tb_sfh_irq Verilator 5", "TB_SFH_IRQ PASS" in out, [l for l in out.splitlines() if "TB_SFH" in l or "ERROR" in l]))

allok = True
for name, ok, lines in results:
    print(f"== {name}: {'PASS' if ok else 'FAIL'}")
    for l in lines:
        print("   " + l)
    allok &= ok
sys.exit(0 if allok else 1)
