#!/usr/bin/env bash
# Regenerate every report in reports/ from the current sources.
set -u
cd "$(dirname "$0")/.."
mkdir -p reports build
{
  echo "date: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "host: $(uname -srm)"
  verilator --version; iverilog -V 2>&1 | head -1; yosys -V; gcc --version | head -1; python3 --version
} > reports/tools.txt
step() { echo "=== $1"; shift; "$@"; echo "=== rc=$?"; }
step "abi-check" python3 abi/gen_abi.py --check                    > reports/abi_check.log 2>&1
step "lint"      python3 scripts/lint.py                           > reports/lint.log 2>&1
make build/test_hostlink build/sfh_gemm_demo_sim                    > build/make.log 2>&1
step "cosim"     build/test_hostlink --seeds 4 --report reports/cosim_results.md > reports/cosim.log 2>&1
step "demo"      build/sfh_gemm_demo_sim                           > reports/gemm_demo_sim.log 2>&1
step "demo-bp"   build/sfh_gemm_demo_sim --backpressure            > reports/gemm_demo_sim_backpressure.log 2>&1
step "sv"        python3 scripts/run_sv_smoke.py                   > reports/sv_tests.log 2>&1
step "synth"     python3 scripts/synth.py                          > reports/synth.log 2>&1
step "vfio"      make vfio                                         > reports/vfio_build.log 2>&1
step "mutants"   python3 scripts/mutants.py                        > reports/mutants.log 2>&1
for f in abi_check lint cosim gemm_demo_sim gemm_demo_sim_backpressure sv_tests synth vfio_build mutants; do
  printf "%-28s %s\n" "$f" "$(tail -1 reports/$f.log)"
done
