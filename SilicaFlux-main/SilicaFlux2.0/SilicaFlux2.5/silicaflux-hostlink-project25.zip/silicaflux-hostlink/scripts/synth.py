#!/usr/bin/env python3
"""Yosys 0.33 synthesis of the new HostLink RTL.

  1. generic synthesis of silicaflux_host_pcie (+ sfh_ep_axi_shell): cell counts,
     `check -assert`, latch check (must be zero);
  2. synth_xilinx -family xc7 of the same: LUT/FF/carry estimates (Yosys mapping
     only: NO vendor place & route, NO timing closure -- an estimate, not a result).
The device top is not synthesized here: its 64 KiB SRAM and 16 KiB TSPM would be
inferred as flops without a vendor memory library (they map to BRAM/SRAM macros
in a real flow; see the SilicaFlux SRAM Wrapper Library)."""
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
os.makedirs("build/synth", exist_ok=True)

SRC = ["generated/sfh_abi_pkg.sv"] + [f"rtl/{m}.sv" for m in (
    "sfh_win_check", "sfh_irq", "sfh_perf", "sfh_bar_regs", "sfh_host_port", "sfh_cmd_validate",
    "sfh_te_ctl", "sfh_engine", "silicaflux_host_pcie")]
SHELL = ["third_party/silicaflux-datafabric/third_party/silicaflux-v/rtl/common/sfv_common.sv",
         "rtl/ep/sfh_ep_axi_shell.sv"]


def yosys(name, files, top, flow):
    reads = "\n".join(f"read_verilog -sv -DSYNTHESIS -DSFV_NO_CLOCK_GATE {f}" for f in files)
    script = f"""{reads}
hierarchy -check -top {top}
{flow}
tee -o build/synth/{name}_stat.txt stat
select -assert-none t:$dlatch t:$_DLATCH_* t:$_DLATCH_P_ t:$_DLATCH_N_
check -assert
"""
    ys = f"build/synth/{name}.ys"
    open(ys, "w").write(script)
    p = subprocess.run(["yosys", "-q", "-l", f"build/synth/{name}.log", ys], capture_output=True, text=True)
    stat = open(f"build/synth/{name}_stat.txt").read() if os.path.exists(f"build/synth/{name}_stat.txt") else ""
    return p.returncode, stat, p.stderr


ok = True
rows = []
for name, files, top, flow in [
    ("hostlink_generic", SRC, "silicaflux_host_pcie", "synth -flatten -top silicaflux_host_pcie"),
    ("shell_generic", SHELL, "sfh_ep_axi_shell", "synth -flatten -top sfh_ep_axi_shell"),
    ("hostlink_xc7", SRC, "silicaflux_host_pcie", "synth_xilinx -family xc7 -flatten -top silicaflux_host_pcie"),
]:
    rc, stat, err = yosys(name, files, top, flow)
    cells = re.search(r"Number of cells:\s+(\d+)", stat)
    print(f"== {name}: {'OK' if rc == 0 else 'FAIL'} (latches: none asserted, check -assert passed)" if rc == 0
          else f"== {name}: FAIL\n{err[-2000:]}")
    ok &= rc == 0
    if rc == 0:
        if "xc7" in name:
            keep = [l.strip() for l in stat.splitlines() if re.search(r"\b(LUT[1-6]|FD[A-Z]*|CARRY4|MUXF[78]|RAM\w*|SRL\w*)\b", l)]
            print("   " + "\n   ".join(keep))
            lut = sum(int(m.group(1)) for m in re.finditer(r"LUT[1-6]\s+(\d+)", stat))
            ff = sum(int(m.group(1)) for m in re.finditer(r"FD[A-Z]*\s+(\d+)", stat))
            print(f"   total LUTs {lut}, flip-flops {ff} (Yosys xc7 mapping estimate, no P&R)")
        else:
            print(f"   cells: {cells.group(1) if cells else '?'}")
            ffs = sum(int(m.group(1)) for m in re.finditer(r"\$_[S]?DFF\w*\s+(\d+)", stat))
            print(f"   flip-flops: {ffs}")
print("SYNTH", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
