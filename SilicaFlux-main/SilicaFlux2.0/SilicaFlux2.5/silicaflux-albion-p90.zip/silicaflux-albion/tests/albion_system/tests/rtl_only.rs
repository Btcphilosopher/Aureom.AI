//! RTL-only system tests: ControlCore ISS lock-step, reset during traffic,
//! interrupt-driven completion timing, host latency sensitivity, queue back-pressure.
use albion_system_tests::iss::{gen_program, Iss, TraceRec};
use albion_system_tests::*;
use sf_albion::rtlsim::RtlSim;
use sf_albion::*;

fn boot_raw(program: &[u32], trace: &str) -> RtlSim {
    let mut t = RtlSim::spawn(&RtlSim::default_binary(0), "ALBION_MIN", &[]).unwrap();
    t.reset().unwrap();
    t.advance(5000).unwrap();
    assert_eq!(t.mmio_write_burst(0, program).unwrap(), 0, "program load");
    t.set_trace(Some(trace)).unwrap();
    assert_eq!(t.mmio_write(regs::MGMT_BASE + regs::MGMT_CORE_CTRL, 1).unwrap(), 0);
    t
}

#[test]
fn controlcore_lockstep_against_iss() {
    let dir = std::env::temp_dir();
    let mut total = 0usize;
    let mut traps = std::collections::BTreeMap::new();
    for seed in 1..=64u64 {
        let mut rng = Rng::new(seed * 7919);
        let prog = gen_program(&mut rng, 500);
        let path = dir.join(format!("albion_iss_{}_{seed}.trace", std::process::id()));
        let mut t = boot_raw(&prog, path.to_str().unwrap());
        let (found, _) = t.run_until_trap(3, 400_000).unwrap();
        t.set_trace(None).unwrap();
        t.shutdown().unwrap();
        assert!(found, "seed {seed}: RTL never reached ebreak");
        let rtl: Vec<TraceRec> = std::fs::read_to_string(&path).unwrap().lines().filter_map(TraceRec::parse).collect();
        let _ = std::fs::remove_file(&path);
        let gold = Iss::new(64 * 1024, &prog).run(100_000);
        for (k, (a, b)) in gold.iter().zip(rtl.iter()).enumerate() {
            assert_eq!(a.key(), b.key(), "seed {seed}: divergence at record {k}\n ISS {a:?}\n RTL {b:?}");
        }
        assert_eq!(gold.len(), rtl.len(), "seed {seed}: trace length");
        total += gold.len();
        for r in gold.iter().filter(|r| r.trap) {
            *traps.entry(r.cause).or_insert(0) += 1;
        }
    }
    // the random programs must actually exercise every implemented trap cause
    for cause in [0u32, 2, 3, 4, 5, 6, 7, 11] {
        assert!(traps.get(&cause).copied().unwrap_or(0) > 0, "trap cause {cause} never exercised: {traps:?}");
    }
    eprintln!("lock-step: {total} records compared, traps {traps:?}");
}

#[test]
fn pin_reset_during_dma_returns_clean_device() {
    let mut d = open(Be::Rtl, &OpenCfg { latency: 20, ..Default::default() });
    let h = d.alloc(MemKind::Host, 16384).unwrap();
    let s = d.alloc(MemKind::DeviceSram, 16384).unwrap();
    d.host_write(&h, 0, &vec![0xFACE_FEED; 4096]).unwrap();
    // start a long host->SRAM transfer and pull reset in the middle of it
    let t = d.submit(&Work::DmaCopy { src: h.addr, dst: s.addr, len: 16384 }).unwrap();
    d.transport().advance(20_000).unwrap();
    assert!(d.poll(t).unwrap().is_none(), "transfer should still be running");
    drop(d.transport().reset());
    // a reset device is in boot mode with scrubbed SRAM; nothing leaks into the next session
    d.transport().advance(6000).unwrap();
    let st = d.raw_read(regs::MGMT_BASE + regs::MGMT_DEV_STATUS).unwrap().0;
    assert_eq!(st & 0x1F, 0x11, "init_done + boot_mode after reset, got 0x{st:x}");
    for a in (0x4000u32..0x8000).step_by(0x400) {
        assert_eq!(d.raw_read(a).unwrap(), (0, regs::FE_OK), "SRAM 0x{a:x} not scrubbed");
    }
    drop(d);
    // and the device boots normally again
    let mut d = open_default(Be::Rtl);
    assert!(d.run(&Work::Ping).unwrap().status.is_ok());
    d.close().unwrap();
}

#[test]
fn soft_reset_during_dma() {
    let mut d = open(Be::Rtl, &OpenCfg { latency: 20, ..Default::default() });
    let h = d.alloc(MemKind::Host, 8192).unwrap();
    let s = d.alloc(MemKind::DeviceSram, 8192).unwrap();
    d.host_write(&h, 0, &vec![0x0BAD_F00D; 2048]).unwrap();
    let _t = d.submit(&Work::DmaCopy { src: h.addr, dst: s.addr, len: 8192 }).unwrap();
    d.transport().advance(10_000).unwrap();
    d.soft_reset_and_reboot(&firmware_image()).unwrap();
    let s2 = d.alloc(MemKind::DeviceSram, 8192).unwrap();
    assert_eq!(s2.addr, s.addr);
    let crc = d.run(&Work::Crc32 { addr: s2.addr, len: 8192 }).unwrap();
    assert_eq!(crc.result[0], refmodel::crc32_words(&vec![0u32; 2048]), "partial transfer survived soft reset");
    d.close().unwrap();
}

#[test]
fn queue_backpressure_and_ordering() {
    let mut d = open_default(Be::Rtl);
    let s = d.alloc(MemKind::DeviceSram, 4096).unwrap();
    // 40 fills back-to-back: the runtime must never overflow the 4-deep queue
    let tickets: Vec<_> = (0..40u32)
        .map(|i| d.submit(&Work::DmaFill { dst: s.addr + 64 * (i % 64), len: 64, pattern: i }).unwrap())
        .collect();
    for t in tickets {
        assert!(d.wait(t, 10_000_000).unwrap().status.is_ok());
    }
    let c = d.counters().unwrap();
    assert_eq!(c.get(regs::TC_CMDQ_DROPS), 0);
    assert_eq!(c.get(regs::TC_CMD_SUBMITTED), c.get(regs::TC_CPL_POSTED));
    // deliberate overflow with raw submits is detected and counted, never silently lost
    for _ in 0..6 {
        d.submit_raw(&Work::DmaFill { dst: s.addr, len: 4096, pattern: 1 }.to_command(2, 0x7000)).unwrap();
    }
    let st = d.reg(regs::MGMT_BASE + regs::MGMT_HCMDQ_STATUS).unwrap();
    let drops = d.counters().unwrap().get(regs::TC_CMDQ_DROPS);
    assert!(drops >= 1 && st & (1 << 16) != 0, "overflow flagged (status 0x{st:x}, drops {drops})");
}

#[test]
fn host_latency_sensitivity_is_monotonic() {
    let mut cyc = vec![];
    for lat in [1u32, 8, 32] {
        let mut d = open(Be::Rtl, &OpenCfg { latency: lat, ..Default::default() });
        let h = d.alloc(MemKind::Host, 4096).unwrap();
        let s = d.alloc(MemKind::DeviceSram, 4096).unwrap();
        let c = d.run(&Work::DmaCopy { src: h.addr, dst: s.addr, len: 4096 }).unwrap();
        assert!(c.status.is_ok());
        cyc.push(c.result[1]);
        d.close().unwrap();
    }
    assert!(cyc[0] < cyc[1] && cyc[1] < cyc[2], "DMA cycles must grow with host latency: {cyc:?}");
}
