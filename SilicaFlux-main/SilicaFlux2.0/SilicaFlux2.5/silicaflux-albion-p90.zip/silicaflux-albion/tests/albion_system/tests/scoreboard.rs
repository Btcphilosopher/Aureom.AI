//! Randomised end-to-end transaction scoreboard: reference model vs RTL.
//!
//! The same random command stream (valid and invalid allocations, maps, copies,
//! fills, CRCs, ECC injections, raw DMAs that the hardware must stop, unsupported
//! workloads, protocol errors) is applied to both backends. Every completion is
//! compared as it happens; at the end host memory, SRAM contents (via firmware
//! CRC), RAS registers and the deterministic telemetry counters must match.
use albion_system_tests::*;
use sf_albion::*;

const DOMS: [u8; 3] = [2, 3, 4];
const ARENA: u32 = 0x10000; // 64 KiB of host memory per domain

fn arena(dom: u8) -> u32 {
    0x0100_0000 * dom as u32
}

#[derive(Clone, Copy, Debug)]
struct Sbuf {
    dom: u8,
    addr: u32,
    size: u32,
}

#[derive(Clone, Copy, Debug)]
struct Hwin {
    dom: u8,
    window: u32,
    addr: u32,
    size: u32,
    perms: u32,
}

#[derive(Default)]
struct Model {
    sram: Vec<Sbuf>,
    host: Vec<Hwin>,
}

/// A region the domain may read (r) / write (w): (addr, size, is_host).
fn regions(m: &Model, dom: u8, need: u32) -> Vec<(u32, u32, bool)> {
    let mut v: Vec<(u32, u32, bool)> = m.sram.iter().filter(|b| b.dom == dom).map(|b| (b.addr, b.size, false)).collect();
    v.extend(m.host.iter().filter(|h| h.dom == dom && h.perms & need == need).map(|h| (h.addr, h.size, true)));
    v
}

fn sub(rng: &mut Rng, base: u32, size: u32) -> (u32, u32) {
    let words = size / 4;
    let off = rng.below(words);
    let len = 1 + rng.below((words - off).min(512));
    (base + 4 * off, 4 * len)
}

fn gen(rng: &mut Rng, m: &Model, banks: u32, bank_bytes: u32) -> (u8, u8, [u32; 7]) {
    let dom = DOMS[rng.below(3) as usize];
    let mut a = [0u32; 7];
    loop {
        match rng.below(100) {
            0..=11 => {
                a[0] = match rng.below(20) {
                    0 => 0,
                    1 => 1 << 20,
                    _ => 4 * (1 + rng.below(1500)),
                };
                return (regs::OP_ALLOC, dom, a);
            }
            12..=17 => {
                let own: Vec<_> = m.sram.iter().filter(|b| b.dom == dom).collect();
                a[0] = if own.is_empty() || rng.chance(10) {
                    m.sram.first().map(|b| b.addr).unwrap_or(0x4000)
                } else {
                    own[rng.below(own.len() as u32) as usize].addr
                };
                return (regs::OP_FREE, dom, a);
            }
            18..=27 => {
                let off = 4 * rng.below(ARENA / 8);
                let size = 4 * (1 + rng.below((ARENA - off) / 8));
                a[0] = arena(dom) + off + if rng.chance(5) { 2 } else { 0 };
                a[1] = size;
                a[2] = if rng.chance(5) { 4 } else { 1 + rng.below(3) };
                return (regs::OP_MAP_HOST, dom, a);
            }
            28..=31 => {
                let own: Vec<_> = m.host.iter().filter(|h| h.dom == dom).collect();
                a[0] = if own.is_empty() || rng.chance(15) { rng.below(10) } else { own[rng.below(own.len() as u32) as usize].window };
                return (regs::OP_UNMAP_HOST, dom, a);
            }
            32..=51 => {
                let rs = regions(m, dom, 1);
                let ws = regions(m, dom, 2);
                if rs.is_empty() || ws.is_empty() {
                    continue;
                }
                let (sb, ss, _) = rs[rng.below(rs.len() as u32) as usize];
                let (db, ds, _) = ws[rng.below(ws.len() as u32) as usize];
                let (src, l1) = sub(rng, sb, ss);
                let (dst, l2) = sub(rng, db, ds);
                a[0] = src;
                a[1] = dst;
                a[2] = l1.min(l2);
                match rng.below(25) {
                    0 => a[2] = 0,
                    1 => a[2] += 2,
                    2 => a[1] = m.sram.iter().find(|b| b.dom != dom).map(|b| b.addr).unwrap_or(0x100),
                    3 => a[2] += 4096, // runs off the window
                    _ => {}
                }
                return (regs::OP_DMA_COPY, dom, a);
            }
            52..=59 => {
                let ws = regions(m, dom, 2);
                if ws.is_empty() {
                    continue;
                }
                let (db, ds, _) = ws[rng.below(ws.len() as u32) as usize];
                let (dst, len) = sub(rng, db, ds);
                a[0] = dst;
                a[1] = len;
                a[2] = rng.u32();
                return (regs::OP_DMA_FILL, dom, a);
            }
            60..=67 => {
                let own: Vec<_> = m.sram.iter().filter(|b| b.dom == dom).collect();
                if own.is_empty() {
                    continue;
                }
                let b = own[rng.below(own.len() as u32) as usize];
                let (addr, len) = sub(rng, b.addr, b.size);
                a[0] = addr;
                a[1] = if rng.chance(5) { len + 4096 } else { len };
                return (regs::OP_CRC32, dom, a);
            }
            68..=75 => {
                // inject into a live buffer word (mostly) or anywhere
                let (bank, word) = if !m.sram.is_empty() && rng.chance(85) {
                    let b = m.sram[rng.below(m.sram.len() as u32) as usize];
                    let w = (b.addr + 4 * rng.below(b.size / 4)) / 4;
                    (w * 4 / bank_bytes, w % (bank_bytes / 4))
                } else {
                    (rng.below(banks + 1), rng.below(bank_bytes / 4 + 2))
                };
                let nbits = if rng.chance(10) { 3 } else { 1 + rng.below(2) };
                let mut mask: u64 = 0;
                while mask.count_ones() < nbits {
                    mask |= 1 << rng.below(39);
                }
                a[0] = bank;
                a[1] = word;
                a[2] = mask as u32;
                a[3] = (mask >> 32) as u32;
                return (regs::OP_RAS_INJECT, if rng.chance(90) { ADMIN } else { dom }, a);
            }
            76..=78 => return (regs::OP_RAS_STATUS, dom, a),
            79..=80 => return (regs::OP_RAS_CLEAR, if rng.chance(80) { ADMIN } else { dom }, a),
            81..=91 => {
                // raw DMA: exactly one side may be invalid, the other is fully valid and clean
                let rs: Vec<_> = regions(m, dom, 1).into_iter().filter(|r| r.2).collect(); // host = never ECC-poisoned
                let ws = regions(m, dom, 2);
                if rs.is_empty() || ws.is_empty() {
                    continue;
                }
                let (sb, ss, _) = rs[rng.below(rs.len() as u32) as usize];
                let (db, ds, _) = ws[rng.below(ws.len() as u32) as usize];
                let (src, l1) = sub(rng, sb, ss);
                let (dst, l2) = sub(rng, db, ds);
                let len = l1.min(l2);
                let bad = [0x0000_0040u32, 0x2000_0000, regs::DMA_BASE, regs::HOSTMEM_BASE + 0x0F00_0000,
                           m.sram.iter().find(|b| b.dom != dom).map(|b| b.addr).unwrap_or(0x4000)][rng.below(5) as usize];
                let rdom = if rng.chance(10) { [1u8, 9][rng.below(2) as usize] } else { dom }; // domain 0 raw DMA: directed tests only
                match rng.below(3) {
                    0 => { a[0] = src; a[1] = dst; }          // both valid
                    1 => { a[0] = src; a[1] = bad; }          // destination invalid, source fully valid
                    _ => {                                    // source runs into invalid, destination valid
                        let (db2, ds2, _) = ws[rng.below(ws.len() as u32) as usize];
                        a[0] = bad;
                        a[1] = db2 + 4 * rng.below((ds2 / 4).saturating_sub(len / 4).max(1));
                        a[2] = len.min(ds2);
                        if (a[0] < a[1] + a[2]) && (a[1] < a[0] + a[2]) { continue; }
                        return (regs::OP_RAW_DMA, rdom, a);
                    }
                }
                a[2] = len;
                if (a[0] < a[1].wrapping_add(a[2])) && (a[1] < a[0].wrapping_add(a[2])) {
                    continue; // overlapping raw copies are timing-dependent by definition
                }
                if rdom != dom && rng.chance(50) {
                    continue;
                }
                return (regs::OP_RAW_DMA, rdom, a);
            }
            92..=94 => return ([regs::OP_PKT_CLASSIFY, regs::OP_VBLK_IO, regs::OP_MATMUL_INT8, 0x7F][rng.below(4) as usize], dom, a),
            95..=97 => return (regs::OP_PING, dom, a),
            98 => return (regs::OP_SELFTEST, dom, a),
            _ => return (regs::OP_TELEM_CLEAR, if rng.chance(70) { ADMIN } else { dom }, a),
        }
    }
}

fn apply(m: &mut Model, op: u8, dom: u8, a: &[u32; 7], c: &Completion) {
    if !c.status.is_ok() {
        return;
    }
    match op {
        x if x == regs::OP_ALLOC => m.sram.push(Sbuf { dom, addr: c.result[0], size: c.result[2] }),
        x if x == regs::OP_FREE => m.sram.retain(|b| !(b.dom == dom && b.addr == a[0])),
        x if x == regs::OP_MAP_HOST => m.host.push(Hwin { dom, window: c.result[0], addr: c.result[1], size: a[1], perms: a[2] }),
        x if x == regs::OP_UNMAP_HOST => m.host.retain(|h| !(h.dom == dom && h.window == a[0])),
        _ => {}
    }
}

fn run_seed(seed: u64, config: u32, nops: usize) {
    let cfg = OpenCfg { config, strap: true, ..Default::default() };
    let mut r = open(Be::Ref, &cfg);
    let mut t = open(Be::Rtl, &cfg);
    let (banks, bank_bytes) = (r.info().sram_banks, r.info().sram_bank_bytes);
    assert_eq!(r.info().feat_impl, t.info().feat_impl);
    let mut rng = Rng::new(seed);
    for d in DOMS {
        let data = rng.words((ARENA / 4) as usize);
        host_put(&mut r, arena(d), &data);
        host_put(&mut t, arena(d), &data);
    }
    let mut m = Model::default();
    let mut stats = std::collections::BTreeMap::<(u8, u8), u32>::new();
    for k in 0..nops {
        let (opc, dom, a) = gen(&mut rng, &m, banks, bank_bytes);
        let w = Work::Raw { opcode: opc, flags: if rng.chance(2) { 1 } else { 0 }, args: a };
        let cr = r.run_as(&w, dom).unwrap();
        let ct = t.run_as(&w, dom).unwrap();
        assert_eq!(comparable(&cr), comparable(&ct), "seed {seed} cfg{config} op #{k}: {w:?} dom {dom}\n ref {cr:?}\n rtl {ct:?}");
        *stats.entry((opc, cr.status.0)).or_insert(0) += 1;
        apply(&mut m, opc, dom, &a, &cr);
    }
    // final state: host memory
    for d in DOMS {
        assert_eq!(host_get(&mut r, arena(d), (ARENA / 4) as usize), host_get(&mut t, arena(d), (ARENA / 4) as usize), "seed {seed}: host arena of domain {d}");
    }
    // SRAM contents via firmware CRC (also re-checks ECC state of every live word)
    for b in m.sram.clone() {
        let w = Work::Crc32 { addr: b.addr, len: b.size };
        let (cr, ct) = (r.run_as(&w, b.dom).unwrap(), t.run_as(&w, b.dom).unwrap());
        assert_eq!(comparable(&cr), comparable(&ct), "seed {seed}: SRAM buffer {b:?}");
    }
    // RAS registers and deterministic telemetry
    for off in [regs::RAS_ERR_STATUS, regs::RAS_ERR_ADDR, regs::RAS_ERR_SYNDROME, regs::RAS_ERR_SOURCE, regs::RAS_CE_COUNT, regs::RAS_UE_COUNT] {
        assert_eq!(r.reg(regs::RAS_BASE + off).unwrap(), t.reg(regs::RAS_BASE + off).unwrap(), "seed {seed}: RAS reg 0x{off:x}");
    }
    assert_eq!(deterministic_counters(&mut r), deterministic_counters(&mut t), "seed {seed}: telemetry");
    let ok = stats.iter().filter(|((_, s), _)| *s == 0).map(|(_, n)| n).sum::<u32>();
    eprintln!("seed {seed} cfg{config}: {nops} ops, {ok} OK, {} distinct (opcode,status) pairs: {stats:?}", stats.len());
}

#[test]
fn scoreboard_min_seeds() {
    for seed in [11u64, 22, 33, 44, 55, 66] {
        run_seed(seed, 0, 160);
    }
}

#[test]
fn scoreboard_cloud_and_hpc() {
    run_seed(77, 1, 120);
    run_seed(88, 2, 120);
}
