//! Security model tests (docs/albion/security_model.md). Isolation violations are
//! critical failures: every case here asserts that a denied access had NO effect.
use albion_system_tests::*;
use sf_albion::*;

const FE_OK: u32 = regs::FE_OK;
const FE_DECERR: u32 = regs::FE_DECERR;
const FE_PERM: u32 = regs::FE_PERM;
const FE_SLVERR: u32 = regs::FE_SLVERR;

#[test]
fn host_mmio_policy_after_boot() {
    for be in Be::all() {
        let mut d = open_default(be);
        // SRAM is not host-accessible after BOOT_LOCK (firmware bank and data banks)
        for a in [0x0000_0000u32, 0x0000_0100, 0x0000_4000, 0x0000_FFFC] {
            assert_eq!(d.raw_write(a, 0xBAD0_BAD0).unwrap(), FE_PERM, "{be:?} write 0x{a:x}");
            assert_eq!(d.raw_read(a).unwrap(), (0, FE_PERM), "{be:?} read 0x{a:x}");
        }
        // privileged pages are invisible to the host
        for page in [regs::IRQ_BASE, regs::DMA_BASE, regs::PERM_BASE] {
            assert_eq!(d.raw_read(page).unwrap().1, FE_PERM, "{be:?} read 0x{page:x}");
            assert_eq!(d.raw_write(page, 1).unwrap(), FE_PERM, "{be:?} write 0x{page:x}");
        }
        // telemetry and RAS: read-only for the host
        assert_eq!(d.raw_read(regs::TELEM_BASE + regs::TELEM_NUM_COUNTERS).unwrap(), (regs::NUM_TCOUNTERS as u32, FE_OK));
        assert_eq!(d.raw_write(regs::TELEM_BASE + regs::TELEM_CTRL, 2).unwrap(), FE_PERM, "{be:?}: host cannot clear counters");
        assert_eq!(d.raw_write(regs::RAS_BASE + regs::RAS_INJ_CTRL, 1).unwrap(), FE_PERM, "{be:?}: host cannot inject directly");
        // MGMT writer rules
        assert_eq!(d.raw_write(regs::MGMT_BASE + regs::MGMT_BOOT_LOCK, 0).unwrap(), FE_SLVERR, "{be:?}: firmware-only register");
        assert_eq!(d.raw_write(regs::MGMT_BASE + regs::MGMT_FW_STATUS, 0).unwrap(), FE_SLVERR);
        assert_eq!(d.raw_write(regs::MGMT_BASE + regs::MGMT_FCPL_PUSH, 1).unwrap(), FE_SLVERR, "{be:?}: host cannot forge completions");
        assert_eq!(d.raw_write(regs::MGMT_BASE + regs::MGMT_FCMD_POP, 1).unwrap(), FE_SLVERR);
        assert_eq!(d.raw_write(regs::MGMT_BASE + regs::MGMT_CHIP_ID, 0).unwrap(), FE_SLVERR);
        assert_eq!(d.raw_write(regs::MGMT_BASE + regs::MGMT_SCRATCH, 0x1234).unwrap(), FE_OK);
        assert_eq!(d.reg(regs::MGMT_BASE + regs::MGMT_SCRATCH).unwrap(), 0x1234);
        // CORE_CTRL is ignored once locked: the core keeps running, cannot be re-loaded
        assert_eq!(d.raw_write(regs::MGMT_BASE + regs::MGMT_CORE_CTRL, 0).unwrap(), FE_OK);
        assert_eq!(d.reg(regs::MGMT_BASE + regs::MGMT_CORE_CTRL).unwrap(), 1, "{be:?}: core still running");
        assert!(d.run(&Work::Ping).unwrap().status.is_ok());
        // exact decoding, no aliasing
        for a in [0x0001_0000u32, 0x2000_0000, 0x4001_0000, 0x7FFF_FFFC] {
            assert_eq!(d.raw_read(a).unwrap().1, FE_DECERR, "{be:?} 0x{a:x} must be DECERR");
        }
        // MMIO pages outside the host allow-list are uniformly PERM (populated or not), so the
        // host cannot probe the private page layout
        for a in [0x4000_6000u32, 0x4000_F000] {
            assert_eq!(d.raw_read(a).unwrap().1, FE_PERM, "{be:?} 0x{a:x}");
        }
        assert_eq!(d.raw_read(regs::MGMT_BASE + 0x0F0).unwrap().1, FE_DECERR, "{be:?}: unpopulated MGMT offset");
        assert_eq!(d.raw_read(regs::TELEM_BASE + 0x100 + 8 * regs::NUM_TCOUNTERS as u32).unwrap().1, FE_DECERR);
        // host cannot reach host memory through the device
        assert_eq!(d.raw_read(regs::HOSTMEM_BASE).unwrap().1, FE_PERM);
        let viol = d.counters().unwrap().get(regs::TC_PERM_VIOL);
        assert_eq!(viol, 4 * 2 + 3 * 2 + 3 + 2, "{be:?}: every denied host access counted");
        d.close().unwrap();
    }
}

#[test]
fn hardware_enforces_isolation_without_firmware_validation() {
    // RAW_DMA (debug strap) skips every firmware check; the DataFabric must still stop each case.
    for be in Be::all() {
        let mut d = open(be, &OpenCfg { strap: true, ..Default::default() });
        let mine = d.alloc(MemKind::DeviceSram, 1024).unwrap(); // domain 2
        d.set_domain(3).unwrap();
        let theirs = d.alloc(MemKind::DeviceSram, 1024).unwrap();
        assert!(d.run(&Work::DmaFill { dst: theirs.addr, len: 1024, pattern: 0x7777_7777 }).unwrap().status.is_ok());
        d.set_domain(2).unwrap();
        let ro_iova = 0x0300_0000;
        assert!(map_host(&mut d, 2, ro_iova, 256, 1).status.is_ok()); // read-only host window
        host_put(&mut d, ro_iova, &[0x1111_1111; 64]);

        let cases: Vec<(u8, u32, u32, u32, Status, u32)> = vec![
            // (domain, src, dst, len, expected status, expected err addr)
            (2, mine.addr, theirs.addr, 64, Status::HW_PERM, theirs.addr),              // other tenant's SRAM
            (2, theirs.addr, mine.addr, 64, Status::HW_PERM, theirs.addr),              // read other tenant
            (2, mine.addr, 0x0000_0040, 64, Status::HW_PERM, 0x40),                     // firmware bank
            (0, mine.addr, 0x0000_0040, 64, Status::HW_PERM, 0x40),                     // even domain 0 cannot hit bank 0
            (2, mine.addr, regs::PERM_BASE + 0x108, 4, Status::HW_PERM, regs::PERM_BASE + 0x108), // window table
            (2, mine.addr, regs::HOSTMEM_BASE + ro_iova, 16, Status::HW_PERM, regs::HOSTMEM_BASE + ro_iova), // RO window
            (2, mine.addr, regs::HOSTMEM_BASE + 0x0F00_0000, 16, Status::HW_PERM, regs::HOSTMEM_BASE + 0x0F00_0000), // unmapped IOVA
            (1, mine.addr, mine.addr + 512, 16, Status::HW_PERM, mine.addr),            // HOST_ADMIN is never a DMA domain
            (0, regs::HOSTMEM_BASE + ro_iova, mine.addr, 16, Status::HW_PERM, regs::HOSTMEM_BASE + ro_iova), // dom0 no host
            (2, mine.addr, 0x2000_0000, 16, Status::HW_DECERR, 0x2000_0000),           // undecoded
            (2, mine.addr + 1000, mine.addr, 64, Status::HW_PERM, mine.addr + 1024),   // source runs off own window mid-transfer
            (2, mine.addr, mine.addr + 2, 8, Status::BAD_PARAM, 0),                     // hardware parameter check
        ];
        for (i, (dom, src, dst, len, st, ea)) in cases.into_iter().enumerate() {
            let c = d.run_as(&Work::RawDma { src, dst, len }, dom).unwrap();
            assert_eq!(c.status, st, "{be:?} case {i}");
            if st != Status::BAD_PARAM {
                assert_eq!(c.result[2], ea, "{be:?} case {i}: error address");
            }
        }
        // read-only host window can still be read
        let c = d.run(&Work::RawDma { src: regs::HOSTMEM_BASE + ro_iova, dst: mine.addr, len: 64 }).unwrap();
        assert!(c.status.is_ok(), "{be:?}");
        // the other tenant's data is intact
        d.set_domain(3).unwrap();
        let crc = d.run(&Work::Crc32 { addr: theirs.addr, len: 1024 }).unwrap();
        assert_eq!(crc.result[0], refmodel::crc32_words(&[0x7777_7777; 256]), "{be:?}: ISOLATION VIOLATION");
        d.set_domain(2).unwrap();
        // the read-only host window was not written
        assert_eq!(host_get(&mut d, ro_iova, 64), vec![0x1111_1111; 64], "{be:?}: RO window written");
        // the window table is intact: domain 2 still works, domain 3 still denied
        let c = d.run(&Work::RawDma { src: mine.addr, dst: mine.addr + 512, len: 16 }).unwrap();
        assert!(c.status.is_ok());
        // firmware still alive and boot still locked
        assert!(d.run(&Work::Ping).unwrap().status.is_ok());
        d.close().unwrap();
    }
}

#[test]
fn window_revocation_is_immediate() {
    for be in Be::all() {
        let mut d = open(be, &OpenCfg { strap: true, ..Default::default() });
        let s = d.alloc(MemKind::DeviceSram, 512).unwrap();
        let h = d.alloc(MemKind::Host, 512).unwrap();
        assert!(d.run(&Work::RawDma { src: s.addr, dst: h.addr, len: 64 }).unwrap().status.is_ok());
        assert!(d.free(&h).unwrap().is_ok());
        let c = d.run(&Work::RawDma { src: s.addr, dst: h.addr, len: 64 }).unwrap();
        assert_eq!(c.status, Status::HW_PERM, "{be:?}: unmapped host window still reachable");
        assert!(d.free(&s).unwrap().is_ok());
        let c = d.run(&Work::RawDma { src: s.addr, dst: s.addr + 256, len: 16 }).unwrap();
        assert_eq!(c.status, Status::HW_PERM, "{be:?}: freed SRAM still reachable");
        // unmap/free of something not owned
        assert_eq!(op(&mut d, regs::OP_UNMAP_HOST, 2, &[0]).status, Status::DENIED);
        assert_eq!(op(&mut d, regs::OP_FREE, 2, &[s.addr]).status, Status::DENIED);
        assert_eq!(op(&mut d, regs::OP_UNMAP_HOST, 2, &[99]).status, Status::BAD_PARAM);
        d.close().unwrap();
    }
}

#[test]
fn boot_mode_rules() {
    // Before the firmware locks boot, the host may load SRAM; afterwards it may not.
    for be in Be::all() {
        let t: Box<dyn Transport> = match be {
            Be::Ref => Box::new(refmodel::RefTransport::new(0)),
            Be::Rtl => Box::new(rtlsim::RtlSim::spawn(&rtlsim::RtlSim::default_binary(0), "ALBION_MIN", &[]).unwrap()),
        };
        let mut t = t;
        t.reset().unwrap();
        t.advance(6000).unwrap();
        let st = t.mmio_read(regs::MGMT_BASE + regs::MGMT_DEV_STATUS).unwrap().0;
        assert_eq!(st & 0x1F, 0x11, "{be:?}: init_done + boot_mode");
        assert_eq!(t.mmio_write(0x0000_4000, 0xA5A5_A5A5).unwrap(), FE_OK);
        assert_eq!(t.mmio_read(0x0000_4000).unwrap(), (0xA5A5_A5A5, FE_OK));
        // privileged pages are still closed in boot mode
        assert_eq!(t.mmio_write(regs::PERM_BASE + 0x108, 0x201).unwrap(), FE_PERM);
        // the telemetry clear path is firmware-only even in boot mode
        assert_eq!(t.mmio_write(regs::TELEM_BASE, 2).unwrap(), FE_PERM);
        t.shutdown().unwrap();
    }
}

#[test]
fn soft_reset_clears_tenant_state() {
    for be in Be::all() {
        let mut d = open_default(be);
        let s = d.alloc(MemKind::DeviceSram, 1024).unwrap();
        assert!(d.run(&Work::DmaFill { dst: s.addr, len: 1024, pattern: 0x5EC2_E700 }).unwrap().status.is_ok());
        let img = firmware_image();
        d.soft_reset_and_reboot(&img).unwrap();
        // everything is re-initialised: allocation restarts at the same address and reads zero
        let t = d.alloc(MemKind::DeviceSram, 1024).unwrap();
        assert_eq!(t.addr, s.addr);
        let crc = d.run(&Work::Crc32 { addr: t.addr, len: 1024 }).unwrap();
        assert_eq!(crc.result[0], refmodel::crc32_words(&[0u32; 256]), "{be:?}: data survived reset");
        let c = d.counters().unwrap();
        assert_eq!(c.get(regs::TC_CMD_SUBMITTED), 2, "{be:?}: counters reset (ALLOC + CRC32)");
        d.close().unwrap();
    }
}
