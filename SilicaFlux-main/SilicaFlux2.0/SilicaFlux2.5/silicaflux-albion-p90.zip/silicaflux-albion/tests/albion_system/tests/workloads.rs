//! End-to-end workloads from the Project 90 brief, on both backends.
//!   A host-to-SRAM DMA, B protected memory copy, C/D/E unsupported-feature
//!   reporting, F fault injection and error reporting, plus firmware execution.
use albion_system_tests::*;
use sf_albion::*;

#[test]
fn boot_info_and_identity() {
    for be in Be::all() {
        let mut d = open_default(be);
        let i = d.info().clone();
        assert_eq!(i.chip_id, regs::CHIP_ID, "{be:?}");
        assert_eq!(i.config_name, "ALBION_MIN");
        assert_eq!(i.fw_version, 0x0001_0000);
        assert_eq!(i.feat_unavail, 0, "ALBION_MIN requests nothing unavailable");
        assert!(i.has(regs::FEAT_DMA | regs::FEAT_PERMISSION | regs::FEAT_SRAM_ECC));
        assert_eq!((i.sram_banks, i.sram_bank_bytes, i.windows, i.cmdq_depth), (4, 16384, 8, 4));
        let st = d.reg(regs::MGMT_BASE + regs::MGMT_DEV_STATUS).unwrap();
        assert_eq!(st & 0x17, 0x07, "{be:?}: init_done, core_run, boot_lock set; boot_mode clear (got 0x{st:x})");
        let p = d.run(&Work::Ping).unwrap();
        assert!(p.status.is_ok());
        assert_eq!(p.result[..2], [0x0001_0000, i.feat_impl]);
        d.close().unwrap();
    }
}

#[test]
fn workload_a_host_to_sram_dma() {
    for be in Be::all() {
        let mut d = open_default(be);
        let mut rng = Rng::new(0xA);
        for &len in &[4u32, 64, 1020, 4096, 16384] {
            let h = d.alloc(MemKind::Host, len).unwrap();
            let s = d.alloc(MemKind::DeviceSram, len).unwrap();
            let h2 = d.alloc(MemKind::Host, len).unwrap();
            let data = rng.words((len / 4) as usize);
            d.host_write(&h, 0, &data).unwrap();
            let c = d.run(&Work::DmaCopy { src: h.addr, dst: s.addr, len }).unwrap();
            assert!(c.status.is_ok(), "{be:?} len {len}: {}", c.status);
            assert_eq!(c.result[0], len, "bytes_done");
            // verify in SRAM by firmware CRC and by copying back out
            let crc = d.run(&Work::Crc32 { addr: s.addr, len }).unwrap();
            assert_eq!(crc.result[0], refmodel::crc32_words(&data), "{be:?} len {len}: firmware CRC");
            let c2 = d.run(&Work::DmaCopy { src: s.addr, dst: h2.addr, len }).unwrap();
            assert!(c2.status.is_ok());
            assert_eq!(d.host_read(&h2, 0, data.len()).unwrap(), data, "{be:?} len {len}: round trip");
            for b in [h2, s, h] {
                assert!(d.free(&b).unwrap().is_ok());
            }
        }
        d.close().unwrap();
    }
}

#[test]
fn workload_b_protected_memory_copy() {
    for be in Be::all() {
        let mut d = open_default(be);
        let mut rng = Rng::new(0xB);
        let host = d.alloc(MemKind::Host, 4096).unwrap();
        let a = d.alloc(MemKind::DeviceSram, 4096).unwrap();
        let b = d.alloc(MemKind::DeviceSram, 4096).unwrap();
        let data = rng.words(1024);
        d.host_write(&host, 0, &data).unwrap();
        assert!(d.run(&Work::DmaCopy { src: host.addr, dst: a.addr, len: 4096 }).unwrap().status.is_ok());
        // SRAM -> SRAM within the domain, at an offset
        let c = d.run(&Work::DmaCopy { src: a.addr + 256, dst: b.addr + 512, len: 2048 }).unwrap();
        assert!(c.status.is_ok(), "{be:?}: {}", c.status);
        let crc = d.run(&Work::Crc32 { addr: b.addr + 512, len: 2048 }).unwrap();
        assert_eq!(crc.result[0], refmodel::crc32_words(&data[64..64 + 512]));

        // another tenant (domain 3) owns c; domain 2 may not touch it - firmware refuses
        d.set_domain(3).unwrap();
        let other = d.alloc(MemKind::DeviceSram, 1024).unwrap();
        d.set_domain(2).unwrap();
        for w in [
            Work::DmaCopy { src: a.addr, dst: other.addr, len: 64 },
            Work::DmaCopy { src: other.addr, dst: a.addr, len: 64 },
            Work::DmaFill { dst: other.addr, len: 64, pattern: 0xDEAD },
            Work::Crc32 { addr: other.addr, len: 64 },
            Work::DmaCopy { src: a.addr, dst: 0x0000_0100, len: 64 },        // firmware bank
            Work::DmaCopy { src: a.addr, dst: regs::DMA_BASE, len: 4 },       // MMIO
            Work::DmaCopy { src: a.addr + 4096 - 64, dst: b.addr + 1024, len: 128 }, // overruns own buffer
        ] {
            let c = d.run(&w).unwrap();
            assert_eq!(c.status, Status::DENIED, "{be:?}: {w:?}");
        }
        // parameter validation
        for (w, st) in [
            (Work::DmaCopy { src: a.addr, dst: b.addr, len: 0 }, Status::BAD_PARAM),
            (Work::DmaCopy { src: a.addr, dst: b.addr, len: 6 }, Status::BAD_PARAM),
            (Work::DmaCopy { src: a.addr + 2, dst: b.addr, len: 8 }, Status::BAD_PARAM),
            (Work::DmaCopy { src: a.addr, dst: a.addr + 64, len: 128 }, Status::BAD_PARAM), // overlap
            (Work::DmaCopy { src: 0xFFFF_FFF0, dst: b.addr, len: 32 }, Status::BAD_PARAM),  // wraps
        ] {
            assert_eq!(d.run(&w).unwrap().status, st, "{be:?}: {w:?}");
        }
        // the other tenant's data was untouched (still zero from the allocation scrub)
        d.set_domain(3).unwrap();
        let crc = d.run(&Work::Crc32 { addr: other.addr, len: 1024 }).unwrap();
        assert_eq!(crc.result[0], refmodel::crc32_words(&vec![0u32; 256]), "{be:?}: isolation");
        d.set_domain(2).unwrap();
        d.close().unwrap();
    }
}

#[test]
fn workloads_c_d_e_report_unavailable_dependencies() {
    for be in Be::all() {
        for config in 0..3u32 {
            let mut d = open(be, &OpenCfg { config, ..Default::default() });
            let i = d.info().clone();
            for (w, feat) in [
                (Work::PacketClassify, regs::FEAT_PACKETFORGE),
                (Work::VirtioBlk, regs::FEAT_VIRTUALFOUNDRY),
                (Work::MatmulInt8, regs::FEAT_COMPUTEWORKS),
            ] {
                assert!(!i.has(feat), "feature 0x{feat:x} must not be reported implemented");
                let c = d.run(&w).unwrap();
                assert_eq!(c.status, Status::UNSUPPORTED, "{be:?} cfg{config} {w:?}");
            }
            let expect_unavail = match config {
                0 => 0,
                1 => regs::FEAT_PACKETFORGE | regs::FEAT_VIRTUALFOUNDRY,
                _ => regs::FEAT_PACKETFORGE | regs::FEAT_VIRTUALFOUNDRY | regs::FEAT_COMPUTEWORKS,
            };
            assert_eq!(i.feat_unavail, expect_unavail, "{be:?} cfg{config}");
            assert_eq!(i.feat_req & !i.feat_impl, i.feat_unavail);
            d.close().unwrap();
        }
    }
}

#[test]
fn workload_f_fault_injection_and_error_reporting() {
    for be in Be::all() {
        let mut d = open_default(be);
        let host = d.alloc(MemKind::Host, 256).unwrap();
        let out = d.alloc(MemKind::Host, 256).unwrap();
        let s = d.alloc(MemKind::DeviceSram, 256).unwrap();
        let data: Vec<u32> = (0..64u32).map(|i| 0x5A5A_0000 | i).collect();
        d.host_write(&host, 0, &data).unwrap();
        let bank = s.addr / 16384;
        let word0 = (s.addr % 16384) / 4;

        // admin-only, parameter checks
        assert_eq!(d.run(&Work::RasInject { bank, word: word0, mask_lo: 1, mask_hi: 0 }).unwrap().status, Status::DENIED);
        let adm = |d: &mut Device, w: Work| d.run_as(&w, ADMIN).unwrap();
        assert_eq!(adm(&mut d, Work::RasInject { bank: 0, word: 0, mask_lo: 1, mask_hi: 0 }).status, Status::DENIED, "firmware bank");
        assert_eq!(adm(&mut d, Work::RasInject { bank: 9, word: 0, mask_lo: 1, mask_hi: 0 }).status, Status::BAD_PARAM);
        assert_eq!(adm(&mut d, Work::RasInject { bank, word: word0, mask_lo: 7, mask_hi: 0 }).status, Status::BAD_PARAM, "3 bits");
        assert_eq!(adm(&mut d, Work::RasInject { bank, word: word0, mask_lo: 0, mask_hi: 0 }).status, Status::BAD_PARAM, "0 bits");

        // 1-bit flip in data bit 5 of word0 -> corrected on read
        assert!(adm(&mut d, Work::RasInject { bank, word: word0, mask_lo: 1 << 5, mask_hi: 0 }).status.is_ok());
        assert!(d.run(&Work::DmaCopy { src: host.addr, dst: s.addr, len: 256 }).unwrap().status.is_ok());
        let c = d.run(&Work::DmaCopy { src: s.addr, dst: out.addr, len: 256 }).unwrap();
        assert!(c.status.is_ok(), "{be:?}: CE must be transparent");
        assert_eq!(d.host_read(&out, 0, 64).unwrap(), data, "{be:?}: corrected data");
        let r = adm(&mut d, Work::RasStatus);
        assert_eq!(r.result[0] & 0xF3, 0x11, "{be:?}: valid CE logged (0x{:x})", r.result[0]);
        assert_eq!(r.result[1], s.addr, "{be:?}: error address");
        assert_eq!(r.result[2], 1 << 16, "{be:?}: 1 CE, 0 UE");
        // syndrome / source from the RAS page (host readable)
        let syn = d.reg(regs::RAS_BASE + regs::RAS_ERR_SYNDROME).unwrap();
        assert_eq!(syn, refmodel::secded_syndrome(1 << 5, 0) as u32, "{be:?}: syndrome");
        let src = d.reg(regs::RAS_BASE + regs::RAS_ERR_SOURCE).unwrap();
        assert_eq!(src, (2 << 8) | ((regs::M_DMARD) << 4) | bank, "{be:?}: source = DMA read, domain 2");

        // 2-bit flip (check bit + data bit) in word 3 -> uncorrectable, DMA stops at that beat
        assert!(adm(&mut d, Work::RasClear).status.is_ok());
        assert!(adm(&mut d, Work::RasInject { bank, word: word0 + 3, mask_lo: 1 << 31, mask_hi: 1 << 2 }).status.is_ok());
        assert!(d.run(&Work::DmaCopy { src: host.addr, dst: s.addr, len: 256 }).unwrap().status.is_ok());
        d.host_write(&out, 0, &[0u32; 64]).unwrap();
        let c = d.run(&Work::DmaCopy { src: s.addr, dst: out.addr, len: 256 }).unwrap();
        assert_eq!(c.status, Status::ECC_UE, "{be:?}");
        assert_eq!(c.result[0], 12, "{be:?}: 3 words delivered before the poisoned beat");
        assert_eq!(c.result[2], s.addr + 12, "{be:?}: failing address");
        let got = d.host_read(&out, 0, 64).unwrap();
        assert_eq!(&got[..3], &data[..3]);
        assert!(got[3..].iter().all(|&w| w == 0), "{be:?}: nothing written at/after the UE");
        // firmware CRC path reports the UE through a precise load-access-fault trap
        let crc = d.run(&Work::Crc32 { addr: s.addr, len: 256 }).unwrap();
        assert_eq!(crc.status, Status::ECC_UE, "{be:?}");
        assert_eq!((crc.result[1], crc.result[2]), (12, s.addr + 12));
        let r = adm(&mut d, Work::RasStatus);
        assert_eq!(r.result[0] & 0xF1, 0x21, "{be:?}: UE logged");
        assert_eq!(r.result[2] & 0xFFFF, 2, "{be:?}: two UE reads (DMA + CRC)");
        // overwrite heals the word
        assert!(d.run(&Work::DmaFill { dst: s.addr, len: 256, pattern: 0x1234_5678 }).unwrap().status.is_ok());
        assert!(d.run(&Work::Crc32 { addr: s.addr, len: 256 }).unwrap().status.is_ok());
        let cnt = d.counters().unwrap();
        assert_eq!((cnt.get(regs::TC_ECC_CE), cnt.get(regs::TC_ECC_UE)), (1, 2), "{be:?}: telemetry");
        d.close().unwrap();
    }
}

#[test]
fn firmware_execution_selftest_and_protocol_errors() {
    for be in Be::all() {
        let mut d = open_default(be);
        let st = d.run(&Work::SelfTest).unwrap();
        assert!(st.status.is_ok());
        assert_eq!(st.result[0], 7, "{be:?}: ALU, SRAM and CRC self-tests pass on the ControlCore");
        assert_eq!(d.run(&Work::Raw { opcode: 0x7E, flags: 0, args: [0; 7] }).unwrap().status, Status::BAD_OPCODE);
        assert_eq!(d.run(&Work::Raw { opcode: regs::OP_PING, flags: 3, args: [0; 7] }).unwrap().status, Status::BAD_PARAM);
        // tenant-only commands from the admin domain, admin-only from tenants
        assert_eq!(d.run_as(&Work::Raw { opcode: regs::OP_ALLOC, flags: 0, args: [64, 0, 0, 0, 0, 0, 0] }, ADMIN).unwrap().status, Status::DENIED);
        assert_eq!(d.run(&Work::TelemClear).unwrap().status, Status::DENIED);
        assert_eq!(d.run(&Work::RawDma { src: 0x4000, dst: 0x8000, len: 4 }).unwrap().status, Status::DENIED, "strap not set");
        d.close().unwrap();
    }
}

#[test]
fn selftest_checksum_matches_between_backends() {
    let mut r = open_default(Be::Ref);
    let mut t = open_default(Be::Rtl);
    let a = r.run(&Work::SelfTest).unwrap();
    let b = t.run(&Work::SelfTest).unwrap();
    assert_eq!(a.result, b.result);
}

#[test]
fn allocation_exhaustion_and_reuse() {
    for be in Be::all() {
        let mut d = open_default(be);
        // 48 KiB of data SRAM: allocate it all in 3 x 16 KiB
        let bufs: Vec<_> = (0..3).map(|_| d.alloc(MemKind::DeviceSram, 16384).unwrap()).collect();
        let c = d.run(&Work::Raw { opcode: regs::OP_ALLOC, flags: 0, args: [256, 0, 0, 0, 0, 0, 0] }).unwrap();
        assert_eq!(c.status, Status::NO_RESOURCE, "{be:?}");
        assert!(d.free(&bufs[1]).unwrap().is_ok());
        let again = d.alloc(MemKind::DeviceSram, 4096).unwrap();
        assert_eq!(again.addr, bufs[1].addr, "{be:?}: first fit reuses the hole");
        // windows: 8 total, 3 in use -> 5 more maps then NO_RESOURCE
        let mut maps = 0;
        loop {
            let c = map_host(&mut d, 2, 0x0100_0000 + maps * 0x1000, 0x1000, 3);
            if c.status == Status::NO_RESOURCE {
                break;
            }
            assert!(c.status.is_ok());
            maps += 1;
        }
        assert_eq!(maps, 5, "{be:?}");
        d.close().unwrap();
    }
}

#[test]
fn freed_memory_is_scrubbed_before_reuse() {
    for be in Be::all() {
        let mut d = open_default(be);
        let s = d.alloc(MemKind::DeviceSram, 1024).unwrap();
        assert!(d.run(&Work::DmaFill { dst: s.addr, len: 1024, pattern: 0xC0FF_EE00 }).unwrap().status.is_ok());
        assert!(d.free(&s).unwrap().is_ok());
        d.set_domain(5).unwrap();
        let t = d.alloc(MemKind::DeviceSram, 1024).unwrap();
        assert_eq!(t.addr, s.addr);
        let crc = d.run(&Work::Crc32 { addr: t.addr, len: 1024 }).unwrap();
        assert_eq!(crc.result[0], refmodel::crc32_words(&[0u32; 256]), "{be:?}: previous tenant's data visible");
        d.close().unwrap();
    }
}

#[test]
fn host_iommu_fault_propagates() {
    for be in Be::all() {
        let mut d = open_default(be);
        let s = d.alloc(MemKind::DeviceSram, 256).unwrap();
        let iova = 0x0200_0000;
        assert!(map_host(&mut d, 2, iova, 256, 3).status.is_ok());
        d.transport().add_host_fault(iova + 128, 4).unwrap();
        host_put(&mut d, iova, &(0..64).collect::<Vec<u32>>());
        let c = d.run(&Work::DmaCopy { src: regs::HOSTMEM_BASE + iova, dst: s.addr, len: 256 }).unwrap();
        assert_eq!(c.status, Status::HOST_FAULT, "{be:?}");
        assert_eq!((c.result[0], c.result[2]), (128, regs::HOSTMEM_BASE + iova + 128));
        d.close().unwrap();
    }
}
