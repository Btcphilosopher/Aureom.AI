//! Debug aid: run one ISS lock-step seed and print the first divergence.
use albion_system_tests::iss::{gen_program, Iss, TraceRec};
use albion_system_tests::Rng;
use sf_albion::rtlsim::RtlSim;
use sf_albion::{regs, Transport};

fn main() {
    let seed: u64 = std::env::args().nth(1).and_then(|s| s.parse().ok()).unwrap_or(8);
    let mut rng = Rng::new(seed * 7919);
    let prog = gen_program(&mut rng, 300);
    let path = std::env::temp_dir().join(format!("iss_debug_{seed}.trace"));
    let mut t = RtlSim::spawn(&RtlSim::default_binary(0), "ALBION_MIN", &[]).unwrap();
    t.reset().unwrap();
    t.advance(5000).unwrap();
    t.mmio_write_burst(0, &prog).unwrap();
    t.set_trace(Some(path.to_str().unwrap())).unwrap();
    t.mmio_write(regs::MGMT_BASE + regs::MGMT_CORE_CTRL, 1).unwrap();
    let r = t.run_until_trap(3, 400_000).unwrap();
    t.set_trace(None).unwrap();
    let rtl: Vec<TraceRec> = std::fs::read_to_string(&path).unwrap().lines().filter_map(TraceRec::parse).collect();
    let gold = Iss::new(64 * 1024, &prog).run(100_000);
    println!("rtl found ebreak={:?} rtl records={} iss records={}", r, rtl.len(), gold.len());
    for (k, (a, b)) in gold.iter().zip(rtl.iter()).enumerate() {
        if a.key() != b.key() {
            println!("first divergence at {k}");
            for j in k.saturating_sub(4)..(k + 3).min(gold.len()).min(rtl.len()) {
                println!(" ISS {:?}\n RTL {:?}", gold[j], rtl[j]);
            }
            return;
        }
    }
    println!("no divergence in common prefix; ISS tail {:?}", gold.last());
    if let Some(lp) = gold.windows(3).position(|w| w[0].pc == 0x18 && w[1].pc == 0x1C && w[2].pc == 0x18) {
        for r in &gold[lp.saturating_sub(12)..lp + 3] {
            println!("  pc={:#06x} insn={:#010x} we={} rd=x{} val={:#x} trap={} cause={}", r.pc, r.insn, r.rd_we, r.rd, r.wdata, r.trap, r.cause);
        }
        return;
    }
    if let Some(first_loop) = gold.iter().position(|r| r.pc == 0x18) {
        let k = gold[first_loop..].iter().position(|r| r.pc == 0x1C).map(|x| x + first_loop).unwrap_or(first_loop);
        let start = gold.iter().take(k + 6).enumerate().filter(|(_, r)| r.pc == 0x10).map(|(i, _)| i).last().unwrap_or(0);
        for r in &gold[start.saturating_sub(4)..(start + 10).min(gold.len())] {
            println!("  pc={:#06x} insn={:#010x} we={} rd=x{} val={:#x} trap={} cause={}", r.pc, r.insn, r.rd_we, r.rd, r.wdata, r.trap, r.cause);
        }
    }
    println!("RTL tail {:?}", &rtl[rtl.len().saturating_sub(3)..]);
}

#[allow(dead_code)]
fn dump_prefix() {}
