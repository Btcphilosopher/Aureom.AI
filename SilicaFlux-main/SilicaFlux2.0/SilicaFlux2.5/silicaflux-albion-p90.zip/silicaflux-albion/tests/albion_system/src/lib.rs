//! Shared helpers for the SilicaFlux Albion system tests.
//!
//! Every test runs on both backends unless it is inherently RTL-only (timing,
//! reset mid-transfer, ISS lock-step). The RTL simulator binaries are produced by
//! `make albion-sim`; a missing binary is a hard failure, never a skip.
pub mod iss;

use sf_albion::*;
use std::path::PathBuf;

pub const ADMIN: u8 = 1;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Be {
    Ref,
    Rtl,
}

impl Be {
    pub fn all() -> [Be; 2] {
        [Be::Ref, Be::Rtl]
    }
    pub fn name(self) -> &'static str {
        match self {
            Be::Ref => "reference",
            Be::Rtl => "rtl",
        }
    }
}

pub fn firmware_image() -> Vec<u8> {
    let p = std::env::var("SF_ALBION_FW")
        .map(PathBuf::from)
        .unwrap_or_else(|_| sf_albion::repo_root().join("build/firmware/albion_fw.bin"));
    std::fs::read(&p).unwrap_or_else(|e| panic!("firmware {} missing ({e}); run make albion-firmware", p.display()))
}

pub struct OpenCfg {
    pub config: u32,
    pub strap: bool,
    pub latency: u32,
    pub domain: u8,
}

impl Default for OpenCfg {
    fn default() -> Self {
        OpenCfg { config: 0, strap: false, latency: 1, domain: 2 }
    }
}

pub fn open(be: Be, c: &OpenCfg) -> Device {
    let backend = match be {
        Be::Ref => Backend::Reference,
        Be::Rtl => {
            let bin = sf_albion::rtlsim::RtlSim::default_binary(c.config);
            assert!(bin.exists(), "RTL simulator {} missing: run `make albion-sim`", bin.display());
            Backend::RtlSim { binary: Some(bin) }
        }
    };
    Device::open(&OpenOptions {
        backend,
        config: c.config,
        firmware: None,
        domain: c.domain,
        debug_strap: c.strap,
        host_latency: c.latency,
        verify_firmware: true,
    })
    .unwrap_or_else(|e| panic!("open {} cfg{}: {e}", be.name(), c.config))
}

pub fn open_default(be: Be) -> Device {
    open(be, &OpenCfg::default())
}

/// xorshift64* - deterministic, dependency-free.
#[derive(Clone)]
pub struct Rng(u64);

impl Rng {
    pub fn new(seed: u64) -> Rng {
        Rng(seed.wrapping_mul(0x9E37_79B9_7F4A_7C15) | 1)
    }
    pub fn next(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.0 = x;
        x.wrapping_mul(0x2545_F491_4F6C_DD1D)
    }
    pub fn u32(&mut self) -> u32 {
        (self.next() >> 32) as u32
    }
    pub fn below(&mut self, n: u32) -> u32 {
        if n == 0 {
            0
        } else {
            (self.next() % n as u64) as u32
        }
    }
    pub fn chance(&mut self, pct: u32) -> bool {
        self.below(100) < pct
    }
    pub fn words(&mut self, n: usize) -> Vec<u32> {
        (0..n).map(|_| self.u32()).collect()
    }
}

/// Raw mailbox op with explicit domain.
pub fn op(dev: &mut Device, opcode: u8, dom: u8, args: &[u32]) -> Completion {
    let mut a = [0u32; 7];
    a[..args.len()].copy_from_slice(args);
    dev.run_as(&Work::Raw { opcode, flags: 0, args: a }, dom)
        .unwrap_or_else(|e| panic!("op 0x{opcode:02x}: {e}"))
}

/// Map a host IOVA range for `dom` (raw MAP_HOST).
pub fn map_host(dev: &mut Device, dom: u8, iova: u32, size: u32, perms: u32) -> Completion {
    op(dev, regs::OP_MAP_HOST, dom, &[iova, size, perms])
}

pub fn host_put(dev: &mut Device, iova: u32, data: &[u32]) {
    dev.transport().host_write(iova, data).unwrap();
}

pub fn host_get(dev: &mut Device, iova: u32, n: usize) -> Vec<u32> {
    dev.transport().host_read(iova, n).unwrap()
}

/// Fields of a completion that are architecturally deterministic for `opcode`.
pub fn comparable(c: &Completion) -> (u8, u8, u32, Option<u32>, u32) {
    let timing_r1 = matches!(c.opcode, x if x == regs::OP_DMA_COPY || x == regs::OP_DMA_FILL || x == regs::OP_RAW_DMA);
    let r2 = if c.opcode == regs::OP_PING { 0 } else { c.result[2] };
    (c.opcode, c.status.0, c.result[0], if timing_r1 { None } else { Some(c.result[1]) }, r2)
}

pub fn deterministic_counters(dev: &mut Device) -> Vec<(&'static str, u64)> {
    let c = dev.counters().unwrap();
    Counters::deterministic_indices().into_iter().map(|i| (regs::TELEMETRY_NAMES[i], c.get(i))).collect()
}
