//! RV32I + Zicsr instruction-set simulator (golden model for the ControlCore) and a
//! random program generator for lock-step comparison against the RTL retirement trace.
//!
//! Architectural behaviour modelled exactly as specified for sf_albion_controlcore:
//! machine mode only; traps 0,1,2,3,4,5,6,7,11; mtvec direct; CSR set as listed in the
//! RTL header. Memory map seen by the core: SRAM [0, sram_bytes), undecoded holes
//! -> access fault, host window 0x8000_0000.. (reads 0 unless written, IOVA >= 1 GiB faults).
use crate::Rng;
use std::collections::HashMap;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TraceRec {
    pub pc: u32,
    pub insn: u32,
    pub rd_we: bool,
    pub rd: u32,
    pub wdata: u32,
    pub trap: bool,
    pub cause: u32,
}

impl TraceRec {
    pub fn parse(line: &str) -> Option<TraceRec> {
        let f: Vec<&str> = line.split_whitespace().collect();
        if f.len() != 7 {
            return None;
        }
        let h = |s: &str| u32::from_str_radix(s, 16).ok();
        Some(TraceRec {
            pc: h(f[0])?,
            insn: h(f[1])?,
            rd_we: f[2] == "1",
            rd: f[3].parse().ok()?,
            wdata: h(f[4])?,
            trap: f[5] == "1",
            cause: h(f[6])?,
        })
    }
    /// Fields that are architecturally defined for this record.
    pub fn key(&self) -> (u32, bool, u32, Option<(u32, bool, u32, u32)>) {
        if self.trap {
            (self.pc, true, self.cause, None)
        } else {
            let (rd, w) = if self.rd_we { (self.rd, self.wdata) } else { (0, 0) };
            (self.pc, false, 0, Some((self.insn, self.rd_we, rd, w)))
        }
    }
}

pub struct Iss {
    pub pc: u32,
    pub x: [u32; 32],
    mem: HashMap<u32, u8>,
    sram_bytes: u32,
    mstatus_mie: bool,
    mstatus_mpie: bool,
    mie_meie: bool,
    mtvec: u32,
    mscratch: u32,
    mepc: u32,
    mcause: u32,
    mtval: u32,
    minstret: u64,
}

enum Ev {
    Retire { rd: u32, val: Option<u32>, next: u32 },
    Trap { cause: u32, tval: u32 },
}

impl Iss {
    pub fn new(sram_bytes: u32, program: &[u32]) -> Iss {
        let mut mem = HashMap::new();
        for (i, w) in program.iter().enumerate() {
            for (b, v) in w.to_le_bytes().iter().enumerate() {
                mem.insert(4 * i as u32 + b as u32, *v);
            }
        }
        Iss {
            pc: 0,
            x: [0; 32],
            mem,
            sram_bytes,
            mstatus_mie: false,
            mstatus_mpie: false,
            mie_meie: false,
            mtvec: 0,
            mscratch: 0,
            mepc: 0,
            mcause: 0,
            mtval: 0,
            minstret: 0,
        }
    }

    fn mapped(&self, a: u32) -> Result<(), ()> {
        if a < self.sram_bytes || (a >= 0x8000_0000 && (a & 0x7FFF_FFFF) < 0x4000_0000) {
            Ok(())
        } else {
            Err(())
        }
    }
    fn rd8(&self, a: u32) -> u8 {
        self.mem.get(&a).copied().unwrap_or(0)
    }
    fn load(&self, a: u32, n: u32) -> Result<u32, ()> {
        self.mapped(a & !3)?;
        let mut v = 0u32;
        for i in 0..n {
            v |= (self.rd8(a + i) as u32) << (8 * i);
        }
        Ok(v)
    }
    fn store(&mut self, a: u32, n: u32, v: u32) -> Result<(), ()> {
        self.mapped(a & !3)?;
        for i in 0..n {
            self.mem.insert(a + i, (v >> (8 * i)) as u8);
        }
        Ok(())
    }

    fn csr_read(&self, a: u32) -> Option<u32> {
        Some(match a {
            0x300 => (3 << 11) | ((self.mstatus_mpie as u32) << 7) | ((self.mstatus_mie as u32) << 3),
            0x301 => 0x4000_0100,
            0x304 => (self.mie_meie as u32) << 11,
            0x305 => self.mtvec,
            0x340 => self.mscratch,
            0x341 => self.mepc,
            0x342 => self.mcause,
            0x343 => self.mtval,
            0x344 => 0,
            0xB02 | 0xC02 => self.minstret as u32,
            0xB82 | 0xC82 => (self.minstret >> 32) as u32,
            0xF11 | 0xF12 | 0xF14 => 0,
            0xF13 => 0x90,
            _ => return None, // cycle CSRs are not modelled (timing-dependent)
        })
    }
    fn csr_write(&mut self, a: u32, v: u32) {
        match a {
            0x300 => {
                self.mstatus_mie = v & 8 != 0;
                self.mstatus_mpie = v & 0x80 != 0;
            }
            0x304 => self.mie_meie = v & (1 << 11) != 0,
            0x305 => self.mtvec = v & !3,
            0x340 => self.mscratch = v,
            0x341 => self.mepc = v & !3,
            0x342 => self.mcause = v,
            0x343 => self.mtval = v,
            _ => {}
        }
    }

    fn exec(&mut self) -> Ev {
        let pc = self.pc;
        if self.mapped(pc).is_err() {
            return Ev::Trap { cause: 1, tval: pc };
        }
        let ir = self.load(pc, 4).unwrap();
        let op = ir & 0x7F;
        let rd = (ir >> 7) & 31;
        let f3 = (ir >> 12) & 7;
        let rs1 = (ir >> 15) & 31;
        let rs2 = (ir >> 20) & 31;
        let f7 = ir >> 25;
        let a = self.x[rs1 as usize];
        let b = self.x[rs2 as usize];
        let imm_i = (ir as i32 >> 20) as u32;
        let imm_s = (((ir as i32 >> 25) << 5) as u32) | ((ir >> 7) & 31);
        let imm_b = ((((ir as i32) >> 31) << 12) as u32) | (((ir >> 7) & 1) << 11) | (((ir >> 25) & 0x3F) << 5) | (((ir >> 8) & 0xF) << 1);
        let imm_u = ir & 0xFFFF_F000;
        let imm_j = ((((ir as i32) >> 31) << 20) as u32) | (ir & 0xFF000) | (((ir >> 20) & 1) << 11) | (((ir >> 21) & 0x3FF) << 1);
        let ill = Ev::Trap { cause: 2, tval: ir };
        let next = pc.wrapping_add(4);
        let jump = |t: u32| -> Option<Ev> { if t & 3 != 0 { Some(Ev::Trap { cause: 0, tval: t }) } else { None } };
        if ir & 3 != 3 {
            return ill;
        }
        let alu = |f3: u32, a: u32, b: u32, alt: bool| -> u32 {
            match f3 {
                0 => if alt { a.wrapping_sub(b) } else { a.wrapping_add(b) },
                1 => a << (b & 31),
                2 => ((a as i32) < (b as i32)) as u32,
                3 => (a < b) as u32,
                4 => a ^ b,
                5 => if alt { ((a as i32) >> (b & 31)) as u32 } else { a >> (b & 31) },
                6 => a | b,
                _ => a & b,
            }
        };
        match op {
            0x37 => Ev::Retire { rd, val: Some(imm_u), next },
            0x17 => Ev::Retire { rd, val: Some(pc.wrapping_add(imm_u)), next },
            0x6F => {
                let t = pc.wrapping_add(imm_j);
                jump(t).unwrap_or(Ev::Retire { rd, val: Some(next), next: t })
            }
            0x67 => {
                if f3 != 0 {
                    return ill;
                }
                let t = a.wrapping_add(imm_i) & !1;
                jump(t).unwrap_or(Ev::Retire { rd, val: Some(next), next: t })
            }
            0x63 => {
                let take = match f3 {
                    0 => a == b,
                    1 => a != b,
                    4 => (a as i32) < (b as i32),
                    5 => (a as i32) >= (b as i32),
                    6 => a < b,
                    7 => a >= b,
                    _ => return ill,
                };
                if take {
                    let t = pc.wrapping_add(imm_b);
                    jump(t).unwrap_or(Ev::Retire { rd: 0, val: None, next: t })
                } else {
                    Ev::Retire { rd: 0, val: None, next }
                }
            }
            0x03 => {
                let ad = a.wrapping_add(imm_i);
                let (n, sext) = match f3 {
                    0 => (1, true),
                    1 => (2, true),
                    2 => (4, false),
                    4 => (1, false),
                    5 => (2, false),
                    _ => return ill,
                };
                if (n == 2 && ad & 1 != 0) || (n == 4 && ad & 3 != 0) {
                    return Ev::Trap { cause: 4, tval: ad };
                }
                match self.load(ad, n) {
                    Err(()) => Ev::Trap { cause: 5, tval: ad },
                    Ok(v) => {
                        let v = match (n, sext) {
                            (1, true) => v as u8 as i8 as i32 as u32,
                            (2, true) => v as u16 as i16 as i32 as u32,
                            _ => v,
                        };
                        Ev::Retire { rd, val: Some(v), next }
                    }
                }
            }
            0x23 => {
                if f3 > 2 {
                    return ill;
                }
                let ad = a.wrapping_add(imm_s);
                let n = 1 << f3;
                if (n == 2 && ad & 1 != 0) || (n == 4 && ad & 3 != 0) {
                    return Ev::Trap { cause: 6, tval: ad };
                }
                match self.store(ad, n, b) {
                    Err(()) => Ev::Trap { cause: 7, tval: ad },
                    Ok(()) => Ev::Retire { rd: 0, val: None, next },
                }
            }
            0x13 => {
                if f3 == 1 && f7 != 0 {
                    return ill;
                }
                if f3 == 5 && f7 != 0 && f7 != 0x20 {
                    return ill;
                }
                let v = if f3 == 0 { a.wrapping_add(imm_i) } else { alu(f3, a, imm_i, f3 == 5 && f7 == 0x20) };
                Ev::Retire { rd, val: Some(v), next }
            }
            0x33 => {
                if f7 != 0 && !(f7 == 0x20 && (f3 == 0 || f3 == 5)) {
                    return ill;
                }
                Ev::Retire { rd, val: Some(alu(f3, a, b, f7 == 0x20)), next }
            }
            0x0F => {
                if f3 > 1 {
                    return ill;
                }
                Ev::Retire { rd: 0, val: None, next }
            }
            0x73 => {
                if f3 == 0 {
                    return match ir {
                        0x0000_0073 => Ev::Trap { cause: 11, tval: 0 },
                        0x0010_0073 => Ev::Trap { cause: 3, tval: pc },
                        0x3020_0073 => {
                            self.mstatus_mie = self.mstatus_mpie;
                            self.mstatus_mpie = true;
                            Ev::Retire { rd: 0, val: None, next: self.mepc }
                        }
                        _ => ill, // WFI is never generated (no interrupt source in ISS runs)
                    };
                }
                if f3 == 4 {
                    return ill;
                }
                let csr = ir >> 20;
                let src = if f3 & 4 != 0 { rs1 } else { a };
                let writes = f3 & 3 == 1 || rs1 != 0;
                let Some(old) = self.csr_read(csr) else { return ill };
                if writes && (csr >> 10) == 3 {
                    return ill;
                }
                if writes {
                    let nv = match f3 & 3 {
                        1 => src,
                        2 => old | src,
                        _ => old & !src,
                    };
                    self.csr_write(csr, nv);
                }
                Ev::Retire { rd, val: Some(old), next }
            }
            _ => ill,
        }
    }

    /// Execute until ebreak (cause 3) or `max` records. Returns the trace.
    pub fn run(&mut self, max: usize) -> Vec<TraceRec> {
        let mut out = vec![];
        while out.len() < max {
            let pc = self.pc;
            let insn = self.load(pc, 4).unwrap_or(0);
            match self.exec() {
                Ev::Retire { rd, val, next } => {
                    let we = rd != 0 && val.is_some();
                    if we {
                        self.x[rd as usize] = val.unwrap();
                    }
                    out.push(TraceRec { pc, insn, rd_we: we, rd: if we { rd } else { 0 }, wdata: if we { val.unwrap() } else { 0 }, trap: false, cause: 0 });
                    self.minstret += 1;
                    self.pc = next;
                }
                Ev::Trap { cause, tval } => {
                    out.push(TraceRec { pc, insn, rd_we: false, rd: 0, wdata: 0, trap: true, cause });
                    self.mepc = pc;
                    self.mcause = cause;
                    self.mtval = tval;
                    self.mstatus_mpie = self.mstatus_mie;
                    self.mstatus_mie = false;
                    self.pc = self.mtvec;
                    if cause == 3 {
                        break;
                    }
                }
            }
        }
        out
    }
}

// ------------------------------------------------------------------ encoders
pub fn r(f7: u32, rs2: u32, rs1: u32, f3: u32, rd: u32, op: u32) -> u32 {
    (f7 << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op
}
pub fn i(imm: i32, rs1: u32, f3: u32, rd: u32, op: u32) -> u32 {
    (((imm as u32) & 0xFFF) << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op
}
pub fn s(imm: i32, rs2: u32, rs1: u32, f3: u32) -> u32 {
    let u = imm as u32;
    (((u >> 5) & 0x7F) << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | ((u & 31) << 7) | 0x23
}
pub fn b(imm: i32, rs2: u32, rs1: u32, f3: u32) -> u32 {
    let u = imm as u32;
    (((u >> 12) & 1) << 31) | (((u >> 5) & 0x3F) << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | (((u >> 1) & 0xF) << 8) | (((u >> 11) & 1) << 7) | 0x63
}
pub fn u(imm: u32, rd: u32, op: u32) -> u32 {
    (imm & 0xFFFF_F000) | (rd << 7) | op
}
pub fn j(imm: i32, rd: u32) -> u32 {
    let v = imm as u32;
    (((v >> 20) & 1) << 31) | (((v >> 1) & 0x3FF) << 21) | (((v >> 11) & 1) << 20) | (((v >> 12) & 0xFF) << 12) | (rd << 7) | 0x6F
}
pub fn li(rd: u32, v: u32) -> [u32; 2] {
    let lo = ((v << 20) as i32) >> 20;
    let hi = v.wrapping_sub(lo as u32);
    [u(hi, rd, 0x37), i(lo, rd, 0, rd, 0x13)]
}

pub const HANDLER: u32 = 0x10;
pub const DATA_BASE: u32 = 0x4800; // x31, inside SRAM bank 1
const RES_HANDLER: u32 = 5; // x5 reserved for the trap handler
const RES_BASE: u32 = 31; // x31 reserved as data base pointer

/// Random program: prologue, `n` random instructions/blocks, ebreak.
pub fn gen_program(rng: &mut Rng, n: usize) -> Vec<u32> {
    let mut p = vec![0u32; 8];
    p[0] = j(0x20, 0); // jump over the handler
    // handler @0x10: mepc += 4; mret
    p[4] = i(0x341, 0, 2, RES_HANDLER, 0x73); // csrrs x5, mepc, x0
    p[5] = i(4, RES_HANDLER, 0, RES_HANDLER, 0x13);
    p[6] = i(0x341, RES_HANDLER, 1, 0, 0x73); // csrrw x0, mepc, x5
    p[7] = 0x3020_0073;
    // prologue @0x20
    p.push(i(HANDLER as i32, 0, 0, RES_HANDLER, 0x13));
    p.push(i(0x305, RES_HANDLER, 1, 0, 0x73)); // csrw mtvec, x5
    p.extend(li(RES_BASE, DATA_BASE));
    for reg in 1..31u32 {
        if reg != RES_HANDLER {
            p.extend(li(reg, rng.u32()));
        }
    }
    let reg = |rng: &mut Rng| -> u32 {
        loop {
            let r = rng.below(31);
            if r != RES_HANDLER {
                return r;
            }
        }
    };
    let src = |rng: &mut Rng| -> u32 { rng.below(32) };
    // address temporaries must be real registers (x0 would silently become absolute 0)
    let tmp = |rng: &mut Rng| -> u32 {
        loop {
            let r = 1 + rng.below(30);
            if r != RES_HANDLER {
                return r;
            }
        }
    };
    for _ in 0..n {
        let k = rng.below(100);
        let (rd, r1, r2) = (reg(rng), src(rng), src(rng));
        match k {
            0..=19 => {
                let f3 = rng.below(8);
                let alt = (f3 == 0 || f3 == 5) && rng.chance(50);
                p.push(r(if alt { 0x20 } else { 0 }, r2, r1, f3, rd, 0x33));
            }
            20..=37 => {
                let f3 = rng.below(8);
                let imm = if f3 == 1 { rng.below(32) as i32 } else if f3 == 5 { (rng.below(32) | if rng.chance(50) { 0x400 } else { 0 }) as i32 } else { (rng.below(4096) as i32) - 2048 };
                p.push(i(imm, r1, f3, rd, 0x13));
            }
            38..=41 => p.push(u(rng.u32(), rd, if rng.chance(50) { 0x37 } else { 0x17 })),
            42..=55 => {
                // load relative to the data base (mostly aligned)
                let f3 = [0, 1, 2, 4, 5][rng.below(5) as usize];
                let mut off = (rng.below(1024) as i32 - 512) & !3;
                if rng.chance(15) {
                    off |= rng.below(4) as i32;
                }
                p.push(i(off, RES_BASE, f3, rd, 0x03));
            }
            56..=67 => {
                let f3 = rng.below(3);
                let mut off = (rng.below(1024) as i32 - 512) & !3;
                if rng.chance(15) {
                    off |= rng.below(4) as i32;
                }
                p.push(s(off, r2, RES_BASE, f3));
            }
            68..=77 => {
                // forward branch over 1..4 instructions (occasionally misaligned target)
                let skip = 1 + rng.below(4) as i32;
                let off = if rng.chance(5) { 4 * skip + 2 } else { 4 * (skip + 1) };
                p.push(b(off, r2, r1, [0, 1, 4, 5, 6, 7][rng.below(6) as usize]));
                for _ in 0..skip {
                    p.push(i((rng.below(64)) as i32, r1, 0, reg(rng), 0x13));
                }
            }
            78..=80 => {
                // jal forward
                let skip = 1 + rng.below(3) as i32;
                p.push(j(4 * (skip + 1), rd));
                for _ in 0..skip {
                    p.push(i(1, rd, 0, reg(rng), 0x13));
                }
            }
            81..=83 => {
                // auipc + jalr forward (bit0 is cleared by jalr; bit1 => misaligned trap)
                let t = tmp(rng);
                let extra = if rng.chance(20) { 2 } else { 0 };
                p.push(u(0, t, 0x17));
                p.push(i(12 + extra, t, 0, rd, 0x67));
                p.push(i(7, 0, 0, reg(rng), 0x13));
            }
            84..=89 => {
                // CSR traffic on safe CSRs
                let csr = [0x340, 0x300, 0x301, 0xF13, 0xF14, 0xB02, 0xC82, 0x343, 0x342][rng.below(9) as usize];
                let f3 = 1 + rng.below(3) + if rng.chance(30) { 4 } else { 0 };
                let ro = (csr >> 10) == 3;
                let f3 = if ro || csr == 0xB02 { (f3 & 4) | 2 } else { f3 };
                let r1 = if ro || csr == 0xB02 { 0 } else { r1 };
                p.push(i(csr as i32, r1, f3, rd, 0x73));
            }
            90..=93 => {
                // access faults: undecoded address / host window beyond 1 GiB
                let t = tmp(rng);
                let base = if rng.chance(50) { 0x2000_0000 } else { 0xC000_0000 };
                p.extend(li(t, base));
                if rng.chance(50) {
                    p.push(i(0, t, 2, reg(rng), 0x03));
                } else {
                    p.push(s(0, reg(rng), t, 2));
                }
            }
            94..=96 => {
                let bad = [0x0000_0000, 0xFFFF_FFFF, r(1, r2, r1, 0, rd, 0x33), i(0, r1, 3, rd, 0x03), 0x0000_4073,
                           i(0x7C0, r1, 1, rd, 0x73), i(0xF11, r1, 1, rd, 0x73), 0x0000_0001, b(8, r2, r1, 2),
                           i(0x403, r1, 1, rd, 0x13),   // SLLI with funct7 != 0
                           i(0x203, r1, 5, rd, 0x13),   // SRxI with funct7 = 0x10
                           0x1020_0073, 0x0020_0073,    // SRET / URET: not implemented (M-mode only)
                           i(0, r1, 1, rd, 0x67)][rng.below(14) as usize];   // JALR funct3 != 0
                p.push(bad);
            }
            97 => p.push(0x0000_0073), // ecall
            98 => p.push(0x0000_000F), // fence
            _ => p.push(i(0, 0, 0, 0, 0x13)), // nop
        }
    }
    p.push(0x0010_0073); // ebreak
    p
}
