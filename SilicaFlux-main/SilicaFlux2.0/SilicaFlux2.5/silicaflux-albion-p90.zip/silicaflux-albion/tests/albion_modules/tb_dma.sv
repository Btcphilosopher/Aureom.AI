// Module regression: DMA engine against a behavioural fabric model with random
// per-port latency / back-pressure and address-triggered errors. For each random
// transfer the TB computes the architectural result independently (first failing
// beat in order, read before write) and checks STATUS, BYTES_DONE, ERR_ADDR and
// the destination memory, regardless of how the engine overlapped reads and writes.
module tb_dma;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic        rg_we;
  logic [11:0] rg_off;
  logic [31:0] rg_wdata, rg_rdata;
  logic [2:0]  rg_err;
  logic        rd_req_valid, rd_req_ready, rd_rsp_valid;
  logic [31:0] rd_req_addr, rd_rsp_rdata;
  logic [2:0]  rd_rsp_err;
  logic        wr_req_valid, wr_req_ready, wr_rsp_valid;
  logic [31:0] wr_req_addr, wr_req_wdata;
  logic [2:0]  wr_rsp_err;
  logic [3:0]  domain;
  logic        ev_ok, ev_err, ev_bytes;

  sf_albion_dma #(.DEPTH(4)) dut (
    .clk, .rst_n, .rg_we, .rg_off, .rg_wdata, .rg_rdata, .rg_err,
    .rd_req_valid, .rd_req_ready, .rd_req_addr, .rd_rsp_valid, .rd_rsp_rdata, .rd_rsp_err,
    .wr_req_valid, .wr_req_ready, .wr_req_addr, .wr_req_wdata, .wr_rsp_valid, .wr_rsp_err,
    .domain_o(domain), .ev_done_ok_o(ev_ok), .ev_done_err_o(ev_err), .ev_bytes_o(ev_bytes));

  // ---------------------------------------------------------------- behavioural memory + error map
  localparam int MW = 4096;            // words
  logic [31:0] mem [MW];
  logic [31:0] golden [MW];
  int rd_fail_word, wr_fail_word;      // word index that fails (or -1)
  logic [2:0] rd_fail_code, wr_fail_code;
  int max_lat;
  int busy_pct;

  // read port: one outstanding, random accept delay and response latency
  int rd_cnt; logic rd_pend; logic [31:0] rd_a;
  int wr_cnt; logic wr_pend; logic [31:0] wr_a, wr_d;
  // back-pressure: a fresh random ready decision once per cycle
  logic rd_rdy_q, wr_rdy_q;
  always_ff @(negedge clk) begin
    rd_rdy_q <= ($urandom_range(0, 99) >= busy_pct);
    wr_rdy_q <= ($urandom_range(0, 99) >= busy_pct);
  end

  logic rd_ready_c, wr_ready_c;
  assign rd_ready_c = !rd_pend && rd_rdy_q;
  assign wr_ready_c = !wr_pend && wr_rdy_q;
  assign rd_req_ready = rd_ready_c;
  assign wr_req_ready = wr_ready_c;

  always_ff @(posedge clk) begin
    rd_rsp_valid <= 1'b0;
    wr_rsp_valid <= 1'b0;
    if (!rst_n) begin
      rd_pend <= 0; wr_pend <= 0;
    end else begin
      if (rd_req_valid && rd_ready_c) begin
        rd_pend <= 1; rd_a <= rd_req_addr; rd_cnt <= $urandom_range(0, max_lat);
      end else if (rd_pend) begin
        if (rd_cnt == 0) begin
          int w;
          w = int'(rd_a >> 2);
          rd_pend <= 0;
          rd_rsp_valid <= 1;
          rd_rsp_err <= (w == rd_fail_word) ? rd_fail_code : 3'd0;
          rd_rsp_rdata <= mem[w % MW];
        end else rd_cnt <= rd_cnt - 1;
      end
      if (wr_req_valid && wr_ready_c) begin
        wr_pend <= 1; wr_a <= wr_req_addr; wr_d <= wr_req_wdata; wr_cnt <= $urandom_range(0, max_lat);
      end else if (wr_pend) begin
        if (wr_cnt == 0) begin
          int w;
          w = int'(wr_a >> 2);
          wr_pend <= 0;
          wr_rsp_valid <= 1;
          if (w == wr_fail_word) wr_rsp_err <= wr_fail_code;
          else begin wr_rsp_err <= 3'd0; mem[w % MW] <= wr_d; end
        end else wr_cnt <= wr_cnt - 1;
      end
    end
  end

  // ---------------------------------------------------------------- register helpers
  task automatic wr(input logic [11:0] off, input logic [31:0] v);
    @(negedge clk); rg_we = 1; rg_off = off; rg_wdata = v;
    @(negedge clk); rg_we = 0;
  endtask
  task automatic rd(input logic [11:0] off, output logic [31:0] v);
    @(negedge clk); rg_we = 0; rg_off = off; #1 v = rg_rdata;
  endtask

  function automatic logic [3:0] map(input logic [2:0] fe);
    case (fe)
      3'd1: map = 4'd1; 3'd2: map = 4'd2; 3'd3: map = 4'd3; 3'd5: map = 4'd6; default: map = 4'd5;
    endcase
  endfunction

  int errors = 0, xfers = 0, err_xfers = 0;

  task automatic one_transfer(input int seed_case);
    int n, src_w, dst_w, fill, exp_idx, i;
    logic [31:0] st, bytes, eaddr, pattern;
    logic [3:0] exp_code;
    n = $urandom_range(1, 96);
    src_w = $urandom_range(0, 1023);
    dst_w = 2048 + $urandom_range(0, 1023);
    fill = ($urandom_range(0, 4) == 0);
    pattern = $urandom;
    rd_fail_word = -1; wr_fail_word = -1;
    if ($urandom_range(0, 2) == 0 && !fill) begin rd_fail_word = src_w + $urandom_range(0, n - 1); rd_fail_code = 3'($urandom_range(1, 5)); end
    if ($urandom_range(0, 2) == 0) begin wr_fail_word = dst_w + $urandom_range(0, n - 1); wr_fail_code = 3'($urandom_range(1, 5)); end
    if (rd_fail_code == 3'd0) rd_fail_code = 3'd2;
    if (wr_fail_code == 3'd0) wr_fail_code = 3'd2;
    max_lat = $urandom_range(0, 6);
    busy_pct = $urandom_range(0, 60);
    for (int k = 0; k < MW; k++) begin mem[k] = $urandom; golden[k] = mem[k]; end
    // architectural expectation
    exp_idx = n; exp_code = 4'd0;
    for (i = 0; i < n; i++) begin
      if (!fill && (src_w + i) == rd_fail_word) begin exp_idx = i; exp_code = map(rd_fail_code); break; end
      if ((dst_w + i) == wr_fail_word) begin exp_idx = i; exp_code = map(wr_fail_code); break; end
      golden[dst_w + i] = fill ? pattern : golden[src_w + i];
    end
    wr(sf_albion_regs_pkg::DMA_SRC, 32'(src_w * 4));
    wr(sf_albion_regs_pkg::DMA_DST, 32'(dst_w * 4));
    wr(sf_albion_regs_pkg::DMA_LEN, 32'(n * 4));
    wr(sf_albion_regs_pkg::DMA_DOMAIN, 32'd5);
    wr(sf_albion_regs_pkg::DMA_FILL_PATTERN, pattern);
    wr(sf_albion_regs_pkg::DMA_CTRL, fill ? 32'd3 : 32'd1);
    for (int t = 0; t < 100000; t++) begin
      rd(sf_albion_regs_pkg::DMA_STATUS, st);
      if (st[1]) break;
    end
    rd(sf_albion_regs_pkg::DMA_BYTES_DONE, bytes);
    rd(sf_albion_regs_pkg::DMA_ERR_ADDR, eaddr);
    xfers++;
    if (exp_code != 0) err_xfers++;
    if (!st[1] || st[0]) begin errors++; $display("case %0d: did not finish (status %h)", seed_case, st); end
    if (st[2] != (exp_code != 0) || st[11:8] != exp_code) begin errors++; $display("case %0d: status %h expected code %0d (n=%0d rdf=%0d wrf=%0d src=%0d dst=%0d fill=%0d)", seed_case, st, exp_code, n, rd_fail_word, wr_fail_word, src_w, dst_w, fill); end
    if (bytes != 32'(exp_idx * 4)) begin errors++; $display("case %0d: bytes %0d expected %0d", seed_case, bytes, exp_idx * 4); end
    if (exp_code != 0) begin
      logic [31:0] ea;
      ea = (!fill && (src_w + exp_idx) == rd_fail_word) ? 32'((src_w + exp_idx) * 4) : 32'((dst_w + exp_idx) * 4);
      if (eaddr != ea) begin errors++; $display("case %0d: err addr %h expected %h", seed_case, eaddr, ea); end
    end
    for (int k = 2048; k < 2048 + 1024 + 96; k++)
      if (mem[k % MW] !== golden[k % MW]) begin errors++; $display("case %0d: dst word %0d %h != %h", seed_case, k, mem[k % MW], golden[k % MW]); break; end
    // busy registers are frozen; BADPARAM path
  endtask

  initial begin
    rg_we = 0; rg_off = 0; rg_wdata = 0;
    rd_rsp_err = 0; wr_rsp_err = 0; rd_rsp_rdata = 0;
    rd_fail_code = 3'd2; wr_fail_code = 3'd2; max_lat = 0; busy_pct = 0;
    repeat (4) @(negedge clk);
    rst_n = 1;
    for (int c = 0; c < 600; c++) one_transfer(c);
    // parameter checks
    begin
      logic [31:0] st;
      wr(sf_albion_regs_pkg::DMA_LEN, 32'd6);
      wr(sf_albion_regs_pkg::DMA_CTRL, 32'd1);
      rd(sf_albion_regs_pkg::DMA_STATUS, st);
      if (st[11:8] != 4'd4 || !st[2]) begin errors++; $display("BADPARAM not reported: %h", st); end
      wr(sf_albion_regs_pkg::DMA_SRC, 32'hFFFF_FFF0);
      wr(sf_albion_regs_pkg::DMA_LEN, 32'd32);
      wr(sf_albion_regs_pkg::DMA_CTRL, 32'd1);
      rd(sf_albion_regs_pkg::DMA_STATUS, st);
      if (st[11:8] != 4'd4) begin errors++; $display("wrap not rejected: %h", st); end
    end
    $display("tb_dma: %0d transfers (%0d with injected errors), %0d errors", xfers, err_xfers, errors);
    if (errors != 0) $fatal(1, "tb_dma FAILED");
    $display("tb_dma PASS");
    $finish;
  end
endmodule
