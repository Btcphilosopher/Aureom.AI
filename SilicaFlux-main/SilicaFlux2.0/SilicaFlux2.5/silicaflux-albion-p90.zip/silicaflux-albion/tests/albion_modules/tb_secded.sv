// Module regression: SECDED (39,32). For every tested data word, all 39 single-bit
// flips must be corrected and all 741 double-bit flips must be detected as UE.
module tb_secded;
  logic [31:0] d, dout;
  logic [38:0] cw, bad;
  logic ce, ue;
  logic [6:0] syn;
  int errors = 0, checks = 0;

  sf_albion_secded_enc u_enc (.data_i(d), .cw_o(cw));
  sf_albion_secded_dec u_dec (.cw_i(bad), .data_o(dout), .ce_o(ce), .ue_o(ue), .syndrome_o(syn));

  task automatic check_word(input logic [31:0] v);
    d = v;
    #1;            // let the encoder settle before sampling cw
    bad = cw;
    #1;
    if (dout !== v || ce || ue) begin errors++; $display("clean word %h -> %h ce=%b ue=%b", v, dout, ce, ue); end
    checks++;
    for (int i = 0; i < 39; i++) begin
      bad = cw ^ (39'd1 << i);
      #1;
      if (dout !== v || !ce || ue) begin errors++; if (errors < 10) $display("1-bit %0d word %h -> %h ce=%b ue=%b", i, v, dout, ce, ue); end
      checks++;
      for (int j = i + 1; j < 39; j++) begin
        bad = cw ^ (39'd1 << i) ^ (39'd1 << j);
        #1;
        if (!ue || ce) begin errors++; if (errors < 10) $display("2-bit %0d,%0d word %h ce=%b ue=%b", i, j, v, ce, ue); end
        checks++;
      end
    end
  endtask

  initial begin
    check_word(32'h0000_0000);
    check_word(32'hFFFF_FFFF);
    check_word(32'hA5A5_5A5A);
    for (int k = 0; k < 32; k++) check_word(32'd1 << k);
    for (int k = 0; k < 300; k++) check_word($urandom);
    $display("tb_secded: %0d checks, %0d errors", checks, errors);
    if (errors != 0) $fatal(1, "tb_secded FAILED");
    $display("tb_secded PASS");
    $finish;
  end
endmodule
