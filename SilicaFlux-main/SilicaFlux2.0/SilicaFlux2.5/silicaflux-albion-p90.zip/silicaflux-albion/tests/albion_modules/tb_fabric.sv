// Module regression: DataFabric + 4 real SECDED SRAM banks + MMIO/host stub slaves
// under concurrent random traffic from all four masters.
//  * every response code is checked against a spec-level permission model
//  * data integrity is checked against a shadow memory (masters write disjoint regions)
//  * at the end the CORE reads back every SRAM word: any write that was denied but
//    still landed, or landed in the wrong place, is caught
module tb_fabric;
  localparam int NB = 4, BB = 16384, NW = 8, NM = 4, NS = NB + 2;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic [NM-1:0] m_req_valid, m_req_ready, m_req_we, m_rsp_valid;
  logic [NM*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0] m_req_wstrb, m_req_domain;
  logic [NM*3-1:0] m_rsp_err;
  logic [NW*32-1:0] win_base, win_limit;
  logic [NW*12-1:0] win_attr;
  logic boot_mode;
  logic [NS-1:0] s_req_valid, s_req_ready, s_req_we, s_rsp_valid;
  logic [NS*32-1:0] s_req_addr, s_req_wdata, s_rsp_rdata;
  logic [NS*4-1:0] s_req_wstrb, s_req_domain;
  logic [NS*2-1:0] s_req_id, s_rsp_id;
  logic [NS*3-1:0] s_rsp_err;
  logic viol, viol_we, decerr, bank_conflict;
  logic [31:0] viol_addr; logic [1:0] viol_master; logic [3:0] viol_domain;
  logic [NM-1:0] ev_m_txn, ev_m_stall; logic [NS-1:0] ev_s_txn;

  sf_albion_datafabric #(.NB(NB), .BANK_BYTES(BB), .NW(NW)) dut (
    .clk, .rst_n, .m_req_valid, .m_req_ready, .m_req_addr, .m_req_we, .m_req_wdata, .m_req_wstrb, .m_req_domain,
    .m_rsp_valid, .m_rsp_rdata, .m_rsp_err, .win_base, .win_limit, .win_attr, .boot_mode,
    .s_req_valid, .s_req_ready, .s_req_addr, .s_req_we, .s_req_wdata, .s_req_wstrb, .s_req_domain, .s_req_id,
    .s_rsp_valid, .s_rsp_rdata, .s_rsp_err, .s_rsp_id,
    .viol_o(viol), .viol_addr_o(viol_addr), .viol_master_o(viol_master), .viol_domain_o(viol_domain), .viol_we_o(viol_we),
    .decerr_o(decerr), .ev_m_txn_o(ev_m_txn), .ev_m_stall_o(ev_m_stall), .ev_s_txn_o(ev_s_txn), .ev_bank_conflict_o(bank_conflict));

  logic [NB-1:0] init_done;
  for (genvar b = 0; b < NB; b++) begin : g_bank
    sf_albion_sram_bank #(.WORDS(BB / 4)) u (
      .clk, .rst_n, .req_valid(s_req_valid[b]), .req_ready(s_req_ready[b]), .req_word(s_req_addr[b*32 + 2 +: 12]),
      .req_we(s_req_we[b]), .req_wdata(s_req_wdata[b*32 +: 32]), .req_wstrb(s_req_wstrb[b*4 +: 4]),
      .req_id(s_req_id[b*2 +: 2]), .req_domain(s_req_domain[b*4 +: 4]),
      .rsp_valid(s_rsp_valid[b]), .rsp_rdata(s_rsp_rdata[b*32 +: 32]), .rsp_err(s_rsp_err[b*3 +: 3]), .rsp_id(s_rsp_id[b*2 +: 2]),
      .inj_arm(1'b0), .inj_word('0), .inj_mask('0), .inj_hit_o(),
      .ecc_ce_o(), .ecc_ue_o(), .ecc_syndrome_o(), .ecc_word_o(), .ecc_master_o(), .ecc_domain_o(), .init_done_o(init_done[b]));
  end

  // stub slaves NB (MMIO) and NB+1 (HOST): one at a time, random latency, rdata = ~addr
  for (genvar s = NB; s < NS; s++) begin : g_stub
    logic busy, rdy, rv;
    int cnt;
    logic [1:0] id;
    logic [31:0] a;
    always_ff @(negedge clk) rdy <= ($urandom_range(0, 3) != 0);
    assign s_req_ready[s] = !busy && rdy;
    always_ff @(posedge clk) begin
      rv <= 1'b0;
      if (!rst_n) busy <= 1'b0;
      else if (s_req_valid[s] && s_req_ready[s]) begin busy <= 1'b1; id <= s_req_id[s*2 +: 2]; a <= s_req_addr[s*32 +: 32]; cnt <= $urandom_range(0, 5); end
      else if (busy) begin
        if (cnt == 0) begin busy <= 1'b0; rv <= 1'b1; end
        else cnt <= cnt - 1;
      end
    end
    assign s_rsp_valid[s]         = rv;
    assign s_rsp_id[s*2 +: 2]     = id;
    assign s_rsp_rdata[s*32 +: 32] = ~a;
    assign s_rsp_err[s*3 +: 3]    = 3'd0;
  end

  // ---------------------------------------------------------------- spec-level permission model
  function automatic logic [2:0] expect_code(input int m, input logic [31:0] a, input logic we, input logic [3:0] dom);
    logic sram, mmio, host, data_bank, win;
    logic [3:0] page;
    sram = a < 32'(NB * BB);
    mmio = a[31:16] == 16'h4000;
    host = a[31];
    page = a[15:12];
    data_bank = sram && (a / BB) >= 1;
    win = 1'b0;
    for (int w = 0; w < NW; w++) begin
      logic [11:0] at;
      at = win_attr[w*12 +: 12];
      if (at[0] && at[11:8] == dom && (we ? at[2] : at[1]) && {a[31:2], 2'b00} >= win_base[w*32 +: 32] &&
          {1'b0, a[31:2], 2'b00} + 33'd3 <= {1'b0, win_limit[w*32 +: 32]}) win = 1'b1;
    end
    if (!(sram || mmio || host)) return 3'd1;
    case (m)
      0: return 3'd0;
      3: return ((mmio && page == 0) || (mmio && !we && (page == 4 || page == 5)) || (sram && boot_mode)) ? 3'd0 : 3'd2;
      default: begin
        if (dom == 0) return data_bank ? 3'd0 : 3'd2;
        if (dom == 1) return 3'd2;
        return ((data_bank || host) && win) ? 3'd0 : 3'd2;
      end
    endcase
  endfunction

  // shadow memory: word index -> value (all SRAM starts at encode(0) = 0)
  logic [31:0] shadow [NB * BB / 4];
  int errors = 0, ops = 0, perm_seen = 0, dec_seen = 0, ok_seen = 0;
  int per_master_ops [NM];

  // SRAM word regions (per 1024-word block): 0 CORE-private, 1 constant (read-only for
  // everyone after init), 2 DMAWR-private, 3 HOST-private. Reads only target the
  // reader's own region or the constant region, so the shadow is race-free.

  // one transaction, phased on negedge so combinational ready/valid is stable
  task automatic xact(input int m, input logic [31:0] a, input logic we, input logic [31:0] wd,
                      output logic [2:0] err, output logic [31:0] got);
    @(negedge clk);
    m_req_valid[m] = 1'b1; m_req_addr[m*32 +: 32] = a; m_req_we[m] = we;
    m_req_wdata[m*32 +: 32] = wd; m_req_wstrb[m*4 +: 4] = 4'hF;
    forever begin
      #1;
      if (m_req_ready[m]) break;
      @(negedge clk);
    end
    @(negedge clk);
    m_req_valid[m] = 1'b0;
    forever begin
      #1;
      if (m_rsp_valid[m]) break;
      @(negedge clk);
    end
    err = m_rsp_err[m*3 +: 3];
    got = m_rsp_rdata[m*32 +: 32];
  endtask

  task automatic master(input int m, input int n);
    for (int k = 0; k < n; k++) begin
      logic [31:0] a, wd, got;
      logic we;
      logic [2:0] ec, err;
      int w, region, sel;
      sel = $urandom_range(0, 99);
      w = $urandom_range(0, NB * BB / 4 - 1);
      if (sel < 70) region = (m == 1) ? 1 : m;
      else region = (m == 2) ? 2 : 1;
      w = (w & ~32'h3FF) | (region * 256) | (w & 8'hFF);
      a = 32'(w) * 4;
      we = (m == 2) ? 1'b1 : (m == 1) ? 1'b0 : (region == m && $urandom_range(0, 1) == 1);
      if (sel >= 90) begin
        case ($urandom_range(0, 2))
          0: a = 32'h4000_0000 | (32'($urandom_range(0, 7)) << 12) | 32'($urandom_range(0, 255) * 4);
          1: a = 32'h8000_0000 | ($urandom & ~32'h3);
          default: a = 32'h2000_0000 + 32'($urandom_range(0, 4095) * 4);
        endcase
        we = (m == 2) ? 1'b1 : (m == 1) ? 1'b0 : $urandom_range(0, 1) == 1;
      end
      wd = $urandom;
      ec = expect_code(m, a, we, m_req_domain[m*4 +: 4]);
      xact(m, a, we, wd, err, got);
      ops++; per_master_ops[m]++;
      if (err != ec) begin errors++; if (errors < 20) $display("M%0d %s 0x%08h: err %0d expected %0d", m, we ? "W" : "R", a, err, ec); end
      if (err == 3'd2) perm_seen++; else if (err == 3'd1) dec_seen++; else ok_seen++;
      if (err == 3'd0 && a < 32'(NB * BB)) begin
        if (we) shadow[a / 4] = wd;
        else if (got !== shadow[a / 4]) begin errors++; if (errors < 20) $display("M%0d R 0x%08h: data %h expected %h", m, a, got, shadow[a / 4]); end
      end
      if (err == 3'd0 && a >= 32'(NB * BB) && !we && got !== ~a) begin errors++; $display("M%0d stub data mismatch @%h", m, a); end
      repeat ($urandom_range(0, 2)) @(negedge clk);
    end
  endtask

  logic [3:0] dom_dma;

  initial begin
    m_req_valid = '0; m_req_addr = '0; m_req_we = '0; m_req_wdata = '0; m_req_wstrb = '0;
    // domains: CORE 0, DMARD/DMAWR random tenant (or 0/1 sometimes), HOST 1
    dom_dma = 4'($urandom_range(2, 15));
    m_req_domain = {4'd1, dom_dma, dom_dma, 4'd0};
    boot_mode = 1'b1;
    // random windows; window 0 always grants the DMA domain RW on banks 1..3 for its regions
    win_attr = '0; win_base = '0; win_limit = '0;
    win_base[0 +: 32] = 32'h0000_4000; win_limit[0 +: 32] = 32'h0000_FFFF; win_attr[0 +: 12] = {dom_dma, 5'b0, 3'b111};
    for (int w = 1; w < NW; w++) begin
      logic [31:0] b;
      b = $urandom_range(0, 1) ? 32'(($urandom_range(0, 65535)) & ~3) : (32'h8000_0000 | ($urandom & ~32'h3));
      win_base[w*32 +: 32] = b;
      win_limit[w*32 +: 32] = b + $urandom_range(4, 8192);
      win_attr[w*12 +: 12] = {4'($urandom_range(0, 15)), 5'b0, 2'($urandom_range(0, 3)), 1'($urandom_range(0, 1))};
    end
    for (int i = 0; i < NB * BB / 4; i++) shadow[i] = 32'h0;
    repeat (3) @(negedge clk);
    rst_n = 1;
    wait (&init_done);
    // initialise the constant region via the CORE
    for (int blk = 0; blk < NB * BB / 4096; blk++)
      for (int i = 0; i < 256; i++) begin
        logic [31:0] a, g; logic [2:0] e;
        a = 32'((blk * 1024 + 256 + i) * 4);
        xact(0, a, 1'b1, a ^ 32'h5A5A_A5A5, e, g);
        shadow[a / 4] = a ^ 32'h5A5A_A5A5;
      end
    // random concurrent phase
    fork
      master(0, 3000);
      master(1, 3000);
      master(2, 3000);
      master(3, 3000);
    join
    // read back everything through the CORE
    for (int i = 0; i < NB * BB / 4; i++) begin
      logic [31:0] g; logic [2:0] e;
      xact(0, 32'(i * 4), 1'b0, 32'h0, e, g);
      if (e != 3'd0 || g !== shadow[i]) begin errors++; if (errors < 30) $display("final word %0d: %h expected %h (err %0d)", i, g, shadow[i], e); end
    end
    $display("tb_fabric: %0d ops (ok %0d, perm %0d, decerr %0d), per master %0d/%0d/%0d/%0d, %0d errors",
             ops, ok_seen, perm_seen, dec_seen, per_master_ops[0], per_master_ops[1], per_master_ops[2], per_master_ops[3], errors);
    if (errors != 0) $fatal(1, "tb_fabric FAILED");
    $display("tb_fabric PASS");
    $finish;
  end

  int conflicts = 0;
  always_ff @(posedge clk) if (bank_conflict) conflicts <= conflicts + 1;
  final $display("tb_fabric: bank-conflict cycles observed: %0d", conflicts);
endmodule
