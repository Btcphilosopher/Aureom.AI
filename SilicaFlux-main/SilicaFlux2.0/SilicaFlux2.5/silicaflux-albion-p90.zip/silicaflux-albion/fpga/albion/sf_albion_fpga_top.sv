// SilicaFlux Albion - board-independent FPGA integration wrapper.
//
// * Clock/reset: one board clock (clk_i), an active-low board reset (rst_ni) that is
//   synchronised inside sf_albion_cloud_top (sf_albion_rstctl), and the debug strap
//   tied LOW (production setting) unless DEBUG_STRAP is set for a lab bitstream.
// * SRAM: sf_albion_sram_macro is behavioural, so FPGA synthesis infers block RAM
//   (ECP5: DP16KD). No vendor primitive is instantiated, keeping this wrapper portable.
// * Host link: the host MMIO target port and host-memory requester port are exported
//   unchanged. A board port binds them to the board's host link (PCIe hard IP + bridge,
//   or a lab UART/JTAG-to-MMIO bridge). That board-specific bridge is NOT part of this
//   repository; no board has been targeted yet, so no FPGA operation is claimed.
module sf_albion_fpga_top #(
  parameter int          CONFIG      = 0,
  parameter bit          DEBUG_STRAP = 1'b0,
  parameter logic [31:0] BUILD_ID    = 32'h0
) (
  input  logic        clk_i,
  input  logic        rst_ni,
  input  logic        h_req_valid_i,
  output logic        h_req_ready_o,
  input  logic [31:0] h_req_addr_i,
  input  logic        h_req_we_i,
  input  logic [31:0] h_req_wdata_i,
  input  logic [3:0]  h_req_wstrb_i,
  output logic        h_rsp_valid_o,
  output logic [31:0] h_rsp_rdata_o,
  output logic [2:0]  h_rsp_err_o,
  output logic        hm_req_valid_o,
  input  logic        hm_req_ready_i,
  output logic [30:0] hm_req_addr_o,
  output logic        hm_req_we_o,
  output logic [31:0] hm_req_wdata_o,
  output logic [3:0]  hm_req_wstrb_o,
  input  logic        hm_rsp_valid_i,
  input  logic [31:0] hm_rsp_rdata_i,
  input  logic        hm_rsp_err_i,
  output logic        host_irq_o,
  output logic [2:0]  led_o            // init_done, core_run, boot_lock
);
  logic init_done, core_run, boot_lock;

  sf_albion_cloud_top #(.CONFIG(CONFIG), .BUILD_ID(BUILD_ID)) u_soc (
    .clk_i, .rst_ni, .dbg_strap_i(DEBUG_STRAP),
    .h_req_valid_i, .h_req_ready_o, .h_req_addr_i, .h_req_we_i, .h_req_wdata_i, .h_req_wstrb_i,
    .h_rsp_valid_o, .h_rsp_rdata_o, .h_rsp_err_o,
    .hm_req_valid_o, .hm_req_ready_i, .hm_req_addr_o, .hm_req_we_o, .hm_req_wdata_o, .hm_req_wstrb_o,
    .hm_rsp_valid_i, .hm_rsp_rdata_i, .hm_rsp_err_i,
    .host_irq_o,
    .init_done_o(init_done), .core_run_o(core_run), .boot_lock_o(boot_lock),
    .trace_valid_o(), .trace_pc_o(), .trace_insn_o(), .trace_rd_we_o(), .trace_rd_o(),
    .trace_rd_wdata_o(), .trace_trap_o(), .trace_cause_o());

  assign led_o = {boot_lock, core_run, init_done};
endmodule
