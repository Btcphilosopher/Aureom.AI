#!/usr/bin/env bash
# SilicaFlux Albion FPGA implementation ESTIMATE (open toolchain, no board).
#   yosys synth_ecp5 -> nextpnr-ecp5 (LFE5UM-85F, CABGA756, 50 MHz target) -> ecppack
# Produces utilisation, nextpnr timing (Fmax) and a bitstream file. Nothing is
# programmed and no host transfer is executed: results are recorded under the
# "fpga_estimate" category, never as FPGA measurements.
set -eu
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
CFG="${1:-0}"
NAME=$(python3 -c "print(['ALBION_MIN','ALBION_CLOUD','ALBION_HPC'][$CFG])")
W="$ROOT/build/fpga/$NAME"
OUT="$ROOT/reports/fpga"
mkdir -p "$W" "$OUT"
for t in yosys nextpnr-ecp5 ecppack; do command -v $t >/dev/null || { echo "UNAVAILABLE: $t not installed"; exit 2; }; done
FILES=$(sed "s|^|$ROOT/|" "$ROOT/rtl/albion/sf_albion.f" | tr '\n' ' ')
echo "== FPGA estimate $NAME (ECP5-85F)"
t0=$(date +%s)
# re-synthesise only when an RTL file is newer than the netlist
if [ ! -f "$W/albion.json" ] || [ -n "$(find $ROOT/rtl/albion $ROOT/fpga/albion -name '*.sv' -newer "$W/albion.json")" ]; then
  yosys -q -l "$W/synth.log" -p "read_verilog -sv -DSYNTHESIS $FILES $ROOT/fpga/albion/sf_albion_fpga_top.sv; \
    hierarchy -top sf_albion_fpga_top -chparam CONFIG $CFG; synth_ecp5 -top sf_albion_fpga_top -json $W/albion.json"
fi
# --timing-allow-fail: a missed target is a result to record, not a reason to stop the flow
if [ "${SKIP_PNR:-0}" != 1 ] || [ ! -f "$W/albion.config" ]; then
  nextpnr-ecp5 --um-85k --package CABGA756 --freq 50 --timing-allow-fail --json "$W/albion.json" --textcfg "$W/albion.config" \
    --report "$W/nextpnr_report.json" --seed 1 -l "$W/pnr.log" -q || { echo "nextpnr failed (see $W/pnr.log)"; exit 1; }
fi
ecppack "$W/albion.config" "$W/albion.bit"
dt=$(( $(date +%s) - t0 ))
python3 - "$W" "$OUT/$NAME.json" "$NAME" "$dt" <<'EOF'
import json, re, sys, os
w, out, name, dt = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
rep = json.load(open(os.path.join(w, "nextpnr_report.json")))
log = open(os.path.join(w, "pnr.log")).read()
util = {k: v for k, v in rep.get("utilization", {}).items() if v.get("used", 0) > 0}
fmax = {("clk_i" if "clk_i" in k else k): round(v.get("achieved", 0), 2) for k, v in rep.get("fmax", {}).items()}
# critical path: start/end points and the modules it crosses, from the nextpnr report
crit = []
for cp in rep.get("critical_paths", []):
    if cp.get("from") != cp.get("to") or "async" in str(cp.get("from")):
        continue
    path = cp.get("path", [])
    mods = []
    for seg in path:
        for key in ("from", "to"):
            cell = (seg.get(key) or {}).get("cell", "")
            m = re.search(r"u_soc\.(g_bank\[\d+\]|u_\w+)", cell)
            if m and (not mods or mods[-1] != m.group(1)):
                mods.append(m.group(1))
    total = sum(seg.get("delay", 0) for seg in path)
    crit.append({"clock": cp.get("from"), "delay_ns": round(total, 2), "modules": mods,
                 "start": (path[0].get("from") or {}).get("cell") if path else None,
                 "end": (path[-1].get("to") or {}).get("cell") if path else None})
res = {
  "category": "fpga_estimate",
  "config": name, "device": "LFE5UM-85F-CABGA756", "target_mhz": 50,
  "tools": {"yosys": os.popen("yosys -V").read().strip(), "nextpnr": os.popen("nextpnr-ecp5 --version 2>&1").read().strip()},
  "utilization": util, "fmax_mhz": fmax,
  "timing_met": all(v >= 50 for v in fmax.values()),
  "critical_paths": crit,
  "bitstream": os.path.join("build/fpga", name, "albion.bit"),
  "bitstream_bytes": os.path.getsize(os.path.join(w, "albion.bit")),
  "seconds": dt,
  "board_programmed": False, "host_transfers_executed": False,
  "caveats": ["place-and-route estimate with unconstrained IO placement; no board, no PCIe/host bridge",
              "the 50 MHz target was NOT met; the bitstream is evidence that the flow completes, not a usable lab image at 50 MHz",
              "timing is nextpnr's post-route estimate at the default speed grade; not a sign-off"],
}
json.dump(res, open(out, "w"), indent=2)
print(json.dumps({"utilization": {k: f"{v['used']}/{v['available']}" for k, v in util.items()}, "fmax_mhz": fmax}, indent=1))
EOF
