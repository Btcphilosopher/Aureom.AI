// Formal: DataFabric permission invariants, for ANY master requests, ANY window
// table contents, ANY boot_mode and ANY arbiter state. The properties are written
// against the security spec (docs/albion/security_model.md), not against the RTL.
//   P1 a DMA master never reaches the MMIO slave
//   P2 a DMA master never reaches SRAM bank 0 (firmware-private)
//   P3 a DMA request reaching an SRAM data bank or the host slave is covered by a
//      valid window of its domain with the matching R/W permission, unless the
//      domain is FIRMWARE (0) and the target is an SRAM data bank
//   P4 DMA in domain HOST_ADMIN (1) never reaches any slave; domain 0 never reaches host memory
//   P5 the HOST reaches SRAM only in boot mode, never host memory, and MMIO only on
//      page MGMT (rw) or TELEM/RAS (read)
//   P6 at most one request is granted per slave (by construction of the id field)
//      and a granted request carries the granted master's own address
module fv_fabric_perm (
  input logic        clk,
  input logic        rst_n,
  input logic [3:0]  m_req_valid,
  input logic [127:0] m_req_addr,
  input logic [3:0]  m_req_we,
  input logic [127:0] m_req_wdata,
  input logic [15:0] m_req_wstrb,
  input logic [3:0]  dma_dom,
  input logic [63:0] win_base,
  input logic [63:0] win_limit,
  input logic [23:0] win_attr,
  input logic        boot_mode,
  input logic [5:0]  s_req_ready,
  input logic [5:0]  s_rsp_valid,
  input logic [191:0] s_rsp_rdata,
  input logic [17:0] s_rsp_err,
  input logic [11:0] s_rsp_id
);
  localparam int NB = 4, BB = 16384, NW = 2, NS = 6;
  logic [3:0] m_req_ready, m_rsp_valid;
  logic [127:0] m_rsp_rdata;
  logic [11:0] m_rsp_err;
  logic [NS-1:0] s_req_valid, s_req_we;
  logic [NS*32-1:0] s_req_addr, s_req_wdata;
  logic [NS*4-1:0] s_req_wstrb, s_req_domain;
  logic [NS*2-1:0] s_req_id;
  logic [15:0] m_req_domain;
  assign m_req_domain = {4'd1, dma_dom, dma_dom, 4'd0};

  sf_albion_datafabric #(.NB(NB), .BANK_BYTES(BB), .NW(NW)) dut (
    .clk, .rst_n, .m_req_valid, .m_req_ready, .m_req_addr, .m_req_we, .m_req_wdata, .m_req_wstrb, .m_req_domain,
    .m_rsp_valid, .m_rsp_rdata, .m_rsp_err, .win_base, .win_limit, .win_attr, .boot_mode,
    .s_req_valid, .s_req_ready, .s_req_addr, .s_req_we, .s_req_wdata, .s_req_wstrb, .s_req_domain, .s_req_id,
    .s_rsp_valid, .s_rsp_rdata, .s_rsp_err, .s_rsp_id,
    .viol_o(), .viol_addr_o(), .viol_master_o(), .viol_domain_o(), .viol_we_o(), .decerr_o(),
    .ev_m_txn_o(), .ev_m_stall_o(), .ev_s_txn_o(), .ev_bank_conflict_o());

  function automatic logic covered(input logic [31:0] a, input logic we, input logic [3:0] dom);
    covered = 1'b0;
    for (int w = 0; w < NW; w++) begin
      if (win_attr[w*12] && win_attr[w*12+8 +: 4] == dom && (we ? win_attr[w*12+2] : win_attr[w*12+1]) &&
          a >= win_base[w*32 +: 32] && {1'b0, a} + 33'd3 <= {1'b0, win_limit[w*32 +: 32]})
        covered = 1'b1;
    end
  endfunction

  always @* begin
    for (int s = 0; s < NS; s++) begin
      if (s_req_valid[s]) begin
        logic [1:0] m;
        logic [31:0] a;
        logic we;
        logic [3:0] dom;
        m   = s_req_id[s*2 +: 2];
        a   = {s_req_addr[s*32 + 2 +: 30], 2'b00};
        we  = s_req_we[s];
        dom = s_req_domain[s*4 +: 4];
        // P6: forwarded fields belong to the granted master
        assert (s_req_addr[s*32 +: 32] == m_req_addr[m*32 +: 32]);
        assert (m_req_valid[m]);
        assert (dom == m_req_domain[m*4 +: 4]);
        if (m == 2'd1 || m == 2'd2) begin
          assert (s != NB);                                             // P1
          assert (s != 0);                                              // P2
          assert (dom != 4'd1);                                         // P4
          if (s == NB + 1) assert (dom != 4'd0 && covered(a, we, dom)); // P3/P4 host
          if (s >= 1 && s < NB && dom != 4'd0) assert (covered(a, we, dom)); // P3 SRAM
        end
        if (m == 2'd3) begin
          if (s < NB) assert (boot_mode);                               // P5
          assert (s != NB + 1);
          if (s == NB) assert (a[15:12] == 4'd0 || (!we && (a[15:12] == 4'd4 || a[15:12] == 4'd5)));
        end
      end
    end
  end
endmodule
