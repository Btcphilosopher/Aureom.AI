// Formal: SECDED (39,32) miter over ALL 2^32 data words. Every error pattern (none,
// 39 single, 741 double) is instantiated as a constant; `bad` is 1 iff any decoder
// violates the specification. ABC proves `bad` is constant 0 (BDD/rewriting engine:
// parity-heavy circuits are intractable for plain CDCL SAT).
module fv_secded (
  input  logic [31:0] d,
  output logic        bad
);
  logic [38:0] cw;
  sf_albion_secded_enc enc (.data_i(d), .cw_o(cw));

  localparam int NP = 1 + 39 + 741;
  logic [NP-1:0] viol;

  // pattern k -> (i, j): k = 0 none; 1..39 single i=k-1; then pairs i<j
  function automatic logic [38:0] pattern(input integer k);
    integer n;
    pattern = '0;
    if (k >= 1 && k <= 39) pattern[k - 1] = 1'b1;
    n = 40;
    for (integer i = 0; i < 39; i = i + 1)
      for (integer j = i + 1; j < 39; j = j + 1) begin
        if (n == k) begin pattern[i] = 1'b1; pattern[j] = 1'b1; end
        n = n + 1;
      end
  endfunction

  for (genvar k = 0; k < NP; k++) begin : g_p
    localparam logic [38:0] E = pattern(k);
    logic [31:0] q;
    logic ce, ue;
    logic [6:0] syn;
    sf_albion_secded_dec dec (.cw_i(cw ^ E), .data_o(q), .ce_o(ce), .ue_o(ue), .syndrome_o(syn));
    if (k == 0)       begin : g0 assign viol[k] = (q != d) || ce || ue; end
    else if (k <= 39) begin : g1 assign viol[k] = (q != d) || !ce || ue; end
    else              begin : g2 assign viol[k] = !ue || ce; end
  end
  assign bad = |viol;
endmodule
