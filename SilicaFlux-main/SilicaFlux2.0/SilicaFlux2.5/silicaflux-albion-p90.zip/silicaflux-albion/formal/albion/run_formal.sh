#!/usr/bin/env bash
# SilicaFlux Albion formal checks. Writes reports/formal/formal_results.json.
#
#  secded              ABC (BDD/rewriting) proof of a miter over ALL 2^32 data words and all
#                      781 error patterns (none / single / double). Parity-heavy, so plain
#                      CDCL SAT is not used here.
#  fabric_permission   Yosys SAT k-induction: DataFabric permission invariants P1-P6 for any
#                      requests, any window table, any boot mode, any arbiter state.
#  fifo_invariants     Yosys SAT k-induction: FIFO occupancy / pointer invariants.
#  dma_bounds_bmc      Yosys SAT bounded check (20 cycles from reset, symbolic register writes
#                      and fabric responses): DMA never leaves [SRC,SRC+LEN) / [DST,DST+LEN),
#                      never writes more than it read, FIFO never over-committed.
#  *_mutation          Non-vacuity: a deliberately broken spec/RTL MUST be refuted.
# Exit status is non-zero if any proof fails or any mutation is NOT detected.
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/reports/formal"
WORK="$ROOT/build/formal"
mkdir -p "$OUT" "$WORK"
R="$ROOT/rtl/albion"
F="$ROOT/formal/albion"
results=()
fail=0

record() { # name kind status seconds
  echo "  $1: $3 ($2, ${4}s)"
  results+=("{\"check\":\"$1\",\"kind\":\"$2\",\"status\":\"$3\",\"seconds\":$4}")
  case "$3" in PROVEN|DETECTED) ;; *) fail=1 ;; esac
}

yosys_sat() { # name top files satargs kind [expect_fail]
  local name="$1" top="$2" files="$3" args="$4" kind="$5" expect="${6:-}"
  local t0=$(date +%s)
  timeout 1800 yosys -q -l "$WORK/$name.log" -p "read_verilog -sv -formal -DSYNTHESIS $files; prep -top $top; flatten; opt_clean; async2sync; sat $args" >/dev/null 2>&1
  local st
  if grep -q "SUCCESS" "$WORK/$name.log"; then st=PROVEN; else st=REFUTED; fi
  if [ -n "$expect" ]; then [ "$st" = REFUTED ] && st=DETECTED || st=MISSED; fi
  record "$name" "$kind" "$st" $(( $(date +%s) - t0 ))
}

abc_miter() { # name files top kind [expect_fail]
  local name="$1" files="$2" top="$3" kind="$4" expect="${5:-}"
  local t0=$(date +%s)
  yosys -q -p "read_verilog -sv $files; synth -flatten -top $top; aigmap; opt_clean; write_aiger -zinit $WORK/$name.aig" >"$WORK/$name.synth.log" 2>&1
  yosys-abc -c "read_aiger $WORK/$name.aig; strash; iprove" >"$WORK/$name.log" 2>&1
  local st
  if grep -q "^UNSATISFIABLE" "$WORK/$name.log"; then st=PROVEN; else st=REFUTED; fi
  if [ -n "$expect" ]; then [ "$st" = REFUTED ] && st=DETECTED || st=MISSED; fi
  record "$name" "$kind" "$st" $(( $(date +%s) - t0 ))
}

echo "== formal ($(yosys -V))"
abc_miter secded "$R/sf_albion_secded.sv $F/fv_secded.sv" fv_secded "ABC iprove, all 2^32 words x 781 error patterns"
yosys_sat fabric_permission fv_fabric_perm "$R/sf_albion_regs_pkg.sv $R/sf_albion_datafabric.sv $F/fv_fabric_perm.sv" \
  "-tempinduct -prove-asserts -verify -set-init-zero" "k-induction, any state"
yosys_sat fifo_invariants fv_fifo "$R/sf_albion_fifo.sv $F/fv_fifo_dma.sv" \
  "-tempinduct -prove-asserts -verify -set-init-zero -set-at 1 rst_n 0" "k-induction, any state"
yosys_sat dma_bounds_bmc fv_dma "$R/sf_albion_regs_pkg.sv $R/sf_albion_fifo.sv $R/sf_albion_dma.sv $F/fv_fifo_dma.sv" \
  "-seq 20 -prove-asserts -verify -set-init-zero -set-at 1 rst_n 0" "bounded model check, 20 cycles from reset"

# non-vacuity mutations
sed 's/data_bank = is_sram \&\& (bank >= FWB);/data_bank = is_sram;/' "$R/sf_albion_datafabric.sv" > "$WORK/fabric_mut.sv"
yosys_sat fabric_mutation fv_fabric_perm "$R/sf_albion_regs_pkg.sv $WORK/fabric_mut.sv $F/fv_fabric_perm.sv" \
  "-tempinduct -prove-asserts -set-init-zero" "mutation: DMA allowed into firmware bank" expect_fail
sed "s/else              begin : g2 assign viol\[k\] = !ue || ce; end/else              begin : g2 assign viol[k] = !ue || ce || (k == 500 \&\& d == 32'hDEADBEEF); end/" \
  "$F/fv_secded.sv" > "$WORK/fv_secded_mut.sv"
abc_miter secded_mutation "$R/sf_albion_secded.sv $WORK/fv_secded_mut.sv" fv_secded "mutation: spec violated for one word" expect_fail

{
  printf '{"tool":"%s","generated":"%s","results":[' "$(yosys -V)" "$(date -u +%FT%TZ)"
  (IFS=,; printf '%s' "${results[*]}")
  printf ']}\n'
} > "$OUT/formal_results.json"
exit $fail
