// Formal: FIFO occupancy invariants (unbounded, by induction) and DMA write bounds
// (bounded model check from reset with fully symbolic register writes and fabric
// responses).
module fv_fifo (
  input logic       clk,
  input logic       rst_n,
  input logic       push,
  input logic [7:0] push_data,
  input logic       pop
);
  logic [7:0] head;
  logic [2:0] count;
  logic full, empty;
  sf_albion_fifo #(.W(8), .DEPTH(4)) dut (.clk, .rst_n, .push, .push_data, .pop, .head, .count, .full, .empty);
  // invariants live in sf_albion_fifo.sv under `ifdef FORMAL
endmodule

module fv_dma (
  input logic        clk,
  input logic        rst_n,
  input logic        rg_we,
  input logic [11:0] rg_off,
  input logic [31:0] rg_wdata,
  input logic        rd_req_ready,
  input logic        rd_rsp_valid_i,
  input logic [31:0] rd_rsp_rdata,
  input logic [2:0]  rd_rsp_err,
  input logic        wr_req_ready,
  input logic        wr_rsp_valid_i,
  input logic [2:0]  wr_rsp_err
);
  logic [31:0] rg_rdata, rd_req_addr, wr_req_addr, wr_req_wdata;
  logic [2:0] rg_err;
  logic rd_req_valid, wr_req_valid;
  logic [3:0] dom;
  // well-formed environment: a response only for an outstanding request
  logic rd_out, wr_out;
  logic rd_rsp_valid, wr_rsp_valid;
  assign rd_rsp_valid = rd_rsp_valid_i && rd_out;
  assign wr_rsp_valid = wr_rsp_valid_i && wr_out;
  always_ff @(posedge clk) begin
    if (!rst_n) begin rd_out <= 1'b0; wr_out <= 1'b0; end
    else begin
      rd_out <= (rd_out && !rd_rsp_valid) || (rd_req_valid && rd_req_ready);
      wr_out <= (wr_out && !wr_rsp_valid) || (wr_req_valid && wr_req_ready);
    end
  end

  sf_albion_dma #(.DEPTH(4)) dut (
    .clk, .rst_n, .rg_we, .rg_off, .rg_wdata, .rg_rdata, .rg_err,
    .rd_req_valid, .rd_req_ready, .rd_req_addr, .rd_rsp_valid, .rd_rsp_rdata, .rd_rsp_err,
    .wr_req_valid, .wr_req_ready, .wr_req_addr, .wr_req_wdata, .wr_rsp_valid, .wr_rsp_err,
    .domain_o(dom), .ev_done_ok_o(), .ev_done_err_o(), .ev_bytes_o());

  // invariants live in sf_albion_dma.sv under `ifdef FORMAL; this wrapper only
  // constrains the environment (a response only for an outstanding request) and
  // checks the one-outstanding-request port protocol.
  always @* begin
    assert (!(rd_out && rd_req_valid && rd_req_ready && !rd_rsp_valid));
    assert (!(wr_out && wr_req_valid && wr_req_ready && !wr_rsp_valid));
  end
endmodule
