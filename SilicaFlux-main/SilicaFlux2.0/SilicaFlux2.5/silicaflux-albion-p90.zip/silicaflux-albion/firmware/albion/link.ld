/* SilicaFlux Albion ControlCore firmware layout: everything lives in SRAM bank 0
 * (firmware-private, 16 KiB minimum across all configurations). The host loads the
 * image at address 0 while the core is held in reset; the core resets to 0. */
OUTPUT_ARCH(riscv)
ENTRY(_start)

MEMORY
{
  FWRAM (rwx) : ORIGIN = 0x00000000, LENGTH = 16K
}

_stack_top = ORIGIN(FWRAM) + LENGTH(FWRAM);
_stack_size = 2K;

SECTIONS
{
  .text : {
    KEEP(*(.text.start))
    *(.text .text.*)
  } > FWRAM
  .rodata : ALIGN(4) { *(.rodata .rodata.* .srodata .srodata.*) } > FWRAM
  .data   : ALIGN(4) { *(.data .data.* .sdata .sdata.*) } > FWRAM
  .bss (NOLOAD) : ALIGN(4) {
    _bss_start = .;
    *(.bss .bss.* .sbss .sbss.* COMMON)
    . = ALIGN(4);
    _bss_end = .;
  } > FWRAM
  _image_end = _bss_start;
  ASSERT(_bss_end + _stack_size <= _stack_top, "firmware does not fit in bank 0 with its stack")
  /DISCARD/ : { *(.comment) *(.note*) *(.riscv.attributes) *(.eh_frame*) }
}
