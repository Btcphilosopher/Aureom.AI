/*
 * SilicaFlux Albion (Project 90) ControlCore firmware.
 *
 * Role: device-side root of trust and command processor.
 *   - Owns the permission window table and the DMA engine; tenants never program
 *     hardware directly.
 *   - Serves the host<->firmware mailbox (spec/albion/regmap.json "opcodes").
 *   - Validates every request against the windows owned by the command's domain
 *     before programming the DMA engine; the DataFabric re-checks every beat in
 *     hardware (defence in depth).
 *   - Allocations are zero-filled before their window opens and scrubbed on free.
 *
 * The behaviour here is mirrored exactly by the reference backend in
 * runtime/albion/src/refmodel.rs; the system tests compare the two.
 */
#include <stdint.h>
#include "albion_regs.h"

#define FW_VERSION         0x00010000u
#define FW_STATUS_BOOTING  0x00000001u
#define FW_STATUS_READY    0x00000002u
#define FW_STATUS_FATAL    0xDEAD0000u

#define REG32(addr)   (*(volatile uint32_t *)(uintptr_t)(addr))
#define MGMT(off)     REG32(ALBION_MGMT_BASE + (off))
#define IRQ(off)      REG32(ALBION_IRQ_BASE + (off))
#define DMA(off)      REG32(ALBION_DMA_BASE + (off))
#define PERM(off)     REG32(ALBION_PERM_BASE + (off))
#define TELEM(off)    REG32(ALBION_TELEM_BASE + (off))
#define RAS(off)      REG32(ALBION_RAS_BASE + (off))

#define KIND_SRAM 1u
#define KIND_HOST 2u
#define PERM_R    1u
#define PERM_W    2u
#define MAX_WIN   16u
#define DMA_TIMEOUT_POLLS 0x01000000u

typedef struct {
    uint32_t used, domain, base, limit, perms, kind;
} window_t;

static uint32_t g_nb, g_bank_bytes, g_nw, g_feat, g_heartbeat;
static uint32_t g_data_base, g_granules;
static uint32_t g_bitmap[32];          /* up to 1024 allocation granules */
static window_t g_win[MAX_WIN];
static uint32_t g_crc_tab[16];
static uint32_t g_selftest_buf[64];

volatile uint32_t g_fault_expect, g_fault_hit, g_fault_addr;

/* ------------------------------------------------------------------ libc subset */
void *memset(void *d, int c, uint32_t n) {
    uint8_t *p = (uint8_t *)d;
    while (n--) *p++ = (uint8_t)c;
    return d;
}
void *memcpy(void *d, const void *s, uint32_t n) {
    uint8_t *p = (uint8_t *)d;
    const uint8_t *q = (const uint8_t *)s;
    while (n--) *p++ = *q++;
    return d;
}

/* ------------------------------------------------------------------ traps */
uint32_t albion_trap_handler(uint32_t mcause, uint32_t mepc, uint32_t mtval) {
    if ((mcause == 5u || mcause == 7u) && g_fault_expect) {
        /* expected access fault (e.g. uncorrectable ECC during CRC): skip the load */
        g_fault_hit = 1u;
        g_fault_addr = mtval;
        return mepc + 4u;
    }
    MGMT(ALBION_MGMT_FW_STATUS) = FW_STATUS_FATAL | (mcause & 0xFFFFu);
    MGMT(ALBION_MGMT_FW_ATTN) = 1u;
    for (;;) __asm__ volatile("wfi");
}

/* ------------------------------------------------------------------ helpers */
static uint32_t popcount32(uint32_t v) {
    uint32_t n = 0;
    while (v) { n += v & 1u; v >>= 1; }
    return n;
}

static int is_tenant(uint32_t dom) { return dom >= ALBION_DOM_TENANT_MIN && dom <= 15u; }

static void crc_init(void) {
    for (uint32_t i = 0; i < 16u; i++) {
        uint32_t c = i;
        for (int k = 0; k < 4; k++) c = (c & 1u) ? (c >> 1) ^ 0xEDB88320u : (c >> 1);
        g_crc_tab[i] = c;
    }
}

static uint32_t crc_byte(uint32_t crc, uint32_t b) {
    crc ^= b & 0xFFu;
    crc = (crc >> 4) ^ g_crc_tab[crc & 15u];
    crc = (crc >> 4) ^ g_crc_tab[crc & 15u];
    return crc;
}

static uint32_t crc_word(uint32_t crc, uint32_t w) {
    crc = crc_byte(crc, w);
    crc = crc_byte(crc, w >> 8);
    crc = crc_byte(crc, w >> 16);
    return crc_byte(crc, w >> 24);
}

static int bm_get(uint32_t g) { return (int)((g_bitmap[g >> 5] >> (g & 31u)) & 1u); }
static void bm_set(uint32_t g, int v) {
    if (v) g_bitmap[g >> 5] |= 1u << (g & 31u);
    else   g_bitmap[g >> 5] &= ~(1u << (g & 31u));
}

static void win_program(uint32_t i) {
    uint32_t off = 0x100u + (i << 4);
    if (!g_win[i].used) {
        PERM(off + 8u) = 0u;            /* invalidate first */
        PERM(off + 0u) = 0u;
        PERM(off + 4u) = 0u;
        return;
    }
    PERM(off + 0u) = g_win[i].base;
    PERM(off + 4u) = g_win[i].limit;
    PERM(off + 8u) = 1u | (g_win[i].perms << 1) | (g_win[i].domain << 8);   /* valid last */
}

static int win_free_slot(void) {
    for (uint32_t i = 0; i < g_nw; i++) if (!g_win[i].used) return (int)i;
    return -1;
}

/* window owned by dom covering [addr, addr+len) with the given perms and kind */
static int win_owned(uint32_t dom, uint32_t addr, uint32_t len, uint32_t perms, uint32_t kinds) {
    uint32_t last = addr + len - 1u;
    for (uint32_t i = 0; i < g_nw; i++) {
        const window_t *w = &g_win[i];
        if (w->used && w->domain == dom && (w->perms & perms) == perms && (w->kind & kinds) &&
            addr >= w->base && last <= w->limit)
            return (int)i;
    }
    return -1;
}

/* ------------------------------------------------------------------ DMA */
static uint32_t map_dma_err(uint32_t code) {
    switch (code) {
    case ALBION_DMAE_DECERR:   return ALBION_ST_HW_DECERR;
    case ALBION_DMAE_PERM:     return ALBION_ST_HW_PERM;
    case ALBION_DMAE_ECC_UE:   return ALBION_ST_ECC_UE;
    case ALBION_DMAE_BADPARAM: return ALBION_ST_BAD_PARAM;
    case ALBION_DMAE_HOSTERR:  return ALBION_ST_HOST_FAULT;
    default:                   return ALBION_ST_HW_SLVERR;
    }
}

static uint32_t run_dma(uint32_t dom, uint32_t src, uint32_t dst, uint32_t len,
                        uint32_t fill, uint32_t pattern, uint32_t *res) {
    DMA(ALBION_DMA_SRC) = src;
    DMA(ALBION_DMA_DST) = dst;
    DMA(ALBION_DMA_LEN) = len;
    DMA(ALBION_DMA_DOMAIN) = dom;
    DMA(ALBION_DMA_FILL_PATTERN) = pattern;
    IRQ(ALBION_IRQ_CLEAR) = ALBION_IRQ_DMA_DONE | ALBION_IRQ_DMA_ERR;
    DMA(ALBION_DMA_CTRL) = 1u | (fill ? 2u : 0u);
    uint32_t polls = 0, st;
    for (;;) {
        st = DMA(ALBION_DMA_STATUS);
        if (st & ALBION_DMA_STATUS_DONE_MASK) break;
        if (++polls == DMA_TIMEOUT_POLLS) return ALBION_ST_TIMEOUT;
        __asm__ volatile("wfi");     /* woken by DMA_DONE/DMA_ERR (or a queued command) */
    }
    IRQ(ALBION_IRQ_CLEAR) = ALBION_IRQ_DMA_DONE | ALBION_IRQ_DMA_ERR;
    res[0] = DMA(ALBION_DMA_BYTES_DONE);
    res[1] = DMA(ALBION_DMA_CYCLES);
    res[2] = DMA(ALBION_DMA_ERR_ADDR);
    if (st & ALBION_DMA_STATUS_ERROR_MASK)
        return map_dma_err((st & ALBION_DMA_STATUS_ERR_CODE_MASK) >> ALBION_DMA_STATUS_ERR_CODE_LSB);
    return ALBION_ST_OK;
}

static uint32_t scrub(uint32_t base, uint32_t len) {
    uint32_t r[3];
    return run_dma(ALBION_DOM_FIRMWARE, 0u, base, len, 1u, 0u, r);
}

/* ------------------------------------------------------------------ commands */
static uint32_t cmd_alloc(uint32_t dom, const uint32_t *a, uint32_t *res) {
    if (!is_tenant(dom)) return ALBION_ST_DENIED;
    uint32_t size = a[0];
    if (size == 0u || size > (g_granules << 8)) return ALBION_ST_BAD_PARAM;
    int w = win_free_slot();
    if (w < 0) return ALBION_ST_NO_RESOURCE;
    uint32_t need = (size + 255u) >> 8;
    uint32_t run = 0, start = 0;
    for (uint32_t g = 0; g < g_granules; g++) {
        if (bm_get(g)) { run = 0; continue; }
        if (run == 0) start = g;
        if (++run == need) {
            uint32_t base = g_data_base + (start << 8);
            uint32_t bytes = need << 8;
            uint32_t st = scrub(base, bytes);           /* zero before exposing */
            if (st != ALBION_ST_OK) return st;
            for (uint32_t k = start; k < start + need; k++) bm_set(k, 1);
            g_win[w].used = 1u;
            g_win[w].domain = dom;
            g_win[w].base = base;
            g_win[w].limit = base + bytes - 1u;
            g_win[w].perms = PERM_R | PERM_W;
            g_win[w].kind = KIND_SRAM;
            win_program((uint32_t)w);
            res[0] = base;
            res[1] = (uint32_t)w;
            res[2] = bytes;
            return ALBION_ST_OK;
        }
    }
    return ALBION_ST_NO_RESOURCE;
}

static uint32_t cmd_free(uint32_t dom, const uint32_t *a) {
    if (!is_tenant(dom)) return ALBION_ST_DENIED;
    for (uint32_t i = 0; i < g_nw; i++) {
        window_t *w = &g_win[i];
        if (w->used && w->kind == KIND_SRAM && w->domain == dom && w->base == a[0]) {
            uint32_t base = w->base, bytes = w->limit - w->base + 1u;
            w->used = 0u;
            win_program(i);                                /* revoke first */
            uint32_t st = scrub(base, bytes);
            uint32_t g0 = (base - g_data_base) >> 8, n = bytes >> 8;
            for (uint32_t k = g0; k < g0 + n; k++) bm_set(k, 0);
            return st;
        }
    }
    return ALBION_ST_DENIED;
}

static uint32_t cmd_map_host(uint32_t dom, const uint32_t *a, uint32_t *res) {
    if (!is_tenant(dom)) return ALBION_ST_DENIED;
    uint32_t iova = a[0], size = a[1], perms = a[2];
    if (size == 0u || (size & 3u) || (iova & 3u)) return ALBION_ST_BAD_PARAM;
    if (iova >= 0x80000000u || size > 0x80000000u - iova) return ALBION_ST_BAD_PARAM;
    if (perms == 0u || perms > 3u) return ALBION_ST_BAD_PARAM;
    int w = win_free_slot();
    if (w < 0) return ALBION_ST_NO_RESOURCE;
    g_win[w].used = 1u;
    g_win[w].domain = dom;
    g_win[w].base = ALBION_HOSTMEM_BASE + iova;
    g_win[w].limit = ALBION_HOSTMEM_BASE + iova + size - 1u;
    g_win[w].perms = perms;
    g_win[w].kind = KIND_HOST;
    win_program((uint32_t)w);
    res[0] = (uint32_t)w;
    res[1] = g_win[w].base;
    return ALBION_ST_OK;
}

static uint32_t cmd_unmap_host(uint32_t dom, const uint32_t *a) {
    if (!is_tenant(dom)) return ALBION_ST_DENIED;
    uint32_t i = a[0];
    if (i >= g_nw) return ALBION_ST_BAD_PARAM;
    if (!g_win[i].used || g_win[i].kind != KIND_HOST || g_win[i].domain != dom) return ALBION_ST_DENIED;
    g_win[i].used = 0u;
    win_program(i);
    return ALBION_ST_OK;
}

static uint32_t check_len(uint32_t len) {
    return (len == 0u || (len & 3u) || len > ALBION_DMA_MAX_LEN) ? ALBION_ST_BAD_PARAM : ALBION_ST_OK;
}
static int wraps(uint32_t addr, uint32_t len) { return (len - 1u) > (0xFFFFFFFFu - addr); }

static uint32_t cmd_dma_copy(uint32_t dom, const uint32_t *a, uint32_t *res) {
    uint32_t src = a[0], dst = a[1], len = a[2];
    if (!is_tenant(dom)) return ALBION_ST_DENIED;
    if (check_len(len) != ALBION_ST_OK || (src & 3u) || (dst & 3u)) return ALBION_ST_BAD_PARAM;
    if (wraps(src, len) || wraps(dst, len)) return ALBION_ST_BAD_PARAM;
    if (src <= dst + len - 1u && dst <= src + len - 1u) return ALBION_ST_BAD_PARAM;   /* overlap */
    if (win_owned(dom, src, len, PERM_R, KIND_SRAM | KIND_HOST) < 0) return ALBION_ST_DENIED;
    if (win_owned(dom, dst, len, PERM_W, KIND_SRAM | KIND_HOST) < 0) return ALBION_ST_DENIED;
    return run_dma(dom, src, dst, len, 0u, 0u, res);
}

static uint32_t cmd_dma_fill(uint32_t dom, const uint32_t *a, uint32_t *res) {
    uint32_t dst = a[0], len = a[1], pattern = a[2];
    if (!is_tenant(dom)) return ALBION_ST_DENIED;
    if (check_len(len) != ALBION_ST_OK || (dst & 3u) || wraps(dst, len)) return ALBION_ST_BAD_PARAM;
    if (win_owned(dom, dst, len, PERM_W, KIND_SRAM | KIND_HOST) < 0) return ALBION_ST_DENIED;
    return run_dma(dom, 0u, dst, len, 1u, pattern, res);
}

static uint32_t cmd_crc32(uint32_t dom, const uint32_t *a, uint32_t *res) {
    uint32_t addr = a[0], len = a[1];
    if (!is_tenant(dom)) return ALBION_ST_DENIED;
    if (check_len(len) != ALBION_ST_OK || (addr & 3u) || wraps(addr, len)) return ALBION_ST_BAD_PARAM;
    if (win_owned(dom, addr, len, PERM_R, KIND_SRAM) < 0) return ALBION_ST_DENIED;
    uint32_t crc = 0xFFFFFFFFu, st = ALBION_ST_OK, done = 0;
    g_fault_hit = 0u;
    g_fault_expect = 1u;
    for (uint32_t off = 0; off < len; off += 4u) {
        uint32_t w = REG32(addr + off);
        if (g_fault_hit) { st = ALBION_ST_ECC_UE; break; }
        crc = crc_word(crc, w);
        done = off + 4u;
    }
    g_fault_expect = 0u;
    res[0] = (st == ALBION_ST_OK) ? ~crc : 0u;
    res[1] = done;
    res[2] = (st == ALBION_ST_OK) ? 0u : g_fault_addr;
    return st;
}

static uint32_t cmd_ras_inject(uint32_t dom, const uint32_t *a) {
    uint32_t bank = a[0], word = a[1], lo = a[2], hi = a[3];
    if (dom != ALBION_DOM_HOST_ADMIN) return ALBION_ST_DENIED;
    if (bank >= g_nb) return ALBION_ST_BAD_PARAM;
    if (bank < ALBION_FW_PRIVATE_BANKS) return ALBION_ST_DENIED;
    if (word >= (g_bank_bytes >> 2) || hi > 0x7Fu) return ALBION_ST_BAD_PARAM;
    uint32_t n = popcount32(lo) + popcount32(hi);
    if (n != 1u && n != 2u) return ALBION_ST_BAD_PARAM;
    RAS(ALBION_RAS_INJ_ADDR) = word;
    RAS(ALBION_RAS_INJ_MASK_LO) = lo;
    RAS(ALBION_RAS_INJ_MASK_HI) = hi;
    RAS(ALBION_RAS_INJ_CTRL) = 1u | (bank << 4);
    return ALBION_ST_OK;
}

static uint32_t cmd_ras_status(uint32_t *res) {
    uint32_t ce = RAS(ALBION_RAS_CE_COUNT), ue = RAS(ALBION_RAS_UE_COUNT);
    if (ce > 0xFFFFu) ce = 0xFFFFu;
    if (ue > 0xFFFFu) ue = 0xFFFFu;
    res[0] = RAS(ALBION_RAS_ERR_STATUS);
    res[1] = RAS(ALBION_RAS_ERR_ADDR);
    res[2] = (ce << 16) | ue;
    return ALBION_ST_OK;
}

static uint32_t cmd_selftest(uint32_t *res) {
    volatile uint32_t seed = 0x13579BDFu, neg = 0xFFFFFFF0u;
    uint32_t bits = 0, x = seed, n16 = neg;
    /* bit0: ALU/shift/compare path (operands are volatile, so evaluated on the core) */
    uint32_t y = (x << 7) ^ (x >> 3) ^ (uint32_t)((int32_t)x >> 5);
    if (y == 0xA93DA025u && (int32_t)n16 < 1 && n16 > 1u) bits |= 1u;
    /* bit1: firmware SRAM write/read-back */
    uint32_t ok = 1u;
    for (uint32_t i = 0; i < 64u; i++) g_selftest_buf[i] = x ^ (i * 0x01010101u);
    for (uint32_t i = 0; i < 64u; i++) if (((volatile uint32_t *)g_selftest_buf)[i] != (x ^ (i * 0x01010101u))) ok = 0u;
    if (ok) bits |= 2u;
    /* bit2: CRC-32 check value of "123456789" */
    const char *s = "123456789";
    uint32_t crc = 0xFFFFFFFFu;
    for (uint32_t i = 0; i < 9u; i++) crc = crc_byte(crc, (uint8_t)s[i]);
    if (~crc == 0xCBF43926u) bits |= 4u;
    uint32_t sum = 0xFFFFFFFFu;
    for (uint32_t i = 0; i < 64u; i++) sum = crc_word(sum, g_selftest_buf[i]);
    res[0] = bits;
    res[1] = ~sum;
    res[2] = 0u;
    return ALBION_ST_OK;
}

static uint32_t dispatch(uint32_t op, uint32_t dom, const uint32_t *a, uint32_t *res) {
    switch (op) {
    case ALBION_OP_PING:
        res[0] = FW_VERSION; res[1] = g_feat; res[2] = g_heartbeat;
        return ALBION_ST_OK;
    case ALBION_OP_ALLOC:       return cmd_alloc(dom, a, res);
    case ALBION_OP_FREE:        return cmd_free(dom, a);
    case ALBION_OP_MAP_HOST:    return cmd_map_host(dom, a, res);
    case ALBION_OP_UNMAP_HOST:  return cmd_unmap_host(dom, a);
    case ALBION_OP_DMA_COPY:    return cmd_dma_copy(dom, a, res);
    case ALBION_OP_DMA_FILL:    return cmd_dma_fill(dom, a, res);
    case ALBION_OP_CRC32:       return cmd_crc32(dom, a, res);
    case ALBION_OP_RAS_INJECT:  return cmd_ras_inject(dom, a);
    case ALBION_OP_RAS_STATUS:  return cmd_ras_status(res);
    case ALBION_OP_RAS_CLEAR:
        if (dom != ALBION_DOM_HOST_ADMIN) return ALBION_ST_DENIED;
        RAS(ALBION_RAS_ERR_CLEAR) = 1u;
        IRQ(ALBION_IRQ_CLEAR) = ALBION_IRQ_ECC_CE | ALBION_IRQ_ECC_UE;
        return ALBION_ST_OK;
    case ALBION_OP_RAW_DMA:
        if (!(MGMT(ALBION_MGMT_DEV_STATUS) & ALBION_MGMT_DEV_STATUS_DBG_STRAP_MASK)) return ALBION_ST_DENIED;
        return run_dma(dom & 15u, a[0], a[1], a[2], 0u, 0u, res);
    case ALBION_OP_PKT_CLASSIFY:
        return (g_feat & ALBION_FEAT_PACKETFORGE) ? ALBION_ST_BAD_OPCODE : ALBION_ST_UNSUPPORTED;
    case ALBION_OP_VBLK_IO:
        return (g_feat & ALBION_FEAT_VIRTUALFOUNDRY) ? ALBION_ST_BAD_OPCODE : ALBION_ST_UNSUPPORTED;
    case ALBION_OP_MATMUL_INT8:
        return (g_feat & ALBION_FEAT_COMPUTEWORKS) ? ALBION_ST_BAD_OPCODE : ALBION_ST_UNSUPPORTED;
    case ALBION_OP_TELEM_CLEAR:
        if (dom != ALBION_DOM_HOST_ADMIN) return ALBION_ST_DENIED;
        TELEM(ALBION_TELEM_CTRL) = 2u;
        return ALBION_ST_OK;
    case ALBION_OP_SELFTEST:    return cmd_selftest(res);
    default:                    return ALBION_ST_BAD_OPCODE;
    }
}

/* ------------------------------------------------------------------ main */
void albion_main(void) {
    MGMT(ALBION_MGMT_FW_STATUS) = FW_STATUS_BOOTING;
    while (!(MGMT(ALBION_MGMT_DEV_STATUS) & ALBION_MGMT_DEV_STATUS_INIT_DONE_MASK)) { }

    g_nb = MGMT(ALBION_MGMT_SRAM_BANKS);
    g_bank_bytes = MGMT(ALBION_MGMT_SRAM_BANK_BYTES);
    g_nw = MGMT(ALBION_MGMT_NUM_WINDOWS);
    if (g_nw > MAX_WIN) g_nw = MAX_WIN;
    g_feat = MGMT(ALBION_MGMT_FEAT_IMPL);
    g_data_base = 0u;
    for (uint32_t i = 0; i < ALBION_FW_PRIVATE_BANKS; i++) g_data_base += g_bank_bytes;
    g_granules = 0u;
    for (uint32_t i = ALBION_FW_PRIVATE_BANKS; i < g_nb; i++) g_granules += g_bank_bytes >> 8;
    if (g_granules > 1024u) g_granules = 1024u;
    crc_init();

    for (uint32_t i = 0; i < g_nw; i++) { g_win[i].used = 0u; win_program(i); }

    MGMT(ALBION_MGMT_BOOT_LOCK) = 1u;                 /* revoke host SRAM access */
    IRQ(ALBION_IRQ_ENABLE) = ALBION_IRQ_CMDQ | ALBION_IRQ_DMA_DONE | ALBION_IRQ_DMA_ERR;
    __asm__ volatile("csrs mie, %0" :: "r"(1u << 11));   /* MEIE: WFI wake-up only (mstatus.MIE stays 0) */
    MGMT(ALBION_MGMT_FW_VERSION) = FW_VERSION;
    MGMT(ALBION_MGMT_FW_STATUS) = FW_STATUS_READY;

    for (;;) {
        MGMT(ALBION_MGMT_FW_HEARTBEAT) = ++g_heartbeat;
        if (MGMT(ALBION_MGMT_FCMDQ_STATUS) & (1u << 9)) {   /* empty */
            __asm__ volatile("wfi");
            continue;
        }
        uint32_t c[8], res[3] = {0u, 0u, 0u};
        for (uint32_t i = 0; i < 8u; i++) c[i] = MGMT(ALBION_MGMT_FCMD_W0 + (i << 2));
        MGMT(ALBION_MGMT_FCMD_POP) = 1u;
        uint32_t op = c[0] & 0xFFu, dom = (c[0] >> 8) & 0xFu, flags = (c[0] >> 12) & 0xFu, tag = c[0] >> 16;
        uint32_t st = flags ? ALBION_ST_BAD_PARAM : dispatch(op, dom, &c[1], res);
        while (MGMT(ALBION_MGMT_FCPLQ_STATUS) & (1u << 8)) { }  /* completion queue full: wait for host */
        MGMT(ALBION_MGMT_FCPL_W0) = op | (st << 8) | (tag << 16);
        MGMT(ALBION_MGMT_FCPL_W1) = res[0];
        MGMT(ALBION_MGMT_FCPL_W2) = res[1];
        MGMT(ALBION_MGMT_FCPL_W3) = res[2];
        MGMT(ALBION_MGMT_FCPL_PUSH) = 1u;
    }
}
