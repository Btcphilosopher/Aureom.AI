# SilicaFlux Albion — System Architecture (Project 90)

## 1. Scope

`sf_albion_cloud_top` integrates a control processor, a common DataFabric, banked ECC SRAM, a protected DMA engine, a host interface and the management, interrupt, permission, telemetry and RAS blocks into one programmable SoC. Three build configurations share one source:

| | ALBION_MIN | ALBION_CLOUD | ALBION_HPC |
|---|---|---|---|
| SRAM | 4 × 16 KiB | 8 × 16 KiB | 8 × 32 KiB |
| Permission windows | 8 | 16 | 16 |
| Command / completion queue | 4 | 8 | 16 |
| Requested accelerators | — | PacketForge, VirtualFoundry | PacketForge, VirtualFoundry, ComputeWorks |
| Accelerators instantiated | — | none (unavailable) | none (unavailable) |

The top derives every size from `sf_albion_cloud_config` (generated from `spec/albion/regmap.json`). `FEAT_REQ` is what a configuration asks for; `FEAT_IMPL = FEAT_REQ & FEAT_AVAILABLE_MASK` is what is instantiated. `FEAT_UNAVAIL` is readable by the host and firmware. `STRICT=1` turns any unavailable feature into an elaboration error, for CI that must not build an incomplete chip.

## 2. Block diagram

```
                     ┌──────────────────────── clock domain clk_i ─────────────────────────┐
 rst_ni ─► rstctl ───┤  rst_n (sync)                                                       │
 host SOFT_RESET ─►  │                                                                     │
                     │   M0 ControlCore ──┐      ┌───────────── DataFabric ─────────────┐   │
                     │   (RV32I, dom 0)   ├─────►│ decode ─► permission ─► per-slave RR │   │
                     │   M1 DMA read  ────┤      │   └► DECERR / PERM responder         │   │
                     │   M2 DMA write ────┤      └──┬──────┬──────┬──────┬──────┬───────┘   │
                     │   M3 Host MMIO ────┘         │      │      │      │      │           │
                     │       (dom 1)           bank0  bank1..N-1  MMIO   HOSTMEM           │
                     │                         (fw)   (data)      │      └► host_if ─► hm_* │
                     │                                     MGMT IRQ DMA PERM TELEM RAS      │
                     └─────────────────────────────────────────────────────────────────────┘
```

## 3. Address map

| Region | Base | Size | Reached by |
|---|---|---|---|
| SRAM | `0x0000_0000` | banks × bank size | core: all banks; DMA: data banks via windows; host: only in boot mode |
| MMIO | `0x4000_0000` | 6 × 4 KiB pages | core: all; host: MGMT (rw), TELEM/RAS (r); DMA: never |
| HOSTMEM | `0x8000_0000` | 2 GiB of host IOVA | DMA via windows; core (debug); host: never |

Decoding is exact. Any address outside a populated region, including SRAM beyond the last bank, returns DECERR, so nothing aliases. The full register map is in [register_map.md](register_map.md).

## 4. Data paths

**Host → device control.** The host writes eight command words and a doorbell into the MGMT page. A 256-bit FIFO queues the command and raises the firmware interrupt. Firmware validates the command against the domain's windows, programs the DMA engine, waits, and pushes a 128-bit completion. A non-empty completion queue raises `host_irq_o`.

**Host ↔ SRAM data.** All bulk data moves by DMA. After `BOOT_LOCK` the host has no load/store path to SRAM. The DMA read port fetches from SRAM or host memory into a 4-entry FIFO, and the write port drains it. Each port has one outstanding request and may re-issue in the cycle its response returns.

**Firmware compute.** The ControlCore executes from bank 0. It can read tenant SRAM for firmware-side work such as `CRC32`, and takes a precise load-access-fault on an uncorrectable ECC error.

## 5. Microarchitecture highlights

* **DataFabric.** Each master's request is decoded and permission-checked combinationally, *before* arbitration. Denied and undecoded requests are accepted immediately and answered by a per-master error responder the next cycle; no slave ever sees them. Each slave has a round-robin arbiter. Responses carry the master ID, so pipelined slaves (SRAM: one request per cycle) need no reorder logic.
* **SRAM bank.** A single-port 1RW macro holds 39-bit codewords. Every word is written with encode(0) during scrub-on-reset before the bank accepts traffic. A full-word write takes one cycle. A partial write is a two-cycle read-modify-write, with the bank not ready in the second cycle. ECC events are reported in the response cycle.
* **DMA.** Results are deterministic regardless of timing. The transfer stops at the lowest-indexed failing beat (read or write); words before it are written, words at or after it are not. BADPARAM covers zero, unaligned or oversize length, unaligned addresses, and ranges that would wrap 2³².
* **ControlCore.** A 6-state multi-cycle FSM (FETCH, FETCH_WAIT, EXEC, MEM, MEM_WAIT, WFI) sharing one fabric port. CPI is about 4–6. WFI wakes on `mip & mie` whatever `mstatus.MIE` is set to; the firmware uses this to sleep between commands without taking interrupts.

## 6. Measured characteristics (see [performance_report.md](performance_report.md))

* SRAM→SRAM DMA: 3.99 B/cycle cross-bank (4.0 theoretical); 2.0 B/cycle same-bank (single-port serialisation).
* Host path: 4 B per L cycles with host latency L. Latency-bound until multiple outstanding host reads exist.
* Mailbox round trip (PING): about 380 cycles end to end; firmware plus MMIO overhead is about 680 cycles per DMA command.
* ALBION_MIN: about 0.47 mm² of sky130hd standard cells, SRAM macros excluded. Telemetry is the largest block, at 32%.
* ECP5-85F place-and-route: 43% of logic, 19% of block RAM, **19.45 MHz post-route (50 MHz target missed)**. The same-cycle response→request chaining that delivers 4 B/cycle is the critical path; see known_limitations.md for the pipelining plan.

## 7. Integration contract for future foundations

A P86/P87/P88 block joins as:
1. a DataFabric master (its own port and domain tag, window-checked like the DMA ports) and/or a slave (an MMIO page plus optional SRAM-like window);
2. a feature bit set to `available: true` in `spec/albion/regmap.json`, so the generator updates `FEAT_AVAILABLE_MASK`;
3. a `generate if (FEAT_IMPL[...])` instance in `sf_albion_cloud_top`;
4. firmware opcode handlers replacing the current UNSUPPORTED returns, mirrored in `runtime/albion/src/refmodel.rs`;
5. scoreboard coverage in `tests/albion_system`.

The master-ID field is currently 2 bits (4 masters). Adding masters widens it; the fabric is parameterised on `NM`, but the role table and response-ID width must be extended together.
