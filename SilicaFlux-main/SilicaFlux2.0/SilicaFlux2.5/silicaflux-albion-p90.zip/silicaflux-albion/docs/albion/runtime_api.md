# SilicaFlux Albion — Host Runtime API

Crate `sf-albion` (`runtime/albion`, library `sf_albion`; rlib, staticlib, cdylib) has no external dependencies. The C header is `runtime/albion/include/sf_albion.h`, and the constants header is the generated `firmware/albion/include/albion_regs.h`.

## Backends

| Backend | What it is | Timed | Use |
|---|---|---|---|
| `Backend::Reference` | executable functional model of the device at the MMIO boundary (fabric rules, SECDED/RAS, DMA semantics, mailbox, firmware semantics) | no | fast software development; golden model for scoreboards |
| `Backend::RtlSim` | the Verilator full-chip model `build/sim/cfg<N>/albion_sim`, driven over a line protocol | cycle-accurate RTL; host side modelled | integration, performance, verification |
| VFIO (`vfio` module) | Linux discovery of a vfio-pci-bound Albion function | — | discovery only; mapping is refused until an endpoint exists |

Both backends sit beneath the same `Transport` trait, so the driver code (`device.rs`) is identical across them.

## API (Rust ↔ C)

| Operation | Rust | C | Notes |
|---|---|---|---|
| open | `Device::open(&OpenOptions)` | `sf_albion_open(opts, &dev)` | reset → wait for scrub → load + verify firmware → start core → wait READY → enable IRQ |
| info | `dev.info()` | `sf_albion_info(dev, &info)` | chip/version, config, `feat_impl` / `feat_req` / `feat_unavail`, sizes, fw version |
| alloc | `dev.alloc(MemKind, size)` | `sf_albion_alloc(dev, kind, size, &buf)` | `DeviceSram` → firmware `ALLOC` (zeroed, private); `Host` → IOVA reservation + `MAP_HOST` |
| submit | `dev.submit(&Work)` / `submit_as(&Work, domain)` | `sf_albion_submit(dev, &work, &ticket)` | flow-controlled to the queue depth, so drops cannot occur |
| poll | `dev.poll(ticket)` | `sf_albion_poll` → 1 done / 0 pending / <0 error | non-blocking; drains the completion queue |
| wait | `dev.wait(ticket, timeout_cycles)` | `sf_albion_wait` | sleeps on the host interrupt (device time) |
| counters | `dev.counters()` | `sf_albion_counters(dev, vals, n)` | 48 × 64-bit telemetry counters (LO-snapshot / HI read pairs) |
| close | `dev.close()` | `sf_albion_close(dev)` | frees every buffer the session still owns, stops the backend |
| host memory | `dev.host_write/host_read(&buf, off, ..)` | `sf_albion_host_write/read` | CPU access to host buffers |
| errors | `sf_albion::Error` | negative `SF_ALBION_E*`, `sf_albion_last_error()` | Io, Protocol, Timeout, InvalidArgument, Device, Unavailable |

`Work` variants: `Ping`, `DmaCopy`, `DmaFill`, `Crc32`, `RasInject`, `RasStatus`, `RasClear`, `RawDma`, `PacketClassify`, `VirtioBlk`, `MatmulInt8`, `TelemClear`, `SelfTest`, `Raw{opcode,flags,args}`. A `Completion` carries `tag`, `opcode`, `status: Status` and `result: [u32; 3]`.

## Domains

A session has a tenant domain (`OpenOptions::domain`, 2–15) that it stamps on tenant commands. `submit_as` with domain 1 issues admin commands such as `RasInject`, `RasClear` and `TelemClear`. The runtime is the *trusted host driver* in the security model. In a multi-tenant deployment it runs in the host service or device plugin, and tenants reach it through an IPC boundary, never through the device directly.

## Environment

| Variable | Default | Meaning |
|---|---|---|
| `SF_ALBION_FW` | `build/firmware/albion_fw.bin` | firmware image |
| `SF_ALBION_SIM_DIR` | `build/sim` | directory holding `cfg<N>/albion_sim` |
| `SF_ALBION_COV_DIR` | unset | if set, each simulator process writes `cov_<pid>.dat` here |

## Simulator line protocol

The protocol is documented at the top of `sim/albion/albion_sim.cpp`. It supports MMIO read and write (single and burst), host-memory read and write, STEP, WAITIRQ, RUNTRAP, RESET, STRAP, HMLAT (host latency), HMFAULT (IOMMU-fault ranges), TRACE and STATS. Lines that are not protocol replies (RTL `$display`) are forwarded to stderr.
