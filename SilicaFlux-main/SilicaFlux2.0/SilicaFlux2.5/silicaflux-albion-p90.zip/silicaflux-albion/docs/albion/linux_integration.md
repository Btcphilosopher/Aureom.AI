# SilicaFlux Albion — Linux Host Integration

## Requirement

Give host software a legitimate path to the device: MMIO to the management page and DMA to host buffers. Untrusted tenants must never receive privileged device MMIO or unrestricted DMA memory.

## Options evaluated

| Option | Isolation of device DMA | Privileged MMIO exposure | Effort | Verdict |
|---|---|---|---|---|
| **A. Dedicated kernel driver** (`albion.ko`: PCI driver, char device, ioctl mailbox, `dma_map_*` with the kernel IOMMU API) | IOMMU through the DMA API; per-tenant IOVA domains need `iommufd`/PASID or a kernel-side domain table | none to userspace; the driver mediates everything | high (kernel code, upstreaming, security review of the ioctl surface) | long-term option for multi-tenant hosts that need per-process IOVA isolation without VFIO |
| **B. VFIO with IOMMU protection** (bind the function to `vfio-pci`; a trusted userspace service owns the VFIO group or iommufd and the BAR mapping; buffers registered with `VFIO_IOMMU_MAP_DMA`) | host IOMMU confines every device DMA to explicitly mapped IOVA ranges, so the device cannot reach unmapped host memory even if firmware or hardware misbehaves | BAR0 is mapped only in the trusted service | low–medium (the Rust runtime already speaks the MMIO protocol) | **chosen first path** |
| **C. Userspace driver framework** (DPDK/SPDK-style polling over VFIO or UIO) | VFIO mode equals B; **UIO has no IOMMU protection** | as in B, or unprotected with UIO | medium | UIO rejected outright; DPDK-style polling over VFIO stays an option for later packet workloads (PacketForge) |

## Chosen design (B, then A when needed)

```
 tenant process ──IPC (domain-scoped requests)──► albion-hostd (trusted)
                                                   ├─ owns /dev/vfio/<group> (or iommufd)
                                                   ├─ mmap BAR0: MGMT / TELEM / RAS pages only
                                                   ├─ VFIO_IOMMU_MAP_DMA for each pinned tenant buffer
                                                   ├─ assigns the tenant's Albion domain (2..15)
                                                   └─ sf_albion runtime (Transport = VFIO)
```

* **Two independent DMA fences.** The host IOMMU rejects any device access outside the IOVA ranges the service mapped. The device's own window table, programmed by firmware from `MAP_HOST` requests, rejects any beat outside the windows of the *tenant's domain*. A device bug, a firmware bug or a malicious command each has to defeat the other fence too.
* **BAR layout requirement on the PCIe endpoint.** BAR0 exposes only the 4 KiB MGMT page plus read-only TELEM and RAS. The IRQ, DMA and PERM pages are not mapped to the host at all; the fabric already denies them. A boot BAR exposing SRAM for firmware load stays functional only in boot mode, as today.
* **Interrupts.** `host_irq_o` becomes an MSI-X vector delivered as an eventfd (`VFIO_DEVICE_SET_IRQS`). `Device::wait` blocks on it.
* **Firmware load.** The service loads the image after reset (boot mode). A signed-image check belongs in the service until secure boot exists on the device.
* **Tenants** never open VFIO and never map device memory. They get allocations, work submission and completion through the service, which enforces quotas.

## What exists in this repository

* `runtime/albion/src/vfio.rs` does real **discovery**. It walks `/sys/bus/pci/devices` for the Albion vendor/device ID and reports the bound driver and IOMMU group. It refuses any function that is not bound to `vfio-pci` with an IOMMU group. A unit test runs it against a fake sysfs tree.
* `open_vfio()` returns `Unavailable` deliberately. BAR mapping and `VFIO_IOMMU_MAP_DMA` are **not implemented**, because no PCIe endpoint exists to test them against: the PCIe controller is external IP, and there is no FPGA board or silicon. They must not be written blind.
* The vendor ID constant is a **placeholder** pending a PCI-SIG assignment.

## Next steps (gated on hardware)

1. Integrate a PCIe endpoint on an FPGA board with a BAR0 → `h_*` adapter and a requester → `hm_*` adapter.
2. Implement `VfioTransport` (group/iommufd open, BAR0 `mmap`, DMA map/unmap, MSI-X eventfd), then run the existing system test suite on it unchanged.
3. Add IOMMU-fault tests on hardware to mirror `host_iommu_fault_propagates`.
