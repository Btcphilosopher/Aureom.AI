# SilicaFlux Albion — Transaction Protocol

## 1. DataFabric port protocol (SF-DF)

Every master and slave port uses the same single-beat request/response protocol. All signals are synchronous to `clk_i`.

**Request channel** (master → fabric → slave)

| Signal | Width | Meaning |
|---|---|---|
| `req_valid` | 1 | request present |
| `req_ready` | 1 | accepted this cycle when `req_valid && req_ready` |
| `req_addr` | 32 | byte address; bits [1:0] are ignored (word-addressed beat) |
| `req_we` | 1 | write |
| `req_wdata` | 32 | write data |
| `req_wstrb` | 4 | byte enables (writes) |
| `req_domain` | 4 | security domain (assigned by the master's role, not by software) |
| `req_id` | 2 | master ID, added by the fabric towards slaves |

**Response channel** (slave → fabric → master): a single-cycle `rsp_valid` pulse with `rsp_rdata[31:0]`, `rsp_err[2:0]` and (slave side) `rsp_id[1:0]`.

| `rsp_err` | Name | Origin |
|---|---|---|
| 0 | OK | slave |
| 1 | DECERR | fabric (no slave at address) or MMIO block (unpopulated offset) |
| 2 | PERM | fabric permission unit; the slave was never accessed |
| 3 | ECC_UE | SRAM bank, uncorrectable read |
| 4 | SLVERR | MMIO block: read-only register, wrong writer, partial-word register write |
| 5 | HOSTERR | host interface: host memory port fault (IOMMU fault in silicon) |

**Rules**

1. **One outstanding request per master.** A master may issue its next request in the same cycle its previous response arrives. Simulation asserts this (`datafabric: master N issued a second outstanding request`).
2. Masters may withdraw `req_valid` before acceptance. The fabric holds no per-request state before the handshake.
3. Slaves return responses in order per slave and echo `req_id`. Pipelined slaves (SRAM) may accept every cycle.
4. Fabric latency: SRAM and MMIO respond the cycle after acceptance, the fabric error responder likewise, and the host interface after the host latency L ≥ 1.
5. A response is routed to the master whose ID it carries. With one outstanding request per master, at most one slave can address a given master in any cycle.

## 2. Arbitration

Each slave has an independent round-robin arbiter over the four masters. The pointer advances past the granted master on each accepted request. A bank-conflict cycle (two or more masters requesting one SRAM bank) is counted in `TELEM.BANK_CONFLICT`. Stall cycles (`valid && !ready`) are counted per master.

## 3. Host-memory port (`hm_*`)

The device's DMA beats to `HOSTMEM_BASE + iova` leave on the host-memory requester port with `hm_req_addr = iova[30:0]`. There is one outstanding request, and the next one may be presented in the response cycle. `hm_rsp_err = 1` marks a host-side fault and maps to HOSTERR, then to DMA error code HOSTERR, then to completion status HOST_FAULT.

## 4. Host MMIO port (`h_*`)

This is the same request/response protocol, driven by the host (a PCIe BAR target in silicon, the Verilator harness in simulation). The host is fabric master 3 with domain HOST_ADMIN. The host must keep one MMIO request outstanding, matching a non-posted PCIe read. A real PCIe adapter turns posted writes into this protocol and must keep them in order.

## 5. Mailbox protocol

Commands are 8 × 32-bit words; completions are 4 × 32-bit words.

```
cmd w0      [7:0] opcode  [11:8] domain  [15:12] flags (must be 0)  [31:16] tag
cmd w1..w7  arguments (see opcode table in register_map.md)
cpl w0      [7:0] opcode  [15:8] status  [31:16] tag
cpl w1..w3  results
```

**Host side:** write `HCMD_W0..7`, then any write to `HCMD_SUBMIT` pushes the command. If the queue is full the command is dropped, `HCMDQ_STATUS.overflow` is set and `TELEM.CMDQ_DROPS` counts it. The runtime never overflows: it limits outstanding commands to the queue depth. Completions are read from `HCPL_W0..3` (queue head) and popped with `HCPL_POP`. `HOST_IRQ_STATUS[0]` (completion queue non-empty) drives `host_irq_o` when enabled.

**Firmware side:** read `FCMD_W0..7`, write `FCMD_POP`, then stage `FCPL_W0..3` and write `FCPL_PUSH`. If the completion queue is full the firmware waits. That cannot happen while the host respects the outstanding-command limit.

Tags are opaque to the device and returned unchanged. The runtime uses unique non-zero tags and rejects a completion whose tag it does not know.

## 6. DMA transfer semantics

| Mode | Behaviour |
|---|---|
| copy | for i in 0..LEN/4: read SRC+4i, write DST+4i, in order |
| fill | for i in 0..LEN/4: write FILL_PATTERN to DST+4i |

The architectural result is defined as if beats ran strictly in order. The first failing beat i (read checked before write) ends the transfer: `BYTES_DONE = 4i`, `ERR_ADDR` is the failing beat's address, and `ERR_CODE` comes from that beat. Prefetch may already have *issued* later reads. They are never written, but telemetry and RAS may count their side effects. Overlapping copies are rejected by the firmware (BAD_PARAM); through RAW_DMA their data result depends on prefetch timing.
