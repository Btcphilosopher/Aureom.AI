# SilicaFlux Albion — Hardware Dependencies (Repository Audit)

Audited 2026-11-15. The whole workspace filesystem was searched for the nine preceding SilicaFlux Albion foundations: sources, netlists, packages, documents and names. **None were present.** Each critical function ALBION_MIN needs was therefore implemented in this repository as a *P90-local* block, named `sf_albion_*`, verified here, and labelled as a stand-in in the feature table (`spec/albion/regmap.json`). Nothing was silently stubbed. The three accelerators the advanced configurations request are reported unavailable in hardware (`MGMT.FEAT_UNAVAIL`), in firmware (UNSUPPORTED) and in the runtime (`DeviceInfo::feature_table`).

Machine-readable form: [`audit/dependencies.json`](../../audit/dependencies.json).

| P | Foundation | Role in P90 | Status in repository | P90-local stand-in | Stand-in status |
|---|---|---|---|---|---|
| 81 | AlbionCore | RISC-V ControlCore *(inferred)* | **Missing** | `sf_albion_controlcore` (RV32I + Zicsr) | Verified (ISS lock-step, firmware boot) |
| 82 | Keystone | unknown: a DataFabric master in the P84 brief; scope not inferable | **Missing** | — | — |
| 83 | Meridian | common DataFabric *(inferred)* | **Missing** | `sf_albion_datafabric` | Verified (module random traffic, formal) |
| 84 | IronMemory | banked SRAM + SECDED | **Missing** | `sf_albion_sram_bank`, `sf_albion_secded` | Verified (formal SECDED, injection) |
| 85 | BridgeEngine | DMA / host bridge *(inferred)* | **Missing** | `sf_albion_dma`, `sf_albion_host_if` | Verified (module TB, BMC, workloads) |
| 86 | PacketForge | packet processing | **Missing** | none | workload C unavailable |
| 87 | VirtualFoundry | protected virtual I/O | **Missing** | none | workload D unavailable |
| 88 | ComputeWorks | tensor / vector | **Missing** | none | workload E unavailable |
| 89 | Citadel | permission / security *(inferred)* | **Missing** | `sf_albion_perm` + fabric invariants + firmware validation | Verified (formal, security suite) |

*Inferred* roles come from the foundation name and the P90 brief only. When the real foundations are brought into the repository, their interfaces must be reconciled with the SF-DF port protocol ([transaction_protocol.md](transaction_protocol.md)). The P90-local blocks should then be replaced, or kept as reference models.

## External IP and tools

| Item | Classification | Consequence |
|---|---|---|
| PCIe endpoint controller + PHY | Blocked by external IP | host interface simulated; the Linux driver cannot be exercised on hardware |
| Compiled SRAM macros (sky130 or the target node) | Blocked by external IP | SRAM is a blackbox in synthesis; no SRAM area or timing; physical design gated |
| OpenROAD / ORFS | Not installed in this environment | `make albion-floorplan` reports exactly what is missing |
| FPGA board + host link | Not available | FPGA results are place-and-route estimates; no board operation claimed |
| DDR/HBM controller + PHY | Out of scope (P84 rule: never invent a DRAM PHY) | on-chip SRAM only |

## Rules carried over from the Project 84 brief

* Start with four SRAM banks and one shared address window. Done: ALBION_MIN has 4 × 16 KiB.
* Never assume two transactions share a single-port macro in one cycle. Done: one access per bank per cycle, and scrub and RMW share the port explicitly.
* Prevent silent address aliasing. Done: exact decode with DECERR, tested.
* Do not report physical SRAM area from an uncalibrated generic array. Done: the SRAM macro is blackboxed and its area is reported as unknown.
