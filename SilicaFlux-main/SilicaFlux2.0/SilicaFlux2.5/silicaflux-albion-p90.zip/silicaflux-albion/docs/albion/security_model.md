# SilicaFlux Albion — Security Model

## Principals

| Domain | Who | May do |
|---|---|---|
| 0 FIRMWARE | ControlCore firmware (device root of trust) | everything; DMA in domain 0 may reach SRAM *data* banks only (scrubbing) |
| 1 HOST_ADMIN | trusted host driver / service | MMIO: MGMT page (mailbox, boot control), read TELEM and RAS; never a DMA domain |
| 2–15 | tenants | memory only through DMA windows opened for them by firmware |

Tenants never touch device registers. Commands reach the firmware through the host driver, which stamps the tenant's domain into each command. The driver is trusted to assign domains and to vouch that a host IOVA range belongs to the tenant (`MAP_HOST`). On Linux the IOMMU (VFIO) enforces that second claim independently; see [linux_integration.md](linux_integration.md).

## Enforcement layers

1. **Firmware validation.** Every tenant command is checked before hardware is programmed. The domain must be a tenant domain, the length and alignment valid, the range not wrapping, a copy not overlapping, and every range must lie inside one window owned by the domain with the needed R/W permission (`firmware/albion/src/main.c`).
2. **Hardware permission check on every beat.** The DataFabric checks each DMA beat against the window table using the DMA's domain register, and checks each host access against the host policy. Denied requests never reach a slave.
3. **Hardware invariants that no window can override:**
   * DMA can never reach MMIO (including the window table itself) or firmware-private SRAM bank 0.
   * DMA in domain 1 is always denied; DMA in domain 0 cannot reach host memory.
   * The host reaches SRAM only in boot mode; it never reaches host memory through the device; it sees MMIO pages outside its allow-list as PERM, populated or not, so it cannot probe the private page layout.
4. **Boot lock.** Once firmware sets `BOOT_LOCK`, the host can neither load SRAM nor stop or restart the core. Only a full device reset, which scrubs SRAM, returns the device to boot mode.
5. **Data lifetime.** Allocations are zero-filled before their window opens and scrubbed again on free. Reset scrubs everything.

## Assurance

| Property | Evidence |
|---|---|
| Fabric invariants P1–P6 for any request, window table, boot mode and arbiter state | formal k-induction (`formal/albion/fv_fabric_perm.sv`), plus a mutation (DMA into bank 0) that the proof must and does refute |
| Hardware stops every isolation attack even with firmware validation bypassed | `hardware_enforces_isolation_without_firmware_validation`: 12 RAW_DMA attacks under the debug strap, then checks that the victim's data, the RO host window and the window table are intact |
| Host access policy after boot, exact decode, no aliasing, every denial counted | `host_mmio_policy_after_boot` |
| Window revocation is immediate | `window_revocation_is_immediate` |
| No tenant data survives free or reset | `freed_memory_is_scrubbed_before_reuse`, `soft_reset_clears_tenant_state`, `pin_reset_during_dma_returns_clean_device` |
| Firmware validation matches an independent model on random valid/invalid streams | `scoreboard_*` (reference model vs RTL, about 1,200 random operations including cross-domain and out-of-window requests) |
| Spec-level permission model vs RTL under concurrent random traffic | `tb_fabric` (≈5,500 checked denials, full-SRAM read-back) |

## The debug strap

`dbg_strap_i` enables the `RAW_DMA` command, which skips firmware validation so that hardware enforcement can be tested on its own. Production designs tie it low; `sf_albion_fpga_top` ties it to the `DEBUG_STRAP` parameter, default 0. With the strap set, any domain's DMA can be *attempted*, but the hardware checks still apply. That is the purpose of the test.

## Explicitly out of scope / not claimed

* **Secure multi-tenant partitions are not advertised.** Isolation is verified in simulation and, for the fabric, formally. There is still no PCIe endpoint, no IOMMU integration test on real hardware, no side-channel (timing, contention) analysis and no fault-attack hardening.
* No secure boot: the firmware image is not authenticated. The host driver that loads it is trusted.
* No attestation and no cryptographic engines. Citadel (P89) is absent.
* Telemetry counters, including per-domain byte counts and stall counters, are visible to HOST_ADMIN. Exposing them to tenants would open a side channel and must be mediated by the host service.
* Denial of service between tenants is not prevented. The firmware serialises commands, so one tenant's large DMA delays others, and there is no QoS.
