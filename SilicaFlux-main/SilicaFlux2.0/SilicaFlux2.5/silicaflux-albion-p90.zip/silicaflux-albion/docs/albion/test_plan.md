# SilicaFlux Albion — Test Plan

`make albion-test` runs everything below and writes `reports/test/test_results.json`. Any failure fails the target. Critical data corruption and isolation violations are test failures by construction: every negative test asserts that the denied access had no effect.

## Levels

| Level | Item | What it proves | Where |
|---|---|---|---|
| Module | SECDED | all 39 single flips corrected, all 741 double flips detected, for 335 words (261,635 checks) | `tests/albion_modules/tb_secded.sv` |
| Module | DMA engine | 600 random transfers (copy/fill, 1–96 beats) with random port latency, back-pressure and address-triggered errors of every type: status, BYTES_DONE, ERR_ADDR and destination memory match the in-order architectural result | `tb_dma.sv` |
| Module | DataFabric + SRAM banks | 4 concurrent masters × 3,000 random transactions × 3 seeds; every response code checked against a spec-level permission model; shadow-memory data checks; full-SRAM read-back proves no denied or misrouted write landed; about 1,000 bank-conflict cycles per seed | `tb_fabric.sv` |
| Core | ControlCore ISA | lock-step retirement trace vs an independent RV32I ISS over 64 random programs × 500 instructions; all trap causes 0,2,3,4,5,6,7,11 must occur | `rtl_only::controlcore_lockstep_against_iss` |
| Firmware | firmware execution | boot, self-test (ALU, SRAM, CRC check value), CRC-32 of tenant data equals host-computed CRC | `workloads::*selftest*`, workload A |
| Full chip | workloads A, B, F | host→SRAM DMA at 5 sizes with round trip and firmware CRC; protected SRAM copy plus 7 DENIED and 5 BAD_PARAM cases with isolation check; ECC CE transparent, UE stops DMA at the poisoned beat, precise CRC trap, syndrome/source/counters | `workloads.rs` |
| Full chip | workloads C, D, E | report UNSUPPORTED and FEAT_UNAVAIL in all three configs | `workloads.rs` |
| Full chip | security | host policy, hardware-only enforcement (RAW_DMA), revocation, boot-mode rules, soft-reset scrub | `security.rs` |
| Full chip | resets | pin reset mid-DMA → clean, scrubbed boot-mode device; soft reset mid-DMA → no partial data | `rtl_only.rs` |
| Full chip | queues | 40 back-to-back commands without drops; deliberate overflow detected and counted | `rtl_only.rs` |
| Full chip | random scoreboard | about 1,200 random valid and invalid operations across MIN, CLOUD and HPC; every completion, host memory, SRAM (via firmware CRC), RAS registers and deterministic telemetry identical between reference model and RTL | `scoreboard.rs` |
| Software | runtime + C ABI | unit tests (CRC, syndrome, VFIO discovery against a fake sysfs); C program over both backends | `sf-albion` tests, `examples/c_smoke.c` |
| Formal | SECDED, permission P1–P6, FIFO, DMA bounds | see `reports/formal/formal_results.json`; each with a mutation that must be refuted | `formal/albion/` |
| Coverage | line / branch / toggle | merged over the full-chip system run on a coverage-instrumented model | `reports/coverage/` |

## What is compared between backends

These must match: completion status and results, except DMA `dma_cycles` and the PING heartbeat (timing); host memory; SRAM contents; RAS log registers; and telemetry counters `DMA_BYTES`, `DMA_DESC_DONE`, `DMA_ERRORS`, `PERM_VIOL`, `DECERR`, `ECC_CE`, `ECC_UE`, `CMD_SUBMITTED`, `CPL_POSTED`, `CMDQ_DROPS` and `DOM0..15_BYTES`.

These are not compared, because the reference model is untimed: cycle counts, fabric transaction, stall and conflict counters, and ControlCore instret and sleep. ECC or permission side effects of DMA prefetch reads issued past a failing *write* beat are architecturally unspecified. The generator avoids streams where they occur, and this is documented in the transaction protocol.

## Bugs found by this plan (kept for the record)

| Found by | Defect | Fix |
|---|---|---|
| design review before simulation | DMA could issue a read in the cycle a read failed, shifting beat indices | issue gated on `!rd_fail`; FIFO flush gating |
| design review | DMA could write a stale FIFO word in the first cycle after START | issue gated on `!f_flush` |
| design review | host_if returned read data using the *current* request's write flag | registered `we_q` |
| AlbionBench (theory vs RTL) | host path measured exactly 4/(L+1) B/cycle: one-cycle re-issue bubble in host_if | re-issue allowed in the response cycle; now 4/L |
| system test | RTL `$display` corrupted the simulator line protocol | client forwards non-protocol lines to stderr |
| ISS lock-step | generator used x0 as an address temporary (both models agreed; the program hung) | generator fix; illegal-encoding set widened after coverage review |
| module TB | SECDED TB sampled the encoder before it settled (TB race, not RTL) | TB fix |
