# SilicaFlux Albion — Kubernetes Device Plugin

## Gate status: NOT BUILT (by design)

The brief says to build the device-plugin prototype *once device discovery and protected allocation work*, and to expose only resources that actually exist.

| Gate | Status |
|---|---|
| Protected allocation works | **yes, in simulation**: firmware-owned windows, verified (system tests, scoreboard, formal fabric proof) |
| Device discovery works on a real host | **no**: no PCIe endpoint exists, so there is nothing to discover; `vfio::discover()` correctly returns zero devices |
| Isolation verified on hardware | **no** |

A plugin built today would either advertise zero devices, which is pointless, or advertise simulated devices as schedulable cluster resources, which the brief forbids. So no plugin code ships, and none of the manifests below are deployable yet.

## Design (ready to implement when the gates open)

**Resource names**

* `aureom.ai/albion` is a whole device for one pod (exclusive), advertised once per `vfio::discover()` result that is `vfio_ready()` and whose firmware reports READY.
* `aureom.ai/albion-domain` is a tenant domain partition (up to 14 per device). It **must not** be advertised until hardware isolation has been verified on the target platform (IOMMU + device windows + side-channel review). Until then the plugin hard-codes it off.

**Plugin behaviour (gRPC `v1beta1.DevicePlugin`)**

* `ListAndWatch`: discovery plus health. A device is Healthy when `FW_STATUS == READY`, `FW_ATTN == 0`, `RAS.UE_COUNT` has not increased since the last poll, and the heartbeat is advancing. Any change is pushed immediately.
* `Allocate`: for whole devices, returns the VFIO group character device (`/dev/vfio/<n>`, `/dev/vfio/vfio`) and env `ALBION_BDF`. For domain partitions (when enabled), returns *no device nodes*, only a Unix socket mount to `albion-hostd` and a one-time domain token. Tenants never get VFIO.
* `GetPreferredAllocation`: prefers devices on the pod's NUMA node.
* **Resource accounting**: per-domain `DOMn_BYTES`, command counts and RAS counters exported as Prometheus metrics by `albion-hostd`, labelled by pod UID.

**Deployment sketch (not deployable yet)**

```yaml
# daemonset: albion-device-plugin (privileged only for /dev/vfio and /var/lib/kubelet/device-plugins)
# pod request:
resources:
  limits:
    aureom.ai/albion: 1
```

## To proceed

1. Satisfy the discovery gate (PCIe endpoint on an FPGA board, VFIO transport; see [linux_integration.md](linux_integration.md)).
2. Implement the plugin with whole-device allocation only, plus health and metrics.
3. Enable `albion-domain` only after an isolation review on hardware.
