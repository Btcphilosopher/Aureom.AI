# SilicaFlux Albion — FPGA Implementation

## Wrapper

`fpga/albion/sf_albion_fpga_top.sv` is board-independent:

* **Clock/reset:** one board clock and an active-low reset, synchronised inside the SoC. The debug strap is tied to the `DEBUG_STRAP` parameter, default 0 for production.
* **FPGA RAM:** the behavioural `sf_albion_sram_macro` infers block RAM (ECP5 DP16KD). No vendor primitive is instantiated.
* **Host link:** the host MMIO target port and host-memory requester port are exported unchanged. A board port connects them to the board's host link: a PCIe hard IP plus bridge, or a lab UART/JTAG-to-MMIO bridge with an on-board memory standing in for host memory. That bridge is board-specific and **not written**, because no board has been chosen.
* **Status LEDs:** `init_done`, `core_run`, `boot_lock`.

## Flow (`make albion-fpga`, open toolchain)

`yosys synth_ecp5`, then `nextpnr-ecp5` (LFE5UM-85F, CABGA756, 50 MHz target, unconstrained IO placement), then `ecppack`. The run writes `reports/fpga/ALBION_MIN.json` with utilisation, nextpnr's post-route Fmax estimate, bitstream size and tool versions.

## Evidence classification

| Step of the brief | Done here? |
|---|---|
| Integrate clock/reset | yes (wrapper) |
| Map FPGA RAM | yes (inferred BRAM, visible in utilisation) |
| Build bitstream | yes (`build/fpga/ALBION_MIN/albion.bit`) |
| Run timing | yes, as a nextpnr estimate with unconstrained IO; **19.45 MHz post-route, 50 MHz target not met** (critical path in [known_limitations.md](known_limitations.md)) |
| Program board | **no**: no compatible board |
| Execute host transfers | **no** |
| Run compute tests | **no** (and ComputeWorks is absent) |
| Capture performance counters | **no** (in simulation only) |

The FPGA results are recorded as `fpga_estimate`, never as FPGA measurements. The engineering terminal shows "Board programmed: NO".

## Bring-up plan when a board exists

1. Choose a board with PCIe (for example an ECP5-5G Versa or a Xilinx/Altera PCIe board) or start with a UART bridge.
2. Write the board port: pin constraints, clocking, and the bridge from `h_*`/`hm_*` to the host link.
3. Use the existing `Transport` trait: add a UART or VFIO transport and run `tests/albion_system` unchanged on hardware.
4. Record AlbionBench results as `fpga` measurements, with board, bitstream hash and tool versions.
