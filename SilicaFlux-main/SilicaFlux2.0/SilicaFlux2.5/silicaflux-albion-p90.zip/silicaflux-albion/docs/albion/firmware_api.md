# SilicaFlux Albion — Firmware API

Source: `firmware/albion/` (C11 + startup assembly, RV32I + Zicsr, clang/LLD, freestanding, about 4.7 KB). The command semantics are mirrored exactly by `runtime/albion/src/refmodel.rs`; the system scoreboards compare the two.

## Image and boot

* Linked at `0x0000_0000` in SRAM bank 0 (`link.ld`, 16 KiB, 2 KiB stack at the top). The host loads `build/firmware/albion_fw.bin` in boot mode; the runtime verifies it word by word.
* `start.S` sets `sp`, installs `albion_trap_entry` in `mtvec`, zeroes `.bss` and calls `albion_main`.
* `albion_main` reports `FW_STATUS = 1` (booting), waits for `INIT_DONE`, then reads the configuration (`SRAM_BANKS`, `SRAM_BANK_BYTES`, `NUM_WINDOWS`, `FEAT_IMPL`). It invalidates every window, sets `BOOT_LOCK`, enables IRQ sources CMDQ, DMA_DONE and DMA_ERR plus `mie.MEIE` (WFI wake-up only; `mstatus.MIE` stays 0), writes `FW_VERSION = 0x00010000` and reports `FW_STATUS = 2` (ready).
* Main loop: increment `FW_HEARTBEAT`; if the command queue is empty, `wfi`; otherwise pop a command, dispatch it and push its completion.

## Traps

`albion_trap_handler(mcause, mepc, mtval)` returns the new `mepc`. A load or store access fault while `g_fault_expect` is set (the CRC routine reading tenant memory) records the address and skips the instruction, which is how uncorrectable ECC errors become `ECC_UE` completions. Any other trap is fatal: `FW_STATUS = 0xDEAD0000 | mcause`, `FW_ATTN = 1` (raises the host interrupt if enabled), then the core parks in `wfi`.

## Commands

The domain is the `w0[11:8]` field of the command. "Tenant" means domains 2–15. Checks run in the order listed, and the first failing check sets the status.

| Opcode | Command | Domain | Checks → status | Results |
|---|---|---|---|---|
| 0x01 | PING | any | — | fw_version, FEAT_IMPL, heartbeat |
| 0x10 | ALLOC size | tenant else DENIED | size 0 or > data SRAM → BAD_PARAM; no free window → NO_RESOURCE; no contiguous run → NO_RESOURCE | addr, window, rounded size |
| 0x11 | FREE addr | tenant | no SRAM window of this domain with base = addr → DENIED | — |
| 0x12 | MAP_HOST iova size perms | tenant | size 0 / unaligned / iova unaligned → BAD_PARAM; outside 2 GiB → BAD_PARAM; perms ∉ 1..3 → BAD_PARAM; no window → NO_RESOURCE | window, fabric addr |
| 0x13 | UNMAP_HOST window | tenant | window ≥ NUM_WINDOWS → BAD_PARAM; not a host window of this domain → DENIED | — |
| 0x20 | DMA_COPY src dst len | tenant | len 0 / unaligned / > 1 MiB, or unaligned src/dst → BAD_PARAM; wrap → BAD_PARAM; overlap → BAD_PARAM; src not in an R window of the domain → DENIED; dst not in a W window → DENIED; then hardware status | bytes_done, dma_cycles, err_addr |
| 0x21 | DMA_FILL dst len pattern | tenant | as above for dst | bytes_done, dma_cycles, err_addr |
| 0x22 | CRC32 addr len | tenant | as above, SRAM windows only; UE during read → ECC_UE | crc (0 on error), bytes, err_addr |
| 0x30 | RAS_INJECT bank word lo hi | HOST_ADMIN | bank ≥ NB → BAD_PARAM; bank 0 → DENIED; word out of range or hi > 0x7F → BAD_PARAM; popcount ∉ {1,2} → BAD_PARAM | — |
| 0x31 | RAS_STATUS | any | — | ERR_STATUS, ERR_ADDR, CE[31:16]·UE[15:0] (saturated at 0xFFFF) |
| 0x32 | RAS_CLEAR | HOST_ADMIN | — | — |
| 0x40 | RAW_DMA src dst len | any (debug strap) | strap low → DENIED; no other checks | as DMA_COPY |
| 0x50/51/52 | PKT_CLASSIFY / VBLK_IO / MATMUL_INT8 | any | feature not in FEAT_IMPL → UNSUPPORTED | — |
| 0x60 | TELEM_CLEAR | HOST_ADMIN | — | — |
| 0x70 | SELFTEST | any | — | bit0 ALU/shift/compare, bit1 firmware SRAM, bit2 CRC-32 check value; checksum |

A non-zero `flags` field gives BAD_PARAM; an unknown opcode gives BAD_OPCODE.

Hardware DMA error mapping: DECERR → HW_DECERR, PERM → HW_PERM, ECC_UE → ECC_UE, BADPARAM → BAD_PARAM, HOSTERR → HOST_FAULT, anything else → HW_SLVERR. A DMA that does not finish within 2²⁴ status polls → TIMEOUT.

## Allocator

There is one bitmap over the data banks (bank 1 onward) with 256-byte granules and at most 1024 granules. The search is first-fit, lowest address first. Each allocation consumes one permission window, granting RW to its domain. Allocation zero-fills through a domain-0 DMA fill *before* the window opens. Free revokes the window, then scrubs, then releases the granules.

## Extending

Add the opcode to `spec/albion/regmap.json` and regenerate. Add the handler to `dispatch()` and an identical model to `refmodel.rs::dispatch`. Then extend the scoreboard generator in `tests/albion_system/tests/scoreboard.rs`.
