# SilicaFlux Albion — Known Limitations

Grouped by what they block. Each is a real constraint of this revision, not a disclaimer.

## Missing foundations (block the advanced configurations)

* **PacketForge (P86), VirtualFoundry (P87), ComputeWorks (P88) are absent.** Workloads C (packet classification), D (virtual block I/O) and E (INT8 GEMM) are not implemented and return UNSUPPORTED. ALBION_CLOUD and ALBION_HPC report this in `FEAT_UNAVAIL`. No packet, virtual-I/O or tensor number exists anywhere in this repository.
* **P81–P85 and P89 are also absent.** P90-local stand-ins exist for each role ALBION_MIN needs. They are verified here but are not the original foundations, whose interfaces may differ.
* **Keystone (P82):** its role cannot be inferred from this repository, so nothing stands in for it.

## Micro-architecture (measured)

* **Host DMA is latency-bound.** One outstanding request per DMA port gives 4 B per L cycles (0.06 B/cycle at L = 64). Tagged multiple-outstanding reads are needed before networking or virtual I/O makes sense.
* **Single DMA channel; the firmware serialises commands.** Mailbox overhead is about 680 cycles per command, so small transfers are overhead-dominated. There is no QoS between tenants.
* **Same-bank copies run at half rate** (single-port banks). This is a software placement concern.
* **Prefetch side effects.** When a DMA *write* fails, reads already prefetched past that beat may have logged ECC or permission events. The data result is still architecturally exact. Overlapping RAW_DMA copies have timing-dependent data; the firmware rejects overlap for normal copies.
* **Fabric:** 4 masters, a 2-bit ID, one outstanding request per master, and no posted writes. Adding accelerator masters needs the role table and ID widened.
* **ControlCore:** RV32I + Zicsr only, with no M (software multiply/divide), no C, no PMP, no debug module, no performance-counter CSRs beyond cycle and instret. It is multi-cycle, at CPI ≈ 4–6.
* **ECC:** correctable errors are corrected on read but not scrubbed back. A word with a latent single-bit error stays correctable until overwritten. There is no patrol scrubber.
* **Mailbox queues are flop-based.** At HPC depth (16) the command FIFO is the largest block (≈159,000 µm²). They should move to SRAM.
* **Telemetry:** 48 × 64-bit counters cost 32% of ALBION_MIN standard-cell area. 48-bit counters would be ample.

## Implementation evidence (block silicon and FPGA claims)

* **No physical design has been run** (no OpenROAD, ORFS or compiled SRAM macro here). SRAM area and timing are unknown. No tapeout readiness.
* **No timing closure, and the first FPGA place-and-route misses its target.** On ECP5-85F, nextpnr reaches **19.45 MHz post-route against a 50 MHz target**. The critical path (51.4 ns) runs from an SRAM BRAM read through SECDED decode and the fabric response mux into the DMA's same-cycle re-issue, then through fabric arbitration into the MMIO register write enable of the permission table. The micro-architecture gets its 4 B/cycle by chaining a response combinationally into the next request, and that chaining is the timing problem. Planned fix: a registered SECDED stage on SRAM responses and a registered MMIO request stage, with two outstanding DMA requests per port to preserve throughput. The full regression must then be re-run. ABC per-module delays (≈10 ns after sizing, no wires) understate this because the worst path crosses module boundaries. Throughput is quoted in bytes/cycle, never GB/s.
* **No power or thermal analysis.** The terminal shows "no recorded data source".
* **FPGA:** place-and-route and bitstream only. No board programmed, no host transfer on FPGA, no board-specific host bridge.
* **No DFT** (scan, MBIST, JTAG).

## Host integration

* **No PCIe endpoint.** The host interface is simulated. VFIO support is discovery-only, and BAR/DMA mapping is refused until an endpoint exists. The PCI vendor ID is a placeholder.
* **No Kubernetes device plugin.** Its gate (real device discovery) is not met; see [kubernetes.md](kubernetes.md).
* **The runtime is the trusted host driver.** Multi-tenant use needs the host service (`albion-hostd`) described in [linux_integration.md](linux_integration.md), which is not written.

## Security

* No secure boot, attestation or crypto (Citadel P89 absent). The host loads unauthenticated firmware.
* No side-channel analysis. Telemetry is visible to the host admin and must not be exposed raw to tenants.
* Isolation is verified in simulation and formally for the fabric, but **secure multi-tenant partitions are not advertised.**

## Verification

* Toggle coverage is 69%, because many upper counter bits and wide data bits never toggle in the workloads. Line coverage is 96% and branch 90%; the uncovered lines are listed in `reports/coverage/coverage_ALBION_MIN.json`.
* The DMA bounds proof is bounded (20 cycles from reset), not unbounded. The SECDED, fabric-permission and FIFO proofs are complete.
* Simulation only uses Verilator 2-state semantics (randomised initial values with `--x-initial unique`). There is no 4-state X-propagation run and no gate-level simulation.
