# SilicaFlux Albion — Physical-Design Assumptions

## Status

Configured, **not executed**. `make albion-floorplan` checks for OpenROAD, OpenROAD-flow-scripts with the sky130hd platform, and a compiled SRAM macro (LEF, Liberty, GDS). None are present in this environment, so it writes `reports/physical/status.json` listing them and exits with status 2. No floorplan, placement, CTS, routing or parasitic extraction has been run. **No tapeout readiness is claimed.**

## Configuration (`physical/albion/`)

| File | Content |
|---|---|
| `sky130hd/config.mk` | ORFS design config: hierarchical synthesis, SRAM macro hooks (`ALBION_SRAM_LEF/LIB/GDS`), 35% core utilisation, 0.55 placement density, macro halo 20 µm, BLOCKS PDN strategy, routability-driven global placement |
| `constraint.sdc` | single clock `clk_i`, 20 ns first-pass target, 30% I/O budgets, false paths on the async reset and the static debug strap |
| `macro_placement.tcl` | four SRAM macros at the core corners (bank 0 nearest the ControlCore); coordinates computed from the macro's real size at run time |
| `io_constraints.tcl` | host MMIO target on the west edge (towards the PCIe controller), host-memory requester on the south, clock/reset/status on the north, trace on the east |
| `sram_macro_blackbox.sv` | blackbox for the 4096 × 39 1RW macro |

The flow covers RTL synthesis, floorplan, SRAM macro placement, pin planning, PDN, placement, clock-tree synthesis and global routing. Detailed routing, timing analysis and parasitic extraction run when ORFS is present (`synth floorplan place cts grt`, then `route finish` as a separate step).

## Assumptions

* **Technology profile:** sky130hd (`sky130_fd_sc_hd`, tt 25 °C 1.8 V) for the first open-PDK pass. A commercial node needs its own platform config and compiled memories. Nothing in the RTL is technology-specific.
* **SRAM:** 4 (MIN) or 8 (CLOUD/HPC) single-port macros of 4096 or 8192 words × 39 bits. OpenRAM can generate sky130 1RW macros; no area or timing is assumed until one is compiled (Project 84 rule).
* **Standard-cell area:** synthesis estimates are in `reports/synth/` (MIN ≈ 0.47 mm² of standard cells). At 35% utilisation the logic alone needs a core of about 1.35 mm², plus macros and halos.
* **Timing risk ranking.** The ECP5 post-route critical path (51.4 ns, 19.45 MHz) is a cross-module chain: SRAM read → SECDED decode (≈4 ns of logic alone in sky130) → fabric response mux → DMA same-cycle re-issue → fabric decode/permission/arbitration → MMIO register write enable. ABC per-module estimates (no wires) rank the MMIO register read multiplexers (mgmt, perm, telemetry) next. Fixes before any ASIC run: a registered SECDED stage on SRAM responses, a registered MMIO request stage and a registered permission result, each costing one cycle of latency, with two outstanding DMA requests to keep throughput.
* **Power:** no analysis has been performed. The largest standard-cell consumers by area are the 48 × 64-bit telemetry counters (32% of MIN) and the flop-based mailbox FIFOs, which reach 21% of HPC. Narrower counters, and holding mailbox queues in SRAM, are the obvious area and power reductions.
* **DFT:** no scan insertion, no MBIST for the SRAM macros, no JTAG. A real tapeout needs all three.
