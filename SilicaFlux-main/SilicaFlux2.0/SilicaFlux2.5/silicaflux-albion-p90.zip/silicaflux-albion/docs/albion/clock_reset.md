# SilicaFlux Albion — Clock and Reset Specification

## Clock

* One clock domain, `clk_i`. Every flop in `sf_albion_cloud_top` is clocked by it, so the design has no clock-domain crossings.
* The host interface ports are synchronous to `clk_i`. A PCIe integration must place its own CDC (asynchronous FIFOs) between the PCIe user clock and `clk_i`. That logic belongs to the PCIe adapter, not to this RTL.
* No frequency has been closed. The ECP5 place-and-route and the sky130 ABC estimates are recorded in `reports/` as estimates only. The sky130 SDC (`physical/albion/constraint.sdc`) sets a 50 MHz first-pass target.

## Resets

| Source | Type | Scope | Effect |
|---|---|---|---|
| `rst_ni` pin | async assert, sync deassert (2-flop synchroniser in `sf_albion_rstctl`) | whole device | everything below is reset |
| `MGMT.SOFT_RESET` = `0xA1B05E70` (host) | synchronous pulse, stretched to 16 cycles | whole device except the stretcher | identical to a pin reset |
| `MGMT.CORE_CTRL.RUN` = 0 | synchronous | ControlCore only | core held in reset (boot mode) |

The internal reset `rst_n` is registered (glitch-free) and synchronous to `clk_i`. All other logic uses synchronous reset. The soft-reset stretcher is reset only by the pin, so a soft reset cannot cancel itself.

## Reset sequence

1. `rst_n` deasserts. Every SRAM bank begins **scrub-on-reset**, writing encode(0) to each word, one word per cycle and all banks in parallel. That takes 4096 cycles in MIN/CLOUD and 8192 in HPC. Until `DEV_STATUS.INIT_DONE`, banks are not ready, and fabric requests to SRAM stall rather than fail.
2. When `INIT_DONE` is set, `DEV_STATUS.BOOT_MODE` = 1 (core in reset, boot not locked). The host may now write the firmware image into SRAM (bank 0) and may read it back.
3. The host writes `CORE_CTRL.RUN = 1`. The ControlCore leaves reset at PC 0.
4. The firmware clears every permission window, sets `BOOT_LOCK` (sticky until reset), enables its interrupt sources and reports `FW_STATUS = READY (2)`. From `BOOT_LOCK` onward the host has no SRAM access, and `CORE_CTRL` writes are ignored.

## Reset guarantees (tested)

* **No data survives a reset.** Scrub-on-reset zeroes all SRAM, including tenant data, so a pin reset in the middle of a DMA leaves a clean device. `pin_reset_during_dma_returns_clean_device`, `soft_reset_during_dma` and `soft_reset_clears_tenant_state` test this.
* All permission windows are invalid after reset. They stay invalid until firmware opens them.
* Telemetry, RAS log, queues, the DMA engine and boot lock are all cleared.
* The host memory belongs to the host and is not affected.

## Not covered

There is no warm reset of individual engines (DMA abort) other than full device reset. There is no reset of a single tenant's state other than FREE/UNMAP. There is no power gating, retention or clock gating.
