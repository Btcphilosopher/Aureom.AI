#!/usr/bin/env bash
# SilicaFlux Albion physical design entry point (make albion-floorplan).
# Runs ORFS synth -> floorplan -> place -> cts -> grt -> (route) for sky130hd when every
# prerequisite exists; otherwise records exactly what is missing and exits with status 2.
# Physical results are only meaningful with the real sky130 libraries AND a compiled SRAM
# macro; no tapeout readiness is implied by any result of this script.
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/reports/physical"; mkdir -p "$OUT"
missing=()
command -v openroad >/dev/null 2>&1 || missing+=("openroad binary (OpenROAD)")
[ -n "${ORFS_ROOT:-}" ] && [ -f "${ORFS_ROOT}/flow/Makefile" ] || missing+=("ORFS_ROOT pointing at OpenROAD-flow-scripts")
[ -n "${ORFS_ROOT:-}" ] && [ -d "${ORFS_ROOT}/flow/platforms/sky130hd" ] || missing+=("sky130hd platform in ORFS")
for v in ALBION_SRAM_LEF ALBION_SRAM_LIB ALBION_SRAM_GDS; do
  f="${!v:-}"; [ -n "$f" ] && [ -f "$f" ] || missing+=("$v (compiled 4096x39 1RW SRAM macro view)")
done
stamp=$(date -u +%FT%TZ)
if [ ${#missing[@]} -ne 0 ]; then
  echo "albion-floorplan: UNAVAILABLE - missing prerequisites:"
  printf '  - %s\n' "${missing[@]}"
  python3 - "$OUT/status.json" "$stamp" "${missing[@]}" <<'PY'
import json, sys
json.dump({"category": "physical", "status": "unavailable", "generated": sys.argv[2],
           "missing": sys.argv[3:],
           "configuration": ["physical/albion/sky130hd/config.mk", "physical/albion/constraint.sdc",
                             "physical/albion/macro_placement.tcl", "physical/albion/io_constraints.tcl"],
           "note": "no floorplan, placement, CTS, routing or parasitic extraction has been run"},
          open(sys.argv[1], "w"), indent=2)
PY
  exit 2
fi
cd "$ORFS_ROOT/flow"
make DESIGN_CONFIG="$ROOT/physical/albion/sky130hd/config.mk" ALBION_ROOT="$ROOT" synth floorplan place cts grt 2>&1 | tee "$OUT/orfs.log"
rc=${PIPESTATUS[0]}
python3 - "$OUT/status.json" "$stamp" "$rc" <<'PY'
import json, sys
json.dump({"category": "physical", "status": "ran" if sys.argv[3] == "0" else "failed", "generated": sys.argv[2],
           "orfs_exit": int(sys.argv[3]), "log": "reports/physical/orfs.log",
           "note": "results require review; no sign-off (DRC/LVS/STA at all corners) has been performed"},
          open(sys.argv[1], "w"), indent=2)
PY
exit $rc
