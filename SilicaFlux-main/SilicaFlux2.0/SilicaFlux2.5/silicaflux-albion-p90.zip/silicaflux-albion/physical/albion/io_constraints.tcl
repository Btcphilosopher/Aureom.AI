# SilicaFlux Albion - pin planning. Host MMIO target on the west edge (towards the PCIe
# controller), host-memory requester on the south edge, clock/reset/status on the north.
place_pins -hor_layers met3 -ver_layers met2 -random_seed 1
set_io_pin_constraint -direction input  -pin_names {h_req_*}  -region left:*
set_io_pin_constraint -direction output -pin_names {h_rsp_* h_req_ready_o} -region left:*
set_io_pin_constraint -pin_names {hm_*}        -region bottom:*
set_io_pin_constraint -pin_names {clk_i rst_ni dbg_strap_i host_irq_o init_done_o core_run_o boot_lock_o} -region top:*
set_io_pin_constraint -pin_names {trace_*}     -region right:*
