# SilicaFlux Albion - SRAM macro placement (ALBION_MIN: 4 banks).
# Banks sit on the north and south edges so the DataFabric crossbar and DMA engine
# occupy the centre; bank 0 (firmware-private, ControlCore fetch path) is placed
# nearest the ControlCore on the west side. Coordinates are derived from the macro
# size at run time: no macro size is assumed in this repository.
set die  [ord::get_die_area]
set core [ord::get_core_area]
set cx0 [lindex $core 0]; set cy0 [lindex $core 1]; set cx1 [lindex $core 2]; set cy1 [lindex $core 3]
set macros [lsort [get_cells -hierarchical *u_mem]]
proc mw {m} { set b [[odb::get_master [$m get_master]] getWidth]; return [ord::dbu_to_microns $b] }
set halo 20
set i 0
foreach m $macros {
  set inst [[ord::get_db_block] findInst [get_full_name $m]]
  set w [ord::dbu_to_microns [[$inst getMaster] getWidth]]
  set h [ord::dbu_to_microns [[$inst getMaster] getHeight]]
  switch $i {
    0 { set x [expr $cx0 + $halo];            set y [expr $cy0 + $halo] }
    1 { set x [expr $cx1 - $halo - $w];       set y [expr $cy0 + $halo] }
    2 { set x [expr $cx0 + $halo];            set y [expr $cy1 - $halo - $h] }
    default { set x [expr $cx1 - $halo - $w]; set y [expr $cy1 - $halo - $h] }
  }
  place_macro -macro_name [get_full_name $m] -location [list $x $y] -orientation R0
  incr i
}
