// Blackbox for physical design: replaced by the compiled SRAM macro's LEF/Liberty.
(* blackbox *)
module sf_albion_sram_macro #(parameter int WORDS = 4096, parameter int W = 39, parameter int AW = $clog2(WORDS)) (
  input logic clk, input logic en, input logic we, input logic [AW-1:0] addr, input logic [W-1:0] wdata, output logic [W-1:0] rdata);
endmodule
