# SilicaFlux Albion - timing constraints (single clock domain).
# 50 MHz is a first-pass target for sky130hd with an SRAM macro in the read path
# (macro clock-to-q + SECDED decode + fabric response mux). It is a goal, not a result.
set clk_period 20.0
create_clock -name clk -period $clk_period [get_ports clk_i]
set_clock_uncertainty 0.5 [get_clocks clk]
# host interface: registered on the far side (PCIe bridge), 30% budget each way
set io_ports [remove_from_collection [all_inputs] [get_ports {clk_i rst_ni}]]
set_input_delay  [expr 0.3 * $clk_period] -clock clk $io_ports
set_output_delay [expr 0.3 * $clk_period] -clock clk [all_outputs]
# asynchronous reset assert, synchronised internally (sf_albion_rstctl)
set_false_path -from [get_ports rst_ni]
# debug strap is a static pin
set_false_path -from [get_ports dbg_strap_i]
set_load 0.02 [all_outputs]
set_driving_cell -lib_cell sky130_fd_sc_hd__buf_4 $io_ports
