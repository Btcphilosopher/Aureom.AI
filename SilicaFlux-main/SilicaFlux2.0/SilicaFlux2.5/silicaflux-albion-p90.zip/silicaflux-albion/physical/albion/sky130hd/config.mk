# SilicaFlux Albion - OpenROAD-flow-scripts (ORFS) configuration, sky130hd.
# Usage (from an ORFS checkout):  make DESIGN_CONFIG=<repo>/physical/albion/sky130hd/config.mk
# Prerequisites that are NOT in this repository (physical/albion/run_floorplan.sh checks them):
#   * OpenROAD + OpenROAD-flow-scripts with the sky130hd platform
#   * a compiled 4096 x 39 single-port SRAM macro (LEF + Liberty + GDS), e.g. from OpenRAM,
#     exported through ALBION_SRAM_LEF / ALBION_SRAM_LIB / ALBION_SRAM_GDS
ALBION_ROOT          ?= $(abspath $(dir $(lastword $(MAKEFILE_LIST)))/../../..)
export PLATFORM        = sky130hd
export DESIGN_NAME     = sf_albion_cloud_top
export DESIGN_NICKNAME = albion_min
export VERILOG_FILES   = $(addprefix $(ALBION_ROOT)/,$(shell grep -v sram_macro $(ALBION_ROOT)/rtl/albion/sf_albion.f))
export VERILOG_FILES_BLACKBOX = $(ALBION_ROOT)/physical/albion/sram_macro_blackbox.sv
export VERILOG_DEFINES = -DSYNTHESIS
export SDC_FILE        = $(ALBION_ROOT)/physical/albion/constraint.sdc
export SYNTH_HIERARCHICAL = 1
# compiled SRAM macro (4 instances in ALBION_MIN: u_soc/g_bank[*].u_bank/u_mem)
export ADDITIONAL_LEFS = $(ALBION_SRAM_LEF)
export ADDITIONAL_LIBS = $(ALBION_SRAM_LIB)
export ADDITIONAL_GDS  = $(ALBION_SRAM_GDS)
# floorplan: core utilisation target for standard cells; macros placed explicitly
export CORE_UTILIZATION   = 35
export PLACE_DENSITY      = 0.55
export MACRO_PLACEMENT_TCL = $(ALBION_ROOT)/physical/albion/macro_placement.tcl
export MACRO_PLACE_HALO   = 20 20
export IO_CONSTRAINTS     = $(ALBION_ROOT)/physical/albion/io_constraints.tcl
export PDN_TCL            = $(PLATFORM_DIR)/openRoad/pdn/BLOCKS_grid_strategy.tcl
export TNS_END_PERCENT    = 100
export GPL_ROUTABILITY_DRIVEN = 1
export SKIP_LAST_GASP     = 1
