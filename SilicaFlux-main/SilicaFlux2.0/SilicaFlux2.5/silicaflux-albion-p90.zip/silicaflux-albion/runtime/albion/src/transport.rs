//! Backend transport: the minimum a host needs from a device - MMIO to BAR0,
//! access to its own (DMA-able) memory, and device time.
use crate::error::Result;

pub trait Transport: Send {
    /// Backend name for reports ("reference", "rtl-sim:ALBION_MIN", "vfio:0000:03:00.0").
    fn name(&self) -> String;
    /// MMIO read. Returns (data, fabric response code).
    fn mmio_read(&mut self, addr: u32) -> Result<(u32, u32)>;
    /// MMIO write. Returns the fabric response code.
    fn mmio_write(&mut self, addr: u32, data: u32) -> Result<u32>;
    /// Sequential MMIO writes; returns the number of non-OK responses.
    fn mmio_write_burst(&mut self, addr: u32, data: &[u32]) -> Result<u32> {
        let mut nerr = 0;
        for (i, d) in data.iter().enumerate() {
            if self.mmio_write(addr + 4 * i as u32, *d)? != 0 {
                nerr += 1;
            }
        }
        Ok(nerr)
    }
    /// Host CPU access to host memory (not a device transaction).
    fn host_write(&mut self, iova: u32, data: &[u32]) -> Result<()>;
    fn host_read(&mut self, iova: u32, n: usize) -> Result<Vec<u32>>;
    /// Let the device run (simulation time). No-op for untimed backends.
    fn advance(&mut self, cycles: u64) -> Result<()>;
    /// Run until the host interrupt asserts or `max_cycles` pass. Returns whether it fired.
    fn wait_irq(&mut self, max_cycles: u64) -> Result<bool>;
    /// Device clock cycles elapsed (None for untimed backends).
    fn cycles(&mut self) -> Result<Option<u64>>;
    /// Pin reset of the whole device.
    fn reset(&mut self) -> Result<()>;
    /// Debug strap pin (enables RAW_DMA). Not available on production hardware.
    fn set_debug_strap(&mut self, on: bool) -> Result<()>;
    /// Host memory latency in device cycles (simulation only).
    fn set_host_latency(&mut self, cycles: u32) -> Result<()>;
    /// Make a host IOVA range fault (models an IOMMU fault; simulation only).
    fn add_host_fault(&mut self, iova: u32, bytes: u32) -> Result<()>;
    /// Optional retirement trace (RTL only).
    fn set_trace(&mut self, _path: Option<&str>) -> Result<()> {
        Ok(())
    }
    /// Release resources.
    fn shutdown(&mut self) -> Result<()>;
}
