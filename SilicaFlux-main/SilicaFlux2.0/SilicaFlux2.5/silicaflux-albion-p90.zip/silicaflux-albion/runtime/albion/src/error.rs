//! Runtime error type.
use std::fmt;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Error {
    /// Transport / process I/O failure.
    Io(String),
    /// The device or simulator answered something unexpected.
    Protocol(String),
    /// A bounded wait expired.
    Timeout(String),
    /// Caller passed something invalid (before reaching the device).
    InvalidArgument(String),
    /// The device reported a failure during bring-up or a fabric error.
    Device(String),
    /// Feature or backend not available in this build / on this host.
    Unavailable(String),
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::Io(s) => write!(f, "io: {s}"),
            Error::Protocol(s) => write!(f, "protocol: {s}"),
            Error::Timeout(s) => write!(f, "timeout: {s}"),
            Error::InvalidArgument(s) => write!(f, "invalid argument: {s}"),
            Error::Device(s) => write!(f, "device: {s}"),
            Error::Unavailable(s) => write!(f, "unavailable: {s}"),
        }
    }
}

impl std::error::Error for Error {}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        Error::Io(e.to_string())
    }
}

pub type Result<T> = std::result::Result<T, Error>;
