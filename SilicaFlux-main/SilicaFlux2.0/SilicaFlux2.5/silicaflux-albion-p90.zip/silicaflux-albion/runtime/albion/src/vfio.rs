//! Linux host-device access: VFIO discovery (see docs/albion/linux_integration.md).
//!
//! Chosen mechanism: the device's PCIe function is bound to `vfio-pci`; the
//! runtime opens the VFIO group, maps BAR0 (MMIO pages MGMT/TELEM/RAS only are
//! exposed by the BAR layout) and registers DMA buffers with
//! VFIO_IOMMU_MAP_DMA so the host IOMMU confines device DMA to pinned,
//! explicitly-mapped IOVA ranges. Tenants never receive the VFIO fd; the trusted
//! host service (or the Kubernetes device plugin) owns it and assigns domains.
//!
//! Status in this repository: discovery is implemented and tested (it walks
//! sysfs); the BAR-mapping/DMA-mapping path is NOT implemented because no PCIe
//! endpoint exists yet (the PCIe controller is external IP and there is no FPGA
//! board or silicon). `open_vfio` therefore returns `Unavailable` with the reason
//! instead of pretending.
use crate::error::{Error, Result};
use std::path::{Path, PathBuf};

/// PCI vendor/device the Albion endpoint will enumerate as. The vendor ID is a
/// placeholder pending PCI-SIG assignment for Aureom.AI.
pub const ALBION_PCI_VENDOR: u16 = 0x1D0F; // PLACEHOLDER - not an assigned Aureom.AI ID
pub const ALBION_PCI_DEVICE: u16 = 0xA190;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PciCandidate {
    pub bdf: String,
    pub vendor: u16,
    pub device: u16,
    pub driver: Option<String>,
    pub iommu_group: Option<u32>,
}

impl PciCandidate {
    /// True when the function can be used safely from user space.
    pub fn vfio_ready(&self) -> bool {
        self.driver.as_deref() == Some("vfio-pci") && self.iommu_group.is_some()
    }
}

fn read_hex(p: &Path) -> Option<u16> {
    let s = std::fs::read_to_string(p).ok()?;
    u16::from_str_radix(s.trim().trim_start_matches("0x"), 16).ok()
}

/// Scan `sysfs_root`/bus/pci/devices for Albion functions.
pub fn discover_in(sysfs_root: &Path) -> Vec<PciCandidate> {
    let dir = sysfs_root.join("bus/pci/devices");
    let Ok(rd) = std::fs::read_dir(&dir) else { return vec![] };
    let mut out = vec![];
    for e in rd.flatten() {
        let p = e.path();
        let (Some(v), Some(d)) = (read_hex(&p.join("vendor")), read_hex(&p.join("device"))) else { continue };
        if v != ALBION_PCI_VENDOR || d != ALBION_PCI_DEVICE {
            continue;
        }
        let driver = std::fs::read_link(p.join("driver"))
            .ok()
            .and_then(|l| l.file_name().map(|f| f.to_string_lossy().to_string()));
        let iommu_group = std::fs::read_link(p.join("iommu_group"))
            .ok()
            .and_then(|l| l.file_name().and_then(|f| f.to_string_lossy().parse().ok()));
        out.push(PciCandidate { bdf: e.file_name().to_string_lossy().to_string(), vendor: v, device: d, driver, iommu_group });
    }
    out.sort_by(|a, b| a.bdf.cmp(&b.bdf));
    out
}

pub fn discover() -> Vec<PciCandidate> {
    discover_in(Path::new("/sys"))
}

/// Attempt to open a VFIO-bound Albion function.
pub fn open_vfio(bdf: &str) -> Result<()> {
    let found = discover();
    let Some(c) = found.iter().find(|c| c.bdf == bdf) else {
        return Err(Error::Unavailable(format!("no Albion PCIe function {bdf} (found {})", found.len())));
    };
    if !c.vfio_ready() {
        return Err(Error::Unavailable(format!(
            "{bdf} is not bound to vfio-pci with an IOMMU group (driver {:?}); refusing unprotected access",
            c.driver
        )));
    }
    Err(Error::Unavailable(
        "VFIO BAR/DMA mapping is not implemented: no Albion PCIe endpoint exists yet (see docs/albion/linux_integration.md)".into(),
    ))
}

/// Helper used by tests: path of a fake sysfs tree.
pub fn fake_sysfs_device(root: &Path, bdf: &str, vendor: u16, device: u16) -> std::io::Result<PathBuf> {
    let p = root.join("bus/pci/devices").join(bdf);
    std::fs::create_dir_all(&p)?;
    std::fs::write(p.join("vendor"), format!("0x{vendor:04x}\n"))?;
    std::fs::write(p.join("device"), format!("0x{device:04x}\n"))?;
    Ok(p)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn discovery_filters_and_reports_unbound() {
        let root = std::env::temp_dir().join(format!("albion_sysfs_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        fake_sysfs_device(&root, "0000:03:00.0", ALBION_PCI_VENDOR, ALBION_PCI_DEVICE).unwrap();
        fake_sysfs_device(&root, "0000:04:00.0", 0x8086, 0x1234).unwrap();
        let found = discover_in(&root);
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].bdf, "0000:03:00.0");
        assert!(!found[0].vfio_ready(), "no driver / iommu group -> must not be usable");
        let _ = std::fs::remove_dir_all(&root);
    }
    #[test]
    fn open_refuses_missing_device() {
        assert!(matches!(open_vfio("0000:ff:1f.7"), Err(Error::Unavailable(_))));
    }
}
