//! The Albion host driver: bring-up, the mailbox protocol and the public API
//! (open / info / alloc / submit / poll / wait / counters / close). Identical code
//! runs on every backend; only the [`Transport`] differs.
use crate::error::{Error, Result};
use crate::proto::{Command, Completion, Status, Work};
use crate::refmodel::RefTransport;
use crate::regs;
use crate::rtlsim::RtlSim;
use crate::transport::Transport;
use std::collections::BTreeMap;
use std::path::PathBuf;

/// Which backend to open.
#[derive(Debug, Clone)]
pub enum Backend {
    /// Untimed executable reference model (no simulator, no hardware).
    Reference,
    /// Verilator full-chip simulation. `binary` defaults to build/sim/cfg<N>/albion_sim.
    RtlSim { binary: Option<PathBuf> },
}

#[derive(Debug, Clone)]
pub struct OpenOptions {
    pub backend: Backend,
    /// 0 = ALBION_MIN, 1 = ALBION_CLOUD, 2 = ALBION_HPC.
    pub config: u32,
    /// Firmware image; defaults to $SF_ALBION_FW or build/firmware/albion_fw.bin.
    pub firmware: Option<PathBuf>,
    /// Security domain for tenant operations issued by this session (2..15).
    pub domain: u8,
    /// Drive the debug strap (simulation only; enables RAW_DMA).
    pub debug_strap: bool,
    /// Host memory latency in device cycles (simulation only).
    pub host_latency: u32,
    /// Verify the firmware image after loading it.
    pub verify_firmware: bool,
}

impl Default for OpenOptions {
    fn default() -> Self {
        OpenOptions {
            backend: Backend::Reference,
            config: 0,
            firmware: None,
            domain: regs::DOM_TENANT_MIN,
            debug_strap: false,
            host_latency: 1,
            verify_firmware: true,
        }
    }
}

/// Static device description read back from the hardware registers.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DeviceInfo {
    pub backend: String,
    pub chip_id: u32,
    pub rtl_version: u32,
    pub config_id: u32,
    pub config_name: String,
    pub feat_impl: u32,
    pub feat_req: u32,
    pub feat_unavail: u32,
    pub sram_banks: u32,
    pub sram_bank_bytes: u32,
    pub windows: u32,
    pub cmdq_depth: u32,
    pub fw_version: u32,
    pub build_id: u32,
}

impl DeviceInfo {
    /// Human-readable feature table (name, requested, implemented, provider).
    pub fn feature_table(&self) -> Vec<(String, bool, bool, String)> {
        regs::FEATURES
            .iter()
            .map(|(n, bit, p)| (n.to_string(), self.feat_req & bit != 0, self.feat_impl & bit != 0, p.to_string()))
            .collect()
    }
    pub fn has(&self, feat: u32) -> bool {
        self.feat_impl & feat == feat
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MemKind {
    /// Device SRAM, zeroed, private to the session domain.
    DeviceSram,
    /// Host memory mapped into a DMA window for the session domain.
    Host,
}

/// An allocation. `addr` is the DataFabric address used in [`Work`] items.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Buffer {
    pub kind: MemKind,
    pub addr: u32,
    pub size: u32,
    pub window: u32,
    pub domain: u8,
    /// Host IOVA for host buffers.
    pub iova: u32,
}

/// Telemetry snapshot.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Counters {
    pub values: Vec<u64>,
}

impl Counters {
    pub fn get(&self, idx: usize) -> u64 {
        self.values.get(idx).copied().unwrap_or(0)
    }
    pub fn named(&self) -> Vec<(&'static str, u64)> {
        regs::TELEMETRY_NAMES.iter().copied().zip(self.values.iter().copied()).collect()
    }
    /// Counters whose value is architecturally deterministic (comparable across backends).
    pub fn deterministic_indices() -> Vec<usize> {
        let mut v = vec![
            regs::TC_DMA_BYTES,
            regs::TC_DMA_DESC_DONE,
            regs::TC_DMA_ERRORS,
            regs::TC_PERM_VIOL,
            regs::TC_DECERR,
            regs::TC_ECC_CE,
            regs::TC_ECC_UE,
            regs::TC_CMD_SUBMITTED,
            regs::TC_CPL_POSTED,
            regs::TC_CMDQ_DROPS,
        ];
        v.extend(regs::TC_DOM0_BYTES..regs::TC_DOM0_BYTES + 16);
        v
    }
}

/// Opaque submission handle.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct Ticket(pub u16);

const POLL_CHUNK_CYCLES: u64 = 2_000;

pub struct Device {
    t: Box<dyn Transport>,
    info: DeviceInfo,
    domain: u8,
    next_tag: u16,
    outstanding: BTreeMap<u16, u8>,
    done: BTreeMap<u16, Completion>,
    buffers: Vec<Buffer>,
    next_iova: u32,
    closed: bool,
}

pub(crate) fn default_firmware() -> PathBuf {
    std::env::var("SF_ALBION_FW")
        .map(PathBuf::from)
        .unwrap_or_else(|_| crate::repo_root().join("build/firmware/albion_fw.bin"))
}

impl Device {
    /// `sf_albion_open`: reset, wait for SRAM scrub, load and start firmware, read info.
    pub fn open(opts: &OpenOptions) -> Result<Device> {
        if opts.config > 2 {
            return Err(Error::InvalidArgument(format!("unknown config {}", opts.config)));
        }
        if !(regs::DOM_TENANT_MIN..=15).contains(&opts.domain) {
            return Err(Error::InvalidArgument(format!("session domain {} is not a tenant domain (2..15)", opts.domain)));
        }
        let t: Box<dyn Transport> = match &opts.backend {
            Backend::Reference => Box::new(RefTransport::new(opts.config)),
            Backend::RtlSim { binary } => {
                let bin = binary.clone().unwrap_or_else(|| RtlSim::default_binary(opts.config));
                Box::new(RtlSim::spawn(&bin, regs::CONFIG_NAMES[opts.config as usize], &[])?)
            }
        };
        let fw = opts.firmware.clone().unwrap_or_else(default_firmware);
        let image = std::fs::read(&fw)
            .map_err(|e| Error::Unavailable(format!("firmware image {}: {e} (run `make albion-firmware`)", fw.display())))?;
        Self::bring_up(t, &image, opts)
    }

    /// Open on an already-constructed transport (used by tests and tools).
    pub fn open_with(t: Box<dyn Transport>, image: &[u8], opts: &OpenOptions) -> Result<Device> {
        Self::bring_up(t, image, opts)
    }

    fn bring_up(mut t: Box<dyn Transport>, image: &[u8], opts: &OpenOptions) -> Result<Device> {
        t.reset()?;
        t.set_debug_strap(opts.debug_strap)?;
        t.set_host_latency(opts.host_latency.max(1))?;
        let mut dev = Device {
            t,
            info: DeviceInfo {
                backend: String::new(),
                chip_id: 0,
                rtl_version: 0,
                config_id: 0,
                config_name: String::new(),
                feat_impl: 0,
                feat_req: 0,
                feat_unavail: 0,
                sram_banks: 0,
                sram_bank_bytes: 0,
                windows: 0,
                cmdq_depth: 0,
                fw_version: 0,
                build_id: 0,
            },
            domain: opts.domain,
            next_tag: 1,
            outstanding: BTreeMap::new(),
            done: BTreeMap::new(),
            buffers: vec![],
            next_iova: 0x0010_0000,
            closed: false,
        };
        let chip = dev.mgmt(regs::MGMT_CHIP_ID)?;
        if chip != regs::CHIP_ID {
            return Err(Error::Device(format!("unexpected CHIP_ID 0x{chip:08x}")));
        }
        // wait for scrub-on-reset
        let mut tries = 0;
        while dev.mgmt(regs::MGMT_DEV_STATUS)? & (1 << regs::MGMT_DEV_STATUS_INIT_DONE_LSB) == 0 {
            tries += 1;
            if tries > 200 {
                return Err(Error::Timeout("SRAM scrub-on-reset did not complete".into()));
            }
            dev.t.advance(POLL_CHUNK_CYCLES)?;
        }
        dev.load_firmware(image, opts.verify_firmware)?;
        dev.mmio_w(regs::MGMT_BASE + regs::MGMT_CORE_CTRL, 1)?;
        let mut tries = 0;
        loop {
            let st = dev.mgmt(regs::MGMT_FW_STATUS)?;
            if st == 2 {
                break;
            }
            if st & 0xFFFF_0000 == 0xDEAD_0000 {
                return Err(Error::Device(format!("firmware fatal during boot: 0x{st:08x}")));
            }
            tries += 1;
            if tries > 200 {
                return Err(Error::Timeout(format!("firmware did not report READY (FW_STATUS=0x{st:08x})")));
            }
            dev.t.advance(POLL_CHUNK_CYCLES)?;
        }
        dev.mmio_w(regs::MGMT_BASE + regs::MGMT_HOST_IRQ_ENABLE, 1)?;
        dev.info = dev.read_info()?;
        Ok(dev)
    }

    fn load_firmware(&mut self, image: &[u8], verify: bool) -> Result<()> {
        if image.is_empty() || image.len() > 16 * 1024 {
            return Err(Error::InvalidArgument(format!("firmware image size {} (1..16384 bytes)", image.len())));
        }
        if self.mgmt(regs::MGMT_DEV_STATUS)? & (1 << regs::MGMT_DEV_STATUS_BOOT_MODE_LSB) == 0 {
            return Err(Error::Device("device is not in boot mode".into()));
        }
        let mut words: Vec<u32> = image.chunks(4).map(|c| {
            let mut b = [0u8; 4];
            b[..c.len()].copy_from_slice(c);
            u32::from_le_bytes(b)
        }).collect();
        if words.is_empty() {
            words.push(0);
        }
        let nerr = self.t.mmio_write_burst(regs::SRAM_BASE, &words)?;
        if nerr != 0 {
            return Err(Error::Device(format!("{nerr} firmware load writes failed")));
        }
        if verify {
            for (i, w) in words.iter().enumerate() {
                let (d, e) = self.t.mmio_read(regs::SRAM_BASE + 4 * i as u32)?;
                if e != 0 || d != *w {
                    return Err(Error::Device(format!("firmware verify mismatch at word {i}: 0x{d:08x} != 0x{w:08x} (err {e})")));
                }
            }
        }
        Ok(())
    }

    fn mgmt(&mut self, off: u32) -> Result<u32> {
        let (d, e) = self.t.mmio_read(regs::MGMT_BASE + off)?;
        if e != 0 {
            return Err(Error::Device(format!("MGMT read 0x{off:03x} -> fabric error {e}")));
        }
        Ok(d)
    }

    fn mmio_w(&mut self, addr: u32, v: u32) -> Result<()> {
        let e = self.t.mmio_write(addr, v)?;
        if e != 0 {
            return Err(Error::Device(format!("MMIO write 0x{addr:08x} -> fabric error {e}")));
        }
        Ok(())
    }

    fn read_info(&mut self) -> Result<DeviceInfo> {
        let config_id = self.mgmt(regs::MGMT_CONFIG_ID)?;
        Ok(DeviceInfo {
            backend: self.t.name(),
            chip_id: self.mgmt(regs::MGMT_CHIP_ID)?,
            rtl_version: self.mgmt(regs::MGMT_VERSION)?,
            config_id,
            config_name: regs::CONFIG_NAMES.get(config_id as usize).unwrap_or(&"UNKNOWN").to_string(),
            feat_impl: self.mgmt(regs::MGMT_FEAT_IMPL)?,
            feat_req: self.mgmt(regs::MGMT_FEAT_REQ)?,
            feat_unavail: self.mgmt(regs::MGMT_FEAT_UNAVAIL)?,
            sram_banks: self.mgmt(regs::MGMT_SRAM_BANKS)?,
            sram_bank_bytes: self.mgmt(regs::MGMT_SRAM_BANK_BYTES)?,
            windows: self.mgmt(regs::MGMT_NUM_WINDOWS)?,
            cmdq_depth: self.mgmt(regs::MGMT_CMDQ_DEPTH)?,
            fw_version: self.mgmt(regs::MGMT_FW_VERSION)?,
            build_id: self.mgmt(regs::MGMT_BUILD_ID)?,
        })
    }

    /// `sf_albion_info`.
    pub fn info(&self) -> &DeviceInfo {
        &self.info
    }

    pub fn domain(&self) -> u8 {
        self.domain
    }

    /// Switch the session domain (models the trusted host driver acting for another tenant).
    pub fn set_domain(&mut self, domain: u8) -> Result<()> {
        if !(regs::DOM_TENANT_MIN..=15).contains(&domain) {
            return Err(Error::InvalidArgument(format!("domain {domain} is not a tenant domain")));
        }
        self.domain = domain;
        Ok(())
    }

    // ---------------------------------------------------------------- mailbox
    /// `sf_albion_submit` with the session domain.
    pub fn submit(&mut self, work: &Work) -> Result<Ticket> {
        let d = self.domain;
        self.submit_as(work, d)
    }

    /// Submit on behalf of an explicit domain (admin operations use HOST_ADMIN = 1).
    pub fn submit_as(&mut self, work: &Work, domain: u8) -> Result<Ticket> {
        // flow control: never exceed the queue depth (no drops by construction)
        while self.outstanding.len() as u32 >= self.info.cmdq_depth.max(1) {
            self.drain()?;
            if self.outstanding.len() as u32 >= self.info.cmdq_depth.max(1) {
                self.t.wait_irq(POLL_CHUNK_CYCLES)?;
            }
        }
        let tag = self.alloc_tag();
        let cmd = work.to_command(domain, tag);
        self.submit_raw(&cmd)?;
        self.outstanding.insert(tag, cmd.opcode);
        Ok(Ticket(tag))
    }

    /// Write an already-encoded command (no flow control; protocol tests).
    pub fn submit_raw(&mut self, cmd: &Command) -> Result<()> {
        let w = cmd.encode();
        for (i, v) in w.iter().enumerate() {
            self.mmio_w(regs::MGMT_BASE + regs::MGMT_HCMD_W0 + 4 * i as u32, *v)?;
        }
        self.mmio_w(regs::MGMT_BASE + regs::MGMT_HCMD_SUBMIT, 1)
    }

    fn alloc_tag(&mut self) -> u16 {
        loop {
            let t = self.next_tag;
            self.next_tag = self.next_tag.wrapping_add(1).max(1);
            if !self.outstanding.contains_key(&t) && !self.done.contains_key(&t) {
                return t;
            }
        }
    }

    /// Pull every completion currently queued into the local table.
    fn drain(&mut self) -> Result<usize> {
        let mut n = 0;
        loop {
            let st = self.mgmt(regs::MGMT_HCPLQ_STATUS)?;
            if st & 0xFF == 0 {
                return Ok(n);
            }
            let mut w = [0u32; 4];
            for (i, v) in w.iter_mut().enumerate() {
                *v = self.mgmt(regs::MGMT_HCPL_W0 + 4 * i as u32)?;
            }
            self.mmio_w(regs::MGMT_BASE + regs::MGMT_HCPL_POP, 1)?;
            let c = Completion::decode(&w);
            if self.outstanding.remove(&c.tag).is_none() {
                return Err(Error::Protocol(format!("completion for unknown tag {} ({:?})", c.tag, c)));
            }
            self.done.insert(c.tag, c);
            n += 1;
        }
    }

    /// `sf_albion_poll`: non-blocking.
    pub fn poll(&mut self, t: Ticket) -> Result<Option<Completion>> {
        if let Some(c) = self.done.remove(&t.0) {
            return Ok(Some(c));
        }
        if !self.outstanding.contains_key(&t.0) {
            return Err(Error::InvalidArgument(format!("unknown ticket {}", t.0)));
        }
        self.drain()?;
        Ok(self.done.remove(&t.0))
    }

    /// `sf_albion_wait`: block (in device time) until complete or `timeout_cycles` pass.
    pub fn wait(&mut self, t: Ticket, timeout_cycles: u64) -> Result<Completion> {
        let mut waited = 0u64;
        loop {
            if let Some(c) = self.poll(t)? {
                return Ok(c);
            }
            if waited >= timeout_cycles {
                return Err(Error::Timeout(format!("ticket {} after {timeout_cycles} cycles", t.0)));
            }
            let fired = self.t.wait_irq(POLL_CHUNK_CYCLES)?;
            waited += POLL_CHUNK_CYCLES;
            if !fired && self.t.cycles()?.is_none() {
                // untimed backend with nothing pending: the command can never complete
                return Err(Error::Protocol(format!("ticket {} has no completion (untimed backend)", t.0)));
            }
        }
    }

    /// submit + wait convenience.
    pub fn run(&mut self, work: &Work) -> Result<Completion> {
        let t = self.submit(work)?;
        self.wait(t, 50_000_000)
    }

    pub fn run_as(&mut self, work: &Work, domain: u8) -> Result<Completion> {
        let t = self.submit_as(work, domain)?;
        self.wait(t, 50_000_000)
    }

    // ---------------------------------------------------------------- memory
    /// `sf_albion_alloc`.
    pub fn alloc(&mut self, kind: MemKind, size: u32) -> Result<Buffer> {
        if size == 0 {
            return Err(Error::InvalidArgument("zero-size allocation".into()));
        }
        let size = (size + 3) & !3;
        match kind {
            MemKind::DeviceSram => {
                let c = self.run(&Work::Raw { opcode: regs::OP_ALLOC, flags: 0, args: [size, 0, 0, 0, 0, 0, 0] })?;
                if !c.status.is_ok() {
                    return Err(Error::Device(format!("ALLOC {size} -> {}", c.status)));
                }
                let b = Buffer { kind, addr: c.result[0], size: c.result[2], window: c.result[1], domain: self.domain, iova: 0 };
                self.buffers.push(b);
                Ok(b)
            }
            MemKind::Host => {
                let iova = self.next_iova;
                let span = (size + 0xFFF) & !0xFFF;
                self.next_iova = self.next_iova.checked_add(span).ok_or_else(|| Error::Device("host IOVA space exhausted".into()))?;
                // a real driver pins + IOMMU-maps here (VFIO_IOMMU_MAP_DMA); simulation memory is always present
                self.t.host_write(iova, &vec![0u32; (size / 4) as usize])?;
                let c = self.run(&Work::Raw { opcode: regs::OP_MAP_HOST, flags: 0, args: [iova, size, 3, 0, 0, 0, 0] })?;
                if !c.status.is_ok() {
                    return Err(Error::Device(format!("MAP_HOST -> {}", c.status)));
                }
                let b = Buffer { kind, addr: c.result[1], size, window: c.result[0], domain: self.domain, iova };
                self.buffers.push(b);
                Ok(b)
            }
        }
    }

    /// Release a buffer (FREE scrubs SRAM; UNMAP closes the host window).
    pub fn free(&mut self, b: &Buffer) -> Result<Status> {
        let (op, arg) = match b.kind {
            MemKind::DeviceSram => (regs::OP_FREE, b.addr),
            MemKind::Host => (regs::OP_UNMAP_HOST, b.window),
        };
        let c = self.run_as(&Work::Raw { opcode: op, flags: 0, args: [arg, 0, 0, 0, 0, 0, 0] }, b.domain)?;
        if c.status.is_ok() {
            self.buffers.retain(|x| x != b);
        }
        Ok(c.status)
    }

    /// CPU write into a host buffer.
    pub fn host_write(&mut self, b: &Buffer, offset: u32, data: &[u32]) -> Result<()> {
        self.check_host(b, offset, data.len())?;
        self.t.host_write(b.iova + offset, data)
    }

    /// CPU read of a host buffer.
    pub fn host_read(&mut self, b: &Buffer, offset: u32, words: usize) -> Result<Vec<u32>> {
        self.check_host(b, offset, words)?;
        self.t.host_read(b.iova + offset, words)
    }

    fn check_host(&self, b: &Buffer, offset: u32, words: usize) -> Result<()> {
        if b.kind != MemKind::Host || offset % 4 != 0 || offset as u64 + 4 * words as u64 > b.size as u64 {
            return Err(Error::InvalidArgument("host buffer access out of range".into()));
        }
        Ok(())
    }

    // ---------------------------------------------------------------- telemetry
    /// `sf_albion_counters`.
    pub fn counters(&mut self) -> Result<Counters> {
        let mut values = Vec::with_capacity(regs::NUM_TCOUNTERS);
        for i in 0..regs::NUM_TCOUNTERS as u32 {
            let lo = self.reg(regs::TELEM_BASE + regs::TELEM_CNT_LO + 8 * i)?;
            let hi = self.reg(regs::TELEM_BASE + regs::TELEM_CNT_HI + 8 * i)?;
            values.push(((hi as u64) << 32) | lo as u64);
        }
        Ok(Counters { values })
    }

    /// Host-readable register (MGMT / TELEM / RAS pages).
    pub fn reg(&mut self, addr: u32) -> Result<u32> {
        let (d, e) = self.t.mmio_read(addr)?;
        if e != 0 {
            return Err(Error::Device(format!("read 0x{addr:08x} -> fabric error {e}")));
        }
        Ok(d)
    }

    /// Raw MMIO for negative tests: returns (data, fabric code) / fabric code.
    pub fn raw_read(&mut self, addr: u32) -> Result<(u32, u32)> {
        self.t.mmio_read(addr)
    }
    pub fn raw_write(&mut self, addr: u32, v: u32) -> Result<u32> {
        self.t.mmio_write(addr, v)
    }

    /// Device time in cycles (None for the untimed reference backend).
    pub fn cycles(&mut self) -> Result<Option<u64>> {
        self.t.cycles()
    }

    pub fn transport(&mut self) -> &mut dyn Transport {
        self.t.as_mut()
    }

    /// Host-initiated soft reset (SOFT_RESET register) followed by a full re-open.
    pub fn soft_reset_and_reboot(&mut self, image: &[u8]) -> Result<()> {
        self.t.mmio_write(regs::MGMT_BASE + regs::MGMT_SOFT_RESET, regs::SOFT_RESET_MAGIC)?;
        self.t.advance(64)?;
        self.outstanding.clear();
        self.done.clear();
        self.buffers.clear();
        let mut tries = 0;
        while self.mgmt(regs::MGMT_DEV_STATUS)? & 1 == 0 {
            tries += 1;
            if tries > 200 {
                return Err(Error::Timeout("scrub after soft reset".into()));
            }
            self.t.advance(POLL_CHUNK_CYCLES)?;
        }
        self.load_firmware(image, false)?;
        self.mmio_w(regs::MGMT_BASE + regs::MGMT_CORE_CTRL, 1)?;
        let mut tries = 0;
        while self.mgmt(regs::MGMT_FW_STATUS)? != 2 {
            tries += 1;
            if tries > 200 {
                return Err(Error::Timeout("firmware READY after soft reset".into()));
            }
            self.t.advance(POLL_CHUNK_CYCLES)?;
        }
        self.mmio_w(regs::MGMT_BASE + regs::MGMT_HOST_IRQ_ENABLE, 1)?;
        Ok(())
    }

    /// `sf_albion_close`: release every buffer this session still owns, stop the backend.
    pub fn close(mut self) -> Result<()> {
        self.close_inner()
    }

    fn close_inner(&mut self) -> Result<()> {
        if self.closed {
            return Ok(());
        }
        self.closed = true;
        let bufs = self.buffers.clone();
        for b in bufs.iter().rev() {
            let _ = self.free(b);
        }
        self.t.shutdown()
    }
}

impl Drop for Device {
    fn drop(&mut self) {
        if !self.closed {
            self.closed = true;
            let _ = self.t.shutdown();
        }
    }
}
