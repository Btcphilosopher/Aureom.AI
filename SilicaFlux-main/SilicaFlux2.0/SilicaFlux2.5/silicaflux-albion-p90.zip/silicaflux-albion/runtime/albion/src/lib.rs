//! # SilicaFlux Albion host runtime (Project 90)
//!
//! Public API (mirrored by the C ABI in `include/sf_albion.h`):
//!
//! | Brief            | Rust                     | C                      |
//! |------------------|--------------------------|------------------------|
//! | sf_albion_open   | [`Device::open`]         | `sf_albion_open`       |
//! | sf_albion_info   | [`Device::info`]         | `sf_albion_info`       |
//! | sf_albion_alloc  | [`Device::alloc`]        | `sf_albion_alloc`      |
//! | sf_albion_submit | [`Device::submit`]       | `sf_albion_submit`     |
//! | sf_albion_poll   | [`Device::poll`]         | `sf_albion_poll`       |
//! | sf_albion_wait   | [`Device::wait`]         | `sf_albion_wait`       |
//! | sf_albion_counters | [`Device::counters`]   | `sf_albion_counters`   |
//! | sf_albion_close  | [`Device::close`]        | `sf_albion_close`      |
//!
//! Backends: [`Backend::Reference`] (executable functional model, untimed) and
//! [`Backend::RtlSim`] (Verilator full-chip simulation). No PCIe hardware is
//! required; the VFIO path is discovery-only until an endpoint exists ([`vfio`]).
pub mod device;
pub mod error;
pub mod ffi;
pub mod proto;
pub mod refmodel;
pub mod regs;
pub mod rtlsim;
pub mod transport;
pub mod vfio;

pub use device::{Backend, Buffer, Counters, Device, DeviceInfo, MemKind, OpenOptions, Ticket};
pub use error::{Error, Result};
pub use proto::{Command, Completion, Status, Work};
pub use transport::Transport;

use std::path::PathBuf;

/// Repository root (compile-time location of this crate, two levels up).
pub fn repo_root() -> PathBuf {
    let here = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    here.parent().and_then(|p| p.parent()).map(PathBuf::from).unwrap_or(here)
}
