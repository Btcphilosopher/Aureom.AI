//! Mailbox protocol: commands, completions, status codes and typed work items.
use crate::regs;

/// Completion status reported by the firmware (or the reference model).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Status(pub u8);

impl Status {
    pub const OK: Status = Status(regs::ST_OK);
    pub const BAD_OPCODE: Status = Status(regs::ST_BAD_OPCODE);
    pub const BAD_PARAM: Status = Status(regs::ST_BAD_PARAM);
    pub const NO_RESOURCE: Status = Status(regs::ST_NO_RESOURCE);
    pub const DENIED: Status = Status(regs::ST_DENIED);
    pub const HW_PERM: Status = Status(regs::ST_HW_PERM);
    pub const HW_DECERR: Status = Status(regs::ST_HW_DECERR);
    pub const ECC_UE: Status = Status(regs::ST_ECC_UE);
    pub const UNSUPPORTED: Status = Status(regs::ST_UNSUPPORTED);
    pub const TIMEOUT: Status = Status(regs::ST_TIMEOUT);
    pub const HW_SLVERR: Status = Status(regs::ST_HW_SLVERR);
    pub const HOST_FAULT: Status = Status(regs::ST_HOST_FAULT);

    pub fn name(self) -> &'static str {
        regs::STATUS_NAMES
            .iter()
            .find(|(v, _)| *v == self.0)
            .map(|(_, n)| *n)
            .unwrap_or("UNKNOWN")
    }
    pub fn is_ok(self) -> bool {
        self == Status::OK
    }
}

impl std::fmt::Display for Status {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}(0x{:02x})", self.name(), self.0)
    }
}

/// A raw 8-word mailbox command.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Command {
    pub opcode: u8,
    pub domain: u8,
    pub flags: u8,
    pub tag: u16,
    pub args: [u32; 7],
}

impl Command {
    pub fn encode(&self) -> [u32; 8] {
        let mut w = [0u32; 8];
        w[0] = self.opcode as u32
            | ((self.domain as u32 & 0xF) << 8)
            | ((self.flags as u32 & 0xF) << 12)
            | ((self.tag as u32) << 16);
        w[1..].copy_from_slice(&self.args);
        w
    }
    pub fn decode(w: &[u32; 8]) -> Command {
        let mut args = [0u32; 7];
        args.copy_from_slice(&w[1..]);
        Command {
            opcode: (w[0] & 0xFF) as u8,
            domain: ((w[0] >> 8) & 0xF) as u8,
            flags: ((w[0] >> 12) & 0xF) as u8,
            tag: (w[0] >> 16) as u16,
            args,
        }
    }
}

/// A completion record.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Completion {
    pub tag: u16,
    pub opcode: u8,
    pub status: Status,
    pub result: [u32; 3],
}

impl Completion {
    pub fn encode(&self) -> [u32; 4] {
        [
            self.opcode as u32 | ((self.status.0 as u32) << 8) | ((self.tag as u32) << 16),
            self.result[0],
            self.result[1],
            self.result[2],
        ]
    }
    pub fn decode(w: &[u32; 4]) -> Completion {
        Completion {
            opcode: (w[0] & 0xFF) as u8,
            status: Status(((w[0] >> 8) & 0xFF) as u8),
            tag: (w[0] >> 16) as u16,
            result: [w[1], w[2], w[3]],
        }
    }
}

/// Typed work items accepted by [`crate::Device::submit`].
/// Addresses are DataFabric addresses (SRAM offsets or `HOSTMEM_BASE + iova`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Work {
    Ping,
    /// Workload A/B: validated DMA copy (host->SRAM, SRAM->SRAM, SRAM->host, host->host).
    DmaCopy { src: u32, dst: u32, len: u32 },
    DmaFill { dst: u32, len: u32, pattern: u32 },
    /// Firmware-executed CRC-32 over SRAM owned by the session domain.
    Crc32 { addr: u32, len: u32 },
    /// Workload F (admin): arm a 1- or 2-bit codeword flip on the next write to bank/word.
    RasInject { bank: u32, word: u32, mask_lo: u32, mask_hi: u32 },
    RasStatus,
    RasClear,
    /// Debug strap only: DMA without firmware validation (hardware enforcement test).
    RawDma { src: u32, dst: u32, len: u32 },
    /// Workload C (requires PacketForge).
    PacketClassify,
    /// Workload D (requires VirtualFoundry).
    VirtioBlk,
    /// Workload E (requires ComputeWorks).
    MatmulInt8,
    TelemClear,
    SelfTest,
    /// Any opcode with explicit arguments (protocol testing).
    Raw { opcode: u8, flags: u8, args: [u32; 7] },
}

impl Work {
    pub fn opcode(&self) -> u8 {
        match self {
            Work::Ping => regs::OP_PING,
            Work::DmaCopy { .. } => regs::OP_DMA_COPY,
            Work::DmaFill { .. } => regs::OP_DMA_FILL,
            Work::Crc32 { .. } => regs::OP_CRC32,
            Work::RasInject { .. } => regs::OP_RAS_INJECT,
            Work::RasStatus => regs::OP_RAS_STATUS,
            Work::RasClear => regs::OP_RAS_CLEAR,
            Work::RawDma { .. } => regs::OP_RAW_DMA,
            Work::PacketClassify => regs::OP_PKT_CLASSIFY,
            Work::VirtioBlk => regs::OP_VBLK_IO,
            Work::MatmulInt8 => regs::OP_MATMUL_INT8,
            Work::TelemClear => regs::OP_TELEM_CLEAR,
            Work::SelfTest => regs::OP_SELFTEST,
            Work::Raw { opcode, .. } => *opcode,
        }
    }

    pub fn to_command(&self, domain: u8, tag: u16) -> Command {
        let mut args = [0u32; 7];
        let mut flags = 0u8;
        match *self {
            Work::DmaCopy { src, dst, len } | Work::RawDma { src, dst, len } => {
                args[0] = src;
                args[1] = dst;
                args[2] = len;
            }
            Work::DmaFill { dst, len, pattern } => {
                args[0] = dst;
                args[1] = len;
                args[2] = pattern;
            }
            Work::Crc32 { addr, len } => {
                args[0] = addr;
                args[1] = len;
            }
            Work::RasInject { bank, word, mask_lo, mask_hi } => {
                args[0] = bank;
                args[1] = word;
                args[2] = mask_lo;
                args[3] = mask_hi;
            }
            Work::Raw { flags: f, args: a, .. } => {
                args = a;
                flags = f;
            }
            _ => {}
        }
        Command { opcode: self.opcode(), domain, flags, tag, args }
    }
}
