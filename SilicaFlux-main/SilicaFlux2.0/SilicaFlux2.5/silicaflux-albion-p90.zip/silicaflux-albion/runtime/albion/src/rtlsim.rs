//! RTL simulation backend: drives the Verilator full-chip harness
//! (sim/albion/albion_sim.cpp) over its line protocol. No PCIe hardware needed.
use crate::error::{Error, Result};
use crate::transport::Transport;
use std::io::{BufRead, BufReader, Write};
use std::path::{Path, PathBuf};
use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};

pub struct RtlSim {
    child: Child,
    stdin: ChildStdin,
    stdout: BufReader<ChildStdout>,
    label: String,
    closed: bool,
}

impl RtlSim {
    pub fn spawn(binary: &Path, label: &str, extra_args: &[String]) -> Result<RtlSim> {
        if !binary.exists() {
            return Err(Error::Unavailable(format!(
                "RTL simulator not found at {} (run `make albion-sim`)",
                binary.display()
            )));
        }
        let mut child = Command::new(binary)
            .args(extra_args)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::inherit())
            .spawn()?;
        let stdin = child.stdin.take().ok_or_else(|| Error::Io("no stdin".into()))?;
        let stdout = BufReader::new(child.stdout.take().ok_or_else(|| Error::Io("no stdout".into()))?);
        Ok(RtlSim { child, stdin, stdout, label: label.to_string(), closed: false })
    }

    /// Locate a simulator binary: $SF_ALBION_SIM_DIR/cfg<N>/albion_sim, else build/sim/cfg<N>.
    pub fn default_binary(config: u32) -> PathBuf {
        let base = std::env::var("SF_ALBION_SIM_DIR")
            .map(PathBuf::from)
            .unwrap_or_else(|_| crate::repo_root().join("build/sim"));
        base.join(format!("cfg{config}")).join("albion_sim")
    }

    fn cmd(&mut self, line: &str) -> Result<Vec<u64>> {
        writeln!(self.stdin, "{line}")?;
        self.stdin.flush()?;
        // RTL $display output (e.g. elaboration notices) shares stdout: forward any
        // non-protocol line to stderr and keep reading for the reply.
        let mut reply = String::new();
        loop {
            reply.clear();
            if self.stdout.read_line(&mut reply)? == 0 {
                return Err(Error::Io(format!("simulator exited during `{}`", short(line))));
            }
            if reply.starts_with("OK") || reply.starts_with("ERR") {
                break;
            }
            eprint!("[albion_sim] {reply}");
        }
        let mut it = reply.split_whitespace();
        match it.next() {
            Some("OK") => it
                .map(|t| t.parse::<u64>().map_err(|_| Error::Protocol(format!("bad token {t}"))))
                .collect(),
            Some("ERR") => Err(Error::Protocol(format!("`{}` -> {}", short(line), reply.trim()))),
            _ => Err(Error::Protocol(format!("unexpected reply `{}`", reply.trim()))),
        }
    }

    /// Raw harness statistics line.
    pub fn stats(&mut self) -> Result<String> {
        writeln!(self.stdin, "STATS")?;
        self.stdin.flush()?;
        let mut reply = String::new();
        self.stdout.read_line(&mut reply)?;
        Ok(reply.trim().trim_start_matches("OK ").to_string())
    }

    /// Run until the ControlCore takes a trap with `cause` (used by ISS lock-step tests).
    pub fn run_until_trap(&mut self, cause: u32, max: u64) -> Result<(bool, u64)> {
        let r = self.cmd(&format!("RUNTRAP {cause} {max}"))?;
        Ok((r.first().copied() == Some(1), r.get(1).copied().unwrap_or(0)))
    }
}

fn short(s: &str) -> String {
    s.chars().take(48).collect()
}

impl Transport for RtlSim {
    fn name(&self) -> String {
        format!("rtl-sim:{}", self.label)
    }
    fn mmio_read(&mut self, addr: u32) -> Result<(u32, u32)> {
        let r = self.cmd(&format!("R {addr}"))?;
        if r.len() != 2 {
            return Err(Error::Protocol("R reply".into()));
        }
        Ok((r[0] as u32, r[1] as u32))
    }
    fn mmio_write(&mut self, addr: u32, data: u32) -> Result<u32> {
        let r = self.cmd(&format!("W {addr} {data}"))?;
        Ok(r.first().copied().unwrap_or(0) as u32)
    }
    fn mmio_write_burst(&mut self, addr: u32, data: &[u32]) -> Result<u32> {
        let mut nerr = 0u32;
        for (ci, chunk) in data.chunks(512).enumerate() {
            let mut line = format!("WB {} {}", addr + (ci * 512 * 4) as u32, chunk.len());
            for d in chunk {
                line.push(' ');
                line.push_str(&d.to_string());
            }
            nerr += self.cmd(&line)?.first().copied().unwrap_or(0) as u32;
        }
        Ok(nerr)
    }
    fn host_write(&mut self, iova: u32, data: &[u32]) -> Result<()> {
        for (ci, chunk) in data.chunks(1024).enumerate() {
            let mut line = format!("HW {} {}", iova + (ci * 1024 * 4) as u32, chunk.len());
            for d in chunk {
                line.push(' ');
                line.push_str(&d.to_string());
            }
            self.cmd(&line)?;
        }
        Ok(())
    }
    fn host_read(&mut self, iova: u32, n: usize) -> Result<Vec<u32>> {
        let mut out = Vec::with_capacity(n);
        let mut off = 0usize;
        while off < n {
            let k = (n - off).min(1024);
            let r = self.cmd(&format!("HR {} {}", iova + (off * 4) as u32, k))?;
            out.extend(r.into_iter().map(|v| v as u32));
            off += k;
        }
        Ok(out)
    }
    fn advance(&mut self, cycles: u64) -> Result<()> {
        self.cmd(&format!("STEP {cycles}"))?;
        Ok(())
    }
    fn wait_irq(&mut self, max_cycles: u64) -> Result<bool> {
        let r = self.cmd(&format!("WAITIRQ {max_cycles}"))?;
        Ok(r.first().copied() == Some(1))
    }
    fn cycles(&mut self) -> Result<Option<u64>> {
        Ok(self.cmd("CYC")?.first().copied())
    }
    fn reset(&mut self) -> Result<()> {
        self.cmd("RESET")?;
        Ok(())
    }
    fn set_debug_strap(&mut self, on: bool) -> Result<()> {
        self.cmd(&format!("STRAP {}", on as u32))?;
        Ok(())
    }
    fn set_host_latency(&mut self, cycles: u32) -> Result<()> {
        self.cmd(&format!("HMLAT {cycles}"))?;
        Ok(())
    }
    fn add_host_fault(&mut self, iova: u32, bytes: u32) -> Result<()> {
        self.cmd(&format!("HMFAULT {iova} {bytes}"))?;
        Ok(())
    }
    fn set_trace(&mut self, path: Option<&str>) -> Result<()> {
        self.cmd(&format!("TRACE {}", path.unwrap_or("off")))?;
        Ok(())
    }
    fn shutdown(&mut self) -> Result<()> {
        if !self.closed {
            self.closed = true;
            let _ = writeln!(self.stdin, "QUIT");
            let _ = self.stdin.flush();
            let mut s = String::new();
            let _ = self.stdout.read_line(&mut s);
            let _ = self.child.wait();
        }
        Ok(())
    }
}

impl Drop for RtlSim {
    fn drop(&mut self) {
        let _ = self.shutdown();
        let _ = self.child.kill();
    }
}
