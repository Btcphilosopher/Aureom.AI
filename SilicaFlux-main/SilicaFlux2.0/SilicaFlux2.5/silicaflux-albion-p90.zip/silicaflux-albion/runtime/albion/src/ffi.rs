//! C ABI (see include/sf_albion.h). Every function returns 0 on success or a
//! negative SF_ALBION_E* code; `sf_albion_last_error` returns the message.
#![allow(clippy::missing_safety_doc)]
use crate::device::{Backend, Device, MemKind, OpenOptions, Ticket};
use crate::error::Error;
use crate::proto::Work;
use std::cell::RefCell;
use std::ffi::{c_char, CStr, CString};
use std::path::PathBuf;

pub const SF_ALBION_OK: i32 = 0;
pub const SF_ALBION_EIO: i32 = -1;
pub const SF_ALBION_EPROTO: i32 = -2;
pub const SF_ALBION_ETIMEDOUT: i32 = -3;
pub const SF_ALBION_EINVAL: i32 = -4;
pub const SF_ALBION_EDEVICE: i32 = -5;
pub const SF_ALBION_EUNAVAIL: i32 = -6;

thread_local! {
    static LAST: RefCell<CString> = RefCell::new(CString::new("").unwrap());
}

fn fail(e: Error) -> i32 {
    let code = match &e {
        Error::Io(_) => SF_ALBION_EIO,
        Error::Protocol(_) => SF_ALBION_EPROTO,
        Error::Timeout(_) => SF_ALBION_ETIMEDOUT,
        Error::InvalidArgument(_) => SF_ALBION_EINVAL,
        Error::Device(_) => SF_ALBION_EDEVICE,
        Error::Unavailable(_) => SF_ALBION_EUNAVAIL,
    };
    LAST.with(|l| *l.borrow_mut() = CString::new(e.to_string().replace('\0', " ")).unwrap());
    code
}

#[repr(C)]
pub struct SfAlbionOpenOpts {
    pub backend: u32, // 0 reference, 1 rtl-sim
    pub config: u32,
    pub domain: u32,
    pub debug_strap: u32,
    pub host_latency: u32,
    pub sim_path: *const c_char,
    pub firmware_path: *const c_char,
}

#[repr(C)]
pub struct SfAlbionInfo {
    pub chip_id: u32,
    pub rtl_version: u32,
    pub config_id: u32,
    pub feat_impl: u32,
    pub feat_req: u32,
    pub feat_unavail: u32,
    pub sram_banks: u32,
    pub sram_bank_bytes: u32,
    pub windows: u32,
    pub cmdq_depth: u32,
    pub fw_version: u32,
}

#[repr(C)]
pub struct SfAlbionBuffer {
    pub kind: u32, // 0 device SRAM, 1 host
    pub addr: u32,
    pub size: u32,
    pub window: u32,
    pub iova: u32,
}

#[repr(C)]
pub struct SfAlbionWork {
    pub opcode: u32,
    pub args: [u32; 7],
}

#[repr(C)]
pub struct SfAlbionCompletion {
    pub tag: u32,
    pub opcode: u32,
    pub status: u32,
    pub result: [u32; 3],
}

pub struct SfAlbionDev(Device);

unsafe fn opt_path(p: *const c_char) -> Option<PathBuf> {
    if p.is_null() {
        None
    } else {
        Some(PathBuf::from(CStr::from_ptr(p).to_string_lossy().to_string()))
    }
}

#[no_mangle]
pub unsafe extern "C" fn sf_albion_open(opts: *const SfAlbionOpenOpts, out: *mut *mut SfAlbionDev) -> i32 {
    if opts.is_null() || out.is_null() {
        return fail(Error::InvalidArgument("null pointer".into()));
    }
    let o = &*opts;
    let backend = match o.backend {
        0 => Backend::Reference,
        1 => Backend::RtlSim { binary: opt_path(o.sim_path) },
        b => return fail(Error::InvalidArgument(format!("backend {b}"))),
    };
    let oo = OpenOptions {
        backend,
        config: o.config,
        firmware: opt_path(o.firmware_path),
        domain: o.domain as u8,
        debug_strap: o.debug_strap != 0,
        host_latency: o.host_latency.max(1),
        verify_firmware: true,
    };
    match Device::open(&oo) {
        Ok(d) => {
            *out = Box::into_raw(Box::new(SfAlbionDev(d)));
            SF_ALBION_OK
        }
        Err(e) => fail(e),
    }
}

#[no_mangle]
pub unsafe extern "C" fn sf_albion_info(dev: *mut SfAlbionDev, out: *mut SfAlbionInfo) -> i32 {
    if dev.is_null() || out.is_null() {
        return fail(Error::InvalidArgument("null pointer".into()));
    }
    let i = (*dev).0.info();
    *out = SfAlbionInfo {
        chip_id: i.chip_id,
        rtl_version: i.rtl_version,
        config_id: i.config_id,
        feat_impl: i.feat_impl,
        feat_req: i.feat_req,
        feat_unavail: i.feat_unavail,
        sram_banks: i.sram_banks,
        sram_bank_bytes: i.sram_bank_bytes,
        windows: i.windows,
        cmdq_depth: i.cmdq_depth,
        fw_version: i.fw_version,
    };
    SF_ALBION_OK
}

#[no_mangle]
pub unsafe extern "C" fn sf_albion_alloc(dev: *mut SfAlbionDev, kind: u32, size: u32, out: *mut SfAlbionBuffer) -> i32 {
    if dev.is_null() || out.is_null() {
        return fail(Error::InvalidArgument("null pointer".into()));
    }
    let k = if kind == 0 { MemKind::DeviceSram } else { MemKind::Host };
    match (*dev).0.alloc(k, size) {
        Ok(b) => {
            *out = SfAlbionBuffer { kind, addr: b.addr, size: b.size, window: b.window, iova: b.iova };
            SF_ALBION_OK
        }
        Err(e) => fail(e),
    }
}

#[no_mangle]
pub unsafe extern "C" fn sf_albion_submit(dev: *mut SfAlbionDev, work: *const SfAlbionWork, ticket: *mut u32) -> i32 {
    if dev.is_null() || work.is_null() || ticket.is_null() {
        return fail(Error::InvalidArgument("null pointer".into()));
    }
    let w = &*work;
    if w.opcode > 0xFF {
        return fail(Error::InvalidArgument("opcode".into()));
    }
    match (*dev).0.submit(&Work::Raw { opcode: w.opcode as u8, flags: 0, args: w.args }) {
        Ok(t) => {
            *ticket = t.0 as u32;
            SF_ALBION_OK
        }
        Err(e) => fail(e),
    }
}

fn fill(out: *mut SfAlbionCompletion, c: &crate::proto::Completion) {
    unsafe {
        *out = SfAlbionCompletion {
            tag: c.tag as u32,
            opcode: c.opcode as u32,
            status: c.status.0 as u32,
            result: c.result,
        };
    }
}

/// Returns 1 when complete (and fills `out`), 0 when still pending, <0 on error.
#[no_mangle]
pub unsafe extern "C" fn sf_albion_poll(dev: *mut SfAlbionDev, ticket: u32, out: *mut SfAlbionCompletion) -> i32 {
    if dev.is_null() || out.is_null() {
        return fail(Error::InvalidArgument("null pointer".into()));
    }
    match (*dev).0.poll(Ticket(ticket as u16)) {
        Ok(Some(c)) => {
            fill(out, &c);
            1
        }
        Ok(None) => 0,
        Err(e) => fail(e),
    }
}

#[no_mangle]
pub unsafe extern "C" fn sf_albion_wait(dev: *mut SfAlbionDev, ticket: u32, timeout_cycles: u64, out: *mut SfAlbionCompletion) -> i32 {
    if dev.is_null() || out.is_null() {
        return fail(Error::InvalidArgument("null pointer".into()));
    }
    match (*dev).0.wait(Ticket(ticket as u16), timeout_cycles) {
        Ok(c) => {
            fill(out, &c);
            SF_ALBION_OK
        }
        Err(e) => fail(e),
    }
}

/// Fills up to `n` counters; returns the number of counters available (>0) or <0.
#[no_mangle]
pub unsafe extern "C" fn sf_albion_counters(dev: *mut SfAlbionDev, values: *mut u64, n: u32) -> i32 {
    if dev.is_null() || (values.is_null() && n > 0) {
        return fail(Error::InvalidArgument("null pointer".into()));
    }
    match (*dev).0.counters() {
        Ok(c) => {
            for (i, v) in c.values.iter().take(n as usize).enumerate() {
                *values.add(i) = *v;
            }
            c.values.len() as i32
        }
        Err(e) => fail(e),
    }
}

#[no_mangle]
pub unsafe extern "C" fn sf_albion_host_write(dev: *mut SfAlbionDev, buf: *const SfAlbionBuffer, offset: u32, data: *const u32, words: u32) -> i32 {
    if dev.is_null() || buf.is_null() || data.is_null() {
        return fail(Error::InvalidArgument("null pointer".into()));
    }
    let b = &*buf;
    let bb = crate::device::Buffer { kind: MemKind::Host, addr: b.addr, size: b.size, window: b.window, domain: (*dev).0.domain(), iova: b.iova };
    let s = std::slice::from_raw_parts(data, words as usize);
    match (*dev).0.host_write(&bb, offset, s) {
        Ok(()) => SF_ALBION_OK,
        Err(e) => fail(e),
    }
}

#[no_mangle]
pub unsafe extern "C" fn sf_albion_host_read(dev: *mut SfAlbionDev, buf: *const SfAlbionBuffer, offset: u32, data: *mut u32, words: u32) -> i32 {
    if dev.is_null() || buf.is_null() || data.is_null() {
        return fail(Error::InvalidArgument("null pointer".into()));
    }
    let b = &*buf;
    let bb = crate::device::Buffer { kind: MemKind::Host, addr: b.addr, size: b.size, window: b.window, domain: (*dev).0.domain(), iova: b.iova };
    match (*dev).0.host_read(&bb, offset, words as usize) {
        Ok(v) => {
            std::ptr::copy_nonoverlapping(v.as_ptr(), data, v.len());
            SF_ALBION_OK
        }
        Err(e) => fail(e),
    }
}

#[no_mangle]
pub unsafe extern "C" fn sf_albion_close(dev: *mut SfAlbionDev) -> i32 {
    if dev.is_null() {
        return fail(Error::InvalidArgument("null pointer".into()));
    }
    let d = Box::from_raw(dev);
    match d.0.close() {
        Ok(()) => SF_ALBION_OK,
        Err(e) => fail(e),
    }
}

#[no_mangle]
pub extern "C" fn sf_albion_last_error() -> *const c_char {
    LAST.with(|l| l.borrow().as_ptr())
}
