//! Reference backend: an executable functional model of the Albion device at the
//! MMIO boundary - DataFabric decode and permission rules, SECDED/RAS semantics,
//! DMA error semantics, mailbox, telemetry - plus the firmware command semantics
//! of firmware/albion/src/main.c.
//!
//! It is untimed. It is the golden model for the end-to-end scoreboards in
//! tests/albion_system: every completion, every byte of SRAM/host memory and the
//! deterministic telemetry counters must match the RTL backend.
//!
//! Deliberately NOT modelled (and therefore never compared): cycle counts, fabric
//! transaction/stall/conflict counters, ControlCore instret/sleep, and ECC/permission
//! events caused by DMA prefetch reads past a failing write beat.
use crate::error::Result;
use crate::regs;
use crate::transport::Transport;
use std::collections::{HashMap, VecDeque};

const FW_VERSION: u32 = 0x0001_0000;
const HOST_MEM_BYTES: u32 = 0x4000_0000;
const KIND_SRAM: u32 = 1;
const KIND_HOST: u32 = 2;
const PERM_R: u32 = 1;
const PERM_W: u32 = 2;

#[derive(Debug, Clone, Copy)]
pub struct RefConfig {
    pub config_id: u32,
    pub banks: u32,
    pub bank_bytes: u32,
    pub windows: u32,
    pub qdepth: u32,
    pub feat_req: u32,
    pub feat_impl: u32,
}

impl RefConfig {
    /// Mirrors spec/albion/regmap.json "configs".
    pub fn for_config(id: u32) -> RefConfig {
        let base = regs::FEAT_CONTROLCORE | regs::FEAT_DATAFABRIC | regs::FEAT_SRAM_ECC | regs::FEAT_DMA
            | regs::FEAT_PERMISSION | regs::FEAT_TELEMETRY | regs::FEAT_RAS | regs::FEAT_HOSTIF | regs::FEAT_IRQ;
        let avail = base;
        let (banks, bank_bytes, windows, qdepth, req) = match id {
            1 => (8, 16384, 16, 8, base | regs::FEAT_PACKETFORGE | regs::FEAT_VIRTUALFOUNDRY),
            2 => (8, 32768, 16, 16, base | regs::FEAT_PACKETFORGE | regs::FEAT_VIRTUALFOUNDRY | regs::FEAT_COMPUTEWORKS),
            _ => (4, 16384, 8, 4, base),
        };
        RefConfig { config_id: id.min(2), banks, bank_bytes, windows, qdepth, feat_req: req, feat_impl: req & avail }
    }
}

#[derive(Debug, Clone, Copy, Default)]
struct HwWin {
    base: u32,
    limit: u32,
    attr: u32, // [0] valid [1] R [2] W [11:8] domain
}

#[derive(Debug, Clone, Copy, Default)]
struct FwWin {
    used: bool,
    domain: u32,
    base: u32,
    limit: u32,
    perms: u32,
    kind: u32,
}

#[derive(Debug, Default, Clone)]
struct Ras {
    valid: bool,
    ovf: bool,
    typ: u32,
    addr: u32,
    syn: u32,
    src: u32,
    ce: u32,
    ue: u32,
    inj_armed: bool,
    inj_done: bool,
    inj_bank: u32,
    inj_addr: u32,
    inj_lo: u32,
    inj_hi: u32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Fe {
    Ok,
    DecErr,
    Perm,
    EccUe,
    SlvErr,
    HostErr,
}

impl Fe {
    fn code(self) -> u32 {
        match self {
            Fe::Ok => regs::FE_OK,
            Fe::DecErr => regs::FE_DECERR,
            Fe::Perm => regs::FE_PERM,
            Fe::EccUe => regs::FE_ECC_UE,
            Fe::SlvErr => regs::FE_SLVERR,
            Fe::HostErr => regs::FE_HOSTERR,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Target {
    Sram { bank: u32, word: u32 },
    Mmio { page: u32, off: u32 },
    Host { iova: u32 },
}

const M_CORE: u32 = regs::M_CORE;
const M_DMARD: u32 = regs::M_DMARD;
const M_DMAWR: u32 = regs::M_DMAWR;
const M_HOST: u32 = regs::M_HOST;

pub struct RefDevice {
    cfg: RefConfig,
    strap: bool,
    core_run: bool,
    boot_lock: bool,
    fw_status: u32,
    fw_version: u32,
    heartbeat: u32,
    scratch: u32,
    host_irq_en: u32,
    hcmd: [u32; 8],
    cmdq: VecDeque<[u32; 8]>,
    cplq: VecDeque<[u32; 4]>,
    cmd_ovf: bool,
    sram: Vec<u32>,
    corrupt: Vec<u8>, // 0 clean, 1 single-bit, 2 double-bit
    corrupt_syn: Vec<u8>,
    hw_win: Vec<HwWin>,
    viol_count: u32,
    viol_addr: u32,
    viol_info: u32,
    ras: Ras,
    telem: [u64; regs::NUM_TCOUNTERS],
    snap_host: u32,
    // firmware state
    bitmap: Vec<bool>,
    fw_win: Vec<FwWin>,
    granules: u32,
    data_base: u32,
    host: HashMap<u32, Vec<u32>>,
    faults: Vec<(u32, u32)>,
}

impl RefDevice {
    pub fn new(cfg: RefConfig) -> RefDevice {
        let mut d = RefDevice {
            cfg,
            strap: false,
            core_run: false,
            boot_lock: false,
            fw_status: 0,
            fw_version: 0,
            heartbeat: 0,
            scratch: 0,
            host_irq_en: 0,
            hcmd: [0; 8],
            cmdq: VecDeque::new(),
            cplq: VecDeque::new(),
            cmd_ovf: false,
            sram: vec![],
            corrupt: vec![],
            corrupt_syn: vec![],
            hw_win: vec![],
            viol_count: 0,
            viol_addr: 0,
            viol_info: 0,
            ras: Ras::default(),
            telem: [0; regs::NUM_TCOUNTERS],
            snap_host: 0,
            bitmap: vec![],
            fw_win: vec![],
            granules: 0,
            data_base: 0,
            host: HashMap::new(),
            faults: vec![],
        };
        d.device_reset();
        d
    }

    /// Hardware reset: everything except host memory (which belongs to the host).
    fn device_reset(&mut self) {
        let words = (self.cfg.banks * self.cfg.bank_bytes / 4) as usize;
        self.core_run = false;
        self.boot_lock = false;
        self.fw_status = 0;
        self.fw_version = 0;
        self.heartbeat = 0;
        self.scratch = 0;
        self.host_irq_en = 0;
        self.hcmd = [0; 8];
        self.cmdq.clear();
        self.cplq.clear();
        self.cmd_ovf = false;
        self.sram = vec![0; words];
        self.corrupt = vec![0; words];
        self.corrupt_syn = vec![0; words];
        self.hw_win = vec![HwWin::default(); self.cfg.windows as usize];
        self.viol_count = 0;
        self.viol_addr = 0;
        self.viol_info = 0;
        self.ras = Ras::default();
        self.telem = [0; regs::NUM_TCOUNTERS];
        self.snap_host = 0;
        self.bitmap.clear();
        self.fw_win.clear();
    }

    fn words_per_bank(&self) -> u32 {
        self.cfg.bank_bytes / 4
    }

    // ---------------------------------------------------------------- fabric
    fn decode(&self, addr: u32) -> Option<Target> {
        let sram_bytes = self.cfg.banks as u64 * self.cfg.bank_bytes as u64;
        if (addr as u64) < sram_bytes {
            Some(Target::Sram { bank: addr / self.cfg.bank_bytes, word: (addr % self.cfg.bank_bytes) >> 2 })
        } else if addr >> 16 == 0x4000 {
            Some(Target::Mmio { page: (addr >> 12) & 0xF, off: addr & 0xFFC })
        } else if addr & 0x8000_0000 != 0 {
            Some(Target::Host { iova: addr & 0x7FFF_FFFF })
        } else {
            None
        }
    }

    fn win_hit(&self, aw: u32, we: bool, dom: u32) -> bool {
        self.hw_win.iter().any(|w| {
            let at = w.attr;
            at & 1 != 0
                && (at >> 8) & 0xF == dom
                && (if we { at & 4 != 0 } else { at & 2 != 0 })
                && aw as u64 >= w.base as u64
                && aw as u64 + 3 <= w.limit as u64
        })
    }

    /// DataFabric decode + permission (sf_albion_datafabric.sv).
    fn fabric(&mut self, master: u32, addr: u32, we: bool, dom: u32) -> std::result::Result<Target, Fe> {
        let Some(t) = self.decode(addr) else {
            self.telem[regs::TC_DECERR] += 1;
            return Err(Fe::DecErr);
        };
        let aw = addr & !3;
        let ok = match master {
            M_CORE => true,
            M_HOST => match t {
                Target::Mmio { page, .. } => {
                    page == regs::PAGE_MGMT_U || (!we && (page == regs::PAGE_TELEM_U || page == regs::PAGE_RAS_U))
                }
                Target::Sram { .. } => self.boot_mode(),
                Target::Host { .. } => false,
            },
            _ => {
                let data_bank = matches!(t, Target::Sram { bank, .. } if bank >= regs::FW_PRIVATE_BANKS);
                let is_host = matches!(t, Target::Host { .. });
                if dom == regs::DOM_FIRMWARE as u32 {
                    data_bank
                } else if dom == regs::DOM_HOST_ADMIN as u32 {
                    false
                } else {
                    (data_bank || is_host) && self.win_hit(aw, we, dom)
                }
            }
        };
        if !ok {
            self.telem[regs::TC_PERM_VIOL] += 1;
            self.viol_count = self.viol_count.saturating_add(1);
            if self.viol_info & 0x8000_0000 == 0 {
                self.viol_addr = addr;
                self.viol_info = 0x8000_0000 | ((we as u32) << 8) | ((master & 3) << 4) | (dom & 0xF);
            }
            return Err(Fe::Perm);
        }
        Ok(t)
    }

    fn boot_mode(&self) -> bool {
        !self.core_run && !self.boot_lock
    }

    fn sram_index(&self, bank: u32, word: u32) -> usize {
        (bank * self.words_per_bank() + word) as usize
    }

    fn ras_event(&mut self, ue: bool, bank: u32, word: u32, master: u32, dom: u32, syn: u8) {
        if ue {
            self.telem[regs::TC_ECC_UE] += 1;
            self.ras.ue = self.ras.ue.saturating_add(1);
        } else {
            self.telem[regs::TC_ECC_CE] += 1;
            self.ras.ce = self.ras.ce.saturating_add(1);
        }
        if self.ras.valid {
            self.ras.ovf = true;
        } else {
            self.ras.valid = true;
            self.ras.typ = if ue { 2 } else { 1 };
            self.ras.addr = bank * self.cfg.bank_bytes + (word << 2);
            self.ras.syn = syn as u32;
            self.ras.src = ((dom & 0xF) << 8) | ((master & 3) << 4) | (bank & 0xF);
        }
    }

    fn sram_read(&mut self, bank: u32, word: u32, master: u32, dom: u32) -> std::result::Result<u32, Fe> {
        let i = self.sram_index(bank, word);
        match self.corrupt[i] {
            0 => Ok(self.sram[i]),
            1 => {
                let syn = self.corrupt_syn[i];
                self.ras_event(false, bank, word, master, dom, syn);
                Ok(self.sram[i])
            }
            _ => {
                let syn = self.corrupt_syn[i];
                self.ras_event(true, bank, word, master, dom, syn);
                Err(Fe::EccUe)
            }
        }
    }

    fn sram_write(&mut self, bank: u32, word: u32, v: u32) {
        let i = self.sram_index(bank, word);
        self.sram[i] = v;
        self.corrupt[i] = 0;
        if self.ras.inj_armed && self.ras.inj_bank == bank && (self.ras.inj_addr & (self.words_per_bank() - 1)) == word {
            let n = self.ras.inj_lo.count_ones() + (self.ras.inj_hi & 0x7F).count_ones();
            if n > 0 {
                self.corrupt[i] = if n == 1 { 1 } else { 2 };
                self.corrupt_syn[i] = secded_syndrome(self.ras.inj_lo, self.ras.inj_hi & 0x7F);
            }
            self.ras.inj_armed = false;
            self.ras.inj_done = true;
        }
    }

    fn host_fault(&self, iova: u32) -> bool {
        iova >= HOST_MEM_BYTES || self.faults.iter().any(|&(b, s)| iova >= b && iova - b < s)
    }

    fn hmem_read(&self, iova: u32) -> u32 {
        self.host.get(&(iova >> 12)).map(|p| p[((iova & 0xFFF) >> 2) as usize]).unwrap_or(0)
    }

    fn hmem_write(&mut self, iova: u32, v: u32) {
        let p = self.host.entry(iova >> 12).or_insert_with(|| vec![0; 1024]);
        p[((iova & 0xFFF) >> 2) as usize] = v;
    }

    /// One DMA beat read (master DMARD) or write (DMAWR).
    fn dma_beat(&mut self, we: bool, addr: u32, dom: u32, data: u32) -> std::result::Result<u32, Fe> {
        let master = if we { M_DMAWR } else { M_DMARD };
        let t = self.fabric(master, addr, we, dom)?;
        match t {
            Target::Sram { bank, word } => {
                if we {
                    self.sram_write(bank, word, data);
                    Ok(0)
                } else {
                    self.sram_read(bank, word, master, dom)
                }
            }
            Target::Host { iova } => {
                if self.host_fault(iova & !3) {
                    return Err(Fe::HostErr);
                }
                if we {
                    self.hmem_write(iova & !3, data);
                    Ok(0)
                } else {
                    Ok(self.hmem_read(iova & !3))
                }
            }
            Target::Mmio { .. } => Err(Fe::SlvErr), // unreachable: fabric denies DMA to MMIO
        }
    }

    /// sf_albion_dma.sv semantics. Returns (dma error code, bytes_done, err_addr).
    fn run_dma_hw(&mut self, dom: u32, src: u32, dst: u32, len: u32, fill: bool, pattern: u32) -> (u32, u32, u32) {
        let src_wrap = src as u64 + len as u64 > 0xFFFF_FFFF;
        let dst_wrap = dst as u64 + len as u64 > 0xFFFF_FFFF;
        let bad = len == 0
            || len & 3 != 0
            || len > regs::DMA_MAX_LEN
            || dst & 3 != 0
            || dst_wrap
            || (!fill && (src & 3 != 0 || src_wrap));
        self.telem[regs::TC_DMA_DESC_DONE] += 1;
        if bad {
            self.telem[regs::TC_DMA_ERRORS] += 1;
            return (regs::DMAE_BADPARAM, 0, 0);
        }
        let n = len / 4;
        for i in 0..n {
            let v = if fill {
                pattern
            } else {
                match self.dma_beat(false, src.wrapping_add(4 * i), dom, 0) {
                    Ok(v) => v,
                    Err(e) => {
                        self.telem[regs::TC_DMA_ERRORS] += 1;
                        return (map_fe(e), 4 * i, src.wrapping_add(4 * i));
                    }
                }
            };
            if let Err(e) = self.dma_beat(true, dst.wrapping_add(4 * i), dom, v) {
                self.telem[regs::TC_DMA_ERRORS] += 1;
                return (map_fe(e), 4 * i, dst.wrapping_add(4 * i));
            }
            self.telem[regs::TC_DMA_BYTES] += 4;
            self.telem[regs::TC_DOM0_BYTES + (dom as usize & 15)] += 4;
        }
        (regs::DMAE_NONE, len, 0)
    }

    // ---------------------------------------------------------------- firmware model
    fn fw_boot(&mut self) {
        self.fw_status = 1;
        self.granules = ((self.cfg.banks - regs::FW_PRIVATE_BANKS) * self.cfg.bank_bytes) >> 8;
        self.granules = self.granules.min(1024);
        self.data_base = regs::FW_PRIVATE_BANKS * self.cfg.bank_bytes;
        self.bitmap = vec![false; self.granules as usize];
        self.fw_win = vec![FwWin::default(); self.cfg.windows.min(16) as usize];
        for w in self.hw_win.iter_mut() {
            *w = HwWin::default();
        }
        self.boot_lock = true;
        self.fw_version = FW_VERSION;
        self.fw_status = 2;
    }

    fn win_program(&mut self, i: usize) {
        let w = self.fw_win[i];
        self.hw_win[i] = if w.used {
            HwWin { base: w.base, limit: w.limit, attr: 1 | (w.perms << 1) | (w.domain << 8) }
        } else {
            HwWin::default()
        };
    }

    fn win_free_slot(&self) -> Option<usize> {
        self.fw_win.iter().position(|w| !w.used)
    }

    fn win_owned(&self, dom: u32, addr: u32, len: u32, perms: u32, kinds: u32) -> bool {
        let last = addr.wrapping_add(len).wrapping_sub(1);
        self.fw_win.iter().any(|w| {
            w.used && w.domain == dom && w.perms & perms == perms && w.kind & kinds != 0 && addr >= w.base && last <= w.limit
        })
    }

    fn fw_run_dma(&mut self, dom: u32, src: u32, dst: u32, len: u32, fill: bool, pattern: u32, res: &mut [u32; 3]) -> u8 {
        let (code, bytes, err_addr) = self.run_dma_hw(dom, src, dst, len, fill, pattern);
        res[0] = bytes;
        res[1] = 0; // cycles: untimed model
        res[2] = err_addr;
        match code {
            regs::DMAE_NONE => regs::ST_OK,
            regs::DMAE_DECERR => regs::ST_HW_DECERR,
            regs::DMAE_PERM => regs::ST_HW_PERM,
            regs::DMAE_ECC_UE => regs::ST_ECC_UE,
            regs::DMAE_BADPARAM => regs::ST_BAD_PARAM,
            regs::DMAE_HOSTERR => regs::ST_HOST_FAULT,
            _ => regs::ST_HW_SLVERR,
        }
    }

    fn scrub(&mut self, base: u32, len: u32) -> u8 {
        let mut r = [0u32; 3];
        self.fw_run_dma(regs::DOM_FIRMWARE as u32, 0, base, len, true, 0, &mut r)
    }

    fn fw_command(&mut self, c: [u32; 8]) -> [u32; 4] {
        let op = (c[0] & 0xFF) as u8;
        let dom = (c[0] >> 8) & 0xF;
        let flags = (c[0] >> 12) & 0xF;
        let tag = c[0] >> 16;
        let a = &c[1..];
        let mut res = [0u32; 3];
        let st = if flags != 0 { regs::ST_BAD_PARAM } else { self.dispatch(op, dom, a, &mut res) };
        [op as u32 | ((st as u32) << 8) | (tag << 16), res[0], res[1], res[2]]
    }

    fn dispatch(&mut self, op: u8, dom: u32, a: &[u32], res: &mut [u32; 3]) -> u8 {
        let tenant = (regs::DOM_TENANT_MIN as u32..=15).contains(&dom);
        let admin = dom == regs::DOM_HOST_ADMIN as u32;
        let check_len = |len: u32| len == 0 || len & 3 != 0 || len > regs::DMA_MAX_LEN;
        let wraps = |addr: u32, len: u32| len.wrapping_sub(1) > 0xFFFF_FFFF - addr;
        match op {
            regs::OP_PING => {
                *res = [FW_VERSION, self.cfg.feat_impl, self.heartbeat];
                regs::ST_OK
            }
            regs::OP_ALLOC => {
                if !tenant {
                    return regs::ST_DENIED;
                }
                let size = a[0];
                if size == 0 || size > (self.granules << 8) {
                    return regs::ST_BAD_PARAM;
                }
                let Some(w) = self.win_free_slot() else { return regs::ST_NO_RESOURCE };
                let need = (size + 255) >> 8;
                let mut run = 0u32;
                let mut start = 0u32;
                for g in 0..self.granules {
                    if self.bitmap[g as usize] {
                        run = 0;
                        continue;
                    }
                    if run == 0 {
                        start = g;
                    }
                    run += 1;
                    if run == need {
                        let base = self.data_base + (start << 8);
                        let bytes = need << 8;
                        let st = self.scrub(base, bytes);
                        if st != regs::ST_OK {
                            return st;
                        }
                        for k in start..start + need {
                            self.bitmap[k as usize] = true;
                        }
                        self.fw_win[w] = FwWin { used: true, domain: dom, base, limit: base + bytes - 1, perms: PERM_R | PERM_W, kind: KIND_SRAM };
                        self.win_program(w);
                        *res = [base, w as u32, bytes];
                        return regs::ST_OK;
                    }
                }
                regs::ST_NO_RESOURCE
            }
            regs::OP_FREE => {
                if !tenant {
                    return regs::ST_DENIED;
                }
                for i in 0..self.fw_win.len() {
                    let w = self.fw_win[i];
                    if w.used && w.kind == KIND_SRAM && w.domain == dom && w.base == a[0] {
                        let bytes = w.limit - w.base + 1;
                        self.fw_win[i].used = false;
                        self.win_program(i);
                        let st = self.scrub(w.base, bytes);
                        let g0 = (w.base - self.data_base) >> 8;
                        for k in g0..g0 + (bytes >> 8) {
                            self.bitmap[k as usize] = false;
                        }
                        return st;
                    }
                }
                regs::ST_DENIED
            }
            regs::OP_MAP_HOST => {
                if !tenant {
                    return regs::ST_DENIED;
                }
                let (iova, size, perms) = (a[0], a[1], a[2]);
                if size == 0 || size & 3 != 0 || iova & 3 != 0 {
                    return regs::ST_BAD_PARAM;
                }
                if iova >= 0x8000_0000 || size > 0x8000_0000 - iova {
                    return regs::ST_BAD_PARAM;
                }
                if perms == 0 || perms > 3 {
                    return regs::ST_BAD_PARAM;
                }
                let Some(w) = self.win_free_slot() else { return regs::ST_NO_RESOURCE };
                let base = regs::HOSTMEM_BASE + iova;
                self.fw_win[w] = FwWin { used: true, domain: dom, base, limit: base + size - 1, perms, kind: KIND_HOST };
                self.win_program(w);
                res[0] = w as u32;
                res[1] = base;
                regs::ST_OK
            }
            regs::OP_UNMAP_HOST => {
                if !tenant {
                    return regs::ST_DENIED;
                }
                let i = a[0] as usize;
                if i >= self.fw_win.len() {
                    return regs::ST_BAD_PARAM;
                }
                let w = self.fw_win[i];
                if !w.used || w.kind != KIND_HOST || w.domain != dom {
                    return regs::ST_DENIED;
                }
                self.fw_win[i].used = false;
                self.win_program(i);
                regs::ST_OK
            }
            regs::OP_DMA_COPY => {
                let (src, dst, len) = (a[0], a[1], a[2]);
                if !tenant {
                    return regs::ST_DENIED;
                }
                if check_len(len) || src & 3 != 0 || dst & 3 != 0 {
                    return regs::ST_BAD_PARAM;
                }
                if wraps(src, len) || wraps(dst, len) {
                    return regs::ST_BAD_PARAM;
                }
                if src <= dst.wrapping_add(len - 1) && dst <= src.wrapping_add(len - 1) {
                    return regs::ST_BAD_PARAM;
                }
                if !self.win_owned(dom, src, len, PERM_R, KIND_SRAM | KIND_HOST) {
                    return regs::ST_DENIED;
                }
                if !self.win_owned(dom, dst, len, PERM_W, KIND_SRAM | KIND_HOST) {
                    return regs::ST_DENIED;
                }
                self.fw_run_dma(dom, src, dst, len, false, 0, res)
            }
            regs::OP_DMA_FILL => {
                let (dst, len, pattern) = (a[0], a[1], a[2]);
                if !tenant {
                    return regs::ST_DENIED;
                }
                if check_len(len) || dst & 3 != 0 || wraps(dst, len) {
                    return regs::ST_BAD_PARAM;
                }
                if !self.win_owned(dom, dst, len, PERM_W, KIND_SRAM | KIND_HOST) {
                    return regs::ST_DENIED;
                }
                self.fw_run_dma(dom, 0, dst, len, true, pattern, res)
            }
            regs::OP_CRC32 => {
                let (addr, len) = (a[0], a[1]);
                if !tenant {
                    return regs::ST_DENIED;
                }
                if check_len(len) || addr & 3 != 0 || wraps(addr, len) {
                    return regs::ST_BAD_PARAM;
                }
                if !self.win_owned(dom, addr, len, PERM_R, KIND_SRAM) {
                    return regs::ST_DENIED;
                }
                let mut crc = 0xFFFF_FFFFu32;
                let mut done = 0u32;
                let mut off = 0u32;
                while off < len {
                    let Some(Target::Sram { bank, word }) = self.decode(addr + off) else { break };
                    match self.sram_read(bank, word, M_CORE, regs::DOM_FIRMWARE as u32) {
                        Ok(w) => {
                            crc = crc32_word(crc, w);
                            done = off + 4;
                        }
                        Err(_) => {
                            *res = [0, done, addr + off];
                            return regs::ST_ECC_UE;
                        }
                    }
                    off += 4;
                }
                *res = [!crc, done, 0];
                regs::ST_OK
            }
            regs::OP_RAS_INJECT => {
                let (bank, word, lo, hi) = (a[0], a[1], a[2], a[3]);
                if !admin {
                    return regs::ST_DENIED;
                }
                if bank >= self.cfg.banks {
                    return regs::ST_BAD_PARAM;
                }
                if bank < regs::FW_PRIVATE_BANKS {
                    return regs::ST_DENIED;
                }
                if word >= self.cfg.bank_bytes >> 2 || hi > 0x7F {
                    return regs::ST_BAD_PARAM;
                }
                let n = lo.count_ones() + hi.count_ones();
                if n != 1 && n != 2 {
                    return regs::ST_BAD_PARAM;
                }
                self.ras.inj_addr = word;
                self.ras.inj_lo = lo;
                self.ras.inj_hi = hi;
                self.ras.inj_armed = true;
                self.ras.inj_bank = bank;
                self.ras.inj_done = false;
                regs::ST_OK
            }
            regs::OP_RAS_STATUS => {
                *res = [self.ras_status_reg(), self.ras.addr, (self.ras.ce.min(0xFFFF) << 16) | self.ras.ue.min(0xFFFF)];
                regs::ST_OK
            }
            regs::OP_RAS_CLEAR => {
                if !admin {
                    return regs::ST_DENIED;
                }
                self.ras.valid = false;
                self.ras.ovf = false;
                regs::ST_OK
            }
            regs::OP_RAW_DMA => {
                if !self.strap {
                    return regs::ST_DENIED;
                }
                self.fw_run_dma(dom & 15, a[0], a[1], a[2], false, 0, res)
            }
            regs::OP_PKT_CLASSIFY => self.unsupported(regs::FEAT_PACKETFORGE),
            regs::OP_VBLK_IO => self.unsupported(regs::FEAT_VIRTUALFOUNDRY),
            regs::OP_MATMUL_INT8 => self.unsupported(regs::FEAT_COMPUTEWORKS),
            regs::OP_TELEM_CLEAR => {
                if !admin {
                    return regs::ST_DENIED;
                }
                self.telem = [0; regs::NUM_TCOUNTERS];
                regs::ST_OK
            }
            regs::OP_SELFTEST => {
                *res = [7, selftest_checksum(), 0];
                regs::ST_OK
            }
            _ => regs::ST_BAD_OPCODE,
        }
    }

    fn unsupported(&self, feat: u32) -> u8 {
        if self.cfg.feat_impl & feat != 0 {
            regs::ST_BAD_OPCODE
        } else {
            regs::ST_UNSUPPORTED
        }
    }

    fn ras_status_reg(&self) -> u32 {
        (self.ras.typ << 4) | ((self.ras.ovf as u32) << 1) | self.ras.valid as u32
    }

    /// Process queued commands in order while completion space exists.
    fn fw_service(&mut self) {
        if !self.core_run || self.fw_status != 2 {
            return;
        }
        while !self.cmdq.is_empty() && (self.cplq.len() as u32) < self.cfg.qdepth {
            let c = self.cmdq.pop_front().unwrap();
            self.heartbeat = self.heartbeat.wrapping_add(1);
            let cpl = self.fw_command(c);
            self.cplq.push_back(cpl);
            self.telem[regs::TC_CPL_POSTED] += 1;
        }
    }

    // ---------------------------------------------------------------- host MMIO
    fn mgmt_read(&self, off: u32) -> std::result::Result<u32, Fe> {
        let q = |len: usize, ovf: bool| -> u32 {
            ((ovf as u32) << 16) | (((len == 0) as u32) << 9) | (((len as u32 == self.cfg.qdepth) as u32) << 8) | len as u32
        };
        let r = match off {
            regs::MGMT_CHIP_ID => regs::CHIP_ID,
            regs::MGMT_VERSION => regs::RTL_VERSION,
            regs::MGMT_CONFIG_ID => self.cfg.config_id,
            regs::MGMT_FEAT_IMPL => self.cfg.feat_impl,
            regs::MGMT_FEAT_REQ => self.cfg.feat_req,
            regs::MGMT_FEAT_UNAVAIL => self.cfg.feat_req & !self.cfg.feat_impl,
            regs::MGMT_SRAM_BANKS => self.cfg.banks,
            regs::MGMT_SRAM_BANK_BYTES => self.cfg.bank_bytes,
            regs::MGMT_NUM_WINDOWS => self.cfg.windows,
            regs::MGMT_CMDQ_DEPTH | regs::MGMT_CPLQ_DEPTH => self.cfg.qdepth,
            regs::MGMT_NUM_DOMAINS => regs::NUM_DOMAINS,
            regs::MGMT_BUILD_ID => 0,
            regs::MGMT_DEV_STATUS => {
                1 | ((self.core_run as u32) << 1)
                    | ((self.boot_lock as u32) << 2)
                    | ((self.strap as u32) << 3)
                    | ((self.boot_mode() as u32) << 4)
            }
            regs::MGMT_CORE_CTRL => self.core_run as u32,
            regs::MGMT_BOOT_LOCK => self.boot_lock as u32,
            regs::MGMT_FW_STATUS => self.fw_status,
            regs::MGMT_FW_VERSION => self.fw_version,
            regs::MGMT_FW_HEARTBEAT => self.heartbeat,
            regs::MGMT_SCRATCH => self.scratch,
            regs::MGMT_HOST_IRQ_STATUS => (!self.cplq.is_empty()) as u32,
            regs::MGMT_HOST_IRQ_ENABLE => self.host_irq_en,
            regs::MGMT_FW_ATTN => 0,
            regs::MGMT_HCMDQ_STATUS | regs::MGMT_FCMDQ_STATUS => q(self.cmdq.len(), self.cmd_ovf && off == regs::MGMT_HCMDQ_STATUS),
            regs::MGMT_HCPLQ_STATUS | regs::MGMT_FCPLQ_STATUS => q(self.cplq.len(), false),
            regs::MGMT_SOFT_RESET | regs::MGMT_HCMD_SUBMIT | regs::MGMT_HCMDQ_CLEAR | regs::MGMT_HCPL_POP
            | regs::MGMT_FCMD_POP | regs::MGMT_FCPL_PUSH => 0,
            o if (regs::MGMT_HCMD_W0..regs::MGMT_HCMD_W0 + 32).contains(&o) => self.hcmd[((o - regs::MGMT_HCMD_W0) / 4) as usize],
            o if (regs::MGMT_HCPL_W0..regs::MGMT_HCPL_W0 + 16).contains(&o) => {
                self.cplq.front().map(|c| c[((o - regs::MGMT_HCPL_W0) / 4) as usize]).unwrap_or(0)
            }
            o if (regs::MGMT_FCMD_W0..regs::MGMT_FCMD_W0 + 32).contains(&o) => {
                self.cmdq.front().map(|c| c[((o - regs::MGMT_FCMD_W0) / 4) as usize]).unwrap_or(0)
            }
            o if (regs::MGMT_FCPL_W0..regs::MGMT_FCPL_W0 + 16).contains(&o) => 0,
            _ => return Err(Fe::DecErr),
        };
        Ok(r)
    }

    fn mgmt_write(&mut self, off: u32, v: u32) -> Fe {
        // validity / writer rules first (sf_albion_mgmt.sv)
        if self.mgmt_read(off).is_err() {
            return Fe::DecErr;
        }
        let host_writable = matches!(
            off,
            regs::MGMT_CORE_CTRL
                | regs::MGMT_SOFT_RESET
                | regs::MGMT_SCRATCH
                | regs::MGMT_HOST_IRQ_ENABLE
                | regs::MGMT_HCMD_SUBMIT
                | regs::MGMT_HCMDQ_CLEAR
                | regs::MGMT_HCPL_POP
        ) || (regs::MGMT_HCMD_W0..regs::MGMT_HCMD_W0 + 32).contains(&off);
        if !host_writable {
            return Fe::SlvErr;
        }
        match off {
            regs::MGMT_CORE_CTRL => {
                if !self.boot_lock {
                    let run = v & 1 != 0;
                    if run && !self.core_run {
                        self.core_run = true;
                        self.fw_boot();
                    } else if !run {
                        self.core_run = false;
                        self.fw_status = 0;
                    }
                }
            }
            regs::MGMT_SOFT_RESET => {
                if v == regs::SOFT_RESET_MAGIC {
                    self.device_reset();
                }
            }
            regs::MGMT_SCRATCH => self.scratch = v,
            regs::MGMT_HOST_IRQ_ENABLE => self.host_irq_en = v,
            regs::MGMT_HCMD_SUBMIT => {
                if self.cmdq.len() as u32 >= self.cfg.qdepth {
                    self.cmd_ovf = true;
                    self.telem[regs::TC_CMDQ_DROPS] += 1;
                } else {
                    self.cmdq.push_back(self.hcmd);
                    self.telem[regs::TC_CMD_SUBMITTED] += 1;
                    self.fw_service();
                }
            }
            regs::MGMT_HCMDQ_CLEAR => {
                if v & 1 != 0 {
                    self.cmd_ovf = false;
                }
            }
            regs::MGMT_HCPL_POP => {
                self.cplq.pop_front();
                self.fw_service();
            }
            o => self.hcmd[((o - regs::MGMT_HCMD_W0) / 4) as usize] = v,
        }
        Fe::Ok
    }

    fn telem_read(&mut self, off: u32) -> std::result::Result<u32, Fe> {
        let nc = regs::NUM_TCOUNTERS as u32;
        if (0x100..0x100 + nc * 8).contains(&off) {
            let i = ((off - 0x100) / 8) as usize;
            if off & 4 == 0 {
                self.snap_host = (self.telem[i] >> 32) as u32;
                return Ok(self.telem[i] as u32);
            }
            return Ok(self.snap_host);
        }
        match off {
            regs::TELEM_CTRL => Ok(0),
            regs::TELEM_NUM_COUNTERS => Ok(nc),
            _ => Err(Fe::DecErr),
        }
    }

    fn ras_read(&self, off: u32) -> std::result::Result<u32, Fe> {
        Ok(match off {
            regs::RAS_ERR_STATUS => self.ras_status_reg(),
            regs::RAS_ERR_ADDR => self.ras.addr,
            regs::RAS_ERR_SYNDROME => self.ras.syn,
            regs::RAS_ERR_SOURCE => self.ras.src,
            regs::RAS_ERR_CLEAR => 0,
            regs::RAS_CE_COUNT => self.ras.ce,
            regs::RAS_UE_COUNT => self.ras.ue,
            regs::RAS_INJ_CTRL => (self.ras.inj_bank << 4) | ((self.ras.inj_done as u32) << 1) | self.ras.inj_armed as u32,
            regs::RAS_INJ_ADDR => self.ras.inj_addr,
            regs::RAS_INJ_MASK_LO => self.ras.inj_lo,
            regs::RAS_INJ_MASK_HI => self.ras.inj_hi,
            regs::RAS_SCRUB_STATUS => 1,
            _ => return Err(Fe::DecErr),
        })
    }

    fn host_access(&mut self, addr: u32, we: bool, v: u32) -> (u32, Fe) {
        let t = match self.fabric(M_HOST, addr, we, regs::DOM_HOST_ADMIN as u32) {
            Ok(t) => t,
            Err(e) => return (0, e),
        };
        match t {
            Target::Sram { bank, word } => {
                if we {
                    self.sram_write(bank, word, v);
                    (0, Fe::Ok)
                } else {
                    match self.sram_read(bank, word, M_HOST, regs::DOM_HOST_ADMIN as u32) {
                        Ok(d) => (d, Fe::Ok),
                        Err(e) => (0, e),
                    }
                }
            }
            Target::Mmio { page, off } => {
                if page > 5 {
                    return (0, Fe::DecErr);
                }
                if page == regs::PAGE_MGMT_U {
                    if we {
                        (0, self.mgmt_write(off, v))
                    } else {
                        match self.mgmt_read(off) {
                            Ok(d) => (d, Fe::Ok),
                            Err(e) => (0, e),
                        }
                    }
                } else if page == regs::PAGE_TELEM_U {
                    match self.telem_read(off) {
                        Ok(d) => (d, Fe::Ok),
                        Err(e) => (0, e),
                    }
                } else {
                    match self.ras_read(off) {
                        Ok(d) => (d, Fe::Ok),
                        Err(e) => (0, e),
                    }
                }
            }
            Target::Host { .. } => (0, Fe::Perm),
        }
    }
}

fn map_fe(e: Fe) -> u32 {
    match e {
        Fe::DecErr => regs::DMAE_DECERR,
        Fe::Perm => regs::DMAE_PERM,
        Fe::EccUe => regs::DMAE_ECC_UE,
        Fe::HostErr => regs::DMAE_HOSTERR,
        _ => regs::DMAE_SLVERR,
    }
}

/// SECDED syndrome {overall parity, hamming syndrome} for a codeword flip mask
/// (sf_albion_secded.sv layout: cw[i-1] = Hamming position i, cw[38] = parity).
pub fn secded_syndrome(lo: u32, hi: u32) -> u8 {
    let mask: u64 = lo as u64 | ((hi as u64 & 0x7F) << 32);
    let mut s = 0u32;
    for bit in 0..38u32 {
        if mask >> bit & 1 == 1 {
            s ^= bit + 1;
        }
    }
    let p = (mask.count_ones() & 1) as u8;
    (p << 6) | (s as u8 & 0x3F)
}

pub fn crc32_word(mut crc: u32, w: u32) -> u32 {
    for b in w.to_le_bytes() {
        crc ^= b as u32;
        for _ in 0..8 {
            crc = if crc & 1 != 0 { (crc >> 1) ^ 0xEDB8_8320 } else { crc >> 1 };
        }
    }
    crc
}

/// CRC-32 (IEEE) over little-endian words, as computed by the firmware.
pub fn crc32_words(words: &[u32]) -> u32 {
    !words.iter().fold(0xFFFF_FFFF, |c, &w| crc32_word(c, w))
}

fn selftest_checksum() -> u32 {
    let x = 0x1357_9BDFu32;
    let buf: Vec<u32> = (0..64u32).map(|i| x ^ i.wrapping_mul(0x0101_0101)).collect();
    crc32_words(&buf)
}

/// Transport wrapper around [`RefDevice`].
pub struct RefTransport {
    dev: RefDevice,
    cfg: RefConfig,
}

impl RefTransport {
    pub fn new(config: u32) -> RefTransport {
        let cfg = RefConfig::for_config(config);
        RefTransport { dev: RefDevice::new(cfg), cfg }
    }
}

impl Transport for RefTransport {
    fn name(&self) -> String {
        format!("reference:{}", regs::CONFIG_NAMES[self.cfg.config_id as usize])
    }
    fn mmio_read(&mut self, addr: u32) -> Result<(u32, u32)> {
        let (d, e) = self.dev.host_access(addr, false, 0);
        Ok((d, e.code()))
    }
    fn mmio_write(&mut self, addr: u32, data: u32) -> Result<u32> {
        let (_, e) = self.dev.host_access(addr, true, data);
        Ok(e.code())
    }
    fn host_write(&mut self, iova: u32, data: &[u32]) -> Result<()> {
        for (i, d) in data.iter().enumerate() {
            self.dev.hmem_write(iova + 4 * i as u32, *d);
        }
        Ok(())
    }
    fn host_read(&mut self, iova: u32, n: usize) -> Result<Vec<u32>> {
        Ok((0..n).map(|i| self.dev.hmem_read(iova + 4 * i as u32)).collect())
    }
    fn advance(&mut self, _cycles: u64) -> Result<()> {
        Ok(())
    }
    fn wait_irq(&mut self, _max: u64) -> Result<bool> {
        Ok(!self.dev.cplq.is_empty() && self.dev.host_irq_en & 1 != 0)
    }
    fn cycles(&mut self) -> Result<Option<u64>> {
        Ok(None)
    }
    fn reset(&mut self) -> Result<()> {
        self.dev.device_reset();
        Ok(())
    }
    fn set_debug_strap(&mut self, on: bool) -> Result<()> {
        self.dev.strap = on;
        Ok(())
    }
    fn set_host_latency(&mut self, _cycles: u32) -> Result<()> {
        Ok(())
    }
    fn add_host_fault(&mut self, iova: u32, bytes: u32) -> Result<()> {
        self.dev.faults.push((iova, bytes));
        Ok(())
    }
    fn shutdown(&mut self) -> Result<()> {
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn crc_check_value() {
        let mut c = 0xFFFF_FFFFu32;
        for b in b"123456789" {
            c ^= *b as u32;
            for _ in 0..8 {
                c = if c & 1 != 0 { (c >> 1) ^ 0xEDB8_8320 } else { c >> 1 };
            }
        }
        assert_eq!(!c, 0xCBF4_3926);
    }
    #[test]
    fn syndrome_single_and_double() {
        assert_eq!(secded_syndrome(1, 0), 0x40 | 1); // bit0 = position 1
        assert_eq!(secded_syndrome(0, 0x40), 0x40); // overall parity bit only
        assert_eq!(secded_syndrome(0b11, 0) & 0x40, 0); // double: parity clean
    }
}
