/*
 * SilicaFlux Albion (Project 90) host runtime - C ABI.
 * Link with libsf_albion.a (plus -lpthread -ldl -lm) or libsf_albion.so.
 * All functions return SF_ALBION_OK (0) or a negative SF_ALBION_E* code;
 * sf_albion_last_error() returns a thread-local description of the last failure.
 * Register/opcode constants: firmware/albion/include/albion_regs.h (generated).
 */
#ifndef SF_ALBION_H
#define SF_ALBION_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SF_ALBION_OK         0
#define SF_ALBION_EIO       -1
#define SF_ALBION_EPROTO    -2
#define SF_ALBION_ETIMEDOUT -3
#define SF_ALBION_EINVAL    -4
#define SF_ALBION_EDEVICE   -5
#define SF_ALBION_EUNAVAIL  -6

#define SF_ALBION_BACKEND_REFERENCE 0u
#define SF_ALBION_BACKEND_RTL_SIM   1u

#define SF_ALBION_MEM_DEVICE_SRAM 0u
#define SF_ALBION_MEM_HOST        1u

typedef struct sf_albion_dev sf_albion_dev;

typedef struct {
    uint32_t backend;        /* SF_ALBION_BACKEND_* */
    uint32_t config;         /* 0 ALBION_MIN, 1 ALBION_CLOUD, 2 ALBION_HPC */
    uint32_t domain;         /* tenant domain for this session, 2..15 */
    uint32_t debug_strap;    /* simulation only */
    uint32_t host_latency;   /* simulation only, device cycles */
    const char *sim_path;    /* NULL = build/sim/cfg<N>/albion_sim */
    const char *firmware_path; /* NULL = build/firmware/albion_fw.bin */
} sf_albion_open_opts;

typedef struct {
    uint32_t chip_id, rtl_version, config_id;
    uint32_t feat_impl, feat_req, feat_unavail;
    uint32_t sram_banks, sram_bank_bytes, windows, cmdq_depth, fw_version;
} sf_albion_info_t;

typedef struct {
    uint32_t kind;   /* SF_ALBION_MEM_* */
    uint32_t addr;   /* DataFabric address used in work items */
    uint32_t size;
    uint32_t window;
    uint32_t iova;   /* host buffers */
} sf_albion_buffer_t;

typedef struct {
    uint32_t opcode;   /* ALBION_OP_* */
    uint32_t args[7];
} sf_albion_work_t;

typedef struct {
    uint32_t tag, opcode, status;   /* status: ALBION_ST_* */
    uint32_t result[3];
} sf_albion_completion_t;

int sf_albion_open(const sf_albion_open_opts *opts, sf_albion_dev **out);
int sf_albion_info(sf_albion_dev *dev, sf_albion_info_t *out);
int sf_albion_alloc(sf_albion_dev *dev, uint32_t kind, uint32_t size, sf_albion_buffer_t *out);
int sf_albion_submit(sf_albion_dev *dev, const sf_albion_work_t *work, uint32_t *ticket);
/* 1 = complete (out filled), 0 = pending, <0 = error */
int sf_albion_poll(sf_albion_dev *dev, uint32_t ticket, sf_albion_completion_t *out);
int sf_albion_wait(sf_albion_dev *dev, uint32_t ticket, uint64_t timeout_cycles, sf_albion_completion_t *out);
/* returns the number of counters available (fills min(n, available)) or <0 */
int sf_albion_counters(sf_albion_dev *dev, uint64_t *values, uint32_t n);
int sf_albion_host_write(sf_albion_dev *dev, const sf_albion_buffer_t *buf, uint32_t offset, const uint32_t *data, uint32_t words);
int sf_albion_host_read(sf_albion_dev *dev, const sf_albion_buffer_t *buf, uint32_t offset, uint32_t *data, uint32_t words);
int sf_albion_close(sf_albion_dev *dev);
const char *sf_albion_last_error(void);

#ifdef __cplusplus
}
#endif
#endif /* SF_ALBION_H */
