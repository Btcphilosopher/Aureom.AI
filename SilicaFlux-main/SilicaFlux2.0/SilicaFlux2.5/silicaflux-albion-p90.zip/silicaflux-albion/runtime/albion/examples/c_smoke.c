/* SilicaFlux Albion C ABI smoke test: open -> info -> alloc -> submit/poll/wait
 * -> counters -> close, on the backend given as argv[1] ("ref" or "rtl"). */
#include <stdio.h>
#include <string.h>
#include "sf_albion.h"
#include "albion_regs.h"

#define CHECK(x) do { int _r = (x); if (_r < 0) { \
    fprintf(stderr, "FAIL %s -> %d: %s\n", #x, _r, sf_albion_last_error()); return 1; } } while (0)

int main(int argc, char **argv) {
    sf_albion_open_opts o;
    memset(&o, 0, sizeof o);
    o.backend = (argc > 1 && strcmp(argv[1], "rtl") == 0) ? SF_ALBION_BACKEND_RTL_SIM : SF_ALBION_BACKEND_REFERENCE;
    o.domain = 2;
    o.host_latency = 1;
    sf_albion_dev *d = NULL;
    CHECK(sf_albion_open(&o, &d));

    sf_albion_info_t info;
    CHECK(sf_albion_info(d, &info));
    printf("chip=0x%08x config=%u banks=%u x %u fw=0x%08x unavail=0x%x\n", info.chip_id, info.config_id,
           info.sram_banks, info.sram_bank_bytes, info.fw_version, info.feat_unavail);
    if (info.chip_id != ALBION_CHIP_ID) { fprintf(stderr, "bad chip id\n"); return 1; }

    sf_albion_buffer_t h, s;
    CHECK(sf_albion_alloc(d, SF_ALBION_MEM_HOST, 256, &h));
    CHECK(sf_albion_alloc(d, SF_ALBION_MEM_DEVICE_SRAM, 256, &s));
    uint32_t data[64], back[64];
    for (int i = 0; i < 64; i++) data[i] = 0xA1B00000u + (uint32_t)i;
    CHECK(sf_albion_host_write(d, &h, 0, data, 64));

    sf_albion_work_t w = { ALBION_OP_DMA_COPY, { h.addr, s.addr, 256, 0, 0, 0, 0 } };
    uint32_t t;
    CHECK(sf_albion_submit(d, &w, &t));
    sf_albion_completion_t c;
    int done = sf_albion_poll(d, t, &c);      /* non-blocking first */
    CHECK(done);
    if (!done) CHECK(sf_albion_wait(d, t, 1000000, &c));
    if (c.status != ALBION_ST_OK) { fprintf(stderr, "copy status %u\n", c.status); return 1; }

    sf_albion_work_t back_w = { ALBION_OP_DMA_COPY, { s.addr, h.addr + 0, 256, 0, 0, 0, 0 } };
    /* copy back into the second half is not allowed (size), reuse the host buffer instead */
    CHECK(sf_albion_host_write(d, &h, 0, (uint32_t[64]){0}, 64));
    CHECK(sf_albion_submit(d, &back_w, &t));
    CHECK(sf_albion_wait(d, t, 1000000, &c));
    CHECK(sf_albion_host_read(d, &h, 0, back, 64));
    if (c.status != ALBION_ST_OK || memcmp(data, back, sizeof data) != 0) { fprintf(stderr, "roundtrip mismatch\n"); return 1; }

    sf_albion_work_t bad = { ALBION_OP_MATMUL_INT8, { 0 } };
    CHECK(sf_albion_submit(d, &bad, &t));
    CHECK(sf_albion_wait(d, t, 1000000, &c));
    printf("MATMUL_INT8 status=0x%02x (expect UNSUPPORTED 0x%02x)\n", c.status, ALBION_ST_UNSUPPORTED);
    if (c.status != ALBION_ST_UNSUPPORTED) return 1;

    uint64_t cnt[64];
    int n = sf_albion_counters(d, cnt, 64);
    CHECK(n);
    printf("counters=%d DMA_BYTES=%llu CMD_SUBMITTED=%llu\n", n, (unsigned long long)cnt[ALBION_TC_DMA_BYTES],
           (unsigned long long)cnt[ALBION_TC_CMD_SUBMITTED]);
    CHECK(sf_albion_close(d));
    printf("C ABI smoke: PASS\n");
    return 0;
}
