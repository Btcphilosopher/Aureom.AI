//! Quick bring-up smoke: open both backends, PING, alloc, DMA host->SRAM->host, CRC.
use sf_albion::*;

fn run(backend: Backend) -> Result<()> {
    let mut dev = Device::open(&OpenOptions { backend, ..Default::default() })?;
    let i = dev.info().clone();
    println!("[{}] {} fw=0x{:08x} feat_impl=0x{:x} unavail=0x{:x}", i.backend, i.config_name, i.fw_version, i.feat_impl, i.feat_unavail);
    println!("  ping: {:?}", dev.run(&Work::Ping)?);
    let h = dev.alloc(MemKind::Host, 1024)?;
    let s = dev.alloc(MemKind::DeviceSram, 1024)?;
    let h2 = dev.alloc(MemKind::Host, 1024)?;
    let data: Vec<u32> = (0..256u32).map(|i| i.wrapping_mul(0x9E37_79B9)).collect();
    dev.host_write(&h, 0, &data)?;
    let c1 = dev.run(&Work::DmaCopy { src: h.addr, dst: s.addr, len: 1024 })?;
    let c2 = dev.run(&Work::DmaCopy { src: s.addr, dst: h2.addr, len: 1024 })?;
    let back = dev.host_read(&h2, 0, 256)?;
    let crc = dev.run(&Work::Crc32 { addr: s.addr, len: 1024 })?;
    println!("  h2d {} d2h {} roundtrip_ok={} crc=0x{:08x} expect=0x{:08x}", c1.status, c2.status, back == data, crc.result[0], refmodel::crc32_words(&data));
    println!("  cycles={:?} counters DMA_BYTES={}", dev.cycles()?, dev.counters()?.get(regs::TC_DMA_BYTES));
    dev.close()
}

fn main() {
    for b in [Backend::Reference, Backend::RtlSim { binary: None }] {
        if let Err(e) = run(b) { println!("ERROR: {e}"); }
    }
}
