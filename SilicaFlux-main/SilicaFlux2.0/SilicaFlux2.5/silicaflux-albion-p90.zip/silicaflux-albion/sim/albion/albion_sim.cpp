// SilicaFlux Albion - Verilator full-chip harness ("simulated host").
//
// Plays the role of the host platform around sf_albion_cloud_top:
//   * drives the host MMIO target port (one outstanding request, like a PCIe BAR
//     access that waits for its completion),
//   * services the host-memory requester port from a sparse host memory model with
//     configurable latency and optional faulting IOVA ranges (models IOMMU faults),
//   * exposes everything over a line protocol on stdin/stdout so the Rust runtime's
//     RTL backend (runtime/albion/src/backend/rtlsim.rs) can drive it.
//
// Protocol (one command per line, one reply line, replies start with OK or ERR):
//   RESET                       pin reset (8 cycles)            -> OK <cycle>
//   W <addr> <data>             MMIO write                      -> OK <err>
//   R <addr>                    MMIO read                       -> OK <data> <err>
//   WB <addr> <n> <d0..dn-1>    n sequential MMIO writes        -> OK <nerr>
//   RB <addr> <n>               n sequential MMIO reads         -> OK <d0..> (errors -> ERR)
//   HW <iova> <n> <d0..>        host memory write (no sim time) -> OK
//   HR <iova> <n>               host memory read                -> OK <d0..>
//   STEP <n>                    advance n cycles                -> OK <cycle>
//   WAITIRQ <max>               run until host_irq or max       -> OK <irq 0|1> <cycles>
//   RUNTRAP <cause> <max>       run until core traps with cause -> OK <found 0|1> <cycles>
//   CYC                                                         -> OK <cycle>
//   STRAP <0|1>                 debug strap pin                 -> OK
//   HMLAT <n>                   host memory latency (>=1)       -> OK
//   HMFAULT <iova> <bytes>      add faulting host range         -> OK
//   TRACE <path|off>            core retirement trace           -> OK
//   STATS                       harness counters                -> OK k=v ...
//   QUIT                        (writes coverage if enabled)    -> OK
// Numbers may be decimal or 0x-prefixed hex.
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <unistd.h>

#include "Vsf_albion_cloud_top.h"
#include "verilated.h"
#if VM_COVERAGE
#include "verilated_cov.h"
#endif

namespace {

struct HostMem {
    std::unordered_map<uint32_t, std::vector<uint32_t>> pages;  // 4 KiB pages
    uint32_t read(uint32_t iova) const {
        auto it = pages.find(iova >> 12);
        if (it == pages.end()) return 0;
        return it->second[(iova & 0xFFF) >> 2];
    }
    void write(uint32_t iova, uint32_t data, uint32_t strb) {
        auto& p = pages[iova >> 12];
        if (p.empty()) p.assign(1024, 0);
        uint32_t& w = p[(iova & 0xFFF) >> 2];
        uint32_t mask = 0;
        for (int b = 0; b < 4; b++)
            if (strb & (1u << b)) mask |= 0xFFu << (8 * b);
        w = (w & ~mask) | (data & mask);
    }
};

struct Range { uint32_t base, size; };

class Harness {
public:
    explicit Harness(VerilatedContext* ctx) : top_(new Vsf_albion_cloud_top{ctx}) {
        top_->clk_i = 0;
        top_->rst_ni = 0;
        top_->dbg_strap_i = 0;
        top_->h_req_valid_i = 0;
        top_->hm_req_ready_i = 1;
        top_->hm_rsp_valid_i = 0;
        top_->eval();
    }
    ~Harness() {
        if (trace_) fclose(trace_);
        top_->final();
    }

    uint64_t cycle() const { return cycle_; }

    // One clock cycle: settle inputs with clk low, sample, rising edge.
    void tick() {
        top_->clk_i = 0;
        // host memory response due this cycle?
        bool rsp_now = hm_pending_ && cycle_ >= hm_due_;
        top_->hm_rsp_valid_i = rsp_now;
        top_->hm_rsp_rdata_i = rsp_now ? hm_rdata_ : 0;
        top_->hm_rsp_err_i = rsp_now ? hm_err_ : 0;
        top_->hm_req_ready_i = !hm_pending_ || rsp_now;
        top_->eval();

        // sample (combinational outputs are settled now)
        bool hm_hs = top_->hm_req_valid_o && top_->hm_req_ready_i;
        uint32_t hm_addr = top_->hm_req_addr_o, hm_wdata = top_->hm_req_wdata_o;
        bool hm_we = top_->hm_req_we_o;
        uint32_t hm_strb = top_->hm_req_wstrb_o;
        h_hs_ = top_->h_req_valid_i && top_->h_req_ready_o;
        h_rsp_ = top_->h_rsp_valid_o;
        h_rsp_data_ = top_->h_rsp_rdata_o;
        h_rsp_err_ = top_->h_rsp_err_o;
        irq_ = top_->host_irq_o;
        if (top_->trace_valid_o) {
            last_trap_ = top_->trace_trap_o;
            last_cause_ = top_->trace_cause_o;
            if (trace_)
                fprintf(trace_, "%08x %08x %d %d %08x %d %08x\n", top_->trace_pc_o, top_->trace_insn_o,
                        top_->trace_rd_we_o, top_->trace_rd_o, top_->trace_rd_wdata_o, top_->trace_trap_o,
                        top_->trace_cause_o);
            trace_seen_ = true;
        }

        top_->clk_i = 1;
        top_->eval();
        cycle_++;

        if (rsp_now) hm_pending_ = false;
        if (hm_hs) {
            bool fault = hm_addr >= kHostMemBytes;
            for (const auto& r : faults_)
                if (hm_addr >= r.base && hm_addr - r.base < r.size) fault = true;
            hm_err_ = fault;
            if (hm_we) {
                if (!fault) mem_.write(hm_addr & ~3u, hm_wdata, hm_strb);
                hm_writes_++;
            } else {
                hm_rdata_ = fault ? 0xDEADBEEF : mem_.read(hm_addr & ~3u);
                hm_reads_++;
            }
            hm_pending_ = true;
            hm_due_ = cycle_ + (hm_latency_ - 1);
        }
        if (h_hs_) top_->h_req_valid_i = 0;
    }

    void reset() {
        top_->rst_ni = 0;
        top_->h_req_valid_i = 0;
        hm_pending_ = false;
        for (int i = 0; i < 8; i++) tick();
        top_->rst_ni = 1;
        for (int i = 0; i < 4; i++) tick();
    }

    // MMIO transaction; returns false on simulation timeout
    bool mmio(uint32_t addr, bool we, uint32_t wdata, uint32_t& rdata, uint32_t& err) {
        top_->h_req_valid_i = 1;
        top_->h_req_addr_i = addr;
        top_->h_req_we_i = we;
        top_->h_req_wdata_i = wdata;
        top_->h_req_wstrb_i = 0xF;
        bool accepted = false;
        for (int i = 0; i < kMmioTimeout; i++) {
            tick();
            if (h_hs_) accepted = true;
            if (accepted) break;
        }
        if (!accepted) { top_->h_req_valid_i = 0; return false; }
        for (int i = 0; i < kMmioTimeout; i++) {
            // response appears in a later cycle; sample with the next tick
            tick();
            if (h_rsp_) {
                rdata = h_rsp_data_;
                err = h_rsp_err_;
                mmio_ops_++;
                return true;
            }
        }
        return false;
    }

    bool wait_irq(uint64_t max, uint64_t& waited) {
        uint64_t start = cycle_;
        while (cycle_ - start < max) {
            tick();
            if (irq_) { waited = cycle_ - start; return true; }
        }
        waited = cycle_ - start;
        return false;
    }

    bool run_until_trap(uint32_t cause, uint64_t max, uint64_t& waited) {
        uint64_t start = cycle_;
        while (cycle_ - start < max) {
            trace_seen_ = false;
            tick();
            if (trace_seen_ && last_trap_ && last_cause_ == cause) { waited = cycle_ - start; return true; }
        }
        waited = cycle_ - start;
        return false;
    }

    void strap(bool v) { top_->dbg_strap_i = v; }
    void hm_latency(uint32_t n) { hm_latency_ = n < 1 ? 1 : n; }
    void hm_fault(uint32_t base, uint32_t size) { faults_.push_back({base, size}); }
    HostMem& mem() { return mem_; }
    void set_trace(const std::string& path) {
        if (trace_) { fclose(trace_); trace_ = nullptr; }
        if (path != "off") trace_ = fopen(path.c_str(), "w");
    }
    std::string stats() const {
        std::ostringstream o;
        o << "cycle=" << cycle_ << " mmio_ops=" << mmio_ops_ << " hm_reads=" << hm_reads_
          << " hm_writes=" << hm_writes_ << " hm_latency=" << hm_latency_;
        return o.str();
    }

private:
    static constexpr int kMmioTimeout = 100000;
    static constexpr uint32_t kHostMemBytes = 0x40000000u;  // 1 GiB of host IOVA space
    std::unique_ptr<Vsf_albion_cloud_top> top_;
    uint64_t cycle_ = 0;
    HostMem mem_;
    std::vector<Range> faults_;
    bool hm_pending_ = false, hm_err_ = false;
    uint64_t hm_due_ = 0;
    uint32_t hm_rdata_ = 0, hm_latency_ = 1;
    bool h_hs_ = false, h_rsp_ = false, irq_ = false;
    uint32_t h_rsp_data_ = 0, h_rsp_err_ = 0;
    bool trace_seen_ = false, last_trap_ = false;
    uint32_t last_cause_ = 0;
    FILE* trace_ = nullptr;
    uint64_t mmio_ops_ = 0, hm_reads_ = 0, hm_writes_ = 0;
};

uint64_t num(const std::string& s) { return std::strtoull(s.c_str(), nullptr, 0); }

}  // namespace

int main(int argc, char** argv) {
    auto ctx = std::make_unique<VerilatedContext>();
    ctx->commandArgs(argc, argv);
    std::string cov_path = "albion_coverage.dat";
    if (const char* d = std::getenv("SF_ALBION_COV_DIR"))  // one file per simulator process
        cov_path = std::string(d) + "/cov_" + std::to_string(static_cast<long>(getpid())) + ".dat";
    for (int i = 1; i < argc; i++)
        if (std::strncmp(argv[i], "+cov=", 5) == 0) cov_path = argv[i] + 5;
    Harness h(ctx.get());
    h.reset();

    std::ios::sync_with_stdio(false);
    std::string line;
    while (std::getline(std::cin, line)) {
        std::istringstream in(line);
        std::string cmd;
        in >> cmd;
        std::vector<std::string> a;
        std::string t;
        while (in >> t) a.push_back(t);
        std::ostringstream out;
        auto need = [&](size_t n) {
            if (a.size() < n) { out << "ERR missing arguments"; return false; }
            return true;
        };
        if (cmd == "RESET") {
            h.reset();
            out << "OK " << h.cycle();
        } else if (cmd == "W") {
            if (need(2)) {
                uint32_t rd, err;
                if (!h.mmio(num(a[0]), true, num(a[1]), rd, err)) out << "ERR mmio timeout";
                else out << "OK " << err;
            }
        } else if (cmd == "R") {
            if (need(1)) {
                uint32_t rd, err;
                if (!h.mmio(num(a[0]), false, 0, rd, err)) out << "ERR mmio timeout";
                else out << "OK " << rd << " " << err;
            }
        } else if (cmd == "WB") {
            if (need(2)) {
                uint32_t addr = num(a[0]), n = num(a[1]), nerr = 0;
                bool ok = a.size() >= 2 + n;
                for (uint32_t i = 0; ok && i < n; i++) {
                    uint32_t rd, err;
                    if (!h.mmio(addr + 4 * i, true, num(a[2 + i]), rd, err)) ok = false;
                    else if (err) nerr++;
                }
                if (!ok) out << "ERR wb failed";
                else out << "OK " << nerr;
            }
        } else if (cmd == "RB") {
            if (need(2)) {
                uint32_t addr = num(a[0]), n = num(a[1]);
                std::ostringstream vals;
                bool ok = true;
                for (uint32_t i = 0; ok && i < n; i++) {
                    uint32_t rd, err;
                    if (!h.mmio(addr + 4 * i, false, 0, rd, err) || err) ok = false;
                    else vals << " " << rd;
                }
                if (!ok) out << "ERR rb failed";
                else out << "OK" << vals.str();
            }
        } else if (cmd == "HW") {
            if (need(2)) {
                uint32_t iova = num(a[0]), n = num(a[1]);
                if (a.size() < 2 + n) out << "ERR missing data";
                else {
                    for (uint32_t i = 0; i < n; i++) h.mem().write(iova + 4 * i, num(a[2 + i]), 0xF);
                    out << "OK";
                }
            }
        } else if (cmd == "HR") {
            if (need(2)) {
                uint32_t iova = num(a[0]), n = num(a[1]);
                out << "OK";
                for (uint32_t i = 0; i < n; i++) out << " " << h.mem().read(iova + 4 * i);
            }
        } else if (cmd == "STEP") {
            if (need(1)) {
                uint64_t n = num(a[0]);
                for (uint64_t i = 0; i < n; i++) h.tick();
                out << "OK " << h.cycle();
            }
        } else if (cmd == "WAITIRQ") {
            if (need(1)) {
                uint64_t w;
                bool irq = h.wait_irq(num(a[0]), w);
                out << "OK " << (irq ? 1 : 0) << " " << w;
            }
        } else if (cmd == "RUNTRAP") {
            if (need(2)) {
                uint64_t w;
                bool f = h.run_until_trap(num(a[0]), num(a[1]), w);
                out << "OK " << (f ? 1 : 0) << " " << w;
            }
        } else if (cmd == "CYC") {
            out << "OK " << h.cycle();
        } else if (cmd == "STRAP") {
            if (need(1)) { h.strap(num(a[0]) != 0); out << "OK"; }
        } else if (cmd == "HMLAT") {
            if (need(1)) { h.hm_latency(num(a[0])); out << "OK"; }
        } else if (cmd == "HMFAULT") {
            if (need(2)) { h.hm_fault(num(a[0]), num(a[1])); out << "OK"; }
        } else if (cmd == "TRACE") {
            if (need(1)) { h.set_trace(a[0]); out << "OK"; }
        } else if (cmd == "STATS") {
            out << "OK " << h.stats();
        } else if (cmd == "QUIT") {
            std::cout << "OK" << std::endl;
            break;
        } else {
            out << "ERR unknown command";
        }
        std::cout << out.str() << "\n" << std::flush;
        if (ctx->gotFinish()) break;
    }
#if VM_COVERAGE
    ctx->coveragep()->write(cov_path.c_str());
#endif
    return 0;
}
