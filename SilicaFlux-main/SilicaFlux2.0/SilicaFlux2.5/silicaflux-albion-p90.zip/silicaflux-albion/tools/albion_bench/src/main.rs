//! AlbionBench - SilicaFlux Albion performance laboratory.
//!
//! Every number is tagged with the category of evidence it comes from:
//!   theoretical  - derived analytically from the micro-architecture (no measurement)
//!   simulation   - measured in cycles on the Verilator RTL model (cycle-accurate for the
//!                  RTL; the host side is a model, so host latency is a parameter)
//!   synthesis    - read from reports/synth (filled by `make albion-synth`, not here)
//!   fpga         - requires a board run; none exists -> recorded as unavailable
//!   silicon      - none exists -> recorded as unavailable
//! Throughput is reported in bytes/cycle. No clock frequency is assumed: converting to
//! GB/s needs a closed timing report, which this repository does not have.
use sf_albion::*;
use std::collections::BTreeMap;
use std::fmt::Write as _;
use std::path::PathBuf;
use std::process::Command;

struct Metric {
    group: &'static str,
    name: String,
    value: f64,
    unit: &'static str,
    category: &'static str,
    detail: String,
}

struct Bench {
    metrics: Vec<Metric>,
    unavailable: Vec<(String, String)>,
    config: u32,
    /// full telemetry snapshots (name -> value) of representative sessions
    snapshots: Vec<(String, Vec<(&'static str, u64)>)>,
}

impl Bench {
    fn add(&mut self, group: &'static str, name: impl Into<String>, value: f64, unit: &'static str, category: &'static str, detail: impl Into<String>) {
        let m = Metric { group, name: name.into(), value, unit, category, detail: detail.into() };
        println!("  [{:<11}] {:<10} {:<46} {:>12.4} {}", m.category, m.group, m.name, m.value, m.unit);
        self.metrics.push(m);
    }
}

fn open(config: u32, latency: u32, strap: bool) -> Device {
    Device::open(&OpenOptions {
        backend: Backend::RtlSim { binary: None },
        config,
        host_latency: latency,
        debug_strap: strap,
        ..Default::default()
    })
    .unwrap_or_else(|e| panic!("open rtl cfg{config}: {e}"))
}

fn delta(a: &Counters, b: &Counters, i: usize) -> u64 {
    b.get(i).wrapping_sub(a.get(i))
}

/// DMA engine cycles for one validated copy (DMA.CYCLES register via the completion).
fn copy_cycles(d: &mut Device, src: u32, dst: u32, len: u32) -> (u32, Counters, Counters) {
    let c0 = d.counters().unwrap();
    let c = d.run(&Work::DmaCopy { src, dst, len }).unwrap();
    assert!(c.status.is_ok(), "bench copy failed: {}", c.status);
    let c1 = d.counters().unwrap();
    (c.result[1], c0, c1)
}

fn dma_throughput(b: &mut Bench) {
    println!("== DMA throughput / SRAM bandwidth / DataFabric contention");
    let cfg = b.config;
    let mut d = open(cfg, 1, false);
    let bank = d.info().sram_bank_bytes;
    let len = 8192u32.min(bank / 2);
    // two buffers in different banks, two in the same bank
    let a = d.alloc(MemKind::DeviceSram, bank).unwrap(); // fills bank 1
    let x = d.alloc(MemKind::DeviceSram, bank).unwrap(); // bank 2
    let (cyc, c0, c1) = copy_cycles(&mut d, a.addr, x.addr, len);
    b.add("dma", "SRAM->SRAM copy, cross-bank", len as f64 / cyc as f64, "B/cycle", "simulation",
          format!("{len} B in {cyc} DMA cycles; bank_conflict_cycles={}", delta(&c0, &c1, regs::TC_BANK_CONFLICT)));
    let (cyc2, c0, c1) = copy_cycles(&mut d, a.addr, a.addr + bank / 2, len);
    b.add("dma", "SRAM->SRAM copy, same bank", len as f64 / cyc2 as f64, "B/cycle", "simulation",
          format!("{len} B in {cyc2} DMA cycles; bank_conflict_cycles={}", delta(&c0, &c1, regs::TC_BANK_CONFLICT)));
    b.add("fabric", "same-bank copy slowdown vs cross-bank", cyc2 as f64 / cyc as f64, "x", "simulation",
          "single-port SRAM: read and write beats serialise on one bank");
    let c0 = d.counters().unwrap();
    let f = d.run(&Work::DmaFill { dst: x.addr, len, pattern: 0xA5A5_A5A5 }).unwrap();
    let c1 = d.counters().unwrap();
    b.add("sram", "SRAM write bandwidth (DMA fill)", len as f64 / f.result[1] as f64, "B/cycle", "simulation",
          format!("{len} B in {} cycles; DMAWR stalls={}", f.result[1], delta(&c0, &c1, regs::TC_M_DMAWR_STALL)));
    b.add("sram", "SRAM read+write bandwidth (cross-bank copy)", 2.0 * len as f64 / cyc as f64, "B/cycle", "simulation", "read beats + write beats");
    b.add("dma", "theoretical: cross-bank copy / fill", 4.0, "B/cycle", "theoretical",
          "one 32-bit beat per cycle per DMA port (back-to-back issue on response, 1-cycle SRAM)");
    b.add("dma", "theoretical: same-bank copy", 2.0, "B/cycle", "theoretical", "single-port bank shared by read and write beats");
    d.close().unwrap();

    // host latency sweep
    for lat in [1u32, 4, 16, 64] {
        let mut d = open(cfg, lat, false);
        let h = d.alloc(MemKind::Host, 4096).unwrap();
        let s = d.alloc(MemKind::DeviceSram, 4096).unwrap();
        let (h2d, c0, c1) = copy_cycles(&mut d, h.addr, s.addr, 4096);
        let (d2h, _, _) = copy_cycles(&mut d, s.addr, h.addr, 4096);
        b.add("dma", format!("host->SRAM, host latency {lat}"), 4096.0 / h2d as f64, "B/cycle", "simulation",
              format!("4096 B in {h2d} cycles; DMARD stall cycles={}", delta(&c0, &c1, regs::TC_M_DMARD_STALL)));
        b.add("dma", format!("SRAM->host, host latency {lat}"), 4096.0 / d2h as f64, "B/cycle", "simulation", format!("4096 B in {d2h} cycles"));
        b.add("dma", format!("theoretical: host path, latency {lat}"), 4.0 / lat as f64, "B/cycle", "theoretical",
              "single outstanding request on the host-memory port, re-issue in the response cycle: 4 B per L cycles");
        d.close().unwrap();
    }
}

fn latency(b: &mut Bench) {
    println!("== I/O latency (host-observed, end to end)");
    let mut d = open(b.config, 1, false);
    let s = d.alloc(MemKind::DeviceSram, 256).unwrap();
    let mut ping = vec![];
    let mut small = vec![];
    for _ in 0..16 {
        let t0 = d.cycles().unwrap().unwrap();
        let c = d.run(&Work::Ping).unwrap();
        assert!(c.status.is_ok());
        ping.push(d.cycles().unwrap().unwrap() - t0);
        let t0 = d.cycles().unwrap().unwrap();
        let c = d.run(&Work::DmaFill { dst: s.addr, len: 64, pattern: 1 }).unwrap();
        assert!(c.status.is_ok());
        small.push(d.cycles().unwrap().unwrap() - t0);
    }
    let med = |v: &mut Vec<u64>| {
        v.sort();
        v[v.len() / 2] as f64
    };
    b.add("latency", "PING round trip (median of 16)", med(&mut ping), "cycles", "simulation",
          "host MMIO writes (8 cmd words + doorbell) -> firmware -> completion -> IRQ -> 4 reads + pop");
    b.add("latency", "64 B DMA_FILL round trip (median of 16)", med(&mut small), "cycles", "simulation", "includes firmware validation");
    let c = d.counters().unwrap();
    b.add("core", "ControlCore instructions retired (session)", c.get(regs::TC_CORE_INSTRET) as f64, "instr", "simulation", "");
    b.add("core", "ControlCore sleep fraction (WFI)", c.get(regs::TC_CORE_SLEEP_CYCLES) as f64 / c.get(regs::TC_CYCLES) as f64, "ratio", "simulation", "");
    b.add("fabric", "HOST port stall cycles (session)", c.get(regs::TC_M_HOST_STALL) as f64, "cycles", "simulation", "MMIO polling contention");
    d.close().unwrap();
}

fn queues(b: &mut Bench) {
    println!("== command queue stalls");
    let mut d = open(b.config, 1, false);
    let depth = d.info().cmdq_depth;
    let s = d.alloc(MemKind::DeviceSram, 4096).unwrap();
    let c0 = d.counters().unwrap();
    let t0 = d.cycles().unwrap().unwrap();
    let n = 32u32;
    let ts: Vec<_> = (0..n).map(|i| d.submit(&Work::DmaFill { dst: s.addr, len: 1024, pattern: i }).unwrap()).collect();
    for t in ts {
        assert!(d.wait(t, 50_000_000).unwrap().status.is_ok());
    }
    let dt = d.cycles().unwrap().unwrap() - t0;
    let c1 = d.counters().unwrap();
    b.add("queue", format!("{n} x 1 KiB fills, queue depth {depth}"), (n as f64 * 1024.0) / dt as f64, "B/cycle", "simulation",
          format!("{dt} cycles end to end; command drops={}", delta(&c0, &c1, regs::TC_CMDQ_DROPS)));
    b.add("queue", "firmware + mailbox overhead per command", (dt as f64 - (n * 256) as f64) / n as f64, "cycles", "simulation",
          "end-to-end cycles minus ideal 256 fill cycles per command");
    // mixed session for the DataFabric traffic view: host<->SRAM, SRAM<->SRAM, CRC, polling
    let h = d.alloc(MemKind::Host, 8192).unwrap();
    let s2 = d.alloc(MemKind::DeviceSram, 8192).unwrap();
    assert!(d.run(&Work::DmaCopy { src: h.addr, dst: s2.addr, len: 8192 }).unwrap().status.is_ok());
    assert!(d.run(&Work::DmaCopy { src: s2.addr, dst: s.addr, len: 4096 }).unwrap().status.is_ok());
    assert!(d.run(&Work::Crc32 { addr: s.addr, len: 1024 }).unwrap().status.is_ok());
    assert!(d.run(&Work::DmaCopy { src: s.addr, dst: h.addr, len: 4096 }).unwrap().status.is_ok());
    let snap = d.counters().unwrap().named();
    b.snapshots.push(("mixed session (queue test + host/SRAM copies + CRC)".into(), snap));
    d.close().unwrap();
}

fn ras(b: &mut Bench) {
    println!("== ECC / RAS events");
    let mut d = open(b.config, 1, false);
    let h = d.alloc(MemKind::Host, 1024).unwrap();
    let s = d.alloc(MemKind::DeviceSram, 1024).unwrap();
    let bank = s.addr / d.info().sram_bank_bytes;
    let w0 = (s.addr % d.info().sram_bank_bytes) / 4;
    for (k, mask) in [(0u32, 1u32 << 3), (5, 1 << 17), (9, 0b11)].iter() {
        assert!(d.run_as(&Work::RasInject { bank, word: w0 + k, mask_lo: *mask, mask_hi: 0 }, 1).unwrap().status.is_ok());
        // a single-word write lands the armed flip without disturbing earlier injections
        assert!(d.run(&Work::DmaCopy { src: h.addr + 4 * k, dst: s.addr + 4 * k, len: 4 }).unwrap().status.is_ok());
    }
    let c = d.run(&Work::Crc32 { addr: s.addr, len: 1024 }).unwrap();
    let cnt = d.counters().unwrap();
    b.add("ras", "ECC corrected events", cnt.get(regs::TC_ECC_CE) as f64, "events", "simulation", "2 single-bit injections, read by firmware CRC");
    b.add("ras", "ECC uncorrectable events", cnt.get(regs::TC_ECC_UE) as f64, "events", "simulation",
          format!("1 double-bit injection; CRC status {} at 0x{:08x}", c.status, c.result[2]));
    d.close().unwrap();
}

fn accounting(b: &mut Bench) {
    println!("== per-domain accounting");
    let mut d = open(b.config, 1, false);
    let mut expect = BTreeMap::new();
    for (dom, n) in [(2u8, 1u32), (3, 3), (4, 7)] {
        d.set_domain(dom).unwrap();
        let s = d.alloc(MemKind::DeviceSram, 2048).unwrap();
        for _ in 0..n {
            assert!(d.run(&Work::DmaFill { dst: s.addr, len: 2048, pattern: dom as u32 }).unwrap().status.is_ok());
        }
        expect.insert(dom, 2048 * n as u64);
    }
    let c = d.counters().unwrap();
    for (dom, e) in expect {
        let got = c.get(regs::TC_DOM0_BYTES + dom as usize);
        assert_eq!(got, e, "domain {dom} accounting");
        b.add("domains", format!("domain {dom} DMA bytes (expected {e})"), got as f64, "bytes", "simulation", "DOMn_BYTES counter, exact");
    }
    b.add("domains", "domain 0 (firmware scrub) DMA bytes", c.get(regs::TC_DOM0_BYTES) as f64, "bytes", "simulation", "zero-on-allocate scrubbing");
    d.close().unwrap();
}

fn unavailable(b: &mut Bench) {
    let missing = [
        ("packet throughput", "PacketForge (Project 86) is not present in the repository; ALBION_CLOUD/HPC report FEAT_UNAVAIL"),
        ("compute throughput (INT8 GEMM)", "ComputeWorks (Project 88) is not present in the repository"),
        ("tensor utilisation", "ComputeWorks (Project 88) is not present in the repository"),
        ("virtual block I/O latency", "VirtualFoundry (Project 87) is not present in the repository"),
        ("fpga measurements", "no FPGA board run has been performed (see reports/fpga for place-and-route estimates only)"),
        ("silicon measurements", "no silicon exists"),
        ("absolute bandwidth (GB/s)", "requires a signed-off clock frequency; no timing closure exists"),
    ];
    for (m, why) in missing {
        println!("  [unavailable] {m}: {why}");
        b.unavailable.push((m.to_string(), why.to_string()));
    }
}

fn sh(cmd: &str, args: &[&str]) -> String {
    Command::new(cmd).args(args).output().ok().map(|o| String::from_utf8_lossy(&o.stdout).lines().next().unwrap_or("").trim().to_string()).unwrap_or_else(|| "unavailable".into())
}

fn esc(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"")
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let config = args.iter().position(|a| a == "--config").and_then(|i| args.get(i + 1)).and_then(|v| v.parse().ok()).unwrap_or(0u32);
    let out_dir = args.iter().position(|a| a == "--out").and_then(|i| args.get(i + 1)).map(PathBuf::from)
        .unwrap_or_else(|| sf_albion::repo_root().join("reports/bench"));
    let mut b = Bench { metrics: vec![], unavailable: vec![], config, snapshots: vec![] };
    println!("AlbionBench - config {} ({})", config, regs::CONFIG_NAMES[config as usize]);
    dma_throughput(&mut b);
    latency(&mut b);
    queues(&mut b);
    ras(&mut b);
    accounting(&mut b);
    unavailable(&mut b);

    let root = sf_albion::repo_root();
    let rev = sh("git", &["-C", root.to_str().unwrap(), "rev-parse", "--short", "HEAD"]);
    // source cleanliness only: regenerated files under reports/ do not make a build dirty
    let dirty = !sh("git", &["-C", root.to_str().unwrap(), "status", "--porcelain", "--untracked-files=no", "--", ".", ":!reports"]).is_empty();
    let ts = sh("date", &["-u", "+%Y-%m-%dT%H:%M:%SZ"]);
    let mut j = String::new();
    let _ = write!(j, "{{\"tool\":\"AlbionBench\",\"timestamp\":\"{ts}\",\"config\":\"{}\",\"backend\":\"rtl-sim (Verilator)\",", regs::CONFIG_NAMES[config as usize]);
    let _ = write!(j, "\"provenance\":{{\"git_rev\":\"{}{}\",\"verilator\":\"{}\",\"rustc\":\"{}\",\"clang\":\"{}\"}},",
        esc(&rev), if dirty { "-dirty" } else { "" }, esc(&sh("verilator", &["--version"])), esc(&sh("rustc", &["--version"])), esc(&sh("clang", &["--version"])));
    j.push_str("\"metrics\":[");
    for (i, m) in b.metrics.iter().enumerate() {
        if i > 0 {
            j.push(',');
        }
        let _ = write!(j, "{{\"group\":\"{}\",\"name\":\"{}\",\"value\":{},\"unit\":\"{}\",\"category\":\"{}\",\"detail\":\"{}\"}}",
            m.group, esc(&m.name), if m.value.is_finite() { format!("{:.6}", m.value) } else { "null".into() }, m.unit, m.category, esc(&m.detail));
    }
    j.push_str("],\"unavailable\":[");
    for (i, (m, why)) in b.unavailable.iter().enumerate() {
        if i > 0 {
            j.push(',');
        }
        let _ = write!(j, "{{\"metric\":\"{}\",\"reason\":\"{}\"}}", esc(m), esc(why));
    }
    j.push_str("],\"telemetry_snapshots\":[");
    for (i, (label, vals)) in b.snapshots.iter().enumerate() {
        if i > 0 {
            j.push(',');
        }
        let _ = write!(j, "{{\"label\":\"{}\",\"counters\":{{", esc(label));
        for (k, (n, v)) in vals.iter().enumerate() {
            if k > 0 {
                j.push(',');
            }
            let _ = write!(j, "\"{n}\":{v}");
        }
        j.push_str("}}");
    }
    j.push_str("]}");
    std::fs::create_dir_all(&out_dir).unwrap();
    let stamp = ts.replace([':', '-'], "");
    std::fs::write(out_dir.join(format!("albionbench_{}_{stamp}.json", regs::CONFIG_NAMES[config as usize])), &j).unwrap();
    std::fs::write(out_dir.join(format!("latest_{}.json", regs::CONFIG_NAMES[config as usize])), &j).unwrap();
    let mut hist = std::fs::read_to_string(out_dir.join("history.jsonl")).unwrap_or_default();
    hist.push_str(&j);
    hist.push('\n');
    std::fs::write(out_dir.join("history.jsonl"), hist).unwrap();
    println!("wrote {}", out_dir.display());
}
