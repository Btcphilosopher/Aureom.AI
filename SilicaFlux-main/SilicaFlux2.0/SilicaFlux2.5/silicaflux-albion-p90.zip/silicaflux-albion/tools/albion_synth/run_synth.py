#!/usr/bin/env python3
"""SilicaFlux Albion synthesis estimates (Yosys).

For each requested configuration:
  1. generic synthesis (technology-independent cell counts, hierarchy kept)
  2. sky130_fd_sc_hd mapping (dfflibmap + ABC with the tt_025C_1v80 liberty) -> standard
     cell area per module and ABC's per-module delay estimate

What these numbers are NOT:
  * SRAM banks are blackbox macros (sf_albion_sram_macro). Their area is NOT reported:
    a compiled macro (OpenRAM / foundry compiler) is required (Project 84 rule: no SRAM area
    from an uncalibrated generic array).
  * ABC delay is a per-module combinational estimate with no wire load, no placement,
    no clock tree and no SRAM timing. It is not a timing sign-off and no Fmax is claimed.

Writes reports/synth/<CONFIG>.json and reports/synth/summary.json.
Usage: run_synth.py [--configs 0,1,2] [--liberty PATH]
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
NAMES = ["ALBION_MIN", "ALBION_CLOUD", "ALBION_HPC"]
DEFAULT_LIB = os.environ.get("SKY130_LIB", str(ROOT / "build/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib"))

STUB = """(* blackbox *)
module sf_albion_sram_macro #(parameter int WORDS = 4096, parameter int W = 39, parameter int AW = $clog2(WORDS)) (
  input logic clk, input logic en, input logic we, input logic [AW-1:0] addr, input logic [W-1:0] wdata, output logic [W-1:0] rdata);
endmodule
"""


def rtl_files():
    files = [l.strip() for l in (ROOT / "rtl/albion/sf_albion.f").read_text().splitlines() if l.strip()]
    return [str(ROOT / f) for f in files if "sram_macro" not in f]


def git_rev():
    try:
        r = subprocess.run(["git", "-C", str(ROOT), "rev-parse", "--short", "HEAD"], capture_output=True, text=True)
        return r.stdout.strip() or "unversioned"
    except OSError:
        return "unversioned"


def run(cfg, lib, work):
    work.mkdir(parents=True, exist_ok=True)
    stub = work / "sram_macro_blackbox.sv"
    stub.write_text(STUB)
    build_id = int(git_rev(), 16) if re.fullmatch(r"[0-9a-f]{7,8}", git_rev()) else 0
    abc_script = work / "abc_sky130.script"
    # yosys' default liberty+delay ABC flow, plus `stime -p` so ABC reports its delay estimate
    abc_script.write_text("strash; &get -n; &fraig -x; &put; scorr; dc2; dretime; strash; &get -n; &dch -f; "
                          "&nf -D 10000; &put; buffer -p; upsize -D 10000; dnsize -D 10000; stime -p\n")
    gen_json = work / f"generic_{cfg}.json"
    sky_json = work / f"sky130_{cfg}.json"
    log = work / f"synth_{cfg}.log"
    script = f"""
read_verilog -sv -DSYNTHESIS {stub} {' '.join(rtl_files())}
hierarchy -check -top sf_albion_cloud_top -chparam CONFIG {cfg} -chparam BUILD_ID {build_id}
synth -top sf_albion_cloud_top
tee -q -o {gen_json} stat -json
dfflibmap -liberty {lib}
abc -liberty {lib} -D 10000 -script {abc_script}
opt_clean -purge
tee -q -o {sky_json} stat -json -liberty {lib}
write_verilog -noattr {work}/netlist_{NAMES[cfg]}_sky130.v
"""
    t0 = time.time()
    r = subprocess.run(["yosys", "-l", str(log), "-q", "-p", script], capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-2000:], r.stderr[-2000:])
        raise SystemExit(f"yosys failed for config {cfg} (see {log})")
    dt = time.time() - t0
    gen = json.loads(gen_json.read_text())
    sky = json.loads(sky_json.read_text())
    text = log.read_text(errors="replace")
    # ABC prints "Delay = <ps> ps" for each module it maps; attribute it to the module
    # named by the preceding "Extracting gate netlist of module" line of the liberty pass
    delays, mod_delay = [], {}
    cur = None
    for line in text[text.find("abc -liberty"):].splitlines():
        mm = re.search(r"Extracting gate netlist of module `(.+?)'", line)
        if mm:
            nm = re.search(r"(sf_albion_\w+)", mm.group(1))
            cur = nm.group(1) if nm else mm.group(1)
        dd = re.search(r"Delay\s*=\s*([0-9.]+)\s*ps", line)
        if dd:
            delays.append(float(dd.group(1)))
            mod_delay[cur] = max(mod_delay.get(cur, 0.0), float(dd.group(1)))
    mods = []
    for name, m in sky["modules"].items():
        mm = re.search(r"(sf_albion_\w+)", name)
        clean = mm.group(1) if mm else name.lstrip("\\")
        flops = sum(v for k, v in m.get("num_cells_by_type", {}).items() if "df" in k.lower())
        mods.append({"module": clean, "full_name": name.lstrip("\\"), "cells": m.get("num_cells", 0),
                     "abc_delay_ps": mod_delay.get(clean),
                     "area_um2": round(m.get("area", 0.0), 1), "flops": flops,
                     "blackbox_srams": m.get("num_cells_by_type", {}).get("sf_albion_sram_macro", 0)})
    design = sky.get("design", {})
    gdesign = gen.get("design", {})
    # flatten-equivalent totals from the design section
    total_area = design.get("area", sum(m["area_um2"] for m in mods))
    cfg_banks = [4, 8, 8][cfg]
    bank_words = [4096, 4096, 8192][cfg]
    out = {
        "category": "synthesis",
        "config": NAMES[cfg],
        "tool": subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip(),
        "liberty": os.path.basename(lib),
        "git_rev": git_rev(),
        "seconds": round(dt, 1),
        "generic": {"cells": gdesign.get("num_cells"), "cells_by_type": gdesign.get("num_cells_by_type", {})},
        "sky130": {
            "std_cell_area_um2": round(total_area, 1),
            "cells": design.get("num_cells"),
            "flops": sum(v for k, v in design.get("num_cells_by_type", {}).items() if "df" in k.lower()),
            "abc_module_delay_ps_max": max(delays) if delays else None,
            "abc_module_delay_ps": dict(sorted(mod_delay.items(), key=lambda kv: -kv[1])),
        },
        "modules": sorted(mods, key=lambda m: -m["area_um2"]),
        "sram_macros": {"count": cfg_banks, "words": bank_words, "bits": 39,
                        "area": None, "note": "blackbox; area requires a compiled SRAM macro (not available)"},
        "caveats": [
            "standard-cell area only; SRAM macros excluded",
            "ABC delay is a per-module combinational estimate without wires, placement or clock tree; no Fmax is claimed",
            "no physical design, no timing sign-off",
        ],
    }
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default="0,1,2")
    ap.add_argument("--liberty", default=DEFAULT_LIB)
    a = ap.parse_args()
    if not Path(a.liberty).exists():
        raise SystemExit(f"liberty {a.liberty} not found: set SKY130_LIB (sky130_fd_sc_hd__tt_025C_1v80.lib)")
    outdir = ROOT / "reports/synth"
    outdir.mkdir(parents=True, exist_ok=True)
    summary = []
    for c in [int(x) for x in a.configs.split(",")]:
        print(f"== synth {NAMES[c]}")
        r = run(c, a.liberty, ROOT / "build/synth")
        (outdir / f"{NAMES[c]}.json").write_text(json.dumps(r, indent=2))
        s = r["sky130"]
        print(f"   sky130 std-cell area {s['std_cell_area_um2']:.0f} um^2, {s['cells']} cells, {s['flops']} flops, "
              f"ABC max module delay {s['abc_module_delay_ps_max']} ps ({r['seconds']} s)")
        for m in r["modules"][:8]:
            print(f"     {m['module']:<28} {m['area_um2']:>12.0f} um^2 {m['cells']:>7} cells")
        summary.append({"config": r["config"], **s, "sram": r["sram_macros"]})
    (outdir / "summary.json").write_text(json.dumps({"category": "synthesis", "results": summary}, indent=2))


if __name__ == "__main__":
    main()
