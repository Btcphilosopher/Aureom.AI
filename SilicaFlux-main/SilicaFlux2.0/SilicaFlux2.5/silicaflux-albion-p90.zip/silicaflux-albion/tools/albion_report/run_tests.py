#!/usr/bin/env python3
"""Run every functional regression and record the outcome in reports/test/test_results.json.

Suites:
  modules   Verilator module testbenches (tests/albion_modules): SECDED, DMA, DataFabric x3 seeds
  runtime   cargo unit tests of the host runtime
  system    cargo system tests (both backends, ISS lock-step, scoreboards, resets, security)
  c_abi     C program linked against libsf_albion.a, on both backends
Exit status is non-zero if anything fails (critical data corruption and isolation
violations are test failures, so they fail the target).
"""
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
B = ROOT / "build"
results = []


def rec(suite, name, ok, seconds, detail=""):
    results.append({"suite": suite, "name": name, "status": "pass" if ok else "FAIL", "seconds": round(seconds, 2), "detail": detail})
    print(f"  [{suite:<7}] {'PASS' if ok else 'FAIL'} {name} ({seconds:.1f}s) {detail}")


def sh(cmd, **kw):
    return subprocess.run(cmd, shell=True, cwd=ROOT, capture_output=True, text=True, **kw)


def module_tbs():
    rtl = "rtl/albion/"
    tbs = {
        "tb_secded": [rtl + "sf_albion_secded.sv"],
        "tb_dma": [rtl + f for f in ["sf_albion_regs_pkg.sv", "sf_albion_secded.sv", "sf_albion_fifo.sv", "sf_albion_dma.sv"]],
        "tb_fabric": [rtl + f for f in ["sf_albion_regs_pkg.sv", "sf_albion_secded.sv", "sf_albion_sram_macro.sv", "sf_albion_sram_bank.sv", "sf_albion_datafabric.sv"]],
    }
    for tb, deps in tbs.items():
        t0 = time.time()
        r = sh(f"verilator --binary --timing -j 2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN {' '.join(deps)} "
               f"tests/albion_modules/{tb}.sv --top-module {tb} -Mdir build/modules/{tb} -o {tb}")
        if r.returncode != 0:
            rec("modules", tb + " (build)", False, time.time() - t0, r.stderr[-300:])
            continue
        seeds = [7, 8, 9] if tb == "tb_fabric" else [1]
        for s in seeds:
            t0 = time.time()
            r = sh(f"./build/modules/{tb}/{tb} +verilator+seed+{s}", timeout=1800)
            summary = next((l for l in r.stdout.splitlines() if l.startswith(tb + ":")), "")
            rec("modules", f"{tb} seed {s}", r.returncode == 0 and f"{tb} PASS" in r.stdout, time.time() - t0, summary)


def cargo(suite, pkg, extra=""):
    t0 = time.time()
    r = sh(f"cargo test --release -p {pkg} --no-fail-fast -- --test-threads=2 {extra}", timeout=7200)
    out = r.stdout + r.stderr
    found = False
    for m in re.finditer(r"^test (\S+) \.\.\. (ok|FAILED)", out, re.M):
        found = True
        rec(suite, m.group(1), m.group(2) == "ok", 0.0)
    if not found or r.returncode != 0:
        rec(suite, f"{pkg} (cargo exit)", r.returncode == 0, time.time() - t0, out[-400:] if r.returncode else "")
    else:
        results[-1]["detail"] = results[-1]["detail"]
        print(f"  [{suite}] cargo {pkg}: {time.time() - t0:.0f}s")


def c_abi():
    t0 = time.time()
    r = sh("gcc -O2 -Wall -Wextra -Werror -Iruntime/albion/include -Ifirmware/albion/include "
           "runtime/albion/examples/c_smoke.c target/release/libsf_albion.a -lpthread -ldl -lm -o build/c/c_smoke")
    if r.returncode != 0:
        rec("c_abi", "build", False, time.time() - t0, r.stderr[-300:])
        return
    for be in ["ref", "rtl"]:
        t0 = time.time()
        r = sh(f"./build/c/c_smoke {be}", timeout=600)
        rec("c_abi", f"c_smoke {be}", r.returncode == 0 and "PASS" in r.stdout, time.time() - t0)


def main():
    (B / "c").mkdir(parents=True, exist_ok=True)
    (B / "modules").mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    print("== module regressions")
    module_tbs()
    print("== runtime unit tests")
    cargo("runtime", "sf-albion")
    print("== system tests (reference + RTL)")
    cargo("system", "albion-system-tests")
    print("== C ABI")
    c_abi()
    rev = sh("git rev-parse --short HEAD").stdout.strip() or "unversioned"
    out = {
        "category": "simulation",
        "generated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "git_rev": rev,
        "seconds": round(time.time() - t0, 1),
        "passed": sum(r["status"] == "pass" for r in results),
        "failed": sum(r["status"] != "pass" for r in results),
        "results": results,
    }
    (ROOT / "reports/test").mkdir(parents=True, exist_ok=True)
    (ROOT / "reports/test/test_results.json").write_text(json.dumps(out, indent=2))
    print(f"== {out['passed']} passed, {out['failed']} failed ({out['seconds']} s)")
    sys.exit(1 if out["failed"] else 0)


if __name__ == "__main__":
    main()
