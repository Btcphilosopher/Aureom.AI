#!/usr/bin/env python3
"""Capture tool versions, Git revision and host facts into reports/provenance.json."""
import json
import platform
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def first(cmd):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        out = (r.stdout or r.stderr).strip().splitlines()
        return out[0].strip() if out else "unavailable"
    except (OSError, subprocess.TimeoutExpired):
        return "unavailable"


def main():
    tools = {
        "verilator": first(["verilator", "--version"]),
        "verilator_coverage": first(["verilator_coverage", "--version"]),
        "yosys": first(["yosys", "-V"]),
        "yosys-abc": "bundled with yosys",
        "nextpnr-ecp5": first(["nextpnr-ecp5", "--version"]),
        "ecppack": first(["ecppack", "--help"]).split(":")[0] if first(["ecppack", "--help"]) != "unavailable" else "unavailable",
        "openroad": first(["openroad", "-version"]),
        "clang": first(["clang", "--version"]),
        "ld.lld": first(["ld.lld", "--version"]),
        "rustc": first(["rustc", "--version"]),
        "cargo": first(["cargo", "--version"]),
        "gcc": first(["gcc", "--version"]),
        "python": platform.python_version(),
        "node": first(["node", "--version"]),
    }
    git = {
        "rev": first(["git", "-C", str(ROOT), "rev-parse", "HEAD"]),
        "short": first(["git", "-C", str(ROOT), "rev-parse", "--short=8", "HEAD"]),
        "dirty": bool(subprocess.run(["git", "-C", str(ROOT), "status", "--porcelain", "--untracked-files=no", "--", ".", ":!reports", ":!tools/albion_terminal/albion_terminal.html", ":!docs/albion/performance_report.md"],
                                     capture_output=True, text=True).stdout.strip()),
        "subject": first(["git", "-C", str(ROOT), "log", "-1", "--format=%s"]),
    }
    lib = ROOT / "build/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib"
    out = {
        "generated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "git": git,
        "tools": tools,
        "pdk": {"sky130_fd_sc_hd__tt_025C_1v80.lib": "present" if lib.exists() else "absent",
                "source": "OpenROAD-flow-scripts flow/platforms/sky130hd/lib (fetched by make albion-pdk)"},
        "host": {"os": platform.platform(), "machine": platform.machine(), "cpus": __import__("os").cpu_count()},
    }
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports/provenance.json").write_text(json.dumps(out, indent=2))
    for k, v in tools.items():
        print(f"  {k:<20} {v}")
    print(f"  git {git['short']}{' (dirty)' if git['dirty'] else ''}")


if __name__ == "__main__":
    main()
