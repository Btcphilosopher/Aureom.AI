#!/usr/bin/env python3
"""Summarise a merged Verilator coverage database (line / toggle / user points).

Usage: cov_report.py <merged.dat> <out.json>
Each point is counted once per (file, line, column, type, signal-or-comment, hierarchy).
Toggle points on wide data buses are reported separately because a data bit that never
toggles in a given workload is a stimulus observation, not dead logic.
"""
import json
import sys
from collections import defaultdict


def parse(path):
    pts = []
    for line in open(path, encoding="latin-1"):
        if not line.startswith("C '"):
            continue
        body, count = line[3:].rsplit("' ", 1)
        kv = {}
        for item in body.split("\x01"):
            if "\x02" in item:
                k, v = item.split("\x02", 1)
                kv[k] = v
        pts.append((kv, int(count)))
    return pts


def main():
    src, out = sys.argv[1], sys.argv[2]
    pts = parse(src)
    by_type = defaultdict(lambda: [0, 0])
    by_file = defaultdict(lambda: defaultdict(lambda: [0, 0]))
    uncovered = defaultdict(list)
    for kv, n in pts:
        t = kv.get("page", "?").split("/")[0].replace("v_", "")
        f = kv.get("f", "?").split("/")[-1]
        by_type[t][0] += 1
        by_file[f][t][0] += 1
        if n > 0:
            by_type[t][1] += 1
            by_file[f][t][1] += 1
        elif len(uncovered[f]) < 12:
            uncovered[f].append({"type": t, "line": int(kv.get("l", 0)), "what": kv.get("o", "")})
    pct = lambda tot, hit: round(100.0 * hit / tot, 2) if tot else None
    rep = {
        "category": "simulation",
        "source": src,
        "note": "merged over every full-chip system test run on the coverage-instrumented ALBION_MIN simulator",
        "totals": {t: {"points": a, "hit": b, "percent": pct(a, b)} for t, (a, b) in sorted(by_type.items())},
        "files": {f: {t: {"points": a, "hit": b, "percent": pct(a, b)} for t, (a, b) in sorted(d.items())}
                  for f, d in sorted(by_file.items())},
        "uncovered_examples": uncovered,
    }
    json.dump(rep, open(out, "w"), indent=2)
    for t, v in rep["totals"].items():
        print(f"  {t:<8} {v['hit']:>6}/{v['points']:<6} {v['percent']}%")
    for f, d in rep["files"].items():
        print(f"  {f:<28} " + "  ".join(f"{t}:{v['percent']}%" for t, v in d.items()))


if __name__ == "__main__":
    main()
