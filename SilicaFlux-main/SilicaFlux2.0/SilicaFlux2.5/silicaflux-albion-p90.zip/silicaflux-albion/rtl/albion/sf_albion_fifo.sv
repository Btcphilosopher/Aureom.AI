// SilicaFlux Albion - synchronous FIFO with first-word fall-through head.
// push is ignored when full, pop is ignored when empty (callers count drops).
module sf_albion_fifo #(
  parameter int W     = 32,
  parameter int DEPTH = 4,
  parameter int CW    = $clog2(DEPTH + 1)
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          push,
  input  logic [W-1:0]  push_data,
  input  logic          pop,
  output logic [W-1:0]  head,
  output logic [CW-1:0] count,
  output logic          full,
  output logic          empty
);
  localparam int PW = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  logic [W-1:0]  mem [DEPTH];
  logic [PW-1:0] wp, rp;
  logic          do_push, do_pop;

  assign full    = (count == CW'(DEPTH));
  assign empty   = (count == '0);
  assign do_push = push && !full;
  assign do_pop  = pop && !empty;
  assign head    = mem[rp];

  function automatic logic [PW-1:0] inc(input logic [PW-1:0] p);
    inc = (p == PW'(DEPTH - 1)) ? '0 : p + 1'b1;
  endfunction

  always_ff @(posedge clk) begin
    if (do_push) mem[wp] <= push_data;
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      wp    <= '0;
      rp    <= '0;
      count <= '0;
    end else begin
      if (do_push) wp <= inc(wp);
      if (do_pop)  rp <= inc(rp);
      case ({do_push, do_pop})
        2'b10:   count <= count + 1'b1;
        2'b01:   count <= count - 1'b1;
        default: ;
      endcase
    end
  end

`ifdef FORMAL
  // occupancy invariants (proven by k-induction in formal/albion)
  always @* begin
    assert (count <= CW'(DEPTH));
    assert (full == (count == CW'(DEPTH)));
    assert (empty == (count == '0));
    if (DEPTH == 4) assert (((wp - rp) & 2'b11) == count[1:0]);
  end
`endif

`ifndef SYNTHESIS
  always_ff @(posedge clk) begin
    if (rst_n && count > CW'(DEPTH)) $error("fifo: count %0d exceeds depth %0d", count, DEPTH);
  end
`endif
endmodule
