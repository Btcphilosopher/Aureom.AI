// SilicaFlux Albion - protected DMA engine.
//
// * Two DataFabric master ports (read, write) and a DEPTH-entry prefetch FIFO, so a
//   copy between different slaves overlaps reads and writes. Each port has one
//   outstanding request and may re-issue in the same cycle its response arrives.
// * Every beat carries DMA.DOMAIN and is checked by the fabric permission unit; the
//   engine itself has no notion of what it may touch.
// * Deterministic error semantics: the transfer stops at the lowest-indexed failing
//   beat. BYTES_DONE = 4 * (index of first failing beat); ERR_ADDR is that beat's
//   address; words before it are written, words at/after it are not. Prefetch reads
//   beyond the failing beat may already have been issued (and counted by telemetry).
// * Modes: copy (src -> dst) and fill (pattern -> dst).
// * Parameter checks (BADPARAM, nothing transferred): LEN == 0, LEN % 4 != 0,
//   LEN > DMA_MAX_LEN, unaligned src/dst, or an address range that wraps 2^32.
module sf_albion_dma #(
  parameter int DEPTH = 4
) (
  input  logic        clk,
  input  logic        rst_n,
  // register port
  input  logic        rg_we,
  input  logic [11:0] rg_off,
  input  logic [31:0] rg_wdata,
  output logic [31:0] rg_rdata,
  output logic [2:0]  rg_err,
  // read port
  output logic        rd_req_valid,
  input  logic        rd_req_ready,
  output logic [31:0] rd_req_addr,
  input  logic        rd_rsp_valid,
  input  logic [31:0] rd_rsp_rdata,
  input  logic [2:0]  rd_rsp_err,
  // write port
  output logic        wr_req_valid,
  input  logic        wr_req_ready,
  output logic [31:0] wr_req_addr,
  output logic [31:0] wr_req_wdata,
  input  logic        wr_rsp_valid,
  input  logic [2:0]  wr_rsp_err,
  // domain for both ports
  output logic [3:0]  domain_o,
  // events
  output logic        ev_done_ok_o,
  output logic        ev_done_err_o,
  output logic        ev_bytes_o       // a 4-byte beat was written successfully
);
  localparam int CW = $clog2(DEPTH + 1);

  logic [31:0] r_src, r_dst, r_len, r_fill, r_err_addr, r_bytes, r_cycles;
  logic [3:0]  r_domain, r_err_code;
  logic        r_mode_fill, busy, done, error;

  // engine state
  logic [31:0] nwords, rd_idx, rd_rsp_idx, wr_idx, wr_rsp_idx;
  logic        rd_out, wr_out, stop_rd, stop_wr;
  logic        err_found;
  logic [31:0] err_idx;

  // ---------------------------------------------------------------- registers
  logic start, badparam;
  logic [32:0] src_end, dst_end;
  assign start   = rg_we && (rg_off == sf_albion_regs_pkg::DMA_CTRL) && rg_wdata[0] && !busy;
  assign src_end = {1'b0, r_src} + {1'b0, r_len};
  assign dst_end = {1'b0, r_dst} + {1'b0, r_len};
  assign badparam = (r_len == 32'h0) || (r_len[1:0] != 2'b00) || (r_len > sf_albion_regs_pkg::DMA_MAX_LEN) ||
                    (r_dst[1:0] != 2'b00) || dst_end[32] ||
                    (!rg_wdata[1] && ((r_src[1:0] != 2'b00) || src_end[32]));

  always_comb begin
    rg_rdata = 32'h0;
    rg_err   = sf_albion_regs_pkg::FE_OK;
    case (rg_off)
      sf_albion_regs_pkg::DMA_SRC:          rg_rdata = r_src;
      sf_albion_regs_pkg::DMA_DST:          rg_rdata = r_dst;
      sf_albion_regs_pkg::DMA_LEN:          rg_rdata = r_len;
      sf_albion_regs_pkg::DMA_DOMAIN:       rg_rdata = {28'h0, r_domain};
      sf_albion_regs_pkg::DMA_CTRL:         rg_rdata = {30'h0, r_mode_fill, 1'b0};
      sf_albion_regs_pkg::DMA_FILL_PATTERN: rg_rdata = r_fill;
      sf_albion_regs_pkg::DMA_STATUS:       rg_rdata = {20'h0, r_err_code, 5'h0, error, done, busy};
      sf_albion_regs_pkg::DMA_ERR_ADDR:     rg_rdata = r_err_addr;
      sf_albion_regs_pkg::DMA_BYTES_DONE:   rg_rdata = r_bytes;
      sf_albion_regs_pkg::DMA_CYCLES:       rg_rdata = r_cycles;
      default: rg_err = sf_albion_regs_pkg::FE_DECERR;
    endcase
    if (rg_we && rg_err == sf_albion_regs_pkg::FE_OK) begin
      if (rg_off == sf_albion_regs_pkg::DMA_STATUS || rg_off == sf_albion_regs_pkg::DMA_ERR_ADDR ||
          rg_off == sf_albion_regs_pkg::DMA_BYTES_DONE || rg_off == sf_albion_regs_pkg::DMA_CYCLES)
        rg_err = sf_albion_regs_pkg::FE_SLVERR;
      // programming registers are frozen while a transfer runs
      else if (busy && rg_off != sf_albion_regs_pkg::DMA_CTRL)
        rg_err = sf_albion_regs_pkg::FE_SLVERR;
    end
  end

  // ---------------------------------------------------------------- FIFO
  logic          f_push, f_pop, f_full, f_empty, f_flush;
  logic [31:0]   f_head;
  logic [CW-1:0] f_count;
  logic          f_rst_n;
  assign f_rst_n = rst_n && !f_flush;

  sf_albion_fifo #(.W(32), .DEPTH(DEPTH)) u_fifo (
    .clk(clk), .rst_n(f_rst_n), .push(f_push), .push_data(rd_rsp_rdata), .pop(f_pop),
    .head(f_head), .count(f_count), .full(f_full), .empty(f_empty));

  logic rd_fail, wr_fail;
  assign rd_fail = rd_rsp_valid && (rd_rsp_err != sf_albion_regs_pkg::FE_OK);
  assign wr_fail = wr_rsp_valid && (wr_rsp_err != sf_albion_regs_pkg::FE_OK);

  // ---------------------------------------------------------------- read side
  logic rd_room;
  assign rd_room      = (32'(f_count) + 32'(rd_out)) < 32'(DEPTH);
  // never issue in the cycle a read fails (keeps beat indices aligned) or while the
  // FIFO is being flushed at START
  assign rd_req_valid = busy && !f_flush && !r_mode_fill && !stop_rd && !rd_fail && (rd_idx < nwords) &&
                        (!rd_out || rd_rsp_valid) && rd_room;
  assign rd_req_addr  = r_src + {rd_idx[29:0], 2'b00};
  assign f_push       = rd_rsp_valid && (rd_rsp_err == sf_albion_regs_pkg::FE_OK) && !stop_wr && !stop_rd;

  // ---------------------------------------------------------------- write side
  logic wr_have_data;
  assign wr_have_data = r_mode_fill || !f_empty;
  assign wr_req_valid = busy && !f_flush && !stop_wr && !wr_fail && wr_have_data && (wr_idx < nwords) &&
                        (!wr_out || wr_rsp_valid);
  assign wr_req_addr  = r_dst + {wr_idx[29:0], 2'b00};
  assign wr_req_wdata = r_mode_fill ? r_fill : f_head;
  assign f_pop        = wr_req_valid && wr_req_ready && !r_mode_fill;

  assign domain_o     = r_domain;

  logic unused_ff;
  assign unused_ff = f_full;

  // ---------------------------------------------------------------- error mapping
  function automatic logic [3:0] map_err(input logic [2:0] fe);
    case (fe)
      sf_albion_regs_pkg::FE_DECERR:  map_err = sf_albion_regs_pkg::DMAE_DECERR;
      sf_albion_regs_pkg::FE_PERM:    map_err = sf_albion_regs_pkg::DMAE_PERM;
      sf_albion_regs_pkg::FE_ECC_UE:  map_err = sf_albion_regs_pkg::DMAE_ECC_UE;
      sf_albion_regs_pkg::FE_HOSTERR: map_err = sf_albion_regs_pkg::DMAE_HOSTERR;
      default:                        map_err = sf_albion_regs_pkg::DMAE_SLVERR;
    endcase
  endfunction


  // completion
  logic finishing;
  always_comb begin
    logic rd_out_n, wr_out_n, stop_wr_n, stop_rd_n;
    rd_out_n  = (rd_out && !rd_rsp_valid) || (rd_req_valid && rd_req_ready);
    wr_out_n  = (wr_out && !wr_rsp_valid) || (wr_req_valid && wr_req_ready);
    stop_wr_n = stop_wr || wr_fail;
    stop_rd_n = stop_rd || rd_fail || wr_fail;
    finishing = 1'b0;
    if (busy && !rd_out_n && !wr_out_n) begin
      if (stop_wr_n) finishing = 1'b1;                                         // write failed
      else if (!r_mode_fill && stop_rd_n && f_empty && !f_push) finishing = 1'b1; // read failed, drained
      else if ((wr_rsp_idx + 32'(wr_rsp_valid && !wr_fail)) == nwords) finishing = 1'b1;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      r_src <= '0; r_dst <= '0; r_len <= '0; r_fill <= '0; r_domain <= '0; r_mode_fill <= 1'b0;
      r_err_addr <= '0; r_bytes <= '0; r_cycles <= '0; r_err_code <= '0;
      busy <= 1'b0; done <= 1'b0; error <= 1'b0;
      nwords <= '0; rd_idx <= '0; rd_rsp_idx <= '0; wr_idx <= '0; wr_rsp_idx <= '0;
      rd_out <= 1'b0; wr_out <= 1'b0; stop_rd <= 1'b0; stop_wr <= 1'b0;
      err_found <= 1'b0; err_idx <= '0;
      f_flush <= 1'b0;
    end else begin
      f_flush <= 1'b0;
      if (rg_we && rg_err == sf_albion_regs_pkg::FE_OK && !busy) begin
        case (rg_off)
          sf_albion_regs_pkg::DMA_SRC:          r_src    <= rg_wdata;
          sf_albion_regs_pkg::DMA_DST:          r_dst    <= rg_wdata;
          sf_albion_regs_pkg::DMA_LEN:          r_len    <= rg_wdata;
          sf_albion_regs_pkg::DMA_DOMAIN:       r_domain <= rg_wdata[3:0];
          sf_albion_regs_pkg::DMA_FILL_PATTERN: r_fill   <= rg_wdata;
          default: ;
        endcase
      end

      if (start) begin
        r_mode_fill <= rg_wdata[1];
        done        <= 1'b0;
        error       <= 1'b0;
        r_err_code  <= sf_albion_regs_pkg::DMAE_NONE;
        r_err_addr  <= 32'h0;
        r_bytes     <= 32'h0;
        r_cycles    <= 32'h0;
        rd_idx <= '0; rd_rsp_idx <= '0; wr_idx <= '0; wr_rsp_idx <= '0;
        rd_out <= 1'b0; wr_out <= 1'b0; stop_rd <= 1'b0; stop_wr <= 1'b0;
        err_found <= 1'b0; err_idx <= '0;
        f_flush <= 1'b1;
        if (badparam) begin
          done       <= 1'b1;
          error      <= 1'b1;
          r_err_code <= sf_albion_regs_pkg::DMAE_BADPARAM;
        end else begin
          busy   <= 1'b1;
          nwords <= {2'b00, r_len[31:2]};
        end
      end else if (busy) begin
        r_cycles <= r_cycles + 32'd1;
        // read side
        if (rd_req_valid && rd_req_ready) begin
          rd_idx <= rd_idx + 32'd1;
          rd_out <= 1'b1;
        end else if (rd_rsp_valid) rd_out <= 1'b0;
        if (rd_rsp_valid) begin
          rd_rsp_idx <= rd_rsp_idx + 32'd1;
          if (rd_fail) begin
            stop_rd <= 1'b1;
            if (!err_found || rd_rsp_idx < err_idx) begin
              err_found  <= 1'b1;
              err_idx    <= rd_rsp_idx;
              r_err_code <= map_err(rd_rsp_err);
              r_err_addr <= r_src + {rd_rsp_idx[29:0], 2'b00};
            end
          end
        end
        // write side
        if (wr_req_valid && wr_req_ready) begin
          wr_idx <= wr_idx + 32'd1;
          wr_out <= 1'b1;
        end else if (wr_rsp_valid) wr_out <= 1'b0;
        if (wr_rsp_valid) begin
          if (wr_fail) begin
            stop_wr <= 1'b1;
            stop_rd <= 1'b1;
            f_flush <= 1'b1;
            // a write failure is always at a lower index than any pending read failure
            err_found  <= 1'b1;
            err_idx    <= wr_rsp_idx;
            r_err_code <= map_err(wr_rsp_err);
            r_err_addr <= r_dst + {wr_rsp_idx[29:0], 2'b00};
          end else begin
            wr_rsp_idx <= wr_rsp_idx + 32'd1;
            r_bytes    <= r_bytes + 32'd4;
          end
        end
        if (finishing) begin
          busy  <= 1'b0;
          done  <= 1'b1;
          error <= err_found || rd_fail || wr_fail;
        end
      end
    end
  end

`ifdef FORMAL
  // transfer-bound invariants (bounded proof from reset in formal/albion)
  always @* begin
    if (busy) begin
      if (wr_req_valid) begin
        assert (wr_idx < nwords);
        assert (wr_req_addr - r_dst < r_len);
      end
      if (rd_req_valid) begin
        assert (!r_mode_fill);
        assert (rd_req_addr - r_src < r_len);
      end
      if (!r_mode_fill) assert (wr_idx <= rd_rsp_idx);
      assert (32'(f_count) + 32'(rd_out) <= 32'(DEPTH));
    end
  end
`endif

  assign ev_done_ok_o  = busy && finishing && !(err_found || rd_fail || wr_fail);
  assign ev_done_err_o = (busy && finishing && (err_found || rd_fail || wr_fail)) || (start && badparam);
  assign ev_bytes_o    = wr_rsp_valid && !wr_fail;
endmodule
