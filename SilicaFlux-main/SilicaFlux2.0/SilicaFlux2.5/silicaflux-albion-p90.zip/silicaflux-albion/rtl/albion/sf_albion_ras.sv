// SilicaFlux Albion - RAS: SECDED error log, CE/UE counters, error injection.
module sf_albion_ras #(
  parameter int NB         = 4,
  parameter int BANK_BYTES = 16384,
  parameter int AW         = $clog2(BANK_BYTES / 4)
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          rg_we,
  input  logic [11:0]   rg_off,
  input  logic [31:0]   rg_wdata,
  output logic [31:0]   rg_rdata,
  output logic [2:0]    rg_err,
  // per-bank ECC events
  input  logic [NB-1:0]     ce_i,
  input  logic [NB-1:0]     ue_i,
  input  logic [NB*7-1:0]   syn_i,
  input  logic [NB*AW-1:0]  word_i,
  input  logic [NB*2-1:0]   master_i,
  input  logic [NB*4-1:0]   domain_i,
  input  logic [NB-1:0]     init_done_i,
  // injection to banks
  output logic [NB-1:0]     inj_arm_o,
  output logic [AW-1:0]     inj_word_o,
  output logic [38:0]       inj_mask_o,
  input  logic [NB-1:0]     inj_hit_i
);
  localparam int BANK_SHIFT = $clog2(BANK_BYTES);

  logic        err_valid, err_ovf;
  logic [3:0]  err_type;
  logic [31:0] err_addr;
  logic [6:0]  err_syn;
  logic [11:0] err_src;
  logic [31:0] ce_count, ue_count;
  logic        inj_armed, inj_done;
  logic [3:0]  inj_bank;
  logic [31:0] inj_addr, inj_lo;
  logic [6:0]  inj_hi;

  always_comb begin
    rg_rdata = 32'h0;
    rg_err   = sf_albion_regs_pkg::FE_OK;
    case (rg_off)
      sf_albion_regs_pkg::RAS_ERR_STATUS:   rg_rdata = {24'h0, err_type, 2'b00, err_ovf, err_valid};
      sf_albion_regs_pkg::RAS_ERR_ADDR:     rg_rdata = err_addr;
      sf_albion_regs_pkg::RAS_ERR_SYNDROME: rg_rdata = {25'h0, err_syn};
      sf_albion_regs_pkg::RAS_ERR_SOURCE:   rg_rdata = {20'h0, err_src};
      sf_albion_regs_pkg::RAS_ERR_CLEAR:    rg_rdata = 32'h0;
      sf_albion_regs_pkg::RAS_CE_COUNT:     rg_rdata = ce_count;
      sf_albion_regs_pkg::RAS_UE_COUNT:     rg_rdata = ue_count;
      sf_albion_regs_pkg::RAS_INJ_CTRL:     rg_rdata = {24'h0, inj_bank, 2'b00, inj_done, inj_armed};
      sf_albion_regs_pkg::RAS_INJ_ADDR:     rg_rdata = inj_addr;
      sf_albion_regs_pkg::RAS_INJ_MASK_LO:  rg_rdata = inj_lo;
      sf_albion_regs_pkg::RAS_INJ_MASK_HI:  rg_rdata = {25'h0, inj_hi};
      sf_albion_regs_pkg::RAS_SCRUB_STATUS: rg_rdata = {31'h0, &init_done_i};
      default: rg_err = sf_albion_regs_pkg::FE_DECERR;
    endcase
    if (rg_we && rg_err == sf_albion_regs_pkg::FE_OK &&
        (rg_off == sf_albion_regs_pkg::RAS_ERR_STATUS || rg_off == sf_albion_regs_pkg::RAS_ERR_ADDR ||
         rg_off == sf_albion_regs_pkg::RAS_ERR_SYNDROME || rg_off == sf_albion_regs_pkg::RAS_ERR_SOURCE ||
         rg_off == sf_albion_regs_pkg::RAS_CE_COUNT || rg_off == sf_albion_regs_pkg::RAS_UE_COUNT ||
         rg_off == sf_albion_regs_pkg::RAS_SCRUB_STATUS))
      rg_err = sf_albion_regs_pkg::FE_SLVERR;
  end

  // first (lowest-numbered) bank reporting an event this cycle is logged
  logic        ev_any;
  integer          ev_bank;
  logic        ev_ue;
  integer          n_ce, n_ue, n_ev;
  always_comb begin
    ev_any  = 1'b0;
    ev_bank = 0;
    ev_ue   = 1'b0;
    n_ce    = 0;
    n_ue    = 0;
    for (int b = NB - 1; b >= 0; b--) begin
      if (ce_i[b] || ue_i[b]) begin
        ev_any  = 1'b1;
        ev_bank = b;
        ev_ue   = ue_i[b];
      end
    end
    for (int b = 0; b < NB; b++) begin
      n_ce = n_ce + 32'(ce_i[b]);
      n_ue = n_ue + 32'(ue_i[b]);
    end
    n_ev = n_ce + n_ue;
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      err_valid <= 1'b0; err_ovf <= 1'b0; err_type <= '0; err_addr <= '0; err_syn <= '0; err_src <= '0;
      ce_count <= '0; ue_count <= '0;
      inj_armed <= 1'b0; inj_done <= 1'b0; inj_bank <= '0; inj_addr <= '0; inj_lo <= '0; inj_hi <= '0;
    end else begin
      if (rg_we && rg_err == sf_albion_regs_pkg::FE_OK) begin
        case (rg_off)
          sf_albion_regs_pkg::RAS_ERR_CLEAR:   if (rg_wdata[0]) begin err_valid <= 1'b0; err_ovf <= 1'b0; end
          sf_albion_regs_pkg::RAS_INJ_CTRL:    begin
            inj_armed <= rg_wdata[0];
            inj_bank  <= rg_wdata[7:4];
            if (rg_wdata[0]) inj_done <= 1'b0;
          end
          sf_albion_regs_pkg::RAS_INJ_ADDR:    inj_addr <= rg_wdata;
          sf_albion_regs_pkg::RAS_INJ_MASK_LO: inj_lo   <= rg_wdata;
          sf_albion_regs_pkg::RAS_INJ_MASK_HI: inj_hi   <= rg_wdata[6:0];
          default: ;
        endcase
      end
      if (|inj_hit_i) begin
        inj_armed <= 1'b0;
        inj_done  <= 1'b1;
      end
      if (ev_any) begin
        if (err_valid || n_ev > 1) err_ovf <= 1'b1;
        if (!err_valid) begin
          err_valid <= 1'b1;
          err_type  <= ev_ue ? 4'd2 : 4'd1;
          err_addr  <= (32'(ev_bank) << BANK_SHIFT) | (32'(word_i[ev_bank*AW +: AW]) << 2);
          err_syn   <= syn_i[ev_bank*7 +: 7];
          err_src   <= {domain_i[ev_bank*4 +: 4], 2'b00, master_i[ev_bank*2 +: 2], 4'(ev_bank)};
        end
      end
      if (n_ce != 0 && ce_count != 32'hFFFF_FFFF) ce_count <= ce_count + 32'(n_ce);
      if (n_ue != 0 && ue_count != 32'hFFFF_FFFF) ue_count <= ue_count + 32'(n_ue);
    end
  end

  always_comb begin
    for (int b = 0; b < NB; b++) inj_arm_o[b] = inj_armed && (32'(inj_bank) == b);
  end
  assign inj_word_o = AW'(inj_addr);
  assign inj_mask_o = {inj_hi, inj_lo};
endmodule
