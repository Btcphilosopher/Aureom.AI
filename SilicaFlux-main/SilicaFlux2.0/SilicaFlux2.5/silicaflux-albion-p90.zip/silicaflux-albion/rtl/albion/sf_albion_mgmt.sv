// SilicaFlux Albion - management page: identity, configuration, boot control,
// firmware status and the host<->firmware mailbox (command + completion queues).
//
// Register access rules (writer column of the register map) are enforced here by
// master id; violations return SLVERR. Unpopulated offsets return DECERR.
module sf_albion_mgmt #(
  parameter int          CONFIG      = 0,
  parameter int          NB          = 4,
  parameter int          BANK_BYTES  = 16384,
  parameter int          NW          = 8,
  parameter int          QDEPTH      = 4,
  parameter logic [31:0] FEAT_IMPL   = 32'h0,
  parameter logic [31:0] FEAT_REQ    = 32'h0,
  parameter logic [31:0] BUILD_ID    = 32'h0
) (
  input  logic        clk,
  input  logic        rst_n,
  // register port
  input  logic        rg_we,
  input  logic        rg_re,
  input  logic [11:0] rg_off,
  input  logic [31:0] rg_wdata,
  input  logic [1:0]  rg_master,
  output logic [31:0] rg_rdata,
  output logic [2:0]  rg_err,
  // status inputs
  input  logic        init_done_i,
  input  logic        dbg_strap_i,
  // control outputs
  output logic        core_run_o,
  output logic        boot_lock_o,
  output logic        boot_mode_o,
  output logic        soft_reset_req_o,
  output logic        host_irq_o,
  output logic        cmdq_nonempty_o,
  // telemetry events
  output logic        ev_cmd_submit_o,
  output logic        ev_cpl_post_o,
  output logic        ev_cmd_drop_o
);
  localparam int CQW = $clog2(QDEPTH + 1);
  localparam logic [1:0] MC = 2'(sf_albion_regs_pkg::M_CORE);
  localparam logic [1:0] MH = 2'(sf_albion_regs_pkg::M_HOST);

  logic        core_run, boot_lock;
  logic [31:0] fw_status, fw_version, fw_heartbeat, scratch, host_irq_en;
  logic        fw_attn;
  logic [255:0] hcmd;
  logic [127:0] fcpl;
  logic        cmd_ovf, cpl_ovf;

  // queues
  logic           cmd_push, cmd_pop, cmd_full, cmd_empty;
  logic [255:0]   cmd_head;
  logic [CQW-1:0] cmd_count;
  logic           cpl_push, cpl_pop, cpl_full, cpl_empty;
  logic [127:0]   cpl_head;
  logic [CQW-1:0] cpl_count;

  sf_albion_fifo #(.W(256), .DEPTH(QDEPTH)) u_cmdq (
    .clk(clk), .rst_n(rst_n), .push(cmd_push), .push_data(hcmd), .pop(cmd_pop),
    .head(cmd_head), .count(cmd_count), .full(cmd_full), .empty(cmd_empty));
  sf_albion_fifo #(.W(128), .DEPTH(QDEPTH)) u_cplq (
    .clk(clk), .rst_n(rst_n), .push(cpl_push), .push_data(fcpl), .pop(cpl_pop),
    .head(cpl_head), .count(cpl_count), .full(cpl_full), .empty(cpl_empty));

  // ---------------------------------------------------------------- write decode
  logic wr_ok;     // write accepted
  logic is_core, is_host;
  assign is_core = (rg_master == MC);
  assign is_host = (rg_master == MH);

  // offsets
  localparam logic [11:0] O_CHIP = sf_albion_regs_pkg::MGMT_CHIP_ID;
  localparam logic [11:0] O_VER  = sf_albion_regs_pkg::MGMT_VERSION;
  localparam logic [11:0] O_CFG  = sf_albion_regs_pkg::MGMT_CONFIG_ID;
  localparam logic [11:0] O_FI   = sf_albion_regs_pkg::MGMT_FEAT_IMPL;
  localparam logic [11:0] O_FR   = sf_albion_regs_pkg::MGMT_FEAT_REQ;
  localparam logic [11:0] O_FU   = sf_albion_regs_pkg::MGMT_FEAT_UNAVAIL;
  localparam logic [11:0] O_NB   = sf_albion_regs_pkg::MGMT_SRAM_BANKS;
  localparam logic [11:0] O_BB   = sf_albion_regs_pkg::MGMT_SRAM_BANK_BYTES;
  localparam logic [11:0] O_NW   = sf_albion_regs_pkg::MGMT_NUM_WINDOWS;
  localparam logic [11:0] O_CQD  = sf_albion_regs_pkg::MGMT_CMDQ_DEPTH;
  localparam logic [11:0] O_PQD  = sf_albion_regs_pkg::MGMT_CPLQ_DEPTH;
  localparam logic [11:0] O_ND   = sf_albion_regs_pkg::MGMT_NUM_DOMAINS;
  localparam logic [11:0] O_BID  = sf_albion_regs_pkg::MGMT_BUILD_ID;
  localparam logic [11:0] O_DST  = sf_albion_regs_pkg::MGMT_DEV_STATUS;
  localparam logic [11:0] O_CC   = sf_albion_regs_pkg::MGMT_CORE_CTRL;
  localparam logic [11:0] O_BL   = sf_albion_regs_pkg::MGMT_BOOT_LOCK;
  localparam logic [11:0] O_SR   = sf_albion_regs_pkg::MGMT_SOFT_RESET;
  localparam logic [11:0] O_FS   = sf_albion_regs_pkg::MGMT_FW_STATUS;
  localparam logic [11:0] O_FV   = sf_albion_regs_pkg::MGMT_FW_VERSION;
  localparam logic [11:0] O_HB   = sf_albion_regs_pkg::MGMT_FW_HEARTBEAT;
  localparam logic [11:0] O_SC   = sf_albion_regs_pkg::MGMT_SCRATCH;
  localparam logic [11:0] O_HIS  = sf_albion_regs_pkg::MGMT_HOST_IRQ_STATUS;
  localparam logic [11:0] O_HIE  = sf_albion_regs_pkg::MGMT_HOST_IRQ_ENABLE;
  localparam logic [11:0] O_FA   = sf_albion_regs_pkg::MGMT_FW_ATTN;
  localparam logic [11:0] O_HC0  = sf_albion_regs_pkg::MGMT_HCMD_W0;
  localparam logic [11:0] O_HSUB = sf_albion_regs_pkg::MGMT_HCMD_SUBMIT;
  localparam logic [11:0] O_HQS  = sf_albion_regs_pkg::MGMT_HCMDQ_STATUS;
  localparam logic [11:0] O_HQC  = sf_albion_regs_pkg::MGMT_HCMDQ_CLEAR;
  localparam logic [11:0] O_HP0  = sf_albion_regs_pkg::MGMT_HCPL_W0;
  localparam logic [11:0] O_HPOP = sf_albion_regs_pkg::MGMT_HCPL_POP;
  localparam logic [11:0] O_HPS  = sf_albion_regs_pkg::MGMT_HCPLQ_STATUS;
  localparam logic [11:0] O_FC0  = sf_albion_regs_pkg::MGMT_FCMD_W0;
  localparam logic [11:0] O_FPOP = sf_albion_regs_pkg::MGMT_FCMD_POP;
  localparam logic [11:0] O_FQS  = sf_albion_regs_pkg::MGMT_FCMDQ_STATUS;
  localparam logic [11:0] O_FP0  = sf_albion_regs_pkg::MGMT_FCPL_W0;
  localparam logic [11:0] O_FPSH = sf_albion_regs_pkg::MGMT_FCPL_PUSH;
  localparam logic [11:0] O_FPS  = sf_albion_regs_pkg::MGMT_FCPLQ_STATUS;

  logic in_hcmd, in_hcpl, in_fcmd, in_fcpl;
  assign in_hcmd = (rg_off >= O_HC0) && (rg_off < O_HC0 + 12'h020);
  assign in_hcpl = (rg_off >= O_HP0) && (rg_off < O_HP0 + 12'h010);
  assign in_fcmd = (rg_off >= O_FC0) && (rg_off < O_FC0 + 12'h020);
  assign in_fcpl = (rg_off >= O_FP0) && (rg_off < O_FP0 + 12'h010);

  logic [31:0] dev_status;
  assign boot_mode_o = init_done_i && !core_run && !boot_lock;
  assign dev_status  = {27'h0, boot_mode_o, dbg_strap_i, boot_lock, core_run, init_done_i};

  logic [31:0] q_status_cmd, q_status_cpl;
  assign q_status_cmd = {15'h0, cmd_ovf, 6'h0, cmd_empty, cmd_full, 8'(cmd_count)};
  assign q_status_cpl = {15'h0, cpl_ovf, 6'h0, cpl_empty, cpl_full, 8'(cpl_count)};

  logic [31:0] host_irq_status;
  assign host_irq_status = {30'h0, fw_attn, !cpl_empty};

  // read mux + legality
  always_comb begin
    logic dec, wlegal;
    dec      = 1'b1;
    wlegal   = 1'b0;
    rg_rdata = 32'h0;
    if (in_hcmd) begin rg_rdata = hcmd[rg_off[4:2]*32 +: 32]; wlegal = is_host; end
    else if (in_hcpl) begin rg_rdata = cpl_head[rg_off[3:2]*32 +: 32]; end
    else if (in_fcmd) begin rg_rdata = cmd_head[rg_off[4:2]*32 +: 32]; end
    else if (in_fcpl) begin rg_rdata = fcpl[rg_off[3:2]*32 +: 32]; wlegal = is_core; end
    else begin
      case (rg_off)
        O_CHIP: rg_rdata = sf_albion_regs_pkg::CHIP_ID;
        O_VER:  rg_rdata = sf_albion_regs_pkg::RTL_VERSION;
        O_CFG:  rg_rdata = 32'(CONFIG);
        O_FI:   rg_rdata = FEAT_IMPL;
        O_FR:   rg_rdata = FEAT_REQ;
        O_FU:   rg_rdata = FEAT_REQ & ~FEAT_IMPL;
        O_NB:   rg_rdata = 32'(NB);
        O_BB:   rg_rdata = 32'(BANK_BYTES);
        O_NW:   rg_rdata = 32'(NW);
        O_CQD:  rg_rdata = 32'(QDEPTH);
        O_PQD:  rg_rdata = 32'(QDEPTH);
        O_ND:   rg_rdata = sf_albion_regs_pkg::NUM_DOMAINS;
        O_BID:  rg_rdata = BUILD_ID;
        O_DST:  rg_rdata = dev_status;
        O_CC:   begin rg_rdata = {31'h0, core_run};  wlegal = is_host; end
        O_BL:   begin rg_rdata = {31'h0, boot_lock}; wlegal = is_core; end
        O_SR:   begin rg_rdata = 32'h0; wlegal = is_host; end
        O_FS:   begin rg_rdata = fw_status;    wlegal = is_core; end
        O_FV:   begin rg_rdata = fw_version;   wlegal = is_core; end
        O_HB:   begin rg_rdata = fw_heartbeat; wlegal = is_core; end
        O_SC:   begin rg_rdata = scratch;      wlegal = 1'b1; end
        O_HIS:  rg_rdata = host_irq_status;
        O_HIE:  begin rg_rdata = host_irq_en;  wlegal = is_host; end
        O_FA:   begin rg_rdata = {31'h0, fw_attn}; wlegal = is_core; end
        O_HSUB: begin rg_rdata = 32'h0; wlegal = is_host; end
        O_HQS:  rg_rdata = q_status_cmd;
        O_HQC:  begin rg_rdata = 32'h0; wlegal = is_host; end
        O_HPOP: begin rg_rdata = 32'h0; wlegal = is_host; end
        O_HPS:  rg_rdata = q_status_cpl;
        O_FPOP: begin rg_rdata = 32'h0; wlegal = is_core; end
        O_FQS:  rg_rdata = q_status_cmd;
        O_FPSH: begin rg_rdata = 32'h0; wlegal = is_core; end
        O_FPS:  rg_rdata = q_status_cpl;
        default: dec = 1'b0;
      endcase
    end
    if (!dec)                  rg_err = sf_albion_regs_pkg::FE_DECERR;
    else if (rg_we && !wlegal) rg_err = sf_albion_regs_pkg::FE_SLVERR;
    else                       rg_err = sf_albion_regs_pkg::FE_OK;
  end

  assign wr_ok = rg_we && (rg_err == sf_albion_regs_pkg::FE_OK);

  // ---------------------------------------------------------------- queue control
  assign cmd_push = wr_ok && (rg_off == O_HSUB);
  assign cmd_pop  = wr_ok && (rg_off == O_FPOP);
  assign cpl_push = wr_ok && (rg_off == O_FPSH);
  assign cpl_pop  = wr_ok && (rg_off == O_HPOP);

  assign ev_cmd_submit_o = cmd_push && !cmd_full;
  assign ev_cmd_drop_o   = cmd_push && cmd_full;
  assign ev_cpl_post_o   = cpl_push && !cpl_full;

  // ---------------------------------------------------------------- registers
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      core_run     <= 1'b0;
      boot_lock    <= 1'b0;
      fw_status    <= 32'h0;
      fw_version   <= 32'h0;
      fw_heartbeat <= 32'h0;
      scratch      <= 32'h0;
      host_irq_en  <= 32'h0;
      fw_attn      <= 1'b0;
      hcmd         <= '0;
      fcpl         <= '0;
      cmd_ovf      <= 1'b0;
      cpl_ovf      <= 1'b0;
    end else begin
      if (wr_ok) begin
        if (in_hcmd) hcmd[rg_off[4:2]*32 +: 32] <= rg_wdata;
        if (in_fcpl) fcpl[rg_off[3:2]*32 +: 32] <= rg_wdata;
        case (rg_off)
          O_CC:  if (!boot_lock) core_run <= rg_wdata[0];
          O_BL:  if (rg_wdata[0]) boot_lock <= 1'b1;
          O_FS:  fw_status    <= rg_wdata;
          O_FV:  fw_version   <= rg_wdata;
          O_HB:  fw_heartbeat <= rg_wdata;
          O_SC:  scratch      <= rg_wdata;
          O_HIE: host_irq_en  <= rg_wdata;
          O_FA:  fw_attn      <= rg_wdata[0];
          O_HQC: if (rg_wdata[0]) cmd_ovf <= 1'b0;
          default: ;
        endcase
      end
      if (cmd_push && cmd_full) cmd_ovf <= 1'b1;
      if (cpl_push && cpl_full) cpl_ovf <= 1'b1;
    end
  end

  assign soft_reset_req_o = wr_ok && (rg_off == O_SR) && (rg_wdata == sf_albion_regs_pkg::SOFT_RESET_MAGIC);
  assign core_run_o       = core_run;
  assign boot_lock_o      = boot_lock;
  assign host_irq_o       = |(host_irq_status & host_irq_en);
  assign cmdq_nonempty_o  = !cmd_empty;

  logic unused;
  assign unused = rg_re;
endmodule
