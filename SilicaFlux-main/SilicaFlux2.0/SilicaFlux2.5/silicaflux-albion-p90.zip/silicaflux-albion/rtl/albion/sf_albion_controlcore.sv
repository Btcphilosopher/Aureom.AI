// SilicaFlux Albion - ControlCore: RV32I + Zicsr, machine mode only, multi-cycle.
//
// * Single DataFabric master port shared by instruction fetch and load/store
//   (one outstanding request).
// * Precise traps: instruction address misaligned (0), instruction access fault (1),
//   illegal instruction (2), breakpoint (3), load misaligned (4), load access
//   fault (5), store misaligned (6), store access fault (7), ecall from M (11),
//   machine external interrupt (0x8000000B).
// * CSRs: mstatus(MIE,MPIE; MPP=11), misa, mie(MEIE), mip(MEIP), mtvec (direct),
//   mscratch, mepc, mcause, mtval, mcycle[h], minstret[h], cycle/instret[h]
//   read-only aliases, mvendorid, marchid, mimpid, mhartid.
// * WFI stalls until (mip & mie) != 0, independent of mstatus.MIE (spec behaviour).
// * Retirement trace port (one pulse per retired instruction or taken trap) is used
//   by the lock-step comparison against tools/albion_iss.
module sf_albion_controlcore #(
  parameter logic [31:0] RESET_PC = 32'h0000_0000,
  parameter logic [31:0] MIMPID   = 32'h0000_0090
) (
  input  logic        clk,
  input  logic        rst_n,
  // fabric master
  output logic        req_valid,
  input  logic        req_ready,
  output logic [31:0] req_addr,
  output logic        req_we,
  output logic [31:0] req_wdata,
  output logic [3:0]  req_wstrb,
  input  logic        rsp_valid,
  input  logic [31:0] rsp_rdata,
  input  logic [2:0]  rsp_err,
  // interrupt
  input  logic        irq_ext_i,
  // trace / telemetry
  output logic        trace_valid_o,
  output logic [31:0] trace_pc_o,
  output logic [31:0] trace_insn_o,
  output logic        trace_rd_we_o,
  output logic [4:0]  trace_rd_o,
  output logic [31:0] trace_rd_wdata_o,
  output logic        trace_trap_o,
  output logic [31:0] trace_cause_o,
  output logic        instret_o,
  output logic        sleep_o
);
  typedef enum logic [2:0] {S_FETCH, S_FETCH_WAIT, S_EXEC, S_MEM, S_MEM_WAIT, S_WFI} state_t;
  state_t state;

  logic [31:0] pc, ir;
  logic [31:0] rf [32];

  // CSRs
  logic        mstatus_mie, mstatus_mpie, mie_meie;
  logic [31:0] mtvec, mscratch, mepc, mcause, mtval;
  logic [63:0] mcycle, minstret;

  // memory op registers
  logic [31:0] mem_addr, mem_wdata;
  logic [3:0]  mem_wstrb;
  logic        mem_we;
  logic [4:0]  mem_rd;
  logic [2:0]  mem_f3;

  // ---------------------------------------------------------------- decode
  logic [6:0]  opcode;
  logic [4:0]  rd, rs1, rs2;
  logic [2:0]  f3;
  logic [6:0]  f7;
  logic [31:0] imm_i, imm_s, imm_b, imm_u, imm_j;
  logic [31:0] x1v, x2v;

  assign opcode = ir[6:0];
  assign rd     = ir[11:7];
  assign f3     = ir[14:12];
  assign rs1    = ir[19:15];
  assign rs2    = ir[24:20];
  assign f7     = ir[31:25];
  assign imm_i  = {{20{ir[31]}}, ir[31:20]};
  assign imm_s  = {{20{ir[31]}}, ir[31:25], ir[11:7]};
  assign imm_b  = {{19{ir[31]}}, ir[31], ir[7], ir[30:25], ir[11:8], 1'b0};
  assign imm_u  = {ir[31:12], 12'h000};
  assign imm_j  = {{11{ir[31]}}, ir[31], ir[19:12], ir[20], ir[30:21], 1'b0};
  assign x1v    = (rs1 == 5'd0) ? 32'h0 : rf[rs1];
  assign x2v    = (rs2 == 5'd0) ? 32'h0 : rf[rs2];

  localparam logic [6:0] OP_LUI = 7'b0110111, OP_AUIPC = 7'b0010111, OP_JAL = 7'b1101111,
                         OP_JALR = 7'b1100111, OP_BRANCH = 7'b1100011, OP_LOAD = 7'b0000011,
                         OP_STORE = 7'b0100011, OP_IMM = 7'b0010011, OP_REG = 7'b0110011,
                         OP_FENCE = 7'b0001111, OP_SYSTEM = 7'b1110011;

  // ---------------------------------------------------------------- CSR read
  logic [11:0] csr_addr;
  logic [31:0] csr_rdata;
  logic        csr_exists;
  logic [31:0] mstatus_v, mip_v, mie_v;

  assign csr_addr  = ir[31:20];
  assign mstatus_v = {19'h0, 2'b11, 3'b000, mstatus_mpie, 3'b000, mstatus_mie, 3'b000};
  assign mip_v     = {20'h0, irq_ext_i, 11'h0};
  assign mie_v     = {20'h0, mie_meie, 11'h0};

  always_comb begin
    csr_exists = 1'b1;
    case (csr_addr)
      12'h300: csr_rdata = mstatus_v;
      12'h301: csr_rdata = 32'h4000_0100;          // misa: RV32I
      12'h304: csr_rdata = mie_v;
      12'h305: csr_rdata = mtvec;
      12'h340: csr_rdata = mscratch;
      12'h341: csr_rdata = mepc;
      12'h342: csr_rdata = mcause;
      12'h343: csr_rdata = mtval;
      12'h344: csr_rdata = mip_v;
      12'hB00, 12'hC00: csr_rdata = mcycle[31:0];
      12'hB02, 12'hC02: csr_rdata = minstret[31:0];
      12'hB80, 12'hC80: csr_rdata = mcycle[63:32];
      12'hB82, 12'hC82: csr_rdata = minstret[63:32];
      12'hF11: csr_rdata = 32'h0;                  // mvendorid
      12'hF12: csr_rdata = 32'h0;                  // marchid
      12'hF13: csr_rdata = MIMPID;                 // mimpid
      12'hF14: csr_rdata = 32'h0;                  // mhartid
      default: begin csr_rdata = 32'h0; csr_exists = 1'b0; end
    endcase
  end

  // ---------------------------------------------------------------- execute (combinational)
  logic        ex_illegal, ex_rd_we, ex_jump, ex_mem, ex_mem_we, ex_ecall, ex_ebreak, ex_mret, ex_wfi;
  logic        ex_csr_we, ex_misalign_mem, ex_misalign_pc;
  logic [31:0] ex_rd_val, ex_next_pc, ex_mem_addr, ex_csr_wval;
  logic [31:0] alu_b, alu_out;
  logic        br_take;

  always_comb begin
    logic [31:0] a, b;
    a = x1v;
    b = (opcode == OP_REG) ? x2v : imm_i;
    alu_b = b;
    case (f3)
      3'b000: alu_out = ((opcode == OP_REG) && f7[5]) ? (a - b) : (a + b);
      3'b001: alu_out = a << b[4:0];
      3'b010: alu_out = {31'h0, $signed(a) < $signed(b)};
      3'b011: alu_out = {31'h0, a < b};
      3'b100: alu_out = a ^ b;
      3'b101: alu_out = f7[5] ? 32'($signed(a) >>> b[4:0]) : (a >> b[4:0]);
      3'b110: alu_out = a | b;
      default: alu_out = a & b;
    endcase
  end

  always_comb begin
    case (f3)
      3'b000: br_take = (x1v == x2v);
      3'b001: br_take = (x1v != x2v);
      3'b100: br_take = $signed(x1v) <  $signed(x2v);
      3'b101: br_take = $signed(x1v) >= $signed(x2v);
      3'b110: br_take = x1v <  x2v;
      3'b111: br_take = x1v >= x2v;
      default: br_take = 1'b0;
    endcase
  end

  always_comb begin
    ex_illegal = 1'b0; ex_rd_we = 1'b0; ex_jump = 1'b0; ex_mem = 1'b0; ex_mem_we = 1'b0;
    ex_ecall = 1'b0; ex_ebreak = 1'b0; ex_mret = 1'b0; ex_wfi = 1'b0; ex_csr_we = 1'b0;
    ex_misalign_mem = 1'b0;
    ex_rd_val = 32'h0; ex_next_pc = pc + 32'd4; ex_mem_addr = 32'h0; ex_csr_wval = 32'h0;
    if (ir[1:0] != 2'b11) ex_illegal = 1'b1;
    else begin
      case (opcode)
        OP_LUI:   begin ex_rd_we = 1'b1; ex_rd_val = imm_u; end
        OP_AUIPC: begin ex_rd_we = 1'b1; ex_rd_val = pc + imm_u; end
        OP_JAL:   begin ex_rd_we = 1'b1; ex_rd_val = pc + 32'd4; ex_jump = 1'b1; ex_next_pc = pc + imm_j; end
        OP_JALR:  begin
          if (f3 != 3'b000) ex_illegal = 1'b1;
          else begin ex_rd_we = 1'b1; ex_rd_val = pc + 32'd4; ex_jump = 1'b1; ex_next_pc = (x1v + imm_i) & ~32'h1; end
        end
        OP_BRANCH: begin
          if (f3 == 3'b010 || f3 == 3'b011) ex_illegal = 1'b1;
          else if (br_take) begin ex_jump = 1'b1; ex_next_pc = pc + imm_b; end
        end
        OP_LOAD: begin
          ex_mem_addr = x1v + imm_i;
          if (f3 == 3'b011 || f3 == 3'b110 || f3 == 3'b111) ex_illegal = 1'b1;
          else begin
            ex_mem = 1'b1;
            if ((f3[1:0] == 2'b01 && ex_mem_addr[0]) || (f3[1:0] == 2'b10 && ex_mem_addr[1:0] != 2'b00))
              ex_misalign_mem = 1'b1;
          end
        end
        OP_STORE: begin
          ex_mem_addr = x1v + imm_s;
          if (f3 > 3'b010) ex_illegal = 1'b1;
          else begin
            ex_mem = 1'b1; ex_mem_we = 1'b1;
            if ((f3 == 3'b001 && ex_mem_addr[0]) || (f3 == 3'b010 && ex_mem_addr[1:0] != 2'b00))
              ex_misalign_mem = 1'b1;
          end
        end
        OP_IMM: begin
          if (f3 == 3'b001 && f7 != 7'h00) ex_illegal = 1'b1;
          else if (f3 == 3'b101 && f7 != 7'h00 && f7 != 7'h20) ex_illegal = 1'b1;
          else begin ex_rd_we = 1'b1; ex_rd_val = (f3 == 3'b000) ? (x1v + imm_i) : alu_out; end
        end
        OP_REG: begin
          if (f7 != 7'h00 && !(f7 == 7'h20 && (f3 == 3'b000 || f3 == 3'b101))) ex_illegal = 1'b1;
          else begin ex_rd_we = 1'b1; ex_rd_val = alu_out; end
        end
        OP_FENCE: begin
          if (f3 != 3'b000 && f3 != 3'b001) ex_illegal = 1'b1;   // FENCE / FENCE.I are no-ops
        end
        OP_SYSTEM: begin
          if (f3 == 3'b000) begin
            case (ir)
              32'h0000_0073: ex_ecall  = 1'b1;
              32'h0010_0073: ex_ebreak = 1'b1;
              32'h3020_0073: ex_mret   = 1'b1;
              32'h1050_0073: ex_wfi    = 1'b1;
              default:       ex_illegal = 1'b1;
            endcase
          end else if (f3 == 3'b100) ex_illegal = 1'b1;
          else begin
            logic [31:0] src;
            logic        writes;
            src    = f3[2] ? {27'h0, rs1} : x1v;
            writes = (f3[1:0] == 2'b01) || (rs1 != 5'd0);
            if (!csr_exists || (writes && csr_addr[11:10] == 2'b11)) ex_illegal = 1'b1;
            else begin
              ex_rd_we  = 1'b1;
              ex_rd_val = csr_rdata;
              ex_csr_we = writes;
              case (f3[1:0])
                2'b01:   ex_csr_wval = src;
                2'b10:   ex_csr_wval = csr_rdata | src;
                default: ex_csr_wval = csr_rdata & ~src;
              endcase
            end
          end
        end
        default: ex_illegal = 1'b1;
      endcase
    end
  end

  assign ex_misalign_pc = ex_jump && (ex_next_pc[1:0] != 2'b00);

  // ---------------------------------------------------------------- interrupt
  logic irq_pending, irq_take;
  assign irq_pending = irq_ext_i && mie_meie;
  assign irq_take    = (state == S_FETCH) && mstatus_mie && irq_pending;

  // ---------------------------------------------------------------- bus port
  always_comb begin
    req_valid = 1'b0;
    req_addr  = pc;
    req_we    = 1'b0;
    req_wdata = mem_wdata;
    req_wstrb = 4'h0;
    if (state == S_FETCH && !irq_take) begin
      req_valid = 1'b1;
      req_addr  = pc;
    end else if (state == S_MEM) begin
      req_valid = 1'b1;
      req_addr  = {mem_addr[31:2], 2'b00};
      req_we    = mem_we;
      req_wstrb = mem_we ? mem_wstrb : 4'h0;
    end
  end

  // load data extraction
  logic [31:0] load_val;
  always_comb begin
    logic [31:0] sh;
    sh = rsp_rdata >> {mem_addr[1:0], 3'b000};
    case (mem_f3)
      3'b000:  load_val = {{24{sh[7]}},  sh[7:0]};
      3'b001:  load_val = {{16{sh[15]}}, sh[15:0]};
      3'b100:  load_val = {24'h0, sh[7:0]};
      3'b101:  load_val = {16'h0, sh[15:0]};
      default: load_val = rsp_rdata;
    endcase
  end

  // ---------------------------------------------------------------- trap / retire decision (combinational)
  logic        retire;
  logic        trap_now;
  logic [31:0] trap_cause, trap_tval;

  always_comb begin
    retire     = 1'b0;
    trap_now   = 1'b0;
    trap_cause = 32'h0;
    trap_tval  = 32'h0;
    case (state)
      S_FETCH: if (irq_take) begin trap_now = 1'b1; trap_cause = 32'h8000_000B; end
      S_FETCH_WAIT: if (rsp_valid && rsp_err != sf_albion_regs_pkg::FE_OK) begin
        trap_now = 1'b1; trap_cause = 32'd1; trap_tval = pc;
      end
      S_EXEC: begin
        if (ex_illegal)          begin trap_now = 1'b1; trap_cause = 32'd2;  trap_tval = ir; end
        else if (ex_ebreak)      begin trap_now = 1'b1; trap_cause = 32'd3;  trap_tval = pc; end
        else if (ex_ecall)       begin trap_now = 1'b1; trap_cause = 32'd11; end
        else if (ex_misalign_pc) begin trap_now = 1'b1; trap_cause = 32'd0;  trap_tval = ex_next_pc; end
        else if (ex_mem && ex_misalign_mem) begin
          trap_now = 1'b1; trap_cause = ex_mem_we ? 32'd6 : 32'd4; trap_tval = ex_mem_addr;
        end
        else if (!ex_mem && !ex_wfi) retire = 1'b1;
      end
      S_MEM_WAIT: if (rsp_valid) begin
        if (rsp_err != sf_albion_regs_pkg::FE_OK) begin
          trap_now = 1'b1; trap_cause = mem_we ? 32'd7 : 32'd5; trap_tval = mem_addr;
        end else retire = 1'b1;
      end
      S_WFI: if (irq_pending) retire = 1'b1;
      default: ;
    endcase
  end

  // ---------------------------------------------------------------- state machine
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state <= S_FETCH; pc <= RESET_PC; ir <= 32'h0;
      mstatus_mie <= 1'b0; mstatus_mpie <= 1'b0; mie_meie <= 1'b0;
      mtvec <= 32'h0; mscratch <= 32'h0; mepc <= 32'h0; mcause <= 32'h0; mtval <= 32'h0;
      mcycle <= 64'h0; minstret <= 64'h0;
      mem_addr <= 32'h0; mem_wdata <= 32'h0; mem_wstrb <= 4'h0; mem_we <= 1'b0; mem_rd <= 5'd0; mem_f3 <= 3'd0;
      for (int i = 0; i < 32; i++) rf[i] <= 32'h0;
    end else begin
      mcycle <= mcycle + 64'd1;
      if (retire) minstret <= minstret + 64'd1;

      if (trap_now) begin
        mepc         <= pc;
        mcause       <= trap_cause;
        mtval        <= trap_tval;
        mstatus_mpie <= mstatus_mie;
        mstatus_mie  <= 1'b0;
        pc           <= {mtvec[31:2], 2'b00};
        state        <= S_FETCH;
      end else begin
        case (state)
          S_FETCH:      if (req_ready) state <= S_FETCH_WAIT;
          S_FETCH_WAIT: if (rsp_valid) begin ir <= rsp_rdata; state <= S_EXEC; end
          S_EXEC: begin
            if (ex_mem) begin
              mem_addr  <= ex_mem_addr;
              mem_we    <= ex_mem_we;
              mem_rd    <= rd;
              mem_f3    <= f3;
              mem_wstrb <= (f3 == 3'b000) ? (4'b0001 << ex_mem_addr[1:0]) :
                           (f3 == 3'b001) ? (4'b0011 << ex_mem_addr[1:0]) : 4'b1111;
              mem_wdata <= (f3 == 3'b000) ? {4{x2v[7:0]}} : (f3 == 3'b001) ? {2{x2v[15:0]}} : x2v;
              state     <= S_MEM;
            end else if (ex_mret) begin
              pc           <= mepc;
              mstatus_mie  <= mstatus_mpie;
              mstatus_mpie <= 1'b1;
              state        <= S_FETCH;
            end else if (ex_wfi) begin
              state <= S_WFI;
            end else begin
              if (ex_rd_we && rd != 5'd0) rf[rd] <= ex_rd_val;
              if (ex_csr_we) begin
                case (csr_addr)
                  12'h300: begin mstatus_mie <= ex_csr_wval[3]; mstatus_mpie <= ex_csr_wval[7]; end
                  12'h304: mie_meie <= ex_csr_wval[11];
                  12'h305: mtvec    <= {ex_csr_wval[31:2], 2'b00};
                  12'h340: mscratch <= ex_csr_wval;
                  12'h341: mepc     <= {ex_csr_wval[31:2], 2'b00};
                  12'h342: mcause   <= ex_csr_wval;
                  12'h343: mtval    <= ex_csr_wval;
                  12'hB00: mcycle[31:0]    <= ex_csr_wval;
                  12'hB80: mcycle[63:32]   <= ex_csr_wval;
                  12'hB02: minstret[31:0]  <= ex_csr_wval;
                  12'hB82: minstret[63:32] <= ex_csr_wval;
                  default: ;
                endcase
              end
              pc    <= ex_next_pc;
              state <= S_FETCH;
            end
          end
          S_MEM:      if (req_ready) state <= S_MEM_WAIT;
          S_MEM_WAIT: if (rsp_valid) begin
            if (!mem_we && mem_rd != 5'd0) rf[mem_rd] <= load_val;
            pc    <= pc + 32'd4;
            state <= S_FETCH;
          end
          S_WFI:      if (irq_pending) begin pc <= pc + 32'd4; state <= S_FETCH; end
          default:    state <= S_FETCH;
        endcase
      end
    end
  end

  // ---------------------------------------------------------------- retirement / trace
  assign trace_valid_o    = retire || trap_now;
  assign trace_pc_o       = pc;
  assign trace_insn_o     = ir;
  assign trace_trap_o     = trap_now;
  assign trace_cause_o    = trap_cause;
  assign trace_rd_we_o    = retire && ((state == S_MEM_WAIT) ? (!mem_we && mem_rd != 5'd0) : (ex_rd_we && rd != 5'd0 && state == S_EXEC));
  assign trace_rd_o       = (state == S_MEM_WAIT) ? mem_rd : rd;
  assign trace_rd_wdata_o = (state == S_MEM_WAIT) ? load_val : ex_rd_val;
  assign instret_o        = retire;
  assign sleep_o          = (state == S_WFI);

  logic unused;
  assign unused = ^alu_b;
endmodule
