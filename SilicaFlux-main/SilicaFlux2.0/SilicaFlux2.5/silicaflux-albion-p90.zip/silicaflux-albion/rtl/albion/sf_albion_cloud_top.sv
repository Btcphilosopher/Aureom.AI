// =============================================================================
// SilicaFlux Albion (Project 90) - ALBIONCLOUD integrated cloud SoC top.
// Aureom.AI / SilicaFlux Albion
//
//   ControlCore (RV32I) --+                         +-- SRAM bank 0 (firmware-private)
//   DMA read port --------+                         +-- SRAM bank 1..NB-1 (data)
//   DMA write port -------+-- DataFabric + perm ----+-- MMIO: MGMT/mailbox, IRQ, DMA,
//   Host MMIO (BAR) ------+                         |         PERM, TELEM, RAS
//                                                   +-- HOSTMEM -> host memory port
//
// CONFIG selects ALBION_MIN (0) / ALBION_CLOUD (1) / ALBION_HPC (2) from
// sf_albion_cloud_config. Requested features whose implementation is not in this
// repository (PacketForge P86, VirtualFoundry P87, ComputeWorks P88) are NOT
// instantiated; they are reported in MGMT.FEAT_UNAVAIL and the firmware returns
// UNSUPPORTED for their workloads. STRICT=1 turns that into an elaboration error.
//
// Single clock domain. rst_ni is asynchronous-assert / synchronous-deassert; all
// logic below the reset controller uses the synchronous internal reset.
// =============================================================================
module sf_albion_cloud_top #(
  parameter int          CONFIG   = 0,
  parameter bit          STRICT   = 1'b0,
  parameter logic [31:0] BUILD_ID = 32'h0000_0000
) (
  input  logic        clk_i,
  input  logic        rst_ni,
  input  logic        dbg_strap_i,
  // host MMIO target (PCIe BAR in silicon)
  input  logic        h_req_valid_i,
  output logic        h_req_ready_o,
  input  logic [31:0] h_req_addr_i,
  input  logic        h_req_we_i,
  input  logic [31:0] h_req_wdata_i,
  input  logic [3:0]  h_req_wstrb_i,
  output logic        h_rsp_valid_o,
  output logic [31:0] h_rsp_rdata_o,
  output logic [2:0]  h_rsp_err_o,
  // host memory requester (PCIe requester behind the host IOMMU in silicon)
  output logic        hm_req_valid_o,
  input  logic        hm_req_ready_i,
  output logic [30:0] hm_req_addr_o,
  output logic        hm_req_we_o,
  output logic [31:0] hm_req_wdata_o,
  output logic [3:0]  hm_req_wstrb_o,
  input  logic        hm_rsp_valid_i,
  input  logic [31:0] hm_rsp_rdata_i,
  input  logic        hm_rsp_err_i,
  output logic        host_irq_o,
  // status
  output logic        init_done_o,
  output logic        core_run_o,
  output logic        boot_lock_o,
  // ControlCore retirement trace (verification / FPGA debug)
  output logic        trace_valid_o,
  output logic [31:0] trace_pc_o,
  output logic [31:0] trace_insn_o,
  output logic        trace_rd_we_o,
  output logic [4:0]  trace_rd_o,
  output logic [31:0] trace_rd_wdata_o,
  output logic        trace_trap_o,
  output logic [31:0] trace_cause_o
);
  // ---------------------------------------------------------------- configuration
  localparam int NB         = sf_albion_cloud_config::cfg_sram_banks(CONFIG);
  localparam int BANK_BYTES = sf_albion_cloud_config::cfg_sram_bank_bytes(CONFIG);
  localparam int NW         = sf_albion_cloud_config::cfg_windows(CONFIG);
  localparam int QDEPTH     = sf_albion_cloud_config::cfg_cmdq_depth(CONFIG);
  localparam logic [31:0] FEAT_REQ  = sf_albion_cloud_config::cfg_feat_req(CONFIG);
  localparam logic [31:0] FEAT_IMPL = FEAT_REQ & sf_albion_regs_pkg::FEAT_AVAILABLE_MASK;
  localparam logic [31:0] FEAT_MISSING = FEAT_REQ & ~FEAT_IMPL;
  localparam int NS         = NB + 2;
  localparam int NM         = 4;
  localparam int WORDS      = BANK_BYTES / 4;
  localparam int AW         = $clog2(WORDS);
  localparam int BANK_SHIFT = $clog2(BANK_BYTES);
  localparam int NC         = sf_albion_regs_pkg::NUM_TCOUNTERS;
  localparam int SI_MMIO    = NB;
  localparam int SI_HOST    = NB + 1;
  localparam int PG_MGMT    = 32'(sf_albion_regs_pkg::PAGE_MGMT);
  localparam int PG_IRQ     = 32'(sf_albion_regs_pkg::PAGE_IRQ);
  localparam int PG_DMA     = 32'(sf_albion_regs_pkg::PAGE_DMA);
  localparam int PG_PERM    = 32'(sf_albion_regs_pkg::PAGE_PERM);
  localparam int PG_TELEM   = 32'(sf_albion_regs_pkg::PAGE_TELEM);
  localparam int PG_RAS     = 32'(sf_albion_regs_pkg::PAGE_RAS);

`ifndef SYNTHESIS
  generate
    if (STRICT && FEAT_MISSING != 32'h0) begin : g_strict
      $error("sf_albion_cloud_top: CONFIG %0d requests unavailable features 0x%08x (see docs/albion/hardware_dependencies.md)",
             CONFIG, FEAT_MISSING);
    end
    if (NB > 8)  begin : g_nb_chk $error("sf_albion_cloud_top: at most 8 SRAM banks are supported by the telemetry map"); end
    if ((BANK_BYTES & (BANK_BYTES - 1)) != 0) begin : g_bb_chk $error("SRAM bank size must be a power of two"); end
  endgenerate
  initial begin
    if (FEAT_MISSING != 32'h0)
      $display("[albion] CONFIG %0d: requested-but-unavailable features 0x%08x reported in MGMT.FEAT_UNAVAIL (not instantiated)",
               CONFIG, FEAT_MISSING);
  end
`endif

  // ---------------------------------------------------------------- reset
  logic rst_n, soft_reset_req;
  sf_albion_rstctl u_rstctl (.clk(clk_i), .rst_ni(rst_ni), .soft_req_i(soft_reset_req), .rst_no(rst_n));

  // ---------------------------------------------------------------- fabric wiring
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_we, m_rsp_valid;
  logic [NM*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0]  m_req_wstrb, m_req_domain;
  logic [NM*3-1:0]  m_rsp_err;

  logic [NS-1:0]    s_req_valid, s_req_ready, s_req_we, s_rsp_valid;
  logic [NS*32-1:0] s_req_addr, s_req_wdata, s_rsp_rdata;
  logic [NS*4-1:0]  s_req_wstrb, s_req_domain;
  logic [NS*2-1:0]  s_req_id, s_rsp_id;
  logic [NS*3-1:0]  s_rsp_err;

  logic [NW*32-1:0] win_base, win_limit;
  logic [NW*12-1:0] win_attr;
  logic             boot_mode, core_run, boot_lock, init_done;

  logic             viol, viol_we, decerr, bank_conflict;
  logic [31:0]      viol_addr;
  logic [1:0]       viol_master;
  logic [3:0]       viol_domain;
  logic [NM-1:0]    ev_m_txn, ev_m_stall;
  logic [NS-1:0]    ev_s_txn;

  sf_albion_datafabric #(.NB(NB), .BANK_BYTES(BANK_BYTES), .NW(NW)) u_fabric (
    .clk(clk_i), .rst_n(rst_n),
    .m_req_valid, .m_req_ready, .m_req_addr, .m_req_we, .m_req_wdata, .m_req_wstrb, .m_req_domain,
    .m_rsp_valid, .m_rsp_rdata, .m_rsp_err,
    .win_base, .win_limit, .win_attr, .boot_mode,
    .s_req_valid, .s_req_ready, .s_req_addr, .s_req_we, .s_req_wdata, .s_req_wstrb, .s_req_domain, .s_req_id,
    .s_rsp_valid, .s_rsp_rdata, .s_rsp_err, .s_rsp_id,
    .viol_o(viol), .viol_addr_o(viol_addr), .viol_master_o(viol_master), .viol_domain_o(viol_domain),
    .viol_we_o(viol_we), .decerr_o(decerr),
    .ev_m_txn_o(ev_m_txn), .ev_m_stall_o(ev_m_stall), .ev_s_txn_o(ev_s_txn), .ev_bank_conflict_o(bank_conflict));

  // ---------------------------------------------------------------- ControlCore (master 0)
  logic core_rst_n, irq_fw, core_instret, core_sleep;
  assign core_rst_n = rst_n && core_run;

  sf_albion_controlcore u_core (
    .clk(clk_i), .rst_n(core_rst_n),
    .req_valid(m_req_valid[0]), .req_ready(m_req_ready[0]), .req_addr(m_req_addr[0*32 +: 32]),
    .req_we(m_req_we[0]), .req_wdata(m_req_wdata[0*32 +: 32]), .req_wstrb(m_req_wstrb[0*4 +: 4]),
    .rsp_valid(m_rsp_valid[0]), .rsp_rdata(m_rsp_rdata[0*32 +: 32]), .rsp_err(m_rsp_err[0*3 +: 3]),
    .irq_ext_i(irq_fw),
    .trace_valid_o, .trace_pc_o, .trace_insn_o, .trace_rd_we_o, .trace_rd_o, .trace_rd_wdata_o,
    .trace_trap_o, .trace_cause_o,
    .instret_o(core_instret), .sleep_o(core_sleep));
  assign m_req_domain[0*4 +: 4] = sf_albion_regs_pkg::DOM_FIRMWARE;

  // ---------------------------------------------------------------- DMA (masters 1, 2)
  logic [31:0] dma_rg_rdata;
  logic [2:0]  dma_rg_err;
  logic [3:0]  dma_domain;
  logic        dma_done_ok, dma_done_err, dma_bytes;
  logic        rg_we, rg_re;
  logic [11:0] rg_off;
  logic [31:0] rg_wdata;
  logic [1:0]  rg_master;
  logic [5:0]  rg_sel;

  sf_albion_dma #(.DEPTH(4)) u_dma (
    .clk(clk_i), .rst_n(rst_n),
    .rg_we(rg_we && rg_sel[PG_DMA]), .rg_off, .rg_wdata,
    .rg_rdata(dma_rg_rdata), .rg_err(dma_rg_err),
    .rd_req_valid(m_req_valid[1]), .rd_req_ready(m_req_ready[1]), .rd_req_addr(m_req_addr[1*32 +: 32]),
    .rd_rsp_valid(m_rsp_valid[1]), .rd_rsp_rdata(m_rsp_rdata[1*32 +: 32]), .rd_rsp_err(m_rsp_err[1*3 +: 3]),
    .wr_req_valid(m_req_valid[2]), .wr_req_ready(m_req_ready[2]), .wr_req_addr(m_req_addr[2*32 +: 32]),
    .wr_req_wdata(m_req_wdata[2*32 +: 32]),
    .wr_rsp_valid(m_rsp_valid[2]), .wr_rsp_err(m_rsp_err[2*3 +: 3]),
    .domain_o(dma_domain),
    .ev_done_ok_o(dma_done_ok), .ev_done_err_o(dma_done_err), .ev_bytes_o(dma_bytes));
  assign m_req_we[1]            = 1'b0;
  assign m_req_wdata[1*32 +: 32] = 32'h0;
  assign m_req_wstrb[1*4 +: 4]  = 4'h0;
  assign m_req_domain[1*4 +: 4] = dma_domain;
  assign m_req_we[2]            = 1'b1;
  assign m_req_wstrb[2*4 +: 4]  = 4'hF;
  assign m_req_domain[2*4 +: 4] = dma_domain;

  logic unused_dma_rd;
  assign unused_dma_rd = ^m_rsp_rdata[2*32 +: 32];

  // ---------------------------------------------------------------- host interface (master 3, slave NB+1)
  sf_albion_host_if u_host (
    .clk(clk_i), .rst_n(rst_n),
    .h_req_valid_i, .h_req_ready_o, .h_req_addr_i, .h_req_we_i, .h_req_wdata_i, .h_req_wstrb_i,
    .h_rsp_valid_o, .h_rsp_rdata_o, .h_rsp_err_o,
    .m_req_valid(m_req_valid[3]), .m_req_ready(m_req_ready[3]), .m_req_addr(m_req_addr[3*32 +: 32]),
    .m_req_we(m_req_we[3]), .m_req_wdata(m_req_wdata[3*32 +: 32]), .m_req_wstrb(m_req_wstrb[3*4 +: 4]),
    .m_rsp_valid(m_rsp_valid[3]), .m_rsp_rdata(m_rsp_rdata[3*32 +: 32]), .m_rsp_err(m_rsp_err[3*3 +: 3]),
    .s_req_valid(s_req_valid[SI_HOST]), .s_req_ready(s_req_ready[SI_HOST]), .s_req_addr(s_req_addr[SI_HOST*32 +: 32]),
    .s_req_we(s_req_we[SI_HOST]), .s_req_wdata(s_req_wdata[SI_HOST*32 +: 32]), .s_req_wstrb(s_req_wstrb[SI_HOST*4 +: 4]),
    .s_req_id(s_req_id[SI_HOST*2 +: 2]),
    .s_rsp_valid(s_rsp_valid[SI_HOST]), .s_rsp_rdata(s_rsp_rdata[SI_HOST*32 +: 32]), .s_rsp_err(s_rsp_err[SI_HOST*3 +: 3]),
    .s_rsp_id(s_rsp_id[SI_HOST*2 +: 2]),
    .hm_req_valid_o, .hm_req_ready_i, .hm_req_addr_o, .hm_req_we_o, .hm_req_wdata_o, .hm_req_wstrb_o,
    .hm_rsp_valid_i, .hm_rsp_rdata_i, .hm_rsp_err_i);
  assign m_req_domain[3*4 +: 4] = sf_albion_regs_pkg::DOM_HOST_ADMIN;

  // ---------------------------------------------------------------- SRAM banks (slaves 0..NB-1)
  logic [NB-1:0]    ecc_ce, ecc_ue, inj_arm, inj_hit, bank_init;
  logic [NB*7-1:0]  ecc_syn;
  logic [NB*AW-1:0] ecc_word;
  logic [NB*2-1:0]  ecc_master;
  logic [NB*4-1:0]  ecc_domain;
  logic [AW-1:0]    inj_word;
  logic [38:0]      inj_mask;

  generate
    for (genvar b = 0; b < NB; b++) begin : g_bank
      logic [31:0] a;
      assign a = s_req_addr[b*32 +: 32];
      sf_albion_sram_bank #(.WORDS(WORDS)) u_bank (
        .clk(clk_i), .rst_n(rst_n),
        .req_valid(s_req_valid[b]), .req_ready(s_req_ready[b]), .req_word(a[BANK_SHIFT-1:2]),
        .req_we(s_req_we[b]), .req_wdata(s_req_wdata[b*32 +: 32]), .req_wstrb(s_req_wstrb[b*4 +: 4]),
        .req_id(s_req_id[b*2 +: 2]), .req_domain(s_req_domain[b*4 +: 4]),
        .rsp_valid(s_rsp_valid[b]), .rsp_rdata(s_rsp_rdata[b*32 +: 32]), .rsp_err(s_rsp_err[b*3 +: 3]),
        .rsp_id(s_rsp_id[b*2 +: 2]),
        .inj_arm(inj_arm[b]), .inj_word(inj_word), .inj_mask(inj_mask), .inj_hit_o(inj_hit[b]),
        .ecc_ce_o(ecc_ce[b]), .ecc_ue_o(ecc_ue[b]), .ecc_syndrome_o(ecc_syn[b*7 +: 7]),
        .ecc_word_o(ecc_word[b*AW +: AW]), .ecc_master_o(ecc_master[b*2 +: 2]), .ecc_domain_o(ecc_domain[b*4 +: 4]),
        .init_done_o(bank_init[b]));
    end
  endgenerate
  assign init_done = &bank_init;

  // ---------------------------------------------------------------- MMIO (slave NB)
  logic [6*32-1:0] pg_rdata;
  logic [6*3-1:0]  pg_err;
  sf_albion_mmio u_mmio (
    .clk(clk_i), .rst_n(rst_n),
    .req_valid(s_req_valid[SI_MMIO]), .req_ready(s_req_ready[SI_MMIO]), .req_addr(s_req_addr[SI_MMIO*32 +: 32]),
    .req_we(s_req_we[SI_MMIO]), .req_wdata(s_req_wdata[SI_MMIO*32 +: 32]), .req_wstrb(s_req_wstrb[SI_MMIO*4 +: 4]),
    .req_id(s_req_id[SI_MMIO*2 +: 2]),
    .rsp_valid(s_rsp_valid[SI_MMIO]), .rsp_rdata(s_rsp_rdata[SI_MMIO*32 +: 32]), .rsp_err(s_rsp_err[SI_MMIO*3 +: 3]),
    .rsp_id(s_rsp_id[SI_MMIO*2 +: 2]),
    .rg_we, .rg_re, .rg_off, .rg_wdata, .rg_master, .rg_page_sel(rg_sel), .pg_rdata, .pg_err);

  logic unused_mmio_dom;
  assign unused_mmio_dom = ^{s_req_domain[SI_MMIO*4 +: 4], s_req_domain[SI_HOST*4 +: 4]};

  // MGMT (page 0)
  logic cmdq_nonempty, ev_cmd_submit, ev_cpl_post, ev_cmd_drop;
  sf_albion_mgmt #(.CONFIG(CONFIG), .NB(NB), .BANK_BYTES(BANK_BYTES), .NW(NW), .QDEPTH(QDEPTH),
                   .FEAT_IMPL(FEAT_IMPL), .FEAT_REQ(FEAT_REQ), .BUILD_ID(BUILD_ID)) u_mgmt (
    .clk(clk_i), .rst_n(rst_n),
    .rg_we(rg_we && rg_sel[PG_MGMT]), .rg_re(rg_re && rg_sel[PG_MGMT]),
    .rg_off, .rg_wdata, .rg_master, .rg_rdata(pg_rdata[0*32 +: 32]), .rg_err(pg_err[0*3 +: 3]),
    .init_done_i(init_done), .dbg_strap_i(dbg_strap_i),
    .core_run_o(core_run), .boot_lock_o(boot_lock), .boot_mode_o(boot_mode), .soft_reset_req_o(soft_reset_req),
    .host_irq_o(host_irq_o), .cmdq_nonempty_o(cmdq_nonempty),
    .ev_cmd_submit_o(ev_cmd_submit), .ev_cpl_post_o(ev_cpl_post), .ev_cmd_drop_o(ev_cmd_drop));

  // IRQ (page 1)
  localparam int NIRQ = sf_albion_regs_pkg::NUM_IRQ;
  logic [NIRQ-1:0] irq_level, irq_pulse;
  always_comb begin
    irq_level = '0;
    irq_pulse = '0;
    irq_level[sf_albion_regs_pkg::IRQ_CMDQ_BIT]      = cmdq_nonempty;
    irq_pulse[sf_albion_regs_pkg::IRQ_DMA_DONE_BIT]  = dma_done_ok;
    irq_pulse[sf_albion_regs_pkg::IRQ_DMA_ERR_BIT]   = dma_done_err;
    irq_pulse[sf_albion_regs_pkg::IRQ_PERM_VIOL_BIT] = viol;
    irq_pulse[sf_albion_regs_pkg::IRQ_ECC_CE_BIT]    = |ecc_ce;
    irq_pulse[sf_albion_regs_pkg::IRQ_ECC_UE_BIT]    = |ecc_ue;
  end
  sf_albion_irq #(.N(NIRQ)) u_irq (
    .clk(clk_i), .rst_n(rst_n),
    .rg_we(rg_we && rg_sel[PG_IRQ]), .rg_off, .rg_wdata,
    .rg_rdata(pg_rdata[1*32 +: 32]), .rg_err(pg_err[1*3 +: 3]),
    .level_i(irq_level), .pulse_i(irq_pulse), .irq_o(irq_fw));

  // DMA (page 2)
  assign pg_rdata[2*32 +: 32] = dma_rg_rdata;
  assign pg_err[2*3 +: 3]     = dma_rg_err;

  // PERM (page 3)
  sf_albion_perm #(.NW(NW)) u_perm (
    .clk(clk_i), .rst_n(rst_n),
    .rg_we(rg_we && rg_sel[PG_PERM]), .rg_off, .rg_wdata,
    .rg_rdata(pg_rdata[3*32 +: 32]), .rg_err(pg_err[3*3 +: 3]),
    .viol_i(viol), .viol_addr_i(viol_addr), .viol_master_i(viol_master), .viol_domain_i(viol_domain),
    .viol_we_i(viol_we),
    .win_base_o(win_base), .win_limit_o(win_limit), .win_attr_o(win_attr));

  // TELEM (page 4)
  logic [NC*4-1:0] tinc;
  always_comb begin
    integer nce, nue;
    nce = 0;
    nue = 0;
    for (int b = 0; b < NB; b++) begin
      nce = nce + 32'(ecc_ce[b]);
      nue = nue + 32'(ecc_ue[b]);
    end
    tinc = '0;
    tinc[sf_albion_regs_pkg::TC_CYCLES*4 +: 4]        = 4'd1;
    for (int m = 0; m < NM; m++) begin
      tinc[(sf_albion_regs_pkg::TC_M_CORE_TXN + m)*4 +: 4]   = {3'd0, ev_m_txn[m]};
      tinc[(sf_albion_regs_pkg::TC_M_CORE_STALL + m)*4 +: 4] = {3'd0, ev_m_stall[m]};
    end
    for (int b = 0; b < NB; b++)
      tinc[(sf_albion_regs_pkg::TC_S_BANK0_TXN + b)*4 +: 4] = {3'd0, ev_s_txn[b]};
    tinc[sf_albion_regs_pkg::TC_S_MMIO_TXN*4 +: 4]     = {3'd0, ev_s_txn[SI_MMIO]};
    tinc[sf_albion_regs_pkg::TC_S_HOST_TXN*4 +: 4]     = {3'd0, ev_s_txn[SI_HOST]};
    tinc[sf_albion_regs_pkg::TC_BANK_CONFLICT*4 +: 4]  = {3'd0, bank_conflict};
    tinc[sf_albion_regs_pkg::TC_DMA_BYTES*4 +: 4]      = dma_bytes ? 4'd4 : 4'd0;
    tinc[sf_albion_regs_pkg::TC_DMA_DESC_DONE*4 +: 4]  = {3'd0, dma_done_ok || dma_done_err};
    tinc[sf_albion_regs_pkg::TC_DMA_ERRORS*4 +: 4]     = {3'd0, dma_done_err};
    tinc[sf_albion_regs_pkg::TC_PERM_VIOL*4 +: 4]      = {3'd0, viol};
    tinc[sf_albion_regs_pkg::TC_DECERR*4 +: 4]         = {3'd0, decerr};
    tinc[sf_albion_regs_pkg::TC_ECC_CE*4 +: 4]         = 4'(nce);
    tinc[sf_albion_regs_pkg::TC_ECC_UE*4 +: 4]         = 4'(nue);
    tinc[sf_albion_regs_pkg::TC_CMD_SUBMITTED*4 +: 4]  = {3'd0, ev_cmd_submit};
    tinc[sf_albion_regs_pkg::TC_CPL_POSTED*4 +: 4]     = {3'd0, ev_cpl_post};
    tinc[sf_albion_regs_pkg::TC_CMDQ_DROPS*4 +: 4]     = {3'd0, ev_cmd_drop};
    tinc[sf_albion_regs_pkg::TC_CORE_INSTRET*4 +: 4]   = {3'd0, core_instret};
    tinc[sf_albion_regs_pkg::TC_CORE_SLEEP_CYCLES*4 +: 4] = {3'd0, core_sleep};
    for (int d = 0; d < 16; d++)
      tinc[(sf_albion_regs_pkg::TC_DOM0_BYTES + d)*4 +: 4] = (dma_bytes && 32'(dma_domain) == d) ? 4'd4 : 4'd0;
  end

  sf_albion_telemetry #(.NC(NC)) u_telem (
    .clk(clk_i), .rst_n(rst_n),
    .rg_we(rg_we && rg_sel[PG_TELEM]), .rg_re(rg_re && rg_sel[PG_TELEM]),
    .rg_off, .rg_wdata, .rg_master,
    .rg_rdata(pg_rdata[4*32 +: 32]), .rg_err(pg_err[4*3 +: 3]), .inc_i(tinc));

  // RAS (page 5)
  sf_albion_ras #(.NB(NB), .BANK_BYTES(BANK_BYTES)) u_ras (
    .clk(clk_i), .rst_n(rst_n),
    .rg_we(rg_we && rg_sel[PG_RAS]), .rg_off, .rg_wdata,
    .rg_rdata(pg_rdata[5*32 +: 32]), .rg_err(pg_err[5*3 +: 3]),
    .ce_i(ecc_ce), .ue_i(ecc_ue), .syn_i(ecc_syn), .word_i(ecc_word), .master_i(ecc_master),
    .domain_i(ecc_domain), .init_done_i(bank_init),
    .inj_arm_o(inj_arm), .inj_word_o(inj_word), .inj_mask_o(inj_mask), .inj_hit_i(inj_hit));

  // ---------------------------------------------------------------- status
  assign init_done_o = init_done;
  assign core_run_o  = core_run;
  assign boot_lock_o = boot_lock;

  logic unused_re;
  assign unused_re = rg_re;
endmodule
