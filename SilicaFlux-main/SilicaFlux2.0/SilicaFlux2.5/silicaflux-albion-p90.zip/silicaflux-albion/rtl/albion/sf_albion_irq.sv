// SilicaFlux Albion - firmware interrupt controller (level + sticky sources).
module sf_albion_irq #(
  parameter int N = 6
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rg_we,
  input  logic [11:0] rg_off,
  input  logic [31:0] rg_wdata,
  output logic [31:0] rg_rdata,
  output logic [2:0]  rg_err,
  input  logic [N-1:0] level_i,      // level sources (bit set => level-type)
  input  logic [N-1:0] pulse_i,      // sticky sources (pulse sets pending)
  output logic        irq_o
);
  logic [N-1:0] sticky, enable;
  logic [N-1:0] pending;
  assign pending = sticky | level_i;
  assign irq_o   = |(pending & enable);

  always_comb begin
    rg_rdata = 32'h0;
    rg_err   = sf_albion_regs_pkg::FE_OK;
    case (rg_off)
      sf_albion_regs_pkg::IRQ_PENDING: begin rg_rdata = 32'(pending); if (rg_we) rg_err = sf_albion_regs_pkg::FE_SLVERR; end
      sf_albion_regs_pkg::IRQ_ENABLE:  rg_rdata = 32'(enable);
      sf_albion_regs_pkg::IRQ_CLEAR:   rg_rdata = 32'h0;
      sf_albion_regs_pkg::IRQ_RAW:     begin rg_rdata = 32'(pending); if (rg_we) rg_err = sf_albion_regs_pkg::FE_SLVERR; end
      default: rg_err = sf_albion_regs_pkg::FE_DECERR;
    endcase
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      sticky <= '0;
      enable <= '0;
    end else begin
      logic [N-1:0] clr;
      clr = '0;
      if (rg_we && rg_off == sf_albion_regs_pkg::IRQ_ENABLE) enable <= rg_wdata[N-1:0];
      if (rg_we && rg_off == sf_albion_regs_pkg::IRQ_CLEAR)  clr = rg_wdata[N-1:0];
      sticky <= (sticky & ~clr) | pulse_i;
    end
  end
endmodule
