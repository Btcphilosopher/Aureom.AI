// SilicaFlux Albion - single-port synchronous SRAM macro wrapper (1RW).
//
// One access per cycle: either a read or a write, never both (single-port macro
// semantics, matching Project 84's rule that two transactions never share a
// single-port macro in one cycle). Read data appears the cycle after `en`.
//
// Simulation / FPGA: behavioural array (FPGA tools infer block RAM).
// ASIC synthesis:    tools/albion_synth reads a blackbox stub instead of this file;
//                    a compiled macro (e.g. OpenRAM / foundry compiler) must be
//                    supplied before any area or timing number for SRAM is meaningful.
module sf_albion_sram_macro #(
  parameter int WORDS = 4096,
  parameter int W     = 39,
  parameter int AW    = $clog2(WORDS)
) (
  input  logic          clk,
  input  logic          en,
  input  logic          we,
  input  logic [AW-1:0] addr,
  input  logic [W-1:0]  wdata,
  output logic [W-1:0]  rdata
);
  logic [W-1:0] mem [WORDS];

  always_ff @(posedge clk) begin
    if (en) begin
      if (we) mem[addr] <= wdata;
      else    rdata     <= mem[addr];
    end
  end
endmodule
