// SilicaFlux Albion - (39,32) SECDED code: extended Hamming(38,32) + overall parity.
//
// Codeword layout: cw[i-1] holds Hamming position i (i = 1..38). Positions that are
// powers of two (1,2,4,8,16,32) are check bits; the other 32 positions carry data
// bits in ascending order. cw[38] is overall (even) parity over cw[37:0].
//
// Decode:  syndrome s = XOR of positions whose index has bit p set (p = 0..5)
//          P = XOR of all 39 bits
//   s == 0, P == 0  -> clean
//   P == 1          -> single-bit error: s == 0 means the overall parity bit;
//                      1 <= s <= 38 flips position s; s > 38 is not a valid
//                      single-bit pattern and is reported as uncorrectable
//   s != 0, P == 0  -> double-bit error (uncorrectable)
// Properties proven in formal/albion (all single flips corrected, all double flips
// detected).

module sf_albion_secded_enc (
  input  logic [31:0] data_i,
  output logic [38:0] cw_o
);
  // position (1..38) of data bit k
  function automatic int dpos(input int k);
    integer c;
    c = 0;
    dpos = 0;
    for (int i = 1; i <= 38; i++) begin
      if ((i & (i - 1)) != 0) begin
        if (c == k) dpos = i;
        c = c + 1;
      end
    end
  endfunction

  // bit i set when Hamming position i (1..38) participates in check bit p
  function automatic logic [38:0] pmask(input int p);
    pmask = '0;
    for (int i = 1; i <= 38; i++) begin
      if (((i >> p) & 1) == 1) pmask[i] = 1'b1;
    end
  endfunction

  logic [38:0] dvec;   // index = Hamming position, index 0 unused
  logic [5:0]  chk;
  logic [38:0] pos;

  always_comb begin
    dvec = '0;
    for (int k = 0; k < 32; k++) dvec[dpos(k)] = data_i[k];
  end

  always_comb begin
    for (int p = 0; p < 6; p++) chk[p] = ^(dvec & pmask(p));
  end

  always_comb begin
    pos = dvec;
    for (int p = 0; p < 6; p++) pos[1 << p] = chk[p];
    cw_o[37:0] = pos[38:1];
    cw_o[38]   = ^pos[38:1];
  end
endmodule


module sf_albion_secded_dec (
  input  logic [38:0] cw_i,
  output logic [31:0] data_o,
  output logic        ce_o,        // single-bit error corrected
  output logic        ue_o,        // uncorrectable error detected
  output logic [6:0]  syndrome_o   // {overall parity, hamming syndrome}
);
  function automatic int dpos(input int k);
    integer c;
    c = 0;
    dpos = 0;
    for (int i = 1; i <= 38; i++) begin
      if ((i & (i - 1)) != 0) begin
        if (c == k) dpos = i;
        c = c + 1;
      end
    end
  endfunction

  function automatic logic [38:0] pmask(input int p);
    pmask = '0;
    for (int i = 1; i <= 38; i++) begin
      if (((i >> p) & 1) == 1) pmask[i] = 1'b1;
    end
  endfunction

  logic [38:0] pos;      // index = Hamming position
  logic [5:0]  s;
  logic        par;
  logic [38:0] fixed;
  logic        single;

  always_comb begin
    pos = {cw_i[37:0], 1'b0};
    for (int p = 0; p < 6; p++) s[p] = ^(pos & pmask(p));
    par = ^cw_i;
    single = par && (s <= 6'd38);
    ce_o = par && (s <= 6'd38);
    ue_o = (!par && (s != 6'd0)) || (par && (s > 6'd38));
    fixed = pos;
    if (single && (s != 6'd0)) fixed[s] = ~pos[s];
    for (int k = 0; k < 32; k++) data_o[k] = fixed[dpos(k)];
    syndrome_o = {par, s};
  end
endmodule
