// SilicaFlux Albion - reset controller.
// * rst_ni: asynchronous-assert, synchronous-deassert (2-flop synchroniser).
// * soft_req_i: host SOFT_RESET pulse; stretched to 16 cycles. The stretcher is
//   reset only by the pin, so a soft reset cannot cancel itself.
// * Output is registered (glitch-free) and synchronous to clk.
module sf_albion_rstctl (
  input  logic clk,
  input  logic rst_ni,
  input  logic soft_req_i,
  output logic rst_no
);
  logic [1:0] sync;
  logic       pin_rst_n;
  logic [3:0] stretch;

  always_ff @(posedge clk or negedge rst_ni) begin
    if (!rst_ni) sync <= 2'b00;
    else         sync <= {sync[0], 1'b1};
  end
  assign pin_rst_n = sync[1];

  always_ff @(posedge clk) begin
    if (!pin_rst_n)      stretch <= 4'd0;
    else if (soft_req_i) stretch <= 4'd15;
    else if (stretch != 4'd0) stretch <= stretch - 4'd1;
  end

  always_ff @(posedge clk or negedge rst_ni) begin
    if (!rst_ni) rst_no <= 1'b0;
    else         rst_no <= pin_rst_n && (stretch == 4'd0) && !soft_req_i;
  end
endmodule
