// SilicaFlux Albion - MMIO slave: decodes 4 KiB pages and fans out a simple
// register port to the peripheral blocks. One-cycle latency, accepts every cycle.
// Register writes must be full-word (wstrb == 4'hF) or they return SLVERR.
module sf_albion_mmio (
  input  logic        clk,
  input  logic        rst_n,
  // DataFabric slave
  input  logic        req_valid,
  output logic        req_ready,
  input  logic [31:0] req_addr,
  input  logic        req_we,
  input  logic [31:0] req_wdata,
  input  logic [3:0]  req_wstrb,
  input  logic [1:0]  req_id,
  output logic        rsp_valid,
  output logic [31:0] rsp_rdata,
  output logic [2:0]  rsp_err,
  output logic [1:0]  rsp_id,
  // register fan-out
  output logic        rg_we,
  output logic        rg_re,
  output logic [11:0] rg_off,
  output logic [31:0] rg_wdata,
  output logic [1:0]  rg_master,
  output logic [5:0]  rg_page_sel,     // one-hot: MGMT IRQ DMA PERM TELEM RAS
  input  logic [6*32-1:0] pg_rdata,
  input  logic [6*3-1:0]  pg_err
);
  logic        hs;
  logic [3:0]  page;
  logic        page_ok, strobe_ok;
  logic [31:0] rdata_mux;
  logic [2:0]  err_mux;

  assign req_ready = 1'b1;
  assign hs        = req_valid;
  assign page      = req_addr[15:12];
  assign page_ok   = (page <= 4'd5);
  assign strobe_ok = !req_we || (req_wstrb == 4'hF);

  always_comb begin
    rg_page_sel = '0;
    if (hs && page_ok && strobe_ok) rg_page_sel[page[2:0]] = 1'b1;
  end

  assign rg_we     = hs && req_we && page_ok && strobe_ok;
  assign rg_re     = hs && !req_we && page_ok;
  assign rg_off    = {req_addr[11:2], 2'b00};
  assign rg_wdata  = req_wdata;
  assign rg_master = req_id;

  always_comb begin
    rdata_mux = 32'h0;
    err_mux   = sf_albion_regs_pkg::FE_DECERR;
    if (page_ok) begin
      rdata_mux = pg_rdata[32'(page)*32 +: 32];
      err_mux   = pg_err[32'(page)*3 +: 3];
    end
    if (page_ok && !strobe_ok) err_mux = sf_albion_regs_pkg::FE_SLVERR;
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      rsp_valid <= 1'b0;
      rsp_rdata <= '0;
      rsp_err   <= '0;
      rsp_id    <= '0;
    end else begin
      rsp_valid <= hs;
      rsp_rdata <= req_we ? 32'h0 : rdata_mux;
      rsp_err   <= err_mux;
      rsp_id    <= req_id;
    end
  end
endmodule
