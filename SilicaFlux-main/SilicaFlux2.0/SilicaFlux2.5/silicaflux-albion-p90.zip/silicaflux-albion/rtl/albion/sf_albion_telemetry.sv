// SilicaFlux Albion - 64-bit event counters.
// Reading CNT_LO[i] snapshots counter i for the reading master; CNT_HI[i] then
// returns that snapshot's upper half (per-master snapshots for CORE and HOST so
// concurrent readers cannot tear each other's values).
module sf_albion_telemetry #(
  parameter int NC = 48
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          rg_we,
  input  logic          rg_re,
  input  logic [11:0]   rg_off,
  input  logic [31:0]   rg_wdata,
  input  logic [1:0]    rg_master,
  output logic [31:0]   rg_rdata,
  output logic [2:0]    rg_err,
  input  logic [NC*4-1:0] inc_i    // per-counter increment this cycle
);
  logic [NC*64-1:0] cnt;
  logic             freeze;
  logic [31:0]      snap_core, snap_host;

  logic in_cnt;
  integer   cidx;
  assign in_cnt = (rg_off >= 12'h100) && (rg_off < 12'h100 + 12'(NC * 8));
  logic [11:0] coff;
  assign coff   = rg_off - 12'h100;
  assign cidx   = 32'(coff[11:3]);

  always_comb begin
    rg_rdata = 32'h0;
    rg_err   = sf_albion_regs_pkg::FE_OK;
    if (in_cnt) begin
      if (rg_off[2] == 1'b0) rg_rdata = cnt[cidx*64 +: 32];
      else rg_rdata = (rg_master == 2'(sf_albion_regs_pkg::M_HOST)) ? snap_host : snap_core;
      if (rg_we) rg_err = sf_albion_regs_pkg::FE_SLVERR;
    end else begin
      case (rg_off)
        sf_albion_regs_pkg::TELEM_CTRL:         rg_rdata = {31'h0, freeze};
        sf_albion_regs_pkg::TELEM_NUM_COUNTERS: begin rg_rdata = 32'(NC); if (rg_we) rg_err = sf_albion_regs_pkg::FE_SLVERR; end
        default: rg_err = sf_albion_regs_pkg::FE_DECERR;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      cnt       <= '0;
      freeze    <= 1'b0;
      snap_core <= '0;
      snap_host <= '0;
    end else begin
      logic clear;
      clear = rg_we && (rg_off == sf_albion_regs_pkg::TELEM_CTRL) && rg_wdata[1];
      if (rg_we && rg_off == sf_albion_regs_pkg::TELEM_CTRL) freeze <= rg_wdata[0];
      for (int i = 0; i < NC; i++) begin
        if (clear)        cnt[i*64 +: 64] <= 64'h0;
        else if (!freeze) cnt[i*64 +: 64] <= cnt[i*64 +: 64] + {60'h0, inc_i[i*4 +: 4]};
      end
      if (rg_re && in_cnt && rg_off[2] == 1'b0) begin
        if (rg_master == 2'(sf_albion_regs_pkg::M_HOST)) snap_host <= cnt[cidx*64 + 32 +: 32];
        else                                             snap_core <= cnt[cidx*64 + 32 +: 32];
      end
    end
  end
endmodule
