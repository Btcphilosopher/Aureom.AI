// SilicaFlux Albion - common DataFabric (crossbar) with integrated permission unit.
//
// Masters (fixed roles, see spec/albion/regmap.json):
//   0 CORE   privileged ControlCore, domain 0
//   1 DMARD  DMA read port   (domain = DMA.DOMAIN, window-checked)
//   2 DMAWR  DMA write port  (domain = DMA.DOMAIN, window-checked)
//   3 HOST   host MMIO       (domain 1, fixed policy)
// Slaves: SRAM bank 0..NB-1, MMIO (index NB), HOSTMEM (index NB+1).
//
// Protocol (per port): valid/ready request handshake; exactly one outstanding
// request per master (enforced by the masters, asserted in simulation); the
// response returns as a single-cycle rsp_valid pulse. Slaves echo the master id
// so they may pipeline.
//
// Every request is decoded and permission-checked BEFORE arbitration. Undecoded
// addresses get DECERR, denied ones get PERM; in both cases no slave is touched
// and the fabric responds itself in the next cycle. Decoding is exact: addresses
// beyond populated SRAM never alias into it.
//
// Hardware invariants that no window can override:
//   * DMA never reaches firmware-private SRAM banks, MMIO, or anything undecoded.
//   * DMA in domain HOST_ADMIN (1) is always denied.
//   * DMA in domain FIRMWARE (0) may reach SRAM data banks only (scrubbing), never host memory.
//   * HOST may only reach the MGMT page (rw), TELEM/RAS pages (read), and SRAM
//     while boot_mode is set (core held in reset and boot not locked).
module sf_albion_datafabric #(
  parameter int NB         = 4,
  parameter int BANK_BYTES = 16384,
  parameter int NW         = 8,
  parameter int NS         = NB + 2,   // derived - do not override
  parameter int NM         = 4         // fixed by the master role table
) (
  input  logic              clk,
  input  logic              rst_n,
  // masters
  input  logic [NM-1:0]     m_req_valid,
  output logic [NM-1:0]     m_req_ready,
  input  logic [NM*32-1:0]  m_req_addr,
  input  logic [NM-1:0]     m_req_we,
  input  logic [NM*32-1:0]  m_req_wdata,
  input  logic [NM*4-1:0]   m_req_wstrb,
  input  logic [NM*4-1:0]   m_req_domain,
  output logic [NM-1:0]     m_rsp_valid,
  output logic [NM*32-1:0]  m_rsp_rdata,
  output logic [NM*3-1:0]   m_rsp_err,
  // permission state
  input  logic [NW*32-1:0]  win_base,
  input  logic [NW*32-1:0]  win_limit,
  input  logic [NW*12-1:0]  win_attr,     // [0] valid [1] R [2] W [11:8] domain
  input  logic              boot_mode,
  // slaves
  output logic [NS-1:0]     s_req_valid,
  input  logic [NS-1:0]     s_req_ready,
  output logic [NS*32-1:0]  s_req_addr,
  output logic [NS-1:0]     s_req_we,
  output logic [NS*32-1:0]  s_req_wdata,
  output logic [NS*4-1:0]   s_req_wstrb,
  output logic [NS*4-1:0]   s_req_domain,
  output logic [NS*2-1:0]   s_req_id,
  input  logic [NS-1:0]     s_rsp_valid,
  input  logic [NS*32-1:0]  s_rsp_rdata,
  input  logic [NS*3-1:0]   s_rsp_err,
  input  logic [NS*2-1:0]   s_rsp_id,
  // events
  output logic              viol_o,
  output logic [31:0]       viol_addr_o,
  output logic [1:0]        viol_master_o,
  output logic [3:0]        viol_domain_o,
  output logic              viol_we_o,
  output logic              decerr_o,
  output logic [NM-1:0]     ev_m_txn_o,
  output logic [NM-1:0]     ev_m_stall_o,
  output logic [NS-1:0]     ev_s_txn_o,
  output logic              ev_bank_conflict_o
);
  localparam int BANK_SHIFT = $clog2(BANK_BYTES);
  localparam int SW         = $clog2(NS);
  localparam logic [32:0] SRAM_BYTES = 33'(NB) * 33'(BANK_BYTES);
  localparam int FWB        = 32'(sf_albion_regs_pkg::FW_PRIVATE_BANKS);

  // ---------------------------------------------------------------- decode + permission
  logic [NM-1:0]    dec_ok;       // address maps to a slave
  logic [NM-1:0]    perm_ok;      // master may perform this access
  logic [NM*SW-1:0] tgt;          // target slave

  always_comb begin
    dec_ok  = '0;
    perm_ok = '0;
    tgt     = '0;
    for (int m = 0; m < NM; m++) begin
      logic [31:0] a;
      logic [31:0] aw;            // word-aligned address
      logic        we;
      logic [3:0]  dom;
      logic        is_sram, is_mmio, is_host;
      logic [3:0]  page;
      integer          bank;
      logic        win_hit;
      a       = m_req_addr[m*32 +: 32];
      aw      = {a[31:2], 2'b00};
      we      = m_req_we[m];
      dom     = m_req_domain[m*4 +: 4];
      is_sram = {1'b0, a} < SRAM_BYTES;
      is_mmio = (a[31:16] == 16'h4000);
      is_host = a[31];
      page    = a[15:12];
      bank    = 32'(a >> BANK_SHIFT);

      win_hit = 1'b0;
      for (int w = 0; w < NW; w++) begin
        logic [11:0] at;
        at = win_attr[w*12 +: 12];
        if (at[0] && (at[11:8] == dom) && (we ? at[2] : at[1]) &&
            ({1'b0, aw} >= {1'b0, win_base[w*32 +: 32]}) &&
            ({1'b0, aw} + 33'd3 <= {1'b0, win_limit[w*32 +: 32]}))
          win_hit = 1'b1;
      end

      if (is_sram) begin
        dec_ok[m]          = 1'b1;
        tgt[m*SW +: SW]    = SW'(bank);
      end else if (is_mmio) begin
        dec_ok[m]          = 1'b1;
        tgt[m*SW +: SW]    = SW'(NB);
      end else if (is_host) begin
        dec_ok[m]          = 1'b1;
        tgt[m*SW +: SW]    = SW'(NB + 1);
      end

      case (m)
        sf_albion_regs_pkg::M_CORE: perm_ok[m] = 1'b1;
        sf_albion_regs_pkg::M_HOST: perm_ok[m] =
            (is_mmio && (page == sf_albion_regs_pkg::PAGE_MGMT)) ||
            (is_mmio && !we && ((page == sf_albion_regs_pkg::PAGE_TELEM) || (page == sf_albion_regs_pkg::PAGE_RAS))) ||
            (is_sram && boot_mode);
        default: begin // DMA ports
          logic data_bank;
          data_bank = is_sram && (bank >= FWB);
          if (dom == sf_albion_regs_pkg::DOM_FIRMWARE)        perm_ok[m] = data_bank;
          else if (dom == sf_albion_regs_pkg::DOM_HOST_ADMIN) perm_ok[m] = 1'b0;
          else                                                 perm_ok[m] = (data_bank || is_host) && win_hit;
        end
      endcase
    end
  end

  // ---------------------------------------------------------------- per-slave round-robin
  logic [NS*NM-1:0] req_vec;
  logic [NS-1:0]    gnt_valid;
  logic [NS*2-1:0]  gnt_id;
  logic [NS*2-1:0]  rr_ptr;

  always_comb begin
    req_vec = '0;
    for (int s = 0; s < NS; s++)
      for (int m = 0; m < NM; m++)
        req_vec[s*NM + m] = m_req_valid[m] && dec_ok[m] && perm_ok[m] && (32'(tgt[m*SW +: SW]) == s);
  end

  always_comb begin
    gnt_valid = '0;
    gnt_id    = '0;
    for (int s = 0; s < NS; s++) begin
      for (int k = 0; k < NM; k++) begin
        logic [1:0] m;
        m = rr_ptr[s*2 +: 2] + 2'(k);
        if (!gnt_valid[s] && req_vec[s*NM + 32'(m)]) begin
          gnt_valid[s]     = 1'b1;
          gnt_id[s*2 +: 2] = m;
        end
      end
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) rr_ptr <= '0;
    else
      for (int s = 0; s < NS; s++)
        if (gnt_valid[s] && s_req_ready[s]) rr_ptr[s*2 +: 2] <= gnt_id[s*2 +: 2] + 2'd1;
  end

  always_comb begin
    for (int s = 0; s < NS; s++) begin
      integer g;
      g = 32'(gnt_id[s*2 +: 2]);
      s_req_valid[s]           = gnt_valid[s];
      s_req_addr[s*32 +: 32]   = m_req_addr[g*32 +: 32];
      s_req_we[s]              = m_req_we[g];
      s_req_wdata[s*32 +: 32]  = m_req_wdata[g*32 +: 32];
      s_req_wstrb[s*4 +: 4]    = m_req_wstrb[g*4 +: 4];
      s_req_domain[s*4 +: 4]   = m_req_domain[g*4 +: 4];
      s_req_id[s*2 +: 2]       = gnt_id[s*2 +: 2];
    end
  end

  // ---------------------------------------------------------------- master ready + local error responder
  logic [NM-1:0]   err_now;      // request answered by the fabric itself
  logic [NM-1:0]   err_q;
  logic [NM*3-1:0] err_code_q;

  always_comb begin
    for (int m = 0; m < NM; m++) begin
      integer s;
      s = 32'(tgt[m*SW +: SW]);
      err_now[m] = m_req_valid[m] && !(dec_ok[m] && perm_ok[m]);
      if (err_now[m])
        m_req_ready[m] = 1'b1;
      else
        m_req_ready[m] = dec_ok[m] && gnt_valid[s] && (32'(gnt_id[s*2 +: 2]) == m) && s_req_ready[s];
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      err_q      <= '0;
      err_code_q <= '0;
    end else begin
      for (int m = 0; m < NM; m++) begin
        err_q[m] <= err_now[m];
        err_code_q[m*3 +: 3] <= dec_ok[m] ? sf_albion_regs_pkg::FE_PERM : sf_albion_regs_pkg::FE_DECERR;
      end
    end
  end

  // ---------------------------------------------------------------- response routing
  always_comb begin
    for (int m = 0; m < NM; m++) begin
      m_rsp_valid[m]          = err_q[m];
      m_rsp_rdata[m*32 +: 32] = 32'h0;
      m_rsp_err[m*3 +: 3]     = err_code_q[m*3 +: 3];
      for (int s = 0; s < NS; s++) begin
        if (s_rsp_valid[s] && (32'(s_rsp_id[s*2 +: 2]) == m)) begin
          m_rsp_valid[m]          = 1'b1;
          m_rsp_rdata[m*32 +: 32] = s_rsp_rdata[s*32 +: 32];
          m_rsp_err[m*3 +: 3]     = s_rsp_err[s*3 +: 3];
        end
      end
    end
  end

  // ---------------------------------------------------------------- events
  always_comb begin
    viol_o        = 1'b0;
    viol_addr_o   = '0;
    viol_master_o = '0;
    viol_domain_o = '0;
    viol_we_o     = 1'b0;
    decerr_o      = 1'b0;
    for (int m = NM - 1; m >= 0; m--) begin
      if (err_now[m] && dec_ok[m]) begin
        viol_o        = 1'b1;
        viol_addr_o   = m_req_addr[m*32 +: 32];
        viol_master_o = 2'(m);
        viol_domain_o = m_req_domain[m*4 +: 4];
        viol_we_o     = m_req_we[m];
      end
      if (err_now[m] && !dec_ok[m]) decerr_o = 1'b1;
    end
    for (int m = 0; m < NM; m++) begin
      ev_m_txn_o[m]   = m_req_valid[m] && m_req_ready[m];
      ev_m_stall_o[m] = m_req_valid[m] && !m_req_ready[m];
    end
    ev_bank_conflict_o = 1'b0;
    for (int s = 0; s < NS; s++) begin
      integer n;
      n = 0;
      for (int m = 0; m < NM; m++) n = n + 32'(req_vec[s*NM + m]);
      ev_s_txn_o[s] = gnt_valid[s] && s_req_ready[s];
      if (s < NB && n > 1) ev_bank_conflict_o = 1'b1;
    end
  end

`ifndef SYNTHESIS
  // one-outstanding-request protocol check
  logic [NM-1:0] outstanding;
  always_ff @(posedge clk) begin
    if (!rst_n) outstanding <= '0;
    else begin
      for (int m = 0; m < NM; m++) begin
        if (m_req_valid[m] && m_req_ready[m] && outstanding[m] && !m_rsp_valid[m])
          $error("datafabric: master %0d issued a second outstanding request", m);
        if (m_rsp_valid[m] && !outstanding[m])
          $error("datafabric: response to master %0d with nothing outstanding", m);
        case ({m_req_valid[m] && m_req_ready[m], m_rsp_valid[m]})
          2'b10: outstanding[m] <= 1'b1;
          2'b01: outstanding[m] <= 1'b0;
          default: ;
        endcase
      end
    end
  end
`endif
endmodule
