// SilicaFlux Albion - host interface.
//
// Two independent paths:
//  * Host MMIO target (host -> device): becomes DataFabric master HOST with domain
//    HOST_ADMIN. In silicon this is fed by a PCIe endpoint's BAR target interface
//    (licensed/hard IP, not part of this repository); in simulation the Verilator
//    harness drives it.
//  * Host memory requester (device -> host): DataFabric slave for the HOSTMEM
//    window. Address is translated to a host IOVA (addr - HOSTMEM_BASE). One
//    outstanding request; the external port may take any number of cycles. In
//    silicon this feeds the PCIe requester interface behind the host IOMMU.
module sf_albion_host_if (
  input  logic        clk,
  input  logic        rst_n,
  // external host MMIO target port
  input  logic        h_req_valid_i,
  output logic        h_req_ready_o,
  input  logic [31:0] h_req_addr_i,
  input  logic        h_req_we_i,
  input  logic [31:0] h_req_wdata_i,
  input  logic [3:0]  h_req_wstrb_i,
  output logic        h_rsp_valid_o,
  output logic [31:0] h_rsp_rdata_o,
  output logic [2:0]  h_rsp_err_o,
  // fabric master side
  output logic        m_req_valid,
  input  logic        m_req_ready,
  output logic [31:0] m_req_addr,
  output logic        m_req_we,
  output logic [31:0] m_req_wdata,
  output logic [3:0]  m_req_wstrb,
  input  logic        m_rsp_valid,
  input  logic [31:0] m_rsp_rdata,
  input  logic [2:0]  m_rsp_err,
  // fabric slave side (HOSTMEM)
  input  logic        s_req_valid,
  output logic        s_req_ready,
  input  logic [31:0] s_req_addr,
  input  logic        s_req_we,
  input  logic [31:0] s_req_wdata,
  input  logic [3:0]  s_req_wstrb,
  input  logic [1:0]  s_req_id,
  output logic        s_rsp_valid,
  output logic [31:0] s_rsp_rdata,
  output logic [2:0]  s_rsp_err,
  output logic [1:0]  s_rsp_id,
  // external host memory port
  output logic        hm_req_valid_o,
  input  logic        hm_req_ready_i,
  output logic [30:0] hm_req_addr_o,
  output logic        hm_req_we_o,
  output logic [31:0] hm_req_wdata_o,
  output logic [3:0]  hm_req_wstrb_o,
  input  logic        hm_rsp_valid_i,
  input  logic [31:0] hm_rsp_rdata_i,
  input  logic        hm_rsp_err_i
);
  // host MMIO: straight pass-through (the host model honours one outstanding request)
  assign m_req_valid   = h_req_valid_i;
  assign h_req_ready_o = m_req_ready;
  assign m_req_addr    = h_req_addr_i;
  assign m_req_we      = h_req_we_i;
  assign m_req_wdata   = h_req_wdata_i;
  assign m_req_wstrb   = h_req_wstrb_i;
  assign h_rsp_valid_o = m_rsp_valid;
  assign h_rsp_rdata_o = m_rsp_rdata;
  assign h_rsp_err_o   = m_rsp_err;

  // host memory requester
  logic       busy;
  logic [1:0] id_q;
  logic       we_q;
  // a new request may issue in the cycle the previous response returns (no bubble:
  // one request per host-latency period, as for the SRAM banks)
  logic slot_free;
  assign slot_free      = !busy || hm_rsp_valid_i;
  assign s_req_ready    = slot_free && hm_req_ready_i;
  assign hm_req_valid_o = s_req_valid && slot_free;
  assign hm_req_addr_o  = s_req_addr[30:0];
  assign hm_req_we_o    = s_req_we;
  assign hm_req_wdata_o = s_req_wdata;
  assign hm_req_wstrb_o = s_req_wstrb;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      busy <= 1'b0;
      id_q <= '0;
      we_q <= 1'b0;
    end else begin
      if (s_req_valid && s_req_ready) begin
        busy <= 1'b1;
        id_q <= s_req_id;
        we_q <= s_req_we;
      end else if (hm_rsp_valid_i) begin
        busy <= 1'b0;
      end
    end
  end

  assign s_rsp_valid = busy && hm_rsp_valid_i;
  assign s_rsp_rdata = we_q ? 32'h0 : hm_rsp_rdata_i;
  assign s_rsp_err   = hm_rsp_err_i ? sf_albion_regs_pkg::FE_HOSTERR : sf_albion_regs_pkg::FE_OK;
  assign s_rsp_id    = id_q;
endmodule
