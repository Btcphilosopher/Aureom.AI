// SilicaFlux Albion - permission unit register file: domain window table and
// violation log. The checking logic lives in the DataFabric (per request, before
// arbitration) so that a denied access never reaches a slave.
module sf_albion_perm #(
  parameter int NW = 8
) (
  input  logic             clk,
  input  logic             rst_n,
  input  logic             rg_we,
  input  logic [11:0]      rg_off,
  input  logic [31:0]      rg_wdata,
  output logic [31:0]      rg_rdata,
  output logic [2:0]       rg_err,
  // violation events from the fabric
  input  logic             viol_i,
  input  logic [31:0]      viol_addr_i,
  input  logic [1:0]       viol_master_i,
  input  logic [3:0]       viol_domain_i,
  input  logic             viol_we_i,
  // window table to the fabric
  output logic [NW*32-1:0] win_base_o,
  output logic [NW*32-1:0] win_limit_o,
  output logic [NW*12-1:0] win_attr_o
);
  logic [31:0] viol_count, viol_addr;
  logic [31:0] viol_info;

  logic        in_win;
  integer          widx;
  logic [3:0]  wreg;
  assign in_win = (rg_off >= 12'h100) && (rg_off < 12'h100 + 12'(NW * 16));
  logic [11:0] woff;
  assign woff   = rg_off - 12'h100;
  assign widx   = 32'(woff[11:4]);
  assign wreg   = rg_off[3:0];

  always_comb begin
    rg_rdata = 32'h0;
    rg_err   = sf_albion_regs_pkg::FE_OK;
    if (in_win) begin
      case (wreg)
        4'h0: rg_rdata = win_base_o[widx*32 +: 32];
        4'h4: rg_rdata = win_limit_o[widx*32 +: 32];
        4'h8: rg_rdata = {20'h0, win_attr_o[widx*12 +: 12]};
        default: rg_err = sf_albion_regs_pkg::FE_DECERR;
      endcase
    end else begin
      case (rg_off)
        sf_albion_regs_pkg::PERM_NUM_WIN:    rg_rdata = 32'(NW);
        sf_albion_regs_pkg::PERM_VIOL_COUNT: rg_rdata = viol_count;
        sf_albion_regs_pkg::PERM_VIOL_ADDR:  rg_rdata = viol_addr;
        sf_albion_regs_pkg::PERM_VIOL_INFO:  rg_rdata = viol_info;
        sf_albion_regs_pkg::PERM_VIOL_CLEAR: rg_rdata = 32'h0;
        default: rg_err = sf_albion_regs_pkg::FE_DECERR;
      endcase
      if (rg_we && rg_err == sf_albion_regs_pkg::FE_OK && rg_off != sf_albion_regs_pkg::PERM_VIOL_CLEAR)
        rg_err = sf_albion_regs_pkg::FE_SLVERR;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      win_base_o  <= '0;
      win_limit_o <= '0;
      win_attr_o  <= '0;      // all windows invalid after reset
      viol_count  <= '0;
      viol_addr   <= '0;
      viol_info   <= '0;
    end else begin
      if (rg_we && rg_err == sf_albion_regs_pkg::FE_OK) begin
        if (in_win) begin
          case (wreg)
            4'h0: win_base_o[widx*32 +: 32]  <= rg_wdata;
            4'h4: win_limit_o[widx*32 +: 32] <= rg_wdata;
            4'h8: win_attr_o[widx*12 +: 12]  <= {rg_wdata[11:8], 5'h0, rg_wdata[2:0]};
            default: ;
          endcase
        end else if (rg_off == sf_albion_regs_pkg::PERM_VIOL_CLEAR && rg_wdata[0]) begin
          viol_info[31] <= 1'b0;
        end
      end
      if (viol_i) begin
        if (viol_count != 32'hFFFF_FFFF) viol_count <= viol_count + 32'd1;
        if (!viol_info[31]) begin
          viol_addr <= viol_addr_i;
          viol_info <= {1'b1, 22'h0, viol_we_i, 2'h0, viol_master_i, viol_domain_i};
        end
      end
    end
  end
endmodule
