// SilicaFlux Albion - SECDED-protected SRAM bank (DataFabric slave).
//
// * Scrub-on-reset: after reset every word is written with encode(0) before the
//   bank accepts traffic (init_done). This initialises check bits and guarantees a
//   reset never leaks a previous tenant's data.
// * Latency: request accepted in cycle t, response in cycle t+1. A new request may
//   be accepted every cycle (pipelined) except during a read-modify-write.
// * Partial writes (wstrb != 4'hF) are read-modify-write: the old word is decoded
//   (corrected if needed), merged, re-encoded and written in cycle t+1; the bank
//   is not ready in that cycle. An uncorrectable old word aborts the write with
//   FE_ECC_UE.
// * Error injection: when armed, the next write to inj_word stores
//   encode(data) ^ inj_mask and pulses inj_hit_o.
// * ECC events are reported in the response cycle with syndrome / word / source.
module sf_albion_sram_bank #(
  parameter int WORDS = 4096,
  parameter int AW    = $clog2(WORDS)
) (
  input  logic          clk,
  input  logic          rst_n,
  // DataFabric slave port
  input  logic          req_valid,
  output logic          req_ready,
  input  logic [AW-1:0] req_word,
  input  logic          req_we,
  input  logic [31:0]   req_wdata,
  input  logic [3:0]    req_wstrb,
  input  logic [1:0]    req_id,
  input  logic [3:0]    req_domain,
  output logic          rsp_valid,
  output logic [31:0]   rsp_rdata,
  output logic [2:0]    rsp_err,
  output logic [1:0]    rsp_id,
  // error injection
  input  logic          inj_arm,
  input  logic [AW-1:0] inj_word,
  input  logic [38:0]   inj_mask,
  output logic          inj_hit_o,
  // ECC events (valid in the response cycle)
  output logic          ecc_ce_o,
  output logic          ecc_ue_o,
  output logic [6:0]    ecc_syndrome_o,
  output logic [AW-1:0] ecc_word_o,
  output logic [1:0]    ecc_master_o,
  output logic [3:0]    ecc_domain_o,
  output logic          init_done_o
);
  // ---------------------------------------------------------------- scrub on reset
  logic          init_done;
  logic [AW-1:0] init_cnt;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      init_done <= 1'b0;
      init_cnt  <= '0;
    end else if (!init_done) begin
      init_cnt <= init_cnt + 1'b1;
      if (init_cnt == AW'(WORDS - 1)) init_done <= 1'b1;
    end
  end
  assign init_done_o = init_done;

  // ---------------------------------------------------------------- stage 1 (response cycle)
  logic          s1_valid, s1_we, s1_rmw;
  logic [AW-1:0] s1_word;
  logic [31:0]   s1_wdata;
  logic [3:0]    s1_wstrb;
  logic [1:0]    s1_id;
  logic [3:0]    s1_domain;

  logic          accept;
  assign req_ready = init_done && !(s1_valid && s1_rmw);
  assign accept    = req_valid && req_ready;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      s1_valid <= 1'b0;
      s1_we    <= 1'b0;
      s1_rmw   <= 1'b0;
      s1_word  <= '0;
      s1_wdata <= '0;
      s1_wstrb <= '0;
      s1_id    <= '0;
      s1_domain<= '0;
    end else begin
      s1_valid <= accept;
      if (accept) begin
        s1_we     <= req_we;
        s1_rmw    <= req_we && (req_wstrb != 4'hF);
        s1_word   <= req_word;
        s1_wdata  <= req_wdata;
        s1_wstrb  <= req_wstrb;
        s1_id     <= req_id;
        s1_domain <= req_domain;
      end
    end
  end

  // ---------------------------------------------------------------- macro + ECC
  logic          m_en, m_we;
  logic [AW-1:0] m_addr;
  logic [38:0]   m_wdata, m_rdata;

  logic [31:0]   enc_in;
  logic [38:0]   enc_out;
  logic [31:0]   dec_data;
  logic          dec_ce, dec_ue;
  logic [6:0]    dec_syn;
  logic [31:0]   merged;
  logic          inj_match_full, inj_match_rmw;

  sf_albion_secded_enc u_enc (.data_i(enc_in), .cw_o(enc_out));
  sf_albion_secded_dec u_dec (.cw_i(m_rdata), .data_o(dec_data), .ce_o(dec_ce), .ue_o(dec_ue), .syndrome_o(dec_syn));

  sf_albion_sram_macro #(.WORDS(WORDS), .W(39)) u_mem (
    .clk(clk), .en(m_en), .we(m_we), .addr(m_addr), .wdata(m_wdata), .rdata(m_rdata));

  always_comb begin
    for (int b = 0; b < 4; b++)
      merged[b*8 +: 8] = s1_wstrb[b] ? s1_wdata[b*8 +: 8] : dec_data[b*8 +: 8];
  end

  assign inj_match_full = inj_arm && accept && req_we && (req_wstrb == 4'hF) && (req_word == inj_word);
  assign inj_match_rmw  = inj_arm && s1_valid && s1_rmw && !dec_ue && (s1_word == inj_word);

  always_comb begin
    m_en    = 1'b0;
    m_we    = 1'b0;
    m_addr  = req_word;
    enc_in  = req_wdata;
    m_wdata = enc_out;
    if (!init_done) begin
      m_en    = 1'b1;
      m_we    = 1'b1;
      m_addr  = init_cnt;
      enc_in  = 32'h0;
      m_wdata = enc_out;
    end else if (s1_valid && s1_rmw) begin
      // second half of read-modify-write
      m_en    = !dec_ue;
      m_we    = 1'b1;
      m_addr  = s1_word;
      enc_in  = merged;
      m_wdata = enc_out ^ (inj_match_rmw ? inj_mask : 39'd0);
    end else if (accept) begin
      m_en    = 1'b1;
      m_we    = req_we && (req_wstrb == 4'hF);   // partial writes read first
      m_addr  = req_word;
      enc_in  = req_wdata;
      m_wdata = enc_out ^ (inj_match_full ? inj_mask : 39'd0);
    end
  end

  assign inj_hit_o = inj_match_full || inj_match_rmw;

  // ---------------------------------------------------------------- response
  logic s1_reads;   // response cycle consumed macro read data
  assign s1_reads = s1_valid && (!s1_we || s1_rmw);

  assign rsp_valid = s1_valid;
  assign rsp_id    = s1_id;
  assign rsp_rdata = s1_we ? 32'h0 : dec_data;
  assign rsp_err   = (s1_reads && dec_ue) ? sf_albion_regs_pkg::FE_ECC_UE : sf_albion_regs_pkg::FE_OK;

  assign ecc_ce_o       = s1_reads && dec_ce;
  assign ecc_ue_o       = s1_reads && dec_ue;
  assign ecc_syndrome_o = dec_syn;
  assign ecc_word_o     = s1_word;
  assign ecc_master_o   = s1_id;
  assign ecc_domain_o   = s1_domain;
endmodule
