# SilicaFlux Project 66 — INFERENCESCHEDULER

**Multi-tenant tensor accelerator scheduler** · Aureom.AI | SilicaFlux-CLOUD
Primary RTL: `rtl/silicaflux_inference_queue.sv`

This is a hardware scheduler that accepts INT8 GEMM work from multiple protected tenant queues and runs it on a single-issue SilicaFlux TensorCore. It returns completions that are isolated per tenant, and its scheduling policies are measured rather than assumed.

> **Integration status: BLOCKED on hardware.** No TensorCore, CloudDMA, MemoryPool or ControlCore source was present (`docs/REPO_AUDIT.md`). All results here come from simulation against **clearly labelled behavioural models** in `sim_models/`. See `docs/INTEGRATION_STATUS.md` for what is needed to unblock FPGA integration.

## What is supported (and advertised in CAPS)

- **Commands:** GEMM only, INT8 × INT8 → INT32, M/N/K up to 64. UINT8/BF16/FP16/FP32 encodings are rejected explicitly; there is no graph support.
- **Scheduling policies:**
  - round robin (baseline);
  - weighted round robin;
  - deficit round robin on measured TensorCore time;
  - strict priority with aging and a per-tenant priority cap;
  - deadline-hint ordering;
  - per-tenant token-bucket rate limiting and admission control.
- **Isolation:**
  - queue ownership via the doorbell;
  - ordered descriptor validation at intake *and* at dispatch;
  - a per-beat DMA permission gate keyed to the scheduler's own active tenant;
  - scratchpad scrub on owner change and after reset or recovery;
  - completion routing restricted to owned CQs;
  - fault quarantine.
- **Context switching:** command boundaries only. Suspend/resume preserves pending commands, transaction IDs, order and scheduler state. There is **no** mid-GEMM preemption, because the TensorCore has no state save/restore.

## Layout

```
rtl/          synthesisable RTL (10 files)
  silicaflux_inference_queue.sv  top level
  sf_iq_arbiter.sv               queue arbiter
  sf_iq_tenant_ctx.sv            tenant context register file
  sf_iq_tensor_adapter.sv        tensor command adapter
  sf_iq_perf_counters.sv         performance counters
  sf_iq_desc_validator.sv, sf_iq_dma_gate.sv, sf_iq_cpl_router.sv, sf_iq_fifo.sv, sf_iq_pkg.sv
sim_models/   SIMULATION MODELS ONLY (TensorCore, memory) — not for synthesis
tb/           self-checking testbench + benchmark harness (tb_top.sv)
host/         Python ABI helpers + layout cross-check against the RTL
scripts/      build, regression, mutation testing, benchmarks, synthesis estimate
docs/         architecture, ABI + registers, verification, benchmarks, audit, integration status
results/      regression results, mutation results, benchmark traces/metrics, synthesis report
```

## Reproduce

Requires Verilator ≥ 5.020 (`--timing`), Python 3 with matplotlib, and optionally Yosys + sv2v.

```bash
python3 scripts/run_tests.py               # 19 directed tests incl. negative control
python3 scripts/mutation_test.py           # 24 injected bugs, each must be killed
python3 scripts/run_benchmarks.py          # §8 scenarios -> results/bench, docs/BENCHMARK_REPORT.md
python3 scripts/make_report.py             # rebuild report + figures from results/bench
python3 host/test_abi.py                   # host ABI vs RTL struct layout
sv2v -DSYNTHESIS rtl/*.sv > build/synth/sfiq.v && yosys -s scripts/synth_yosys.ys
```

## Documents

- `docs/ARCHITECTURE.md` — pipeline, protection layers, policies, context switching, faults, limitations
- `docs/COMMAND_ABI_AND_REGISTERS.md` — descriptor, completion, status codes, TensorCore interface, register map
- `docs/VERIFICATION.md` — test plan and results, mutation testing, bugs found
- `docs/BENCHMARK_REPORT.md` — measured throughput, fairness, tail latency, overheads
- `docs/REPO_AUDIT.md`, `docs/INTEGRATION_STATUS.md`
