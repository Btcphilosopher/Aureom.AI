// =============================================================================
// SilicaFlux Project 66 — tb_top.sv
// Self-checking testbench + benchmark harness for silicaflux_inference_queue.
//
//   +TEST=<name>          run one directed test (see run_test() dispatch)
//   +BENCH=<file>         run a workload file (scripts/run_benchmarks.py)
//   +TRACE=<file>         per-completion CSV trace (bench mode)
//   +COUNTERS=<file>      final counter dump (bench mode)
//
// Scoreboard invariants checked on EVERY completion, in every test:
//   * the transaction id was submitted, and completes exactly once
//   * tenant, (expected) status and (expected) CQ match the submission
//   * the CQ is owned by the completion's tenant in the testbench's shadow
//   * OK results equal a golden INT8 GEMM computed from memory
// Residue monitor: whenever the TensorCore accepts a command for a tenant
// different from the previous one, the whole scratchpad must be zero.
//
// TestBench discipline: all stimulus is driven just after a negative clock
// edge; DUT outputs are sampled at negative edges or in posedge monitors.
// =============================================================================
`timescale 1ns/1ps
module tb_top;
  import sf_iq_pkg::*;

  parameter bit ALLOW_SCRUB_BYPASS = 1'b0;

  localparam int NQ = 4, NT = 4, NCQ = 4, QDEPTH = 8, NREG = 2;
  localparam int MEM_BYTES = 4 * 1024 * 1024;
  localparam int RBYTES    = 1024 * 1024;            // per-tenant region
  localparam int MAXCMD    = 16384;
  localparam int NSLOT     = 24;
  localparam int SLOT_B    = 16 * 1024;

  // ---------------------------------------------------------------------------
  // Clock / reset
  // ---------------------------------------------------------------------------
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------------------
  // DUT wiring
  // ---------------------------------------------------------------------------
  logic        csr_we = 1'b0;
  logic [15:0] csr_addr = '0;
  logic [31:0] csr_wdata = '0, csr_rdata;
  logic        sub_valid = 1'b0, sub_ready;
  logic [7:0]  sub_qid = '0;
  logic [255:0] sub_desc = '0;
  logic        cpl_valid, cpl_ready = 1'b1;
  logic [CPL_W-1:0] cpl_data;
  logic        tc_cmd_valid, tc_cmd_ready, tc_rsp_valid, tc_rsp_ready;
  tc_cmd_t     tc_cmd;
  tc_rsp_t     tc_rsp;
  logic        tc_scrub_req, tc_scrub_done, tc_soft_reset;
  logic [2:0]  tc_phase;
  logic        tcm_req_valid, tcm_req_ready, tcm_req_we, tcm_rsp_valid, tcm_rsp_err;
  logic [31:0] tcm_req_addr, tcm_req_wdata, tcm_rsp_rdata;
  logic        mem_req_valid, mem_req_ready, mem_req_we, mem_req_poison;
  logic [31:0] mem_req_addr, mem_req_wdata;
  logic        mem_rsp_valid, mem_rsp_err;
  logic [31:0] mem_rsp_rdata;
  logic        irq_err;

  // testbench-controlled environment knobs
  logic [7:0]  contention_pct = 8'd0;
  logic [31:0] mem_seed = 32'h0BAD_5EED;
  logic [7:0]  fi_domain = 8'hFF;
  logic [31:0] fi_oob_offset = 32'd0;
  logic [31:0] fi_wr_redirect = 32'd0;
  logic        fi_hang = 1'b0, fi_internal_err = 1'b0, fi_acc_no_clear = 1'b0;

  silicaflux_inference_queue #(
    .NQ(NQ), .NT(NT), .NCQ(NCQ), .QDEPTH(QDEPTH), .NREG(NREG),
    .ALLOW_SCRUB_BYPASS(ALLOW_SCRUB_BYPASS)
  ) u_dut (
    .clk, .rst_n,
    .csr_we, .csr_addr, .csr_wdata, .csr_rdata,
    .sub_valid, .sub_ready, .sub_qid, .sub_desc,
    .cpl_valid, .cpl_ready, .cpl_data,
    .tc_cmd_valid, .tc_cmd_ready, .tc_cmd, .tc_rsp_valid, .tc_rsp_ready, .tc_rsp,
    .tc_scrub_req, .tc_scrub_done, .tc_soft_reset, .tc_phase,
    .tcm_req_valid, .tcm_req_ready, .tcm_req_we, .tcm_req_addr, .tcm_req_wdata,
    .tcm_rsp_valid, .tcm_rsp_rdata, .tcm_rsp_err,
    .mem_req_valid, .mem_req_ready, .mem_req_we, .mem_req_addr, .mem_req_wdata, .mem_req_poison,
    .mem_rsp_valid, .mem_rsp_rdata, .mem_rsp_err,
    .irq_err
  );

  sim_tensorcore_model u_tc (
    .clk, .rst_n, .soft_reset(tc_soft_reset),
    .cmd_valid(tc_cmd_valid), .cmd_ready(tc_cmd_ready), .cmd(tc_cmd),
    .rsp_valid(tc_rsp_valid), .rsp_ready(tc_rsp_ready), .rsp(tc_rsp),
    .scrub_req(tc_scrub_req), .scrub_done(tc_scrub_done), .phase(tc_phase),
    .mem_req_valid(tcm_req_valid), .mem_req_ready(tcm_req_ready), .mem_req_we(tcm_req_we),
    .mem_req_addr(tcm_req_addr), .mem_req_wdata(tcm_req_wdata),
    .mem_rsp_valid(tcm_rsp_valid), .mem_rsp_rdata(tcm_rsp_rdata), .mem_rsp_err(tcm_rsp_err),
    .fi_domain, .fi_oob_offset, .fi_wr_redirect, .fi_hang, .fi_internal_err, .fi_acc_no_clear
  );

  sim_memory_model #(.MEM_BYTES(MEM_BYTES), .RD_LAT(4)) u_mem (
    .clk, .rst_n, .contention_pct, .seed(mem_seed),
    .req_valid(mem_req_valid), .req_ready(mem_req_ready), .req_we(mem_req_we),
    .req_addr(mem_req_addr), .req_wdata(mem_req_wdata), .req_poison(mem_req_poison),
    .rsp_valid(mem_rsp_valid), .rsp_rdata(mem_rsp_rdata), .rsp_err(mem_rsp_err)
  );

  // ---------------------------------------------------------------------------
  // Register map helpers
  // ---------------------------------------------------------------------------
  localparam logic [15:0] R_CTRL = 16'h0000, R_STATUS = 16'h0004, R_WD = 16'h0008,
                          R_QUANTUM = 16'h000C, R_AGING = 16'h0010, R_ERR = 16'h0014,
                          R_CAPS0 = 16'h0018, R_CAPS1 = 16'h001C, R_CAPS2 = 16'h0020,
                          R_CAPS3 = 16'h0024, R_FAULTADDR = 16'h002C;
  function automatic logic [15:0] RQ(int q, int off);  return 16'(16'h0100 + q*16 + off);  endfunction
  function automatic logic [15:0] RCQ(int c);          return 16'(16'h0200 + c*4);         endfunction
  function automatic logic [15:0] RT(int t, int off);  return 16'(16'h0400 + t*64 + off);  endfunction
  // counter indices
  localparam int G_CYCLES = 0, G_TC_BUSY = 1, G_TC_COMPUTE = 2, G_DMA_WAIT = 3, G_DMA_STALL = 4,
                 G_SCHED_OVH = 5, G_DISPATCH = 6, G_CTXSW_CYC = 7, G_CTXSW = 8, G_CPL_BP = 9,
                 G_IDLE = 10, G_DISPATCHED = 11, G_OK = 12, G_ERR = 13, G_REJ = 14, G_ABORT = 15,
                 G_MACS = 16, G_DROP = 17, G_QWAIT = 18, G_TIMEOUT = 19;
  localparam int T_OK = 0, T_MACS = 1, T_BUSY = 2, T_QWAIT = 3, T_QWAITMAX = 4, T_REJ = 5,
                 T_ERR = 6, T_DLMISS = 7, T_DISP = 8, T_SCRUB = 9;
  string g_names [20] = '{"CYCLES","TC_BUSY","TC_COMPUTE","DMA_WAIT","DMA_STALL","SCHED_OVERHEAD",
                          "DISPATCH","CTX_SWITCH_CYCLES","CTX_SWITCHES","CPL_BACKPRESSURE","IDLE",
                          "DISPATCHED","COMPLETED_OK","COMPLETED_ERR","REJECTED","ABORTED",
                          "USEFUL_MACS","CPL_DROPPED","QUEUE_WAIT_TOTAL","TIMEOUTS"};
  string t_names [10] = '{"COMPLETED_OK","MACS","BUSY_CYCLES","QUEUE_WAIT_TOTAL","QUEUE_WAIT_MAX",
                          "REJECTED","ERRORS","DEADLINE_MISS","DISPATCHED","SCRUB_CYCLES"};

  // ---------------------------------------------------------------------------
  // Scoreboard state
  // ---------------------------------------------------------------------------
  int      errors = 0;
  int      unsigned cyc = 0;
  bit      c_used [MAXCMD];
  bit      c_done [MAXCMD];
  bit      c_drop [MAXCMD];      // completion expected to be dropped (CQ revoked)
  int      c_tenant [MAXCMD], c_qid [MAXCMD], c_m [MAXCMD], c_n [MAXCMD], c_k [MAXCMD];
  int      c_prio [MAXCMD], c_dl [MAXCMD];
  int      unsigned c_a [MAXCMD], c_b [MAXCMD], c_c [MAXCMD], c_arrival [MAXCMD];
  int      c_exp_status [MAXCMD], c_exp_cq [MAXCMD];
  int      c_status [MAXCMD];
  int      unsigned c_tsub [MAXCMD], c_tdisp [MAXCMD], c_tcpl [MAXCMD];
  int      next_txn = 1;
  int      n_cpl = 0;
  int      cpl_order [MAXCMD];         // txn ids in completion order
  int      t_seq [NT];
  int      t_outstanding [NT];
  int      cq_owner_sh [NCQ];
  bit      cq_valid_sh [NCQ];
  bit      check_results = 1'b1;
  bit      expect_leaks  = 1'b0;
  int      leaks = 0;
  int      residue_violations = 0;
  int      last_tc_tenant = -1;
  int      trace_fd = 0;
  logic [31:0] rng = 32'hC0FF_EE11;

  `define CHECK(cond, msg) \
    if (!(cond)) begin errors++; $display("[%0t] CHECK FAILED: %s", $time, msg); end

  function automatic int unsigned rnd(int unsigned n);
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return (n == 0) ? 0 : (rng % n);
  endfunction

  function automatic int unsigned tbase(int t); return t * RBYTES; endfunction

  // ---------------------------------------------------------------------------
  // Memory backdoor + golden model
  // ---------------------------------------------------------------------------
  function automatic int sx8(logic [7:0] b); return int'($signed(b)); endfunction
  function automatic logic [31:0] mem32(int unsigned a);
    return {u_mem.mem[a+3], u_mem.mem[a+2], u_mem.mem[a+1], u_mem.mem[a]};
  endfunction

  function automatic int gemm_mismatches(int txn);
    int mism = 0;
    for (int i = 0; i < c_m[txn]; i++)
      for (int j = 0; j < c_n[txn]; j++) begin
        int s = 0;
        for (int kk = 0; kk < c_k[txn]; kk++)
          s += sx8(u_mem.mem[c_a[txn] + i*c_k[txn] + kk]) * sx8(u_mem.mem[c_b[txn] + kk*c_n[txn] + j]);
        if (mem32(c_c[txn] + 4*(i*c_n[txn] + j)) != 32'(s)) mism++;
      end
    return mism;
  endfunction

  function automatic bit spad_nonzero();
    for (int i = 0; i < 64*64; i++) begin
      if (u_tc.spad_a[i] != 8'h00) return 1'b1;
      if (u_tc.spad_b[i] != 8'h00) return 1'b1;
      if (u_tc.acc[i]    != 32'h0) return 1'b1;
    end
    return 1'b0;
  endfunction

  task automatic fill_operands(int t);
    for (int unsigned i = 0; i < 32*1024; i++) u_mem.mem[tbase(t) + i] = 8'(rnd(256));
    // "secret" area at the top of each region
    for (int unsigned i = RBYTES - 64*1024; i < RBYTES; i++) u_mem.mem[tbase(t) + i] = 8'(8'h50 + t);
  endtask

  function automatic int unsigned region_sum(int t, int unsigned off, int unsigned len);
    int unsigned s = 0;
    for (int unsigned i = 0; i < len; i++) s = s * 31 + u_mem.mem[tbase(t) + off + i];
    return s;
  endfunction

  // ---------------------------------------------------------------------------
  // Monitors
  // ---------------------------------------------------------------------------
  cpl_t mon_cpl;
  always @(posedge clk) begin
    cyc <= cyc + 1;
    if (rst_n && cpl_valid && cpl_ready) begin
      int txn;
      mon_cpl = cpl_t'(cpl_data);
      txn = int'(mon_cpl.txn_id);
      if (txn >= MAXCMD || !c_used[txn]) begin
        errors++; $display("[%0t] SCOREBOARD: unknown completion txn=%0d", $time, txn);
      end else if (c_done[txn]) begin
        errors++; $display("[%0t] SCOREBOARD: duplicate completion txn=%0d", $time, txn);
      end else begin
        c_done[txn]   = 1'b1;
        c_status[txn] = int'(mon_cpl.status);
        c_tsub[txn]   = mon_cpl.t_submit;
        c_tdisp[txn]  = mon_cpl.t_dispatch;
        c_tcpl[txn]   = mon_cpl.t_complete;
        cpl_order[n_cpl] = txn;
        n_cpl++;
        if (c_tenant[txn] >= 0 && c_tenant[txn] < NT) t_outstanding[c_tenant[txn]]--;
        if (c_drop[txn]) begin
          errors++; $display("[%0t] SCOREBOARD: txn=%0d should have been dropped", $time, txn);
        end
        if (int'(mon_cpl.tenant) != c_tenant[txn]) begin
          errors++; $display("[%0t] SCOREBOARD: txn=%0d tenant %0d expected %0d", $time, txn, mon_cpl.tenant, c_tenant[txn]);
        end
        if (c_exp_status[txn] >= 0 && int'(mon_cpl.status) != c_exp_status[txn]) begin
          errors++; $display("[%0t] SCOREBOARD: txn=%0d status 0x%02h expected 0x%02h", $time, txn, mon_cpl.status, c_exp_status[txn]);
        end
        if (c_exp_cq[txn] >= 0 && int'(mon_cpl.cq_id) != c_exp_cq[txn]) begin
          errors++; $display("[%0t] SCOREBOARD: txn=%0d cq %0d expected %0d", $time, txn, mon_cpl.cq_id, c_exp_cq[txn]);
        end
        if (mon_cpl.cq_id >= NCQ || !cq_valid_sh[mon_cpl.cq_id] || cq_owner_sh[mon_cpl.cq_id] != int'(mon_cpl.tenant)) begin
          errors++; $display("[%0t] ISOLATION: txn=%0d delivered to CQ %0d not owned by tenant %0d", $time, txn, mon_cpl.cq_id, mon_cpl.tenant);
        end
        if (check_results && mon_cpl.status == ST_OK) begin
          int mm = gemm_mismatches(txn);
          if (mm != 0) begin
            if (expect_leaks) leaks++;
            else begin
              errors++; $display("[%0t] RESULT: txn=%0d tenant=%0d %0dx%0dx%0d has %0d wrong elements", $time, txn, c_tenant[txn], c_m[txn], c_n[txn], c_k[txn], mm);
            end
          end
        end
        if (trace_fd != 0)
          $fwrite(trace_fd, "%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d\n",
                  txn, mon_cpl.tenant, mon_cpl.qid, mon_cpl.cq_id, mon_cpl.status,
                  c_m[txn], c_n[txn], c_k[txn], c_prio[txn], c_dl[txn], c_arrival[txn],
                  mon_cpl.t_submit, mon_cpl.t_dispatch, mon_cpl.t_complete);
      end
    end
    // scratchpad residue monitor
    if (rst_n && tc_cmd_valid && tc_cmd_ready) begin
      int t = int'(tc_cmd.domain);
      if (t != last_tc_tenant) begin
        if (spad_nonzero()) begin
          residue_violations++;
          if (!expect_leaks) begin
            errors++; $display("[%0t] ISOLATION: scratchpad not clean when tenant %0d took over from %0d", $time, t, last_tc_tenant);
          end
        end
      end
      last_tc_tenant = t;
    end
    // a poisoned beat must never be a write that reached memory
    if (rst_n && mem_req_valid && mem_req_ready && mem_req_poison && !u_dut.u_gate.fault) begin
      errors++; $display("[%0t] GATE: poisoned beat without fault report", $time);
    end
  end

  // ---------------------------------------------------------------------------
  // Host-side tasks
  // ---------------------------------------------------------------------------
  task automatic tick(int n = 1);
    repeat (n) @(negedge clk);
  endtask

  task automatic csr_wr(logic [15:0] a, logic [31:0] d);
    csr_we = 1'b1; csr_addr = a; csr_wdata = d;
    @(negedge clk);
    csr_we = 1'b0;
    if (a[15:8] == 8'h02) begin            // keep CQ ownership shadow for the scoreboard
      cq_valid_sh[(a - 16'h0200) / 4] = d[0];
      cq_owner_sh[(a - 16'h0200) / 4] = int'(d[11:8]);
    end
  endtask

  // combinational read: settle, sample, then re-align to the next falling edge
  // so that every host task returns exactly at a negedge (see submit_raw)
  task automatic csr_rd(logic [15:0] a, output logic [31:0] d);
    csr_addr = a; #1; d = csr_rdata;
    @(negedge clk);
  endtask

  task automatic cnt_g(int i, output longint unsigned v);
    logic [31:0] lo, hi;
    csr_rd(16'(16'h0800 + i*8), lo); csr_rd(16'(16'h0800 + i*8 + 4), hi);
    v = {hi, lo};
  endtask

  task automatic cnt_t(int t, int j, output longint unsigned v);
    logic [31:0] lo, hi;
    csr_rd(16'(16'h0C00 + t*128 + j*8), lo); csr_rd(16'(16'h0C00 + t*128 + j*8 + 4), hi);
    v = {hi, lo};
  endtask

  task automatic do_reset();
    rst_n = 1'b0;
    sub_valid = 1'b0; csr_we = 1'b0;
    tick(5);
    rst_n = 1'b1;
    tick(2);
    last_tc_tenant = -1;
    for (int i = 0; i < NCQ; i++) begin cq_valid_sh[i] = 1'b0; cq_owner_sh[i] = 0; end
    for (int t = 0; t < NT; t++) t_outstanding[t] = 0;
    // anything in flight before reset is gone: forget it
    for (int i = 0; i < MAXCMD; i++) begin c_used[i] = 1'b0; c_done[i] = 1'b0; c_drop[i] = 1'b0; end
  endtask

  // tenant t: region0 = its 1 MB slice (RW), owns queue q and CQ cq
  task automatic cfg_tenant(int t, int q, int cq, int prio_cap = 3, int weight = 1);
    csr_wr(RT(t, 'h18), tbase(t));
    csr_wr(RT(t, 'h1C), tbase(t) + RBYTES - 1);
    csr_wr(RT(t, 'h20), 32'h3);
    csr_wr(RCQ(cq), 32'h1 | (t << 8));
    csr_wr(RQ(q, 0), 32'h1 | (t << 8) | (cq << 16));
    csr_wr(RQ(q, 4), weight);
    csr_wr(RT(t, 'h00), 32'h1 | (prio_cap << 4));
  endtask

  task automatic set_ctrl(bit en, int pol, bit bypass = 1'b0);
    csr_wr(R_CTRL, {23'd0, bypass, 4'd0, 3'(pol), en});
  endtask

  task automatic std_setup(int ntenants, int pol = 0);
    for (int t = 0; t < ntenants; t++) begin
      cfg_tenant(t, t, t);
      fill_operands(t);
    end
    set_ctrl(1'b1, pol);
  endtask

  function automatic desc_t mk_desc(int t, int m, int n, int k, int unsigned a, int unsigned b,
                                    int unsigned c, int prio, int dl, int cq, int txn);
    desc_t d = '0;
    d.opcode = OP_GEMM; d.numfmt = FMT_INT8; d.acc_prec = ACC_INT32;
    d.m = 16'(m); d.n = 16'(n); d.k = 16'(k);
    d.a_addr = a; d.b_addr = b; d.c_addr = c;
    d.tenant_id = 8'(t); d.prio = 2'(prio); d.txn_id = 16'(txn); d.cq_id = 8'(cq);
    d.deadline = 24'(dl);
    return d;
  endfunction

  // raw submission: call right after a negedge; returns right after a negedge
  bit dbg = 1'b0;
  localparam int CLK_PERIOD = 10;   // ns; falling edges at exact multiples
  task automatic submit_raw(int q, desc_t d);
    if (($time % CLK_PERIOD) != 0) begin
      errors++; $display("[%0t] TB SYNC ERROR: submit_raw called off the falling edge", $time);
      @(negedge clk);
    end
    if (dbg) $display("[%0t] submit_raw q=%0d txn=%0d m=%0d n=%0d k=%0d", $time, q, d.txn_id, d.m, d.n, d.k);
    sub_valid = 1'b1; sub_qid = 8'(q); sub_desc = d;
    while (!sub_ready) @(negedge clk);
    @(negedge clk);
    sub_valid = 1'b0;
  endtask

  // record + submit an arbitrary descriptor
  task automatic submit_desc(int q, desc_t d, int exp_tenant, int exp_status, int exp_cq);
    int txn = int'(d.txn_id);
    c_used[txn] = 1'b1; c_done[txn] = 1'b0; c_drop[txn] = 1'b0;
    c_tenant[txn] = exp_tenant; c_qid[txn] = q;
    c_m[txn] = int'(d.m); c_n[txn] = int'(d.n); c_k[txn] = int'(d.k);
    c_a[txn] = d.a_addr; c_b[txn] = d.b_addr; c_c[txn] = d.c_addr;
    c_prio[txn] = int'(d.prio); c_dl[txn] = int'(d.deadline);
    c_exp_status[txn] = exp_status; c_exp_cq[txn] = exp_cq;
    c_arrival[txn] = u_dut.now;
    if (exp_tenant >= 0 && exp_tenant < NT) t_outstanding[exp_tenant]++;
    submit_raw(q, d);
  endtask

  function automatic int alloc_txn();
    int t = next_txn;
    next_txn = (next_txn + 1 >= MAXCMD) ? 1 : next_txn + 1;
    return t;
  endfunction

  // standard GEMM from tenant t's operand pools into its next C slot
  task automatic gemm(int t, int q, int m, int n, int k, output int txn,
                      input int prio = 0, input int dl = 0, input int cq = -1,
                      input int exp_status = 0);
    int unsigned a, b, c;
    int cqe = (cq < 0) ? t : cq;
    txn = alloc_txn();
    a = tbase(t) +            4 * rnd((16*1024 - m*k) / 4 + 1);
    b = tbase(t) + 16*1024 +  4 * rnd((16*1024 - k*n) / 4 + 1);
    c = tbase(t) + 512*1024 + SLOT_B * (t_seq[t] % NSLOT);
    t_seq[t]++;
    submit_desc(q, mk_desc(t, m, n, k, a, b, c, prio, dl, cqe, txn), t, exp_status, cqe);
  endtask

  task automatic wait_txn(int txn, int timeout = 2_000_000);
    int w = 0;
    forever begin
      if (c_done[txn] || w >= timeout) break;
      tick(); w++;
    end
    `CHECK(c_done[txn], $sformatf("timeout waiting for txn %0d", txn))
  endtask

  function automatic int pending_cnt();
    int p = 0;
    for (int i = 0; i < MAXCMD; i++) if (c_used[i] && !c_done[i] && !c_drop[i]) p++;
    return p;
  endfunction

  task automatic wait_all(int timeout = 5_000_000);
    int w, p;
    w = 0;
    forever begin
      p = pending_cnt();
      if (p == 0 || w >= timeout) break;
      if (dbg && (w % 4096 == 0)) $display("[%0t] wait_all w=%0d pending=%0d now=%0d", $time, w, p, u_dut.now);
      tick(16);
      w = w + 16;
    end
    `CHECK(pending_cnt() == 0, $sformatf("timeout: %0d commands never completed", pending_cnt()))
  endtask

  // =============================================================================
  // DIRECTED TESTS
  // =============================================================================

  // T01 — single tenant, a sweep of GEMM shapes, CAPS advertisement
  task automatic t_single_gemm();
    int txn;
    int dims [8][3] = '{'{1,1,1}, '{4,4,4}, '{5,7,3}, '{16,16,16}, '{64,64,64}, '{3,64,1}, '{64,1,64}, '{17,9,33}};
    longint unsigned ok, macs, exp_macs = 0;
    logic [31:0] v;
    std_setup(1);
    if (dbg) $display("[%0t] setup done", $time);
    csr_rd(R_CAPS1, v);
    `CHECK(v[0] && v[4] && v[8] && !v[20], "CAPS1 must advertise GEMM/INT8/INT32 and no mid-GEMM preemption")
    `CHECK(v[24] == ALLOW_SCRUB_BYPASS, "CAPS1 scrub-bypass bit must reflect build parameter")
    csr_rd(R_CAPS2, v);
    `CHECK(v == {16'd64, 16'd64}, "CAPS2 max dims")
    foreach (dims[i]) begin
      if (dbg) $display("[%0t] gemm %0d", $time, i);
      gemm(0, 0, dims[i][0], dims[i][1], dims[i][2], txn);
      exp_macs += dims[i][0] * dims[i][1] * dims[i][2];
    end
    if (dbg) $display("[%0t] all submitted", $time);
    wait_all();
    cnt_g(G_OK, ok); cnt_g(G_MACS, macs);
    `CHECK(ok == 8, $sformatf("COMPLETED_OK=%0d expected 8", ok))
    `CHECK(macs == exp_macs, $sformatf("USEFUL_MACS=%0d expected %0d", macs, exp_macs))
    `CHECK(u_tc.stat_scrubs == 1, "exactly one scrub (reset leaves scratchpad UNKNOWN)")
  endtask

  // T02 — FIFO order within one queue
  task automatic t_queue_order();
    int txns [8];
    std_setup(1);
    set_ctrl(1'b0, POL_RR);                  // hold dispatch while filling
    for (int i = 0; i < 8; i++) gemm(0, 0, 4 + i, 8, 4, txns[i]);
    set_ctrl(1'b1, POL_RR);
    wait_all();
    for (int i = 0; i < 8; i++) begin
      `CHECK(cpl_order[i] == txns[i], $sformatf("completion %0d is txn %0d expected %0d", i, cpl_order[i], txns[i]))
      if (i > 0) `CHECK(c_tdisp[txns[i]] > c_tdisp[txns[i-1]], "dispatch order must follow queue order")
    end
  endtask

  // T03 — round-robin rotation across 4 tenant queues
  task automatic t_rr_order();
    int txn;
    std_setup(4);
    set_ctrl(1'b0, POL_RR);
    for (int r = 0; r < 4; r++) for (int t = 0; t < 4; t++) gemm(t, t, 8, 8, 8, txn);
    set_ctrl(1'b1, POL_RR);
    wait_all();
    for (int i = 1; i < 16; i++) begin
      int a = c_tenant[cpl_order[i-1]], b = c_tenant[cpl_order[i]];
      `CHECK(b == (a + 1) % 4, $sformatf("RR rotation broken at %0d: %0d -> %0d", i, a, b))
    end
  endtask

  // T04 — every rejection path; nothing invalid reaches the TensorCore or memory
  task automatic t_invalid_cmds();
    int txn, cmds_before, writes_before;
    desc_t d, base;
    longint unsigned drops, rej;
    logic [31:0] v;
    std_setup(2);
    // tenant 0, region 1: read-only window at the top of the address space (wrap tests)
    csr_wr(RT(0, 'h24), 32'hFFFF_0000); csr_wr(RT(0, 'h28), 32'hFFFF_FFFF); csr_wr(RT(0, 'h2C), 32'h1);
    // tenant 2: queue 2 + CQ 2 configured, tenant itself left disabled
    csr_wr(RCQ(2), 32'h1 | (2 << 8));
    csr_wr(RQ(2, 0), 32'h1 | (2 << 8) | (2 << 16));
    tick(2);
    cmds_before = u_tc.stat_cmds; writes_before = u_mem.stat_writes;
    base = mk_desc(0, 8, 8, 8, tbase(0), tbase(0) + 16*1024, tbase(0) + 512*1024, 0, 0, 0, 0);

    d = base; d.opcode = 8'h02;               d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_UNSUP_OP, 0);
    d = base; d.numfmt = FMT_BF16;            d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_UNSUP_FMT, 0);
    d = base; d.numfmt = FMT_FP16;            d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_UNSUP_FMT, 0);
    d = base; d.numfmt = FMT_UINT8;           d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_UNSUP_FMT, 0);
    d = base; d.acc_prec = ACC_FP32;          d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_UNSUP_PREC, 0);
    d = base; d.m = 0;                        d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_BAD_DIMS, 0);
    d = base; d.k = 65;                       d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_BAD_DIMS, 0);
    d = base; d.n = 16'hFFFF;                 d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_BAD_DIMS, 0);
    d = base; d.a_addr += 1;                  d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_BAD_ALIGN, 0);
    d = base; d.c_addr += 2;                  d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_BAD_ALIGN, 0);
    d = base; d.rsvd = 30'h1;                 d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_RSVD_NONZERO, 0);
    d = base; d.flags = 8'h80;                d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_RSVD_NONZERO, 0);
    // CQ out of range / owned by another tenant: error goes to queue 0's error CQ (0), never CQ 1
    d = base; d.cq_id = 8'd9;                 d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_BAD_CQ, 0);
    d = base; d.cq_id = 8'd1;                 d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_BAD_CQ, 0);
    // spoofed tenant id on tenant 0's doorbell: attributed to the queue owner (0)
    d = base; d.tenant_id = 8'd1; d.cq_id = 8'd1; d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_TENANT_MISMATCH, 0);
    // cross-tenant operands / output
    d = base; d.a_addr = tbase(1);            d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_PERM_A, 0);
    d = base; d.b_addr = tbase(1) + 64;       d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_PERM_B, 0);
    d = base; d.c_addr = tbase(1) + 512*1024; d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_PERM_C, 0);
    // straddling the end of the own region
    d = base; d.c_addr = tbase(1) - 128;      d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_PERM_C, 0);
    // output into a read-only region
    d = base; d.c_addr = 32'hFFFF_0000;       d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_PERM_C, 0);
    // 32-bit wrap-around: [0xFFFFFF00, +4096) wraps to 0x00000EFF
    d = base; d.a_addr = 32'hFFFF_FF00; d.m = 64; d.k = 64; d.txn_id = 16'(alloc_txn()); submit_desc(0, d, 0, ST_PERM_A, 0);
    // disabled tenant
    d = base; d.tenant_id = 8'd2; d.cq_id = 8'd2; d.a_addr = tbase(2); d.b_addr = tbase(2); d.c_addr = tbase(2) + 512*1024;
    d.txn_id = 16'(alloc_txn()); submit_desc(2, d, 2, ST_TENANT_DISABLED, 2);
    // disabled queue (3) and non-existent queue (9): no owner -> no CQ -> dropped + flagged
    d = base; d.txn_id = 16'(alloc_txn()); c_used[d.txn_id] = 1'b1; c_drop[d.txn_id] = 1'b1; c_tenant[d.txn_id] = -1;
    submit_raw(3, d);
    d = base; d.txn_id = 16'(alloc_txn()); c_used[d.txn_id] = 1'b1; c_drop[d.txn_id] = 1'b1; c_tenant[d.txn_id] = -1;
    submit_raw(9, d);
    wait_all(100_000);
    tick(20);
    `CHECK(u_tc.stat_cmds == cmds_before, "an invalid command reached the TensorCore")
    `CHECK(u_mem.stat_writes == writes_before, "an invalid command wrote memory")
    cnt_g(G_DROP, drops); cnt_g(G_REJ, rej);
    `CHECK(drops == 2, $sformatf("CPL_DROPPED=%0d expected 2", drops))
    `CHECK(rej == 24, $sformatf("REJECTED=%0d expected 24", rej))
    csr_rd(R_ERR, v);
    `CHECK(v[0], "ERR_STICKY.cpl_drop must be set")
    `CHECK(irq_err, "irq_err must be asserted")
    csr_wr(R_ERR, 32'h3F); csr_rd(R_ERR, v);
    `CHECK(v == 0, "ERR_STICKY must clear on W1C")
    // a valid command still works afterwards
    gemm(0, 0, 8, 8, 8, txn);
    wait_all();
  endtask

  // T05 — rogue TensorCore DMA: gate blocks, tenant quarantined, others unaffected
  task automatic t_dma_gate_isolation();
    int bad, y1, y2, z1, z2, z3, after, ok2;
    int unsigned victim_pool, victim_secret;
    logic [31:0] v;
    std_setup(2);
    victim_pool   = region_sum(1, 0, 32*1024);
    victim_secret = region_sum(1, RBYTES - 64*1024, 64*1024);
    set_ctrl(1'b0, POL_PRIO);
    fi_domain = 8'd0; fi_oob_offset = RBYTES;      // tenant 0's 3rd A read lands in tenant 1
    gemm(0, 0, 16, 16, 16, bad, 0, 0, -1, ST_DMA_FAULT);
    gemm(0, 0, 8, 8, 8, y1, 0, 0, -1, ST_ABORTED);
    gemm(0, 0, 8, 8, 8, y2, 0, 0, -1, ST_ABORTED);
    gemm(1, 1, 16, 16, 16, z1);
    gemm(1, 1, 16, 16, 16, z2);
    set_ctrl(1'b1, POL_PRIO);                      // equal priority, tie-break starts at queue 0
    wait_txn(bad);
    // checked immediately: the next tenant's scrub has not finished yet
    `CHECK(u_tc.spad_a[8] == 0 && u_tc.spad_a[9] == 0 && u_tc.spad_a[10] == 0 && u_tc.spad_a[11] == 0,
           "rogue read must not deliver another tenant's bytes into the scratchpad")
    `CHECK(u_mem.stat_poisoned >= 1, "gate must have poisoned the rogue read")
    wait_all();
    fi_oob_offset = 0;
    csr_rd(RT(0, 'h00), v);
    `CHECK(v[2], "tenant 0 must be quarantined")
    csr_rd(R_FAULTADDR, v);
    `CHECK(v >= tbase(1) && v < tbase(2), $sformatf("fault address 0x%08h should be in tenant 1", v))
    csr_rd(R_ERR, v);
    `CHECK(v[1], "ERR_STICKY.dma_fault must be set")
    // quarantined tenant: new submissions rejected, other tenant keeps working
    gemm(0, 0, 4, 4, 4, after, 0, 0, -1, ST_TENANT_FAULTED);
    gemm(1, 1, 8, 8, 8, z3);
    wait_all();
    // host clears the fault (W1C) -> tenant 0 works again
    csr_wr(RT(0, 'h00), 32'h1 | (3 << 4) | 32'h4);
    csr_rd(RT(0, 'h00), v);
    `CHECK(!v[2], "fault must clear on W1C")
    gemm(0, 0, 8, 8, 8, ok2);
    wait_all();
    `CHECK(region_sum(1, 0, 32*1024) == victim_pool, "victim operand pool modified")
    `CHECK(region_sum(1, RBYTES - 64*1024, 64*1024) == victim_secret, "victim secret area modified")
  endtask

  // T05b — rogue TensorCore WRITE into a region the tenant may only READ
  //        (also: legitimate shared read-only window across tenants)
  task automatic t_dma_gate_write();
    int good, bad, txn;
    int unsigned victim;
    logic [31:0] v;
    desc_t d;
    std_setup(2);
    // tenant 0, region 1: READ-ONLY view of tenant 1's operand pool (shared weights)
    csr_wr(RT(0, 'h24), tbase(1)); csr_wr(RT(0, 'h28), tbase(1) + 32*1024 - 1); csr_wr(RT(0, 'h2C), 32'h1);
    victim = region_sum(1, 0, 32*1024);
    // legitimate: A from own pool, B from the shared read-only window
    good = alloc_txn();
    d = mk_desc(0, 16, 16, 16, tbase(0) + 64, tbase(1) + 1024, tbase(0) + 512*1024, 0, 0, 0, good);
    submit_desc(0, d, 0, ST_OK, 0);
    // illegal by descriptor: output into the read-only window
    txn = alloc_txn();
    d = mk_desc(0, 8, 8, 8, tbase(0), tbase(0), tbase(1) + 2048, 0, 0, 0, txn);
    submit_desc(0, d, 0, ST_PERM_C, 0);
    wait_all();
    // illegal at run time: a faulty TensorCore redirects its first store there
    fi_domain = 8'd0; fi_wr_redirect = tbase(1) + 32'h100;
    gemm(0, 0, 8, 8, 8, bad, 0, 0, -1, ST_DMA_FAULT);
    wait_txn(bad);
    fi_wr_redirect = 0;
    `CHECK(region_sum(1, 0, 32*1024) == victim, "rogue write modified another tenant's read-only data")
    `CHECK(u_mem.stat_poisoned >= 1, "rogue write must be poisoned")
    csr_rd(R_FAULTADDR, v);
    `CHECK(v == tbase(1) + 32'h100, $sformatf("fault address 0x%08h", v))
    csr_rd(RT(0, 'h00), v);
    `CHECK(v[2], "tenant 0 must be quarantined after a rogue write")
    // tenant 1 unaffected
    gemm(1, 1, 8, 8, 8, txn);
    wait_all();
  endtask

  // T06 — scratchpad scrub on tenant change defeats a leaky-accumulator TensorCore
  task automatic t_spad_scrub();
    int txn;
    longint unsigned sw0, sw1;
    logic [31:0] v;
    std_setup(2);
    // scrub bypass request must be ignored in a production build
    set_ctrl(1'b1, POL_RR, 1'b1);
    csr_rd(R_CTRL, v);
    if (!ALLOW_SCRUB_BYPASS) `CHECK(!v[8], "scrub_bypass must be tied off when ALLOW_SCRUB_BYPASS=0")
    set_ctrl(1'b0, POL_RR);
    fi_acc_no_clear = 1'b1;                       // buggy TensorCore: accumulators not cleared
    for (int i = 0; i < 6; i++) begin
      gemm(0, 0, 12, 12, 12, txn);
      gemm(1, 1, 12, 12, 12, txn);
    end
    set_ctrl(1'b1, POL_RR);
    wait_all();
    fi_acc_no_clear = 1'b0;
    cnt_g(G_CTXSW, sw0);
    `CHECK(sw0 == 12, $sformatf("CTX_SWITCHES=%0d expected 12 (every command changes tenant)", sw0))
    // same-tenant back-to-back: no scrub
    for (int i = 0; i < 4; i++) gemm(0, 0, 8, 8, 8, txn);
    wait_all();
    cnt_g(G_CTXSW, sw1);
    `CHECK(sw1 - sw0 <= 1, $sformatf("same-tenant commands must not scrub (%0d -> %0d)", sw0, sw1))
    `CHECK(residue_violations == 0, "residue monitor")
  endtask

  // T07 — NEGATIVE CONTROL (bypass build only): without scrubbing, data leaks
  task automatic t_spad_scrub_negative();
    int txn;
    if (!ALLOW_SCRUB_BYPASS) begin
      $display("t_spad_scrub_negative requires +define build with ALLOW_SCRUB_BYPASS=1");
      errors++;
      return;
    end
    std_setup(2);
    expect_leaks = 1'b1;
    set_ctrl(1'b0, POL_RR, 1'b1);
    fi_acc_no_clear = 1'b1;
    for (int i = 0; i < 6; i++) begin
      gemm(0, 0, 12, 12, 12, txn);
      gemm(1, 1, 12, 12, 12, txn);
    end
    set_ctrl(1'b1, POL_RR, 1'b1);
    wait_all();
    fi_acc_no_clear = 1'b0;
    $display("negative control: leaked results=%0d residue violations=%0d", leaks, residue_violations);
    `CHECK(leaks > 0, "with scrubbing bypassed the leak must be observable (checker sanity)")
    `CHECK(residue_violations > 0, "residue monitor must fire with scrubbing bypassed")
    expect_leaks = 1'b0;
  endtask

  // closed-loop feeder used by fairness / rate tests
  task automatic closed_loop(int nt, int dims[4][3], int window, int total, output int done_at_measure);
    int issued [4] = '{0,0,0,0};
    int txn, start = n_cpl;
    forever begin
      bit any;
      if (n_cpl - start >= total) break;
      any = 1'b0;
      for (int t = 0; t < nt; t++) begin
        if (t_outstanding[t] < window) begin
          gemm(t, t, dims[t][0], dims[t][1], dims[t][2], txn);
          issued[t]++;
          any = 1'b1;
        end
      end
      if (!any) tick();
    end
    done_at_measure = n_cpl;
  endtask

  // T08 — fairness: RR equal shares, WRR weights, DRR time-fair on mixed sizes
  task automatic t_fairness();
    int d_eq [4][3] = '{'{8,8,8}, '{8,8,8}, '{8,8,8}, '{8,8,8}};
    int d_mix[4][3] = '{'{8,8,8}, '{16,16,16}, '{32,32,16}, '{32,32,32}};
    int dummy, cnt [4];
    longint unsigned busy [4], v;
    real share [4], mx, mn, rr_ratio, drr_ratio;

    // --- RR, equal sizes: command counts equal -------------------------------
    std_setup(4, POL_RR);
    csr_wr(R_CTRL, 32'h1 | (POL_RR << 1) | (1 << 16));        // clear counters
    closed_loop(4, d_eq, 3, 200, dummy);
    for (int t = 0; t < 4; t++) begin cnt_t(t, T_OK, v); cnt[t] = int'(v); end
    for (int t = 1; t < 4; t++)
      `CHECK((cnt[t] - cnt[0] <= 2) && (cnt[0] - cnt[t] <= 2), $sformatf("RR counts %0d %0d %0d %0d", cnt[0], cnt[1], cnt[2], cnt[3]))
    wait_all();

    // --- WRR 1:2:3:4 ----------------------------------------------------------
    for (int q = 0; q < 4; q++) csr_wr(RQ(q, 4), q + 1);
    csr_wr(R_CTRL, 32'h1 | (POL_WRR << 1) | (1 << 16));
    closed_loop(4, d_eq, 8, 400, dummy);
    for (int t = 0; t < 4; t++) begin cnt_t(t, T_OK, v); cnt[t] = int'(v); end
    for (int t = 1; t < 4; t++) begin
      real ratio = real'(cnt[t]) / real'(cnt[0]);
      `CHECK(ratio > (t + 1) * 0.85 && ratio < (t + 1) * 1.15, $sformatf("WRR ratio t%0d/t0 = %0.2f expected %0d", t, ratio, t + 1))
    end
    $display("WRR completions: %0d %0d %0d %0d", cnt[0], cnt[1], cnt[2], cnt[3]);
    wait_all();
    for (int q = 0; q < 4; q++) csr_wr(RQ(q, 4), 1);

    // --- RR vs DRR on mixed sizes: TensorCore time share ---------------------
    for (int pass = 0; pass < 2; pass++) begin
      int pol = (pass == 0) ? POL_RR : POL_DRR;
      csr_wr(R_QUANTUM, 512);
      csr_wr(R_CTRL, 32'h1 | (pol << 1) | (1 << 16));
      closed_loop(4, d_mix, 8, (pass == 0) ? 160 : 300, dummy);
      mx = 0; mn = 1;
      for (int t = 0; t < 4; t++) begin cnt_t(t, T_BUSY, busy[t]); end
      for (int t = 0; t < 4; t++) begin
        share[t] = real'(busy[t]) / real'(busy[0] + busy[1] + busy[2] + busy[3]);
        if (share[t] > mx) mx = share[t];
        if (share[t] < mn) mn = share[t];
      end
      $display("%s busy shares: %0.3f %0.3f %0.3f %0.3f", pass == 0 ? "RR " : "DRR", share[0], share[1], share[2], share[3]);
      if (pass == 0) rr_ratio = mx / mn; else drr_ratio = mx / mn;
      wait_all();
    end
    `CHECK(drr_ratio < 1.35, $sformatf("DRR max/min TensorCore share %0.2f should be < 1.35", drr_ratio))
    `CHECK(rr_ratio > drr_ratio, "DRR must be fairer than RR in TensorCore time on mixed sizes")
  endtask

  // T09 — priority classes, cap clamping, aging
  task automatic t_priority();
    int lo [6], hi [3], a, b, starve, txn;
    std_setup(3);
    csr_wr(RT(1, 'h00), 32'h1 | (0 << 4));   // tenant 1 capped at prio 0
    csr_wr(RT(2, 'h00), 32'h1 | (1 << 4));   // tenant 2 capped at prio 1
    set_ctrl(1'b0, POL_PRIO);
    for (int i = 0; i < 6; i++) gemm(1, 1, 8, 8, 8, lo[i], 3);   // requests 3, clamped to 0
    for (int i = 0; i < 3; i++) gemm(0, 0, 8, 8, 8, hi[i], 3);
    gemm(2, 2, 8, 8, 8, a, 1);
    set_ctrl(1'b1, POL_PRIO);
    wait_all();
    for (int i = 0; i < 3; i++)
      `CHECK(cpl_order[i] == hi[i], $sformatf("completion %0d should be high-priority txn %0d", i, hi[i]))
    `CHECK(cpl_order[3] == a, "prio-1 tenant must beat clamped prio-3 request of a cap-0 tenant")

    // aging: tenant 0 floods prio 3, tenant 1 has one prio-0 command
    csr_wr(R_AGING, 3000);
    n_cpl = 0;
    set_ctrl(1'b0, POL_PRIO);
    for (int i = 0; i < 8; i++) gemm(0, 0, 16, 16, 16, txn, 3);
    gemm(1, 1, 8, 8, 8, starve, 0);
    set_ctrl(1'b1, POL_PRIO);
    for (int r = 0; r < 30; r++) begin
      if (t_outstanding[0] < 6) gemm(0, 0, 16, 16, 16, txn, 3); else tick(50);
      if (c_done[starve]) break;
    end
    wait_txn(starve);
    $display("aging: low-priority wait = %0d cycles (limit 3000)", c_tdisp[starve] - c_tsub[starve]);
    `CHECK(c_tdisp[starve] - c_tsub[starve] < 3000 + 1500, "aging must bound low-priority queueing delay")
    wait_all();
    csr_wr(R_AGING, 0);
  endtask

  // T10 — deadline-hint ordering
  task automatic t_deadline();
    int t0, t1, t2, t3;
    std_setup(4);
    set_ctrl(1'b0, POL_DEADLINE);
    gemm(0, 0, 8, 8, 8, t0, 0, 50000);
    gemm(1, 1, 8, 8, 8, t1, 0, 1000);
    gemm(2, 2, 8, 8, 8, t2, 0, 0);
    gemm(3, 3, 8, 8, 8, t3, 0, 20000);
    set_ctrl(1'b1, POL_DEADLINE);
    wait_all();
    `CHECK(cpl_order[0] == t1 && cpl_order[1] == t3 && cpl_order[2] == t0 && cpl_order[3] == t2,
           "deadline-hint order must be t1, t3, t0, t2(no hint)")
  endtask

  // T11 — token-bucket rate limit on MEASURED TensorCore occupancy
  task automatic t_rate_limit();
    int d [4][3] = '{'{16,16,16}, '{16,16,16}, '{0,0,0}, '{0,0,0}};
    int dummy;
    longint unsigned d0, d1, cyc_g, b0, b1;
    real budget, s0;
    std_setup(2, POL_RR);
    // 1 token per 4 cycles (25% of TensorCore time), burst 2000
    csr_wr(RT(0, 'h08), 1); csr_wr(RT(0, 'h0C), 4); csr_wr(RT(0, 'h10), 2000); csr_wr(RT(0, 'h04), 1);
    csr_wr(R_CTRL, 32'h1 | (POL_RR << 1) | (1 << 16));
    closed_loop(2, d, 3, 120, dummy);
    cnt_t(0, T_DISP, d0); cnt_t(1, T_DISP, d1); cnt_g(G_CYCLES, cyc_g);
    cnt_t(0, T_BUSY, b0); cnt_t(1, T_BUSY, b1);
    // budget: rate * time + burst + one command of debt (+ scrub) in flight
    budget = 0.25 * real'(cyc_g) + 2000.0 + 1500.0;
    s0 = real'(b0) / real'(cyc_g);
    $display("rate limit: tenant0 busy %0d cycles (budget %0.0f, share %0.3f, target 0.25), dispatched %0d; tenant1 share %0.3f dispatched %0d",
             b0, budget, s0, d0, real'(b1) / real'(cyc_g), d1);
    `CHECK(real'(b0) <= budget, "rate-limited tenant exceeded its occupancy budget")
    `CHECK(real'(b0) >= 0.80 * 0.25 * real'(cyc_g), "backlogged rate-limited tenant must receive its budget")
    `CHECK(d1 > d0, "unlimited tenant must receive the remaining capacity")
    wait_all();
  endtask

  // T12 — admission control and queue-full: rejected, never head-of-line blocking
  task automatic t_admission();
    int txn, low_ready = 0;
    std_setup(2);
    csr_wr(RQ(0, 8), 2);                         // tenant 0 may queue at most 2
    set_ctrl(1'b0, POL_RR);
    gemm(0, 0, 8, 8, 8, txn);
    gemm(0, 0, 8, 8, 8, txn);
    gemm(0, 0, 8, 8, 8, txn, 0, 0, -1, ST_ADMISSION);
    gemm(0, 0, 8, 8, 8, txn, 0, 0, -1, ST_ADMISSION);
    for (int i = 0; i < 8; i++) gemm(1, 1, 8, 8, 8, txn);
    gemm(1, 1, 8, 8, 8, txn, 0, 0, -1, ST_QUEUE_FULL);
    gemm(0, 0, 8, 8, 8, txn, 0, 0, -1, ST_ADMISSION);
    tick(30);
    set_ctrl(1'b1, POL_RR);
    wait_all();
  endtask

  // T13 — completion back-pressure and intake back-pressure
  task automatic t_backpressure();
    int txn, first_cmds, saw_not_ready = 0;
    longint unsigned bp;
    desc_t d;
    std_setup(2);
    cpl_ready = 1'b0;
    for (int i = 0; i < 3; i++) begin gemm(0, 0, 8, 8, 8, txn); gemm(1, 1, 8, 8, 8, txn); end
    tick(20000);
    `CHECK(n_cpl == 0, "no completion may be delivered while cpl_ready=0")
    `CHECK(u_tc.stat_cmds == 1, $sformatf("TensorCore must stall behind the held completion (ran %0d)", u_tc.stat_cmds))
    cnt_g(G_CPL_BP, bp);
    `CHECK(bp > 1000, "CPL_BACKPRESSURE counter must count")
    // flood invalid descriptors: reject FIFO (depth 4) fills, then sub_ready drops
    d = mk_desc(0, 8, 8, 8, 0, 0, 0, 0, 0, 0, 0); d.opcode = 8'hEE;
    for (int i = 0; i < 6; i++) begin
      d.txn_id = 16'(alloc_txn());
      c_used[d.txn_id] = 1'b1; c_done[d.txn_id] = 1'b0; c_drop[d.txn_id] = 1'b0; c_tenant[d.txn_id] = 0;
      c_exp_status[d.txn_id] = ST_UNSUP_OP; c_exp_cq[d.txn_id] = 0;
      sub_valid = 1'b1; sub_qid = 8'd0; sub_desc = d;
      while (!sub_ready) begin saw_not_ready++; if (saw_not_ready == 50) cpl_ready = 1'b1; @(negedge clk); end
      @(negedge clk); sub_valid = 1'b0;
    end
    `CHECK(saw_not_ready > 0, "sub_ready must drop once the reject path is full")
    // release with random completion-port stalls
    for (int i = 0; i < 4000; i++) begin
      if (pending_cnt() == 0) break;
      cpl_ready = (rnd(100) < 60); tick();
    end
    cpl_ready = 1'b1;
    wait_all();
  endtask

  // T14 — reset in the middle of execution
  task automatic t_reset();
    int txn;
    logic [31:0] v;
    longint unsigned c;
    std_setup(2);
    for (int i = 0; i < 4; i++) begin gemm(0, 0, 32, 32, 32, txn); gemm(1, 1, 32, 32, 32, txn); end
    forever begin
      if (tc_phase == PH_COMPUTE) break;
      tick();
    end
    do_reset();
    csr_rd(R_CTRL, v);           `CHECK(v == 0, "CTRL resets to 0 (scheduler disabled)")
    csr_rd(R_STATUS, v);         `CHECK(v[3:2] == SP_UNKNOWN && !v[0], "STATUS after reset: idle, scratchpad UNKNOWN")
    csr_rd(RT(0, 'h00), v);      `CHECK(v == 0, "tenant 0 disabled after reset")
    csr_rd(RT(0, 'h20), v);      `CHECK(v == 0, "region permissions cleared after reset")
    csr_rd(RQ(0, 'hC), v);       `CHECK(v[7:0] == 0, "queue 0 empty after reset")
    cnt_g(G_DISPATCHED, c);      `CHECK(c == 0, "counters cleared by reset")
    `CHECK(!cpl_valid, "no completion after reset")
    // unconfigured after reset: submission is dropped (no owned CQ to report to)
    begin
      desc_t d = mk_desc(0, 8, 8, 8, tbase(0), tbase(0), tbase(0) + 512*1024, 0, 0, 0, alloc_txn());
      c_used[d.txn_id] = 1'b1; c_drop[d.txn_id] = 1'b1; c_tenant[d.txn_id] = -1;
      submit_raw(0, d);
    end
    tick(10);
    cnt_g(G_DROP, c);            `CHECK(c == 1, "pre-configuration submission must be dropped and counted")
    // reconfigure and run; first dispatch must scrub
    std_setup(2);
    for (int i = 0; i < 3; i++) begin gemm(0, 0, 16, 16, 16, txn); gemm(1, 1, 16, 16, 16, txn); end
    wait_all();
    `CHECK(residue_violations == 0, "scratchpad must be scrubbed after reset")
  endtask

  // T15 — completion association under a random mixed multi-tenant workload,
  //       two queues/CQs for one tenant, policy changes, memory contention
  task automatic t_cpl_assoc_random();
    int txn, sizes [6] = '{1, 4, 8, 13, 32, 64};
    std_setup(3);
    // tenant 2 also owns queue 3 and CQ 3
    csr_wr(RCQ(3), 32'h1 | (2 << 8));
    csr_wr(RQ(3, 0), 32'h1 | (2 << 8) | (3 << 16));
    contention_pct = 8'd30;
    for (int i = 0; i < 400; i++) begin
      int q, t, m, n, k, cq, pr, dl;
      q  = rnd(4);
      t  = (q == 3) ? 2 : q;
      m  = sizes[rnd(6)]; n = sizes[rnd(6)]; k = sizes[rnd(5)];
      cq = (t == 2) ? 2 + rnd(2) : t;
      pr = rnd(4);
      dl = (rnd(2) != 0) ? rnd(40000) : 0;
      if (i % 50 == 0) set_ctrl(1'b1, rnd(5));
      if (t_outstanding[t] >= 7) begin cpl_ready = 1'b1; tick(200); i--; continue; end
      cpl_ready = (rnd(100) < 85);
      gemm(t, q, m, n, k, txn, pr, dl, cq);
    end
    cpl_ready = 1'b1;
    wait_all();
    contention_pct = 8'd0;
    `CHECK(n_cpl == 400, $sformatf("expected 400 completions, got %0d", n_cpl))
  endtask

  // T16 — resource exhaustion: every queue full, completion port blocked
  task automatic t_resource_exhaustion();
    int txn, rejects = 0;
    longint unsigned disp, ok, err, rej;
    std_setup(4);
    set_ctrl(1'b0, POL_RR);
    for (int t = 0; t < 4; t++) for (int i = 0; i < 8; i++) gemm(t, t, 4, 4, 4, txn);
    for (int t = 0; t < 4; t++) begin gemm(t, t, 4, 4, 4, txn, 0, 0, -1, ST_QUEUE_FULL); rejects++; end
    cpl_ready = 1'b0;
    set_ctrl(1'b1, POL_RR);
    tick(5000);
    for (int i = 0; i < 4000; i++) begin
      if (pending_cnt() == 0) break;
      cpl_ready = (rnd(100) < 30); tick();
    end
    cpl_ready = 1'b1;
    wait_all();
    cnt_g(G_DISPATCHED, disp); cnt_g(G_OK, ok); cnt_g(G_ERR, err); cnt_g(G_REJ, rej);
    `CHECK(disp == ok + err, "DISPATCHED must equal COMPLETED_OK + COMPLETED_ERR")
    `CHECK(ok == 32 && rej == rejects, $sformatf("ok=%0d rej=%0d", ok, rej))
  endtask

  // T17 — fault handling: hang/watchdog, internal error, TOCTOU revocation,
  //       CQ revoked in flight, queue-disable flush
  task automatic t_faults();
    int h, n1, n2, ie, r1, r2, lc, f1, f2, f3, cmds;
    longint unsigned to, sw_a, sw_b;
    logic [31:0] v;
    std_setup(2);
    csr_wr(R_WD, 5000);
    // (a) TensorCore hangs on tenant 1's command
    fi_domain = 8'd1; fi_hang = 1'b1;
    gemm(1, 1, 8, 8, 8, h, 0, 0, -1, ST_TIMEOUT);
    wait_txn(h);
    fi_hang = 1'b0;
    cnt_g(G_TIMEOUT, to);  `CHECK(to == 1, "TIMEOUTS counter")
    csr_rd(R_ERR, v);      `CHECK(v[3], "ERR_STICKY.timeout")
    csr_rd(RT(1, 0), v);   `CHECK(!v[2], "a timeout must not quarantine the tenant")
    cnt_g(G_CTXSW, sw_a);
    gemm(1, 1, 8, 8, 8, n1);                        // same tenant: still scrubbed (UNKNOWN)
    wait_all();
    cnt_g(G_CTXSW, sw_b);  `CHECK(sw_b == sw_a + 1, "recovery must force a scrub even for the same tenant")
    // (b) internal error
    fi_domain = 8'd0; fi_internal_err = 1'b1;
    gemm(0, 0, 8, 8, 8, ie, 0, 0, -1, ST_TC_ERROR);
    wait_txn(ie);
    fi_internal_err = 1'b0;
    gemm(0, 0, 8, 8, 8, n2);
    wait_all();
    csr_rd(R_ERR, v);      `CHECK(v[5], "ERR_STICKY.tc_error")
    // (c) region revoked after intake: dispatch-time revalidation rejects
    set_ctrl(1'b0, POL_RR);
    gemm(0, 0, 8, 8, 8, r1, 0, 0, -1, ST_PERM_A);
    gemm(0, 0, 8, 8, 8, r2, 0, 0, -1, ST_PERM_A);
    cmds = u_tc.stat_cmds;
    csr_wr(RT(0, 'h20), 0);
    set_ctrl(1'b1, POL_RR);
    wait_all();
    `CHECK(u_tc.stat_cmds == cmds, "revoked commands must not reach the TensorCore")
    csr_wr(RT(0, 'h20), 3);
    // (d) CQ ownership changed while the command executes: completion dropped
    gemm(0, 0, 64, 64, 64, lc);
    forever begin
      if (tc_phase == PH_COMPUTE) break;
      tick();
    end
    c_drop[lc] = 1'b1;
    csr_wr(RCQ(0), 32'h1 | (1 << 8));               // CQ 0 now belongs to tenant 1
    tick(30000);
    `CHECK(!c_done[lc], "completion must not be delivered to the new CQ owner")
    csr_rd(R_ERR, v);      `CHECK(v[0], "ERR_STICKY.cpl_drop")
    csr_wr(RCQ(0), 32'h1 | (0 << 8));
    // (e) disabling a queue flushes its pending work as ABORTED
    set_ctrl(1'b0, POL_RR);
    gemm(1, 1, 8, 8, 8, f1, 0, 0, -1, ST_ABORTED);
    gemm(1, 1, 8, 8, 8, f2, 0, 0, -1, ST_ABORTED);
    gemm(1, 1, 8, 8, 8, f3, 0, 0, -1, ST_ABORTED);
    csr_wr(RQ(1, 0), 32'h0 | (1 << 8) | (1 << 16));
    wait_all();
  endtask

  // T18 — suspend / resume = command-boundary context switch
  task automatic t_suspend_resume();
    int a [6], b [6], inflight_txn, done_before, idx;
    logic [31:0] v;
    std_setup(2);
    set_ctrl(1'b0, POL_RR);
    for (int i = 0; i < 6; i++) begin gemm(0, 0, 32, 32, 32, a[i]); gemm(1, 1, 16, 16, 16, b[i]); end
    set_ctrl(1'b1, POL_RR);
    // wait until a tenant-0 command is executing, then suspend tenant 0
    forever begin
      if (tc_phase == PH_COMPUTE && u_dut.active_tenant == 0) break;
      tick();
    end
    csr_wr(RT(0, 0), 32'h1 | 32'h2 | (3 << 4));
    csr_rd(RT(0, 'h14), v);
    `CHECK(v[0], "tenant 0 must show in-flight right after suspend (no mid-GEMM preemption)")
    done_before = 0;
    for (int i = 0; i < 6; i++) if (c_done[a[i]]) done_before++;
    tick(60000);
    idx = 0;
    for (int i = 0; i < 6; i++) if (c_done[a[i]]) idx++;
    `CHECK(idx == done_before + 1, $sformatf("exactly the in-flight command may finish while suspended (%0d -> %0d)", done_before, idx))
    csr_rd(RT(0, 'h14), v);
    `CHECK(!v[0] && v[1] && v[2], "suspended tenant: quiesced, work pending")
    for (int i = 0; i < 6; i++) `CHECK(c_done[b[i]], "other tenant must keep running")
    csr_wr(RT(0, 0), 32'h1 | (3 << 4));             // resume
    wait_all();
    for (int i = 1; i < 6; i++)
      `CHECK(c_tcpl[a[i]] > c_tcpl[a[i-1]], "resumed work must keep queue order and txn ids")
  endtask

  // =============================================================================
  // BENCHMARK MODE
  // =============================================================================
  int          b_arr [MAXCMD], b_t [MAXCMD], b_m [MAXCMD], b_n [MAXCMD], b_k [MAXCMD];
  int          b_prio [MAXCMD], b_dl [MAXCMD];
  int          tl [NT][MAXCMD];
  int          tl_n [NT], tl_i [NT], t_window [NT];

  task automatic run_bench(string wl);
    int fd, rt, key, val, ncmd = 0, total, tx, rr = 0, cpl_pct = 100;
    int t, weight, pcap, rl_en, rl_rate, rl_per, rl_burst, admit, window;
    int unsigned start;
    string trace_file, cnt_file;
    longint unsigned v;
    fd = $fopen(wl, "r");
    if (fd == 0) begin $display("cannot open %s", wl); errors++; return; end
    for (int i = 0; i < NT; i++) begin tl_n[i] = 0; tl_i[i] = 0; t_window[i] = 0; end
    // fixed tenant configuration first so CFG lines can override
    for (int i = 0; i < NT; i++) begin cfg_tenant(i, i, i); fill_operands(i); end
    set_ctrl(1'b0, POL_RR);
    forever begin
      if ($feof(fd)) break;
      if ($fscanf(fd, "%d", rt) != 1) break;
      if (rt == 0) break;
      if (rt == 1) begin
        void'($fscanf(fd, "%d %d", key, val));
        case (key)
          1: set_ctrl(1'b0, val);
          2: contention_pct = 8'(val);
          3: csr_wr(R_QUANTUM, val);
          4: csr_wr(R_AGING, val);
          5: csr_wr(R_WD, val);
          6: cpl_pct = val;
          7: begin rng = val; mem_seed = val; end
          8: check_results = (val != 0);
          default: ;
        endcase
      end else if (rt == 2) begin
        void'($fscanf(fd, "%d %d %d %d %d %d %d %d %d", t, weight, pcap, rl_en, rl_rate, rl_per, rl_burst, admit, window));
        csr_wr(RQ(t, 4), weight);
        csr_wr(RQ(t, 8), admit);
        csr_wr(RT(t, 0), 32'h1 | (pcap << 4));
        csr_wr(RT(t, 'h08), rl_rate); csr_wr(RT(t, 'h0C), rl_per); csr_wr(RT(t, 'h10), rl_burst);
        csr_wr(RT(t, 'h04), rl_en);
        t_window[t] = window;
      end else if (rt == 3) begin
        void'($fscanf(fd, "%d %d %d %d %d %d %d", b_arr[ncmd], b_t[ncmd], b_m[ncmd], b_n[ncmd], b_k[ncmd], b_prio[ncmd], b_dl[ncmd]));
        tl[b_t[ncmd]][tl_n[b_t[ncmd]]] = ncmd;
        tl_n[b_t[ncmd]]++;
        ncmd++;
      end
    end
    $fclose(fd);
    total = ncmd;
    if (!$value$plusargs("TRACE=%s", trace_file)) trace_file = "trace.csv";
    if (!$value$plusargs("COUNTERS=%s", cnt_file)) cnt_file = "counters.txt";
    trace_fd = $fopen(trace_file, "w");
    $fwrite(trace_fd, "txn,tenant,qid,cq,status,m,n,k,prio,deadline,arrival,submit,dispatch,complete\n");
    begin
      logic [31:0] ctrl; csr_rd(R_CTRL, ctrl);
      csr_wr(R_CTRL, ctrl | 32'h1 | (1 << 16));          // enable + clear counters
    end
    start = u_dut.now;
    n_cpl = 0;
    forever begin
      bit sent;
      if (n_cpl >= total) break;
      sent = 1'b0;
      for (int s = 0; s < NT; s++) begin
        int tt;
        if (sent) break;
        tt = (rr + s) % NT;
        if (tl_i[tt] < tl_n[tt]) begin
          int ci = tl[tt][tl_i[tt]];
          bit ready_now = (t_window[tt] > 0) ? (t_outstanding[tt] < t_window[tt])
                                             : (u_dut.now - start >= 32'(b_arr[ci]));
          if (ready_now) begin
            cpl_ready = (rnd(100) < cpl_pct);
            gemm(tt, tt, b_m[ci], b_n[ci], b_k[ci], tx, b_prio[ci], b_dl[ci], -1, -1);
            c_arrival[tx] = (t_window[tt] > 0) ? u_dut.now : start + 32'(b_arr[ci]);
            tl_i[tt]++;
            sent = 1'b1;
            rr = (tt + 1) % NT;
          end
        end
      end
      if (!sent) begin cpl_ready = (rnd(100) < cpl_pct); tick(); end
    end
    cpl_ready = 1'b1;
    tick(10);
    $fclose(trace_fd); trace_fd = 0;
    fd = $fopen(cnt_file, "w");
    for (int i = 0; i < 20; i++) begin cnt_g(i, v); $fwrite(fd, "G %s %0d\n", g_names[i], v); end
    for (int tt = 0; tt < NT; tt++)
      for (int j = 0; j < 10; j++) begin cnt_t(tt, j, v); $fwrite(fd, "T%0d %s %0d\n", tt, t_names[j], v); end
    $fwrite(fd, "M MEM_BUSY_CYCLES %0d\n", u_mem.stat_busy_cycles);
    $fwrite(fd, "M RESIDUE_VIOLATIONS %0d\n", residue_violations);
    $fwrite(fd, "M SCOREBOARD_ERRORS %0d\n", errors);
    $fclose(fd);
  endtask

  // =============================================================================
  // Main
  // =============================================================================
  string test_name, bench_file;
  initial begin
    for (int i = 0; i < MAXCMD; i++) begin c_used[i] = 0; c_done[i] = 0; c_drop[i] = 0; end
    for (int t = 0; t < NT; t++) begin t_seq[t] = 0; t_outstanding[t] = 0; end
    for (int c = 0; c < NCQ; c++) begin cq_owner_sh[c] = 0; cq_valid_sh[c] = 0; end
    dbg = $test$plusargs("DBG");
    do_reset();
    if ($value$plusargs("BENCH=%s", bench_file)) begin
      run_bench(bench_file);
      test_name = {"bench:", bench_file};
    end else begin
      if (!$value$plusargs("TEST=%s", test_name)) test_name = "single_gemm";
      case (test_name)
        "single_gemm":         t_single_gemm();
        "queue_order":         t_queue_order();
        "rr_order":            t_rr_order();
        "invalid_cmds":        t_invalid_cmds();
        "dma_gate_isolation":  t_dma_gate_isolation();
        "dma_gate_write":      t_dma_gate_write();
        "spad_scrub":          t_spad_scrub();
        "spad_scrub_negative": t_spad_scrub_negative();
        "fairness":            t_fairness();
        "priority":            t_priority();
        "deadline":            t_deadline();
        "rate_limit":          t_rate_limit();
        "admission":           t_admission();
        "backpressure":        t_backpressure();
        "reset":               t_reset();
        "cpl_assoc_random":    t_cpl_assoc_random();
        "resource_exhaustion": t_resource_exhaustion();
        "faults":              t_faults();
        "suspend_resume":      t_suspend_resume();
        default: begin $display("unknown test %s", test_name); errors++; end
      endcase
    end
    tick(10);
    $display("RESULT %s %s errors=%0d completions=%0d residue_violations=%0d cycles=%0d",
             test_name, (errors == 0) ? "PASS" : "FAIL", errors, n_cpl, residue_violations, u_dut.now);
    $finish;
  end

  always @(posedge clk) if (dbg && rst_n && sub_valid && sub_ready)
    $display("[%0t] INTAKE q=%0d txn=%0d status=0x%02h accept=%0b reject=%0b route_ok=%0b",
             $time, sub_qid, u_dut.in_desc.txn_id, u_dut.in_status, u_dut.in_accept, u_dut.in_reject, u_dut.in_route_ok);

  // optional heartbeat (+HEARTBEAT=<cycles>) for debugging stalls
  int unsigned hb = 0;
  initial begin
    if ($value$plusargs("HEARTBEAT=%d", hb) && hb != 0) begin
      forever begin
        repeat (hb) @(posedge clk);
        $display("[hb %0t] now=%0d n_cpl=%0d sub_v=%0b sub_r=%0b adapter=%0d tc_phase=%0d sched_en=%0b any_elig=%0b qcnt0=%0d stat_cmds=%0d",
                 $time, u_dut.now, n_cpl, sub_valid, sub_ready, u_dut.u_adapter.state, tc_phase,
                 u_dut.sched_en, u_dut.any_elig, u_dut.q_count[0], u_tc.stat_cmds);
        $display("      qcnt=%0d,%0d,%0d,%0d elig=%b t_en=%b susp=%b fault=%b rl_tok0=%0d lc=%0b rej_empty=%0b cpl_v=%0b cpl_r=%0b pending=%0d",
                 u_dut.q_count[0], u_dut.q_count[1], u_dut.q_count[2], u_dut.q_count[3], u_dut.elig,
                 u_dut.t_en, u_dut.t_susp, u_dut.t_fault, $signed(u_dut.rl_tokens[0]), u_dut.lc_valid,
                 u_dut.rej_empty, cpl_valid, cpl_ready, pending_cnt());
        $fflush();
      end
    end
  end

  // global simulation timeout
  initial begin
    #(400_000_000);
    $display("RESULT %s FAIL global-timeout", test_name);
    $finish;
  end
endmodule
