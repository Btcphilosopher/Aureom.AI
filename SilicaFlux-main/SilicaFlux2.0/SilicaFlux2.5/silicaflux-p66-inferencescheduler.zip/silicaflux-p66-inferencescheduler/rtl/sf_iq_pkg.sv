// =============================================================================
// SilicaFlux Project 66 — INFERENCESCHEDULER
// Aureom.AI | SilicaFlux-CLOUD
// sf_iq_pkg.sv — command ABI, status codes, completion record, shared helpers
// =============================================================================
// The descriptor layout below IS the GEMM command ABI proposed by this project.
// No pre-existing SilicaFlux GEMM ABI was present in the audited workspace
// (see docs/REPO_AUDIT.md); if one is later supplied, this package is the single
// place to reconcile it.
//
// Supported today (and advertised in CAPS):  opcode GEMM, INT8 x INT8 -> INT32.
// Encodings for UINT8/BF16/FP16/FP32 are RESERVED so that they can be rejected
// explicitly with a distinct status. They are not implemented.
// =============================================================================
package sf_iq_pkg;

  // ---------------------------------------------------------------------------
  // Opcodes / numeric formats / accumulator precision
  // ---------------------------------------------------------------------------
  localparam logic [7:0] OP_GEMM   = 8'h01;   // C[MxN] = A[MxK] * B[KxN]

  localparam logic [3:0] FMT_INT8  = 4'h1;    // supported
  localparam logic [3:0] FMT_UINT8 = 4'h2;    // reserved, rejected
  localparam logic [3:0] FMT_BF16  = 4'h3;    // reserved, rejected (no BF16 engine)
  localparam logic [3:0] FMT_FP16  = 4'h4;    // reserved, rejected (no FP16 engine)

  localparam logic [3:0] ACC_INT32 = 4'h2;    // supported
  localparam logic [3:0] ACC_FP32  = 4'h3;    // reserved, rejected

  // ---------------------------------------------------------------------------
  // Completion status codes
  // ---------------------------------------------------------------------------
  localparam logic [7:0] ST_OK              = 8'h00;
  // intake / validation
  localparam logic [7:0] ST_BAD_QUEUE       = 8'h01;
  localparam logic [7:0] ST_TENANT_MISMATCH = 8'h02;
  localparam logic [7:0] ST_TENANT_DISABLED = 8'h03;
  localparam logic [7:0] ST_TENANT_FAULTED  = 8'h04;
  localparam logic [7:0] ST_RSVD_NONZERO    = 8'h05;
  localparam logic [7:0] ST_UNSUP_OP        = 8'h06;
  localparam logic [7:0] ST_UNSUP_FMT       = 8'h07;
  localparam logic [7:0] ST_UNSUP_PREC      = 8'h08;
  localparam logic [7:0] ST_BAD_DIMS        = 8'h09;
  localparam logic [7:0] ST_BAD_ALIGN       = 8'h0A;
  localparam logic [7:0] ST_BAD_CQ          = 8'h0B;
  localparam logic [7:0] ST_PERM_A          = 8'h0C;
  localparam logic [7:0] ST_PERM_B          = 8'h0D;
  localparam logic [7:0] ST_PERM_C          = 8'h0E;
  // admission
  localparam logic [7:0] ST_QUEUE_FULL      = 8'h10;
  localparam logic [7:0] ST_ADMISSION       = 8'h11;
  // execution
  localparam logic [7:0] ST_ABORTED         = 8'h20;
  localparam logic [7:0] ST_DMA_FAULT       = 8'h21;
  localparam logic [7:0] ST_TC_ERROR        = 8'h22;
  localparam logic [7:0] ST_TIMEOUT         = 8'h23;

  // ---------------------------------------------------------------------------
  // Scheduling policies (CTRL.policy)
  // ---------------------------------------------------------------------------
  localparam logic [2:0] POL_RR       = 3'd0;  // baseline round robin (1 cmd/visit)
  localparam logic [2:0] POL_WRR      = 3'd1;  // weighted RR, weight = commands/visit
  localparam logic [2:0] POL_DRR      = 3'd2;  // deficit RR on estimated TensorCore cycles
  localparam logic [2:0] POL_PRIO     = 3'd3;  // strict priority + aging, RR tie-break
  localparam logic [2:0] POL_DEADLINE = 3'd4;  // earliest-deadline-hint first, RR tie-break

  // ---------------------------------------------------------------------------
  // Command descriptor: 256 bits / 32 bytes, little-endian field packing
  // (bit 0 = opcode[0]).  Reserved bits and flags MUST be zero.
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [29:0] rsvd;       // [255:226] must be zero
    logic [23:0] deadline;   // [225:202] relative deadline HINT in cycles, 0 = none
    logic [7:0]  flags;      // [201:194] must be zero (no flags defined yet)
    logic [7:0]  cq_id;      // [193:186] completion queue
    logic [15:0] txn_id;     // [185:170] host transaction id, echoed in completion
    logic [1:0]  prio;       // [169:168] requested priority class (clamped to tenant cap)
    logic [7:0]  tenant_id;  // [167:160] claimed tenant; must equal queue owner
    logic [31:0] c_addr;     // [159:128] INT32 output, row-major MxN, 4B aligned
    logic [31:0] b_addr;     // [127:96]  INT8 operand B, row-major KxN, 4B aligned
    logic [31:0] a_addr;     // [95:64]   INT8 operand A, row-major MxK, 4B aligned
    logic [15:0] k;          // [63:48]
    logic [15:0] n;          // [47:32]
    logic [15:0] m;          // [31:16]
    logic [3:0]  acc_prec;   // [15:12] accumulator / output precision
    logic [3:0]  numfmt;     // [11:8]  operand numeric format
    logic [7:0]  opcode;     // [7:0]
  } desc_t;

  localparam int unsigned DESC_W = $bits(desc_t);   // 256

  // Queue entry = validated descriptor + intake metadata
  typedef struct packed {
    logic [31:0] cost;       // estimated TensorCore occupancy (cycles)
    logic [31:0] t_submit;   // cycle stamp at intake
    desc_t       desc;       // prio field already clamped to tenant cap
  } qentry_t;

  localparam int unsigned QENTRY_W = $bits(qentry_t);

  // Completion record (144 bits)
  typedef struct packed {
    logic [31:0] t_complete;
    logic [31:0] t_dispatch; // 0 if never dispatched
    logic [31:0] t_submit;
    logic [7:0]  status;
    logic [7:0]  cq_id;
    logic [7:0]  qid;
    logic [7:0]  tenant;
    logic [15:0] txn_id;
  } cpl_t;

  localparam int unsigned CPL_W = $bits(cpl_t);

  // TensorCore command / response (adapter <-> TensorCore). Proposed ABI.
  typedef struct packed {
    logic [7:0]  tag;
    logic [7:0]  domain;     // informational; the DMA gate uses the scheduler's own copy
    logic [31:0] c_addr;
    logic [31:0] b_addr;
    logic [31:0] a_addr;
    logic [15:0] k;
    logic [15:0] n;
    logic [15:0] m;
    logic [7:0]  opcode;
  } tc_cmd_t;

  localparam logic [7:0] TC_RSP_OK      = 8'h00;
  localparam logic [7:0] TC_RSP_DMA_ERR = 8'h01;
  localparam logic [7:0] TC_RSP_INT_ERR = 8'h02;

  typedef struct packed {
    logic [7:0] status;
    logic [7:0] tag;
  } tc_rsp_t;

  // TensorCore phase encoding (status input from TensorCore, used by counters)
  localparam logic [2:0] PH_IDLE    = 3'd0;
  localparam logic [2:0] PH_LOAD    = 3'd1;
  localparam logic [2:0] PH_COMPUTE = 3'd2;
  localparam logic [2:0] PH_STORE   = 3'd3;
  localparam logic [2:0] PH_RESP    = 3'd4;
  localparam logic [2:0] PH_SCRUB   = 3'd5;
  localparam logic [2:0] PH_HANG    = 3'd6;

  // Scratchpad ownership states
  localparam logic [1:0] SP_CLEAN   = 2'd0;   // known zero
  localparam logic [1:0] SP_OWNED   = 2'd1;   // holds data of spad_owner
  localparam logic [1:0] SP_UNKNOWN = 2'd2;   // after reset / TensorCore recovery

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  // Byte range [addr, addr+len-1] inside [base, limit] (inclusive). len > 0.
  // 34-bit arithmetic so that ranges wrapping past 2^32 are rejected.
  function automatic logic range_in(input logic [31:0] addr, input logic [31:0] len,
                                    input logic [31:0] base, input logic [31:0] limit);
    logic [33:0] last;
    last = {2'b00, addr} + {2'b00, len} - 34'd1;
    return (len != 32'd0) && (addr >= base) && (last <= {2'b00, limit}) && (limit >= base);
  endfunction

  // Estimated TensorCore occupancy for an output-stationary ROWS x COLS
  // systolic array: tiles * (K + ROWS + COLS - 1) compute + operand/result
  // word transfers. Used for DRR fairness and rate limiting; it is an
  // ESTIMATE (memory contention is not included).
  function automatic logic [31:0] est_cost(input logic [15:0] m, input logic [15:0] n,
                                           input logic [15:0] k,
                                           input int unsigned rows, input int unsigned cols);
    logic [31:0] tm, tn, comp, la, lb, st;
    tm   = ({16'd0, m} + rows - 1) / rows;
    tn   = ({16'd0, n} + cols - 1) / cols;
    comp = tm * tn * ({16'd0, k} + rows + cols - 1);
    la   = ({16'd0, m} * {16'd0, k} + 32'd3) >> 2;
    lb   = ({16'd0, k} * {16'd0, n} + 32'd3) >> 2;
    st   = {16'd0, m} * {16'd0, n};
    return comp + la + lb + st;
  endfunction

endpackage
