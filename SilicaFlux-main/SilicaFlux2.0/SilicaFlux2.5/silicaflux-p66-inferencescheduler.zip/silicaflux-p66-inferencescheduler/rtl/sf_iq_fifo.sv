// =============================================================================
// SilicaFlux Project 66 — sf_iq_fifo.sv
// Synchronous show-ahead FIFO. DEPTH must be a power of two.
// push when full / pop when empty are ignored and flagged by assertion.
// =============================================================================
module sf_iq_fifo #(
  parameter int unsigned W     = 32,
  parameter int unsigned DEPTH = 8,
  localparam int unsigned AW   = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          push,
  input  logic [W-1:0]  din,
  input  logic          pop,
  output logic [W-1:0]  dout,
  output logic          empty,
  output logic          full,
  output logic [AW:0]   count
);
  logic [W-1:0] mem [DEPTH];
  logic [AW-1:0] rd_ptr, wr_ptr;

  wire do_push = push && !full;
  wire do_pop  = pop  && !empty;

  assign empty = (count == '0);
  assign full  = (count == (AW+1)'(DEPTH));
  assign dout  = mem[rd_ptr];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_ptr <= '0;
      wr_ptr <= '0;
      count  <= '0;
    end else begin
      if (do_push) wr_ptr <= wr_ptr + 1'b1;
      if (do_pop)  rd_ptr <= rd_ptr + 1'b1;
      case ({do_push, do_pop})
        2'b10:   count <= count + 1'b1;
        2'b01:   count <= count - 1'b1;
        default: ;
      endcase
    end
  end

  // Storage is not reset (RAM-friendly). Entries are only readable when valid.
  always_ff @(posedge clk) begin
    if (do_push) mem[wr_ptr] <= din;
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk) begin
    if (rst_n) begin
      assert (!(push && full))  else $error("sf_iq_fifo: push while full");
      assert (!(pop  && empty)) else $error("sf_iq_fifo: pop while empty");
    end
  end
`endif
endmodule
