// =============================================================================
// SilicaFlux Project 66 — sf_iq_perf_counters.sv
// Global and per-tenant performance counters (CNT_W bits, read as lo/hi words).
//
// Global counter index (CSR 0x0800 + 8*i, +0 lo / +4 hi)
//   0 CYCLES              cycles since clear
//   1 TC_BUSY             TensorCore executing a scheduler command (adapter RUN)
//   2 TC_COMPUTE          TensorCore reports COMPUTE phase
//   3 DMA_WAIT            TensorCore reports LOAD or STORE phase
//   4 DMA_STALL           TensorCore memory request valid but not accepted
//   5 SCHED_OVERHEAD      scheduler enabled, TensorCore path idle, eligible work queued
//   6 DISPATCH            cycles presenting a command to the TensorCore
//   7 CTX_SWITCH_CYCLES   scratchpad scrub cycles (tenant change / recovery)
//   8 CTX_SWITCHES        scrubs started
//   9 CPL_BACKPRESSURE    completion held because the completion port is not ready
//  10 IDLE                TensorCore path idle and nothing eligible
//  11 DISPATCHED          commands sent to the TensorCore path
//  12 COMPLETED_OK
//  13 COMPLETED_ERR       TensorCore-path completions with non-OK status
//  14 REJECTED            intake rejections (incl. admission control)
//  15 ABORTED             queue entries discarded without execution
//  16 USEFUL_MACS         M*N*K of OK completions
//  17 CPL_DROPPED         completions that could not be routed to an owned CQ
//  18 QUEUE_WAIT_TOTAL    sum of (dispatch - submit) over dispatched commands
//  19 TIMEOUTS
//
// Per-tenant counter index (CSR 0x0C00 + 0x80*t + 8*j)
//   0 COMPLETED_OK  1 MACS  2 BUSY_CYCLES  3 QUEUE_WAIT_TOTAL  4 QUEUE_WAIT_MAX
//   5 REJECTED      6 ERRORS(+aborts)  7 DEADLINE_MISS  8 DISPATCHED  9 SCRUB_CYCLES
// =============================================================================
module sf_iq_perf_counters
  import sf_iq_pkg::*;
#(
  parameter int unsigned NT    = 4,
  parameter int unsigned CNT_W = 48,
  localparam int unsigned TW = (NT > 1) ? $clog2(NT) : 1,
  localparam int unsigned NG = 20,
  localparam int unsigned NTC = 10
) (
  input  logic              clk,
  input  logic              rst_n,
  input  logic              clear,
  // levels
  input  logic [2:0]        tc_phase,
  input  logic              tc_mem_stall,
  input  logic              sched_en,
  input  logic              any_elig,
  input  logic              st_busy,
  input  logic              st_scrub,
  input  logic              st_issue,
  input  logic              st_run,
  input  logic              st_hold,
  input  logic [TW-1:0]     active_tenant,
  // events
  input  logic              ev_dispatch,
  input  logic [TW-1:0]     ev_dispatch_tenant,
  input  logic [31:0]       ev_dispatch_wait,
  input  logic              ev_scrub_start,
  input  logic              ev_cpl,
  input  logic [TW-1:0]     ev_cpl_tenant,
  input  logic [7:0]        ev_cpl_status,
  input  logic [31:0]       ev_cpl_macs,
  input  logic              ev_cpl_deadline_miss,
  input  logic              ev_reject,
  input  logic              ev_reject_tv,      // tenant known
  input  logic [TW-1:0]     ev_reject_tenant,
  input  logic              ev_abort,
  input  logic [TW-1:0]     ev_abort_tenant,
  input  logic              ev_drop,
  input  logic              ev_timeout,
  // CSR read
  input  logic [15:0]       csr_addr,
  output logic              rd_hit,
  output logic [31:0]       rd_data
);
  logic [CNT_W-1:0] g [NG];
  logic [CNT_W-1:0] tc [NT][NTC];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NG; i++) g[i] <= '0;
      for (int t = 0; t < NT; t++) for (int j = 0; j < NTC; j++) tc[t][j] <= '0;
    end else if (clear) begin
      for (int i = 0; i < NG; i++) g[i] <= '0;
      for (int t = 0; t < NT; t++) for (int j = 0; j < NTC; j++) tc[t][j] <= '0;
    end else begin
      g[0] <= g[0] + 1'b1;
      if (st_run)                                           g[1]  <= g[1]  + 1'b1;
      if (tc_phase == PH_COMPUTE)                           g[2]  <= g[2]  + 1'b1;
      if (tc_phase == PH_LOAD || tc_phase == PH_STORE)      g[3]  <= g[3]  + 1'b1;
      if (tc_mem_stall)                                     g[4]  <= g[4]  + 1'b1;
      if (sched_en && !st_busy && any_elig)                 g[5]  <= g[5]  + 1'b1;
      if (st_issue)                                         g[6]  <= g[6]  + 1'b1;
      if (st_scrub)                                         g[7]  <= g[7]  + 1'b1;
      if (ev_scrub_start)                                   g[8]  <= g[8]  + 1'b1;
      if (st_hold && !ev_cpl)                               g[9]  <= g[9]  + 1'b1;
      if (!st_busy && !any_elig)                            g[10] <= g[10] + 1'b1;
      if (ev_dispatch)                                      g[11] <= g[11] + 1'b1;
      if (ev_cpl && ev_cpl_status == ST_OK)                 g[12] <= g[12] + 1'b1;
      if (ev_cpl && ev_cpl_status != ST_OK)                 g[13] <= g[13] + 1'b1;
      if (ev_reject)                                        g[14] <= g[14] + 1'b1;
      if (ev_abort)                                         g[15] <= g[15] + 1'b1;
      if (ev_cpl && ev_cpl_status == ST_OK)                 g[16] <= g[16] + CNT_W'(ev_cpl_macs);
      if (ev_drop)                                          g[17] <= g[17] + 1'b1;
      if (ev_dispatch)                                      g[18] <= g[18] + CNT_W'(ev_dispatch_wait);
      if (ev_timeout)                                       g[19] <= g[19] + 1'b1;

      for (int t = 0; t < NT; t++) begin
        if (ev_cpl && ev_cpl_tenant == TW'(t) && ev_cpl_status == ST_OK) begin
          tc[t][0] <= tc[t][0] + 1'b1;
          tc[t][1] <= tc[t][1] + CNT_W'(ev_cpl_macs);
        end
        if ((st_scrub || st_issue || st_run) && active_tenant == TW'(t))
          tc[t][2] <= tc[t][2] + 1'b1;
        if (ev_dispatch && ev_dispatch_tenant == TW'(t)) begin
          tc[t][3] <= tc[t][3] + CNT_W'(ev_dispatch_wait);
          if (CNT_W'(ev_dispatch_wait) > tc[t][4]) tc[t][4] <= CNT_W'(ev_dispatch_wait);
          tc[t][8] <= tc[t][8] + 1'b1;
        end
        if (ev_reject && ev_reject_tv && ev_reject_tenant == TW'(t))
          tc[t][5] <= tc[t][5] + 1'b1;
        if ((ev_cpl && ev_cpl_tenant == TW'(t) && ev_cpl_status != ST_OK) ||
            (ev_abort && ev_abort_tenant == TW'(t)))
          tc[t][6] <= tc[t][6] + ((ev_cpl && ev_cpl_tenant == TW'(t) && ev_cpl_status != ST_OK) &&
                                  (ev_abort && ev_abort_tenant == TW'(t)) ? CNT_W'(2) : CNT_W'(1));
        if (ev_cpl && ev_cpl_tenant == TW'(t) && ev_cpl_deadline_miss)
          tc[t][7] <= tc[t][7] + 1'b1;
        if (st_scrub && active_tenant == TW'(t))
          tc[t][9] <= tc[t][9] + 1'b1;
      end
    end
  end

  // CSR read
  always_comb begin
    rd_hit  = 1'b0;
    rd_data = 32'd0;
    for (int i = 0; i < NG; i++) begin
      logic [63:0] v;
      v = 64'(g[i]);
      if (csr_addr == 16'h0800 + 16'(i*8))     begin rd_hit = 1'b1; rd_data = v[31:0];  end
      if (csr_addr == 16'h0800 + 16'(i*8 + 4)) begin rd_hit = 1'b1; rd_data = v[63:32]; end
    end
    for (int t = 0; t < NT; t++) begin
      for (int j = 0; j < NTC; j++) begin
        logic [63:0] v;
        v = 64'(tc[t][j]);
        if (csr_addr == 16'h0C00 + 16'(t*128 + j*8))     begin rd_hit = 1'b1; rd_data = v[31:0];  end
        if (csr_addr == 16'h0C00 + 16'(t*128 + j*8 + 4)) begin rd_hit = 1'b1; rd_data = v[63:32]; end
      end
    end
  end

`ifndef SYNTHESIS
  initial assert (NT <= 8) else $fatal(1, "per-tenant counter map supports NT<=8");
`endif
endmodule
