// =============================================================================
// SilicaFlux Project 66 — sf_iq_tenant_ctx.sv
// Control + tenant context register file.
//
// Holds every piece of configuration that defines a protection domain:
//   * queue -> tenant ownership, per-queue weight, admission limit, error CQ
//   * completion-queue -> tenant ownership
//   * per-tenant enable / suspend / fault (quarantine) / priority cap
//   * per-tenant memory regions (base, limit inclusive, R/W permission)
//   * per-tenant rate-limit configuration
//   * global scheduler control (enable, policy, watchdog, DRR quantum, aging)
//
// Reset state is deny-by-default: scheduler disabled, all queues/CQs/tenants
// disabled, all regions without permission, priority cap 0.
//
// The register file is written only through the privileged CSR port (host /
// hypervisor). Tenant-facing doorbells never reach this block.
// See docs/REGISTER_MAP.md.
// =============================================================================
module sf_iq_tenant_ctx #(
  parameter int unsigned NQ     = 4,
  parameter int unsigned NT     = 4,
  parameter int unsigned NCQ    = 4,
  parameter int unsigned NREG   = 2,
  parameter int unsigned QDEPTH = 8,
  parameter bit          ALLOW_SCRUB_BYPASS = 1'b0,
  localparam int unsigned TW = (NT  > 1) ? $clog2(NT)  : 1,
  localparam int unsigned CW = (NCQ > 1) ? $clog2(NCQ) : 1
) (
  input  logic                         clk,
  input  logic                         rst_n,
  // privileged CSR port
  input  logic                         csr_we,
  input  logic [15:0]                  csr_addr,
  input  logic [31:0]                  csr_wdata,
  output logic                         rd_hit,
  output logic [31:0]                  rd_data,
  // hardware fault (quarantine) set, one-hot per tenant
  input  logic [NT-1:0]                fault_set,
  // global
  output logic                         sched_en,
  output logic [2:0]                   policy,
  output logic                         scrub_bypass,
  output logic [31:0]                  wd_limit,
  output logic [31:0]                  drr_quantum,
  output logic [31:0]                  aging_limit,
  output logic                         cnt_clear,
  // queues
  output logic [NQ-1:0]                q_en,
  output logic [NQ-1:0][TW-1:0]        q_owner,
  output logic [NQ-1:0][CW-1:0]        q_err_cq,
  output logic [NQ-1:0][7:0]           q_weight,
  output logic [NQ-1:0][7:0]           q_admit,
  // completion queues
  output logic [NCQ-1:0]               cq_valid,
  output logic [NCQ-1:0][TW-1:0]       cq_owner,
  // tenants
  output logic [NT-1:0]                t_en,
  output logic [NT-1:0]                t_susp,
  output logic [NT-1:0]                t_fault,
  output logic [NT-1:0][1:0]           t_prio_cap,
  output logic [NT-1:0]                t_rl_en,
  output logic [NT-1:0][31:0]          t_rl_rate,
  output logic [NT-1:0][31:0]          t_rl_period,
  output logic [NT-1:0][31:0]          t_rl_burst,
  output logic [NT-1:0][NREG-1:0][31:0] r_base,
  output logic [NT-1:0][NREG-1:0][31:0] r_limit,
  output logic [NT-1:0][NREG-1:0][1:0]  r_perm      // [0]=read [1]=write
);

  // ---------------------------------------------------------------------------
  // Address map
  // ---------------------------------------------------------------------------
  localparam logic [15:0] A_CTRL     = 16'h0000;
  localparam logic [15:0] A_WD       = 16'h0008;
  localparam logic [15:0] A_QUANTUM  = 16'h000C;
  localparam logic [15:0] A_AGING    = 16'h0010;
  localparam logic [15:0] A_Q_BASE   = 16'h0100;  // + q*0x10
  localparam logic [15:0] A_CQ_BASE  = 16'h0200;  // + c*0x4
  localparam logic [15:0] A_T_BASE   = 16'h0400;  // + t*0x40

  function automatic logic [15:0] qa(input int unsigned q, input int unsigned off);
    return A_Q_BASE + 16'(q * 16) + 16'(off);
  endfunction
  function automatic logic [15:0] ca(input int unsigned c);
    return A_CQ_BASE + 16'(c * 4);
  endfunction
  function automatic logic [15:0] ta(input int unsigned t, input int unsigned off);
    return A_T_BASE + 16'(t * 64) + 16'(off);
  endfunction
  // per-tenant offsets
  localparam int unsigned T_CTRL = 'h00, T_RLCFG = 'h04, T_RLRATE = 'h08,
                          T_RLPER = 'h0C, T_RLBURST = 'h10;
  localparam int unsigned T_REG0 = 'h18;   // region r: +r*0xC {BASE, LIMIT, PERM}

  // ---------------------------------------------------------------------------
  // Writes
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sched_en     <= 1'b0;
      policy       <= 3'd0;
      scrub_bypass <= 1'b0;
      wd_limit     <= 32'h0010_0000;
      drr_quantum  <= 32'd1024;
      aging_limit  <= 32'd0;
      cnt_clear    <= 1'b0;
      for (int q = 0; q < NQ; q++) begin
        q_en[q]     <= 1'b0;
        q_owner[q]  <= TW'(q % NT);
        q_err_cq[q] <= '0;
        q_weight[q] <= 8'd1;
        q_admit[q]  <= 8'(QDEPTH);
      end
      for (int c = 0; c < NCQ; c++) begin
        cq_valid[c] <= 1'b0;
        cq_owner[c] <= '0;
      end
      for (int t = 0; t < NT; t++) begin
        t_en[t]        <= 1'b0;
        t_susp[t]      <= 1'b0;
        t_fault[t]     <= 1'b0;
        t_prio_cap[t]  <= 2'd0;
        t_rl_en[t]     <= 1'b0;
        t_rl_rate[t]   <= 32'd0;
        t_rl_period[t] <= 32'd1;
        t_rl_burst[t]  <= 32'd0;
        for (int r = 0; r < NREG; r++) begin
          r_base[t][r]  <= 32'd0;
          r_limit[t][r] <= 32'd0;
          r_perm[t][r]  <= 2'b00;
        end
      end
    end else begin
      cnt_clear <= 1'b0;
      if (csr_we) begin
        if (csr_addr == A_CTRL) begin
          sched_en     <= csr_wdata[0];
          policy       <= csr_wdata[3:1];
          scrub_bypass <= ALLOW_SCRUB_BYPASS ? csr_wdata[8] : 1'b0;
          cnt_clear    <= csr_wdata[16];
        end
        if (csr_addr == A_WD)      wd_limit    <= csr_wdata;
        if (csr_addr == A_QUANTUM) drr_quantum <= csr_wdata;
        if (csr_addr == A_AGING)   aging_limit <= csr_wdata;
        for (int q = 0; q < NQ; q++) begin
          if (csr_addr == qa(q, 0)) begin
            q_en[q]     <= csr_wdata[0];
            q_owner[q]  <= csr_wdata[8 +: TW];
            q_err_cq[q] <= csr_wdata[16 +: CW];
          end
          if (csr_addr == qa(q, 4)) q_weight[q] <= (csr_wdata[7:0] == 8'd0) ? 8'd1 : csr_wdata[7:0];
          if (csr_addr == qa(q, 8)) q_admit[q]  <= (csr_wdata[7:0] > 8'(QDEPTH)) ? 8'(QDEPTH)
                                                                                   : csr_wdata[7:0];
        end
        for (int c = 0; c < NCQ; c++) begin
          if (csr_addr == ca(c)) begin
            cq_valid[c] <= csr_wdata[0];
            cq_owner[c] <= csr_wdata[8 +: TW];
          end
        end
        for (int t = 0; t < NT; t++) begin
          if (csr_addr == ta(t, T_CTRL)) begin
            t_en[t]       <= csr_wdata[0];
            t_susp[t]     <= csr_wdata[1];
            t_prio_cap[t] <= csr_wdata[5:4];
          end
          if (csr_addr == ta(t, T_RLCFG))   t_rl_en[t]     <= csr_wdata[0];
          if (csr_addr == ta(t, T_RLRATE))  t_rl_rate[t]   <= csr_wdata;
          if (csr_addr == ta(t, T_RLPER))   t_rl_period[t] <= (csr_wdata == 32'd0) ? 32'd1 : csr_wdata;
          if (csr_addr == ta(t, T_RLBURST)) t_rl_burst[t]  <= csr_wdata;
          for (int r = 0; r < NREG; r++) begin
            if (csr_addr == ta(t, T_REG0 + r*12 + 0)) r_base[t][r]  <= csr_wdata;
            if (csr_addr == ta(t, T_REG0 + r*12 + 4)) r_limit[t][r] <= csr_wdata;
            if (csr_addr == ta(t, T_REG0 + r*12 + 8)) r_perm[t][r]  <= csr_wdata[1:0];
          end
        end
      end
      // Fault: hardware set has priority over a simultaneous software clear.
      for (int t = 0; t < NT; t++) begin
        if (fault_set[t])
          t_fault[t] <= 1'b1;
        else if (csr_we && csr_addr == ta(t, T_CTRL) && csr_wdata[2])
          t_fault[t] <= 1'b0;   // W1C
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Reads (combinational)
  // ---------------------------------------------------------------------------
  always_comb begin
    rd_hit  = 1'b0;
    rd_data = 32'd0;
    if (csr_addr == A_CTRL) begin
      rd_hit = 1'b1; rd_data = {23'd0, scrub_bypass, 4'd0, policy, sched_en};
    end
    if (csr_addr == A_WD)      begin rd_hit = 1'b1; rd_data = wd_limit;    end
    if (csr_addr == A_QUANTUM) begin rd_hit = 1'b1; rd_data = drr_quantum; end
    if (csr_addr == A_AGING)   begin rd_hit = 1'b1; rd_data = aging_limit; end
    for (int q = 0; q < NQ; q++) begin
      if (csr_addr == qa(q, 0)) begin
        rd_hit = 1'b1;
        rd_data = 32'd0;
        rd_data[0] = q_en[q];
        rd_data[8 +: TW]  = q_owner[q];
        rd_data[16 +: CW] = q_err_cq[q];
      end
      if (csr_addr == qa(q, 4)) begin rd_hit = 1'b1; rd_data = {24'd0, q_weight[q]}; end
      if (csr_addr == qa(q, 8)) begin rd_hit = 1'b1; rd_data = {24'd0, q_admit[q]};  end
    end
    for (int c = 0; c < NCQ; c++) begin
      if (csr_addr == ca(c)) begin
        rd_hit = 1'b1;
        rd_data = 32'd0;
        rd_data[0] = cq_valid[c];
        rd_data[8 +: TW] = cq_owner[c];
      end
    end
    for (int t = 0; t < NT; t++) begin
      if (csr_addr == ta(t, T_CTRL)) begin
        rd_hit = 1'b1; rd_data = {26'd0, t_prio_cap[t], 1'b0, t_fault[t], t_susp[t], t_en[t]};
      end
      if (csr_addr == ta(t, T_RLCFG))   begin rd_hit = 1'b1; rd_data = {31'd0, t_rl_en[t]}; end
      if (csr_addr == ta(t, T_RLRATE))  begin rd_hit = 1'b1; rd_data = t_rl_rate[t];   end
      if (csr_addr == ta(t, T_RLPER))   begin rd_hit = 1'b1; rd_data = t_rl_period[t]; end
      if (csr_addr == ta(t, T_RLBURST)) begin rd_hit = 1'b1; rd_data = t_rl_burst[t];  end
      for (int r = 0; r < NREG; r++) begin
        if (csr_addr == ta(t, T_REG0 + r*12 + 0)) begin rd_hit = 1'b1; rd_data = r_base[t][r];  end
        if (csr_addr == ta(t, T_REG0 + r*12 + 4)) begin rd_hit = 1'b1; rd_data = r_limit[t][r]; end
        if (csr_addr == ta(t, T_REG0 + r*12 + 8)) begin rd_hit = 1'b1; rd_data = {30'd0, r_perm[t][r]}; end
      end
    end
  end

`ifndef SYNTHESIS
  initial begin
    assert (NREG >= 1 && NREG <= 3) else $fatal(1, "NREG must be 1..3 (register map stride)");
    assert (NQ <= 16 && NT <= 16 && NCQ <= 64) else $fatal(1, "register map supports NQ<=16, NT<=16, NCQ<=64");
  end
`endif
endmodule
