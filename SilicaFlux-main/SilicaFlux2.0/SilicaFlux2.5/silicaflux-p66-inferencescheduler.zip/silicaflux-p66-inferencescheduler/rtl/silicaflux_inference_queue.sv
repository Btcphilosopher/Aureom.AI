// =============================================================================
// SilicaFlux Project 66 — INFERENCESCHEDULER
// silicaflux_inference_queue.sv — multi-tenant TensorCore command scheduler
// Aureom.AI | SilicaFlux-CLOUD
//
//   Host submission ──► Descriptor validation ──► Tenant queues (NQ FIFOs)
//        (doorbell qid)     (intake, ordered checks)     │
//                                                         ▼
//                         Scheduling policy (sf_iq_arbiter, rate limiter)
//                                                         │
//                              Dispatch-time revalidation ┤──► local abort
//                                                         ▼
//                         Tensor command adapter (scrub / issue / watchdog)
//                                │                       ▲
//                       TensorCore cmd/rsp        DMA gate (active tenant)
//                                                         │
//   Completion port ◄── Completion router (CQ ownership) ◄┘
//
// One command executes at a time (the TensorCore is single-issue and has no
// state save/restore); tenant switches happen only at command boundaries.
// Supported work: GEMM, INT8 x INT8 -> INT32. Everything else is rejected.
// =============================================================================
module silicaflux_inference_queue
  import sf_iq_pkg::*;
#(
  parameter int unsigned NQ        = 4,
  parameter int unsigned NT        = 4,
  parameter int unsigned NCQ       = 4,
  parameter int unsigned QDEPTH    = 8,
  parameter int unsigned NREG      = 2,
  parameter int unsigned MAX_M     = 64,
  parameter int unsigned MAX_N     = 64,
  parameter int unsigned MAX_K     = 64,
  parameter int unsigned TC_ROWS   = 4,
  parameter int unsigned TC_COLS   = 4,
  parameter int unsigned REJ_DEPTH = 4,
  parameter int unsigned CNT_W     = 48,
  parameter bit          ALLOW_SCRUB_BYPASS = 1'b0,   // negative-test builds only
  localparam int unsigned TW = (NT  > 1) ? $clog2(NT)  : 1,
  localparam int unsigned CW = (NCQ > 1) ? $clog2(NCQ) : 1,
  localparam int unsigned QW = (NQ  > 1) ? $clog2(NQ)  : 1,
  localparam int unsigned DW = $clog2(QDEPTH)
) (
  input  logic               clk,
  input  logic               rst_n,
  // privileged CSR port (combinational read)
  input  logic               csr_we,
  input  logic [15:0]        csr_addr,
  input  logic [31:0]        csr_wdata,
  output logic [31:0]        csr_rdata,
  // submission (qid comes from the doorbell page, not from tenant data)
  input  logic               sub_valid,
  output logic               sub_ready,
  input  logic [7:0]         sub_qid,
  input  logic [DESC_W-1:0]  sub_desc,
  // completion
  output logic               cpl_valid,
  input  logic               cpl_ready,
  output logic [CPL_W-1:0]   cpl_data,
  // TensorCore control
  output logic               tc_cmd_valid,
  input  logic               tc_cmd_ready,
  output tc_cmd_t            tc_cmd,
  input  logic               tc_rsp_valid,
  output logic               tc_rsp_ready,
  input  tc_rsp_t            tc_rsp,
  output logic               tc_scrub_req,
  input  logic               tc_scrub_done,
  output logic               tc_soft_reset,
  input  logic [2:0]         tc_phase,
  // TensorCore memory master -> gate
  input  logic               tcm_req_valid,
  output logic               tcm_req_ready,
  input  logic               tcm_req_we,
  input  logic [31:0]        tcm_req_addr,
  input  logic [31:0]        tcm_req_wdata,
  output logic               tcm_rsp_valid,
  output logic [31:0]        tcm_rsp_rdata,
  output logic               tcm_rsp_err,
  // gate -> memory subsystem (CloudDMA / MemoryPool port)
  output logic               mem_req_valid,
  input  logic               mem_req_ready,
  output logic               mem_req_we,
  output logic [31:0]        mem_req_addr,
  output logic [31:0]        mem_req_wdata,
  output logic               mem_req_poison,
  input  logic               mem_rsp_valid,
  input  logic [31:0]        mem_rsp_rdata,
  input  logic               mem_rsp_err,
  // interrupt: any sticky error set
  output logic               irq_err
);
  // ---------------------------------------------------------------------------
  // Time base
  // ---------------------------------------------------------------------------
  logic [31:0] now;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) now <= 32'd0; else now <= now + 32'd1;

  // ---------------------------------------------------------------------------
  // Context register file
  // ---------------------------------------------------------------------------
  logic                          sched_en, scrub_bypass, cnt_clear;
  logic [2:0]                    policy;
  logic [31:0]                   wd_limit, drr_quantum, aging_limit;
  logic [NQ-1:0]                 q_en;
  logic [NQ-1:0][TW-1:0]         q_owner;
  logic [NQ-1:0][CW-1:0]         q_err_cq;
  logic [NQ-1:0][7:0]            q_weight, q_admit;
  logic [NCQ-1:0]                cq_valid;
  logic [NCQ-1:0][TW-1:0]        cq_owner;
  logic [NT-1:0]                 t_en, t_susp, t_fault, t_rl_en;
  logic [NT-1:0][1:0]            t_prio_cap;
  logic [NT-1:0][31:0]           t_rl_rate, t_rl_period, t_rl_burst;
  logic [NT-1:0][NREG-1:0][31:0] r_base, r_limit;
  logic [NT-1:0][NREG-1:0][1:0]  r_perm;
  logic [NT-1:0]                 fault_set;
  logic                          ctx_hit;
  logic [31:0]                   ctx_rdata;

  sf_iq_tenant_ctx #(
    .NQ(NQ), .NT(NT), .NCQ(NCQ), .NREG(NREG), .QDEPTH(QDEPTH),
    .ALLOW_SCRUB_BYPASS(ALLOW_SCRUB_BYPASS)
  ) u_ctx (
    .clk, .rst_n,
    .csr_we, .csr_addr, .csr_wdata,
    .rd_hit(ctx_hit), .rd_data(ctx_rdata),
    .fault_set,
    .sched_en, .policy, .scrub_bypass, .wd_limit, .drr_quantum, .aging_limit, .cnt_clear,
    .q_en, .q_owner, .q_err_cq, .q_weight, .q_admit,
    .cq_valid, .cq_owner,
    .t_en, .t_susp, .t_fault, .t_prio_cap,
    .t_rl_en, .t_rl_rate, .t_rl_period, .t_rl_burst,
    .r_base, .r_limit, .r_perm
  );

  // ---------------------------------------------------------------------------
  // Intake: validation + admission
  // ---------------------------------------------------------------------------
  desc_t         in_desc;
  logic [7:0]    in_status;
  logic          in_qid_ok, in_route_ok;
  logic [TW-1:0] in_owner;
  logic [CW-1:0] in_route_cq;
  logic [1:0]    in_prio;
  logic [31:0]   in_cost;
  logic [QW-1:0] in_q;

  assign in_desc = desc_t'(sub_desc);
  assign in_q    = sub_qid[QW-1:0];

  sf_iq_desc_validator #(
    .NQ(NQ), .NT(NT), .NCQ(NCQ), .NREG(NREG),
    .MAX_M(MAX_M), .MAX_N(MAX_N), .MAX_K(MAX_K), .TC_ROWS(TC_ROWS), .TC_COLS(TC_COLS)
  ) u_val_intake (
    .desc(in_desc), .qid(sub_qid),
    .q_en, .q_owner, .q_err_cq, .cq_valid, .cq_owner, .t_en, .t_fault, .t_prio_cap,
    .r_base, .r_limit, .r_perm,
    .status(in_status), .qid_ok(in_qid_ok), .owner(in_owner),
    .route_ok(in_route_ok), .route_cq(in_route_cq), .prio_eff(in_prio), .cost(in_cost)
  );

  // tenant queues
  logic [NQ-1:0]          q_push, q_pop, q_empty, q_full;
  logic [NQ-1:0][DW:0]    q_count;
  qentry_t                q_head [NQ];
  qentry_t                in_entry;

  always_comb begin
    in_entry           = '0;
    in_entry.desc      = in_desc;
    in_entry.desc.prio = in_prio;
    in_entry.t_submit  = now;
    in_entry.cost      = in_cost;
  end

  // reject FIFO
  logic rej_push, rej_pop, rej_empty, rej_full;
  cpl_t rej_din, rej_head;
  logic [$clog2(REJ_DEPTH):0] rej_count;

  logic in_fire, in_room, in_admit, in_accept, in_reject;
  logic [7:0] in_rej_status;

  assign sub_ready = !rej_full;
  assign in_fire   = sub_valid && sub_ready;
  assign in_room   = in_qid_ok && (q_count[in_q] < (DW+1)'(QDEPTH));
  assign in_admit  = in_qid_ok && ({{(8-DW-1){1'b0}}, q_count[in_q]} < q_admit[in_q]);
  assign in_accept = in_fire && (in_status == ST_OK) && in_room && in_admit;
  assign in_reject = in_fire && !in_accept;
  assign in_rej_status = (in_status != ST_OK) ? in_status :
                         (!in_room)           ? ST_QUEUE_FULL : ST_ADMISSION;

  always_comb begin
    rej_din            = '0;
    rej_din.txn_id     = in_desc.txn_id;
    rej_din.tenant     = in_qid_ok ? 8'(in_owner) : 8'd0;
    rej_din.qid        = sub_qid;
    rej_din.cq_id      = 8'(in_route_cq);
    rej_din.status     = in_rej_status;
    rej_din.t_submit   = now;
    rej_din.t_dispatch = 32'd0;
    rej_din.t_complete = now;
  end
  assign rej_push = in_reject && in_route_ok;

  sf_iq_fifo #(.W(CPL_W), .DEPTH(REJ_DEPTH)) u_rej_fifo (
    .clk, .rst_n, .push(rej_push), .din(rej_din), .pop(rej_pop),
    .dout(rej_head), .empty(rej_empty), .full(rej_full), .count(rej_count)
  );

  for (genvar gq = 0; gq < NQ; gq++) begin : g_q
    assign q_push[gq] = in_accept && (in_q == QW'(gq));
    sf_iq_fifo #(.W(QENTRY_W), .DEPTH(QDEPTH)) u_fifo (
      .clk, .rst_n, .push(q_push[gq]), .din(in_entry), .pop(q_pop[gq]),
      .dout(q_head[gq]), .empty(q_empty[gq]), .full(q_full[gq]), .count(q_count[gq])
    );
  end

  // ---------------------------------------------------------------------------
  // Arbitration
  // ---------------------------------------------------------------------------
  logic [NQ-1:0]         head_valid;
  logic [NQ-1:0][1:0]    head_prio;
  logic [NQ-1:0][31:0]   head_cost, head_submit;
  logic [NQ-1:0][23:0]   head_deadline;
  logic [NQ-1:0]         elig;
  logic                  any_elig;
  logic                  sel_valid, take, take_charge, allow;
  logic [QW-1:0]         sel_q;
  logic [NT-1:0][31:0]   rl_tokens;

  always_comb begin
    for (int q = 0; q < NQ; q++) begin
      head_valid[q]    = !q_empty[q];
      head_prio[q]     = q_head[q].desc.prio;
      head_cost[q]     = q_head[q].cost;
      head_submit[q]   = q_head[q].t_submit;
      head_deadline[q] = q_head[q].desc.deadline;
    end
  end

  logic disp_ready;
  logic lc_valid;
  logic               occ_valid;
  logic [7:0]         occ_qid;
  logic [TW-1:0]      occ_tenant;
  logic signed [31:0] occ_delta;

  assign allow = sched_en && disp_ready && !lc_valid;

  sf_iq_arbiter #(.NQ(NQ), .NT(NT)) u_arb (
    .clk, .rst_n, .now,
    .policy, .drr_quantum, .aging_limit,
    .head_valid, .head_prio, .head_cost, .head_submit, .head_deadline,
    .q_en, .q_owner, .q_weight,
    .t_en, .t_susp, .t_fault, .t_rl_en, .t_rl_rate, .t_rl_period, .t_rl_burst,
    .allow, .take, .take_charge,
    .corr_valid(occ_valid), .corr_q(occ_qid[QW-1:0]), .corr_tenant(occ_tenant), .corr_delta(occ_delta),
    .sel_valid, .sel_q, .elig, .any_elig, .rl_tokens
  );

  // dispatch-time revalidation of the selected head
  qentry_t       sel_entry;
  logic [7:0]    dp_status;
  logic          dp_qid_ok, dp_route_ok;
  logic [TW-1:0] dp_owner;
  logic [CW-1:0] dp_route_cq;
  logic [1:0]    dp_prio;
  logic [31:0]   dp_cost;

  assign sel_entry = q_head[sel_q];

  sf_iq_desc_validator #(
    .NQ(NQ), .NT(NT), .NCQ(NCQ), .NREG(NREG),
    .MAX_M(MAX_M), .MAX_N(MAX_N), .MAX_K(MAX_K), .TC_ROWS(TC_ROWS), .TC_COLS(TC_COLS)
  ) u_val_dispatch (
    .desc(sel_entry.desc), .qid(8'(sel_q)),
    .q_en, .q_owner, .q_err_cq, .cq_valid, .cq_owner, .t_en, .t_fault, .t_prio_cap,
    .r_base, .r_limit, .r_perm,
    .status(dp_status), .qid_ok(dp_qid_ok), .owner(dp_owner),
    .route_ok(dp_route_ok), .route_cq(dp_route_cq), .prio_eff(dp_prio), .cost(dp_cost)
  );

  logic sel_ok, sel_bad;
  assign sel_ok      = sel_valid && (dp_status == ST_OK);
  assign sel_bad     = sel_valid && (dp_status != ST_OK);
  assign take        = sel_valid;
  assign take_charge = sel_ok;

  // abort drain: queued work of disabled queues / disabled or faulted tenants
  logic [NQ-1:0] drain_need;
  logic          drain_any, drain_fire;
  logic [QW-1:0] drain_q;
  always_comb begin
    drain_any = 1'b0;
    drain_q   = '0;
    for (int q = 0; q < NQ; q++) begin
      logic [TW-1:0] ht;
      ht = q_head[q].desc.tenant_id[TW-1:0];
      drain_need[q] = !q_empty[q] && (!q_en[q] || !t_en[ht] || t_fault[ht]);
    end
    for (int q = NQ - 1; q >= 0; q--) begin
      if (drain_need[q]) begin
        drain_any = 1'b1;
        drain_q   = QW'(q);
      end
    end
  end
  assign drain_fire = drain_any && !lc_valid && !sel_bad;

  always_comb begin
    for (int q = 0; q < NQ; q++)
      q_pop[q] = (take && sel_q == QW'(q)) || (drain_fire && drain_q == QW'(q));
  end

  // local-completion slot (aborts / revalidation failures)
  cpl_t lc_rec;
  logic lc_accept;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lc_valid <= 1'b0;
      lc_rec   <= '0;
    end else begin
      if (lc_accept) lc_valid <= 1'b0;
      if (sel_bad || drain_fire) begin
        qentry_t e;
        e = sel_bad ? sel_entry : q_head[drain_q];
        lc_valid          <= 1'b1;
        lc_rec            <= '0;
        lc_rec.txn_id     <= e.desc.txn_id;
        lc_rec.tenant     <= e.desc.tenant_id;
        lc_rec.qid        <= sel_bad ? 8'(sel_q) : 8'(drain_q);
        lc_rec.cq_id      <= e.desc.cq_id;
        lc_rec.status     <= sel_bad ? dp_status : ST_ABORTED;
        lc_rec.t_submit   <= e.t_submit;
        lc_rec.t_dispatch <= 32'd0;
        lc_rec.t_complete <= now;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Tensor command adapter + DMA gate
  // ---------------------------------------------------------------------------
  logic          ad_cpl_valid, ad_cpl_ready;
  cpl_t          ad_cpl;
  logic          gate_fault, gate_fault_we;
  logic [31:0]   gate_fault_addr;
  logic          active_valid;
  logic [TW-1:0] active_tenant;
  logic          st_busy, st_scrub, st_issue, st_run, st_hold;
  logic [1:0]    spad_state;
  logic [TW-1:0] spad_owner;
  logic          ev_scrub_start, ev_cpl, ev_cpl_dl_miss, ev_timeout, ev_bad_tag, ev_stray_dma;
  logic [TW-1:0] ev_cpl_tenant;
  logic [7:0]    ev_cpl_status;
  logic [31:0]   ev_cpl_macs;

  sf_iq_tensor_adapter #(.NT(NT), .NQ(NQ)) u_adapter (
    .clk, .rst_n, .now, .wd_limit, .scrub_bypass,
    .disp_valid(sel_ok), .disp_ready, .disp_entry(sel_entry), .disp_qid(8'(sel_q)),
    .disp_tenant(sel_entry.desc.tenant_id[TW-1:0]),
    .tc_cmd_valid, .tc_cmd_ready, .tc_cmd, .tc_rsp_valid, .tc_rsp_ready, .tc_rsp,
    .tc_scrub_req, .tc_scrub_done, .tc_soft_reset,
    .gate_fault, .active_valid, .active_tenant,
    .cpl_valid(ad_cpl_valid), .cpl_ready(ad_cpl_ready), .cpl(ad_cpl),
    .fault_set,
    .st_busy, .st_scrub, .st_issue, .st_run, .st_hold, .spad_state, .spad_owner,
    .ev_scrub_start, .ev_cpl, .ev_cpl_tenant, .ev_cpl_status, .ev_cpl_macs,
    .ev_cpl_deadline_miss(ev_cpl_dl_miss), .ev_timeout, .ev_bad_tag, .ev_stray_dma,
    .occ_valid, .occ_qid, .occ_tenant, .occ_delta
  );

  sf_iq_dma_gate #(.NT(NT), .NREG(NREG)) u_gate (
    .clk, .rst_n, .active_valid, .active_tenant, .r_base, .r_limit, .r_perm,
    .m_req_valid(tcm_req_valid), .m_req_ready(tcm_req_ready), .m_req_we(tcm_req_we),
    .m_req_addr(tcm_req_addr), .m_req_wdata(tcm_req_wdata),
    .m_rsp_valid(tcm_rsp_valid), .m_rsp_rdata(tcm_rsp_rdata), .m_rsp_err(tcm_rsp_err),
    .s_req_valid(mem_req_valid), .s_req_ready(mem_req_ready), .s_req_we(mem_req_we),
    .s_req_addr(mem_req_addr), .s_req_wdata(mem_req_wdata), .s_req_poison(mem_req_poison),
    .s_rsp_valid(mem_rsp_valid), .s_rsp_rdata(mem_rsp_rdata), .s_rsp_err(mem_rsp_err),
    .fault(gate_fault), .fault_addr(gate_fault_addr), .fault_we(gate_fault_we)
  );

  // ---------------------------------------------------------------------------
  // Completion router
  // ---------------------------------------------------------------------------
  logic [2:0] src_valid, src_ready;
  cpl_t [2:0] src_cpl;
  logic       rt_drop;
  cpl_t       cpl_rec;

  assign src_valid    = {ad_cpl_valid, lc_valid, !rej_empty};
  assign src_cpl      = {ad_cpl, lc_rec, rej_head};
  assign rej_pop      = src_ready[0];
  assign lc_accept    = src_ready[1];
  assign ad_cpl_ready = src_ready[2];

  sf_iq_cpl_router #(.NS(3), .NT(NT), .NCQ(NCQ)) u_router (
    .clk, .rst_n, .src_valid, .src_ready, .src_cpl, .cq_valid, .cq_owner,
    .cpl_valid, .cpl_ready, .cpl_data(cpl_rec), .drop(rt_drop)
  );
  assign cpl_data = cpl_rec;

  // ---------------------------------------------------------------------------
  // Sticky errors / status
  // ---------------------------------------------------------------------------
  //  [0] completion dropped (unroutable)   [1] DMA permission fault (tenant quarantined)
  //  [2] stray TensorCore DMA (no command) [3] watchdog timeout
  //  [4] TensorCore response tag mismatch  [5] TensorCore internal error
  logic [5:0]  err_sticky;
  logic [31:0] last_fault_addr;
  logic        in_drop;
  assign in_drop = in_reject && !in_route_ok;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      err_sticky      <= '0;
      last_fault_addr <= '0;
    end else begin
      if (csr_we && csr_addr == 16'h0014) err_sticky <= err_sticky & ~csr_wdata[5:0];
      if (rt_drop || in_drop)                      err_sticky[0] <= 1'b1;
      if (|fault_set)                              err_sticky[1] <= 1'b1;
      if (ev_stray_dma)                            err_sticky[2] <= 1'b1;
      if (ev_timeout)                              err_sticky[3] <= 1'b1;
      if (ev_bad_tag)                              err_sticky[4] <= 1'b1;
      if (ev_cpl && ev_cpl_status == ST_TC_ERROR)  err_sticky[5] <= 1'b1;
      if (gate_fault) last_fault_addr <= gate_fault_addr;
    end
  end
  assign irq_err = |err_sticky;

  // ---------------------------------------------------------------------------
  // Performance counters
  // ---------------------------------------------------------------------------
  logic        perf_hit;
  logic [31:0] perf_rdata;
  logic        ev_abort;
  logic [TW-1:0] ev_abort_tenant;
  assign ev_abort        = sel_bad || drain_fire;
  assign ev_abort_tenant = sel_bad ? sel_entry.desc.tenant_id[TW-1:0]
                                   : q_head[drain_q].desc.tenant_id[TW-1:0];

  sf_iq_perf_counters #(.NT(NT), .CNT_W(CNT_W)) u_perf (
    .clk, .rst_n, .clear(cnt_clear),
    .tc_phase, .tc_mem_stall(tcm_req_valid && !mem_req_ready),
    .sched_en, .any_elig, .st_busy, .st_scrub, .st_issue, .st_run, .st_hold,
    .active_tenant,
    .ev_dispatch(sel_ok), .ev_dispatch_tenant(sel_entry.desc.tenant_id[TW-1:0]),
    .ev_dispatch_wait(now - sel_entry.t_submit),
    .ev_scrub_start,
    .ev_cpl, .ev_cpl_tenant, .ev_cpl_status, .ev_cpl_macs, .ev_cpl_deadline_miss(ev_cpl_dl_miss),
    .ev_reject(in_reject), .ev_reject_tv(in_qid_ok), .ev_reject_tenant(in_owner),
    .ev_abort, .ev_abort_tenant,
    .ev_drop(rt_drop || in_drop), .ev_timeout,
    .csr_addr, .rd_hit(perf_hit), .rd_data(perf_rdata)
  );

  // ---------------------------------------------------------------------------
  // CSR read mux (status, capabilities, queue/tenant status)
  // ---------------------------------------------------------------------------
  logic [NT-1:0] t_inflight, t_pending;
  always_comb begin
    for (int t = 0; t < NT; t++) begin
      t_inflight[t] = st_busy && (active_tenant == TW'(t));
      t_pending[t]  = 1'b0;
      for (int q = 0; q < NQ; q++)
        if (!q_empty[q] && q_head[q].desc.tenant_id == 8'(t)) t_pending[t] = 1'b1;
    end
  end

  always_comb begin
    csr_rdata = 32'd0;
    if (ctx_hit)       csr_rdata = ctx_rdata;
    else if (perf_hit) csr_rdata = perf_rdata;
    else begin
      case (csr_addr)
        16'h0004: begin // STATUS
          csr_rdata[0]     = st_busy;
          csr_rdata[1]     = sched_en;
          csr_rdata[3:2]   = spad_state;
          csr_rdata[4 +: TW] = spad_owner;
          csr_rdata[8 +: TW] = active_tenant;
          csr_rdata[12]    = any_elig;
          csr_rdata[13]    = rej_full;
          csr_rdata[14]    = lc_valid;
        end
        16'h0014: csr_rdata = {26'd0, err_sticky};
        16'h0018: csr_rdata = {8'(NREG), 8'(NCQ), 8'(NT), 8'(NQ)};          // CAPS0
        16'h001C: begin                                                     // CAPS1
          csr_rdata[0]     = 1'b1;               // OP_GEMM
          csr_rdata[4]     = 1'b1;               // FMT_INT8 (UINT8/BF16/FP16 NOT supported)
          csr_rdata[8]     = 1'b1;               // ACC_INT32
          csr_rdata[16:12] = 5'b11111;           // RR, WRR, DRR, PRIO, DEADLINE
          csr_rdata[20]    = 1'b0;               // mid-GEMM preemption: NOT supported
          csr_rdata[24]    = ALLOW_SCRUB_BYPASS;
        end
        16'h0020: csr_rdata = {16'(MAX_N), 16'(MAX_M)};                     // CAPS2
        16'h0024: csr_rdata = {8'(TC_COLS), 8'(TC_ROWS), 16'(MAX_K)};       // CAPS3
        16'h0028: csr_rdata = {24'd0, 8'(QDEPTH)};                          // CAPS4
        16'h002C: csr_rdata = last_fault_addr;
        16'h0030: csr_rdata = now;
        default: begin
          for (int q = 0; q < NQ; q++)
            if (csr_addr == 16'h0100 + 16'(q*16) + 16'h000C)
              csr_rdata = {16'd0, 7'd0, elig[q], 8'(q_count[q])};
          for (int t = 0; t < NT; t++) begin
            if (csr_addr == 16'h0400 + 16'(t*64) + 16'h0014)
              csr_rdata = {29'd0, !t_inflight[t], t_pending[t], t_inflight[t]};
            if (csr_addr == 16'h0400 + 16'(t*64) + 16'h003C)
              csr_rdata = rl_tokens[t];
          end
        end
      endcase
    end
  end

`ifndef SYNTHESIS
  // --- isolation assertions -------------------------------------------------
  always_ff @(posedge clk) begin
    if (rst_n) begin
      // a queued entry always belongs to the tenant that owned the queue at intake
      if (in_accept)
        assert (in_desc.tenant_id == 8'(in_owner)) else $error("intake accepted foreign tenant");
      // the TensorCore is only given commands that passed revalidation
      if (sel_ok)
        assert (dp_status == ST_OK && sel_entry.desc.tenant_id == 8'(q_owner[sel_q]))
          else $error("dispatch of non-validated command");
      // delivered completions are routed only to CQs owned by their tenant
      if (cpl_valid && cpl_ready)
        assert (cpl_rec.cq_id < 8'(NCQ) && cq_valid[cpl_rec.cq_id[CW-1:0]] &&
                8'(cq_owner[cpl_rec.cq_id[CW-1:0]]) == cpl_rec.tenant)
          else $error("completion misrouted");
      // only one source may claim the local-completion slot per cycle
      assert (!(sel_bad && drain_fire)) else $error("lc slot double claim");
    end
  end
`endif
endmodule
