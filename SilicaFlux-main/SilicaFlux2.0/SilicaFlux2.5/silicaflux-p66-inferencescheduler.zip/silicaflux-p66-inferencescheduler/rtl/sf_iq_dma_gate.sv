// =============================================================================
// SilicaFlux Project 66 — sf_iq_dma_gate.sv
// Run-time DMA permission gate (defence in depth behind descriptor validation).
//
// Every word-sized request issued by the TensorCore's memory master is checked
// against the LIVE region table of the tenant that the SCHEDULER believes owns
// the TensorCore (active_tenant). The domain field a TensorCore might put on
// its own requests is deliberately not trusted.
//
// A request that fails (wrong tenant region, missing R/W permission, or any
// request while no command is active) is forwarded with `poison` set:
//   * poisoned writes are dropped by the memory subsystem,
//   * poisoned reads return zero data with rsp_err (AXI DECERR-like),
// so response ordering is preserved without a reorder buffer. A single-cycle
// `fault` pulse with the offending address is raised on acceptance.
//
// If the attached interconnect cannot honour `poison`, the gate must instead
// block the request and synthesise the error response (see INTEGRATION_STATUS).
// =============================================================================
module sf_iq_dma_gate
  import sf_iq_pkg::*;
#(
  parameter int unsigned NT   = 4,
  parameter int unsigned NREG = 2,
  localparam int unsigned TW = (NT > 1) ? $clog2(NT) : 1
) (
  input  logic                          clk,
  input  logic                          rst_n,
  // scheduler context
  input  logic                          active_valid,
  input  logic [TW-1:0]                 active_tenant,
  input  logic [NT-1:0][NREG-1:0][31:0] r_base,
  input  logic [NT-1:0][NREG-1:0][31:0] r_limit,
  input  logic [NT-1:0][NREG-1:0][1:0]  r_perm,
  // from TensorCore memory master
  input  logic                          m_req_valid,
  output logic                          m_req_ready,
  input  logic                          m_req_we,
  input  logic [31:0]                   m_req_addr,
  input  logic [31:0]                   m_req_wdata,
  output logic                          m_rsp_valid,
  output logic [31:0]                   m_rsp_rdata,
  output logic                          m_rsp_err,
  // to memory subsystem (CloudDMA / MemoryPool port)
  output logic                          s_req_valid,
  input  logic                          s_req_ready,
  output logic                          s_req_we,
  output logic [31:0]                   s_req_addr,
  output logic [31:0]                   s_req_wdata,
  output logic                          s_req_poison,
  input  logic                          s_rsp_valid,
  input  logic [31:0]                   s_rsp_rdata,
  input  logic                          s_rsp_err,
  // fault report
  output logic                          fault,        // pulse on accepted violating beat
  output logic [31:0]                   fault_addr,
  output logic                          fault_we
);
  logic allowed;

  always_comb begin
    allowed = 1'b0;
    if (active_valid) begin
      for (int r = 0; r < NREG; r++) begin
        if ((m_req_we ? r_perm[active_tenant][r][1] : r_perm[active_tenant][r][0]) &&
            range_in(m_req_addr, 32'd4, r_base[active_tenant][r], r_limit[active_tenant][r]))
          allowed = 1'b1;
      end
    end
  end

  assign s_req_valid  = m_req_valid;
  assign m_req_ready  = s_req_ready;
  assign s_req_we     = m_req_we;
  assign s_req_addr   = m_req_addr;
  assign s_req_wdata  = m_req_wdata;
  assign s_req_poison = !allowed;

  assign m_rsp_valid  = s_rsp_valid;
  assign m_rsp_rdata  = s_rsp_rdata;
  assign m_rsp_err    = s_rsp_err;

  assign fault      = m_req_valid && s_req_ready && !allowed;
  assign fault_addr = m_req_addr;
  assign fault_we   = m_req_we;

  // (clk/rst_n kept for future registered-check variants and assertions)
`ifndef SYNTHESIS
  always_ff @(posedge clk) begin
    if (rst_n && s_req_valid && s_req_ready && !s_req_poison) begin
      assert (active_valid) else $error("sf_iq_dma_gate: unpoisoned beat with no active command");
    end
  end
`endif
endmodule
