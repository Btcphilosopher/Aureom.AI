// =============================================================================
// SilicaFlux Project 66 — sf_iq_cpl_router.sv
// Merges completion sources (intake rejects, local aborts, TensorCore
// completions) onto the single completion port, round robin.
//
// Final isolation check: a record is only presented if its CQ is valid and
// owned by the record's tenant *at the moment of delivery*. If the host
// reassigned the CQ while the command was in flight, the record is dropped
// (never delivered to the new owner) and `drop` pulses so the host can be
// told through ERR_STICKY / the counters.
// =============================================================================
module sf_iq_cpl_router
  import sf_iq_pkg::*;
#(
  parameter int unsigned NS  = 3,
  parameter int unsigned NT  = 4,
  parameter int unsigned NCQ = 4,
  localparam int unsigned TW = (NT  > 1) ? $clog2(NT)  : 1,
  localparam int unsigned CW = (NCQ > 1) ? $clog2(NCQ) : 1,
  localparam int unsigned SW = (NS  > 1) ? $clog2(NS)  : 1
) (
  input  logic                  clk,
  input  logic                  rst_n,
  input  logic [NS-1:0]         src_valid,
  output logic [NS-1:0]         src_ready,
  input  cpl_t [NS-1:0]         src_cpl,
  input  logic [NCQ-1:0]        cq_valid,
  input  logic [NCQ-1:0][TW-1:0] cq_owner,
  output logic                  cpl_valid,
  input  logic                  cpl_ready,
  output cpl_t                  cpl_data,
  output logic                  drop
);
  logic [SW-1:0] last;
  logic          found;
  logic [SW-1:0] pick;
  logic          route_ok;
  logic [CW-1:0] cq;

  always_comb begin
    found = 1'b0;
    pick  = '0;
    for (int i = 1; i <= NS; i++) begin
      int unsigned j;
      j = (int'(last) + i) % NS;
      if (!found && src_valid[j]) begin
        found = 1'b1;
        pick  = SW'(j);
      end
    end
    cq       = src_cpl[pick].cq_id[CW-1:0];
    route_ok = (src_cpl[pick].cq_id < 8'(NCQ)) && cq_valid[cq] &&
               (8'(cq_owner[cq]) == src_cpl[pick].tenant);

    cpl_valid = found && route_ok;
    cpl_data  = src_cpl[pick];
    drop      = found && !route_ok;
    src_ready = '0;
    if (found && (!route_ok || cpl_ready)) src_ready[pick] = 1'b1;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) last <= SW'(NS - 1);
    else if (found && (!route_ok || cpl_ready)) last <= pick;
  end
endmodule
