// =============================================================================
// SilicaFlux Project 66 — sf_iq_desc_validator.sv
// Purely combinational descriptor validation.
//
// Instantiated twice in the top level:
//   (1) at intake, before a descriptor is allowed into a tenant queue;
//   (2) at dispatch, on the selected queue head (time-of-check / time-of-use:
//       the host may have revoked a region, CQ or queue since intake).
//
// The authoritative tenant is the OWNER OF THE QUEUE the descriptor arrived on
// (the queue is selected by the doorbell address, which tenant software cannot
// forge). The descriptor's tenant_id field is only cross-checked against it.
//
// Checks are applied in a fixed order; the first failure is reported.
// =============================================================================
module sf_iq_desc_validator
  import sf_iq_pkg::*;
#(
  parameter int unsigned NQ    = 4,
  parameter int unsigned NT    = 4,
  parameter int unsigned NCQ   = 4,
  parameter int unsigned NREG  = 2,
  parameter int unsigned MAX_M = 64,
  parameter int unsigned MAX_N = 64,
  parameter int unsigned MAX_K = 64,
  parameter int unsigned TC_ROWS = 4,
  parameter int unsigned TC_COLS = 4,
  localparam int unsigned TW = (NT  > 1) ? $clog2(NT)  : 1,
  localparam int unsigned CW = (NCQ > 1) ? $clog2(NCQ) : 1,
  localparam int unsigned QW = (NQ  > 1) ? $clog2(NQ)  : 1
) (
  input  desc_t                         desc,
  input  logic [7:0]                    qid,
  // context
  input  logic [NQ-1:0]                 q_en,
  input  logic [NQ-1:0][TW-1:0]         q_owner,
  input  logic [NQ-1:0][CW-1:0]         q_err_cq,
  input  logic [NCQ-1:0]                cq_valid,
  input  logic [NCQ-1:0][TW-1:0]        cq_owner,
  input  logic [NT-1:0]                 t_en,
  input  logic [NT-1:0]                 t_fault,
  input  logic [NT-1:0][1:0]            t_prio_cap,
  input  logic [NT-1:0][NREG-1:0][31:0] r_base,
  input  logic [NT-1:0][NREG-1:0][31:0] r_limit,
  input  logic [NT-1:0][NREG-1:0][1:0]  r_perm,
  // results
  output logic [7:0]                    status,
  output logic                          qid_ok,      // qid names an enabled queue
  output logic [TW-1:0]                 owner,       // queue owner (valid if qid_ok)
  output logic                          route_ok,    // a completion can be routed
  output logic [CW-1:0]                 route_cq,    // CQ for the completion
  output logic [1:0]                    prio_eff,    // clamped priority
  output logic [31:0]                   cost         // estimated TensorCore cycles
);
  logic [QW-1:0] q;
  logic [31:0]   len_a, len_b, len_c;
  logic          a_ok, b_ok, c_ok, cq_ok, dims_ok;
  logic [CW-1:0] cq_idx;

  always_comb begin
    q      = qid[QW-1:0];
    qid_ok = (qid < 8'(NQ)) && q_en[q];
    owner  = q_owner[q];

    len_a  = {16'd0, desc.m} * {16'd0, desc.k};
    len_b  = {16'd0, desc.k} * {16'd0, desc.n};
    len_c  = ({16'd0, desc.m} * {16'd0, desc.n}) << 2;

    dims_ok = (desc.m != 16'd0) && (desc.n != 16'd0) && (desc.k != 16'd0) &&
              (desc.m <= 16'(MAX_M)) && (desc.n <= 16'(MAX_N)) && (desc.k <= 16'(MAX_K));

    // operand A / B need read permission, C needs write permission, each
    // entirely inside ONE region of the owning tenant.
    a_ok = 1'b0; b_ok = 1'b0; c_ok = 1'b0;
    for (int r = 0; r < NREG; r++) begin
      if (r_perm[owner][r][0] && range_in(desc.a_addr, len_a, r_base[owner][r], r_limit[owner][r])) a_ok = 1'b1;
      if (r_perm[owner][r][0] && range_in(desc.b_addr, len_b, r_base[owner][r], r_limit[owner][r])) b_ok = 1'b1;
      if (r_perm[owner][r][1] && range_in(desc.c_addr, len_c, r_base[owner][r], r_limit[owner][r])) c_ok = 1'b1;
    end

    cq_idx = desc.cq_id[CW-1:0];
    cq_ok  = (desc.cq_id < 8'(NCQ)) && cq_valid[cq_idx] && (cq_owner[cq_idx] == owner);

    // completion routing: the descriptor's own CQ if it is owned by the queue
    // owner, otherwise the queue's error CQ if THAT is owned by the queue
    // owner. Never a CQ of another tenant.
    if (qid_ok && cq_ok) begin
      route_ok = 1'b1; route_cq = cq_idx;
    end else if (qid_ok && cq_valid[q_err_cq[q]] && cq_owner[q_err_cq[q]] == owner) begin
      route_ok = 1'b1; route_cq = q_err_cq[q];
    end else begin
      route_ok = 1'b0; route_cq = '0;
    end

    prio_eff = (desc.prio > t_prio_cap[owner]) ? t_prio_cap[owner] : desc.prio;
    cost     = est_cost(desc.m, desc.n, desc.k, TC_ROWS, TC_COLS);

    // ordered checks
    if      (!qid_ok)                                     status = ST_BAD_QUEUE;
    else if (desc.tenant_id != 8'(owner))                 status = ST_TENANT_MISMATCH;
    else if (!t_en[owner])                                status = ST_TENANT_DISABLED;
    else if (t_fault[owner])                              status = ST_TENANT_FAULTED;
    else if (desc.rsvd != '0 || desc.flags != '0)         status = ST_RSVD_NONZERO;
    else if (desc.opcode != OP_GEMM)                      status = ST_UNSUP_OP;
    else if (desc.numfmt != FMT_INT8)                     status = ST_UNSUP_FMT;
    else if (desc.acc_prec != ACC_INT32)                  status = ST_UNSUP_PREC;
    else if (!dims_ok)                                    status = ST_BAD_DIMS;
    else if ((desc.a_addr[1:0] | desc.b_addr[1:0] | desc.c_addr[1:0]) != 2'b00)
                                                          status = ST_BAD_ALIGN;
    else if (!cq_ok)                                      status = ST_BAD_CQ;
    else if (!a_ok)                                       status = ST_PERM_A;
    else if (!b_ok)                                       status = ST_PERM_B;
    else if (!c_ok)                                       status = ST_PERM_C;
    else                                                  status = ST_OK;
  end
endmodule
