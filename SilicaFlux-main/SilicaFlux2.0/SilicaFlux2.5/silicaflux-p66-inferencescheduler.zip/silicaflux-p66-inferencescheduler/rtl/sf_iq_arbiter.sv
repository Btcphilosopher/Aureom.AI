// =============================================================================
// SilicaFlux Project 66 — sf_iq_arbiter.sv
// Queue arbiter for the single-issue TensorCore.
//
// Policies (CTRL.policy):
//   RR       one command per visit, rotate                  (baseline)
//   WRR      q_weight commands per visit                    (command-count share)
//   DRR      deficit RR, quantum = DRR_QUANTUM * q_weight,  (TensorCore-time share)
//            cost = estimated TensorCore cycles of the head
//   PRIO     highest effective priority first; a head older than AGING_LIMIT
//            cycles is promoted above every class (starvation bound);
//            RR among equals
//   DEADLINE smallest slack (submit + hint - now) first; heads without a hint
//            are treated as infinitely late; RR among equals.  HINT ONLY — no
//            latency guarantee is made (see docs/ARCHITECTURE.md §Scheduling).
//
// Rate limiting (orthogonal to policy): per-tenant token bucket in units of
// TensorCore cycles. A tenant is eligible while tokens >= 0; a dispatch
// subtracts its estimated cost (tokens may go negative = debt), so commands
// larger than the burst size still make progress.
//
// Occupancy correction: the estimate ignores scratchpad scrubs caused by a
// tenant switch, memory latency and handshake overhead. When a command
// finishes, the adapter reports (measured occupancy - estimate) and that
// delta is charged to the DRR deficit of the queue and to the tenant's token
// bucket. Without it, tenants issuing many small GEMMs were measured to
// receive ~1.5x the TensorCore time of large-GEMM tenants under DRR, and a
// 25% rate limit admitted ~37% occupancy (docs/BENCHMARK_REPORT.md).
//
// Interface contract: sel_valid/sel_q are combinational. The top level asserts
// `take` in the same cycle when it pops queue sel_q (dispatch or abort).
// `take_charge` is 0 when the head is discarded without using the TensorCore.
// =============================================================================
module sf_iq_arbiter
  import sf_iq_pkg::*;
#(
  parameter int unsigned NQ = 4,
  parameter int unsigned NT = 4,
  localparam int unsigned TW = (NT > 1) ? $clog2(NT) : 1,
  localparam int unsigned QW = (NQ > 1) ? $clog2(NQ) : 1
) (
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic [31:0]             now,
  // global config
  input  logic [2:0]              policy,
  input  logic [31:0]             drr_quantum,
  input  logic [31:0]             aging_limit,
  // queue heads
  input  logic [NQ-1:0]           head_valid,
  input  logic [NQ-1:0][1:0]      head_prio,
  input  logic [NQ-1:0][31:0]     head_cost,
  input  logic [NQ-1:0][31:0]     head_submit,
  input  logic [NQ-1:0][23:0]     head_deadline,
  // queue / tenant context
  input  logic [NQ-1:0]           q_en,
  input  logic [NQ-1:0][TW-1:0]   q_owner,
  input  logic [NQ-1:0][7:0]      q_weight,
  input  logic [NT-1:0]           t_en,
  input  logic [NT-1:0]           t_susp,
  input  logic [NT-1:0]           t_fault,
  input  logic [NT-1:0]           t_rl_en,
  input  logic [NT-1:0][31:0]     t_rl_rate,
  input  logic [NT-1:0][31:0]     t_rl_period,
  input  logic [NT-1:0][31:0]     t_rl_burst,
  // handshake
  input  logic                    allow,        // TensorCore path can accept now
  input  logic                    take,         // sel_q popped this cycle
  input  logic                    take_charge,  // ... and dispatched to TensorCore
  // occupancy correction from the adapter (measured - estimated cycles)
  input  logic                    corr_valid,
  input  logic [QW-1:0]           corr_q,
  input  logic [TW-1:0]           corr_tenant,
  input  logic signed [31:0]      corr_delta,
  output logic                    sel_valid,
  output logic [QW-1:0]           sel_q,
  // status
  output logic [NQ-1:0]           elig,
  output logic                    any_elig,
  output logic [NT-1:0][31:0]     rl_tokens
);
  // ---------------------------------------------------------------------------
  // Rate limiter state
  // ---------------------------------------------------------------------------
  logic signed [31:0] tokens  [NT];
  logic        [31:0] per_cnt [NT];
  logic [NT-1:0]      rl_ok;

  always_comb begin
    for (int t = 0; t < NT; t++) begin
      rl_ok[t]     = !t_rl_en[t] || (tokens[t] >= 0);
      rl_tokens[t] = tokens[t];
    end
  end

  // ---------------------------------------------------------------------------
  // Eligibility
  // ---------------------------------------------------------------------------
  always_comb begin
    for (int q = 0; q < NQ; q++) begin
      elig[q] = head_valid[q] && q_en[q] &&
                t_en[q_owner[q]] && !t_susp[q_owner[q]] && !t_fault[q_owner[q]] &&
                rl_ok[q_owner[q]];
    end
    any_elig = |elig;
  end

  wire is_rr_family = (policy == POL_RR) || (policy == POL_WRR) || (policy == POL_DRR) ||
                      (policy > POL_DEADLINE);   // undefined encodings fall back to RR
  wire is_drr  = (policy == POL_DRR);
  wire is_prio = (policy == POL_PRIO);

  // ---------------------------------------------------------------------------
  // RR / WRR / DRR : pointer + per-queue credit (signed deficit)
  // ---------------------------------------------------------------------------
  localparam logic signed [31:0] CREDIT_MAX = 32'sh3FFF_FFFF;
  logic [QW-1:0]      cur;
  logic signed [31:0] credit   [NQ];
  logic signed [31:0] credit_n [NQ];
  logic signed [31:0] cost_eff [NQ];
  logic               cur_can, nxt_found;
  logic [QW-1:0]      nxt;
  logic signed [31:0] quantum_nxt;

  always_comb begin
    for (int q = 0; q < NQ; q++) cost_eff[q] = is_drr ? $signed(head_cost[q]) : 32'sd1;
    cur_can   = elig[cur] && (credit[cur] >= cost_eff[cur]);
    nxt_found = 1'b0;
    nxt       = cur;
    for (int i = 1; i <= NQ; i++) begin
      int unsigned j;
      j = (int'(cur) + i) % NQ;
      if (!nxt_found && elig[j]) begin
        nxt_found = 1'b1;
        nxt       = QW'(j);
      end
    end
    quantum_nxt = $signed(drr_quantum * {24'd0, q_weight[nxt]});
    if (quantum_nxt > CREDIT_MAX || quantum_nxt < 0) quantum_nxt = CREDIT_MAX;
  end

  // next-state of the credit array
  always_comb begin
    for (int q = 0; q < NQ; q++) credit_n[q] = credit[q];
    if (is_rr_family) begin
      if (take) begin
        credit_n[sel_q] = credit[sel_q] - cost_eff[sel_q];
      end else if (!cur_can && nxt_found) begin
        if (is_drr) begin
          credit_n[nxt] = (credit[nxt] > CREDIT_MAX - quantum_nxt) ? CREDIT_MAX : credit[nxt] + quantum_nxt;
        end else begin
          credit_n[nxt] = (policy == POL_WRR) ? $signed({24'd0, q_weight[nxt]}) : 32'sd1;
        end
      end
      if (is_drr) begin
        if (corr_valid) credit_n[corr_q] = credit_n[corr_q] - corr_delta;
        // an empty queue forfeits surplus (standard DRR) but keeps its debt
        for (int q = 0; q < NQ; q++)
          if (!head_valid[q] && credit_n[q] > 0) credit_n[q] = 32'sd0;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // PRIO / DEADLINE : combinational best-of-heads, RR tie-break from `last`
  // ---------------------------------------------------------------------------
  logic [QW-1:0] last;
  logic          best_found;
  logic [QW-1:0] best_q;
  logic [2:0]    best_pkey;
  logic signed [31:0] best_slack;

  always_comb begin
    best_found = 1'b0;
    best_q     = '0;
    best_pkey  = 3'd0;
    best_slack = 32'sh7FFF_FFFF;
    for (int i = 1; i <= NQ; i++) begin
      int unsigned j;
      logic [2:0]  pkey;
      logic signed [31:0] slack;
      logic aged;
      j     = (int'(last) + i) % NQ;
      aged  = (aging_limit != 32'd0) && ((now - head_submit[j]) >= aging_limit);
      pkey  = aged ? 3'd4 : {1'b0, head_prio[j]};
      slack = (head_deadline[j] == 24'd0) ? 32'sh7FFF_FFFF
                                          : $signed(head_submit[j] + {8'd0, head_deadline[j]} - now);
      if (elig[j]) begin
        if (!best_found ||
            ( is_prio && (pkey  >  best_pkey)) ||
            (!is_prio && (slack <  best_slack))) begin
          best_found = 1'b1;
          best_q     = QW'(j);
          best_pkey  = pkey;
          best_slack = slack;
        end
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Selection
  // ---------------------------------------------------------------------------
  always_comb begin
    if (is_rr_family) begin
      sel_valid = allow && cur_can;
      sel_q     = cur;
    end else begin
      sel_valid = allow && best_found;
      sel_q     = best_q;
    end
  end

  // ---------------------------------------------------------------------------
  // State update
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cur  <= '0;
      last <= QW'(NQ - 1);
      for (int q = 0; q < NQ; q++) credit[q] <= 32'sd0;
    end else begin
      if (take) last <= sel_q;
      if (is_rr_family && !take && !cur_can && nxt_found) cur <= nxt;
      for (int q = 0; q < NQ; q++) credit[q] <= credit_n[q];
    end
  end

  // rate limiter
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int t = 0; t < NT; t++) begin
        tokens[t]  <= 32'sd0;
        per_cnt[t] <= 32'd0;
      end
    end else begin
      for (int t = 0; t < NT; t++) begin
        if (!t_rl_en[t]) begin
          tokens[t]  <= 32'sd0;
          per_cnt[t] <= 32'd0;
        end else begin
          logic signed [31:0] tk;
          tk = tokens[t];
          if (per_cnt[t] + 32'd1 >= t_rl_period[t]) begin
            per_cnt[t] <= 32'd0;
            tk = tk + $signed(t_rl_rate[t]);
            if (tk > $signed(t_rl_burst[t])) tk = $signed(t_rl_burst[t]);
          end else begin
            per_cnt[t] <= per_cnt[t] + 32'd1;
          end
          if (take && take_charge && q_owner[sel_q] == TW'(t))
            tk = tk - $signed(head_cost[sel_q]);
          if (corr_valid && corr_tenant == TW'(t))
            tk = tk - corr_delta;
          tokens[t] <= tk;
        end
      end
    end
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk) begin
    if (rst_n && take) begin
      assert (sel_valid) else $error("sf_iq_arbiter: take without sel_valid");
    end
  end
`endif
endmodule
