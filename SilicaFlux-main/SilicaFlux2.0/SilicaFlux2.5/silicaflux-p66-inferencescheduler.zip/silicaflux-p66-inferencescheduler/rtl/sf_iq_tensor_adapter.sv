// =============================================================================
// SilicaFlux Project 66 — sf_iq_tensor_adapter.sv
// Tensor command adapter: turns one validated queue entry into one TensorCore
// GEMM command, and the TensorCore response into one completion record.
//
// Responsibilities
//   * Scratchpad ownership tracking. The TensorCore's operand/accumulator SRAM
//     is shared by all tenants. Before a command of tenant T is issued, the
//     scratchpad must be CLEAN or already OWNED by T; otherwise a scrub is
//     requested and must complete first. Reset and TensorCore recovery leave
//     the scratchpad UNKNOWN (SRAM is not cleared by reset), which also forces
//     a scrub.
//   * Command-boundary context switching only: one command is in flight; a
//     switch between tenants can only happen between commands. There is no
//     mid-GEMM preemption because the TensorCore offers no state save/restore.
//   * Active-domain register for the DMA gate (scheduler-owned, not taken from
//     the TensorCore).
//   * Watchdog: if the TensorCore does not finish a scrub or a command within
//     WD_LIMIT cycles it is soft-reset, the command completes with ST_TIMEOUT
//     and the scratchpad becomes UNKNOWN.
//   * Response tag check: a response whose tag does not match the in-flight
//     command is discarded and flagged.
//   * DMA gate violations during a command -> ST_DMA_FAULT and tenant quarantine.
// =============================================================================
module sf_iq_tensor_adapter
  import sf_iq_pkg::*;
#(
  parameter int unsigned NT = 4,
  parameter int unsigned NQ = 4,
  localparam int unsigned TW = (NT > 1) ? $clog2(NT) : 1
) (
  input  logic              clk,
  input  logic              rst_n,
  input  logic [31:0]       now,
  input  logic [31:0]       wd_limit,
  input  logic              scrub_bypass,     // only ever 1 in negative-test builds
  // dispatch from scheduler
  input  logic              disp_valid,
  output logic              disp_ready,
  input  qentry_t           disp_entry,
  input  logic [7:0]        disp_qid,
  input  logic [TW-1:0]     disp_tenant,
  // TensorCore command / response / maintenance
  output logic              tc_cmd_valid,
  input  logic              tc_cmd_ready,
  output tc_cmd_t           tc_cmd,
  input  logic              tc_rsp_valid,
  output logic              tc_rsp_ready,
  input  tc_rsp_t           tc_rsp,
  output logic              tc_scrub_req,
  input  logic              tc_scrub_done,
  output logic              tc_soft_reset,
  // DMA gate
  input  logic              gate_fault,
  output logic              active_valid,
  output logic [TW-1:0]     active_tenant,
  // completion
  output logic              cpl_valid,
  input  logic              cpl_ready,
  output cpl_t              cpl,
  // quarantine request to the context register file
  output logic [NT-1:0]     fault_set,
  // status / events for counters
  output logic              st_busy,          // not idle
  output logic              st_scrub,         // scrubbing
  output logic              st_issue,         // presenting command to TensorCore
  output logic              st_run,           // command executing
  output logic              st_hold,          // completion waiting for the CQ path
  output logic [1:0]        spad_state,
  output logic [TW-1:0]     spad_owner,
  output logic              ev_scrub_start,
  output logic              ev_cpl,           // completion record accepted
  output logic [TW-1:0]     ev_cpl_tenant,
  output logic [7:0]        ev_cpl_status,
  output logic [31:0]       ev_cpl_macs,
  output logic              ev_cpl_deadline_miss,
  output logic              ev_timeout,
  output logic              ev_bad_tag,
  output logic              ev_stray_dma,
  // occupancy correction for DRR / rate limiting (registered pulse)
  output logic              occ_valid,
  output logic [7:0]        occ_qid,
  output logic [TW-1:0]     occ_tenant,
  output logic signed [31:0] occ_delta        // measured occupancy - estimated cost
);
  typedef enum logic [2:0] {S_IDLE, S_SCRUB, S_ISSUE, S_RUN, S_HOLD} state_e;
  state_e state;

  qentry_t        a_entry;
  logic [7:0]     a_qid;
  logic [TW-1:0]  a_tenant;
  logic [31:0]    a_dispatch;
  logic [7:0]     a_tag;
  logic           a_fault_seen;
  logic [31:0]    wd_cnt;
  logic [1:0]     sp_state;
  logic [TW-1:0]  sp_owner;
  logic [7:0]     tag_ctr;

  wire wd_expired = (wd_limit != 32'd0) && (wd_cnt >= wd_limit);

  function automatic logic need_scrub(input logic [1:0] st, input logic [TW-1:0] own,
                                      input logic [TW-1:0] t);
    return (st == SP_UNKNOWN) || (st == SP_OWNED && own != t);
  endfunction

  // ---------------------------------------------------------------------------
  // Outputs
  // ---------------------------------------------------------------------------
  assign disp_ready    = (state == S_IDLE);
  assign tc_cmd_valid  = (state == S_ISSUE);
  assign tc_scrub_req  = (state == S_SCRUB);
  assign tc_rsp_ready  = 1'b1;              // responses always consumed (stray ones dropped)
  assign active_valid  = (state == S_RUN);
  assign active_tenant = a_tenant;
  assign cpl_valid     = (state == S_HOLD);
  assign spad_state    = sp_state;
  assign spad_owner    = sp_owner;

  assign st_busy  = (state != S_IDLE);
  assign st_scrub = (state == S_SCRUB);
  assign st_issue = (state == S_ISSUE);
  assign st_run   = (state == S_RUN);
  assign st_hold  = (state == S_HOLD);

  always_comb begin
    tc_cmd        = '0;
    tc_cmd.opcode = a_entry.desc.opcode;
    tc_cmd.m      = a_entry.desc.m;
    tc_cmd.n      = a_entry.desc.n;
    tc_cmd.k      = a_entry.desc.k;
    tc_cmd.a_addr = a_entry.desc.a_addr;
    tc_cmd.b_addr = a_entry.desc.b_addr;
    tc_cmd.c_addr = a_entry.desc.c_addr;
    tc_cmd.domain = 8'(a_tenant);
    tc_cmd.tag    = a_tag;
  end

  // completion record (held in a_* registers + cpl_status)
  logic [7:0] cpl_status;
  always_comb begin
    cpl            = '0;
    cpl.txn_id     = a_entry.desc.txn_id;
    cpl.tenant     = 8'(a_tenant);
    cpl.qid        = a_qid;
    cpl.cq_id      = a_entry.desc.cq_id;
    cpl.status     = cpl_status;
    cpl.t_submit   = a_entry.t_submit;
    cpl.t_dispatch = a_dispatch;
    cpl.t_complete = now;
  end

  wire        rsp_fire   = (state == S_RUN) && tc_rsp_valid;
  wire        rsp_tag_ok = (tc_rsp.tag == a_tag);
  logic [7:0] rsp_status;
  always_comb begin
    if (a_fault_seen || gate_fault)            rsp_status = ST_DMA_FAULT;
    else if (tc_rsp.status == TC_RSP_OK)       rsp_status = ST_OK;
    else                                       rsp_status = ST_TC_ERROR;
  end

  // events
  assign ev_cpl        = (state == S_HOLD) && cpl_ready;
  assign ev_cpl_tenant = a_tenant;
  assign ev_cpl_status = cpl_status;
  assign ev_cpl_macs   = {16'd0, a_entry.desc.m} * {16'd0, a_entry.desc.n} * {16'd0, a_entry.desc.k};
  assign ev_cpl_deadline_miss = (a_entry.desc.deadline != 24'd0) &&
                                ($signed(now - (a_entry.t_submit + {8'd0, a_entry.desc.deadline})) > 0);
  assign ev_scrub_start = (state == S_IDLE) && disp_valid &&
                          need_scrub(sp_state, sp_owner, disp_tenant) && !scrub_bypass;
  assign ev_bad_tag     = tc_rsp_valid && !((state == S_RUN) && rsp_tag_ok);
  assign ev_stray_dma   = gate_fault && (state != S_RUN);

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state         <= S_IDLE;
      a_entry       <= '0;
      a_qid         <= '0;
      a_tenant      <= '0;
      a_dispatch    <= '0;
      a_tag         <= '0;
      a_fault_seen  <= 1'b0;
      wd_cnt        <= '0;
      sp_state      <= SP_UNKNOWN;     // SRAM contents survive reset: must scrub
      sp_owner      <= '0;
      tag_ctr       <= '0;
      cpl_status    <= ST_OK;
      tc_soft_reset <= 1'b0;
      fault_set     <= '0;
      ev_timeout    <= 1'b0;
      occ_valid     <= 1'b0;
      occ_qid       <= '0;
      occ_tenant    <= '0;
      occ_delta     <= '0;
    end else begin
      tc_soft_reset <= 1'b0;
      fault_set     <= '0;
      ev_timeout    <= 1'b0;
      occ_valid     <= 1'b0;
      // TensorCore occupancy ends when the adapter leaves SCRUB/RUN for HOLD
      if ((state == S_RUN && ((rsp_fire && rsp_tag_ok) || wd_expired)) ||
          (state == S_SCRUB && !tc_scrub_done && wd_expired)) begin
        occ_valid  <= 1'b1;
        occ_qid    <= a_qid;
        occ_tenant <= a_tenant;
        occ_delta  <= $signed(now - a_dispatch + 32'd1) - $signed(a_entry.cost);
      end

      case (state)
        S_IDLE: begin
          wd_cnt       <= '0;
          a_fault_seen <= 1'b0;
          if (disp_valid) begin
            a_entry    <= disp_entry;
            a_qid      <= disp_qid;
            a_tenant   <= disp_tenant;
            a_dispatch <= now;
            a_tag      <= tag_ctr;
            tag_ctr    <= tag_ctr + 8'd1;
            if (need_scrub(sp_state, sp_owner, disp_tenant) && !scrub_bypass)
              state <= S_SCRUB;
            else
              state <= S_ISSUE;
          end
        end

        S_SCRUB: begin
          wd_cnt <= wd_cnt + 32'd1;
          if (tc_scrub_done) begin
            sp_state <= SP_CLEAN;
            wd_cnt   <= '0;
            state    <= S_ISSUE;
          end else if (wd_expired) begin
            tc_soft_reset <= 1'b1;
            ev_timeout    <= 1'b1;
            sp_state      <= SP_UNKNOWN;
            cpl_status    <= ST_TIMEOUT;
            state         <= S_HOLD;
          end
        end

        S_ISSUE: begin
          if (tc_cmd_ready) begin
            // From here on the scratchpad holds (or will hold) this tenant's data.
            sp_state <= SP_OWNED;
            sp_owner <= a_tenant;
            wd_cnt   <= '0;
            state    <= S_RUN;
          end
        end

        S_RUN: begin
          wd_cnt <= wd_cnt + 32'd1;
          if (gate_fault) a_fault_seen <= 1'b1;
          if (rsp_fire && rsp_tag_ok) begin
            cpl_status <= rsp_status;
            if (rsp_status == ST_DMA_FAULT) fault_set[a_tenant] <= 1'b1;
            state <= S_HOLD;
          end else if (wd_expired) begin
            tc_soft_reset <= 1'b1;
            ev_timeout    <= 1'b1;
            sp_state      <= SP_UNKNOWN;
            cpl_status    <= (a_fault_seen || gate_fault) ? ST_DMA_FAULT : ST_TIMEOUT;
            if (a_fault_seen || gate_fault) fault_set[a_tenant] <= 1'b1;
            state         <= S_HOLD;
          end
        end

        S_HOLD: begin
          if (cpl_ready) state <= S_IDLE;
        end

        default: state <= S_IDLE;
      endcase
    end
  end

`ifndef SYNTHESIS
  // Isolation invariant: a command is never presented to the TensorCore while
  // the scratchpad holds another tenant's data or unknown data.
  always_ff @(posedge clk) begin
    if (rst_n && state == S_ISSUE && tc_cmd_ready && !scrub_bypass) begin
      assert (sp_state == SP_CLEAN || (sp_state == SP_OWNED && sp_owner == a_tenant))
        else $error("sf_iq_tensor_adapter: issue with foreign/unknown scratchpad state=%0d owner=%0d tenant=%0d",
                    sp_state, sp_owner, a_tenant);
    end
  end
`endif
endmodule
