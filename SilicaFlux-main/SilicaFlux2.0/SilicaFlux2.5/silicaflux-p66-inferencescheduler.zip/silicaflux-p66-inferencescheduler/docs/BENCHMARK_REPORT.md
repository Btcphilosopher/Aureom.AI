# Scheduling benchmarks (brief §7, §8)

> **Every number below is measured** from cycle-accurate simulation of the RTL scheduler driving the **behavioural TensorCore model** (4×4 INT8 systolic timing, 64 B/cycle scrub, 4-cycle memory, up to 8 reads in flight). Absolute cycle counts characterise the scheduler against that model, **not silicon**. Every OK result in every run was also checked bit-exact against a golden GEMM, and the scratchpad residue monitor was active (column `chk`).

Reproduce: `python3 scripts/run_benchmarks.py && python3 scripts/make_report.py`. Raw traces: `results/bench/<scenario>/trace.csv` (one row per completion: submit / dispatch / complete cycles), counters: `counters.txt`, workloads: `workload.txt`, summary: `results/bench/summary.json`.

Metric definitions: *MAC util* = useful MACs / (cycles × 16); *TC busy* = fraction of cycles a command occupies the TensorCore; *ctx* = fraction of cycles spent scrubbing for tenant switches; *ovh/disp* = scheduler-induced idle + dispatch cycles per dispatched command; latency = complete − arrival (open loop: intended arrival; closed loop: submission); Jain = Jain's index over weight-normalised TensorCore shares of backlogged tenants (1.0 = perfectly fair).

## Key findings

1. **Scheduling overhead is negligible.** Arbitration plus issue costs **2.0 cycles per dispatched command** in every scenario. A single tenant keeps the TensorCore 97–100% busy.
2. **Tenant switches dominate small multi-tenant work.**
   - Each switch costs **386 cycles**, a whole-scratchpad scrub of 24 KiB at 64 B/cycle, and that scrub is required for isolation.
   - With 4 tenants of 8³ GEMMs under RR, **70.2% of all cycles are scrubbing** and a command costs 550 cycles.
   - WRR weight 8 batches 8 commands per visit: scrub drops to 22.9%, 213 cycles per command (**2.6×**), with identical fairness.
   - With two tenants of 16³: RR spends 33.7% scrubbing; WRR4 spends 11.3% and delivers +34% throughput (873 → 1168 cmds/Mcycle).
   - Recommendations: size WRR weights / DRR quanta so per-visit work is ≥ ~10× the scrub cost. Ask the TensorCore for a dirty-extent scrub; the scheduler interface would not change.
3. **Each policy equalises what it is designed to** (§3, windowed while all tenants are backlogged).
   - RR equalises commands, 80/80/80/79, but TensorCore time splits 6% / 12% / 34% / 48% (Jain 0.69).
   - WRR delivers commands exactly 1:2:3:4.
   - DRR with measured-occupancy correction delivers TensorCore time 0.253 / 0.254 / 0.248 / 0.245 (**Jain 1.000**), also on random shapes.
4. **Non-preemptive latency bound** (§4). An 8³ stream behind 64³ GEMMs (24.3 k cycles each):
   - Under RR its median latency is ~191 k cycles, and 105 of 190 arrivals are rejected because its queue fills.
   - PRIO or DEADLINE cut the median to 11.9 k, and **p99 / max are 25.2 k / 25.3 k ≈ one 64³ service time plus a scrub**. That is the floor for any policy without preemption.
   - The 3000-cycle deadline hints are therefore largely missed. No latency guarantee below the longest admitted command can be offered; that would need tiling or a cap on other tenants' command size.
5. **Aging sets the high-priority tail under saturation** (§5). PRIO improves the high-priority median from 72.7 k to 6.4 k cycles and rejections from 117 to 21. The p99 stays at ~51.7 k, though, because background commands that age past `AGING_LIMIT` (40 k) are promoted above class 3. The starvation bound for background work and the tail of the high class are the same knob.
6. **Admission control bounds latency** (§7). At ~1.6× offered load, an admission limit of 3 instead of 8 cuts the worst tenant p99 from 37.8 k to 14.9 k cycles. Throughput is essentially unchanged (596 vs 608 completions) and rejections rise only from 392 to 404.
7. **Rate limiting is exact on measured occupancy** (§8). The tenant limited to 20% held 0.200 of all cycles. The unlimited tenant finished its 200 commands early, so its whole-run share is low.
8. **Memory contention** (§6) costs throughput directly, because operand load / result store do not overlap compute in the model. MAC utilisation falls from 0.463 to 0.227 as the memory port becomes 75% busy.
9. **Single-tenant MAC utilisation** rises from 0.19 (8³) to 0.67 (64³). It is bounded by non-overlapped load/store and systolic fill/drain, which are properties of the TensorCore model rather than the scheduler.


## 1. One tenant — scheduler overhead and TensorCore utilisation

| GEMM | cmds | cycles/cmd | MAC util | TC busy | compute | DMA wait | ovh/disp | chk |
|---|---|---|---|---|---|---|---|---|
| 8³ | 200 | 165.985 | 0.193 | 0.970 | 0.361 | 0.602 | 2.005 | PASS |
| 16³ | 200 | 761.985 | 0.336 | 0.993 | 0.483 | 0.509 | 2.005 | PASS |
| 32³ | 200 | 4041.985 | 0.507 | 0.999 | 0.618 | 0.381 | 2.005 | PASS |
| 64³ | 60 | 24334.617 | 0.673 | 1.000 | 0.747 | 0.253 | 2.017 | PASS |

## 2. Two tenants — the cost of switching

| scenario | cycles | cmds/Mcycle | MAC util | switches | ctx | cycles/switch | Jain | chk |
|---|---|---|---|---|---|---|---|---|
| two_tenants_rr | 458411 | 872.579 | 0.223 | 400 | 0.337 | 386.000 | 1.000 | PASS |
| two_tenants_wrr4 | 342611 | 1167.505 | 0.299 | 100 | 0.113 | 386.000 | 1.000 | PASS |

## 3. Four tenants, mixed sizes — RR vs WRR vs DRR

Tenant sizes: t0 8³, t1 16³, t2 32×32×16, t3 32³; WRR weights 1:2:3:4; DRR quantum 512 × weight 1.

Shares are measured from the traces inside the window where all four tenants were backlogged (whole-run shares would reflect each tenant's total demand instead).

| policy | t0 TC share | t1 TC share | t2 TC share | t3 TC share | cmds in window | Jain TC time/weight | Jain cmds/weight | MAC util | ctx | chk |
|---|---|---|---|---|---|---|---|---|---|---|
| RR | 0.060 | 0.124 | 0.342 | 0.475 | 80/80/80/79 | 0.693 | 1.000 | 0.317 | 0.221 | PASS |
| WRR | 0.020 | 0.069 | 0.313 | 0.598 | 20/40/60/80 | 0.682 | 1.000 | 0.361 | 0.112 | PASS |
| DRR | 0.253 | 0.254 | 0.248 | 0.245 | 400/104/37/26 | 1.000 | 0.465 | 0.336 | 0.174 | PASS |

![shares](figures/fairness_shares.png)

**Random shapes (incl. 5×7×3, 24×40×8, 64×16×64), DRR:** windowed Jain (TC time) 1.000, MAC util 0.442, ctx 0.102, PASS.

## 4. Short vs long GEMMs — tail latency of a short stream behind 64³ work

t0: 8³ open loop, mean inter-arrival 6000 cycles, prio 3, deadline hint 3000. t1: 64³ closed loop (2 outstanding).

| policy | t0 p50 | t0 p95 | t0 p99 | t0 max | t0 hint misses | t1 service p50 | MAC util | chk |
|---|---|---|---|---|---|---|---|---|
| RR | 191370 | 201767 | 202272 | 202272 | 45/45 | 24713 | 0.650 | PASS |
| PRIO | 11850 | 24308 | 25165 | 25276 | 134/150 | 24713 | 0.643 | PASS |
| DEADLINE | 11850 | 24308 | 25165 | 25276 | 134/150 | 24713 | 0.643 | PASS |
| DRR | 22608 | 46680 | 49175 | 49176 | 136/144 | 24713 | 0.651 | PASS |

![cdf](figures/short_vs_long_cdf.png)

## 5. High-priority traffic over saturating background

| policy | hi p50 | hi p99 | hi max | worst background p99 | MAC util | chk |
|---|---|---|---|---|---|---|
| RR | 72661 | 85423 | 85423 | 47990 | 0.365 | PASS |
| PRIO | 6382 | 51708 | 52281 | 52737 | 0.366 | PASS |

## 6. Memory contention

| memory busy | cycles | MAC util | compute | DMA wait | DMA stall | service p50 | chk |
|---|---|---|---|---|---|---|---|
| 0% | 885211 | 0.463 | 0.564 | 0.348 | 0.000 | 4425 | PASS |
| 25% | 987315 | 0.415 | 0.506 | 0.415 | 0.103 | 4933 | PASS |
| 50% | 1193900 | 0.343 | 0.418 | 0.517 | 0.259 | 5964 | PASS |
| 75% | 1807795 | 0.227 | 0.276 | 0.681 | 0.510 | 9056 | PASS |

![contention](figures/contention.png)

## 7. Queue saturation and admission control

| admission limit | completed | rejected | worst tenant p99 | max latency | TC busy | chk |
|---|---|---|---|---|---|---|
| 8 | 608 | 392 | 37792 | 37816 | 0.662 | PASS |
| 3 | 596 | 404 | 14878 | 14893 | 0.657 | PASS |

## 8. Rate limiting

| tenant | limit | TensorCore time share of all cycles | completed |
|---|---|---|---|
| t0 | 20% | 0.200 | 200 |
| t1 | none | 0.200 | 200 |

## 9. Context-switch overhead vs batching (4 tenants of 8³)

| scenario | switches | ctx fraction | cycles/switch | cmds/Mcycle | MAC util | chk |
|---|---|---|---|---|---|---|
| ctxswitch_rr | 640 | 0.702 | 386.000 | 1818.125 | 0.058 | PASS |
| ctxswitch_wrr8 | 81 | 0.229 | 386.000 | 4697.696 | 0.150 | PASS |

## 10. Cycle breakdown

![breakdown](figures/cycle_breakdown.png)

*Remaining cycles not shown are TensorCore RESP/handshake, dispatch and completion-path cycles.*

## All scenarios

| scenario | workload | cycles | ok | rejected | MAC util | chk |
|---|---|---|---|---|---|---|
| one_tenant_8 | 1 tenant, closed loop, 8x8x8 GEMM | 33197 | 200 | 0 | 0.193 | PASS |
| one_tenant_16 | 1 tenant, closed loop, 16x16x16 GEMM | 152397 | 200 | 0 | 0.336 | PASS |
| one_tenant_32 | 1 tenant, closed loop, 32x32x32 GEMM | 808397 | 200 | 0 | 0.507 | PASS |
| one_tenant_64 | 1 tenant, closed loop, 64x64x64 GEMM | 1460077 | 60 | 0 | 0.673 | PASS |
| two_tenants_rr | 2 tenants, 16^3 each, RR | 458411 | 400 | 0 | 0.223 | PASS |
| two_tenants_wrr4 | 2 tenants, 16^3 each, WRR weight 4 (batches of 4) | 342611 | 400 | 0 | 0.299 | PASS |
| four_tenants_mixed_rr | 4 tenants, sizes 8^3/16^3/32x32x16/32^3, RR | 978157 | 760 | 0 | 0.317 | PASS |
| four_tenants_mixed_wrr | 4 tenants, sizes 8^3/16^3/32x32x16/32^3, WRR | 857339 | 760 | 0 | 0.361 | PASS |
| four_tenants_mixed_drr | 4 tenants, sizes 8^3/16^3/32x32x16/32^3, DRR | 923080 | 760 | 0 | 0.336 | PASS |
| mixed_random_drr | 4 tenants, random shapes incl. non-multiples of 4, DRR | 1032577 | 480 | 0 | 0.442 | PASS |
| short_vs_long_rr | tenant0: 8^3 open-loop (mean IA 6000 cy, prio 3, hint 3000); tenant1: 64^3 closed loop; RR | 1010619 | 85 | 105 | 0.650 | PASS |
| short_vs_long_prio | tenant0: 8^3 open-loop (mean IA 6000 cy, prio 3, hint 3000); tenant1: 64^3 closed loop; PRIO | 1026680 | 190 | 0 | 0.643 | PASS |
| short_vs_long_deadline | tenant0: 8^3 open-loop (mean IA 6000 cy, prio 3, hint 3000); tenant1: 64^3 closed loop; DEADLINE | 1026680 | 190 | 0 | 0.643 | PASS |
| short_vs_long_drr | tenant0: 8^3 open-loop (mean IA 6000 cy, prio 3, hint 3000); tenant1: 64^3 closed loop; DRR | 1013360 | 184 | 6 | 0.651 | PASS |
| high_prio_rr | tenant0 16^3 open-loop prio 3 vs 3 saturating background tenants, RR | 1362909 | 533 | 117 | 0.365 | PASS |
| high_prio_prio | tenant0 16^3 open-loop prio 3 vs 3 saturating background tenants, PRIO | 1427376 | 629 | 21 | 0.366 | PASS |
| mem_contention_0 | 2 tenants 32^3, memory busy 0% of cycles | 885211 | 200 | 0 | 0.463 | PASS |
| mem_contention_25 | 2 tenants 32^3, memory busy 25% of cycles | 987315 | 200 | 0 | 0.415 | PASS |
| mem_contention_50 | 2 tenants 32^3, memory busy 50% of cycles | 1193900 | 200 | 0 | 0.343 | PASS |
| mem_contention_75 | 2 tenants 32^3, memory busy 75% of cycles | 1807795 | 200 | 0 | 0.227 | PASS |
| saturation_admit8 | 4 tenants open loop 16^3, offered ~1.6x capacity, admission limit 8 | 695731 | 608 | 392 | 0.224 | PASS |
| saturation_admit3 | 4 tenants open loop 16^3, offered ~1.6x capacity, admission limit 3 | 686962 | 596 | 404 | 0.222 | PASS |
| rate_limit_20pct | tenant0 limited to 20% occupancy, tenant1 unlimited | 827376 | 400 | 0 | 0.124 | PASS |
| ctxswitch_rr | 4 tenants of 8^3 GEMMs, RR (scrub on every tenant change) | 352011 | 640 | 0 | 0.058 | PASS |
| ctxswitch_wrr8 | 4 tenants of 8^3 GEMMs, WRR weight 8 (scrub on every tenant change) | 136237 | 640 | 0 | 0.150 | PASS |
