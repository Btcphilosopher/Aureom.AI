# INFERENCESCHEDULER — architecture

SilicaFlux Project 66 · Aureom.AI | SilicaFlux-CLOUD · primary RTL `rtl/silicaflux_inference_queue.sv`

## 1. Pipeline

```
 tenant doorbell ──► sub_qid ─┐
 (privileged mapping)         │
 host descriptor ─────────────┴─► Descriptor validation ──reject──► reject FIFO ─┐
                                   (sf_iq_desc_validator, intake)                │
                                           │ accept                              │
                                           ▼                                     │
                                  Tenant queues  (NQ × QDEPTH FIFOs)             │
                                           │                                     │
                           Scheduling policy (sf_iq_arbiter)                     │
                           RR · WRR · DRR · PRIO+aging · DEADLINE                │
                           + per-tenant token bucket, admission control          │
                                           │ selected head                       │
                           Dispatch-time revalidation ──fail──► local abort ─────┤
                           (second sf_iq_desc_validator)                         │
                                           │                                     │
                           Tensor command adapter (sf_iq_tensor_adapter)         │
                           scrub-on-owner-change · issue · watchdog · tag check  │
                              │ tc_cmd / tc_rsp            ▲ active tenant       │
                              ▼                            │                     │
                         TensorCore ──memory master──► DMA gate ──► CloudDMA /    │
                                                     (sf_iq_dma_gate)  MemoryPool│
                                           │ completion                          │
                                           ▼                                     ▼
                           Completion router (sf_iq_cpl_router) ◄────────────────┘
                           CQ-ownership check at delivery
                                           │
                                           ▼
                                   completion port (cpl_t)
```

| Module | Role |
|---|---|
| `sf_iq_pkg.sv` | Descriptor / completion / TensorCore ABI, status codes, `range_in`, `est_cost` |
| `sf_iq_fifo.sv` | Show-ahead FIFO (tenant queues, reject queue) |
| `sf_iq_tenant_ctx.sv` | **Tenant context register file**: ownership, regions, priorities, rate limits, global control. Deny-by-default reset. |
| `sf_iq_desc_validator.sv` | Ordered descriptor checks. Instantiated at intake *and* at dispatch. |
| `sf_iq_arbiter.sv` | **Queue arbiter**: five policies, token buckets, occupancy correction |
| `sf_iq_tensor_adapter.sv` | **Tensor command adapter**: scratchpad ownership, scrub sequencing, TensorCore handshake, watchdog, completion build |
| `sf_iq_dma_gate.sv` | Run-time per-beat permission check on the TensorCore memory master |
| `sf_iq_cpl_router.sv` | Round-robin completion merge with CQ ownership enforcement |
| `sf_iq_perf_counters.sv` | **Performance counters** (20 global, 10 per tenant) |
| `silicaflux_inference_queue.sv` | Top: intake, queues, dispatch glue, abort drain, sticky errors, CSR mux |

The design is single-issue. Exactly one command occupies the TensorCore at a time, because the TensorCore (and its model) is single-issue and offers no state save/restore.

## 2. Protection model

A protection domain (tenant) consists of the following, all programmed only through the privileged CSR port:

- the queues it owns;
- the completion queues (CQs) it owns;
- up to `NREG` memory regions, each with an inclusive `[base, limit]` range and R/W permission.

Isolation is enforced in layers. Each layer assumes the one before it may have been bypassed.

| # | Layer | Where | What it stops |
|---|---|---|---|
| 1 | **Queue ownership** | intake | The authoritative tenant is the owner of the queue the descriptor arrived on (`sub_qid` comes from the doorbell mapping). A descriptor claiming another `tenant_id` is rejected `TENANT_MISMATCH`. |
| 2 | **Descriptor validation** | intake | Unsupported op/format/precision, bad dims, misalignment, reserved bits, foreign CQ, and any A/B range not fully inside one *readable* own region or C range not fully inside one *writable* own region. Ranges use 34-bit arithmetic, so a range that wraps past 2³² is rejected. |
| 3 | **Dispatch-time revalidation** | dispatch | Time-of-check/time-of-use. If the host revoked a region, CQ or queue after intake, the command completes with the corresponding error and never reaches the TensorCore. |
| 4 | **DMA gate** | every memory beat | Checks each TensorCore beat against the **live** region table of the tenant the *scheduler* says is active. Any beat issued while no command is active is also blocked. Violations are poisoned (writes dropped, reads return 0 + error), the command completes `DMA_FAULT`, and the tenant is **quarantined**. |
| 5 | **Scratchpad scrub** | adapter | The shared operand/accumulator SRAM is scrubbed before a command whose tenant differs from the last owner. It is also scrubbed after reset or TensorCore recovery, when the state is UNKNOWN because SRAM survives reset. |
| 6 | **Completion routing** | delivery | A completion is delivered only to a CQ that is valid and owned by the completion's tenant *at delivery time*. Otherwise it is dropped and flagged (`ERR_STICKY[0]`, `CPL_DROPPED`); it is never delivered to another tenant. |

Rejected descriptors still produce a completion, so the host never waits forever. The completion goes to the descriptor's CQ if the queue owner owns it, otherwise to the queue's configured error CQ if the owner owns that. It is never sent to a CQ of another tenant. If neither applies (unknown or disabled queue), the descriptor is dropped and counted.

### Scratchpad ownership state machine

```
reset / watchdog recovery ──► UNKNOWN ──scrub──► CLEAN ──issue(T)──► OWNED(T)
                                                   ▲                    │
                                                   └──scrub── issue(T'≠T)
```

An RTL assertion checks that no command is ever issued unless the state is CLEAN or OWNED(by the same tenant). In addition, the testbench's residue monitor checks the model's *actual* SRAM contents on every tenant change.

### Out of scope / host responsibilities

- **DRAM contents.** When a region moves to another tenant, its DRAM must be cleared by the host or MemoryPool.
- **Region overlap.** The scheduler does not prevent the host from granting two tenants overlapping regions; that is a policy decision (a read-only shared-weights window is a legitimate use and is tested).
- **Poison handling.** The interconnect behind the gate must honour `poison`.

## 3. Scheduling

The arbiter chooses among queue heads that are *eligible*. A head is eligible when the queue is non-empty and enabled, and the tenant is enabled, not suspended, not faulted, and has non-negative rate-limit tokens.

| Policy | Rule | Share it equalises |
|---|---|---|
| `RR` (baseline) | one command per visit, rotate | commands |
| `WRR` | `q_weight` commands per visit | commands × weight |
| `DRR` | deficit round robin, quantum = `DRR_QUANTUM × q_weight`, cost = TensorCore cycles | TensorCore time × weight |
| `PRIO` | highest effective class first; a head older than `AGING_LIMIT` cycles is promoted above all classes; RR among equals | — (latency for high classes) |
| `DEADLINE` | smallest slack `submit + hint − now` first; no hint = infinitely late; RR among equals | — (deadline hints) |

**Priority** requested in a descriptor is clamped to the tenant's `prio_cap` (default 0), so a tenant cannot promote itself.

**Rate limiting.** Each tenant has a token bucket in TensorCore cycles (`rate` tokens every `period` cycles, capped at `burst`). A tenant is eligible while tokens ≥ 0. Dispatch subtracts the estimated cost, and debt is allowed, so commands larger than the burst still progress. The limiter is intentionally *not* work-conserving.

**Admission control.** Each queue has an admission limit ≤ `QDEPTH`. Submissions beyond it, or into a full queue, are *rejected* with `ADMISSION` / `QUEUE_FULL`; they are not back-pressured. The shared submission port therefore never head-of-line blocks one tenant behind another tenant's full queue. `sub_ready` only drops when the 4-entry reject FIFO is full, which happens only when the completion port itself is stalled.

### Occupancy correction (a finding from verification)

The cost of a command is first estimated as:

```
ceil(M/4)·ceil(N/4)·(K+7) + ceil(M·K/4) + ceil(K·N/4) + M·N
```

This covers systolic compute and word transfers. The estimate omits three things:

- the ~385-cycle scratchpad scrub that a tenant *switch* costs;
- memory latency;
- handshake overhead.

Tenants issuing many small GEMMs switch in on almost every visit, so they were systematically under-charged. Measured under DRR on 8³/16³/32×32×16/32³ tenants, the 8³ tenant received 30.3% of TensorCore time and the 32³ tenant 20.5%. A 25% rate limit admitted 37.5% occupancy.

The adapter now reports, for every finished command, the difference between measured occupancy (dispatch → response, including any scrub it caused) and the estimate. The arbiter charges that difference to the queue's DRR deficit and to the tenant's token bucket. Positive DRR surplus is still forfeited when a queue empties, but debt is kept. After the fix the measured shares are 0.249 / 0.252 / 0.251 / 0.248, and the 25% limit measures 0.250 (`fairness`, `rate_limit` tests; mutant M21).

### Latency statements

The scheduler is non-preemptive at command granularity. The queueing delay of a newly arriving command is therefore bounded below by the residual service time of whatever is executing. A 64×64×64 GEMM occupies the model TensorCore for roughly 25 k cycles. **No policy can guarantee a deadline shorter than the longest admitted command's service time plus one scrub.**

Deadline hints are hints. Measured miss rates are reported in `BENCHMARK_REPORT.md`; no guarantee is claimed. A bounded-latency class would need, at minimum, an admission rule that caps the size of other tenants' commands.

## 4. Context switching (brief §6)

Switching happens **only at command boundaries**.

- **Tenant change between commands.** The adapter inserts a scrub, attributed to the incoming tenant and counted as context-switch overhead. Same-tenant back-to-back commands do not scrub.
- **Suspend** (`T_CTRL.suspend`). The tenant becomes ineligible at the next boundary. Its in-flight command completes normally; no mid-GEMM preemption is claimed (`CAPS1[20] = 0`). Its pending commands, their transaction IDs, queue order and the scheduler state (RR pointer, DRR deficits, tokens) are preserved. `T_STATUS` reports in-flight / pending / quiesced. Resume continues in the original order.
- **Disable tenant / disable queue / quarantine.** Pending commands are flushed as `ABORTED` completions, so every submitted transaction is accounted for.

## 5. Faults

| Event | Detection | Completion | Side effects |
|---|---|---|---|
| Descriptor invalid | intake validator | specific status | `REJECTED` counter |
| Context revoked after intake | dispatch revalidation | specific status | never reaches TensorCore |
| Rogue / out-of-bounds TensorCore DMA | DMA gate | `DMA_FAULT` | tenant quarantined, its queue flushed `ABORTED`, `ERR_STICKY[1]`, `FAULT_ADDR` |
| Stray DMA with no active command | DMA gate | — | blocked, `ERR_STICKY[2]` |
| TensorCore hang | watchdog `WD_LIMIT` | `TIMEOUT` | TensorCore soft reset, scratchpad → UNKNOWN (forced scrub), `ERR_STICKY[3]`; tenant *not* quarantined |
| TensorCore internal error | response status | `TC_ERROR` | `ERR_STICKY[5]` |
| Response with wrong tag | tag check | dropped | `ERR_STICKY[4]` |
| CQ reassigned in flight | completion router | dropped | `ERR_STICKY[0]`, `CPL_DROPPED` |

`irq_err` is the OR of `ERR_STICKY`, which is write-1-to-clear. A quarantined tenant is re-enabled by writing 1 to `T_CTRL[2]`.

## 6. Reset

Asynchronous active-low reset returns the block to a deny-by-default state:

- scheduler disabled, every queue, CQ and tenant disabled;
- every region without permission, priority caps at 0;
- all FIFOs empty, all counters zero;
- scratchpad state **UNKNOWN**, so the first dispatch after reset always scrubs.

Submissions before reconfiguration are dropped and counted.

## 7. Parameters

| Parameter | Default | Notes |
|---|---|---|
| `NQ` / `NT` / `NCQ` | 4 / 4 / 4 | register map supports NQ ≤ 16, NT ≤ 8 (counters), NCQ ≤ 64 |
| `QDEPTH` | 8 | power of two |
| `NREG` | 2 | regions per tenant (1..3) |
| `MAX_M/N/K` | 64 | must match TensorCore capability; larger dims are rejected, not tiled |
| `TC_ROWS/COLS` | 4 / 4 | used only by the cost estimate |
| `REJ_DEPTH` | 4 | reject FIFO |
| `CNT_W` | 48 | counter width |
| `ALLOW_SCRUB_BYPASS` | 0 | **negative-test builds only**; with 0 the bypass bit is tied off and CAPS1[24]=0 |

## 8. Known limitations

1. **Single outstanding command, no overlap.** The next command's operand load does not overlap the current compute, and dispatch waits for the previous completion record to be accepted. This is the main throughput cost for small GEMMs (see benchmark report).
2. **Whole-scratchpad scrub.** About 24 KiB at 64 B/cycle, roughly 385 cycles per tenant change. A TensorCore that tracked its dirty extent could scrub less; that is a TensorCore feature request, and the scheduler interface (`tc_scrub_req/done`) does not change.
3. **No tiling.** Dimensions above `MAX_*` are rejected. Tiling large GEMMs into boundary-preemptible sub-commands would also shorten the non-preemptive latency bound.
4. **32-bit time base.** Aging and deadline comparisons are wrap-safe only within a 2³¹-cycle window.
5. **Cost estimate.** Accurate only relative to the 4×4 model. The occupancy correction compensates at run time, but DRR quanta should be re-tuned against the real TensorCore.
