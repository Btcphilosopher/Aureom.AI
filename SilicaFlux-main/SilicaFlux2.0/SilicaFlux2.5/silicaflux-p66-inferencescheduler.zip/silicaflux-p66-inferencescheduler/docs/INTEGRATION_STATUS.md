# FPGA / hardware integration status (brief §9)

## Status: **BLOCKED**

There is no verified TensorCore RTL, CloudDMA, MemoryPool or ControlCore in the workspace (`REPO_AUDIT.md`). As the brief requires, the scheduler was verified against a **clearly labelled latency-aware simulation model** (`sim_models/sim_tensorcore_model.sv`), and hardware integration is kept blocked. No FPGA bitstream, timing closure or on-board measurement is claimed.

## Synthesis resource estimate (scheduler RTL only)

Flow: `sv2v` → Yosys 0.33 `synth_xilinx -flatten` (generic Xilinx 7-series mapping) for the default parameters (NQ=NT=NCQ=4, QDEPTH=8, NREG=2, CNT_W=48). Full report: `results/synth_report.txt`.

| Resource | Count |
|---|---|
| LUT (LUT1–LUT6) | 21,843 |
| Flip-flops (FDCE + FDPE) | 4,961 |
| Distributed RAM (RAM32M, queue storage) | 240 |
| DSP48E1 | 17 |
| CARRY4 | 3,291 |
| MUXF7 / MUXF8 | 1,949 / 395 |

Caveats:

- This is a pre-place-and-route **estimate**, not vendor results.
- IBUF/OBUF cells are artefacts of synthesising the block standalone.
- Yosys counts some inverters as separate cells that vendor tools absorb into LUTs.
- No timing constraints were applied, so **no Fmax is claimed**. The widest combinational paths are the two validators: owner-indexed region compares plus the cost multiply. The CSR read mux and the deadline slack comparison are next. Registering the dispatch-time revalidation is the first pipelining step if timing fails.
- Counters (60 × 48 bit) are a significant share of the flip-flops; `CNT_W` is a parameter.

## What the real TensorCore must provide (interface contract)

1. A GEMM command port with valid/ready, a tag that is echoed in the response, and a status (OK / DMA error / internal error). See `COMMAND_ABI_AND_REGISTERS.md` §4.
2. **A scratchpad scrub request/done handshake** that zeroes every operand and accumulator SRAM. Without it, multi-tenant isolation cannot be provided and integration must remain blocked.
3. A soft reset that abandons the current command and does not hang outstanding memory transactions.
4. A phase indication (optional; counters only).
5. All memory traffic through the scheduler's DMA gate, so it cannot bypass the per-beat check.

## What the interconnect / CloudDMA must provide

- Honour `poison`: drop poisoned writes, and return an error with no data for poisoned reads, in order, like an AXI decode-error slave. If it cannot, the gate must be changed to block the beat and synthesise the error response itself.
- Region (DRAM) scrubbing when MemoryPool reassigns memory between tenants.

## Unblock checklist

1. Supply the verified TensorCore 02 RTL and its command ABI. Reconcile `tc_cmd_t` / `tc_rsp_t` in `sf_iq_pkg.sv`.
2. Replace `sim_tensorcore_model` with the RTL in `tb/tb_top.sv`. Re-run `scripts/run_tests.py` and `scripts/mutation_test.py`, then re-tune `DRR_QUANTUM` with `scripts/run_benchmarks.py`.
3. Connect CloudDMA through the gate and verify poison semantics with the `dma_gate_*` tests.
4. Add timing constraints, run vendor synthesis and place-and-route, and pipeline the validators if needed.
5. Only then: an on-board bring-up using the register sequence in `COMMAND_ABI_AND_REGISTERS.md` §6.
