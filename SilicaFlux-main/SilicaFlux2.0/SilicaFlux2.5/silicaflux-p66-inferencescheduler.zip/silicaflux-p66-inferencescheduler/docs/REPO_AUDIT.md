# Repository audit (brief §1)

**Date:** 2026-11-13. **Scope:** the workspace supplied for Project 66.

## Result

The workspace contained no SilicaFlux source of any kind. Every component the brief asks to inspect is absent. The table below records each finding and how the build responds to it.

| Component | Found | Consequence for this build |
|---|---|---|
| SilicaFlux TensorCore RTL | **No** | `sim_models/sim_tensorcore_model.sv`, a behavioural latency-aware INT8 GEMM model, stands in for it. Its geometry (4×4 INT8 MAC array, INT32 accumulation) follows the TensorCore 02 baseline. It is **not** that RTL. Hardware integration is **blocked** (see `INTEGRATION_STATUS.md`). |
| GEMM command ABI | **No** | A descriptor ABI is proposed in `rtl/sf_iq_pkg.sv` and documented in `COMMAND_ABI.md`. It is the single point of reconciliation if an official ABI exists elsewhere. |
| SRAM buffers (operand / accumulator scratchpad) | **No** | These are modelled inside the TensorCore model: A 4 KiB, B 4 KiB, accumulators 16 KiB. The scheduler only assumes the scratchpad exists, is shared, survives reset, and can be scrubbed on request. |
| CloudDMA | **No** | `sim_models/sim_memory_model.sv` stands in for it. The scheduler's DMA gate defines the required contract: poisoned beats must be dropped or answered with an error, like an AXI decode-error slave. |
| MemoryPool | **No** | Region allocation is treated as a host responsibility. The scheduler enforces the regions it is given. Scrubbing *DRAM* when a region moves between tenants is a host / MemoryPool responsibility and is out of scope here. |
| ControlCore | **No** | The privileged CSR port of `silicaflux_inference_queue` is the interface a ControlCore or hypervisor would drive. Tenant software never reaches it. |
| Performance counters | **No** | A new counter block was added: `rtl/sf_iq_perf_counters.sv`, with 20 global and 10 per-tenant counters. |
| Host runtime | **No** | `host/sf_iq_abi.py` provides descriptor packing, completion decoding and the register map. Its layout is verified against the SystemVerilog structs by `host/test_abi.py`. |

## Capability statement derived from the audit

The audit found no evidence of any arithmetic engine other than the INT8 GEMM baseline. The scheduler therefore advertises, and accepts, only the following:

- opcode `GEMM`
- operand format `INT8`
- accumulator / output precision `INT32`

Encodings for UINT8, BF16, FP16 and FP32 are reserved so they can be **rejected explicitly** with `ST_UNSUP_FMT` / `ST_UNSUP_PREC`. Arbitrary neural-network graphs are not supported.

The CAPS registers report this. They also report that mid-GEMM preemption is *not* supported, because no TensorCore state save/restore exists.
