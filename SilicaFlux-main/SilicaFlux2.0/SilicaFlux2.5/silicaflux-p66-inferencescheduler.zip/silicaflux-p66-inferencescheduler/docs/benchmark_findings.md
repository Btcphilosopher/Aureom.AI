## Key findings

1. **Scheduling overhead is negligible.** Arbitration plus issue costs **2.0 cycles per dispatched command** in every scenario. A single tenant keeps the TensorCore 97–100% busy.
2. **Tenant switches dominate small multi-tenant work.**
   - Each switch costs **386 cycles**, a whole-scratchpad scrub of 24 KiB at 64 B/cycle, and that scrub is required for isolation.
   - With 4 tenants of 8³ GEMMs under RR, **70.2% of all cycles are scrubbing** and a command costs 550 cycles.
   - WRR weight 8 batches 8 commands per visit: scrub drops to 22.9%, 213 cycles per command (**2.6×**), with identical fairness.
   - With two tenants of 16³: RR spends 33.7% scrubbing; WRR4 spends 11.3% and delivers +34% throughput (873 → 1168 cmds/Mcycle).
   - Recommendations: size WRR weights / DRR quanta so per-visit work is ≥ ~10× the scrub cost. Ask the TensorCore for a dirty-extent scrub; the scheduler interface would not change.
3. **Each policy equalises what it is designed to** (§3, windowed while all tenants are backlogged).
   - RR equalises commands, 80/80/80/79, but TensorCore time splits 6% / 12% / 34% / 48% (Jain 0.69).
   - WRR delivers commands exactly 1:2:3:4.
   - DRR with measured-occupancy correction delivers TensorCore time 0.253 / 0.254 / 0.248 / 0.245 (**Jain 1.000**), also on random shapes.
4. **Non-preemptive latency bound** (§4). An 8³ stream behind 64³ GEMMs (24.3 k cycles each):
   - Under RR its median latency is ~191 k cycles, and 105 of 190 arrivals are rejected because its queue fills.
   - PRIO or DEADLINE cut the median to 11.9 k, and **p99 / max are 25.2 k / 25.3 k ≈ one 64³ service time plus a scrub**. That is the floor for any policy without preemption.
   - The 3000-cycle deadline hints are therefore largely missed. No latency guarantee below the longest admitted command can be offered; that would need tiling or a cap on other tenants' command size.
5. **Aging sets the high-priority tail under saturation** (§5). PRIO improves the high-priority median from 72.7 k to 6.4 k cycles and rejections from 117 to 21. The p99 stays at ~51.7 k, though, because background commands that age past `AGING_LIMIT` (40 k) are promoted above class 3. The starvation bound for background work and the tail of the high class are the same knob.
6. **Admission control bounds latency** (§7). At ~1.6× offered load, an admission limit of 3 instead of 8 cuts the worst tenant p99 from 37.8 k to 14.9 k cycles. Throughput is essentially unchanged (596 vs 608 completions) and rejections rise only from 392 to 404.
7. **Rate limiting is exact on measured occupancy** (§8). The tenant limited to 20% held 0.200 of all cycles. The unlimited tenant finished its 200 commands early, so its whole-run share is low.
8. **Memory contention** (§6) costs throughput directly, because operand load / result store do not overlap compute in the model. MAC utilisation falls from 0.463 to 0.227 as the memory port becomes 75% busy.
9. **Single-tenant MAC utilisation** rises from 0.19 (8³) to 0.67 (64³). It is bounded by non-overlapped load/store and systolic fill/drain, which are properties of the TensorCore model rather than the scheduler.
