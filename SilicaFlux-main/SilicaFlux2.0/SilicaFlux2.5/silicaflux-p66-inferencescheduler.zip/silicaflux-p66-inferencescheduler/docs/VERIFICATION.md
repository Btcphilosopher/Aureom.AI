# Verification (brief §10)

Simulator: Verilator 5.020 (`--timing --assert`), cycle-accurate RTL plus behavioural TensorCore and memory models. Run with `python3 scripts/run_tests.py`; results are in `results/test_results.txt` and the logs in `results/logs/`.

**Result: 19 / 19 directed tests pass**, including the negative control.

## Always-on checkers (every test and every benchmark run)

| Checker | Property |
|---|---|
| Scoreboard | Every completion's `txn_id` was submitted and completes **exactly once**. Tenant, expected status and expected CQ match. The CQ is owned by the completion's tenant (testbench shadow of the CSRs). |
| Golden GEMM | Every `OK` result is compared element-by-element with an INT8×INT8→INT32 reference computed from memory. |
| Residue monitor | Whenever the TensorCore accepts a command for a different tenant than the previous one, the model's entire scratchpad (operands and accumulators) must be zero. |
| Gate monitor | Every poisoned beat must coincide with a gate fault report. |
| RTL assertions | Scratchpad CLEAN/OWNED-by-same-tenant at issue · only revalidated commands dispatched · completions delivered only to owned CQs · no FIFO overflow/underflow · local-abort slot never double-claimed · no unpoisoned beat without an active command. |
| Sync guard | The testbench fails if stimulus is ever driven off the falling edge (see bug B3). |

## Directed tests

| Test | Brief item | What it proves |
|---|---|---|
| `single_gemm` | GEMM function | 8 shapes (1³ … 64³, 5×7×3, 17×9×33, 3×64×1, 64×1×64) bit-exact; CAPS advertise only GEMM/INT8/INT32 and no mid-GEMM preemption; one scrub after reset |
| `queue_order` | queue ordering | FIFO completion and dispatch order within a queue |
| `rr_order` | queue ordering | strict RR rotation across 4 tenant queues |
| `invalid_cmds` | invalid commands, memory permissions | 22 malformed descriptors each get the exact status and are routed only to an owned CQ: op, BF16/FP16/UINT8, FP32 accumulate, zero/oversize dims, alignment, reserved bits, flags, foreign/out-of-range CQ, spoofed tenant, cross-tenant A/B/C, straddling region end, write into a read-only region, 32-bit wrap, disabled tenant. Two submissions with no owner are dropped and flagged. **Nothing reaches the TensorCore or memory.** |
| `dma_gate_isolation` | tenant isolation, fault handling | A rogue TensorCore read into another tenant is poisoned (no bytes reach the scratchpad); the tenant is quarantined, its queue flushed `ABORTED`, new work rejected `TENANT_FAULTED`. The other tenant is unaffected; the victim's data is unchanged; W1C recovery works. |
| `dma_gate_write` | memory permissions | Legitimate shared **read-only** window across tenants; a descriptor writing into it is rejected; a rogue TensorCore write into it is poisoned, the data is unchanged and the tenant quarantined |
| `spad_scrub` | context isolation | With a TensorCore that never clears its accumulators, alternating tenants still get correct results because of the scrub; same-tenant back-to-back commands do not scrub; the scrub-bypass bit is tied off in production builds |
| `spad_scrub_negative` | checker validity | **Negative control** (`ALLOW_SCRUB_BYPASS=1` build): with scrubbing bypassed, 12/12 results leak and the residue monitor fires 12 times, proving the isolation checkers can detect a leak |
| `fairness` | fairness | RR equal counts (±2); WRR 1:2:3:4 → 40/80/120/160; DRR TensorCore shares within 1.35× max/min (measured 0.249–0.252) and fairer than RR |
| `priority` | scheduling | strict classes, prio-cap clamping, aging bounds a starved command's wait (measured 3428 cycles at limit 3000) |
| `deadline` | scheduling | earliest-hint order; no-hint last |
| `rate_limit` | rate limiting | 25% limit holds measured occupancy at 0.250 and the backlogged limited tenant receives its budget |
| `admission` | resource exhaustion | `ADMISSION` / `QUEUE_FULL` rejections; no head-of-line blocking of other tenants |
| `backpressure` | backpressure | completion port held → no completion lost, TensorCore stalls after one command, reject path fills and `sub_ready` drops, then recovery under random 60% ready |
| `reset` | reset | mid-GEMM reset → deny-by-default CSRs, empty queues, counters 0, scratchpad UNKNOWN; pre-config submissions dropped; first post-reset dispatch scrubs |
| `cpl_assoc_random` | completion association, mixed workloads | 400 random commands, 3 tenants, one tenant with 2 queues and 2 CQs, random priorities/hints, policy changes every 50, 30% memory contention, 85% random completion-ready |
| `resource_exhaustion` | resource exhaustion | all queues full, completion port throttled, counter consistency `DISPATCHED = OK + ERR` |
| `faults` | fault handling | watchdog on a hung TensorCore (TIMEOUT, soft reset, forced scrub, no quarantine); internal error; region revoked after intake (dispatch revalidation, never reaches TensorCore); CQ reassigned in flight (completion dropped, never misdelivered); queue disable flushes `ABORTED` |
| `suspend_resume` | context management | suspend during a GEMM: in-flight completes, no further dispatch, status quiesced/pending, other tenant continues; resume preserves order and txn ids |

Host ABI: `python3 host/test_abi.py` parses `desc_t` / `cpl_t` from `rtl/sf_iq_pkg.sv` and checks that the Python layouts match.

## Mutation testing

`scripts/mutation_test.py` injects one deliberate bug at a time into the RTL (24 defined) and runs the regression. Results are in `results/mutation_results.md`. **Every mutant executed so far was killed.** Mutants marked *not run* in that file were not executed before packaging; run `python3 scripts/mutation_test.py <IDs>` to complete them.

Designing the mutant list exposed one gap before the campaign ran: no test made the TensorCore issue a rogue **write**, so a gate that checked R instead of W for writes (M12) would have survived. `dma_gate_write` was added, and M12 is killed by it.

## Bugs found by testing

| # | Kind | Finding | Fix |
|---|---|---|---|
| B1 | **Design** | DRR and the rate limiter charged only the *estimated* GEMM cost. They ignored the 386-cycle scrub a tenant switch causes, plus fixed overheads. Small-GEMM tenants got 30.3% of TensorCore time against 20.5% for 32³ tenants under DRR, and a 25% limit admitted 37.5%. | Measured-occupancy correction charged back to the DRR deficit and token bucket (0.249–0.252 and 0.250 after the fix). |
| B2 | Testbench | Random test livelocked by holding the completion port low while backing off. | Release while waiting. |
| B3 | Testbench | `csr_rd` used `#1` settle delays. Several in a row crossed the next posedge, so descriptors were driven after the sampling edge and silently lost. This caused the `reset` and `faults` failures. | Re-align to negedge; sync guard added. |
| B4 | Tooling | A `while (func() != 0 && …)` loop with a timing control in its body never executed its body under Verilator 5.020 `--timing`. Root cause not isolated to a minimal reproducer. | Loops rewritten as `forever`/`break`. |
| B5 | Analysis | Whole-run TensorCore shares measure demand, not fairness, once tenants finish at different times. DRR appeared *less* fair than RR. | Fairness computed only while all tenants are backlogged. |

## Not covered

- No formal proofs.
- No gate-level or post-synthesis simulation.
- No real TensorCore, CloudDMA or MemoryPool; protocol assumptions are listed in `INTEGRATION_STATUS.md`.
- One seed per random test.
- No coverage database (Verilator line/toggle coverage was not collected).
