# Command ABI and register map

Source of truth: `rtl/sf_iq_pkg.sv` (layouts) and `rtl/sf_iq_tenant_ctx.sv` / `rtl/silicaflux_inference_queue.sv` (registers). `host/sf_iq_abi.py` mirrors both, and `host/test_abi.py` fails if the Python layouts diverge from the SystemVerilog structs.

## 1. Command descriptor (256 bits, bit 0 = `opcode[0]`, little-endian bytes)

| Bits | Field | Notes |
|---|---|---|
| [7:0] | `opcode` | `0x01` GEMM. Anything else → `UNSUP_OP` |
| [11:8] | `numfmt` | `0x1` INT8 (supported). `0x2` UINT8, `0x3` BF16, `0x4` FP16 are reserved → `UNSUP_FMT` |
| [15:12] | `acc_prec` | `0x2` INT32 (supported). `0x3` FP32 reserved → `UNSUP_PREC` |
| [31:16] | `m` | 1..MAX_M (64) |
| [47:32] | `n` | 1..MAX_N (64) |
| [63:48] | `k` | 1..MAX_K (64) |
| [95:64] | `a_addr` | A, INT8, row-major M×K packed, 4-byte aligned, needs **R** |
| [127:96] | `b_addr` | B, INT8, row-major K×N packed, 4-byte aligned, needs **R** |
| [159:128] | `c_addr` | C, INT32 little-endian, row-major M×N, 4-byte aligned, needs **W** |
| [167:160] | `tenant_id` | must equal the owner of the submission queue |
| [169:168] | `prio` | 0..3, clamped to the tenant's `prio_cap` |
| [185:170] | `txn_id` | echoed in the completion |
| [193:186] | `cq_id` | completion queue; must be owned by the tenant |
| [201:194] | `flags` | must be 0 (no flags defined) |
| [225:202] | `deadline` | relative deadline **hint** in cycles, 0 = none |
| [255:226] | `rsvd` | must be 0 |

Semantics: `C[i][j] = Σk sext(A[i][k]) · sext(B[k][j])`, exact 32-bit two's-complement (no saturation; |C| ≤ 64·128·128 so no overflow at MAX_K = 64).

## 2. Completion record (144 bits)

| Bits | Field |
|---|---|
| [15:0] | `txn_id` |
| [23:16] | `tenant` (owner of the submission queue) |
| [31:24] | `qid` |
| [39:32] | `cq_id` |
| [47:40] | `status` |
| [79:48] | `t_submit` (intake cycle) |
| [111:80] | `t_dispatch` (0 if never dispatched) |
| [143:112] | `t_complete` |

## 3. Status codes

| Code | Name | Meaning |
|---|---|---|
| 0x00 | OK | GEMM completed, C written |
| 0x01 | BAD_QUEUE | queue unknown or disabled (no completion possible → dropped + counted) |
| 0x02 | TENANT_MISMATCH | descriptor `tenant_id` ≠ queue owner |
| 0x03 | TENANT_DISABLED | owning tenant disabled |
| 0x04 | TENANT_FAULTED | owning tenant quarantined |
| 0x05 | RSVD_NONZERO | reserved bits or flags set |
| 0x06 | UNSUP_OP | opcode not GEMM |
| 0x07 | UNSUP_FMT | operand format not INT8 |
| 0x08 | UNSUP_PREC | output precision not INT32 |
| 0x09 | BAD_DIMS | a dimension is 0 or above MAX |
| 0x0A | BAD_ALIGN | an address is not 4-byte aligned |
| 0x0B | BAD_CQ | CQ invalid or owned by another tenant |
| 0x0C/0D/0E | PERM_A/B/C | range not inside one own region with the needed permission (or wraps 2³²) |
| 0x10 | QUEUE_FULL | queue at QDEPTH |
| 0x11 | ADMISSION | queue at its admission limit |
| 0x20 | ABORTED | discarded unexecuted (tenant/queue disabled or tenant quarantined) |
| 0x21 | DMA_FAULT | TensorCore DMA violated the tenant's regions → tenant quarantined |
| 0x22 | TC_ERROR | TensorCore reported an internal/memory error |
| 0x23 | TIMEOUT | watchdog expired, TensorCore soft-reset |

## 4. TensorCore interface (proposed; to be reconciled with the real TensorCore)

| Signal | Dir (scheduler) | Meaning |
|---|---|---|
| `tc_cmd_valid/ready`, `tc_cmd` | out/in | `{opcode, m, n, k, a, b, c, domain, tag}`; `domain` is informational |
| `tc_rsp_valid/ready`, `tc_rsp` | in/out | `{tag, status}`; status 0 OK, 1 DMA error, 2 internal error |
| `tc_scrub_req` / `tc_scrub_done` | out/in | request held until `done`; zero all operand and accumulator SRAM |
| `tc_soft_reset` | out | 1-cycle pulse; abandon current work (SRAM need not be cleared) |
| `tc_phase[2:0]` | in | IDLE, LOAD, COMPUTE, STORE, RESP, SCRUB, HANG — used only by counters |
| memory master | in → gate | word requests `{we, addr, wdata}` + in-order read responses |
| memory slave | gate → out | same plus `poison`; poisoned writes must be dropped, poisoned reads return error |

## 5. Register map (privileged CSR port, 32-bit, byte addresses)

### Global

| Addr | Name | Access | Fields |
|---|---|---|---|
| 0x000 | CTRL | RW | [0] sched_en (rst 0) · [3:1] policy (0 RR, 1 WRR, 2 DRR, 3 PRIO, 4 DEADLINE) · [8] scrub_bypass (only if `ALLOW_SCRUB_BYPASS`, else reads 0) · [16] counter clear (self-clearing pulse) |
| 0x004 | STATUS | RO | [0] busy · [1] sched_en · [3:2] scratchpad state (0 CLEAN, 1 OWNED, 2 UNKNOWN) · [7:4] scratchpad owner · [11:8] active tenant · [12] eligible work pending · [13] reject FIFO full · [14] local-abort slot busy |
| 0x008 | WD_LIMIT | RW | watchdog cycles, 0 = disabled (rst 0x100000) |
| 0x00C | DRR_QUANTUM | RW | DRR quantum per weight unit, TensorCore cycles (rst 1024) |
| 0x010 | AGING_LIMIT | RW | PRIO aging threshold cycles, 0 = off (rst 0) |
| 0x014 | ERR_STICKY | W1C | [0] completion dropped · [1] DMA fault · [2] stray DMA · [3] timeout · [4] bad tag · [5] TensorCore error |
| 0x018 | CAPS0 | RO | {NREG, NCQ, NT, NQ} bytes |
| 0x01C | CAPS1 | RO | [0] GEMM · [4] INT8 · [8] INT32 · [16:12] policy mask · [20] mid-GEMM preemption = **0** · [24] scrub-bypass build |
| 0x020 | CAPS2 | RO | {MAX_N, MAX_M} |
| 0x024 | CAPS3 | RO | {TC_COLS, TC_ROWS, MAX_K} |
| 0x028 | CAPS4 | RO | QDEPTH |
| 0x02C | FAULT_ADDR | RO | address of the last gate violation |
| 0x030 | NOW | RO | cycle counter |

### Queue q (0x100 + 0x10·q)

| Off | Name | Fields |
|---|---|---|
| +0x0 | Q_CFG | [0] enable · [11:8] owner tenant · [19:16] error CQ |
| +0x4 | Q_WEIGHT | [7:0] WRR/DRR weight (0 treated as 1, rst 1) |
| +0x8 | Q_ADMIT | [7:0] admission limit (clamped to QDEPTH, rst QDEPTH) |
| +0xC | Q_STATUS (RO) | [7:0] occupancy · [8] eligible |

### Completion queue c (0x200 + 4·c)

[0] valid · [11:8] owner tenant

### Tenant t (0x400 + 0x40·t)

| Off | Name | Fields |
|---|---|---|
| +0x00 | T_CTRL | [0] enable · [1] suspend · [2] fault (RO; write 1 to clear) · [5:4] prio_cap |
| +0x04 | T_RL_CFG | [0] rate limiter enable |
| +0x08 | T_RL_RATE | tokens added per period (TensorCore cycles) |
| +0x0C | T_RL_PERIOD | cycles per refill (0 treated as 1) |
| +0x10 | T_RL_BURST | token cap |
| +0x14 | T_STATUS (RO) | [0] in flight · [1] work pending · [2] quiesced |
| +0x18 + 0xC·r | R_BASE (r) | region r base (inclusive) |
| +0x1C + 0xC·r | R_LIMIT (r) | region r limit (inclusive) |
| +0x20 + 0xC·r | R_PERM (r) | [0] read · [1] write |
| +0x3C | T_RL_TOKENS (RO) | signed token balance |

### Counters (RO, 48-bit, lo word at +0, hi word at +4)

Global counter i at `0x800 + 8·i`; per-tenant counter j of tenant t at `0xC00 + 0x80·t + 8·j`. Indices and definitions are in the header of `rtl/sf_iq_perf_counters.sv`:

- **Global (0..19):** CYCLES, TC_BUSY, TC_COMPUTE, DMA_WAIT, DMA_STALL, SCHED_OVERHEAD, DISPATCH, CTX_SWITCH_CYCLES, CTX_SWITCHES, CPL_BACKPRESSURE, IDLE, DISPATCHED, COMPLETED_OK, COMPLETED_ERR, REJECTED, ABORTED, USEFUL_MACS, CPL_DROPPED, QUEUE_WAIT_TOTAL, TIMEOUTS.
- **Per tenant (0..9):** COMPLETED_OK, MACS, BUSY_CYCLES, QUEUE_WAIT_TOTAL, QUEUE_WAIT_MAX, REJECTED, ERRORS, DEADLINE_MISS, DISPATCHED, SCRUB_CYCLES.

## 6. Bring-up sequence

1. Program regions (`R_BASE/LIMIT/PERM`), CQ ownership, queue ownership + error CQ, weights / admission limits, `T_CTRL` (enable, prio_cap), optional rate limits.
2. Program `WD_LIMIT`, `DRR_QUANTUM`, `AGING_LIMIT`.
3. Write `CTRL` with `sched_en=1` and the policy.

Change a tenant's regions only while it is suspended and quiesced. The hardware is nonetheless safe if you don't: it revalidates at dispatch and the gate checks the live table.
