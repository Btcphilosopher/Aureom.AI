"""Cross-checks host/sf_iq_abi.py against the SystemVerilog structs in rtl/sf_iq_pkg.sv."""
import os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
import sf_iq_abi as abi

PKG = os.path.join(os.path.dirname(__file__), "..", "rtl", "sf_iq_pkg.sv")


def sv_struct(name):
    src = open(PKG).read()
    body = re.search(r"typedef struct packed \{([^{}]*)\}\s*%s;" % name, src, re.S).group(1)
    out = []
    for line in body.splitlines():
        m = re.match(r"\s*(?:logic\s*\[(\d+):(\d+)\]|logic)\s+(\w+);", line)
        if m:
            w = int(m.group(1)) - int(m.group(2)) + 1 if m.group(1) else 1
            out.append((m.group(3), w))
    return list(reversed(out))          # SV lists MSB first; ABI lists LSB first


def test_desc_layout_matches_sv():
    assert sv_struct("desc_t") == abi.DESC_LAYOUT
    assert sum(w for _, w in abi.DESC_LAYOUT) == 256


def test_cpl_layout_matches_sv():
    assert sv_struct("cpl_t") == abi.CPL_LAYOUT
    assert sum(w for _, w in abi.CPL_LAYOUT) == 144


def test_roundtrip_and_positions():
    d = abi.Desc(m=17, n=9, k=33, a_addr=0x1000, b_addr=0x2004, c_addr=0x8000,
                 tenant_id=2, txn_id=0xBEEF, cq_id=3, prio=1, deadline=12345)
    w = abi.pack_desc(d)
    assert abi.unpack_desc(w) == d
    assert w & 0xFF == abi.OP_GEMM
    assert (w >> 16) & 0xFFFF == 17          # m at [31:16]
    assert (w >> 64) & 0xFFFFFFFF == 0x1000  # a_addr at [95:64]
    assert (w >> 170) & 0xFFFF == 0xBEEF     # txn_id at [185:170]


def test_cost_matches_reference_values():
    assert abi.est_cost(16, 16, 16) == 752
    assert abi.est_cost(8, 8, 8) == 156


if __name__ == "__main__":
    n = 0
    for k, f in list(globals().items()):
        if k.startswith("test_"):
            f(); n += 1
    print("host ABI: %d checks passed" % n)
