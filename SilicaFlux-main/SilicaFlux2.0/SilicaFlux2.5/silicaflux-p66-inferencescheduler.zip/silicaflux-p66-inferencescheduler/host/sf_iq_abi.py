"""SilicaFlux Project 66 — host-side ABI helpers for silicaflux_inference_queue.

Pure Python, no dependencies. Mirrors rtl/sf_iq_pkg.sv; host/test_abi.py
parses that file and fails if the layouts ever diverge.

    from sf_iq_abi import Desc, pack_desc, unpack_cpl, REG
    d = Desc(m=16, n=16, k=16, a_addr=0x1000, b_addr=0x2000, c_addr=0x8000,
             tenant_id=0, txn_id=7, cq_id=0)
    word = pack_desc(d)          # 256-bit int, bit 0 = opcode[0]
    raw  = word.to_bytes(32, "little")
"""
from dataclasses import dataclass, fields

OP_GEMM = 0x01
FMT_INT8, FMT_UINT8, FMT_BF16, FMT_FP16 = 0x1, 0x2, 0x3, 0x4      # only INT8 supported
ACC_INT32, ACC_FP32 = 0x2, 0x3                                   # only INT32 supported

STATUS = {
    0x00: "OK", 0x01: "BAD_QUEUE", 0x02: "TENANT_MISMATCH", 0x03: "TENANT_DISABLED",
    0x04: "TENANT_FAULTED", 0x05: "RSVD_NONZERO", 0x06: "UNSUP_OP", 0x07: "UNSUP_FMT",
    0x08: "UNSUP_PREC", 0x09: "BAD_DIMS", 0x0A: "BAD_ALIGN", 0x0B: "BAD_CQ",
    0x0C: "PERM_A", 0x0D: "PERM_B", 0x0E: "PERM_C", 0x10: "QUEUE_FULL", 0x11: "ADMISSION",
    0x20: "ABORTED", 0x21: "DMA_FAULT", 0x22: "TC_ERROR", 0x23: "TIMEOUT",
}
POLICY = {"RR": 0, "WRR": 1, "DRR": 2, "PRIO": 3, "DEADLINE": 4}

# (name, width) from bit 0 upward — must match desc_t / cpl_t in sf_iq_pkg.sv
DESC_LAYOUT = [("opcode", 8), ("numfmt", 4), ("acc_prec", 4), ("m", 16), ("n", 16), ("k", 16),
               ("a_addr", 32), ("b_addr", 32), ("c_addr", 32), ("tenant_id", 8), ("prio", 2),
               ("txn_id", 16), ("cq_id", 8), ("flags", 8), ("deadline", 24), ("rsvd", 30)]
CPL_LAYOUT = [("txn_id", 16), ("tenant", 8), ("qid", 8), ("cq_id", 8), ("status", 8),
              ("t_submit", 32), ("t_dispatch", 32), ("t_complete", 32)]


@dataclass
class Desc:
    m: int
    n: int
    k: int
    a_addr: int
    b_addr: int
    c_addr: int
    tenant_id: int
    txn_id: int
    cq_id: int
    prio: int = 0
    deadline: int = 0
    opcode: int = OP_GEMM
    numfmt: int = FMT_INT8
    acc_prec: int = ACC_INT32
    flags: int = 0
    rsvd: int = 0


def _pack(layout, values):
    word, pos = 0, 0
    for name, w in layout:
        v = values[name]
        if v < 0 or v >= (1 << w):
            raise ValueError("%s=%d does not fit in %d bits" % (name, v, w))
        word |= v << pos
        pos += w
    return word


def _unpack(layout, word):
    out, pos = {}, 0
    for name, w in layout:
        out[name] = (word >> pos) & ((1 << w) - 1)
        pos += w
    return out


def pack_desc(d: Desc) -> int:
    return _pack(DESC_LAYOUT, {f.name: getattr(d, f.name) for f in fields(d)})


def unpack_desc(word: int) -> Desc:
    return Desc(**_unpack(DESC_LAYOUT, word))


def unpack_cpl(word: int) -> dict:
    c = _unpack(CPL_LAYOUT, word)
    c["status_name"] = STATUS.get(c["status"], "UNKNOWN_0x%02X" % c["status"])
    return c


def est_cost(m, n, k, rows=4, cols=4):
    """Same estimate as sf_iq_pkg::est_cost (TensorCore cycles, before correction)."""
    return (-(-m // rows)) * (-(-n // cols)) * (k + rows + cols - 1) + (m * k + 3) // 4 + (k * n + 3) // 4 + m * n


# ---------------------------------------------------------------- register map
class REG:
    CTRL, STATUS, WD_LIMIT, DRR_QUANTUM, AGING_LIMIT, ERR_STICKY = 0x000, 0x004, 0x008, 0x00C, 0x010, 0x014
    CAPS0, CAPS1, CAPS2, CAPS3, CAPS4, FAULT_ADDR, NOW = 0x018, 0x01C, 0x020, 0x024, 0x028, 0x02C, 0x030

    @staticmethod
    def q(q, off):          # 0 CFG, 4 WEIGHT, 8 ADMIT, C STATUS
        return 0x100 + 0x10 * q + off

    @staticmethod
    def cq(c):
        return 0x200 + 4 * c

    @staticmethod
    def t(t, off):          # 0 CTRL, 4 RL_CFG, 8 RL_RATE, C RL_PERIOD, 10 RL_BURST, 14 STATUS, 3C RL_TOKENS
        return 0x400 + 0x40 * t + off

    @staticmethod
    def region(t, r, which):  # which: 0 BASE, 4 LIMIT, 8 PERM
        return 0x400 + 0x40 * t + 0x18 + 0xC * r + which

    @staticmethod
    def gcnt(i):
        return 0x800 + 8 * i

    @staticmethod
    def tcnt(t, j):
        return 0xC00 + 0x80 * t + 8 * j


def tenant_setup_writes(t, q, cq, base, limit, prio_cap=0, weight=1):
    """CSR writes (addr, data) that give tenant t one RW region, queue q and CQ cq."""
    return [(REG.region(t, 0, 0), base), (REG.region(t, 0, 4), limit), (REG.region(t, 0, 8), 0x3),
            (REG.cq(cq), 0x1 | (t << 8)), (REG.q(q, 0), 0x1 | (t << 8) | (cq << 16)),
            (REG.q(q, 4), weight), (REG.t(t, 0), 0x1 | (prio_cap << 4))]
