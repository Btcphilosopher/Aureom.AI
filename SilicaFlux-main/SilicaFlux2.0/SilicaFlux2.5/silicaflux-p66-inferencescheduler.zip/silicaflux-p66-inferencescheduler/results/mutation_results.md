# Mutation testing results

Each mutant injects one deliberate bug into the RTL; the regression runs until the first failure.

| ID | Injected bug | Result | First test to fail (detector) |
|---|---|---|---|
| M01 | validator: output (C) permission check skipped | KILLED | invalid_cmds (testbench check) |
| M02 | validator: operand A permission check skipped | KILLED | invalid_cmds (testbench check) |
| M03 | validator: spoofed tenant_id accepted | KILLED | invalid_cmds (testbench check) |
| M04 | validator: BF16/FP16 formats accepted | KILLED | invalid_cmds (testbench check) |
| M05 | range check: 32-bit wrap-around not detected | KILLED | invalid_cmds (testbench check) |
| M06 | completion routing: descriptor CQ used even if foreign | KILLED | invalid_cmds (testbench check) |
| M07 | dispatch-time revalidation removed (TOCTOU) | KILLED | faults (RTL assertion) |
| M08 | completion router: CQ ownership check removed | KILLED | faults (RTL assertion) |
| M09 | no scrub when scratchpad owned by another tenant | KILLED | rr_order (RTL assertion) |
| M10 | reset leaves scratchpad marked CLEAN | KILLED | single_gemm (testbench check) |
| M11 | DMA gate allows every beat | KILLED | dma_gate_isolation (testbench check) |
| M12 | DMA gate checks read permission for writes | KILLED | dma_gate_write (testbench check) |
| M13 | DMA fault does not quarantine the tenant | KILLED | dma_gate_isolation (testbench check) |
| M14 | watchdog disabled | *not run* | – |
| M15 | abort drain disabled (faulted/disabled work stranded) | *not run* | – |
| M16 | admission limit ignored | *not run* | – |
| M17 | suspended tenants still scheduled | *not run* | – |
| M18 | priority cap not enforced | *not run* | – |
| M19 | WRR weights ignored | *not run* | – |
| M20 | aging disabled | *not run* | – |
| M21 | occupancy correction ignored by DRR and rate limiter | *not run* | – |
| M22 | rate limiter never blocks | *not run* | – |
| M23 | deadline policy picks latest instead of earliest | *not run* | – |
| M24 | response tag not checked | *not run* | – |

**13 / 13 executed mutants killed; 11 of 24 defined mutants not yet executed.**
