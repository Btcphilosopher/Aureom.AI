// #############################################################################
// ##                                                                         ##
// ##   SIMULATION MODEL — NOT THE VERIFIED SILICAFLUX TENSORCORE RTL          ##
// ##   DO NOT SYNTHESISE. DO NOT USE AS EVIDENCE OF HARDWARE TIMING.           ##
// ##                                                                         ##
// #############################################################################
// SilicaFlux Project 66 — sim_tensorcore_model.sv
//
// Behavioural, latency-aware stand-in for the SilicaFlux TensorCore, used
// because no TensorCore RTL was present in the audited workspace
// (docs/REPO_AUDIT.md). Hardware integration is BLOCKED until the real,
// verified TensorCore 02 systolic array and its command ABI are supplied
// (docs/INTEGRATION_STATUS.md).
//
// What it models
//   * INT8 x INT8 -> INT32 GEMM, row-major packed A[MxK], B[KxN], C[MxN].
//   * Timing of an output-stationary ROWS x COLS systolic array:
//       compute = ceil(M/ROWS) * ceil(N/COLS) * (K + ROWS + COLS - 1) cycles
//     plus word-by-word operand loads (up to MAX_OUT reads in flight) and
//     result stores, all through a real memory port subject to back-pressure.
//   * A shared scratchpad (operand buffers + accumulators) that is NOT
//     cleared by soft reset and keeps data between commands, so scheduler
//     scrubbing has something real to protect.
//   * Scrub command: ceil(scratchpad_bytes / SCRUB_BPC) cycles, then zero.
//
// Fault injection (testbench controlled; oob/hang/internal_err only apply to
// commands whose domain == fi_domain, or to all commands if fi_domain == 8'hFF)
//   fi_oob_offset   != 0 : the 3rd operand-A read is issued at +offset (rogue DMA)
//   fi_wr_redirect  != 0 : the first result word is stored to this absolute address
//   fi_hang              : accept the command and never respond (watchdog test)
//   fi_internal_err      : finish compute, skip the store, report INT_ERR
//   fi_acc_no_clear      : accumulators are NOT cleared at command start
//                          (models a TensorCore bug that leaks residue)
// #############################################################################
module sim_tensorcore_model
  import sf_iq_pkg::*;
#(
  parameter int unsigned ROWS      = 4,
  parameter int unsigned COLS      = 4,
  parameter int unsigned MAX_M     = 64,
  parameter int unsigned MAX_N     = 64,
  parameter int unsigned MAX_K     = 64,
  parameter int unsigned SCRUB_BPC = 64,
  parameter int unsigned MAX_OUT   = 8
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        soft_reset,
  input  logic        cmd_valid,
  output logic        cmd_ready,
  input  tc_cmd_t     cmd,
  output logic        rsp_valid,
  input  logic        rsp_ready,
  output tc_rsp_t     rsp,
  input  logic        scrub_req,
  output logic        scrub_done,
  output logic [2:0]  phase,
  output logic        mem_req_valid,
  input  logic        mem_req_ready,
  output logic        mem_req_we,
  output logic [31:0] mem_req_addr,
  output logic [31:0] mem_req_wdata,
  input  logic        mem_rsp_valid,
  input  logic [31:0] mem_rsp_rdata,
  input  logic        mem_rsp_err,
  input  logic [7:0]  fi_domain,        // 8'hFF = any command
  input  logic [31:0] fi_oob_offset,
  input  logic [31:0] fi_wr_redirect,   // != 0: first result word is written here
  input  logic        fi_hang,
  input  logic        fi_internal_err,
  input  logic        fi_acc_no_clear
);
  localparam int unsigned SPAD_BYTES = MAX_M*MAX_K + MAX_K*MAX_N + 4*MAX_M*MAX_N;
  localparam int unsigned SCRUB_CYC  = (SPAD_BYTES + SCRUB_BPC - 1) / SCRUB_BPC;

  // shared scratchpad (public for testbench residue checks)
  logic [7:0]  spad_a [MAX_M*MAX_K];
  logic [7:0]  spad_b [MAX_K*MAX_N];
  logic [31:0] acc    [MAX_M*MAX_N];

  tc_cmd_t     c;
  int unsigned wa, wb, issue_idx, resp_idx, outstanding, drop_cnt;
  int unsigned st_i, st_j, cnt;
  logic        dma_err, int_err, fi_act;
  logic [7:0]  rsp_status;

  // statistics (public)
  int unsigned stat_cmds, stat_scrubs;

  initial begin
    // SRAM power-up contents are undefined: fill with a non-zero pattern so a
    // missing scrub is observable.
    for (int i = 0; i < MAX_M*MAX_K; i++) spad_a[i] = 8'hA5;
    for (int i = 0; i < MAX_K*MAX_N; i++) spad_b[i] = 8'h5A;
    for (int i = 0; i < MAX_M*MAX_N; i++) acc[i]    = 32'hDEAD_BEEF;
  end

  assign cmd_ready  = (phase == PH_IDLE) && !scrub_req;
  assign rsp_valid  = (phase == PH_RESP);
  assign rsp.tag    = c.tag;
  assign rsp.status = rsp_status;
  assign scrub_done = (phase == PH_SCRUB) && (cnt == 0);

  // memory request generation
  always_comb begin
    mem_req_valid = 1'b0;
    mem_req_we    = 1'b0;
    mem_req_addr  = 32'd0;
    mem_req_wdata = 32'd0;
    if (phase == PH_LOAD && issue_idx < wa + wb && outstanding < MAX_OUT) begin
      mem_req_valid = 1'b1;
      if (issue_idx < wa) begin
        mem_req_addr = c.a_addr + 32'(4 * issue_idx);
        if (fi_act && fi_oob_offset != 32'd0 && issue_idx == 2) mem_req_addr = mem_req_addr + fi_oob_offset;
      end else begin
        mem_req_addr = c.b_addr + 32'(4 * (issue_idx - wa));
      end
    end else if (phase == PH_STORE) begin
      mem_req_valid = 1'b1;
      mem_req_we    = 1'b1;
      mem_req_addr  = c.c_addr + 32'(4 * (st_i * int'(c.n) + st_j));
      if (fi_act && fi_wr_redirect != 32'd0 && st_i == 0 && st_j == 0) mem_req_addr = fi_wr_redirect;
      mem_req_wdata = acc[st_i * MAX_N + st_j];
    end
  end

  task automatic do_compute();
    for (int i = 0; i < int'(c.m); i++) begin
      for (int j = 0; j < int'(c.n); j++) begin
        logic signed [31:0] s;
        s = 0;
        for (int kk = 0; kk < int'(c.k); kk++)
          s += $signed({{24{spad_a[i*int'(c.k)+kk][7]}}, spad_a[i*int'(c.k)+kk]}) *
               $signed({{24{spad_b[kk*int'(c.n)+j][7]}}, spad_b[kk*int'(c.n)+j]});
        acc[i*MAX_N + j] = (fi_acc_no_clear ? acc[i*MAX_N + j] : 32'd0) + s;
      end
    end
  endtask

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      phase <= PH_IDLE; c <= '0; wa <= 0; wb <= 0; issue_idx <= 0; resp_idx <= 0;
      outstanding <= 0; drop_cnt <= 0; st_i <= 0; st_j <= 0; cnt <= 0;
      dma_err <= 1'b0; int_err <= 1'b0; fi_act <= 1'b0; rsp_status <= TC_RSP_OK;
      stat_cmds <= 0; stat_scrubs <= 0;
    end else if (soft_reset) begin
      // soft reset: abandon work; scratchpad contents are deliberately kept
      phase       <= PH_IDLE;
      drop_cnt    <= drop_cnt + outstanding;
      outstanding <= 0;
    end else begin
      // read responses
      if (mem_rsp_valid) begin
        if (drop_cnt != 0) begin
          drop_cnt <= drop_cnt - 1;
        end else if (phase == PH_LOAD) begin
          for (int b = 0; b < 4; b++) begin
            int unsigned idx;
            if (resp_idx < wa) begin
              idx = 4*resp_idx + b;
              if (idx < int'(c.m)*int'(c.k)) spad_a[idx] = mem_rsp_rdata[8*b +: 8];
            end else begin
              idx = 4*(resp_idx - wa) + b;
              if (idx < int'(c.k)*int'(c.n)) spad_b[idx] = mem_rsp_rdata[8*b +: 8];
            end
          end
          if (mem_rsp_err) dma_err <= 1'b1;
          resp_idx <= resp_idx + 1;
        end
      end

      case (phase)
        PH_IDLE: begin
          if (scrub_req) begin
            phase <= PH_SCRUB;
            cnt   <= SCRUB_CYC;
            stat_scrubs <= stat_scrubs + 1;
          end else if (cmd_valid) begin
            c         <= cmd;
            wa        <= (int'(cmd.m) * int'(cmd.k) + 3) / 4;
            wb        <= (int'(cmd.k) * int'(cmd.n) + 3) / 4;
            issue_idx <= 0;
            resp_idx  <= 0;
            dma_err   <= 1'b0;
            fi_act    <= (fi_domain == 8'hFF) || (fi_domain == cmd.domain);
            int_err   <= fi_internal_err && ((fi_domain == 8'hFF) || (fi_domain == cmd.domain));
            stat_cmds <= stat_cmds + 1;
            phase     <= (fi_hang && ((fi_domain == 8'hFF) || (fi_domain == cmd.domain))) ? PH_HANG : PH_LOAD;
          end
        end

        PH_LOAD: begin
          logic iss, rsp_now;
          iss     = mem_req_valid && mem_req_ready;
          rsp_now = mem_rsp_valid && (drop_cnt == 0);
          if (iss) issue_idx <= issue_idx + 1;
          outstanding <= outstanding + (iss ? 1 : 0) - (rsp_now ? 1 : 0);
          if (resp_idx + (rsp_now ? 1 : 0) == wa + wb) begin
            if (dma_err || (rsp_now && mem_rsp_err)) begin
              rsp_status <= TC_RSP_DMA_ERR;
              phase      <= PH_RESP;
            end else begin
              cnt   <= ((int'(c.m) + ROWS - 1) / ROWS) * ((int'(c.n) + COLS - 1) / COLS) *
                       (int'(c.k) + ROWS + COLS - 1);
              phase <= PH_COMPUTE;
            end
          end
        end

        PH_COMPUTE: begin
          if (cnt <= 1) begin
            do_compute();
            st_i <= 0; st_j <= 0;
            if (int_err) begin
              rsp_status <= TC_RSP_INT_ERR;
              phase      <= PH_RESP;
            end else begin
              phase <= PH_STORE;
            end
          end else begin
            cnt <= cnt - 1;
          end
        end

        PH_STORE: begin
          if (mem_req_ready) begin
            if (st_j + 1 == int'(c.n)) begin
              st_j <= 0;
              if (st_i + 1 == int'(c.m)) begin
                rsp_status <= TC_RSP_OK;
                phase      <= PH_RESP;
              end else begin
                st_i <= st_i + 1;
              end
            end else begin
              st_j <= st_j + 1;
            end
          end
        end

        PH_RESP: if (rsp_ready) phase <= PH_IDLE;

        PH_SCRUB: begin
          if (cnt == 0) begin
            for (int i = 0; i < MAX_M*MAX_K; i++) spad_a[i] = 8'h00;
            for (int i = 0; i < MAX_K*MAX_N; i++) spad_b[i] = 8'h00;
            for (int i = 0; i < MAX_M*MAX_N; i++) acc[i]    = 32'h0;
            phase <= PH_IDLE;
          end else begin
            cnt <= cnt - 1;
          end
        end

        PH_HANG: ;   // only soft_reset leaves this state

        default: phase <= PH_IDLE;
      endcase
    end
  end
endmodule
