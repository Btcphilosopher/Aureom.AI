// #############################################################################
// ##   SIMULATION MODEL — stands in for CloudDMA / MemoryPool (absent)        ##
// ##   DO NOT SYNTHESISE.                                                     ##
// #############################################################################
// SilicaFlux Project 66 — sim_memory_model.sv
//
// Byte-addressed memory with a 32-bit word port.
//   * Reads: fixed RD_LAT pipeline, in-order responses.
//   * Contention: each cycle the port is unavailable with probability
//     contention_pct/100 (xorshift32), emulating other bus masters.
//   * Poisoned requests (from the DMA gate) never touch the array: poisoned
//     reads return 0 with rsp_err, poisoned writes are discarded. This is the
//     behaviour of an AXI default/error slave and is REQUIRED of the real
//     interconnect (docs/INTEGRATION_STATUS.md).
//   * Out-of-range addresses behave like poisoned requests.
// Counters are public for testbench assertions.
// #############################################################################
module sim_memory_model #(
  parameter int unsigned MEM_BYTES = 2*1024*1024,
  parameter int unsigned RD_LAT    = 4
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [7:0]  contention_pct,
  input  logic [31:0] seed,
  input  logic        req_valid,
  output logic        req_ready,
  input  logic        req_we,
  input  logic [31:0] req_addr,
  input  logic [31:0] req_wdata,
  input  logic        req_poison,
  output logic        rsp_valid,
  output logic [31:0] rsp_rdata,
  output logic        rsp_err
);
  logic [7:0] mem [MEM_BYTES];

  logic [31:0] lfsr;
  logic        pv [RD_LAT];
  logic [31:0] pd [RD_LAT];
  logic        pe [RD_LAT];

  int unsigned stat_reads, stat_writes, stat_poisoned, stat_busy_cycles;

  function automatic logic [31:0] xs32(input logic [31:0] x);
    logic [31:0] y;
    y = x ^ (x << 13);
    y = y ^ (y >> 17);
    y = y ^ (y << 5);
    return y;
  endfunction

  assign req_ready = ((lfsr % 100) >= {24'd0, contention_pct});
  assign rsp_valid = pv[RD_LAT-1];
  assign rsp_rdata = pd[RD_LAT-1];
  assign rsp_err   = pe[RD_LAT-1];

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lfsr <= (seed == 0) ? 32'h1234_5678 : seed;
      for (int i = 0; i < RD_LAT; i++) begin pv[i] <= 1'b0; pd[i] <= '0; pe[i] <= 1'b0; end
      stat_reads <= 0; stat_writes <= 0; stat_poisoned <= 0; stat_busy_cycles <= 0;
    end else begin
      logic acc, bad;
      lfsr <= xs32(lfsr);
      if (!req_ready) stat_busy_cycles <= stat_busy_cycles + 1;
      acc = req_valid && req_ready;
      bad = req_poison || (req_addr > 32'(MEM_BYTES - 4));
      for (int i = RD_LAT - 1; i > 0; i--) begin
        pv[i] <= pv[i-1]; pd[i] <= pd[i-1]; pe[i] <= pe[i-1];
      end
      pv[0] <= acc && !req_we;
      pd[0] <= '0;
      pe[0] <= 1'b0;
      if (acc) begin
        if (bad) stat_poisoned <= stat_poisoned + 1;
        if (req_we) begin
          if (!bad) begin
            for (int b = 0; b < 4; b++) mem[req_addr + b] <= req_wdata[8*b +: 8];
            stat_writes <= stat_writes + 1;
          end
        end else begin
          if (!bad) begin
            pd[0] <= {mem[req_addr+3], mem[req_addr+2], mem[req_addr+1], mem[req_addr]};
            stat_reads <= stat_reads + 1;
          end else begin
            pe[0] <= 1'b1;
          end
        end
      end
    end
  end
endmodule
