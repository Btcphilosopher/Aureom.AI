#!/usr/bin/env bash
# Build the Verilator simulation. Usage: scripts/build.sh [outdir] [extra verilator args]
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=${1:-build/obj}; shift || true
mkdir -p "$(dirname "$OUT")"
verilator --binary --timing --assert -j 8 --timescale 1ns/1ps \
  -Wno-fatal -Wno-WIDTH -Wno-UNUSED -Wno-BLKSEQ -Wno-INITIALDLY -Wno-MULTIDRIVEN -Wno-SYNCASYNCNET -Wno-SIDEEFFECT \
  --top-module tb_top -f scripts/files.f -Mdir "$OUT" -o sim "$@" > "$OUT.build.log" 2>&1 \
  || { tail -40 "$OUT.build.log"; exit 1; }
echo "built $OUT/sim"
