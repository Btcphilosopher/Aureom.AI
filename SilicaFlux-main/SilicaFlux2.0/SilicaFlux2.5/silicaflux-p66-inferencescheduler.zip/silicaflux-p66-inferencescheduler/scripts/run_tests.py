#!/usr/bin/env python3
"""Build and run the SilicaFlux Project 66 self-checking regression.

Usage: scripts/run_tests.py [-j N] [--no-build] [test ...]
Writes results/test_results.txt and per-test logs in results/logs/.
"""
import argparse, os, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TESTS = ["single_gemm", "queue_order", "rr_order", "invalid_cmds", "dma_gate_isolation", "dma_gate_write",
         "spad_scrub", "fairness", "priority", "deadline", "rate_limit", "admission",
         "backpressure", "reset", "cpl_assoc_random", "resource_exhaustion", "faults",
         "suspend_resume"]
# negative control runs on a separate build with ALLOW_SCRUB_BYPASS=1
NEG_TESTS = ["spad_scrub_negative"]


def build(outdir, extra=()):
    r = subprocess.run(["bash", os.path.join(ROOT, "scripts/build.sh"), outdir, *extra], cwd=ROOT,
                       capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout, r.stderr)
        sys.exit("build failed: " + outdir)


def run(test, simdir, timeout):
    logdir = os.path.join(ROOT, "results/logs")
    os.makedirs(logdir, exist_ok=True)
    log = os.path.join(logdir, test + ".log")
    t0 = time.time()
    try:
        r = subprocess.run([os.path.join(ROOT, simdir, "sim"), "+TEST=" + test], cwd=logdir,
                           capture_output=True, text=True, timeout=timeout)
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        out += "\nRESULT %s FAIL wallclock-timeout\n" % test
    open(log, "w").write(out)
    line = next((l for l in out.splitlines() if l.startswith("RESULT")), "RESULT %s FAIL no-result" % test)
    ok = (" PASS " in line) and ("%Error" not in out) and ("Assertion failed" not in out)
    return test, ok, line, time.time() - t0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-j", type=int, default=4)
    ap.add_argument("--no-build", action="store_true")
    ap.add_argument("--timeout", type=int, default=240)
    ap.add_argument("tests", nargs="*")
    a = ap.parse_args()
    tests = a.tests or (TESTS + NEG_TESTS)
    if not a.no_build:
        build("build/obj")
        if any(t in NEG_TESTS for t in tests):
            build("build/obj_neg", ["-GALLOW_SCRUB_BYPASS=1"])
    jobs = [(t, "build/obj_neg" if t in NEG_TESTS else "build/obj") for t in tests]
    with ThreadPoolExecutor(a.j) as ex:
        res = list(ex.map(lambda j: run(j[0], j[1], a.timeout), jobs))
    lines = []
    for t, ok, line, dt in res:
        lines.append("%-22s %s  (%5.1fs)  %s" % (t, "PASS" if ok else "FAIL", dt, line))
    npass = sum(ok for _, ok, _, _ in res)
    summary = "\n".join(lines) + "\n\n%d/%d tests passed\n" % (npass, len(res))
    print(summary)
    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    if not a.tests:
        open(os.path.join(ROOT, "results/test_results.txt"), "w").write(summary)
    sys.exit(0 if npass == len(res) else 1)


if __name__ == "__main__":
    main()
