#!/usr/bin/env python3
"""Mutation testing for the SilicaFlux Project 66 regression.

Each mutant is a single, deliberate bug injected into the RTL (a precise
string substitution). The mutant is built and the full directed regression is
run against it. A mutant is KILLED if any test fails (scoreboard check,
isolation monitor, or RTL assertion) and SURVIVES otherwise. Survivors expose
gaps in the verification suite.

Usage: scripts/mutation_test.py [MUTANT_ID ...]   (results -> results/mutation_results.md)
"""
import os, re, shutil, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TESTS = ["single_gemm", "queue_order", "rr_order", "invalid_cmds", "dma_gate_isolation",
         "spad_scrub", "fairness", "priority", "deadline", "rate_limit", "admission",
         "backpressure", "reset", "cpl_assoc_random", "resource_exhaustion", "faults",
         "suspend_resume", "dma_gate_write"]

# id, file, description, old, new
MUTANTS = [
 ("M01", "rtl/sf_iq_desc_validator.sv", "validator: output (C) permission check skipped",
  "else if (!c_ok)                                       status = ST_PERM_C;",
  "else if (1'b0)                                        status = ST_PERM_C;"),
 ("M02", "rtl/sf_iq_desc_validator.sv", "validator: operand A permission check skipped",
  "else if (!a_ok)                                       status = ST_PERM_A;",
  "else if (1'b0)                                        status = ST_PERM_A;"),
 ("M03", "rtl/sf_iq_desc_validator.sv", "validator: spoofed tenant_id accepted",
  "else if (desc.tenant_id != 8'(owner))                 status = ST_TENANT_MISMATCH;",
  "else if (1'b0)                                        status = ST_TENANT_MISMATCH;"),
 ("M04", "rtl/sf_iq_desc_validator.sv", "validator: BF16/FP16 formats accepted",
  "else if (desc.numfmt != FMT_INT8)                     status = ST_UNSUP_FMT;",
  "else if (1'b0)                                        status = ST_UNSUP_FMT;"),
 ("M05", "rtl/sf_iq_pkg.sv", "range check: 32-bit wrap-around not detected",
  "last = {2'b00, addr} + {2'b00, len} - 34'd1;",
  "last = {2'b00, addr + len - 32'd1};"),
 ("M06", "rtl/sf_iq_desc_validator.sv", "completion routing: descriptor CQ used even if foreign",
  "if (qid_ok && cq_ok) begin",
  "if (qid_ok) begin"),
 ("M07", "rtl/silicaflux_inference_queue.sv", "dispatch-time revalidation removed (TOCTOU)",
  "assign sel_ok      = sel_valid && (dp_status == ST_OK);\n  assign sel_bad     = sel_valid && (dp_status != ST_OK);",
  "assign sel_ok      = sel_valid;\n  assign sel_bad     = 1'b0;"),
 ("M08", "rtl/sf_iq_cpl_router.sv", "completion router: CQ ownership check removed",
  "route_ok = (src_cpl[pick].cq_id < 8'(NCQ)) && cq_valid[cq] &&\n               (8'(cq_owner[cq]) == src_cpl[pick].tenant);",
  "route_ok = (src_cpl[pick].cq_id < 8'(NCQ));"),
 ("M09", "rtl/sf_iq_tensor_adapter.sv", "no scrub when scratchpad owned by another tenant",
  "return (st == SP_UNKNOWN) || (st == SP_OWNED && own != t);",
  "return (st == SP_UNKNOWN);"),
 ("M10", "rtl/sf_iq_tensor_adapter.sv", "reset leaves scratchpad marked CLEAN",
  "sp_state      <= SP_UNKNOWN;     // SRAM contents survive reset: must scrub",
  "sp_state      <= SP_CLEAN;"),
 ("M11", "rtl/sf_iq_dma_gate.sv", "DMA gate allows every beat",
  "    if (active_valid) begin\n      for (int r = 0; r < NREG; r++) begin",
  "    allowed = 1'b1;\n    if (active_valid) begin\n      for (int r = 0; r < NREG; r++) begin"),
 ("M12", "rtl/sf_iq_dma_gate.sv", "DMA gate checks read permission for writes",
  "(m_req_we ? r_perm[active_tenant][r][1] : r_perm[active_tenant][r][0])",
  "r_perm[active_tenant][r][0]"),
 ("M13", "rtl/sf_iq_tensor_adapter.sv", "DMA fault does not quarantine the tenant",
  "if (rsp_status == ST_DMA_FAULT) fault_set[a_tenant] <= 1'b1;",
  "if (1'b0) fault_set[a_tenant] <= 1'b1;"),
 ("M14", "rtl/sf_iq_tensor_adapter.sv", "watchdog disabled",
  "wire wd_expired = (wd_limit != 32'd0) && (wd_cnt >= wd_limit);",
  "wire wd_expired = 1'b0;"),
 ("M15", "rtl/silicaflux_inference_queue.sv", "abort drain disabled (faulted/disabled work stranded)",
  "assign drain_fire = drain_any && !lc_valid && !sel_bad;",
  "assign drain_fire = 1'b0;"),
 ("M16", "rtl/silicaflux_inference_queue.sv", "admission limit ignored",
  "assign in_admit  = in_qid_ok && ({{(8-DW-1){1'b0}}, q_count[in_q]} < q_admit[in_q]);",
  "assign in_admit  = in_qid_ok;"),
 ("M17", "rtl/sf_iq_arbiter.sv", "suspended tenants still scheduled",
  "t_en[q_owner[q]] && !t_susp[q_owner[q]] && !t_fault[q_owner[q]] &&",
  "t_en[q_owner[q]] && !t_fault[q_owner[q]] &&"),
 ("M18", "rtl/sf_iq_desc_validator.sv", "priority cap not enforced",
  "prio_eff = (desc.prio > t_prio_cap[owner]) ? t_prio_cap[owner] : desc.prio;",
  "prio_eff = desc.prio;"),
 ("M19", "rtl/sf_iq_arbiter.sv", "WRR weights ignored",
  "credit_n[nxt] = (policy == POL_WRR) ? $signed({24'd0, q_weight[nxt]}) : 32'sd1;",
  "credit_n[nxt] = 32'sd1;"),
 ("M20", "rtl/sf_iq_arbiter.sv", "aging disabled",
  "aged  = (aging_limit != 32'd0) && ((now - head_submit[j]) >= aging_limit);",
  "aged  = 1'b0;"),
 ("M21", "rtl/sf_iq_arbiter.sv", "occupancy correction ignored by DRR and rate limiter",
  "if (corr_valid) credit_n[corr_q] = credit_n[corr_q] - corr_delta;",
  "if (1'b0) credit_n[corr_q] = credit_n[corr_q] - corr_delta;"),
 ("M22", "rtl/sf_iq_arbiter.sv", "rate limiter never blocks",
  "rl_ok[t]     = !t_rl_en[t] || (tokens[t] >= 0);",
  "rl_ok[t]     = 1'b1;"),
 ("M23", "rtl/sf_iq_arbiter.sv", "deadline policy picks latest instead of earliest",
  "(!is_prio && (slack <  best_slack))",
  "(!is_prio && (slack >  best_slack))"),
 ("M24", "rtl/sf_iq_tensor_adapter.sv", "response tag not checked",
  "wire        rsp_tag_ok = (tc_rsp.tag == a_tag);",
  "wire        rsp_tag_ok = 1'b1;"),
]


def sh(cmd, cwd, timeout=900):
    return subprocess.run(cmd, cwd=cwd, shell=True, capture_output=True, text=True, timeout=timeout)


def run_mutant(m):
    mid, f, desc, old, new = m
    work = "/tmp/mut_" + mid
    shutil.rmtree(work, ignore_errors=True)
    shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns("build", "results", "*.zip"))
    p = os.path.join(work, f)
    src = open(p).read()
    if src.count(old) != 1:
        return mid, desc, "INVALID", "pattern found %d times" % src.count(old), 0
    open(p, "w").write(src.replace(old, new))
    t0 = time.time()
    # -O0 C++: ~2x faster Verilator build, slower sim; fine for mutation runs
    r = sh("bash scripts/build.sh build/obj -MAKEFLAGS 'OPT_FAST=-O0 OPT_SLOW=-O0 OPT_GLOBAL=-O0'", work)
    if r.returncode != 0:
        return mid, desc, "BUILD-FAIL", r.stdout[-300:], time.time() - t0
    killed_by = []
    os.makedirs(os.path.join(work, "logs"), exist_ok=True)
    for t in TESTS:
        try:
            rr = subprocess.run([os.path.join(work, "build/obj/sim"), "+TEST=" + t],
                                cwd=os.path.join(work, "logs"), capture_output=True, text=True, timeout=120)
            out = rr.stdout + rr.stderr
        except subprocess.TimeoutExpired:
            out = "RESULT %s FAIL timeout" % t
        line = next((l for l in out.splitlines() if l.startswith("RESULT")), "RESULT %s FAIL none" % t)
        if " PASS " not in line or "%Error" in out:
            how = "RTL assertion" if "%Error" in out else "testbench check"
            killed_by.append("%s (%s)" % (t, how))
            break                       # first kill is enough
    shutil.rmtree(work, ignore_errors=True)
    status = "KILLED" if killed_by else "SURVIVED"
    return mid, desc, status, ", ".join(killed_by) if killed_by else "-", time.time() - t0


def main():
    sel = sys.argv[1:]
    muts = [m for m in MUTANTS if not sel or m[0] in sel]
    out = os.path.join(ROOT, "results/mutation_results.md")
    js = os.path.join(ROOT, "results/mutation_results.json")
    import json
    done = {r[0]: r for r in json.load(open(js))} if os.path.exists(js) else {}
    for m in muts:
        res = run_mutant(m)
        done[res[0]] = list(res)
        json.dump(sorted(done.values()), open(js, "w"), indent=1)
        rows = sorted(done.values())
        print("%s %-9s %s :: %s (%.0fs)" % (res[0], res[2], res[1], res[3], res[4]), flush=True)
        with open(out, "w") as fh:
            fh.write("# Mutation testing results\n\n")
            fh.write("Each mutant injects one deliberate bug into the RTL; the full directed regression is run.\n\n")
            fh.write("| ID | Injected bug | Result | First test to fail (detector) |\n|---|---|---|---|\n")
            for r in rows:
                fh.write("| %s | %s | %s | %s |\n" % (r[0], r[1], r[2], r[3]))
            k = sum(r[2] == "KILLED" for r in rows)
            fh.write("\n**%d / %d mutants killed.**\n" % (k, len(rows)))


if __name__ == "__main__":
    main()
