#!/usr/bin/env python3
"""Build docs/BENCHMARK_REPORT.md and docs/figures/*.png from results/bench.

All numbers come from measured simulation traces (results/bench/*/trace.csv)
and hardware counters (counters.txt) summarised in results/bench/summary.json.
Hand-written interpretation lives in docs/benchmark_findings.md and is spliced in.
"""
import csv, json, os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S = json.load(open(os.path.join(ROOT, "results/bench/summary.json")))
FIG = os.path.join(ROOT, "docs/figures")
os.makedirs(FIG, exist_ok=True)


def T(name, t, k):
    return S[name]["tenants"][str(t)][k]


def f(x, d=3):
    if x is None:
        return "–"
    if isinstance(x, float):
        return ("%." + str(d) + "f") % x
    return str(x)


def table(hdr, rows):
    out = ["| " + " | ".join(hdr) + " |", "|" + "---|" * len(hdr)]
    out += ["| " + " | ".join(f(c) if not isinstance(c, str) else c for c in r) + " |" for r in rows]
    return "\n".join(out)


def lat_list(name, t):
    rows = csv.DictReader(open(os.path.join(ROOT, "results/bench", name, "trace.csv")))
    return sorted(int(r["complete"]) - int(r["arrival"]) for r in rows
                  if int(r["tenant"]) == t and int(r["status"]) == 0)


md = []
md.append("# Scheduling benchmarks (brief §7, §8)\n")
md.append("> **Every number below is measured** from cycle-accurate simulation of the RTL scheduler driving the "
          "**behavioural TensorCore model** (4×4 INT8 systolic timing, 64 B/cycle scrub, 4-cycle memory, up to 8 reads "
          "in flight). Absolute cycle counts characterise the scheduler against that model, **not silicon**. "
          "Every OK result in every run was also checked bit-exact against a golden GEMM, and the scratchpad residue "
          "monitor was active (column `chk`).\n")
md.append("Reproduce: `python3 scripts/run_benchmarks.py && python3 scripts/make_report.py`. Raw traces: "
          "`results/bench/<scenario>/trace.csv` (one row per completion: submit / dispatch / complete cycles), "
          "counters: `counters.txt`, workloads: `workload.txt`, summary: `results/bench/summary.json`.\n")
md.append("Metric definitions: *MAC util* = useful MACs / (cycles × 16); *TC busy* = fraction of cycles a command "
          "occupies the TensorCore; *ctx* = fraction of cycles spent scrubbing for tenant switches; *ovh/disp* = "
          "scheduler-induced idle + dispatch cycles per dispatched command; latency = complete − arrival (open loop: "
          "intended arrival; closed loop: submission); Jain = Jain's index over weight-normalised TensorCore shares of "
          "backlogged tenants (1.0 = perfectly fair).\n")

findings = os.path.join(ROOT, "docs/benchmark_findings.md")
if os.path.exists(findings):
    md.append(open(findings).read() + "\n")


def chk(n):
    s = S[n]
    return "PASS" if (" PASS " in s["sim_result"] and s["residue_violations"] == 0 and s["scoreboard_errors"] == 0) else "FAIL"


# 1 one tenant
md.append("## 1. One tenant — scheduler overhead and TensorCore utilisation\n")
rows = []
for d in (8, 16, 32, 64):
    n = "one_tenant_%d" % d
    s = S[n]
    rows.append(["%d³" % d, s["completed_ok"], s["cycles"] / max(1, s["completed_ok"]), s["mac_utilisation"],
                 s["tc_busy_frac"], s["compute_frac"], s["dma_wait_frac"], s["overhead_per_dispatch"], chk(n)])
md.append(table(["GEMM", "cmds", "cycles/cmd", "MAC util", "TC busy", "compute", "DMA wait", "ovh/disp", "chk"], rows) + "\n")

# 2 two tenants
md.append("## 2. Two tenants — the cost of switching\n")
rows = []
for n in ("two_tenants_rr", "two_tenants_wrr4"):
    s = S[n]
    rows.append([n, s["cycles"], s["cmds_per_mcycle"], s["mac_utilisation"], s["ctx_switches"], s["ctx_switch_frac"],
                 s["ctx_cycles_per_switch"], s["jain_time_window"], chk(n)])
md.append(table(["scenario", "cycles", "cmds/Mcycle", "MAC util", "switches", "ctx", "cycles/switch", "Jain", "chk"], rows) + "\n")

# 3 four tenants mixed
md.append("## 3. Four tenants, mixed sizes — RR vs WRR vs DRR\n")
md.append("Tenant sizes: t0 8³, t1 16³, t2 32×32×16, t3 32³; WRR weights 1:2:3:4; DRR quantum 512 × weight 1.\n")
rows = []
for p in ("rr", "wrr", "drr"):
    n = "four_tenants_mixed_" + p
    s = S[n]
    rows.append([p.upper()] + [T(n, t, "win_share") for t in range(4)] + ["%d/%d/%d/%d" % tuple(T(n, t, "win_cmds") for t in range(4))] +
                [s["jain_time_window"], s["jain_cmds_window"], s["mac_utilisation"], s["ctx_switch_frac"], chk(n)])
md.append("Shares are measured from the traces inside the window where all four tenants were backlogged "
          "(whole-run shares would reflect each tenant's total demand instead).\n")
md.append(table(["policy", "t0 TC share", "t1 TC share", "t2 TC share", "t3 TC share", "cmds in window", "Jain TC time/weight",
                 "Jain cmds/weight", "MAC util", "ctx", "chk"], rows) + "\n")
fig, ax = plt.subplots(figsize=(7, 3.2))
w = 0.2
for i, p in enumerate(("rr", "wrr", "drr")):
    n = "four_tenants_mixed_" + p
    ax.bar([t + (i - 1) * w for t in range(4)], [T(n, t, "win_share") for t in range(4)], w, label=p.upper())
ax.axhline(0.25, ls="--", lw=0.8, color="k")
ax.set_xticks(range(4)); ax.set_xticklabels(["t0 8³", "t1 16³", "t2 32×32×16", "t3 32³"])
ax.set_ylabel("share of TensorCore time"); ax.legend(); ax.set_title("Measured TensorCore share by policy")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fairness_shares.png"), dpi=130); plt.close(fig)
md.append("![shares](figures/fairness_shares.png)\n")

n = "mixed_random_drr"
s = S[n]
md.append("**Random shapes (incl. 5×7×3, 24×40×8, 64×16×64), DRR:** windowed Jain (TC time) %s, MAC util %s, ctx %s, %s.\n" % (
    f(s["jain_time_window"]), f(s["mac_utilisation"]), f(s["ctx_switch_frac"]), chk(n)))

# 4 short vs long
md.append("## 4. Short vs long GEMMs — tail latency of a short stream behind 64³ work\n")
md.append("t0: 8³ open loop, mean inter-arrival 6000 cycles, prio 3, deadline hint 3000. t1: 64³ closed loop (2 outstanding).\n")
rows = []
for p in ("rr", "prio", "deadline", "drr"):
    n = "short_vs_long_" + p
    rows.append([p.upper(), T(n, 0, "lat_p50"), T(n, 0, "lat_p95"), T(n, 0, "lat_p99"), T(n, 0, "lat_max"),
                 "%d/%d" % (T(n, 0, "deadline_miss"), T(n, 0, "deadline_cmds")), T(n, 1, "svc_p50"),
                 S[n]["mac_utilisation"], chk(n)])
md.append(table(["policy", "t0 p50", "t0 p95", "t0 p99", "t0 max", "t0 hint misses", "t1 service p50", "MAC util", "chk"], rows) + "\n")
fig, ax = plt.subplots(figsize=(7, 3.2))
for p in ("rr", "prio", "deadline", "drr"):
    L = lat_list("short_vs_long_" + p, 0)
    ax.plot(L, [(i + 1) / len(L) for i in range(len(L))], label=p.upper())
ax.set_xscale("log"); ax.set_xlabel("8³ command latency (cycles)"); ax.set_ylabel("CDF")
ax.set_title("Short-command latency behind 64³ GEMMs (non-preemptive)"); ax.legend()
fig.tight_layout(); fig.savefig(os.path.join(FIG, "short_vs_long_cdf.png"), dpi=130); plt.close(fig)
md.append("![cdf](figures/short_vs_long_cdf.png)\n")

# 5 high priority
md.append("## 5. High-priority traffic over saturating background\n")
rows = []
for p in ("rr", "prio"):
    n = "high_prio_" + p
    bg = [T(n, t, "lat_p99") for t in (1, 2, 3)]
    rows.append([p.upper(), T(n, 0, "lat_p50"), T(n, 0, "lat_p99"), T(n, 0, "lat_max"), max(bg),
                 S[n]["mac_utilisation"], chk(n)])
md.append(table(["policy", "hi p50", "hi p99", "hi max", "worst background p99", "MAC util", "chk"], rows) + "\n")

# 6 contention
md.append("## 6. Memory contention\n")
rows = []
for c in (0, 25, 50, 75):
    n = "mem_contention_%d" % c
    s = S[n]
    rows.append(["%d%%" % c, s["cycles"], s["mac_utilisation"], s["compute_frac"], s["dma_wait_frac"], s["dma_stall_frac"],
                 T(n, 0, "svc_p50"), chk(n)])
md.append(table(["memory busy", "cycles", "MAC util", "compute", "DMA wait", "DMA stall", "service p50", "chk"], rows) + "\n")
fig, ax = plt.subplots(figsize=(6, 3))
cs = (0, 25, 50, 75)
ax.plot(cs, [S["mem_contention_%d" % c]["mac_utilisation"] for c in cs], "o-", label="MAC utilisation")
ax.plot(cs, [S["mem_contention_%d" % c]["dma_wait_frac"] for c in cs], "s-", label="DMA-wait fraction")
ax.set_xlabel("memory port busy (% of cycles)"); ax.legend(); ax.set_title("32³ GEMMs under memory contention")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "contention.png"), dpi=130); plt.close(fig)
md.append("![contention](figures/contention.png)\n")

# 7 saturation
md.append("## 7. Queue saturation and admission control\n")
rows = []
for a in (8, 3):
    n = "saturation_admit%d" % a
    s = S[n]
    rows.append([a, s["completed_ok"], s["rejected"], max(T(n, t, "lat_p99") for t in range(4)),
                 max(T(n, t, "lat_max") for t in range(4)), s["tc_busy_frac"], chk(n)])
md.append(table(["admission limit", "completed", "rejected", "worst tenant p99", "max latency", "TC busy", "chk"], rows) + "\n")

# 8 rate limit
n = "rate_limit_20pct"
md.append("## 8. Rate limiting\n")
md.append(table(["tenant", "limit", "TensorCore time share of all cycles", "completed"],
                [["t0", "20%", T(n, 0, "busy_share_of_time"), T(n, 0, "completed")],
                 ["t1", "none", T(n, 1, "busy_share_of_time"), T(n, 1, "completed")]]) + "\n")

# 9 context switch
md.append("## 9. Context-switch overhead vs batching (4 tenants of 8³)\n")
rows = []
for n in ("ctxswitch_rr", "ctxswitch_wrr8"):
    s = S[n]
    rows.append([n, s["ctx_switches"], s["ctx_switch_frac"], s["ctx_cycles_per_switch"], s["cmds_per_mcycle"],
                 s["mac_utilisation"], chk(n)])
md.append(table(["scenario", "switches", "ctx fraction", "cycles/switch", "cmds/Mcycle", "MAC util", "chk"], rows) + "\n")

# overhead breakdown figure
names = ["one_tenant_8", "one_tenant_64", "two_tenants_rr", "four_tenants_mixed_drr", "ctxswitch_rr", "ctxswitch_wrr8", "mem_contention_75"]
fig, ax = plt.subplots(figsize=(8, 3.4))
bot = [0] * len(names)
for key, lab in (("compute_frac", "compute"), ("dma_wait_frac", "load/store"), ("ctx_switch_frac", "scrub (ctx switch)"), ("idle_frac", "idle")):
    v = [S[x][key] for x in names]
    ax.bar(range(len(names)), v, bottom=bot, label=lab)
    bot = [a + b for a, b in zip(bot, v)]
ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=25, ha="right", fontsize=7)
ax.set_ylabel("fraction of cycles"); ax.legend(fontsize=7); ax.set_title("Where the cycles go")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "cycle_breakdown.png"), dpi=130); plt.close(fig)
md.append("## 10. Cycle breakdown\n\n![breakdown](figures/cycle_breakdown.png)\n")
md.append("*Remaining cycles not shown are TensorCore RESP/handshake, dispatch and completion-path cycles.*\n")

md.append("## All scenarios\n")
rows = [[n, S[n]["desc"], S[n]["cycles"], S[n]["completed_ok"], S[n]["rejected"], S[n]["mac_utilisation"], chk(n)] for n in S]
md.append(table(["scenario", "workload", "cycles", "ok", "rejected", "MAC util", "chk"], rows) + "\n")
open(os.path.join(ROOT, "docs/BENCHMARK_REPORT.md"), "w").write("\n".join(md))
print("report written: %d scenarios" % len(S))
