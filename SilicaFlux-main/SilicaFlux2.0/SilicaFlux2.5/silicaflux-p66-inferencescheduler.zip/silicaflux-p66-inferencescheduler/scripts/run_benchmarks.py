#!/usr/bin/env python3
"""SilicaFlux Project 66 — scheduling benchmarks (brief §7/§8).

Generates seeded workload files, runs them on the Verilator testbench in
+BENCH mode (every OK result is still checked against the golden GEMM), and
computes metrics from the MEASURED per-completion traces and hardware counters.

IMPORTANT: the TensorCore and memory are SIMULATION MODELS (4x4 INT8 systolic
timing model, 4-cycle memory). Absolute cycle counts characterise the
scheduler against that model; they are not silicon measurements.

Usage: scripts/run_benchmarks.py [--only name ...] [--no-build]
Outputs: results/bench/<scenario>/{workload.txt,trace.csv,counters.txt},
         results/bench/summary.json, docs/figures/*.png, docs/BENCHMARK_REPORT.md
"""
import argparse, csv, json, math, os, random, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BENCH = os.path.join(ROOT, "results/bench")
POL = {"RR": 0, "WRR": 1, "DRR": 2, "PRIO": 3, "DEADLINE": 4}
PEAK_MACS_PER_CYCLE = 16          # 4x4 array model
CFG_KEYS = {"policy": 1, "contention": 2, "quantum": 3, "aging": 4, "wd": 5, "cpl_pct": 6, "seed": 7, "check": 8}


# ----------------------------------------------------------------------------
# workload construction
# ----------------------------------------------------------------------------
class WL:
    def __init__(self, seed=1):
        self.cfg = {}
        self.tenants = {}
        self.cmds = []
        self.rng = random.Random(seed)
        self.cfg["seed"] = seed

    def tenant(self, t, weight=1, prio_cap=3, rl=None, admit=8, window=0):
        rl_en, rate, per, burst = (0, 0, 1, 0) if rl is None else (1, rl[0], rl[1], rl[2])
        self.tenants[t] = (weight, prio_cap, rl_en, rate, per, burst, admit, window)

    def closed(self, t, n, dims, prio=0, dl=0, window=3, **kw):
        self.tenant(t, window=window, **kw)
        for _ in range(n):
            m, nn, k = dims() if callable(dims) else dims
            self.cmds.append((0, t, m, nn, k, prio, dl))

    def open(self, t, n, dims, mean_ia, prio=0, dl=0, start=0, **kw):
        self.tenant(t, window=0, **kw)
        at = start
        for _ in range(n):
            at += max(1, int(self.rng.expovariate(1.0 / mean_ia)))
            m, nn, k = dims() if callable(dims) else dims
            self.cmds.append((at, t, m, nn, k, prio, dl))

    def write(self, path):
        with open(path, "w") as f:
            for k, v in self.cfg.items():
                f.write("1 %d %d\n" % (CFG_KEYS[k], v))
            for t, p in sorted(self.tenants.items()):
                f.write("2 %d %d %d %d %d %d %d %d %d\n" % ((t,) + p))
            for c in sorted(self.cmds, key=lambda c: c[0]):
                f.write("3 %d %d %d %d %d %d %d\n" % c)
            f.write("0\n")


def est_cost(m, n, k, R=4, C=4):
    return math.ceil(m / R) * math.ceil(n / C) * (k + R + C - 1) + (m * k + 3) // 4 + (k * n + 3) // 4 + m * n


def pick(rng, choices):
    return lambda: rng.choice(choices)


# ----------------------------------------------------------------------------
# scenarios (brief §8)
# ----------------------------------------------------------------------------
def scenarios():
    S = []

    def add(name, group, desc, wl):
        S.append((name, group, desc, wl))

    # 1. one tenant
    for d in (8, 16, 32, 64):
        w = WL(11); w.cfg["policy"] = POL["RR"]
        w.closed(0, 200 if d < 64 else 60, (d, d, d), window=4)
        add("one_tenant_%d" % d, "one_tenant", "1 tenant, closed loop, %dx%dx%d GEMM" % (d, d, d), w)

    # 2. two tenants, equal
    w = WL(12); w.cfg["policy"] = POL["RR"]
    for t in (0, 1): w.closed(t, 200, (16, 16, 16), window=4)
    add("two_tenants_rr", "two_tenants", "2 tenants, 16^3 each, RR", w)
    w = WL(12); w.cfg["policy"] = POL["WRR"]
    for t in (0, 1): w.closed(t, 200, (16, 16, 16), window=8, weight=4)
    add("two_tenants_wrr4", "two_tenants", "2 tenants, 16^3 each, WRR weight 4 (batches of 4)", w)

    # 3. four tenants, mixed sizes, RR / WRR / DRR
    sizes = [(8, 8, 8), (16, 16, 16), (32, 32, 16), (32, 32, 32)]
    for pol in ("RR", "WRR", "DRR"):
        w = WL(13); w.cfg["policy"] = POL[pol]; w.cfg["quantum"] = 512
        for t in range(4):
            w.closed(t, 400 if t == 0 else (200 if t == 1 else 80), sizes[t], window=8,
                     weight=(t + 1) if pol == "WRR" else 1)
        add("four_tenants_mixed_%s" % pol.lower(), "four_tenants",
            "4 tenants, sizes 8^3/16^3/32x32x16/32^3, %s" % pol, w)

    # 4. mixed random sizes, 4 tenants, DRR
    w = WL(14); w.cfg["policy"] = POL["DRR"]; w.cfg["quantum"] = 1024
    for t in range(4):
        w.closed(t, 120, pick(w.rng, [(4, 4, 4), (8, 8, 8), (16, 16, 16), (24, 40, 8), (32, 32, 32), (64, 16, 64), (5, 7, 3)]), window=6)
    add("mixed_random_drr", "mixed", "4 tenants, random shapes incl. non-multiples of 4, DRR", w)

    # 5. short vs long GEMMs: latency of the short stream under each policy
    for pol in ("RR", "PRIO", "DEADLINE", "DRR"):
        w = WL(15); w.cfg["policy"] = POL[pol]; w.cfg["quantum"] = 2048
        w.open(0, 150, (8, 8, 8), mean_ia=6000, prio=3, dl=3000)
        w.closed(1, 40, (64, 64, 64), window=2, prio=0)
        add("short_vs_long_%s" % pol.lower(), "short_long",
            "tenant0: 8^3 open-loop (mean IA 6000 cy, prio 3, hint 3000); tenant1: 64^3 closed loop; %s" % pol, w)

    # 6. high-priority traffic over saturating background
    for pol in ("RR", "PRIO"):
        w = WL(16); w.cfg["policy"] = POL[pol]; w.cfg["aging"] = 40000
        w.open(0, 200, (16, 16, 16), mean_ia=4000, prio=3)
        for t in (1, 2, 3):
            w.closed(t, 150, pick(w.rng, [(16, 16, 16), (32, 32, 16), (32, 32, 32)]), window=4, prio=0)
        add("high_prio_%s" % pol.lower(), "high_prio",
            "tenant0 16^3 open-loop prio 3 vs 3 saturating background tenants, %s" % pol, w)

    # 7. memory contention
    for c in (0, 25, 50, 75):
        w = WL(17); w.cfg["policy"] = POL["RR"]; w.cfg["contention"] = c
        for t in (0, 1): w.closed(t, 100, (32, 32, 32), window=3)
        add("mem_contention_%d" % c, "contention", "2 tenants 32^3, memory busy %d%% of cycles" % c, w)

    # 8. queue saturation (open loop at ~1.6x capacity) with admission limits
    cap_ia = None
    for admit in (8, 3):
        w = WL(18); w.cfg["policy"] = POL["RR"]
        for t in range(4):
            w.open(t, 250, (16, 16, 16), mean_ia=2600, admit=admit)
        add("saturation_admit%d" % admit, "saturation",
            "4 tenants open loop 16^3, offered ~1.6x capacity, admission limit %d" % admit, w)

    # 9. rate limiting
    w = WL(19); w.cfg["policy"] = POL["RR"]
    w.closed(0, 200, (16, 16, 16), window=4, rl=(1, 5, 2000))       # 20% of TensorCore time
    w.closed(1, 200, (16, 16, 16), window=4)
    add("rate_limit_20pct", "rate_limit", "tenant0 limited to 20% occupancy, tenant1 unlimited", w)

    # 10. context-switch cost vs batching (small GEMMs, frequent tenant changes)
    for pol, wt in (("RR", 1), ("WRR", 8)):
        w = WL(20); w.cfg["policy"] = POL[pol]
        for t in range(4): w.closed(t, 160, (8, 8, 8), window=8, weight=wt)
        add("ctxswitch_%s" % ("rr" if pol == "RR" else "wrr8"), "ctxswitch",
            "4 tenants of 8^3 GEMMs, %s (scrub on every tenant change)" % ("RR" if pol == "RR" else "WRR weight 8"), w)
    return S


# ----------------------------------------------------------------------------
# analysis
# ----------------------------------------------------------------------------
def pct(v, p):
    if not v:
        return float("nan")
    v = sorted(v)
    i = min(len(v) - 1, max(0, int(math.ceil(p / 100.0 * len(v))) - 1))
    return v[i]


def jain(x):
    x = [a for a in x if a is not None]
    if not x or sum(x) == 0:
        return float("nan")
    return sum(x) ** 2 / (len(x) * sum(a * a for a in x))


def analyse(d, wl):
    rows = list(csv.DictReader(open(os.path.join(d, "trace.csv"))))
    cnt = {}
    for line in open(os.path.join(d, "counters.txt")):
        a, b, c = line.split()
        cnt[(a, b)] = int(c)
    G = lambda k: cnt[("G", k)]
    cyc = G("CYCLES")
    res = {"cycles": cyc}
    ok = [r for r in rows if int(r["status"]) == 0]
    res["completed_ok"] = len(ok)
    res["rejected"] = G("REJECTED")
    res["errors"] = G("COMPLETED_ERR") + G("ABORTED")
    res["useful_macs"] = G("USEFUL_MACS")
    res["macs_per_cycle"] = G("USEFUL_MACS") / cyc
    res["mac_utilisation"] = res["macs_per_cycle"] / PEAK_MACS_PER_CYCLE
    res["cmds_per_mcycle"] = 1e6 * len(ok) / cyc
    res["tc_busy_frac"] = G("TC_BUSY") / cyc
    res["compute_frac"] = G("TC_COMPUTE") / cyc
    res["dma_wait_frac"] = G("DMA_WAIT") / cyc
    res["dma_stall_frac"] = G("DMA_STALL") / cyc
    res["ctx_switch_frac"] = G("CTX_SWITCH_CYCLES") / cyc
    res["ctx_switches"] = G("CTX_SWITCHES")
    res["sched_overhead_cycles"] = G("SCHED_OVERHEAD")
    res["dispatch_cycles"] = G("DISPATCH")
    res["dispatched"] = G("DISPATCHED")
    res["overhead_per_dispatch"] = (G("SCHED_OVERHEAD") + G("DISPATCH")) / max(1, G("DISPATCHED"))
    res["ctx_cycles_per_switch"] = G("CTX_SWITCH_CYCLES") / max(1, G("CTX_SWITCHES"))
    res["idle_frac"] = G("IDLE") / cyc
    res["cpl_backpressure"] = G("CPL_BACKPRESSURE")
    res["residue_violations"] = cnt[("M", "RESIDUE_VIOLATIONS")]
    res["scoreboard_errors"] = cnt[("M", "SCOREBOARD_ERRORS")]
    busy = {}
    per = {}
    for t in sorted(wl.tenants):
        tr = [r for r in ok if int(r["tenant"]) == t]
        lat = [int(r["complete"]) - int(r["arrival"]) for r in tr]
        qw = [int(r["dispatch"]) - int(r["submit"]) for r in tr]
        svc = [int(r["complete"]) - int(r["dispatch"]) for r in tr]
        dl = [r for r in tr if int(r["deadline"]) > 0]
        miss = sum(1 for r in dl if int(r["complete"]) - int(r["arrival"]) > int(r["deadline"]))
        rej = sum(1 for r in rows if int(r["tenant"]) == t and int(r["status"]) in (0x10, 0x11))
        b = cnt[("T%d" % t, "BUSY_CYCLES")]
        busy[t] = b
        per[t] = {"completed": len(tr), "rejected": rej, "busy_cycles": b, "busy_share_of_time": b / cyc,
                  "macs": cnt[("T%d" % t, "MACS")],
                  "lat_p50": pct(lat, 50), "lat_p95": pct(lat, 95), "lat_p99": pct(lat, 99), "lat_max": max(lat) if lat else None,
                  "qwait_p50": pct(qw, 50), "qwait_p99": pct(qw, 99), "svc_p50": pct(svc, 50),
                  "deadline_cmds": len(dl), "deadline_miss": miss,
                  "weight": wl.tenants[t][0]}
    tot = sum(busy.values()) or 1
    for t in per:
        per[t]["busy_share"] = busy[t] / tot
    # fairness among tenants that were backlogged (closed loop), weight-normalised.
    # Whole-run shares reflect total demand once tenants run dry, so shares are
    # computed from the traces inside the window where ALL closed-loop tenants
    # still had work: [first dispatch, earliest last-completion of any of them].
    closed = [t for t in per if wl.tenants[t][7] > 0]
    if closed:
        t0w = min(int(r["dispatch"]) for r in ok)
        t1w = min(max(int(r["complete"]) for r in ok if int(r["tenant"]) == t) for t in closed)
        res["fair_window"] = [t0w, t1w]
        wb = {t: 0 for t in per}
        wc = {t: 0 for t in per}
        for r in ok:
            d, c, t = int(r["dispatch"]), int(r["complete"]), int(r["tenant"])
            wb[t] += max(0, min(c, t1w) - max(d, t0w))
            if c <= t1w:
                wc[t] += 1
        tw = sum(wb[t] for t in closed) or 1
        for t in per:
            per[t]["win_share"] = wb[t] / tw if t in closed else None
            per[t]["win_cmds"] = wc[t]
        res["jain_time_window"] = jain([per[t]["win_share"] / per[t]["weight"] for t in closed]) if len(closed) > 1 else None
        res["jain_cmds_window"] = jain([wc[t] / per[t]["weight"] for t in closed]) if len(closed) > 1 else None
    res["jain_busy_weighted"] = jain([per[t]["busy_share"] / per[t]["weight"] for t in closed]) if len(closed) > 1 else None
    res["jain_cmds_weighted"] = jain([per[t]["completed"] / per[t]["weight"] for t in closed]) if len(closed) > 1 else None
    res["tenants"] = per
    return res


# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--no-build", action="store_true")
    ap.add_argument("--analyse-only", action="store_true")
    a = ap.parse_args()
    if not a.no_build and not a.analyse_only:
        r = subprocess.run(["bash", "scripts/build.sh", "build/obj"], cwd=ROOT)
        if r.returncode:
            sys.exit("build failed")
    os.makedirs(BENCH, exist_ok=True)
    summ_path = os.path.join(BENCH, "summary.json")
    summary = json.load(open(summ_path)) if os.path.exists(summ_path) else {}
    for name, group, desc, wl in scenarios():
        if a.only and name not in a.only and group not in a.only:
            continue
        d = os.path.join(BENCH, name)
        os.makedirs(d, exist_ok=True)
        wl.write(os.path.join(d, "workload.txt"))
        if not a.analyse_only:
            r = subprocess.run([os.path.join(ROOT, "build/obj/sim"), "+BENCH=workload.txt",
                                "+TRACE=trace.csv", "+COUNTERS=counters.txt"], cwd=d,
                               capture_output=True, text=True, timeout=1200)
            open(os.path.join(d, "sim.log"), "w").write(r.stdout + r.stderr)
            line = next((l for l in r.stdout.splitlines() if l.startswith("RESULT")), "RESULT none")
            if " PASS " not in line:
                print("!!", name, line)
        res = analyse(d, wl)
        res["group"], res["desc"] = group, desc
        res["sim_result"] = next((l for l in open(os.path.join(d, "sim.log")) if l.startswith("RESULT")), "").strip()
        summary[name] = res
        print("%-26s cyc=%8d ok=%4d rej=%3d util=%.3f busy=%.3f ctx=%.3f jain=%s %s" % (
            name, res["cycles"], res["completed_ok"], res["rejected"], res["mac_utilisation"],
            res["tc_busy_frac"], res["ctx_switch_frac"],
            "%.3f" % res["jain_time_window"] if res.get("jain_time_window") else "-",
            "PASS" if " PASS " in res["sim_result"] else "FAIL"), flush=True)
        json.dump(summary, open(summ_path, "w"), indent=1, default=str)


if __name__ == "__main__":
    main()
