# 00 — Repository audit (Project 103, SilicaFlux StreamDMA)

Audited: the working tree of the session checkout of `Btcphilosopher/Aureom.AI`. As in the earlier SilicaFlux projects the hardware lives
almost entirely **inside zip archives** (`SilicaFlux-main/`, `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`); the archives named in the
brief were located by member name and the ones that matter were extracted read-only to a scratch directory.

**What was and was not read.** Read line by line in this project: the CloudDMA P64 permission checker, permission table and package, the
CloudDMA audit / descriptor / protection / limitation documents, P61 `sfd_fifo` and `sfd_rr_arb`, and the Meridian arbitration document.
Located and sized by name, but **not re-read line by line here** (their properties below are quoted from CloudDMA P64's own audit of them,
`silicaflux-clouddma-p64/docs/00_AUDIT.md`): the HPC / Storage / HostLink / DataFabric DMA engines. Nothing from older projects was re-simulated.

## 1. Inventory against the brief

| Brief item | What exists (archive :: member) | Decision |
|---|---|---|
| **CloudDMA** | `silicaflux-clouddma-p64` (`silicaflux_cloud_dma`, `sfdma_channel`, `sfdma_desc_walker`, `sfdma_burst_ctrl`, `sfdma_perm_checker`, `sfdma_perm_table`, `sfdma_bytebuf`, …); `silicaflux-clouddpu-p61 :: sfd_clouddma` | **Reused** (vendored byte-for-byte): `sfdma_perm_checker`, `sfdma_perm_table`, `silicaflux_dma_pkg`, and P61's `sfd_fifo`. **Not reused**: the CloudDMA channel itself — it is a different, larger design (descriptor-in-memory chain walker, CRC, completion record written to memory, IOMMU ASIDs, multi-channel) and it has no `memmove`; StreamDMA is a new single-channel engine whose differences are listed in docs/01 |
| **HPC DMA** | `silicaflux-hpc-m05-dma-adapter :: hpc_dma_adapter` (+ M07 perf counters) | Not reused. A word-oriented adapter; no byte strobes / unaligned bursts (per P64's audit) |
| **Storage DMA** | `silicaflux-storagecore-p51 :: sfs_dma` | Not reused (one outstanding, aligned). Storage is memory type 2 behind the memory port |
| **DataFabric** | `silicaflux-datafabric :: silicaflux_dma, dma_transfer_engine, dma_burst_engine, dma_validate, sfb_*` | **Contract noted, not reused.** SFB2 has no native bursts and no IDs (R5/R6/R10, per its PROTOCOL.md), so it cannot carry reordered, multi-outstanding bursts. StreamDMA's port is AXI4-style (INCR bursts, IDs). **Gap:** there is no AXI4→SFB2 slave adapter in the repository; local SRAM behind SFB2 needs one |
| **MeridianQoS** | `silicaflux-meridian-p83 :: sf_meridian_arbiter, sf_meridian_mport, sf_meridian_fabric` (QoS classes, aging) | Not integrated. QoS arbitration between masters belongs in the fabric in front of the memory port; mapping a StreamDMA port onto a Meridian master port was not evaluated |
| **SRAMController** | `silicaflux-sramcontroller-p73 :: sf_sram_controller` | Not instantiated. Local SRAM is memory type 1 reached through the memory port |
| **MemoryMatrix** | **no module of that name exists** (searched member names of every archive and file contents) | — |
| **TensorCore / Vector Engine** | `silicaflux.zip :: vector_engine.sv, tensor_unit.sv`; `silicaflux-tensorcore0x`; `silicaflux-tensorcore07 :: tensor_dma_adapter`; `silicaflux-hpc-m02-vector-lane` | Compute sinks/sources: memory type 4 ("compute scratchpad"). Not integrated; the tensor DMA adapter is a different, narrower interface |
| **MemoryGuard** | **no module of that name exists.** Nearest verified artefacts: `sfdma_perm_checker/table` (P64), `sf_albion_iommu` in `silicaflux-domainguard`, `sfd_sram_guard`/`sfd_host_guard` in P61 | StreamDMA **defines** the MemoryGuard interface as the IOMMU contract of the P64 checker and reuses that checker (docs/03). DomainGuard was listed but not integrated |
| HBM | `silicaflux-hbmcore :: sf_hbm_dma_adapter` | Not integrated. HBM is memory type 0 |

## 2. Reuse actually made

Vendored **unchanged** (`third_party/`, SHA-256 in `third_party/MANIFEST.sha256`; the hashes equal both the CloudDMA project's manifest and the
archive member): `sfd_fifo.sv`, `sfd_rr_arb.sv` (P61; the latter is vendored for completeness, not instantiated), `sfdma_perm_checker.sv`,
`sfdma_perm_table.sv`, `silicaflux_dma_pkg.sv` (P64). `sfd_fifo` is used for the descriptor queue, both segment FIFOs, the AR / AW look-ahead
queues, the burst-plan queues and the W FIFO. The checker is the MemoryGuard front end. The table is the bench's MemoryGuard model
(a *model of an IOMMU contract*, not an isolation mechanism).

## 3. Modules that do not exist and what stands in for them

| Needed | Stand-in |
|---|---|
| MemoryGuard / IOMMU | vendored P64 checker + simulation table (verified there against an independent 64-bit reference) |
| AXI4→SFB2 adapter | none; the bench models an AXI4 slave |
| A control plane that supplies the trusted domain with each descriptor | the `desc_domain` sideband; the bench drives it |
| Memory (DRAM/SRAM/storage/network/compute) | the bench's byte-array slave model, with reordering, interleaving, latency, backpressure and faults |

## 4. Tooling used here

Verilator 5.020, Yosys 0.33, Icarus Verilog 12 (present, not used for the system bench), Z3 4.8.12 with `yosys-smtbmc`, Python 3. SymbiYosys is
not packaged for this environment; `formal/stream_dma/run_formal.py` performs the same Yosys → SMT2 → `smtbmc` steps. The repository coding rules for
Yosys 0.33 were followed (flat ports, no packages in the new RTL, no `int'()` casts).

## 5. Gaps found in the repository that this project does not close

No MemoryGuard, no AXI4→SFB2 adapter, no memory fabric with multiple outstanding transactions in front of local SRAM, no FPGA or silicon
result anywhere in the repository that this design could be compared with.
