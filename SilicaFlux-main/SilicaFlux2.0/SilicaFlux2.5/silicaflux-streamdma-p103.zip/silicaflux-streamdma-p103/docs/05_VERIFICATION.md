# 05 — Verification

Evidence is split by strength: **formal** (proofs on the RTL), **simulation with an independent reference model and monitors**, and **mutation testing** (does the bench notice injected bugs?).
Result files: `reports/regression.md`, `reports/formal.md`, `reports/formal_mutants.md`, `reports/mutation.md`, `reports/lint.md`.
Everything is reproducible with `make all` (see README).

## 1. The bench (`tests/stream_dma/`)

| Part | What it is |
|---|---|
| `tb_top.sv` | wrapper: the DUT behind the vendored CloudDMA permission table (the MemoryGuard model), wide buses at fixed width so one C++ bench serves every `DATA_WIDTH` |
| `tb_core.h` | **AXI slave model** (byte arrays per memory type; latency, jitter, random ready/valid; reads in order / bursts reordered / beats interleaved across IDs; B in order or reordered; slave that waits for `WVALID` before `AWREADY`; error responses at chosen beats; hang modes) and the **per-cycle monitors** |
| `tb_ref.h` | the **independent byte-accurate reference model**: its own descriptor-validation rules (written from docs/02), its own translation table, its own byte arrays and write counters; strictly sequential, byte-by-byte execution of the descriptor stream; predicts every completion record |
| `tb_main.cpp` | test classes, random generator, driver |
| `tb_bench.h` | benchmark mode (performance counters; every run still checked) |

**Monitors, checked every cycle:** `valid` held and payload stable until `ready`; burst size / type / alignment / ≤ `BURST_LENGTH` / no 4 KiB crossing; ID range and
uniqueness among outstanding requests; `WLAST` placement; no zero strobe; **no data on a lane whose strobe is 0** (stale-data leak); domain sideband ∈ trusted domains of the run;
**protection monitor** (every AR/AW physical range must be granted by the bench's own translation table); **stray-access monitor** (every AR/AW must lie in the beat-aligned envelope of a segment of the stream);
guard protocol error never raised; a bus-level **completion-contract check** (reported `bytes_done` = payload bytes of write bursts the slave answered `OKAY`).

**Per-run checks against the reference:** completion records (txn, domain, status, error code, `bytes_done`, `bytes_total`, guard fault detail); every destination byte; **every byte's write count**
(a lost byte shows as a missing write, a duplicated byte as a count of 2, a stray byte as a write outside every destination); no write by a refused transaction; performance counters vs the bus monitor
(bursts, beats, bytes) and the plan; irq pulse count; quiescence (nothing happens after completion).

## 2. Test classes against the brief's list

| Brief item | Test class (runs per configuration & seed) |
|---|---|
| Single-byte transfers | `single_byte`: every source lane × destination lane (all memory-type pairs), last byte of a page |
| Full-width transfers | `full_width`: 1, 2, BL−1, BL, BL+1, 2·BL, 3·BL+5 beats, aligned |
| Large bursts | `large`: 4 KiB … 250 000 bytes, aligned / unaligned, starting just below 4 KiB boundaries |
| Scatter-gather | `scatter_gather`: gather / scatter / both noncontiguous, 64 one-byte segments, boundaries on beat and burst edges |
| Unaligned boundaries, partial strobes | `unaligned`: random (source offset × destination offset × length) over the whole offset space incl. BL·W±1; partial first/last beats observed on the bus |
| Random backpressure | `backpressure` (six profiles on every channel, completion port and descriptor push), `aw_waits_for_w`, `completion_backpressure`, `random_regression` (random per-run slave) |
| Multiple transactions | `multi_txn`, `random_regression` |
| Reordering / interleave / multiple outstanding | `reorder_interleave` (read bursts reordered, beats interleaved, B reordered); configurations with 2, 3, 4, 8 slots |
| Memory faults | `memory_faults`: SLVERR/DECERR on read and write at first / middle / last burst, one beat or all beats, mid-chain; engine recovers |
| Invalid descriptors | `invalid_descriptors`, `descriptor_boundaries`, `invalid_chains`, `type_disable`: every error code, boundaries (exactly 2^AW legal, +1 byte an overflow), an invalid descriptor at every chain position, structural errors, stray descriptors, resynchronisation |
| Protection violations | `protection`: unmapped src/dst, read-only / write-only windows, straddling windows, other domain's window, claimed-vs-trusted domain, domain change mid-chain, disabled memory types; no write by a refused transaction |
| Hazards / overlap | `hazards`: RAW chains, WAW (last writer wins), WAR, FENCE, in both slave modes; the interlock must fire; intra-segment overlap rejected |
| Reset during transfers | `reset_cancel`: hard and soft reset at random cycles during random traffic: no bus activity afterwards, no completion, written bytes correct and in place, next transaction clean |
| Abort, timeout | `abort`, `timeout_fence` (R/B/AR/AW/W/guard hangs; fence holds; recovery; no false timeout while waiting for software) |
| Protocol faults | `bus_protocol_faults` (bad RLAST, spurious B) |
| No lost or duplicated bytes | every run (write-count check) |

## 3. Configurations (`tests/stream_dma/configs.sh`)

`initial` (128-bit, 1/1 outstanding, PLAN 1) · `par4` (4/4) · `small` (BL 4, FIFO 8, 2/2, small length limits — exercises the total-bytes limit and tight buffers) · `dw64` (3 read / 2 write slots: non power-of-two) ·
`dw256` · `dw32` (BL 64) · `dw512` (BL 8). Each runs 5 seeds with random initial register values (`--x-initial unique`, `+verilator+rand+reset+2`).

## 4. Mutation testing (`scripts/mutate.py`)

Each mutant injects ONE bug in a scratch copy of the RTL, rebuilds the bench and runs the suite with fail-fast; **the suite must fail**. The list targets the bug classes the brief names: lane/strobe
errors, lost / duplicated / garbage bytes, address formed without the guard (read and write), burst crossing 4 KiB / too long / ring overrun, response matched by position instead of ID, completion
before the writes are acknowledged, ignored bus errors, slots never freed, domain / overlap / overflow / version / reserved checks removed, skip-mode resynchronisation, hazard interlock removed / released early,
watchdog dead, soft reset without the guard drain. Result in `reports/mutation.md`.
Honest history: the early mutation runs left **three survivors**. (1) `read-rlast-unchecked` was an *equivalent* mutant (the fault was still raised by a second, redundant check) — replaced by a mutant that removes that
second check. (2) `write-b-ok-counts-error` exposed a real gap: the bench did not compare `bytes_done` with the bus's own acknowledgements — the bus-level completion-contract check was added. (3) `desc-skip-never-ends` exposed
a real gap: no test put a stray descriptor right after a broken transaction's LAST — a test was added. All three are killed in the final run.

## 5. Formal (`formal/stream_dma/`)

| Harness | Property | Strength |
|---|---|---|
| `fv_plan.sv` | burst planner equals its specification and: 1 ≤ bytes ≤ remaining, 1 ≤ beats ≤ BURST_LENGTH, beat envelope inside one 4 KiB page, payload lane accounting exact | exhaustive (4 parameter sets) |
| `fv_dcheck.sv` | `err == 0` ⇔ every acceptance rule; implies no overflow / in range / no overlap / domain bound | exhaustive (AW 16, 40, 64) |
| `fv_align.sv` | byte order preserved, conservation `cnt == in − out`, strobes exact, unused lanes zero, no overflow | BMC (DW 16: 12 cycles, DW 32: 8 cycles) |
| `fv_buffer.sv` | equivalent to a shadow model; entries visible strictly in reservation order whatever the fill order | BMC (4 and 8 entries) |
| `fv_cpl.sv` | record stable until accepted; an OK record has `done == total`; status/error consistency; flush/fence shapes | BMC (12 cycles) |
`formal_mutants.py` injects known bugs and requires the matching harness to find them (`reports/formal_mutants.md`) — a proof that cannot fail proves nothing.
One formal mutant (suppressing `cpl_valid` for the first cycle) was *benign* — it only delays the record and violates no stated property — and was replaced by one where `valid` drops while the record is stalled (caught).
Two harness defects were found and fixed along the way (an unrealistic environment that let `fault_evt` arrive with code 0; `assume` statements that Yosys's built-in SAT ignores — constraints are now built into the stimulus).

## 6. Bugs and hazards found by this verification (and fixed)

1. `kill` dropped one cycle before `flush` took effect, so a burst could be *counted* (not issued) in that cycle: performance counters over-counted and the behaviour was fragile. `kill` is now held through the flush cycle (mutant `cpl-kill-not-held-in-flush`).
2. **Soft reset hazard:** a core reset while the external guard still had a response in flight could let that stale answer be matched to a later request, giving it the wrong physical address. `ctl_soft_reset` is now deferred until the guard is quiet (`soft_reset_pending`), and `soft_reset_active` tells the platform when to reset the fabric.
3. The planner's `rem[13:0]` slice was out of range for `MAX_SEG_LOG2 < 13` (found by the lint matrix); fixed by zero-extension.
4. Bench defects fixed: wrong hand-expectations (flag precedence), a generator that produced illegal source addresses, abort-test timing races, test lengths beyond the small configuration's limits.

## 7. What was not verified

See docs/08: no hardware; read/write engines and integration are simulation-only; one simulator; models by the same author.
