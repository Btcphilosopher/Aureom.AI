# 08 — Limitations: what this is **not**

Read this before relying on anything in this directory.

## Evidence level

* **Everything is simulation and formal on RTL.** Verilator 5.020 system bench; Yosys 0.33 / Z3 / Yosys-SAT proofs; Yosys generic and Xilinx-7 mapping for
  resource estimates. **No FPGA, no place-and-route, no silicon, no timing closure, no power analysis.** No frequency, area (µm²) or power number is
  claimed. Throughput numbers are simulation cycles against a behavioural slave.
* **Formal coverage is partial.** Exhaustive (a proof over all inputs): burst planner, descriptor checker. **Bounded** (BMC to the depths in
  reports/formal.md, not unbounded proofs): byte realigner (DW = 16, 32), data-buffer ring (4 and 8 entries), completion engine. **Not formally verified**: the read and write
  engines, the hazard interlock, the top-level integration, the vendored MemoryGuard path (verified in CloudDMA P64, not re-proved here). Their evidence is the bench, the monitors and the mutation run.
* **Directed + constrained-random, not exhaustive.** Coverage is reported as test classes and counts, not as code/toggle coverage from a coverage tool.
* **Mutation testing samples, it does not cover.** The injected faults (reports/mutation.md) were chosen to model the bug classes the brief names; that every one is
  detected is evidence the bench is sensitive to those faults, not a measure of completeness. Three survivors in the early runs exposed two real bench gaps (closed with a new check and a new test) and one equivalent mutant (docs/05 §4).
* **One simulator.** Icarus Verilog is installed but was not used for the system bench (SystemVerilog + C++ harness).
* **The slave, the guard and the reference model are models written for this project.** Real memories add behaviours they do not have (posted writes acknowledged
  early, link-level retries, address-dependent latency, ATS/PASID). The reference model and the RTL were written by the same author; independence is of *code and structure*, not of authorship.

## Function

* **One channel** (`NUM_CHANNELS` must be 1; any other value is an elaboration error). The brief's first stage ("one fully verified DMA channel") is what is delivered.
* **One transaction in flight.** Memory-level parallelism (`MAX_OUTSTANDING_*`) is implemented and verified; *transaction-level* overlap is not. Consequence, measured
  (benchmarks/stream_dma/REPORT.md §4): 64-byte transactions run at ≈ 1.4 B/cycle at 10-cycle memory latency regardless of outstanding depth. Next step: overlap the start
  of transaction n+1 with the completion tail of n; it needs per-transaction contexts and error attribution.
* **No `memmove`**: an overlapping copy inside one segment is **rejected** (`ERR_OVERLAP`); cross-segment hazards are interlocked.
* One opcode (COPY). No fill, compare, CRC, or gather list on one side only. Segment length ≤ `2**MAX_SEG_LOG2`.
* **No rollback.** After an error, bytes already written stay written (`bytes_done` counts the acknowledged ones). Chains are not atomic.
* **Fence after a timeout:** the channel stays fenced until `ctl_soft_reset`/`rst_n`; a bus that never answers wedges it by design.
* Write completion means "`B` received". Posted-write interconnects weaken that guarantee (platform property).
* Read responses may interleave and reorder across IDs; **same-ID reordering is not supported** (the DMA never reuses an ID while outstanding, so it never needs it).
* Data width 32..512 (power of two); bursts ≤ 4 KiB and ≤ 256 beats; `ADDR_WIDTH` ≤ 64.
* The data buffer is register-file style storage with an asynchronous read port. In a generic ASIC flow it becomes flip-flops (reports/synth.md); production use needs an SRAM macro
  with a registered read (not done). On FPGA it maps to distributed RAM.

## Protection

* The vendored table is a **model** of an IOMMU contract, not an isolation mechanism. Real isolation needs the platform conditions in 09_INTEGRATION.
* Permission is evaluated **per burst, ahead of use**; revoking a mapping while a burst is authorised-but-in-flight does not stop that burst — quiesce first.
* **IOVA aliasing** (two IOVAs mapped to the same physical bytes) cannot be detected from addresses and can defeat the overlap check; mappings must be injective.
* No scrubbing of the data buffer between transactions; no side-channel isolation; no DoS fairness; no ECC/parity on the buffer or the descriptors.
* `ctl_soft_reset` is only safe if the fabric is reset in the `soft_reset_active` cycle and the guard has no accepted-but-unanswered request (otherwise it never completes; use `rst_n`).

## Not done

Multi-channel; transaction overlap; SRAM-macro buffer; CSR block and driver; integration with the repository's MeridianQoS fabric, SRAMController, TensorCore, Vector Engine
or a real MemoryGuard (none exists); AXI4→SFB2 adapter (none exists).
