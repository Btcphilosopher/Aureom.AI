# 07 — FPGA / ASIC integration: lint, synthesis, FIFOs, timing structure, resources, pipeline depth

**Evidence level: Yosys 0.33 synthesis estimates only — generic gates (`abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX`), `abc -lut 6`, and `synth_xilinx -family xc7` mapping. No PDK, no place-and-route, no timing constraints,
no FPGA or silicon was built. Nothing below is a frequency, power or µm² figure.** Raw tables: `reports/synth.md`, `reports/synth.json`, `reports/lint.md`.
(The synthesis run was taken before one width-only edit in `sf_stream_dma_plan` — a zero-extension of the remaining-bytes input — which changes no logic.)

## Lint

Verilator `-Wall`: 0 warnings in 9 parameterisations (32…512-bit, 3/2 non-power-of-two slots, 64-bit and 16-bit addresses, `BURST_LENGTH` 5, 8/8 slots); the vendored files are waived by file glob only (`rtl/lint.vlt`) and are
checked for byte identity instead. 13 illegal parameter combinations are rejected at elaboration. Yosys 0.33 reads the whole design (coding rules of the repository followed: flat ports, no packages/structs in new RTL, no `int'()`).

## Resource use (flattened `sf_stream_dma`)

| config | ASIC-generic cells | flops | Xilinx-7 LUTs | FFs | LUTRAM cells |
|---|---|---|---|---|---|
| initial (128-bit, 1/1, FIFO 64, W-FIFO 32) | 69 565 | 18 974 | 9 823 | 4 272 | 158 |
| 4/4 outstanding, PLAN 2 | 72 201 | 19 649 | 9 943 | 4 387 | 208 |
| 256-bit, 4/4 | 112 249 | 32 907 | 14 309 | 4 779 | 277 |

Going from 1/1 to 4/4 outstanding costs ~4% cells (slot tables and look-ahead queues): the buffers, not the request tracking, dominate. Per block (`reports/synth.md`): the **performance bank is the single largest control item**
(15 069 cells, 1 664 flops = 22% of the initial design: 36 counters × 48 bits, saturating); `CNT_W = 32` would remove about a third of its flops and is the first area knob if the counters are not all needed.

## FIFO implementation

* **Data buffer (ring)** `FIFO_DEPTH × (DATA_WIDTH + log2(bytes/beat) + 1)` bits (64 × 133 = 8.5 kbit initially), one write port, one *asynchronous* read port, per-entry valid bits.
  *FPGA:* maps to distributed RAM (`RAM32M`/`RAM64M`, 45 cells for the ring alone). *Generic ASIC flow:* no memory compiler, so it becomes **8 602 flip-flops** (the "flops" column) — **not acceptable for production**; the intended
  implementation is an SRAM macro with a **registered** read (not done; requires a one-cycle head prefetch). This is the largest single resource item.
* **W FIFO**, **AR/AW look-ahead queues**, **segment FIFOs**, **descriptor queue**: the vendored `sfd_fifo` (storage not reset, control reset): distributed RAM on FPGA, flops in the generic flow (the write path shows 5 511 flops, mostly the 32-beat W FIFO).

## Control timing and combinational critical paths (logic depth, not frequency)

| block | gate levels (generic) | LUT6 levels | comment |
|---|---|---|---|
| `sf_stream_dma_dcheck` | 114 | 24 | 128-bit overflow/overlap compares and adds in **one cycle** |
| `sf_stream_dma_descriptor` | 124 | 26 | dcheck + context + output register: **the deepest path in the design** |
| `sf_stream_dma_read` | 81–82 | 18 | R ingest (slot lookup → shift/mask → ring write index) and hazard-hull compares |
| `sf_stream_dma_write` | 71 | 16 | assembler (aligner pop → W-FIFO), AW issue |
| `sf_stream_dma_perf` | 81 | 17 | 48-bit saturating adders |
| `sf_stream_dma_cpl` | 64 | 13 | |
| `sf_stream_dma_plan`, `_align`, `_buffer` | 34 / 34 / 30 | 9 / 8 / 7 | data path stays shallow: the realigner is two byte-granular barrel shifters |

Top level: 120–128 gate levels, 26–27 LUT6 levels, set by the validator path, not the data path. Mitigation available (not implemented): register the validator in two stages (range/overflow compares, then overlap/total) — adds one cycle of latency per
descriptor (effect not measured); the hazard-hull compares can be pipelined the same way. All outputs on the memory port (`ar_*`, `aw_*`, `w_*`) are registered or FIFO-driven; `r_ready`/`b_ready` are constant 1; every input
response passes through a register stage before any slot lookup.

## Pipeline depth

* **Data path, per beat:** `R` input register → ring write (visible next cycle) → aligner accumulator → W FIFO → `W` pin: **4 register stages** from the `R` pin to the `W` pin, plus the store-and-forward wait for the rest of the write burst.
* **Measured (simulation, 2-cycle memory latency, 4-beat burst):** last `R` beat → `AW` 5 cycles; `AW` → `B` 5; `B` → completion record 3; completion accepted → next transaction's first `AR` 11 (validator, segment FIFOs, hazard stage, planner, guard round trip, AR issue).
* **Control:** the guard round trip is a few cycles per burst (the bench's table has `LAT = 2`, plus the checker and queue registers); it is hidden by `PLAN_DEPTH = 2` and costs ~6% at low latency with `PLAN_DEPTH = 1` (measured, docs/06).
* **Throughput vs depth:** the engine reaches 99% of the datapath peak once `N · BURST_LENGTH · bytes/beat` covers `bytes/beat · (BURST_LENGTH + L + 2)` (docs/06).

## Before an FPGA/ASIC build (not done here)

Replace the ring by an SRAM macro / BRAM with registered read; pipeline the validator; choose `CNT_W`; run real synthesis with timing constraints and the target libraries; constrain the guard and memory ports; run gate-level simulation of the bench.
