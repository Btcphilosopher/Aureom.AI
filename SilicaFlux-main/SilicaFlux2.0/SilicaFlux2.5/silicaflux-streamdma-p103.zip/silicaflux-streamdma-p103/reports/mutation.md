# Mutation testing

41 injected RTL bugs; **41 killed**, 0 survived, 0 invalid/unbuildable.
Each mutant is built into a scratch copy and run against `tb_<config> 1 all 60`; KILLED = the suite reported a failure (or hung).

| mutant | result | first symptom | what it models |
|---|---|---|---|
| align-strobe-no-lane-shift | KILLED | [FAIL @88] W data lane 1 nonzero with strobe 0 (stale data leak) | write strobes ignore the destination lane offset |
| align-data-no-lane-shift | KILLED | [FAIL @88] W data lane 0 nonzero with strobe 0 (stale data leak) | write data ignores the destination lane offset |
| align-insert-before-pop | KILLED | [FAIL @14322] DATA MISMATCH type 1 pa 40010: got 00 expected cb | bytes inserted at the pre-pop fill level (lost/duplicated bytes) |
| align-room-check | KILLED | [FAIL @88705] DATA MISMATCH type 4 pa 41020: got 00 expected f6 | accumulator overflow |
| read-first-beat-shift | KILLED | [FAIL @870] DATA MISMATCH type 1 pa 40000: got f9 expected 1a | source byte offset of the first beat ignored |
| read-mask-off-by-one | KILLED | [FAIL @128682] DATA MISMATCH type 1 pa 40562: got dd expected d4 | garbage lane leaks into the byte stream |
| read-last-beat-count | KILLED | [FAIL @70] perf BYTES_RD 16 != 1 | partial final beat treated as full |
| read-fill-index | KILLED | [FAIL @21542] run did not reach quiescence in 7248 cycles (got 0/1 completions, busy=1) | all beats of a burst land in one ring entry |
| read-rlast-fault-missing | KILLED | [FAIL @441800] AR id 0 reused while outstanding | bad RLAST not reported as a protocol error |
| read-bus-error-ignored | KILLED | [FAIL @303415] run did not reach quiescence in 17790 cycles (got 0/1 completions, busy=1) | read error response swallowed |
| read-address-bypasses-guard | KILLED | [FAIL @30] PROTECTION: AR [40000000,+1 beats) type 0 not granted to any trusted domain of this run | AR address formed from the descriptor, not the guard's grant |
| write-address-bypasses-guard | KILLED | [FAIL @38] PROTECTION: AW [50040000,+1 beats) type 1 not granted to any trusted domain of this run | AW address formed from the descriptor, not the guard's grant |
| write-bytes-ack-off-by-one | KILLED | [FAIL @70] cpl[0] status 1 != 0 (err 0x35 vs 0) | completion accounting |
| write-bus-error-ignored | KILLED | [FAIL @285788] cpl[0] err 0x35 != 0x31 | write error response swallowed (and counted as acknowledged) |
| write-b-ok-counts-error | KILLED | [FAIL @285758] COMPLETION CONTRACT: reported bytes_done 256 != 0 bytes acknowledged OKAY on the bus | errored write counted as acknowledged |
| write-spurious-b-ignored | KILLED | [FAIL @442273] cpl[0] status 0 != 1 (err 0 vs 0x32) | unmatched B response ignored |
| write-slot-never-freed | KILLED | [FAIL @6858] run did not reach quiescence in 6814 cycles (got 0/1 completions, busy=1) | B response does not free its slot |
| write-last-burst-never-ends | KILLED | [FAIL @6858] run did not reach quiescence in 6814 cycles (got 0/1 completions, busy=1) | transaction end never signalled |
| write-beat-last-wrong | KILLED | [FAIL @6858] run did not reach quiescence in 6814 cycles (got 0/1 completions, busy=1) | WLAST / burst length |
| plan-crosses-4k | KILLED | [FAIL @87031] cpl[0] status 1 != 0 (err 0x20 vs 0) | burst crosses a 4 KiB page |
| plan-extra-beat | KILLED | [FAIL @7608] run did not reach quiescence in 6814 cycles (got 0/1 completions, busy=1) | burst one beat too long |
| plan-ignores-burst-limit | KILLED | [FAIL @14700] AR burst 17 beats > BURST_LENGTH | BURST_LENGTH ignored |
| buffer-no-reservation-check | KILLED | [FAIL @218195] run did not reach quiescence in 76800 cycles (got 0/1 completions, busy=1) | ring overrun |
| buffer-valid-not-cleared | KILLED | [FAIL @15773] DATA MISMATCH type 1 pa 40400: got b9 expected ec | stale valid bit re-delivers data |
| desc-domain-unchecked | KILLED | [FAIL @294188] STRAY READ [0,+7 beats) type 0 outside every source envelope | descriptor may claim any domain |
| desc-overlap-unchecked | KILLED | [FAIL @294796] STRAY READ [3e0,+7 beats) type 0 outside every source envelope | overlapping copy accepted |
| desc-overflow-boundary | KILLED | [FAIL @295195] cpl[0] err 0xd != 0x20 | off-by-one at the top of the address space |
| desc-range-unchecked | KILLED | [FAIL @294658] cpl[0] err 0xd != 0xc | address >= 2^AW accepted |
| desc-version-unchecked | KILLED | [FAIL @294060] STRAY READ [0,+7 beats) type 0 outside every source envelope | wrong descriptor version accepted |
| desc-reserved-unchecked | KILLED | [FAIL @294348] STRAY READ [0,+7 beats) type 0 outside every source envelope | reserved bits accepted |
| desc-chain-txn-unchecked | KILLED | [FAIL @296191] STRAY READ [bb0,+16 beats) type 0 outside every source envelope | TXN_ID may change mid-transaction |
| desc-skip-never-ends | KILLED | [FAIL @350536] completion records: got 2 expected 3 | skip mode never resynchronises on LAST |
| desc-total-wrong | KILLED | [FAIL @70] cpl[0] status 1 != 0 (err 0x35 vs 0) | bytes_total accounting |
| cpl-completes-before-writes-ack | KILLED | [FAIL @66] cpl[0] status 1 != 0 (err 0x35 vs 0) | completion signalled before the destination acknowledged the writes |
| cpl-drain-ignores-outstanding | KILLED | [FAIL @303790] run did not reach quiescence in 17790 cycles (got 1/1 completions, busy=0) | error path flushes while requests are still on the bus |
| cpl-watchdog-dead | KILLED | [FAIL @430256] timeout mode 0: no completion within 4000 cycles | timeout never fires |
| cpl-kill-not-held-in-flush | KILLED | [FAIL @285658] perf RD_BURSTS 2 != bus 1 | work can start in the flush cycle (perf counters over-count) |
| read-hazard-disabled | KILLED | [FAIL @117732] DATA MISMATCH type 3 pa d843a: got 52 expected 46 | RAW/WAW interlock removed |
| read-hazard-quiesce-early | KILLED | [FAIL @174809] DATA MISMATCH type 3 pa 78f15: got ff expected c4 | interlock releases before earlier writes are acknowledged |
| read-id-not-matched | KILLED | [FAIL @25322] run did not reach quiescence in 10608 cycles (got 0/1 completions, busy=1) | R responses matched to slot 0 regardless of RID (assumes in-order) |
| top-soft-reset-not-deferred | KILLED | [FAIL @316893] guard protocol error event (stale guard response) | soft reset while a guard response is in flight |

Elapsed 201 s.
