# Lint report (Verilator 5.020, -Wall, third_party waived by rtl/lint.vlt only)

| configuration | warnings |
|---|---|
| default (128-bit, N=1/1) | 0 |
| DATA_WIDTH=32 BURST_LENGTH=64 FIFO_DEPTH=128 | 0 |
| DATA_WIDTH=64 N=3/2 (non power-of-two slots) | 0 |
| DATA_WIDTH=256 N=4/4 PLAN_DEPTH=2 | 0 |
| DATA_WIDTH=512 BURST_LENGTH=8 | 0 |
| ADDR_WIDTH=64 | 0 |
| ADDR_WIDTH=16 small limits | 0 |
| BURST_LENGTH=5 (non power of two) FIFO_DEPTH=8 | 0 |
| N=8/8 FIFO=256 | 0 |

## Negative elaboration tests (each must be rejected)

| illegal parameters | rejected |
|---|---|
| NUM_CHANNELS=2 | yes |
| DATA_WIDTH=48 | yes |
| DATA_WIDTH=16 | yes |
| DATA_WIDTH=1024 | yes |
| BURST_LENGTH=0 | yes |
| BURST_LENGTH=512 | yes |
| BURST_LENGTH*bytes > 4096 (DW=512 BL=128) | yes |
| FIFO_DEPTH=48 (not a power of two) | yes |
| FIFO_DEPTH < BURST_LENGTH | yes |
| WR_FIFO_DEPTH < BURST_LENGTH | yes |
| ADDR_WIDTH=8 | yes |
| MAX_OUTSTANDING_READS=0 | yes |
| DOM_W=0 | yes |

**All clean / all rejected as required.**
