# Regression report

7 configurations x 5 seeds = 35 bench runs, **ALL PASS**; 55265 directed + constrained-random descriptor streams, 75.5 M simulated cycles. Verilator 5.020, `--x-initial unique`, random register init per seed, random-regression length 300. Elapsed 145 s.

| config | seed | result | runs | failed | bus-monitor errors | cycles |
|---|---|---|---|---|---|---|
| initial | 1 | PASS | 1621 | 0 | 0 | 2178030 |
| initial | 2 | PASS | 1621 | 0 | 0 | 2181737 |
| initial | 3 | PASS | 1621 | 0 | 0 | 2078049 |
| initial | 4 | PASS | 1621 | 0 | 0 | 2315014 |
| initial | 5 | PASS | 1621 | 0 | 0 | 2340318 |
| par4 | 1 | PASS | 1621 | 0 | 0 | 1556740 |
| par4 | 2 | PASS | 1621 | 0 | 0 | 1472804 |
| par4 | 3 | PASS | 1621 | 0 | 0 | 1647627 |
| par4 | 4 | PASS | 1621 | 0 | 0 | 1543173 |
| par4 | 5 | PASS | 1621 | 0 | 0 | 1526176 |
| small | 1 | PASS | 1623 | 0 | 0 | 1029438 |
| small | 2 | PASS | 1623 | 0 | 0 | 1207634 |
| small | 3 | PASS | 1623 | 0 | 0 | 1119231 |
| small | 4 | PASS | 1623 | 0 | 0 | 1103140 |
| small | 5 | PASS | 1623 | 0 | 0 | 1178116 |
| dw64 | 1 | PASS | 1429 | 0 | 0 | 2828568 |
| dw64 | 2 | PASS | 1429 | 0 | 0 | 2870258 |
| dw64 | 3 | PASS | 1429 | 0 | 0 | 2970801 |
| dw64 | 4 | PASS | 1429 | 0 | 0 | 2996538 |
| dw64 | 5 | PASS | 1429 | 0 | 0 | 2981548 |
| dw256 | 1 | PASS | 1589 | 0 | 0 | 924894 |
| dw256 | 2 | PASS | 1589 | 0 | 0 | 925388 |
| dw256 | 3 | PASS | 1589 | 0 | 0 | 897656 |
| dw256 | 4 | PASS | 1589 | 0 | 0 | 904566 |
| dw256 | 5 | PASS | 1589 | 0 | 0 | 818199 |
| dw32 | 1 | PASS | 973 | 0 | 0 | 6111429 |
| dw32 | 2 | PASS | 973 | 0 | 0 | 5762537 |
| dw32 | 3 | PASS | 973 | 0 | 0 | 5744224 |
| dw32 | 4 | PASS | 973 | 0 | 0 | 5529931 |
| dw32 | 5 | PASS | 973 | 0 | 0 | 5496647 |
| dw512 | 1 | PASS | 2197 | 0 | 0 | 628060 |
| dw512 | 2 | PASS | 2197 | 0 | 0 | 626853 |
| dw512 | 3 | PASS | 2197 | 0 | 0 | 642771 |
| dw512 | 4 | PASS | 2197 | 0 | 0 | 685385 |
| dw512 | 5 | PASS | 2197 | 0 | 0 | 631513 |

## Test classes (summed over all configurations and seeds)

| test class | runs | failed |
|---|---|---|
| abort | 2100 | 0 |
| aw_waits_for_w | 105 | 0 |
| backpressure | 630 | 0 |
| bus_protocol_faults | 140 | 0 |
| completion_backpressure | 35 | 0 |
| descriptor_boundaries | 320 | 0 |
| full_width | 525 | 0 |
| hazards | 1120 | 0 |
| invalid_chains | 530 | 0 |
| invalid_descriptors | 945 | 0 |
| large | 490 | 0 |
| memory_faults | 1750 | 0 |
| multi_txn | 70 | 0 |
| protection | 700 | 0 |
| random_regression | 10500 | 0 |
| reorder_interleave | 630 | 0 |
| reset_cancel | 4200 | 0 |
| scatter_gather | 490 | 0 |
| single_byte | 10465 | 0 |
| timeout_fence | 455 | 0 |
| type_disable | 105 | 0 |
| unaligned | 18960 | 0 |

Each 'run' is one descriptor stream executed on the DUT and compared with the independent reference model: every destination byte, every byte's write count (lost / duplicated / stray bytes), every completion-record field, the bus-level completion contract and the performance counters; plus the per-cycle bus protocol, protection and domain monitors.
