# Synthesis report (Yosys 0.33, generic cells and Xilinx-7 mapping; no PDK, no place-and-route)

**Read this first.** Counts are complexity indicators. `ltp` is the longest topological path in gate/LUT levels -- a logic-depth indicator only, not a frequency: there is no cell library, wire model, placement or timing constraint. No FPGA or silicon was built.

## Top level (`sf_stream_dma`, flattened)

| config | ASIC-generic cells | flops | logic gates | memory bits | gate levels (ltp) | FPGA LUTs | FPGA FFs | LUTRAM/SRL/BRAM cells | LUT6 levels (abc -lut 6) |
|---|---|---|---|---|---|---|---|---|---|
| initial | 69565 | 18974 | 50591 | 0 | 120 | 9823 | 4272 | 158 | 26 |
| par4 | 72201 | 19649 | 52552 | 0 | 128 | 9943 | 4387 | 208 | 27 |
| dw256_par4 | 112249 | 32907 | 79342 | 0 | 120 | 14309 | 4779 | 277 | 26 |

## Per block (flattened, same flows)

| block | params | ASIC cells | flops | gate levels | FPGA LUTs | FPGA FFs | RAM cells | LUT6 levels |
|---|---|---|---|---|---|---|---|---|
| sf_stream_dma_plan | {'DW': 128, 'BL': 16, 'REM_W': 25} | 178 | 0 | 34 | 62 | 0 | 0 | 9 |
| sf_stream_dma_dcheck | {} | 1662 | 0 | 114 | 313 | 0 | 0 | 24 |
| sf_stream_dma_descriptor | {} | 2114 | 248 | 124 | 515 | 248 | 0 | 26 |
| sf_stream_dma_buffer | {'DW': 128, 'DEPTH': 64} | 26363 | 8602 | 30 | 267 | 90 | 45 | 7 |
| sf_stream_dma_align | {'DW': 128} | 4886 | 262 | 34 | 2499 | 262 | 0 | 8 |
| sf_stream_dma_read | {'NSLOT': 1, 'PLAN_DEPTH': 1} | 9569 | 1047 | 81 | 1898 | 1047 | 0 | 18 |
| sf_stream_dma_read | {'NSLOT': 4, 'PLAN_DEPTH': 2} | 10532 | 1357 | 82 | 2051 | 1179 | 17 | 18 |
| sf_stream_dma_write | {'NSLOT': 1, 'PLAN_DEPTH': 1} | 15931 | 5511 | 71 | 3072 | 871 | 25 | 16 |
| sf_stream_dma_write | {'NSLOT': 4, 'PLAN_DEPTH': 2} | 16953 | 5876 | 71 | 3131 | 854 | 58 | 16 |
| sf_stream_dma_cpl | {} | 1444 | 320 | 64 | 341 | 320 | 0 | 13 |
| sf_stream_dma_perf | {} | 15069 | 1664 | 81 | 3927 | 1664 | 0 | 17 |
