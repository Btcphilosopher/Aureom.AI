# Formal sensitivity (injected bugs the formal jobs must find)

| formal job | injected bug | result |
|---|---|---|
| plan_dw128_bl16 | burst may cross a 4 KiB page | CAUGHT |
| plan_dw128_bl16 | one beat too many | CAUGHT |
| dcheck_aw40 | destination overflow unchecked | CAUGHT |
| dcheck_aw40 | overlap check incomplete | CAUGHT |
| dcheck_aw40 | upper bits of the domain claim ignored | CAUGHT |
| align_dw32 | bytes inserted at the wrong offset | CAUGHT |
| align_dw32 | strobe ignores the lane offset | CAUGHT |
| align_dw32 | pop allowed with one byte missing | CAUGHT |
| buffer_d4 | valid bit not cleared on pop | CAUGHT |
| buffer_d4 | reservation may overrun the ring | CAUGHT |
| cpl | valid drops while the record is stalled | CAUGHT |
| cpl | completion self-check removed | CAUGHT |

12/12 caught.
