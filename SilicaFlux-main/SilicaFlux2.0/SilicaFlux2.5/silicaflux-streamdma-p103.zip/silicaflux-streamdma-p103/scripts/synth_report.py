#!/usr/bin/env python3
"""Synthesis report (Yosys 0.33, no PDK).  Two flows per block:
  asic-generic : synth -flatten; abc to a generic AND/OR/XOR/MUX gate set; flops/memories counted; `ltp` = longest topological
                 path in gate levels (a LOGIC-DEPTH indicator only: no wire load, no cell delay, NOT a frequency)
  fpga-xc7     : synth_xilinx (LUT6 / FDRE / LUTRAM / BRAM mapping) -- resource counts, logic levels
Memories: the generic flow has no RAM macro, so memories are mapped to flip-flops (this is what an ASIC flow without an SRAM
compiler would do); synth_xilinx infers distributed RAM / BRAM.
usage: synth_report.py [--quick] [--report reports/synth.md]"""
import argparse, os, re, subprocess, sys, time, json
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = ["third_party/p61-clouddpu/rtl/sfd_fifo.sv", "third_party/clouddma-p64/rtl/silicaflux_dma_pkg.sv", "third_party/clouddma-p64/rtl/sfdma_perm_checker.sv"] + \
      ["rtl/stream_dma/sf_stream_dma_%s.sv" % n for n in ("plan","dcheck","queue","descriptor","buffer","align","read","write","cpl","perf")] + ["rtl/stream_dma/sf_stream_dma.sv"]

def ys(script):
    r = subprocess.run(["yosys", "-q", "-l", "/dev/stdout", "-p", script], cwd=ROOT, capture_output=True, text=True, timeout=3000)
    return r.stdout + r.stderr

def parse_stat(txt):
    # take the LAST statistics block
    blk = txt.split("Printing statistics.")[-1]
    cells = {}
    for m in re.finditer(r"^\s+(\$?[A-Za-z_0-9\\$]+)\s+(\d+)\s*$", blk, re.M):
        cells[m.group(1)] = int(m.group(2))
    tot = re.search(r"Number of cells:\s+(\d+)", blk) or re.search(r"^\s+(\d+)\s+cells", blk, re.M)
    mem = re.search(r"Number of memory bits:\s+(\d+)", blk)
    return cells, int(tot.group(1)) if tot else sum(cells.values()), int(mem.group(1)) if mem else 0

def ltp(txt):
    m = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", txt)
    return int(m.group(1)) if m else None

def run_block(top, params, extra_src=None):
    rd = "read_verilog -sv -I rtl/stream_dma " + " ".join(SRC)
    cp = "; ".join(f"chparam -set {k} {v} {top}" for k, v in params.items())
    out = {}
    t0 = time.time()
    a = ys(f"{rd}; {cp}; hierarchy -check -top {top}; synth -flatten -top {top}; abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX; opt_clean; ltp -noff; stat")
    cells, tot, mem = parse_stat(a)
    dffs = sum(v for k, v in cells.items() if "DFF" in k or "DLATCH" in k)
    out["asic"] = {"cells": tot, "ff": dffs, "logic": tot - dffs, "mem_bits": mem, "ltp": ltp(a)}
    l6 = ys(f"{rd}; {cp}; hierarchy -check -top {top}; synth -flatten -top {top}; abc -lut 6; opt_clean; ltp -noff; stat")
    out["lut6_levels"] = ltp(l6)
    f = ys(f"{rd}; {cp}; hierarchy -check -top {top}; synth_xilinx -family xc7 -flatten -top {top}; stat")
    cells, tot, mem = parse_stat(f)
    lut = sum(v for k, v in cells.items() if k.startswith("LUT"))
    ff = sum(v for k, v in cells.items() if k.startswith("FD"))
    ram = sum(v for k, v in cells.items() if k.startswith("RAM") or k.startswith("RAMB") or k.startswith("SRL"))
    out["fpga"] = {"lut": lut, "ff": ff, "ram": ram, "carry": sum(v for k, v in cells.items() if k.startswith("CARRY")), "muxf": sum(v for k, v in cells.items() if k.startswith("MUXF")), "ltp": None,
                   "ram_cells": {k: v for k, v in cells.items() if k.startswith("RAM") or k.startswith("SRL")}}
    out["sec"] = time.time() - t0
    return out

CFG = {
  "initial": dict(DATA_WIDTH=128, ADDR_WIDTH=40, BURST_LENGTH=16, FIFO_DEPTH=64, MAX_OUTSTANDING_READS=1, MAX_OUTSTANDING_WRITES=1, PLAN_DEPTH=1, SEG_DEPTH=2, WR_FIFO_DEPTH=32),
  "par4":    dict(DATA_WIDTH=128, ADDR_WIDTH=40, BURST_LENGTH=16, FIFO_DEPTH=64, MAX_OUTSTANDING_READS=4, MAX_OUTSTANDING_WRITES=4, PLAN_DEPTH=2, SEG_DEPTH=2, WR_FIFO_DEPTH=32),
  "dw256_par4": dict(DATA_WIDTH=256, ADDR_WIDTH=40, BURST_LENGTH=16, FIFO_DEPTH=64, MAX_OUTSTANDING_READS=4, MAX_OUTSTANDING_WRITES=4, PLAN_DEPTH=2, SEG_DEPTH=2, WR_FIFO_DEPTH=32),
}
BLOCKS = [("sf_stream_dma_plan", {"DW": 128, "BL": 16, "REM_W": 25}), ("sf_stream_dma_dcheck", {}), ("sf_stream_dma_descriptor", {}),
          ("sf_stream_dma_buffer", {"DW": 128, "DEPTH": 64}), ("sf_stream_dma_align", {"DW": 128}),
          ("sf_stream_dma_read", {"NSLOT": 1, "PLAN_DEPTH": 1}), ("sf_stream_dma_read", {"NSLOT": 4, "PLAN_DEPTH": 2}),
          ("sf_stream_dma_write", {"NSLOT": 1, "PLAN_DEPTH": 1}), ("sf_stream_dma_write", {"NSLOT": 4, "PLAN_DEPTH": 2}),
          ("sf_stream_dma_cpl", {}), ("sf_stream_dma_perf", {})]

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--quick", action="store_true"); ap.add_argument("--report", default="reports/synth.md"); a = ap.parse_args()
    res = {"top": {}, "blocks": []}
    for name, p in CFG.items():
        if a.quick and name != "initial": continue
        print("synth top", name, flush=True); res["top"][name] = run_block("sf_stream_dma", p); print(json.dumps(res["top"][name]), flush=True)
    if not a.quick:
        for b, p in BLOCKS:
            print("synth block", b, p, flush=True); r = run_block(b, p); res["blocks"].append((b, p, r)); print(json.dumps(r), flush=True)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "synth.json"), "w"), indent=1)
    with open(os.path.join(ROOT, a.report), "w") as f:
        f.write("# Synthesis report (Yosys 0.33, generic cells and Xilinx-7 mapping; no PDK, no place-and-route)\n\n"
                "**Read this first.** Counts are complexity indicators. `ltp` is the longest topological path in gate/LUT levels -- a logic-depth indicator only, "
                "not a frequency: there is no cell library, wire model, placement or timing constraint. No FPGA or silicon was built.\n\n"
                "## Top level (`sf_stream_dma`, flattened)\n\n| config | ASIC-generic cells | flops | logic gates | memory bits | gate levels (ltp) | FPGA LUTs | FPGA FFs | LUTRAM/SRL/BRAM cells | LUT6 levels (abc -lut 6) |\n|---|---|---|---|---|---|---|---|---|---|\n")
        for n, r in res["top"].items():
            A, F = r["asic"], r["fpga"]
            f.write(f"| {n} | {A['cells']} | {A['ff']} | {A['logic']} | {A['mem_bits']} | {A['ltp']} | {F['lut']} | {F['ff']} | {F['ram']} | {r['lut6_levels']} |\n")
        if res["blocks"]:
            f.write("\n## Per block (flattened, same flows)\n\n| block | params | ASIC cells | flops | gate levels | FPGA LUTs | FPGA FFs | RAM cells | LUT6 levels |\n|---|---|---|---|---|---|---|---|---|\n")
            for b, p, r in res["blocks"]:
                A, F = r["asic"], r["fpga"]
                f.write(f"| {b} | {p} | {A['cells']} | {A['ff']} | {A['ltp']} | {F['lut']} | {F['ff']} | {F['ram']} | {r['lut6_levels']} |\n")
