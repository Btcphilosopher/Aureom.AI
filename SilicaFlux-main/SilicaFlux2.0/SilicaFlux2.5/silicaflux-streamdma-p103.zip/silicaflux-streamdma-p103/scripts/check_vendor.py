#!/usr/bin/env python3
"""Verify that every vendored file in third_party/ is byte-identical to the SHA-256 recorded in third_party/MANIFEST.tsv.
With --archive <silicaflux-clouddma-p64.zip>, additionally compare the CloudDMA members against the archive itself."""
import hashlib, os, sys, zipfile
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
bad = 0
for line in open(os.path.join(root, "third_party", "MANIFEST.tsv")):
    if line.startswith("#") or not line.strip(): continue
    path, member, _src, sha = line.rstrip("\n").split("\t")
    h = hashlib.sha256(open(os.path.join(root, "third_party", path), "rb").read()).hexdigest()
    ok = (h == sha); bad += (not ok)
    print(("OK  " if ok else "BAD ") + path)
if "--archive" in sys.argv:
    z = zipfile.ZipFile(sys.argv[sys.argv.index("--archive") + 1])
    for line in open(os.path.join(root, "third_party", "MANIFEST.tsv")):
        if line.startswith("#") or not line.strip(): continue
        path, member, _src, sha = line.rstrip("\n").split("\t")
        if path.startswith("clouddma-p64/"):
            h = hashlib.sha256(z.read(member)).hexdigest(); ok = (h == sha); bad += (not ok)
            print(("OK  " if ok else "BAD ") + "archive:" + member)
sys.exit(1 if bad else 0)
