#!/bin/bash
# Verilator -Wall lint of sf_stream_dma in several parameterisations (must be warning-free) plus negative elaboration tests
# (illegal parameter combinations must be REJECTED).  Writes reports/lint.md.
cd "$(dirname "$0")/.."
mkdir -p reports; OUT=reports/lint.md
{ echo "# Lint report (Verilator $(verilator --version | cut -d' ' -f2), -Wall, third_party waived by rtl/lint.vlt only)"; echo; echo "| configuration | warnings |"; echo "|---|---|"; } > $OUT
fail=0
lint() { # name, params...
  name="$1"; shift; G=""; for p in "$@"; do G="$G -G$p"; done
  n=$(verilator --lint-only -Wall -Irtl/stream_dma rtl/lint.vlt -f rtl/filelist.f --top-module sf_stream_dma $G 2>&1 | grep -c '^%Warning\|^%Error')
  echo "| $name | $n |" >> $OUT; [ "$n" = 0 ] || fail=1
}
lint "default (128-bit, N=1/1)"
lint "DATA_WIDTH=32 BURST_LENGTH=64 FIFO_DEPTH=128" DATA_WIDTH=32 BURST_LENGTH=64 FIFO_DEPTH=128
lint "DATA_WIDTH=64 N=3/2 (non power-of-two slots)" DATA_WIDTH=64 MAX_OUTSTANDING_READS=3 MAX_OUTSTANDING_WRITES=2
lint "DATA_WIDTH=256 N=4/4 PLAN_DEPTH=2" DATA_WIDTH=256 MAX_OUTSTANDING_READS=4 MAX_OUTSTANDING_WRITES=4 PLAN_DEPTH=2
lint "DATA_WIDTH=512 BURST_LENGTH=8" DATA_WIDTH=512 BURST_LENGTH=8 FIFO_DEPTH=32
lint "ADDR_WIDTH=64" ADDR_WIDTH=64
lint "ADDR_WIDTH=16 small limits" ADDR_WIDTH=16 MAX_SEG_LOG2=10 MAX_TXN_LOG2=12
lint "BURST_LENGTH=5 (non power of two) FIFO_DEPTH=8" BURST_LENGTH=5 FIFO_DEPTH=8
lint "N=8/8 FIFO=256" MAX_OUTSTANDING_READS=8 MAX_OUTSTANDING_WRITES=8 FIFO_DEPTH=256 WR_FIFO_DEPTH=64
echo >> $OUT; echo "## Negative elaboration tests (each must be rejected)" >> $OUT; echo >> $OUT; echo "| illegal parameters | rejected |" >> $OUT; echo "|---|---|" >> $OUT
neg() { name="$1"; shift; G=""; for p in "$@"; do G="$G -G$p"; done
  if verilator --lint-only -Irtl/stream_dma rtl/lint.vlt -f rtl/filelist.f --top-module sf_stream_dma $G >/dev/null 2>&1; then echo "| $name | **NO (accepted!)** |" >> $OUT; fail=1; else echo "| $name | yes |" >> $OUT; fi; }
neg "NUM_CHANNELS=2" NUM_CHANNELS=2
neg "DATA_WIDTH=48" DATA_WIDTH=48
neg "DATA_WIDTH=16" DATA_WIDTH=16
neg "DATA_WIDTH=1024" DATA_WIDTH=1024
neg "BURST_LENGTH=0" BURST_LENGTH=0
neg "BURST_LENGTH=512" BURST_LENGTH=512
neg "BURST_LENGTH*bytes > 4096 (DW=512 BL=128)" DATA_WIDTH=512 BURST_LENGTH=128 FIFO_DEPTH=128 WR_FIFO_DEPTH=128
neg "FIFO_DEPTH=48 (not a power of two)" FIFO_DEPTH=48
neg "FIFO_DEPTH < BURST_LENGTH" BURST_LENGTH=32 FIFO_DEPTH=16
neg "WR_FIFO_DEPTH < BURST_LENGTH" WR_FIFO_DEPTH=8
neg "ADDR_WIDTH=8" ADDR_WIDTH=8
neg "MAX_OUTSTANDING_READS=0" MAX_OUTSTANDING_READS=0
neg "DOM_W=0" DOM_W=0
echo >> $OUT; [ $fail = 0 ] && echo "**All clean / all rejected as required.**" >> $OUT || echo "**FAILURES - see rows above.**" >> $OUT
cat $OUT; exit $fail
