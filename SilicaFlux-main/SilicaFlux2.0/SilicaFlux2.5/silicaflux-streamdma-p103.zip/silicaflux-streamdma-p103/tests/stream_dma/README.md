# tests/stream_dma — Verilator system bench

```
bash scripts/build_tb.sh <config>            # configs: tests/stream_dma/configs.sh  (initial par4 small dw64 dw256 dw32 dw512 + benchmark configs)
build/tb_<config>/tb_<config> [seed] [test|all|bench] [random-runs] [+verilator+rand+reset+2 +verilator+seed+N]
TB_TRACE=1 ...   print every AR / AW / R / B / completion handshake
TB_FAILFAST=1 .. exit at the first failing run (used by the mutation harness)
```
Files: `tb_top.sv` (DUT + vendored permission table as MemoryGuard model), `tb_core.h` (AXI slave model, monitors), `tb_ref.h` (independent reference model, run/check),
`tb_main.cpp` (tests), `tb_bench.h` (benchmark mode). See docs/05_VERIFICATION.md.
