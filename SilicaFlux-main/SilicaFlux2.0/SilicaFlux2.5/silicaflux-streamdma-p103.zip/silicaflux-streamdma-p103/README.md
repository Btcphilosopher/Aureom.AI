# SilicaFlux StreamDMA — Project 103

A high-throughput, synthesizable, **protected scatter-gather DMA engine** (`sf_stream_dma`): descriptor queue → descriptor validator → MemoryGuard → read request engine →
data buffer → write request engine → completion engine, on an AXI4-style ready/valid memory port with IDs, bursts and explicit byte strobes.

**Scope of this release (as briefed: "first one fully verified channel, then parallel outstanding requests"):** one DMA channel (`NUM_CHANNELS` must be 1), one transaction in flight,
`MAX_OUTSTANDING_READS/WRITES` parameterised (initial configuration 1/1, verified up to 8/8), 128-bit initial datapath (32..512 supported).
**Evidence level: simulation + formal on RTL, plus Yosys synthesis estimates. No FPGA, no silicon, no timing closure; no frequency, power or µm² figure is claimed.** Read `docs/08_LIMITATIONS.md` first.

## Deliverables

| Brief | Where |
|---|---|
| `sf_stream_dma.sv` (+ `_descriptor`, `_read`, `_write`, `_queue`, `_perf`) | `rtl/stream_dma/` — plus helpers `_dcheck`, `_plan`, `_buffer`, `_align`, `_cpl`, `_defs.svh` (file list: `rtl/filelist.f`) |
| `tests/stream_dma/` | Verilator C++ bench, AXI slave model, monitors, **independent byte-accurate reference model** |
| `formal/stream_dma/` | Yosys / Z3 / Yosys-SAT harnesses and runners |
| `benchmarks/stream_dma/` | workloads, raw counter data (`results.csv`), analysis (`REPORT.md`) |
| docs | `docs/00_AUDIT … 09_INTEGRATION` |
| evidence | `reports/` (regression, formal, formal sensitivity, mutation, lint, synthesis, tools) |
| reused, byte-identical | `third_party/` (SHA-256 manifest, `scripts/check_vendor.py`) |

## Results (all reproducible with `make all`)

| Item | Result |
|---|---|
| Regression | 7 configurations × 5 seeds, **all pass**: 55 265 descriptor streams, 75.5 M simulated cycles, every byte / write count / completion field compared with the reference model, plus per-cycle protocol, protection and stray-access monitors (`reports/regression.md`) |
| Mutation testing | **41 / 41 injected RTL bugs detected** (`reports/mutation.md`; early survivors exposed two real bench gaps, both closed — docs/05 §4) |
| Formal | planner and descriptor checker **proved exhaustively**; byte realigner, ring buffer and completion engine **bounded** (BMC); 12 / 12 jobs pass and the harnesses find the injected bugs (`reports/formal.md`, `formal_mutants.md`) |
| Lint | Verilator `-Wall` clean in 9 parameterisations; 13 illegal parameter sets are rejected at elaboration (`reports/lint.md`) |
| Throughput (simulation) | 128 KiB copy, 128-bit: **Phase 1** (1 outstanding) 12.8 / 9.1 / 5.3 / 2.6 B/cycle at memory latency 2 / 10 / 30 / 80; **Phase 2** (2–8 outstanding) 15.9 B/cycle = **99% of the 16 B/cycle datapath peak**; matches the bandwidth-delay formula within ~2%. Small (64 B) transactions: ≈ 1.4 B/cycle — limited by the one-transaction-in-flight contract (`benchmarks/stream_dma/REPORT.md`) |
| Synthesis (Yosys, no PDK) | see `reports/synth.md` and `docs/07_SYNTHESIS.md` |

## What the design guarantees (and where it is checked)

* **Byte accuracy under backpressure and contention:** unaligned source/destination, partial first/last beats with explicit strobes, ≥ 2 outstanding bursts, reordered and interleaved read responses (matched by ID), reordered write responses.
* **Completion only after the destination accepted the writes:** `status OK` only when every issued write burst was answered `OKAY` and `bytes_done == bytes_total`; checked against the bus itself (docs/04).
* **Protection:** every AR/AW address is the physical address granted by the MemoryGuard for that burst; the trusted domain is a hardware sideband captured at push, never a descriptor field; descriptors are validated against overflow, range, overlap, flags, versions, chain structure (docs/02, docs/03).
* **No silent corruption of overlaps:** overlapping copies inside a segment are rejected (no memmove); cross-segment read-after-write / write-after-write are interlocked.
* **Faults, abort, timeout, reset:** error status with partial-completion accounting, drain-then-flush, watchdog + fence, deferred soft reset that cannot leak a stale guard answer, hard-reset cancellation (docs/04).

## Reuse (docs/00_AUDIT.md)

Vendored unchanged from CloudDMA P64 / CloudDPU P61: `sfd_fifo` (all queues), `sfdma_perm_checker` (MemoryGuard front end), `sfdma_perm_table` (bench's MemoryGuard model), `silicaflux_dma_pkg`.
**No module named MemoryGuard or MemoryMatrix exists in the repository**; the MemoryGuard interface is defined here as the verified IOMMU contract of the P64 checker. SRAMController, MeridianQoS, TensorCore, Vector Engine, DataFabric
were audited but are **not integrated** (reasons in the audit).

## Quick start

```bash
make check-vendor lint          # vendored files intact, lint clean
bash scripts/build_tb.sh initial && build/tb_initial/tb_initial 1 all     # the initial configuration
make regress formal mutate bench synth                                    # full evidence (synth is slow)
```
Tools: Verilator 5.020, Yosys 0.33, Z3 4.8, Python 3, g++, make (`reports/tools.txt`).

## Known limits (summary of docs/08)

One channel, one transaction in flight; no memmove; no rollback; data buffer is register-file style (SRAM macro needed for ASIC); partial formal coverage; the guard, memory and reference model are models written for this project;
platform requirements for isolation are listed in `docs/09_INTEGRATION.md` (injective mappings, single path to memory, quiesce before unmapping, fabric reset with `soft_reset_active`).
