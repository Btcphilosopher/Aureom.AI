#!/usr/bin/env python3
"""Formal sensitivity check: inject a known RTL bug into a scratch copy and require the matching formal job to FAIL (find a counterexample).
A proof that cannot fail proves nothing; this shows each harness can.  usage: formal_mutants.py [--report reports/formal_mutants.md]"""
import os, shutil, sys, tempfile, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_formal as rf
ROOT = rf.ROOT
R = "rtl/stream_dma/"
# (formal job name, rtl file, old, new, description)
MUT = [
 ("plan_dw128_bl16", R+"sf_stream_dma_plan.sv", "lim_pg   = 14'd4096 - 14'(addr_lo);", "lim_pg   = 14'd4097 - 14'(addr_lo);", "burst may cross a 4 KiB page"),
 ("plan_dw128_bl16", R+"sf_stream_dma_plan.sv", "nbeats   = 9'((sum + 14'(W - 1)) >> LW);", "nbeats   = 9'((sum + 14'(W)) >> LW);", "one beat too many"),
 ("dcheck_aw40", R+"sf_stream_dma_dcheck.sv", "wire         ovf_bad  = (s_end > lim_a) || (d_end > lim_a);", "wire         ovf_bad  = (s_end > lim_a);", "destination overflow unchecked"),
 ("dcheck_aw40", R+"sf_stream_dma_dcheck.sv", "wire         ovl_bad  = (s_type == d_type) && ({64'd0, src} < d_end) && ({64'd0, dst} < s_end);", "wire         ovl_bad  = (s_type == d_type) && ({64'd0, src} < d_end);", "overlap check incomplete"),
 ("dcheck_aw40", R+"sf_stream_dma_dcheck.sv", "wire dom_bad   = (dom_cl != 16'(trusted_domain));", "wire dom_bad   = (dom_cl[DOM_W-1:0] != trusted_domain);", "upper bits of the domain claim ignored"),
 ("align_dw32", R+"sf_stream_dma_align.sv", "<< (8 * 32'(cnt_p));", "<< (8 * 32'(cnt));", "bytes inserted at the wrong offset"),
 ("align_dw32", R+"sf_stream_dma_align.sv", "assign out_strb = nmask << pop_lo;", "assign out_strb = nmask;", "strobe ignores the lane offset"),
 ("align_dw32", R+"sf_stream_dma_align.sv", "assign pop_ok   = (cnt >= CW'(pop_n)) && (pop_n != '0);", "assign pop_ok   = (cnt + CW'(1) >= CW'(pop_n)) && (pop_n != '0);", "pop allowed with one byte missing"),
 ("buffer_d4", R+"sf_stream_dma_buffer.sv", "if (pop)        vld[rp] <= 1'b0;", "", "valid bit not cleared on pop"),
 ("buffer_d4", R+"sf_stream_dma_buffer.sv", "assign rsv_ok   = ((16'(rsv) + 16'(rsv_n)) <= 16'(DEPTH));", "assign rsv_ok   = ((16'(rsv) + 16'(rsv_n)) <= 16'(DEPTH) + 16'd1);", "reservation may overrun the ring"),
 ("cpl", R+"sf_stream_dma_cpl.sv", "assign cpl_valid = (st == ST_CPL) && rec_en;", "assign cpl_valid = (st == ST_CPL) && rec_en && (now[3:0] != 4'd7);", "valid drops while the record is stalled"),
 ("cpl", R+"sf_stream_dma_cpl.sv", "wire sum_ok   = end_is_err || (acked_bytes == end_total);", "wire sum_ok   = 1'b1;", "completion self-check removed"),
]
if __name__ == "__main__":
    out = os.path.join(ROOT, "build", "formal_mut"); shutil.rmtree(out, ignore_errors=True)
    jobs = {j[0]: j for j in rf.JOBS}; rows = []; allok = True
    for (jn, f, old, new, why) in MUT:
        tmp = tempfile.mkdtemp(prefix="sfsd_fm_")
        shutil.copytree(ROOT, tmp + "/p", ignore=shutil.ignore_patterns("build", "reports", "*.zip", ".git", "benchmarks"))
        p = os.path.join(tmp, "p", f); src = open(p).read()
        if old not in src: rows.append((jn, why, "BAD-MUTANT")); allok = False; continue
        open(p, "w").write(src.replace(old, new, 1))
        r = rf.run(jobs[jn], out, cwd=os.path.join(tmp, "p"), tmo=300)
        res = "CAUGHT" if r[1] == "FAIL" else ("MISSED" if r[1] == "PASS" else r[1])
        allok &= (res == "CAUGHT"); rows.append((jn, why, res)); print(f"{res:8s} {jn:16s} {why}", flush=True)
        shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, "reports", "formal_mutants.md"), "w") as fo:
        fo.write("# Formal sensitivity (injected bugs the formal jobs must find)\n\n| formal job | injected bug | result |\n|---|---|---|\n")
        for r in rows: fo.write(f"| {r[0]} | {r[1]} | {r[2]} |\n")
        fo.write(f"\n{sum(1 for r in rows if r[2]=='CAUGHT')}/{len(rows)} caught.\n")
    sys.exit(0 if allok else 1)
