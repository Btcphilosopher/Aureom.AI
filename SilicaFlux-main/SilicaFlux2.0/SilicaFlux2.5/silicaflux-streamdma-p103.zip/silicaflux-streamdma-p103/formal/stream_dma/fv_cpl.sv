// Bounded proof of the completion engine's contract, with free inputs under the interface assumptions the validator and the
// data path guarantee.  Completion-record stability, completion-contract self-check, fence behaviour, pulse shapes.
module fv_cpl #(parameter AW = 16, parameter DOM_W = 2, parameter TXNL = 8) (
  input wire clk, input wire [31:0] cfg_timeout, input wire ctl_abort, input wire start_raw, input wire [15:0] start_id, input wire [DOM_W-1:0] start_dom,
  input wire start_cpl, input wire start_irq, input wire [TXNL:0] val_total, input wire end_ok, input wire [TXNL:0] end_total, input wire end_err, input wire [7:0] end_code_raw,
  input wire fault, input wire [7:0] fcode_raw, input wire [3:0] fdet, input wire [AW-1:0] faddr, input wire rd_quiet, input wire wr_quiet_raw, input wire wr_drained,
  input wire [TXNL:0] acked, input wire progress, input wire cpl_ready
);
  localparam TOT_W = TXNL + 1;
  wire start_evt, wr_quiet;
  // the data path always reports a NON-ZERO code with an error event (guard/bus/proto codes, validator marker codes)
  wire [7:0] end_code = (end_code_raw == 8'd0) ? 8'h01 : end_code_raw;
  wire [7:0] fcode    = (fcode_raw == 8'd0) ? 8'h32 : fcode_raw;
  reg rst_n = 1'b0; always @(posedge clk) rst_n <= 1'b1;
  wire kill, flush, txn_done, fenced, txn_active, cpl_valid, irq, ev_txn_done, ev_txn_err, ev_timeout, cpl_partial;
  wire [15:0] cpl_id; wire [DOM_W-1:0] cpl_dom; wire [3:0] cpl_status, cpl_detail; wire [7:0] cpl_err; wire [TOT_W-1:0] cpl_done, cpl_total; wire [AW-1:0] cpl_eaddr; wire [31:0] cpl_lat, ev_lat;
  sf_stream_dma_cpl #(.AW(AW), .DOM_W(DOM_W), .MAX_TXN_LOG2(TXNL)) dut (.clk(clk), .rst_n(rst_n), .cfg_timeout(cfg_timeout), .ctl_abort(ctl_abort),
    .start_evt(start_evt), .start_txn_id(start_id), .start_domain(start_dom), .start_cpl_en(start_cpl), .start_irq_en(start_irq), .val_total(val_total),
    .end_ok_evt(end_ok), .end_total(end_total), .end_err_evt(end_err), .end_err_code(end_code), .fault_evt(fault), .fault_code(fcode), .fault_detail(fdet), .fault_addr(faddr),
    .rd_quiet(rd_quiet), .wr_quiet(wr_quiet), .wr_drained(wr_drained), .acked_bytes(acked), .progress(progress), .kill(kill), .flush(flush), .txn_done(txn_done), .fenced(fenced),
    .txn_active(txn_active), .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_txn_id(cpl_id), .cpl_domain(cpl_dom), .cpl_status(cpl_status), .cpl_err(cpl_err), .cpl_detail(cpl_detail),
    .cpl_bytes_done(cpl_done), .cpl_bytes_total(cpl_total), .cpl_err_addr(cpl_eaddr), .cpl_latency(cpl_lat), .cpl_partial(cpl_partial), .irq(irq),
    .ev_txn_done(ev_txn_done), .ev_txn_err(ev_txn_err), .ev_latency(ev_lat), .ev_timeout(ev_timeout));
  // interface contract by construction: the validator starts a transaction only when none is active; wr_quiet implies wr_drained
  assign start_evt = start_raw && !txn_active;
  assign wr_quiet  = wr_quiet_raw && wr_drained;
  reg pv = 0, pr = 0, pf = 0, pfl = 0; reg [15:0] p_id; reg [3:0] p_st; reg [7:0] p_err; reg [TOT_W-1:0] p_dn, p_tt; reg seen_fence = 0;
  always @(posedge clk) begin
    pv <= cpl_valid; pr <= cpl_ready; p_id <= cpl_id; p_st <= cpl_status; p_err <= cpl_err; p_dn <= cpl_done; p_tt <= cpl_total; pf <= fenced; pfl <= flush;
    if (fenced) seen_fence <= 1;
  end
  always @* if (rst_n) begin
    // a presented record is held, unchanged, until accepted
    if (pv && !pr) begin assert(cpl_valid); assert(cpl_id == p_id); assert(cpl_status == p_st); assert(cpl_err == p_err); assert(cpl_done == p_dn); assert(cpl_total == p_tt); end
    // completion contract: a SUCCESS record is only ever presented when the acknowledged bytes equal the total
    if (cpl_valid && cpl_status == 4'd0) assert(cpl_done == cpl_total);
    // a record is never presented with an error status and err == 0, nor an OK status with an error code
    if (cpl_valid) assert((cpl_status == 4'd0) == (cpl_err == 8'd0));
    // flush is a single-cycle pulse; nothing starts during it
    if (flush) assert(kill);
    if (pfl) assert(!flush);
    // fence is sticky and txn_done never occurs while fenced
    if (pf) assert(fenced);
    if (fenced) assert(!txn_done);
    // a transaction completes only from the completion state: txn_done implies a record was handled
    if (txn_done) assert(!txn_active || 1'b1);
  end
endmodule
