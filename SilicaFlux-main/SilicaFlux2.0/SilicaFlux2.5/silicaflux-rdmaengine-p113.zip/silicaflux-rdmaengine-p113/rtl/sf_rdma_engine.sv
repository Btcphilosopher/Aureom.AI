// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_engine   (PRIMARY RTL)
//
// A synthesizable remote-memory operation engine for SilicaFlux cloud / HPC systems: ONE reliable-connected queue pair, SEND /
// RDMA WRITE / RDMA READ, protected memory regions with keys and protection domains, in-order completion, sequence numbers,
// acknowledgement, timeout / retry, duplicate suppression, bounded queues with back-pressure and CQ credit accounting, and
// performance counters.  The internal protocol is SFRT v1 (docs/TRANSPORT_SPEC.md) carried over a PacketCore-compatible AXI-S
// frame stream.
//
// *** THIS IS NOT A RoCEv2 / INFINIBAND / iWARP STACK AND DOES NOT INTEROPERATE WITH THEM. ***
//
//   Work Queue -> Queue Pair controller -> Memory-registration check -> Data movement -> Transport adapter -> remote endpoint
//   Transport adapter -> packet / operation validation -> memory protection -> local DMA -> response / completion
//
// Trusted configuration (`cfg_*`) is the ONLY way to program memory regions and QP state.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none

module sf_rdma_engine #(
  parameter int DW            = 64,           // stream and memory data width: 32 / 64 / 128
  parameter int PA_W          = 32,           // physical address width (>= 32)
  parameter int MTU           = 256,          // payload bytes per frame (power of two, >= DW/8)
  parameter int NMR           = 8,            // memory regions
  parameter int PD_W          = 4,
  parameter int CTX_W         = 2,
  parameter int SQ_DEPTH      = 8,
  parameter int RQ_DEPTH      = 8,
  parameter int CQ_DEPTH      = 32,           // >= SQ_DEPTH + RQ_DEPTH recommended
  parameter int WINDOW        = 8,            // outstanding request PSNs (power of two)
  parameter int MAX_RD        = 2,            // outstanding READ requests
  parameter int MEM_RD_OUT    = 4,            // outstanding memory read words
  parameter int MEM_WR_OUT    = 4,            // outstanding memory write words
  parameter int PAGE_BYTES    = 4096,
  parameter int MAX_MSG_BYTES = 1048576,
  parameter int ACCEPT_ACK_DELAY = 64,
  localparam int B            = DW/8,
  localparam int RID_W        = (NMR > 1) ? $clog2(NMR) : 1,
  localparam int NCTX         = (1 << CTX_W)
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // ---- trusted configuration ------------------------------------------------------------------------------------------------------
  input  wire logic                 cfg_valid,
  output logic                      cfg_ready,
  input  wire logic [3:0]           cfg_cmd,           // 1 MR_SET, 2 MR_INVAL, 3 QP_MODIFY, 4 CTX_SET
  input  wire logic [RID_W-1:0]     cfg_idx,
  input  wire logic [63:0]          cfg_va,
  input  wire logic [31:0]          cfg_len,
  input  wire logic [PA_W-1:0]      cfg_pa,
  input  wire logic [31:0]          cfg_key,
  input  wire logic [PD_W-1:0]      cfg_pd,
  input  wire logic [7:0]           cfg_acc,
  input  wire logic [CTX_W-1:0]     cfg_ctx,
  input  wire logic [NCTX-1:0]      cfg_ctx_mask,
  input  wire logic [2:0]           cfg_qp_state,
  input  wire logic [15:0]          cfg_qpn,
  input  wire logic [15:0]          cfg_rqpn,
  input  wire logic [15:0]          cfg_epoch,
  input  wire logic [23:0]          cfg_rq_psn,
  input  wire logic [47:0]          cfg_lmac,
  input  wire logic [47:0]          cfg_pmac,
  input  wire logic [23:0]          cfg_sq_psn,
  input  wire logic [31:0]          cfg_timeout,
  input  wire logic [3:0]           cfg_retry,
  input  wire logic [3:0]           cfg_rnr_retry,
  input  wire logic [31:0]          cfg_rnr_delay,
  output logic                      cfg_rsp_valid,
  output logic [3:0]                cfg_rsp_status,
  output logic [2:0]                qp_state,
  output logic [3:0]                qp_err_cause,
  // ---- send queue post ---------------------------------------------------------------------------------------------------------------
  input  wire logic                 sq_post_valid,
  output logic                      sq_post_ready,
  input  wire logic [3:0]           sq_post_op,
  input  wire logic [63:0]          sq_post_wr_id,
  input  wire logic [63:0]          sq_post_laddr,
  input  wire logic [31:0]          sq_post_lkey,
  input  wire logic [31:0]          sq_post_len,
  input  wire logic [63:0]          sq_post_raddr,
  input  wire logic [31:0]          sq_post_rkey,
  input  wire logic [3:0]           sq_post_flags,
  output logic                      sq_post_rsp_valid,
  output logic [2:0]                sq_post_rsp_status,
  // ---- receive queue post --------------------------------------------------------------------------------------------------------------
  input  wire logic                 rq_post_valid,
  output logic                      rq_post_ready,
  input  wire logic [63:0]          rq_post_wr_id,
  input  wire logic [63:0]          rq_post_addr,
  input  wire logic [31:0]          rq_post_lkey,
  input  wire logic [31:0]          rq_post_len,
  output logic                      rq_post_rsp_valid,
  output logic [2:0]                rq_post_rsp_status,
  // ---- completion queue -----------------------------------------------------------------------------------------------------------------
  output logic                      cq_valid,
  input  wire logic                 cq_ready,
  output logic [63:0]               cq_wr_id,
  output logic [3:0]                cq_op,
  output logic [3:0]                cq_status,
  output logic [31:0]               cq_len,
  output logic [15:0]               cq_qpn,
  // ---- local memory (in-order responses, one per accepted request; the engine never lets more than MEM_*_OUT be outstanding) ----------------
  output logic                      mrd_valid,
  input  wire logic                 mrd_ready,
  output logic [PA_W-1:0]           mrd_addr,
  output logic [CTX_W-1:0]          mrd_ctx,
  input  wire logic                 mrd_rsp_valid,
  input  wire logic [DW-1:0]        mrd_rsp_data,
  input  wire logic                 mrd_rsp_err,
  output logic                      mwr_valid,
  input  wire logic                 mwr_ready,
  output logic [PA_W-1:0]           mwr_addr,
  output logic [DW-1:0]             mwr_data,
  output logic [B-1:0]              mwr_strb,
  output logic [CTX_W-1:0]          mwr_ctx,
  input  wire logic                 mwr_ack_valid,
  input  wire logic                 mwr_ack_err,
  // ---- transport stream (PacketCore AXI-S contract) ---------------------------------------------------------------------------------------
  output logic                      tx_valid,
  input  wire logic                 tx_ready,
  output logic [DW-1:0]             tx_data,
  output logic [B-1:0]              tx_keep,
  output logic                      tx_last,
  input  wire logic                 rx_valid,
  output logic                      rx_ready,
  input  wire logic [DW-1:0]        rx_data,
  input  wire logic [B-1:0]         rx_keep,
  input  wire logic                 rx_last,
  input  wire logic                 rx_err,
  // ---- performance / diagnostics -----------------------------------------------------------------------------------------------------------
  input  wire logic [7:0]           perf_idx,
  output logic [63:0]               perf_data,
  input  wire logic                 perf_clear,
  output logic [3:0]                fl_fault,
  output logic [31:0]               fl_key,
  output logic [63:0]               fl_va,
  output logic [31:0]               fl_len,
  output logic [1:0]                fl_op,
  output logic                      ref_ovf
);
  localparam int WB = $clog2(WINDOW);
  localparam int NNF = `SFR_NFAULT;

  // ---- parameter legality: an illegal configuration is REFUSED at elaboration, never silently built ---------------------------------
  function automatic bit is_pow2(input int v);
    begin is_pow2 = (v >= 2) && ((v & (v - 1)) == 0); end
  endfunction
  generate
    if (!(DW == 32 || DW == 64 || DW == 128))             begin : g_e_dw      $error("DW must be 32, 64 or 128 (the 48-byte frame prefix must be a multiple of DW/8)"); end
    if (PA_W < 32 || PA_W > 64)                           begin : g_e_pa      $error("PA_W must be 32..64"); end
    if (!is_pow2(MTU) || MTU < DW/8 || MTU > 4096)        begin : g_e_mtu     $error("MTU must be a power of two, >= DW/8 and <= 4096"); end
    if (NMR < 2 || NMR > 31)                              begin : g_e_nmr     $error("NMR must be 2..31"); end
    if (PD_W < 1 || PD_W > 8 || CTX_W < 1 || CTX_W > 4)   begin : g_e_pd      $error("PD_W must be 1..8 and CTX_W 1..4"); end
    if (!is_pow2(SQ_DEPTH) || !is_pow2(RQ_DEPTH))         begin : g_e_q       $error("SQ_DEPTH and RQ_DEPTH must be powers of two >= 2"); end
    if (!is_pow2(CQ_DEPTH))                               begin : g_e_cq      $error("CQ_DEPTH must be a power of two >= 2"); end
    if (!is_pow2(WINDOW) || WINDOW > 4096)                begin : g_e_win     $error("WINDOW must be a power of two in 2..4096"); end
    if (MAX_RD < 1 || MAX_RD > 15)                        begin : g_e_rd      $error("MAX_RD must be 1..15"); end
    if (!is_pow2(MEM_RD_OUT) || !is_pow2(MEM_WR_OUT))     begin : g_e_mem     $error("MEM_RD_OUT and MEM_WR_OUT must be powers of two >= 2"); end
    if (!is_pow2(PAGE_BYTES))                             begin : g_e_page    $error("PAGE_BYTES must be a power of two"); end
    if (MAX_MSG_BYTES < 1 || MAX_MSG_BYTES > 32'h7FFF_FFFF) begin : g_e_msg   $error("MAX_MSG_BYTES must be 1..2^31-1"); end
    if (ACCEPT_ACK_DELAY < 1)                             begin : g_e_ack     $error("ACCEPT_ACK_DELAY must be >= 1"); end
  endgenerate

  // ---------------------------------------------------------------------------------------------------------------------------------
  // trusted configuration dispatcher
  // ---------------------------------------------------------------------------------------------------------------------------------
  logic        cfg_busy;
  wire         cfg_hs   = cfg_valid && cfg_ready;
  wire         is_mr    = (cfg_cmd == `SFR_CFG_MR_SET) || (cfg_cmd == `SFR_CFG_MR_INVAL) || (cfg_cmd == `SFR_CFG_CTX_SET);
  wire         is_qp    = (cfg_cmd == `SFR_CFG_QP_MODIFY);
  wire         mr_cmd_v = cfg_hs && is_mr;
  wire         qm_v     = cfg_hs && is_qp;
  wire         mr_rsp_v; wire [3:0] mr_rsp_s;
  wire         qm_rsp_v; wire [3:0] qm_rsp_s;
  assign cfg_ready = !cfg_busy;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin cfg_busy <= 1'b0; cfg_rsp_valid <= 1'b0; cfg_rsp_status <= 4'd0; end
    else begin
      cfg_rsp_valid <= 1'b0;
      if (cfg_hs) begin
        if (is_mr || is_qp) cfg_busy <= 1'b1;
        else begin cfg_rsp_valid <= 1'b1; cfg_rsp_status <= (cfg_cmd == `SFR_CFG_NOP) ? `SFR_CS_OK : `SFR_CS_FIELDS; end
      end
      if (mr_rsp_v) begin cfg_busy <= 1'b0; cfg_rsp_valid <= 1'b1; cfg_rsp_status <= mr_rsp_s; end
      if (qm_rsp_v) begin cfg_busy <= 1'b0; cfg_rsp_valid <= 1'b1; cfg_rsp_status <= qm_rsp_s; end
    end
  end
  wire [1:0] mr_op2 = (cfg_cmd == `SFR_CFG_MR_SET) ? 2'd1 : (cfg_cmd == `SFR_CFG_MR_INVAL) ? 2'd2 : 2'd3;

  // ---------------------------------------------------------------------------------------------------------------------------------
  // registry
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire [1:0]            reg_chk_valid;
  wire [3:0]            reg_chk_op;
  wire [63:0]           reg_chk_key;
  wire [2*PD_W-1:0]     reg_chk_pd;
  wire [127:0]          reg_chk_va;
  wire [63:0]           reg_chk_len;
  wire [1:0]            reg_rsp_valid, reg_rsp_ok;
  wire [7:0]            reg_rsp_fault;
  wire [2*RID_W-1:0]    reg_rsp_rid;
  wire [2*PA_W-1:0]     reg_rsp_pa;
  wire [2*CTX_W-1:0]    reg_rsp_ctx;
  wire [5:0]            reg_rel_valid;
  wire [6*RID_W-1:0]    reg_rel_rid;
  wire                  reg_ref_clear;
  wire [2*RID_W-1:0]    g_rid;
  wire [2*PA_W-1:0]     g_pa;
  wire [2*16-1:0]       g_len;
  wire [1:0]            g_ok;
  wire [NNF*32-1:0]     fault_cnt;
  wire [NMR-1:0]        tbl_valid_unused;

  sf_rdma_memory_registry #(.NMR(NMR), .PA_W(PA_W), .PD_W(PD_W), .CTX_W(CTX_W), .NCHK(2), .NREL(6), .NG(2), .GLEN_W(16),
                            .PAGE_BYTES(PAGE_BYTES), .MAX_MSG_BYTES(MAX_MSG_BYTES)) u_reg (
    .clk(clk), .rst_n(rst_n),
    .mr_cmd_valid(mr_cmd_v), .mr_cmd(mr_op2), .mr_idx(cfg_idx), .mr_va(cfg_va), .mr_len(cfg_len), .mr_pa(cfg_pa), .mr_key(cfg_key),
    .mr_pd(cfg_pd), .mr_acc(cfg_acc), .mr_ctx(cfg_ctx), .mr_ctx_mask(cfg_ctx_mask), .mr_rsp_valid(mr_rsp_v), .mr_rsp_status(mr_rsp_s),
    .chk_valid(reg_chk_valid), .chk_op(reg_chk_op), .chk_key(reg_chk_key), .chk_pd(reg_chk_pd), .chk_va(reg_chk_va), .chk_len(reg_chk_len),
    .rsp_valid(reg_rsp_valid), .rsp_ok(reg_rsp_ok), .rsp_fault(reg_rsp_fault), .rsp_rid(reg_rsp_rid), .rsp_pa(reg_rsp_pa), .rsp_ctx(reg_rsp_ctx),
    .rel_valid(reg_rel_valid), .rel_rid(reg_rel_rid), .ref_clear(reg_ref_clear),
    .g_rid(g_rid), .g_pa(g_pa), .g_len(g_len), .g_ok(g_ok),
    .fault_cnt(fault_cnt), .tbl_valid(tbl_valid_unused), .fl_fault(fl_fault), .fl_key(fl_key), .fl_va(fl_va), .fl_len(fl_len), .fl_op(fl_op),
    .ref_ovf(ref_ovf));

  // ---------------------------------------------------------------------------------------------------------------------------------
  // work queues, completion queue
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire        credits_ge1, credits_ge2, sq_take, rq_take;
  wire        sq_head_valid, sq_pop; wire [1:0] sq_head_op; wire [63:0] sq_head_wr_id, sq_head_laddr, sq_head_raddr; wire [31:0] sq_head_lkey, sq_head_len, sq_head_rkey;
  wire        rq_head_valid, rq_pop; wire [63:0] rq_head_wr_id, rq_head_addr; wire [31:0] rq_head_lkey, rq_head_len;
  wire [$clog2(SQ_DEPTH):0] sq_occ; wire [$clog2(RQ_DEPTH):0] rq_occ;
  wire        ev_rej_opcode, ev_rej_state, ev_rej_len, ev_rej_fields, ev_rej_range, ev_stall_sqfull, ev_stall_cqcred;
  wire        q_clear;

  sf_rdma_wqe #(.SQ_DEPTH(SQ_DEPTH), .RQ_DEPTH(RQ_DEPTH), .MAX_MSG_BYTES(MAX_MSG_BYTES)) u_wqe (
    .clk(clk), .rst_n(rst_n), .clear(q_clear), .qp_state(qp_state),
    .sq_post_valid(sq_post_valid), .sq_post_ready(sq_post_ready), .sq_post_op(sq_post_op), .sq_post_wr_id(sq_post_wr_id),
    .sq_post_laddr(sq_post_laddr), .sq_post_lkey(sq_post_lkey), .sq_post_len(sq_post_len), .sq_post_raddr(sq_post_raddr),
    .sq_post_rkey(sq_post_rkey), .sq_post_flags(sq_post_flags), .sq_post_rsp_valid(sq_post_rsp_valid), .sq_post_rsp_status(sq_post_rsp_status),
    .rq_post_valid(rq_post_valid), .rq_post_ready(rq_post_ready), .rq_post_wr_id(rq_post_wr_id), .rq_post_addr(rq_post_addr),
    .rq_post_lkey(rq_post_lkey), .rq_post_len(rq_post_len), .rq_post_rsp_valid(rq_post_rsp_valid), .rq_post_rsp_status(rq_post_rsp_status),
    .credits_ge1(credits_ge1), .credits_ge2(credits_ge2), .sq_take(sq_take), .rq_take(rq_take),
    .sq_head_valid(sq_head_valid), .sq_pop(sq_pop), .sq_head_op(sq_head_op), .sq_head_wr_id(sq_head_wr_id), .sq_head_laddr(sq_head_laddr),
    .sq_head_lkey(sq_head_lkey), .sq_head_len(sq_head_len), .sq_head_raddr(sq_head_raddr), .sq_head_rkey(sq_head_rkey),
    .rq_head_valid(rq_head_valid), .rq_pop(rq_pop), .rq_head_wr_id(rq_head_wr_id), .rq_head_addr(rq_head_addr), .rq_head_lkey(rq_head_lkey),
    .rq_head_len(rq_head_len), .sq_occ(sq_occ), .rq_occ(rq_occ),
    .ev_rej_opcode(ev_rej_opcode), .ev_rej_state(ev_rej_state), .ev_rej_len(ev_rej_len), .ev_rej_fields(ev_rej_fields),
    .ev_rej_range(ev_rej_range), .ev_stall_sqfull(ev_stall_sqfull), .ev_stall_cqcred(ev_stall_cqcred));

  wire        c0_valid, c0_ready, c1_valid, c1_ready;
  wire [63:0] c0_wr_id, c1_wr_id; wire [3:0] c0_op, c0_status, c1_op, c1_status; wire [31:0] c0_len, c1_len;
  wire [15:0] local_qpn;
  wire [$clog2(CQ_DEPTH):0] cq_count, cq_credits /* verilator public_flat_rd */;      // (read by the bench for the credit-conservation check)
  wire        cq_overflow;
  sf_rdma_completion #(.CQ_DEPTH(CQ_DEPTH)) u_cq (
    .clk(clk), .rst_n(rst_n), .local_qpn(local_qpn), .take_sq(sq_take), .take_rq(rq_take), .credits_ge1(credits_ge1), .credits_ge2(credits_ge2),
    .p0_valid(c0_valid), .p0_ready(c0_ready), .p0_wr_id(c0_wr_id), .p0_op(c0_op), .p0_status(c0_status), .p0_len(c0_len),
    .p1_valid(c1_valid), .p1_ready(c1_ready), .p1_wr_id(c1_wr_id), .p1_op(c1_op), .p1_status(c1_status), .p1_len(c1_len),
    .cq_valid(cq_valid), .cq_ready(cq_ready), .cq_wr_id(cq_wr_id), .cq_op(cq_op), .cq_status(cq_status), .cq_len(cq_len), .cq_qpn(cq_qpn),
    .cq_count(cq_count), .credits(cq_credits), .ev_overflow(cq_overflow));

  // ---------------------------------------------------------------------------------------------------------------------------------
  // transport adapter, data movement
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire [47:0] cfg_local_mac, cfg_peer_mac; wire [15:0] cfg_epoch_q; wire cfg_req_en, cfg_resp_en;
  wire [2:0]  txh_valid, txh_ready; wire [3*272-1:0] txh_sh; wire tx_hold, tx_flush, tx_quiet;
  wire        rxh_valid; wire [271:0] rxh_sh; wire rxh_pop, rx_flush;
  wire        rxp_valid, rxp_ready; wire [DW-1:0] rxp_data; wire [B-1:0] rxp_keep; wire rxp_last;
  wire [1:0]  txp_valid; wire [2*DW-1:0] txp_data; wire [1:0] txp_last, txp_err;
  wire        tx_drop_req, ad_ev_tx_abort, ad_ev_tx_abort_err, ad_tx_abort_port; wire [23:0] ad_tx_abort_psn;
  wire        ad_ev_tx_frame, ad_ev_rx_frame, ad_ev_stall_txlink, ad_ev_stall_rxbuf, ad_ev_drop_state;
  wire [8:0]  ad_ev_drop; wire [15:0] ad_ev_rx_pay, ad_ev_tx_pay;

  sf_rdma_transport_adapter #(.DW(DW), .MTU(MTU)) u_ad (
    .clk(clk), .rst_n(rst_n), .cfg_local_mac(cfg_local_mac), .cfg_peer_mac(cfg_peer_mac), .cfg_local_qpn(local_qpn), .cfg_epoch(cfg_epoch_q),
    .cfg_req_en(cfg_req_en), .cfg_resp_en(cfg_resp_en),
    .tx_valid(tx_valid), .tx_ready(tx_ready), .tx_data(tx_data), .tx_keep(tx_keep), .tx_last(tx_last),
    .rx_valid(rx_valid), .rx_ready(rx_ready), .rx_data(rx_data), .rx_keep(rx_keep), .rx_last(rx_last), .rx_err(rx_err),
    .txh_valid(txh_valid), .txh_ready(txh_ready), .txh_sh(txh_sh), .txp_valid(txp_valid), .txp_data(txp_data), .txp_last(txp_last), .txp_err(txp_err),
    .tx_drop_req(tx_drop_req), .ev_tx_abort(ad_ev_tx_abort), .ev_tx_abort_err(ad_ev_tx_abort_err), .tx_abort_port(ad_tx_abort_port), .tx_abort_psn(ad_tx_abort_psn),
    .tx_hold(tx_hold), .tx_flush(tx_flush), .tx_quiet(tx_quiet),
    .rxh_valid(rxh_valid), .rxh_sh(rxh_sh), .rxh_pop(rxh_pop), .rxp_valid(rxp_valid), .rxp_ready(rxp_ready), .rxp_data(rxp_data),
    .rxp_keep(rxp_keep), .rxp_last(rxp_last), .rx_flush(rx_flush),
    .ev_tx_frame(ad_ev_tx_frame), .ev_rx_frame(ad_ev_rx_frame), .ev_stall_txlink(ad_ev_stall_txlink), .ev_stall_rxbuf(ad_ev_stall_rxbuf),
    .ev_drop(ad_ev_drop), .ev_drop_state(ad_ev_drop_state), .ev_rx_paybytes(ad_ev_rx_pay), .ev_tx_paybytes(ad_ev_tx_pay));

  // read engine (memory -> transmit payload), write engine (receive payload -> memory)
  wire        rdc_valid, rdc_ready, rdc_port; wire [PA_W-1:0] rdc_pa; wire [15:0] rdc_len; wire [RID_W-1:0] rdc_rid; wire [CTX_W-1:0] rdc_ctx;
  wire        rd_viol, rd_idle, rd_done_valid, rd_done_port, rd_done_err;
  wire        pl_valid, pl_last, pl_port, pl_err; wire [DW-1:0] pl_data; wire [B-1:0] pl_keep;
  wire [$clog2(DW/8):0] rd_bytes;
  wire        dma_clear;
  sf_rdma_dma_rd #(.DW(DW), .PA_W(PA_W), .RID_W(RID_W), .CTX_W(CTX_W), .MEM_OUT(MEM_RD_OUT), .CMD_Q(2)) u_dr (
    .clk(clk), .rst_n(rst_n), .clear(dma_clear),
    .cmd_valid(rdc_valid), .cmd_ready(rdc_ready), .cmd_pa(rdc_pa), .cmd_len(rdc_len), .cmd_port(rdc_port), .cmd_rid(rdc_rid), .cmd_ctx(rdc_ctx),
    .viol(rd_viol), .g_rid(g_rid[RID_W-1:0]), .g_pa(g_pa[PA_W-1:0]), .g_len(g_len[15:0]), .g_ok(g_ok[0]),
    .mrd_valid(mrd_valid), .mrd_ready(mrd_ready), .mrd_addr(mrd_addr), .mrd_ctx(mrd_ctx),
    .mrd_rsp_valid(mrd_rsp_valid), .mrd_rsp_data(mrd_rsp_data), .mrd_rsp_err(mrd_rsp_err),
    .pl_valid(pl_valid), .pl_data(pl_data), .pl_keep(pl_keep), .pl_last(pl_last), .pl_port(pl_port), .pl_err(pl_err),
    .done_valid(rd_done_valid), .done_port(rd_done_port), .done_err(rd_done_err), .idle(rd_idle), .bytes_n(rd_bytes));
  assign txp_valid = {pl_valid && pl_port, pl_valid && !pl_port};
  assign txp_data  = {pl_data, pl_data};
  assign txp_last  = {pl_last, pl_last};
  assign txp_err   = {pl_err, pl_err};

  wire        dw_cmd_valid, dw_cmd_ready, dw_cmd_discard; wire [PA_W-1:0] dw_cmd_pa; wire [15:0] dw_cmd_len; wire [RID_W-1:0] dw_cmd_rid; wire [CTX_W-1:0] dw_cmd_ctx;
  wire        dw_done_valid, dw_done_err, dw_viol, dw_idle;
  wire [$clog2(DW/8):0] wr_bytes;
  sf_rdma_dma_wr #(.DW(DW), .PA_W(PA_W), .RID_W(RID_W), .CTX_W(CTX_W), .MEM_WR_OUT(MEM_WR_OUT), .CMD_Q(4)) u_dw (
    .clk(clk), .rst_n(rst_n), .clear(dma_clear),
    .cmd_valid(dw_cmd_valid), .cmd_ready(dw_cmd_ready), .cmd_discard(dw_cmd_discard), .cmd_pa(dw_cmd_pa), .cmd_len(dw_cmd_len),
    .cmd_rid(dw_cmd_rid), .cmd_ctx(dw_cmd_ctx), .viol(dw_viol), .g_rid(g_rid[2*RID_W-1:RID_W]), .g_pa(g_pa[2*PA_W-1:PA_W]),
    .g_len(g_len[31:16]), .g_ok(g_ok[1]),
    .pl_valid(rxp_valid), .pl_ready(rxp_ready), .pl_data(rxp_data),
    .mwr_valid(mwr_valid), .mwr_ready(mwr_ready), .mwr_addr(mwr_addr), .mwr_data(mwr_data), .mwr_strb(mwr_strb), .mwr_ctx(mwr_ctx),
    .mwr_ack_valid(mwr_ack_valid), .mwr_ack_err(mwr_ack_err),
    .done_valid(dw_done_valid), .done_err(dw_done_err), .idle(dw_idle), .bytes_n(wr_bytes));

  // ---------------------------------------------------------------------------------------------------------------------------------
  // queue pair
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire [WB+1:0] win_occ, ring_occ;
  wire        ev_retry_timeout, ev_retry_nak, ev_retry_rnr, ev_tx_retx, ev_rx_ack_stale, ev_rx_nak, ev_stall_window, ev_stall_rdlim;
  wire        lat_valid; wire [1:0] lat_op; wire [31:0] lat_cycles;
  wire        cqe_valid; wire [3:0] cqe_op, cqe_status; wire [31:0] cqe_len;
  wire        ev_dup, ev_oos, ev_resp_drop, ev_accept, ev_commit, ev_unsupp, ev_dup_rd_fault, ev_nak_badcode, ev_tx_nak, ev_rnr_sent, ev_guard_viol;
  wire [31:0] now;
  sf_rdma_qp #(.WINDOW(WINDOW), .MAX_RD(MAX_RD), .MTU(MTU), .PA_W(PA_W), .PD_W(PD_W), .RID_W(RID_W), .CTX_W(CTX_W),
               .MAX_MSG_BYTES(MAX_MSG_BYTES), .ACCEPT_ACK_DELAY(ACCEPT_ACK_DELAY)) u_qp (
    .clk(clk), .rst_n(rst_n), .now(now),
    .qm_valid(qm_v), .qm_state(cfg_qp_state), .qm_qpn(cfg_qpn), .qm_pd(cfg_pd), .qm_rqpn(cfg_rqpn), .qm_epoch(cfg_epoch), .qm_rq_psn(cfg_rq_psn),
    .qm_lmac(cfg_lmac), .qm_pmac(cfg_pmac), .qm_sq_psn(cfg_sq_psn), .qm_timeout(cfg_timeout), .qm_retry(cfg_retry), .qm_rnr_retry(cfg_rnr_retry),
    .qm_rnr_delay(cfg_rnr_delay), .qm_rsp_valid(qm_rsp_v), .qm_rsp_status(qm_rsp_s),
    .qp_state(qp_state), .qp_err_cause(qp_err_cause), .local_qpn(local_qpn), .cfg_local_mac(cfg_local_mac), .cfg_peer_mac(cfg_peer_mac),
    .cfg_epoch(cfg_epoch_q), .cfg_req_en(cfg_req_en), .cfg_resp_en(cfg_resp_en),
    .sq_valid(sq_head_valid), .sq_pop(sq_pop), .sq_op(sq_head_op), .sq_wr_id(sq_head_wr_id), .sq_laddr(sq_head_laddr), .sq_lkey(sq_head_lkey),
    .sq_len(sq_head_len), .sq_raddr(sq_head_raddr), .sq_rkey(sq_head_rkey),
    .rq_valid(rq_head_valid), .rq_pop(rq_pop), .rq_wr_id(rq_head_wr_id), .rq_addr(rq_head_addr), .rq_lkey(rq_head_lkey), .rq_len(rq_head_len),
    .reg_chk_valid(reg_chk_valid), .reg_chk_op(reg_chk_op), .reg_chk_key(reg_chk_key), .reg_chk_pd(reg_chk_pd), .reg_chk_va(reg_chk_va),
    .reg_chk_len(reg_chk_len), .reg_rsp_valid(reg_rsp_valid), .reg_rsp_ok(reg_rsp_ok), .reg_rsp_rid(reg_rsp_rid), .reg_rsp_pa(reg_rsp_pa),
    .reg_rsp_ctx(reg_rsp_ctx), .reg_rel_valid(reg_rel_valid), .reg_rel_rid(reg_rel_rid), .reg_ref_clear(reg_ref_clear),
    .rdc_valid(rdc_valid), .rdc_ready(rdc_ready), .rdc_pa(rdc_pa), .rdc_len(rdc_len), .rdc_port(rdc_port), .rdc_rid(rdc_rid), .rdc_ctx(rdc_ctx),
    .rd_done_valid(rd_done_valid), .rd_done_port(rd_done_port), .rd_viol(rd_viol), .rd_idle(rd_idle),
    .dw_cmd_valid(dw_cmd_valid), .dw_cmd_ready(dw_cmd_ready), .dw_cmd_discard(dw_cmd_discard), .dw_cmd_pa(dw_cmd_pa), .dw_cmd_len(dw_cmd_len),
    .dw_cmd_rid(dw_cmd_rid), .dw_cmd_ctx(dw_cmd_ctx), .dw_done_valid(dw_done_valid), .dw_done_err(dw_done_err), .dw_viol(dw_viol),
    .dw_idle(dw_idle), .dma_clear(dma_clear),
    .txh_valid(txh_valid), .txh_ready(txh_ready), .txh_sh(txh_sh), .tx_hold(tx_hold), .tx_flush(tx_flush), .tx_drop_req(tx_drop_req), .tx_quiet(tx_quiet),
    .ad_abort_ev(ad_ev_tx_abort), .ad_abort_err(ad_ev_tx_abort_err), .ad_abort_port(ad_tx_abort_port), .ad_abort_psn(ad_tx_abort_psn),
    .rxh_valid(rxh_valid), .rxh_sh(rxh_sh), .rxh_pop(rxh_pop), .rx_flush(rx_flush),
    .c0_valid(c0_valid), .c0_ready(c0_ready), .c0_wr_id(c0_wr_id), .c0_op(c0_op), .c0_status(c0_status), .c0_len(c0_len),
    .c1_valid(c1_valid), .c1_ready(c1_ready), .c1_wr_id(c1_wr_id), .c1_op(c1_op), .c1_status(c1_status), .c1_len(c1_len),
    .q_clear(q_clear), .win_occ(win_occ), .ring_occ(ring_occ),
    .ev_retry_timeout(ev_retry_timeout), .ev_retry_nak(ev_retry_nak), .ev_retry_rnr(ev_retry_rnr), .ev_tx_retx(ev_tx_retx),
    .ev_rx_ack_stale(ev_rx_ack_stale), .ev_rx_nak(ev_rx_nak), .ev_stall_window(ev_stall_window), .ev_stall_rdlim(ev_stall_rdlim),
    .lat_valid(lat_valid), .lat_op(lat_op), .lat_cycles(lat_cycles), .cqe_valid(cqe_valid), .cqe_op(cqe_op), .cqe_status(cqe_status), .cqe_len(cqe_len),
    .ev_dup(ev_dup), .ev_oos(ev_oos), .ev_resp_drop(ev_resp_drop), .ev_accept(ev_accept), .ev_commit(ev_commit), .ev_unsupp(ev_unsupp),
    .ev_dup_rd_fault(ev_dup_rd_fault), .ev_nak_badcode(ev_nak_badcode), .ev_tx_nak(ev_tx_nak), .ev_rnr_sent(ev_rnr_sent), .ev_guard_viol(ev_guard_viol));

  // ---------------------------------------------------------------------------------------------------------------------------------
  // performance counters: one increment per counter index
  // ---------------------------------------------------------------------------------------------------------------------------------
  localparam int NPC = `SFR_PC_NUM;
  logic [NPC*32-1:0] inc;
  wire cqe_ok    = cqe_valid && (cqe_status == `SFR_CQ_OK);
  wire cqe_err   = cqe_valid && (cqe_status != `SFR_CQ_OK) && (cqe_status != `SFR_CQ_FLUSH);
  wire cqe_flush = cqe_valid && (cqe_status == `SFR_CQ_FLUSH);
  wire [31:0] dr_cycle_busy = rd_idle ? 32'd0 : 32'd1;
  wire [31:0] dw_cycle_busy = dw_idle ? 32'd0 : 32'd1;
  always_comb begin
    inc = '0;
    inc[`SFR_PC_OPS_SEND*32   +: 32] = (cqe_ok && cqe_op == `SFR_WOP_SEND)  ? 32'd1 : 32'd0;
    inc[`SFR_PC_OPS_WRITE*32  +: 32] = (cqe_ok && cqe_op == `SFR_WOP_WRITE) ? 32'd1 : 32'd0;
    inc[`SFR_PC_OPS_READ*32   +: 32] = (cqe_ok && cqe_op == `SFR_WOP_READ)  ? 32'd1 : 32'd0;
    inc[`SFR_PC_OPS_ERR*32    +: 32] = cqe_err   ? 32'd1 : 32'd0;
    inc[`SFR_PC_OPS_FLUSHED*32 +: 32] = cqe_flush ? 32'd1 : 32'd0;
    inc[`SFR_PC_BYTES_SEND*32  +: 32] = (cqe_ok && cqe_op == `SFR_WOP_SEND)  ? cqe_len : 32'd0;
    inc[`SFR_PC_BYTES_WRITE*32 +: 32] = (cqe_ok && cqe_op == `SFR_WOP_WRITE) ? cqe_len : 32'd0;
    inc[`SFR_PC_BYTES_READ*32  +: 32] = (cqe_ok && cqe_op == `SFR_WOP_READ)  ? cqe_len : 32'd0;
    // receive-side completions (RECV) are produced by the responder; counted where they enter the CQ
    inc[`SFR_PC_OPS_RECV*32   +: 32] = (c1_valid && c1_ready && c1_op == `SFR_WOP_RECV && c1_status == `SFR_CQ_OK) ? 32'd1 : 32'd0;
    inc[`SFR_PC_BYTES_RECV*32 +: 32] = (c1_valid && c1_ready && c1_op == `SFR_WOP_RECV && c1_status == `SFR_CQ_OK) ? c1_len : 32'd0;
    inc[`SFR_PC_RETRY_TIMEOUT*32 +: 32] = ev_retry_timeout ? 32'd1 : 32'd0;
    inc[`SFR_PC_RETRY_NAK*32     +: 32] = ev_retry_nak     ? 32'd1 : 32'd0;
    inc[`SFR_PC_RETRY_RNR*32     +: 32] = ev_retry_rnr     ? 32'd1 : 32'd0;
    inc[`SFR_PC_TX_RETX*32       +: 32] = ev_tx_retx       ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DUP*32        +: 32] = ev_dup           ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_OOS*32        +: 32] = ev_oos           ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_NAK*32        +: 32] = ev_rx_nak        ? 32'd1 : 32'd0;
    inc[`SFR_PC_TX_NAK*32        +: 32] = ev_tx_nak        ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_ACK_STALE*32  +: 32] = ev_rx_ack_stale  ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_RESP_DROP*32  +: 32] = ev_resp_drop     ? 32'd1 : 32'd0;
    inc[`SFR_PC_EPSN_ACCEPTS*32  +: 32] = ev_accept        ? 32'd1 : 32'd0;
    inc[`SFR_PC_CPSN_COMMITS*32  +: 32] = ev_commit        ? 32'd1 : 32'd0;
    inc[`SFR_PC_STALL_TXLINK*32  +: 32] = ad_ev_stall_txlink ? 32'd1 : 32'd0;
    inc[`SFR_PC_STALL_WINDOW*32  +: 32] = ev_stall_window  ? 32'd1 : 32'd0;
    inc[`SFR_PC_STALL_RDLIM*32   +: 32] = ev_stall_rdlim   ? 32'd1 : 32'd0;
    inc[`SFR_PC_STALL_SQFULL*32  +: 32] = ev_stall_sqfull  ? 32'd1 : 32'd0;
    inc[`SFR_PC_STALL_CQCRED*32  +: 32] = ev_stall_cqcred  ? 32'd1 : 32'd0;
    inc[`SFR_PC_STALL_RXBUF*32   +: 32] = ad_ev_stall_rxbuf ? 32'd1 : 32'd0;
    inc[`SFR_PC_DMA_RD_BYTES*32  +: 32] = 32'(rd_bytes);
    inc[`SFR_PC_DMA_RD_BUSY*32   +: 32] = dr_cycle_busy;
    inc[`SFR_PC_DMA_WR_BYTES*32  +: 32] = 32'(wr_bytes);
    inc[`SFR_PC_DMA_WR_BUSY*32   +: 32] = dw_cycle_busy;
    inc[`SFR_PC_GUARD_VIOL*32    +: 32] = ev_guard_viol ? 32'd1 : 32'd0;
    inc[`SFR_PC_TX_FRAMES*32     +: 32] = ad_ev_tx_frame ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_FRAMES*32     +: 32] = ad_ev_rx_frame ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DROP_LEN*32   +: 32] = ad_ev_drop[0] ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DROP_KEEP*32  +: 32] = ad_ev_drop[1] ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DROP_MACERR*32 +: 32] = ad_ev_drop[2] ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DROP_ETYPE*32 +: 32] = ad_ev_drop[3] ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DROP_MAC*32   +: 32] = ad_ev_drop[4] ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DROP_VER*32   +: 32] = ad_ev_drop[5] ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DROP_OPCODE*32 +: 32] = ad_ev_drop[6] ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DROP_QPN*32   +: 32] = ad_ev_drop[7] ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DROP_EPOCH*32 +: 32] = ad_ev_drop[8] ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DROP_STATE*32 +: 32] = ad_ev_drop_state ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_UNSUPP_OP*32  +: 32] = ev_unsupp ? 32'd1 : 32'd0;
    inc[`SFR_PC_POST_REJ_OPCODE*32 +: 32] = ev_rej_opcode ? 32'd1 : 32'd0;
    inc[`SFR_PC_POST_REJ_STATE*32  +: 32] = ev_rej_state  ? 32'd1 : 32'd0;
    inc[`SFR_PC_POST_REJ_LEN*32    +: 32] = ev_rej_len    ? 32'd1 : 32'd0;
    inc[`SFR_PC_POST_REJ_FIELDS*32 +: 32] = ev_rej_fields ? 32'd1 : 32'd0;
    inc[`SFR_PC_POST_REJ_RANGE*32  +: 32] = ev_rej_range  ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_DUP_RD_FAULT*32 +: 32] = ev_dup_rd_fault ? 32'd1 : 32'd0;
    inc[`SFR_PC_RX_NAK_BADCODE*32  +: 32] = ev_nak_badcode  ? 32'd1 : 32'd0;
    inc[`SFR_PC_REQ_ACCEPTED*32    +: 32] = ev_accept ? 32'd1 : 32'd0;
    inc[`SFR_PC_WR_COMMITTED*32    +: 32] = ev_commit ? 32'd1 : 32'd0;
    inc[`SFR_PC_BYTES_TX_PAY*32    +: 32] = 32'(ad_ev_tx_pay);
    inc[`SFR_PC_BYTES_RX_PAY*32    +: 32] = 32'(ad_ev_rx_pay);
    inc[`SFR_PC_RNR_SENT*32        +: 32] = ev_rnr_sent ? 32'd1 : 32'd0;
  end
  sf_rdma_perf #(.NPC(NPC)) u_perf (
    .clk(clk), .rst_n(rst_n), .clr(perf_clear), .now(now), .inc(inc), .lat_valid(lat_valid), .lat_op(lat_op), .lat_cycles(lat_cycles),
    .occ_sq(32'(sq_occ)), .occ_rq(32'(rq_occ)), .occ_cq(32'(cq_count)), .occ_win(32'(win_occ)),
    .fault_cnt(fault_cnt), .rd_idx(perf_idx), .rd_data(perf_data));
endmodule
`default_nettype wire
