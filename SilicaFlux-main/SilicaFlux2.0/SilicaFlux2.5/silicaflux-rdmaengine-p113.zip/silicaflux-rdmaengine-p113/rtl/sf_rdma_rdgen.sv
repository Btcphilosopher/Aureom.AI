// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_rdgen   (READ executor of the responder)
//
// Validated READ requests are queued by the receive processor and executed HERE, decoupled from frame reception.
//   * READ-AFTER-WRITE FENCE: a read starts only when every earlier-PSN request has committed (cpsn  >=  psn).
//   * The read is cut into READ_RESP frames of <= MTU bytes.  For each frame a transmit slot (header + payload space) is reserved
//     together with the read command (one atomic push), so the shared read engine never blocks on a full output buffer.
//   * "Fetched" = every read command of this read has completed (data is in the transmit buffer): then the request counts as COMMITTED
//     (`done_valid`, fresh reads only) and its registry reference is released.  A DUPLICATE (replayed) READ re-executes the same way
//     but does not touch commit state.
//   * `halt` (QP ERR / drain): nothing more is issued; commands already handed to the read engine complete.  Queued requests keep their
//     registry references until the QP is RESET (which clears every reference, spec 11.5).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none

module sf_rdma_rdgen #(
  parameter int MTU    = 256,
  parameter int PA_W   = 32,
  parameter int RID_W  = 3,
  parameter int CTX_W  = 2,
  parameter int RDQ    = 4                      // power of two
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clear,
  input  wire logic              halt,
  input  wire logic [15:0]       remote_qpn,
  input  wire logic [15:0]       epoch,
  input  wire logic [23:0]       cpsn,
  // queue (from the receive processor)
  input  wire logic              q_valid,
  output logic                   q_ready,
  input  wire logic [23:0]       q_psn,
  input  wire logic [PA_W-1:0]   q_pa,
  input  wire logic [31:0]       q_len,         // bytes to return (mlen - moff)
  input  wire logic [31:0]       q_moff,
  input  wire logic [31:0]       q_mlen,
  input  wire logic [RID_W-1:0]  q_rid,
  input  wire logic [CTX_W-1:0]  q_ctx,
  input  wire logic              q_replay,
  // transmit request (port 1) + read command
  output logic                   tx_valid,
  input  wire logic              tx_ready,
  output logic [271:0]           tx_sh,
  output logic [PA_W-1:0]        tx_pa,
  output logic [15:0]            tx_len,
  output logic [RID_W-1:0]       tx_rid,
  output logic [CTX_W-1:0]       tx_ctx,
  input  wire logic              rd_done_valid,          // read command of port 1 completed
  // results
  output logic                   done_valid,             // fresh read fetched: commit it
  output logic [23:0]            done_psn,
  output logic                   rel_valid,
  output logic [RID_W-1:0]       rel_rid,
  output logic                   idle,
  output logic                   ev_resp_frame
);
  // ---- queue ----------------------------------------------------------------------------------------------------------------------
  localparam int QW = 24 + PA_W + 32 + 32 + 32 + RID_W + CTX_W + 1;
  wire qf_full, qf_empty, qf_ovf, qf_unf;
  wire [$clog2(RDQ):0] qf_cnt;
  wire [QW-1:0] qf_rd;
  logic qf_pop;
  sf_rdma_fifo #(.WIDTH(QW), .DEPTH(RDQ)) u_q (
    .clk(clk), .rst_n(rst_n), .clear(clear), .push(q_valid && q_ready), .wdata({q_psn, q_pa, q_len, q_moff, q_mlen, q_rid, q_ctx, q_replay}),
    .pop(qf_pop), .rdata(qf_rd), .full(qf_full), .empty(qf_empty), .count(qf_cnt), .ovf(qf_ovf), .unf(qf_unf));
  assign q_ready = !qf_full && !halt;

  // ---- active read ------------------------------------------------------------------------------------------------------------------
  logic              act, replay;
  logic [23:0]       a_psn;
  logic [PA_W-1:0]   a_pa;
  logic [31:0]       a_left, a_moff, a_mlen;
  logic [RID_W-1:0]  a_rid;
  logic [CTX_W-1:0]  a_ctx;
  logic [7:0]        outst;                      // read commands handed over and not yet completed

  wire [QW-1:0] h = qf_rd;
  wire [23:0]        h_psn  = h[QW-1 -: 24];
  wire [PA_W-1:0]    h_pa   = h[QW-24-1 -: PA_W];
  wire [31:0]        h_len  = h[QW-24-PA_W-1 -: 32];
  wire [31:0]        h_moff = h[QW-24-PA_W-32-1 -: 32];
  wire [31:0]        h_mlen = h[QW-24-PA_W-64-1 -: 32];
  wire [RID_W-1:0]   h_rid  = h[RID_W+CTX_W+1-1 -: RID_W];
  wire [CTX_W-1:0]   h_ctx  = h[CTX_W+1-1 -: CTX_W];
  wire               h_rep  = h[0];

  // fence: cpsn >= psn  (modular)
  wire [23:0] fence_d = cpsn - a_psn;
  wire        fence_ok = !fence_d[23];

  wire [31:0] seg32  = (a_left > 32'(MTU)) ? 32'(MTU) : a_left;
  wire        started = act && !halt && fence_ok;
  assign tx_valid = started && (a_left != 32'd0);
  assign tx_pa    = a_pa;
  assign tx_len   = seg32[15:0];
  assign tx_rid   = a_rid;
  assign tx_ctx   = a_ctx;
  wire        hs  = tx_valid && tx_ready;
  assign ev_resp_frame = hs;

  wire [23:0]  p24 = a_psn;
  wire [15:0]  qn  = remote_qpn;
  wire [15:0]  ep  = epoch;
  wire [15:0]  pl16 = seg32[15:0];
  wire [31:0]  ml  = a_mlen;
  wire [31:0]  mo  = a_moff;
  wire         isf = (a_moff == 32'd0);
  wire         isl = ((a_moff + seg32) == a_mlen);
  wire [7:0]   vf  = {`SFR_VERSION, 1'b0, 1'b0, isl, isf};
  always_comb begin
    tx_sh = '0;
    tx_sh[8*`SFR_SH_VF     +: 8]  = vf;
    tx_sh[8*`SFR_SH_OPC    +: 8]  = `SFR_OP_READ_RESP;
    tx_sh[8*`SFR_SH_QPN    +: 16] = `SFR_BSW16(qn);
    tx_sh[8*`SFR_SH_EPOCH  +: 16] = `SFR_BSW16(ep);
    tx_sh[8*`SFR_SH_PSN    +: 24] = `SFR_BSW24(p24);
    tx_sh[8*`SFR_SH_PAYLEN +: 16] = `SFR_BSW16(pl16);
    tx_sh[8*`SFR_SH_MLEN   +: 32] = `SFR_BSW32(ml);
    tx_sh[8*`SFR_SH_MOFF   +: 32] = `SFR_BSW32(mo);
  end

  wire all_issued = act && (a_left == 32'd0);
  wire all_done   = all_issued && (outst == 8'd0);
  assign qf_pop   = !act && !qf_empty;

  assign done_valid = all_done && !replay;
  assign done_psn   = a_psn;
  assign rel_valid  = all_done;
  assign rel_rid    = a_rid;
  assign idle       = qf_empty && !act;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      act <= 1'b0; replay <= 1'b0; a_psn <= '0; a_pa <= '0; a_left <= '0; a_moff <= '0; a_mlen <= '0;
      a_rid <= '0; a_ctx <= '0; outst <= '0;
    end else if (clear) begin
      act <= 1'b0; outst <= '0;
    end else begin
      outst <= outst + (hs ? 8'd1 : 8'd0) - (rd_done_valid ? 8'd1 : 8'd0);
      if (qf_pop && !halt) begin
        act <= 1'b1; replay <= h_rep; a_psn <= h_psn; a_pa <= h_pa; a_left <= h_len; a_moff <= h_moff; a_mlen <= h_mlen;
        a_rid <= h_rid; a_ctx <= h_ctx;
      end
      if (hs) begin
        a_pa <= a_pa + PA_W'(seg32); a_left <= a_left - seg32; a_moff <= a_moff + seg32;
      end
      if (all_done) act <= 1'b0;
    end
  end
endmodule
`default_nettype wire
