// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_defs.svh
// Constants, status codes and SFRT header field macros.  Included (`include) by every RTL file; macros only, so no
// package dependency and no unused-parameter lint noise.   Normative reference: docs/TRANSPORT_SPEC.md
// =============================================================================
`ifndef SF_RDMA_DEFS_SVH
`define SF_RDMA_DEFS_SVH

// ---- wire constants -------------------------------------------------------------------------------------------
`define SFR_ETHERTYPE      16'h88B5
`define SFR_VERSION        4'h1
`define SFR_HDR_BYTES      48            // 14 Ethernet + 34 SFRT
`define SFR_SH_BYTES       34
`define SFR_SH_W           272
`define SFR_FH_W           384
`define SFR_MIN_FRAME      60

`define SFR_OP_SEND        8'h01
`define SFR_OP_WRITE       8'h02
`define SFR_OP_READ_REQ    8'h03
`define SFR_OP_READ_RESP   8'h10
`define SFR_OP_ACK         8'h20
`define SFR_OP_NAK         8'h21

`define SFR_NAK_SEQ        4'd1
`define SFR_NAK_RNR        4'd2
`define SFR_NAK_INV        4'd3
`define SFR_NAK_ACC        4'd4
`define SFR_NAK_OP         4'd5

// ---- SFRT-header (34 bytes, byte k at [8k+:8]) field positions (SFRT-relative = frame byte - 14) ----------------
`define SFR_SH_VF          0
`define SFR_SH_OPC         1
`define SFR_SH_QPN         2
`define SFR_SH_EPOCH       4
`define SFR_SH_PSN         6
`define SFR_SH_PAYLEN      9
`define SFR_SH_MLEN        11
`define SFR_SH_MOFF        15
`define SFR_SH_VA          19
`define SFR_SH_RKEY        27
`define SFR_SH_CODE        30
`define SFR_SH_ACCEPT      31

// big-endian byte swap helpers (a field's MSB goes to the LOWEST byte address)
`define SFR_BSW16(x)       {x[7:0], x[15:8]}
`define SFR_BSW24(x)       {x[7:0], x[15:8], x[23:16]}
`define SFR_BSW32(x)       {x[7:0], x[15:8], x[23:16], x[31:24]}
`define SFR_BSW64(x)       {x[7:0], x[15:8], x[23:16], x[31:24], x[39:32], x[47:40], x[55:48], x[63:56]}

// field extraction from a 272-bit SFRT header vector h (h MUST be a plain identifier: only single-level selects are used, which keeps
// the formal flow's front end happy).  Byte `o` is the MOST significant byte of the field (big-endian).
`define SFR_F16(h,o)       {h[8*(o) +: 8], h[8*((o)+1) +: 8]}
`define SFR_F24(h,o)       {h[8*(o) +: 8], h[8*((o)+1) +: 8], h[8*((o)+2) +: 8]}
`define SFR_F32(h,o)       {h[8*(o) +: 8], h[8*((o)+1) +: 8], h[8*((o)+2) +: 8], h[8*((o)+3) +: 8]}
`define SFR_F64(h,o)       {h[8*(o) +: 8], h[8*((o)+1) +: 8], h[8*((o)+2) +: 8], h[8*((o)+3) +: 8], h[8*((o)+4) +: 8], h[8*((o)+5) +: 8], h[8*((o)+6) +: 8], h[8*((o)+7) +: 8]}
`define SFR_H_VF(h)        h[8*`SFR_SH_VF +: 8]
`define SFR_H_OPC(h)       h[8*`SFR_SH_OPC +: 8]
`define SFR_H_QPN(h)       `SFR_F16(h, `SFR_SH_QPN)
`define SFR_H_EPOCH(h)     `SFR_F16(h, `SFR_SH_EPOCH)
`define SFR_H_PSN(h)       `SFR_F24(h, `SFR_SH_PSN)
`define SFR_H_PAYLEN(h)    `SFR_F16(h, `SFR_SH_PAYLEN)
`define SFR_H_MLEN(h)      `SFR_F32(h, `SFR_SH_MLEN)
`define SFR_H_MOFF(h)      `SFR_F32(h, `SFR_SH_MOFF)
`define SFR_H_VA(h)        `SFR_F64(h, `SFR_SH_VA)
`define SFR_H_RKEY(h)      `SFR_F32(h, `SFR_SH_RKEY)
`define SFR_H_CODE(h)      h[8*`SFR_SH_CODE +: 8]
`define SFR_H_ACCEPT(h)    `SFR_F24(h, `SFR_SH_ACCEPT)

// ---- work request / completion / status codes -------------------------------------------------------------------
`define SFR_WOP_SEND       4'd1
`define SFR_WOP_WRITE      4'd2
`define SFR_WOP_READ       4'd3
`define SFR_WOP_RECV       4'd4          // CQE only
`define SFR_W2_SEND        2'd1          // 2-bit forms used inside the queues / request table
`define SFR_W2_WRITE       2'd2
`define SFR_W2_READ        2'd3

`define SFR_POST_OK        3'd0
`define SFR_POST_OPCODE    3'd1
`define SFR_POST_STATE     3'd2
`define SFR_POST_LEN       3'd3
`define SFR_POST_FIELDS    3'd4
`define SFR_POST_RANGE     3'd5

`define SFR_CQ_OK          4'd0
`define SFR_CQ_LOC_LEN     4'd1
`define SFR_CQ_LOC_PROT    4'd2
`define SFR_CQ_FLUSH       4'd3
`define SFR_CQ_REM_ACC     4'd4
`define SFR_CQ_REM_INV     4'd5
`define SFR_CQ_REM_OP      4'd6
`define SFR_CQ_RETRY       4'd7
`define SFR_CQ_RNR         4'd8
`define SFR_CQ_LOC_OP      4'd9

`define SFR_CFG_NOP        4'd0
`define SFR_CFG_MR_SET     4'd1
`define SFR_CFG_MR_INVAL   4'd2
`define SFR_CFG_QP_MODIFY  4'd3
`define SFR_CFG_CTX_SET    4'd4

`define SFR_CS_OK          4'd0
`define SFR_CS_IDX         4'd1
`define SFR_CS_BUSY        4'd2
`define SFR_CS_EXISTS      4'd3
`define SFR_CS_DUPKEY      4'd4
`define SFR_CS_FIELDS      4'd5
`define SFR_CS_RANGE       4'd6
`define SFR_CS_NOENT       4'd7
`define SFR_CS_STATE       4'd8

// QP states
`define SFR_QP_RESET       3'd0
`define SFR_QP_INIT        3'd1
`define SFR_QP_RTR         3'd2
`define SFR_QP_RTS         3'd3
`define SFR_QP_ERR         3'd4
`define SFR_QP_DRAIN       3'd5          // internal: reset in progress

// QP error causes (diagnostic)
`define SFR_EC_NONE        4'd0
`define SFR_EC_LOCAL_PROT  4'd1
`define SFR_EC_REMOTE_NAK  4'd2
`define SFR_EC_RETRY       4'd3
`define SFR_EC_RNR         4'd4
`define SFR_EC_RESP_FATAL  4'd5
`define SFR_EC_INT         4'd6
`define SFR_EC_CFG         4'd7

// memory registry: check op encoding, access bits, fault classes
`define SFR_CK_LRD         2'd0
`define SFR_CK_LWR         2'd1
`define SFR_CK_RRD         2'd2
`define SFR_CK_RWR         2'd3

`define SFR_ACC_LR         0
`define SFR_ACC_LW         1
`define SFR_ACC_RR         2
`define SFR_ACC_RW         3
`define SFR_ACC_CONTIG     4

`define SFR_FT_NONE        4'd0
`define SFR_FT_BAD_OP      4'd1
`define SFR_FT_BAD_KEY     4'd2
`define SFR_FT_BAD_PD      4'd3
`define SFR_FT_BAD_DIR     4'd4
`define SFR_FT_BAD_PERM    4'd5
`define SFR_FT_BAD_LEN     4'd6
`define SFR_FT_OVERFLOW    4'd7
`define SFR_FT_RANGE       4'd8
`define SFR_FT_PAGE_CROSS  4'd9
`define SFR_FT_XLATE       4'd10
`define SFR_NFAULT         11

// ---- performance counter indices (docs/TRANSPORT_SPEC.md section 15; names in scripts/perf_names.txt) ------------------
`define SFR_PC_CYCLES          0
`define SFR_PC_OPS_SEND        1
`define SFR_PC_OPS_WRITE       2
`define SFR_PC_OPS_READ        3
`define SFR_PC_OPS_RECV        4
`define SFR_PC_OPS_ERR         5
`define SFR_PC_OPS_FLUSHED     6
`define SFR_PC_BYTES_SEND      7
`define SFR_PC_BYTES_WRITE     8
`define SFR_PC_BYTES_READ      9
`define SFR_PC_BYTES_RECV      10
`define SFR_PC_LAT_WR_SUM      11
`define SFR_PC_LAT_WR_CNT      12
`define SFR_PC_LAT_WR_MIN      13
`define SFR_PC_LAT_WR_MAX      14
`define SFR_PC_LAT_RD_SUM      15
`define SFR_PC_LAT_RD_CNT      16
`define SFR_PC_LAT_RD_MIN      17
`define SFR_PC_LAT_RD_MAX      18
`define SFR_PC_LAT_SD_SUM      19
`define SFR_PC_LAT_SD_CNT      20
`define SFR_PC_LAT_SD_MIN      21
`define SFR_PC_LAT_SD_MAX      22
`define SFR_PC_SQ_OCC_MAX      23
`define SFR_PC_RQ_OCC_MAX      24
`define SFR_PC_CQ_OCC_MAX      25
`define SFR_PC_WIN_OCC_MAX     26
`define SFR_PC_SQ_OCC_SUM      27
`define SFR_PC_RQ_OCC_SUM      28
`define SFR_PC_CQ_OCC_SUM      29
`define SFR_PC_WIN_OCC_SUM     30
`define SFR_PC_RETRY_TIMEOUT   31
`define SFR_PC_RETRY_NAK       32
`define SFR_PC_RETRY_RNR       33
`define SFR_PC_TX_RETX         34
`define SFR_PC_RX_DUP          35
`define SFR_PC_RX_OOS          36
`define SFR_PC_RX_NAK          37
`define SFR_PC_TX_NAK          38
`define SFR_PC_RX_ACK_STALE    39
`define SFR_PC_RX_RESP_DROP    40
`define SFR_PC_EPSN_ACCEPTS    41
`define SFR_PC_CPSN_COMMITS    42
`define SFR_PC_STALL_TXLINK    43
`define SFR_PC_STALL_WINDOW    44
`define SFR_PC_STALL_RDLIM     45
`define SFR_PC_STALL_SQFULL    46
`define SFR_PC_STALL_CQCRED    47
`define SFR_PC_STALL_RXBUF     48
`define SFR_PC_DMA_RD_BYTES    49
`define SFR_PC_DMA_RD_BUSY     50
`define SFR_PC_DMA_WR_BYTES    51
`define SFR_PC_DMA_WR_BUSY     52
`define SFR_PC_GUARD_VIOL      53
`define SFR_PC_MR_FAULT_TOTAL  54
`define SFR_PC_MR_FAULT_BASE   55      // + fault class 1..10  -> 56..65
`define SFR_PC_TX_FRAMES       66
`define SFR_PC_RX_FRAMES       67
`define SFR_PC_RX_DROP_LEN     68
`define SFR_PC_RX_DROP_KEEP    69
`define SFR_PC_RX_DROP_MACERR  70
`define SFR_PC_RX_DROP_ETYPE   71
`define SFR_PC_RX_DROP_MAC     72
`define SFR_PC_RX_DROP_VER     73
`define SFR_PC_RX_DROP_OPCODE  74
`define SFR_PC_RX_DROP_QPN     75
`define SFR_PC_RX_DROP_EPOCH   76
`define SFR_PC_RX_DROP_STATE   77
`define SFR_PC_RX_UNSUPP_OP    78
`define SFR_PC_POST_REJ_OPCODE 79
`define SFR_PC_POST_REJ_STATE  80
`define SFR_PC_POST_REJ_LEN    81
`define SFR_PC_POST_REJ_FIELDS 82
`define SFR_PC_POST_REJ_RANGE  83
`define SFR_PC_RX_DUP_RD_FAULT 84
`define SFR_PC_RX_NAK_BADCODE  85
`define SFR_PC_REQ_ACCEPTED    86
`define SFR_PC_WR_COMMITTED    87
`define SFR_PC_BYTES_TX_PAY    88
`define SFR_PC_BYTES_RX_PAY    89
`define SFR_PC_RNR_SENT        90
`define SFR_PC_NUM             91

`endif
