// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_wqe
//
// Bounded send queue (SQ) and receive queue (RQ) with post-time validation.
//   * A post is a handshake (post_valid && post_ready); `post_ready` is low when the queue is full or no CQ credit is free
//     (BACK-PRESSURE: a post is never dropped).
//   * One cycle after the handshake the post STATUS is returned.  A rejected WQE (unsupported opcode, wrong QP state, bad length,
//     reserved flags, 64-bit wrap) is NOT enqueued, takes no slot and no CQ credit and has no effect on QP state (spec 6.3).
//   * The queue heads are presented FWFT to the QP controller; `*_pop` consumes the head.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none

module sf_rdma_wqe #(
  parameter int SQ_DEPTH      = 8,           // power of two
  parameter int RQ_DEPTH      = 8,           // power of two
  parameter int MAX_MSG_BYTES = 1048576
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        clear,            // QP reset: empty both queues (the flush has already completed every WQE)
  input  wire logic [2:0]  qp_state,
  // ---- send-queue post port ------------------------------------------------------------------------------------------
  input  wire logic        sq_post_valid,
  output logic             sq_post_ready,
  input  wire logic [3:0]  sq_post_op,
  input  wire logic [63:0] sq_post_wr_id,
  input  wire logic [63:0] sq_post_laddr,
  input  wire logic [31:0] sq_post_lkey,
  input  wire logic [31:0] sq_post_len,
  input  wire logic [63:0] sq_post_raddr,
  input  wire logic [31:0] sq_post_rkey,
  input  wire logic [3:0]  sq_post_flags,
  output logic             sq_post_rsp_valid,
  output logic [2:0]       sq_post_rsp_status,
  // ---- receive-queue post port ---------------------------------------------------------------------------------------
  input  wire logic        rq_post_valid,
  output logic             rq_post_ready,
  input  wire logic [63:0] rq_post_wr_id,
  input  wire logic [63:0] rq_post_addr,
  input  wire logic [31:0] rq_post_lkey,
  input  wire logic [31:0] rq_post_len,
  output logic             rq_post_rsp_valid,
  output logic [2:0]       rq_post_rsp_status,
  // ---- CQ credit (from the completion unit) -------------------------------------------------------------------------
  input  wire logic        credits_ge1,
  input  wire logic        credits_ge2,
  output logic             sq_take,          // an OK post reserved one CQ credit this cycle
  output logic             rq_take,
  // ---- heads --------------------------------------------------------------------------------------------------------
  output logic             sq_head_valid,
  input  wire logic        sq_pop,
  output logic [1:0]       sq_head_op,
  output logic [63:0]      sq_head_wr_id,
  output logic [63:0]      sq_head_laddr,
  output logic [31:0]      sq_head_lkey,
  output logic [31:0]      sq_head_len,
  output logic [63:0]      sq_head_raddr,
  output logic [31:0]      sq_head_rkey,
  output logic             rq_head_valid,
  input  wire logic        rq_pop,
  output logic [63:0]      rq_head_wr_id,
  output logic [63:0]      rq_head_addr,
  output logic [31:0]      rq_head_lkey,
  output logic [31:0]      rq_head_len,
  // ---- status / events ----------------------------------------------------------------------------------------------
  output logic [$clog2(SQ_DEPTH):0] sq_occ,
  output logic [$clog2(RQ_DEPTH):0] rq_occ,
  output logic             ev_rej_opcode,
  output logic             ev_rej_state,
  output logic             ev_rej_len,
  output logic             ev_rej_fields,
  output logic             ev_rej_range,
  output logic             ev_stall_sqfull,  // a post is waiting because the SQ is full
  output logic             ev_stall_cqcred   // a post is waiting because no CQ credit is free
);
  localparam int SQB = $clog2(SQ_DEPTH);
  localparam int RQB = $clog2(RQ_DEPTH);

  // ---- storage -----------------------------------------------------------------------------------------------------
  logic [1:0]  s_op   [0:SQ_DEPTH-1];
  logic [63:0] s_wr   [0:SQ_DEPTH-1];
  logic [63:0] s_la   [0:SQ_DEPTH-1];
  logic [31:0] s_lk   [0:SQ_DEPTH-1];
  logic [31:0] s_ln   [0:SQ_DEPTH-1];
  logic [63:0] s_ra   [0:SQ_DEPTH-1];
  logic [31:0] s_rk   [0:SQ_DEPTH-1];
  logic [SQB:0] s_wp, s_rp;

  logic [63:0] r_wr   [0:RQ_DEPTH-1];
  logic [63:0] r_ad   [0:RQ_DEPTH-1];
  logic [31:0] r_lk   [0:RQ_DEPTH-1];
  logic [31:0] r_ln   [0:RQ_DEPTH-1];
  logic [RQB:0] r_wp, r_rp;

  wire sq_full  = (s_wp - s_rp) == (SQB+1)'(SQ_DEPTH);
  wire sq_empty = (s_wp == s_rp);
  wire rq_full  = (r_wp - r_rp) == (RQB+1)'(RQ_DEPTH);
  wire rq_empty = (r_wp == r_rp);
  assign sq_occ = s_wp - s_rp;
  assign rq_occ = r_wp - r_rp;

  // ---- post validation (combinational on the offered fields) ---------------------------------------------------------------
  logic [2:0]  sq_st, rq_st;
  logic [64:0] sq_rend, rq_end;
  logic        sq_needs_range;
  always_comb begin
    sq_rend = {1'b0, sq_post_raddr} + {33'b0, sq_post_len};
    rq_end  = {1'b0, rq_post_addr}  + {33'b0, rq_post_len};
    sq_needs_range = (sq_post_op == `SFR_WOP_WRITE) || (sq_post_op == `SFR_WOP_READ);
    sq_st = `SFR_POST_OK;
    if      (qp_state != `SFR_QP_RTS)                                                   sq_st = `SFR_POST_STATE;
    else if (sq_post_op != `SFR_WOP_SEND && sq_post_op != `SFR_WOP_WRITE && sq_post_op != `SFR_WOP_READ) sq_st = `SFR_POST_OPCODE;
    else if (sq_post_flags != 4'd0)                                                     sq_st = `SFR_POST_FIELDS;
    else if (sq_post_len > MAX_MSG_BYTES || (sq_needs_range && sq_post_len == 32'd0))   sq_st = `SFR_POST_LEN;
    else if (sq_needs_range && sq_rend[64] && (|sq_rend[63:0]))                         sq_st = `SFR_POST_RANGE;
    rq_st = `SFR_POST_OK;
    if      (qp_state != `SFR_QP_INIT && qp_state != `SFR_QP_RTR && qp_state != `SFR_QP_RTS) rq_st = `SFR_POST_STATE;
    else if (rq_post_len > MAX_MSG_BYTES)                                               rq_st = `SFR_POST_LEN;
    else if (rq_end[64] && (|rq_end[63:0]))                                             rq_st = `SFR_POST_RANGE;
  end

  assign sq_post_ready = !sq_full && credits_ge1;
  wire   sq_hs   = sq_post_valid && sq_post_ready;
  assign sq_take = sq_hs && (sq_st == `SFR_POST_OK);
  assign rq_post_ready = !rq_full && (sq_take ? credits_ge2 : credits_ge1);
  wire   rq_hs   = rq_post_valid && rq_post_ready;
  assign rq_take = rq_hs && (rq_st == `SFR_POST_OK);

  assign ev_stall_sqfull = sq_post_valid && sq_full;
  assign ev_stall_cqcred = (sq_post_valid && !sq_full && !credits_ge1) || (rq_post_valid && !rq_full && !rq_post_ready);

  assign ev_rej_opcode = sq_hs && sq_st == `SFR_POST_OPCODE;
  assign ev_rej_state  = (sq_hs && sq_st == `SFR_POST_STATE) || (rq_hs && rq_st == `SFR_POST_STATE);
  assign ev_rej_len    = (sq_hs && sq_st == `SFR_POST_LEN)   || (rq_hs && rq_st == `SFR_POST_LEN);
  assign ev_rej_fields = sq_hs && sq_st == `SFR_POST_FIELDS;
  assign ev_rej_range  = (sq_hs && sq_st == `SFR_POST_RANGE) || (rq_hs && rq_st == `SFR_POST_RANGE);

  // ---- heads ---------------------------------------------------------------------------------------------------------
  assign sq_head_valid = !sq_empty;
  assign sq_head_op    = s_op[s_rp[SQB-1:0]];
  assign sq_head_wr_id = s_wr[s_rp[SQB-1:0]];
  assign sq_head_laddr = s_la[s_rp[SQB-1:0]];
  assign sq_head_lkey  = s_lk[s_rp[SQB-1:0]];
  assign sq_head_len   = s_ln[s_rp[SQB-1:0]];
  assign sq_head_raddr = s_ra[s_rp[SQB-1:0]];
  assign sq_head_rkey  = s_rk[s_rp[SQB-1:0]];
  assign rq_head_valid = !rq_empty;
  assign rq_head_wr_id = r_wr[r_rp[RQB-1:0]];
  assign rq_head_addr  = r_ad[r_rp[RQB-1:0]];
  assign rq_head_lkey  = r_lk[r_rp[RQB-1:0]];
  assign rq_head_len   = r_ln[r_rp[RQB-1:0]];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s_wp <= '0; s_rp <= '0; r_wp <= '0; r_rp <= '0;
      sq_post_rsp_valid <= 1'b0; sq_post_rsp_status <= 3'd0;
      rq_post_rsp_valid <= 1'b0; rq_post_rsp_status <= 3'd0;
    end else begin
      sq_post_rsp_valid <= sq_hs;
      if (sq_hs) sq_post_rsp_status <= sq_st;
      rq_post_rsp_valid <= rq_hs;
      if (rq_hs) rq_post_rsp_status <= rq_st;
      if (clear) begin
        s_wp <= '0; s_rp <= '0; r_wp <= '0; r_rp <= '0;
      end else begin
        if (sq_take) begin
          s_op[s_wp[SQB-1:0]] <= sq_post_op[1:0];  s_wr[s_wp[SQB-1:0]] <= sq_post_wr_id;
          s_la[s_wp[SQB-1:0]] <= sq_post_laddr;    s_lk[s_wp[SQB-1:0]] <= sq_post_lkey;
          s_ln[s_wp[SQB-1:0]] <= sq_post_len;      s_ra[s_wp[SQB-1:0]] <= sq_post_raddr;
          s_rk[s_wp[SQB-1:0]] <= sq_post_rkey;
          s_wp <= s_wp + 1'b1;
        end
        if (sq_pop && !sq_empty) s_rp <= s_rp + 1'b1;
        if (rq_take) begin
          r_wr[r_wp[RQB-1:0]] <= rq_post_wr_id;    r_ad[r_wp[RQB-1:0]] <= rq_post_addr;
          r_lk[r_wp[RQB-1:0]] <= rq_post_lkey;     r_ln[r_wp[RQB-1:0]] <= rq_post_len;
          r_wp <= r_wp + 1'b1;
        end
        if (rq_pop && !rq_empty) r_rp <= r_rp + 1'b1;
      end
    end
  end
endmodule
`default_nettype wire
