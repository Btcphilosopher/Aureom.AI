// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_dma_wr   (data-movement engine, payload stream -> memory)
//
// Writes a payload stream to byte-granular physical address `pa` using word writes with byte strobes (vendored sf_stream_dma_align
// gearbox performs the re-alignment).  Commands:
//     WRITE   (kind 0)  consume ceil(len/B) beats from the receive buffer and write them at pa.
//     DISCARD (kind 1)  consume the beats of a rejected/duplicate frame and write NOTHING (keeps the buffer in frame order).
// EVERY WRITE command is checked against the registry guard before the first beat is consumed; a failing command is converted to
// DISCARD (no memory write at all) and raises `viol`.
// COMMIT: `done_valid` pulses once per WRITE command, in order, after the memory acknowledged EVERY word of that command (committed).
// Memory acknowledgements are in order, one per accepted word; at most MEM_WR_OUT words are outstanding.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_rdma_dma_wr #(
  parameter int DW         = 64,
  parameter int PA_W       = 32,
  parameter int RID_W      = 3,
  parameter int CTX_W      = 2,
  parameter int MEM_WR_OUT = 4,                // power of two
  parameter int CMD_Q      = 4,                // power of two
  localparam int B         = DW/8,
  localparam int LB        = $clog2(DW/8)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clear,
  // command
  input  wire logic              cmd_valid,
  output logic                   cmd_ready,
  input  wire logic              cmd_discard,
  input  wire logic [PA_W-1:0]   cmd_pa,
  input  wire logic [15:0]       cmd_len,
  input  wire logic [RID_W-1:0]  cmd_rid,
  input  wire logic [CTX_W-1:0]  cmd_ctx,
  output logic                   viol,
  // registry guard
  output logic [RID_W-1:0]       g_rid,
  output logic [PA_W-1:0]        g_pa,
  output logic [15:0]            g_len,
  input  wire logic              g_ok,
  // payload source (receive buffer)
  input  wire logic              pl_valid,
  output logic                   pl_ready,
  input  wire logic [DW-1:0]     pl_data,
  // memory write port
  output logic                   mwr_valid,
  input  wire logic              mwr_ready,
  output logic [PA_W-1:0]        mwr_addr,
  output logic [DW-1:0]          mwr_data,
  output logic [B-1:0]           mwr_strb,
  output logic [CTX_W-1:0]       mwr_ctx,
  input  wire logic              mwr_ack_valid,
  input  wire logic              mwr_ack_err,
  // completion / status
  output logic                   done_valid,
  output logic                   done_err,
  output logic                   idle,
  output logic [LB:0]            bytes_n
);
  localparam int WB = $clog2(MEM_WR_OUT);

  // ---- command FIFO ----------------------------------------------------------------------------------------------------------
  localparam int CW = 2 + PA_W + 16 + CTX_W;                  // {converted, discard, pa, len, ctx}
  wire cq_full, cq_empty, cq_ovf, cq_unf;
  wire [$clog2(CMD_Q):0] cq_cnt;
  wire [CW-1:0] cq_rd;
  logic cq_pop;
  assign g_rid = cmd_rid; assign g_pa = cmd_pa; assign g_len = cmd_len;
  assign cmd_ready = !cq_full;
  wire cmd_take = cmd_valid && cmd_ready;
`ifdef SF_SIM_FAULT_INJECT
  // SIMULATION ONLY (never defined for synthesis, lint or the shipped benches): force the guard of the N-th accepted write command to
  // fail (+GUARD_WR_N=n), to exercise the recovery path of the defence-in-depth mechanism (independent review, F-09).
  integer inj_n, inj_cnt;
  initial begin inj_n = 0; inj_cnt = 0; if (!$value$plusargs("GUARD_WR_N=%d", inj_n)) inj_n = 0; end
  always_ff @(posedge clk) if (cmd_valid && cmd_ready && !cmd_discard) inj_cnt <= inj_cnt + 1;
  wire gd_ok = g_ok && !((inj_n != 0) && cmd_valid && cmd_ready && !cmd_discard && ((inj_cnt + 1) == inj_n));
`else
  wire gd_ok = g_ok;
`endif
  wire cmd_conv = cmd_take && !cmd_discard && !gd_ok;          // guard failure -> converted to DISCARD
  logic viol_q;
  assign viol = viol_q;
  sf_rdma_fifo #(.WIDTH(CW), .DEPTH(CMD_Q)) u_cq (
    .clk(clk), .rst_n(rst_n), .clear(clear), .push(cmd_take),
    .wdata({(!cmd_discard && !gd_ok), (cmd_discard || !gd_ok), cmd_pa, cmd_len, cmd_ctx}),
    .pop(cq_pop), .rdata(cq_rd), .full(cq_full), .empty(cq_empty), .count(cq_cnt), .ovf(cq_ovf), .unf(cq_unf));
  wire             c_conv = cq_rd[CW-1];
  wire             c_disc = cq_rd[CW-2];
  wire [PA_W-1:0]  c_pa   = cq_rd[CW-3 -: PA_W];
  wire [15:0]      c_len  = cq_rd[CTX_W+16-1 -: 16];
  wire [CTX_W-1:0] c_ctx  = cq_rd[CTX_W-1:0];

  // ---- active command --------------------------------------------------------------------------------------------------------
  logic              act, disc, conv_q;
  logic [PA_W-1:0]   addr;
  logic [LB-1:0]     off;
  logic [15:0]       in_left, out_left;
  logic              first_out;
  logic [CTX_W-1:0]  ctx;
  assign cq_pop = !cq_empty && !act;

  // gearbox
  wire [31:0]  il32   = 32'(in_left);
  wire [31:0]  inn32  = (32'(B) < il32) ? 32'(B) : il32;
  wire [LB:0]  in_n   = inn32[LB:0];
  logic [DW-1:0] in_data_m;
  always_comb for (int i = 0; i < B; i++) in_data_m[8*i +: 8] = (i < inn32) ? pl_data[8*i +: 8] : 8'h00;

  wire         gb_in_ready;
  wire         gb_push = act && !disc && pl_valid && (in_left != 16'd0) && gb_in_ready;
  assign pl_ready = act && (in_left != 16'd0) && (disc || gb_in_ready);
  wire         pl_take = pl_valid && pl_ready;

  wire [31:0]  ol32     = 32'(out_left);
  wire [31:0]  room32   = 32'(B) - 32'(off);
  wire [31:0]  pn_first = (room32 < ol32) ? room32 : ol32;
  wire [31:0]  pn_rest  = (32'(B) < ol32) ? 32'(B) : ol32;
  wire [31:0]  pn32     = first_out ? pn_first : pn_rest;
  wire [LB:0]  pop_n    = pn32[LB:0];
  wire [LB-1:0] pop_lo  = first_out ? off : '0;

  wire         gb_pop_ok;
  wire [DW-1:0] gb_out;
  wire [B-1:0]  gb_strb;
  wire [LB+1:0] gb_cnt;

  // outstanding-write tag FIFO: 1 = last word of a command
  wire tf_full, tf_empty, tf_ovf, tf_unf, tf_rd;
  wire [WB:0] tf_cnt;
  wire wr_hs;
  sf_rdma_fifo #(.WIDTH(1), .DEPTH(MEM_WR_OUT)) u_tf (
    .clk(clk), .rst_n(rst_n), .clear(clear), .push(wr_hs), .wdata(out_left <= 16'(pn32)),
    .pop(mwr_ack_valid), .rdata(tf_rd), .full(tf_full), .empty(tf_empty), .count(tf_cnt), .ovf(tf_ovf), .unf(tf_unf));

  assign mwr_valid = act && !disc && (out_left != 16'd0) && gb_pop_ok && !tf_full;
  assign wr_hs     = mwr_valid && mwr_ready;
  assign mwr_addr  = addr;
  assign mwr_data  = gb_out;
  assign mwr_strb  = gb_strb;
  assign mwr_ctx   = ctx;
  assign bytes_n   = wr_hs ? pop_n : '0;

  sf_stream_dma_align #(.DW(DW)) u_gb (
    .clk(clk), .rst_n(rst_n), .flush(clear),
    .in_valid(gb_push), .in_ready(gb_in_ready), .in_data(in_data_m), .in_nbytes(in_n),
    .pop_req(wr_hs), .pop_lo(pop_lo), .pop_n(pop_n), .pop_ok(gb_pop_ok),
    .out_data(gb_out), .out_strb(gb_strb), .cnt(gb_cnt));

  assign idle = cq_empty && !act && tf_empty;

  logic err_acc;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      act <= 1'b0; disc <= 1'b0; conv_q <= 1'b0; addr <= '0; off <= '0; in_left <= '0; out_left <= '0; first_out <= 1'b0; ctx <= '0;
      done_valid <= 1'b0; done_err <= 1'b0; err_acc <= 1'b0; viol_q <= 1'b0;
    end else if (clear) begin
      act <= 1'b0; done_valid <= 1'b0; err_acc <= 1'b0; viol_q <= 1'b0;
    end else begin
      done_valid <= 1'b0;
      viol_q     <= cmd_conv;
      if (cq_pop) begin
        act <= 1'b1; disc <= c_disc; conv_q <= c_conv; addr <= {c_pa[PA_W-1:LB], {LB{1'b0}}}; off <= c_pa[LB-1:0];
        in_left <= c_len; out_left <= c_len; first_out <= 1'b1; ctx <= c_ctx;
      end
      if (pl_take) in_left <= in_left - 16'(inn32);
      if (wr_hs) begin
        addr      <= addr + PA_W'(B);
        out_left  <= out_left - 16'(pn32);
        first_out <= 1'b0;
      end
      // command complete (all beats consumed; for WRITE also all words issued)
      if (act && (in_left == 16'd0) && (disc || out_left == 16'd0) && !conv_q) act <= 1'b0;
      // commit: the ack of the last word of a command
      if (mwr_ack_valid) begin
        if (tf_rd) begin done_valid <= 1'b1; done_err <= err_acc || mwr_ack_err; err_acc <= 1'b0; end
        else if (mwr_ack_err) err_acc <= 1'b1;
      end
      // A command CONVERTED to a discard by the guard (it never touched memory) still has a pending-completion tag at the receive
      // processor.  It reports `done` with an error, IN ORDER (after every earlier write was acknowledged): without it the tag stayed
      // for ever and the QP reset could never drain (found by the independent review, F-09).
      if (act && conv_q && (in_left == 16'd0) && tf_empty && !mwr_ack_valid && !done_valid) begin
        act <= 1'b0; done_valid <= 1'b1; done_err <= 1'b1;
      end
    end
  end
endmodule
`default_nettype wire
