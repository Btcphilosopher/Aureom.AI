// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_transport_adapter
//
// Carries RDMA operation metadata (the 34-byte SFRT header) and payloads over a streaming frame interface that follows the
// PacketCore (P62) stream contract (AXI-S subset: byte 0 = data[7:0] of beat 0, contiguous low-order keep on the last beat,
// FCS excluded, err on the last beat).  THIS IS NOT A RoCEv2 / INFINIBAND STACK: the Ethernet shim carries a private EtherType.
//
// TRANSMIT  three header ports (0 requester requests, 1 read responses, 2 ACK/NAK control).  A header is accepted only if the
//           payload space for its frame is RESERVED (ports 0/1); the payload is then pushed (always accepted).  A frame leaves
//           only when COMPLETE (store-and-forward: tx_valid never drops mid-frame, no MAC under-run).  Frame arbitration:
//           control first, then round-robin (vendored sf_rr_arb).  Output slice = vendored sfb_skid_buffer.
// RECEIVE   store-and-forward with commit/abort: the header is parsed on the beat that completes it, the payload (only the bytes
//           the header announces; pad is discarded) goes to a ring, and the frame is COMMITTED only if the whole frame passed every
//           check (spec 3.4).  A dropped frame leaves nothing behind.  When storage is full `rx_ready` falls (back-pressure).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none

module sf_rdma_transport_adapter #(
  parameter int DW        = 64,                       // 32 / 64 / 128
  parameter int MTU       = 256,                      // max payload bytes per frame
  parameter int HQ_DEPTH  = 4,                        // header FIFO depth (power of two)
  localparam int B        = DW/8,
  localparam int LB       = $clog2(DW/8),
  localparam int HB       = 48/(DW/8),                // header beats
  localparam int TXB      = 2*(MTU/(DW/8)),           // TX payload ring depth per port (beats, power of two)
  localparam int RXB      = 2*(MTU/(DW/8))            // RX payload ring depth (beats)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // ---- trusted per-connection configuration (from the QP) --------------------------------------------------------------------
  input  wire logic [47:0]       cfg_local_mac,
  input  wire logic [47:0]       cfg_peer_mac,
  input  wire logic [15:0]       cfg_local_qpn,
  input  wire logic [15:0]       cfg_epoch,
  input  wire logic              cfg_req_en,           // requests are accepted
  input  wire logic              cfg_resp_en,          // responses / ACK / NAK are accepted
  // ---- link stream ------------------------------------------------------------------------------------------------------------
  output logic                   tx_valid,
  input  wire logic              tx_ready,
  output logic [DW-1:0]          tx_data,
  output logic [B-1:0]           tx_keep,
  output logic                   tx_last,
  input  wire logic              rx_valid,
  output logic                   rx_ready,
  input  wire logic [DW-1:0]     rx_data,
  input  wire logic [B-1:0]      rx_keep,
  input  wire logic              rx_last,
  input  wire logic              rx_err,
  // ---- transmit header ports --------------------------------------------------------------------------------------------------
  input  wire logic [2:0]        txh_valid,
  output logic [2:0]             txh_ready,
  input  wire logic [3*272-1:0]  txh_sh,
  // payload push for ports 0 and 1
  input  wire logic [1:0]        txp_valid,
  input  wire logic [2*DW-1:0]   txp_data,
  input  wire logic [1:0]        txp_last,             // the beat is the last of its frame's payload
  input  wire logic [1:0]        txp_err,              // (with the last beat) the payload fetch failed: the frame is garbage, it must NEVER leave
  input  wire logic              tx_drop_req,          // QP in ERR: queued REQUEST frames (port 0) are discarded when they would start; responses are not
  input  wire logic              tx_hold,              // do not START new frames (reset drain)
  input  wire logic              tx_flush,             // discard queued, not-started frames (only with tx_quiet)
  output logic                   tx_quiet,
  // ---- receive: header FIFO and payload ----------------------------------------------------------------------------------------
  output logic                   rxh_valid,
  output logic [271:0]           rxh_sh,
  input  wire logic              rxh_pop,
  output logic                   rxp_valid,
  input  wire logic              rxp_ready,
  output logic [DW-1:0]          rxp_data,
  output logic [B-1:0]           rxp_keep,
  output logic                   rxp_last,
  input  wire logic              rx_flush,
  // ---- events (single-cycle pulses) -----------------------------------------------------------------------------------------------
  output logic                   ev_tx_abort,          // a queued frame was discarded instead of transmitted
  output logic                   ev_tx_abort_err,      //   ... because its payload fetch failed (memory error), not because of the QP state
  output logic                   tx_abort_port,        //   0 requester request, 1 read response
  output logic [23:0]            tx_abort_psn,
  output logic                   ev_tx_frame,
  output logic                   ev_rx_frame,
  output logic                   ev_stall_txlink,
  output logic                   ev_stall_rxbuf,
  output logic [8:0]             ev_drop,              // [0]len [1]keep [2]macerr [3]ethertype [4]mac [5]ver [6]opcode [7]qpn [8]epoch (state in ev_drop_state)
  output logic                   ev_drop_state,
  output logic [15:0]            ev_rx_paybytes,
  output logic [15:0]            ev_tx_paybytes
);
  // ---------------------------------------------------------------------------------------------------------------------------
  // TRANSMIT
  // ---------------------------------------------------------------------------------------------------------------------------
  localparam int TAB = $clog2(TXB);

  function automatic [31:0] nbeats_of(input [15:0] paylen);
    nbeats_of = (32'(paylen) + 32'(B-1)) >> LB;
  endfunction

  // per-port header FIFOs.  All per-port selects are made inside a generate block (constant indices): Yosys cannot elaborate a
  // part-select of a part-select with a loop variable.
  wire [2:0]        hq_full, hq_empty;
  wire [3*272-1:0]  hq_rd_f;
  logic [2:0]       hq_pop;
  logic [TAB:0]     t_wp [0:1];
  logic [TAB:0]     t_rp [0:1];
  logic [TAB+1:0]   t_res [0:1];                // reserved beats (accepted headers not yet fully transmitted)
  logic [DW-1:0]    t_ring0 [0:TXB-1];
  logic [DW-1:0]    t_ring1 [0:TXB-1];
  wire [2:0]        hdr_hs;
  wire [2:0]        pz_head;                    // poison flag of the oldest frame (with payload) of each port
  logic [1:0]       pz_pop;
  wire [2:0]        fr_ready;                   // head frame complete and ready to start
  wire [3*32-1:0]   hs_need_f;                  // payload beats of the header offered on each port

  genvar gp;
  generate
    for (gp = 0; gp < 3; gp++) begin : g_tx
      wire [271:0] sh_in = txh_sh[gp*272 +: 272];
      wire [271:0] sh_hd;
      wire [31:0]  need_in = (gp == 2) ? 32'd0 : nbeats_of(`SFR_H_PAYLEN(sh_in));
      if (gp == 2) begin : g_ctl
        assign txh_ready[gp] = !hq_full[gp];
        assign fr_ready[gp]  = !hq_empty[gp];
      end else begin : g_data
        wire [TAB:0] avl = t_wp[gp] - t_rp[gp];  // pointer-width difference (modular)
        wire [31:0]  need_hd = nbeats_of(`SFR_H_PAYLEN(sh_hd));
        assign txh_ready[gp] = !hq_full[gp] && ((32'(t_res[gp]) + need_in) <= 32'(TXB));
        assign fr_ready[gp]  = !hq_empty[gp] && (32'(avl) >= need_hd);
      end
      assign hdr_hs[gp]                 = txh_valid[gp] && txh_ready[gp];
      if (gp != 2) begin : g_pz
        // one flag per frame that has a payload, pushed with the LAST beat of that payload, popped when the frame starts / is dropped
        sf_rdma_fifo #(.WIDTH(1), .DEPTH(HQ_DEPTH)) u_pz (
          .clk(clk), .rst_n(rst_n), .clear(tx_flush), .push(txp_valid[gp] && txp_last[gp]), .wdata(txp_err[gp]),
          .pop(pz_pop[gp]), .rdata(pz_head[gp]), .full(), .empty(), .count(), .ovf(), .unf());
      end else begin : g_pz2
        assign pz_head[gp] = 1'b0;
      end
      assign hs_need_f[gp*32 +: 32]     = need_in;
      assign hq_rd_f[gp*272 +: 272]     = sh_hd;
      sf_rdma_fifo #(.WIDTH(272), .DEPTH(HQ_DEPTH)) u_hq (
        .clk(clk), .rst_n(rst_n), .clear(tx_flush), .push(hdr_hs[gp]), .wdata(sh_in),
        .pop(hq_pop[gp]), .rdata(sh_hd), .full(hq_full[gp]), .empty(hq_empty[gp]), .count(), .ovf(), .unf());
    end
  endgenerate

  // arbitration: control (2) first, then round-robin between 0 and 1
  logic        busy;
  wire         go_ok = !busy && !tx_hold;
  wire [1:0]   rr_req = fr_ready[1:0];
  wire [1:0]   rr_gnt_unused; wire [0:0] rr_idx; wire rr_any;
  logic        start;
  sf_rr_arb #(.N(2)) u_rr (.clk(clk), .rst_n(rst_n), .req(rr_req), .advance(start && !fr_ready[2]), .gnt(rr_gnt_unused), .gnt_idx(rr_idx), .any(rr_any));
  wire         sel2 = fr_ready[2];
  wire [1:0]   sel_port = sel2 ? 2'd2 : {1'b0, rr_idx[0]};
  assign start = go_ok && (fr_ready[2] || rr_any);

  // current frame
  logic [1:0]    c_port;
  logic [383:0]  c_fh;
  logic [15:0]   c_paylen;
  logic [31:0]   c_need;
  logic [31:0]   c_nbeats;
  logic [B-1:0]  c_lastkeep;
  logic [31:0]   k;                             // beat index

  logic [47:0] pm, lm;
  always_comb begin
    pm = {cfg_peer_mac[7:0],  cfg_peer_mac[15:8],  cfg_peer_mac[23:16],  cfg_peer_mac[31:24],  cfg_peer_mac[39:32],  cfg_peer_mac[47:40]};
    lm = {cfg_local_mac[7:0], cfg_local_mac[15:8], cfg_local_mac[23:16], cfg_local_mac[31:24], cfg_local_mac[39:32], cfg_local_mac[47:40]};
  end

  // frame length bookkeeping at start
  logic [31:0] s_len, s_nb, s_lastb;
  logic [271:0] s_sh;
  logic [15:0]  s_paylen;
  always_comb begin
    case (sel_port)
      2'd0:    s_sh = hq_rd_f[0*272 +: 272];
      2'd1:    s_sh = hq_rd_f[1*272 +: 272];
      default: s_sh = hq_rd_f[2*272 +: 272];
    endcase
    s_paylen = `SFR_H_PAYLEN(s_sh);
    s_len    = (32'd48 + 32'(s_paylen) < 32'd60) ? 32'd60 : (32'd48 + 32'(s_paylen));
    s_nb     = (s_len + 32'(B-1)) >> LB;
    s_lastb  = s_len - ((s_nb - 32'd1) << LB);
  end

  assign hq_pop = {3{start}} & (3'd1 << sel_port);

  // A frame that is ready either starts (is transmitted) or is DROPPED: because its payload fetch failed (poison flag) or because it is a
  // REQUEST and the QP is in ERR ("no further frame carrying new requests is transmitted", spec 11.1).  A drop consumes the frame's header and payload beats
  // and is reported; nothing leaves on the link.
  wire [31:0]  s_need   = (sel_port == 2'd2) ? 32'd0 : nbeats_of(s_paylen);
  wire         s_poison = (s_need != 32'd0) && pz_head[sel_port];
  // (Only requests: a responder that sent a fatal NAK has already COMMITTED the earlier READs, whose queued READ_RESP frames the NAK overtook
  //  on the control port; they must still go out.)
  wire         drop_cand = ((sel_port == 2'd0) && tx_drop_req) || ((sel_port != 2'd2) && s_poison);
  wire         drop_now = start && drop_cand;
  wire         send_now = start && !drop_cand;
  always_comb begin
    pz_pop = '0;
    if (start && (s_need != 32'd0)) pz_pop[sel_port[0]] = 1'b1;
  end
  assign ev_tx_abort     = drop_now;
  assign ev_tx_abort_err = drop_now && s_poison;
  assign tx_abort_port   = sel_port[0];
  assign tx_abort_psn    = `SFR_H_PSN(s_sh);

  // beat data
  logic [DW-1:0] beat_data;
  logic [DW-1:0] pl_word;
  always_comb begin
    pl_word = '0;
    if (k >= 32'(HB) && (k - 32'(HB)) < c_need) begin
      if (c_port[0]) pl_word = t_ring1[(t_rp[1][TAB-1:0] + TAB'(k - 32'(HB)))];
      else           pl_word = t_ring0[(t_rp[0][TAB-1:0] + TAB'(k - 32'(HB)))];
    end
    if (k < 32'(HB)) beat_data = c_fh[k*DW +: DW];
    else             beat_data = pl_word;
  end
  wire         beat_last = (k == c_nbeats - 32'd1);
  wire [B-1:0] beat_keep = beat_last ? c_lastkeep : {B{1'b1}};

  wire         sk_s_ready;
  wire         sk_s_valid = busy;
  wire         beat_hs = sk_s_valid && sk_s_ready;
  wire         sk_m_valid;
  logic        frame_end;
  assign frame_end = beat_hs && beat_last;

  wire [DW+B+1-1:0] sk_m;
  sfb_skid_buffer #(.WIDTH(DW+B+1)) u_skid (
    .clk(clk), .rst_n(rst_n), .s_valid(sk_s_valid), .s_ready(sk_s_ready), .s_data({beat_last, beat_keep, beat_data}),
    .m_valid(sk_m_valid), .m_ready(tx_ready), .m_data(sk_m));
  assign tx_valid = sk_m_valid;
  assign tx_data  = sk_m[DW-1:0];
  assign tx_keep  = sk_m[DW +: B];
  assign tx_last  = sk_m[DW+B];
  assign tx_quiet = !busy && !sk_m_valid;
  assign ev_stall_txlink = tx_valid && !tx_ready;
  assign ev_tx_frame     = frame_end;
  assign ev_tx_paybytes  = frame_end ? c_paylen : 16'd0;

  // payload push (always accepted: the space was reserved with the header)
  wire [TAB-1:0] wi0 = t_wp[0][TAB-1:0];
  wire [TAB-1:0] wi1 = t_wp[1][TAB-1:0];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy <= 1'b0; k <= '0; c_port <= '0; c_fh <= '0; c_paylen <= '0; c_need <= '0; c_nbeats <= '0; c_lastkeep <= '0;
      for (int p = 0; p < 2; p++) begin t_wp[p] <= '0; t_rp[p] <= '0; t_res[p] <= '0; end
    end else begin
      if (txp_valid[0]) begin t_ring0[wi0] <= txp_data[0*DW +: DW]; end
      if (txp_valid[1]) begin t_ring1[wi1] <= txp_data[1*DW +: DW]; end
      if (tx_flush) begin
        for (int p = 0; p < 2; p++) begin t_wp[p] <= '0; t_rp[p] <= '0; t_res[p] <= '0; end
      end else begin
        for (int p = 0; p < 2; p++) begin
          if (txp_valid[p]) t_wp[p] <= t_wp[p] + 1'b1;
          t_res[p] <= t_res[p] + (hdr_hs[p] ? (TAB+2)'(hs_need_f[p*32 +: 32]) : '0)
                              - ((frame_end && c_port == 2'(p)) ? (TAB+2)'(c_need) : '0)
                              - ((drop_now && sel_port == 2'(p)) ? (TAB+2)'(s_need) : '0);
          t_rp[p] <= t_rp[p] + ((frame_end && c_port == 2'(p)) ? (TAB+1)'(c_need) : '0)
                             + ((drop_now && sel_port == 2'(p)) ? (TAB+1)'(s_need) : '0);
        end
      end
      if (send_now) begin
        busy       <= 1'b1;
        k          <= 32'd0;
        c_port     <= sel_port;
        c_paylen   <= s_paylen;
        c_need     <= (sel_port == 2'd2) ? 32'd0 : nbeats_of(s_paylen);
        c_nbeats   <= s_nb;
        c_lastkeep <= (s_lastb >= 32'(B)) ? {B{1'b1}} : (B'((1 << s_lastb[LB:0]) - 1));
        c_fh       <= {s_sh, 8'hB5, 8'h88, lm, pm};
      end else if (beat_hs) begin
        k <= k + 32'd1;
        if (beat_last) busy <= 1'b0;
      end
    end
  end

  // ---------------------------------------------------------------------------------------------------------------------------
  // RECEIVE
  // ---------------------------------------------------------------------------------------------------------------------------
  localparam int RAB = $clog2(RXB);
  logic [DW-1:0]  r_ring_d [0:RXB-1];
  logic [B-1:0]   r_ring_k [0:RXB-1];
  logic           r_ring_l [0:RXB-1];
  logic [RAB:0]   rw, rc, rrd;                    // write, commit, read pointers

  wire            rhq_full, rhq_empty;
  logic           rhq_push;
  logic [271:0]   r_sh_q;
  sf_rdma_fifo #(.WIDTH(272), .DEPTH(HQ_DEPTH)) u_rhq (
    .clk(clk), .rst_n(rst_n), .clear(rx_flush), .push(rhq_push), .wdata(r_sh_q),
    .pop(rxh_pop), .rdata(rxh_sh), .full(rhq_full), .empty(rhq_empty), .count(), .ovf(), .unf());  // verilator lint_off PINCONNECTEMPTY
  assign rxh_valid = !rhq_empty;

  wire ring_full = ((rw - rrd) == (RAB+1)'(RXB));
  assign rx_ready = !ring_full && !rhq_full && !rx_flush;   // the flush pulse is one cycle: never lose a beat
  wire   rx_hs = rx_valid && rx_ready;
  assign ev_stall_rxbuf = rx_valid && !rx_ready;

  // frame-in-progress registers
  logic [31:0]  r_cnt;                            // beat index within the frame
  logic [383:0] r_hdr;                            // header assembled so far
  logic [31:0]  r_bytes;                          // frame bytes so far
  logic [15:0]  r_pay_left;
  logic [15:0]  r_paylen;
  logic         r_hdr_done, r_store;
  logic         f_len, f_keep, f_etype, f_mac, f_ver, f_opc, f_qpn, f_epoch, f_state, f_force;

  // per-beat decode
  logic [31:0]  nbytes;
  logic         keep_ok;
  logic [DW-1:0] kmask, dmask;
  always_comb begin
    nbytes = 32'd0;
    for (int i = 0; i < B; i++) nbytes = nbytes + (rx_keep[i] ? 32'd1 : 32'd0);
    if (!rx_last) nbytes = 32'(B);
    keep_ok = rx_last ? ((rx_keep != '0) && ((rx_keep & (rx_keep + 1'b1)) == '0)) : (rx_keep == {B{1'b1}});
    for (int i = 0; i < B; i++) kmask[8*i +: 8] = (rx_last && !rx_keep[i]) ? 8'h00 : 8'hFF;
    dmask = rx_data & kmask;
  end

  // header completes on this beat?
  wire hdr_beat = rx_hs && (r_cnt == 32'(HB-1));
  wire [383:0] hdr_now = r_hdr | ({{(384-DW){1'b0}}, dmask} << (r_cnt*DW));
  wire [271:0] sh_now  = hdr_now[383:112];
  wire [47:0]  d_mac   = hdr_now[47:0];
  wire [47:0]  s_mac   = hdr_now[95:48];
  wire [15:0]  etype   = {hdr_now[103:96], hdr_now[111:104]};     // frame byte 12 is the MSB (0x88), byte 13 the LSB (0xB5)
  wire [7:0]   vf      = `SFR_H_VF(sh_now);
  wire [7:0]   opc     = `SFR_H_OPC(sh_now);
  wire [15:0]  hpaylen = `SFR_H_PAYLEN(sh_now);
  wire [15:0]  hqpn    = `SFR_H_QPN(sh_now);
  wire [15:0]  hepoch  = `SFR_H_EPOCH(sh_now);
  wire         is_req  = (opc >= 8'h01 && opc <= 8'h0F);
  wire         is_resp = (opc == `SFR_OP_READ_RESP) || (opc == `SFR_OP_ACK) || (opc == `SFR_OP_NAK);
  wire         opc_ok  = is_req || is_resp;
  wire         pl_zero = (opc == `SFR_OP_READ_REQ) || (opc == `SFR_OP_ACK) || (opc == `SFR_OP_NAK);
  wire [47:0]  lmac_be = {cfg_local_mac[7:0], cfg_local_mac[15:8], cfg_local_mac[23:16], cfg_local_mac[31:24], cfg_local_mac[39:32], cfg_local_mac[47:40]};
  wire [47:0]  pmac_be = {cfg_peer_mac[7:0],  cfg_peer_mac[15:8],  cfg_peer_mac[23:16],  cfg_peer_mac[31:24],  cfg_peer_mac[39:32],  cfg_peer_mac[47:40]};

  // end-of-frame verdict
  logic [31:0] tot_bytes, exp_len;
  logic        end_len_bad;
  logic [8:0]  why;
  logic        why_state, good;
  wire         lastbeat = rx_hs && rx_last;
  always_comb begin
    tot_bytes   = r_bytes + nbytes;
    exp_len     = (32'd48 + 32'(r_paylen) < 32'd60) ? 32'd60 : (32'd48 + 32'(r_paylen));
    end_len_bad = !r_hdr_done || (tot_bytes != exp_len);
    why = '0; why_state = 1'b0;
    if      (end_len_bad)           why[0] = 1'b1;               // runt / length rule
    else if (f_keep || !keep_ok)    why[1] = 1'b1;
    else if (rx_err || f_force)     why[2] = 1'b1;
    else if (f_etype)               why[3] = 1'b1;
    else if (f_mac)                 why[4] = 1'b1;
    else if (f_ver)                 why[5] = 1'b1;
    else if (f_opc)                 why[6] = 1'b1;
    else if (f_len)                 why[0] = 1'b1;               // paylen > MTU / class rule (AFTER the opcode check, spec 3.4)
    else if (f_qpn)                 why[7] = 1'b1;
    else if (f_epoch)               why[8] = 1'b1;
    else if (f_state)               why_state = 1'b1;
    good = !(|why) && !why_state;
  end

  // payload store decision for this beat
  wire        in_pay    = (r_cnt >= 32'(HB));
  wire        do_store  = rx_hs && in_pay && r_store && (r_pay_left != 16'd0);
  wire [31:0] st32      = (nbytes < 32'(r_pay_left)) ? nbytes : 32'(r_pay_left);
  logic [B-1:0]  st_keep;
  logic [DW-1:0] st_data;
  always_comb begin
    for (int i = 0; i < B; i++) begin
      st_keep[i] = (32'(i) < st32);
      st_data[8*i +: 8] = (32'(i) < st32) ? rx_data[8*i +: 8] : 8'h00;
    end
  end
  wire        st_last = (32'(r_pay_left) == st32);          // the beat that carries the final payload byte

  assign r_sh_q   = r_hdr[383:112];
  assign rhq_push = lastbeat && good;

  assign rxp_valid = (rrd != rc);
  assign rxp_data  = r_ring_d[rrd[RAB-1:0]];
  assign rxp_keep  = r_ring_k[rrd[RAB-1:0]];
  assign rxp_last  = r_ring_l[rrd[RAB-1:0]];

  always_comb begin
    ev_drop = '0; ev_drop_state = 1'b0;
    if (lastbeat && !good) begin ev_drop = why; ev_drop_state = why_state; end
  end
  assign ev_rx_frame    = rhq_push;
  assign ev_rx_paybytes = rhq_push ? r_paylen : 16'd0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rw <= '0; rc <= '0; rrd <= '0;
      r_cnt <= '0; r_hdr <= '0; r_bytes <= '0; r_pay_left <= '0; r_paylen <= '0; r_hdr_done <= 1'b0; r_store <= 1'b0;
      f_len <= 1'b0; f_keep <= 1'b0; f_etype <= 1'b0; f_mac <= 1'b0; f_ver <= 1'b0; f_opc <= 1'b0; f_qpn <= 1'b0;
      f_epoch <= 1'b0; f_state <= 1'b0; f_force <= 1'b0;
    end else begin
      if (rxp_valid && rxp_ready) rrd <= rrd + 1'b1;
      if (rx_flush) begin
        rw <= rrd; rc <= rrd;
        if (r_cnt != 32'd0) f_force <= 1'b1;            // a frame in progress is aborted at its last beat
      end else if (rx_hs) begin
        // ---- accumulate
        r_bytes <= r_bytes + nbytes;
        if (r_cnt < 32'(HB)) r_hdr <= hdr_now;
        if (!keep_ok) f_keep <= 1'b1;
        // ---- header checks, on the beat that completes the header
        if (hdr_beat) begin
          r_hdr_done <= !rx_last;                         // a frame that ends here is shorter than 60 bytes
          r_paylen   <= hpaylen;
          r_pay_left <= hpaylen;
          f_etype    <= (etype != `SFR_ETHERTYPE);
          f_mac      <= (d_mac != lmac_be) || (s_mac != pmac_be);
          f_ver      <= (vf[7:4] != `SFR_VERSION) || vf[3];
          f_opc      <= !opc_ok;
          f_len      <= (hpaylen > 16'(MTU)) || (pl_zero && hpaylen != 16'd0);
          f_qpn      <= (hqpn != cfg_local_qpn);
          f_epoch    <= (hepoch != cfg_epoch);
          f_state    <= is_req ? !cfg_req_en : !cfg_resp_en;
          r_store    <= !rx_last && opc_ok && (etype == `SFR_ETHERTYPE) && (d_mac == lmac_be) && (s_mac == pmac_be) &&
                        (vf[7:4] == `SFR_VERSION) && !vf[3] && (hpaylen <= 16'(MTU)) && !(pl_zero && hpaylen != 16'd0) &&
                        (hqpn == cfg_local_qpn) && (hepoch == cfg_epoch) && (is_req ? cfg_req_en : cfg_resp_en);
        end
        if (r_cnt != 32'hFFFF_FFFF) r_cnt <= r_cnt + 32'd1;
        // ---- payload store
        if (do_store) begin
          r_ring_d[rw[RAB-1:0]] <= st_data;
          r_ring_k[rw[RAB-1:0]] <= st_keep;
          r_ring_l[rw[RAB-1:0]] <= st_last;
          rw        <= rw + 1'b1;
          r_pay_left <= r_pay_left - 16'(st32);
        end
        // ---- end of frame: commit or abort, reset the frame registers
        if (rx_last) begin
          if (good) rc <= (do_store ? rw + 1'b1 : rw);
          else      rw <= rc;
          r_cnt <= '0; r_hdr <= '0; r_bytes <= '0; r_pay_left <= '0; r_paylen <= '0; r_hdr_done <= 1'b0; r_store <= 1'b0;
          f_len <= 1'b0; f_keep <= 1'b0; f_etype <= 1'b0; f_mac <= 1'b0; f_ver <= 1'b0; f_opc <= 1'b0; f_qpn <= 1'b0;
          f_epoch <= 1'b0; f_state <= 1'b0; f_force <= 1'b0;
        end
      end
    end
  end
endmodule
`default_nettype wire
