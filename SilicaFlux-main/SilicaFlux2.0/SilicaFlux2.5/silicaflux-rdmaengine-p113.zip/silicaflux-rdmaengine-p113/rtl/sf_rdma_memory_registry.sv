// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_memory_registry
//
// Protected memory-region table.  The ONLY block that can turn (key, protection domain, VA, length) into a physical
// address.  Configured ONLY through the trusted `mr_*` port; nothing on the wire or in a WQE can write the table.
//
// CHECK FUNCTION (docs/TRANSPORT_SPEC.md 8.3; first match wins; the grant is the conjunction of ALL clauses):
//   BAD_KEY < BAD_PD < BAD_DIR < BAD_PERM < BAD_LEN < OVERFLOW < RANGE < PAGE_CROSS < XLATE
//   A correct key alone NEVER grants: the PD of the QP must equal the region's PD, the direction and the specific right must be
//   granted, the WHOLE range must lie in ONE region (65-bit arithmetic: no wrap-around), page crossings need a CONTIG region,
//   and the translation context must be live.
// REFERENCES: a grant increments the region's refcnt; the owner releases it.  MR_INVAL is refused (ERR_BUSY) while refcnt != 0,
//   so an accepted operation can never lose its region.  Results are registered (one cycle after chk_valid).
// GUARD: combinational second check used by the DMA engines (valid && refcnt>0 && physical window containment).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none

module sf_rdma_memory_registry #(
  parameter int NMR           = 8,
  parameter int PA_W          = 32,
  parameter int PD_W          = 4,
  parameter int CTX_W         = 2,
  parameter int NCHK          = 2,
  parameter int NREL          = 3,
  parameter int NG            = 2,
  parameter int GLEN_W        = 16,
  parameter int REF_W         = 8,
  parameter int PAGE_BYTES    = 4096,
  parameter int MAX_MSG_BYTES = 1048576,
  localparam int RID_W        = (NMR > 1) ? $clog2(NMR) : 1,
  localparam int NCTX         = (1 << CTX_W),
  localparam int NNF          = `SFR_NFAULT
) (
  input  wire logic                      clk,
  input  wire logic                      rst_n,
  // ---- trusted configuration ------------------------------------------------------------------------------------
  input  wire logic                      mr_cmd_valid,
  input  wire logic [1:0]                mr_cmd,          // 1 SET, 2 INVAL, 3 CTX
  input  wire logic [RID_W-1:0]          mr_idx,
  input  wire logic [63:0]               mr_va,
  input  wire logic [31:0]               mr_len,
  input  wire logic [PA_W-1:0]           mr_pa,
  input  wire logic [31:0]               mr_key,
  input  wire logic [PD_W-1:0]           mr_pd,
  input  wire logic [7:0]                mr_acc,
  input  wire logic [CTX_W-1:0]          mr_ctx,
  input  wire logic [NCTX-1:0]           mr_ctx_mask,
  output logic                           mr_rsp_valid,
  output logic [3:0]                     mr_rsp_status,
  // ---- check ports ------------------------------------------------------------------------------------------------
  input  wire logic [NCHK-1:0]           chk_valid,
  input  wire logic [NCHK*2-1:0]         chk_op,
  input  wire logic [NCHK*32-1:0]        chk_key,
  input  wire logic [NCHK*PD_W-1:0]      chk_pd,
  input  wire logic [NCHK*64-1:0]        chk_va,
  input  wire logic [NCHK*32-1:0]        chk_len,
  output logic [NCHK-1:0]                rsp_valid,
  output logic [NCHK-1:0]                rsp_ok,
  output logic [NCHK*4-1:0]              rsp_fault,
  output logic [NCHK*RID_W-1:0]          rsp_rid,
  output logic [NCHK*PA_W-1:0]           rsp_pa,
  output logic [NCHK*CTX_W-1:0]          rsp_ctx,
  // ---- reference release / clear ---------------------------------------------------------------------------------
  input  wire logic [NREL-1:0]           rel_valid,
  input  wire logic [NREL*RID_W-1:0]     rel_rid,
  input  wire logic                      ref_clear,
  // ---- DMA guard (combinational) -----------------------------------------------------------------------------------
  input  wire logic [NG*RID_W-1:0]       g_rid,
  input  wire logic [NG*PA_W-1:0]        g_pa,
  input  wire logic [NG*GLEN_W-1:0]      g_len,
  output logic [NG-1:0]                  g_ok,
  // ---- diagnostics ------------------------------------------------------------------------------------------------
  output logic [NNF*32-1:0]              fault_cnt,
  output logic [NMR-1:0]                 tbl_valid,
  output logic [3:0]                     fl_fault,
  output logic [31:0]                    fl_key,
  output logic [63:0]                    fl_va,
  output logic [31:0]                    fl_len,
  output logic [1:0]                     fl_op,
  output logic                           ref_ovf
);
  localparam int PG_SH = $clog2(PAGE_BYTES);

  // ---- the table ----------------------------------------------------------------------------------------------------
  logic                v_q   [0:NMR-1];
  logic [31:0]         key_q [0:NMR-1];
  logic [63:0]         vab_q [0:NMR-1];
  logic [31:0]         len_q [0:NMR-1];
  logic [PA_W-1:0]     pab_q [0:NMR-1];
  logic [PD_W-1:0]     pd_q  [0:NMR-1];
  logic [7:0]          acc_q [0:NMR-1];
  logic [CTX_W-1:0]    ctx_q [0:NMR-1];
  logic [REF_W-1:0]    ref_q [0:NMR-1];
  logic [NCTX-1:0]     ctx_en;

  always_comb for (int i = 0; i < NMR; i++) tbl_valid[i] = v_q[i];

  // ---- configuration decode (combinational; applied at the clock edge) ---------------------------------------------------
  logic [4:0]  idx_i;
  logic        inv_now;                         // an invalidation is being applied this cycle
  logic [RID_W-1:0] inv_idx;
  logic        set_now;
  logic [3:0]  cstat;
  logic        dupkey;
  logic [64:0] cva_end;
  logic [PA_W:0] cpa_end;

  always_comb begin
    idx_i  = 5'(mr_idx);
    dupkey = 1'b0;
    for (int i = 0; i < NMR; i++) if (v_q[i] && key_q[i] == mr_key) dupkey = 1'b1;
    cva_end = {1'b0, mr_va} + {33'b0, mr_len};
    cpa_end = {1'b0, mr_pa} + {{(PA_W-31){1'b0}}, mr_len};
    cstat   = `SFR_CS_OK;
    inv_now = 1'b0;
    inv_idx = mr_idx;
    set_now = 1'b0;
    if (mr_cmd_valid) begin
      case (mr_cmd)
        2'd1: begin
          if (idx_i >= 5'(NMR))                       cstat = `SFR_CS_IDX;
          else if (v_q[mr_idx])                       cstat = `SFR_CS_EXISTS;
          else if (mr_len == 32'd0 || mr_acc[7:5] != 3'd0) cstat = `SFR_CS_FIELDS;
          else if ((cva_end[64] && (|cva_end[63:0])) || (cpa_end[PA_W] && (|cpa_end[PA_W-1:0]))) cstat = `SFR_CS_RANGE;
          else if (dupkey)                            cstat = `SFR_CS_DUPKEY;
          else                                        set_now = 1'b1;
        end
        2'd2: begin
          if (idx_i >= 5'(NMR))                       cstat = `SFR_CS_IDX;
          else if (!v_q[mr_idx])                      cstat = `SFR_CS_NOENT;
          else if (ref_q[mr_idx] != '0)               cstat = `SFR_CS_BUSY;
          else                                        inv_now = 1'b1;
        end
        2'd3: cstat = `SFR_CS_OK;
        default: cstat = `SFR_CS_FIELDS;
      endcase
    end
  end

  // ---- checker, one instance per port ----------------------------------------------------------------------------------
  wire [NCHK-1:0]       p_ok;
  wire [NCHK*4-1:0]     p_fault;
  wire [NCHK*RID_W-1:0] p_rid;
  wire [NCHK*PA_W-1:0]  p_pa;
  wire [NCHK*CTX_W-1:0] p_ctx;
  wire [NCHK*NMR-1:0]   acq_hit;                 // per port: one-hot of the region granted this cycle

  generate
    for (genvar p = 0; p < NCHK; p++) begin : g_chk
      wire [1:0]      op  = chk_op [p*2 +: 2];
      wire [31:0]     key = chk_key[p*32 +: 32];
      wire [PD_W-1:0] pd  = chk_pd [p*PD_W +: PD_W];
      wire [63:0]     va  = chk_va [p*64 +: 64];
      wire [31:0]     len = chk_len[p*32 +: 32];

      logic             found;
      logic [RID_W-1:0] rid;
      logic [PD_W-1:0]  e_pd;
      logic [7:0]       e_acc;
      logic [63:0]      e_vab;
      logic [31:0]      e_len;
      logic [PA_W-1:0]  e_pab;
      logic [CTX_W-1:0] e_ctx;
      logic [64:0]      va_end, reg_end;
      logic [63:0]      va_last;
      logic [63:0]      offs;
      logic             ovf, range_ok, pg_cross, dir_ok, perm_ok;
      logic [3:0]       f;
      logic [PA_W-1:0]  pa;
      logic             okl;
      logic [NMR-1:0]   hit;

      always_comb begin
        found = 1'b0; rid = '0; e_pd = '0; e_acc = '0; e_vab = '0; e_len = '0; e_pab = '0; e_ctx = '0;
        for (int i = 0; i < NMR; i++) begin
          if (!found && v_q[i] && key_q[i] == key && !(inv_now && inv_idx == RID_W'(i))) begin
            found = 1'b1; rid = RID_W'(i);
            e_pd = pd_q[i]; e_acc = acc_q[i]; e_vab = vab_q[i]; e_len = len_q[i]; e_pab = pab_q[i]; e_ctx = ctx_q[i];
          end
        end
        va_end   = {1'b0, va} + {33'b0, len};
        va_last  = va + {32'b0, len} - 64'd1;
        reg_end  = {1'b0, e_vab} + {33'b0, e_len};
        ovf      = va_end[64] && (|va_end[63:0]);                      // > 2^64
        range_ok = (va >= e_vab) && (va_end <= reg_end);
        pg_cross = !e_acc[`SFR_ACC_CONTIG] && ((va >> PG_SH) != (va_last >> PG_SH));
        dir_ok   = op[1] ? (|e_acc[3:2]) : (|e_acc[1:0]);
        perm_ok  = ((e_acc >> op) & 8'd1) != 8'd0;
        offs     = va - e_vab;
        pa       = e_pab + offs[PA_W-1:0];
        f = `SFR_FT_NONE;
        if      (!found)                                         f = `SFR_FT_BAD_KEY;
        else if (e_pd != pd)                                     f = `SFR_FT_BAD_PD;
        else if (!dir_ok)                                        f = `SFR_FT_BAD_DIR;
        else if (!perm_ok)                                       f = `SFR_FT_BAD_PERM;
        else if (len == 32'd0 || len > MAX_MSG_BYTES)            f = `SFR_FT_BAD_LEN;
        else if (ovf)                                            f = `SFR_FT_OVERFLOW;
        else if (!range_ok)                                      f = `SFR_FT_RANGE;
        else if (pg_cross)                                       f = `SFR_FT_PAGE_CROSS;
        else if (!ctx_en[e_ctx])                                 f = `SFR_FT_XLATE;
        okl = chk_valid[p] && (f == `SFR_FT_NONE);
        for (int i = 0; i < NMR; i++) hit[i] = okl && (rid == RID_W'(i));
      end
      assign p_ok   [p]                = okl;
      assign p_fault[p*4 +: 4]         = chk_valid[p] ? f : `SFR_FT_NONE;
      assign p_rid  [p*RID_W +: RID_W] = rid;
      assign p_pa   [p*PA_W +: PA_W]   = pa;
      assign p_ctx  [p*CTX_W +: CTX_W] = e_ctx;
      assign acq_hit[p*NMR +: NMR]     = hit;
    end
  endgenerate

  // ---- combinational next-state: reference counts, fault statistics, fault log --------------------------------------------
  logic [REF_W:0] ref_nx  [0:NMR-1];
  logic [31:0]    fc      [0:NNF-1];
  logic [31:0]    fc_inc  [0:NNF-1];
  logic           lf_set;
  logic [3:0]     lf_fault;
  logic [31:0]    lf_key, lf_len;
  logic [63:0]    lf_va;
  logic [1:0]     lf_op;
  logic [NNF*32-1:0] fc_flat;

  always_comb begin
    for (int i = 0; i < NMR; i++) begin
      ref_nx[i] = {1'b0, ref_q[i]};
      for (int p = 0; p < NCHK; p++) if (acq_hit[p*NMR+i]) ref_nx[i] = ref_nx[i] + 1'b1;
      for (int r = 0; r < NREL; r++) if (rel_valid[r] && rel_rid[r*RID_W +: RID_W] == RID_W'(i)) ref_nx[i] = ref_nx[i] - 1'b1;
    end
    for (int c = 0; c < NNF; c++) begin
      fc_inc[c] = 32'd0;
      for (int p = 0; p < NCHK; p++) begin
        if (c == 0) begin
          if (chk_valid[p] && p_fault[p*4 +: 4] != `SFR_FT_NONE) fc_inc[c] = fc_inc[c] + 32'd1;
        end else begin
          if (chk_valid[p] && p_fault[p*4 +: 4] == 4'(c)) fc_inc[c] = fc_inc[c] + 32'd1;
        end
      end
    end
    lf_set = 1'b0; lf_fault = 4'd0; lf_key = 32'd0; lf_len = 32'd0; lf_va = 64'd0; lf_op = 2'd0;
    for (int p = 0; p < NCHK; p++) begin
      if (!lf_set && chk_valid[p] && p_fault[p*4 +: 4] != `SFR_FT_NONE) begin
        lf_set = 1'b1; lf_fault = p_fault[p*4 +: 4]; lf_key = chk_key[p*32 +: 32];
        lf_va = chk_va[p*64 +: 64]; lf_len = chk_len[p*32 +: 32]; lf_op = chk_op[p*2 +: 2];
      end
    end
    for (int c = 0; c < NNF; c++) fc_flat[c*32 +: 32] = fc[c];
  end
  assign fault_cnt = fc_flat;

  // ---- sequential: results, table update, refcounts, counters ----------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NMR; i++) begin
        v_q[i] <= 1'b0; key_q[i] <= '0; vab_q[i] <= '0; len_q[i] <= '0; pab_q[i] <= '0;
        pd_q[i] <= '0; acc_q[i] <= '0; ctx_q[i] <= '0; ref_q[i] <= '0;
      end
      ctx_en        <= NCTX'(1);
      mr_rsp_valid  <= 1'b0;
      mr_rsp_status <= 4'd0;
      rsp_valid     <= '0;
      rsp_ok        <= '0;
      rsp_fault     <= '0;
      rsp_rid       <= '0;
      rsp_pa        <= '0;
      rsp_ctx       <= '0;
      for (int c = 0; c < NNF; c++) fc[c] <= 32'd0;
      fl_fault <= 4'd0; fl_key <= 32'd0; fl_va <= 64'd0; fl_len <= 32'd0; fl_op <= 2'd0;
      ref_ovf <= 1'b0;
    end else begin
      // ---- configuration
      mr_rsp_valid  <= mr_cmd_valid;
      mr_rsp_status <= cstat;
      if (mr_cmd_valid && mr_cmd == 2'd3) ctx_en <= mr_ctx_mask;
      if (set_now) begin
        v_q[mr_idx] <= 1'b1; key_q[mr_idx] <= mr_key; vab_q[mr_idx] <= mr_va; len_q[mr_idx] <= mr_len;
        pab_q[mr_idx] <= mr_pa; pd_q[mr_idx] <= mr_pd; acc_q[mr_idx] <= mr_acc; ctx_q[mr_idx] <= mr_ctx;
      end
      if (inv_now) v_q[inv_idx] <= 1'b0;

      // ---- check results (registered)
      rsp_valid <= chk_valid;
      rsp_ok    <= p_ok;
      rsp_fault <= p_fault;
      rsp_rid   <= p_rid;
      rsp_pa    <= p_pa;
      rsp_ctx   <= p_ctx;

      // ---- reference counts (a wrap is a diagnostic; it can only happen if a client violates acquire/release pairing)
      for (int i = 0; i < NMR; i++) begin
        if (ref_clear) ref_q[i] <= '0;
        else begin
          ref_q[i] <= ref_nx[i][REF_W-1:0];
          if (ref_nx[i][REF_W]) ref_ovf <= 1'b1;
        end
      end

      // ---- fault statistics (saturating) and the one-entry log
      for (int c = 0; c < NNF; c++)
        if (fc_inc[c] != 32'd0) fc[c] <= (fc[c] > 32'hFFFF_FFFF - fc_inc[c]) ? 32'hFFFF_FFFF : fc[c] + fc_inc[c];
      if (lf_set) begin
        fl_fault <= lf_fault; fl_key <= lf_key; fl_va <= lf_va; fl_len <= lf_len; fl_op <= lf_op;
      end
    end
  end

  // ---- guard ---------------------------------------------------------------------------------------------------------------
  generate
    for (genvar k = 0; k < NG; k++) begin : g_guard
      wire [RID_W-1:0]  rid = g_rid[k*RID_W +: RID_W];
      wire [PA_W-1:0]   pa  = g_pa [k*PA_W +: PA_W];
      wire [GLEN_W-1:0] ln  = g_len[k*GLEN_W +: GLEN_W];
      logic [PA_W:0]    pa_end, win_end;
      logic [PA_W-1:0]  w_pab;
      logic [31:0]      w_len;
      logic             w_v;
      logic [REF_W-1:0] w_ref;
      always_comb begin
        w_v = v_q[rid]; w_pab = pab_q[rid]; w_len = len_q[rid]; w_ref = ref_q[rid];
        pa_end  = {1'b0, pa} + {{(PA_W+1-GLEN_W){1'b0}}, ln};
        win_end = {1'b0, w_pab} + {{(PA_W-31){1'b0}}, w_len};
        g_ok[k] = w_v && (w_ref != '0) && (ln != '0) && (pa >= w_pab) && (pa_end <= win_end);
      end
    end
  endgenerate
endmodule
`default_nettype wire
