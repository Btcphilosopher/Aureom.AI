// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_requester
//
// Requester half of the queue pair (spec 7, 9, 11).
//   issue     SQ head -> local registry check (once per WQE) -> segmentation into WINDOW-bounded request-table entries.
//   transmit  walks the table from `txp`; every frame can be RE-CREATED from its entry (retransmission re-reads local memory).
//   ack       cumulative commit frontier `chi` and accept frontier `ahi` from ACK/NAK; WRITE/SEND entries are done when PSN < chi,
//             READ entries when their data has been committed to local memory.  Retire in order; the CQE of a WQE is produced when
//             its LAST entry retires, so send-queue completions are in post order.
//   failure   local protection error / fatal NAK / retry exhaustion complete the failing WQE with its status, then request QP ERR;
//             while the QP is in ERR everything else is flushed (WR_FLUSH_ERR) in queue order.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none

module sf_rdma_requester #(
  parameter int WINDOW   = 8,                  // power of two: outstanding request PSNs
  parameter int MAX_RD   = 2,                  // outstanding READ requests
  parameter int MTU      = 256,
  parameter int PA_W     = 32,
  parameter int PD_W     = 4,
  parameter int RID_W    = 3,
  parameter int CTX_W    = 2,
  localparam int WB      = $clog2(WINDOW)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clear,
  // ---- QP context ----------------------------------------------------------------------------------------------------------------
  input  wire logic              en,                    // QP in RTS
  input  wire logic              flush_en,              // QP in ERR
  input  wire logic              ld_valid,              // pulse on entering RTS: load PSNs
  input  wire logic [23:0]       ld_psn,
  input  wire logic [PD_W-1:0]   qp_pd,
  input  wire logic [15:0]       remote_qpn,
  input  wire logic [15:0]       epoch,
  input  wire logic [31:0]       cfg_timeout,
  input  wire logic [3:0]        cfg_retry_max,
  input  wire logic [3:0]        cfg_rnr_max,
  input  wire logic [31:0]       cfg_rnr_delay,
  input  wire logic [31:0]       now,
  // ---- SQ head -------------------------------------------------------------------------------------------------------------------
  input  wire logic              sq_valid,
  output logic                   sq_pop,
  input  wire logic [1:0]        sq_op,
  input  wire logic [63:0]       sq_wr_id,
  input  wire logic [63:0]       sq_laddr,
  input  wire logic [31:0]       sq_lkey,
  input  wire logic [31:0]       sq_len,
  input  wire logic [63:0]       sq_raddr,
  input  wire logic [31:0]       sq_rkey,
  // ---- registry (local checks) ------------------------------------------------------------------------------------------------------
  output logic                   chk_valid,
  output logic [1:0]             chk_op,
  output logic [31:0]            chk_key,
  output logic [PD_W-1:0]        chk_pd,
  output logic [63:0]            chk_va,
  output logic [31:0]            chk_len,
  input  wire logic              rsp_valid,
  input  wire logic              rsp_ok,
  input  wire logic [RID_W-1:0]  rsp_rid,
  input  wire logic [PA_W-1:0]   rsp_pa,
  input  wire logic [CTX_W-1:0]  rsp_ctx,
  output logic                   rel_valid,             // release of a WQE's local grant (context pop)
  output logic [RID_W-1:0]       rel_rid,
  output logic                   rel_chk_valid,         // release of the grant of a WQE that was flushed while its check was in flight
  output logic [RID_W-1:0]       rel_chk_rid,
  // ---- transmit request ------------------------------------------------------------------------------------------------------------
  output logic                   tx_valid,
  input  wire logic              tx_ready,
  output logic [271:0]           tx_sh,
  output logic                   tx_has_pl,
  output logic [PA_W-1:0]        tx_pa,
  output logic [15:0]            tx_len,
  output logic [RID_W-1:0]       tx_rid,
  output logic [CTX_W-1:0]       tx_ctx,
  // ---- events from the receive processor ---------------------------------------------------------------------------------------------
  input  wire logic              ack_valid,
  input  wire logic [23:0]       ack_cn,
  input  wire logic [23:0]       ack_an,
  input  wire logic [3:0]        ack_code,
  input  wire logic [23:0]       rr_psn,
  output logic                   rr_found,
  output logic [31:0]            rr_exp_off,
  output logic [31:0]            rr_mlen,
  output logic [PA_W-1:0]        rr_lpa,
  output logic [RID_W-1:0]       rr_rid,
  output logic [CTX_W-1:0]       rr_ctx,
  input  wire logic              rr_accept,
  input  wire logic [15:0]       rr_accept_len,
  input  wire logic              place_done_valid,
  input  wire logic [23:0]       place_done_psn,
  // ---- local (memory) errors ----------------------------------------------------------------------------------------------------------
  input  wire logic              lerr_tx_valid,         // the payload fetch of the frame with this PSN failed (the frame was dropped)
  input  wire logic [23:0]       lerr_tx_psn,
  input  wire logic              lerr_pl_valid,         // the placement write of the READ response of this table entry failed
  input  wire logic [WB-1:0]     lerr_pl_idx,
  input  wire logic              dma_quiet,             // no data movement of THIS requester is in flight (source reads, response placements)
  // ---- completion producer P0 ------------------------------------------------------------------------------------------------------
  output logic                   cmp_valid,
  input  wire logic              cmp_ready,
  output logic [63:0]            cmp_wr_id,
  output logic [3:0]             cmp_op,
  output logic [3:0]             cmp_status,
  output logic [31:0]            cmp_len,
  // ---- QP error request ----------------------------------------------------------------------------------------------------------------
  output logic                   err_req,
  output logic [3:0]             err_cause,
  // ---- status / events -------------------------------------------------------------------------------------------------------------------
  output logic                   idle,
  output logic                   quiet,                  // drain condition for QP reset: issue FSM parked and no WQE context left
  output logic [WB+1:0]          win_occ,
  output logic                   ev_retry_timeout,
  output logic                   ev_retry_nak,
  output logic                   ev_retry_rnr,
  output logic                   ev_tx_retx,
  output logic                   ev_rx_ack_stale,
  output logic                   ev_rx_nak,
  output logic                   ev_stall_window,
  output logic                   ev_stall_rdlim,
  output logic                   lat_valid,
  output logic [1:0]             lat_op,
  output logic [31:0]            lat_cycles,
  output logic                   cqe_valid,              // perf: a CQE was produced
  output logic [3:0]             cqe_op,
  output logic [3:0]             cqe_status,
  output logic [31:0]            cqe_len
);
  // ---------------------------------------------------------------------------------------------------------------------------------
  // helpers: 24-bit modular PSN arithmetic
  // ---------------------------------------------------------------------------------------------------------------------------------
  function automatic logic psn_le(input logic [23:0] a, input logic [23:0] b);   // a <= b  (modular)
    logic [23:0] d;
    d = b - a;
    psn_le = !d[23];
  endfunction
  function automatic logic psn_lt(input logic [23:0] a, input logic [23:0] b);      // a <  b  (modular)
    logic [23:0] d;
    d = b - a;
    psn_lt = (d != 24'd0) && !d[23];
  endfunction

  // ---------------------------------------------------------------------------------------------------------------------------------
  // state
  // ---------------------------------------------------------------------------------------------------------------------------------
  logic [23:0] una, nxt, txp, hi, chi, ahi;
  // request table (indexed by psn[WB-1:0])
  logic [1:0]       e_op    [0:WINDOW-1];
  logic             e_first [0:WINDOW-1];
  logic             e_last  [0:WINDOW-1];
  logic [WB-1:0]    e_wq    [0:WINDOW-1];
  logic [15:0]      e_plen  [0:WINDOW-1];
  logic [31:0]      e_moff  [0:WINDOW-1];
  logic [31:0]      e_mlen  [0:WINDOW-1];
  logic [63:0]      e_va    [0:WINDOW-1];
  logic [31:0]      e_rkey  [0:WINDOW-1];
  logic [PA_W-1:0]  e_lpa   [0:WINDOW-1];
  logic [RID_W-1:0] e_rid   [0:WINDOW-1];
  logic [CTX_W-1:0] e_ctx   [0:WINDOW-1];
  logic [31:0]      e_rdoff [0:WINDOW-1];
  logic             e_done  [0:WINDOW-1];
  // WQE context ring
  logic [63:0]      w_wr   [0:WINDOW-1];
  logic [1:0]       w_op   [0:WINDOW-1];
  logic [31:0]      w_len  [0:WINDOW-1];
  logic [RID_W-1:0] w_rid  [0:WINDOW-1];
  logic             w_ref  [0:WINDOW-1];
  logic [31:0]      w_t0   [0:WINDOW-1];
  logic             w_fail [0:WINDOW-1];
  logic [3:0]       w_fst  [0:WINDOW-1];
  logic [WB:0]      w_hd, w_tl;                // head (oldest), tail (next alloc)
  wire  [WB:0]      w_cnt = w_tl - w_hd;
  wire              w_empty = (w_cnt == '0);
  wire              w_full  = (w_cnt == (WB+1)'(WINDOW));

  // issue FSM
  typedef enum logic [1:0] {IS_IDLE, IS_CHK, IS_SEG} iss_t;
  iss_t         ist;
  logic         halt;                          // no new WQE may start
  logic [31:0]  seg_off;
  logic [PA_W-1:0]  g_pa;
  logic [RID_W-1:0] g_rid;
  logic [CTX_W-1:0] g_ctx;
  logic [WB-1:0] cur_w;                         // ctx index of the WQE being segmented
  logic [3:0]   rd_out;

  // failure bookkeeping
  logic         err_pending;                   // fatal NAK seen, or a LOCAL error (memory error) on the entry err_psn
  logic         err_loc;                       //   ... the local kind: status LOC_OP_ERR, QP error cause INT_ERR
  logic [23:0]  err_psn;
  logic [3:0]   err_status;
  logic         fail_pend;                     // exhaustion: fail the head WQE
  logic [3:0]   fail_status, fail_cause;
  logic         err_sent;

  // retry unit
  logic         ev_to, ev_nk, ev_rn, exhausted, rnr_exh, rnr_wait;
  logic [3:0]   retry_cnt, rnr_cnt;
  logic [23:0]  nak_tgt, rnr_tgt;
  logic         progress, nak_retry_p, rnr_nak_p, restart_p;
  // After a fatal NAK the entries BEFORE err_psn must still complete: an earlier READ needs its data.  So the timer keeps running while
  // una != err_psn, and only entries before err_psn are (re)transmitted.  (A fatal-mode responder never re-executes a READ, so a READ
  // whose response was lost ends in RETRY_EXC_ERR after the retries; before this fix nothing ever completed and the QP hung in RTS: F-01.)
  wire          armed = en && (una != nxt) && (txp != una) && !(err_pending && (una == err_psn));
  sf_rdma_retry u_retry (
    .clk(clk), .rst_n(rst_n), .en(en && !clear), .armed(armed), .progress(progress), .restart(restart_p),
    .nak_retry(nak_retry_p), .rnr_nak(rnr_nak_p),
    .cfg_timeout(cfg_timeout), .cfg_retry_max(cfg_retry_max), .cfg_rnr_max(cfg_rnr_max), .cfg_rnr_delay(cfg_rnr_delay),
    .ev_timeout(ev_to), .ev_nak(ev_nk), .ev_rnr(ev_rn), .exhausted(exhausted), .rnr_exhausted(rnr_exh), .rnr_wait(rnr_wait),
    .retry_cnt(retry_cnt), .rnr_cnt(rnr_cnt));
  assign ev_retry_timeout = ev_to;
  assign ev_retry_nak     = ev_nk;
  assign ev_retry_rnr     = ev_rn;

  // ---------------------------------------------------------------------------------------------------------------------------------
  // combinational: occupancy, issue conditions
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire [23:0]   occ24    = nxt - una;
  wire          win_full = (occ24 >= 24'(WINDOW));
  assign        win_occ  = (WB+2)'(occ24);
  wire          rd_ok    = (rd_out < 4'(MAX_RD));
  wire          start_ok = en && !halt && !flush_en && sq_valid && !w_full;
  wire          need_chk = (sq_len != 32'd0);

  // registry check request (issued from the idle state, straight from the SQ head)
  assign chk_valid = (ist == IS_IDLE) && start_ok && need_chk;
  assign chk_op    = (sq_op == `SFR_W2_READ) ? `SFR_CK_LWR : `SFR_CK_LRD;
  assign chk_key   = sq_lkey;
  assign chk_pd    = qp_pd;
  assign chk_va    = sq_laddr;
  assign chk_len   = sq_len;

  // segmentation of the head WQE
  wire [31:0]   remain   = sq_len - seg_off;
  wire [31:0]   plen32   = (sq_op == `SFR_W2_READ) ? 32'd0 : ((remain > 32'(MTU)) ? 32'(MTU) : remain);
  wire          seg_last = (sq_op == `SFR_W2_READ) ? 1'b1 : ((seg_off + plen32) >= sq_len);
  wire          seg_first = (seg_off == 32'd0);
  wire          seg_go   = (ist == IS_SEG) && en && !halt && !flush_en && !win_full && ((sq_op != `SFR_W2_READ) || rd_ok);
  assign ev_stall_window = (ist == IS_SEG) && en && !halt && !flush_en && win_full;
  assign ev_stall_rdlim  = (ist == IS_SEG) && en && !halt && !flush_en && !win_full && (sq_op == `SFR_W2_READ) && !rd_ok;
  wire [WB-1:0] nxt_i    = nxt[WB-1:0];

  // ---------------------------------------------------------------------------------------------------------------------------------
  // receive-side lookups (READ response acceptance) -- combinational view of the table
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire [WB-1:0] rr_i   = rr_psn[WB-1:0];
  wire [23:0]   rr_d   = rr_psn - una;
  assign rr_found      = en && (rr_d < occ24) && (e_op[rr_i] == `SFR_W2_READ) && !e_done[rr_i] && !(err_pending && !psn_lt(rr_psn, err_psn));
  assign rr_exp_off    = e_rdoff[rr_i];
  assign rr_mlen       = e_mlen[rr_i];
  assign rr_lpa        = e_lpa[rr_i];
  assign rr_rid        = e_rid[rr_i];
  assign rr_ctx        = e_ctx[rr_i];

  // ---------------------------------------------------------------------------------------------------------------------------------
  // transmit request from the table
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire [23:0]   nak_tgt_c = psn_lt(nak_tgt, una) ? una : nak_tgt;
  wire [23:0]   rnr_tgt_c = psn_lt(rnr_tgt, una) ? una : rnr_tgt;
  wire [WB-1:0] txp_i  = txp[WB-1:0];
  wire          tx_en  = en && !rnr_wait && !flush_en && (txp != nxt) && (!err_pending || psn_lt(txp, err_psn));
  wire [1:0]    t_op   = e_op[txp_i];
  wire          t_retx = psn_lt(txp, hi);
  wire [31:0]   t_rdoff = e_rdoff[txp_i];
  wire          t_isrd = (t_op == `SFR_W2_READ);
  wire [63:0]   t_va   = t_isrd ? (e_va[txp_i] + {32'd0, t_rdoff}) : ((t_op == `SFR_W2_WRITE) ? e_va[txp_i] : 64'd0);
  wire [31:0]   t_moff = t_isrd ? t_rdoff : e_moff[txp_i];
  wire [15:0]   t_pl   = t_isrd ? 16'd0 : e_plen[txp_i];
  wire          t_first = t_isrd ? (t_rdoff == 32'd0) : e_first[txp_i];
  wire          t_last  = t_isrd ? 1'b1 : e_last[txp_i];
  wire [7:0]    t_opc  = t_isrd ? `SFR_OP_READ_REQ : ((t_op == `SFR_W2_WRITE) ? `SFR_OP_WRITE : `SFR_OP_SEND);
  wire [31:0]   t_mlen = e_mlen[txp_i];
  wire [31:0]   t_rkey = (t_op == `SFR_W2_SEND) ? 32'd0 : e_rkey[txp_i];
  wire [7:0]    t_vf   = {`SFR_VERSION, 1'b0, t_retx, t_last, t_first};
  wire [15:0]   w_qpn  = remote_qpn;
  wire [15:0]   w_ep   = epoch;
  wire [23:0]   t_psn  = txp;
  always_comb begin
    tx_sh = '0;
    tx_sh[8*`SFR_SH_VF     +: 8]  = t_vf;
    tx_sh[8*`SFR_SH_OPC    +: 8]  = t_opc;
    tx_sh[8*`SFR_SH_QPN    +: 16] = `SFR_BSW16(w_qpn);
    tx_sh[8*`SFR_SH_EPOCH  +: 16] = `SFR_BSW16(w_ep);
    tx_sh[8*`SFR_SH_PSN    +: 24] = `SFR_BSW24(t_psn);
    tx_sh[8*`SFR_SH_PAYLEN +: 16] = `SFR_BSW16(t_pl);
    tx_sh[8*`SFR_SH_MLEN   +: 32] = `SFR_BSW32(t_mlen);
    tx_sh[8*`SFR_SH_MOFF   +: 32] = `SFR_BSW32(t_moff);
    tx_sh[8*`SFR_SH_VA     +: 64] = `SFR_BSW64(t_va);
    tx_sh[8*`SFR_SH_RKEY   +: 32] = `SFR_BSW32(t_rkey);
  end
  assign tx_valid  = tx_en;
  assign tx_has_pl = !t_isrd && (e_plen[txp_i] != 16'd0);
  assign tx_pa     = e_lpa[txp_i];
  assign tx_len    = e_plen[txp_i];
  assign tx_rid    = e_rid[txp_i];
  assign tx_ctx    = e_ctx[txp_i];
  wire   tx_hs     = tx_valid && tx_ready;
  assign ev_tx_retx = tx_hs && t_retx;

  // ---------------------------------------------------------------------------------------------------------------------------------
  // ACK / NAK validity (combinational on the event)
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire [23:0] dc = ack_cn - una;
  wire [23:0] da = ack_an - una;
  wire [23:0] dn = nxt - una;
  wire        ack_ok = ack_valid && en && (dc <= da) && (da <= dn);
  wire [23:0] chi_d = chi - una;
  wire [23:0] ahi_d = ahi - una;
  wire        commit_adv = ack_ok && (dc > chi_d);
  wire        accept_adv = ack_ok && (da > ahi_d);
  assign ev_rx_ack_stale = ack_valid && en && !((dc <= da) && (da <= dn));
  assign ev_rx_nak       = ack_ok && (ack_code != 4'd0);
  wire        nak_seq   = ack_ok && (ack_code == `SFR_NAK_SEQ);
  wire        nak_rnr   = ack_ok && (ack_code == `SFR_NAK_RNR);
  wire        nak_fatal = ack_ok && (ack_code == `SFR_NAK_INV || ack_code == `SFR_NAK_ACC || ack_code == `SFR_NAK_OP) &&
                          (da < dn) && !err_pending;
  wire [3:0]  nak_st    = (ack_code == `SFR_NAK_INV) ? `SFR_CQ_REM_INV : (ack_code == `SFR_NAK_ACC) ? `SFR_CQ_REM_ACC : `SFR_CQ_REM_OP;

  // ---------------------------------------------------------------------------------------------------------------------------------
  // retire / failure / flush: ONE completion producer, fixed priority  fail > flush > retire
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire [WB-1:0] una_i  = una[WB-1:0];
  wire [WB-1:0] hd_i   = w_hd[WB-1:0];
  wire          u_exist = (una != nxt);
  wire          u_isrd  = (e_op[una_i] == `SFR_W2_READ);
  wire          u_done  = u_isrd ? e_done[una_i] : psn_lt(una, chi);
  wire          head_failed = !w_empty && w_fail[hd_i];
  // (A) local failure at the head: all earlier entries retired
  wire          fail_local  = en && !flush_en && !u_exist && head_failed;
  // (B) fatal NAK reached: the entry at una is the failed request
  wire          fail_nak    = en && !flush_en && err_pending && u_exist && (una == err_psn) && !w_empty && (!err_loc || dma_quiet);
  // (C) retry / RNR exhaustion
  wire          fail_exh    = en && !flush_en && fail_pend && !w_empty;
  wire          do_fail     = (fail_local || fail_nak || fail_exh) && !err_sent;
  wire [3:0]    fail_st     = fail_local ? w_fst[hd_i] : (fail_nak ? err_status : fail_status);
  wire [3:0]    fail_cs     = fail_local ? `SFR_EC_LOCAL_PROT : (fail_nak ? (err_loc ? `SFR_EC_INT : `SFR_EC_REMOTE_NAK) : fail_cause);

  // ---- LOCAL error: a memory error response on a source read (the frame was dropped by the adapter, nothing was transmitted) or on the
  // placement of READ response data.  The entry's WQE completes LOC_OP_ERR once every earlier entry has retired, then the QP enters ERR
  // (spec 11.1 f).  Same machinery as a fatal NAK: stop issuing, transmit only entries BEFORE the failed one.
  wire [WB-1:0] lerr_pl_d   = lerr_pl_idx - una[WB-1:0];
  wire [23:0]   lerr_pl_psn = una + 24'(lerr_pl_d);
  wire [23:0]   lerr_psn    = lerr_tx_valid ? lerr_tx_psn : lerr_pl_psn;
  wire          lerr_ok     = en && !flush_en && !err_sent && (lerr_tx_valid || lerr_pl_valid) &&
                              psn_le(una, lerr_psn) && psn_lt(lerr_psn, nxt) && (!err_pending || psn_lt(lerr_psn, err_psn));

  wire          do_flush_ctx = flush_en && !w_empty && dma_quiet;      // the grant is released only when no DMA of this requester can still use it (F-06)
  wire          do_flush_sq  = flush_en && w_empty && (ist == IS_IDLE) && sq_valid;
  // a fatal NAK stops retirement at err_psn (the failing WQE must be failed, not completed); after a failure was reported (err_sent)
  // nothing retires any more: the failed WQE's context has been popped and the QP is about to enter ERR
  wire          err_pending_blocks = err_pending && (una == err_psn);
  wire          do_retire    = en && !flush_en && !err_sent && !do_fail && !err_pending_blocks && u_exist && u_done;

  logic         c_valid;
  logic [63:0]  c_wr;
  logic [3:0]   c_op, c_st;
  logic [31:0]  c_len;
  always_comb begin
    c_valid = 1'b0; c_wr = '0; c_op = '0; c_st = '0; c_len = '0;
    if (do_fail) begin
      c_valid = 1'b1; c_wr = w_wr[hd_i]; c_op = {2'b00, w_op[hd_i]}; c_st = fail_st; c_len = 32'd0;
    end else if (do_flush_ctx) begin
      c_valid = 1'b1; c_wr = w_wr[hd_i]; c_op = {2'b00, w_op[hd_i]}; c_st = `SFR_CQ_FLUSH; c_len = 32'd0;
    end else if (do_flush_sq) begin
      c_valid = 1'b1; c_wr = sq_wr_id;   c_op = {2'b00, sq_op};      c_st = `SFR_CQ_FLUSH; c_len = 32'd0;
    end else if (do_retire && e_last[una_i]) begin
      c_valid = 1'b1; c_wr = w_wr[hd_i]; c_op = {2'b00, w_op[hd_i]}; c_st = `SFR_CQ_OK;    c_len = w_len[hd_i];
    end
  end
  assign cmp_valid  = c_valid;
  assign cmp_wr_id  = c_wr;
  assign cmp_op     = c_op;
  assign cmp_status = c_st;
  assign cmp_len    = c_len;
  wire   c_go       = c_valid && cmp_ready;           // the completion is accepted this cycle

  wire   fail_go    = do_fail && cmp_ready;
  wire   flush_ctx_go = do_flush_ctx && !do_fail && cmp_ready;
  wire   flush_sq_go  = do_flush_sq && !do_flush_ctx && !do_fail && cmp_ready;
  wire   retire_go    = do_retire && (!e_last[una_i] || cmp_ready);
  wire   ctx_pop      = fail_go || flush_ctx_go || (retire_go && e_last[una_i]);
  assign cqe_valid  = c_go;
  assign cqe_op     = c_op;
  assign cqe_status = c_st;
  assign cqe_len    = c_len;
  assign lat_valid  = retire_go && e_last[una_i];
  assign lat_op     = w_op[hd_i];
  assign lat_cycles = now - w_t0[hd_i];

  // reference release of the WQE's local grant when its ctx is popped; also the grant of a WQE flushed mid-check
  logic         flush_chk_rel;
  logic [RID_W-1:0] flush_chk_rid;
  assign rel_valid     = ctx_pop && w_ref[hd_i];
  assign rel_rid       = w_rid[hd_i];
  assign rel_chk_valid = flush_chk_rel;
  assign rel_chk_rid   = flush_chk_rid;

  // error request to the QP
  assign err_req   = fail_go;
  assign err_cause = fail_cs;

  // outstanding-READ credit: ONE net update.  (Separate "+1 on issue" and "-1 on retire" assignments lose the increment when a READ is
  // issued in the same cycle another retires; with rd_out == 0 the 4-bit count then wrapped to 15 and every later READ stalled for ever.)
  wire rd_inc = seg_go && (sq_op == `SFR_W2_READ);
  wire rd_dec = retire_go && u_isrd;
  assign progress = ack_ok && (commit_adv || accept_adv) || rr_accept || retire_go;

  // Frontiers and the transmit pointer have several writers in one cycle (ACK, retire, rewind, transmit).  Each is computed ONCE as a net
  // next-state; "last assignment wins" silently dropped an ACK's frontier update when a READ retired in the same cycle (F-07) and left
  // txp below una after a same-cycle rewind + retire (S-01).
  logic [23:0] chi_n, ahi_n, txp_n;
  always_comb begin
    chi_n = chi; ahi_n = ahi; txp_n = txp;
    if (commit_adv) chi_n = ack_cn;
    if (accept_adv) ahi_n = ack_an;
    if (tx_hs)      txp_n = txp + 24'd1;
    if (ev_to && !(err_pending && !psn_lt(una, err_psn)))  txp_n = una;                   // (no rewind once every earlier entry has retired under a fatal NAK)
    if (ev_nk && psn_lt(nak_tgt_c, txp)) txp_n = nak_tgt_c;
    if (ev_rn && psn_lt(rnr_tgt_c, txp)) txp_n = rnr_tgt_c;
    if (retire_go) begin
      // INVARIANT  una <= txp  and  una < chi, ahi  (modular compares are only meaningful within half the space): enforced on the NET values
      if (psn_lt(txp_n, una + 24'd1)) txp_n = una + 24'd1;
      if (!psn_le(una + 24'd1, chi_n)) chi_n = una + 24'd1;
      if (!psn_le(una + 24'd1, ahi_n)) ahi_n = una + 24'd1;
    end
  end
  assign idle     = (una == nxt) && (ist == IS_IDLE) && w_empty;
  // the request table is cleared BY the reset, so it must not be part of the condition that the reset waits for
  assign quiet    = (ist == IS_IDLE) && w_empty;

  // ---------------------------------------------------------------------------------------------------------------------------------
  // sequential
  // ---------------------------------------------------------------------------------------------------------------------------------
  assign sq_pop = (seg_go && seg_last) || flush_sq_go ||
                  (flush_en && (ist == IS_SEG)) ||                                        // WQE already has a ctx: it is flushed from there
                  ((ist == IS_CHK) && rsp_valid && !rsp_ok && !flush_en);                // failed at issue: ctx records it
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      una <= '0; nxt <= '0; txp <= '0; hi <= '0; chi <= '0; ahi <= '0;
      w_hd <= '0; w_tl <= '0; ist <= IS_IDLE; halt <= 1'b0; seg_off <= '0; g_pa <= '0; g_rid <= '0; g_ctx <= '0;
      cur_w <= '0; rd_out <= '0; err_pending <= 1'b0; err_loc <= 1'b0; err_psn <= '0; err_status <= '0; fail_pend <= 1'b0;
      fail_status <= '0; fail_cause <= '0; err_sent <= 1'b0; nak_tgt <= '0; rnr_tgt <= '0;
      nak_retry_p <= 1'b0; rnr_nak_p <= 1'b0; restart_p <= 1'b0; flush_chk_rel <= 1'b0; flush_chk_rid <= '0;
    end else if (clear) begin
      w_hd <= '0; w_tl <= '0; ist <= IS_IDLE; halt <= 1'b0; seg_off <= '0; rd_out <= '0;
      err_pending <= 1'b0; err_loc <= 1'b0; fail_pend <= 1'b0; err_sent <= 1'b0; nak_retry_p <= 1'b0; rnr_nak_p <= 1'b0; restart_p <= 1'b0;
      flush_chk_rel <= 1'b0; una <= nxt; txp <= nxt; hi <= nxt;
    end else begin
      nak_retry_p <= nak_seq; rnr_nak_p <= nak_rnr; restart_p <= 1'b0; flush_chk_rel <= 1'b0;
      rd_out <= rd_out + (rd_inc ? 4'd1 : 4'd0) - (rd_dec ? 4'd1 : 4'd0);
      // ---- QP entering RTS: load the sequence space
      if (ld_valid) begin
        una <= ld_psn; nxt <= ld_psn; txp <= ld_psn; hi <= ld_psn; chi <= ld_psn; ahi <= ld_psn;
        halt <= 1'b0; err_pending <= 1'b0; err_loc <= 1'b0; fail_pend <= 1'b0; err_sent <= 1'b0;
      end
      if (fail_go) err_sent <= 1'b1;
      if (do_fail) fail_pend <= 1'b0;
      // S-03: an exhaustion that coincided with the retirement of the LAST outstanding WQE leaves nothing to fail; do not stay halted for ever
      if (fail_pend && w_empty && !do_fail) begin fail_pend <= 1'b0; if (!err_pending) halt <= 1'b0; end
      // ---- issue FSM
      case (ist)
        IS_IDLE: begin
          if (start_ok) begin
            if (need_chk) begin
              ist <= IS_CHK;
            end else begin                                                // zero-length SEND: nothing to check or hold
              w_wr[w_tl[WB-1:0]] <= sq_wr_id; w_op[w_tl[WB-1:0]] <= sq_op; w_len[w_tl[WB-1:0]] <= sq_len;
              w_rid[w_tl[WB-1:0]] <= '0; w_ref[w_tl[WB-1:0]] <= 1'b0; w_t0[w_tl[WB-1:0]] <= now;
              w_fail[w_tl[WB-1:0]] <= 1'b0; w_fst[w_tl[WB-1:0]] <= '0;
              cur_w <= w_tl[WB-1:0]; w_tl <= w_tl + 1'b1; g_pa <= '0; g_rid <= '0; g_ctx <= '0;
              seg_off <= 32'd0; ist <= IS_SEG;
            end
          end
        end
        IS_CHK: begin
          if (rsp_valid) begin
            if (flush_en) begin
              if (rsp_ok) begin flush_chk_rel <= 1'b1; flush_chk_rid <= rsp_rid; end   // the grant is dropped, the WQE is flushed from the SQ
              ist <= IS_IDLE;
            end else if (rsp_ok) begin
              w_wr[w_tl[WB-1:0]] <= sq_wr_id; w_op[w_tl[WB-1:0]] <= sq_op; w_len[w_tl[WB-1:0]] <= sq_len;
              w_rid[w_tl[WB-1:0]] <= rsp_rid; w_ref[w_tl[WB-1:0]] <= 1'b1; w_t0[w_tl[WB-1:0]] <= now;
              w_fail[w_tl[WB-1:0]] <= 1'b0; w_fst[w_tl[WB-1:0]] <= '0;
              cur_w <= w_tl[WB-1:0]; w_tl <= w_tl + 1'b1; g_pa <= rsp_pa; g_rid <= rsp_rid; g_ctx <= rsp_ctx;
              seg_off <= 32'd0; ist <= IS_SEG;
            end else begin                                                // local protection failure: the WQE is recorded as failed
              w_wr[w_tl[WB-1:0]] <= sq_wr_id; w_op[w_tl[WB-1:0]] <= sq_op; w_len[w_tl[WB-1:0]] <= sq_len;
              w_rid[w_tl[WB-1:0]] <= '0; w_ref[w_tl[WB-1:0]] <= 1'b0; w_t0[w_tl[WB-1:0]] <= now;
              w_fail[w_tl[WB-1:0]] <= 1'b1; w_fst[w_tl[WB-1:0]] <= `SFR_CQ_LOC_PROT;
              w_tl <= w_tl + 1'b1; halt <= 1'b1; ist <= IS_IDLE;
            end
          end
        end
        default: begin   // IS_SEG
          if (flush_en) ist <= IS_IDLE;                                   // sq_pop drops the head; its ctx is flushed
          else if (seg_go) begin
            e_op   [nxt_i] <= sq_op;
            e_first[nxt_i] <= seg_first;
            e_last [nxt_i] <= seg_last;
            e_wq   [nxt_i] <= cur_w;
            e_plen [nxt_i] <= plen32[15:0];
            e_moff [nxt_i] <= seg_off;
            e_mlen [nxt_i] <= sq_len;
            e_va   [nxt_i] <= (sq_op == `SFR_W2_WRITE) ? (sq_raddr + {32'd0, seg_off}) : sq_raddr;
            e_rkey [nxt_i] <= sq_rkey;
            e_lpa  [nxt_i] <= g_pa + PA_W'(seg_off);
            e_rid  [nxt_i] <= g_rid;
            e_ctx  [nxt_i] <= g_ctx;
            e_rdoff[nxt_i] <= 32'd0;
            e_done [nxt_i] <= 1'b0;
            nxt     <= nxt + 24'd1;
            seg_off <= seg_off + plen32;
            if (seg_last) ist <= IS_IDLE;
          end
        end
      endcase

      // ---- transmit pointer, retransmission triggers
      if (!ld_valid) begin txp <= txp_n; chi <= chi_n; ahi <= ahi_n; end         // (the PSN load of a new RTS has priority)
      if (tx_hs && (hi == txp)) hi <= txp + 24'd1;
      if (ev_to || ev_nk || ev_rn) restart_p <= 1'b1;
      // (a rewind target may have been overtaken by retirement meanwhile: txp_n never goes below una, see above)
      if (nak_seq) nak_tgt <= ack_an;
      if (nak_rnr) rnr_tgt <= ack_an;

      // ---- ACK / NAK application
      if (nak_fatal) begin err_pending <= 1'b1; err_loc <= 1'b0; err_psn <= ack_an; err_status <= nak_st; halt <= 1'b1; end
      if (lerr_ok)   begin err_pending <= 1'b1; err_loc <= 1'b1; err_psn <= lerr_psn; err_status <= `SFR_CQ_LOC_OP; halt <= 1'b1; end
      if (place_done_valid) e_done[place_done_psn[WB-1:0]] <= 1'b1;
      if (rr_accept) e_rdoff[rr_i] <= e_rdoff[rr_i] + {16'd0, rr_accept_len};

      // ---- exhaustion
      if ((exhausted || rnr_exh) && !err_sent && !fail_pend) begin
        fail_pend <= 1'b1; halt <= 1'b1;
        fail_status <= exhausted ? `SFR_CQ_RETRY : `SFR_CQ_RNR;
        fail_cause  <= exhausted ? `SFR_EC_RETRY : `SFR_EC_RNR;
      end

      // ---- retire
      if (retire_go) begin
        una <= una + 24'd1;
        // (invariant una <= txp, and the frontiers staying ahead of una, are enforced on the net next-state values above: a late
        //  cumulative ACK can retire entries txp still points at; without it the engine re-sent an entry whose grant was released)
        if (e_last[una_i]) w_hd <= w_hd + 1'b1;
      end
      if (fail_go || flush_ctx_go) w_hd <= w_hd + 1'b1;
    end
  end
endmodule
`default_nettype wire
