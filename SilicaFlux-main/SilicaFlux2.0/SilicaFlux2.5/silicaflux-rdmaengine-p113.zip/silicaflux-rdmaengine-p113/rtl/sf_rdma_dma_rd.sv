// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_dma_rd   (data-movement engine, memory -> payload stream)
//
// Reads `len` bytes starting at byte-granular physical address `pa` from the local memory (word reads, in-order responses,
// up to MEM_OUT outstanding) and re-aligns them into a payload stream that starts at lane 0 (vendored, formally checked
// sf_stream_dma_align gearbox).  Commands carry the physical window granted by the registry; EVERY command is first checked
// against the registry's DMA guard (valid region, reference held, physical window containment).  A command that fails the guard is
// dropped BEFORE any memory access and raises `viol`.
// Responses cannot be back-pressured by the memory: a request is issued only if its response will fit the response FIFO.
// Output: `pl_*` beats (always accepted: the consumer reserved the space before the command was issued), tagged with `pl_port`.
// `done_*` pulses once per command, in order, after its last beat.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_rdma_dma_rd #(
  parameter int DW      = 64,
  parameter int PA_W    = 32,
  parameter int RID_W   = 3,
  parameter int CTX_W   = 2,
  parameter int MEM_OUT = 4,                   // power of two
  parameter int CMD_Q   = 2,                   // power of two
  localparam int B      = DW/8,
  localparam int LB     = $clog2(DW/8)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clear,
  // command
  input  wire logic              cmd_valid,
  output logic                   cmd_ready,
  input  wire logic [PA_W-1:0]   cmd_pa,
  input  wire logic [15:0]       cmd_len,
  input  wire logic              cmd_port,
  input  wire logic [RID_W-1:0]  cmd_rid,
  input  wire logic [CTX_W-1:0]  cmd_ctx,
  output logic                   viol,
  // registry guard
  output logic [RID_W-1:0]       g_rid,
  output logic [PA_W-1:0]        g_pa,
  output logic [15:0]            g_len,
  input  wire logic              g_ok,
  // memory read port
  output logic                   mrd_valid,
  input  wire logic              mrd_ready,
  output logic [PA_W-1:0]        mrd_addr,
  output logic [CTX_W-1:0]       mrd_ctx,
  input  wire logic              mrd_rsp_valid,
  input  wire logic [DW-1:0]     mrd_rsp_data,
  input  wire logic              mrd_rsp_err,
  // payload out
  output logic                   pl_valid,
  output logic [DW-1:0]          pl_data,
  output logic [B-1:0]           pl_keep,
  output logic                   pl_last,
  output logic                   pl_port,
  output logic                   pl_err,               // sticky: a memory read of this command returned an error (valid with `pl_last`; the data is garbage)
  // completion / status
  output logic                   done_valid,
  output logic                   done_port,
  output logic                   done_err,
  output logic                   idle,
  output logic [LB:0]            bytes_n
);
  localparam int OW = $clog2(MEM_OUT);

  // ---- command FIFO (guard-checked at entry) ------------------------------------------------------------------------------
  wire              cq_full, cq_empty, cq_ovf, cq_unf;
  wire [$clog2(CMD_Q):0] cq_cnt;
  wire [PA_W+16+1+RID_W+CTX_W-1:0] cq_rd;
  wire              cmd_ok = g_ok;
  assign g_rid = cmd_rid; assign g_pa = cmd_pa; assign g_len = cmd_len;
  assign cmd_ready = !cq_full;
  wire cmd_take = cmd_valid && cmd_ready;
  logic viol_q;
  assign viol = viol_q;
  logic cq_pop;
  sf_rdma_fifo #(.WIDTH(PA_W+16+1+RID_W+CTX_W), .DEPTH(CMD_Q)) u_cq (
    .clk(clk), .rst_n(rst_n), .clear(clear), .push(cmd_take && cmd_ok), .wdata({cmd_pa, cmd_len, cmd_port, cmd_rid, cmd_ctx}),
    .pop(cq_pop), .rdata(cq_rd), .full(cq_full), .empty(cq_empty), .count(cq_cnt), .ovf(cq_ovf), .unf(cq_unf));
  wire [PA_W-1:0]  c_pa   = cq_rd[PA_W+16+1+RID_W+CTX_W-1 -: PA_W];
  wire [15:0]      c_len  = cq_rd[16+1+RID_W+CTX_W-1 -: 16];
  wire             c_port = cq_rd[1+RID_W+CTX_W-1];
  wire [CTX_W-1:0] c_ctx  = cq_rd[CTX_W-1:0];

  // ---- info FIFO (issue stage -> output stage): off, len, port ---------------------------------------------------------------
  wire              if_full, if_empty, if_ovf, if_unf;
  wire [$clog2(CMD_Q):0] if_cnt;
  wire [LB+16+1-1:0] if_rd;
  logic             if_push, if_pop;
  sf_rdma_fifo #(.WIDTH(LB+16+1), .DEPTH(CMD_Q)) u_if (
    .clk(clk), .rst_n(rst_n), .clear(clear), .push(if_push), .wdata({c_pa[LB-1:0], c_len, c_port}),
    .pop(if_pop), .rdata(if_rd), .full(if_full), .empty(if_empty), .count(if_cnt), .ovf(if_ovf), .unf(if_unf));

  // ---- response FIFO -------------------------------------------------------------------------------------------------------
  wire              rf_full, rf_empty, rf_ovf, rf_unf;
  wire [OW:0]       rf_cnt;
  wire [DW:0]       rf_rd;
  logic             rf_pop;
  sf_rdma_fifo #(.WIDTH(DW+1), .DEPTH(MEM_OUT)) u_rf (
    .clk(clk), .rst_n(rst_n), .clear(clear), .push(mrd_rsp_valid), .wdata({mrd_rsp_err, mrd_rsp_data}),
    .pop(rf_pop), .rdata(rf_rd), .full(rf_full), .empty(rf_empty), .count(rf_cnt), .ovf(rf_ovf), .unf(rf_unf));

  // ---- issue stage ----------------------------------------------------------------------------------------------------------
  logic              iss_act;
  logic [PA_W-1:0]   iss_addr;
  logic [16:0]       iss_words;
  logic [CTX_W-1:0]  iss_ctx;
  logic [OW+1:0]     outst;                    // issued, response not yet consumed by the output stage
  wire [31:0]        tot32     = 32'(c_pa[LB-1:0]) + 32'(c_len);
  wire [31:0]        nw32      = (tot32 + 32'(B-1)) >> LB;
  wire [16:0]        nwords    = nw32[16:0];
  assign cq_pop  = !cq_empty && !iss_act && !if_full;
  assign if_push = cq_pop;
  assign mrd_valid = iss_act && (outst < (OW+2)'(MEM_OUT));
  assign mrd_addr  = iss_addr;
  assign mrd_ctx   = iss_ctx;
  wire iss_hs = mrd_valid && mrd_ready;

  // ---- output stage + gearbox ---------------------------------------------------------------------------------------------
  logic              out_act;
  logic [LB-1:0]     out_off;
  logic [15:0]       push_left, emit_left;
  logic              first, o_port, err_acc;
  wire [DW-1:0]      rf_data = rf_rd[DW-1:0];
  wire               rf_err  = rf_rd[DW];

  wire [31:0]  pl32    = 32'(push_left);
  wire [31:0]  room32  = 32'(B) - 32'(out_off);                       // bytes of the first word that belong to the command
  wire [31:0]  firstn  = (room32 < pl32) ? room32 : pl32;
  wire [31:0]  fulln   = (32'(B) < pl32) ? 32'(B) : pl32;
  wire [31:0]  in_n32  = first ? firstn : fulln;
  wire [LB:0]  in_n    = in_n32[LB:0];
  wire [DW-1:0] shifted = first ? (rf_data >> (8 * 32'(out_off))) : rf_data;
  logic [DW-1:0] in_data_m;
  always_comb begin
    for (int i = 0; i < B; i++) in_data_m[8*i +: 8] = (i < 32'(in_n)) ? shifted[8*i +: 8] : 8'h00;
  end
  wire         gb_in_ready;
  wire         gb_push = out_act && !rf_empty && (push_left != 16'd0) && gb_in_ready;
  assign rf_pop = gb_push;

  wire [LB:0]  pop_n   = (emit_left >= 16'(B)) ? (LB+1)'(B) : (LB+1)'(emit_left);
  wire         gb_pop_ok;
  wire [DW-1:0] gb_out;
  wire [B-1:0]  gb_strb;
  wire [LB+1:0] gb_cnt;
  wire         do_emit = out_act && (emit_left != 16'd0) && gb_pop_ok;

  sf_stream_dma_align #(.DW(DW)) u_gb (
    .clk(clk), .rst_n(rst_n), .flush(clear),
    .in_valid(gb_push), .in_ready(gb_in_ready), .in_data(in_data_m), .in_nbytes(in_n),
    .pop_req(out_act && (emit_left != 16'd0)), .pop_lo('0), .pop_n(pop_n), .pop_ok(gb_pop_ok),
    .out_data(gb_out), .out_strb(gb_strb), .cnt(gb_cnt));

  assign pl_valid = do_emit;
  assign pl_data  = gb_out;
  assign pl_keep  = gb_strb;
  assign pl_last  = (emit_left <= 16'(B));
  assign pl_port  = o_port;
  assign pl_err   = err_acc || (gb_push && rf_err);
  assign bytes_n  = do_emit ? pop_n : '0;
  assign if_pop   = !out_act && !if_empty;

  wire fin = do_emit && (emit_left <= 16'(B));

  assign idle = cq_empty && if_empty && !iss_act && !out_act && (outst == '0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      iss_act <= 1'b0; iss_addr <= '0; iss_words <= '0; iss_ctx <= '0; outst <= '0;
      out_act <= 1'b0; out_off <= '0; push_left <= '0; emit_left <= '0; first <= 1'b0; o_port <= 1'b0; err_acc <= 1'b0;
      done_valid <= 1'b0; done_port <= 1'b0; done_err <= 1'b0; viol_q <= 1'b0;
    end else if (clear) begin
      iss_act <= 1'b0; outst <= '0; out_act <= 1'b0; done_valid <= 1'b0; viol_q <= 1'b0; err_acc <= 1'b0;
    end else begin
      done_valid <= 1'b0;
      viol_q     <= cmd_take && !cmd_ok;
      // issue
      if (cq_pop) begin
        iss_act   <= 1'b1;
        iss_addr  <= {c_pa[PA_W-1:LB], {LB{1'b0}}};
        iss_words <= nwords;
        iss_ctx   <= c_ctx;
      end
      if (iss_hs) begin
        iss_addr  <= iss_addr + PA_W'(B);
        iss_words <= iss_words - 17'd1;
        if (iss_words == 17'd1) iss_act <= 1'b0;
      end
      outst <= outst + (OW+2)'(iss_hs ? 1 : 0) - (OW+2)'(rf_pop ? 1 : 0);
      // output
      if (if_pop) begin
        out_act   <= 1'b1;
        out_off   <= if_rd[LB+16+1-1 -: LB];
        push_left <= if_rd[16:1];
        emit_left <= if_rd[16:1];
        o_port    <= if_rd[0];
        first     <= 1'b1;
        err_acc   <= 1'b0;
      end
      if (gb_push) begin
        push_left <= push_left - 16'(in_n);
        first     <= 1'b0;
        if (rf_err) err_acc <= 1'b1;
      end
      if (do_emit) emit_left <= emit_left - 16'(pop_n);
      if (fin) begin
        out_act    <= 1'b0;
        done_valid <= 1'b1;
        done_port  <= o_port;
        done_err   <= err_acc || (gb_push && rf_err);
      end
    end
  end
endmodule
`default_nettype wire
