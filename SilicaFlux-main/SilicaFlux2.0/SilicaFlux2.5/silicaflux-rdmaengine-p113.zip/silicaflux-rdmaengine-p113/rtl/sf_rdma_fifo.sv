// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_fifo
// Small first-word-fall-through FIFO with a synchronous `clear` (needed by QP reset).  Power-of-two depth.
// A push while full or a pop while empty is IGNORED and raises the sticky `ovf` / `unf` diagnostics (clients are built so that
// this cannot happen; the formal harnesses assert it).  Storage is not reset.
// Why not the repository's sync_fifo: it has no flush, and uses `initial` + concurrent SVA that the formal flow cannot read
// (docs/00_AUDIT.md).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_rdma_fifo #(
  parameter int WIDTH = 8,
  parameter int DEPTH = 4                      // power of two, >= 2
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             clear,
  input  wire logic             push,
  input  wire logic [WIDTH-1:0] wdata,
  input  wire logic             pop,
  output logic [WIDTH-1:0]      rdata,
  output logic                  full,
  output logic                  empty,
  output logic [$clog2(DEPTH):0] count,
  output logic                  ovf,
  output logic                  unf
);
  localparam int AB = $clog2(DEPTH);
  logic [WIDTH-1:0] mem [0:DEPTH-1];
  logic [AB:0] wp, rp;
  assign count = wp - rp;
  assign full  = (count == (AB+1)'(DEPTH));
  assign empty = (wp == rp);
  assign rdata = mem[rp[AB-1:0]];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp <= '0; rp <= '0; ovf <= 1'b0; unf <= 1'b0;
    end else if (clear) begin
      wp <= '0; rp <= '0;
    end else begin
      if (push && !full) begin mem[wp[AB-1:0]] <= wdata; wp <= wp + 1'b1; end
      if (push &&  full) ovf <= 1'b1;
      if (pop  && !empty) rp <= rp + 1'b1;
      if (pop  &&  empty) unf <= 1'b1;
    end
  end
endmodule
`default_nettype wire
