// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_completion
//
// Completion queue with CREDIT RESERVATION.
//   Every accepted post (SQ or RQ) takes one credit; the credit is returned when the host CONSUMES the CQE.  Hence
//        posted-and-uncompleted WQEs + CQ occupancy <= CQ_DEPTH
//   at all times, so a completion (including a flush completion) can ALWAYS be stored: the CQ can never overflow and a
//   completion can never be lost.  If the host stops draining, `credits_ge1` falls and posting is back-pressured.
//   Two producers (P0 = send-queue side, P1 = receive-queue side) are merged by a round-robin arbiter.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none

module sf_rdma_completion #(
  parameter int CQ_DEPTH = 32                   // power of two
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic [15:0] local_qpn,
  // credit reservation
  input  wire logic        take_sq,
  input  wire logic        take_rq,
  output logic             credits_ge1,
  output logic             credits_ge2,
  // producers
  input  wire logic        p0_valid,
  output logic             p0_ready,
  input  wire logic [63:0] p0_wr_id,
  input  wire logic [3:0]  p0_op,
  input  wire logic [3:0]  p0_status,
  input  wire logic [31:0] p0_len,
  input  wire logic        p1_valid,
  output logic             p1_ready,
  input  wire logic [63:0] p1_wr_id,
  input  wire logic [3:0]  p1_op,
  input  wire logic [3:0]  p1_status,
  input  wire logic [31:0] p1_len,
  // host side
  output logic             cq_valid,
  input  wire logic        cq_ready,
  output logic [63:0]      cq_wr_id,
  output logic [3:0]       cq_op,
  output logic [3:0]       cq_status,
  output logic [31:0]      cq_len,
  output logic [15:0]      cq_qpn,
  output logic [$clog2(CQ_DEPTH):0] cq_count,
  output logic [$clog2(CQ_DEPTH):0] credits,
  output logic             ev_overflow        // diagnostic: a push found the FIFO full (impossible by construction)
);
  localparam int AB = $clog2(CQ_DEPTH);

  logic [63:0] m_wr [0:CQ_DEPTH-1];
  logic [3:0]  m_op [0:CQ_DEPTH-1];
  logic [3:0]  m_st [0:CQ_DEPTH-1];
  logic [31:0] m_ln [0:CQ_DEPTH-1];
  logic [AB:0] wp, rp;
  logic        last_p1;                       // round-robin: 1 = P1 won last

  wire full  = (wp - rp) == (AB+1)'(CQ_DEPTH);
  wire empty = (wp == rp);
  assign cq_count = wp - rp;

  wire g1 = p1_valid && (!p0_valid || !last_p1);   // P1 gets it if P0 idle, or P0 won last time
  wire g0 = p0_valid && !g1;
  assign p0_ready = g0 && !full;
  assign p1_ready = g1 && !full;
  wire push = (p0_valid || p1_valid) && !full;
  assign ev_overflow = (p0_valid || p1_valid) && full;

  assign credits_ge1 = (credits >= (AB+1)'(1));
  assign credits_ge2 = (credits >= (AB+1)'(2));

  assign cq_valid  = !empty;
  assign cq_wr_id  = m_wr[rp[AB-1:0]];
  assign cq_op     = m_op[rp[AB-1:0]];
  assign cq_status = m_st[rp[AB-1:0]];
  assign cq_len    = m_ln[rp[AB-1:0]];
  assign cq_qpn    = local_qpn;

  wire pop = cq_valid && cq_ready;
  logic [AB:0] credits_nx;
  always_comb begin
    credits_nx = credits;
    if (take_sq) credits_nx = credits_nx - 1'b1;
    if (take_rq) credits_nx = credits_nx - 1'b1;
    if (pop)     credits_nx = credits_nx + 1'b1;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp <= '0; rp <= '0; last_p1 <= 1'b0; credits <= (AB+1)'(CQ_DEPTH);
    end else begin
      credits <= credits_nx;
      if (push) begin
        if (g1) begin
          m_wr[wp[AB-1:0]] <= p1_wr_id; m_op[wp[AB-1:0]] <= p1_op; m_st[wp[AB-1:0]] <= p1_status; m_ln[wp[AB-1:0]] <= p1_len;
        end else begin
          m_wr[wp[AB-1:0]] <= p0_wr_id; m_op[wp[AB-1:0]] <= p0_op; m_st[wp[AB-1:0]] <= p0_status; m_ln[wp[AB-1:0]] <= p0_len;
        end
        wp      <= wp + 1'b1;
        last_p1 <= g1;
      end
      if (pop) rp <= rp + 1'b1;
    end
  end
endmodule
`default_nettype wire
