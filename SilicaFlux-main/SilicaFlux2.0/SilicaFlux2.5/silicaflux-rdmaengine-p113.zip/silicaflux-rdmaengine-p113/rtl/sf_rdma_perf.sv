// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_perf
//
// Performance counters.  Everything is MEASURED from observed events, nothing is estimated:
//   * plain event / byte counters:   cnt[i] += inc[i]         (the engine top wires one increment per counter index)
//   * operation latency (cycles from WQE issue to its CQE) for WRITE / READ / SEND: sum, count, min, max
//   * queue occupancy (SQ, RQ, CQ, request window): high-water mark and cycle-integral (sum / CYCLES = mean occupancy)
//   * the registry's per-class fault counters are passed through (indices SFR_PC_MR_FAULT_*)
// Counters are 48 bits wide (readout zero-extended to 64) and saturate.  A read is `rd_idx` -> `rd_data` (combinational).
// `clr` zeroes the counters in this block (not the registry's fault counters, not the adapter's free-running state).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none

module sf_rdma_perf #(
  parameter int NPC = `SFR_PC_NUM,
  parameter int CW  = 48
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                clr,
  output logic [31:0]              now,
  input  wire logic [NPC*32-1:0]   inc,            // per-counter increment this cycle (the pass-through indices ignore it)
  // latency
  input  wire logic                lat_valid,
  input  wire logic [1:0]          lat_op,         // 1 SEND, 2 WRITE, 3 READ
  input  wire logic [31:0]         lat_cycles,
  // occupancy levels
  input  wire logic [31:0]         occ_sq,
  input  wire logic [31:0]         occ_rq,
  input  wire logic [31:0]         occ_cq,
  input  wire logic [31:0]         occ_win,
  // registry fault counters (index 0 = total, 1..10 = classes)
  input  wire logic [`SFR_NFAULT*32-1:0] fault_cnt,
  // readout
  input  wire logic [7:0]          rd_idx,
  output logic [63:0]              rd_data
);
  logic [CW-1:0] cnt [0:NPC-1];
  wire  [CW-1:0] sat = {CW{1'b1}};

  function automatic logic [CW-1:0] sadd(input logic [CW-1:0] a, input logic [31:0] b);
    logic [CW:0] t;
    begin t = {1'b0, a} + {{(CW+1-32){1'b0}}, b}; sadd = t[CW] ? {CW{1'b1}} : t[CW-1:0]; end
  endfunction

  // latency bookkeeping selects
  wire is_wr = lat_valid && (lat_op == 2'd2);
  wire is_rd = lat_valid && (lat_op == 2'd3);
  wire is_sd = lat_valid && (lat_op == 2'd1);

  // ---- next-value network (combinational): generic increment, then the special indices override ------------------------------------
  logic [CW-1:0] nx [0:NPC-1];
  always_comb begin
    for (int i = 0; i < NPC; i++) nx[i] = sadd(cnt[i], inc[i*32 +: 32]);
    nx[`SFR_PC_CYCLES]       = sadd(cnt[`SFR_PC_CYCLES], 32'd1);
    nx[`SFR_PC_LAT_WR_SUM]   = sadd(cnt[`SFR_PC_LAT_WR_SUM], is_wr ? lat_cycles : 32'd0);
    nx[`SFR_PC_LAT_WR_CNT]   = sadd(cnt[`SFR_PC_LAT_WR_CNT], is_wr ? 32'd1 : 32'd0);
    nx[`SFR_PC_LAT_RD_SUM]   = sadd(cnt[`SFR_PC_LAT_RD_SUM], is_rd ? lat_cycles : 32'd0);
    nx[`SFR_PC_LAT_RD_CNT]   = sadd(cnt[`SFR_PC_LAT_RD_CNT], is_rd ? 32'd1 : 32'd0);
    nx[`SFR_PC_LAT_SD_SUM]   = sadd(cnt[`SFR_PC_LAT_SD_SUM], is_sd ? lat_cycles : 32'd0);
    nx[`SFR_PC_LAT_SD_CNT]   = sadd(cnt[`SFR_PC_LAT_SD_CNT], is_sd ? 32'd1 : 32'd0);
    nx[`SFR_PC_LAT_WR_MIN]   = (is_wr && {16'd0, lat_cycles} < cnt[`SFR_PC_LAT_WR_MIN]) ? {16'd0, lat_cycles} : cnt[`SFR_PC_LAT_WR_MIN];
    nx[`SFR_PC_LAT_RD_MIN]   = (is_rd && {16'd0, lat_cycles} < cnt[`SFR_PC_LAT_RD_MIN]) ? {16'd0, lat_cycles} : cnt[`SFR_PC_LAT_RD_MIN];
    nx[`SFR_PC_LAT_SD_MIN]   = (is_sd && {16'd0, lat_cycles} < cnt[`SFR_PC_LAT_SD_MIN]) ? {16'd0, lat_cycles} : cnt[`SFR_PC_LAT_SD_MIN];
    nx[`SFR_PC_LAT_WR_MAX]   = (is_wr && {16'd0, lat_cycles} > cnt[`SFR_PC_LAT_WR_MAX]) ? {16'd0, lat_cycles} : cnt[`SFR_PC_LAT_WR_MAX];
    nx[`SFR_PC_LAT_RD_MAX]   = (is_rd && {16'd0, lat_cycles} > cnt[`SFR_PC_LAT_RD_MAX]) ? {16'd0, lat_cycles} : cnt[`SFR_PC_LAT_RD_MAX];
    nx[`SFR_PC_LAT_SD_MAX]   = (is_sd && {16'd0, lat_cycles} > cnt[`SFR_PC_LAT_SD_MAX]) ? {16'd0, lat_cycles} : cnt[`SFR_PC_LAT_SD_MAX];
    nx[`SFR_PC_SQ_OCC_MAX]   = ({16'd0, occ_sq}  > cnt[`SFR_PC_SQ_OCC_MAX])  ? {16'd0, occ_sq}  : cnt[`SFR_PC_SQ_OCC_MAX];
    nx[`SFR_PC_RQ_OCC_MAX]   = ({16'd0, occ_rq}  > cnt[`SFR_PC_RQ_OCC_MAX])  ? {16'd0, occ_rq}  : cnt[`SFR_PC_RQ_OCC_MAX];
    nx[`SFR_PC_CQ_OCC_MAX]   = ({16'd0, occ_cq}  > cnt[`SFR_PC_CQ_OCC_MAX])  ? {16'd0, occ_cq}  : cnt[`SFR_PC_CQ_OCC_MAX];
    nx[`SFR_PC_WIN_OCC_MAX]  = ({16'd0, occ_win} > cnt[`SFR_PC_WIN_OCC_MAX]) ? {16'd0, occ_win} : cnt[`SFR_PC_WIN_OCC_MAX];
    nx[`SFR_PC_SQ_OCC_SUM]   = sadd(cnt[`SFR_PC_SQ_OCC_SUM],  occ_sq);
    nx[`SFR_PC_RQ_OCC_SUM]   = sadd(cnt[`SFR_PC_RQ_OCC_SUM],  occ_rq);
    nx[`SFR_PC_CQ_OCC_SUM]   = sadd(cnt[`SFR_PC_CQ_OCC_SUM],  occ_cq);
    nx[`SFR_PC_WIN_OCC_SUM]  = sadd(cnt[`SFR_PC_WIN_OCC_SUM], occ_win);
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) now <= 32'd0;
    else        now <= now + 32'd1;
  end

  // one register process per counter: reset/clear value is all-ones for the three minima, zero otherwise
  genvar gi;
  generate
    for (gi = 0; gi < NPC; gi++) begin : g_cnt
      localparam bit IS_MIN = (gi == `SFR_PC_LAT_WR_MIN) || (gi == `SFR_PC_LAT_RD_MIN) || (gi == `SFR_PC_LAT_SD_MIN);
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)    cnt[gi] <= IS_MIN ? sat : '0;
        else if (clr)  cnt[gi] <= IS_MIN ? sat : '0;
        else           cnt[gi] <= nx[gi];
      end
    end
  endgenerate

  // ---- readout --------------------------------------------------------------------------------------------------------------------
  always_comb begin
    rd_data = '0;
    if (rd_idx < 8'(NPC)) rd_data = {{(64-CW){1'b0}}, cnt[rd_idx[6:0]]};
    // a minimum with no sample reads as 0
    if (rd_idx == 8'(`SFR_PC_LAT_WR_MIN) && cnt[`SFR_PC_LAT_WR_CNT] == '0) rd_data = 64'd0;
    if (rd_idx == 8'(`SFR_PC_LAT_RD_MIN) && cnt[`SFR_PC_LAT_RD_CNT] == '0) rd_data = 64'd0;
    if (rd_idx == 8'(`SFR_PC_LAT_SD_MIN) && cnt[`SFR_PC_LAT_SD_CNT] == '0) rd_data = 64'd0;
    // registry fault counters pass through
    if (rd_idx >= 8'(`SFR_PC_MR_FAULT_TOTAL) && rd_idx < 8'(`SFR_PC_MR_FAULT_TOTAL + `SFR_NFAULT + 1)) begin
      case (rd_idx)
        8'(`SFR_PC_MR_FAULT_TOTAL):                 rd_data = {32'd0, fault_cnt[0*32 +: 32]};
        8'(`SFR_PC_MR_FAULT_BASE + 1):              rd_data = {32'd0, fault_cnt[1*32 +: 32]};
        8'(`SFR_PC_MR_FAULT_BASE + 2):              rd_data = {32'd0, fault_cnt[2*32 +: 32]};
        8'(`SFR_PC_MR_FAULT_BASE + 3):              rd_data = {32'd0, fault_cnt[3*32 +: 32]};
        8'(`SFR_PC_MR_FAULT_BASE + 4):              rd_data = {32'd0, fault_cnt[4*32 +: 32]};
        8'(`SFR_PC_MR_FAULT_BASE + 5):              rd_data = {32'd0, fault_cnt[5*32 +: 32]};
        8'(`SFR_PC_MR_FAULT_BASE + 6):              rd_data = {32'd0, fault_cnt[6*32 +: 32]};
        8'(`SFR_PC_MR_FAULT_BASE + 7):              rd_data = {32'd0, fault_cnt[7*32 +: 32]};
        8'(`SFR_PC_MR_FAULT_BASE + 8):              rd_data = {32'd0, fault_cnt[8*32 +: 32]};
        8'(`SFR_PC_MR_FAULT_BASE + 9):              rd_data = {32'd0, fault_cnt[9*32 +: 32]};
        8'(`SFR_PC_MR_FAULT_BASE + 10):             rd_data = {32'd0, fault_cnt[10*32 +: 32]};
        default: ;
      endcase
    end
  end
endmodule
`default_nettype wire
