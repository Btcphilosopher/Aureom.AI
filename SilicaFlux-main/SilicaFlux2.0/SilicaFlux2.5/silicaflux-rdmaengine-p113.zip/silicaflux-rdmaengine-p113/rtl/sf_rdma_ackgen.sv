// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_ackgen
//
// ACK / NAK generator of the responder.  DECOUPLED from frame reception: the receive processor only sets flags here and never waits
// for the transmit side (this is what makes the two-endpoint system deadlock free, spec 12.7).
//   ACK  {psn = commit_next(cpsn), accept_next(epsn), code 0}: scheduled when cpsn advances, on a duplicate, and opportunistically
//        for ACCEPTANCE when epsn moved but nothing was reported for ACCEPT_ACK_DELAY cycles.  Coalescing is natural: the frame is
//        built from the frontiers at the moment it is pushed.
//   NAK  SEQ_ERR / RNR: one-shot flags.
//   FATAL NAK (INV_REQ / REM_ACCESS / REM_OP): emitted only after cpsn == epsn (every earlier request committed), so it always has
//        commit_next == accept_next == PSN of the failed request.  After emission the responder QP is in ERR and every later request
//        frame is answered with the same NAK (REPLAY), making error reporting reliable under loss.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none

module sf_rdma_ackgen #(
  parameter int ACCEPT_ACK_DELAY = 64
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        clear,
  input  wire logic        en,                  // QP in RTR/RTS (or ERR with replay armed)
  input  wire logic [15:0] remote_qpn,
  input  wire logic [15:0] epoch,
  input  wire logic [23:0] cpsn,
  input  wire logic [23:0] epsn,
  // triggers from the receive processor (single-cycle pulses)
  input  wire logic        acc_ev,              // a request was ACCEPTED (epsn advanced)
  input  wire logic        ack_set,
  input  wire logic        nak_set,
  input  wire logic [3:0]  nak_code,
  input  wire logic        fatal_set,
  input  wire logic [3:0]  fatal_code,
  input  wire logic        replay_set,
  // transmit request (control port)
  output logic             tx_valid,
  input  wire logic        tx_ready,
  output logic [271:0]     tx_sh,
  // status
  output logic             fatal_pend,          // a fatal error was decided; further requests are discarded
  output logic             resp_err,            // fatal NAK emitted: the responder QP must enter ERR; replay armed
  output logic             err_req,             // one-cycle pulse: request QP ERR (cause RESP_FATAL)
  output logic             ev_tx_nak,
  output logic             ev_rnr_sent,
  output logic             idle
);
  logic        ack_pend, nak_pend, rep_pend;
  logic [3:0]  nak_c, fat_c;
  logic        acc_pend;                        // something was accepted since the last report (acceptance reporting)
  logic [31:0] dly;

  wire fatal_ready = fatal_pend && !resp_err && (cpsn == epsn);
  wire send_fatal  = fatal_ready;
  wire send_nak    = !send_fatal && nak_pend;
  wire send_rep    = !send_fatal && !send_nak && rep_pend && resp_err;
  wire send_ack    = !send_fatal && !send_nak && !send_rep && ack_pend;
  assign tx_valid  = en && (send_fatal || send_nak || send_rep || send_ack);

  wire [3:0]  code = send_fatal ? fat_c : send_nak ? nak_c : send_rep ? fat_c : 4'd0;
  wire        is_nak = (code != 4'd0);
  wire [7:0]  opc  = is_nak ? `SFR_OP_NAK : `SFR_OP_ACK;
  wire [7:0]  vf   = {`SFR_VERSION, 4'b0000};
  wire [23:0] c24  = cpsn;
  wire [23:0] e24  = epsn;
  wire [15:0] qn   = remote_qpn;
  wire [15:0] ep   = epoch;
  wire [7:0]  cd8  = {4'd0, code};
  always_comb begin
    tx_sh = '0;
    tx_sh[8*`SFR_SH_VF     +: 8]  = vf;
    tx_sh[8*`SFR_SH_OPC    +: 8]  = opc;
    tx_sh[8*`SFR_SH_QPN    +: 16] = `SFR_BSW16(qn);
    tx_sh[8*`SFR_SH_EPOCH  +: 16] = `SFR_BSW16(ep);
    tx_sh[8*`SFR_SH_PSN    +: 24] = `SFR_BSW24(c24);
    tx_sh[8*`SFR_SH_CODE   +: 8]  = cd8;
    tx_sh[8*`SFR_SH_ACCEPT +: 24] = `SFR_BSW24(e24);
  end
  wire hs = tx_valid && tx_ready;
  assign ev_tx_nak   = hs && is_nak;
  assign ev_rnr_sent = hs && (code == `SFR_NAK_RNR);
  assign err_req     = hs && send_fatal;
  assign idle        = !ack_pend && !nak_pend && !rep_pend && !(fatal_pend && !resp_err);

  // ---- next-state: an event ALWAYS beats the clear of the frame being pushed in the same cycle --------------------------------
  // (An ACK pushed this cycle is built from the frontiers BEFORE this cycle's commit, so a commit in the same cycle is NOT covered by
  //  it and must leave its ACK pending.  Doing "set" before "clear" in program order silently lost that ACK: the requester then
  //  timed out and retransmitted -- found by the independent random regression.)
  logic        ack_pend_n, nak_pend_n, rep_pend_n, acc_pend_n, dly_exp;
  logic [31:0] dly_n;
  always_comb begin
    ack_pend_n = ack_pend; nak_pend_n = nak_pend; rep_pend_n = rep_pend; acc_pend_n = acc_pend;
    dly_n = acc_pend ? dly + 32'd1 : 32'd0;
    dly_exp = acc_pend && (dly + 32'd1 >= 32'(ACCEPT_ACK_DELAY));
    if (hs) begin                                   // the pushed frame consumes exactly one pending item
      acc_pend_n = 1'b0; dly_n = 32'd0;
      if (!send_fatal) begin
        if (send_nak) nak_pend_n = 1'b0; else if (send_rep) rep_pend_n = 1'b0; else ack_pend_n = 1'b0;
      end
    end
    if (dly_exp && !hs) begin ack_pend_n = 1'b1; acc_pend_n = 1'b0; dly_n = 32'd0; end   // acceptance report is due
    if (ack_set)                  ack_pend_n = 1'b1;                                     // events win over the clear above
    if (nak_set)                  nak_pend_n = 1'b1;
    if (replay_set && resp_err)   rep_pend_n = 1'b1;
    if (acc_ev)                   acc_pend_n = 1'b1;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ack_pend <= 1'b0; nak_pend <= 1'b0; rep_pend <= 1'b0; nak_c <= '0; fat_c <= '0; fatal_pend <= 1'b0; resp_err <= 1'b0;
      acc_pend <= 1'b0; dly <= '0;
    end else if (clear) begin
      ack_pend <= 1'b0; nak_pend <= 1'b0; rep_pend <= 1'b0; fatal_pend <= 1'b0; resp_err <= 1'b0; dly <= '0; acc_pend <= 1'b0;
    end else begin
      ack_pend <= ack_pend_n; nak_pend <= nak_pend_n; rep_pend <= rep_pend_n; acc_pend <= acc_pend_n; dly <= dly_n;
      if (nak_set) nak_c <= nak_code;
      if (fatal_set && !fatal_pend) begin fatal_pend <= 1'b1; fat_c <= fatal_code; end
      if (hs && send_fatal) resp_err <= 1'b1;
    end
  end
endmodule
`default_nettype wire
