// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_retry
//
// Retransmission timer, retry accounting and RNR back-off (spec 9.6).
//   * The timer runs while `armed` (unfinished work AND something transmitted) and not in RNR wait.  `progress` restarts it and
//     resets BOTH consecutive-retry counters.  `restart` (a retransmission was started) restarts the timer only.
//   * Expiry (or a SEQ_ERR NAK, `nak_retry`): with k consecutive retries so far, k == retry_max -> `exhausted` (one pulse, then dead
//     until `en` falls) else k++ and `ev_timeout` / `ev_nak`.   Effective timeout = timeout << min(k, BACKOFF_MAX).
//   * RNR NAK: r == rnr_max -> `rnr_exhausted`; else r++, wait `rnr_delay` cycles (`rnr_wait` high: the requester transmits nothing),
//     then `ev_rnr`.  RNR NAKs arriving during the wait are ignored (they are in-flight duplicates).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_rdma_retry #(
  parameter int BACKOFF_MAX = 3
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        en,
  input  wire logic        armed,
  input  wire logic        progress,
  input  wire logic        restart,
  input  wire logic        nak_retry,
  input  wire logic        rnr_nak,
  input  wire logic [31:0] cfg_timeout,
  input  wire logic [3:0]  cfg_retry_max,
  input  wire logic [3:0]  cfg_rnr_max,
  input  wire logic [31:0] cfg_rnr_delay,
  output logic             ev_timeout,
  output logic             ev_nak,
  output logic             ev_rnr,
  output logic             exhausted,
  output logic             rnr_exhausted,
  output logic             rnr_wait,
  output logic [3:0]       retry_cnt,
  output logic [3:0]       rnr_cnt
);
  logic [34:0] tcnt;
  logic [31:0] rcnt;
  logic        dead;

  wire [2:0]  sh    = (retry_cnt > 4'(BACKOFF_MAX)) ? 3'(BACKOFF_MAX) : retry_cnt[2:0];
  wire [34:0] limit = {3'b0, cfg_timeout} << sh;
  wire        expire = en && armed && !rnr_wait && (tcnt >= limit);

  // Consecutive-retry accounting restarts on `progress`, but an event that arrives in the SAME cycle is still an event: it is counted
  // against the restarted base (a SEQ_ERR NAK normally comes WITH a commit-frontier advance, i.e. with progress; the old code let the
  // progress branch swallow it, so go-back-N and RNR back-off fell back to the 3000-cycle timer -- found by the independent review, F-03).
  wire [3:0] rc_b = progress ? 4'd0 : retry_cnt;
  wire [3:0] nc_b = progress ? 4'd0 : rnr_cnt;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tcnt <= '0; rcnt <= '0; dead <= 1'b0; rnr_wait <= 1'b0; retry_cnt <= '0; rnr_cnt <= '0;
      ev_timeout <= 1'b0; ev_nak <= 1'b0; ev_rnr <= 1'b0; exhausted <= 1'b0; rnr_exhausted <= 1'b0;
    end else begin
      ev_timeout <= 1'b0; ev_nak <= 1'b0; ev_rnr <= 1'b0; exhausted <= 1'b0; rnr_exhausted <= 1'b0;
      if (!en) begin
        tcnt <= '0; rcnt <= '0; dead <= 1'b0; rnr_wait <= 1'b0; retry_cnt <= '0; rnr_cnt <= '0;
      end else begin
        if (progress) begin tcnt <= '0; retry_cnt <= '0; rnr_cnt <= '0; dead <= 1'b0; end   // (an event below may set `dead` again)
        else if (restart || !armed) tcnt <= '0;                // never carry a stale count into a new armed period
        else if (!rnr_wait) tcnt <= tcnt + 1'b1;

        if (rnr_wait) begin
          if (!progress) begin                                // (the wait is paused for the cycle of a progress event, as before)
            rcnt <= rcnt + 1'b1;
            if (rcnt + 32'd1 >= cfg_rnr_delay) begin
              rnr_wait <= 1'b0; ev_rnr <= 1'b1; tcnt <= '0;
            end
          end
        end else if (!dead) begin
          if (rnr_nak) begin
            if (nc_b == cfg_rnr_max) begin rnr_exhausted <= 1'b1; dead <= 1'b1; end
            else begin rnr_cnt <= nc_b + 1'b1; rnr_wait <= 1'b1; rcnt <= '0; end
          end else if ((expire && !progress) || nak_retry) begin
            if (rc_b == cfg_retry_max) begin exhausted <= 1'b1; dead <= 1'b1; end
            else begin
              retry_cnt <= rc_b + 1'b1; tcnt <= '0;
              if (nak_retry) ev_nak <= 1'b1; else ev_timeout <= 1'b1;
            end
          end
        end
      end
    end
  end
endmodule
`default_nettype wire
