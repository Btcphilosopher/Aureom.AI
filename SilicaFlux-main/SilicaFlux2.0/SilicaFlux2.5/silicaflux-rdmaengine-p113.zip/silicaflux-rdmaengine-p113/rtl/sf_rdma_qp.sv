// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_qp   (queue-pair controller; ONE queue pair)
//
// Holds the QP state machine and the trusted connection attributes, and ties together
//     requester (sf_rdma_requester)  receive processor / responder (sf_rdma_rx)  read executor (sf_rdma_rdgen)
//     ACK/NAK generator (sf_rdma_ackgen)  and the transmit glue (header + payload-fetch reservation, frame arbitration inputs).
//
// STATES  RESET -> INIT -> RTR -> RTS, ERR, and the internal DRAIN (reset in progress).  Transitions only by the trusted `qm_*` command
// (or the documented fatal-error transitions to ERR).  ERR flushes every outstanding WQE (spec 11.1).  QP reset (spec 11.5): flush,
// wait until the DMA engines and the transmit adapter are quiescent (in-flight DMA completes, a frame in transmission completes),
// then clear ALL QP state, references and queued frames; the memory-region table and the CQ contents are preserved.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none

module sf_rdma_qp #(
  parameter int WINDOW        = 8,
  parameter int MAX_RD        = 2,
  parameter int MTU           = 256,
  parameter int PA_W          = 32,
  parameter int PD_W          = 4,
  parameter int RID_W         = 3,
  parameter int CTX_W         = 2,
  parameter int RDQ           = 4,
  parameter int TAGQ          = 16,
  parameter int MAX_MSG_BYTES = 1048576,
  parameter int ACCEPT_ACK_DELAY = 64,
  localparam int WB           = $clog2(WINDOW)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic [31:0]       now,
  // ---- trusted QP command ---------------------------------------------------------------------------------------------------------
  input  wire logic              qm_valid,
  input  wire logic [2:0]        qm_state,
  input  wire logic [15:0]       qm_qpn,
  input  wire logic [PD_W-1:0]   qm_pd,
  input  wire logic [15:0]       qm_rqpn,
  input  wire logic [15:0]       qm_epoch,
  input  wire logic [23:0]       qm_rq_psn,
  input  wire logic [47:0]       qm_lmac,
  input  wire logic [47:0]       qm_pmac,
  input  wire logic [23:0]       qm_sq_psn,
  input  wire logic [31:0]       qm_timeout,
  input  wire logic [3:0]        qm_retry,
  input  wire logic [3:0]        qm_rnr_retry,
  input  wire logic [31:0]       qm_rnr_delay,
  output logic                   qm_rsp_valid,
  output logic [3:0]             qm_rsp_status,
  // ---- QP status / connection attributes (to the adapter and the top) ------------------------------------------------------------------
  output logic [2:0]             qp_state,
  output logic [3:0]             qp_err_cause,
  output logic [15:0]            local_qpn,
  output logic [47:0]            cfg_local_mac,
  output logic [47:0]            cfg_peer_mac,
  output logic [15:0]            cfg_epoch,
  output logic                   cfg_req_en,
  output logic                   cfg_resp_en,
  // ---- SQ / RQ heads --------------------------------------------------------------------------------------------------------------------
  input  wire logic              sq_valid,
  output logic                   sq_pop,
  input  wire logic [1:0]        sq_op,
  input  wire logic [63:0]       sq_wr_id,
  input  wire logic [63:0]       sq_laddr,
  input  wire logic [31:0]       sq_lkey,
  input  wire logic [31:0]       sq_len,
  input  wire logic [63:0]       sq_raddr,
  input  wire logic [31:0]       sq_rkey,
  input  wire logic              rq_valid,
  output logic                   rq_pop,
  input  wire logic [63:0]       rq_wr_id,
  input  wire logic [63:0]       rq_addr,
  input  wire logic [31:0]       rq_lkey,
  input  wire logic [31:0]       rq_len,
  // ---- registry: two check ports, three release ports -------------------------------------------------------------------------------------
  output logic [1:0]             reg_chk_valid,
  output logic [3:0]             reg_chk_op,
  output logic [2*32-1:0]        reg_chk_key,
  output logic [2*PD_W-1:0]      reg_chk_pd,
  output logic [2*64-1:0]        reg_chk_va,
  output logic [2*32-1:0]        reg_chk_len,
  input  wire logic [1:0]        reg_rsp_valid,
  input  wire logic [1:0]        reg_rsp_ok,
  input  wire logic [2*RID_W-1:0] reg_rsp_rid,
  input  wire logic [2*PA_W-1:0] reg_rsp_pa,
  input  wire logic [2*CTX_W-1:0] reg_rsp_ctx,
  output logic [5:0]             reg_rel_valid,          // one release port per source: 0 requester ctx, 1 requester flushed check, 2 rx commit, 3 rx abort, 4 rx flush, 5 read executor
  output logic [6*RID_W-1:0]     reg_rel_rid,
  output logic                   reg_ref_clear,
  // ---- data movement ---------------------------------------------------------------------------------------------------------------------
  output logic                   rdc_valid,
  input  wire logic              rdc_ready,
  output logic [PA_W-1:0]        rdc_pa,
  output logic [15:0]            rdc_len,
  output logic                   rdc_port,
  output logic [RID_W-1:0]       rdc_rid,
  output logic [CTX_W-1:0]       rdc_ctx,
  input  wire logic              rd_done_valid,
  input  wire logic              rd_done_port,
  input  wire logic              rd_viol,
  input  wire logic              rd_idle,
  output logic                   dw_cmd_valid,
  input  wire logic              dw_cmd_ready,
  output logic                   dw_cmd_discard,
  output logic [PA_W-1:0]        dw_cmd_pa,
  output logic [15:0]            dw_cmd_len,
  output logic [RID_W-1:0]       dw_cmd_rid,
  output logic [CTX_W-1:0]       dw_cmd_ctx,
  input  wire logic              dw_done_valid,
  input  wire logic              dw_done_err,
  input  wire logic              dw_viol,
  input  wire logic              dw_idle,
  output logic                   dma_clear,
  // ---- transport adapter ---------------------------------------------------------------------------------------------------------------
  output logic [2:0]             txh_valid,
  input  wire logic [2:0]        txh_ready,
  output logic [3*272-1:0]       txh_sh,
  output logic                   tx_hold,
  output logic                   tx_flush,
  output logic                   tx_drop_req,
  input  wire logic              tx_quiet,
  input  wire logic              ad_abort_ev,           // the adapter dropped a frame instead of transmitting it
  input  wire logic              ad_abort_err,          //   ... because its payload fetch failed (memory error)
  input  wire logic              ad_abort_port,         //   0 requester request, 1 read response
  input  wire logic [23:0]       ad_abort_psn,
  input  wire logic              rxh_valid,
  input  wire logic [271:0]      rxh_sh,
  output logic                   rxh_pop,
  output logic                   rx_flush,
  // ---- completion producers ------------------------------------------------------------------------------------------------------------
  output logic                   c0_valid,
  input  wire logic              c0_ready,
  output logic [63:0]            c0_wr_id,
  output logic [3:0]             c0_op,
  output logic [3:0]             c0_status,
  output logic [31:0]            c0_len,
  output logic                   c1_valid,
  input  wire logic              c1_ready,
  output logic [63:0]            c1_wr_id,
  output logic [3:0]             c1_op,
  output logic [3:0]             c1_status,
  output logic [31:0]            c1_len,
  // ---- queue clear (to the WQE queues) and status -----------------------------------------------------------------------------------------
  output logic                   q_clear,
  output logic [WB+1:0]          win_occ,
  output logic [WB+1:0]          ring_occ,
  // ---- events for the performance block ------------------------------------------------------------------------------------------------
  output logic                   ev_retry_timeout, ev_retry_nak, ev_retry_rnr, ev_tx_retx, ev_rx_ack_stale, ev_rx_nak,
  output logic                   ev_stall_window, ev_stall_rdlim,
  output logic                   lat_valid,
  output logic [1:0]             lat_op,
  output logic [31:0]            lat_cycles,
  output logic                   cqe_valid,
  output logic [3:0]             cqe_op,
  output logic [3:0]             cqe_status,
  output logic [31:0]            cqe_len,
  output logic                   ev_dup, ev_oos, ev_resp_drop, ev_accept, ev_commit, ev_unsupp, ev_dup_rd_fault, ev_nak_badcode,
  output logic                   ev_tx_nak, ev_rnr_sent,
  output logic                   ev_guard_viol
);
  // ---------------------------------------------------------------------------------------------------------------------------------
  // QP state, attributes
  // ---------------------------------------------------------------------------------------------------------------------------------
  logic [2:0]  state;
  logic [3:0]  err_cause_q;
  logic [PD_W-1:0] a_pd;
  logic [15:0] a_rqpn, a_epoch;
  logic [23:0] a_rq_psn, a_sq_psn;
  logic [31:0] a_timeout, a_rnr_delay;
  logic [3:0]  a_retry, a_rnr_retry;
  logic        ld_rx, ld_tx, clr_q, drain_done_q;
  logic        rst_pend;
  assign qp_state     = state;
  assign qp_err_cause = err_cause_q;

  wire st_rts   = (state == `SFR_QP_RTS);
  wire st_rtr   = (state == `SFR_QP_RTR);
  wire st_err   = (state == `SFR_QP_ERR);
  wire st_drain = (state == `SFR_QP_DRAIN);
  wire flush_en = st_err || st_drain;

  // sub-block status
  wire        ag_fatal_pend, ag_resp_err, ag_err_req, ag_tx_valid, ag_idle;
  wire        req_idle, req_quiet, req_err_req, rx_err_req, rx_quiet, rg_idle;
  wire [3:0]  req_err_cause, rx_err_cause;
  assign cfg_req_en   = st_rtr || st_rts || (st_err && ag_resp_err);
  assign cfg_resp_en  = st_rts;
  logic [47:0] qm_lmac_q, qm_pmac_q;
  assign cfg_local_mac = qm_lmac_q;
  assign cfg_peer_mac  = qm_pmac_q;
  assign cfg_epoch     = a_epoch;

  // fatal-error requests
  wire resp_abort_err = ad_abort_ev && ad_abort_err && ad_abort_port;      // a READ response could not be fetched: the responder QP errors (no WQE to fail)
  wire any_err = req_err_req || rx_err_req || ag_err_req || rd_viol || dw_viol || resp_abort_err;
  wire [3:0] any_cause = req_err_req ? req_err_cause : ag_err_req ? `SFR_EC_RESP_FATAL : `SFR_EC_INT;
  assign ev_guard_viol = rd_viol || dw_viol;

  // ---------------------------------------------------------------------------------------------------------------------------------
  // QP command
  // ---------------------------------------------------------------------------------------------------------------------------------
  logic [3:0] cstat;
  logic       c_apply;
  always_comb begin
    cstat = `SFR_CS_OK; c_apply = 1'b0;
    if (qm_valid) begin
      case (qm_state)
        `SFR_QP_INIT:  if (state == `SFR_QP_RESET) c_apply = 1'b1; else cstat = `SFR_CS_STATE;
        `SFR_QP_RTR:   if (state == `SFR_QP_INIT)  c_apply = 1'b1; else cstat = `SFR_CS_STATE;
        `SFR_QP_RTS:   if (state != `SFR_QP_RTR)   cstat = `SFR_CS_STATE;
                       else if (qm_timeout == 32'd0 || qm_rnr_delay == 32'd0) cstat = `SFR_CS_FIELDS;
                       else c_apply = 1'b1;
        `SFR_QP_ERR:   if (state == `SFR_QP_RESET || state == `SFR_QP_DRAIN) cstat = `SFR_CS_STATE; else c_apply = 1'b1;
        `SFR_QP_RESET: c_apply = 1'b1;
        default:       cstat = `SFR_CS_STATE;
      endcase
    end
  end

  assign tx_hold  = st_drain;
  assign tx_drop_req = flush_en;                       // ERR: queued REQUEST frames are discarded when they would start (spec 11.1)
  wire   drain_ok = st_drain && req_quiet && !sq_valid && !rq_valid && rx_quiet && rd_idle && dw_idle && tx_quiet;
  assign q_clear  = clr_q;
  assign dma_clear = clr_q;
  assign tx_flush  = clr_q;
  assign rx_flush  = clr_q;
  assign reg_ref_clear = clr_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= `SFR_QP_RESET; err_cause_q <= `SFR_EC_NONE; a_pd <= '0; local_qpn <= '0; a_rqpn <= '0; a_epoch <= '0; a_rq_psn <= '0;
      a_sq_psn <= '0; a_timeout <= 32'd1; a_rnr_delay <= 32'd1; a_retry <= '0; a_rnr_retry <= '0; qm_lmac_q <= '0; qm_pmac_q <= '0;
      ld_rx <= 1'b0; ld_tx <= 1'b0; clr_q <= 1'b0; qm_rsp_valid <= 1'b0; qm_rsp_status <= '0; rst_pend <= 1'b0; drain_done_q <= 1'b0;
    end else begin
      ld_rx <= 1'b0; ld_tx <= 1'b0; qm_rsp_valid <= 1'b0; clr_q <= 1'b0;
      // ---- fatal error transitions
      if (any_err && (state == `SFR_QP_INIT || state == `SFR_QP_RTR || state == `SFR_QP_RTS)) begin
        state <= `SFR_QP_ERR; err_cause_q <= any_cause;
      end
      // ---- trusted command: a refused command answers immediately with its status; an accepted one answers when applied
      if (qm_valid) begin
        qm_rsp_status <= cstat;
        if (!c_apply) qm_rsp_valid <= 1'b1;
        else case (qm_state)
          `SFR_QP_INIT: begin state <= `SFR_QP_INIT; a_pd <= qm_pd; local_qpn <= qm_qpn; err_cause_q <= `SFR_EC_NONE; qm_rsp_valid <= 1'b1; end
          `SFR_QP_RTR:  begin state <= `SFR_QP_RTR; a_rqpn <= qm_rqpn; a_epoch <= qm_epoch; a_rq_psn <= qm_rq_psn;
                              qm_lmac_q <= qm_lmac; qm_pmac_q <= qm_pmac; ld_rx <= 1'b1; qm_rsp_valid <= 1'b1; end
          `SFR_QP_RTS:  begin state <= `SFR_QP_RTS; a_sq_psn <= qm_sq_psn; a_timeout <= qm_timeout; a_retry <= qm_retry;
                              a_rnr_retry <= qm_rnr_retry; a_rnr_delay <= qm_rnr_delay; ld_tx <= 1'b1; qm_rsp_valid <= 1'b1; end
          `SFR_QP_ERR:  begin state <= `SFR_QP_ERR; err_cause_q <= `SFR_EC_CFG; qm_rsp_valid <= 1'b1; end
          default: begin                                   // RESET
            if (state == `SFR_QP_RESET) qm_rsp_valid <= 1'b1;
            else begin state <= `SFR_QP_DRAIN; rst_pend <= 1'b1; end   // the answer comes when the drain has finished
          end
        endcase
      end
      // ---- drain -> clear -> RESET
      if (drain_ok && !clr_q && !drain_done_q) begin clr_q <= 1'b1; drain_done_q <= 1'b1; end
      if (st_drain && drain_done_q && !clr_q) begin
        state <= `SFR_QP_RESET; drain_done_q <= 1'b0; err_cause_q <= `SFR_EC_NONE;
        if (rst_pend) begin qm_rsp_valid <= 1'b1; qm_rsp_status <= `SFR_CS_OK; rst_pend <= 1'b0; end
      end
    end
  end

  // ---------------------------------------------------------------------------------------------------------------------------------
  // requester
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire        ack_valid; wire [23:0] ack_cn, ack_an; wire [3:0] ack_code;
  wire [23:0] rr_psn; wire rr_found; wire [31:0] rr_exp_off, rr_mlen; wire [PA_W-1:0] rr_lpa; wire [RID_W-1:0] rr_rid; wire [CTX_W-1:0] rr_ctx;
  wire        rr_accept; wire [15:0] rr_accept_len; wire place_done_valid; wire [23:0] place_done_psn;
  wire        rq_tx_valid, rq_tx_has_pl; wire [271:0] rq_tx_sh; wire [PA_W-1:0] rq_tx_pa; wire [15:0] rq_tx_len; wire [RID_W-1:0] rq_tx_rid; wire [CTX_W-1:0] rq_tx_ctx;
  wire        rq_rel_valid; wire [RID_W-1:0] rq_rel_rid;
  wire        rq_tx_ready;
  wire        rq_rel_chk_valid; wire [RID_W-1:0] rq_rel_chk_rid;
  wire        rx_place_idle, rx_place_err_valid; wire [WB-1:0] rx_place_err_idx;
  // source reads of THIS requester that are in flight in the read engine (port 0): the WQE's grant must not be released before they end
  logic [7:0] rd0_out;
  wire        rd0_inc = rdc_valid && rdc_ready && !rdc_port;
  wire        rd0_dec = rd_done_valid && !rd_done_port;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rd0_out <= '0;
    else if (clr_q) rd0_out <= '0;
    else rd0_out <= rd0_out + (rd0_inc ? 8'd1 : 8'd0) - (rd0_dec ? 8'd1 : 8'd0);
  end
  wire        req_dma_quiet = (rd0_out == 8'd0) && rx_place_idle;

  sf_rdma_requester #(.WINDOW(WINDOW), .MAX_RD(MAX_RD), .MTU(MTU), .PA_W(PA_W), .PD_W(PD_W), .RID_W(RID_W), .CTX_W(CTX_W)) u_req (
    .clk(clk), .rst_n(rst_n), .clear(clr_q), .en(st_rts), .flush_en(flush_en), .ld_valid(ld_tx), .ld_psn(a_sq_psn),
    .qp_pd(a_pd), .remote_qpn(a_rqpn), .epoch(a_epoch), .cfg_timeout(a_timeout), .cfg_retry_max(a_retry), .cfg_rnr_max(a_rnr_retry),
    .cfg_rnr_delay(a_rnr_delay), .now(now),
    .sq_valid(sq_valid), .sq_pop(sq_pop), .sq_op(sq_op), .sq_wr_id(sq_wr_id), .sq_laddr(sq_laddr), .sq_lkey(sq_lkey), .sq_len(sq_len),
    .sq_raddr(sq_raddr), .sq_rkey(sq_rkey),
    .chk_valid(reg_chk_valid[0]), .chk_op(reg_chk_op[1:0]), .chk_key(reg_chk_key[31:0]), .chk_pd(reg_chk_pd[PD_W-1:0]),
    .chk_va(reg_chk_va[63:0]), .chk_len(reg_chk_len[31:0]),
    .rsp_valid(reg_rsp_valid[0]), .rsp_ok(reg_rsp_ok[0]), .rsp_rid(reg_rsp_rid[RID_W-1:0]), .rsp_pa(reg_rsp_pa[PA_W-1:0]), .rsp_ctx(reg_rsp_ctx[CTX_W-1:0]),
    .rel_valid(rq_rel_valid), .rel_rid(rq_rel_rid), .rel_chk_valid(rq_rel_chk_valid), .rel_chk_rid(rq_rel_chk_rid),
    .lerr_tx_valid(ad_abort_ev && ad_abort_err && !ad_abort_port), .lerr_tx_psn(ad_abort_psn),
    .lerr_pl_valid(rx_place_err_valid), .lerr_pl_idx(rx_place_err_idx), .dma_quiet(req_dma_quiet),
    .tx_valid(rq_tx_valid), .tx_ready(rq_tx_ready), .tx_sh(rq_tx_sh), .tx_has_pl(rq_tx_has_pl), .tx_pa(rq_tx_pa), .tx_len(rq_tx_len),
    .tx_rid(rq_tx_rid), .tx_ctx(rq_tx_ctx),
    .ack_valid(ack_valid), .ack_cn(ack_cn), .ack_an(ack_an), .ack_code(ack_code),
    .rr_psn(rr_psn), .rr_found(rr_found), .rr_exp_off(rr_exp_off), .rr_mlen(rr_mlen), .rr_lpa(rr_lpa), .rr_rid(rr_rid), .rr_ctx(rr_ctx),
    .rr_accept(rr_accept), .rr_accept_len(rr_accept_len), .place_done_valid(place_done_valid), .place_done_psn(place_done_psn),
    .cmp_valid(c0_valid), .cmp_ready(c0_ready), .cmp_wr_id(c0_wr_id), .cmp_op(c0_op), .cmp_status(c0_status), .cmp_len(c0_len),
    .err_req(req_err_req), .err_cause(req_err_cause), .idle(req_idle), .quiet(req_quiet), .win_occ(win_occ),
    .ev_retry_timeout(ev_retry_timeout), .ev_retry_nak(ev_retry_nak), .ev_retry_rnr(ev_retry_rnr), .ev_tx_retx(ev_tx_retx),
    .ev_rx_ack_stale(ev_rx_ack_stale), .ev_rx_nak(ev_rx_nak), .ev_stall_window(ev_stall_window), .ev_stall_rdlim(ev_stall_rdlim),
    .lat_valid(lat_valid), .lat_op(lat_op), .lat_cycles(lat_cycles),
    .cqe_valid(cqe_valid), .cqe_op(cqe_op), .cqe_status(cqe_status), .cqe_len(cqe_len));

  // ---------------------------------------------------------------------------------------------------------------------------------
  // responder: receive processor, read executor, ACK generator
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire [23:0] cpsn, epsn;
  wire        rdq_valid, rdq_ready, rdq_replay; wire [23:0] rdq_psn; wire [PA_W-1:0] rdq_pa; wire [31:0] rdq_len, rdq_moff, rdq_mlen;
  wire [RID_W-1:0] rdq_rid; wire [CTX_W-1:0] rdq_ctx;
  wire        rg_done_valid; wire [23:0] rg_done_psn;
  wire        ag_ack_set, ag_nak_set, ag_fatal_set, ag_replay_set; wire [3:0] ag_nak_code, ag_fatal_code;
  wire        rx_rel_c_valid, rx_rel_a_valid, rx_rel_f_valid; wire [RID_W-1:0] rx_rel_c_rid, rx_rel_a_rid, rx_rel_f_rid;
  wire        fatal_mode = ag_fatal_pend || ag_resp_err;

  sf_rdma_rx #(.WINDOW(WINDOW), .MTU(MTU), .PA_W(PA_W), .PD_W(PD_W), .RID_W(RID_W), .CTX_W(CTX_W), .TAGQ(TAGQ), .MAX_MSG_BYTES(MAX_MSG_BYTES)) u_rx (
    .clk(clk), .rst_n(rst_n), .clear(clr_q), .en_req(st_rtr || st_rts), .en_resp(st_rts), .flush_en(flush_en),
    .ld_valid(ld_rx), .ld_psn(a_rq_psn), .qp_pd(a_pd),
    .rxh_valid(rxh_valid), .rxh_sh(rxh_sh), .rxh_pop(rxh_pop),
    .dw_cmd_valid(dw_cmd_valid), .dw_cmd_ready(dw_cmd_ready), .dw_cmd_discard(dw_cmd_discard), .dw_cmd_pa(dw_cmd_pa), .dw_cmd_len(dw_cmd_len),
    .dw_cmd_rid(dw_cmd_rid), .dw_cmd_ctx(dw_cmd_ctx), .dw_done_valid(dw_done_valid), .dw_done_err(dw_done_err), .dw_viol(dw_viol),
    .chk_valid(reg_chk_valid[1]), .chk_op(reg_chk_op[3:2]), .chk_key(reg_chk_key[63:32]), .chk_pd(reg_chk_pd[2*PD_W-1:PD_W]),
    .chk_va(reg_chk_va[127:64]), .chk_len(reg_chk_len[63:32]),
    .rsp_valid(reg_rsp_valid[1]), .rsp_ok(reg_rsp_ok[1]), .rsp_rid(reg_rsp_rid[2*RID_W-1:RID_W]), .rsp_pa(reg_rsp_pa[2*PA_W-1:PA_W]),
    .rsp_ctx(reg_rsp_ctx[2*CTX_W-1:CTX_W]),
    .rel_c_valid(rx_rel_c_valid), .rel_c_rid(rx_rel_c_rid), .rel_a_valid(rx_rel_a_valid), .rel_a_rid(rx_rel_a_rid), .rel_f_valid(rx_rel_f_valid), .rel_f_rid(rx_rel_f_rid),
    .rq_valid(rq_valid), .rq_pop(rq_pop), .rq_wr_id(rq_wr_id), .rq_addr(rq_addr), .rq_lkey(rq_lkey), .rq_len(rq_len),
    .cmp_valid(c1_valid), .cmp_ready(c1_ready), .cmp_wr_id(c1_wr_id), .cmp_op(c1_op), .cmp_status(c1_status), .cmp_len(c1_len),
    .ack_valid(ack_valid), .ack_cn(ack_cn), .ack_an(ack_an), .ack_code(ack_code),
    .rr_psn(rr_psn), .rr_found(rr_found), .rr_exp_off(rr_exp_off), .rr_mlen(rr_mlen), .rr_lpa(rr_lpa), .rr_rid(rr_rid), .rr_ctx(rr_ctx),
    .rr_accept(rr_accept), .rr_accept_len(rr_accept_len), .place_done_valid(place_done_valid), .place_done_psn(place_done_psn),
    .place_err_valid(rx_place_err_valid), .place_err_idx(rx_place_err_idx), .place_idle(rx_place_idle),
    .rdq_valid(rdq_valid), .rdq_ready(rdq_ready), .rdq_psn(rdq_psn), .rdq_pa(rdq_pa), .rdq_len(rdq_len), .rdq_moff(rdq_moff),
    .rdq_mlen(rdq_mlen), .rdq_rid(rdq_rid), .rdq_ctx(rdq_ctx), .rdq_replay(rdq_replay),
    .rg_done_valid(rg_done_valid), .rg_done_psn(rg_done_psn),
    .ag_ack_set(ag_ack_set), .ag_nak_set(ag_nak_set), .ag_nak_code(ag_nak_code), .ag_fatal_set(ag_fatal_set), .ag_fatal_code(ag_fatal_code),
    .ag_replay_set(ag_replay_set), .fatal_mode(fatal_mode),
    .cpsn(cpsn), .epsn(epsn), .quiet(rx_quiet), .err_req(rx_err_req), .err_cause(rx_err_cause), .ring_occ(ring_occ),
    .ev_dup(ev_dup), .ev_oos(ev_oos), .ev_resp_drop(ev_resp_drop), .ev_accept(ev_accept), .ev_commit(ev_commit), .ev_unsupp(ev_unsupp),
    .ev_dup_rd_fault(ev_dup_rd_fault), .ev_nak_badcode(ev_nak_badcode));

  // an ACK is also due whenever the commit frontier moves
  wire ag_ack_trig = ag_ack_set || ev_commit;
  wire [271:0] ag_tx_sh; wire ag_tx_ready;
  sf_rdma_ackgen #(.ACCEPT_ACK_DELAY(ACCEPT_ACK_DELAY)) u_ag (
    .clk(clk), .rst_n(rst_n), .clear(clr_q), .en(cfg_req_en), .remote_qpn(a_rqpn), .epoch(a_epoch), .cpsn(cpsn), .epsn(epsn),
    .acc_ev(ev_accept), .ack_set(ag_ack_trig), .nak_set(ag_nak_set), .nak_code(ag_nak_code), .fatal_set(ag_fatal_set), .fatal_code(ag_fatal_code),
    .replay_set(ag_replay_set), .tx_valid(ag_tx_valid), .tx_ready(ag_tx_ready), .tx_sh(ag_tx_sh),
    .fatal_pend(ag_fatal_pend), .resp_err(ag_resp_err), .err_req(ag_err_req), .ev_tx_nak(ev_tx_nak), .ev_rnr_sent(ev_rnr_sent), .idle(ag_idle));

  wire        rg_tx_valid; wire [271:0] rg_tx_sh; wire [PA_W-1:0] rg_tx_pa; wire [15:0] rg_tx_len; wire [RID_W-1:0] rg_tx_rid; wire [CTX_W-1:0] rg_tx_ctx;
  wire        rg_tx_ready;
  wire        rg_rel_valid; wire [RID_W-1:0] rg_rel_rid; wire rg_resp_frame;
  sf_rdma_rdgen #(.MTU(MTU), .PA_W(PA_W), .RID_W(RID_W), .CTX_W(CTX_W), .RDQ(RDQ)) u_rg (
    .clk(clk), .rst_n(rst_n), .clear(clr_q), .halt(flush_en), .remote_qpn(a_rqpn), .epoch(a_epoch), .cpsn(cpsn),
    .q_valid(rdq_valid), .q_ready(rdq_ready), .q_psn(rdq_psn), .q_pa(rdq_pa), .q_len(rdq_len), .q_moff(rdq_moff), .q_mlen(rdq_mlen),
    .q_rid(rdq_rid), .q_ctx(rdq_ctx), .q_replay(rdq_replay),
    .tx_valid(rg_tx_valid), .tx_ready(rg_tx_ready), .tx_sh(rg_tx_sh), .tx_pa(rg_tx_pa), .tx_len(rg_tx_len), .tx_rid(rg_tx_rid), .tx_ctx(rg_tx_ctx),
    .rd_done_valid(rd_done_valid && rd_done_port), .done_valid(rg_done_valid), .done_psn(rg_done_psn),
    .rel_valid(rg_rel_valid), .rel_rid(rg_rel_rid), .idle(rg_idle), .ev_resp_frame(rg_resp_frame));

  // ---------------------------------------------------------------------------------------------------------------------------------
  // transmit glue: a payload frame reserves its header slot AND its read command in one atomic push
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire req0 = rq_tx_valid && rq_tx_has_pl && txh_ready[0];
  wire req1 = rg_tx_valid && txh_ready[1];
  wire [1:0] arb_gnt; wire [0:0] arb_idx; wire arb_any;
  wire push0 = arb_gnt[0] && rdc_ready;
  wire push1 = arb_gnt[1] && rdc_ready;
  sf_rr_arb #(.N(2)) u_arb (.clk(clk), .rst_n(rst_n), .req({req1, req0}), .advance(push0 || push1), .gnt(arb_gnt), .gnt_idx(arb_idx), .any(arb_any));

  assign txh_valid[0] = push0 || (rq_tx_valid && !rq_tx_has_pl);
  assign txh_valid[1] = push1;
  assign txh_valid[2] = ag_tx_valid;
  assign txh_sh       = {ag_tx_sh, rg_tx_sh, rq_tx_sh};
  assign rq_tx_ready  = txh_valid[0] && txh_ready[0];
  assign rg_tx_ready  = txh_valid[1] && txh_ready[1];
  assign ag_tx_ready  = txh_valid[2] && txh_ready[2];

  assign rdc_valid = arb_gnt[0] || arb_gnt[1];
  assign rdc_port  = arb_gnt[1];
  assign rdc_pa    = arb_gnt[1] ? rg_tx_pa  : rq_tx_pa;
  assign rdc_len   = arb_gnt[1] ? rg_tx_len : rq_tx_len;
  assign rdc_rid   = arb_gnt[1] ? rg_tx_rid : rq_tx_rid;
  assign rdc_ctx   = arb_gnt[1] ? rg_tx_ctx : rq_tx_ctx;

  // reference releases (requester, receive processor, read executor)
  assign reg_rel_valid = {rg_rel_valid, rx_rel_f_valid, rx_rel_a_valid, rx_rel_c_valid, rq_rel_chk_valid, rq_rel_valid};
  assign reg_rel_rid   = {rg_rel_rid, rx_rel_f_rid, rx_rel_a_rid, rx_rel_c_rid, rq_rel_chk_rid, rq_rel_rid};
endmodule
`default_nettype wire
