// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: sf_rdma_rx   (receive processor + responder)
//
// Consumes committed frames from the transport adapter, ONE AT A TIME, and never waits for the transmit side:
//   ACK/NAK        -> requester (frontier update)
//   READ_RESP      -> requester lookup; accepted data is placed by the write DMA at (grant PA + moff); else discarded
//   SEND/WRITE/READ_REQ (requests) -> classify by PSN against `epsn` (spec 9.3):
//        duplicate        no effect on memory/RQ/CQ; ACK scheduled (a duplicate READ is re-executed)
//        out of sequence  discarded; SEQ_ERR NAK (once per gap)
//        in order         validate (7.4) -> registry check -> DMA command -> accept (epsn++)
// Every frame with a payload gets exactly one DMA command (WRITE or DISCARD) BEFORE its header is popped, so the payload ring and the
// header FIFO stay in lock step.  Memory is touched only through DMA commands built from a registry GRANT.
// COMMIT RING: one entry per accepted request (indexed by PSN).  cpsn (commit_next) advances over consecutive DONE entries; a SEND's
// RECV CQE is produced when its last segment commits, BEFORE the ACK covering it is built (spec 7.1).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none

module sf_rdma_rx #(
  parameter int WINDOW        = 8,
  parameter int MTU           = 256,
  parameter int PA_W          = 32,
  parameter int PD_W          = 4,
  parameter int RID_W         = 3,
  parameter int CTX_W         = 2,
  parameter int TAGQ          = 16,                 // power of two: pending write completions
  parameter int MAX_MSG_BYTES = 1048576,
  localparam int WB           = $clog2(WINDOW)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clear,
  // ---- QP context -----------------------------------------------------------------------------------------------------------------
  input  wire logic              en_req,
  input  wire logic              en_resp,
  input  wire logic              flush_en,
  input  wire logic              ld_valid,
  input  wire logic [23:0]       ld_psn,
  input  wire logic [PD_W-1:0]   qp_pd,
  // ---- adapter ----------------------------------------------------------------------------------------------------------------------
  input  wire logic              rxh_valid,
  input  wire logic [271:0]      rxh_sh,
  output logic                   rxh_pop,
  // ---- write DMA --------------------------------------------------------------------------------------------------------------------
  output logic                   dw_cmd_valid,
  input  wire logic              dw_cmd_ready,
  output logic                   dw_cmd_discard,
  output logic [PA_W-1:0]        dw_cmd_pa,
  output logic [15:0]            dw_cmd_len,
  output logic [RID_W-1:0]       dw_cmd_rid,
  output logic [CTX_W-1:0]       dw_cmd_ctx,
  input  wire logic              dw_done_valid,
  input  wire logic              dw_done_err,
  input  wire logic              dw_viol,
  // ---- registry (port 1) ---------------------------------------------------------------------------------------------------------------
  output logic                   chk_valid,
  output logic [1:0]             chk_op,
  output logic [31:0]            chk_key,
  output logic [PD_W-1:0]        chk_pd,
  output logic [63:0]            chk_va,
  output logic [31:0]            chk_len,
  input  wire logic              rsp_valid,
  input  wire logic              rsp_ok,
  input  wire logic [RID_W-1:0]  rsp_rid,
  input  wire logic [PA_W-1:0]   rsp_pa,
  input  wire logic [CTX_W-1:0]  rsp_ctx,
  output logic                   rel_c_valid,           // release: commit of a ring entry
  output logic [RID_W-1:0]       rel_c_rid,
  output logic                   rel_a_valid,           // release: a check answered after the QP went to ERR / a fatal decision (frame discarded)
  output logic [RID_W-1:0]       rel_a_rid,
  output logic                   rel_f_valid,           // release: flush of a partially received SEND
  output logic [RID_W-1:0]       rel_f_rid,
  // ---- receive queue head ----------------------------------------------------------------------------------------------------------------
  input  wire logic              rq_valid,
  output logic                   rq_pop,
  input  wire logic [63:0]       rq_wr_id,
  input  wire logic [63:0]       rq_addr,
  input  wire logic [31:0]       rq_lkey,
  input  wire logic [31:0]       rq_len,
  // ---- completion producer P1 --------------------------------------------------------------------------------------------------------------
  output logic                   cmp_valid,
  input  wire logic              cmp_ready,
  output logic [63:0]            cmp_wr_id,
  output logic [3:0]             cmp_op,
  output logic [3:0]             cmp_status,
  output logic [31:0]            cmp_len,
  // ---- requester interface -------------------------------------------------------------------------------------------------------------
  output logic                   ack_valid,
  output logic [23:0]            ack_cn,
  output logic [23:0]            ack_an,
  output logic [3:0]             ack_code,
  output logic [23:0]            rr_psn,
  input  wire logic              rr_found,
  input  wire logic [31:0]       rr_exp_off,
  input  wire logic [31:0]       rr_mlen,
  input  wire logic [PA_W-1:0]   rr_lpa,
  input  wire logic [RID_W-1:0]  rr_rid,
  input  wire logic [CTX_W-1:0]  rr_ctx,
  output logic                   rr_accept,
  output logic [15:0]            rr_accept_len,
  output logic                   place_done_valid,
  output logic [23:0]            place_done_psn,
  output logic                   place_err_valid,       // the placement write of a READ response failed (memory error)
  output logic [WB-1:0]          place_err_idx,
  output logic                   place_idle,            // no READ-response placement is in flight
  // ---- read executor -----------------------------------------------------------------------------------------------------------------------
  output logic                   rdq_valid,
  input  wire logic              rdq_ready,
  output logic [23:0]            rdq_psn,
  output logic [PA_W-1:0]        rdq_pa,
  output logic [31:0]            rdq_len,
  output logic [31:0]            rdq_moff,
  output logic [31:0]            rdq_mlen,
  output logic [RID_W-1:0]       rdq_rid,
  output logic [CTX_W-1:0]       rdq_ctx,
  output logic                   rdq_replay,
  input  wire logic              rg_done_valid,
  input  wire logic [23:0]       rg_done_psn,
  // ---- ACK generator ------------------------------------------------------------------------------------------------------------------------
  output logic                   ag_ack_set,
  output logic                   ag_nak_set,
  output logic [3:0]             ag_nak_code,
  output logic                   ag_fatal_set,
  output logic [3:0]             ag_fatal_code,
  output logic                   ag_replay_set,
  input  wire logic              fatal_mode,
  // ---- frontiers / status -------------------------------------------------------------------------------------------------------------------
  output logic [23:0]            cpsn,
  output logic [23:0]            epsn,
  output logic                   quiet,
  output logic                   err_req,
  output logic [3:0]             err_cause,
  output logic [WB+1:0]          ring_occ,
  // ---- events ------------------------------------------------------------------------------------------------------------------------------------
  output logic                   ev_dup,
  output logic                   ev_oos,
  output logic                   ev_resp_drop,
  output logic                   ev_accept,
  output logic                   ev_commit,
  output logic                   ev_unsupp,
  output logic                   ev_dup_rd_fault,
  output logic                   ev_nak_badcode
);
  // ---------------------------------------------------------------------------------------------------------------------------------
  // header decode
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire [271:0] sh = rxh_sh;
  wire [7:0]   opc    = `SFR_H_OPC(sh);
  wire [7:0]   vf     = `SFR_H_VF(sh);
  wire [23:0]  psn    = `SFR_H_PSN(sh);
  wire [15:0]  paylen = `SFR_H_PAYLEN(sh);
  wire [31:0]  mlen   = `SFR_H_MLEN(sh);
  wire [31:0]  moff   = `SFR_H_MOFF(sh);
  wire [63:0]  hva    = `SFR_H_VA(sh);
  wire [31:0]  hrkey  = `SFR_H_RKEY(sh);
  wire [7:0]   hcode  = `SFR_H_CODE(sh);
  wire [23:0]  hacc   = `SFR_H_ACCEPT(sh);
  wire         f_first = vf[0];
  wire         f_last  = vf[1];
  wire         is_send  = (opc == `SFR_OP_SEND);
  wire         is_write = (opc == `SFR_OP_WRITE);
  wire         is_rreq  = (opc == `SFR_OP_READ_REQ);
  wire         is_resv  = (opc >= 8'h04) && (opc <= 8'h0F);
  wire         is_rresp = (opc == `SFR_OP_READ_RESP);
  wire         is_ack   = (opc == `SFR_OP_ACK);
  wire         is_nak   = (opc == `SFR_OP_NAK);
  wire         is_req   = is_send || is_write || is_rreq || is_resv;
  wire         has_pl   = (paylen != 16'd0);
  wire [32:0]  mo_pl    = {1'b0, moff} + {17'd0, paylen};
  wire [23:0]  dpsn     = psn - epsn;
  wire         dup      = dpsn[23];
  wire         future   = !dpsn[23] && (dpsn != 24'd0);

  // ---------------------------------------------------------------------------------------------------------------------------------
  // state
  // ---------------------------------------------------------------------------------------------------------------------------------
  typedef enum logic [1:0] {S_DISP, S_CHK, S_CQE} st_t;
  st_t         st;
  logic [1:0]  a_kind;                              // 0 WRITE, 1 SEND first, 2 READ (fresh), 3 READ (duplicate)
  logic        nak_sent;
  logic [3:0]  cqe_st_q;                            // status for the S_CQE completion

  // SEND message in progress
  logic        cur_valid, cur_has;
  logic [63:0] cur_wr;
  logic [RID_W-1:0] cur_rid;
  logic [PA_W-1:0]  cur_pa;
  logic [CTX_W-1:0] cur_ctx;
  logic [31:0] cur_mlen, cur_off;

  // commit ring
  logic        c_vld   [0:WINDOW-1];                // (kept for formal observability)
  logic        c_done  [0:WINDOW-1];
  logic        c_ref   [0:WINDOW-1];
  logic [RID_W-1:0] c_rid [0:WINDOW-1];
  logic        c_slast [0:WINDOW-1];
  logic [63:0] c_wr    [0:WINDOW-1];
  logic [31:0] c_mlen  [0:WINDOW-1];
  logic        c_isrd  [0:WINDOW-1];                // READ request: executed by the read executor, no memory write here
  logic        c_issend[0:WINDOW-1];                // SEND segment
  logic        c_err   [0:WINDOW-1];                // its memory write was acknowledged with an error (the data is NOT there)
  logic        msg_err;                             // a committed segment of the SEND at the head of the ring had a memory error

  wire [23:0]  occ24    = epsn - cpsn;
  wire         ring_free = (occ24 < 24'(WINDOW));
  assign ring_occ = (WB+2)'(occ24);
  wire [WB-1:0] ep_i = epsn[WB-1:0];
  wire [WB-1:0] cp_i = cpsn[WB-1:0];
  wire         ring_empty = (cpsn == epsn);

  // pending write-completion tags: {kind (0 RSP / 1 PLACE), last, idx}
  wire tg_full, tg_empty, tg_ovf, tg_unf;
  wire [$clog2(TAGQ):0] tg_cnt;
  wire [WB+1:0] tg_rd;
  logic tg_push;
  logic [$clog2(TAGQ):0] place_pend;                // READ-response placements in flight
  logic [WB+1:0] tg_wd;
  sf_rdma_fifo #(.WIDTH(WB+2), .DEPTH(TAGQ)) u_tg (
    .clk(clk), .rst_n(rst_n), .clear(clear), .push(tg_push), .wdata(tg_wd),
    .pop(dw_done_valid), .rdata(tg_rd), .full(tg_full), .empty(tg_empty), .count(tg_cnt), .ovf(tg_ovf), .unf(tg_unf));
  wire         tg_kind = tg_rd[WB+1];
  wire         tg_last = tg_rd[WB];
  wire [WB-1:0] tg_idx = tg_rd[WB-1:0];

  // ---------------------------------------------------------------------------------------------------------------------------------
  // validity of an in-order request (spec 7.4)
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire         len_ok   = (mo_pl <= {1'b0, mlen});
  wire         first_ok = (f_first == (moff == 32'd0));
  wire         last_ok  = (f_last == (mo_pl == {1'b0, mlen}));
  wire         mlen_ok  = (mlen <= 32'(MAX_MSG_BYTES));
  wire         send_cont_ok = cur_valid && (moff == cur_off) && (mlen == cur_mlen);
  wire         v_send  = len_ok && first_ok && last_ok && mlen_ok && (f_first ? !cur_valid : send_cont_ok);
  wire         v_write = has_pl && len_ok && first_ok && last_ok && mlen_ok && !cur_valid;
  wire         v_rreq_s = !has_pl && (moff < mlen) && f_last && first_ok && mlen_ok;     // structure only (also used for duplicates)
  wire         v_rreq  = v_rreq_s && !cur_valid;
  wire         v_ok    = is_send ? v_send : is_write ? v_write : is_rreq ? v_rreq : 1'b0;

  // resources
  wire         tag_free = !tg_full;
  wire         pl_stall = has_pl && !dw_cmd_ready;
  wire [31:0]  rd_len   = mlen - moff;

  // READ_RESP acceptance
  wire         rr_ok = en_resp && rr_found && has_pl && (moff == rr_exp_off) && (mlen == rr_mlen) && (mo_pl <= {1'b0, mlen}) &&
                       (f_last == (mo_pl == {1'b0, mlen}));

  // ---------------------------------------------------------------------------------------------------------------------------------
  // the frame FSM (combinational actions)
  // ---------------------------------------------------------------------------------------------------------------------------------
  logic        do_accept;                           // epsn++ and ring entry push
  logic        ring_done_in, ring_ref_in, ring_slast_in, ring_isrd_in, ring_issend_in;
  logic [RID_W-1:0] ring_rid_in;
  logic [63:0] ring_wr_in;
  logic [31:0] ring_mlen_in;
  logic        cur_set, cur_clr;                    // update SEND-message state
  logic [63:0] cur_wr_n; logic [RID_W-1:0] cur_rid_n; logic [PA_W-1:0] cur_pa_n; logic [CTX_W-1:0] cur_ctx_n; logic cur_has_n;
  logic [31:0] cur_off_n;
  logic        st_chk_go, st_cqe_go, st_disp_go;
  logic [1:0]  a_kind_n;
  logic [3:0]  cqe_st_n;
  logic        fsm_cqe;                             // the FSM wants a RECV CQE (S_CQE)
  logic        set_nak_sent;
  logic        chk_abort_rel;

  logic [1:0]  cmd_kind;                           // 0 none, 1 WRITE, 2 DISCARD
  logic [PA_W-1:0] w_pa; logic [RID_W-1:0] w_rid; logic [CTX_W-1:0] w_ctx;
  logic        rq_pop_f;

  always_comb begin
    // defaults
    rxh_pop = 1'b0; cmd_kind = 2'd0; w_pa = '0; w_rid = '0; w_ctx = '0;
    chk_valid = 1'b0; chk_op = '0; chk_key = '0; chk_pd = qp_pd; chk_va = '0; chk_len = '0;
    rq_pop_f = 1'b0;
    ack_valid = 1'b0; ack_cn = psn; ack_an = hacc; ack_code = 4'd0; rr_psn = psn; rr_accept = 1'b0; rr_accept_len = paylen;
    rdq_valid = 1'b0; rdq_psn = psn; rdq_pa = '0; rdq_len = rd_len; rdq_moff = moff; rdq_mlen = mlen; rdq_rid = '0; rdq_ctx = '0; rdq_replay = 1'b0;
    ag_ack_set = 1'b0; ag_nak_set = 1'b0; ag_nak_code = '0; ag_fatal_set = 1'b0; ag_fatal_code = '0; ag_replay_set = 1'b0;
    do_accept = 1'b0; ring_done_in = 1'b0; ring_ref_in = 1'b0; ring_slast_in = 1'b0; ring_isrd_in = 1'b0; ring_issend_in = 1'b0; ring_rid_in = '0; ring_wr_in = '0; ring_mlen_in = '0;
    cur_set = 1'b0; cur_clr = 1'b0; cur_wr_n = '0; cur_rid_n = '0; cur_pa_n = '0; cur_ctx_n = '0; cur_has_n = 1'b0; cur_off_n = '0;
    tg_push = 1'b0; tg_wd = '0; st_chk_go = 1'b0; st_cqe_go = 1'b0; st_disp_go = 1'b0; a_kind_n = a_kind; cqe_st_n = cqe_st_q;
    fsm_cqe = 1'b0; set_nak_sent = 1'b0; chk_abort_rel = 1'b0;
    ev_dup = 1'b0; ev_oos = 1'b0; ev_resp_drop = 1'b0; ev_unsupp = 1'b0; ev_dup_rd_fault = 1'b0; ev_nak_badcode = 1'b0;

    case (st)
      // =====================================================================================================================
      S_DISP: begin
        if (rxh_valid) begin
          if (is_ack || is_nak) begin
            // ---- control frame -> requester
            if (is_nak && !(hcode >= 8'd1 && hcode <= 8'd5)) ev_nak_badcode = 1'b1;
            else if (en_resp) begin ack_valid = 1'b1; ack_code = is_nak ? hcode[3:0] : 4'd0; end
            rxh_pop = 1'b1;
          end else if (is_rresp) begin
            // ---- READ response data -> requester
            if (has_pl && !(dw_cmd_ready && tag_free)) begin
              // wait for command / tag space
            end else begin
              if (rr_ok) begin
                cmd_kind = 2'd1; w_pa = rr_lpa + PA_W'(moff); w_rid = rr_rid; w_ctx = rr_ctx;
                tg_push = 1'b1; tg_wd = {1'b1, (mo_pl == {1'b0, mlen}), psn[WB-1:0]};
                rr_accept = 1'b1;
              end else begin
                cmd_kind = 2'd2; ev_resp_drop = 1'b1;
              end
              rxh_pop = 1'b1;
            end
          end else if (is_req) begin
            // ---- request
            if (pl_stall) begin
              // wait for a DMA command slot
            end else if (fatal_mode) begin
              cmd_kind = 2'd2; ag_replay_set = 1'b1; rxh_pop = 1'b1;
            end else if (!en_req) begin
              cmd_kind = 2'd2; rxh_pop = 1'b1;
            end else if (future) begin
              cmd_kind = 2'd2; ev_oos = 1'b1;
              if (!nak_sent) begin ag_nak_set = 1'b1; ag_nak_code = `SFR_NAK_SEQ; set_nak_sent = 1'b1; end
              rxh_pop = 1'b1;
            end else if (dup) begin
              cmd_kind = 2'd2; ev_dup = 1'b1; ag_ack_set = 1'b1;
              if (is_rreq && v_rreq_s && rdq_ready) begin
                chk_valid = 1'b1; chk_op = `SFR_CK_RRD; chk_key = hrkey; chk_va = hva; chk_len = rd_len;
                a_kind_n = 2'd3; st_chk_go = 1'b1;                 // header stays until the check answers
              end else rxh_pop = 1'b1;
            end else begin
              // ---- in order
              if (is_resv || !v_ok) begin
                cmd_kind = 2'd2; ag_fatal_set = 1'b1; ag_fatal_code = `SFR_NAK_INV; ev_unsupp = is_resv; rxh_pop = 1'b1;
              end else if (is_write) begin
                if (ring_free && tag_free) begin
                  chk_valid = 1'b1; chk_op = `SFR_CK_RWR; chk_key = hrkey; chk_va = hva; chk_len = {16'd0, paylen};
                  a_kind_n = 2'd0; st_chk_go = 1'b1;
                end
              end else if (is_rreq) begin
                if (!rdq_ready) begin
                  ag_nak_set = 1'b1; ag_nak_code = `SFR_NAK_RNR; rxh_pop = 1'b1;
                end else if (ring_free) begin
                  chk_valid = 1'b1; chk_op = `SFR_CK_RRD; chk_key = hrkey; chk_va = hva; chk_len = rd_len;
                  a_kind_n = 2'd2; st_chk_go = 1'b1;
                end
              end else begin
                // ---- SEND
                if (ring_free && (!has_pl || tag_free)) begin
                  if (f_first) begin
                    if (!rq_valid) begin
                      cmd_kind = 2'd2; ag_nak_set = 1'b1; ag_nak_code = `SFR_NAK_RNR; rxh_pop = 1'b1;
                    end else if (mlen > rq_len) begin
                      cqe_st_n = `SFR_CQ_LOC_LEN; st_cqe_go = 1'b1;
                    end else if (rq_len != 32'd0) begin
                      chk_valid = 1'b1; chk_op = `SFR_CK_LWR; chk_key = rq_lkey; chk_va = rq_addr; chk_len = rq_len;
                      a_kind_n = 2'd1; st_chk_go = 1'b1;
                    end else begin
                      // zero-length receive buffer, zero-length message: nothing to protect
                      rq_pop_f = 1'b1; do_accept = 1'b1; ring_done_in = 1'b1; ring_slast_in = 1'b1; ring_issend_in = 1'b1; ring_wr_in = rq_wr_id; ring_mlen_in = mlen;
                      rxh_pop = 1'b1;
                    end
                  end else begin
                    // continuation segment of the message in progress
                    if (has_pl) begin
                      cmd_kind = 2'd1; w_pa = cur_pa + PA_W'(moff); w_rid = cur_rid; w_ctx = cur_ctx;
                      tg_push = 1'b1; tg_wd = {1'b0, 1'b0, ep_i};
                    end
                    do_accept = 1'b1; ring_done_in = !has_pl; ring_slast_in = f_last; ring_issend_in = 1'b1; ring_ref_in = f_last && cur_has; ring_rid_in = cur_rid;
                    ring_wr_in = cur_wr; ring_mlen_in = cur_mlen;
                    if (f_last) cur_clr = 1'b1; else begin cur_off_n = mo_pl[31:0]; cur_set = 1'b1; cur_wr_n = cur_wr; cur_rid_n = cur_rid; cur_pa_n = cur_pa; cur_ctx_n = cur_ctx; cur_has_n = cur_has; end
                    rxh_pop = 1'b1;
                  end
                end
              end
            end
          end else begin
            // opcode outside the defined classes cannot reach here (the adapter drops it); be safe
            cmd_kind = 2'd2; rxh_pop = 1'b1;
          end
        end
      end
      // =====================================================================================================================
      S_CHK: begin
        // the registry answer is valid in this cycle
        if (rsp_valid) begin
          st_disp_go = 1'b1;
          if (flush_en || fatal_mode) begin
            // the QP went to error / a fatal decision was taken while the check was in flight: drop the grant, discard the frame
            chk_abort_rel = rsp_ok; cmd_kind = 2'd2; rxh_pop = 1'b1;
          end else case (a_kind)
            2'd0: begin  // WRITE
              if (rsp_ok) begin
                cmd_kind = 2'd1; w_pa = rsp_pa; w_rid = rsp_rid; w_ctx = rsp_ctx;
                tg_push = 1'b1; tg_wd = {1'b0, 1'b0, ep_i};
                do_accept = 1'b1; ring_ref_in = 1'b1; ring_rid_in = rsp_rid;
              end else begin
                cmd_kind = 2'd2; ag_fatal_set = 1'b1; ag_fatal_code = `SFR_NAK_ACC;
              end
              rxh_pop = 1'b1;
            end
            2'd1: begin  // SEND, first segment: receive-buffer check
              if (rsp_ok) begin
                rq_pop_f = 1'b1;
                if (has_pl) begin
                  cmd_kind = 2'd1; w_pa = rsp_pa + PA_W'(moff); w_rid = rsp_rid; w_ctx = rsp_ctx;
                  tg_push = 1'b1; tg_wd = {1'b0, 1'b0, ep_i};
                end
                do_accept = 1'b1; ring_done_in = !has_pl; ring_slast_in = f_last; ring_issend_in = 1'b1; ring_ref_in = f_last; ring_rid_in = rsp_rid;
                ring_wr_in = rq_wr_id; ring_mlen_in = mlen;
                if (!f_last) begin cur_set = 1'b1; cur_wr_n = rq_wr_id; cur_rid_n = rsp_rid; cur_pa_n = rsp_pa; cur_ctx_n = rsp_ctx; cur_has_n = 1'b1; cur_off_n = mo_pl[31:0]; end
                rxh_pop = 1'b1; st_disp_go = 1'b1;
              end else begin
                cqe_st_n = `SFR_CQ_LOC_PROT; st_cqe_go = 1'b1; st_disp_go = 1'b0;
              end
            end
            2'd2: begin  // READ, fresh
              if (rsp_ok) begin
                rdq_valid = 1'b1; rdq_pa = rsp_pa; rdq_rid = rsp_rid; rdq_ctx = rsp_ctx; rdq_replay = 1'b0;
                do_accept = 1'b1; ring_done_in = 1'b0; ring_ref_in = 1'b0; ring_isrd_in = 1'b1;
              end else begin
                ag_fatal_set = 1'b1; ag_fatal_code = `SFR_NAK_ACC;
              end
              rxh_pop = 1'b1;
            end
            default: begin // READ, duplicate (re-execution)
              if (rsp_ok) begin
                rdq_valid = 1'b1; rdq_pa = rsp_pa; rdq_rid = rsp_rid; rdq_ctx = rsp_ctx; rdq_replay = 1'b1;
              end else ev_dup_rd_fault = 1'b1;
              rxh_pop = 1'b1;
            end
          endcase
        end
      end
      // =====================================================================================================================
      default: begin  // S_CQE: a RECV completion for the consumed receive WQE with an error status, then the fatal NAK
        fsm_cqe = 1'b1;
        if (cmp_ready && ring_empty) begin
          rq_pop_f = 1'b1; cmd_kind = 2'd2; ag_fatal_set = 1'b1; ag_fatal_code = `SFR_NAK_OP; rxh_pop = 1'b1; st_disp_go = 1'b1;
        end
      end
    endcase
  end

  assign dw_cmd_valid   = (cmd_kind == 2'd1) || ((cmd_kind == 2'd2) && has_pl);
  assign dw_cmd_discard = (cmd_kind == 2'd2);
  assign dw_cmd_pa      = (cmd_kind == 2'd1) ? w_pa  : '0;
  assign dw_cmd_rid     = (cmd_kind == 2'd1) ? w_rid : '0;
  assign dw_cmd_ctx     = (cmd_kind == 2'd1) ? w_ctx : '0;
  assign dw_cmd_len     = paylen;

  // ---------------------------------------------------------------------------------------------------------------------------------
  // completion producer P1.  RECV completions leave in RECEIVE-QUEUE POST ORDER (spec 13), which is the order of the messages:
  //   committed SENDs of the ring (oldest first)  >  the FSM's error CQE for the next RQE  >  flush of the SEND in progress  >  flush of the RQ.
  // Everything younger than the ring waits until the ring is EMPTY (cpsn == epsn): before this, a flush CQE could overtake the RECV-OK CQE
  // of an older SEND whose write had not committed yet (found by the independent review, F-02).
  // In ERR a READ entry at the head of the ring can never complete (the read executor is halted): it is skipped, so the SENDs behind it still
  // commit and produce their CQE (otherwise their RQE and CQ credit were lost, F-05).
  // ---------------------------------------------------------------------------------------------------------------------------------
  wire         ring_ready = !ring_empty && (c_done[cp_i] || (flush_en && c_isrd[cp_i]));
  wire         ring_cqe   = ring_ready && c_slast[cp_i];
  wire         fsm_go     = fsm_cqe && ring_empty;
  wire         flush_cur  = flush_en && cur_valid && !fsm_cqe && ring_empty;
  wire         flush_rq   = flush_en && !cur_valid && !fsm_cqe && rq_valid && (st == S_DISP) && ring_empty;
  wire         ring_err   = c_err[cp_i] || msg_err;           // a memory error hit this message (the RECV completes LOC_OP_ERR)
  always_comb begin
    cmp_valid = 1'b0; cmp_wr_id = '0; cmp_op = `SFR_WOP_RECV; cmp_status = `SFR_CQ_OK; cmp_len = '0;
    if (ring_cqe)       begin cmp_valid = 1'b1; cmp_wr_id = c_wr[cp_i]; cmp_status = ring_err ? `SFR_CQ_LOC_OP : `SFR_CQ_OK; cmp_len = ring_err ? 32'd0 : c_mlen[cp_i]; end
    else if (fsm_go)    begin cmp_valid = 1'b1; cmp_wr_id = rq_wr_id; cmp_status = cqe_st_q; end
    else if (flush_cur) begin cmp_valid = 1'b1; cmp_wr_id = cur_wr;   cmp_status = msg_err ? `SFR_CQ_LOC_OP : `SFR_CQ_FLUSH; end
    else if (flush_rq)  begin cmp_valid = 1'b1; cmp_wr_id = rq_wr_id; cmp_status = `SFR_CQ_FLUSH; end
  end
  wire flush_cur_go = flush_cur && !ring_cqe && cmp_ready;
  wire flush_rq_go  = flush_rq  && cmp_ready;
  wire commit_go    = ring_ready && (!c_slast[cp_i] || (ring_cqe && cmp_ready));

  // reference releases: ONE PORT PER SOURCE (a shared port silently dropped a release when two coincided, S-02)
  assign rel_c_valid = commit_go && c_ref[cp_i];
  assign rel_c_rid   = c_rid[cp_i];
  assign rel_a_valid = chk_abort_rel;
  assign rel_a_rid   = rsp_rid;
  assign rel_f_valid = flush_cur_go && cur_has;
  assign rel_f_rid   = cur_rid;
  assign rq_pop      = rq_pop_f || flush_rq_go;

  // ---------------------------------------------------------------------------------------------------------------------------------
  // sequential
  // ---------------------------------------------------------------------------------------------------------------------------------
  // drain condition for QP reset: the frame FSM is parked, nothing is waiting for a write completion, no SEND is half received, and the
  // commit ring has drained (every accepted SEND produced its RECV CQE; READ entries are skipped in ERR, so this always terminates).
  assign quiet = (st == S_DISP) && !rxh_valid && !cur_valid && tg_empty && ring_empty;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_DISP; a_kind <= '0; nak_sent <= 1'b0; cqe_st_q <= '0; cur_valid <= 1'b0; cur_has <= 1'b0; cur_wr <= '0; cur_rid <= '0;
      cur_pa <= '0; cur_ctx <= '0; cur_mlen <= '0; cur_off <= '0; cpsn <= '0; epsn <= '0; msg_err <= 1'b0; place_pend <= '0;
      for (int i = 0; i < WINDOW; i++) begin c_vld[i] <= 1'b0; c_done[i] <= 1'b0; c_ref[i] <= 1'b0; c_rid[i] <= '0; c_slast[i] <= 1'b0; c_wr[i] <= '0; c_mlen[i] <= '0; c_isrd[i] <= 1'b0; c_issend[i] <= 1'b0; c_err[i] <= 1'b0; end
    end else if (clear) begin
      st <= S_DISP; nak_sent <= 1'b0; cur_valid <= 1'b0; cur_has <= 1'b0; cpsn <= epsn; msg_err <= 1'b0; place_pend <= '0;
      for (int i = 0; i < WINDOW; i++) begin c_vld[i] <= 1'b0; c_done[i] <= 1'b0; c_err[i] <= 1'b0; end
    end else begin
      if (ld_valid) begin cpsn <= ld_psn; epsn <= ld_psn; nak_sent <= 1'b0; end
      // frame FSM
      if (st_chk_go) begin st <= S_CHK; a_kind <= a_kind_n; end
      else if (st_cqe_go) begin st <= S_CQE; cqe_st_q <= cqe_st_n; end
      else if (st_disp_go) st <= S_DISP;
      if (set_nak_sent) nak_sent <= 1'b1;
      // accept: ring entry + epsn
      if (do_accept) begin
        c_vld[ep_i] <= 1'b1; c_done[ep_i] <= ring_done_in; c_ref[ep_i] <= ring_ref_in; c_rid[ep_i] <= ring_rid_in;
        c_slast[ep_i] <= ring_slast_in; c_wr[ep_i] <= ring_wr_in; c_mlen[ep_i] <= ring_mlen_in;
        c_isrd[ep_i] <= ring_isrd_in; c_issend[ep_i] <= ring_issend_in; c_err[ep_i] <= 1'b0;
        epsn <= epsn + 24'd1; nak_sent <= 1'b0;
      end
      // SEND message state
      if (cur_set) begin cur_valid <= 1'b1; cur_wr <= cur_wr_n; cur_rid <= cur_rid_n; cur_pa <= cur_pa_n; cur_ctx <= cur_ctx_n;
                         cur_has <= cur_has_n; cur_off <= cur_off_n; if (f_first) cur_mlen <= mlen; end
      if (cur_clr || flush_cur_go) cur_valid <= 1'b0;
      // write completions -> ring / requester
      if (dw_done_valid && !tg_empty && !tg_kind) begin c_done[tg_idx] <= 1'b1; if (dw_done_err) c_err[tg_idx] <= 1'b1; end
      place_pend <= place_pend + (($clog2(TAGQ)+1)'((tg_push && tg_wd[WB+1]) ? 1 : 0)) - (($clog2(TAGQ)+1)'((dw_done_valid && !tg_empty && tg_kind) ? 1 : 0));
      if (rg_done_valid) c_done[rg_done_psn[WB-1:0]] <= 1'b1;
      // commit
      if (commit_go) begin
        c_vld[cp_i] <= 1'b0; c_done[cp_i] <= 1'b0; cpsn <= cpsn + 24'd1;
        if (c_issend[cp_i]) begin if (c_slast[cp_i]) msg_err <= 1'b0; else if (c_err[cp_i]) msg_err <= 1'b1; end
      end
      if (flush_cur_go) msg_err <= 1'b0;
    end
  end

  // write completion routing: a finished READ-response placement tells the requester (only the LAST segment of a read matters)
  assign place_done_valid = dw_done_valid && !tg_empty && tg_kind && tg_last && !dw_done_err;
  assign place_done_psn   = 24'(tg_idx);
  assign place_err_valid  = dw_done_valid && !tg_empty && tg_kind && dw_done_err;
  assign place_err_idx    = tg_idx;
  assign place_idle       = (place_pend == '0);
  assign ev_accept = do_accept;
  assign ev_commit = commit_go;
  // a failed READ-response placement is reported to the requester (it fails the owning WQE LOC_OP_ERR); a failed responder write errors the QP here
  assign err_req   = (dw_done_valid && dw_done_err && !tg_empty && !tg_kind) || dw_viol;
  assign err_cause = `SFR_EC_INT;
endmodule
`default_nettype wire
