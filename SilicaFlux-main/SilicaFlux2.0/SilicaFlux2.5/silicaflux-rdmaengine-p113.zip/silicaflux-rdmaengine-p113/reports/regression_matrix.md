# Regression across parameterisations

The same directed suite (and, where listed, the random suites) with the engine built for each configuration and the reference model told the same parameters. (238 s)

| DW | MTU | WINDOW | MAX_RD | directed suite | random |
|---|---|---|---|---|---|
| 64 | 256 | 8 | 2 | 141/141 runs pass  (5 s)  -> out/matrix_dw64_mtu256_w8_rd2.md | random 120/120 |
| 32 | 256 | 8 | 2 | 141/141 runs pass  (6 s)  -> out/matrix_dw32_mtu256_w8_rd2.md | random 120/120 |
| 128 | 256 | 8 | 2 | 141/141 runs pass  (6 s)  -> out/matrix_dw128_mtu256_w8_rd2.md | random 120/120 |
| 64 | 64 | 8 | 2 | 139/139 runs pass  (5 s)  -> out/matrix_dw64_mtu64_w8_rd2.md | random 120/120 |
| 64 | 128 | 8 | 2 | 139/139 runs pass  (6 s)  -> out/matrix_dw64_mtu128_w8_rd2.md | random 120/120 |
| 64 | 512 | 8 | 2 | 139/139 runs pass  (5 s)  -> out/matrix_dw64_mtu512_w8_rd2.md | random 120/120 |
| 64 | 1024 | 8 | 2 | 139/139 runs pass  (6 s)  -> out/matrix_dw64_mtu1024_w8_rd2.md | random 120/120 |
| 64 | 256 | 4 | 2 | 141/141 runs pass  (6 s)  -> out/matrix_dw64_mtu256_w4_rd2.md | random 120/120 |
| 64 | 256 | 16 | 2 | 141/141 runs pass  (9 s)  -> out/matrix_dw64_mtu256_w16_rd2.md | random 120/120 |
| 64 | 256 | 2 | 1 | 141/141 runs pass  (8 s)  -> out/matrix_dw64_mtu256_w2_rd1.md | random 120/120 |
| 64 | 256 | 8 | 4 | 141/141 runs pass  (8 s)  -> out/matrix_dw64_mtu256_w8_rd4.md | random 120/120 |
| 32 | 64 | 4 | 1 | 139/139 runs pass  (8 s)  -> out/matrix_dw32_mtu64_w4_rd1.md | random 120/120 |
| 128 | 1024 | 16 | 4 | 139/139 runs pass  (8 s)  -> out/matrix_dw128_mtu1024_w16_rd4.md | random 120/120 |
| 32 | 1024 | 2 | 2 | 139/139 runs pass  (8 s)  -> out/matrix_dw32_mtu1024_w2_rd2.md | random 120/120 |
