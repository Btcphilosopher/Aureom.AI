# Lint and elaboration

## Verilator -Wall, legal parameter sets (must be clean)

| parameters | result |
|---|---|
| `defaults` | clean |
| `{'DW': 32}` | clean |
| `{'DW': 128, 'MTU': 512}` | clean |
| `{'MTU': 64, 'WINDOW': 4, 'NMR': 4}` | clean |
| `{'MTU': 1024, 'WINDOW': 16, 'MAX_RD': 4}` | clean |
| `{'DW': 32, 'MTU': 64, 'WINDOW': 2, 'MAX_RD': 1, 'SQ_DEPTH': 2, 'RQ_DEPTH': 2, 'CQ_DEPTH': 4}` | clean |
| `{'PA_W': 40, 'PD_W': 8, 'CTX_W': 3}` | clean |
| `{'SQ_DEPTH': 16, 'RQ_DEPTH': 16, 'CQ_DEPTH': 64, 'MEM_RD_OUT': 8, 'MEM_WR_OUT': 2}` | clean |

## Illegal parameter sets (each must be refused at elaboration by its own check)

| parameters | refused by | result |
|---|---|---|
| `{'DW': 16}` | `DW must` | refused |
| `{'DW': 256}` | `DW must` | refused |
| `{'PA_W': 24}` | `PA_W must` | refused |
| `{'MTU': 100}` | `MTU must` | refused |
| `{'MTU': 4, 'DW': 64}` | `MTU must` | refused |
| `{'MTU': 8192}` | `MTU must` | refused |
| `{'NMR': 1}` | `NMR must` | refused |
| `{'NMR': 40}` | `NMR must` | refused |
| `{'PD_W': 0}` | `` | refused |
| `{'CTX_W': 5}` | `PD_W must` | refused |
| `{'SQ_DEPTH': 6}` | `SQ_DEPTH` | refused |
| `{'RQ_DEPTH': 1}` | `SQ_DEPTH` | refused |
| `{'CQ_DEPTH': 12}` | `CQ_DEPTH` | refused |
| `{'WINDOW': 3}` | `WINDOW must` | refused |
| `{'WINDOW': 1}` | `WINDOW must` | refused |
| `{'MAX_RD': 0}` | `MAX_RD` | refused |
| `{'MAX_RD': 16}` | `MAX_RD` | refused |
| `{'MEM_RD_OUT': 3}` | `MEM_RD_OUT` | refused |
| `{'MEM_WR_OUT': 1}` | `MEM_RD_OUT` | refused |
| `{'PAGE_BYTES': 1000}` | `PAGE_BYTES` | refused |
| `{'ACCEPT_ACK_DELAY': 0}` | `ACCEPT_ACK_DELAY` | refused |

## Yosys elaboration (proc) of the full engine

sf_rdma_engine: elaborates
