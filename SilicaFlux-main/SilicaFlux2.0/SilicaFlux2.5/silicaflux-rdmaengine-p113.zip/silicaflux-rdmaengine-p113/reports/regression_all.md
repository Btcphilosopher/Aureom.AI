# Full simulation regression (`scripts/regress_all.py`)

**ALL STAGES PASS** in 164 s.

| stage | result | detail |
|---|---|---|
| make build | PASS | ok |
| make build-fi | PASS | ok |
| make build-pc | PASS | ok |
| lint (Verilator -Wall + illegal parameters) | PASS | lint: OK -> reports/lint.md |
| vendor check | PASS | vendor check: OK |
| reference model self-tests | PASS | OK |
| directed suite x seeds 1,2,3,4,5 | PASS | 705/705 runs |
| review repros (explicit expectations) | PASS | 16/16 runs |
| random suites (seeds 1..6 x 40) | PASS | 240/240 runs |
| fault-tail suites (seeds 101..106 x 30) | PASS | 180/180 runs |
| chaos suites (6 seeds, forced ERR/RESET) | PASS | 480/480 runs |
| PacketCore (P62) in path | PASS | 138/141 runs; 3 expected differences (PacketCore filters malformed / MAC-flagged frames before the engine counts them) |

The benches are Verilator models of the RTL; every scenario is run with randomised initial state (`+verilator+rand+reset+2`). Evidence level: RTL simulation. No FPGA, no timing, no silicon.
