# Formal verification results (RDMAEngine, Project 113)

Yosys 0.33 -> SMT2 -> `yosys-smtbmc --unroll` + z3 4.8.12.  Regenerate: `scripts/formal.py --mutants`.  Details of what is and is not covered: `formal/rdma/README.md`.

* **PROVED** = `comb` (all inputs, depth 1) or `prove` (k-induction: base case from reset + induction step) = UNBOUNDED for the stated instance and environment.
* **BOUNDED d** = BMC from reset, no violation within d cycles; NOT an unbounded proof.  **UNKNOWN** = timeout or induction not closed (reported honestly).
* **WITNESSED** = the assertion of a `vac` job failed as it must: the situation is reachable, so the passing jobs are not vacuous.
* **KILLED** = a planted defect was caught (see `reports/formal_mutants.md`).

| job | kind | harness | instance | depth | result | s | claim |
|---|---|---|---|---:|---|---:|---|
| retry_prove | prove | retry | FULLCFG=1 | 4 | **PROVED** | 3.4 | R1-R8 (+ F-03: a NAK in a progress cycle is processed against the reset base, progress clears `dead`) on the real widths (32-bit timeout / rnr_delay): counters bounded, exhaustion, timer never early / never lost, progress reset, RNR wait exactly rnr_delay; UNBOUNDED |
| retry_bmc | bmc | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2 | 22 | **BOUNDED 22** | 7.1 | R1-R8 from reset, small configuration, depth 22 (cross-check of the induction proof) |
| retry_bmc_k4 | bmc | retry | FULLCFG=0, TMAX=1, RMAX=4, NMAX=0, DMAX=1 | 20 | **BOUNDED 20** | 2.4 | R1-R8 from reset with retry_max up to 4 (back-off exponent min(k,3) reached: a timer expiry at k >= 3), depth 20 |
| vac_retry_11 | vac | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=11 | 20 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:159.11-159.51 @step 3) | 0.3 | witness: F-03: a SEQ_ERR NAK arriving in a progress cycle fires ev_nak |
| vac_retry_12 | vac | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=12 | 20 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:160.11-160.68 @step 3) | 0.2 | witness: F-03: an RNR NAK arriving in a progress cycle starts the wait |
| vac_retry_13 | vac | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=13 | 20 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:161.11-161.50 @step 4) | 0.3 | witness: `progress` clears the exhaustion latch |
| vac_retry_10 | vac | retry | FULLCFG=0, TMAX=1, RMAX=4, NMAX=0, DMAX=1, VAC=10 | 24 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:162.11-162.54 @step 14) | 0.5 | witness: a timer expiry with retry_cnt == 4 after k = 3 retries (exponent cap exercised) is reachable |
| vac_retry_1 | vac | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=1 | 18 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:150.11-150.31 @step 4) | 0.3 | witness: a timer expiry (ev_timeout) is reachable |
| vac_retry_2 | vac | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=2 | 18 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:151.11-151.27 @step 3) | 0.3 | witness: a SEQ_ERR-driven retry (ev_nak) is reachable |
| vac_retry_3 | vac | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=3 | 18 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:152.11-152.30 @step 3) | 0.2 | witness: retry exhaustion is reachable |
| vac_retry_4 | vac | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=4 | 18 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:153.11-153.27 @step 4) | 0.2 | witness: the end of an RNR wait (ev_rnr) is reachable |
| vac_retry_5 | vac | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=5 | 18 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:154.11-154.34 @step 3) | 0.2 | witness: RNR exhaustion is reachable |
| vac_retry_6 | vac | retry | FULLCFG=0, TMAX=2, RMAX=3, NMAX=1, DMAX=2, VAC=6 | 30 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:155.11-155.54 @step 9) | 0.4 | witness: a timeout with back-off exponent 3 (4th retry) is reachable |
| vac_retry_7 | vac | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=7 | 18 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:156.11-156.64 @step 4) | 0.3 | witness: progress with a non-zero retry counter is reachable |
| vac_retry_8 | vac | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=8 | 18 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:157.11-157.46 @step 5) | 0.3 | witness: OBS-1: an RNR wait stretched by a progress pulse is reachable |
| vac_retry_9 | vac | retry | FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=9 | 18 | **WITNESSED** (fv_retry: formal/rdma/fv_retry.sv:158.11-158.61 @step 3) | 0.2 | witness: an RNR NAK arriving during the wait is reachable |
| completion_prove | prove | completion | KMAX=0 | 4 | **PROVED** | 1.5 | K1-K4: credit invariant credits+cq_count+(takes-pushes)==CQ_DEPTH, no overflow, FIFO exactly-once order of a free-ordinal tagged CQE; UNBOUNDED (CQ_DEPTH=4) |
| completion_bmc | bmc | completion | KMAX=3 | 14 | **BOUNDED 14** | 3.6 | K1-K4 from reset, tagged ordinal K < 3, depth 14 (cross-check of the induction proof) |
| vac_completion_1 | vac | completion | KMAX=3, VAC=1 | 14 | **WITNESSED** (fv_completion: formal/rdma/fv_completion.sv:138.11-138.36 @step 7) | 0.3 | witness: the CQ becomes full (cq_count == CQ_DEPTH) |
| vac_completion_2 | vac | completion | KMAX=3, VAC=2 | 14 | **WITNESSED** (fv_completion: formal/rdma/fv_completion.sv:139.11-139.35 @step 4) | 0.3 | witness: all credits are reserved (credits == 0: posting back-pressured) |
| vac_completion_3 | vac | completion | KMAX=3, VAC=3 | 14 | **WITNESSED** (fv_completion: formal/rdma/fv_completion.sv:140.11-140.67 @step 3) | 0.3 | witness: both producers offer in the same cycle and exactly one is served |
| vac_completion_4 | vac | completion | KMAX=3, VAC=4 | 14 | **WITNESSED** (fv_completion: formal/rdma/fv_completion.sv:141.11-141.33 @step 4) | 0.3 | witness: a pop and a push in the same cycle |
| vac_completion_5 | vac | completion | KMAX=3, VAC=5 | 14 | **WITNESSED** (fv_completion: formal/rdma/fv_completion.sv:142.11-142.49 @step 4) | 0.4 | witness: the tagged CQE is popped (the FIFO-order check is exercised) |
| wqe_prove | prove | wqe | KMAX=0 | 4 | **PROVED** | 10.5 | W1-W6: post status = spec 6.3 in the stated precedence for ALL inputs, unsupported opcode never accepted, rejected post takes no slot/credit, FIFO order of a free-ordinal tagged post, back-pressure, occupancy; UNBOUNDED (depth-4 queues) |
| wqe_bmc | bmc | wqe | KMAX=3 | 14 | **BOUNDED 14** | 27.7 | W1-W6 from reset, tagged ordinal K < 3, depth 14 (cross-check of the induction proof) |
| vac_wqe_1 | vac | wqe | KMAX=3, VAC=1 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:231.11-231.27 @step 2) | 0.9 | witness: an SQ post is accepted |
| vac_wqe_2 | vac | wqe | KMAX=3, VAC=2 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:232.11-232.61 @step 3) | 0.8 | witness: POST_ERR_OPCODE |
| vac_wqe_3 | vac | wqe | KMAX=3, VAC=3 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:233.11-233.61 @step 3) | 0.8 | witness: POST_ERR_STATE |
| vac_wqe_4 | vac | wqe | KMAX=3, VAC=4 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:234.11-234.61 @step 3) | 1.0 | witness: POST_ERR_LEN |
| vac_wqe_5 | vac | wqe | KMAX=3, VAC=5 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:235.11-235.61 @step 3) | 0.8 | witness: POST_ERR_FIELDS |
| vac_wqe_6 | vac | wqe | KMAX=3, VAC=6 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:236.11-236.61 @step 3) | 0.9 | witness: POST_ERR_RANGE |
| vac_wqe_7 | vac | wqe | KMAX=3, VAC=7 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:237.11-237.27 @step 2) | 0.9 | witness: an RQ post is accepted |
| vac_wqe_8 | vac | wqe | KMAX=3, VAC=8 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:238.11-238.61 @step 3) | 0.8 | witness: RQ POST_ERR_STATE |
| vac_wqe_9 | vac | wqe | KMAX=3, VAC=9 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:239.11-239.61 @step 3) | 0.8 | witness: RQ POST_ERR_LEN |
| vac_wqe_10 | vac | wqe | KMAX=3, VAC=10 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:240.12-240.61 @step 3) | 0.9 | witness: RQ POST_ERR_RANGE |
| vac_wqe_11 | vac | wqe | KMAX=3, VAC=11 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:241.12-241.73 @step 6) | 0.9 | witness: SQ full back-pressure |
| vac_wqe_12 | vac | wqe | KMAX=3, VAC=12 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:242.12-242.73 @step 2) | 0.7 | witness: an aliasing unsupported opcode (5) offered to a ready queue in RTS |
| vac_wqe_13 | vac | wqe | KMAX=3, VAC=13 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:243.12-243.52 @step 3) | 0.8 | witness: the tagged SQ post is popped |
| vac_wqe_14 | vac | wqe | KMAX=3, VAC=14 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:244.12-244.52 @step 3) | 0.8 | witness: the tagged RQ post is popped |
| vac_wqe_15 | vac | wqe | KMAX=3, VAC=15 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:245.12-245.42 @step 2) | 0.8 | witness: both queues take a credit in the same cycle |
| vac_wqe_16 | vac | wqe | KMAX=3, VAC=16 | 14 | **WITNESSED** (fv_wqe: formal/rdma/fv_wqe.sv:246.12-246.89 @step 2) | 0.7 | witness: credit back-pressure with a non-full queue |
| registry_bmc | bmc | registry | P2=0, G2=0, CNT=0 | 7 | **BOUNDED 7** | 399.7 | G1-G8 from reset with symbolic commands (3 SETs fill the table): grant iff every 8.3 clause, first-failing fault code, config statuses, refcounts, guard, counters/log; BOUNDED (NMR=3, real 64-bit VA) |
| registry_cnt_bmc | bmc | registry | P2=1, G2=0, CNT=1 | 5 | **BOUNDED 5** | 478.0 | G1-G8 with BOTH check ports and the fault statistics: per-class saturating counters and the one-entry fault log equal the shadow; BOUNDED |
| vac_registry_1 | vac | registry | CNT=1, VAC=1 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:362.11-362.49 @step 4) | 13.0 | witness: a grant on port 0 |
| vac_registry_2 | vac | registry | CNT=1, VAC=2 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:363.11-363.33 @step 4) | 12.8 | witness: a grant on port 1 |
| vac_registry_3 | vac | registry | CNT=1, VAC=3 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:364.11-364.93 @step 4) | 5.4 | witness: a correct key with a different PD is presented |
| vac_registry_4 | vac | registry | CNT=1, VAC=4 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:365.11-365.46 @step 4) | 12.7 | witness: fault OVERFLOW (va+len wraps 2^64) |
| vac_registry_5 | vac | registry | CNT=1, VAC=5 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:366.11-366.63 @step 4) | 12.6 | witness: fault RANGE with a correct key |
| vac_registry_6 | vac | registry | CNT=1, VAC=6 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:367.11-367.46 @step 4) | 14.0 | witness: fault PAGE_CROSS |
| vac_registry_7 | vac | registry | CNT=1, VAC=7 | 7 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:368.11-368.47 @step 4) | 13.4 | witness: fault XLATE (context not live) |
| vac_registry_8 | vac | registry | CNT=1, VAC=8 | 8 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:369.11-369.61 @step 5) | 17.8 | witness: MR_INVAL answered BUSY |
| vac_registry_9 | vac | registry | CNT=1, VAC=9 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:370.11-370.61 @step 4) | 13.1 | witness: ERR_DUPKEY |
| vac_registry_10 | vac | registry | CNT=1, VAC=10 | 5 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:371.12-371.61 @step 3) | 9.3 | witness: ERR_RANGE |
| vac_registry_11 | vac | registry | CNT=1, VAC=11 | 5 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:372.12-372.61 @step 3) | 10.1 | witness: ERR_IDX |
| vac_registry_12 | vac | registry | CNT=1, VAC=12 | 8 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:373.12-373.53 @step 4) | 13.7 | witness: the DMA guard passes |
| vac_registry_13 | vac | registry | CNT=1, VAC=13 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:374.12-374.46 @step 4) | 12.3 | witness: both ports granted in one cycle |
| vac_registry_14 | vac | registry | CNT=1, VAC=14 | 8 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:375.12-375.35 @step 5) | 7.0 | witness: the table is completely full |
| vac_registry_15 | vac | registry | CNT=1, VAC=15 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:376.12-376.46 @step 4) | 14.4 | witness: fault BAD_DIR |
| vac_registry_16 | vac | registry | CNT=1, VAC=16 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:377.12-377.46 @step 4) | 12.6 | witness: fault BAD_PERM |
| vac_registry_17 | vac | registry | CNT=1, VAC=17 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:378.12-378.46 @step 4) | 12.4 | witness: fault BAD_LEN |
| vac_registry_18 | vac | registry | CNT=1, VAC=18 | 4 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:379.12-379.46 @step 3) | 8.9 | witness: fault BAD_KEY |
| vac_registry_19 | vac | registry | CNT=1, VAC=19 | 6 | **WITNESSED** (fv_registry: formal/rdma/fv_registry.sv:380.12-380.46 @step 4) | 11.5 | witness: fault BAD_PD |
| ackgen_prove | prove | ackgen | - | 4 | **PROVED** | 0.4 | A1-A6: no flag event is ever lost (incl. same-cycle push), flags cleared only by the consuming handshake, priority fatal>NAK>replay>ACK, frame contents, fatal NAK only at cpsn==epsn, replays repeat the fatal code, acceptance report; UNBOUNDED |
| ackgen_bmc | bmc | ackgen | - | 18 | **BOUNDED 18** | 1.6 | A1-A6 from reset, depth 18 (cross-check of the induction proof) |
| vac_ackgen_1 | vac | ackgen | VAC=1 | 14 | **WITNESSED** (fv_ackgen: formal/rdma/fv_ackgen.sv:145.11-145.47 @step 3) | 0.3 | witness: ack_set in the cycle an ACK frame is pushed (the lost-event bug situation) |
| vac_ackgen_2 | vac | ackgen | VAC=2 | 14 | **WITNESSED** (fv_ackgen: formal/rdma/fv_ackgen.sv:146.11-146.47 @step 3) | 0.2 | witness: nak_set while a NAK frame is pushed |
| vac_ackgen_3 | vac | ackgen | VAC=3 | 14 | **WITNESSED** (fv_ackgen: formal/rdma/fv_ackgen.sv:147.11-147.62 @step 5) | 0.3 | witness: replay_set while a replay frame is pushed |
| vac_ackgen_4 | vac | ackgen | VAC=4 | 14 | **WITNESSED** (fv_ackgen: formal/rdma/fv_ackgen.sv:148.11-148.28 @step 3) | 0.2 | witness: the fatal NAK is emitted |
| vac_ackgen_5 | vac | ackgen | VAC=5 | 14 | **WITNESSED** (fv_ackgen: formal/rdma/fv_ackgen.sv:149.11-149.62 @step 5) | 0.3 | witness: a replay frame is offered after the fatal NAK |
| vac_ackgen_6 | vac | ackgen | VAC=6 | 14 | **WITNESSED** (fv_ackgen: formal/rdma/fv_ackgen.sv:150.11-150.26 @step 6) | 0.3 | witness: the acceptance report makes an ACK pending |
| vac_ackgen_7 | vac | ackgen | VAC=7 | 14 | **WITNESSED** (fv_ackgen: formal/rdma/fv_ackgen.sv:151.11-151.35 @step 3) | 0.3 | witness: an acceptance event in the cycle a frame is pushed |
| vac_ackgen_8 | vac | ackgen | VAC=8 | 14 | **WITNESSED** (fv_ackgen: formal/rdma/fv_ackgen.sv:152.11-152.67 @step 3) | 0.2 | witness: NAK and ACK pending together (priority exercised) |
| vac_ackgen_9 | vac | ackgen | VAC=9 | 14 | **WITNESSED** (fv_ackgen: formal/rdma/fv_ackgen.sv:153.11-153.68 @step 3) | 0.2 | witness: a fatal NAK held back until cpsn == epsn |
| vac_ackgen_10 | vac | ackgen | VAC=10 | 14 | **WITNESSED** (fv_ackgen: formal/rdma/fv_ackgen.sv:154.12-154.46 @step 3) | 0.2 | witness: a second acceptance event while one is pending |
| dma_wr_bmc | bmc | dma_wr | KCMAX=2, LMAX=7 | 11 | **BOUNDED 11** | 210.7 | D1-D5 from reset: exact write set / data / strobes of a free command KC at a free address TA, no write for DISCARD / guard-failed commands, viol, commit after all acks, outstanding <= MEM_WR_OUT; BOUNDED (DW=32, PA_W=6) |
| vac_dma_wr_1 | vac | dma_wr | KCMAX=3, LMAX=9, VAC=1 | 14 | **WITNESSED** (fv_dma_wr: formal/rdma/fv_dma_wr.sv:143.11-143.70 @step 7) | 0.8 | witness: the tagged WRITE commits (done pulse after all acks) |
| vac_dma_wr_2 | vac | dma_wr | KCMAX=3, LMAX=9, VAC=2 | 14 | **WITNESSED** (fv_dma_wr: formal/rdma/fv_dma_wr.sv:144.11-144.53 @step 6) | 0.6 | witness: a second word of the tagged command is written |
| vac_dma_wr_3 | vac | dma_wr | KCMAX=3, LMAX=9, VAC=3 | 14 | **WITNESSED** (fv_dma_wr: formal/rdma/fv_dma_wr.sv:145.11-145.25 @step 3) | 0.4 | witness: a guard failure converts a command and raises viol |
| vac_dma_wr_4 | vac | dma_wr | KCMAX=3, LMAX=9, VAC=4 | 14 | **WITNESSED** (fv_dma_wr: formal/rdma/fv_dma_wr.sv:146.11-146.49 @step 4) | 0.5 | witness: a DISCARD command consumes payload beats |
| vac_dma_wr_5 | vac | dma_wr | KCMAX=3, LMAX=9, VAC=5 | 14 | **WITNESSED** (fv_dma_wr: formal/rdma/fv_dma_wr.sv:147.11-147.36 @step 7) | 0.7 | witness: the outstanding-write limit is reached |
| vac_dma_wr_6 | vac | dma_wr | KCMAX=3, LMAX=9, VAC=6 | 14 | **WITNESSED** (fv_dma_wr: formal/rdma/fv_dma_wr.sv:148.11-148.76 @step 5) | 0.7 | witness: an unaligned tagged byte is written |
| vac_dma_wr_7 | vac | dma_wr | KCMAX=3, LMAX=9, VAC=7 | 14 | **WITNESSED** (fv_dma_wr: formal/rdma/fv_dma_wr.sv:149.11-149.56 @step 5) | 0.6 | witness: a written word contains an address outside the command (strobe must be 0) |
| vac_dma_wr_8 | vac | dma_wr | KCMAX=3, LMAX=9, VAC=8 | 14 | **WITNESSED** (fv_dma_wr: formal/rdma/fv_dma_wr.sv:150.11-150.45 @step 6) | 0.6 | witness: an acknowledgement error reaches done_err |
| vac_dma_wr_9 | vac | dma_wr | KCMAX=3, LMAX=9, VAC=9 | 14 | **WITNESSED** (fv_dma_wr: formal/rdma/fv_dma_wr.sv:151.11-151.72 @step 6) | 0.6 | witness: a guard-converted command reports done (F-09) |
| dma_rd_bmc | bmc | dma_rd | KCMAX=2, LMAX=7 | 12 | **BOUNDED 12** | 424.7 | P1-P5 from reset: read addresses inside the commanded range, payload bytes / keep / last / port exactly as commanded (free command KC), guard-failed commands issue no read and pulse viol, outstanding <= MEM_OUT, no FIFO overflow, done accounting; BOUNDED (DW=32, PA_W=6) |
| vac_dma_rd_1 | vac | dma_rd | KCMAX=3, LMAX=9, VAC=1 | 14 | **WITNESSED** (fv_dma_rd: formal/rdma/fv_dma_rd.sv:166.11-166.69 @step 8) | 0.8 | witness: the tagged command completes (done pulse) |
| vac_dma_rd_2 | vac | dma_rd | KCMAX=3, LMAX=9, VAC=2 | 14 | **WITNESSED** (fv_dma_rd: formal/rdma/fv_dma_rd.sv:167.11-167.52 @step 5) | 0.7 | witness: a second word of the tagged command is read |
| vac_dma_rd_3 | vac | dma_rd | KCMAX=3, LMAX=9, VAC=3 | 14 | **WITNESSED** (fv_dma_rd: formal/rdma/fv_dma_rd.sv:168.11-168.25 @step 3) | 0.5 | witness: a guard failure raises viol |
| vac_dma_rd_4 | vac | dma_rd | KCMAX=3, LMAX=9, VAC=4 | 14 | **WITNESSED** (fv_dma_rd: formal/rdma/fv_dma_rd.sv:169.11-169.37 @step 6) | 0.6 | witness: the outstanding-read limit is reached |
| vac_dma_rd_5 | vac | dma_rd | KCMAX=3, LMAX=9, VAC=5 | 14 | **WITNESSED** (fv_dma_rd: formal/rdma/fv_dma_rd.sv:170.11-170.74 @step 7) | 0.6 | witness: a partial last beat is emitted |
| vac_dma_rd_6 | vac | dma_rd | KCMAX=3, LMAX=9, VAC=6 | 14 | **WITNESSED** (fv_dma_rd: formal/rdma/fv_dma_rd.sv:171.11-171.78 @step 8) | 0.9 | witness: a misaligned multi-beat command (realignment) |
| vac_dma_rd_7 | vac | dma_rd | KCMAX=3, LMAX=9, VAC=7 | 14 | **WITNESSED** (fv_dma_rd: formal/rdma/fv_dma_rd.sv:172.11-172.45 @step 8) | 0.8 | witness: a memory error reaches done_err |
| rx_safety_bmc | bmc | rx | - | 12 | **BOUNDED 12** | 336.5 | X1-X6: remote-write safety (WRITE only in order, only with the grant of its own check, pa/rid/ctx = granted, never for duplicates / out-of-sequence), epsn/cpsn discipline, no fatal with a used grant, RNR, reserved opcode -> INV_REQ; BOUNDED (WINDOW=4) |
| vac_rx_1 | vac | rx | VAC=1 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:207.11-207.73 @step 5) | 15.5 | witness: a WRITE command from a granted check of an in-order WRITE frame |
| vac_rx_2 | vac | rx | VAC=2 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:208.11-208.56 @step 4) | 12.2 | witness: a duplicate request frame is presented |
| vac_rx_3 | vac | rx | VAC=3 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:209.11-209.33 @step 4) | 12.5 | witness: a fatal NAK decision |
| vac_rx_4 | vac | rx | VAC=4 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:210.11-210.140 @step 4) | 11.8 | witness: RNR: in-order SEND first segment with no receive WQE |
| vac_rx_5 | vac | rx | VAC=5 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:211.11-211.81 @step 4) | 11.6 | witness: reserved opcode -> INV_REQ |
| vac_rx_6 | vac | rx | VAC=6 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:212.11-212.53 @step 6) | 15.5 | witness: a SEND continuation WRITE command |
| vac_rx_7 | vac | rx | VAC=7 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:213.11-213.41 @step 4) | 11.5 | witness: a READ_RESP placement |
| vac_rx_8 | vac | rx | VAC=8 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:214.11-214.30 @step 5) | 14.4 | witness: a commit (cpsn advances) |
| vac_rx_9 | vac | rx | VAC=9 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:215.11-215.37 @step 8) | 23.2 | witness: the commit window is full |
| vac_rx_10 | vac | rx | VAC=10 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:216.12-216.96 @step 5) | 15.2 | witness: a grant arriving in fatal / flush mode is released |
| vac_rx_11 | vac | rx | VAC=11 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:217.12-217.58 @step 4) | 11.5 | witness: an out-of-sequence request frame is presented |
| vac_rx_12 | vac | rx | VAC=12 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:218.12-218.64 @step 5) | 14.5 | witness: a READ request is accepted |
| vac_rx_13 | vac | rx | VAC=13 | 12 | **WITNESSED** (fv_rx_safety: formal/rdma/fv_rx_safety.sv:219.12-219.84 @step 6) | 16.8 | witness: a READ entry is committed by the flush (skipped) |
| requester_w4_rd_bmc | bmc | requester | WIN=4, ONLYRD=1 | 10 | **BOUNDED 10** | 134.8 | Q1-Q7 with WINDOW 4 and an all-READ SQ stream (three READs can be outstanding: MAX_RD limit); BOUNDED |
| requester_rd_bmc | bmc | requester | WIN=2, ONLYRD=1 | 11 | **BOUNDED 11** | 392.0 | Q1-Q7 with an all-READ SQ stream (reaches READ issue + retirement races: rd_out, bug 2); BOUNDED |
| requester_deep_bmc | bmc | requester | WIN=2 | 10 | **BOUNDED 10** | 433.0 | SAME harness, depth 10: FOUND the una <= txp violation F-1 (SEQ_ERR rewind and retirement in the same cycle) on the RTL of 12:01 (= review item S-01, fixed by the txp_n net next-state); regression check on the repaired RTL |
| requester_bmc | bmc | requester | WIN=2 | 9 | **BOUNDED 9** | 64.7 | Q1-Q6: window, una<=txp<=nxt (also after rewinds), rd_out == READ entries in flight, completion only after commit / placement, CQEs in post order exactly once, no entries for failed WQEs; BOUNDED (WINDOW=2, MAX_RD=2) |
| vac_requester_1 | vac | requester | WIN=2, VAC=1 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:222.11-222.69 @step 8) | 8.0 | witness: a WRITE completes OK |
| vac_requester_2 | vac | requester | WIN=2, VAC=2 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:223.11-223.69 @step 9) | 8.8 | witness: a READ completes OK |
| vac_requester_3 | vac | requester | WIN=2, VAC=3 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:224.11-224.35 @step 8) | 6.8 | witness: the window fills |
| vac_requester_4 | vac | requester | WIN=2, VAC=4 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:225.11-225.57 @step 9) | 7.2 | witness: a timeout rewinds the transmit pointer |
| vac_requester_5 | vac | requester | WIN=2, VAC=5 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:226.11-226.62 @step 8) | 6.6 | witness: an entry retires while txp points at it (bug-3 corner) |
| vac_requester_6 | vac | requester | WIN=2, VAC=6 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:227.11-227.39 @step 10) | 7.6 | witness: two READs outstanding |
| vac_requester_7 | vac | requester | WIN=2, VAC=7 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:228.11-228.51 @step 6) | 5.5 | witness: a local-check failure completes with LOC_PROT_ERR |
| vac_requester_8 | vac | requester | WIN=2, VAC=8 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:229.11-229.51 @step 3) | 3.5 | witness: a flush CQE |
| vac_requester_9 | vac | requester | WIN=2, VAC=9 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:230.11-230.57 @step 8) | 6.4 | witness: a retransmitted frame is sent |
| vac_requester_10 | vac | requester | WIN=2, VAC=10 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:231.12-231.54 @step 6) | 5.0 | witness: a SEQ_ERR NAK rewinds |
| vac_requester_11 | vac | requester | WIN=2, VAC=11 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:232.12-232.36 @step 7) | 6.1 | witness: an RNR wait ends |
| vac_requester_12 | vac | requester | WIN=2, VAC=12 | 18 | **WITNESSED** (fv_requester: formal/rdma/fv_requester.sv:233.12-233.52 @step 7) | 5.9 | witness: retry exhaustion fails a WQE |
| psn_spec | comb | psn | PART=0 | 1 | **PROVED** | 0.8 | F1-F4 for ALL 24-bit a, b, c: exactly one of before / equal / after (neither at exactly half the space), transitivity inside a window, window total order, stepping |
| psn_rx | comb | psn | PART=1 | 4 | **PROVED** | 3.8 | sf_rdma_rx classification of a request frame (in order / out of sequence / duplicate, exactly-half = stale) equals the spec definition for ALL psn / epsn (exhaustive: combinational in (psn, epsn), epsn loaded freely) |
| vac_psn_1 | vac | psn | PART=0, VAC=1 | 1 | **WITNESSED** (fv_psn: formal/rdma/fv_psn.sv:43.11-43.40 @step 0) | 0.2 | witness: a pair at exactly half the space exists |
| vac_psn_2 | vac | psn | PART=0, VAC=2 | 1 | **WITNESSED** (fv_psn: formal/rdma/fv_psn.sv:44.11-44.68 @step 0) | 0.3 | witness: transitivity genuinely FAILS outside a window (so the window side-condition of F2 is needed) |
| vac_psn_rx_1 | vac | psn | PART=1, VAC=1 | 5 | **WITNESSED** (fv_psn: formal/rdma/fv_psn.sv:93.13-93.52 @step 3) | 3.5 | witness: a duplicate verdict (ev_dup) occurs |
| vac_psn_rx_2 | vac | psn | PART=1, VAC=2 | 5 | **WITNESSED** (fv_psn: formal/rdma/fv_psn.sv:94.13-94.52 @step 3) | 3.3 | witness: an out-of-sequence verdict (ev_oos) occurs |
| vac_psn_rx_3 | vac | psn | PART=1, VAC=3 | 5 | **WITNESSED** (fv_psn: formal/rdma/fv_psn.sv:95.13-95.47 @step 3) | 3.7 | witness: an in-order frame is processed (rxh_pop) |
| vac_psn_rx_4 | vac | psn | PART=1, VAC=4 | 5 | **WITNESSED** (fv_psn: formal/rdma/fv_psn.sv:96.13-96.42 @step 3) | 3.5 | witness: the exactly-half distance occurs |

Summary: BOUNDED 14, PROVED 6, WITNESSED 110  (130 jobs).

Mutation campaign: 81 / 84 planted defects KILLED (table: `reports/formal_mutants.md`).
