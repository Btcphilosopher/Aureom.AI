# Synthesis estimate (Yosys generic gates)

**What this is.** `yosys synth` of `sf_rdma_engine` with the vendored IP, generic gate library, hierarchy kept. **What it is not:** no PDK, no FPGA mapping, no timing, no area in µm², no frequency, no power. Arrays (payload rings, request table, WQE context ring, queues) become REGISTERS here although a real flow would infer SRAM/BRAM for the rings, so the flop counts overstate the logic.


## `default` (defaults: DW=64 MTU=256 WINDOW=8 NMR=8)  — 131 s, rc=0

| module (parameterised instance) | cells | flip-flops |
|---|---|---|
| `design hierarchy` | 198159 | 38829 |
| `sf_rdma_transport_adapter` | 47995 | 13862 |
| `$paramodsf_rdma_perfNPC=s32'00000000000000000000000001011011` | 46030 | 4243 |
| `sf_rdma_requester` | 20940 | 3430 |
| `sf_rdma_memory_registry` | 20851 | 2021 |
| `sf_rdma_rx` | 14640 | 1070 |
| `sf_rdma_wqe` | 11752 | 3880 |
| `$paramodsf_rdma_completionCQ_DEPTH=s32'00000000000000000000000000100000` | 10309 | 3347 |
| `sf_rdma_fifo` | 2777 | 1096 |
| `$paramodsf_stream_dma_alignDW=s32'00000000000000000000000001000000` | 2303 | 133 |
| `sf_rdma_fifo` | 1637 | 640 |
| `sf_rdma_retry` | 1371 | 82 |
| `sf_rdma_rdgen` | 1341 | 167 |
| `sf_rdma_dma_rd` | 1069 | 96 |
| `sf_rdma_dma_wr` | 813 | 74 |
| `sf_rdma_fifo` | 708 | 268 |
| `sf_rdma_qp` | 666 | 293 |
| `sf_rdma_fifo` | 578 | 216 |
| `$paramodsf_rdma_ackgenACCEPT_ACK_DELAY=s32'00000000000000000000000001000000` | 427 | 46 |
| `sf_rdma_fifo` | 394 | 92 |
| `$paramodsfb_skid_bufferWIDTH=s32'00000000000000000000000001001001` | 229 | 148 |
| `sf_rdma_engine` | 215 | 6 |
| `sf_rdma_fifo` | 195 | 114 |
| `sf_rdma_fifo` | 92 | 46 |
| `sf_rdma_fifo` | 68 | 12 |
| `$paramodsf_rr_arbN=s32'00000000000000000000000000000010` | 10 | 1 |

**Whole design (hierarchy summed): 198159 cells.**

## `small` {'DW': 32, 'MTU': 64, 'WINDOW': 4, 'NMR': 4, 'SQ_DEPTH': 4, 'RQ_DEPTH': 4, 'CQ_DEPTH': 8}  — 94 s, rc=0

| module (parameterised instance) | cells | flip-flops |
|---|---|---|
| `design hierarchy` | 137917 | 21682 |
| `$paramodsf_rdma_perfNPC=s32'00000000000000000000000001011011` | 46010 | 4243 |
| `sf_rdma_transport_adapter` | 18424 | 4219 |
| `sf_rdma_memory_registry` | 15267 | 1299 |
| `sf_rdma_requester` | 14352 | 1862 |
| `sf_rdma_rx` | 13164 | 645 |
| `sf_rdma_wqe` | 5877 | 1948 |
| `sf_rdma_fifo` | 2777 | 1096 |
| `$paramodsf_rdma_completionCQ_DEPTH=s32'00000000000000000000000000001000` | 2552 | 845 |
| `sf_rdma_fifo` | 1627 | 636 |
| `sf_rdma_retry` | 1369 | 82 |
| `sf_rdma_rdgen` | 1340 | 166 |
| `$paramodsf_stream_dma_alignDW=s32'00000000000000000000000000100000` | 1027 | 68 |
| `sf_rdma_dma_rd` | 807 | 96 |
| `sf_rdma_dma_wr` | 752 | 74 |
| `sf_rdma_qp` | 669 | 293 |
| `sf_rdma_fifo` | 578 | 216 |
| `$paramodsf_rdma_ackgenACCEPT_ACK_DELAY=s32'00000000000000000000000001000000` | 427 | 46 |
| `sf_rdma_fifo` | 388 | 140 |
| `sf_rdma_fifo` | 342 | 76 |
| `sf_rdma_engine` | 215 | 6 |
| `sf_rdma_fifo` | 192 | 112 |
| `$paramodsfb_skid_bufferWIDTH=s32'00000000000000000000000000100101` | 121 | 76 |
| `sf_rdma_fifo` | 89 | 44 |
| `sf_rdma_fifo` | 68 | 12 |
| `$paramodsf_rr_arbN=s32'00000000000000000000000000000010` | 10 | 1 |

**Whole design (hierarchy summed): 137917 cells.**

## `wide` {'DW': 128, 'MTU': 512, 'WINDOW': 16}  — 181 s, rc=0

| module (parameterised instance) | cells | flip-flops |
|---|---|---|
| `design hierarchy` | 259866 | 56265 |
| `sf_rdma_transport_adapter` | 86657 | 26668 |
| `$paramodsf_rdma_perfNPC=s32'00000000000000000000000001011011` | 46010 | 4243 |
| `sf_rdma_requester` | 34010 | 6544 |
| `sf_rdma_memory_registry` | 20850 | 2021 |
| `sf_rdma_rx` | 17396 | 1910 |
| `sf_rdma_wqe` | 11751 | 3880 |
| `$paramodsf_rdma_completionCQ_DEPTH=s32'00000000000000000000000000100000` | 10309 | 3347 |
| `$paramodsf_stream_dma_alignDW=s32'00000000000000000000000010000000` | 5118 | 262 |
| `sf_rdma_fifo` | 2777 | 1096 |
| `sf_rdma_dma_rd` | 1649 | 96 |
| `sf_rdma_fifo` | 1637 | 640 |
| `sf_rdma_retry` | 1376 | 82 |
| `sf_rdma_fifo` | 1348 | 524 |
| `sf_rdma_rdgen` | 1345 | 167 |
| `sf_rdma_dma_wr` | 926 | 74 |
| `sf_rdma_qp` | 670 | 293 |
| `sf_rdma_fifo` | 578 | 216 |
| `$paramodsfb_skid_bufferWIDTH=s32'00000000000000000000000010010001` | 445 | 292 |
| `sf_rdma_fifo` | 440 | 108 |
| `$paramodsf_rdma_ackgenACCEPT_ACK_DELAY=s32'00000000000000000000000001000000` | 427 | 46 |
| `sf_rdma_engine` | 215 | 6 |
| `sf_rdma_fifo` | 195 | 114 |
| `sf_rdma_fifo` | 95 | 48 |
| `sf_rdma_fifo` | 68 | 12 |
| `$paramodsf_rr_arbN=s32'00000000000000000000000000000010` | 10 | 1 |

**Whole design (hierarchy summed): 259866 cells.**
