# Simulation mutation testing

Baseline: 141/141 runs pass  (8 s) | 15/16 runs pass  (1 s) (1 failing runs).  **57 / 57 mutants killed**, 0 survived, 0 invalid.

| mutant | file | what a correct suite must notice | result | first scenarios that caught it |
|---|---|---|---|---|
| reg_no_pd | sf_rdma_memory_registry.sv | domain isolation: a correct key from another protection domain must not grant | KILLED | t051_domain_isolation_write.scn, t052_domain_isolation_read.scn, t053_domain_isolation_local_lkey.scn (+1) |
| reg_range_lt | sf_rdma_memory_registry.sv | off-by-one: a request ending exactly at the region end must be granted | KILLED | t133_exact_fit_region_boundaries.scn |
| reg_range_nolo | sf_rdma_memory_registry.sv | a request starting below the region must be refused | KILLED | t033_write_range_below_start.scn, t037_read_range_below_start.scn |
| reg_no_overflow | sf_rdma_memory_registry.sv | a wrapping 64-bit range must be refused as OVERFLOW | KILLED | t040_overflow_local_laddr_wraps.scn, t041_overflow_wire_write.scn, t042_overflow_wire_read.scn |
| reg_no_dir | sf_rdma_memory_registry.sv | a local-only region used remotely is a DIRECTION fault | KILLED | t055_direction_write_to_localonly.scn, t056_direction_read_from_localonly.scn, t057_direction_send_from_remoteonly_local.scn (+1) |
| reg_no_perm | sf_rdma_memory_registry.sv | write to a read-only region must be refused | KILLED | t046_perm_write_to_readonly.scn, t047_perm_read_from_writeonly.scn, t048_perm_read_dest_readonly_local.scn (+2) |
| reg_no_pagecross | sf_rdma_memory_registry.sv | page crossing on a non-contiguous region must be refused | KILLED | t059_page_cross_write_noncontig.scn, t060_page_cross_read_noncontig.scn, t061_page_cross_local_noncontig.scn |
| reg_no_xlate | sf_rdma_memory_registry.sv | a disabled translation context must refuse access | KILLED | t068_ctx_disabled_remote.scn, t070_ctx_disable_live_context.scn, t071_ctx_disabled_local.scn |
| reg_no_dupkey | sf_rdma_memory_registry.sv | duplicate keys must be refused at registration | KILLED | t076_cfg_status_matrix.scn |
| reg_key_31bits | sf_rdma_memory_registry.sv | the whole 32-bit key must match | KILLED | t134_key_bit31_differs_remote.scn, t136_key_bit31_differs_local.scn |
| reg_pa_nooffset | sf_rdma_memory_registry.sv | the physical address must include the offset into the region | KILLED | rv01c_read_then_fatal_control.scn, t001_send_single.scn, t002_send_multiseg.scn (+111) |
| wqe_flags_ok | sf_rdma_wqe.sv | reserved flags must be rejected at post | KILLED | t074_post_status_matrix.scn |
| wqe_zero_len | sf_rdma_wqe.sv | zero-length WRITE/READ must be rejected at post | KILLED | t074_post_status_matrix.scn |
| wqe_no_range | sf_rdma_wqe.sv | a message wrapping 2^64 must be rejected at post | KILLED | t074_post_status_matrix.scn |
| wqe_op_any | sf_rdma_wqe.sv | unsupported opcodes must be rejected explicitly | KILLED | t073_post_unsupported_opcode.scn, t074_post_status_matrix.scn |
| cq_no_credit_ret | sf_rdma_completion.sv | CQ credits must be returned when the host consumes a CQE | KILLED | rv01_read_then_fatal_resp_lost.scn, rv01b_read_then_fatal_last_resp_lost.scn, rv01c_read_then_fatal_control.scn (+150) |
| retry_one_more | sf_rdma_retry.sv | retry budget: exactly retry_max retransmissions, then exhausted | KILLED | rv01_read_then_fatal_resp_lost.scn, rv01b_read_then_fatal_last_resp_lost.scn, t109_timeout_black_forward_retry_exc.scn (+3) |
| retry_no_reset | sf_rdma_retry.sv | progress must reset the consecutive-retry counter | KILLED | t140_retry_budget_restarts_on_progress.scn |
| req_done_early | sf_rdma_requester.sv | completion only after the responder COMMITTED the data | KILLED | rv02_recv_cqe_order_forced_err.scn, rv03_seq_nak_dropped_by_progress.scn, rv04_rnr_nak_dropped_by_progress.scn (+129) |
| req_window_over | sf_rdma_requester.sv | the outstanding window is a hard bound | KILLED | t005_send_mtu_edges.scn, t007_write_aligned.scn, t008_write_unaligned.scn (+9) |
| req_no_gbn | sf_rdma_requester.sv | a timeout must retransmit from the oldest unfinished request | KILLED | rv01_read_then_fatal_resp_lost.scn, rv01b_read_then_fatal_last_resp_lost.scn, t090_loss_random_forward.scn (+9) |
| req_ignore_commit | sf_rdma_requester.sv | the commit frontier must be tracked | KILLED | rv01_read_then_fatal_resp_lost.scn, rv01b_read_then_fatal_last_resp_lost.scn, rv03_seq_nak_dropped_by_progress.scn (+105) |
| req_stale_ack_ok | sf_rdma_requester.sv | stale / forged ACKs must be ignored | KILLED | t086_inject_stale_ack_and_badcode.scn, t103_reorder_random_delay.scn, t129_concurrent_dma_under_loss.scn |
| rx_dup_inorder | sf_rdma_rx.sv | a duplicate request must never be applied twice | KILLED | t087_stale_duplicate_must_not_overwrite.scn, t088_stale_duplicate_multisegment.scn, t097_loss_by_ordinal_last_ack.scn (+12) |
| rx_no_rspok | sf_rdma_rx.sv | no memory write without a registry grant | KILLED | rv01_read_then_fatal_resp_lost.scn, rv01b_read_then_fatal_last_resp_lost.scn, rv01c_read_then_fatal_control.scn (+21) |
| rx_no_lencheck | sf_rdma_rx.sv | an incoming message longer than the receive buffer must be refused | KILLED | t030_rqe_too_small.scn, t141_recv_error_cqe_waits_for_older_send.scn |
| rx_no_rnr | sf_rdma_rx.sv | a SEND with no receive WQE must get RNR, not garbage | KILLED | rv04_rnr_nak_dropped_by_progress.scn, t041_overflow_wire_write.scn, t042_overflow_wire_read.scn (+15) |
| rx_resp_offset | sf_rdma_rx.sv | READ responses must arrive in order at the expected offset | KILLED | rv01_read_then_fatal_resp_lost.scn, rv01b_read_then_fatal_last_resp_lost.scn, t100_duplicate_random.scn (+3) |
| rx_accept_on_fault | sf_rdma_rx.sv | a refused request must not advance accept_next | KILLED | rv01_read_then_fatal_resp_lost.scn, rv01b_read_then_fatal_last_resp_lost.scn, rv01c_read_then_fatal_control.scn (+21) |
| rdgen_no_fence | sf_rdma_rdgen.sv | read-after-write fence (spec 7.3) | KILLED | t137_read_after_write_slow_responder_memory.scn |
| ag_commit_eq_accept | sf_rdma_ackgen.sv | an ACK must report the COMMIT frontier, not the accept frontier | KILLED | rv02_recv_cqe_order_forced_err.scn, t002_send_multiseg.scn, t004_send_unaligned.scn (+17) |
| ag_fatal_early | sf_rdma_ackgen.sv | a fatal NAK waits until every earlier request has committed | KILLED | rv01_read_then_fatal_resp_lost.scn, rv01b_read_then_fatal_last_resp_lost.scn, rv01c_read_then_fatal_control.scn (+16) |
| ad_no_epoch | sf_rdma_transport_adapter.sv | frames of an old connection incarnation must be dropped | KILLED | t084_inject_malformed_frames.scn, t085_inject_malformed_frames_to_requester.scn, t118_qp_reset_mid_traffic_new_epoch.scn (+1) |
| ad_no_ethertype | sf_rdma_transport_adapter.sv | a frame with the wrong EtherType must be dropped | KILLED | rv13_drop_counter_order_paylen_gt_mtu.scn, t084_inject_malformed_frames.scn, t085_inject_malformed_frames_to_requester.scn |
| ad_no_lencheck | sf_rdma_transport_adapter.sv | a frame whose length contradicts its header must be dropped | KILLED | t084_inject_malformed_frames.scn, t085_inject_malformed_frames_to_requester.scn |
| ad_ignore_macerr | sf_rdma_transport_adapter.sv | a frame flagged bad by the MAC must never be committed | KILLED | t139_wire_write_flagged_bad_by_mac.scn |
| dw_first_offset | sf_rdma_dma_wr.sv | unaligned destination: partial first word strobes | KILLED | t004_send_unaligned.scn, t006_send_len_sweep.scn, t008_write_unaligned.scn (+12) |
| dr_unaligned_addr | sf_rdma_dma_rd.sv | memory reads are word aligned | KILLED | t004_send_unaligned.scn, t006_send_len_sweep.scn, t008_write_unaligned.scn (+11) |
| rx_no_flush_rq | sf_rdma_rx.sv | unconsumed receive WQEs must be flushed when the QP errs | KILLED | rv02_recv_cqe_order_forced_err.scn, t024_write_bad_rkey.scn, t029_rqe_bad_lkey.scn (+7) |
| retry_nak_swallowed | sf_rdma_retry.sv | F-03: a SEQ_ERR NAK in a progress cycle must still start go-back-N | KILLED | rv03_seq_nak_dropped_by_progress.scn |
| retry_rnr_swallowed | sf_rdma_retry.sv | F-03: an RNR NAK in a progress cycle must still start the back-off | KILLED | rv04_rnr_nak_dropped_by_progress.scn |
| req_chi_overwrite | sf_rdma_requester.sv | F-07: the retire fix-up must not overwrite an ACK's frontier update | KILLED | rv12_chi_update_lost_to_retire_fixup.scn |
| req_txp_noclamp | sf_rdma_requester.sv | S-01: txp may never fall below una (needs the random suites) | KILLED | r0001_032_mix.scn, r0002_012_mix.scn, r0002_013_mix.scn |
| req_fatal_disarm | sf_rdma_requester.sv | F-01: after a fatal NAK the timer keeps protecting the earlier entries | KILLED | rv01_read_then_fatal_resp_lost.scn, rv01b_read_then_fatal_last_resp_lost.scn |
| req_fatal_notx | sf_rdma_requester.sv | F-01: after a fatal NAK the earlier entries are still retransmitted | KILLED | rv01_read_then_fatal_resp_lost.scn, rv01b_read_then_fatal_last_resp_lost.scn |
| req_fatal_txall | sf_rdma_requester.sv | F-01: after a fatal NAK nothing at or after the failed PSN is retransmitted | KILLED | rv01_read_then_fatal_resp_lost.scn, rv01b_read_then_fatal_last_resp_lost.scn |
| req_lerr_off | sf_rdma_requester.sv | F-04: a memory error on a source read must fail the WQE LOC_OP_ERR | KILLED | rv07_memerr_requester_source_read.scn |
| req_flush_nogate | sf_rdma_requester.sv | F-06: a flushed WQE's grant is not released while its DMA is in flight | KILLED | rv06_inval_ok_while_read_placement_in_flight.scn |
| rx_flush_early | sf_rdma_rx.sv | F-02/F-06: flush completions wait until every older message committed | KILLED | rv14_inval_ok_while_partial_send_dma_in_flight.scn |
| rx_no_read_skip | sf_rdma_rx.sv | F-05: a READ that can never execute must not block the commit ring in ERR | KILLED | rv05_recv_cqe_lost_behind_stuck_read.scn |
| rx_werr_ignored | sf_rdma_rx.sv | F-04: a write acknowledged with an error must not complete the RECV OK | KILLED | rv09_memerr_write_ack_send.scn |
| rx_fsm_cqe_early | sf_rdma_rx.sv | RQ order: the FSM's error CQE waits for older messages | KILLED | t141_recv_error_cqe_waits_for_older_send.scn |
| ad_no_poison | sf_rdma_transport_adapter.sv | F-04: a frame whose payload fetch failed must never be transmitted | KILLED | rv07_memerr_requester_source_read.scn, rv08_memerr_responder_read_data.scn |
| dr_no_pl_err | sf_rdma_dma_rd.sv | F-04: the read engine must report a failed fetch | KILLED | rv07_memerr_requester_source_read.scn, rv08_memerr_responder_read_data.scn |
| ad_no_req_drop | sf_rdma_transport_adapter.sv | F-08: no request frame leaves after the QP entered ERR | KILLED | rv10_frames_leave_after_err.scn |
| ad_drop_resp_in_err | sf_rdma_transport_adapter.sv | F-08 (regression found while fixing): responses to already committed READs must still go out after a fatal NAK | KILLED | rv01c_read_then_fatal_control.scn |
| ad_len_early | sf_rdma_transport_adapter.sv | F-10: paylen > MTU is counted after the opcode check | KILLED | rv13_drop_counter_order_paylen_gt_mtu.scn |
