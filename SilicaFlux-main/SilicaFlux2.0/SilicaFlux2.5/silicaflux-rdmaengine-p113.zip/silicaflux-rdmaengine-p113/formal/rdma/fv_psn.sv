// =============================================================================
// Formal harness: modular PSN ordering (spec 0 "PSN arithmetic") and the receive classification psn vs epsn (spec 9.3)
//
// Definitions (spec 0, written HERE with 25/26-bit arithmetic, independent of the RTL's "difference sign bit" tricks):
//   dist(a,b) = (b - a) mod 2^24;     a before b  <=>  dist(a,b) in [1, 2^23 - 1].
// PART = 0 (no DUT, comb, depth 1: PROVED for ALL 24-bit a, b, c):
//   F1  for dist(a,b) != 2^23 exactly one of  a before b,  a = b,  b before a  holds;  at exactly 2^23 NEITHER direction holds.
//   F2  transitivity inside a window: dist(a,b) >= 1, dist(b,c) >= 1 and dist(a,b) + dist(b,c) <= 2^23 - 1  =>  a before c.
//   F3  a sliding window is totally ordered: for a base u and two PSNs x, y with dist(u,x) <= WINDOW and dist(u,y) <= WINDOW
//       (WINDOW = 8 here, 2^23 in general): x before y  <=>  dist(u,x) < dist(u,y).
//   F4  stepping: a before a+1, and a+1 is the only PSN b with dist(a,b) = 1.
// PART = 1 (sf_rdma_rx instantiated, exhaustive over psn / epsn):  the receive classification of a REQUEST frame in state S_DISP
//   (spec 9.3) equals the specification:   psn = epsn  -> in order (neither ev_dup nor ev_oos);   epsn before psn -> out of sequence
//   (ev_oos, never ev_dup);   psn before epsn -> duplicate (ev_dup, never ev_oos);   psn at exactly half the space -> the RTL
//   treats it as a duplicate (the spec leaves it open; it is never applied: safe).   In ALL cases other than "in order" no WRITE command
//   (dw_cmd_valid && !dw_cmd_discard) and no accept is produced.   (The observed outputs are a combinational function of (psn, epsn) and
//   every epsn is reachable through the load pulse, so the depth-4 check from reset is exhaustive for this claim.)
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none
module fv_psn #(
  parameter PART = 0,
  parameter VAC  = 0
) (
  input wire clk,
  input wire [23:0] a, input wire [23:0] b, input wire [23:0] c,
  input wire [271:0] hdr_f
);
  function [24:0] dist(input [23:0] x, input [23:0] y); dist = ({1'b0, y} + 25'h1000000 - {1'b0, x}) & 25'h0FFFFFF; endfunction
  function before(input [23:0] x, input [23:0] y); reg [24:0] d; begin d = dist(x, y); before = (d >= 25'd1) && (d <= 25'h7FFFFF); end endfunction
  wire [24:0] dab = dist(a, b), dbc = dist(b, c), dac = dist(a, c);

  generate if (PART == 0) begin : g_spec
    always @* if (VAC == 0) begin
      F1a: assert(dab == 25'h800000 || ((before(a, b) ? 1 : 0) + ((a == b) ? 1 : 0) + (before(b, a) ? 1 : 0) == 1));
      F1b: assert(dab != 25'h800000 || (!before(a, b) && !before(b, a)));
      F2:  assert(!(dab >= 25'd1 && dbc >= 25'd1 && dab + dbc <= 25'h7FFFFF) || before(a, c));
      F3:  assert(!(dab <= 25'd8 && dac <= 25'd8) || (before(b, c) == (dab < dac)));     // base a, window elements b, c
      F4a: assert(before(a, a + 24'd1));
      F4b: assert(!(dist(a, b) == 25'd1) || b == a + 24'd1);
    end else begin
      case (VAC)
        1: assert(!(dab == 25'h800000));                       // the exactly-half distance exists
        2: assert(!(before(a, b) && before(b, c) && !before(a, c)));   // transitivity FAILS outside a window (reachable counter-example to the unconstrained claim)
      endcase
    end
  end else begin : g_rx
    reg init = 1'b1;
    always @(posedge clk) init <= 1'b0;
    wire rst_n = !init;
    reg first = 1'b1; always @(posedge clk) if (!init) first <= 1'b0;
    wire ld_valid = !init && first;
    (* anyconst *) reg [23:0] PSN0;
    wire [271:0] sh = hdr_f;
    wire [7:0] opc = `SFR_H_OPC(sh);
    wire [23:0] psn = `SFR_H_PSN(sh);
    wire [15:0] paylen = `SFR_H_PAYLEN(sh);
    wire is_reqop = (opc >= 8'h01) && (opc <= 8'h0F);
    wire rxh_pop, dw_cmd_valid, dw_cmd_discard, chk_valid, rel_c_valid, rel_a_valid, rel_f_valid, place_err_valid, place_idle, rq_pop, cmp_valid, ack_valid, rr_accept, place_done_valid, rdq_valid, rdq_replay;
    wire ag_ack_set, ag_nak_set, ag_fatal_set, ag_replay_set, quiet, err_req, ev_dup, ev_oos, ev_resp_drop, ev_accept, ev_commit, ev_unsupp, ev_dup_rd_fault, ev_nak_badcode;
    wire [7:0] dw_cmd_pa; wire [15:0] dw_cmd_len; wire [0:0] dw_cmd_rid, dw_cmd_ctx; wire [1:0] chk_op; wire [31:0] chk_key, chk_len; wire [1:0] chk_pd; wire [63:0] chk_va; wire [0:0] rel_c_rid, rel_a_rid, rel_f_rid; wire [1:0] place_err_idx;
    wire [63:0] cmp_wr_id; wire [3:0] cmp_op, cmp_status; wire [31:0] cmp_len; wire [23:0] ack_cn, ack_an, rr_psn, place_done_psn, rdq_psn, cpsn, epsn; wire [3:0] ack_code, ag_nak_code, ag_fatal_code, err_cause;
    wire [15:0] rr_accept_len; wire [7:0] rdq_pa; wire [31:0] rdq_len, rdq_moff, rdq_mlen; wire [0:0] rdq_rid, rdq_ctx; wire [3:0] ring_occ;
    wire [1:0] o_st;   // OBS g_rx.o_st g_rx.dut.st ?PART=1
    sf_rdma_rx #(.WINDOW(4), .MTU(256), .PA_W(8), .PD_W(2), .RID_W(1), .CTX_W(1), .TAGQ(4), .MAX_MSG_BYTES(1048576)) dut (
      .clk(clk), .rst_n(rst_n), .clear(1'b0), .en_req(1'b1), .en_resp(1'b1), .flush_en(1'b0), .ld_valid(ld_valid), .ld_psn(PSN0), .qp_pd(2'd1),
      .rxh_valid(1'b1), .rxh_sh(hdr_f), .rxh_pop(rxh_pop),
      .dw_cmd_valid(dw_cmd_valid), .dw_cmd_ready(1'b1), .dw_cmd_discard(dw_cmd_discard), .dw_cmd_pa(dw_cmd_pa), .dw_cmd_len(dw_cmd_len), .dw_cmd_rid(dw_cmd_rid), .dw_cmd_ctx(dw_cmd_ctx),
      .dw_done_valid(1'b0), .dw_done_err(1'b0), .dw_viol(1'b0),
      .chk_valid(chk_valid), .chk_op(chk_op), .chk_key(chk_key), .chk_pd(chk_pd), .chk_va(chk_va), .chk_len(chk_len),
      .rsp_valid(1'b0), .rsp_ok(1'b0), .rsp_rid(1'b0), .rsp_pa(8'd0), .rsp_ctx(1'b0), .rel_c_valid(rel_c_valid), .rel_c_rid(rel_c_rid), .rel_a_valid(rel_a_valid), .rel_a_rid(rel_a_rid), .rel_f_valid(rel_f_valid), .rel_f_rid(rel_f_rid),
      .rq_valid(1'b0), .rq_pop(rq_pop), .rq_wr_id(64'd0), .rq_addr(64'd0), .rq_lkey(32'd0), .rq_len(32'd0),
      .cmp_valid(cmp_valid), .cmp_ready(1'b1), .cmp_wr_id(cmp_wr_id), .cmp_op(cmp_op), .cmp_status(cmp_status), .cmp_len(cmp_len),
      .ack_valid(ack_valid), .ack_cn(ack_cn), .ack_an(ack_an), .ack_code(ack_code), .rr_psn(rr_psn), .rr_found(1'b0), .rr_exp_off(32'd0), .rr_mlen(32'd0),
      .rr_lpa(8'd0), .rr_rid(1'b0), .rr_ctx(1'b0), .rr_accept(rr_accept), .rr_accept_len(rr_accept_len), .place_done_valid(place_done_valid), .place_done_psn(place_done_psn), .place_err_valid(place_err_valid), .place_err_idx(place_err_idx), .place_idle(place_idle),
      .rdq_valid(rdq_valid), .rdq_ready(1'b1), .rdq_psn(rdq_psn), .rdq_pa(rdq_pa), .rdq_len(rdq_len), .rdq_moff(rdq_moff), .rdq_mlen(rdq_mlen), .rdq_rid(rdq_rid), .rdq_ctx(rdq_ctx),
      .rdq_replay(rdq_replay), .rg_done_valid(1'b0), .rg_done_psn(24'd0),
      .ag_ack_set(ag_ack_set), .ag_nak_set(ag_nak_set), .ag_nak_code(ag_nak_code), .ag_fatal_set(ag_fatal_set), .ag_fatal_code(ag_fatal_code), .ag_replay_set(ag_replay_set), .fatal_mode(1'b0),
      .cpsn(cpsn), .epsn(epsn), .quiet(quiet), .err_req(err_req), .err_cause(err_cause), .ring_occ(ring_occ),
      .ev_dup(ev_dup), .ev_oos(ev_oos), .ev_resp_drop(ev_resp_drop), .ev_accept(ev_accept), .ev_commit(ev_commit), .ev_unsupp(ev_unsupp), .ev_dup_rd_fault(ev_dup_rd_fault), .ev_nak_badcode(ev_nak_badcode));
    wire [24:0] dpe = dist(psn, epsn);             // psn before epsn  <=>  dpe in [1, 2^23-1]
    wire [24:0] dep = dist(epsn, psn);             // epsn before psn
    wire frame_in_s_disp = !init && !first && (o_st == 2'd0) && is_reqop && (epsn == PSN0);
    always @(posedge clk) if (frame_in_s_disp) begin
      if (VAC == 0) begin
        C1: assert(psn != epsn || (!ev_dup && !ev_oos));
        C2: assert(!before(epsn, psn) || (ev_oos && !ev_dup));
        C3: assert(!before(psn, epsn) || (ev_dup && !ev_oos));
        C4: assert(dep != 25'h800000 || (ev_dup && !ev_oos));                 // exactly half: treated as stale (never applied)
        C5: assert(psn == epsn || (!(dw_cmd_valid && !dw_cmd_discard) && !ev_accept && !rq_pop));
      end else begin
        case (VAC)
          1: assert(!(ev_dup && before(psn, epsn)));
          2: assert(!(ev_oos && before(epsn, psn)));
          3: assert(!(psn == epsn && rxh_pop));                               // an in-order frame is processed
          4: assert(!(dep == 25'h800000));
        endcase
      end
    end
  end endgenerate
endmodule
