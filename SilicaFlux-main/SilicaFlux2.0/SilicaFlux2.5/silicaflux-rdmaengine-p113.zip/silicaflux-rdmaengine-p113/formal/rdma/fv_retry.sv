// =============================================================================
// Formal harness: sf_rdma_retry   (retransmission timer, retry accounting, RNR back-off)       TRANSPORT_SPEC 9.5, 9.6, 5.1
//
// Claims (plain English), each derived from the spec text, checked against a shadow built ONLY from the module's ports:
//   R1  retry_cnt <= retry_max and rnr_cnt <= rnr_max, always (constant configuration).                         [9.6: k = retry_max -> exhausted]
//   R2  `exhausted` is raised only when retry_cnt == retry_max (and `rnr_exhausted` only when rnr_cnt == rnr_max).  [9.6]
//   R3  After an exhaustion pulse nothing fires again (no ev_*, no second exhausted) until `en` falls.              [module contract / 11.1]
//   R4  No event (ev_*, exhausted, rnr_exhausted) is ever the consequence of a cycle in which `en` was low.         [QP state gating, 5.2]
//   R5  The retransmission timer never expires earlier than the effective timeout  timeout << min(k, 3)  counted in
//       consecutive running cycles since the last restart / progress / (re)arming / retry event (shadow counter).      [9.6]
//       Conversely an expiry with the timer at the limit and nothing else pending always produces an event.         [no late / lost expiry]
//   R6  `progress` resets BOTH consecutive-retry counters to 0 and starts no retry.                                 [9.5 (2), 9.6]
//   R7  Retry accounting: a decision with k < retry_max gives k+1 and ev_timeout / ev_nak (SEQ_ERR NAK wins when both);
//       with k == retry_max it gives `exhausted` and leaves k unchanged.   RNR: the same with r and rnr_max.         [9.6]
//   R8  RNR: ev_rnr comes exactly rnr_delay (non-progress) wait cycles after an ACCEPTED RNR NAK; RNR NAKs, retry NAKs and
//       timer expiries arriving during the wait are ignored (rnr_cnt / retry_cnt unchanged).                        [9.5 (5), 9.6]
// Environment: configuration is CONSTANT (anyconst) with timeout >= 1 (spec 5.1); all other inputs are free every cycle.
//              Reset is applied in cycle 0 only.  `restart` is free (the requester pulses it the cycle after an event).
// Instance: FULLCFG=1 -> 32-bit timeout / rnr_delay, 4-bit counts (the real widths).  FULLCFG=0 -> small bounds for BMC / witnesses.
// VAC != 0: reachability witnesses (the assertion MUST fail; see formal.py).
// Induction lemmas (OBS lines) relate the shadow to three internal registers (tcnt, rcnt, dead); the claims above are on ports only.
// =============================================================================
`default_nettype none
module fv_retry #(
  parameter FULLCFG = 1,
  parameter TMAX    = 2,       // FULLCFG=0: 1 <= timeout <= TMAX
  parameter RMAX    = 2,       //            retry_max <= RMAX
  parameter NMAX    = 1,       //            rnr_max   <= NMAX
  parameter DMAX    = 2,       //            rnr_delay <= DMAX
  parameter VAC     = 0
) (
  input wire clk,
  input wire en, input wire armed, input wire progress, input wire restart, input wire nak_retry, input wire rnr_nak
);
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  (* anyconst *) reg [31:0] cfg_timeout;
  (* anyconst *) reg [3:0]  cfg_retry_max;
  (* anyconst *) reg [3:0]  cfg_rnr_max;
  (* anyconst *) reg [31:0] cfg_rnr_delay;
  always @(posedge clk) begin
    assume(cfg_timeout >= 32'd1);
    if (FULLCFG == 0) begin
      assume(cfg_timeout <= TMAX); assume(cfg_retry_max <= RMAX); assume(cfg_rnr_max <= NMAX); assume(cfg_rnr_delay <= DMAX);
    end
  end

  wire ev_timeout, ev_nak, ev_rnr, exhausted, rnr_exhausted, rnr_wait;
  wire [3:0] retry_cnt, rnr_cnt;
  sf_rdma_retry #(.BACKOFF_MAX(3)) dut (
    .clk(clk), .rst_n(rst_n), .en(en), .armed(armed), .progress(progress), .restart(restart), .nak_retry(nak_retry), .rnr_nak(rnr_nak),
    .cfg_timeout(cfg_timeout), .cfg_retry_max(cfg_retry_max), .cfg_rnr_max(cfg_rnr_max), .cfg_rnr_delay(cfg_rnr_delay),
    .ev_timeout(ev_timeout), .ev_nak(ev_nak), .ev_rnr(ev_rnr), .exhausted(exhausted), .rnr_exhausted(rnr_exhausted),
    .rnr_wait(rnr_wait), .retry_cnt(retry_cnt), .rnr_cnt(rnr_cnt));
  // induction-lemma observation of internal registers
  wire [34:0] o_tcnt;   // OBS o_tcnt dut.tcnt
  wire [31:0] o_rcnt;   // OBS o_rcnt dut.rcnt
  wire        o_dead;   // OBS o_dead dut.dead

  // ---------------------------------------------------------------- shadow (ports only)
  wire any_ev = ev_timeout | ev_nak | ev_rnr;
  wire any_ex = exhausted | rnr_exhausted;
  wire [2:0]  k3    = (retry_cnt > 4'd3) ? 3'd3 : retry_cnt[2:0];         // min(k, BACKOFF_MAX=3)
  wire [34:0] limit = {3'b0, cfg_timeout} << k3;                           // effective timeout of the current k

  reg [34:0] sc;          // consecutive cycles the retransmission timer has been running (before ev compensation)
  reg        dead_s;      // an exhaustion pulse was seen and `en` has not fallen since
  reg [31:0] wc, st;      // RNR wait: cycles waited, of which cycles that carried a `progress` pulse
  // sc_eff(t): the count AT cycle t.  A retry event visible at t is the registered result of a decision at t-1, which restarted the timer.
  wire [34:0] sc_eff   = any_ev ? 35'd0 : sc;
  wire        dead_eff = dead_s | any_ex;

  // previous-cycle copies (a decision taken in cycle t is observed in cycle t+1)
  reg en_q, armed_q, progress_q, nak_retry_q, rnr_nak_q, rnr_wait_q, dead_eff_q;
  reg [3:0]  retry_cnt_q, rnr_cnt_q; reg dead_s_q;
  reg [34:0] sc_eff_q, limit_q;
  reg [31:0] wc_q, st_q;

  always @(posedge clk) begin
    if (init) begin
      sc <= 35'd0; dead_s <= 1'b0; wc <= 32'd0; st <= 32'd0;
      en_q <= 1'b0; armed_q <= 1'b0; progress_q <= 1'b0; nak_retry_q <= 1'b0; rnr_nak_q <= 1'b0; rnr_wait_q <= 1'b0; dead_eff_q <= 1'b0;
      dead_s_q <= 1'b0; retry_cnt_q <= 4'd0; rnr_cnt_q <= 4'd0; sc_eff_q <= 35'd0; limit_q <= 35'd0; wc_q <= 32'd0; st_q <= 32'd0;
    end else begin
      if (!en || progress || restart || !armed) sc <= 35'd0;               // spec 9.6: runs while armed; restarts on progress / retransmission
      else if (rnr_wait)                         sc <= sc_eff;               //         paused during the RNR wait
      else                                       sc <= sc_eff + 35'd1;
      dead_s <= en ? (dead_eff && !progress) : 1'b0;                      // `progress` clears the dead latch (an event of the same cycle may set it again)
      if (!rnr_wait) begin wc <= 32'd0; st <= 32'd0; end
      else begin wc <= wc + 32'd1; if (progress && en) st <= st + 32'd1; end
      en_q <= en; armed_q <= armed; progress_q <= progress; nak_retry_q <= nak_retry; rnr_nak_q <= rnr_nak; rnr_wait_q <= rnr_wait; dead_eff_q <= dead_eff;
      dead_s_q <= dead_eff; retry_cnt_q <= retry_cnt; rnr_cnt_q <= rnr_cnt; sc_eff_q <= sc_eff; limit_q <= limit; wc_q <= wc; st_q <= st;
    end
  end

  // what a decision in the previous cycle must have been (spec 9.5 / 9.6 priority: RNR NAK, then SEQ_ERR NAK / timer expiry).  `progress` resets
  // both counters BEFORE the event of the same cycle is counted (the event is processed against the reset base); only a timer EXPIRY is
  // suppressed by progress (progress restarts the timer).
  wire live_q    = en_q && !rnr_wait_q && !dead_eff_q;
  wire [3:0] rcb_q = progress_q ? 4'd0 : retry_cnt_q;                 // retry base of the decision
  wire [3:0] ncb_q = progress_q ? 4'd0 : rnr_cnt_q;
  wire rnr_acc_q = live_q && rnr_nak_q;
  wire expired_q = armed_q && (sc_eff_q >= limit_q);
  wire ret_dec_q = live_q && !rnr_nak_q && ((expired_q && !progress_q) || nak_retry_q);
  wire [32:0] waited_q = {1'b0, (wc_q - st_q)} + 33'd1;               // non-progress wait cycles including the previous cycle
  wire wait_end_q = rnr_wait_q && en_q && !progress_q && (waited_q >= {1'b0, cfg_rnr_delay});

  always @(posedge clk) if (!init) begin
    if (VAC == 0) begin
      // R1
      A01: assert(retry_cnt <= cfg_retry_max);
      A02: assert(rnr_cnt   <= cfg_rnr_max);
      // R2
      A03: assert(!exhausted     || retry_cnt == cfg_retry_max);
      A04: assert(!rnr_exhausted || rnr_cnt   == cfg_rnr_max);
      // R3 / R4
      A05: assert(!dead_s || !(any_ev | any_ex));
      A06: assert(!(any_ev | any_ex) || en_q);
      // R5 : never earlier than the effective timeout; never lost
      A07: assert(!ev_timeout || (expired_q && !nak_retry_q && !progress_q));
      A08: assert(!ret_dec_q || (ev_timeout | ev_nak | exhausted));
      // R6 / R7 counter accounting: counters = base (reset by progress) + 1 for an ACCEPTED event; a decision with base == max exhausts instead
      A09: assert(!en_q || retry_cnt == ((ret_dec_q && rcb_q != cfg_retry_max) ? rcb_q + 4'd1 : rcb_q));
      A10: assert(!en_q || rnr_cnt   == ((rnr_acc_q && ncb_q != cfg_rnr_max)   ? ncb_q + 4'd1 : ncb_q));
      A11: assert(!(ev_timeout | ev_nak | exhausted) || ret_dec_q);
      A12: assert(!(ret_dec_q && rcb_q != cfg_retry_max) || ((nak_retry_q ? ev_nak : ev_timeout) && !exhausted));
      A13: assert(!(ret_dec_q && rcb_q == cfg_retry_max) || (exhausted && !ev_timeout && !ev_nak));
      A14: assert(!(rnr_exhausted || (rnr_wait && !rnr_wait_q)) || rnr_acc_q);
      A15: assert(!(rnr_acc_q && ncb_q != cfg_rnr_max) || (rnr_wait && !rnr_exhausted));
      A16: assert(!(rnr_acc_q && ncb_q == cfg_rnr_max) || (rnr_exhausted && !rnr_wait));
      // R8 RNR wait
      A17: assert(ev_rnr == wait_end_q);                                                  // exactly at the end of the wait, never otherwise
      A18: assert(!(rnr_wait_q && en_q) || (rnr_wait == !(!progress_q && waited_q >= {1'b0, cfg_rnr_delay})));
      A19: assert(!ev_rnr || (waited_q == ((cfg_rnr_delay == 32'd0) ? 33'd1 : {1'b0, cfg_rnr_delay})));   // exactly rnr_delay non-progress cycles
      A20: assert(!(rnr_wait_q && en_q) || !(ev_timeout | ev_nak | exhausted | rnr_exhausted));      // NAKs / expiry during the wait are ignored (counters: A09 / A10)
      A21: assert(!(!en_q) || (!rnr_wait && retry_cnt == 4'd0 && rnr_cnt == 4'd0));
      // NEW (review fix F-03): a NAK that arrives in the SAME cycle as progress is NOT swallowed
      A27: assert(!(en_q && progress_q && nak_retry_q && !rnr_nak_q && !rnr_wait_q && !dead_eff_q) || (ev_nak | exhausted));
      A28: assert(!(en_q && progress_q && rnr_nak_q && !rnr_wait_q && !dead_eff_q) || (rnr_wait | rnr_exhausted));
      // induction lemmas (shadow <-> internal registers)
      A22: assert(sc_eff == o_tcnt);
      A23: assert(o_dead == dead_eff);
      A24: assert(!rnr_wait || o_rcnt == wc - st);
      A25: assert(!(o_dead && rnr_wait));
      A26: assert(!rnr_wait || {1'b0, o_rcnt} < ((cfg_rnr_delay == 32'd0) ? 33'd1 : {1'b0, cfg_rnr_delay}));
    end else begin
      case (VAC)
        1: assert(!ev_timeout);                                   // a timer expiry is reachable
        2: assert(!ev_nak);                                       // a SEQ_ERR-driven retry is reachable
        3: assert(!exhausted);                                    // retry exhaustion is reachable
        4: assert(!ev_rnr);                                       // the end of an RNR wait is reachable
        5: assert(!rnr_exhausted);                                // RNR exhaustion is reachable
        6: assert(!(ev_timeout && retry_cnt == 4'd3));            // a timeout with back-off exponent 3 (4th retry) is reachable
        7: assert(!(en_q && progress_q && retry_cnt_q != 4'd0));  // progress with a non-zero retry counter (R6 is not vacuous)
        8: assert(!(ev_rnr && st_q != 32'd0));                    // OBSERVATION OBS-1: an RNR wait is stretched by a progress pulse
        9: assert(!(rnr_nak && rnr_wait && en && !progress));     // an RNR NAK arrives during the wait (and is ignored)
       11: assert(!(ev_nak && progress_q && en_q));               // F-03: a SEQ_ERR NAK in a progress cycle fires ev_nak
       12: assert(!(rnr_wait && !rnr_wait_q && progress_q && en_q)); // F-03: an RNR NAK in a progress cycle starts the wait
       13: assert(!(dead_s_q && !dead_eff && en));                 // `progress` clears the exhaustion latch
       10: assert(!(ev_timeout && retry_cnt == 4'd4));            // a timer expiry decided at k = 3 (back-off exponent cap reached)
      endcase
    end
  end
endmodule
