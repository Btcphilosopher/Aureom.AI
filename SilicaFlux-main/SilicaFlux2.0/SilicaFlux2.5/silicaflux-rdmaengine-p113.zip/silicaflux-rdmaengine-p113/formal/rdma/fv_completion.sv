// =============================================================================
// Formal harness: sf_rdma_completion   (completion queue with CREDIT RESERVATION)               TRANSPORT_SPEC 12.2, 13
//
// Claims (plain English):
//   K1  CREDIT INVARIANT  credits + cq_count + (takes - pushes) == CQ_DEPTH  at all times, where takes = credits reserved by accepted
//       posts (take_sq / take_rq) and pushes = CQEs accepted by the queue.  Credits never go negative or above CQ_DEPTH.     [12.2]
//   K2  Hence `ev_overflow` (a push found the queue full) NEVER fires and a producer with an outstanding reservation is never blocked
//       by a full queue: "a completion can never be lost or overflow the CQ, including flush completions".                  [12.2]
//   K3  Every accepted CQE is popped exactly once, in FIFO (acceptance) order, with all its fields intact: a symbolic tagged item
//       (the K-th accepted CQE, K free) must come out as the K-th popped CQE with identical wr_id/op/status/len.            [13]
//       cq_count == accepted - popped (nothing lost, nothing duplicated), cq_valid == (cq_count != 0).
//   K4  Arbitration: at most one producer is accepted per cycle (p0_ready and p1_ready are never both high); a producer is only
//       accepted when it offers a CQE (ready implies valid) and a ready producer is never starved by the full flag while it
//       holds a reservation (see K2).
// Environment (assumptions, all justified by the neighbouring blocks):
//   E1  takes are guarded by the credit flags exactly as sf_rdma_wqe does: take_sq -> credits_ge1; take_rq -> (take_sq ? ge2 : ge1)
//       (that the wqe block honours this is asserted in fv_wqe, claim W5).
//   E2  producers push only against an EARLIER take: P0 (send queue) against a take_sq, P1 (receive queue) against a take_rq
//       (shadow counters pend0 / pend1 count takes not yet matched by an accepted push).
//   E3  host `cq_ready`, producer data and the valid pattern are otherwise free every cycle.
// Instance: CQ_DEPTH = 4 (the induction lemmas observe the 4 storage words through OBS wires, so DEPTH is fixed at 4).
// Reset in cycle 0 only.  VAC != 0: reachability witnesses (assertion MUST fail).
// =============================================================================
`default_nettype none
module fv_completion #(
  parameter KMAX = 3,          // BMC instances: the tagged ordinal K is assumed < KMAX (KMAX = 0: K is a free 32-bit value, k-induction)
  parameter VAC  = 0
) (
  input wire clk,
  input wire take_sq, input wire take_rq,
  input wire p0_valid, input wire [63:0] p0_wr_id, input wire [3:0] p0_op, input wire [3:0] p0_status, input wire [31:0] p0_len,
  input wire p1_valid, input wire [63:0] p1_wr_id, input wire [3:0] p1_op, input wire [3:0] p1_status, input wire [31:0] p1_len,
  input wire cq_ready
);
  localparam DEPTH = 4;
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  wire credits_ge1, credits_ge2, p0_ready, p1_ready, cq_valid, ev_overflow;
  wire [63:0] cq_wr_id; wire [3:0] cq_op, cq_status; wire [31:0] cq_len; wire [15:0] cq_qpn;
  wire [2:0] cq_count, credits;
  sf_rdma_completion #(.CQ_DEPTH(DEPTH)) dut (
    .clk(clk), .rst_n(rst_n), .local_qpn(16'h1234), .take_sq(take_sq), .take_rq(take_rq), .credits_ge1(credits_ge1), .credits_ge2(credits_ge2),
    .p0_valid(p0_valid), .p0_ready(p0_ready), .p0_wr_id(p0_wr_id), .p0_op(p0_op), .p0_status(p0_status), .p0_len(p0_len),
    .p1_valid(p1_valid), .p1_ready(p1_ready), .p1_wr_id(p1_wr_id), .p1_op(p1_op), .p1_status(p1_status), .p1_len(p1_len),
    .cq_valid(cq_valid), .cq_ready(cq_ready), .cq_wr_id(cq_wr_id), .cq_op(cq_op), .cq_status(cq_status), .cq_len(cq_len), .cq_qpn(cq_qpn),
    .cq_count(cq_count), .credits(credits), .ev_overflow(ev_overflow));
  // observation of internal state for the induction lemmas
  wire [2:0]  o_wp, o_rp;   // OBS o_wp dut.wp
                            // OBS o_rp dut.rp
  wire [63:0] o_wr0, o_wr1, o_wr2, o_wr3;   // OBS o_wr0 dut.m_wr[0]
  wire [3:0]  o_op0, o_op1, o_op2, o_op3;   // OBS o_wr1 dut.m_wr[1]
  wire [3:0]  o_st0, o_st1, o_st2, o_st3;   // OBS o_wr2 dut.m_wr[2]
  wire [31:0] o_ln0, o_ln1, o_ln2, o_ln3;   // OBS o_wr3 dut.m_wr[3]
                                            // OBS o_op0 dut.m_op[0]
                                            // OBS o_op1 dut.m_op[1]
                                            // OBS o_op2 dut.m_op[2]
                                            // OBS o_op3 dut.m_op[3]
                                            // OBS o_st0 dut.m_st[0]
                                            // OBS o_st1 dut.m_st[1]
                                            // OBS o_st2 dut.m_st[2]
                                            // OBS o_st3 dut.m_st[3]
                                            // OBS o_ln0 dut.m_ln[0]
                                            // OBS o_ln1 dut.m_ln[1]
                                            // OBS o_ln2 dut.m_ln[2]
                                            // OBS o_ln3 dut.m_ln[3]

  // ---------------------------------------------------------------- shadow
  wire acc0 = p0_valid && p0_ready;
  wire acc1 = p1_valid && p1_ready;
  wire acc  = acc0 || acc1;
  wire pop  = cq_valid && cq_ready;
  wire [63:0] a_wr = acc1 ? p1_wr_id  : p0_wr_id;
  wire [3:0]  a_op = acc1 ? p1_op     : p0_op;
  wire [3:0]  a_st = acc1 ? p1_status : p0_status;
  wire [31:0] a_ln = acc1 ? p1_len    : p0_len;

  reg [3:0]  pend0, pend1;          // takes (per producer side) not yet matched by an accepted push
  reg [31:0] npush, npop;           // accepted pushes / pops since reset
  reg [31:0] takes_sq_n, takes_rq_n;
  reg        tagged;                // the K-th accepted CQE has been recorded
  reg [63:0] t_wr; reg [3:0] t_op, t_st; reg [31:0] t_ln;
  (* anyconst *) reg [31:0] K;
  always @(posedge clk) if (KMAX != 0) assume(K < KMAX);

  // E1 / E2
  always @(posedge clk) if (!init) begin
    assume(!take_sq || credits_ge1);
    assume(!take_rq || (take_sq ? credits_ge2 : credits_ge1));
    assume(!p0_valid || pend0 != 4'd0);
    assume(!p1_valid || pend1 != 4'd0);
  end

  always @(posedge clk) begin
    if (init) begin
      pend0 <= 4'd0; pend1 <= 4'd0; npush <= 32'd0; npop <= 32'd0; tagged <= 1'b0;
      t_wr <= 64'd0; t_op <= 4'd0; t_st <= 4'd0; t_ln <= 32'd0;
    end else begin
      pend0 <= pend0 + {3'd0, take_sq} - {3'd0, acc0};
      pend1 <= pend1 + {3'd0, take_rq} - {3'd0, acc1};
      if (acc) begin
        npush <= npush + 32'd1;
        if (npush == K) begin tagged <= 1'b1; t_wr <= a_wr; t_op <= a_op; t_st <= a_st; t_ln <= a_ln; end
      end
      if (pop) npop <= npop + 32'd1;
    end
  end

  // storage word K mod 4 (induction lemma only)
  wire [1:0] ki = K[1:0];
  wire [63:0] s_wr = (ki == 2'd0) ? o_wr0 : (ki == 2'd1) ? o_wr1 : (ki == 2'd2) ? o_wr2 : o_wr3;
  wire [3:0]  s_op = (ki == 2'd0) ? o_op0 : (ki == 2'd1) ? o_op1 : (ki == 2'd2) ? o_op2 : o_op3;
  wire [3:0]  s_st = (ki == 2'd0) ? o_st0 : (ki == 2'd1) ? o_st1 : (ki == 2'd2) ? o_st2 : o_st3;
  wire [31:0] s_ln = (ki == 2'd0) ? o_ln0 : (ki == 2'd1) ? o_ln1 : (ki == 2'd2) ? o_ln2 : o_ln3;
  wire in_q = tagged && ((K - npop) < {29'd0, cq_count});   // the tagged CQE (K-th accepted) is currently stored (modular: no counter wrap issues)

  wire [6:0] sum7 = {4'd0, credits} + {4'd0, cq_count} + {3'd0, pend0} + {3'd0, pend1};

  always @(posedge clk) if (!init) begin
    if (VAC == 0) begin
      K1a: assert(sum7 == 7'd4);                                           // the credit invariant (no wrap: 7-bit sum)
      K1b: assert(credits <= 3'd4 && cq_count <= 3'd4);
      K2:  assert(!ev_overflow);
      K3a: assert(cq_valid == (cq_count != 3'd0));
      K3b: assert({29'd0, cq_count} == npush - npop);                       // nothing lost or duplicated
      K3c: assert(!(pop && tagged && npop == K) || (cq_wr_id == t_wr && cq_op == t_op && cq_status == t_st && cq_len == t_ln));
      K3d: assert(!(pop && npop == K) || tagged);                          // the K-th pop can only happen after the K-th push
      K4a: assert(!(p0_ready && p1_ready));
      K4b: assert((!p0_ready || p0_valid) && (!p1_ready || p1_valid));
      K4c: assert(!(p0_valid || p1_valid) || (p0_ready || p1_ready));       // an offering producer holding a reservation is always accepted
      // induction lemmas (state <-> shadow)
      L1: assert(o_wp == npush[2:0] && o_rp == npop[2:0]);
      L2: assert(!in_q || (s_wr == t_wr && s_op == t_op && s_st == t_st && s_ln == t_ln));
      L3: assert(!((K - npop) < {29'd0, cq_count}) || tagged);             // the K-th CQE, if stored, has been recorded
    end else begin
      case (VAC)
        1: assert(cq_count != 3'd4);                                  // the CQ can become full
        2: assert(credits != 3'd0);                                   // all credits can be reserved (post back-pressure, credits_ge1 low)
        3: assert(!(p0_valid && p1_valid && p0_ready != p1_ready));   // both producers offer, the arbiter serves exactly one
        4: assert(!(pop && acc));                                     // a pop and a push in the same cycle
        5: assert(!(pop && tagged && npop == K));                     // the tagged CQE is popped (K3c is exercised; use KMAX = 3)
      endcase
    end
  end
endmodule
