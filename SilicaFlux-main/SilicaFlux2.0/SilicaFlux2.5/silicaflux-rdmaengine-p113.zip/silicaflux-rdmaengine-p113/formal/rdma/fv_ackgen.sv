// =============================================================================
// Formal harness: sf_rdma_ackgen   (ACK / NAK generator of the responder)                         TRANSPORT_SPEC 9.3, 9.4, 11.2
//
// Regression guard for the "lost event" bug found by simulation: an ack_set / nak_set / replay_set / acc_ev raised in the SAME cycle as
// the frame push that consumes the flag of the same kind was dropped (the old code did "set" and then "clear" in program order).
// Claims (plain English):
//   A1  EVENTS ARE NEVER LOST: ack_set in cycle t  =>  the ACK flag is set in t+1 (also when an ACK frame is pushed in cycle t -- that
//       frame was built from the frontiers BEFORE the event);  nak_set => NAK flag (with the new code);  replay_set while resp_err =>
//       replay flag;  fatal_set while no fatal is pending => fatal pending with that code.  (Unless `clear` in t.)         [9.4, 11.2]
//   A2  A pending flag is cleared ONLY by a frame handshake that consumed it (or by `clear`), and a flag is raised only by its event
//       (or, for the ACK flag, by the acceptance report): a SEQ_ERR/RNR NAK frame consumes the NAK flag, a replay frame the replay
//       flag, an ACK frame the ACK flag.  A fatal NAK is not a flag-clearing frame.                                        [9.4]
//   A3  Priority of the frame offered to the transmitter:  fatal NAK > NAK > replay > ACK, and a frame is offered exactly when
//       something is pending (en && any pending <=> tx_valid) -- nothing pending is ever starved by `tx_valid` staying low.   [9.4]
//   A4  Frame contents: every ACK/NAK frame carries psn = commit_next (cpsn) and accept_next = epsn of the cycle it is pushed;
//       code 0 for an ACK, the stored NAK code otherwise.  A FATAL NAK is emitted only when cpsn == epsn, so it carries
//       psn == accept_next == epsn == the PSN of the failed request, and its code is a fatal code (3, 4, 5).               [9.4]
//   A5  After the fatal NAK (resp_err) every request-driven replay frame is the SAME NAK (same code as the fatal NAK); the fatal
//       NAK is emitted at most once (err_req pulses once) and the stored fatal code never changes while the fatal is pending. [11.2]
//   A6  Acceptance report: after acc_ev, if no frame is pushed for ACCEPT_ACK_DELAY cycles an ACK becomes pending.        [9.4]
// Environment: nak_code in {1 SEQ_ERR, 2 RNR}, fatal_code in {3, 4, 5} (the only codes the receive processor ever requests);
//   en, tx_ready, cpsn, epsn, clear and all event pulses are otherwise free every cycle; reset in cycle 0 only.
// Instance: ACCEPT_ACK_DELAY = 3.  The induction lemmas observe the internal flags through OBS wires.  VAC != 0: witnesses.
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none
module fv_ackgen #(
  parameter VAC = 0
) (
  input wire clk, input wire clear, input wire en,
  input wire [15:0] remote_qpn, input wire [15:0] epoch, input wire [23:0] cpsn, input wire [23:0] epsn,
  input wire acc_ev, input wire ack_set, input wire nak_set, input wire [3:0] nak_code, input wire fatal_set, input wire [3:0] fatal_code, input wire replay_set,
  input wire tx_ready
);
  localparam D = 3;
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  wire tx_valid, fatal_pend, resp_err, err_req, ev_tx_nak, ev_rnr_sent, idle;
  wire [271:0] tx_sh;
  sf_rdma_ackgen #(.ACCEPT_ACK_DELAY(D)) dut (
    .clk(clk), .rst_n(rst_n), .clear(clear), .en(en), .remote_qpn(remote_qpn), .epoch(epoch), .cpsn(cpsn), .epsn(epsn),
    .acc_ev(acc_ev), .ack_set(ack_set), .nak_set(nak_set), .nak_code(nak_code), .fatal_set(fatal_set), .fatal_code(fatal_code), .replay_set(replay_set),
    .tx_valid(tx_valid), .tx_ready(tx_ready), .tx_sh(tx_sh), .fatal_pend(fatal_pend), .resp_err(resp_err), .err_req(err_req),
    .ev_tx_nak(ev_tx_nak), .ev_rnr_sent(ev_rnr_sent), .idle(idle));
  wire        o_ack, o_nak, o_rep, o_acc;   // OBS o_ack dut.ack_pend
                                            // OBS o_nak dut.nak_pend
                                            // OBS o_rep dut.rep_pend
                                            // OBS o_acc dut.acc_pend
  wire [3:0]  o_nakc, o_fatc;               // OBS o_nakc dut.nak_c
                                            // OBS o_fatc dut.fat_c
  wire [31:0] o_dly;                        // OBS o_dly dut.dly

  always @(posedge clk) if (!init) begin
    assume(nak_code == 4'd1 || nak_code == 4'd2);
    assume(fatal_code >= 4'd3 && fatal_code <= 4'd5);
  end

  // ---------------------------------------------------------------- decode of the frame offered to the transmitter
  wire [7:0]  f_opc  = `SFR_H_OPC(tx_sh);
  wire [7:0]  f_code = `SFR_H_CODE(tx_sh);
  wire [23:0] f_psn  = `SFR_H_PSN(tx_sh);
  wire [23:0] f_acc  = `SFR_H_ACCEPT(tx_sh);
  wire        hs     = tx_valid && tx_ready;
  wire        f_isack = (f_opc == `SFR_OP_ACK) && (f_code == 8'd0);
  wire        f_isnak = (f_opc == `SFR_OP_NAK);
  wire        f_nakcl = f_isnak && (f_code == 8'd1 || f_code == 8'd2);      // SEQ_ERR / RNR class (request-driven NAK flag)
  wire        f_fatcl = f_isnak && (f_code >= 8'd3 && f_code <= 8'd5);      // INV_REQ / REM_ACCESS / REM_OP: fatal frame or replay of it
  // the frame the spec says must be offered: priority fatal > NAK > replay > ACK
  wire fatal_ready_s = fatal_pend && !resp_err && (cpsn == epsn);
  wire pending_s     = fatal_ready_s || o_nak || (o_rep && resp_err) || o_ack;

  // ---------------------------------------------------------------- shadow
  reg        clear_q, ack_set_q, nak_set_q, rep_ev_q, fat_ev_q, hs_q, resp_err_q, fatpend_q, errreq_q, isack_q, nakcl_q, fatcl_q, exp_q;
  reg        ackp_q, nakp_q, repp_q;
  reg [3:0]  nak_code_q, fatal_code_q, fatc_q, f_code_q;
  reg        fcode_v;  reg [3:0] fcode_s;           // code of the fatal NAK frame, once emitted
  reg        wait_s;   reg [31:0] cnt_s;            // acceptance-report shadow (cycles since acc_ev, while no frame is pushed)
  wire       exp_now = wait_s && !hs && (cnt_s + 32'd1 >= D);

  always @(posedge clk) begin
    if (init) begin
      clear_q <= 1'b0; ack_set_q <= 1'b0; nak_set_q <= 1'b0; rep_ev_q <= 1'b0; fat_ev_q <= 1'b0; hs_q <= 1'b0; resp_err_q <= 1'b0; fatpend_q <= 1'b0; errreq_q <= 1'b0;
      isack_q <= 1'b0; nakcl_q <= 1'b0; fatcl_q <= 1'b0; exp_q <= 1'b0; ackp_q <= 1'b0; nakp_q <= 1'b0; repp_q <= 1'b0; nak_code_q <= 4'd0; fatal_code_q <= 4'd0; fatc_q <= 4'd0; f_code_q <= 4'd0;
      fcode_v <= 1'b0; fcode_s <= 4'd0; wait_s <= 1'b0; cnt_s <= 32'd0;
    end else begin
      clear_q <= clear; ack_set_q <= ack_set; nak_set_q <= nak_set; rep_ev_q <= replay_set && resp_err; fat_ev_q <= fatal_set && !fatal_pend;
      hs_q <= hs; resp_err_q <= resp_err; fatpend_q <= fatal_pend; errreq_q <= err_req; isack_q <= f_isack; nakcl_q <= f_nakcl; fatcl_q <= f_fatcl;
      exp_q <= exp_now && !clear; ackp_q <= o_ack; nakp_q <= o_nak; repp_q <= o_rep; nak_code_q <= nak_code; fatal_code_q <= fatal_code; fatc_q <= o_fatc; f_code_q <= f_code[3:0];
      if (clear) begin fcode_v <= 1'b0; wait_s <= 1'b0; cnt_s <= 32'd0; end
      else begin
        if (err_req) begin fcode_v <= 1'b1; fcode_s <= f_code[3:0]; end
        // acceptance report shadow: armed by acc_ev; any pushed frame (or the report itself) restarts the silence count
        wait_s <= acc_ev ? 1'b1 : ((hs || exp_now) ? 1'b0 : wait_s);
        cnt_s  <= (hs || exp_now) ? 32'd0 : (wait_s ? cnt_s + 32'd1 : 32'd0);
      end
    end
  end

  always @(posedge clk) if (!init) begin
    if (VAC == 0) begin
      // A1
      A1a: assert(!ack_set_q  || clear_q || o_ack);
      A1b: assert(!nak_set_q  || clear_q || (o_nak && o_nakc == nak_code_q));
      A1c: assert(!rep_ev_q   || clear_q || o_rep);
      A1d: assert(!fat_ev_q   || clear_q || (fatal_pend && o_fatc == fatal_code_q));
      // A2
      A2a: assert(!(ackp_q && !o_ack) || clear_q || (hs_q && isack_q));
      A2b: assert(!(nakp_q && !o_nak) || clear_q || (hs_q && nakcl_q));
      A2c: assert(!(repp_q && !o_rep) || clear_q || (hs_q && fatcl_q && resp_err_q));
      A2d: assert(!(!ackp_q && o_ack) || ack_set_q || exp_q);
      A2e: assert(!(!nakp_q && o_nak) || nak_set_q);
      A2f: assert(!(!repp_q && o_rep) || rep_ev_q);
      // A3
      A3a: assert(tx_valid == (en && pending_s));
      A3b: assert(!tx_valid || !fatal_ready_s || (f_fatcl && f_code[3:0] == o_fatc));
      A3c: assert(!tx_valid || fatal_ready_s || !o_nak || (f_nakcl && f_code[3:0] == o_nakc));
      A3d: assert(!tx_valid || fatal_ready_s || o_nak || !(o_rep && resp_err) || (f_fatcl && f_code[3:0] == o_fatc));
      A3e: assert(!tx_valid || fatal_ready_s || o_nak || (o_rep && resp_err) || f_isack);
      // A4
      A4a: assert(!tx_valid || (f_psn == cpsn && f_acc == epsn));
      A4b: assert(!err_req || (cpsn == epsn && f_psn == epsn && f_acc == epsn && f_fatcl));
      A4c: assert(!tx_valid || (f_isack || f_isnak));
      // A5
      A5a: assert(!(resp_err && !resp_err_q) || errreq_q);                   // resp_err rises only with the fatal frame handshake
      A5b: assert(!err_req || !resp_err);                                    // the fatal NAK is emitted at most once
      A5c: assert(!(fatpend_q && fatal_pend && !clear_q) || o_fatc == fatc_q);   // stored fatal code never changes while pending
      A5d: assert(!resp_err || (fcode_v && fcode_s == o_fatc));
      A5e: assert(!(tx_valid && resp_err && !o_nak && o_rep) || (f_fatcl && f_code[3:0] == fcode_s));
      // A6
      A6a: assert(!exp_q || o_ack);
      // induction lemmas (state <-> shadow)
      L1: assert(!resp_err || fatal_pend);
      L2: assert(wait_s == o_acc);
      L3: assert(!o_acc || o_dly == cnt_s);
      L4: assert(!o_acc || o_dly < D);
      L5: assert(o_acc || o_dly == 32'd0);
      L6: assert(!(fcode_v) || resp_err);
      L8: assert(!fatal_pend || (o_fatc >= 4'd3 && o_fatc <= 4'd5));
      L9: assert(o_nakc == 4'd1 || o_nakc == 4'd2 || o_nakc == 4'd0);
      L10: assert(!o_nak || o_nakc == 4'd1 || o_nakc == 4'd2);
    end else begin
      case (VAC)
        1: assert(!(ack_set && hs && f_isack));                           // the old bug's situation: ack_set in the cycle an ACK frame is pushed
        2: assert(!(nak_set && hs && f_nakcl));                          // nak_set while a NAK frame is pushed
        3: assert(!(replay_set && resp_err && hs && f_fatcl));          // replay_set while a replay frame is pushed
        4: assert(!err_req);                                             // the fatal NAK is emitted
        5: assert(!(tx_valid && resp_err && !o_nak && o_rep));           // a replay frame is offered after the fatal NAK
        6: assert(!exp_q);                                               // the acceptance report makes an ACK pending
        7: assert(!(acc_ev && hs));                                      // acceptance event in the cycle a frame is pushed
        8: assert(!(o_nak && o_ack && tx_valid && !fatal_ready_s));      // NAK and ACK pending together: the NAK goes first
        9: assert(!(fatal_pend && !resp_err && cpsn != epsn && en));     // a fatal NAK is held back until cpsn == epsn
        10: assert(!(acc_ev && o_acc && !hs));                           // a second acceptance event while one is pending
      endcase
    end
  end
endmodule
