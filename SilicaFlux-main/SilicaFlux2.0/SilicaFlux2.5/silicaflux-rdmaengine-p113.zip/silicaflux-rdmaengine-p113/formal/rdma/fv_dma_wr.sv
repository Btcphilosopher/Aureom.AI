// =============================================================================
// Formal harness: sf_rdma_dma_wr   (payload stream -> memory write port, DW = 32)           TRANSPORT_SPEC 8.5, 9.2, 10 (2, 3, 4)
//
// Claims (plain English):
//   D1  EXACT WRITE SET.  For a WRITE command that passed the guard, the memory writes it causes touch EXACTLY the bytes
//       [pa, pa+len): proved for a FREE command ordinal KC and a FREE byte address TA -- the word that contains TA is written exactly
//       once, at the right word address, with strobe[TA%4] == (TA in [pa, pa+len)), and the data byte equals the payload byte at
//       offset TA-pa of that command's payload stream.  (All other lanes / addresses are covered by the freedom of TA, all commands by KC.)
//   D2  NO WRITE WITHOUT AUTHORITY.  No memory write is ever issued while a DISCARD command (a rejected / duplicate frame, or a
//       command converted to DISCARD because the registry guard failed) is being processed; the number of write words issued never
//       exceeds the number of words of the guard-passed WRITE commands accepted so far.                           [10.3 "rejected request leaves no memory trace"]
//   D3  A command that fails the guard is converted to DISCARD and `viol` pulses exactly one cycle after its acceptance (and only then). [8.5]
//   D4  COMMIT.  `done_valid` pulses once per WRITE command AND once per guard-CONVERTED command (review fix F-09: a converted command reports
//       done with done_err = 1, never having touched memory), in order, and only after the memory has acknowledged ALL words of every earlier
//       command (and of the command itself, for a WRITE; checked for KC); done_err reports an acknowledgement error of any word;
//       when the engine is idle every accepted command has been reported (no tag is ever left pending).             [9.2 "committed", 8.5]
//   D5  At most MEM_WR_OUT writes are outstanding (issued, not yet acknowledged); the payload beats consumed never exceed the beats
//       of the accepted commands (ceil(len/4) each); mwr_ctx is the command's context.                              [12, 9.2]
// Environment (assumptions): the memory acknowledges in order, one ack per accepted write, never without an outstanding write;
//   ready / ack timing / ack_err / payload data are arbitrary; the registry guard is replaced by a symbolic window [LO, HI) fixed for
//   the run (g_ok == pa >= LO && pa+len <= HI); commands have 1 <= len <= LMAX (the receive processor never issues len = 0);
//   `clear` (QP reset flush) is NOT exercised here (clear = 0); reset in cycle 0 only.
// Instance: DW = 32 (B = 4), PA_W = 6, MEM_WR_OUT = 2, CMD_Q = 2, LMAX = 9 (up to 4 words incl. misalignment).  BMC from reset, KC < KCMAX.
// VAC != 0: reachability witnesses (the assertion MUST fail).
// =============================================================================
`default_nettype none
module fv_dma_wr #(
  parameter KCMAX = 3,
  parameter LMAX  = 9,
  parameter VAC   = 0
) (
  input wire clk,
  input wire cmd_valid, input wire cmd_discard, input wire [5:0] cmd_pa, input wire [15:0] cmd_len, input wire cmd_rid, input wire cmd_ctx,
  input wire pl_valid, input wire [31:0] pl_data,
  input wire mwr_ready, input wire mwr_ack_valid, input wire mwr_ack_err
);
  localparam PA_W = 6, MEMO = 2;
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  (* anyconst *) reg [PA_W-1:0] LO;
  (* anyconst *) reg [PA_W:0]   HI;
  (* anyconst *) reg [PA_W-1:0] TA;
  (* anyconst *) reg [7:0]      KC;
  always @(posedge clk) begin assume(KC < KCMAX); assume({1'b0, LO} < HI && HI <= 7'd64); end   // the window lies inside the 2^PA_W physical space (registry ERR_RANGE at registration)

  wire cmd_ready, viol, pl_ready, mwr_valid, done_valid, done_err, idle;
  wire [0:0] g_rid; wire [PA_W-1:0] g_pa; wire [15:0] g_len;
  wire [PA_W-1:0] mwr_addr; wire [31:0] mwr_data; wire [3:0] mwr_strb; wire [0:0] mwr_ctx;
  wire [2:0] bytes_n;
  wire [16:0] g_end = {11'd0, g_pa} + {1'b0, g_len};
  wire g_ok = (g_pa >= LO) && (g_end <= {10'd0, HI});
  sf_rdma_dma_wr #(.DW(32), .PA_W(PA_W), .RID_W(1), .CTX_W(1), .MEM_WR_OUT(MEMO), .CMD_Q(2)) dut (
    .clk(clk), .rst_n(rst_n), .clear(1'b0),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_discard(cmd_discard), .cmd_pa(cmd_pa), .cmd_len(cmd_len), .cmd_rid(cmd_rid), .cmd_ctx(cmd_ctx), .viol(viol),
    .g_rid(g_rid), .g_pa(g_pa), .g_len(g_len), .g_ok(g_ok),
    .pl_valid(pl_valid), .pl_ready(pl_ready), .pl_data(pl_data),
    .mwr_valid(mwr_valid), .mwr_ready(mwr_ready), .mwr_addr(mwr_addr), .mwr_data(mwr_data), .mwr_strb(mwr_strb), .mwr_ctx(mwr_ctx),
    .mwr_ack_valid(mwr_ack_valid), .mwr_ack_err(mwr_ack_err), .done_valid(done_valid), .done_err(done_err), .idle(idle), .bytes_n(bytes_n));
  wire o_act, o_disc;   // OBS o_act dut.act
                        // OBS o_disc dut.disc

  // ---------------------------------------------------------------- shadow
  wire cmd_take = cmd_valid && cmd_ready;
  wire is_wr    = cmd_take && !cmd_discard && g_ok;          // a WRITE that passed the guard
  wire conv     = cmd_take && !cmd_discard && !g_ok;         // converted to DISCARD
  wire pl_take  = pl_valid && pl_ready;
  wire wr_hs    = mwr_valid && mwr_ready;
  function [7:0] nwords(input [PA_W-1:0] pa, input [15:0] len); nwords = (({6'd0, pa[1:0]} + len[7:0] + 8'd3) >> 2); endfunction
  function [7:0] nbeats(input [15:0] len); nbeats = ((len[7:0] + 8'd3) >> 2); endfunction

  reg [7:0] ncmd, nwcmd, wsum, psum, wcnt, acks, pcnt, ndone;     // accepted commands / WRITE commands / words authorised / beats commanded / write handshakes / acks / beats consumed / done pulses
  reg        conv_q;
  // the tagged command KC
  reg        k_seen, k_wr, k_conv; reg [PA_W-1:0] k_pa; reg [15:0] k_len; reg k_ctx; reg [7:0] k_wstart, k_pstart, k_widx; reg [7:0] k_words;
  reg        tb_v; reg [7:0] tbyte; reg k_err; reg k_done_seen;
  wire [PA_W:0] k_off = {1'b0, TA} - {1'b0, k_pa};                 // offset of TA in the command
  wire          k_inr = (TA >= k_pa) && ({2'b0, TA} < {2'b0, k_pa} + {2'b0, k_len[7:0]});
  wire [7:0]    k_wbeat = {2'd0, k_off[PA_W:2]};
  wire [31:0]   k_wi = wcnt - k_wstart;                             // index of the current write word inside KC
  wire          k_inw = k_seen && k_wr && (wcnt >= k_wstart) && (wcnt < k_wstart + (k_words));
  wire [PA_W-1:0] k_wordaddr = {k_pa[PA_W-1:2], 2'b00} + {k_wi[PA_W-3:0], 2'b00};
  wire          k_isw = (mwr_addr[PA_W-1:2] == TA[PA_W-1:2]);
  wire [7:0]    outst = wcnt[7:0] - acks[7:0];

  always @(posedge clk) if (!init) begin
    assume(cmd_len >= 16'd1 && cmd_len <= LMAX);
    assume(!mwr_ack_valid || outst != 8'd0);
  end

  always @(posedge clk) begin
    if (init) begin
      ncmd <= 0; nwcmd <= 0; wsum <= 0; psum <= 0; wcnt <= 0; acks <= 0; pcnt <= 0; ndone <= 0; conv_q <= 1'b0;
      k_seen <= 1'b0; k_wr <= 1'b0; k_conv <= 1'b0; k_pa <= 0; k_len <= 0; k_ctx <= 1'b0; k_wstart <= 0; k_pstart <= 0; k_widx <= 0; k_words <= 0; tb_v <= 1'b0; tbyte <= 8'd0; k_err <= 1'b0; k_done_seen <= 1'b0;
    end else begin
      conv_q <= conv;
      if (cmd_take) begin
        ncmd <= ncmd + 8'd1;
        psum <= psum + (nbeats(cmd_len));
        if (is_wr) wsum <= wsum + (nwords(cmd_pa, cmd_len));
        if (is_wr || conv) nwcmd <= nwcmd + 8'd1;                         // commands that owe a done pulse
        if (ncmd == KC) begin
          k_seen <= 1'b1; k_wr <= is_wr; k_conv <= conv; k_pa <= cmd_pa; k_len <= cmd_len; k_ctx <= cmd_ctx; k_wstart <= wsum; k_pstart <= psum; k_widx <= nwcmd; k_words <= nwords(cmd_pa, cmd_len);
        end
      end
      if (pl_take) pcnt <= pcnt + 8'd1;
      if (wr_hs)   wcnt <= wcnt + 8'd1;
      if (mwr_ack_valid) begin
        acks <= acks + 8'd1;
        if (k_seen && k_wr && acks >= k_wstart && acks < k_wstart + (k_words) && mwr_ack_err) k_err <= 1'b1;
      end
      if (done_valid) ndone <= ndone + 8'd1;
      // capture the tagged payload byte when its beat is consumed
      if (k_seen && k_wr && k_inr && pl_take && pcnt == k_pstart + (k_wbeat)) begin tb_v <= 1'b1; tbyte <= pl_data[8*k_off[1:0] +: 8]; end
      if (done_valid && k_seen && k_wr && ndone == k_widx) k_done_seen <= 1'b1;
    end
  end

  always @(posedge clk) if (!init) begin
    if (VAC == 0) begin
      // D1 : exact write set for the tagged command / address
      D1a: assert(!(wr_hs && k_inw) || mwr_addr == k_wordaddr);
      D1b: assert(!(wr_hs && k_inw && k_isw) || (mwr_strb[TA[1:0]] == k_inr));
      D1c: assert(!(wr_hs && k_inw && k_isw && k_inr) || (tb_v && mwr_data[8*TA[1:0] +: 8] == tbyte));
      D1d: assert(!(wr_hs && k_inw) || mwr_ctx == k_ctx);
      D1e: assert(!(wr_hs && k_inw) || mwr_strb != 4'd0);
      // D2 : no write without authority
      D2a: assert(!(mwr_valid && o_act && o_disc));
      D2b: assert(wcnt <= wsum);
      // D3
      D3a: assert(viol == conv_q);
      // D4
      D4a: assert(ndone <= nwcmd);
      D4c: assert(!(done_valid && k_seen && k_conv && ndone == k_widx) || (acks >= k_wstart && done_err));      // a converted command: done with error, after every earlier write was acknowledged
      D4d: assert(!(idle && !done_valid) || ndone == nwcmd);                                                  // idle: no completion is owed
      D4b: assert(!(done_valid && k_seen && k_wr && ndone == k_widx) || (acks >= k_wstart + (k_words) && done_err == k_err));
      // D5
      D5a: assert(outst <= MEMO);
      D5b: assert(pcnt <= psum);
    end else begin
      case (VAC)
        1: assert(!(done_valid && k_seen && k_wr && ndone == k_widx));           // the tagged WRITE commits (D4b exercised)
        2: assert(!(wr_hs && k_inw && k_wi == 8'd1));                           // a second word of the tagged command is written (multi-word command)
        3: assert(!viol);                                                        // a guard failure converts a command and raises viol
        4: assert(!(o_act && o_disc && pl_take));                                // a DISCARD command consumes payload beats
        5: assert(!(outst == MEMO));                                             // the outstanding-write limit is reached
        6: assert(!(wr_hs && k_inw && k_isw && k_inr && k_pa[1:0] != 2'd0));    // an unaligned tagged byte is written (D1c exercised, misaligned start)
        7: assert(!(wr_hs && k_inw && k_isw && !k_inr));                         // the tagged address lies outside the command but inside a written word (strobe must be 0)
        8: assert(!(done_valid && done_err));                                    // an acknowledgement error reaches done_err
        9: assert(!(done_valid && k_seen && k_conv && ndone == k_widx));         // the tagged command was converted by the guard and still reports done
      endcase
    end
  end
endmodule
