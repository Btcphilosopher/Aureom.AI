// =============================================================================
// Formal harness: sf_rdma_dma_rd   (local memory -> payload stream, DW = 32)                 TRANSPORT_SPEC 7.1-7.3, 8.5, 12.6
//
// Claims (plain English):
//   P1  Every memory read word address belongs to the commanded range: request number q of a guard-passed command is the word at
//       (pa & ~3) + 4*(q - first), i.e. inside [pa&~3, (pa+len-1)&~3] -- proved for a FREE command ordinal KC (all commands by freedom of
//       KC) -- and no more reads are issued than the guard-passed commands need (sum of ceil(((pa&3)+len)/4) words).
//   P2  The payload stream of a command carries EXACTLY the commanded bytes in order: beat j has keep = ones for the bytes
//       4j .. min(4j+3, len-1), every kept lane equals memory[pa + 4j + lane] (memory = an injective abstract function of the byte
//       address, delivered in order with arbitrary latency), `last` only on the final beat (j == ceil(len/4)-1), `port` is the
//       command's port, ceil(len/4) beats per command and never more beats than the guard-passed commands need.
//   P3  A command that FAILS the guard issues NO memory read and no payload beat at all and `viol` pulses exactly one cycle after its
//       acceptance (and only then).                                                                                       [8.5]
//   P4  At most MEM_OUT reads are outstanding at the memory (responses cannot be back-pressured: the response FIFO never overflows);
//       no internal FIFO (command, info, response) ever overflows or underflows.                                       [12.6, 8.5]
//   P5  done_valid pulses exactly once per guard-passed command, in order, the cycle after its last beat (with the command's
//       port); done_err is the OR of the memory error flags of the command's words; `pl_err` (valid with pl_last) is the same OR (review fix:
//       the consumer is told the payload is garbage).
// Environment (assumptions): memory answers in order, one response per accepted request, never without an outstanding request,
//   arbitrary latency / ready / error flags; abstract memory content byte(x) = injective function of x; the registry guard is a
//   symbolic window [LO, HI) fixed for the run (g_ok == pa >= LO && pa+len <= HI, HI <= 2^PA_W); 1 <= len <= LMAX; `clear` is not
//   exercised (clear = 0); the payload consumer always accepts (the engine's contract: space is reserved before the command); reset
//   in cycle 0 only.
// Instance: DW = 32 (B = 4), PA_W = 6, MEM_OUT = 2, CMD_Q = 2, LMAX = 9.  BMC from reset, KC < KCMAX.   VAC != 0: witnesses.
// =============================================================================
`default_nettype none
module fv_dma_rd #(
  parameter KCMAX = 3,
  parameter LMAX  = 9,
  parameter VAC   = 0
) (
  input wire clk,
  input wire cmd_valid, input wire [5:0] cmd_pa, input wire [15:0] cmd_len, input wire cmd_port, input wire cmd_rid, input wire cmd_ctx,
  input wire mrd_ready, input wire mrd_rsp_valid, input wire mrd_rsp_err
);
  localparam PA_W = 6, MEMO = 2;
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  (* anyconst *) reg [PA_W-1:0] LO;
  (* anyconst *) reg [PA_W:0]   HI;
  (* anyconst *) reg [7:0]      KC;
  always @(posedge clk) begin assume(KC < KCMAX); assume({1'b0, LO} < HI && HI <= 7'd64); end

  // abstract memory: byte at byte address x
  function [7:0] bf(input [PA_W-1:0] x); bf = {2'b10, x} ^ 8'h5A; endfunction
  function [31:0] wordf(input [PA_W-1:0] a); wordf = {bf(a + 6'd3), bf(a + 6'd2), bf(a + 6'd1), bf(a)}; endfunction

  wire cmd_ready, viol, mrd_valid, pl_valid, pl_last, pl_port, pl_err, done_valid, done_port, done_err, idle;
  wire [0:0] g_rid; wire [PA_W-1:0] g_pa; wire [15:0] g_len;
  wire [PA_W-1:0] mrd_addr; wire [0:0] mrd_ctx; wire [31:0] pl_data; wire [3:0] pl_keep; wire [2:0] bytes_n;
  wire [31:0] mrd_rsp_data;
  wire [16:0] g_end = {11'd0, g_pa} + {1'b0, g_len};
  wire g_ok = (g_pa >= LO) && (g_end <= {10'd0, HI});
  sf_rdma_dma_rd #(.DW(32), .PA_W(PA_W), .RID_W(1), .CTX_W(1), .MEM_OUT(MEMO), .CMD_Q(2)) dut (
    .clk(clk), .rst_n(rst_n), .clear(1'b0),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_pa(cmd_pa), .cmd_len(cmd_len), .cmd_port(cmd_port), .cmd_rid(cmd_rid), .cmd_ctx(cmd_ctx), .viol(viol),
    .g_rid(g_rid), .g_pa(g_pa), .g_len(g_len), .g_ok(g_ok),
    .mrd_valid(mrd_valid), .mrd_ready(mrd_ready), .mrd_addr(mrd_addr), .mrd_ctx(mrd_ctx), .mrd_rsp_valid(mrd_rsp_valid), .mrd_rsp_data(mrd_rsp_data), .mrd_rsp_err(mrd_rsp_err),
    .pl_valid(pl_valid), .pl_data(pl_data), .pl_keep(pl_keep), .pl_last(pl_last), .pl_port(pl_port), .pl_err(pl_err),
    .done_valid(done_valid), .done_port(done_port), .done_err(done_err), .idle(idle), .bytes_n(bytes_n));
  wire o_cq_ovf, o_cq_unf, o_if_ovf, o_if_unf, o_rf_ovf, o_rf_unf;   // OBS o_cq_ovf dut.u_cq.ovf
                                                                     // OBS o_cq_unf dut.u_cq.unf
                                                                     // OBS o_if_ovf dut.u_if.ovf
                                                                     // OBS o_if_unf dut.u_if.unf
                                                                     // OBS o_rf_ovf dut.u_rf.ovf
                                                                     // OBS o_rf_unf dut.u_rf.unf

  // ---------------------------------------------------------------- memory model: in-order responses with the content of the oldest request
  wire rd_hs  = mrd_valid && mrd_ready;
  reg [PA_W-1:0] rq [0:3];                                    // outstanding request addresses (depth 4 > MEM_OUT so a violation is observable)
  reg [2:0] rq_wp, rq_rp;
  wire [2:0] rq_cnt = rq_wp - rq_rp;
  assign mrd_rsp_data = wordf(rq[rq_rp[1:0]]);
  always @(posedge clk) if (!init) begin
    assume(cmd_len >= 16'd1 && cmd_len <= LMAX);
    assume(!mrd_rsp_valid || rq_cnt != 3'd0);
  end
  always @(posedge clk) begin
    if (init) begin rq_wp <= 3'd0; rq_rp <= 3'd0; end
    else begin
      if (rd_hs) begin rq[rq_wp[1:0]] <= mrd_addr; rq_wp <= rq_wp + 3'd1; end
      if (mrd_rsp_valid) rq_rp <= rq_rp + 3'd1;
    end
  end

  // ---------------------------------------------------------------- shadow
  wire cmd_take = cmd_valid && cmd_ready;
  wire is_ok    = cmd_take && g_ok;
  wire conv     = cmd_take && !g_ok;
  function [7:0] nwords(input [PA_W-1:0] pa, input [15:0] len); nwords = (({6'd0, pa[1:0]} + len[7:0] + 8'd3) >> 2); endfunction
  function [7:0] nbeats(input [15:0] len); nbeats = ((len[7:0] + 8'd3) >> 2); endfunction

  reg [7:0] ncmd, nok, qsum, bsum, qcnt, rcnt, bcnt, ndone;
  reg        conv_q, last_q, lastport_q;
  reg        k_seen, k_ok; reg [PA_W-1:0] k_pa; reg [15:0] k_len; reg k_port; reg [7:0] k_qstart, k_bstart, k_idx; reg [7:0] k_words, k_beats; reg k_err;
  wire pl_hs = pl_valid;                                       // the consumer always accepts
  wire [31:0] k_q = qcnt - k_qstart;
  wire [31:0] k_j = bcnt - k_bstart;
  wire        k_inq = k_seen && k_ok && (qcnt >= k_qstart) && (qcnt < k_qstart + (k_words));
  wire        k_inb = k_seen && k_ok && (bcnt >= k_bstart) && (bcnt < k_bstart + (k_beats));
  wire [PA_W-1:0] k_bpa = k_pa + {k_j[PA_W-3:0], 2'b00};      // byte address of lane 0 of beat j (pa + 4j)
  wire [7:0]  k_rem = k_len[7:0] - {k_j[5:0], 2'b00};          // bytes left from beat j on
  reg [3:0]   exp_keep;
  always @* begin
    exp_keep = 4'd0;
    if (k_rem >= 8'd4) exp_keep = 4'b1111;
    else if (k_rem == 8'd3) exp_keep = 4'b0111;
    else if (k_rem == 8'd2) exp_keep = 4'b0011;
    else if (k_rem == 8'd1) exp_keep = 4'b0001;
  end
  wire        lastbeat = (k_j + 8'd1 == (k_beats));
  wire [7:0]  rsp_n = rcnt[7:0];

  always @(posedge clk) begin
    if (init) begin
      ncmd <= 0; nok <= 0; qsum <= 0; bsum <= 0; qcnt <= 0; rcnt <= 0; bcnt <= 0; ndone <= 0; conv_q <= 1'b0; last_q <= 1'b0; lastport_q <= 1'b0;
      k_seen <= 1'b0; k_ok <= 1'b0; k_pa <= 0; k_len <= 0; k_port <= 1'b0; k_qstart <= 0; k_bstart <= 0; k_idx <= 0; k_words <= 0; k_beats <= 0; k_err <= 1'b0;
    end else begin
      conv_q <= conv;
      if (cmd_take) begin
        ncmd <= ncmd + 8'd1;
        if (is_ok) begin qsum <= qsum + (nwords(cmd_pa, cmd_len)); bsum <= bsum + (nbeats(cmd_len)); nok <= nok + 8'd1; end
        if (ncmd == KC) begin
          k_seen <= 1'b1; k_ok <= g_ok; k_pa <= cmd_pa; k_len <= cmd_len; k_port <= cmd_port; k_qstart <= qsum; k_bstart <= bsum; k_idx <= nok;
          k_words <= nwords(cmd_pa, cmd_len); k_beats <= nbeats(cmd_len);
        end
      end
      if (rd_hs) qcnt <= qcnt + 8'd1;
      if (mrd_rsp_valid) begin
        rcnt <= rcnt + 8'd1;
        if (k_seen && k_ok && rcnt >= k_qstart && rcnt < k_qstart + (k_words) && mrd_rsp_err) k_err <= 1'b1;
      end
      if (pl_hs) bcnt <= bcnt + 8'd1;
      last_q <= pl_valid && pl_last; lastport_q <= pl_port;
      if (done_valid) ndone <= ndone + 8'd1;
    end
  end

  always @(posedge clk) if (!init) begin
    if (VAC == 0) begin
      // P1
      P1a: assert(!(rd_hs && k_inq) || mrd_addr == {k_pa[PA_W-1:2], 2'b00} + {k_q[PA_W-3:0], 2'b00});
      P1b: assert(qcnt <= qsum);
      // P2
      P2a: assert(!(pl_valid && k_inb) || pl_keep == exp_keep);
      P2b: assert(!(pl_valid && k_inb) || pl_last == lastbeat);
      P2c: assert(!(pl_valid && k_inb) || pl_port == k_port);
      P2d: assert(!(pl_valid && k_inb) || ((!pl_keep[0] || pl_data[7:0]   == bf(k_bpa)) && (!pl_keep[1] || pl_data[15:8]  == bf(k_bpa + 6'd1)) &&
                                          (!pl_keep[2] || pl_data[23:16] == bf(k_bpa + 6'd2)) && (!pl_keep[3] || pl_data[31:24] == bf(k_bpa + 6'd3))));
      P2e: assert(bcnt <= bsum);
      // P3
      P3a: assert(viol == conv_q);
      // P4
      P4a: assert(rq_cnt <= MEMO);
      P4b: assert(!o_cq_ovf && !o_cq_unf && !o_if_ovf && !o_if_unf && !o_rf_ovf && !o_rf_unf);
      // P5
      P5a: assert(done_valid == last_q);
      P5b: assert(!done_valid || done_port == lastport_q);
      P5c: assert(ndone <= nok);
      P5e: assert(!(pl_valid && pl_last && k_inb) || pl_err == k_err);
      P5d: assert(!(done_valid && k_seen && k_ok && ndone == k_idx) || (done_err == k_err && rcnt >= k_qstart + (k_words)));
    end else begin
      case (VAC)
        1: assert(!(done_valid && k_seen && k_ok && ndone == k_idx));            // the tagged command completes
        2: assert(!(rd_hs && k_inq && k_q == 8'd1));                            // a second word of the tagged command is read (multi-word command)
        3: assert(!viol);                                                        // a guard failure raises viol
        4: assert(!(rq_cnt == MEMO));                                            // the outstanding-read limit is reached
        5: assert(!(pl_valid && k_inb && lastbeat && k_len[1:0] != 2'd0));       // a partial last beat (keep != 1111) is emitted
        6: assert(!(pl_valid && k_inb && k_pa[1:0] != 2'd0 && k_len > 16'd4));   // a misaligned multi-beat command (realignment exercised)
        7: assert(!(done_valid && done_err));                                    // a memory error reaches done_err
      endcase
    end
  end
endmodule
