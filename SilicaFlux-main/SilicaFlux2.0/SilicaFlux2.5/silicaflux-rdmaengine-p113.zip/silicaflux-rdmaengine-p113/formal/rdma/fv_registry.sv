// =============================================================================
// Formal harness: sf_rdma_memory_registry   (the ONLY block that turns (key, PD, VA, len) into a physical address)
//                                                                                              TRANSPORT_SPEC 8.1 - 8.5, 14
// An INDEPENDENT SHADOW MODEL of the table lives in this file: it is driven by the same symbolic configuration / check / release
// commands, uses wide (129 / 130-bit) arithmetic and an OR-select instead of the RTL's priority chain, and is compared with the RTL
// through its PORTS every cycle (plus, for the induction lemmas only, the RTL table registers through OBS wires).
// Claims:
//   G1  A check is GRANTED IFF every clause of 8.3 holds in the shadow: valid entry with the key; PD equal; the direction AND the
//       specific right; 1 <= len <= MAX_MSG_BYTES; va+len <= 2^64 (no wrap); the WHOLE [va, va+len) inside the ONE region; CONTIG or
//       the same 4 KiB page; translation context live.  On a grant pa == pa_base + (va - va_base) and ctx == entry.ctx.
//   G2  The fault code is exactly the FIRST failing clause in the spec order BAD_KEY < BAD_PD < BAD_DIR < BAD_PERM < BAD_LEN <
//       OVERFLOW < RANGE < PAGE_CROSS < XLATE; no fault is reported on a grant or on an idle port.
//   G3  Named corollaries (asserted separately): a correct key with a DIFFERENT PD never grants; a correct key with an out-of-range or
//       64-bit-wrapping range never grants; a grant only ever names a valid entry, hit by the presented key, owned by the presented PD.
//   G4  Configuration statuses (8.2 / 14): MR_SET gives ERR_IDX, ERR_EXISTS, ERR_FIELDS, ERR_RANGE, ERR_DUPKEY in exactly that order,
//       else OK and installs the entry; MR_INVAL gives ERR_IDX, ERR_NOENT, ERR_BUSY (refcount != 0) else OK and invalidates;
//       CTX_SET always OK.  A check in the cycle of a successful MR_INVAL never grants that region.
//   G5  Reference counts: a grant acquires, rel_* releases, ref_clear zeroes; MR_INVAL is BUSY exactly while the shadow refcount is
//       non-zero; the RTL refcounts equal the shadow; ref_ovf never fires under paired acquire/release.
//   G6  Keys of valid entries stay unique; the RTL table (valid, key, va_base, len, pa_base, pd, acc, ctx) equals the shadow.
//   G7  DMA guard (8.5): g_ok == (entry valid && refcnt > 0 && pa_base <= pa && pa+len <= pa_base+len_entry) for every rid / pa / len
//       (the RTL additionally refuses len == 0, which 8.5 leaves open: stricter, safe -- asserted as such).
//   G8  Fault statistics (8.3): the per-class saturating counters and the total equal the shadow; the one-entry fault log holds the
//       (op, key, va, len, fault) tuple of a faulting port of the most recent faulting cycle.
// Environment (assumptions): reset in cycle 0 only; mr_cmd != 0 when mr_cmd_valid (the QP command is not a registry command);
//   g_rid < NMR (a DMA command carries a granted rid); releases only against references really held (paired acquire/release) and no
//   refcount overflow (REF_W bits); everything else (all command fields, check requests of BOTH ports, ref_clear) is free every cycle.
// Instance: NMR = 3 (non-power-of-two so ERR_IDX is reachable), NCHK = 2, NREL = 2, NG = 2, PA_W = 32, PD_W = 2, CTX_W = 2, REF_W = 3,
//   PAGE_BYTES 4096, MAX_MSG_BYTES 1 MiB.  The 64-bit VA, 32-bit len / key and PAGE are the REAL widths (hard-coded in the RTL).
//   The table is NOT assumed to start in any state: BMC from reset with symbolic commands reaches every table content (3 SETs fill it).
// VAC != 0: reachability witnesses (the assertion MUST fail).
// =============================================================================
`default_nettype none
module fv_registry #(
  parameter P2  = 1,          // 1: both check ports are exercised; 0: port 1 is idle (smaller model, deeper BMC)
  parameter CNT = 1,          // 1: also check the fault counters / fault log (G8); 0: not instantiated in the model (smaller, deeper BMC)
  parameter G2  = 1,          // 1: both guard ports; 0: guard port 1 tied to length 0
  parameter VAC = 0
) (
  input wire clk,
  // configuration
  input wire mr_cmd_valid, input wire [1:0] mr_cmd, input wire [1:0] mr_idx, input wire [63:0] mr_va, input wire [31:0] mr_len,
  input wire [31:0] mr_pa, input wire [31:0] mr_key, input wire [1:0] mr_pd, input wire [7:0] mr_acc, input wire [1:0] mr_ctx, input wire [3:0] mr_ctx_mask,
  // checks (two ports)
  input wire [1:0] chk_valid_f, input wire [3:0] chk_op, input wire [63:0] chk_key, input wire [3:0] chk_pd, input wire [127:0] chk_va, input wire [63:0] chk_len,
  // references
  input wire [1:0] rel_valid, input wire [3:0] rel_rid, input wire ref_clear,
  // guards
  input wire [3:0] g_rid, input wire [63:0] g_pa, input wire [31:0] g_len_f
);
  wire [1:0]  chk_valid = {P2 ? chk_valid_f[1] : 1'b0, chk_valid_f[0]};
  wire [31:0] g_len     = {G2 ? g_len_f[31:16] : 16'd0, g_len_f[15:0]};
  localparam NMR = 3, NCHK = 2, NREL = 2, NG = 2, PA_W = 32, PD_W = 2, CTX_W = 2, REF_W = 3, RID_W = 2;
  localparam [31:0] MAXB = 32'd1048576;
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  // ---------------------------------------------------------------- DUT
  wire mr_rsp_valid; wire [3:0] mr_rsp_status;
  wire [NCHK-1:0] rsp_valid, rsp_ok; wire [NCHK*4-1:0] rsp_fault; wire [NCHK*RID_W-1:0] rsp_rid; wire [NCHK*PA_W-1:0] rsp_pa; wire [NCHK*CTX_W-1:0] rsp_ctx;
  wire [NG-1:0] g_ok;
  wire [11*32-1:0] fault_cnt; wire [NMR-1:0] tbl_valid; wire [3:0] fl_fault; wire [31:0] fl_key; wire [63:0] fl_va; wire [31:0] fl_len; wire [1:0] fl_op; wire ref_ovf;
  sf_rdma_memory_registry #(.NMR(NMR), .PA_W(PA_W), .PD_W(PD_W), .CTX_W(CTX_W), .NCHK(NCHK), .NREL(NREL), .NG(NG), .GLEN_W(16), .REF_W(REF_W),
                            .PAGE_BYTES(4096), .MAX_MSG_BYTES(1048576)) dut (
    .clk(clk), .rst_n(rst_n),
    .mr_cmd_valid(mr_cmd_valid), .mr_cmd(mr_cmd), .mr_idx(mr_idx), .mr_va(mr_va), .mr_len(mr_len), .mr_pa(mr_pa), .mr_key(mr_key), .mr_pd(mr_pd),
    .mr_acc(mr_acc), .mr_ctx(mr_ctx), .mr_ctx_mask(mr_ctx_mask), .mr_rsp_valid(mr_rsp_valid), .mr_rsp_status(mr_rsp_status),
    .chk_valid(chk_valid), .chk_op(chk_op), .chk_key(chk_key), .chk_pd(chk_pd), .chk_va(chk_va), .chk_len(chk_len),
    .rsp_valid(rsp_valid), .rsp_ok(rsp_ok), .rsp_fault(rsp_fault), .rsp_rid(rsp_rid), .rsp_pa(rsp_pa), .rsp_ctx(rsp_ctx),
    .rel_valid(rel_valid), .rel_rid(rel_rid), .ref_clear(ref_clear),
    .g_rid(g_rid), .g_pa(g_pa), .g_len(g_len), .g_ok(g_ok),
    .fault_cnt(fault_cnt), .tbl_valid(tbl_valid), .fl_fault(fl_fault), .fl_key(fl_key), .fl_va(fl_va), .fl_len(fl_len), .fl_op(fl_op), .ref_ovf(ref_ovf));

  // observation of the RTL table (induction lemmas / mirror)
  wire [31:0] o_key0, o_key1, o_key2;    // OBS o_key0 dut.key_q[0]
                                         // OBS o_key1 dut.key_q[1]
                                         // OBS o_key2 dut.key_q[2]
  wire [63:0] o_vab0, o_vab1, o_vab2;    // OBS o_vab0 dut.vab_q[0]
                                         // OBS o_vab1 dut.vab_q[1]
                                         // OBS o_vab2 dut.vab_q[2]
  wire [31:0] o_len0, o_len1, o_len2;    // OBS o_len0 dut.len_q[0]
                                         // OBS o_len1 dut.len_q[1]
                                         // OBS o_len2 dut.len_q[2]
  wire [31:0] o_pab0, o_pab1, o_pab2;    // OBS o_pab0 dut.pab_q[0]
                                         // OBS o_pab1 dut.pab_q[1]
                                         // OBS o_pab2 dut.pab_q[2]
  wire [1:0]  o_pd0, o_pd1, o_pd2;       // OBS o_pd0 dut.pd_q[0]
                                         // OBS o_pd1 dut.pd_q[1]
                                         // OBS o_pd2 dut.pd_q[2]
  wire [7:0]  o_acc0, o_acc1, o_acc2;    // OBS o_acc0 dut.acc_q[0]
                                         // OBS o_acc1 dut.acc_q[1]
                                         // OBS o_acc2 dut.acc_q[2]
  wire [1:0]  o_ctx0, o_ctx1, o_ctx2;    // OBS o_ctx0 dut.ctx_q[0]
                                         // OBS o_ctx1 dut.ctx_q[1]
                                         // OBS o_ctx2 dut.ctx_q[2]
  wire [REF_W-1:0] o_ref0, o_ref1, o_ref2; // OBS o_ref0 dut.ref_q[0]
                                         // OBS o_ref1 dut.ref_q[1]
                                         // OBS o_ref2 dut.ref_q[2]
  wire [3:0]  o_ctxen;                   // OBS o_ctxen dut.ctx_en

  // ---------------------------------------------------------------- shadow table
  reg [NMR-1:0]      sh_v;
  reg [32*NMR-1:0]   sh_key;
  reg [64*NMR-1:0]   sh_vab;
  reg [32*NMR-1:0]   sh_len;
  reg [PA_W*NMR-1:0] sh_pab;
  reg [PD_W*NMR-1:0] sh_pd;
  reg [8*NMR-1:0]    sh_acc;
  reg [CTX_W*NMR-1:0] sh_ctx;
  reg [7:0]          sh_ref [0:NMR-1];                 // reference counts (8 bits: no wrap in the shadow)
  reg [3:0]          sh_ctxen;
  reg [31:0]         sh_fc [0:10];                     // per-class fault counters (0 = total)

  // ---------------------------------------------------------------- configuration command, evaluated against the shadow
  reg [3:0] c_stat;
  reg       c_set, c_inv;
  reg       c_dup;
  reg [129:0] c_vaend, c_paend;
  integer ci;
  always @* begin
    c_dup = 1'b0;
    for (ci = 0; ci < NMR; ci = ci + 1) if (sh_v[ci] && sh_key[32*ci +: 32] == mr_key) c_dup = 1'b1;
    c_vaend = {66'd0, mr_va} + {98'd0, mr_len};
    c_paend = {98'd0, mr_pa} + {98'd0, mr_len};
    c_stat = 4'd0; c_set = 1'b0; c_inv = 1'b0;
    if (mr_cmd_valid) begin
      if (mr_cmd == 2'd1) begin                                                   // MR_SET
        if      (mr_idx >= NMR)                                  c_stat = 4'd1;   // ERR_IDX
        else if (sh_v[mr_idx])                                   c_stat = 4'd3;   // ERR_EXISTS
        else if (mr_len == 32'd0 || mr_acc[7:5] != 3'd0)         c_stat = 4'd5;   // ERR_FIELDS
        else if (c_vaend > 130'h1_0000_0000_0000_0000 || c_paend > 130'h1_0000_0000)  c_stat = 4'd6;   // ERR_RANGE  (2^64 / 2^PA_W)
        else if (c_dup)                                          c_stat = 4'd4;   // ERR_DUPKEY
        else begin c_stat = 4'd0; c_set = 1'b1; end
      end else if (mr_cmd == 2'd2) begin                                          // MR_INVAL
        if      (mr_idx >= NMR)                                  c_stat = 4'd1;   // ERR_IDX
        else if (!sh_v[mr_idx])                                  c_stat = 4'd7;   // ERR_NOENT
        else if (sh_ref[mr_idx] != 8'd0)                         c_stat = 4'd2;   // ERR_BUSY
        else begin c_stat = 4'd0; c_inv = 1'b1; end
      end else c_stat = 4'd0;                                                     // CTX_SET (3): always OK
    end
  end

  // ---------------------------------------------------------------- the check function, per port (independent formulation)
  wire [NCHK-1:0]        sp_found, sp_grant, sp_ovf, sp_inrange;
  wire [NCHK*4-1:0]      sp_fault;
  wire [NCHK*RID_W-1:0]  sp_idx;
  wire [NCHK*PD_W-1:0]   sp_epd;
  wire [NCHK*PA_W-1:0]   sp_pa;
  wire [NCHK*CTX_W-1:0]  sp_ectx;
  genvar gp;
  generate for (gp = 0; gp < NCHK; gp = gp + 1) begin : g_sp
    wire [1:0]  op  = chk_op[2*gp +: 2];
    wire [31:0] key = chk_key[32*gp +: 32];
    wire [PD_W-1:0] pd = chk_pd[2*gp +: 2];
    wire [63:0] va  = chk_va[64*gp +: 64];
    wire [31:0] len = chk_len[32*gp +: 32];
    reg         found;
    reg [RID_W-1:0] idx;
    reg [PD_W-1:0]  e_pd; reg [7:0] e_acc; reg [63:0] e_vab; reg [31:0] e_len; reg [PA_W-1:0] e_pab; reg [CTX_W-1:0] e_ctx;
    reg [129:0] wend, rend, last, pa_w;
    reg         ovf, inr, dirok, permok, pgx, live;
    reg [3:0]   f;
    integer     i;
    always @* begin
      found = 1'b0; idx = {RID_W{1'b0}}; e_pd = {PD_W{1'b0}}; e_acc = 8'd0; e_vab = 64'd0; e_len = 32'd0; e_pab = {PA_W{1'b0}}; e_ctx = {CTX_W{1'b0}};
      for (i = 0; i < NMR; i = i + 1) begin
        // an entry that is being invalidated in THIS cycle (successful MR_INVAL) is already gone for a concurrent check
        if (sh_v[i] && sh_key[32*i +: 32] == key && !(c_inv && mr_idx == i)) begin
          found = 1'b1; idx = idx | i[RID_W-1:0];                 // keys of valid entries are unique: OR-select
          e_pd = e_pd | sh_pd[PD_W*i +: PD_W]; e_acc = e_acc | sh_acc[8*i +: 8]; e_vab = e_vab | sh_vab[64*i +: 64];
          e_len = e_len | sh_len[32*i +: 32]; e_pab = e_pab | sh_pab[PA_W*i +: PA_W]; e_ctx = e_ctx | sh_ctx[CTX_W*i +: CTX_W];
        end
      end
      wend  = {66'd0, va} + {98'd0, len};                         // 130-bit: no wrap possible
      rend  = {66'd0, e_vab} + {98'd0, e_len};
      last  = wend - 130'd1;
      ovf   = (wend > 130'h1_0000_0000_0000_0000);
      inr   = (va >= e_vab) && (wend <= rend);
      dirok = (op[1] == 1'b0) ? (e_acc[0] || e_acc[1]) : (e_acc[2] || e_acc[3]);
      permok= e_acc[op];
      pgx   = !e_acc[4] && ((va / 64'd4096) != (last[63:0] / 64'd4096));
      pa_w  = {98'd0, e_pab} + ({66'd0, va} - {66'd0, e_vab});
      f = 4'd0;
      if      (!found)                          f = 4'd2;   // BAD_KEY
      else if (e_pd != pd)                      f = 4'd3;   // BAD_PD
      else if (!dirok)                          f = 4'd4;   // BAD_DIR
      else if (!permok)                         f = 4'd5;   // BAD_PERM
      else if (len == 32'd0 || len > MAXB)      f = 4'd6;   // BAD_LEN
      else if (ovf)                             f = 4'd7;   // OVERFLOW
      else if (!inr)                            f = 4'd8;   // RANGE
      else if (pgx)                             f = 4'd9;   // PAGE_CROSS
      else if (!sh_ctxen[e_ctx])                f = 4'd10;  // XLATE
      live = chk_valid[gp];
    end
    assign sp_found[gp]  = found;
    assign sp_grant[gp]  = live && (f == 4'd0);
    assign sp_fault[4*gp +: 4] = live ? f : 4'd0;
    assign sp_idx[RID_W*gp +: RID_W] = idx;
    assign sp_epd[PD_W*gp +: PD_W] = e_pd;
    assign sp_pa[PA_W*gp +: PA_W] = pa_w[PA_W-1:0];
    assign sp_ectx[CTX_W*gp +: CTX_W] = e_ctx;
    assign sp_ovf[gp] = ovf;
    assign sp_inrange[gp] = inr;
  end endgenerate

  // ---------------------------------------------------------------- reference accounting and environment constraints (paired acquire / release)
  reg [7:0] g_cnt [0:NMR-1];          // grants this cycle per entry
  reg [7:0] r_cnt [0:NMR-1];          // releases this cycle per entry
  integer ei, pi, ri;
  always @* begin
    for (ei = 0; ei < NMR; ei = ei + 1) begin
      g_cnt[ei] = 8'd0; r_cnt[ei] = 8'd0;
      for (pi = 0; pi < NCHK; pi = pi + 1) if (sp_grant[pi] && sp_idx[RID_W*pi +: RID_W] == ei) g_cnt[ei] = g_cnt[ei] + 8'd1;
      for (ri = 0; ri < NREL; ri = ri + 1) if (rel_valid[ri] && rel_rid[RID_W*ri +: RID_W] == ei) r_cnt[ei] = r_cnt[ei] + 8'd1;
    end
  end
  integer ea, ra;
  always @(posedge clk) if (!init) begin
    assume(!mr_cmd_valid || mr_cmd != 2'd0);
    assume(g_rid[1:0] < NMR && g_rid[3:2] < NMR);
    for (ea = 0; ea < NMR; ea = ea + 1) begin
      assume(r_cnt[ea] <= sh_ref[ea]);                               // paired: release only a held reference
      assume(sh_ref[ea] + g_cnt[ea] - r_cnt[ea] <= 8'd7);            // no refcount overflow (REF_W = 3)
    end
    for (ra = 0; ra < NREL; ra = ra + 1) assume(!rel_valid[ra] || rel_rid[RID_W*ra +: RID_W] < NMR);
  end

  // ---------------------------------------------------------------- shadow update and previous-cycle copies
  reg                 cmd_v_q;  reg [3:0] cstat_q;
  reg [NCHK-1:0]      chk_v_q, sp_grant_q, sp_found_q, sp_ovf_q, sp_inr_q;
  reg [NCHK*4-1:0]    sp_fault_q; reg [NCHK*RID_W-1:0] sp_idx_q; reg [NCHK*PD_W-1:0] sp_epd_q; reg [NCHK*PA_W-1:0] sp_pa_q; reg [NCHK*CTX_W-1:0] sp_ectx_q;
  reg [NCHK*PD_W-1:0] chk_pd_q;
  // fault-log candidates of the most recent faulting cycle
  reg                 lf_any;
  reg [NCHK-1:0]      lf_v;
  reg [NCHK*4-1:0]    lf_fault; reg [NCHK*32-1:0] lf_key; reg [NCHK*64-1:0] lf_va; reg [NCHK*32-1:0] lf_len; reg [NCHK*2-1:0] lf_op;
  integer ki, ci2, pj, pk;
  reg [31:0] inc [0:10];
  always @* begin
    for (ci2 = 0; ci2 <= 10; ci2 = ci2 + 1) begin
      inc[ci2] = 32'd0;
      for (pj = 0; pj < NCHK; pj = pj + 1) begin
        if (ci2 == 0) begin if (sp_fault[4*pj +: 4] != 4'd0) inc[ci2] = inc[ci2] + 32'd1; end
        else if (sp_fault[4*pj +: 4] == ci2[3:0]) inc[ci2] = inc[ci2] + 32'd1;
      end
    end
  end

  always @(posedge clk) begin
    if (init) begin
      sh_v <= {NMR{1'b0}}; sh_key <= 0; sh_vab <= 0; sh_len <= 0; sh_pab <= 0; sh_pd <= 0; sh_acc <= 0; sh_ctx <= 0; sh_ctxen <= 4'b0001;
      for (ki = 0; ki < NMR; ki = ki + 1) sh_ref[ki] <= 8'd0;
      for (ki = 0; ki <= 10; ki = ki + 1) sh_fc[ki] <= 32'd0;
      cmd_v_q <= 1'b0; cstat_q <= 4'd0; chk_v_q <= 0; sp_grant_q <= 0; sp_found_q <= 0; sp_ovf_q <= 0; sp_inr_q <= 0; sp_fault_q <= 0; sp_idx_q <= 0; sp_epd_q <= 0;
      sp_pa_q <= 0; sp_ectx_q <= 0; chk_pd_q <= 0; lf_any <= 1'b0; lf_v <= 0; lf_fault <= 0; lf_key <= 0; lf_va <= 0; lf_len <= 0; lf_op <= 0;
    end else begin
      cmd_v_q <= mr_cmd_valid; cstat_q <= c_stat;
      if (c_set) begin
        sh_v[mr_idx] <= 1'b1; sh_key[32*mr_idx +: 32] <= mr_key; sh_vab[64*mr_idx +: 64] <= mr_va; sh_len[32*mr_idx +: 32] <= mr_len;
        sh_pab[PA_W*mr_idx +: PA_W] <= mr_pa; sh_pd[PD_W*mr_idx +: PD_W] <= mr_pd; sh_acc[8*mr_idx +: 8] <= mr_acc; sh_ctx[CTX_W*mr_idx +: CTX_W] <= mr_ctx;
      end
      if (c_inv) sh_v[mr_idx] <= 1'b0;
      if (mr_cmd_valid && mr_cmd == 2'd3) sh_ctxen <= mr_ctx_mask;
      for (ki = 0; ki < NMR; ki = ki + 1) sh_ref[ki] <= ref_clear ? 8'd0 : (sh_ref[ki] + g_cnt[ki] - r_cnt[ki]);
      for (ki = 0; ki <= 10; ki = ki + 1) sh_fc[ki] <= (sh_fc[ki] > 32'hFFFF_FFFF - inc[ki]) ? 32'hFFFF_FFFF : sh_fc[ki] + inc[ki];
      chk_v_q <= chk_valid; sp_grant_q <= sp_grant; sp_found_q <= sp_found; sp_ovf_q <= sp_ovf; sp_inr_q <= sp_inrange; sp_fault_q <= sp_fault; sp_idx_q <= sp_idx;
      sp_epd_q <= sp_epd; sp_pa_q <= sp_pa; sp_ectx_q <= sp_ectx; chk_pd_q <= chk_pd;
      if (|sp_fault) begin
        lf_any <= 1'b1;
        for (pk = 0; pk < NCHK; pk = pk + 1) begin
          lf_v[pk] <= (sp_fault[4*pk +: 4] != 4'd0);
          lf_fault[4*pk +: 4] <= sp_fault[4*pk +: 4]; lf_key[32*pk +: 32] <= chk_key[32*pk +: 32]; lf_va[64*pk +: 64] <= chk_va[64*pk +: 64];
          lf_len[32*pk +: 32] <= chk_len[32*pk +: 32]; lf_op[2*pk +: 2] <= chk_op[2*pk +: 2];
        end
      end
    end
  end

  // ---------------------------------------------------------------- guard specification (8.5), wide arithmetic
  reg [NG-1:0] g_spec;
  reg [129:0]  gp_end, gw_end;
  integer gk;
  reg [31:0]   gl;
  always @* begin
    for (gk = 0; gk < NG; gk = gk + 1) begin
      g_spec[gk] = 1'b0;
      gl = (gk == 0) ? {16'd0, g_len[15:0]} : {16'd0, g_len[31:16]};
      gp_end = {98'd0, g_pa[32*gk +: 32]} + {98'd0, gl};
      case (g_rid[2*gk +: 2])
        2'd0: begin gw_end = {98'd0, sh_pab[0 +: 32]} + {98'd0, sh_len[0 +: 32]};  g_spec[gk] = sh_v[0] && sh_ref[0] != 8'd0 && gl != 32'd0 && g_pa[32*gk +: 32] >= sh_pab[0 +: 32]  && gp_end <= gw_end; end
        2'd1: begin gw_end = {98'd0, sh_pab[32 +: 32]} + {98'd0, sh_len[32 +: 32]}; g_spec[gk] = sh_v[1] && sh_ref[1] != 8'd0 && gl != 32'd0 && g_pa[32*gk +: 32] >= sh_pab[32 +: 32] && gp_end <= gw_end; end
        default: begin gw_end = {98'd0, sh_pab[64 +: 32]} + {98'd0, sh_len[64 +: 32]}; g_spec[gk] = sh_v[2] && sh_ref[2] != 8'd0 && gl != 32'd0 && g_pa[32*gk +: 32] >= sh_pab[64 +: 32] && gp_end <= gw_end; end
      endcase
    end
  end

  // ---------------------------------------------------------------- RTL table as seen by the lemmas
  // selectors over the OBS wires (functions, not concatenations: `connect -set` of an OBS wire that sits inside a net alias is unreliable)
  function [31:0] f_key(input integer n); f_key = (n == 0) ? o_key0 : (n == 1) ? o_key1 : o_key2; endfunction
  function [63:0] f_vab(input integer n); f_vab = (n == 0) ? o_vab0 : (n == 1) ? o_vab1 : o_vab2; endfunction
  function [31:0] f_len(input integer n); f_len = (n == 0) ? o_len0 : (n == 1) ? o_len1 : o_len2; endfunction
  function [31:0] f_pab(input integer n); f_pab = (n == 0) ? o_pab0 : (n == 1) ? o_pab1 : o_pab2; endfunction
  function [1:0]  f_pd (input integer n); f_pd  = (n == 0) ? o_pd0  : (n == 1) ? o_pd1  : o_pd2;  endfunction
  function [7:0]  f_acc(input integer n); f_acc = (n == 0) ? o_acc0 : (n == 1) ? o_acc1 : o_acc2; endfunction
  function [1:0]  f_ctx(input integer n); f_ctx = (n == 0) ? o_ctx0 : (n == 1) ? o_ctx1 : o_ctx2; endfunction
  function [REF_W-1:0] f_ref(input integer n); f_ref = (n == 0) ? o_ref0 : (n == 1) ? o_ref1 : o_ref2; endfunction

  integer a, b, c;
  reg mirror_ok, uniq_ok, ref_ok, lf_ok;
  always @* begin
    mirror_ok = (tbl_valid == sh_v) && (o_ctxen == sh_ctxen);
    uniq_ok = 1'b1; ref_ok = 1'b1;
    for (a = 0; a < NMR; a = a + 1) begin
      if (sh_v[a]) begin
        mirror_ok = mirror_ok && f_key(a) == sh_key[32*a +: 32] && f_vab(a) == sh_vab[64*a +: 64] && f_len(a) == sh_len[32*a +: 32] &&
                    f_pab(a) == sh_pab[32*a +: 32] && f_pd(a) == sh_pd[2*a +: 2] && f_acc(a) == sh_acc[8*a +: 8] && f_ctx(a) == sh_ctx[2*a +: 2];
      end
      ref_ok = ref_ok && ({5'd0, f_ref(a)} == sh_ref[a]) && sh_ref[a] <= 8'd7;
      for (b = a + 1; b < NMR; b = b + 1) if (sh_v[a] && sh_v[b] && sh_key[32*a +: 32] == sh_key[32*b +: 32]) uniq_ok = 1'b0;
    end
    lf_ok = !lf_any ? (fl_fault == 4'd0 && fl_key == 32'd0 && fl_va == 64'd0 && fl_len == 32'd0 && fl_op == 2'd0) : 1'b0;
    for (c = 0; c < NCHK; c = c + 1)
      if (lf_any && lf_v[c] && fl_fault == lf_fault[4*c +: 4] && fl_key == lf_key[32*c +: 32] && fl_va == lf_va[64*c +: 64] && fl_len == lf_len[32*c +: 32] && fl_op == lf_op[2*c +: 2]) lf_ok = 1'b1;
  end

  // ---------------------------------------------------------------- the assertions
  integer w;
  reg fc_ok;
  always @* begin
    fc_ok = 1'b1;
    for (w = 0; w <= 10; w = w + 1) fc_ok = fc_ok && (fault_cnt[32*w +: 32] == sh_fc[w]);
  end
  genvar q;
  generate for (q = 0; q < NCHK; q = q + 1) begin : g_as
    always @(posedge clk) if (!init && VAC == 0) begin
      assert(rsp_valid[q] == chk_v_q[q]);
      assert(rsp_ok[q] == sp_grant_q[q]);
      assert(rsp_fault[4*q +: 4] == sp_fault_q[4*q +: 4]);
      assert(!rsp_ok[q] || (rsp_pa[PA_W*q +: PA_W] == sp_pa_q[PA_W*q +: PA_W] && rsp_ctx[CTX_W*q +: CTX_W] == sp_ectx_q[CTX_W*q +: CTX_W] &&
                                 rsp_rid[RID_W*q +: RID_W] == sp_idx_q[RID_W*q +: RID_W]));
      assert(!(chk_v_q[q] && sp_found_q[q] && sp_epd_q[PD_W*q +: PD_W] != chk_pd_q[PD_W*q +: PD_W]) || !rsp_ok[q]);   // right key, wrong PD: never
      assert(!(chk_v_q[q] && sp_found_q[q] && (sp_ovf_q[q] || !sp_inr_q[q])) || !rsp_ok[q]);                            // right key, wrap / out of range: never
      assert(!rsp_ok[q] || (sp_found_q[q] && sp_epd_q[PD_W*q +: PD_W] == chk_pd_q[PD_W*q +: PD_W] && !sp_ovf_q[q] && sp_inr_q[q]));
    end
  end endgenerate
  always @(posedge clk) if (!init) begin
    if (VAC == 0) begin
      G4a: assert(mr_rsp_valid == cmd_v_q);
      G4b: assert(!cmd_v_q || mr_rsp_status == cstat_q);
      G6a: assert(mirror_ok);
      G6b: assert(uniq_ok);
      G5a: assert(ref_ok);
      G5b: assert(!ref_ovf);
      G7a: assert(g_ok[0] == g_spec[0] && g_ok[1] == g_spec[1]);   // (with G2 = 0 guard port 1 sees len 0 and must refuse)
      if (CNT) begin
        G8a: assert(fc_ok);
        G8b: assert(lf_ok);
      end
    end else begin
      case (VAC)
        1:  assert(!(rsp_ok[0] && rsp_valid[0]));                                        // a grant on port 0
        2:  assert(!(rsp_ok[1]));                                                        // a grant on port 1
        3:  assert(!(rsp_valid[0] && sp_found_q[0] && sp_epd_q[0 +: 2] != chk_pd_q[0 +: 2]));   // correct key, wrong PD offered
        4:  assert(!(rsp_fault[3:0] == 4'd7));                                           // OVERFLOW (va + len wraps)
        5:  assert(!(rsp_fault[3:0] == 4'd8 && sp_found_q[0]));                          // RANGE with a correct key
        6:  assert(!(rsp_fault[3:0] == 4'd9));                                           // PAGE_CROSS
        7:  assert(!(rsp_fault[3:0] == 4'd10));                                          // XLATE (context not live)
        8:  assert(!(mr_rsp_valid && mr_rsp_status == 4'd2));                            // MR_INVAL answered BUSY
        9:  assert(!(mr_rsp_valid && mr_rsp_status == 4'd4));                            // ERR_DUPKEY
        10: assert(!(mr_rsp_valid && mr_rsp_status == 4'd6));                            // ERR_RANGE
        11: assert(!(mr_rsp_valid && mr_rsp_status == 4'd1));                            // ERR_IDX
        12: assert(!(g_ok[0] && g_rid[1:0] == 2'd2));                                    // the guard passes
        13: assert(!(rsp_ok[0] && rsp_ok[1]));                                           // both ports granted in the same cycle
        14: assert(sh_v != 3'b111);                                                     // the table can be completely full
        15: assert(!(rsp_fault[3:0] == 4'd4));                                           // BAD_DIR
        16: assert(!(rsp_fault[3:0] == 4'd5));                                           // BAD_PERM
        17: assert(!(rsp_fault[3:0] == 4'd6));                                           // BAD_LEN
        18: assert(!(rsp_fault[3:0] == 4'd2));                                           // BAD_KEY
        19: assert(!(rsp_fault[3:0] == 4'd3));                                           // BAD_PD
      endcase
    end
  end
endmodule
