// =============================================================================
// Formal harness: sf_rdma_requester   (issue / transmit / ACK / retire / failure)               TRANSPORT_SPEC 6, 7, 9.1, 9.5, 9.6, 11.1, 12.3
//
// Free environment: symbolic SQ head (a stable, in-order WQE stream), registry answers (one cycle after a check request), tx_ready,
// ACK / NAK events (valid, stale and forged ones), READ-response placement events, cmp_ready; a small retry configuration (constant) so
// timeouts / NAK rewinds / RNR waits happen within the BMC depth.  Claims:
//   Q1  Window: occupancy (nxt - una) <= WINDOW and  una <= txp <= nxt (modular) at ALL times -- in particular after a go-back-N
//       rewind (timeout / SEQ_ERR / RNR) followed by a cumulative ACK that retires entries; a transmit request never names a PSN
//       before una or at/after nxt, and tx_sh carries PSN = txp.                                                          [9.1]  (regression: bug 3)
//   Q2  Outstanding READs: rd_out == number of READ entries in [una, nxt) (never wraps, never loses an increment when a READ is issued in
//       the cycle another retires) and rd_out <= MAX_RD.                                                                [9.1, 12.3]  (regression: bug 2)
//   Q3  COMPLETION ONLY AFTER COMMIT.  A WRITE / SEND CQE with status OK is produced only after a VALID ACK (spec 9.5 validity) whose
//       commit_next covered the WQE's last PSN (shadow: highest commit_next of any valid ACK); a READ CQE only after the response-
//       placement completion event of its entry.  una advances over a WRITE / SEND entry only when committed, over a READ entry only
//       when placed.                                                                                                       [7.2, 7.3, 9.5]
//   Q4  CQEs are emitted in WQE POST order, exactly once each: the k-th CQE carries wr_id k (the SQ head stream is numbered), and no CQE
//       is produced for a WQE that was not started (a WQE gets its context at the local check; the head WQE of a multi-segment message can fail before it is popped).                                  [9.5(3), 11.1, 13]
//   Q5  A local-check failure never produces a transmit request for that WQE: the request-table entries created (nxt - first PSN) never
//       exceed the segments of the WQEs that PASSED the local check (failed WQEs contribute none).                         [7.1-7.3]
//   Q7  The commit and accept frontiers (chi / ahi) never lose a valid ACK: whenever the shadow frontier of the valid ACKs is ahead of una, the
//       RTL frontier has reached it (ACK + retirement in one cycle included).                                             (regression: F-07)
//   Q6  Stale / forged ACKs (spec 9.5 validity) never move una / chi (checked through Q3) and never exceed nxt.
// Environment assumptions: reset in cycle 0, PSN load pulse (ld_valid) in cycle 1 with a free 24-bit PSN0 (modular wrap exercised);
//   clear = 0; en = 1 from cycle 2 until flush_en (QP ERR), flush sticky; SQ head numbered, stable until popped, op in {1,2,3}, 0 <= len <= 9
//   (len >= 1 for WRITE / READ: post-validated by sf_rdma_wqe); registry answers exactly one cycle after chk_valid; ack_code <= 5;
//   rr_accept only for a found READ entry with a legal length, place_done only for a fully received READ entry (rdoff == mlen);
//   retry configuration constant with timeout in [1,2], retry_max <= 2, rnr_max <= 1, rnr_delay <= 2.
// Instance: WINDOW = 4, MAX_RD = 2, MTU = 4, PA_W = 8, PD_W = 2, RID_W = 1, CTX_W = 1.  BMC from reset.   VAC != 0: witnesses.
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none
module fv_requester #(
  parameter WIN = 2,           // request-table / WINDOW size (2 or 4)
  parameter ONLYRD = 0,        // 1: the SQ stream carries READ WQEs only (reaches the rd_out races much earlier)
  parameter VAC = 0
) (
  input wire clk,
  input wire flush_f,
  input wire sq_valid_f, input wire [1:0] sq_op_f, input wire [31:0] sq_len_f,
  input wire rsp_ok, input wire rsp_rid, input wire [7:0] rsp_pa, input wire rsp_ctx,
  input wire tx_ready,
  input wire ack_valid, input wire [4:0] ack_cn_o, input wire [4:0] ack_an_o, input wire [3:0] ack_code,       // ACK frontiers as signed offsets (+-16) from una: stale, valid and forged-beyond-nxt ones
  input wire [2:0] rr_o, input wire rr_accept, input wire [15:0] rr_accept_len, input wire place_done_valid, input wire [1:0] pd_o,
  input wire cmp_ready
);
  localparam W = WIN, MAXRD = 2, MTUP = 4, PA_W = 8;
  localparam [23:0] W24 = W;
  localparam WBH = (WIN == 2) ? 1 : 2;
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;
  reg first = 1'b1;  always @(posedge clk) if (!init) first <= 1'b0;
  reg run = 1'b0;    always @(posedge clk) if (!init && !first) run <= 1'b1;        // cycle >= 2
  (* anyconst *) reg [23:0] PSN0;
  (* anyconst *) reg [31:0] cfg_timeout;
  (* anyconst *) reg [3:0]  cfg_retry_max;
  (* anyconst *) reg [3:0]  cfg_rnr_max;
  (* anyconst *) reg [31:0] cfg_rnr_delay;
  always @(posedge clk) begin
    assume(cfg_timeout >= 32'd1 && cfg_timeout <= 32'd2); assume(cfg_retry_max <= 4'd2); assume(cfg_rnr_max <= 4'd1); assume(cfg_rnr_delay <= 32'd2);
  end
  wire ld_valid = !init && first;
  reg flush_q;
  wire flush_en = flush_f;
  wire en = run && !flush_en;

  // ---------------------------------------------------------------- SQ head: a numbered stream, stable until popped
  reg [31:0] sq_seq;                                   // number of WQEs popped from the SQ so far
  reg        sq_hold_q; reg [1:0] sq_op_q; reg [31:0] sq_len_q;
  // the 64-bit addresses and 32-bit keys of a WQE are pure payload for the requester (copied into the request table, never decoded): fixed to 0 here,
  // which removes ~700 free state bits from the model without touching any control path
  wire [63:0] sq_laddr = 64'd0, sq_raddr = 64'd0; wire [31:0] sq_lkey = 32'd0, sq_rkey = 32'd0;
  wire sq_valid = sq_valid_f;
  wire [1:0] sq_op = sq_op_f; wire [31:0] sq_len = sq_len_f;
  wire [63:0] sq_wr_id = {32'd0, sq_seq};

  // internal state observed by the invariants / legality constraints
  wire [23:0] o_una, o_nxt, o_txp;        // OBS o_una dut.una
                                          // OBS o_nxt dut.nxt
                                          // OBS o_txp dut.txp
  wire [23:0] o_chi, o_ahi;               // OBS o_chi dut.chi
                                          // OBS o_ahi dut.ahi
  wire [3:0]  o_rdout;                    // OBS o_rdout dut.rd_out
  wire [1:0]  o_ist;                      // OBS o_ist dut.ist
  wire [1:0]  o_eop0, o_eop1, o_eop2, o_eop3;       // OBS o_eop0 dut.e_op[0]
                                                    // OBS o_eop1 dut.e_op[1]
                                                    // OBS o_eop2 dut.e_op[2] ?WIN=4
                                                    // OBS o_eop3 dut.e_op[3] ?WIN=4
  wire [31:0] o_rdo0, o_rdo1, o_rdo2, o_rdo3;      // OBS o_rdo0 dut.e_rdoff[0]
                                                    // OBS o_rdo1 dut.e_rdoff[1]
                                                    // OBS o_rdo2 dut.e_rdoff[2] ?WIN=4
                                                    // OBS o_rdo3 dut.e_rdoff[3] ?WIN=4
  wire [31:0] o_eml0, o_eml1, o_eml2, o_eml3;      // OBS o_eml0 dut.e_mlen[0]
                                                    // OBS o_eml1 dut.e_mlen[1]
                                                    // OBS o_eml2 dut.e_mlen[2] ?WIN=4
                                                    // OBS o_eml3 dut.e_mlen[3] ?WIN=4
  generate if (WIN == 2) begin : g_w2     // slots 2 / 3 do not exist: tie their observation wires
    assign o_eop2 = 2'd0; assign o_eop3 = 2'd0; assign o_rdo2 = 32'd0; assign o_rdo3 = 32'd0; assign o_eml2 = 32'd0; assign o_eml3 = 32'd0;
  end endgenerate
  wire [23:0] ack_cn = o_una + {{19{ack_cn_o[4]}}, ack_cn_o};
  wire [23:0] ack_an = o_una + {{19{ack_an_o[4]}}, ack_an_o};
  wire [23:0] rr_psn = o_una + {{21{rr_o[2]}}, rr_o};
  wire [23:0] place_done_psn = o_una + {22'd0, pd_o};
  // ---------------------------------------------------------------- DUT
  wire sq_pop, chk_valid, rel_valid, rel_chk_valid, tx_valid, tx_has_pl, rr_found, cmp_valid, err_req, idle, ev_retry_timeout, ev_retry_nak, ev_retry_rnr, ev_tx_retx, ev_rx_ack_stale, ev_rx_nak, ev_stall_window, ev_stall_rdlim, lat_valid, cqe_valid, quiet;
  wire [1:0] chk_op; wire [31:0] chk_key, chk_len; wire [1:0] chk_pd; wire [63:0] chk_va; wire [0:0] rel_rid, rel_chk_rid; wire [271:0] tx_sh; wire [PA_W-1:0] tx_pa; wire [15:0] tx_len; wire [0:0] tx_rid, tx_ctx;
  wire [31:0] rr_exp_off, rr_mlen; wire [PA_W-1:0] rr_lpa; wire [0:0] rr_rid, rr_ctx; wire [63:0] cmp_wr_id; wire [3:0] cmp_op, cmp_status, err_cause, cqe_op, cqe_status; wire [31:0] cmp_len, lat_cycles, cqe_len;
  wire [3:0] win_occ; wire [1:0] lat_op;
  reg chk_v_q;
  wire rsp_valid = chk_v_q;
  sf_rdma_requester #(.WINDOW(WIN), .MAX_RD(MAXRD), .MTU(MTUP), .PA_W(PA_W), .PD_W(2), .RID_W(1), .CTX_W(1)) dut (
    .clk(clk), .rst_n(rst_n), .clear(1'b0), .en(en), .flush_en(flush_en), .ld_valid(ld_valid), .ld_psn(PSN0), .qp_pd(2'd1), .remote_qpn(16'h0002), .epoch(16'h0001),
    .cfg_timeout(cfg_timeout), .cfg_retry_max(cfg_retry_max), .cfg_rnr_max(cfg_rnr_max), .cfg_rnr_delay(cfg_rnr_delay), .now(32'd0),
    .sq_valid(sq_valid), .sq_pop(sq_pop), .sq_op(sq_op), .sq_wr_id(sq_wr_id), .sq_laddr(sq_laddr), .sq_lkey(sq_lkey), .sq_len(sq_len), .sq_raddr(sq_raddr), .sq_rkey(sq_rkey),
    .chk_valid(chk_valid), .chk_op(chk_op), .chk_key(chk_key), .chk_pd(chk_pd), .chk_va(chk_va), .chk_len(chk_len),
    .rsp_valid(rsp_valid), .rsp_ok(rsp_ok), .rsp_rid(rsp_rid), .rsp_pa(rsp_pa), .rsp_ctx(rsp_ctx), .rel_valid(rel_valid), .rel_rid(rel_rid), .rel_chk_valid(rel_chk_valid), .rel_chk_rid(rel_chk_rid),
    .lerr_tx_valid(1'b0), .lerr_tx_psn(24'd0), .lerr_pl_valid(1'b0), .lerr_pl_idx({WBH{1'b0}}), .dma_quiet(1'b1),      // local-error inputs not exercised here (tied off)
    .tx_valid(tx_valid), .tx_ready(tx_ready), .tx_sh(tx_sh), .tx_has_pl(tx_has_pl), .tx_pa(tx_pa), .tx_len(tx_len), .tx_rid(tx_rid), .tx_ctx(tx_ctx),
    .ack_valid(ack_valid), .ack_cn(ack_cn), .ack_an(ack_an), .ack_code(ack_code), .rr_psn(rr_psn), .rr_found(rr_found), .rr_exp_off(rr_exp_off), .rr_mlen(rr_mlen), .rr_lpa(rr_lpa),
    .rr_rid(rr_rid), .rr_ctx(rr_ctx), .rr_accept(rr_accept), .rr_accept_len(rr_accept_len), .place_done_valid(place_done_valid), .place_done_psn(place_done_psn),
    .cmp_valid(cmp_valid), .cmp_ready(cmp_ready), .cmp_wr_id(cmp_wr_id), .cmp_op(cmp_op), .cmp_status(cmp_status), .cmp_len(cmp_len), .err_req(err_req), .err_cause(err_cause),
    .idle(idle), .quiet(quiet), .win_occ(win_occ), .ev_retry_timeout(ev_retry_timeout), .ev_retry_nak(ev_retry_nak), .ev_retry_rnr(ev_retry_rnr), .ev_tx_retx(ev_tx_retx),
    .ev_rx_ack_stale(ev_rx_ack_stale), .ev_rx_nak(ev_rx_nak), .ev_stall_window(ev_stall_window), .ev_stall_rdlim(ev_stall_rdlim), .lat_valid(lat_valid), .lat_op(lat_op),
    .lat_cycles(lat_cycles), .cqe_valid(cqe_valid), .cqe_op(cqe_op), .cqe_status(cqe_status), .cqe_len(cqe_len));
  function [1:0] f_eop(input [1:0] n); f_eop = (n == 0) ? o_eop0 : (n == 1) ? o_eop1 : (n == 2) ? o_eop2 : o_eop3; endfunction
  function [31:0] f_rdo(input [1:0] n); f_rdo = (n == 0) ? o_rdo0 : (n == 1) ? o_rdo1 : (n == 2) ? o_rdo2 : o_rdo3; endfunction
  function [31:0] f_eml(input [1:0] n); f_eml = (n == 0) ? o_eml0 : (n == 1) ? o_eml1 : (n == 2) ? o_eml2 : o_eml3; endfunction

  function [1:0] slot(input [23:0] psn); slot = (W == 2) ? {1'b0, psn[0]} : psn[1:0]; endfunction
  // ---------------------------------------------------------------- helpers
  function psn_lt(input [23:0] a, input [23:0] b); reg [23:0] d; begin d = b - a; psn_lt = (d != 24'd0) && !d[23]; end endfunction
  function [31:0] segs(input [1:0] op, input [31:0] len);   // request PSNs of a WQE (spec 7): READ 1; SEND / WRITE max(1, ceil(len / MTU))
    begin segs = (op == 2'd3) ? 32'd1 : (len == 32'd0) ? 32'd1 : ((len + MTUP - 1) / MTUP); end
  endfunction

  // ---------------------------------------------------------------- shadow
  reg [23:0] cmax, amax;           // highest commit_next / accept_next carried by a VALID ACK (spec 9.5 validity)
  reg [3:0]  pdone;                // READ placement completion seen per table slot
  reg [31:0] cq_next;              // wr_id the next CQE must carry
  reg [31:0] okseg;                // request PSNs of the WQEs that passed the local check
  reg ld_q; reg [1:0]  ist_q; reg [23:0] una_q, txp_q; reg rdq_una; reg pd_una_q; reg [3:0] rdout_q; reg [23:0] cmax_q;
  wire [23:0] dc = ack_cn - o_una, da = ack_an - o_una, dn = o_nxt - o_una;
  wire ack_ok_s = ack_valid && en && (dc <= da) && (da <= dn);
  wire cqe_go = cmp_valid && cmp_ready;
  wire [23:0] occ_w  = o_nxt - o_una;                  // (24-bit wires: Verilog would widen `a - b <= W` to 32 bits BEFORE subtracting)
  wire [23:0] made_w = o_nxt - PSN0;
  // READ entries in [una, nxt): a harness shadow of the request table (set when an entry is created for a READ WQE, cleared when una passes it)
  reg [3:0] rdm; reg [23:0] nxt_q;
  // NOTE: never alias an OBS wire (bit select / concatenation / function argument): `connect -set` unsets such aliases.  `& mask` makes a cell.
  wire [1:0] msk = (W == 2) ? 2'b01 : 2'b11;
  wire [23:0] una_c = o_una + 24'd0;                    // a cell, not an alias of the OBS wire
  wire [1:0] su = (W == 2) ? {1'b0, una_c[0]} : una_c[1:0];
  wire [1:0] s1 = (su + 2'd1) & msk;
  wire [1:0] s2 = (su + 2'd2) & msk, s3 = (su + 2'd3) & msk;
  // (the shadow lags the DUT by one cycle: it is built from the observed changes of nxt / una, so it is compared with the registered view of the state)
  wire [23:0] occ_q = nxt_q - una_q;
  wire [1:0]  q0 = slot(una_q), q1 = slot(una_q + 24'd1), q2 = slot(una_q + 24'd2), q3 = slot(una_q + 24'd3);
  wire rd0 = (occ_q > 24'd0 && W > 0) ? rdm[q0] : 1'b0;
  wire rd1 = (occ_q > 24'd1 && W > 1) ? rdm[q1] : 1'b0;
  wire rd2 = (occ_q > 24'd2 && W > 2) ? rdm[q2] : 1'b0;
  wire rd3 = (occ_q > 24'd3 && W > 3) ? rdm[q3] : 1'b0;
  wire [31:0] nrd = {31'd0, rd0} + {31'd0, rd1} + {31'd0, rd2} + {31'd0, rd3};
  always @(posedge clk) if (!init) begin
    assume(ack_code <= 4'd5);
    assume(sq_op != 2'd0);
    assume(!ONLYRD || sq_op == 2'd3);
    assume(sq_len <= 32'd9);
    assume(sq_op == 2'd1 || sq_len != 32'd0);
    assume(!sq_valid || sq_wr_id == {32'd0, sq_seq});
    assume(!sq_hold_q || (sq_valid && sq_op == sq_op_q && sq_len == sq_len_q));
    assume(!flush_q || flush_en);
    // READ-response events are legal only for READ entries of the table
    assume(!rr_accept || (rr_found && rr_accept_len != 16'd0 && ({16'd0, rr_accept_len} <= rr_mlen - rr_exp_off)));
    assume(!place_done_valid || (rdm[slot(place_done_psn)] && (place_done_psn - o_una) < (o_nxt - o_una) && !pdone[slot(place_done_psn)]));
  end
  always @(posedge clk) begin
    if (init) begin
      cmax <= 24'd0; amax <= 24'd0; pdone <= 4'd0; cq_next <= 32'd0; okseg <= 32'd0; sq_seq <= 32'd0; sq_hold_q <= 1'b0; sq_op_q <= 2'd0; sq_len_q <= 32'd0;
      ld_q <= 1'b0; rdm <= 4'd0; nxt_q <= 24'd0; rdout_q <= 4'd0; chk_v_q <= 1'b0; flush_q <= 1'b0; ist_q <= 2'd0; una_q <= 24'd0; txp_q <= 24'd0; rdq_una <= 1'b0; pd_una_q <= 1'b0; cmax_q <= 24'd0;
    end else begin
      rdout_q <= o_rdout; ld_q <= ld_valid; chk_v_q <= chk_valid; flush_q <= flush_en; ist_q <= o_ist; una_q <= o_una; txp_q <= o_txp; rdq_una <= rdm[su]; pd_una_q <= pdone[su]; cmax_q <= cmax;
      sq_hold_q <= sq_valid && !sq_pop; sq_op_q <= sq_op; sq_len_q <= sq_len;
      if (sq_pop) sq_seq <= sq_seq + 32'd1;
      nxt_q <= o_nxt;
      if (o_nxt != nxt_q && !ld_q) rdm[slot(nxt_q)] <= (sq_op_q == 2'd3);
      if (o_una != una_q && !ld_q) rdm[slot(una_q)] <= 1'b0;
      if (ld_valid) begin cmax <= PSN0; amax <= PSN0; end
      else begin
        if (ack_ok_s && psn_lt(cmax, ack_cn)) cmax <= ack_cn;
        if (ack_ok_s && psn_lt(amax, ack_an)) amax <= ack_an;
      end
      if (place_done_valid) pdone[slot(place_done_psn)] <= 1'b1;
      if (o_una != una_q) pdone[slot(una_q)] <= 1'b0;
      if (cqe_go) cq_next <= cq_next + 32'd1;
      // WQEs that passed the local check: zero-length SEND (IDLE -> SEG) or checked (CHK -> SEG)
      if (o_ist == 2'd2 && (ist_q == 2'd0 || ist_q == 2'd1)) okseg <= okseg + segs(sq_op, sq_len);
    end
  end

  always @(posedge clk) if (!init && !first) begin
    if (VAC == 0) begin
      // Q1
      Q1a: assert(occ_w <= W24);
      Q1b: assert(!(psn_lt(o_txp, o_una)) && !(psn_lt(o_nxt, o_txp)));           // una <= txp <= nxt (modular)
      Q1c: assert(!tx_valid || (`SFR_H_PSN(tx_sh) == o_txp && o_txp != o_nxt && !psn_lt(o_txp, o_una)));
      Q1d: assert({20'd0, win_occ} == occ_w);
      // Q2
      Q2a: assert(o_rdout <= MAXRD);
      Q2b: assert(ld_q || {28'd0, rdout_q} == nrd);
      // Q3
      Q3a: assert(!(cqe_go && cmp_status == `SFR_CQ_OK && cmp_op != 4'd3) || psn_lt(o_una, cmax));
      Q3b: assert(!(cqe_go && cmp_status == `SFR_CQ_OK && cmp_op == 4'd3) || pdone[su]);
      Q3c: assert(!run || o_una == una_q || (rdq_una ? pd_una_q : psn_lt(una_q, cmax_q)));      // una advanced over a committed / placed entry only
      // Q7 (review fix F-07 / S-01): the commit / accept frontiers are never lost -- not even when the ACK and a retirement fall in the same cycle
      Q7a: assert(!run || !psn_lt(o_una, cmax) || !psn_lt(o_chi, cmax));
      Q7b: assert(!run || !psn_lt(o_una, amax) || !psn_lt(o_ahi, amax));
      // Q4
      Q4a: assert(!cqe_go || cmp_wr_id == {32'd0, cq_next});
      Q4b: assert(cq_next <= sq_seq + {31'd0, o_ist == 2'd2});     // a CQE exists only for a popped WQE, or for the head WQE that already has its context (mid-segmentation failure)
      // Q5
      Q5a: assert({8'd0, made_w} <= okseg);
    end else begin
      case (VAC)
        1: assert(!(cqe_go && cmp_status == `SFR_CQ_OK && cmp_op == 4'd2));      // a WRITE completes OK
        2: assert(!(cqe_go && cmp_status == `SFR_CQ_OK && cmp_op == 4'd3));      // a READ completes OK
        3: assert(!(occ_w == W24));                                        // the window fills
        4: assert(!(ev_retry_timeout && o_txp != o_nxt));                        // a timeout rewinds the transmit pointer
        5: assert(!(run && o_una != una_q && txp_q == una_q));                 // an entry retires while txp points at it (the bug-3 corner; excludes the PSN load)
        6: assert(!(o_rdout == MAXRD));                                          // two READs outstanding
        7: assert(!(cqe_go && cmp_status == `SFR_CQ_LOC_PROT));                  // a local-check failure completes with LOC_PROT_ERR
        8: assert(!(cqe_go && cmp_status == `SFR_CQ_FLUSH));                     // a flush CQE
        9: assert(!(tx_valid && tx_ready && ev_tx_retx));                        // a retransmitted frame is sent
        10: assert(!(ev_retry_nak && o_nxt != o_una));                           // a SEQ_ERR NAK rewinds
        11: assert(!(ev_retry_rnr));                                             // an RNR wait ends
        12: assert(!(cqe_go && cmp_status == `SFR_CQ_RETRY));                    // retry exhaustion fails a WQE
      endcase
    end
  end
endmodule
