// =============================================================================
// Formal harness: sf_rdma_wqe   (send / receive queues with post-time validation)               TRANSPORT_SPEC 6.1-6.3, 7.5, 12.1-12.2
//
// Claims (plain English):
//   W1  The post status returned one cycle after a handshake is EXACTLY the spec 6.3 table in the stated precedence
//       STATE, OPCODE, FIELDS, LEN, RANGE (first match wins), for ALL inputs.  An independent specification (129-bit arithmetic) is
//       evaluated at the handshake and compared with sq_post_rsp_status / rq_post_rsp_status; rsp_valid pulses only after a handshake.
//   W2  An unsupported SQ opcode (not 1, 2, 3 -- including 5, 9, 13 whose low two bits alias a valid opcode) is NEVER accepted into
//       the queue: sq_take implies QP state RTS and op in {1,2,3} (and the stored head opcode is never 0).               [6.3, 7.5]
//   W3  A rejected post takes no slot and no credit: sq_take / rq_take are high exactly for the OK handshakes; occupancy changes
//       only by accepted posts and pops (shadow counters).                                                                  [6.3]
//   W4  An accepted post appears at the head in FIFO order with every field intact: the K-th accepted SQ post (and K-th RQ post), K
//       free, comes out as the K-th popped head with identical op / wr_id / addr / key / len fields.                          [12.1]
//   W5  Back-pressure, not error: a full queue or missing credit deasserts post_ready; a handshake never needs a credit that is not
//       there: take -> credits_ge1, and take_sq && take_rq -> credits_ge2 (this discharges assumption E1 of fv_completion). [6.3, 12.1, 12.2]
//   W6  Occupancy never exceeds the depth; head_valid == (occupancy != 0); QP-reset `clear` empties both queues.
// Environment: all post fields, credit flags (credits_ge2 -> credits_ge1), pops and qp_state are free; `clear` only in qp_state DRAIN
//   (sf_rdma_qp raises q_clear only while draining, where no post can be accepted -- checked here as W2/W1 STATE rows).
// Instance: SQ_DEPTH = RQ_DEPTH = 4 (the induction lemmas observe the storage words through OBS wires), MAX_MSG_BYTES = 1 MiB (real value).
// Reset in cycle 0 only.  KMAX = 0: K free (k-induction); KMAX > 0: K < KMAX (BMC).  VAC != 0: reachability witnesses (MUST fail).
// (generated skeleton: the OBS list is mechanical; this file is the source of record)
// =============================================================================
`default_nettype none
module fv_wqe #(
  parameter KMAX = 0,
  parameter VAC  = 0
) (
  input wire clk, input wire clear, input wire [2:0] qp_state,
  input wire sq_post_valid, input wire [3:0] sq_post_op, input wire [63:0] sq_post_wr_id, input wire [63:0] sq_post_laddr, input wire [31:0] sq_post_lkey,
  input wire [31:0] sq_post_len, input wire [63:0] sq_post_raddr, input wire [31:0] sq_post_rkey, input wire [3:0] sq_post_flags,
  input wire rq_post_valid, input wire [63:0] rq_post_wr_id, input wire [63:0] rq_post_addr, input wire [31:0] rq_post_lkey, input wire [31:0] rq_post_len,
  input wire credits_ge1, input wire credits_ge2, input wire sq_pop, input wire rq_pop
);
  localparam DEPTH = 4;
  localparam [31:0] MAXB = 32'd1048576;
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  wire sq_post_ready, sq_post_rsp_valid, rq_post_ready, rq_post_rsp_valid, sq_take, rq_take, sq_head_valid, rq_head_valid;
  wire [2:0] sq_post_rsp_status, rq_post_rsp_status;
  wire [1:0] sq_head_op; wire [63:0] sq_head_wr_id, sq_head_laddr, sq_head_raddr; wire [31:0] sq_head_lkey, sq_head_len, sq_head_rkey;
  wire [63:0] rq_head_wr_id, rq_head_addr; wire [31:0] rq_head_lkey, rq_head_len;
  wire [2:0] sq_occ, rq_occ;
  wire ev_rej_opcode, ev_rej_state, ev_rej_len, ev_rej_fields, ev_rej_range, ev_stall_sqfull, ev_stall_cqcred;
  sf_rdma_wqe #(.SQ_DEPTH(DEPTH), .RQ_DEPTH(DEPTH), .MAX_MSG_BYTES(1048576)) dut (
    .clk(clk), .rst_n(rst_n), .clear(clear), .qp_state(qp_state),
    .sq_post_valid(sq_post_valid), .sq_post_ready(sq_post_ready), .sq_post_op(sq_post_op), .sq_post_wr_id(sq_post_wr_id), .sq_post_laddr(sq_post_laddr),
    .sq_post_lkey(sq_post_lkey), .sq_post_len(sq_post_len), .sq_post_raddr(sq_post_raddr), .sq_post_rkey(sq_post_rkey), .sq_post_flags(sq_post_flags),
    .sq_post_rsp_valid(sq_post_rsp_valid), .sq_post_rsp_status(sq_post_rsp_status),
    .rq_post_valid(rq_post_valid), .rq_post_ready(rq_post_ready), .rq_post_wr_id(rq_post_wr_id), .rq_post_addr(rq_post_addr), .rq_post_lkey(rq_post_lkey),
    .rq_post_len(rq_post_len), .rq_post_rsp_valid(rq_post_rsp_valid), .rq_post_rsp_status(rq_post_rsp_status),
    .credits_ge1(credits_ge1), .credits_ge2(credits_ge2), .sq_take(sq_take), .rq_take(rq_take),
    .sq_head_valid(sq_head_valid), .sq_pop(sq_pop), .sq_head_op(sq_head_op), .sq_head_wr_id(sq_head_wr_id), .sq_head_laddr(sq_head_laddr),
    .sq_head_lkey(sq_head_lkey), .sq_head_len(sq_head_len), .sq_head_raddr(sq_head_raddr), .sq_head_rkey(sq_head_rkey),
    .rq_head_valid(rq_head_valid), .rq_pop(rq_pop), .rq_head_wr_id(rq_head_wr_id), .rq_head_addr(rq_head_addr), .rq_head_lkey(rq_head_lkey), .rq_head_len(rq_head_len),
    .sq_occ(sq_occ), .rq_occ(rq_occ), .ev_rej_opcode(ev_rej_opcode), .ev_rej_state(ev_rej_state), .ev_rej_len(ev_rej_len), .ev_rej_fields(ev_rej_fields),
    .ev_rej_range(ev_rej_range), .ev_stall_sqfull(ev_stall_sqfull), .ev_stall_cqcred(ev_stall_cqcred));

  // observation of internal storage for the induction lemmas
  wire [2:0] o_swp, o_srp, o_rwp, o_rrp;   // OBS o_swp dut.s_wp
                                           // OBS o_srp dut.s_rp
                                           // OBS o_rwp dut.r_wp
                                           // OBS o_rrp dut.r_rp
  wire [1:0] o_sop0;   // OBS o_sop0 dut.s_op[0]
  wire [1:0] o_sop1;   // OBS o_sop1 dut.s_op[1]
  wire [1:0] o_sop2;   // OBS o_sop2 dut.s_op[2]
  wire [1:0] o_sop3;   // OBS o_sop3 dut.s_op[3]
  wire [63:0] o_swr0;   // OBS o_swr0 dut.s_wr[0]
  wire [63:0] o_swr1;   // OBS o_swr1 dut.s_wr[1]
  wire [63:0] o_swr2;   // OBS o_swr2 dut.s_wr[2]
  wire [63:0] o_swr3;   // OBS o_swr3 dut.s_wr[3]
  wire [63:0] o_sla0;   // OBS o_sla0 dut.s_la[0]
  wire [63:0] o_sla1;   // OBS o_sla1 dut.s_la[1]
  wire [63:0] o_sla2;   // OBS o_sla2 dut.s_la[2]
  wire [63:0] o_sla3;   // OBS o_sla3 dut.s_la[3]
  wire [31:0] o_slk0;   // OBS o_slk0 dut.s_lk[0]
  wire [31:0] o_slk1;   // OBS o_slk1 dut.s_lk[1]
  wire [31:0] o_slk2;   // OBS o_slk2 dut.s_lk[2]
  wire [31:0] o_slk3;   // OBS o_slk3 dut.s_lk[3]
  wire [31:0] o_sln0;   // OBS o_sln0 dut.s_ln[0]
  wire [31:0] o_sln1;   // OBS o_sln1 dut.s_ln[1]
  wire [31:0] o_sln2;   // OBS o_sln2 dut.s_ln[2]
  wire [31:0] o_sln3;   // OBS o_sln3 dut.s_ln[3]
  wire [63:0] o_sra0;   // OBS o_sra0 dut.s_ra[0]
  wire [63:0] o_sra1;   // OBS o_sra1 dut.s_ra[1]
  wire [63:0] o_sra2;   // OBS o_sra2 dut.s_ra[2]
  wire [63:0] o_sra3;   // OBS o_sra3 dut.s_ra[3]
  wire [31:0] o_srk0;   // OBS o_srk0 dut.s_rk[0]
  wire [31:0] o_srk1;   // OBS o_srk1 dut.s_rk[1]
  wire [31:0] o_srk2;   // OBS o_srk2 dut.s_rk[2]
  wire [31:0] o_srk3;   // OBS o_srk3 dut.s_rk[3]
  wire [63:0] o_rwr0;   // OBS o_rwr0 dut.r_wr[0]
  wire [63:0] o_rwr1;   // OBS o_rwr1 dut.r_wr[1]
  wire [63:0] o_rwr2;   // OBS o_rwr2 dut.r_wr[2]
  wire [63:0] o_rwr3;   // OBS o_rwr3 dut.r_wr[3]
  wire [63:0] o_rad0;   // OBS o_rad0 dut.r_ad[0]
  wire [63:0] o_rad1;   // OBS o_rad1 dut.r_ad[1]
  wire [63:0] o_rad2;   // OBS o_rad2 dut.r_ad[2]
  wire [63:0] o_rad3;   // OBS o_rad3 dut.r_ad[3]
  wire [31:0] o_rlk0;   // OBS o_rlk0 dut.r_lk[0]
  wire [31:0] o_rlk1;   // OBS o_rlk1 dut.r_lk[1]
  wire [31:0] o_rlk2;   // OBS o_rlk2 dut.r_lk[2]
  wire [31:0] o_rlk3;   // OBS o_rlk3 dut.r_lk[3]
  wire [31:0] o_rln0;   // OBS o_rln0 dut.r_ln[0]
  wire [31:0] o_rln1;   // OBS o_rln1 dut.r_ln[1]
  wire [31:0] o_rln2;   // OBS o_rln2 dut.r_ln[2]
  wire [31:0] o_rln3;   // OBS o_rln3 dut.r_ln[3]

  // ---------------------------------------------------------------- independent specification of 6.3 (wide arithmetic)
  localparam [2:0] ST_RESET = 3'd0, ST_INIT = 3'd1, ST_RTR = 3'd2, ST_RTS = 3'd3, ST_DRAIN = 3'd5;
  wire [128:0] sq_end = {65'd0, sq_post_raddr} + {97'd0, sq_post_len};
  wire [128:0] rq_end = {65'd0, rq_post_addr}  + {97'd0, rq_post_len};
  wire sq_rw      = (sq_post_op == 4'd2) || (sq_post_op == 4'd3);                 // WRITE / READ need len>=1 and a remote range
  wire sq_op_ok   = (sq_post_op == 4'd1) || sq_rw;
  wire [128:0] two64 = 129'h1_0000_0000_0000_0000;
  reg [2:0] sq_spec, rq_spec;
  always @* begin
    sq_spec = 3'd0;                                            // POST_OK
    if      (qp_state != ST_RTS)                                  sq_spec = 3'd2;   // POST_ERR_STATE
    else if (!sq_op_ok)                                           sq_spec = 3'd1;   // POST_ERR_OPCODE
    else if (sq_post_flags != 4'd0)                               sq_spec = 3'd4;   // POST_ERR_FIELDS
    else if (sq_post_len > MAXB || (sq_rw && sq_post_len == 32'd0)) sq_spec = 3'd3; // POST_ERR_LEN
    else if (sq_rw && sq_end > two64)                             sq_spec = 3'd5;   // POST_ERR_RANGE
    rq_spec = 3'd0;
    if      (!(qp_state == ST_INIT || qp_state == ST_RTR || qp_state == ST_RTS)) rq_spec = 3'd2;
    else if (rq_post_len > MAXB)                                  rq_spec = 3'd3;
    else if (rq_end > two64)                                      rq_spec = 3'd5;
  end

  // ---------------------------------------------------------------- shadow state
  wire sq_hs = sq_post_valid && sq_post_ready;
  wire rq_hs = rq_post_valid && rq_post_ready;
  wire sq_ok = sq_hs && sq_spec == 3'd0;
  wire rq_ok = rq_hs && rq_spec == 3'd0;
  wire sq_popv = sq_pop && sq_head_valid;
  wire rq_popv = rq_pop && rq_head_valid;

  reg        hs_sq_q, hs_rq_q;
  reg [2:0]  exp_sq_q, exp_rq_q;
  reg [31:0] spush, spop, rpush, rpop;
  reg        stag, rtag;
  reg [1:0]  t_sop; reg [63:0] t_swr, t_sla, t_sra; reg [31:0] t_slk, t_sln, t_srk;
  reg [63:0] t_rwr, t_rad; reg [31:0] t_rlk, t_rln;
  (* anyconst *) reg [31:0] K;
  always @(posedge clk) if (KMAX != 0) assume(K < KMAX);
  always @(posedge clk) if (!init) begin
    assume(!credits_ge2 || credits_ge1);
    assume(!clear || qp_state == ST_DRAIN);
  end

  always @(posedge clk) begin
    if (init) begin
      hs_sq_q <= 1'b0; hs_rq_q <= 1'b0; exp_sq_q <= 3'd0; exp_rq_q <= 3'd0; spush <= 32'd0; spop <= 32'd0; rpush <= 32'd0; rpop <= 32'd0; stag <= 1'b0; rtag <= 1'b0;
      t_sop <= 2'd0; t_swr <= 64'd0; t_sla <= 64'd0; t_sra <= 64'd0; t_slk <= 32'd0; t_sln <= 32'd0; t_srk <= 32'd0; t_rwr <= 64'd0; t_rad <= 64'd0; t_rlk <= 32'd0; t_rln <= 32'd0;
    end else begin
      hs_sq_q <= sq_hs; hs_rq_q <= rq_hs; exp_sq_q <= sq_spec; exp_rq_q <= rq_spec;
      if (clear) begin
        spush <= 32'd0; spop <= 32'd0; rpush <= 32'd0; rpop <= 32'd0; stag <= 1'b0; rtag <= 1'b0;
      end else begin
        if (sq_ok) begin
          spush <= spush + 32'd1;
          if (spush == K) begin stag <= 1'b1; t_sop <= sq_post_op[1:0]; t_swr <= sq_post_wr_id; t_sla <= sq_post_laddr; t_slk <= sq_post_lkey; t_sln <= sq_post_len; t_sra <= sq_post_raddr; t_srk <= sq_post_rkey; end
        end
        if (sq_popv) spop <= spop + 32'd1;
        if (rq_ok) begin
          rpush <= rpush + 32'd1;
          if (rpush == K) begin rtag <= 1'b1; t_rwr <= rq_post_wr_id; t_rad <= rq_post_addr; t_rlk <= rq_post_lkey; t_rln <= rq_post_len; end
        end
        if (rq_popv) rpop <= rpop + 32'd1;
      end
    end
  end

  // storage word K mod 4 (induction lemma only)
  wire [1:0] ki = K[1:0];
  wire [1:0] x_sop = (ki == 2'd0) ? o_sop0 : (ki == 2'd1) ? o_sop1 : (ki == 2'd2) ? o_sop2 : o_sop3;
  wire [63:0] x_swr = (ki == 2'd0) ? o_swr0 : (ki == 2'd1) ? o_swr1 : (ki == 2'd2) ? o_swr2 : o_swr3;
  wire [63:0] x_sla = (ki == 2'd0) ? o_sla0 : (ki == 2'd1) ? o_sla1 : (ki == 2'd2) ? o_sla2 : o_sla3;
  wire [31:0] x_slk = (ki == 2'd0) ? o_slk0 : (ki == 2'd1) ? o_slk1 : (ki == 2'd2) ? o_slk2 : o_slk3;
  wire [31:0] x_sln = (ki == 2'd0) ? o_sln0 : (ki == 2'd1) ? o_sln1 : (ki == 2'd2) ? o_sln2 : o_sln3;
  wire [63:0] x_sra = (ki == 2'd0) ? o_sra0 : (ki == 2'd1) ? o_sra1 : (ki == 2'd2) ? o_sra2 : o_sra3;
  wire [31:0] x_srk = (ki == 2'd0) ? o_srk0 : (ki == 2'd1) ? o_srk1 : (ki == 2'd2) ? o_srk2 : o_srk3;
  wire [63:0] x_rwr = (ki == 2'd0) ? o_rwr0 : (ki == 2'd1) ? o_rwr1 : (ki == 2'd2) ? o_rwr2 : o_rwr3;
  wire [63:0] x_rad = (ki == 2'd0) ? o_rad0 : (ki == 2'd1) ? o_rad1 : (ki == 2'd2) ? o_rad2 : o_rad3;
  wire [31:0] x_rlk = (ki == 2'd0) ? o_rlk0 : (ki == 2'd1) ? o_rlk1 : (ki == 2'd2) ? o_rlk2 : o_rlk3;
  wire [31:0] x_rln = (ki == 2'd0) ? o_rln0 : (ki == 2'd1) ? o_rln1 : (ki == 2'd2) ? o_rln2 : o_rln3;
  wire [31:0] s_cnt = spush - spop;
  wire [31:0] r_cnt = rpush - rpop;
  wire s_inq = stag && ((K - spop) < s_cnt);
  wire r_inq = rtag && ((K - rpop) < r_cnt);

  always @(posedge clk) if (!init) begin
    if (VAC == 0) begin
      // W1
      W1a: assert(sq_post_rsp_valid == hs_sq_q);
      W1b: assert(rq_post_rsp_valid == hs_rq_q);
      W1c: assert(!hs_sq_q || sq_post_rsp_status == exp_sq_q);
      W1d: assert(!hs_rq_q || rq_post_rsp_status == exp_rq_q);
      // W2
      W2a: assert(!sq_take || (qp_state == ST_RTS && sq_op_ok));
      W2b: assert(!sq_head_valid || sq_head_op != 2'd0);
      // W3
      W3a: assert(sq_take == sq_ok);
      W3b: assert(rq_take == rq_ok);
      W3c: assert(s_cnt == {29'd0, sq_occ} && r_cnt == {29'd0, rq_occ});
      // W4
      W4a: assert(!(sq_popv && stag && spop == K) || (sq_head_op == t_sop && sq_head_wr_id == t_swr && sq_head_laddr == t_sla && sq_head_lkey == t_slk &&
                                                       sq_head_len == t_sln && sq_head_raddr == t_sra && sq_head_rkey == t_srk));
      W4b: assert(!(rq_popv && rtag && rpop == K) || (rq_head_wr_id == t_rwr && rq_head_addr == t_rad && rq_head_lkey == t_rlk && rq_head_len == t_rln));
      W4c: assert(!(sq_popv && spop == K) || stag);
      W4d: assert(!(rq_popv && rpop == K) || rtag);
      // W5
      W5a: assert(!sq_post_ready || (sq_occ != 3'd4 && credits_ge1));
      W5b: assert(!rq_post_ready || (rq_occ != 3'd4 && credits_ge1));
      W5c: assert(!(sq_take || rq_take) || credits_ge1);
      W5d: assert(!(sq_take && rq_take) || credits_ge2);
      // W6
      W6a: assert(sq_occ <= 3'd4 && rq_occ <= 3'd4);
      W6b: assert(sq_head_valid == (sq_occ != 3'd0) && rq_head_valid == (rq_occ != 3'd0));
      // induction lemmas (state <-> shadow)
      L1: assert(o_swp == spush[2:0] && o_srp == spop[2:0] && o_rwp == rpush[2:0] && o_rrp == rpop[2:0]);
      L2: assert(!s_inq || (x_sop == t_sop && x_swr == t_swr && x_sla == t_sla && x_slk == t_slk && x_sln == t_sln && x_sra == t_sra && x_srk == t_srk));
      L3: assert(!r_inq || (x_rwr == t_rwr && x_rad == t_rad && x_rlk == t_rlk && x_rln == t_rln));
      L4: assert(!((K - spop) < s_cnt) || stag);
      L5: assert(!((K - rpop) < r_cnt) || rtag);
      L6: assert((!(({1'b0, 2'd0 - o_srp[1:0]}) < {1'b0, sq_occ}) || o_sop0 != 2'd0) && (!(({1'b0, 2'd1 - o_srp[1:0]}) < {1'b0, sq_occ}) || o_sop1 != 2'd0) &&
                 (!(({1'b0, 2'd2 - o_srp[1:0]}) < {1'b0, sq_occ}) || o_sop2 != 2'd0) && (!(({1'b0, 2'd3 - o_srp[1:0]}) < {1'b0, sq_occ}) || o_sop3 != 2'd0));  // every stored opcode is non-zero
    end else begin
      case (VAC)
        1:  assert(!sq_ok);                                              // an SQ post is accepted
        2:  assert(!(hs_sq_q && sq_post_rsp_status == 3'd1));            // POST_ERR_OPCODE reachable
        3:  assert(!(hs_sq_q && sq_post_rsp_status == 3'd2));            // POST_ERR_STATE
        4:  assert(!(hs_sq_q && sq_post_rsp_status == 3'd3));            // POST_ERR_LEN
        5:  assert(!(hs_sq_q && sq_post_rsp_status == 3'd4));            // POST_ERR_FIELDS
        6:  assert(!(hs_sq_q && sq_post_rsp_status == 3'd5));            // POST_ERR_RANGE
        7:  assert(!rq_ok);                                              // an RQ post is accepted
        8:  assert(!(hs_rq_q && rq_post_rsp_status == 3'd2));            // RQ POST_ERR_STATE
        9:  assert(!(hs_rq_q && rq_post_rsp_status == 3'd3));            // RQ POST_ERR_LEN
        10: assert(!(hs_rq_q && rq_post_rsp_status == 3'd5));            // RQ POST_ERR_RANGE
        11: assert(!(sq_post_valid && !sq_post_ready && sq_occ == 3'd4)); // SQ full: post back-pressured
        12: assert(!(sq_hs && sq_post_op == 4'd5 && qp_state == ST_RTS)); // an aliasing unsupported opcode (5) is presented to a ready queue in RTS
        13: assert(!(sq_popv && stag && spop == K));                     // the tagged SQ post is popped (W4a exercised)
        14: assert(!(rq_popv && rtag && rpop == K));                     // the tagged RQ post is popped (W4b exercised)
        15: assert(!(sq_take && rq_take));                               // both queues take a credit in one cycle
        16: assert(!(sq_post_valid && !sq_post_ready && !credits_ge1 && sq_occ != 3'd4)); // credit back-pressure (no credit, queue not full)
      endcase
    end
  end
endmodule
