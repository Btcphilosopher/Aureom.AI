// =============================================================================
// Formal harness: sf_rdma_rx   (receive processor + responder)   REMOTE-WRITE SAFETY               TRANSPORT_SPEC 7.2, 7.4, 9.2-9.4, 10, 8.4
//
// Free environment, protocol-legal: symbolic header frames (every field free; the header is stable until popped), registry answers
// (exactly one cycle after a check request; grant / rid / pa / ctx free), DMA ready / done, receive-queue head (stable until popped),
// requester lookups, QP state (en_req / en_resp / flush_en consistent, flush sticky), fatal_mode = the registered fatal decision (as the
// ACK generator provides it).  Claims (all observed through ports + the frame-FSM state `st`):
//   X1  REMOTE-WRITE SAFETY.  A WRITE DMA command (dw_cmd_valid && !dw_cmd_discard) is issued only
//       (i)   for a REQUEST frame whose PSN equals epsn at that time (in order) and only when requests are enabled and no fatal decision
//             is pending, or for a READ_RESP placement the requester lookup accepted (spec 7.3: entry outstanding, moff = expected,
//             moff+paylen <= mlen); duplicates (psn before epsn) and out-of-sequence frames (psn after epsn) NEVER produce one;
//       (ii)  in the cycle in which the registry answer was `rsp_ok` for the check issued for THIS frame (op / key / va / len / pd of the
//             check match the frame, 7.2), with the command's pa / rid / ctx equal to the granted ones (+ moff for a SEND segment);
//             a SEND continuation uses the grant of its first segment (pa = first grant pa + moff);
//       (iii) never when the frame decision is a fatal NAK in the same cycle.
//   X2  epsn increments by exactly 1 and only on an accepted request (ev_accept), never decrements; an accept needs an in-order
//       frame and its grant; cpsn advances by exactly 1 per ev_commit, only over an entry whose completion (write done / read done /
//       no DMA needed) has been signalled; cpsn <= epsn (modular) and epsn - cpsn <= WINDOW at all times.                  [9.2]
//   X3  A fatal NAK decision (ag_fatal_set) never coincides with a registry grant being used (no WRITE / READ command, no accept); a grant
//       that arrives while the QP is flushed / fatal_mode is RELEASED (rel_valid with that rid) and discarded.             [8.4, 10.3]
//   X4  An in-order SEND first segment with no receive WQE (rq_valid = 0) is never accepted: no accept, no write, no RQ pop (RNR).  [7.1]
//   X5  An unsupported reserved opcode (0x04-0x0F), in order, never produces a DMA WRITE command and always raises ag_fatal_set with
//       INV_REQ (code 3) when the frame is popped.                                                                          [7.4(1), 7.5]
//   X6  Duplicate / out-of-sequence request frames have no effect: no accept, no RQ pop, no WRITE, no fresh READ command.   [9.3, 10.1]
// Environment assumptions: reset in cycle 0 only; clear = 0 (QP-reset flush not exercised); ld pulse in cycle 1 sets epsn = cpsn = PSN0
//   (free 24-bit, so modular wrap-around is exercised); paylen < 16, mlen < 32, moff < 32 (state-space bound; the comparisons are width-uniform);
//   dw_done_valid only with an outstanding WRITE command, rg_done_valid only for an outstanding READ entry in the window.
// Instance: WINDOW = 4, PA_W = 8, PD_W = 2, RID_W = 1, CTX_W = 1, TAGQ = 4, MAX_MSG_BYTES = 1 MiB.  BMC from reset.   VAC != 0: witnesses.
// =============================================================================
`include "sf_rdma_defs.svh"
`default_nettype none
module fv_rx_safety #(
  parameter VAC = 0
) (
  input wire clk,
  input wire en_req_f, input wire en_resp_f, input wire flush_f,
  input wire rxh_valid, input wire [271:0] rxh_sh,
  input wire dw_cmd_ready, input wire dw_done_valid, input wire dw_done_err, input wire dw_viol,
  input wire rsp_ok, input wire rsp_rid, input wire [7:0] rsp_pa, input wire rsp_ctx,
  input wire rq_valid, input wire [63:0] rq_wr_id, input wire [63:0] rq_addr, input wire [31:0] rq_lkey, input wire [31:0] rq_len,
  input wire cmp_ready,
  input wire rr_found, input wire [31:0] rr_exp_off, input wire [31:0] rr_mlen, input wire [7:0] rr_lpa, input wire rr_rid, input wire rr_ctx,
  input wire rdq_ready, input wire rg_done_valid, input wire [23:0] rg_done_psn
);
  localparam W = 4, PA_W = 8;
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;
  reg first = 1'b1;                                   // cycle 1 = the PSN load pulse
  always @(posedge clk) if (!init) first <= 1'b0;
  (* anyconst *) reg [23:0] PSN0;
  (* anyconst *) reg [1:0]  qp_pd;                  // the QP's protection domain: constant (trusted configuration)
  wire ld_valid = !init && first;

  // ---------------------------------------------------------------- legal QP state
  reg flush_q;
  reg run = 1'b0; always @(posedge clk) if (!init && !first) run <= 1'b1;           // requests / responses are enabled only after the PSN load
  wire en_req = en_req_f && run, en_resp = en_resp_f && run, flush_en = flush_f;
  // ---------------------------------------------------------------- DUT
  wire rxh_pop, dw_cmd_valid, dw_cmd_discard, chk_valid, rsp_valid, rel_c_valid, rel_a_valid, rel_f_valid, place_err_valid, place_idle, rq_pop, cmp_valid, ack_valid, rr_accept, place_done_valid, rdq_valid, rdq_replay;
  wire ag_ack_set, ag_nak_set, ag_fatal_set, ag_replay_set, quiet, err_req, ev_dup, ev_oos, ev_resp_drop, ev_accept, ev_commit, ev_unsupp, ev_dup_rd_fault, ev_nak_badcode;
  wire [PA_W-1:0] dw_cmd_pa; wire [15:0] dw_cmd_len; wire [0:0] dw_cmd_rid, dw_cmd_ctx;
  wire [1:0] chk_op; wire [31:0] chk_key, chk_len; wire [1:0] chk_pd; wire [63:0] chk_va; wire [0:0] rel_c_rid, rel_a_rid, rel_f_rid; wire [1:0] place_err_idx;
  wire [63:0] cmp_wr_id; wire [3:0] cmp_op, cmp_status; wire [31:0] cmp_len;
  wire [23:0] ack_cn, ack_an, rr_psn, place_done_psn, rdq_psn, cpsn, epsn; wire [3:0] ack_code, ag_nak_code, ag_fatal_code, err_cause;
  wire [15:0] rr_accept_len; wire [PA_W-1:0] rdq_pa; wire [31:0] rdq_len, rdq_moff, rdq_mlen; wire [0:0] rdq_rid, rdq_ctx;
  wire [3:0] ring_occ;
  wire fatal_mode;
  sf_rdma_rx #(.WINDOW(W), .MTU(256), .PA_W(PA_W), .PD_W(2), .RID_W(1), .CTX_W(1), .TAGQ(4), .MAX_MSG_BYTES(1048576)) dut (
    .clk(clk), .rst_n(rst_n), .clear(1'b0), .en_req(en_req), .en_resp(en_resp), .flush_en(flush_en), .ld_valid(ld_valid), .ld_psn(PSN0), .qp_pd(qp_pd),
    .rxh_valid(rxh_valid), .rxh_sh(rxh_sh), .rxh_pop(rxh_pop),
    .dw_cmd_valid(dw_cmd_valid), .dw_cmd_ready(dw_cmd_ready), .dw_cmd_discard(dw_cmd_discard), .dw_cmd_pa(dw_cmd_pa), .dw_cmd_len(dw_cmd_len), .dw_cmd_rid(dw_cmd_rid), .dw_cmd_ctx(dw_cmd_ctx),
    .dw_done_valid(dw_done_valid), .dw_done_err(dw_done_err), .dw_viol(dw_viol),
    .chk_valid(chk_valid), .chk_op(chk_op), .chk_key(chk_key), .chk_pd(chk_pd), .chk_va(chk_va), .chk_len(chk_len),
    .rsp_valid(rsp_valid), .rsp_ok(rsp_ok), .rsp_rid(rsp_rid), .rsp_pa(rsp_pa), .rsp_ctx(rsp_ctx), .rel_c_valid(rel_c_valid), .rel_c_rid(rel_c_rid), .rel_a_valid(rel_a_valid), .rel_a_rid(rel_a_rid), .rel_f_valid(rel_f_valid), .rel_f_rid(rel_f_rid),
    .rq_valid(rq_valid), .rq_pop(rq_pop), .rq_wr_id(rq_wr_id), .rq_addr(rq_addr), .rq_lkey(rq_lkey), .rq_len(rq_len),
    .cmp_valid(cmp_valid), .cmp_ready(cmp_ready), .cmp_wr_id(cmp_wr_id), .cmp_op(cmp_op), .cmp_status(cmp_status), .cmp_len(cmp_len),
    .ack_valid(ack_valid), .ack_cn(ack_cn), .ack_an(ack_an), .ack_code(ack_code), .rr_psn(rr_psn), .rr_found(rr_found), .rr_exp_off(rr_exp_off), .rr_mlen(rr_mlen),
    .rr_lpa(rr_lpa), .rr_rid(rr_rid), .rr_ctx(rr_ctx), .rr_accept(rr_accept), .rr_accept_len(rr_accept_len), .place_done_valid(place_done_valid), .place_done_psn(place_done_psn), .place_err_valid(place_err_valid), .place_err_idx(place_err_idx), .place_idle(place_idle),
    .rdq_valid(rdq_valid), .rdq_ready(rdq_ready), .rdq_psn(rdq_psn), .rdq_pa(rdq_pa), .rdq_len(rdq_len), .rdq_moff(rdq_moff), .rdq_mlen(rdq_mlen), .rdq_rid(rdq_rid), .rdq_ctx(rdq_ctx),
    .rdq_replay(rdq_replay), .rg_done_valid(rg_done_valid), .rg_done_psn(rg_done_psn),
    .ag_ack_set(ag_ack_set), .ag_nak_set(ag_nak_set), .ag_nak_code(ag_nak_code), .ag_fatal_set(ag_fatal_set), .ag_fatal_code(ag_fatal_code), .ag_replay_set(ag_replay_set), .fatal_mode(fatal_mode),
    .cpsn(cpsn), .epsn(epsn), .quiet(quiet), .err_req(err_req), .err_cause(err_cause), .ring_occ(ring_occ),
    .ev_dup(ev_dup), .ev_oos(ev_oos), .ev_resp_drop(ev_resp_drop), .ev_accept(ev_accept), .ev_commit(ev_commit), .ev_unsupp(ev_unsupp), .ev_dup_rd_fault(ev_dup_rd_fault), .ev_nak_badcode(ev_nak_badcode));
  wire [1:0] o_st;      // OBS o_st dut.st

  // ---------------------------------------------------------------- header decode (spec 3.2 layout) and the frame classification
  wire [271:0] sh = rxh_sh;
  wire [7:0]   opc    = `SFR_H_OPC(sh);
  wire [7:0]   vf     = `SFR_H_VF(sh);
  wire [23:0]  psn    = `SFR_H_PSN(sh);
  wire [15:0]  paylen = `SFR_H_PAYLEN(sh);
  wire [31:0]  mlen   = `SFR_H_MLEN(sh);
  wire [31:0]  moff   = `SFR_H_MOFF(sh);
  wire [63:0]  hva    = `SFR_H_VA(sh);
  wire [31:0]  hrkey  = `SFR_H_RKEY(sh);
  wire is_send  = (opc == 8'h01), is_write = (opc == 8'h02), is_rreq = (opc == 8'h03), is_resv = (opc >= 8'h04) && (opc <= 8'h0F), is_rresp = (opc == 8'h10);
  wire is_reqop = is_send || is_write || is_rreq || is_resv;
  wire has_pl   = (paylen != 16'd0);
  wire f_first  = vf[0];
  wire in_order = (psn == epsn);
  wire [23:0] dpsn = psn - epsn;
  wire [32:0] mo_pl = {1'b0, moff} + {17'd0, paylen};
  wire resp_ok_spec = en_resp && rr_found && has_pl && (moff == rr_exp_off) && (mlen == rr_mlen) && (mo_pl <= {1'b0, mlen});

  // ---------------------------------------------------------------- environment (legal behaviours)
  reg fm_q;                                           // fatal_mode: the registered fatal decision
  assign fatal_mode = fm_q;
  reg hold_q; reg [271:0] sh_q;                       // header stability: a valid header not yet popped is presented unchanged
  reg rdy_q, cmdv_q; reg enreq_q; reg chk_v_q; reg rq_hold_q; reg [63:0] rqw_q, rqa_q; reg [31:0] rqk_q, rql_q;
  reg [3:0] sig, need, rdent;                         // ring-entry completion shadow: signalled / needs external completion / is a READ entry
  reg [3:0] tg_idx [0:3]; reg tg_kind [0:3]; reg [2:0] tg_wp, tg_rp;     // tag FIFO shadow (kind 1 = READ_RESP placement)
  assign rsp_valid = chk_v_q;                         // registry answers exactly one cycle after a check request
  wire [2:0] tg_cnt = tg_wp - tg_rp;
  always @(posedge clk) if (!init) begin
    assume(!(flush_en && (en_req || en_resp)));
    assume(!en_resp || en_req);
    assume(!flush_q || flush_en);
    assume(!(rdy_q && !cmdv_q) || dw_cmd_ready);            // command-FIFO room does not vanish without a push (only this unit pushes)
    assume(!(enreq_q && !en_req) || flush_en);              // requests are disabled only through ERR (flush)
    assume(!hold_q || (rxh_valid && rxh_sh == sh_q));
    assume(!rq_hold_q || (rq_valid && rq_wr_id == rqw_q && rq_addr == rqa_q && rq_lkey == rqk_q && rq_len == rql_q));
    assume(paylen < 16'd16 && mlen < 32'd32 && moff < 32'd32);
    assume(!dw_done_valid || tg_cnt != 3'd0);
    assume(!rg_done_valid || (rdent[rg_done_psn[1:0]] && !sig[rg_done_psn[1:0]]));      // READ-completion events only for outstanding READ entries
  end

  // ---------------------------------------------------------------- shadow
  wire wr_cmd = dw_cmd_valid && !dw_cmd_discard;
  wire [23:0] occ_w = epsn - cpsn;                     // (24-bit wire: `a - b <= W` would otherwise be widened to 32 bits before the subtraction)
  reg [23:0] epsn_q, cpsn_q; reg acc_q, com_q, ld_q;
  reg [1:0]  ck_op_q; reg [31:0] ck_key_q, ck_len_q; reg [1:0] ck_pd_q; reg [63:0] ck_va_q;       // the check request issued last cycle
  reg [1:0]  ck_kind_q;                               // 0 WRITE frame, 1 SEND first, 2 READ fresh, 3 READ duplicate
  reg        cur_v; reg [PA_W-1:0] cur_pa; reg cur_rid, cur_ctx;                                       // SEND message in progress: grant of its first segment
  reg [271:0] ck_sh_q;
  integer i;
  always @(posedge clk) begin
    if (init) begin
      fm_q <= 1'b0; hold_q <= 1'b0; sh_q <= 272'd0; chk_v_q <= 1'b0; rq_hold_q <= 1'b0; rqw_q <= 64'd0; rqa_q <= 64'd0; rqk_q <= 32'd0; rql_q <= 32'd0; enreq_q <= 1'b0; rdy_q <= 1'b0; cmdv_q <= 1'b0;
      sig <= 4'd0; need <= 4'd0; rdent <= 4'd0; tg_wp <= 3'd0; tg_rp <= 3'd0; epsn_q <= 24'd0; cpsn_q <= 24'd0; acc_q <= 1'b0; com_q <= 1'b0; ld_q <= 1'b0; flush_q <= 1'b0;
      ck_op_q <= 2'd0; ck_key_q <= 32'd0; ck_len_q <= 32'd0; ck_pd_q <= 2'd0; ck_va_q <= 64'd0; ck_kind_q <= 2'd0; cur_v <= 1'b0; cur_pa <= 0; cur_rid <= 1'b0; cur_ctx <= 1'b0; ck_sh_q <= 272'd0;
    end else begin
      fm_q <= fm_q | ag_fatal_set;
      flush_q <= flush_en; enreq_q <= en_req; rdy_q <= dw_cmd_ready; cmdv_q <= dw_cmd_valid;
      hold_q <= rxh_valid && !rxh_pop; sh_q <= rxh_sh;
      rq_hold_q <= rq_valid && !rq_pop; rqw_q <= rq_wr_id; rqa_q <= rq_addr; rqk_q <= rq_lkey; rql_q <= rq_len;
      chk_v_q <= chk_valid;
      epsn_q <= epsn; cpsn_q <= cpsn; acc_q <= ev_accept; com_q <= ev_commit; ld_q <= ld_valid;
      if (chk_valid) begin
        ck_op_q <= chk_op; ck_key_q <= chk_key; ck_len_q <= chk_len; ck_pd_q <= chk_pd; ck_va_q <= chk_va; ck_sh_q <= rxh_sh;
        ck_kind_q <= is_write ? 2'd0 : is_send ? 2'd1 : in_order ? 2'd2 : 2'd3;
      end
      // WRITE-command / tag shadow
      if (wr_cmd) begin
        tg_idx[tg_wp[1:0]] <= epsn[1:0]; tg_kind[tg_wp[1:0]] <= is_rresp; tg_wp <= tg_wp + 3'd1;
      end
      if (dw_done_valid) begin
        tg_rp <= tg_rp + 3'd1;
        if (!tg_kind[tg_rp[1:0]]) sig[tg_idx[tg_rp[1:0]]] <= 1'b1;
      end
      if (rg_done_valid) sig[rg_done_psn[1:0]] <= 1'b1;
      if (ev_accept) begin need[epsn[1:0]] <= wr_cmd || rdq_valid; sig[epsn[1:0]] <= !(wr_cmd || rdq_valid); rdent[epsn[1:0]] <= rdq_valid; end
      if (ev_commit) begin sig[cpsn[1:0]] <= 1'b0; need[cpsn[1:0]] <= 1'b0; rdent[cpsn[1:0]] <= 1'b0; end
      // SEND message grant (first segment accepted with more segments to come)
      if (ev_accept && o_st == 2'd1 && ck_kind_q == 2'd1) begin cur_v <= !vf[1]; cur_pa <= rsp_pa; cur_rid <= rsp_rid; cur_ctx <= rsp_ctx; end
      else if (ev_accept && o_st == 2'd0 && is_send && vf[1]) cur_v <= 1'b0;
      else if (flush_en) cur_v <= 1'b0;
    end
  end

  // ---------------------------------------------------------------- state-dependent predicates
  wire st_disp = (o_st == 2'd0), st_chk = (o_st == 2'd1);
  wire pl_stall = has_pl && !dw_cmd_ready;
  wire grant_now = st_chk && rsp_valid && rsp_ok;
  wire disp_req  = st_disp && rxh_valid && is_reqop && en_req && !fatal_mode;

  always @(posedge clk) if (!init && !first) begin
    if (VAC == 0) begin
      // X1 (i)
      X1a: assert(!wr_cmd || (is_rresp ? resp_ok_spec : ((is_send || is_write) && in_order && en_req && !fatal_mode)));
      X1b: assert(!(wr_cmd && is_rresp) || (dw_cmd_pa == rr_lpa + moff[PA_W-1:0] && dw_cmd_rid == rr_rid && dw_cmd_ctx == rr_ctx && dw_cmd_len == paylen && st_disp));
      // X1 (ii): the grant used is the one answered for THIS frame's check
      X1c: assert(!(wr_cmd && !is_rresp && st_chk) || (grant_now && !flush_en && dw_cmd_rid == rsp_rid && dw_cmd_ctx == rsp_ctx &&
                   (ck_kind_q == 2'd0 ? (dw_cmd_pa == rsp_pa) : (ck_kind_q == 2'd1 && dw_cmd_pa == rsp_pa + moff[PA_W-1:0]))));
      X1d: assert(!(wr_cmd && !is_rresp && st_chk && ck_kind_q == 2'd0) || (ck_sh_q == rxh_sh && ck_op_q == `SFR_CK_RWR && ck_key_q == hrkey && ck_va_q == hva && ck_len_q == {16'd0, paylen} && ck_pd_q == qp_pd));
      X1e: assert(!(wr_cmd && !is_rresp && st_chk && ck_kind_q == 2'd1) || (ck_sh_q == rxh_sh && ck_op_q == `SFR_CK_LWR && ck_key_q == rq_lkey && ck_va_q == rq_addr && ck_len_q == rq_len && ck_pd_q == qp_pd));
      X1f: assert(!(wr_cmd && !is_rresp && st_disp) || (is_send && !f_first && cur_v && dw_cmd_pa == cur_pa + moff[PA_W-1:0] && dw_cmd_rid == cur_rid && dw_cmd_ctx == cur_ctx));
      X1g: assert(!(wr_cmd && !is_rresp) || dw_cmd_len == paylen);
      // X2
      X2a: assert(ld_q || epsn == epsn_q + {23'd0, acc_q});
      X2b: assert(ld_q || cpsn == cpsn_q + {23'd0, com_q});
      X2c: assert(!ev_accept || (in_order && (st_chk ? grant_now : (st_disp && is_send))));
      X2d: assert(occ_w <= 24'd4);
      X2e: assert(!ev_commit || sig[cpsn[1:0]] || (flush_en && rdent[cpsn[1:0]]));   // review fix: while the QP is flushed a READ entry (never to complete) is skipped
      X2f: assert(!ev_commit || cpsn != epsn);
      // X3
      X3a: assert(!ag_fatal_set || (!wr_cmd && !rdq_valid && !ev_accept));
      X3b: assert(!(st_chk && rsp_valid && rsp_ok && (flush_en || fatal_mode)) || (rel_a_valid && rel_a_rid == rsp_rid && !ev_accept && !wr_cmd && !rdq_valid));
      // X4
      X4a: assert(!(st_disp && rxh_valid && is_send && f_first && in_order && !rq_valid && en_req && !fatal_mode) || (!ev_accept && !wr_cmd && !rq_pop));
      // X5
      X5a: assert(!(disp_req && is_resv && in_order) || (!wr_cmd && !rdq_valid && !ev_accept && (pl_stall || (rxh_pop && ag_fatal_set && ag_fatal_code == `SFR_NAK_INV))));
      // X6
      X6a: assert(!(disp_req && !in_order) || (!ev_accept && !rq_pop && !wr_cmd && !(rdq_valid && !rdq_replay)));
    end else begin
      case (VAC)
        1: assert(!(wr_cmd && !is_rresp && st_chk && ck_kind_q == 2'd0));                      // a WRITE command from a granted check of an in-order WRITE frame
        2: assert(!(disp_req && !in_order && dpsn[23]));                                      // a duplicate request frame is presented
        3: assert(!ag_fatal_set);                                                              // a fatal NAK decision
        4: assert(!(st_disp && rxh_valid && is_send && f_first && in_order && !rq_valid && en_req && !fatal_mode && rxh_pop && ag_nak_set));   // RNR (no receive WQE)
        5: assert(!(disp_req && is_resv && in_order && rxh_pop && ag_fatal_set));              // reserved opcode -> INV_REQ
        6: assert(!(wr_cmd && !is_rresp && st_disp));                                          // a SEND continuation WRITE command
        7: assert(!(wr_cmd && is_rresp));                                                      // a READ_RESP placement
        8: assert(!ev_commit);                                                                 // a commit
        9: assert(!(occ_w == 24'd4));                                                      // the window is full
        10: assert(!(st_chk && rsp_valid && rsp_ok && (flush_en || fatal_mode) && rel_a_valid)); // an aborted grant is released (rel_a port)
        11: assert(!(disp_req && !in_order && !dpsn[23]));                                    // an out-of-sequence request frame is presented
        12: assert(!(ev_accept && st_chk && ck_kind_q == 2'd2));                              // a READ request is accepted
        13: assert(!(ev_commit && flush_en && rdent[cpsn[1:0]] && !sig[cpsn[1:0]]));          // a READ entry is skipped by the flush commit
      endcase
    end
  end
endmodule
