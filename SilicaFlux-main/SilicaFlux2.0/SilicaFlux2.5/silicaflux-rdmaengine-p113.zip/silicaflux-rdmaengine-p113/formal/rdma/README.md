# Formal verification of the RDMAEngine (Project 113): Yosys -> SMT2 -> z3

Everything here is generated / driven by `scripts/formal.py`; results are in `reports/formal.md` (every job), `reports/formal.json` and
`reports/formal_mutants.md` (planted defects).  `rtl/` is read-only for this layer: mutants are applied to COPIES under `out/formal/`.

```
scripts/formal.py                 # all jobs          (2 parallel jobs, 10 min wall-clock limit per job)
scripts/formal.py --list
scripts/formal.py --only retry_prove vac_retry_3
scripts/formal.py --mutants       # jobs + the mutation campaign        (--mutants-only: just the campaign)
```

Job kinds and how to read a verdict (the words are used literally in the reports):

| verdict | meaning |
|---|---|
| **PROVED** | `comb` job (depth-1 check, all inputs) or `prove` job (k-induction: base case from reset + induction step) = **unbounded** for the stated instance and environment |
| **BOUNDED d** | `bmc` job: no violation within `yosys-smtbmc -t d` from reset.  NOT an unbounded proof.  (Yosys registers the immediate assertions of clocked blocks, so `-t d` covers the conditions of cycles 0 .. d-2.  Also: a Verilog `a - b <= W` is evaluated in 32 bits BEFORE the subtraction: all PSN differences in the harnesses are 24-bit wires.) |
| **WITNESSED** | `vac` job: the assertion MUST fail; it did, i.e. the situation is reachable and the passing jobs are not vacuous |
| **KILLED / SURVIVED** | `mut` job: the harness re-run (BMC) on a copy of the RTL with ONE planted defect failed / did not fail |
| **UNKNOWN** | time-out (10 min) or the induction step did not close: reported as such, never as a pass |

## How the flow works (and the three tool facts that matter)

`read_verilog -sv -formal; hierarchy -top <harness> -chparam ..; proc; flatten; connect -set <OBS>; prep; async2sync; dffunmap; write_smt2 -wires; yosys-smtbmc -s z3 --unroll [-i] -t N`

1. The RTL uses an **asynchronous active-low reset**; `async2sync` turns it into a synchronous model.  Every harness holds reset in cycle 0 only
   (`reg init = 1'b1`, `rst_n = !init`), shadow registers reset with it, and assertions are disabled while `init` is high.
2. **`--unroll` is essential.**  Without it z3 4.8 does not terminate even on the depth-1 check of the registry (exponential `define-fun` expansion in
   the solver front end); with it every job below runs.  (boolector 1.5 does not work with this smtbmc.)
3. Yosys 0.33 has **no hierarchical references**.  Harness comments `// OBS <harness_wire> <flattened.dut.path> [?PARAM=value]` make the runner emit
   `connect -set`, which exports an internal DUT register to a harness wire.  They are used **only** for inductive-strengthening lemmas, for the
   RTL table mirror of the registry and for a few state invariants (una / nxt / txp ...); the headline claims are on ports.  (Never alias an OBS wire -- bit select, concatenation, a function argument that is the wire itself:
   `connect -set` then silently UNSETS the alias and the aliased wire becomes undriven/free.  Harnesses read OBS wires only through cells: `==`, `&`, muxes.
   Two of my own harness bugs were exactly this; the runner reports no `no driver` warnings for the final harnesses.)

Every harness starts with a comment block that states its claims in plain English with the spec section each comes from.  Every `prove` harness
carries its inductive strengthening as named `assert`s (lemmas `L1 ...`), proved by the same induction.

## Harnesses, instances, and what each proves

Verdict column = the strongest verdict reached (see `reports/formal.md` for the per-job table, times and depths).  "bugs" = which of the three
simulation-found bugs (1 = ackgen lost event, 2 = requester `rd_out`, 3 = requester `una <= txp`) the harness would have caught.

| harness (module) | instance | what it establishes | verdict | bugs |
|---|---|---|---|---|
| `fv_retry` (`sf_rdma_retry`) | real widths: 32-bit timeout / rnr_delay, 4-bit counters; constant config; free inputs | R1-R8: `retry_cnt <= retry_max`, `rnr_cnt <= rnr_max`; `exhausted` only at `k == retry_max` and never repeats until `en` falls; no event from a cycle with `en` low; the timer never expires before `timeout << min(k,3)` consecutive running cycles (shadow counter) and never lost; `progress` resets both counters; RNR wait exactly `rnr_delay` non-progress cycles, NAKs / expiries during the wait ignored | `retry_prove` PROVED (k-induction); `retry_bmc` BOUNDED 22 | (3: the rewind events `ev_*` that move `txp` are exactly characterised: an extra / early rewind event is a violation) |
| `fv_completion` (`sf_rdma_completion`) | CQ_DEPTH 4; takes guarded by credits; producers push only against an earlier take | K1-K4: `credits + cq_count + (takes - pushes) == CQ_DEPTH`, `ev_overflow` never, a free-ordinal tagged CQE comes out exactly once, in order, intact; one producer per cycle | `completion_prove` PROVED; `completion_bmc` BOUNDED 14 | - |
| `fv_wqe` (`sf_rdma_wqe`) | SQ / RQ depth 4, MAX_MSG_BYTES 1 MiB (real), 64-bit addresses | W1-W6: post status = spec 6.3 in the order STATE, OPCODE, FIELDS, LEN, RANGE for all inputs (129-bit spec); unsupported opcode (incl. aliases 5, 9, 13) never accepted; rejected post takes no slot / credit; FIFO order of a free-ordinal tagged post; back-pressure; `take -> credit` (discharges completion's assumption) | `wqe_prove` PROVED; `wqe_bmc` BOUNDED 14 | - |
| `fv_registry` (`sf_rdma_memory_registry`) | NMR 3, NCHK 2 / 1, NG 2 / 1, PA_W 32, PD_W 2, CTX_W 2, REF_W 3; 64-bit VA, 32-bit len / key (real) | G1-G8: grant IFF every clause of 8.3 against an independent 130-bit shadow table; fault code = first failing clause; domain isolation / wrap / range corollaries; MR_SET / MR_INVAL / CTX_SET statuses; refcounts; unique keys; table mirror; DMA guard; fault counters and log | `registry_bmc` BOUNDED 7; `registry_cnt_bmc` (counters / log, both ports) see `reports/formal.md` | - |
| `fv_ackgen` (`sf_rdma_ackgen`) | ACCEPT_ACK_DELAY 3 | A1-A6: no flag event is ever lost (also in the cycle of the push of its own kind), flags cleared only by the consuming handshake, priority fatal > NAK > replay > ACK, frame contents (psn = cpsn, accept_next = epsn), fatal NAK only at `cpsn == epsn`, replays repeat the fatal code, acceptance report timing | `ackgen_prove` PROVED; `ackgen_bmc` BOUNDED 18 | **1** (A1a / A1b / A1c: mutants AG1, AG1a, AG1n, AG1r) |
| `fv_dma_wr` (`sf_rdma_dma_wr`) | DW 32, PA_W 6, MEM_WR_OUT 2, CMD_Q 2, len <= 7..9 | D1-D5: exact byte set / strobes / data of a free command KC at a free address TA, no write for DISCARD or guard-failed commands, `viol`, commit only after all acks (+ `done_err`), outstanding <= MEM_WR_OUT | `dma_wr_bmc` BOUNDED 11 | - |
| `fv_dma_rd` (`sf_rdma_dma_rd`) | DW 32, PA_W 6, MEM_OUT 2, CMD_Q 2 | P1-P5: read addresses inside the range, payload bytes / keep / last / port exactly as commanded (abstract memory), guard-failed commands read nothing and pulse `viol`, outstanding <= MEM_OUT, no FIFO overflow, done accounting | `dma_rd_bmc` BOUNDED 12 | - |
| `fv_rx_safety` (`sf_rdma_rx`) | WINDOW 4, PA_W 8, TAGQ 4 | X1-X6: WRITE only for in-order frames with the grant of their own check (or an accepted READ_RESP), pa / rid / ctx equal the grant (+ moff), never for duplicates / out-of-sequence; epsn / cpsn discipline, commit only after completion; no fatal with a used grant; grant released on abort; RNR; reserved opcode -> INV_REQ | `rx_safety_bmc` BOUNDED 12 | - |
| `fv_requester` (`sf_rdma_requester`) | WINDOW 2 (`WIN=4` selectable), MAX_RD 2, MTU 4, PA_W 8; WQE addresses / keys fixed to 0 (pure payload); ACK frontiers as +-16 offsets from una | Q1-Q6: window, `una <= txp <= nxt` always (also after rewinds), `rd_out ==` READ entries in flight, completion only after commit / placement, CQEs in post order exactly once, no entries for failed WQEs | `requester_bmc` BOUNDED 9; `requester_deep_bmc` BOUNDED 10 (12 timed out: UNKNOWN); `requester_rd_bmc` / `requester_w4_rd_bmc` see `reports/formal.md` | **2** (Q2a / Q2b: mutant RQ3), **3** (Q1b / Q1c / Q3c: mutants RQ4, RQ5) |
| `fv_psn` (`sf_rdma_rx`) | 24-bit PSNs, all values | F1-F4 modular PSN facts for ALL a, b, c; the rx in-order / duplicate / future split equals the spec definition for ALL (psn, epsn) | `psn_spec` PROVED, `psn_rx` PROVED | - |

Non-vacuity: every harness has `vac_<harness>_<n>` jobs (a grant is reachable, a duplicate frame, retry exhaustion, a full CQ, a two-word DMA command, a fatal NAK
decision, ...); all must be WITNESSED.  Mutation: `reports/formal_mutants.md` (planted defects by textual substitution on COPIES of the RTL; each must be KILLED).


## What the harnesses would have caught (the three simulation-found bugs, plus the earlier ones)

* **Bug 1 (ackgen lost event)**: `fv_ackgen` A1a-A1d: "an event in cycle t leaves its flag set in t+1".  Re-introduced as `AG1` (all four flags), `AG1a` (ACK only: the exact
  simulation-found case, `ack_set` in the cycle an ACK frame is pushed), `AG1n`, `AG1r`: all KILLED.  Witness `vac_ackgen_1` shows the situation is reachable.
* **Bug 2 (requester `rd_out` wrap)**: `fv_requester` Q2a / Q2b: `rd_out == number of READ entries in [una, nxt)` and `<= MAX_RD` (an independent count over the request table).
  Re-introduced as `RQ3` (two separate assignments) and `RQ7`: KILLED.
* **Bug 3 (requester `una <= txp`)**: `fv_requester` Q1b / Q1c (`una <= txp <= nxt` modular, `tx_valid` never names a PSN before `una`) with timeouts / NAK / RNR rewinds enabled and
  free ACKs.  Re-introduced as `RQ4` (the `if (txp == una)` line deleted) and `RQ5` (rewind target not clamped): KILLED.  `vac_requester_5` witnesses the corner (an entry retires
  while `txp` points at it).
* Earlier simulation / audit findings are covered by: `RX1`-`RX9` (duplicate applied twice, registry verdict ignored, epsn advanced on a rejected request, wrong continuation address,
  reserved opcode, RNR, reference leak, fatal mode, READ_RESP placement), `RG1`-`RG13` (registry), `WQ1`-`WQ8`, `CQ1`-`CQ5`, `DW1`-`DW6`, `DR1`-`DR5`, `RT1`-`RT8`, `PS1`-`PS3`.


## Final result set (reports/formal.md, formal.json, formal_mutants.md) and its provenance

**130 jobs: 6 PROVED, 14 BOUNDED, 110 WITNESSED, 0 UNKNOWN / FAILED;  84 mutants: 81 KILLED, 1 SURVIVED (`RQ7`), 2 UNKNOWN (`RG7`, `RQ3`).**

* **PROVED (unbounded, same instance / environment):** `retry_prove`, `completion_prove`, `wqe_prove`, `ackgen_prove` (k-induction, k = 2, with named inductive lemmas) and `psn_spec`, `psn_rx` (combinational:
  all 24-bit PSNs / all epsn).
* **BOUNDED d (BMC from reset; NOT an unbounded proof):** `registry_bmc` 7, `registry_cnt_bmc` 5, `dma_wr_bmc` 11, `dma_rd_bmc` 12, `rx_safety_bmc` 12, `requester_bmc` 9, `requester_deep_bmc` 10, `requester_rd_bmc` 11,
  `requester_w4_rd_bmc` 10 and the cross-check BMCs `retry_bmc` 22, `retry_bmc_k4` 20, `completion_bmc` 14, `wqe_bmc` 14, `ackgen_bmc` 18.
* **UNKNOWN in earlier attempts (time-out at 600 s), reported at the depth that completes:** `requester_deep_bmc` at depth 12 and `requester_rd_bmc` at depth 12 (now 10 / 11), `registry_cnt_bmc` at depth 6 (now 5), `dma_wr_bmc` 13 / `dma_rd_bmc` 14 (now 11 / 12),
  `registry_bmc` 9 (now 7).  Mutants `RG7` and `RQ3` are UNKNOWN (420 s) and `RQ7` SURVIVED: see "Mutation campaign" above.
* **Provenance -- please read.**  A single `scripts/formal.py --mutants` run from scratch is ~50 minutes of wall clock on the shared 4-core machine (sum of the BMC jobs ~45 min, the heavy mutants ~40 min, at most two jobs in
  parallel); it was NOT possible inside the time left after the RTL merge.  The result set was produced by the same runner, in `--only` batches, ALL against the current `rtl/` content: every job / mutant of a module that CHANGED in the
  merge (retry, requester, rx, dma_wr, dma_rd, transport adapter is not verified) was run AFTER the merge; the results of `completion`, `wqe`, `ackgen`, `memory_registry` (unchanged files: mtimes 11:10 - 11:59) and `psn_spec` stem from batches
  run before the merge on identical file content (`registry_bmc` and the registry mutants `RG1-RG6` were re-run after it).  `reports/*.{md,json}` were rewritten by the final `--only` invocation of the runner, which drops stale results of
  older job / mutant definitions.  Re-running `scripts/formal.py --mutants` end to end is the way to turn this into one atomic run.
* Pre-merge (RTL of 12:01) results are kept under `out/formal/baseline_rtl1201/` for comparison.

## Re-verification against the review-fix RTL (merge of 14:20) -- what changed and why

The harnesses were first completed on the RTL of 12:01 and then ADAPTED to the merged RTL.  Verdicts that changed, with the reason (harness updated, not an RTL bug, unless stated):

| harness | change | verdict before -> after | why |
|---|---|---|---|
| `fv_requester` on the 12:01 RTL | **F-1 (real bug)**: `una <= txp` violated by a same-cycle SEQ_ERR rewind + retirement (`Q1b`, depth 10 / step 8-9) | FAILED -> `requester_deep_bmc` BOUNDED 10 | the merged RTL computes `txp_n` once and clamps it against the next `una` (review item S-01): the counterexample no longer exists; the same harness now PASSES, and mutant `RQ4` (clamp deleted) is KILLED again by `Q1b` |
| `fv_retry` | encoded "a NAK in a progress cycle is ignored; `dead` is cleared only by `!en`" | PROVED -> (adapted) PROVED | new behaviour (review F-03): progress resets the counters BEFORE the NAK is counted, only an expiry is suppressed by progress, `progress` clears `dead`.  New claims A09 / A10 (counter = reset base + 1 per accepted event), A27 / A28 (a NAK in a progress cycle fires `ev_nak` / starts the RNR wait), witnesses `vac_retry_11-13`, mutants `RT9`, `RT10`.  The RNR wait is still paused for a progress cycle (OBS-1 stands) |
| `fv_requester` | new ports tied off (`lerr_*` 0, `dma_quiet` 1); new claim `Q7` (chi / ahi never lose a valid ACK, also with a retirement in the same cycle: review F-07); mutant `RQ11` | - | `tx_en` / `armed` now stop at `psn >= err_psn` instead of `err_pending`: no assertion depended on the old condition |
| `fv_rx_safety` | `X2e` relaxed: a READ entry may be committed WITHOUT completion while the QP is flushed (`ring_ready = c_done \|\| (flush_en && c_isrd)`); release checked on the new `rel_a_*` port; new outputs left unconnected | BOUNDED 12 -> FAILED (first adapted run, `X2e`) -> BOUNDED 12 | the harness encoded the OLD commit rule; the counterexample was exactly the new, intended flush-skip of a READ entry; witness `vac_rx_13` |
| `fv_dma_wr` | a guard-converted command now reports `done` (`done_err = 1`) in order: `D4` extended (`D4c`: converted command done with error after every earlier ack; `D4d`: idle => no completion owed); new witness `vac_dma_wr_9`; mutant `DW7` (done omitted) | BOUNDED 11 -> BOUNDED 11 | review F-09 |
| `fv_dma_rd` | new output `pl_err` checked (`P5e`: equals the OR of the command's memory error flags at `pl_last`) | BOUNDED 12 -> BOUNDED 12 | review fix |
| `fv_psn` (`psn_rx`) | port list updated | PROVED -> PROVED | - |
| registry, wqe, completion, ackgen, psn_spec | RTL files unchanged | unchanged | - |

The transport adapter, the new engine / qp wiring (NREL 6) and the local-error paths (`lerr_*`, `place_err_*`, `err_loc`) are NOT covered by a harness: the inputs are tied off.  `requester_deep_bmc` at depth 12 and `registry_cnt_bmc` at depth 6 time out (UNKNOWN); they are reported at the depth that completes.

## Findings and observations (first RTL snapshot of 12:01: ackgen explicit next-state, requester `rd_inc/rd_dec` + clamped rewind targets)

**One real RTL bug was found (F-1, below); everything else is an observation.**  The three simulation-found bugs are re-introduced as planted mutants (`AG1*`, `RQ3`, `RQ4`,
`RQ5`) so the harnesses are regression guards for them.

* **F-1 (REAL BUG, spec 9.1 `una <= txp <= nxt`): a SEQ_ERR (or timeout / RNR) rewind and a retirement in the SAME cycle leave `txp < una` (`sf_rdma_requester`, RTL of 12:01).**
  Found by `requester_deep_bmc` (assertion `Q1b`, `una <= txp <= nxt` modular; depth 12, 42 s), i.e. the fix for "bug 3" (`if (txp == una) txp <= una + 1` and the clamped
  `nak_tgt_c` / `rnr_tgt_c`) is incomplete.  Minimal counterexample (relative PSNs; one WRITE, `retry_max >= 1`, free ACKs), cycle: events -> state
  ```
  c4  SEQ_ERR NAK(an=0) accepted                          -> nak_tgt = 0
  c5  WRITE entry psn 0 created (nxt=1), transmitted      -> txp = 1
  c6  second entry psn 1 created (nxt=2); a SEQ_ERR NAK(an=0) is applied one cycle later: nak_retry_p
  c7  ev_nak fires (go-back-N to nak_tgt_c = 0) in the SAME cycle as retire_go (una 0 -> 1, a valid cumulative ACK covered entry 0)
        RTL:  if (ev_nk)   begin if (psn_lt(nak_tgt_c, txp)) txp <= nak_tgt_c; ... end        // txp <= 0   (clamp uses the OLD una = 0)
              if (retire_go) begin una <= una + 1; if (txp == una) txp <= una + 1; end        // txp (old) = 1 != una = 0: no bump
  c8  una = 1, txp = 0   =>  txp < una : the next tx_valid re-sends PSN 0 whose entry (and local grant) has just been released
  ```
  The same hole exists for `ev_to` (`txp <= una`, old una) and `ev_rn` with a retirement in the same cycle.  Proposed fix: compute the next `txp` ONCE as a net value and clamp it
  against the NEXT una: `txp_n = (rewind ? target : tx_hs ? txp + 1 : txp); if (retire_go && psn_lt(txp_n, una + 1)) txp_n = una + 1;` (modular compares), then `txp <= txp_n`.
  FIXED in the merged RTL (review item S-01: `txp_n` net next-state with a clamp against `una + 1` on retirement).  `requester_deep_bmc` (depth 10) is the regression check and mutant `RQ4` re-introduces the hole.
* **OBS-1  the RNR back-off is stretched by `progress` pulses (`sf_rdma_retry`).**  `rcnt` advances only in the `else` of `if (progress)`, so each progress pulse inside the
  wait adds one cycle: the wait is `rnr_delay` NON-progress cycles, not `rnr_delay` cycles (spec 9.5(5)).  `fv_retry` proves the exact behaviour (A16-A18; A19-A20 for the ignored NAKs) and
  `vac_retry_8` witnesses it.  Minimal trace (`rnr_delay = 1`): cycle 1 `rnr_nak` accepted; cycle 2 `progress` with `rnr_wait` high (counter frozen); cycle 3 the wait ends;
  cycle 4 `ev_rnr` (without the pulse: cycle 3).  Severity LOW (back-off lower bound; the stretch is bounded by the number of frontier advances).  Proposed fix if the exact
  delay matters: count `rcnt` before / independent of the `progress` branch.
* **OBS-2  a PSN at exactly half the space is classified a duplicate (`sf_rdma_rx`).**  Spec 0 defines `before` only for distances `[1, 2^23-1]`; `dup = (psn-epsn)[23]` treats
  `2^23` as stale (ACK, no effect).  `psn_rx` proves this and that no non-in-order frame has any WRITE / accept / RQ effect: safe.  The spec should say it.
* **OBS-3  the DMA guard refuses `len = 0` (spec 8.5 is silent).**  Stricter and safe: no command with len 0 is ever issued.  `fv_registry` G7 asserts it explicitly.
* **OBS-4  a `restart` pulse in the cycle of an expiry does not cancel that expiry (`sf_rdma_retry`).**  Only reachable for `timeout = 1` with back-off exponent 0; the shadow of
  `fv_retry` (R5) models `restart` as clearing the timer for the NEXT cycle, as the RTL does.

(The task brief asked for `formal/rdma/FINDINGS.md` for real bugs; the environment refused a report-file write from this agent, so F-1 and the observations live in this section and in the final report.)

## Mutation campaign: survivors and unknowns (investigated)

84 planted defects (`scripts/formal_mutants.py`, table in `reports/formal_mutants.md`).  Not KILLED:

* **`RG7` (page-crossing check dropped) -- UNKNOWN**: the BMC on the mutant did not finish in 420 s (a 64-bit page-cross counterexample on top of a 3-entry table).  The unmutated check is
  covered (`vac_registry_6` witnesses a PAGE_CROSS fault; `G1/G2` compare the fault code with the shadow), so this is a solver-effort limit, not a missing claim.
* **`RQ3` (`rd_out` updated by two assignments; the simulation-found bug 2) -- UNKNOWN**: the lost increment needs a READ to be issued in the very cycle another READ retires (check, segment,
  transmit, ACK, placement, retirement: >= 13 cycles).  `requester_rd_bmc` (all-READ stream) times out at that depth.  The CLAIM is stated (`Q2a/Q2b`, a shadow count of READ entries) and the
  outstanding-READ limit is exercised (`vac_requester_6`), but the bug itself is NOT demonstrated killed by a formal job; the simulation campaign killed it.
* **`RQ7` (`rd_ok` uses `<=`) -- SURVIVED at depth 10 (WINDOW 4)**: a third outstanding READ needs three check / segment rounds (>= 15 cycles).  On the WINDOW-2 instance the mutant is EQUIVALENT
  (a third entry cannot exist).  Not killed formally.
* Every other mutant is KILLED; several are killed by a lemma (`L*`) instead of the headline claim (the lemma observes an RTL register), which still means the mutant is observable.

## Honest limits (read before relying on any verdict)

* **Instances are small.**  Queue depths 4, WINDOW 4 (rx) / 2 (requester), MAX_RD 2, NMR 3 (registry), DW 32 and PA_W 6 / 8 (DMA / rx), CQ_DEPTH 4.  The RTL hard-codes the
  64-bit VA, 32-bit len / key and the 24-bit PSN, so those are the REAL widths (the registry and PSN harnesses run on 64-bit / 24-bit data).
  A property proved on the small instance is not automatically true on the default (WINDOW 8, DW 64, NMR 8) instance; the RTL is parametric
  and uniform, but that is an argument, not a proof.
* **BOUNDED is bounded.**  `registry_*`, `dma_wr_bmc`, `dma_rd_bmc`, `rx_safety_bmc`, `requester_bmc` are bounded model checks.  For the registry the bound is
  chosen so that every table content is reachable (3 `MR_SET` + 1 `CTX_SET`), which makes the check-function / config-status verdicts exhaustive for
  this NMR, but refcounts above 1, fault counters above a few events and long command histories are NOT covered beyond the depth.
  `retry`, `completion`, `wqe`, `ackgen` and the two `psn` jobs are unbounded (k-induction / comb); `*_bmc` jobs of the same harnesses are cross-checks.
* **Environments are abstractions** (each stated in the harness header): the registry guard of the DMA harnesses is a symbolic window `[LO, HI)` instead of
  the real table; the memory is an in-order abstract function; `clear` (QP reset flush) is not exercised except in `fv_wqe`; the rx harness bounds
  `paylen < 16`, `mlen, moff < 32`; the requester harness bounds `len <= 9`, timeouts <= 2, ACK frontiers to +-16 around una, and drops the WQE address / key payload.
* **Not covered formally:** the transport adapter, rdgen, the QP controller (state machine, reset / drain sequencing), the engine top level and the
  performance counters; deadlock freedom / liveness (every property is a safety property; the only "eventually" claims are witnessed by `vac` jobs);
  data integrity across the link; the arithmetic of segmentation beyond the small MTU used (`MTU = 4`); the SEND / RECV CQE contents of the rx harness
  (only the write-safety and sequencing contract is proved); simultaneous multi-QP behaviour (there is one QP).
* `vendored third_party/sf_stream_dma_align.sv` is used as is (proved elsewhere); the DMA harnesses prove the engines AROUND it.
* The harness lemmas that reference RTL internals (OBS) are invariants of the design; a wrong lemma cannot make a false property pass (a lemma is
  itself asserted and must hold), but a lemma that is too weak shows up as an UNKNOWN (induction step fails), never as a PASS.
