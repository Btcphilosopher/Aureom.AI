#!/usr/bin/env python3
"""Performance benchmarks of the SilicaFlux RDMA engine.  EVERYTHING here is MEASURED in cycle-accurate RTL simulation (Verilator) on the
two-endpoint bench; nothing is estimated.  Units are simulation CYCLES and BYTES/CYCLE; no clock frequency, area or power is claimed.
(Gbit/s would be bytes/cycle x 8 x f_clk: that needs a timing-closed clock, which this project does not have.)

  benchmarks/rdma/bench.py [--quick] [--sweeps size,memlat,window,mtu,dw,loss,bidir,memout,maxrd]
Builds the bench variants it needs (make build ...), generates its own workloads, runs them, and writes
  benchmarks/rdma/results.csv   one row per run (rows of a sweep that is not re-run are kept, so one sweep can be refreshed alone)
Tables and analysis: benchmarks/rdma/make_report.py turns results.csv into benchmarks/rdma/REPORT.md.
Throughput = completed payload bytes / (cycle of last CQE - cycle of first accepted post).  Latency = the engine's own lat_* counters (WQE issue -> CQE).
"""
import argparse, csv, os, re, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUTD = os.path.join(ROOT, "out", "bench"); os.makedirs(OUTD, exist_ok=True)
SETUP = """seed v={seed}
mem_fill ep=A addr=0x0 len=0x40000 pat=7
mem_fill ep=B addr=0x0 len=0x40000 pat=9
mr ep=A idx=0 va=0x10000 len=0x40000 pa=0x0 key=0x1001 pd=1 acc=0x1F ctx=0
mr ep=B idx=0 va=0x10000 len=0x40000 pa=0x0 key=0x1001 pd=1 acc=0x1F ctx=0
qp ep=A state=INIT qpn=1 pd=1
qp ep=B state=INIT qpn=2 pd=1
qp ep=A state=RTR rqpn=2 epoch=1 rq_psn=512 smac=0x20000000001 dmac=0x20000000002
qp ep=B state=RTR rqpn=1 epoch=1 rq_psn=256 smac=0x20000000002 dmac=0x20000000001
qp ep=A state=RTS sq_psn=256 timeout={to} retry=7 rnr_retry=7 rnr_delay=200
qp ep=B state=RTS sq_psn=512 timeout={to} retry=7 rnr_retry=7 rnr_delay=200
"""
def build(dw=64, mtu=256, window=8, max_rd=2, mem_out=4):
    tag = f"dw{dw}_mtu{mtu}_w{window}" + ("" if (max_rd, mem_out) == (2, 4) else f"_rd{max_rd}_mo{mem_out}")   # the tag must encode EVERY parameter that is varied
    # (make tracks sources, not parameters: a tag that left one out would silently reuse another configuration's binary)
    tb = os.path.join(ROOT, "out", f"tb_{tag}")
    args = ["make", "-C", ROOT, f"DW={dw}", f"MTU={mtu}", f"WINDOW={window}", f"MAX_RD={max_rd}", f"MEM_RD_OUT={mem_out}", f"MEM_WR_OUT={mem_out}", f"TAG={tag}", f"out/tb_{tag}"]
    r = subprocess.run(args, capture_output=True, text=True)       # always through make: it rebuilds only when a source changed (a stale binary once hid a bench bug)
    if r.returncode: sys.exit("build failed:\n" + r.stderr[-1500:])
    return tb
def run(tb, body, name, to=3000, lat=(2, 2), stall=0, link="", seed=3):
    scn = SETUP.format(to=to, seed=seed) + f"mem_lat ep=A min={lat[0]} max={lat[1]} stall={stall}\nmem_lat ep=B min={lat[0]} max={lat[1]} stall={stall}\n" + link + body + "barrier max=1500000\n"
    p = os.path.join(OUTD, name + ".scn"); open(p, "w").write(scn)
    r = subprocess.run([tb, "+verilator+rand+reset+2", "+verilator+seed+1", p, os.path.join(OUTD, name + ".res")], capture_output=True, text=True, timeout=300)
    res = open(os.path.join(OUTD, name + ".res")).read().splitlines()
    return parse(res), r.returncode
def parse(lines):
    d = {"cnt": {"A": {}, "B": {}}, "cqe": {"A": [], "B": []}, "post": {"A": [], "B": []}, "mon": 0, "memw": {"A": [], "B": []}}
    for l in lines:
        t = l.split()
        if not t: continue
        kv = dict(x.split("=", 1) for x in t[1:] if "=" in x)
        if t[0] == "CNT": d["cnt"][kv["ep"]][kv["name"]] = int(kv["value"])
        elif t[0] == "CQE": d["cqe"][kv["ep"]].append((int(kv["cyc"]), int(kv["wr_id"]), int(kv["op"]), int(kv["status"]), int(kv["len"])))
        elif t[0] == "POST" and kv.get("which") == "SQ": d["post"][kv["ep"]].append((int(kv["cyc"]), int(kv["status"])))
        elif t[0] == "MON": d["mon"] += 1
        elif t[0] == "MEMW": d["memw"][kv["ep"]].append(int(kv["cyc"]))
    return d
def metrics(d, ep="A", payload_ok_ops=(1, 2, 3)):
    cq = [c for c in d["cqe"][ep] if c[3] == 0 and c[2] in payload_ok_ops]; ps = d["post"][ep]
    if not cq or not ps: return dict(bytes=0, cycles=0, bpc=0.0, ops=0)
    nbytes = sum(c[4] for c in cq); cyc = max(c[0] for c in cq) - min(p[0] for p in ps)
    return dict(bytes=nbytes, cycles=cyc, bpc=nbytes / max(cyc, 1), ops=len(cq))
def memw_gaps(cycles):
    """Cadence of the memory-write port in steady state (middle half of the run): words accepted, number of gaps (a gap = two consecutive
    word writes more than one cycle apart) and the mean number of IDLE cycles in a gap.  A frame-bound transfer shows one gap per frame."""
    if len(cycles) < 64: return dict(words=len(cycles), gaps=0, idle_mean=0.0)
    dl = [b - a for a, b in zip(cycles, cycles[1:])]; mid = dl[len(dl) // 4: 3 * len(dl) // 4]
    g = [x - 1 for x in mid if x > 1]
    return dict(words=len(mid) + 1, gaps=len(g), idle_mean=(sum(g) / len(g)) if g else 0.0)
def ops_body(op, size, n, base_l=0x10000, base_r=0x10000, stride=None):
    stride = stride or ((size + 63) // 64 * 64 + 64); b = ""
    for i in range(n):
        span = 0x20000 - ((size + 63) // 64 * 64)          # keep every buffer inside the 256 KiB registered region
        l = base_l + (i * stride) % span; r = base_r + 0x20000 + (i * stride) % span
        if op == "SEND":      # a receive buffer is posted just before its send (the RQ is only RQ_DEPTH deep)
            b += f"post_recv ep=B wr_id={1000+i} addr={0x30000 + (i*(size+64))%0x10000} lkey=0x1001 len={size+16}\n"
        b += f"post_send ep=A wr_id={i+1} op={op} laddr={l} lkey=0x1001 len={size} raddr={r} rkey=0x1001\n"
    return b
def recv_body(n, size):
    return "".join(f"post_recv ep=B wr_id={1000+i} addr={0x30000 + (i*(size+64))%0x10000} lkey=0x1001 len={size+16}\n" for i in range(n))
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--quick", action="store_true"); ap.add_argument("--sweeps", default="size,memlat,window,mtu,dw,loss,bidir,memout,maxrd")
    a = ap.parse_args(); sweeps = a.sweeps.split(","); rows = []
    def rec(sweep, params, name, d, rc, ep="A", **extra):
        m = metrics(d, ep); c = d["cnt"]["A"]; cb = d["cnt"]["B"]
        row = dict(sweep=sweep, **params, **m, mon=d["mon"] + (rc != 0), lat_wr_mean=round(c.get("lat_write_sum", 0) / max(c.get("lat_write_cnt", 0), 1), 1),
                   lat_rd_mean=round(c.get("lat_read_sum", 0) / max(c.get("lat_read_cnt", 0), 1), 1), lat_sd_mean=round(c.get("lat_send_sum", 0) / max(c.get("lat_send_cnt", 0), 1), 1),
                   retries=c.get("retry_timeout", 0) + c.get("retry_nak", 0) + c.get("retry_rnr", 0), retry_timeout=c.get("retry_timeout", 0), retry_nak=c.get("retry_nak", 0), retry_rnr=c.get("retry_rnr", 0), retx_frames=c.get("tx_retx_frames", 0), dup_seen=cb.get("rx_dup", 0),
                   stall_window=c.get("stall_window", 0), stall_txlink=c.get("stall_tx_link", 0), dma_rd_bytes=c.get("dma_rd_bytes", 0), dma_rd_busy=c.get("dma_rd_busy", 0),
                   dma_wr_bytes=cb.get("dma_wr_bytes", 0) + c.get("dma_wr_bytes", 0), dma_wr_busy=max(cb.get("dma_wr_busy", 0), c.get("dma_wr_busy", 0)),
                   win_occ_max=c.get("win_occ_max", 0),
                   memw_words_A=memw_gaps(d["memw"]["A"])["words"], memw_gaps_A=memw_gaps(d["memw"]["A"])["gaps"], memw_idle_A=round(memw_gaps(d["memw"]["A"])["idle_mean"], 2),
                   memw_words_B=memw_gaps(d["memw"]["B"])["words"], memw_gaps_B=memw_gaps(d["memw"]["B"])["gaps"], memw_idle_B=round(memw_gaps(d["memw"]["B"])["idle_mean"], 2), sq_occ_max=c.get("sq_occ_max", 0), mr_faults=c.get("mr_fault_total", 0) + cb.get("mr_fault_total", 0), **extra)
        rows.append(row); print(f"  {sweep:7s} {params} -> {m['bpc']:.3f} B/cyc over {m['cycles']} cyc, {m['ops']} ops, lat_wr={row['lat_wr_mean']} lat_rd={row['lat_rd_mean']} retries={row['retries']}")
    sizes = [64, 256, 1024, 4096, 16384] if a.quick else [8, 64, 256, 1024, 4096, 16384, 65536]
    tb64 = build()
    if "size" in sweeps:
        print("size sweep (DW=64, MTU=256, W=8, mem latency 2, clean link)")
        for op in ("WRITE", "READ", "SEND"):
            for s in sizes:
                n = max(8, min(64, 262144 // max(s, 1))); body = ops_body(op, s, n)
                d, rc = run(tb64, body, f"size_{op}_{s}"); rec("size", dict(op=op, size=s, n=n), "", d, rc)
        print("single-outstanding latency (one op at a time)")
        for op in ("WRITE", "READ", "SEND"):
            for s in (8, 64, 256, 1024, 4096):
                body = ""
                for i in range(8):
                    body += ops_body(op, s, 1).replace("wr_id=1 ", f"wr_id={i+1} ").replace("wr_id=1000", f"wr_id={2000+i}") + "barrier max=200000\n"
                d, rc = run(tb64, body, f"lat_{op}_{s}"); rec("latency1", dict(op=op, size=s, n=8), "", d, rc)
    if "memlat" in sweeps:
        print("memory latency sweep (4 KiB x 16)")
        for op in ("WRITE", "READ"):
            for L in (1, 2, 10, 30, 80):
                d, rc = run(tb64, ops_body(op, 4096, 16), f"memlat_{op}_{L}", lat=(L, L)); rec("memlat", dict(op=op, mem_latency=L, size=4096), "", d, rc)
    if "loss" in sweeps:
        print("loss sweep (WRITE 4 KiB x 24, both directions lossy, timeout 600, 5 scenario seeds per point)")
        for p in (0, 1, 2, 5, 10):
            link = f"link dir=AB drop={p} delay_min=1 delay_max=4\nlink dir=BA drop={p} delay_min=1 delay_max=4\n"
            for sd in (3, 4, 5, 6, 7):
                d, rc = run(tb64, ops_body("WRITE", 4096, 24), f"loss_{p}_s{sd}", to=600, link=link, seed=sd); rec("loss", dict(op="WRITE", drop_pct=p, size=4096), "", d, rc, seed=sd)
    if "bidir" in sweeps:
        print("bidirectional (A->B WRITE and B->A WRITE concurrently)")
        for s in (256, 4096):
            body = ops_body("WRITE", s, 16) + "".join(f"post_send ep=B wr_id={i+1} op=WRITE laddr={0x10000+i*(s+64)} lkey=0x1001 len={s} raddr={0x30000+(i*(s+64))%0x8000} rkey=0x1001\n" for i in range(16))
            d, rc = run(tb64, body, f"bidir_{s}"); m = metrics(d, "A"); mb = metrics(d, "B")
            rec("bidir", dict(op="WRITE+WRITE", size=s), "", d, rc, bpc_B=round(mb["bpc"], 3), bpc_total=round(m["bpc"] + mb["bpc"], 3))
    if "window" in sweeps:
        print("window sweep (WRITE 1 KiB x 32)")
        for w in (2, 4, 8, 16):
            tb = build(window=w); d, rc = run(tb, ops_body("WRITE", 1024, 32), f"window_{w}"); rec("window", dict(op="WRITE", window=w, size=1024), "", d, rc)
        for w in (2, 4, 8, 16):
            tb = build(window=w); d, rc = run(tb, ops_body("WRITE", 128, 64), f"window_small_{w}", lat=(10, 10)); rec("window", dict(op="WRITE", window=w, size=128, mem_latency=10), "", d, rc)
    if "mtu" in sweeps:
        print("MTU sweep (WRITE 16 KiB x 8)")
        for mtu in (64, 128, 256, 512, 1024):
            tb = build(mtu=mtu); d, rc = run(tb, ops_body("WRITE", 16384, 8), f"mtu_{mtu}"); rec("mtu", dict(op="WRITE", mtu=mtu, size=16384), "", d, rc)
    if "dw" in sweeps:
        print("data-width sweep (WRITE 4 KiB x 32, READ 4 KiB x 16)")
        for dw in (32, 64, 128):
            tb = build(dw=dw)
            for op, n in (("WRITE", 32), ("READ", 16)):
                d, rc = run(tb, ops_body(op, 4096, n), f"dw_{op}_{dw}"); rec("dw", dict(op=op, dw=dw, size=4096), "", d, rc)
    if "memout" in sweeps:
        print("outstanding-memory-words sweep (4 KiB x 16; MEM_RD_OUT = MEM_WR_OUT = mem_out)")
        for mo in (2, 4, 8, 16):
            tb = build(mem_out=mo)
            for op in ("WRITE", "READ"):
                for L in (2, 10, 30):
                    d, rc = run(tb, ops_body(op, 4096, 16), f"memout_{op}_{mo}_{L}", lat=(L, L)); rec("memout", dict(op=op, mem_out=mo, mem_latency=L, size=4096, dw=64), "", d, rc)
        for mo in (4, 8, 16):
            tb = build(dw=128, mem_out=mo); d, rc = run(tb, ops_body("WRITE", 4096, 32), f"memout_dw128_{mo}"); rec("memout", dict(op="WRITE", mem_out=mo, mem_latency=2, size=4096, dw=128), "", d, rc)
    if "maxrd" in sweeps:
        print("outstanding-READ sweep (READ x 64, MAX_RD = 1,2,4,8)")
        for mr in (1, 2, 4, 8):
            tb = build(max_rd=mr)
            for s in (8, 64, 256, 4096):
                n = 64 if s <= 256 else 16
                d, rc = run(tb, ops_body("READ", s, n), f"maxrd_{mr}_{s}"); rec("maxrd", dict(op="READ", max_rd=mr, size=s, n=n), "", d, rc)
    path = os.path.join(ROOT, "benchmarks", "rdma", "results.csv")
    if os.path.exists(path):                                # keep the rows of the sweeps that were NOT re-run
        produced = {r["sweep"] for r in rows}                 # a requested sweep may emit rows under more than one name (size -> size, latency1)
        old = [r for r in csv.DictReader(open(path)) if r["sweep"] not in produced]
        rows = old + rows
    keys = sorted({k for r in rows for k in r}); first = ["sweep", "op", "size", "dw", "mtu", "window", "mem_latency", "mem_out", "max_rd", "drop_pct", "seed", "n"]
    keys = [k for k in first if k in keys] + [k for k in keys if k not in first]
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); [w.writerow(r) for r in rows]
    print(f"{len(rows)} rows -> benchmarks/rdma/results.csv; any monitor/bench failure: {sum(int(r['mon']) for r in rows)}")
main()
