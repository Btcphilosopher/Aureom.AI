# 00 — Repository audit: what exists, what was reused, what was not

Audit date: 2026-11-20. Source: `btcphilosopher/Aureom.AI`, `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/*.zip` (each project is an archive; they were
extracted to a scratch directory and read there; **nothing in the repository was modified and nothing was committed**).

## 0. Two facts to state first

1. **There is no module named PacketForge** anywhere in the repository (searched archive entry names and contents for `packetforge`, `streamdma`, `pagewalker`, `memoryguard`, `pciebridge`, `meridian`, `datafabric`, `rdma`).
   The streaming network datapath is **PacketCore (Project 62, `silicaflux_packet_engine`)**; the brief's "PacketForge" is read as PacketCore. If PacketForge is meant to be a different, not-yet-uploaded
   block, the adapter in this project needs only the stream contract in `TRANSPORT_SPEC.md` §3.1 to connect to it.
2. **There is no Ethernet MAC/PHY, no RDMA, no RoCE and no InfiniBand code** in the repository (PacketCore's audit says the same for MAC/PHY). This project therefore cannot be verified against any external RDMA implementation, and does not claim to.

## 1. Blocks inspected

| Block (archive) | What it is | Fit for this project | Decision |
|---|---|---|---|
| **PacketCore P62** `silicaflux-packetcore-p62` | cloud network processor: AXI-S parse → classify → queues → scheduler; commit/abort store-and-forward; `sf_pkt_mac_adapter` for an existing MAC | **the streaming datapath the brief asks to connect to** | **Integrated**: the adapter speaks its stream contract exactly (frame byte 0 = `data[7:0]`, contiguous low `keep`, FCS excluded, `err` on last beat, runt ≥ 60 B). Vendored **unmodified** for the integration bench (`third_party/packetcore-p62`) |
| **StreamDMA P103 (r2)** `sf_stream_dma_align` | byte re-alignment gearbox, formally checked (`fv_align`) | exactly the primitive needed for unaligned memory↔stream movement | **Reused unmodified** in both DMA engines |
| StreamDMA P103 (rest) | protected memory→memory scatter-gather copy engine, AXI4-style bursts/IDs, descriptor ABI | copies memory→memory; this project moves memory↔stream with a simple in-order port | not reused (different data path); design lessons reused (guard before access, drain-then-flush, commit only after the write ack) |
| **DataFabric** `sfb_skid_buffer` | 2-entry valid/ready slice, formally checked (`fv_sfb_skid`) | transmit output register slice | **Reused unmodified** |
| **P40 FloorplanBuild** `sf_rr_arb` | round-robin arbiter (advance on accept) | transmit frame arbitration; read-command arbitration | **Reused unmodified** |
| `sync_fifo` (memory_cache_repo, vendored via PacketCore) | parameterised FIFO | no flush/clear, and uses `initial` blocks plus concurrent SVA that Yosys 0.33 cannot read | **not reused**; `sf_rdma_fifo` (flushable, formal-friendly) written instead |
| **MemoryGuard P104** | region-based protection of 4 *ports* × 4 *domains*; no keys, no protection domains of the RDMA kind, port-bound identity | a **different trust model**: RDMA needs key + PD + direction + translation context per region | not reused as the registry (written `sf_rdma_memory_registry`); its principles are followed (whole-range check in N+1 bits, deny-before-access, trusted configuration only, drain/refcount before reconfiguration). It remains the right *platform-level* second line behind this engine's own DMA guard |
| **PageWalker P108** | IOMMU: TLB + page-table walker reading SFB2 memory, 4-entry TLB, Sv39-compatible subset | v1 uses a **linear per-region mapping** (spec 8.1); page tables are out of scope | not reused; **integration point defined**: replace the linear `pa = pa_base + (va − va_base)` by a PageWalker translation request/response per page (spec 8.3 PAGE_CROSS already forces page-confined transfers on non-contiguous regions) |
| **PCIeBridge P110**, HostBridge M96, CloudDMA P64, MemoryMatrix P101, MeridianQoS P102 | host/PCIe attach, cloud DMA, banked SRAM, QoS | belong to the integration of this engine into a SoC (host memory path), not to the protocol engine | not used; MemoryMatrix is the natural local-memory target for `mrd_*/mwr_*` (word ports, in-order responses) |
| BufferCore P55, SRAM subsystems (P71–P80) | SRAM buffering | the adapter's payload rings are simple arrays that synthesize to SRAM/registers; no external macro needed | not used |

## 2. Vendored files (byte-identical to the repository; `third_party/MANIFEST.sha256`, checked by `scripts/check_vendor.py`)

| File | Origin | Role |
|---|---|---|
| `sfb_skid_buffer.sv` | `silicaflux-datafabric.zip → rtl/interconnect/` (same bytes as in PacketCore's `third_party/silicaflux-reused`) | TX output slice |
| `sf_rr_arb.sv` | `silicaflux-p40-floorplanbuild.zip → rtl/common/` | TX frame arbiter, read-command arbiter |
| `sf_stream_dma_align.sv` | `silicaflux-streamdma-p103-r2.zip → rtl/stream_dma/` | byte realigner in `sf_rdma_dma_rd` / `sf_rdma_dma_wr` |
| `packetcore-p62/**` | `silicaflux-packetcore-p62.zip` | integration bench only (`tests/rdma/integration`) |

## 3. What had to be written (nothing verified existed)
Memory-region registry with keys / PDs / refcounts, work queues with post-time validation, completion queue with credit reservation, queue-pair controller, requester / responder with sequence numbers, ACK/commit frontiers, retry and RNR,
the SFRT transport adapter, a flushable FIFO, performance counters, and the whole verification environment.

## 4. Environment
Verilator 5.020, Yosys 0.33, z3 4.8.12, Icarus 12 (Ubuntu 24.04 packages): the same toolchain versions the PacketCore, StreamDMA and PageWalker projects were verified with.
