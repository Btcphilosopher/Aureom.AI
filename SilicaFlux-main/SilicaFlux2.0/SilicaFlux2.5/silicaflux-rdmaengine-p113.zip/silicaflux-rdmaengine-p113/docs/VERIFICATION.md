# VERIFICATION — what was checked, by which oracle, and what that does and does not show

Evidence level throughout: **RTL simulation, small-instance formal checks, a generic-gate synthesis estimate.** No FPGA, no timing, no silicon (`LIMITATIONS.md`). Raw evidence is in `reports/`; every number below is reproduced by `python3 scripts/regress_all.py` (simulation), `scripts/mutate.py`, `scripts/formal.py`, `scripts/synth.py`, `benchmarks/rdma/bench.py`.

## 1. The layers, and what each one is an oracle for

| layer | oracle | what it can catch | what it cannot |
|---|---|---|---|
| **Directed suite**: 141 scenarios × 5 seeds | the **independent reference model** predicts every CQE (status, length, order), every byte of final memory, exact per-byte write counts, counter bounds | functional errors in every required behaviour (table in §2) | interleavings the op-level model cannot predict (forced errors mid-flight, injected memory errors) |
| **Random suites**: 6 seeds × 40 valid mixed scenarios, 6 seeds × 30 single-fault tails | same model | corner combinations (alignment × length × loss × reorder × latency) the author did not think of; found 3 RTL bugs the directed suite missed | same limit as above |
| **Review repros**: 16 scenarios | explicit expectation files (`.expect`) checked by `scripts/check_expect.py` | one scenario per defect the independent review found; **15 of the 16 fail on the pre-fix RTL** (rv11 needs the simulation-only fault injection, which was put into a copy of the old RTL to show its hang) and all pass now; `rv01c` is the control and passes on both | only what each file states |
| **Chaos suites**: 6 seeds × 80 | model-independent properties: exactly one CQE per accepted post, completions in post order, no OK after a failure, both QPs end in RESET | the flush / error / reset paths with traffic in flight | data correctness (a separate layer) |
| **Standing bench invariants** (every run of every scenario) | CQ credit conservation (DUT credits = `CQ_DEPTH` − unconsumed posts); *nothing open after a QP reset*; 20 bench monitors in all (handshake stability, one memory response per request, no mid-frame `tx_valid` gap, wire-level ACK/NAK frontier ordering `commit ⪯ accept`, fatal NAK only at `commit = accept`, …) | accounting drift, lost completions, protocol-timing violations | |
| **Parameter matrix**: DW 32/64/128 × MTU × WINDOW × MAX_RD, directed + random | model told the same parameters | parameter-dependent bugs (found a bench truncation at DW 128) | |
| **PacketCore (P62) in the receive path** | same model | integration of the real front end; 3 scenarios differ **by design** (PacketCore drops malformed and MAC-flagged frames before the engine can count them) | MAC/PHY (none involved) |
| **Mutation testing**: 57 (simulation) + 84 (formal) mutants | "does any test notice a planted defect?" | holes in the tests | says nothing about defects nobody planted |
| **Formal** (Yosys → SMT2 → z3) | assertions on RTL, small instances | unbounded: PSN modular arithmetic (all 24-bit values), the retry unit, CQ credit conservation, WQE posting, ACK generation; bounded (5–12 cycles): registry, DMA engines, receive-processor safety, requester. Found the S-01 bug independently | large instances, anything UNKNOWN |
| **Independent adversarial review** | a reviewer who had not written the RTL, white-box instrumentation of copies, ~2 000 further random and chaos runs | 1 critical, 3 high, 5 medium, 1 low defects (`REVIEW_FINDINGS.md`) | what it did not look at (its own list) |

Randomised initial state (`+verilator+rand+reset+2`) is used for every run: any state that is not reset shows up as a failure.

## 2. The brief's required tests → scenarios

| required test | directed scenarios (`tests/rdma/scenarios/`) |
|---|---|
| successful SEND | `t001`–`t006`, `t023`, `t125` (single, multi-segment, zero length, unaligned, MTU edges, length sweep) |
| successful WRITE | `t007`–`t011`, `t016`, `t021` |
| successful READ | `t012`–`t016`, `t022`, `t131` |
| **invalid key** | `t024`, `t025`, `t043`, `t045`, `t072`, `t134`–`t136` (single-bit key differences) |
| **out-of-range** | `t032`–`t042`, `t044`, `t132`, `t133` (above end, below start, last byte over, multi-segment partial, 2⁶⁴ wrap, exact fit) |
| **packet loss** | `t090`–`t099`, `t129`, `t131` (random and by ordinal, both directions, READ request lost, last ACK lost) |
| **duplicate** | `t087`–`t089`, `t100`–`t102` (stale duplicate must not overwrite newer data; duplicate READ re-executed) |
| **delayed ack** | `t105`, `t106` (spurious retransmission), and reordering by delay `t103`, `t104` |
| **retry** | `t107`, `t108`, `t140` (retry budget restarts on progress) |
| **timeout** | `t109`–`t112` (black-holed link → `RETRY_EXC_ERR`, later WQEs flushed) |
| **reset** | `t118`–`t122` (mid-traffic reset with a new epoch, hard reset of either side, forced ERR) |
| **queue saturation** | `t124`–`t128` (SQ, RQ, CQ credits, window) |
| **concurrent DMA** | `t020`, `t129`, `t137` (memory-latency jitter, loss, slow responder memory) |
| **domain isolation** | `t051`–`t054` (a different PD cannot read, write, use an lkey or an RQE), plus direction/permission `t046`–`t058`, translation `t059`–`t071` |
| final remote memory vs. an independent reference | every scenario: `dump` records are compared byte for byte with the model; in addition per-byte write counts and the read envelope |
| remote-write accept vs. commit | `t137`, `t138`, `t141` and the bench monitor "completion only after the `mwr_ack` of the last byte" |
| memory errors, forced errors, injected faults | `tests/rdma/review/rv01`–`rv14` (explicit expectations), chaos suites |

## 3. The reference model and why it is independent

`tests/rdma/model/` is written from `docs/TRANSPORT_SPEC.md` in Python, without reading the RTL. It resolves operations at the op level (one send-queue head at a time, with link impairments as outcome classes) and predicts: CQE sequences, final memory, per-byte write counts, the set of memory ranges that may legally be read, counter bounds (reliability counters are **bounds**, not equalities, because timing decides them). 101 self-tests exercise the model on its own. It was the only oracle that found three RTL defects the author's directed tests missed (`CHANGELOG.md` #3–#5).

Where the model and the RTL disagreed, the question was always "which one misread the spec?" — and the answer was a spec clarification (`CHANGELOG.md`, "Specification changes", and `tests/rdma/model/SPEC_QUESTIONS.md`), never a loosened check. **Limit:** author and model share one reading of the spec; a misreading both made would not be seen. The independent review is the only evidence against that: it reported no shared misreading (which is not a proof that there is none), and it did find that the spec's own deadlock-freedom argument is incomplete (S-04) and that the spec was silent on a READ that precedes a fatal NAK (now resolved, spec 9.5(6)).

What the model **cannot** do — and what covers it instead (spec A.6): it is op-level, so it cannot interleave a forced error, an injected memory error or an exact-cycle stall with frames in flight. Those scenarios carry explicit expectation files, and the chaos campaign checks model-independent conservation properties.

## 4. Defects verification found (all fixed; full table in `CHANGELOG.md`)

* **Author's own tests / first random campaign (5):** spurious ACK after set-up, QP reset hang, lost ACK in the same cycle as a commit, READ credit leak, retransmission of a retired entry (stopped by the DMA guard).
* **Independent review (10 confirmed + 3 suspected fixed):** memory error responses ignored (critical); a fatal NAK that hung a QP in RTS for ever; a RECV completion and CQ credit lost on reset; grants released while DMA was in flight; flush completions out of order; NAK/RNR events swallowed when coinciding with progress; ACK frontier overwritten by a retire fix-up; request frames leaving after ERR; QP reset hanging after a guard violation; a drop counter attributed out of order.
* **A regression introduced by one of the fixes and caught by the control scenario** (dropping READ responses after a fatal NAK) — recorded in `CHANGELOG.md` because it shows what the control scenarios are for.
* **Test-suite gaps found by mutation (5 + 2):** each closed by a new scenario or monitor.
* **Verification-infrastructure defects** (not RTL): bench `keep` truncation at DW 128, a benchmark that over-posted a receive queue, benchmark addresses outside the registered region, a synthesis script whose `chparam` ran too late (the `small`/`wide` estimates were never produced until now), a mutation driver that overwrote its full report on a partial run, and a **lint script that silently evaluated none of its 21 illegal-parameter checks** (a trailing comment swallowed the code after it) — found by reading the generated report. All three are fixed; the lesson is recorded because a green exit status was not evidence.

Defects the review found and that were **not** fixed (S-04 deadlock argument on back-pressured links, S-05, S-06) are in `LIMITATIONS.md` with the reason.

## 5. Results (this tree)

| check | result | evidence |
|---|---|---|
| Lint: Verilator `-Wall` over 8 legal parameter sets; 21 illegal sets must be **refused at elaboration**; Yosys elaboration of the full engine | all clean; **21 / 21 refused**; elaborates | `reports/lint.md` |
| Vendored IP byte-identical to the verified repo | OK | `third_party/MANIFEST.sha256`, `scripts/check_vendor.py` |
| Reference model self-tests | 101 / 101 | `tests/rdma/model/test_model.py` |
| **Directed suite**: 141 scenarios × 5 seeds, model as oracle | **705 / 705** | `reports/regression_all.md`, `reports/regression.md` |
| **Review repros**: one scenario per defect the independent review found | **16 / 16** (15 fail on the pre-fix RTL; `rv01c` is the control and passes on both) | `reports/regression_all.md`, `tests/rdma/review/` |
| **Random**: 6 seeds × 40 mixed scenarios; **fault tails**: 6 × 30 | **240 / 240**; **180 / 180** | `reports/regression_all.md` |
| **Chaos**: 480 scenarios with forced ERR/RESET at random moments | **480 / 480** (the same campaign finds the RQ-order defect 5 times on the pre-fix RTL) | `reports/regression_all.md` |
| **Parameter matrix**: 14 configurations (DW 32/64/128, MTU 64–1024, WINDOW 2–16, MAX_RD 1–4), directed + 120 random each | **all pass** (139–141 directed, 120 random each) | `reports/regression_matrix.md` |
| **PacketCore (P62) in the receive path** | 138 / 141; the 3 differences (`t084`, `t085`, `t139`) are drop *counters* only: PacketCore filters malformed and MAC-flagged frames before the engine counts them | `reports/regression_packetcore.md` |
| **Mutation testing (simulation)** | **57 / 57** mutants killed | `reports/mutation.md` |
| **Formal** (Yosys → SMT2 → z3), small instances | 130 jobs: **6 PROVED** (unbounded: retry unit, CQ credits, WQE posting, ACK generation, PSN arithmetic ×2), **14 BOUNDED** (5–22 cycles), **110 WITNESSED** (non-vacuity), 0 UNKNOWN. Formal mutants: **81 / 84 killed**, 1 survived (equivalent on that instance), 2 UNKNOWN. One real bug found independently (S-01). | `reports/formal.md`, `formal/rdma/README.md` |
| **Independent adversarial review** | 1 critical, 3 high, 5 medium, 1 low confirmed → all fixed; 3 suspected, 3 documented | `docs/REVIEW_FINDINGS.md`, `docs/CHANGELOG.md` |
| **Synthesis estimate** (Yosys generic gates; arrays counted as flip-flops; **no timing, no mapping**) | default 198 159 cells / 38 829 FFs · small (DW 32, MTU 64, WINDOW 4, NMR 4) 137 917 / 21 682 · wide (DW 128, MTU 512, WINDOW 16) 259 866 / 56 265 | `reports/synth.md` |
| **Benchmarks** (cycle-accurate simulation; **no clock claimed**) | ≈ 6.0 B/cycle large-transfer WRITE/READ = 75 % of the 8 B/cycle stream peak (DW 64, MTU 256); 58-cycle unloaded 8-byte latency; DW 128 → 11.05 B/cycle | `benchmarks/rdma/REPORT.md`, `docs/PERFORMANCE.md` |

## 6. Honest caveats about the evidence

* **All directed, random and chaos scenarios run on one memory model** (in-order, pipelined, fixed or jittered latency) and one link model. A reordering memory or a back-pressuring link is not modelled; the deadlock-freedom argument for the latter is *argued, not verified* (S-04).
* **Seeds only randomise reset state and the scenario generators**; Verilator is two-state. X-propagation problems are not exercised (`--x-initial unique` randomises initial values instead).
* **Formal results are for small instances** (`formal/rdma/README.md` lists every instance and whether the result is PROVED or BOUNDED); nothing is claimed for the default parameters beyond what the simulation shows.
* **Synthesis numbers are generic-gate counts** (arrays are counted as flip-flops, no mapping, no timing): a size indication only.
* The mutation set is the author's list of plausible defects; its kill rate is a statement about the tests, not about the RTL.
