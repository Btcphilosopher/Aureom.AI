# SilicaFlux RDMA Transport Specification — SFRT v1 (Project 113)

**Status: NORMATIVE for the RTL, the reference model and the testbench of this project.**
Where this document and the RTL disagree, one of them has a bug; the disagreement is reported, never silently resolved.

> ## What this is NOT
> SFRT is an **internal SilicaFlux protocol**. It is **not RoCEv2, not InfiniBand, not iWARP**, it does not interoperate with them, and
> nothing here may be described as a standards-compliant RDMA stack. It borrows *concepts* (queue pairs, memory regions with keys and
> protection domains, 24-bit PSNs, cumulative acknowledgement, go-back-N retransmission, RNR) because they are well understood.
> The wire format, the opcodes, the ACK semantics and the error semantics are SilicaFlux's own.
> Interoperability is a separately verified future milestone (`docs/FUTURE_EXPANSION.md`).

## 0. Conventions

* "MUST / MUST NOT / MAY" are normative. All numbers are decimal unless prefixed `0x`.
* **PSN arithmetic** is modulo 2^24. `a ≺ b` ("a before b") iff `((b − a) mod 2^24) ∈ [1, 2^23 − 1]`. `a ⪯ b` iff `a = b` or `a ≺ b`.
  `dist(a,b) = (b − a) mod 2^24`.
* **Multi-byte header fields are big-endian** (network order) *in byte positions*; byte 0 of a frame is `data[7:0]` of beat 0 (AXI-S convention
  of PacketCore, see §3.1).
* **Endpoint** = one instance of `sf_rdma_engine` (one QP). **Requester** = the endpoint role that posts a SEND/WRITE/READ work request.
  **Responder** = the role that executes it. Every endpoint is both, simultaneously.
* **Local memory** = the memory behind an endpoint's `mrd_*`/`mwr_*` ports. **PA** = a physical address on those ports; **VA** = the 64-bit
  address space of memory regions.

## 1. Scope (the subset that is defined)

| Item | v1 |
|---|---|
| Queue pairs per endpoint | **1** (reliable-connected, point-to-point) |
| Work-request opcodes | `SEND`, `RDMA WRITE`, `RDMA READ`. Every other value is **explicitly rejected** (§6.3, §7.5) |
| Immediate data, atomics, SEND-with-invalidate, multicast, unreliable transports, SRQ | **not supported** (opcode space reserved, §3.3) |
| Message size | ≤ `MAX_MSG_BYTES` (default 1 MiB); segmented into frames of ≤ `MTU` payload bytes |
| Connection setup | by **trusted configuration only** (§5). There is no connection-management protocol |
| End-to-end data integrity (ICRC-like) | **none**. The link (MAC FCS) is responsible; the adapter takes a frame-error flag and drops flagged frames |
| Congestion control | **none** beyond the fixed window and RNR back-off |
| Address translation | **linear per-region mapping** plus a mapping-context enable (§8.3); no page tables (PageWalker integration is future work) |

## 2. The simulated reliable transport (what the protocol is built on)

The "simulated transport" is a **frame link** between two endpoints. It is modelled explicitly (testbench `link` model); the reliability is
**implemented by the endpoints**, not assumed from the link.

The link:
* carries whole frames (never partial frames); each frame is delivered **complete or not at all**;
* **MAY drop** any frame, **MAY duplicate** any frame, **MAY delay** any frame by an arbitrary but finite time, **MAY reorder** frames (a
  consequence of unequal delays);
* **never corrupts** a frame silently (a corrupted frame is signalled with the `rx_err` flag on its last beat and MUST be dropped by the
  receiver, exactly as a MAC reports an FCS failure);
* carries frames in **both directions independently**; a frame is delivered at most (1 + number of duplications) times.

The protocol therefore provides, per direction, on top of this link:
**exactly-once effect, in order, with bounded retries; or an explicit error** (§11). It does **not** provide exactly-once *knowledge*: after
a transport failure the requester may not know whether a request took effect (§11.3).

## 3. Frame format

### 3.1 Stream contract (identical to PacketCore, `third_party/packetcore-p62`)

AXI4-Stream subset: `valid/ready`, `data[DW-1:0]`, `keep[DW/8-1:0]`, `last`, and `err` sampled on the last beat only.
**Byte 0 of the frame is `data[7:0]` of beat 0; byte *k* of a beat is `data[8k+7:8k]`.** `keep` is all-ones on every beat except the last; on the
last beat it is a contiguous low-order mask (`2^n − 1`, n ≥ 1). There is no SOP signal: the first beat after a `last` starts a frame.
Frames **exclude** the Ethernet FCS. Data under `keep = 0` is never used. DW ∈ {32, 64, 128}.

### 3.2 Layout

Frame = **14-byte Ethernet header + 34-byte SFRT header + payload**. The 48-byte prefix is a multiple of 16 so that the payload is beat-aligned
for every supported DW.

| Frame byte | Size | Field | Notes |
|---|---|---|---|
| 0–5 | 6 | `dst_mac` | MUST equal the receiver's configured `local_mac` |
| 6–11 | 6 | `src_mac` | MUST equal the receiver's configured `peer_mac` |
| 12–13 | 2 | `ethertype` = **0x88B5** | IEEE 802 "Local Experimental EtherType 1" |
| **SFRT header** (byte 14 = SFRT byte 0) | | | |
| 14 | 1 | `ver_flags` | `[7:4]` = version = **1**; `[3]` reserved = 0; `[2]` `RETX`; `[1]` `LAST`; `[0]` `FIRST` |
| 15 | 1 | `opcode` | §3.3 |
| 16–17 | 2 | `qpn` | destination QP number; MUST equal the receiver's `local_qpn` |
| 18–19 | 2 | `epoch` | connection generation; MUST equal the receiver's configured `epoch` |
| 20–22 | 3 | `psn` | requests: PSN of this request. `READ_RESP`: PSN of the READ request it answers. `ACK`/`NAK`: **`commit_next`** |
| 23–24 | 2 | `paylen` | payload bytes in this frame (0 … MTU) |
| 25–28 | 4 | `mlen` | `SEND`/`WRITE`: total message length. `READ_REQ`: total length of the read message. `READ_RESP`: same as the request. |
| 29–32 | 4 | `moff` | byte offset of this frame's data within the message (`READ_REQ`: first offset requested) |
| 33–40 | 8 | `va` | `WRITE`: remote VA of **this segment's first byte**. `READ_REQ`: remote VA of the **first requested byte** (= message VA + `moff`). Otherwise 0 |
| 41–44 | 4 | `rkey` | `WRITE`/`READ_REQ`: remote memory key. `ACK`/`NAK`: bytes 41–43 are 0 and **byte 44 = `code`** (0 for `ACK`, the NAK code otherwise). Otherwise 0 |
| 45–47 | 3 | `accept_next` | **`ACK`/`NAK` only** (big-endian). Otherwise reserved, 0 |
| 48 … | `paylen` | payload | |

The 34-byte SFRT header is a fixed-size union. For `ACK`/`NAK` frame bytes 33–43 are 0, **byte 44 = `code`** and **bytes 45–47 = `accept_next`**.
Senders MUST transmit reserved bits/bytes as 0. Receivers MUST ignore (not reject) non-zero values in bytes documented "otherwise 0" or
unused by the opcode, except for the reserved flag bit `[3]`, whose non-zero value is a malformed frame.

**Frame length rule.** `frame_len = max(60, 48 + paylen)`. Bytes after `48 + paylen` are padding (ignored, transmitted as 0). `ACK`, `NAK` and
`READ_REQ` MUST have `paylen = 0`. A frame whose length differs from the rule, or that is shorter than 48 bytes, is **malformed**.

### 3.3 Opcodes

| `opcode` | Name | Class | v1 |
|---|---|---|---|
| 0x01 | `SEND` | request | supported |
| 0x02 | `WRITE` | request | supported |
| 0x03 | `READ_REQ` | request | supported |
| 0x04 – 0x0F | *reserved request opcodes* (atomics, immediates, …) | request | **unsupported** → explicit rejection (§7.5) |
| 0x10 | `READ_RESP` | response | supported |
| 0x20 | `ACK` | control | supported |
| 0x21 | `NAK` | control | supported |
| anything else | — | — | malformed: dropped and counted |

`NAK.code`: **1 `SEQ_ERR`**, **2 `RNR`**, **3 `INV_REQ`**, **4 `REM_ACCESS`**, **5 `REM_OP`**; other values → the NAK is ignored and counted (`rx_nak_badcode`).

### 3.4 Adapter-level validation (before any protocol state is touched)

A received frame is **dropped whole** (never presented to the protocol engine, never touching memory) and counted in a named counter if:
runt (< 48 bytes or violates the length rule) → `rx_drop_len`; `keep` illegal → `rx_drop_keep`; `err` on last beat → `rx_drop_macerr`;
ethertype ≠ 0x88B5 → `rx_drop_ethertype`; `dst_mac ≠ local_mac` or `src_mac ≠ peer_mac` → `rx_drop_mac`; version ≠ 1 or reserved flag bit set → `rx_drop_ver`;
opcode not in §3.3 → `rx_drop_opcode`; `paylen > MTU` or the class rule on `paylen` violated → `rx_drop_len`; `qpn ≠ local_qpn` → `rx_drop_qpn`;
`epoch ≠ epoch(QP)` → `rx_drop_epoch`. Evaluation order is as listed (first match is counted). If the QP is not in a state that accepts the
frame (§5.2), it is counted in `rx_drop_state`. **The payload of a frame is stored and the frame is committed only when the *whole* frame
has been received and validated** (store-and-forward at the adapter): a truncated or flagged frame never leaves a partial effect.

## 4. Roles of the blocks (architecture contract)

```
 post_send ─► SQ ─► QP controller ─► Memory-registration check (local) ─► Data movement (read) ─► Transport adapter ─► link
 post_recv ─► RQ ─┘                                                                                              │
 link ─► Transport adapter ─► Packet/operation validation ─► Memory protection (remote) ─► Data movement (write) ─► response / completion
```
Only the **memory registry** can convert (key, PD, VA, length) into a physical address. The data-movement engines accept only the physical
window produced by a registry grant, and re-check every command against the registry's physical window and reference count
("guard", §8.5) before issuing the first memory access. There is no other path from a packet or a WQE to a memory address.

## 5. Queue pair

### 5.1 State machine

`RESET → INIT → RTR → RTS`, and `ERR`. Transitions are **commands on the trusted configuration port**; nothing on the wire or in a WQE can change QP state
except the fatal-error transitions to `ERR` listed in §11.

| Command (target) | Attributes latched | Legal from |
|---|---|---|
| →`INIT` | `local_qpn[15:0]`, `pd[PD_W-1:0]` | `RESET` |
| →`RTR` | `remote_qpn[15:0]`, `epoch[15:0]`, `rq_psn[23:0]`, `local_mac[47:0]`, `peer_mac[47:0]` | `INIT` |
| →`RTS` | `sq_psn[23:0]`, `timeout[31:0]` (cycles, ≥ 1), `retry_max[3:0]`, `rnr_retry_max[3:0]`, `rnr_delay[31:0]` (cycles) | `RTR` |
| →`ERR` (forced; cause `CFG_FORCED`) | — | any state except `RESET` |
| →`RESET` | — | any state (§11.5) |

Any other transition is refused with `cfg status = ERR_STATE` and has no effect.

### 5.2 What each state accepts

| State | post RQ | post SQ | requests from wire (responder) | responses/ACK/NAK from wire (requester) | requester issues |
|---|---|---|---|---|---|
| RESET, INIT | INIT only | no | dropped (`rx_drop_state`) | dropped | no |
| RTR | yes | no | **processed** | dropped | no |
| RTS | yes | yes | processed | processed | yes |
| ERR | no | no | dropped, **except** NAK replay (§11.2) | dropped | no |

The QP's `pd` is the protection domain against which **every** registry check made on behalf of this QP is evaluated (local *and* remote).
It is configured only by the trusted port; the wire never supplies a PD.

## 6. Work requests

### 6.1 SQ WQE (fields on the post port)

| Field | Bits | Meaning |
|---|---|---|
| `op` | 4 | `1` SEND, `2` WRITE, `3` READ; anything else is unsupported |
| `wr_id` | 64 | returned verbatim in the CQE |
| `laddr`, `lkey`, `len` | 64, 32, 32 | local buffer: SEND/WRITE source, READ destination |
| `raddr`, `rkey` | 64, 32 | WRITE/READ remote target; ignored for SEND |
| `flags` | 4 | reserved, MUST be 0 |

### 6.2 RQ WQE: `wr_id` (64), `addr` (64), `lkey` (32), `len` (32). A SEND consumes **one** RQ WQE per message.

### 6.3 Post-time validation (explicit rejection)

The post interface returns a **post status** one cycle after the handshake. A rejected WQE is **not** enqueued, consumes no queue slot, no
CQ credit, and has no effect on QP state (it is a local software error, reported synchronously, as `ibv_post_send` does).

| Status | Code | When |
|---|---|---|
| `POST_OK` | 0 | accepted |
| `POST_ERR_OPCODE` | 1 | SQ `op` ∉ {1,2,3} (**unsupported opcode**) |
| `POST_ERR_STATE` | 2 | SQ: QP not in RTS. RQ: QP not in INIT/RTR/RTS |
| `POST_ERR_LEN` | 3 | `len > MAX_MSG_BYTES`; or `len = 0` for WRITE/READ (zero-length SEND is legal) |
| `POST_ERR_FIELDS` | 4 | `flags ≠ 0` |
| `POST_ERR_RANGE` | 5 | `raddr + len > 2^64` (WRITE/READ) or `addr + len > 2^64` (RQ) — a message must not wrap the 64-bit space |

Evaluation order: STATE, OPCODE, FIELDS, LEN, RANGE (first match wins). A full queue or exhausted CQ credit is **not** an error: `post_ready` is
deasserted (back-pressure) and the producer waits.

## 7. Operation semantics

All three operations are carried by **requests** with consecutive PSNs. A message of length L (SEND/WRITE) occupies `max(1, ceil(L / MTU))` PSNs, one per frame
("segment"): segment *i* has `moff = i·MTU`, `paylen = min(MTU, L − moff)`; `FIRST` iff `moff = 0`; `LAST` iff `moff + paylen = L`.
A READ occupies **one** PSN (the request); its *responses* are not PSN-numbered requests.

### 7.1 SEND

* **Requester.** Registry check (local, `LOCAL_READ`, `lkey`, `pd`, `laddr`, `len`) at issue time; skipped for `len = 0`. Frames carry the payload read from local memory.
* **Responder, first segment (`moff = 0`).** If the RQ is empty → **RNR NAK**, nothing consumed. Otherwise the RQ WQE is consumed; `mlen > rqe.len` → fatal `REM_OP`
  (the consumed RQE completes with `LOC_LEN_ERR`); registry check (`LOCAL_WRITE`, `rqe.lkey`, `pd`, `rqe.addr`, `rqe.len`) fails → fatal `REM_OP`
  (RQE completes with `LOC_PROT_ERR`) — skipped when `rqe.len = 0`. Payload of segment at `moff` is written at `rqe.addr + moff`
  (PA = grant PA + `moff`).
* **Acknowledgement.** The responder ACKs a SEND segment **after the segment's bytes are committed** (§10).
* **Requester completion.** CQE `{op=SEND, status=OK, byte_len=len}` when the commit frontier passes the **last** segment (= data committed in the responder's receive buffer).
* **Responder completion.** CQE `{op=RECV, status=OK, wr_id=rqe.wr_id, byte_len=mlen}` is produced **after the last segment is committed and before the ACK that
  covers it is generated** (so a requester that has seen its SEND complete can rely on the receiver's CQE existing).

### 7.2 RDMA WRITE

* **Requester.** Registry check (local, `LOCAL_READ`, `lkey`, `pd`, `laddr`, `len`) at issue; each frame carries its own `va`/`rkey`.
* **Responder.** Per frame: registry check (**remote**, `REMOTE_WRITE`, `rkey`, `pd`, `va`, `paylen`); on success the frame payload is written to the granted PA. A failed check is fatal `REM_ACCESS`; **no byte of that frame, nor
  of any later frame, is written.** No RQ WQE is consumed; no responder CQE.
* **Requester completion.** CQE `{op=WRITE, status=OK, byte_len=len}` when the commit frontier passes the last segment.

### 7.3 RDMA READ

* **Requester.** Registry check (local, `LOCAL_WRITE`, `lkey`, `pd`, `laddr`, `len`) at issue (the destination buffer); one `READ_REQ` frame (`va = raddr`, `rkey`, `mlen = len`, `moff = 0`).
  The entry retires, and the CQE `{op=READ, status=OK, byte_len=len}` is produced, when **all `len` response bytes have been committed to local memory**.
* **Responder.** In order, after validation: registry check (remote, `REMOTE_READ`, `rkey`, `pd`, `va`, `mlen − moff`) — failure is fatal `REM_ACCESS`, and **no memory read is issued**. The request is placed in a read queue and
  executed by an engine that is decoupled from frame reception (§12.3). **Read-after-write fence:** the read is executed only after every earlier-PSN request of this QP has *committed* (`commit_next ⪰ psn`).
  The read data is returned in `READ_RESP` frames: `psn` = request PSN, `moff` = offset of the segment within the message, `paylen ≤ MTU`, `mlen` = message length, `LAST` iff `moff + paylen = mlen`.
* **Ordering guarantee limits.** There is **no** ordering guarantee between the data fetch of a READ and the placement of *later-PSN* WRITE/SEND data of the same QP to overlapping memory (as in InfiniBand,
  the application orders conflicting accesses by waiting for the READ completion). A **duplicate** READ (retransmission) is **re-executed against current memory** and may observe later writes.
* **Requester response handling.** A `READ_RESP` segment is accepted iff the READ entry for `psn` is outstanding and incomplete, `moff` equals the entry's next-expected offset, and `moff + paylen ≤ mlen_entry`; otherwise it is dropped
  (`rx_resp_drop`). In particular **a responder can never cause the requester to write outside the validated destination window.**
* **READ retransmission** resumes at the next-expected offset: the retransmitted `READ_REQ` carries `moff = next_off`, `va = raddr + next_off`, `mlen` unchanged.

### 7.4 Request validity rules at the responder (in-order requests only; violations are fatal `INV_REQ`)

1. The opcode is supported (§3.3), otherwise **fatal `INV_REQ`** — this is the explicit rejection of unsupported wire opcodes.
2. `moff + paylen ≤ mlen`; `FIRST ⇔ moff = 0`; for SEND/WRITE `LAST ⇔ moff + paylen = mlen`; for READ_REQ `LAST = 1`, `paylen = 0`, `moff < mlen`; WRITE: `paylen ≥ 1`; `mlen ≤ MAX_MSG_BYTES`.
3. SEND continuation (`FIRST = 0`) requires a message in progress with equal `mlen` and `moff` = bytes received so far; `FIRST = 1` requires **no** message in progress; any other opcode while a SEND message is in progress is invalid.

### 7.5 Explicit rejection of unsupported operations — summary

| Where | What | Result |
|---|---|---|
| post port | `op ∉ {1,2,3}` | `POST_ERR_OPCODE`, counter `post_rej_opcode`, nothing enqueued |
| wire, in-order request with opcode 0x04–0x0F | fatal `INV_REQ`: NAK(`INV_REQ`), responder QP → ERR, counter `rx_unsupported_op` | requester WQE completes `REM_INV_REQ_ERR` |
| wire, opcode outside §3.3 | dropped, counter `rx_drop_opcode` | — |

## 8. Memory registration

### 8.1 Table entry (written only through the trusted configuration port)

`valid`, `key[31:0]`, `va_base[63:0]`, `len[31:0]`, `pa_base[PA_W-1:0]`, `pd[PD_W-1:0]`, `acc[7:0]`, `ctx[CTX_W-1:0]`, `refcnt`.
`acc`: bit0 `LOCAL_READ`, bit1 `LOCAL_WRITE`, bit2 `REMOTE_READ`, bit3 `REMOTE_WRITE`, bit4 `CONTIG` (the region is physically contiguous across page boundaries), bits 5–7 reserved = 0.
The table has `NMR` entries (default 8). The mapping is **linear**: `PA(va) = pa_base + (va − va_base)`.

### 8.2 Configuration commands (trusted port)

| Command | Effect | Status |
|---|---|---|
| `MR_SET idx` | install entry. Requires slot invalid | statuses, **evaluated in exactly this order, first match wins**: `ERR_IDX` (idx ≥ NMR), `ERR_EXISTS` (slot valid), `ERR_FIELDS` (len = 0, or reserved `acc` bits 7:5 set), `ERR_RANGE` (`va_base + len > 2^64` or `pa_base + len > 2^PA_W`), `ERR_DUPKEY` (key equals the key of another **valid** entry). A `pd` or `ctx` outside the field width cannot be presented at all (the port is `PD_W` / `CTX_W` bits wide) and is therefore not a status. |
| `MR_INVAL idx` | `valid ← 0`. Takes effect only if `refcnt = 0` | `ERR_IDX`, `ERR_NOENT` (slot not valid), `ERR_BUSY` (`refcnt ≠ 0`: an accepted operation still holds the region) |
| `CTX_SET mask` | `ctx_en ← mask` (bit *c* enables mapping context *c*); reset value `0b0001` | always OK |

Keys of valid entries are **unique** (enforced by `ERR_DUPKEY`), so a key identifies at most one valid region.

### 8.3 The check function (normative; order of fault classification is normative, the grant condition is the conjunction of all clauses)

Input: `op ∈ {LOCAL_READ=0, LOCAL_WRITE=1, REMOTE_READ=2, REMOTE_WRITE=3}`, `key`, `pd` (**the QP's**), `va`, `len`. Output: `grant` + `(rid, pa, ctx)`, or a fault. First match wins:

| # | Fault | Condition |
|---|---|---|
| 1 | `BAD_KEY` (2) | no valid entry has `key` |
| 2 | `BAD_PD` (3) | `entry.pd ≠ pd`  (**domain isolation: a correct key alone never grants**) |
| 3 | `BAD_DIR` (4) | the entry grants **no** right at all in the direction of `op` (local rights = acc[1:0] for LOCAL_*, remote rights = acc[3:2] for REMOTE_*) |
| 4 | `BAD_PERM` (5) | the specific right (acc bit `op`) is missing |
| 5 | `BAD_LEN` (6) | `len = 0` or `len > MAX_MSG_BYTES` |
| 6 | `OVERFLOW` (7) | `va + len > 2^64` (computed in 65 bits: no wrap-around can alias a low address) |
| 7 | `RANGE` (8) | not (`entry.va_base ≤ va` and `va + len ≤ entry.va_base + entry.len`) — the **whole** range, first and last byte, must be inside **one** region |
| 8 | `PAGE_CROSS` (9) | region not `CONTIG` and `floor(va / PAGE_BYTES) ≠ floor((va + len − 1) / PAGE_BYTES)` (PAGE_BYTES = 4096) |
| 9 | `XLATE` (10) | `ctx_en[entry.ctx] = 0` (translation context not live) |

`BAD_OP` (1) is returned for an `op` encoding outside 0–3 (cannot occur from the engine; checked for completeness).
On grant: `pa = entry.pa_base + (va − entry.va_base)`, `ctx = entry.ctx`, and **`refcnt` of the entry is incremented** (the reference is released by the
owner of the grant when the operation retires). Checks never modify anything else. Every fault increments a per-class saturating counter and updates a one-entry fault log (`op, key, va, len, fault`).

### 8.4 Reference ownership (why `ERR_BUSY` exists)
A grant holds its region until released: requester local grants are released when the WQE retires; responder grants when the frame's commit completes (WRITE/SEND segment) or when the READ
has been fully fetched (a SEND message's RQE grant is released at the end of the message). `MR_INVAL` therefore can never pull a region out from under an in-flight DMA.

### 8.5 DMA guard (defence in depth)
Every DMA command carries `(rid, pa, len)`. Before the first memory access of a command the engine asks the registry whether `entry[rid]` is valid, `refcnt[rid] > 0`, and
`pa_base ≤ pa` and `pa + len ≤ pa_base + entry.len`. If not, **no memory access is issued**, the command is dropped, `guard_violation` is counted, and the QP enters `ERR` (cause `INT_ERR`). This cannot happen unless the engine itself is wrong;
it exists so that a bug in offset arithmetic cannot become an out-of-region access.

## 9. Sequencing, acknowledgement and retry

### 9.1 Requester state
`una` (oldest unfinished PSN), `nxt` (next PSN to allocate), `txp` (next PSN to (re)transmit, `una ⪯ txp ⪯ nxt`), `hi` (highest PSN transmitted + 1; a frame with PSN ≺ `hi` is a retransmission and carries `RETX`).
Outstanding window: `dist(una, nxt) ≤ WINDOW` (default 8). Outstanding READ requests ≤ `MAX_RD` (default 2). The peer's read-request queue depth is **not negotiated**; a `MAX_RD` larger than it only costs RNR retries (§12 rule 5), it never breaks correctness.
Each outstanding PSN has a table entry holding everything needed to **re-create the frame** (opcode, flags, VA, rkey, local PA window, lengths, offsets), so a retransmission re-reads payload from local memory.

### 9.2 Responder state
`epsn` = **`accept_next`**: the PSN of the next request to be accepted. `cpsn` = **`commit_next`**: every request with PSN ≺ `cpsn` has been executed to completion. Invariant: `cpsn ⪯ epsn` and `dist(cpsn, epsn) ≤ WINDOW`.
Initially `epsn = cpsn = rq_psn`.
**Accepted** = validated and handed to the data-movement engine (WRITE/SEND), or placed in the read queue (READ). **Committed** = for WRITE/SEND, **every byte has been acknowledged by the memory write port** (and, for the last segment of a SEND, the RECV CQE has been
produced); for READ, the read data has been fetched from memory into the transmit buffer.

### 9.3 Classification of a request frame (psn vs `epsn`), after adapter validation
* `psn = epsn` → **in order**: validated per §7.4, executed per §7. If accepted: `epsn ← epsn + 1`, the "NAK already sent" flag is cleared.
* `epsn ≺ psn` → **out of sequence**: the frame has no effect (payload discarded); if the "NAK already sent" flag is clear, send `NAK(SEQ_ERR)` and set the flag; counter `rx_oos`.
* `psn ≺ epsn` → **duplicate**: the frame has **no effect on memory, on `epsn`, on the RQ, or on any CQ**; an ACK is scheduled (it carries the current frontiers); counter `rx_dup`. Exception: a duplicate `READ_REQ` is **re-executed** (§7.3) after a fresh registry check (a failing recheck is ignored and counted `rx_dup_read_fault`).

### 9.4 ACK and NAK
`ACK`: `psn = cpsn`, `accept_next = epsn`, `code = 0`. `NAK`: `psn = cpsn`, `accept_next = epsn`, `code ≠ 0`; a NAK always concerns **the request with PSN `epsn`** (for `SEQ_ERR`: "I am waiting for `epsn`").
ACKs are cumulative and idempotent. An ACK is scheduled when `cpsn` advances, when a duplicate is detected, and **opportunistically for acceptance** when `epsn ≠ the epsn last reported` and nothing has been reported for `ACCEPT_ACK_DELAY` cycles (this tells the requester
"received and executing" so that slow commits do not cause spurious retransmission). Coalescing: one ACK reflects the frontiers at the moment it is built; any number of commits between two ACKs are covered by one ACK.
**Fatal NAKs (3, 4, 5) are emitted only after `cpsn = epsn`**, i.e. after every previously accepted request has committed; therefore a fatal NAK always satisfies `commit_next = accept_next = PSN of the failed request`.

### 9.5 Requester processing of ACK/NAK
A frame with `(cn, an)` is **valid** iff `dist(una, cn) ≤ dist(una, an) ≤ dist(una, nxt)` (otherwise it is stale/forged: ignored, counted `rx_ack_stale`).
1. Every entry with PSN ≺ `cn` is marked **committed**. WRITE/SEND entries become *done*; a READ entry stays incomplete until its data has been placed.
2. If `an ≻ una_at_last_progress` or `cn` advanced, that is **progress**: the timer restarts and the consecutive-retry counter resets to 0.
3. Retire: while the entry at `una` is done, release its resources, `una ← una + 1`; when the **last** entry of a WQE retires, the WQE's CQE is produced (so SQ completions are **in post order**).
4. `NAK(SEQ_ERR)`: `txp ← an` (go-back-N from the responder's expected PSN) if `txp ≻ an`; counts as a retry (§9.6).
5. `NAK(RNR)`: transmission stops; after `rnr_delay` cycles `txp ← an`; counts against `rnr_retry_max` (§9.6).
6. Fatal NAK (3/4/5) whose `accept_next` names an **outstanding** request (`una ⪯ an ≺ nxt`; a NAK that names no outstanding request is ignored): remember `err_psn = an`, `err_status` = `REM_INV_REQ_ERR` / `REM_ACCESS_ERR` / `REM_OP_ERR`; stop issuing. When retirement reaches `err_psn` the WQE owning it completes with that status, then the QP enters `ERR` (§11.1).
   **Entries before `err_psn` must still complete.** WRITE/SEND entries already did (a fatal NAK is emitted only after `cpsn = epsn`); an earlier **READ** still needs its response data. Therefore, while a fatal NAK is pending, the retransmission timer keeps running as long as `una ≺ err_psn`, and **only entries with PSN ≺ `err_psn` are (re)transmitted** (never the failed request or later ones). A responder in fatal mode never re-executes a READ (§11.2), so a READ whose response was lost cannot be recovered: it ends `RETRY_EXC_ERR` when the retries are exhausted, that failure takes the place of the fatal NAK's status, and the faulty WQE is flushed (`WR_FLUSH_ERR`). (Resolves SPEC_QUESTIONS #12; before this rule nothing completed and the QP stayed in `RTS` for ever.)

### 9.6 Timeout and retry policy
* The retransmission timer runs while there is an unfinished entry **and something has been transmitted** (`txp ≻ una`). It restarts on progress and on every retransmission.
* On expiry with `k` consecutive retries so far: if `k = retry_max` → **retry exhausted** (§11.1); else `k ← k + 1`, `txp ← una` (go-back-N from the oldest unfinished PSN), counter `retry_timeout`. Effective timeout = `timeout << min(k, BACKOFF_MAX)` (`BACKOFF_MAX` = 3).
* SEQ_ERR-driven retransmission also increments `k` (counter `retry_nak`). **A NAK that arrives in the same cycle as progress is still a NAK**: progress first resets the consecutive-retry counters, then the NAK is counted against the restarted base and acted on (go-back-N / RNR back-off start immediately; they are *not* left to the retransmission timer). A SEQ_ERR NAK normally travels together with a commit-frontier advance, so this is the common case.
* **RNR:** the retransmission timer does **not** run while the requester waits out `rnr_delay`, and an RNR NAK is **not** progress. A separate counter `r`; `r = rnr_retry_max` at the next RNR NAK → **RNR retry exhausted**; otherwise `r ← r + 1`; the counter `retry_rnr` counts the RNR **retransmissions** (it ticks when the `rnr_delay` has elapsed and the request is sent again, not when the NAK arrives). `r` resets on progress.
* Retransmission re-reads payload from local memory; the application MUST NOT modify a posted source buffer until the WQE completes.

### 9.7 Local errors: memory error responses (cause `LOC_OP_ERR`)
The memory interface may answer a read with an error response and acknowledge a write with an error (`mrd_rsp_err`, `mwr_ack_err`). The engine never transmits or commits data that comes from a failed access:
1. **Requester, source read of a request payload** (SEND/WRITE). The frame is built in the adapter but **never transmitted** (it is dropped when it would start; nothing leaves on the link). The WQE owning the entry completes `LOC_OP_ERR` once every earlier WQE has retired (like a fatal NAK: stop issuing, only earlier entries are still transmitted), then the QP enters `ERR` with cause `INT_ERR`.
2. **Requester, placement of READ response data.** The write of the READ's destination failed: the READ WQE completes `LOC_OP_ERR` (after the earlier WQEs), cause `INT_ERR`. The WQE's local grant is released only after every placement write of that READ has ended.
3. **Responder, fetch of READ data.** The response frame is **not sent**; the responder QP enters `ERR` (`INT_ERR`). There is no WQE to fail. The requester is not told (§11.2) and ends `RETRY_EXC_ERR`.
4. **Responder, write of an incoming WRITE/SEND.** The entry is marked failed: it is **not acknowledged** (the QP is in `ERR`, nothing is sent), the QP enters `ERR` (`INT_ERR`), and if the entry belongs to a SEND, the **RECV completes `LOC_OP_ERR`** (never `OK`, with length 0).
In every case the failing memory access leaves no garbage in the peer's memory and no `OK` completion for data that is not there.

## 10. Remote write safety (the contract)

1. **A request is applied at most once.** Application is decided by PSN alone: a frame with `psn ≺ epsn` never causes a memory write, a RQE consumption or a CQE, however many times it is delivered. Therefore a delayed/duplicated old WRITE can **never overwrite newer data**.
2. **Acceptance ≠ commitment.** `accept_next` advances when the request has been validated and handed to the data mover; `commit_next` advances only when its bytes have been acknowledged by the memory write port. The requester completes a WRITE/SEND **only** on `commit_next`. Both frontiers are carried in every ACK/NAK.
3. **No effect before authorisation.** No memory access of any kind is issued for a request until its registry check has granted (and the DMA guard confirmed) its physical window; a rejected request leaves no memory trace.
4. **No partial frames.** A frame is applied only if it was received completely and validated (§3.4).
5. **Ordering at the responder.** Accepted WRITE/SEND data is committed in PSN order (single in-order write path).
6. **Ambiguity is explicit.** If a transport failure ends a WQE with an error, the application must treat the remote effect of that WQE (and of later unfinished WQEs) as **unknown** (§11.3).

## 11. Failure and restart semantics

### 11.1 Transition to `ERR`
Causes: (a) local protection error on a WQE's local buffer (`LOC_PROT_ERR`), (b) fatal NAK received, (c) retry exhausted (`RETRY_EXC_ERR`), (d) RNR retry exhausted (`RNR_RETRY_EXC_ERR`), (e) fatal request error at the responder (it sends a fatal NAK
first, §9.4), (f) DMA guard violation or memory error response (`LOC_OP_ERR`, §9.7), (g) forced by configuration.
On entry to `ERR`: the **failing WQE** completes with its specific status (when the failure is attributable to a WQE: a, b, c, d, f); **every other WQE** that has not completed — in-flight, queued in the SQ, and every unconsumed RQ WQE, **and a partly received SEND's RQE** — completes with
`WR_FLUSH_ERR`, in queue order. Every WQE that was completed with `OK` before the transition stays `OK`. A SEND message whose **last segment had already been accepted** when the QP entered `ERR` still completes its RECV with `OK` when its bytes commit (its receive WQE was consumed and its data is real; this also keeps CQ credit accounting exact: every consumed WQE produces exactly one CQE). Issue stops immediately; no further frame carrying new requests is transmitted: **request frames that are queued in the adapter and have not started are discarded** (a frame already being transmitted is completed). **Responses to READs that were already accepted are still transmitted** (a responder's fatal NAK overtakes them on the control path, and they were committed before it). DMA operations already in flight complete (an operation is never torn) but produce no completion.
**Ordering and resources on ERR.** (1) RECV completions leave in **RQ post order**: the SENDs already accepted commit and complete first (OK, or `LOC_OP_ERR` after a memory error), then the partly received SEND's RQE and the unconsumed RQEs flush — a flush completion never overtakes an older OK. (2) A READ at the head of the responder's commit ring that can never execute (the read executor is halted) is skipped, so the SENDs behind it still commit and complete; every consumed RQE produces exactly one CQE and its CQ credit returns. (3) A flushed WQE's local grant (registry reference) is released **only after the DMA that uses it has ended**: until then `MR_INVAL` answers `ERR_BUSY`, and the CQE that hands the buffer back to the host is produced after the last write into it.
Cause (a) is ordered: the failing WQE's CQE is produced when every earlier WQE has retired.

### 11.2 NAK replay
A responder that entered `ERR` because of a fatal request error (e) **remembers the NAK** (`code`, `epsn`). To every subsequent frame that survives adapter validation and is a request, it answers with that NAK (no memory effect, no state change) until reset. The replayed NAK carries the frozen frontiers (`commit_next = accept_next` = the PSN of the failed request: no request is accepted after the fatal decision) and the original code; it is sent for in-order, duplicate and out-of-sequence request frames alike. This makes
error reporting reliable under loss. (A QP in `ERR` for any other reason sends nothing.)

### 11.3 Outcome ambiguity (normative warning)
After `RETRY_EXC_ERR`, `RNR_RETRY_EXC_ERR` or a flush, the remote memory MAY or MAY NOT contain the effect of the failed WQE and of subsequent ones: the request may have been executed whose ACK was lost. SFRT guarantees **at-most-once** application, never exactly-once knowledge.

### 11.4 Transport failure
A black-holed link ends in `RETRY_EXC_ERR` on the oldest unfinished WQE after `retry_max` retransmissions; all others flush. A link that recovers before exhaustion is invisible to the application (apart from latency and retry counters).

### 11.5 Reset and restart
* **QP reset (configuration command →`RESET`).** Equivalent to forced `ERR` (flush completions as §11.1) followed by: wait until the data-movement engines and the transmit adapter are quiescent (in-flight DMA completes; a frame already being transmitted is completed; frames queued but not started are discarded), then clear **all** QP state
  (PSNs, tables, queues, read queue, pending ACK/NAK, references on registry entries). The memory-region table, `ctx_en` and the CQ contents are preserved. The *attribute registers* (`local_qpn`, `pd`, `epoch`, MACs, timers) are NOT cleared by a QP reset (they are overwritten by the next `INIT`/`RTR`/`RTS` commands); frames that arrive in `RESET`/`INIT` are dropped and classified by the order of 3.4 against the stale attributes (so, typically, `rx_drop_state`). After a **hard** reset the attribute registers are zero. The configuration command completes (`cfg_rsp`) when this is done.
* **Hard reset (`rst_n`).** Clears everything, including the registry, the CQ and all counters. The endpoint behaves as freshly powered.
* **Restart of one peer.** The surviving peer observes silence or (after the restarted peer re-initialises with a new epoch) `rx_drop_epoch`; its outstanding WQEs end in `RETRY_EXC_ERR`; it must itself be moved through `RESET → INIT → RTR → RTS` with the **same new `epoch`** and consistent PSNs before traffic resumes.
* **Epoch.** The trusted agent MUST use a different `epoch` for every connection incarnation between the same pair. Frames of an earlier incarnation are dropped (`rx_drop_epoch`) and cannot touch memory or state.
* **Data in the link survives a reset.** That is why the epoch exists.

## 12. Flow control and credits

1. **Bounded send queue** (`SQ_DEPTH`), **bounded receive queue** (`RQ_DEPTH`): posting while full is back-pressured (`*_post_ready = 0`), never dropped.
2. **CQ credit.** Every accepted post (SQ or RQ) reserves one CQ slot; the slot is freed when the CQE is *consumed* by the host. Hence `posted-and-uncompleted + CQ occupancy ≤ CQ_DEPTH` and **a completion can never be lost or overflow the CQ**, including flush completions. When the host stops draining the CQ, posting stalls (counter `stall_cq_credit`).
3. **Outstanding limit.** `WINDOW` request PSNs and `MAX_RD` reads in flight per requester; exceeded → issue stalls (counters `stall_window`, `stall_rd_limit`).
4. **Receive buffering.** The adapter's receive buffer is finite: when it is full `rx_ready` is deasserted (no frame is accepted that cannot be stored; counter `stall_rx_buf`). Nothing accepted is ever dropped silently.
5. **Responder resources.** No RQ WQE for a first SEND segment, or a full read queue for an in-order READ, → **RNR NAK** (the request is *not* accepted; the requester retries after `rnr_delay`). A duplicate READ finding the read queue full is ignored (it will be retried).
6. **Transmit side.** A frame is reserved (header + payload space) in the transmit buffer **before** its payload is fetched, so the shared read engine never blocks on a full output buffer.
7. **Deadlock freedom (argument).** (i) Frame reception never waits for transmission: ACK/NAK generation and READ execution are decoupled from the receive processor, which waits only for local memory/commit resources. (ii) READ execution waits only for the local commit frontier and for transmit-buffer space, which drains as the peer receives, and the peer's receive processor never waits for anything on the network. Hence no cycle of waits exists between two endpoints.
   **Stated assumption (found by the independent review, S-04, not demonstrated).** The argument assumes that the transmit buffer of an endpoint drains independently of what the peer's receive processor is doing. With a link that back-pressures (`tx_ready`/`rx_ready` as specified in 12.4) and a READ at the head of each endpoint's commit ring, a circular wait through the two transmit buffers and the two receive processors may be constructed; the simulated link of the bench is an unbounded queue and cannot show it, and no bounded-link bench was built. Until one exists, deadlock freedom is argued, not verified, for back-pressured links (`docs/LIMITATIONS.md`).

## 13. Completion queue entry

| Field | Bits | |
|---|---|---|
| `wr_id` | 64 | from the WQE |
| `op` | 4 | 1 SEND, 2 WRITE, 3 READ, 4 RECV |
| `status` | 4 | below |
| `byte_len` | 32 | bytes transferred (SEND/WRITE/READ: `len`; RECV: `mlen`); 0 for error/flush CQEs |
| `qpn` | 16 | local QPN |

| Status | Code | Meaning |
|---|---|---|
| `OK` | 0 | |
| `LOC_LEN_ERR` | 1 | RECV: incoming message longer than the RQ buffer |
| `LOC_PROT_ERR` | 2 | local lkey/range/permission/PD failure |
| `WR_FLUSH_ERR` | 3 | flushed because the QP entered ERR or was reset |
| `REM_ACCESS_ERR` | 4 | peer reported REM_ACCESS (key/PD/permission/range/…; **the reason is deliberately not disclosed to the requester**; it is in the responder's fault log) |
| `REM_INV_REQ_ERR` | 5 | peer reported INV_REQ (incl. unsupported opcode) |
| `REM_OP_ERR` | 6 | peer reported REM_OP (RQE too small / RQE protection failure) |
| `RETRY_EXC_ERR` | 7 | retry counter exhausted |
| `RNR_RETRY_EXC_ERR` | 8 | RNR retry counter exhausted |
| `LOC_OP_ERR` | 9 | memory error response (§9.7) or DMA guard violation; the CQE of a RECV whose data write failed |

CQEs of the send queue are produced **in post order**; RECV CQEs in RQ post order; the two streams are not ordered relative to each other.

## 14. Configuration status codes (`cfg_rsp_status`)
`0` OK, `1` ERR_IDX, `2` ERR_BUSY, `3` ERR_EXISTS, `4` ERR_DUPKEY, `5` ERR_FIELDS, `6` ERR_RANGE, `7` ERR_NOENT, `8` ERR_STATE.

## 15. Counters (names are normative; indices are in `rtl/sf_rdma_defs.svh`)
Operations: `ops_done_send/write/read/recv`, `ops_err`, `ops_flushed`. Bytes: `bytes_send/write/read/recv` (completed OK). Latency (cycles, WQE issue → CQE): `lat_{write,read,send}_{sum,cnt,min,max}`.
Occupancy: `{sq,rq,cq,win}_occ_{max,sum}`. Reliability: `retry_timeout`, `retry_nak`, `retry_rnr`, `tx_retx_frames`, `rx_dup`, `rx_oos`, `rx_nak`, `tx_nak`, `rx_ack_stale`, `rx_resp_drop`, `epsn_accepts`, `cpsn_commits`.
Stalls: `stall_tx_link`, `stall_window`, `stall_rd_limit`, `stall_sq_full`, `stall_cq_credit`, `stall_rx_buf`. DMA: `dma_rd_bytes`, `dma_rd_busy`, `dma_wr_bytes`, `dma_wr_busy`, `guard_violation`.
Registration: `mr_fault_total`, `mr_fault_{bad_key,bad_pd,bad_dir,bad_perm,bad_len,overflow,range,page_cross,xlate}`.
Frames: `tx_frames`, `rx_frames`, and every `rx_drop_*` / `post_rej_*` counter above. Also: `rx_dup_read_fault` (a duplicate READ whose re-check failed; not counted in `mr_fault_*`'s per-class totals of the original request), `rx_nak_badcode`, `rnr_sent`, `req_accepted`, `writes_committed`, `bytes_tx_payload`, `bytes_rx_payload`.
**Scope:** `ops_done_*`, `ops_err`, `ops_flushed` and `bytes_*` count **send-queue** completions (`ops_done_recv`/`bytes_recv` count OK RECV completions; RECV error/flush completions are in no `ops_*` counter). `dma_rd_bytes`/`dma_wr_bytes` count bytes moved through the memory ports (a retransmitted payload read counts again). `lat_*` are cycles from WQE issue (first registry check) to CQE production.

## 16. Conformance and non-goals
Evidence for each clause is listed in `docs/VERIFICATION.md`. Nothing in this document is a claim of compatibility with any external standard.

---

# Appendix A — Verification contract (scenario and result files)

The testbench executes **scenario files**; an independent Python model predicts the outcome; a checker compares. Both consume the formats below.

## A.1 Scenario file (`*.scn`)
Line-oriented. `#` starts a comment. Each line: `command key=value key=value …`. Numbers: decimal or `0x…`. `ep` is `A` or `B`. Commands execute in order; time advances in `run`, `barrier`, `wait_cqe` and while a configuration or post command waits for its handshake.

| Command | Keys | Effect |
|---|---|---|
| `build` | `dw`,`mtu`,`window`,… | informational (the build parameters the scenario assumes) |
| `seed` | `v` | RNG seed for the bench's random choices |
| `mem_fill` | `ep addr len pat` | fill **PA** range with `pat(seed,i)` (A.3) |
| `mem_lat` | `ep min max stall` | memory latency (cycles, uniform in [min,max]) and `ready` stall percentage (0–100) |
| `mem_err` | `ep kind=rd\|wr n` | the `n`-th memory read **response** (`rd`, garbage data) or write **acknowledge** (`wr`, the write is not applied) from now on is an **error** (`n=0` disarms) — exercises §9.7; the reference model does not predict it (such scenarios carry a `.expect` file, below) |
| `option` | `post_wait=N post_block=ok` | a post that is not accepted within `N` cycles is abandoned with a NOTE instead of a bench error (chaos scenarios: a bounded queue legitimately stays full when the traffic was cut off) |
| `mr` | `ep idx va len pa key pd acc ctx` | `MR_SET` |
| `mr_inval` | `ep idx` | `MR_INVAL` |
| `ctx_en` | `ep mask` | `CTX_SET` |
| `qp` | `ep state` + attributes of §5.1 (`qpn pd rqpn epoch rq_psn smac dmac sq_psn timeout retry rnr_retry rnr_delay`) | `QP_MODIFY`; `state` ∈ `INIT RTR RTS ERR RESET` |
| `post_recv` | `ep wr_id addr lkey len` | RQ post |
| `post_send` | `ep wr_id op laddr lkey len raddr rkey` | SQ post; `op` = `SEND WRITE READ` or an integer (to test unsupported opcodes); optional `flags` |
| `cq_drain` | `ep on` | host drains the CQ (default on); `0` stops draining |
| `link` | `dir=AB|BA drop dup delay_min delay_max reorder stall` | random impairments, percent per frame (`drop`,`dup`); delay uniform in `[delay_min, delay_max]`; **reordering emerges from the delay spread** (`reorder` is accepted and ignored); `stall` = percentage of cycles the *transmitting* endpoint's `tx_ready` is low |
| `link_script` | `dir drop=n,n,… dup=n,… delay=n:cycles,…` | impairments by **frame ordinal** (1-based, per direction, counted from the start of the simulation, counting only frames transmitted by the endpoint into that direction) |
| `link_black` | `dir on` | drop everything in that direction while on |
| `reset` | `ep kind=hard|qp` | hard reset pulse / QP reset command |
| `inject` | `dir hex [err=1] [badkeep=1] [delay=n]` | put a raw frame (hex bytes, FCS excluded) on the link; it is **not** subject to the link impairments and is **not** counted in the `link_script` ordinals. `err=1` raises the MAC error flag on the last beat; `badkeep=1` corrupts the `keep` of the second beat (illegal pattern); `delay` = cycles until delivery |
| `run` | `cycles` | advance. (`post_send`/`post_recv` block the script until the post handshake happens: a full queue or an exhausted CQ credit stalls the script, not the engine) |
| `barrier` | `max` | run until the system is **quiet** (both endpoints and the link idle for 64 consecutive cycles: no queued WQEs, nothing outstanding, no frames in flight) or `max` cycles |
| `wait_cqe` | `ep n max` | run until `ep` has produced ≥ `n` CQEs in total, or `max` cycles |
| `dump` | `ep addr len` | record the contents of a PA range **at that point of the scenario** (the memory as it is when the command executes; later commands do not affect it) |

## A.2 Result file (`*.res`, produced by the bench)
```
CFG    ep=A cmd=MR_SET idx=0 status=0
POST   ep=A wr_id=.. which=SQ|RQ status=..
CQE    ep=A cyc=.. wr_id=.. op=.. status=.. len=.. qpn=..
MEMW   ep=A cyc=.. addr=0x.. strb=0x.. data=0x..      # every accepted memory write word, in order
MEMR   ep=A cyc=.. addr=0x..                          # every accepted memory read word
CNT    ep=A name=..  value=..                         # every counter of §15
QPST   ep=A state=.. cause=..
DUMP   ep=A addr=0x.. hex=....
END    cycles=..  timeout=0|1
```

## A.3 Deterministic pattern
`pat(seed, i)`: `x = (seed*2654435761 + i*2246822519) mod 2^32; x ^= x >> 15; x = (x * 2654435761) mod 2^32; return (x >> 24) & 0xFF`.

## A.4 What the model predicts and the checker compares
Per scenario: the sequence of CQEs of each endpoint's send queue and receive queue (op, status, len, wr_id); the contents of every `dump` range at the point where the `dump` command executes; the **per-byte write count** of each endpoint's memory (from `MEMW` strobes) — each byte of an accepted WRITE/SEND/READ-placement is written **exactly once** and no byte outside the union of
authorised windows is ever written or read; post statuses; `cfg` statuses; the registry fault counters; the QP state at the end; and bounds on reliability counters (e.g. `retry_* ≥ 1` when a scenario forces loss; `= 0` on a clean link).

## A.5 Rules for the checker that follow from the protocol (normative)
* **Read envelope.** Requests are pipelined: when a WQE fails, later WQEs of the same QP may already have passed their LOCAL check, been read from local memory and been transmitted before the NAK came back. Reading the source buffer of **any posted WQE that passed its local check** is therefore legal (reads have no side effect on the destination, which the responder never applies after a fatal NAK). The envelope of legal reads is the union of: local source buffers (SEND/WRITE) of every posted WQE whose local check passes, READ-source ranges that the peer was authorised to read (including re-executions), and receive-buffer reads that never happen. Memory reads are checked at word granularity.
* **Write envelope** is exact: each byte written equals the model's write count (0 for any byte of a rejected request, 1 for every byte of an accepted one).
* **Reliability counters are timing dependent.** Nothing about retry counts is exact: the RNR counter resets on progress (9.6), so `retry_rnr` has no upper bound (a late ACK for another WQE between two RNR NAKs grants a new round of `rnr_retry_max` retries); when RNR retries were *exhausted* it is at least `rnr_retry_max`. Everything else is a **bound**: `retry_* == 0` is only required on a clean link with no reset and no RNR; with loss, duplication, reorder, delayed ACKs, RNR or a reset `retry_timeout + retry_nak + retry_rnr >= 1` where the scenario forces it, and no upper bound is asserted beyond `retry_timeout + retry_nak <= retry_max` per progress period. A pipelined request behind an RNR'd SEND legitimately provokes a SEQ_ERR NAK and a `retry_nak`.
* **Drop counters after a hard reset.** A hard reset clears the QP attributes including the MAC registers, so frames that reach a freshly reset endpoint are classified in the order of 3.4: they count as `rx_drop_mac` until the endpoint is moved to RTR again, and as `rx_drop_state` only if the MACs match.

## A.6 Scenarios the reference model does not predict: expectation files and chaos properties (normative for the verification environment)
The reference model is **op-level**: it resolves one send-queue head at a time and cannot interleave a forced error, an injected memory error or an exact-cycle stall with frames in flight. Such scenarios are verified by other, *explicit* oracles — never by weakening the model:
* **`X.expect`** next to `X.scn` (`scripts/check_expect.py`, grammar in its header): the exact list of send/receive completions, the final QP state and error cause, counter bounds, `MR_INVAL` status, and the ordering "the CQE that hands a buffer back comes after the last write into it". A scenario with an `.expect` file is *not* given to the model. `tests/rdma/review/` holds one per defect reproduced by the independent review; each fails on the pre-fix RTL and passes on the fixed RTL.
* **Chaos scenarios** (`tests/rdma/gen/gen_chaos.py`, checked by `scripts/check_chaos.py`): valid random traffic with forced `ERR`/`RESET` at random moments. Model-independent properties: no bench monitor; both QPs end in `RESET`; every accepted post produces **exactly one** CQE; send and receive completions are in post order; no completion is `OK` after an earlier failure of the same queue.
* **Standing bench invariants**, checked at the end of every run of every scenario: CQ credit conservation (the DUT's free credits equal `CQ_DEPTH` minus the posted WQEs whose CQE was not consumed) and "after a QP reset nothing is open" (every posted WQE produced a CQE, flushed ones included).
* **Simulation-only fault injection**: `make build-fi` builds the bench with `-DSF_SIM_FAULT_INJECT`, which lets `+GUARD_WR_N=n` make the guard of the `n`-th responder write command fail (the situation the DMA guard defends against), to test the recovery path (QP reset after a guard violation). The macro is never defined for synthesis, lint or the shipped benches.
