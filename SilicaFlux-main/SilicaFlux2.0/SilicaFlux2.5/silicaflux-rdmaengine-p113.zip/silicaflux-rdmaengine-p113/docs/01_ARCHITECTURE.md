# 01 — Architecture

```
                         trusted cfg port                    host: post_send / post_recv / CQ
                               │                                       │
                       ┌───────▼────────┐   grant / fault       ┌──────▼───────┐   completions
                       │ sf_rdma_memory │◄──────────────────────┤ sf_rdma_wqe  │──────────────┐
                       │   _registry    │   (2 check ports,     │ SQ / RQ +    │              │
                       │ key,PD,range,  │    3 release ports,   │ post checks  │       ┌──────▼───────┐
                       │ perm,ctx,refs  │    DMA guard)         └──────┬───────┘       │ sf_rdma_     │
                       └───▲────▲───▲───┘                              │ heads         │ completion   │
              guard rd/wr  │    │   │ check                    ┌───────▼────────────┐  │ (CQ + credit)│
                           │    │   └──────────────────────────┤   sf_rdma_qp       │──►              │
 memory ◄─ sf_rdma_dma_rd ─┘    └──────────────────────────────┤  QP state machine  │  └──────────────┘
 ports  ─► sf_rdma_dma_wr                                      │  sf_rdma_requester │ window, PSN table, go-back-N, ordered retire
            ▲   │  payload                                     │  sf_rdma_rx        │ classify, validate, grant, DMA cmd, commit ring
            │   ▼                                              │  sf_rdma_rdgen     │ READ executor (decoupled, RAW fence)
        ┌───┴───────────────────────────────┐                  │  sf_rdma_ackgen    │ ACK / NAK (decoupled)
        │ sf_rdma_transport_adapter         │◄─────────────────┤  sf_rdma_retry     │ timeout / retry / RNR
        │ TX: 3 header ports, reserved      │  SFRT headers    └────────────────────┘
        │     payload rings, store-forward  │
        │ RX: parse, validate, commit/abort │          sf_rdma_perf: counters, latency, occupancy
        └───────┬───────────────▲───────────┘
          AXI-S │ tx            │ rx   (PacketCore stream contract, 48-byte Ethernet+SFRT prefix)
```

## Brief → files

| Brief | File |
|---|---|
| Work Queue | `sf_rdma_wqe.sv` (SQ, RQ, post validation) |
| Queue Pair Controller | `sf_rdma_qp.sv` (+ `sf_rdma_requester`, `sf_rdma_rx`, `sf_rdma_rdgen`, `sf_rdma_ackgen`) |
| Memory Registration Check | `sf_rdma_memory_registry.sv` |
| Data Movement Engine | `sf_rdma_dma_rd.sv`, `sf_rdma_dma_wr.sv` (+ vendored `sf_stream_dma_align`) |
| Transport Adapter | `sf_rdma_transport_adapter.sv` |
| retry / timeout | `sf_rdma_retry.sv` |
| completion tracking | `sf_rdma_completion.sv` (queue, credits) + the requester's in-order retire + the responder's commit ring |
| performance | `sf_rdma_perf.sv` |
| top | `sf_rdma_engine.sv` |
| support | `sf_rdma_fifo.sv`, `sf_rdma_defs.svh` |

## Datapaths

**Send path (requester).** `post_send` → SQ → *issue FSM* checks the local buffer with the registry **once per WQE** (the grant, a physical window + a reference, is kept until the WQE retires) → the WQE is cut into MTU segments, each stored as a **request-table entry** (opcode, flags, remote VA/key, local PA window, offsets) →
the *transmit pointer* walks the table: for a payload frame it atomically (i) reserves header + payload space in the adapter and (ii) enqueues a read command in the DMA read engine (guard-checked against the registry) → the read engine streams the bytes, re-aligned by the vendored gearbox, into the reserved space → when complete the frame is serialized
(Ethernet shim + 34-byte SFRT header + payload) through a vendored skid slice. A frame can always be rebuilt from its table entry, so **retransmission is the same path** (re-reading local memory).

**Receive path.** Frames arrive on the AXI-S stream; the adapter parses the 48-byte prefix, validates it, stores only the announced payload bytes and **commits the frame only when it was received completely and passed every check** (otherwise the write pointer is rolled back: no partial effect). The receive processor handles one frame at a time:
ACK/NAK → requester; READ_RESP → requester lookup, accepted data is written at *(grant PA + offset)*; request frames are classified by PSN (in-order / duplicate / out-of-sequence), validated (spec 7.4), checked by the registry, turned into exactly **one DMA command per payload frame** (WRITE or DISCARD) before the header is popped, and entered in the **commit ring**.
The write DMA acknowledges a command only after the memory acknowledged every word → the ring entry becomes *done* → `commit_next` advances → a SEND's RECV CQE is produced → the ACK covering it is built.

**Why two frontiers.** `accept_next` = validated and handed to the data mover; `commit_next` = acknowledged by the memory. Requester completions use only `commit_next`. Both travel in every ACK/NAK, so a slow memory never causes a spurious retransmission yet never produces a premature completion.

## Mechanisms worth knowing
* **One path to memory.** DMA commands carry a registry grant `(rid, pa, len)`. Before a command's first access the DMA engine asks the registry's guard (valid, reference held, physical window containment). A failing command is converted to DISCARD / dropped, `viol` is raised, the QP errors. Nothing else drives the memory ports.
* **Frame abort.** A frame is complete when its whole payload is in the transmit ring. If the payload fetch failed, the read engine flags it (`pl_err` on the last beat), the adapter keeps one poison flag per frame and **drops the frame when it would start** (nothing leaves, the requester is told which PSN); in ERR the same drop path discards queued *request* frames (responses to READs already committed still go out).
* **References.** A grant increments the region's reference count; the owner releases it on retirement/commit; every source has **its own release port** (requester context, requester flushed check, receive commit, receive abort, receive flush, read executor), and a flush releases a grant only when the DMA that uses it has ended. `MR_INVAL` is refused while the count is non-zero, so an accepted operation can never lose its region. QP reset clears every reference.
* **No silent loss.** Posts back-pressure; CQ slots are reserved at post time; the receive buffer back-pressures `rx_ready`; the responder answers RNR instead of dropping a request it cannot take. Frames the protocol *chooses* to drop (malformed, wrong epoch, stale) are counted.
* **Deadlock freedom.** The receive processor never waits for transmission: ACK/NAK generation and READ execution are decoupled units; READ execution waits only for the local commit frontier and transmit-buffer space (spec 12.7).
* **Read-after-write fence.** A READ executes only after every earlier-PSN request has committed.
* **Reset / restart.** QP reset flushes, waits for in-flight DMA and a frame in transmission, then clears everything including references; a new connection incarnation uses a new epoch so frames of the old one cannot touch anything (spec 11.5).
* **Byte granularity.** Local and remote addresses and lengths are arbitrary bytes; the gearbox realigns, strobes mask partial words.

## Mapping to hardware
The request table, WQE context ring, commit ring and queues are small register arrays (WINDOW, SQ/RQ depth); the payload rings are arrays that infer SRAM. The registry is a flop CAM (NMR entries). Yosys generic-gate counts: see `reports/synth.md` (no PDK/FPGA timing is claimed).
