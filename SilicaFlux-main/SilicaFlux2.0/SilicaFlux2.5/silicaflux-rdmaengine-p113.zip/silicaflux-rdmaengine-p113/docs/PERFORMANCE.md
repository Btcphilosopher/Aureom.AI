# PERFORMANCE — headline results (full analysis: `benchmarks/rdma/REPORT.md`)

**Units are simulation cycles and bytes per cycle.** No clock frequency, no Gbit/s, no power, no area is claimed: converting needs a timing-closed clock and this project has none. The link in these runs is ideal (zero delay) except in the loss sweep; the memory is the bench's in-order, pipelined, fixed-latency model. All 135 runs finished with zero monitor or bench failures. Raw data: `benchmarks/rdma/results.csv`; reproduce with `python3 benchmarks/rdma/bench.py && python3 benchmarks/rdma/make_report.py`.

| quantity (DW 64, MTU 256, window 8, memory latency 2) | measured |
|---|---|
| WRITE / READ / SEND throughput, large transfers | ≈ 6.0 B/cycle = **75 % of the 8 B/cycle stream peak** |
| 8-byte WRITE (per-operation cost) | 0.82 B/cycle (≈ 10 cycles per operation) |
| unloaded latency, 8 B → 4 KiB (WRITE, SEND, READ) | 58 → ≈ 825 cycles (WRITE completion includes the remote memory commit and the ACK) |
| throughput by data width (4 KiB WRITE / READ) | DW 32: 3.12 / 3.05 · DW 64: 5.98 / 5.87 · DW 128: 11.05 / 10.87 B/cycle |
| both directions at once (4 KiB WRITEs) | 11.1 B/cycle total = 1.85 × one-way |
| frame loss, 4 KiB WRITEs, mean of 5 seeds | 94 % / 89 % / 74 % / 55 % of lossless at 1 / 2 / 5 / 10 % |

## What limits it (measured, not assumed)

1. **The 75 % plateau is two limits that nearly coincide at MTU 256**: the 48-byte per-frame prefix (a 256-byte frame is 38 cycles on the wire) and the number of outstanding memory words `MEM_*_OUT` = 4 (40 cycles per 256 B at memory latency 2), plus a residual of 1–3 cycles per frame that is **not attributed to a stage**. The commit period of a frame follows `max(wire, memory-depth) + residual` within 1–3 cycles at every MTU and data width tried (`REPORT.md` §5).
2. **Memory-bound regime**: with a slow memory, throughput ≈ 8 B × `MEM_OUT` ÷ (L + 3) (fitted constant), to within 3 % where it predicts ≤ 5 B/cycle. `MEM_OUT` = 8 lifts the default case to 6.47 B/cycle; the default stays 4 because every other verification result was obtained at it.
3. **Small READs are bounded by `MAX_RD` × bytes ÷ unloaded latency**. ⚠ `MAX_RD` above the responder's read queue (`RDQ` = 4, not an engine parameter) causes RNR retries on a clean link (12 retries and about −17.5 % throughput at `MAX_RD` = 8, 256 B READs): **keep `MAX_RD` ≤ 4** (`LIMITATIONS.md`).
4. **Send window**: window × MTU must cover target rate × round trip; 2 and 4 frames are limited by the window, 8 and 16 are not. A window-full counter alone does not say the window is too small.
5. **Loss**: recovery is NAK-driven go-back-N (timeouts are 0–16 % of retries); each recovery event resends ≈ 5 frames. Single draws mislead — report the spread over seeds.

## Not measured

Absolute performance (no clock), a real link or MAC, more than one QP, translation/page-crossing workloads, a memory with variable latency or back-pressure, mixed READ/WRITE/SEND traffic beyond the bidirectional WRITE point (`REPORT.md` §8).

The loss figures were re-measured after the independent review's fixes; the lossless figures are bit-identical before and after (`REPORT.md` §6).
