# Limitations — read before relying on anything

**Evidence level: RTL simulation (Verilator, two endpoints, independent Python reference model), formal checks on RTL for small instances (Yosys + z3), Yosys generic-gate counts. No FPGA, no place-and-route, no PDK, no silicon; no clock frequency, power or area figure is claimed.**
Throughput/latency are in simulation cycles and bytes/cycle.

## Protocol
* **SFRT is not RoCEv2, InfiniBand or iWARP.** No BTH/RETH/AETH/ICRC, no UDP/IP, no interoperability with any other implementation, and none was tested. The brief's rule is followed: interoperability is a separate, later, separately verified milestone (`FUTURE_EXPANSION.md`).
* One queue pair. No atomics, immediate data, send-with-invalidate, SRQ, multicast, unreliable services. Reserved request opcodes are rejected explicitly.
* No end-to-end integrity check (no ICRC): the link's frame check is trusted (`rx_err`). A corrupting link that passes frames would corrupt data.
* No congestion control (fixed window + RNR back-off only), no PFC/ECN handling, no pacing. Go-back-N retransmission: lossy links with a large window waste bandwidth (measured in `benchmarks/rdma/REPORT.md`).
* No connection-management protocol: both endpoints are configured by the trusted port with consistent attributes (epoch, PSNs, MACs, MTU).
* Outcome ambiguity after a failure is inherent (at-most-once, not exactly-once knowledge; spec 11.3).
* A duplicate READ re-executes against **current** memory; READ data fetch is not ordered against *later-PSN* writes to overlapping memory (as in IB; use the completion).
* An error on the responder (access violation, invalid request, RQE too small) **kills the QP** (RC semantics), reported to the requester as a coarse status without the reason; the reason is in the responder's fault log.

* **Deadlock freedom on a back-pressured link is argued, not verified (review S-04).** The spec 12.7 argument assumes each transmit buffer drains independently of the peer's receive processor. With a READ at the head of each endpoint's commit ring, a full ring and full buffers, a circular wait may exist; the bench link is an unbounded queue and cannot show it, and no bounded-link bench was built. Mitigation if it matters: a separate, always-draining READ-response buffer, or a receive processor that can park a blocked head request.
* **A responder memory error is not reported to the peer.** A memory error response on the responder's READ fetch or write sends nothing (spec 9.7, 11.2): the requester learns it as `RETRY_EXC_ERR` after its retries. Only the requester's own memory errors produce `LOC_OP_ERR` on the failing WQE.
* **A lost READ response before a fatal NAK costs the fatal status.** The READ ends `RETRY_EXC_ERR` and the faulty WQE is flushed instead of completing `REM_*_ERR` (spec 9.5(6)); a fatal-mode responder never re-executes a READ.
* **Release of the failing WQE's grant is not gated on DMA idleness in the retry/NAK-exhaustion paths** (it is gated in the flush and local-memory-error paths, review F-06). A READ response placement of the *failing* WQE itself still in flight when it fails by retry exhaustion could write after the grant is released; reaching this needs data arriving for a WQE that has just exhausted its retries (review S-06/F-06 residual, not observed).
* **Retry exhaustion can fail an already-committed head WQE** whose entries are all committed but not yet retired (one retire per cycle) when the exhaustion pulse lands in that window (review S-06; spec 11.1 says the *oldest unfinished* WQE fails). Narrow, not observed.
* **A pending NAK code can be overwritten** by a later one (RNR by SEQ_ERR; review S-05). Allowed by spec A.5 (a pipelined request behind an RNR'd SEND legitimately provokes a SEQ_ERR NAK); a robustness remark, not a defect.

## Memory protection
* Translation is a **linear per-region mapping** with a mapping-context enable. No page tables, TLB, IOMMU: **PageWalker is not integrated** (integration point described in the audit). Non-contiguous regions only allow page-confined transfers.
* The registry is a flop CAM of `NMR` entries (default 8); larger tables need hashing/SRAM (future work).
* Keys are plain 32-bit values chosen by the trusted agent; there is no key-generation or tag-rotation scheme, and no defence against key guessing beyond PD + range + permission checks and fault counting.
* MemoryGuard (P104) is **not** instantiated behind the engine; the engine's own DMA guard is the second line of defence.

## Implementation
* **Throughput plateaus at ≈ 75 % of the stream peak** at MTU 256 / DW 64 (6.0 of 8 B/cycle). Measured explanation (`benchmarks/rdma/REPORT.md` §3, §5): two limits that nearly coincide at that MTU — the 48-byte per-frame prefix (frame = 38 cycles on the wire) and the number of outstanding memory words `MEM_*_OUT` = 4 (40 cycles per 256 B at memory latency 2) — plus a residual of 1–3 cycles per frame that is not attributed to a stage. With `MEM_*_OUT` = 8 the same workload reaches 6.5 B/cycle; the default was not changed because all verification evidence was obtained at 4. With a slow memory the depth, not the window, is the limit (throughput ≈ 8 B × `MEM_OUT` ÷ (L + 3)).
* **`MAX_RD` must not exceed the responder's read queue (`RDQ` = 4, a `sf_rdma_qp` parameter that the engine does not expose).** The peer's depth is not negotiated and any `MAX_RD` 1..15 elaborates. A requester with more READs outstanding than the responder can queue gets RNR NAKs on a clean link: at `MAX_RD` = 8 and 256-byte READs, 12 RNR retries and 37 retransmitted requests, throughput 4.1 against 5.0 B/cycle at `MAX_RD` = 4 (data still applied exactly once). Functionally correct, a performance cliff by configuration.
* The commit ring size equals `WINDOW`; a peer with a larger window wastes it.
* `sync_fifo` from the repository is not reused (no flush, SVA the formal flow cannot read) — a purpose-built FIFO is used.
* `MEMW`/`MEMR` traces, scenario format and the bench are specific to this project.

## Verification honesty
* The reference model and the RTL were written by different authors from the same specification; shared misreadings of the spec are possible, and every disagreement found so far was resolved by clarifying the spec (`docs/VERIFICATION.md`, section "Spec findings").
* Formal results are for **small parameter instances** and, where stated, bounded; see `formal/rdma/README.md` for what is PROVED (k-induction) versus BOUNDED. Only 6 of 130 jobs are unbounded proofs (retry, completion, WQE, ackgen, and two PSN-arithmetic checks). **Not covered formally at all:** the transport adapter, the QP/engine wiring (6 release ports), the local memory-error paths (`lerr_*`, `place_err_*`, `err_loc`) and any liveness property ("it eventually completes"). The formal run was **not one atomic run**: it was produced by the same runner in batches; every module the review fixes changed was re-run after the merge, the unchanged ones keep their earlier results (provenance in the README). In the formal mutant campaign 81 of 84 mutants were killed, 1 survived (`RQ7`, equivalent on the 2-entry window of that instance) and 2 are UNKNOWN (`RQ3`, `RG7`: solver effort / needs more cycles than the budget).
* The PacketCore integration is a simulation of PacketCore's reset configuration (default forward to queue 0); no MAC/PHY is involved.
