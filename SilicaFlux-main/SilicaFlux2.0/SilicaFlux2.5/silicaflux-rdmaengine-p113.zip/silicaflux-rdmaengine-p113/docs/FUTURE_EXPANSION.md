# FUTURE EXPANSION — research notes and milestone gates

Status of this document: **research and planning, not implemented, not verified.** Facts are marked *(confirmed)* where a source was read for this document, *(from memory — verify)* where they are the author's recollection and must be checked against the governing document before any work starts.
The brief's rule stands: **protocol interoperability is a separately verified milestone and is NOT claimed by this project.** Remote-memory semantics (this project's definition of done) come first; none of the items below may be described as done until its own gate passes.

## 0. Why order matters

SFRT v1 fixes the *semantics* that every later transport must preserve: protected regions with key+PD+range+direction checks, commit-versus-accept, at-most-once application by PSN, explicit failure/restart rules, bounded queues with credits.
Changing the wire protocol changes headers, opcodes and some error behaviour, but not those invariants — so the existing reference model, the "write exactly once per byte" and "completion only after commit" checkers, the registry harness and the mutation suite remain the regression net for every step below.

## 1. RoCEv2 transport integration (a new transport adapter, not a rewrite)

**What RoCEv2 is.** It carries InfiniBand transport headers over UDP/IP: *Ethernet + IP + UDP (destination port 4791) + IB (BTH + extension headers + payload) + ICRC* *(confirmed, e.g. a DPDK flow-item description of RoCE: "ETH + IP + UDP(dport 4791) + IB(BTH + ExtHDR + PAYLOAD + CRC)"; the governing text is IBTA Architecture Specification Annex A17, "RoCEv2", cited by the Wikipedia RoCE article).*
**Access caveat *(confirmed)*:** the IBTA volume is not freely downloadable; vendor forum threads report difficulty obtaining the current text. **Obtaining the licensed specification is step zero**; nothing below may be implemented from memory.

Work items (each needs the spec text; sizes and bit positions are deliberately not restated here):
1. Wire formats: BTH, RETH (WRITE/READ), AETH (ACK/NAK/credits), ATOMICETH (out of scope for v1), ICRC computation (incl. the masked-field rules), UDP source-port entropy for ECMP, IPv4/IPv6 and ToS/DSCP/ECN handling. *(from memory — verify: BTH is 12 bytes, ICRC 4 bytes.)*
2. Opcode mapping: SFRT `SEND/WRITE/READ_REQ/READ_RESP` → the RC opcode families (first/middle/last/only), with the 24-bit PSN as the sequence number (SFRT already uses 24-bit modular PSNs).
3. Semantic gaps to close, each a **behavioural difference** to be specified and tested, not glossed over: IB's ACK coalescing and AETH syndrome/credit encoding; NAK codes and their exact requester reactions; RNR timers encoding; read-response PSN consumption (SFRT gives a READ one PSN; IB numbers response packets); retry-count and timer semantics; the "responder QP goes to error" rules; out-of-order delivery handling; memory-key (L_Key/R_Key) format (index + tag) vs SFRT's flat 32-bit key; protection-domain and access-flag semantics; zero-length operations.
4. Where it plugs in: a new `sf_rdma_transport_adapter_roce` with the same header-port/payload-port contract; the registry, DMA engines, completion unit, and most of the QP logic stay. SFRT's epoch field disappears (IB uses QP re-creation and PSN/QPN discipline) — the stale-frame protection must be re-argued.
5. Fixed-function pieces that did not exist before: ICRC generator/checker (parallel CRC32 at line rate), IP/UDP header build/parse, ARP/ND or static neighbour table, checksums as required by the IP stack.

**Milestone gate (separate from this project's definition of done):**
* conformance vectors derived from the licensed spec (header encode/decode, opcode state machines), reviewed by someone who did not write the RTL;
* interoperability tests against an independent implementation. Soft-RoCE (`rxe`, in Linux) is the usual open target for a first interop check *(from memory — verify current status)*, then a commercial RNIC;
* **only then** may any document use the word RoCE for this engine.

## 2. Real Ethernet MAC integration

* **Interface.** PacketCore already defines the AXI-S contract and a `sf_pkt_mac_adapter` for "the common AXI-Stream MAC interface" (RX without `tready`, `tuser[0]` = bad frame, FCS stripped; TX with `tready`, MAC pads and appends FCS). The RDMA adapter speaks the same stream, so the plan is *engine → (PacketCore or directly) → `sf_pkt_mac_adapter` → MAC*. PacketCore's MAC-adapter was itself verified only against a behavioural MAC model written for that project, not a real MAC — the same caveat applies here.
* **Open MAC/PHY options *(confirmed)*:** the open-source FPGA NIC Corundum uses the `verilog-ethernet` 10G/25G MAC and PHY modules; for 100G on Xilinx UltraScale+ it uses the vendor CMAC core (RS-FEC) under the free CMAC licence. Corundum's simulations use cocotb with Icarus/Verilator. These are candidates for a loopback/bring-up design; none has been evaluated here.
* **Work:** clock-domain and width conversion to the MAC (the engine is single-clock, DW 32/64/128; real 25/100G MACs are wider/faster); minimum-frame padding is already done (60 B); pause/PFC frames and flow-control signalling; error/FCS reporting through `rx_err`; timestamp (PTP) path if latency measurements on hardware are wanted.
* **Gate:** loopback on hardware with a real MAC at line rate for each frame size; frame-error injection; back-to-back minimum frames; the same scenario suite replayed on hardware through a host-side controller (the scenario file format is already device-neutral).

## 3. Congestion management

SFRT v1 has only a fixed window and RNR back-off. For a lossless Ethernet fabric the reference deployment pattern is PFC + ECN with a rate-based sender controller; the widely cited scheme for RoCEv2 is **DCQCN** *(confirmed: Zhu et al., "Congestion Control for Large-Scale RDMA Deployments", SIGCOMM 2015; it needs only standard ECN/RED in switches, runs on the NIC, and addresses PFC head-of-line blocking and unfairness)*.
Plan:
1. Receive-side: ECN marking visibility in the adapter, and a congestion notification frame generator (decoupled from reception like `ackgen`, so it cannot create the deadlock the spec rules out).
2. Send-side: a per-QP rate limiter in the transmit arbiter (PacketCore already contains token-bucket rate limiting in its scheduler — a reuse candidate), plus the rate-increase/decrease state machine.
3. Interaction with go-back-N: a tighter window or pacing reduces the retransmission waste measured in `benchmarks/rdma/REPORT.md`; selective repeat is a separate option to evaluate (more state per PSN).
4. Verification: not by unit test alone — a closed-loop fabric model (two or more endpoints through a bottlenecked queue with ECN marking) with fairness and queue-length assertions; throughput/latency curves versus the published behaviour.
**Gate:** stability (no oscillation or livelock) under incast, fairness between flows, no starvation of ACK/NAK frames, and unchanged remote-memory semantics (the scenario suite must still pass with congestion control enabled and a lossless fabric model).

## 4. Multi-queue operation

What assumes one QP today (the migration list):
* single `epsn/cpsn`, single commit ring and request table inside `sf_rdma_requester` / `sf_rdma_rx` — per-QP state must move into addressable storage (register file or SRAM) indexed by QPN, with the engine processing one QP's event per cycle;
* the adapter's QPN check (`cfg_local_qpn`) becomes a QP-table lookup (also yielding epoch, peer MAC, PD);
* registry check ports carry the QP's PD (already an input of the check, so isolation between QPs of different PDs is structurally supported);
* completion queue: per-QP or shared CQ with the existing credit scheme extended to per-CQ reservation;
* QP scheduler: arbitration among QPs with work (round-robin/weighted), per-QP window and credit accounting, fairness on the TX path;
* per-QP error isolation: an error must flush only that QP (today's drain/reset sequencing is per engine);
* timers: one timer per QP is expensive — a timer wheel or ordered timeout list;
* registry reference ownership is already per grant and keeps working.
**Gate:** the existing scenarios replayed per QP in parallel with cross-QP isolation checks (a faulting QP must not disturb another's memory, counters or completions), plus new scenarios for QP-table exhaustion and concurrent reset of one QP.

## 5. Larger registered-memory tables

The registry is a flop CAM with `NMR` = 8 entries; area and timing grow linearly with entries.
Options: (a) a hash/set-associative table in SRAM with the key as the index+tag (as IB's L_Key/R_Key index+tag construction suggests *(from memory — verify)*), with a small on-chip cache of hot entries; (b) hierarchical translation: region table → per-region page table walked by **PageWalker (P108)** — its translation request/response contract and the `PAGE_CROSS` rule in spec 8.3 are the intended seam; (c) MemoryGuard (P104) behind the engine as a platform-level region filter.
Needed: key lifecycle (generation counters to make stale keys fail), atomic update vs in-flight use (the existing reference-count discipline generalises), registration-latency limits, and reference-count storage per entry.
**Gate:** the registry formal harness re-run for the new structure (same independent shadow model), table-full and eviction scenarios, stale-key-after-reuse scenarios, and a measured lookup-latency report.

## 6. Physical FPGA networking

Prerequisites, in order: (1) an actual MAC (§2); (2) a timing-closed clock — **none of this project's results carry a frequency**, so the first FPGA run decides it: Yosys generic gates in `reports/synth.md` are only a size indication; the PacketCore project reports (for its own, different design) that a reduced configuration did not meet a 50 MHz target on an ECP5 in place-and-route — treat timing as unproven here too; (3) a host path: configuration port and CQ/doorbell exposed over PCIe (PCIeBridge P110) or a soft CPU; (4) a board with at least two ports, or one board in loopback plus a second endpoint (another FPGA or a commodity NIC speaking the same wire format, which is only possible for RoCEv2 after §1).
Bring-up plan: simulation-to-hardware replay of the scenario files; loopback with injected faults via a link-impairment shim; BER/loss tests; thermal/long-soak with the counters of `sf_rdma_perf` exported; compare measured throughput with `benchmarks/rdma/REPORT.md` shapes (bytes/cycle × measured clock).
**Gate:** hardware passes the same scenario suite and the random suites; a timing report from the vendor flow; a measured, not estimated, line-rate figure.

## 7. Suggested order and effort

| # | Item | Depends on | Risk |
|---|---|---|---|
| 1 | Real MAC loopback on an FPGA (SFRT as is) | MAC IP, board | clocking, CDC |
| 2 | Congestion control (rate limiter + ECN reaction) | 1 | stability |
| 3 | Multi-queue | — | state storage, timers, fairness |
| 4 | Bigger registry / PageWalker translation | 3 (per-QP PD) | translation latency |
| 5 | RoCEv2 adapter + licensed-spec conformance + interop | licensed spec | semantic gaps (§1.3) |

## Sources
* RoCEv2 framing, UDP port 4791, Annex A17 reference, spec access: [DPDK flow-item patch](https://patches.dpdk.org/comment/160335/), [RDMA over Converged Ethernet (Wikipedia)](https://wikipedia.com/wiki/RDMA_over_Converged_Ethernet), [NVIDIA WinOF — RoCE v2 UDP port](https://networking-docs.nvidia.com/winofdocumentation/55053000/roce-v2-udp-port), [Intel community thread on obtaining the specification](https://community.intel.com/t5/Ethernet-Products/RoCEv2-Specification/m-p/1733266).
* DCQCN: [Congestion Control for Large-Scale RDMA Deployments (Microsoft Research)](https://www.microsoft.com/en-us/research/publication/congestion-control-for-large-scale-rdma-deployments/) (verify the DOI against the ACM Digital Library before citing; the indexed records disagree).
* Open FPGA NIC / MAC: [Corundum](https://github.com/corundum/corundum) and its paper [(UCSD)](https://leed.sysnet.ucsd.edu/papers/CorundumPaper.pdf); the `verilog-ethernet` MACs it uses for 10G/25G. The search did not surface Corundum RDMA support; none is assumed.
