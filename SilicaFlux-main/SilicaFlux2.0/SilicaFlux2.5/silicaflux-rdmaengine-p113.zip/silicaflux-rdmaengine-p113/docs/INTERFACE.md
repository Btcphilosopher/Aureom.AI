# INTERFACE — `sf_rdma_engine`

All signals are synchronous to `clk` (single clock domain); reset `rst_n` is asynchronous-assert, active low (SilicaFlux convention). Parameters at the end.
Message semantics are in `TRANSPORT_SPEC.md`; this file is the pin-level contract.

## 1. Trusted configuration port (`cfg_*`) — the ONLY way to program regions and QP state

One command at a time: `cfg_valid && cfg_ready` is the handshake, `cfg_ready` falls while a command executes; the answer is a one-cycle pulse `cfg_rsp_valid` with `cfg_rsp_status`.

| `cfg_cmd` | Name | Fields used | Notes |
|---|---|---|---|
| 0 | NOP | — | status OK |
| 1 | `MR_SET` | `idx va len pa key pd acc ctx` | install a region (spec 8.2; `acc`: bit0 LR, bit1 LW, bit2 RR, bit3 RW, bit4 CONTIG) |
| 2 | `MR_INVAL` | `idx` | refused with BUSY while an accepted operation holds the region |
| 3 | `QP_MODIFY` | `qp_state` + attributes (`qpn pd rqpn epoch rq_psn lmac pmac sq_psn timeout retry rnr_retry rnr_delay`) | spec 5.1; `qp_state`: 0 RESET, 1 INIT, 2 RTR, 3 RTS, 4 ERR. A RESET answers only when the drain has finished |
| 4 | `CTX_SET` | `ctx_mask` | enable / disable mapping contexts |
| other | — | — | status `ERR_FIELDS` |

Status codes: spec 14. `cfg_pd` doubles as the QP's protection domain for `→INIT`. Outputs `qp_state[2:0]` (0 RESET, 1 INIT, 2 RTR, 3 RTS, 4 ERR, 5 DRAIN = reset in progress) and `qp_err_cause[3:0]`
(1 local protection, 2 fatal NAK received, 3 retry exhausted, 4 RNR exhausted, 5 responder fatal, 6 internal (DMA guard / memory error), 7 forced by configuration).

## 2. Work queues
**SQ post** `sq_post_valid/ready` + `op[3:0] wr_id[63:0] laddr[63:0] lkey[31:0] len[31:0] raddr[63:0] rkey[31:0] flags[3:0]`. `sq_post_ready` is low while the SQ is full or no CQ credit is free (back-pressure; never a drop).
One cycle after the handshake `sq_post_rsp_valid` pulses with `sq_post_rsp_status` (0 OK, 1 unsupported opcode, 2 QP state, 3 length, 4 reserved flags, 5 64-bit wrap). A rejected post occupies nothing.
**RQ post** `rq_post_valid/ready` + `wr_id addr lkey len`, response `rq_post_rsp_valid/status` likewise.
Host buffers named by a posted WQE must not change until its CQE (retransmission re-reads them).

## 3. Completion queue
`cq_valid/cq_ready` + `cq_wr_id[63:0] cq_op[3:0] (1 SEND 2 WRITE 3 READ 4 RECV) cq_status[3:0] cq_len[31:0] cq_qpn[15:0]` (status codes: spec 13). Each accepted post reserves one slot, returned when the CQE is consumed:
the CQ cannot overflow; a host that stops reading only stalls its own posts.

## 4. Local memory ports (word ports, **in-order** responses, byte-granular strobes on writes)
Read: `mrd_valid/ready`, `mrd_addr` (word aligned PA), `mrd_ctx` (mapping context of the granted region); response `mrd_rsp_valid`, `mrd_rsp_data[DW]`, `mrd_rsp_err` — **one response per accepted request, in request order, never back-pressured** (the engine never has more than `MEM_RD_OUT` outstanding).
Write: `mwr_valid/ready`, `mwr_addr` (word aligned), `mwr_data[DW]`, `mwr_strb[DW/8]`, `mwr_ctx`; acknowledgement `mwr_ack_valid`, `mwr_ack_err` — one per accepted write, in order, at most `MEM_WR_OUT` outstanding.
**Error responses (`mrd_rsp_err`, `mwr_ack_err`)** are never turned into data: a failed read of a request payload aborts that frame (it is never transmitted) and fails the owning WQE `LOC_OP_ERR`; a failed read for a READ response sends nothing; a failed write is not acknowledged and its RECV completes `LOC_OP_ERR`; the QP enters `ERR` with cause 6 in every case (spec 9.7). The bench can inject them (`mem_err`, spec A.1).
**A write counts as COMMITTED when its `mwr_ack` arrives** — that is the event all completion and acknowledgement semantics hang on. Every address on these ports is a physical address produced by a registry grant; nothing else can reach them.

## 5. Transport stream (the PacketCore AXI-S contract)
`tx_valid/ready/data/keep/last` and `rx_valid/ready/data/keep/last/err`. Byte 0 of a frame is `data[7:0]` of beat 0; `keep` is all-ones except on the last beat, where it is a contiguous low mask; FCS excluded; `rx_err` is sampled on the last beat and the frame is dropped.
A transmitted frame is **contiguous** (no `tx_valid` gap inside a frame). Frame format and validation: spec 3.

## 6. Performance / diagnostics
`perf_idx[7:0] → perf_data[63:0]` (combinational read of any counter, names and indices in `docs/PERF_COUNTERS.md`); `perf_clear` zeroes the counters of the perf block (not the registry's fault counters).
`fl_*` — the registry's last-fault record (`fault class, key, va, len, op`); `ref_ovf` — sticky diagnostic that the reference-count discipline was violated (must stay 0).

## 7. Parameters
| Parameter | Default | Meaning / legal values |
|---|---|---|
| `DW` | 64 | stream and memory data width: 32, 64, 128 (verified); the 48-byte frame prefix must be a multiple of `DW/8` |
| `PA_W` | 32 | physical address width (≥ 32) |
| `MTU` | 256 | payload bytes per frame: power of two, ≥ `DW/8`, ≤ 4096; **must be equal on both endpoints** |
| `NMR` | 8 | memory regions |
| `PD_W`, `CTX_W` | 4, 2 | protection-domain id width, mapping-context id width |
| `SQ_DEPTH`, `RQ_DEPTH`, `CQ_DEPTH` | 8, 8, 32 | powers of two; `CQ_DEPTH ≥ SQ_DEPTH + RQ_DEPTH` lets every posted WQE be outstanding at once |
| `WINDOW` | 8 | outstanding request PSNs (power of two). The responder's commit ring has the same size; a requester window larger than the peer's ring is safe (the receive processor simply waits for a commit to free a slot) but wastes the extra window, so use equal values |
| `MAX_RD` | 2 | outstanding READ requests (1..15). **Keep ≤ the responder's read-request queue (`RDQ` = 4, fixed in this version): above it the responder answers with RNR NAKs and throughput drops, `LIMITATIONS.md`** |
| `MEM_RD_OUT`, `MEM_WR_OUT` | 4, 4 | outstanding memory words (powers of two) |
| `PAGE_BYTES` | 4096 | page size for the non-contiguous-region check |
| `MAX_MSG_BYTES` | 1 MiB | largest message |
| `ACCEPT_ACK_DELAY` | 64 | cycles before an acceptance-only ACK is sent |
