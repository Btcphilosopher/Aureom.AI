# Adversarial review findings (SilicaFlux P113 RDMAEngine)

Reviewer did not write the RTL. Nothing under `rtl/`, `third_party/` or the existing tests was modified. All reproductions are under
`tests/rdma/review/` (`README.md` there lists the helper scripts and patches); white-box instrumentation and fault injection were done on **copies** of the RTL / bench
(patches kept in `tests/rdma/review/*.patch`).

Evidence base: Verilator 5.020 bench, the independent Python checker, and (new) an instrumented RTL copy (`@@INV` invariants, `@@EVT` race detectors, final CQ-credit report) run on
~1 600 random scenarios (`gen_random.py`, seeds 9001/7000, 12 build configurations: DW 32/64/128, MTU 64..1024, WINDOW 2/4/8/16, MAX_RD 1/2/4, MEM_RD_OUT/MEM_WR_OUT 2/16,
PA_W 40, SQ/RQ/CQ depth 2/2/4), the 139 directed scenarios on the same variants, and 400 "chaos" variants (random forced ERR / QP RESET at random cycles with a model-independent
conservation check: every accepted post must produce exactly one CQE, RQ/SQ CQEs in post order).

* No invariant violation was seen for: `txp >= una`, `txp <= nxt`, window / rd_out bounds, FIFO overflow/underflow, registry ref wrap, CQ overflow, DMA guard, final CQ credit.
* CONFIRMED defects are listed first (each has a failing run or a cycle-exact trace); SUSPECTED ones are reasoning only (S-xx).

## Summary

| id | sev | status | one line |
|---|---|---|---|
| F-01 | HIGH | CONFIRMED | fatal NAK disarms retransmission: READ whose response is lost never completes, QP stuck in RTS for ever |
| F-02 | MEDIUM | CONFIRMED | ERR flush emits RECV CQEs out of RQ post order (flush CQEs overtake a pending OK RECV) |
| F-03 | MEDIUM | CONFIRMED | `sf_rdma_retry` swallows SEQ_ERR-NAK / RNR-NAK events when `progress` is high in the same cycle (class 1); typical NAK takes the 3000-cycle timer path |
| F-04 | CRITICAL | CONFIRMED | memory read/write **error responses are ignored**: garbage transmitted/committed, WQE completes OK; `LOC_OP_ERR` is never produced |
| F-05 | HIGH | CONFIRMED | RECV completion + CQ credit lost: SEND committed behind an unfinished READ is never completed when the QP errors / is reset |
| F-06 | HIGH | CONFIRMED | ERR flush releases registry references while DMA writes are still in flight: MR_INVAL succeeds, buffers are written after the CQE / after invalidation |
| F-07 | MEDIUM | CONFIRMED | requester retire fix-up overwrites `chi`/`ahi` update from an ACK in the same cycle (class 1): ACK lost, WQEs complete only after timeouts |
| F-08 | MEDIUM | CONFIRMED | after ERR the adapter still transmits already-queued request frames (spec 11.1: "no further frame carrying new requests") |
| F-09 | MEDIUM | CONFIRMED (fault injection) | after a DMA-guard violation the QP RESET never completes (stale write tag) -> cfg port dead until `rst_n` |
| F-10 | LOW | CONFIRMED | adapter counts `paylen > MTU` as `rx_drop_len` before ethertype/MAC/opcode (spec 3.4 order) |
| S-01 | MEDIUM | SUSPECTED | same-cycle rewind (`ev_nk`/`ev_rn`/`ev_to`) + retire still leaves `txp < una` (class 3 sibling) |
| S-02 | LOW | SUSPECTED | single release port shared by several sources in rx and requester: simultaneous releases drop one -> refcount leak until reset (class 2) |
| S-03 | LOW | SUSPECTED | `fail_pend` + empty WQE-context ring leaves `halt` set for ever |
| S-04 | MEDIUM | SUSPECTED (design) | spec 12.7 deadlock-freedom argument is false in general: commit ring head-of-line READ couples RX to peer RX via TX buffer |
| S-05 | LOW | SUSPECTED | ackgen merges pending NAK codes (RNR can be overwritten by SEQ_ERR) |
| S-06 | LOW | SUSPECTED | retry exhaustion fails the head WQE even if it is already fully committed but not yet retired |

Counts (confirmed): CRITICAL 1, HIGH 3, MEDIUM 5, LOW 1 = 10.  Suspected: MEDIUM 2 (S-01, S-04), LOW 4 (S-02, S-03, S-05, S-06) = 6.

---------------------------------------------------------------------------------------------------------------------------------------------------

## CONFIRMED BY A FAILING RUN

### F-01 HIGH -- fatal NAK disarms the retransmission machinery; an earlier READ with lost response hangs the QP
* **Where:** `sf_rdma_requester.sv:193` (`armed = en && !err_pending && ...`), `:250` (`tx_en = en && !err_pending && ...`), `:488` (`nak_fatal` sets `err_pending`, `halt`); `:320` (`fail_nak` needs `una == err_psn`);
  `sf_rdma_rx.sv:299-300` (responder in fatal mode answers *every* request, also duplicates, with the replayed NAK -- a retransmitted READ_REQ is never re-executed).
* **What is wrong:** after a fatal NAK (`err_pending`) the requester neither transmits nor runs the timer. Retirement is in order, so everything before `err_psn` must still complete. WRITE/SEND
  entries are covered by the NAK's `cn == an`, but an earlier **READ** needs its READ_RESP data. If a response frame is lost (or the NAK carries `cn < an`) the READ never completes, `una == err_psn` is never reached,
  `fail_nak` never fires: no CQE for the READ, none for the faulty WQE, QP stays RTS (`QPST state=3`) for ever. SPEC_QUESTIONS #12 lists the READ-before-fatal-NAK case as "not stated" and the generators avoid it with a barrier -- that is exactly the hole.
  Even the most lenient reading (the READ may fail) is violated: nothing is ever completed.
* **Repro (fails):** `tests/rdma/review/rv01_read_then_fatal_resp_lost.scn` (all three READ_RESP frames dropped), `rv01b_...last_resp_lost.scn` (only the last), control `rv01c_...control.scn` passes.
  Trace: B ends in ERR (cause 5, NAK sent), A: `NOTE barrier timed out`, no CQE at all, `QPST ep=A state=3`.
  `python3 scripts/regress.py --dir tests/rdma/review --only rv01 --tag _rev --report /tmp/x.md`
* **Fix:** keep the retransmission timer armed while `err_pending && una != err_psn`; since a fatal-mode responder cannot re-execute a duplicate READ, on the first expiry fail the oldest incomplete WQE with `RETRY_EXC_ERR`
  (existing `fail_pend` path) and proceed to ERR; do not retransmit entries >= `err_psn`.
* **Confidence:** very high (deterministic hang, reproduced, root cause read from the code).

### F-02 MEDIUM -- RECV CQEs of an ERR flush are not in RQ post order
* **Where:** `sf_rdma_rx.sv:437-446` (`flush_cur` / `flush_rq` have priority over `ring_cqe`; `ring_cqe` is blocked while either flush is active, `:440`).
* **What is wrong:** a SEND whose last segment was accepted but whose bytes are not yet committed (slow memory) has its RECV-OK CQE delayed until the write acks; when the QP goes ERR in between, the later RQEs
  (and the RQE of a partially received message) are flushed *first*. Spec 13: "RECV CQEs in RQ post order"; spec 11.1 says the accepted SEND still completes OK.
* **Repro (fails):** `rv02_recv_cqe_order_forced_err.scn`: B CQEs = `[102 FLUSH, 103 FLUSH, 101 OK]`, expected `[101 OK, 102 FLUSH, 103 FLUSH]` (checker: "CQE ep=B RQ #1/#3 mismatch"). (A's side of the checker output differs only because the model does not know the injected timing.)
  Also found by the chaos campaign: 3/400 runs with `RQ CQEs not in post order: [1002, 1001]` etc.
* **Fix:** produce older ring CQEs before any flush CQE: gate `flush_cur`/`flush_rq` until every ring entry with `c_slast` has been completed (or is known never to complete, see F-05); i.e. priority `fsm_cqe > ring_cqe > flush_cur > flush_rq`, flush waits for `cpsn == epsn`.
* **Confidence:** high.

### F-03 MEDIUM -- retry unit drops NAK-triggered retransmission / RNR back-off when `progress` coincides (class 1 sibling)
* **Where:** `sf_rdma_retry.sv:55-57` (`else if (progress)` branch has priority and ignores `nak_retry` / `rnr_nak` / `expire`), requester `:383` (`progress` includes `retire_go`), `:406` (`nak_retry_p <= nak_seq`, one cycle delayed).
* **What is wrong:** a SEQ_ERR/RNR NAK normally also advances the commit frontier (`cn > una`); the retire that follows is `progress` exactly in the cycle the registered `nak_retry_p`/`rnr_nak_p` arrives, so the event is silently discarded.
  Result: no go-back-N (spec 9.5(4)) and no RNR back-off (9.5(5)); recovery only by the timer (`timeout << k`, 3000 cycles in the suite) with `retry_timeout` instead of `retry_nak`/`retry_rnr`. It also burns the retry budget faster than the spec intends.
  The suite does not notice because spec A.5 only bounds the reliability counters.
* **Evidence:** instrumented RTL reports `nak_retry_dropped_by_progress` 3x in the directed suite (t103) and 212x in 400 random scenarios; `rnr_nak_dropped_by_progress` in t115.
  Directed: `rv03_seq_nak_dropped_by_progress.scn`: WRITEs 2..4 complete at cycle ~3273 (instead of ~200), `retry_timeout=1 retry_nak=0`, instrumentation `nak_retry_dropped_by_progress cyc=189`.
  `rv04_rnr_nak_dropped_by_progress.scn`: RQE posted at ~1000, SEND completes at 3318 (expected ~1300), `retry_timeout=1`, `rnr_nak_dropped_by_progress cyc=234`. (Both pass the checker; look at the CQE cycles / CNT lines of the `.res`.)
* **Fix:** evaluate `nak_retry`/`rnr_nak` before (or independently of) the `progress` branch; progress resets `tcnt`/counters *after* the NAK has been counted (or have the requester hold `nak_retry_p`/`rnr_nak_p` until the retry unit consumed them).
* **Confidence:** very high (events observed, effect measured).

### F-04 CRITICAL -- memory error responses are ignored (silent data corruption, `LOC_OP_ERR` never produced)
* **Where:** `sf_rdma_engine.sv:289,300` (`rd_done_err` declared, driven by `sf_rdma_dma_rd.sv:210`, connected to nothing; `sf_rdma_qp.sv:99-101` has no such port); `sf_rdma_rx.sv:496` (a failed write still sets `c_done`) and `:508` (a write error only raises QP ERR);
  `SFR_CQ_LOC_OP` (9) is never used anywhere in `rtl/`. Spec 11.1(f)/13: memory error response -> failing WQE completes `LOC_OP_ERR`, QP -> ERR (INT_ERR). The bench never drives `mrd_rsp_err`/`mwr_ack_err` (always 0), so nothing tests this.
* **What is wrong:** (a) an error response on a local source read (SEND/WRITE payload) or on the responder's READ fetch is dropped: the garbage word is transmitted, the peer commits it and the WQE completes OK, QP stays RTS.
  (b) a write acknowledged with error: the entry is still committed, a SEND still produces `RECV status=OK len=mlen` for a buffer that was not fully written (the QP then enters ERR cause 6, so the peer may or may not get the ACK).
* **Repro (needs the patched bench, `tests/rdma/review/run_memerr.sh`; env var injects the error):**
  `rv07` (`SF_RD_ERR=A:3`): A's WRITE completes `status=0`, QP RTS, B's memory contains 8 bytes of the 0xEE garbage. `rv08` (`SF_RD_ERR=B:3`): READ completes OK with garbage at A.
  `rv09` (`SF_WR_ERR=B:3`): B `CQE RECV status=0 len=256` while B is in ERR (cause 6) and the 3rd word was never written.
* **Fix:** wire `done_err` of both DMA engines into the QP error logic; on a requester source-read error complete the owning WQE `LOC_OP_ERR`, abort the frame (never transmit it) and enter ERR; on a responder READ-fetch error the same plus no READ_RESP; on a write error produce RECV `LOC_OP_ERR` / do not ACK past it. Add error injection to the bench.
* **Confidence:** high (observed with injection; the spec behaviour is explicit).

### F-05 HIGH -- RECV completion and CQ credit lost: a SEND behind an unfinished READ never completes when the QP errors/resets
* **Where:** `sf_rdma_rx.sv:439-450` (in-order commit), `sf_rdma_rdgen.sv:95,127,143` (`halt` stops a READ that is not fully issued, it can then never raise `done`), `sf_rdma_qp.sv:216` + `sf_rdma_rx.sv:469,475-477` (`quiet` ignores the ring; `clear` discards it).
* **What is wrong:** commit is strictly in PSN order. If a READ (incomplete: its transmit buffer is full, link stalled) is at the ring head and a later SEND is accepted and fully written, its RECV CQE is held behind the READ.
  When the QP enters ERR the READ executor halts, the READ entry never completes, the SEND's CQE is never produced, and the RESET clears the ring: the consumed RQE has **no CQE** and its CQ credit is gone for ever
  (the credit invariant of spec 12.2 / 11.1 "every consumed WQE produces exactly one CQE" breaks; repeated errors exhaust the CQ credit -> posts stall for ever).
* **Repro (fails):** `rv05_recv_cqe_lost_behind_stuck_read.scn`: B: `epsn_accepts=2 cpsn_commits=0`, SEND data written (MEMW at cycle 146) but `RQ #1 missing CQE wr_id=101`, final credits 31, `ref_clear_nonzero idx=0 ref=3`.
* **Fix:** on ERR/DRAIN mark every ring entry whose executor will never run (READ not started, replay) as done and release its reference so the ring drains and the pending RECV CQEs are produced; make `drain_ok` wait for `cpsn == epsn` (or for all `c_slast` entries to have produced their CQE).
* **Confidence:** high.

### F-06 HIGH -- ERR flush releases registry references while DMA writes into the buffer are still in flight
* **Where:** `sf_rdma_requester.sv:358-361,372` (`flush_ctx_go -> ctx_pop -> rel_valid` of the WQE's local grant, no wait for the READ-placement DMA already queued), `sf_rdma_rx.sv:455-456` (`rel_f = flush_cur_go && cur_has` releases the RQE grant of a partial SEND although accepted segments are still queued in `dma_wr`).
  The DMA guard (`sf_rdma_dma_wr.sv:73`) is evaluated once at command accept.
* **What is wrong:** the flush CQE hands the buffer back to the host and the region becomes invalidatable (`refcnt = 0`) while the write DMA still has to write the (accepted) READ response / SEND data. Spec 8.4: "MR_INVAL can never pull a region out from under an in-flight DMA".
  (Spec 11.1 allows in-flight DMA to *complete*; it does not allow the reference to be dropped meanwhile.)
* **Repro (fails the model comparison; the real evidence is in the DUMPs):** `rv06_inval_ok_while_read_placement_in_flight.scn` (requester READ placement) and `rv14_inval_ok_while_partial_send_dma_in_flight.scn` (responder partial SEND): READ/RECV completes `WR_FLUSH_ERR` at cycle 2593 / 394,
  `MR_INVAL status=0` (should be BUSY), dump taken right after it vs. dump 60 000 cycles later differ in 381 / 506 bytes: the DMA kept writing into the invalidated region until cycle ~9300.
* **Fix:** release the grants of flushed WQEs / the partial message only when the DMA engines are idle for them (e.g. do the release in the drain step, or count outstanding commands per rid), or delay the flush CQE until `dw_idle`.
* **Confidence:** high.

### F-07 MEDIUM -- retire fix-up overwrites the ACK's `chi`/`ahi` update in the same cycle (class 1 sibling)
* **Where:** `sf_rdma_requester.sv:486-487` (`chi <= ack_cn`, `ahi <= ack_an`) followed by `:507-508` (`if (!psn_le(una+1, chi)) chi <= una+1;` evaluated on the OLD `chi`; last assignment wins).
* **What is wrong:** a READ retires through its data placement (`e_done`) while `chi == una` (its ACK has not arrived yet -- the instrumented build counts 34 such retirements in the 400 chaos runs and 67-75 in 400 random runs). An ACK with `cn > una+1` processed in that very cycle has its commit frontier replaced by `una+1`;
  the responder will not repeat it, so the entries behind the READ complete only after retransmission timeouts.
* **Repro (cycle exact, found by `tests/rdma/review/sweep_chi.py`):** `rv12_chi_update_lost_to_retire_fixup.scn` -- the WRITE CQEs complete at cycle 9401/9402 (`retry_timeout=2`) instead of ~254; neighbouring injection delays 148/150 give 254.
  Also observed in the wild: `chi_update_lost_to_retire_fixup` in random scenario `a9001_118_mix` (m16_16 build, seed 2). (The checker aborts with MODEL ERROR on the hand-injected ACK; read the `.res`.)
* **Fix:** `chi <= commit_adv ? ack_cn : una+1` (take the later PSN) -- compute `chi_n/ahi_n` once, as `max(chi, ack_cn, una+1)`.
* **Confidence:** very high.

### F-08 MEDIUM -- request frames already queued in the adapter leave after the QP entered ERR
* **Where:** `sf_rdma_qp.sv:215` (`tx_hold = st_drain` only), `sf_rdma_requester.sv:250` (ERR only stops the *offer* of new headers); frames in the adapter's header FIFO / payload ring are started regardless.
* **What is wrong:** spec 11.1: "Issue stops immediately; no further frame carrying new requests is transmitted." After a forced/any ERR, up to HQ_DEPTH (4) request frames (new PSNs) still go out and the peer executes them although every WQE was already completed `WR_FLUSH_ERR`.
* **Repro:** `rv10_frames_leave_after_err.scn`: A's TX frozen, 4 WRITEs queued, A forced to ERR (CQEs `WR_FLUSH_ERR` at cycles 696-699), stall released: A `tx_frames=4`, B `epsn_accepts=4` and 32 MEMW words (cycles 780-832). (The checker mismatch is the model's view without the stall; the facts are in `.res`.)
* **Fix:** hold/discard port-0 headers (and their reserved payload) when the QP is in ERR (`tx_hold`/`tx_flush` for port 0 on `flush_en`).
* **Confidence:** high; severity MEDIUM because spec 11.3 already declares the remote effect of flushed WQEs unknown.

### F-09 MEDIUM -- a DMA-guard violation makes the following QP RESET hang for ever (fault injection)
* **Where:** `sf_rdma_rx.sv:349,377,389` (a pending-completion tag is pushed together with the write command), `sf_rdma_dma_wr.sv:73,78,152` (guard failure converts the command to DISCARD which never raises `done_valid`), `sf_rdma_rx.sv:469` (`quiet` needs `tg_empty`), `sf_rdma_qp.sv:216`.
* **What is wrong:** the stale tag keeps `tg_empty` low, `rx_quiet` never rises, DRAIN never ends: `cfg_ready` stays low, no more MR/QP command can be issued; only `rst_n` recovers. This is the recovery path of the defence-in-depth mechanism (the three bugs already found fired it).
* **Repro:** `rv11_reset_after_guard_violation.scn` with a COPY of the RTL in which `+GUARD_WR_N=2` forces a guard failure (`tests/rdma/review/run_guard_inject.sh`): `QPST ep=B state=5 cause=6`, `MON B cfg command QP_RESET never completed`.
* **Fix:** let dma_wr raise `done_valid` (with error) for converted commands, or have rx not count converted tags (`dw_viol` pops the tag); additionally let `quiet` ignore `tg` in ERR/DRAIN.
* **Confidence:** high (injected fault; the code path is deterministic).

### F-10 LOW -- drop-counter attribution order (spec 3.4)
* **Where:** `sf_rdma_transport_adapter.sv:317,384` (`f_len` = `paylen > MTU` / class rule is the first entry of `why`).
* **What is wrong:** spec order is runt/length -> keep -> macerr -> ethertype -> mac -> version -> opcode -> *(paylen > MTU or class rule -> rx_drop_len)* -> qpn -> epoch -> state. A frame with a wrong ethertype/MAC/opcode **and** an over-long payload is counted `rx_drop_len`.
* **Repro (fails):** `rv13_drop_counter_order_paylen_gt_mtu.scn` (`rx_drop_len` 3 instead of ethertype/mac/opcode 1/1/1). Frames are dropped either way.
* **Fix:** split `f_len` into the runt/length-rule part (first) and the paylen/class part (after opcode).
* **Confidence:** high.

---------------------------------------------------------------------------------------------------------------------------------------------------

## SUSPECTED (reasoning only; no failing run)

### S-01 MEDIUM -- go-back-N rewind in the same cycle as a retire still leaves `txp < una` (class 3 sibling of the fixed bug)
* **Where:** `sf_rdma_requester.sv:478-481` (`ev_to`: `txp <= una`; `ev_nk`/`ev_rn`: `txp <= nak/rnr_tgt_c`) vs. `:505` (`if (txp == una) txp <= una + 1;` compares the OLD `txp`).
* **Trace:** cycle c: `ev_nk` with `nak_tgt_c == una` (clamped), `txp_old > una`, and `retire_go` for entry `una`. `txp <= una` (rewind) is not corrected because `txp_old != una`; `una <= una+1`. Now `txp = una-1`: the retired entry (its WQE
  grant released if it was the last entry) is re-transmitted; payload re-read of a freed buffer -> DMA guard violation -> QP ERR when the region's refcount is 0 (otherwise a harmless duplicate frame that reads memory after the host owns it again).
  Same for `ev_rn` and `ev_to`. Reachability is low because `progress` (retire) normally suppresses the same-cycle event (that is F-03!): it needs a retire without `progress` in the previous cycle (READ placement completing, or a retire delayed by `cmp_ready`).
  The instrumented build (`@@INV REQ txp_below_una`, `@@EVT nak_rewind_with_retire`) saw it 0 times in ~2 000 runs.
* **Fix:** compute `txp_n` once: `txp_n = rewind ? target : txp(+1)`, then `if (retire && psn_lt(txp_n, una+1)) txp_n = una+1`.
* **Confidence:** medium (mechanism certain from the code, hit never observed).

### S-02 LOW -- simultaneous releases on a shared release port lose one (class 2)
* **Where:** `sf_rdma_rx.sv:454-461` (`rel_a`/`rel_f`/`rel_c` share one port, priority mux; the comment claims mutual exclusion): `rel_f` (flush of a partial SEND) can coincide with the commit of an older WRITE entry (`c_ref=1`), `rel_a` (aborted check in S_CHK) with `rel_c`.
  `sf_rdma_requester.sv:372-373`: `flush_chk_rel` (one cycle late) vs `ctx_pop && w_ref` of another WQE flushed in the same cycle.
* **Effect:** the dropped release leaves `refcnt` +1; `MR_INVAL` answers BUSY in ERR until the QP RESET (which clears refs). Not seen in the 400 chaos runs (`@@INV RX rel_collision` / `REQ rel_collision_flush_chk` = 0).
* **Fix:** per-source release ports (the registry already has NREL=3 inputs), or a small release queue.
* **Confidence:** medium.

### S-03 LOW -- `fail_pend` set while the WQE-context ring becomes empty
* **Where:** `sf_rdma_requester.sv:322` (`fail_exh` needs `!w_empty`), `:493-497` (exhaustion sets `fail_pend`, `halt`), `:332` (`do_fail` outranks retire).
* **Trace:** the retry unit's `exhausted` pulse (registered) at cycle c, the last outstanding WQE retiring at cycle c (READ placement or `cmp_ready` stall -- the same no-progress-in-c-1 corner as S-01): `fail_pend=1`, `halt=1`, `w_empty` -> nothing ever fails, no new WQE ever starts (`start_ok` needs `!halt`), QP stays RTS.
* **Fix:** clear `fail_pend` when `w_empty && !u_exist`.  **Confidence:** medium-low (needs a rare coincidence).

### S-04 MEDIUM (design) -- spec 12.7 deadlock-freedom argument does not hold once the link back-pressures
* **Where:** `sf_rdma_rx.sv:318-326,439` (a request waits for `ring_free`; the ring head may be a READ that waits for the READ executor, which waits for TX-buffer space), `sf_rdma_rdgen.sv:95-96`, `sf_rdma_transport_adapter.sv:117,261`.
* **Reasoning:** "READ execution waits only for ... transmit-buffer space, which drains as the peer receives" -- the peer's RX drains only through its receive processor, which handles headers strictly in order and can itself be blocked on `ring_free` behind *its* unfinished READ (7 WRITEs behind one READ fill an 8-entry ring).
  With a link that back-pressures (`tx_ready`/`rx_ready` as specified in 12.4) two endpoints can each hold a READ at the ring head, a full ring and a full RX buffer: circular wait. The bench link is an unbounded queue, so it cannot show it; the PacketCore integration was not examined for it.
* **Fix / mitigation:** bound the READ executor independently (a separate READ_RESP buffer that always drains), or let the rx processor skip over / park a blocked head request; at least document the assumption.  **Confidence:** low-medium (needs a bounded-link bench to demonstrate).

### S-05 LOW -- `nak_c` is overwritten while an older NAK is still pending
* **Where:** `sf_rdma_ackgen.sv:117` (`if (nak_set) nak_c <= nak_code;`, one `nak_pend`). RNR pending + a later out-of-sequence frame -> only SEQ_ERR is sent (RNR back-off skipped, go-back-N at once); the reverse merges to RNR. Allowed by A.5 ("a pipelined request behind an RNR'd SEND legitimately provokes a SEQ_ERR NAK"), so only a robustness remark.

### S-06 LOW -- exhaustion fails an already-committed head WQE
* **Where:** `sf_rdma_requester.sv:323,332` (`do_fail` has priority over `do_retire`; the failing WQE is always the head ctx). If `exhausted`/`rnr_exh` lands while the head WQE's entries are all committed but not yet retired (one retire per cycle), the committed WQE completes `RETRY_EXC_ERR` (spec 11.1 says the *oldest unfinished* WQE fails). Narrow window (progress suppresses the timer while retiring).

---------------------------------------------------------------------------------------------------------------------------------------------------

## Reviewed and found sound (no defect found; short)
* **Same-cycle set/clear in `sf_rdma_ackgen`** after the fix (event-wins structure), commit-ring `c_done` set/clear (distinct indices by construction), `epsn/cpsn` loads, `nak_sent` set/clear exclusivity, `cur_valid` set/clear.
* **Counters with net update:** `rd_out`, `dma_rd.outst`, `rdgen.outst`, adapter `t_res`, registry `ref_nx` (several acquires + 3 releases per cycle), CQ `credits_nx`, FIFO pointers, retry counters (`retry_cnt/rnr_cnt` bounded by the compares).
* **PSN arithmetic:** all modular compares (`psn_lt/le`, `dc/da/dn`, `rr_d`, `dpsn`, rdgen fence, `chi/ahi` clamps) are correct for WINDOW 2, 4, 8, 16 (random campaign with PSN start values near 0xFFFFFF in every configuration; WINDOW=2/16 builds pass 250 random + 139 directed).
* **Byte lanes:** adapter TX/RX header assembly, padding to 60 bytes, last-beat keep, payload store/commit/rollback at DW 32/64/128; `dma_rd`/`dma_wr` first/last-word strobes and gearbox use at DW 32/128 (random campaign, MTU 64..1024, odd lengths and alignments); PA_W = 40 build.
* **Registry:** check order, 65-bit range arithmetic, same-cycle MR_INVAL vs. acquire exclusion, reference accounting, guard window check, `ref_clear`.
* **QP reset (clean path):** DRAIN ordering (flush, wait for DMA/TX/rx quiet, flush TX header FIFOs, clear registry refs), SQ/RQ post rejection while DRAIN, CQ credit accounting over 400 chaos ERR/RESET runs (apart from F-02/F-05).
* **Protection:** no path from a wire frame to memory without a registry grant + guard was found (continuation SEND segments, READ_RESP placement and duplicate-READ re-check included).
* **Ordering rules:** fatal NAK only after `cpsn == epsn` (bench monitor + code), duplicate suppression (`psn ≺ epsn` never writes), RAW fence, NAK replay in ERR, RNR for first SEND segment / full READ queue.
* **Parameter builds:** DW 32/64/128 x MTU 64..1024 x WINDOW 2..16 x MAX_RD 1..4 x MEM_RD_OUT/MEM_WR_OUT 2/16 pass the directed suite and the random campaign with no invariant hit (apart from the F-03/F-07 events).
  One exception that is a scenario/timing artefact, not an RTL defect: DW32/MTU1024/WINDOW2, `t137` shows 2 spurious timeouts on a clean link because the 70-cycle memory needs ~3060 cycles to commit 700 bytes at DW 32 (timeout 3000); with `timeout=6000` it passes.
  (Design remark: a commit that takes longer than the requester's timeout always causes go-back-N duplicates, the responder sends only one acceptance ACK.)

## Not examined / limits
* Formal flow and `formal/` (not re-run), the PacketCore integration bench (`build-pc`), synthesis reports, performance claims.
* `NMR` / `PD_W` / `CTX_W` / `MAX_MSG_BYTES` other than the defaults, `PA_W = 64`, `ACCEPT_ACK_DELAY` variants; MTU 4096; CQ_DEPTH < SQ_DEPTH + RQ_DEPTH beyond the existing directed scenario.
* S-04 needs a link model with back-pressure; no such bench was built.
* The black-box checker aborts on hand-crafted ACKs in rv12 (MODEL ERROR) and cannot model the injected stalls of rv06/rv10/rv14: for those, read the `.res` as described in each finding.

---------------------------------------------------------------------------------------------------------------------------------------------------

## Maintainer disposition (added after the review; the text above is the reviewer's, unchanged)

Every CONFIRMED finding was **reproduced by the maintainer on the pre-fix RTL first** (the plain scenarios fail the model comparison; the injection ones fail their explicit expectations), fixed, and is now guarded by a scenario that **fails on the old RTL and passes on the new**. Details, the guard of each fix and the mutants that prove the guard are in `docs/CHANGELOG.md` ("Second wave"). Re-run: `python3 scripts/regress.py --dir tests/rdma/review` (and `make build-fi` for rv11).

| id | disposition |
|---|---|
| F-01 | **fixed** (timer armed while `una ≺ err_psn`, only earlier entries retransmitted; the READ ends RETRY_EXC_ERR) — spec 9.5(6) |
| F-02 | **fixed** (ring first, flush after an empty ring) — spec 11.1 |
| F-03 | **fixed** (NAK/RNR processed in a progress cycle) — spec 9.6 |
| F-04 | **fixed** (poisoned frames never leave; LOC_OP_ERR; RECV LOC_OP_ERR; bench `mem_err`) — spec 9.7 |
| F-05 | **fixed** (READ entries skipped in ERR; reset waits for the ring) + standing bench invariant "nothing open after a reset" |
| F-06 | **fixed for the flush and local-error paths**; the retry/NAK-exhaustion paths are not gated (residual, in LIMITATIONS) |
| F-07 | **fixed** (single net next-state for `chi`/`ahi`/`txp`) |
| F-08 | **fixed for request frames**; the first version also dropped READ responses and broke the control scenario `rv01c` — narrowed (CHANGELOG) |
| F-09 | **fixed** (a guard-converted write command reports `done`) — tested with the simulation-only fault injection |
| F-10 | **fixed** (spec 3.4 order) |
| S-01 | **fixed** together with F-07; **confirmed afterwards by an independent formal counterexample** on the pre-fix RTL (never hit in the reviewer's ~2 000 simulation runs) |
| S-02 | **fixed** (one release port per source) |
| S-03 | **fixed** (stale `fail_pend`/`halt` cleared) — structural, never reproduced |
| S-04 | **not fixed, documented**: the spec 12.7 argument now states its assumption; a bounded-link bench was not built (LIMITATIONS) |
| S-05, S-06 | **not fixed, documented** (LIMITATIONS); both are narrow and allowed or nearly allowed by the spec |

**What the review did not examine** (its own list) and what was done about it: the formal flow (re-run by a separate agent on the fixed RTL, `reports/formal.md`), the PacketCore integration (re-run, three expected differences, `reports/regression_all.md`), synthesis and performance claims (re-run, `reports/synth.md`, `benchmarks/rdma/REPORT.md`), parameter variants beyond the review's twelve (`reports/regression_matrix.md`).
