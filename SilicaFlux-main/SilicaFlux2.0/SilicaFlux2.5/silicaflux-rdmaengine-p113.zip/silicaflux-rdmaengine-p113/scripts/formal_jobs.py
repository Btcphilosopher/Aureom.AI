"""Job table of scripts/formal.py (one J(...) per formal job).  J(name, kind, group, params, depth, claim)."""

def define(J):
    # ---------------------------------------------------------------- retry
    J("retry_prove", "prove", "retry", dict(FULLCFG=1), 4, "R1-R8 (+ F-03: a NAK in a progress cycle is processed against the reset base, progress clears `dead`) on the real widths (32-bit timeout / rnr_delay): counters bounded, exhaustion, timer never early / never lost, progress reset, RNR wait exactly rnr_delay; UNBOUNDED")
    J("retry_bmc", "bmc", "retry", dict(FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2), 22, "R1-R8 from reset, small configuration, depth 22 (cross-check of the induction proof)")
    J("retry_bmc_k4", "bmc", "retry", dict(FULLCFG=0, TMAX=1, RMAX=4, NMAX=0, DMAX=1), 20, "R1-R8 from reset with retry_max up to 4 (back-off exponent min(k,3) reached: a timer expiry at k >= 3), depth 20")
    for v, w in [(11, "F-03: a SEQ_ERR NAK arriving in a progress cycle fires ev_nak"), (12, "F-03: an RNR NAK arriving in a progress cycle starts the wait"), (13, "`progress` clears the exhaustion latch")]:
        J(f"vac_retry_{v}", "vac", "retry", dict(FULLCFG=0, TMAX=2, RMAX=2, NMAX=1, DMAX=2, VAC=v), 20, f"witness: {w}")
    J("vac_retry_10", "vac", "retry", dict(FULLCFG=0, TMAX=1, RMAX=4, NMAX=0, DMAX=1, VAC=10), 24, "witness: a timer expiry with retry_cnt == 4 after k = 3 retries (exponent cap exercised) is reachable")
    for v, w in [(1, "a timer expiry (ev_timeout)"), (2, "a SEQ_ERR-driven retry (ev_nak)"), (3, "retry exhaustion"), (4, "the end of an RNR wait (ev_rnr)"),
                 (5, "RNR exhaustion"), (6, "a timeout with back-off exponent 3 (4th retry)"), (7, "progress with a non-zero retry counter"),
                 (8, "OBS-1: an RNR wait stretched by a progress pulse"), (9, "an RNR NAK arriving during the wait")]:
        J(f"vac_retry_{v}", "vac", "retry", dict(FULLCFG=0, TMAX=2, RMAX=3 if v == 6 else 2, NMAX=1, DMAX=2, VAC=v), 30 if v == 6 else 18, f"witness: {w} is reachable")

    # ---------------------------------------------------------------- completion
    J("completion_prove", "prove", "completion", dict(KMAX=0), 4, "K1-K4: credit invariant credits+cq_count+(takes-pushes)==CQ_DEPTH, no overflow, FIFO exactly-once order of a free-ordinal tagged CQE; UNBOUNDED (CQ_DEPTH=4)")
    J("completion_bmc", "bmc", "completion", dict(KMAX=3), 14, "K1-K4 from reset, tagged ordinal K < 3, depth 14 (cross-check of the induction proof)")
    for v, w in [(1, "the CQ becomes full (cq_count == CQ_DEPTH)"), (2, "all credits are reserved (credits == 0: posting back-pressured)"),
                 (3, "both producers offer in the same cycle and exactly one is served"), (4, "a pop and a push in the same cycle"), (5, "the tagged CQE is popped (the FIFO-order check is exercised)")]:
        J(f"vac_completion_{v}", "vac", "completion", dict(KMAX=3, VAC=v), 14, f"witness: {w}")

    # ---------------------------------------------------------------- wqe
    J("wqe_prove", "prove", "wqe", dict(KMAX=0), 4, "W1-W6: post status = spec 6.3 in the stated precedence for ALL inputs, unsupported opcode never accepted, rejected post takes no slot/credit, FIFO order of a free-ordinal tagged post, back-pressure, occupancy; UNBOUNDED (depth-4 queues)")
    J("wqe_bmc", "bmc", "wqe", dict(KMAX=3), 14, "W1-W6 from reset, tagged ordinal K < 3, depth 14 (cross-check of the induction proof)")
    for v, w in [(1, "an SQ post is accepted"), (2, "POST_ERR_OPCODE"), (3, "POST_ERR_STATE"), (4, "POST_ERR_LEN"), (5, "POST_ERR_FIELDS"), (6, "POST_ERR_RANGE"),
                 (7, "an RQ post is accepted"), (8, "RQ POST_ERR_STATE"), (9, "RQ POST_ERR_LEN"), (10, "RQ POST_ERR_RANGE"), (11, "SQ full back-pressure"),
                 (12, "an aliasing unsupported opcode (5) offered to a ready queue in RTS"), (13, "the tagged SQ post is popped"), (14, "the tagged RQ post is popped"),
                 (15, "both queues take a credit in the same cycle"), (16, "credit back-pressure with a non-full queue")]:
        J(f"vac_wqe_{v}", "vac", "wqe", dict(KMAX=3, VAC=v), 14, f"witness: {w}")

    # ---------------------------------------------------------------- registry
    J("registry_bmc", "bmc", "registry", dict(P2=0, G2=0, CNT=0), 7, "G1-G8 from reset with symbolic commands (3 SETs fill the table): grant iff every 8.3 clause, first-failing fault code, config statuses, refcounts, guard, counters/log; BOUNDED (NMR=3, real 64-bit VA)")
    J("registry_cnt_bmc", "bmc", "registry", dict(P2=1, G2=0, CNT=1), 5, "G1-G8 with BOTH check ports and the fault statistics: per-class saturating counters and the one-entry fault log equal the shadow; BOUNDED")
    for v, w, d in [(1, "a grant on port 0", 6), (2, "a grant on port 1", 6), (3, "a correct key with a different PD is presented", 6), (4, "fault OVERFLOW (va+len wraps 2^64)", 6),
                    (5, "fault RANGE with a correct key", 6), (6, "fault PAGE_CROSS", 6), (7, "fault XLATE (context not live)", 7), (8, "MR_INVAL answered BUSY", 8),
                    (9, "ERR_DUPKEY", 6), (10, "ERR_RANGE", 5), (11, "ERR_IDX", 5), (12, "the DMA guard passes", 8), (13, "both ports granted in one cycle", 6),
                    (14, "the table is completely full", 8), (15, "fault BAD_DIR", 6), (16, "fault BAD_PERM", 6), (17, "fault BAD_LEN", 6), (18, "fault BAD_KEY", 4), (19, "fault BAD_PD", 6)]:
        J(f"vac_registry_{v}", "vac", "registry", dict(CNT=1, VAC=v), d, f"witness: {w}")

    # ---------------------------------------------------------------- ackgen
    J("ackgen_prove", "prove", "ackgen", dict(), 4, "A1-A6: no flag event is ever lost (incl. same-cycle push), flags cleared only by the consuming handshake, priority fatal>NAK>replay>ACK, frame contents, fatal NAK only at cpsn==epsn, replays repeat the fatal code, acceptance report; UNBOUNDED")
    J("ackgen_bmc", "bmc", "ackgen", dict(), 18, "A1-A6 from reset, depth 18 (cross-check of the induction proof)")
    for v, w in [(1, "ack_set in the cycle an ACK frame is pushed (the lost-event bug situation)"), (2, "nak_set while a NAK frame is pushed"), (3, "replay_set while a replay frame is pushed"),
                 (4, "the fatal NAK is emitted"), (5, "a replay frame is offered after the fatal NAK"), (6, "the acceptance report makes an ACK pending"),
                 (7, "an acceptance event in the cycle a frame is pushed"), (8, "NAK and ACK pending together (priority exercised)"), (9, "a fatal NAK held back until cpsn == epsn"),
                 (10, "a second acceptance event while one is pending")]:
        J(f"vac_ackgen_{v}", "vac", "ackgen", dict(VAC=v), 14, f"witness: {w}")

    # ---------------------------------------------------------------- dma_wr
    J("dma_wr_bmc", "bmc", "dma_wr", dict(KCMAX=2, LMAX=7), 11, "D1-D5 from reset: exact write set / data / strobes of a free command KC at a free address TA, no write for DISCARD / guard-failed commands, viol, commit after all acks, outstanding <= MEM_WR_OUT; BOUNDED (DW=32, PA_W=6)")
    for v, w in [(1, "the tagged WRITE commits (done pulse after all acks)"), (2, "a second word of the tagged command is written"), (3, "a guard failure converts a command and raises viol"),
                 (4, "a DISCARD command consumes payload beats"), (5, "the outstanding-write limit is reached"), (6, "an unaligned tagged byte is written"),
                 (7, "a written word contains an address outside the command (strobe must be 0)"), (8, "an acknowledgement error reaches done_err"), (9, "a guard-converted command reports done (F-09)")]:
        J(f"vac_dma_wr_{v}", "vac", "dma_wr", dict(KCMAX=3, LMAX=9, VAC=v), 14, f"witness: {w}")

    # ---------------------------------------------------------------- dma_rd
    J("dma_rd_bmc", "bmc", "dma_rd", dict(KCMAX=2, LMAX=7), 12, "P1-P5 from reset: read addresses inside the commanded range, payload bytes / keep / last / port exactly as commanded (free command KC), guard-failed commands issue no read and pulse viol, outstanding <= MEM_OUT, no FIFO overflow, done accounting; BOUNDED (DW=32, PA_W=6)")
    for v, w in [(1, "the tagged command completes (done pulse)"), (2, "a second word of the tagged command is read"), (3, "a guard failure raises viol"), (4, "the outstanding-read limit is reached"),
                 (5, "a partial last beat is emitted"), (6, "a misaligned multi-beat command (realignment)"), (7, "a memory error reaches done_err")]:
        J(f"vac_dma_rd_{v}", "vac", "dma_rd", dict(KCMAX=3, LMAX=9, VAC=v), 14, f"witness: {w}")

    # ---------------------------------------------------------------- rx safety
    J("rx_safety_bmc", "bmc", "rx", dict(), 12, "X1-X6: remote-write safety (WRITE only in order, only with the grant of its own check, pa/rid/ctx = granted, never for duplicates / out-of-sequence), epsn/cpsn discipline, no fatal with a used grant, RNR, reserved opcode -> INV_REQ; BOUNDED (WINDOW=4)")
    for v, w in [(1, "a WRITE command from a granted check of an in-order WRITE frame"), (2, "a duplicate request frame is presented"), (3, "a fatal NAK decision"), (4, "RNR: in-order SEND first segment with no receive WQE"),
                 (5, "reserved opcode -> INV_REQ"), (6, "a SEND continuation WRITE command"), (7, "a READ_RESP placement"), (8, "a commit (cpsn advances)"), (9, "the commit window is full"),
                 (10, "a grant arriving in fatal / flush mode is released"), (11, "an out-of-sequence request frame is presented"), (12, "a READ request is accepted"), (13, "a READ entry is committed by the flush (skipped)")]:
        J(f"vac_rx_{v}", "vac", "rx", dict(VAC=v), 12, f"witness: {w}")

    # ---------------------------------------------------------------- requester
    J("requester_w4_rd_bmc", "bmc", "requester", dict(WIN=4, ONLYRD=1), 10, "Q1-Q7 with WINDOW 4 and an all-READ SQ stream (three READs can be outstanding: MAX_RD limit); BOUNDED"); J("requester_rd_bmc", "bmc", "requester", dict(WIN=2, ONLYRD=1), 11, "Q1-Q7 with an all-READ SQ stream (reaches READ issue + retirement races: rd_out, bug 2); BOUNDED"); J("requester_deep_bmc", "bmc", "requester", dict(WIN=2), 10, "SAME harness, depth 10: FOUND the una <= txp violation F-1 (SEQ_ERR rewind and retirement in the same cycle) on the RTL of 12:01 (= review item S-01, fixed by the txp_n net next-state); regression check on the repaired RTL"); J("requester_bmc", "bmc", "requester", dict(WIN=2), 9, "Q1-Q6: window, una<=txp<=nxt (also after rewinds), rd_out == READ entries in flight, completion only after commit / placement, CQEs in post order exactly once, no entries for failed WQEs; BOUNDED (WINDOW=2, MAX_RD=2)")
    for v, w in [(1, "a WRITE completes OK"), (2, "a READ completes OK"), (3, "the window fills"), (4, "a timeout rewinds the transmit pointer"), (5, "an entry retires while txp points at it (bug-3 corner)"),
                 (6, "two READs outstanding"), (7, "a local-check failure completes with LOC_PROT_ERR"), (8, "a flush CQE"), (9, "a retransmitted frame is sent"), (10, "a SEQ_ERR NAK rewinds"),
                 (11, "an RNR wait ends"), (12, "retry exhaustion fails a WQE")]:
        J(f"vac_requester_{v}", "vac", "requester", dict(WIN=2, VAC=v), 18, f"witness: {w}")

    # ---------------------------------------------------------------- psn
    J("psn_spec", "comb", "psn", dict(PART=0), 1, "F1-F4 for ALL 24-bit a, b, c: exactly one of before / equal / after (neither at exactly half the space), transitivity inside a window, window total order, stepping")
    J("psn_rx", "comb", "psn", dict(PART=1), 4, "sf_rdma_rx classification of a request frame (in order / out of sequence / duplicate, exactly-half = stale) equals the spec definition for ALL psn / epsn (exhaustive: combinational in (psn, epsn), epsn loaded freely)")
    J("vac_psn_1", "vac", "psn", dict(PART=0, VAC=1), 1, "witness: a pair at exactly half the space exists")
    J("vac_psn_2", "vac", "psn", dict(PART=0, VAC=2), 1, "witness: transitivity genuinely FAILS outside a window (so the window side-condition of F2 is needed)")
    for v, w in [(1, "a duplicate verdict (ev_dup) occurs"), (2, "an out-of-sequence verdict (ev_oos) occurs"), (3, "an in-order frame is processed (rxh_pop)"), (4, "the exactly-half distance occurs")]:
        J(f"vac_psn_rx_{v}", "vac", "psn", dict(PART=1, VAC=v), 5, f"witness: {w}")
