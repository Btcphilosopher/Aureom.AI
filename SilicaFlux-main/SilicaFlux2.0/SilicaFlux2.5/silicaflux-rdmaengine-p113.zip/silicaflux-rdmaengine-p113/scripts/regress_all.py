#!/usr/bin/env python3
"""One command for the whole simulation-based verification stack.  Writes reports/regression_all.md.

  scripts/regress_all.py [--quick] [--repo /path/to/Aureom.AI]

  1  builds                  make build, make build-fi, make build-pc          (the benches the stages below use)
  2  lint                    Verilator -Wall over the engine + the 13 illegal-parameter refusals       (scripts/lint.py)
  3  vendor check            third_party/ is byte-identical to the verified repo IP                    (needs --repo)
  4  model self-tests        the reference model's own unit tests
  5  directed suite          every scenario in tests/rdma/scenarios x 5 seeds                           (reference model as the oracle)
  6  review repros           tests/rdma/review: one scenario per defect the independent review found    (explicit .expect oracles)
  7  random suites           gen_random.py seeds 1..6 x 40 scenarios                                    (reference model)
  8  fault-tail suites      gen_random.py --faults seeds 101..106 x 30 scenarios                       (reference model)
  9  chaos suites           gen_chaos.py: forced ERR/RESET at random moments, seeds 1..6 x 80          (model-independent properties)
 10  PacketCore in path     the directed suite through the real PacketCore (P62) front end              (3 scenarios differ by design, see below)
Exit status 0 only if every stage passes (the PacketCore stage is compared with its documented expected-difference set)."""
import argparse, glob, os, re, shutil, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PC_EXPECTED_DIFF = {"t084_inject_malformed_frames.scn", "t085_inject_malformed_frames_to_requester.scn", "t139_wire_write_flagged_bad_by_mac.scn"}

def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT, **kw)

def regress(args):
    r = sh([sys.executable, os.path.join("scripts", "regress.py")] + args)
    m = re.search(r"(\d+)/(\d+) runs pass", r.stdout)
    fails = [l.split()[1] for l in r.stdout.splitlines() if l.startswith("FAIL")]
    return (int(m.group(1)), int(m.group(2)), fails) if m else (0, 0, ["no summary: " + (r.stdout + r.stderr)[-200:]])

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--quick", action="store_true"); ap.add_argument("--repo", default="")
    a = ap.parse_args(); t0 = time.time(); rows = []; ok_all = True
    def row(name, ok, detail):
        nonlocal ok_all
        ok_all &= ok; rows.append((name, "PASS" if ok else "**FAIL**", detail)); print(f"{'PASS' if ok else 'FAIL'}  {name}: {detail}", flush=True)
    os.makedirs(os.path.join(ROOT, "out"), exist_ok=True)
    for tgt in ("build", "build-fi", "build-pc"):
        r = sh(["make", tgt]); row("make " + tgt, r.returncode == 0, "ok" if r.returncode == 0 else (r.stdout + r.stderr)[-200:])
    r = sh([sys.executable, os.path.join("scripts", "lint.py")]); row("lint (Verilator -Wall + illegal parameters)", r.returncode == 0, (r.stdout.strip().splitlines() or [""])[-1])
    if a.repo:
        r = sh([sys.executable, os.path.join("scripts", "check_vendor.py"), "--repo", a.repo]); row("vendor check", r.returncode == 0, (r.stdout.strip().splitlines() or [""])[-1])
    else:
        rows.append(("vendor check", "skipped", "no --repo given")); print("SKIP  vendor check (no --repo)")
    r = sh([sys.executable, os.path.join("tests", "rdma", "model", "test_model.py")]); row("reference model self-tests", r.returncode == 0, (r.stderr.strip().splitlines() or [""])[-1])
    seeds = "1" if a.quick else "1,2,3,4,5"
    p, t, f = regress(["--dir", "tests/rdma/scenarios", "--seeds", seeds, "--jobs", "4", "--tag", "_all_dir", "--report", "out/ra_directed.md"]); row(f"directed suite x seeds {seeds}", p == t and t > 0, f"{p}/{t} runs" + (f"; failing {f[:3]}" if f else ""))
    p, t, f = regress(["--dir", "tests/rdma/review", "--jobs", "4", "--tag", "_all_rev", "--report", "out/ra_review.md"]); row("review repros (explicit expectations)", p == t and t > 0, f"{p}/{t} runs" + (f"; failing {f[:3]}" if f else ""))
    nseed = 2 if a.quick else 6
    tot = [0, 0]; bad = []
    for s in range(1, nseed + 1):
        d = os.path.join("out", f"rand_{s}"); shutil.rmtree(os.path.join(ROOT, d), ignore_errors=True)
        sh([sys.executable, "-I", os.path.join("tests", "rdma", "gen", "gen_random.py"), "--seed", str(s), "--count", "40", "--out", d])
        p, t, f = regress(["--dir", d, "--jobs", "4", "--tag", f"_all_r{s}", "--report", f"out/ra_rand{s}.md"]); tot[0] += p; tot[1] += t; bad += f
    row(f"random suites (seeds 1..{nseed} x 40)", tot[0] == tot[1] and tot[1] > 0, f"{tot[0]}/{tot[1]} runs" + (f"; failing {bad[:3]}" if bad else ""))
    tot = [0, 0]; bad = []
    for s in range(1, nseed + 1):
        d = os.path.join("out", f"randf_{s}"); shutil.rmtree(os.path.join(ROOT, d), ignore_errors=True)
        sh([sys.executable, "-I", os.path.join("tests", "rdma", "gen", "gen_random.py"), "--faults", "--seed", str(100 + s), "--count", "30", "--out", d])
        p, t, f = regress(["--dir", d, "--jobs", "4", "--tag", f"_all_f{s}", "--report", f"out/ra_randf{s}.md"]); tot[0] += p; tot[1] += t; bad += f
    row(f"fault-tail suites (seeds 101..{100 + nseed} x 30)", tot[0] == tot[1] and tot[1] > 0, f"{tot[0]}/{tot[1]} runs" + (f"; failing {bad[:3]}" if bad else ""))
    cd = os.path.join("out", "chaos_all"); shutil.rmtree(os.path.join(ROOT, cd), ignore_errors=True)
    for s in range(1, nseed + 1):
        sh([sys.executable, "-I", os.path.join("tests", "rdma", "gen", "gen_chaos.py"), "--src", os.path.join("out", f"rand_{s}"), "--seed", str(s), "--out", cd, "--per", "2"])
    p, t, f = regress(["--dir", cd, "--checker", "chaos", "--jobs", "4", "--timeout", "120", "--tag", "_all_chaos", "--report", "out/ra_chaos.md"]); row(f"chaos suites ({nseed} seeds, forced ERR/RESET)", p == t and t > 0, f"{p}/{t} runs" + (f"; failing {f[:3]}" if f else ""))
    pc = os.path.join("out", "tb_pc_dw64_mtu256_w8")
    p, t, f = regress(["--tb", pc, "--dir", "tests/rdma/scenarios", "--jobs", "3", "--tag", "_all_pc", "--report", "out/ra_pc.md"])
    unexpected = sorted(set(f) - PC_EXPECTED_DIFF); missing = sorted(PC_EXPECTED_DIFF - set(f))
    row("PacketCore (P62) in path", not unexpected and t > 0, f"{p}/{t} runs; {len(set(f) & PC_EXPECTED_DIFF)} expected differences (PacketCore filters malformed / MAC-flagged frames before the engine counts them)" +
        (f"; UNEXPECTED {unexpected[:3]}" if unexpected else "") + (f"; (expected differences that passed: {missing})" if missing else ""))
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, "reports", "regression_all.md"), "w") as o:
        o.write(f"# Full simulation regression (`scripts/regress_all.py`{' --quick' if a.quick else ''})\n\n{'**ALL STAGES PASS**' if ok_all else '**FAILURES**'} in {time.time() - t0:.0f} s.\n\n| stage | result | detail |\n|---|---|---|\n")
        for r_ in rows: o.write("| %s | %s | %s |\n" % r_)
        o.write("\nThe benches are Verilator models of the RTL; every scenario is run with randomised initial state (`+verilator+rand+reset+2`). "
                "Evidence level: RTL simulation. No FPGA, no timing, no silicon.\n")
    print(f"\n{'ALL STAGES PASS' if ok_all else 'FAILURES'} ({time.time() - t0:.0f} s) -> reports/regression_all.md")
    return 0 if ok_all else 1

sys.exit(main())
