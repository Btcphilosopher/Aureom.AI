#!/usr/bin/env python3
"""Yosys generic-gate synthesis ESTIMATE (no PDK, no FPGA mapping, no timing).  Writes reports/synth.md.
  scripts/synth.py [--set default|small|wide]
Counts are $_AND_/$_DFF_-style generic cells after `synth`; arrays (rings, tables) are mapped to REGISTERS here, so storage that would infer SRAM/BRAM
is counted as flops: the numbers are an upper bound on logic, a size INDICATION and nothing else.  No frequency, power or area is claimed."""
import argparse, os, re, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = open(os.path.join(os.path.dirname(ROOT), "..", "..", "rtl_files.txt")).read().split() if False else \
      "rtl/sf_rdma_fifo.sv rtl/sf_rdma_memory_registry.sv rtl/sf_rdma_wqe.sv rtl/sf_rdma_completion.sv rtl/sf_rdma_retry.sv rtl/sf_rdma_dma_rd.sv rtl/sf_rdma_dma_wr.sv rtl/sf_rdma_transport_adapter.sv rtl/sf_rdma_requester.sv rtl/sf_rdma_rx.sv rtl/sf_rdma_rdgen.sv rtl/sf_rdma_ackgen.sv rtl/sf_rdma_qp.sv rtl/sf_rdma_perf.sv rtl/sf_rdma_engine.sv third_party/sfb_skid_buffer.sv third_party/sf_rr_arb.sv third_party/sf_stream_dma_align.sv".split()
SETS = {"default": {}, "small": dict(DW=32, MTU=64, WINDOW=4, NMR=4, SQ_DEPTH=4, RQ_DEPTH=4, CQ_DEPTH=8), "wide": dict(DW=128, MTU=512, WINDOW=16)}
def run(name, params):
    chp = "; ".join(f"chparam -set {k} {v} sf_rdma_engine" for k, v in params.items())
    script = f"read_verilog -sv -Irtl {' '.join(RTL)}; {chp + ';' if chp else ''} hierarchy -check -top sf_rdma_engine; synth -top sf_rdma_engine; stat"
    t0 = time.time(); r = subprocess.run(["yosys", "-q", "-l", os.path.join(ROOT, "out", f"synth_{name}.log"), "-p", script], capture_output=True, text=True, cwd=ROOT)
    log = open(os.path.join(ROOT, "out", f"synth_{name}.log")).read()
    return log, time.time() - t0, r.returncode
def parse(log):
    mods = {}; cur = None
    for l in log.splitlines():
        m = re.match(r"=== (.+?) ===", l)
        if m: cur = m.group(1); mods[cur] = {"cells": 0, "ff": 0}; continue
        if cur and re.match(r"\s+Number of cells:\s+(\d+)", l): mods[cur]["cells"] = int(re.search(r"(\d+)", l).group(1))
        if cur and re.search(r"\$_(S?DFF|DFF|DFFE|SDFFE|SDFFCE|DFFSR|ALDFF|ALDFFE)\w*\s+(\d+)", l): mods[cur]["ff"] += int(l.split()[-1])
    return mods
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--set", default="default,small,wide"); a = ap.parse_args()
    os.makedirs(os.path.join(ROOT, "out"), exist_ok=True); out = ["# Synthesis estimate (Yosys generic gates)\n",
        "**What this is.** `yosys synth` of `sf_rdma_engine` with the vendored IP, generic gate library, hierarchy kept. **What it is not:** no PDK, no FPGA mapping, no timing, no area in µm², no frequency, no power. Arrays (payload rings, request table, WQE context ring, queues) become REGISTERS here although a real flow would infer SRAM/BRAM for the rings, so the flop counts overstate the logic.\n"]
    for name in a.set.split(","):
        log, secs, rc = run(name, SETS[name]); mods = parse(log)
        out.append(f"\n## `{name}` {SETS[name] or '(defaults: DW=64 MTU=256 WINDOW=8 NMR=8)'}  — {secs:.0f} s, rc={rc}\n\n| module (parameterised instance) | cells | flip-flops |\n|---|---|---|")
        top = [k for k in mods if k.endswith("sf_rdma_engine") or k == "sf_rdma_engine"]
        for k, v in sorted(mods.items(), key=lambda kv: -kv[1]["cells"]):
            nm = re.sub(r"^\$paramod\$[0-9a-f]+\\", "", k).replace("\\", ""); out.append(f"| `{nm}` | {v['cells']} | {v['ff']} |")
        tot = re.findall(r"design hierarchy ===.*?Number of cells:\s+(\d+)", log, flags=re.S)
        if tot: out.append(f"\n**Whole design (hierarchy summed): {tot[-1]} cells.**")
        print(name, "done", f"{secs:.0f}s", "total cells:", tot[-1] if tot else "?")
    open(os.path.join(ROOT, "reports", "synth.md"), "w").write("\n".join(out) + "\n")
main()
