#!/usr/bin/env python3
"""Run the scenario suite: bench (Verilator, two endpoints) -> result file -> independent Python reference model/checker.

  scripts/regress.py [--tb out/tb_dw64_mtu256_w8] [--dir tests/rdma/scenarios] [--only SUBSTR] [--jobs N] [--seeds S1,S2] [--pc]
Each scenario is run once per seed (the seed randomises Verilator's initial state: any un-reset state shows up as a failure).
Exit status 0 only if every run passed AND no bench monitor fired.  Results: reports/regression.md, out/regress/<name>.<seed>.{res,log}
"""
import argparse, glob, os, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHECK = os.path.join(ROOT, "tests", "rdma", "model", "check_results.py")
CHECK_EXPECT = os.path.join(ROOT, "scripts", "check_expect.py")
CHECK_CHAOS = os.path.join(ROOT, "scripts", "check_chaos.py")
CHK_MODE = "model"                                  # --checker chaos: model-independent conservation properties (gen_chaos.py scenarios)

def run_one(tb, scn, seed, outdir, timeout):
    base = os.path.join(outdir, os.path.basename(scn)[:-4] + f".s{seed}")
    t0 = time.time()
    # a scenario with a sibling .expect file is checked against its listed outcomes (scripts/check_expect.py) instead of the reference model
    exp = scn[:-4] + ".expect"; extra = []
    if os.path.exists(exp):
        for raw in open(exp):
            w = raw.split("#", 1)[0].split()
            if len(w) >= 2 and w[0] == "tb" and w[1] == "fi": tb = tb + "_fi"
            if len(w) >= 2 and w[0] == "args": extra += w[1:]
        if not os.path.exists(tb):
            return dict(name=os.path.basename(scn), seed=seed, ok=False, why="bench variant missing (make build-fi): " + os.path.basename(tb), secs=0.0, out="")
    try:
        p = subprocess.run([tb, f"+verilator+rand+reset+2", f"+verilator+seed+{seed}"] + extra + [scn, base + ".res"],
                           capture_output=True, text=True, timeout=timeout)
        bench_rc = p.returncode; bench_err = p.stderr.strip()
    except subprocess.TimeoutExpired:
        return dict(name=os.path.basename(scn), seed=seed, ok=False, why="bench timeout", secs=time.time() - t0, out="")
    if not os.path.exists(base + ".res"):
        return dict(name=os.path.basename(scn), seed=seed, ok=False, why="no result file: " + bench_err[:200], secs=time.time() - t0, out="")
    c = subprocess.run([sys.executable, "-I", CHECK_EXPECT, scn, base + ".res", exp] if os.path.exists(exp) else
                       [sys.executable, "-I", CHECK_CHAOS, scn, base + ".res"] if CHK_MODE == "chaos" else [sys.executable, "-I", CHECK, scn, base + ".res"],
                       capture_output=True, text=True)
    out = (c.stdout + c.stderr).strip()
    open(base + ".log", "w").write(out + "\n")
    mon = bench_rc != 0
    ok = (c.returncode == 0) and not mon
    why = "" if ok else ("bench monitor/exit %d; " % bench_rc if mon else "") + out.splitlines()[0][:160] if out else ("bench monitor" if mon else "checker failed")
    return dict(name=os.path.basename(scn), seed=seed, ok=ok, why=why, secs=time.time() - t0, out=out)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tb", default=os.path.join(ROOT, "out", "tb_dw64_mtu256_w8"))
    ap.add_argument("--dir", default=os.path.join(ROOT, "tests", "rdma", "scenarios"))
    ap.add_argument("--only", default=""); ap.add_argument("--jobs", type=int, default=2); ap.add_argument("--seeds", default="1")
    ap.add_argument("--timeout", type=int, default=300); ap.add_argument("--report", default=os.path.join(ROOT, "reports", "regression.md"))
    ap.add_argument("--tag", default=""); ap.add_argument("--checker", default="model", choices=["model", "chaos"])
    a = ap.parse_args()
    global CHK_MODE; CHK_MODE = a.checker
    outdir = os.path.join(ROOT, "out", "regress" + a.tag); os.makedirs(outdir, exist_ok=True)
    scns = sorted(s for s in glob.glob(os.path.join(a.dir, "*.scn")) if a.only in os.path.basename(s))
    seeds = [int(x) for x in a.seeds.split(",")]
    jobs = [(a.tb, s, sd, outdir, a.timeout) for s in scns for sd in seeds]
    t0 = time.time()
    with ThreadPoolExecutor(a.jobs) as ex: res = list(ex.map(lambda j: run_one(*j), jobs))
    npass = sum(r["ok"] for r in res)
    os.makedirs(os.path.dirname(a.report), exist_ok=True)
    with open(a.report, "w") as f:
        f.write(f"# Scenario regression\n\nbench `{os.path.relpath(a.tb, ROOT)}`, {len(scns)} scenarios x seeds {seeds} = {len(res)} runs: **{npass} pass, {len(res)-npass} fail** ({time.time()-t0:.0f} s)\n\n")
        f.write("| scenario | seed | result | s | note |\n|---|---|---|---|---|\n")
        for r in res: f.write(f"| {r['name']} | {r['seed']} | {'PASS' if r['ok'] else '**FAIL**'} | {r['secs']:.1f} | {r['why']} |\n")
    for r in res:
        if not r["ok"]: print(f"FAIL {r['name']} seed {r['seed']}: {r['why']}")
    print(f"{npass}/{len(res)} runs pass  ({time.time()-t0:.0f} s)  -> {os.path.relpath(a.report, ROOT)}")
    return 0 if npass == len(res) else 1
sys.exit(main())
