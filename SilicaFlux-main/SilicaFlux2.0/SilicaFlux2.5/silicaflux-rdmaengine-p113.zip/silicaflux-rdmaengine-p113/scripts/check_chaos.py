#!/usr/bin/env python3
"""Model-independent checker for chaos scenarios (tests/rdma/gen/gen_chaos.py).

  check_chaos.py scenario.scn result.res        exit 0 = every property holds

Properties (they hold for ANY legal interleaving of traffic, forced errors and resets):
  P1  no bench monitor fired and the run did not time out  (this includes the bench's standing invariants: CQ credit conservation,
      nothing left open after a reset, every configuration command answered)
  P2  both queue pairs end in RESET
  P3  every ACCEPTED post (POST status 0) produced exactly one CQE, per endpoint and queue (send / receive), and no CQE exists without a post
  P4  send-queue completions are in post order; receive-queue completions are in post order            (spec 13)
  P5  no success after a failure: once a queue produced a non-OK completion, no later completion of that queue is OK
      -- except a RECV: a SEND whose last segment was accepted before the error completes OK in order, and a RECV flushed by the error can only
         come after it, so the property holds for the receive queue as well."""
import sys

def kv(tokens):
    return dict(t.split("=", 1) for t in tokens if "=" in t)

def main():
    scn, res = sys.argv[1:3]
    posts = {("A", "SQ"): [], ("A", "RQ"): [], ("B", "SQ"): [], ("B", "RQ"): []}
    cqes = {("A", "SQ"): [], ("A", "RQ"): [], ("B", "SQ"): [], ("B", "RQ"): []}
    qpst = {}; end = {}; mons = []
    for l in open(res):
        t = l.split()
        if not t: continue
        d = kv(t[1:])
        if t[0] == "POST" and d.get("status") == "0": posts[(d["ep"], d["which"])].append(int(d["wr_id"]))
        elif t[0] == "CQE": cqes[(d["ep"], "RQ" if d["op"] == "4" else "SQ")].append((int(d["wr_id"]), int(d["status"])))
        elif t[0] == "QPST": qpst[d["ep"]] = int(d["state"])
        elif t[0] == "END": end = d
        elif t[0] == "MON": mons.append(l.strip())
    bad = []
    if end.get("monitor_errors", "0") != "0": bad.append("P1: bench monitors fired: " + "; ".join(m[:120] for m in mons[:3]))
    for ep in "AB":
        if qpst.get(ep) != 0: bad.append("P2: QP %s ends in state %s, expected RESET(0)" % (ep, qpst.get(ep)))
    for key in posts:
        want = posts[key]; got = [w for w, _ in cqes[key]]
        if sorted(want) != sorted(got):
            miss = sorted(set(want) - set(got)); extra = sorted(set(got) - set(want))
            dup = sorted({w for w in got if got.count(w) > 1})
            bad.append("P3: %s %s: posted %d, completed %d; missing %s extra %s duplicated %s" % (key[0], key[1], len(want), len(got), miss[:5], extra[:5], dup[:5]))
        elif got != want:
            bad.append("P4: %s %s completions out of post order: %s (posted %s)" % (key[0], key[1], got[:12], want[:12]))
        failed = False
        for w, s in cqes[key]:
            if s != 0: failed = True
            elif failed:
                bad.append("P5: %s %s: wr_id %d completed OK after an earlier failure" % (key[0], key[1], w)); break
    if bad:
        print("FAIL (%d)" % len(bad))
        for b in bad: print("  MISMATCH: " + b)
        return 1
    print("PASS (chaos properties)")
    return 0

sys.exit(main())
