#!/usr/bin/env python3
"""Lint and elaboration checks.  Writes reports/lint.md.
  * Verilator -Wall over the engine for a set of LEGAL parameterisations (must be warning-free),
  * Yosys elaboration (proc) of the full engine and every sub-module,
  * ILLEGAL parameter sets: each must be refused at elaboration by its intended check (the failure must come from the $error text).
"""
import os, subprocess, sys, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = "rtl/sf_rdma_fifo.sv rtl/sf_rdma_memory_registry.sv rtl/sf_rdma_wqe.sv rtl/sf_rdma_completion.sv rtl/sf_rdma_retry.sv rtl/sf_rdma_dma_rd.sv rtl/sf_rdma_dma_wr.sv rtl/sf_rdma_transport_adapter.sv rtl/sf_rdma_requester.sv rtl/sf_rdma_rx.sv rtl/sf_rdma_rdgen.sv rtl/sf_rdma_ackgen.sv rtl/sf_rdma_qp.sv rtl/sf_rdma_perf.sv rtl/sf_rdma_engine.sv third_party/sfb_skid_buffer.sv third_party/sf_rr_arb.sv third_party/sf_stream_dma_align.sv".split()
def vl(params, top="sf_rdma_engine"):
    cmd = ["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-Irtl", "-Ithird_party", "rtl/lint.vlt"] + RTL + ["--top-module", top] + [f"-G{k}={v}" for k, v in params.items()]
    return subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)
LEGAL = [dict(), dict(DW=32), dict(DW=128, MTU=512), dict(MTU=64, WINDOW=4, NMR=4), dict(MTU=1024, WINDOW=16, MAX_RD=4), dict(DW=32, MTU=64, WINDOW=2, MAX_RD=1, SQ_DEPTH=2, RQ_DEPTH=2, CQ_DEPTH=4),
         dict(PA_W=40, PD_W=8, CTX_W=3), dict(SQ_DEPTH=16, RQ_DEPTH=16, CQ_DEPTH=64, MEM_RD_OUT=8, MEM_WR_OUT=2)]
ILLEGAL = [(dict(DW=16), "DW must"), (dict(DW=256), "DW must"), (dict(PA_W=24), "PA_W must"), (dict(MTU=100), "MTU must"), (dict(MTU=4, DW=64), "MTU must"), (dict(MTU=8192), "MTU must"),
           (dict(NMR=1), "NMR must"), (dict(NMR=40), "NMR must"), (dict(PD_W=0), ""), (dict(CTX_W=5), "PD_W must"), (dict(SQ_DEPTH=6), "SQ_DEPTH"), (dict(RQ_DEPTH=1), "SQ_DEPTH"),
           (dict(CQ_DEPTH=12), "CQ_DEPTH"), (dict(WINDOW=3), "WINDOW must"), (dict(WINDOW=1), "WINDOW must"), (dict(MAX_RD=0), "MAX_RD"), (dict(MAX_RD=16), "MAX_RD"),
           (dict(MEM_RD_OUT=3), "MEM_RD_OUT"), (dict(MEM_WR_OUT=1), "MEM_RD_OUT"), (dict(PAGE_BYTES=1000), "PAGE_BYTES"), (dict(ACCEPT_ACK_DELAY=0), "ACCEPT_ACK_DELAY")]
out = ["# Lint and elaboration\n"]; bad = 0
out.append("## Verilator -Wall, legal parameter sets (must be clean)\n\n| parameters | result |\n|---|---|")
for p in LEGAL:
    r = vl(p); w = [l for l in r.stderr.splitlines() if l.startswith("%Warning") or l.startswith("%Error")]
    ok = (r.returncode == 0 and not w); bad += (not ok); out.append(f"| `{p or 'defaults'}` | {'clean' if ok else 'FAIL: ' + (w[0][:120] if w else r.stderr[-120:])} |")
out.append("\n## Illegal parameter sets (each must be refused at elaboration by its own check)\n\n| parameters | refused by | result |\n|---|---|---|")
for p, tag in ILLEGAL:
    # (tag "" = refused by the front end itself, e.g. a zero-width port, before the elaboration check can run)
    r = vl(p); ok = (r.returncode != 0 and (tag == "" or tag in (r.stderr + r.stdout)))
    bad += (not ok)
    out.append(f"| `{p}` | `{tag}` | {'refused' if ok else 'NOT REFUSED (rc=%d)' % r.returncode} |")
out.append("\n## Yosys elaboration (proc) of the full engine\n")
y = subprocess.run(["yosys", "-q", "-p", f"read_verilog -sv -Irtl {' '.join(RTL)}; hierarchy -check -top sf_rdma_engine; proc"], capture_output=True, text=True, cwd=ROOT)
yok = (y.returncode == 0 and "ERROR" not in y.stdout + y.stderr); bad += (not yok); out.append("sf_rdma_engine: " + ("elaborates" if yok else "FAIL\n" + (y.stdout + y.stderr)[-400:]))
open(os.path.join(ROOT, "reports", "lint.md"), "w").write("\n".join(out) + "\n")
print(f"lint: {'OK' if not bad else str(bad) + ' problem(s)'} -> reports/lint.md"); sys.exit(1 if bad else 0)
