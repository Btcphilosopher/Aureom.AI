#!/usr/bin/env python3
"""Package the project as a ZIP.  NOTHING is committed to git: this only reads the tree and writes an archive.

  scripts/make_zip.py [--out PATH]
Excludes build products (out/), Python caches and the random suites; includes sources, docs, reports, scripts, tests (bench, model, generators,
scenarios, suspects), formal harnesses, benchmarks and the vendored IP with its manifest.  Writes a SHA-256 of the archive next to it.
"""
import argparse, hashlib, os, sys, zipfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = os.path.basename(ROOT)
SKIP_DIRS = {"out", "__pycache__", ".git", ".pytest_cache"}
SKIP_SUFFIX = (".pyc", ".o", ".d", ".a")
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default=os.path.join(os.path.dirname(ROOT), NAME + ".zip")); a = ap.parse_args()
    n = 0
    with zipfile.ZipFile(a.out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for d, ds, fs in os.walk(ROOT):
            ds[:] = sorted(x for x in ds if x not in SKIP_DIRS)
            for f in sorted(fs):
                if f.endswith(SKIP_SUFFIX) or f == "perf_names.h" and False: continue
                p = os.path.join(d, f); z.write(p, os.path.join(NAME, os.path.relpath(p, ROOT))); n += 1
    h = hashlib.sha256(open(a.out, "rb").read()).hexdigest()
    open(a.out + ".sha256", "w").write(f"{h}  {os.path.basename(a.out)}\n")
    print(f"{n} files, {os.path.getsize(a.out)/1e6:.2f} MB -> {a.out}\nsha256 {h}")
main()
