#!/usr/bin/env python3
"""Simulation mutation testing: plant ONE defect in a COPY of the RTL, rebuild the bench, run the scenario suite, and require that the
suite notices.  A mutant is KILLED when its set of failing runs differs from the (clean) baseline, SURVIVED otherwise.

  scripts/mutate.py [--only ID,ID] [--list] [--jobs 2] [--dir tests/rdma/scenarios]
Gate: the unmutated design is run first; if the baseline is not fully green the script says so and judges kills against the baseline failure set.
Results: reports/mutation.md.  The original rtl/ is never modified.
"""
import argparse, glob, os, shutil, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
# (id, file, old, new, what a correct suite must notice)
M = [
 ("reg_no_pd",        "sf_rdma_memory_registry.sv", "else if (e_pd != pd)                                     f = `SFR_FT_BAD_PD;", "else if (1'b0)                                          f = `SFR_FT_BAD_PD;", "domain isolation: a correct key from another protection domain must not grant"),
 ("reg_range_lt",     "sf_rdma_memory_registry.sv", "range_ok = (va >= e_vab) && (va_end <= reg_end);", "range_ok = (va >= e_vab) && (va_end <  reg_end);", "off-by-one: a request ending exactly at the region end must be granted"),
 ("reg_range_nolo",   "sf_rdma_memory_registry.sv", "range_ok = (va >= e_vab) && (va_end <= reg_end);", "range_ok = (va_end <= reg_end);", "a request starting below the region must be refused"),
 ("reg_no_overflow",  "sf_rdma_memory_registry.sv", "else if (ovf)                                            f = `SFR_FT_OVERFLOW;", "else if (1'b0)                                          f = `SFR_FT_OVERFLOW;", "a wrapping 64-bit range must be refused as OVERFLOW"),
 ("reg_no_dir",       "sf_rdma_memory_registry.sv", "else if (!dir_ok)                                        f = `SFR_FT_BAD_DIR;", "else if (1'b0)                                          f = `SFR_FT_BAD_DIR;", "a local-only region used remotely is a DIRECTION fault"),
 ("reg_no_perm",      "sf_rdma_memory_registry.sv", "else if (!perm_ok)                                       f = `SFR_FT_BAD_PERM;", "else if (1'b0)                                          f = `SFR_FT_BAD_PERM;", "write to a read-only region must be refused"),
 ("reg_no_pagecross", "sf_rdma_memory_registry.sv", "else if (pg_cross)                                       f = `SFR_FT_PAGE_CROSS;", "else if (1'b0)                                          f = `SFR_FT_PAGE_CROSS;", "page crossing on a non-contiguous region must be refused"),
 ("reg_no_xlate",     "sf_rdma_memory_registry.sv", "else if (!ctx_en[e_ctx])                                 f = `SFR_FT_XLATE;", "else if (1'b0)                                          f = `SFR_FT_XLATE;", "a disabled translation context must refuse access"),
 ("reg_no_dupkey",    "sf_rdma_memory_registry.sv", "else if (dupkey)                            cstat = `SFR_CS_DUPKEY;", "else if (1'b0)                            cstat = `SFR_CS_DUPKEY;", "duplicate keys must be refused at registration"),
 ("reg_key_31bits",   "sf_rdma_memory_registry.sv", "key_q[i] == key &&", "key_q[i][30:0] == key[30:0] &&", "the whole 32-bit key must match"),
 ("reg_pa_nooffset",  "sf_rdma_memory_registry.sv", "pa       = e_pab + offs[PA_W-1:0];", "pa       = e_pab;", "the physical address must include the offset into the region"),
 ("wqe_flags_ok",     "sf_rdma_wqe.sv", "else if (sq_post_flags != 4'd0)                                                     sq_st = `SFR_POST_FIELDS;", "else if (1'b0)                                                     sq_st = `SFR_POST_FIELDS;", "reserved flags must be rejected at post"),
 ("wqe_zero_len",     "sf_rdma_wqe.sv", "(sq_needs_range && sq_post_len == 32'd0)", "1'b0", "zero-length WRITE/READ must be rejected at post"),
 ("wqe_no_range",     "sf_rdma_wqe.sv", "else if (sq_needs_range && sq_rend[64] && (|sq_rend[63:0]))                         sq_st = `SFR_POST_RANGE;", "else if (1'b0)                         sq_st = `SFR_POST_RANGE;", "a message wrapping 2^64 must be rejected at post"),
 ("wqe_op_any",       "sf_rdma_wqe.sv", "else if (sq_post_op != `SFR_WOP_SEND && sq_post_op != `SFR_WOP_WRITE && sq_post_op != `SFR_WOP_READ) sq_st = `SFR_POST_OPCODE;", "else if (sq_post_op[3:2] != 2'b00 && 1'b0) sq_st = `SFR_POST_OPCODE;", "unsupported opcodes must be rejected explicitly"),
 ("cq_no_credit_ret", "sf_rdma_completion.sv", "if (pop)     credits_nx = credits_nx + 1'b1;", "if (1'b0)    credits_nx = credits_nx + 1'b1;", "CQ credits must be returned when the host consumes a CQE"),
 ("retry_one_more",   "sf_rdma_retry.sv", "if (rc_b == cfg_retry_max) begin exhausted", "if (rc_b >  cfg_retry_max) begin exhausted", "retry budget: exactly retry_max retransmissions, then exhausted"),
 ("retry_no_reset",   "sf_rdma_retry.sv", "if (progress) begin tcnt <= '0; retry_cnt <= '0; rnr_cnt <= '0; dead <= 1'b0; end", "if (progress) begin tcnt <= '0; rnr_cnt <= '0; dead <= 1'b0; end", "progress must reset the consecutive-retry counter"),
 ("req_done_early",   "sf_rdma_requester.sv", ": psn_lt(una, chi);", ": 1'b1;", "completion only after the responder COMMITTED the data"),
 ("req_window_over",  "sf_rdma_requester.sv", "wire          win_full = (occ24 >= 24'(WINDOW));", "wire          win_full = (occ24 >  24'(WINDOW));", "the outstanding window is a hard bound"),
 ("req_no_gbn",       "sf_rdma_requester.sv", "if (ev_to && !(err_pending && !psn_lt(una, err_psn)))  txp_n = una;", "if (1'b0)  txp_n = una;", "a timeout must retransmit from the oldest unfinished request"),
 ("req_ignore_commit","sf_rdma_requester.sv", "if (commit_adv) chi_n = ack_cn;", "", "the commit frontier must be tracked"),
 ("req_stale_ack_ok", "sf_rdma_requester.sv", "wire        ack_ok = ack_valid && en && (dc <= da) && (da <= dn);", "wire        ack_ok = ack_valid && en;", "stale / forged ACKs must be ignored"),
 ("rx_dup_inorder",   "sf_rdma_rx.sv", "end else if (dup) begin", "end else if (1'b0) begin", "a duplicate request must never be applied twice"),
 ("rx_no_rspok",      "sf_rdma_rx.sv", "            2'd0: begin  // WRITE\n              if (rsp_ok) begin", "            2'd0: begin  // WRITE\n              if (1'b1) begin", "no memory write without a registry grant"),
 ("rx_no_lencheck",   "sf_rdma_rx.sv", "end else if (mlen > rq_len) begin", "end else if (1'b0) begin", "an incoming message longer than the receive buffer must be refused"),
 ("rx_no_rnr",        "sf_rdma_rx.sv", "if (!rq_valid) begin", "if (1'b0) begin", "a SEND with no receive WQE must get RNR, not garbage"),
 ("rx_resp_offset",   "sf_rdma_rx.sv", "(moff == rr_exp_off) && ", "", "READ responses must arrive in order at the expected offset"),
 ("rx_accept_on_fault","sf_rdma_rx.sv", "                cmd_kind = 2'd2; ag_fatal_set = 1'b1; ag_fatal_code = `SFR_NAK_ACC;", "                cmd_kind = 2'd2; ag_fatal_set = 1'b1; ag_fatal_code = `SFR_NAK_ACC; do_accept = 1'b1;", "a refused request must not advance accept_next"),
 ("rdgen_no_fence",   "sf_rdma_rdgen.sv", "wire        fence_ok = !fence_d[23];", "wire        fence_ok = 1'b1;", "read-after-write fence (spec 7.3)"),
 ("ag_commit_eq_accept","sf_rdma_ackgen.sv", "wire [23:0] c24  = cpsn;", "wire [23:0] c24  = epsn;", "an ACK must report the COMMIT frontier, not the accept frontier"),
 ("ag_fatal_early",   "sf_rdma_ackgen.sv", "wire fatal_ready = fatal_pend && !resp_err && (cpsn == epsn);", "wire fatal_ready = fatal_pend && !resp_err;", "a fatal NAK waits until every earlier request has committed"),
 ("ad_no_epoch",      "sf_rdma_transport_adapter.sv", "f_epoch    <= (hepoch != cfg_epoch);", "f_epoch    <= 1'b0;", "frames of an old connection incarnation must be dropped"),
 ("ad_no_ethertype",  "sf_rdma_transport_adapter.sv", "f_etype    <= (etype != `SFR_ETHERTYPE);", "f_etype    <= 1'b0;", "a frame with the wrong EtherType must be dropped"),
 ("ad_no_lencheck",   "sf_rdma_transport_adapter.sv", "end_len_bad = !r_hdr_done || (tot_bytes != exp_len);", "end_len_bad = !r_hdr_done;", "a frame whose length contradicts its header must be dropped"),
 ("ad_ignore_macerr", "sf_rdma_transport_adapter.sv", "else if (rx_err || f_force)     why[2] = 1'b1;", "else if (f_force)     why[2] = 1'b1;", "a frame flagged bad by the MAC must never be committed"),
 ("dw_first_offset",  "sf_rdma_dma_wr.sv", "wire [31:0]  pn32     = first_out ? pn_first : pn_rest;", "wire [31:0]  pn32     = pn_rest;", "unaligned destination: partial first word strobes"),
 ("dr_unaligned_addr","sf_rdma_dma_rd.sv", "iss_addr  <= {c_pa[PA_W-1:LB], {LB{1'b0}}};", "iss_addr  <= c_pa;", "memory reads are word aligned"),
 ("rx_no_flush_rq",   "sf_rdma_rx.sv", "wire         flush_rq   = flush_en && !cur_valid && !fsm_cqe && rq_valid && (st == S_DISP) && ring_empty;", "wire         flush_rq   = 1'b0;", "unconsumed receive WQEs must be flushed when the QP errs"),

 # ---- guards of the fixes made after the independent review (docs/REVIEW_FINDINGS.md): each must be noticed by the review scenarios / chaos / invariants
 ("retry_nak_swallowed", "sf_rdma_retry.sv", "end else if ((expire && !progress) || nak_retry) begin", "end else if (!progress && (expire || nak_retry)) begin", "F-03: a SEQ_ERR NAK in a progress cycle must still start go-back-N"),
 ("retry_rnr_swallowed", "sf_rdma_retry.sv", "          if (rnr_nak) begin\n            if (nc_b == cfg_rnr_max)", "          if (rnr_nak && !progress) begin\n            if (nc_b == cfg_rnr_max)", "F-03: an RNR NAK in a progress cycle must still start the back-off"),
 ("req_chi_overwrite",   "sf_rdma_requester.sv", "if (!psn_le(una + 24'd1, chi_n)) chi_n = una + 24'd1;", "if (!psn_le(una + 24'd1, chi)) chi_n = una + 24'd1;", "F-07: the retire fix-up must not overwrite an ACK's frontier update"),
 ("req_txp_noclamp",     "sf_rdma_requester.sv", "if (psn_lt(txp_n, una + 24'd1)) txp_n = una + 24'd1;", "", "S-01: txp may never fall below una (needs the random suites)"),
 ("req_fatal_disarm",    "sf_rdma_requester.sv", "wire          armed = en && (una != nxt) && (txp != una) && !(err_pending && (una == err_psn));", "wire          armed = en && !err_pending && (una != nxt) && (txp != una);", "F-01: after a fatal NAK the timer keeps protecting the earlier entries"),
 ("req_fatal_notx",      "sf_rdma_requester.sv", "(!err_pending || psn_lt(txp, err_psn));", "(!err_pending);", "F-01: after a fatal NAK the earlier entries are still retransmitted"),
 ("req_fatal_txall",     "sf_rdma_requester.sv", "(!err_pending || psn_lt(txp, err_psn));", "1'b1;", "F-01: after a fatal NAK nothing at or after the failed PSN is retransmitted"),
 ("req_lerr_off",        "sf_rdma_requester.sv", "wire          lerr_ok     = en && !flush_en && !err_sent && (lerr_tx_valid || lerr_pl_valid) &&", "wire          lerr_ok     = 1'b0 && (lerr_tx_valid || lerr_pl_valid) &&", "F-04: a memory error on a source read must fail the WQE LOC_OP_ERR"),
 ("req_flush_nogate",    "sf_rdma_requester.sv", "wire          do_flush_ctx = flush_en && !w_empty && dma_quiet;", "wire          do_flush_ctx = flush_en && !w_empty;", "F-06: a flushed WQE's grant is not released while its DMA is in flight"),
 ("rx_flush_early",      "sf_rdma_rx.sv", "wire         flush_cur  = flush_en && cur_valid && !fsm_cqe && ring_empty;", "wire         flush_cur  = flush_en && cur_valid && !fsm_cqe;", "F-02/F-06: flush completions wait until every older message committed"),
 ("rx_no_read_skip",     "sf_rdma_rx.sv", "wire         ring_ready = !ring_empty && (c_done[cp_i] || (flush_en && c_isrd[cp_i]));", "wire         ring_ready = !ring_empty && c_done[cp_i];", "F-05: a READ that can never execute must not block the commit ring in ERR"),
 ("rx_werr_ignored",     "sf_rdma_rx.sv", "if (dw_done_err) c_err[tg_idx] <= 1'b1; end", "end", "F-04: a write acknowledged with an error must not complete the RECV OK"),
 ("rx_fsm_cqe_early",    "sf_rdma_rx.sv", "        if (cmp_ready && ring_empty) begin", "        if (cmp_ready) begin", "RQ order: the FSM's error CQE waits for older messages"),
 ("ad_no_poison",        "sf_rdma_transport_adapter.sv", "wire         s_poison = (s_need != 32'd0) && pz_head[sel_port];", "wire         s_poison = 1'b0;", "F-04: a frame whose payload fetch failed must never be transmitted"),
 ("dr_no_pl_err",        "sf_rdma_dma_rd.sv", "assign pl_err   = err_acc || (gb_push && rf_err);", "assign pl_err   = 1'b0;", "F-04: the read engine must report a failed fetch"),
 ("ad_no_req_drop",      "sf_rdma_transport_adapter.sv", "wire         drop_cand = ((sel_port == 2'd0) && tx_drop_req) || ((sel_port != 2'd2) && s_poison);", "wire         drop_cand = ((sel_port != 2'd2) && s_poison);", "F-08: no request frame leaves after the QP entered ERR"),
 ("ad_drop_resp_in_err", "sf_rdma_transport_adapter.sv", "wire         drop_cand = ((sel_port == 2'd0) && tx_drop_req) || ((sel_port != 2'd2) && s_poison);", "wire         drop_cand = ((sel_port != 2'd2) && tx_drop_req) || ((sel_port != 2'd2) && s_poison);", "F-08 (regression found while fixing): responses to already committed READs must still go out after a fatal NAK"),
 ("ad_len_early",        "sf_rdma_transport_adapter.sv", "    if      (end_len_bad)           why[0] = 1'b1;               // runt / length rule", "    if      (f_len || end_len_bad)  why[0] = 1'b1;               // runt / length rule", "F-10: paylen > MTU is counted after the opcode check"),
]
def run(cmd, **kw): return subprocess.run(cmd, capture_output=True, text=True, **kw)
def build(workdir):
    r = run(["make", "-C", workdir, "out/tb_dw64_mtu256_w8", "OUT=out"]); return r.returncode == 0, (r.stdout + r.stderr)[-600:]
def suite(tb, specs, jobs, tag):
    """run every scenario set of `specs` (path[:checker]); returns the failing runs (scenario name) and a summary line"""
    fails = []; summ = []
    for n, spec in enumerate(specs):
        d, _, chk = spec.partition(":")
        r = run([sys.executable, os.path.join(ROOT, "scripts", "regress.py"), "--tb", tb, "--dir", d, "--jobs", str(jobs), "--tag", f"_{tag}{n}",
                 "--timeout", "60", "--checker", chk or "model", "--report", os.path.join(ROOT, "out", f"mut_{tag}{n}.md")])
        fails += [l.split()[1] for l in r.stdout.splitlines() if l.startswith("FAIL")]
        summ.append(r.stdout.strip().splitlines()[-1] if r.stdout.strip() else "no output")
    return sorted(fails), " | ".join(x.split("  ->")[0] for x in summ)
# scenario sets run for EVERY mutant: the directed suite and the review repros.  Some mutants can only be exposed by random traffic.
EXTRA = {"req_txp_noclamp": ["out/rand_1", "out/rand_2", "out/rand_3", "out/rand_4"]}
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--only", default=""); ap.add_argument("--list", action="store_true")
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--dir", default=",".join([os.path.join(ROOT, "tests", "rdma", "scenarios"), os.path.join(ROOT, "tests", "rdma", "review")]), help="comma separated scenario sets (path[:chaos])")
    a = ap.parse_args()
    if a.list:
        for m in M: print(f"{m[0]:20s} {m[1]:32s} {m[4]}")
        return 0
    sel = [m for m in M if not a.only or m[0] in a.only.split(",")]
    base = os.path.join(ROOT, "out", "mut"); os.makedirs(base, exist_ok=True)
    def stage(mid):
        w = os.path.join(base, mid); shutil.rmtree(w, ignore_errors=True); os.makedirs(os.path.join(w, "out"))
        shutil.copytree(os.path.join(ROOT, "rtl"), os.path.join(w, "rtl"))
        for n in ("third_party", "tests", "scripts", "Makefile"):
            os.symlink(os.path.join(ROOT, n), os.path.join(w, n))
        return w
    w = stage("_baseline"); ok, log = build(w)
    if not ok: print("baseline build failed\n" + log); return 2
    dirs = a.dir.split(",")
    bfails, bsum = suite(os.path.join(w, "out", "tb_dw64_mtu256_w8"), dirs, a.jobs, "base")
    xdirs = sorted({d for v in EXTRA.values() for d in v if os.path.isdir(d)}); xfails, xsum = suite(os.path.join(w, "out", "tb_dw64_mtu256_w8"), xdirs, a.jobs, "basex") if xdirs else ([], "")
    bfails = sorted(set(bfails) | set(xfails))
    print(f"baseline: {bsum} {xsum}  ({len(bfails)} failing runs; kills are judged against this set)")
    rows = []
    for mid, f, old, new, why in sel:
        t0 = time.time(); w = stage(mid); p = os.path.join(w, "rtl", f); s = open(p).read()
        if s.count(old) != 1: rows.append((mid, f, why, "INVALID", f"pattern found {s.count(old)}x")); print(f"{mid:20s} INVALID ({s.count(old)} matches)"); continue
        open(p, "w").write(s.replace(old, new)); ok, log = build(w)
        if not ok: rows.append((mid, f, why, "KILLED", "does not compile / elaborate")); print(f"{mid:20s} KILLED (build fails)"); continue
        fails, summ = suite(os.path.join(w, "out", "tb_dw64_mtu256_w8"), dirs + [d for d in EXTRA.get(mid, []) if os.path.isdir(d)], a.jobs, mid)
        new_f = sorted(set(fails) - set(bfails)); gone = sorted(set(bfails) - set(fails))
        st = "KILLED" if (new_f or gone) else "SURVIVED"
        by = ", ".join(new_f[:3]) + (f" (+{len(new_f)-3})" if len(new_f) > 3 else "") if new_f else (f"fixed baseline fails: {gone[:2]}" if gone else "")
        rows.append((mid, f, why, st, by)); print(f"{mid:20s} {st:9s} {len(new_f):3d} new failing runs  [{time.time()-t0:.0f}s]  {by[:80]}")
        shutil.rmtree(os.path.join(base, mid), ignore_errors=True)
    k = sum(r[3] == "KILLED" for r in rows); v = sum(r[3] != "INVALID" for r in rows)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    # a PARTIAL run (--only) must never overwrite the report of the full campaign
    rep_path = os.path.join(ROOT, "out", "mutation_partial.md") if a.only else os.path.join(ROOT, "reports", "mutation.md")
    with open(rep_path, "w") as o:
        o.write(f"# Simulation mutation testing\n\nBaseline: {bsum} ({len(bfails)} failing runs).  **{k} / {v} mutants killed**, {sum(r[3]=='SURVIVED' for r in rows)} survived, {sum(r[3]=='INVALID' for r in rows)} invalid.\n\n")
        o.write("| mutant | file | what a correct suite must notice | result | first scenarios that caught it |\n|---|---|---|---|---|\n")
        for r in rows: o.write(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} | {r[4]} |\n")
    print(f"{k}/{v} killed -> {os.path.relpath(rep_path, ROOT)}"); return 0
sys.exit(main())
