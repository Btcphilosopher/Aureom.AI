#!/usr/bin/env python3
"""Expectation checker for DIRECTED scenarios whose outcome the op-level reference model cannot predict (frame-level interleavings, injected
memory errors, forced errors at exact cycles).  A scenario X.scn with a sibling X.expect is verified against exactly the outcomes listed
there instead of the model; every scenario without one still goes through tests/rdma/model/check_results.py.

  check_expect.py scenario.scn result.res scenario.expect          exit 0 = every expectation holds and no bench monitor fired

Grammar (one directive per line, '#' starts a comment):
  tb fi                              run on the bench built with the simulation-only fault injection (make build-fi)       [read by regress.py]
  args +GUARD_WR_N=2                 extra bench arguments                                                                    [read by regress.py]
  sq  <ep> <wr_id>:<STATUS> ...      the send-queue completions (op != RECV) of <ep>, EXACTLY this list, in this order
  rq  <ep> <wr_id>:<STATUS> ...      the RECV completions of <ep>, exactly this list, in this order
  qpst <ep> <STATE>[/<cause>]        final QP state (RESET INIT RTR RTS ERR) and optionally the error cause number
  cnt <ep> <counter> <op> <value>    performance counter comparison, op in == != >= <= > <
  dump <ep> <i> <j> eq|ne            the i-th and j-th DUMP of <ep> (1-based, -1 = last) are equal / differ
  dump_absent <ep> <i> <hex>         the i-th dump does not contain this byte pattern
  cqe_after_memw <ep> <wr_id>        the CQE of <wr_id> at <ep> is produced AFTER the last memory write of <ep> (the buffer is handed back only when no DMA can still write into it)
  cfg <ep> <CMD> key=value ...       some CFG record of <ep> has this command and these fields (e.g. status=2)
  note present|absent <text>         a NOTE line containing <text> exists / does not exist
Status names are those of spec section 13 (OK, WR_FLUSH_ERR, LOC_OP_ERR, RETRY_EXC_ERR, ...)."""
import operator, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tests", "rdma", "model"))
from scn import CQE_STATUS, CQE_OP, QP_STATES   # noqa: E402  (names <-> codes, the same tables the reference model uses)

OPS = {"==": operator.eq, "!=": operator.ne, ">=": operator.ge, "<=": operator.le, ">": operator.gt, "<": operator.lt}

def kv(tokens):
    return dict(t.split("=", 1) for t in tokens if "=" in t)

def main():
    scn, res, exp = sys.argv[1:4]
    memw = {"A": [], "B": []}; cqe_cyc = {}
    cqes = {"A": [], "B": []}; qpst = {}; cnt = {"A": {}, "B": {}}; dumps = {"A": [], "B": []}; cfgs = []; notes = []; end = {}
    for l in open(res):
        t = l.split()
        if not t: continue
        d = kv(t[1:])
        if t[0] == "CQE": cqes[d["ep"]].append((int(d["wr_id"]), int(d["op"]), int(d["status"]))); cqe_cyc[(d["ep"], int(d["wr_id"]))] = int(d["cyc"])
        elif t[0] == "MEMW": memw[d["ep"]].append(int(d["cyc"]))
        elif t[0] == "QPST": qpst[d["ep"]] = (int(d["state"]), int(d["cause"]))
        elif t[0] == "CNT": cnt[d["ep"]][d["name"]] = int(d["value"])
        elif t[0] == "DUMP": dumps[d["ep"]].append(d["hex"])
        elif t[0] == "CFG": cfgs.append((d["ep"], d["cmd"], d))
        elif t[0] == "NOTE": notes.append(l.strip())
        elif t[0] == "END": end = d
    bad = []
    if end.get("monitor_errors", "0") != "0": bad.append("bench monitor errors: %s" % end.get("monitor_errors"))
    if end.get("timeout", "0") != "0": bad.append("bench timeout")
    stat_name = {v: k for k, v in CQE_STATUS.items()}
    for n, raw in enumerate(open(exp), 1):
        line = raw.split("#", 1)[0].strip()
        if not line: continue
        t = line.split(); k = t[0]
        try:
            if k in ("tb", "args"):
                continue
            elif k in ("sq", "rq"):
                ep = t[1]
                want = [(int(a.split(":")[0]), CQE_STATUS[a.split(":")[1]]) for a in t[2:]]
                got = [(w, s) for (w, o, s) in cqes[ep] if (o == CQE_OP["RECV"]) == (k == "rq")]
                if got != want:
                    f = lambda L: " ".join("%d:%s" % (w, stat_name.get(s, s)) for w, s in L) or "(none)"
                    bad.append("line %d: %s %s CQEs: got [%s], expected [%s]" % (n, k, ep, f(got), f(want)))
            elif k == "qpst":
                ep = t[1]; st, _, cause = t[2].partition("/")
                g = qpst.get(ep)
                if g is None:
                    bad.append("line %d: no QPST record for %s" % (n, ep)); continue
                gname = QP_STATES[g[0]] if g[0] < len(QP_STATES) else ("DRAIN" if g[0] == 5 else str(g[0]))
                if gname != st:
                    bad.append("line %d: QP %s state: got %s, expected %s" % (n, ep, gname, st))
                elif cause and g[1] != int(cause):
                    bad.append("line %d: QP %s error cause: got %d, expected %s" % (n, ep, g[1], cause))
            elif k == "cnt":
                ep, name, op, val = t[1], t[2], t[3], int(t[4], 0)
                g = cnt[ep].get(name)
                if g is None: bad.append("line %d: counter %s/%s not in the result file" % (n, ep, name))
                elif not OPS[op](g, val): bad.append("line %d: counter %s %s = %d, expected %s %d" % (n, ep, name, g, op, val))
            elif k in ("dump", "dump_absent"):
                ep = t[1]; L = dumps[ep]
                idx = lambda s: (len(L) + int(s)) if int(s) < 0 else int(s) - 1
                if k == "dump":
                    i, j = idx(t[2]), idx(t[3])
                    if not (0 <= i < len(L) and 0 <= j < len(L)): bad.append("line %d: %s has only %d dump(s)" % (n, ep, len(L)))
                    elif (L[i] == L[j]) != (t[4] == "eq"):
                        nd = sum(1 for a in range(0, min(len(L[i]), len(L[j])), 2) if L[i][a:a + 2] != L[j][a:a + 2])
                        bad.append("line %d: dumps %s/%s of %s are %s, expected %s (%d byte(s) differ)" % (n, t[2], t[3], ep, "equal" if L[i] == L[j] else "different", t[4], nd))
                else:
                    i = idx(t[2])
                    if not (0 <= i < len(L)): bad.append("line %d: %s has only %d dump(s)" % (n, ep, len(L)))
                    elif t[3].lower() in L[i].lower(): bad.append("line %d: dump %s of %s contains the forbidden pattern %s" % (n, t[2], ep, t[3]))
            elif k == "cqe_after_memw":
                ep, wr = t[1], int(t[2])
                if (ep, wr) not in cqe_cyc: bad.append("line %d: no CQE for wr_id %d at %s" % (n, wr, ep))
                elif memw[ep] and max(memw[ep]) >= cqe_cyc[(ep, wr)]:
                    bad.append("line %d: the CQE of wr_id %d at %s (cycle %d) precedes the last memory write (cycle %d): the buffer was handed back while a DMA could still write into it" % (n, wr, ep, cqe_cyc[(ep, wr)], max(memw[ep])))
            elif k == "cfg":
                ep, cmd, want = t[1], t[2], kv(t[3:])
                if not any(e == ep and c == cmd and all(d.get(a) == b for a, b in want.items()) for e, c, d in cfgs):
                    bad.append("line %d: no CFG %s %s with %s (have: %s)" % (n, ep, cmd, want, [d for e, c, d in cfgs if e == ep and c == cmd][:3]))
            elif k == "note":
                text = " ".join(t[2:]); has = any(text in x for x in notes)
                if (t[1] == "present") != has: bad.append("line %d: NOTE '%s' is %s" % (n, text, "present" if has else "absent"))
            else:
                bad.append("line %d: unknown directive '%s'" % (n, k))
        except (KeyError, IndexError, ValueError) as e:
            bad.append("line %d: cannot evaluate '%s' (%s: %s)" % (n, line, type(e).__name__, e))
    if bad:
        print("FAIL (%d expectation(s) violated)" % len(bad))
        for b in bad: print("  MISMATCH: " + b)
        return 1
    print("PASS (expectations of %s)" % os.path.basename(exp))
    return 0

sys.exit(main())
