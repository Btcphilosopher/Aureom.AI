#!/usr/bin/env python3
"""Vendored-IP integrity check.

  scripts/check_vendor.py                 verify third_party/ against third_party/MANIFEST.sha256
  scripts/check_vendor.py --repo <root>   ALSO compare every vendored file with the ORIGINAL inside the SilicaFlux repository archives
  scripts/check_vendor.py --write         (re)generate the manifest from the current files
"""
import argparse, hashlib, os, sys, zipfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TP = os.path.join(ROOT, "third_party")
MAN = os.path.join(TP, "MANIFEST.sha256")
SRC25 = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5"
# vendored file -> (archive relative to repo root, member path inside the archive)
ORIGIN = {
  "sfb_skid_buffer.sv":      (f"{SRC25}/silicaflux-datafabric.zip",           "silicaflux-datafabric/rtl/interconnect/sfb_skid_buffer.sv"),
  "sf_rr_arb.sv":            (f"{SRC25}/silicaflux-p40-floorplanbuild.zip",   "silicaflux-p40/rtl/common/sf_rr_arb.sv"),
  "sf_stream_dma_align.sv":  (f"{SRC25}/silicaflux-streamdma-p103-r2.zip",    "silicaflux-streamdma-p103/rtl/stream_dma/sf_stream_dma_align.sv"),
}
PC_ARCHIVE = f"{SRC25}/silicaflux-packetcore-p62.zip"
def sha(b): return hashlib.sha256(b).hexdigest()
def files():
    for d, _, fs in os.walk(TP):
        for f in sorted(fs):
            if f == "MANIFEST.sha256": continue
            p = os.path.join(d, f); yield os.path.relpath(p, TP), p
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--repo"); ap.add_argument("--write", action="store_true"); a = ap.parse_args()
    cur = {r: sha(open(p, "rb").read()) for r, p in files()}
    if a.write:
        with open(MAN, "w") as f:
            for r in sorted(cur): f.write(f"{cur[r]}  {r}\n")
        print(f"manifest written ({len(cur)} files)"); return 0
    bad = 0
    man = {l.split("  ", 1)[1].strip(): l.split("  ", 1)[0] for l in open(MAN) if l.strip()}
    for r in sorted(set(man) | set(cur)):
        if man.get(r) != cur.get(r): print(f"MANIFEST MISMATCH  {r}"); bad += 1
    if a.repo:
        for r, (arc, mem) in ORIGIN.items():
            z = zipfile.ZipFile(os.path.join(a.repo, arc)); o = sha(z.read(mem))
            ok = (o == cur[r]); print(("IDENTICAL " if ok else "DIFFERENT ") + f"{r}  <- {arc}:{mem}"); bad += (not ok)
        z = zipfile.ZipFile(os.path.join(a.repo, PC_ARCHIVE)); names = set(z.namelist())
        for r in sorted(cur):
            if not r.startswith("packetcore-p62/"): continue
            sub = r[len("packetcore-p62/"):]
            inner = "silicaflux-packetcore-p62/" + ("rtl/" + sub[4:] if sub.startswith("rtl/") else "third_party/silicaflux-reused/" + sub[len("reused/"):])
            if inner not in names: print(f"MISSING in archive  {inner}"); bad += 1; continue
            ok = sha(z.read(inner)) == cur[r]; bad += (not ok)
            if not ok: print(f"DIFFERENT {r}")
        print("packetcore-p62: all files compared" if not bad else "")
    print("vendor check:", "OK" if not bad else f"{bad} problem(s)"); return 1 if bad else 0
sys.exit(main())
