#!/usr/bin/env python3
"""RDMAEngine formal driver: Yosys -> SMT2 -> yosys-smtbmc + z3  (Project 113).

    scripts/formal.py [--only NAME ...] [--jobs N] [--list] [--mutants] [--mutants-only]

Job kinds
   comb   purely combinational harness: the depth-1 check is a complete proof for ALL inputs        (PASSED = PROVED)
   prove  k-induction: base case from reset + induction step                                          (PASSED = PROVED, UNBOUNDED)
   bmc    bounded model check from reset to DEPTH cycles                                              (PASSED = BOUNDED to depth, NOT an unbounded proof)
   vac    reachability witness: the stated assertion MUST FAIL                                       (FAILED = WITNESSED: the situation is reachable)
   mut    the harness run (BMC) on a COPY of the RTL with one planted defect: it MUST FAIL            (FAILED = KILLED)
Results: reports/formal.md, reports/formal.json, reports/formal_mutants.md.   Work area: out/formal/ (nothing is written elsewhere).
rtl/ and third_party/ are READ-ONLY: mutants are applied to copies under out/formal/mut_*/.

Flow per job (see formal/rdma/README.md):
   read_verilog -sv -formal -DFORMAL; hierarchy -top <harness> -chparam ..; proc; flatten; connect -set <obs>; prep; async2sync; dffunmap;
   write_smt2 -wires; yosys-smtbmc -s z3 --unroll [-i] -t DEPTH
   * the RTL uses an ASYNC active-low reset: async2sync makes it a synchronous model; the harness holds reset in cycle 0 only.
   * `--unroll` is essential: without it z3 4.8 does not terminate even on the depth-1 check of the registry.
   * harness comments of the form   `// OBS <harness_wire> <flattened.path.to.dut.signal> [?PARAM=value]`   export an INTERNAL DUT register to the harness
     (hierarchical references are not supported by Yosys 0.33).  They are used ONLY inside inductive-strengthening lemmas.
"""
import argparse, json, os, re, shutil, signal, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
FV = os.path.join(ROOT, "formal", "rdma")
OUT = os.path.join(ROOT, "out", "formal")
Z3_TIMEOUT = 600      # seconds, hard wall-clock limit per job
MUT_TIMEOUT = 420

# harness group -> (top module, RTL files (searched in rtl/ then third_party/), harness files)
FIFO = "sf_rdma_fifo.sv"
GROUPS = {
  "retry":      ("fv_retry",      ["sf_rdma_retry.sv"], ["fv_retry.sv"]),
  "completion": ("fv_completion", ["sf_rdma_completion.sv"], ["fv_completion.sv"]),
  "wqe":        ("fv_wqe",        ["sf_rdma_wqe.sv"], ["fv_wqe.sv"]),
  "registry":   ("fv_registry",   ["sf_rdma_memory_registry.sv"], ["fv_registry.sv"]),
  "ackgen":     ("fv_ackgen",     ["sf_rdma_ackgen.sv"], ["fv_ackgen.sv"]),
  "dma_wr":     ("fv_dma_wr",     [FIFO, "sf_rdma_dma_wr.sv", "sf_stream_dma_align.sv"], ["fv_dma_wr.sv"]),
  "dma_rd":     ("fv_dma_rd",     [FIFO, "sf_rdma_dma_rd.sv", "sf_stream_dma_align.sv"], ["fv_dma_rd.sv"]),
  "rx":         ("fv_rx_safety",  [FIFO, "sf_rdma_rx.sv"], ["fv_rx_safety.sv"]),
  "requester":  ("fv_requester",  ["sf_rdma_retry.sv", "sf_rdma_requester.sv"], ["fv_requester.sv"]),
  "psn":        ("fv_psn",        [FIFO, "sf_rdma_rx.sv"], ["fv_psn.sv"]),
}

JOBS = []
def J(name, kind, group, params, depth, claim, timeout=Z3_TIMEOUT):
    JOBS.append(dict(name=name, kind=kind, group=group, params=params, depth=depth, claim=claim, timeout=timeout))

import formal_jobs      # the job table (kept in its own file so this driver stays small)
formal_jobs.define(J)
import formal_mutants as MU


def locate(rtl_root, fname):
    for d in ("rtl", "third_party"):
        p = os.path.join(rtl_root, d, fname)
        if os.path.exists(p): return p
    raise FileNotFoundError(fname)


def flow(group, params, rtl_root, work, name):
    """Yosys front end; returns (CompletedProcess, smt2 path)."""
    top, rfiles, ffiles = GROUPS[group]
    hfiles = [os.path.join(FV, f) for f in ffiles]
    chp = " ".join(f"-chparam {k} {v}" for k, v in params.items())
    obs = []
    for hf in hfiles:
        for m in re.finditer(r"//\s*OBS\s+(\S+)\s+(\S+)(?:\s+\?(\w+)=(\w+))?", open(hf).read()):
            if m.group(3) and str(params.get(m.group(3))) != m.group(4): continue      # conditional OBS: `?PARAM=value`
            obs.append(f"connect -set {m.group(1)} {m.group(2)}")
    files = " ".join([locate(rtl_root, f) for f in rfiles] + hfiles)
    smt = os.path.join(work, name + ".smt2")
    incs = f"-I{os.path.join(rtl_root, 'rtl')} -I{os.path.join(rtl_root, 'third_party')}"
    ys = (f"read_verilog -sv -formal -DFORMAL {incs} {files}; hierarchy -check -top {top} {chp}; proc; flatten; "
          + "; ".join(obs) + ("; " if obs else "") +
          f"prep -top {top}; async2sync; dffunmap; opt_clean; write_smt2 -wires {smt}")
    r = subprocess.run(["yosys", "-q", "-p", ys], capture_output=True, text=True, cwd=work)
    return r, smt


def err_tail(r):
    ls = [l for l in (r.stdout + r.stderr).splitlines() if "ERROR" in l or "rror:" in l]
    return (ls[-1] if ls else (r.stdout + r.stderr)[-200:]).replace(ROOT + "/", "")[-300:]


def run_cmd(cmd, timeout, cwd):
    """run with a hard wall-clock limit; the whole process group is killed on expiry"""
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=cwd, start_new_session=True)
    try:
        out, _ = p.communicate(timeout=timeout)
        return out, False
    except subprocess.TimeoutExpired:
        try: os.killpg(p.pid, signal.SIGKILL)
        except ProcessLookupError: pass
        out, _ = p.communicate()
        return out or "", True


def smtbmc(induct, smt, depth, timeout, work, name):
    cmd = ["yosys-smtbmc", "-s", "z3", "--unroll", "--noprogress"] + (["-i"] if induct else []) + ["-t", str(depth), smt]
    out, to = run_cmd(cmd, timeout, work)
    out = out.replace("\r", "\n")
    open(os.path.join(work, name + ".log"), "w").write(out)
    if to: return "TIMEOUT", "timeout after %ds" % timeout
    m = re.findall(r"Status: (\w+)", out)
    st = m[-1] if m else "UNKNOWN"
    det = ""
    if "Temporal induction failed" in out: st = "INDUCTION-FAILED"
    mm = re.search(r"Assert failed in ([^\n]*)", out)
    if mm: det = re.sub(r"\(\$assert[^)]*\)", "", mm.group(1)).replace(ROOT + "/", "").strip()
    mm = re.findall(r"Checking assertions in step (\d+)", out)
    if st == "FAILED" and "BMC failed" in out and mm: det = (det + " @step " + mm[-1]).strip()
    if st == "PASSED" and induct:
        k = re.findall(r"Trying induction in step (\d+)", out)
        if k: det = "induction step k=%s" % k[-1]
    return st, det


def verdict(kind, st):
    if kind in ("comb", "prove"):
        return {"PASSED": "PROVED", "FAILED": "FAILED", "TIMEOUT": "UNKNOWN", "INDUCTION-FAILED": "UNKNOWN"}.get(st, "UNKNOWN")
    if kind == "bmc":
        return {"PASSED": "BOUNDED", "FAILED": "FAILED", "TIMEOUT": "UNKNOWN"}.get(st, "UNKNOWN")
    if kind == "vac":
        return {"FAILED": "WITNESSED", "PASSED": "NOT-REACHABLE", "TIMEOUT": "UNKNOWN"}.get(st, "UNKNOWN")
    return "UNKNOWN"


def run_job(j):
    os.makedirs(OUT, exist_ok=True)
    work = os.path.join(OUT, "job_" + j["name"]); shutil.rmtree(work, ignore_errors=True); os.makedirs(work)
    t0 = time.time()
    r, smt = flow(j["group"], j["params"], ROOT, work, j["name"])
    if r.returncode != 0:
        return dict(j, status="ERROR", result="ERROR", detail=err_tail(r), secs=round(time.time() - t0, 1))
    st, det = smtbmc(j["kind"] == "prove", smt, j["depth"], j["timeout"], work, j["name"])
    res = verdict(j["kind"], st)
    if res == "UNKNOWN" and st == "INDUCTION-FAILED": det = "induction step fails (not inductive at this depth)"
    secs = round(time.time() - t0, 1)
    if res in ("PROVED", "BOUNDED", "WITNESSED"):
        shutil.rmtree(work, ignore_errors=True)       # keep logs only of jobs that need a look
    return dict(j, status=st, result=res, detail=det, secs=secs)


def apply_mutant(m, dest):
    for d in ("rtl", "third_party"):
        shutil.copytree(os.path.join(ROOT, d), os.path.join(dest, d), ignore=shutil.ignore_patterns("packetcore-p62", "*.vlt"))
    p = os.path.join(dest, "rtl", m["file"])
    src = open(p).read()
    olds = m["old"] if isinstance(m["old"], list) else [m["old"]]
    news = m["new"] if isinstance(m["new"], list) else [m["new"]]
    for o, n in zip(olds, news):
        c = src.count(o)
        assert c >= 1, f"mutant {m['id']}: pattern not found in {m['file']}: {o[:60]!r}"
        want = m.get("count", 1)
        assert want == 0 or c >= want, f"mutant {m['id']}: pattern occurs {c} times"
        src = src.replace(o, n) if want == 0 else src.replace(o, n, want)
    open(p, "w").write(src)


def run_mutant(m):
    res = []
    jobs = {j["name"]: j for j in JOBS}
    for cj in m["catch"]:
        jn, _, dep = cj.partition(":")
        j = jobs[jn]
        work = os.path.join(OUT, f"mut_{m['id']}"); shutil.rmtree(work, ignore_errors=True); os.makedirs(work)
        apply_mutant(m, work)
        t0 = time.time()
        r, smt = flow(j["group"], j["params"], work, work, "m")
        if r.returncode != 0:
            res.append(dict(name="mut_" + m["id"], kind="mut", group=j["group"], mutant=m, caught_by=jn, status="ERROR", result="ERROR",
                            detail=err_tail(r), secs=round(time.time() - t0, 1), claim=m["desc"])); continue
        depth = int(dep) if dep else j["depth"]
        st, det = smtbmc(False, smt, depth, MUT_TIMEOUT, work, "m")
        rs = {"FAILED": "KILLED", "PASSED": "SURVIVED", "TIMEOUT": "UNKNOWN"}.get(st, "UNKNOWN")
        res.append(dict(name="mut_" + m["id"], kind="mut", group=j["group"], mutant=m, caught_by=jn, depth=depth, status=st, result=rs,
                        detail=det, secs=round(time.time() - t0, 1), claim=m["desc"]))
        if rs == "KILLED": shutil.rmtree(work, ignore_errors=True)
    return res


def clip(s, n=110): return s if len(s) <= n else s[:n - 1] + "..."


def write_reports(allr):
    rd = os.path.join(ROOT, "reports"); os.makedirs(rd, exist_ok=True)
    order = {j["name"]: i for i, j in enumerate(JOBS)}
    jr = sorted([x for x in allr if x["kind"] != "mut"], key=lambda x: order.get(x["name"], 10**6))
    mr = sorted([x for x in allr if x["kind"] == "mut"], key=lambda x: x["name"])
    ser = lambda x: {k: v for k, v in x.items() if k != "mutant"} | ({"mutant": {k: v for k, v in x["mutant"].items() if k in ("id", "file", "desc")}} if "mutant" in x else {})
    json.dump([ser(x) for x in jr + mr], open(os.path.join(rd, "formal.json"), "w"), indent=1)
    with open(os.path.join(rd, "formal.md"), "w") as f:
        f.write("# Formal verification results (RDMAEngine, Project 113)\n\n"
                "Yosys 0.33 -> SMT2 -> `yosys-smtbmc --unroll` + z3 4.8.12.  Regenerate: `scripts/formal.py --mutants`.  Details of what is and is not covered: `formal/rdma/README.md`.\n\n"
                "* **PROVED** = `comb` (all inputs, depth 1) or `prove` (k-induction: base case from reset + induction step) = UNBOUNDED for the stated instance and environment.\n"
                "* **BOUNDED d** = BMC from reset, no violation within d cycles; NOT an unbounded proof.  **UNKNOWN** = timeout or induction not closed (reported honestly).\n"
                "* **WITNESSED** = the assertion of a `vac` job failed as it must: the situation is reachable, so the passing jobs are not vacuous.\n"
                "* **KILLED** = a planted defect was caught (see `reports/formal_mutants.md`).\n\n"
                "| job | kind | harness | instance | depth | result | s | claim |\n|---|---|---|---|---:|---|---:|---|\n")
        for x in jr:
            res = x["result"]
            if res == "BOUNDED": res = f"BOUNDED {x['depth']}"
            inst = ", ".join(f"{k}={v}" for k, v in x["params"].items()) or "-"
            extra = f" ({x['detail']})" if x["detail"] and res not in ("PROVED",) and not res.startswith("BOUNDED") else ""
            f.write(f"| {x['name']} | {x['kind']} | {x['group']} | {inst} | {x['depth']} | **{res}**{extra} | {x['secs']} | {x['claim']} |\n")
        cnt = {}
        for x in jr: cnt[x["result"]] = cnt.get(x["result"], 0) + 1
        f.write("\nSummary: " + ", ".join(f"{k} {v}" for k, v in sorted(cnt.items())) + f"  ({len(jr)} jobs).\n")
        if mr:
            k = sum(1 for x in mr if x["result"] == "KILLED")
            f.write(f"\nMutation campaign: {k} / {len(mr)} planted defects KILLED (table: `reports/formal_mutants.md`).\n")
    if mr:
        with open(os.path.join(rd, "formal_mutants.md"), "w") as f:
            f.write("# Formal mutation campaign\n\nEach row: one textual substitution applied to a COPY of the RTL file (the original is never touched); the named harness job is\n"
                    "re-run (BMC) on the copy and MUST FAIL (KILLED).  A SURVIVED row would need investigation.\n\n"
                    "| id | file | defect | old text | new text | caught by | depth | result | s |\n|---|---|---|---|---|---|---:|---|---:|\n")
            esc = lambda s: s.replace("|", "\\|").replace("\n", " ")
            for x in mr:
                m = x["mutant"]
                o = m["old"] if isinstance(m["old"], str) else " ;; ".join(m["old"]); n = m["new"] if isinstance(m["new"], str) else " ;; ".join(m["new"])
                f.write(f"| {m['id']} | {m['file']} | {esc(m['desc'])} | `{esc(clip(o.strip(), 90))}` | `{esc(clip(n.strip(), 90))}` | {x['caught_by']} | {x.get('depth','')} | **{x['result']}** | {x['secs']} |\n")
            k = sum(1 for x in mr if x["result"] == "KILLED")
            f.write(f"\n{k} / {len(mr)} KILLED, {sum(1 for x in mr if x['result']=='SURVIVED')} SURVIVED, {sum(1 for x in mr if x['result'] not in ('KILLED','SURVIVED'))} other.\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*", help="job names (or mutant ids)")
    ap.add_argument("--jobs", type=int, default=2, help="parallel jobs (the machine is shared: keep <= 2)")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--mutants", action="store_true", help="also run the mutation campaign")
    ap.add_argument("--mutants-only", action="store_true")
    a = ap.parse_args()
    if a.list:
        for j in JOBS: print(f"{j['name']:26} {j['kind']:6} {j['group']:11} depth={j['depth']:<3} {j['params']} - {j['claim']}")
        for m in MU.MUTANTS: print(f"{'mut_' + m['id']:26} mut    {m['catch']} - {m['desc']}")
        return 0
    os.makedirs(OUT, exist_ok=True)
    jobs = [] if a.mutants_only else [j for j in JOBS if (not a.only or j["name"] in a.only)]
    sel = lambda m: (a.only is None and (a.mutants or a.mutants_only)) or (a.only is not None and (m["id"] in a.only or "mut_" + m["id"] in a.only)) or (a.mutants_only and not a.only)
    muts = [m for m in MU.MUTANTS if sel(m)]
    results = []
    with ThreadPoolExecutor(max(1, min(a.jobs, 2))) as ex:
        futs = [ex.submit(run_job, j) for j in jobs] + [ex.submit(run_mutant, m) for m in muts]
        for fu in as_completed(futs):
            r = fu.result()
            for x in (r if isinstance(r, list) else [r]):
                results.append(x)
                print(f"{x['result']:13} {x['name']:26} {x['secs']:7.1f}s  {x.get('detail','')[:100]}", flush=True)
    prev = {}
    jp = os.path.join(ROOT, "reports", "formal.json")
    if os.path.exists(jp) and (a.only or a.mutants_only):
        mm = {m["id"]: m for m in MU.MUTANTS}
        for x in json.load(open(jp)):
            if x["kind"] == "mut":
                m = mm.get(x["name"][4:])
                if m is None or x.get("caught_by") != m["catch"][0].partition(":")[0]: continue        # stale result of an older definition
                x["mutant"] = dict(m)
            prev[x["name"]] = x
    for x in results: prev[x["name"]] = x
    names = {j["name"] for j in JOBS}; ids = {"mut_" + m["id"] for m in MU.MUTANTS}
    allr = [x for x in prev.values() if (x["kind"] != "mut" and x["name"] in names) or (x["kind"] == "mut" and x["name"] in ids and "mutant" in x)]
    write_reports(allr)
    bad = [x for x in results if x["result"] in ("FAILED", "ERROR", "SURVIVED", "NOT-REACHABLE", "UNKNOWN")]
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
