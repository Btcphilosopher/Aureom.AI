#!/usr/bin/env python3
"""Run the scenario suite against several PARAMETERISATIONS of the engine (data width, MTU, window, max outstanding reads).

For every configuration: build the bench variant (make DW=.. MTU=.. WINDOW=.. MAX_RD=..), copy the scenarios with the `build` line rewritten so the
independent model assumes the same parameters, and run scripts/regress.py on that copy.  Results: reports/regression_matrix.md
  scripts/regress_matrix.py [--seeds 1,2] [--random N]   (--random N also runs N seeds of the random generator per configuration)
"""
import argparse, glob, os, re, shutil, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIGS = [  # dw, mtu, window, max_rd
    (64, 256, 8, 2), (32, 256, 8, 2), (128, 256, 8, 2), (64, 64, 8, 2), (64, 128, 8, 2), (64, 512, 8, 2), (64, 1024, 8, 2),
    (64, 256, 4, 2), (64, 256, 16, 2), (64, 256, 2, 1), (64, 256, 8, 4), (32, 64, 4, 1), (128, 1024, 16, 4), (32, 1024, 2, 2),
]
def sh(cmd, **kw): return subprocess.run(cmd, capture_output=True, text=True, **kw)
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seeds", default="1"); ap.add_argument("--random", type=int, default=0)
    ap.add_argument("--only", default=""); a = ap.parse_args()
    rows = []; t0 = time.time()
    for dw, mtu, w, rd in CONFIGS:
        tag = f"dw{dw}_mtu{mtu}_w{w}"
        if a.only and a.only not in tag + f"_rd{rd}": continue
        r = sh(["make", "-C", ROOT, f"DW={dw}", f"MTU={mtu}", f"WINDOW={w}", f"MAX_RD={rd}", f"TAG={tag}_rd{rd}", f"out/tb_{tag}_rd{rd}"])
        if r.returncode: print(f"BUILD FAIL {tag}\n{r.stderr[-800:]}"); rows.append((dw, mtu, w, rd, "BUILD FAIL", "")); continue
        sd = os.path.join(ROOT, "out", "matrix", tag + f"_rd{rd}"); shutil.rmtree(sd, ignore_errors=True); os.makedirs(sd)
        srcs = glob.glob(os.path.join(ROOT, "tests", "rdma", "scenarios", "*.scn"))
        if mtu != 256:      # hand-crafted wire frames in these scenarios are sized around MTU 256 (a 'too long' frame is legal at a larger MTU)
            srcs = [x for x in srcs if not os.path.basename(x).startswith(("t084_", "t088_"))]
        for f in srcs:
            txt = open(f).read()
            def fix(m):
                line = m.group(0)
                for k, v in (("dw", dw), ("mtu", mtu), ("window", w), ("max_rd", rd)):
                    line = re.sub(rf"\b{k}=\d+", f"{k}={v}", line) if re.search(rf"\b{k}=", line) else line + f" {k}={v}"
                return line
            txt = re.sub(r"^build .*$", fix, txt, flags=re.M)
            open(os.path.join(sd, os.path.basename(f)), "w").write(txt)
        p = sh([sys.executable, os.path.join(ROOT, "scripts", "regress.py"), "--tb", os.path.join(ROOT, "out", f"tb_{tag}_rd{rd}"), "--dir", sd,
                "--seeds", a.seeds, "--jobs", "3", "--tag", f"_m_{tag}_rd{rd}", "--report", os.path.join(ROOT, "out", f"matrix_{tag}_rd{rd}.md")])
        summ = p.stdout.strip().splitlines()[-1] if p.stdout.strip() else "no output"; fails = [l for l in p.stdout.splitlines() if l.startswith("FAIL")]
        extra = ""
        if a.random:
            tot = ok = 0
            for s in range(1, a.random + 1):
                rd_dir = os.path.join(ROOT, "out", f"rand_{s}")      # reuse the seeds generated for the default configuration
                if not os.path.isdir(rd_dir): continue
                d2 = os.path.join(sd, f"rand_{s}"); shutil.rmtree(d2, ignore_errors=True); os.makedirs(d2)
                for f in glob.glob(os.path.join(rd_dir, "*.scn")):
                    txt = re.sub(r"^build .*$", lambda m: re.sub(r"\bdw=\d+", f"dw={dw}", re.sub(r"\bmtu=\d+", f"mtu={mtu}", re.sub(r"\bwindow=\d+", f"window={w}", m.group(0)))), open(f).read(), flags=re.M)
                    open(os.path.join(d2, os.path.basename(f)), "w").write(txt)
                q = sh([sys.executable, os.path.join(ROOT, "scripts", "regress.py"), "--tb", os.path.join(ROOT, "out", f"tb_{tag}_rd{rd}"), "--dir", d2, "--jobs", "3",
                        "--tag", f"_mr_{tag}_{s}", "--report", os.path.join(ROOT, "out", f"matrixr_{tag}_{s}.md")])
                m = re.search(r"(\d+)/(\d+) runs", q.stdout or ""); 
                if m: ok += int(m.group(1)); tot += int(m.group(2))
            extra = f"random {ok}/{tot}"
        print(f"dw={dw:3d} mtu={mtu:4d} window={w:2d} max_rd={rd}: {summ}  {extra}")
        for l in fails[:4]: print("     " + l[:150])
        rows.append((dw, mtu, w, rd, summ, extra))
    with open(os.path.join(ROOT, "reports", "regression_matrix.md"), "w") as f:
        f.write(f"# Regression across parameterisations\n\nThe same directed suite (and, where listed, the random suites) with the engine built for each configuration and the reference model told the same parameters. ({time.time()-t0:.0f} s)\n\n| DW | MTU | WINDOW | MAX_RD | directed suite | random |\n|---|---|---|---|---|---|\n")
        for r in rows: f.write(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} | {r[4]} | {r[5]} |\n")
sys.exit(main())
