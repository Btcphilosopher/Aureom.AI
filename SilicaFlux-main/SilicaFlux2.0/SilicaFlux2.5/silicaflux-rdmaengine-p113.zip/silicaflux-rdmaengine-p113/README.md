# SilicaFlux Project 113 — RDMAEngine

A synthesizable **remote-memory operation engine**: one queue pair that performs **SEND, RDMA WRITE and RDMA READ** between two endpoints over a *simulated reliable transport*, with a protected **memory-region table** (key + protection domain + direction + range + translation checked on every remote and local access), PSN-based sequencing, acknowledgements, timeout / retry / duplicate detection, a **remote-write safety contract that distinguishes "accepted" from "committed"**, bounded queues with back-pressure and credits, a PacketCore (P62) streaming interface, and performance counters.

Primary RTL: `rtl/sf_rdma_engine.sv`. Definition of done (from the brief): *two simulated endpoints exchange supported remote-memory operations correctly while enforcing registered-memory permissions and handling the defined transport failures.*

## What this is NOT (read this first)

* **Not RoCEv2, not InfiniBand, not iWARP.** The wire protocol is **SFRT v1**, an internal protocol (private EtherType `0x88B5`, 34-byte header) that borrows the *ideas* of a reliable-connection RDMA transport (24-bit PSNs, cumulative ACK, go-back-N, RNR). **No interoperability with any other implementation is claimed or tested.** RoCEv2 is a separately verified later milestone (`docs/FUTURE_EXPANSION.md`).
* **Evidence level is RTL simulation** (Verilator, two endpoints, an independent Python reference model), **bounded/k-induction formal checks on small instances** (Yosys → SMT2 → z3) and a Yosys generic-gate *estimate*. **No FPGA, no place-and-route, no timing closure, no PDK, no silicon.** Throughput and latency are in simulation **cycles and bytes/cycle**; **no clock frequency, Gbit/s, power or area is claimed.**
* One queue pair. No atomics, immediate data, SRQ, congestion control, real MAC/PHY, multi-queue (all listed with their gates in `docs/FUTURE_EXPANSION.md`).
* The full list of what is *not* covered, and the defects that were found but deliberately not fixed, is in **`docs/LIMITATIONS.md`**. Please read it before relying on anything.

## Quick start

Needs `verilator` (5.020 used), `yosys`, `z3`, Python 3.

```bash
make build                                              # two-endpoint Verilator bench -> out/tb_dw64_mtu256_w8
make build-fi                                           # (optional) the same bench with the simulation-only guard fault injection; only scenario rv11 needs it
python3 scripts/regress_all.py --repo /path/to/Aureom.AI   # the whole simulation stack (about 3 minutes), writes reports/regression_all.md
python3 benchmarks/rdma/bench.py && python3 benchmarks/rdma/make_report.py   # benchmarks -> benchmarks/rdma/REPORT.md
python3 scripts/mutate.py                               # mutation campaign (each mutant rebuilds the bench), reports/mutation.md
python3 scripts/formal.py                               # formal jobs, reports/formal.md
python3 scripts/synth.py                                # Yosys generic-gate estimate, reports/synth.md
python3 scripts/make_zip.py --out ../silicaflux-rdmaengine-p113.zip
```

`--repo` is the checkout of the verified Aureom.AI repository that `third_party/` was vendored from; `scripts/check_vendor.py` proves the vendored files are byte-identical to it.

## Layout

| path | what |
|---|---|
| `rtl/` | the engine: `sf_rdma_engine` (top), `sf_rdma_qp`, `sf_rdma_wqe`, `sf_rdma_memory_registry`, `sf_rdma_transport_adapter`, `sf_rdma_retry`, `sf_rdma_completion`, `sf_rdma_perf`, plus `sf_rdma_requester`, `sf_rdma_rx`, `sf_rdma_rdgen`, `sf_rdma_ackgen`, `sf_rdma_dma_rd`, `sf_rdma_dma_wr`, `sf_rdma_fifo`, `sf_rdma_defs.svh`; `lint.vlt` holds the justified lint waivers |
| `third_party/` | verified repo IP reused **unchanged** (skid buffer, round-robin arbiter, stream byte-realigner) and the PacketCore (P62) front end for the integration run; `MANIFEST.sha256` |
| `docs/TRANSPORT_SPEC.md` | the normative SFRT v1 specification (the contract the RTL, the model and the tests are all written from) |
| `docs/` | `00_AUDIT` (reuse audit), `01_ARCHITECTURE`, `INTERFACE`, `PERF_COUNTERS`, `PERFORMANCE`, `LIMITATIONS`, `CHANGELOG` (every defect verification found), `REVIEW_FINDINGS` (independent adversarial review + disposition), `VERIFICATION` (what was verified and how), `FUTURE_EXPANSION` (RoCEv2, real MAC, congestion control, multi-queue, larger registry, FPGA networking) |
| `tests/rdma/bench/` | two-endpoint Verilator C++ bench: cycle-level monitors, link impairment model (drop / duplicate / delay / reorder / black-hole / frame injection), memory model with latency, stalls and **injectable memory errors** |
| `tests/rdma/model/` | the **independent reference model and checker** (Python, written from the spec, not from the RTL) and its 101 self-tests |
| `tests/rdma/gen/`, `tests/rdma/scenarios/` | scenario generators; **141 directed scenarios** (success, invalid key, out of range, loss, duplicate, delayed ACK, retry, timeout, reset, queue saturation, concurrent DMA, domain isolation, …) and random / fault-tail / **chaos** generators |
| `tests/rdma/review/` | one scenario (+ explicit expectations) per defect the independent review found |
| `tests/rdma/integration/` | the engine with PacketCore in the receive path |
| `formal/rdma/` | formal harnesses and their README (what is PROVED, what is only BOUNDED) |
| `benchmarks/rdma/` | benchmark driver, raw results (`results.csv`) and the generated report |
| `reports/` | the evidence: regression, matrix, PacketCore run, lint, mutation, formal, synthesis |
| `scripts/` | all drivers (`regress_all.py`, `regress.py`, `regress_matrix.py`, `mutate.py`, `formal.py`, `synth.py`, `lint.py`, `check_vendor.py`, `make_zip.py`, …) |

## Results at a glance

Everything below is reproduced by the commands above; the files in `reports/` are the raw evidence.

| check | result | evidence |
|---|---|---|
| Lint: Verilator `-Wall` over 8 legal parameter sets; 21 illegal sets must be **refused at elaboration**; Yosys elaboration of the full engine | all clean; **21 / 21 refused**; elaborates | `reports/lint.md` |
| Vendored IP byte-identical to the verified repo | OK | `third_party/MANIFEST.sha256`, `scripts/check_vendor.py` |
| Reference model self-tests | 101 / 101 | `tests/rdma/model/test_model.py` |
| **Directed suite**: 141 scenarios × 5 seeds, model as oracle | **705 / 705** | `reports/regression_all.md`, `reports/regression.md` |
| **Review repros**: one scenario per defect the independent review found | **16 / 16** (15 fail on the pre-fix RTL; `rv01c` is the control and passes on both) | `reports/regression_all.md`, `tests/rdma/review/` |
| **Random**: 6 seeds × 40 mixed scenarios; **fault tails**: 6 × 30 | **240 / 240**; **180 / 180** | `reports/regression_all.md` |
| **Chaos**: 480 scenarios with forced ERR/RESET at random moments | **480 / 480** (the same campaign finds the RQ-order defect 5 times on the pre-fix RTL) | `reports/regression_all.md` |
| **Parameter matrix**: 14 configurations (DW 32/64/128, MTU 64–1024, WINDOW 2–16, MAX_RD 1–4), directed + 120 random each | **all pass** (139–141 directed, 120 random each) | `reports/regression_matrix.md` |
| **PacketCore (P62) in the receive path** | 138 / 141; the 3 differences (`t084`, `t085`, `t139`) are drop *counters* only: PacketCore filters malformed and MAC-flagged frames before the engine counts them | `reports/regression_packetcore.md` |
| **Mutation testing (simulation)** | **57 / 57** mutants killed | `reports/mutation.md` |
| **Formal** (Yosys → SMT2 → z3), small instances | 130 jobs: **6 PROVED** (unbounded: retry unit, CQ credits, WQE posting, ACK generation, PSN arithmetic ×2), **14 BOUNDED** (5–22 cycles), **110 WITNESSED** (non-vacuity), 0 UNKNOWN. Formal mutants: **81 / 84 killed**, 1 survived (equivalent on that instance), 2 UNKNOWN. One real bug found independently (S-01). | `reports/formal.md`, `formal/rdma/README.md` |
| **Independent adversarial review** | 1 critical, 3 high, 5 medium, 1 low confirmed → all fixed; 3 suspected, 3 documented | `docs/REVIEW_FINDINGS.md`, `docs/CHANGELOG.md` |
| **Synthesis estimate** (Yosys generic gates; arrays counted as flip-flops; **no timing, no mapping**) | default 198 159 cells / 38 829 FFs · small (DW 32, MTU 64, WINDOW 4, NMR 4) 137 917 / 21 682 · wide (DW 128, MTU 512, WINDOW 16) 259 866 / 56 265 | `reports/synth.md` |
| **Benchmarks** (cycle-accurate simulation; **no clock claimed**) | ≈ 6.0 B/cycle large-transfer WRITE/READ = 75 % of the 8 B/cycle stream peak (DW 64, MTU 256); 58-cycle unloaded 8-byte latency; DW 128 → 11.05 B/cycle | `benchmarks/rdma/REPORT.md`, `docs/PERFORMANCE.md` |

## How the verification was done, and how far it can be trusted

* The **reference model was written separately from the RTL**, both from `docs/TRANSPORT_SPEC.md`. Every disagreement was resolved by clarifying the spec, never by loosening a check (`docs/CHANGELOG.md`, "Specification changes"). Shared misreadings of the spec are still possible.
* The **final remote memory is compared byte-for-byte with the model** in every scenario, per-byte write counts must be exact (a byte of a rejected request is written zero times, of an accepted one exactly once), completions must follow the remote commit, and a wire-level monitor checks every ACK/NAK frontier.
* An **independent adversarial review** (a separate agent that did not write the RTL, with white-box instrumentation of copies) found **1 critical, 3 high, 5 medium and 1 low** confirmed defects — among them *memory error responses silently ignored* and *a fatal NAK that could hang a QP for ever*. All were reproduced on the old RTL, fixed, and are guarded by tests that fail on the old RTL (`docs/REVIEW_FINDINGS.md`, `docs/CHANGELOG.md`). The review also showed the limits of the earlier evidence: the flush/error paths were under-tested, which is why a chaos campaign and two standing bench invariants were added.
* **Mutation testing** plants one defect at a time in a copy of the RTL; a mutant that no test notices is a hole in the tests. It found five holes in the first campaign and two more after the review fixes (one existing mutant had silently become weaker), each closed by a new scenario.
* Formal results are for **small parameter instances**; `formal/rdma/README.md` separates PROVED (k-induction) from BOUNDED (BMC to depth d) and lists anything UNKNOWN.

## Where to start reading

`docs/TRANSPORT_SPEC.md` (the contract) → `docs/01_ARCHITECTURE.md` → `docs/VERIFICATION.md` → `docs/LIMITATIONS.md` → `benchmarks/rdma/REPORT.md`.
