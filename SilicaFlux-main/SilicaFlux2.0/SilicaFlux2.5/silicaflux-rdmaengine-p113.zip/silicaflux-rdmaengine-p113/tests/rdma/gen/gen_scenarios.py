#!/usr/bin/env python3
"""gen_scenarios.py - directed scenario suite for SFRT (spec Appendix A.1).

    python3 -I gen_scenarios.py [--out DIR] [--list] [--no-check] [--only SUBSTR]

Writes one `t<NN>_<name>.scn` per case into ../scenarios (default).  After writing, every scenario is run through
the independent model (must not raise, must produce NO determinism warnings) and its ideal result is pushed
through check_results (must PASS) - so a generated suite is always internally consistent.

Conventions: see scn_lib.py for the memory map.  Unless stated otherwise A is the requester, B the responder;
error scenarios are unidirectional; random link impairments appear only in scenarios whose outcome is success.
"""
import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'model'))

from scn_lib import *                          # noqa: F401,F403,E402
from scn_lib import (Scn, va, pa, key, MRS, MAC, QPN, SRC, RDST, WDST, RQB, RSRC, init_mem, npsn, MTU,   # noqa: E402
                     K, MAIN_END, new, mva, W, R, SND, RQ, D, peer_ab, peer_ba, payload, inject)
import frames as F                             # noqa: E402
import scn as SC                               # noqa: E402

SCENARIOS = []


def sc(name, **setup_kw):
    def deco(fn):
        SCENARIOS.append((name, fn, setup_kw))
        return fn
    return deco


# ===========================================================================
# 1. successful operations
# ===========================================================================
@sc('send_single')
def _(s):
    """single-segment SEND, RQE larger than the message"""
    RQ(s, 0, 512, wr_id=101)
    SND(s, 100, wr_id=1)
    s.barrier()
    D(s, 'B', RQB, 0, 160)


@sc('send_multiseg')
def _(s):
    """multi-segment SENDs: 4 segments, exactly 8 segments (= window), 12 segments"""
    RQ(s, 0x0000, 1024, wr_id=101)
    RQ(s, 0x0400, 2048, wr_id=102)
    RQ(s, 0x1000, 3072, wr_id=103)
    SND(s, 1000, wr_id=1)
    SND(s, 2048, src=0x400, wr_id=2)
    SND(s, 3000, src=0x1000, wr_id=3)
    s.barrier()
    D(s, 'B', RQB, 0, 1024)
    D(s, 'B', RQB, 0x400, 2048)
    D(s, 'B', RQB, 0x1000, 3072)


@sc('send_zero_len')
def _(s):
    """zero-length SENDs: one PSN, RECV CQE byte_len 0; an RQE with len 0 skips the registry check (invalid lkey ok)"""
    RQ(s, 0x000, 64, wr_id=101)
    RQ(s, 0x100, 0, lkey=0xDEAD, wr_id=102)
    RQ(s, 0x200, 64, wr_id=103)
    SND(s, 0, wr_id=1)
    SND(s, 0, wr_id=2)
    SND(s, 1, wr_id=3)
    s.barrier()
    D(s, 'B', RQB, 0, 0x240)


@sc('send_unaligned')
def _(s):
    """SENDs with unaligned source addresses and unaligned receive buffers"""
    items = [(1, 3, 5), (3, 5, 333), (7, 1, 1000), (5, 6, 255), (2, 7, 257), (6, 2, 600)]
    for i in range(0, len(items), 3):
        for j, (so, ro, ln) in enumerate(items[i:i + 3]):
            RQ(s, (j * 0x800) + ro, ln + 32, wr_id=101 + i + j)
        for j, (so, ro, ln) in enumerate(items[i:i + 3]):
            SND(s, ln, src=so + (i + j) * 0x400, wr_id=1 + i + j)
        s.barrier()
        for j, (so, ro, ln) in enumerate(items[i:i + 3]):
            D(s, 'B', RQB, (j * 0x800) + ro, ln + 8)


@sc('send_mtu_edges')
def _(s):
    """SEND lengths around MTU multiples: 255 256 257 511 512 513 767 768 769"""
    lens = [255, 256, 257, 511, 512, 513, 767, 768, 769]
    n = 0
    for i in range(0, len(lens), 3):
        grp = lens[i:i + 3]
        for j, ln in enumerate(grp):
            RQ(s, j * 0x400, ln + 16, wr_id=101 + n + j)
        for j, ln in enumerate(grp):
            SND(s, ln, src=(n + j) * 0x100, wr_id=1 + n + j)
        s.barrier()
        for j, ln in enumerate(grp):
            D(s, 'B', RQB, j * 0x400, ln + 4)
        n += len(grp)


@sc('send_len_sweep')
def _(s):
    """SEND length sweep incl. 0 and 1, RQE exactly as long as the message for some"""
    lens = [0, 1, 7, 8, 9, 63, 64, 65, 127, 129, 300, 1000]
    off = 0
    n = 0
    for i in range(0, len(lens), 4):
        slots = []
        for j, ln in enumerate(lens[i:i + 4]):
            rl = ln if (i + j) % 2 else ln + 24
            RQ(s, off, rl, wr_id=101 + n + j)
            slots.append((off, ln))
            off += rl + 3
        for j, ln in enumerate(lens[i:i + 4]):
            SND(s, ln, src=((n + j) * 37) % 1000, wr_id=1 + n + j)
        s.barrier()
        n += 4
    D(s, 'B', RQB, 0, off + 8)


@sc('write_aligned')
def _(s):
    """aligned RDMA WRITEs of 8 .. 2048 bytes to aligned remote addresses"""
    off = 0
    for ln in (8, 64, 256, 512, 1024, 2048):
        W(s, ln, src=0, dst=off)
        off = (off + ln + 63) & ~63
    s.barrier()
    D(s, 'B', WDST, 0, off + 8)


@sc('write_unaligned')
def _(s):
    """unaligned local and remote addresses (all 8 byte phases), lengths 1..3000"""
    cases = [(1, 3, 1), (2, 5, 2), (3, 7, 7), (5, 1, 129), (7, 3, 257), (1, 5, 513), (6, 6, 1001), (3, 2, 2999),
             (0, 7, 3000), (4, 4, 1500)]
    off = 0
    for so, do, ln in cases:
        W(s, ln, src=so, dst=off + do)
        off += ln + 24
    s.barrier()
    D(s, 'B', WDST, 0, off)


@sc('write_len_sweep_small')
def _(s):
    """WRITE lengths 1..129 around word (8) and 32/64/128 boundaries, misaligned both ends"""
    lens = [1, 2, 3, 4, 5, 6, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64, 65, 127, 128, 129]
    off = 0
    for i, ln in enumerate(lens):
        W(s, ln, src=i * 32 + (i % 8), dst=off)
        off += ln + (i % 8) + 1
    s.barrier()
    D(s, 'B', WDST, 0, off)


@sc('write_len_sweep_mtu')
def _(s):
    """WRITE lengths at MTU multiples: k*256-1, k*256, k*256+1 for k=1..8"""
    lens = []
    for k in range(1, 9):
        lens += [256 * k - 1, 256 * k, 256 * k + 1]
    off = 0
    for i, ln in enumerate(lens):
        W(s, ln, src=(i % 8), dst=off + (i % 8))
        off += ln + 16
    s.barrier()
    D(s, 'B', WDST, 0, off)


@sc('write_8k_windowed')
def _(s):
    """one 8192 byte WRITE = 32 segments through a window of 8 PSNs"""
    W(s, 8192, src=1, dst=3)
    s.barrier()
    D(s, 'B', WDST, 0, 8192 + 8)


@sc('read_aligned')
def _(s):
    """aligned RDMA READs (MAX_RD = 2 outstanding)"""
    off = 0
    for ln in (8, 64, 256, 512, 1024, 2048):
        R(s, ln, dst=off, src=off)
        off = (off + ln + 63) & ~63
    s.barrier()
    D(s, 'A', RDST, 0, off + 8)


@sc('read_unaligned')
def _(s):
    """READs with unaligned local destination and unaligned remote source"""
    cases = [(1, 3, 1), (2, 5, 2), (3, 7, 7), (5, 1, 129), (7, 3, 257), (1, 5, 513), (6, 6, 1001)]
    off = 0
    for do, so, ln in cases:
        R(s, ln, dst=off + do, src=off + so)
        off += ln + 24
    s.barrier()
    D(s, 'A', RDST, 0, off)


@sc('read_len_sweep')
def _(s):
    """READ lengths 1..2000 incl. MTU multiples"""
    lens = [1, 2, 3, 7, 8, 9, 31, 32, 33, 63, 64, 65, 255, 256, 257, 511, 512, 513, 1000, 2000]
    off = 0
    for i, ln in enumerate(lens):
        R(s, ln, dst=off + (i % 8), src=off + ((i * 3) % 8))
        off += ln + 16
    s.barrier()
    D(s, 'A', RDST, 0, off)


@sc('read_3000_and_8k')
def _(s):
    """a 3000 byte READ (12 response segments) and a 7000 byte READ"""
    R(s, 3000, dst=1, src=2)
    R(s, 7000, dst=0x1000 + 5, src=0)
    s.barrier()
    D(s, 'A', RDST, 0, 0x1000 + 7000 + 16)


@sc('write_then_read_back')
def _(s):
    """READ-after-WRITE fence: the READ (later PSN, same flow) must observe the WRITE's data"""
    W(s, 700, src=0, dst=0)
    R(s, 700, dst=0, src=0, raddr=mva(WDST), wr_id=None)       # reads B's WDST: what the WRITE just put there
    W(s, 300, src=0x400, dst=0x400)
    R(s, 300, dst=0x400, src=0, raddr=mva(WDST + 0x400))
    s.barrier()
    D(s, 'A', RDST, 0, 0x500)
    D(s, 'B', WDST, 0, 0x500)


@sc('pipelined_mixed_24')
def _(s):
    """24 pipelined WQEs (SQ_DEPTH 8 -> post back-pressure): 12 WRITE, 8 READ, 4 SEND"""
    for i in range(4):
        RQ(s, i * 0x400, 600, wr_id=101 + i)
    seq = ['W', 'R', 'W', 'S', 'R', 'W'] * 4
    seq[3] = seq[9] = seq[15] = seq[21] = 'S'
    wi = ri = si = 0
    for i, k in enumerate(seq):
        if k == 'W':
            W(s, 100 + 7 * wi, src=wi * 130, dst=wi * 300)
            wi += 1
        elif k == 'R':
            R(s, 90 + 11 * ri, dst=ri * 200, src=ri * 160)
            ri += 1
        else:
            SND(s, 200 + 13 * si, src=0x2000 + si * 300)
            si += 1
    s.barrier()
    D(s, 'B', WDST, 0, 12 * 300)
    D(s, 'A', RDST, 0, 8 * 200)
    D(s, 'B', RQB, 0, 0x1000)


@sc('psn_wrap_bidirectional', psn_ab=0xFFFFF0, psn_ba=0xFFFFFA)
def _(s):
    """PSNs of both directions start just below 2^24 and wrap during multi-segment WRITE/SEND/READ traffic"""
    RQ(s, 0, 700, ep='B', wr_id=101)
    RQ(s, 0, 700, ep='A', wr_id=201)
    W(s, 3000, src=0, dst=0, ep='A')                 # 12 PSNs: FFFFF0 .. FFFFFB
    SND(s, 600, src=0x1000, ep='A')                  # wraps to 0x000000
    R(s, 500, dst=0, src=0, ep='A')
    W(s, 2500, src=0, dst=0, ep='B')                 # 10 PSNs from FFFFFA: wraps
    SND(s, 650, src=0x1000, ep='B')
    R(s, 400, dst=0, src=0, ep='B')
    s.barrier()
    D(s, 'B', WDST, 0, 3000)
    D(s, 'A', WDST, 0, 2500)
    D(s, 'B', RQB, 0, 700)
    D(s, 'A', RQB, 0, 700)
    D(s, 'A', RDST, 0, 500)
    D(s, 'B', RDST, 0, 400)


@sc('psn_wrap_unidirectional_reads', psn_ab=0xFFFFFE)
def _(s):
    """PSN wrap with a READ exactly at the wrap and WRITEs around it"""
    W(s, 100, dst=0)                          # FFFFFE
    R(s, 128, dst=0, src=0)                   # FFFFFF
    W(s, 100, src=0x100, dst=0x100)           # 000000
    R(s, 128, dst=0x100, src=0x100)           # 000001
    s.barrier()
    D(s, 'B', WDST, 0, 0x180)
    D(s, 'A', RDST, 0, 0x200)


@sc('concurrent_dma_jitter')
def _(s):
    """A and B write/read each other simultaneously (disjoint role areas) with memory latency jitter on both ends"""
    s.cmd('mem_lat', ep='A', min=1, max=9, stall=30)
    s.cmd('mem_lat', ep='B', min=2, max=12, stall=10)
    for i in range(6):
        W(s, 200 + 37 * i, src=i * 256, dst=i * 300, ep='A')
        W(s, 180 + 41 * i, src=i * 256, dst=i * 300, ep='B')
        if i % 2 == 0:
            R(s, 150 + 17 * i, dst=i * 200, src=i * 200, ep='A')
            R(s, 170 + 19 * i, dst=i * 200, src=i * 200, ep='B')
    s.barrier()
    D(s, 'B', WDST, 0, 1900)
    D(s, 'A', WDST, 0, 1900)
    D(s, 'A', RDST, 0, 1200)
    D(s, 'B', RDST, 0, 1200)


@sc('many_small_writes_window')
def _(s):
    """40 one-segment WRITEs back to back: the 8-PSN window and the 8-deep SQ are saturated"""
    for i in range(40):
        W(s, 16 + (i % 5), src=i * 20, dst=i * 24)
    s.barrier()
    D(s, 'B', WDST, 0, 40 * 24)


@sc('read_limit_burst')
def _(s):
    """6 READs back to back (MAX_RD = 2): the read limit stalls issue, all complete in order"""
    for i in range(6):
        R(s, 300 + i, dst=i * 400, src=i * 400)
    s.barrier()
    D(s, 'A', RDST, 0, 6 * 400)


@sc('mixed_bidirectional_sends')
def _(s):
    """both sides SEND to each other while the peer's WRITEs/READs are running"""
    for i in range(3):
        RQ(s, i * 0x400, 400, ep='B', wr_id=101 + i)
        RQ(s, i * 0x400, 400, ep='A', wr_id=201 + i)
    for i in range(3):
        SND(s, 100 + 50 * i, src=i * 128, ep='A')
        SND(s, 120 + 40 * i, src=i * 128, ep='B')
        W(s, 64 * (i + 1), src=0x800, dst=i * 256, ep='A')
        W(s, 80 * (i + 1), src=0x800, dst=i * 256, ep='B')
    R(s, 256, dst=0, src=0, ep='A')
    R(s, 256, dst=0, src=0, ep='B')
    s.barrier()
    D(s, 'B', RQB, 0, 0xC00)
    D(s, 'A', RQB, 0, 0xC00)
    D(s, 'B', WDST, 0, 0x600)
    D(s, 'A', WDST, 0, 0x600)


# ===========================================================================
# 2. protection / validation faults (one fatal fault per scenario)
# ===========================================================================
def fault_frame(s, bad, with_rq=False, dump_area=None):
    """WRITE ok (wr 1) ; <bad> ; WRITE (flushed)"""
    if with_rq:
        RQ(s, 0, 64, wr_id=101)
        RQ(s, 0x100, 64, wr_id=102)
    W(s, 64, src=0, dst=0)
    bad(s)
    W(s, 64, src=0x100, dst=0x100)
    s.barrier()
    D(s, 'B', WDST, 0, 0x200)


@sc('write_bad_rkey')
def _(s):
    """WRITE with an unknown rkey -> REM_ACCESS_ERR; responder QP -> ERR and flushes its two receive WQEs"""
    fault_frame(s, lambda s: W(s, 64, src=0x80, dst=0x80, rkey=0xDEAD), with_rq=True)


@sc('read_bad_rkey')
def _(s):
    fault_frame(s, lambda s: R(s, 64, dst=0, src=0, rkey=0xDEAD))


@sc('write_bad_lkey_local')
def _(s):
    """local lkey unknown: LOC_PROT_ERR for that WQE after the earlier WQE retired OK; later WQE flushed; nothing sent"""
    fault_frame(s, lambda s: W(s, 64, src=0x80, dst=0x80, lkey=0xBAD))


@sc('send_bad_lkey_local')
def _(s):
    fault_frame(s, lambda s: SND(s, 64, lkey=0xBAD))


@sc('read_bad_lkey_local')
def _(s):
    fault_frame(s, lambda s: R(s, 64, lkey=0xBAD))


@sc('rqe_bad_lkey')
def _(s):
    """receive WQE with an invalid lkey: responder REM_OP, its RQE completes LOC_PROT_ERR, the next RQE is flushed"""
    RQ(s, 0, 128, lkey=0xBAD, wr_id=101)
    RQ(s, 0x100, 128, wr_id=102)
    SND(s, 64, wr_id=1)
    W(s, 64, wr_id=2)
    s.barrier()
    D(s, 'B', RQB, 0, 0x200)
    D(s, 'B', WDST, 0, 0x100)


@sc('rqe_too_small')
def _(s):
    """SEND longer than the receive buffer: REM_OP at the requester, LOC_LEN_ERR on the RQE, next RQE flushed"""
    RQ(s, 0, 100, wr_id=101)
    RQ(s, 0x400, 600, wr_id=102)
    W(s, 64, dst=0, wr_id=1)
    SND(s, 101, wr_id=2)
    W(s, 64, src=0x100, dst=0x100, wr_id=3)
    s.barrier()
    D(s, 'B', RQB, 0, 0x500)
    D(s, 'B', WDST, 0, 0x200)


@sc('rqe_larger_than_region')
def _(s):
    """the receive-side registry check covers the whole RQE buffer (rqe.len), not just the message: RQE exceeding
    the region -> REM_OP / LOC_PROT_ERR even for a tiny SEND"""
    RQ(s, 0, 128, addr=MAIN_END - 64, wr_id=101)
    SND(s, 16, wr_id=1)
    s.barrier()


@sc('write_range_above_end')
def _(s):
    """remote WRITE starting exactly at the first byte past the region"""
    s.fill('B', pa('main', 0xFF00), 0x300, 0x77)
    fault_frame(s, lambda s: W(s, 16, src=0x80, raddr=MAIN_END, dst=0))
    s.dump('B', pa('main', 0xFF00), 0x200)


@sc('write_range_below_start')
def _(s):
    """remote WRITE whose first 8 bytes lie below the region"""
    fault_frame(s, lambda s: W(s, 16, src=0x80, raddr=mva(0) - 8))


@sc('write_range_last_byte_over')
def _(s):
    """remote WRITE whose LAST byte is one past the region (first byte inside)"""
    s.fill('B', pa('main', 0xFF00), 0x300, 0x77)
    fault_frame(s, lambda s: W(s, 16, src=0x80, raddr=MAIN_END - 15))
    s.dump('B', pa('main', 0xFF00), 0x100)


@sc('write_range_multiseg_partial')
def _(s):
    """1000 byte WRITE that runs 168 bytes past the region end in its 3rd segment: segments 0 and 1 land (512 bytes),
    nothing of segment 2 or later does; WQE completes REM_ACCESS_ERR"""
    s.fill('B', pa('main', 0xF000), 0x1200, 0x66)
    fault_frame(s, lambda s: W(s, 1000, src=0x200, raddr=MAIN_END - 600))
    s.dump('B', pa('main', 0xFD00), 0x300)


@sc('read_range_above_end')
def _(s):
    fault_frame(s, lambda s: R(s, 16, raddr=MAIN_END))


@sc('read_range_below_start')
def _(s):
    fault_frame(s, lambda s: R(s, 16, raddr=mva(0) - 4))


@sc('read_range_last_byte_over')
def _(s):
    fault_frame(s, lambda s: R(s, 300, raddr=MAIN_END - 299))


@sc('local_range_laddr_crosses_end')
def _(s):
    """local source buffer runs one byte past its region -> LOC_PROT_ERR"""
    fault_frame(s, lambda s: W(s, 16, laddr=MAIN_END - 15, dst=0x80))


@sc('overflow_local_laddr_wraps')
def _(s):
    """laddr = 2^64-8, len 16: the 65-bit sum exceeds 2^64 -> OVERFLOW (must not alias a low address) -> LOC_PROT_ERR"""
    fault_frame(s, lambda s: W(s, 16, laddr=(1 << 64) - 8, dst=0x80))


def wire_fatal(s, frame_fn):
    """A's SEND finds no receive buffer at B (RNR wait).  A crafted request with the SAME PSN is injected towards B:
    it is in order, fails, B sends a fatal NAK for that PSN, which completes A's waiting SEND with the NAK's status."""
    w = SND(s, 64, wr_id=1)
    s.run(150)
    inject(s, 'AB', frame_fn(s.psn_of[('A', w)]))
    s.barrier()


@sc('overflow_wire_write')
def _(s):
    """injected WRITE with va = 2^64-8, paylen 16 (65-bit overflow) -> mr_fault_overflow at B, REM_ACCESS_ERR at A"""
    wire_fatal(s, lambda p: F.request_frame(peer_ab(s), 'WRITE', p, payload=payload(1, 16), mlen=16,
                                            va=(1 << 64) - 8, rkey=K))


@sc('overflow_wire_read')
def _(s):
    wire_fatal(s, lambda p: F.request_frame(peer_ab(s), 'READ', p, mlen=16, moff=0, va=(1 << 64) - 8, rkey=K))


@sc('wire_write_bad_key')
def _(s):
    wire_fatal(s, lambda p: F.request_frame(peer_ab(s), 'WRITE', p, payload=payload(2, 32), mlen=32, va=mva(WDST),
                                            rkey=0xBEEF))


@sc('wire_write_range')
def _(s):
    wire_fatal(s, lambda p: F.request_frame(peer_ab(s), 'WRITE', p, payload=payload(2, 32), mlen=32,
                                            va=MAIN_END - 16, rkey=K))


@sc('wire_read_bad_key')
def _(s):
    wire_fatal(s, lambda p: F.request_frame(peer_ab(s), 'READ', p, mlen=64, va=mva(RSRC), rkey=0xBEEF))


@sc('perm_write_to_readonly')
def _(s):
    """region with REMOTE_READ only: a remote WRITE has remote rights available but not the right one -> BAD_PERM"""
    fault_frame(s, lambda s: W(s, 16, src=0x80, raddr=va('rdonly', 0), rkey=key('rdonly')))


@sc('perm_read_from_writeonly')
def _(s):
    fault_frame(s, lambda s: R(s, 16, raddr=va('wronly', 0), rkey=key('wronly')))


@sc('perm_read_dest_readonly_local')
def _(s):
    """READ destination in a region without LOCAL_WRITE -> local BAD_PERM"""
    fault_frame(s, lambda s: R(s, 16, laddr=va('rdonly', 0), lkey=key('rdonly')))


@sc('perm_send_from_writeonly_local')
def _(s):
    """SEND source in a region without LOCAL_READ (it has LOCAL_WRITE: direction is fine, right is missing)"""
    fault_frame(s, lambda s: SND(s, 16, laddr=va('wronly', 0), lkey=key('wronly')))


@sc('perm_rqe_in_readonly')
def _(s):
    RQ(s, 0, 64, lkey=key('rdonly'), addr=va('rdonly', 0), wr_id=101)
    SND(s, 16, wr_id=1)
    s.barrier()


@sc('domain_isolation_write')
def _(s):
    """valid key of a pd=2 region, otherwise valid range and rights: must be rejected (QP is bound to pd=1)"""
    fault_frame(s, lambda s: W(s, 16, src=0x80, raddr=va('otherpd', 0), rkey=key('otherpd')))


@sc('domain_isolation_read')
def _(s):
    fault_frame(s, lambda s: R(s, 16, raddr=va('otherpd', 0), rkey=key('otherpd')))


@sc('domain_isolation_local_lkey')
def _(s):
    fault_frame(s, lambda s: W(s, 16, laddr=va('otherpd', 0), lkey=key('otherpd'), dst=0x80))


@sc('domain_isolation_rqe')
def _(s):
    RQ(s, 0, 64, lkey=key('otherpd'), addr=va('otherpd', 0), wr_id=101)
    SND(s, 16, wr_id=1)
    s.barrier()


@sc('direction_write_to_localonly')
def _(s):
    """region with local rights only used by a remote WRITE -> BAD_DIR (not BAD_PERM)"""
    fault_frame(s, lambda s: W(s, 16, src=0x80, raddr=va('localonly', 0), rkey=key('localonly')))


@sc('direction_read_from_localonly')
def _(s):
    fault_frame(s, lambda s: R(s, 16, raddr=va('localonly', 0), rkey=key('localonly')))


@sc('direction_send_from_remoteonly_local')
def _(s):
    """region with remote rights only used as local SEND source -> BAD_DIR"""
    fault_frame(s, lambda s: SND(s, 16, laddr=va('remoteonly', 0), lkey=key('remoteonly')))


@sc('direction_read_dest_remoteonly_local')
def _(s):
    fault_frame(s, lambda s: R(s, 16, laddr=va('remoteonly', 0), lkey=key('remoteonly')))


@sc('page_cross_write_noncontig')
def _(s):
    """non-CONTIG region: a single WRITE frame straddling a 4 KiB boundary -> PAGE_CROSS at the responder"""
    s.fill('B', pa('paged', 0xF00), 0x300, 0x55)
    fault_frame(s, lambda s: W(s, 200, src=0x80, raddr=va('paged', 0x1000 - 100), rkey=key('paged')))
    s.dump('B', pa('paged', 0xF00), 0x300)


@sc('page_cross_read_noncontig')
def _(s):
    fault_frame(s, lambda s: R(s, 200, raddr=va('paged', 0x2000 - 100), rkey=key('paged')))


@sc('page_cross_local_noncontig')
def _(s):
    """local source buffer in a non-CONTIG region straddling a page boundary -> local PAGE_CROSS"""
    fault_frame(s, lambda s: W(s, 200, laddr=va('paged', 0x1000 - 100), lkey=key('paged'), dst=0x80))


@sc('page_cross_ok_cases')
def _(s):
    """CONTIG region crosses a page freely; non-CONTIG region: a frame ending exactly on the boundary and one
    starting exactly on it are fine; a 512 byte WRITE whose two frames are split exactly at the page boundary is
    fine too (the check is per frame)"""
    s.fill('B', pa('paged', 0), 0x3000, 0x45)
    W(s, 200, src=0x80, raddr=mva(WDST + 0x1000 - 100), dst=0)                    # CONTIG, crosses a page
    W(s, 100, src=0x80, raddr=va('paged', 0x1000 - 100), rkey=key('paged'))      # ends exactly at the boundary
    W(s, 100, src=0x80, raddr=va('paged', 0x1000), rkey=key('paged'))            # starts exactly at the boundary
    W(s, 512, src=0x100, raddr=va('paged', 0x2000 - 256), rkey=key('paged'))      # frames [..0x1F00,0x2000) [0x2000,..)
    s.barrier()
    s.dump('B', pa('paged', 0xF00), 0x1400)
    D(s, 'B', WDST, 0x1000 - 100, 200)


@sc('invalidated_remote_region')
def _(s):
    """B invalidates the region (valid, idle) and A then writes with its key: rejected with BAD_KEY"""
    W(s, 64, dst=0)
    s.barrier()
    s.cmd('mr_inval', ep='B', idx=MRS['main']['idx'])
    W(s, 64, src=0x100, dst=0x100)
    W(s, 64, src=0x200, dst=0x200)
    s.barrier()
    D(s, 'B', WDST, 0, 0x300)


@sc('invalidated_local_region')
def _(s):
    s.cmd('mr_inval', ep='A', idx=MRS['main']['idx'])
    W(s, 64, dst=0)
    W(s, 64, dst=0x100)
    s.barrier()
    D(s, 'B', WDST, 0, 0x200)


@sc('invalidate_then_reregister')
def _(s):
    """MR_INVAL then MR_SET of the slot with a new key: the old key is dead, the new key works; ERR_NOENT on re-inval"""
    W(s, 64, dst=0)
    s.barrier()
    s.cmd('mr_inval', ep='B', idx=MRS['main']['idx'])
    s.cmd('mr_inval', ep='B', idx=MRS['main']['idx'])                  # ERR_NOENT
    m = MRS['main']
    s.cmd('mr', ep='B', idx=m['idx'], va=m['va'], len=m['len'], pa=m['pa'], key=0x7777, pd=1, acc=m['acc'], ctx=0)
    W(s, 64, src=0x100, dst=0x100, rkey=0x7777)
    s.barrier()
    D(s, 'B', WDST, 0, 0x200)


@sc('invalidated_old_key_after_reregister')
def _(s):
    s.cmd('mr_inval', ep='B', idx=MRS['main']['idx'])
    m = MRS['main']
    s.cmd('mr', ep='B', idx=m['idx'], va=m['va'], len=m['len'], pa=m['pa'], key=0x7777, pd=1, acc=m['acc'], ctx=0)
    W(s, 64, dst=0)                                                    # old key K
    W(s, 64, src=0x100, dst=0x100, rkey=0x7777)
    s.barrier()
    D(s, 'B', WDST, 0, 0x200)


@sc('mr_busy_with_stuck_wqe')
def _(s):
    """ERR_BUSY: A's WQE is stuck (forward link black) and holds a grant on A's region; MR_INVAL is refused; after a QP
    reset (references cleared, flush) MR_INVAL succeeds"""
    s.cmd('link_black', dir='AB', on=1)
    W(s, 64, dst=0, wr_id=1)
    s.run(300)
    s.cmd('mr_inval', ep='A', idx=MRS['main']['idx'])                  # ERR_BUSY
    s.cmd('reset', ep='A', kind='qp')
    s.cmd('mr_inval', ep='A', idx=MRS['main']['idx'])                  # OK
    s.cmd('link_black', dir='AB', on=0)
    s.barrier()


@sc('ctx_disabled_remote')
def _(s):
    """region bound to mapping context 1 while ctx_en = 0b0001 -> XLATE"""
    fault_frame(s, lambda s: W(s, 16, src=0x80, raddr=va('ctx1', 0), rkey=key('ctx1')))


@sc('ctx_enabled_remote')
def _(s):
    s.cmd('ctx_en', ep='B', mask=0x3)
    s.fill('B', pa('ctx1', 0), 0x1000, 0x5A)
    W(s, 64, raddr=va('ctx1', 0), rkey=key('ctx1'))
    R(s, 64, raddr=va('ctx1', 0), rkey=key('ctx1'))
    s.barrier()
    s.dump('B', pa('ctx1', 0), 128)
    D(s, 'A', RDST, 0, 64)


@sc('ctx_disable_live_context')
def _(s):
    """ctx_en = 0b0010 disables context 0 (which `main` uses): the region is no longer reachable"""
    s.cmd('ctx_en', ep='B', mask=0x2)
    fault_frame(s, lambda s: W(s, 16, src=0x80, dst=0x80))


@sc('ctx_disabled_local')
def _(s):
    s.cmd('ctx_en', ep='A', mask=0x2)
    fault_frame(s, lambda s: W(s, 16, src=0x80, dst=0x80))


@sc('mr_bad_key_then_good_traffic')
def _(s):
    """a run of rejected-at-post and accepted WQEs: after the fatal NAK nothing further is processed"""
    W(s, 32, dst=0)
    W(s, 32, dst=0x40, rkey=0)
    s.barrier()
    D(s, 'B', WDST, 0, 0x100)


# ---------------------------------------------------------------------------
# post-port validation (6.3) and configuration status codes
# ---------------------------------------------------------------------------
@sc('post_unsupported_opcode')
def _(s):
    """op = 4, 0, 15 at the post port: POST_ERR_OPCODE, nothing enqueued, no CQE, QP unaffected, traffic continues"""
    for op in (4, 0, 15):
        s.post('A', op, mva(SRC), K, 16, mva(WDST), K)
    W(s, 64, dst=0)
    s.post('A', 7, mva(SRC), K, 16, mva(WDST), K)
    W(s, 64, src=0x100, dst=0x100)
    s.barrier()
    D(s, 'B', WDST, 0, 0x200)


@sc('post_status_matrix')
def _(s):
    """every post status: LEN (zero WRITE/READ, > MAX_MSG), FIELDS, OPCODE-before-FIELDS, RANGE (wraps by one byte), RQ RANGE,
    RQ LEN (literal reading of 6.3), RQ len 0 accepted; followed by a valid WRITE proving the QP is untouched"""
    s.post('A', 'WRITE', mva(SRC), K, 0, mva(WDST), K)                      # LEN (zero WRITE)
    s.post('A', 'READ', mva(RDST), K, 0, mva(RSRC), K)                      # LEN (zero READ)
    s.post('A', 'SEND', mva(SRC), K, (1 << 20) + 1)                         # LEN (> MAX_MSG)
    s.post('A', 'SEND', mva(SRC), K, 16, flags=1)                           # FIELDS
    s.post('A', 4, mva(SRC), K, 16, flags=1)                                # OPCODE beats FIELDS
    s.post('A', 'WRITE', mva(SRC), K, 16, (1 << 64) - 8, K)                 # RANGE
    s.post('A', 'READ', mva(RDST), K, 16, (1 << 64) - 15, K)                # RANGE (wraps by one byte)
    s.post_recv('B', (1 << 64) - 8, K, 16)                                  # RQ RANGE
    s.post_recv('B', mva(RQB), K, (1 << 20) + 1)                            # RQ LEN
    s.post_recv('B', mva(RQB), K, 0)                                        # RQ len 0 is accepted
    W(s, 64, dst=0)
    s.barrier()
    D(s, 'B', WDST, 0, 0x100)


@sc('post_status_state')
def _(s):
    """posts while the QP is not RTS: SQ rejected with STATE in RESET/INIT/RTR/ERR; RQ accepted in INIT/RTR only"""
    s2 = s
    s2.cmd('qp', ep='A', state='RESET')                                      # A leaves RTS
    s2.post('A', 'SEND', mva(SRC), K, 8, track=False)                        # STATE (RESET)
    s2.post_recv('A', mva(RQB), K, 8, wr_id=1)                               # RQ in RESET: STATE
    s2.cmd('qp', ep='A', state='INIT', qpn=1, pd=1)
    s2.post('A', 'SEND', mva(SRC), K, 8, track=False)                        # STATE (INIT)
    s2.post_recv('A', mva(RQB), K, 8, wr_id=2)                               # RQ in INIT: OK
    s2.cmd('qp', ep='A', state='RTR', rqpn=2, epoch=s.epoch, rq_psn=0x200, smac=MAC['A'], dmac=MAC['B'])
    s2.post('A', 'SEND', mva(SRC), K, 8, track=False)                        # STATE (RTR)
    s2.post_recv('A', mva(RQB + 0x100), K, 8, wr_id=3)                       # RQ in RTR: OK
    s2.cmd('qp', ep='A', state='ERR')
    s2.post('A', 'SEND', mva(SRC), K, 8, track=False)                        # STATE (ERR)
    s2.post_recv('A', mva(RQB + 0x200), K, 8, wr_id=4)                       # RQ in ERR: STATE
    s2.barrier()


@sc('cfg_status_matrix')
def _(s):
    """configuration status codes: MR_SET (IDX EXISTS FIELDS RANGE DUPKEY), MR_INVAL (IDX NOENT), CTX_SET, QP_MODIFY illegal
    transitions (ERR_STATE).  MR_SET status precedence is normative (8.2): IDX, EXISTS, FIELDS, RANGE, DUPKEY.  A pd / ctx wider
    than the port cannot be presented and is not a status.  Assumes PA_W=32 (see build line)."""
    e = 'A'
    s.cmd('mr', ep=e, idx=8, va=0x1000, len=16, pa=0, key=0x2001, pd=1, acc=0x1F, ctx=0)                 # ERR_IDX
    s.cmd('mr', ep=e, idx=7, va=0x1000, len=16, pa=0, key=0x2001, pd=1, acc=0x1F, ctx=0)                 # EXISTS (idx7 used)
    s.cmd('mr_inval', ep=e, idx=7)
    s.cmd('mr', ep=e, idx=7, va=0x1000, len=0, pa=0, key=0x2001, pd=1, acc=0x1F, ctx=0)                  # FIELDS len=0
    s.cmd('mr', ep=e, idx=7, va=0x1000, len=16, pa=0, key=0x2001, pd=1, acc=0x3F, ctx=0)                 # FIELDS reserved acc bit
    s.cmd('mr', ep=e, idx=7, va=(1 << 64) - 8, len=16, pa=0, key=0x2001, pd=1, acc=0x1F, ctx=0)          # ERR_RANGE va wrap
    s.cmd('mr', ep=e, idx=7, va=0x1000, len=16, pa=(1 << 32) - 8, key=0x2001, pd=1, acc=0x1F, ctx=0)     # ERR_RANGE pa overflow
    s.cmd('mr', ep=e, idx=7, va=0x1000, len=16, pa=0, key=K, pd=1, acc=0x1F, ctx=0)                      # ERR_DUPKEY
    s.cmd('mr', ep=e, idx=7, va=(1 << 64) - 16, len=16, pa=(1 << 32) - 16, key=0x2001, pd=1, acc=0x1F, ctx=0)  # exactly fits: OK
    s.cmd('mr_inval', ep=e, idx=7)                                                                         # OK
    s.cmd('mr_inval', ep=e, idx=7)                                                                         # ERR_NOENT
    s.cmd('mr_inval', ep=e, idx=9)                                                                         # ERR_IDX
    s.cmd('ctx_en', ep=e, mask=0xF)
    s.cmd('ctx_en', ep=e, mask=0x1)
    s.cmd('qp', ep=e, state='INIT', qpn=1, pd=1)                       # RTS -> INIT illegal
    s.cmd('qp', ep=e, state='RTR', rqpn=2, epoch=1, rq_psn=0, smac=1, dmac=2)   # RTS -> RTR illegal
    s.cmd('qp', ep=e, state='RESET')
    s.cmd('qp', ep=e, state='RTR', rqpn=2, epoch=1, rq_psn=0, smac=1, dmac=2)   # RESET -> RTR illegal
    s.cmd('qp', ep=e, state='RTS', sq_psn=0, timeout=100, retry=1, rnr_retry=1, rnr_delay=10)  # RESET -> RTS illegal
    s.cmd('qp', ep=e, state='ERR')                                      # RESET -> ERR illegal
    s.cmd('qp', ep=e, state='INIT', qpn=1, pd=1)
    s.cmd('qp', ep=e, state='INIT', qpn=1, pd=1)                       # INIT -> INIT illegal
    s.cmd('qp', ep=e, state='RTS', sq_psn=0, timeout=100, retry=1, rnr_retry=1, rnr_delay=10)  # INIT -> RTS illegal
    s.cmd('qp', ep=e, state='ERR')                                      # forced error
    s.cmd('qp', ep=e, state='ERR')                                      # ERR -> ERR accepted
    s.cmd('qp', ep=e, state='INIT', qpn=1, pd=1)                       # ERR -> INIT illegal
    s.cmd('qp', ep=e, state='RESET')
    s.barrier()


# ---------------------------------------------------------------------------
# unsupported opcodes on the wire, malformed frames
# ---------------------------------------------------------------------------
for _op in (0x05, 0x04, 0x0F, 0x08):
    def _mk(op):
        @sc('wire_unsupported_opcode_%02x' % op)
        def _(s):
            """reserved request opcode 0x%02X, in order (same PSN as A's waiting SEND): fatal INV_REQ -> NAK(INV_REQ), B -> ERR,
            rx_unsupported_op; A's WQE completes REM_INV_REQ_ERR""" % op
            wire_fatal(s, lambda p: F.build_frame(MAC['B'], MAC['A'], op, QPN['B'], s.epoch, p, flags=3, mlen=0))
    _mk(_op)


@sc('wire_invreq_write_zero_paylen')
def _(s):
    """well-formed frame that violates 7.4: WRITE with paylen 0 -> fatal INV_REQ (no rx_unsupported_op)"""
    wire_fatal(s, lambda p: F.request_frame(peer_ab(s), 'WRITE', p, mlen=0, va=mva(WDST), rkey=K))


@sc('wire_invreq_first_flag')
def _(s):
    """SEND segment with FIRST=0 but moff=0: INV_REQ"""
    wire_fatal(s, lambda p: F.request_frame(peer_ab(s), 'SEND', p, payload=bytes(8), mlen=8, flags=F.FLAG_LAST))


@sc('wire_opcodes_outside_spec_dropped')
def _(s):
    """opcodes outside 3.3 are dropped and counted (rx_drop_opcode) at the adapter, whatever the PSN; traffic unaffected"""
    W(s, 64, dst=0)
    s.barrier()
    for op in (0x30, 0x00, 0x22, 0x11, 0xFF, 0x1F):
        inject(s, 'AB', F.build_frame(MAC['B'], MAC['A'], op, QPN['B'], s.epoch, s.psn['A'], flags=3, mlen=0))
        inject(s, 'BA', F.build_frame(MAC['A'], MAC['B'], op, QPN['A'], s.epoch, s.psn['B'], flags=3, mlen=0))
    W(s, 64, src=0x100, dst=0x100)
    s.barrier()
    D(s, 'B', WDST, 0, 0x200)


def good_write_frame(s, psn, dst=0x300, n=32, **kw):
    d = dict(payload=payload(9, n), mlen=n, va=mva(WDST + dst), rkey=K)
    d.update(kw)
    return F.request_frame(peer_ab(s), 'WRITE', psn, **d)


@sc('inject_malformed_frames')
def _(s):
    """frames the adapter must drop whole and count: bad ethertype, wrong epoch, wrong qpn, wrong dst/src mac, bad
    version, reserved flag set, runt, 59 byte frame, header/length mismatch, paylen > MTU, ACK with payload, over-long
    frame.  Real traffic before and after is unaffected; no memory is touched by the injected frames."""
    W(s, 64, dst=0)
    s.barrier()
    p = s.psn['A']
    good = good_write_frame(s, p)
    cases = [
        ('rx_drop_ethertype', good_write_frame(s, p, ethertype=0x0800)),
        ('rx_drop_epoch', good_write_frame(s, p, epoch=s.epoch + 1)),
        ('rx_drop_qpn', good_write_frame(s, p, qpn=0x1234)),
        ('rx_drop_mac', good_write_frame(s, p, dst_mac=MAC['A'])),
        ('rx_drop_mac', good_write_frame(s, p, src_mac=0x0200000000FF)),
        ('rx_drop_ver', good_write_frame(s, p, ver=2)),
        ('rx_drop_ver', good_write_frame(s, p, flags=F.FLAG_FIRST | F.FLAG_LAST | F.FLAG_RSVD)),
        ('rx_drop_len', good[:30]),
        ('rx_drop_len', good[:47]),
        ('rx_drop_len', good[:59]),
        ('rx_drop_len', good + b'\0' * 7),
        ('rx_drop_len', F.build_frame(MAC['B'], MAC['A'], F.OP_WRITE, QPN['B'], s.epoch, p, flags=3, mlen=100, paylen=100,
                                      va=mva(WDST + 0x300), rkey=K)),                       # header says 100, frame is 60
        ('rx_drop_len', good_write_frame(s, p, payload=bytes(300), mlen=300)),             # paylen > MTU
        ('rx_drop_len', F.build_frame(MAC['B'], MAC['A'], F.OP_ACK, QPN['B'], s.epoch, p, paylen=4, payload=bytes(4))),
        ('rx_drop_len', F.build_frame(MAC['B'], MAC['A'], F.OP_READ_REQ, QPN['B'], s.epoch, p, flags=3, mlen=8, paylen=2,
                                      payload=bytes(2))),
    ]
    for _, fr in cases:
        inject(s, 'AB', fr)
    s.barrier()
    W(s, 64, src=0x100, dst=0x100)
    s.barrier()
    D(s, 'B', WDST, 0, 0x400)


@sc('inject_malformed_frames_to_requester')
def _(s):
    """the same malformed classes towards the requester side (ACK-shaped frames): all dropped and counted, nothing disturbed"""
    W(s, 64, dst=0)
    s.barrier()
    a = lambda **kw: F.ack_frame(peer_ba(s), s.psn['A'], s.psn['B'], **kw)
    for fr in (a(ethertype=0x86DD), a(epoch=s.epoch + 3), a(qpn=7), a(dst_mac=MAC['B']), a(ver=0), a()[:40], a()[:59]):
        inject(s, 'BA', fr)
    s.barrier()
    W(s, 64, src=0x100, dst=0x100)
    s.barrier()
    D(s, 'B', WDST, 0, 0x200)


@sc('inject_stale_ack_and_badcode')
def _(s):
    """well-formed but useless control frames at the requester: stale ACK (cumulative point beyond anything sent),
    NAK with an undefined code (ignored, rx_nak_badcode), READ_RESP for no outstanding READ (rx_resp_drop)"""
    W(s, 64, dst=0)
    s.barrier()
    nxt = s.psn['A']
    inject(s, 'BA', F.ack_frame(peer_ba(s), (nxt + 5) & 0xFFFFFF, (nxt + 5) & 0xFFFFFF))                  # stale
    inject(s, 'BA', F.ack_frame(peer_ba(s), (nxt - 9) & 0xFFFFFF, (nxt - 9) & 0xFFFFFF))                  # stale (old)
    inject(s, 'BA', F.ack_frame(peer_ba(s), nxt, nxt, code=9, nak=True))                                    # bad NAK code
    inject(s, 'BA', F.build_frame(MAC['A'], MAC['B'], F.OP_READ_RESP, QPN['A'], s.epoch, nxt, flags=3, payload=bytes(16),
                                  mlen=16, moff=0))
    s.barrier()
    W(s, 64, src=0x100, dst=0x100)
    s.barrier()
    D(s, 'B', WDST, 0, 0x200)


@sc('stale_duplicate_must_not_overwrite')
def _(s):
    """WRITE X, WRITE Y to the same address (committed, barrier between), then a duplicate of X's frame (older PSN, same
    epoch) is delivered: memory must still hold Y; exactly one write per byte per accepted op (2 per byte overall)"""
    a1 = W(s, 200, src=0, dst=0x40, wr_id=1)
    s.barrier()
    a2 = W(s, 200, src=0x400, dst=0x40, wr_id=2)
    s.barrier()
    dup = F.request_frame(peer_ab(s), 'WRITE', s.psn_of[('A', a1)], payload=payload(0x11, 200), mlen=200,
                          va=mva(WDST + 0x40), rkey=K, flags=F.FLAG_FIRST | F.FLAG_LAST | F.FLAG_RETX)
    inject(s, 'AB', dup)
    s.barrier()
    inject(s, 'AB', dup)
    s.barrier()
    D(s, 'B', WDST, 0, 0x180)


@sc('stale_duplicate_multisegment')
def _(s):
    """same with a 3-segment WRITE X overwritten by Y; then ALL segments of X are re-delivered as duplicates"""
    a1 = W(s, 700, src=0, dst=0x40, wr_id=1)
    s.barrier()
    a2 = W(s, 700, src=0x800, dst=0x40, wr_id=2)
    s.barrier()
    p0 = s.psn_of[('A', a1)]
    for i, (moff, pl) in enumerate(M_segments(700)):
        inject(s, 'AB', F.request_frame(peer_ab(s), 'WRITE', (p0 + i) & 0xFFFFFF,
                                        payload=payload(0x11, 700)[moff:moff + pl], mlen=700, moff=moff,
                                        va=mva(WDST + 0x40 + moff), rkey=K,
                                        flags=F.segment_flags(moff, pl, 700, retx=True)))
    s.barrier()
    D(s, 'B', WDST, 0, 0x400)


def M_segments(n, mtu=MTU):
    return [(i * mtu, min(mtu, n - i * mtu)) for i in range(npsn(n, mtu))]


@sc('duplicate_read_request_reexecuted')
def _(s):
    """a duplicated READ_REQ (old PSN) is re-executed against current memory and its response is dropped by the
    requester: the READ destination is written exactly once"""
    r = R(s, 300, dst=0, src=0, wr_id=1)
    s.barrier()
    p = s.psn_of[('A', r)]
    inject(s, 'AB', F.request_frame(peer_ab(s), 'READ', p, mlen=300, moff=0, va=mva(RSRC), rkey=K,
                                    flags=F.FLAG_FIRST | F.FLAG_LAST | F.FLAG_RETX))
    s.barrier()
    D(s, 'A', RDST, 0, 0x180)


# ===========================================================================
# 3. link impairments (success outcomes)
# ===========================================================================
def traffic_mix(s, n=8, with_send=True):
    """moderate A->B traffic: WRITEs, READs and SENDs with their buffers (disjoint areas)"""
    if with_send:
        for i in range(2):
            RQ(s, i * 0x400, 500, wr_id=101 + i)
    for i in range(n):
        W(s, 150 + 23 * i, src=i * 200, dst=i * 256)
        if i % 3 == 2:
            R(s, 200 + 19 * i, dst=i * 256, src=i * 256)
    if with_send:
        SND(s, 300, src=0x2000)
        SND(s, 450, src=0x2400)


def traffic_dumps(s, n=8):
    D(s, 'B', WDST, 0, n * 256)
    D(s, 'A', RDST, 0, n * 256)
    D(s, 'B', RQB, 0, 0x800)


@sc('loss_random_forward', timeout=2000, retry=7)
def _(s):
    """10% random frame loss on A->B; retransmission (go-back-N / NAK / timeout) must deliver everything exactly once"""
    s.cmd('seed', v=11)
    s.link('AB', drop=10)
    traffic_mix(s)
    s.barrier(400000)
    traffic_dumps(s)


@sc('loss_random_reverse', timeout=2000, retry=7)
def _(s):
    """10% random loss of ACKs / READ responses (B->A)"""
    s.cmd('seed', v=12)
    s.link('BA', drop=10)
    traffic_mix(s)
    s.barrier(400000)
    traffic_dumps(s)


@sc('loss_random_both', timeout=2000, retry=7)
def _(s):
    s.cmd('seed', v=13)
    s.link('AB', drop=8)
    s.link('BA', drop=8)
    traffic_mix(s, n=10)
    s.barrier(500000)
    traffic_dumps(s, 10)


@sc('loss_by_ordinal_forward_first', timeout=2000, retry=7)
def _(s):
    """link_script: the very first request frame (ordinal 1) is lost -> timeout retransmission"""
    s.cmd('link_script', dir='AB', drop=[1])
    W(s, 600, dst=0)
    W(s, 100, src=0x400, dst=0x400)
    s.barrier(100000)
    D(s, 'B', WDST, 0, 0x500)


@sc('loss_by_ordinal_forward_middle', timeout=2000, retry=7)
def _(s):
    """a middle frame of a 5-segment WRITE is lost: NAK(SEQ_ERR) / go-back-N recovery"""
    s.cmd('link_script', dir='AB', drop=[3])
    W(s, 1200, dst=0)
    W(s, 100, src=0x600, dst=0x600)
    s.barrier(100000)
    D(s, 'B', WDST, 0, 0x700)


@sc('loss_by_ordinal_forward_multiple', timeout=2000, retry=7)
def _(s):
    s.cmd('link_script', dir='AB', drop=[1, 2, 4, 7, 8])
    for i in range(6):
        W(s, 300, src=i * 300, dst=i * 300)
    s.barrier(200000)
    D(s, 'B', WDST, 0, 6 * 300)


@sc('loss_by_ordinal_reverse', timeout=2000, retry=7)
def _(s):
    """first ACK / response frames are lost on the reverse path (READ responses included)"""
    s.cmd('link_script', dir='BA', drop=[1, 2])
    W(s, 400, dst=0)
    R(s, 700, dst=0, src=0)
    s.barrier(200000)
    D(s, 'B', WDST, 0, 0x400)
    D(s, 'A', RDST, 0, 0x300 + 0x100)


@sc('loss_by_ordinal_last_ack', timeout=1000, retry=7)
def _(s):
    """the final ACK of the stream is lost: the requester must still complete (timeout, duplicate request, fresh ACK)"""
    s.cmd('link_script', dir='BA', drop=[1, 2, 3, 4, 5, 6])
    W(s, 100, dst=0)
    s.barrier(200000)
    D(s, 'B', WDST, 0, 0x100)


@sc('loss_read_request_lost', timeout=1000, retry=7)
def _(s):
    s.cmd('link_script', dir='AB', drop=[1])
    R(s, 500, dst=0, src=0)
    s.barrier(100000)
    D(s, 'A', RDST, 0, 0x200)


@sc('loss_send_with_rnr_and_loss', timeout=2000, retry=7, rnr_retry=7, rnr_delay=200)
def _(s):
    s.cmd('link_script', dir='AB', drop=[2])
    RQ(s, 0, 1200, wr_id=101)
    SND(s, 1000)
    s.barrier(200000)
    D(s, 'B', RQB, 0, 1024)


@sc('duplicate_random', timeout=2000, retry=7)
def _(s):
    """30% frame duplication both ways: duplicates are idempotent (each byte written exactly once, one CQE per WQE)"""
    s.cmd('seed', v=14)
    s.link('AB', dup=30)
    s.link('BA', dup=30)
    traffic_mix(s)
    s.barrier(200000)
    traffic_dumps(s)


@sc('duplicate_by_ordinal', timeout=2000, retry=7)
def _(s):
    """link_script: duplicate frames 1..4 of a multi-segment WRITE and the first ACKs"""
    s.cmd('link_script', dir='AB', dup=[1, 2, 3, 4])
    s.cmd('link_script', dir='BA', dup=[1, 2])
    W(s, 1000, dst=0)
    W(s, 100, src=0x400, dst=0x400)
    R(s, 300, dst=0, src=0)
    s.barrier(100000)
    D(s, 'B', WDST, 0, 0x500)
    D(s, 'A', RDST, 0, 0x180)


@sc('duplicate_write_overwrite_order', timeout=2000, retry=7)
def _(s):
    """WRITE X, barrier, WRITE Y same address, with every frame duplicated: final contents are Y's"""
    s.cmd('link_script', dir='AB', dup=[1, 2, 3, 4, 5, 6])
    W(s, 500, src=0, dst=0x40)
    s.barrier(100000)
    W(s, 500, src=0x800, dst=0x40)
    s.barrier(100000)
    D(s, 'B', WDST, 0, 0x300)


@sc('reorder_random_delay', timeout=3000, retry=7)
def _(s):
    """uniform delay spread 5..400 cycles on both directions (reordering): the protocol sorts it out"""
    s.cmd('seed', v=15)
    s.link('AB', delay_min=5, delay_max=400, reorder=40)
    s.link('BA', delay_min=5, delay_max=400, reorder=40)
    traffic_mix(s)
    s.barrier(400000)
    traffic_dumps(s)


@sc('reorder_by_ordinal_delay', timeout=3000, retry=7)
def _(s):
    """link_script delays frame 2 by 300 cycles (arrives after frames 3,4): out of sequence -> NAK / retransmit"""
    s.cmd('link_script', dir='AB', delay=[(2, 300)])
    W(s, 1200, dst=0)
    s.barrier(100000)
    D(s, 'B', WDST, 0, 0x500)


@sc('delayed_ack_spurious_retransmit', timeout=800, retry=7)
def _(s):
    """every B->A frame is delayed by 1500 cycles (> timeout 800): the requester retransmits spuriously; the responder
    sees duplicates (no re-execution), everything completes once"""
    s.link('BA', delay_min=1500, delay_max=1500)
    W(s, 300, dst=0)
    W(s, 300, src=0x400, dst=0x400)
    R(s, 200, dst=0, src=0)
    s.barrier(200000)
    D(s, 'B', WDST, 0, 0x600)
    D(s, 'A', RDST, 0, 0x100)


@sc('delayed_forward_spurious_retransmit', timeout=800, retry=7)
def _(s):
    """every A->B frame delayed 1200 cycles (> timeout): duplicates arrive behind the originals"""
    s.link('AB', delay_min=1200, delay_max=1200)
    W(s, 300, dst=0)
    W(s, 300, src=0x400, dst=0x400)
    s.barrier(200000)
    D(s, 'B', WDST, 0, 0x600)


@sc('retry_then_success_black_forward', timeout=1000, retry=5)
def _(s):
    """A->B link black for 1500 cycles: first retransmission (at ~1000) is lost, the second (~3000) gets through;
    the application sees only latency (retry_timeout counter = 2)"""
    s.cmd('link_black', dir='AB', on=1)
    W(s, 400, dst=0)
    s.run(1500)
    s.cmd('link_black', dir='AB', on=0)
    s.barrier(100000)
    D(s, 'B', WDST, 0, 0x200)


@sc('retry_then_success_black_reverse', timeout=1000, retry=5)
def _(s):
    """B->A black for 1500 cycles: the request executes at B once; ACKs are lost; retransmissions are duplicates"""
    s.cmd('link_black', dir='BA', on=1)
    W(s, 400, dst=0)
    R(s, 200, dst=0, src=0)
    s.run(1500)
    s.cmd('link_black', dir='BA', on=0)
    s.barrier(100000)
    D(s, 'B', WDST, 0, 0x200)
    D(s, 'A', RDST, 0, 0x100)


@sc('timeout_black_forward_retry_exc', timeout=400, retry=3)
def _(s):
    """A->B black forever: head WQE RETRY_EXC_ERR after retry_max=3 retransmissions, the rest flushed, B's memory untouched"""
    s.cmd('link_black', dir='AB', on=1)
    W(s, 300, dst=0, wr_id=1)
    W(s, 100, src=0x400, dst=0x400, wr_id=2)
    SND(s, 50, wr_id=3)
    s.barrier(60000)
    D(s, 'B', WDST, 0, 0x500)


@sc('timeout_black_reverse_retry_exc', timeout=400, retry=3)
def _(s):
    """B->A black forever: requests ARE executed once (remote memory changed), but the requester only ever sees silence:
    head WQE RETRY_EXC_ERR, the others WR_FLUSH_ERR although their effect happened (11.3).  4 WRITEs = 4 PSNs: within WINDOW"""
    s.cmd('link_black', dir='BA', on=1)
    for i in range(4):
        W(s, 200, src=i * 200, dst=i * 256, wr_id=i + 1)
    s.barrier(60000)
    D(s, 'B', WDST, 0, 4 * 256)


@sc('timeout_black_reverse_read_retry_exc', timeout=400, retry=2)
def _(s):
    """B->A black: the READ is executed (source read, response lost); requester ends RETRY_EXC, destination untouched"""
    s.cmd('link_black', dir='BA', on=1)
    R(s, 600, dst=0, src=0, wr_id=1)
    W(s, 100, wr_id=2)
    s.barrier(60000)
    D(s, 'A', RDST, 0, 0x300)
    D(s, 'B', WDST, 0, 0x100)


@sc('timeout_black_forward_after_good_ops', timeout=400, retry=2)
def _(s):
    """two WQEs complete, the link then dies: the next WQE is the head and fails, the rest flush"""
    W(s, 200, dst=0, wr_id=1)
    R(s, 200, dst=0, src=0, wr_id=2)
    s.barrier()
    s.cmd('link_black', dir='AB', on=1)
    W(s, 200, src=0x400, dst=0x400, wr_id=3)
    W(s, 200, src=0x800, dst=0x800, wr_id=4)
    s.barrier(60000)
    D(s, 'B', WDST, 0, 0xA00)
    D(s, 'A', RDST, 0, 0x100)


@sc('rnr_recv_posted_late', timeout=3000, retry=7, rnr_retry=7, rnr_delay=400)
def _(s):
    """SEND arrives before any receive WQE exists: RNR NAK, the requester waits rnr_delay (400) and retries; the RQE is
    posted 300 cycles later and the SEND then succeeds on the second try"""
    SND(s, 300, wr_id=1)
    s.run(300)
    RQ(s, 0, 512, wr_id=101)
    s.barrier(100000)
    D(s, 'B', RQB, 0, 0x140)


@sc('rnr_two_sends_one_rqe_late', timeout=3000, retry=7, rnr_retry=7, rnr_delay=400)
def _(s):
    """first SEND has its receive WQE, the second one finds the RQ empty (RNR) until its RQE is posted 300 cycles later"""
    RQ(s, 0, 128, wr_id=101)
    SND(s, 100, wr_id=1)
    s.barrier()
    SND(s, 90, src=0x100, wr_id=2)
    s.run(300)
    RQ(s, 0x400, 128, wr_id=102)
    s.barrier(100000)
    D(s, 'B', RQB, 0, 0x500)


@sc('rnr_never_posted', timeout=3000, retry=7, rnr_retry=3, rnr_delay=200)
def _(s):
    """no receive WQE ever: after rnr_retry_max=3 RNR retries the SEND completes RNR_RETRY_EXC_ERR; the preceding WRITE
    is OK, the following WRITE is flushed"""
    W(s, 100, dst=0, wr_id=1)
    SND(s, 100, wr_id=2)
    W(s, 100, src=0x100, dst=0x100, wr_id=3)
    s.barrier(60000)
    D(s, 'B', WDST, 0, 0x200)


@sc('rnr_retry_zero', timeout=3000, retry=7, rnr_retry=0, rnr_delay=200)
def _(s):
    SND(s, 40, wr_id=1)
    s.barrier(60000)


@sc('rnr_flushes_own_receive_queue', timeout=3000, retry=7, rnr_retry=1, rnr_delay=100)
def _(s):
    """requester A has two unconsumed receive WQEs when its SEND exhausts RNR retries: they are flushed (RECV CQEs)"""
    RQ(s, 0, 64, ep='A', wr_id=201)
    RQ(s, 0x100, 64, ep='A', wr_id=202)
    SND(s, 40, wr_id=1)
    s.barrier(60000)


@sc('qp_reset_mid_traffic_new_epoch', timeout=3000, retry=7)
def _(s):
    """traffic, then a stuck WQE batch is flushed by a QP reset (link black so nothing completes), both QPs are
    re-established with a NEW epoch and fresh PSNs, traffic resumes, and a frame of the old epoch is injected: dropped
    (rx_drop_epoch) without touching memory"""
    W(s, 200, dst=0, wr_id=1)
    R(s, 100, dst=0, src=0, wr_id=2)
    s.barrier()
    s.cmd('link_black', dir='AB', on=1)
    RQ(s, 0, 64, ep='A', wr_id=201)
    for i in range(3):
        W(s, 100, src=i * 128, dst=0x400 + i * 128, wr_id=10 + i)
    s.run(300)
    s.cmd('reset', ep='A', kind='qp')                                   # flush: 3 WRITE CQEs + the RQE
    s.cmd('link_black', dir='AB', on=0)
    s.cmd('reset', ep='B', kind='qp')
    s.qp_up('A', epoch=2, rq_psn=0x600, sq_psn=0x500)
    s.qp_up('B', epoch=2, rq_psn=0x500, sq_psn=0x600)
    s.epoch = 2
    s.psn = {'A': 0x500, 'B': 0x600}
    W(s, 300, src=0x800, dst=0x800, wr_id=20)
    R(s, 200, dst=0x200, src=0, wr_id=21)
    RQ(s, 0, 128, wr_id=101)
    SND(s, 100, src=0x900, wr_id=22)
    s.barrier()
    old = F.request_frame(peer_ab(s, epoch=1), 'WRITE', s.psn['A'], payload=payload(5, 64), mlen=64, va=mva(WDST + 0x2000),
                          rkey=K)
    inject(s, 'AB', old)
    inject(s, 'BA', F.ack_frame(peer_ba(s, epoch=1), s.psn['A'], s.psn['A']))
    s.barrier()
    W(s, 100, src=0xA00, dst=0xA00, wr_id=23)
    s.barrier()
    D(s, 'B', WDST, 0x800, 300)
    D(s, 'B', WDST, 0xA00, 100)
    D(s, 'B', WDST, 0x2000, 64)
    D(s, 'B', WDST, 0, 0x400)
    D(s, 'A', RDST, 0x200, 200)
    D(s, 'B', RQB, 0, 128)


@sc('qp_reset_idle_then_reestablish', timeout=3000, retry=7)
def _(s):
    """quiet QP reset of both sides (nothing outstanding), re-init with a different epoch and PSNs, traffic again;
    memory regions survive the reset"""
    W(s, 300, dst=0)
    s.barrier()
    for ep in 'AB':
        s.cmd('reset', ep=ep, kind='qp')
    s.qp_up('A', epoch=7, rq_psn=0xFFFFF8, sq_psn=0x10)
    s.qp_up('B', epoch=7, rq_psn=0x10, sq_psn=0xFFFFF8)
    s.epoch = 7
    s.psn = {'A': 0x10, 'B': 0xFFFFF8}
    W(s, 300, src=0x400, dst=0x400)
    W(s, 300, src=0x400, dst=0x800, ep='B')
    s.barrier()
    D(s, 'B', WDST, 0, 0x600)
    D(s, 'A', WDST, 0x800, 300)


@sc('qp_forced_err_flushes', timeout=3000, retry=7)
def _(s):
    """forced ERR (configuration) with WQEs in flight (stuck behind a black link) and posted receive WQEs: everything
    unfinished flushes in queue order; further posts are rejected (STATE)"""
    s.cmd('link_black', dir='AB', on=1)
    RQ(s, 0, 64, ep='A', wr_id=201)
    RQ(s, 0x100, 64, ep='A', wr_id=202)
    W(s, 100, wr_id=1)
    SND(s, 100, wr_id=2)
    W(s, 100, src=0x100, dst=0x100, wr_id=3)
    s.run(300)
    s.cmd('qp', ep='A', state='ERR')
    RQ(s, 0x200, 64, ep='A', wr_id=203)
    s.post('A', 'WRITE', mva(SRC), K, 8, mva(WDST), K, track=False)
    s.barrier()


@sc('hard_reset_responder_then_reinit', timeout=400, retry=2)
def _(s):
    """traffic, then B takes a hard reset (registry, counters, QP all cleared): A's next WQEs are dropped as rx_drop_state,
    A ends RETRY_EXC (+flush) ; the trusted agent re-initialises B (registry + QP, new epoch) and A (reset + new QP);
    traffic resumes"""
    W(s, 200, dst=0, wr_id=1)
    s.barrier()
    s.cmd('reset', ep='B', kind='hard')
    W(s, 200, src=0x400, dst=0x400, wr_id=2)
    W(s, 100, src=0x800, dst=0x800, wr_id=3)
    s.barrier(60000)
    s.cmd('reset', ep='A', kind='qp')
    s.mrs('B')
    s.qp_up('B', epoch=9, rq_psn=0x700, sq_psn=0x800, timeout=3000, retry=7)
    s.qp_up('A', epoch=9, rq_psn=0x800, sq_psn=0x700, timeout=3000, retry=7)
    s.epoch = 9
    s.psn = {'A': 0x700, 'B': 0x800}
    W(s, 300, src=0xC00, dst=0xC00, wr_id=4)
    R(s, 200, dst=0, src=0, wr_id=5)
    s.barrier()
    D(s, 'B', WDST, 0xC00, 300)
    D(s, 'A', RDST, 0, 200)


@sc('hard_reset_requester_then_reinit', timeout=400, retry=2)
def _(s):
    """hard reset of the requester while idle, then full re-initialisation with a new epoch"""
    W(s, 200, dst=0, wr_id=1)
    s.barrier()
    s.cmd('reset', ep='A', kind='hard')
    s.cmd('reset', ep='B', kind='qp')
    s.mrs('A')
    s.qp_up('A', epoch=4, rq_psn=0x300, sq_psn=0x400, timeout=3000, retry=7)
    s.qp_up('B', epoch=4, rq_psn=0x400, sq_psn=0x300, timeout=3000, retry=7)
    s.epoch = 4
    s.psn = {'A': 0x400, 'B': 0x300}
    W(s, 300, src=0x400, dst=0x400, wr_id=2)
    R(s, 100, dst=0, src=0, wr_id=3)
    s.barrier()
    D(s, 'B', WDST, 0x400, 300)
    D(s, 'A', RDST, 0, 100)


@sc('epoch_mismatch_blackhole', timeout=300, retry=2)
def _(s):
    """peers configured with different epochs: every frame is dropped (rx_drop_epoch) and A ends RETRY_EXC"""
    s.cmd('reset', ep='B', kind='qp')
    s.qp_up('B', epoch=2, rq_psn=0x100, sq_psn=0x200, timeout=300, retry=2)
    W(s, 100, dst=0, wr_id=1)
    s.barrier(60000)
    D(s, 'B', WDST, 0, 0x100)


@sc('queue_saturation_sq')
def _(s):
    """post 20 WQEs in a burst (SQ_DEPTH = 8): the post interface back-pressures, all execute in order"""
    for i in range(20):
        W(s, 64 + i, src=i * 100, dst=i * 100)
    s.barrier()
    D(s, 'B', WDST, 0, 2000)


@sc('queue_saturation_sends')
def _(s):
    """SENDs in bursts of 4 against 4 receive WQEs (RQ depth is not assumed larger)"""
    n = 0
    for b in range(3):
        for j in range(4):
            RQ(s, (b * 4 + j) * 0x200, 300, wr_id=101 + n + j)
        for j in range(4):
            SND(s, 100 + 10 * (n + j), src=(n + j) * 128, wr_id=1 + n + j)
        s.barrier()
        n += 4
    D(s, 'B', RQB, 0, 12 * 0x200)


@sc('cq_credit_exhaustion', cq_depth=16)
def _(s):
    """host stops draining the A completion queue (cq_drain 0): CQ credit runs out after CQ_DEPTH (=16, see build line)
    posts and the post interface stalls; draining is re-enabled later and everything completes.  NOTE: needs a bench
    whose post commands do not block the command stream (see SPEC_QUESTIONS.md)"""
    s.cmd('cq_drain', ep='A', on=0)
    for i in range(24):
        W(s, 32, src=i * 40, dst=i * 40)
    s.run(3000)
    s.cmd('cq_drain', ep='A', on=1)
    s.barrier()
    D(s, 'B', WDST, 0, 24 * 40)


@sc('cq_hold_and_release')
def _(s):
    """a handful of completions are held back (cq_drain 0) and released later; fewer posts than any sane CQ depth"""
    s.cmd('cq_drain', ep='A', on=0)
    s.cmd('cq_drain', ep='B', on=0)
    RQ(s, 0, 128, wr_id=101)
    for i in range(3):
        W(s, 32, src=i * 40, dst=i * 40)
    SND(s, 60)
    s.run(1500)
    s.cmd('cq_drain', ep='A', on=1)
    s.cmd('cq_drain', ep='B', on=1)
    s.barrier()
    D(s, 'B', WDST, 0, 128)
    D(s, 'B', RQB, 0, 64)


@sc('window_saturation_many_segments')
def _(s):
    """a 12 KiB WRITE (48 segments) and a 6 KiB SEND saturate the 8-PSN window continuously"""
    RQ(s, 0, 6200, wr_id=101)
    W(s, 12288, src=0, dst=0)
    SND(s, 6144, src=0x2000)
    s.barrier()
    D(s, 'B', WDST, 0, 12288)
    D(s, 'B', RQB, 0, 6144)


@sc('concurrent_dma_under_loss', timeout=3000, retry=7)
def _(s):
    """bidirectional traffic with memory jitter on both ends AND 8% loss / 8% duplication / delay spread on the link"""
    s.cmd('seed', v=21)
    s.cmd('mem_lat', ep='A', min=1, max=7, stall=25)
    s.cmd('mem_lat', ep='B', min=1, max=11, stall=15)
    s.link('AB', drop=8, dup=8, delay_min=0, delay_max=150)
    s.link('BA', drop=8, dup=8, delay_min=0, delay_max=150)
    for i in range(5):
        W(s, 200 + 31 * i, src=i * 256, dst=i * 300, ep='A')
        W(s, 190 + 29 * i, src=i * 256, dst=i * 300, ep='B')
        R(s, 120 + 13 * i, dst=i * 200, src=i * 200, ep='A')
        R(s, 140 + 11 * i, dst=i * 200, src=i * 200, ep='B')
    s.barrier(800000)
    D(s, 'B', WDST, 0, 1800)
    D(s, 'A', WDST, 0, 1800)
    D(s, 'A', RDST, 0, 1000)
    D(s, 'B', RDST, 0, 1000)


@sc('rnr_with_loss_and_dup', timeout=3000, retry=7, rnr_retry=7, rnr_delay=400)
def _(s):
    s.cmd('seed', v=22)
    s.link('AB', drop=5, dup=10)
    s.link('BA', drop=5, dup=10)
    SND(s, 500, wr_id=1)
    s.run(300)
    RQ(s, 0, 600, wr_id=101)
    W(s, 300, src=0x600, dst=0, wr_id=2)
    s.barrier(400000)
    D(s, 'B', RQB, 0, 0x300)
    D(s, 'B', WDST, 0, 0x180)


@sc('lossy_read_heavy', timeout=3000, retry=7)
def _(s):
    s.cmd('seed', v=23)
    s.link('AB', drop=8)
    s.link('BA', drop=8)
    for i in range(6):
        R(s, 700, dst=i * 800, src=i * 800)
    s.barrier(600000)
    D(s, 'A', RDST, 0, 6 * 800)


@sc('post_range_exact_2_64_boundary')
def _(s):
    """raddr + len == 2^64 exactly is legal at the post port (only > 2^64 is POST_ERR_RANGE); the WQE is then rejected by
    the remote registry check (RANGE) like any other out-of-region access"""
    s.post('A', 'WRITE', mva(SRC), K, 16, (1 << 64) - 16, K, wr_id=1)
    s.post('A', 'READ', mva(RDST), K, 16, (1 << 64) - 16, K, wr_id=2)
    s.barrier()


# ---------------------------------------------------------------------------
# Added after the first simulation-mutation campaign (reports/mutation.md): each scenario below exists because a planted defect SURVIVED
# the suite without it.  (reg_range_lt, reg_key_31bits, rdgen_no_fence, ag_fatal_early, ad_ignore_macerr)
@sc('exact_fit_region_boundaries')
def _(s):
    """transfers that END EXACTLY at the last byte of a region, start at its first byte, or are one byte long at either end, for remote
    WRITE/READ/SEND and for the LOCAL buffer checks: all must be granted (off-by-one on either end of the range check)"""
    end = 0x10000
    W(s, 64, src=0, raddr=mva(end - 64))                          # remote range ends exactly at the region end
    W(s, 1, src=0x100, raddr=mva(0))                              # first byte of the region
    s.barrier()
    D(s, 'B', 0, end - 64, 64)
    D(s, 'B', 0, 0, 1)
    R(s, 64, dst=0, raddr=mva(end - 64))                          # READ of exactly the last 64 bytes (reads what the WRITE put there)
    s.barrier()
    D(s, 'A', RDST, 0, 64)
    W(s, 1, src=0x200, raddr=mva(end - 1))                        # the very last byte
    s.barrier()
    RQ(s, 0, 64, addr=mva(end - 64), wr_id=101)                   # receive buffer ending exactly at the region end
    SND(s, 64, src=0x400)
    s.barrier()
    D(s, 'B', 0, end - 64, 64)
    W(s, 64, laddr=mva(end - 64), raddr=mva(WDST + 0x500))        # LOCAL source buffer ending exactly at the region end
    R(s, 64, laddr=mva(end - 128), raddr=mva(RSRC))               # LOCAL destination ends 64 bytes before the end (control)
    s.barrier()
    D(s, 'B', WDST, 0x500, 64)


@sc('key_bit31_differs_remote')
def _(s):
    """rkey differing from a valid key ONLY in bit 31 must be an unknown key (the whole 32-bit key is compared)"""
    fault_frame(s, lambda s: W(s, 64, src=0x80, dst=0x80, rkey=K ^ 0x80000000), with_rq=True)


@sc('key_bit0_differs_remote')
def _(s):
    """rkey differing from a valid key ONLY in bit 0"""
    fault_frame(s, lambda s: W(s, 64, src=0x80, dst=0x80, rkey=K ^ 1), with_rq=True)


@sc('key_bit31_differs_local')
def _(s):
    """lkey differing from a valid key ONLY in bit 31: local protection error"""
    fault_frame(s, lambda s: W(s, 64, src=0x80, dst=0x80, lkey=K ^ 0x80000000))


@sc('read_after_write_slow_responder_memory', timeout=8000)   # (the slow commit must stay shorter than the retry timer at every data width / MTU: a spurious timeout is not what this scenario is about)
def _(s):
    """READ-after-WRITE fence with a responder memory that needs 70 cycles to COMMIT a write: the READ must still return the WRITE's
    data (without the fence it would read the old contents)"""
    s.cmd('mem_lat', ep='B', min=70, max=70, stall=0)
    W(s, 700, src=0, dst=0)
    R(s, 40, dst=0x400, raddr=mva(WDST + 660))       # a SHORT read of the tail FIRST: the words written last are still uncommitted when it arrives
    R(s, 700, dst=0, raddr=mva(WDST))
    s.barrier(600000)
    D(s, 'A', RDST, 0, 700)
    D(s, 'A', RDST, 0x400, 40)
    D(s, 'B', WDST, 0, 700)


@sc('fatal_nak_waits_for_slow_commit')
def _(s):
    """two good WRITEs followed by an access violation, responder memory slow: the fatal NAK may only leave AFTER both earlier writes
    committed, so both complete OK; the faulty one fails with REM_ACCESS_ERR; the last is flushed"""
    s.cmd('mem_lat', ep='B', min=70, max=70, stall=0)
    W(s, 256, src=0, dst=0)
    W(s, 256, src=0x100, dst=0x100)
    W(s, 64, src=0x200, dst=0x200, rkey=0xDEAD)
    W(s, 64, src=0x300, dst=0x300)
    s.barrier(600000)
    D(s, 'B', WDST, 0, 0x600)


@sc('wire_write_flagged_bad_by_mac')
def _(s):
    """a perfectly valid in-order WRITE frame whose last beat carries the MAC's error flag must be dropped whole (rx_drop_macerr) and have no
    effect; the real WRITE with the same PSN afterwards succeeds"""
    fr = F.request_frame(peer_ab(s), 'WRITE', s.psn['A'], payload=payload(0x77, 64), va=mva(WDST), rkey=K, mlen=64)
    s.cmd('inject', dir='AB', hex=F.to_hex(fr), err=1)
    s.barrier(20000)
    D(s, 'B', WDST, 0, 64)
    W(s, 64, src=0, dst=0)
    s.barrier()
    D(s, 'B', WDST, 0, 64)


@sc('retry_budget_restarts_on_progress', timeout=300, retry=2)
def _(s):
    """retry=2 and four operations that each lose their first frame once: every operation needs exactly ONE retransmission, so the budget is never
    exceeded -- provided that progress (the completion of the previous operation) restarts the consecutive-retry counter.  A counter that is never
    reset runs out at the third timeout and fails the third operation RETRY_EXC_ERR (found by mutation testing: the old suite caught this only by
    accident, through a timing-dependent random-delay scenario)"""
    s.cmd('link_script', dir='AB', drop=[1, 3, 5, 7])
    for i in range(4):
        W(s, 64, src=i * 0x40, dst=i * 0x40)
        s.barrier(100000)
    D(s, 'B', WDST, 0, 0x100)

@sc('recv_error_cqe_waits_for_older_send')
def _(s):
    """RQ completion ORDER (spec 13): B's memory is slow, so the RECV completion of the first SEND (it fits its buffer) is produced only when its
    write commits.  The second SEND is longer than its receive buffer: its LOC_LEN_ERR completion must NOT overtake the first one.  Expected RQ
    completions at B: [101 OK, 102 LOC_LEN_ERR] (found by mutation testing: the error CQE was not ordered against the commit ring)"""
    s.cmd('mem_lat', ep='B', min=300, max=300, stall=0)
    RQ(s, 0, 256, wr_id=101)
    RQ(s, 0x100, 16, wr_id=102)
    SND(s, 100)
    SND(s, 64, src=0x100)
    s.barrier(100000)
    D(s, 'B', RQB, 0, 0x110)

# ---------------------------------------------------------------------------
def build_all(outdir, only=None, check=True, verbose=True):
    import sfrt_model
    import fake_bench
    import check_results
    os.makedirs(outdir, exist_ok=True)
    for old in os.listdir(outdir):
        if old.startswith('t') and old.endswith('.scn') and old[1:3].isdigit() and only is None:
            os.remove(os.path.join(outdir, old))
    names = []
    problems = []
    for idx, (name, fn, kw) in enumerate(SCENARIOS, 1):
        fname = 't%03d_%s.scn' % (idx, name)
        if only and only not in fname:
            continue
        doc = (fn.__doc__ or '').strip()
        s = new(name, doc, **kw)
        fn(s)
        path = os.path.join(outdir, fname)
        s.write(path)
        names.append((fname, doc.split('\n')[0] if doc else ''))
        if check:
            try:
                cmds = SC.parse_scn(path)
                exp = sfrt_model.Model(cmds, fname).run()
                if exp.warnings:
                    problems.append('%s: model warnings: %s' % (fname, exp.warnings[:3]))
                if exp.notes:
                    problems.append('%s: model notes: %s' % (fname, exp.notes[:3]))
                res = SC.parse_res_text(fake_bench.make_result_text(exp))
                rep = check_results.check(exp, res, cmds)
                if rep.fail:
                    problems.append('%s: ideal result does not pass the checker: %s' % (fname, rep.fail[:3]))
                # a generated scenario must contain a final barrier-ish settle
            except Exception as e:           # noqa
                problems.append('%s: %s: %s' % (fname, type(e).__name__, e))
    if verbose:
        for f, d in names:
            print('%-52s %s' % (f, d))
        print('%d scenarios written to %s' % (len(names), outdir))
    for p in problems:
        print('PROBLEM: ' + p)
    return len(names), problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=os.path.join(HERE, '..', 'scenarios'))
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--no-check', action='store_true')
    ap.add_argument('--only')
    a = ap.parse_args()
    if a.list:
        for i, (n, fn, kw) in enumerate(SCENARIOS, 1):
            print('t%03d_%s' % (i, n))
        return 0
    n, problems = build_all(os.path.abspath(a.out), a.only, not a.no_check)
    return 1 if problems else 0


if __name__ == '__main__':
    sys.exit(main())
