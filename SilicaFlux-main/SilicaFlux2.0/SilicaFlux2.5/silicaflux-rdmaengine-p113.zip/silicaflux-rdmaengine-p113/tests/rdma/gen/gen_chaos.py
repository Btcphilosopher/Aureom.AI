#!/usr/bin/env python3
"""gen_chaos.py - CHAOS scenarios: valid random traffic with a forced QP error / reset injected at a random moment.

    python3 -I gen_chaos.py --src DIR_OF_RANDOM_SCN --seed N --out DIR [--per 2]

For each scenario of --src it writes --per variants.  A variant runs the original traffic and, at random points after the QPs are up, forces one
or both endpoints to ERR (and sometimes to RESET and back up), then finally resets both endpoints.  The outcome is NOT predicted by the reference
model (it cannot interleave a forced error with in-flight frames); it is checked by scripts/check_chaos.py with model-independent conservation
properties: every accepted post produces exactly one CQE, completions are in post order, no success after a failure, both QPs end in RESET,
and the bench's standing invariants hold (monitors, CQ credit conservation, nothing left open after a reset).
This is the class of scenario in which the independent review found F-02, F-05, F-06 and F-09: the flush / drain paths."""
import argparse, os, random, re, sys

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True); ap.add_argument("--seed", type=int, required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--per", type=int, default=2)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    rnd = random.Random(a.seed)
    n = 0
    for fn in sorted(os.listdir(a.src)):
        if not fn.endswith(".scn"): continue
        L = open(os.path.join(a.src, fn)).read().split("\n")
        up = max((i for i, l in enumerate(L) if l.startswith("qp ") and "state=RTS" in l), default=-1)
        body_idx = [i for i in range(up + 1, len(L)) if L[i].strip() and not L[i].startswith("#")]
        if not body_idx: continue
        for v in range(a.per):
            M = list(L)
            M.insert(up + 1, "option post_wait=5000 post_block=ok")        # a blocked post (queue full because the traffic was cut off) is abandoned, not an error
            ins = []                                                       # (line index, [lines to insert AFTER it])
            body_idx2 = [i + 1 for i in body_idx]                          # (shifted by the option line)
            for _ in range(rnd.choice((1, 1, 2))):
                at = rnd.choice(body_idx2)
                ep = rnd.choice("AB")
                cmds = ["run cycles=%d" % rnd.choice((5, 20, 60, 150, 400, 900, 2500)), "qp ep=%s state=ERR" % ep]
                r = rnd.random()
                if r < 0.35:                                                 # also reset it
                    cmds += ["run cycles=%d" % rnd.choice((10, 200, 1500)), "qp ep=%s state=RESET" % ep]
                ins.append((at, cmds))
            for at, cmds in sorted(ins, reverse=True):
                M[at + 1:at + 1] = cmds
            while M and not M[-1].strip(): M.pop()
            M += ["# chaos: final reset of both endpoints (every WQE must have completed once it is done)", "run cycles=300",
                  "qp ep=A state=RESET", "qp ep=B state=RESET", "run cycles=200"]
            name = "c%d_%s_v%d.scn" % (a.seed, os.path.splitext(fn)[0], v)
            open(os.path.join(a.out, name), "w").write("\n".join(M) + "\n"); n += 1
    print("wrote %d chaos scenarios to %s" % (n, a.out))

main()
