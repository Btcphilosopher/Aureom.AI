#!/usr/bin/env python3
"""gen_random.py - random scenario generator for SFRT.

    python3 -I gen_random.py --seed N --count M --out DIR [--faults] [--prefix P] [--keep-bad]

Default mode: valid mixed traffic whose outcome is SUCCESS -- random op types / lengths / alignments over the role
areas of `main`, one- or two-directional, random link (clean / loss / dup / delay+reorder / mixes) and memory latency
jitter.  The model predicts the clean outcome (+ counter bounds), so the same scenario is valid for any link profile.

--faults: SINGLE-FAULT TAILS.  Valid traffic (rounds separated by barriers), then ONE invalid operation last (post-port
rejection, local protection fault, remote protection fault, receive-buffer fault ...), optionally followed by up to two
WQEs that must be flushed.  Fault scenarios are unidirectional (only A posts sends; B may post receives) and use a clean
link, so the flush set is timing independent.

Every generated scenario is run through the model: it must not raise and must not produce determinism warnings (else it
is re-rolled with a different sub-seed).  Output files: <prefix><seed>_<index>_<kind>.scn
"""
import argparse
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'model'))

from scn_lib import (Scn, va, pa, key, MRS, MAC, QPN, SRC, RDST, WDST, RQB, RSRC, SRC_LEN, RDST_LEN, WDST_LEN, RQB_LEN,  # noqa: E402
                     RSRC_LEN, init_mem, npsn, K, MAIN_END, mva, W, R, SND, RQ, D, new)
import sfrt_model                                # noqa: E402
import scn as SC                                 # noqa: E402


class Bump:
    """bump allocator inside an area with a requested byte phase (alignment mod 8)"""

    def __init__(self, size):
        self.size, self.cur = size, 0

    def take(self, n, phase):
        off = self.cur + ((phase - self.cur) % 8)
        if off + n > self.size:
            return None
        self.cur = off + n + 1
        return off


def rand_len(rng, kind):
    r = rng.random()
    if kind == 'SEND' and r < 0.04:
        return 0
    if r < 0.35:
        n = rng.randint(1, 64)
    elif r < 0.60:
        n = rng.randint(65, 700)
    elif r < 0.80:
        n = rng.randint(1, 6) * 256 + rng.choice([-1, 0, 1])
    elif r < 0.96:
        n = rng.randint(700, 3000)
    else:
        n = rng.randint(3000, 5000)
    return max(0 if kind == 'SEND' else 1, n)


def link_profile(rng, s):
    """random link; returns (name, impaired)"""
    p = rng.random()
    if p < 0.30:
        return 'clean', False
    prof = []
    if rng.random() < 0.6:
        d = rng.randint(3, 12)
        for dr in rng.choice([('AB',), ('BA',), ('AB', 'BA')]):
            prof.append((dr, dict(drop=d)))
    if rng.random() < 0.4:
        d = rng.randint(5, 30)
        for dr in rng.choice([('AB',), ('BA',), ('AB', 'BA')]):
            prof.append((dr, dict(dup=d)))
    if rng.random() < 0.4 or not prof:
        dmax = rng.choice([40, 100, 250, 400])
        for dr in rng.choice([('AB',), ('BA',), ('AB', 'BA')]):
            prof.append((dr, dict(delay_min=rng.randint(0, 10), delay_max=dmax, reorder=rng.choice([0, 20, 40]))))
    merged = {'AB': {}, 'BA': {}}
    for dr, kv in prof:
        merged[dr].update(kv)
    desc = []
    for dr in ('AB', 'BA'):
        if merged[dr]:
            s.link(dr, **merged[dr])
            desc.append(dr + ':' + ','.join('%s=%d' % kv for kv in merged[dr].items()))
    return '+'.join(desc), True


def gen_mixed(rng, name, idx):
    s_psn = rng.choice([0x100, 0x1234, 0xFFFFF0 + rng.randint(0, 7), 0xFFFFFF, 0x7FFFF0])
    r_psn = rng.choice([0x200, 0x4321, 0xFFFFF4 + rng.randint(0, 3), 0x0])
    s = Scn(name, 'random mixed traffic (success outcome)')
    kv = dict(timeout=rng.choice([2000, 3000]), retry=7, rnr_retry=7, rnr_delay=rng.choice([200, 400]),
              psn_ab=s_psn, psn_ba=r_psn, epoch=rng.randint(1, 60000), seed=rng.randint(1, 1 << 20))
    s.setup(**kv)
    init_mem(s)
    s.comment('seed-derived profile: psn_ab=0x%X psn_ba=0x%X' % (s_psn, r_psn))
    for ep in 'AB':
        if rng.random() < 0.5:
            s.cmd('mem_lat', ep=ep, min=rng.randint(0, 3), max=rng.randint(3, 12), stall=rng.choice([0, 10, 30]))
    prof, impaired = link_profile(rng, s)
    s.comment('link profile: %s' % prof)
    dirs = rng.choice([('A',), ('B',), ('A', 'B'), ('A', 'B')])
    alloc = {}            # (mem ep, area) -> Bump

    def A_(ep, area, size):
        return alloc.setdefault((ep, area), Bump(size))

    used = {}             # (ep, area) -> max extent
    nrounds = rng.randint(1, 4)
    for rnd in range(nrounds):
        plan = []
        for _ in range(rng.randint(2, 12)):
            plan.append((rng.choice(dirs), rng.choice(['WRITE', 'WRITE', 'READ', 'SEND', 'SEND'])))
        nsend = {'A': 0, 'B': 0}
        ops = []
        for X, kind in plan:
            Y = 'B' if X == 'A' else 'A'
            n = rand_len(rng, kind)
            sphase = rng.randint(0, 7)
            src_off = rng.randint(0, SRC_LEN - 6000 - 8) // 8 * 8 + sphase
            if kind == 'WRITE':
                d = A_(Y, WDST, WDST_LEN).take(n, rng.randint(0, 7))
                if d is None:
                    continue
                ops.append(('W', X, n, src_off, d))
                used[(Y, WDST)] = max(used.get((Y, WDST), 0), d + n)
            elif kind == 'READ':
                d = A_(X, RDST, RDST_LEN).take(n, rng.randint(0, 7))
                if d is None or n > RSRC_LEN - 16:
                    continue
                so = rng.randint(0, RSRC_LEN - n - 8)
                ops.append(('R', X, n, d, so))
                used[(X, RDST)] = max(used.get((X, RDST), 0), d + n)
            else:
                if nsend[X] >= 4:
                    continue
                rl = n + rng.choice([0, 0, 1, 7, 64])
                rq = A_(Y, RQB, RQB_LEN).take(rl, rng.randint(0, 7))
                if rq is None:
                    continue
                nsend[X] += 1
                ops.append(('S', X, n, src_off, (rq, rl)))
                used[(Y, RQB)] = max(used.get((Y, RQB), 0), rq + rl)
        # receive buffers first (never more than 4 outstanding per responder), then the pipelined WQEs
        for X in ('A', 'B'):
            Y = 'B' if X == 'A' else 'A'
            for o in ops:
                if o[0] == 'S' and o[1] == X:
                    RQ(s, o[4][0], o[4][1], ep=Y)
        for o in ops:
            if o[0] == 'W':
                W(s, o[2], src=o[3], dst=o[4], ep=o[1])
            elif o[0] == 'R':
                R(s, o[2], dst=o[3], src=o[4], ep=o[1])
            else:
                SND(s, o[2], src=o[3], ep=o[1])
        s.barrier(700000 if impaired else 100000)
    for (ep, area), ext in sorted(used.items()):
        D(s, ep, area, 0, ext + 8 if area != RQB else min(ext + 8, RQB_LEN))
    return s


# ---------------------------------------------------------------------------
# single-fault tails
# ---------------------------------------------------------------------------
FAULTS = [
    'remote_bad_key_write', 'remote_bad_key_read', 'remote_range_write', 'remote_range_read', 'remote_below_start',
    'remote_last_byte_over', 'perm_write', 'perm_read', 'pd_write', 'pd_read', 'dir_write', 'dir_read',
    'page_cross_write', 'page_cross_read', 'ctx_write', 'local_bad_lkey_write', 'local_bad_lkey_send',
    'local_bad_lkey_read', 'local_range', 'local_perm_send', 'local_dir_send', 'local_pd', 'local_overflow',
    'rqe_small', 'rqe_bad_lkey', 'rqe_pd', 'post_opcode', 'post_len0_write', 'post_len0_read', 'post_flags',
    'post_range', 'post_len_max', 'invalidated_remote', 'invalidated_local',
]


def fault_tail(rng, s, kind, tails):
    """emit the faulty op (+ context); returns True if the QP is expected to survive (post-port rejection)"""
    wr = 100
    if kind == 'remote_bad_key_write':
        W(s, 64, src=0x40, dst=0x40, rkey=rng.choice([0xDEAD, 0, 0xFFFFFFFF]))
    elif kind == 'remote_bad_key_read':
        R(s, 64, dst=0x40, src=0x40, rkey=0xDEAD)
    elif kind == 'remote_range_write':
        W(s, rng.choice([16, 300, 1000]), raddr=MAIN_END + rng.choice([0, 8, 4096]))
    elif kind == 'remote_range_read':
        R(s, rng.choice([16, 300]), raddr=MAIN_END + rng.choice([0, 16]))
    elif kind == 'remote_below_start':
        W(s, 16, raddr=mva(0) - rng.choice([1, 8, 15]))
    elif kind == 'remote_last_byte_over':
        n = rng.choice([16, 300, 700])
        W(s, n, raddr=MAIN_END - n + 1)
    elif kind == 'perm_write':
        W(s, 16, raddr=va('rdonly', 0), rkey=key('rdonly'))
    elif kind == 'perm_read':
        R(s, 16, raddr=va('wronly', 0), rkey=key('wronly'))
    elif kind == 'pd_write':
        W(s, 16, raddr=va('otherpd', 0), rkey=key('otherpd'))
    elif kind == 'pd_read':
        R(s, 16, raddr=va('otherpd', 0), rkey=key('otherpd'))
    elif kind == 'dir_write':
        W(s, 16, raddr=va('localonly', 0), rkey=key('localonly'))
    elif kind == 'dir_read':
        R(s, 16, raddr=va('localonly', 0), rkey=key('localonly'))
    elif kind == 'page_cross_write':
        n = rng.choice([100, 200, 300])
        W(s, n, raddr=va('paged', 0x1000 * rng.randint(1, 3) - n // 2), rkey=key('paged'))
    elif kind == 'page_cross_read':
        n = rng.choice([100, 200])
        R(s, n, raddr=va('paged', 0x1000 * rng.randint(1, 3) - n // 2), rkey=key('paged'))
    elif kind == 'ctx_write':
        W(s, 16, raddr=va('ctx1', 0), rkey=key('ctx1'))
    elif kind == 'local_bad_lkey_write':
        W(s, 64, lkey=rng.choice([0xBAD, 0]))
    elif kind == 'local_bad_lkey_send':
        SND(s, 64, lkey=0xBAD)
    elif kind == 'local_bad_lkey_read':
        R(s, 64, lkey=0xBAD)
    elif kind == 'local_range':
        W(s, 32, laddr=MAIN_END - rng.choice([1, 16, 31]))
    elif kind == 'local_perm_send':
        SND(s, 16, laddr=va('wronly', 0), lkey=key('wronly'))
    elif kind == 'local_dir_send':
        SND(s, 16, laddr=va('remoteonly', 0), lkey=key('remoteonly'))
    elif kind == 'local_pd':
        W(s, 16, laddr=va('otherpd', 0), lkey=key('otherpd'))
    elif kind == 'local_overflow':
        W(s, 16, laddr=(1 << 64) - rng.choice([1, 8, 15]))
    elif kind == 'rqe_small':
        SND(s, 200, src=0x80)
    elif kind == 'rqe_bad_lkey':
        SND(s, 64)
    elif kind == 'rqe_pd':
        SND(s, 64)
    elif kind == 'invalidated_remote':
        s.cmd('mr_inval', ep='B', idx=MRS['main']['idx'])
        W(s, 64, src=0x40, dst=0x40)
    elif kind == 'invalidated_local':
        s.cmd('mr_inval', ep='A', idx=MRS['main']['idx'])
        W(s, 64, src=0x40, dst=0x40)
    elif kind == 'post_opcode':
        s.post('A', rng.choice([0, 4, 5, 8, 15]), mva(SRC), K, 16, mva(WDST), K, track=False)
        return True
    elif kind == 'post_len0_write':
        s.post('A', 'WRITE', mva(SRC), K, 0, mva(WDST), K, track=False)
        return True
    elif kind == 'post_len0_read':
        s.post('A', 'READ', mva(RDST), K, 0, mva(RSRC), K, track=False)
        return True
    elif kind == 'post_flags':
        s.post('A', rng.choice(['SEND', 'WRITE', 'READ']), mva(SRC), K, 16, mva(WDST), K, flags=rng.choice([1, 2, 8, 15]),
               track=False)
        return True
    elif kind == 'post_range':
        s.post('A', rng.choice(['WRITE', 'READ']), mva(SRC), K, 16, (1 << 64) - rng.randint(1, 15), K, track=False)
        return True
    elif kind == 'post_len_max':
        s.post('A', 'SEND', mva(SRC), K, (1 << 20) + rng.randint(1, 100), track=False)
        return True
    return False


def gen_fault(rng, name, idx, kind):
    s = Scn(name, 'random valid traffic followed by one single fault: %s' % kind)
    s.setup(timeout=3000, retry=7, rnr_retry=7, rnr_delay=200, seed=rng.randint(1, 1 << 20),
            psn_ab=rng.choice([0x100, 0xFFFFF8]), psn_ba=0x200, epoch=rng.randint(1, 1000))
    init_mem(s)
    for ep in 'AB':
        if rng.random() < 0.4:
            s.cmd('mem_lat', ep=ep, min=0, max=rng.randint(2, 8), stall=rng.choice([0, 20]))
    alloc = {}
    used = {}

    def A_(ep, area, size):
        return alloc.setdefault((ep, area), Bump(size))

    for rnd in range(rng.randint(0, 3)):
        nsend = 0
        ops = []
        for _ in range(rng.randint(1, 8)):
            kind_op = rng.choice(['WRITE', 'WRITE', 'READ', 'SEND'])
            n = rand_len(rng, kind_op)
            src_off = rng.randint(0, 8000) // 8 * 8 + rng.randint(0, 7)
            if kind_op == 'WRITE':
                d = A_('B', WDST, WDST_LEN).take(n, rng.randint(0, 7))
                if d is not None:
                    ops.append(('W', n, src_off, d))
                    used[('B', WDST)] = max(used.get(('B', WDST), 0), d + n)
            elif kind_op == 'READ':
                d = A_('A', RDST, RDST_LEN).take(n, rng.randint(0, 7))
                if d is not None and n < RSRC_LEN - 16:
                    ops.append(('R', n, d, rng.randint(0, RSRC_LEN - n - 8)))
                    used[('A', RDST)] = max(used.get(('A', RDST), 0), d + n)
            elif nsend < 4:
                rl = n + rng.choice([0, 3, 64])
                rq = A_('B', RQB, RQB_LEN).take(rl, rng.randint(0, 7))
                if rq is not None:
                    nsend += 1
                    ops.append(('S', n, src_off, (rq, rl)))
                    used[('B', RQB)] = max(used.get(('B', RQB), 0), rq + rl)
        for o in ops:
            if o[0] == 'S':
                RQ(s, o[3][0], o[3][1], ep='B')
        for o in ops:
            if o[0] == 'W':
                W(s, o[1], src=o[2], dst=o[3])
            elif o[0] == 'R':
                R(s, o[1], dst=o[2], src=o[3])
            else:
                SND(s, o[1], src=o[2])
        s.barrier()
    # context of the tail: B's receive WQEs (flushed when the responder dies; also what SEND faults consume)
    if kind in ('rqe_small',):
        RQ(s, 0x1800, 100)
        RQ(s, 0x1A00, 64)
    elif kind == 'rqe_bad_lkey':
        RQ(s, 0x1800, 128, lkey=rng.choice([0xBAD, 0]))
        RQ(s, 0x1A00, 64)
    elif kind == 'rqe_pd':
        RQ(s, 0, 64, lkey=key('otherpd'), addr=va('otherpd', 0))
    elif rng.random() < 0.5:
        RQ(s, 0x1800, 64)
    survive = fault_tail(rng, s, kind, 0)
    ntail = rng.randint(0, 2) if not survive else 1
    for t in range(ntail):
        W(s, 32 + t, src=0x600 + t * 64, dst=0x3000 + t * 64)
    s.barrier()
    for (ep, area), ext in sorted(used.items()):
        D(s, ep, area, 0, ext + 8 if area != RQB else min(ext + 8, RQB_LEN))
    D(s, 'B', WDST, 0x3000, 256)
    D(s, 'B', WDST, 0, 0x100)
    D(s, 'B', RQB, 0x1800, 0x300)
    return s


def check_scn(path):
    cmds = SC.parse_scn(path)
    exp = sfrt_model.Model(cmds, os.path.basename(path)).run()
    return exp


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--seed', type=int, required=True)
    ap.add_argument('--count', type=int, required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--faults', action='store_true', help='single-fault tail scenarios')
    ap.add_argument('--prefix', default=None)
    ap.add_argument('--keep-bad', action='store_true', help='keep scenarios the model rejects (for debugging)')
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    prefix = a.prefix if a.prefix is not None else ('f' if a.faults else 'r')
    bad = 0
    for i in range(a.count):
        for attempt in range(30):
            rng = random.Random(a.seed * 1000003 + i * 101 + attempt * 7919)
            if a.faults:
                kind = FAULTS[(i + a.seed) % len(FAULTS)]
                nm = '%s%04d_%03d_%s' % (prefix, a.seed, i, kind)
                s = gen_fault(rng, nm, i, kind)
            else:
                nm = '%s%04d_%03d_mix' % (prefix, a.seed, i)
                s = gen_mixed(rng, nm, i)
            path = os.path.join(a.out, nm + '.scn')
            s.write(path)
            try:
                exp = check_scn(path)
                if exp.warnings or exp.notes:
                    raise ValueError('warnings: %s %s' % (exp.warnings[:2], exp.notes[:2]))
                break
            except Exception as e:     # noqa
                err = '%s: %s' % (type(e).__name__, e)
                if not a.keep_bad:
                    os.remove(path)
        else:
            bad += 1
            print('GAVE UP on %s: %s' % (nm, err))
            continue
    print('wrote %d scenario(s) to %s (%d gave up)' % (a.count - bad, a.out, bad))
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
