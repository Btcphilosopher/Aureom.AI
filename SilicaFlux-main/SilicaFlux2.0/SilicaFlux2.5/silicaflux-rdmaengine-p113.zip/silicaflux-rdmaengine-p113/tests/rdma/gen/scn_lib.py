#!/usr/bin/env python3
"""scn_lib.py - helpers shared by the scenario generators (standard setup, memory map, command shortcuts).

Standard memory map (identical on A and B, per-endpoint PA space):

  name       idx  VA base    len     PA base  pd  acc   ctx  purpose
  main       0    0x10000    0x10000 0x00000  1   0x1F  0    LR|LW|RR|RW|CONTIG  general purpose (64 KiB)
  paged      1    0x40000    0x4000  0x10000  1   0x0F  0    like main but NOT contiguous (page-cross check applies)
  otherpd    2    0x80000    0x1000  0x14000  2   0x1F  0    valid key, but protection domain 2 (QPs use pd 1)
  localonly  3    0x90000    0x1000  0x15000  1   0x13  0    LR|LW|CONTIG (no remote rights at all)
  rdonly     4    0xA0000    0x1000  0x16000  1   0x15  0    LR|RR|CONTIG (remote read only)
  wronly     5    0xB0000    0x1000  0x17000  1   0x1A  0    LW|RW|CONTIG (remote write only, no local read)
  ctx1       6    0xC0000    0x1000  0x18000  1   0x1F  1    mapping context 1 (disabled by default)
  remoteonly 7    0xD0000    0x1000  0x19000  1   0x1C  0    RR|RW|CONTIG (no local rights at all)

Role areas inside `main` (identical layout on both endpoints; offsets):
  SRC 0x0000(16K) own SEND/WRITE source | RDST 0x4000(16K) own READ destination | WDST 0x8000(16K) peer WRITE destination
  RQB 0xC000(8K) own receive buffers    | RSRC 0xE000(8K) data served to the peer's READs

QPs: A qpn=1, B qpn=2, pd=1, MACs A=0x020000000001 B=0x020000000002.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'model'))

from scn import ScnWriter                      # noqa: E402
import frames as F                             # noqa: E402
import scn as SC                               # noqa: E402

MAC = {'A': 0x020000000001, 'B': 0x020000000002}
QPN = {'A': 1, 'B': 2}
PD = 1

MRS = {
    'main':       dict(idx=0, va=0x10000, len=0x10000, pa=0x00000, key=0x1001, pd=1, acc=0x1F, ctx=0),
    'paged':      dict(idx=1, va=0x40000, len=0x4000,  pa=0x10000, key=0x1002, pd=1, acc=0x0F, ctx=0),
    'otherpd':    dict(idx=2, va=0x80000, len=0x1000,  pa=0x14000, key=0x1003, pd=2, acc=0x1F, ctx=0),
    'localonly':  dict(idx=3, va=0x90000, len=0x1000,  pa=0x15000, key=0x1004, pd=1, acc=0x13, ctx=0),
    'rdonly':     dict(idx=4, va=0xA0000, len=0x1000,  pa=0x16000, key=0x1005, pd=1, acc=0x15, ctx=0),
    'wronly':     dict(idx=5, va=0xB0000, len=0x1000,  pa=0x17000, key=0x1006, pd=1, acc=0x1A, ctx=0),
    'ctx1':       dict(idx=6, va=0xC0000, len=0x1000,  pa=0x18000, key=0x1007, pd=1, acc=0x1F, ctx=1),
    'remoteonly': dict(idx=7, va=0xD0000, len=0x1000,  pa=0x19000, key=0x1008, pd=1, acc=0x1C, ctx=0),
}

# role areas inside `main` (offsets; each endpoint uses the same layout for the roles it plays)
SRC, RDST, WDST, RQB, RSRC = 0x0000, 0x4000, 0x8000, 0xC000, 0xE000
SRC_LEN, RDST_LEN, WDST_LEN, RQB_LEN, RSRC_LEN = 0x4000, 0x4000, 0x4000, 0x2000, 0x2000
PATS = {'A': 0x10, 'B': 0x20}      # base pattern seeds per endpoint

BUILD = dict(dw=64, mtu=256, window=8, max_rd=2, nmr=8, sq_depth=8, pd_w=4, ctx_w=2, pa_w=32)
MTU = 256


def va(name, off=0):
    return MRS[name]['va'] + off


def pa(name, off=0):
    return MRS[name]['pa'] + off


def key(name):
    return MRS[name]['key']


def other(ep):
    return 'B' if ep == 'A' else 'A'


class Scn(ScnWriter):
    """ScnWriter + conveniences.  `ops` records posted WQEs so generators can compute expected PSNs."""

    def __init__(self, name, doc=''):
        super().__init__(name, doc)
        self.name = name
        self.next_wr = {'A': 1, 'B': 1}
        self.build_params = dict(BUILD)
        self.psn = {'A': 0x100, 'B': 0x200}
        self.psn_of = {}
        self.epoch = 1

    # ---- standard setup -------------------------------------------------
    def build(self, **over):
        self.build_params.update(over)
        self.cmd('build', **self.build_params)

    def mrs(self, ep, names=None, skip=()):
        for n, m in MRS.items():
            if names is not None and n not in names:
                continue
            if n in skip:
                continue
            self.cmd('mr', ep=ep, idx=m['idx'], va=m['va'], len=m['len'], pa=m['pa'], key=m['key'], pd=m['pd'],
                     acc=m['acc'], ctx=m['ctx'])

    def qp_up(self, ep, epoch=1, rq_psn=0x100, sq_psn=0x100, timeout=3000, retry=7, rnr_retry=7, rnr_delay=200,
              qpn=None, rqpn=None, pd=PD, smac=None, dmac=None, from_reset=True):
        o = other(ep)
        qpn = QPN[ep] if qpn is None else qpn
        rqpn = QPN[o] if rqpn is None else rqpn
        smac = MAC[ep] if smac is None else smac
        dmac = MAC[o] if dmac is None else dmac
        self.cmd('qp', ep=ep, state='INIT', qpn=qpn, pd=pd)
        self.cmd('qp', ep=ep, state='RTR', rqpn=rqpn, epoch=epoch, rq_psn=rq_psn, smac=smac, dmac=dmac)
        self.cmd('qp', ep=ep, state='RTS', sq_psn=sq_psn, timeout=timeout, retry=retry, rnr_retry=rnr_retry,
                 rnr_delay=rnr_delay)

    def setup(self, epoch=1, psn_ab=0x100, psn_ba=0x200, timeout=3000, retry=7, rnr_retry=7, rnr_delay=200,
              mr_names=None, seed=1, mrs=True, qps=True, **build):
        """build + seed + MRs + QPs RESET->INIT->RTR->RTS on both ends (A sends from psn_ab, B from psn_ba)."""
        self.build(**build)
        self.cmd('seed', v=seed)
        if mrs:
            for ep in 'AB':
                self.mrs(ep, mr_names)
        if qps:
            self.qp_up('A', epoch=epoch, rq_psn=psn_ba, sq_psn=psn_ab, timeout=timeout, retry=retry,
                       rnr_retry=rnr_retry, rnr_delay=rnr_delay)
            self.qp_up('B', epoch=epoch, rq_psn=psn_ab, sq_psn=psn_ba, timeout=timeout, retry=retry,
                       rnr_retry=rnr_retry, rnr_delay=rnr_delay)
        self.psn = {'A': psn_ab, 'B': psn_ba}      # next PSN each endpoint will allocate (for crafted frames)
        self.epoch = epoch

    # ---- data -------------------------------------------------------------
    def fill(self, ep, addr, length, pat):
        self.cmd('mem_fill', ep=ep, addr=addr, len=length, pat=pat)

    def dump(self, ep, addr, length):
        self.cmd('dump', ep=ep, addr=addr, len=length)

    # ---- work requests -------------------------------------------------------
    def wr(self, ep):
        w = self.next_wr[ep]
        self.next_wr[ep] += 1
        return w

    def post_recv(self, ep, addr, lkey, length, wr_id=None):
        wr_id = self.wr(ep) + 1000 if wr_id is None else wr_id
        self.cmd('post_recv', ep=ep, wr_id=wr_id, addr=addr, lkey=lkey, len=length)
        return wr_id

    def post(self, ep, op, laddr, lkey, length, raddr=0, rkey=0, wr_id=None, track=True, **extra):
        """post_send.  When `track` (default) and the op is SEND/WRITE/READ the PSNs it will consume are recorded
        in self.psn / self.psn_of[(ep, wr_id)] -- only valid when the post is expected to be accepted."""
        wr_id = self.wr(ep) if wr_id is None else wr_id
        self.cmd('post_send', ep=ep, wr_id=wr_id, op=op, laddr=laddr, lkey=lkey, len=length, raddr=raddr, rkey=rkey,
                 **extra)
        if track and op in ('SEND', 'WRITE', 'READ') and not extra.get('flags'):
            self.psn_of[(ep, wr_id)] = self.psn[ep]
            self.psn[ep] = (self.psn[ep] + (1 if op == 'READ' else npsn(length))) & 0xFFFFFF
        return wr_id

    # ---- time ---------------------------------------------------------------
    def run(self, cycles):
        self.cmd('run', cycles=cycles)

    def barrier(self, mx=60000):
        self.cmd('barrier', max=mx)

    def link(self, d, drop=0, dup=0, delay_min=0, delay_max=0, reorder=0):
        self.cmd('link', dir=d, drop=drop, dup=dup, delay_min=delay_min, delay_max=delay_max, reorder=reorder)


def npsn(length, mtu=MTU):
    return max(1, -(-length // mtu))


def init_mem(s, eps='AB'):
    """fill every role area of `main` with a distinct deterministic pattern (so that 'not written' is visible)."""
    for ep in eps:
        base = PATS[ep]
        s.fill(ep, pa('main', SRC), SRC_LEN, base + 1)
        s.fill(ep, pa('main', RDST), RDST_LEN, base + 2)
        s.fill(ep, pa('main', WDST), WDST_LEN, base + 3)
        s.fill(ep, pa('main', RQB), RQB_LEN, base + 4)
        s.fill(ep, pa('main', RSRC), RSRC_LEN, base + 5)


# ---------------------------------------------------------------------------
# shared scenario-building shortcuts
# ---------------------------------------------------------------------------
K = key('main')
MAIN_END = va('main', 0x10000)                 # first VA past the `main` region


def new(name, doc, **kw):
    """a Scn with the standard setup and the role areas pre-filled"""
    s = Scn(name, doc)
    s.setup(**kw)
    init_mem(s)
    return s


def mva(off):
    """VA inside `main` at offset `off`"""
    return va('main', off)


def W(s, ln, src=0, dst=0, ep='A', **kw):
    """RDMA WRITE of `ln` bytes: local SRC+src -> peer WDST+dst  (kw: lkey, rkey, laddr, raddr, wr_id, flags)"""
    kw.setdefault('rkey', K)
    lkey = kw.pop('lkey', K)
    raddr = kw.pop('raddr', mva(WDST + dst))
    laddr = kw.pop('laddr', mva(SRC + src))
    return s.post(ep, 'WRITE', laddr, lkey, ln, raddr, kw.pop('rkey'), **kw)


def R(s, ln, dst=0, src=0, ep='A', **kw):
    """RDMA READ of `ln` bytes: peer RSRC+src -> local RDST+dst"""
    kw.setdefault('rkey', K)
    lkey = kw.pop('lkey', K)
    raddr = kw.pop('raddr', mva(RSRC + src))
    laddr = kw.pop('laddr', mva(RDST + dst))
    return s.post(ep, 'READ', laddr, lkey, ln, raddr, kw.pop('rkey'), **kw)


def SND(s, ln, src=0, ep='A', **kw):
    """SEND of `ln` bytes from local SRC+src"""
    lkey = kw.pop('lkey', K)
    laddr = kw.pop('laddr', mva(SRC + src))
    return s.post(ep, 'SEND', laddr, lkey, ln, **kw)


def RQ(s, off, ln, ep='B', lkey=K, wr_id=None, addr=None):
    """post a receive WQE for RQB+off"""
    return s.post_recv(ep, mva(RQB + off) if addr is None else addr, lkey, ln, wr_id)


def D(s, ep, area, off, ln):
    s.dump(ep, pa('main', area + off), ln)


def peer_ab(s, epoch=None):
    """addressing of frames A sends to B"""
    return F.Peer(MAC['A'], MAC['B'], QPN['B'], s.epoch if epoch is None else epoch)


def peer_ba(s, epoch=None):
    return F.Peer(MAC['B'], MAC['A'], QPN['A'], s.epoch if epoch is None else epoch)


def payload(seed, n):
    """the bytes pat(seed, 0..n-1) (what mem_fill pat=seed puts at the start of a range)"""
    return bytes(SC.pat(seed, i) for i in range(n))


def inject(s, d, data):
    s.cmd('inject', dir=d, hex=F.to_hex(data))
