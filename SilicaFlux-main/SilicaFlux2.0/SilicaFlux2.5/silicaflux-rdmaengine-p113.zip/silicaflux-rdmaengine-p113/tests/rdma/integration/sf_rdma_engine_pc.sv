// =============================================================================
// SilicaFlux Project 113 -- sf_rdma_engine_pc : the RDMA engine with a REAL PacketCore (Project 62) on its receive path.
//
// Same parameters and ports as sf_rdma_engine (drop-in for the two-endpoint bench).  Frames arriving on the link `rx_*` stream
// enter PacketCore's ingress (parse -> classify -> egress queue -> scheduler -> egress stream) and PacketCore's data egress feeds the
// engine's receive stream.  PacketCore runs with its reset configuration: no rules, default action = forward to queue 0.
// Consequences that are part of the test: runts (< 60 B), bad-FCS frames (rx_err) and oversize frames are dropped by PacketCore;
// frame bytes are not modified (no rewrite rule is installed); PacketCore exerts back-pressure through s_ready (lossless mode).
// This is an INTEGRATION TEST of the stream contract.  No Ethernet MAC/PHY is involved, and nothing here is RoCE.
// =============================================================================
`default_nettype none
module sf_rdma_engine_pc #(
  parameter int DW            = 64,
  parameter int PA_W          = 32,
  parameter int MTU           = 256,
  parameter int NMR           = 8,
  parameter int PD_W          = 4,
  parameter int CTX_W         = 2,
  parameter int SQ_DEPTH      = 8,
  parameter int RQ_DEPTH      = 8,
  parameter int CQ_DEPTH      = 32,
  parameter int WINDOW        = 8,
  parameter int MAX_RD        = 2,
  parameter int MEM_RD_OUT    = 4,
  parameter int MEM_WR_OUT    = 4,
  parameter int PAGE_BYTES    = 4096,
  parameter int MAX_MSG_BYTES = 1048576,
  parameter int ACCEPT_ACK_DELAY = 64,
  localparam int B            = DW/8,
  localparam int RID_W        = (NMR > 1) ? $clog2(NMR) : 1,
  localparam int NCTX         = (1 << CTX_W)
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 cfg_valid,
  output logic                      cfg_ready,
  input  wire logic [3:0]           cfg_cmd,
  input  wire logic [RID_W-1:0]     cfg_idx,
  input  wire logic [63:0]          cfg_va,
  input  wire logic [31:0]          cfg_len,
  input  wire logic [PA_W-1:0]      cfg_pa,
  input  wire logic [31:0]          cfg_key,
  input  wire logic [PD_W-1:0]      cfg_pd,
  input  wire logic [7:0]           cfg_acc,
  input  wire logic [CTX_W-1:0]     cfg_ctx,
  input  wire logic [NCTX-1:0]      cfg_ctx_mask,
  input  wire logic [2:0]           cfg_qp_state,
  input  wire logic [15:0]          cfg_qpn,
  input  wire logic [15:0]          cfg_rqpn,
  input  wire logic [15:0]          cfg_epoch,
  input  wire logic [23:0]          cfg_rq_psn,
  input  wire logic [47:0]          cfg_lmac,
  input  wire logic [47:0]          cfg_pmac,
  input  wire logic [23:0]          cfg_sq_psn,
  input  wire logic [31:0]          cfg_timeout,
  input  wire logic [3:0]           cfg_retry,
  input  wire logic [3:0]           cfg_rnr_retry,
  input  wire logic [31:0]          cfg_rnr_delay,
  output logic                      cfg_rsp_valid,
  output logic [3:0]                cfg_rsp_status,
  output logic [2:0]                qp_state,
  output logic [3:0]                qp_err_cause,
  input  wire logic                 sq_post_valid,
  output logic                      sq_post_ready,
  input  wire logic [3:0]           sq_post_op,
  input  wire logic [63:0]          sq_post_wr_id,
  input  wire logic [63:0]          sq_post_laddr,
  input  wire logic [31:0]          sq_post_lkey,
  input  wire logic [31:0]          sq_post_len,
  input  wire logic [63:0]          sq_post_raddr,
  input  wire logic [31:0]          sq_post_rkey,
  input  wire logic [3:0]           sq_post_flags,
  output logic                      sq_post_rsp_valid,
  output logic [2:0]                sq_post_rsp_status,
  input  wire logic                 rq_post_valid,
  output logic                      rq_post_ready,
  input  wire logic [63:0]          rq_post_wr_id,
  input  wire logic [63:0]          rq_post_addr,
  input  wire logic [31:0]          rq_post_lkey,
  input  wire logic [31:0]          rq_post_len,
  output logic                      rq_post_rsp_valid,
  output logic [2:0]                rq_post_rsp_status,
  output logic                      cq_valid,
  input  wire logic                 cq_ready,
  output logic [63:0]               cq_wr_id,
  output logic [3:0]                cq_op,
  output logic [3:0]                cq_status,
  output logic [31:0]               cq_len,
  output logic [15:0]               cq_qpn,
  output logic                      mrd_valid,
  input  wire logic                 mrd_ready,
  output logic [PA_W-1:0]           mrd_addr,
  output logic [CTX_W-1:0]          mrd_ctx,
  input  wire logic                 mrd_rsp_valid,
  input  wire logic [DW-1:0]        mrd_rsp_data,
  input  wire logic                 mrd_rsp_err,
  output logic                      mwr_valid,
  input  wire logic                 mwr_ready,
  output logic [PA_W-1:0]           mwr_addr,
  output logic [DW-1:0]             mwr_data,
  output logic [B-1:0]              mwr_strb,
  output logic [CTX_W-1:0]          mwr_ctx,
  input  wire logic                 mwr_ack_valid,
  input  wire logic                 mwr_ack_err,
  output logic                      tx_valid,
  input  wire logic                 tx_ready,
  output logic [DW-1:0]             tx_data,
  output logic [B-1:0]              tx_keep,
  output logic                      tx_last,
  input  wire logic                 rx_valid,
  output logic                      rx_ready,
  input  wire logic [DW-1:0]        rx_data,
  input  wire logic [B-1:0]         rx_keep,
  input  wire logic                 rx_last,
  input  wire logic                 rx_err,
  input  wire logic [7:0]           perf_idx,
  output logic [63:0]               perf_data,
  input  wire logic                 perf_clear,
  output logic [3:0]                fl_fault,
  output logic [31:0]               fl_key,
  output logic [63:0]               fl_va,
  output logic [31:0]               fl_len,
  output logic [1:0]                fl_op,
  output logic                      ref_ovf
);
  // PacketCore data egress -> engine receive stream
  logic              pc_m_valid, pc_m_ready, pc_m_last, pc_m_err;
  logic [DW-1:0]     pc_m_data;
  logic [B-1:0]      pc_m_keep;
  // unused sidebands
  logic [3:0] m_queue; logic [2:0] m_tc; logic [3:0] m_src; logic [15:0] m_meta; logic [31:0] m_hash; logic [15:0] m_len;
  logic x_valid, x_last, rb_rvalid, rb_err, pc_idle; logic [DW-1:0] x_data; logic [B-1:0] x_keep; logic [3:0] x_reason; logic [2:0] x_tc;
  logic [3:0] x_src; logic [15:0] x_meta; logic [31:0] x_hash; logic [15:0] x_len; logic [31:0] rb_rdata;

  silicaflux_packet_engine #(.DW(DW), .NUM_QUEUES(2), .MAX_FRAME_BYTES(1600), .QUEUE_BYTES(4096), .MGMT_BYTES(4096)) u_pc (
    .clk(clk), .rst_n(rst_n),
    .s_valid(rx_valid), .s_ready(rx_ready), .s_data(rx_data), .s_keep(rx_keep), .s_last(rx_last), .s_err(rx_err), .s_src(4'd0), .s_meta(16'd0),
    .m_valid(pc_m_valid), .m_ready(pc_m_ready), .m_data(pc_m_data), .m_keep(pc_m_keep), .m_last(pc_m_last), .m_err(pc_m_err),
    .m_queue(m_queue), .m_tc(m_tc), .m_src(m_src), .m_meta(m_meta), .m_hash(m_hash), .m_len(m_len),
    .x_valid(x_valid), .x_ready(1'b1), .x_data(x_data), .x_keep(x_keep), .x_last(x_last), .x_reason(x_reason), .x_tc(x_tc), .x_src(x_src),
    .x_meta(x_meta), .x_hash(x_hash), .x_len(x_len),
    .rb_req(1'b0), .rb_we(1'b0), .rb_addr(16'd0), .rb_wdata(32'd0), .rb_tenant(4'd0), .rb_rvalid(rb_rvalid), .rb_rdata(rb_rdata), .rb_err(rb_err),
    .idle(pc_idle));

  // the engine sees PacketCore's egress as its receive stream (PacketCore never forwards a frame flagged bad: m_err is tied 0)
  sf_rdma_engine #(.DW(DW), .PA_W(PA_W), .MTU(MTU), .NMR(NMR), .PD_W(PD_W), .CTX_W(CTX_W), .SQ_DEPTH(SQ_DEPTH), .RQ_DEPTH(RQ_DEPTH),
                   .CQ_DEPTH(CQ_DEPTH), .WINDOW(WINDOW), .MAX_RD(MAX_RD), .MEM_RD_OUT(MEM_RD_OUT), .MEM_WR_OUT(MEM_WR_OUT),
                   .PAGE_BYTES(PAGE_BYTES), .MAX_MSG_BYTES(MAX_MSG_BYTES), .ACCEPT_ACK_DELAY(ACCEPT_ACK_DELAY)) u_e (
    .rx_valid(pc_m_valid), .rx_ready(pc_m_ready), .rx_data(pc_m_data), .rx_keep(pc_m_keep), .rx_last(pc_m_last), .rx_err(pc_m_err),
    .*);
endmodule
`default_nettype wire
