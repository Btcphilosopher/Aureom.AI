// =============================================================================
// SilicaFlux Project 113 -- RDMAEngine :: two-endpoint verification bench (Verilator, C++)
//
//   scenario file (docs/TRANSPORT_SPEC.md Appendix A)  ->  this bench  ->  result file  ->  tests/rdma/model/check_results.py
//
// Two instances of sf_rdma_engine (A, B) each with its own byte-addressed memory model (random latency, random ready stalls, in-order
// responses; a write is applied at the moment it is ACKNOWLEDGED, so a premature read of "committed" data returns stale bytes), joined
// by a frame-level LINK model that can drop, duplicate, delay, reorder, black-hole and inject frames.  Cycle-level MONITORS check the
// stream and memory-port protocols; everything else is judged offline by the independent Python reference model from the result file.
// =============================================================================
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <deque>
#include <map>
#include <set>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <random>
#include <type_traits>

#ifdef TB_PC
#include "Vsf_rdma_engine_pc.h"
typedef Vsf_rdma_engine_pc DUT;
#include "Vsf_rdma_engine_pc___024root.h"
#else
#include "Vsf_rdma_engine.h"
typedef Vsf_rdma_engine DUT;
#include "Vsf_rdma_engine___024root.h"
#endif
#include "verilated.h"
#include "perf_names.h"

#ifndef TB_DW
#define TB_DW 64
#endif
#ifndef TB_MEM_RD_OUT
#define TB_MEM_RD_OUT 4
#endif
#ifndef TB_MEM_WR_OUT
#define TB_MEM_WR_OUT 4
#endif
#ifndef TB_CQ_DEPTH
#define TB_CQ_DEPTH 32
#endif
static const int DWB = TB_DW / 8;   // bytes per beat

// ---------------------------------------------------------------------------------------------------------------------------------
// width-generic access to Verilator signals (CData/SData/IData/QData or VlWide<N>) as little-endian byte arrays
// ---------------------------------------------------------------------------------------------------------------------------------
template <std::size_t N> static constexpr size_t words_of(const VlWide<N>&) { return N; }
template <typename T> static void put_bytes(T& s, const uint8_t* b, int n) {
  if constexpr (std::is_integral<T>::value) {
    uint64_t v = 0; for (int i = 0; i < n && i < 8; i++) v |= (uint64_t)b[i] << (8 * i); s = (T)v;
  } else {
    for (size_t w = 0; w < words_of(s); w++) { uint32_t v = 0; for (int i = 0; i < 4; i++) { size_t k = w * 4 + i; if ((int)k < n) v |= (uint32_t)b[k] << (8 * i); } s[w] = v; }
  }
}
template <typename T> static void get_bytes(const T& s, uint8_t* b, int n) {
  if constexpr (std::is_integral<T>::value) {
    uint64_t v = (uint64_t)s; for (int i = 0; i < n; i++) b[i] = (i < 8) ? (uint8_t)(v >> (8 * i)) : 0;
  } else {
    for (int i = 0; i < n; i++) { size_t w = i / 4; b[i] = (w < words_of(s)) ? (uint8_t)(s[w] >> (8 * (i % 4))) : 0; }
  }
}
template <typename T> static uint64_t get_u64(const T& s) { uint8_t b[8]; get_bytes(s, b, 8); uint64_t v = 0; for (int i = 0; i < 8; i++) v |= (uint64_t)b[i] << (8 * i); return v; }

// ---------------------------------------------------------------------------------------------------------------------------------
static std::mt19937_64 rng(1);
static uint64_t now_cycle = 0;
static FILE* resf = nullptr;
static int mon_errors = 0;
#define MON(...) do { mon_errors++; fprintf(resf, "MON cyc=%llu ", (unsigned long long)now_cycle); fprintf(resf, __VA_ARGS__); fprintf(resf, "\n"); } while (0)
static uint32_t rnd(uint32_t lo, uint32_t hi) { if (hi <= lo) return lo; return lo + (uint32_t)(rng() % (hi - lo + 1)); }
static bool pct(int p) { return p > 0 && (int)(rng() % 100) < p; }

static uint8_t pat_byte(uint32_t seed, uint32_t i) {   // spec A.3
  uint32_t x = (uint32_t)((uint64_t)seed * 2654435761u + (uint64_t)i * 2246822519u);
  x ^= x >> 15; x = (uint32_t)((uint64_t)x * 2654435761u);
  return (uint8_t)(x >> 24);
}

// ---------------------------------------------------------------------------------------------------------------------------------
struct Mem {
  std::unordered_map<uint64_t, std::vector<uint8_t>> pg;
  uint8_t rd(uint64_t a) const { auto it = pg.find(a >> 12); return it == pg.end() ? 0 : it->second[a & 4095]; }
  void wr(uint64_t a, uint8_t v) { auto& p = pg[a >> 12]; if (p.empty()) p.assign(4096, 0); p[a & 4095] = v; }
};

struct RdResp { uint64_t due; std::vector<uint8_t> d; };
struct WrAck  { uint64_t due; uint64_t addr; std::vector<uint8_t> d; uint32_t strb; };
struct PostRsp { uint64_t wr_id; bool sq; };

struct EP {
  char name = 'A';
  DUT* d = nullptr;
  Mem mem;
  int lat_min = 1, lat_max = 1, stall = 0;
  std::deque<RdResp> rq; uint64_t rd_last_due = 0;
  std::deque<WrAck>  wq; uint64_t wr_last_due = 0;
  int rd_out = 0, wr_out = 0;
  // driver
  bool cq_drain = true;
  uint64_t cqe_total = 0;
  int sq_open = 0;                     // OK-posted SQ WQEs whose CQE has not been produced
  int cq_credit_open = 0;              // OK posts not yet consumed from the CQ (credit invariant)
  std::deque<PostRsp> pend_rsp;
  // cfg driver
  bool cfg_act = false, cfg_sent = false, cfg_done = false;
  uint32_t cfg_cmd = 0; uint32_t cfg_idx = 0; uint64_t cfg_va = 0; uint32_t cfg_len = 0; uint64_t cfg_pa = 0; uint32_t cfg_key = 0; uint32_t cfg_pd = 0;
  uint32_t cfg_acc = 0, cfg_ctx = 0, cfg_ctx_mask = 0, cfg_qp_state = 0, cfg_qpn = 0, cfg_rqpn = 0, cfg_epoch = 0, cfg_rq_psn = 0, cfg_sq_psn = 0;
  uint64_t cfg_lmac = 0, cfg_pmac = 0; uint32_t cfg_timeout = 0, cfg_retry = 0, cfg_rnr_retry = 0, cfg_rnr_delay = 0;
  std::string cfg_name;
  // post drivers
  bool sq_act = false; uint32_t sq_op = 0, sq_flags = 0; uint64_t sq_wr = 0, sq_la = 0, sq_ra = 0; uint32_t sq_lk = 0, sq_len = 0, sq_rk = 0;
  bool rq_act = false; uint64_t rq_wr = 0, rq_addr = 0; uint32_t rq_lk = 0, rq_len = 0;
  // monitors
  bool in_frame = false; bool p_tx_valid = false, p_tx_ready = false; uint8_t p_tx_d[32]; uint32_t p_tx_k = 0; bool p_tx_l = false;
  bool p_rd_valid = false, p_rd_ready = false; uint64_t p_rd_addr = 0;
  bool p_wr_valid = false, p_wr_ready = false; uint64_t p_wr_addr = 0; uint8_t p_wr_d[32]; uint32_t p_wr_s = 0;
  uint64_t last_act = 0;
  int tx_stall = 0;                    // percentage of cycles tx_ready is low
  std::vector<uint8_t> asm_buf; uint32_t tx_beats = 0;
  uint64_t frames_tx = 0;
  uint64_t rd_err_n = 0, wr_err_n = 0, rd_seen = 0, wr_seen = 0;   // `mem_err`: the n-th memory read response / write acknowledge from now on is an ERROR
};

struct Frame { std::vector<uint8_t> b; bool err = false; bool badkeep = false; uint64_t due = 0; uint64_t seq = 0; };
struct Dir {
  std::vector<Frame> pend; Frame cur; bool active = false; size_t pos = 0; uint64_t seq = 0;
  int drop = 0, dup = 0, dmin = 0, dmax = 0; bool black = false;
  std::set<uint64_t> drop_n, dup_n; std::map<uint64_t, uint64_t> delay_n;
  uint64_t ordinal = 0; uint64_t dropped = 0, duped = 0;
  bool empty() const { return pend.empty() && !active; }
};

static EP A, B; static Dir AB, BA;     // AB: frames from A.tx to B.rx

// ---------------------------------------------------------------------------------------------------------------------------------
static std::string hex_of(const std::vector<uint8_t>& v) { static const char* h = "0123456789abcdef"; std::string s; for (auto c : v) { s += h[c >> 4]; s += h[c & 15]; } return s; }
static std::string word_hex(const uint8_t* b, int n) { static const char* h = "0123456789abcdef"; std::string s; for (int i = n - 1; i >= 0; i--) { s += h[b[i] >> 4]; s += h[b[i] & 15]; } return s; }

// ---------------------------------------------------------------------------------------------------------------------------------
// one simulated clock cycle for both endpoints
// ---------------------------------------------------------------------------------------------------------------------------------
static void deliver_start(Dir& D) {
  if (D.active) return;
  size_t best = (size_t)-1;
  for (size_t i = 0; i < D.pend.size(); i++)
    if (D.pend[i].due <= now_cycle && (best == (size_t)-1 || D.pend[i].due < D.pend[best].due ||
        (D.pend[i].due == D.pend[best].due && D.pend[i].seq < D.pend[best].seq))) best = i;
  if (best != (size_t)-1) { D.cur = D.pend[best]; D.pend.erase(D.pend.begin() + best); D.active = true; D.pos = 0; }
}

static void drive_rx(Dir& D, EP& e) {
  DUT* d = e.d;
  if (D.active) {
    size_t rem = D.cur.b.size() - D.pos; int n = (int)std::min<size_t>(rem, DWB); bool last = (rem <= (size_t)DWB);
    uint8_t buf[32] = {0}; memcpy(buf, &D.cur.b[D.pos], n);
    uint32_t keep = (n >= 32) ? 0xFFFFFFFFu : ((1u << n) - 1);
    if (D.cur.badkeep && D.pos == (size_t)DWB && !last) keep &= ~1u;
    put_bytes(d->rx_data, buf, DWB); d->rx_keep = keep; d->rx_valid = 1; d->rx_last = last; d->rx_err = last && D.cur.err;
  } else { d->rx_valid = 0; d->rx_keep = 0; d->rx_last = 0; d->rx_err = 0; uint8_t z[32] = {0}; put_bytes(d->rx_data, z, DWB); }
}

static void offer_frame(Dir& D, std::vector<uint8_t> bytes) {
  D.ordinal++;
  uint64_t o = D.ordinal;
  bool drop = D.black || D.drop_n.count(o) || pct(D.drop);
  if (drop) { D.dropped++; return; }
  Frame f; f.b = std::move(bytes);
  uint64_t dl = D.delay_n.count(o) ? D.delay_n[o] : rnd(D.dmin, D.dmax);
  f.due = now_cycle + 1 + dl; f.seq = D.seq++;
  bool dupl = D.dup_n.count(o) || pct(D.dup);
  D.pend.push_back(f);
  if (dupl) { Frame g = f; g.due = f.due + 1 + rnd(D.dmin, D.dmax); g.seq = D.seq++; D.pend.push_back(g); D.duped++; }
}

static void tick() {
  EP* eps[2] = {&A, &B};
  // -------- phase 1: choose inputs.  A receives the frames that travel B->A (BA); B receives AB.
  deliver_start(AB); deliver_start(BA);
  drive_rx(BA, A);          // A's receive side is fed by direction BA
  drive_rx(AB, B);
  for (int k = 0; k < 2; k++) {
    EP& e = *eps[k]; DUT* d = e.d;
    d->tx_ready = !pct(e.tx_stall);
    d->mrd_ready = !pct(e.stall); d->mwr_ready = !pct(e.stall);
    // memory responses
    d->mrd_rsp_valid = 0; d->mrd_rsp_err = 0; { uint8_t z[32] = {0}; put_bytes(d->mrd_rsp_data, z, DWB); }
    if (!e.rq.empty() && e.rq.front().due <= now_cycle) { d->mrd_rsp_valid = 1; put_bytes(d->mrd_rsp_data, e.rq.front().d.data(), DWB);
      if (e.rd_err_n && ++e.rd_seen == e.rd_err_n) {                  // error response: the data is garbage (0xEE)
        d->mrd_rsp_err = 1; uint8_t g[32]; memset(g, 0xEE, sizeof g); put_bytes(d->mrd_rsp_data, g, DWB);
        fprintf(resf, "NOTE cyc=%llu INJECT read error ep=%c response #%llu\n", (unsigned long long)now_cycle, e.name, (unsigned long long)e.rd_seen); } }
    d->mwr_ack_valid = 0; d->mwr_ack_err = 0;
    if (!e.wq.empty() && e.wq.front().due <= now_cycle) { d->mwr_ack_valid = 1;
      if (e.wr_err_n && ++e.wr_seen == e.wr_err_n) {                  // error acknowledge: the write is NOT applied
        d->mwr_ack_err = 1; e.wq.front().strb = 0;
        fprintf(resf, "NOTE cyc=%llu INJECT write error ep=%c ack #%llu (write not applied)\n", (unsigned long long)now_cycle, e.name, (unsigned long long)e.wr_seen); } }
    d->cq_ready = e.cq_drain;
    // cfg
    d->cfg_valid = e.cfg_act && !e.cfg_sent; d->cfg_cmd = e.cfg_cmd; d->cfg_idx = e.cfg_idx; d->cfg_va = e.cfg_va; d->cfg_len = e.cfg_len;
    d->cfg_pa = e.cfg_pa; d->cfg_key = e.cfg_key; d->cfg_pd = e.cfg_pd; d->cfg_acc = e.cfg_acc; d->cfg_ctx = e.cfg_ctx; d->cfg_ctx_mask = e.cfg_ctx_mask;
    d->cfg_qp_state = e.cfg_qp_state; d->cfg_qpn = e.cfg_qpn; d->cfg_rqpn = e.cfg_rqpn; d->cfg_epoch = e.cfg_epoch; d->cfg_rq_psn = e.cfg_rq_psn;
    d->cfg_lmac = e.cfg_lmac; d->cfg_pmac = e.cfg_pmac; d->cfg_sq_psn = e.cfg_sq_psn; d->cfg_timeout = e.cfg_timeout; d->cfg_retry = e.cfg_retry;
    d->cfg_rnr_retry = e.cfg_rnr_retry; d->cfg_rnr_delay = e.cfg_rnr_delay;
    // posts
    d->sq_post_valid = e.sq_act; d->sq_post_op = e.sq_op; d->sq_post_wr_id = e.sq_wr; d->sq_post_laddr = e.sq_la; d->sq_post_lkey = e.sq_lk; d->sq_post_len = e.sq_len;
    d->sq_post_raddr = e.sq_ra; d->sq_post_rkey = e.sq_rk; d->sq_post_flags = e.sq_flags;
    d->rq_post_valid = e.rq_act; d->rq_post_wr_id = e.rq_wr; d->rq_post_addr = e.rq_addr; d->rq_post_lkey = e.rq_lk; d->rq_post_len = e.rq_len;
    d->perf_idx = 0; d->perf_clear = 0;
  }
  // -------- phase 2: settle
  A.d->clk = 0; B.d->clk = 0; A.d->eval(); B.d->eval();
  // -------- phase 3: sample handshakes (before the clock edge)
  for (int k = 0; k < 2; k++) {
    EP& e = *eps[k]; DUT* d = e.d; Dir& rxdir = (k == 0) ? BA : AB; Dir& txdir = (k == 0) ? AB : BA;
    // --- transmit stream -> link, with protocol monitors
    bool tv = d->tx_valid, tr = d->tx_ready; uint8_t td[32]; get_bytes(d->tx_data, td, DWB); uint32_t tk = (uint32_t)d->tx_keep; bool tl = d->tx_last;
    if (e.p_tx_valid && !e.p_tx_ready) {
      if (!tv) MON("%c tx_valid dropped while !tx_ready", e.name);
      else if (memcmp(td, e.p_tx_d, DWB) != 0 || tk != e.p_tx_k || tl != e.p_tx_l) MON("%c tx payload changed while stalled", e.name);
    }
    if (e.in_frame && !tv) MON("%c tx gap inside a frame (store-and-forward violated)", e.name);
    if (tv && tr) {
      uint32_t full = (DWB >= 32) ? 0xFFFFFFFFu : ((1u << DWB) - 1);
      if (!tl && tk != full) MON("%c tx keep not all-ones on a non-last beat (0x%x)", e.name, tk);
      if (tl && (tk == 0 || ((tk & (tk + 1)) != 0))) MON("%c tx keep illegal on last beat (0x%x)", e.name, tk);
      int nb = tl ? __builtin_popcount(tk) : DWB;
      e.asm_buf.insert(e.asm_buf.end(), td, td + nb); e.in_frame = !tl; e.last_act = now_cycle;
      if (tl) {
        e.frames_tx++;
        // ---- wire-level protocol monitor (spec 9.4): every ACK/NAK this endpoint transmits must satisfy commit_next <= accept_next (modular),
        //      and a FATAL NAK (INV_REQ/REM_ACCESS/REM_OP) must have commit_next == accept_next (all earlier requests committed first)
        const std::vector<uint8_t>& f = e.asm_buf;
        if (f.size() >= 48 && f[12] == 0x88 && f[13] == 0xB5 && (f[15] == 0x20 || f[15] == 0x21)) {
          uint32_t cn = (f[20] << 16) | (f[21] << 8) | f[22], an = (f[45] << 16) | (f[46] << 8) | f[47]; uint32_t code = f[44];
          uint32_t d = (an - cn) & 0xFFFFFF;
          if (d >= 0x800000) MON("%c ACK/NAK with commit_next 0x%x AFTER accept_next 0x%x", e.name, cn, an);
          if (f[15] == 0x21 && (code == 3 || code == 4 || code == 5) && cn != an) MON("%c fatal NAK (code %u) sent with commit_next 0x%x != accept_next 0x%x", e.name, code, cn, an);
          if (f[15] == 0x20 && code != 0) MON("%c ACK frame with non-zero code", e.name);
        }
        offer_frame(txdir, e.asm_buf); e.asm_buf.clear();
      }
    }
    e.p_tx_valid = tv; e.p_tx_ready = tr; memcpy(e.p_tx_d, td, DWB); e.p_tx_k = tk; e.p_tx_l = tl;
    // --- receive stream handshake
    if (d->rx_valid && d->rx_ready) { e.last_act = now_cycle; rxdir.pos += DWB; if (rxdir.pos >= rxdir.cur.b.size()) { rxdir.active = false; } }
    // --- memory read port
    bool rv = d->mrd_valid, rr = d->mrd_ready; uint64_t ra = get_u64(d->mrd_addr);
    if (e.p_rd_valid && !e.p_rd_ready && (!rv || ra != e.p_rd_addr)) MON("%c mrd request changed/dropped while !mrd_ready", e.name);
    if (rv && (ra & (DWB - 1))) MON("%c mrd_addr 0x%llx not word aligned", e.name, (unsigned long long)ra);
    if (rv && rr) {
      RdResp r; r.d.resize(DWB); for (int i = 0; i < DWB; i++) r.d[i] = e.mem.rd(ra + i);
      r.due = std::max<uint64_t>(e.rd_last_due, now_cycle + rnd(e.lat_min, e.lat_max) + 1); e.rd_last_due = r.due;
      e.rq.push_back(r); e.rd_out++; if (e.rd_out > TB_MEM_RD_OUT + 1) MON("%c more than %d memory reads outstanding", e.name, TB_MEM_RD_OUT);
      fprintf(resf, "MEMR ep=%c cyc=%llu addr=0x%llx\n", e.name, (unsigned long long)now_cycle, (unsigned long long)ra); e.last_act = now_cycle;
    }
    e.p_rd_valid = rv; e.p_rd_ready = rr; e.p_rd_addr = ra;
    if (d->mrd_rsp_valid) { e.rq.pop_front(); e.rd_out--; e.last_act = now_cycle; }
    // --- memory write port
    bool wv = d->mwr_valid, wr_ = d->mwr_ready; uint64_t wa = get_u64(d->mwr_addr); uint8_t wd[32]; get_bytes(d->mwr_data, wd, DWB); uint32_t ws = d->mwr_strb;
    if (e.p_wr_valid && !e.p_wr_ready && (!wv || wa != e.p_wr_addr || ws != e.p_wr_s || memcmp(wd, e.p_wr_d, DWB) != 0)) MON("%c mwr request changed/dropped while !mwr_ready", e.name);
    if (wv && (wa & (DWB - 1))) MON("%c mwr_addr 0x%llx not word aligned", e.name, (unsigned long long)wa);
    if (wv && ws == 0) MON("%c mwr with empty strobe", e.name);
    if (wv && wr_) {
      WrAck w; w.addr = wa; w.d.assign(wd, wd + DWB); w.strb = ws;
      w.due = std::max<uint64_t>(e.wr_last_due, now_cycle + rnd(e.lat_min, e.lat_max) + 1); e.wr_last_due = w.due;
      e.wq.push_back(w); e.wr_out++; if (e.wr_out > TB_MEM_WR_OUT + 1) MON("%c more than %d memory writes outstanding", e.name, TB_MEM_WR_OUT);
      fprintf(resf, "MEMW ep=%c cyc=%llu addr=0x%llx strb=0x%x data=0x%s ack=%llu\n", e.name, (unsigned long long)now_cycle, (unsigned long long)wa, ws, word_hex(wd, DWB).c_str(), (unsigned long long)w.due);
      e.last_act = now_cycle;
    }
    e.p_wr_valid = wv; e.p_wr_ready = wr_; e.p_wr_addr = wa; e.p_wr_s = ws; memcpy(e.p_wr_d, wd, DWB);
    if (d->mwr_ack_valid) {   // the write becomes visible at the moment it is acknowledged
      WrAck& w = e.wq.front();
      for (int i = 0; i < DWB; i++) if ((w.strb >> i) & 1) e.mem.wr(w.addr + i, w.d[i]);
      e.wq.pop_front(); e.wr_out--; e.last_act = now_cycle;
    }
    // --- completion queue
    if (d->cq_valid && d->cq_ready) {
      fprintf(resf, "CQE ep=%c cyc=%llu wr_id=%llu op=%u status=%u len=%u qpn=%u\n", e.name, (unsigned long long)now_cycle, (unsigned long long)d->cq_wr_id,
              (unsigned)d->cq_op, (unsigned)d->cq_status, (unsigned)d->cq_len, (unsigned)d->cq_qpn);
      e.cqe_total++; e.cq_credit_open--; if (d->cq_op != 4) e.sq_open--; e.last_act = now_cycle;
    }
    // --- post handshakes and responses
    if (d->sq_post_valid && d->sq_post_ready) { e.sq_act = false; e.pend_rsp.push_back({e.sq_wr, true}); e.last_act = now_cycle; }
    if (d->rq_post_valid && d->rq_post_ready) { e.rq_act = false; e.pend_rsp.push_back({e.rq_wr, false}); e.last_act = now_cycle; }
    if (d->sq_post_rsp_valid) {
      auto it = std::find_if(e.pend_rsp.begin(), e.pend_rsp.end(), [](const PostRsp& p) { return p.sq; });
      uint64_t w = (it != e.pend_rsp.end()) ? it->wr_id : 0; if (it != e.pend_rsp.end()) e.pend_rsp.erase(it);
      fprintf(resf, "POST ep=%c wr_id=%llu which=SQ status=%u cyc=%llu\n", e.name, (unsigned long long)w, (unsigned)d->sq_post_rsp_status, (unsigned long long)now_cycle);
      if (d->sq_post_rsp_status == 0) { e.sq_open++; e.cq_credit_open++; }
    }
    if (d->rq_post_rsp_valid) {
      auto it = std::find_if(e.pend_rsp.begin(), e.pend_rsp.end(), [](const PostRsp& p) { return !p.sq; });
      uint64_t w = (it != e.pend_rsp.end()) ? it->wr_id : 0; if (it != e.pend_rsp.end()) e.pend_rsp.erase(it);
      fprintf(resf, "POST ep=%c wr_id=%llu which=RQ status=%u cyc=%llu\n", e.name, (unsigned long long)w, (unsigned)d->rq_post_rsp_status, (unsigned long long)now_cycle);
      if (d->rq_post_rsp_status == 0) e.cq_credit_open++;
    }
    if (e.cq_credit_open > TB_CQ_DEPTH) MON("%c CQ credit invariant broken: %d outstanding > %d", e.name, e.cq_credit_open, TB_CQ_DEPTH);
    // --- configuration
    if (d->cfg_valid && d->cfg_ready) { e.cfg_sent = true; e.last_act = now_cycle; }
    if (d->cfg_rsp_valid) {
      fprintf(resf, "CFG ep=%c cmd=%s idx=%u status=%u\n", e.name, e.cfg_name.c_str(), e.cfg_idx, (unsigned)d->cfg_rsp_status);
      e.cfg_done = true; e.cfg_act = false; e.last_act = now_cycle;
    }
  }
  // -------- phase 4: clock edge
  A.d->clk = 1; B.d->clk = 1; A.d->eval(); B.d->eval();
  now_cycle++;
}

// ---------------------------------------------------------------------------------------------------------------------------------
// scenario execution
// ---------------------------------------------------------------------------------------------------------------------------------
typedef std::map<std::string, std::string> KV;
static uint64_t num(const KV& kv, const char* k, uint64_t dflt = 0) { auto it = kv.find(k); return it == kv.end() ? dflt : std::strtoull(it->second.c_str(), nullptr, 0); }
static std::string str(const KV& kv, const char* k, const char* dflt = "") { auto it = kv.find(k); return it == kv.end() ? std::string(dflt) : it->second; }
static EP& epof(const KV& kv) { return str(kv, "ep", "A") == "B" ? B : A; }
static Dir& dirof(const KV& kv) { return str(kv, "dir", "AB") == "BA" ? BA : AB; }

static uint32_t qp_state_code(const std::string& s) {
  if (s == "RESET") return 0; if (s == "INIT") return 1; if (s == "RTR") return 2; if (s == "RTS") return 3; if (s == "ERR") return 4;
  fprintf(stderr, "bad qp state %s\n", s.c_str()); exit(2);
}
static void run_cycles(uint64_t n) { for (uint64_t i = 0; i < n; i++) tick(); }

static void do_cfg(EP& e, uint32_t cmd, const char* name) {
  e.cfg_cmd = cmd; e.cfg_name = name; e.cfg_act = true; e.cfg_sent = false; e.cfg_done = false;
  uint64_t t0 = now_cycle; while (!e.cfg_done) { tick(); if (now_cycle - t0 > 200000) { MON("%c cfg command %s never completed", e.name, name); e.cfg_act = false; break; } }
  tick();
}
// `option post_wait=N post_block=ok`: a post that is not accepted within N cycles is ABANDONED with a NOTE instead of a monitor error.  Used by chaos
// scenarios, where traffic is deliberately cut off and a bounded queue legitimately stays full (back-pressure, never a drop).
static uint64_t post_wait = 2000000; static bool post_block_ok = false;
static void post_gave_up(EP& e, const char* what) {
  if (post_block_ok) fprintf(resf, "NOTE cyc=%llu %c %s not accepted (queue full by design), post abandoned\n", (unsigned long long)now_cycle, e.name, what);
  else MON("%c %s never accepted", e.name, what);
}
static void do_post_sq(EP& e) {
  e.sq_act = true; uint64_t t0 = now_cycle;
  while (e.sq_act) { tick(); if (now_cycle - t0 > post_wait) { post_gave_up(e, "post_send"); e.sq_act = false; } }
}
static void do_post_rq(EP& e) {
  e.rq_act = true; uint64_t t0 = now_cycle;
  while (e.rq_act) { tick(); if (now_cycle - t0 > post_wait) { post_gave_up(e, "post_recv"); e.rq_act = false; } }
}
static bool system_quiet() {
  if (A.sq_open != 0 || B.sq_open != 0) return false;
  if (!AB.empty() || !BA.empty()) return false;
  if (!A.asm_buf.empty() || !B.asm_buf.empty()) return false;
  if (A.cfg_act || B.cfg_act || A.sq_act || A.rq_act || B.sq_act || B.rq_act) return false;
  if (now_cycle - A.last_act < 64 || now_cycle - B.last_act < 64) return false;
  return true;
}
static void hard_reset(EP& e) {
  e.d->rst_n = 0; for (int i = 0; i < 4; i++) tick();
  e.rq.clear(); e.wq.clear(); e.rd_out = 0; e.wr_out = 0; e.rd_last_due = e.wr_last_due = 0; e.cq_credit_open = 0; e.sq_open = 0; e.pend_rsp.clear();
  e.sq_act = e.rq_act = e.cfg_act = false; e.asm_buf.clear(); e.in_frame = false; e.p_tx_valid = false; e.p_rd_valid = false; e.p_wr_valid = false;
  e.d->rst_n = 1; tick(); tick();
}
static std::vector<uint8_t> unhex(const std::string& s) {
  std::vector<uint8_t> v; for (size_t i = 0; i + 1 < s.size(); i += 2) v.push_back((uint8_t)std::stoul(s.substr(i, 2), nullptr, 16)); return v;
}
static std::set<uint64_t> parse_list(const std::string& s) {
  std::set<uint64_t> r; std::stringstream ss(s); std::string t; while (std::getline(ss, t, ',')) if (!t.empty()) r.insert(std::strtoull(t.c_str(), nullptr, 0)); return r;
}

static void exec(const std::string& cmd, const KV& kv) {
  if (cmd == "build" || cmd == "param") return;
  if (cmd == "seed") { rng.seed(num(kv, "v", 1)); return; }
  if (cmd == "mem_fill") { EP& e = epof(kv); uint64_t a = num(kv, "addr"), n = num(kv, "len"); uint32_t p = (uint32_t)num(kv, "pat"); for (uint64_t i = 0; i < n; i++) e.mem.wr(a + i, pat_byte(p, (uint32_t)i)); return; }
  if (cmd == "option") { if (kv.count("post_wait")) post_wait = (uint64_t)num(kv, "post_wait", 2000000); if (kv.count("post_block")) post_block_ok = (str(kv, "post_block") == "ok"); return; }
  if (cmd == "mem_err") {                       // mem_err ep=A kind=rd|wr n=K   (K = 0 disarms)
    EP& e = epof(kv); std::string k = str(kv, "kind", "rd"); uint64_t n = (uint64_t)num(kv, "n", 0);
    if (k == "rd") { e.rd_err_n = n; e.rd_seen = 0; } else { e.wr_err_n = n; e.wr_seen = 0; }
    return;
  }
  if (cmd == "mem_lat") { EP& e = epof(kv); e.lat_min = (int)num(kv, "min", 1); e.lat_max = (int)num(kv, "max", e.lat_min); e.stall = (int)num(kv, "stall", 0); return; }
  if (cmd == "mr") { EP& e = epof(kv); e.cfg_idx = (uint32_t)num(kv, "idx"); e.cfg_va = num(kv, "va"); e.cfg_len = (uint32_t)num(kv, "len"); e.cfg_pa = num(kv, "pa");
    e.cfg_key = (uint32_t)num(kv, "key"); e.cfg_pd = (uint32_t)num(kv, "pd"); e.cfg_acc = (uint32_t)num(kv, "acc"); e.cfg_ctx = (uint32_t)num(kv, "ctx"); do_cfg(e, 1, "MR_SET"); return; }
  if (cmd == "mr_inval") { EP& e = epof(kv); e.cfg_idx = (uint32_t)num(kv, "idx"); do_cfg(e, 2, "MR_INVAL"); return; }
  if (cmd == "ctx_en") { EP& e = epof(kv); e.cfg_ctx_mask = (uint32_t)num(kv, "mask"); do_cfg(e, 4, "CTX_SET"); return; }
  if (cmd == "qp") {
    EP& e = epof(kv); e.cfg_qp_state = qp_state_code(str(kv, "state", "INIT")); e.cfg_qpn = (uint32_t)num(kv, "qpn", e.cfg_qpn); e.cfg_pd = (uint32_t)num(kv, "pd", e.cfg_pd);
    e.cfg_rqpn = (uint32_t)num(kv, "rqpn"); e.cfg_epoch = (uint32_t)num(kv, "epoch"); e.cfg_rq_psn = (uint32_t)num(kv, "rq_psn"); e.cfg_lmac = num(kv, "smac"); e.cfg_pmac = num(kv, "dmac");
    e.cfg_sq_psn = (uint32_t)num(kv, "sq_psn"); e.cfg_timeout = (uint32_t)num(kv, "timeout", 1000); e.cfg_retry = (uint32_t)num(kv, "retry", 3);
    e.cfg_rnr_retry = (uint32_t)num(kv, "rnr_retry", 3); e.cfg_rnr_delay = (uint32_t)num(kv, "rnr_delay", 100);
    do_cfg(e, 3, ("QP_" + str(kv, "state", "INIT")).c_str()); return; }
  if (cmd == "post_recv") { EP& e = epof(kv); e.rq_wr = num(kv, "wr_id"); e.rq_addr = num(kv, "addr"); e.rq_lk = (uint32_t)num(kv, "lkey"); e.rq_len = (uint32_t)num(kv, "len"); do_post_rq(e); return; }
  if (cmd == "post_send") {
    EP& e = epof(kv); std::string o = str(kv, "op", "SEND"); uint32_t op = (o == "SEND") ? 1 : (o == "WRITE") ? 2 : (o == "READ") ? 3 : (uint32_t)std::strtoul(o.c_str(), nullptr, 0);
    e.sq_op = op; e.sq_wr = num(kv, "wr_id"); e.sq_la = num(kv, "laddr"); e.sq_lk = (uint32_t)num(kv, "lkey"); e.sq_len = (uint32_t)num(kv, "len");
    e.sq_ra = num(kv, "raddr"); e.sq_rk = (uint32_t)num(kv, "rkey"); e.sq_flags = (uint32_t)num(kv, "flags"); do_post_sq(e); return; }
  if (cmd == "cq_drain") { epof(kv).cq_drain = num(kv, "on", 1) != 0; return; }
  if (cmd == "link") { Dir& D = dirof(kv); D.drop = (int)num(kv, "drop", D.drop); D.dup = (int)num(kv, "dup", D.dup); D.dmin = (int)num(kv, "delay_min", D.dmin); D.dmax = (int)num(kv, "delay_max", D.dmax);
    if (kv.count("stall")) ((&D == &AB) ? A : B).tx_stall = (int)num(kv, "stall"); return; }
  if (cmd == "link_script") { Dir& D = dirof(kv); if (kv.count("drop")) D.drop_n = parse_list(str(kv, "drop")); if (kv.count("dup")) D.dup_n = parse_list(str(kv, "dup"));
    if (kv.count("delay")) { std::stringstream ss(str(kv, "delay")); std::string t; while (std::getline(ss, t, ',')) { auto c = t.find(':'); if (c != std::string::npos) D.delay_n[std::strtoull(t.substr(0, c).c_str(), nullptr, 0)] = std::strtoull(t.substr(c + 1).c_str(), nullptr, 0); } } return; }
  if (cmd == "link_black") { dirof(kv).black = num(kv, "on", 1) != 0; return; }
  if (cmd == "reset") { EP& e = epof(kv); if (str(kv, "kind", "hard") == "hard") hard_reset(e); else { e.cfg_qp_state = 0; do_cfg(e, 3, "QP_RESET"); } return; }
  if (cmd == "inject") { Dir& D = dirof(kv); Frame f; f.b = unhex(str(kv, "hex")); f.err = num(kv, "err", 0) != 0; f.badkeep = num(kv, "badkeep", 0) != 0; f.due = now_cycle + 1 + num(kv, "delay", 0); f.seq = D.seq++; D.pend.push_back(f); return; }
  if (cmd == "run") { run_cycles(num(kv, "cycles", 1)); return; }
  if (cmd == "barrier") { uint64_t mx = num(kv, "max", 200000), t0 = now_cycle; while (!system_quiet() && now_cycle - t0 < mx) tick(); if (!system_quiet()) fprintf(resf, "NOTE cyc=%llu barrier timed out\n", (unsigned long long)now_cycle); return; }
  if (cmd == "wait_cqe") { EP& e = epof(kv); uint64_t n = num(kv, "n"), mx = num(kv, "max", 200000), t0 = now_cycle; while (e.cqe_total < n && now_cycle - t0 < mx) tick(); return; }
  if (cmd == "dump") { EP& e = epof(kv); uint64_t a = num(kv, "addr"), n = num(kv, "len"); std::vector<uint8_t> v; for (uint64_t i = 0; i < n; i++) v.push_back(e.mem.rd(a + i));
    fprintf(resf, "DUMP ep=%c addr=0x%llx hex=%s\n", e.name, (unsigned long long)a, hex_of(v).c_str()); return; }
  fprintf(stderr, "unknown scenario command: %s\n", cmd.c_str()); exit(2);
}

// Two standing invariants, checked at the end of EVERY run for both endpoints:
//  (1) CQ credit conservation (spec 12.2): the DUT's free credits equal CQ_DEPTH minus the posted WQEs whose CQE the host has not consumed.
//      This catches credit-counter drift (a lost or doubled credit); a completion that is never produced is NOT visible here, because the
//      host's own bookkeeping then still counts that WQE as open.
//  (2) After a QP reset every posted WQE has produced exactly one CQE (flushed ones included): in state RESET nothing may be open.
//      This is the signature of a lost completion (e.g. a consumed RQE whose CQE was swallowed by the reset).
#ifdef TB_PC
#define DUT_CREDITS(d) ((unsigned)(d)->rootp->sf_rdma_engine_pc__DOT__u_e__DOT__cq_credits)
#else
#define DUT_CREDITS(d) ((unsigned)(d)->rootp->sf_rdma_engine__DOT__cq_credits)
#endif
static void check_credits(EP& e) {
  unsigned cr = DUT_CREDITS(e.d); int want = TB_CQ_DEPTH - e.cq_credit_open;
  fprintf(resf, "FINAL ep=%c credits=%u open=%d depth=%d\n", e.name, cr, e.cq_credit_open, TB_CQ_DEPTH);
  if ((int)cr != want) MON("%c CQ credit leak: DUT has %u free credits, expected %d (CQ_DEPTH %d - %d open)", e.name, cr, want, TB_CQ_DEPTH, e.cq_credit_open);
  if (e.d->qp_state == 0 && e.cq_credit_open != 0) MON("%c QP is in RESET but %d posted WQE(s) never produced a completion", e.name, e.cq_credit_open);
}
static void dump_counters(EP& e) {
  for (int i = 0; i < PERF_N; i++) {
    e.d->perf_idx = i; A.d->eval(); B.d->eval();
    fprintf(resf, "CNT ep=%c name=%s value=%llu\n", e.name, PERF_NAMES[i], (unsigned long long)e.d->perf_data);
  }
  fprintf(resf, "QPST ep=%c state=%u cause=%u\n", e.name, (unsigned)e.d->qp_state, (unsigned)e.d->qp_err_cause);
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  std::vector<const char*> pos; for (int i = 1; i < argc; i++) if (argv[i][0] != '+') pos.push_back(argv[i]);   // +verilator+... are plusargs
  if (pos.size() < 2) { fprintf(stderr, "usage: %s [+verilator+rand+reset+2 +verilator+seed+N] scenario.scn result.res\n", argv[0]); return 2; }
  resf = fopen(pos[1], "w"); if (!resf) { perror("result"); return 2; }
  A.name = 'A'; B.name = 'B'; A.d = new DUT; B.d = new DUT;
  for (EP* e : {&A, &B}) {
    DUT* d = e->d; d->clk = 0; d->rst_n = 0; d->cfg_valid = 0; d->sq_post_valid = 0; d->rq_post_valid = 0; d->cq_ready = 1; d->rx_valid = 0; d->tx_ready = 1;
    d->mrd_ready = 1; d->mwr_ready = 1; d->mrd_rsp_valid = 0; d->mwr_ack_valid = 0; d->perf_idx = 0; d->perf_clear = 0; d->rx_err = 0; d->rx_last = 0; d->rx_keep = 0;
    d->mrd_rsp_err = 0; d->mwr_ack_err = 0;
  }
  A.d->eval(); B.d->eval();
  for (int i = 0; i < 4; i++) { A.d->clk = 1; B.d->clk = 1; A.d->eval(); B.d->eval(); A.d->clk = 0; B.d->clk = 0; A.d->eval(); B.d->eval(); }
  A.d->rst_n = 1; B.d->rst_n = 1;
  tick(); tick();
  std::ifstream in(pos[0]); if (!in) { perror("scenario"); return 2; }
  std::string line; int lineno = 0;
  while (std::getline(in, line)) {
    lineno++; auto h = line.find('#'); if (h != std::string::npos) line = line.substr(0, h);
    std::stringstream ss(line); std::string cmd; if (!(ss >> cmd)) continue;
    KV kv; std::string tok; while (ss >> tok) { auto eq = tok.find('='); if (eq == std::string::npos) continue; kv[tok.substr(0, eq)] = tok.substr(eq + 1); }
    exec(cmd, kv);
  }
  run_cycles(8);
  check_credits(A); check_credits(B);
  dump_counters(A); dump_counters(B);
  fprintf(resf, "END cycles=%llu timeout=0 monitor_errors=%d\n", (unsigned long long)now_cycle, mon_errors);
  fclose(resf); A.d->final(); B.d->final(); delete A.d; delete B.d;
  return mon_errors ? 1 : 0;
}
