#!/usr/bin/env python3
"""gen_review.py - adversarial-review reproduction scenarios (tests/rdma/review/*.scn).  Run: python3 -I gen_review.py [name-substring]"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'gen'))
sys.path.insert(0, os.path.join(HERE, '..', 'model'))
from scn_lib import (Scn, va, pa, key, MRS, MAC, QPN, SRC, RDST, WDST, RQB, RSRC, SRC_LEN, RDST_LEN, WDST_LEN, RQB_LEN,
                     RSRC_LEN, init_mem, npsn, K, MAIN_END, mva, W, R, SND, RQ, D, new, inject, peer_ab, peer_ba, payload)
import frames as F

SC = []
def sc(name, **kw):
    def deco(fn):
        SC.append((name, fn, kw)); return fn
    return deco

def hdr(s, text):
    for ln in text.strip().splitlines():
        s.comment(ln)

# ---------------------------------------------------------------------------------------------------------------------------
@sc('rv01_read_then_fatal_resp_lost', timeout=300, retry=2)
def _(s):
    hdr(s, """REVIEW rv01: READ (3 segments) followed by a WRITE with a bad rkey; the READ_RESP frames of the READ are lost on the way back.
    Spec 9.6: the retransmission timer protects every unfinished entry; 9.5(6): the fatal NAK only stops *issuing*.  A fatal-mode responder
    never re-executes a READ (11.2), so the lost READ data can never be re-sent: the READ ends RETRY_EXC_ERR after its retries (timeout 300,
    2 retries), the faulty WRITE and everything later is flushed.  Old RTL: err_pending disarmed the timer and blocked transmission -> the READ
    never completed and the QP stayed in RTS for ever (hang).""")
    s.cmd('link_script', dir='BA', drop='1,2,3')
    R(s, 600, dst=0, src=0)
    W(s, 64, src=0, dst=0, rkey=0xDEAD)
    s.barrier(100000)
    D(s, 'A', RDST, 0, 600)


@sc('rv01b_read_then_fatal_last_resp_lost', timeout=300, retry=2)
def _(s):
    hdr(s, """REVIEW rv01b: same as rv01 but only the LAST READ_RESP segment is lost (B->A ordinal 3).""")
    s.cmd('link_script', dir='BA', drop='3')
    R(s, 600, dst=0, src=0)
    W(s, 64, src=0, dst=0, rkey=0xDEAD)
    s.barrier(100000)
    D(s, 'A', RDST, 0, 600)

@sc('rv01c_read_then_fatal_control')
def _(s):
    hdr(s, """REVIEW rv01c: control for rv01 -- no loss.  Must pass.""")
    R(s, 600, dst=0, src=0)
    W(s, 64, src=0, dst=0, rkey=0xDEAD)
    s.barrier(100000)
    D(s, 'A', RDST, 0, 600)

@sc('rv02_recv_cqe_order_forced_err')
def _(s):
    hdr(s, """REVIEW rv02: B has RQEs 101,102,103.  A sends one SEND (consumes 101); B's memory is slow, so the RECV CQE of 101 waits for the write
    acknowledge.  B is forced to ERR in between.  Spec 13: RECV CQEs are in RQ post order -> [101 OK, 102 FLUSH, 103 FLUSH].
    RTL: flush_rq has priority over the commit-ring CQE -> 102/103 FLUSH are produced before 101 OK.""")
    s.cmd('mem_lat', ep='B', min=400, max=400, stall=0)
    RQ(s, 0, 256, wr_id=101); RQ(s, 0x100, 256, wr_id=102); RQ(s, 0x200, 256, wr_id=103)
    SND(s, 100)
    s.run(150)
    s.cmd('qp', ep='B', state='ERR')
    s.barrier(20000)
    D(s, 'B', RQB, 0, 100)

@sc('rv03_seq_nak_dropped_by_progress', timeout=3000)
def _(s):
    hdr(s, """REVIEW rv03: four 64-byte WRITEs; A->B frame #2 is lost, the first ACK of B (B->A #1) is lost, so the SEQ_ERR NAK(an=psn2) carries the
    commit of WRITE 1.  Spec 9.5(4): NAK(SEQ_ERR) => txp <- an (go-back-N at once).  RTL: the NAK also retires entry 1; retire_go (= progress)
    coincides with the registered nak_retry pulse and sf_rdma_retry's `progress` branch swallows it -> no fast retransmit, recovery only by the
    3000-cycle timer.  Look at the CQE cycles and CNT retry_nak / retry_timeout of ep A.""")
    s.cmd('link_script', dir='AB', drop='2')
    s.cmd('link_script', dir='BA', drop='1')
    for i in range(4):
        W(s, 64, src=i * 64, dst=i * 64)
    s.barrier(60000)
    D(s, 'B', WDST, 0, 256)

@sc('rv04_rnr_nak_dropped_by_progress', timeout=3000, rnr_delay=200)
def _(s):
    hdr(s, """REVIEW rv04: WRITE then SEND, B has no RQE; the ACK for the WRITE is lost (B->A #1), so the RNR NAK carries the WRITE's commit.  The
    RQE is posted 1000 cycles later.  Spec 9.5(5)/9.6: honour rnr_delay (200) and retry -> SEND completes shortly after the RQE exists.
    RTL: the RNR NAK retires the WRITE in the same cycle (progress) and the retry unit swallows rnr_nak_p -> no back-off; the SEND is
    recovered only by the 3000-cycle retransmission timer.""")
    s.cmd('link_script', dir='BA', drop='1')
    s.cmd('link_script', dir='AB', delay='2:60')          # the SEND reaches B after the WRITE was committed and ACKed
    W(s, 64, src=0, dst=0)
    SND(s, 64, src=0x100)
    s.run(1000)
    RQ(s, 0, 256, wr_id=101)
    s.barrier(60000)
    D(s, 'B', RQB, 0, 64)

@sc('rv05_recv_cqe_lost_behind_stuck_read')
def _(s):
    hdr(s, """REVIEW rv05: A READs 3000 bytes from B and then SENDs 64 bytes (B has RQE 101).  B's transmit side is frozen (tx stall 100 %), so B's READ
    executor (rdgen) cannot finish; the SEND is accepted behind the READ in B's commit ring and its data is written.  B is forced to ERR,
    the stall is released, B is reset.  Spec 11.1: a SEND whose last segment was accepted completes its RECV with OK ("every consumed WQE
    produces exactly one CQE").  RTL: the ring commits in order, the READ entry never completes (rdgen halted), so the RECV CQE of the
    consumed RQE is never produced and the ring is cleared by the reset -> the RQE and its CQ credit are lost for ever.""")
    RQ(s, 0, 256, wr_id=101)
    s.cmd('link', dir='BA', stall=100)
    R(s, 3000, dst=0, src=0)
    SND(s, 64)
    s.run(4000)
    s.cmd('qp', ep='B', state='ERR')
    s.cmd('link', dir='BA', stall=0)
    s.run(3000)
    s.cmd('qp', ep='B', state='RESET')
    s.barrier(20000)
    D(s, 'B', RQB, 0, 64)

@sc('rv06_inval_ok_while_read_placement_in_flight')
def _(s):
    hdr(s, """REVIEW rv06: B READs 1024 bytes from A; B's memory is very slow (write ack latency 600), so the READ_RESP placement DMA lags far behind.
    B is forced to ERR while the placement is queued: the READ WQE is flushed at once and its local grant (reference) is released.  The host
    then invalidates the region (MR_INVAL) -> accepted (status 0 / not BUSY) although the DMA still has to write the destination;
    dump 1 (right after the MR_INVAL) still holds the old pattern, dump 2 (later) holds the READ data: the engine wrote into an
    invalidated region (spec 8.4: 'MR_INVAL can never pull a region out from under an in-flight DMA').""")
    s.cmd('mem_lat', ep='B', min=600, max=600, stall=0)
    R(s, 1024, dst=0, src=0, ep='B')
    s.run(2500)
    s.cmd('qp', ep='B', state='ERR')
    s.run(50)
    s.cmd('mr_inval', ep='B', idx=0)
    D(s, 'B', RDST, 0, 1024)
    s.run(60000)
    D(s, 'B', RDST, 0, 1024)

@sc('rv07_memerr_requester_source_read')
def _(s):
    hdr(s, """REVIEW rv07 (`mem_err ep=A kind=rd n=3`: the 3rd read response of A is an ERROR response with garbage data).  A WRITEs 256 bytes from
    local memory.  Spec 11.1(f)/13: a memory error response -> the WQE completes LOC_OP_ERR and the QP enters ERR (INT_ERR); NOTHING wrong may be
    transmitted or committed remotely.  Old RTL: dma_rd.done_err was unconnected, the garbage was transmitted, B committed it, A's WQE completed OK.""")
    s.cmd('mem_err', ep='A', kind='rd', n=3)
    W(s, 256, src=0, dst=0)
    s.barrier(20000)
    D(s, 'B', WDST, 0, 256)

@sc('rv08_memerr_responder_read_data')
def _(s):
    hdr(s, """REVIEW rv08 (`mem_err ep=B kind=rd n=3`): A READs 256 bytes from B; B's memory returns an error response (garbage data) for the 3rd word.
    B must NOT send the response (QP ERR, cause INT_ERR); A is not told (11.2: a QP in ERR for another reason sends nothing) and ends RETRY_EXC_ERR
    after its retries.  Old RTL: the garbage was sent in READ_RESP and A completed the READ with OK.""")
    s.cmd('mem_err', ep='B', kind='rd', n=3)
    R(s, 256, dst=0, src=0)
    s.barrier(20000)
    D(s, 'A', RDST, 0, 256)

@sc('rv09_memerr_write_ack_send')
def _(s):
    hdr(s, """REVIEW rv09 (`mem_err ep=B kind=wr n=3`): A SENDs 256 bytes to B; the 3rd write of B's memory is acknowledged with an ERROR (not applied).
    The RECV completes LOC_OP_ERR (not OK), B's QP enters ERR (INT_ERR), the entry is not ACKed.  Old RTL: the entry still committed and the RECV CQE
    said OK/len=256 although part of the receive buffer was never written.""")
    s.cmd('mem_err', ep='B', kind='wr', n=3)
    RQ(s, 0, 512, wr_id=101)
    SND(s, 256)
    s.barrier(20000)
    D(s, 'B', RQB, 0, 256)

@sc('rv10_frames_leave_after_err')
def _(s):
    hdr(s, """REVIEW rv10: A's transmitter is frozen (tx stall 100 %) while A queues four 64-byte WRITEs (frames sit in the adapter's header FIFO).  A is forced to ERR
    (all four WQEs complete WR_FLUSH_ERR), then the stall is released.  Spec 11.1: 'Issue stops immediately; no further frame carrying new requests
    is transmitted.'  RTL: ERR only gates the requester's *offer* (tx_en); frames already accepted by the adapter still leave (only RESET holds/flushes them),
    B executes the four WRITEs although every WQE was reported flushed.  (B's WDST area changes; the model expects it untouched.)""")
    s.cmd('link', dir='AB', stall=100)
    for i in range(4):
        W(s, 64, src=i * 64, dst=i * 64)
    s.run(600)
    s.cmd('qp', ep='A', state='ERR')
    s.run(50)
    s.cmd('link', dir='AB', stall=0)
    s.run(3000)
    D(s, 'B', WDST, 0, 256)
    s.barrier(20000)

@sc('rv11_reset_after_guard_violation')
def _(s):
    hdr(s, """REVIEW rv11 (fault injection in a COPY of the RTL: +GUARD_WR_N=2 makes the 2nd responder WRITE command look like a DMA-guard failure -- the
    situation the guard exists for).  A WRITEs 3 x 64 bytes; B's guard fires, B enters ERR (cause 6) as specified.  The trusted agent then resets
    B.  RTL: the failing command is converted to DISCARD but the receive processor already pushed a pending-completion tag for it; a DISCARD
    never completes, so the tag FIFO never empties, rx `quiet` stays low, the DRAIN never ends: `qp ep=B state=RESET` is never answered and the
    configuration port stays busy for ever (only rst_n recovers).""")
    W(s, 64, src=0, dst=0)
    W(s, 64, src=64, dst=64)
    W(s, 64, src=128, dst=128)
    s.run(1500)
    s.cmd('qp', ep='B', state='RESET')
    s.run(500)

@sc('rv12_chi_update_lost_to_retire_fixup', timeout=3000)
def _(s):
    hdr(s, """REVIEW rv12 (cycle-exact; found with sweep_chi.py): READ then two WRITEs from A.  All B->A frames except the READ_RESP and (ordinals 2..6) the ACKs are
    dropped; an ACK covering all three requests is injected so that it is processed in the very cycle in which the READ retires through its data placement
    (A's write latency 40).  requester.sv: `if (commit_adv) chi <= ack_cn;` is followed in the same always_ff by the retire fix-up
    `if (!psn_le(una+1, chi)) chi <= una+1;` (uses the OLD chi) -> the ACK's commit frontier is lost; the two WRITEs complete only after
    two retransmission timeouts (CQE cycle ~9400) instead of ~254.  Neighbouring injection delays (148, 150) complete at ~254.""")
    s.cmd('link_script', dir='BA', drop='2,3,4,5,6')
    s.cmd('mem_lat', ep='A', min=40, max=40, stall=0)
    R(s, 64, dst=0, src=0)
    W(s, 64, src=0, dst=0)
    W(s, 64, src=64, dst=64)
    nxt = s.psn['A']
    inject(s, 'BA', F.ack_frame(peer_ba(s), nxt, nxt)) if False else s.cmd('inject', dir='BA', hex=F.to_hex(F.ack_frame(peer_ba(s), nxt, nxt)), delay=149)
    s.barrier(40000)

@sc('rv13_drop_counter_order_paylen_gt_mtu')
def _(s):
    hdr(s, """REVIEW rv13: spec 3.4 evaluation order is ... ethertype, mac, version, opcode, THEN 'paylen > MTU or class rule' -> rx_drop_len, then qpn, epoch, state.
    Three frames with an over-long payload (300 > MTU 256, frame length consistent with the length rule) that ALSO have an earlier fault: wrong ethertype,
    wrong destination MAC, unknown opcode.  Model: rx_drop_ethertype / rx_drop_mac / rx_drop_opcode.  RTL (transport_adapter.sv f_len is first in `why`):
    all three are counted in rx_drop_len.  (Frames are dropped in both cases; only the counter attribution differs.)""")
    pa_ = peer_ab(s)
    pl = bytes(300)
    inject(s, 'AB', F.build_frame(MAC['B'], MAC['A'], 0x02, QPN['B'], s.epoch, s.psn['A'], flags=3, payload=pl, mlen=300, va=mva(WDST), rkey=K, ethertype=0x1234))
    s.barrier(3000)
    inject(s, 'AB', F.build_frame(MAC['B'] ^ 0x10, MAC['A'], 0x02, QPN['B'], s.epoch, s.psn['A'], flags=3, payload=pl, mlen=300, va=mva(WDST), rkey=K))
    s.barrier(3000)
    inject(s, 'AB', F.build_frame(MAC['B'], MAC['A'], 0x55, QPN['B'], s.epoch, s.psn['A'], flags=3, payload=pl, mlen=300, va=mva(WDST), rkey=K))
    s.barrier(3000)

@sc('rv14_inval_ok_while_partial_send_dma_in_flight')
def _(s):
    hdr(s, """REVIEW rv14: like rv06 for the RESPONDER side.  A SENDs 600 bytes (3 segments) into B's 1024-byte RQE; the 3rd frame is lost so a SEND message is
    'in progress' at B; B's memory is slow (600 cycles).  B is forced to ERR: flush_cur completes RQE 101 with WR_FLUSH_ERR and releases the RQE grant
    (rx.sv rel_f) although the DMA writes of the two accepted segments are still queued.  MR_INVAL then answers OK (not BUSY) and the dumps before /
    after show the receive buffer being written AFTER the region was invalidated.""")
    s.cmd('mem_lat', ep='B', min=600, max=600, stall=0)
    s.cmd('link_script', dir='AB', drop='3')
    RQ(s, 0, 1024, wr_id=101)
    SND(s, 600)
    s.run(300)
    s.cmd('qp', ep='B', state='ERR')
    s.run(50)
    s.cmd('mr_inval', ep='B', idx=0)
    D(s, 'B', RQB, 0, 512)
    s.run(60000)
    D(s, 'B', RQB, 0, 512)

# ---------------------------------------------------------------------------------------------------------------------------
def build_all(outdir, only=None):
    os.makedirs(outdir, exist_ok=True)
    for name, fn, kw in SC:
        if only and only not in name: continue
        s = Scn(name, '')
        s.setup(**kw)
        init_mem(s)
        fn(s)
        s.write(os.path.join(outdir, name + '.scn')) if hasattr(s, 'write') else None
        print('wrote', name)

if __name__ == '__main__':
    build_all(HERE, sys.argv[1] if len(sys.argv) > 1 else None)
