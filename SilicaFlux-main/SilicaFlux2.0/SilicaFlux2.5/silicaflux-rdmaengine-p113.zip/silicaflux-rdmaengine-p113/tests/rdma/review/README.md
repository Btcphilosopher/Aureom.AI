# tests/rdma/review - adversarial review reproductions

`gen_review.py [substr]` writes the `rv*.scn` scenarios (they use only the scenario language of TRANSPORT_SPEC Appendix A, built with `tests/rdma/gen/scn_lib.py`).

* Plain scenarios (run with the normal bench + independent checker):
  `python3 scripts/regress.py --dir tests/rdma/review --tag _rev --report /tmp/review.md`
  rv01, rv01b, rv02, rv03, rv04, rv05, rv06, rv10 FAIL or show the described behaviour (see docs/REVIEW_FINDINGS.md for what to look at;
  some of them fail in the model comparison only because the model does not model the injected timing -- the finding text says which mismatch is the real one).
  rv01c is the control (passes).
* rv07-rv09 need memory ERROR injection that the stock bench cannot do: `tb_memerr.patch` (unified diff against tests/rdma/bench/tb_rdma.cpp) adds
  env vars `SF_RD_ERR=A:n` (n-th read response of endpoint A is an error response with garbage data) and `SF_WR_ERR=B:n` (n-th write acknowledge is an
  error and the write is not applied).  `run_memerr.sh` builds the patched bench in a scratch directory and runs rv07-rv09.
* rv11 needs a guard-violation injection in a COPY of the RTL (`rtl_guard_inject.patch`, +GUARD_WR_N=n plusarg), built by `run_guard_inject.sh`.
* `rtl_instrumentation.patch` is the (copy-only) white-box instrumentation used for the random campaigns (`@@INV` / `@@EVT` lines): invariants txp>=una,
  FIFO overflow/underflow, ref wrap, release-port collisions, dropped retry events, final CQ credits.  It is NOT applied to rtl/.
