#!/bin/bash
# Build the stock RTL with a PATCHED COPY of the bench (memory error injection) in a scratch dir and run rv07-rv09.
set -e
ROOT=$(cd "$(dirname "$0")/../../.." && pwd); W=${1:-/tmp/sf_review_memerr}
rm -rf "$W"; mkdir -p "$W"; cp -r "$ROOT/rtl" "$ROOT/third_party" "$ROOT/Makefile" "$ROOT/scripts" "$W/"; mkdir -p "$W/tests/rdma" "$W/docs" "$W/out"
cp -r "$ROOT/tests/rdma/bench" "$W/tests/rdma/"; (cd "$W" && patch -p0 tests/rdma/bench/tb_rdma.cpp < "$ROOT/tests/rdma/review/tb_memerr.patch" >/dev/null && make build >/dev/null)
TB="$W/out/tb_dw64_mtu256_w8"; R="$ROOT/tests/rdma/review"
SF_RD_ERR=A:3 $TB $R/rv07_memerr_requester_source_read.scn $W/rv07.res; SF_RD_ERR=B:3 $TB $R/rv08_memerr_responder_read_data.scn $W/rv08.res; SF_WR_ERR=B:3 $TB $R/rv09_memerr_write_ack_send.scn $W/rv09.res
grep -H -E "^(CQE|QPST|NOTE)" $W/rv07.res $W/rv08.res $W/rv09.res
