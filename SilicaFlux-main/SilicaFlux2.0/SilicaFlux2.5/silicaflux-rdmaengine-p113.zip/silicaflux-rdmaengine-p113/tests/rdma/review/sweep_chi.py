#!/usr/bin/env python3
"""sweep_chi.py TB [lo hi] : rv12 search -- READ then two WRITEs, all B->A frames except the READ_RESP dropped, an ACK (cn=nxt) injected N cycles after the
last post.  When the ACK is processed in the very cycle the READ retires (READ done via placement while chi==una) the requester's retire-time frontier fix-up
(`chi <= una+1`) overwrites the ACK's `chi <= ack_cn`: the WRITEs then complete only after the retransmission timer (~3000 cycles) instead of at once."""
import sys, os, subprocess, re
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, '..', 'gen')); sys.path.insert(0, os.path.join(HERE, '..', 'model'))
from scn_lib import *
import frames as F
tb = sys.argv[1]; lo = int(sys.argv[2]) if len(sys.argv) > 2 else 60; hi = int(sys.argv[3]) if len(sys.argv) > 3 else 220
L = int(os.environ.get('LAT', '40'))
res = []
for n in range(lo, hi):
    s = Scn('rv12_chi_%d' % n, ''); s.setup(timeout=3000); init_mem(s)
    s.cmd('link_script', dir='BA', drop=','.join(str(i) for i in range(2, 7)))
    s.cmd('mem_lat', ep='A', min=L, max=L, stall=0)
    R(s, 64, dst=0, src=0)
    W(s, 64, src=0, dst=0); W(s, 64, src=64, dst=64)
    nxt = s.psn['A']
    fr = F.ack_frame(peer_ba(s), nxt, nxt)
    s.cmd('inject', dir='BA', hex=F.to_hex(fr), delay=n)
    s.barrier(20000)
    fn = '/tmp/rv12_%d.scn' % n; s.write(fn)
    p = subprocess.run([tb, fn, '/tmp/rv12_%d.res' % n], capture_output=True, text=True)
    cq = [int(re.search(r'cyc=(\d+)', l).group(1)) for l in open('/tmp/rv12_%d.res' % n) if l.startswith('CQE ep=A')]
    ev = [l for l in p.stdout.splitlines() if 'chi_update_lost' in l or 'ahi_update_lost' in l]
    res.append((n, max(cq) if cq else -1, len(cq), ev))
slow = [r for r in res if r[1] > 1500 or r[2] < 3]
print('swept %d delays; slow/incomplete: %s' % (len(res), [(r[0], r[1], r[2]) for r in slow]))
print('instrumented events:', [(r[0], r[3][0]) for r in res if r[3]])
