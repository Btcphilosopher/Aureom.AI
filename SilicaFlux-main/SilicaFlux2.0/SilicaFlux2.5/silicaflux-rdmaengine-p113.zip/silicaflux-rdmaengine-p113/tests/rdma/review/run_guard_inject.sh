#!/bin/bash
# COPY of the RTL with a guard-violation injection (plusarg +GUARD_WR_N=2): rv11 -> QP reset never completes.
set -e
ROOT=$(cd "$(dirname "$0")/../../.." && pwd); W=${1:-/tmp/sf_review_guard}
rm -rf "$W"; mkdir -p "$W"; cp -r "$ROOT/rtl" "$ROOT/third_party" "$ROOT/Makefile" "$ROOT/scripts" "$W/"; mkdir -p "$W/tests/rdma" "$W/docs" "$W/out"; cp -r "$ROOT/tests/rdma/bench" "$W/tests/rdma/"
(cd "$W" && patch -p0 rtl/sf_rdma_dma_wr.sv < "$ROOT/tests/rdma/review/rtl_guard_inject.patch" >/dev/null && make build >/dev/null)
"$W/out/tb_dw64_mtu256_w8" +GUARD_WR_N=2 "$ROOT/tests/rdma/review/rv11_reset_after_guard_violation.scn" "$W/rv11.res" || true
grep -E "^(MON|QPST|END)" "$W/rv11.res"
