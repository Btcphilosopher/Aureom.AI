#!/usr/bin/env python3
"""scn.py - scenario-file (A.1) / result-file (A.2) parsers and a scenario writer.

Written from docs/TRANSPORT_SPEC.md only (independent of the RTL).

Parsed scenario form (deliberately simple):
    [ {'cmd': 'post_send', 'line': 12, 'text': '<original line>', 'ep': 'A', 'wr_id': 1, 'op': 'WRITE', ...}, ... ]
Numbers are ints (decimal or 0x hex).  Symbolic values stay strings:
    ep -> 'A'|'B', dir -> 'AB'|'BA', state -> 'INIT'..., op -> 'SEND'|'WRITE'|'READ' or int, kind -> 'hard'|'qp',
    hex -> raw string.  link_script keys drop/dup -> [int,...], delay -> [(ordinal, cycles), ...].
Parsed result form: see parse_res() (a Result object).
"""
import re

# ---------------------------------------------------------------------------
# Name <-> code tables (spec sections 6.3, 8.3, 13, 14)
# ---------------------------------------------------------------------------
POST_STATUS = {'POST_OK': 0, 'POST_ERR_OPCODE': 1, 'POST_ERR_STATE': 2, 'POST_ERR_LEN': 3,
               'POST_ERR_FIELDS': 4, 'POST_ERR_RANGE': 5}
CFG_STATUS = {'OK': 0, 'ERR_IDX': 1, 'ERR_BUSY': 2, 'ERR_EXISTS': 3, 'ERR_DUPKEY': 4,
              'ERR_FIELDS': 5, 'ERR_RANGE': 6, 'ERR_NOENT': 7, 'ERR_STATE': 8}
CQE_STATUS = {'OK': 0, 'LOC_LEN_ERR': 1, 'LOC_PROT_ERR': 2, 'WR_FLUSH_ERR': 3, 'REM_ACCESS_ERR': 4,
              'REM_INV_REQ_ERR': 5, 'REM_OP_ERR': 6, 'RETRY_EXC_ERR': 7, 'RNR_RETRY_EXC_ERR': 8,
              'LOC_OP_ERR': 9}
CQE_OP = {'SEND': 1, 'WRITE': 2, 'READ': 3, 'RECV': 4}
QP_STATES = ['RESET', 'INIT', 'RTR', 'RTS', 'ERR']
FAULT_CLASSES = ['bad_key', 'bad_pd', 'bad_dir', 'bad_perm', 'bad_len', 'overflow', 'range', 'page_cross', 'xlate']

POST_STATUS_NAME = {v: k for k, v in POST_STATUS.items()}
CFG_STATUS_NAME = {v: k for k, v in CFG_STATUS.items()}
CQE_STATUS_NAME = {v: k for k, v in CQE_STATUS.items()}
CQE_OP_NAME = {v: k for k, v in CQE_OP.items()}

# ---------------------------------------------------------------------------
# Deterministic pattern (A.3)
# ---------------------------------------------------------------------------


def pat(seed, i):
    """pat(seed, i) of spec A.3."""
    x = (seed * 2654435761 + i * 2246822519) & 0xFFFFFFFF
    x ^= x >> 15
    x = (x * 2654435761) & 0xFFFFFFFF
    return (x >> 24) & 0xFF


# ---------------------------------------------------------------------------
# Number / value parsing
# ---------------------------------------------------------------------------
_NUM_RE = re.compile(r'^[+-]?(0[xX][0-9a-fA-F]+|[0-9]+)$')


def is_num(s):
    return bool(_NUM_RE.match(s))


def parse_num(s):
    """decimal or 0x hex (never octal: '010' is ten)."""
    s = s.strip()
    neg = s.startswith('-')
    if s[:1] in '+-':
        s = s[1:]
    if s[:2] in ('0x', '0X'):
        v = int(s[2:], 16)
    else:
        v = int(s, 10)
    return -v if neg else v


_STR_KEYS = {'state', 'ep', 'dir', 'kind', 'hex', 'cmd', 'name', 'which', 'op'}
_LIST_KEYS_LINK_SCRIPT = {'drop', 'dup', 'delay'}


class ScnError(Exception):
    pass


def _conv(cmd, key, val, lineno):
    if cmd == 'link_script' and key in _LIST_KEYS_LINK_SCRIPT:
        items = [x for x in val.split(',') if x != '']
        out = []
        for it in items:
            try:
                if key == 'delay':
                    n, cyc = it.split(':')
                    out.append((parse_num(n), parse_num(cyc)))
                else:
                    out.append(parse_num(it))
            except ValueError:
                raise ScnError('line %d: bad %s item %r' % (lineno, key, it))
        return out
    if key == 'hex':
        return val
    if key in ('ep', 'dir', 'state', 'kind'):
        return val.upper() if key != 'kind' else val.lower()
    if key == 'op':
        return val.upper() if not is_num(val) else parse_num(val)
    if is_num(val):
        return parse_num(val)
    return val


def parse_scn_text(text):
    cmds = []
    for lineno, raw in enumerate(text.splitlines(), 1):
        line = raw.split('#', 1)[0].strip()
        if not line:
            continue
        toks = line.split()
        c = {'cmd': toks[0].lower(), 'line': lineno, 'text': raw.rstrip()}
        for t in toks[1:]:
            if '=' not in t:
                raise ScnError('line %d: token %r is not key=value' % (lineno, t))
            k, v = t.split('=', 1)
            k = k.lower()
            if k in c and k not in ('cmd',):
                raise ScnError('line %d: duplicate key %r' % (lineno, k))
            c[k] = _conv(c['cmd'], k, v, lineno)
        cmds.append(c)
    return cmds


def parse_scn(path):
    with open(path, 'r') as f:
        return parse_scn_text(f.read())


# ---------------------------------------------------------------------------
# Scenario writer
# ---------------------------------------------------------------------------
_HEX_KEYS = {'addr', 'laddr', 'raddr', 'va', 'pa', 'key', 'lkey', 'rkey', 'smac', 'dmac', 'mask', 'acc'}


def _fmt(key, v):
    if isinstance(v, bool):
        return '1' if v else '0'
    if isinstance(v, int):
        if key in _HEX_KEYS:
            return '0x%X' % v
        return str(v)
    if isinstance(v, (list, tuple)):
        parts = []
        for it in v:
            if isinstance(it, (list, tuple)):
                parts.append('%d:%d' % tuple(it))
            else:
                parts.append(str(it))
        return ','.join(parts)
    return str(v)


class ScnWriter:
    """Builds the text of a scenario file."""

    def __init__(self, name='', doc=''):
        self.lines = []
        if name:
            self.comment('scenario: %s' % name)
        for d in (doc.strip().splitlines() if doc else []):
            self.comment(d)

    def comment(self, text=''):
        self.lines.append('# ' + text if text else '#')

    def blank(self):
        self.lines.append('')

    def cmd(self, name, **kv):
        parts = [name]
        for k, v in kv.items():
            if v is None:
                continue
            parts.append('%s=%s' % (k, _fmt(k, v)))
        self.lines.append(' '.join(parts))

    def text(self):
        return '\n'.join(self.lines) + '\n'

    def write(self, path):
        with open(path, 'w') as f:
            f.write(self.text())


# ---------------------------------------------------------------------------
# Result file (A.2)
# ---------------------------------------------------------------------------
def _norm_code(val, table):
    """value is a number or a symbolic name; return int code (or None if unknown)."""
    if isinstance(val, int):
        return val
    if isinstance(val, str):
        v = val.upper()
        if v in table:
            return table[v]
        if v.startswith('POST_') is False and ('POST_' + v) in table:
            return table['POST_' + v]
        if is_num(val):
            return parse_num(val)
    return None


class Result:
    def __init__(self):
        self.cfgs = []      # dicts: ep, cmd, status(int), line, raw
        self.posts = []     # ep, wr_id, which, status
        self.cqes = []      # ep, cyc, wr_id, op(int), status(int), len, qpn
        self.memw = []      # ep, cyc, addr, strb, data
        self.memr = []      # ep, cyc, addr
        self.cnts = {}      # ep -> {name: value} (last value wins)
        self.cnt_lines = [] # (ep, name, value)
        self.qpst = []      # ep, state, cause
        self.dumps = []     # ep, addr, hex
        self.end = None     # dict cycles, timeout, monitor_errors
        self.bench_notes = []   # 'NOTE cyc=.. text' lines of the bench (e.g. barrier timed out)
        self.mons = []          # 'MON cyc=.. text' lines of the bench monitors (protocol/liveness monitors)
        self.unknown = []   # unparsed lines
        self.errors = []    # parse problems (strings)


def _tokens(line):
    line = line.split('#', 1)[0].strip()
    toks = line.split()
    if not toks:
        return None, {}
    kv = {}
    for t in toks[1:]:
        if '=' in t:
            k, v = t.split('=', 1)
            kv[k.lower()] = v
    return toks[0].upper(), kv


def _num_or_str(v):
    if v is not None and is_num(v):
        return parse_num(v)
    return v


def _state_code(v):
    if v is None:
        return None
    u = str(v).upper()
    if u in QP_STATES:
        return u
    if is_num(str(v)):
        n = parse_num(str(v))
        if 0 <= n < len(QP_STATES):
            return QP_STATES[n]
    return u


def parse_res_text(text):
    r = Result()
    for lineno, raw in enumerate(text.splitlines(), 1):
        kind, kv = _tokens(raw)
        if kind is None:
            continue
        try:
            ep = kv.get('ep', '').upper()
            if kind == 'CFG':
                r.cfgs.append({'ep': ep, 'cmd': kv.get('cmd', ''), 'status': _norm_code(_num_or_str(kv.get('status')), CFG_STATUS),
                               'line': lineno, 'raw': raw.strip(), 'kv': kv})
            elif kind == 'POST':
                r.posts.append({'ep': ep, 'wr_id': _num_or_str(kv.get('wr_id')), 'which': kv.get('which', '').upper(),
                                'status': _norm_code(_num_or_str(kv.get('status')), POST_STATUS), 'line': lineno})
            elif kind == 'CQE':
                r.cqes.append({'ep': ep, 'cyc': _num_or_str(kv.get('cyc')), 'wr_id': _num_or_str(kv.get('wr_id')),
                               'op': _norm_code(_num_or_str(kv.get('op')), CQE_OP),
                               'status': _norm_code(_num_or_str(kv.get('status')), CQE_STATUS),
                               'len': _num_or_str(kv.get('len', kv.get('byte_len'))), 'qpn': _num_or_str(kv.get('qpn')),
                               'line': lineno})
            elif kind == 'MEMW':
                r.memw.append({'ep': ep, 'cyc': _num_or_str(kv.get('cyc')), 'addr': parse_num(kv['addr']),
                               'strb': parse_num(kv['strb']), 'data': parse_num(kv['data']), 'line': lineno,
                               'ack': _num_or_str(kv['ack']) if 'ack' in kv else None})
            elif kind == 'MEMR':
                r.memr.append({'ep': ep, 'cyc': _num_or_str(kv.get('cyc')), 'addr': parse_num(kv['addr']), 'line': lineno})
            elif kind == 'CNT':
                name = kv['name']
                val = parse_num(kv['value'])
                r.cnts.setdefault(ep, {})[name] = val
                r.cnt_lines.append((ep, name, val))
            elif kind == 'QPST':
                r.qpst.append({'ep': ep, 'state': _state_code(kv.get('state')), 'cause': kv.get('cause'), 'line': lineno})
            elif kind == 'DUMP':
                h = kv.get('hex', '')
                if h[:2] in ('0x', '0X'):
                    h = h[2:]
                r.dumps.append({'ep': ep, 'addr': parse_num(kv['addr']), 'hex': h.lower(), 'line': lineno})
            elif kind == 'END':
                r.end = {'cycles': _num_or_str(kv.get('cycles')), 'timeout': _num_or_str(kv.get('timeout')),
                         'monitor_errors': _num_or_str(kv.get('monitor_errors', '0')), 'line': lineno}
            elif kind == 'NOTE':
                r.bench_notes.append(raw.split('#', 1)[0].strip())
            elif kind == 'MON':
                r.mons.append(raw.split('#', 1)[0].strip())
            elif kind == 'FINAL':       # the bench's own end-of-run invariants (CQ credits); a violation is reported by the bench as MON
                pass
            else:
                r.unknown.append(raw.strip())
        except (KeyError, ValueError) as e:
            r.errors.append('result line %d: cannot parse %r (%s: %s)' % (lineno, raw.strip(), type(e).__name__, e))
    return r


def parse_res(path):
    with open(path, 'r') as f:
        return parse_res_text(f.read())


if __name__ == '__main__':
    import sys
    for p in sys.argv[1:]:
        if p.endswith('.scn'):
            print(p, len(parse_scn(p)), 'commands')
        else:
            rr = parse_res(p)
            print(p, len(rr.cqes), 'CQEs', len(rr.memw), 'MEMW', len(rr.errors), 'errors')
