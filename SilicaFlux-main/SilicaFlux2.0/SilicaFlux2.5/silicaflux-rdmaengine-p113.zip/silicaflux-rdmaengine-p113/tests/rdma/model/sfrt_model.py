#!/usr/bin/env python3
"""sfrt_model.py - independent, idealised *functional* reference model of SFRT v1 (Project 113).

Written ONLY from docs/TRANSPORT_SPEC.md (no RTL was read).  The model does not model cycles of the
design; it executes a parsed scenario (scn.py) command by command and produces an `Expectation`:
    per endpoint: SQ / RQ CQE sequences, post statuses, cfg statuses, dump contents, per-byte write
    counts, legal-access envelope, registry fault counters, final QP state, exact counters and
    bounds on counters (reliability counters).

Time:  the model keeps a coarse notion of time (`now`, in cycles) driven by run/barrier/wait_cqe/idle,
and rough estimates of how long a transfer takes.  It is used for exactly two things:
  (a) deciding the outcome of *stuck* operations (black-holed link, RNR with no receive buffer, silent
      peer): a retry timeline (spec 9.6) is evaluated against the link_black timeline / RQE post times;
  (b) a determinism *lint*: the model emits `warnings` when the scenario depends on cycle-exact timing
      (e.g. a QP reset while a non-stuck operation is in flight, conflicting memory accesses within one
      batch, a link_black edge within 150 cycles of a retry attempt).  Generators must produce
      scenarios with no warnings.
"""
import json
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import frames as F                      # noqa: E402
from scn import (pat, CQE_STATUS, CQE_OP, FAULT_CLASSES, parse_scn, POST_STATUS, CFG_STATUS)  # noqa: E402

M24 = 0xFFFFFF
TWO64 = 1 << 64

# ---------------------------------------------------------------------------
# PSN arithmetic (spec 0)
# ---------------------------------------------------------------------------


def psn_dist(a, b):
    return (b - a) & M24


def psn_before(a, b):
    return 1 <= psn_dist(a, b) <= (1 << 23) - 1


def psn_before_eq(a, b):
    return a == b or psn_before(a, b)


def psn_add(a, n):
    return (a + n) & M24


def ack_valid(una, cn, an, nxt):
    """spec 9.5: an ACK/NAK with (commit_next, accept_next) is valid iff
    dist(una,cn) <= dist(una,an) <= dist(una,nxt)."""
    return psn_dist(una, cn) <= psn_dist(una, an) <= psn_dist(una, nxt)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
OP_SEND, OP_WRITE, OP_READ = 1, 2, 3
OP_NAMES = {1: 'SEND', 2: 'WRITE', 3: 'READ'}
LOCAL_READ, LOCAL_WRITE, REMOTE_READ, REMOTE_WRITE = 0, 1, 2, 3
ST_OK = CQE_STATUS['OK']
ST_FLUSH = CQE_STATUS['WR_FLUSH_ERR']
NAK_STATUS = {F.NAK_INV_REQ: CQE_STATUS['REM_INV_REQ_ERR'], F.NAK_REM_ACCESS: CQE_STATUS['REM_ACCESS_ERR'],
              F.NAK_REM_OP: CQE_STATUS['REM_OP_ERR']}

# coarse timing constants (cycles) - only used for stuck-operation timelines and the lint
T_TX = 30        # launch -> first frame on the wire
T_FWD = 40       # forward latency of the link + adapter
T_REV = 40       # reverse latency
T_ISSUE = 25
T_RNR_RTT = 100  # extra per RNR round trip on top of rnr_delay
RQE_LAG = 20     # an RQE posted at t is visible to the responder from t+RQE_LAG
LINT_MARGIN = 150
BACKOFF_MAX = 3


class ModelError(Exception):
    pass


class Params:
    def __init__(self):
        self.dw = 64
        self.mtu = 256
        self.window = 8
        self.max_rd = 2
        self.nmr = 8
        self.max_msg = 1 << 20
        self.pd_w = 4
        self.ctx_w = 2
        self.pa_w = 32
        self.page = 4096
        self.sq_depth = 8
        self.backoff_max = BACKOFF_MAX

    def apply_build(self, c):
        m = {'dw': 'dw', 'mtu': 'mtu', 'window': 'window', 'max_rd': 'max_rd', 'nmr': 'nmr', 'max_msg': 'max_msg',
             'max_msg_bytes': 'max_msg', 'pd_w': 'pd_w', 'ctx_w': 'ctx_w', 'pa_w': 'pa_w', 'page': 'page',
             'page_bytes': 'page', 'sq_depth': 'sq_depth', 'backoff_max': 'backoff_max'}
        for k, v in c.items():
            if k in m and isinstance(v, int):
                setattr(self, m[k], v)

    @property
    def wbytes(self):
        return self.dw // 8

    def to_dict(self):
        return {k: getattr(self, k) for k in ('dw', 'mtu', 'window', 'max_rd', 'nmr', 'max_msg', 'pd_w', 'ctx_w',
                                              'pa_w', 'page', 'sq_depth', 'backoff_max')}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def merge_ranges(rs):
    out = []
    for lo, hi in sorted(rs):
        if hi <= lo:
            continue
        if out and lo <= out[-1][1]:
            if hi > out[-1][1]:
                out[-1][1] = hi
        else:
            out.append([lo, hi])
    return [tuple(x) for x in out]


def nseg_for(length, mtu):
    """segments (= PSNs) of a SEND/WRITE message of `length` bytes: max(1, ceil(L/MTU))."""
    return max(1, -(-length // mtu))


def segments(length, mtu):
    """[(moff, paylen)] of a message (spec 7)."""
    n = nseg_for(length, mtu)
    return [(i * mtu, min(mtu, length - i * mtu)) for i in range(n)]


# ---------------------------------------------------------------------------
# Memory
# ---------------------------------------------------------------------------
class Mem:
    """sparse byte memory (PA -> byte); unwritten bytes read as 0 and are flagged 'unknown' for dumps."""

    def __init__(self):
        self.b = {}

    def fill(self, addr, ln, seed):
        for i in range(ln):
            self.b[addr + i] = pat(seed, i)

    def read(self, addr, ln):
        g = self.b.get
        return bytes(g(addr + i, 0) for i in range(ln))

    def write(self, addr, data):
        for i, v in enumerate(data):
            self.b[addr + i] = v

    def known(self, addr, ln):
        return all((addr + i) in self.b for i in range(ln))


# ---------------------------------------------------------------------------
# Memory registry (spec 8)
# ---------------------------------------------------------------------------
class MR:
    __slots__ = ('valid', 'key', 'va_base', 'len', 'pa_base', 'pd', 'acc', 'ctx', 'refcnt')

    def __init__(self):
        self.valid = False
        self.key = self.va_base = self.len = self.pa_base = self.pd = self.acc = self.ctx = 0
        self.refcnt = 0


class Grant:
    def __init__(self, idx, pa, ctx):
        self.idx, self.pa, self.ctx = idx, pa, ctx


class Registry:
    CFG_OK, ERR_IDX, ERR_BUSY, ERR_EXISTS, ERR_DUPKEY, ERR_FIELDS, ERR_RANGE, ERR_NOENT = 0, 1, 2, 3, 4, 5, 6, 7

    def __init__(self, P):
        self.P = P
        self.mrs = [MR() for _ in range(P.nmr)]
        self.ctx_en = 1
        self.faults = Counter()
        self.fault_total = 0
        self.fault_log = None

    # -- configuration commands (8.2) --
    def mr_set(self, idx, va, ln, pa, key, pd, acc, ctx):
        P = self.P
        if not (0 <= idx < P.nmr):
            return self.ERR_IDX
        e = self.mrs[idx]
        if e.valid:
            return self.ERR_EXISTS
        # pd / ctx / acc are PD_W / CTX_W / 8 bit wide port fields: out-of-width values cannot be presented (the bench
        # truncates them), so they are not statuses (spec 8.2).
        pd &= (1 << P.pd_w) - 1
        ctx &= (1 << P.ctx_w) - 1
        acc &= 0xFF
        if ln == 0 or (acc & 0xE0):
            return self.ERR_FIELDS
        if va + ln > TWO64 or pa + ln > (1 << P.pa_w):
            return self.ERR_RANGE
        for o in self.mrs:
            if o.valid and o.key == key:
                return self.ERR_DUPKEY
        e.valid, e.key, e.va_base, e.len, e.pa_base, e.pd, e.acc, e.ctx, e.refcnt = True, key, va, ln, pa, pd, acc, ctx, 0
        return self.CFG_OK

    def mr_inval(self, idx):
        if not (0 <= idx < self.P.nmr):
            return self.ERR_IDX
        e = self.mrs[idx]
        if not e.valid:
            return self.ERR_NOENT
        if e.refcnt != 0:
            return self.ERR_BUSY
        e.valid = False
        return self.CFG_OK

    def ctx_set(self, mask):
        self.ctx_en = mask

    # -- the check function (8.3) --
    def evaluate(self, op, key, pd, va, length):
        """pure: returns ('grant', Grant) or ('fault', name).  Normative order, first match wins."""
        P = self.P
        if op not in (0, 1, 2, 3):
            return ('fault', 'bad_op')
        ent, ei = None, None
        for i, e in enumerate(self.mrs):
            if e.valid and e.key == key:
                ent, ei = e, i
                break
        if ent is None:
            return ('fault', 'bad_key')
        if ent.pd != pd:
            return ('fault', 'bad_pd')
        rights = (ent.acc & 0x3) if op in (LOCAL_READ, LOCAL_WRITE) else ((ent.acc >> 2) & 0x3)
        if rights == 0:
            return ('fault', 'bad_dir')
        if not (ent.acc >> op) & 1:
            return ('fault', 'bad_perm')
        if length == 0 or length > P.max_msg:
            return ('fault', 'bad_len')
        if va + length > TWO64:
            return ('fault', 'overflow')
        if not (ent.va_base <= va and va + length <= ent.va_base + ent.len):
            return ('fault', 'range')
        if not (ent.acc & 0x10) and (va // P.page) != ((va + length - 1) // P.page):
            return ('fault', 'page_cross')
        if not (self.ctx_en >> ent.ctx) & 1:
            return ('fault', 'xlate')
        return ('grant', Grant(ei, ent.pa_base + (va - ent.va_base), ent.ctx))

    def check(self, op, key, pd, va, length):
        """check + side effects: refcnt++ on grant, per-class fault counter on fault.  Returns Grant or fault name."""
        kind, r = self.evaluate(op, key, pd, va, length)
        if kind == 'fault':
            self.faults[r] += 1
            self.fault_total += 1
            self.fault_log = (op, key, va, length, r)
            return r
        self.mrs[r.idx].refcnt += 1
        return r

    def release(self, grant_or_idx):
        idx = grant_or_idx.idx if isinstance(grant_or_idx, Grant) else grant_or_idx
        if self.mrs[idx].refcnt > 0:
            self.mrs[idx].refcnt -= 1

    def clear_refs(self):
        for e in self.mrs:
            e.refcnt = 0


# ---------------------------------------------------------------------------
# Work requests / endpoint
# ---------------------------------------------------------------------------
class Wqe:
    def __init__(self, line, wr_id, kind, laddr, lkey, ln, raddr, rkey, tp, mtu):
        self.line, self.wr_id, self.kind = line, wr_id, kind
        self.laddr, self.lkey, self.len, self.raddr, self.rkey = laddr, lkey, ln, raddr, rkey
        self.tp = tp
        self.npsn = nseg_for(ln, mtu) if kind in (OP_SEND, OP_WRITE) else 1
        self.psn0 = None
        self.phase = 'new'
        self.issued = False
        self.local_fault = None
        self.grant = None
        self.local_pa = None
        self.seg_done = 0
        self.rstate = 'none'          # none | done   (responder side effects complete)
        self.rdata = None
        self.rq_grant = None
        self.rq_pa = None
        self.rqe = None
        self.seq = 0
        self.attempts = 0
        self.launch = None
        self.next_a = None
        self.k = 0
        self.r = 0
        self.cause = None
        self.result = None


class Rqe:
    def __init__(self, line, wr_id, addr, lkey, ln, tpost):
        self.line, self.wr_id, self.addr, self.lkey, self.len, self.tpost = line, wr_id, addr, lkey, ln, tpost


class Ep:
    def __init__(self, name, P):
        self.name, self.P = name, P
        self.mem = Mem()
        self.wc = Counter()                 # per-byte write count (never reset: memory outlives the endpoint)
        self.read_env, self.write_env = [], []
        self.write_log = []                  # (lo, hi, scenario line, what) provenance of every placement
        self.sq_cqes, self.rq_cqes = [], []
        self.posts, self.cfgs = [], []
        self.hard_reset()

    def hard_reset(self):
        self.reg = Registry(self.P)
        self.cnt = Counter()
        self.lo_only = Counter()            # counters known only as lower bounds
        self.rt_timeout = 0                 # modelled retransmission timeouts
        self.rt_rnr = 0
        self.rt_nak = 0
        self.rnr_success = False
        self.forced_extra_retry = 0
        self.soft_retry_lo = 0
        self.wbytes_since_reset = 0         # dma_wr_bytes is cleared by a hard reset
        self.lo_group = 0                   # drops in RESET/INIT after a QP reset (counter class not determined by the spec)
        self.attr_cleared = True            # rst_n clears the QP attributes incl. the MAC registers (spec A.5)
        self.lenient = []                   # source buffers of posted WQEs that passed (or would pass) the local check
        self.n_sends = 0
        self.exh_timer = 0
        self.exh_rnr = 0
        self.rnr_resolved = 0               # SENDs that were RNR-NAKed and later completed OK (=> retransmitted after rnr_delay)
        self.rnr_retry_seen = 0
        self.retry_seen = 0
        self.clear_qp()
        self.state = 'RESET'
        self.err_cause = None
        self.err_nak = None
        self.err_t = None

    def clear_qp(self):
        self.state = 'RESET'
        self.qpn = self.pd = self.rqpn = self.epoch = self.rq_psn = self.smac = self.dmac = None
        self.sq_psn = self.timeout = self.retry = self.rnr_retry = self.rnr_delay = None
        self.nxt = self.epsn = self.cpsn = 0
        self.err_nak = None
        self.err_t = None
        self.sq = []
        self.rq = []
        self.flow_clock = 0
        self.oos_nak_sent = False

    def note_write(self, pa, ln, line=0, what='', info=None):
        """info = {'mem','kind','req','sq','rq'}: which WQE (scenario line of its post_send / of the consumed post_recv)
        placed this range -- used by the checker's 'completion only after commit' rule."""
        for i in range(ln):
            self.wc[pa + i] += 1
        self.wbytes_since_reset += ln
        self.write_env.append((pa, pa + ln))
        self.write_log.append((pa, pa + ln, line, what, info or {}))


# ---------------------------------------------------------------------------
# Expectation
# ---------------------------------------------------------------------------
class EpExp:
    def __init__(self, name):
        self.name = name
        self.qpn = None
        self.sq_cqes = []
        self.rq_cqes = []
        self.posts = []
        self.cfgs = []
        self.dumps = []
        self.write_counts = {}
        self.final_bytes = {}
        self.read_env = []
        self.write_env = []
        self.write_log = []       # (lo, hi, line, what): which scenario line placed which PA range
        self.faults = {}
        self.counters = {}        # exact, hard
        self.soft_counters = {}   # exact, soft (RTL-specific semantics)
        self.bounds = []          # {'name' or 'terms', 'lo', 'hi', 'soft', 'why'}
        self.qp_state = 'RESET'
        self.qp_cause = None
        self.info = {}

    def to_dict(self):
        d = dict(self.__dict__)
        d['write_counts'] = {str(k): v for k, v in self.write_counts.items()}
        d['final_bytes'] = {str(k): v for k, v in self.final_bytes.items()}
        return d


class Expectation:
    def __init__(self):
        self.ep = {'A': EpExp('A'), 'B': EpExp('B')}
        self.warnings = []     # (line, message): scenario is timing dependent / not deterministic
        self.notes = []
        self.expect_timeout = False
        self.params = {}
        self.name = ''

    def to_dict(self):
        return {'name': self.name, 'params': self.params, 'warnings': self.warnings, 'notes': self.notes,
                'expect_timeout': self.expect_timeout, 'ep': {k: v.to_dict() for k, v in self.ep.items()}}

    def to_json(self, **kw):
        return json.dumps(self.to_dict(), **kw)


# ---------------------------------------------------------------------------
# The model
# ---------------------------------------------------------------------------
class Model:
    def __init__(self, cmds, name=''):
        self.cmds = cmds
        self.name = name
        self.P = Params()
        for c in cmds:
            if c['cmd'] == 'build':
                self.P.apply_build(c)
        self.A = Ep('A', self.P)
        self.B = Ep('B', self.P)
        self.now = 0
        self.max_done_t = 0
        self.warnings = []
        self.notes = []
        self.expect_timeout = False
        self.black = {'AB': [], 'BA': []}          # [[on, off|None], ...]
        self.link_imp = {'AB': {}, 'BA': {}}       # random impairments (last `link` command)
        self.link_script = {'AB': None, 'BA': None}
        self.impaired = False
        self.had_err = False
        self.had_retry = False
        self.had_reset = False
        self.dump_snaps = []
        self.script_forced = {'A': 0, 'B': 0}
        self.dumps = []
        self.cq_drain = {'A': True, 'B': True}
        self.cur_line = 0
        self.started = {'AB': False, 'BA': False}
        self.sq_posted = {'A': 0, 'B': 0}
        self.psn_posted = {'A': 0, 'B': 0}
        self.seq = {'A': 0, 'B': 0}
        self.batch_acc = []                      # access records since the last barrier (determinism lint)
        self.mem_lat = {'A': (0, 0, 0), 'B': (0, 0, 0)}

    # ---- plumbing ------------------------------------------------------
    def ep(self, name):
        if name == 'A':
            return self.A
        if name == 'B':
            return self.B
        raise ModelError('bad ep %r' % (name,))

    def peer(self, E):
        return self.B if E is self.A else self.A

    def warn(self, msg):
        self.warnings.append((self.cur_line, msg))

    # ---- CQE production -----------------------------------------------
    def cqe(self, E, which, wr_id, op, status, ln, t, line):
        rec = {'wr_id': wr_id, 'op': op, 'status': status, 'len': ln, 'line': line, 't': int(t), 'qpn': E.qpn}
        (E.sq_cqes if which == 'SQ' else E.rq_cqes).append(rec)
        opn = {1: 'send', 2: 'write', 3: 'read', 4: 'recv'}[op]
        if status == ST_OK:
            E.cnt['ops_done_' + opn] += 1
            E.cnt['bytes_' + opn] += ln
        elif status == ST_FLUSH:
            E.cnt['ops_flushed' if which == 'SQ' else 'rq_ops_flushed'] += 1
        else:
            E.cnt['ops_err' if which == 'SQ' else 'rq_ops_err'] += 1
        self.max_done_t = max(self.max_done_t, int(t))

    # ---- error / reset -------------------------------------------------
    def enter_err(self, E, cause, t):
        """spec 11.1: flush everything not completed, in queue order."""
        if E.state == 'ERR':
            return
        E.state = 'ERR'
        E.err_cause = cause
        self.had_err = True
        for op in E.sq:
            if not op.issued:
                self.lenient_read(E, op)
            self.release_op(E, op)
            self.cqe(E, 'SQ', op.wr_id, op.kind, ST_FLUSH, 0, t, op.line)
        E.sq = []
        for rqe in E.rq:
            self.cqe(E, 'RQ', rqe.wr_id, 4, ST_FLUSH, 0, t, rqe.line)
        E.rq = []

    def lenient_read(self, E, op):
        """spec A.5: the source buffer of any posted WQE whose local check passes may legitimately have been read
        (pipelining), even if the WQE is later flushed.  Pure evaluation: no counters, no references."""
        if op.kind not in (OP_SEND, OP_WRITE) or op.len == 0 or E.pd is None:
            return
        kind, r = E.reg.evaluate(LOCAL_READ, op.lkey, E.pd, op.laddr, op.len)
        if kind == 'grant':
            E.lenient.append((r.pa, r.pa + op.len))

    def note_vanishing(self, E):
        for op in E.sq:
            self.lenient_read(E, op)

    def release_op(self, E, op):
        if op.grant is not None:
            E.reg.release(op.grant)
            op.grant = None
        if op.rq_grant is not None:
            E.reg.release(op.rq_grant)
            op.rq_grant = None

    def reset_qp(self, E, t):
        if E.state != 'RESET':
            self.had_reset = True
        if E.state in ('INIT', 'RTR', 'RTS'):
            self.enter_err(E, 'CFG_FORCED', t)
        E.reg.clear_refs()
        E.clear_qp()
        E.flow_clock = t

    # ---- link timeline -------------------------------------------------
    def is_black(self, d, t):
        for on, off in self.black[d]:
            if on <= t and (off is None or t < off):
                return True
        return False

    def black_ambiguous(self, d, t, t0):
        """does the black state of direction d change within LINT_MARGIN of t (not looking before t0, the launch)?"""
        s = self.is_black(d, t)
        return self.is_black(d, max(t0, t - LINT_MARGIN)) != s or self.is_black(d, t + LINT_MARGIN) != s

    # ---- local (requester) issue --------------------------------------
    def issue_op(self, X, op):
        if op.issued:
            return
        op.issued = True
        self.started[X.name + self.peer(X).name] = True
        if op.kind == OP_SEND and op.len == 0:
            return
        need = LOCAL_WRITE if op.kind == OP_READ else LOCAL_READ
        r = X.reg.check(need, op.lkey, X.pd, op.laddr, op.len)
        if isinstance(r, str):
            op.local_fault = r
            return
        op.grant = r
        op.local_pa = r.pa
        if op.kind == OP_READ:
            X.write_env.append((r.pa, r.pa + op.len))
            self.acc(X.name, 'w', r.pa, r.pa + op.len, op, 'loc', 'READ_DST')
        else:
            X.read_env.append((r.pa, r.pa + op.len))
            self.acc(X.name, 'r', r.pa, r.pa + op.len, op, 'loc', 'LOC_SRC')

    # ---- responder execution ------------------------------------------
    def acc(self, mem_ep, rw, lo, hi, op, role, what):
        """log a memory access for the determinism lint.  role: 'resp' (done by the peer's flow as responder)
        or 'loc' (done by the endpoint's own requester)."""
        self.batch_acc.append({'ep': mem_ep, 'rw': rw, 'lo': lo, 'hi': hi, 'line': op.line, 'role': role,
                               'flow': (mem_ep if role == 'loc' else ('B' if mem_ep == 'A' else 'A')),
                               'seq': op.seq, 'what': what})

    def psn_check(self, X, Y, op, i):
        want = psn_add(op.psn0, i)
        if Y.epsn != want:
            raise ModelError('PSN mismatch between requester %s (psn %06X) and responder %s (epsn %06X): '
                             'scenario configures inconsistent sq_psn/rq_psn' % (X.name, want, Y.name, Y.epsn))

    def responder_fatal(self, Y, code, psn, t):
        Y.err_nak = (code, psn)
        Y.err_t = t
        self.enter_err(Y, 'REQ_ERR_%d' % code, t)

    def exec_op(self, X, Y, op, upto, ta):
        """Execute, at responder Y, the segments of `op` up to `upto` (PSN slots).  Returns 'ok'|'rnr'|'fatal'."""
        mtu = self.P.mtu
        if op.rstate == 'done':
            return 'ok'
        if op.kind == OP_WRITE:
            while op.seg_done < min(upto, op.npsn):
                i = op.seg_done
                moff, pl = i * mtu, min(mtu, op.len - i * mtu)
                self.psn_check(X, Y, op, i)
                g = Y.reg.check(REMOTE_WRITE, op.rkey, Y.pd, op.raddr + moff, pl)
                if isinstance(g, str):
                    self.responder_fatal(Y, F.NAK_REM_ACCESS, psn_add(op.psn0, i), ta)
                    return 'fatal'
                Y.mem.write(g.pa, X.mem.read(op.local_pa + moff, pl))
                Y.note_write(g.pa, pl, op.line, 'WRITE wr_id=%d' % op.wr_id,
                             {'mem': Y.name, 'kind': 'WRITE', 'req': X.name, 'sq': op.line, 'rq': None})
                self.acc(Y.name, 'w', g.pa, g.pa + pl, op, 'resp', 'WRITE')
                Y.reg.release(g)
                op.seg_done += 1
                Y.epsn = Y.cpsn = psn_add(Y.epsn, 1)
            if op.seg_done >= op.npsn:
                op.rstate = 'done'
            return 'ok'
        if op.kind == OP_SEND:
            while op.seg_done < min(upto, op.npsn):
                i = op.seg_done
                self.psn_check(X, Y, op, i)
                if i == 0:
                    if not Y.rq or Y.rq[0].tpost + RQE_LAG > ta:
                        if Y.rq and abs(Y.rq[0].tpost + RQE_LAG - ta) < LINT_MARGIN:
                            self.warn('RNR race: RQE posted within %d cycles of the SEND arrival' % LINT_MARGIN)
                        return 'rnr'
                    if abs(Y.rq[0].tpost + RQE_LAG - ta) < LINT_MARGIN and Y.rq[0].tpost > op.tp:
                        self.warn('RNR race: RQE posted within %d cycles of the SEND arrival' % LINT_MARGIN)
                    rqe = Y.rq.pop(0)
                    op.rqe = rqe
                    if op.len > rqe.len:
                        self.cqe(Y, 'RQ', rqe.wr_id, 4, CQE_STATUS['LOC_LEN_ERR'], 0, ta, rqe.line)
                        self.responder_fatal(Y, F.NAK_REM_OP, psn_add(op.psn0, i), ta)
                        return 'fatal'
                    op.rq_grant = None
                    op.rq_pa = None
                    if rqe.len > 0:
                        g = Y.reg.check(LOCAL_WRITE, rqe.lkey, Y.pd, rqe.addr, rqe.len)
                        if isinstance(g, str):
                            self.cqe(Y, 'RQ', rqe.wr_id, 4, CQE_STATUS['LOC_PROT_ERR'], 0, ta, rqe.line)
                            self.responder_fatal(Y, F.NAK_REM_OP, psn_add(op.psn0, i), ta)
                            return 'fatal'
                        op.rq_grant = g
                        op.rq_pa = g.pa
                moff, pl = i * mtu, min(mtu, op.len - i * mtu)
                if pl > 0:
                    pa = op.rq_pa + moff
                    Y.mem.write(pa, X.mem.read(op.local_pa + moff, pl))
                    Y.note_write(pa, pl, op.line, 'SEND wr_id=%d' % op.wr_id,
                                 {'mem': Y.name, 'kind': 'SEND', 'req': X.name, 'sq': op.line, 'rq': op.rqe.line})
                    self.acc(Y.name, 'w', pa, pa + pl, op, 'resp', 'SEND')
                op.seg_done += 1
                Y.epsn = Y.cpsn = psn_add(Y.epsn, 1)
                if op.seg_done == op.npsn:
                    self.cqe(Y, 'RQ', op.rqe.wr_id, 4, ST_OK, op.len, ta, op.rqe.line)
                    if op.rq_grant is not None:
                        Y.reg.release(op.rq_grant)
                        op.rq_grant = None
            if op.seg_done >= op.npsn:
                op.rstate = 'done'
            return 'ok'
        # READ
        self.psn_check(X, Y, op, 0)
        g = Y.reg.check(REMOTE_READ, op.rkey, Y.pd, op.raddr, op.len)
        if isinstance(g, str):
            self.responder_fatal(Y, F.NAK_REM_ACCESS, op.psn0, ta)
            return 'fatal'
        op.rdata = Y.mem.read(g.pa, op.len)
        Y.read_env.append((g.pa, g.pa + op.len))
        self.acc(Y.name, 'r', g.pa, g.pa + op.len, op, 'resp', 'READ_SRC')
        Y.reg.release(g)
        op.seg_done = 1
        op.rstate = 'done'
        Y.epsn = Y.cpsn = psn_add(Y.epsn, 1)
        return 'ok'

    def exec_prefix(self, X, Y, ta):
        """Frames that leave the requester while NO acknowledgement ever returns: only the first WINDOW
        PSNs (and at most MAX_RD reads) are transmitted; the responder executes them once, in order."""
        budget = self.P.window
        reads = 0
        for op in list(X.sq):
            if Y.state == 'ERR' or budget <= 0:
                break
            if op.kind == OP_READ and reads >= self.P.max_rd:
                break
            take = min(op.npsn, budget)
            self.issue_op(X, op)
            if op.local_fault:
                break
            res = self.exec_op(X, Y, op, take, ta)
            if res != 'ok':
                break
            budget -= take
            if take < op.npsn:
                break
            if op.kind == OP_READ:
                reads += 1

    # ---- one transmission attempt of the head op -----------------------
    def cfg_drop_req(self, X, Y):
        """adapter-level verdict for a request frame from X at Y (None = passes)."""
        if None in (X.smac, X.dmac, X.rqpn, X.epoch, Y.smac, Y.dmac, Y.qpn, Y.epoch):
            return None
        fr = F.build_frame(X.dmac, X.smac, F.OP_SEND, X.rqpn, X.epoch, 0, flags=3)
        return F.adapter_check(fr, Y.smac, Y.dmac, Y.qpn, Y.epoch, self.P.mtu)[0]

    def cfg_drop_resp(self, Y, X):
        """adapter verdict for an ACK/NAK from responder Y at requester X."""
        if None in (X.smac, X.dmac, X.rqpn, X.epoch, Y.smac, Y.dmac, Y.rqpn, Y.epoch, X.qpn):
            return None
        fr = F.build_frame(Y.dmac, Y.smac, F.OP_ACK, Y.rqpn, Y.epoch, 0)
        return F.adapter_check(fr, X.smac, X.dmac, X.qpn, X.epoch, self.P.mtu)[0]

    def attempt(self, X, Y, op, a):
        dirf, dirr = X.name + Y.name, Y.name + X.name
        ta = a + T_FWD
        tf, tr = a + 20, a + 20 + T_FWD
        for d, t in ((dirf, tf), (dirr, tr)):
            if self.black_ambiguous(d, t, op.launch):
                self.warn('link_black edge on %s within %d cycles of a retry attempt (t~%d): timing dependent'
                          % (d, LINT_MARGIN, t))
        if self.is_black(dirf, tf):
            return ('lost',)
        if Y.state in ('RESET', 'INIT'):
            if Y.attr_cleared:
                Y.lo_only['rx_drop_mac'] += 1          # MAC registers are zero until RTR (spec 3.4 order, A.5)
            else:
                Y.lo_group += 1                         # state / mac / qpn / epoch: not determined by the spec
            return ('lost',)
        why = self.cfg_drop_req(X, Y)
        if why:
            Y.lo_only[why] += 1
            return ('lost',)
        rev_ok = not self.is_black(dirr, tr)
        why_r = self.cfg_drop_resp(Y, X)
        if why_r:
            X.lo_only[why_r] += 1
            rev_ok = False
        if Y.state == 'ERR':
            if Y.err_nak is None:
                Y.lo_only['rx_drop_state'] += 1
                return ('lost',)
            return self.nak_outcome(X, Y, op) if rev_ok else ('lost',)
        # responder accepts requests (RTR / RTS)
        if rev_ok:
            res = self.exec_op(X, Y, op, op.npsn, ta) if self.issue_ok(X, op) else 'blocked'
            if res == 'rnr':
                return ('rnr',)
            if Y.state == 'ERR' and Y.err_nak is not None:
                return self.nak_outcome(X, Y, op)
            if res == 'ok':
                return ('ok',)
            return ('lost',)
        self.exec_prefix(X, Y, ta)
        return ('lost',)

    def issue_ok(self, X, op):
        self.issue_op(X, op)
        return not op.local_fault

    def nak_outcome(self, X, Y, op):
        code, perr = Y.err_nak
        una = op.psn0
        if not psn_dist(una, perr) <= psn_dist(una, X.nxt):
            X.lo_only['rx_ack_stale'] += 1
            return ('lost',)
        d = psn_dist(una, perr)
        if d < op.npsn:
            return ('fatal', code, perr)
        return ('ok',) if op.rstate == 'done' else ('lost',)

    # ---- advance the requester flow ------------------------------------
    def xfer_time(self, op):
        wb = self.P.wbytes
        segs = segments(op.len, self.P.mtu) if op.kind != OP_READ else segments(op.len, self.P.mtu)
        cyc = sum(-(-(48 + pl) // wb) for _, pl in segs)
        extra = (len(segs) // max(1, self.P.window)) * 100
        return int(1.5 * cyc + 40 + extra)

    def step_op(self, X, Y, op, te):
        """advance the head op as far as time te allows.  Returns 'pending' | 'done' | 'failed'."""
        if op.launch is None:
            op.launch = max(op.tp, X.flow_clock)
        if op.phase == 'new':
            self.issue_op(X, op)
            op.phase = 'sent'
            if op.local_fault:
                op.result = ('local_fault', op.launch + T_ISSUE)
            else:
                op.next_a = op.launch + T_TX
        while True:
            if op.result is not None:
                if op.result[1] > te:
                    return 'pending'
                return self.finalize(X, Y, op)
            a = op.next_a
            if a > te:
                return 'pending'
            op.attempts += 1
            if op.cause == 'timer':
                X.rt_timeout += 1
                self.had_retry = True
                op.cause = None
            out = self.attempt(X, Y, op, a)
            kind = out[0]
            if kind == 'ok':
                self.check_delay_forced(X, Y)
                op.result = ('ok', a + T_FWD + T_REV + self.xfer_time(op))
            elif kind == 'fatal':
                op.result = ('fatal', a + T_FWD + T_REV + 20, out[1], out[2])
            elif kind == 'lost':
                tau = X.timeout << min(op.k, self.P.backoff_max)
                t_exp = a + tau
                if op.k >= X.retry:
                    op.result = ('exhaust_retry', t_exp)
                else:
                    op.k += 1
                    op.next_a = t_exp
                    op.cause = 'timer'
            elif kind == 'rnr':
                t_nak = a + T_FWD + T_REV
                if op.r >= X.rnr_retry:
                    op.result = ('exhaust_rnr', t_nak)
                else:
                    op.r += 1
                    X.rt_rnr += 1
                    X.rnr_success = True
                    self.had_retry = True
                    op.next_a = t_nak + X.rnr_delay + T_RNR_RTT - T_FWD - T_REV

    def check_delay_forced(self, X, Y):
        """spec A.1 `link ... delay`: if the round trip exceeds the timeout, a spurious retransmission is forced."""
        df = self.link_imp[X.name + Y.name].get('delay_min', 0)
        dr = self.link_imp[Y.name + X.name].get('delay_min', 0)
        if X.timeout and df + dr > X.timeout + LINT_MARGIN:
            X.forced_extra_retry = max(X.forced_extra_retry, 1)
            self.impaired = True

    def finalize(self, X, Y, op):
        kind, t = op.result[0], op.result[1]
        if kind == 'ok':
            if op.kind == OP_READ:
                if op.rstate != 'done':
                    raise ModelError('READ completes without data')
                X.mem.write(op.local_pa, op.rdata)
                X.note_write(op.local_pa, op.len, op.line, 'READ wr_id=%d' % op.wr_id,
                             {'mem': X.name, 'kind': 'READ', 'req': X.name, 'sq': op.line, 'rq': None})
            self.release_op(X, op)
            self.cqe(X, 'SQ', op.wr_id, op.kind, ST_OK, op.len, t, op.line)
            X.sq.pop(0)
            X.flow_clock = t
            if op.r > 0:
                X.rnr_resolved += 1
            return 'done'
        if kind == 'fatal':
            code = op.result[2]
            status = NAK_STATUS[code]
            cause = 'FATAL_NAK_%d' % code
        elif kind == 'exhaust_retry':
            status, cause = CQE_STATUS['RETRY_EXC_ERR'], 'RETRY_EXC'
            X.exh_timer += 1
        elif kind == 'exhaust_rnr':
            status, cause = CQE_STATUS['RNR_RETRY_EXC_ERR'], 'RNR_RETRY_EXC'
            X.exh_rnr += 1
            X.rnr_success = False
        elif kind == 'local_fault':
            status, cause = CQE_STATUS['LOC_PROT_ERR'], 'LOC_PROT_ERR'
        else:
            raise ModelError('bad result %r' % (op.result,))
        self.release_op(X, op)
        X.sq.pop(0)
        self.cqe(X, 'SQ', op.wr_id, op.kind, status, 0, t, op.line)
        X.flow_clock = t
        self.enter_err(X, cause, t)
        return 'failed'

    def advance(self, te):
        for _ in range(10000):
            progressed = False
            for X in (self.A, self.B):
                Y = self.peer(X)
                while X.sq and X.state == 'RTS':
                    r = self.step_op(X, Y, X.sq[0], te)
                    if r == 'pending':
                        break
                    progressed = True
                    if r == 'failed':
                        break
            if not progressed:
                break

    def has_pending(self):
        return any(E.state == 'RTS' and E.sq for E in (self.A, self.B))

    # ---- environment-change lint ----------------------------------------
    def sync_env(self, kind):
        """called before commands that change the environment: settle what has finished, and warn if
        something non-stuck is still in flight (the outcome would then depend on cycle timing)."""
        self.advance(self.now)
        for E in (self.A, self.B):
            if E.state != 'RTS' or not E.sq:
                continue
            op = E.sq[0]
            if op.attempts == 0 and op.result is None:
                self.warn('%s right after WQE wr_id=%d (line %d) was posted, before it was even transmitted: '
                          'timing dependent (add run/barrier)' % (kind, op.wr_id, op.line))
            elif op.result is not None and op.result[1] > self.now:
                self.warn('%s while WQE wr_id=%d (line %d) is in flight (completes ~t+%d): timing dependent'
                          % (kind, op.wr_id, op.line, op.result[1] - self.now))
        if self.max_done_t > self.now + 1:
            self.warn('%s while activity is still in flight (until ~t+%d): timing dependent'
                      % (kind, self.max_done_t - self.now))

    # ---- command handlers ---------------------------------------------
    def run(self):
        for c in self.cmds:
            self.cur_line = c['line']
            h = getattr(self, 'do_' + c['cmd'], None)
            if h is None:
                self.notes.append('line %d: unknown command %r ignored' % (c['line'], c['cmd']))
                continue
            try:
                h(c)
            except ModelError as e:
                raise ModelError('line %d (%s): %s' % (c['line'], c['text'].strip(), e))
        self.cur_line = (self.cmds[-1]['line'] if self.cmds else 0)
        self.advance(self.now)
        self.lint_conflicts()
        for E in (self.A, self.B):
            for op in E.sq:
                self.lenient_read(E, op)
            if E.state == 'RTS' and E.sq:
                self.warn('scenario ends with %s still having %d unfinished WQE(s) (no final barrier?)' % (E.name, len(E.sq)))
        return self.build_expectation()

    def do_build(self, c):
        pass

    def do_seed(self, c):
        pass

    def do_mem_lat(self, c):
        self.mem_lat[c['ep']] = (c.get('min', 0), c.get('max', 0), c.get('stall', 0))

    def do_cq_drain(self, c):
        self.cq_drain[c['ep']] = bool(c.get('on', 1))

    def do_mem_fill(self, c):
        self.sync_env('mem_fill')
        E = self.ep(c['ep'])
        E.mem.fill(c['addr'], c['len'], c.get('pat', 0))

    def do_mr(self, c):
        self.sync_env('mr')
        E = self.ep(c['ep'])
        st = E.reg.mr_set(c['idx'], c['va'], c['len'], c['pa'], c['key'], c['pd'], c['acc'], c.get('ctx', 0))
        E.cfgs.append({'cmd': 'MR_SET', 'status': st, 'line': c['line']})

    def do_mr_inval(self, c):
        self.sync_env('mr_inval')
        E = self.ep(c['ep'])
        st = E.reg.mr_inval(c['idx'])
        E.cfgs.append({'cmd': 'MR_INVAL', 'status': st, 'line': c['line']})

    def do_ctx_en(self, c):
        self.sync_env('ctx_en')
        E = self.ep(c['ep'])
        E.reg.ctx_set(c['mask'])
        E.cfgs.append({'cmd': 'CTX_SET', 'status': 0, 'line': c['line']})

    def do_qp(self, c):
        self.sync_env('qp')
        E = self.ep(c['ep'])
        st = c['state']
        cur = E.state
        if st == 'INIT':
            ok = cur == 'RESET'
        elif st == 'RTR':
            ok = cur == 'INIT'
        elif st == 'RTS':
            ok = cur == 'RTR'
        elif st == 'ERR':
            ok = cur != 'RESET'
        elif st == 'RESET':
            ok = True
        else:
            raise ModelError('unknown qp state %r' % st)
        opt = False
        if not ok:
            E.cfgs.append({'cmd': 'QP_MODIFY', 'status': CFG_STATUS['ERR_STATE'], 'line': c['line'], 'optional': opt})
            return
        if st == 'INIT':
            E.state = 'INIT'
            E.qpn, E.pd = c.get('qpn', 0), c.get('pd', 0)
        elif st == 'RTR':
            E.state = 'RTR'
            E.rqpn, E.epoch, E.rq_psn = c.get('rqpn', 0), c.get('epoch', 0), c.get('rq_psn', 0) & M24
            E.smac, E.dmac = c.get('smac', 0), c.get('dmac', 0)
            E.attr_cleared = False
            E.epsn = E.cpsn = E.rq_psn
        elif st == 'RTS':
            E.state = 'RTS'
            E.sq_psn = c.get('sq_psn', 0) & M24
            E.timeout = c.get('timeout', 1000)
            E.retry = c.get('retry', 3)
            E.rnr_retry = c.get('rnr_retry', 3)
            E.rnr_delay = c.get('rnr_delay', 100)
            E.rnr_retry_seen = max(E.rnr_retry_seen, E.rnr_retry)
            E.retry_seen = max(E.retry_seen, E.retry)
            E.nxt = E.sq_psn
            E.flow_clock = self.now
        elif st == 'ERR':
            self.enter_err(E, 'CFG_FORCED', self.now)
        elif st == 'RESET':
            self.reset_qp(E, self.now)
        E.cfgs.append({'cmd': 'QP_MODIFY', 'status': 0, 'line': c['line'], 'optional': opt})

    # -- posting --
    def do_post_recv(self, c):
        E = self.ep(c['ep'])
        addr, ln, wr_id = c['addr'], c['len'], c['wr_id']
        if E.state not in ('INIT', 'RTR', 'RTS'):
            st = 2
        elif ln > self.P.max_msg:
            st = 3
        elif addr + ln > TWO64:
            st = 5
        else:
            st = 0
        E.posts.append({'which': 'RQ', 'wr_id': wr_id, 'status': st, 'line': c['line']})
        if st == 0:
            E.rq.append(Rqe(c['line'], wr_id, addr, c.get('lkey', 0), ln, self.now))
        else:
            E.cnt[{2: 'post_rej_state', 3: 'post_rej_len', 5: 'post_rej_range'}[st]] += 1

    def do_post_send(self, c):
        E = self.ep(c['ep'])
        opv = c['op']
        kind = {'SEND': 1, 'WRITE': 2, 'READ': 3}.get(opv, -1) if isinstance(opv, str) else opv
        ln, wr_id = c['len'], c['wr_id']
        flags = c.get('flags', 0)
        raddr = c.get('raddr', 0)
        if E.state != 'RTS':
            st = 2
        elif kind not in (1, 2, 3):
            st = 1
        elif flags != 0:
            st = 4
        elif ln > self.P.max_msg or (ln == 0 and kind in (OP_WRITE, OP_READ)):
            st = 3
        elif kind in (OP_WRITE, OP_READ) and raddr + ln > TWO64:
            st = 5
        else:
            st = 0
        E.posts.append({'which': 'SQ', 'wr_id': wr_id, 'status': st, 'line': c['line']})
        if st == 0:
            op = Wqe(c['line'], wr_id, kind, c.get('laddr', 0), c.get('lkey', 0), ln, raddr, c.get('rkey', 0),
                     self.now, self.P.mtu)
            op.psn0 = E.nxt
            E.nxt = psn_add(E.nxt, op.npsn)
            op.seq = self.seq[E.name]
            self.seq[E.name] += 1
            E.sq.append(op)
            self.lenient_read(E, op)
            if kind == OP_SEND:
                E.n_sends += 1
            self.sq_posted[E.name] += 1
            self.psn_posted[E.name] += op.npsn
        else:
            E.cnt[{1: 'post_rej_opcode', 2: 'post_rej_state', 3: 'post_rej_len', 4: 'post_rej_fields',
                   5: 'post_rej_range'}[st]] += 1

    # -- link --
    def do_link(self, c):
        d = c['dir']
        imp = {k: v for k, v in c.items() if k in ('drop', 'dup', 'delay_min', 'delay_max', 'reorder')}
        self.link_imp[d] = imp
        if imp.get('drop', 0) or imp.get('dup', 0) or imp.get('reorder', 0) or imp.get('delay_max', 0):
            self.impaired = True

    def do_link_script(self, c):
        self.sync_env('link_script')
        d = c['dir']
        sc = {'drop': c.get('drop', []), 'dup': c.get('dup', []), 'delay': c.get('delay', []),
              'clean_start': not self.started[d]}
        self.link_script[d] = sc
        self.impaired = True

    def do_link_black(self, c):
        self.sync_env('link_black')
        d = c['dir']
        on = bool(c.get('on', 1))
        if on:
            if not self.black[d] or self.black[d][-1][1] is not None:
                self.black[d].append([self.now, None])
        else:
            if self.black[d] and self.black[d][-1][1] is None:
                self.black[d][-1][1] = self.now

    # -- reset --
    def do_reset(self, c):
        self.sync_env('reset')
        E = self.ep(c['ep'])
        if c['kind'] == 'hard':
            self.note_vanishing(E)
            E.hard_reset()
            self.had_reset = True
            E.flow_clock = self.now
        elif c['kind'] == 'qp':
            self.reset_qp(E, self.now)
            E.cfgs.append({'cmd': 'QP_MODIFY', 'status': 0, 'line': c['line'], 'optional': True})
        else:
            raise ModelError('bad reset kind %r' % c['kind'])

    # -- inject --
    def do_inject(self, c):
        self.sync_env('inject')
        d = c['dir']
        if self.is_black(d, self.now + 20):
            self.warn('inject while link %s is black: behaviour of the bench is unspecified' % d)
        rx = self.B if d == 'AB' else self.A
        data = F.from_hex(c['hex'])
        self.inject_effect(rx, data, bool(c.get('err', 0)))

    def inject_effect(self, rx, data, rx_err=False):
        X = self.peer(rx)
        counter, f = F.adapter_check(data, rx.smac if rx.smac is not None else -1, rx.dmac if rx.dmac is not None else -1,
                                     rx.qpn if rx.qpn is not None else -1, rx.epoch if rx.epoch is not None else -1,
                                     self.P.mtu, rx_err=rx_err)       # a frame flagged bad by the MAC is dropped whole (spec 3.4)
        if rx.state in ('RESET', 'INIT'):
            if rx.attr_cleared:
                # after rst_n the MAC registers are 0: classification per 3.4 against zeroed attributes
                counter0, _ = F.adapter_check(data, 0, 0, 0, 0, self.P.mtu, rx_err=rx_err)
                rx.cnt[counter0 or 'rx_drop_state'] += 1
            elif counter in ('rx_drop_len', 'rx_drop_ethertype', 'rx_drop_ver', 'rx_drop_opcode', 'rx_drop_keep', 'rx_drop_macerr'):
                rx.cnt[counter] += 1
            else:
                rx.lo_group += 1
            return
        if counter:
            rx.cnt[counter] += 1
            return
        cls = F.opcode_class(f['opcode'])
        if rx.state == 'ERR':
            if cls == 'request' and rx.err_nak is not None:
                rx.cnt['tx_nak'] += 1
            else:
                rx.cnt['rx_drop_state'] += 1
            return
        if not F.state_accepts(rx.state, cls):
            rx.cnt['rx_drop_state'] += 1
            return
        if cls == 'request':
            psn = f['psn']
            if psn == rx.epsn:
                why = F.protocol_request_violation(f, self.P.max_msg)
                rx.lo_only['tx_nak'] += 1
                if why is not None:
                    if 0x04 <= f['opcode'] <= 0x0F:
                        rx.cnt['rx_unsupported_op'] += 1
                    self.responder_fatal(rx, F.NAK_INV_REQ, rx.epsn, self.now + T_FWD)
                elif f['opcode'] in (F.OP_WRITE, F.OP_READ_REQ):
                    # well-formed in-order WRITE / READ_REQ: only the *failing* registry check is modelled
                    if f['opcode'] == F.OP_WRITE:
                        g = rx.reg.check(REMOTE_WRITE, f['rkey'], rx.pd, f['va'], f['paylen'])
                    else:
                        g = rx.reg.check(REMOTE_READ, f['rkey'], rx.pd, f['va'], f['mlen'] - f['moff'])
                    if not isinstance(g, str):
                        rx.reg.release(g)
                        raise ModelError('inject of a well-formed in-order request that PASSES the registry check is '
                                         'not supported by the model (only faulting ones are)')
                    self.responder_fatal(rx, F.NAK_REM_ACCESS, rx.epsn, self.now + T_FWD)
                else:
                    raise ModelError('inject of an in-order SEND is not supported by the model')
            elif psn_before(psn, rx.epsn):
                rx.cnt['rx_dup'] += 1
                if f['opcode'] == F.OP_READ_REQ:
                    # a duplicate READ_REQ is re-executed; the requester drops the repeated response segments
                    X.lo_only['rx_resp_drop'] += 1
            else:
                rx.cnt['rx_oos'] += 1
                rx.lo_only['tx_nak'] += 1
        elif cls == 'response':
            rx.cnt['rx_resp_drop'] += 1
        else:
            # ACK / NAK at the requester
            if f['opcode'] == F.OP_NAK and f['code'] not in (1, 2, 3, 4, 5):
                rx.cnt['rx_nak_badcode'] += 1
                return
            una = rx.sq[0].psn0 if rx.sq else rx.nxt
            if not ack_valid(una, f['psn'], f['accept_next'], rx.nxt):
                rx.cnt['rx_ack_stale'] += 1
            elif f['opcode'] == F.OP_NAK or f['psn'] != una:
                raise ModelError('inject of a valid ACK/NAK that changes requester state is not supported')

    # -- time --
    def do_run(self, c):
        cyc = c.get('cycles', c.get('n', 0))
        self.advance(self.now + cyc)
        self.now += cyc

    do_idle = do_run

    def do_barrier(self, c):
        mx = c.get('max', 100000)
        te = self.now + mx
        self.advance(te)
        self.check_conflicts_reset_and_lint()
        if self.has_pending():
            self.now = te
            self.expect_timeout = True
        else:
            self.now = max(self.now, self.max_done_t + 64)

    def cqe_count(self, E):
        return len(E.sq_cqes) + len(E.rq_cqes)

    def do_wait_cqe(self, c):
        E = self.ep(c['ep'])
        n, mx = c['n'], c.get('max', 100000)
        te = self.now + mx
        t = self.now
        for s in (5, 20, 60, 200, 600, 2000, 6000, 20000, 60000, 200000, 600000, 2000000, 6000000, 20000000):
            t = min(self.now + s, te)
            self.advance(t)
            if self.cqe_count(E) >= n or t >= te:
                break
        if self.cqe_count(E) >= n:
            ts = sorted(r['t'] for r in E.sq_cqes + E.rq_cqes)
            self.now = max(self.now, min(t, ts[n - 1]))
        else:
            self.now = te
            self.expect_timeout = True

    def do_dump(self, c):
        """spec A.1: the memory as it is when the command executes (not the end-of-scenario memory)"""
        self.sync_env('dump')
        E = self.ep(c['ep'])
        if not E.mem.known(c['addr'], c['len']):
            self.notes.append('dump at line %d (%s 0x%X+%d) covers bytes never filled/written: expected as 0'
                              % (c['line'], c['ep'], c['addr'], c['len']))
        self.dump_snaps.append({'ep': c['ep'], 'addr': c['addr'], 'len': c['len'], 'line': c['line'],
                                'hex': E.mem.read(c['addr'], c['len']).hex()})

    # ---- determinism lint on memory accesses ----------------------------
    def check_conflicts_reset_and_lint(self):
        self.lint_conflicts()
        self.batch_acc = []

    def lint_conflicts(self):
        """Determinism lint.  Within one batch (between barriers) overlapping accesses to the same bytes are
        forbidden when at least one is a write, EXCEPT between responder-side accesses of one flow (the
        in-order write path + the read-after-write fence of 7.3 make them deterministic) -- but a READ source
        read followed by a later-PSN write of the same flow is unordered (7.3) and flagged."""
        by_ep = {}
        for a in self.batch_acc:
            by_ep.setdefault(a['ep'], []).append(a)
        seen = set()
        for ep, lst in by_ep.items():
            lst = sorted(lst, key=lambda x: x['lo'])
            for i in range(len(lst)):
                a = lst[i]
                for j in range(i + 1, len(lst)):
                    b = lst[j]
                    if b['lo'] >= a['hi']:
                        break
                    if a['rw'] == 'r' and b['rw'] == 'r':
                        continue
                    if a['line'] == b['line'] and a['seq'] == b['seq'] and a['flow'] == b['flow']:
                        continue
                    if a['role'] == 'resp' and b['role'] == 'resp':
                        first, second = (a, b) if a['seq'] <= b['seq'] else (b, a)
                        if not (first['what'] == 'READ_SRC' and second['rw'] == 'w'):
                            continue
                    key = (ep, a['line'], b['line'])
                    if key in seen:
                        continue
                    seen.add(key)
                    self.warnings.append((max(a['line'], b['line']),
                                          'conflicting accesses within one batch on %s memory: %s/%s (line %d) vs %s/%s '
                                          '(line %d) overlap' % (ep, a['what'], a['rw'], a['line'], b['what'], b['rw'], b['line'])))

    # ---- build expectation ------------------------------------------------
    def build_expectation(self):
        ex = Expectation()
        ex.name = self.name
        ex.params = self.P.to_dict()
        ex.warnings = list(self.warnings)
        ex.notes = list(self.notes)
        ex.expect_timeout = self.expect_timeout
        for E in (self.A, self.B):
            x = ex.ep[E.name]
            x.qpn = E.qpn
            x.sq_cqes = [dict(r) for r in E.sq_cqes]
            x.rq_cqes = [dict(r) for r in E.rq_cqes]
            x.posts = list(E.posts)
            x.cfgs = list(E.cfgs)
            x.write_counts = dict(E.wc)
            x.write_log = list(E.write_log)
            x.final_bytes = {pa: E.mem.b.get(pa, 0) for pa in E.wc}
            x.read_env = merge_ranges(E.read_env + E.lenient)
            x.write_env = merge_ranges(E.write_env)
            x.faults = {f: E.reg.faults[f] for f in FAULT_CLASSES}
            x.qp_state = E.state
            x.qp_cause = E.err_cause if E.state == 'ERR' else None
            x.dumps = [dict(d) for d in self.dump_snaps if d['ep'] == E.name]
            self.fill_counters(E, x)
        return ex

    def fill_counters(self, E, x):
        P = self.P
        C = E.cnt
        hard = x.counters
        soft = x.soft_counters
        for k in ('send', 'write', 'read', 'recv'):
            hard['ops_done_' + k] = C['ops_done_' + k]
            hard['bytes_' + k] = C['bytes_' + k]
        for f in FAULT_CLASSES:
            hard['mr_fault_' + f] = E.reg.faults[f]
        hard['mr_fault_total'] = E.reg.fault_total
        hard['post_rej_opcode'] = C['post_rej_opcode']
        for k in ('post_rej_state', 'post_rej_len', 'post_rej_fields', 'post_rej_range'):
            soft[k] = C[k]
        soft['rx_nak_badcode'] = C['rx_nak_badcode']
        # spec 15 does not say whether ops_err / ops_flushed include receive-queue completions: accept both readings
        for nm in ('ops_err', 'ops_flushed'):
            x.bounds.append({'name': nm, 'lo': C[nm], 'hi': C[nm] + C['rq_' + nm], 'soft': True,
                             'why': 'SQ completions (+ RQ completions if the counter includes them)'})
        hard['guard_violation'] = 0
        soft['dma_wr_bytes'] = E.wbytes_since_reset
        hard['rx_unsupported_op'] = C['rx_unsupported_op']
        irregular = self.impaired or self.had_err or self.had_retry or self.had_reset
        if E.lo_group:
            x.bounds.append({'terms': ['rx_drop_state', 'rx_drop_mac', 'rx_drop_qpn', 'rx_drop_epoch'], 'lo': E.lo_group and 1,
                             'hi': None, 'soft': False,
                             'why': 'frames reached an endpoint in RESET/INIT after a QP reset (class not fixed by the spec)'})
        for name in ('rx_drop_len', 'rx_drop_keep', 'rx_drop_macerr', 'rx_drop_ethertype', 'rx_drop_mac', 'rx_drop_ver',
                     'rx_drop_opcode', 'rx_drop_qpn', 'rx_drop_epoch', 'rx_drop_state'):
            v = C[name]
            lo_only = E.lo_only[name]
            group = E.lo_group > 0 and name in ('rx_drop_state', 'rx_drop_mac', 'rx_drop_qpn', 'rx_drop_epoch')
            open_ = lo_only > 0 or group or (name == 'rx_drop_state' and irregular)
            if open_:
                x.bounds.append({'name': name, 'lo': v + (1 if lo_only else 0), 'hi': None, 'soft': False,
                                 'why': 'frames dropped (config mismatch / non-accepting state) while the peer retries'})
            else:
                hard[name] = v
        for name in ('rx_dup', 'rx_oos', 'rx_ack_stale', 'rx_resp_drop'):
            v = C[name]
            if irregular or E.lo_only[name] > 0:
                x.bounds.append({'name': name, 'lo': v, 'hi': None, 'soft': True, 'why': 'impairments/errors/retries present'})
            else:
                soft[name] = v
        # reliability counters of the requester role: only the bounds of spec A.5
        #   retry_timeout + retry_nak : == 0 on a clean link without reset/RNR; lower bounds where the scenario forces
        #                               retransmission; no upper bound beyond retry_max per progress period
        #   retry_rnr                 : <= rnr_retry_max (per progress period); == rnr_retry_max when RNR retries are exhausted
        n_to, n_rnr = E.rt_timeout, E.rt_rnr
        rnr_involved = n_rnr > 0 or E.exh_rnr > 0
        unclean = self.impaired or self.had_reset or rnr_involved
        lo = max(n_to, E.forced_extra_retry)
        if not unclean and not E.exh_timer:
            hi = lo if lo == 0 else None
            if lo:
                hi = None
        elif E.exh_timer and not unclean:
            hi = lo                       # exactly retry_max per exhausted progress period
        else:
            hi = None
        if E.exh_timer and E.exh_timer == 1 and not unclean:
            lo = hi = max(n_to, E.retry_seen)
        x.bounds.append({'terms': ['retry_timeout', 'retry_nak'], 'lo': lo, 'hi': hi, 'soft': False,
                         'why': 'modelled timer expiries=%d%s%s' % (n_to, ', retry exhausted' if E.exh_timer else '',
                                                                    ', unclean link/reset/RNR' if unclean else ', clean link')})
        rhi = E.rnr_retry_seen * max(1, E.n_sends) if E.n_sends else 0
        # a lower bound only where the SEND really waited and was retransmitted (success after RNR) or exhausted its
        # RNR retries: whether the counter ticks at NAK receipt or at the retransmission is not fixed by 9.6 (a SEND that
        # is killed by a fatal NAK during rnr_delay may show 0)
        rlo = E.rnr_retry_seen * E.exh_rnr if E.exh_rnr else (1 if E.rnr_resolved else 0)
        if E.exh_rnr:
            rhi = max(rhi, rlo)
        # spec 9.6: the RNR counter resets on PROGRESS, so another WQE's late ACK between two RNR NAKs legitimately grants a new round of
        # rnr_retry_max retries: there is no upper bound.  A lower bound is only guaranteed when the RNR retries were EXHAUSTED; "the SEND
        # waited at least once" depends on whether the receive buffer was posted before the SEND arrived (timing: parameters change it).
        rhi = None
        x.bounds.append({'name': 'retry_rnr', 'lo': rlo, 'hi': rhi, 'soft': not bool(E.exh_rnr),
                         'why': 'RNR NAKs modelled=%d, rnr_retry_max=%d, SENDs posted=%d%s'
                                % (n_rnr, E.rnr_retry_seen, E.n_sends, ', RNR retries exhausted' if E.exh_rnr else '')})
        # request frames dropped by a link_script ordinal in the first transmission force at least one retry
        sc = self.link_script['AB'] if E.name == 'A' else self.link_script['BA']
        if sc and sc['clean_start'] and sc['drop'] and not self.had_err and E.name == 'A' and self.sq_posted['B'] == 0 \
                and min(sc['drop']) <= self.psn_posted['A']:
            x.bounds.append({'terms': ['retry_timeout', 'retry_nak', 'retry_rnr'], 'lo': 1, 'hi': None, 'soft': True,
                             'why': 'link_script drops request frame #%d of the first transmission' % min(sc['drop'])})
        if n_to == 0 and not unclean and not E.exh_timer:
            x.bounds.append({'name': 'tx_retx_frames', 'lo': 0, 'hi': 0, 'soft': True, 'why': 'clean link, no retries'})


def predict(scn, name=''):
    """scn: path to a .scn file or an already-parsed command list.  Returns an Expectation."""
    if isinstance(scn, str):
        name = name or os.path.basename(scn)
        cmds = parse_scn(scn)
    else:
        cmds = scn
    return Model(cmds, name).run()


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description='run the SFRT reference model on a scenario and dump the Expectation')
    ap.add_argument('scenario')
    ap.add_argument('--summary', action='store_true')
    a = ap.parse_args()
    e = predict(a.scenario)
    if a.summary:
        for k, x in e.ep.items():
            print(k, 'state=%s' % x.qp_state, 'SQ:', [(r['wr_id'], r['op'], r['status'], r['len']) for r in x.sq_cqes],
                  'RQ:', [(r['wr_id'], r['status'], r['len']) for r in x.rq_cqes])
        for w in e.warnings:
            print('WARN line %d: %s' % w)
    else:
        print(e.to_json(indent=1))
