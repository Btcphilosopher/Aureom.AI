#!/usr/bin/env python3
"""check_results.py - compare a bench result file against the independent reference model.

    python3 -I check_results.py <scenario.scn> <result.res> [--strict] [-v] [--json]

Prints `PASS` (exit 0) or `FAIL (N mismatches)` followed by precise mismatch lines (exit 1).
Exit 2 = the model itself could not process the scenario.

Compared (spec A.4): SQ and RQ CQE sequences (wr_id, op, status, len, qpn), post statuses, cfg statuses,
dump contents, EXACT per-byte write counts reconstructed from the MEMW strobes (+ written values), reads only
inside the word-granular legal-read envelope, registry fault counters, exact counters, bounds on reliability
counters, final QP state.  `soft` findings (counters whose exact RTL semantics the spec leaves open) are
printed as NOTE and only fail with --strict.
"""
import argparse
import bisect
import json
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import scn as S                                   # noqa: E402
import sfrt_model as M                            # noqa: E402

MAX_GROUPS = 12


class Report:
    def __init__(self):
        self.fail = []     # hard mismatches
        self.soft = []     # soft findings
        self.notes = []    # informational
        self.stats = {}

    def bad(self, msg):
        self.fail.append(msg)

    def softbad(self, msg):
        self.soft.append(msg)

    def note(self, msg):
        self.notes.append(msg)


def _lines_text(cmds):
    return {c['line']: c['text'].strip() for c in cmds}


def _src(lines, ln):
    if ln in lines:
        return 'scenario line %d: %s' % (ln, lines[ln])
    return 'scenario line %s' % ln if ln else ''


def _op_name(o):
    return S.CQE_OP_NAME.get(o, str(o))


def _st_name(s):
    return S.CQE_STATUS_NAME.get(s, str(s))


def _fmt_cqe(r):
    return 'wr_id=%s op=%s status=%s len=%s' % (r['wr_id'], _op_name(r['op']), _st_name(r['status']), r['len'])


def _ranges(byte_to_key):
    """group {addr: key} into contiguous (lo, hi_incl, key) runs."""
    out = []
    for a in sorted(byte_to_key):
        k = byte_to_key[a]
        if out and out[-1][1] == a - 1 and out[-1][2] == k:
            out[-1][1] = a
        else:
            out.append([a, a, k])
    return out


def _env_contains(env, a):
    # env: sorted list of (lo,hi) merged
    i = bisect.bisect_right(env, (a, 1 << 80)) - 1
    return i >= 0 and env[i][0] <= a < env[i][1]


def _env_overlaps(env, lo, hi):
    i = bisect.bisect_right(env, (lo, 1 << 80)) - 1
    if i >= 0 and env[i][1] > lo:
        return True
    j = i + 1
    return j < len(env) and env[j][0] < hi


# ---------------------------------------------------------------------------
def check(exp, res, cmds, strict=False):
    rep = Report()
    lines = _lines_text(cmds)
    W = exp.params['dw'] // 8

    for e in res.errors:
        rep.bad('result file: ' + e)
    for u in res.unknown[:5]:
        rep.note("result file: unrecognised line ignored: %r" % u)
    if res.end is None:
        rep.bad('result file has no END line (run aborted?)')
    else:
        if res.end.get('timeout') not in (0, None) and not exp.expect_timeout:
            rep.bad('END timeout=1: a barrier/wait_cqe/the run hit its limit, the model expects every barrier to complete')
        if res.end.get('timeout') in (0, None) and exp.expect_timeout:
            rep.softbad('model expected a barrier/wait_cqe to time out (stuck operation outliving `max`), the bench did not time out')

    for m in res.mons:
        rep.bad('bench monitor reported: %s' % m)
    if res.end is not None and isinstance(res.end.get('monitor_errors'), int) and res.end['monitor_errors'] > 0 and not res.mons:
        rep.bad('END monitor_errors=%d (bench monitors flagged protocol/liveness violations)' % res.end['monitor_errors'])
    for n in res.bench_notes:
        if 'timed out' in n:
            if not exp.expect_timeout:
                rep.bad('bench: "%s" -- the system did not become quiet / the awaited CQEs did not appear within the limit; '
                        'the model expects every barrier/wait_cqe to complete' % n)
        else:
            rep.note('bench: ' + n)
    for w in exp.warnings:
        rep.note('scenario/model warning (line %s): %s -- expectations for this scenario may be timing dependent' % w)
    for n in exp.notes:
        rep.note(n)

    check_commit_before_completion(rep, exp, res, lines, W)
    for ep in ('A', 'B'):
        x = exp.ep[ep]
        check_cfg(rep, ep, x, res, lines)
        check_posts(rep, ep, x, res, lines)
        check_cqes(rep, ep, x, res, lines)
        check_dumps(rep, ep, x, res, lines)
        check_mem(rep, ep, x, res, lines, W)
        check_counters(rep, ep, x, res)
        check_qpst(rep, ep, x, res)
    return rep


# ---------------------------------------------------------------------------
def check_commit_before_completion(rep, exp, res, lines, W):
    """Completion only after commit (spec 7.1 / 7.2 / 7.3 / 10.2).  For every OK CQE
         WRITE (requester), SEND (requester), RECV (responder), READ (requester)
    the CQE cycle must be >= the largest `ack` cycle of ALL MEMW words that belong to that WQE.  The words are matched
    to the WQE through the model's provenance of every placement (PA range + per-byte write order): the k-th write of
    byte b in the MEMW trace is the k-th placement of b in the model.  A CQE (or the ACK that lets the requester
    complete) produced on *accept* instead of *commit* shows up as a CQE that precedes the last memory acknowledge."""
    have_ack = any(w['ack'] is not None for w in res.memw)
    if not have_ack:
        if res.memw:
            rep.note('MEMW lines carry no ack= field: the completion-after-commit rule was not evaluated')
        return
    ack_sq = {}      # (requester ep, post_send line) -> max ack
    ack_rq = {}      # (responder ep, post_recv line)  -> max ack
    for mem_ep in ('A', 'B'):
        x = exp.ep[mem_ep]
        cover = {}                                   # byte -> [log entry index, ...] in model order
        for i, (lo, hi, _l, _w, _info) in enumerate(x.write_log):
            for b in range(lo, hi):
                cover.setdefault(b, []).append(i)
        seen = Counter()
        entry_ack = {}
        for w in res.memw:
            if w['ep'] != mem_ep or w['ack'] is None:
                continue
            for k in range(W):
                if (w['strb'] >> k) & 1:
                    b = w['addr'] + k
                    n = seen[b]
                    seen[b] += 1
                    lst = cover.get(b)
                    if lst is not None and n < len(lst):
                        i = lst[n]
                        if w['ack'] > entry_ack.get(i, -1):
                            entry_ack[i] = w['ack']
        for i, a in entry_ack.items():
            info = x.write_log[i][4]
            if not info:
                continue
            k1 = (info['req'], info['sq'])
            ack_sq[k1] = max(ack_sq.get(k1, -1), a)
            if info['kind'] == 'SEND' and info['rq'] is not None:
                k2 = (mem_ep, info['rq'])
                ack_rq[k2] = max(ack_rq.get(k2, -1), a)
    checked = 0
    for ep in ('A', 'B'):
        x = exp.ep[ep]
        allr = [c for c in res.cqes if c['ep'] == ep]
        streams = (('SQ', x.sq_cqes, [c for c in allr if c['op'] != 4], ack_sq),
                   ('RQ', x.rq_cqes, [c for c in allr if c['op'] == 4], ack_rq))
        for name, E, R, table in streams:
            for e, r in zip(E, R):
                if e['status'] != 0 or r['status'] != 0 or r['wr_id'] != e['wr_id'] or r['op'] != e['op']:
                    continue
                a = table.get((ep, e['line']))
                if a is None or r['cyc'] is None:
                    continue
                checked += 1
                if r['cyc'] < a:
                    rep.bad('COMMIT ep=%s %s CQE wr_id=%s op=%s completed at cycle %d but the last memory write of that WQE was '
                            'acknowledged at cycle %d: completion/ACK must wait for the commit (result line %d) -- %s'
                            % (ep, name, e['wr_id'], _op_name(e['op']), r['cyc'], a, r['line'], _src(lines, e['line'])))
    rep.stats['commit_rule_wqes_checked'] = checked


def check_cfg(rep, ep, x, res, lines):
    R = [c for c in res.cfgs if c['ep'] == ep]
    E = x.cfgs
    req = [e for e in E if not e.get('optional')]
    if len(R) == len(E):
        pairs = list(zip(E, R))
    elif len(R) == len(req):
        pairs = list(zip(req, R))
    else:
        rep.bad('CFG ep=%s: %d CFG lines in result, expected %d (or %d if QP-reset commands are not reported)'
                % (ep, len(R), len(E), len(req)))
        pairs = list(zip(E if abs(len(R) - len(E)) <= abs(len(R) - len(req)) else req, R))
    for e, r in pairs:
        if r['status'] != e['status']:
            rep.bad('CFG ep=%s %s: expected status %s (%d), got %s -- %s'
                    % (ep, e['cmd'], S.CFG_STATUS_NAME.get(e['status']), e['status'],
                       S.CFG_STATUS_NAME.get(r['status'], r['status']), _src(lines, e['line'])))


def check_posts(rep, ep, x, res, lines):
    for which in ('SQ', 'RQ'):
        E = [p for p in x.posts if p['which'] == which]
        R = [p for p in res.posts if p['ep'] == ep and p['which'] == which]
        if len(E) != len(R):
            rep.bad('POST ep=%s %s: %d POST lines in result, expected %d' % (ep, which, len(R), len(E)))
        for i, (e, r) in enumerate(zip(E, R)):
            if r['wr_id'] != e['wr_id']:
                rep.bad('POST ep=%s %s #%d: expected wr_id=%s got wr_id=%s -- %s'
                        % (ep, which, i + 1, e['wr_id'], r['wr_id'], _src(lines, e['line'])))
            if r['status'] != e['status']:
                rep.bad('POST ep=%s %s wr_id=%s: expected status %s (%d), got %s -- %s'
                        % (ep, which, e['wr_id'], S.POST_STATUS_NAME.get(e['status']), e['status'],
                           S.POST_STATUS_NAME.get(r['status'], r['status']), _src(lines, e['line'])))


def check_cqes(rep, ep, x, res, lines):
    allr = [c for c in res.cqes if c['ep'] == ep]
    streams = (('SQ', x.sq_cqes, [c for c in allr if c['op'] != 4]),
               ('RQ', x.rq_cqes, [c for c in allr if c['op'] == 4]))
    for name, E, R in streams:
        n = max(len(E), len(R))
        shown = 0
        for i in range(n):
            e = E[i] if i < len(E) else None
            r = R[i] if i < len(R) else None
            if e is None:
                rep.bad('CQE ep=%s %s #%d: unexpected extra CQE %s (result line %d)' % (ep, name, i + 1, _fmt_cqe(r), r['line']))
                shown += 1
            elif r is None:
                rep.bad('CQE ep=%s %s #%d: missing CQE, expected %s -- %s'
                        % (ep, name, i + 1, _fmt_cqe(e), _src(lines, e['line'])))
                shown += 1
            else:
                diffs = []
                for k in ('wr_id', 'op', 'status', 'len'):
                    if r[k] is not None and r[k] != e[k]:
                        diffs.append(k)
                if diffs:
                    rep.bad('CQE ep=%s %s #%d: expected [%s] got [%s] (differs: %s) -- %s'
                            % (ep, name, i + 1, _fmt_cqe(e), _fmt_cqe(r), ','.join(diffs), _src(lines, e['line'])))
                    shown += 1
                elif x.qpn is not None and r['qpn'] is not None and r['qpn'] != x.qpn:
                    rep.softbad('CQE ep=%s %s #%d wr_id=%s: qpn=%s expected %s' % (ep, name, i + 1, e['wr_id'], r['qpn'], x.qpn))
            if shown >= MAX_GROUPS:
                rep.bad('CQE ep=%s %s: ... further CQE mismatches suppressed' % (ep, name))
                break


def check_dumps(rep, ep, x, res, lines):
    R = [d for d in res.dumps if d['ep'] == ep]
    E = x.dumps
    if len(R) != len(E):
        rep.bad('DUMP ep=%s: %d DUMP lines in result, expected %d' % (ep, len(R), len(E)))
    for e, r in zip(E, R):
        if r['addr'] != e['addr']:
            rep.bad('DUMP ep=%s: expected addr 0x%X got 0x%X -- %s' % (ep, e['addr'], r['addr'], _src(lines, e['line'])))
            continue
        if r['hex'] != e['hex']:
            eb, rb = bytes.fromhex(e['hex']), bytes.fromhex(r['hex']) if len(r['hex']) % 2 == 0 else b''
            if len(rb) != len(eb):
                rep.bad('DUMP ep=%s addr=0x%X: expected %d bytes, got %d -- %s'
                        % (ep, e['addr'], len(eb), len(rb), _src(lines, e['line'])))
                continue
            bad = [i for i in range(len(eb)) if eb[i] != rb[i]]
            i0 = bad[0]
            lo, hi = max(0, i0 - 4), min(len(eb), i0 + 12)
            rep.bad('DUMP ep=%s addr=0x%X len=%d: %d byte(s) differ, first at PA 0x%X (offset %d): expected %s got %s -- %s'
                    % (ep, e['addr'], len(eb), len(bad), e['addr'] + i0, i0, eb[lo:hi].hex(), rb[lo:hi].hex(),
                       _src(lines, e['line'])))


def check_mem(rep, ep, x, res, lines, W):
    seen = Counter()
    lastv = {}
    unaligned = 0
    nw = 0
    for w in res.memw:
        if w['ep'] != ep:
            continue
        nw += 1
        a = w['addr']
        if a % W:
            unaligned += 1
            if unaligned <= 3:
                rep.bad('MEMW ep=%s result line %d: write address 0x%X is not aligned to the %d-byte memory word' % (ep, w['line'], a, W))
        for k in range(W):
            if (w['strb'] >> k) & 1:
                b = a + k
                seen[b] += 1
                lastv[b] = (w['data'] >> (8 * k)) & 0xFF
    exp_wc = x.write_counts
    wenv = x.write_env
    # --- exact per-byte write counts ---
    diff = {}
    for b in set(seen) | set(exp_wc):
        s, e = seen.get(b, 0), exp_wc.get(b, 0)
        if s != e:
            diff[b] = (s, e)
    groups = _ranges(diff)
    for g_i, (lo, hi, (s, e)) in enumerate(groups):
        if g_i >= MAX_GROUPS:
            rep.bad('MEMW ep=%s: ... %d further byte-count mismatch ranges suppressed' % (ep, len(groups) - MAX_GROUPS))
            break
        extra = ''
        if e == 0:
            if not _env_contains(wenv, lo):
                extra = ' -- OUTSIDE every authorised write window (no accepted operation may touch these bytes)'
            else:
                extra = ' -- inside an authorised window but not expected to be written again'
        else:
            who = sorted({(l, w) for (a0, a1, l, w, _i) in x.write_log if a0 <= hi and lo < a1})
            if who:
                extra = ' -- expected by ' + '; '.join('%s (%s)' % (w, _src(lines, l)) for l, w in who[:3])
        rep.bad('MEMW ep=%s PA [0x%X..0x%X] (%d bytes): written %d time(s), expected %d%s'
                % (ep, lo, hi, hi - lo + 1, s, e, extra))
    # --- written values: last write of each byte must equal the model's final byte ---
    vdiff = {}
    for b, v in lastv.items():
        if b in x.final_bytes and exp_wc.get(b, 0) > 0 and x.final_bytes[b] != v:
            vdiff[b] = (v, x.final_bytes[b])
    for g_i, (lo, hi, (v, ev)) in enumerate(_ranges({b: (v, e) for b, (v, e) in vdiff.items()})):
        if g_i >= MAX_GROUPS:
            break
        rep.bad('MEMW ep=%s PA [0x%X..0x%X]: data written differs from the expected final contents (e.g. wrote 0x%02X expected 0x%02X)'
                % (ep, lo, hi, v, ev))
    # --- reads: word granular envelope ---
    renv = x.read_env
    bad_reads = {}
    nr = 0
    for r in res.memr:
        if r['ep'] != ep:
            continue
        nr += 1
        a = r['addr']
        if a % W:
            rep.bad('MEMR ep=%s result line %d: read address 0x%X is not aligned to the %d-byte memory word' % (ep, r['line'], a, W))
        base = a - (a % W)
        if not _env_overlaps(renv, base, base + W):
            bad_reads[base] = 1
    for g_i, (lo, hi, _) in enumerate(_ranges({b: 1 for b in bad_reads}) if W == 1 else _word_groups(bad_reads, W)):
        if g_i >= MAX_GROUPS:
            rep.bad('MEMR ep=%s: ... further out-of-envelope read ranges suppressed' % ep)
            break
        rep.bad('MEMR ep=%s PA [0x%X..0x%X]: memory read outside every authorised read window (local source buffers / served READ ranges)'
                % (ep, lo, hi + W - 1))
    rep.stats['%s_memw_words' % ep] = nw
    rep.stats['%s_memr_words' % ep] = nr
    rep.stats['%s_bytes_written' % ep] = sum(seen.values())


def _word_groups(bad, W):
    out = []
    for a in sorted(bad):
        if out and out[-1][1] == a - W:
            out[-1][1] = a
        else:
            out.append([a, a, 1])
    return out


def check_counters(rep, ep, x, res):
    C = res.cnts.get(ep, {})
    if not C:
        rep.bad('CNT ep=%s: no counters in the result' % ep)
        return
    for name, v in sorted(x.counters.items()):
        if name not in C:
            rep.bad('CNT ep=%s %s: counter not reported (expected %d)' % (ep, name, v))
        elif C[name] != v:
            rep.bad('CNT ep=%s %s: expected %d, got %d' % (ep, name, v, C[name]))
    for name, v in sorted(x.soft_counters.items()):
        if name in C and C[name] != v:
            rep.softbad('CNT ep=%s %s: expected %d, got %d (semantics left open by the spec)' % (ep, name, v, C[name]))
    for b in x.bounds:
        terms = b.get('terms') or [b['name']]
        if any(t not in C for t in terms):
            missing = [t for t in terms if t not in C]
            (rep.softbad if b['soft'] else rep.bad)('CNT ep=%s %s: counter(s) not reported: %s' % (ep, '+'.join(terms), ','.join(missing)))
            continue
        v = sum(C[t] for t in terms)
        lo, hi = b['lo'], b['hi']
        if v < lo or (hi is not None and v > hi):
            rng = '== %d' % lo if hi == lo else ('>= %d' % lo if hi is None else '%d..%d' % (lo, hi))
            (rep.softbad if b['soft'] else rep.bad)(
                'CNT ep=%s %s: got %d, model expects %s (%s)' % (ep, '+'.join(terms) if len(terms) > 1 else terms[0], v, rng, b['why']))
    # structural counters that must hold on any scenario
    if 'guard_violation' in C and C['guard_violation'] != 0:
        pass    # already covered by exact counters
    if 'mr_fault_total' in C:
        s = sum(C.get('mr_fault_' + f, 0) for f in S.FAULT_CLASSES)
        if s != C['mr_fault_total']:
            rep.softbad('CNT ep=%s mr_fault_total=%d but the per-class counters sum to %d' % (ep, C['mr_fault_total'], s))


def check_qpst(rep, ep, x, res):
    q = [r for r in res.qpst if r['ep'] == ep]
    if not q:
        rep.bad('QPST ep=%s: no QPST line in the result' % ep)
        return
    last = q[-1]
    if last['state'] != x.qp_state:
        rep.bad('QPST ep=%s: final QP state expected %s, got %s' % (ep, x.qp_state, last['state']))


# ---------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('scenario')
    ap.add_argument('result')
    ap.add_argument('--strict', action='store_true', help='soft findings also fail')
    ap.add_argument('-v', '--verbose', action='store_true')
    ap.add_argument('--json', action='store_true', help='machine readable report')
    a = ap.parse_args(argv)
    try:
        cmds = S.parse_scn(a.scenario)
        exp = M.Model(cmds, os.path.basename(a.scenario)).run()
    except (M.ModelError, S.ScnError) as e:
        print('MODEL ERROR: %s' % e)
        return 2
    res = S.parse_res(a.result)
    rep = check(exp, res, cmds, a.strict)
    nfail = len(rep.fail) + (len(rep.soft) if a.strict else 0)
    if a.json:
        print(json.dumps({'pass': nfail == 0, 'fail': rep.fail, 'soft': rep.soft, 'notes': rep.notes, 'stats': rep.stats}, indent=1))
        return 0 if nfail == 0 else 1
    if nfail == 0:
        print('PASS')
    else:
        print('FAIL (%d mismatches)' % nfail)
    for m in rep.fail:
        print('  MISMATCH: ' + m)
    for m in rep.soft:
        print('  %s: %s' % ('MISMATCH(strict)' if a.strict else 'NOTE(soft)', m))
    if a.verbose or nfail:
        for m in rep.notes:
            print('  NOTE: ' + m)
    if a.verbose:
        print('  stats: ' + ', '.join('%s=%s' % kv for kv in sorted(rep.stats.items())))
    return 0 if nfail == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
