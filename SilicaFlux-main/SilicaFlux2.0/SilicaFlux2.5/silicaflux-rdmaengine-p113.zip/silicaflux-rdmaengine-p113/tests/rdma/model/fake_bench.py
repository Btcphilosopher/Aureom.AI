#!/usr/bin/env python3
"""fake_bench.py - turn the model's own Expectation into an *ideal* result file (spec A.2 format).

NOT a DUT model.  It exists only to self-test check_results.py (parsing, mismatch detection) and to dry-run the
generated suite (a scenario whose ideal result does not pass the checker is a bug in the model/checker/generator).

    python3 -I fake_bench.py scenario.scn out.res
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import scn as S                      # noqa: E402
import sfrt_model as M               # noqa: E402


CQE_BASE = 10_000_000          # ideal bench: every memory write is acknowledged long before any completion


def make_result_text(exp, dw=None):
    W = (dw or exp.params['dw']) // 8
    out = []
    cyc = 100
    for ep in 'AB':
        x = exp.ep[ep]
        for c in x.cfgs:
            out.append('CFG    ep=%s cmd=%s idx=0 status=%d' % (ep, c['cmd'], c['status']))
    for ep in 'AB':
        x = exp.ep[ep]
        for p in x.posts:
            out.append('POST   ep=%s wr_id=%d which=%s status=%d' % (ep, p['wr_id'], p['which'], p['status']))
    ev = []
    for ep in 'AB':
        x = exp.ep[ep]
        for r in x.sq_cqes + x.rq_cqes:
            ev.append((r['t'] + CQE_BASE, 'CQE    ep=%s cyc=%d wr_id=%d op=%d status=%d len=%d qpn=%d'
                       % (ep, r['t'] + CQE_BASE, r['wr_id'], r['op'], r['status'], r['len'], r['qpn'] or 0)))
    # memory writes: one MEMW per aligned word touched by each placement range, strobes byte exact
    for ep in 'AB':
        x = exp.ep[ep]
        t = 1
        for lo, hi, line, what, _info in x.write_log:
            a = lo - lo % W
            while a < hi:
                strb, data = 0, 0
                for k in range(W):
                    b = a + k
                    if lo <= b < hi:
                        strb |= 1 << k
                        data |= x.final_bytes.get(b, 0) << (8 * k)
                ev.append((t, 'MEMW   ep=%s cyc=%d addr=0x%X strb=0x%X data=0x%X ack=%d' % (ep, t, a, strb, data, t + 1)))
                a += W
                t += 1
        for lo, hi in x.read_env:
            a = lo - lo % W
            while a < hi:
                ev.append((t, 'MEMR   ep=%s cyc=%d addr=0x%X' % (ep, t, a)))
                a += W
                t += 1
    ev.sort(key=lambda e: e[0])
    out.extend(e[1] for e in ev)
    for ep in 'AB':
        x = exp.ep[ep]
        names = dict(x.counters)
        names.update(x.soft_counters)
        for b in x.bounds:                       # single-counter bounds first
            if 'name' in b:
                names.setdefault(b['name'], b['lo'])
        for b in x.bounds:                       # then sums: put any deficit on the first free term
            if 'terms' in b:
                cur = sum(names.get(t, 0) for t in b['terms'])
                free = [t for t in b['terms'] if t not in names]
                for t in b['terms']:
                    names.setdefault(t, 0)
                if cur < b['lo']:
                    names[(free or b['terms'])[0]] += b['lo'] - cur
        for k in ('retry_timeout', 'retry_nak', 'retry_rnr'):
            names.setdefault(k, 0)
        for n, v in sorted(names.items()):
            out.append('CNT    ep=%s name=%s value=%d' % (ep, n, v))
    for ep in 'AB':
        x = exp.ep[ep]
        out.append('QPST   ep=%s state=%s cause=%s' % (ep, x.qp_state, x.qp_cause or 'NONE'))
    for ep in 'AB':
        for d in exp.ep[ep].dumps:
            out.append('DUMP   ep=%s addr=0x%X hex=%s' % (ep, d['addr'], d['hex']))
    out.append('END    cycles=%d timeout=%d' % (cyc, 1 if exp.expect_timeout else 0))
    return '\n'.join(out) + '\n'


def main():
    scn_path, out = sys.argv[1], sys.argv[2]
    exp = M.predict(scn_path)
    with open(out, 'w') as f:
        f.write(make_result_text(exp))


if __name__ == '__main__':
    main()
