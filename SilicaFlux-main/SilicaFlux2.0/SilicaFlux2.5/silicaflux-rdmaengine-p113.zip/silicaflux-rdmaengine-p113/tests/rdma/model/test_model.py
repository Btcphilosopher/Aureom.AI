#!/usr/bin/env python3
"""Self-tests of the SFRT reference model (pure Python, no RTL needed).

Run:  python3 -I test_model.py        (or: python3 -I -m unittest test_model, from this directory)
All expected values below are hand-computed from docs/TRANSPORT_SPEC.md.
"""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'gen'))

import frames as F                                   # noqa: E402
import scn                                           # noqa: E402
import sfrt_model as M                               # noqa: E402
from scn_lib import Scn, va, pa, key, MRS, MAC, QPN  # noqa: E402

ST = scn.CQE_STATUS
CFG = scn.CFG_STATUS


def run(s, expect_clean=True):
    """s: Scn writer.  Returns (model, expectation)."""
    cmds = scn.parse_scn_text(s.text())
    m = M.Model(cmds, s.name)
    e = m.run()
    if expect_clean:
        assert not e.warnings, e.warnings
    return m, e


def cq(x):
    """(wr_id, op, status, len) tuples of a CQE list"""
    return [(r['wr_id'], r['op'], r['status'], r['len']) for r in x]


class TestScn(unittest.TestCase):
    def test_numbers_and_keys(self):
        c = scn.parse_scn_text('post_send ep=A wr_id=0x10 op=write laddr=0x1000 lkey=5 len=7 raddr=0 rkey=0 # c\n#x\n')
        self.assertEqual(c[0]['wr_id'], 16)
        self.assertEqual(c[0]['op'], 'WRITE')
        self.assertEqual(c[0]['laddr'], 4096)
        self.assertEqual(scn.parse_num('010'), 10)       # decimal, never octal

    def test_link_script_lists(self):
        c = scn.parse_scn_text('link_script dir=AB drop=1,3 dup=2 delay=4:300,5:10\n')[0]
        self.assertEqual(c['drop'], [1, 3])
        self.assertEqual(c['dup'], [2])
        self.assertEqual(c['delay'], [(4, 300), (5, 10)])

    def test_inject_hex_stays_string(self):
        c = scn.parse_scn_text('inject dir=AB hex=1234\n')[0]
        self.assertEqual(c['hex'], '1234')

    def test_integer_op(self):
        self.assertEqual(scn.parse_scn_text('post_send ep=A wr_id=1 op=15 len=1\n')[0]['op'], 15)

    def test_pattern(self):
        # hand computed: pat(0,0): x=0 -> x^=0 -> 0 ; pat(1,0): x=2654435761; x^=x>>15; x=x*2654435761 mod 2^32
        self.assertEqual(scn.pat(0, 0), 0)
        x = 2654435761
        x ^= x >> 15
        x = (x * 2654435761) & 0xFFFFFFFF
        self.assertEqual(scn.pat(1, 0), (x >> 24) & 0xFF)
        self.assertEqual(scn.pat(5, 3), scn.pat(5, 3))
        self.assertNotEqual([scn.pat(1, i) for i in range(16)], [scn.pat(2, i) for i in range(16)])

    def test_result_parse(self):
        r = scn.parse_res_text('CFG ep=A cmd=MR_SET idx=0 status=0\nPOST ep=A wr_id=5 which=SQ status=POST_OK\n'
                               'CQE ep=B cyc=10 wr_id=0x5 op=RECV status=OK len=7 qpn=2\n'
                               'MEMW ep=A cyc=3 addr=0x10 strb=0xFF data=0x0807060504030201\n'
                               'CNT ep=A name=tx_frames value=3\nQPST ep=A state=RTS cause=NONE\n'
                               'DUMP ep=A addr=0x10 hex=0102\nEND cycles=100 timeout=0\n')
        self.assertEqual(r.cqes[0]['op'], 4)
        self.assertEqual(r.cqes[0]['wr_id'], 5)
        self.assertEqual(r.posts[0]['status'], 0)
        self.assertEqual(r.memw[0]['data'], 0x0807060504030201)
        self.assertEqual(r.cnts['A']['tx_frames'], 3)
        self.assertEqual(r.dumps[0]['hex'], '0102')
        self.assertEqual(r.end['timeout'], 0)


class TestPsn(unittest.TestCase):
    def test_before(self):
        self.assertTrue(M.psn_before(5, 6))
        self.assertFalse(M.psn_before(5, 5))
        self.assertFalse(M.psn_before(6, 5))
        self.assertTrue(M.psn_before(0xFFFFFF, 0))                 # wrap: FFFFFF precedes 000000
        self.assertTrue(M.psn_before(0xFFFFF0, 0x000005))
        self.assertTrue(M.psn_before(0, 0x7FFFFF))                 # dist = 2^23-1 : before
        self.assertFalse(M.psn_before(0, 0x800000))                # dist = 2^23   : neither before nor after
        self.assertFalse(M.psn_before(0x800000, 0))
        self.assertTrue(M.psn_before(0x800001, 0))                 # dist(0x800001, 0) = 2^23-1
        self.assertTrue(M.psn_before_eq(7, 7))

    def test_dist_add(self):
        self.assertEqual(M.psn_dist(0xFFFFFE, 3), 5)
        self.assertEqual(M.psn_add(0xFFFFFF, 1), 0)
        self.assertEqual(M.psn_add(0xFFFFF0, 20), 4)

    def test_ack_valid(self):
        # una=10 nxt=14: cn=12 an=13 valid; cn=14 an=14 valid; an=15 (beyond nxt) invalid; cn>an invalid; cn<una invalid
        self.assertTrue(M.ack_valid(10, 12, 13, 14))
        self.assertTrue(M.ack_valid(10, 14, 14, 14))
        self.assertTrue(M.ack_valid(10, 10, 10, 14))
        self.assertFalse(M.ack_valid(10, 12, 15, 14))
        self.assertFalse(M.ack_valid(10, 13, 12, 14))
        self.assertFalse(M.ack_valid(10, 9, 12, 14))
        # wrap
        self.assertTrue(M.ack_valid(0xFFFFFE, 0, 1, 2))
        self.assertFalse(M.ack_valid(0xFFFFFE, 3, 3, 2))


class TestSegmentation(unittest.TestCase):
    def test_nseg(self):
        mtu = 256
        self.assertEqual(M.nseg_for(0, mtu), 1)       # zero-length SEND occupies one PSN
        self.assertEqual(M.nseg_for(1, mtu), 1)
        self.assertEqual(M.nseg_for(256, mtu), 1)
        self.assertEqual(M.nseg_for(257, mtu), 2)
        self.assertEqual(M.nseg_for(512, mtu), 2)
        self.assertEqual(M.nseg_for(3000, mtu), 12)

    def test_segments(self):
        self.assertEqual(M.segments(0, 256), [(0, 0)])
        self.assertEqual(M.segments(257, 256), [(0, 256), (256, 1)])
        s = M.segments(3000, 256)
        self.assertEqual(s[-1], (2816, 184))
        self.assertEqual(sum(p for _, p in s), 3000)


class TestRegistry(unittest.TestCase):
    def mk(self, **kw):
        P = M.Params()
        r = M.Registry(P)
        d = dict(idx=0, va=0x10000, ln=0x2000, pa=0x400, key=0xAB, pd=1, acc=0x1F, ctx=0)
        d.update(kw)
        self.assertEqual(r.mr_set(d['idx'], d['va'], d['ln'], d['pa'], d['key'], d['pd'], d['acc'], d['ctx']), 0)
        return r

    def ev(self, r, op, key=0xAB, pd=1, va=0x10000, ln=16):
        k, v = r.evaluate(op, key, pd, va, ln)
        return v if k == 'fault' else v

    def test_grant_pa(self):
        r = self.mk()
        g = self.ev(r, 3, va=0x10010, ln=32)
        self.assertEqual(g.pa, 0x400 + 0x10)

    def test_priority_key_pd_dir_perm_len(self):
        r = self.mk(acc=0x03)                        # local rights only
        self.assertEqual(self.ev(r, 3, key=0x99, pd=7, ln=0), 'bad_key')      # key beats everything
        self.assertEqual(self.ev(r, 3, pd=7, ln=0), 'bad_pd')                 # pd beats dir
        self.assertEqual(self.ev(r, 3, ln=0), 'bad_dir')                      # dir beats len
        self.assertEqual(self.ev(r, 2, ln=0), 'bad_dir')
        r2 = self.mk(acc=0x05, key=0xCD, idx=1)      # LR + RR
        self.assertEqual(self.ev(r2, 3, key=0xCD), 'bad_perm')                # has remote rights, not RW
        self.assertEqual(self.ev(r2, 1, key=0xCD), 'bad_perm')                # has local rights, not LW
        self.assertEqual(self.ev(r2, 3, key=0xCD, ln=0), 'bad_perm')          # perm beats len
        self.assertEqual(self.ev(r2, 2, key=0xCD, ln=0), 'bad_len')
        self.assertEqual(self.ev(r2, 2, key=0xCD, ln=(1 << 20) + 1), 'bad_len')
        self.assertNotEqual(self.ev(r2, 2, key=0xCD, ln=1 << 20), 'bad_len')  # = MAX is not BAD_LEN (but range)

    def test_bad_op(self):
        r = self.mk()
        self.assertEqual(self.ev(r, 4), 'bad_op')
        self.assertEqual(self.ev(r, -1), 'bad_op')

    def test_overflow_before_range(self):
        r = self.mk(va=(1 << 64) - 0x1000, ln=0x1000, key=0x77)
        va0 = (1 << 64) - 0x1000
        g = self.ev(r, 0, key=0x77, va=va0, ln=0x1000)                         # va+len == 2^64 exactly: allowed
        self.assertIsInstance(g, M.Grant)
        self.assertEqual(self.ev(r, 0, key=0x77, va=(1 << 64) - 4, ln=8), 'overflow')
        self.assertEqual(self.ev(r, 0, key=0x77, va=(1 << 64) - 1, ln=2), 'overflow')
        # wrap alias: va+len mod 2^64 would be small; must be OVERFLOW, never a grant to a low address
        r2 = self.mk(va=0, ln=0x1000, key=0x78, idx=1)
        self.assertEqual(self.ev(r2, 0, key=0x78, va=(1 << 64) - 4, ln=8), 'overflow')

    def test_range_boundaries(self):
        r = self.mk()                                                          # [0x10000, 0x12000)
        self.assertIsInstance(self.ev(r, 0, va=0x10000, ln=0x2000), M.Grant)   # whole region
        self.assertIsInstance(self.ev(r, 0, va=0x11FFF, ln=1), M.Grant)        # last byte
        self.assertEqual(self.ev(r, 0, va=0x11FFF, ln=2), 'range')             # last byte over
        self.assertEqual(self.ev(r, 0, va=0xFFFF, ln=2), 'range')              # first byte below
        self.assertEqual(self.ev(r, 0, va=0x12000, ln=1), 'range')             # above end
        self.assertEqual(self.ev(r, 0, va=0x10000, ln=0x2001), 'range')

    def test_range_one_region_only(self):
        r = self.mk(ln=0x1000)
        r.mr_set(1, 0x11000, 0x1000, 0x2000, 0xEF, 1, 0x1F, 0)                 # adjacent region, other key
        self.assertEqual(self.ev(r, 0, va=0x10F00, ln=0x200), 'range')         # spans two regions: not allowed

    def test_page_cross(self):
        r = self.mk(va=0x10000, ln=0x4000, acc=0x0F, key=0x31)                  # not CONTIG
        self.assertIsInstance(self.ev(r, 0, key=0x31, va=0x10000, ln=0x1000), M.Grant)   # exactly one page
        self.assertEqual(self.ev(r, 0, key=0x31, va=0x10FFF, ln=2), 'page_cross')
        self.assertEqual(self.ev(r, 0, key=0x31, va=0x10000, ln=0x1001), 'page_cross')
        self.assertIsInstance(self.ev(r, 0, key=0x31, va=0x10FFF, ln=1), M.Grant)
        rc = self.mk(va=0x10000, ln=0x4000, acc=0x1F, key=0x32, idx=1)           # CONTIG
        self.assertIsInstance(self.ev(rc, 0, key=0x32, va=0x10FFF, ln=2), M.Grant)

    def test_xlate_last(self):
        r = self.mk(ctx=2)
        self.assertEqual(self.ev(r, 0), 'xlate')                                # reset value 0b0001: ctx 2 not live
        r.ctx_set(0b0100)
        self.assertIsInstance(self.ev(r, 0), M.Grant)
        self.assertEqual(self.ev(r, 0, va=0x20000), 'range')                    # range beats xlate

    def test_refcnt_and_busy(self):
        r = self.mk()
        g = r.check(0, 0xAB, 1, 0x10000, 8)
        self.assertEqual(r.mrs[0].refcnt, 1)
        self.assertEqual(r.mr_inval(0), 2)                                      # ERR_BUSY
        r.release(g)
        self.assertEqual(r.mr_inval(0), 0)
        self.assertEqual(r.mr_inval(0), 7)                                      # ERR_NOENT
        self.assertEqual(r.check(0, 0xAB, 1, 0x10000, 8), 'bad_key')            # invalidated
        self.assertEqual(r.faults['bad_key'], 1)
        self.assertEqual(r.fault_total, 1)

    def test_mr_set_statuses(self):
        P = M.Params()
        r = M.Registry(P)
        self.assertEqual(r.mr_set(8, 0, 16, 0, 1, 0, 0x1F, 0), 1)               # ERR_IDX (NMR=8)
        self.assertEqual(r.mr_set(0, 0, 16, 0, 1, 0, 0x1F, 0), 0)
        self.assertEqual(r.mr_set(0, 0, 16, 0, 2, 0, 0x1F, 0), 3)               # ERR_EXISTS
        self.assertEqual(r.mr_set(1, 0, 0, 0, 3, 0, 0x1F, 0), 5)                # ERR_FIELDS len=0
        self.assertEqual(r.mr_set(1, 0, 16, 0, 3, 0, 0x3F, 0), 5)               # reserved acc bit 5
        # pd / ctx wider than the port are truncated by the port, they are NOT statuses (spec 8.2)
        self.assertEqual(r.mr_set(5, 0x500, 16, 0, 0x55, (1 << P.pd_w) + 1, 0x1F, (1 << P.ctx_w) + 2), 0)
        self.assertEqual((r.mrs[5].pd, r.mrs[5].ctx), (1, 2))
        self.assertEqual(r.mr_inval(5), 0)
        self.assertEqual(r.mr_set(1, (1 << 64) - 8, 16, 0, 3, 0, 0x1F, 0), 6)   # ERR_RANGE va wrap
        self.assertEqual(r.mr_set(1, 0, 16, (1 << P.pa_w) - 8, 3, 0, 0x1F, 0), 6)  # ERR_RANGE pa overflow
        self.assertEqual(r.mr_set(1, 0, 16, (1 << P.pa_w) - 16, 3, 0, 0x1F, 0), 0)  # exactly fits
        self.assertEqual(r.mr_set(2, 0, 16, 0, 3, 0, 0x1F, 0), 4)               # ERR_DUPKEY (key 3 valid at idx 1)
        self.assertEqual(r.mr_inval(1), 0)
        self.assertEqual(r.mr_set(2, 0, 16, 0, 3, 0, 0x1F, 0), 0)               # key free again once invalidated


class TestFrames(unittest.TestCase):
    CFGK = dict(local_mac=MAC['B'], peer_mac=MAC['A'], local_qpn=2, epoch=7)

    def req(self, **kw):
        base = dict(dst_mac=MAC['B'], src_mac=MAC['A'], opcode=F.OP_WRITE, qpn=2, epoch=7, psn=0x123456, flags=3,
                    payload=bytes(range(10)), mlen=10, moff=0, va=0x1122334455667788, rkey=0xAABBCCDD)
        base.update(kw)
        return F.build_frame(**base)

    def test_layout_offsets(self):
        d = self.req()
        self.assertEqual(len(d), 60)                                   # 48 + 10 = 58 -> padded to 60
        self.assertEqual(d[0:6], bytes.fromhex('020000000002'))
        self.assertEqual(d[6:12], bytes.fromhex('020000000001'))
        self.assertEqual(d[12:14], bytes([0x88, 0xB5]))
        self.assertEqual(d[14], 0x13)                                  # ver 1, FIRST|LAST
        self.assertEqual(d[15], 0x02)
        self.assertEqual(d[16:18], bytes([0, 2]))
        self.assertEqual(d[18:20], bytes([0, 7]))
        self.assertEqual(d[20:23], bytes([0x12, 0x34, 0x56]))
        self.assertEqual(d[23:25], bytes([0, 10]))
        self.assertEqual(d[25:29], bytes([0, 0, 0, 10]))
        self.assertEqual(d[29:33], bytes(4))
        self.assertEqual(d[33:41], bytes.fromhex('1122334455667788'))
        self.assertEqual(d[41:45], bytes.fromhex('AABBCCDD'))
        self.assertEqual(d[45:48], bytes(3))
        self.assertEqual(d[48:58], bytes(range(10)))
        self.assertEqual(d[58:60], bytes(2))

    def test_ack_nak_layout(self):
        d = F.build_frame(MAC['A'], MAC['B'], F.OP_NAK, 1, 7, 0x000010, code=F.NAK_RNR, accept_next=0x000011)
        self.assertEqual(len(d), 60)
        self.assertEqual(d[15], 0x21)
        self.assertEqual(d[20:23], bytes([0, 0, 0x10]))                # commit_next in psn field
        self.assertEqual(d[33:44], bytes(11))                          # bytes 33..43 zero
        self.assertEqual(d[44], 2)                                     # code
        self.assertEqual(d[45:48], bytes([0, 0, 0x11]))                # accept_next
        f = F.parse_frame(d)
        self.assertEqual((f['code'], f['accept_next'], f['psn']), (2, 0x11, 0x10))

    def test_roundtrip(self):
        d = self.req(payload=bytes(range(256)) * 1, mlen=256, flags=0x13 & 0x3)
        f = F.parse_frame(d)
        self.assertEqual(f['opcode'], 2)
        self.assertEqual(f['paylen'], 256)
        self.assertEqual(f['payload'], bytes(range(256)))
        self.assertEqual(f['va'], 0x1122334455667788)
        self.assertEqual(f['rkey'], 0xAABBCCDD)
        self.assertEqual(f['epoch'], 7)
        self.assertEqual(f['psn'], 0x123456)
        self.assertTrue(f['first'] and f['last'] and not f['retx'])
        self.assertEqual(F.from_hex(F.to_hex(d)), d)
        self.assertEqual(len(d), 304)

    def test_frame_len_rule(self):
        self.assertEqual(F.frame_len_rule(0), 60)
        self.assertEqual(F.frame_len_rule(12), 60)
        self.assertEqual(F.frame_len_rule(13), 61)
        self.assertEqual(F.frame_len_rule(256), 304)

    def chk(self, d):
        return F.adapter_check(d, mtu=256, **self.CFGK)[0]

    def test_adapter_ok(self):
        self.assertIsNone(self.chk(self.req()))

    def test_adapter_drops_in_order(self):
        self.assertEqual(self.chk(self.req()[:30]), 'rx_drop_len')                        # runt
        self.assertEqual(self.chk(self.req()[:47]), 'rx_drop_len')
        self.assertEqual(self.chk(self.req()[:59]), 'rx_drop_len')                        # 59 < 60 violates the rule
        self.assertEqual(self.chk(self.req() + b'\0'), 'rx_drop_len')                     # longer than the rule
        self.assertEqual(self.chk(self.req(ethertype=0x0800)), 'rx_drop_ethertype')
        self.assertEqual(self.chk(self.req(dst_mac=MAC['A'])), 'rx_drop_mac')
        self.assertEqual(self.chk(self.req(src_mac=MAC['B'])), 'rx_drop_mac')
        self.assertEqual(self.chk(self.req(ver=2)), 'rx_drop_ver')
        self.assertEqual(self.chk(self.req(flags=0x8 | 3)), 'rx_drop_ver')                # reserved flag bit
        self.assertEqual(self.chk(self.req(opcode=0x30)), 'rx_drop_opcode')
        self.assertEqual(self.chk(self.req(opcode=0x00)), 'rx_drop_opcode')
        self.assertEqual(self.chk(self.req(opcode=0x22)), 'rx_drop_opcode')
        self.assertIsNone(self.chk(self.req(opcode=0x05)))                                # reserved request: passes adapter
        self.assertIsNone(self.chk(self.req(opcode=0x0F)))
        self.assertEqual(self.chk(self.req(qpn=9)), 'rx_drop_qpn')
        self.assertEqual(self.chk(self.req(epoch=6)), 'rx_drop_epoch')

    def test_adapter_paylen_rules(self):
        big = self.req(payload=bytes(300), mlen=300)
        self.assertEqual(self.chk(big), 'rx_drop_len')                                    # paylen > MTU
        ack = F.build_frame(MAC['B'], MAC['A'], F.OP_ACK, 2, 7, 1, paylen=5, payload=bytes(5))
        self.assertEqual(self.chk(ack), 'rx_drop_len')                                    # class rule
        rd = F.build_frame(MAC['B'], MAC['A'], F.OP_READ_REQ, 2, 7, 1, flags=3, mlen=10, paylen=3, payload=bytes(3))
        self.assertEqual(self.chk(rd), 'rx_drop_len')
        lie = F.build_frame(MAC['B'], MAC['A'], F.OP_WRITE, 2, 7, 1, flags=3, mlen=100, paylen=100, payload=b'')
        self.assertEqual(len(lie), 60)
        self.assertEqual(self.chk(lie), 'rx_drop_len')                                    # header says 100, frame is 60

    def test_adapter_order(self):
        # bad ethertype AND bad epoch: ethertype is evaluated first
        self.assertEqual(self.chk(self.req(ethertype=1, epoch=99, qpn=99)), 'rx_drop_ethertype')
        self.assertEqual(self.chk(self.req(qpn=99, epoch=99)), 'rx_drop_qpn')
        self.assertEqual(self.chk(self.req(ver=3, opcode=0x30)), 'rx_drop_ver')
        # runt beats everything
        self.assertEqual(self.chk(self.req(ethertype=1)[:20]), 'rx_drop_len')

    def test_protocol_request_violation(self):
        f = F.parse_frame(self.req(opcode=0x05))
        self.assertIn('unsupported', F.protocol_request_violation(f))
        f = F.parse_frame(F.build_frame(MAC['B'], MAC['A'], F.OP_WRITE, 2, 7, 1, flags=3, mlen=0))   # WRITE paylen 0
        self.assertIsNotNone(F.protocol_request_violation(f))
        f = F.parse_frame(F.build_frame(MAC['B'], MAC['A'], F.OP_SEND, 2, 7, 1, flags=3, mlen=0))    # zero-length SEND is legal
        self.assertIsNone(F.protocol_request_violation(f))

    def test_state_accepts(self):
        self.assertFalse(F.state_accepts('RESET', 'request'))
        self.assertFalse(F.state_accepts('INIT', 'control'))
        self.assertTrue(F.state_accepts('RTR', 'request'))
        self.assertFalse(F.state_accepts('RTR', 'control'))
        self.assertFalse(F.state_accepts('RTR', 'response'))
        self.assertTrue(F.state_accepts('RTS', 'response'))
        self.assertFalse(F.state_accepts('ERR', 'request'))


class TestModelBasic(unittest.TestCase):
    def base(self, name, **kw):
        s = Scn(name)
        s.setup(**kw)
        return s

    def test_write_read_send_exactly_once(self):
        s = self.base('basic')
        s.fill('A', pa('main', 0), 0x1000, 0x11)
        s.fill('B', pa('main', 0x1000), 0x1000, 0x22)
        s.fill('B', pa('main', 0x2000), 0x1000, 0x33)
        s.fill('B', pa('main', 0x3000), 0x400, 0x44)
        s.post_recv('B', va('main', 0x3000), key('main'), 512, wr_id=77)
        s.post('A', 'WRITE', va('main', 0), key('main'), 700, va('main', 0x1000), key('main'), wr_id=1)
        s.post('A', 'READ', va('main', 0x2000), key('main'), 300, va('main', 0x2000), key('main'), wr_id=2)
        s.post('A', 'SEND', va('main', 0x100), key('main'), 400, wr_id=3)
        s.barrier()
        s.dump('B', pa('main', 0x1000), 700)
        s.dump('A', pa('main', 0x2000), 300)
        s.dump('B', pa('main', 0x3000), 400)
        m, e = run(s)
        a, b = e.ep['A'], e.ep['B']
        self.assertEqual(cq(a.sq_cqes), [(1, 2, 0, 700), (2, 3, 0, 300), (3, 1, 0, 400)])
        self.assertEqual(cq(b.rq_cqes), [(77, 4, 0, 400)])
        self.assertEqual(a.qp_state, 'RTS')
        # data: B's 0x1000.. holds A's 0x0.. pattern
        self.assertEqual(bytes.fromhex(b.dumps[0]['hex']), bytes(scn.pat(0x11, i) for i in range(700)))
        self.assertEqual(bytes.fromhex(a.dumps[0]['hex']), bytes(scn.pat(0x33, i) for i in range(300)))
        self.assertEqual(bytes.fromhex(b.dumps[1]['hex']), bytes(scn.pat(0x11, 0x100 + i) for i in range(400)))
        # exactly once
        self.assertEqual(set(b.write_counts.values()), {1})
        self.assertEqual(len(b.write_counts), 700 + 400)
        self.assertEqual(len(a.write_counts), 300)
        # envelope
        self.assertEqual(a.read_env, [(0, 700), (0x100, 0x100 + 400)] and M.merge_ranges([(0, 700), (0x100, 0x290)]))
        self.assertEqual(b.read_env, [(0x2000, 0x2000 + 300)])
        # counters
        self.assertEqual(a.counters['ops_done_write'], 1)
        self.assertEqual(a.counters['bytes_write'], 700)
        self.assertEqual(a.counters['ops_done_read'], 1)
        self.assertEqual(b.counters['ops_done_recv'], 1)
        self.assertEqual(b.counters['bytes_recv'], 400)
        self.assertEqual(a.faults['bad_key'], 0)

    def test_zero_length_send(self):
        s = self.base('zlen')
        s.post_recv('B', va('main', 0x100), key('main'), 64, wr_id=5)
        s.post('A', 'SEND', va('main', 0), key('main'), 0, wr_id=9)
        s.barrier()
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(9, 1, 0, 0)])
        self.assertEqual(cq(e.ep['B'].rq_cqes), [(5, 4, 0, 0)])
        self.assertEqual(e.ep['B'].write_counts, {})
        self.assertEqual(m.A.nxt, 0x101)                       # one PSN for a zero-length message

    def test_psn_consumption_and_wrap(self):
        s = self.base('wrap', psn_ab=0xFFFFF0)
        s.fill('A', pa('main', 0), 0x2000, 7)
        s.post('A', 'WRITE', va('main', 0), key('main'), 5120, va('main', 0x2000), key('main'), wr_id=1)   # 20 segments
        s.post('A', 'READ', va('main', 0x3000), key('main'), 64, va('main', 0x100), key('main'), wr_id=2)     # 1 PSN
        s.barrier()
        m, e = run(s)
        self.assertEqual(m.A.nxt, (0xFFFFF0 + 21) & 0xFFFFFF)
        self.assertEqual(m.B.epsn, m.A.nxt)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, 0, 5120), (2, 3, 0, 64)])

    def test_mtu_boundaries(self):
        s = self.base('mtu')
        s.fill('A', pa('main', 0), 0x2000, 9)
        off = 0x2000
        for ln in (255, 256, 257, 512, 513):
            s.post('A', 'WRITE', va('main', 0), key('main'), ln, va('main', off), key('main'))
            off += 0x400
        s.barrier()
        m, e = run(s)
        self.assertEqual([r['len'] for r in e.ep['A'].sq_cqes], [255, 256, 257, 512, 513])
        self.assertEqual(m.A.nxt, 0x100 + 1 + 1 + 2 + 2 + 3)

    def test_unaligned_send_write(self):
        s = self.base('unal')
        s.fill('A', pa('main', 0), 0x800, 3)
        s.post_recv('B', va('main', 0x1003), key('main'), 600)
        s.post('A', 'SEND', va('main', 5), key('main'), 333)
        s.post('A', 'WRITE', va('main', 0x11), key('main'), 129, va('main', 0x2007), key('main'))
        s.barrier()
        s.dump('B', pa('main', 0x1003), 333)
        m, e = run(s)
        self.assertEqual(bytes.fromhex(e.ep['B'].dumps[0]['hex']), bytes(scn.pat(3, 5 + i) for i in range(333)))
        self.assertEqual(sorted(e.ep['B'].write_counts)[0], 0x1003)

    def test_read_after_write_fence(self):
        s = self.base('raw')
        s.fill('A', pa('main', 0), 0x400, 5)
        s.fill('B', pa('main', 0x1000), 0x400, 6)
        s.post('A', 'WRITE', va('main', 0), key('main'), 300, va('main', 0x1000), key('main'))
        s.post('A', 'READ', va('main', 0x2000), key('main'), 300, va('main', 0x1000), key('main'))      # reads what was written
        s.barrier()
        s.dump('A', pa('main', 0x2000), 300)
        m, e = run(s)
        self.assertEqual(bytes.fromhex(e.ep['A'].dumps[0]['hex']), bytes(scn.pat(5, i) for i in range(300)))

    def test_conflict_lint(self):
        s = self.base('conflict')
        s.fill('A', pa('main', 0), 0x400, 5)
        s.post('A', 'READ', va('main', 0x2000), key('main'), 300, va('main', 0x1000), key('main'))
        s.post('A', 'WRITE', va('main', 0), key('main'), 300, va('main', 0x1000), key('main'))          # write after READ of same bytes
        s.barrier()
        m, e = run(s, expect_clean=False)
        self.assertTrue(any('conflicting' in w[1] for w in e.warnings))


class TestModelErrors(unittest.TestCase):
    def base(self, name, **kw):
        s = Scn(name)
        s.setup(**kw)
        return s

    def test_invalid_rkey_write(self):
        s = self.base('badkey')
        s.fill('A', pa('main', 0), 0x400, 1)
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1000), 0xDEAD, wr_id=1)
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1000), key('main'), wr_id=2)
        s.barrier()
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, ST['REM_ACCESS_ERR'], 0), (2, 2, ST['WR_FLUSH_ERR'], 0)])
        self.assertEqual(e.ep['A'].qp_state, 'ERR')
        self.assertEqual(e.ep['B'].qp_state, 'ERR')
        self.assertEqual(e.ep['B'].faults['bad_key'], 1)
        self.assertEqual(e.ep['B'].counters['mr_fault_total'], 1)
        self.assertEqual(e.ep['B'].write_counts, {})
        self.assertEqual(e.ep['A'].counters['mr_fault_total'], 0)

    def test_partial_write_then_range_fault(self):
        # region main is 0x10000 long at VA 0x10000; write 600 bytes starting 300 bytes before its end:
        # segment 0 = 256 bytes (fits), segment 1 [256,512) crosses the end -> fault; nothing of seg1/seg2 written
        s = self.base('partial')
        s.fill('A', pa('main', 0), 0x400, 1)
        s.post('A', 'WRITE', va('main', 0), key('main'), 600, va('main', 0x10000 - 300), key('main'), wr_id=1)
        s.post('A', 'WRITE', va('main', 0), key('main'), 8, va('main', 0), key('main'), wr_id=2)
        s.barrier()
        m, e = run(s)
        b = e.ep['B']
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, ST['REM_ACCESS_ERR'], 0), (2, 2, ST['WR_FLUSH_ERR'], 0)])
        self.assertEqual(sorted(b.write_counts)[0], 0x10000 - 300)
        self.assertEqual(len(b.write_counts), 256)                       # exactly segment 0
        self.assertEqual(b.faults['range'], 1)
        self.assertEqual(m.B.epsn, 0x101)                                # only segment 0 was accepted

    def test_responder_error_flushes_rq(self):
        s = self.base('rqflush')
        s.post_recv('B', va('main', 0x100), key('main'), 64, wr_id=11)
        s.post_recv('B', va('main', 0x200), key('main'), 64, wr_id=12)
        s.post('A', 'WRITE', va('main', 0), key('main'), 8, va('main', 0x1000), 0xBAD, wr_id=1)
        s.barrier()
        s.post_recv('B', va('main', 0x300), key('main'), 64, wr_id=13)            # QP in ERR: rejected
        m, e = run(s)
        self.assertEqual(cq(e.ep['B'].rq_cqes), [(11, 4, ST['WR_FLUSH_ERR'], 0), (12, 4, ST['WR_FLUSH_ERR'], 0)])
        self.assertEqual(e.ep['B'].posts[-1]['status'], 2)

    def test_send_rqe_too_small(self):
        s = self.base('rqesmall')
        s.post_recv('B', va('main', 0x100), key('main'), 100, wr_id=11)
        s.post_recv('B', va('main', 0x200), key('main'), 100, wr_id=12)
        s.post('A', 'SEND', va('main', 0), key('main'), 101, wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 1, ST['REM_OP_ERR'], 0)])
        self.assertEqual(cq(e.ep['B'].rq_cqes), [(11, 4, ST['LOC_LEN_ERR'], 0), (12, 4, ST['WR_FLUSH_ERR'], 0)])
        self.assertEqual(e.ep['B'].write_counts, {})

    def test_send_rqe_bad_lkey(self):
        s = self.base('rqeprot')
        s.post_recv('B', va('main', 0x100), 0xBEEF, 100, wr_id=11)
        s.post('A', 'SEND', va('main', 0), key('main'), 10, wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(cq(e.ep['B'].rq_cqes), [(11, 4, ST['LOC_PROT_ERR'], 0)])
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 1, ST['REM_OP_ERR'], 0)])
        self.assertEqual(e.ep['B'].faults['bad_key'], 1)

    def test_domain_isolation(self):
        s = self.base('pd')
        s.post('A', 'WRITE', va('main', 0), key('main'), 8, va('otherpd', 0), key('otherpd'), wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(e.ep['B'].faults['bad_pd'], 1)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, ST['REM_ACCESS_ERR'], 0)])

    def test_direction_and_permission(self):
        s = self.base('perm')
        s.post('A', 'WRITE', va('main', 0), key('main'), 8, va('localonly', 0), key('localonly'), wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(e.ep['B'].faults['bad_dir'], 1)
        s = self.base('perm2')
        s.post('A', 'WRITE', va('main', 0), key('main'), 8, va('rdonly', 0), key('rdonly'), wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(e.ep['B'].faults['bad_perm'], 1)

    def test_local_protection_ordering(self):
        s = self.base('locprot')
        s.fill('A', pa('main', 0), 0x400, 1)
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1000), key('main'), wr_id=1)
        s.post('A', 'WRITE', va('main', 0), 0xBAD, 64, va('main', 0x1100), key('main'), wr_id=2)
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1200), key('main'), wr_id=3)
        s.barrier()
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, 0, 64), (2, 2, ST['LOC_PROT_ERR'], 0), (3, 2, ST['WR_FLUSH_ERR'], 0)])
        self.assertEqual(e.ep['A'].faults['bad_key'], 1)
        self.assertEqual(len(e.ep['B'].write_counts), 64)               # only WQE 1 reached the wire
        self.assertEqual(e.ep['B'].qp_state, 'RTS')

    def test_local_read_dest_perm(self):
        s = self.base('locread')
        s.post('A', 'READ', va('rdonly', 0), key('rdonly'), 16, va('main', 0), key('main'), wr_id=1)   # rdonly has no LOCAL_WRITE
        s.barrier()
        m, e = run(s)
        self.assertEqual(e.ep['A'].faults['bad_perm'], 1)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 3, ST['LOC_PROT_ERR'], 0)])

    def test_page_cross_noncontig(self):
        s = self.base('pgx')
        s.post('A', 'WRITE', va('main', 0), key('main'), 100, va('paged', 0x1000 - 50), key('paged'), wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(e.ep['B'].faults['page_cross'], 1)
        s = self.base('pgx2')
        s.post('A', 'WRITE', va('main', 0), key('main'), 100, va('main', 0x1000 - 50), key('main'), wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(e.ep['B'].faults['page_cross'], 0)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, 0, 100)])

    def test_page_cross_is_per_frame(self):
        # message crosses a page boundary exactly at a segment boundary: no individual frame crosses -> OK
        s = self.base('pgx3')
        s.post('A', 'WRITE', va('main', 0), key('main'), 512, va('paged', 0x1000 - 256), key('paged'), wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, 0, 512)])

    def test_xlate_ctx_disabled(self):
        s = self.base('xlate')
        s.post('A', 'WRITE', va('main', 0), key('main'), 8, va('ctx1', 0), key('ctx1'), wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(e.ep['B'].faults['xlate'], 1)
        s = self.base('xlate2')
        s.cmd('ctx_en', ep='B', mask=3)
        s.post('A', 'WRITE', va('main', 0), key('main'), 8, va('ctx1', 0), key('ctx1'), wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(e.ep['B'].faults['xlate'], 0)

    def test_overflow_64bit(self):
        s = self.base('ovf')
        s.post('A', 'WRITE', va('main', 0), key('main'), 16, (1 << 64) - 8, key('main'), wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(e.ep['A'].posts[-1]['status'], 5)                  # POST_ERR_RANGE at post time
        self.assertEqual(e.ep['A'].sq_cqes, [])
        s = self.base('ovf2')
        # a region at the very top of VA space: access is legal when va+len == 2^64
        s.cmd('mr_inval', ep='B', idx=7)
        s.cmd('mr', ep='B', idx=7, va=(1 << 64) - 0x100, len=0x100, pa=0x1D000, key=0x77, pd=1, acc=0x1F, ctx=0)
        s.post('A', 'WRITE', va('main', 0), key('main'), 16, (1 << 64) - 16, 0x77, wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, 0, 16)])

    def test_read_fault_no_memory_read(self):
        s = self.base('rdfault')
        s.post('A', 'READ', va('main', 0), key('main'), 16, va('main', 0), 0xBAD, wr_id=1)
        s.barrier()
        m, e = run(s)
        self.assertEqual(e.ep['B'].read_env, [])                           # no memory read was issued
        self.assertEqual(e.ep['A'].write_counts, {})
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 3, ST['REM_ACCESS_ERR'], 0)])

    def test_post_statuses(self):
        s = self.base('posts')
        s.post('A', 4, 0, 0, 8, wr_id=1)                # unsupported opcode
        s.post('A', 0, 0, 0, 8, wr_id=2)
        s.post('A', 15, 0, 0, 8, wr_id=3)
        s.post('A', 'WRITE', va('main', 0), key('main'), 0, va('main', 0), key('main'), wr_id=4)         # zero-length WRITE
        s.post('A', 'READ', va('main', 0), key('main'), 0, va('main', 0), key('main'), wr_id=5)
        s.post('A', 'SEND', va('main', 0), key('main'), (1 << 20) + 1, wr_id=6)                          # > MAX_MSG
        s.post('A', 'SEND', va('main', 0), key('main'), 8, wr_id=7, flags=1)
        s.post('A', 'READ', va('main', 0), key('main'), 8, (1 << 64) - 4, key('main'), wr_id=8)         # wraps
        s.post('A', 4, 0, 0, 0, wr_id=9, flags=1)                                                         # opcode beats flags
        s.post_recv('B', (1 << 64) - 4, key('main'), 8, wr_id=10)
        s.barrier()
        m, e = run(s)
        self.assertEqual([p['status'] for p in e.ep['A'].posts], [1, 1, 1, 3, 3, 3, 4, 5, 1])
        self.assertEqual(e.ep['B'].posts[0]['status'], 5)
        self.assertEqual(e.ep['A'].counters['post_rej_opcode'], 4)
        self.assertEqual(e.ep['A'].sq_cqes, [])

    def test_post_state_checks(self):
        s = Scn('poststate')
        s.build()
        s.cmd('qp', ep='A', state='INIT', qpn=1, pd=1)
        s.post('A', 'SEND', 0, 0, 8, wr_id=1)                       # SQ not RTS: STATE (beats opcode check)
        s.post('A', 4, 0, 0, 8, wr_id=2)
        s.post_recv('A', va('main', 0), 1, 8, wr_id=3)              # RQ in INIT: allowed
        s.cmd('qp', ep='B', state='INIT', qpn=2, pd=1)
        s.cmd('qp', ep='B', state='ERR')
        s.post_recv('B', 0, 0, 8, wr_id=4)                          # ERR: rejected
        m, e = run(s)
        self.assertEqual([p['status'] for p in e.ep['A'].posts], [2, 2, 0])
        self.assertEqual([p['status'] for p in e.ep['B'].posts], [2])

    def test_qp_transitions_and_cfg_status(self):
        s = Scn('qpcfg')
        s.build()
        s.cmd('qp', ep='A', state='RTR', rqpn=2)                     # RESET -> RTR illegal
        s.cmd('qp', ep='A', state='ERR')                             # RESET -> ERR illegal
        s.cmd('qp', ep='A', state='INIT', qpn=1, pd=1)
        s.cmd('qp', ep='A', state='INIT', qpn=1, pd=1)               # INIT -> INIT illegal
        s.cmd('qp', ep='A', state='RTS', sq_psn=0, timeout=10)       # INIT -> RTS illegal
        s.cmd('qp', ep='A', state='RTR', rqpn=2, epoch=1, rq_psn=0, smac=1, dmac=2)
        s.cmd('qp', ep='A', state='ERR')                             # forced error
        s.cmd('qp', ep='A', state='ERR')                             # ERR -> ERR is fine ("any state except RESET")
        s.cmd('qp', ep='A', state='RTS', sq_psn=0, timeout=10)       # ERR -> RTS illegal
        s.cmd('qp', ep='A', state='RESET')
        m, e = run(s)
        self.assertEqual([c['status'] for c in e.ep['A'].cfgs], [8, 8, 0, 8, 8, 0, 0, 0, 8, 0])
        self.assertEqual(e.ep['A'].qp_state, 'RESET')

    def test_mr_cfg_via_scenario(self):
        s = Scn('mrcfg')
        s.build()
        s.cmd('mr', ep='A', idx=9, va=0, len=16, pa=0, key=1, pd=0, acc=0x1F, ctx=0)       # ERR_IDX
        s.cmd('mr', ep='A', idx=0, va=0, len=16, pa=0, key=1, pd=0, acc=0x1F, ctx=0)
        s.cmd('mr', ep='A', idx=0, va=0, len=16, pa=0, key=2, pd=0, acc=0x1F, ctx=0)       # ERR_EXISTS
        s.cmd('mr', ep='A', idx=1, va=0, len=16, pa=0, key=1, pd=0, acc=0x1F, ctx=0)       # ERR_DUPKEY
        s.cmd('mr_inval', ep='A', idx=3)                                                    # ERR_NOENT
        s.cmd('mr_inval', ep='A', idx=0)
        s.cmd('ctx_en', ep='A', mask=0xF)
        m, e = run(s)
        self.assertEqual([c['status'] for c in e.ep['A'].cfgs], [1, 0, 3, 4, 7, 0, 0])

    def test_mr_busy_with_stuck_op(self):
        s = self.base('busy', timeout=3000, retry=7)
        s.cmd('link_black', dir='AB', on=1)
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1000), key('main'), wr_id=1)
        s.run(300)
        s.cmd('mr_inval', ep='A', idx=0)                          # local grant of the stuck WQE is held
        s.cmd('reset', ep='A', kind='qp')                         # flush; references are cleared
        s.cmd('mr_inval', ep='A', idx=0)
        m, e = run(s)
        st = [c for c in e.ep['A'].cfgs if c['cmd'] == 'MR_INVAL']
        self.assertEqual([c['status'] for c in st], [2, 0])


class TestModelFailures(unittest.TestCase):
    def base(self, name, **kw):
        s = Scn(name)
        s.setup(**kw)
        return s

    def bound(self, x, name=None):
        """name=None: the hard (retry_timeout+retry_nak) bound; name='retry_rnr' the RNR bound; any other: by name"""
        for b in x.bounds:
            if (name and b.get('name') == name) or (name is None and b.get('terms') == ['retry_timeout', 'retry_nak']):
                return b
        return None

    def test_forward_black_retry_exc(self):
        s = self.base('blackAB', timeout=400, retry=3)
        s.fill('A', pa('main', 0), 0x400, 1)
        s.cmd('link_black', dir='AB', on=1)
        s.post('A', 'WRITE', va('main', 0), key('main'), 100, va('main', 0x1000), key('main'), wr_id=1)
        s.post('A', 'WRITE', va('main', 0), key('main'), 100, va('main', 0x1100), key('main'), wr_id=2)
        s.barrier(30000)
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, ST['RETRY_EXC_ERR'], 0), (2, 2, ST['WR_FLUSH_ERR'], 0)])
        self.assertEqual(e.ep['B'].write_counts, {})
        self.assertEqual(e.ep['A'].qp_state, 'ERR')
        b = self.bound(e.ep['A'])
        self.assertEqual((b['lo'], b['hi']), (3, 3))                    # exactly retry_max retransmissions
        self.assertFalse(e.expect_timeout)

    def test_reverse_black_remote_executed(self):
        s = self.base('blackBA', timeout=400, retry=3)
        s.fill('A', pa('main', 0), 0x400, 1)
        s.cmd('link_black', dir='BA', on=1)
        for i in range(3):
            s.post('A', 'WRITE', va('main', 0), key('main'), 100, va('main', 0x1000 + 0x100 * i), key('main'), wr_id=i + 1)
        s.barrier(30000)
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, ST['RETRY_EXC_ERR'], 0), (2, 2, ST['WR_FLUSH_ERR'], 0),
                                                 (3, 2, ST['WR_FLUSH_ERR'], 0)])
        self.assertEqual(len(e.ep['B'].write_counts), 300)              # remote memory WAS changed (11.3)
        self.assertEqual(set(e.ep['B'].write_counts.values()), {1})

    def test_reverse_black_window_limit(self):
        s = self.base('blackBA10', timeout=400, retry=2)
        s.fill('A', pa('main', 0), 0x400, 1)
        s.cmd('link_black', dir='BA', on=1)
        for i in range(10):
            s.post('A', 'WRITE', va('main', 0), key('main'), 100, va('main', 0x1000 + 0x100 * i), key('main'), wr_id=i + 1)
        s.barrier(30000)
        m, e = run(s)
        self.assertEqual(len(e.ep['B'].write_counts), 800)              # only the first WINDOW=8 PSNs left the requester

    def test_reverse_black_read_only_two_reads(self):
        s = self.base('blackBAread', timeout=400, retry=1)
        s.fill('B', pa('main', 0x1000), 0x1000, 1)
        s.cmd('link_black', dir='BA', on=1)
        for i in range(4):
            s.post('A', 'READ', va('main', 0x100 * i), key('main'), 64, va('main', 0x1000 + 0x100 * i), key('main'), wr_id=i + 1)
        s.barrier(30000)
        m, e = run(s)
        self.assertEqual(M.merge_ranges(e.ep['B'].read_env), [(0x1000, 0x1040), (0x1100, 0x1140)])   # MAX_RD = 2
        self.assertEqual(e.ep['A'].write_counts, {})                    # responses never arrived

    def test_black_recovers(self):
        s = self.base('blackrecover', timeout=1000, retry=5)
        s.fill('A', pa('main', 0), 0x400, 1)
        s.cmd('link_black', dir='AB', on=1)
        s.post('A', 'WRITE', va('main', 0), key('main'), 100, va('main', 0x1000), key('main'), wr_id=1)
        s.run(1500)                                                      # first retransmission at ~1030 is lost, next at ~3030
        s.cmd('link_black', dir='AB', on=0)
        s.barrier(30000)
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, 0, 100)])
        b = self.bound(e.ep['A'])
        self.assertEqual((b['lo'], b['hi']), (2, None))                # forced lower bound, no upper bound (A.5)
        self.assertEqual(len(e.ep['B'].write_counts), 100)

    def test_rnr_never_posted(self):
        s = self.base('rnrnever', rnr_retry=2, rnr_delay=200)
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1000), key('main'), wr_id=1)
        s.post('A', 'SEND', va('main', 0), key('main'), 64, wr_id=2)
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1100), key('main'), wr_id=3)
        s.barrier(30000)
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, 0, 64), (2, 1, ST['RNR_RETRY_EXC_ERR'], 0), (3, 2, ST['WR_FLUSH_ERR'], 0)])
        b = self.bound(e.ep['A'], 'retry_rnr')
        self.assertEqual((b['lo'], b['hi']), (2, None))                  # retry_rnr >= rnr_retry_max when exhausted; no upper bound (resets on progress, spec 9.6)
        self.assertEqual(self.bound(e.ep['A'])['lo'], 0)                 # the WRITE behind the SEND may provoke retry_nak
        self.assertIsNone(self.bound(e.ep['A'])['hi'])
        self.assertEqual(len(e.ep['B'].write_counts), 64)                # the WRITE before the SEND did land
        self.assertEqual(e.ep['B'].qp_state, 'RTS')

    def test_rnr_then_posted(self):
        s = self.base('rnrlate', rnr_retry=7, rnr_delay=200)
        s.post('A', 'SEND', va('main', 0), key('main'), 64, wr_id=2)
        s.run(500)
        s.post_recv('B', va('main', 0x100), key('main'), 128, wr_id=9)
        s.barrier(30000)
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(2, 1, 0, 64)])
        self.assertEqual(cq(e.ep['B'].rq_cqes), [(9, 4, 0, 64)])
        b = self.bound(e.ep['A'], 'retry_rnr')
        self.assertIsNone(b['hi'])                                       # no upper bound: the RNR counter resets on progress (spec 9.6)
        self.assertGreaterEqual(b['lo'], 1)

    def test_rnr_posted_in_same_batch_before(self):
        s = self.base('rnrnone')
        s.post_recv('B', va('main', 0x100), key('main'), 128, wr_id=9)
        s.post('A', 'SEND', va('main', 0), key('main'), 64, wr_id=2)
        s.barrier()
        m, e = run(s)
        b = self.bound(e.ep['A'])
        self.assertEqual((b['lo'], b['hi']), (0, 0))

    def test_unsupported_wire_opcode(self):
        # A's SEND waits (RNR); an injected reserved opcode 0x05 request carrying the same PSN is fatal INV_REQ
        s = self.base('op05')
        s.post('A', 'SEND', va('main', 0), key('main'), 64, wr_id=1)
        s.run(150)
        fr = F.build_frame(MAC['B'], MAC['A'], 0x05, QPN['B'], 1, 0x100, flags=3, mlen=0)
        s.cmd('inject', dir='AB', hex=F.to_hex(fr))
        s.barrier(30000)
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 1, ST['REM_INV_REQ_ERR'], 0)])
        self.assertEqual(e.ep['B'].qp_state, 'ERR')
        self.assertEqual(e.ep['B'].counters['rx_unsupported_op'], 1)
        self.assertEqual(e.ep['A'].qp_state, 'ERR')

    def test_inject_drop_counters(self):
        s = self.base('inj')
        good = dict(dst_mac=MAC['B'], src_mac=MAC['A'], opcode=F.OP_WRITE, qpn=2, epoch=1, psn=0x100, flags=3,
                    payload=b'abcd', mlen=4, va=va('main', 0), rkey=key('main'))
        def inj(**kw):
            d = dict(good)
            d.update(kw)
            s.cmd('inject', dir='AB', hex=F.to_hex(F.build_frame(**d)))
        inj(ethertype=0x0800)
        inj(epoch=9)
        inj(qpn=77)
        inj(dst_mac=MAC['A'])
        inj(ver=2)
        inj(opcode=0x30)
        inj(opcode=0x30)
        s.cmd('inject', dir='AB', hex=F.to_hex(F.build_frame(**good)[:20]))
        s.barrier()
        m, e = run(s)
        c = e.ep['B'].counters
        self.assertEqual((c['rx_drop_ethertype'], c['rx_drop_epoch'], c['rx_drop_qpn'], c['rx_drop_mac'], c['rx_drop_ver'],
                          c['rx_drop_opcode'], c['rx_drop_len']), (1, 1, 1, 1, 1, 2, 1))
        self.assertEqual(e.ep['B'].write_counts, {})
        self.assertEqual(e.ep['B'].qp_state, 'RTS')

    def test_stale_duplicate_does_not_overwrite(self):
        s = self.base('stale')
        s.fill('A', pa('main', 0), 0x400, 1)
        s.fill('A', pa('main', 0x400), 0x400, 2)
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1000), key('main'), wr_id=1)        # X
        s.barrier()
        s.post('A', 'WRITE', va('main', 0x400), key('main'), 64, va('main', 0x1000), key('main'), wr_id=2)    # Y, same place
        s.barrier()
        dup = F.build_frame(MAC['B'], MAC['A'], F.OP_WRITE, QPN['B'], 1, 0x100, flags=3 | 4,
                            payload=bytes(scn.pat(1, i) for i in range(64)), mlen=64, va=va('main', 0x1000), rkey=key('main'))
        s.cmd('inject', dir='AB', hex=F.to_hex(dup))
        s.barrier()
        s.dump('B', pa('main', 0x1000), 64)
        m, e = run(s)
        b = e.ep['B']
        self.assertEqual(bytes.fromhex(b.dumps[0]['hex']), bytes(scn.pat(2, i) for i in range(64)))
        self.assertEqual(set(b.write_counts.values()), {2})                                   # one write per accepted op
        self.assertEqual(b.soft_counters['rx_dup'], 1)

    def test_reset_flushes_and_reestablish(self):
        s = self.base('reset', timeout=3000, retry=7)
        s.fill('A', pa('main', 0), 0x400, 1)
        s.cmd('link_black', dir='AB', on=1)
        s.post_recv('A', va('main', 0x300), key('main'), 64, wr_id=50)
        for i in range(3):
            s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1000 + 0x100 * i), key('main'), wr_id=i + 1)
        s.run(300)
        s.cmd('reset', ep='A', kind='qp')
        s.cmd('link_black', dir='AB', on=0)
        s.cmd('reset', ep='B', kind='qp')
        s.qp_up('A', epoch=2, rq_psn=0x600, sq_psn=0x500)
        s.qp_up('B', epoch=2, rq_psn=0x500, sq_psn=0x600)
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x2000), key('main'), wr_id=10)
        s.barrier()
        stale = F.build_frame(MAC['B'], MAC['A'], F.OP_WRITE, QPN['B'], 1, 0x501, flags=3, payload=bytes(8), mlen=8,
                              va=va('main', 0x2100), rkey=key('main'))
        s.cmd('inject', dir='AB', hex=F.to_hex(stale))
        s.barrier()
        m, e = run(s)
        a, b = e.ep['A'], e.ep['B']
        self.assertEqual(cq(a.sq_cqes), [(1, 2, ST['WR_FLUSH_ERR'], 0), (2, 2, ST['WR_FLUSH_ERR'], 0),
                                         (3, 2, ST['WR_FLUSH_ERR'], 0), (10, 2, 0, 64)])
        self.assertEqual(cq(a.rq_cqes), [(50, 4, ST['WR_FLUSH_ERR'], 0)])
        self.assertEqual(a.qp_state, 'RTS')
        self.assertEqual(b.counters['rx_drop_epoch'], 1)
        self.assertEqual(len(b.write_counts), 64)                       # only the new-epoch WRITE

    def test_hard_reset_clears_registry_and_counters(self):
        s = self.base('hard', timeout=400, retry=2)
        s.fill('A', pa('main', 0), 0x400, 1)
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1000), 0xBAD, wr_id=1)      # fault counted at B
        s.barrier()
        s.cmd('reset', ep='B', kind='hard')
        s.cmd('qp', ep='A', state='RESET')
        m, e = run(s)
        b = e.ep['B']
        self.assertEqual(b.counters['mr_fault_total'], 0)               # counters cleared by the hard reset
        self.assertEqual(b.qp_state, 'RESET')
        self.assertFalse(m.B.reg.mrs[0].valid)

    def test_hard_reset_responder_then_traffic_times_out(self):
        s = self.base('hardtraffic', timeout=400, retry=2)
        s.cmd('reset', ep='B', kind='hard')
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1000), key('main'), wr_id=1)
        s.barrier(30000)
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, ST['RETRY_EXC_ERR'], 0)])
        # spec A.5: after rst_n the MAC registers are 0 -> frames count as rx_drop_mac until the endpoint is in RTR again
        self.assertTrue(any(b.get('name') == 'rx_drop_mac' and b['lo'] >= 1 for b in e.ep['B'].bounds))
        self.assertNotIn('rx_drop_mac', e.ep['B'].counters)

    def test_epoch_mismatch_is_blackhole(self):
        s = Scn('epochmismatch')
        s.build()
        s.cmd('seed', v=1)
        for ep in 'AB':
            s.mrs(ep)
        s.qp_up('A', epoch=1, rq_psn=0x200, sq_psn=0x100, timeout=300, retry=1)
        s.qp_up('B', epoch=2, rq_psn=0x100, sq_psn=0x200, timeout=300, retry=1)
        s.post('A', 'WRITE', va('main', 0), key('main'), 8, va('main', 0x1000), key('main'), wr_id=1)
        s.barrier(30000)
        m, e = run(s)
        self.assertEqual(cq(e.ep['A'].sq_cqes), [(1, 2, ST['RETRY_EXC_ERR'], 0)])
        self.assertTrue(any(b.get('name') == 'rx_drop_epoch' and b['lo'] >= 1 for b in e.ep['B'].bounds))

    def test_dump_is_snapshot_at_its_position(self):
        s = self.base('dumppos')
        s.fill('A', pa('main', 0), 0x400, 1)
        s.fill('B', pa('main', 0x8000), 0x400, 2)
        s.dump('B', pa('main', 0x8000), 64)                      # before the WRITE: still the mem_fill pattern
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x8000), key('main'), wr_id=1)
        s.barrier()
        s.dump('B', pa('main', 0x8000), 64)                      # after: the written data
        m, e = run(s)
        d = e.ep['B'].dumps
        self.assertEqual(bytes.fromhex(d[0]['hex']), bytes(scn.pat(2, i) for i in range(64)))
        self.assertEqual(bytes.fromhex(d[1]['hex']), bytes(scn.pat(1, i) for i in range(64)))

    def test_read_envelope_covers_flushed_pipelined_wqes(self):
        # spec A.5: a WQE behind a failing one may already have been read; its source buffer is in the read envelope,
        # the writes stay exact (nothing of it is written)
        s = self.base('envelope')
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x8000), 0xBAD, wr_id=1)           # remote fault
        s.post('A', 'WRITE', va('main', 0x100), key('main'), 64, va('main', 0x8100), key('main'), wr_id=2)  # flushed
        s.post('A', 'SEND', va('main', 0x200), key('main'), 64, wr_id=3)                                   # flushed
        s.post('A', 'WRITE', va('main', 0x300), 0xBAD, 64, va('main', 0x8200), key('main'), wr_id=4)       # local check fails
        s.barrier()
        m, e = run(s)
        self.assertEqual(M.merge_ranges(e.ep['A'].read_env), [(0, 64), (0x100, 0x140), (0x200, 0x240)])
        self.assertEqual(e.ep['B'].write_counts, {})

    def test_timing_lint_post_then_black(self):
        s = self.base('lint')
        s.post('A', 'WRITE', va('main', 0), key('main'), 64, va('main', 0x1000), key('main'), wr_id=1)
        s.cmd('link_black', dir='AB', on=1)                              # same instant as the post: timing dependent
        s.barrier(30000)
        m, e = run(s, expect_clean=False)
        self.assertTrue(e.warnings)

    def test_bidirectional_disjoint(self):
        s = self.base('bidir')
        s.fill('A', pa('main', 0), 0x800, 1)
        s.fill('B', pa('main', 0), 0x800, 2)
        for i in range(4):
            s.post('A', 'WRITE', va('main', 0x100 * i), key('main'), 200, va('main', 0x2000 + 0x100 * i), key('main'))
            s.post('B', 'WRITE', va('main', 0x100 * i), key('main'), 200, va('main', 0x2000 + 0x100 * i), key('main'))
        s.barrier()
        m, e = run(s)
        self.assertEqual(len(e.ep['A'].sq_cqes), 4)
        self.assertEqual(len(e.ep['B'].sq_cqes), 4)
        self.assertEqual(len(e.ep['A'].write_counts), 800)
        self.assertEqual(set(e.ep['A'].write_counts.values()), {1})


class TestChecker(unittest.TestCase):
    """mutation tests: an ideal result passes; every single deliberate defect is detected and reported precisely"""

    @classmethod
    def setUpClass(cls):
        import check_results as C
        import fake_bench
        cls.C, cls.fb = C, fake_bench
        s = Scn('chk')
        s.setup()
        s.fill('A', pa('main', 0), 0x1000, 0x11)
        s.fill('B', pa('main', 0x1000), 0x1000, 0x22)
        s.fill('B', pa('main', 0x2000), 0x1000, 0x33)
        s.post_recv('B', va('main', 0x3000), key('main'), 512, wr_id=77)
        s.post('A', 'WRITE', va('main', 3), key('main'), 701, va('main', 0x1005), key('main'), wr_id=1)   # unaligned both ends
        s.post('A', 'READ', va('main', 0x2000), key('main'), 300, va('main', 0x2003), key('main'), wr_id=2)
        s.post('A', 'SEND', va('main', 0x100), key('main'), 400, wr_id=3)
        s.barrier()
        s.dump('B', pa('main', 0x1005), 701)
        s.dump('A', pa('main', 0x2000), 300)
        cls.cmds = scn.parse_scn_text(s.text())
        cls.exp = M.Model(cls.cmds, 'chk').run()
        cls.text = fake_bench.make_result_text(cls.exp)

    def go(self, text=None, mutate=None):
        t = self.text if text is None else text
        if mutate:
            t = mutate(t)
        return self.C.check(self.exp, scn.parse_res_text(t), self.cmds)

    def lines(self, t):
        return t.split('\n')

    def assertFails(self, rep, *needles):
        blob = '\n'.join(rep.fail)
        self.assertTrue(rep.fail, 'checker did not detect the defect')
        for n in needles:
            self.assertIn(n, blob)

    def test_ideal_passes(self):
        rep = self.go()
        self.assertEqual(rep.fail, [])
        self.assertEqual(rep.soft, [])

    def test_cqe_status(self):
        def mut(t):
            out, done = [], False
            for l in self.lines(t):
                if not done and l.startswith('CQE') and 'ep=A' in l and 'wr_id=2' in l:
                    l = l.replace('status=0', 'status=7')
                    done = True
                out.append(l)
            return '\n'.join(out)
        self.assertFails(self.go(mutate=mut), 'CQE ep=A SQ #2', 'RETRY_EXC_ERR')

    def test_cqe_missing_and_extra(self):
        rep = self.go(mutate=lambda t: '\n'.join(l for l in self.lines(t) if not (l.startswith('CQE') and 'wr_id=77' in l)))
        self.assertFails(rep, 'missing CQE')
        rep = self.go(mutate=lambda t: t + 'CQE    ep=A cyc=9 wr_id=5 op=2 status=0 len=1 qpn=1\n')
        self.assertFails(rep, 'unexpected extra CQE')

    def test_cqe_order(self):
        def mut(t):
            ls = self.lines(t)
            idx = [i for i, l in enumerate(ls) if l.startswith('CQE') and 'ep=A' in l]
            ls[idx[0]], ls[idx[1]] = ls[idx[1]], ls[idx[0]]
            return '\n'.join(ls)
        self.assertFails(self.go(mutate=mut), 'CQE ep=A SQ #1')

    def test_missing_write_word(self):
        def mut(t):
            ls = self.lines(t)
            i = [k for k, l in enumerate(ls) if l.startswith('MEMW') and 'ep=B' in l][3]
            del ls[i]
            return '\n'.join(ls)
        self.assertFails(self.go(mutate=mut), 'MEMW ep=B', 'written 0 time(s), expected 1', 'WRITE wr_id=1')

    def test_double_write(self):
        def mut(t):
            ls = self.lines(t)
            i = [k for k, l in enumerate(ls) if l.startswith('MEMW') and 'ep=B' in l][3]
            ls.insert(i, ls[i])
            return '\n'.join(ls)
        self.assertFails(self.go(mutate=mut), 'written 2 time(s), expected 1')

    def test_write_outside_envelope(self):
        rep = self.go(mutate=lambda t: t + 'MEMW   ep=B cyc=9 addr=0x6000 strb=0x1 data=0x5\n')
        self.assertFails(rep, 'OUTSIDE every authorised write window')

    def test_strobe_byte_exactness(self):
        # the last partial word write has its strobe widened by one byte: one byte too many is written
        def mut(t):
            ls = self.lines(t)
            ws = [k for k, l in enumerate(ls) if l.startswith('MEMW') and 'ep=B' in l]
            k = ws[0]                                    # first B word: PA 0x1000, bytes from 0x1005 on (unaligned start)
            self.assertIn('strb=0xE0', ls[k])
            ls[k] = ls[k].replace('strb=0xE0', 'strb=0xF0')
            return '\n'.join(ls)
        self.assertFails(self.go(mutate=mut), 'PA [0x1004..0x1004]', 'written 1 time(s), expected 0')

    def test_data_value(self):
        def mut(t):
            ls = self.lines(t)
            k = [k for k, l in enumerate(ls) if l.startswith('MEMW') and 'ep=B' in l][5]
            ls[k] = ls[k].rsplit('data=0x', 1)[0] + 'data=0x0'
            return '\n'.join(ls)
        self.assertFails(self.go(mutate=mut), 'data written differs')

    def test_read_outside_envelope(self):
        rep = self.go(mutate=lambda t: t + 'MEMR   ep=A cyc=9 addr=0x7000\n')
        self.assertFails(rep, 'MEMR ep=A', 'outside every authorised read window')

    def test_read_word_granularity(self):
        # WRITE source starts at PA 3: the aligned word 0 overlaps the legal range and must be accepted
        rep = self.go(mutate=lambda t: t + 'MEMR   ep=A cyc=9 addr=0x0\n')
        self.assertEqual(rep.fail, [])
        # but the word just before a served READ range [0x2000..] is not legal on B
        rep = self.go(mutate=lambda t: t + 'MEMR   ep=B cyc=9 addr=0x1FF8\n')
        self.assertFails(rep, 'MEMR ep=B')
        rep = self.go(mutate=lambda t: t + 'MEMR   ep=B cyc=9 addr=0x2000\n')
        self.assertEqual(rep.fail, [])

    def test_unaligned_word_address(self):
        rep = self.go(mutate=lambda t: t + 'MEMR   ep=B cyc=9 addr=0x2001\n')
        self.assertFails(rep, 'not aligned')

    def test_dump(self):
        def mut(t):
            return t.replace('DUMP   ep=A addr=0x2000 hex=', 'DUMP   ep=A addr=0x2000 hex=ff', 1)
        self.assertFails(self.go(mutate=mut), 'DUMP ep=A')
        def mut2(t):
            ls = self.lines(t)
            k = [k for k, l in enumerate(ls) if l.startswith('DUMP   ep=B')][0]
            h = ls[k].split('hex=')[1]
            h2 = h[:20] + ('00' if h[20:22] != '00' else '01') + h[22:]
            ls[k] = ls[k].split('hex=')[0] + 'hex=' + h2
            return '\n'.join(ls)
        self.assertFails(self.go(mutate=mut2), '1 byte(s) differ', 'offset 10')

    def test_counter(self):
        rep = self.go(mutate=lambda t: t.replace('name=mr_fault_range value=0', 'name=mr_fault_range value=1', 1))
        self.assertFails(rep, 'mr_fault_range')

    def test_missing_counter(self):
        rep = self.go(mutate=lambda t: '\n'.join(l for l in self.lines(t) if 'name=ops_done_write' not in l))
        self.assertFails(rep, 'ops_done_write', 'not reported')

    def test_retry_bound_clean_link(self):
        rep = self.go(mutate=lambda t: t.replace('ep=A name=retry_timeout value=0', 'ep=A name=retry_timeout value=1', 1))
        self.assertFails(rep, 'retry_timeout')

    def test_qpst(self):
        rep = self.go(mutate=lambda t: t.replace('QPST   ep=A state=RTS', 'QPST   ep=A state=ERR'))
        self.assertFails(rep, 'QPST ep=A', 'expected RTS')

    def test_no_end(self):
        rep = self.go(mutate=lambda t: '\n'.join(l for l in self.lines(t) if not l.startswith('END')))
        self.assertFails(rep, 'no END line')

    def test_timeout_flag(self):
        rep = self.go(mutate=lambda t: t.replace('timeout=0', 'timeout=1'))
        self.assertFails(rep, 'END timeout=1')

    def _early_cqe(self, ep, wr_id, op):
        import re

        def mut(t):
            out = []
            for l in self.lines(t):
                if l.startswith('CQE') and 'ep=%s ' % ep in l and ' wr_id=%d ' % wr_id in l and ' op=%d ' % op in l:
                    l = re.sub(r'cyc=\d+', 'cyc=5', l)
                out.append(l)
            return '\n'.join(out)
        return mut

    def test_commit_before_completion_write(self):
        rep = self.go(mutate=self._early_cqe('A', 1, 2))
        self.assertFails(rep, 'COMMIT ep=A SQ CQE wr_id=1 op=WRITE', 'acknowledged at cycle')

    def test_commit_before_completion_read(self):
        rep = self.go(mutate=self._early_cqe('A', 2, 3))
        self.assertFails(rep, 'COMMIT ep=A SQ CQE wr_id=2 op=READ')

    def test_commit_before_completion_send_and_recv(self):
        rep = self.go(mutate=self._early_cqe('A', 3, 1))
        self.assertFails(rep, 'COMMIT ep=A SQ CQE wr_id=3 op=SEND')
        rep = self.go(mutate=self._early_cqe('B', 77, 4))
        self.assertFails(rep, 'COMMIT ep=B RQ CQE wr_id=77 op=RECV')

    def test_commit_late_ack_of_one_word(self):
        # a single word of the WRITE's data is acknowledged after the WQE completed
        def mut(t):
            ls = self.lines(t)
            k = [k for k, l in enumerate(ls) if l.startswith('MEMW') and 'ep=B' in l][2]
            ls[k] = ls[k].rsplit('ack=', 1)[0] + 'ack=99999999999'
            return '\n'.join(ls)
        self.assertFails(self.go(mutate=mut), 'COMMIT ep=A SQ CQE wr_id=1 op=WRITE')

    def test_post_and_cfg_status(self):
        rep = self.go(mutate=lambda t: t.replace('wr_id=1 which=SQ status=0', 'wr_id=1 which=SQ status=2', 1))
        self.assertFails(rep, 'POST ep=A SQ wr_id=1')
        rep = self.go(mutate=lambda t: t.replace('CFG    ep=B cmd=MR_SET idx=0 status=0', 'CFG    ep=B cmd=MR_SET idx=0 status=3', 1))
        self.assertFails(rep, 'CFG ep=B MR_SET', 'ERR_EXISTS')


class TestExpectationJson(unittest.TestCase):
    def test_json_roundtrip(self):
        import json
        s = Scn('json')
        s.setup()
        s.post('A', 'WRITE', va('main', 0), key('main'), 8, va('main', 0x1000), key('main'))
        s.barrier()
        m, e = run(s)
        d = json.loads(e.to_json())
        self.assertEqual(d['ep']['A']['sq_cqes'][0]['status'], 0)


if __name__ == '__main__':
    unittest.main(verbosity=1)
