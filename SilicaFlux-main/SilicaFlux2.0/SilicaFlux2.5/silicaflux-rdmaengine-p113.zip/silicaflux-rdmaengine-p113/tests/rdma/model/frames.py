#!/usr/bin/env python3
"""frames.py - independent SFRT frame builder / parser / adapter-level validator (spec section 3).

Written from docs/TRANSPORT_SPEC.md only.  Frame = 14 B Ethernet header + 34 B SFRT header + payload
(frame bytes 0..47 are the 48-byte prefix; payload starts at byte 48).  All multi-byte fields are
big-endian by byte position.
"""

ETHERTYPE = 0x88B5
HDR_BYTES = 48
MIN_FRAME = 60

OP_SEND = 0x01
OP_WRITE = 0x02
OP_READ_REQ = 0x03
OP_READ_RESP = 0x10
OP_ACK = 0x20
OP_NAK = 0x21

FLAG_FIRST = 0x01
FLAG_LAST = 0x02
FLAG_RETX = 0x04
FLAG_RSVD = 0x08

NAK_SEQ_ERR = 1
NAK_RNR = 2
NAK_INV_REQ = 3
NAK_REM_ACCESS = 4
NAK_REM_OP = 5

OPCODE_NAMES = {0x01: 'SEND', 0x02: 'WRITE', 0x03: 'READ_REQ', 0x10: 'READ_RESP', 0x20: 'ACK', 0x21: 'NAK'}


def is_request_opcode(op):
    """supported (1..3) or reserved (4..0xF) request opcodes."""
    return 0x01 <= op <= 0x0F


def opcode_known(op):
    """opcode listed in spec 3.3 (anything else is malformed -> rx_drop_opcode)."""
    return (0x01 <= op <= 0x0F) or op in (0x10, 0x20, 0x21)


def opcode_class(op):
    if 0x01 <= op <= 0x0F:
        return 'request'
    if op == 0x10:
        return 'response'
    if op in (0x20, 0x21):
        return 'control'
    return None


def mac_bytes(m):
    return int(m).to_bytes(6, 'big')


def frame_len_rule(paylen):
    """spec 3.2: frame_len = max(60, 48 + paylen)."""
    return max(MIN_FRAME, HDR_BYTES + paylen)


def build_frame(dst_mac, src_mac, opcode, qpn, epoch, psn, flags=0, ver=1, payload=b'', paylen=None,
                mlen=0, moff=0, va=0, rkey=0, code=0, accept_next=0, ethertype=ETHERTYPE, pad=True):
    """Build a frame exactly as the spec's sender would (reserved bytes 0, padded to 60).

    For ACK/NAK the va/rkey bytes 33..43 are 0, byte 44 = `code`, bytes 45..47 = `accept_next`.
    `paylen` defaults to len(payload) (override to craft inconsistent frames)."""
    payload = bytes(payload)
    if paylen is None:
        paylen = len(payload)
    b = bytearray()
    b += mac_bytes(dst_mac)
    b += mac_bytes(src_mac)
    b += int(ethertype).to_bytes(2, 'big')
    b.append(((ver & 0xF) << 4) | (flags & 0xF))
    b.append(opcode & 0xFF)
    b += int(qpn).to_bytes(2, 'big')
    b += int(epoch).to_bytes(2, 'big')
    b += int(psn & 0xFFFFFF).to_bytes(3, 'big')
    b += int(paylen).to_bytes(2, 'big')
    b += int(mlen).to_bytes(4, 'big')
    b += int(moff).to_bytes(4, 'big')
    if opcode in (OP_ACK, OP_NAK):
        b += bytes(8)                     # 33..40
        b += bytes(3)                     # 41..43
        b.append(code & 0xFF)             # 44
        b += int(accept_next & 0xFFFFFF).to_bytes(3, 'big')   # 45..47
    else:
        b += int(va).to_bytes(8, 'big')
        b += int(rkey).to_bytes(4, 'big')
        b += bytes(3)                     # 45..47 reserved
    assert len(b) == HDR_BYTES, len(b)
    b += payload
    if pad and len(b) < MIN_FRAME:
        b += bytes(MIN_FRAME - len(b))
    return bytes(b)


def segment_flags(moff, paylen, mlen, retx=False):
    f = 0
    if moff == 0:
        f |= FLAG_FIRST
    if moff + paylen == mlen:
        f |= FLAG_LAST
    if retx:
        f |= FLAG_RETX
    return f


def parse_frame(data):
    """Field extraction without any validation.  Returns None if the frame is shorter than 48 bytes."""
    d = bytes(data)
    if len(d) < HDR_BYTES:
        return None
    f = {
        'len': len(d),
        'dst_mac': int.from_bytes(d[0:6], 'big'),
        'src_mac': int.from_bytes(d[6:12], 'big'),
        'ethertype': int.from_bytes(d[12:14], 'big'),
        'ver': d[14] >> 4,
        'flags': d[14] & 0xF,
        'rsvd_flag': bool(d[14] & 0x8),
        'retx': bool(d[14] & 0x4),
        'last': bool(d[14] & 0x2),
        'first': bool(d[14] & 0x1),
        'opcode': d[15],
        'qpn': int.from_bytes(d[16:18], 'big'),
        'epoch': int.from_bytes(d[18:20], 'big'),
        'psn': int.from_bytes(d[20:23], 'big'),
        'paylen': int.from_bytes(d[23:25], 'big'),
        'mlen': int.from_bytes(d[25:29], 'big'),
        'moff': int.from_bytes(d[29:33], 'big'),
        'va': int.from_bytes(d[33:41], 'big'),
        'rkey': int.from_bytes(d[41:45], 'big'),
        'code': d[44],
        'accept_next': int.from_bytes(d[45:48], 'big'),
        'payload': d[HDR_BYTES:HDR_BYTES + int.from_bytes(d[23:25], 'big')],
    }
    return f


def adapter_check(data, local_mac, peer_mac, local_qpn, epoch, mtu=256, keep_ok=True, rx_err=False):
    """Spec 3.4 adapter-level validation, evaluation order as listed (first match counted).

    Returns (counter_name_or_None, fields_or_None).  The QP-state check (rx_drop_state) is NOT done here:
    it is the last step and depends on the QP state (see QP-state helpers in the model)."""
    d = bytes(data)
    # 1. runt / length rule
    if len(d) < HDR_BYTES:
        return 'rx_drop_len', None
    f = parse_frame(d)
    if len(d) != frame_len_rule(f['paylen']):
        return 'rx_drop_len', f
    # 2. keep / 3. macerr (cannot be expressed on the wire; kept for completeness)
    if not keep_ok:
        return 'rx_drop_keep', f
    if rx_err:
        return 'rx_drop_macerr', f
    # 4. ethertype
    if f['ethertype'] != ETHERTYPE:
        return 'rx_drop_ethertype', f
    # 5. macs
    if f['dst_mac'] != local_mac or f['src_mac'] != peer_mac:
        return 'rx_drop_mac', f
    # 6. version / reserved flag
    if f['ver'] != 1 or f['rsvd_flag']:
        return 'rx_drop_ver', f
    # 7. opcode
    if not opcode_known(f['opcode']):
        return 'rx_drop_opcode', f
    # 8. paylen > MTU or class rule on paylen (ACK, NAK, READ_REQ must have paylen = 0)
    if f['paylen'] > mtu:
        return 'rx_drop_len', f
    if f['opcode'] in (OP_ACK, OP_NAK, OP_READ_REQ) and f['paylen'] != 0:
        return 'rx_drop_len', f
    # 9. qpn
    if f['qpn'] != local_qpn:
        return 'rx_drop_qpn', f
    # 10. epoch
    if f['epoch'] != epoch:
        return 'rx_drop_epoch', f
    return None, f


def state_accepts(state, opclass):
    """spec 5.2: does a QP in `state` hand a frame of class opclass to the protocol engine?
    (ERR is handled separately by NAK replay.)"""
    if state in ('RESET', 'INIT'):
        return False
    if state == 'RTR':
        return opclass == 'request'
    if state == 'RTS':
        return True
    return False


def protocol_request_violation(f, max_msg=1 << 20):
    """spec 7.4 (1, 2) for a request frame that survived the adapter: returns a reason string if the
    in-order request is a fatal INV_REQ, else None.  Rule 3 (SEND continuation) needs responder state and is
    not evaluated here."""
    op = f['opcode']
    if not (OP_SEND <= op <= OP_READ_REQ):
        return 'unsupported opcode 0x%02X' % op
    if f['moff'] + f['paylen'] > f['mlen']:
        return 'moff+paylen > mlen'
    if f['first'] != (f['moff'] == 0):
        return 'FIRST != (moff==0)'
    if op in (OP_SEND, OP_WRITE) and f['last'] != (f['moff'] + f['paylen'] == f['mlen']):
        return 'LAST != (moff+paylen==mlen)'
    if op == OP_READ_REQ:
        if not f['last'] or f['paylen'] != 0 or not f['moff'] < f['mlen']:
            return 'READ_REQ rule'
    if op == OP_WRITE and f['paylen'] < 1:
        return 'WRITE paylen < 1'
    if f['mlen'] > max_msg:
        return 'mlen > MAX_MSG_BYTES'
    return None


def to_hex(data):
    return bytes(data).hex()


def from_hex(s):
    s = s.strip()
    if s[:2] in ('0x', '0X'):
        s = s[2:]
    return bytes.fromhex(s)


# ---------------------------------------------------------------------------
# Higher level helpers used by the generators (frames sent by endpoint `src` towards `dst`)
# ---------------------------------------------------------------------------
class Peer:
    """Addressing of a connection as seen by the sender of a crafted frame."""

    def __init__(self, src_mac, dst_mac, dst_qpn, epoch):
        self.src_mac = src_mac
        self.dst_mac = dst_mac
        self.dst_qpn = dst_qpn
        self.epoch = epoch


def request_frame(peer, kind, psn, **kw):
    """kind in SEND/WRITE/READ_REQ (or an int opcode).  kw: payload, mlen, moff, va, rkey, flags, epoch, qpn ..."""
    opcode = {'SEND': OP_SEND, 'WRITE': OP_WRITE, 'READ': OP_READ_REQ, 'READ_REQ': OP_READ_REQ}.get(kind, kind)
    payload = kw.pop('payload', b'')
    mlen = kw.pop('mlen', len(payload))
    moff = kw.pop('moff', 0)
    flags = kw.pop('flags', None)
    paylen = kw.pop('paylen', None)
    pl = len(payload) if paylen is None else paylen
    if flags is None:
        if opcode == OP_READ_REQ:
            flags = (FLAG_FIRST if moff == 0 else 0) | FLAG_LAST
        else:
            flags = segment_flags(moff, pl, mlen)
    epoch = kw.pop('epoch', peer.epoch)
    qpn = kw.pop('qpn', peer.dst_qpn)
    return build_frame(kw.pop('dst_mac', peer.dst_mac), kw.pop('src_mac', peer.src_mac), opcode, qpn, epoch, psn,
                       flags=flags, payload=payload, paylen=paylen, mlen=mlen, moff=moff, **kw)


def ack_frame(peer, commit_next, accept_next, code=0, nak=False, **kw):
    return build_frame(kw.pop('dst_mac', peer.dst_mac), kw.pop('src_mac', peer.src_mac),
                       OP_NAK if nak else OP_ACK, kw.pop('qpn', peer.dst_qpn), kw.pop('epoch', peer.epoch),
                       commit_next, code=code, accept_next=accept_next, **kw)
