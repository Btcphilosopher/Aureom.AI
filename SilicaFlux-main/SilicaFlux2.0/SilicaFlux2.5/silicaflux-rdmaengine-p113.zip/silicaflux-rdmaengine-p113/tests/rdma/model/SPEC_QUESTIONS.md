# SPEC_QUESTIONS - ambiguities met while writing the independent SFRT reference model

Each entry: **section**, the ambiguity, what the model/generators implement (the most literal reading).
`[resolved]` = the coordinator has since clarified it in `docs/TRANSPORT_SPEC.md`; kept for the record.
`[observed]` = the RTL/bench behaves in a way that shows how it was understood (not a verdict).

## Frame format / adapter (3.x)
1. **3.4, state check vs attribute checks.** The list ends "If the QP is not in a state that accepts the frame it is counted in
   `rx_drop_state`"; for RESET/INIT the MAC/QPN/epoch registers are not (or no longer) configured, so the order is ambiguous.
   `[resolved, A.5]` after rst_n the MAC registers are 0 -> `rx_drop_mac` until RTR. Implemented so. After a *QP reset* (not
   rst_n) it is not said whether the attributes survive: the model only asserts `rx_drop_state + rx_drop_mac + rx_drop_qpn +
   rx_drop_epoch >= 1` there.
2. **3.2/3.4, frames of 48..59 bytes and over-long frames.** Read literally (`frame_len == max(60, 48+paylen)`), a 59-byte frame and a
   frame longer than the rule are both malformed -> `rx_drop_len`. Implemented (scenario `inject_malformed_frames`).
3. **3.4, `rx_drop_keep` / `rx_drop_macerr`.** Cannot be produced by the scenario language (`inject` has no keep/err control); the
   model predicts exactly 0 for them.
4. **3.4, `rx_drop_len` for an ACK-shaped frame with `paylen != 0` vs `rx_drop_opcode`.** Order as listed: opcode first, then the
   class rule on `paylen`. Implemented.

## Queue pair / posting (5.x, 6.x)
5. **5.1, invalid attribute values** (`timeout = 0`, `retry_max > 15`, `rnr_retry_max > 15`, `rnr_delay` huge): no status is defined
   (ERR_STATE is only for illegal transitions). Model: accepted (OK); not exercised by the suite.
6. **5.1/11.5, which QP attributes survive a QP reset.** "clear all QP state" - qpn/pd/epoch/MACs are attributes, not state?
   Model: irrelevant for traffic (the agent re-programs them), only matters for item 1.
7. **6.3, RQ post `LEN`.** The `POST_ERR_LEN` row (`len > MAX_MSG_BYTES`) is not restricted to the SQ. Implemented for both queues;
   RQ `len = 0` accepted; RQ has no FIELDS/OPCODE check. (`post_status_matrix`)
8. **6.3, evaluation order for an RQ post.** STATE, LEN, RANGE (the SQ-only rows skipped). Implemented.
9. **6.3, `raddr + len == 2^64`** is legal at the port (`>` is the error) and then fails the remote registry check with RANGE
   (not OVERFLOW). Implemented (`post_range_exact_2_64_boundary`).

## Operations (7.x)
10. **7.1, receive-side registry check covers `rqe.len`, not `mlen`.** An RQE that exceeds its region fails for even a tiny SEND; the
    check is skipped only for `rqe.len = 0` (a zero-length message into a non-empty RQE is still checked). Order: `mlen > rqe.len`
    (LOC_LEN_ERR) before the registry check. Implemented literally (`rqe_larger_than_region`, `send_zero_len`).
11. **7.2, partial effect of a failing multi-frame WRITE.** Frames before the failing frame are committed and stay in memory
    ("no byte of that frame, nor of any later frame, is written"); 11.3 calls the effect "unknown" after a transport failure but a
    REM_ACCESS failure is deterministic. Model predicts the earlier segments written exactly once (`write_range_multiseg_partial`).
12. **7.3/9.5(6), a READ that precedes a fatal NAK.** If the fatal NAK overtakes the earlier READ's response data, does the READ
    still complete OK? Not stated in the first draft. Generators put a `barrier` between READs and a following faulting WQE in
    directed and random fault scenarios. **RESOLVED after the independent review (spec 9.5(6)):** the READ's data is still
    delivered (the fatal NAK only stops *issuing*); if a response frame is lost it cannot be recovered (a fatal-mode responder never
    re-executes a READ), the READ ends `RETRY_EXC_ERR` after its retries and the faulty WQE is flushed. The op-level model still
    cannot predict that interleaving; it is covered by `tests/rdma/review/rv01*.scn` with explicit expectations (spec A.6).
13. **7.4/9.5(6), fatal NAK for a PSN that no WQE owns** (e.g. an injected reserved-opcode request when the requester is idle):
    "the WQE owning it completes ... then the QP enters ERR" has no WQE to complete. Model/generators avoid it: the requester
    holds a SEND stuck in RNR wait with the same PSN (`wire_*` scenarios), so the NAK has an owner.
14. **7.3 / 9.1, window accounting of a READ.** READ = 1 PSN, but is its window slot released at commit of the request or when the
    response data is placed? Matters only for how many PSNs leave a requester whose ACKs never return; the model keeps such
    scenarios within `WINDOW` PSNs and `MAX_RD` reads.

## Registry (8.x)
15. **8.2, MR_SET status precedence** `[resolved]`: IDX, EXISTS, FIELDS, RANGE, DUPKEY, first match wins. `pd`/`ctx` wider than the
    port are truncated by the port and are **not** statuses (model truncates to PD_W/CTX_W/8 bits).
16. **8.1/8.2, parameters that the spec does not give.** `PD_W`, `CTX_W`, `PA_W`, `CQ_DEPTH`, `RQ_DEPTH`, `MAX_RD` default, `NMR`.
    Model defaults: PD_W=4, CTX_W=2, PA_W=32, NMR=8, MAX_RD=2, WINDOW=8, MAX_MSG_BYTES=1 MiB, PAGE_BYTES=4096; all can be changed on
    the `build` line. Only `PA_W` (ERR_RANGE) and `CQ_DEPTH` (`cq_credit_exhaustion`) are exercised by directed scenarios.
17. **8.3, page-cross granularity.** Responder: per frame `(va, paylen)` (and whole range for READ); requester local check: the whole
    `len`. So a >4 KiB local buffer in a non-CONTIG region can never pass its local check although each segment would pass at the
    responder. Implemented literally (`page_cross_ok_cases`, `page_cross_local_noncontig`).
18. **8.4, which references are observable through `ERR_BUSY`.** Only the requester's local grant of an issued, unretired WQE
    (stuck behind a black link) is modelled; responder grants are released before a command can observe them.
    Scenario `mr_busy_with_stuck_wqe`. After a QP reset the references are cleared (11.5).
19. **9.3, `rx_dup_read_fault`** is named in the text but absent from the counter list in 15; whether the failed re-check also
    increments `mr_fault_*` is not said. Model: no fault counters for duplicate READs (no scenario makes one fail).

## Sequencing, retry, errors (9.x, 11.x)
20. **9.6, timer while waiting out `rnr_delay`.** Is the retransmission timer stopped during an RNR wait? Does an RNR NAK count as
    progress? Not stated. Suite uses `timeout >= 3000` with `rnr_delay <= 400` so the question does not arise.
21. **9.6, what exactly `retry_rnr` counts** `[observed]`: "r <- r+1 (counter retry_rnr)" at NAK receipt, or at the RNR retransmission?
    The RTL counts at the retransmission (a SEND killed by a fatal NAK during `rnr_delay` shows `retry_rnr = 0`). Model asserts
    `retry_rnr <= rnr_retry_max * (#SENDs)`, `== rnr_retry_max` after exhaustion and `>= 1` only if a SEND waited and then completed.
22. **9.6, number of timer waits.** Effective timeout for the k-th wait is `timeout << min(k, 3)` with k = 0 for the first wait;
    exhaustion happens at the expiry with k = retry_max, so `retry_timeout + retry_nak == retry_max` for a forward-black WQE
    (`timeout_black_forward_retry_exc`).
23. **9.3, "NAK already sent" flag and RNR.** Does an RNR NAK set/clear the flag that suppresses repeated SEQ_ERR NAKs? Pipelined
    requests behind an RNR'd SEND may or may not cause a `retry_nak` `[resolved, A.5: allowed]`.
24. **11.1(a), when does a local protection error enter ERR?** Issue "stops immediately" but the failing WQE's CQE is produced only
    when every earlier WQE has retired. Model: earlier WQEs complete OK (their effect happens), the failing WQE completes
    LOC_PROT_ERR, later WQEs are never issued (flushed, no remote effect). `[observed]` the RTL agrees on writes; their *source
    reads* may happen (`[resolved, A.5]` read envelope).
25. **11.2, NAK replay.** Which `psn`/`accept_next` the replayed NAK carries, whether it is also sent for duplicates and
    out-of-sequence frames, and what a requester does with a replayed NAK whose PSN no outstanding WQE owns. Model: the NAK of the
    original error is replayed to every request frame that passes the adapter.
26. **11.5, does `reset kind=qp` produce a CFG result line?** Model marks that CFG entry optional; the checker accepts both.
27. **11.5, hard reset vs memory and CQ.** Model assumes the bench memory contents survive `rst_n` (the memory is not part of the
    endpoint) and that the CQ is drained (no undrained CQE is lost). Generators avoid depending on it (no dump of pre-reset data
    through a reset endpoint's registry).
28. **11.5/12, RQEs posted in INIT.** A QP reset / ERR flushes them as RECV WR_FLUSH_ERR like any unconsumed RQE (model).
29. **5.1 / 9.2, PSN consistency.** `sq_psn` of one side must equal `rq_psn` of the other; nothing says what happens otherwise
    (silent drops vs fatal). The model raises an error for inconsistent configurations; every scenario uses consistent PSNs
    (also near wrap and after re-establishment).

## Counters (15)
30. **ops_err / ops_flushed** `[observed]`: do they include RECV completions? The RTL counts SQ completions only. Model: soft bound
    `[SQ, SQ+RQ]`. `bytes_*` count OK completions only; `ops_done_recv`/`bytes_recv` per RECV CQE.
31. **dma_wr_bytes / dma_rd_bytes semantics** (bytes vs words, retransmitted reads). Model: soft check of dma_wr_bytes = bytes
    written since the last hard reset.
32. **post_rej_* counters.** Only `post_rej_opcode` is named (7.5); the model asserts it exactly and the other four (`_state`,
    `_len`, `_fields`, `_range`) as soft.
33. **tx_retx_frames, rx_dup, rx_oos, rx_ack_stale, rx_resp_drop**: exact only on a clean link (soft); otherwise lower bounds.

## Scenario / result file format (Appendix A)
34. **A.1 `dump`** `[resolved]`: snapshot at the position of the command (the model evaluates it there; generators still put dumps
    after the final barrier).
35. **A.1 `mem_fill` index.** `pat(seed, i)` with `i` = offset from the start of the filled range (not the absolute PA).
36. **A.1 `idle`** is mentioned as a time-advancing command but not defined: model treats it like `run` (`cycles=` or `n=`).
37. **A.1 `link_script` ordinals.** Counted from simulation start or from the command? Does `dup=n` plus `delay=n:c` delay the
    original, the copy or both? Suite: scripts are issued before the first frame of that direction (so both readings agree) and
    never combine dup and delay on one ordinal; the "delayed duplicate must not overwrite" test uses an explicit `inject`.
38. **A.1 `inject` vs `link_black` / random impairments:** does an injected frame go through them? Generators never inject into a
    black direction; the model warns if they do.
39. **A.1 `link reorder`** (percent? probability of being delayed by delay_max?). Treated as an impairment flag only.
40. **A.1 blocking of `post_*` when `post_ready = 0`.** `cq_credit_exhaustion` needs the command stream to continue while posts are
    back-pressured (otherwise `cq_drain on=1` is never reached). It is the only scenario with that requirement.
41. **A.1 `wait_cqe`:** returns as soon as `n` CQEs exist, leaving other work in flight; model advances time in steps until the
    count is reached. Suite uses `barrier` everywhere.
42. **A.2 encodings.** `op`, `status`, `state` may be names or numbers; `cause` names are not specified. The parser accepts both,
    the checker only compares the QP *state*. `[observed]` the bench encodes states/causes as numbers and reports barrier
    time-outs as `NOTE ... barrier timed out` and violated monitors as `MON ...` lines while `END timeout=` stays 0; the checker
    treats a timed-out barrier or any `MON` line as a mismatch unless the model expects the time-out.
43. **A.4/A.5, completion after commit.** "CQE cycle >= max memory ack cycle of the WQE's words" (`>=`, exact). Applied to WRITE,
    SEND (requester), RECV (responder) and READ (placement in the requester) CQEs.
44. **Initial memory contents** are not specified: generators `mem_fill` every range they `dump`; the model flags (note) a dump
    over never-filled, never-written bytes.
