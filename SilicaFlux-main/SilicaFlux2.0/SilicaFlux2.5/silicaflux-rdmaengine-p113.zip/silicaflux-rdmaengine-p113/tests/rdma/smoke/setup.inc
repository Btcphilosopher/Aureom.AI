seed v=1
mem_fill ep=A addr=0x10000 len=8192 pat=11
mem_fill ep=B addr=0x20000 len=8192 pat=22
mr ep=A idx=0 va=0x1000 len=0x4000 pa=0x10000 key=0x1111 pd=1 acc=0xF ctx=0
mr ep=B idx=0 va=0x5000 len=0x4000 pa=0x20000 key=0x2222 pd=1 acc=0xF ctx=0
qp ep=A state=INIT pd=1 qpn=5
qp ep=B state=INIT pd=1 qpn=7
qp ep=A state=RTR rqpn=7 epoch=3 rq_psn=0x100 smac=0x020000000001 dmac=0x020000000002
qp ep=B state=RTR rqpn=5 epoch=3 rq_psn=0x200 smac=0x020000000002 dmac=0x020000000001
qp ep=A state=RTS sq_psn=0x200 timeout=1500 retry=5 rnr_retry=3 rnr_delay=200
qp ep=B state=RTS sq_psn=0x100 timeout=1500 retry=5 rnr_retry=3 rnr_delay=200
