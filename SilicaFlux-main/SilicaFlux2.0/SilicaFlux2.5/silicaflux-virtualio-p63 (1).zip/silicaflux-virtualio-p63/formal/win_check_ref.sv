// Reference formulation of the window permission check for the formal equivalence proof (VERIFICATION ONLY).
// Deliberately written differently from rtl/sfv_win_check.sv: 128-bit arithmetic, a flat loop, no shared sub-expressions.
//   ok        <=>  len != 0  AND  exists w : valid[w] AND base[w] <= addr AND addr + len <= base[w] + size[w]  AND the permissions
//   contained <=>  the same without the permission test
// With 128-bit arithmetic nothing can wrap: if the RTL (65-bit arithmetic) is equivalent to this, the RTL cannot wrap either.
`default_nettype none
module win_check_ref #(parameter int NW = 2) (
  input  wire logic [NW*64-1:0] base,
  input  wire logic [NW*64-1:0] size,
  input  wire logic [NW*3-1:0]  ctl,
  input  wire logic [63:0]      addr,
  input  wire logic [31:0]      len,
  input  wire logic             need_r,
  input  wire logic             need_w,
  output logic                  contained,
  output logic                  ok
);
  always_comb begin
    integer w;
    logic [127:0] a, l, b, s;
    contained = 1'b0;
    ok = 1'b0;
    a = {64'd0, addr};
    l = {96'd0, len};
    for (w = 0; w < NW; w = w + 1) begin
      b = {64'd0, base[w*64 +: 64]};
      s = {64'd0, size[w*64 +: 64]};
      if (ctl[w*3 + 2] && l != 128'd0 && a >= b && (a + l) <= (b + s)) begin
        contained = 1'b1;
        if ((!need_r || ctl[w*3 + 0]) && (!need_w || ctl[w*3 + 1])) ok = 1'b1;
      end
    end
  end
endmodule
`default_nettype wire
