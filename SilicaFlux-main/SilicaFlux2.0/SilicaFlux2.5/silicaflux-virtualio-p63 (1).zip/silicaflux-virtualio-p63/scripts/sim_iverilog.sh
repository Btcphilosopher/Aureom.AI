#!/bin/bash
# Build + run the system testbench on Icarus Verilog.  Extra args are passed to iverilog (e.g. -Ptb_virtio.NF=2).
D="$(cd "$(dirname "$0")/.." && pwd)"
OUT=${OUT:-$D/build/tb_ivl}
iverilog -g2012 -Wall -Wno-timescale -I "$D/tb" -o "$OUT" "$@" \
  $("$D/scripts/rtl_files.sh") "$D/vendor/sfb_protocol_checker.sv" "$D/tb/tb_sfb2_delay.sv" "$D/tb/tb_virtio.sv" -s tb_virtio || exit 1
vvp -n "$OUT"
