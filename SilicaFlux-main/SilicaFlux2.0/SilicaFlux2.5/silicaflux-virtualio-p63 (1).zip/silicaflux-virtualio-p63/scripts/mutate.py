#!/usr/bin/env python3
"""Mutation campaign: plant one RTL bug at a time and require the verification suite to notice.

For every mutant: copy rtl/ to build/mut/<id>/rtl, apply the textual change, build the system testbench against that copy and run
it.  KILLED = the testbench reports FAIL (or hangs into its watchdog); SURVIVED = it still reports PASS; INVALID = does not compile.
A survivor is either a test hole (fix the test) or an EQUIVALENT mutant (the bug cannot be observed through any port) -- each is
analysed and recorded in reports/mutation.md, never silently dropped.

  mutate.py run [--jobs N] [--only M01,M05]      run (writes reports/mutation.md)
  mutate.py list                                 list the mutants
"""
import os, re, shutil, subprocess, sys, time, concurrent.futures as cf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# id, description, [(file, old, new), ...], extra simulator args, what is expected to notice
M = [
 ("M01", "window WRITE permission ignored", [("sfv_win_check.sv", "(!need_w || ctl[w*3 + silicaflux_virtio_pkg::WC_W]);", "1'b1;")], [], "DMA permission tests"),
 ("M02", "window READ permission ignored", [("sfv_win_check.sv", "(!need_r || ctl[w*3 + silicaflux_virtio_pkg::WC_R]) &&", "1'b1 &&")], [], "DMA permission tests"),
 ("M03", "window end check off by one byte", [("sfv_win_check.sv", "(a_end <= w_end);", "(a_end <= w_end + 65'd1);")], [], "window-edge tests"),
 ("M04", "window start check off by one byte", [("sfv_win_check.sv", "(addr >= wb) &&", "(addr + 64'd1 >= wb) &&")], [], "window-edge tests"),
 ("M05", "domain-enable check dropped (default deny lost)", [("sfv_domain_adapter.sv", "q_den    = q_dvalid && dom_en[dsel(q_dom)];", "q_den    = q_dvalid;")], [], "disabled-domain test"),
 ("M06", "per-beat guard bypassed", [("sfv_domain_adapter.sv", "assign g_ok = in_grant && g_den && g_tok;", "assign g_ok = 1'b1;")], [], "revocation test"),
 ("M07", "per-beat guard ignores the live table (grant only)", [("sfv_domain_adapter.sv", "assign g_ok = in_grant && g_den && g_tok;", "assign g_ok = in_grant && g_den;")], [], "revocation test"),
 ("M08", "descriptor cycle detection removed", [("sfv_desc_walker.sv", "end else if (visited_q[idx_q[$clog2(MAX_QSZ)-1:0]]) begin", "end else if (1'b0) begin")], [], "malformed-chain tests"),
 ("M09", "chain length limit off by one", [("sfv_desc_walker.sv", "end else if (cnt_q >= 16'(MAX_CHAIN)) begin", "end else if (cnt_q > 16'(MAX_CHAIN)) begin")], [], "chain-length tests"),
 ("M10", "indirect descriptors accepted", [("sfv_desc_walker.sv", "end else if ((d_flags & silicaflux_virtio_pkg::DESC_F_INDIRECT) != 16'd0) begin", "end else if (1'b0) begin")], [], "malformed-chain tests"),
 ("M11", "device-readable-after-writable allowed", [("sfv_desc_walker.sv", "end else if (!d_write_f && seen_wr_q) begin", "end else if (1'b0) begin")], [], "malformed-chain tests"),
 ("M12", "reserved descriptor flags accepted", [("sfv_desc_walker.sv", "if ((d_flags & ~silicaflux_virtio_pkg::DESC_F_KNOWN) != 16'd0) begin", "if (1'b0) begin")], [], "malformed-chain tests"),
 ("M13", "read-only function accepts writes", [("sfv_blk_exec.sv", "(t_out && ro)", "1'b0")], [], "read-only test"),
 ("M14", "sector range check lets a request cross the end of the disk", [("sfv_blk_exec.sv", "(nsect > (cap_sectors - h_sector))", "(nsect > (cap_sectors - h_sector + 64'd1))")], [], "capacity-edge tests"),
 ("M15", "used.len omits the status byte", [("sfv_blk_exec.sv", "assign used_len   = wrb_q[31:0] + 32'd1;", "assign used_len   = wrb_q[31:0];")], [], "used.len expectations"),
 ("M16", "used element written without its length", [("sfv_queue_ctrl.sv", "ld_mask = 16'h00FF; end   // le32 id, le32 len", "ld_mask = 16'h000F; end")], [], "completion checks"),
 ("M17", "NO_INTERRUPT ignored", [("sfv_queue_ctrl.sv", "due_q[g] && !av_nointr;", "due_q[g];"), ("sfv_queue_ctrl.sv", "due_q[cf_q] && !av_nointr;", "due_q[cf_q];")], [], "interrupt tests"),
 ("M18", "a full ring (outstanding == queue size) treated as overrun", [("sfv_queue_ctrl.sv", "if (n_av > qsz_q) begin", "if (n_av >= qsz_q) begin")], [], "queue-full test"),
 ("M19", "FEATURES_OK granted for features not offered", [("sfv_func_regs.sv", "wire        feat_ok  = ((dfeat_q & ~dev_feat) == 64'd0) && dfeat_q[silicaflux_virtio_pkg::F_VERSION_1];", "wire        feat_ok  = dfeat_q[silicaflux_virtio_pkg::F_VERSION_1];")], [], "feature-negotiation tests"),
 ("M20", "queue address alignment not validated", [("sfv_func_regs.sv", "wire        al_ok   = (desc_q[3:0] == 4'd0) && (avail_q[0] == 1'b0) && (used_q[1:0] == 2'd0);", "wire        al_ok   = 1'b1;")], [], "queue-setup tests"),
 ("M21", "Status reads 0 before the engine has stopped (reset completes early)", [("sfv_func_regs.sv", "rst_pend_q <= 1'b1;", "rst_pend_q <= 1'b1; status_q <= 8'd0;")], [], "in-flight reset test"),
 ("M22", "in-flight transfer ignores a reset (abort lost)", [("sfv_beat_mover.sv", "if (abort_i) begin\n            res_q <= 3'd3;\n            st_q  <= M_FIN;\n          end else if (!g_ok) begin", "if (1'b0) begin\n            res_q <= 3'd3;\n            st_q  <= M_FIN;\n          end else if (!g_ok) begin"), ("sfv_beat_mover.sv", "end else if (abort_i) begin", "end else if (1'b0) begin")], [], "in-flight reset test"),
 ("M23", "LOST DOORBELL (the bug found by co-simulation): pend cleared at the end of an empty poll", [("sfv_queue_ctrl.sv", "if (pend_clr[f]) pend_q[f] <= 1'b0;", "if (pend_clr[f] || ((st_q == Q_AV_EVAL) && (32'(cf_q) == f) && (n_av == 16'd0))) pend_q[f] <= 1'b0;")], [], "doorbell-race test"),
 ("M24", "available-ring head NOT range checked anywhere (the check exists twice: controller and walker; both removed)", [("sfv_queue_ctrl.sv", "end else if (pk_data[15:0] >= qsz_q) begin", "end else if (1'b0) begin"), ("sfv_desc_walker.sv", "if (idx_q >= qsize) begin", "if (1'b0) begin")], [], "head-index test"),
 ("M25", "function-to-domain binding ignored: every function uses domain 0", [("sfv_queue_ctrl.sv", "dom_q     <= f_dom[sel_f*DOMW +: DOMW];", "dom_q     <= f_dom[0 +: DOMW];")], ["-GNF=2"], "multi-tenant isolation tests"),
 ("M26", "management lets an IN-USE function be reconfigured", [("sfv_mgmt.sv", "wire        fbusy     = f_inuse_i[fs];", "wire        fbusy     = 1'b0;")], [], "management-rule tests"),
 ("M27", "management accepts windows that are not beat-aligned", [("sfv_mgmt.sv", "wire win_geo_ok = !mg_req_wdata[silicaflux_virtio_pkg::WC_V] ||", "wire win_geo_ok = 1'b1 || !mg_req_wdata[silicaflux_virtio_pkg::WC_V] ||")], [], "management-rule tests"),
 ("M28", "backend partition upper bound not enforced (UNIT: tb_ramdisk)", [("sfv_ramdisk.sv", "wire        acc_ok  = sel_ok_dom && (a_end <= sel_size) &&", "wire        acc_ok  = sel_ok_dom && 1'b1 &&")], ["UNIT"], "ramdisk unit bench"),
 ("M29", "backend uses domain 0's partition base for every domain (UNIT: tb_ramdisk)", [("sfv_ramdisk.sv", "sel_base   = {1'b0, pbase[(32'(s_req_dom) < ND) ? 32'(s_req_dom) : 0]};", "sel_base   = {1'b0, pbase[0]};")], ["UNIT"], "ramdisk unit bench"),
 ("M30", "scrub does not zero the partition (UNIT: tb_ramdisk)", [("sfv_ramdisk.sv", "mem[scr_idx[WAW-1:0]] <= '0;", "mem[scr_idx[WAW-1:0]] <= mem[scr_idx[WAW-1:0]];")], ["UNIT"], "ramdisk unit bench"),
]

def build_tree(mid, edits):
    d = os.path.join(ROOT, "build", "mut", mid)
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(os.path.join(ROOT, "rtl"), os.path.join(d, "rtl"))
    for fn, old, new in edits:
        path = os.path.join(d, "rtl", fn)
        s = open(path).read()
        if s.count(old) != 1:
            return d, "pattern for %s found %d times" % (fn, s.count(old))
        open(path, "w").write(s.replace(old, new))
    return d, None

def run_mutant(m, jobs):
    mid, desc, edits, args, who = m
    t0 = time.time()
    d, err = build_tree(mid, edits)
    if err:
        return dict(id=mid, desc=desc, who=who, status="INVALID", note=err, secs=0)
    env = dict(os.environ, RTL_ROOT=d, J="1", B=os.path.join(d, "tb"))
    if args == ["UNIT"]:
        # build the unit bench against the mutated ramdisk
        cmd = ["bash", "-c", "iverilog -g2012 -Wno-timescale -o %s/ut %s/rtl/pkg/silicaflux_virtio_pkg.sv %s/rtl/sfv_ramdisk.sv %s/vendor/sfb_protocol_checker.sv %s/tb/unit/tb_ramdisk.sv -s tb_ramdisk 2>&1 | grep -v -E 'sorry|synthesized'; vvp -n %s/ut" % (d, d, d, ROOT, ROOT, d)]
        r = subprocess.run(cmd, capture_output=True, text=True, env=env, cwd=ROOT)
    else:
        extra = list(args)
        # the system suite without the long random sweep, to keep the campaign short; all directed tests + doorbell + multi-tenant run
        if "-GNF=2" in extra:
            extra += ["-GTESTMASK=%d" % (32768 + 1)]
        else:
            extra += ["-GNRAND=60"]
        r = subprocess.run([os.path.join(ROOT, "scripts", "sim_verilator.sh")] + extra, capture_output=True, text=True, env=env, cwd=ROOT)
    out = r.stdout + r.stderr
    if "TB RESULT PASS" in out:
        st = "SURVIVED"
    elif "TB RESULT FAIL" in out:
        st = "KILLED"
    else:
        st = "INVALID"
    note = ""
    if st == "KILLED":
        m1 = re.search(r"\[FAIL\][^\n]*?:\s+([^\n:]*)(?::[^\n]*)?\n", out)
        fails = [l.strip() for l in out.splitlines() if "[FAIL]" in l or "[MON]" in l]
        note = fails[0][:180] if fails else "testbench reported failure"
    elif st == "INVALID":
        note = "build/run problem: " + (out.strip().splitlines() or ["?"])[-1][:160]
    return dict(id=mid, desc=desc, who=who, status=st, note=note, secs=int(time.time() - t0))

def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ("run", "list"):
        print(__doc__); return 2
    if sys.argv[1] == "list":
        for m in M: print(m[0], m[1]); return 0
    jobs = 3
    if "--jobs" in sys.argv: jobs = int(sys.argv[sys.argv.index("--jobs") + 1])
    only = sys.argv[sys.argv.index("--only") + 1].split(",") if "--only" in sys.argv else None
    todo = [m for m in M if not only or m[0] in only]
    rows = []
    with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
        futs = [ex.submit(run_mutant, m, jobs) for m in todo]
        for f in cf.as_completed(futs):
            r = f.result(); rows.append(r)
            print("%s %-9s %4ds  %s" % (r["id"], r["status"], r["secs"], r["desc"]), flush=True)
    # merge with the previous campaign when only some mutants were re-run (results are kept in reports/mutation_results.json)
    import json
    jp = os.path.join(ROOT, "reports", "mutation_results.json")
    prev = {}
    if os.path.exists(jp):
        prev = {r["id"]: r for r in json.load(open(jp))}
    elif os.path.exists(os.path.join(ROOT, "reports", "mutation.md")):
        for line in open(os.path.join(ROOT, "reports", "mutation.md")):
            m = re.match(r"\| (M\d+) \| (.*?) \| \*\*(\w+)\*\* \| (.*) \|$", line.rstrip("\n"))
            if m: prev[m.group(1)] = dict(id=m.group(1), desc=m.group(2), who="", status=m.group(3), note=m.group(4), secs=0)
    for r in rows: prev[r["id"]] = r
    descs = {m_[0]: m_[1] for m_ in M}
    rows = [dict(prev[k], desc=descs.get(k, prev[k]["desc"])) for k in sorted(prev) if k in descs]
    json.dump(rows, open(jp, "w"), indent=1)
    killed = sum(r["status"] == "KILLED" for r in rows)
    with open(os.path.join(ROOT, "reports", "mutation.md"), "w") as f:
        f.write("# Mutation campaign (generated by scripts/mutate.py)\n\n")
        f.write("One planted RTL bug at a time; **killed** = the verification suite reported a failure.  %d / %d mutants killed.\n\n" % (killed, len(rows)))
        f.write("| id | planted bug | status | first failure message |\n|---|---|---|---|\n")
        for r in rows:
            f.write("| %s | %s | **%s** | %s |\n" % (r["id"], r["desc"], r["status"], r["note"].replace("|", "/")))
    print("MUTATION: %d / %d killed; survivors: %s" % (killed, len(rows), [r["id"] for r in rows if r["status"] == "SURVIVED"]))
    return 0

sys.exit(main())
