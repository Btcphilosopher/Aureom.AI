#!/bin/bash
# Unit benches (fast): the protected backend in isolation.  Runs on Icarus Verilog and on Verilator.
D="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$D/build" "$D/reports/unit"
RC=0
echo "== tb_ramdisk on Icarus Verilog"
iverilog -g2012 -Wno-timescale -o "$D/build/tb_ramdisk_ivl" "$D/rtl/pkg/silicaflux_virtio_pkg.sv" "$D/rtl/sfv_ramdisk.sv" "$D/vendor/sfb_protocol_checker.sv" \
   "$D/tb/unit/tb_ramdisk.sv" -s tb_ramdisk 2>&1 | grep -v -E "sorry: constant|cannot be synthesized"
vvp -n "$D/build/tb_ramdisk_ivl" | tee "$D/reports/unit/tb_ramdisk_ivl.log" | grep -E "FAIL|SUMMARY|RESULT"
grep -q "TB RESULT PASS" "$D/reports/unit/tb_ramdisk_ivl.log" || RC=1
echo "== tb_ramdisk on Verilator"
B="$D/build/tb_ramdisk_vl"; rm -rf "$B"
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module tb_ramdisk -Mdir "$B" -o tb_ramdisk_vl \
   "$D/rtl/pkg/silicaflux_virtio_pkg.sv" "$D/rtl/sfv_ramdisk.sv" "$D/vendor/sfb_protocol_checker.sv" "$D/tb/unit/tb_ramdisk.sv" > "$B.log" 2>&1 || { tail -20 "$B.log"; exit 1; }
"$B/tb_ramdisk_vl" | tee "$D/reports/unit/tb_ramdisk_vl.log" | grep -E "FAIL|SUMMARY|RESULT"
grep -q "TB RESULT PASS" "$D/reports/unit/tb_ramdisk_vl.log" || RC=1
exit $RC
