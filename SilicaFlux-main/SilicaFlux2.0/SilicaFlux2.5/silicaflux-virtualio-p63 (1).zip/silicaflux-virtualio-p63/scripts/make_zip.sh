#!/bin/bash
# Package the project as a zip (build products excluded).  This is NOT a git commit and touches no git state.
D="$(cd "$(dirname "$0")/.." && pwd)"
NAME=silicaflux-virtualio-p63
OUT="${1:-$(dirname "$D")/$NAME.zip}"
cd "$(dirname "$D")" || exit 1
rm -f "$OUT"
zip -qr "$OUT" "$(basename "$D")" -x "$(basename "$D")/build/*" -x "*/__pycache__/*" -x "*/target/*" -x "*.o" -x "*.a"
( cd "$(dirname "$OUT")" && sha256sum "$(basename "$OUT")" ) | tee "$D/reports/zip.sha256"
unzip -l "$OUT" | tail -1
