#!/bin/bash
# Prints the exact tool versions the project was built and verified with.
for c in verilator yosys iverilog gcc python3 make; do
  if command -v $c >/dev/null 2>&1; then
    case $c in iverilog) v=$($c -V 2>&1 | head -1);; *) v=$($c --version 2>&1 | head -1);; esac
    printf '%-12s %s\n' $c "$v"
  else printf '%-12s %s\n' $c "NOT INSTALLED"; fi
done
