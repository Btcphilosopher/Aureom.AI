#!/bin/bash
# Exhaustive equivalence proof (Yosys miter + SAT) of rtl/sfv_win_check.sv against formal/win_check_ref.sv, for 1, 2 and 4 windows.
# Proves: for ALL 64-bit addresses, 32-bit lengths, window bases/sizes and permission bits the RTL grants exactly what the 128-bit
# reference grants -- in particular no wrap-around, no off-by-one at either window edge, no permission confusion.
D="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$D/reports/formal"
RC=0
for NW in 1 2 4; do
  yosys -q -l "$D/reports/formal/win_check_nw$NW.log" -p "
    read_verilog -sv $D/rtl/pkg/silicaflux_virtio_pkg.sv $D/rtl/sfv_win_check.sv $D/formal/win_check_ref.sv;
    chparam -set NW $NW sfv_win_check; chparam -set NW $NW win_check_ref;
    hierarchy -check;
    proc; flatten; opt_clean;
    miter -equiv -flatten -make_assert -make_outputs sfv_win_check win_check_ref miter;
    hierarchy -top miter;
    sat -verify -prove-asserts -show-ports -timeout 1500 miter" >/dev/null 2>&1
  if grep -q "SUCCESS" "$D/reports/formal/win_check_nw$NW.log"; then echo "NW=$NW: PROVED equivalent for all inputs ($(grep -c . "$D/reports/formal/win_check_nw$NW.log") log lines)";
  else echo "NW=$NW: NOT PROVED"; tail -5 "$D/reports/formal/win_check_nw$NW.log"; RC=1; fi
done
exit $RC
