#!/bin/bash
# Prints the synthesizable RTL file list in dependency order (package first).
D="${RTL_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
for f in rtl/pkg/silicaflux_virtio_pkg.sv rtl/sfv_win_check.sv rtl/sfv_domain_adapter.sv rtl/sfv_beat_mover.sv rtl/sfv_gdma.sv \
         rtl/sfv_ramdisk.sv rtl/sfv_func_regs.sv rtl/sfv_desc_walker.sv rtl/sfv_blk_exec.sv rtl/sfv_perf.sv \
         rtl/sfv_queue_ctrl.sv rtl/sfv_mgmt.sv rtl/sfv_engine_core.sv rtl/silicaflux_virtio_engine.sv; do
  echo "$D/$f"
done
