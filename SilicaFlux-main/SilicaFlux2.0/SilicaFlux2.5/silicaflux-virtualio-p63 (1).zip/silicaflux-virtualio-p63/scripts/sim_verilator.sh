#!/bin/bash
# Build + run the system testbench on Verilator (--binary --timing).  Extra args: -GNF=2 etc.
D="$(cd "$(dirname "$0")/.." && pwd)"
B=${B:-$D/build/tb_vl}
rm -rf "$B"
verilator --binary --timing -j ${J:-$(nproc)} -O0 --output-split 5000 --output-split-cfuncs 500 -CFLAGS -O0 -Wno-fatal -Wno-lint -Wno-style -Wno-WIDTH -Wno-CASEINCOMPLETE -Wno-MULTIDRIVEN -Wno-INITIALDLY --top-module tb_virtio \
  -I"$D/tb" -Mdir "$B" -o tb_vl --x-assign 0 --x-initial 0 "$@" \
  $("$D/scripts/rtl_files.sh") "$D/vendor/sfb_protocol_checker.sv" "$D/tb/tb_sfb2_delay.sv" "$D/tb/tb_virtio.sv" > "$B.build.log" 2>&1 || { tail -40 "$B.build.log"; exit 1; }
"$B/tb_vl"
