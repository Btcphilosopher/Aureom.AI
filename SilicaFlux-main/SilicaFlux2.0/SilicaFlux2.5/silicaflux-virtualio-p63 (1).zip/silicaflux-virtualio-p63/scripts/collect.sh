#!/bin/bash
# Runs the quick checks and stores their output in reports/ (check-abi, lint, host, rust, unit, formal).
D="$(cd "$(dirname "$0")/.." && pwd)"
cd "$D" || exit 1
mkdir -p reports
RC=0
python3 scripts/gen_abi.py --check > reports/check_abi.log 2>&1 || RC=1
python3 scripts/lint.py > reports/lint.log 2>&1 || RC=1
{ make -C host; build/host/diff_soft_soft 500 1; build/host/diff_soft_soft 500 2; } > reports/host_softdev.log 2>&1 || RC=1
( cd host/rust && cargo test --offline ) > reports/rust_tests.log 2>&1 || RC=1
bash scripts/unit.sh > reports/unit.log 2>&1 || RC=1
bash scripts/formal_wincheck.sh > reports/formal.log 2>&1 || RC=1
scripts/tools.sh > reports/tools.txt
for f in check_abi lint host_softdev rust_tests unit formal; do printf '%-14s ' $f; tail -1 reports/$f.log | cut -c1-120; done
exit $RC
