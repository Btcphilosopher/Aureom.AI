#!/bin/bash
# Build the Verilator co-simulation (RTL + C host library) and run:  scripts/cosim.sh [demo | diff <ops> <seed>] [--stall N]
D="$(cd "$(dirname "$0")/.." && pwd)"
B=$D/build/cosim
make -C "$D/host" ../build/host/libsfv_host.a >/dev/null || exit 1
if [ ! -x "$B/sfv_cosim" ] || [ -n "$REBUILD" ]; then
  rm -rf "$B"
  verilator --cc --exe --build -j "$(nproc)" -O1 -Wno-fatal -Wno-lint -Wno-style --top-module silicaflux_virtio_engine \
    -Mdir "$B" -o sfv_cosim --x-assign 0 --x-initial 0 \
    -CFLAGS "-I$D/host/include -I$D/host/examples -O1" -LDFLAGS "$D/build/host/libsfv_host.a" \
    $("$D/scripts/rtl_files.sh") "$D/cosim/sfv_cosim.cpp" > "$B.build.log" 2>&1 || { tail -30 "$B.build.log"; exit 1; }
fi
"$B/sfv_cosim" "$@"
