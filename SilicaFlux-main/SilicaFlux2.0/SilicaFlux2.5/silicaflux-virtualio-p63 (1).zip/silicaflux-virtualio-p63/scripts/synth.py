#!/usr/bin/env python3
"""Yosys 0.33 generic synthesis of the VirtualIO RTL: per-module and per-configuration; writes reports/synth/SUMMARY.md.
  * `check -assert` must be clean (no combinational loops, no multiple drivers, no undriven used wires);  latches must be 0
  * numbers are Yosys GENERIC cells (and an xc7 LUT6/FF estimate): NOT an area, timing or power claim -- there is no place and route
  * the RAM-disk store is a memory: its bits are reported separately and excluded from the logic totals"""
import subprocess, re, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES = [l.strip() for l in subprocess.run([os.path.join(ROOT, "scripts/rtl_files.sh")], capture_output=True, text=True).stdout.splitlines()]
OUT = os.path.join(ROOT, "reports", "synth")
os.makedirs(OUT, exist_ok=True)

def yosys(script, log):
    r = subprocess.run(["yosys", "-q", "-l", log, "-p", script], capture_output=True, text=True, cwd=ROOT)
    return r.returncode, open(log).read() if os.path.exists(log) else r.stderr

def stat(text):
    t = text.split("Printing statistics.")[-1]
    n = re.search(r"Number of cells:\s+(\d+)", t)
    cells = {}
    for m in re.finditer(r"^\s+(\$?[A-Za-z_0-9$\\]+)\s+(\d+)\s*$", t, re.M):
        cells[m.group(1)] = cells.get(m.group(1), 0) + int(m.group(2))
    mb = re.search(r"Number of memory bits:\s+(\d+)", t)
    return (int(n.group(1)) if n else None), cells, (int(mb.group(1)) if mb else 0)   # (bits of $mem cells are added by the caller)

def run_one(label, top, params, xc7=False, memory_only=False):
    chp = " ".join("chparam -set %s %s %s;" % (k, v, top) for k, v in params.items())
    rd = "read_verilog -sv -defer %s;" % " ".join(FILES)
    base = "%s %s hierarchy -check -top %s;" % (rd, chp, top)
    log = os.path.join(OUT, label + ".log")
    if memory_only:
        gen = base + " proc; opt; memory_collect; check -assert; tee -o %s.stat_generic.txt stat;" % os.path.join(OUT, label)
    else:
        gen = base + " synth -top %s -flatten; check -assert; tee -o %s.stat_generic.txt stat;" % (top, os.path.join(OUT, label))
    rc, text = yosys(gen, log)
    n, cells, mbits = stat(text)
    if memory_only and (cells.get("$mem_v2", 0) or cells.get("$mem", 0)):   # the store is the one large memory: STORE_BYTES x 8 bits
        mbits = int(params.get("STORE_BYTES", 65536)) * 8                    # (small on-chip arrays elsewhere are not counted here)
    res = {"label": label, "top": top, "params": params, "rc": rc, "check_ok": rc == 0, "cells": n, "mem_bits": mbits}
    if label.startswith("wrapper_elab"): n = None                       # elaboration + check only: the hierarchical stat has no single cell total
    res["cells"] = n
    res["latches"] = sum(v for k, v in cells.items() if "LATCH" in k.upper()) if n else None
    res["ff"] = sum(v for k, v in cells.items() if re.match(r"\$_(S?DFF|DFFE|SDFFE|DFFSR|ADFF|ALDFF)", k)) if not memory_only else None
    if xc7:
        log2 = os.path.join(OUT, label + ".xc7.log")
        x = base + " synth_xilinx -family xc7 -top %s -flatten; tee -o %s.stat_xc7.txt stat;" % (top, os.path.join(OUT, label))
        rc2, t2 = yosys(x, log2)
        n2, c2, _ = stat(t2)
        res["xc7_ok"] = rc2 == 0
        res["lut"] = sum(v for k, v in c2.items() if re.fullmatch(r"LUT[1-6]", k))
        res["xff"] = sum(v for k, v in c2.items() if re.fullmatch(r"FD\w*", k))
        res["carry"] = c2.get("CARRY4", 0)
        res["bram"] = sum(v for k, v in c2.items() if k.startswith("RAMB"))
    return res

import json
RES_JSON = os.path.join(OUT, "results.json")

def main():
    only = sys.argv[sys.argv.index("--only") + 1].split(",") if "--only" in sys.argv else None
    prev = {r["label"]: r for r in json.load(open(RES_JSON))} if only and os.path.exists(RES_JSON) else {}
    mods = ["sfv_win_check", "sfv_domain_adapter", "sfv_beat_mover", "sfv_gdma", "sfv_func_regs", "sfv_desc_walker", "sfv_blk_exec",
            "sfv_perf", "sfv_queue_ctrl", "sfv_mgmt", "sfv_ramdisk"]
    cfgs = [("core_default", "sfv_engine_core", {}, True),
            ("core_nf2", "sfv_engine_core", {"NF": 2}, True),
            ("core_nf4", "sfv_engine_core", {"NF": 4, "ND": 4}, False),
            ("core_dw128", "sfv_engine_core", {"DW": 128}, False),
            ("core_dw32", "sfv_engine_core", {"DW": 32}, False),
            ("core_ext_iommu", "sfv_engine_core", {"EXT_IOMMU": 1}, True),
            ("core_q256_c16_s128", "sfv_engine_core", {"MAX_QSZ": 256, "MAX_CHAIN": 16, "STAGE": 128}, False),
            ("core_small", "sfv_engine_core", {"MAX_QSZ": 8, "MAX_CHAIN": 4, "STAGE": 16, "NW": 2}, True)]
    results = []
    def want(label): return not only or label in only
    for m in mods:
        if not want("mod_" + m):
            if "mod_" + m in prev: results.append(prev["mod_" + m])
            continue
        params = {"STORE_BYTES": 4096} if m == "sfv_ramdisk" else {}
        results.append(run_one("mod_" + m, m, params, xc7=(m in ("sfv_ramdisk",)), memory_only=(m == "sfv_ramdisk")))
        r = results[-1]; print("%-22s cells=%s ff=%s mem_bits=%s check=%s" % (m, r["cells"], r["ff"], r["mem_bits"], "ok" if r["check_ok"] else "FAIL"), flush=True)
    for label, top, params, x in cfgs:
        if not want(label):
            if label in prev: results.append(prev[label])
            continue
        results.append(run_one(label, top, params, xc7=x))
        r = results[-1]
        print("%-22s cells=%s ff=%s lut=%s check=%s" % (label, r["cells"], r["ff"], r.get("lut"), "ok" if r["check_ok"] else "FAIL"), flush=True)
    if want("wrapper_elab_store4k"):
        results.append(run_one("wrapper_elab_store4k", "silicaflux_virtio_engine", {"STORE_BYTES": 4096}, memory_only=True))
    elif "wrapper_elab_store4k" in prev: results.append(prev["wrapper_elab_store4k"])
    json.dump(results, open(RES_JSON, "w"), indent=1)
    r = results[-1]; print("%-22s cells=%s mem_bits=%s check=%s" % (r["label"], r["cells"], r["mem_bits"], "ok" if r["check_ok"] else "FAIL"), flush=True)
    with open(os.path.join(OUT, "SUMMARY.md"), "w") as f:
        f.write("# Synthesis summary (generated by scripts/synth.py)\n\n")
        f.write("Tool: Yosys 0.33 (the repository's baseline flow).  GENERIC synthesis only: `synth -flatten`, `check -assert` (no combinational loops / multiple drivers / "
                "undriven wires), latch count; for some runs a separate `synth_xilinx -family xc7` mapping gives a LUT6/FF *estimate*.  "
                "**No place-and-route, no timing, no power, no area claim.**\n\n")
        f.write("| run | top | parameters | generic cells | flops | memory bits | `check -assert` | latches | xc7 LUTs | xc7 FFs | CARRY4 | BRAM |\n|---|---|---|---|---|---|---|---|---|---|---|---|\n")
        for r in results:
            f.write("| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |\n" % (r["label"], r["top"], ", ".join("%s=%s" % kv for kv in r["params"].items()) or "defaults",
                    r["cells"], r["ff"] if r["ff"] is not None else "-", r["mem_bits"], "clean" if r["check_ok"] else "**FAILED**", r["latches"] if r["latches"] is not None else "-",
                    r.get("lut", "-"), r.get("xff", "-"), r.get("carry", "-"), r.get("bram", "-")))
        f.write("\nNotes\n\n* `mod_*` rows synthesise each module on its own (default parameters) to show where the logic is; the sum of the modules is larger than the flattened "
                "`core_default` row because flattening lets Yosys share and constant-fold across module boundaries.\n"
                "* `mod_sfv_ramdisk` and `wrapper_elab_store4k` stop before technology mapping (`proc; opt; memory_collect`): the store is a **memory** (a macro / block RAM in a real flow); "
                "its bits are reported in the `memory bits` column and are NOT included in any logic number.\n"
                "* The logic is large for what it does because this is a *generic* netlist of a design whose stage buffer is byte-lane muxed, whose counters are 23 x 32 bit per function and whose domain "
                "tables are comparators over 64-bit addresses -- see docs/SYNTHESIS.md for the breakdown and the obvious reductions (SRAM stage, fewer counters, 48-bit comparators).\n")
    bad = [r for r in results if not r["check_ok"] or (r["latches"] not in (0, None))]
    print("synthesis: %d runs, %d problem(s)" % (len(results), len(bad)))
    return 1 if bad else 0

sys.exit(main())
