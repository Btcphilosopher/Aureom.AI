// =============================================================================
// VirtualIO :: sfv_func_regs -- virtio-mmio (Version 2) register block of ONE virtio-blk function
//
// The guest-visible, versioned register interface of the device (spec 4.2.2): MagicValue "virt", Version 2, DeviceID,
// VendorID, feature windows, status, queue setup, notification, interrupt status / acknowledge, configuration space.
//
//   * Features: only silicaflux_virtio_pkg::device_features() is ever offered.  FEATURES_OK is granted only if the
//     driver's accepted set is a subset of it AND contains VIRTIO_F_VERSION_1; otherwise the bit reads back 0 (spec 3.1.1
//     step 6: the driver re-reads the status to find out).  No legacy interface exists (Version is 2).
//   * Status is monotonic: a driver can only SET bits; clearing is a reset (write 0).  NEEDS_RESET (0x40) is owned by
//     the device (set by the engine on a fatal fault) and is cleared only by a reset.  DRIVER_OK is granted only after
//     FEATURES_OK.
//   * Reset: writing 0 to Status stops the function immediately (`running` falls), asks the engine to abandon any work for
//     it (rst_req) and clears every register when the engine acknowledges.  Status keeps reading its OLD non-zero value
//     until then, so a driver that polls for 0 (spec 2.4.1) cannot observe "reset complete" while a DMA beat of the
//     function is still in flight.
//   * Queue setup (spec 4.2.3.2): QueueNum / address registers are accepted only while the queue is not ready.  Writing
//     QueueReady = 1 is accepted only for a legal geometry -- power-of-two size <= QueueNumMax, desc table 16-byte, avail
//     ring 2-byte, used ring 4-byte aligned, each area wholly inside the guest address space -- otherwise QueueReady stays
//     0.  Only queue 0 exists.  Writing QueueReady = 0 is ignored (no VIRTIO_F_RING_RESET).
//   * A function that management has not enabled reads DeviceID 0 ("no device") and ignores all writes.
//   * 32-bit accesses only (the bus bridge widens sub-word configuration reads).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfv_func_regs #(
  parameter int MAX_QSZ   = 64,
  parameter int MAX_CHAIN = 8,
  parameter int GM_AW     = 48,
  parameter int EXT_IOMMU = 0
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // guest register access (decoded for this function)
  input  wire logic        rd_en,
  input  wire logic        wr_en,
  input  wire logic [11:0] addr,
  input  wire logic [31:0] wdata,
  output logic [31:0]      rdata,
  // management-owned configuration
  input  wire logic        cfg_en,
  input  wire logic        cfg_ro,
  input  wire logic [63:0] cfg_cap,
  // engine interface
  output logic             running,        // DRIVER_OK, queue ready, no fault, not resetting, enabled
  output logic             qready,
  output logic [15:0]      qnum,
  output logic [63:0]      q_desc,
  output logic [63:0]      q_avail,
  output logic [63:0]      q_used,
  output logic             kick,           // pulse: QueueNotify(0)
  output logic             drv_ok_evt,     // pulse: DRIVER_OK just became set
  output logic             rst_req,        // level: reset requested, waiting for the engine
  input  wire logic        rst_ack,        // pulse from the engine: nothing of this function is in flight any more
  input  wire logic        fatal_set,      // pulse: set NEEDS_RESET + configuration-change interrupt
  input  wire logic        irq_set,        // pulse: used-buffer notification
  output logic [7:0]       status_o,
  output logic             irq_o,
  output logic             in_use          // status != 0 or reset pending: management may not reconfigure
);
  // rd_en: reads have no side effects, the strobe is kept so the port matches the write side
  wire unused_rd = &{1'b0, rd_en};

  logic [7:0]   status_q;
  logic [31:0]  dsel_q, hsel_q, qsel_q;
  logic [63:0]  dfeat_q;
  logic [15:0]  qnum_q;
  logic         qready_q;
  logic [63:0]  desc_q, avail_q, used_q;
  logic [1:0]   int_q;
  logic         rst_pend_q;

  localparam logic [7:0] S_ACK = silicaflux_virtio_pkg::ST_ACKNOWLEDGE;
  localparam logic [7:0] S_DRV = silicaflux_virtio_pkg::ST_DRIVER;
  localparam logic [7:0] S_DOK = silicaflux_virtio_pkg::ST_DRIVER_OK;
  localparam logic [7:0] S_FOK = silicaflux_virtio_pkg::ST_FEATURES_OK;
  localparam logic [7:0] S_NRS = silicaflux_virtio_pkg::ST_NEEDS_RESET;
  localparam logic [7:0] S_FLD = silicaflux_virtio_pkg::ST_FAILED;

  wire [63:0] dev_feat = silicaflux_virtio_pkg::device_features(cfg_ro, EXT_IOMMU != 0);
  wire        feat_ok  = ((dfeat_q & ~dev_feat) == 64'd0) && dfeat_q[silicaflux_virtio_pkg::F_VERSION_1];

  // ------------------------------------------------------------------ queue geometry validation (QueueReady = 1)
  wire        q_pow2  = (qnum_q != 16'd0) && ((qnum_q & (qnum_q - 16'd1)) == 16'd0);
  wire        q_size  = q_pow2 && (qnum_q <= 16'(MAX_QSZ));
  wire        al_ok   = (desc_q[3:0] == 4'd0) && (avail_q[0] == 1'b0) && (used_q[1:0] == 2'd0);
  wire [65:0] d_end   = {2'b00, desc_q}  + 66'(qnum_q) * 66'd16;
  wire [65:0] a_end   = {2'b00, avail_q} + 66'(qnum_q) * 66'd2 + 66'd6;
  wire [65:0] u_end   = {2'b00, used_q}  + 66'(qnum_q) * 66'd8 + 66'd6;
  wire [65:0] lim     = 66'd1 << GM_AW;
  wire        rng_ok  = (d_end <= lim) && (a_end <= lim) && (u_end <= lim);
  wire        q_valid = q_size && al_ok && rng_ok;

  // ------------------------------------------------------------------ status write rule (combinational)
  logic [7:0] st_next;
  always_comb begin
    st_next = status_q;
    if ((status_q & S_NRS) != 8'd0) begin
      st_next = status_q | (wdata[7:0] & S_FLD);                        // only FAILED may still be set
    end else begin
      st_next = status_q | (wdata[7:0] & (S_ACK | S_DRV | S_FLD));
      if (wdata[3]) begin                                               // FEATURES_OK requested
        if (feat_ok && (st_next & S_ACK) != 8'd0 && (st_next & S_DRV) != 8'd0) st_next = st_next | S_FOK;
      end
      if (wdata[2] && ((st_next & S_FOK) != 8'd0)) st_next = st_next | S_DOK;   // DRIVER_OK only after FEATURES_OK
    end
  end

  // ------------------------------------------------------------------ read multiplexer
  always_comb begin
    rdata = 32'd0;
    case (addr)
      silicaflux_virtio_pkg::R_MAGIC:         rdata = silicaflux_virtio_pkg::MMIO_MAGIC;
      silicaflux_virtio_pkg::R_VERSION:       rdata = silicaflux_virtio_pkg::MMIO_VERSION;
      silicaflux_virtio_pkg::R_DEVICE_ID:     rdata = cfg_en ? silicaflux_virtio_pkg::DEVICE_ID_BLOCK : silicaflux_virtio_pkg::DEVICE_ID_NONE;
      silicaflux_virtio_pkg::R_VENDOR_ID:     rdata = silicaflux_virtio_pkg::VENDOR_ID;
      silicaflux_virtio_pkg::R_DEV_FEATURES:  rdata = !cfg_en ? 32'd0 : (dsel_q == 32'd0) ? dev_feat[31:0] :
                                                      (dsel_q == 32'd1) ? dev_feat[63:32] : 32'd0;
      silicaflux_virtio_pkg::R_QUEUE_NUM_MAX: rdata = (cfg_en && qsel_q == 32'd0) ? 32'(MAX_QSZ) : 32'd0;
      silicaflux_virtio_pkg::R_QUEUE_READY:   rdata = {31'd0, cfg_en && qsel_q == 32'd0 && qready_q};
      silicaflux_virtio_pkg::R_INT_STATUS:    rdata = cfg_en ? {30'd0, int_q} : 32'd0;
      silicaflux_virtio_pkg::R_STATUS:        rdata = cfg_en ? {24'd0, status_q} : 32'd0;
      silicaflux_virtio_pkg::R_CONFIG_GEN:    rdata = 32'd0;                       // the configuration never changes while in use
      silicaflux_virtio_pkg::CFG_CAPACITY_LO: rdata = cfg_en ? cfg_cap[31:0]  : 32'd0;
      silicaflux_virtio_pkg::CFG_CAPACITY_HI: rdata = cfg_en ? cfg_cap[63:32] : 32'd0;
      silicaflux_virtio_pkg::CFG_SEG_MAX:     rdata = cfg_en ? 32'(MAX_CHAIN - 2) : 32'd0;
      silicaflux_virtio_pkg::CFG_BLK_SIZE:    rdata = cfg_en ? 32'(silicaflux_virtio_pkg::SECTOR_BYTES) : 32'd0;
      default:                                rdata = 32'd0;                       // write-only / not implemented: reads 0
    endcase
  end

  // ------------------------------------------------------------------ outputs
  assign status_o = status_q;
  assign qready   = qready_q;
  assign qnum     = qnum_q;
  assign q_desc   = desc_q;
  assign q_avail  = avail_q;
  assign q_used   = used_q;
  assign irq_o    = |int_q;
  assign rst_req  = rst_pend_q;
  assign in_use   = (status_q != 8'd0) || rst_pend_q;
  assign running  = cfg_en && ((status_q & S_DOK) != 8'd0) && ((status_q & (S_NRS | S_FLD)) == 8'd0) &&
                    !rst_pend_q && qready_q;

  wire wr_ok = wr_en && cfg_en && !rst_pend_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      status_q   <= 8'd0;
      dsel_q     <= 32'd0;
      hsel_q     <= 32'd0;
      qsel_q     <= 32'd0;
      dfeat_q    <= 64'd0;
      qnum_q     <= 16'd0;
      qready_q   <= 1'b0;
      desc_q     <= 64'd0;
      avail_q    <= 64'd0;
      used_q     <= 64'd0;
      int_q      <= 2'b00;
      rst_pend_q <= 1'b0;
      kick       <= 1'b0;
      drv_ok_evt <= 1'b0;
    end else begin
      kick       <= 1'b0;
      drv_ok_evt <= 1'b0;

      // engine -> function events (accepted unless a reset is under way)
      if (irq_set && !rst_pend_q)   int_q[0] <= 1'b1;
      if (fatal_set && !rst_pend_q) begin
        status_q <= status_q | S_NRS;
        int_q[1] <= 1'b1;
      end

      if (rst_pend_q && rst_ack) begin
        status_q   <= 8'd0;
        dsel_q     <= 32'd0;
        hsel_q     <= 32'd0;
        qsel_q     <= 32'd0;
        dfeat_q    <= 64'd0;
        qnum_q     <= 16'd0;
        qready_q   <= 1'b0;
        desc_q     <= 64'd0;
        avail_q    <= 64'd0;
        used_q     <= 64'd0;
        int_q      <= 2'b00;
        rst_pend_q <= 1'b0;
      end else if (wr_ok) begin
        case (addr)
          silicaflux_virtio_pkg::R_DEV_FEAT_SEL: dsel_q <= wdata;
          silicaflux_virtio_pkg::R_DRV_FEAT_SEL: hsel_q <= wdata;
          silicaflux_virtio_pkg::R_DRV_FEATURES: begin
            if ((status_q & S_FOK) == 8'd0) begin                            // frozen once FEATURES_OK is set
              if (hsel_q == 32'd0) dfeat_q[31:0]  <= wdata;
              if (hsel_q == 32'd1) dfeat_q[63:32] <= wdata;
            end
          end
          silicaflux_virtio_pkg::R_QUEUE_SEL: qsel_q <= wdata;
          silicaflux_virtio_pkg::R_QUEUE_NUM:  if (qsel_q == 32'd0 && !qready_q) qnum_q <= wdata[15:0];
          silicaflux_virtio_pkg::R_QUEUE_READY: begin
            if (qsel_q == 32'd0 && wdata[0] && !qready_q && ((status_q & S_FOK) != 8'd0) && q_valid)
              qready_q <= 1'b1;
          end
          silicaflux_virtio_pkg::R_QUEUE_NOTIFY: if (wdata[15:0] == 16'd0) kick <= 1'b1;
          silicaflux_virtio_pkg::R_INT_ACK:      int_q <= int_q & ~wdata[1:0];
          silicaflux_virtio_pkg::R_STATUS: begin
            if (wdata[7:0] == 8'd0) begin
              rst_pend_q <= 1'b1;
            end else begin
              status_q <= st_next;
              if (((st_next & S_DOK) != 8'd0) && ((status_q & S_DOK) == 8'd0)) drv_ok_evt <= 1'b1;
            end
          end
          silicaflux_virtio_pkg::R_QUEUE_DESC_LO: if (qsel_q == 32'd0 && !qready_q) desc_q[31:0]   <= wdata;
          silicaflux_virtio_pkg::R_QUEUE_DESC_HI: if (qsel_q == 32'd0 && !qready_q) desc_q[63:32]  <= wdata;
          silicaflux_virtio_pkg::R_QUEUE_DRV_LO:  if (qsel_q == 32'd0 && !qready_q) avail_q[31:0]  <= wdata;
          silicaflux_virtio_pkg::R_QUEUE_DRV_HI:  if (qsel_q == 32'd0 && !qready_q) avail_q[63:32] <= wdata;
          silicaflux_virtio_pkg::R_QUEUE_DEV_LO:  if (qsel_q == 32'd0 && !qready_q) used_q[31:0]   <= wdata;
          silicaflux_virtio_pkg::R_QUEUE_DEV_HI:  if (qsel_q == 32'd0 && !qready_q) used_q[63:32]  <= wdata;
          default: ;
        endcase
      end
    end
  end
endmodule

`default_nettype wire
