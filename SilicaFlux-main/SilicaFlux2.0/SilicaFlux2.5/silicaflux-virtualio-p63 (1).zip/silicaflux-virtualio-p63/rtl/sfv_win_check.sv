// =============================================================================
// VirtualIO :: sfv_win_check -- is [addr, addr+len) inside ONE window of a domain that grants the needed permission?
// Combinational.  `contained` = some valid window holds the whole range (any permission);  `ok` = and it grants the
// permissions asked for.  A zero-length range never matches.  A range that straddles two adjacent windows is refused
// (it must lie inside one window).  64-bit base/size arithmetic is done in 65 bits, so nothing can wrap.
// ctl bits per window: [0] R, [1] W, [2] valid  (silicaflux_virtio_pkg::WC_*)
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfv_win_check #(
  parameter int NW = 4
) (
  input  wire logic [NW*64-1:0] base,
  input  wire logic [NW*64-1:0] size,
  input  wire logic [NW*3-1:0]  ctl,
  input  wire logic [63:0]      addr,
  input  wire logic [31:0]      len,
  input  wire logic             need_r,
  input  wire logic             need_w,
  output logic                  contained,
  output logic                  ok
);
  logic [NW-1:0] cont, perm;
  wire  [64:0]   a_end = {1'b0, addr} + {33'd0, len};
  genvar w;
  generate
    for (w = 0; w < NW; w++) begin : g_win
      wire [63:0] wb    = base[w*64 +: 64];
      wire [64:0] w_end = {1'b0, wb} + {1'b0, size[w*64 +: 64]};
      assign cont[w] = ctl[w*3 + silicaflux_virtio_pkg::WC_V] && (len != 32'd0) &&
                       (addr >= wb) && (a_end <= w_end);
      assign perm[w] = (!need_r || ctl[w*3 + silicaflux_virtio_pkg::WC_R]) &&
                       (!need_w || ctl[w*3 + silicaflux_virtio_pkg::WC_W]);
    end
  endgenerate
  assign contained = |cont;
  assign ok        = |(cont & perm);
endmodule

`default_nettype wire
