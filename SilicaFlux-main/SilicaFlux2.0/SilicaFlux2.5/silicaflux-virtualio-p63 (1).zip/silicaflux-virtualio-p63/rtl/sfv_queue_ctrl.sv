// =============================================================================
// VirtualIO :: sfv_queue_ctrl -- SPLIT-VIRTQUEUE CONTROLLER (spec 2.7.6 / 2.7.8 / 2.7.7), one request at a time
//
// Serves every function round-robin, one complete request per slot.  For the function it serves:
//
//   1. poll      read avail {flags, idx} (4 bytes); outstanding = idx - last_avail (mod 2^16).
//                outstanding > queue size  ->  FATAL FC_AVAIL_OVERRUN.   0 -> nothing to do: go idle.
//   2. head      read ring[last_avail % size]; head >= size -> FATAL FC_BAD_HEAD.
//   3. walk      sfv_desc_walker validates the chain (cycles, length, flags, indirect, order, bounds).
//   4. execute   sfv_blk_exec performs the virtio-blk request and writes the status byte.
//   5. complete  write used.ring[used_idx % size] = {id = head, len = bytes written to device-writable buffers}, wait for
//                the write to be ACKNOWLEDGED, THEN write used.idx = used_idx + 1 and wait for that too.
//                -> a used entry is never visible before the request (data AND status) is complete, and the idx never
//                   advances before its entry is in memory.
//   6. notify    re-poll avail (this is also the next iteration's step 1).  If avail.flags has NO_INTERRUPT (bit 0) the
//                interrupt for the completion just published is suppressed, otherwise INT_VRING is raised.  Only
//                NO_INTERRUPT is honoured; VIRTIO_F_EVENT_IDX is not offered and used.flags (NO_NOTIFY) is never written.
//
// Ownership: exactly one head is owned by the device between step 2 and step 5 (head_q); the used entry id is always
// that head.  A FATAL fault (structural violation, refused or failed ring/descriptor/status access) completes nothing: the
// function gets NEEDS_RESET + a configuration-change interrupt and is not served again until the driver resets it.
// Quarantine policy: a request that completed with a data-path isolation violation is published (status IOERR) and then
// the function is stopped the same way, if its management `quarantine` flag is set.
// Reset / failure of the served function aborts the request at the next beat boundary and writes nothing further.
//
// Nothing is consumed or notified before DRIVER_OK (f_running).  Doorbells / DRIVER_OK only set `pend`; a doorbell that
// arrives while a request is running is not lost (pend is re-armed).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfv_queue_ctrl #(
  parameter int NF        = 1,
  parameter int FW        = 1,
  parameter int DOMW      = 1,
  parameter int MAX_QSZ   = 64,
  parameter int MAX_CHAIN = 8,
  parameter int STAGE     = 64
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // per function
  input  wire logic [NF-1:0]       f_running,
  input  wire logic [NF-1:0]       f_kick,
  input  wire logic [NF-1:0]       f_drv_ok_evt,
  input  wire logic [NF-1:0]       f_rst_req,
  input  wire logic [NF*16-1:0]    f_qnum,
  input  wire logic [NF*64-1:0]    f_desc,
  input  wire logic [NF*64-1:0]    f_avail,
  input  wire logic [NF*64-1:0]    f_used,
  input  wire logic [NF*DOMW-1:0]  f_dom,
  input  wire logic [NF*64-1:0]    f_cap,
  input  wire logic [NF-1:0]       f_ro,
  input  wire logic [NF-1:0]       f_quar,
  output logic [NF-1:0]            f_rst_ack,
  output logic [NF-1:0]            f_fatal_set,
  output logic [NF-1:0]            f_irq_set,
  // guest-DMA unit
  output logic                     cmd_valid,
  output logic                     cmd_tgt,
  output logic                     cmd_wr,
  output logic                     cmd_data,
  output logic [DOMW-1:0]          cmd_dom,
  output logic [63:0]              cmd_addr,
  output logic [15:0]              cmd_len,
  output logic [$clog2(STAGE)-1:0] cmd_soff,
  input  wire logic                cmd_ready,
  input  wire logic                cmd_done,
  input  wire logic                cmd_err,
  input  wire logic [7:0]          cmd_code,
  input  wire logic [7:0]          cmd_detail,
  output logic                     abort_o,
  output logic                     ld_en,
  output logic [127:0]             ld_data,
  output logic [15:0]              ld_mask,
  input  wire logic [127:0]        pk_data,
  // fault report (pulse)
  output logic                     flt_v,
  output logic [FW-1:0]            flt_f,
  output logic [7:0]               flt_code,
  output logic [7:0]               flt_detail,
  // observation
  output logic [NF*16-1:0]         o_last_avail,
  output logic [NF*16-1:0]         o_used_idx,
  output logic [NF-1:0]            o_pend,
  output logic [FW-1:0]            o_cf,
  output logic                     o_busy,
  // performance events (attributed to o_cf)
  output logic                     p_req_done,
  output logic                     p_req_err,
  output logic [31:0]              p_lat,
  output logic                     p_walk_v,
  output logic [15:0]              p_walk,
  output logic [15:0]              p_ndesc,
  output logic                     p_irq,
  output logic                     p_irq_supp,
  output logic                     p_viol,
  output logic                     p_fatal,
  output logic                     p_util_v,
  output logic [15:0]              p_util,
  output logic [NF-1:0]            p_wait
);
  localparam int SAW = $clog2(STAGE);
  localparam logic [4:0] Q_IDLE = 5'd0,  Q_AV_CMD = 5'd1,  Q_AV_WAIT = 5'd2,  Q_AV_EVAL = 5'd3, Q_HD_CMD = 5'd4,
                         Q_HD_WAIT = 5'd5, Q_WK_GO = 5'd6, Q_WK_RUN = 5'd7,   Q_EX_GO = 5'd8,   Q_EX_RUN = 5'd9,
                         Q_UE_LD = 5'd10, Q_UE_CMD = 5'd11, Q_UE_WAIT = 5'd12, Q_UI_LD = 5'd13, Q_UI_CMD = 5'd14,
                         Q_UI_WAIT = 5'd15, Q_FATAL = 5'd16, Q_ABORT = 5'd17;

  logic [4:0]       st_q;
  logic [FW-1:0]    cf_q, rr_q;
  logic [15:0]      la_q [0:NF-1];
  logic [15:0]      ui_q [0:NF-1];
  logic [NF-1:0]    pend_q, due_q;

  // values of the served function, latched at selection
  logic [15:0]      qsz_q;
  logic [63:0]      desc_q, avail_q, used_q, cap_q;
  logic [DOMW-1:0]  dom_q;
  logic             ro_q, quar_q;

  logic [15:0]      head_q;
  logic [31:0]      ulen_q;
  logic [7:0]       exst_q;
  logic             exviol_q, counted_q;
  logic [7:0]       fcode_q, fdet_q;
  logic [31:0]      lat_q;

  // ------------------------------------------------------------------ child blocks
  logic              wk_go, wk_done, wk_err, wk_gvalid;
  logic [63:0]       wk_gaddr;
  logic [7:0]        wk_code, wk_nseg, wk_nrd;
  logic [15:0]       wk_ndesc, wk_cyc;
  logic [MAX_CHAIN*64-1:0] wk_sa;
  logic [MAX_CHAIN*32-1:0] wk_sl;
  logic [39:0]       wk_trd, wk_twr;
  logic              ex_go, ex_done, ex_fatal, ex_viol, ex_gvalid, ex_gtgt, ex_gwr, ex_gdata, ex_ld_en;
  logic [7:0]        ex_fcode, ex_status;
  logic [31:0]       ex_ulen;
  logic [63:0]       ex_gaddr;
  logic [15:0]       ex_glen;
  logic [SAW-1:0]    ex_gsoff;
  logic [127:0]      ex_ld_data;
  logic [15:0]       ex_ld_mask;

  wire kill = (st_q != Q_IDLE) && (st_q != Q_ABORT) && (st_q != Q_FATAL) && !f_running[cf_q];

  sfv_desc_walker #(.MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN)) u_walk (
    .clk, .rst_n, .kill, .go(wk_go), .head(head_q), .qsize(qsz_q), .desc_base(desc_q),
    .g_valid(wk_gvalid), .g_addr(wk_gaddr), .g_ready(cmd_ready && st_q == Q_WK_RUN), .g_done(cmd_done && st_q == Q_WK_RUN),
    .g_err(cmd_err), .g_code(cmd_code), .pk_data,
    .done(wk_done), .err(wk_err), .errcode(wk_code), .ndesc(wk_ndesc), .walk_cycles(wk_cyc),
    .nseg(wk_nseg), .nrd(wk_nrd), .seg_addr(wk_sa), .seg_len(wk_sl), .tot_rd(wk_trd), .tot_wr(wk_twr));

  sfv_blk_exec #(.MAX_CHAIN(MAX_CHAIN), .STAGE(STAGE)) u_exec (
    .clk, .rst_n, .kill, .go(ex_go), .cap_sectors(cap_q), .ro(ro_q),
    .nseg(wk_nseg), .nrd(wk_nrd), .seg_addr(wk_sa), .seg_len(wk_sl), .tot_rd(wk_trd), .tot_wr(wk_twr),
    .g_valid(ex_gvalid), .g_tgt(ex_gtgt), .g_wr(ex_gwr), .g_data(ex_gdata), .g_addr(ex_gaddr), .g_len(ex_glen), .g_soff(ex_gsoff),
    .g_ready(cmd_ready && st_q == Q_EX_RUN), .g_done(cmd_done && st_q == Q_EX_RUN), .g_err(cmd_err), .g_code(cmd_code),
    .ld_en(ex_ld_en), .ld_data(ex_ld_data), .ld_mask(ex_ld_mask), .pk_data,
    .done(ex_done), .fatal(ex_fatal), .fatal_code(ex_fcode), .used_len(ex_ulen), .viol(ex_viol), .status(ex_status));

  // ------------------------------------------------------------------ arbitration
  logic          sel_v;
  logic [FW-1:0] sel_f;
  always_comb begin
    integer i;
    logic [FW-1:0] k;
    sel_v = 1'b0;
    sel_f = '0;
    for (i = 0; i < NF; i++) begin
      k = FW'((32'(rr_q) + i) % NF);
      if (!sel_v && f_running[k] && pend_q[k] && !f_rst_req[k]) begin
        sel_v = 1'b1;
        sel_f = k;
      end
    end
  end

  // pend is cleared when a poll of the function starts (IDLE -> AV_CMD, or the re-poll after a completion), on a fatal fault and on reset
  logic [NF-1:0] pend_clr;
  always_comb begin
    integer f;
    for (f = 0; f < NF; f++)
      pend_clr[f] = f_rst_ack[f] ||
                    ((st_q == Q_IDLE)    && sel_v && (32'(sel_f) == f)) ||
                    ((st_q == Q_UI_WAIT) && cmd_done && !cmd_err && (32'(cf_q) == f)) ||
                    ((st_q == Q_FATAL)   && (32'(cf_q) == f));
  end

  // reset acknowledge: immediate for an idle engine or another function; the served function is aborted first
  always_comb begin
    integer f;
    for (f = 0; f < NF; f++)
      f_rst_ack[f] = f_rst_req[f] && ((st_q == Q_IDLE) || (32'(cf_q) != f));
  end

  // ------------------------------------------------------------------ command / stage multiplexing
  // avail snapshot, valid in Q_AV_EVAL (the stage holds the poll result)
  wire        av_nointr = pk_data[0];            // avail.flags bit 0: VIRTQ_AVAIL_F_NO_INTERRUPT (other bits ignored)
  wire [15:0] av_idx   = pk_data[31:16];
  wire [15:0] qmask  = qsz_q - 16'd1;
  wire [15:0] la_cur = la_q[cf_q];
  wire [15:0] ui_cur = ui_q[cf_q];
  always_comb begin
    cmd_valid = 1'b0;
    cmd_tgt   = 1'b0;
    cmd_wr    = 1'b0;
    cmd_data  = 1'b0;
    cmd_dom   = dom_q;
    cmd_addr  = 64'd0;
    cmd_len   = 16'd0;
    cmd_soff  = '0;
    ld_en     = 1'b0;
    ld_data   = 128'd0;
    ld_mask   = 16'd0;
    case (st_q)
      Q_AV_CMD: begin cmd_valid = 1'b1; cmd_addr = avail_q; cmd_len = 16'd4; end
      Q_HD_CMD: begin cmd_valid = 1'b1; cmd_addr = avail_q + 64'd4 + {47'd0, (la_cur & qmask), 1'b0}; cmd_len = 16'd2; end
      Q_WK_RUN: begin cmd_valid = wk_gvalid; cmd_addr = wk_gaddr; cmd_len = 16'd16; end
      Q_EX_RUN: begin
        cmd_valid = ex_gvalid; cmd_tgt = ex_gtgt; cmd_wr = ex_gwr; cmd_data = ex_gdata;
        cmd_addr = ex_gaddr; cmd_len = ex_glen; cmd_soff = ex_gsoff;
        ld_en = ex_ld_en; ld_data = ex_ld_data; ld_mask = ex_ld_mask;
      end
      Q_UE_LD: begin ld_en = 1'b1; ld_data = {64'd0, ulen_q, 16'd0, head_q}; ld_mask = 16'h00FF; end   // le32 id, le32 len
      Q_UE_CMD: begin
        cmd_valid = 1'b1; cmd_wr = 1'b1; cmd_len = 16'd8;
        cmd_addr  = used_q + 64'd4 + {45'd0, (ui_cur & qmask), 3'd0};
      end
      Q_UI_LD: begin ld_en = 1'b1; ld_data = {112'd0, ui_cur + 16'd1}; ld_mask = 16'h0003; end
      Q_UI_CMD: begin cmd_valid = 1'b1; cmd_wr = 1'b1; cmd_addr = used_q + 64'd2; cmd_len = 16'd2; end
      default: ;
    endcase
  end

  assign wk_go   = (st_q == Q_WK_GO);
  assign ex_go   = (st_q == Q_EX_GO);
  assign abort_o = (st_q == Q_ABORT);
  assign o_cf    = cf_q;
  assign o_busy  = (st_q != Q_IDLE);

  genvar g;
  generate
    for (g = 0; g < NF; g++) begin : g_obs
      assign o_last_avail[g*16 +: 16] = la_q[g];
      assign o_used_idx[g*16 +: 16]   = ui_q[g];
      assign p_wait[g] = pend_q[g] && f_running[g] && !((st_q != Q_IDLE) && (32'(cf_q) == g));
      assign f_fatal_set[g] = (st_q == Q_FATAL) && (32'(cf_q) == g);
      assign f_irq_set[g]   = (st_q == Q_AV_EVAL) && (32'(cf_q) == g) && due_q[g] && !av_nointr;
    end
  endgenerate
  assign o_pend = pend_q;

  wire [15:0] n_av     = av_idx - la_cur;

  // events
  assign p_irq      = (st_q == Q_AV_EVAL) && due_q[cf_q] && !av_nointr;
  assign p_irq_supp = (st_q == Q_AV_EVAL) && due_q[cf_q] &&  av_nointr;
  assign p_util_v   = (st_q == Q_AV_EVAL);
  assign p_util     = n_av;
  assign p_walk_v   = (st_q == Q_WK_RUN) && wk_done && !wk_err;
  assign p_walk     = wk_cyc;
  assign p_ndesc    = wk_ndesc;
  assign p_fatal    = (st_q == Q_FATAL);
  assign p_viol     = ((st_q == Q_FATAL) && (fcode_q == silicaflux_virtio_pkg::FC_DMA_DENIED) && !counted_q) ||
                      ((st_q == Q_UI_WAIT) && cmd_done && !cmd_err && exviol_q);
  assign p_req_done = (st_q == Q_UI_WAIT) && cmd_done && !cmd_err;
  assign p_req_err  = p_req_done && (exst_q != silicaflux_virtio_pkg::BLK_S_OK);
  assign p_lat      = lat_q + 32'd1;

  assign flt_v      = (st_q == Q_FATAL);
  assign flt_f      = cf_q;
  assign flt_code   = fcode_q;
  assign flt_detail = fdet_q;

  // ------------------------------------------------------------------ sequencer
  always_ff @(posedge clk or negedge rst_n) begin
    integer f;
    if (!rst_n) begin
      st_q      <= Q_IDLE;
      cf_q      <= '0;
      rr_q      <= '0;
      pend_q    <= '0;
      due_q     <= '0;
      qsz_q     <= 16'd0;
      desc_q    <= 64'd0;
      avail_q   <= 64'd0;
      used_q    <= 64'd0;
      cap_q     <= 64'd0;
      dom_q     <= '0;
      ro_q      <= 1'b0;
      quar_q    <= 1'b0;
      head_q    <= 16'd0;
      ulen_q    <= 32'd0;
      exst_q    <= 8'd0;
      exviol_q  <= 1'b0;
      counted_q <= 1'b0;
      fcode_q   <= silicaflux_virtio_pkg::FC_NONE;
      fdet_q    <= silicaflux_virtio_pkg::DD_OK;
      lat_q     <= 32'd0;
      for (f = 0; f < NF; f++) begin
        la_q[f] <= 16'd0;
        ui_q[f] <= 16'd0;
      end
    end else begin
      // a successful reset of a function clears its queue state (pend is handled below)
      for (f = 0; f < NF; f++)
        if (f_rst_ack[f]) begin
          la_q[f]    <= 16'd0;
          ui_q[f]    <= 16'd0;
          due_q[f]   <= 1'b0;
        end

      if (st_q >= Q_HD_CMD && st_q <= Q_UI_WAIT) lat_q <= lat_q + 32'd1;
      if (cmd_done && cmd_err && cmd_code == silicaflux_virtio_pkg::GD_DENIED) fdet_q <= cmd_detail;

      if (kill) begin
        st_q <= Q_ABORT;
      end else begin
        case (st_q)
          Q_IDLE: begin
            if (sel_v) begin
              cf_q      <= sel_f;
              rr_q      <= (32'(sel_f) + 1 >= NF) ? '0 : FW'(32'(sel_f) + 1);
              qsz_q     <= f_qnum[sel_f*16 +: 16];
              desc_q    <= f_desc[sel_f*64 +: 64];
              avail_q   <= f_avail[sel_f*64 +: 64];
              used_q    <= f_used[sel_f*64 +: 64];
              cap_q     <= f_cap[sel_f*64 +: 64];
              dom_q     <= f_dom[sel_f*DOMW +: DOMW];
              ro_q      <= f_ro[sel_f];
              quar_q    <= f_quar[sel_f];
              fdet_q    <= silicaflux_virtio_pkg::DD_OK;
              st_q      <= Q_AV_CMD;
            end
          end
          Q_AV_CMD: if (cmd_ready) st_q <= Q_AV_WAIT;
          Q_AV_WAIT: begin
            if (cmd_done) begin
              if (cmd_err) begin
                fcode_q   <= silicaflux_virtio_pkg::gd_is_violation(cmd_code) ? silicaflux_virtio_pkg::FC_DMA_DENIED
                                                                              : silicaflux_virtio_pkg::FC_GUEST_BUS;
                counted_q <= 1'b0;
                st_q      <= Q_FATAL;
              end else st_q <= Q_AV_EVAL;
            end
          end
          Q_AV_EVAL: begin
            due_q[cf_q] <= 1'b0;                          // the completion just published has now been notified (or suppressed)
            lat_q       <= 32'd0;
            counted_q   <= 1'b0;
            if (n_av > qsz_q) begin
              fcode_q <= silicaflux_virtio_pkg::FC_AVAIL_OVERRUN;
              st_q    <= Q_FATAL;
            end else if (n_av == 16'd0) begin
              st_q <= Q_IDLE;                              // pend was cleared when this poll STARTED: a doorbell that arrived since stays armed
            end else begin
              st_q <= Q_HD_CMD;
            end
          end
          Q_HD_CMD: if (cmd_ready) st_q <= Q_HD_WAIT;
          Q_HD_WAIT: begin
            if (cmd_done) begin
              if (cmd_err) begin
                fcode_q <= silicaflux_virtio_pkg::gd_is_violation(cmd_code) ? silicaflux_virtio_pkg::FC_DMA_DENIED
                                                                            : silicaflux_virtio_pkg::FC_GUEST_BUS;
                st_q    <= Q_FATAL;
              end else if (pk_data[15:0] >= qsz_q) begin
                fcode_q <= silicaflux_virtio_pkg::FC_BAD_HEAD;
                st_q    <= Q_FATAL;
              end else begin
                head_q <= pk_data[15:0];
                st_q   <= Q_WK_GO;
              end
            end
          end
          Q_WK_GO: st_q <= Q_WK_RUN;
          Q_WK_RUN: begin
            if (wk_done) begin
              if (wk_err) begin
                fcode_q <= wk_code;
                st_q    <= Q_FATAL;
              end else st_q <= Q_EX_GO;
            end
          end
          Q_EX_GO: st_q <= Q_EX_RUN;
          Q_EX_RUN: begin
            if (ex_done) begin
              if (ex_fatal) begin
                fcode_q <= ex_fcode;
                st_q    <= Q_FATAL;
              end else begin
                ulen_q   <= ex_ulen;
                exst_q   <= ex_status;
                exviol_q <= ex_viol;
                st_q     <= Q_UE_LD;
              end
            end
          end
          Q_UE_LD:  st_q <= Q_UE_CMD;
          Q_UE_CMD: if (cmd_ready) st_q <= Q_UE_WAIT;
          Q_UE_WAIT: begin
            if (cmd_done) begin
              if (cmd_err) begin
                fcode_q <= silicaflux_virtio_pkg::gd_is_violation(cmd_code) ? silicaflux_virtio_pkg::FC_DMA_DENIED
                                                                            : silicaflux_virtio_pkg::FC_GUEST_BUS;
                st_q    <= Q_FATAL;
              end else st_q <= Q_UI_LD;
            end
          end
          Q_UI_LD:  st_q <= Q_UI_CMD;
          Q_UI_CMD: if (cmd_ready) st_q <= Q_UI_WAIT;
          Q_UI_WAIT: begin
            if (cmd_done) begin
              if (cmd_err) begin
                fcode_q <= silicaflux_virtio_pkg::gd_is_violation(cmd_code) ? silicaflux_virtio_pkg::FC_DMA_DENIED
                                                                            : silicaflux_virtio_pkg::FC_GUEST_BUS;
                st_q    <= Q_FATAL;
              end else begin
                ui_q[cf_q]  <= ui_q[cf_q] + 16'd1;
                la_q[cf_q]  <= la_q[cf_q] + 16'd1;
                due_q[cf_q] <= 1'b1;
                if (exviol_q && quar_q) begin               // published; now stop the function
                  fcode_q   <= silicaflux_virtio_pkg::FC_DMA_DENIED;
                  counted_q <= 1'b1;
                  st_q      <= Q_FATAL;
                end else st_q <= Q_AV_CMD;
              end
            end
          end
          Q_FATAL: st_q <= Q_IDLE;
          Q_ABORT: begin
            if (cmd_ready) st_q <= Q_IDLE;
          end
          default: st_q <= Q_IDLE;
        endcase
      end

      // ---- pend: set by a doorbell or DRIVER_OK; cleared when a ring poll STARTS (so a doorbell that lands while the poll
      //      is in flight re-arms it and is never lost), on a fatal fault and on a function reset.  A set in the same cycle
      //      as a clear WINS.
      for (f = 0; f < NF; f++) begin
        if (pend_clr[f]) pend_q[f] <= 1'b0;
        if (f_kick[f] || f_drv_ok_evt[f]) pend_q[f] <= 1'b1;
      end
    end
  end

  wire unused_qc = &{1'b0, av_idx[0], wk_nseg[0]};
endmodule

`default_nettype wire
