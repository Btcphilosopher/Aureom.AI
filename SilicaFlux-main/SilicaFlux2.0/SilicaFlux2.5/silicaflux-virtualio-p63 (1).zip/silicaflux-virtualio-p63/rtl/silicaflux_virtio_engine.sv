// =============================================================================
// SilicaFlux VirtualIO (Project 63) :: silicaflux_virtio_engine -- PRIMARY RTL
//
// Virtual-machine I/O acceleration for the SilicaFlux CloudDPU: a VirtIO block device (virtio-mmio v2, split virtqueue,
// VIRTIO_F_VERSION_1) whose requests are fetched from guest memory, validated, and executed by the DPU against a
// PROTECTED backend (per-domain partitions of a volatile block store), with every guest-memory access checked against the
// permission table of the function's DMA domain.
//
// This wrapper = sfv_engine_core + sfv_ramdisk.  To use another backend (e.g. the CloudDPU's tenant SRAM partitions through
// the DPU fabric), instantiate sfv_engine_core directly and attach to its bk_* / pc_* ports.
//
// Features offered (and ONLY these): VIRTIO_F_VERSION_1, VIRTIO_BLK_F_SEG_MAX, VIRTIO_BLK_F_BLK_SIZE, VIRTIO_BLK_F_RO
// (when the function is configured read-only), VIRTIO_F_ACCESS_PLATFORM (only with EXT_IOMMU = 1).  Not offered, not
// implemented: packed rings, indirect descriptors, EVENT_IDX, IN_ORDER, multiqueue, FLUSH, DISCARD, WRITE_ZEROES, SIZE_MAX.
//
// Scope and honesty: simulation + generic-synthesis evidence only (docs/VERIFICATION.md, docs/SYNTHESIS.md); no PCIe, no
// SR-IOV, no real IOMMU, no hardware.  See docs/LIMITATIONS.md.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module silicaflux_virtio_engine #(
  parameter int NUM_FUNCS   = 1,
  parameter int NUM_DOMAINS = 2,
  parameter int NUM_WIN     = 4,
  parameter int MAX_QSZ     = 64,
  parameter int MAX_CHAIN   = 8,
  parameter int STAGE_BYTES = 64,
  parameter int ADDR_WIDTH  = 48,
  parameter int DATA_WIDTH  = 64,
  parameter int STORE_BYTES = 65536,
  parameter int EXT_IOMMU   = 0
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // guest virtio-mmio (one 4 KiB window per function)
  input  wire logic              mmio_req_valid,
  output logic                   mmio_req_ready,
  input  wire logic              mmio_req_write,
  input  wire logic [15:0]       mmio_req_addr,
  input  wire logic [31:0]       mmio_req_wdata,
  output logic                   mmio_rsp_valid,
  output logic [31:0]            mmio_rsp_rdata,
  output logic                   mmio_rsp_err,
  output logic [NUM_FUNCS-1:0]   irq_o,
  // management
  input  wire logic              mg_req_valid,
  output logic                   mg_req_ready,
  input  wire logic              mg_req_write,
  input  wire logic [11:0]       mg_req_addr,
  input  wire logic [31:0]       mg_req_wdata,
  output logic                   mg_rsp_valid,
  output logic [31:0]            mg_rsp_rdata,
  output logic                   mg_rsp_err,
  output logic                   mgmt_irq_o,
  // guest memory master (SFB2)
  output logic                   gm_req_valid,
  input  wire logic              gm_req_ready,
  output logic                   gm_req_write,
  output logic [ADDR_WIDTH-1:0]  gm_req_addr,
  output logic [DATA_WIDTH-1:0]  gm_req_wdata,
  output logic [DATA_WIDTH/8-1:0] gm_req_wstrb,
  input  wire logic              gm_rsp_valid,
  output logic                   gm_rsp_ready,
  input  wire logic [DATA_WIDTH-1:0] gm_rsp_rdata,
  input  wire logic              gm_rsp_error,
  // external IOMMU (EXT_IOMMU = 1; tie inputs low otherwise)
  output logic                   iommu_req_valid,
  input  wire logic              iommu_req_ready,
  output logic [$clog2(NUM_DOMAINS > 1 ? NUM_DOMAINS : 2)-1:0] iommu_req_dom,
  output logic [63:0]            iommu_req_iova,
  output logic [31:0]            iommu_req_len,
  output logic                   iommu_req_write,
  input  wire logic              iommu_rsp_valid,
  input  wire logic              iommu_rsp_ok,
  input  wire logic [ADDR_WIDTH-1:0] iommu_rsp_pa
);
  localparam int DOMW = (NUM_DOMAINS > 1) ? $clog2(NUM_DOMAINS) : 1;
  localparam int BKAW = 32;

  logic                bk_req_valid, bk_req_ready, bk_req_write, bk_rsp_valid, bk_rsp_ready, bk_rsp_error;
  logic [BKAW-1:0]     bk_req_addr;
  logic [DATA_WIDTH-1:0] bk_req_wdata, bk_rsp_rdata;
  logic [DATA_WIDTH/8-1:0] bk_req_wstrb;
  logic [DOMW-1:0]     bk_req_dom, pc_dom;
  logic                pc_valid, pc_en, pc_scrub, pc_ok;
  logic [31:0]         pc_base, pc_size;
  logic [NUM_DOMAINS-1:0]    part_en, part_busy;
  logic [NUM_DOMAINS*32-1:0] part_size;

  sfv_engine_core #(.NF(NUM_FUNCS), .ND(NUM_DOMAINS), .NW(NUM_WIN), .MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN),
                    .STAGE(STAGE_BYTES), .AW(ADDR_WIDTH), .DW(DATA_WIDTH), .BKAW(BKAW), .EXT_IOMMU(EXT_IOMMU),
                    .STORE_BYTES(STORE_BYTES)) u_core (
    .clk, .rst_n,
    .mmio_req_valid, .mmio_req_ready, .mmio_req_write, .mmio_req_addr, .mmio_req_wdata,
    .mmio_rsp_valid, .mmio_rsp_rdata, .mmio_rsp_err, .irq_o,
    .mg_req_valid, .mg_req_ready, .mg_req_write, .mg_req_addr, .mg_req_wdata,
    .mg_rsp_valid, .mg_rsp_rdata, .mg_rsp_err, .mgmt_irq_o,
    .gm_req_valid, .gm_req_ready, .gm_req_write, .gm_req_addr, .gm_req_wdata, .gm_req_wstrb,
    .gm_rsp_valid, .gm_rsp_ready, .gm_rsp_rdata, .gm_rsp_error,
    .bk_req_valid, .bk_req_ready, .bk_req_write, .bk_req_addr, .bk_req_wdata, .bk_req_wstrb, .bk_req_dom,
    .bk_rsp_valid, .bk_rsp_ready, .bk_rsp_rdata, .bk_rsp_error,
    .pc_valid, .pc_dom, .pc_base, .pc_size, .pc_en, .pc_scrub, .pc_ok,
    .part_en_i(part_en), .part_busy_i(part_busy), .part_size_i(part_size),
    .iommu_req_valid, .iommu_req_ready, .iommu_req_dom, .iommu_req_iova, .iommu_req_len, .iommu_req_write,
    .iommu_rsp_valid, .iommu_rsp_ok, .iommu_rsp_pa);

  sfv_ramdisk #(.DW(DATA_WIDTH), .AW(BKAW), .STORE_BYTES(STORE_BYTES), .ND(NUM_DOMAINS), .DOMW(DOMW)) u_store (
    .clk, .rst_n,
    .s_req_valid(bk_req_valid), .s_req_ready(bk_req_ready), .s_req_write(bk_req_write), .s_req_addr(bk_req_addr),
    .s_req_wdata(bk_req_wdata), .s_req_wstrb(bk_req_wstrb), .s_req_dom(bk_req_dom),
    .s_rsp_valid(bk_rsp_valid), .s_rsp_ready(bk_rsp_ready), .s_rsp_rdata(bk_rsp_rdata), .s_rsp_error(bk_rsp_error),
    .pc_valid, .pc_dom, .pc_base, .pc_size, .pc_en, .pc_scrub, .pc_ok,
    .part_en_o(part_en), .part_busy_o(part_busy), .part_size_o(part_size));
endmodule

`default_nettype wire
