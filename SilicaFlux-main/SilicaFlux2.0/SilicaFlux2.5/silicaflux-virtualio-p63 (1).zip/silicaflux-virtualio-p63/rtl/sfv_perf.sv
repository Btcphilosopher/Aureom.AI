// =============================================================================
// VirtualIO :: sfv_perf -- per-function performance counters (32 bit, free-running: they wrap at 2^32, read them before that)
//
// Counter ids and meanings: silicaflux_virtio_pkg::PC_*.  All events arrive as pulses / levels from the queue controller,
// the guest-DMA unit and the register blocks; nothing here influences the data path.  Reading: select {function, counter}
// and read `rd_data` (combinational).  `clr` zeroes every counter (and re-arms the latency minimum).
//   completion latency = cycles from the head fetch of a request to the completion of its used.idx write
//   descriptor-walk latency = cycles from the walker's go to its verdict
// "Queue stall" (PC_QSTALL) = cycles in which a function had work pending but the engine was serving another function
// or was idle between arbitration slots; "bus stall" (PC_BUS_STALL) = cycles the engine held a valid request that the
// guest memory / backend had not yet accepted.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfv_perf #(
  parameter int NF = 1,
  parameter int FW = 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clr,
  // selection / readout
  input  wire logic [FW-1:0]     rd_func,
  input  wire logic [7:0]        rd_ctr,
  output logic [31:0]            rd_data,
  // events attributed to the function being served
  input  wire logic [FW-1:0]     ev_cf,
  input  wire logic              ev_busy,          // level: engine serving ev_cf
  input  wire logic              ev_bus_stall,     // level
  input  wire logic              ev_req_done,
  input  wire logic              ev_req_err,
  input  wire logic [31:0]       ev_lat,           // valid with ev_req_done
  input  wire logic              ev_walk_v,
  input  wire logic [15:0]       ev_walk,
  input  wire logic [15:0]       ev_ndesc,         // valid with ev_walk_v
  input  wire logic              ev_irq,
  input  wire logic              ev_irq_supp,
  input  wire logic              ev_viol,
  input  wire logic              ev_fatal,
  input  wire logic              ev_util_v,
  input  wire logic [15:0]       ev_util,
  input  wire logic              ev_rd_data_v,
  input  wire logic              ev_wr_data_v,
  input  wire logic              ev_meta_v,
  input  wire logic [15:0]       ev_bytes,         // bytes of the data / meta event
  // per-function events
  input  wire logic [NF-1:0]     kick_v,
  input  wire logic [NF-1:0]     wait_v            // level: work pending but not being served
);
  localparam int N = silicaflux_virtio_pkg::PC_N;

  logic [31:0] c [0:NF-1][0:N-1];

  assign rd_data = (32'(rd_func) < NF && 32'(rd_ctr) < N) ? c[32'(rd_func) < NF ? 32'(rd_func) : 0][32'(rd_ctr) < N ? 32'(rd_ctr) : 0] : 32'd0;

  always_ff @(posedge clk or negedge rst_n) begin
    integer f, k;
    if (!rst_n) begin
      for (f = 0; f < NF; f++) begin
        for (k = 0; k < N; k++) c[f][k] <= 32'd0;
        c[f][silicaflux_virtio_pkg::PC_LAT_MIN] <= 32'hFFFF_FFFF;
      end
    end else if (clr) begin
      for (f = 0; f < NF; f++) begin
        for (k = 0; k < N; k++) c[f][k] <= 32'd0;
        c[f][silicaflux_virtio_pkg::PC_LAT_MIN] <= 32'hFFFF_FFFF;
      end
    end else begin
      for (f = 0; f < NF; f++) begin
        if (kick_v[f]) c[f][silicaflux_virtio_pkg::PC_KICKS] <= c[f][silicaflux_virtio_pkg::PC_KICKS] + 32'd1;
        if (wait_v[f]) c[f][silicaflux_virtio_pkg::PC_QSTALL] <= c[f][silicaflux_virtio_pkg::PC_QSTALL] + 32'd1;
        if (32'(ev_cf) == f) begin
          if (ev_busy)       c[f][silicaflux_virtio_pkg::PC_BUSY]      <= c[f][silicaflux_virtio_pkg::PC_BUSY] + 32'd1;
          if (ev_bus_stall)  c[f][silicaflux_virtio_pkg::PC_BUS_STALL] <= c[f][silicaflux_virtio_pkg::PC_BUS_STALL] + 32'd1;
          if (ev_req_done) begin
            c[f][silicaflux_virtio_pkg::PC_REQ_DONE] <= c[f][silicaflux_virtio_pkg::PC_REQ_DONE] + 32'd1;
            c[f][silicaflux_virtio_pkg::PC_LAT_SUM]  <= c[f][silicaflux_virtio_pkg::PC_LAT_SUM] + ev_lat;
            if (ev_lat > c[f][silicaflux_virtio_pkg::PC_LAT_MAX]) c[f][silicaflux_virtio_pkg::PC_LAT_MAX] <= ev_lat;
            if (ev_lat < c[f][silicaflux_virtio_pkg::PC_LAT_MIN]) c[f][silicaflux_virtio_pkg::PC_LAT_MIN] <= ev_lat;
          end
          if (ev_req_err)  c[f][silicaflux_virtio_pkg::PC_REQ_ERR]  <= c[f][silicaflux_virtio_pkg::PC_REQ_ERR] + 32'd1;
          if (ev_walk_v) begin
            c[f][silicaflux_virtio_pkg::PC_DESC]       <= c[f][silicaflux_virtio_pkg::PC_DESC] + {16'd0, ev_ndesc};
            c[f][silicaflux_virtio_pkg::PC_WALK_COUNT] <= c[f][silicaflux_virtio_pkg::PC_WALK_COUNT] + 32'd1;
            c[f][silicaflux_virtio_pkg::PC_WALK_SUM]   <= c[f][silicaflux_virtio_pkg::PC_WALK_SUM] + {16'd0, ev_walk};
            if ({16'd0, ev_walk} > c[f][silicaflux_virtio_pkg::PC_WALK_MAX]) c[f][silicaflux_virtio_pkg::PC_WALK_MAX] <= {16'd0, ev_walk};
          end
          if (ev_irq)      c[f][silicaflux_virtio_pkg::PC_IRQ_RAISED]     <= c[f][silicaflux_virtio_pkg::PC_IRQ_RAISED] + 32'd1;
          if (ev_irq_supp) c[f][silicaflux_virtio_pkg::PC_IRQ_SUPPRESSED] <= c[f][silicaflux_virtio_pkg::PC_IRQ_SUPPRESSED] + 32'd1;
          if (ev_viol)     c[f][silicaflux_virtio_pkg::PC_VIOLATIONS]     <= c[f][silicaflux_virtio_pkg::PC_VIOLATIONS] + 32'd1;
          if (ev_fatal)    c[f][silicaflux_virtio_pkg::PC_FATAL]          <= c[f][silicaflux_virtio_pkg::PC_FATAL] + 32'd1;
          if (ev_util_v) begin
            c[f][silicaflux_virtio_pkg::PC_UTIL_SUM]     <= c[f][silicaflux_virtio_pkg::PC_UTIL_SUM] + {16'd0, ev_util};
            c[f][silicaflux_virtio_pkg::PC_UTIL_SAMPLES] <= c[f][silicaflux_virtio_pkg::PC_UTIL_SAMPLES] + 32'd1;
            if ({16'd0, ev_util} > c[f][silicaflux_virtio_pkg::PC_UTIL_MAX]) c[f][silicaflux_virtio_pkg::PC_UTIL_MAX] <= {16'd0, ev_util};
          end
          if (ev_rd_data_v) c[f][silicaflux_virtio_pkg::PC_DMA_RD_DATA] <= c[f][silicaflux_virtio_pkg::PC_DMA_RD_DATA] + {16'd0, ev_bytes};
          if (ev_wr_data_v) c[f][silicaflux_virtio_pkg::PC_DMA_WR_DATA] <= c[f][silicaflux_virtio_pkg::PC_DMA_WR_DATA] + {16'd0, ev_bytes};
          if (ev_meta_v)    c[f][silicaflux_virtio_pkg::PC_DMA_META]    <= c[f][silicaflux_virtio_pkg::PC_DMA_META] + {16'd0, ev_bytes};
        end
      end
    end
  end
endmodule

`default_nettype wire
