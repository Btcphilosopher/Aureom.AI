// =============================================================================
// VirtualIO :: sfv_gdma -- the engine's ONLY path to guest memory and to the backend
//
// One command at a time moves up to STAGE_BYTES between the stage buffer and either
//   tgt = 0  guest memory  (SFB2 master gm_*, ranges validated by sfv_domain_adapter, beats guarded), or
//   tgt = 1  the protected backend (SFB2 master bk_*, with the domain id as a sideband; the backend has its own guard).
// Every walker / queue-controller / executor access (ring, descriptor, header, data, status, used entry) goes through
// here, so there is exactly one place where a guest address can reach the bus and it is always behind the adapter.
//
// The stage buffer is shared: small structures (descriptor, available-ring words, block header) land in stage[0..15] and
// are read through pk_data; structures to be written (used entry, status byte) are loaded with ld_* before the write.
//   result codes (c_code): silicaflux_virtio_pkg::GD_*   c_detail: the adapter's reason (DD_*) when GD_DENIED
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfv_gdma #(
  parameter int AW        = 48,
  parameter int DW        = 64,
  parameter int BKAW      = 32,
  parameter int STAGE     = 64,
  parameter int ND        = 2,
  parameter int NW        = 4,
  parameter int DOMW      = 1,
  parameter int EXT_IOMMU = 0
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // command
  input  wire logic              c_valid,
  output logic                   c_ready,
  input  wire logic              c_tgt,            // 0 guest memory, 1 backend
  input  wire logic              c_wr,             // 1 stage -> target, 0 target -> stage
  input  wire logic              c_data,           // 1: request data (statistics only)
  input  wire logic [DOMW-1:0]   c_dom,
  input  wire logic [63:0]       c_addr,
  input  wire logic [15:0]       c_len,            // 1 .. STAGE
  input  wire logic [$clog2(STAGE)-1:0] c_soff,
  input  wire logic              abort_i,
  output logic                   c_done,           // one-cycle pulse
  output logic                   c_err,
  output logic [7:0]             c_code,
  output logic [7:0]             c_detail,
  output logic                   busy_o,
  // stage side
  input  wire logic              ld_en,            // only while idle
  input  wire logic [127:0]      ld_data,
  input  wire logic [15:0]       ld_mask,
  output logic [127:0]           pk_data,
  // statistics pulses (valid in the c_done cycle, successful commands only)
  output logic                   ev_ok,
  output logic [15:0]            ev_len,
  output logic                   ev_tgt,
  output logic                   ev_wr,
  output logic                   ev_data,
  output logic                   ev_viol,          // a refusal (adapter or guard)
  output logic                   stall_o,          // request valid but not accepted this cycle
  // guest memory port
  output logic                   gm_req_valid,
  input  wire logic              gm_req_ready,
  output logic                   gm_req_write,
  output logic [AW-1:0]          gm_req_addr,
  output logic [DW-1:0]          gm_req_wdata,
  output logic [DW/8-1:0]        gm_req_wstrb,
  input  wire logic              gm_rsp_valid,
  output logic                   gm_rsp_ready,
  input  wire logic [DW-1:0]     gm_rsp_rdata,
  input  wire logic              gm_rsp_error,
  // backend port
  output logic                   bk_req_valid,
  input  wire logic              bk_req_ready,
  output logic                   bk_req_write,
  output logic [BKAW-1:0]        bk_req_addr,
  output logic [DW-1:0]          bk_req_wdata,
  output logic [DW/8-1:0]        bk_req_wstrb,
  output logic [DOMW-1:0]        bk_req_dom,
  input  wire logic              bk_rsp_valid,
  output logic                   bk_rsp_ready,
  input  wire logic [DW-1:0]     bk_rsp_rdata,
  input  wire logic              bk_rsp_error,
  // domain tables
  input  wire logic [ND-1:0]       dom_en,
  input  wire logic [ND*NW*64-1:0] win_base,
  input  wire logic [ND*NW*64-1:0] win_size,
  input  wire logic [ND*NW*3-1:0]  win_ctl,
  // external IOMMU
  output logic                   iommu_req_valid,
  input  wire logic              iommu_req_ready,
  output logic [DOMW-1:0]        iommu_req_dom,
  output logic [63:0]            iommu_req_iova,
  output logic [31:0]            iommu_req_len,
  output logic                   iommu_req_write,
  input  wire logic              iommu_rsp_valid,
  input  wire logic              iommu_rsp_ok,
  input  wire logic [AW-1:0]     iommu_rsp_pa
);
  localparam int BW  = DW / 8;
  localparam int SAW = $clog2(STAGE);
  localparam logic [2:0] G_IDLE = 3'd0, G_CHKREQ = 3'd1, G_CHK = 3'd2, G_MVGO = 3'd3, G_MV = 3'd4, G_FIN = 3'd5;

  logic [2:0]        st_q;
  logic              tgt_q, wr_q, data_q;
  logic [DOMW-1:0]   dom_q;
  logic [63:0]       addr_q;
  logic [15:0]       len_q;
  logic [SAW-1:0]    soff_q;
  logic [AW-1:0]     pa_q;
  logic [7:0]        code_q, detail_q;
  logic              viol_q;

  // ------------------------------------------------------------------ stage buffer
  logic [7:0] stage [0:STAGE-1];
`ifndef SYNTHESIS
  initial begin : init_stage
    integer i;
    for (i = 0; i < STAGE; i++) stage[i] = 8'h00;   // simulation only: no X in the stage before first use
  end
`endif

  logic [BW-1:0]      mv_st_we;
  logic [BW*SAW-1:0]  mv_widx, mv_ridx;
  logic [DW-1:0]      mv_wdata, mv_rdata;

  always_comb begin
    integer j;
    for (j = 0; j < BW; j++) mv_rdata[j*8 +: 8] = stage[mv_ridx[j*SAW +: SAW]];
    for (j = 0; j < 16; j++) pk_data[j*8 +: 8]  = stage[j];
  end

  always_ff @(posedge clk) begin
    integer j;
    for (j = 0; j < BW; j++)
      if (mv_st_we[j]) stage[mv_widx[j*SAW +: SAW]] <= mv_wdata[j*8 +: 8];
    if (ld_en && (st_q == G_IDLE))
      for (j = 0; j < 16; j++)
        if (ld_mask[j]) stage[j] <= ld_data[j*8 +: 8];
  end

  // ------------------------------------------------------------------ adapter
  logic              chk_done, chk_ok;
  logic [AW-1:0]     chk_pa;
  logic [7:0]        chk_detail;
  logic [AW-1:0]     g_lo;
  logic [15:0]       g_len;
  logic              g_ok_ad;

  sfv_domain_adapter #(.ND(ND), .NW(NW), .AW(AW), .DOMW(DOMW), .EXT_IOMMU(EXT_IOMMU)) u_adapter (
    .clk, .rst_n, .dom_en, .win_base, .win_size, .win_ctl,
    .chk_valid(st_q == G_CHKREQ), .chk_dom(dom_q), .chk_addr(addr_q), .chk_len({16'd0, len_q}), .chk_write(wr_q),
    .chk_done, .chk_ok, .chk_pa, .chk_detail,
    .g_dom(dom_q), .g_lo, .g_len, .g_write(wr_q), .g_ok(g_ok_ad), .grant_clear(st_q == G_FIN),
    .iommu_req_valid, .iommu_req_ready, .iommu_req_dom, .iommu_req_iova, .iommu_req_len, .iommu_req_write,
    .iommu_rsp_valid, .iommu_rsp_ok, .iommu_rsp_pa);

  // ------------------------------------------------------------------ mover
  logic              mv_busy, mv_done, mv_req_valid, mv_req_write, mv_rsp_ready;
  logic [2:0]        mv_res;
  logic [AW-1:0]     mv_req_addr;
  logic [DW-1:0]     mv_req_wdata;
  logic [BW-1:0]     mv_req_wstrb;
  logic              mv_req_ready, mv_rsp_valid, mv_rsp_error;
  logic [DW-1:0]     mv_rsp_rdata;

  sfv_beat_mover #(.AW(AW), .DW(DW), .SAW(SAW)) u_mv (
    .clk, .rst_n, .start(st_q == G_MVGO), .wr(wr_q), .addr(tgt_q ? {{(AW-BKAW){1'b0}}, addr_q[BKAW-1:0]} : pa_q),
    .len(len_q), .soff(soff_q), .abort_i, .busy(mv_busy), .done(mv_done), .res(mv_res),
    .req_valid(mv_req_valid), .req_ready(mv_req_ready), .req_write(mv_req_write), .req_addr(mv_req_addr),
    .req_wdata(mv_req_wdata), .req_wstrb(mv_req_wstrb),
    .rsp_valid(mv_rsp_valid), .rsp_ready(mv_rsp_ready), .rsp_rdata(mv_rsp_rdata), .rsp_error(mv_rsp_error),
    .g_lo, .g_len, .g_ok(tgt_q ? 1'b1 : g_ok_ad),
    .st_we(mv_st_we), .st_widx(mv_widx), .st_wdata(mv_wdata), .st_ridx(mv_ridx), .st_rdata(mv_rdata));

  // port steering
  assign gm_req_valid = mv_req_valid && !tgt_q;
  assign gm_req_write = mv_req_write;
  assign gm_req_addr  = mv_req_addr;
  assign gm_req_wdata = mv_req_wdata;
  assign gm_req_wstrb = mv_req_wstrb;
  assign gm_rsp_ready = mv_rsp_ready && !tgt_q;
  assign bk_req_valid = mv_req_valid && tgt_q;
  assign bk_req_write = mv_req_write;
  assign bk_req_addr  = mv_req_addr[BKAW-1:0];
  assign bk_req_wdata = mv_req_wdata;
  assign bk_req_wstrb = mv_req_wstrb;
  assign bk_req_dom   = dom_q;
  assign bk_rsp_ready = mv_rsp_ready && tgt_q;
  assign mv_req_ready = tgt_q ? bk_req_ready : gm_req_ready;
  assign mv_rsp_valid = tgt_q ? bk_rsp_valid : gm_rsp_valid;
  assign mv_rsp_rdata = tgt_q ? bk_rsp_rdata : gm_rsp_rdata;
  assign mv_rsp_error = tgt_q ? bk_rsp_error : gm_rsp_error;
  assign stall_o      = mv_req_valid && !mv_req_ready;

  // ------------------------------------------------------------------ command FSM
  assign c_ready = (st_q == G_IDLE);
  assign busy_o  = (st_q != G_IDLE);
  assign c_done  = (st_q == G_FIN);
  assign c_err   = (code_q != silicaflux_virtio_pkg::GD_OK);
  assign c_code  = code_q;
  assign c_detail = detail_q;
  assign ev_ok   = (st_q == G_FIN) && (code_q == silicaflux_virtio_pkg::GD_OK);
  assign ev_len  = len_q;
  assign ev_tgt  = tgt_q;
  assign ev_wr   = wr_q;
  assign ev_data = data_q;
  assign ev_viol = (st_q == G_FIN) && viol_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q     <= G_IDLE;
      tgt_q    <= 1'b0;
      wr_q     <= 1'b0;
      data_q   <= 1'b0;
      dom_q    <= '0;
      addr_q   <= 64'd0;
      len_q    <= 16'd0;
      soff_q   <= '0;
      pa_q     <= '0;
      code_q   <= silicaflux_virtio_pkg::GD_OK;
      detail_q <= silicaflux_virtio_pkg::DD_OK;
      viol_q   <= 1'b0;
    end else begin
      case (st_q)
        G_IDLE: begin
          if (c_valid) begin
            tgt_q    <= c_tgt;
            wr_q     <= c_wr;
            data_q   <= c_data;
            dom_q    <= c_dom;
            addr_q   <= c_addr;
            len_q    <= c_len;
            soff_q   <= c_soff;
            code_q   <= silicaflux_virtio_pkg::GD_OK;
            detail_q <= silicaflux_virtio_pkg::DD_OK;
            viol_q   <= 1'b0;
            st_q     <= c_tgt ? G_MVGO : G_CHKREQ;
          end
        end
        G_CHKREQ: st_q <= G_CHK;
        G_CHK: begin
          if (chk_done) begin
            detail_q <= chk_detail;
            pa_q     <= chk_pa;
            if (chk_ok) begin
              st_q <= G_MVGO;
            end else begin
              code_q <= silicaflux_virtio_pkg::GD_DENIED;
              viol_q <= 1'b1;
              st_q   <= G_FIN;
            end
          end
        end
        G_MVGO: begin
          if (abort_i) begin
            code_q <= silicaflux_virtio_pkg::GD_ABORT;
            st_q   <= G_FIN;
          end else begin
            st_q <= G_MV;
          end
        end
        G_MV: begin
          if (mv_done) begin
            case (mv_res)
              3'd0:    code_q <= silicaflux_virtio_pkg::GD_OK;
              3'd1:    begin code_q <= silicaflux_virtio_pkg::GD_GUARD; viol_q <= 1'b1; end
              3'd2:    code_q <= tgt_q ? silicaflux_virtio_pkg::GD_BKERR : silicaflux_virtio_pkg::GD_BUS;
              default: code_q <= silicaflux_virtio_pkg::GD_ABORT;
            endcase
            st_q <= G_FIN;
          end
        end
        G_FIN: st_q <= G_IDLE;
        default: st_q <= G_IDLE;
      endcase
    end
  end

  wire unused_gd = &{1'b0, mv_busy};
endmodule

`default_nettype wire
